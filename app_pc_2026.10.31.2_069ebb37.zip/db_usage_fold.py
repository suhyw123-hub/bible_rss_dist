"""자료 보유 현황 집계 — **참조 구현**(영구 도구 · `--selftest` 의무).

★★★ **왜 파이썬으로 쓰나** (2026-09-06).
  집계 자체는 **Cloudflare Worker** 가 한다(`api.hagahtorah.com` — 실측
  `Server: cloudflare`). 그런데 그 코드는 이 저장소에 없어서, 문서에
  의사코드만 적어 두면 **아무도 시험하지 않는다.**
  ⇒ 같은 로직을 여기서 한 벌 쓰고 **selftest 로 증명**한다. Worker 의 JS 는
    이 함수를 그대로 옮긴 것이고, 규칙이 바뀌면 **여기부터** 고친다.
  ⚠ **이 파일은 앱이 import 하지 않는다** — 서버 로직의 정본이자 시험대다.

★★ **가장 위험한 자리는 멱등이다.**
  앱은 한 달치를 **덮어쓰기**로 다시 보낼 수 있다(`usage_stats.flush_current`).
  그냥 `n = n + 1` 하면 **같은 사람을 두 번 센다.** 그러면 「몇 명이
  최신인가」가 사람 수보다 커지고, 그 수치는 조용히 틀린 채로 쌓인다.
  ⇒ **그 사람의 지난 값을 먼저 빼고 새 값을 더한다.**

★ **`uuid` 는 분포 표에 안 들어간다** — 넣는 순간 「누가 무엇을 갖고 있나」가
  되어 익명 집계가 아니게 된다. uuid 를 쥐는 것은 **멱등용 작업 표 하나**뿐이고
  그 표는 집계가 끝난 달에 지워도 된다.

사용법
  python db_usage_fold.py --selftest      자가 검증(의무)
  python db_usage_fold.py --js            Worker 에 붙여넣을 JS 조각을 낸다
"""

import os
import sys
import json
import sqlite3

#: 릴리스(코어 판)를 담는 자리표. 자산 열쇠와 겹칠 수 없는 글자여야 한다.
REL_KEY = "*"

SCHEMA = """
CREATE TABLE IF NOT EXISTS usage_pack_release (
  period_ym TEXT    NOT NULL,
  release   INTEGER NOT NULL,
  n         INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (period_ym, release)
);
CREATE TABLE IF NOT EXISTS usage_pack_asset (
  period_ym TEXT    NOT NULL,
  akey      TEXT    NOT NULL,
  version   INTEGER NOT NULL,
  n         INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (period_ym, akey, version)
);
-- ⚠ 멱등용 작업 표 — 여기에만 uuid 가 있다(분포 표에는 없다)
CREATE TABLE IF NOT EXISTS usage_pack_last (
  uuid      TEXT    NOT NULL,
  period_ym TEXT    NOT NULL,
  akey      TEXT    NOT NULL,
  version   INTEGER NOT NULL,
  PRIMARY KEY (uuid, period_ym, akey)
);
"""


def init(conn):
    conn.executescript(SCHEMA)
    conn.commit()


# ── 집계 ────────────────────────────────────────────────────────────
def _rows_of(payload):
    """payload → [(akey, version)]. **보낼 값이 없으면 빈 목록.**

    ⚠ **판이 0 이하이거나 정수가 아니면 버린다** — 앱이 「모르는 판은 안
      보낸다」는 규칙을 지키지만(§`_pack_fields`), 받는 쪽도 믿지 않는다.
      0 을 세면 「받았는데 0 판」이라는 거짓 집계가 된다.
    """
    out = []
    rel = payload.get("pack_release")
    if isinstance(rel, int) and not isinstance(rel, bool) and rel > 0:
        out.append((REL_KEY, rel))
    assets = payload.get("assets")
    if isinstance(assets, dict):
        for k, v in assets.items():
            if not isinstance(k, str) or not k:
                continue
            if k == REL_KEY:          # 자리표와 겹치는 열쇠는 버린다
                continue
            if isinstance(v, int) and not isinstance(v, bool) and v > 0:
                out.append((k, v))
    return out


def _bump(conn, ym, akey, ver, d):
    """분포 한 칸을 d 만큼 옮긴다.

    ⚠ **0 아래로 안 내려간다** — 사람이 자료를 지우고 다시 받는 사이에
      순서가 뒤엉킬 수 있다. 음수 인원은 어떤 경우에도 뜻이 없다.
    """
    if akey == REL_KEY:
        conn.execute(
            "INSERT INTO usage_pack_release(period_ym, release, n) VALUES(?,?,?) "
            "ON CONFLICT(period_ym, release) DO UPDATE SET n = MAX(0, n + ?)",
            (ym, ver, max(0, d), d))
    else:
        conn.execute(
            "INSERT INTO usage_pack_asset(period_ym, akey, version, n) VALUES(?,?,?,?) "
            "ON CONFLICT(period_ym, akey, version) DO UPDATE SET n = MAX(0, n + ?)",
            (ym, akey, ver, max(0, d), d))


def fold(conn, uuid, payload):
    """한 통을 접는다. 몇 칸이 움직였는지 돌려준다.

    ★ **멱등** — 같은 통을 다시 받으면 아무것도 안 움직인다(0).
    ⚠ 부르는 쪽은 이 함수 전체를 `try` 로 감싼다 — **집계가 실패해도 접수는
      성공해야 한다**(이용통계 본체는 이미 저장돼 있다).
    """
    ym = payload.get("period_ym")
    if not uuid or not isinstance(ym, str) or not ym:
        return 0
    moved = 0
    for akey, ver in _rows_of(payload):
        row = conn.execute(
            "SELECT version FROM usage_pack_last "
            "WHERE uuid=? AND period_ym=? AND akey=?", (uuid, ym, akey)).fetchone()
        prev = row[0] if row else None
        if prev == ver:
            continue                      # 안 바뀌었다 — 두 번 세지 않는다
        if prev is not None:
            _bump(conn, ym, akey, prev, -1)
        _bump(conn, ym, akey, ver, +1)
        conn.execute(
            "INSERT INTO usage_pack_last(uuid, period_ym, akey, version) VALUES(?,?,?,?) "
            "ON CONFLICT(uuid, period_ym, akey) DO UPDATE SET version = excluded.version",
            (uuid, ym, akey, ver))
        moved += 1
    conn.commit()
    return moved


def stats(conn, ym=None):
    """`/v1/stats` 에 실을 두 열쇠를 만든다.

    ⚠ 이름은 **관리자 화면이 읽는 그대로**여야 한다
      (`admin/panel_usage_stats._fill_pack`). 여기서 바꾸면 화면이 조용히 빈다.
    """
    if ym is None:
        r = conn.execute("SELECT MAX(period_ym) FROM ("
                         "SELECT period_ym FROM usage_pack_release "
                         "UNION SELECT period_ym FROM usage_pack_asset)").fetchone()
        ym = r[0] if r else None
    if not ym:
        return {"pack_release_dist": [], "pack_asset_dist": []}
    rel = [{"release": a, "n": b} for a, b in conn.execute(
        "SELECT release, n FROM usage_pack_release "
        "WHERE period_ym=? AND n>0 ORDER BY release DESC", (ym,))]
    ast_ = [{"key": a, "version": b, "n": c} for a, b, c in conn.execute(
        "SELECT akey, version, n FROM usage_pack_asset "
        "WHERE period_ym=? AND n>0 ORDER BY n DESC, akey", (ym,))]
    return {"pack_release_dist": rel, "pack_asset_dist": ast_}


def prune(conn, keep_ym):
    """집계가 끝난 달의 **작업 표**를 비운다(분포는 남긴다).

    ⚠ uuid 를 쥐는 유일한 표라 오래 들고 있을 이유가 없다.
    """
    n = conn.execute("DELETE FROM usage_pack_last WHERE period_ym < ?",
                     (keep_ym,)).rowcount
    conn.commit()
    return n


# ── Worker 에 붙여넣을 JS ───────────────────────────────────────────
JS = r"""
// ── 자료 보유 현황 집계 (hagahtorah) ───────────────────────────────
// 정본 로직 = app/db_usage_fold.py (파이썬 selftest 로 증명돼 있다).
// 규칙을 바꾸면 그 파일부터 고치고 여기로 옮긴다.
const REL_KEY = '*';

async function ensurePackSchema(db) {
  await db.batch([
    db.prepare(`CREATE TABLE IF NOT EXISTS usage_pack_release (
      period_ym TEXT NOT NULL, release INTEGER NOT NULL,
      n INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (period_ym, release))`),
    db.prepare(`CREATE TABLE IF NOT EXISTS usage_pack_asset (
      period_ym TEXT NOT NULL, akey TEXT NOT NULL, version INTEGER NOT NULL,
      n INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (period_ym, akey, version))`),
    db.prepare(`CREATE TABLE IF NOT EXISTS usage_pack_last (
      uuid TEXT NOT NULL, period_ym TEXT NOT NULL, akey TEXT NOT NULL,
      version INTEGER NOT NULL, PRIMARY KEY (uuid, period_ym, akey))`),
  ]);
}

function packRows(payload) {
  const out = [];
  const rel = payload.pack_release;
  if (Number.isInteger(rel) && rel > 0) out.push([REL_KEY, rel]);
  const a = payload.assets;
  if (a && typeof a === 'object') {
    for (const [k, v] of Object.entries(a)) {
      if (!k || k === REL_KEY) continue;
      if (Number.isInteger(v) && v > 0) out.push([k, v]);
    }
  }
  return out;
}

async function packBump(db, ym, akey, ver, d) {
  const seed = Math.max(0, d);
  if (akey === REL_KEY) {
    await db.prepare(
      `INSERT INTO usage_pack_release(period_ym, release, n) VALUES(?,?,?)
       ON CONFLICT(period_ym, release) DO UPDATE SET n = MAX(0, n + ?)`
    ).bind(ym, ver, seed, d).run();
  } else {
    await db.prepare(
      `INSERT INTO usage_pack_asset(period_ym, akey, version, n) VALUES(?,?,?,?)
       ON CONFLICT(period_ym, akey, version) DO UPDATE SET n = MAX(0, n + ?)`
    ).bind(ym, akey, ver, seed, d).run();
  }
}

// 같은 달을 다시 받아도 두 번 세지 않는다: 지난 값을 빼고 새 값을 더한다.
async function foldPack(db, uuid, payload) {
  const ym = payload.period_ym;
  if (!uuid || typeof ym !== 'string' || !ym) return 0;
  let moved = 0;
  for (const [akey, ver] of packRows(payload)) {
    const prev = await db.prepare(
      `SELECT version FROM usage_pack_last WHERE uuid=? AND period_ym=? AND akey=?`
    ).bind(uuid, ym, akey).first();
    if (prev && prev.version === ver) continue;
    if (prev) await packBump(db, ym, akey, prev.version, -1);
    await packBump(db, ym, akey, ver, +1);
    await db.prepare(
      `INSERT INTO usage_pack_last(uuid, period_ym, akey, version) VALUES(?,?,?,?)
       ON CONFLICT(uuid, period_ym, akey) DO UPDATE SET version = excluded.version`
    ).bind(uuid, ym, akey, ver).run();
    moved++;
  }
  return moved;
}

// /v1/stats 에 더할 두 열쇠. 이름은 관리자 화면이 읽는 그대로여야 한다.
async function packStats(db, ym) {
  if (!ym) {
    const r = await db.prepare(
      `SELECT MAX(period_ym) AS ym FROM (
         SELECT period_ym FROM usage_pack_release
         UNION SELECT period_ym FROM usage_pack_asset)`).first();
    ym = r && r.ym;
  }
  if (!ym) return { pack_release_dist: [], pack_asset_dist: [] };
  const rel = await db.prepare(
    `SELECT release, n FROM usage_pack_release
     WHERE period_ym=? AND n>0 ORDER BY release DESC`).bind(ym).all();
  const ast = await db.prepare(
    `SELECT akey AS key, version, n FROM usage_pack_asset
     WHERE period_ym=? AND n>0 ORDER BY n DESC, akey`).bind(ym).all();
  return { pack_release_dist: rel.results || [], pack_asset_dist: ast.results || [] };
}

/* 배선 두 자리 ─────────────────────────────────────────────────────
   ① POST /v1/usage 안, 이용통계 본체를 저장한 **뒤**:
        try { await ensurePackSchema(env.DB);
              await foldPack(env.DB, payload.uuid, payload); }
        catch (e) { }        // ⚠ 집계 실패가 접수 실패가 되면 안 된다
   ② GET /v1/stats 응답을 만들 때:
        Object.assign(out, await packStats(env.DB, null));
   ─────────────────────────────────────────────────────────────── */
"""


# ── 자가 검증 ───────────────────────────────────────────────────────
def _selftest():
    ok = [0]
    fail = []

    def chk(name, cond):
        if cond:
            ok[0] += 1
        else:
            fail.append(name)
        print(("  OK  " if cond else "  FAIL") + " " + name)

    c = sqlite3.connect(":memory:")
    init(c)
    ym = "2026-09"

    def n_rel(v):
        r = c.execute("SELECT n FROM usage_pack_release WHERE period_ym=? AND release=?",
                      (ym, v)).fetchone()
        return r[0] if r else 0

    def n_ast(k, v):
        r = c.execute("SELECT n FROM usage_pack_asset "
                      "WHERE period_ym=? AND akey=? AND version=?", (ym, k, v)).fetchone()
        return r[0] if r else 0

    P = {"period_ym": ym, "pack_release": 3,
         "assets": {"BOOK|SPURGEON_ME|KO": 2, "BIBLE|KRV|": 1}}

    # ① 처음 받으면 센다
    fold(c, "u1", P)
    chk("첫 통 — 릴리스 3 = 1명", n_rel(3) == 1)
    chk("첫 통 — 자산 두 칸", n_ast("BOOK|SPURGEON_ME|KO", 2) == 1 and n_ast("BIBLE|KRV|", 1) == 1)

    # ② ★ 멱등 — 같은 통을 다시 받아도 안 는다
    moved = fold(c, "u1", P)
    chk("★ 같은 통 재수신 — 움직인 칸 0", moved == 0)
    chk("★ 같은 통 재수신 — 릴리스 그대로 1", n_rel(3) == 1)

    # ③ 판이 오르면 옛 칸에서 빠지고 새 칸으로 간다
    fold(c, "u1", dict(P, pack_release=4))
    chk("판 오름 — 옛 칸 0", n_rel(3) == 0)
    chk("판 오름 — 새 칸 1", n_rel(4) == 1)

    # ④ 사람이 늘면 더해진다
    fold(c, "u2", dict(P, pack_release=4))
    chk("둘째 사람 — 릴리스 4 = 2명", n_rel(4) == 2)

    # ⑤ 0 아래로 안 내려간다
    _bump(c, ym, REL_KEY, 9, -5)
    chk("음수 방지 — MAX(0, …)", n_rel(9) == 0)

    # ⑥ 못 믿을 값은 버린다
    c2 = sqlite3.connect(":memory:")
    init(c2)
    fold(c2, "u9", {"period_ym": ym, "pack_release": 0,
                    "assets": {"A|B|C": 0, "": 3, REL_KEY: 7, "D|E|F": True}})
    left = c2.execute("SELECT COUNT(*) FROM usage_pack_release").fetchone()[0] + \
        c2.execute("SELECT COUNT(*) FROM usage_pack_asset").fetchone()[0]
    chk("0·빈 열쇠·자리표·bool 은 안 센다", left == 0)

    # ⑦ uuid 가 분포 표에 없다
    cols = set()
    for t in ("usage_pack_release", "usage_pack_asset"):
        cols |= {r[1] for r in c.execute("PRAGMA table_info(%s)" % t)}
    chk("★ 분포 표에 uuid 가 없다", "uuid" not in cols)

    # ⑧ 화면이 읽는 열쇠 이름이 맞다
    st = stats(c, ym)
    chk("stats 열쇠 이름", set(st) == {"pack_release_dist", "pack_asset_dist"})
    chk("stats 릴리스 값", any(r["release"] == 4 and r["n"] == 2 for r in st["pack_release_dist"]))
    chk("stats 자산 칸 이름 = key/version/n",
        (not st["pack_asset_dist"]) or set(st["pack_asset_dist"][0]) == {"key", "version", "n"})

    # ⑨ 관리자 화면이 실제로 그 이름을 읽는가 — 두 벌이 갈리지 않게 잰다
    try:
        import io as _io
        src = _io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    "admin", "panel_usage_stats.py"),
                       encoding="utf-8").read()
    except Exception:
        src = ""
    chk("★ 관리자 화면이 같은 열쇠를 읽는다",
        "pack_release_dist" in src and "pack_asset_dist" in src)

    # ⑩ 작업 표만 비운다
    before_rel = n_rel(4)
    prune(c, "2026-10")
    chk("prune — 작업 표는 비고", c.execute(
        "SELECT COUNT(*) FROM usage_pack_last").fetchone()[0] == 0)
    chk("prune — 분포는 남는다", n_rel(4) == before_rel)

    # ⑪ JS 조각이 파이썬과 같은 규칙을 담고 있다
    for needle in ("MAX(0, n + ?)", "usage_pack_last", "packStats",
                   "pack_release_dist", "prev.version === ver"):
        chk("JS 조각에 '%s'" % needle, needle in JS)

    c.close()
    c2.close()
    print("db_usage_fold selftest %d/%d" % (ok[0], ok[0] + len(fail)))
    if fail:
        print("실패: " + ", ".join(fail))
    sys.exit(0 if not fail else 1)


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        _selftest()
    elif "--js" in sys.argv:
        os.write(1, JS.encode("utf-8"))
    else:
        print(__doc__)
