"""익명 이용통계 클라이언트 — user_data.db 로컬 카운터 + 월 1회 전송.

약관: docs/consent_{KO,EN}.md · 스키마: docs/usage_schema.md · 서버: api.hagahtorah.com
원칙:
  - 개인식별정보·콘텐츠·IP·국가 미수집. 익명 UUID + 카운트만.
  - **비동의 시 어떤 기록/전송도 하지 않는다.**
  - **어린이 모드 활성 중에는 어떤 카운터도 증가시키지 않는다.**
  - period 는 UTC 'YYYY-MM'. 전송은 멱등(서버가 uuid+period 로 덮어씀).

사용(앱 측):
  import usage_stats as us
  us.init()                                   # 앱 시작 시 1회 (스키마 보장)
  if us.has_consent() is None: <동의 다이얼로그>  # 최초 실행
  us.set_kids_mode(True/False)                # 어린이 모드 진입/이탈
  us.start_session(app_ver, lang, bible_ver)  # 앱 시작(동의 시 sessions++ & 월 전송 시도)
  us.screen_hit('p1_read')                    # 화면 진입
  us.bump('note_create')                      # 액션 발생
"""
import os
import json
import sqlite3
import threading
import datetime
import platform
import urllib.request

import appdb

# ── 설정 ────────────────────────────────────────────────────────────
ENDPOINT = "https://api.hagahtorah.com/v1/usage"
CONSENT_ENDPOINT = "https://api.hagahtorah.com/v1/consent"
APP_KEY = "3f5cf305d37283d3f68becac858ba330"   # 가벼운 스팸 필터(배포 앱에 내장 — 준공개)
PAYLOAD_VER = 3      # 2 = 자료 보유 현황(pack_release·assets) 포함 · 3 = 쇼핑몰 열쇠 shop_*:…(2026-10-25)
_TIMEOUT = 10

# ★★★ 2026-10-20 — 화면·동작 **등록표 하나**(PC · 폰 공통 · 관리자 화면이 이 표에서 이름·묶음을 읽는다).
#   사용자 지시 「폰이 추가되었고 화면들이 추가되었다. 폰, 새로운 화면을 중심으로 이용통계를 체계적으로」.
#   ⚠ 그전에는 화이트리스트가 9월 이전에 멈춰 **새 화면 코드(p4_refs · plan_theme · plan_pick)를 조용히 버렸다** —
#     기록하는 쪽은 부르는데 거르는 쪽이 몰라서 0 이었다(§0-1). 이제 거르개와 이름표가 **같은 표**다.
#   ⚠⚠ 코드는 **바꾸지 않는다** — 바꾸면 지난 달 값과 갈린다. 걷은 화면은 넷째 칸 True 로 이름표만 남긴다.
#   ★ 폰 코드는 m_ 로 시작한다 — 서버는 열쇠를 이름과 상관없이 더하므로 서버를 안 고치고 PC·폰이 갈린다.
#   꼴 = 코드: (기기 PC|M, 묶음, 이름, 걷은 화면인가)
SCREENS = {
    # ── PC P1 ──
    'p1_bible':      ('PC', '성경', 'P1 성경읽기', False),
    'p1_read':       ('PC', '도서/설교', 'P1 도서/설교집', False),
    'p1_plan':       ('PC', '묵상플랜', 'P1 묵상플랜', False),
    'mypath':        ('PC', '나의 묵상', 'P1 나의 묵상', False),
    'announce':      ('PC', '소통', 'P1 공지', False),
    'inquiry':       ('PC', '소통', 'P1 1:1 문의', False),
    'plan_whole':    ('PC', '묵상플랜', '플랜 · 전체읽기', False),
    'plan_theme':    ('PC', '묵상플랜', '플랜 · 주제읽기', False),
    'plan_diag':     ('PC', '묵상플랜', '플랜 · 회복묵상', False),
    'plan_lens':     ('PC', '묵상플랜', '플랜 · 렌즈묵상', False),
    'plan_mine':     ('PC', '묵상플랜', '플랜 · 내 플랜', False),
    'plan_room':     ('PC', '묵상플랜', '플랜 · 함께 묵상', False),
    # ── PC P2 ──
    'p2_desc':       ('PC', '설명·주석', 'P2 설명', False),
    'p2_note':       ('PC', '노트', 'P2 묵상노트', False),
    # ── PC P4 ──
    'p4_compare':    ('PC', '성경', 'P4 역본비교', False),
    'p4_canvas':     ('PC', '연결', 'P4 구절 연결', False),
    'p4_flow':       ('PC', '연결', 'P4 말씀의 흐름', False),
    'p4_comm':       ('PC', '설명·주석', 'P4 주석', False),
    'p4_terms':      ('PC', '주요용어', 'P4 주요용어', False),
    'p4_refs':       ('PC', '연구/설교노트', 'P4 연구/설교노트', False),
    'p4_video':      ('PC', '영상', 'P4 온라인 영상', False),
    'p4_ai':         ('PC', 'AI', 'P4 AI 도우미', False),
    'p4_geneal_m':   ('PC', '지도·가계도', 'P4 메시아 가계도', False),
    'p4_pilgrim':    ('PC', '지도·가계도', 'P4 믿음의 발자취', False),
    'media':         ('PC', '소식', 'P4 최신 콘텐츠', False),
    'p4_shop':       ('PC', '쇼핑몰', 'P4 쇼핑몰', False),
    # ── PC 주요용어 안쪽 ──
    'entity_desc':   ('PC', '주요용어', '용어 · 용어사전', False),
    'entity_pericope': ('PC', '주요용어', '용어 · 용례구절', False),
    'entity_links':  ('PC', '주요용어', '용어 · 자료·영상', False),
    # ── PC 설정 ──
    'settings':      ('PC', '설정', '설정 열기', False),
    'set_start':     ('PC', '설정', '설정 · 시작/종료', False),
    'set_vlf':       ('PC', '설정', '설정 · 버전/언어/폰트', False),
    'set_screen':    ('PC', '설정', '설정 · 화면 선택', False),
    'set_download':  ('PC', '설정', '설정 · 다운로드', False),
    'set_mobile':    ('PC', '설정', '설정 · 모바일 연결', False),
    'set_ytsave':    ('PC', '설정', '설정 · 유튜브 간편 저장', False),
    'set_care':      ('PC', '설정', '설정 · 앱 관리', False),
    # ── PC 걷은 화면(지난 기록을 읽으려고 이름표만) ──
    'p4_tree':       ('PC', '연결', '(옛) 연결구절 트리', True),
    'p4_report':     ('PC', '연결', '(옛) 리포트', True),
    'p4_geneal_d':   ('PC', '지도·가계도', '(옛) 제자 가계도', True),
    'p2_commentary': ('PC', '설명·주석', '(옛) P2 주석', True),
    'p2_internal':   ('PC', '연구/설교노트', '(옛) P2 내부자료', True),
    'p2_links':      ('PC', '연결', '(옛) P2 링크', True),
    'res_commentary': ('PC', '설명·주석', '(옛) 리서치 주석', True),
    'res_internal':  ('PC', '연구/설교노트', '(옛) 리서치 내부자료', True),
    'res_links':     ('PC', '연결', '(옛) 리서치 링크', True),
    'res_note':      ('PC', '노트', '(옛) 리서치 묵상노트', True),
    'entity_dict':   ('PC', '주요용어', '(옛) 엔티티 사전', True),
    'entity_journey': ('PC', '주요용어', '(옛) 엔티티 여정', True),
    'plan_book':     ('PC', '묵상플랜', '(옛) 플랜 도서묵상', True),
    'plan_pick':     ('PC', '묵상플랜', '(옛) 플랜 골라담기', True),
    'entity':        ('PC', '주요용어', '(옛) 엔티티', True),
    'pericope':      ('PC', '연결', '(옛) 페리코프', True),
    # ── 폰 ──
    'm_home':        ('M', '홈', '홈', False),
    'm_bible':       ('M', '성경', '성경', False),
    'm_plan':        ('M', '묵상플랜', '플랜', False),
    'm_library':     ('M', '도서/설교', '내 서재', False),
    'm_youtube':     ('M', '영상', '유튜브', False),
    'm_desc':        ('M', '설명·주석', '구절 · 설명', False),
    'm_comm':        ('M', '설명·주석', '구절 · 주석', False),
    'm_compare':     ('M', '성경', '구절 · 역본비교', False),
    'm_lex':         ('M', '주요용어', '구절 · 원어', False),
    'm_links':       ('M', '연결', '구절 · 연결구절', False),
    'm_ref':         ('M', '연구/설교노트', '구절 · 연구설교', False),
    'm_video':       ('M', '영상', '구절 · 유튜브', False),
    'm_note':        ('M', '노트', '구절 · 노트', False),
    'm_ai':          ('M', 'AI', 'AI 도우미', False),
    'm_search':      ('M', '성경', '검색', False),
    'm_prayer':      ('M', '기도', '기도 노트', False),
    'm_memo':        ('M', '암송', '암송', False),
    'm_notice':      ('M', '소통', '공지', False),
    'm_settings':    ('M', '설정', '설정', False),
    'm_packs':       ('M', '설정', '설정 · 자료 받기', False),
    'm_sync':        ('M', '설정', '설정 · PC 와 함께 쓰기', False),
    'm_player':      ('M', '영상', '영상 재생 화면', False),
    # ★ 2026-10-27 (docs/1.txt 3) 새 화면(폰 kUsageScreens 와 같다)
    'm_card':        ('M', '말씀카드', '말씀카드', False),
    'm_explore':     ('M', '둘러보기', '둘러보기', False),
    'm_timeline':    ('M', '둘러보기', '연대표', False),
    'm_footsteps':   ('M', '둘러보기', '믿음의 발자취', False),
    'm_genealogy':   ('M', '둘러보기', '가계도', False),
    'm_sitephoto':   ('M', '둘러보기', '성경 유적 사진', False),
    'm_news':        ('M', '홈', '최신 뉴스 · 묵상', False),
    'm_mysite':      ('M', '홈', '내가 모은 사이트', False),
    'm_shop':        ('M', '쇼핑몰', '추천몰', False),
    'm_refwrite':    ('M', '연구/설교노트', '연구/설교노트 쓰기', False),
    'm_ailib':       ('M', 'AI', '프롬프트 라이브러리', False),
    'm_chatclean':   ('M', 'AI', 'AI 대화 정리', False),
    # ★ 2026-10-28 docs/1.txt 3 — 새 화면(공동체몰 · 수집함 · 노트 목록 · 녹음 설정 · 자료로 대화)
    'm_cmall':       ('M', '쇼핑몰', '공동체몰', False),
    'm_cmall_owner': ('M', '쇼핑몰', '공동체몰 · 내 가게 등록', False),
    'm_saved':       ('M', '영상', '유튜브 · 수집함', False),
    'm_refnotes':    ('M', '연구/설교노트', '내서재 · 연구/설교노트', False),
    'm_favverses':   ('M', '성경', '즐겨찾기 구절', False),
    'm_booknotes':   ('M', '노트', '도서노트', False),
    'm_voice':       ('M', '설정', '설정 · 녹음', False),
    'm_ai_mat':      ('M', 'AI', 'AI 대화 · 자료로 대화', False),
    'm_pilgrim':     ('M', '둘러보기', '순례 코스', False),
}
#: 동작 — 꼴 = 코드: (기기, 이름). 폰은 m_ 접두.
COUNTERS = {
    'sessions': ('PC', '접속 횟수'), 'active_days': ('PC', '사용일수'),
    'note_create': ('PC', '묵상노트 새로'), 'note_edit': ('PC', '묵상노트 고침'),
    'highlight_add': ('PC', '하이라이트'), 'favorite_add': ('PC', '즐겨찾기'),
    'search_run': ('PC', '검색'), 'commentary_open': ('PC', '주석 열람'),
    'book_read_open': ('PC', '도서 열람'), 'lens_use': ('PC', '렌즈묵상'),
    'plan_enroll': ('PC', '플랜 시작'), 'plan_progress': ('PC', '플랜 진도'),
    'plan_complete': ('PC', '플랜 완료'), 'media_play': ('PC', '영상 재생'),
    'version_compare': ('PC', '역본 비교'), 'diagnosis_done': ('PC', '(옛) 자가진단'),
    'ai_send': ('PC', 'AI 보내기'),
    'dev_pc': ('PC', 'PC 사용자(그 달)'),
    'm_sessions': ('M', '접속 횟수'), 'm_active_days': ('M', '사용일수'),
    'm_note_create': ('M', '노트 새로'), 'm_favorite_add': ('M', '즐겨찾기'),
    'm_search_run': ('M', '검색'), 'm_media_play': ('M', '영상 재생'),
    'm_plan_progress': ('M', '플랜 진도'), 'm_ai_send': ('M', 'AI 보내기'),
    'm_prayer_add': ('M', '기도 새로'), 'm_share': ('M', '공유'),
    'm_voice_rec': ('M', '녹음'),
    'dev_m': ('M', '폰 사용자(그 달)'),
}
# 이 PC 앱이 기록해도 되는 열쇠(오타·무한증식 차단) — 등록표에서 PC 것만
_COUNTERS = {k for k, v in COUNTERS.items() if v[0] == 'PC' and k != 'dev_pc'}
_SCREENS = {k for k, v in SCREENS.items() if v[0] == 'PC'}

_kids_mode = False   # 어린이 모드 게이트


# ── 연결 ────────────────────────────────────────────────────────────
def _db_path():
    # bible_master.db 와 같은 폴더의 user_data.db
    return appdb.user_db_path(appdb.MAIN_DB)


def _conn():
    c = sqlite3.connect(_db_path(), timeout=20)
    try:
        c.execute("PRAGMA busy_timeout=20000")
        c.execute("PRAGMA journal_mode=WAL")
    except Exception:
        pass
    return c


def _ensure(c):
    c.executescript("""
        CREATE TABLE IF NOT EXISTS usage_counter (
          period_ym  TEXT NOT NULL,
          metric_key TEXT NOT NULL,
          count      INTEGER NOT NULL DEFAULT 0,
          PRIMARY KEY (period_ym, metric_key)
        );
        CREATE TABLE IF NOT EXISTS usage_active_day (
          ymd TEXT PRIMARY KEY
        );
        CREATE TABLE IF NOT EXISTS usage_state (
          key TEXT PRIMARY KEY,
          value TEXT
        );
    """)


# ── 시간(UTC) ───────────────────────────────────────────────────────
def _now_ym():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m")


def _now_ymd():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d")


# ── 상태 ────────────────────────────────────────────────────────────
def init():
    """앱 시작 시 1회 — 스키마 보장. 실패해도 앱에 영향 없음."""
    try:
        c = _conn()
        try:
            _ensure(c)
            c.commit()
        finally:
            c.close()
    except Exception:
        pass


def _get_state(c, key, default=None):
    r = c.execute("SELECT value FROM usage_state WHERE key=?", (key,)).fetchone()
    return r[0] if r else default


def _set_state(c, key, value):
    c.execute(
        "INSERT INTO usage_state(key,value) VALUES(?,?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (key, str(value)),
    )


def has_consent():
    """True(동의)/False(거부)/None(아직 안 물어봄)."""
    try:
        c = _conn()
        try:
            _ensure(c)
            v = _get_state(c, "consent")
            if v is None:
                return None
            return v == "1"
        finally:
            c.close()
    except Exception:
        return None


def set_consent(agreed):
    """동의 다이얼로그/설정 토글에서 호출. 동의 시 UUID 생성·install_ym 기록."""
    try:
        import uuid as _u
        c = _conn()
        try:
            _ensure(c)
            _set_state(c, "consent", "1" if agreed else "0")
            _set_state(c, "consent_ts", _now_ymd())
            if agreed:
                # ★ **동의한 약관 판을 적어 둔다** — 새 칸이 생기면 옛 동의로
                #   덮지 않는다(위 `CONSENT_VER` 주석).
                _set_state(c, CONSENT_VER_KEY, str(CONSENT_VER))
                if _get_state(c, "uuid") is None:
                    _set_state(c, "uuid", str(_u.uuid4()))
                if _get_state(c, "install_ym") is None:
                    _set_state(c, "install_ym", _now_ym())
                if _get_state(c, "consent_first_date") is None:
                    _set_state(c, "consent_first_date", _now_ymd())
            c.commit()
        finally:
            c.close()
    except Exception:
        pass


def is_enabled():
    return has_consent() is True


def set_kids_mode(on):
    """어린이 모드 진입(True)/이탈(False). 활성 중 모든 카운트 차단."""
    global _kids_mode
    _kids_mode = bool(on)


# ── 카운트 ──────────────────────────────────────────────────────────
def _gate():
    return (not _kids_mode) and is_enabled()


def _bump_keys(keys, mark_active=True):
    """keys: [(metric_key, n), ...] 를 현재 월에 누적.
    **비동기(데몬 스레드)** — 호출자의 열린 DB 트랜잭션(노트/즐겨찾기/플랜 저장 등) 안에서
    호출돼도 UI/저장을 막지 않는다. user_data.db 쓰기잠금이 풀린 뒤 기록(busy_timeout 대기)."""
    if not keys:
        return

    def _w():
        try:
            ym = _now_ym()
            c = _conn()
            try:
                _ensure(c)
                for mk, n in keys:
                    c.execute(
                        "INSERT INTO usage_counter(period_ym,metric_key,count) VALUES(?,?,?) "
                        "ON CONFLICT(period_ym,metric_key) DO UPDATE SET count=count+?",
                        (ym, mk, n, n),
                    )
                if mark_active:
                    c.execute("INSERT OR IGNORE INTO usage_active_day(ymd) VALUES(?)", (_now_ymd(),))
                c.commit()
            finally:
                c.close()
        except Exception:
            pass

    threading.Thread(target=_w, daemon=True).start()


def bump(metric_key, n=1):
    """액션 카운터 +n. 유효 키만."""
    if not _gate() or metric_key not in _COUNTERS:
        return
    _bump_keys([(metric_key, n)])


SHOP_KINDS = ('item', 'mall', 'search', 'repeat', 'gift')


def shop_event(kind, ident):
    """★ 2026-10-25 (docs/1.txt 4) 쇼핑몰 통계 — 열쇠 `shop_<kind>:<id>`(폰 UsageRepo.shopEvent 와 같은 꼴).
    kind = item(상품 열기) · mall(쇼핑몰 열기) · search(그 쇼핑몰 검색) · repeat(자주 사는 상품) · gift(기프트카드 보내기)
    id = 상품 번호·쇼핑몰 코드(글자·숫자·_- · 40자) — 그 밖은 버린다(오타로 열쇠가 늘지 않게) · 사람은 모른다(수만)."""
    import re as _re
    ident = str(ident or '')
    if not _gate() or kind not in SHOP_KINDS or not _re.fullmatch(r'[A-Za-z0-9_-]{1,40}', ident):
        return
    _bump_keys([('shop_%s:%s' % (kind, ident), 1)])


def screen_hit(code):
    """화면 진입 +1. 유효 화면코드만."""
    if not _gate() or code not in _SCREENS:
        return
    _bump_keys([("screen:" + code, 1)])


# ── 전송 ────────────────────────────────────────────────────────────
def _build_payload(c, period, uuid, app_ver, lang, bible_ver):
    rows = c.execute(
        "SELECT metric_key, count FROM usage_counter WHERE period_ym=?", (period,)
    ).fetchall()
    metrics, screens = {}, {}
    for mk, cnt in rows:
        if mk.startswith("screen:"):
            screens[mk[7:]] = cnt
        else:
            metrics[mk] = cnt
    active = c.execute(
        "SELECT COUNT(*) FROM usage_active_day WHERE ymd LIKE ?", (period + "%",)
    ).fetchone()[0]
    if active:
        metrics["active_days"] = active
    # ★ 2026-10-20 — 그 달 이 기기가 PC 였다(관리자 화면이 PC·폰 사용자 수를 가른다 · 서버는 그대로 더한다)
    if metrics or screens or active:
        metrics["dev_pc"] = 1
    if screens:
        metrics["screens"] = screens
    # ★★ **공동체 방 — 「몇 개 공동체가 쓰는가」**(2026-09-08 사용자 지시
    #   「자동승인 해도 **몇개 교회가 쓰는지 통계 필요**하다」).
    #   ★ **새 통로를 안 만든다** — 여기 한 줄이다.
    #   ⚠⚠ **이름·연락처·글은 안 보낸다** — 유형·인원·역할뿐이다. 익명이
    #     깨지면 안 된다(`room_core.metrics_rows` 가 그 문을 지킨다).
    #   ⚠ **한 방을 여러 사람이 보낸다** — 받는 쪽이 `role` 로 가른다.
    #     **방장 것만 세면 방 수**이고 나머지는 참여자 수다.
    #   ⚠ 방이 없으면 **열쇠 자체를 안 넣는다**(§0-1 빈 서랍).
    try:
        import room_core as _RC
        _rooms = _RC.metrics_rows(c)
        if _rooms:
            metrics["rooms"] = _rooms
    except Exception:
        pass
    out = {
        "uuid": uuid,
        "period_ym": period,
        "payload_ver": PAYLOAD_VER,
        "app_ver": app_ver or "",
        "os": platform.system() or "",
        "lang": (lang or "").upper(),
        "bible_ver": bible_ver or "",
        "metrics": metrics,
    }
    out.update(_pack_fields(c))
    return out


# ── 자료 보유 현황 (릴리스·자산 통계) ─────────────────────────────────
#: ★★★ **왜 이것이 필요한가** (2026-09-06 사용자 6-1 「릴리스 한 이후 릴리스
#:   단위 또는 자산 단위로 **다운로드 받은 사용자 통계**를 입수할 수 있도록」).
#:   ⚠⚠ 배포가 **정적 파일**(GitHub raw + jsDelivr)이라 **우리 서버에 받은
#:     기록이 남지 않는다** — 다운로드 로그가 아예 없다.
#:   ⇒ **앱이 「내가 지금 무엇을 갖고 있나」를 알린다**(A안). 그러면
#:     「몇 번 받았나」가 아니라 **「몇 명이 최신인가」**를 알 수 있고,
#:     받았다 지운 것도 저절로 반영된다.
#:
#: ⚠⚠ **재동의를 받지 않는다 — 새 범주가 아니다** (2026-09-06 사용자
#:   「이용통계 화면의 **문구를 수정하면 충분**할 것 같다. 다운로드 통계나
#:   이용통계가 **차이가 큰가**」).
#:   ★ 내가 처음에 「새 범주라 옛 동의로 못 덮는다」고 적었는데 **실측이 그것을
#:     뒤집었다** — 지금 이미 나가는 값이 이렇다:
#:       `bible_ver: "KRV"`            어느 역본을 읽는가
#:       `screens: {p4_terms: 476, …}` 어느 화면을 몇 번 열었는가
#:     「스펄전 설교집 한국어판을 갖고 있다」는 이것과 **같은 결**이다.
#:     익명 번호에 붙은 취향이라는 점에서 층이 같다.
#:   ⇒ **문구로 알리고 그대로 보낸다.** 판은 기록만 남긴다(정말 성격이 다른
#:     것을 넣는 날 이 값이 근거가 된다). **막는 자리로 쓰지 않는다.**
CONSENT_VER = 2          # ← 기록용(자료 보유 현황이 들어간 판). 게이트 아님
CONSENT_VER_KEY = "consent_ver"


def consent_ver():
    """이 사람이 동의한 약관 판. 모르면 1(옛 동의)."""
    try:
        c = _conn()
        try:
            _ensure(c)
            v = _get_state(c, CONSENT_VER_KEY)
            return int(v) if v else 1
        finally:
            c.close()
    except Exception:
        return 1


def _pack_fields(c):
    """`{'pack_release':N, 'assets':{...}}` — 동의 판이 낮으면 **빈 dict**.

    ★ **릴리스와 자산을 함께 낸다** — 사용자가 물은 두 축이다.
      · `pack_release` = 내 코어가 몇 판인가(하나)
      · `assets` = `{"BOOK|SPURGEON_ME|KO": 3, …}` 자산마다 내 판
    ⚠ **판을 모르는 것은 안 넣는다** — 0 으로 채우면 「받았는데 0 판」이라는
      거짓 집계가 된다(§0-1b).
    ⚠ 이름·경로·내용은 한 글자도 안 보낸다 — **열쇠와 판뿐**이다.
    """
    # ⚠⚠ **동의판으로 막지 않는다** (2026-09-06 사용자 「**이용통계 화면의
    #   문구를 수정하면 충분**할 것 같다. 다운로드 통계나 이용통계가 차이가
    #   큰가」 — 실측이 그 판단을 받쳤다).
    #   지금 이미 보내는 것이 `bible_ver`(어느 역본을 읽나) ·
    #   `screens`(어느 화면을 몇 번 열었나)이고, 「받아 둔 자료」는 **같은 결**
    #   이다 — 익명 번호에 붙은 취향이지 새 범주가 아니다.
    #   ⇒ 재동의를 받을 만한 차이가 아니라서 **문구로 알리고 그대로 보낸다.**
    # ⚠ 막아 두었더니 **켜 두고도 이 항목만 조용히 안 나갔다**(실측 동의판 1).
    #   §0-1 조용한 실패의 자리라 그 자체가 고칠 이유였다.
    out = {}
    try:
        import pack_status as PS
        rel = 0
        try:
            rel = int(PS.have().get("cursor") or 0)
        except Exception:
            rel = 0
        if rel:
            out["pack_release"] = rel
        mine = PS.mine_versions()
        if mine:
            out["assets"] = {"%s|%s|%s" % k: v for k, v in mine.items()}
    except Exception:
        return out
    return out


def summary_lines(app_ver="", lang="", bible_ver="", conn=None):
    """**지금 보내는 것**을 사람이 읽을 줄로 낸다. (라벨, 값) 목록.

    ★★ **약관이 약속한 것을 화면이 실제로 보인다** (2026-09-06). 약관은
      「UUID는 [설정 › 개인정보]에서 확인 가능」이라 적어 두었는데 그 화면에
      **UUID 가 없었다**(실측 `_build_privacy` 가 `get_uuid` 를 한 번도 안
      부른다). 없는 것을 있다고 적으면 고지가 거짓이 된다.
    ⚠⚠ **payload 를 두 벌로 적지 않는다** — 실제로 보내는 `_build_payload`
      를 그대로 불러 옮긴다. 손으로 적으면 항목을 늘린 날 화면만 옛말을 한다.
    ⚠ 동의 여부는 여기서 안 본다 — **동의 안 해도 제 식별자는 볼 수 있어야**
      한다(그것이 확인할 권리다). 「지금 보내는가」는 화면이 말한다.
    """
    own = conn is None
    if own:
        conn = _conn()
    try:
        _ensure(conn)
        # ⚠ 환경값(앱 판·언어·역본)은 **앱이 알려 준 것**을 쓴다
        #   (`remember_env`). 이 모듈이 다시 짐작하면 실제로 나간 값과 갈린다.
        p = _build_payload(
            conn, _now_ym(), get_uuid(),
            app_ver or _get_state(conn, "env_app_ver") or "",
            lang or _get_state(conn, "env_lang") or "",
            bible_ver or _get_state(conn, "env_bible") or "")
    except Exception:
        if own:
            try:
                conn.close()
            except Exception:
                pass
        return []
    if own:
        try:
            conn.close()
        except Exception:
            pass
    m = p.get("metrics") or {}
    sc = m.get("screens") or {}
    out = [
        (_t2("SET_PRIV_F_UUID", "익명 식별자"), str(p.get("uuid") or "")),
        (_t2("SET_PRIV_F_ENV", "환경"),
         "%s · %s · %s · %s" % (p.get("lang") or "-", p.get("bible_ver") or "-",
                                p.get("app_ver") or "-", p.get("os") or "-")),
        (_t2("SET_PRIV_F_USE", "이번 달 사용"),
         _t2("SET_PRIV_F_USE_V", "접속 %d회 · 사용한 날 %d일")
         % (int(m.get("sessions") or 0), int(m.get("active_days") or 0))),
        (_t2("SET_PRIV_F_SCREEN", "화면별 사용 횟수"),
         _t2("SET_PRIV_F_N", "%d종") % len(sc)),
    ]
    if "pack_release" in p:
        out.append((_t2("SET_PRIV_F_REL", "연결 자료 판"),
                    "%s" % p.get("pack_release")))
    if "assets" in p:
        out.append((_t2("SET_PRIV_F_ASSET", "받아 둔 자료"),
                    _t2("SET_PRIV_F_N", "%d종") % len(p.get("assets") or {})))
    # ★★ **개인정보 탭이 「지금 보내는 것」을 그대로 말한다**(§204차 ③) —
    #   payload 를 두 벌로 적지 않고 **실제로 나가는 값**을 옮긴다.
    #   ⚠ 방이 없으면 줄을 안 만든다(§0-1 빈 서랍).
    rm = m.get("rooms") or []
    if rm:
        out.append((_t2("SET_PRIV_F_ROOM", "참여한 공동체"),
                    _t2("SET_PRIV_F_ROOM_V", "%d곳 (유형과 인원만 · 이름·연락처·"
                                             "글은 보내지 않습니다)") % len(rm)))
    return out


def _t2(k, d):
    try:
        import i18n
        return i18n.t(k, d)
    except Exception:
        return d


#: 이보다 크면 gzip 으로 보낸다. 작은 것은 압축이 오히려 손해다(헤더가 붙는다).
_GZIP_MIN = 800


def _post(payload):
    """전송. **큰 것은 gzip 으로 보낸다.**

    ★ 왜 (2026-09-06 사용자 물음 「**수만명이 다운로드 해도 통계관리
      가능한가**」): 자료 보유 현황이 들어가면서 한 통이 236B → **4,022B**
      가 됐다(전 자산 169개를 가진 최악). 실측 **gzip 하면 1,110B (−72%)**.
      10만 명이면 한 달 **384MB → 106MB**.
    ⚠ 작은 통은 그냥 보낸다 — gzip 헤더가 붙어 되레 커진다(실측 236B→187B
      로 이득이 작고, 옛 판 사용자는 늘 이 크기다).
    ⚠ 서버가 `Content-Encoding: gzip` 을 못 읽으면 실패한다 —
      **실패하면 다음 실행 때 재시도**하므로 자료를 잃지는 않지만,
      서버 쪽을 먼저 확인하고 켤 것(§0-1 조용한 실패 금지).
    """
    raw = json.dumps(payload).encode("utf-8")
    hdr = {
        "content-type": "application/json",
        "x-app-key": APP_KEY,
        # 기본 'Python-urllib' UA 는 Cloudflare 봇 보호에 403 차단되므로 명시.
        "user-agent": "hagahtorah-app/" + str(PAYLOAD_VER),
    }
    data = raw
    if len(raw) >= _GZIP_MIN:
        try:
            import gzip as _gz
            packed = _gz.compress(raw)
            if len(packed) < len(raw):
                data, hdr["content-encoding"] = packed, "gzip"
        except Exception:
            pass
    req = urllib.request.Request(
        ENDPOINT, data=data, method="POST", headers=hdr,
    )
    with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
        return 200 <= resp.status < 300


#: 월초 몰림을 흩는 날 수 — 기기마다 1~N일째에 보낸다.
#: ★ 실측(§195차 ㉓) 10만 명이 1일에 몰리면 **83 req/s**. 달마다 한 번뿐이라
#:   대역폭은 문제가 아니지만 **한 시각에 몰리는 것**이 문제였다.
_SPREAD_DAYS = 5


def _spread_ok(db_path=None, today=None):
    """지금이 이 기기가 보낼 차례인가 — **월초 몰림 분산**.

    ★★ 2026-09-07 사용자 물음 「서버와의 송신/수신 시간대가 서로 겹치지 않도록
      하는 장치가 **모든 송신/수신 장치에 대해서 일괄적으로 적용**되는가?」
      ⇒ **그때까지는 아니었다.** 트레이(공지·링크 팩)만 `sync_schedule` 을
        타고 이용통계는 **앱을 켜는 즉시** 보냈다. 달마다 한 번이라 잘 안
        보였지만, 직전 달 것을 보내므로 **1일에 앱을 켜는 사람이 전부** 보낸다.
    ★ 같은 씨앗(`sync_schedule.seed`)을 쓴다 — 새 분산 장치를 만들면 두 벌이
      되고, 두 벌은 언젠가 갈린다.
    ⚠ **막지 않고 미룬다** — 못 보낸 달은 다음 실행에서 그대로 간다
      (`period_ym < 이번 달` 조회라 빠지지 않는다). 늦게 보내도 집계는 달
      단위라 값이 같다.
    ⚠ 분산 장치를 못 읽으면 **보낸다** — 못 읽었다고 영영 안 보내면
      「동의했는데 통계가 안 온다」가 된다(§0-1).
    """
    from datetime import date as _date
    d = today or _date.today()
    if d.day > _SPREAD_DAYS:      # 늦게 켠 사람은 그냥 보낸다
        return True
    try:
        import appdb
        import sync_schedule as SS
        c = appdb.connect(db_path or "bible_master.db")
        try:
            off = SS.slot_sec(SS.seed(c)) % _SPREAD_DAYS
        finally:
            c.close()
    except Exception:
        return True
    return d.day >= 1 + off


def _upload_worker(app_ver, lang, bible_ver):
    try:
        if not _spread_ok():
            return
        cur_ym = _now_ym()
        c = _conn()
        try:
            _ensure(c)
            if _get_state(c, "consent") != "1":
                return
            uuid = _get_state(c, "uuid")
            if not uuid:
                return
            last = _get_state(c, "last_upload_ym", "")
            # 직전 달까지의 미전송 period 들 (현재 월은 아직 진행 중 → 제외)
            periods = c.execute(
                "SELECT DISTINCT period_ym FROM usage_counter "
                "WHERE period_ym < ? AND period_ym > ? ORDER BY period_ym",
                (cur_ym, last),
            ).fetchall()
            for (period,) in periods:
                payload = _build_payload(c, period, uuid, app_ver, lang, bible_ver)
                if not _post(payload):
                    return  # 실패 → 다음 실행 때 재시도
                _set_state(c, "last_upload_ym", period)
                # 전송 끝난 과거 데이터 정리
                c.execute("DELETE FROM usage_counter WHERE period_ym=?", (period,))
                c.execute("DELETE FROM usage_active_day WHERE ymd LIKE ?", (period + "%",))
                c.commit()
        finally:
            c.close()
    except Exception:
        pass


def remember_env(app_ver="", lang="", bible_ver=""):
    """앱이 알려 준 환경값(앱 판·언어·역본)을 적어 둔다.

    ★ **보낸 값이 정본이다** — 설정 화면이 이 값을 다시 짐작하면 실제로
      나간 것과 갈릴 수 있다. 그래서 알려 준 쪽이 그대로 남긴다.
    ⚠ **동의 게이트 밖이다** — 동의 안 한 사람도 「지금 보내는 것」 화면에서
      제 값을 볼 수 있어야 한다(안 보낼 뿐이다).
    """
    try:
        c = _conn()
        try:
            _ensure(c)
            _set_state(c, "env_app_ver", app_ver or "")
            _set_state(c, "env_lang", lang or "")
            _set_state(c, "env_bible", bible_ver or "")
            c.commit()
        finally:
            c.close()
    except Exception:
        pass


def start_session(app_ver="", lang="", bible_ver=""):
    """앱 시작 시 호출 — 동의 시 sessions++ & 직전 달 전송(백그라운드)."""
    remember_env(app_ver, lang, bible_ver)
    if not _gate():
        return
    _bump_keys([("sessions", 1)])
    t = threading.Thread(
        target=_upload_worker, args=(app_ver, lang, bible_ver), daemon=True
    )
    t.start()


def flush_current(app_ver="", lang="", bible_ver=""):
    """[테스트/즉시] 현재 월의 누적 집계를 지금 전송(삭제 안 함 — 멱등 덮어쓰기).
    동의 시에만. 백그라운드. 정기 전송은 start_session(직전 달)이 담당."""
    if not is_enabled():
        return

    def _w():
        try:
            ym = _now_ym()
            c = _conn()
            try:
                _ensure(c)
                uuid = _get_state(c, "uuid")
                if not uuid:
                    return
                payload = _build_payload(c, ym, uuid, app_ver, lang, bible_ver)
            finally:
                c.close()
            _post(payload)
        except Exception:
            pass

    threading.Thread(target=_w, daemon=True).start()


def report_consent_choice(agreed, lang="", app_ver=""):
    """동의/거부 '결정'을 **식별자 없이** 1회 익명 전송(백그라운드).
    동의 게이트와 무관하게 호출(거부자도 결정 사실만 익명 집계 — 약관 고지됨).
    최초 동의 다이얼로그에서만 호출(설정 토글 변경 시에는 호출하지 않음 — 동의율 왜곡 방지)."""
    def _w():
        try:
            payload = {
                "choice": "accept" if agreed else "decline",
                "lang": (lang or "").upper(),
                "app_ver": app_ver or "",
            }
            data = json.dumps(payload).encode("utf-8")
            req = urllib.request.Request(
                CONSENT_ENDPOINT, data=data, method="POST",
                headers={
                    "content-type": "application/json",
                    "x-app-key": APP_KEY,
                    "user-agent": "hagahtorah-app/" + str(PAYLOAD_VER),
                },
            )
            urllib.request.urlopen(req, timeout=_TIMEOUT)
        except Exception:
            pass
    threading.Thread(target=_w, daemon=True).start()


def send_withdraw(reason="", lang="", app_ver=""):
    """동의 철회를 식별자 없이 서버에 전송(통계 반영). 동기 호출 → 성공 bool 반환.
    철회 자체(수집 중단)는 set_consent(False)로 이미 즉시 처리됨. 이건 통계 신호 전송용.
    UI는 스레드로 호출해 결과를 표시하길 권장(블로킹 방지)."""
    try:
        payload = {
            "choice": "withdraw",
            "reason": (reason or "")[:500],
            "lang": (lang or "").upper(),
            "app_ver": app_ver or "",
        }
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            CONSENT_ENDPOINT, data=data, method="POST",
            headers={
                "content-type": "application/json",
                "x-app-key": APP_KEY,
                "user-agent": "hagahtorah-app/" + str(PAYLOAD_VER),
            },
        )
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            return 200 <= resp.status < 300
    except Exception:
        return False


def consent_date():
    """최초 동의한 날짜(YYYY-MM-DD). 미동의 시 None."""
    try:
        c = _conn()
        try:
            _ensure(c)
            if _get_state(c, "consent") != "1":
                return None
            return _get_state(c, "consent_first_date") or _get_state(c, "consent_ts")
        finally:
            c.close()
    except Exception:
        return None


def consent_days():
    """동의한 지 며칠째인지(consent_ts 기준). 미동의/오류=None, 동의했으나 날짜없음=0."""
    try:
        import datetime as _dt
        c = _conn()
        try:
            _ensure(c)
            if _get_state(c, "consent") != "1":
                return None
            ts = _get_state(c, "consent_ts")
            if not ts:
                return 0
            d0 = _dt.date.fromisoformat(str(ts)[:10])
            return (_dt.datetime.now(_dt.timezone.utc).date() - d0).days
        finally:
            c.close()
    except Exception:
        return None


def get_uuid():
    """설정 화면에서 본인 UUID 표시용."""
    try:
        c = _conn()
        try:
            _ensure(c)
            return _get_state(c, "uuid")
        finally:
            c.close()
    except Exception:
        return None


# ── 자가 검증 ───────────────────────────────────────────────────────
def _selftest():
    """`python usage_stats.py --selftest`

    ⚠⚠ **실 DB 에 한 글자도 안 쓴다**(§0-5). 상태를 건드리는 항목은
      스냅샷 → 시험 → 원복으로 잰다.
    """
    import sys
    ok = [0]
    fail = []

    def chk(name, cond):
        if cond:
            ok[0] += 1
        else:
            fail.append(name)
        print(("  OK  " if cond else "  FAIL") + " " + name)

    # ① 게이트가 걷혔는가 — 동의판이 낮아도 자료 칸이 나간다
    #    (2026-09-06 사용자 「문구를 수정하면 충분」. 되돌아가면 여기서 잡힌다)
    src = ""
    try:
        import io as _io
        src = _io.open(__file__, encoding="utf-8").read()
    except Exception:
        pass
    needle = "if consent_ver() < " + "CONSENT_VER"
    chk("_pack_fields 가 동의판으로 막지 않는다",
        src.count(needle) == 0)

    # ② payload 를 두 벌로 적지 않는다 — summary_lines 가 _build_payload 를 쓴다
    i = src.find("def summary_lines")
    j = src.find("\ndef ", i + 10)
    chk("summary_lines 가 실제 payload 를 읽는다",
        i > 0 and "_build_payload(" in src[i:j])

    # ③ 환경값을 이 모듈이 짐작하지 않는다
    chk("환경값은 remember_env 가 남긴 것을 쓴다",
        'env_app_ver' in src and 'def remember_env' in src)

    # ④ remember_env 는 동의 게이트 밖이다(동의 안 해도 제 값을 본다)
    i2 = src.find("def remember_env")
    j2 = src.find("\ndef ", i2 + 10)
    chk("remember_env 가 _gate 를 안 본다", "_gate()" not in src[i2:j2])

    # ④-2 등록표 — 폰이 세는 열쇠가 모두 이 표에 있다(관리자 화면이 이름을 못 찾으면 코드가 그대로 뜬다)
    import re as _re
    try:
        dsrc = open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 'mobile', 'lib', 'data', 'usage_repo.dart'), encoding='utf-8').read()
        dkeys = set()
        for blk in _re.findall(r"const kUsage(?:Screens|Counters) = \{(.*?)\};", dsrc, _re.S):
            dkeys |= set(_re.findall(r"'(m_[a-z_]+)'", blk))
        known = {k for k, v in SCREENS.items() if v[0] == 'M'} | {k for k, v in COUNTERS.items() if v[0] == 'M'}
        chk("폰 열쇠가 모두 등록표에 있다 %s" % sorted(dkeys - known), dkeys and not (dkeys - known))
    except OSError:
        pass
    chk("PC 기록 거르개 = 등록표의 PC 줄", _SCREENS == {k for k, v in SCREENS.items() if v[0] == 'PC'})

    # ⑤ 왕복 — 스냅샷 → 바꾸기 → 원복
    keep = None
    try:
        c = _conn()
        try:
            _ensure(c)
            keep = _get_state(c, "env_app_ver")
        finally:
            c.close()
        remember_env("9.9.9-test", "XX", "YY")
        rows = dict(summary_lines())
        env = rows.get(_t2("SET_PRIV_F_ENV", "환경"), "")
        chk("summary_lines 가 알려 준 환경값을 그대로 낸다",
            "9.9.9-test" in env and "XX" in env and "YY" in env)
        uid = rows.get(_t2("SET_PRIV_F_UUID", "익명 식별자"), "")
        chk("익명 식별자 줄 = get_uuid()", uid == (get_uuid() or ""))
    finally:
        try:
            c = _conn()
            try:
                _ensure(c)
                _set_state(c, "env_app_ver", keep or "")
                c.commit()
            finally:
                c.close()
        except Exception:
            pass
    # ⑥ 원복됐는가
    try:
        c = _conn()
        try:
            _ensure(c)
            back = _get_state(c, "env_app_ver")
        finally:
            c.close()
    except Exception:
        back = None
    chk("★ 시험 전 상태로 원복", back == keep)

    # ⑦ 월초 몰림 분산 (2026-09-07 사용자 물음 4)
    from datetime import date as _d
    got = {_spread_ok(today=_d(2026, 9, n)) for n in range(1, _SPREAD_DAYS + 1)}
    chk("★ 월초 며칠은 기기마다 차례가 다르다", got == {True, False} or got == {True})
    chk("★ 늦게 켠 사람은 그냥 보낸다",
        _spread_ok(today=_d(2026, 9, _SPREAD_DAYS + 1)) is True)
    chk("★ 분산 장치를 못 읽으면 보낸다(막지 않는다)",
        _spread_ok(db_path="___없는파일___", today=_d(2026, 9, 1)) is True)
    # 탐지력 — 씨앗이 다르면 차례도 갈린다
    try:
        import sync_schedule as _SS
        offs = {_SS.slot_sec("dev-%d" % i) % _SPREAD_DAYS for i in range(40)}
        chk("★ 기기마다 흩어진다(한 날에 안 몰린다)", len(offs) >= 3)
    except Exception:
        chk("★ 기기마다 흩어진다(한 날에 안 몰린다)", False)

    print("usage_stats selftest %d/%d" % (ok[0], ok[0] + len(fail)))
    if fail:
        print("실패: " + ", ".join(fail))
    sys.exit(0 if not fail else 1)


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        _selftest()
