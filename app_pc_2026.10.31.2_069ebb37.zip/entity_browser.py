"""
entity_browser.py
-----------------
P4 Tab4: 종합 엔티티 브라우저.

레이아웃 (가로 3분할):
  [좌 23%]  유형 필터 + 엔티티 목록
  [중 27%]  엔티티 프로필 + 설명문 + URL + 인물 버튼
  [우 50%]  페리코프 목록 + 구절 내용 (가장 큰 공간)

진입점:
  load_entity(entity_id)  ← P2 탭2 클릭 → 자동 이동
  유형 필터 + 목록 클릭    ← 독립 브라우징
"""

import re
import sqlite3
# ★★ 구간 판정은 **한 문**이다(§verse_range) — `verse_id` 는 신원이고
#   차례는 `sort_order` 다. 번호로 나열하면 절체계 이형 구간에서 샌다.
import verse_range as _vr
import appdb
import verse_text as _vt   # ★ 절 본문은 이 문 하나로(합쳐짐·없는절 보완 §verse_text)
import webbrowser
import tkinter as tk
from tkinter import ttk

try:
    import media_player
    _MP_EMBED_OK = media_player.embed_available()   # Windows + PyQt6 → 인라인 임베드 가능
except Exception:
    media_player = None
    _MP_EMBED_OK = False

import media_list_view as mlv   # 미디어 목록 표준 표시(언어/형태/제목/채널/★)
import media_link               # 영상 연결 단일 소스(통합 표 이름·link_type)
import entity_relation          # 엔티티↔엔티티 연결 단일 소스(인물·우상)
# ⚠ 통합 표에는 인물 관계와 우상 관계가 **함께** 산다 — 갈래를 안 좁히면
#   엘리야로 물었을 때 「엘리야 ↔ 바알」이 인물 관계에 섞여 든다.
_PERS_W, _PERS_A = entity_relation.person_where('pr')
_IDOL_W, _IDOL_A = entity_relation.idol_where('ir')



def _ref_lang():
    """구절약명에 쓸 언어 — **성경 역본**을 따른다(표시언어 콤보가 아니다).

    2026-08-15 사용자 지시: 「구절약명은 버전을 바꿀 때에만 바뀌어야 한다」.
    ⚠ `book_names` 에 EL·HE·COP 가 없어 원문 역본(GNT·WLC·COP*)은 **영어**로 떨어진다.
    """
    try:
        import lang_config
        return lang_config.ref_lang()
    except Exception:
        return 'EN'

def _yt_id(url: str):
    """YouTube URL → video_id — 정본은 `media_link.yt_id` (한 곳만 고친다)."""
    import media_link
    return media_link.yt_id(url)

_TYPE_KO = {
    'PERSON': '인물', 'PLACE': '장소', 'OBJECT': '사물',
    'FEAST':  '절기', 'SYSTEM': '제도', 'GROUP':  '그룹',
    'IDOL':   '우상',
}

# ★ 유형 표의 집은 **`entity_types.py`** 다 (2026-09-22) — 같은 표가 여섯
#   곳에 베껴져 있었고 베낀 것들은 유형이 빠져 있었다. 여기서는 읽기만 한다.
#   ⚠ 옛 이름을 **별칭으로 남긴다** — 이 파일 안에서 널리 쓰인다.
import entity_types as _et
_TYPE_CODES = _et.CODES
_TYPE_LABEL = _et.LABEL
_ALL_LABEL = _et.ALL_LABEL
# 「유형」 머리말 — 2026-08-12 에 콤보가 버튼으로 바뀌면서 쓰지 않는다(버튼 자체가 유형이다).
# 지우지 않는 것은 유형 선택을 다시 콤보로 되돌릴 때 10개 언어를 다시 번역하지 않기 위해서다.
_TYPE_HDR_LABEL = {'KO': '유형', 'EN': 'Type', 'ZH': '类型', 'JA': '種別',
                    'DE': 'Typ', 'FR': 'Type', 'ES': 'Tipo',
                    'AR': 'نوع', 'RU': 'Тип', 'PT': 'Tipo'}

_TYPE_TAG = {
    'PERSON': 'person', 'PLACE': 'place', 'OBJECT': 'object',
    'FEAST':  'feast',  'SYSTEM': 'system', 'GROUP': 'group',
    'NATION': 'nation', 'IDOL': 'idol', 'DOCTRINE': 'doctrine', 'TERM': 'term',
}
_IDOL_REL_KO = {
    'WORSHIPPER': '숭배자',
    'INTRODUCER': '도입자',
    'REFORMER':   '개혁자',
    'OPPONENT':   '대적자',
    'PROPHET':    '경고선지자',
    'VICTIM':     '희생자',
}

# 민족 관계 (2026-09-02 0.txt 1번 — entity_relation.NATION 어휘의 화면 이름)
_NAT_REL_KO = {
    'FOUNDER':      '조상',
    'KING':         '왕',
    'MEMBER':       '그 민족 사람',
    'PROPHET_TO':   '보냄 받은 선지자',
    'COURT':        '궁정에 선 사람',
    'NATIONAL_GOD': '민족의 신',
}
# ★★ **라벨은 짧게 — 축이 의미를 말한다** (2026-09-05 사용자 지시
#   「예언/책망한 이 => 예언책망... 짧게 하면 된다」).
#   ⚠ 겹치는 관계는 `[자녀·원수] 압살롬` 처럼 이어 붙으므로 **한 조각이 길면
#     줄이 통째로 길어진다**(실측 최대 15자 `[예언/책망한 이·일시갈등]`).
#   ★ `redemptive_axis`(언약·전수·대적·회복)가 묶음 머리에서 **의미**를
#     말하므로 여기서는 **종류만** 짧게 적으면 된다. 슬래시로 두 뜻을 억지로
#     붙이지 않는다(`예언/책망한 이` → `예언책망`).
#   ⇒ **네 글자를 넘기지 않는다.**
#  ⚠⚠ **줄이되 「상대가 누구인가」를 잃지 않는다** (2026-09-05 사용자 재지적
#    「물려받음, 물려줌, 말씀받음 ??? 이상하다」). 처음에 `신앙 물려받음` 을
#    `물려받음` 으로만 줄였는데, 그것은 **관계의 이름**이지 상대가 누구인지가
#    아니다 — §190차에 `[부] 요나단` 을 고친 그 병이 이 둘에 남아 있었다.
#    실측 방향은 한쪽뿐이다(ORACLE 10건 전부 **선지자→왕** ·
#    SPIRITUAL_LEGACY 8건 전부 **스승→후계자**) ⇒
#      ORACLE            권면함 / **선지자**
#      SPIRITUAL_LEGACY  **후계자** / **신앙스승**
#    ⚠ `MENTOR`(제자/스승)와 갈라 둔다 — 일반 가르침과 신앙 유산은 다르다.
#: **관계 묶음 머리 이름** (2026-09-07 사용자 지시 — 「**언약관계인물,
#: 대적관계인물** 등으로 표시해야 무슨 말인지 이해한다」).
#: ⚠ `db_person_relation.AXIS_KO`(언약·전수·대적·회복)를 그대로 쓰면 안 된다 —
#:   그것은 **축의 이름**이고 여기 필요한 것은 **「그 축의 관계에 있는 인물」**
#:   이다. 「언약」 한 낱말은 관계의 축인지 그 인물의 속성인지 안 갈린다.
#: ⚠ 「기타」는 2026-09-05 사용자가 지은 이름이라 그 낱말을 지킨다.
_AXIS_GROUP_KEY = {
    'COVENANT':    ('PREL_AXG_COVENANT',    '언약 관계 인물'),
    'MENTORSHIP':  ('PREL_AXG_MENTORSHIP',  '전수 관계 인물'),
    'CONFLICT':    ('PREL_AXG_CONFLICT',    '대적 관계 인물'),
    'RESTORATION': ('PREL_AXG_RESTORATION', '회복 관계 인물'),
    None:          ('PREL_AXG_ETC',         '기타 관계 인물'),
}


def _AXIS_GROUP_NAME(axis):
    k, fb = _AXIS_GROUP_KEY.get(axis or None) or ('', axis or '')
    return i18n.t(k, fb) if k else fb


#: **검색 결과 묶음 이름** (2026-09-07 사용자 확정 ④).
#: ⚠ 2군은 **검색어를 넣어 짓는다** — 「하나님…」·「언약…」. 사용자가 쓴 표기
#:   그대로이고, 조사(을/를)가 안 붙어 11언어에서 안 깨진다.
_SEARCH_GROUP_KEY = {
    1: ('EB_SG_SELF',   '본명 · 별명'),
    2: ('EB_SG_PREFIX', '{q}…'),
    3: ('EB_SG_REL',    '관련된 것'),
}


def _SEARCH_GROUP_NAME(g, q=''):
    k, fb = _SEARCH_GROUP_KEY.get(g) or ('', '')
    s = i18n.t(k, fb) if k else fb
    try:
        return s.replace('{q}', q or '')
    except Exception:
        return s


_REL_TYPE_SHORT_KO = {
    'FATHER': '부', 'MOTHER': '모', 'SPOUSE': '배우자',
    'CHILD': '자녀', 'SIBLING': '형제', 'IN_LAW': '인척',
    'KIN': '친족', 'CONCUBINE': '첩', 'INFORMAL_UNION': '동거',
    'CO_WORKER': '동역자', 'ALLY': '동맹', 'FRIEND': '친구',
    'ENEMY': '원수', 'RIVAL': '경쟁자', 'AUTHORITY': '권위자',
    'STEWARDSHIP': '청지기', 'MENTOR': '스승', 'FOLLOWER': '제자',
    'BETRAYAL': '배신', 'CONFLICT_TEMP': '일시갈등',
    'ORACLE': '예언권면', 'SPIRITUAL_LEGACY': '신앙전수',
    'OCCULT_DECEPTION': '영적타락', 'SACRED_ENCOUNTER': '신성조우',
    'SPIRITUAL_CATALYST': '영적촉매',
}
# ★ **역방향 이름** (2026-09-03 0.txt 2번 사용자 지적 — 「다윗-므비보셋-
#   요나단을 보면 요나단 앞에 [부]… 므비보셋이 요나단의 아버지처럼 보인다」).
#   트리의 라벨은 **「위 노드의 무엇인가」**로 읽혀야 한다. 저장은 한 행
#   (from→to)이므로, 내가 to 쪽이면 뒤집힌 이름을 쓴다.
#   ⚠ 대칭 관계(형제·친구·배우자…)는 뒤집어도 같은 말이라 표에 없다.
#   ⚠⚠ **실측이 표를 뒤집었다** — 저장은 `clicked=아버지 → target=자녀`
#     (FATHER 행: 이새→다윗 · 요나단→므비보셋). 그러므로 **내가 clicked
#     쪽이면 상대는 자녀**이고, target 쪽이면 상대가 부모다. 옛
#     `_REL_TYPE_SHORT_KO` 는 「관계의 이름」이지 「상대가 누구인가」가
#     아니어서 [부] 로 그려졌고, 그것이 사용자가 본 오독의 정체다.
_REL_FWD_KO = {          # 내가 clicked → 상대는?
    'FATHER': '자녀', 'MOTHER': '자녀', 'CHILD': '부모',
    'AUTHORITY': '아랫사람', 'STEWARDSHIP': '주인',
    'MENTOR': '제자', 'FOLLOWER': '스승',
    'BETRAYAL': '배신함', 'ORACLE': '권면함',
    'SPIRITUAL_LEGACY': '후계자',
    'OCCULT_DECEPTION': '유혹당함',
}
_REL_REV_KO = {          # 내가 target → 상대는?
    'FATHER': '아버지', 'MOTHER': '어머니', 'CHILD': '자녀',
    'CONCUBINE': '배우자',
    'AUTHORITY': '권위자', 'STEWARDSHIP': '청지기',
    'MENTOR': '스승', 'FOLLOWER': '제자',
    'BETRAYAL': '배신당함', 'ORACLE': '선지자',
    'SPIRITUAL_LEGACY': '신앙스승',
    'OCCULT_DECEPTION': '유혹함',
}

_MILESTONE_KO = {
    'BIRTH':       '탄생',      'CALL':        '부르심',
    'FORMATION':   '훈련',      'CONFLICT':    '위기/충돌',
    'CRISIS':      '절정 위기', 'ACHIEVEMENT': '성취',
    'TRANSFER':    '사명 이양', 'LEGACY':      '결실/유산',
    'DEATH':       '죽음',
}
_ROLE_KO = {
    'PROTAGONIST': '주인공', 'ANTAGONIST': '대적자',
    'SUPPORTER':   '조력자', 'MENTIONED':  '언급',
    'BACKGROUND':  '배경',
}
import i18n                               # UI 라벨·enum 다국어(ui_strings) — KO는 아래 맵을 폴백으로 유지
import bidi
import verse_ref                               # 오른쪽에서 왼쪽으로 읽는 글 (font.md §8)
_ROLE_PRI_KO = {
    'KING': '왕', 'PROPHET': '선지자', 'PRIEST': '제사장',
    'APOSTLE': '사도', 'JUDGE': '사사', 'PATRIARCH': '족장',
    'DISCIPLE': '제자', 'LAYPERSON': '평신도', 'ANTAGONIST': '대적자',
}
_TIME_KO = {
    'PATRIARCH': '족장 시대', 'EXODUS': '출애굽', 'JUDGES': '사사 시대',
    'KINGDOM': '왕정 시대', 'DIVIDED': '분열 왕국', 'EXILE': '포로기',
    'RETURN': '귀환기', 'GOSPEL': '복음서', 'EARLY_CHURCH': '초대 교회',
}


def _C(role, fallback):
    """역할 색 — 화면에 값을 박지 않는다(§36). 폴백은 이 꼴 안에서만.

    ⚠ 모듈 레벨에서 미리 계산하지 말 것 — import 시점에 굳어 테마를 안 따른다.
    """
    try:
        import ui_theme
        return ui_theme.C(role) or fallback
    except Exception:
        return fallback


def _tfr(w, db, scope='prose', delta=0):
    """읽는 본문에 **구역 글꼴**을 입히고 등록한다 (font.md §36-2).

    ⚠ 이 파일에는 `theme_font` 배선이 **하나도 없었다** — 그래서 사전·설명·구절
      본문이 설정을 따르지 않았다(2026-08-16 사용자 지적). `register` 라야
      설정을 바꿀 때 따라온다(`apply` 만 부르면 만들 때 한 번뿐이다).
    ⚠ `delta` 는 **크기를 박는 것이 아니라 단계**다 — 설정을 바꾸면 그 차이를
      유지한 채 함께 커진다(§36 「크기 위계」).
    """
    try:
        import theme_font
        theme_font.register(w, db, scope, size_delta=delta)
    except Exception:
        pass


class EntityBrowserPanel(ttk.Frame):
    """P4 Tab4 종합 엔티티 브라우저."""

    def __init__(self, parent, db_path, lang_getter=None,
                 on_person_tree=None, on_person_net=None,
                 compact=False, on_close=None, on_verse_jump=None,
                 on_article_open=None, on_sermon_select=None, on_doctrine_select=None,
                 on_user_open=None):
        """
        compact=True: 좌측 엔티티 목록·검색 영역 숨김. 외부에서 load_entity(eid)로
                     직접 진입하는 용도 (예: 가계도 노드 클릭 → 슬라이딩 패널).
                     페리코프 데이터 없는 인물은 우측 영역도 자동 숨김.
        on_close: compact 모드일 때 상단 헤더의 [✕] 버튼 클릭 시 호출.
                  부모(예: GenealogyCanvas)가 PanedWindow.forget 처리.
        """
        super().__init__(parent)
        self.db_path        = db_path
        # ★★★ **표시 언어의 문은 하나다**(2026-09-17 사용자 「모든 탭에서
        #   언어코드가 적용」) — 모서리 콤보가 있으면 그것이, 없으면 앱
        #   환경설정 언어가 답이다. 서브탭들은 이미 `lang_getter()` 를 쓰므로
        #   **여기 한 곳만 바꾸면 전부 따라온다**(자리마다 고치면 하나가 샌다).
        self._app_lang      = lang_getter or (lambda: 'KO')
        self.lang_getter    = self._disp_lang
        self.on_person_tree = on_person_tree   # callback(entity_id) → Tab5 족보
        self.on_person_net  = on_person_net    # callback(entity_id) → Tab6 네트워크
        # ★ compact(가계도 슬라이드)는 이제 **같은 화면의 「닫힘 모드」**다
        #   (2026-09-15 사용자 「오른쪽에서 표시되는 방식으로」 + 「표시 방식을
        #   통일」). 왼쪽 칸을 접고 시작할 뿐 위젯은 전부 있다 — 따로 짓지 않는다.
        self._compact       = False
        self._start_hidden  = bool(compact)
        self._on_close      = on_close
        self._current_strong = None       # 승격 안 된 낱말을 열었을 때의 스트롱 번호
        self._left_mode     = 'SEARCH'    # SEARCH · HIDDEN · LEX
        self._lex_vid       = None
        # ★ 흐름으로 가는 문 — **호스트가 심는다**(늦은 바인딩).
        #   ⚠ 미리 선언해 두어야 `getattr` 가드가 조용히 건너뛰지 않는다
        #     (§99차 `on_open_panel` 과 같은 함정).
        self.on_chain_open  = None
        self.on_verse_jump  = on_verse_jump    # 여정 탭 스토리 '묵상' → P1/P2
        self.on_article_open = on_article_open  # 내부자료(작성자료) 글 → P4 탭10(자료)
        self.on_sermon_select   = on_sermon_select    # 내부연결 설교·도서 → P1
        self.on_doctrine_select = on_doctrine_select  # 내부연결 사전·문답 → P1
        self.on_user_open   = on_user_open      # 내가 쓴 글 ref_id → P4 탭10(자료)

        self._all_entities: list[dict] = []
        self._type_filter:  str | None = None
        # compact 모드(가계도 슬라이드)에는 상단 bar 가 없다 — 아래 위젯들이 안 만들어지므로
        # 쓰는 쪽에서 반드시 None 을 견뎌야 한다.
        self._type_btn_f = None
        self._cnt_lbl = None
        self._q_var = None
        self._crumb_f = None        # 탐색 경로 줄 — 상단 bar 안(compact 에는 없다)
        self._current_eid:  int | None = None
        self._peri_rows:    list[dict] = []
        self._expand_peri_id:   int | None = None
        self._expand_start_vid: int | None = None
        self._expand_end_vid:   int | None = None

        self._tree_expand_eid: int | None = None   # 현재 좌측 트리에서 펼쳐진 최상위 엔티티
        self._breadcrumb: list[int] = []            # 탐색 경로 [root, child, grandchild]

        self._dict_variant_var = tk.StringVar(value='ORIGINAL')
        self._dict_lang_var    = tk.StringVar(value='KO')

        self._build()
        self.after(100, self._load_all_entities)
        if self._start_hidden:
            self.set_left_mode('HIDDEN')

    # ── UI 구성 ──────────────────────────────────────────────────────────────

    def _build(self):
        # ★★★ 머리띠는 **전폭**이다 (2026-09-15) — 왼쪽 칸을 접는 「닫힘 모드」
        #   에서도 이름(탐색 경로)·Focus·[검색창 표시] 가 보여야 한다. 옛 압축판
        #   (가계도)의 「이름 + ✕」 머리도 이 띠가 맡는다(on_close 가 있으면 ✕).
        # ★★★ **머리띠를 걷었다**(2026-09-17 · 1.txt 1-3 사용자 「가장 상단 bar에
        #   용어(왼쪽), 검색창 닫기 버튼(오른쪽)이 배치되어 있다. **제거하라**」 ·
        #   1-4 「**본문 표시공간을 한줄이라도 더 늘려야 한다**」).
        #   ⇒ 이름은 **용어사전 줄의 굵은 글자**가, 토글은 **노트북 모서리**가
        #     맡는다. 띠 32px 가 통째로 본문으로 간다.
        #   ⚠ P4 공통 Focus 는 **이 띠를 안 쓴다**(256차 ⑯ 에서 노트북 탭 줄로
        #     옮겼다 — `_attach_p4_focus` 는 부르는 곳 0). 그래서 걷어도 안 잃는다.
        #   ⚠ **압축판(가계도 슬라이드)에는 ✕ 가 필요하다** — 그때만 띠를 편다.
        self._build_left_bar(self)
        _bar = self._bar
        self._left_toggle_btn = None
        if self._on_close:
            tk.Button(_bar, text='✕', bg=_C('panel_alt', '#E8EAF6'), bd=0,
                      font=('', 11, 'bold'), cursor='hand2',
                      command=self._handle_close).pack(side='right', padx=6)
        else:
            _bar.pack_forget()

        # ★★ 전폭 상단 bar 폐지 (2026-09-02 사용자 지시 ③ — 「용어사전~여정
        #   서브탭을 한 칸 위로」). 머리띠(이름·P4 Focus)는 **왼쪽 기둥 위**로
        #   내려가고, 노트북이 패널 맨 위부터 시작한다. My Edit·ⓜ 는 노트북
        #   오른쪽 위 모서리(place — 탭 줄 오른쪽은 빈 자리다).
        #   ⚠ P4 공통 Focus 는 `_p4_focus_bar` 속성으로 잇는다 —
        #     user_main._p4_tab_bar 가 「첫 자식의 첫 자식」 규칙으로 찾는데
        #     이제 첫 자식이 PanedWindow 라 그 규칙으로는 못 찾는다.
        h_pw = tk.PanedWindow(self, orient='horizontal',
                               sashwidth=5, bg=_C('border', '#BDC3C7'), sashrelief='flat')
        h_pw.pack(fill='both', expand=True)

        # ★ 왼쪽 칸 = 내용물이 둘인 한 칸 (2026-09-15 3모드)
        #   검색 층(검색창·유형·목록) / 원어 층(이 절의 낱말 목록). 모드가 둘 중
        #   하나를 보이거나 칸째 접는다(`set_left_mode`).
        left_f = tk.Frame(h_pw, bg=_C('panel', '#F2F3F4'))
        self._left_f = left_f
        h_pw.add(left_f, width=250)
        self._search_stack = tk.Frame(left_f, bg=_C('panel', '#F2F3F4'))
        self._search_stack.pack(fill='both', expand=True)
        self._build_left(self._search_stack)
        self._lex_stack = tk.Frame(left_f, bg=_C('panel', '#F2F3F4'))
        self._build_lex_stack(self._lex_stack)

        # [2026-06-04 리팩토링] 우측 페리코프 영역 → Notebook 서브탭4로 통합.
        # 좌측 목록 + 중앙 Notebook 만 남음.
        center_f = tk.Frame(h_pw, bg=_C('panel', 'white'))
        self._center_f = center_f
        h_pw.add(center_f, width=420)
        self._build_center(center_f)

        # 구 호환 (외부 호출 가드)
        self._h_pw = h_pw
        self._right_f = None
        self._right_visible = False

    # ── 좌측: 유형 필터 + 엔티티 목록 ──────────────────────────────────────────

    # 유형 버튼 고정폭(px). 10개 언어를 실제 폰트로 재서 정했다 —
    # 가장 긴 러시아어 «Доктрина» 가 64px 이라 70 이면 어느 언어도 잘리지 않고,
    # 11개를 늘어놓아도 770px 이라 한 줄에 들어간다(2026-08-12 실측).
    # ⚠ tk.Button(width=N) 은 **픽셀이 아니라 글자 수**다 — 폰트마다 어긋나므로
    #   Frame + pack_propagate(False) 로 픽셀을 못 박는다.
    _TYPE_BTN_W = 76      # 개수 () 가 들어가 70 → 76 (2026-09-01)

    # ── 왼쪽 칸 3모드 (2026-09-15 `1.txt` 3번 (4) 사용자 설계) ─────────────
    #   검색 = 탭을 직접 눌렀을 때 · 닫힘 = P1 라벨로 들어왔을 때 ·
    #   원어 = P1 [Lexicon] 으로 들어왔을 때. 세 길이 다르고 **오른쪽은 같다**.
    #   직전 모드를 기억하지 않는다 — 들어온 길이 정한다.

    def set_left_mode(self, mode):
        mode = (mode or 'SEARCH').upper()
        if mode not in ('SEARCH', 'HIDDEN', 'LEX'):
            mode = 'SEARCH'
        self._left_mode = mode
        pw, lf = getattr(self, '_h_pw', None), getattr(self, '_left_f', None)
        if pw is None or lf is None:
            return
        # ⚠ `panes()` 는 Tcl 객체 튜플이라 문자열로 바꿔 견준다(실측으로 잡았다)
        shown = str(lf) in [str(x) for x in pw.panes()]
        try:
            if mode == 'HIDDEN':
                if shown:
                    pw.forget(lf)
            else:
                if not shown:
                    pw.add(lf, before=self._center_f, width=250)
                if mode == 'LEX':
                    self._search_stack.pack_forget()
                    if not self._lex_stack.winfo_manager():
                        self._lex_stack.pack(fill='both', expand=True)
                else:
                    self._lex_stack.pack_forget()
                    if not self._search_stack.winfo_manager():
                        self._search_stack.pack(fill='both', expand=True)
        except Exception as e:
            print('[EntityBrowser] left mode: %s' % e)
        try:
            self._left_toggle_btn.config(text=i18n.t(
                'EB_SEARCH_HIDE' if mode == 'SEARCH' else 'EB_SEARCH_SHOW',
                '검색창 닫기' if mode == 'SEARCH' else '검색창 표시'))
            # ⚠ 글자 폭이 바뀌면 **칸 폭과 탭 시작점**도 다시 잰다(안 하면
            #   좁은 쪽 글자가 잘리거나 넓은 쪽에 빈자리가 남는다)
            _st = getattr(self, '_left_strip', None)
            if _st is not None:
                _st.after_idle(_st.fit)
        except Exception:
            pass
        self._count_changed()

    def left_mode(self):
        return self._left_mode

    on_count = None      # 낱말 목록이 바뀌면 — P4 탭 배지가 다시 센다(80-2)

    def badge_count(self):
        """탭 배지 = 왼쪽 낱말 목록 수(그 절). 원어 모드가 아니면 None."""
        if self._left_mode != 'LEX' or not getattr(self, '_lex_vid', None):
            return None
        return len(getattr(self, '_lex_rows', {}) or {})

    def _count_changed(self):
        if callable(self.on_count):
            try:
                self.on_count()
            except Exception:
                pass

    def _toggle_left(self):
        """[검색창 닫기/표시] — 검색이 보이면 접고, 아니면 검색을 편다."""
        self.set_left_mode('HIDDEN' if self._left_mode == 'SEARCH' else 'SEARCH')

    def _build_lex_stack(self, parent):
        """원어 층 — 이 절의 낱말 목록(원어·음역·절 수·용어). P2 원어 갈래의
        위 목록과 같은 재료(`db_lex_link`)이고 뜻 칸은 뺐다(사용자 지시).
        승격된 낱말은 「용어」 칸에 그 이름이 있고, 누르면 라벨을 누른 것과 같다."""
        self._lex_head = tk.Label(parent, text='', anchor='w',
                                  bg=_C('panel', '#F2F3F4'),
                                  fg=_C('accent', '#1A5276'), font=('', 9, 'bold'))
        self._lex_head.pack(fill='x', padx=6, pady=(4, 2))
        f = tk.Frame(parent, bg=_C('panel', '#F2F3F4'))
        f.pack(fill='both', expand=True, padx=2, pady=(0, 2))
        vsb = ttk.Scrollbar(f, orient='vertical')
        vsb.pack(side='right', fill='y')
        tv = ttk.Treeview(f, columns=('form', 'tr', 'n', 'term'),
                          show='headings', selectmode='browse',
                          yscrollcommand=vsb.set)
        vsb.config(command=tv.yview)
        tv.pack(fill='both', expand=True)
        # 왼쪽 칸 250px 에 네 칸 — 실측으로 폭을 맞췄다(용어 칸이 늘어난다)
        for c, w, a, key, d in (('form', 64, 'center', 'LEX_COL_FORM', '원어'),
                                ('tr', 72, 'w', 'LEX_COL_TR', '음역'),
                                ('n', 34, 'e', 'LEX_COL_N', '절'),
                                ('term', 56, 'w', 'EB_COL_TERM', '용어')):
            tv.heading(c, text=i18n.t(key, d))
            tv.column(c, width=w, anchor=a, stretch=(c == 'term'), minwidth=36)
        import theme_font as _tf
        _tf.list_style('EBLex.Treeview', self.db_path, heading=True, indent=0)
        tv.configure(style='EBLex.Treeview')
        tv.bind('<<TreeviewSelect>>', self._on_lex_pick)
        self._lex_tv = tv
        self._lex_rows = {}          # iid → (strong, entity_id or None, translit)

    def show_lexicon(self, vid):
        """P1 [Lexicon] — 그 절의 낱말 목록을 왼쪽에 펴고 첫 낱말을 연다."""
        self.set_left_mode('LEX')
        self._lex_vid = vid
        tv = self._lex_tv
        tv.delete(*tv.get_children())
        self._lex_rows = {}
        if not vid:
            self._lex_head.config(text='')
            return
        try:
            import db_lex_link as LL
            with appdb.connect(self.db_path) as conn:
                sts = LL.lemmas_of(conn, vid)
                lang = (self.lang_getter() or 'KO').upper()
                r = conn.execute(
                    "SELECT bn.short_name, bi.chapter, bi.verse FROM bible_index bi"
                    " LEFT JOIN book_names bn ON bn.book_code=bi.bcode AND bn.lang_code=?"
                    " WHERE bi.verse_id=?", (lang, vid)).fetchone()
                ref = self._mk_ref(r[0] or '', r[1], r[2]) if r else str(vid)
                n = 0
                for st in sts:
                    info = LL.word_info(conn, st)
                    if not info:
                        continue
                    # 승격된 낱말인가 — **사람 용어**가 앵커로 가진 스트롱.
                    #   ⚠⚠ 기계 낱말(W_ · `subtype LEX` 10,892개 — §195차 「엘」 사건
                    #     때 전수 등록된 것)은 엔티티이지만 **승격이 아니다**(254차
                    #     「승격 안 된 원어 10,892」가 바로 이것). 실측 앵커 스트롱
                    #     11,068 중 사람 용어의 것은 **227**뿐이다. 그것으로 열면
                    #     이름도 설명도 없는 회색 화면이 뜬다 — 낱말 화면으로 연다.
                    e = conn.execute(
                        "SELECT l.entity_id FROM sys_entity_lemma l"
                        " JOIN sys_entity_master m ON m.entity_id=l.entity_id"
                        " WHERE l.strong=? AND COALESCE(l.record_status,'LIVE')='LIVE'"
                        "   AND m.record_status='LIVE'"
                        "   AND COALESCE(m.json_detail,'') NOT LIKE '%\"subtype\": \"LEX\"%'"
                        " ORDER BY l.lemma_id LIMIT 1",
                        (st,)).fetchone()
                    eid = e[0] if e else None
                    # ⚠ 이름은 **지금 DB 에서** 읽는다 — `_all_entities` 는 탭을 연 뒤
                    #   한 번 채운 것이라 방금 승격한 용어의 한국어 이름을 모른다
                    #   (실측 — 승격 직후 영어 기계 이름이 떴다).
                    term = ''
                    if eid:
                        nm = conn.execute(
                            "SELECT contents FROM sys_text_asset WHERE clicked_id=?"
                            " AND text_type='ENTITY_NAME' AND record_status='LIVE'"
                            " AND lang_code IN (?, 'EN', 'KO')"
                            " ORDER BY CASE lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1"
                            " ELSE 2 END LIMIT 1", (eid, lang, lang)).fetchone()
                        term = (nm[0] if nm and nm[0] else '') or self._get_entity_name(eid)
                    iid = tv.insert('', 'end', values=(
                        info['form'], info['translit'], info['n_verse'], term))
                    self._lex_rows[iid] = (st, eid, info['translit'])
                    n += 1
            self._lex_head.config(text=i18n.t('EB_LEX_HEAD', '{ref}의 낱말 {n}개')
                                  .format(ref=ref, n=n))
        except Exception as e:
            print('[EntityBrowser] show_lexicon: %s' % e)
        first = next(iter(self._lex_rows), None)
        if first:
            try:
                tv.selection_set(first)
                tv.see(first)
            except Exception:
                pass
        self._count_changed()

    def _on_lex_pick(self, _e=None):
        sel = self._lex_tv.selection()
        if not sel or sel[0] not in self._lex_rows:
            return
        st, eid, tr = self._lex_rows[sel[0]]
        if eid:
            self.load_entity(eid, from_vid=self._lex_vid)
        else:
            self.load_lemma(st, from_vid=self._lex_vid, translit=tr)

    def load_lemma(self, strong, from_vid=None, translit=''):
        """승격 안 된 낱말을 오른쪽에 연다 — 용어와 **같은 화면**(2026-09-15).

        차이는 설명 탭 하나뿐이다: 용어설명이 없으니 「사전 모음」이 첫 화면이고
        머리에 그 사실을 한 줄 적는다. 나머지 탭은 재료가 있으면 열리고 없으면
        잠긴다(용어와 같은 규칙 — 「낱말이라서」 잠그지 않는다)."""
        self._current_strong = strong
        self._current_eid = None
        self._from_vid = from_vid
        self._lex_translit = translit or ''
        self._breadcrumb = []
        try:
            import db_lex_link as LL
            with appdb.connect(self.db_path) as conn:
                info = LL.word_info(conn, strong) or {}
        except Exception:
            info = {}
        self._lex_info = info
        self._update_breadcrumb()
        # 메타 — 원어 · 뜻 · 절 수 (용어의 「원어: H835(아쉐르)」 줄과 같은 자리)
        meta = ['%s: %s(%s)' % (i18n.t('ENTITY_ATTR_STRONG', '원어'), strong,
                                info.get('translit') or translit or '')]
        if info.get('gloss'):
            meta.append('%s: %s' % (i18n.t('LEX_COL_GLOSS', '뜻'), info['gloss']))
        if info.get('n_verse'):
            meta.append('%s: %d' % (i18n.t('LEX_COL_N', '절'), info['n_verse']))
        self._meta_lbl.config(text='  |  '.join(meta))   # 자리는 늘 있다(④)
        # ★ 2026-10-14 — 내가 붙인 원어 설명(폰·PC AI 결과를 담은 것)이 있으면 설명 칸에
        mine = ''
        try:
            import user_ai as _UA
            with appdb.connect(self.db_path) as conn:
                mine = _UA.lemma_note(conn, strong, self._app_lang())
        except Exception:
            mine = ''
        self._desc_body = ('[%s]%s%s' % (i18n.t('EB_MY_LEMMA', '내 원어 설명'), chr(10), mine)) if mine.strip() else ''
        self._fill(self._desc_txt, self._desc_body)
        self._hide_cmp()
        self._person_btn_f.pack_forget()
        # 재료 유무로만 여닫는 탭들 — 없는 번호(-1)로 물으면 0건이라 저절로 잠긴다
        self._load_songs(-1)
        self._load_media_urls(-1)
        self._load_entity_refs(-1)
        self._load_dict_entries(None)
        self._load_external_sites(None)
        self._load_strong_sites(None, anchors=[(strong, translit or '')])
        self._load_linked(None)
        self._load_study_entries(-1)
        self._gate_subtabs_for_type('TERM')
        # ★★ **손으로 잠그지 않는다**(2026-09-17) — 낱말에는 걸 자리가 없어
        #   위 네 문이 이미 0건을 내고, **0건 규칙 하나**(`_apply_tab_prefs`)가
        #   다섯 갈래에 똑같이 걸린다. 여기서 또 잠그면 규칙이 둘이 된다.

    def _build_left_bar(self, parent):
        """왼쪽 기둥 머리띠 — [P4 Focus/Restore] + 이름(탐색 경로).

        ★ 2026-09-02 사용자 지시 ③ — 전폭 bar 를 걷어 서브탭이 한 칸 올라갔다.
          P4 공통 Focus 는 `_p4_focus_bar` 속성이 이 띠를 가리켜 여기 심긴다.
          My Edit·ⓜ 는 노트북 모서리로(_build_center)."""
        import ui_theme
        bar = tk.Frame(parent, bg=_C('panel_alt', '#E8EAF6'))
        ui_theme.bar_height(bar)        # P4 서브탭 공통 높이(32px)
        bar.pack(side='top', fill='x')
        self._bar = bar
        self._p4_focus_bar = bar        # ← user_main._p4_tab_bar 가 본다
        self._crumb_f = tk.Frame(bar, bg=_C('panel_alt', '#E8EAF6'))
        self._crumb_f.pack(side='left', padx=(6, 0))

        self._q_var = tk.StringVar()
        self._type_btns = {}
        self._type_options: list[tuple[str, str | None]] = []
        # 개수 라벨 폐지 (0.txt 6번) — 개수는 유형 단추 안의 () 가 말한다.
        self._cnt_lbl = None

    # ══════════════════════════════════════════════════════════════
    #  [E] — 내 수정 (설명 고쳐 쓰기 · 별명 더하기 · 용어 가리기)
    # ══════════════════════════════════════════════════════════════
    #  [E] — 용어사전 덮개 **종합 화면** (2026-08-26 사용자 확정)
    #
    #  「E 버튼: 용어사전에 관한 사용자 덮개 모델의 종합화면으로 만들어라.
    #   별명 / 설명문 / 영상링크 / 텍스트링크 / 연구자료 / 연결구절 관리기능을
    #   포괄하라. 유형분류 수정기능도 추가하라. 탭 화면으로 만들어라.
    #   상단에 큼직하게 용어 이름을 표시해라. 무엇이 기준인지 명확해야 한다.」
    #
    #  ★ 권한(사용자 확정) — 설명·연결구절·링크·연구자료·별명·유형 = 고칠 수 있다 /
    #    **이름은 못 고친다(별명으로)** / 사전·여정 = 손댈 수 없다.
    #  ⚠ **배포 DB 를 한 글자도 안 건드린다** — 전부 userdb 쪽 덮개 표로 간다.
    # ══════════════════════════════════════════════════════════════
    def _open_my_entity(self):
        from tkinter import messagebox
        eid = getattr(self, '_current_eid', None)
        if not eid:
            messagebox.showinfo(i18n.t('EB_OV_E_T', '내 수정'),
                                i18n.t('EB_OV_PICK', '먼저 용어를 선택하세요.'),
                                parent=self)
            return
        # ★ 3단계 — **패키지 주방**으로 (2026-08-28). 옛 MY 창(_MyWin)은
        #   몸통(MyBody)을 주방이 심으므로 화면이 그대로 살아 있다.
        import my_edit
        return my_edit.open(self, 'ENTITY', int(eid))

    def _hide_current(self):
        """지금 엔티티를 덮개로 가린다 — 목록·태그·티커에서 함께 사라진다."""
        from tkinter import messagebox
        eid = getattr(self, '_current_eid', None)
        if not eid:
            messagebox.showinfo(i18n.t('EB_OV_HIDE', '숨기기'),
                                i18n.t('EB_OV_PICK', '먼저 용어를 선택하세요.'),
                                parent=self)
            return
        try:
            with appdb.connect(self.db_path) as conn:
                r = conn.execute('SELECT entity_code, entity_type '
                                 'FROM sys_entity_master WHERE entity_id=?',
                                 (eid,)).fetchone()
                if not r:
                    return
                nm = next((e['name'] for e in
                           getattr(self, '_all_entities', [])
                           if e['entity_id'] == eid), r[0])
                if not messagebox.askyesno(
                        i18n.t('EB_OV_HIDE', '숨기기'),
                        i18n.t('EB_OV_HIDE_Q',
                               '「{name}」을(를) 내 화면에서 가립니다. 기본 '
                               '자산은 바뀌지 않고, 설정 ▸ 휴지통에서 언제든 '
                               '해제할 수 있습니다. 계속할까요?'
                               ).format(name=nm), parent=self):
                    return
                import overlay
                overlay.hide(conn, overlay.EntityOverlay(),
                             {'entity_code': r[0], 'entity_type': r[1]})
        except Exception as e:
            print('[entity hide]', e)
            return
        self._load_all_entities()            # 목록에서 즉시 사라진다

    def _type_counts(self):
        """유형별 개수 — 단추 안 () 표기용 (2026-09-01 0.txt 6번).

        조회는 `overlay_read.entity_type_counts` 한 문 — 가림 덮개까지 빼서
        목록과 개수가 같은 것을 센다(2026-09-02 검사기 검거로 이관)."""
        try:
            import overlay_read as _or
            with appdb.connect(self.db_path) as conn:
                return _or.entity_type_counts(conn)
        except Exception:
            return {None: 0}

    def _rebuild_type_buttons(self):
        """언어가 바뀌면 라벨이 바뀌므로 다시 만든다.

        ★ 2026-09-01 (0.txt 6번 사용자 지시) —
          · [전체]가 맨 앞(용어사전 서브탭 바로 위) · **인물이 맨 오른쪽**
          · 개수를 단추 **안에 () 로**(별도 숫자 라벨 폐지)
          · 서식 = Recent 형식(flat_btn) · 크기는 종전(픽셀 고정 holder)"""
        if getattr(self, '_type_btn_f', None) is None:
            return
        for w in self._type_btn_f.winfo_children():
            w.destroy()      # 콤보는 제 줄(_type_cmb_f)로 이사했다 (2026-09-02)
        self._type_btns = {}
        lang = self.lang_getter()
        lbl_map = _TYPE_LABEL.get(lang, _TYPE_LABEL['EN'])
        all_lbl = _ALL_LABEL.get(lang, _ALL_LABEL['EN'])
        # ★ 차례 = 사용자 확정 (2026-09-02 0.txt 2번) —
        #   전체 / 용어 교리 제도 절기 사물 / 그룹 민족 우상 인물 / 장소.
        #   새 유형이 생기면 뒤에 붙는다(빠뜨리지 않게).
        _ORDER = ('TERM', 'DOCTRINE', 'SYSTEM', 'FEAST', 'OBJECT',
                  'GROUP', 'NATION', 'IDOL', 'PERSON', 'PLACE')
        _codes = ([tc for tc in _ORDER if tc in _TYPE_CODES]
                  + [tc for tc in _TYPE_CODES if tc not in _ORDER])
        self._type_options = ([(all_lbl, None)]
                              + [(lbl_map.get(tc, tc), tc) for tc in _codes])
        cnt = self._type_counts()
        import ui_theme as _uit
        _fb = _uit.flat_btn(font=('', 8))
        # ★ 3열 그리드 (2026-09-02 ③ — 왼쪽 기둥 폭 250px 에 11개를 담는다)
        for idx2, (label, code) in enumerate(self._type_options):
            holder = tk.Frame(self._type_btn_f, width=self._TYPE_BTN_W,
                              height=24, bg=_C('panel', 'white'))
            holder.grid(row=idx2 // 3, column=idx2 % 3, padx=1, pady=1)
            holder.pack_propagate(False)          # 픽셀 고정 (위 주석)
            b = tk.Button(holder, text='%s (%d)' % (label, cnt.get(code, 0)),
                          command=lambda c=code: self._on_type_button(c), **_fb)
            b.pack(fill='both', expand=True)
            self._type_btns[code] = b
        self._paint_type_buttons()

    def _paint_type_buttons(self):
        """선택한 유형만 도드라지게. **색은 테마에서 가져온다** (2026-08-13).

        ⚠ 예전에는 `#3F51B5`/`#F5F6FA` 를 박아 두고 클릭할 때마다 다시 칠했다.
          어두운 테마에서 **누르는 순간 안 고른 버튼이 흰색으로 되돌아왔다** —
          `ui_theme.paint` 의 재칠보다 이 함수가 늦게 도는 경우가 있었기 때문이다.
          ⇒ 타이밍에 기대지 않고 **여기서 바로 테마 색을 쓴다.**
        """
        try:
            import ui_theme
            on_bg, on_fg = ui_theme.C('accent'), ui_theme.C('fg_on_dark')
            off_bg, off_fg = ui_theme.C('panel_alt'), ui_theme.C('fg')
        except Exception:
            on_bg, on_fg, off_bg, off_fg=_C('accent', '#3F51B5'), 'white', '#F5F6FA', '#2C3E50'
        for code, b in self._type_btns.items():
            on = (code == self._type_filter)
            # flat_btn(Recent 서식) — 눌림은 색이 말한다 (2026-09-01)
            b.config(bg=on_bg if on else off_bg,
                     fg=on_fg if on else off_fg)

    def _sync_era_combo(self):
        """콤보는 유형이 정한다 — 인물=시대 · 장소=지역 · 그 밖=없음
        (2026-09-02 0.txt 8번 「장소 버튼 눌렀을 때만, 인물과 동일한 자리」).
        유형을 떠나면 값도 되돌린다(낡은 거르기가 남지 않게)."""
        for cmb, want in ((getattr(self, '_era_cmb', None),
                           self._type_filter == 'PERSON'),
                          (getattr(self, '_region_cmb', None),
                           self._type_filter == 'PLACE'),
                          (getattr(self, '_axis_cmb', None),
                           self._type_filter == 'TERM')):
            if cmb is None:
                continue
            try:
                if want:
                    if not cmb.winfo_ismapped():
                        cmb.pack(side='left', padx=(4, 4), pady=3)
                else:
                    if cmb.winfo_ismapped():
                        cmb.pack_forget()
                    cmb.current(0)
            except Exception as e:
                print('[EntityBrowser] combo sync: %s' % e)

    def _era_filter_code(self):
        try:
            i = self._era_cmb.current()
            return self._era_codes[i] if i >= 0 else ''
        except Exception:
            return ''

    def _axis_filter_code(self):
        try:
            i = self._axis_cmb.current()
            return self._axis_codes[i] if i >= 0 else ''
        except Exception:
            return ''

    def _region_filter_code(self):
        try:
            i = self._region_cmb.current()
            return self._region_codes[i] if i >= 0 else ''
        except Exception:
            return ''

    def _on_type_button(self, code):
        self._type_filter = code
        self._paint_type_buttons()
        self._sync_era_combo()
        self._populate_list()

    def _on_search(self):
        self._populate_list()

    def _clear_search(self):
        """✕ — 검색어를 비우고 전체로 돌아간다 (2026-08-21 사용자 지시)."""
        if self._q_var is not None:
            self._q_var.set('')
        self._populate_list()

    def _alias_hit(self, eid, q, lang):
        """별명에 걸리나. json_detail 을 매번 읽지 않도록 한 번만 모아 둔다."""
        cache = getattr(self, '_alias_cache', None)
        if cache is None:
            cache = {}
            try:
                from entity_aliases import aliases_for_lang
                with appdb.connect(self.db_path) as conn:
                    code_of = {}
                    for _id, _jd, _code in conn.execute(
                            "SELECT entity_id, json_detail, entity_code "
                            "FROM sys_entity_master "
                            "WHERE COALESCE(record_status,'LIVE')='LIVE'"):
                        code_of[_code] = _id
                        al = aliases_for_lang(_jd, lang)
                        if al:
                            cache[_id] = [a.lower() for a in al]
                    # ★ **내가 더한 별명도 걸린다** (2026-08-26) — 별명을 넣어
                    #   두고 그것으로 못 찾으면 넣은 뜻이 없다.
                    import overlay as _ov
                    for _code, _al in _ov.entity_aliases_user(conn, lang).items():
                        _id = code_of.get(_code)
                        if _id is not None and _al:
                            cache.setdefault(_id, [])
                            cache[_id] += [a.lower() for a in _al]
                    # ★ **낱말(원어 앵커) 층도 검색에 건다** (2026-09-02
                    #   사용자 지적 — 「하마르티아 … 검색 자체가 안 된다」).
                    #   음역은 부분일치, 스트롱 번호는 **정확 일치만**(부분이면
                    #   G93 이 G932 까지 잡는다 — 실측).
                    import overlay_read as _or_af
                    st_cache = {}
                    _mtr = {}
                    try:
                        _mtr = dict(conn.execute(
                            "SELECT strong, COALESCE(translit,'')"
                            " FROM sys_lemma_master"))
                    except Exception:
                        pass
                    for _id, _tr, _st in conn.execute(
                            "SELECT entity_id, COALESCE(translit,''),"
                            " COALESCE(strong,'') FROM sys_entity_lemma"):
                        if _tr:
                            cache.setdefault(_id, [])
                            cache[_id].append(_tr.lower())
                            # 부호 벗긴 꼴 — shâphaṭ 를 shaphat 로도 찾는다
                            _a = _or_af.ascii_fold(_tr)
                            if _a and _a != _tr.lower():
                                cache[_id].append(_a)
                        # 마스터 라틴 음역 — 정성 용어(한글 음역)도 라틴으로
                        _m = _mtr.get(_st, '')
                        if _m and _m != _tr:
                            cache.setdefault(_id, [])
                            cache[_id].append(_m.lower())
                            _a2 = _or_af.ascii_fold(_m)
                            if _a2:
                                cache[_id].append(_a2)
                        if _st:
                            st_cache.setdefault(_id, set()).add(_st.lower())
                    self._strong_cache = st_cache
            except Exception:
                pass
            self._alias_cache = cache
        ql = q.lower()
        return any(ql in a for a in cache.get(eid, ())) or \
            ql in getattr(self, '_strong_cache', {}).get(eid, ())

    def _build_left(self, parent):
        # ★ 탐색창 = 목록의 상단 (2026-09-01 0.txt 6번 사용자 지시 — 「용어표시
        #   라벨 아래(목록의 상단)에 배치」). 이름과 **별명**을 함께 뒤진다(§12-5).
        srow = tk.Frame(parent, bg=_C('panel', '#F2F3F4'))
        srow.pack(side='top', fill='x', padx=2, pady=(2, 0))
        # ★ 2026-10-07 (docs/1.txt 51-4(6)) — [입력창][검색][X] 는 세 화면(주요용어·연구노트·
        #   온라인영상) 공통 부품이다. 비우면 곧바로 전체로 돌아온다(그 부품이 한다).
        import search_row
        search_row.build(srow, self._q_var, self._on_search, self._clear_search,
                         db_path=self.db_path)

        # ★★ 유형존 = **검색창과 목록 사이** (2026-09-02 사용자 지시 ③ —
        #   「검색창과 목록 화면의 가운데에 11~12개의 버튼과 콤보상자 표시공간을
        #   할당하라」). 버튼은 3열 그리드, 그 아래 시대/지역 콤보 줄(고정
        #   높이 — 있고 없고에 목록이 오르내리지 않게).
        self._type_btn_f = tk.Frame(parent, bg=_C('panel', '#F2F3F4'))
        self._type_btn_f.pack(side='top', fill='x', padx=2, pady=(2, 0))
        self._type_cmb_f = tk.Frame(parent, bg=_C('panel', '#F2F3F4'), height=28)
        self._type_cmb_f.pack(side='top', fill='x', padx=2)
        self._type_cmb_f.pack_propagate(False)
        self._era_var = tk.StringVar(value='')
        self._era_codes = ['']
        self._era_cmb = ttk.Combobox(self._type_cmb_f, textvariable=self._era_var,
                                     state='readonly', width=12, font=('', 9))
        try:
            import db_era_code as _EC
            with appdb.connect(self.db_path) as _c:
                _pairs = _EC.eras(_c, (self.lang_getter() or 'KO'))
            self._era_codes = [''] + [c for c, _n in _pairs]
            self._era_cmb['values'] = ([i18n.t('EB_ERA_ALL', '시대 전체')]
                                       + [n for _c2, n in _pairs])
            self._era_cmb.current(0)
        except Exception as _e:
            print('[EntityBrowser] era combo: %s' % _e)
        self._era_cmb.bind('<<ComboboxSelected>>',
                           lambda e: self._populate_list())
        self._region_var = tk.StringVar(value='')
        self._region_codes = ['']
        self._region_cmb = ttk.Combobox(self._type_cmb_f,
                                        textvariable=self._region_var,
                                        state='readonly', width=12, font=('', 9))
        try:
            import db_region_code as _RC
            with appdb.connect(self.db_path) as _c:
                _rpairs = _RC.regions(_c, (self.lang_getter() or 'KO'))
            self._region_codes = [''] + [c for c, _n in _rpairs]
            self._region_cmb['values'] = ([i18n.t('EB_REGION_ALL', '지역 전체')]
                                          + [n for _c2, n in _rpairs])
            self._region_cmb.current(0)
        except Exception as _e:
            print('[EntityBrowser] region combo: %s' % _e)
        self._region_cmb.bind('<<ComboboxSelected>>',
                              lambda e: self._populate_list())
        # ★★★ **용어 축 콤보**(2026-09-07 사용자 「용어사전에서 어떻게 분류할
        #   것인가? **속성/성품 · 행동/반응** ... 이런식으로」).
        #   ⚠ **용어 유형에서만** 뜬다 — 인물의 시대 콤보와 같은 자리·같은 문법.
        #   ⚠ 축은 새 유형이 아니라 꼬리표다(§12-0) — `json_detail.axis`.
        self._axis_var = tk.StringVar(value='')
        self._axis_codes = ['']
        self._axis_cmb = ttk.Combobox(self._type_cmb_f,
                                      textvariable=self._axis_var,
                                      state='readonly', width=12, font=('', 9))
        try:
            import db_term_axis as _TA
            self._axis_codes = [''] + [c for c, _n, _d in _TA.AXES]
            # ⚠ **축 이름을 그대로 쓰지 않는다** — 그 표의 글자는 우리말이라
            #   다른 언어 사용자가 한국어를 본다(§0-3, 2026-09-07 실측).
            self._axis_cmb['values'] = ([i18n.t('EB_AXIS_ALL', '축 전체')]
                                        + [_TA.axis_name(c)
                                           for c, _n, _d in _TA.AXES])
            self._axis_cmb.current(0)
        except Exception as _e:
            print('[EntityBrowser] axis combo: %s' % _e)
        self._axis_cmb.bind('<<ComboboxSelected>>',
                            lambda e: self._populate_list())
        self._rebuild_type_buttons()

        list_f = tk.Frame(parent, bg=_C('panel', '#F2F3F4'))
        list_f.pack(fill='both', expand=True, padx=2, pady=(0, 2))

        vsb = ttk.Scrollbar(list_f, orient='vertical')
        vsb.pack(side='right', fill='y')

        self._list_tv = ttk.Treeview(list_f, show='tree', selectmode='browse',
                                      yscrollcommand=vsb.set)
        vsb.config(command=self._list_tv.yview)
        self._list_tv.pack(fill='both', expand=True)
        self._list_tv.bind('<<TreeviewSelect>>', self._on_list_select)
        # ★★ **관계 묶음(`ax_*`)은 접히지 않는다** (2026-09-07 사용자 지시
        #   「트리구조 조절이 **매우 불편하다. 그냥 한번에 다 펼쳐지는 것이
        #   좋다**」). 묶음은 「무엇의 관계인가」를 말하는 **이름표**이지
        #   여닫는 서랍이 아니다 — 접으면 그 인물의 관계 절반이 조용히 사라진다.
        #   ⚠ 인물 줄(`c_*`)의 여닫기는 그대로 둔다(파고드는 동작이라 뜻이 있다).
        self._list_tv.bind('<<TreeviewClose>>', self._keep_group_open)

        import theme_font as _tf
        # ★★ **들여쓰기 0** (2026-09-07 사용자 확정 ④) — 묶음 머리를 쓰면서도
        #   목록 폭을 한 픽셀도 안 내준다. 가장 긴 이름이 18자
        #   (「불쌍히 여기다 · 스플랑크니조마이」)라 한 단(≈20px)이 아깝다.
        #   층은 머리의 굵기·색(`cat` 태그)이 말한다.
        #   ⚠ **`list_style` 의 인자로 준다** — 그 문이 값을 적어 두었다가
        #     글꼴이 바뀔 때 다시 먹인다(`reapply_all`). 밖에서 따로
        #     `configure` 하면 그때 8로 되돌아간다(실측으로 잡았다).
        _tf.list_style('EB.Treeview', self.db_path, heading=False, indent=0)
        ttk.Style().configure('EB.Treeview',
                              background=_C('bg', '#FAFAFA'), fieldbackground=_C('bg', '#FAFAFA'))
        self._list_tv.configure(style='EB.Treeview')
        # ★ **유형별 글자색을 쓰지 않는다** (2026-08-13 사용자 결정).
        #   예전에는 인물·장소·교리를 색으로 갈랐는데, 지금은 **상단 유형 버튼이
        #   그 일을 한다.** 색까지 나누면 얻는 것 없이 **바탕에 따라 안 읽히는 글자**만
        #   생긴다. 목록 글자는 테마의 기본 글자색 하나로 간다.
        #   ⇒ 유형 태그에 `foreground` 를 주지 않는다(태그 자체는 다른 곳에서 쓸 수 있어 둔다).
        self._list_tv.tag_configure('section', foreground=_C('fg_dim', '#AAB7B8'),
                                     font=('', 7))

    # ── 중앙: 엔티티 프로필 ──────────────────────────────────────────────────

    def _build_center(self, parent):
        # [2026-06-04] 외부 헤더 제거 — 기본정보는 탭1 설명 안 맨 위로 이동.
        # ★★ **앱 표준 탭을 그대로 쓴다** (2026-08-26 사용자 「탭 크기는 작고
        #   설명/사전이름 버튼은 더 크다. 가분수같다」 + 「표준 테마를 따르라」).
        #   전에는 `Center.TNotebook` 이라는 **자기 스타일**을 지어 색·글꼴을
        #   따로 박았다. 그래서 ① 9pt 로 고정돼 설정 글꼴(11pt)을 따르는 갈래
        #   단추보다 작았고 ② `ui_theme.apply_notebook_tabs` 의 표준 처리가
        #   이 노트북만 비껴갔다.
        #   ⚠⚠ **자기 스타일에 `foreground`(선택 시 fg_on_dark)만 먹고 배경이
        #     안 먹으면 흰 바탕에 흰 글자**가 된다 — 실제로 그렇게 나왔다
        #     (ui_theme 주석이 관리자 앱에서 같은 사고를 기록해 두었다).
        #   ⇒ 스타일을 안 만들고 기본 `TNotebook` 을 쓴다. 색·글꼴·균형이
        #     P2·P4 다른 탭과 저절로 같아진다.
        self._center_nb = ttk.Notebook(parent)
        self._center_nb.pack(fill='both', expand=True, padx=2, pady=(2, 2))
        # ★ My Edit + ⓜ = 노트북 오른쪽 위 모서리 (2026-09-02 ③ — 전폭 bar 가
        #   사라지면서 이사. 탭 줄 오른쪽은 빈 자리다. 링크 Focus 는 영상링크
        #   탭 안으로 들어가 자리가 겹치지 않는다).
        if not self._compact:
            # ★★★ **[검색창 닫기/표시] = 탭 줄 맨 왼쪽 칸**(2026-09-17 사용자
            #   「현재 위치가 싫다. **검색창과 가까운 곳**에 배치해야 사용자가
            #    쉽게 인지한다. **Focus 버튼과 같은 자리**에 배치하라」 ·
            #   「**"용어사전" 탭을 오른쪽으로 한칸 이동**하라」).
            #   ⇒ 그 둘은 **한 일**이다 — 칸이 생기면 첫 탭이 그만큼 오른쪽에서
            #     시작한다(`tabmargins`). 왼쪽 칸 바로 위라 **검색창과 가깝다**.
            #   ⚠ 옛 자리(노트북 오른쪽 모서리)는 화면 반대쪽이라 눈에 안 띄었다.
            #   ⚠ **알맹이는 `ui_theme.tab_strip` 한 문** — P1·P4 Focus 와 같은
            #     것이다. 여기서 다시 짜면 테마 전환에서 한쪽만 깨진다.
            import ui_theme as _ut0
            _strip = _ut0.tab_strip(self._center_nb, 'EBSearch.TNotebook')
            self._left_strip = _strip
            self._left_toggle_btn = tk.Button(
                _strip, text=i18n.t('EB_SEARCH_HIDE', '검색창 닫기'),
                command=self._toggle_left, **_ut0.flat_btn())
            self._left_toggle_btn.place(x=0, y=0, relwidth=1.0, relheight=1.0)
            _corner = tk.Frame(self._center_nb)
            # ★★★ **표시 언어 콤보 = 마지막 탭 오른쪽**(2026-09-17 사용자
            #   「가장 오른쪽 탭(주로 더보기) + 공백 + **언어콤보** + 공백 +
            #    다른 버튼들」). 탭 **밖**이라 여덟 탭이 다 같은 언어를 쓴다.
            #   ⚠ 옛 자리(용어사전 탭 안)는 그 탭에서만 보여, 나머지 일곱은
            #     앱 언어를 따라 **한 화면에 두 언어**가 섰다.
            #   ⚠ 왼쪽 칸에 넣어 봤다가 **사용자가 반려했다**(「정말 이상하다」).
            import lang_combo as _lcm
            self._dict_lang = _lcm.LangCombo(
                _corner, db_path=self.db_path,
                on_change=self._on_dict_lang_pick,
                width=11, gap=0, pady=0, side='left',
                default_lang=(self._app_lang() or 'KO').upper(),
                key='LANGSEL_DICT')
            self._dict_lang.set_items(_lcm.variant_items())
            # ⚠ `LangCombo` 는 Frame 이 아니다 — 콤보 위젯을 직접 다시 담는다
            self._dict_lang.combo.pack_configure(padx=(0, 8))
            # ★ [T] — 탭 설정(P2 와 **같은 팝업**). 화면마다 팝업을 지으면
            #   필수·표시방식 규칙이 갈린다(2026-09-17).
            tk.Button(_corner, text='T', bd=1, padx=6, pady=0,
                      font=('', 9, 'bold'), cursor='hand2',
                      command=self._open_tab_settings).pack(side='left',
                                                            padx=(0, 4))
            self._e_btn = tk.Button(_corner, text='My Edit',
                                    bd=1, padx=8, pady=0, font=('', 9, 'bold'),
                                    cursor='hand2', command=self._open_my_entity)
            self._e_btn.pack(side='left', padx=(0, 2))
            # ★ 299차 — [AI] : 지금 용어를 닻으로 AI 도우미(용어 갈래). 콜백은 user_main 이 건다.
            self.on_ai = getattr(self, 'on_ai', None)
            self._ai_btn = tk.Button(_corner, text='AI', bd=1, padx=8, pady=0, font=('', 9, 'bold'),
                                     cursor='hand2',
                                     command=lambda: (self.on_ai(self._current_eid)
                                                      if callable(self.on_ai) and self._current_eid
                                                      # ★ 2026-10-14 승격 안 된 낱말 화면 — 그 낱말을 닻으로
                                                      else self.on_ai_lemma(self._current_strong)
                                                      if callable(getattr(self, 'on_ai_lemma', None))
                                                      and getattr(self, '_current_strong', None) else None))
            self._ai_btn.pack(side='left', padx=(0, 2))
            self._hide_btn = self._e_btn          # 옛 이름 — 참조 보호
            try:
                from manual_widget import attach_manual_icon
                attach_manual_icon(_corner, 'U_P4_T4',
                                   lang_provider=self.lang_getter).pack(side='left')
            except Exception:
                pass
            _corner.place(relx=1.0, x=-4, y=2, anchor='ne')
            self._corner = _corner
            # ★ 좁아지면 콤보를 줄여 **마지막 탭을 안 가린다**(아래 `_fit_corner`)
            self._center_nb.bind('<Configure>',
                                 lambda _e: self._fit_corner_later(), add='+')
            self._center_nb.after_idle(self._fit_corner)

        # ── Tab 1: 용어사전 (갈래 줄 → 사전 사이트 → meta → 본문) ─────────────
        # ★ 탭 이름 = **「용어사전」** (2026-08-26 사용자 지시). 이 탭이 담는 것은
        #   우리 설명 + 외부 사전이므로 「설명」보다 정확하다. 안쪽 첫 갈래 단추가
        #   「설명」이다.
        desc_pane = tk.Frame(self._center_nb, bg=_C('panel', 'white'))
        self._center_nb.add(desc_pane, text=i18n.t('TAB_TERMDICT', '용어사전'))

        # ★ 이름 라벨·유형 chip 을 걷었다 (2026-08-26 사용자
        #   「맨 오른쪽에 인물/그룹 등의 구분값이 왜 표시되는가? 제거하라」).
        #   이름은 **상단 bar 의 탐색 경로**가, 유형은 **왼쪽 목록의 유형 단추**가
        #   이미 말한다 — 여기 또 두면 같은 말이 두 번이다.
        #   ⚠ 둘 다 None 으로 남긴다(갱신 코드가 그 가드를 본다).
        self._name_lbl = None
        self._type_chip = None

        # ── 비교 칸 — 「같아 보이지만 다른 낱말」 (2026-08-10, entity.md ①) ────
        # ★★ **좌우 분할로 재설계** (2026-09-02 사용자 지시 — 「상하 구분은
        #   가려진다. 데이터가 있는 경우에만 좌우로 배치하고 리사이즈를
        #   허용하라」). 옛 바닥 띠는 본문(expand)에 밀려 작은 창에서 안 보였다.
        #   · 짝이 있을 때만 오른쪽 패널로 add(빈 서랍 금지) · 사시 리사이즈
        #   · 본문 = Text(wrap='word') — 라벨 wraplength 가 문장을 어중간한
        #     자리에서 자르던 것을 표준 본문 위젯으로(§36 표준서식).
        self._desc_pw = tk.PanedWindow(desc_pane, orient='horizontal',
                                       sashwidth=5, bd=0,
                                       bg=_C('border', '#D5DBDB'))
        self._desc_pw.pack(side='top', fill='both', expand=True)

        # ★★ 2026-09-16 · 1.txt 3-(6)·5-4 사용자 — 「용어설명 아래에 "헷갈리는 낱말"
        #   목록을 배치하고, 낱말을 클릭하면 오른쪽에 별도 화면(슬라이딩)에 헷갈리는
        #   낱말의 설명문을 추가로 표시」 · 「지금은 클릭하면 주요용어 목록의 포커스가
        #   바뀐다. 결국 용어사전 등이 모두 바뀌어 버린다」.
        #   ⇒ 목록은 설명 본문 **아래**(같은 왼쪽 칸), 누르면 **오른쪽 칸**에 그 낱말의
        #     설명문만 편다 — 지금 보는 용어는 그대로다. [이 용어로 이동] 이 옛 동작.
        self._body_host = tk.Frame(self._desc_pw, bg=_C('panel', 'white'))
        self._desc_pw.add(self._body_host, stretch='always', minsize=240)
        self._cmp_f = tk.Frame(self._body_host, bg=_C('panel', 'white'))
        # ★★★ 2026-09-24 — **「헷갈리는 이웃 낱말」 → 「가까운 낱말」**
        #   (1.txt 15번). 이 칸은 오래전부터 헷갈리는 짝만이 아니라 **의미장
        #   형제·흐름·어근 가족**까지 함께 보이고 있었다 — 이름이 내용보다
        #   좁았다. 이제 짝마다 **관계**(반대말·비슷한 말…)를 적는다.
        tk.Label(self._cmp_f, text=i18n.t('EB_COMPARE', '가까운 낱말'),
                 bg=_C('panel', 'white'), fg=_C('fg_title', '#1A5276'),
                 font=('', 9, 'bold'), anchor='w'
                 ).pack(fill='x', padx=8, pady=(6, 2))
        _cmp_body = tk.Frame(self._cmp_f, bg=_C('panel', 'white'))
        _cmp_body.pack(fill='both', expand=True, padx=(8, 2), pady=(0, 6))
        _cmp_sb = tk.Scrollbar(_cmp_body)
        _cmp_sb.pack(side='right', fill='y')
        self._cmp_txt = tk.Text(_cmp_body, wrap='word', bd=0, height=3,
                                bg=_C('bg', '#FFFEF8'), fg=_C('fg', '#2C3E50'),
                                yscrollcommand=_cmp_sb.set, cursor='arrow',
                                state='disabled', padx=4, pady=2)
        self._cmp_txt.pack(side='left', fill='both', expand=True)
        _cmp_sb.config(command=self._cmp_txt.yview)
        _tfr(self._cmp_txt, self.db_path, 'prose', -1)
        self._cmp_rows = []

        # ── 본문 자리 하나 — 갈래에 따라 「설명」 또는 「사전」을 갈아 끼운다 ──
        # ★★ 설명·사전 탭 통합 (2026-08-26 사용자 승인 1안).
        #   사전 풀이를 가진 용어가 451개 중 163개(36%)뿐이라 독립 탭은 열 번 중
        #   여섯 번 빈 화면이었다. 이제 **갈래 단추**로 가른다 —
        #   `[설명] [Smith] [Easton]` 처럼 **그 용어에 실제로 있는 사전만** 뜬다.
        #   ⚠ 위젯을 파괴하지 않고 `pack_forget` 으로 바꿔 끼운다(§3 캔버스/트리뷰
        #     선례) — 파괴하면 스크롤 자리·태그를 매번 다시 지어야 한다.

        # 설명 본문
        # ── 오른쪽 슬라이딩 — 고른 이웃 낱말의 설명문 (누를 때만 pane 에 든다) ──
        self._nb_f = tk.Frame(self._desc_pw, bg=_C('panel', 'white'))
        _nbh = tk.Frame(self._nb_f, bg=_C('panel', 'white'))
        _nbh.pack(fill='x', padx=6, pady=(6, 2))
        self._nb_name = tk.Label(_nbh, text='', anchor='w', font=('', 9, 'bold'),
                                 bg=_C('panel', 'white'), fg=_C('fg_title', '#1A5276'))
        self._nb_name.pack(side='left', fill='x', expand=True)
        tk.Button(_nbh, text='✕', bd=0, cursor='hand2', padx=4, pady=0,
                  bg=_C('panel', 'white'), fg=_C('fg_dim', '#7F8C8D'),
                  command=self._hide_neighbor).pack(side='right')
        tk.Button(_nbh, text=i18n.t('EB_NB_GO', '이 용어로 이동'), font=('', 8),
                  bd=1, padx=6, pady=0, cursor='hand2',
                  command=self._go_neighbor).pack(side='right', padx=(0, 6))
        _nbb = tk.Frame(self._nb_f, bg=_C('panel', 'white'))
        _nbb.pack(fill='both', expand=True, padx=(6, 2), pady=(0, 6))
        _nbsb = tk.Scrollbar(_nbb)
        _nbsb.pack(side='right', fill='y')
        self._nb_txt = tk.Text(_nbb, wrap='word', bd=0,
                               bg=_C('bg', '#FDFEFE'), fg=_C('fg', '#2C3E50'),
                               yscrollcommand=_nbsb.set, cursor='arrow',
                               state='disabled', padx=8, pady=6)
        self._nb_txt.pack(side='left', fill='both', expand=True)
        _nbsb.config(command=self._nb_txt.yview)
        _tfr(self._nb_txt, self.db_path, 'prose')
        self._nb_eid = None

        desc_f = tk.Frame(self._body_host, bg=_C('panel', 'white'))
        self._desc_f = desc_f
        desc_f.pack(fill='both', expand=True, padx=4, pady=4)
        desc_sb = ttk.Scrollbar(desc_f)
        desc_sb.pack(side='right', fill='y')
        # ⚠ 요청 높이를 낮게(4줄) — 기본 24줄을 요청하면 낮은 P4 에서 아래 목록이
        #   0px 이 된다. 남는 자리는 expand 가 어차피 여기로 준다(2026-09-16 실측:
        #   172px 칸에서 8줄로도 목록이 0 이었다).
        self._desc_txt = tk.Text(desc_f, wrap='word', relief='flat', height=4,
                                  bg=_C('bg', '#FDFEFE'), font=('', 9),
                                  yscrollcommand=desc_sb.set,
                                  state='disabled', cursor='arrow',
                                  padx=8, pady=6)
        desc_sb.config(command=self._desc_txt.yview)
        self._desc_txt.pack(fill='both', expand=True)
        _tfr(self._desc_txt, self.db_path, 'prose')   # 엔티티 설명 (§36)

        # ★★ 옛 「사전」 탭은 없앴다 — 위 설명 탭 안의 **갈래**로 들어간다.
        #   ⚠ `_dict_subtab_index = None` — `_apply_type_tabs` 가 이 값으로 탭을
        #     잠그던 자리라, 없어진 탭을 가리키면 엉뚱한 탭이 잠긴다.
        dict_pane = desc_pane
        self._dict_subtab_index = None

        # 표시 언어 — **콤보 하나** (2026-08-14 사용자 지시 8번 「주요용어/사전탭의
        # 언어콤보도 표준화」). 주석·도서와 같은 `lang_combo` 를 쓴다.
        # ⚠ 예전에는 라디오 3개(원문·현대영어·다국어) + 폭 6짜리 콤보였고,
        #   **없는 판을 눌러도 그대로 눌려** 빈 화면이 나왔다.
        # ── ① 갈래 줄 — `[설명] [Smith] [Easton]` … 오른쪽 끝에 언어 콤보 ──
        #   (2026-08-26 사용자 배치 지시: 「설명 탭 배치하고 그 오른쪽에 사전이름,
        #    그 오른쪽에 언어 콤보」)
        dict_ctrl = tk.Frame(dict_pane, bg=_C('panel', '#F0F0F0'), padx=4, pady=3)
        # ⚠ 본문 자리(`_body_host`)가 이미 expand 로 붙어 있다 — `before=` 로
        #   순서를 당기지 않으면 이 줄이 본문 **아래**로 내려간다.
        dict_ctrl.pack(fill='x', side='top', before=self._desc_pw)
        # ⚠ 언어 콤보는 **여기 없다** — 노트북 오른쪽 위 모서리로 옮겼다
        #   (2026-09-17). 이 탭에만 있으면 나머지 일곱이 못 따른다.

        # 사전별 버튼 (2026-08-10 사용자 지시 「사전을 서브 버튼으로 표시하면 좋겠다」).
        # 전에는 Easton·Smith·Meyer 세 항목을 한 칸에 위아래로 이어 붙여서, 위에
        # 긴 것이 걸리면 아래 사전이 있는 줄도 몰랐다. 지금은 한 번에 하나만 보인다.
        # ⚠ 그 엔티티에 **실제로 있는 사전만** 버튼을 만든다. 늘 셋을 그리면 눌러도
        #   빈 화면이 나온다.
        # ★ **언어 콤보와 같은 줄, 오른쪽으로** (2026-08-16 사용자 지시
        #   「언어콤보상자에서 오른쪽 여백을 두고 오른쪽에 버튼을 배치하자」).
        #   콤보 **바로 아래**에 있어서 줄이 둘로 늘고 본문 자리를 먹었다.
        # ★ **고른 이름을 단추 줄 맨 왼쪽에 굵게**(2026-09-15 항목 ③ 사용자
        #   승인). 2026-08-26 에 걷었던 이름 라벨의 자리가 아니라 **갈래 줄
        #   안**이다 — 「무엇의 설명·사전인가」를 단추 바로 옆에서 말한다.
        self._dict_name_lbl = tk.Label(dict_ctrl, text='', bg=_C('panel', '#F0F0F0'),
                                       fg=_C('fg_title', '#1A5276'), anchor='w')
        _tfr(self._dict_name_lbl, self.db_path, 'ui')
        try:
            import tkinter.font as _tkf
            _nf = _tkf.Font(font=self._dict_name_lbl.cget('font'))
            _nf.configure(weight='bold')
            self._dict_name_lbl.configure(font=_nf)
        except Exception:
            pass
        self._dict_btnbar = tk.Frame(dict_ctrl, bg=_C('panel', '#F0F0F0'))
        self._dict_btnbar.pack(side='left')
        # ★★ 차례 = **[용어설명][사전 모음] (공백) 이름 굵게 · 원어**
        #   (2026-09-17 · 1.txt 1-4 사용자 배치 그대로).
        #: 원어 표기 — 「원어: H7307(루아흐) · G4151(프뉴마)」
        #: ⚠ 붙이는 것은 `_paint_dict_name`·`_paint_dict_lex` 가 한다 —
        #:   값이 없으면 안 그린다(§0-1). 여기서 미리 붙이면 빈 칸이 남는다.
        self._dict_lex_lbl = tk.Label(dict_ctrl, text='',
                                      bg=_C('panel', '#F0F0F0'),
                                      fg=_C('fg_dim', '#5D6D7E'), anchor='w')
        _tfr(self._dict_lex_lbl, self.db_path, 'meta')
        self._dict_btns = {}
        self._dict_rows = []
        self._dict_src  = None

        # ── ② 외부 사전 사이트 = **사전 단추 오른쪽, 같은 줄** (2026-09-02
        #   사용자 지시 ⑤ — 「"외부사전사이트:" 라벨을 제거하고 버튼 문자를
        #   함축적으로」). 별도 고정 높이 줄(30px)이 통째로 사라져 본문이
        #   그만큼 는다. 언어 콤보(오른쪽 끝) 왼쪽에 붙는다.
        self._dict_ext_f = tk.Frame(dict_ctrl, bg=_C('panel', '#F0F0F0'))
        self._dict_ext_f.pack(side='right', padx=(4, 6))
        self._dict_ext_lbl = None      # 라벨 폐지 — 옛 참조 보호
        # 버튼들은 _load_external_sites에서 동적 생성

        # ── ②-2 **원어사전 Direct Link** (2026-09-12 사용자 `1.txt` 2-5 —
        #   「주요용어 탭의 "용어사전" 서브탭 **첫 라인의 오른쪽**에 선택한
        #    용어에 대한 원어사전 Direct Link 버튼 배치」).
        #   ★★★ **재료가 이미 다 있었다** — `sys_entity_lemma` 의 Strong 번호와
        #     `scope='STRONG'` 사이트 둘(BibleHub Lexicon · Blue Letter Bible),
        #     그리고 자리표를 치환하는 `overlay_read.strong_url`.
        #     그전에는 **사전 본문 글자 속 링크**라 단추처럼 안 보였다.
        #   ⚠⚠ **앵커가 없으면 안 그린다**(§0-1) — 실측 사람이 보는 용어 578개
        #     중 앵커가 있는 것은 **129개(22%)**다. 용어(TERM) 108/122 · 교리
        #     20/50 이고 **인물·장소·절기는 0개**다. 「다윗」에 원어사전 단추를
        #     다는 것은 뜻이 없다.
        #   ⚠⚠ **단추만으로는 못 놓는다** — 앵커가 넷인 용어(「구원」 H3467·
        #     H3444·G4982·G4991)에 사이트 둘이면 **여덟 단추 864px** 이고,
        #     줄 자리는 1,235px 인데 필요가 1,524px 이었다(실측). 좁은
        #     compact 모드는 410px 에 647px 이 필요했다.
        #   ⇒ **주석 화면과 같은 문법** — 대표 하나만 단추, 나머지는 콤보.
        #     좁으면 단추를 접는다(콤보에 그대로 있어 잃는 것이 없다).
        self._dict_strong_f = tk.Frame(dict_ctrl, bg=_C('panel', '#F0F0F0'))
        self._dict_strong_f.pack(side='right', padx=(4, 0))
        self._strong_combo = ttk.Combobox(self._dict_strong_f, state='disabled',
                                          width=16)
        self._strong_combo.pack(side='right', padx=(4, 0))
        self._strong_combo.bind('<<ComboboxSelected>>', self._on_strong_pick)
        self._strong_map = {}
        self._strong_btn = None
        dict_ctrl.bind('<Configure>', self._fit_dict_bar)

        # ── ③ 연대·지파 등 라벨 — **2단에 한 줄로 못 박는다** ────────────
        # ★★★ 2026-09-17 사용자 ④ 「용어설명 / 사전모음 아래에 시대, 역할 등을
        #   표시하는 공간이 있다. 1) 이 공간을 **항상 배치**해서 용어 선택에 따라
        #   **들쭉날쭉하는 일이 없도록** 하라. 2) 또는 1단으로 옮겨라.
        #   **공간이 좁다면 2단에 고정배치**하라」.
        #   ⇒ 1단은 이미 꽉 찼다(갈래 단추·이름·원어·사전 사이트·언어콤보) —
        #     그래서 **2단 고정**을 골랐다. 사용자가 적어 준 그 갈림길 그대로다.
        # ⚠⚠⚠ **들쭉날쭉의 진짜 원인은 `wraplength=560` 이었다** — 실측 가장 긴
        #   메타가 **654px** 이라 560 에서 둘째 줄로 접혔다. 그런데 이 칸의 실제
        #   폭은 1,200px 안팎이다. **없는 좁음을 스스로 만들어** 접고 있었다.
        #   ⇒ 접지 않는다(`wraplength=0`) — 어떤 용어를 골라도 **언제나 한 줄**.
        # ⚠ 비어도 **걷지 않는다**(옛 `pack_forget`) — 그것이 곧 들쭉날쭉이었다.
        #   실측 사람이 보는 용어 578개 중 메타가 있는 것은 247개(43%)라
        #   **고르는 족족 본문이 11px 씩 오르내렸다**.
        # ⚠ 빈 줄에 유형(인물·장소)을 대신 적지 않는다 — 2026-08-26 에 사용자가
        #   「구분값이 왜 표시되는가? 제거하라」로 걷은 그 값이다.
        self._meta_lbl = tk.Label(desc_pane, text='', bg=_C('panel', 'white'),
                                  font=('', 8), fg=_C('fg_dim', '#5D6D7E'),
                                  anchor='w', justify='left', wraplength=0)
        self._meta_lbl.pack(fill='x', padx=10, pady=(3, 0),
                            before=self._desc_pw)
        self._meta_sep = tk.Frame(desc_pane, bg=_C('border', '#D5DBDB'),
                                  height=1)
        self._meta_sep.pack(fill='x', padx=6, pady=(3, 4),
                            before=self._desc_pw)

        # ⚠ 사전 본문은 **처음에 안 붙인다** — 기본 갈래가 「설명」이다.
        #   `_show_src_branch` 가 둘을 바꿔 끼운다.
        dict_f = tk.Frame(self._body_host, bg=_C('panel', 'white'))
        self._dict_body_f = dict_f
        dict_sb = ttk.Scrollbar(dict_f)
        dict_sb.pack(side='right', fill='y')
        self._dict_txt = tk.Text(dict_f, wrap='word', relief='flat',
                                  bg=_C('bg', '#F9FBE7'),
                                  yscrollcommand=dict_sb.set,
                                  state='disabled', cursor='arrow',
                                  padx=8, pady=6)
        dict_sb.config(command=self._dict_txt.yview)
        self._dict_txt.pack(fill='both', expand=True)
        _tfr(self._dict_txt, self.db_path, 'prose')   # 사전 본문 (§36)
        # ★ 표준서식 (2026-09-02 사용자 지시 ①) — 태그 크기를 박지 않고 설정
        #   글꼴(prose 구역)에서 유도한다. 본문 태그는 글꼴을 아예 안 적어
        #   위젯 등록 글꼴을 그대로 따른다(연결구절 탭과 같은 문법).
        try:
            import theme_font as _thf2
            _psz = int(_thf2.resolve(self.db_path, 'prose')['size'])
        except Exception:
            _psz = 10
        self._dict_txt.tag_configure('dict_src',
                                      font=('', max(7, _psz - 3), 'bold'),
                                      foreground=_C('fg_dim', '#808B96'))
        self._dict_txt.tag_configure('dict_title',
                                      font=('', _psz, 'bold'),
                                      foreground=_C('fg_title', '#1A5276'))
        self._dict_txt.tag_configure('dict_body',
                                      foreground=_C('fg', '#2C3E50'),
                                      spacing1=2, spacing2=1)

        # Tab 3: 외부 링크
        # ★ 서브탭 승격 (2026-09-02 0.txt 3번) — 옛 「링크」 탭의 갈래 단추
        #   [영상링크][텍스트링크]가 **정식 서브탭 둘**이 됐다. 이 pane 은
        #   영상링크(목록+인라인 플레이어) 몫이다.
        url_pane = tk.Frame(self._center_nb, bg=_C('panel', 'white'))
        self._center_nb.add(url_pane, text=i18n.t('EB_BR_VIDEO', '영상링크'))
        self._url_subtab_index = self._center_nb.index('end') - 1   # 개수 표시용

        # 본문: 좌(버튼+링크 목록) + 우(임베드 플레이어). compact/임베드 불가 환경은 좌측만.
        self._embed_host = None
        self._embed_player = None
        self._embed_hint = None
        self._embed_enabled = (not self._compact) and _MP_EMBED_OK

        if self._embed_enabled:
            # 좌(목록)/우(플레이어) — 드래그로 비율 조절 가능 (PanedWindow 의 sash)
            body = tk.PanedWindow(url_pane, orient='horizontal', sashwidth=6,
                                  bg=_C('border', '#C8CDD2'), sashrelief='raised', opaqueresize=False)
            body.pack(side='top', fill='both', expand=True)
            left_col = tk.Frame(body, bg=_C('panel', 'white'))
            self._embed_host = tk.Frame(body, bg=_C('dark_bg', 'black'))
            body.add(left_col, minsize=200, width=390, stretch='never')
            body.add(self._embed_host, minsize=240, stretch='always')
            self._embed_hint = tk.Label(self._embed_host,
                     text=i18n.t('EB_CLICK_VIDEO','◀ 왼쪽 목록에서 영상을 클릭하세요'),
                     bg=_C('dark_bg', 'black'), fg=_C('fg_dim', '#888'), font=('', 9))
            self._embed_hint.pack(expand=True)
            # 패널 파괴 시 자식 프로세스 정리
            self.bind('<Destroy>', self._on_destroy_cleanup, add='+')
        else:
            body = tk.Frame(url_pane, bg=_C('panel', 'white'))
            body.pack(side='top', fill='both', expand=True)
            left_col = tk.Frame(body, bg=_C('panel', 'white'))
            left_col.pack(fill='both', expand=True, padx=4, pady=4)

        # ★ 옛 갈래 단추 줄은 서브탭 승격으로 걷었다 (2026-09-02 0.txt 3번).
        self._inline_btn = None      # 옛 「큰 창으로 보기」 — 참조 보호
        # ★ [Focus]/[Restore] = **영상 목록 첫 칸 바로 위** (2026-09-02 사용자
        #   지시 ② — 노트북 모서리는 여정 탭과 너무 떨어져 어색했다. 탭 안에
        #   살므로 「영상링크 탭에서만 보인다」가 저절로 된다).
        #   서식 = P4 공통 Focus 와 같은 flat_btn.
        import ui_theme as _uth2
        _fbkw = _uth2.flat_btn(font=('', 9))
        _lk_top = tk.Frame(left_col, bg=_C('panel', 'white'))
        _lk_top.pack(side='top', fill='x', pady=(0, 2))
        self._lk_focus_btn = tk.Button(
            _lk_top, text=i18n.t('UM_FOCUS', 'Focus'),
            command=lambda: self._link_focus(True),
            **_uth2.focus_kw(font=('', 9)))
        self._lk_restore_btn = tk.Button(
            _lk_top, text=i18n.t('UM_RESTORE', 'Restore'),
            command=lambda: self._link_focus(False),
            **_uth2.focus_kw(restore=True, font=('', 9)))
        # ⚠ 안 그린다(2026-09-16 · 1.txt 28 — Focus/Restore 는 P4 구절연결 탭 하나뿐).
        #   단추는 만들어 두어 `_link_focus` 가 살아 있다(코드 자리를 남긴다).
        self._lk_focused = False

        # 표준 5컬럼(언어/형태/제목/채널/★) — links_panel(P2/P4노드) Links 와 동일 모양
        url_f = tk.Frame(left_col, bg=_C('panel', 'white'))
        url_f.pack(side='top', fill='both', expand=True)
        self._url_tv = mlv.build_tree(url_f, style_name='EBLinks.Treeview')
        # 범위·고르기 칸은 용어 화면에서 무의미 — 폭 0 (칸 수는 표준 유지)
        for _c0 in ('pick', 'scope'):
            self._url_tv.column(_c0, width=0, minwidth=0, stretch=False)
        url_vsb = ttk.Scrollbar(url_f, orient='vertical', command=self._url_tv.yview)
        self._url_tv.configure(yscrollcommand=url_vsb.set)
        url_vsb.pack(side='right', fill='y')
        self._url_tv.pack(side='left', fill='both', expand=True)
        self._url_tv.bind('<ButtonRelease-1>', self._on_url_click)
        self._url_items = {}        # iid -> (media_id, url, yt_video_id)

        # ── 텍스트링크 서브탭 (2026-09-02 승격) — 제 트리 + 참고자료 목록.
        #   텍스트 줄은 브라우저로 열리므로 플레이어가 필요 없다 — 트리를
        #   따로 두는 것이 플레이어 공유 재부모화(§96차 Tk 불가)보다 안전하다.
        txt_pane = tk.Frame(self._center_nb, bg=_C('panel', 'white'))
        self._center_nb.add(txt_pane, text=i18n.t('EB_BR_TEXT', '텍스트링크'))
        self._txt_subtab_index = self._center_nb.index('end') - 1
        self._txt_pane = txt_pane
        _txt_f = tk.Frame(txt_pane, bg=_C('panel', 'white'))
        _txt_f.pack(side='top', fill='both', expand=True, padx=4, pady=(4, 0))
        self._txt_tv = mlv.build_tree(_txt_f, style_name='EBLinks.Treeview')
        for _c0 in ('pick', 'scope'):
            self._txt_tv.column(_c0, width=0, minwidth=0, stretch=False)
        _txt_vsb = ttk.Scrollbar(_txt_f, orient='vertical',
                                 command=self._txt_tv.yview)
        self._txt_tv.configure(yscrollcommand=_txt_vsb.set)
        _txt_vsb.pack(side='right', fill='y')
        self._txt_tv.pack(side='left', fill='both', expand=True)
        self._txt_tv.bind('<ButtonRelease-1>', self._on_url_click)
        self._txt_items = {}        # iid -> (media_id, url, None)

        # [관] 엔티티 연결 참고자료 — 텍스트링크 탭 하단(글 자료라 이 갈래 몫)
        refa_lf = ttk.LabelFrame(txt_pane, text=i18n.t('EB_REF_ARTICLES', '참고자료'))
        refa_lf.pack(side='bottom', fill='x', padx=4, pady=(4, 4))
        self._refa_tv = ttk.Treeview(refa_lf, columns=('lang', 'title'),
                                     show='headings', height=4, selectmode='browse')
        self._refa_tv.heading('lang', text=i18n.t('COMMON_LANG', '언어'))
        self._refa_tv.heading('title', text=i18n.t('COMMON_TITLE', '제목'))
        self._refa_tv.column('lang', width=44, anchor='center', stretch=False)
        self._refa_tv.column('title', width=320, anchor='w')
        refa_vsb = ttk.Scrollbar(refa_lf, orient='vertical', command=self._refa_tv.yview)
        self._refa_tv.configure(yscrollcommand=refa_vsb.set)
        refa_vsb.pack(side='right', fill='y')
        self._refa_tv.pack(side='left', fill='x', expand=True)
        self._refa_tv.bind('<Double-1>', self._on_refa_click)
        self._refa_tv.bind('<Return>', self._on_refa_click)
        self._refa_items = {}       # iid -> url

        # ── Tab 4: 연결구절 — 구절단락 + 낱말구절 통합 (2026-08-26 사용자 지시
        #   「하나로 통합하라. 목록의 구분값을 2개로 나누어라」) ─────────────────
        # 한 목록에 두 층이 산다:
        #   단락 = 사람이 이은 의미(서사) 연결(ENTI_PERI — 연결설명문·단락설명문)
        #   낱말 = 원어 앵커에서 기계로 나온 절 + 사람이 이은 절(ENTI_VERS)
        # 오른쪽 = 그 구간 본문 + 설명문(연결설명문 우선, 없으면 단락설명문).
        # 옛 두 탭(TAB_PERICOPE·TAB_ENTITY_LEX)의 열쇠는 다른 화면이 쓰므로 그대로 두고
        # 새 열쇠(TAB_ENTITY_LINKVERSE)를 쓴다.
        link_pane = tk.Frame(self._center_nb, bg=_C('panel', 'white'))
        self._center_nb.add(link_pane, text=i18n.t('TAB_ENTITY_LINKVERSE', '연결구절'))
        self._link_subtab_index = self._center_nb.index('end') - 1
        self._build_linked_subtab(link_pane)

        # ── Tab 5: 연구 (우리가 쓴 내부자료 글) ────────────────────────────
        # 사전 탭에 섞지 않는다 — 수입한 사전과 우리가 정리한 글은 신뢰의 층이 다르다
        # (§21-4 가 「전부 교리자료라 부르면 연구 글도 교리자료가 된다」로 겪은 함정).
        # 줄을 누르면 P4 탭10(자료)으로 보내 넓게 읽는다. 0편이면 연결구절 탭과
        # 같은 방식으로 비활성 — 429개 엔티티 대부분이 아직 0편이다.
        study_pane = tk.Frame(self._center_nb, bg=_C('panel', 'white'))
        # ★ 여기도 **하위탭이 상위탭 자리를 차지**한 자리다 → 「연구자료」(2026-08-16).
        self._center_nb.add(study_pane, text=i18n.t('TAB_RESEARCH', '연구/설교노트'))
        self._study_subtab_index = self._center_nb.index('end') - 1
        self._build_study_subtab(study_pane)

        # ── 내부연결 서브탭 (2026-09-02 승격 — 옛 연구자료 탭의 갈래) ────
        #   사전·문답·설교·도서로 이어지는 줄 — 더블클릭이 그 화면으로 보낸다.
        nav_pane = tk.Frame(self._center_nb, bg=_C('panel', 'white'))
        self._center_nb.add(nav_pane, text=i18n.t('REFR_SCOPE_NAV', '내부연결'))
        self._nav_subtab_index = self._center_nb.index('end') - 1
        self._nav_pane = nav_pane
        _nav_f = tk.Frame(nav_pane, bg=_C('panel', 'white'))
        _nav_f.pack(fill='both', expand=True, padx=6, pady=6)
        ntv = ttk.Treeview(_nav_f, columns=('title', 'verses'),
                           show='headings', selectmode='browse')
        ntv.heading('title',  text=i18n.t('COMMON_TITLE', '제목'))
        ntv.heading('verses', text=i18n.t('REFR_LINKED_VERSES', '연결 구절'))
        ntv.column('title',  width=300, minwidth=110, anchor='w')
        ntv.column('verses', width=60, minwidth=50, anchor='center', stretch=False)
        _nvsb = ttk.Scrollbar(_nav_f, orient='vertical', command=ntv.yview)
        ntv.configure(yscrollcommand=_nvsb.set)
        _nvsb.pack(side='right', fill='y')
        ntv.pack(fill='both', expand=True)
        ntv.bind('<Double-1>', self._on_study_open)
        ntv.bind('<Return>', self._on_study_open)
        self._nav_tv = ntv
        import theme_font as _tf2
        _tf2.list_style('EB.Treeview', self.db_path, heading=True,
                        indent=0)

        # ── 찬양 — 곡 → 판 → 영상 세 층 (2026-09-09) ────────────────────
        # ★ 부품은 `song_panel` 하나 — P2 와 같은 것을 심는다(층·표기가 갈리지
        #   않게). 축만 다르다: 여기는 **용어**, P2 는 **구절**.
        # ⚠ 그 용어에 곡이 없으면 **탭이 잠긴다**(§0-1 빈 서랍 금지).
        song_pane = tk.Frame(self._center_nb)
        self._center_nb.add(song_pane, text=i18n.t('TAB_SONG', '찬양'))
        self._song_subtab_index = self._center_nb.index('end') - 1
        self._song_panel = None
        self._song_host = song_pane

        # ★★★ **여정 탭을 걷었다**(2026-09-17 사용자 「여정=삭제」).
        #   ⚠ **잃는 것이 없다** — 같은 지도를 P4 「믿음의 발자취」 탭이 훨씬
        #     넓게 보인다(§31). 여기 것은 420~1,200px 칸에 끼운 축소판이었고,
        #     실측 578용어 중 경로가 있는 것이 **121개(21%)** 라 나머지에서는
        #     늘 잠긴 채 자리만 먹었다.
        #   ⚠ 옛 이름은 `None` 으로 남긴다 — 밖에서 읽는 자리가 견디게.
        self._journey_pane = None
        self._journey_subtab_index = None
        self._journey_map = None
        self._journey_pending = None

        # ── 「더보기」 — 선택 갈래를 **한 목록**으로 (2026-09-17) ──────────
        # ★ 위젯은 P2 와 **같은 것**(`p2_one_list.OneList`) — 칸·★·✕·손놀림이
        #   갈리지 않게 재료만 갈아 끼운다(`eb_one_list.rows`).
        more_pane = tk.Frame(self._center_nb, bg=_C('panel', 'white'))
        self._center_nb.add(more_pane, text=i18n.t('P2T_MORE', '더보기'))
        self._more_subtab_index = self._center_nb.index('end') - 1
        self._more_pane = more_pane
        self._more_list = None            # 첫 필요 때 만든다(§29 지연)
        self._more_tabs = None            # 더보기 안 갈래 줄(서브탭 방식)
        self._more_one = False            # 표시방식 — `_apply_tab_prefs_now` 가 적는다
        # ★★★ **서브탭 차례 = 용어사전 · 연결구절 · 연구자료 · 내부연결 ·
        #   영상링크 · 텍스트링크 · 여정** (2026-09-02 0.txt 3번 승격).
        #   만드는 차례는 위젯끼리 참조가 얽혀 있어 못 바꾼다 — **다 만든 뒤
        #   자리만 옮긴다**(`insert`).
        #   ⚠ `*_subtab_index` 는 만들 때 `index('end')-1` 로 박아 둔 값이라
        #     옮기고 나면 **전부 어긋난다.** 옮긴 뒤 다시 잰다(안 그러면
        #     `_gate_subtabs_for_type` 이 엉뚱한 탭을 잠근다 — §94차 사고).
        try:
            for pos, pane in enumerate((desc_pane, link_pane, study_pane,
                                        nav_pane, url_pane, txt_pane,
                                        song_pane, more_pane)):
                self._center_nb.insert(pos, pane)
            for attr, pane in (('_dict_subtab_index', desc_pane),
                               ('_link_subtab_index', link_pane),
                               ('_study_subtab_index', study_pane),
                               ('_nav_subtab_index', nav_pane),
                               ('_url_subtab_index', url_pane),
                               ('_txt_subtab_index', txt_pane),
                               ('_song_subtab_index', song_pane),
                               ('_more_subtab_index', more_pane)):
                setattr(self, attr, self._center_nb.index(pane))
        except Exception as _e:
            print('[EntityBrowser] 서브탭 재배치: %s' % _e)

        self._center_nb.bind('<<NotebookTabChanged>>', self._on_center_tab_changed, add='+')

        # ── 인물 전용 버튼 (pack/pack_forget으로 토글) ───────────────────────
        self._person_btn_f = tk.Frame(parent, bg=_C('accent_bg', '#EBF5FB'))
        tk.Button(self._person_btn_f, text=i18n.t('EB_GENEALOGY','족보 보기'),
                  font=('', 9), relief='groove',
                  bg=_C('accent_bg', '#AED6F1'), activebackground=_C('select_bg', '#85C1E9'),
                  command=self._on_person_tree_click
                  ).pack(side='left', padx=8, pady=6)
        # ⚠ **[네트워크 보기] 단추를 걷었다**(2026-09-26 · 1.txt 20번 1) —
        #   가던 곳(P4 제자 가계도)이 없어졌다. 누르면 아무 일도 안 나는
        #   단추를 남기지 않는다(§0-1). `_on_person_net_click` 은 되돌릴
        #   자리로 남긴다(탭을 되살리면 이 줄과 함께 되살린다).

    # ── 연결구절 서브탭 (단락 + 낱말 한 목록 — 2026-08-26) ─────────────────────

    def _build_linked_subtab(self, parent):
        """연결구절 — 좌 목록(구분·구절·내용) + 우 본문·설명문.

        구분값은 「단락」/「낱말」 둘뿐이다(사용자 「일단 구분값으로만 식별하자」).
        ⚠ 마일스톤 ★ 접두는 폐지(사용자 「제목에 붙인 별표는 삭제하라」) —
          대표값(부르심·훈련 등)은 내용 칸 꼬리에 「 · 훈련」 으로 남긴다.
        ⚠ 옛 보기 모드 3단추(구절/단락설명/모아보기)는 폐지 — 오른쪽이
          본문과 설명문을 **함께** 보인다(사용자 「버튼 3개가 필요 없는 것 같다」
          + 「페리코프 표시하고 연결설명문 또는 페리코프설명문을 표시」).
        """
        # 낱말 버튼 줄 — 원어 앵커가 있는 엔티티에서만 나타난다(pack/forget)
        self._lex_btnbar = tk.Frame(parent, bg=_C('panel', 'white'))
        self._lex_btns = {}
        self._lex_lemmas = []
        self._lex_lemma = None
        # ★ **낱말 뜻은 여기 한 번**(2026-09-15 항목 ③). 그전에는 절마다
        #   「낱말 설명」 블록으로 되풀이되어 어느 절을 눌러도 같은 글이었다
        #   (실측 절마다 쓴 글은 38건뿐). 단추 뒤에 붙고 폭은 `_fit_lex_gloss`.
        self._lex_gloss_lbl = tk.Label(self._lex_btnbar, text='',
                                       bg=_C('panel', 'white'),
                                       fg=_C('fg_dim', '#566573'),
                                       anchor='w', justify='left')
        _tfr(self._lex_gloss_lbl, self.db_path, 'meta')
        self._lex_rend_sum = ''
        self._lex_btnbar.bind('<Configure>', self._fit_lex_gloss, add='+')

        # ⚠ 바닥 안내줄은 expand 자식보다 **먼저** side='bottom' 으로 잡는다
        #   (뒤에 pack 하면 1×1 로 안 보인다 — 문서의 반복 함정)
        tk.Label(parent, bg=_C('panel', 'white'), fg=_C('fg_dim', '#566573'),
                 anchor='w', font=('', 8),
                 text=i18n.t('EB_LEX_HINT', '줄을 두 번 누르면 그 구절로 이동합니다')
                 ).pack(side='bottom', fill='x', padx=6, pady=(0, 2))

        # ★ 상하 분할 (2026-09-01 0.txt 7번 사용자 지시 — 「좌우 분할이라
        #   왼쪽 성경구절이 제대로 안 보임. 상하 분할배치 방식으로 전환」).
        #   위 = 목록 · 아래 = 본문+설명문. 목록 칸 폭이 패널 전폭을 얻는다.
        h_pw = tk.PanedWindow(parent, orient='vertical',
                               sashwidth=5, bg=_C('border', '#BDC3C7'), sashrelief='flat')
        h_pw.pack(fill='both', expand=True)
        self._link_pw = h_pw

        # 위: 통합 목록
        left = tk.Frame(h_pw, bg=_C('panel', '#FAFAFA'))
        h_pw.add(left, height=230)
        # ★★ 「시대」 칸 신설 (2026-09-01 사용자 승인 아이디어 ③ — 「언약이
        #   족장→시내→왕정→새 언약으로 **자라는 모습**이 한눈에」). 줄 차례
        #   (대표 먼저 · 의미 먼저)는 그대로 두고 칸 하나로 분포를 보인다.
        #   값은 `db_era_code.era_of_verse` — 코드표가 단일 소스다.
        # ★★ 「갈래」 칸 (2026-09-02 사용자 확정 — 「하나의 용어 안에 서로
        #   연결된 두 갈래 · 단어 하나가 구속사의 이미-아직을 보여 준다」).
        #   원천(하나님) → 십자가(전환점) → 확산(성도·공동체). 값은
        #   `sys_entity_branch`(db_term_branch) — 값이 있는 줄만 채워진다.
        # ⚠ **「시대」 칸은 걷었다**(2026-09-15 항목 ③) — 용어에서 값이
        #   0/11,064 라 늘 빈 칸이었다(실측). `db_era_code` 자체는 남는다.
        cols = ('kind', 'branch', 'ref', 'text')
        vsb = ttk.Scrollbar(left, orient='vertical')
        tv = ttk.Treeview(left, columns=cols, show='headings',
                          selectmode='browse', yscrollcommand=vsb.set)
        vsb.config(command=tv.yview)
        vsb.pack(side='right', fill='y')
        tv.pack(fill='both', expand=True, padx=(2, 0), pady=(2, 2))
        tv.heading('kind', text=i18n.t('EB_COL_KIND', '구분'))
        # ★ 「흐름」(2026-09-15 항목 ③ — 옛 「단계」). 값(원천·십자가·확산)은 그대로.
        tv.heading('branch', text=i18n.t('EB_COL_FLOW', '흐름'))
        tv.heading('ref',  text=i18n.t('EB_LEX_REF', '구절'))
        tv.heading('text', text=i18n.t('EB_COL_CONTENT', '내용'))
        tv.column('kind', width=44, minwidth=40, anchor='center', stretch=False)
        tv.column('branch', width=52, minwidth=44, anchor='center', stretch=False)
        tv.column('ref',  width=110, minwidth=70, anchor='w', stretch=False)
        tv.column('text', width=220, minwidth=120, anchor='w')
        import theme_font as _tf
        f = _tf.list_style('Peri.Treeview', self.db_path, heading=True)
        ttk.Style().configure('Peri.Treeview',
                              background=_C('panel', '#FAFAFA'),
                              fieldbackground=_C('panel', '#FAFAFA'),
                              foreground=_C('fg', '#2C3E50'))
        tv.configure(style='Peri.Treeview')
        # 목록 트리 표준(§18-3 4차) — 상태를 말하는 색만 남긴다
        tv.tag_configure('milestone', foreground=_C('fg_title', '#1A5276'),
                         font=f + ('bold',))
        tv.tag_configure('key',      foreground=_C('warning', '#7E5109'),
                         font=f + ('bold',))
        tv.tag_configure('thematic', foreground=_C('success', '#1E8449'))
        tv.tag_configure('more',     foreground=_C('accent', '#2874A6'))
        tv.tag_configure('section',  foreground=_C('fg_dim', '#AAB7B8'))
        tv.bind('<<TreeviewSelect>>', self._on_linked_select)
        tv.bind('<Double-1>', self._on_linked_open)
        self._link_tv = tv
        self._peri_tv = tv   # 옛 이름 호환(외부 하네스·점프)

        # 아래: 머리줄(제목 + ±5) + 본문·설명문 한 Text
        right = tk.Frame(h_pw, bg=_C('bg', 'white'))
        h_pw.add(right)
        hdr = tk.Frame(right, bg=_C('panel', '#F8F9FA'))
        hdr.pack(fill='x')
        self._verse_title_lbl = tk.Label(
            hdr, text=i18n.t('EB_LINK_HINT', '목록에서 줄을 선택하세요'),
            bg=_C('panel', '#F8F9FA'), fg=_C('fg_title', '#2C3E50'),
            font=('', 9, 'bold'), anchor='w')
        self._verse_title_lbl.pack(side='left', padx=10, pady=4)
        # ★ [문맥 ±5] **토글 하나**(2026-09-15 항목 ③) — 옛 [+5][−5] 둘은
        #   본문 자체를 늘려 **설명문 아래에 본문이 또** 보였다. 이제 위 칸은
        #   고른 절만, 문맥은 누를 때만 **아래에 따로** 펼친다(다시 누르면 접힘).
        #   ⚠ 옛 이름 둘(`_expand_verse_btn`·`_shrink_verse_btn`)은 같은 단추를
        #     가리킨다 — 밖에서 state 를 만지던 자리가 살아 있다.
        self._ctx_btn = tk.Button(
            hdr, text=i18n.t('EB_CTX5', '문맥 ±5'), command=self._toggle_ctx,
            bd=1, padx=8, pady=2, cursor='hand2', state='disabled')
        _tfr(self._ctx_btn, self.db_path, 'ui')
        self._ctx_btn.pack(side='right', padx=(3, 6), pady=4)
        self._expand_verse_btn = self._ctx_btn
        self._shrink_verse_btn = self._ctx_btn
        self._ctx_on = False
        self._paint_ctx_btn(enabled=False)

        verse_f = tk.Frame(right, bg=_C('bg', 'white'))
        verse_f.pack(fill='both', expand=True)
        verse_vsb = ttk.Scrollbar(verse_f, orient='vertical')
        verse_vsb.pack(side='right', fill='y')
        self._verse_txt = tk.Text(verse_f, wrap='word', relief='flat',
                                   bg=_C('bg', '#FFFEF8'),
                                   yscrollcommand=verse_vsb.set,
                                   state='disabled', cursor='arrow',
                                   padx=14, pady=10, spacing1=3, spacing2=1)
        verse_vsb.config(command=self._verse_txt.yview)
        self._verse_txt.pack(fill='both', expand=True)
        _tfr(self._verse_txt, self.db_path, 'bible')   # 성경 구절 (§36)
        # ★ 표준서식 (2026-09-01 0.txt 7번) — 태그 크기를 박지 않고 설정
        #   글꼴(bible 구역) 크기에서 끌어온다. 본문(body·epdesc)은 글꼴을 아예
        #   안 적어 위젯 등록 글꼴을 그대로 따른다(§36).
        try:
            import theme_font as _thf
            _bsz = int(_thf.resolve(self.db_path, 'bible')['size'])
        except Exception:
            _bsz = 10
        self._verse_txt.tag_configure('ref',  foreground=_C('fg_title', '#1A5276'),
                                       font=('', max(8, _bsz - 1), 'bold'))
        self._verse_txt.tag_configure('body', foreground=_C('fg', '#2C3E50'))
        self._verse_txt.tag_configure('role',       foreground=_C('accent', '#7D3C98'),
                                       font=('', max(7, _bsz - 2), 'bold'))
        self._verse_txt.tag_configure('peri_title', foreground=_C('success', '#117A65'),
                                       font=('', max(8, _bsz - 1), 'bold'))
        self._verse_txt.tag_configure('epdesc',     foreground=_C('fg_title', '#4A235A'))
        self._verse_txt.tag_configure('empty',      foreground=_C('fg_dim', '#AAAAAA'),
                                       font=('', max(7, _bsz - 2)))
        # ★ 문맥 블록(2026-09-15) — 머리 한 줄 + 고른 절은 바탕색으로 가른다
        self._verse_txt.tag_configure('ctx_head',   foreground=_C('fg_dim', '#7F8C8D'),
                                       font=('', max(7, _bsz - 2), 'bold'))
        self._verse_txt.tag_configure('anchor',     background=_C('accent_bg', '#EAF2F8'))

        # 상태 — 오른쪽 렌더의 단일 소스
        self._peri_rows = []
        self._lex_rows = {}          # iid -> verse_id
        self._lex_notes = {}         # iid -> (구절 표기, 연결설명문)
        self._lex_all = False
        self._right_desc = None      # (머리 라벨, 본문) — ±5 재렌더 때 유지
        self._right_anchor = None    # (sv, ev) — 앵커 원 범위(−5 되돌리기 바닥)

    # ── 공개 API ─────────────────────────────────────────────────────────────

    #: 의미연결 갈래 단추의 코드 — 사전 코드와 안 겹치는 이름
    LINK_SRC = 'LINKDESC'

    def load_entity(self, entity_id: int, _retry: int = 0, from_vid=None):
        """`from_vid` — **어느 절에서 눌러 들어왔나**(2026-09-01 사용자 지시).

        ★★★ 왜 필요한가 — 의미연결은 **본문에 그 낱말이 없다.** 그래서 사용자는
          「왜 이게 연결됐지?」로 읽는다. 그 오해를 푸는 것이 연결설명문이므로
          **도착하자마자 보여야** 한다. 그러려면 화면이 「검색으로 왔는지 절에서
          왔는지」를 알아야 하는데, 지금까지는 알 길이 없었다.
        ⚠ **다른 용어를 고르면 지운다** — 안 지우면 엉뚱한 용어에 그 절의
          설명문이 붙는다(`_set_entity_from` 이 그 일을 한다).
        """
        """외부 진입점: 가계도·발자취·연구자료 → 그 항목을 연다.

        ⚠ **목록은 탭을 처음 열 때 `after(100)` 로 채워진다**(§29 지연 로드).
          갓 지은 탭으로 곧장 점프하면 그 순간 목록이 비어 있어, 프로필은
          열리지만 **왼쪽 목록에서 그 줄이 선택되지 않는다**(실측 — 같은 코드가
          두 번째 실행에서는 선택됐다. 순전히 시간 문제였다).
        ⇒ 목록이 아직 비었으면 잠깐 뒤 한 번 더 시도한다(최대 3회, 멱등)."""
        # ★ 출발지를 먼저 담는다 — 아래 렌더가 이 값을 본다.
        self._from_vid = from_vid
        self._retry_from = from_vid          # 재시도 때도 잃지 않는다
        self._current_strong = None          # 용어를 열면 낱말 상태는 끝
        if not self._compact:
            self._build_type_options()
            iid = str(entity_id)
            if self._list_tv.exists(iid):
                self._list_tv.see(iid)
                # ★ 빗장 — 이 선택은 우리가 맞춘 것이지 사용자가 고른 것이 아니다.
                self._sel_sync = True
                try:
                    self._list_tv.selection_set(iid)
                finally:
                    # 큐에 들어간 이벤트가 돈 **뒤에** 내린다(순서로는 못 막는다).
                    self.after_idle(lambda: setattr(self, '_sel_sync', False))
                return
            if _retry < 3 and not self._list_tv.get_children():
                self.after(200, lambda e=entity_id, r=_retry + 1,
                           v=from_vid: self.load_entity(e, r, v))
        # compact 모드 또는 list에 없는 경우 — 직접 프로파일 로드
        self._breadcrumb = [entity_id]
        self._load_entity_profile(entity_id)
        if not self._compact:
            self._update_breadcrumb()
        # compact 헤더 제목 갱신
        if self._compact:
            try:
                with appdb.connect(self.db_path) as conn:
                    lang = self.lang_getter() or 'KO'
                    row = conn.execute(
                        "SELECT em.entity_code, "
                        " (SELECT contents FROM sys_text_asset ta "
                        "   WHERE ta.clicked_id=em.entity_id "
                        "     AND ta.text_type='ENTITY_NAME' "
                        "     AND ta.lang_code=? AND ta.record_status='LIVE' LIMIT 1) AS nm_lang, "
                        " (SELECT contents FROM sys_text_asset ta "
                        "   WHERE ta.clicked_id=em.entity_id "
                        "     AND ta.text_type='ENTITY_NAME' "
                        "     AND ta.lang_code='EN' AND ta.record_status='LIVE' LIMIT 1) AS nm_en, "
                        " (SELECT contents FROM sys_text_asset ta "
                        "   WHERE ta.clicked_id=em.entity_id "
                        "     AND ta.text_type='ENTITY_NAME' "
                        "     AND ta.lang_code='KO' AND ta.record_status='LIVE' LIMIT 1) AS nm_ko "
                        "  FROM sys_entity_master em WHERE em.entity_id=?",
                        (lang, entity_id)).fetchone()
                if row:
                    nm = row[1] or row[2] or row[3] or row[0]
                    self._compact_title_lbl.config(text=nm)
            except Exception:
                pass

    def _handle_close(self):
        """compact 헤더 X 클릭 — 외부 콜백에 위임 (PanedWindow.forget 등)."""
        if self._on_close:
            try:
                self._on_close()
            except Exception as e:
                print(f'[entity_browser close] {e}')

    # ── 내부: 데이터 ─────────────────────────────────────────────────────────

    def _load_all_entities(self):
        try:
            with appdb.connect(self.db_path) as conn:
                lang = self.lang_getter()
                rows = conn.execute(
                    "SELECT em.entity_id, em.entity_code, em.entity_type, em.importance, "
                    "  (SELECT ta.contents FROM sys_text_asset ta "
                    "   WHERE ta.text_type='ENTITY_NAME' AND ta.clicked_id=em.entity_id "
                    "   AND ta.lang_code=? AND ta.record_status='LIVE' LIMIT 1) AS name_lang, "
                    "  (SELECT ta.contents FROM sys_text_asset ta "
                    "   WHERE ta.text_type='ENTITY_NAME' AND ta.clicked_id=em.entity_id "
                    "   AND ta.lang_code='EN' AND ta.record_status='LIVE' LIMIT 1) AS name_en, "
                    "  (SELECT ta.contents FROM sys_text_asset ta "
                    "   WHERE ta.text_type='ENTITY_NAME' AND ta.clicked_id=em.entity_id "
                    "   AND ta.lang_code='KO' AND ta.record_status='LIVE' LIMIT 1) AS name_ko, "
                    # ★ 시대 (2026-09-01 아이디어 ②) — 인물의 time_context.
                    #   칸이 이미 있어(§12-2) 배선만 한다.
                    "  (SELECT sp.time_context FROM sys_person sp "
                    "   WHERE sp.person_id=em.entity_id) AS tctx, "
                    # ★ 지역 (2026-09-02 0.txt 8번 집행) — PLACE 의 json_detail
                    #   .region_code. 코드표 = db_region_code(12지역 106곳 실측).
                    "  em.json_detail "
                    "FROM sys_entity_master em "
                    "WHERE em.record_status='LIVE' "
                    "ORDER BY COALESCE(name_lang, name_en, name_ko, em.entity_code) "
                    "         COLLATE NOCASE ASC",
                    (lang,)
                ).fetchall()
        except Exception as e:
            print(f"[EntityBrowser] _load_all_entities error: {e}")
            return

        # ★ 덮개 (2026-08-26 읽기 배선) — 사용자가 가린 엔티티는 목록에서 뺀다.
        #   되돌리기 = 설정 ▸ 휴지통(가림 해제). 열쇠는 entity_code(자연 열쇠).
        _hidden = set()
        try:
            import db_tag_system as _T
            with appdb.connect(self.db_path) as conn:
                _hidden = _T.user_hidden_entity_codes(conn)
        except Exception:
            pass

        self._all_entities = []
        for eid, code, etype, imp, name_lang, name_en, name_ko, tctx, jd in rows:
            if code in _hidden:
                continue
            # ★ 기계 낱말(subtype LEX) 표식 — 훑기 목록에서는 빠지고
            #   검색어가 있을 때만 회색으로 나온다(2026-09-02 사용자 확정).
            _lex = bool(jd and '"subtype": "LEX"' in jd)
            name = name_lang or name_en or name_ko or code
            _era = None
            try:
                import db_era_code as _EC
                _era = _EC.person_era(tctx)
            except Exception:
                pass
            _reg = None
            if etype == 'PLACE':
                try:
                    import json as _json
                    _reg = _json.loads(jd or '{}').get('region_code')
                except Exception:
                    pass
            # ★ 용어 축 (2026-09-07) — `json_detail.axis`
            _ax = None
            if etype == 'TERM':
                try:
                    import json as _json2
                    _ax = (_json2.loads(jd or '{}') or {}).get('axis')
                except Exception:
                    pass
            self._all_entities.append(dict(
                entity_id=eid, entity_code=code, entity_type=etype,
                importance=imp, name=name, era=_era, region=_reg, lex=_lex,
                axis=_ax,
            ))
        # ★★★ **내 용어를 같은 목록에 붙인다**(2026-09-18 사용자 「관리자가
        #   만든 심리/국면 용어를 사용자도 사용하고 사용자가 추가할 수도 있어야
        #   한다 · 모든 기능은 오버레이 방식」).
        #   ⚠ 번호 공간이 다르다 — `entity_id` 는 **None** 이고 줄 열쇠는
        #     `u_<번호>` 다(§240차 「한 이름이 두 표를 가리키면 안 된다」).
        try:
            import overlay_read as _or_my
            with appdb.connect(self.db_path) as conn:
                for tid, nm, tc in _or_my.my_terms(conn, lang):
                    self._all_entities.append(dict(
                        entity_id=None, user_tag_id=tid, entity_code='u%d' % tid,
                        entity_type=tc, importance=5, name=nm,
                        era=None, region=None, lex=False, axis=None, mine=True))
            self._all_entities.sort(key=lambda e: (e.get('name') or '').lower())
        except Exception as e:
            print('[EntityBrowser] my_terms: %s' % e)
        self._build_type_options()
        self._populate_list()

    def _search_kin(self, q, lang):
        """검색어와 **같은 것**인 항목들 — `overlay_read` 한 문에 맡긴다.

        ⚠ 여기서 다시 짜지 말 것 — 검색 경로가 둘이라(이 목록 · 총괄 창)
          갈리면 같은 낱말이 화면마다 다른 자리에 선다(§176차 그 자리).
        ⚠ (검색어, 언어)로 캐시한다 — 글자를 칠 때마다 도는 자리다.
        """
        key = (q, lang)
        if getattr(self, '_kin_cache', (None,))[0] == key:
            return self._kin_cache[1]
        kin = set()
        try:
            import overlay_read as _or_k
            with appdb.connect(self.db_path) as conn:
                kin = _or_k.search_kin(conn, q, lang)
        except Exception as e:
            print('[EntityBrowser] _search_kin: %s' % e)
        self._kin_cache = (key, kin)
        return kin

    def _populate_list(self):
        self._list_tv.delete(*self._list_tv.get_children())
        filtered = [e for e in self._all_entities
                    if self._type_filter is None or e['entity_type'] == self._type_filter]
        # ★ 시대 거르기 — 인물 유형에서만 콤보가 보이므로 그때만 값이 있다
        _ec = self._era_filter_code() if self._type_filter == 'PERSON' else ''
        if _ec:
            filtered = [e for e in filtered if e.get('era') == _ec]
        # ★ 지역 거르기 — 장소 유형에서만 (2026-09-02 0.txt 8번)
        _rc = self._region_filter_code() if self._type_filter == 'PLACE' else ''
        if _rc:
            filtered = [e for e in filtered if e.get('region') == _rc]
        # ★ 축 거르기 — 용어 유형에서만 (2026-09-07)
        #   ⚠ 「축 없음」을 고를 수는 없다 — 축은 훑어보기의 도구이지 자격
        #     심사가 아니다(축이 없어도 목록에 남는다).
        _ax = self._axis_filter_code() if self._type_filter == 'TERM' else ''
        if _ax:
            filtered = [e for e in filtered if e.get('axis') == _ax]

        # 검색 — 이름 + 별명(2026-08-12). 별명은 `json_detail.aliases.{lang}` 에 있고
        # `entity_aliases.matches_query` 가 같은 언어끼리 맞춰 준다(§12-5).
        q = ''
        if self._q_var is not None:
            try:
                q = (self._q_var.get() or '').strip()
            except Exception:
                pass
        if q:
            lang = (self.lang_getter() or 'KO').upper()
            ql = q.lower()
            hit = []
            for e in filtered:
                if ql in (e.get('name') or '').lower():
                    hit.append(e); continue
                if e.get('entity_id') and self._alias_hit(e['entity_id'],
                                                          q, lang):
                    hit.append(e)
            filtered = hit
        else:
            # ★ 빈 검색 = 훑기 — 기계 낱말(LEX 1.1만)은 안 싣는다 (2026-09-02
            #   사용자 확정 「수백 개 묶음은 분류가 의미 없다」). 검색·연결·
            #   의미장으로는 그대로 닿고, 검색어가 있으면 회색으로 나온다.
            filtered = [e for e in filtered if not e.get('lex')]

        if self._cnt_lbl is not None:
            self._cnt_lbl.config(
                text=i18n.t('EB_COUNT_N', '{n}개').format(n=len(filtered)))

        # [2026-06-04] "전체" 선택 시 유형별 섹션 헤더 제거 — 다국어 알파벳 순으로만 표시
        # 낱말(LEX)은 회색 — 그릴 때마다 역할색 재적용(§36-5b)
        self._list_tv.tag_configure('lexword', foreground=_C('fg_dim', '#95A5A6'))
        # ★★★ **검색하면 「그 낱말과 무슨 사이인가」로 묶는다**
        #   (2026-09-07 사용자 지적 「하나님을 검색하면 하나님이 표시되기
        #   이전에 먼저 거룩, 사랑 등이 먼저 표시된다」 + 확정 「④」).
        #   ⚠⚠ 실패의 뿌리는 **별명으로 걸린 것과 그 낱말 자체를 같은 층으로
        #     본 것**이다(사용자 교정). 전능자·샤다이는 별명으로 걸리지만
        #     **그 자체가 하나님의 이름**이라 거룩과 같은 칸이면 안 된다.
        #   ⚠ 묶음이 **하나뿐이면 머리를 안 그린다**(§0-1 빈 서랍) —
        #     실측 20낱말 중 둘 이상인 것은 11.
        #   ⚠ 묶음 머리는 `_h_` 접두라 `_on_list_select` 가 이미 지나친다.
        groups = None
        if q:
            import overlay_read as _or_sg
            kin = self._search_kin(q, lang)
            groups = {}
            for e in filtered:
                groups.setdefault(
                    _or_sg.search_group(q, e.get('name') or '',
                                        e['entity_id'], kin), []).append(e)
            if len(groups) < 2:
                groups = None
            else:
                # ⚠ **묶음 안에서도 그 낱말 자체가 형제보다 앞이다** — 안 그러면
                #   1군 안에서 「하나님」이 전능자·지존자 뒤 3위가 된다(실측).
                for g in groups:
                    groups[g].sort(
                        key=lambda x: (0 if q in _or_sg.name_parts(
                            x.get('name') or '') else 1, x.get('name') or ''))

        def _put(e, parent=''):
            tag = _TYPE_TAG.get(e['entity_type'], 'normal')
            tags = (tag, 'lexword') if e.get('lex') else (tag,)
            if e.get('mine'):
                # ⚠ 내 것임을 **글로** 알린다 — 색만으로는 못 가른다
                self._list_tv.insert(parent, 'end',
                                     iid='u_%d' % e['user_tag_id'],
                                     text='%s  [내]' % e['name'], tags=tags)
                return
            self._list_tv.insert(parent, 'end', iid=str(e['entity_id']),
                                 text=e['name'], tags=tags)

        if groups:
            for g in sorted(groups):
                gid = '_h_g%d' % g
                self._list_tv.insert(
                    '', 'end', iid=gid, tags=('cat',), open=True,
                    text='%s (%d)' % (_SEARCH_GROUP_NAME(g, q), len(groups[g])))
                for e in groups[g]:
                    _put(e, gid)
        else:
            for e in filtered:
                _put(e)

    def _load_entity_profile(self, entity_id: int):
        import json as _json
        self._current_eid = entity_id
        try:
            with appdb.connect(self.db_path) as conn:
                # ★ 표시 언어는 **설명 탭의 콤보 하나**가 정한다(0.txt 2-3).
                #   콤보가 없는 compact 모드에서만 앱 언어를 따른다.
                lang = self._desc_lang()
                row = conn.execute(
                    "SELECT em.entity_type, em.year_start, em.year_end, em.json_detail "
                    "FROM sys_entity_master em "
                    "WHERE em.entity_id=? AND em.record_status='LIVE'",
                    (entity_id,)
                ).fetchone()
                if not row:
                    return
                etype, ys, ye, json_raw = row
                jd = {}
                if json_raw:
                    try:
                        jd = _json.loads(json_raw)
                    except Exception:
                        pass

                name = (self._get_text(conn, entity_id, 'ENTITY_NAME', lang)
                        or self._get_text(conn, entity_id, 'ENTITY_NAME', 'EN')
                        or self._get_text(conn, entity_id, 'ENTITY_NAME', 'KO')
                        or str(entity_id))
                # ★ 덮개(내 설명)를 먼저 본다. **가리면 폴백을 멈춘다** —
                #   안 그러면 가린 글이 영어로 되살아난다(§88차 사고).
                desc, self._desc_hidden = self._desc_with_overlay(
                    conn, entity_id, lang)
                if not desc:
                    desc = i18n.t('EB_DESC_HIDDEN', '(내가 가린 설명입니다)') \
                        if self._desc_hidden \
                        else i18n.t('EB_NO_DESC', '(설명문 없음)')

                person_ext = None
                if etype == 'PERSON':
                    pr = conn.execute(
                        "SELECT tribe_code, role_primary, time_context, gender "
                        "FROM sys_person WHERE person_id=?", (entity_id,)
                    ).fetchone()
                    if pr:
                        person_ext = dict(tribe=pr[0], role=pr[1],
                                          time=pr[2], gender=pr[3])

                # IDOL related_idols → KO 이름 resolve
                idol_related_lines = []
                if etype == 'IDOL' and jd.get('related_idols'):
                    _REL_KO = {'CONSORT': '배우자/모신', 'SAME_DEITY': '동일신격',
                                'PANTHEON': '파생신', 'SYNCRETISM': '혼합숭배'}
                    for ri in jd['related_idols']:
                        rcode = ri.get('code', '')
                        _rc   = ri.get('relation', '')
                        rrel  = (i18n.t('ENTITY_IDOLREL2_' + str(_rc), _REL_KO[_rc])
                                 if _rc in _REL_KO else _rc)
                        rnote = ri.get('note', '')
                        rname_row = conn.execute(
                            "SELECT ta.contents FROM sys_text_asset ta "
                            "JOIN sys_entity_master em ON em.entity_id=ta.clicked_id "
                            "WHERE em.entity_code=? AND ta.text_type='ENTITY_NAME' "
                            "AND ta.lang_code='KO' AND ta.record_status='LIVE' LIMIT 1",
                            (rcode,)
                        ).fetchone()
                        rname = rname_row[0] if rname_row else rcode
                        idol_related_lines.append(f"  • {rname} ({rrel}) — {rnote}")
        except Exception as e:
            print(f"[EntityBrowser] _load_entity_profile error: {e}")
            return

        # 헤더 — 이름·유형 표시 위젯은 걷었다(2026-08-26). 가드로 견딘다.
        type_ko = _TYPE_KO.get(etype, etype)
        if self._name_lbl is not None:
            self._name_lbl.config(text=name)
        if self._type_chip is not None:
            self._type_chip.config(text=f' {type_ko} ')

        # 메타
        meta = []
        if ys is not None:
            ys_s = f"BC {-ys}" if ys < 0 else f"AD {ys}"
            ye_s = ''
            if ye is not None:
                ye_v = f"BC {-ye}" if ye < 0 else f"AD {ye}"
                ye_s = f" ~ {ye_v}"
            meta.append(f"{i18n.t('ENTITY_ATTR_YEAR','연대')}: {ys_s}{ye_s}")
        if person_ext:
            t = person_ext['tribe']
            if t and t not in ('UNKNOWN', 'NT_NONE', None):
                meta.append(f"{i18n.t('ENTITY_ATTR_TRIBE','지파')}: {t}")
            r = person_ext['role']
            if r:
                meta.append(f"{i18n.t('ENTITY_ATTR_ROLE','역할')}: "
                            f"{i18n.t('ENTITY_ROLE_'+r, _ROLE_PRI_KO.get(r, r))}")
            c = person_ext['time']
            if c:
                meta.append(f"{i18n.t('ENTITY_ATTR_TIME','시대')}: "
                            f"{i18n.t('ENTITY_TIME_'+c, _TIME_KO.get(c, c))}")
        _IDOL_TYPE_KO = {
            'FOREIGN_DEITY':  '이방 신 (외래)',
            'SELF_MADE':      '자체 제작 우상',
            'OBJECT_DEIFIED': '신격화된 사물',
            'ABSTRACT':       '추상적 우상',
            'DEIFIED_HUMAN':  '신격화된 인간',
        }
        # json_detail attr 값 해석: 중첩 다국어({lang:val})→lang/KO/EN 폴백, flat 문자열→그대로
        def _av(key):
            v = jd.get(key)
            if isinstance(v, dict):
                return v.get(lang) or v.get('EN') or v.get('KO') or next(iter(v.values()), '')
            return v if isinstance(v, str) else ('' if v is None else str(v))
        if etype == 'PLACE':
            if _av('modern_name'):
                meta.append(f"{i18n.t('ENTITY_ATTR_MODERN_NAME','현대명')}: {_av('modern_name')}")
            if _av('heb_name'):
                meta.append(f"{i18n.t('ENTITY_ATTR_HEB_NAME','히브리어')}: {_av('heb_name')}")
            if _av('region'):
                meta.append(f"{i18n.t('ENTITY_ATTR_REGION','지역')}: {_av('region')}")
        elif etype == 'IDOL':
            # 서술 attr(worship_category 등)은 ENTITY_DESC로 이전됨 — 코드(idol_type)만 표시
            if _av('idol_type'):
                _it = _av('idol_type')
                meta.append(i18n.t('ENTITY_IDOL_TYPE_'+_it, _IDOL_TYPE_KO.get(_it, _it)))
        # ⚠⚠ **원어 앵커 줄을 본문 meta 에서 걷었다**(2026-09-17 · 1.txt 1-4) —
        #   이제 **용어사전 줄의 이름 오른쪽**에 있다(`_paint_dict_lex`).
        #   두 자리에 두면 같은 말이 두 번이고 본문 줄을 하나 먹는다
        #   (사용자 「본문 표시공간을 한줄이라도 더 늘려야 한다」).
        # ★★★ **이름에 담긴 고백** (2026-09-07 · 1.txt 제안 A).
        #   추상적인 형용사·동사가 성경 안에서 **사람·땅의 이름으로 서 있다**:
        #     다윗 = 사랑받는 자 · 노아 = 안식 · 벧엘 = 하나님의 집
        #   ⚠ **맨 앞에 둔다**(원어 코드보다도 앞) — 이 한 줄이 그 인물·장소를
        #     읽는 첫 문이 된다. 원어 코드는 조회용이고 이것은 **뜻**이다.
        #   ⚠ 없으면 아무것도 안 그린다(§0-1 빈 서랍 금지) — 실측 111/287.
        try:
            import db_name_meaning as _NM
            with appdb.connect(self.db_path) as _c3:
                _mean, _st = _NM.get_meaning(_c3, entity_id, lang)
            if _mean:
                meta.insert(0, '%s: %s' % (
                    i18n.t('ENTITY_ATTR_NAMEMEAN', '이름의 뜻'), _mean))
        except Exception as _e:
            print('[entity name-meaning]', _e)
        # ★ 소속 (2026-09-02 UI 점검 ② — 인물 화면에 역방향이 없었다).
        #   민족·그룹의 MEMBER 행을 인물 쪽에서 뒤집어 읽는다. MEMBER 만 —
        #   조상(FOUNDER)·궁정(COURT)·보냄 받은 선지자(PROPHET_TO)를 「소속」
        #   이라 부르면 거짓이 된다(다니엘은 바벨론 소속이 아니다).
        try:
            import entity_relation as _ER
            import entity_overlay as _EO2
            with appdb.connect(self.db_path) as _c2:
                _grp = [
                    (_EO2.entity_head(_c2, r[0], lang) or (None,))[0]
                    for r in _c2.execute(
                        "SELECT clicked_id FROM %s WHERE link_type='ENTI_ENTI'"
                        " AND rel_code='MEMBER' AND target_id=?"
                        " AND COALESCE(record_status,'LIVE')='LIVE'"
                        % _ER.TBL, (entity_id,)).fetchall()]
            _grp = [g for g in _grp if g]
            if _grp:
                meta.append('%s: %s' % (
                    i18n.t('ENTITY_ATTR_BELONG', '소속'), ' · '.join(_grp)))
        except Exception as _e:
            print('[entity belong]', _e)
        # ★ 비면 줄과 구분선을 함께 걷는다 (2026-09-02 UI 점검 ① — 사물·제도·
        #   절기 등 원어·연대 없는 유형에서 빈 라벨이 세로 공간만 차지했다)
        # ⚠ **비어도 자리를 지킨다**(2026-09-17 사용자 ④) — 걷으면 용어를
        #   고를 때마다 본문이 오르내린다. 글자만 지운다.
        self._meta_lbl.config(text='  |  '.join(meta) if meta else '')

        # 설명문 — IDOL은 상세 정보를 desc_txt 맨 위에 먼저 표시
        if etype == 'IDOL' and jd:
            detail_lines = []
            # entry_path·prophet_warning·judgment_result·ot_nt_link 는 ENTITY_DESC로 이전됨(서술 텍스트)
            if idol_related_lines:
                detail_lines.append(i18n.t('ENTITY_ATTR_RELATED_IDOLS', '연관 우상') + ':')
                detail_lines.extend(idol_related_lines)
            detail_block = '\n'.join(detail_lines)
            if desc and desc != i18n.t('EB_NO_DESC', '(설명문 없음)'):
                full_desc = detail_block + '\n\n' + desc if detail_block else desc
            else:
                full_desc = detail_block or desc
        else:
            full_desc = desc
        # ★ **담아 둔다** — 「그 절과의 연결」 갈래가 이 칸을 잠시 빌려 쓰므로
        #   돌아올 때 되채울 글이 필요하다(2026-09-01 사용자 신고
        #   「설명 버튼을 눌러도 안된다」 — 덮어쓰고 되돌리는 길을 안 만들었다).
        self._desc_body = full_desc
        self._fill(self._desc_txt, full_desc)
        self._load_compare(entity_id)

        # 인물 전용 버튼 표시 여부
        if etype == 'PERSON':
            self._person_btn_f.pack(fill='x', pady=(0, 4))
        else:
            self._person_btn_f.pack_forget()

        # 찬양 (곡 → 판 → 영상)
        self._load_songs(entity_id)
        # 외부 링크 로드
        self._load_media_urls(entity_id)
        # [관] 엔티티 연결 참고자료 로드
        self._load_entity_refs(entity_id)

        # 사전 항목 로드 (표시 언어 목록은 고정이라 여기서 다시 만들지 않는다)
        self._load_dict_entries(entity_id)
        # [Phase 2-G Step 4] 외부 사전 사이트 버튼 로드
        self._load_external_sites(entity_id)
        self._load_strong_sites(entity_id)     # ★ 원어사전 Direct Link

        # 연결구절 로드 (단락 + 낱말 — 한 목록)
        self._load_linked(entity_id)
        # 연구(내부자료 글) 서브탭 — 걸린 글 있으면 활성, 없으면 비활성
        self._load_study_entries(entity_id)
        # 용어(TERM)에는 없는 서브탭을 닫는다 — 사전은 인명·지명 표제어뿐이다.
        # ⚠ 연결구절 탭은 TERM 에서도 산다(낱말 구절이 TERM 의 중심 화면).
        self._gate_subtabs_for_type(etype)

    #: ⚠ **비었다** — 유형으로 막던 유일한 자리가 「여정」이었고 그 탭을
    #:   걷었다(2026-09-17). 표는 남긴다 — 다시 생기면 여기 한 줄이다.
    _TYPE_HIDE_TABS = {}
    _SELF_MANAGED_TABS = ()          # 옛 이름 — 이제 규칙이 하나다

    # ★★★ **주요용어 서브탭 — 필수 둘 · 선택 다섯**(2026-09-17 사용자 확정
    #   「필수=용어사전+용례구절, 선택=나머지, 여정=삭제」).
    #   열쇠·차례는 `p2_tab_settings.SCREENS['EB_MAIN_TABS']` 와 **같은 글자**다.
    _EB_CFG = 'EB_MAIN_TABS'
    _EB_ORDER = ('DICT', 'LINK', 'VIDEO', 'TEXT', 'STUDY', 'NAV', 'SONG')
    _EB_IDX = {'DICT': '_dict_subtab_index', 'LINK': '_link_subtab_index',
               'VIDEO': '_url_subtab_index', 'TEXT': '_txt_subtab_index',
               'STUDY': '_study_subtab_index', 'NAV': '_nav_subtab_index',
               'SONG': '_song_subtab_index'}
    _EB_LABEL = {'DICT': ('TAB_TERMDICT', '용어사전'),
                 'LINK': ('TAB_ENTITY_LINKVERSE', '용례구절'),
                 'VIDEO': ('EB_BR_VIDEO', '영상링크'),
                 'TEXT': ('EB_BR_TEXT', '텍스트링크'),
                 'STUDY': ('TAB_RESEARCH', '연구자료'),
                 'NAV': ('REFR_SCOPE_NAV', '내부연결'),
                 'SONG': ('TAB_SONG', '찬양')}

    def _gate_subtabs_for_type(self, etype):
        """유형에 없는 서브탭을 닫는다 — 지금은 **닫을 것이 없다**(여정 삭제).

        상태 판정은 전부 `_apply_tab_prefs` 하나로 모았다(2026-09-17).
        """
        self._apply_tab_prefs()

    def _set_tab_n(self, key, n):
        """그 갈래의 개수를 적어 두고 **규칙 하나**를 다시 돌린다.

        ⚠ 라벨·잠금·감춤·더보기를 각 로더가 따로 쓰면 **규칙이 다섯 벌**이 된다 —
          그것이 사용자가 짚은 「일관성이 맞는가」의 정체였다(2026-09-17).
        """
        if not hasattr(self, '_tab_n'):
            self._tab_n = {}
        self._tab_n[key] = n
        self._apply_tab_prefs()

    def _apply_tab_prefs(self):
        """판정을 **유휴 때 한 번**으로 모은다(2026-09-17).

        ⚠ 한 용어를 열면 개수를 적는 문이 다섯 번 불린다 — 그때마다 다 그리면
          용어 41(영상 2,369편)에서 눈에 띄게 멎는다(「안 바뀐다」로 보인다).
        """
        if getattr(self, '_prefs_job', None):
            return
        try:
            self._prefs_job = self.after_idle(self._apply_tab_prefs_now)
        except Exception:
            self._prefs_job = None
            self._apply_tab_prefs_now()

    def _apply_tab_prefs_now(self):
        """서브탭의 이름·개수·잠금·감춤·더보기 — **판정은 여기 하나.**

        규칙(사용자 확정 2026-09-17)
          · **필수 둘**(용어사전·용례구절)은 언제나 보이고 잠기지 않는다.
          · **선택 다섯**은 ⓐ 안 고른 것 → 「더보기」 한 목록 ⓑ 고른 것은 제 탭 ·
            **0건이면 잠근다**(다섯에 똑같이 — 옛날에는 셋만 잠갔다) ·
            「목록이 없는 갈래는 감추기」를 켜면 아예 뺀다.
          · 표시방식 **통합탭**이면 다섯을 **전부** 더보기로 모은다.
          · 「더보기」에는 **안에 든 것의 합**을 적는다(사용자 「더보기(#)」).
        ⚠ 압축판(가계도 슬라이드)은 설정을 안 따른다 — 칸이 좁아 탭이 애초에 적다.
        """
        self._prefs_job = None
        nb = getattr(self, '_center_nb', None)
        if nb is None:
            return
        try:
            import p2_tab_settings as TS
            hideable = TS.hideable_of(self._EB_CFG)
            fixed = TS.fixed_of(self._EB_CFG)
            if self._compact:
                # ⚠ 압축판은 **설정을 안 따른다**(칸이 좁고 들어온 길이 다르다) —
                #   그래도 이름·개수·0건 잠금은 그대로 돈다(기본값으로 판정).
                main, one, hide = set(self._EB_ORDER), False, False
            else:
                # ⚠ 기본값을 여기 또 적지 않는다 — 표는 `p2_tab_settings` 다
                _d = next(d for k, _o, d, _i, _l in TS.SCREENS
                          if k == self._EB_CFG)
                main = set(TS.read_main(self.db_path, self._EB_CFG,
                                        self._EB_ORDER, _d))
                # ★ 통합탭이면 **체크와 상관없이** 선택 다섯을 전부 더보기로
                one = TS.read_more(self.db_path,
                                   TS.MORE_KEY[self._EB_CFG]) == 'ONE'
                hide = TS.read_hide_empty(self.db_path,
                                          TS.HIDE_EMPTY_KEY[self._EB_CFG])
            # ★ 더보기 **안이 어떻게 보이나**도 이 값이 정한다 — `_fill_more`
            #   가 다시 읽으면 판정이 두 곳이 되어 갈린다.
            self._more_one = bool(one)
        except Exception as e:
            print('[EntityBrowser] 탭 설정: %s' % e)
            return
        cnt = getattr(self, '_tab_n', {}) or {}
        more_keys, more_n = [], 0
        for k in self._EB_ORDER:
            idx = getattr(self, self._EB_IDX[k], None)
            if idx is None:
                continue
            n = cnt.get(k)
            nm = i18n.t(*self._EB_LABEL[k])
            try:
                if k in fixed:
                    # ★ 필수 — 0건이어도 **잠그지 않는다**(사용자 「필수」의 뜻)
                    nb.tab(idx, state='normal',
                           text=nm if n is None else '%s (%d)' % (nm, n))
                    continue
                base = False if one else (k in main)
                if not TS.visible_with(k, n, base, hide, hideable, ()):
                    nb.tab(idx, state='hidden')
                    if n:                      # 감춰서 사라진 것은 안 센다
                        more_keys.append(k)
                        more_n += int(n)
                    continue
                nb.tab(idx, text='%s (%d)' % (nm, n or 0),
                       state=('normal' if n else 'disabled'))
            except Exception as e:
                print('[EntityBrowser] 탭 %s: %s' % (k, e))
        self._paint_more_tab(more_keys, more_n)

    def _paint_more_tab(self, keys, n):
        """「더보기(N)」 — 담을 것이 없으면 **탭째 사라진다**(§0-1)."""
        idx = getattr(self, '_more_subtab_index', None)
        nb = getattr(self, '_center_nb', None)
        if idx is None or nb is None:
            return
        try:
            if not keys:
                nb.tab(idx, state='hidden')
                return
            nb.tab(idx, state='normal',
                   text='%s (%d)' % (i18n.t('P2T_MORE', '더보기'), n))
        except Exception:
            return
        # ★ 목록은 **그 탭을 열 때** 채운다(§29 지연) — 용어 41 은 2,369줄이라
        #   미리 그리면 용어를 여는 동안 화면이 멎는다. 라벨의 수는 이미 있다.
        self._more_keys = tuple(keys)
        self._more_dirty = True
        # ★ 갈래 줄은 **목록보다 먼저** 맞춘다 — `_fill_more` 가 지금 고른
        #   갈래를 읽으므로 차례가 바뀌면 옛 갈래를 그린다.
        if getattr(self, '_more_tabs', None) is not None:
            try:
                self._sync_more_bar(keys)
            except Exception as e:
                print('[EntityBrowser] 더보기 갈래줄: %s' % e)
        try:
            if nb.index('current') == idx:
                if self._ensure_more_ui():
                    self._sync_more_bar(keys)
                self._fill_more()
        except Exception:
            pass

    def _ensure_more_ui(self):
        """더보기 몸통 = **갈래 줄 + 목록 하나**. 처음 필요할 때 짓는다(§29).

        ★ 다섯이 `share_with` 로 **한 프레임**을 쓰므로 목록 위젯은 하나다 —
          단추는 「어느 갈래를 볼까」를 정하는 거르개다.
        """
        if getattr(self, '_more_list', None) is not None:
            return True
        try:
            import branch_tabs as BT
            import eb_one_list as EBO
            import p2_one_list as POL
            bt = BT.BranchTabs(self._more_pane, db_path=self.db_path,
                               state_key='EB_MORE_BR',
                               on_change=self._on_more_branch)
            bt.pack(fill='both', expand=True)
            _first = None
            for k, ik, ko in EBO.KINDS:
                bt.add(k, ik, ko, share_with=_first)
                _first = _first or k
            self._more_tabs = bt
            lst = POL.OneList(
                bt.frame_for(_first), self.db_path,
                lang_getter=lambda: (self.lang_getter() or 'KO'),
                keys=EBO.ORDER, on_open=self._on_more_open,
                rows_fn=lambda _db, eid, ks, lg: EBO.rows(self, eid, ks, lg),
                empty_text=i18n.t('EBO_EMPTY',
                                  '이 용어에 연결된 자료가 없습니다'))
            lst.pack(fill='both', expand=True, padx=4, pady=4)
            self._more_list = lst
            bt.finish()
            return True
        except Exception as e:
            print('[EntityBrowser] 더보기 얼개: %s' % e)
            return False

    def _on_more_branch(self, _key=None):
        """더보기 안에서 갈래를 바꿨다 — 그 갈래만 다시 그린다."""
        self._more_dirty = True
        self._fill_more()

    def _sync_more_bar(self, keys):
        """갈래 줄을 지금 상태에 맞춘다 — **담긴 갈래만·개수와 함께**.

        ⚠ 통합탭이면 줄을 **감춘다** — 다섯을 한 목록으로 보는 것이 그 방식의
          뜻이라 갈래 단추가 있으면 화면이 거짓말을 한다(§0-1).
        """
        bt = getattr(self, '_more_tabs', None)
        if bt is None:
            return
        import eb_one_list as EBO
        want = set(keys or ())
        for k in EBO.ORDER:
            bt.set_count(k, self._tab_n.get(k) if k in want else None)
            bt.set_visible(k, k in want)
        bt.set_bar_visible(not self._more_one)
        if self._more_one:
            return
        # ⚠ 보고 있던 갈래가 더보기에서 빠졌으면 남은 첫 갈래로 옮긴다
        if bt.current() not in want:
            for k in EBO.ORDER:
                if k in want:
                    bt.select(k)
                    break

    def _fill_more(self):
        """「더보기」를 그린다 — **열려 있을 때만**(다시 필요하면 표식으로).

        ★★★ **표시방식을 여기서 읽는다**(2026-09-17 사용자 「더보기 누르면 왜
          서브탭이 표시되지 않고 통합탭으로 표시하는가?」) — 그전에는 언제나
          한 목록이라 **라디오가 절반만 들었다**.
            서브탭 = 갈래 줄에서 **고른 하나**만
            통합탭 = 담긴 갈래 **전부**를 한 목록으로
        """
        if not getattr(self, '_more_dirty', False):
            return
        keys = getattr(self, '_more_keys', ())
        if not keys or not self._ensure_more_ui():
            return
        # ⚠⚠ **갈래 줄을 여기서도 맞춘다** — 탭을 열 때 처음 지어지므로
        #   `_paint_more_tab` 만으로는 못 맞춘다(실측: 0건 갈래 단추가 남아
        #   그것을 누르면 아무 일도 안 일어났다).
        if not getattr(self, '_more_syncing', False):
            self._more_syncing = True
            try:
                self._sync_more_bar(keys)
            except Exception as e:
                print('[EntityBrowser] 더보기 갈래줄: %s' % e)
            finally:
                self._more_syncing = False
        lst = self._more_list
        bt = getattr(self, '_more_tabs', None)
        use = tuple(keys)
        if not self._more_one and bt is not None:
            cur = bt.current()
            use = (cur,) if cur in set(keys) else use[:1]
        try:
            lst.set_keys(use)
            eid = getattr(self, '_current_eid', None)
            if eid:
                lst.load(eid)
            self._more_dirty = False
        except Exception as e:
            print('[EntityBrowser] 더보기 채우기: %s' % e)

    def _on_more_open(self, key, num, url='', yt=None):
        """더보기 줄을 누르면 **원래 서브탭이 하던 일**을 그대로 한다."""
        try:
            if key in ('VIDEO', 'TEXT'):
                if yt:
                    return self._embed_play(yt)
                if url:
                    return webbrowser.open(url)
                return
            if key in ('STUDY', 'NAV'):
                return self._open_study_iid(str(num), key == 'STUDY')
            if key == 'SONG':
                idx = getattr(self, '_song_subtab_index', None)
                if idx is not None:
                    self._center_nb.select(idx)
                return
        except Exception as e:
            print('[EntityBrowser] 더보기 열기: %s' % e)

    def _open_tab_settings(self):
        """[T] — P2 와 **같은 팝업**. 적용하면 그 자리에서 반영한다."""
        import p2_tab_settings as TS

        def _apply(cfg_key, keys):
            # ★ 적용하는 문은 앱에 하나다(`user_main._apply_tab_pref_of`) —
            #   여기서 따로 쓰면 P2·NodePanel 이 안 따라온다.
            fn = getattr(self.winfo_toplevel(), '_apply_tab_pref_of', None)
            if callable(fn):
                return fn(cfg_key, keys)
            if cfg_key == self._EB_CFG:       # 앱 밖(하네스)에서 띄운 경우
                self._apply_tab_prefs()
        try:
            TS.open_win(self.winfo_toplevel(), self.db_path, _apply)
        except Exception as e:
            print('[EntityBrowser] 탭 설정: %s' % e)


    def _fill_dict_lang(self):
        """표시 언어 목록 — **고정이다. DB 를 묻지 않는다** (2026-08-14 설계 확정).

        ⚠ 예전에는 「이 용어에 어떤 판이 있나」를 물었다. 앱이 완성본이 아니므로
          지금 없다고 안 보이면 번역이 채워져도 그 화면은 그대로다.
          없는 것은 **영어로 폴백**해서 보인다.
        """
        import lang_combo
        self._dict_lang.set_items(lang_combo.variant_items())
        self._sync_dict_lang()

    def apply_font(self):
        """★ 설정 ▸ 폰트를 이 화면 **전체**가 따르게 한다 (2026-08-26 사용자
        「UI 는 표준 테마를 따르라 — 설정 메뉴 화면색 / 폰트 옵션」).

        `theme_font.reapply_all` 이 `_poke` 로 이 이름을 찾아 불러 준다 —
        호출부를 따로 배선하면 **빠뜨린 화면만 조용히 안 따라온다**(§36 교훈).
        ⚠ `scale` 은 `register` 로 등록된 위젯(본문 Text)은 건너뛴다 — 그쪽은
          구역(prose)이 통제한다. 여기서 잡는 것은 라벨·단추 같은 **크롬**이고,
          **크기 위계(제목이 본문보다 크다)는 그대로 지킨다.**
        """
        try:
            import theme_font as _tf2
            _tf2.scale(self, self.db_path)
            for st, head, ind in (('EB.Treeview', False, 0),
                                  ('Peri.Treeview', True, 8)):
                _tf2.list_style(st, self.db_path, heading=head,
                                indent=ind)
        except Exception as e:
            print('[EntityBrowser] apply_font: %s' % e)

    def _desc_lang(self):
        """설명·사전이 함께 쓰는 표시 언어 (0.txt 2-3 — 콤보 하나).

        ⚠ compact 모드(가계도 슬라이드)에는 콤보가 없다 — 앱 언어로 물러선다.
        """
        if getattr(self, '_dict_lang', None) is not None:
            v = (self._dict_lang_var.get() or '').upper()
            if v:
                return v
        return (self.lang_getter() or 'KO').upper()

    #: 모서리 콤보 폭 — 넓은 쪽부터. 좁아지면 차례로 줄인다.
    _CORNER_W = (11, 9, 7, 6, 5, 4)

    def _fit_corner_later(self, ms=60):
        """기하가 가라앉은 뒤에 잰다 — `<Configure>` 순간은 옛 폭이다(§256차 ②)."""
        try:
            if getattr(self, '_corner_job', None):
                self.after_cancel(self._corner_job)
        except Exception:
            pass
        try:
            self._corner_job = self.after(ms, self._fit_corner)
        except Exception:
            self._corner_job = None

    def _tab_right_edge(self):
        """탭 줄이 끝나는 x — 없으면 0. 굵게 훑고 잘게 다듬는다."""
        nb = getattr(self, '_center_nb', None)
        if nb is None:
            return 0
        try:
            w = nb.winfo_width()
            x = 0
            for i in range(w - 4, 0, -8):
                if nb.identify(i, 12) == 'label':
                    x = i
                    break
            if not x:
                return 0
            for i in range(x, min(w - 2, x + 8), 2):
                if nb.identify(i, 12) == 'label':
                    x = i
            return x
        except Exception:
            return 0

    def _fit_corner(self):
        """모서리 칸이 **마지막 탭을 안 가리게** 콤보 폭을 선택한다.

        ⚠ 폭을 **바뀔 때만** 적는다 — 무조건 적으면 `<Configure>` 가 다시
          나서 끝없는 idle 고리가 된다(§256차 ⑰ 그 자리).
        """
        self._corner_job = None
        nb = getattr(self, '_center_nb', None)
        cor = getattr(self, '_corner', None)
        lc = getattr(self, '_dict_lang', None)
        if nb is None or cor is None or lc is None:
            return
        try:
            end = self._tab_right_edge()
            if not end:
                return
            room = nb.winfo_width() - 4 - (end + 6)
            cur = int(lc.combo.cget('width') or 0)
            want = self._CORNER_W[-1]
            for w in self._CORNER_W:
                lc.combo.configure(width=w)
                cor.update_idletasks()
                if cor.winfo_reqwidth() <= room:
                    want = w
                    break
            if int(lc.combo.cget('width') or 0) != want:
                lc.combo.configure(width=want)
            if want != cur:
                cor.update_idletasks()
        except Exception as e:
            print('[EntityBrowser] 모서리 맞춤: %s' % e)

    def _disp_lang(self):
        """지금 화면이 쓸 언어 — 모서리 콤보가 이긴다(없으면 앱 언어)."""
        try:
            lc = getattr(self, '_dict_lang', None)
            v = lc.lang() if lc is not None else None
        except Exception:
            v = None
        try:
            return (v or self._app_lang() or 'KO')
        except Exception:
            return v or 'KO'

    def _sync_dict_lang(self):
        cur = self._dict_lang.current()
        if cur:
            self._dict_variant_var.set(cur[0] or 'ORIGINAL')
            self._dict_lang_var.set((cur[1] or 'EN').upper())

    def _on_dict_lang_pick(self, cur):
        """★ 콤보 하나가 **설명과 사전을 함께** 지배한다 (0.txt 2-3 · 2026-08-26).

        ⚠ 예전에는 사전만 이 콤보를 따르고 설명은 앱 언어를 따라, 둘이 서로
          다른 언어로 나란히 있을 수 있었다.
        """
        self._sync_dict_lang()
        if getattr(self, '_current_strong', None):
            self.load_lemma(self._current_strong, from_vid=self._from_vid,
                            translit=getattr(self, '_lex_translit', ''))
        elif self._current_eid is not None:
            self.load_entity(self._current_eid)      # 설명·사전을 함께 다시 그린다

    #: 원어사전 사이트 짧은 이름 — 좁은 줄이라 함축한다(§2026-09-02 그 결).
    _STRONG_SHORT = {'BIBLEHUB_STRONG': 'BibleHub', 'BLB_STRONG': 'BLB'}

    def _load_strong_sites(self, entity_id, anchors=None):
        """원어사전 Direct Link — **대표 하나는 단추, 전부는 콤보**.

        ★ 이름에 Strong 번호를 적는다 — **앵커가 둘 이상일 때만**(「구원」은
          H3467·H3444·G4982·G4991 넷이라 어느 낱말로 가는지 말해야 한다).
          하나뿐이면 번호가 군더더기다(실측 앵커 1개 48용어 · 2개 65 · 3개 13 ·
          4개 3).
        ⚠ **주소를 여기서 짓지 않는다** — 자리표 치환은 `overlay_read.strong_url`
          한 문이다(사전 본문 속 링크가 쓰는 그 문).
        ⚠⚠ **앵커가 없으면 칸째 비운다**(§0-1) — 실측 사람이 보는 용어 578개
          중 앵커가 있는 것은 **129개(22%)**다. 용어 108/122 · 교리 20/50 이고
          **인물·장소·절기는 0개**다. 「다윗」에 원어사전 단추는 뜻이 없다.
        """
        if self._strong_btn is not None:
            try:
                self._strong_btn.destroy()
            except Exception:
                pass
            self._strong_btn = None
        self._strong_map = {}
        self._strong_combo.set('')
        self._strong_combo['values'] = []
        self._strong_combo.config(state='disabled')
        # ⚠⚠ **앵커가 없으면 칸을 아예 걷는다**(2026-09-17 사용자 「1단에
        #   언어콤보 이외의 콤보상자가 있다. 이것은 어떤 용도인가? **필요없으면
        #   제거하라**」). 그전에는 `state='disabled'` 만 주고 **자리는 그대로**
        #   두어, 앵커가 없는 **578용어 중 449개(78%)**에서 아무 값도 없는
        #   콤보가 1단 자리를 먹고 있었다(§0-1 빈 서랍 금지).
        self._dict_strong_f.pack_forget()
        if not entity_id and not anchors:
            return
        try:
            import overlay_read as _or
            with appdb.connect(self.db_path) as conn:
                sites = _or.strong_sites(conn)
                # ★ 낱말은 앵커를 직접 받는다(2026-09-15) — 표에는 없다
                lem = (list(anchors) if anchors is not None
                       else _or.anchors_of(conn, entity_id))
        except Exception as e:
            print('[EntityBrowser] _load_strong_sites: %s' % str(e)[:80])
            return
        if not sites or not lem:
            return          # 앵커가 없으면 자리도 안 먹는다(§0-1)
        seen, anchors = set(), []
        for st, tr in lem:
            if st and st not in seen:
                seen.add(st)
                anchors.append((st, tr))
        many = len(anchors) > 1
        items, first = [], None
        for st, _tr in anchors:
            for code, name, tmpl in sites:
                short = self._STRONG_SHORT.get(code, name)
                label = ('%s %s' % (short, st)) if many else short
                try:
                    url = _or.strong_url(tmpl, st)
                except Exception:
                    continue
                if label in self._strong_map:
                    continue
                self._strong_map[label] = url
                items.append(label)
                if first is None:
                    first = (label, url)
        if not items:
            return
        self._strong_combo['values'] = items
        self._strong_combo.config(state='readonly')
        self._strong_combo.set(i18n.t('EB_STRONG_PICK', '원어사전 ▾'))
        if not self._dict_strong_f.winfo_manager():
            self._dict_strong_f.pack(side='right', padx=(4, 0))
        # ★ 대표 하나는 **단추**(사용자 「버튼 배치」) — 좁으면 접는다
        _bg, _hv = _C('panel', '#FFFFFF'), _C('select_bg', '#D6EAF8')
        b = tk.Label(self._dict_strong_f, text=' %s ' % first[0],
                     bg=_bg, fg=_C('accent', '#1A5276'),
                     cursor='hand2', padx=6, pady=0, relief='solid', bd=1)
        _tfr(b, self.db_path, 'ui', delta=-1)
        b.pack(side='right', padx=2)
        b.bind('<Button-1>', lambda _e, u=first[1]: webbrowser.open(u))
        b.bind('<Enter>', lambda _e, w=b, h=_hv: w.config(bg=h))
        b.bind('<Leave>', lambda _e, w=b, g=_bg: w.config(bg=g))
        self._strong_btn = b
        self._fit_dict_bar()

    def _on_strong_pick(self, _e=None):
        """선택하면 연다. ⚠ **선택한 채로 두지 않는다** — 이름이 남으면 「지금
        그것을 보고 있다」로 읽힌다."""
        url = self._strong_map.get(self._strong_combo.get())
        self._strong_combo.set(i18n.t('EB_STRONG_PICK', '원어사전 ▾'))
        if url:
            webbrowser.open(url)

    def _fit_dict_bar(self, _e=None):
        """첫 줄이 좁으면 **원어사전 단추부터** 접는다(콤보에 그대로 있다)."""
        try:
            bar = self._dict_strong_f.master
            have = bar.winfo_width()
            if have <= 1 or self._strong_btn is None:
                return
            need = sum(w.winfo_reqwidth() + 6
                       for w in bar.winfo_children() if w.winfo_ismapped())
            shown = self._strong_btn.winfo_ismapped()
            if shown and need > have:
                self._strong_btn.pack_forget()
                need -= self._strong_btn.winfo_reqwidth() + 6
            elif not shown and need + self._strong_btn.winfo_reqwidth() + 6 <= have:
                self._strong_btn.pack(side='right', padx=2)
                need += self._strong_btn.winfo_reqwidth() + 6
            # ⚠⚠ **아주 좁으면 칸째 접는다**(가계도 슬라이드 = compact 410px).
            #   거기서는 **사전 갈래 단추만으로 507px** 이라 애초에 자리가 없다.
            #   원어사전은 **넓은 P4 주요용어 탭**에서 본다 — 접어도 잃는 것이
            #   없고, 안 접으면 갈래 단추가 대신 잘린다.
            cf = self._dict_strong_f
            if cf.winfo_ismapped() and need > have:
                cf.pack_forget()
            elif (not cf.winfo_ismapped()
                  and need + cf.winfo_reqwidth() + 6 <= have
                  and self._strong_map):
                cf.pack(side='right', padx=(4, 0))
        except Exception:
            pass

    def _load_external_sites(self, entity_id: int):
        """[Phase 2-G Step 4] dict_pane 하단 외부 사전 사이트 버튼 동적 생성.
        sys_ref_entity_url JOIN sys_ref_site (scope='ENTITY' AND is_active=1) — 클릭 시 webbrowser.open."""
        # 기존 버튼 destroy (2026-09-02 — 라벨은 폐지됐다)
        for w in self._dict_ext_f.winfo_children():
            w.destroy()
        if not entity_id:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT s.site_code, s.site_name, s.site_name_ko, eu.url "
                    "  FROM sys_ref_entity_url eu "
                    "  JOIN sys_ref_site s ON s.site_id=eu.site_id "
                    " WHERE eu.entity_id=? AND eu.is_active=1 "
                    "   AND s.is_active=1 AND s.scope='ENTITY' "
                    "   AND COALESCE(eu.map_status,'AUTO')!='EXCLUDED' "
                    "   AND COALESCE(eu.record_status,'LIVE')='LIVE' "
                    "   AND COALESCE(s.record_status,'LIVE')='LIVE' "
                    " ORDER BY s.sort_order, s.site_code",
                    (entity_id,)
                ).fetchall()
        except Exception as e:
            print(f'[EntityBrowser] _load_external_sites error: {e}')
            return
        if not rows:
            return      # 같은 줄이라 빈 안내를 안 그린다 — 자리도 안 먹는다
        lang = self.lang_getter() if callable(self.lang_getter) else 'KO'
        # ★ 함축 표기 (2026-09-02 사용자 지시 ⑤ — 같은 줄로 올라오면서 자리가
        #   좁다. 「버튼 문자를 함축적으로」). 사이트가 늘면 여기 한 줄.
        _SHORT = {'WIKI_EN': 'Wiki(EN)', 'WIKI_KO': '위키(KO)',
                  'BIBLEHUB_TOPICAL': 'BibleHub',
                  'BIBLESTUDYTOOLS_DICT': 'BST'}
        for code, name_en, name_ko, url in rows:
            label = _SHORT.get(code) or (
                name_ko if lang == 'KO' and name_ko else name_en)
            # ⚠ 색을 박지 않는다(§36) — hover 복원색도 **역할**이라야
            #   검정 테마에서 지나간 자리만 하얗게 남지 않는다(§26 Recent 사고).
            _bg, _hv = _C('panel', '#FFFFFF'), _C('select_bg', '#D6EAF8')
            btn = tk.Label(self._dict_ext_f, text=f' {label} ',
                           bg=_bg, fg=_C('accent', '#1A5276'),
                           cursor='hand2', padx=6, pady=0,
                           relief='solid', bd=1)
            # ★ **한 단계 작게** (2026-08-26 사용자 지시) — 사전 이름 단추보다
            #   아래 층이라 같은 크기면 무게가 안 갈린다.
            _tfr(btn, self.db_path, 'ui', delta=-1)
            btn.pack(side='left', padx=2)
            btn.bind('<Button-1>', lambda _e, u=url: webbrowser.open(u))
            btn.bind('<Enter>', lambda _e, b=btn, h=_hv: b.config(bg=h))
            btn.bind('<Leave>', lambda _e, b=btn, g=_bg: b.config(bg=g))

    def _open_chain(self, chain_code):
        """흐름으로 간다 — 호스트(P4)가 탭을 연다.

        ⚠ **여기서 화면을 짓지 않는다** — 흐름 상세는 P4 탭7(구속사 연결
          설명)이 이미 맡는다. 두 곳에 지으면 규칙이 갈린다.
        ⚠ 호스트가 안 심어 주었으면 **왜 안 되는지 말한다**(§0-1 —
          눌러도 아무 일이 없으면 고장으로 읽힌다).
        """
        fn = getattr(self, 'on_chain_open', None)
        if callable(fn):
            try:
                fn(chain_code)
                return
            except Exception as e:
                print('[chain open] %s' % e)
        try:
            from tkinter import messagebox
            messagebox.showinfo(
                i18n.t('EB_WORD_CHAIN', '이 낱말이 흐르는 자리'),
                i18n.t('EB_CHAIN_WHERE',
                       '구속사 흐름은 「구절 연결」 화면의 '
                       '「구속사 연결 설명」에서 볼 수 있습니다.'),
                parent=self.winfo_toplevel())
        except Exception:
            pass

    def _show_neighbor(self, eid, name=''):
        """헷갈리는 이웃 낱말 → **오른쪽 슬라이딩 칸**에 그 설명문 (2026-09-16 · 3-(6)).
        지금 보는 용어와 그 탭들은 그대로다 — 옮기려면 [이 용어로 이동]."""
        try:
            eid = int(eid)
        except Exception:
            return
        self._nb_eid = eid
        lang = (self.lang_getter() if callable(self.lang_getter) else 'KO') or 'KO'
        txt = ''
        try:
            with appdb.connect(self.db_path) as conn:
                txt, _hidden = self._desc_with_overlay(conn, eid, lang.upper())
        except Exception as e:
            print('[neighbor desc] %s' % e)
        if not (name or '').strip():
            try:
                name = self._get_entity_name(eid) or ''
            except Exception:
                name = ''
        try:
            self._nb_name.config(text=name)
            self._nb_txt.config(state='normal')
            self._nb_txt.delete('1.0', 'end')
            self._nb_txt.insert('end', txt or i18n.t('COMMON_NODESC', '(설명문이 없습니다.)'))
            self._nb_txt.config(state='disabled')
            if str(self._nb_f) not in [str(x) for x in self._desc_pw.panes()]:
                self._desc_pw.add(self._nb_f, minsize=220, width=340, stretch='never')
        except Exception as e:
            print('[neighbor pane] %s' % e)

    def _hide_neighbor(self):
        self._nb_eid = None
        try:
            if str(self._nb_f) in [str(x) for x in self._desc_pw.panes()]:
                self._desc_pw.forget(self._nb_f)
        except Exception:
            pass

    def _go_neighbor(self):
        """[이 용어로 이동] — 옛 동작: 그 낱말을 지금 용어로."""
        eid = self._nb_eid
        if eid:
            self._hide_neighbor()
            self.load_entity(eid)

    def _hide_cmp(self):
        """비교 패널을 걷는다 — 짝이 없거나 사전·연결 갈래일 때."""
        try:
            # ⚠ panes() 는 Tcl_Obj 를 돌려줄 수 있다 — str 로 맞춰 비교해야
            #   걷기가 실제로 돈다(안 맞으면 조용히 패널이 남는다. 실측으로 잡음)
            self._cmp_f.pack_forget()
            self._hide_neighbor()
        except Exception:
            pass

    def _load_compare(self, entity_id: int):
        """설명문 아래 비교 칸. 짝이 없으면 칸째로 감춘다.

        ⚠ 한 짝은 **양쪽에서 다 보인다**(`db_entity_compare.fetch`). 토브를 봐도
          야샤르를 봐도 같은 줄이 뜬다 — 그래서 설명문에 두 이름이 다 적혀 있어야 한다.
        """
        self._cmp_rows = []
        rows = []
        try:
            import db_entity_compare as EC
            import overlay_read as _or
            with appdb.connect(self.db_path) as conn:
                lang = (self.lang_getter() if callable(self.lang_getter) else 'KO') or 'KO'
                # ★ 네 칸으로 받는다 — 넷째가 **관계**(2026-09-24)
                rows = EC.fetch(conn, entity_id, lang.upper(), with_rel=True)
                self._cmp_rel_name = {
                    rc: EC.rel_name(conn, rc, lang.upper())
                    for rc in EC.REL_KINDS}
                # ★ **의미장 형제 합류** (2026-09-02 177차) — 소속 링크(데이터)
                #   에서 자동 유도. 어느 낱말을 눌러도 가족 전부가 뜬다(사용자
                #   「유사단어 세트가 5개라면 어떤 단어를 눌러도 4개는 표시」).
                #   손으로 쓴 비교 짝이 먼저, 형제는 그 뒤에 붙는다.
                have = {r[0] for r in rows} | {entity_id}
                for sib in _or.field_siblings(conn, entity_id, lang.upper()):
                    if sib[0] not in have:
                        have.add(sib[0])
                        # ⚠ **손으로 고른 관계가 아니다** — 의미장 소속에서
                        #   기계가 유도한 줄이므로 그렇다고 적는다(§0-1).
                        rows.append(tuple(sib) + ('_FIELD',))
        except Exception as e:
            print(f'[compare] {e}')
        # ★★★ **이 낱말이 흐르는 자리** (2026-09-07 · 1.txt 제안 C).
        #   사용자 확정: 「낱말묵상플랜은 … **연결되는 구절의 분량이 작다면
        #   흐름묵상과 같이 해도 좋다**」.
        #   ⚠⚠ **새 흐름을 만들지 않았다** — 재 보니 「사랑」·「하나님과 동행」
        #     같은 흐름이 **이미 81개** 있었고 품질이 우리 대표 절보다 나았다.
        #     빠진 것은 **낱말 ↔ 흐름의 다리**였다(`db_word_chain`).
        #   ★ 「헷갈리는 이웃 낱말」과 **같은 칸**에 둔다 — 축이 같다
        #     (둘 다 「이 낱말과 이어진 것」). 자리를 안 늘린다.
        chains = []
        try:
            import db_word_chain as _WC
            with appdb.connect(self.db_path) as _c:
                chains = _WC.links_of_term(_c, entity_id)
        except Exception as e:
            print('[word chain] %s' % e)
        # ★★★ **같은 뿌리에서 나온 낱말** (2026-09-07 · 1.txt 제안 B).
        #   ★ 가장 값진 것은 **그 낱말을 이름으로 지닌 사람**이다(실측):
        #     카보드(영광) → 요게벳「여호와는 영광」 · 이가봇「영광이 떠났다」
        #   ⇒ A(이름에 담긴 고백)와 한 몸이라 **같은 칸**에 둔다.
        #   ⚠ 헬라어는 가족이 거의 없다 — 없으면 안 그린다(§0-1).
        fam = None
        try:
            import db_word_family as _WF
            with appdb.connect(self.db_path) as _c:
                fam = _WF.family_of_entity(_c, entity_id)
                _fam_ent = _WF.entity_of_strong(_c)
        except Exception as e:
            print('[word family] %s' % e)
            _fam_ent = {}
        if fam and not (fam['words'] or fam['names']):
            fam = None
        if not rows and not chains and not fam:
            self._hide_cmp()
            return
        # Text 하나에 흐르는 본문으로 — 이름은 클릭 태그, 설명은 단어 단위
        # 줄바꿈(문장을 엔터로 자르지 않는다 — §36 표준서식).
        t = self._cmp_txt
        self._retag()
        t.config(state='normal')
        t.delete('1.0', 'end')
        NL = chr(10)
        for i, row in enumerate(rows):
            other, name, note = row[:3]
            rel = row[3] if len(row) > 3 else None
            if i:
                t.insert('end', NL)
            tag = 'cmp_go_%d' % i
            t.insert('end', name, ('cmp_name', tag))
            # ★ **무슨 사이인지 그 줄에서 말한다** — 반대말과 비슷한 말이
            #   한 목록에 섞여 있으면 글을 끝까지 읽어야 알 수 있다.
            lbl = (i18n.t('EB_REL_FIELD', '같은 의미장') if rel == '_FIELD'
                   else (getattr(self, '_cmp_rel_name', {}) or {}).get(rel, ''))
            if lbl:
                t.insert('end', '  · ' + lbl, ('cmp_note',))
            t.insert('end', NL + (note or '').strip() + NL, ('cmp_note',))
            # ★ 누르면 **오른쪽에 그 낱말의 설명문** — 지금 용어는 안 바뀐다(2026-09-16)
            t.tag_bind(tag, '<Button-1>',
                       lambda _e, o=other, n=name: self._show_neighbor(o, n))
            t.tag_bind(tag, '<Enter>',
                       lambda _e, w=t: w.config(cursor='hand2'))
            t.tag_bind(tag, '<Leave>',
                       lambda _e, w=t: w.config(cursor='arrow'))
            self._cmp_rows.append((other, name))
        # ── 이 낱말이 흐르는 자리 ─────────────────────────────────
        if chains:
            if rows:
                t.insert('end', NL)
            t.insert('end', i18n.t('EB_WORD_CHAIN', '이 낱말이 흐르는 자리') + NL,
                     ('cmp_name',))
            for j, (cc, cname) in enumerate(chains):
                tag = 'wc_go_%d' % j
                t.insert('end', '· ' + (cname or cc), ('cmp_name', tag))
                t.insert('end', NL)
                t.tag_bind(tag, '<Button-1>',
                           lambda _e, code=cc: self._open_chain(code))
                t.tag_bind(tag, '<Enter>',
                           lambda _e, w=t: w.config(cursor='hand2'))
                t.tag_bind(tag, '<Leave>',
                           lambda _e, w=t: w.config(cursor='arrow'))
        # ── 같은 뿌리에서 나온 낱말 ───────────────────────────────
        if fam:
            import db_word_family as _WF2
            if rows or chains:
                t.insert('end', NL)
            head = i18n.t('EB_WORD_FAMILY', '같은 뿌리에서 나온 낱말')
            if fam.get('roots'):
                head += '  (%s)' % ' · '.join(
                    _WF2.label(r) for r in fam['roots'])
            t.insert('end', head + NL, ('cmp_name',))
            k = 0
            for key, pre in (('words', '· '), ('names', '· ')):
                if key == 'names' and fam['names']:
                    t.insert('end', i18n.t('EB_WF_NAMES',
                                           '이 낱말을 이름으로 지닌 이') + NL,
                             ('cmp_note',))
                for r in fam[key]:
                    eid2 = _fam_ent.get(r['strong'])
                    # ★ **우리 자산이면 그 이름으로** 보인다 — 낱말 마스터의
                    #   음역은 로마자(`Ṭôwbîyâh`)라 한국어 화면에서 안 읽힌다.
                    #   ⚠ 한글 음역을 지어내지 않는다 — 있는 이름을 쓴다.
                    nm2 = ''
                    if eid2:
                        try:
                            nm2 = self._get_entity_name(eid2) or ''
                            # ⚠ 못 찾으면 **번호를 돌려준다** — 숫자가 뜨면
                            #   안 되므로 그때는 음역을 쓴다.
                            if nm2.isdigit():
                                nm2 = ''
                        except Exception:
                            nm2 = ''
                    lbl = pre + (nm2 or _WF2.label(r))
                    if eid2 and eid2 != entity_id:
                        tag = 'wf_go_%d' % k
                        t.insert('end', lbl, ('cmp_name', tag))
                        t.tag_bind(tag, '<Button-1>',
                                   lambda _e, o=eid2: self.load_entity(o))
                        t.tag_bind(tag, '<Enter>',
                                   lambda _e, w=t: w.config(cursor='hand2'))
                        t.tag_bind(tag, '<Leave>',
                                   lambda _e, w=t: w.config(cursor='arrow'))
                        k += 1
                    else:
                        # ⚠ 우리 자산이 없는 낱말은 **누를 수 없다** —
                        #   눌러도 아무 일이 없으면 고장으로 읽힌다(§0-1).
                        t.insert('end', lbl, ('cmp_note',))
                    t.insert('end', NL)
        t.config(state='disabled')
        # ★ 짝이 있을 때만 오른쪽 패널로 — 사시로 크기를 조절할 수 있다.
        try:
            if not self._cmp_f.winfo_manager():
                # ⚠ 본문(desc_f) **뒤에** 붙인다 — pack 은 붙인 차례로 자리를 주므로
                #   좁으면 목록이 줄고 설명문이 남는다(먼저 붙였더니 P4 가 낮을 때
                #   목록이 칸을 다 먹어 설명문이 안 보였다 — 실측).
                self._cmp_f.pack(side='bottom', fill='x', padx=4, pady=(0, 4))
        except Exception as e:
            print('[compare pane] %s' % e)

    # 사전 셋 — 버튼에 쓸 짧은 이름과 본문 머리에 쓸 긴 이름.
    # ⚠ 두 곳에 따로 적지 않는다. 한쪽만 고치면 버튼과 본문이 다른 사전을 가리킨다.
    _DICT_SRC = (('EASTON_DICT', 'Easton', "Easton's Bible Dictionary (1897)"),
                 ('SMITH_DICT',  'Smith',  "Smith's Bible Dictionary (1884)"),
                 ('MEYER_BC',    'Meyer',  'F.B. Meyer — Bible Characters'))

    def _load_dict_entries(self, entity_id: int):
        # ★ 승격 안 된 낱말 — 백과(REFU_ENTI)는 없고 스트롱·BDB·A-S·Thayer 만
        #   앵커 하나로 읽는다. 꼬리(단추·기본 갈래)는 용어와 같다.
        if getattr(self, '_current_strong', None):
            return self._finish_dict([], None,
                                     [(self._current_strong,
                                       getattr(self, '_lex_translit', ''))])
        _src_name = {c: full for c, _s, full in self._DICT_SRC}
        variant = self._dict_variant_var.get()
        if variant == 'TRANSLATED':
            v_param, l_param = 'TRANSLATED', self._dict_lang_var.get()
        elif variant == 'MODERN_EN':
            v_param, l_param = 'MODERN_EN', 'EN'
        else:
            v_param, l_param = 'ORIGINAL', 'EN'
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute("""
                    SELECT u.unit_label, s.src_code,
                           COALESCE(NULLIF(TRIM(rt.body_text),''), rf.body_text)
                    -- ★ 2026-08-24 통합 표(`REFU_ENTI`)
                    FROM sys_link_asset el
                    JOIN sys_ref_unit u ON u.ref_unit_id = el.clicked_id
                    JOIN sys_ref_source s ON s.ref_src_id = u.ref_src_id
                    LEFT JOIN sys_ref_text rt ON rt.ref_unit_id = u.ref_unit_id
                      AND rt.text_variant = ?
                      AND UPPER(rt.lang_code) = UPPER(?)
                      AND rt.record_status = 'LIVE'
                    -- ★ **폴백은 언제나 영어** (2026-08-14 설계 확정)
                    LEFT JOIN sys_ref_text rf ON rf.ref_unit_id = u.ref_unit_id
                      AND rf.text_variant = 'ORIGINAL'
                      AND UPPER(rf.lang_code) = 'EN'
                      AND rf.record_status = 'LIVE'
                    WHERE el.link_type = 'REFU_ENTI' AND el.target_id = ?
                      AND COALESCE(el.record_status,'LIVE') = 'LIVE'
                      AND u.record_status = 'LIVE' AND s.record_status = 'LIVE'
                      AND s.src_code IN ('EASTON_DICT', 'SMITH_DICT', 'MEYER_BC')
                    ORDER BY s.ref_src_id, u.sequence
                """, (v_param, l_param, entity_id)).fetchall()
                # ★★ **내가 이은 사전도 함께** (2026-08-27 · 0.txt 1번 —
                #   MY 창에서 사전을 이어도 이 탭이 sys 만 읽어 안 보였다.
                #   가린 sys 항목은 뺀다(읽는 화면).
                import entity_overlay as _EO
                _mine, _hid = [], set()
                for _d in _EO.dict_links(conn, entity_id, l_param):
                    if _d['src'] == 'HIDE':
                        _hid.add(_d['unit_id'])
                    elif _d['src'] == 'NEW':
                        _mine.append(_d['unit_id'])
                if _hid:
                    _keep = []
                    for _r in rows:
                        _u = conn.execute(
                            "SELECT ref_unit_id FROM sys_ref_unit "
                            "WHERE unit_label=? LIMIT 1", (_r[0],)).fetchone()
                        if not (_u and _u[0] in _hid):
                            _keep.append(_r)
                    rows = _keep
                for _uid in _mine:
                    _r2 = conn.execute(
                        "SELECT u.unit_label, s.src_code, "
                        "  COALESCE(NULLIF(TRIM(rt.body_text),''), rf.body_text) "
                        "  FROM sys_ref_unit u "
                        "  JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id "
                        "  LEFT JOIN sys_ref_text rt ON rt.ref_unit_id=u.ref_unit_id "
                        "   AND rt.text_variant=? AND UPPER(rt.lang_code)=UPPER(?) "
                        "   AND rt.record_status='LIVE' "
                        "  LEFT JOIN sys_ref_text rf ON rf.ref_unit_id=u.ref_unit_id "
                        "   AND rf.text_variant='ORIGINAL' "
                        "   AND UPPER(rf.lang_code)='EN' AND rf.record_status='LIVE' "
                        " WHERE u.ref_unit_id=?",
                        (v_param, l_param, _uid)).fetchone()
                    if _r2:
                        rows = list(rows) + [_r2]
        except Exception as e:
            self._fill(self._dict_txt,
                       i18n.t('EB_LOAD_ERR', '불러오기 오류: {e}').format(e=e))
            return

        try:
            import overlay_read as _or0
            with appdb.connect(self.db_path) as conn:
                anchors = _or0.anchors_of(conn, entity_id)
        except Exception:
            anchors = []
        self._finish_dict(rows, entity_id, anchors)

    def _finish_dict(self, rows, entity_id, anchors):
        """사전 재료를 담고 갈래 단추를 그린다 — 용어·낱말 공통 꼬리 (2026-09-15).

        anchors = [(strong, 음역)] — 용어는 앵커 표에서, 낱말은 그 번호 하나.
        """
        self._dict_rows = list(rows or [])
        self._strong_rows = []
        self._bdb_rows = []
        self._as_rows = []
        self._th_rows = []
        self._bookd_rows = []
        try:
            import overlay_read as _or2
            with appdb.connect(self.db_path) as conn:
                self._strong_rows = _or2.strong_entries_for(conn, anchors)
                self._strong_sites = _or2.strong_sites(conn)
                self._bdb_rows = _or2.bdb_entries_for(conn, anchors)
                self._as_rows = _or2.absmith_entries_for(conn, anchors)
                self._th_rows = _or2.thayer_entries_for(conn, anchors)
                if entity_id:
                    self._bookd_rows = _or2.book_dict_entries(conn, entity_id)
        except Exception as e:
            print('[EntityBrowser] strong: %s' % e)
        have = [c for c, _s, _f in self._DICT_SRC
                if any(r[1] == c for r in self._dict_rows)]
        # ★★★ 갈래는 둘뿐이다 — [용어설명] · [사전 모음] (+ 절에서 왔을 때
        #   「룻1:16 과의 연결」). 2026-09-15 사용자 「사전마다 단추를 두던 방식을
        #   폐기 · 하나로 결합 · 「전체」 → 「사전 모음」」.
        #   · 용어설명이 있으면 그것이 첫 화면, 없으면(낱말·설명 없는 용어)
        #     사전 모음이 첫 화면이고 머리에 그 사실을 한 줄 적는다.
        #   · 옛 저장값이 사전 하나(STRONG·BDB…)를 가리키면 사전 모음으로.
        _from = getattr(self, '_from_vid', None)
        _has_link = bool(entity_id and _from and self._link_desc_for(
            entity_id, _from, self.lang_getter()))
        _has_desc = bool(entity_id) and bool(
            (getattr(self, '_desc_body', '') or '').strip())
        if _has_link:
            self._dict_src = self.LINK_SRC
        elif self._dict_src == self.DESC_SRC and _has_desc:
            pass
        elif self._dict_src in (None, self.LINK_SRC, self.DESC_SRC):
            self._dict_src = self.DESC_SRC if _has_desc else self.ALLD_SRC
        else:
            self._dict_src = self.ALLD_SRC
        if self._dict_src == self.ALLD_SRC and self._n_dict_src() < 1 and _has_desc:
            self._dict_src = self.DESC_SRC
        self._render_dict_btns(have)
        self._show_src_branch()

    DESC_SRC = 'DESC'          # 갈래 단추 첫 자리 — 우리가 쓴 설명문
    STRONG_SRC = 'STRONG'      # 낱말 마스터(스트롱 1890) 갈래 (2026-09-02)
    BDB_SRC = 'BDB'            # BDB 뜻 개요(OSHB 전사) 갈래 (2026-09-03)
    AS_SRC = 'AS'              # Abbott-Smith(1922) 헬라 사전 갈래 (2026-09-03)
    BOOKD_SRC = 'BOOKD'        # 낱말 분석 문헌(Girdlestone 등) 갈래 (2026-09-03)
    TH_SRC = 'TH'              # Thayer(1889) 헬라 심층 사전 갈래 (2026-09-03)
    ALLD_SRC = 'ALLD'          # [전체] — 사전 원천 통합 스크롤 (2026-09-03)
    # 외부 사전 사이트 줄의 **고정 높이** — 있고 없고에 화면이 안 흔들리게(2026-08-26)
    _EXT_ROW_H = 30

    def _link_desc_for(self, entity_id, vid, lang):
        """그 절(또는 그 절을 덮는 구간)의 **의미연결 설명문**. 없으면 None.

        ⚠ **어휘연결이면 안 돌려준다**(사용자 지시) — 낱말이 본문에 있으니
          오해가 없고, 설명문도 원래 없다.
        ⚠ **구간 연결도 잡는다** — `창1:3~5` 로 이었으면 4절에서 들어와도
          그 설명문이 나와야 한다(2026-09-01 구간 연결 신설).
        """
        if not entity_id or not vid:
            return None
        try:
            import link_picker as _lp
            with appdb.connect(self.db_path) as conn:
                # ⚠ **화면이 연결 SQL 을 쓰지 않는다** — 연결을 아는 곳은
                #   `link_picker` 다(`db_overlay_audit` 래칫이 그것을 지킨다).
                r = _lp.verse_link_for(conn, entity_id, vid)
                _tt, _lang = 'ENTITY_VERSE_DESC', (lang or 'KO').upper()
                if not r:
                    # ★ **낱말연결에 단 설명문도 잡는다** (2026-09-01 소급
                    #   재작성). 낱말이 그 절에 있는 교리(언약 창17:7 등)는
                    #   THEMATIC 을 만들면 같은 절이 두 번 뜨므로 설명문을
                    #   **낱말연결 행에** 달았다 — 그 글이 보이는 길이 이것이다.
                    #   ⚠ 「어휘연결이면 안 뜬다」(148차)는 **설명문이 없던**
                    #     때의 규칙이다. 글이 실제로 있으면 보이는 것이 맞다 —
                    #     단추는 설명문이 있을 때만 생기므로 잡음이 안 는다.
                    r2 = _lp.verse_link_for(conn, entity_id, vid,
                                            rel='LEXICAL')
                    if r2:
                        import overlay_read as _or0
                        _b0, _s0 = _or0.text(conn, _tt, r2[0], _lang)
                        if _b0 and (_b0.get('contents') or '').strip():
                            r = r2
                if not r:
                    # ★★★ **단락으로 이어 둔 것도 잡는다** (2026-09-01 사용자
                    #   물음 — 「창1:1 에 삼위일체 단어가 없는데 **설명문도
                    #   없다. 왜 그런가**」).
                    #   ⚠⚠ **설명문은 있었다 — 화면이 안 읽고 있었다.** 그
                    #     연결은 절이 아니라 **단락**(`ENTI_PERI`)에 걸려 있고
                    #     글은 `ENTITY_PERI_DESC` 에 있는데, 이 함수가
                    #     `ENTI_VERS` 만 보고 있었다. 사용자에게는 둘이 같은
                    #     「이 절과의 연결」이므로 **한 단추가 둘 다 맡는다.**
                    #   ⏭ 단락 연결 822건을 절로 옮기는 일(entity.md)은 별건이고,
                    #     옮기기 전까지 **이 길이 없으면 그 설명문은 안 보인다.**
                    r = _lp.peri_link_for(conn, entity_id, vid)
                    if not r:
                        return None
                    _tt = 'ENTITY_PERI_DESC'
                # ⚠⚠ **덮개를 태워 읽는다** — sys 를 직접 읽으면 사용자가 고친
                #   설명문이 안 나온다(`db_overlay_audit` 래칫이 잡았다).
                #   가림은 폴백을 이긴다 — `overlay_read` 가 그 규칙을 안다.
                import overlay_read as _or
                _body, _src = _or.text(conn, _tt, r[0], _lang)
                if not _body or not (_body.get('contents') or '').strip():
                    return None
                return {'body': _body['contents'],
                        'ref': _lp.scope_label(conn, r[1], r[2], lang)
                               or self._vref(conn, r[1])}
        except Exception as e:
            print('[EntityBrowser] link desc: %s' % e)
            return None

    @staticmethod
    def _vref(conn, vid):
        r = conn.execute(
            "SELECT bn.short_name, bi.chapter, bi.verse FROM bible_index bi"
            "  JOIN book_names bn ON bn.book_code=bi.bcode"
            "   AND UPPER(bn.lang_code)='KO' WHERE bi.verse_id=?", (vid,)).fetchone()
        return ('%s%s:%s' % r) if r else ''

    def _render_dict_btns(self, have):
        """갈래 단추 줄 — `[설명] [Smith] [Easton]`.

        ★★ 설명·사전 통합 (2026-08-26). **「설명」이 늘 첫 단추**이고, 그 뒤에
          **그 용어에 실제로 있는 사전만** 붙는다. 사전이 하나도 없으면 설명
          단추만 남는다 — 눌러도 빈 화면인 단추를 만들지 않는다.
        ⚠ 줄 자체를 감추지 않는다. 감추면 사전이 있는 용어로 옮겼을 때
          단추가 갑자기 나타났다 사라져 자리가 흔들린다.
        """
        for w in self._dict_btnbar.winfo_children():
            w.destroy()
        self._dict_btns = {}
        # ⚠ 버튼 줄은 언어 콤보 줄(dict_ctrl)의 자식이다(2026-08-16 이사).
        #   옛 자리 기준 `before=dict_f`(다른 부모)로 되살리면 TclError —
        #   생성 때와 같은 방식으로 붙인다.
        # ★ **왼쪽에 공백 없이 붙인다**(2026-09-01 사용자 지시) — 이름 라벨 뒤.
        # ⚠ 차례가 뒤집혔다(2026-09-17 · 1.txt 1-4) — **단추가 먼저, 이름이 뒤**다.
        if not self._dict_btnbar.winfo_manager():
            self._dict_btnbar.pack(side='left')
        self._paint_dict_name()

        # ★ Recent 서식 (2026-09-02 사용자 지시 ④) — flat_btn · 눌림은 색
        import ui_theme as _uth3
        # ★ 단추 축소 (2026-09-03 사용자 지시 「용어설명, Easton 등 버튼의
        #   크기를 줄여라」) — 글꼴은 meta 구역(표준서식의 작은 단계 · 설정을
        #   따라 함께 준다), 여백도 좁힌다. 원천이 늘어 줄이 길어진 대응.
        _fbk = _uth3.flat_btn(padx=3, pady=1)
        # ★ [용어설명]·[사전 모음] 은 **한 단계 크게**(delta -1), 그 밖(「…과의
        #   연결」)은 -2 (2026-09-15 항목 ③ 사용자 승인).
        def _mk(code, label, delta=-2):
            b = tk.Button(self._dict_btnbar, text=label,
                          command=lambda c=code: self._set_dict_src(c), **_fbk)
            # delta — 크기를 박는 것이 아니라 **단계**(§36 크기 위계).
            # 설정을 키우면 그 차이를 유지한 채 함께 커진다.
            _tfr(b, self.db_path, 'meta', delta=delta)
            b.pack(side='left', padx=(0, 3))
            self._dict_btns[code] = b

        # ★★★ **맨 왼쪽 = 「그 절과의 연결」** (2026-09-01 사용자 지시 —
        #   「용어사전 서브탭이 가장 먼저 보여지는 곳이므로, 설명버튼/사전이름
        #   버튼들이 배치된 곳 **가장 왼쪽**에 버튼을 만들어서 의미연결
        #   설명문을 배치하는 것이 좋겠다」).
        #   ★ **이름에 출발지를 박는다** — 「연결 설명」이라고만 쓰면 무엇과의
        #     연결인지 모른다. `룻1:16 과의 연결` 이라 적으면 그 자리가 왜 떠
        #     있는지 즉시 안다(주요용어 화면은 원래 일반 설명 자리다).
        #   ⚠ **검색으로 왔거나 어휘연결이면 안 만든다**(사용자 지시) —
        #     `_link_desc_for` 가 그때 None 을 돌려준다.
        # ★ **「용어설명」이 맨 왼쪽 고정**(2026-09-01 사용자 지시 — 「설명 버튼이
        #   고정되어야 한다면 가장 왼쪽에 배치해도 좋다. **「용어설명」이라고
        #   수정하라**」). 늘 있는 단추가 늘 같은 자리에 있어야 손이 기억한다.
        # ★ [용어설명] — 용어(엔티티)에만. 낱말에는 설명이 없어 단추도 없다.
        if self._current_eid:
            _mk(self.DESC_SRC, i18n.t('EB_TERM_DESC', '용어설명'), delta=-1)
        self._link_desc = None
        if self._current_eid and getattr(self, '_from_vid', None):
            self._link_desc = self._link_desc_for(
                self._current_eid, self._from_vid, self.lang_getter())
        if self._link_desc:
            _mk(self.LINK_SRC, i18n.t('EB_LINK_WITH', '{ref} 과의 연결').format(
                ref=self._link_desc['ref']))
        # ★ [사전 모음] — 원천이 하나라도 있으면(2026-09-15 · 옛 「전체」는 둘
        #   이상일 때만 떴다). 사전마다 두던 단추는 걷었다 — 결합 화면이 소제목으로
        #   원천을 가른다.
        if self._n_dict_src() >= 1:
            _mk(self.ALLD_SRC, i18n.t('EB_DICT_ALL', '사전 모음'), delta=-1)
        self._paint_dict_btns()

    def _paint_dict_name(self):
        """갈래 줄 이름 라벨 — 용어는 이름, 낱말은 원어 글자(음역). 없으면 감춘다."""
        lbl = getattr(self, '_dict_name_lbl', None)
        if lbl is None:
            return
        txt = ''
        try:
            if getattr(self, '_current_strong', None):
                info = getattr(self, '_lex_info', {}) or {}
                txt = ' '.join(x for x in (
                    info.get('form', ''),
                    ('(%s)' % info['translit']) if info.get('translit') else '') if x) \
                    or self._current_strong
            elif self._current_eid:
                txt = self._get_entity_name(self._current_eid) or ''
        except Exception:
            txt = ''
        lbl.config(text=txt)
        if txt and not lbl.winfo_manager():
            # ★ 단추 줄 **뒤**에 공백을 두고(1.txt 1-4 「(공백) 용어를 굵게」)
            lbl.pack(side='left', padx=(12, 6), after=self._dict_btnbar)
        elif not txt:
            lbl.pack_forget()
        self._paint_dict_lex()

    def _paint_dict_lex(self):
        """이름 오른쪽 **원어 표기** — 「원어: H7307(루아흐) · G4151(프뉴마)」.

        2026-09-17 · 1.txt 1-4 사용자 배치 그대로. 그전에는 본문 위 제 줄을
        먹고 있었다(「본문 표시공간을 한줄이라도 더 늘려야 한다」).
        ⚠ **앵커가 없으면 안 그린다**(§0-1) — 인물·장소는 원어가 0 이다.
        """
        lbl = getattr(self, '_dict_lex_lbl', None)
        if lbl is None:
            return
        txt = ''
        try:
            eid = getattr(self, '_current_eid', None)
            if eid and not getattr(self, '_current_strong', None):
                import appdb as _a
                with _a.connect(self.db_path) as _c:
                    rows = _c.execute(
                        "SELECT strong, COALESCE(translit,'') FROM sys_entity_lemma"
                        " WHERE entity_id=?"
                        "   AND COALESCE(record_status,'LIVE')='LIVE'"
                        " ORDER BY sort_order, lemma_id", (int(eid),)
                    ).fetchall()
                parts = ['%s(%s)' % (a, b) if b else str(a) for a, b in rows]
                if parts:
                    txt = i18n.t('EB_LEX_ANCHOR', '원어: ') + ' · '.join(parts)
        except Exception:
            txt = ''
        lbl.config(text=txt)
        if txt and not lbl.winfo_manager():
            lbl.pack(side='left', after=self._dict_name_lbl)
        elif not txt:
            lbl.pack_forget()

    def _paint_dict_btns(self):
        """갈래 단추 표준(§76) — **활성 dark_bg + fg_on_dark · 비활성 panel_alt + fg**.

        ⚠ 색을 박아 두면 검정 테마에서 안 고른 단추가 흰색으로 남는다
          (유형 단추가 같은 사고를 겪었다 — 위 `_paint_type_btns` 참조).
        """
        on_bg, on_fg = _C('dark_bg', '#2E86C1'), _C('fg_on_dark', 'white')
        off_bg, off_fg = _C('panel_alt', '#ECF0F1'), _C('fg', '#566573')
        for code, b in self._dict_btns.items():
            on = (code == self._dict_src)
            # flat(Recent) 서식 — 눌림은 색이 말한다 (2026-09-02 ④)
            b.configure(bg=on_bg if on else off_bg,
                        fg=on_fg if on else off_fg)

    def _set_dict_src(self, code):
        if code == self._dict_src:
            return
        self._dict_src = code
        self._paint_dict_btns()
        self._show_src_branch()

    def _show_src_branch(self):
        """본문 자리에 「설명」 또는 「사전」을 갈아 끼운다.

        ⚠ 위젯을 파괴하지 않는다 — `pack_forget` 으로 숨겼다 되살린다.
          파괴하면 스크롤 자리·태그·글꼴 등록을 매번 다시 지어야 한다.
        ⚠ 「헷갈리는 이웃 낱말」 칸은 **설명 갈래의 것**이다. 사전 글 밑에
          붙어 있으면 그 사전이 낸 것처럼 읽힌다.
        """
        # ★ 「그 절과의 연결」 갈래 — 설명 자리를 그대로 쓰되 글만 갈아 끼운다.
        #   ⚠ 새 위젯을 만들지 않는다 — 스크롤·글꼴 등록을 또 지어야 한다.
        if self._dict_src == self.LINK_SRC and getattr(self, '_link_desc', None):
            self._dict_body_f.pack_forget()
            if not self._desc_f.winfo_ismapped():
                self._desc_f.pack(fill='both', expand=True, padx=4, pady=4)
            self._hide_cmp()
            try:
                t = self._desc_txt
                t.config(state='normal')
                t.delete('1.0', 'end')
                t.insert('end', self._link_desc['body'])
                t.config(state='disabled')
            except Exception as e:
                print('[EntityBrowser] link body: %s' % e)
            return
        is_desc = (self._dict_src == self.DESC_SRC)
        (self._dict_body_f if is_desc else self._desc_f).pack_forget()
        tgt = self._desc_f if is_desc else self._dict_body_f
        if not tgt.winfo_ismapped():
            tgt.pack(fill='both', expand=True, padx=4, pady=4)
        if is_desc:
            # ⚠ 「그 절과의 연결」이 이 칸을 덮어썼을 수 있다 — 되채운다.
            try:
                self._fill(self._desc_txt, getattr(self, '_desc_body', '') or '')
            except Exception as e:
                print('[EntityBrowser] desc restore: %s' % e)
            self._load_compare(self._current_eid) if self._current_eid else None
        else:
            self._hide_cmp()
            if self._dict_src == self.STRONG_SRC:
                self._render_strong()
            elif self._dict_src == self.BDB_SRC:
                self._render_bdb()
            elif self._dict_src == self.AS_SRC:
                self._render_absmith()
            elif self._dict_src == self.TH_SRC:
                self._render_thayer()
            elif self._dict_src == self.BOOKD_SRC:
                self._render_bookdict()
            elif self._dict_src == self.ALLD_SRC:
                self._render_dict_all()
            else:
                self._render_dict()

    def _render_bdb(self, append=False):
        """BDB 갈래 (184차 개요 → 2026-09-03 188차 **무삭제 전문**) —
        히브리 앵커마다 한 덩이. 본문 = eliranwong unabridged 전사(PD)라
        「전사 개요」 단서가 필요 없어졌다."""
        t = self._dict_txt
        t.config(state='normal')
        if not append:
            t.delete('1.0', 'end')
        NL = chr(10)
        for i, r in enumerate(getattr(self, '_bdb_rows', []) or []):
            if i:
                t.insert('end', NL + NL)
            t.insert('end', '[Brown-Driver-Briggs (1906)]' + NL,
                     ('dict_src',))
            head = ' '.join(x for x in (r['translit_ko'], r['heb']) if x)
            t.insert('end', head + NL, ('dict_title',))
            t.insert('end', r['strong'] + NL, ('dict_src',))
            t.insert('end', r['body'], ('dict_body',))
        if not (getattr(self, '_bdb_rows', None)) and not append:
            t.insert('end', i18n.t('EB_NO_DICT', '(연결된 사전 항목 없음)'))
        t.config(state='disabled')
        if not append:
            t.see('1.0')

    def _n_dict_src(self):
        """이 항목이 가진 사전 원천 수 — [전체] 단추의 문턱."""
        return ((1 if getattr(self, '_strong_rows', None) else 0)
                + (1 if getattr(self, '_bdb_rows', None) else 0)
                + (1 if getattr(self, '_as_rows', None) else 0)
                + (1 if getattr(self, '_th_rows', None) else 0)
                + len({r[1] for r in (getattr(self, '_dict_rows', None) or ())})
                + (1 if getattr(self, '_bookd_rows', None) else 0))

    def _render_dict_all(self):
        """[전체] — 사전 원천을 **한 화면에 차례로** (2026-09-03 사용자 승인).

        순서 = 얕은 데서 깊은 데로: 정의(Strong) → 사전(BDB·A-S) →
        백과(Easton·Smith·Meyer) → 문헌(Girdlestone). 인물은 백과 2~3이
        엇비슷해 이어 읽기가 값이고, 용어는 층이 달라 「한 낱말의 전모」가
        값이다 — 두 갈래 다 이 순서가 자연스러운 독서 순서다.
        ⚠ 각 원천 렌더러를 append 모드로 재사용한다 — 여기서 다시 그리면
          원천을 늘릴 때마다 두 곳을 고치게 된다."""
        t = self._dict_txt
        t.config(state='normal')
        t.delete('1.0', 'end')
        NL = chr(10)
        first = [True]
        # ★ 용어설명이 없어 사전이 첫 화면인 경우 — 그 사실을 한 줄 (2026-09-15)
        if not (getattr(self, '_desc_body', '') or '').strip():
            t.insert('end', i18n.t('EB_LEX_NO_DESC',
                                   '이 낱말에는 아직 용어설명이 없어 사전을 보입니다.')
                     + NL + NL, ('dict_src',))
        if self._n_dict_src() < 1:
            t.insert('end', i18n.t('EB_NO_STRONG_DEF', '사전에 이 낱말의 항목이 없습니다.'))
            t.config(state='disabled')
            return

        def sep():
            if not first[0]:
                t.config(state='normal')
                t.insert('end', NL + NL)
            first[0] = False

        if getattr(self, '_strong_rows', None):
            sep()
            self._render_strong(append=True)
        if getattr(self, '_bdb_rows', None):
            sep()
            self._render_bdb(append=True)
        if getattr(self, '_as_rows', None):
            sep()
            self._render_absmith(append=True)
        if getattr(self, '_th_rows', None):
            sep()
            self._render_thayer(append=True)
        if getattr(self, '_dict_rows', None):
            sep()
            self._render_dict(append=True)
        if getattr(self, '_bookd_rows', None):
            sep()
            self._render_bookdict(append=True)
        t.config(state='disabled')
        t.see('1.0')

    def _render_thayer(self, append=False):
        """Thayer(1889) 갈래 (2026-09-03 189차) — 헬라 앵커마다 한 덩이.

        A-S 의 깊은 짝. 본문은 저자의 글(EN) 그대로 — 번역 안 함 정책 동일."""
        t = self._dict_txt
        t.config(state='normal')
        if not append:
            t.delete('1.0', 'end')
        NL = chr(10)
        for i, r in enumerate(getattr(self, '_th_rows', []) or []):
            if i:
                t.insert('end', NL + NL)
            t.insert('end', "[Thayer's Greek-English Lexicon (1889)]" + NL,
                     ('dict_src',))
            head = ' '.join(x for x in (r['translit_ko'], r['grk'],
                                        r['translit']) if x)
            t.insert('end', head + NL, ('dict_title',))
            t.insert('end', r['strong'] + NL, ('dict_src',))
            t.insert('end', r['body'], ('dict_body',))
        if not (getattr(self, '_th_rows', None)) and not append:
            t.insert('end', i18n.t('EB_NO_DICT', '(연결된 사전 항목 없음)'))
        t.config(state='disabled')
        if not append:
            t.see('1.0')

    def _render_bookdict(self, append=False):
        """낱말 분석 문헌 갈래 (2026-09-03 — 사용자 확정 「사전으로 명시한
        목록에 대해서만」). 유닛마다 한 덩이 — 책 순서(sequence)대로.
        본문은 저자의 글(EN) 그대로 — [Strong][BDB] 와 같은 정책."""
        t = self._dict_txt
        t.config(state='normal')
        if not append:
            t.delete('1.0', 'end')
        NL = chr(10)
        for i, r in enumerate(getattr(self, '_bookd_rows', []) or []):
            if i:
                t.insert('end', NL + NL)
            t.insert('end', '[%s]' % r['full'] + NL, ('dict_src',))
            if r['label']:
                t.insert('end', r['label'] + NL, ('dict_title',))
            t.insert('end', r['body'], ('dict_body',))
        if not (getattr(self, '_bookd_rows', None)) and not append:
            t.insert('end', i18n.t('EB_NO_DICT', '(연결된 사전 항목 없음)'))
        t.config(state='disabled')
        if not append:
            t.see('1.0')

    def _render_absmith(self, append=False):
        """Abbott-Smith(1922) 갈래 (2026-09-03 186차) — 헬라 앵커마다 한 덩이.

        BDB(_render_bdb)의 짝. 본문은 사람이 마크업한 TEI 전사 전문이라
        뜻 갈래 번호·구절 참조가 그대로 있다 — 저자의 글(EN)이라 번역하지
        않는다(한국어 결은 낱말 단추의 우리 글이 맡는다)."""
        t = self._dict_txt
        t.config(state='normal')
        if not append:
            t.delete('1.0', 'end')
        NL = chr(10)
        for i, r in enumerate(getattr(self, '_as_rows', []) or []):
            if i:
                t.insert('end', NL + NL)
            t.insert('end', '[Abbott-Smith, Manual Greek Lexicon (1922)]' + NL,
                     ('dict_src',))
            head = ' '.join(x for x in (r['translit_ko'], r['grk']) if x)
            t.insert('end', head + NL, ('dict_title',))
            meta = r['strong'] + (
                ' · NT %d' % r['occurs'] if r.get('occurs') else '')
            t.insert('end', meta + NL, ('dict_src',))
            t.insert('end', r['body'], ('dict_body',))
        if not (getattr(self, '_as_rows', None)) and not append:
            t.insert('end', i18n.t('EB_NO_DICT', '(연결된 사전 항목 없음)'))
        t.config(state='disabled')
        if not append:
            t.see('1.0')

    def _render_strong(self, append=False):
        """낱말 마스터(스트롱 1890) 갈래 — 앵커마다 한 덩이 (2026-09-02 178차).

        덩이 = 머리(음역·원어 글자·코드·품사·출현 수) + 어원 + 정의 + KJV
        옮김새 + **외부 사이트 링크 줄**(sys_ref_site scope='STRONG' — 표에
        한 줄 더하면 단추가 는다). 본문은 스트롱 원문(EN) 그대로 — 저자의
        글이라 번역하지 않는다(한국어 결 설명은 낱말 단추의 우리 글이 맡는다).
        """
        t = self._dict_txt
        t.config(state='normal')
        if not append:
            t.delete('1.0', 'end')
        NL = chr(10)
        import webbrowser
        import overlay_read as _or3
        # ★ 번역문(LEMMA_DEF · 그 언어 행)이 있으면 그것을, 없으면 영어 원문
        #   (2026-09-15 사용자 「번역된 다국어 표시, 없으면 영어 폴백」).
        _lang = self._desc_lang()
        _trs = {}
        try:
            with appdb.connect(self.db_path) as _ct:
                for r in getattr(self, '_strong_rows', []) or []:
                    _x = _or3.lemma_text(_ct, r['strong'], _lang)
                    if _x:
                        _trs[r['strong']] = _x
        except Exception:
            pass
        for i, r in enumerate(getattr(self, '_strong_rows', []) or []):
            if i:
                t.insert('end', NL + NL)
            t.insert('end', "[Strong's Dictionary (1890)]" + NL, ('dict_src',))
            head = ' '.join(x for x in (r['translit_ko'], r['form'],
                                        '(%s)' % r['translit'] if r['translit'] else '') if x)
            t.insert('end', head + NL, ('dict_title',))
            meta = ' · '.join(x for x in (
                r['strong'], r['pos'],
                ('%d×' % r['occ']) if r['occ'] else '') if x)
            t.insert('end', meta + NL, ('dict_src',))
            if r['strong'] in _trs:
                t.insert('end', _trs[r['strong']] + NL, ('dict_body',))
            else:
                if r['deriv']:
                    t.insert('end', r['deriv'] + NL, ('dict_body',))
                if r['def_en']:
                    t.insert('end', r['def_en'] + NL, ('dict_body',))
                if r['kjv']:
                    t.insert('end', 'KJV: ' + r['kjv'] + NL, ('dict_body',))
            # 외부 사이트 — 그 낱말 페이지로 바로
            for j, (code, name, tmpl) in enumerate(
                    getattr(self, '_strong_sites', []) or []):
                url = _or3.strong_url(tmpl, r['strong'])
                tag = 'st_lnk_%d_%d' % (i, j)
                if j:
                    t.insert('end', '  ')
                t.insert('end', name, ('dict_link', tag))
                t.tag_bind(tag, '<Button-1>',
                           lambda _e, u=url: webbrowser.open(u))
                t.tag_bind(tag, '<Enter>',
                           lambda _e, w=t: w.config(cursor='hand2'))
                t.tag_bind(tag, '<Leave>',
                           lambda _e, w=t: w.config(cursor='arrow'))
        if not (getattr(self, '_strong_rows', None)) and not append:
            t.insert('end', i18n.t('EB_NO_DICT', '(연결된 사전 항목 없음)'))
        t.config(state='disabled')
        if not append:
            t.see('1.0')

    def _render_dict(self, have=None, append=False):
        _src_name = {c: full for c, _s, full in self._DICT_SRC}
        self._dict_txt.config(state='normal')
        if not append:
            self._dict_txt.delete('1.0', 'end')
        # append([전체]) 때는 갈래 필터를 안 건다 — _dict_src 가 ALLD 라
        # 사전 코드와 안 맞아 0건이 된다(백과 전부를 이어 그린다).
        rows = (list(self._dict_rows) if append else
                [r for r in self._dict_rows
                 if self._dict_src is None or r[1] == self._dict_src])
        if not rows and append:
            self._dict_txt.config(state='disabled')
            return
        if not rows:
            if self._dict_src and self._dict_rows:
                # 다른 사전에는 있는데 고르던 사전이 이 항목에 없다 — 이름을 댄다
                msg = i18n.t(
                    'EB_NO_DICT_SRC',
                    '「{src}」 사전에는 이 항목이 없습니다. 위 버튼에서 다른 사전을 선택하세요.'
                ).format(src=_src_name.get(self._dict_src, self._dict_src))
            else:
                msg = i18n.t('EB_NO_DICT', '(연결된 사전 항목 없음)')
            self._dict_txt.insert('1.0', msg)
            self._dict_txt.config(state='disabled')
            return
        first = True
        for label, src_code, body_text in rows:
            if not first:
                self._dict_txt.insert('end', '\n\n')
            first = False
            src_name = _src_name.get(src_code, src_code)
            self._dict_txt.insert('end', f'[{src_name}]\n', ('dict_src',))
            self._dict_txt.insert('end', f'{label}\n', ('dict_title',))
            self._dict_txt.insert('end', body_text or i18n.t('MSG_NO_BODY', '(본문 없음)'),
                                  ('dict_body',))
        self._dict_txt.config(state='disabled')
        if not append:
            self._dict_txt.see('1.0')

    def _open_inline_player(self):
        """현재 엔티티의 미디어를 PyQt 인라인 플레이어(별도 창)로 띄운다.
        4개 영역 공용 표준 모듈 media_player.launch() 사용. YouTube 는 인라인 재생,
        비-YouTube 는 플레이어 내 [브라우저에서 열기]."""
        eid = getattr(self, '_current_eid', None)
        if not eid:
            return
        # ⚠ 갈래 이름을 여기서 다시 적지 않는다. Links 패널이 쓰는 `MEDIATYPE_*` 를
        #   그대로 쓴다 — 두 곳에 적으면 같은 영상이 화면마다 다른 이름으로 불린다.
        def _mtag(mt):
            try:
                from links_panel import MEDIA_TYPE_LABEL as _L
            except Exception:
                _L = {}
            return '[%s]' % i18n.t('MEDIATYPE_' + str(mt), _L.get(mt, mt))
        try:
            import overlay_read
            with appdb.connect(self.db_path) as conn:
                _lc = (self.lang_getter() if callable(self.lang_getter) else 'KO') or 'KO'
                # ★ 조회는 링크 탭과 **같은 문**(overlay_read.media) — 내 링크도
                #   재생 목록에 들어오고, 가린 것은 안 들어온다.
                rows = overlay_read.media(conn, eid, 'VIDEO', _lc)
                nm = conn.execute(
                    "SELECT contents FROM sys_text_asset "
                    "WHERE clicked_id=? AND text_type='ENTITY_NAME' "
                    "  AND lang_code IN (?,'EN','KO') AND record_status='LIVE' "
                    "ORDER BY CASE lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                    (eid, _lc, _lc)).fetchone()
        except Exception as e:
            print(f'[inline player] {e}')
            return
        videos = [{'title': d['title'], 'url': d['url'],
                   'tag': _mtag(d['mtype'])}
                  for d in rows if d['src'] != 'HIDE' and d['yt']]
        if not videos:
            from tkinter import messagebox
            messagebox.showinfo(
                i18n.t('MSG_T_INLINEVIDEO', '인라인 영상'),
                i18n.t('EB_NO_VIDEO',
                       '재생할 YouTube 영상이 없습니다.\n'
                       '(승인된 영상이 없거나 아직 수집 전입니다.)'))
            return
        title = i18n.t('EB_RELATED_VIDEO', '{name} — 관련 영상').format(
            name=(nm[0] if nm else i18n.t('EB_RELATED', '관련')))
        try:
            import media_player
            if media_player.launch(title, videos):
                return
        except Exception as e:
            print(f'[inline player] {e}')
        # 폴백: 첫 영상 브라우저
        if videos:
            webbrowser.open(videos[0]['url'])

    def _embed_play(self, video_id: str):
        """우측 임베드 패널에서 YouTube 영상 인라인 재생 (탭 안 좌우 분할)."""
        if not self._embed_host or not video_id or media_player is None:
            return
        if self._embed_player is None:
            # 안내 라벨 제거 후 플레이어 생성
            for w in self._embed_host.winfo_children():
                w.destroy()
            self._embed_player = media_player.EmbeddedPlayer(self._embed_host)
        self._embed_player.play(video_id)

    def _on_destroy_cleanup(self, event):
        if event.widget is self and self._embed_player is not None:
            try:
                self._embed_player.stop()
            except Exception:
                pass
            self._embed_player = None

    def _set_link_tab_counts(self, nv: int, nt: int):
        """영상링크/텍스트링크 개수 — **라벨은 `_apply_tab_prefs` 가 적는다.**"""
        if not hasattr(self, '_tab_n'):
            self._tab_n = {}
        self._tab_n['VIDEO'] = int(nv or 0)
        self._tab_n['TEXT'] = int(nt or 0)
        self._apply_tab_prefs()

    def _set_url_tab_count(self, n: int):
        """옛 이름 — 오류 경로 호환(합계만 알 때는 영상 쪽에만 적는다)."""
        self._set_link_tab_counts(n, 0)

    def _load_songs(self, entity_id: int):
        """그 용어의 찬양 — 곡이 없으면 **탭을 잠근다**(빈 서랍 금지).

        ⚠ 패널은 **쓸 때 만든다**(§29 지연) — 대부분의 용어에는 곡이 없다.
        """
        idx = getattr(self, '_song_subtab_index', None)
        n = 0
        try:
            import appdb as _ad, db_song as _S
            _c = _ad.connect(self.db_path)
            n = len(_S.songs_of_entity(_c, entity_id,
                                       (self.lang_getter() or 'KO').upper()))
            _c.close()
        except Exception:
            n = 0
        if n and self._song_panel is None:
            try:
                import song_panel
                self._song_panel = song_panel.SongPanel(
                    self._song_host, self.db_path,
                    lang_getter=lambda: (self.lang_getter() or 'KO'))
                self._song_panel.pack(fill='both', expand=True)
            except Exception as _e:
                print('[EntityBrowser] 찬양 패널: %s' % _e)
        if self._song_panel is not None:
            try:
                self._song_panel.load_entity(entity_id)
            except Exception:
                pass
        # ★ 라벨·잠금은 `_apply_tab_prefs` 한 곳 — 갈래마다 따로 적지 않는다
        self._set_tab_n('SONG', int(n or 0))

    def _load_media_urls(self, entity_id: int):
        # 엔티티 전환 시 우측 임베드 패널 비우기 (직전 영상 잔상 제거)
        if self._embed_player is not None:
            try:
                self._embed_player.clear()
            except Exception:
                pass
        self._url_tv.delete(*self._url_tv.get_children())
        self._url_items = {}
        # ★★★ 조회는 `overlay_read.media` **한 문**이다 (C 단계 — 2026-08-27).
        #   예전에는 sys 만 읽어서 **팝업으로 넣은 내 링크가 이 탭에 없었다**
        #   (갈렙 텍스트링크 사고). 이제 sys+내 것이 합쳐 오고 가린 것(H)은
        #   읽는 화면이라 뺀다(overlay_mark 규칙).
        try:
            import overlay_read
            with appdb.connect(self.db_path) as conn:
                _lc = (self.lang_getter() if callable(self.lang_getter) else 'KO') or 'KO'
                rows = overlay_read.media(conn, entity_id, 'ALL', _lc)
        except Exception as e:
            self._set_url_tab_count(0)
            print(f'[EntityBrowser] _load_media_urls: {e}')
            return

        # ★ 두 서브탭을 함께 채운다 (2026-09-02 승격) — 영상(인라인 재생) ↔
        #   텍스트(브라우저). 판정은 `media_link.yt_id` 가 단일 소스.
        if hasattr(self, '_txt_tv'):
            self._txt_tv.delete(*self._txt_tv.get_children())
        self._txt_items = {}
        shown = [d for d in rows if d['src'] != 'HIDE']     # 읽는 화면 = H 제외
        import overlay_mark as _om
        _om.configure_tree(self._url_tv)
        if hasattr(self, '_txt_tv'):
            _om.configure_tree(self._txt_tv)
        nv = nt = 0
        for d in shown:
            is_video = bool(d['yt'])
            tv = self._url_tv if is_video else getattr(self, '_txt_tv', None)
            if tv is None:
                continue
            kind = (i18n.t('EB_MY_LINK', '내 링크') if d['is_user']
                    else mlv.kind_label(d['mtype'], d['ftype'], d['aud']))
            channel = '' if d['is_user'] else mlv.channel_of(d['desc'])
            mk = _om.mark_of(d['src'], for_reading=True)
            iid = tv.insert(
                '', 'end',
                # ⚠⚠ **칸 수는 표준(mlv.COLS 7칸)과 같아야 한다** — 2026-08-30
                #   표준에 범위(scope) 칸이 더해졌는데 여기만 6값이라 **값이
                #   한 칸씩 밀려** 제목이 언어 칸 밑에, ★ 이 제목 칸 밑에
                #   그려졌다(2026-09-03 사용자 신고 「목록에 표시된 제목과
                #   실제 목록이 일치하지 않는다」). 범위 칸은 용어 화면에서
                #   무의미라 빈 값 + 폭 0.
                values=(mlv.PICK_OFF, '', d['lang'], kind,
                        _om.prefix(d['title'], mk), channel,
                        mlv.fav_mark(d['is_fav'])),
                tags=((_om.tag_name(mk),) if mk else
                      (('fav',) if d['is_fav'] else ('row',))))
            # ⚠ 내 링크는 fav 토글 금지 — `user_media_fav` 는 sys media_id 용이라
            #   내 번호를 넣으면 엉뚱한 sys 미디어에 ★ 이 붙는다. mid=None.
            rec = (None if d['is_user'] else d['mid'], d['url'],
                   d['yt'] if self._embed_enabled else None)
            if is_video:
                self._url_items[iid] = rec
                nv += 1
            else:
                self._txt_items[iid] = rec
                nt += 1
        self._set_link_tab_counts(nv, nt)

    # ── 링크 갈래 — 영상 / 텍스트 (2026-08-26) ─────────────────────
    def _link_focus(self, on):
        """P4 를 전체 폭으로 — 연구자료 탭이 쓰는 장치를 그대로 쓴다.

        ⚠ 이 패널은 P4 안에 살지만 **확장 장치는 앱(user_main)의 것**이다.
          최상위로 올라가 찾는다. 없으면 조용히 아무 일도 안 하지 않고 알린다.
        """
        root = self.winfo_toplevel()
        fn = getattr(root, 'activate_p4_focus_mode' if on
                     else 'deactivate_p4_focus_mode', None)
        if not callable(fn):
            print('[EntityBrowser] focus: 앱에 확장 장치가 없다')
            return
        try:
            fn()
        except Exception as e:
            print('[EntityBrowser] focus: %s' % e)
            return
        # ★ 왼쪽 용어 트리도 함께 접는다 (2026-09-01 0.txt 5번 사용자 지시 —
        #   「가장 왼쪽의 용어 트리는 제외하고 영상링크 목록 + 영상표시화면만
        #   확대할 것」). 사시를 0 으로 밀고, Restore 때 원 자리로 되돌린다.
        if not self._compact:
            try:
                if on:
                    self._lk_saved_sash = self._h_pw.sash_coord(0)[0]
                    self._h_pw.sash_place(0, 0, 1)
                else:
                    self._h_pw.sash_place(
                        0, int(getattr(self, '_lk_saved_sash', 240) or 240), 1)
            except Exception as e:
                print('[EntityBrowser] focus sash: %s' % e)
        self._lk_focused = bool(on)
        # (단추는 안 그린다 — 2026-09-16 1.txt 28)

    def _load_entity_refs(self, entity_id: int):
        """[관] 엔티티 연결 참고자료 — sys_ref_asset (대표 entity_id ∪ sys_ref_asset_link ENTITY)."""
        if not hasattr(self, '_refa_tv'):
            return
        self._refa_tv.delete(*self._refa_tv.get_children())
        self._refa_items = {}
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT DISTINCT a.ref_id, a.lang_code, a.title, a.source_name, a.url "
                    "FROM sys_ref_asset a "
                    "WHERE a.record_status='LIVE' AND a.is_active=1 "
                    "  AND (a.entity_id=? OR a.ref_id IN ("
                    # ★ 2026-08-24 통합 표(`RSSA_ENTI`)
                    "       SELECT clicked_id FROM sys_link_asset "
                    "       WHERE link_type='RSSA_ENTI' AND target_id=? "
                    "         AND COALESCE(record_status,'LIVE')='LIVE')) "
                    "ORDER BY a.ref_id DESC",
                    (entity_id, entity_id)).fetchall()
        except Exception as e:
            print(f'[EntityBrowser] _load_entity_refs: {e}')
            return
        for ref_id, lang, title, source, url in rows:
            disp = title or source or i18n.t('REFR_NOTITLE', '(제목없음)')
            iid = self._refa_tv.insert('', 'end',
                                       values=(lang or '', disp))
            self._refa_items[iid] = url or ''
        # 라벨에 개수 표시
        try:
            self._refa_tv.master.config(
                text=i18n.t('EB_REF_ARTICLES', '참고자료') + f' ({len(rows)})')
        except Exception:
            pass

    def _on_refa_click(self, _event):
        sel = self._refa_tv.selection()
        if not sel:
            return
        url = self._refa_items.get(sel[0])
        if url:
            webbrowser.open(url)

    def _on_url_click(self, event):
        # ★ 영상/텍스트 두 트리가 같은 핸들러를 쓴다 (2026-09-02 승격) —
        #   event.widget 이 어느 탭인지 말한다.
        tv = event.widget
        items = (self._url_items if tv is self._url_tv
                 else getattr(self, '_txt_items', {}))
        if tv.identify_region(event.x, event.y) != 'cell':
            return
        iid = tv.identify_row(event.y)
        if not iid or iid not in items:
            return
        mid, url, yt = items[iid]
        if tv.identify_column(event.x) == mlv.FAV_COL:
            if mid is None:
                return                      # 내 링크 — fav 는 sys 미디어 전용
            res = mlv.toggle_fav(self.db_path, mid)
            if res:
                _state, mark, tag = res
                vals = list(tv.item(iid, 'values'))
                vals[6] = mark              # fav = 표준 7칸의 마지막(#7)
                tv.item(iid, values=vals, tags=(tag,))
            return
        if yt:
            self._embed_play(yt)            # YouTube → 우측 인라인 재생
        elif url:
            webbrowser.open(url)            # 비-YouTube → 브라우저

    def _load_linked(self, entity_id: int):
        """연결구절 목록 — 단락 행(ENTI_PERI) + 낱말 행(ENTI_VERS) 한 목록.

        (2026-08-26 통합 — 옛 `_load_pericopes` + `_load_lex` 를 합쳤다.)"""
        if not hasattr(self, '_link_tv'):
            return
        self._peri_rows = []
        self._right_desc = None
        self._right_anchor = None
        self._cur_range = None
        self._fill(self._verse_txt, '')
        self._verse_title_lbl.config(
            text=i18n.t('EB_LINK_HINT', '목록에서 줄을 선택하세요'))
        self._paint_ctx_btn(enabled=False)
        # ★ 승격 안 된 낱말 — 단락 연결은 없고 낱말 절만(`sys_verse_lemma`).
        #   낱말 단추 하나(그 번호)로 용어 화면과 같은 목록을 그린다(2026-09-15).
        if getattr(self, '_current_strong', None):
            st = self._current_strong
            info = getattr(self, '_lex_info', {}) or {}
            for b in self._lex_btns.values():
                b.destroy()
            self._lex_btns = {}
            self._lex_all = False
            self._lex_lemmas = [(st, info.get('lang', ''), st,
                                 info.get('translit', ''), info.get('gloss', ''),
                                 info.get('n_verse', 0))]
            self._lex_lemma = st
            b = tk.Button(self._lex_btnbar, bd=1, padx=8, pady=1, cursor='hand2',
                          font=('', 8),
                          text='%s %s %d' % (info.get('translit', ''), st,
                                             info.get('n_verse', 0) or 0))
            b.pack(side='left', padx=(0, 4))
            self._lex_btns[st] = b
            if not self._lex_btnbar.winfo_ismapped():
                self._lex_btnbar.pack(fill='x', padx=6, pady=(6, 2),
                                      before=self._link_pw)
            self._linked_fill(None)
            return

        try:
            with appdb.connect(self.db_path) as conn:
                lang = self.lang_getter() or 'KO'
                book_lang = _ref_lang()      # ★ 약명은 **역본**을 따른다(표시언어 아님)
                rows = conn.execute(
                    "SELECT ep.sys_link_id, ep.target_id, "
                    "       (ep.milestone_type IS NOT NULL), "
                    "       ep.milestone_type, ep.rel_code, ep.importance, "
                    "       pa.start_vid, pa.end_vid, "
                    "  (SELECT ta.contents FROM sys_text_asset ta "
                    "   WHERE ta.text_type='PERI_TITLE' AND ta.clicked_id=ep.target_id "
                    "   AND ta.lang_code IN (?,'EN','KO') AND ta.record_status='LIVE' "
                    "   ORDER BY CASE ta.lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1) AS title, "
                    "  (SELECT ta.contents FROM sys_text_asset ta "
                    "   WHERE ta.text_type='ENTITY_PERI_DESC' AND ta.clicked_id=ep.sys_link_id "
                    "   AND ta.lang_code IN (?,'EN','KO') AND ta.record_status='LIVE' "
                    "   ORDER BY CASE ta.lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1) AS ep_desc, "
                    "  (SELECT ta.contents FROM sys_text_asset ta "
                    "   WHERE ta.text_type='PERI_DESC' AND ta.clicked_id=ep.target_id "
                    "   AND ta.lang_code IN (?,'EN','KO') AND ta.record_status='LIVE' "
                    "   ORDER BY CASE ta.lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1) AS peri_desc, "
                    "  bn.short_name, bi1.chapter, bi1.verse, bi2.chapter, bi2.verse "
                    # ★ 2026-08-24 통합 표(`ENTI_PERI`). role_in_peri→rel_code ·
                    #   is_milestone 은 milestone_type 유무로 판정한다(중복 칸이었다).
                    "FROM sys_link_asset ep "
                    "JOIN sys_pericope_asset pa ON pa.pericope_id=ep.target_id "
                    "JOIN bible_index bi1 ON bi1.verse_id=pa.start_vid "
                    "JOIN bible_index bi2 ON bi2.verse_id=pa.end_vid "
                    "LEFT JOIN book_names bn ON bn.book_code=bi1.bcode AND bn.lang_code=? "
                    "WHERE ep.link_type='ENTI_PERI' AND ep.clicked_id=? "
                    "  AND COALESCE(ep.record_status,'LIVE')='LIVE' "
                    "  AND pa.record_status='LIVE' AND pa.peri_type='BODY' "
                    "ORDER BY (ep.milestone_type IS NOT NULL) DESC, ep.importance DESC",
                    (lang, lang, lang, lang, lang, lang, book_lang, entity_id)
                ).fetchall()
        except Exception as e:
            print(f"[EntityBrowser] _load_linked error: {e}")
            rows = []

        for r in rows:
            (ep_id, peri_id, is_ms, ms_type, role, imp, sv, ev,
             title, ep_desc, peri_desc,
             bk, c1, v1, c2, v2) = r

            title = title or ''
            c2v2  = f'{c1}:{v1}~{v2}' if c1 == c2 else f'{c1}:{v1}~{c2}:{v2}'
            rng   = f'{bk or ""}{c2v2}'
            # 마일스톤 대표값(부르심·훈련 등)은 살리고 ★ 는 뗀다(2026-08-26 지시)
            ms_ko  = (i18n.t('ENTITY_MS_' + str(ms_type),
                             _MILESTONE_KO.get(ms_type, ''))
                      if ms_type and ms_type in _MILESTONE_KO else '')
            self._peri_rows.append(dict(
                ep_id=ep_id, pericope_id=peri_id, is_milestone=is_ms,
                ms_type=ms_type, ms_label=ms_ko, role=role, importance=imp,
                title=title or rng, rng=rng,
                start_vid=sv, end_vid=ev, ep_desc=ep_desc or '',
                peri_desc=peri_desc or '',
            ))

        # 낱말(원어 앵커) — 있는 엔티티에서만 버튼 줄이 나타난다
        import db_term_load as T
        self._lex_all = False
        try:
            with appdb.connect(self.db_path) as conn:
                self._lex_lemmas = T.fetch_lemma_rows(conn, entity_id)
        except Exception as e:
            print(f"[EntityBrowser] _load_linked lemma error: {e}")
            self._lex_lemmas = []
        for b in self._lex_btns.values():
            b.destroy()
        self._lex_btns = {}
        order = sorted(self._lex_lemmas, key=lambda r: -r[5])
        self._lex_lemma = order[0][0] if order else None
        if self._lex_lemmas:
            for lid, _lg, strong, tr, _gl, n in self._lex_lemmas:
                b = tk.Button(self._lex_btnbar, bd=1, padx=8, pady=1, cursor='hand2',
                              font=('', 8),
                              text='%s %s %d' % (tr or '', strong or '', n),
                              command=lambda i=lid: self._set_lex_lemma(i))
                b.pack(side='left', padx=(0, 4))
                self._lex_btns[lid] = b
            if not self._lex_btnbar.winfo_ismapped():
                self._lex_btnbar.pack(fill='x', padx=6, pady=(6, 2),
                                      before=self._link_pw)
        else:
            self._lex_btnbar.pack_forget()

        self._linked_fill(entity_id)

    def _update_link_subtab_label(self, n_total):
        """용례구절 개수 — **필수 갈래라 0건이어도 안 잠근다**(2026-09-17).

        라벨·상태는 `_apply_tab_prefs` 한 곳이 적는다.
        """
        if not hasattr(self, '_center_nb'):
            return
        if not hasattr(self, '_tab_n'):
            self._tab_n = {}
        self._tab_n['LINK'] = int(n_total or 0)
        self._apply_tab_prefs()

    # ── 연결구절 목록 채우기 (의미 + 낱말) ─────────────────────────────────
    _LEX_HEAD_N = 25                 # 낱말 행에서 처음에 보이는 줄 수

    @staticmethod
    def _mk_ref(nm, ch, v):
        # CJK 약명은 붙이고 라틴은 한 칸(§54 표기 규칙)
        sep = '' if nm and ord(nm[0]) > 0x2E80 else ' '
        return f'{nm}{sep}{ch}:{v}'

    def _linked_fill(self, entity_id):
        """목록을 그린다 — 의미 행(단락 + THEMATIC 절) 먼저, 그 뒤 낱말 행.

        구분값 둘이 층을 가른다(2026-08-26 사용자 「두가지 유형을 적절하게 잘
        대표할 단어를 구분값으로 표시하라」):
          의미 = 사람이 이은 연결(단락 ENTI_PERI + 절 THEMATIC) — 설명문이 본체
          낱말 = 원어 앵커에서 기계로 나온 절(LEXICAL) — 색인, 설명문 없음
        ⚠ ◈(설명문 있음)·시대 칸·「의미」 들여쓰기는 2026-09-15 항목 ③ 에서 걷었다.
        ⚠ 빈도가 23배 차이난다(샤마 1,072절 · 바라 46절) — 낱말 행은
          **대표 먼저 · 나머지는 [더 보기]** 그대로다.
        """
        import db_term_load as T
        import overlay_mark as _om
        tv = self._link_tv
        tv.delete(*tv.get_children())
        _om.configure_tree(tv)   # 표식 색은 그릴 때마다(§36-5b)
        self._link_info = {}
        kind_m = i18n.t('EB_KIND_MEANING', '의미')
        kind_w = i18n.t('EB_KIND_WORD', '낱말')

        # ★★ **구분 칸이 연결의 성격을 말한다** (2026-09-24 · 1.txt 15번 4)
        #   「연결구절의 성격을 구분하는 별도구분값 필요」).
        #   성격이 없으면(기본 THEMATIC) 종전대로 「의미」다 — 이름이 바뀌면
        #   사용자가 쓰던 화면이 까닭 없이 달라진다.
        #   ⚠ 이름은 `rel_vocab` 한 곳에서 온다(화면이 또 적지 않는다).
        _rel_nm, _used_kinds = {}, set()

        def _kind_label(rel):
            r = (rel or T.MEANING_DEFAULT)
            if r == T.MEANING_DEFAULT:
                return kind_m
            _used_kinds.add(r)
            if r not in _rel_nm:
                try:
                    import rel_vocab as _rv
                    with appdb.connect(self.db_path) as _cn:
                        _rel_nm[r] = _rv.name(_cn, 'ENTI_VERS', r, lang)
                except Exception:
                    _rel_nm[r] = r
            return _rel_nm[r] or kind_m
        # ★ 이 낱말이 우리말로 갈리는가 — 갈릴 때만 절마다 표시한다(2026-09-07)
        _lex_rend = []
        lang = (self.lang_getter() or 'KO').upper() if callable(getattr(self, 'lang_getter', None)) else 'KO'


        # ★ 갈래 칸 재료 — (엔티티, 절) → 원천/십자가/확산. 값이 없으면 빈 칸.
        _br_map, _br_names = {}, {
            'SRC': i18n.t('EB_BR_SRC', '원천'),
            'CROSS': i18n.t('EB_BR_CROSS', '십자가'),
            'OUT': i18n.t('EB_BR_OUT', '확산')}
        try:
            import db_term_branch as _tb
            if entity_id:
                with appdb.connect(self.db_path) as _cb:
                    _br_map = _tb.branch_map(_cb, entity_id)
        except Exception:
            pass

        def _bname(vid):
            return _br_names.get(_br_map.get(vid), '')

        # ★ 갈래 값이 하나도 없으면 칸 폭 0 (2026-09-02 UI 점검 ③ — 빈 칸
        #   52px 가 좁은 패널에서 내용 칸만 줄였다. 서재 pick 칸 문법)
        try:
            if _br_map:
                tv.column('branch', width=52, minwidth=44, stretch=False)
            else:
                tv.column('branch', width=0, minwidth=0, stretch=False)
        except Exception:
            pass

        # ① 의미 — 단락 행 (마일스톤·중요도 순서는 SQL 이 정했다)
        for pr in self._peri_rows:
            txt = pr['title']
            if pr['ms_label']:
                txt += f" · {pr['ms_label']}"
            # ⚠ ◈(설명문 있음) 접두를 걷었다(2026-09-15 항목 ③) — 오른쪽이
            #   글을 보이면 그것이 곧 표시다. 「구분」 칸이 갈래를 이미 말한다.
            iid = f"P{pr['pericope_id']}"
            tv.insert('', 'end', iid=iid,
                      values=(kind_m, '', pr['rng'], txt),
                      tags=('milestone',) if pr['is_milestone'] else ())
            self._link_info[iid] = dict(kind='P', pr=pr)

        them, n_words = [], 0
        try:
            with appdb.connect(self.db_path) as conn:
                ver = self._get_version(conn)

                def _vrow(vid):
                    r = conn.execute('SELECT bcode,chapter,verse FROM bible_index'
                                     ' WHERE verse_id=?', (vid,)).fetchone()
                    if not r:
                        return None, ''
                    nm = conn.execute('SELECT short_name FROM book_names'
                                      ' WHERE book_code=? AND lang_code=? LIMIT 1',
                                      (r[0], lang)).fetchone()
                    ref = self._mk_ref(nm[0] if nm else r[0], r[1], r[2])
                    # ★ 합쳐진 절·없는 절도 뜻이 통하게(§verse_text)
                    return ref, _vt.resolve(conn, vid, ver, lang)['text']

                # 표식 재료 — 내 절 연결(있으면 sys 짝이 있는지로 E/N 이 갈린다)
                _umk = {}
                try:
                    for _t, _e, _st in ([] if not entity_id else conn.execute(
                            "SELECT target_id, COALESCE(end_id,target_id), "
                            "COALESCE(record_status,'LIVE') "
                            "FROM userdb.user_link_asset WHERE link_type='ENTI_VERS'"
                            " AND clicked_id=?", (entity_id,))):
                        _has = conn.execute(
                            "SELECT 1 FROM sys_link_asset WHERE link_type='ENTI_VERS'"
                            " AND clicked_id=? AND target_id=?"
                            " AND COALESCE(record_status,'LIVE')='LIVE'",
                            (entity_id, _t)).fetchone()
                        _umk[(_t, _e)] = ('HIDE' if _st == 'HIDE'
                                          else ('EDIT' if _has else 'NEW'))
                except Exception as _e2:
                    print('[EntityBrowser] user link marks: %s' % _e2)

                # ② 의미 — 사람이 이은 절(THEMATIC). 낱말 필터와 무관하게 늘 보인다.
                #   (앵커 1~3절 + 설명문 의무 — entity.md §3. 낱말이 없는 절이라
                #    낱말 행과 겹치지 않는다.)
                _st_lemma = getattr(self, '_current_strong', None)
                # ⚠ **의미 층 전부**를 묻는다 — 등호로 좁히면 성격값이 있는
                #   절이 목록에서 조용히 사라진다(`db_term_load.MEANING_KINDS`).
                them = ([] if _st_lemma else
                        T.fetch_verses(conn, entity_id, kind=T.MEANING_KINDS,
                                       lang=lang))
                # ★★ **내가 더한 절 연결도 여기 나와야 한다** (2026-08-26).
                #   `fetch_verses` 는 배포 표만 읽는다 — 그것만 쓰면 MY 창에서
                #   더한 연결이 **목록에 아예 안 보인다**(실측으로 잡았다).
                #   가린 것은 뺀다(읽는 목록이다).
                # ★★★ **다섯째 칸 = 구간 끝**(2026-09-01) — 용어마다 제 폭을
                #   갖는다. `창1:3~5` 처럼 고정 단락에 안 맞춰도 된다.
                _sysv = {v for v, _k, _i, _n, _e in them}
                for _k2, _st in sorted(_umk.items()):
                    if _st == 'HIDE' or _k2[0] in _sysv:
                        continue
                    them = list(them) + [(_k2[0], T.MEANING_DEFAULT, 0, '',
                                          _k2[1])]
                for vid, _kind, _is_key, note, _endv in them:
                    if _umk.get((vid, vid)) == 'HIDE':
                        continue          # 내가 가린 sys 연결
                    ref, body = _vrow(vid)
                    if ref is None:
                        continue
                    # ⚠ 범위 표기는 **`link_picker.scope_label` 한 곳**이 짓는다
                    #   (§114차) — 화면마다 지어내면 `창1:3~5` 와 `창 1:3-5` 가
                    #   섞인다. 한 절이면 빈 칸을 돌려주므로 그대로 쓴다.
                    if _endv and _endv != vid:
                        try:
                            import link_picker as _lp
                            _rg = _lp.scope_label(conn, vid, _endv, lang)
                            if _rg:
                                ref = _rg
                        except Exception as _e3:
                            print('[EntityBrowser] scope_label: %s' % _e3)
                    # ★ N/E/H — 사람이 이은 절 연결은 내가 더하거나 고칠 수
                    #   있다(MY 창). 가린 것은 여기 안 나온다(읽는 목록).
                    _mk = _om.mark_of(_umk.get((vid, vid), 'SYS'),
                                      for_reading=True)
                    iid = tv.insert('', 'end',
                                    tags=((_om.tag_name(_mk),) if _mk
                                          else ('thematic',)),
                                    # ⚠ 표식이 없으면 **들여쓰기도 없다**
                                    #   (2026-09-15 항목 ③ — `_om.prefix` 의
                                    #   빈 칸이 「의미」 행만 안으로 밀었다).
                                    values=(_kind_label(_kind), _bname(vid), ref,
                                            (_om.prefix(bidi.for_display(body[:120]), _mk)
                                             if _mk else bidi.for_display(body[:120]))))
                    self._link_info[iid] = dict(kind='V', vid=vid, ref=ref,
                                                note=note or '')

                # ③ 낱말 — LEXICAL 만, 지금 고른 낱말로 가른다(entity.md ②)
                if _st_lemma:
                    # 낱말 — 그 번호가 있는 절 전부(대표 표식은 아직 없다)
                    import db_lex_link as _LL
                    rows = [(v, 'LEXICAL', 0, '', None)
                            for v in _LL.verses_of(conn, _st_lemma)]
                else:
                    rows = T.fetch_verses(conn, entity_id, lang=lang,
                                          lemma_id=self._lex_lemma)
                    # ⚠ 의미 층은 위에서 이미 그렸다 — 목록으로 뺀다(등호로
                    #   빼면 성격값이 있는 절이 **낱말 행으로 두 번** 나온다)
                    rows = [r for r in rows if r[1] not in T.MEANING_KINDS]
                n_words = len(rows)

                # 고른 낱말의 설명 — 절을 고르기 전 오른쪽 기본 글
                cur = next((r for r in self._lex_lemmas
                            if r[0] == self._lex_lemma), None)
                self._lex_lemma_head = ('%s %s' % (cur[3] or '', cur[2] or '')).strip() if cur else ''
                note = (T.fetch_lemma_note(conn, self._lex_lemma, lang)
                        if (self._lex_lemma and not _st_lemma) else '')
                self._lex_lemma_note = note or (cur[4] if cur else '') or ''
                self._lex_rend_sum = ''
                # ★ 낱말 마스터 보강 (2026-09-02 178차) — 우리 글 아래에
                #   스트롱 신원 한 줄 + KJV 옮김새. 마스터가 없으면 그대로.
                if cur:
                    try:
                        import overlay_read as _or4
                        _m = next((x for x in (
                            _or4.strong_entries_for(conn, [(cur[2], cur[3] or '')])
                            if _st_lemma else _or4.strong_entries(conn, entity_id))
                                   if x['strong'] == cur[2]), None)
                        if _m:
                            _line = ' · '.join(x for x in (
                                _m['strong'], _m['form'], _m['pos'],
                                ('%d×' % _m['occ']) if _m['occ'] else '') if x)
                            _tail = _line
                            if _m['kjv']:
                                _tail += chr(10) + 'KJV: ' + _m['kjv']
                            self._lex_lemma_note = (
                                (self._lex_lemma_note + chr(10) + chr(10))
                                if self._lex_lemma_note else '') + _tail
                    except Exception:
                        pass
                    # ★★★ **개역한글 옮김새**(2026-09-07 사용자 지시 —
                    #   「원어가 한글로 다양하게 번역된 사실을 알 수 있도록」).
                    #   ★ `KJV:` 줄 바로 아래 — 영어 옮김새의 우리말 짝이다.
                    #   ⚠ **갈리지 않으면 안 그린다**(§0-1 빈 서랍).
                    #   ⚠ 개수는 **절 수**다 — 한 절에 두 번 나와도 하나로 센다.
                    try:
                        import db_lemma_render as _lr
                        _rs = _lr.summary(conn, cur[2])
                        if _rs:
                            _lex_rend = _lr.renders_of(cur[2])
                            self._lex_rend_sum = _rs
                            self._lex_lemma_note = (
                                (self._lex_lemma_note + chr(10))
                                if self._lex_lemma_note else '') + (
                                i18n.t('EB_LEX_RENDER', '개역한글 옮김새(절 수)')
                                + ': ' + _rs)
                    except Exception:
                        pass
                self._set_lex_gloss(cur)
                for lid, b in self._lex_btns.items():
                    on = (lid == self._lex_lemma)
                    b.configure(
                        bg=_C('dark_bg', '#7E5109') if on
                        else _C('panel_alt', '#ECF0F1'),
                        fg=_C('fg_on_dark', 'white') if on else _C('fg', '#566573'),
                        relief='sunken' if on else 'raised')

                shown = rows if self._lex_all else rows[:self._LEX_HEAD_N]
                n_key = sum(1 for r in rows if r[2])
                head_key = head_rest = False
                for vid, _kind, is_key, note, _e5 in shown:
                    # 대표/그 밖을 **보이는 경계**로 가른다(2026-08-10)
                    if is_key and not head_key:
                        tv.insert('', 'end', tags=('section',), values=(
                            '', '', '', i18n.t('EB_LEX_SEC_KEY', '대표 구절 ({n})').format(n=n_key)))
                        head_key = True
                    elif not is_key and not head_rest:
                        tv.insert('', 'end', tags=('section',), values=(
                            '', '', '', i18n.t('EB_LEX_SEC_REST', '그 밖의 구절 ({n})')
                            .format(n=len(rows) - n_key)))
                        head_rest = True
                    ref, body = _vrow(vid)
                    if ref is None:
                        continue
                    # ★★★ **이 절은 그 낱말을 무엇으로 옮겼나**(2026-09-07).
                    #   목록을 내려가면 인자·은혜·긍휼이 차례로 나오는데
                    #   **같은 낱말인 줄 모르면 뒤죽박죽으로 읽힌다.**
                    #   ⚠ **갈리는 낱말에서만** 붙인다(`_lex_rend` 가 비면 안 붙는다).
                    _rw = ''
                    if _lex_rend:
                        try:
                            import db_lemma_render as _lr2
                            _rw = _lr2.find_in(body, _lex_rend)
                        except Exception:
                            _rw = ''
                    # ⚠ 목록 줄은 **언제나 성경 본문**이다(설명문으로 바꿔 그리지 않는다)
                    iid = tv.insert('', 'end',
                                    values=(kind_w, _bname(vid), ref,
                                            (('[%s] ' % _rw) if _rw else '')
                                            + bidi.for_display(body[:120])),
                                    tags=('key',) if is_key else ())
                    self._link_info[iid] = dict(kind='V', vid=vid, ref=ref,
                                                note=note or '')
                if not self._lex_all and len(rows) > self._LEX_HEAD_N:
                    tv.insert('', 'end', iid='__more__', tags=('more',),
                              values=('', '', '', i18n.t('EB_LEX_MORE', '나머지 {n}곳 모두 보기')
                                      .format(n=len(rows) - self._LEX_HEAD_N)))
        except Exception as e:
            print(f'[EntityBrowser] _linked_fill error: {e}')

        # ★ 「구분」 칸은 **쓰인 글자를 재서** 넓힌다(성격값이 있을 때만)
        self._fit_kind_col([kind_m, kind_w] + [_rel_nm.get(k, k)
                                               for k in _used_kinds])
        self._update_link_subtab_label(len(self._peri_rows) + len(them) + n_words)
        first = next(iter(self._link_info), None)
        if first:
            try:
                tv.selection_set(first)
            except Exception:
                pass
        else:
            # 고를 줄이 없다 — 낱말 설명이라도 있으면 그것을, 없으면 안내만
            self._verse_title_lbl.config(
                text=getattr(self, '_lex_lemma_head', '')
                     or i18n.t('EB_LINK_HINT', '목록에서 줄을 선택하세요'))
            self._fill(self._verse_txt, getattr(self, '_lex_lemma_note', ''))
            self._paint_ctx_btn(enabled=False)

    def _fit_kind_col(self, labels):
        """「구분」 칸을 **쓰인 글자에 맞춰** 넓힌다(성격값이 있을 때만).

        ⚠ 미리 넓혀 두지 않는다 — 대부분의 용어에는 「의미」·「낱말」뿐이라
          빈자리가 내용 칸을 줄인다(§237차 ㉈ 갈래 칸과 같은 판단).
        """
        tv = getattr(self, '_link_tv', None)
        if tv is None:
            return
        try:
            import tkinter.font as _tkf
            f = _tkf.Font(font='TkDefaultFont')
            need = max([44] + [f.measure(x) + 16 for x in labels if x])
            tv.column('kind', width=need, minwidth=min(need, 44),
                      anchor='center', stretch=False)
        except Exception as e:                       # noqa: BLE001
            print('[EntityBrowser] kind col: %s' % e)

    def _set_lex_lemma(self, lemma_id):
        if lemma_id == self._lex_lemma:
            return
        self._lex_lemma = lemma_id
        self._lex_all = False
        self._linked_fill(self._current_eid)

    def _on_linked_open(self, _e=None):
        """겹클릭 — 그 구절로 이동. [더 보기] 줄은 전체 펼침."""
        sel = self._link_tv.selection()
        if not sel:
            return
        if sel[0] == '__more__':
            self._lex_all = True
            self._linked_fill(self._current_eid)
            return
        info = self._link_info.get(sel[0])
        if not info:
            return
        vid = info['vid'] if info['kind'] == 'V' else info['pr']['start_vid']
        if vid and callable(getattr(self, 'on_verse_jump', None)):
            self.on_verse_jump(vid)

    # ── 연구 서브탭 (내부자료 글) ─────────────────────────────────────────
    # ★ 두 갈래 버튼 (2026-08-10 사용자 결정) — P2 내부자료 탭과 **같은 모양**으로 맞춘다.
    #   작성자료(MINE) = 우리가 쓴 연구 글(src_type='STUDY')
    #   내부연결(NAV)  = 그 밖의 자료집(사전 · 문답 · 주제 …)
    #   ⚠ 이 버튼이 없어서 **사전 연결 289건이 화면에서 죽어 있었다.** 엔티티에 이미
    #     붙어 있는데 서브탭이 STUDY 만 보느라 볼 길이 없었다. 새로 넣은 데이터가 아니다.
    ST_MINE, ST_NAV = 'MINE', 'NAV'
    _ST_SRCWORD = {'DICTIONARY': ('REFR_SRC_DICT', '사전'),
                   'CATECHISM':  ('REFR_SRC_CATE', '문답'),
                   'TOPICAL':    ('REFR_SRC_TOPIC', '주제'),
                   'HISTORICAL': ('REFR_SRC_HIST', '역사'),
                   'CHARACTER_STUDY': ('REFR_SRC_CHAR', '인물')}

    def _build_study_subtab(self, pane):
        # ★ 갈래 단추 줄·안내문 제거 (2026-09-02 0.txt 3번 — 서브탭 승격 +
        #   「안내문 삭제하라」). 이 pane = 연구자료(내가 쓴 글)만.
        self._study_scope = self.ST_MINE      # 옛 이름 참조 보호(핸들러가 읽음)
        self._study_btns = {}

        # ★ 좌: 목록 / 우: 그 자리에서 읽고 쓰는 화면 (2026-08-10 사용자 지시
        #   「P4 주요용어 탭은 내부에서 조회 / 추가 기능을 모두 해결한다」).
        #   오른쪽은 P4 탭10 과 **같은 위젯**(`RefDetailView`)을 목록만 끄고 심은 것이다.
        #   따로 만들면 표시 방법이 둘로 갈린다.
        pw = ttk.PanedWindow(pane, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=6, pady=(0, 6))
        lf = tk.Frame(pw, bg=_C('panel', 'white'))
        pw.add(lf, weight=1)

        cols = ('title', 'verses')
        tv = ttk.Treeview(lf, columns=cols, show='headings', selectmode='browse',
                          height=8)
        tv.heading('title',  text=i18n.t('COMMON_TITLE', '제목'))
        tv.heading('verses', text=i18n.t('REFR_LINKED_VERSES', '연결 구절'))
        tv.column('title',  width=250, minwidth=110, anchor='w')
        tv.column('verses', width=60, minwidth=50, anchor='center', stretch=False)
        vsb = ttk.Scrollbar(lf, orient='vertical', command=tv.yview)
        tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        tv.pack(fill='both', expand=True)
        # 한 번 누르면 옆에서 읽고, 두 번 누르면 넓은 화면(P4 탭10·P1)으로 나간다.
        tv.bind('<<TreeviewSelect>>', self._on_study_pick)
        tv.bind('<Double-1>', self._on_study_open)
        tv.bind('<Return>', self._on_study_open)
        self._study_tv = tv
        self._study_rows = {self.ST_MINE: [], self.ST_NAV: []}

        self._study_pw   = pw
        self._study_view = None      # RefDetailView — 이 서브탭을 처음 열 때 만든다(§29)
        self._study_host = tk.Frame(pw, bg=_C('panel', 'white'))
        pw.add(self._study_host, weight=2)

    def _build_study_view(self):
        """오른쪽 읽기·쓰기 화면. **처음 필요할 때** 만든다 — 엔티티를 열 때마다
        만들면 시작이 무거워진다(§29 지연 빌드)."""
        if self._study_view is not None:
            return self._study_view
        try:
            from p4_ref_view import RefDetailView
            self._study_view = RefDetailView(
                self._study_host, self.db_path,
                lang_getter=self.lang_getter, show_list=False,
                on_verse_jump=getattr(self, 'on_verse_jump', None),
                on_entity_jump=self.load_entity,
                # 도서·설교 콤보 [▶ 보기] → P1 (2026-08-19 — P4 탭10과 같은 길)
                on_book_jump=getattr(self, 'on_sermon_select', None),
                seed_entity_getter=lambda: self._current_eid,
                on_saved=lambda _rid: (self._current_eid
                                       and self._load_study_entries(self._current_eid)))
            # ★ 연결하기 창 결과 → 그 화면으로 (2026-08-24) — 밖에서 준 길
            self._study_view.on_link_open = getattr(self, 'on_link_open', None)
            self._study_view.pack(fill='both', expand=True)
        except Exception as e:
            print(f'[study view] {e}')
            self._study_view = None
        return self._study_view

    def _on_study_pick(self, _=None):
        """한 번 누름 — 옆 칸에서 바로 읽는다(탭을 떠나지 않는다)."""
        sel = self._study_tv.selection()
        if not sel:
            return
        kind, num = sel[0][:1], sel[0][1:]
        if not num.isdigit():
            return
        v = self._build_study_view()
        if v is None:
            return
        if kind == 'U':
            v.show_user(int(num))
        elif kind == 'R':
            v.show_article(int(num))
        else:
            # 설교·도서는 이 위젯이 다루는 표가 아니다. 목록만 고르고 넘어간다.
            v.clear()

    def _load_study_entries(self, entity_id: int):
        """이 엔티티에 걸린 내부자료. `sys_ref_entity_link` 는 사전이 이미 쓰던 표다.

        ⚠ 예전에는 `src_type='STUDY'` 로 걸러 **8건만** 보였다. 같은 표에 붙어 있던
          사전 289건이 통째로 안 보였다 — 두 갈래로 나눠 둘 다 보여 준다.
        """
        self._study_rows = {self.ST_MINE: [], self.ST_NAV: []}
        try:
            with appdb.connect(self.db_path) as conn:
                # ★ 가림 덮개 (C 단계) — 사용자가 팝업에서 가린 sys 연결은 읽는
                #   화면에서 빠져야 한다. 목록 SQL 은 칸이 많아 그대로 두고
                #   **가림 집합만** 조회 문(overlay_read)에서 받아 거른다.
                import overlay_read as OR_
                _hid_ref = OR_.hidden_ids(conn, 'ENTITY', entity_id, 'REF_UNIT')
                _hid_bunt = OR_.hidden_ids(conn, 'ENTITY', entity_id,
                                           'BOOK_UNIT')
                for uid, label, question, n, role, stype in conn.execute("""
                        SELECT u.ref_unit_id, u.unit_label, u.unit_question,
                               (SELECT COUNT(*) FROM sys_link_asset vl
                                 WHERE vl.link_type='REFU_VERS'
                                   AND vl.clicked_id = u.ref_unit_id
                                   AND COALESCE(vl.record_status,'LIVE')='LIVE'),
                               el.rel_code, s.src_type
                        -- ★ 2026-08-24 통합 표(`REFU_ENTI`). link_role 은 rel_code 다.
                        FROM sys_link_asset el
                        JOIN sys_ref_unit   u ON u.ref_unit_id = el.clicked_id
                        JOIN sys_ref_source s ON s.ref_src_id  = u.ref_src_id
                        WHERE el.link_type = 'REFU_ENTI' AND el.target_id = ?
                          AND COALESCE(el.record_status,'LIVE')='LIVE'
                          AND COALESCE(u.record_status,'LIVE')='LIVE'
                          -- ⚠ 사전은 여기 넣지 않는다. **사전 탭이 따로 있다**
                          --   (`_load_dict_entries`, EASTON/SMITH/MEYER). 2026-08-10 에
                          --   내부연결에 289건을 노출시켰다가 사전 탭과 겹쳤다.
                          AND s.src_code NOT IN ('EASTON_DICT','SMITH_DICT','MEYER_BC')
                        ORDER BY CASE el.rel_code WHEN 'SUBJECT' THEN 0 ELSE 1 END,
                                 u.sequence, u.ref_unit_id
                    """, (entity_id,)):
                    if uid in _hid_ref:
                        continue            # 가린 것 — 읽는 화면에서 제외
                    mine = (stype or '').upper() == 'STUDY'
                    ttl = label or question or ''
                    if not mine:
                        k, ko = self._ST_SRCWORD.get((stype or '').upper(),
                                                     ('REFR_SRC_ETC', '자료'))
                        ttl = '%s · %s' % (i18n.t(k, ko), ttl)
                    self._study_rows[self.ST_MINE if mine else self.ST_NAV].append(
                        {'iid': 'R%d' % uid, 'id': uid, 'label': ttl, 'n': n, 'role': role})

                # 설교집·도서 (2026-08-24 통합 표 `BUNT_ENTI` 로 옮김 —
                #   조회는 `BEL.fetch_units` 한 곳이라 여기는 안 고쳤다)
                # ⚠ **번호 앞에 갈래를 붙인다.** sys_ref_unit 도 sys_book_unit 도 1번부터
                #   번호를 매겨서, 그냥 숫자로 넘기면 받는 쪽이 어느 표인지 알 수 없다.
                #   실제로 둘 다 1번이 있다(ref 1~615 · book 1~4371). 눌렀을 때 엉뚱한
                #   글이 열리는 것을 이 접두가 막는다.
                import db_book_entity_link as BEL
                import overlay_read as _or3
                # ⚠ 사전 갈래로 승격한 책(Girdlestone)은 뺀다 — 166차 Easton
                #   제외와 같은 원칙(한 자료가 두 탭에 뜨면 안 된다)
                for uid, ttl, n, role, cat in BEL.fetch_units(
                        conn, entity_id,
                        exclude_books=tuple(_or3.BOOK_DICT_SRC)):
                    if uid in _hid_bunt:
                        continue            # 가린 것 — 읽는 화면에서 제외
                    word = ('REFR_SRC_SERMON', '설교') if cat == 'SERMON' \
                        else ('REFR_SRC_BOOK', '도서')
                    self._study_rows[self.ST_NAV].append(
                        {'iid': 'B%d' % uid, 'id': uid, 'n': n, 'role': role,
                         'label': '%s · %s' % (i18n.t(*word), ttl)})

                # 내가 쓴 글 (2026-08-10) — 여기서 쓴 것이 여기 보여야 「자체 완결」이다.
                # ★★ **연결은 `link_picker.targets_of` 한 문으로만 묻는다**
                #   (2026-08-27 사용자 지적 「팝업에서 연결했는데 서브탭은 (0)」).
                #   여기서 SQL 을 직접 쓰면 그 순간 이름 하나만 보게 되고,
                #   실측 `ENTI_UREF` 2건 · `UREF_ENTI` 15건이 **하나도 안 겹쳐서**
                #   한쪽이 통째로 사라진다. 옛 단일 칸(`entity_id`)만 여기서 본다.
                import link_picker as LP
                rid_set = {i for i, _e in
                           LP.targets_of(conn, 'ENTITY', entity_id, 'USER_REF')}
                rid_set.update(r[0] for r in conn.execute(
                    "SELECT ref_id FROM user_ref_asset "
                    " WHERE COALESCE(record_status,'LIVE')='LIVE' AND entity_id=?",
                    (entity_id,)))
                for rid, ttl, ty in ([] if not rid_set else conn.execute(
                        "SELECT ref_id, title, ref_type FROM user_ref_asset "
                        " WHERE COALESCE(record_status,'LIVE')='LIVE' "
                        "   AND ref_id IN (%s) ORDER BY ref_id"
                        % ','.join('?' * len(rid_set)), tuple(sorted(rid_set)))):
                    self._study_rows[self.ST_MINE].append(
                        {'iid': 'U%d' % rid, 'id': rid, 'role': 'SUBJECT',
                         'n': 0, 'label': ttl or i18n.t('REFR_NOTITLE', '(제목없음)')})
        except Exception as e:
            print(f'[study subtab] {e}')
        # ⚠ **엔티티가 바뀔 때만** 오른쪽을 비운다. 저장 뒤에도 비우면 방금 쓴 글이
        #   눈앞에서 사라진다(`on_saved` 가 이 함수를 같은 엔티티로 다시 부른다).
        if self._study_view is not None and \
                getattr(self, '_study_loaded_eid', None) != entity_id:
            self._study_view.clear()
        self._study_loaded_eid = entity_id
        self._render_study()

    def _render_study(self):
        """두 서브탭(연구자료·내부연결)의 트리를 함께 채운다 (2026-09-02 승격)."""
        for tv, code in ((getattr(self, '_study_tv', None), self.ST_MINE),
                         (getattr(self, '_nav_tv', None), self.ST_NAV)):
            if tv is None:
                continue
            tv.delete(*tv.get_children())
            for r in self._study_rows.get(code, []):
                mark = '' if r['role'] == 'SUBJECT' else '· '
                tv.insert('', 'end', iid=r['iid'],
                          values=(mark + r['label'], r['n']))
        # ★★ **0건 잠금 규칙을 여기서 예외로 두지 않는다**(2026-09-17).
        #   그전에는 「연구자료는 여기서 새로 쓸 수 있으니 0건이라도 연다」였다 —
        #   그 예외가 곧 사용자가 짚은 **일관성 없음**이었다. 새로 쓰는 길은
        #   이제 **모서리 [My Edit]** 에 있으므로(그때는 없었다) 잠가도 잃는 것이
        #   없다. 판정은 `_apply_tab_prefs` 하나.
        if not hasattr(self, '_tab_n'):
            self._tab_n = {}
        self._tab_n['STUDY'] = len(self._study_rows.get(self.ST_MINE, []))
        self._tab_n['NAV'] = len(self._study_rows.get(self.ST_NAV, []))
        self._apply_tab_prefs()

    def _on_study_open(self, _=None):
        """줄 번호 앞 글자로 **어느 표에서 온 것인지** 가려 보낸다.

        R = sys_ref_unit(우리 글·사전 …) · B = sys_book_unit(설교집·도서)
        접두가 없으면 둘 다 「1번」이라 구분이 안 된다.
        """
        # ★ 두 서브탭이 같은 핸들러 — event.widget 이 갈래를 말한다 (2026-09-02)
        tv = getattr(_, 'widget', None) if _ is not None else None
        if tv is None or tv not in (getattr(self, '_study_tv', None),
                                    getattr(self, '_nav_tv', None)):
            tv = getattr(self, '_study_tv', None)
        from_mine = (tv is getattr(self, '_study_tv', None))
        sel = tv.selection() if tv is not None else None
        if not sel:
            return
        return self._open_study_iid(sel[0], from_mine)

    def _open_study_iid(self, iid, from_mine):
        """줄 번호 하나로 연다 — **더보기 통합 목록도 같은 문을 쓴다**(2026-09-17).

        ⚠ 여기서 다시 짜면 서브탭과 통합탭이 **다른 곳으로** 간다.
        """
        key = str(iid or '')
        kind, num = key[:1], key[1:]
        if not num.isdigit():
            return
        uid = int(num)
        # ⚠ 가는 곳이 갈래마다 다르다. **P2 내부자료와 같은 콜백을 쓴다**(2026-08-10) —
        #   전에는 셋을 다 `on_article_open` 으로 보내서, 설교·사전을 눌러도 P1 도서/설교
        #   탭이 열리지 않았다. P2 는 되는데 P4 만 안 되던 것이 이 때문이다.
        #     작성자료(STUDY)      → on_article_open    P4 탭10(자료)
        #     내부연결 R(사전·문답) → on_doctrine_select P1 문답·사전
        #     내부연결 B(설교·도서) → on_sermon_select   P1 도서/설교
        if kind == 'U':                      # 내가 쓴 글 → P4 탭10 에서 넓게
            if callable(getattr(self, 'on_user_open', None)):
                self.on_user_open(uid)
            return
        if from_mine:
            if callable(getattr(self, 'on_article_open', None)):
                self.on_article_open(uid)
            return
        cb = self.on_doctrine_select if kind == 'R' else self.on_sermon_select
        if callable(cb):
            cb(uid)
            return
        # 여는 경로가 없으면 그 단위가 다루는 첫 절로라도 보낸다
        try:
            with appdb.connect(self.db_path) as conn:
                tbl, col = (('sys_ref_unit', 'ref_unit_id') if kind == 'R'
                            else ('sys_book_unit', 'unit_id'))
                if kind == 'R':
                    # ★ 2026-08-24 통합 표(`REFU_VERS`)
                    r = conn.execute("SELECT target_id FROM sys_link_asset"
                                     " WHERE link_type='REFU_VERS' AND clicked_id=?"
                                     " AND COALESCE(record_status,'LIVE')='LIVE'"
                                     " LIMIT 1", (uid,)).fetchone()
                else:
                    r = conn.execute('SELECT start_vid FROM %s WHERE %s=?' % (tbl, col),
                                     (uid,)).fetchone()
            if r and r[0] and callable(getattr(self, 'on_verse_jump', None)):
                self.on_verse_jump(r[0])
        except Exception as e:
            print(f'[study open] {e}')

    # ── 여정 — **탭을 걷었다**(2026-09-17 사용자 「여정=삭제」) ─────────────
    def _load_journey(self, entity_id=None, etype=None):
        """옛 이름 — 부르는 곳이 남아 있어도 **아무 일도 안 한다**.

        같은 지도를 P4 「믿음의 발자취」 탭이 넓게 보인다(§31) — 자리가 둘이었다.
        """
        if True:
            return
        if not hasattr(self, '_journey_subtab_index'):
            return
        try:
            import pilgrimage_view
            exists = etype in ('PLACE', 'PERSON') and \
                pilgrimage_view.journey_exists(self.db_path, entity_id, etype)
        except Exception:
            exists = False
        try:
            if exists:
                self._center_nb.tab(self._journey_subtab_index, text=''+i18n.t('TAB_JOURNEY','여정'), state='normal')
            else:
                self._center_nb.tab(self._journey_subtab_index, text=i18n.t('TAB_JOURNEY','여정')+' (0)', state='disabled')
        except Exception:
            pass
        self._journey_pending = (entity_id, etype) if exists else None
        try:
            if exists and self._center_nb.index('current') == self._journey_subtab_index:
                self._build_or_focus_journey()
        except Exception:
            pass

    def _on_center_tab_changed(self, _e=None):
        # 이용통계 — 탭 번호를 박지 않고 인덱스 속성으로 잇는다(재배치 안전)
        try:
            import usage_stats
            _cur = self._center_nb.index('current')
            _map = {getattr(self, '_dict_subtab_index', None): 'entity_desc',
                    getattr(self, '_link_subtab_index', None): 'entity_pericope',
                    getattr(self, '_study_subtab_index', None): 'entity_links',
                    getattr(self, '_nav_subtab_index', None): 'entity_links',
                    getattr(self, '_url_subtab_index', None): 'entity_links',
                    getattr(self, '_txt_subtab_index', None): 'entity_links',
                    getattr(self, '_more_subtab_index', None): 'entity_links'}
            _c = _map.get(_cur)
            if _c:
                usage_stats.screen_hit(_c)
        except Exception:
            pass

        try:
            if self._center_nb.index('current') == self._more_subtab_index:
                self._fill_more()
        except Exception:
            pass
        # ★ **내부자료 서브탭을 열면 오른쪽 화면을 바로 짓는다** (2026-08-14 사용자 지적
        #   「양쪽에 언어 콤보가 전혀 없다」).
        #   ⚠ 예전에는 **줄을 눌러야** 지었다. 그래서 표시 언어 콤보가 그때까지
        #     아예 존재하지 않았고, 상단만 보는 사람에게는 없는 것과 같았다.
        #     묵상플랜의 판 콤보에서 겪은 것과 **같은 함정**이다(font.md §25).
        #   ⇒ 자리는 미리 만들고 내용만 나중에 채운다.
        try:
            if self._center_nb.index('current') == self._study_subtab_index:
                self._build_study_view()
        except Exception:
            pass

    def _build_or_focus_journey(self):
        if not getattr(self, '_journey_pending', None):
            return
        eid, etype = self._journey_pending
        try:
            import pilgrimage_view
            if self._journey_map is None:
                self._journey_map = pilgrimage_view.PilgrimageView(
                    self._journey_pane, db_path=self.db_path,
                    lang_getter=self.lang_getter, embed=True,
                    on_verse_jump=self.on_verse_jump)
                self._journey_map.pack(fill='both', expand=True)
                self._journey_map.update_idletasks()
            if etype == 'PERSON':
                self._journey_map.focus_person(eid)
            else:
                self._journey_map.focus_place(eid)
        except Exception as e:
            print(f'[journey subtab] {e}')

    # ── 우측 보기 모드 ────────────────────────────────────────────────
    def _role_label(self, role):
        return i18n.t('ENTITY_ROLE_' + str(role), str(role))

    def _on_linked_select(self, _=None):
        """목록 선택 → 오른쪽 = 본문 + 설명문(연결설명문 우선, 없으면 단락설명문).

        (2026-08-26 사용자 지시 「오른쪽 화면에서는 페리코프 표시하고
        연결설명문 또는 페리코프설명문을 표시하도록 하라」 — 옛 보기 모드
        3단추는 폐지, 본문과 설명문을 함께 그린다.)"""
        sel = self._link_tv.selection()
        if not sel:
            return
        info = getattr(self, '_link_info', {}).get(sel[0])
        if not info:
            return          # 구획 줄·[더 보기] — 오른쪽을 안 바꾼다
        if info['kind'] == 'P':
            pr = info['pr']
            title = pr['title'] or pr['rng']
            if pr['ms_label']:
                title += f" · {pr['ms_label']}"
            if pr['ep_desc']:
                desc = (i18n.t('EB_DESC_EP', '연결 설명'), pr['ep_desc'])
            elif pr['peri_desc']:
                desc = (i18n.t('EB_DESC_PERI', '단락 설명'), pr['peri_desc'])
            else:
                desc = None
            self._right_anchor = (pr['start_vid'], pr['end_vid'])
        else:
            title = info['ref']
            # ★ **절마다 쓴 글이 있을 때만**(2026-09-15 항목 ③). 낱말 뜻은
            #   단추 줄 옆 라벨이 한 번 말한다 — 절마다 되풀이하면 어느 절을
            #   눌러도 같은 글이라 설명 자리가 무의미해진다(실측 38/11,064).
            desc = ((i18n.t('EB_DESC_EP', '연결 설명'), info['note'])
                    if info['note'] else None)
            self._right_anchor = (info['vid'], info['vid'])
        self._right_title = title
        self._right_desc = desc
        self._cur_range = self._right_anchor
        self._render_right()

    def _render_right(self):
        """오른쪽 칸 — **선택한 절 → 연결설명문 → (문맥 ±5)** (2026-09-15 항목 ③).

        그전에는 설명문 위에 본문이 있고 ±5 가 그 본문을 늘려 **설명문 아래에
        본문이 또** 보였다. 이제 위 두 블록은 고정이고, 문맥은 [문맥 ±5] 를
        눌렀을 때만 **아래에 따로** 펼친다 — 앞뒤 다섯 절 사이에 고른 절이
        바탕색으로 들어 있어 이어 읽힌다.
        """
        if not self._right_anchor:
            return
        sv, ev = self._right_anchor
        self._cur_range = self._right_anchor
        self._paint_ctx_btn(enabled=True)
        self._verse_title_lbl.config(
            text=(getattr(self, '_right_title', '') or ''))
        try:
            with appdb.connect(self.db_path) as conn:
                ver = self._get_version(conn)
                book_lang = _ref_lang()      # ★ 약명은 **역본**을 따른다(표시언어 아님)

                def _rows(a, b):
                    return conn.execute(
                        "SELECT bi.bcode, bi.chapter, bi.verse, bc.verse_text, "
                        "bn.short_name, bi.verse_id "
                        "FROM bible_index bi "
                        "LEFT JOIN bible_content bc "
                        "  ON bc.verse_id=bi.verse_id AND bc.version_code=? "
                        "LEFT JOIN book_names bn "
                        "  ON bn.book_code=bi.bcode AND bn.lang_code=? "
                        "WHERE " + _vr.between_sql('bi.verse_id') +
                        " ORDER BY bi.sort_order",
                        [ver, book_lang] + _vr.between_args(a, b)).fetchall()
                rows = _rows(sv, ev)
                ctx = []
                if self._ctx_on:
                    csv, cev = self._ctx_range(conn, sv, ev)
                    ctx = _rows(csv, cev)
        except Exception as e:
            self._fill(self._verse_txt,
                       i18n.t('EB_LOAD_ERR', '불러오기 오류: {e}').format(e=e))
            return

        self._retag()
        t = self._verse_txt
        t.config(state='normal')
        t.delete('1.0', 'end')
        anchor_ids = {r[5] for r in rows}

        def _put(rs, mark_anchor=False):
            # ★ **보이는 범위가 약명 형식을 정한다** (`verse_ref` · 2026-08-14).
            _scope = verse_ref.scope_of([r[:5] for r in rs])
            t.tag_configure('body', lmargin1=0,
                            lmargin2=verse_ref.width_hint(_scope))
            prev_book = None
            for bcode, ch, v, text, bname, vid in rs:
                if bname and bname != prev_book:
                    if prev_book is not None:
                        t.insert('end', chr(10))
                    prev_book = bname
                ref = verse_ref.label(_scope, bname or bcode, ch, v)
                _extra = ('anchor',) if (mark_anchor and vid in anchor_ids) else ()
                t.insert('end', ref, ('ref',) + _extra)
                bidi.insert(t, '  %s%s' % (text or '', chr(10)), ('body',) + _extra)

        _put(rows)
        if self._right_desc:
            head, body = self._right_desc
            t.insert('end', chr(10) + head + chr(10), 'role')
            t.insert('end', body + chr(10), 'epdesc')
        if self._ctx_on and ctx:
            t.insert('end', chr(10) + i18n.t('EB_CTX5', '문맥 ±5') + chr(10), 'ctx_head')
            _put(ctx, mark_anchor=True)
        t.config(state='disabled')
        t.see('1.0')

    def _ctx_range(self, conn, sv, ev):
        """앞뒤 다섯 절 — **차례(`sort_order`)로 센다**(§236차 · 번호는 차례가 아니다)."""
        a = conn.execute(
            "SELECT verse_id FROM bible_index WHERE sort_order < "
            "(SELECT sort_order FROM bible_index WHERE verse_id=?) "
            "ORDER BY sort_order DESC LIMIT 5", (sv,)).fetchall()
        b = conn.execute(
            "SELECT verse_id FROM bible_index WHERE sort_order > "
            "(SELECT sort_order FROM bible_index WHERE verse_id=?) "
            "ORDER BY sort_order ASC LIMIT 5", (ev,)).fetchall()
        return (a[-1][0] if a else sv), (b[-1][0] if b else ev)

    def _toggle_ctx(self):
        """[문맥 ±5] — 누르면 펼치고 다시 누르면 접는다."""
        if not self._right_anchor:
            return
        self._ctx_on = not self._ctx_on
        self._render_right()

    def _paint_ctx_btn(self, enabled=True):
        """토글 단추 색 — 켜짐은 dark_bg(§76 갈래 단추 표준) · 꺼짐은 accent_bg."""
        b = getattr(self, '_ctx_btn', None)
        if b is None:
            return
        on = bool(enabled and self._ctx_on)
        try:
            b.config(state='normal' if enabled else 'disabled',
                     bg=_C('dark_bg', '#1A5276') if on else _C('accent_bg', '#AED6F1'),
                     fg=_C('fg_on_dark', 'white') if on else _C('accent', '#1A5276'),
                     relief='sunken' if on else 'raised')
        except Exception:
            pass

    def _expand_verses(self):
        """옛 이름 — [문맥 ±5] 켜기."""
        if self._right_anchor and not self._ctx_on:
            self._toggle_ctx()

    def _shrink_verses(self):
        """옛 이름 — [문맥 ±5] 끄기."""
        if self._right_anchor and self._ctx_on:
            self._toggle_ctx()

    def _set_lex_gloss(self, cur):
        """낱말 단추 줄 옆 라벨 — 「뜻 · 개역한글 옮김새」 **한 번**(2026-09-15)."""
        lbl = getattr(self, '_lex_gloss_lbl', None)
        if lbl is None:
            return
        parts = []
        if cur and (cur[4] or ''):
            parts.append(str(cur[4]))
        if getattr(self, '_lex_rend_sum', ''):
            parts.append('%s: %s' % (i18n.t('EB_LEX_RENDER', '개역한글 옮김새(절 수)'),
                                     self._lex_rend_sum))
        txt = '   |   '.join(parts)
        lbl.config(text=txt)
        lbl.pack_forget()
        if txt:
            lbl.pack(side='left', padx=(8, 0), fill='x', expand=True)
        self._fit_lex_gloss()

    def _fit_lex_gloss(self, _e=None):
        """라벨 접는 폭 = 줄 폭 − 단추 폭. 안 재면 긴 옮김새가 오른쪽으로 잘린다."""
        lbl = getattr(self, '_lex_gloss_lbl', None)
        if lbl is None:
            return
        try:
            w = self._lex_btnbar.winfo_width()
            used = sum(b.winfo_reqwidth() + 4 for b in self._lex_btns.values())
            lbl.config(wraplength=max(120, w - used - 24))
        except Exception:
            pass

    def _range_label(self, start_vid: int, end_vid: int) -> str:
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT bn.short_name, bi1.chapter, bi1.verse, bi2.chapter, bi2.verse "
                    "FROM bible_index bi1 "
                    "JOIN bible_index bi2 ON bi2.verse_id=? "
                    "LEFT JOIN book_names bn ON bn.book_code=bi1.bcode AND bn.lang_code='KO' "
                    "WHERE bi1.verse_id=?",
                    (end_vid, start_vid)
                ).fetchone()
            if row:
                bk, c1, v1, c2, v2 = row
                c2v2 = f'{c1}:{v1}~{v2}' if c1 == c2 else f'{c1}:{v1}~{c2}:{v2}'
                return f'{bk or ""} {c2v2}'
        except Exception:
            pass
        return ''

    def _get_version(self, conn) -> str:
        # 단일 소스 = user_config['v1_code'] (2026-07-30). 아래 sys_config 조회는
        # 컬럼명이 실제 스키마(config_val)와 달라 늘 실패하던 레거시 — 폴백으로만 남긴다.
        import verse_tier
        v = verse_tier.get_version(conn, None)
        if v:
            return v
        try:
            r = conn.execute(
                "SELECT config_value FROM sys_config WHERE config_key='version' LIMIT 1"
            ).fetchone()
            if r:
                return r[0]
        except Exception:
            pass
        try:
            r = conn.execute(
                "SELECT version_code FROM bible_version "
                "WHERE lang_code='KO' AND record_status='LIVE' LIMIT 1"
            ).fetchone()
            if r:
                return r[0]
        except Exception:
            pass
        return 'KRV'

    # ── 이벤트 핸들러 ─────────────────────────────────────────────────────────

    def _build_type_options(self):
        """유형 선택은 2026-08-12 에 콤보 → 버튼으로 바뀌었다(사용자 지시).
        이름은 호출부가 여럿이라 그대로 두고 속만 갈았다. compact 모드에는 bar 가 없다."""
        if getattr(self, '_type_btn_f', None) is not None:
            self._rebuild_type_buttons()

    def select_my_term(self, utag_id, _tries=8):
        """밖에서 그 「내 용어」를 선택해 놓고 연다(통합검색이 부른다).

        ⚠ 목록은 `after(100)` 로 늦게 찬다 — 갓 연 탭이면 그 순간 비어 있다.
          `tag_search_view.select_tag` 가 겪은 그 자리라 **몇 번 다시 본다**."""
        iid = 'u_%d' % int(utag_id)
        if self._list_tv.exists(iid):
            self._list_tv.selection_set(iid)
            self._list_tv.see(iid)
            self._show_my_term(int(utag_id))
            return True
        if _tries > 0:
            self.after(150, lambda: self.select_my_term(utag_id, _tries - 1))
        return False

    def _show_my_term(self, utag_id):
        """내가 만든 용어 — 가벼운 카드.

        ★ 다른 갈래는 **0건 규칙이 알아서 잠근다**(§2026-09-17 `_set_tab_n`) —
          여기서 탭을 손으로 여닫지 않는다. 규칙이 두 벌이 되면 갈린다.
        ⚠ 고치기·연결은 **[My Edit] 창**이 한다(`my_edit.open(.., \'UTAG\', id)`)
          — 화면을 또 만들지 않는다.
        """
        self._current_eid = None
        self._current_utag = utag_id
        lang = (self.lang_getter() or 'KO').upper()
        nm, tc, n_link = '#%d' % utag_id, 'PHASE', 0
        try:
            import overlay_read as _or_c
            import link_picker as _lp_c
            with appdb.connect(self.db_path) as conn:
                for tid, _nm, _tc in _or_c.my_terms(conn, lang):
                    if tid == utag_id:
                        nm, tc = _nm, _tc
                        break
                try:
                    n_link = len(_lp_c.links_of(conn, 'UTAG', utag_id,
                                                scope='USER'))
                except Exception:
                    n_link = 0
        except Exception as e:
            print('[EntityBrowser] _show_my_term: %s' % e)
        tname = _TYPE_LABEL.get(lang, _TYPE_LABEL['EN']).get(tc, tc)
        if self._name_lbl is not None:
            self._name_lbl.config(text=nm)
        card = '%s\n\n%s: %s\n%s: %d\n\n%s' % (
            nm,
            i18n.t('EB_TYPE_HDR', '분류'), tname,
            i18n.t('EB_MY_LINKS', '내가 붙인 것'), n_link,
            i18n.t('EB_MY_TERM_NOTE',
                   '내가 만든 용어입니다. 이름과 분류를 수정하거나 다른 자료에 '
                   '붙이려면 [My Edit] 창을 엽니다.'))
        try:
            self._fill(self._desc_txt, card)
        except Exception:
            pass
        # 용례구절·나머지 갈래는 이 용어에 해당하지 않는다 — 개수 0 을 알리면
        # 0건 규칙이 잠그거나 감춘다(화면이 스스로 정한다).
        try:
            self._link_tv.delete(*self._link_tv.get_children())
        except Exception:
            pass
        for k in getattr(self, '_EB_ORDER', ()):
            try:
                self._set_tab_n(k, 0)
            except Exception:
                pass

    def _on_list_select(self, _=None):
        sel = self._list_tv.selection()
        if not sel:
            return
        # ⚠⚠ **목록에서 직접 고르면 출발지를 지운다**(2026-09-01) — 안 지우면
        #   룻1:16 에서 들어와 다른 용어를 골랐을 때 **그 용어에 룻1:16 설명문이
        #   붙는다.** 사용자가 「검색해서 들어온 경우에는 보여줄 일이 없다」고
        #   한 것이 정확히 이 자리다.
        # ⚠⚠⚠ **다만 우리가 프로그램으로 고른 것은 「직접 고른 것」이 아니다.**
        #   `load_entity` 가 왼쪽 목록을 맞춰 주려고 `selection_set` 을 부르는데,
        #   그것이 `<<TreeviewSelect>>` 를 **큐에 넣어** 방금 담은 출발지를
        #   지워 버렸다(2026-09-01 실측 — 조회 문은 멀쩡한데 `_from_vid` 가
        #   None 이었다). §128차 트리 선택 사고와 **같은 자리**다.
        if not getattr(self, '_sel_sync', False):
            self._from_vid = None
        iid = sel[0]
        if iid.startswith('_h_'):
            return
        if iid.startswith('u_'):
            self._show_my_term(int(iid[2:]))
            return
        if iid.startswith('c_'):
            parts = iid.split('_', 3)  # ['c', parent_eid, child_eid, rel_type]
            # ★ 관계 블록은 `_on_child_select` 가 **프로필을 그린 직후**에
            #   붙인다 — 여기서 부르면 뒤이어 도는 그리기가 덮는다(실측).
            self._on_child_select(iid, int(parts[2]))
            return
        if iid.startswith('g_'):
            parts = iid.split('_', 3)  # ['g', l1_eid, l2_eid, rel_type]
            self._on_grandchild_select(iid, int(parts[2]))
            return
        try:
            eid = int(iid)
        except ValueError:
            return
        self._on_toplevel_select(eid)

    # ── 트리 탐색 핸들러 ─────────────────────────────────────────────────────

    def _append_relation_block(self, from_id, to_id, rel_type=None):
        """설명 본문 끝에 **이 관계의 글 + 구절**을 덧붙인다.

        ⚠ **없으면 아무것도 안 그린다**(§0-1 빈 서랍 금지) — 관계 설명문은
          146건 중 29건뿐이라 대부분의 관계에서 이 블록이 안 나온다.
        ⚠ 번호 축이 둘이라는 사실은 `db_person_relation.relation_view` 가
          감춘다 — 화면은 from/to/유형만 넘긴다.
        """
        txt = getattr(self, '_desc_txt', None)
        try:
            if txt is None or not txt.winfo_exists():
                return
        except Exception:
            return                      # 창이 닫혔다(§129차 `after_idle` 가드)
        try:
            import db_person_relation as _PR
        except Exception:
            return
        lang = self.lang_getter() or 'KO'
        with appdb.connect(self.db_path) as conn:
            v = _PR.relation_view(conn, from_id, to_id, rel_type, lang)
            if not v or (not v['desc'] and not v['verses']):
                return
            a = self._get_entity_name(from_id)
            b = self._get_entity_name(to_id)
        txt.configure(state='normal')
        txt.insert('end', '\n\n')
        txt.insert('end', '%s ↔ %s\n' % (a, b), 'relhead')
        if v['desc']:
            txt.insert('end', v['desc'] + '\n', 'prose')
        for _lid, _sv, _ev, ref, body in v['verses']:
            txt.insert('end', '\n%s  ' % ref, 'relref')
            txt.insert('end', body + '\n', 'prose')
        txt.configure(state='disabled')
        # ⚠ 태그 색은 **그릴 때마다** 역할로 — paint 는 Text 태그를 못 본다
        #   (§36-5b). 하드코딩하면 검정 테마에서 그 자리만 굳는다.
        txt.tag_configure('relhead', foreground=_C('accent', '#2471A3'),
                          spacing1=6, spacing3=2)
        txt.tag_configure('relref', foreground=_C('fg_dim', '#7F8C8D'))

    def _on_toplevel_select(self, eid: int):
        """최상위 엔티티 클릭: 기존 트리 접고 새 트리 펼침."""
        if self._tree_expand_eid and self._tree_expand_eid != eid:
            self._collapse_entity(str(self._tree_expand_eid))
        self._tree_expand_eid = eid
        self._breadcrumb = [eid]
        self._load_entity_profile(eid)
        self._update_breadcrumb()
        if not self._list_tv.get_children(str(eid)):
            self._expand_level1(str(eid), eid)
        else:
            self._list_tv.item(str(eid), open=True)
        # ★★ **한 번에 다 펼친다**(2026-09-07 사용자 「**처음에 트리를 모두
        #   펼쳐라. 클릭 반응이 이상하다**」). 그전에는 자식을 눌러야 손자가
        #   나오고 **그때 형제의 손자가 지워져** 트리가 발밑에서 무너졌다.
        #   ⚠ 크기를 재고 정했다 — 실측 가장 큰 다윗이 **66줄**(1층 26 ·
        #     2층 40)이고 예수 51 · 하나님의 속성 26 이다. 감당된다.
        self._expand_all_children(str(eid))

    def _expand_all_children(self, parent_iid):
        """1층 줄마다 2층을 미리 펼친다 — **한 번에 다 보인다.**

        ⚠ 이미 펼쳐진 줄은 건너뛴다(멱등) · 없는 줄은 조용히 넘어간다.
        ⚠ `_expand_level2` 가 그 줄의 관계를 다시 읽으므로 **여기서 조회를
          또 짜지 않는다** — 두 벌이 되면 라벨 규칙이 갈린다.
        """
        try:
            for k in self._rel_rows(parent_iid):
                if self._list_tv.get_children(k):
                    continue
                ps = str(k).split('_', 3)
                if len(ps) < 3:
                    continue
                try:
                    self._expand_level2(k, int(ps[2]))
                except Exception:
                    continue
        except Exception as e:
            print('[EntityBrowser] _expand_all_children: %s' % e)

    def _rel_rows(self, parent_iid):
        """그 마디 아래의 **관계 줄** — 축 묶음(`ax_…`)은 뚫고 본다.

        ⚠ 축 묶음이 생기기 전에는 `get_children` 이 곧 관계 줄이었다.
          묶음을 넣은 뒤로는 한 겹이 더 있으므로 **여기 한 문**으로 감춘다 —
          쓰는 자리마다 풀면 하나는 반드시 빠진다.
        """
        out = []
        for k in self._list_tv.get_children(parent_iid):
            if str(k).startswith('ax_'):
                out.extend(self._list_tv.get_children(k))
            else:
                out.append(k)
        return out

    def _on_child_select(self, iid: str, child_eid: int):
        """1레벨 자식 클릭: 형제 노드의 손자를 접고 이 노드의 손자를 펼침."""
        root_eid = self._tree_expand_eid or child_eid
        if self._tree_expand_eid:
            # ⚠⚠⚠ **축 묶음을 뚫고 본다** (2026-09-05 실측으로 잡았다).
            #   관계를 축(`ax_…`)으로 묶자 `get_children(다윗)` 이 **묶음**을
            #   내주고, 그것을 형제로 보고 자식을 지우는 바람에 **관계 줄이
            #   통째로 사라졌다** — 그 뒤 클릭이 `Item … not found` 로 죽었다.
            #   ⇒ 묶음이면 한 겹 더 내려간다.
            #   ★ **트리 구조를 바꿨으면 눌러 봐야 한다** — 렌더만 보면
            #     이 부류가 안 잡힌다(그렇게 「Tk 오류 0」을 두 번 보고했다).
            # ⚠⚠ **형제의 손자를 지우지 않는다**(2026-09-07 사용자 지시) —
            #   그것이 「클릭 반응이 이상하다」의 정체였다. 자식을 누를 때마다
            #   옆 가지가 사라져 **트리가 발밑에서 무너졌다.**
            pass
        if not self._list_tv.get_children(iid):
            self._expand_level2(iid, child_eid)
        else:
            self._list_tv.item(iid, open=True)
        self._breadcrumb = [root_eid, child_eid]
        self._load_entity_profile(child_eid)
        self._update_breadcrumb()
        # ★★★ **관계 자체의 글과 구절** (2026-09-05 사용자 설계 0.person.txt
        #   §2 — 「다윗 아래에 후새를 클릭하면 후새에 관한 설명문, **다윗-후새의
        #   설명문**(관계유형을 고려), **다윗-후새 관련 구절**을 연결한다」).
        #   ⚠⚠ **프로필을 그린 직후여야 한다** — 디스패처에서 부르면 뒤이어
        #     도는 그리기가 본문을 덮어 **조용히 사라진다**(실측: 데이터·위젯이
        #     다 멀쩡한데 화면에 없었고 `after_idle` 로도 안 됐다).
        try:
            ps = str(iid).split('_', 3)
            self._append_relation_block(root_eid, child_eid,
                                        ps[3] if len(ps) > 3 else None)
        except Exception as _e:
            print('[EntityBrowser] relation block: %s' % _e)

    def _on_grandchild_select(self, iid: str, gc_eid: int):
        """2레벨 손자 클릭: 프로필만 교체, 트리 구조 유지."""
        parts = iid.split('_', 3)   # ['g', l1_eid, l2_eid, rel_type]
        l1_eid   = int(parts[1])
        root_eid = self._breadcrumb[0] if self._breadcrumb else l1_eid
        self._breadcrumb = [root_eid, l1_eid, gc_eid]
        self._load_entity_profile(gc_eid)
        self._update_breadcrumb()

    def _keep_group_open(self, _e=None):
        """접힌 것이 관계 묶음이면 그 자리에서 도로 편다."""
        try:
            iid = self._list_tv.focus()
            if iid and (iid.startswith('ax_') or iid.startswith('_h_g')):
                self._list_tv.item(iid, open=True)
        except Exception:
            pass

    def _expand_level1(self, parent_iid: str, entity_id: int):
        etype = self._get_entity_type(entity_id)
        lang  = self.lang_getter()
        try:
            with appdb.connect(self.db_path) as conn:
                children = self._fetch_related(conn, entity_id, etype, lang)
        except Exception as e:
            print(f"[EntityBrowser] _expand_level1: {e}")
            return
        # ★★★ **축으로 묶는다** (2026-09-05 사용자 설계 0.person.txt §3~4).
        #   ⚠ 「관계 유형이 겹치는 경우 때문에 불편하다 · **결합하면 매우
        #     길어질 것**」의 답이다 — **묶음 머리가 의미(축)를 말하므로 줄에는
        #     종류만** 남는다. 실측 다윗 화면 최대 14자 → 12자.
        #   ⚠ 축이 없는 관계(배경 인물 14건)는 묶음을 안 만든다 — 억지로 넷에
        #     밀어 넣지 않는다(§db_person_relation).
        try:
            import db_person_relation as _PR
            AX_KO, ORDER = _PR.AXIS_KO, _PR.AXIS_CODES
        except Exception:
            AX_KO, ORDER = {}, ()
        buckets = {}
        for row in children:
            axis = row[5] if len(row) > 5 else None
            buckets.setdefault(axis, []).append(row)
        # 축이 하나뿐(또는 전부 없음)이면 묶지 않는다 — 마디 하나가 늘 뿐이다
        use_group = len([a for a in buckets if a]) >= 2
        for axis in list(ORDER) + [None]:
            rows = buckets.get(axis)
            if not rows:
                continue
            host = parent_iid
            if use_group:
                # ★★ **축이 없는 것도 이름을 가진다 — 「기타」** (2026-09-05
                #   사용자 지시 「그밖 => 기타 라고 이름을 지어라」).
                #   ⚠ 그전에는 축 없는 관계가 **묶음 밖에 홀로** 떠서 왜
                #     밖인지 알 수 없었다. 「축이 없다」도 하나의 상태이고,
                #     그것이 이름을 가지면 떠 있는 줄이 없어진다.
                #   ⚠ 억지로 넷에 밀어 넣지 않는다 — 그러면 분류가 거짓이
                #     된다(실측 15건이 전부 배경 인물이다).
                #   ★★ **묶음 이름이 「무엇의 관계인가」를 말한다**
                #     (2026-09-07 사용자 「**언약관계인물, 대적관계인물** 등으로
                #     표시해야 무슨 말인지 이해한다」). 「언약」 한 낱말이면
                #     그것이 관계의 축인지 그 인물의 속성인지 알 수 없다.
                nm = _AXIS_GROUP_NAME(axis)
                gid = f'ax_{entity_id}_{axis or "ETC"}'
                if not self._list_tv.exists(gid):
                    self._list_tv.insert(parent_iid, 'end', iid=gid,
                                         text='  %s' % nm,
                                         tags=('cat',), open=True)
                host = gid
            for row in rows:
                related_id, rel_type, rel_ko, name, tag = row[:5]
                child_iid = f'c_{entity_id}_{related_id}_{rel_type}'
                if self._list_tv.exists(child_iid):
                    continue
                # ⚠ **라벨이 없으면 대괄호도 안 그린다**(2026-09-07) —
                #   관문 소속처럼 「무슨 관계인지 자리가 말하는」 줄에는
                #   `[  ]` 만 남으면 그것이 고장으로 읽힌다.
                lbl = ('  [%s] %s' % (rel_ko, name)) if rel_ko                     else ('  %s' % name)
                self._list_tv.insert(host, 'end', iid=child_iid,
                                     text=lbl, tags=(tag,))
        self._list_tv.item(parent_iid, open=True)

    def _expand_level2(self, parent_iid: str, entity_id: int):
        etype = self._get_entity_type(entity_id)
        lang  = self.lang_getter()
        try:
            with appdb.connect(self.db_path) as conn:
                children = self._fetch_related(conn, entity_id, etype, lang)
        except Exception as e:
            print(f"[EntityBrowser] _expand_level2: {e}")
            return
        # ★★ **경로에 이미 있는 인물은 다시 안 낸다** (2026-09-03 0.txt 2번
        #   사용자 지적 「다윗 - 요나단 - 다시 다윗 .. 반복 등장하는 것은
        #   제거되어야 한다」). 캔버스 §46 보호 가지와 같은 규칙 —
        #   되돌아가는 가지는 정보를 더하지 않고 혼란만 만든다.
        seen = set()
        try:
            # 뿌리(1레벨 부모의 부모)까지 거슬러 경로를 모은다
            iid = parent_iid
            while iid:
                for p in str(iid).split('_')[1:]:
                    if p.isdigit():
                        seen.add(int(p))
                iid = self._list_tv.parent(iid)
        except Exception:
            pass
        seen.add(entity_id)
        # ⚠ `_fetch_related` 가 **여섯 칸**을 낸다(축이 늘었다) — 다섯으로
        #   풀면 여기서 죽는다(§147차 「칸을 늘리면 푸는 쪽이 조용히 밀린다」).
        #   2레벨은 이미 「부모의 무엇」으로 읽으므로 축 묶음을 안 쓴다.
        for row in children:
            related_id, rel_type, rel_ko, name, tag = row[:5]
            if related_id in seen:
                continue                 # 사이클 — 위에서 이미 지나온 인물
            gc_iid = f'g_{entity_id}_{related_id}_{rel_type}'
            if self._list_tv.exists(gc_iid):
                continue
            # ★ 기준 명시 — 3단계에서 「누구 기준인가」가 모호하다는 지적의
            #   답(0.txt 2번). 라벨을 **「부모이름의 무엇」**으로 읽게 한다.
            base = self._list_tv.item(parent_iid, 'text') or ''
            base = base.strip()
            if base.startswith('['):
                base = base.split(']', 1)[-1].strip()
            # ⚠ **라벨이 없으면 대괄호도 안 그린다**(2026-09-07) — 관문
            #   소속처럼 자리가 관계를 말하는 줄에 `[하나님의 속성의 ]` 같은
            #   빈 꼬리가 붙는 것을 실측으로 잡았다.
            head = (('%s의 %s' % (base, rel_ko)) if base else rel_ko)                 if rel_ko else ''
            self._list_tv.insert(
                parent_iid, 'end', iid=gc_iid, tags=(tag,),
                text=('    [%s] %s' % (head, name)) if head
                     else ('    %s' % name))
        self._list_tv.item(parent_iid, open=True)

    def _collapse_entity(self, parent_iid: str):
        if not self._list_tv.exists(parent_iid):
            return
        for child in list(self._list_tv.get_children(parent_iid)):
            for gc in list(self._list_tv.get_children(child)):
                self._list_tv.delete(gc)
            self._list_tv.delete(child)
        self._list_tv.item(parent_iid, open=False)

    def _fetch_related(self, conn, entity_id: int, etype: str, lang: str
                       ) -> list[tuple]:
        """[(related_id, rel_type, rel_ko_label, name, tag)] 반환."""
        results = []
        if etype == 'IDOL':
            rows = conn.execute("""
                SELECT ir.target_id, ir.rel_code,
                    COALESCE(
                        (SELECT ta.contents FROM sys_text_asset ta
                         WHERE ta.text_type='ENTITY_NAME' AND ta.clicked_id=ir.target_id
                         AND ta.lang_code=? AND ta.record_status='LIVE' LIMIT 1),
                        (SELECT ta.contents FROM sys_text_asset ta
                         WHERE ta.text_type='ENTITY_NAME' AND ta.clicked_id=ir.target_id
                         AND ta.lang_code='EN' AND ta.record_status='LIVE' LIMIT 1),
                        (SELECT ta.contents FROM sys_text_asset ta
                         WHERE ta.text_type='ENTITY_NAME' AND ta.clicked_id=ir.target_id
                         AND ta.lang_code='KO' AND ta.record_status='LIVE' LIMIT 1),
                        CAST(ir.target_id AS TEXT)
                    ) AS name
                FROM %s ir
                WHERE %s AND ir.clicked_id=?
                  AND COALESCE(ir.record_status,'LIVE')='LIVE'
                ORDER BY ir.rel_code
            """ % (entity_relation.TBL, _IDOL_W),
                (lang, *_IDOL_A, entity_id)).fetchall()
            for person_id, rel_type, name in rows:
                rel_ko = i18n.t('IDOLREL_' + str(rel_type), _IDOL_REL_KO.get(rel_type, rel_type))
                results.append((person_id, rel_type, rel_ko, name, 'person'))
            # ★ 이 신을 섬긴 민족 (2026-09-02 0.txt 1번 — 한 행 양방향:
            #   민족 쪽 NATIONAL_GOD 행을 우상 쪽에서 뒤집어 읽는다).
            #   이름은 `entity_overlay.entity_head`(조회 문 — 검사기 규칙).
            import entity_overlay as _EO
            for (nid,) in conn.execute("""
                SELECT nr.clicked_id FROM %s nr
                WHERE nr.link_type='ENTI_ENTI' AND nr.rel_code='NATIONAL_GOD'
                  AND nr.target_id=?
                  AND COALESCE(nr.record_status,'LIVE')='LIVE'
            """ % entity_relation.TBL, (entity_id,)).fetchall():
                name = (_EO.entity_head(conn, nid, lang) or (None,))[0] or str(nid)
                rel_ko = i18n.t('NATREL_NATIONAL_GOD_R', '섬긴 민족')
                results.append((nid, 'NATIONAL_GOD_R', rel_ko, name, 'nation'))

        elif etype in ('NATION', 'GROUP'):
            # ★ 민족·그룹(집단) 서브트리 (2026-09-02 0.txt 1번 — 우상과 같은
            #   문법). clicked=집단 · target=인물|우상. 대표 몇 명만 담겨
            #   있다(db_nation_rel — 전수가 아니라 활용도 높은 것만).
            #   ⚠ 지파 12개는 행이 없어 서브트리가 안 생긴다(의도 — 조상
            #     인물이 1:1 이라 관계가 정보를 더하지 않는다).
            import entity_overlay as _EO
            w, a = entity_relation.nation_where('nr')
            rows = conn.execute("""
                SELECT nr.target_id, nr.rel_code
                FROM %s nr
                WHERE %s AND nr.clicked_id=?
                  AND COALESCE(nr.record_status,'LIVE')='LIVE'
                ORDER BY nr.rel_code
            """ % (entity_relation.TBL, w),
                (*a, entity_id)).fetchall()
            for tid, rel_type in rows:
                name = (_EO.entity_head(conn, tid, lang) or (None,))[0] or str(tid)
                # ⚠ 그룹의 MEMBER 는 「그 민족 사람」이 아니다 — 말이 대상을
                #   따라간다(바리새파의 바울 = 「소속 인물」).
                if etype == 'GROUP' and rel_type == 'MEMBER':
                    rel_ko = i18n.t('NATREL_MEMBER_G', '소속 인물')
                else:
                    rel_ko = i18n.t('NATREL_' + str(rel_type),
                                    _NAT_REL_KO.get(rel_type, rel_type))
                tag = 'idol' if rel_type == 'NATIONAL_GOD' else 'person'
                results.append((tid, rel_type, rel_ko, name, tag))

        elif etype == 'PERSON':
            rows = conn.execute("""
                SELECT pr.clicked_id, pr.target_id,
                       pr.relation_cat, pr.rel_code
                FROM %s pr
                WHERE %s AND (pr.clicked_id=? OR pr.target_id=?)
                  AND COALESCE(pr.record_status,'LIVE')='LIVE'
                ORDER BY pr.relation_cat, pr.rel_code
            """ % (entity_relation.TBL, _PERS_W),
                (*_PERS_A, entity_id, entity_id)).fetchall()
            # ★★ **같은 짝의 여러 관계를 한 줄로** (2026-09-03 0.txt 2번
            #   사용자 확정 — 「한 사람이 두 가지 관계가 있는 경우
            #   [경쟁자/권위자] 관계를 통합하는 것이 좋겠다. 설명문이 각각
            #   달라야 한다면 통합이 어려울 것이다」).
            #   ⇒ **설명문이 있는 관계는 안 합친다**(제 줄을 지킨다) — 글이
            #     다르면 구분할 이유가 있다는 그 조건 그대로다.
            #   실측 — 사울↔다윗 RIVAL·AUTHORITY 둘 다 설명문 0(합쳐도 잃는
            #   것이 없다). `sys_text_asset('RELATION_DESC')` 유무로 가른다.
            #   ⚠ 조회는 `overlay_read` 한 문 — 화면이 sys 를 직접 읽으면
            #     검사기(ratchet)가 잡는다(실제로 이 자리에서 잡혔다).
            import overlay_read as _or4
            _desc_rel = _or4.relations_with_desc(conn)
            _merged = {}          # other_id → [라벨…]  (설명문 없는 것만)
            _order = []
            for from_id, to_id, rel_cat, rel_type in rows:
                other_id = to_id if from_id == entity_id else from_id
                name_row = conn.execute("""
                    SELECT COALESCE(
                        (SELECT ta.contents FROM sys_text_asset ta
                         WHERE ta.text_type='ENTITY_NAME' AND ta.clicked_id=?
                         AND ta.lang_code=? AND ta.record_status='LIVE' LIMIT 1),
                        (SELECT ta.contents FROM sys_text_asset ta
                         WHERE ta.text_type='ENTITY_NAME' AND ta.clicked_id=?
                         AND ta.lang_code='EN' AND ta.record_status='LIVE' LIMIT 1),
                        (SELECT ta.contents FROM sys_text_asset ta
                         WHERE ta.text_type='ENTITY_NAME' AND ta.clicked_id=?
                         AND ta.lang_code='KO' AND ta.record_status='LIVE' LIMIT 1),
                        CAST(? AS TEXT)
                    )
                """, (other_id, lang, other_id, other_id, other_id)).fetchone()
                name     = name_row[0] if name_row else str(other_id)
                oth_type = self._get_entity_type(other_id)
                tag      = _TYPE_TAG.get(oth_type, 'person')
                # ★ 방향 — 내가 to 쪽이면 **뒤집힌 이름**(위 노드 기준으로 읽힌다)
                if from_id == entity_id:
                    rel_ko = _REL_FWD_KO.get(
                        rel_type, _REL_TYPE_SHORT_KO.get(rel_type, rel_type))
                else:
                    rel_ko = _REL_REV_KO.get(
                        rel_type, _REL_TYPE_SHORT_KO.get(rel_type, rel_type))
                key = other_id
                if key not in _merged:
                    _merged[key] = {'labels': [], 'rel': rel_type,
                                    'name': name, 'tag': tag, 'axes': []}
                    _order.append(key)
                if rel_ko not in _merged[key]['labels']:
                    _merged[key]['labels'].append(rel_ko)
                # ★★ **축은 저장하지 않고 계산한다**(관계 136건 — 비용 0).
                #   담으면 두 표 중 어디에 둘지가 다시 문제가 된다(통합 표는
                #   모든 연결이 공유하므로 축 칸을 달 수 없다).
                try:
                    import db_person_relation as _PR
                    _ax = _PR.axis_for(conn, None, None, rel_type,
                                       from_id, to_id)
                    if _ax:
                        _merged[key]['axes'].append(_ax)
                    _merged[key]['axis'] = _PR.pick_axis(_merged[key]['axes'])
                except Exception:
                    pass
            for key in _order:
                m = _merged[key]
                # 라벨 통합 — [경쟁자·권위자] 꼴(사용자 확정)
                results.append((key, m['rel'], '·'.join(m['labels']),
                                m['name'], m['tag'], m.get('axis')))

        # ★★★ **관문 ↔ 소속** (2026-09-07 사용자 지시 「하나님의 속성 -
        #   편재성, 전능성... **연결되어야 한다** … 유사한 것들도 **모두
        #   일괄적으로**」). 실측 그전에는 「하나님의 속성」에 아무것도 안
        #   이어져 있었고, 「거룩」에서 하나님으로 갈 길이 **없었다**.
        #   ⚠ **유형을 안 가린다** — 관문은 교리이고 소속은 용어라 위의
        #     유형 분기 어디에도 안 걸린다. 그래서 **분기 밖에서** 덧붙인다.
        #   ⚠ **양방향** — 관문에서는 「소속」이, 소속에서는 「속한 곳」이 뜬다.
        #     한쪽만 읽으면 거룩에서 하나님으로 가는 길이 다시 막힌다.
        try:
            import entity_overlay as _EOg
            gw, ga = entity_relation.gateway_where('gl')
            for tid, back in (
                    [(r[0], False) for r in conn.execute(
                        "SELECT gl.target_id FROM %s gl WHERE %s "
                        "AND gl.clicked_id=? AND COALESCE(gl.record_status,"
                        "'LIVE')='LIVE'" % (entity_relation.TBL, gw),
                        (*ga, entity_id))]
                    + [(r[0], True) for r in conn.execute(
                        "SELECT gl.clicked_id FROM %s gl WHERE %s "
                        "AND gl.target_id=? AND COALESCE(gl.record_status,"
                        "'LIVE')='LIVE'" % (entity_relation.TBL, gw),
                        (*ga, entity_id))]):
                nm2 = (_EOg.entity_head(conn, tid, lang) or (None,))[0] or str(tid)
                # ⚠ **라벨을 안 붙인다**(2026-09-07 사용자 「속한 곳, 이에
                #   속함.. 이런 것 **제거하라. 인덴트만 잘 표시하라.
                #   없어도 이해할 것이다**」). 관문 아래 있으면 소속이고
                #   소속 아래 있으면 관문이다 — **자리가 이미 말한다.**
                results.append((tid, 'ASPECT', '', nm2, 'entity'))
        except Exception as _e:
            print('[EntityBrowser] gateway: %s' % _e)

        # ⚠ 인물이 아닌 갈래는 축이 없다 — 칸 수를 맞춰 준다(푸는 쪽이 밀린다)
        return [r if len(r) == 6 else tuple(r) + (None,) for r in results]

    def _update_breadcrumb(self):
        """탐색 경로를 **상단 bar 한 줄**에 그린다 (2026-08-26 사용자 지시).

        ⚠ compact 모드(가계도 슬라이드)에는 상단 bar 가 없어 `_crumb_f` 가
          None 이다 — 조용히 넘어간다.
        """
        crumb = getattr(self, '_crumb_f', None)
        if crumb is None:
            return
        for w in crumb.winfo_children():
            w.destroy()
        bg = _C('panel_alt', '#E8EAF6')
        if getattr(self, '_current_strong', None):
            info = getattr(self, '_lex_info', {}) or {}
            txt = ' '.join(x for x in (
                info.get('form', ''),
                ('(%s)' % info['translit']) if info.get('translit') else '') if x) \
                or self._current_strong
            lbl = tk.Label(crumb, text=txt, bg=bg, fg=_C('fg', '#2C3E50'))
            _tfr(lbl, self.db_path, 'ui')
            try:
                import tkinter.font as _tkf
                _f = _tkf.Font(font=lbl.cget('font'))
                _f.configure(weight='bold')
                lbl.configure(font=_f)
            except Exception:
                pass
            lbl.pack(side='left')
            return
        if not self._breadcrumb:
            return
        for i, eid in enumerate(self._breadcrumb):
            name = self._get_entity_name(eid)
            if i > 0:
                _sep = tk.Label(crumb, text=' › ', bg=bg,
                                fg=_C('fg_dim', '#95A5A6'))
                _tfr(_sep, self.db_path, 'ui')
                _sep.pack(side='left')
            is_last = (i == len(self._breadcrumb) - 1)
            fg    = _C('fg', '#2C3E50') if is_last else _C('accent', '#2471A3')
            lbl   = tk.Label(crumb, text=name, bg=bg, fg=fg,
                             cursor='arrow' if is_last else 'hand2')
            # 표준서식(0.txt 6번) — 크기는 설정 글꼴을 따르고 굵기만 상태
            _tfr(lbl, self.db_path, 'ui')
            if is_last:
                try:
                    import tkinter.font as _tkf
                    _f = _tkf.Font(font=lbl.cget('font'))
                    _f.configure(weight='bold')
                    lbl.configure(font=_f)
                except Exception:
                    pass
            lbl.pack(side='left')
            if not is_last:
                _e = eid
                lbl.bind('<Button-1>', lambda ev, x=_e: self._crumb_navigate(x))

    def _crumb_navigate(self, eid: int):
        try:
            idx = self._breadcrumb.index(eid)
        except ValueError:
            return
        self._breadcrumb = self._breadcrumb[:idx + 1]
        self._load_entity_profile(eid)
        self._update_breadcrumb()
        iid = str(eid)
        if self._list_tv.exists(iid):
            self._list_tv.selection_set(iid)
            self._list_tv.see(iid)

    def _get_entity_type(self, entity_id: int) -> str:
        for e in self._all_entities:
            if e['entity_id'] == entity_id:
                return e['entity_type']
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT entity_type FROM sys_entity_master WHERE entity_id=?",
                    (entity_id,)
                ).fetchone()
                return row[0] if row else 'PERSON'
        except Exception:
            return 'PERSON'

    def _get_entity_name(self, entity_id: int) -> str:
        for e in self._all_entities:
            if e['entity_id'] == entity_id:
                return e['name']
        return str(entity_id)

    def _on_person_tree_click(self):
        if self._current_eid and self.on_person_tree:
            self.on_person_tree(self._current_eid)

    def _on_person_net_click(self):
        if self._current_eid and self.on_person_net:
            self.on_person_net(self._current_eid)

    # ── 유틸리티 ──────────────────────────────────────────────────────────────

    def _get_text(self, conn, clicked_id: int, text_type: str, lang: str) -> str:
        row = conn.execute(
            "SELECT contents FROM sys_text_asset "
            "WHERE text_type=? AND clicked_id=? AND lang_code=? "
            "AND record_status='LIVE' LIMIT 1",
            (text_type, clicked_id, lang)
        ).fetchone()
        return row[0] if row else ''

    def _get_text_ex(self, conn, clicked_id, text_type, lang):
        """덮개까지 본 결과 — `(글, 가림여부)`.

        ★★ **가림은 언어 폴백을 이긴다** (2026-08-26 사용자 지적 · §88차 재발
          방지). 사용자가 한국어 설명을 **가렸는데** 폴백이 그대로 돌면
          영어 설명이 튀어나온다 — 지운 글이 다른 언어로 되살아나는 셈이다.
          구절 설명문에서 이미 한 번 난 사고다(`_text_one_lang_ex` 가 그때의 답).
        ⇒ 「가려서 빈 것」과 「원래 없는 것」을 갈라 돌려주고, 부르는 쪽이
          **가림이면 다음 언어로 넘어가지 않는다.**
        """
        try:
            import overlay
            ov = overlay.text_override(conn, text_type, clicked_id,
                                       (lang or '').upper(), '')
        except Exception:
            ov = None
        if ov:
            if ov[0] == 'HIDE':
                return '', True                    # 가렸다 — 폴백 금지
            title, contents = ov[1]
            return (contents or title or ''), False
        return self._get_text(conn, clicked_id, text_type, lang), False

    def _desc_with_overlay(self, conn, entity_id, lang):
        """설명문 — 요청 언어 → EN → KO 폴백. **가리면 거기서 멈춘다.**

        ★ 2026-08-27 — 조회 규칙을 `overlay_read.text_lang`(정본)으로 옮겼다.
          「가린 것 보기」 옵션이 켜져 있으면 가린 글을 **내용째** 돌려주고
          가림 표식은 그대로 True 다(화면이 H 로 알린다).
        """
        import overlay_read
        opt = overlay_read.show_hidden(conn)
        for lg in (lang, 'EN', 'KO'):
            if not lg:
                continue
            row, st = overlay_read.text_lang(conn, 'ENTITY_DESC', entity_id,
                                             lg, None, opt_show_hidden=opt)
            if st == 'HIDE':
                return ((row or {}).get('contents') or ''), True
            if row and (row.get('contents') or '').strip():
                return row['contents'], False
        return '', False


    def _retag(self):
        """Text 태그 색을 **지금 테마로** 다시 입힌다 (§36-5b).

        ⚠ `ui_theme.paint` 는 위젯 옵션만 본다 — 태그 색은 못 본다.
          그래서 **그릴 때마다** 여기를 지나야 검정 테마에서 안 굳는다.
        """
        try:
            # 서브트리 우상 줄 역할색 (2026-09-02 UI 점검 ④ — 민족 서브트리에
            #   인물·우상이 섞여, 우상 줄만 warning 색으로 가른다. 사용자 확정
            #   「우상 줄만 역할색 적용」). section 도 테마를 따라오게 함께.
            self._list_tv.tag_configure('idol',
                                        foreground=_C('warning', '#7E5109'))
            self._list_tv.tag_configure('section',
                                        foreground=_C('fg_dim', '#AAB7B8'))
            for t, role, dflt in (
                    ('ref', 'accent', '#1A5276'),
                    ('body', 'fg', '#2C3E50'),
                    ('role', 'accent', '#7D3C98'),
                    ('peri_title', 'success', '#117A65'),
                    ('epdesc', 'fg', '#4A235A'),
                    ('empty', 'fg_dim', '#AAAAAA')):
                self._verse_txt.tag_configure(t, foreground=_C(role, dflt))
            self._verse_txt.configure(bg=_C('bg', '#FFFEF8'),
                                      fg=_C('fg', '#2C3E50'))
            self._cmp_txt.tag_configure(
                'cmp_name', foreground=_C('accent', '#1A5276'),
                underline=True)
            self._cmp_txt.tag_configure(
                'cmp_note', foreground=_C('fg', '#2C3E50'))
            self._cmp_txt.configure(bg=_C('bg', '#FFFEF8'),
                                    fg=_C('fg', '#2C3E50'))
            for t, role, dflt in (
                    ('dict_link', 'accent', '#1A5276'),
                    ('dict_src', 'fg_dim', '#808B96'),
                    ('dict_title', 'fg_title', '#1A5276'),
                    ('dict_body', 'fg', '#2C3E50')):
                self._dict_txt.tag_configure(t, foreground=_C(role, dflt))
            self._dict_txt.configure(bg=_C('bg', '#F9FBE7'),
                                     fg=_C('fg', '#2C3E50'))
        except Exception:
            pass

    def _fill(self, widget: tk.Text, text: str):
        self._retag()
        widget.config(state='normal')
        widget.delete('1.0', 'end')
        if text:
            widget.insert('1.0', text)
        widget.config(state='disabled')
