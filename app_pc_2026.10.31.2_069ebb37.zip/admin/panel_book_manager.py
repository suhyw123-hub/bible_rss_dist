"""
admin/panel_book_manager.py
----------------------------
도서/저자 관리 패널

레이아웃:
  [좌 200px] book_category별 도서 트리 + [신규 도서] 버튼
  [우]       Notebook 2탭
    Tab1: 기본정보 — 도서 메타데이터 편집 / 신규 등록
    Tab2: 유닛 목록 — 챕터/설교 유닛 조회·추가·편집·삭제
            + 하단 본문 패널 — 선택 유닛의 body_text 표시

★★ **화면 글자에 코드를 적지 않는다** (2026-09-22 사용자 「암호같은
  표현들은 모두 사람의 언어로」) — `LIVE`/`HIDE` → 「보임/숨김」 ·
  `sys_book_source`·`lang_code` → 칸 이름만.
  ⚠ **값은 그대로다** — `record_status` 는 여전히 `LIVE`/`HIDE` 다.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import appdb
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import panel_std                 # 표준 탭 묶음 (2026-08-24 · 1단계)

DB = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'bible_master.db')

_CAT_ORDER  = ['DEVOTIONAL', 'SPIRITUALITY', 'FICTION', 'BIOGRAPHY', 'DOCTRINE', 'HISTORY', 'SERMON']
_CAT_LABELS = {
    'DEVOTIONAL':   '일일묵상',
    'SPIRITUALITY': '영성고전',
    'FICTION':      '신앙소설',
    'BIOGRAPHY':    '고백/전기',
    'DOCTRINE':     '교리입문',
    'HISTORY':      '역사배경',    # 2026-08-18 에더샤임 3권(db_edersheim_import)
    'SERMON':       '설교',
}
_SESSION_TYPES   = ['CHAPTER', 'SERMON', 'MORNING', 'EVENING', 'SECTION']
_COPYRIGHT_TYPES = ['PUBLIC_DOMAIN', 'LICENSED']
import lang_compare                      # 원문 잠금 · 다국어 비교 (2026-08-25 · 2-A)
import lang_config                       # 언어 단일 소스(sys_language) — 도서 본문 언어=원문 포함
_LANG_CODES      = lang_config.all_langs()
# ★★★ **언어 이름·칩은 `admin/lang_ui` 하나에서 온다**(2026-09-18
#   사용자 「관리자화면에 등장하는 모든 언어라벨을 **도서관리 화면의
#   방식으로 통일**」·「모든 언어콤보를 **영어로 통일**」).
#   ⚠ 옛 코드는 화면마다 표를 베껴 갖고 있었고 서로 달라서 **한 콤보 안에서
#     영어와 현지어가 섞였다**(Chinese · 中文(繁體) · 日本語 · Русский).
#     여기에 다시 적지 말 것 — 늘어나는 언어도 저절로 따라온다.
import lang_ui as _lu
_LANG_CODE_TO_NAME = {c: _lu.name_en(c) for c in _lu.codes()}
_LANG_CODE_TO_NAME.update(_lu.EXTRA_NAME)
# ⚠ **그 화면이 쓰는 코드 목록 그대로** 이름을 만든다 — 도서관리는
#   `all_langs()`(원문 HE·EL·COP 포함)라 `_lu.names()`(UI 열하나)로
#   갈아 끼우면 **원문 언어가 콤보에서 사라진다**(실측으로 잡았다).
_LANG_DISPLAY_NAMES = [_LANG_CODE_TO_NAME.get(c, _lu.name_en(c))
                       for c in _LANG_CODES]
_LANG_CHIP_BG = dict(_lu.CHIP_BG)

_REF_SRC_TYPE_LABELS = {
    'CATECHISM':        '교리문답',
    'TOPICAL':          '주제별',
    'DICTIONARY':       '사전',
    'CHARACTER_STUDY':  '인물연구',
    'HISTORICAL':       '역사적 배경',
}

_VARIANT_ABBR = {
    'ORIGINAL':    'O',
    'MODERN_EN':   'M',
    'TRANSLATED':  'T',
    'SUMMARY':     'S',
}
_VARIANT_KO = {
    'ORIGINAL':    '원문',
    'MODERN_EN':   '현대어',
    'TRANSLATED':  '번역',
    'SUMMARY':     '요약',
}


def _render_chips(parent, items):
    """언어 칩 — `lang_ui` 한 문에 위임(도서관리 방식)."""
    _lu.render_chips(parent, items)

def _code_to_name(code: str) -> str:
    return _lu.name_en(code)


def _name_to_code(name: str) -> str:
    return _lu.code_of(name)


def _ensure_title_col(conn) -> None:
    """`sys_ref_text.title`(2026-08-10 신설)이 없으면 만든다. 멱등.

    ⚠ 이 칸이 없는 DB 로 열면 조회 SQL 이 통째로 터진다.
    """
    try:
        import db_ref_unit_load as RU
        RU.ensure_title_col(conn)
    except Exception as e:
        print('[book_manager ensure title] %s' % e)


def _db() -> sqlite3.Connection:
    return appdb.connect(DB, timeout=30)


class BookManagerPanel(ttk.Frame):

    #: 이 패널이 맡을 갈래 — 메뉴 하나에 주제 하나 (2026-08-15 사용자 지시
    #: 「서브탭을 만드는 것보다 한 메뉴에 한 주제를 담는 것도 매우 직관적이고 좋다」).
    #: ⚠ 셋 다 같은 표(`sys_book_*` / `sys_ref_*`)를 쓰므로 **클래스는 하나**로 두고
    #:   왼쪽 목록만 갈라 놓는다. 코드를 세 벌로 베끼면 갈라진다.
    MODES = {'BOOK': ' 도서 ', 'SERMON': ' 설교집 ', 'REF': ' 교리문답 '}

    def __init__(self, parent, mode=None):
        super().__init__(parent)
        # None = 예전처럼 셋 다 (되돌릴 자리)
        self._mode = mode if mode in self.MODES else None
        self._book_id: int | None = None
        self._is_new:  bool = False
        self._books:   dict[int, dict] = {}
        self._all_units: list = []
        self._current_uid: int | None = None
        self._panel_lang_var = tk.StringVar(value='KO')
        self._tr_text_id: int | None = None
        self._tr_left_text_id: int | None = None
        # doctrine/ref source state
        self._ref_src_id: int | None = None
        self._current_ref_unit_id: int | None = None
        self._all_ref_units: list = []
        self._doc_src_left_tid: int | None = None
        self._doc_src_right_tid: int | None = None
        # 맡지 않은 갈래의 나무는 만들지 않는다 — 쓰는 쪽이 None 을 견딘다
        self._tv = None
        self._sermon_tree = None   # 교리문답 나무는 `_ref_tv` — hasattr 로 지킨다
        self._build()
        self._load_book_list()
        self._load_ref_source_list()

    # ── 레이아웃 ──────────────────────────────────────────────────────────────

    def _build(self):
        pw = ttk.PanedWindow(self, orient='horizontal')
        pw.pack(fill='both', expand=True)

        lf = ttk.Frame(pw, width=200)
        lf.pack_propagate(False)
        pw.add(lf, weight=0)

        rf = ttk.Frame(pw)
        pw.add(rf, weight=1)

        self._build_left(lf)
        self._build_right(rf)

    # ── 왼쪽: 도서/설교집 탭 ─────────────────────────────────────────────────

    def _build_left(self, f):
        """왼쪽 목록. **맡은 갈래 하나만** 그린다 (2026-08-15).

        ⚠ 예전에는 도서·설교집·자료실 세 탭이 한 화면에 있었다. 그래서
          ① 사전이 이 화면과 「사전 관리자」 두 곳에서 편집됐고
          ② 설교집 3,573 유닛과 도서가 같은 자리를 다퉜다.
          메뉴를 갈라 **한 메뉴에 한 주제**로 둔다 — 화면이 닮아도 축이 다르다.
        """
        ttk.Label(f, text={'BOOK': '도서 목록', 'SERMON': '설교집 목록',
                           'REF': '교리문답 목록'}.get(self._mode, '목록'),
                  font=('', 9, 'bold')).pack(anchor='w', padx=6, pady=(6, 2))

        s = ttk.Style()
        s.configure('BM.Treeview', font=('Malgun Gothic', 9), rowheight=22)

        self._left_tab_nb = ttk.Notebook(f)
        self._left_tab_nb.pack(fill='both', expand=True)

        want = self._mode
        if want in (None, 'BOOK'):
            book_tab = ttk.Frame(self._left_tab_nb)
            self._left_tab_nb.add(book_tab, text=' 도서 ')
            self._build_book_tree_left(book_tab)
        if want in (None, 'SERMON'):
            sermon_tab = ttk.Frame(self._left_tab_nb)
            self._left_tab_nb.add(sermon_tab, text=' 설교집 ')
            self._build_sermon_tree_left(sermon_tab)
        if want in (None, 'REF'):
            doc_tab = ttk.Frame(self._left_tab_nb)
            self._left_tab_nb.add(doc_tab, text=' 교리문답 ')
            self._build_ref_source_tree_left(doc_tab)

    def _build_book_tree_left(self, f):
        # ★ **묶는 축을 고른다**(2026-09-18 사용자 「왼쪽 도서목록 트리 :
        #   주제별/저자별 버튼을 추가하라」). 실측 도서 35권 · 저자 28명이라
        #   저자별로 묶으면 대부분 한 권짜리 가지가 되지만, **그 사람의 책이
        #   몇 권인지**가 한눈에 보이는 것이 이 축의 값이다(스펄전 4 · 에더샤임 3).
        #   ⚠ 고른 축은 기억한다 — 화면을 다시 열 때 되돌아가면 손이 헛돈다.
        axis_bar = ttk.Frame(f)
        axis_bar.pack(fill='x', padx=4, pady=(2, 0))
        self._book_axis = tk.StringVar(value=self._read_axis())
        for val, lbl in (('CAT', '주제별'), ('AUTHOR', '저자별')):
            ttk.Radiobutton(axis_bar, text=lbl, value=val,
                            variable=self._book_axis,
                            command=self._on_book_axis).pack(side='left',
                                                             padx=(0, 10))
        vsb = ttk.Scrollbar(f, orient='vertical')
        vsb.pack(side='right', fill='y', pady=(2, 0))
        self._tv = ttk.Treeview(f, show='tree', selectmode='browse',
                                style='BM.Treeview', yscrollcommand=vsb.set)
        vsb.config(command=self._tv.yview)
        self._tv.pack(fill='both', expand=True, padx=(4, 0), pady=2)
        self._tv.tag_configure('cat',  foreground='#1A252F',
                               font=('Malgun Gothic', 9, 'bold'))
        self._tv.tag_configure('live', foreground='#2C3E50')
        self._tv.tag_configure('hide', foreground='#AAAAAA')
        self._tv.bind('<<TreeviewSelect>>', self._on_tree_select)
        # ★ **값을 바꾸는 단추는 맨 위**(§0 · 2026-09-22) — 트리가
        #   expand 라 뒤에 담으면 y=870/900 으로 밀려 창이 작을 때 안 보인다.
        ttk.Button(f, text='+ 신규 도서',
                   command=lambda: self._new_book('DEVOTIONAL')).pack(
            fill='x', padx=4, pady=(0, 2), before=axis_bar)

    def _build_sermon_tree_left(self, f):
        vsb = ttk.Scrollbar(f, orient='vertical')
        vsb.pack(side='right', fill='y', pady=(2, 0))
        self._sermon_tree = ttk.Treeview(f, show='tree', selectmode='browse',
                                         style='BM.Treeview', yscrollcommand=vsb.set)
        vsb.config(command=self._sermon_tree.yview)
        self._sermon_tree.pack(fill='both', expand=True, padx=(4, 0), pady=2)
        self._sermon_tree.tag_configure('cat',  foreground='#1A252F',
                                        font=('Malgun Gothic', 9, 'bold'))
        self._sermon_tree.tag_configure('live', foreground='#2C3E50')
        self._sermon_tree.tag_configure('hide', foreground='#AAAAAA')
        self._sermon_tree.bind('<<TreeviewSelect>>', self._on_tree_select)
        # ★ **맨 위**(§0) — 위와 같은 까닭
        ttk.Button(f, text='+ 신규 설교집',
                   command=lambda: self._new_book('SERMON')).pack(
            fill='x', padx=4, pady=(0, 2), before=vsb)

    _AXIS_KEY = 'ADM_BOOK_TREE_AXIS'

    def _read_axis(self):
        """선택한 축을 되살린다 — 없으면 주제별(지금까지의 모습)."""
        try:
            conn = _db()
            row = conn.execute("SELECT config_val FROM user_config "
                               "WHERE config_key=?", (self._AXIS_KEY,)).fetchone()
            conn.close()
            if row and row[0] in ('CAT', 'AUTHOR'):
                return row[0]
        except Exception:
            pass
        return 'CAT'

    def _on_book_axis(self):
        val = self._book_axis.get()
        try:
            conn = _db()
            conn.execute("INSERT INTO user_config (config_key, config_val) "
                         "VALUES (?,?) ON CONFLICT(config_key) DO UPDATE "
                         "SET config_val=excluded.config_val",
                         (self._AXIS_KEY, val))
            conn.commit()
            conn.close()
        except Exception:
            pass
        self._load_book_list(reselect_id=self._book_id)

    def _fill_book_tree_by_author(self, rows):
        """저자 ▸ 도서. ⚠ 저자를 모르는 책도 **자리를 준다**(§0-1)."""
        by_author = {}
        for bid, code, title, author, cat, status in rows:
            if (cat or 'DEVOTIONAL') == 'SERMON':
                continue
            key = (author or '').strip() or '(저자 없음)'
            by_author.setdefault(key, []).append((bid, title, status))
        for author in sorted(by_author, key=lambda a: (a == '(저자 없음)', a)):
            items = by_author[author]
            iid = 'AU_%s' % author
            self._tv.insert('', 'end', iid=iid,
                            text='%s  (%d)' % (author, len(items)),
                            tags=('cat',), open=True)
            for bid, title, status in items:
                self._tv.insert(iid, 'end', iid='B_%d' % bid,
                                text='  %s' % title,
                                tags=('live' if status == 'LIVE' else 'hide',))

    def _load_book_list(self, reselect_id: int | None = None):
        # ⚠ 맡은 갈래의 나무만 있다 — 나머지는 아예 만들지 않았다(`_build_left`).
        #   없는 것을 지우려 들면 그 자리에서 터진다.
        for tv in (self._tv, self._sermon_tree):
            if tv is not None:
                tv.delete(*tv.get_children())
        self._books.clear()

        try:
            conn = _db()
            rows = conn.execute(
                "SELECT book_id, book_code, title, author, book_category, record_status "
                "FROM sys_book_asset ORDER BY book_category, book_id"
            ).fetchall()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return

        non_sermon_order = [c for c in _CAT_ORDER if c != 'SERMON']
        by_cat: dict[str, list] = {c: [] for c in _CAT_ORDER}
        for bid, code, title, author, cat, status in rows:
            self._books[bid] = dict(book_id=bid, book_code=code, title=title,
                                    author=author, category=cat or 'DEVOTIONAL',
                                    status=status)
            bucket = by_cat.get(cat or 'DEVOTIONAL')
            if bucket is not None:
                bucket.append((bid, title, status))

        # 도서 탭 (non-SERMON) — 축이 저자별이면 그리로 넘긴다
        if self._tv is not None and getattr(self, '_book_axis', None) \
                and self._book_axis.get() == 'AUTHOR':
            self._fill_book_tree_by_author(rows)
            non_sermon_order = []
        for cat_code in (non_sermon_order if self._tv is not None else []):
            items = by_cat[cat_code]
            if not items:
                continue
            label = f'{_CAT_LABELS.get(cat_code, cat_code)}  ({len(items)})'
            cat_iid = f'CAT_{cat_code}'
            self._tv.insert('', 'end', iid=cat_iid, text=label,
                            tags=('cat',), open=True)
            for bid, title, status in items:
                tag = 'live' if status == 'LIVE' else 'hide'
                self._tv.insert(cat_iid, 'end', iid=f'B_{bid}',
                                text=f'  {title}', tags=(tag,))

        # 설교집 탭 (SERMON)
        sermon_items = by_cat.get('SERMON', [])
        if sermon_items and self._sermon_tree is not None:
            cat_iid = 'CAT_SERMON'
            self._sermon_tree.insert('', 'end', iid=cat_iid,
                                     text=f'설교  ({len(sermon_items)})',
                                     tags=('cat',), open=True)
            for bid, title, status in sermon_items:
                tag = 'live' if status == 'LIVE' else 'hide'
                self._sermon_tree.insert(cat_iid, 'end', iid=f'B_{bid}',
                                         text=f'  {title}', tags=(tag,))

        if reselect_id:
            iid = f'B_{reselect_id}'
            for idx, tv in enumerate((self._tv, self._sermon_tree)):
                if tv is not None and tv.exists(iid):
                    tv.selection_set(iid)
                    tv.see(iid)
                    self._left_tab_nb.select(0)   # 갈래마다 탭이 하나뿐이다
                    break

    # ── 번역 대시보드에서 넘어오는 점프 (2026-08-17) ─────────────────────────

    def receive_jump(self, jump: dict):
        """도서/설교 = {'book_id','unit_id','lang'} · 교리문답(REF) =
        {'src_id','unit_id','lang'}. 묶음 선택 + 유닛 목록 탭 + 유닛 선택 +
        오른쪽(번역) 편집기를 그 언어로."""
        lang = (jump.get('lang') or '').upper()
        uid = jump.get('unit_id')

        if jump.get('src_id') is not None:            # 교리문답 갈래
            src_id = jump['src_id']
            try:
                self._load_ref_source_list(reselect_id=src_id)
            except Exception:
                pass
            self._show_doc_panel()
            self._load_ref_source(src_id)
            if lang:
                self._doc_right_variant_var.set(
                    'ORIGINAL' if lang == 'EN' else 'TRANSLATED')
                self._doc_right_lang_var.set(_code_to_name(lang))
            self._doc_nb.select(1)
            self._load_ref_units(src_id)

            def _sel():
                iid = f'RU_{uid}'
                if uid and self._doc_unit_tv.exists(iid):
                    self._doc_unit_tv.selection_set(iid)
                    self._doc_unit_tv.see(iid)
                    self._on_doc_unit_select()
            self.after(200, _sel)
            return

        book_id = jump.get('book_id')
        if book_id:
            self._load_book_list(reselect_id=book_id)
            self._show_book_panel()
            self._load_book(book_id)
        if lang and hasattr(self, '_body_lang_var'):
            self._body_variant_var.set(
                'ORIGINAL' if lang == 'EN' else 'TRANSLATED')
            self._body_lang_var.set(_code_to_name(lang))
        self._nb.select(1)
        bid = book_id or self._book_id
        if bid:
            self._load_units(bid)

        def _sel2():
            iid = f'U_{uid}'
            if uid and self._unit_tv.exists(iid):
                self._unit_tv.selection_set(iid)
                self._unit_tv.see(iid)
                self._on_unit_select()
        self.after(200, _sel2)

    def _on_tree_select(self, event=None):
        tree = (event.widget if event else (self._tv or self._sermon_tree))
        if tree is None:
            return
        sel = tree.selection()
        if not sel:
            return
        iid = sel[0]
        if not iid.startswith('B_'):
            return
        try:
            book_id = int(iid[2:])
        except ValueError:
            return
        self._show_book_panel()
        self._load_book(book_id)

    # ── 오른쪽: Notebook ──────────────────────────────────────────────────────

    def _build_right(self, f):
        self._book_frame = ttk.Frame(f)
        self._book_frame.pack(fill='both', expand=True)

        self._doc_frame = ttk.Frame(f)

        self._nb = ttk.Notebook(self._book_frame)
        self._nb.pack(fill='both', expand=True, padx=2, pady=2)

        # ★★ **표준 탭 묶음**(2026-08-24 · 1단계 `admin/panel_std.py`) —
        #   `[기본정보] [«낱낱»] [본문] [번역] [연결] [경로]` 중 이 화면이 쓰는 것.
        #   ⚠ 자리는 표준, **낱낱의 이름만 이 화면의 말**(「유닛 목록」).
        #   ⚠ 없는 탭은 안 만든다 — 「본문」은 유닛 목록 안에서 이미 고치고 있다.
        tabs = panel_std.build(self._nb, {
            'BASIC': None,
            'ITEMS': ('유닛 목록', 'BM_TAB_UNITS'),
            'TRANS': None,
            'LINK': None,          # 2026-08-25 · 4-B — **새로 붙는다**
        })
        t1, t2 = tabs['BASIC'], tabs['ITEMS']

        self._build_tab1(t1)
        self._build_tab2(t2)
        self._build_trans_tab(tabs['TRANS'])
        self._build_link_tab(tabs['LINK'])
        self._nb.bind('<<NotebookTabChanged>>', self._on_tab_change)

        self._build_doc_right(self._doc_frame)

    def _show_book_panel(self):
        self._doc_frame.pack_forget()
        self._book_frame.pack(fill='both', expand=True)

    def _show_doc_panel(self):
        self._book_frame.pack_forget()
        self._doc_frame.pack(fill='both', expand=True)

    def _on_tab_change(self, _=None):
        i = self._nb.index('current')
        if i == 1 and self._book_id:
            self._load_units(self._book_id)
        elif i == 2:
            self._refresh_trans()
        elif i == 3 and getattr(self, '_link_tv', None) is not None:
            self._link_tv.refresh()

    # ── 연결 (표준 5번 자리) — 2026-08-25 · 4-B ──────────────────────────────
    # ★ **부품을 쓴다**(`panel_std.link_tab` → `link_picker` scope='SYS').
    #   화면마다 만들면 곧 열 벌이 갈라진다(§76 이 겪은 그대로).
    # ⚠ 대상은 **유닛이 골라져 있으면 유닛, 아니면 도서**다 — 연결은 편에도
    #   책에도 걸린다(실측: BUNT_* 407행 · BOOK_* 16행).

    def _link_owner(self):
        uid = getattr(self, '_current_uid', None)
        if uid:
            return ('BOOK_UNIT', uid)
        if getattr(self, '_book_id', None):
            return ('BOOK', self._book_id)
        return None

    def _build_link_tab(self, f):
        self._link_tv = panel_std.link_tab(
            f, self._link_owner,
            lang_getter=lambda: 'KO', scope='SYS')

    # ── 번역 현황 (표준 4번 자리) ─────────────────────────────────────────────
    # ★ **새로 짜지 않는다** — `admin/lang_status.py` 를 `panel_std.translation_tab`
    #   이 감싼다. 여섯 화면이 같은 표를 요구하는데(0.txt 78·84·88·93·97·100)
    #   화면마다 만들면 곧 여섯 벌이 갈라진다.
    # ⚠ **분수로 센다** — 도서 하나에 유닛이 수백 개라 「있다/없다」로는 못 읽는다
    #   (렌즈 관리가 같은 이유로 분수를 쓴다).

    def _build_trans_tab(self, f):
        self._trans_tbl = panel_std.translation_tab(
            f,
            columns=[('asset', '도서 정보', 90),
                     ('label', '유닛 제목', 90),
                     ('body', '본문', 90)],
            provider=self._trans_counts,
            on_pick=self._trans_pick,
            hint='줄을 두 번 누르면 「유닛 목록」에서 그 언어로 편집합니다.')

    def _trans_counts(self, lang):
        """그 언어의 보유 — `(된 수, 전체)`.

        ⚠ **본문은 언어마다 판본이 다르다** — EN 은 `ORIGINAL`(저자의 글),
          그 밖은 `TRANSLATED`. 번역 대시보드(§17차)가 세운 규칙 그대로다.
        """
        bid = self._book_id
        if not bid:
            return {}
        lang = (lang or '').upper()
        try:
            with appdb.connect() as c:
                units = c.execute(
                    "SELECT COUNT(*) FROM sys_book_unit "
                    " WHERE book_id=? AND COALESCE(record_status,'LIVE')='LIVE'",
                    (bid,)).fetchone()[0]
                asset = c.execute(
                    "SELECT COUNT(*) FROM sys_book_asset_text "
                    " WHERE book_id=? AND UPPER(lang_code)=? "
                    "   AND COALESCE(title,'')<>''", (bid, lang)).fetchone()[0]
                label = c.execute(
                    "SELECT COUNT(*) FROM sys_text_asset ta "
                    "  JOIN sys_book_unit u ON u.unit_id=ta.clicked_id "
                    " WHERE ta.text_type='BOOK_UNIT_LABEL' AND u.book_id=? "
                    "   AND UPPER(ta.lang_code)=? "
                    "   AND COALESCE(ta.record_status,'LIVE')='LIVE'",
                    (bid, lang)).fetchone()[0]
                variant = 'ORIGINAL' if lang == 'EN' else 'TRANSLATED'
                body = c.execute(
                    "SELECT COUNT(*) FROM sys_book_unit_text x "
                    "  JOIN sys_book_unit u ON u.unit_id=x.unit_id "
                    " WHERE u.book_id=? AND x.text_variant=? "
                    "   AND UPPER(x.lang_code)=? AND COALESCE(x.body_text,'')<>''",
                    (bid, variant, lang)).fetchone()[0]
        except Exception as e:
            print('[trans counts] %s' % e)
            return {}
        return {'asset': (min(asset, 1), 1),
                'label': (label, units),
                'body': (body, units)}

    def _refresh_trans(self):
        t = getattr(self, '_trans_tbl', None)
        if t is not None:
            try:
                t.refresh()
            except Exception as e:
                print('[trans refresh] %s' % e)

    def _trans_pick(self, lang):
        """두 번 누르면 「유닛 목록」으로 가서 그 언어로 편집한다."""
        try:
            self._nb.select(1)
            for nm in ('_tr_left_lang_cb', '_u_lang_cb', '_lang_cb'):
                cb = getattr(self, nm, None)
                if cb is not None:
                    cb.set(lang)
                    cb.event_generate('<<ComboboxSelected>>')
                    break
        except Exception as e:
            print('[trans pick] %s' % e)

    # ── Tab1: 기본정보 ────────────────────────────────────────────────────────

    def _build_tab1(self, f):
        self._t1_vars: dict[str, tk.Variable] = {}

        outer = ttk.Frame(f)
        outer.pack(fill='both', expand=True, padx=10, pady=8)

        def field(parent, label, key, widget_type='entry', values=None, width=44, lw=12):
            fr = ttk.Frame(parent)
            fr.pack(fill='x', pady=2, padx=4)
            ttk.Label(fr, text=label, width=lw, anchor='e').pack(side='left')
            if widget_type == 'entry':
                v = tk.StringVar()
                ttk.Entry(fr, textvariable=v, width=width).pack(side='left', padx=(4, 0))
            elif widget_type == 'combo':
                v = tk.StringVar()
                ttk.Combobox(fr, textvariable=v, values=values,
                             width=width - 2, state='readonly').pack(side='left', padx=(4, 0))
            self._t1_vars[key] = v

        # ── Section A: EN 기본정보 ─────────────────────────────────────────────
        en_f = ttk.LabelFrame(outer, text=' 도서 기본정보 (EN) ')
        en_f.pack(fill='x', pady=(0, 4))

        field(en_f, '제목 (title)',  'title',  width=48)
        field(en_f, '저자 (author)', 'author', width=40)

        desc_row = ttk.Frame(en_f)
        desc_row.pack(fill='x', pady=2, padx=4)
        ttk.Label(desc_row, text='도서 소개', width=12, anchor='ne').pack(
            side='left', anchor='n')
        desc_wrap = ttk.Frame(desc_row)
        desc_wrap.pack(side='left', fill='x', expand=True, padx=(4, 0))
        desc_vsb = ttk.Scrollbar(desc_wrap, orient='vertical')
        desc_vsb.pack(side='right', fill='y')
        self._t1_desc = tk.Text(desc_wrap, height=4, width=50, wrap='word',
                                 font=('Malgun Gothic', 9), yscrollcommand=desc_vsb.set)
        desc_vsb.config(command=self._t1_desc.yview)
        self._t1_desc.pack(fill='x', expand=True)

        # ── Section B: 짧은 컬럼 2단 배치 ────────────────────────────────────
        short_f = ttk.Frame(outer)
        short_f.pack(fill='x', pady=(4, 2))
        col1 = ttk.Frame(short_f)
        col1.pack(side='left', fill='x', expand=True)
        col2 = ttk.Frame(short_f)
        col2.pack(side='left', fill='x', expand=True)

        def sfield(parent, label, key, widget_type='entry', values=None, width=16):
            fr = ttk.Frame(parent)
            fr.pack(fill='x', pady=2, padx=4)
            ttk.Label(fr, text=label, width=9, anchor='e').pack(side='left')
            if widget_type == 'entry':
                v = tk.StringVar()
                ttk.Entry(fr, textvariable=v, width=width).pack(side='left', padx=(4, 0))
            elif widget_type == 'combo':
                v = tk.StringVar()
                ttk.Combobox(fr, textvariable=v, values=values,
                             width=width - 2, state='readonly').pack(side='left', padx=(4, 0))
            self._t1_vars[key] = v

        sfield(col1, '도서코드',  'book_code',      width=20)
        sfield(col1, '카테고리',  'book_category',  widget_type='combo', values=_CAT_ORDER,       width=14)
        sfield(col1, '저작권',    'copyright_type', widget_type='combo', values=_COPYRIGHT_TYPES, width=16)
        sfield(col2, '언어',      'lang_code',      widget_type='combo', values=_LANG_DISPLAY_NAMES, width=12)
        sfield(col2, '출판연도',  'pub_year',       width=8)
        sfield(col2, 'ISBN',      'isbn',            width=18)

        url_row = ttk.Frame(outer)
        url_row.pack(fill='x', pady=2, padx=4)
        ttk.Label(url_row, text='원문 URL', width=9, anchor='e').pack(side='left')
        url_v = tk.StringVar()
        ttk.Entry(url_row, textvariable=url_v, width=56).pack(side='left', padx=(4, 0))
        self._t1_vars['source_url'] = url_v

        # ── 출처 목록 (`sys_book_source`) ─────────────────────────────────────
        # ★ 사용자 지시(2026-08-22): 「관리자 화면을 수정해서 각각 url을 표시하라」.
        #   위 「원문 URL」 칸은 **한 곳**뿐인데 실제로는 여럿이다 —
        #   천로역정은 1부·2부가 다른 파일이고, 대조에 쓴 곳과 **버린 후보**도
        #   남아 있어야 같은 삽질을 안 한다.
        src_f = ttk.LabelFrame(outer, text=' 확인한 출처 ')
        src_f.pack(fill='x', pady=(6, 2))
        cols = ('role', 'pct', 'name', 'url', 'note')
        self._t1_src = ttk.Treeview(src_f, columns=cols, show='headings',
                                    height=4, selectmode='browse')
        for c, t, w in (('role', '역할', 74), ('pct', '일치', 48),
                        ('name', '이름', 210), ('url', '주소', 300),
                        ('note', '메모', 420)):
            self._t1_src.heading(c, text=t)
            self._t1_src.column(c, width=w, anchor='w',
                                stretch=(c == 'note'))
        sb = ttk.Scrollbar(src_f, orient='vertical',
                           command=self._t1_src.yview)
        self._t1_src.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._t1_src.pack(side='left', fill='x', expand=True)
        # 색은 역할로 — 버린 후보가 눈에 띄어야 한다
        self._t1_src.tag_configure('REJECTED', foreground='#B03A2E')
        self._t1_src.tag_configure('CROSS', foreground='#5D6D7E')
        self._t1_src.bind('<Double-1>', self._open_source_url)
        bar = ttk.Frame(src_f)
        bar.pack(side='bottom', fill='x')

        # ── 버튼 행 ───────────────────────────────────────────────────────────
        btn_f = ttk.Frame(outer)
        btn_f.pack(fill='x', pady=(8, 4))
        ttk.Button(btn_f, text='저장', command=self._save_book, width=10).pack(side='left')
        self._btn_status = ttk.Button(btn_f, text='숨기기',
                                      command=self._toggle_status, width=14)
        self._btn_status.pack(side='left', padx=(8, 0))
        ttk.Button(btn_f, text='새로고침', command=self._refresh_form,
                   width=10).pack(side='right')
        self._t1_status_lbl = ttk.Label(btn_f, text='', foreground='gray', font=('', 8))
        self._t1_status_lbl.pack(side='left', padx=(12, 0))

        # ── 구분선 ────────────────────────────────────────────────────────────
        ttk.Separator(outer, orient='horizontal').pack(fill='x', pady=(4, 6))

        # ── Section C: 번역 텍스트 — 좌우 비교 패널 ──────────────────────────
        tr_hdr = ttk.Frame(outer)
        tr_hdr.pack(fill='x', pady=(0, 2))
        ttk.Label(tr_hdr, text='번역 텍스트', font=('', 8, 'bold')).pack(side='left')
        self._tr_count_lbl = ttk.Label(tr_hdr, text='', foreground='gray', font=('', 8))
        self._tr_count_lbl.pack(side='left', padx=(8, 0))
        self._tr_lang_chips_f = tk.Frame(tr_hdr)
        self._tr_lang_chips_f.pack(side='left', padx=(10, 0))

        tr_pw = ttk.PanedWindow(outer, orient='horizontal')
        tr_pw.pack(fill='both', expand=True, pady=(0, 4))

        # 왼쪽: 편집 (좌측)
        tr_left_f = ttk.LabelFrame(tr_pw, text=' 수정 (좌) ')
        tr_pw.add(tr_left_f, weight=1)

        tr_l_ctrl = ttk.Frame(tr_left_f)
        tr_l_ctrl.pack(fill='x', padx=6, pady=(4, 2))
        ttk.Label(tr_l_ctrl, text='언어:').pack(side='left')
        self._tr_left_lang_var = tk.StringVar(value=_code_to_name('EN'))
        self._tr_left_lang_cb = ttk.Combobox(
            tr_l_ctrl, textvariable=self._tr_left_lang_var,
            values=_LANG_DISPLAY_NAMES, width=9, state='readonly')
        _lu.retrofit(self._tr_left_lang_cb)   # 언어 콤보 = 영어 이름(값은 코드 그대로)
        self._tr_left_lang_cb.pack(side='left', padx=(4, 0))
        self._tr_left_lang_cb.bind('<<ComboboxSelected>>',
                                    lambda _: self._on_tr_left_lang_change())
        ttk.Button(tr_l_ctrl, text='+ 신규', command=self._add_translation_left,
                   width=8).pack(side='left', padx=(8, 0))
        ttk.Button(tr_l_ctrl, text='저장', command=self._save_translation_left,
                   width=7).pack(side='left', padx=(6, 0))
        ttk.Button(tr_l_ctrl, text='삭제', command=self._delete_translation_left,
                   width=7).pack(side='left', padx=(4, 0))
        self._tr_left_status_lbl = ttk.Label(tr_l_ctrl, text='', foreground='gray',
                                              font=('', 8))
        self._tr_left_status_lbl.pack(side='left', padx=(6, 0))

        tr_l_title = ttk.Frame(tr_left_f)
        tr_l_title.pack(fill='x', padx=6, pady=2)
        ttk.Label(tr_l_title, text='제목', width=7, anchor='e').pack(side='left')
        self._tr_left_title_var = tk.StringVar()
        ttk.Entry(tr_l_title, textvariable=self._tr_left_title_var, width=28).pack(
            side='left', padx=(4, 0))

        tr_l_author = ttk.Frame(tr_left_f)
        tr_l_author.pack(fill='x', padx=6, pady=2)
        ttk.Label(tr_l_author, text='저자명', width=7, anchor='e').pack(side='left')
        self._tr_left_author_var = tk.StringVar()
        ttk.Entry(tr_l_author, textvariable=self._tr_left_author_var, width=28).pack(
            side='left', padx=(4, 0))

        tr_l_desc_wrap = ttk.Frame(tr_left_f)
        tr_l_desc_wrap.pack(fill='both', expand=True, padx=6, pady=2)
        tr_l_vsb = ttk.Scrollbar(tr_l_desc_wrap, orient='vertical')
        tr_l_vsb.pack(side='right', fill='y')
        self._tr_left_desc_txt = tk.Text(
            tr_l_desc_wrap, wrap='word', font=('Malgun Gothic', 9),
            yscrollcommand=tr_l_vsb.set)
        tr_l_vsb.config(command=self._tr_left_desc_txt.yview)
        self._tr_left_desc_txt.pack(fill='both', expand=True)

        # 오른쪽: 편집
        tr_right_f = ttk.LabelFrame(tr_pw, text=' 수정 (우) ')
        tr_pw.add(tr_right_f, weight=1)

        tr_r_ctrl = ttk.Frame(tr_right_f)
        tr_r_ctrl.pack(fill='x', padx=6, pady=(4, 2))
        ttk.Label(tr_r_ctrl, text='언어:').pack(side='left')
        self._tr_lang_var = tk.StringVar()
        _tr_r_lang_cb = ttk.Combobox(
            tr_r_ctrl, textvariable=self._tr_lang_var,
            values=_LANG_DISPLAY_NAMES, width=9, state='readonly')
        _lu.retrofit(_tr_r_lang_cb)   # 언어 콤보 = 영어 이름(값은 코드 그대로)
        _tr_r_lang_cb.pack(side='left', padx=(4, 0))
        _tr_r_lang_cb.bind('<<ComboboxSelected>>',
                            lambda _: self._on_tr_right_lang_change())
        ttk.Button(tr_r_ctrl, text='+ 신규', command=self._add_translation,
                   width=8).pack(side='left', padx=(8, 0))
        ttk.Button(tr_r_ctrl, text='저장', command=self._save_translation,
                   width=7).pack(side='left', padx=(6, 0))
        ttk.Button(tr_r_ctrl, text='삭제', command=self._delete_translation,
                   width=7).pack(side='left', padx=(4, 0))
        self._tr_status_lbl = ttk.Label(tr_r_ctrl, text='', foreground='gray',
                                         font=('', 8))
        self._tr_status_lbl.pack(side='left', padx=(6, 0))

        tr_r_title = ttk.Frame(tr_right_f)
        tr_r_title.pack(fill='x', padx=6, pady=2)
        ttk.Label(tr_r_title, text='제목', width=7, anchor='e').pack(side='left')
        self._tr_title_var = tk.StringVar()
        ttk.Entry(tr_r_title, textvariable=self._tr_title_var, width=28).pack(
            side='left', padx=(4, 0))

        tr_r_author = ttk.Frame(tr_right_f)
        tr_r_author.pack(fill='x', padx=6, pady=2)
        ttk.Label(tr_r_author, text='저자명', width=7, anchor='e').pack(side='left')
        self._tr_author_var = tk.StringVar()
        ttk.Entry(tr_r_author, textvariable=self._tr_author_var, width=28).pack(
            side='left', padx=(4, 0))

        tr_r_desc_wrap = ttk.Frame(tr_right_f)
        tr_r_desc_wrap.pack(fill='both', expand=True, padx=6, pady=2)
        tr_r_vsb = ttk.Scrollbar(tr_r_desc_wrap, orient='vertical')
        tr_r_vsb.pack(side='right', fill='y')
        self._tr_desc_txt = tk.Text(
            tr_r_desc_wrap, wrap='word', font=('Malgun Gothic', 9),
            yscrollcommand=tr_r_vsb.set)
        tr_r_vsb.config(command=self._tr_desc_txt.yview)
        self._tr_desc_txt.pack(fill='both', expand=True)

    def _open_source_url(self, _e=None):
        """출처 줄을 두 번 누르면 그 주소를 연다 — 사람이 직접 확인하도록."""
        tv = getattr(self, '_t1_src', None)
        if tv is None or not tv.selection():
            return
        url = tv.item(tv.selection()[0], 'values')[3]
        if url:
            import webbrowser
            webbrowser.open(url)

    def _load_sources(self, book_code):
        """`sys_book_source` 를 읽어 채운다. 표가 없어도 죽지 않는다."""
        tv = getattr(self, '_t1_src', None)
        if tv is None:
            return
        tv.delete(*tv.get_children())
        if not book_code:
            return
        try:
            conn = _db()
            rows = conn.execute(
                "SELECT role, match_pct, name, url, note FROM sys_book_source "
                " WHERE book_code=? AND COALESCE(record_status,'LIVE')='LIVE'"
                " ORDER BY CASE role WHEN 'PRIMARY' THEN 0 WHEN 'CROSS' THEN 1"
                "                    ELSE 2 END, src_id", (book_code,)).fetchall()
            conn.close()
        except Exception:
            rows = []          # 그 표가 없는 DB 로 열 수도 있다
        for role, pct, name, url, note in rows:
            tv.insert('', 'end',
                      values=(role, ('%d%%' % pct) if pct is not None else '-',
                              name or '', url or '',
                              ' '.join((note or '').split())),
                      tags=(role,))
        if not rows:
            tv.insert('', 'end',
                      values=('', '', '(확인한 출처가 아직 없습니다)', '', ''))

    def _load_book(self, book_id: int):
        self._book_id = book_id
        self._is_new  = False

        try:
            conn = _db()
            row = conn.execute(
                "SELECT book_code, title, author, book_category, lang_code, "
                "       copyright_type, pub_year, isbn, source_url, description, "
                "       record_status "
                "FROM sys_book_asset WHERE book_id=?", (book_id,)
            ).fetchone()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return

        if not row:
            return

        (code, title, author, cat, lang, ctype, year, isbn, url, desc, status) = row
        self._load_sources(code)

        keys = ['book_code','title','author','book_category','lang_code',
                'copyright_type','pub_year','isbn','source_url']
        vals = [code, title, author, cat or 'DEVOTIONAL',
                _code_to_name(lang or 'EN'),
                ctype or 'PUBLIC_DOMAIN', str(year or ''), isbn or '', url or '']
        for k, v in zip(keys, vals):
            self._t1_vars[k].set(v)

        self._t1_desc.delete('1.0', 'end')
        self._t1_desc.insert('1.0', desc or '')

        live = (status == 'LIVE')
        self._btn_status.config(
            text='숨기기' if live else '되살리기',
            style='TButton')
        self._t1_status_lbl.config(
            text=('현재: 보임' if live else '현재: 숨김'),
            foreground='#27AE60' if live else '#AAA')

        if self._nb.index('current') == 1:
            self._load_units(book_id)

        if hasattr(self, '_tr_left_lang_cb'):
            self._load_translations()

    def _load_translations(self):
        if not self._book_id or not hasattr(self, '_tr_left_lang_cb'):
            return
        try:
            conn = _db()
            rows = conn.execute(
                "SELECT lang_code FROM sys_book_asset_text "
                "WHERE book_id=? AND record_status='LIVE' ORDER BY lang_code",
                (self._book_id,)
            ).fetchall()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return
        langs = [r[0] for r in rows]
        self._tr_count_lbl.config(text=f'{len(langs)}개 번역')
        if hasattr(self, '_tr_lang_chips_f'):
            _render_chips(self._tr_lang_chips_f,
                          [(_code_to_name(lc), lc) for lc in langs])
        if not self._tr_left_lang_var.get():
            self._tr_left_lang_var.set(_code_to_name('EN'))
        self._on_tr_left_lang_change()
        if not self._tr_lang_var.get():
            self._tr_lang_var.set(_code_to_name('KO'))
        self._on_tr_right_lang_change()
        self._tr_status_lbl.config(text='')

    def _load_tr_left(self):
        if not self._book_id:
            return
        lang = _name_to_code(self._tr_left_lang_var.get())
        try:
            conn = _db()
            row = conn.execute(
                "SELECT text_id, title, author, description FROM sys_book_asset_text "
                "WHERE book_id=? AND lang_code=? AND record_status='LIVE'",
                (self._book_id, lang)
            ).fetchone()
            conn.close()
        except Exception:
            row = None
        if row:
            self._tr_left_text_id = row[0]
            self._tr_left_title_var.set(row[1] or '')
            self._tr_left_author_var.set(row[2] or '')
            self._tr_left_desc_txt.delete('1.0', 'end')
            if row[3]:
                self._tr_left_desc_txt.insert('1.0', row[3])
        else:
            self._tr_left_text_id = None
            self._tr_left_title_var.set('')
            self._tr_left_author_var.set('')
            self._tr_left_desc_txt.delete('1.0', 'end')
        self._tr_left_status_lbl.config(text='')

    def _on_tr_left_lang_change(self):
        self._load_tr_left()

    def _add_translation_left(self):
        self._tr_left_text_id = None
        self._tr_left_lang_var.set('')
        self._tr_left_title_var.set('')
        self._tr_left_author_var.set('')
        self._tr_left_desc_txt.delete('1.0', 'end')
        self._tr_left_status_lbl.config(text='')

    def _save_translation_left(self):
        if not self._book_id:
            messagebox.showwarning('선택 필요', '도서를 먼저 선택하세요.')
            return
        lang   = _name_to_code(self._tr_left_lang_var.get().strip())
        title  = self._tr_left_title_var.get().strip()
        author = self._tr_left_author_var.get().strip()
        desc   = self._tr_left_desc_txt.get('1.0', 'end-1c').strip()
        if not lang:
            messagebox.showwarning('입력 오류', '언어코드를 선택하세요.')
            return
        if not title and not desc:
            messagebox.showwarning('입력 오류', '번역 제목 또는 번역 소개를 입력하세요.')
            return
        try:
            conn = _db()
            if self._tr_left_text_id:
                conn.execute(
                    "UPDATE sys_book_asset_text "
                    "SET lang_code=?, title=?, author=?, description=? "
                    "WHERE text_id=?",
                    (lang, title or None, author or None, desc or None,
                     self._tr_left_text_id))
            else:
                conn.execute(
                    "INSERT INTO sys_book_asset_text "
                    "(book_id, lang_code, title, author, description, record_status) "
                    "VALUES (?,?,?,?,?,'LIVE')",
                    (self._book_id, lang, title or None, author or None,
                     desc or None))
                self._tr_left_text_id = conn.execute(
                    "SELECT last_insert_rowid()").fetchone()[0]
            conn.commit()
            conn.close()
        except sqlite3.IntegrityError:
            messagebox.showerror('중복 오류',
                                  f'언어코드 {lang}이(가) 이미 존재합니다.')
            return
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return
        self._tr_left_status_lbl.config(text='저장됨', foreground='#27AE60')
        self.after(2000, lambda: self._tr_left_status_lbl.config(text=''))
        self._load_translations()
        self._tr_left_lang_var.set(_code_to_name(lang))
        self._load_tr_left()

    def _delete_translation_left(self):
        if not self._tr_left_text_id:
            messagebox.showwarning('선택 필요',
                                    '삭제할 번역 언어코드를 왼쪽에서 선택하세요.')
            return
        lang = self._tr_left_lang_var.get()
        if not messagebox.askyesno('삭제 확인', f'{lang} 번역을 삭제하시겠습니까?'):
            return
        try:
            conn = _db()
            conn.execute(
                "UPDATE sys_book_asset_text SET record_status='HIDE' "
                "WHERE text_id=?", (self._tr_left_text_id,))
            conn.commit()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return
        self._tr_left_text_id = None
        self._tr_left_lang_var.set('')
        self._tr_left_title_var.set('')
        self._tr_left_author_var.set('')
        self._tr_left_desc_txt.delete('1.0', 'end')
        self._load_translations()

    def _on_tr_right_lang_change(self):
        if not self._book_id:
            return
        lang = _name_to_code(self._tr_lang_var.get())
        try:
            conn = _db()
            row = conn.execute(
                "SELECT text_id, title, author, description FROM sys_book_asset_text "
                "WHERE book_id=? AND lang_code=? AND record_status='LIVE'",
                (self._book_id, lang)
            ).fetchone()
            conn.close()
        except Exception:
            row = None
        if row:
            self._tr_text_id = row[0]
            self._tr_title_var.set(row[1] or '')
            self._tr_author_var.set(row[2] or '')
            self._tr_desc_txt.delete('1.0', 'end')
            if row[3]:
                self._tr_desc_txt.insert('1.0', row[3])
        else:
            self._tr_text_id = None
            self._tr_title_var.set('')
            self._tr_author_var.set('')
            self._tr_desc_txt.delete('1.0', 'end')
        self._tr_status_lbl.config(text='')

    def _add_translation(self):
        self._tr_text_id = None
        self._tr_lang_var.set('')
        self._tr_title_var.set('')
        self._tr_author_var.set('')
        self._tr_desc_txt.delete('1.0', 'end')
        self._tr_status_lbl.config(text='')

    def _save_translation(self):
        if not self._book_id:
            messagebox.showwarning('선택 필요', '도서를 먼저 선택하세요.')
            return
        lang   = _name_to_code(self._tr_lang_var.get().strip())
        title  = self._tr_title_var.get().strip()
        author = self._tr_author_var.get().strip()
        desc   = self._tr_desc_txt.get('1.0', 'end-1c').strip()
        if not lang:
            messagebox.showwarning('입력 오류', '언어코드를 선택하세요.')
            return
        if not title and not desc:
            messagebox.showwarning('입력 오류', '번역 제목 또는 번역 소개를 입력하세요.')
            return
        try:
            conn = _db()
            if self._tr_text_id:
                conn.execute(
                    "UPDATE sys_book_asset_text "
                    "SET lang_code=?, title=?, author=?, description=? "
                    "WHERE text_id=?",
                    (lang, title or None, author or None, desc or None,
                     self._tr_text_id))
            else:
                conn.execute(
                    "INSERT INTO sys_book_asset_text "
                    "(book_id, lang_code, title, author, description, record_status) "
                    "VALUES (?,?,?,?,?,'LIVE')",
                    (self._book_id, lang, title or None, author or None,
                     desc or None))
                self._tr_text_id = conn.execute(
                    "SELECT last_insert_rowid()").fetchone()[0]
            conn.commit()
            conn.close()
        except sqlite3.IntegrityError:
            messagebox.showerror('중복 오류',
                                  f'언어코드 {lang}이(가) 이미 존재합니다.')
            return
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return
        self._tr_status_lbl.config(text='저장됨', foreground='#27AE60')
        self.after(2000, lambda: self._tr_status_lbl.config(text=''))
        self._load_translations()
        self._tr_lang_var.set(_code_to_name(lang))
        self._on_tr_right_lang_change()

    def _delete_translation(self):
        if not self._tr_text_id:
            messagebox.showwarning('선택 필요',
                                    '삭제할 번역 언어코드를 오른쪽에서 선택하세요.')
            return
        lang = self._tr_lang_var.get()
        if not messagebox.askyesno('삭제 확인', f'{lang} 번역을 삭제하시겠습니까?'):
            return
        try:
            conn = _db()
            conn.execute(
                "UPDATE sys_book_asset_text SET record_status='HIDE' "
                "WHERE text_id=?", (self._tr_text_id,))
            conn.commit()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return
        self._tr_text_id = None
        self._tr_lang_var.set('')
        self._tr_title_var.set('')
        self._tr_author_var.set('')
        self._tr_desc_txt.delete('1.0', 'end')
        self._load_translations()

    def _refresh_form(self):
        if self._book_id:
            self._load_book(self._book_id)

    def _save_book(self):
        title    = self._t1_vars['title'].get().strip()
        code     = self._t1_vars['book_code'].get().strip()
        author   = self._t1_vars['author'].get().strip()
        cat      = self._t1_vars['book_category'].get().strip()
        lang     = _name_to_code(self._t1_vars['lang_code'].get().strip()) or 'EN'
        ctype    = self._t1_vars['copyright_type'].get().strip() or 'PUBLIC_DOMAIN'
        year_s   = self._t1_vars['pub_year'].get().strip()
        isbn     = self._t1_vars['isbn'].get().strip()
        url      = self._t1_vars['source_url'].get().strip()
        desc     = self._t1_desc.get('1.0', 'end-1c').strip()

        if not title or not code:
            messagebox.showwarning('입력 오류', '제목과 도서코드는 필수입니다.')
            return

        year = None
        if year_s:
            try:
                year = int(year_s)
            except ValueError:
                messagebox.showwarning('입력 오류', '출판연도는 정수로 입력하세요.')
                return

        try:
            conn = _db()
            if self._is_new:
                conn.execute(
                    "INSERT INTO sys_book_asset "
                    "(book_code, title, author, lang_code, copyright_type, "
                    " pub_year, isbn, source_url, description, "
                    " book_category, record_status) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (code, title, author or None, lang, ctype,
                     year, isbn or None, url or None, desc or None,
                     cat or 'DEVOTIONAL', 'LIVE'))
                new_id = conn.execute(
                    "SELECT last_insert_rowid()").fetchone()[0]
                conn.commit()
                conn.close()
                self._book_id = new_id
                self._is_new  = False
                self._load_book_list(reselect_id=new_id)
                messagebox.showinfo('완료', f'도서 등록 완료 (book_id={new_id})')
            else:
                conn.execute(
                    "UPDATE sys_book_asset SET "
                    "book_code=?, title=?, author=?, lang_code=?, "
                    "copyright_type=?, pub_year=?, isbn=?, source_url=?, "
                    "description=?, book_category=? "
                    "WHERE book_id=?",
                    (code, title, author or None, lang, ctype,
                     year, isbn or None, url or None, desc or None,
                     cat or 'DEVOTIONAL', self._book_id))
                conn.commit()
                conn.close()
                self._load_book_list(reselect_id=self._book_id)
                self._t1_status_lbl.config(text='저장 완료', foreground='#27AE60')
                self.after(2000, lambda: self._refresh_form())
        except sqlite3.IntegrityError as e:
            messagebox.showerror('중복 오류', f'book_code가 이미 존재합니다.\n{e}')
        except Exception as e:
            messagebox.showerror('오류', str(e))

    def _toggle_status(self):
        if not self._book_id:
            return
        try:
            conn = _db()
            cur = conn.execute(
                "SELECT record_status FROM sys_book_asset WHERE book_id=?",
                (self._book_id,)
            ).fetchone()
            if not cur:
                conn.close()
                return
            new_status = 'HIDE' if cur[0] == 'LIVE' else 'LIVE'
            conn.execute(
                "UPDATE sys_book_asset SET record_status=? WHERE book_id=?",
                (new_status, self._book_id))
            conn.commit()
            conn.close()
            self._load_book_list(reselect_id=self._book_id)
            self._load_book(self._book_id)
        except Exception as e:
            messagebox.showerror('오류', str(e))

    def _new_book(self, default_cat: str = 'DEVOTIONAL'):
        self._book_id = None
        self._is_new  = True
        for k, v in self._t1_vars.items():
            v.set(_code_to_name('EN') if k == 'lang_code' else
                  'PUBLIC_DOMAIN' if k == 'copyright_type' else
                  default_cat if k == 'book_category' else '')
        self._t1_desc.delete('1.0', 'end')
        self._btn_status.config(text='(저장 후 변경 가능)')
        self._t1_status_lbl.config(text='신규', foreground='#1A5276')
        if hasattr(self, '_tr_count_lbl'):
            self._tr_count_lbl.config(text='')
        if hasattr(self, '_tr_left_lang_cb'):
            self._tr_left_lang_var.set('')
            self._tr_left_title_var.set('')
            self._tr_left_author_var.set('')
            self._tr_left_desc_txt.delete('1.0', 'end')
            self._tr_left_text_id = None
            self._tr_left_status_lbl.config(text='')
        if hasattr(self, '_tr_lang_var'):
            self._tr_lang_var.set('')
            self._tr_title_var.set('')
            self._tr_author_var.set('')
            self._tr_desc_txt.delete('1.0', 'end')
            self._tr_text_id = None
        self._nb.select(0)
        self._tv.selection_remove(*self._tv.selection())
        self._sermon_tree.selection_remove(*self._sermon_tree.selection())

    # ── Tab2: 유닛 목록 ───────────────────────────────────────────────────────

    def _build_tab2(self, f):
        # 필터 바
        filter_f = ttk.Frame(f)
        filter_f.pack(fill='x', padx=8, pady=(6, 2))
        ttk.Label(filter_f, text='제목 검색:').pack(side='left')
        self._filter_var = tk.StringVar()
        self._filter_var.trace_add('write', lambda *_: self._apply_unit_filter())
        ttk.Entry(filter_f, textvariable=self._filter_var, width=30).pack(
            side='left', padx=(4, 0))
        ttk.Button(filter_f, text='초기화', width=6,
                   command=lambda: self._filter_var.set('')).pack(side='left', padx=(6, 0))

        # 버튼 행
        btn_f = ttk.Frame(f)
        btn_f.pack(fill='x', padx=8, pady=(2, 2))
        ttk.Button(btn_f, text='+ 유닛 추가', command=self._add_unit).pack(side='left')
        ttk.Button(btn_f, text='수정',        command=self._edit_unit).pack(
            side='left', padx=(6, 0))
        ttk.Button(btn_f, text='삭제',        command=self._delete_unit).pack(
            side='left', padx=(6, 0))
        self._t2_count_lbl = ttk.Label(btn_f, text='', foreground='gray',
                                       font=('', 8))
        self._t2_count_lbl.pack(side='left', padx=(12, 0))

        # 세로 분할: 상단=유닛 목록, 하단=본문 패널
        vpw = ttk.PanedWindow(f, orient='vertical')
        vpw.pack(fill='both', expand=True, padx=(8, 4), pady=(0, 4))

        # 상단: 유닛 트리뷰
        top_f = ttk.Frame(vpw)
        vpw.add(top_f, weight=2)

        cols = ('seq', 'type', 'label', 'verse_ref', 'texts')
        self._unit_tv = ttk.Treeview(top_f, columns=cols, show='headings',
                                      selectmode='browse', height=10)
        self._unit_tv.heading('seq',       text='순서')
        self._unit_tv.heading('type',      text='유형')
        self._unit_tv.heading('label',     text='제목')
        self._unit_tv.heading('verse_ref', text='성경 본문')
        self._unit_tv.heading('texts',     text='번역 현황')

        self._unit_tv.column('seq',       width=45,  stretch=False, anchor='center')
        self._unit_tv.column('type',      width=70,  stretch=False)
        self._unit_tv.column('label',     width=240, stretch=True)
        self._unit_tv.column('verse_ref', width=130, stretch=False)
        self._unit_tv.column('texts',     width=120, stretch=False)

        vsb = ttk.Scrollbar(top_f, orient='vertical', command=self._unit_tv.yview)
        self._unit_tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        self._unit_tv.pack(fill='both', expand=True)
        self._unit_tv.bind('<<TreeviewSelect>>', self._on_unit_select)

        # 하단: 본문 내용 패널 (좌우 비교)
        bot_f = ttk.LabelFrame(vpw, text=' 본문 내용 ')
        vpw.add(bot_f, weight=1)

        unit_strip_f = ttk.Frame(bot_f)
        unit_strip_f.pack(fill='x', padx=6, pady=(4, 0))
        ttk.Label(unit_strip_f, text='번역:', font=('', 8)).pack(side='left')
        self._unit_lang_strip = tk.Frame(unit_strip_f)
        self._unit_lang_strip.pack(side='left', padx=(4, 0))

        body_pw = ttk.PanedWindow(bot_f, orient='horizontal')
        body_pw.pack(fill='both', expand=True, padx=4, pady=(2, 4))

        # ── 왼쪽: 편집 (좌) ─────────────────────────────────────────────────
        left_body_f = ttk.LabelFrame(body_pw, text=' 수정 (좌) ')
        body_pw.add(left_body_f, weight=1)

        left_ctrl = ttk.Frame(left_body_f)
        left_ctrl.pack(fill='x', padx=4, pady=(4, 2))
        self._left_variant_var = tk.StringVar(value='MODERN_EN')
        for _val, _lbl in [('ORIGINAL', '원문'), ('MODERN_EN', '현대어'),
                            ('TRANSLATED', '번역'), ('SUMMARY', '요약')]:
            ttk.Radiobutton(left_ctrl, text=_lbl, variable=self._left_variant_var,
                            value=_val,
                            command=self._on_left_variant_change).pack(
                side='left', padx=(0, 3))
        self._left_lang_var = tk.StringVar(value=_code_to_name('EN'))
        self._left_lang_cb = ttk.Combobox(
            left_ctrl, textvariable=self._left_lang_var,
            values=_LANG_DISPLAY_NAMES, width=9, state='readonly')
        _lu.retrofit(self._left_lang_cb)   # 언어 콤보 = 영어 이름(값은 코드 그대로)
        self._left_lang_cb.pack(side='left', padx=(4, 0))
        self._left_lang_cb.bind('<<ComboboxSelected>>',
                                 lambda _: self._refresh_left_body())
        # ★★ **왼쪽은 기준 자리 — 읽기 전용**(2026-08-25 사용자 확정
        #   「왼쪽을 선택하고 이것이 기준이다. **오른쪽을 선택한 것들이
        #   수정대상이다**」). 저장·HIDE 단추를 뗐다.
        #   ⚠ **자리 규칙과 잠금 규칙은 다른 것이다** — 잠금(`ORIGINAL`)은
        #     좌·우 어디서든 걸리고(2-A), 자리 규칙은 「왼쪽이면 못 고친다」다.
        #     그래서 **왼쪽 한국어 · 오른쪽 중국어로 중국어를 고치는 것은 된다.**
        #   ⚠ `_save_body_text_left`·`_hide_body_text_left` 는 **지우지 않았다** —
        #     되돌릴 때 필요하고, 자물쇠(2-A)가 그 안에 걸려 있다.
        ttk.Label(left_ctrl, text='기준 · 읽기 전용',
                  foreground='#7F8C8D').pack(side='left', padx=(8, 0))
        self._left_body_save_lbl = ttk.Label(
            left_ctrl, text='', foreground='gray', font=('', 8))
        self._left_body_save_lbl.pack(side='left', padx=(6, 0))

        left_lbl_f = ttk.Frame(left_body_f)
        left_lbl_f.pack(fill='x', padx=4, pady=(2, 0))
        ttk.Label(left_lbl_f, text='제목:', width=5, anchor='e').pack(side='left')
        self._left_unit_trans_var = tk.StringVar()
        # ⚠ 왼쪽은 기준 자리 — 제목도 읽기 전용이다(위 참조).
        ttk.Entry(left_lbl_f, textvariable=self._left_unit_trans_var,
                  width=22, state='readonly').pack(side='left', padx=(4, 6))
        self._left_label_save_lbl = ttk.Label(
            left_lbl_f, text='', foreground='gray', font=('', 8))
        self._left_label_save_lbl.pack(side='left')

        self._left_body_meta_lbl = ttk.Label(
            left_body_f, text='', foreground='gray', font=('Malgun Gothic', 7))
        self._left_body_meta_lbl.pack(anchor='w', padx=4)

        left_body_wrap = ttk.Frame(left_body_f)
        left_body_wrap.pack(fill='both', expand=True, padx=4, pady=(0, 2))
        l_vsb = ttk.Scrollbar(left_body_wrap, orient='vertical')
        l_vsb.pack(side='right', fill='y')
        self._left_body_txt = tk.Text(
            left_body_wrap, wrap='word', font=('Malgun Gothic', 9),
            relief='flat', bg='#FAFAFA',
            state='disabled',                  # 기준 자리 — 읽기 전용
            yscrollcommand=l_vsb.set)
        l_vsb.config(command=self._left_body_txt.yview)
        self._left_body_txt.pack(fill='both', expand=True)

        # ── 오른쪽: 편집 ────────────────────────────────────────────────────
        right_body_f = ttk.LabelFrame(body_pw, text=' 수정 (우) ')
        body_pw.add(right_body_f, weight=1)

        right_ctrl = ttk.Frame(right_body_f)
        right_ctrl.pack(fill='x', padx=4, pady=(4, 2))
        self._body_variant_var = tk.StringVar(value='MODERN_EN')
        for _val, _lbl in [('ORIGINAL', '원문'), ('MODERN_EN', '현대어'),
                            ('TRANSLATED', '번역'), ('SUMMARY', '요약')]:
            ttk.Radiobutton(right_ctrl, text=_lbl,
                            variable=self._body_variant_var,
                            value=_val,
                            command=self._on_variant_change).pack(
                side='left', padx=(0, 3))
        self._body_lang_var = tk.StringVar(value=_code_to_name('EN'))
        self._body_lang_cb = ttk.Combobox(
            right_ctrl, textvariable=self._body_lang_var,
            values=_LANG_DISPLAY_NAMES, width=9, state='readonly')
        _lu.retrofit(self._body_lang_cb)   # 언어 콤보 = 영어 이름(값은 코드 그대로)
        self._body_lang_cb.pack(side='left', padx=(4, 0))
        self._body_lang_cb.bind('<<ComboboxSelected>>',
                                 lambda _: self._refresh_body_text())
        ttk.Button(right_ctrl, text='저장', command=self._save_body_text,
                   width=6).pack(side='left', padx=(8, 0))
        ttk.Button(right_ctrl, text='숨기기', command=self._hide_body_text,
                   width=6).pack(side='left', padx=(4, 0))
        self._body_save_lbl = ttk.Label(
            right_ctrl, text='', foreground='gray', font=('', 8))
        self._body_save_lbl.pack(side='left', padx=(6, 0))

        right_lbl_f = ttk.Frame(right_body_f)
        right_lbl_f.pack(fill='x', padx=4, pady=(2, 0))
        ttk.Label(right_lbl_f, text='제목:', width=5, anchor='e').pack(side='left')
        self._unit_trans_var = tk.StringVar()
        ttk.Entry(right_lbl_f, textvariable=self._unit_trans_var,
                  width=22).pack(side='left', padx=(4, 6))
        self._unit_label_save_lbl = ttk.Label(
            right_lbl_f, text='', foreground='gray', font=('', 8))
        self._unit_label_save_lbl.pack(side='left')

        self._body_meta_lbl = ttk.Label(
            right_body_f, text='', foreground='gray', font=('Malgun Gothic', 7))
        self._body_meta_lbl.pack(anchor='w', padx=4)

        right_body_wrap = ttk.Frame(right_body_f)
        right_body_wrap.pack(fill='both', expand=True, padx=4, pady=(0, 2))
        r_vsb = ttk.Scrollbar(right_body_wrap, orient='vertical')
        r_vsb.pack(side='right', fill='y')
        self._body_txt = tk.Text(
            right_body_wrap, wrap='word', font=('Malgun Gothic', 9),
            relief='flat', bg='#FAFAFA',
            yscrollcommand=r_vsb.set)
        r_vsb.config(command=self._body_txt.yview)
        self._body_txt.pack(fill='both', expand=True)

    def _on_unit_select(self, _=None):
        sel = self._unit_tv.selection()
        if not sel:
            return
        iid = sel[0]
        if not iid.startswith('U_'):
            return
        try:
            uid = int(iid[2:])
        except ValueError:
            return
        self._current_uid = uid
        row = next((r for r in self._all_units if r[0] == uid), None)
        self._refresh_unit_lang_strip(row[6] if row else None)
        self._refresh_left_body()
        self._load_unit_label_translation_left()
        self._on_variant_change()
        self._load_unit_label_translation()

    @staticmethod
    def _fmt_texts(raw: str | None) -> str:
        if not raw:
            return ''
        parts = []
        for tok in raw.split(','):
            tok = tok.strip()
            if ':' not in tok:
                continue
            variant, lang = tok.split(':', 1)
            abbr = _VARIANT_ABBR.get(variant, variant[:1])
            parts.append(f'{abbr}:{lang}')
        return '  '.join(parts)

    def _refresh_unit_lang_strip(self, texts_raw: str | None):
        if not hasattr(self, '_unit_lang_strip'):
            return
        for w in self._unit_lang_strip.winfo_children():
            w.destroy()
        if not texts_raw:
            return
        chips: list[tuple[str, str]] = []
        for tok in texts_raw.split(','):
            tok = tok.strip()
            if ':' not in tok:
                continue
            variant, lang = tok.split(':', 1)
            label = f"{_VARIANT_KO.get(variant, variant)}·{lang}"
            chips.append((label, lang))
        _render_chips(self._unit_lang_strip, chips)

    def _load_units(self, book_id: int):
        try:
            conn = _db()
            rows = conn.execute(
                "SELECT u.unit_id, u.sequence, u.session_type, u.unit_label, "
                "       u.key_verse_ref, u.start_vid, "
                "       GROUP_CONCAT(DISTINCT t.text_variant || ':' || UPPER(t.lang_code)) "
                "FROM sys_book_unit u "
                "LEFT JOIN sys_book_unit_text t "
                "       ON t.unit_id = u.unit_id AND t.record_status='LIVE' "
                "WHERE u.book_id=? AND u.record_status='LIVE' "
                "GROUP BY u.unit_id "
                "ORDER BY u.sequence",
                (book_id,)
            ).fetchall()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return

        self._all_units = rows
        self._current_uid = None
        if hasattr(self, '_filter_var'):
            self._filter_var.set('')
        self._apply_unit_filter()
        if hasattr(self, '_unit_lang_strip'):
            for w in self._unit_lang_strip.winfo_children():
                w.destroy()
        # 본문 패널 초기화
        for attr, cfg in [
            ('_left_body_meta_lbl', {'text': ''}),
            ('_left_body_save_lbl', {'text': ''}),
            ('_left_label_save_lbl', {'text': ''}),
            ('_body_meta_lbl',    {'text': '(유닛을 선택하면 본문이 표시됩니다)',
                                   'foreground': 'gray'}),
            ('_body_save_lbl',    {'text': ''}),
            ('_unit_label_save_lbl', {'text': ''}),
        ]:
            if hasattr(self, attr):
                getattr(self, attr).config(**cfg)
        for attr in ('_left_body_txt', '_body_txt'):
            if hasattr(self, attr):
                w = getattr(self, attr)
                # ⚠ 왼쪽은 읽기 전용(`disabled`)이라 **그대로 지우면 조용히
                #   아무 일도 안 한다.** 잠깐 열고 다시 잠근다.
                st = str(w.cget('state'))
                w.config(state='normal')
                w.delete('1.0', 'end')
                w.config(state=st)
        if hasattr(self, '_left_unit_trans_var'):
            self._left_unit_trans_var.set('')
        if hasattr(self, '_unit_trans_var'):
            self._unit_trans_var.set('')

    def _apply_unit_filter(self):
        self._unit_tv.delete(*self._unit_tv.get_children())
        keyword = getattr(self, '_filter_var', tk.StringVar()).get().strip().lower()
        rows = getattr(self, '_all_units', [])
        shown = 0
        for uid, seq, stype, label, vref, vid, texts_raw in rows:
            if keyword and keyword not in (label or '').lower():
                continue
            self._unit_tv.insert('', 'end', iid=f'U_{uid}',
                                  values=(seq, stype or '', label or '',
                                          vref or '',
                                          self._fmt_texts(texts_raw)))
            shown += 1
        total = len(rows)
        if keyword:
            self._t2_count_lbl.config(text=f'{shown}/{total}개 표시')
        else:
            self._t2_count_lbl.config(text=f'총 {total}개 유닛')

    def _get_book_lang(self) -> str:
        if not self._book_id:
            return 'EN'
        try:
            conn = _db()
            r = conn.execute(
                "SELECT lang_code FROM sys_book_asset WHERE book_id=?",
                (self._book_id,)
            ).fetchone()
            conn.close()
            return (r[0] or 'EN').upper() if r else 'EN'
        except Exception:
            return 'EN'

    def _refresh_left_body(self):
        uid = self._current_uid
        if not uid or not hasattr(self, '_left_body_txt'):
            return
        variant = self._left_variant_var.get()
        lang    = _name_to_code(self._left_lang_var.get())
        try:
            conn = _db()
            row = conn.execute(
                "SELECT text_id, body_text FROM sys_book_unit_text "
                "WHERE unit_id=? AND text_variant=? AND lang_code=? "
                "  AND record_status='LIVE'",
                (uid, variant, lang)
            ).fetchone()
            conn.close()
        except Exception:
            row = None
        # ⚠ 왼쪽은 **읽기 전용**이라 채우는 동안만 잠깐 연다 — 안 그러면
        #   `delete`/`insert` 가 조용히 아무 일도 안 한다(`disabled` Text).
        self._left_body_txt.config(state='normal')
        self._left_body_txt.delete('1.0', 'end')
        if row and row[1]:
            self._left_body_meta_lbl.config(
                text=f'uid={uid}  {variant}/{lang}  tid={row[0]}',
                foreground='#555')
            self._left_body_txt.insert('1.0', row[1])
        else:
            self._left_body_meta_lbl.config(
                text=f'uid={uid}  {variant}/{lang}  (없음)',
                foreground='gray')
        self._left_body_txt.config(state='disabled')      # 다시 잠근다
        if hasattr(self, '_left_body_save_lbl'):
            self._left_body_save_lbl.config(text='')

    def _on_left_variant_change(self):
        variant = self._left_variant_var.get()
        if variant == 'ORIGINAL':
            self._left_lang_var.set(_code_to_name(self._get_book_lang()))
        elif variant == 'MODERN_EN':
            self._left_lang_var.set(_code_to_name('EN'))
        self._refresh_left_body()
        self._load_unit_label_translation_left()

    def _load_unit_label_translation_left(self):
        uid = self._current_uid
        if not uid or not hasattr(self, '_left_unit_trans_var'):
            return
        lang = _name_to_code(self._left_lang_var.get())
        try:
            conn = _db()
            r = conn.execute(
                "SELECT contents FROM sys_text_asset "
                "WHERE text_type='BOOK_UNIT_LABEL' AND clicked_id=? "
                "  AND lang_code=? AND record_status='LIVE' LIMIT 1",
                (uid, lang)
            ).fetchone()
            conn.close()
        except Exception:
            r = None
        self._left_unit_trans_var.set(r[0] if r else '')
        if hasattr(self, '_left_label_save_lbl'):
            self._left_label_save_lbl.config(text='')

    def _save_body_text_left(self):
        uid = self._current_uid
        if not uid:
            messagebox.showwarning('선택 필요', '유닛을 먼저 선택하세요.')
            return
        variant = self._left_variant_var.get()
        # ⚠ 원문은 남의 글이라 고치거나 지울 수 없다 (lang_compare 단일 규칙)
        if lang_compare.guard(variant, self, 'save'):
            return
        lang    = _name_to_code(self._left_lang_var.get())
        body    = self._left_body_txt.get('1.0', 'end-1c').strip()
        label   = self._left_unit_trans_var.get().strip()
        if not body and not label:
            messagebox.showwarning('내용 없음', '제목 또는 본문 내용을 입력하세요.')
            return
        try:
            conn = _db()
            if body:
                ex = conn.execute(
                    "SELECT text_id FROM sys_book_unit_text "
                    "WHERE unit_id=? AND text_variant=? AND lang_code=? "
                    "  AND record_status='LIVE'",
                    (uid, variant, lang)
                ).fetchone()
                if ex:
                    conn.execute(
                        "UPDATE sys_book_unit_text SET body_text=? "
                        "WHERE text_id=?",
                        (body, ex[0]))
                else:
                    conn.execute(
                        "INSERT INTO sys_book_unit_text "
                        "(unit_id, text_variant, lang_code, body_text, record_status) "
                        "VALUES (?,?,?,?,'LIVE')",
                        (uid, variant, lang, body))
            if label:
                ex_lbl = conn.execute(
                    "SELECT sys_text_id FROM sys_text_asset "
                    "WHERE text_type='BOOK_UNIT_LABEL' AND clicked_id=? "
                    "  AND lang_code=? AND record_status='LIVE'",
                    (uid, lang)
                ).fetchone()
                if ex_lbl:
                    conn.execute(
                        "UPDATE sys_text_asset SET contents=? "
                        "WHERE sys_text_id=?",
                        (label, ex_lbl[0]))
                else:
                    conn.execute(
                        "INSERT INTO sys_text_asset "
                        "(clicked_id, text_type, title, contents, "
                        " lang_code, record_status) "
                        "VALUES (?,?,?,?,?,'LIVE')",
                        (uid, 'BOOK_UNIT_LABEL', f'UL_{uid}', label, lang))
            conn.commit()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return
        self._left_body_save_lbl.config(text='저장됨', foreground='#27AE60')
        self._left_label_save_lbl.config(text='')
        self.after(2000, lambda: self._left_body_save_lbl.config(text=''))
        self._refresh_left_body()

    def _hide_body_text_left(self):
        uid = self._current_uid
        if not uid:
            return
        variant = self._left_variant_var.get()
        # ⚠ 원문은 남의 글이라 고치거나 지울 수 없다 (lang_compare 단일 규칙)
        if lang_compare.guard(variant, self, 'delete'):
            return
        lang    = _name_to_code(self._left_lang_var.get())
        if not messagebox.askyesno(
            '삭제 확인',
            f'unit_id={uid}  {variant}/{lang} 본문을 HIDE 처리하시겠습니까?'
        ):
            return
        try:
            conn = _db()
            conn.execute(
                "UPDATE sys_book_unit_text SET record_status='HIDE' "
                "WHERE unit_id=? AND text_variant=? AND lang_code=?",
                (uid, variant, lang))
            conn.commit()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return
        self._refresh_left_body()

    def _on_variant_change(self):
        variant = self._body_variant_var.get()
        if variant == 'ORIGINAL':
            self._body_lang_var.set(_code_to_name(self._get_book_lang()))
        elif variant == 'MODERN_EN':
            self._body_lang_var.set(_code_to_name('EN'))
        self._refresh_body_text()
        self._load_unit_label_translation()

    def _refresh_body_text(self):
        uid = self._current_uid
        if not uid:
            return
        variant = self._body_variant_var.get()
        lang    = _name_to_code(self._body_lang_var.get())
        try:
            conn = _db()
            row = conn.execute(
                "SELECT text_id, body_text FROM sys_book_unit_text "
                "WHERE unit_id=? AND text_variant=? AND lang_code=? "
                "  AND record_status='LIVE'",
                (uid, variant, lang)
            ).fetchone()
            conn.close()
        except Exception:
            row = None
        self._body_txt.delete('1.0', 'end')
        if row and row[1]:
            self._body_meta_lbl.config(
                text=f'unit_id={uid}  |  {variant}  |  {lang}  |  text_id={row[0]}',
                foreground='#555')
            self._body_txt.insert('1.0', row[1])
        else:
            self._body_meta_lbl.config(
                text=f'unit_id={uid}  |  {variant}  |  {lang}  |  (없음)',
                foreground='gray')
        if hasattr(self, '_body_save_lbl'):
            self._body_save_lbl.config(text='')

    def _load_unit_label_translation(self):
        uid = self._current_uid
        if not uid or not hasattr(self, '_unit_trans_var'):
            return
        lang = _name_to_code(self._body_lang_var.get())
        try:
            conn = _db()
            r = conn.execute(
                "SELECT contents FROM sys_text_asset "
                "WHERE text_type='BOOK_UNIT_LABEL' AND clicked_id=? "
                "  AND lang_code=? AND record_status='LIVE' LIMIT 1",
                (uid, lang)
            ).fetchone()
            conn.close()
        except Exception:
            r = None
        self._unit_trans_var.set(r[0] if r else '')
        self._unit_label_save_lbl.config(text='')

    def _save_body_text(self):
        uid = self._current_uid
        if not uid:
            messagebox.showwarning('선택 필요', '유닛을 먼저 선택하세요.')
            return
        variant = self._body_variant_var.get()
        # ⚠ 원문은 남의 글이라 고치거나 지울 수 없다 (lang_compare 단일 규칙)
        if lang_compare.guard(variant, self, 'save'):
            return
        lang    = _name_to_code(self._body_lang_var.get())
        body    = self._body_txt.get('1.0', 'end-1c').strip()
        label   = self._unit_trans_var.get().strip()
        if not body and not label:
            messagebox.showwarning('내용 없음', '제목 또는 본문 내용을 입력하세요.')
            return
        try:
            conn = _db()
            if body:
                ex = conn.execute(
                    "SELECT text_id FROM sys_book_unit_text "
                    "WHERE unit_id=? AND text_variant=? AND lang_code=? "
                    "  AND record_status='LIVE'",
                    (uid, variant, lang)
                ).fetchone()
                if ex:
                    conn.execute(
                        "UPDATE sys_book_unit_text SET body_text=? "
                        "WHERE text_id=?",
                        (body, ex[0]))
                else:
                    conn.execute(
                        "INSERT INTO sys_book_unit_text "
                        "(unit_id, text_variant, lang_code, body_text, record_status) "
                        "VALUES (?,?,?,?,'LIVE')",
                        (uid, variant, lang, body))
            if label:
                ex_lbl = conn.execute(
                    "SELECT sys_text_id FROM sys_text_asset "
                    "WHERE text_type='BOOK_UNIT_LABEL' AND clicked_id=? "
                    "  AND lang_code=? AND record_status='LIVE'",
                    (uid, lang)
                ).fetchone()
                if ex_lbl:
                    conn.execute(
                        "UPDATE sys_text_asset SET contents=? "
                        "WHERE sys_text_id=?",
                        (label, ex_lbl[0]))
                else:
                    conn.execute(
                        "INSERT INTO sys_text_asset "
                        "(clicked_id, text_type, title, contents, "
                        " lang_code, record_status) "
                        "VALUES (?,?,?,?,?,'LIVE')",
                        (uid, 'BOOK_UNIT_LABEL', f'UL_{uid}', label, lang))
            conn.commit()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return
        self._body_save_lbl.config(text='저장됨', foreground='#27AE60')
        self._unit_label_save_lbl.config(text='')
        self.after(2000, lambda: self._body_save_lbl.config(text=''))
        self._refresh_body_text()

    def _hide_body_text(self):
        uid = self._current_uid
        if not uid:
            return
        variant = self._body_variant_var.get()
        # ⚠ 원문은 남의 글이라 고치거나 지울 수 없다 (lang_compare 단일 규칙)
        if lang_compare.guard(variant, self, 'delete'):
            return
        lang    = _name_to_code(self._body_lang_var.get())
        if not messagebox.askyesno(
            '삭제 확인',
            f'unit_id={uid}  {variant}/{lang} 본문을 HIDE 처리하시겠습니까?'
        ):
            return
        try:
            conn = _db()
            conn.execute(
                "UPDATE sys_book_unit_text SET record_status='HIDE' "
                "WHERE unit_id=? AND text_variant=? AND lang_code=?",
                (uid, variant, lang))
            conn.commit()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return
        self._refresh_body_text()

    def _add_unit(self):
        if not self._book_id:
            messagebox.showwarning('선택 필요', '먼저 도서를 선택하세요.')
            return

        try:
            conn = _db()
            max_seq = conn.execute(
                "SELECT COALESCE(MAX(sequence), 0) FROM sys_book_unit "
                "WHERE book_id=? AND record_status='LIVE'",
                (self._book_id,)
            ).fetchone()[0]
            cat_row = conn.execute(
                "SELECT book_category FROM sys_book_asset WHERE book_id=?",
                (self._book_id,)
            ).fetchone()
            conn.close()
        except Exception:
            max_seq = 0
            cat_row = None

        default_type = 'SERMON' if (cat_row and cat_row[0] == 'SERMON') else 'CHAPTER'

        dlg = _UnitDialog(self, next_seq=max_seq + 1, default_type=default_type)
        self.wait_window(dlg)
        if not dlg.result:
            return

        seq, stype, label, vref, start_vid, end_vid, body_text = dlg.result
        book_lang = self._get_book_lang()
        try:
            conn = _db()
            conn.execute(
                "INSERT INTO sys_book_unit "
                "(book_id, sequence, session_type, unit_label, "
                " key_verse_ref, start_vid, end_vid, record_status) "
                "VALUES (?,?,?,?,?,?,?,'LIVE')",
                (self._book_id, seq, stype, label, vref or None,
                 start_vid or None, end_vid or None))
            uid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
            if body_text:
                conn.execute(
                    "INSERT INTO sys_book_unit_text "
                    "(unit_id, text_variant, lang_code, body_text, record_status) "
                    "VALUES (?, 'ORIGINAL', ?, ?, 'LIVE')",
                    (uid, book_lang, body_text))
            conn.commit()
            conn.close()
            self._load_units(self._book_id)
        except Exception as e:
            messagebox.showerror('오류', str(e))

    def _edit_unit(self):
        sel = self._unit_tv.selection()
        if not sel:
            messagebox.showwarning('선택 필요', '편집할 유닛을 선택하세요.')
            return
        iid = sel[0]
        try:
            uid = int(iid[2:])
        except ValueError:
            return

        row = next((r for r in self._all_units if r[0] == uid), None)
        if not row:
            return
        # ⚠ `_load_units` 가 **7칸**을 뽑는다(마지막은 번역 현황 `GROUP_CONCAT`).
        #   6개로 풀고 있어서 **「수정」을 누를 때마다 `ValueError` 로 터졌다** —
        #   tkinter 콜백이라 콘솔에만 찍히고 다이얼로그가 아예 안 떴다(2026-08-15 실측).
        #   칸을 늘리면서 이 한 곳만 놓친 것이다. **자리로 풀지 말고 앞에서 잘라 쓴다.**
        uid, seq, stype, label, vref, vid = row[:6]

        # 기존 본문 및 start_vid/end_vid 조회
        try:
            conn = _db()
            txt_row = conn.execute(
                "SELECT text_id, text_variant, lang_code, body_text "
                "FROM sys_book_unit_text "
                "WHERE unit_id=? AND text_variant='ORIGINAL' "
                "AND record_status='LIVE' LIMIT 1",
                (uid,)
            ).fetchone()
            vid_row = conn.execute(
                "SELECT start_vid, end_vid FROM sys_book_unit WHERE unit_id=?",
                (uid,)
            ).fetchone()
            conn.close()
        except Exception:
            txt_row = None
            vid_row = None

        existing_body  = txt_row[3] if txt_row else ''
        existing_tid   = txt_row[0] if txt_row else None
        prefill_svid   = str(vid_row[0]) if vid_row and vid_row[0] else ''
        prefill_evid   = str(vid_row[1]) if vid_row and vid_row[1] else ''

        dlg = _UnitDialog(self, next_seq=seq, default_type=stype or 'CHAPTER',
                           prefill_label=label or '', prefill_vref=vref or '',
                           prefill_vid=prefill_svid, prefill_evid=prefill_evid,
                           prefill_body=existing_body or '',
                           edit_mode=True)
        self.wait_window(dlg)
        if not dlg.result:
            return

        new_seq, new_stype, new_label, new_vref, new_svid, new_evid, new_body = dlg.result
        book_lang = self._get_book_lang()
        try:
            conn = _db()
            conn.execute(
                "UPDATE sys_book_unit SET "
                "sequence=?, session_type=?, unit_label=?, key_verse_ref=?, "
                "start_vid=?, end_vid=? "
                "WHERE unit_id=?",
                (new_seq, new_stype, new_label, new_vref or None,
                 new_svid or None, new_evid or None, uid))
            if new_body:
                if existing_tid:
                    conn.execute(
                        "UPDATE sys_book_unit_text SET body_text=? WHERE text_id=?",
                        (new_body, existing_tid))
                else:
                    conn.execute(
                        "INSERT INTO sys_book_unit_text "
                        "(unit_id, text_variant, lang_code, body_text, record_status) "
                        "VALUES (?, 'ORIGINAL', ?, ?, 'LIVE')",
                        (uid, book_lang, new_body))
            elif existing_tid and not new_body:
                # 본문을 지웠으면 HIDE 처리
                conn.execute(
                    "UPDATE sys_book_unit_text SET record_status='HIDE' WHERE text_id=?",
                    (existing_tid,))
            conn.commit()
            conn.close()
            self._load_units(self._book_id)
        except Exception as e:
            messagebox.showerror('오류', str(e))

    def _delete_unit(self):
        sel = self._unit_tv.selection()
        if not sel:
            return
        iid = sel[0]
        uid = int(iid[2:])
        if not messagebox.askyesno('삭제 확인', f'unit_id={uid} 유닛을 삭제하시겠습니까?'):
            return
        try:
            conn = _db()
            conn.execute(
                "UPDATE sys_book_unit SET record_status='HIDE' WHERE unit_id=?",
                (uid,))
            conn.commit()
            conn.close()
            self._load_units(self._book_id)
        except Exception as e:
            messagebox.showerror('오류', str(e))

    # ── 교리/자료 (sys_ref_*) ────────────────────────────────────────────────

    def _build_ref_source_tree_left(self, f):
        vsb = ttk.Scrollbar(f, orient='vertical')
        vsb.pack(side='right', fill='y', pady=(2, 0))
        self._ref_tv = ttk.Treeview(f, show='tree', selectmode='browse',
                                    style='BM.Treeview', yscrollcommand=vsb.set)
        vsb.config(command=self._ref_tv.yview)
        self._ref_tv.pack(fill='both', expand=True, padx=(4, 0), pady=2)
        self._ref_tv.tag_configure('cat',  foreground='#1A252F',
                                   font=('Malgun Gothic', 9, 'bold'))
        self._ref_tv.tag_configure('live', foreground='#2C3E50')
        self._ref_tv.tag_configure('hide', foreground='#AAAAAA')
        self._ref_tv.bind('<<TreeviewSelect>>', self._on_ref_tree_select)

    def _load_ref_source_list(self, reselect_id: int | None = None):
        if not hasattr(self, '_ref_tv'):
            return
        self._ref_tv.delete(*self._ref_tv.get_children())
        try:
            conn = _db()
            rows = conn.execute(
                # ⚠ **사전(DICTIONARY)과 연구자료(STUDY)는 뺀다** (2026-08-15).
                #   각각 「사전 관리자」·「연구자료」가 그 집이고, 두 곳에서 고치면
                #   어느 것이 진짜인지 알 수 없다.
                #   남는 것 = 문답 3 · 인물연구 1 · 역사 3 · 주제색인 1.
                #   갈래가 넷이어도 **전부 수입해서 번역한 자료집**이라 한 메뉴에 둔다.
                "SELECT ref_src_id, src_code, src_type, title, record_status "
                "FROM sys_ref_source WHERE src_type NOT IN ('DICTIONARY','STUDY') "
                "ORDER BY src_type, title"
            ).fetchall()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return

        by_type: dict[str, list] = {}
        for sid, code, stype, title, status in rows:
            by_type.setdefault(stype, []).append((sid, code, title, status))

        for stype, items in sorted(by_type.items()):
            label = _REF_SRC_TYPE_LABELS.get(stype, stype)
            cat_iid = f'RT_{stype}'
            self._ref_tv.insert('', 'end', iid=cat_iid,
                                text=f'{label}  ({len(items)})',
                                tags=('cat',), open=True)
            for sid, code, title, status in items:
                tag = 'live' if status == 'LIVE' else 'hide'
                self._ref_tv.insert(cat_iid, 'end', iid=f'RS_{sid}',
                                    text=f'  {title or code}', tags=(tag,))

        if reselect_id:
            iid = f'RS_{reselect_id}'
            if self._ref_tv.exists(iid):
                self._ref_tv.selection_set(iid)
                self._ref_tv.see(iid)

    def _on_ref_tree_select(self, _=None):
        sel = self._ref_tv.selection()
        if not sel:
            return
        iid = sel[0]
        if not iid.startswith('RS_'):
            return
        try:
            src_id = int(iid[3:])
        except ValueError:
            return
        self._show_doc_panel()
        self._load_ref_source(src_id)

    def _load_ref_source(self, src_id: int):
        self._ref_src_id = src_id
        try:
            conn = _db()
            row = conn.execute(
                "SELECT src_code, src_type, mapping_type, title, author, "
                "       pub_year, lang_code, record_status, description "
                "FROM sys_ref_source WHERE ref_src_id=?", (src_id,)
            ).fetchone()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return
        if not row:
            return
        code, stype, mtype, title, author, year, lang, status, desc = row
        self._doc_t1_vars['src_code'].set(code or '')
        self._doc_t1_vars['src_type'].set(
            f"{stype}  ({_REF_SRC_TYPE_LABELS.get(stype, stype)})")
        self._doc_t1_vars['mapping_type'].set(mtype or '')
        self._doc_t1_vars['title'].set(title or '')
        self._doc_t1_vars['author'].set(author or '')
        self._doc_t1_vars['pub_year'].set(str(year or ''))
        self._doc_lang_var.set(_code_to_name(lang or 'EN'))
        if hasattr(self, '_doc_t1_desc'):
            self._doc_t1_desc.delete('1.0', 'end')
            if desc:
                self._doc_t1_desc.insert('1.0', desc)
        live = (status == 'LIVE')
        self._doc_btn_status.config(
            text='숨기기' if live else '되살리기')
        self._doc_t1_status_lbl.config(
            text=('현재: 보임' if live else '현재: 숨김'),
            foreground='#27AE60' if live else '#AAA')
        if self._doc_nb.index('current') == 1:
            self._load_ref_units(src_id)
        self._load_doc_src_translations()

    def _save_doc_source(self):
        if not self._ref_src_id:
            messagebox.showwarning('선택 필요', '소스를 먼저 선택하세요.')
            return
        title  = self._doc_t1_vars['title'].get().strip()
        author = self._doc_t1_vars['author'].get().strip()
        year_s = self._doc_t1_vars['pub_year'].get().strip()
        lang   = _name_to_code(self._doc_lang_var.get())
        desc   = self._doc_t1_desc.get('1.0', 'end-1c').strip() if hasattr(self, '_doc_t1_desc') else None
        year = None
        if year_s:
            try:
                year = int(year_s)
            except ValueError:
                messagebox.showwarning('입력 오류', '출판연도는 정수로 입력하세요.')
                return
        try:
            conn = _db()
            conn.execute(
                "UPDATE sys_ref_source SET title=?, author=?, pub_year=?, lang_code=?, description=? "
                "WHERE ref_src_id=?",
                (title or None, author or None, year, lang, desc or None, self._ref_src_id))
            conn.commit()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return
        self._doc_t1_status_lbl.config(text='저장 완료', foreground='#27AE60')
        self.after(2000, lambda: self._load_ref_source(self._ref_src_id))
        self._load_ref_source_list(reselect_id=self._ref_src_id)

    def _toggle_doc_source_status(self):
        if not self._ref_src_id:
            return
        try:
            conn = _db()
            cur = conn.execute(
                "SELECT record_status FROM sys_ref_source WHERE ref_src_id=?",
                (self._ref_src_id,)
            ).fetchone()
            if not cur:
                conn.close(); return
            new_st = 'HIDE' if cur[0] == 'LIVE' else 'LIVE'
            conn.execute(
                "UPDATE sys_ref_source SET record_status=? WHERE ref_src_id=?",
                (new_st, self._ref_src_id))
            conn.commit()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e)); return
        self._load_ref_source_list(reselect_id=self._ref_src_id)
        self._load_ref_source(self._ref_src_id)

    def _build_doc_right(self, f):
        self._doc_nb = ttk.Notebook(f)
        self._doc_nb.pack(fill='both', expand=True, padx=2, pady=2)

        # ★ 표준 탭 묶음 — 교리문답은 「문답」이 낱낱이다(자리는 같다).
        #   ⚠ 이름을 「소스 정보」→**「기본정보」**로 통일했다(같은 것을 달리 부를
        #     까닭이 없다 — 표준 3~6번 이름 통일과 같은 이유).
        # ★★ **연결 탭을 붙인다** (2026-08-27 · 서고 체계화). 도서·설교는 있고
        #   교리문답만 없었다 — 그런데 **실제 연결이 3,810건**이다
        #   (`REFU_VERS` 3,513 · `REFU_ENTI` 297). 빈 서랍이 아니다.
        #   ⚠ 낱낱이 `REF_UNIT` 이라 `link_picker` 가 이미 다룰 줄 안다.
        dtabs = panel_std.build(self._doc_nb, {
            'BASIC': None,
            'ITEMS': ('문답 목록', 'BM_TAB_REF_UNITS'),
            'TRANS': None,
            'LINK': None,
        })
        self._build_doc_tab1(dtabs['BASIC'])
        self._build_doc_tab2(dtabs['ITEMS'])
        self._build_doc_trans_tab(dtabs['TRANS'])
        self._build_doc_link_tab(dtabs['LINK'])
        self._doc_nb.bind('<<NotebookTabChanged>>', self._on_doc_tab_change)

    # ── 교리문답 연결 (표준 5번 자리) — 2026-08-27 ────────────────────────
    def _doc_link_owner(self):
        """선택한 문답이 있으면 그것, 없으면 자료집 전체.

        ⚠ `REF_SRC` 는 `link_picker.KINDS` 밖이라 **주인으로만** 쓴다 —
          이름표(`_SYS_ONLY_LABEL`)는 있어서 반대쪽에서 보인다.
        """
        uid = getattr(self, '_current_ref_unit_id', None)
        if uid:
            return ('REF_UNIT', uid)
        if getattr(self, '_ref_src_id', None):
            return ('REF_SRC', self._ref_src_id)
        return None

    def _build_doc_link_tab(self, f):
        # ★ 부품을 쓴다 — 화면마다 만들면 갈라진다(도서 쪽과 **같은 한 줄**)
        self._doc_link_tv = panel_std.link_tab(
            f, self._doc_link_owner, lang_getter=lambda: 'KO', scope='SYS')

    def _refresh_doc_link_tab(self):
        tv = getattr(self, '_doc_link_tv', None)
        if tv is not None:
            try:
                tv.refresh()
            except Exception as e:
                print('[doc link tab] %s' % e)

    # ── 교리문답 번역 현황 ────────────────────────────────────────────────
    def _build_doc_trans_tab(self, f):
        self._doc_trans_tbl = panel_std.translation_tab(
            f,
            columns=[('title', '제목', 90), ('body', '본문', 90)],
            provider=self._doc_trans_counts,
            hint='자료집 하나의 언어별 보유입니다.')

    def _doc_trans_counts(self, lang):
        """⚠⚠ **문답 자료집은 원문이 `sys_ref_text` 에 없다** — `unit_question`·
        `unit_answer` 칸에 있고 `sys_ref_text` 는 **번역 층**이다(실측:
        하이델베르크 129문답이 `ref_text` **0행**).
        그대로 세면 원문 언어가 **0/129** 로 나와 「빠뜨렸다」로 읽힌다.
        ⇒ **그 자료집의 원문 언어에서는 `unit_answer` 를 본문으로 센다.**
        ⚠ 사전·주제색인은 반대로 `sys_ref_text` 에 원문이 있다 — 자료집이
          스스로 밝힌 `lang_code` 로 가른다(유형을 손으로 나열하지 않는다).
        """
        sid = getattr(self, '_ref_src_id', None)
        if not sid:
            return {}
        lang = (lang or '').upper()
        try:
            with appdb.connect() as c:
                r = c.execute("SELECT UPPER(COALESCE(lang_code,'EN')) "
                              "  FROM sys_ref_source WHERE ref_src_id=?",
                              (sid,)).fetchone()
                src_lang = r[0] if r else 'EN'
                units = c.execute(
                    "SELECT COUNT(*) FROM sys_ref_unit "
                    " WHERE ref_src_id=? AND COALESCE(record_status,'LIVE')='LIVE'",
                    (sid,)).fetchone()[0]
                ti, bo = c.execute(
                    "SELECT SUM(COALESCE(t.title,'')<>''), "
                    "       SUM(COALESCE(t.body_text,'')<>'') "
                    "  FROM sys_ref_text t JOIN sys_ref_unit u "
                    "    ON u.ref_unit_id=t.ref_unit_id "
                    " WHERE u.ref_src_id=? AND UPPER(t.lang_code)=?",
                    (sid, lang)).fetchone()
                ti, bo = (ti or 0), (bo or 0)
                if lang == src_lang:
                    # 원문 언어 — 칸에 든 것도 함께 센다(둘 중 있는 쪽)
                    q, a = c.execute(
                        "SELECT SUM(COALESCE(unit_question,'')<>''), "
                        "       SUM(COALESCE(unit_answer,'')<>'') "
                        "  FROM sys_ref_unit WHERE ref_src_id=? "
                        "   AND COALESCE(record_status,'LIVE')='LIVE'",
                        (sid,)).fetchone()
                    ti = max(ti, q or 0)
                    bo = max(bo, a or 0)
        except Exception as e:
            print('[doc trans] %s' % e)
            return {}
        return {'title': (ti, units), 'body': (bo, units)}

    def _on_doc_tab_change(self, _=None):
        # ⚠ **번호를 세지 말고 이름으로 가른다** — 탭이 늘면 번호가 밀린다
        #   (연결 탭을 3번에 더하면서 실제로 밀렸다).
        if self._doc_nb.index('current') == 3:
            self._refresh_doc_link_tab()
            return
        if self._doc_nb.index('current') == 2:
            t = getattr(self, '_doc_trans_tbl', None)
            if t is not None:
                try: t.refresh()
                except Exception as e: print('[doc trans refresh] %s' % e)
            return
        if self._doc_nb.index('current') == 1 and self._ref_src_id:
            self._load_ref_units(self._ref_src_id)

    def _build_doc_tab1(self, f):
        self._doc_t1_vars: dict[str, tk.Variable] = {}
        outer = ttk.Frame(f)
        outer.pack(fill='both', expand=True, padx=10, pady=8)

        def field(label, key, ro=False, width=38):
            fr = ttk.Frame(outer)
            fr.pack(fill='x', pady=2, padx=4)
            ttk.Label(fr, text=label, width=16, anchor='e').pack(side='left')
            v = tk.StringVar()
            e = ttk.Entry(fr, textvariable=v, width=width)
            if ro:
                e.configure(state='readonly')
            e.pack(side='left', padx=(4, 0))
            self._doc_t1_vars[key] = v

        field('소스코드',          'src_code',     ro=True, width=20)
        field('소스유형',          'src_type',     ro=True, width=32)
        field('매핑유형',          'mapping_type', ro=True, width=16)
        field('제목 (title)',      'title',        width=44)
        field('저자 (author)',     'author',       width=36)
        field('출판연도',          'pub_year',     width=8)

        lang_fr = ttk.Frame(outer)
        lang_fr.pack(fill='x', pady=2, padx=4)
        ttk.Label(lang_fr, text='언어', width=16, anchor='e').pack(side='left')
        self._doc_lang_var = tk.StringVar(value=_code_to_name('EN'))
        ttk.Combobox(lang_fr, textvariable=self._doc_lang_var,
                     values=_LANG_DISPLAY_NAMES, width=11,
                     state='readonly').pack(side='left', padx=(4, 0))

        desc_row = ttk.Frame(outer)
        desc_row.pack(fill='x', pady=(4, 2), padx=4)
        ttk.Label(desc_row, text='소개 (desc)', width=16, anchor='ne').pack(
            side='left', anchor='n')
        desc_wrap = ttk.Frame(desc_row)
        desc_wrap.pack(side='left', fill='x', expand=True, padx=(4, 0))
        desc_vsb = ttk.Scrollbar(desc_wrap, orient='vertical')
        desc_vsb.pack(side='right', fill='y')
        self._doc_t1_desc = tk.Text(desc_wrap, height=3, width=50, wrap='word',
                                     font=('Malgun Gothic', 9),
                                     yscrollcommand=desc_vsb.set)
        desc_vsb.config(command=self._doc_t1_desc.yview)
        self._doc_t1_desc.pack(fill='x', expand=True)

        btn_f = ttk.Frame(outer)
        btn_f.pack(fill='x', pady=(6, 4))
        ttk.Button(btn_f, text='저장', command=self._save_doc_source,
                   width=10).pack(side='left')
        self._doc_btn_status = ttk.Button(
            btn_f, text='숨기기', command=self._toggle_doc_source_status,
            width=14)
        self._doc_btn_status.pack(side='left', padx=(8, 0))
        self._doc_t1_status_lbl = ttk.Label(btn_f, text='', foreground='gray',
                                             font=('', 8))
        self._doc_t1_status_lbl.pack(side='left', padx=(12, 0))

        ttk.Separator(outer, orient='horizontal').pack(fill='x', pady=(4, 6))

        tr_hdr = ttk.Frame(outer)
        tr_hdr.pack(fill='x', pady=(0, 2))
        ttk.Label(tr_hdr, text='번역 텍스트', font=('', 8, 'bold')).pack(side='left')
        self._doc_src_tr_count_lbl = ttk.Label(tr_hdr, text='', foreground='gray',
                                                font=('', 8))
        self._doc_src_tr_count_lbl.pack(side='left', padx=(8, 0))

        tr_pw = ttk.PanedWindow(outer, orient='horizontal')
        tr_pw.pack(fill='both', expand=True, pady=(0, 4))

        # ── 왼쪽 번역 패널 ────────────────────────────────────────────────────
        src_tr_l_f = ttk.LabelFrame(tr_pw, text=' 수정 (좌) ')
        tr_pw.add(src_tr_l_f, weight=1)

        src_tr_l_ctrl = ttk.Frame(src_tr_l_f)
        src_tr_l_ctrl.pack(fill='x', padx=6, pady=(4, 2))
        ttk.Label(src_tr_l_ctrl, text='언어:').pack(side='left')
        self._doc_src_left_lang_var = tk.StringVar(value=_code_to_name('EN'))
        src_tr_l_lang_cb = ttk.Combobox(
            src_tr_l_ctrl, textvariable=self._doc_src_left_lang_var,
            values=_LANG_DISPLAY_NAMES, width=9, state='readonly')
        _lu.retrofit(src_tr_l_lang_cb)   # 언어 콤보 = 영어 이름(값은 코드 그대로)
        src_tr_l_lang_cb.pack(side='left', padx=(4, 0))
        src_tr_l_lang_cb.bind('<<ComboboxSelected>>',
                               lambda _: self._load_doc_src_side('left'))
        ttk.Button(src_tr_l_ctrl, text='+ 신규',
                   command=lambda: self._add_doc_src_side('left'),
                   width=8).pack(side='left', padx=(8, 0))
        ttk.Button(src_tr_l_ctrl, text='저장',
                   command=lambda: self._save_doc_src_side('left'),
                   width=7).pack(side='left', padx=(6, 0))
        ttk.Button(src_tr_l_ctrl, text='삭제',
                   command=lambda: self._delete_doc_src_side('left'),
                   width=7).pack(side='left', padx=(4, 0))
        self._doc_src_left_status_lbl = ttk.Label(src_tr_l_ctrl, text='',
                                                   foreground='gray', font=('', 8))
        self._doc_src_left_status_lbl.pack(side='left', padx=(6, 0))

        src_tr_l_title_f = ttk.Frame(src_tr_l_f)
        src_tr_l_title_f.pack(fill='x', padx=6, pady=2)
        ttk.Label(src_tr_l_title_f, text='제목', width=7, anchor='e').pack(side='left')
        self._doc_src_left_title_var = tk.StringVar()
        ttk.Entry(src_tr_l_title_f, textvariable=self._doc_src_left_title_var,
                  width=28).pack(side='left', padx=(4, 0))

        src_tr_l_desc_wrap = ttk.Frame(src_tr_l_f)
        src_tr_l_desc_wrap.pack(fill='both', expand=True, padx=6, pady=2)
        src_tr_l_vsb = ttk.Scrollbar(src_tr_l_desc_wrap, orient='vertical')
        src_tr_l_vsb.pack(side='right', fill='y')
        self._doc_src_left_desc_txt = tk.Text(
            src_tr_l_desc_wrap, wrap='word', font=('Malgun Gothic', 9),
            yscrollcommand=src_tr_l_vsb.set)
        src_tr_l_vsb.config(command=self._doc_src_left_desc_txt.yview)
        self._doc_src_left_desc_txt.pack(fill='both', expand=True)

        # ── 오른쪽 번역 패널 ──────────────────────────────────────────────────
        src_tr_r_f = ttk.LabelFrame(tr_pw, text=' 수정 (우) ')
        tr_pw.add(src_tr_r_f, weight=1)

        src_tr_r_ctrl = ttk.Frame(src_tr_r_f)
        src_tr_r_ctrl.pack(fill='x', padx=6, pady=(4, 2))
        ttk.Label(src_tr_r_ctrl, text='언어:').pack(side='left')
        self._doc_src_right_lang_var = tk.StringVar(value=_code_to_name('KO'))
        src_tr_r_lang_cb = ttk.Combobox(
            src_tr_r_ctrl, textvariable=self._doc_src_right_lang_var,
            values=_LANG_DISPLAY_NAMES, width=9, state='readonly')
        _lu.retrofit(src_tr_r_lang_cb)   # 언어 콤보 = 영어 이름(값은 코드 그대로)
        src_tr_r_lang_cb.pack(side='left', padx=(4, 0))
        src_tr_r_lang_cb.bind('<<ComboboxSelected>>',
                               lambda _: self._load_doc_src_side('right'))
        ttk.Button(src_tr_r_ctrl, text='+ 신규',
                   command=lambda: self._add_doc_src_side('right'),
                   width=8).pack(side='left', padx=(8, 0))
        ttk.Button(src_tr_r_ctrl, text='저장',
                   command=lambda: self._save_doc_src_side('right'),
                   width=7).pack(side='left', padx=(6, 0))
        ttk.Button(src_tr_r_ctrl, text='삭제',
                   command=lambda: self._delete_doc_src_side('right'),
                   width=7).pack(side='left', padx=(4, 0))
        self._doc_src_right_status_lbl = ttk.Label(src_tr_r_ctrl, text='',
                                                    foreground='gray', font=('', 8))
        self._doc_src_right_status_lbl.pack(side='left', padx=(6, 0))

        src_tr_r_title_f = ttk.Frame(src_tr_r_f)
        src_tr_r_title_f.pack(fill='x', padx=6, pady=2)
        ttk.Label(src_tr_r_title_f, text='제목', width=7, anchor='e').pack(side='left')
        self._doc_src_right_title_var = tk.StringVar()
        ttk.Entry(src_tr_r_title_f, textvariable=self._doc_src_right_title_var,
                  width=28).pack(side='left', padx=(4, 0))

        src_tr_r_desc_wrap = ttk.Frame(src_tr_r_f)
        src_tr_r_desc_wrap.pack(fill='both', expand=True, padx=6, pady=2)
        src_tr_r_vsb = ttk.Scrollbar(src_tr_r_desc_wrap, orient='vertical')
        src_tr_r_vsb.pack(side='right', fill='y')
        self._doc_src_right_desc_txt = tk.Text(
            src_tr_r_desc_wrap, wrap='word', font=('Malgun Gothic', 9),
            yscrollcommand=src_tr_r_vsb.set)
        src_tr_r_vsb.config(command=self._doc_src_right_desc_txt.yview)
        self._doc_src_right_desc_txt.pack(fill='both', expand=True)

    def _load_doc_src_translations(self):
        if not self._ref_src_id or not hasattr(self, '_doc_src_tr_count_lbl'):
            return
        try:
            conn = _db()
            rows = conn.execute(
                "SELECT DISTINCT lang_code FROM sys_text_asset "
                "WHERE text_type='REF_SRC_DESC' AND clicked_id=? "
                "  AND record_status='LIVE'",
                (self._ref_src_id,)
            ).fetchall()
            conn.close()
        except Exception:
            rows = []
        langs = [r[0] for r in rows]
        self._doc_src_tr_count_lbl.config(text=f'{len(langs)}개 번역')
        if not self._doc_src_left_lang_var.get():
            self._doc_src_left_lang_var.set(_code_to_name('EN'))
        self._load_doc_src_side('left')
        if not self._doc_src_right_lang_var.get():
            self._doc_src_right_lang_var.set(_code_to_name('KO'))
        self._load_doc_src_side('right')

    def _load_doc_src_side(self, side: str):
        if not self._ref_src_id:
            return
        lang = _name_to_code(
            self._doc_src_left_lang_var.get() if side == 'left'
            else self._doc_src_right_lang_var.get())
        try:
            conn = _db()
            row = conn.execute(
                "SELECT sys_text_id, title, contents FROM sys_text_asset "
                "WHERE text_type='REF_SRC_DESC' AND clicked_id=? "
                "  AND lang_code=? AND record_status='LIVE'",
                (self._ref_src_id, lang)
            ).fetchone()
            conn.close()
        except Exception:
            row = None
        if side == 'left':
            self._doc_src_left_tid = row[0] if row else None
            self._doc_src_left_title_var.set(row[1] or '' if row else '')
            self._doc_src_left_desc_txt.delete('1.0', 'end')
            if row and row[2]:
                self._doc_src_left_desc_txt.insert('1.0', row[2])
            self._doc_src_left_status_lbl.config(text='')
        else:
            self._doc_src_right_tid = row[0] if row else None
            self._doc_src_right_title_var.set(row[1] or '' if row else '')
            self._doc_src_right_desc_txt.delete('1.0', 'end')
            if row and row[2]:
                self._doc_src_right_desc_txt.insert('1.0', row[2])
            self._doc_src_right_status_lbl.config(text='')

    def _add_doc_src_side(self, side: str):
        if side == 'left':
            self._doc_src_left_tid = None
            self._doc_src_left_lang_var.set('')
            self._doc_src_left_title_var.set('')
            self._doc_src_left_desc_txt.delete('1.0', 'end')
            self._doc_src_left_status_lbl.config(text='')
        else:
            self._doc_src_right_tid = None
            self._doc_src_right_lang_var.set('')
            self._doc_src_right_title_var.set('')
            self._doc_src_right_desc_txt.delete('1.0', 'end')
            self._doc_src_right_status_lbl.config(text='')

    def _save_doc_src_side(self, side: str):
        if not self._ref_src_id:
            messagebox.showwarning('선택 필요', '소스를 먼저 선택하세요.')
            return
        if side == 'left':
            lang       = _name_to_code(self._doc_src_left_lang_var.get().strip())
            title      = self._doc_src_left_title_var.get().strip()
            desc       = self._doc_src_left_desc_txt.get('1.0', 'end-1c').strip()
            tid        = self._doc_src_left_tid
            status_lbl = self._doc_src_left_status_lbl
        else:
            lang       = _name_to_code(self._doc_src_right_lang_var.get().strip())
            title      = self._doc_src_right_title_var.get().strip()
            desc       = self._doc_src_right_desc_txt.get('1.0', 'end-1c').strip()
            tid        = self._doc_src_right_tid
            status_lbl = self._doc_src_right_status_lbl
        if not lang:
            messagebox.showwarning('입력 오류', '언어코드를 선택하세요.')
            return
        if not title and not desc:
            messagebox.showwarning('입력 오류', '제목 또는 소개를 입력하세요.')
            return
        try:
            conn = _db()
            if tid:
                conn.execute(
                    "UPDATE sys_text_asset SET lang_code=?, title=?, contents=? "
                    "WHERE sys_text_id=?",
                    (lang, title or None, desc or None, tid))
            else:
                conn.execute(
                    "INSERT INTO sys_text_asset "
                    "(clicked_id, text_type, title, contents, lang_code, record_status) "
                    "VALUES (?,?,?,?,?,'LIVE')",
                    (self._ref_src_id, 'REF_SRC_DESC', title or None, desc or None, lang))
                new_tid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
                if side == 'left':
                    self._doc_src_left_tid = new_tid
                else:
                    self._doc_src_right_tid = new_tid
            conn.commit()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return
        status_lbl.config(text='저장됨', foreground='#27AE60')
        self.after(2000, lambda: status_lbl.config(text=''))
        self._load_doc_src_translations()
        if side == 'left':
            self._doc_src_left_lang_var.set(_code_to_name(lang))
        else:
            self._doc_src_right_lang_var.set(_code_to_name(lang))
        self._load_doc_src_side(side)

    def _delete_doc_src_side(self, side: str):
        if side == 'left':
            tid  = self._doc_src_left_tid
            lang = self._doc_src_left_lang_var.get()
        else:
            tid  = self._doc_src_right_tid
            lang = self._doc_src_right_lang_var.get()
        if not tid:
            messagebox.showwarning('선택 필요', '삭제할 번역이 없습니다.')
            return
        if not messagebox.askyesno('삭제 확인', f'{lang} 번역을 삭제하시겠습니까?'):
            return
        try:
            conn = _db()
            conn.execute(
                "UPDATE sys_text_asset SET record_status='HIDE' WHERE sys_text_id=?",
                (tid,))
            conn.commit()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return
        if side == 'left':
            self._doc_src_left_tid = None
            self._doc_src_left_lang_var.set('')
            self._doc_src_left_title_var.set('')
            self._doc_src_left_desc_txt.delete('1.0', 'end')
        else:
            self._doc_src_right_tid = None
            self._doc_src_right_lang_var.set('')
            self._doc_src_right_title_var.set('')
            self._doc_src_right_desc_txt.delete('1.0', 'end')
        self._load_doc_src_translations()

    def _build_doc_tab2(self, f):
        filter_f = ttk.Frame(f)
        filter_f.pack(fill='x', padx=8, pady=(6, 2))
        ttk.Label(filter_f, text='제목 검색:').pack(side='left')
        self._doc_filter_var = tk.StringVar()
        self._doc_filter_var.trace_add('write', lambda *_: self._apply_doc_unit_filter())
        ttk.Entry(filter_f, textvariable=self._doc_filter_var,
                  width=28).pack(side='left', padx=(4, 0))
        ttk.Button(filter_f, text='초기화', width=6,
                   command=lambda: self._doc_filter_var.set('')).pack(
            side='left', padx=(6, 0))
        self._doc_t2_count_lbl = ttk.Label(filter_f, text='', foreground='gray',
                                            font=('', 8))
        self._doc_t2_count_lbl.pack(side='left', padx=(12, 0))

        # ★ **목록 요약 편집** — 오른쪽 끝(단추는 상단 · §0). 고른 문답의
        #   요약(REF_UNIT_SHORT)을 그 자리에서 저장한다. 언어 콤보 + 칸 + 저장.
        ttk.Button(filter_f, text='요약 저장', width=8,
                   command=self._save_doc_short).pack(side='right')
        self._doc_short_var = tk.StringVar()
        ttk.Entry(filter_f, textvariable=self._doc_short_var,
                  width=16).pack(side='right', padx=(4, 4))
        # ⚠ **코드가 아니라 이름**(2026-09-18 2-2) — 이 화면의 다른 콤보와
        #   같은 표(`_LANG_DISPLAY_NAMES`)를 쓴다. 읽을 때 `_name_to_code`.
        #   ★ 목록을 열하나로 넓혔다 — 요약이 지금 KO·EN 둘뿐인 것은
        #     **자료의 상태**이지 이 칸이 둘만 받아야 할 까닭이 아니다.
        self._doc_short_lang = ttk.Combobox(filter_f, state='readonly',
                                            width=14,
                                            values=_LANG_DISPLAY_NAMES)
        _lu.retrofit(self._doc_short_lang)   # 언어 콤보 = 영어 이름(값은 코드 그대로)
        self._doc_short_lang.set(_code_to_name('KO'))
        self._doc_short_lang.bind('<<ComboboxSelected>>',
                                  lambda _e: self._load_doc_short())
        self._doc_short_lang.pack(side='right')
        ttk.Label(filter_f, text='목록 요약').pack(side='right', padx=(0, 4))

        vpw = ttk.PanedWindow(f, orient='vertical')
        vpw.pack(fill='both', expand=True, padx=(8, 4), pady=(0, 4))

        top_f = ttk.Frame(vpw)
        vpw.add(top_f, weight=1)

        cols = ('seq', 'short', 'label', 'section')
        self._doc_unit_tv = ttk.Treeview(
            top_f, columns=cols, show='headings', selectmode='browse', height=8)
        self._doc_unit_tv.heading('seq',     text='순서')
        # ★ 요약이 제목보다 **앞** — 번호 제목(Q.1 …)보다 이것이 내용을 말한다
        self._doc_unit_tv.heading('short',   text='요약')
        self._doc_unit_tv.heading('label',   text='유닛 제목')
        self._doc_unit_tv.heading('section', text='섹션코드')
        self._doc_unit_tv.column('short',   width=130, stretch=False)
        self._doc_unit_tv.column('seq',     width=50,  stretch=False, anchor='center')
        self._doc_unit_tv.column('label',   width=320, stretch=True)
        self._doc_unit_tv.column('section', width=110, stretch=False)
        doc_vsb = ttk.Scrollbar(top_f, orient='vertical',
                                command=self._doc_unit_tv.yview)
        self._doc_unit_tv.configure(yscrollcommand=doc_vsb.set)
        doc_vsb.pack(side='right', fill='y')
        self._doc_unit_tv.pack(fill='both', expand=True)
        self._doc_unit_tv.bind('<<TreeviewSelect>>', self._on_doc_unit_select)

        bot_f = ttk.LabelFrame(vpw, text=' 본문 내용 ')
        vpw.add(bot_f, weight=1)

        body_pw = ttk.PanedWindow(bot_f, orient='horizontal')
        body_pw.pack(fill='both', expand=True, padx=4, pady=4)

        # 왼쪽 편집
        dl_f = ttk.LabelFrame(body_pw, text=' 수정 (좌) ')
        body_pw.add(dl_f, weight=1)

        dl_ctrl = ttk.Frame(dl_f)
        dl_ctrl.pack(fill='x', padx=4, pady=(4, 2))
        self._doc_left_variant_var = tk.StringVar(value='ORIGINAL')
        for _v, _l in [('ORIGINAL', '원문'), ('MODERN_EN', '현대어'),
                       ('TRANSLATED', '번역'), ('SUMMARY', '요약')]:
            ttk.Radiobutton(dl_ctrl, text=_l, variable=self._doc_left_variant_var,
                            value=_v,
                            command=self._on_doc_left_variant_change).pack(
                side='left', padx=(0, 3))
        self._doc_left_lang_var = tk.StringVar(value=_code_to_name('EN'))
        ttk.Combobox(dl_ctrl, textvariable=self._doc_left_lang_var,
                     values=_LANG_DISPLAY_NAMES, width=9,
                     state='readonly').pack(side='left', padx=(4, 0))
        self._doc_left_lang_var.trace_add(
            'write', lambda *_: self._refresh_doc_left_body())
        # ★★ **왼쪽은 기준 자리 — 읽기 전용**(도서 쪽과 같은 규칙, 위 참조).
        #   ⚠ 함수(`_save_doc_body_left`·`_hide_doc_body_left`)는 **안 지운다** —
        #     되돌릴 때 필요하다.
        ttk.Label(dl_ctrl, text='기준 · 읽기 전용',
                  foreground='#7F8C8D').pack(side='left', padx=(8, 0))
        self._doc_left_save_lbl = ttk.Label(dl_ctrl, text='', foreground='gray',
                                             font=('', 8))
        self._doc_left_save_lbl.pack(side='left', padx=(6, 0))
        self._doc_left_meta_lbl = ttk.Label(dl_f, text='', foreground='gray',
                                             font=('Malgun Gothic', 7))
        self._doc_left_meta_lbl.pack(anchor='w', padx=4)
        # 제목(다국어) — `sys_ref_text.title`(2026-08-10). 본문과 같은 행이라
        # 언어를 바꾸면 제목도 함께 바뀐다. 비우면 목록에 unit_label 이 나온다.
        dl_ttl = ttk.Frame(dl_f)
        dl_ttl.pack(fill='x', padx=4, pady=(0, 2))
        ttk.Label(dl_ttl, text='제목', width=4).pack(side='left')
        self._doc_left_title_var = tk.StringVar()
        ttk.Entry(dl_ttl, textvariable=self._doc_left_title_var,
                  state='readonly').pack(side='left', fill='x', expand=True)
        dl_wrap = ttk.Frame(dl_f)
        dl_wrap.pack(fill='both', expand=True, padx=4, pady=(0, 2))
        dl_vsb = ttk.Scrollbar(dl_wrap, orient='vertical')
        dl_vsb.pack(side='right', fill='y')
        self._doc_left_body_txt = tk.Text(
            dl_wrap, wrap='word', font=('Malgun Gothic', 9),
            relief='flat', bg='#FAFAFA', state='disabled',   # 기준 자리
            yscrollcommand=dl_vsb.set)
        dl_vsb.config(command=self._doc_left_body_txt.yview)
        self._doc_left_body_txt.pack(fill='both', expand=True)

        # 오른쪽 편집
        dr_f = ttk.LabelFrame(body_pw, text=' 수정 (우) ')
        body_pw.add(dr_f, weight=1)

        dr_ctrl = ttk.Frame(dr_f)
        dr_ctrl.pack(fill='x', padx=4, pady=(4, 2))
        self._doc_right_variant_var = tk.StringVar(value='ORIGINAL')
        for _v, _l in [('ORIGINAL', '원문'), ('MODERN_EN', '현대어'),
                       ('TRANSLATED', '번역'), ('SUMMARY', '요약')]:
            ttk.Radiobutton(dr_ctrl, text=_l, variable=self._doc_right_variant_var,
                            value=_v,
                            command=self._on_doc_right_variant_change).pack(
                side='left', padx=(0, 3))
        self._doc_right_lang_var = tk.StringVar(value=_code_to_name('KO'))
        ttk.Combobox(dr_ctrl, textvariable=self._doc_right_lang_var,
                     values=_LANG_DISPLAY_NAMES, width=9,
                     state='readonly').pack(side='left', padx=(4, 0))
        self._doc_right_lang_var.trace_add(
            'write', lambda *_: self._refresh_doc_right_body())
        ttk.Button(dr_ctrl, text='저장', command=self._save_doc_body_right,
                   width=6).pack(side='left', padx=(8, 0))
        ttk.Button(dr_ctrl, text='숨기기', command=self._hide_doc_body_right,
                   width=6).pack(side='left', padx=(4, 0))
        self._doc_right_save_lbl = ttk.Label(dr_ctrl, text='', foreground='gray',
                                              font=('', 8))
        self._doc_right_save_lbl.pack(side='left', padx=(6, 0))
        self._doc_right_meta_lbl = ttk.Label(dr_f, text='', foreground='gray',
                                              font=('Malgun Gothic', 7))
        self._doc_right_meta_lbl.pack(anchor='w', padx=4)
        # 제목(다국어) — `sys_ref_text.title`(2026-08-10). 본문과 같은 행이라
        # 언어를 바꾸면 제목도 함께 바뀐다. 비우면 목록에 unit_label 이 나온다.
        dr_ttl = ttk.Frame(dr_f)
        dr_ttl.pack(fill='x', padx=4, pady=(0, 2))
        ttk.Label(dr_ttl, text='제목', width=4).pack(side='left')
        self._doc_right_title_var = tk.StringVar()
        ttk.Entry(dr_ttl, textvariable=self._doc_right_title_var).pack(
            side='left', fill='x', expand=True)
        dr_wrap = ttk.Frame(dr_f)
        dr_wrap.pack(fill='both', expand=True, padx=4, pady=(0, 2))
        dr_vsb = ttk.Scrollbar(dr_wrap, orient='vertical')
        dr_vsb.pack(side='right', fill='y')
        self._doc_right_body_txt = tk.Text(
            dr_wrap, wrap='word', font=('Malgun Gothic', 9),
            relief='flat', bg='#FAFAFA', yscrollcommand=dr_vsb.set)
        dr_vsb.config(command=self._doc_right_body_txt.yview)
        self._doc_right_body_txt.pack(fill='both', expand=True)

    def _load_ref_units(self, src_id: int):
        try:
            conn = _db()
            # ★ **목록 요약**(REF_UNIT_SHORT · 2026-08-27 사용자 승인 —
            #   「문답 목록이 길거나 숫자만 있다. 핵심을 한두 단어로」).
            #   있으면 요약 칼럼에, 검색도 요약으로 걸린다. 없으면 빈칸(폴백).
            rows = conn.execute(
                "SELECT u.ref_unit_id, u.sequence, u.unit_label, u.section_code,"
                "  COALESCE((SELECT sh.title FROM sys_text_asset sh "
                "     WHERE sh.text_type='REF_UNIT_SHORT' "
                "       AND sh.clicked_id=u.ref_unit_id "
                "       AND TRIM(COALESCE(sh.title,''))<>'' "
                "       AND COALESCE(sh.record_status,'LIVE')='LIVE' "
                "     ORDER BY CASE UPPER(sh.lang_code) WHEN 'KO' THEN 0 "
                "              WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1), '') "
                "FROM sys_ref_unit u "
                "WHERE u.ref_src_id=? AND u.record_status='LIVE' "
                "ORDER BY u.sequence",
                (src_id,)
            ).fetchall()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return
        self._all_ref_units = rows
        self._current_ref_unit_id = None
        if hasattr(self, '_doc_filter_var'):
            self._doc_filter_var.set('')
        self._apply_doc_unit_filter()
        # ⚠ 왼쪽은 disabled — 잠깐 열고 다시 잠근다
        for attr in ('_doc_left_body_txt', '_doc_right_body_txt'):
            if hasattr(self, attr):
                _w = getattr(self, attr)
                _st = str(_w.cget('state'))
                _w.config(state='normal')
                _w.delete('1.0', 'end')
                _w.config(state=_st)
        for attr in ('_doc_left_meta_lbl', '_doc_right_meta_lbl'):
            if hasattr(self, attr):
                getattr(self, attr).config(text='(유닛을 선택하면 본문이 표시됩니다)',
                                           foreground='gray')

    def _apply_doc_unit_filter(self):
        if not hasattr(self, '_doc_unit_tv'):
            return
        self._doc_unit_tv.delete(*self._doc_unit_tv.get_children())
        keyword = getattr(self, '_doc_filter_var', tk.StringVar()).get().strip().lower()
        rows = self._all_ref_units
        shown = 0
        for uid, seq, label, section, short in rows:
            # 검색은 제목 + **요약** 둘 다 — 「위로」로 쳐도 Q.1 이 나온다
            if keyword and keyword not in (label or '').lower()                     and keyword not in (short or '').lower():
                continue
            self._doc_unit_tv.insert('', 'end', iid=f'RU_{uid}',
                                     values=(seq, short or '', label or '',
                                             section or ''))
            shown += 1
        total = len(rows)
        if hasattr(self, '_doc_t2_count_lbl'):
            if keyword:
                self._doc_t2_count_lbl.config(text=f'{shown}/{total}개 표시')
            else:
                self._doc_t2_count_lbl.config(text=f'총 {total}개 유닛')

    def _on_doc_unit_select(self, _=None):
        sel = self._doc_unit_tv.selection()
        if not sel:
            return
        iid = sel[0]
        if not iid.startswith('RU_'):
            return
        try:
            uid = int(iid[3:])
        except ValueError:
            return
        self._current_ref_unit_id = uid
        # ★ 고른 문답이 바뀌면 연결 탭도 그 문답을 본다(안 하면 옛 목록이 남는다)
        self._refresh_doc_link_tab()
        self._load_doc_short()
        self._refresh_doc_left_body()
        self._refresh_doc_right_body()

    # ── 목록 요약(REF_UNIT_SHORT) — 2026-08-27 ─────────────────────────
    # ★ 규칙은 `db_refunit_short` 가 정한다(길이 게이트·빈 값=HIDE·EN 폴백).
    #   여기서 SQL 을 쓰면 두 벌이 된다.
    def _load_doc_short(self):
        if not hasattr(self, '_doc_short_var'):
            return
        uid = getattr(self, '_current_ref_unit_id', None)
        self._doc_short_var.set('')
        if not uid:
            return
        try:
            import db_refunit_short as SH
            conn = _db()
            try:
                # ⚠ 폴백 없이 **그 언어의 것만** — EN 값을 KO 칸에 보이면
                #   저장할 때 EN 요약이 KO 로 복제된다
                r = conn.execute(
                    "SELECT title FROM sys_text_asset "
                    " WHERE text_type=? AND clicked_id=? "
                    "   AND UPPER(lang_code)=? "
                    "   AND COALESCE(record_status,'LIVE')='LIVE'",
                    (SH.TT, uid,
                     _name_to_code(self._doc_short_lang.get()))
                ).fetchone()
                self._doc_short_var.set((r and r[0]) or '')
            finally:
                conn.close()
        except Exception as e:
            print('[doc short load] %s' % e)

    def _save_doc_short(self):
        uid = getattr(self, '_current_ref_unit_id', None)
        if not uid:
            messagebox.showinfo('목록 요약', '문답을 먼저 선택하세요.', parent=self)
            return
        try:
            import db_refunit_short as SH
            conn = _db()
            try:
                SH.save_short(conn, uid,
                              _name_to_code(self._doc_short_lang.get()),
                              self._doc_short_var.get())
            finally:
                conn.close()
        except ValueError as e:
            messagebox.showwarning('목록 요약', str(e), parent=self)
            return
        except Exception as e:
            messagebox.showerror('목록 요약', str(e), parent=self)
            return
        # 목록 칼럼이 곧 저장 결과다 — 다시 읽어 보인다
        if getattr(self, '_ref_src_id', None):
            self._load_ref_units(self._ref_src_id)

    def _on_doc_left_variant_change(self):
        variant = self._doc_left_variant_var.get()
        if variant == 'TRANSLATED':
            self._doc_left_lang_var.set(_code_to_name('KO'))
        else:
            self._doc_left_lang_var.set(_code_to_name('EN'))

    def _on_doc_right_variant_change(self):
        variant = self._doc_right_variant_var.get()
        if variant == 'TRANSLATED':
            self._doc_right_lang_var.set(_code_to_name('KO'))
        else:
            self._doc_right_lang_var.set(_code_to_name('EN'))

    def _refresh_doc_left_body(self):
        uid = self._current_ref_unit_id
        if not uid or not hasattr(self, '_doc_left_body_txt'):
            return
        variant = self._doc_left_variant_var.get()
        lang    = _name_to_code(self._doc_left_lang_var.get())
        try:
            conn = _db()
            _ensure_title_col(conn)
            row = conn.execute(
                "SELECT text_id, body_text, title FROM sys_ref_text "
                "WHERE ref_unit_id=? AND text_variant=? AND lang_code=? "
                "  AND record_status='LIVE'",
                (uid, variant, lang)
            ).fetchone()
            conn.close()
        except Exception:
            row = None
        # ⚠ 읽기 전용이라 채우는 동안만 잠깐 연다(안 열면 조용히 안 들어간다)
        self._doc_left_body_txt.config(state='normal')
        self._doc_left_body_txt.delete('1.0', 'end')
        self._doc_left_title_var.set((row[2] or '') if row else '')
        if row and row[1]:
            self._doc_left_meta_lbl.config(
                text=f'uid={uid}  {variant}/{lang}  tid={row[0]}',
                foreground='#555')
            self._doc_left_body_txt.insert('1.0', row[1])
        else:
            self._doc_left_meta_lbl.config(
                text=f'uid={uid}  {variant}/{lang}  (없음)', foreground='gray')
        self._doc_left_body_txt.config(state='disabled')     # 다시 잠근다
        self._doc_left_save_lbl.config(text='')

    def _refresh_doc_right_body(self):
        uid = self._current_ref_unit_id
        if not uid or not hasattr(self, '_doc_right_body_txt'):
            return
        variant = self._doc_right_variant_var.get()
        lang    = _name_to_code(self._doc_right_lang_var.get())
        try:
            conn = _db()
            _ensure_title_col(conn)
            row = conn.execute(
                "SELECT text_id, body_text, title FROM sys_ref_text "
                "WHERE ref_unit_id=? AND text_variant=? AND lang_code=? "
                "  AND record_status='LIVE'",
                (uid, variant, lang)
            ).fetchone()
            conn.close()
        except Exception:
            row = None
        self._doc_right_body_txt.delete('1.0', 'end')
        self._doc_right_title_var.set((row[2] or '') if row else '')
        if row and row[1]:
            self._doc_right_meta_lbl.config(
                text=f'uid={uid}  {variant}/{lang}  tid={row[0]}',
                foreground='#555')
            self._doc_right_body_txt.insert('1.0', row[1])
        else:
            self._doc_right_meta_lbl.config(
                text=f'uid={uid}  {variant}/{lang}  (없음)', foreground='gray')
        self._doc_right_save_lbl.config(text='')

    def _save_doc_body_left(self):
        uid     = self._current_ref_unit_id
        variant = self._doc_left_variant_var.get()
        lang    = _name_to_code(self._doc_left_lang_var.get())
        self._save_ref_text(uid, variant, lang, self._doc_left_body_txt,
                            self._doc_left_save_lbl, self._refresh_doc_left_body,
                            self._doc_left_title_var.get().strip())

    def _save_doc_body_right(self):
        uid     = self._current_ref_unit_id
        variant = self._doc_right_variant_var.get()
        lang    = _name_to_code(self._doc_right_lang_var.get())
        self._save_ref_text(uid, variant, lang, self._doc_right_body_txt,
                            self._doc_right_save_lbl, self._refresh_doc_right_body,
                            self._doc_right_title_var.get().strip())

    def _save_ref_text(self, uid, variant, lang, txt_widget, lbl, refresh_fn,
                       title=None):
        if not uid:
            messagebox.showwarning('선택 필요', '유닛을 먼저 선택하세요.')
            return
        body = txt_widget.get('1.0', 'end-1c').strip()
        if not body:
            messagebox.showwarning('내용 없음', '본문 내용을 입력하세요.')
            return
        try:
            conn = _db()
            _ensure_title_col(conn)
            ex = conn.execute(
                "SELECT text_id FROM sys_ref_text "
                "WHERE ref_unit_id=? AND text_variant=? AND lang_code=? "
                "  AND record_status='LIVE'",
                (uid, variant, lang)
            ).fetchone()
            if ex:
                conn.execute("UPDATE sys_ref_text SET body_text=?, title=?"
                             " WHERE text_id=?", (body, title or None, ex[0]))
            else:
                conn.execute(
                    "INSERT INTO sys_ref_text "
                    "(ref_unit_id, text_variant, lang_code, body_text, title,"
                    " record_status) VALUES (?,?,?,?,?,'LIVE')",
                    (uid, variant, lang, body, title or None))
            conn.commit()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return
        lbl.config(text='저장됨', foreground='#27AE60')
        self.after(2000, lambda: lbl.config(text=''))
        refresh_fn()

    def _hide_doc_body_left(self):
        uid     = self._current_ref_unit_id
        variant = self._doc_left_variant_var.get()
        lang    = _name_to_code(self._doc_left_lang_var.get())
        self._hide_ref_text(uid, variant, lang, self._refresh_doc_left_body)

    def _hide_doc_body_right(self):
        uid     = self._current_ref_unit_id
        variant = self._doc_right_variant_var.get()
        lang    = _name_to_code(self._doc_right_lang_var.get())
        self._hide_ref_text(uid, variant, lang, self._refresh_doc_right_body)

    def _hide_ref_text(self, uid, variant, lang, refresh_fn):
        if not uid:
            return
        if not messagebox.askyesno(
            '삭제 확인',
            f'uid={uid}  {variant}/{lang} 본문을 HIDE 처리하시겠습니까?'
        ):
            return
        try:
            conn = _db()
            conn.execute(
                "UPDATE sys_ref_text SET record_status='HIDE' "
                "WHERE ref_unit_id=? AND text_variant=? AND lang_code=?",
                (uid, variant, lang))
            conn.commit()
            conn.close()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return
        refresh_fn()


# ── 유닛 추가/편집 다이얼로그 ─────────────────────────────────────────────────

class _UnitDialog(tk.Toplevel):

    def __init__(self, parent,
                 next_seq: int = 1,
                 default_type: str = 'CHAPTER',
                 prefill_label: str = '',
                 prefill_vref:  str = '',
                 prefill_vid:   str = '',
                 prefill_evid:  str = '',
                 prefill_body:  str = '',
                 edit_mode: bool = False):
        super().__init__(parent)
        self.title('유닛 편집' if edit_mode else '유닛 추가')
        self.resizable(True, True)
        self.grab_set()
        self.result = None

        outer = ttk.Frame(self)
        outer.pack(fill='both', expand=True, padx=14, pady=10)

        # ── 기본 정보 ──────────────────────────────────────────────
        info_f = ttk.LabelFrame(outer, text=' 기본정보 ')
        info_f.pack(fill='x', pady=(0, 6))

        def lbl_entry(parent, row_idx, label, default='', width=36):
            ttk.Label(parent, text=label, width=12, anchor='e').grid(
                row=row_idx, column=0, padx=(0, 6), pady=3, sticky='e')
            v = tk.StringVar(value=default)
            ttk.Entry(parent, textvariable=v, width=width).grid(
                row=row_idx, column=1, sticky='w')
            return v

        self._seq_v   = lbl_entry(info_f, 0, '순서 (seq)', str(next_seq), width=8)
        self._lbl_v   = lbl_entry(info_f, 1, '제목', prefill_label, width=38)

        ttk.Label(info_f, text='유형', width=12, anchor='e').grid(
            row=2, column=0, padx=(0, 6), pady=3, sticky='e')
        self._type_v = tk.StringVar(value=default_type)
        ttk.Combobox(info_f, textvariable=self._type_v, values=_SESSION_TYPES,
                     width=14, state='readonly').grid(row=2, column=1, sticky='w')

        self._vref_v  = lbl_entry(info_f, 3, '성경 본문', prefill_vref, width=28)
        ttk.Label(info_f, text='예) John 3:16', foreground='gray',
                  font=('', 8)).grid(row=3, column=1, sticky='w', padx=(220, 0))

        # start_vid / end_vid
        self._svid_v = lbl_entry(info_f, 4, 'start_vid', prefill_vid, width=12)
        ttk.Label(info_f, text='verse_id 정수 (플랜 생성 기준)', foreground='gray',
                  font=('', 8)).grid(row=4, column=1, sticky='w', padx=(96, 0))
        self._evid_v = lbl_entry(info_f, 5, 'end_vid', prefill_evid, width=12)
        ttk.Label(info_f, text='범위 끝 (단일 구절이면 비워두기)', foreground='gray',
                  font=('', 8)).grid(row=5, column=1, sticky='w', padx=(96, 0))

        # ── 본문 내용 (ORIGINAL) ───────────────────────────────────
        body_f = ttk.LabelFrame(outer, text=' 본문 내용 (ORIGINAL) ')
        body_f.pack(fill='both', expand=True, pady=(0, 6))

        body_wrap = ttk.Frame(body_f)
        body_wrap.pack(fill='both', expand=True, padx=4, pady=4)
        body_vsb = ttk.Scrollbar(body_wrap, orient='vertical')
        body_vsb.pack(side='right', fill='y')
        self._body_txt = tk.Text(body_wrap, height=10, wrap='word',
                                  font=('Malgun Gothic', 9),
                                  yscrollcommand=body_vsb.set)
        body_vsb.config(command=self._body_txt.yview)
        self._body_txt.pack(fill='both', expand=True)
        if prefill_body:
            self._body_txt.insert('1.0', prefill_body)

        ttk.Label(body_f,
                  text='비워두면 본문 없이 저장됩니다  (나중에 편집 버튼으로 추가 가능)',
                  foreground='gray', font=('', 8)).pack(anchor='w', padx=6, pady=(0, 4))

        # ── 버튼 ──────────────────────────────────────────────────
        btn_f = ttk.Frame(outer)
        btn_f.pack(fill='x', pady=(4, 0))
        ttk.Button(btn_f, text='확인', command=self._ok,
                   width=10).pack(side='left', padx=4)
        ttk.Button(btn_f, text='취소', command=self.destroy,
                   width=10).pack(side='left', padx=4)

        self.geometry('520x480')
        self.after(100, lambda: self._lbl_v and None)

    def _ok(self):
        label = self._lbl_v.get().strip()
        if not label:
            messagebox.showwarning('입력 오류', '제목을 입력하세요.', parent=self)
            return
        try:
            seq = int(self._seq_v.get())
        except ValueError:
            messagebox.showwarning('입력 오류', '순서는 정수로 입력하세요.', parent=self)
            return
        body = self._body_txt.get('1.0', 'end-1c').strip()
        svid_s = self._svid_v.get().strip()
        evid_s = self._evid_v.get().strip()
        start_vid = int(svid_s) if svid_s.isdigit() else None
        end_vid   = int(evid_s) if evid_s.isdigit() else None
        self.result = (seq, self._type_v.get(), label,
                       self._vref_v.get().strip(),
                       start_vid, end_vid, body)
        self.destroy()
