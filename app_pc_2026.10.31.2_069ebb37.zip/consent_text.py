"""익명 이용통계 동의 텍스트 + 다이얼로그 (KO/EN, 기본 KO 폴백).

원문: docs/consent_{KO,EN}.md. 최초 실행 다이얼로그와 설정 '개인정보' 탭이 공용으로 사용.
버튼/짧은 라벨은 i18n.t 사용, 긴 고지 본문은 여기 상수로 보관(장문 prose).
향후 다국어 확장 시 _SHORT/_FULL 에 언어 추가.
"""
import tkinter as tk
import i18n

_SHORT = {
    "KO": (
        "hagahtorah를 개선하기 위해 익명 이용통계를 수집하고자 합니다.\n\n"
        "▪ 수집: 익명 식별자(UUID), 언어·성경버전·앱버전·기기 OS, 월 1회 화면별 사용 횟수·"
        "데이터 저장 건수 등 집계 숫자\n"
        "▪ 월 1회: 내가 받아 둔 자료의 이름표와 판 번호 (예: 성경 개역한글 1판)\n"
        "▪ 수집 안 함: 이름·이메일 등 개인정보, 노트 내용·검색어·구절 본문, IP·위치·국가\n"
        "▪ 동의/거부 선택 자체는 식별자 없이 익명으로 집계됩니다\n"
        "▪ 지금 실제로 보내는 값은 [설정 › 개인정보] 화면에서 그대로 볼 수 있습니다\n"
        "▪ 공동체 묵상 방(선택 기능): 방을 여는 사람이 적은 이름·연락처만 방 등록 신고로 "
        "관리자에게 한 번 전해집니다. 참여자 이름과 나눈 글은 여러분이 정한 폴더로만 "
        "오가며 이 앱의 서버에는 오지 않습니다\n\n"
        "데이터는 암호화(HTTPS) 전송되며 기능 개선 용도로만 사용됩니다. "
        "어린이 모드에서는 수집하지 않습니다."
    ),
    "EN": (
        "To improve hagahtorah, we'd like to collect anonymous usage statistics.\n\n"
        "- Collected: an anonymous ID (UUID), language, Bible version, app version, device OS, "
        "and once a month aggregate counts (per-screen usage, items saved, etc.)\n"
        "- Once a month: the labels and version numbers of the materials you have "
        "downloaded (e.g. Bible KRV v1)\n"
        "- Never collected: personal data (name, email), your notes/search terms/scripture text, "
        "IP, location, or country\n"
        "- Your consent choice itself is counted anonymously, without any identifier\n"
        "- [Settings > Privacy] shows exactly what is sent, right now\n"
        "- Community rooms (optional): only the name and contact entered by the person "
        "who opens a room are sent once to the admin as a room registration. Participants' "
        "names and shared notes travel only through the folder you choose - never to this "
        "app's server\n\n"
        "Data is sent encrypted (HTTPS) and used only to improve the app. "
        "Nothing is collected in Kids mode."
    ),
}

_FULL = {
    "KO": (
        "익명 이용통계 수집·이용 안내 (최종 업데이트: 2026-09-08)\n\n"
        "1. 목적\n사용 패턴을 익명으로 파악하여 기능 개선·우선순위 결정에 활용합니다. "
        "광고·판매·프로파일링에 사용하지 않습니다.\n\n"
        "2. 수집 항목\n· 최초 1회: 무작위 익명 식별자(UUID), 언어, 성경버전, 앱버전, 기기 OS\n"
        "· 월 1회: 접속 횟수, 화면별 사용 횟수, 데이터 저장·수정 건수, "
        "주석 열람·검색 실행 횟수 등 집계 숫자\n"
        "· 월 1회: 자료 보유 현황 — 내려받아 둔 자료의 종류·이름표·언어와 판 번호 "
        "(예: BOOK|SPURGEON_ME|KO = 3판). 자료의 내용·파일 경로·제목은 보내지 않습니다. "
        "이 앱은 자료를 정적 파일로 배포해 누가 받았는지 서버에 기록이 남지 않으므로, "
        "「지금 무엇을 갖고 있나」를 앱이 알리는 방식을 씁니다.\n"
        "· 지금 실제로 보내는 값은 [설정 › 개인정보] 화면에서 그대로 볼 수 있습니다.\n"
        "· 동의/거부 시: 선택 결과(동의/거부)만 식별자 없이 1회 익명 집계(개인 식별 불가)\n\n"
        "3. 수집하지 않는 정보\n이름·이메일·연락처 등 개인 식별정보, 노트·검색어·구절 본문 등 콘텐츠, "
        "IP 주소, 위치·국가. 수집 데이터만으로 개인을 식별할 수 없습니다. "
        "(예외 하나: 공동체 묵상 방을 여는 사람이 스스로 적는 이름·연락처 — 아래 10.)\n\n"
        "4. 보유 및 이용 기간\n수집일로부터 최대 12개월 보관 후 삭제합니다.\n\n"
        "5. 처리 위탁 및 국외 이전\n데이터는 Cloudflare, Inc.(미국/글로벌)의 서버에 암호화되어 저장됩니다. "
        "동의 시 국외 저장에 동의하는 것으로 봅니다.\n\n"
        "6. 동의 거부 권리 및 철회\n동의는 선택이며, 거부해도 모든 기능을 제한 없이 사용할 수 있습니다. "
        "[설정 › 개인정보]에서 언제든 철회할 수 있고, 철회 시 이후 수집이 중단됩니다.\n\n"
        "7. 삭제 요청\n앱 내 [1:1 문의]로 익명 식별자(UUID) 삭제를 요청할 수 있습니다. "
        "(UUID는 [설정 › 개인정보]에서 확인 가능)\n\n"
        "8. 만 14세 미만·어린이\n어린이 모드에서는 통계를 수집하지 않습니다. "
        "만 14세 미만은 법정대리인의 동의 하에 사용하시기 바랍니다.\n\n"
        "9. 문의\n앱 내 [1:1 문의]로 문의해 주세요.\n\n"
        "10. 공동체 묵상 방 (선택 기능)\n"
        "· 방을 여는 사람(방장)이 적는 이름·연락처(이메일)는 방 등록 신고로 이 앱의 관리자에게 "
        "한 번 전해집니다. 자료에 문제가 있거나 앱이 크게 바뀔 때 연락하는 데만 쓰며, "
        "다른 참여자에게 보이지 않고 광고에 쓰지 않습니다. 적지 않아도 방은 열립니다.\n"
        "· 참여자가 적는 이름과 나눈 글(묵상·게시판·첨부 파일)은 방장이 정한 폴더"
        "(구글드라이브 등 여러분의 동기화 폴더)로만 오갑니다. 이 앱을 만든 사람은 그 폴더에 "
        "접근할 수 없고 그 글을 받지도 보관하지도 않습니다.\n"
        "· 이용통계에는 방의 유형·인원·역할만 익명으로 실립니다. 방 이름·이름·연락처·글은 싣지 않습니다.\n"
        "· 방을 지우면 이 PC 의 방 기록과 연락처가 함께 사라집니다. 폴더의 파일은 그 공동체의 "
        "것이므로 앱이 지우지 않습니다.\n"
        "· 방에 올린 교재와 글의 내용은 방장의 책임입니다(방을 열 때 동의하는 책임 선언)."
    ),
    "EN": (
        "Notice on Anonymous Usage Statistics (Last updated: 2026-09-08)\n\n"
        "1. Purpose\nTo understand usage patterns anonymously and improve features. "
        "Never used for advertising, sale, or profiling.\n\n"
        "2. What we collect\n- Once at install: a random anonymous ID (UUID), language, Bible version, "
        "app version, device OS\n- Once a month: aggregate counts (sessions, per-screen usage, items "
        "saved/edited, commentary views, searches, etc.)\n- Once a month: materials on hand - the kind, label, language and version number of what you have downloaded (e.g. BOOK|SPURGEON_ME|KO = v3). We never send the contents, file paths or titles. Because this app distributes materials as static files, no server record of who downloaded what exists, so the app reports what it currently holds instead.\n- You can see exactly what is sent, right now, in [Settings > Privacy].\n- On your consent choice: only the outcome "
        "(accept/decline) is counted once, anonymously and without any identifier\n\n"
        "3. What we never collect\nPersonally identifying info (name, email, contact), content (notes, "
        "search terms, scripture text), IP address, or location/country. The data alone cannot identify you. "
        "(One exception: the name and contact a person enters themselves when opening a community room - see 10.)\n\n"
        "4. Retention\nStored for up to 12 months, then deleted.\n\n"
        "5. Processor & international transfer\nData is stored encrypted on Cloudflare, Inc. (US/global). "
        "By consenting you also consent to storage outside your country.\n\n"
        "6. Right to refuse / withdraw\nConsent is optional; refusing lets you use all features. "
        "Withdraw anytime in [Settings > Privacy]; collection stops thereafter.\n\n"
        "7. Deletion requests\nRequest deletion of your anonymous ID (UUID) via [Contact/Support]. "
        "(Your UUID is shown in [Settings > Privacy].)\n\n"
        "8. Children\nNothing is collected in Kids mode. Where required by law, users under the "
        "applicable age should use the app with a guardian's consent.\n\n"
        "9. Contact\nReach us via [Contact/Support] in the app.\n\n"
        "10. Community rooms (optional feature)\n"
        "- The name and contact (email) entered by the person who opens a room (the host) are sent once "
        "to this app's admin as a room registration. It is used only to reach the host about problem "
        "materials or major app changes, is never shown to other participants and never used for "
        "advertising. A room opens even without it.\n"
        "- Participants' names and shared writing (meditations, board posts, attached files) travel only "
        "through the folder the host chooses (your own sync folder such as Google Drive). The app's "
        "author cannot access that folder and neither receives nor stores that content.\n"
        "- Usage statistics carry only the room type, member count and role, anonymously - never the "
        "room name, names, contacts or writing.\n"
        "- Deleting a room removes the room record and contact from this PC. Files in the folder belong "
        "to the community and are not deleted by the app.\n"
        "- The host is responsible for the materials and posts in a room (the responsibility statement "
        "accepted when opening it)."
    ),
}


def _key(lang):
    return "EN" if str(lang or "").upper().startswith("EN") else "KO"


def short(lang):
    return _SHORT[_key(lang)]


def full(lang):
    return _FULL[_key(lang)]


def show_full_notice(master, lang="KO"):
    """전문 고지 팝업(스크롤). 최초 동의 다이얼로그와 설정 탭이 공용."""
    win = tk.Toplevel(master)
    win.title(i18n.t("CONSENT_TITLE", "익명 이용통계 안내"))
    win.geometry("640x560")
    win.transient(master)
    try:
        win.grab_set()
    except Exception:
        pass
    txt = tk.Text(win, wrap="word", font=("Malgun Gothic", 10), padx=14, pady=12)
    sb = tk.Scrollbar(win, command=txt.yview)
    txt.configure(yscrollcommand=sb.set)
    sb.pack(side="right", fill="y")
    txt.pack(side="left", fill="both", expand=True)
    txt.insert("1.0", full(lang))
    txt.config(state="disabled")
    tk.Button(win, text=i18n.t("COMMON_CLOSE", "닫기"), command=win.destroy).pack(side="bottom", pady=6)


def show_first_run_dialog(master, lang, on_result):
    """최초 실행 동의 다이얼로그(opt-in). on_result(agreed: bool) 콜백."""
    win = tk.Toplevel(master)
    win.title(i18n.t("CONSENT_TITLE", "익명 이용통계 수집 동의 (선택)"))
    win.geometry("560x430")
    win.transient(master)
    try:
        win.grab_set()
    except Exception:
        pass

    tk.Label(win, text=i18n.t("CONSENT_TITLE", "익명 이용통계 수집 동의 (선택)"),
             font=("Malgun Gothic", 12, "bold"), anchor="w").pack(fill="x", padx=16, pady=(14, 6))
    body = tk.Message(win, text=short(lang), width=520, font=("Malgun Gothic", 9), justify="left")
    body.pack(fill="x", padx=16)

    tk.Label(win, text=i18n.t("CONSENT_ASK", "익명 이용통계 수집에 동의하시겠습니까? (취소해도 모든 기능을 사용할 수 있습니다)"),
             font=("Malgun Gothic", 9), fg="#555", anchor="w", wraplength=520, justify="left"
             ).pack(fill="x", padx=16, pady=(10, 4))

    done = {"v": False}

    def _finish(agreed):
        if done["v"]:
            return
        done["v"] = True
        try:
            on_result(bool(agreed))
        finally:
            win.destroy()

    bar = tk.Frame(win)
    bar.pack(side="bottom", fill="x", pady=10)
    tk.Button(bar, text=i18n.t("CONSENT_OK", "동의"), bg="#1E8449", fg="white",
              padx=20, pady=4, font=("Malgun Gothic", 10, "bold"),
              command=lambda: _finish(True)).pack(side="right", padx=(4, 14))
    tk.Button(bar, text=i18n.t("CONSENT_CANCEL", "취소"), padx=16, pady=4,
              font=("Malgun Gothic", 10), command=lambda: _finish(False)).pack(side="right", padx=2)
    tk.Button(bar, text=i18n.t("CONSENT_MORE", "자세히 보기"),
              command=lambda: show_full_notice(win, lang)).pack(side="left", padx=14)

    # X 로 닫으면 '취소(미동의)'로 결정 처리(반복 질문 방지)
    win.protocol("WM_DELETE_WINDOW", lambda: _finish(False))
