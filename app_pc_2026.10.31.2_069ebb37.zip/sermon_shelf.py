# -*- coding: utf-8 -*-
"""sermon_shelf.py — 「설교 서재」 (영구 부품 · `--selftest` 의무, 2026-08-24 신설)
================================================================================

사용자 물음: 「설교집은 별도의 대시보드가 필요할까? **설교 분류를 통상적으로
어떻게 하는가? 그 기준을 사용하면 좋을 것 같다**」

★★★ **필요하다 — 단위가 다르다.** 실측:

    설교 3,573편 중 스펄전 한 권이 3,519편 (98%) · 나머지 네 권 합쳐 54편

  도서 서재가 「어느 **책**을 읽을까」라면 설교는 「어느 **설교**를 읽을까」다.
  거르는 대상이 책이 아니라 **편**이라 한 화면에 못 담는다. 그래서 도서 서재
  (`book_shelf` — 카드 격자)와 달리 여기는 **목록**이다(카드 3,573장은 못 그린다).

★★ **분류 축은 「본문(성경)」이다** — 설교집 색인의 통상 기준이면서, 우리가
   사실상 100% 가진 유일한 것이다. 통상 기준 여섯을 실측과 대조한 결과:

   | 통상 기준 | 우리 재료 | 채택 |
   |---|---|---|
   | **본문(강해)** — 성경 순서 | 기준 구절 **3,527/3,573 = 98.7%** | ✅ 장르 7 |
   | 저자·설교집 | 100% | ✅ |
   | 주제(Topical) | 태그 **191건 = 5%** | ✗ 아직 |
   | 교회력(절기) | 성탄 8 · 부활 14 · 오순절 4 | ✗ 재료 없음 |
   | 연대순 | `sermon_date` 가 `Lord's Day Morning` 류 자유 글이라 **연도가 안 나온다** | ✗ |
   | 분량 | 편당 유닛 **중앙 17 · 85%가 16~20** | ✗ **구분이 안 된다** |

   ⚠ **분량 축을 일부러 뺐다.** 도서에서는 16~59,313유닛으로 갈리지만 설교는
     거의 다 같은 길이라, 구간을 만들어도 한 칸에 3,044편이 몰린다. **재료가
     있다고 축이 되는 것이 아니다 — 갈라야 축이다.**
   ⚠ 절기·설교 유형은 **재료가 없으니 단추를 만들지 않는다**(빈 서랍 금지, §4-⑤).

★ **기준 구절은 저장값을 안 믿는다** — `key_verse_ref` 에 줄바꿈과 로마 숫자가
  섞여 있다(실측 `'\\n\\nMATT. xvi'`). `start_vid` 에서 **그릴 때마다 다시
  짓는다**(§54 핀 칩과 같은 원칙) — 화면 언어도 저절로 따라온다.
"""

import os
import sys
import tkinter as tk
from tkinter import ttk

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

import appdb
import i18n
from plan_builder import FilterRow

# 성경 장르 7 — 설교집 색인의 통상 구분. 실측 231·221·634·617·960·792·72.
GENRES = (('LAW',   'SS_G_LAW',   '모세오경',      1,  5),
          ('HIST',  'SS_G_HIST',  '역사서',        6, 17),
          ('POET',  'SS_G_POET',  '시가서',       18, 22),
          ('PROPH', 'SS_G_PROPH', '예언서',       23, 39),
          ('GOSP',  'SS_G_GOSP',  '복음서·행전',   40, 44),
          ('EPIS',  'SS_G_EPIS',  '서신서',       45, 65),
          ('REV',   'SS_G_REV',   '요한계시록',    66, 66),
          ('NONE',  'SS_G_NONE',  '본문 미상',      0,  0))

SORTS = (('bible', 'SS_SORT_BIBLE', '성경순'),
         ('book', 'SS_SORT_BOOK', '설교집'),
         ('title', 'SS_SORT_TITLE', '제목'))

# ⚠ **분량 축은 일부러 없다** (2026-08-24 실측). 사용자는 「분량은 의미 있다」고
#   보았으나 설교는 10%~90% 구간이 **15~18유닛**이고 「17유닛」 한 값에만
#   1,135편(32%)이 몰린다 — 스펄전 MTP 가 주간 소책자라 **인쇄 지면이 고정**돼
#   길이가 애초에 균일하다. 도서(16~59,313)와 달리 **갈리지 않으므로 축이 아니다.**
# ⚠ **연대 축도 없다** (사용자 판단이 맞았다) — 설교집 다섯의 연대가
#   1741·1770·1771·1836·1894 로 **저자와 1:1**이라 설교집 축과 같은 축이다.
ALL = '\x00ALL'          # 책 콤보의 「전체」 (책 이름과 겹칠 수 없는 값)


def _C(role, fallback):
    try:
        import ui_theme
        return ui_theme.C(role) or fallback
    except Exception:
        return fallback


def genre_of(bcode):
    """그 책이 드는 장르 코드. `bcode` 가 없으면 `'NONE'`."""
    if not bcode:
        return 'NONE'
    for code, _ik, _lbl, lo, hi in GENRES:
        if lo and lo <= bcode <= hi:
            return code
    return 'NONE'


def fetch(db_path, lang='KO'):
    """[{unit_id, book_id, src, title, ref, bcode, vid, read}] — 한 번에.

    ⚠ 3,573편을 편마다 물으면 화면이 멈춘다. **질의 셋**(설교집·유닛·약명 표)으로
      끝낸다. 약명은 `book_names` 를 한 번 읽어 파이썬에서 붙인다.
    """
    out = []
    try:
        with appdb.connect(db_path) as c:
            # ⚠ 팩 경계는 **설교집 단위**다(편 하나만 받는 일은 없다).
            has = {r[0] for r in c.execute(
                "SELECT DISTINCT u.book_id FROM sys_book_unit u "
                " JOIN sys_book_unit_text x ON x.unit_id = u.unit_id")}
            src = {}
            for bid, t in c.execute(
                    "SELECT a.book_id, COALESCE(k.title, a.title) "
                    "  FROM sys_book_asset a "
                    "  LEFT JOIN sys_book_asset_text k "
                    "         ON k.book_id = a.book_id AND k.lang_code = ? "
                    " WHERE a.book_category='SERMON' "
                    "   AND COALESCE(a.record_status,'LIVE')='LIVE'", (lang,)):
                src[bid] = t or ''

            # 약명 — **저장된 `key_verse_ref` 를 안 쓴다**(줄바꿈·로마 숫자 혼재).
            names = {}
            for bc, sn in c.execute(
                    "SELECT bn.book_code, bn.short_name FROM book_names bn "
                    " WHERE bn.lang_code=?", (lang,)):
                names[bc] = sn
            if not names:
                for bc, sn in c.execute(
                        "SELECT book_code, short_name FROM book_names "
                        " WHERE lang_code='EN'"):
                    names[bc] = sn

            q = ("SELECT u.unit_id, u.book_id, u.unit_label, u.sequence, "
                 "       bi.bcode, bi.chapter, bi.verse, u.start_vid "
                 "  FROM sys_book_unit u "
                 "  JOIN sys_book_asset a ON a.book_id = u.book_id "
                 "  LEFT JOIN bible_index bi ON bi.verse_id = u.start_vid "
                 " WHERE a.book_category='SERMON' "
                 "   AND COALESCE(u.record_status,'LIVE')='LIVE' "
                 "   AND COALESCE(a.record_status,'LIVE')='LIVE'")
            for uid, bid, label, seq, bc, ch, vs, vid in c.execute(q):
                out.append({
                    'unit_id': uid,
                    'book_id': bid,
                    'src': src.get(bid, ''),
                    'title': ' '.join((label or '').split()),   # ⚠ 줄바꿈을 눌러 준다
                    'seq': seq or 0,
                    'bcode': bc or 0,
                    'bname': names.get(bc) or names.get(str(bc)) or '',
                    'ref': ref_label(names, bc, ch, vs),
                    'vid': vid or 0,
                    'has_text': bid in has,
                    'read': 0,
                })
    except Exception as e:
        print('[sermon_shelf fetch] %s' % e)
    return out


def ref_label(names, bcode, chapter, verse):
    """`창1:1` — CJK 는 붙이고 라틴은 한 칸 띄운다(§54 표기 규칙)."""
    if not bcode:
        return ''
    sn = names.get(bcode) or names.get(str(bcode)) or ''
    if not sn:
        return ''
    gap = '' if any('　' <= ch <= '鿿' or '가' <= ch <= '힣'
                    for ch in sn) else ' '
    return '%s%s%s:%s' % (sn, gap, chapter or 1, verse or 1)


def sort_rows(rows, key):
    if key == 'book':
        return sorted(rows, key=lambda r: (r['src'], r['seq'], r['title']))
    if key == 'title':
        return sorted(rows, key=lambda r: (r['title'].lower(), r['src']))
    # 성경순 — **본문 미상은 맨 뒤**(0 을 앞에 두면 창세기보다 앞선다)
    return sorted(rows, key=lambda r: (r['vid'] == 0, r['vid'], r['title']))


def apply_filters(rows, srcs, genres, read_only, query='', bcode=None):
    """묶음 안 OR · 묶음 사이 AND + 책 한 권 + 제목/약명 찾기."""
    q = (query or '').strip().lower()
    out = []
    for r in rows:
        if srcs is not None and r['book_id'] not in srcs:
            continue
        if genres is not None and genre_of(r['bcode']) not in genres:
            continue
        if bcode and r['bcode'] != bcode:
            continue
        if read_only and not r.get('read'):
            continue
        if q and q not in r['title'].lower() and q not in r['ref'].lower():
            continue
        out.append(r)
    return out


def empty_reason(rows, srcs, genres, read_only, query='', bcode=None):
    """0건이면 **왜**인지 한 줄. 조용히 비면 고장으로 읽힌다(§0 no silent caps)."""
    if not rows:
        return i18n.t('SS_EMPTY_NONE', '등록된 설교가 없습니다.')
    guilty = []
    if query and apply_filters(rows, srcs, genres, read_only, '', bcode):
        guilty.append(i18n.t('SS_FIND', '찾기'))
    if srcs is not None and apply_filters(rows, None, genres, read_only, query, bcode):
        guilty.append(i18n.t('SS_G_SRC', '설교집'))
    if genres is not None and apply_filters(rows, srcs, None, read_only, query, bcode):
        guilty.append(i18n.t('SS_G_BIBLE', '본문'))
    if bcode and apply_filters(rows, srcs, genres, read_only, query, None):
        guilty.append(i18n.t('SS_G_BOOK', '책'))
    if read_only and apply_filters(rows, srcs, genres, False, query, bcode):
        guilty.append(i18n.t('SS_READ_ONLY', '읽은 것만'))
    if guilty:
        return i18n.t('SS_EMPTY_BY',
                      '선택한 조건에 맞는 설교가 없습니다 — 「{g}」 조건을 넓혀 보세요.'
                      ).format(g=' · '.join(guilty))
    return i18n.t('SS_EMPTY_ALL', '선택한 조건에 맞는 설교가 없습니다.')


class SermonShelf(tk.Frame):
    """설교 서재 — 설교집·본문 필터 + 찾기 + 정렬 + 편 목록."""

    def __init__(self, parent, db_path, lang_getter=None, on_open=None,
                 read_getter=None, on_download=None, **kw):
        """on_open(unit_id) — 줄을 누르면 그 설교를 설교집 갈래에서 연다.
        on_download(book_id) — **아직 안 받은 설교집**은 여기로(다운로드 화면).
        read_getter(book_id) → 그 설교집에서 읽은 unit_id 집합(없으면 빈 집합)."""
        super().__init__(parent, **kw)
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.on_open = on_open
        self.on_download = on_download
        self.read_getter = read_getter
        self._rows = []
        self._sort = tk.StringVar(value='bible')
        self._read_only = tk.BooleanVar(value=False)
        self._q = tk.StringVar(value='')
        self._bk = tk.StringVar(value='')      # 책 콤보의 표시값
        self._bk_map = {}                      # 표시값 → bcode
        self._f_src = self._f_gen = None
        self._built_bar = False
        self._build()

    # ── 화면 ──────────────────────────────────────────────────────────────
    def _build(self):
        bg = _C('bg', '#FDFEFE')
        self.configure(bg=bg)
        pnl = _C('panel_alt', '#F4F6F7')
        self._bar = tk.Frame(self, bg=pnl)
        self._bar.pack(fill='x')
        self._opt_f = tk.Frame(self._bar, bg=pnl)
        self._opt_f.pack(fill='x', padx=6, pady=(4, 2))
        ttk.Separator(self._bar, orient='horizontal').pack(fill='x', padx=6)
        self._sort_f = tk.Frame(self._bar, bg=pnl)
        self._sort_f.pack(fill='x', padx=6, pady=(3, 4))

        wrap = tk.Frame(self, bg=bg)
        wrap.pack(fill='both', expand=True, padx=4, pady=(2, 4))
        # ★★ **순위 칸은 「읽을 차례」를 켤 때만 펴진다**(2026-08-31) —
        #   평소 폭 0 이라 지금과 똑같이 보인다(`media_list_view` 의 pick 칸과
        #   같은 문법, §111차). 설교 서재는 **카드가 아니라 목록**이라 카드에
        #   달던 순위·▲▼ 를 그대로 못 쓴다.
        # ★★★ **체크 칸 + 순위 칸 — 둘 다 「읽을 차례」를 켤 때만 펴진다**
        #   (2026-08-31). 평소 폭 0 이라 지금과 똑같이 보인다.
        #   ⚠⚠ **고르기와 열기를 갈라야 한다** — 그전 판은 여러 줄을 고를 수만
        #     있게 하고 **줄을 누르면 설교가 열리는 것을 안 막아서**, 담을 것을
        #     고르는 순간 화면이 떠나 버렸다(사용자 「목록을 클릭하면 연결되어
        #     버린다」). §111차에 링크 목록에서 겪은 그 문제이고, 그때 만든 답
        #     (체크 칸 + 「고르는 동안에는 아무것도 열지 않는다」)을 그대로 쓴다.
        cols = ('pick', 'ord', 'ref', 'src')
        self._tv = ttk.Treeview(wrap, columns=cols, show='tree headings',
                                selectmode='browse')
        self._tv.heading('#0', text=i18n.t('SS_C_TITLE', '설교 제목'))
        self._tv.heading('pick', text='')
        self._tv.column('pick', width=0, minwidth=0, anchor='center',
                        stretch=False)
        self._tv.heading('ord', text='')
        self._tv.heading('ref', text=i18n.t('SS_C_REF', '본문'))
        self._tv.heading('src', text=i18n.t('SS_C_SRC', '설교집'))
        self._tv.column('ord', width=0, minwidth=0, anchor='center',
                        stretch=False)
        self._tv.column('#0', width=430, stretch=True)
        self._tv.column('ref', width=110, anchor='w', stretch=False)
        self._tv.column('src', width=150, anchor='w', stretch=False)
        sb = ttk.Scrollbar(wrap, orient='vertical', command=self._tv.yview)
        self._tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._tv.pack(side='left', fill='both', expand=True)
        # ★ 한 번 눌러 연다(도서 카드와 같은 규약).
        self._tv.bind('<<TreeviewSelect>>', self._on_pick)
        try:
            import theme_font
            theme_font.list_style('SermonShelf.Treeview', self.db_path)
            self._tv.configure(style='SermonShelf.Treeview')
        except Exception:
            pass
        self._retag()

    def _retag(self):
        """태그 색은 **그릴 때마다 역할로 다시** 준다(§36-5b)."""
        try:
            self._tv.tag_configure('empty', foreground=_C('fg_dim', '#95A5A6'))
            self._tv.tag_configure('read', foreground=_C('fg_dim', '#7F8C8D'))
            self._tv.tag_configure('nodl', foreground=_C('warning', '#B7950B'))
        except Exception:
            pass

    # ── 데이터 ────────────────────────────────────────────────────────────
    def reload(self):
        self._rows = fetch(self.db_path, (self.lang_getter() or 'KO').upper())
        if callable(self.read_getter):
            done = {}
            for r in self._rows:
                bid = r['book_id']
                if bid not in done:
                    try:
                        done[bid] = set(self.read_getter(bid) or ())
                    except Exception:
                        done[bid] = set()
                r['read'] = 1 if r['unit_id'] in done[bid] else 0
        self._build_bar()
        self._render()

    def _build_bar(self):
        """필터는 **한 번만 짓는다** — 다시 지으면 켠 체크가 풀린다."""
        if self._built_bar:
            return
        pnl = _C('panel_alt', '#F4F6F7')

        # 설교집 — 개수를 함께 적는다(스펄전 3,519 대 웨슬리 4 라 안 적으면 오해한다)
        cnt = {}
        name = {}
        for r in self._rows:
            cnt[r['book_id']] = cnt.get(r['book_id'], 0) + 1
            name[r['book_id']] = r['src']
        ids = sorted(cnt, key=lambda b: -cnt[b])
        self._f_src = FilterRow(
            self._opt_f, 0, i18n.t('SS_G_SRC', '설교집'), ids,
            {b: '%s (%s)' % (name[b][:12], '{:,}'.format(cnt[b])) for b in ids},
            self._render)

        used = {genre_of(r['bcode']) for r in self._rows}
        gens = [g[0] for g in GENRES if g[0] in used]
        self._f_gen = FilterRow(
            self._opt_f, 1, i18n.t('SS_G_BIBLE', '본문'), gens,
            {g[0]: i18n.t(g[1], g[2]) for g in GENRES}, self._on_genre)

        # ★ **책은 콤보 하나**(체크박스 66개는 못 놓는다). 셋째 축이면서 값이
        #   싸고 실제로 좁힌다 — 복음서·행전 960편이 요한복음 312편으로 준다.
        #   ⚠ 목록은 **위 두 줄을 이미 통과한 편**에서만 만든다. 안 그러면 고를 수
        #     없는 책이 콤보에 떠서 골라 놓고 0건이 된다.
        tk.Label(self._opt_f, text=i18n.t('SS_G_BOOK', '책'), bg=pnl,
                 fg=_C('fg', '#2C3E50')).grid(row=2, column=0, sticky='w',
                                              padx=(2, 8), pady=2)
        self._bk_cb = ttk.Combobox(self._opt_f, textvariable=self._bk,
                                   state='readonly', width=18)
        self._bk_cb.grid(row=2, column=1, columnspan=3, sticky='w', pady=2)
        self._bk_cb.bind('<<ComboboxSelected>>', lambda _e: self._render())

        tk.Label(self._sort_f, text=i18n.t('SS_SORT', '정렬'), bg=pnl,
                 fg=_C('fg_dim', '#7F8C8D')).pack(side='left', padx=(2, 8))
        for key, ikey, dflt in SORTS:
            ttk.Radiobutton(self._sort_f, text=i18n.t(ikey, dflt), value=key,
                            variable=self._sort,
                            command=self._render).pack(side='left', padx=(0, 10))
        ttk.Checkbutton(self._sort_f, text=i18n.t('SS_READ_ONLY', '읽은 것만'),
                        variable=self._read_only,
                        command=self._render).pack(side='left', padx=(20, 0))
        # ★★★ **읽을 차례 — 설교는 「편」 단위다**(2026-08-31 사용자 「설교서재
        #   에서 읽을차례 기능은 어떻게 적용해야 하는가? … **목록에 체크 기능을
        #   부가**해야 할 것 같다」).
        #   ⚠ 도서 서재는 **책**(38권)에 차례를 매기지만 설교집은 5권뿐이고
        #     사용자가 고르는 것은 **설교 한 편**이다. 그래서 알갱이가 다르다.
        #   ★ 카드가 아니라 목록이라 ▲▼ 를 줄마다 못 단다 — **여러 줄을 골라**
        #     이 줄의 단추로 한꺼번에 옮긴다(`selectmode='extended'`).
        self._order_on = tk.BooleanVar(value=False)
        ttk.Checkbutton(self._sort_f, text=i18n.t('BS_SORT_ORDER', '읽을 차례'),
                        variable=self._order_on,
                        command=self._render).pack(side='left', padx=(20, 0))
        self._ord_btns = tk.Frame(self._sort_f, bg=pnl)
        for _t, _cb in (('▲', lambda: self._ord_move(-1)),
                        ('▼', lambda: self._ord_move(+1)),
                        (i18n.t('BS_ORDER_ADD', '＋ 차례에'),
                         lambda: self._ord_edit('add')),
                        (i18n.t('BS_ORDER_DROP', '✕ 빼기'),
                         lambda: self._ord_edit('remove'))):
            tk.Button(self._ord_btns, text=_t, bg=pnl, bd=1, relief='raised',
                      font=('', 8), cursor='hand2', padx=4, pady=0,
                      command=_cb).pack(side='left', padx=(4, 0))
        # ★ **찾기는 여기에 꼭 있어야 한다** — 3,573편은 눈으로 못 훑는다.
        tk.Label(self._sort_f, text=i18n.t('SS_FIND', '찾기'), bg=pnl,
                 fg=_C('fg_dim', '#7F8C8D')).pack(side='left', padx=(20, 4))
        e = ttk.Entry(self._sort_f, textvariable=self._q, width=18)
        e.pack(side='left')
        self._q.trace_add('write', lambda *_a: self._render())
        self._cnt_lbl = tk.Label(self._sort_f, text='', bg=pnl,
                                 fg=_C('fg_dim', '#7F8C8D'))
        self._cnt_lbl.pack(side='right', padx=(0, 4))
        self._built_bar = True
        self._sync_book_combo()

    def _on_genre(self, *_a):
        """장르를 바꾸면 **책 콤보 목록을 다시 짓는다** — 선택할 수 없는 책을 남기면
        골라 놓고 0건이 된다. 지금 고른 책이 새 목록에 없으면 전체로 되돌린다."""
        self._sync_book_combo()
        self._render()

    def _sync_book_combo(self):
        srcs, gens = self._sel()
        pool = apply_filters(self._rows, srcs, gens, False, '', None)
        cnt, name = {}, {}
        for r in pool:
            if not r['bcode']:
                continue
            cnt[r['bcode']] = cnt.get(r['bcode'], 0) + 1
            name[r['bcode']] = r['bname'] or str(r['bcode'])
        allv = i18n.t('COMMON_ALL', '전체')
        vals = [allv]
        self._bk_map = {allv: None}
        for bc in sorted(cnt):                       # 정경 순서
            lbl = '%s (%d)' % (name[bc], cnt[bc])
            vals.append(lbl)
            self._bk_map[lbl] = bc
        try:
            self._bk_cb['values'] = vals
        except Exception:
            return
        if self._bk.get() not in self._bk_map:
            self._bk.set(allv)

    def _sel(self):
        def s(f):
            if f is None or f.is_all():
                return None
            return set(f.get_selected())
        return s(self._f_src), s(self._f_gen)

    def _bcode(self):
        return self._bk_map.get(self._bk.get())

    ORDER_KIND = 'SERMON'        # 읽을 차례의 갈래 — **편(unit_id)** 을 담는다
    on_order_changed = None
    PICK_MARK = 'v'              # 체크 표식 — 맑은 고딕 보유 글자만(§29)

    def _picks(self):
        if not hasattr(self, '_pick_set'):
            self._pick_set = set()
        return self._pick_set

    def _toggle_pick(self, iid):
        """체크 칸 토글 — **여는 대신** 이것을 한다(차례 모드)."""
        try:
            uid = int(iid[1:])
        except Exception:
            return
        ps = self._picks()
        ps.discard(uid) if uid in ps else ps.add(uid)
        try:
            self._tv.set(iid, 'pick', self.PICK_MARK if uid in ps else '')
        except Exception:
            pass
        self._sync_ord_btns()

    def _sync_ord_btns(self):
        """선택한 것이 없으면 **왜 잠겼는지** 이름이 말한다."""
        n = len(self._picks())
        b = getattr(self, '_pick_lbl', None)
        if b is not None:
            b.config(text=i18n.t('SS_PICKED', '선택한 것 {n}편').format(n=n)
                     if n else i18n.t('SS_PICK_HINT', '줄을 눌러 선택하세요'))

    def order_mode(self):
        try:
            return bool(self._order_on.get())
        except Exception:
            return False

    def _rank(self):
        """`{unit_id: 순위}` — 읽은 편은 빠지고 번호가 다시 매겨진다."""
        if not self.order_mode():
            return {}
        try:
            import read_order, appdb as _a
            fin = {r['unit_id'] for r in self._rows if r.get('read')}
            with _a.connect(self.db_path) as c:
                return read_order.rank_map(c, self.ORDER_KIND, fin)
        except Exception as e:
            print('[sermon rank] %s' % e)
            return {}

    def _picked(self):
        """차례 단추가 다루는 것 = **체크한 편**(선택한 줄이 아니다)."""
        return [u for u in self._order_seq() if u in self._picks()]             or sorted(self._picks())

    def _order_seq(self):
        try:
            import read_order, appdb as _a
            with _a.connect(self.db_path) as c:
                return read_order.order(c, self.ORDER_KIND)
        except Exception:
            return []

    def _ord_move(self, delta):
        ids = self._picked()
        if not ids:
            return
        try:
            import read_order, appdb as _a
            with _a.connect(self.db_path) as c:
                # ⚠⚠ **하나씩 옮기면 순환한다** — 맨 위 것이 못 올라가는 사이
                #   아래 것들이 올라와 차례가 돌아버린다(실측 `[756,1339,3211]`
                #   에 ▲ → `1339,3211,756`). 묶음으로 옮기는 문 하나를 쓴다.
                read_order.move_many(c, self.ORDER_KIND, ids, delta)
        except Exception as e:
            print('[sermon move] %s' % e)
            return
        self._after_order(ids)

    def _ord_edit(self, what):
        ids = self._picked()
        if not ids:
            return
        try:
            import read_order, appdb as _a
            with _a.connect(self.db_path) as c:
                for u in ids:
                    getattr(read_order, what)(c, self.ORDER_KIND, u)
        except Exception as e:
            print('[sermon order %s] %s' % (what, e))
            return
        self._after_order(ids)

    def _after_order(self, ids):
        if not self.order_mode():
            self._order_on.set(True)
        self._render()             # 체크는 `_pick_set` 에 있어 다시 그려도 산다
        if callable(getattr(self, 'on_order_changed', None)):
            self.on_order_changed()

    def visible(self):
        srcs, gens = self._sel()
        rows = apply_filters(self._rows, srcs, gens, self._read_only.get(),
                             self._q.get(), self._bcode())
        rows = sort_rows(rows, self._sort.get())
        if not self.order_mode():
            return rows
        rk = self._rank()
        # 차례에 든 편이 위, 나머지는 원래 차례로 뒤에(빼지 않는다)
        return sorted(rows, key=lambda r: (0, rk[r['unit_id']])
                      if r['unit_id'] in rk else (1, 0))

    # ── 목록 ──────────────────────────────────────────────────────────────
    def _render(self, *_a):
        self._retag()
        tv = self._tv
        self._loading = True
        try:
            tv.delete(*tv.get_children())
            rows = self.visible()
            rk = self._rank()
            _om = self.order_mode()
            tv.column('ord', width=44 if _om else 0)
            tv.column('pick', width=26 if _om else 0)
            if not _om and self._picks():
                # ⚠ **접을 때 비운다** — 남기면 다음에 켰을 때 이미 체크된 채라
                #   「나도 모르게 담았다」가 난다(§111차 교훈).
                self._picks().clear()
            try:
                if _om and not self._ord_btns.winfo_ismapped():
                    self._ord_btns.pack(side='left', padx=(14, 0))
                elif not _om and self._ord_btns.winfo_ismapped():
                    self._ord_btns.pack_forget()
            except Exception:
                pass
            for r in rows:
                # ★ 안 받은 설교집은 **`↓`** — 읽음 축(●/○)과 섞지 않는다.
                #   `⤓ ⇩ ⬇` 는 맑은 고딕·굴림·바탕 셋 다 없다(cmap 실측).
                got = r.get('has_text', True)
                mark = ('●' if r['read'] else '○') if got else '↓'
                tv.insert('', 'end', iid='U%d' % r['unit_id'],
                          text='%s %s' % (mark, r['title'] or '(제목 없음)'),
                          values=(self.PICK_MARK if r['unit_id'] in self._picks()
                                  else '',
                                  str(rk.get(r['unit_id']) or ''),
                                  r['ref'], r['src']),
                          tags=(('nodl',) if not got
                                else ('read',) if r['read'] else ()))
            if not rows:
                srcs, gens = self._sel()
                tv.insert('', 'end', iid='EMPTY', values=('', '', '', ''),
                          text=empty_reason(self._rows, srcs, gens,
                                            self._read_only.get(), self._q.get(),
                                            self._bcode()),
                          tags=('empty',))
            try:
                n, t = len(rows), len(self._rows)
                self._cnt_lbl.config(
                    text=i18n.t('SS_COUNT', '{n}편').format(n='{:,}'.format(n))
                    if n == t else
                    i18n.t('SS_COUNT_OF', '{n} / {t}편').format(
                        n='{:,}'.format(n), t='{:,}'.format(t)))
            except Exception:
                pass
        finally:
            self._loading = False

    def _on_pick(self, _e=None):
        # ⚠ 다시 그리는 중에는 무시한다 — `delete`/`insert` 가 선택 이벤트를 낸다
        if getattr(self, '_loading', False):
            return
        sel = self._tv.selection()
        if not sel or sel[0] == 'EMPTY':
            return
        # ★★ **차례를 고르는 동안에는 아무것도 열지 않는다** — 누르면 체크만
        #   토글한다. 안 그러면 고르다가 설교가 열려 목록을 떠난다.
        if self.order_mode():
            self._toggle_pick(sel[0])
            return
        try:
            uid = int(sel[0][1:])
        except Exception:
            return
        r = next((x for x in self._rows if x['unit_id'] == uid), None)
        # ★ **안 받은 설교집은 설교집 탭이 아니라 다운로드 화면으로**(사용자 지시).
        if r is not None and not r.get('has_text', True):
            if callable(self.on_download):
                self.on_download(r['book_id'])
            else:
                print('[sermon_shelf] 안 받은 설교집 %s — 다운로드 경로 미배선'
                      % r['book_id'])
            return
        if callable(self.on_open):
            self.on_open(uid)


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def _selftest():
    ok = fail = 0

    def t(name, cond, extra=''):
        nonlocal ok, fail
        if cond:
            ok += 1
        else:
            fail += 1
            print('  FAIL %s %s' % (name, extra))

    db = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bible_master.db')
    rows = fetch(db, 'KO')
    t('설교를 읽어 온다', len(rows) > 3000, len(rows))
    t('제목이 다 있다', all(r['title'] for r in rows),
      [r['unit_id'] for r in rows if not r['title']][:3])
    # ★ 제목·약명에 줄바꿈이 남아 있으면 목록 한 줄이 깨진다(실측으로 잡은 결함)
    t('제목에 줄바꿈이 없다', not any('\n' in r['title'] or '\r' in r['title']
                                for r in rows))
    t('약명에 줄바꿈이 없다', not any('\n' in r['ref'] for r in rows))
    t('설교집 이름이 다 있다', all(r['src'] for r in rows))
    t('약명이 대부분 붙는다',
      sum(1 for r in rows if r['ref']) > len(rows) * 0.95,
      sum(1 for r in rows if r['ref']))
    t('약명이 한국어다', any('창' in r['ref'] or '요' in r['ref'] for r in rows),
      [r['ref'] for r in rows[:3]])
    # ⚠⚠ **파트가 되살아나지 않는가** — 설교 목록에 파트 칸이 있으면 안 된다
    #   (2026-08-24 폐기. 편당 유닛 중앙 17로 구분도 안 됐다).
    t('행에 파트가 없다', all('parts' not in r for r in rows))

    # 장르 — 모든 편이 정확히 한 칸에
    t('장르가 전 편을 덮는다', all(genre_of(r['bcode']) for r in rows))
    codes = {g[0] for g in GENRES}
    t('장르 코드가 표 안이다', all(genre_of(r['bcode']) in codes for r in rows))
    for code, _ik, lbl, lo, hi in GENRES:
        if code == 'NONE':
            continue
        t('장르 「%s」 에 설교가 있다' % lbl,
          any(genre_of(r['bcode']) == code for r in rows))
    t('장르가 겹치지 않는다',
      all(GENRES[i][4] + 1 == GENRES[i + 1][3]
          for i in range(len(GENRES) - 2)))

    # 필터
    t('전체면 다 나온다', len(apply_filters(rows, None, None, False)) == len(rows))
    g1 = {'GOSP'}
    t('장르 하나만 선택하면 그 칸만',
      all(genre_of(r['bcode']) in g1 for r in apply_filters(rows, None, g1, False)))
    b1 = {rows[0]['book_id']}
    both = apply_filters(rows, b1, g1, False)
    t('묶음 사이는 교집합', all(r['book_id'] in b1 and genre_of(r['bcode']) in g1
                          for r in both))
    t('AND 는 각각보다 크지 않다',
      len(both) <= min(len(apply_filters(rows, b1, None, False)),
                       len(apply_filters(rows, None, g1, False))))
    # 찾기
    word = rows[0]['title'].split()[0]
    found = apply_filters(rows, None, None, False, word)
    t('찾기가 걸린다', found and all(word.lower() in r['title'].lower()
                                or word.lower() in r['ref'].lower() for r in found),
      word)
    t('없는 말은 0건', len(apply_filters(rows, None, None, False, 'zzqq')) == 0)
    t('찾기가 약명으로도 걸린다',
      len(apply_filters(rows, None, None, False, '요')) > 0)

    msg = empty_reason(rows, None, None, False, 'zzqq')
    t('0건 이유가 찾기를 짚는다', '찾기' in msg, msg)

    # 정렬
    for key, _i, _d in SORTS:
        s = sort_rows(rows, key)
        t('정렬 %s 가 같은 집합이다' % key,
          {r['unit_id'] for r in s} == {r['unit_id'] for r in rows})
    b = sort_rows(rows, 'bible')
    zero = [i for i, r in enumerate(b) if r['vid'] == 0]
    t('본문 미상은 맨 뒤', (not zero) or min(zero) >= len(b) - len(zero), zero[:3])
    t('성경순이 실제로 오름차순',
      all(b[i]['vid'] <= b[i + 1]['vid']
          for i in range(len(b) - len(zero) - 1)))

    try:
        root = tk.Tk()
        root.geometry('1100x700')
    except Exception:
        print('  (건너뜀) Tk 없음')
        print('selftest %d/%d' % (ok, ok + fail))
        return fail == 0
    try:
        opened = []
        sh = SermonShelf(root, db, lambda: 'KO', on_open=opened.append)
        sh.pack(fill='both', expand=True)
        root.update()
        import time
        t0 = time.time()
        sh.reload()
        root.update()
        ms = (time.time() - t0) * 1000
        # ⚠ **기계 부하를 탄다** — 같은 코드가 한가할 때 ~1,000ms, 다른 검사와
        #   나란히 돌 때 2,600ms 로 재졌다(실측). 문턱을 1.5초로 두었더니 회귀가
        #   아닌 것을 회귀로 잡았다. **성능 검사는 넉넉히 잡고 값을 함께 찍는다.**
        t('3,573편을 4초 안에 그린다 (부하를 탄다)', ms < 4000, '%.0fms' % ms)
        print('        그리기 %.0fms (한가할 때 ~1,000)' % ms)
        t('줄이 다 그려진다', len(sh._tv.get_children()) == len(rows),
          '%d/%d' % (len(sh._tv.get_children()), len(rows)))
        # 장르 체크박스를 실제로 만진다
        sh._f_gen._all_var.set(False)
        for k, v in sh._f_gen._vars.items():
            v.set(k == 'GOSP')
        sh._render()
        root.update()
        want = len(apply_filters(rows, None, {'GOSP'}, False))
        t('체크박스를 만지면 그만큼만', len(sh.visible()) == want,
          '%d/%d' % (len(sh.visible()), want))
        t('개수 라벨이 부분을 알린다', '/' in sh._cnt_lbl.cget('text'),
          sh._cnt_lbl.cget('text'))
        # 찾기
        sh._f_gen._all_var.set(True)
        sh._f_gen._on_all()
        sh._q.set('zzqq')
        root.update()
        t('찾기 0건이면 이유가 뜬다',
          sh._tv.get_children() == ('EMPTY',) and
          bool(sh._tv.item('EMPTY', 'text').strip()),
          sh._tv.item('EMPTY', 'text') if sh._tv.get_children() else '(없음)')
        sh._q.set('')
        root.update()
        t('찾기를 지우면 돌아온다', len(sh.visible()) == len(rows))
        # ★ 책 콤보 — 셋째 축
        vals = list(sh._bk_cb['values'])
        t('책 콤보에 「전체」가 맨 앞', vals and vals[0] == i18n.t('COMMON_ALL', '전체'))
        t('책 콤보가 정경 순서',
          [sh._bk_map[v] for v in vals[1:]] == sorted(sh._bk_map[v] for v in vals[1:]))
        t('책 콤보가 편수를 적는다', all('(' in v for v in vals[1:]))
        pick = next((v for v in vals[1:] if v.startswith('요 ')
                     or v.startswith('요(')), vals[1] if len(vals) > 1 else None)
        if pick:
            sh._bk.set(pick)
            sh._render()
            root.update()
            bc = sh._bk_map[pick]
            t('책을 선택하면 그 책만',
              sh.visible() and all(r['bcode'] == bc for r in sh.visible()), pick)
            t('책 편수가 콤보 라벨과 맞는다',
              len(sh.visible()) == int(pick.rsplit('(', 1)[1].rstrip(')')),
              '%d ↔ %s' % (len(sh.visible()), pick))
        # 장르를 좁히면 콤보 목록도 좁아진다 — 고를 수 없는 책이 남으면 안 된다
        n_all = len(sh._bk_cb['values'])
        sh._f_gen._all_var.set(False)
        for k, v in sh._f_gen._vars.items():
            v.set(k == 'REV')
        sh._on_genre()
        root.update()
        n_rev = len(sh._bk_cb['values'])
        t('장르를 좁히면 책 목록도 좁아진다', n_rev < n_all, '%d → %d' % (n_all, n_rev))
        t('좁힌 목록에 선택할 수 없는 책이 없다',
          all(len(apply_filters(rows, None, {'REV'}, False, '', sh._bk_map[v])) > 0
              for v in list(sh._bk_cb['values'])[1:]))
        t('사라진 책을 선택한 채로 남지 않는다',
          sh._bk.get() in sh._bk_map, sh._bk.get())
        sh._f_gen._all_var.set(True)
        sh._f_gen._on_all()
        sh._on_genre()
        sh._bk.set(i18n.t('COMMON_ALL', '전체'))
        sh._render()
        root.update()
        t('전체로 되돌아온다', len(sh.visible()) == len(rows))
        # 줄을 고르면 unit_id 가 나간다
        root.update_idletasks()
        first = sh._tv.get_children()[0]
        sh._tv.selection_set(first)
        root.update()
        t('줄을 선택하면 열린다', len(opened) == 1, opened)
        t('나간 것이 그 설교다',
          (not opened) or opened[0] == sh.visible()[0]['unit_id'])
        # 다시 그리는 중에는 안 열려야 한다(delete/insert 가 선택을 낸다)
        n0 = len(opened)
        sh._render()
        root.update()
        t('다시 그려도 헛되이 안 열린다', len(opened) == n0,
          '%d → %d' % (n0, len(opened)))
    finally:
        try:
            root.destroy()
        except Exception:
            pass
    print('selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    a = sys.argv[1:]
    if not a or a[0] == '--selftest':
        sys.exit(0 if _selftest() else 1)
    if a[0] == '--list':
        db = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bible_master.db')
        rows = sort_rows(fetch(db, 'KO'), a[1] if len(a) > 1 else 'bible')
        for r in rows[:40]:
            print('%-9s %-52s %-14s' % (r['ref'], r['title'][:52],
                                          r['src'][:14]))
        print('… 모두 %s편' % '{:,}'.format(len(rows)))
    else:
        print(__doc__)


if __name__ == '__main__':
    main()
