# ★★★ **시작 절차는 run.py 한 곳이다**(2026-10-09 사용자 「바로시작 … 클릭 가능하다고 표시되더라도
#   클릭이 안된다」). 바탕화면 바로가기는 이 파일을 켠다 — 무거운 import 를 하기 **전에**
#   `run.main()` 으로 넘긴다(스플래시가 곧바로 뜨고 · 짓는 동안 클릭을 받고 · 첫 실행 안내도
#   같다). 그쪽이 이 파일을 모듈(`user_main`)로 다시 불러 쓴다(캐시된 바이트코드).
if __name__ == '__main__':
    import run as _run
    _run.main()
    raise SystemExit(0)

import os
import json
import math
import re
import sqlite3
import sys              # ⚠ 끄기 대화·트레이 시작(_ask_close·_start_tray)이 쓴다.
#                         2026-09-03 191차에 그 코드를 넣으면서 이 줄을 빠뜨려
#                         **X 버튼을 눌러도 아무 일이 안 일어났다**(NameError 가
#                         Tk 콜백에서 조용히 삼켜졌다). 지우지 말 것.
# ★★ 구간 판정은 **한 문**이다(§verse_range) — `verse_id` 는 신원이고
#   차례는 `sort_order` 다. 번호로 재면 절체계 이형 구간에서 샌다.
import verse_range as _vr
import appdb
import verse_text as _vt   # ★ 절 본문은 이 문 하나로(합쳐짐·없는절 보완 §verse_text)
import textwrap
import tkinter as tk
import webbrowser
from datetime import datetime
from tkinter import ttk, scrolledtext
import i18n
import ui_theme
ui_theme.guard_listboxes()     # ★ 317차-21 — 목록 아래 빈 곳 클릭은 아무 일도 없다(앱 전체 · docs/1.txt 50-1)
import theme_font
import verse_ref
import bidi
# ⚠ **`tk.Tk()` 를 만들기 전에** 불러야 Tk 가 그 폰트를 인식한다(font.md §13).
#   `fonts/`(번들 · SIL OFL)와 `fonts_user/`(사용자)를 설치 없이 등록한다. 실측 24ms.
try:
    theme_font.load_font_files()
except Exception:
    pass
from p4_tree import BibleP4TreeCanvas
from p4_node_panel import NodePanel
from manual_widget import attach_manual_icon, bind_toggle_hotkey
from map_manager import MapManager
from tkinter import ttk, scrolledtext, messagebox
from note_refr_panel import NoteRefrPanel
from refr_unified_panel import RefUnifiedPanel
from plan_main_view import PlanMainView
from links_panel import LinksPanel
# ⚠⚠⚠ **음성 부품은 여기서 import 하지 않는다** (2026-09-05 사용자 지시
#   「**P1의 버튼들은 클릭할 때 끌어오도록 하라**」).
#   실측 — `voice_play_bar` → `voice_bible` → `sounddevice`(197ms)+`numpy`(82ms)
#   = **290ms**. 앱을 켤 때마다 그 값을 치르는데, 음성은 **단추를 눌렀을 때만**
#   필요하다. ⇒ 아래 property·메서드가 그때 끌어온다.
from entity_browser import EntityBrowserPanel
from figure_tree import FigureTreeCanvas
from genealogy_canvas import GenealogyCanvas
from p1_reading_view import ReadingView
from commentary_panel import CommentaryPanel
from verse_text_list import VerseTextList


def _heb_lang(conn, ver):
    """그 역본이 **히브리어**인가 — 히브리 절 번호를 병기할 자리인가.

    ⚠ 역본 코드를 늘어놓지 않는다(`WLC`·`DHNT`·`SGHNT`…) — 히브리어 역본을
      하나 더 담는 날 반드시 한 곳이 빠진다. **언어 코드로 묻는다.**
    """
    try:
        r = conn.execute('SELECT lang_code FROM bible_version'
                         ' WHERE version_code=?', (ver,)).fetchone()
    except Exception:
        return False
    return bool(r) and (r[0] or '').upper() == 'HE'

# 최근 구절 보관 개수 (2026-08-12 사용자 결정).
# ⚠ **자르는 자리가 시작 복원과 구절 추가 두 곳**이라 숫자를 직접 쓰면 한쪽만 고쳐진다.
#   실제로 그렇게 냈다가 앱을 껐다 켜면 옛 개수로 되돌아갔다 — 그래서 상수로 뽑았다.
# 실측(2026-08-12): 기술적 상한이 없다 — SQLite 변수 32,766 · 저장 500건 10KB ·
#   렌더 500건 49ms. 걸리는 것은 화면 높이뿐이고(행 21px) 스크롤바로 해소된다.
#   100 을 고른 것은 그 이상이면 스크롤로도 못 찾기 때문이다 —
#   많이 쌓인 것은 검색이 되는 「나의 묵상 ▸ 최근 구절」 서브탭이 맡는다.
RECENT_VERSE_MAX = 100
# 팝업이 세로로 차지할 수 있는 최대 픽셀. 이보다 길면 잘라서 스크롤한다.
POPUP_MAX_H = 420
POPUP_MIN_W = 420       # 목록이 짧아도 이보다 좁아지지 않는다(약명만 남고 본문이 잘린다)
POPUP_TEXT_CHARS = 60   # 한 줄에 보일 본문 글자 수. 넘으면 … 로 자른다

# 「구절 연결」 두 화면의 둘째 줄 높이 (2026-08-12 사용자 지적).
# 캔버스는 Journey 바, 트리뷰는 breadcrumb 이 그 자리인데 **25px 대 35px 로 달라서**
# 화면을 갈아탈 때마다 아래 내용이 튀었다. 한 값으로 묶고 둘 다 pack_propagate(False)
# 로 못 박는다 — 캔버스 쪽은 선언만 30 이고 실제로는 자식 높이(25)를 따르고 있었다.
JOURNEY_BAR_H = 30


PANE_MIN = 38      # 패널 최소 크기 ≈ 1cm — 사라지지만 않게 (2026-08-13)


def _C(role, fallback):
    """역할 색 — 팔레트에 없으면 폴백(§0 하드코딩 금지, `font.md` §36)."""
    try:
        import ui_theme
        return ui_theme.C(role) or fallback
    except Exception:
        return fallback




def _ref_lang():
    """구절약명에 쓸 언어 — **성경 역본**을 따른다(표시언어 콤보가 아니다).

    2026-08-15 사용자 지시: 「구절약명은 버전을 바꿀 때에만 바뀌어야 한다」.
    ⚠ `book_names` 에 EL·HE·COP 가 없어 원문 역본(GNT·WLC·COP*)은 **영어**로 떨어진다.
    """
    try:
        import lang_config
        return lang_config.ref_lang()
    except Exception:
        return 'EN'

# ★ 설명문 안에서 「이 구절의 연결」 접힘줄이 들어갈 자리를 가리키는 표식.
#   `_fetch_combined_desc` 가 심고 `p4_node_panel._render_desc` 가 바꿔 끼운다.
#   ⚠ 사람이 읽는 글에 절대 안 나올 글자여야 한다.
FOLD_MARK = '\x00FOLD\x00'


#: ★ `run.py` 가 심는 고리 — **P1 이 준비된 순간** 불린다.
#   스플래시가 이때 「바로 시작」을 켠다(생성자 끝까지 기다리지 않는다).
#: ★★★ **스플래시가 있으면 창을 처음부터 숨긴 채 짓는다** (2026-09-17 사용자 「시작화면이
#:   표시되면서 앱의 메인화면이 반짝 표시되었다가 사라진다」).
#:   ⚠⚠ 그전에는 `MatrixMasterApp()` 이 **다 지어진 뒤에** `withdraw()` 했다. 그런데 짓는 동안
#:     `ON_PROGRESS`(스플래시 `update()`)가 Tcl 이벤트 줄을 돌리므로 그때 본 창이 **화면에
#:     올라갔다가**(Map) 곧 숨는다 — 그것이 「반짝」이다. **숨기는 시점을 생성자 첫 줄로 올린다.**
#:   두 진입점(`run.py` · 이 파일 `__main__`)이 짓기 **전에** 참으로 둔다.
START_HIDDEN = False
ON_P1_READY = None
#: 시작 진행 훅 (2026-09-16 · 1.txt 2·55번) — `run.py` 가 스플래시의 이벤트를
#:   돌리는 함수를 건다. 본체를 짓는 동안(P1 준비 뒤 ~0.3초) 누른 클릭이
#:   **큐에만 쌓여** 「바로 시작이 떠 있는데 안 눌린다」로 보였다. `_mark` 가
#:   단계마다 이것을 불러 그 사이에도 클릭이 먹게 한다.
ON_PROGRESS = None


#: 읽기 조회의 상태 조건 — sys 표를 읽는 자리마다 붙인다(2026-09-09 덮개 전수 조사)
_ST = "COALESCE(record_status,'LIVE')='LIVE'"

class MatrixMasterApp(tk.Tk):
    def __init__(self):
        super().__init__()
        # ★★★ **스플래시가 있으면 여기서 곧바로 숨긴다**(2026-09-17 · 「메인화면이 반짝」).
        #   ⚠ 다 짓고 나서 숨기면 늦다 — 짓는 동안 `ON_PROGRESS` 가 이벤트를 돌리므로
        #     그 순간 창이 화면에 올라간다. 부르는 쪽은 `deiconify()` 를 그대로 쓴다.
        if START_HIDDEN:
            try:
                self.withdraw()
            except Exception:
                pass
        # ★★ **오류 기록 지붕**(2026-08-25 · errlog) — 사용자 PC 에서 난 오류가
        #   남는 유일한 자리다. 그전에는 `print` 로 콘솔에만 나가 **사라졌다**
        #   (실측: `except → print` 340곳 · `except → pass` 710곳 · 지붕 0곳).
        #   ⚠ **맨 앞에 건다** — 뒤에 걸면 그 사이에 난 오류를 놓친다.
        #   ⚠ 여기서 실패해도 앱은 떠야 한다 — 로그가 앱을 죽이면 안 된다.
        try:
            import errlog
            errlog.install(self)
        except Exception as e:
            print('[errlog] %s' % e)
        # 시작 타이밍 계측 — 기본 OFF. 진단 시: 환경변수 STARTUP_TIMING=1 또는 startup_timing.on 파일 생성
        self._timing_on = bool(os.environ.get('STARTUP_TIMING')) or os.path.exists('startup_timing.on')
        import time as _time
        self._t0 = _time.perf_counter()
        self._marks = []
        self._mark('super().__init__')
        self.db_path = appdb.MAIN_DB   # 설치 경로 독립(§appdb.APP_DIR) — CWD 무관
        self.last_clicked_vid = None
        self.is_syncing = False
        self.history_labels = {}
        self.combos = {}
        self.book_map = {}
        self.p1_data: list = []
        self.p1_idx_map: list = []

        # 🎯 [신설] 녹음 상태 및 소유자 관리 변수
        self.is_recording = False
        self.current_recording_item = None
        self.voice_owner = "Me" # 기본 소유자
        
        # 🎯 [신설] 상태 추적을 위한 변수들 초기화
        self.path_mode_var = tk.IntVar(value=1)            # Toggle_off/Multi_path
        self._last_entity_tab = 'tree'   # Tab3/Tab4 마지막 활성 기억

        self._load_app_config()
        # 앱 이름 = Hagah Dabar (2026-08-19 사용자 확정 — 히브리어 하가(묵상하다)
        # + 다바르(말씀). Logos 는 기존 성경 소프트웨어의 상표라 피했다)
        self.title('::: Hagah Dabar :::')
        self.geometry("1600x950")
        # ★ 직전 창 크기·위치(2026-10-10 사용자 「max 상태로 닫고 다시 실행하면 max 상태가
        #   아니다」 — 창 모양을 **저장하는 코드가 아예 없었다**). 최대화는 화면에 나타난 뒤
        #   `restore_window_state` 가 건다(숨긴 채 짓는 동안 걸면 창이 미리 보인다).
        try:
            _g = self._load_state('win_geometry', '')
            _m = re.match(r'^(\d+)x(\d+)\+(-?\d+)\+(-?\d+)$', str(_g or ''))
            if _m:
                _w, _h, _x, _y = (int(v) for v in _m.groups())
                _sw, _sh = self.winfo_screenwidth(), self.winfo_screenheight()
                if _w >= 400 and _h >= 300:
                    # 화면이 바뀌어(모니터를 뺐다 등) 위치가 밖이면 위치는 버린다
                    if -50 <= _x <= _sw - 100 and -10 <= _y <= _sh - 100:
                        self.geometry('%dx%d+%d+%d' % (_w, _h, _x, _y))
                    else:
                        self.geometry('%dx%d' % (_w, _h))
        except Exception:
            pass
        # ★ X 단추도 우리 destroy() 를 타게 한다 — 종료 중 직전값 저장 잠금
        #   (`_closing`)이 걸리려면 파이썬 destroy 가 반드시 불려야 한다.
        # ★★ 2026-09-03 190차 — X 는 **끄기 대화**를 먼저 지난다(완전 종료 /
        #   트레이에 두기). 대화가 destroy 를 부른다.
        self.protocol('WM_DELETE_WINDOW', self._ask_close)
        # ★ 앱 아이콘 — 와인색 성경책에 금색 H(0.txt 3번 · db_make_icons).
        #   ⚠ 아이콘이 없어도 앱은 떠야 한다.
        try:
            # ⚠ `default=` 로 주면 **팝업까지** 같은 아이콘을 쓴다.
            self.iconbitmap(default=appdb.app_path(
                os.path.join('icons', 'app_user.ico')))
        except Exception:
            pass

        # ★ **본체 실행 표식** — 트레이 에이전트가 이것을 보고 「본체가 떠
        #   있으면 아무것도 안 한다」를 지킨다(동시 쓰기 금지). 주기적으로
        #   만져야 비정상 종료 뒤 표식이 영원히 남지 않는다(나이로 판정).
        try:
            import tray_agent as _tray
            _tray.mark_running()
            self._tray_touch()
        except Exception:
            pass

        # 지금 보고 있는 탭을 진한 회색으로 (2026-08-10 사용자 지시).
        # ⚠ 화면마다 고치지 않는다 — `ttk.Style` 은 인터프리터 전역이라 이 한 줄이
        #   P1~P4 와 그 안의 모든 서브탭에 함께 걸린다.
        try:
            import ui_theme
            ui_theme.load(self.db_path)      # 저장된 테마를 먼저 읽는다
            ui_theme.apply_ttk(self)         # 탭·표·입력칸 (탭 색은 이 안에서)
            # ★ 2026-10-21 목록 칸 폭은 사람이 끈 대로(철칙 · tree_cols — 모든 목록에 한 번)
            import tree_cols
            tree_cols.install(self, self.db_path if hasattr(self, 'db_path') else None)
        except Exception as e:
            print(f'[tab style] {e}')
        # ★★★ **검색칸에 들어가면 그 언어로 바로 친다**(2026-09-11 사용자
        #   「사용자가 **KO를 설정하였다면** 검색창에 입력할 때 **기본 언어를
        #   KO로** … 프랑스어 사용자라면 FR로」 · 「**러시아어는 RU 기본세팅**」).
        #   ★ **기본값일 뿐이다** — 사람이 한/영을 바꾸면 그 칸에서는 그대로 간다.
        #   ⚠ 문은 하나다(`ime_hint.attach_class`) — 화면마다 붙이면 빠뜨린다.
        try:
            import ime_hint
            import i18n as _i18n_ime
            ime_hint.attach_class(self, lambda: _i18n_ime.get_lang())
        except Exception as _e_ime:
            print('[입력기] %s' % _e_ime)
        
        self._mark('before setup_ui')
        self.setup_ui()
        self._mark('after setup_ui')
        # ★ 저장된 테마를 **다 만든 뒤** 화면에 칠한다 (2026-08-13).
        # ⚠ 첫 페인트를 늦추지 않도록 유휴에 미룬다 — 위젯이 다 있어야 훑을 수 있다(§29).
        self.after_idle(self._paint_theme)
        # ★ 저장된 「기본」 크기를 **다 만든 뒤** 화면에 입힌다 (font.md §22).
        # ⚠ 첫 페인트를 늦추지 않도록 유휴에 미룬다 — 위젯이 다 있어야 훑을 수 있다(§29).
        self.after_idle(self._scale_fonts)
        # ★ **지연 빌드된 탭까지 따라오게 한다** (2026-08-14 사용자 지적).
        #   위 한 번은 「지금 있는 위젯」만 훑는다. 묵상플랜·도서/설교는 그때
        #   아직 없어서 영영 설정을 안 따랐다. 테마 색과 같은 고리를 폰트에도 건다.
        self.bind_all('<<NotebookTabChanged>>', self._scale_new_tab, add='+')
        # ★ **내용을 다시 그릴 때 생기는 위젯까지** (2026-08-14). 탭 고리만으로는
        #   못 잡는다 — 콤보의 닫힌 칸이 작게 남던 것이 이 경우였다.
        self.bind_all('<Map>', self._scale_on_map, add='+')
        # ★★ **창을 작업표시줄 위로**(2026-09-29 299차-2 · 사용자 「대화입력창이 없다」).
        #   윈도우는 요청 크기(1600x950)를 **화면** 높이로만 조이고 **작업 영역**은 안 본다 —
        #   실측 1536x864 화면 · 작업 영역 아래 816 인데 창 아래가 873 이라 **맨 아래 57px 가
        #   작업표시줄 밑에 묻혔다**. P4 맨 아래 칸(AI 도우미 입력 칸)이 그 자리였다.
        #   첫 <Map> 뒤 한 번만 잰다 — 창이 그려진 뒤라야 제목 띠·테두리 두께를 알 수 있다.
        self.bind('<Map>', self._fit_to_workarea, add='+')
        self.after_idle(self._ensure_indexes)     # 없으면 화면이 느려지는 인덱스
        self.after_idle(self._dump_marks)       # 첫 유휴(≈첫 페인트) 시점에 타이밍 기록
        self.after(500, self.initiate_explorer_from_db)
        self.dash_show_all_lang = tk.BooleanVar(value=False)
        self.v_pw.bind("<ButtonRelease-1>", lambda e: self._save_state("p1_height", self.top_pw.winfo_height()), add="+")
        self.top_pw.bind("<ButtonRelease-1>", lambda e: self._save_state("p1_width", self.p1_f.winfo_width()), add="+")
        # 매뉴얼 화면코드 토글 단축키 (Ctrl+H) — 모든 매뉴얼 아이콘 옆에 코드 라벨 표시/숨김
        bind_toggle_hotkey(self, '<Control-h>')
        self._usage_bootstrap()   # 익명 이용통계: 동의 확인 + 세션 시작

    def _scale_fonts(self, widget=None, only_new=False):
        """박힌 글꼴·크기를 저장된 설정 기준으로 다시 잡는다.

        ⚠ 설정이 기본값 그대로면 바뀌는 것이 없으므로 훑지 않는다 — 시작이 느려진다.
          ★ **크기만 보고 판단하면 안 된다** (2026-08-14). 크기는 10 그대로 두고
            글꼴 이름만 바꾼 경우가 흔한데, 그때 이 가드가 통째로 막고 있었다.
        ★ `only_new=True` = 탭 전환·Map 고리 전용(새 위젯만 — 2026-08-27).
          설정 저장·시작의 전체 재기는 기본값(False)으로 부른다.
        """
        try:
            if not self._font_scale_needed():
                return
            theme_font.scale(widget if widget is not None else self,
                             self.db_path, only_new=only_new)
        except Exception as e:
            print(f'[font scale] {e}')

    _font_need = None        # None = 아직 안 봄

    # ── 인덱스 보장 ───────────────────────────────────────────────────────────
    # ★ 없으면 **화면이 느려지는** 인덱스만 여기 둔다 (2026-08-14 사용자 지적
    #   「이렇게 개발하면 앱의 속도를 느리게 하는 것 아닌가?」 — 맞는 지적이었다).
    #
    #   `sys_book_unit_text` 에 인덱스가 **하나도 없었다.** 그 표는 `body_text` 가
    #   커서 한 줄 찾자고 6,016줄 12MB 를 훑는다 — 실측 **74.75ms**.
    #   `unit_id` 인덱스 하나로 **0.01ms** 가 됐다(7,000배).
    #
    # ⚠ `bible_master.db` 는 콘텐츠 갱신 때 **통째로 교체**된다(§1). 그러면 인덱스도
    #   함께 사라지므로, 스크립트로 한 번 만들어 두는 것으로는 부족하다.
    #   시작할 때 **있으면 0.03ms, 없으면 13ms** 로 보장한다.
    # ⚠ **안 쓰이는 인덱스는 넣지 말 것.** `sys_pericope_asset(start_vid,end_vid)` 를
    #   만들어 보았더니 SQLite 가 `idx_sys_peri_type` 을 골라 쓰지 않았다 —
    #   쓰기 비용과 자리만 늘었다. `EXPLAIN QUERY PLAN` 으로 확인하고 넣는다.
    _INDEXES = (
        ("idx_book_unit_text_unit",
         "CREATE INDEX IF NOT EXISTS idx_book_unit_text_unit "
         "ON sys_book_unit_text(unit_id)"),
    )

    def _ensure_indexes(self):
        try:
            with appdb.connect(self.db_path) as conn:
                for _name, sql in self._INDEXES:
                    conn.execute(sql)
                conn.commit()
        except Exception as e:
            print(f'[index] {e}')

    def _font_scale_needed(self):
        """설정이 화면에 무언가를 바꿀 만한가.

        ⚠ **결과를 기억한다.** `<Map>` 마다 불리는데 여기서 `load()` 를 하면
          위젯 하나 올라올 때마다 SQLite 를 연다 — 시작할 때만 수백 번이다.
          설정이 바뀌는 곳은 `_apply_reading_font` 하나이므로 거기서 지운다.
        """
        if self._font_need is not None:
            return self._font_need
        try:
            d = theme_font.load(self.db_path)['font']
            need = bool((d.get('base') or {}).get('family')
                        or (d.get('ui') or {}).get('family'))
            if not need:
                need = (theme_font.resolve(self.db_path, 'ui')['size']
                        != theme_font.REF_SIZE)
        except Exception:
            need = False
        self._font_need = need
        return need

    def _scale_new_tab(self, ev=None):
        """탭이 바뀌면 그 안쪽 글꼴을 다시 잡는다 — **지연 빌드된 화면을 위해.**

        ★ 왜 필요한가 (2026-08-14 사용자 지적 「오늘 묵상완료 ~ 중단 까지의 모든
          글자가 통합폰트 관리화면의 영향을 받지 않는다」).
          시작 때 `_scale_fonts` 가 한 번 훑지만 그 시점에 묵상플랜·도서/설교 탭은
          **아직 만들어지지도 않았다**(§29 지연 빌드). 나중에 생긴 위젯은 화면에
          박힌 값(맑은 고딕 9)을 그대로 안고 태어나 영영 설정을 안 따랐다.
          ⚠ 테마 색은 `_paint_new_tab` 으로 이미 이 문제를 풀어 두었는데
            **폰트 쪽에는 같은 고리가 없었다.** 같은 함정을 두 번 만난 것이다.
        """
        try:
            if not self._font_scale_needed():
                return
            # ★ Map 배치와 **같은 예약**을 쓴다 (2026-08-27 「P1 탭 깜빡」 수리).
            #   탭 전환 한 번에 이 고리+Map 배치가 겹쳐 훑기가 4번 돌고 있었다 —
            #   어차피 둘 다 「새 위젯만」(only_new) 훑으므로 한 번이면 된다.
            if self._map_after is None:
                self._map_after = self.after_idle(self._flush_map_scale)
        except Exception:
            pass

    # ── 늦게 태어나는 위젯 ────────────────────────────────────────────────────
    _map_after = None

    def _scale_on_map(self, ev=None):
        """**새로 화면에 올라온 위젯**도 설정을 따르게 한다 (2026-08-14 사용자 지적
        「콤보상자를 클릭하기 전에 표시되는 글자 크기는 통합폰트의 영향을 받지 않고,
        클릭해서 나타나는 값은 정상이다」).

        ★ 왜 그렇게 보였나 — 원인을 실측으로 잡았다.
          콤보의 **닫힌 칸**은 그 위젯 자신의 `-font` 로 그린다. 그런데 화면이
          데이터를 읽으며 **그때 만드는** 콤보(도서 판 고르개 등)는 시작·탭전환·설정
          저장 어느 시점에도 없어서 `scale()` 을 한 번도 못 받고, 박힌 값(`8pt`)을
          그대로 안고 태어난다.
          반면 **펼친 목록**은 별개 위젯이라 `TkDefaultFont` 를 쓰는데, 그것은
          `apply_ui` 가 이미 바꿔 놓았다. ⇒ **닫으면 작고 열면 크다.**
          실측 — 기본을 「궁서 16」으로 두고 그 뒤에 만들어진 판 콤보는 `{} 8`(굴림 8),
          같은 순간 `TkDefaultFont` 는 궁서 16.

        ⚠ **탭 전환 고리(`_scale_new_tab`)만으로는 못 잡는다.** 그것은 탭이 바뀔 때
          한 번이고, 여기서 문제가 되는 위젯은 **탭 안에서 내용을 다시 그릴 때** 생긴다.
        ⚠ `<Map>` 은 위젯 하나마다 터진다 — 화면 하나를 짓는 동안 수백 번이다.
          그래서 **미뤄 모았다가 한 번만** 훑는다(`after` 로 debounce). 설정이 기본값
          그대로면 아무 일도 하지 않으므로 평소에는 비용이 0이다.
        """
        try:
            if not self._font_scale_needed():
                return
            if self._map_after is not None:
                return                      # 이미 예약돼 있다 — 모아서 한 번만
            # ⚠ **벽시계(`after(ms)`)가 아니라 유휴(`after_idle`)로 미룬다.**
            #   화면 하나를 짓는 동안 `<Map>` 이 수백 번 터지는데, 유휴는 그 다발이
            #   끝난 **직후**에 딱 한 번 돈다. 밀리초로 잡으면 빌드가 그보다 오래
            #   걸릴 때 중간에 돌고, 짧게 끝나면 한참 뒤에 도는 등 어긋난다.
            self._map_after = self.after_idle(self._flush_map_scale)
        except Exception:
            pass

    def _flush_map_scale(self):
        """창 전체를 **한 번** 훑는다.

        ★ 「올라온 가지만 훑기」를 만들어 재 보았다가 **버렸다** (2026-08-14).
          한 다발에 위젯이 수백 개 올라오므로 조상 걸러내기와 `winfo_exists` 왕복이
          붙어 오히려 **2배 이상 느렸다** — 실측 257ms → 602ms(한 번 최대 98ms).
          전체 훑기는 한 번 11ms 로 고르다. **머리로 짐작하지 말고 재 볼 것.**
        ⚠ 설정이 기본값이면 `_scale_on_map` 이 여기까지 오지도 않는다.
        """
        self._map_after = None
        # ★ 새로 올라온 위젯만 — 이미 잰 것은 표식으로 건너뛴다(2026-08-27)
        self._scale_fonts(only_new=True)

    def _paint_theme(self):
        """저장된 화면 색을 지금 떠 있는 위젯에 입힌다.

        ⚠ 나중에 만들어지는 화면(지연 빌드 탭)은 이 시점에 없다 — 그때는 그 화면이
          만들어질 때의 색(밝은 기본)으로 남는다. **탭을 열 때 다시 칠해야 한다.**
        """
        try:
            import ui_theme
            # ★ **새로 뜨는 팝업에도 테마를 입힌다** (2026-08-16 사용자 지적
            #   「기적묵상 팝업에 배경색 표준을 안 따르는 부분이 있다」).
            #   실측 — 팝업의 창 바탕·캔버스가 `SystemButtonFace` 로 남는다.
            #   ⚠ **아래 early return 보다 위**에 둔다. 기본 테마에서도 `#F0F0F0` 는
            #     팔레트 `bg` 와 다르다.
            #   ⚠ 팝업 파일 20개를 고치지 않는다 — 여기 한 곳이면 앞으로 만들 팝업까지
            #     저절로 따라온다(사용자 앱 팝업 20개 중 스스로 거는 것은 2개뿐이었다).
            self.bind_all('<Map>', self._adopt_popup, add='+')
            if ui_theme.current() == ui_theme.DEFAULT:
                return                      # 기본이면 지금 색 그대로다 — 훑을 것 없다
            ui_theme.paint(self)
            # ★ 나중에 만들어지는 탭까지 따라오게 한다. 탭을 처음 열면 그 안의 위젯이
            #   그때 생기므로 여기서 한 번 더 칠한다.
            # ⚠ 핸들러 안에서 **동기로 무거운 일을 하지 않는다**(§29) — `after_idle` 로 미룬다.
            self.bind_all('<<NotebookTabChanged>>', self._paint_new_tab, add='+')
            # ★ **누른 뒤에도 다시 칠한다** (2026-08-13 사용자 지적
            #   「버튼이 여러개 있을 때 색상 반전기능이 모두 문제다」).
            #   고른 버튼을 표시하는 흔한 방법이 누를 때 `config(bg=...)` 로 색을
            #   갈아 끼우는 것인데, 그 값은 화면에 박힌 밝은 색이다. 화면마다
            #   고치는 대신 **누른 뒤 한 번 더 훑어** 테마 색으로 번역한다.
            #   ⚠ 되돌리는 것이 아니다 — `_orig` 가 새 색을 원본으로 받아들이므로
            #     고른 버튼과 안 고른 버튼이 **다른 역할**로 갈린다.
            self.bind_all('<ButtonRelease-1>', self._paint_after_click, add='+')
        except Exception as e:
            print(f'[theme paint] {e}')

    def _paint_built(self, key=None):
        """**지연 빌드가 끝난 자리를 그 자리에서 칠한다** (2026-08-30).

        ⚠⚠ 그전에는 탭 전환 고리(`_paint_new_tab`)에만 기댔는데, **무거운 화면은
          그 고리의 250ms 뒤늦은 재칠보다 늦게 지어진다** — 실측으로 역본비교의
          스크롤바가 `SystemButtonFace`·`SystemScrollbar` 인 채로 남았다(사용자
          신고 「스크롤 바 역시」). 표에는 그 이름 색이 **있었다** — 아무도 그
          위젯을 방문하지 않았을 뿐이다.
        ⇒ **다 짓고 그 자리를 칠한다.** 연결 작업대·「다음 단계」 줄·참조사이트
          팝업에 쓴 것과 같은 처방이고, 이제 지연 탭 전부가 그 규칙을 따른다.
        """
        try:
            import ui_theme
            if ui_theme.current() == ui_theme.DEFAULT:
                return
            w = self
            if hasattr(key, 'winfo_children'):
                w = key
            self.after_idle(lambda t=w: ui_theme.paint(t))
            self.after(250, lambda t=w: ui_theme.paint(t))
        except Exception as e:
            print('[paint built] %s' % e)

    def _paint_after_click(self, ev=None):
        """누른 자리 **둘레만** 다시 칠한다 — 색을 갈아 끼우는 버튼들을 위해.

        ⚠ 창 전체를 훑으면 클릭마다 수천 개를 도느라 굼떠진다. 누른 위젯의
          **두 칸 위 조상**까지만 본다 — 버튼 묶음 하나가 대개 그 안에 든다.
        ⚠ 핸들러 안에서 바로 하지 않는다(§29) — 화면이 색을 바꾸는 것이
          이 이벤트 **뒤**일 수 있어 `after_idle` 로 미룬다.
        """
        try:
            import ui_theme
            if ui_theme.current() == ui_theme.DEFAULT:
                return
            w = getattr(ev, 'widget', None)
            if w is None or not hasattr(w, 'winfo_children'):
                return
            for _ in range(2):
                p = getattr(w, 'master', None)
                if p is None:
                    break
                w = p
            # ⚠ **유휴 한 번으로는 늦다.** 화면이 누른 뒤 `after(...)` 로 목록을 다시
            #   그리며 버튼 색을 그때 칠하는 경우가 있다 — 주요용어 유형 버튼이
            #   그래서 「전체」만 흰 채로 남았다(2026-08-13 사용자 지적).
            #   유휴에 한 번, 잠깐 뒤에 한 번 더 훑는다.
            self.after_idle(lambda t=w: ui_theme.paint(t))
            self.after(180, lambda t=w: ui_theme.paint(t))
        except Exception:
            pass

    def _paint_new_tab(self, ev=None):
        """탭이 바뀌면 그 탭 안쪽만 다시 칠한다 — 지연 빌드된 화면을 위해.

        ⚠ **유휴 한 번으로는 늦는 화면이 있다** (2026-08-19 실측 — P4 [▶ 보기]
          점프 직후 도서/설교 트리: 유휴 paint 시점에 트리가 아직 비어 있어
          Treeview 태그 번역이 안 걸렸다. 채움은 그 뒤라 하드코딩 색이 남는다).
          `_paint_after_click` 과 같은 이유로 잠깐 뒤 한 번 더 훑는다."""
        try:
            import ui_theme
            if ui_theme.current() == ui_theme.DEFAULT:
                return
            w = getattr(ev, 'widget', None)
            # ★ `only_new` (2026-08-27 사용자 신고 「P1 탭이 깜빡하며 느려졌다」)
            #   — 전환마다 전체 재칠(실측 ~160ms×2회)이 원인이었다. 이 고리의
            #   몫은 **지연 빌드로 새로 생긴 위젯**뿐이므로 표식 없는 것만 칠한다.
            #   화면이 색을 갈아 끼운 옛 위젯은 클릭 고리·전체 칠(시작/설정)의 몫.
            self.after_idle(lambda: ui_theme.paint(
                w if w is not None else self, only_new=True))
            self.after(250, lambda: ui_theme.paint(
                w if w is not None else self, only_new=True))
        except Exception:
            pass

    def _usage_bootstrap(self):
        """익명 이용통계 초기화 — 스키마 보장 후 첫 페인트 뒤 동의 확인/세션 시작."""
        try:
            import usage_stats
            usage_stats.init()
        except Exception:
            return
        try:
            import appdb, user_feedback
            with appdb.connect(self.db_path) as _c:
                self._app_ver = user_feedback.app_version(_c)
        except Exception:
            self._app_ver = "1.0"
        self.after(900, self._usage_consent_session)

    def _usage_consent_session(self):
        try:
            import usage_stats, consent_text
        except Exception:
            return
        av = getattr(self, "_app_ver", "1.0")

        def _go():
            usage_stats.start_session(av, getattr(self, "lang", ""), getattr(self, "ver", ""))
            self._usage_test_timer(av)   # [테스트] USAGE_TEST_INTERVAL 설정 시에만 동작

        if usage_stats.has_consent() is None:
            def _on(agreed):
                usage_stats.set_consent(agreed)
                # 동의/거부 결정을 식별자 없이 익명 집계(동의율 파악, 약관 고지됨)
                usage_stats.report_consent_choice(agreed, getattr(self, "lang", ""), av)
                _go()
            try:
                consent_text.show_first_run_dialog(self, getattr(self, "lang", "KO"), _on)
            except Exception:
                _go()
        else:
            _go()

    def _usage_test_timer(self, app_ver):
        """[테스트 전용] 환경변수 USAGE_TEST_INTERVAL(초) 설정 시 그 주기로 '현재 월' 즉시 전송.
        예: USAGE_TEST_INTERVAL=300 python user_main.py (5분). 미설정 시 동작 안 함(프로덕션 무영향)."""
        import os
        iv = os.environ.get('USAGE_TEST_INTERVAL')
        if not iv:
            return
        try:
            ms = max(10, int(iv)) * 1000
        except Exception:
            return

        def _tick():
            try:
                import usage_stats
                usage_stats.flush_current(app_ver, getattr(self, 'lang', ''), getattr(self, 'ver', ''))
            except Exception:
                pass
            self.after(ms, _tick)

        self.after(ms, _tick)

    def _mark(self, label):
        """시작 단계 타이밍 기록(진단용, 기본 OFF). 단계마다 즉시 로그 append → 중간에 멈춰도 진행 남김."""
        try:
            if callable(ON_PROGRESS):
                ON_PROGRESS()          # 스플래시 클릭이 그 사이에도 먹게(2026-09-16)
        except Exception:
            pass
        if not getattr(self, '_timing_on', False):
            return
        try:
            import time as _time
            dt = _time.perf_counter() - self._t0
            self._marks.append((label, dt))
            mode = 'w' if len(self._marks) == 1 else 'a'
            with open('startup_timing.log', mode, encoding='utf-8') as f:
                f.write(f"+{dt:6.2f}s  {label}\n")
        except Exception:
            pass

    def _dump_marks(self):
        """누적 시작 타이밍을 startup_timing.log + 콘솔에 출력(첫 페인트 직후 1회, 기본 OFF)."""
        if not getattr(self, '_timing_on', False):
            return
        try:
            self._mark('first idle (≈first paint)')
            lines = [f"  +{t:6.2f}s  {label}" for label, t in self._marks]
            txt = "=== startup timing ===\n" + "\n".join(lines) + "\n"
            print(txt)
            with open('startup_timing.log', 'w', encoding='utf-8') as f:
                f.write(txt)
        except Exception:
            pass

    def _on_refs_branch_manual(self, key):
        """연구자료 갈래가 바뀌면 매뉴얼 단추가 가리키는 화면도 바뀐다."""
        ic = getattr(self, '_refs_manual', None)
        if ic is not None:
            try:
                ic.set_screen_code(self._REF_MANUAL.get(key, 'U_P4_R_LIST'))
            except Exception as e:
                print(f'[manual refs branch] {e}')

    def _manual_at(self, bar, screen_code, padx=(4, 6)):
        """매뉴얼 단추 [M] 을 그 줄 **오른쪽 끝**에 (2026-08-22).

        ★ 자리 규칙 하나 — **그 화면 상단 줄의 맨 오른쪽**. 주요용어·도서/설교가
          이미 그렇게 하고 있어 새 규칙이 아니다.
        ⚠ 붙이는 곳이 늘어날수록 손으로 베끼면 자리가 갈린다 — 한 함수로 모은다.
        """
        try:
            ic = attach_manual_icon(
                bar, screen_code,
                lang_provider=lambda: getattr(self, 'lang', 'KO'))
            ic.pack(side='right', padx=padx)
            return ic
        except Exception as e:
            print(f'[manual {screen_code}] {e}')
            return None

    def _tlog(self, label):
        """[진단] 시작 후 경과시간 로그(STARTUP_TIMING 시에만)."""
        if getattr(self, '_timing_on', False):
            import time as _t
            print(f'[T +{_t.perf_counter() - self._t0:6.2f}s] {label}', flush=True)

    def _work_area(self):
        """작업표시줄을 뺀 화면 자리 (l, t, r, b). 못 읽으면 화면 전체.

        ⚠ `SystemParametersInfoW(SPI_GETWORKAREA)` 는 이 프로세스의 DPI 인식과 같은 좌표계로
          돌아온다(Tk 좌표와 같은 자리) — 배율 1.25 에서 실측 (0,0,1536,816).
        """
        try:
            import ctypes
            class _R(ctypes.Structure):
                _fields_ = [('l', ctypes.c_long), ('t', ctypes.c_long),
                            ('r', ctypes.c_long), ('b', ctypes.c_long)]
            r = _R()
            if ctypes.windll.user32.SystemParametersInfoW(0x30, 0, ctypes.byref(r), 0):
                if r.r > r.l and r.b > r.t:
                    return int(r.l), int(r.t), int(r.r), int(r.b)
        except Exception:
            pass
        return 0, 0, self.winfo_screenwidth(), self.winfo_screenheight()

    def _fit_to_workarea(self, ev=None):
        """첫 표시 뒤 한 번 — 창 바깥 테두리가 작업 영역을 넘으면 그만큼 조인다.

        ⚠ `<Map>` 은 자식 위젯에서도 올라온다 — 이 창 자신일 때만.
        ⚠ 저장값이 아니라 **지금 창**만 조인다(§258차 ⑰ 과 같은 원칙 — 쓰는 순간만).
        """
        if ev is not None and ev.widget is not self:
            return
        if getattr(self, '_wa_fitted', False):
            return
        self._wa_fitted = True
        self.after(60, self._fit_to_workarea_now)

    def _save_window_state(self):
        """닫기 직전 — 최대화 여부와 (보통 상태면) 창 크기·위치를 적는다.
        ⚠ 최대화 상태의 `geometry()` 는 화면 전체 크기라 **보통 크기를 덮지 않는다**."""
        try:
            zoomed = (self.state() == 'zoomed')
            self._save_state('win_state', 'zoomed' if zoomed else 'normal')
            if not zoomed and self.state() == 'normal':
                self._save_state('win_geometry', self.geometry())
        except Exception as e:
            self._quiet('[win state] %s' % e)

    def restore_window_state(self):
        """앱이 화면에 나타난 뒤(run.main) — 최대화로 닫았으면 다시 최대화한다."""
        try:
            if self._load_state('win_state', 'normal') == 'zoomed':
                self.state('zoomed')
        except Exception as e:
            self._quiet('[win state] %s' % e)

    def _fit_to_workarea_now(self):
        try:
            if self.state() == 'zoomed':
                return                   # 최대화는 윈도우가 작업 영역에 맞춘다
            l, t, r, b = self._work_area()
            for _ in range(3):
                m = re.match(r'(\d+)x(\d+)([+-]\d+)([+-]\d+)', self.geometry())
                if not m:
                    return
                w, h, gx, gy = (int(m.group(i)) for i in (1, 2, 3, 4))
                rx, ry = self.winfo_rootx(), self.winfo_rooty()
                top = max(0, ry - gy)            # 제목 띠 + 위 테두리
                side = max(0, rx - gx)           # 옆 테두리 — 아래 테두리도 이만큼으로 본다
                nx, ny = max(l, gx), max(t, gy)
                nw = min(w, (r - l) - 2 * side)
                nh = min(h, (b - ny) - top - side)
                if nw < 400 or nh < 300:         # 화면이 그보다 작으면 손대지 않는다
                    return
                if (nw, nh, nx, ny) == (w, h, gx, gy):
                    return
                self.geometry('%dx%d+%d+%d' % (nw, nh, nx, ny))
                self.update_idletasks()
        except Exception:
            pass

    def _fit_px(self, v, axis='w', ratio=0.80):
        """저장된 픽셀 값을 **이 화면에 맞게** 조인다.

        ⚠ 저장값을 고치지 않는다 — 큰 화면으로 돌아가면 그대로 되살아난다.
          조이는 것은 **쓰는 순간**뿐이다.
        ⚠ 화면 크기를 못 읽으면 그냥 둔다(조용히 0 으로 만들지 않는다).
        """
        try:
            lim = int((self.winfo_screenwidth() if axis == 'w'
                       else self.winfo_screenheight()) * ratio)
        except Exception:
            return v
        return max(PANE_MIN, min(int(v), lim)) if lim > PANE_MIN else v

    def _load_app_config(self):
        """[수리] DB 설정과 JSON의 UI 기하학/선택 상태를 통합 로드합니다."""
        conn = appdb.connect(self.db_path)
        cur = conn.cursor()
        self.lang = self._get_cfg_val(cur, 'user_lang', 'KO')
        # 설명문 표시 언어(전역 공유) — 미설정 시 UI 언어로 초기화(콤보/렌더 일관)
        try:
            import verse_tier
            verse_tier._migrate(conn)          # 옛 이름(DESC_LANG)을 한 번 옮긴다
            if not cur.execute("SELECT 1 FROM user_config WHERE config_key='LANGSEL_DESC'").fetchone():
                verse_tier.set_desc_lang(conn, self.lang)
        except Exception:
            pass
        self.ver = self._get_cfg_val(cur, 'v1_code', 'KRV')
        _vrow = cur.execute(
            "SELECT coverage_scope, versification_system FROM bible_version WHERE version_code=?",
            (self.ver,)
        ).fetchone()
        self._ver_coverage      = _vrow[0] if _vrow else 'FULL'
        self._ver_versification = _vrow[1] if _vrow else 'MT'
        conn.close()
        i18n.load(self.db_path, self.lang)

        # 1. 배치 규격 로드 (cfg_... 항목 전수 조사)
        self.cfg_start_x = int(self._load_state("cfg_start_x", 300))
        # 기본 300 — 설정 선택지(300~700)와 정합 (2026-09-01 0.txt 2번. 저장값은 그대로)
        self.cfg_h_gap = int(self._load_state("cfg_h_gap", 300))
        self.cfg_v_gap = int(self._load_state("cfg_v_gap", 210))
        self.cfg_box_limit = int(self._load_state("cfg_box_limit", 3))
        # cfg_box_width 폐지 (2026-09-01 0.txt 2번) — 폭은 _p4_body_chars 가 자동 산출
        self.cfg_font_size = int(self._load_state("cfg_font_size", 9))
        self.cfg_line_bold = int(self._load_state("cfg_line_bold", 1))
        self.cfg_font_family = str(self._load_state("cfg_font_family", "Malgun Gothic"))
        # ★ **렌즈노드 박스 규격** (2026-08-20 사용자 지시 — 「구절박스는 규격이
        #   정해져 있어 조절할 필요가 없지만, 렌즈노드 박스는 이름 길이가 서로
        #   달라 조절해야 한다」). 한 축을 정하면 **나머지는 글자에서 계산**된다:
        #   · 'H' 높이 기준 — 줄 수를 정하면 **폭은 자동**(글자 수 ÷ 줄 수)
        #   · 'W' 폭 기준  — 글자 수를 정하면 **높이(줄 수)는 자동**
        #   기본 1줄 = 예전 화면 그대로.
        self.cfg_node_mode = str(self._load_state("cfg_node_mode", "H")).upper()
        self.cfg_node_lines = int(self._load_state("cfg_node_lines", 1))
        self.cfg_node_chars = int(self._load_state("cfg_node_chars", 14))

        # 2. 모드별 DESC 높이 로드
        self.p4_desc_h_normal = int(self._load_state("p4_desc_h_normal", 200))
        self.p4_desc_h_focus = int(self._load_state("p4_desc_h_focus", 400))
        self.p4_desc_height = self.p4_desc_h_normal 

        # 3. 화면 기하학 및 선택 상태 복구
        self.active_node_id = int(self._load_state("last_verse_id", 1))
        self._migrate_p4_tab_numbers()      # 리포트 탭 폐지에 따른 번호 이주(1회)
        # ⚠ **읽기 전에 이주한다** — 읽고 나서 고치면 이번 판은 옛 번호로 연다
        #   (옛 이주 `_migrate_p4_tab_numbers` 는 바로 위에서 이미 불렸다).
        try:
            self._migrate_p4_tab_20260926()
        except Exception:
            pass
        try:
            self._migrate_p4_tab_20261007()
        except Exception:
            pass
        try:
            self._migrate_p1_tab_20260926()
        except Exception:
            pass
        self.last_p4_tab_idx = int(self._load_state("last_p4_tab", 0))
        # ★ 화면에 견주어 조인다 — 큰 화면에서 저장한 값이 작은 노트북에서
        #   옆 칸을 0 으로 만들면 안 된다(2026-09-17). 값은 안 고친다.
        self.p1_height = self._fit_px(
            int(self._load_state("p1_height", 350)), 'h', 0.70)
        self.p1_width = self._fit_px(
            int(self._load_state("p1_width", 1100)), 'w', 0.80)
        # (구) 트리뷰 탭의 좌측 폭. 2026-08-12 통합으로 그 PanedWindow 가 없어졌고,
        # 폭은 NodePanel 이 자기 것을 따로 기억한다(`P4_NODE_PANEL_WIDTH`).
        # 저장값은 남아 있어도 무해하므로 읽기만 남긴다.
        self.p4_t2_left_width = int(self._load_state("p4_t2_left_width", 1000))
        self.last_book = str(self._load_state("last_book", ""))
        self.last_chap = str(self._load_state("last_chap", "1"))
        self.last_scope_t1 = int(self._load_state("last_scope_t1", 1))
        self.last_scope_t2 = int(self._load_state("last_scope_t2", 1))
        # 🎯 [신설] 경로 유지 모드 로드 (1: Toggle_off, 2: Multi_path)
        self.path_mode = int(self._load_state("path_mode", 1))
        # 🎯 [신설 2026-06-01] VERS_VERS 연결유형 등급 필터 (A=핵심 / AB=+확장 / ABC=+참조)
        # 기본값 = **핵심(A)** (2026-08-20 사용자 확정 — 「초기값: 구절, 핵심, 토글」)
        self.link_tier_filter = str(self._load_state("link_tier_filter", "A"))
        if self.link_tier_filter not in ("A", "AB", "ABC"):
            self.link_tier_filter = "AB"
        self.last_reading = self._load_state("last_reading", {})

    def _get_cfg_val(self, cur, key, default):
        """[헬퍼] user_config에서 안전하게 값을 추출합니다."""

        cur.execute("SELECT config_val FROM user_config WHERE config_key = ?", (key,))
        row = cur.fetchone()
        return row[0] if row else default

    # ── 오늘의 말씀 카드 ──────────────────────────────────────────────────────

    # ★ **최상단 「오늘의 말씀」 배너와 광고 예약 공간을 없앴다 (2026-08-15 사용자 지시).**
    #   높이 78px 을 첫 화면에서 늘 먹고 있었고, 광고 칸은 자리만 잡은 채 비어 있었다.
    #   배너 광고는 나중에 **P1 전담 탭**으로 간다(§21-6 CDN 재사용, 0건이면 탭을 안 만든다).
    #   ⓘ 출처·라이선스 버튼도 함께 뺐다 — 같은 내용이 지원/설정 ▸ 정보에 있다.
    #
    # ⚠ **배너에 딸려 있던 일이 하나 있다.** 배너가 오늘의 구절을 고르면서 **다음 실행
    #   스플래시용 캐시**(`splash/bg.png`·`splash_verse.json`)를 함께 갱신하고 있었다(§34).
    #   배너만 지우면 시작화면 구절이 첫 실행 이후 영영 안 바뀐다. 그래서 그 일만
    #   `_refresh_splash_cache` 로 떼어 남겼다 — 화면에 아무것도 그리지 않는다.

    def _refresh_splash_cache(self):
        """다음 실행 스플래시용 캐시 갱신 — 구절 + 랜덤 활성 사진. 비차단·실패 무해."""
        hl = self._get_banner_verse()
        if not hl:
            return
        vid, text, book, chap, verse = hl
        try:
            import splash_screen
            # ⚠ 스플래시는 앱보다 **먼저** 뜨므로 i18n(DB)을 못 연다 —
            #   지금 언어로 다음 실행의 단추 글자를 함께 적어 둔다.
            splash_screen.save_today_verse(
                f"{book} {chap}:{verse}", text,
                wait_text=i18n.t('SPL_WAIT', '준비 중…'),
                go_text=i18n.t('SPL_GO', '바로 시작 ▸'))
            with appdb.connect(self.db_path) as _sc:
                # ★ **구절을 함께 넘긴다** — 그래야 그 구절의 장면에 어울리는
                #   사진이 골라진다(2026-09-05 · db_splash_scene).
                splash_screen.refresh_photo_cache(
                    _sc, verse_id=vid,
                    lang=(i18n.get_lang() or 'KO'))
                # ★ 홍보 배너도 같은 자리에서 — 스플래시는 DB 도 망도 안
                #   건드리므로(§34) **다음 실행**이 읽을 캐시를 적어 둔다.
                # ⚠ 인자는 **DB 경로**다(`ads` 가 경로로 연다) — 연결 객체가
                #   아니다. 고를 것이 없으면 그 문이 캐시를 스스로 걷는다.
                splash_screen.refresh_banner_cache(
                    self.db_path, lang=(i18n.get_lang() or 'KO'))
        except Exception:
            pass

    def _get_banner_verse(self):
        """배너 표시 구절 선택 — 사용자 구절 즐겨찾기(user_favorite VERSE) + 관리자 추천
        (sys_verse_highlight FEATURED)을 **합쳐서 매 실행 랜덤**으로 1구절."""
        try:
            with appdb.connect(self.db_path) as conn:
                vids = [r[0] for r in conn.execute(
                    "SELECT verse_id FROM user_favorite "
                    "WHERE fav_type='VERSE' AND record_status='LIVE' AND verse_id IS NOT NULL").fetchall()]
                vids += [r[0] for r in conn.execute(
                    "SELECT verse_id FROM sys_verse_highlight "
                    "WHERE highlight_type='FEATURED' AND record_status='LIVE'").fetchall()]
                vids = list(dict.fromkeys(v for v in vids if v is not None))   # 중복 제거(순서 보존)
                if not vids:
                    return None
                import random
                vid = random.choice(vids)
                row = conn.execute(
                    "SELECT bc.verse_text, bn.short_name, bi.chapter, bi.verse "
                    "FROM bible_index bi "
                    "JOIN bible_content bc ON bc.verse_id=bi.verse_id AND bc.version_code=? "
                    "JOIN book_names bn ON bn.book_code=bi.bcode AND bn.lang_code=? "
                    "WHERE bi.verse_id=?", (self.ver, _ref_lang(), vid)).fetchone()
                if not row:    # 선택 버전에 본문 없으면 KRV 폴백
                    row = conn.execute(
                        "SELECT bc.verse_text, bn.short_name, bi.chapter, bi.verse "
                        "FROM bible_index bi "
                        "JOIN bible_content bc ON bc.verse_id=bi.verse_id AND bc.version_code='KRV' "
                        "JOIN book_names bn ON bn.book_code=bi.bcode AND bn.lang_code=? "
                        "WHERE bi.verse_id=?", (_ref_lang(), vid)).fetchone()
                if not row:
                    return None
                return (vid, row[0], row[1], row[2], row[3])
        except Exception:
            return None

    def _peri_title(self, conn, peri_id, lang):
        """페리코프 제목 — 사용자언어 → EN → KO 폴백(없으면 ''). 코드 노출 방지.
        PERI_TITLE 값은 title 칼럼(구버전 contents 폴백)."""
        for lc in (lang, 'EN', 'KO'):
            try:
                r = conn.execute(
                    "SELECT COALESCE(title, contents) FROM sys_text_asset "
                    "WHERE clicked_id=? AND text_type='PERI_TITLE' AND lang_code=? AND COALESCE(record_status,'LIVE')='LIVE' "
                    "  AND COALESCE(title, contents) IS NOT NULL AND COALESCE(title, contents)<>'' "
                    "LIMIT 1", (peri_id, lc)).fetchone()
            except Exception:
                r = None
            if r and r[0]:
                return r[0]
        return ''

    # ─────────────────────────────────────────────────────────────────────────

    def load_short_names(self):
        """성경 약명 로드 — 사용자 언어 우선, 없으면 EN, 그다음 KO (책별)."""
        lang = getattr(self, 'lang', 'KO') or 'KO'
        pri = {lang: 0, 'EN': 1, 'KO': 2}
        with appdb.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT book_code, lang_code, short_name FROM book_names "
                "WHERE lang_code IN (?,'EN','KO')", (lang,)).fetchall()
        best: dict[str, tuple] = {}
        for code, lc, nm in rows:
            rank = pri.get(lc, 9)
            if nm and (code not in best or rank < best[code][0]):
                best[code] = (rank, nm)
        return {code: v[1] for code, v in best.items()}

    def setup_ui(self):
        """[통합수리] 프레임 생성 순서를 교정하여 AttributeError를 방지하고 레이아웃을 확정합니다."""
        # 🎯 [해결] 하위 메서드들이 공통으로 사용하는 변수를 가장 먼저 선언합니다.
        self.scope_t1_var = tk.IntVar(
            value=min(int(getattr(self, 'last_scope_t1', 1) or 1), 2))   # 3(+Container) 폐기
        # VERS_VERS 등급 필터
        # ★ 범위(핵심/확장/참조) 필터 폐지 (2026-09-02 0.txt 5번 사용자 확정 —
        #   「최대표시갯수 + 유형별 점수가 있으므로 3가지 인위적 분류가 필요
        #   없어졌다」). 변수는 조회 코드가 아직 읽으므로 **늘 ABC(전체)** 로
        #   못 박는다 — 옛 저장값('A' 등)을 살리면 화면에 조절 칸이 없는데
        #   연결이 걸러지는 유령 상태가 된다.
        self.link_tier_var = tk.StringVar(value='ABC')
        self.scope_t2_var = tk.IntVar(value=getattr(self, 'last_scope_t2', 1))
        if not hasattr(self, 'path_mode_var'):
            self.path_mode_var = tk.IntVar(value=getattr(self, 'path_mode', 1))

        # 0. (최상단 배너 제거 2026-08-15) 배너가 겸하던 스플래시 캐시 갱신만 남긴다
        self.after(700, self._refresh_splash_cache)

        # 1. 전체 수직 레이아웃 (V_PW)
        self.v_pw = tk.PanedWindow(self, orient='vertical', sashwidth=4, bg="#D5DBDB", sashrelief='flat')
        self.v_pw.pack(expand=True, fill='both')

        # 2. 상단 레이아웃 (P1 성경 목록 + P2 본문 연구)
        self.top_pw = tk.PanedWindow(self.v_pw, orient='horizontal', bg="#D5DBDB", sashwidth=4)
        # ★ **한 패널이 아예 사라지지 않게 최소 크기를 못 박는다** (2026-08-13 사용자 지시).
        #   막대를 끝까지 끌면 패널이 0 이 되고, 그러면 **되돌릴 손잡이조차 안 보여**
        #   사용자가 대처할 방법이 없다(검증 중에 실제로 그렇게 만들었다).
        # ⚠ 비율(95%)이 아니라 **최소 픽셀**로 잡는다 — 비율은 창 크기에 따라
        #   뜻이 달라지지만 최소 픽셀은 어느 창에서나 지켜진다.
        # ⚠ **크게 잡으면 안 된다.** 처음에 160~320px 로 두었더니 막대가
        #   70% 쯤에서 멈춰 「리사이즈가 안 된다」가 됐다. 목적은 넓이를
        #   지키는 것이 아니라 **패널이 사라지지 않게** 하는 것뿐이다.
        #   ⇒ `PANE_MIN` = 1cm 남짓(38px). 손잡이를 다시 잡을 만큼만 남긴다.
        self.v_pw.add(self.top_pw, height=self.p1_height, minsize=PANE_MIN)

        # 저장된 UI 글꼴을 **첫 화면부터** 입힌다. 여기서 안 하면 설정을 바꾼 뒤
        # 앱을 다시 켰을 때 UI 만 옛 크기로 돌아간다.
        try:
            theme_font.apply_ui(self.db_path, self)
            # ★ 기본 Treeview 도 표준 목록 서식으로 (2026-08-18) — 이름 없는
            #   트리(나의 길·팝업 등)가 22px 로 남던 마지막 구멍. list_style 이
            #   등록해 두므로 설정이 바뀌면 reapply_all 이 함께 갱신한다.
            theme_font.list_style('Treeview', self.db_path)
        except Exception:
            pass

        self._mark('p1 begin')
        self._setup_p1_ui(self.top_pw)
        self._mark('p1 done')
        # ★★★ **P1 이 서면 곧바로 「바로 시작」을 켠다** (2026-09-05 사용자 —
        #   「**p1 화면만 표시될 수 있는 상황이면 바로시작 라벨이 표시되어도
        #    된다**」). 실측 — 생성자 786ms 중 P4 탭0 이 268ms 인데, 그것은
        #   P1 을 보는 데 필요 없는 일이다.
        #   ⚠ **탭은 이미 지연 빌드다**(§29) — P4 는 탭 0 만, 나머지 일곱은
        #     누를 때 지어진다. 그래서 여기서 무장해도 눌러 들어가면 P1 이
        #     온전하고, 다른 탭은 그때 지어진다.
        #   ⚠ 아직 `mainloop` 전이라 이때 누른 클릭은 큐에 쌓였다가 곧 처리된다.
        try:
            if callable(ON_P1_READY):
                ON_P1_READY(self)
        except Exception:
            pass
        # P1 재생 관련(가벼움)은 P2가 지연돼도 존재하도록 미리 초기화(원래 _setup_p2_ui 안에 있던 것).
        self.__ps = None          # 처음 쓸 때 만든다(무거운 import)
        self.__player = None      # 처음 재생할 때 만든다
        self._p1_verse_ids: list[int] = []
        # P2(연구 워크벤치 ~1.0s, 시작 단일 최대 비용)는 첫 페인트 '후'에 빌드(phased build).
        # on_verse_selected·_update_p1_desc·재생 핸들러의 P2 접근은 모두 hasattr/getattr 가드라 안전.
        self.after(120, self._post_paint_build_p2_ui)
        self._mark('p2 deferred')

        # 3. 하단 탭 시스템 (P4 연관절 탐색)
        # ⚠⚠ **공통 띠를 걷었다** (2026-08-31 사용자 지시 「상식 밖의 장소에
        #   배치했다. **당장 제거하라.** 한 줄이라고 여유공간을 확보해야 한다」).
        #   ⇒ 단추는 **캔버스 단추 바로 왼쪽**(탭 0 의 제 줄)으로 돌아간다.
        #   ⚠ 탭 3~7 은 **자기 줄이 없다** — 거기에 넣으려면 줄을 새로 만들어야
        #     하고 그것이 방금 반려된 그 방식이다. 실측·설명은 세션 일지에.
        # ★ 2026-10-07 (51-4) — P4 탭이 12개 + 배지라 전역 탭 여백(좌우 10px)으로는 넘친다
        #   (실측 KO 1,505 · ES 1,869 / P4 1,498px). P4 만 좌우 여백을 줄인 스타일을 쓴다 —
        #   색·모양은 전역 탭 스타일을 그대로 물려받는다. 이름은 P4 전용 짧은 열쇠(`P4T_*`).
        try:
            _s4 = ttk.Style()
            _s4.configure('P4.TNotebook.Tab', padding=(5, 3))
        except Exception:
            pass
        # ★ 2026-10-07 (317차-26) — P4 는 **틀(p4_host) 안의 노트북**이다. 왼쪽 탭 막대
        #   (`side_rail`)가 그 틀 안 노트북 왼쪽에 선다. 창 나눔(v_pw)에 드는 것은 틀이다 —
        #   Focus 접기·펴기도 틀을 접는다(`_p1_focus` · `deactivate_p4_focus_mode`).
        self.p4_host = tk.Frame(self.v_pw)
        self.v_pw.add(self.p4_host, minsize=PANE_MIN)
        self.p4_nb = ttk.Notebook(self.p4_host, style='P4.TNotebook')
        self.p4_nb.pack(fill='both', expand=True)
        # ★★ **P4 탭을 고르는 문은 하나** — 고르는 순간 P1 [Focus] 로 접혀 있던 P4 를
        #   편다(2026-10-09 1.txt 59-2 사용자 「P2에서 목록을 클릭하면 자동으로
        #   Restore 기능이 작동하면서 P4의 해당 화면을 표시」). 고르는 자리가 서른
        #   곳 가까이라 자리마다 붙이면 반드시 빠진다 — 그래서 문을 감싼다.
        #   ⚠ 이미 그 탭이어도 편다(새 글만 넘겨받는 경우 탭 전환이 없다).
        #   ⚠ 사람이 부르지 않은 고르기(직전 탭 되살리기 · 쇼핑몰 감추기)는
        #     `_p4_select_raw` 를 쓴다 — 안 그러면 Focus 가 저절로 풀린다.
        self._p4_select_raw = self.p4_nb.select

        def _p4_select(tab_id=None, _raw=self._p4_select_raw):
            if tab_id is None:
                return _raw()
            if getattr(self, '_p1_focused', False):
                try:
                    self._p1_focus(False)
                except Exception as e:
                    print('[p4 reveal] %s' % e)
            return _raw(tab_id)
        self.p4_nb.select = _p4_select
        # ★ [Focus]/[Restore] = P4 탭 줄 맨 왼쪽 한 쌍(2026-09-16 · 1.txt 28) — 어느 탭에서도 보인다.
        #   `btn_focus`/`btn_restore` 이름은 그대로(`activate_p4_focus_mode` 가 바꿔 낀다).
        self._p4_focus_strip = self._focus_strip(self.p4_nb, 'P4Focus.TNotebook')
        self.btn_focus = tk.Button(
            self._p4_focus_strip, text=i18n.t('UM_FOCUS', 'Focus'),
            command=self.activate_p4_focus_mode, **ui_theme.focus_kw())
        self.btn_restore = tk.Button(
            self._p4_focus_strip, text=i18n.t('UM_RESTORE', 'Restore'),
            command=self.deactivate_p4_focus_mode, **ui_theme.focus_kw(restore=True))
        self.btn_focus.place(**self.FOCUS_FILL)
        self._p4_focus_strip.fit()

        # 🎯 [해결] 탭 프레임들을 먼저 생성하여 self 속성으로 등록 (AttributeError 방지)
        # ★ 캔버스 탭 + 트리뷰 탭 = 「구절 연결」 한 탭으로 통합 (2026-08-12 사용자 결정).
        #   두 화면은 왼쪽(그림 / 나무 목록)만 다르고 **오른쪽이 같은 화면인데 두 벌 만들어
        #   띄우고 있었다** — 주석·내부자료·링크·묵상노트 인스턴스가 각각 한 벌씩,
        #   P2 까지 치면 세 벌이었다. 통합으로 두 벌이 된다.
        #   설명문 경로도 같았다 — 트리뷰의 `_load_focus_research_data` 와 NodePanel 의
        #   `_refresh_desc` 가 **둘 다 `_fetch_combined_desc`** 를 부르고 있었다.
        # ⚠ `p4_t2_f` 를 없앴으므로 뒤 탭들의 **인덱스가 하나씩 당겨진다**.
        #   `_lazy_tab_builders` 키와 `last_p4_tab` 저장값이 함께 걸린다(아래 참조).
        # ★★★ 2026-10-07 (docs/1.txt 51-4(2)) — **P4 탭을 넷으로 묶어 다시 놓았다**(사용자 차례 그대로):
        #   ① 구절 자체 = 역본비교 · ② 구절간 연결 = 구절 연결 · 말씀의 흐름 ·
        #   ③ 구절과 연결된 컨텐츠 = 주석 · 주요용어 · 연구/설교노트 · 온라인 영상 · AI 도우미 ·
        #   ④ 구절과 직접 관계없는 것 = 메시아 가계도 · 믿음의 발자취 · 최신 콘텐츠 · 쇼핑몰.
        #   말씀의 흐름은 역본비교와 한 탭(갈래)이던 것을 **제 탭으로** 떼었고, 주석은 P2 에서 왔다.
        #   ⚠ 만드는 차례가 곧 탭 번호다 — `self.P4` 표와 `_migrate_p4_tab_20261007` 이 함께 간다.
        #   ⚠ 프레임 이름(p4_tN_f)은 옛 것을 그대로 쓴다 — 부르는 자리가 수십 곳이다.
        self._p4_tab_base = {}

        def _p4_add(frame, key, ik, ko):
            self._p4_tab_base[key] = (ik, ko)
            self.p4_nb.add(frame, text=i18n.t(ik, ko))

        self.p4_t9_f = ttk.Frame(self.p4_nb)
        _p4_add(self.p4_t9_f, 'compare', 'P4T_COMPARE', '역본비교')
        self.p4_t1_f = ttk.Frame(self.p4_nb)
        _p4_add(self.p4_t1_f, 'link', 'P4T_LINK', '구절 연결')
        self.p4_t14_f = ttk.Frame(self.p4_nb)
        _p4_add(self.p4_t14_f, 'flow', 'P4T_FLOW', '말씀의 흐름')
        self.p4_t15_f = ttk.Frame(self.p4_nb)
        _p4_add(self.p4_t15_f, 'comm', 'P2T_COMM', '주석')
        self.p4_t4_f = ttk.Frame(self.p4_nb)
        _p4_add(self.p4_t4_f, 'entity', 'P4T_TERMS', '주요용어')
        self.p4_t10_f = ttk.Frame(self.p4_nb)
        _p4_add(self.p4_t10_f, 'refs', 'P4T_NOTES', '연구/설교노트')
        self.p4_t8_f = ttk.Frame(self.p4_nb)
        _p4_add(self.p4_t8_f, 'kids', 'P4T_VIDEO', '유튜브')
        self.p4_t13_f = ttk.Frame(self.p4_nb)
        _p4_add(self.p4_t13_f, 'ai', 'P4T_AI', 'AI 도우미')
        self.p4_t5_f = ttk.Frame(self.p4_nb)
        _p4_add(self.p4_t5_f, 'messiah', 'P4T_GENEAL', '메시아 가계도')
        self.p4_t7_f = ttk.Frame(self.p4_nb)
        _p4_add(self.p4_t7_f, 'pilgrimage', 'P4T_PILGRIM', '믿음의 발자취')
        self.p4_t12_f = ttk.Frame(self.p4_nb)
        _p4_add(self.p4_t12_f, 'news', 'P4T_NEWS', '최신 콘텐츠')
        # 쇼핑몰 — 맨 뒤 · 상품 0개면 감춘다(`_sync_shop_tab` · hide 는 번호를 안 민다)
        self.p4_t11_f = ttk.Frame(self.p4_nb)
        _p4_add(self.p4_t11_f, 'shop', 'TAB_P4_SHOP', '쇼핑몰')
        # ★ 왼쪽 탭 막대(설정 ▸ 화면 배치) — P4 는 탭 줄에 단추를 얹은 서브 노트북이
        #   없다(주요용어 안쪽 탭은 줄에 검색 단추·언어 콤보가 있어 그대로 둔다).
        try:
            import side_rail
            self.p4_rail = side_rail.SideRail(
                self.p4_host, self.p4_nb, self.db_path, 'P4', 'P4Focus.TNotebook',
                strip=self._p4_focus_strip, focus_builder=self._rail_p4_focus)
            self.p4_rail.apply(side_rail.get_mode(self.db_path, 'P4'))
        except Exception as e:
            print('[p4 rail] %s' % e)
        # Tab10 자료 — P2 내부자료 목록에서 고른 글·내 자료·영상을 넓게 펼치는 자리.
        # P1 은 노트북이라 읽기 탭으로 가면 성경 본문이 가려진다. P4 는 P1 과 좌우로
        # 나뉜 별개 패널이라 본문을 띄워 둔 채 읽을 수 있다. 글과 영상을 한 탭에서
        # 위젯만 갈아 끼워 쓴다(탭이 이미 9개라 둘로 나누면 라벨이 무너진다).
        # ★ 이름을 「내부자료」로 (2026-08-13 사용자 지시). **P2 탭3 과 같은 키를 쓴다** —
        #   같은 개념(P2 는 목록, 여기는 넓게 읽기)이라 두 곳에 따로 적으면 말이 갈라진다.
        #   `TAB_INTERNAL` 은 이미 11개 언어가 채워져 있어 번역도 따라온다.
        #   ⚠ 옛 키 `TAB_P4_REF`('자료')는 이제 아무도 안 쓴다.
        # ★ **이 탭 이름만 「연구자료」다** (2026-08-16 사용자 지시).
        #   규칙 — **상위탭 = 내부자료(그릇) · 하위탭 = 연구자료(그 안의 갈래)**.
        #   그런데 이 탭과 주요용어 서브탭은 **하위탭이 상위탭 자리를 차지**한 것이라
        #   그릇 층이 없다. 담긴 것은 P2 하위탭(연구 글·내 자료) 그대로다.
        #   ⇒ 이름도 담긴 것을 따른다. P2 탭3·NodePanel 탭3 은 **내부자료로 둔다**
        #     (거기는 연구자료 + 내부연결 두 갈래를 담는 진짜 그릇이다).
        #   ⚠ 2026-08-14 에 `TAB_INTERNAL` **값**을 바꿨다가 하루 만에 되돌린 적이 있다 —
        #     세 곳이 그 열쇠를 함께 쓰기 때문이다. 이번에는 **열쇠를 갈랐다**(`TAB_RESEARCH`).
        #   (연구자료 탭 프레임은 위 1번 자리에서 만든다 — 2026-08-20 이동)

        # 4. 각 탭 내부의 세부 UI 배치
        #    탭0(구절연결)은 p4_view 가 93곳에서 참조되는 핵심이라 즉시 빌드.
        self._setup_p4_link_tab()         # Tab 0 — 캔버스 + 트리뷰 통합
        self._mark('p4 tab 0 done')

        # 🎯 [백그라운드 유휴 빌드 — CLAUDE.md §29.4] 탭3~5(엔티티/메시아·제자 가계도)는
        #    무겁다(가계도는 생성 즉시 144·43 노드 풀 렌더). 시작 시 '직전값 탭 1개'만 빌드하고,
        #    나머지는 첫 페인트 후 유휴 시간(after_idle 체인)에 하나씩 백그라운드로 미리 빌드한다.
        #    → 무거운 빌드를 탭 클릭 핸들러 안에서 동기 실행하지 않으므로 블로킹·geometry 회귀가 없다.
        # ⚠ **키가 탭 인덱스다.** 캔버스·트리뷰 통합으로 탭이 하나 줄어 전부 -1 했다
        #   (2026-08-12). 탭 순서를 바꾸면 여기도 함께 고칠 것.
        # ★ **탭 번호를 화면 코드에 흩어 놓지 않는다** (2026-08-13).
        #   2026-08-12 에 캔버스+트리뷰를 한 탭으로 합치면서 번호가 하나씩 당겨졌는데,
        #   `_ensure_p4_tab_built(3)` 같은 호출부 넷이 **옛 번호를 그대로 써서**
        #   엉뚱한 탭을 짓고 있었다. 그래서 P1 구절→엔티티→주요용어 로 들어가면
        #   `entity_browser` 가 아직 없어 **이름도 설명문도 안 떴다**(사용자 지적).
        #   ⇒ 이름으로 부른다. 탭이 또 바뀌면 이 표 한 곳만 고친다.
        # ⚠ **탭 번호는 이 표에만 적는다** (§3). 밖에서 `idx == 7` 처럼 쓰면
        #   탭이 하나 늘거나 줄 때 조용히 엉뚱한 탭에서 돈다 — 실제로 두 번 당했다.
        # 2026-08-20 — 'report' 폐지, 'refs' 가 8 → **1**(그 자리로 이사).
        #   나머지 2~7 은 그대로다(그것이 이 방식을 고른 까닭).
        # 2026-09-26 · 1.txt 20번 — **제자 가계도 폐지** · **역본·말씀흐름을
        #   구절연결 옆으로**(구절 축끼리 모은다). 저장값은 아래
        #   `_migrate_p4_tab_20260926` 이 한 번 이주한다.
        self.P4 = {'compare': 0, 'link': 1, 'flow': 2, 'comm': 3, 'entity': 4,
                   'refs': 5, 'kids': 6, 'ai': 7, 'messiah': 8, 'pilgrimage': 9,
                   'news': 10, 'shop': 11}
        _P = self.P4
        self._lazy_tab_builders = {
            _P['compare']: self._setup_version_compare_tab,  # 역본비교
            _P['flow']: self._setup_flow_tab,                 # 말씀의 흐름(51-4 — 제 탭)
            _P['comm']: self._setup_comm_tab,                 # 주석(51-4 — P2 에서 왔다)
            _P['entity']: self._setup_entity_browser_tab,
            _P['refs']: self._setup_ref_detail_tab,
            _P['kids']: self._setup_kids_tab,
            _P['ai']: self._setup_ai_tab,
            _P['messiah']: self._setup_figure_tree_tab,
            _P['pilgrimage']: self._setup_pilgrimage_tab,
            _P['news']: self._setup_news_tab,
            _P['shop']: self._setup_shop_tab,
        }
        self._built_lazy_tabs = set()

        # 5. 상태 복구 및 이벤트 바인딩
        self.p4_nb.bind("<<NotebookTabChanged>>", self._on_p4_tab_changed)
        # ⚠ 예전 사용자의 app_state.json 에는 **탭이 10개이던 시절의 값**(최대 9)이 남아 있다.
        #   그대로 select 하면 범위를 벗어나 엉뚱한 탭이 열리거나 예외가 난다.
        _n_tabs = len(self.p4_nb.tabs())
        if not (0 <= self.last_p4_tab_idx < _n_tabs):
            self.last_p4_tab_idx = 0
        # 직전값 탭이 지연 대상이면 시작 시 그 탭만 즉시 빌드(창 표시 전이라 geometry 안전).
        # 직전 탭을 '먼저 선택'해 사용자 습관 화면을 우선 노출. 내용 빌드는 첫 페인트 '후'로 미룬다
        # (after_idle도 페인트를 선점하므로 타이머 사용). 무거운 가계도가 직전 탭이어도 창은 먼저 뜬다.
        self._p4_startup = True
        self.p4_nb.select(self.last_p4_tab_idx)
        self._mark(f'select last_p4_tab({self.last_p4_tab_idx}) — build deferred')
        # ★★★ 쇼핑몰 — 상품이 0개면 감춘다. **반드시 직전 탭 복원 뒤에** 부른다:
        #   `select` 는 감춰 둔 탭을 **도로 보이게 한다**(Tk 의 SelectTab 이
        #   hidden 을 normal 로 되돌린다 — 실측). 앞에서 감추면 여기서
        #   되살아나고, 그러면 지연 빌드가 **상품 0인 화면을 지어** 놓는다.
        # ⚠ 서버 config 가 아직 안 왔을 수 있어 **8초 뒤 한 번 더** 쟴다.
        self._sync_shop_tab()
        try:
            self.after(8000, self._sync_shop_tab)
        except Exception:
            pass
        # ★★★ **ad-config 원격 fetch — 진입점이 아니라 앞이 부른다.**
        #   ⚠⚠⚠ 그전엔 `run.py` 에만 있어 **`user_main.py` 로 켜면
        #     영영 안 받았다** — 그리고 **배포 꾸러미의 실행기가
        #     바로 그 길**이다(§258차 ⑩). 관리자가 무엇을 발행해도
        #     사용자 화면은 옆 캐시를 그대로 들고 있었고 **오류도 안 났다**(§0-1).
        #   ★ 스플래시 「표시 안 함」 가드가 `run.py` 에만 있던 그 자리와
        #     똑같다 — **같은 일을 하는 자리가 둘이면 한쪽만 고쳤진다.**
        #   ⚠ 24시간 throttle 은 `maybe_fetch` 안에 있다(매번 받지 않는다) ·
        #     백그라운드라 시작을 안 막는다 · 못 받으면 옆 캐시를 그대로 쓴다.
        #   ⚠ 3초에 받고 **8초에 쇼핑몰 탭을 다시 재므로**(바로 위) 받은 것이
        #     **그 세션 안에** 보인다 — 차례를 바꾸지 말 것.
        try:
            import ads as _ads
            self.after(3000, lambda: _ads.maybe_fetch(self.db_path))
        except Exception:
            pass
        # ★★★ **영상 연결 델타 — 앱이 켜져 있는 동안 스스로 받는다**(2026-09-29
        #   293차 · 사용자 「매일 자동전송되는 링크팩 델타를 사용자 화면에서
        #   매일 자동 추가하는 기능도 완성하라」).
        #   ⚠⚠ 그전에는 받는 쪽이 **트레이뿐**이었고 트레이는 「본체가 떠 있으면
        #     아무것도 안 한다」(동시 쓰기 금지). 곧 **앱을 켜 둔 사람은 영영 못
        #     받았다** — 다운로드 화면은 「앱을 켜 두면 자동으로 받습니다」라
        #     적고 있었다(§0-1 거짓말).
        #   ★ 12초 뒤 첫 판정, 그 뒤로는 **다음 받을 때를 계산해 그때 한 번만**
        #     깨어난다(`sync_schedule.seconds_until` — 사용자 「10분마다 판정하는
        #     것은 과도하다」). 판정·받는 문은 트레이와 같다(`should_fetch` ·
        #     `fetch_pack_deltas`)라 하루 한 번을 넘지 않는다.
        self.after(12000, self._pack_sync_tick)
        # ★ 2026-10-25 앱 새 판 확인(하루 한 번 · 받아 두면 위에 알림 한 줄 · 다시 켜면 바뀐다)
        self.after(20000, self._app_update_tick)
        # ★ 2026-10-13 (docs/1.txt 73) — 하루 한 번 자동 정리(오래된 변경 이력 · 처리 끝난 폰 초안 ·
        #   아무도 안 가리키는 끊긴 영상). 앱이 다 뜬 뒤 뒤에서 — 화면을 안 멈춘다.
        self.after(30000, self._housekeep_once)
        # ★ 유튜브 간편 저장(2026-10-09 1.txt 59-3) — 링크 복사 감지 · 확장 프로그램 받는 곳
        self.after(2500, self._yt_setup)
        # ★ 떠 있는 트레이가 옛 판이면 새 판으로(2026-10-09 사용자 신고)
        self.after(6000, self._refresh_tray)
        self.after(200, self._post_paint_build_last_p4)
        # 프리빌드 비활성(2026-06-16, 사용자 요청): 직전 탭만 빌드, 나머지 P4 탭은 첫 클릭 시 빌드(순수 on-click).
        # 화면 표시 후 백그라운드로 다른 탭을 미리 만들지 않음 → 시작 후 모래시계 잔상 제거.
        # (프리빌드를 되살리려면 아래 줄 복원: self.after(1500, self._prebuild_next_lazy_tab))

        # 패널 크기 및 너비 실시간 저장 바인딩
        self.v_pw.bind("<ButtonRelease-1>", lambda e: self._save_state("p1_height", self.top_pw.winfo_height()), add="+")
        self.top_pw.bind("<ButtonRelease-1>", lambda e: self._save_state("p1_width", self.p1_f.winfo_width()), add="+")


    def _setup_p4_link_tab(self):
        """Tab 0 「구절 연결」 — 캔버스와 트리뷰를 한 탭에 담는다 (2026-08-12 통합).

        왼쪽만 갈아 끼우고 **오른쪽 NodePanel 은 두 화면이 함께 쓴다.**
        예전에는 탭이 둘이라 주석·내부자료·링크·묵상노트가 각각 한 벌씩 떠 있었다.

        층 구조 (2026-08-12 2차 — 두 줄을 한 줄로 합쳤다)
            [캔버스][트리뷰] Focus 범위·등급·경로 [캔버스설정]   ⓜ [설명패널 접기]
            캔버스 전용 줄(Journey·Save Map…)      ← 캔버스일 때만 pack
            ┌ 좌: 캔버스 또는 트리뷰 ┬ 우: NodePanel ┐

        ⚠ 한 줄 폭 실측 = **975px**(전환 203 + 옵션 772) / P4 폭 1498px.
          고정폭이라 창을 1000px 아래로 좁히면 오른쪽부터 잘린다.
        """
        parent = self.p4_t1_f

        # (a) 맨 윗줄 — 전환·옵션·매뉴얼·접기가 **한 줄**에 들어간다.
        #     예전에는 전환 줄(28px)과 옵션 줄(24px)이 따로라 세로 52px 을 먹었다.
        self._link_bar = tk.Frame(parent, bg="#ECF0F1")
        ui_theme.bar_height(self._link_bar)      # P4 서브탭 공통 높이(32px)
        self._link_bar.pack(side='top', fill='x', padx=5, pady=(3, 0))
        self._build_link_switch_bar(self._link_bar)

        # (b) 공통 옵션 — 같은 줄 안에 이어 붙인다. **여기 한 번만 만든다.**
        #     `_setup_scope_ctrl` 은 json_key 로 캔버스 전용 묶음(등급·배치 콤보)을 가르므로
        #     "last_scope_t1" 을 그대로 넘긴다.
        self._setup_scope_ctrl(self._link_bar, self.scope_t1_var, "last_scope_t1")

        # (c) 좌우 분할 — 왼쪽은 화면 두 개를 겹쳐 놓고 pack 으로 갈아 끼운다.
        self.p4_side_pw = tk.PanedWindow(parent, orient='horizontal', sashwidth=4, bg="#D5DBDB")
        self.p4_side_pw.pack(expand=True, fill='both')

        self.p4_left_stack = tk.Frame(self.p4_side_pw, bg="white")
        self.p4_side_pw.add(self.p4_left_stack, minsize=PANE_MIN)

        # ── 캔버스 화면 ──────────────────────────────────────────────────
        self.p4_canvas_area = tk.Frame(self.p4_left_stack, bg="white")

        # 5. 🎯 [보존] 네비게이션 및 여정 티커 바 로직 (Reset, Save, Home 등)
        # 🎯 [최종수리] 중복을 원천 차단하고 단일 행(Journey - 상태 - 버튼)으로 통합 배치합니다.
        h_f = tk.Frame(self.p4_canvas_area, bg="#F2F4F4", height=JOURNEY_BAR_H)
        h_f.pack(side='top', fill='x', padx=5, pady=0)
        h_f.pack_propagate(False)      # 선언 높이를 실제로 지킨다(트리뷰 쪽과 맞추려면 필수)

        # (1) 왼쪽: 여정 경로 표시 (가장 넓은 공간 차지)
        # ★ 2026-09-01 (0.txt 3번) — 「Journey:」 → 「경로:」 다국어(UM_JOURNEY)
        tk.Label(h_f, text=' %s ' % i18n.t('UM_JOURNEY', '경로:'),
                 bg="#F2F4F4", font=("Malgun Gothic", 8, "bold"),
                 fg="#2E86C1").pack(side='left')
        self.history_lbl = tk.Label(h_f, text="", bg="#F2F4F4", font=("Malgun Gothic", 8), fg="#7F8C8D", anchor='w')
        self.history_lbl.pack(side='left', fill='x', expand=True)

        # ★ **[Home]~[Manage] 는 상단 bar 로 이사했다** (2026-08-20 사용자 지시).
        #   여기 캔버스 줄에는 **Journey 경로만** 남는다 — 그래서 경로가 길어도
        #   잘리지 않고, 위아래 두 줄에 단추가 흩어지지 않는다.
        #   ⚠ 이 줄의 ⓜ 도 폐지 — 상단 bar 에 이미 있다(사용자 「중복이다」).
        self._build_canvas_action_btns(self._link_bar)

        # (3) 상태 라벨 — 만들어는 두되 **화면에는 안 붙인다**(2026-08-20 사용자
        #     「Home 왼쪽 상태값 표시 라벨 삭제해도 됨」). `_update_ui_status_labels`
        #     이 계속 글자를 넣으므로 위젯 자체는 남긴다(호출부 보호).
        self.p4_status_lbl = tk.Label(h_f, text=i18n.t('UM_INITSTATUS','초기화 상태'), fg="red", font=("Malgun Gothic", 9, "bold"), bg="#F2F4F4")

        # 주소록 등록 (맵 콤보는 2026-08-20 전부 폐지 — 팝업이 대신한다)
        if not hasattr(self, 'map_switchers'):
            self.map_switchers = {}
        self.history_labels["last_scope_t1"] = self.history_lbl

        # 6. 🎯 캔버스 객체 생성 및 배치
        self._mark('p4 link: canvas')        # 스플래시 클릭이 이 사이에도 먹게(2026-10-09)
        self.p4_view = BibleP4TreeCanvas(
            self.p4_canvas_area, self.db_path, self.lang, self.ver,
            on_node_click=self.on_node_click,
            on_node_double_click=self.handle_p4_node_double_click,
            on_chain_click=self._handle_chain_marker_click,
            bg="white"
        )
        # 배지 클릭 = 펼치기만 (읽기는 박스 클릭 — 2026-08-20 사용자 설계)
        self.p4_view.on_badge_click = self._on_badge_expand
        # ＋ = 다음 묶음을 아래에 추가 · − = 마지막 묶음 걷기 (2026-09-02 확정)
        self.p4_view.on_plus_click = self._on_plus_next
        self.p4_view.on_minus_click = self._on_minus_prev
        self._sync_canvas_style()      # 저장해 둔 캔버스 설정을 캔버스에 심는다
        # [2026-06-04] 기존 단독 chain 슬라이드는 NodePanel 탭7에서 embed로 대체.
        # 이 객체는 남아 있으나 호출 안 됨 (안전 보존, 후속 정리 가능).
        # [2026-07-30] 독립 ChainSlidePanel 인스턴스 제거 — 생성만 되고 show 호출이
        # 없는 죽은 위젯이었다(연쇄는 NodePanel 탭7이 ChainSlidePanel 을 embed 해 대체).
        # 클래스/파일(p4_chain_slide.py)은 그 탭이 쓰므로 그대로 둔다.

        # [신설] 통합 슬라이딩 패널 — 노드/P 마커/C 마커 클릭 시 등장
        # P2 5탭 (DESC/주석/Internal/Links/묵상노트) + 페리코프 + 연쇄 = 7탭
        self._mark('p4 link: node panel')    # 가장 무거운 덩이(0.3초) 앞에서 한 번 더
        self.p4_node_panel = NodePanel(
            self.p4_side_pw, self.db_path,
            lang_provider=lambda: getattr(self, 'lang', 'KO'),
            ver_provider=lambda: getattr(self, 'ver', 'KRV'),
            fetch_desc_fn=self._fetch_combined_desc,
            # 「이 구절의 연결」 접힘줄 (2026-08-21 `0.txt` 4번) — **P4 에만**
            fetch_links_fn=self._fold_children,
            fetch_link_desc_fn=self._fold_link_desc,
            on_link_ai=self._ai_link_analyze,
            on_verse_click=self._plan_verse_navigate,
            on_sermon_select=self._open_sermon_unit,
            on_doctrine_select=self._open_doctrine_unit,
            on_article_open=lambda i: self._open_ref_detail('ARTICLE', i),
            on_user_open=lambda i: self._open_ref_detail('USER', i),
            on_user_new=lambda v: self._open_ref_detail('NEW', v),
            on_chain_detail=self._open_chain_detail,
            on_video_open=self._open_video_online)
        self.p4_node_panel.on_desc_marks = self._desc_ai_marks     # ★ 2026-10-21 설명 칸마다 [AI 분석]
        # ⚠ 앵커는 **왼쪽 묶음**이다. 예전에는 캔버스 영역이었는데, 통합 뒤에는 왼쪽이
        #   캔버스↔트리뷰로 갈아 끼워지므로 캔버스를 앵커로 두면 트리뷰에서 자리를 잃는다.
        # ★ 「아직 안 받았습니다」에서 다운로드 탭으로(1.txt 16-3 ⑤).
        #   ⚠ NodePanel 이 제 주석 패널에 이 값을 물려준다 — 여기서 안 심으면
        #     P4 쪽에서는 단추가 영영 안 뜬다(오류도 안 난다).
        self.p4_node_panel.on_download_jump = self._open_download_tab
        self.p4_node_panel.set_pw_anchor(self.p4_left_stack)

        self.p4_view.pack(expand=True, fill='both')

        # ── 트리뷰 화면 ──────────────────────────────────────────────────
        self.tree_focus_area = tk.Frame(self.p4_left_stack, bg="white")

        # ⚠ 여기 있던 매뉴얼 아이콘 전용 띠(24px)를 없앴다 (2026-08-12 사용자 지적
        #   「빈 공간 bar」). 위젯이 하나뿐인데 높이를 24px 잡아먹고 있었다 —
        #   아이콘은 맨 윗줄로 올라갔고 화면에 따라 코드를 갈아 끼운다.

        # 캔버스의 Journey 바와 **같은 높이·같은 여백**이라야 화면을 갈아탈 때 안 튄다.
        self.breadcrumb_f = tk.Frame(self.tree_focus_area, bg="white", height=JOURNEY_BAR_H)
        self.breadcrumb_f.pack(fill='x', side='top', padx=5, pady=0)
        self.breadcrumb_f.pack_propagate(False)

        self._setup_pure_treeview(self.tree_focus_area)

        # 직전에 보던 화면으로 연다 (기본 = 캔버스)
        self._show_link_view(self._load_state('p4_link_view', 'CANVAS'), initial=True)

    # ── 「구절 연결」 화면 전환 ────────────────────────────────────────────
    def _build_link_switch_bar(self, bar):
        """[캔버스][트리뷰] 전환 · 매뉴얼 · 패널 접기. 버튼은 늘 상단(§0).

        옵션 묶음과 **같은 줄**을 쓴다 — 왼쪽부터 전환 버튼, 그 뒤에 `_setup_scope_ctrl`
        이 붙고, 오른쪽 끝에서 접기·매뉴얼이 역순으로 자리를 잡는다.
        """
        # (Focus/Restore 는 P4 탭 줄 맨 왼쪽 한 쌍 — 2026-09-16 1.txt 28. 이 줄에는 안 짓는다)
        self._link_view_btns = {}
        for key, txt in (('CANVAS', i18n.t('UM_LINK_CANVAS', '캔버스')),
                         ('TREE',   i18n.t('UM_LINK_TREE',   '트리뷰'))):
            b = tk.Button(bar, text=f' {txt} ', font=("Malgun Gothic", 9, "bold"),
                          bd=1, relief='raised', cursor='hand2', padx=6,
                          command=lambda k=key: self._show_link_view(k))
            b.pack(side='left', padx=(4, 2), pady=2)
            self._link_view_btns[key] = b

        # 오른쪽 패널 — X 로 없애지도, 늘 띄워 두지도 않는 제3의 방법(사용자 지시).
        # ⚠ side='right' 는 **먼저 pack 한 것이 더 오른쪽**에 온다. 접기가 끝, 그 왼쪽이 ⓜ.
        self._link_panel_btn = tk.Button(
            bar, text=i18n.t('UM_LINK_PANEL_HIDE', '설명패널 접기'),
            font=("Malgun Gothic", 8), bd=1, relief='groove', cursor='hand2',
            command=self._toggle_link_panel)
        self._link_panel_btn.pack(side='right', padx=4, pady=2)

        # 매뉴얼 ⓜ — 아이콘은 하나지만 **여는 글은 화면마다 따로다**(사용자 지시).
        # 화면을 갈아탈 때 `set_screen_code` 로 U_P4_T1 / U_P4_T2 를 바꿔 끼운다.
        self._link_manual_icon = attach_manual_icon(
            bar, 'U_P4_T1', lang_provider=lambda: getattr(self, 'lang', 'KO'))
        self._link_manual_icon.pack(side='right', padx=(4, 2))

    def _show_link_view(self, key, initial=False):
        """왼쪽 화면을 갈아 끼운다. **destroy 가 아니라 pack_forget** 이라
        캔버스에 펼쳐 둔 노드가 그대로 남는다(탭이 공짜로 해 주던 일)."""
        key = 'TREE' if str(key).upper() == 'TREE' else 'CANVAS'
        self._link_view = key
        for w in (getattr(self, 'p4_canvas_area', None), getattr(self, 'tree_focus_area', None)):
            if w is not None:
                w.pack_forget()
        area = self.tree_focus_area if key == 'TREE' else self.p4_canvas_area
        area.pack(fill='both', expand=True)

        # 눌린 버튼 표시
        for k, b in getattr(self, '_link_view_btns', {}).items():
            on = (k == key)
            b.config(relief='sunken' if on else 'raised',
                     bg='#5D6D7E' if on else '#EAEDED',
                     fg='white' if on else '#2C3E50')

        # 매뉴얼은 아이콘만 하나이고 **여는 글은 화면마다 따로다**(사용자 지시).
        ic = getattr(self, '_link_manual_icon', None)
        if ic is not None:
            try:
                ic.set_screen_code('U_P4_T2' if key == 'TREE' else 'U_P4_T1')
            except Exception:
                pass

        # 화면마다 쓰던 방식을 지킨다(사용자 지시) —
        #   트리뷰는 오른쪽 패널이 늘 보이고, 캔버스는 클릭할 때 나온다.
        panel = getattr(self, 'p4_node_panel', None)
        if panel is not None:
            if key == 'TREE':
                if not panel.winfo_ismapped():
                    panel._attach_if_hidden()
            elif initial:
                panel.hide()
            # 오른쪽 탭 선택도 화면마다 따로 기억한다(2026-08-12 사용자 지적
            # 「상호의존적으로 작동」). 캔버스에서 주석을 보다 트리뷰로 가면
            # 트리뷰가 마지막에 보던 탭으로 돌아온다.
            try:
                panel.set_view_key(key)
            except Exception:
                pass

        if not initial:
            self._save_state('p4_link_view', key)
            # ★ 2026-10-07 (docs/1.txt 51-1) — **단추를 누를 때 한 번에 맞춘다**(사용자 확정).
            #   지도는 하나라 펼친 것은 이미 양쪽에 있다 — 여기서는 보이는 화면만 다시 비춘다.
            #   트리뷰로: 캔버스에서 펼친 것을 그린다 · 캔버스로: 선을 다시 긋고 트리에서
            #   고른 노드로 화면을 옮긴다(숨어 있는 동안 트리에서 펼친 노드가 거기 있다).
            try:
                if key == 'TREE':
                    self.after_idle(self._sync_p4_tree_from_canvas)
                else:
                    def _to_canvas():
                        try:
                            self.p4_view.redraw_edges()
                        except Exception:
                            pass
                        self._sync_canvas_from_tree()
                    self.after_idle(_to_canvas)
            except Exception:
                pass

    def _toggle_link_panel(self):
        """설명패널 **잠금** 토글 (2026-08-20 사용자 지시로 뜻이 바뀌었다).

        ⚠ 예전에는 `panel.hide()` 한 줄이라 **패널 우측 상단 ✕ 와 완전히 같았다**
          (사용자 지적 — 「버튼을 차별적으로 운영하려면 기능이 달라야 한다」).
        ⇒ 이제 접기 = **잠금 모드**: 노드를 눌러도 패널이 안 열리고 자녀만
          펼쳐진다. 다시 보려면 [설명펴기]. ✕ 는 종전대로 **일회성 닫기**
          (다음에 노드를 누르면 다시 열린다) — 두 단추의 역할이 갈린다."""
        panel = getattr(self, 'p4_node_panel', None)
        if panel is None:
            return
        self._link_panel_locked = not getattr(self, '_link_panel_locked', False)
        # ★ 2026-09-01 (0.txt 3번) — 토글 상태를 음각/양각으로도 보인다
        #   (§55 규약: 기본 raised 계열 · 눌린 상태만 sunken).
        if self._link_panel_locked:
            panel.hide()
            self._link_panel_btn.config(
                text=i18n.t('UM_LINK_PANEL_SHOW', '설명펴기'), relief='sunken')
        else:
            panel._attach_if_hidden()
            self._link_panel_btn.config(
                text=i18n.t('UM_LINK_PANEL_HIDE', '설명접기'), relief='groove')

    # 수동맵 관리화면
    def _save_manual_map(self):
        """[최종완결] 입력창 중복을 제거하고 UI 높이를 확보하여 description 입력이 가능하게 합니다."""
        save_win = tk.Toplevel(self)
        save_win.title("Save Manual Map")
        save_win.geometry("450x550") # 높이를 550으로 확장하여 모든 위젯 노출 보장
        
        tk.Label(save_win, text="Map Name:", font=("Malgun Gothic", 9, "bold")).pack(pady=(10, 2))
        name_ent = tk.Entry(save_win, width=50)
        name_ent.pack(pady=2)
        name_ent.insert(0, f"MAP_{datetime.now().strftime('%m%d_%H%M')}")
        
        tk.Label(save_win, text="Tags (comma separated):", font=("Malgun Gothic", 9, "bold")).pack(pady=(10, 2))
        tag_ent = tk.Entry(save_win, width=50)
        tag_ent.pack(pady=2)

        # 🎯 [수리] 중복을 제거하고 하나의 상세 설명(Description) 박스만 배치합니다.
        tk.Label(save_win, text=i18n.t('UM_MAPDESC','Description (Map 상세 설명):'), font=("Malgun Gothic", 9, "bold")).pack(pady=(10, 2))
        desc_txt = tk.Text(save_win, height=12, width=55, font=("Malgun Gothic", 9))
        desc_txt.pack(padx=15, pady=5)

        def do_save():
            m_name = name_ent.get().strip()
            t_list = tag_ent.get().strip()
            d_content = desc_txt.get("1.0", tk.END).strip()
            
            if not m_name: return
            
            # 🎯 [수리] 장부(nodes)의 모든 정보(rel_label 포함)가 JSON에 담기도록 합니다.
            struct_data = {vid: info for vid, info in self.p4_view.nodes.items()}
            path_str = "|".join(self.current_journey_list)
            
            with appdb.connect(self.db_path) as conn:
                sql = """
                    INSERT INTO user_saved_maps 
                    (root_id, save_type, map_name, path_string, tag_list, description, full_structure, updated_at) 
                    VALUES (?, 'MANUAL', ?, ?, ?, ?, ?, datetime('now'))
                """
                conn.execute(sql, (self.active_node_id, m_name, path_str, t_list, d_content, json.dumps(struct_data, ensure_ascii=False)))
                conn.commit()
            
            messagebox.showinfo(i18n.t('MSG_T_SAVEDONE', "저장 완료"), i18n.t('MSG_MANUAL_SAVE_DONE', "'{name}' 수동 저장이 완료되었습니다.").format(name=m_name))
            save_win.destroy()
            self._refresh_map_switcher_list()

        tk.Button(save_win, text=" Save Now ", command=do_save, width=25, 
                  bg="#2E86C1", fg="white", font=("Malgun Gothic", 10, "bold")).pack(pady=15)

    # ── 삭제됨: `_setup_p4_tree_tab` · `_setup_research_workbench` · `_on_focus_tab_changed`
    #    (2026-08-12 캔버스·트리뷰 통합).
    #    트리뷰 화면은 `_setup_p4_link_tab` 안으로 들어갔고, 오른쪽 5탭 워크벤치는
    #    **NodePanel 7탭이 그대로 대신한다** — 설명문 경로가 애초에 같았다
    #    (`_load_focus_research_data` 와 NodePanel `_refresh_desc` 가 둘 다
    #     `_fetch_combined_desc` 를 부르고 있었다).
    #    이로써 CommentaryPanel·RefUnifiedPanel·LinksPanel·NoteRefrPanel 인스턴스가
    #    **한 벌씩 줄었다**(P2 + 캔버스 + 트리뷰 = 세 벌 → 두 벌).
    #    화면코드 `res_*` 히트는 NodePanel 쪽에서 낼 것 — 지금은 집계되지 않는다.

    def _setup_entity_browser_tab(self):
        """Tab — 주요용어(종합 엔티티 브라우저)."""
        # ⚠ 여기 있던 매뉴얼 아이콘 전용 띠(28px)를 없앴다 (2026-08-12 사용자 지적
        #   「비어있는 bar」). 트리뷰에서 없앤 것과 같은 종류다 — 위젯이 하나뿐인데
        #   높이를 차지하고 있었다. 아이콘은 패널 자체의 상단 bar 오른쪽 끝으로 갔다
        #   (`EntityBrowserPanel._build_top_bar`, 코드는 그대로 U_P4_T4).
        self.entity_browser = EntityBrowserPanel(
            self.p4_t4_f, self.db_path,
            lang_getter=lambda: self.lang,
            on_person_tree=self._on_person_tree_click,
            on_person_net=self._on_person_net_click,
            on_verse_jump=self._plan_verse_navigate,   # 여정 탭 스토리 묵상 → P1/P2
            # 작성자료 글 → P4 탭10(자료). 구절 쪽(P2 내부자료)과 같은 자리로 모인다
            on_article_open=lambda i: self._open_ref_detail('ARTICLE', i),
            # 내부연결 — P2 내부자료와 **같은 곳으로** 보낸다(2026-08-10).
            # 전에는 셋을 다 on_article_open 으로 보내서 P4 에서만 도서/설교 탭이 안 열렸다.
            on_sermon_select=self._open_sermon_unit,
            on_doctrine_select=self._open_doctrine_unit,
            # 내가 쓴 글도 넓게 볼 길을 준다(두 번 누르면 탭10)
            on_user_open=lambda i: self._open_ref_detail('USER', i),
        )
        self.entity_browser.on_count = self._badges_soon
        # ★ 80-4 — 사람이 고른 구절이 이미 있으면 그 절의 낱말 목록으로 연다(배지와 같은 화면)
        if getattr(self, '_list_vid', None):
            _lv = self._list_vid
            self.entity_browser.after_idle(lambda: self.entity_browser.show_lexicon(int(_lv)))
        # ★ 연결하기 창 결과 → 그 화면으로 (2026-08-24). 주요용어 안 연구자료
        #   패널이 이 값을 그대로 물려받는다.
        self.entity_browser.on_link_open = self._tag_asset_jump
        self.entity_browser.on_ai = self._open_ai_term     # 299차 — [AI] 용어 닻
        self.entity_browser.on_ai_lemma = self._open_ai_lemma   # 2026-10-14 — 승격 안 된 낱말 닻
        # ★ 「이 낱말이 흐르는 자리」 → 구속사 연결 설명(2026-09-07 · 1.txt C).
        #   ⚠ 흐름 화면을 여기서 다시 짓지 않는다 — P4 탭7 이 이미 맡는다.
        self.entity_browser.on_chain_open = self._open_chain_detail
        self.entity_browser.pack(fill='both', expand=True)

    def _setup_figure_tree_tab(self):
        """Tab5 — 가계도 (아담→그리스도). 기존 figure_tree 대체."""
        self.figure_tree = GenealogyCanvas(
            self.p4_t5_f, self.db_path,
            lang_provider=lambda: getattr(self, 'lang', 'KO'),
            on_entity_jump=lambda eid: self._on_genealogy_entity_jump(eid),
        )
        self.figure_tree.pack(fill='both', expand=True)

    def _on_genealogy_entity_jump(self, entity_id):
        """가계도·발자취·연구자료 → P4 주요용어 탭에서 그 항목을 연다.

        ★ **2026-08-21 수리 — 이 길은 지금까지 탭만 바꾸고 아무것도 안 열었다.**
          `hasattr(self.entity_browser, 'select_entity')` 로 감싸 두었는데
          `EntityBrowserPanel` 에 그런 이름이 **없다**(진짜 이름은 `load_entity`).
          없는 이름이라 가드가 늘 거짓 → 조용히 지나가고 화면에는
          「엔티티를 선택하세요」가 남았다(실측). 오류도 안 났다.
        ⚠ 이 함수를 쓰는 곳이 **넷**이다 — 메시아 가계도 · 제자 가계도 ·
          발자취 핀 더블클릭 · 연구자료 용어 더블클릭. 넷 다 죽어 있었다.
        ⇒ **hasattr 로 감싼 호출은 이름이 틀려도 아무 소리를 안 낸다.**
          방어를 하려면 실패를 알려야 한다(아래처럼 남은 경우 print)."""
        if not entity_id:
            return
        try:
            # 지연 빌드 대상이면 먼저 동기 빌드 — 객체가 있어야 항목을 연다
            if hasattr(self, 'p4_nb'):
                self._ensure_p4_tab_built(self.P4['entity'])
                self.p4_nb.select(self.p4_t4_f)
            eb = getattr(self, 'entity_browser', None)
            fn = getattr(eb, 'load_entity', None) or getattr(eb, 'select_entity', None)
            if fn is None:
                print('[entity jump] 주요용어 화면에 여는 함수가 없다')
                return
            fn(int(entity_id))
        except Exception as e:
            print(f'[entity jump] {e}')

    def _setup_figure_net_tab(self):
        """Tab6 — 제자 가계도 (lineage_type='DISCIPLE')."""
        self.disciple_canvas = GenealogyCanvas(
            self.p4_t6_f, db_path=self.db_path,
            lang_provider=lambda: getattr(self, 'lang', 'KO'),
            on_entity_jump=lambda eid: self._on_genealogy_entity_jump(eid),
            lineage_type='DISCIPLE',
        )
        self.disciple_canvas.pack(fill='both', expand=True)

    def _setup_news_tab(self):
        """Tab — 최신 콘텐츠(RSS·유튜브). P1 에서 옮겨 왔다(1.txt 20번 3).

        ⚠ **위젯은 그대로 `ReadingNewsView`** 다 — 옮긴 것은 자리뿐이다.
          다시 지으면 배너·면책·채널 규칙이 두 벌이 된다.
        ⚠ 옛 이름 `self.p1_reading_news` 를 **그대로 쓴다** — 밖에서 그 이름을
          부르는 자리가 있을 수 있다(이름을 바꾸면 그 길이 조용히 죽는다).
        """
        try:
            from reading_news_view import ReadingNewsView
            self.p1_reading_news = ReadingNewsView(
                self.p4_t12_f, self.db_path,
                lang_getter=lambda: getattr(self, 'lang', 'KO'))
            self.p1_reading_news.pack(fill='both', expand=True)
        except Exception as e:
            print('[news tab] %s' % e)

    def _setup_ai_tab(self):
        """Tab — AI 도우미(사용자의 AI 대화 · 298차). 저장은 개인 DB 만."""
        try:
            from ai_chat_view import AIChatView
            self.ai_chat_view = AIChatView(
                self.p4_t13_f, self.db_path,
                lang_getter=lambda: getattr(self, 'lang', 'KO'),
                on_saved=lambda rid: self._ai_saved(rid),
                on_open=self._ai_open_saved)
            self.ai_chat_view.pack(fill='both', expand=True)
            # ★ 2026-10-21 AI 답을 설명문·분야 도움말·묵상노트로 담으면 P2·P4 설명을 곧바로 다시 그린다
            self.ai_chat_view.on_desc_saved = self._ai_desc_saved
            # ★ 2026-10-16 채팅이 늘거나 줄면 P4 「AI 도우미 (n)」 배지를 다시 센다
            self.ai_chat_view.on_changed = lambda: self._update_p4_badges(getattr(self, '_p4_badge_vid', None))
            # ★ 317차 — **이번 실행에서 사람이 고른 구절**만 넘긴다. 시작할 때 복원된
            #   구절은 사람이 고른 것이 아니라 그대로 두면 Free 로 시작한다(사용자 확정).
            vid = getattr(self, '_ai_picked_vid', None)
            if vid:
                self.ai_chat_view.set_anchor(vid)
        except Exception as e:
            print('[ai tab] %s' % e)

    def _ai_open_saved(self, kind, item_id):
        """AI 도우미 저장 뒤 [열어 보기] — 담은 그 자리로(317차 · 자동으로는 안 옮긴다)."""
        try:
            if kind == 'USER_REF':
                self._open_ref_detail('USER', int(item_id))
            elif kind == 'VERSE':
                self._plan_verse_navigate(int(item_id))
            elif kind == 'ENTITY':
                self._on_genealogy_entity_jump(int(item_id))
        except Exception as e:                            # noqa: BLE001
            print('[ai open] %s' % e)

    def _ai_desc_saved(self):
        try:
            self._update_p1_desc(getattr(self, '_p1_verse_id', None))
        except Exception as e:
            print('[ai desc saved p2] %s' % e)
        try:
            panel = getattr(self, 'p4_node_panel', None)
            vid = getattr(panel, '_curr_view_id', None) if panel is not None else None
            if vid:
                panel._refresh_desc(vid)
        except Exception as e:
            print('[ai desc saved p4] %s' % e)
        try:
            np_ = getattr(self, "p2_note_panel", None)
            if np_ is not None and getattr(self, "_p1_verse_id", None):
                np_.load(self._p1_verse_id)
        except Exception:
            pass

    def _ai_saved(self, rid):
        """AI 대화를 「내 자료」로 담았다 — 연구자료 화면이 다시 읽게 한다."""
        try:
            v = getattr(self, 'ref_detail_view', None)
            if v is not None and hasattr(v, 'reload'):
                v.reload()
        except Exception:
            pass

    def _schedule_p4_follow(self, vid):
        """P4 따라가기를 화면이 그려진 뒤로 미룬다 — 마지막에 누른 구절만 한다(74-11)."""
        self._p4_follow_gen = getattr(self, '_p4_follow_gen', 0) + 1
        gen = self._p4_follow_gen

        def run():
            if gen != getattr(self, '_p4_follow_gen', 0):
                return                              # 그 사이 다른 구절을 눌렀다
            with appdb.scope(getattr(self, '_verse_memo', None)):
                self._p4_verse_follow(vid)
        try:
            self.after(40, run)
        except Exception:
            run()

    def _p4_verse_follow(self, vid):
        """★ 2026-10-07 (docs/1.txt 51-3) — 사람이 P1·P4 에서 누른 구절로 **연구/설교노트·
        온라인영상 목록을 거른다**(그 구절에 연결된 것만 · 칩/X 로 풀린다).

        ⚠ 사람이 누른 것만(`_ai_picked_vid` 와 같은 자리에서 부른다) — 시작할 때 복원한 구절로
          걸면 「구절을 클릭하지 않은 상태 = 지금 그대로」(사용자)가 깨진다.
        ⚠ 지어진 화면만 — 아직 안 지은 화면은 지을 때 `_ai_picked_vid` 로 건다."""
        self._ref_follow = ('VID', vid)
        self._list_vid = vid            # ★ 80-2 — P4 목록들이 지금 따르는 구절(배지는 이 구절만 센다)
        # ★ 80-4 — 주요용어도 그 절의 낱말 목록으로(배지 수 = 목록 수). 안 지은 탭은 지을 때.
        eb = getattr(self, 'entity_browser', None)
        if eb is not None and vid:
            try:
                if eb.left_mode() != 'LEX' or getattr(eb, '_lex_vid', None) != int(vid):
                    eb.show_lexicon(int(vid))
            except Exception as e:
                print('[p4 follow lex] %s' % e)
        for name in ('ref_detail_view', 'kids_view'):
            v = getattr(self, name, None)
            if v is None:
                continue
            try:
                if name == 'kids_view':
                    v.set_verse_filter(vid)
                else:
                    v.set_verse(vid)
            except Exception as e:
                print('[p4 verse follow] %s: %s' % (name, e))
        # ★ 51-4(1) — **P4 에서 누른 연결 상대구절도 P1 구절과 같은 수준으로** P4 탭이 따라온다
        #   (주석 · 주요용어 원어 · 역본비교 · 연구/설교노트 노트 갈래들). 손자·증손자를 쌓지 않고
        #   지금 누른 구절 하나만(51-4(4) 라).
        try:
            cp = getattr(self, 'p4_commentary_panel', None)
            if cp is not None:
                cp.load(int(vid))
        except Exception as e:
            print('[p4 follow comm] %s' % e)
        try:
            self._sync_lexicon(int(vid))
        except Exception:
            pass
        try:
            vc = getattr(self, 'version_compare_view', None)
            if vc is not None:
                vc.load(int(vid))
        except Exception:
            pass
        for name in ('p4_refs_nav', 'p4_refs_text'):
            v = getattr(self, name, None)
            if v is not None:
                try:
                    v.load(int(vid))
                except Exception as e:
                    print('[p4 follow %s] %s' % (name, e))
        self._update_p4_badges(vid)

    def _badges_soon(self):
        """P4 화면의 목록이 바뀌었다 — 배지를 다시(목록 수 = 배지 수 · 80-2)."""
        j = getattr(self, '_badge_job', None)
        if j:
            try:
                self.after_cancel(j)
            except Exception:
                pass

        def go():
            self._badge_job = None
            try:
                self._update_p4_badges(getattr(self, '_p4_badge_vid', None)
                                       or getattr(self, '_list_vid', None))
            except Exception as e:
                print('[badges soon] %s' % e)
        self._badge_job = self.after(120, go)

    def _ref_ctx_follow(self, ctx):
        """★ 2026-10-13 docs/1.txt 79-2 — 도서 편·플랜 하루를 열면 P4 연구/설교노트가 **그 자리로 미리 걸린다**.
        아직 안 지은 화면은 지을 때 건다(`_ref_follow`)."""
        self._ref_follow = ('CTX', ctx)
        self._list_vid = None           # 연구/설교노트는 자리로 · 배지는 그 화면 줄 수(지어진 뒤)
        v = getattr(self, 'ref_detail_view', None)
        if v is not None:
            try:
                v.set_context(ctx)
            except Exception as e:
                print('[ref ctx follow] %s' % e)

    def _update_p4_badges(self, vid):
        """★ 51-4(4) 다 — P4 탭 머리에 **그 구절의 개수**(주석 · 주요용어 낱말 · 연구/설교노트 · 영상).

        세는 문은 P2 배지가 쓰던 `p4_node_panel.tab_counts` 하나(각 패널 count 재사용) —
        영상만 온라인영상 목록과 같은 문(`kids_view.verse_media_count`)으로 센다.
        ⚠ 0 도 (0) 으로 적는다(P2 규칙 — 「없다」와 「안 셌다」를 가른다).
        ⚠ 구절이 없으면 배지를 걷는다(이름만)."""
        base = getattr(self, '_p4_tab_base', {})
        if not base:
            return
        self._p4_badge_vid = vid
        cnt = {}
        # ★★ 2026-10-13 docs/1.txt 80-2 「배지와 실제 목록의 갯수는 무조건 같아야 한다」 —
        #   목록이 그 구절을 따를 때만 센다(사람이 누른 구절 = `_list_vid`). 시작할 때 복원한 구절이면
        #   목록이 그 구절이 아니므로 **배지를 안 단다**. 지어진 탭은 **그 화면이 보이는 줄 수**를 그대로 쓴다.
        if vid and int(vid) != int(getattr(self, '_list_vid', 0) or 0):
            vid = None
        if vid:
            try:
                import p4_node_panel as _np
                _ul = getattr(self, 'lang', 'KO')
                c = _np.tab_counts(self.db_path, int(vid), _ul)
                cnt = {'comm': c.get('comm'), 'entity': c.get('lex'), 'refs': c.get('mine')}
                # ★ 연구/설교노트 탭은 제 언어 콤보(`LANGSEL_REF`)가 있다(1.txt 59-1)
                try:
                    import lang_combo as _LC, refr_unified_panel as _ru
                    _rl = _LC.chosen_lang('LANGSEL_REF', _ul) or _ul
                    if _rl != (_LC.chosen_lang('LANGSEL_REFR', _ul) or _ul):
                        cnt['refs'] = _ru.counts_for(self.db_path, int(vid), _rl).get('mine')
                except Exception:
                    pass
            except Exception as e:
                print('[p4 badges] %s' % e)
            try:
                # ★ 2026-10-16 사용자 「창1:1과 관련한 모든 대화목록이 AI(5)와 같이」 — 그 절을 덮는
                #   구절 채팅 수(업무 무관 · 빈 채팅 빼고). AI 도우미 채팅목록이 같은 문으로 맨 위에 둔다.
                import user_ai as _UA
                with appdb.connect(self.db_path) as _c:
                    cnt['ai'] = _UA.verse_chat_count(_c, int(vid))
            except Exception as e:
                print('[p4 badges ai] %s' % e)
            try:
                import kids_view as _kv
                cnt['kids'] = _kv.verse_media_count(
                    self.db_path, int(vid),
                    _kv.chosen_lang(getattr(self, 'lang', 'KO'), self.db_path))
            except Exception as e:
                print('[p4 badges kids] %s' % e)
        for key, attr in (('entity', 'entity_browser'), ('refs', 'ref_detail_view'),
                          ('kids', 'kids_view')):
            v = getattr(self, attr, None)
            if v is not None and hasattr(v, 'badge_count'):
                try:
                    cnt[key] = v.badge_count()
                except Exception:
                    pass
        self._p4_badge_vals = cnt
        frames = {'comm': self.p4_t15_f, 'entity': self.p4_t4_f,
                  'refs': self.p4_t10_f, 'kids': self.p4_t8_f, 'ai': self.p4_t13_f}
        for key, fr in frames.items():
            ik, ko = base.get(key, ('', key))
            n = cnt.get(key)
            txt = i18n.t(ik, ko) + (' (%d)' % n if n is not None else '')
            try:
                self.p4_nb.tab(fr, text=txt)
            except Exception:
                pass

    def _ai_follow_verse(self, vid):
        """P1 구절이 바뀌면 AI 도우미(지어져 있으면)의 닻이 따라온다(299차 사용자 지시).
        ⚠ 용어 갈래를 보고 있으면 안 건드린다 — 용어 닻은 주요용어가 정한다."""
        v = getattr(self, 'ai_chat_view', None)
        if v is None or not vid:
            return
        try:
            # ★ 317차 — Free 에서도 따라온다(사람이 구절을 눌렀다 = 그 구절을 묻겠다)
            if v.scope() in ('VERSE', 'FREE') and (v.scope() == 'FREE' or v.anchor()[0] != int(vid)):
                v.set_anchor(int(vid))
        except Exception:
            pass

    def _ai_sync_now(self):
        """AI 도우미 탭을 누르면 — 구절 갈래면 지금 P1 구절, 용어 갈래면 주요용어 화면의 용어."""
        v = getattr(self, 'ai_chat_view', None)
        if v is None:
            return
        try:
            if v.scope() == 'REF':
                # ⚠ 연구자료 갈래는 **따라오지 않는다** — 그 닻은 사용자가 연구자료
                #   화면에서 골라 준 것이라 P1 구절이 바뀌었다고 갈아 끼우면
                #   보던 자료를 잃는다(용어 갈래와 같은 규칙).
                return
            if v.scope() == 'TERM':
                eb = getattr(self, 'entity_browser', None)
                eid = getattr(eb, '_current_eid', None) if eb is not None else None
                if eid and v.anchor()[0] != int(eid):
                    v.set_term(int(eid))
            else:
                # ★ 317차 — 사람이 이번 실행에서 고른 구절만(없으면 Free 그대로)
                vid = getattr(self, '_ai_picked_vid', None)
                if vid and (v.scope() == 'FREE' or v.anchor()[0] != int(vid)):
                    v.set_anchor(int(vid))
        except Exception:
            pass

    def _open_ai_ref(self, anchor):
        """연구자료 화면 [AI] — 그 자료를 닻으로 AI 도우미(연구자료 갈래)를 연다.

        ★ 303차 · docs/1.txt 1번 3열 「연구자료 탭에서 연구자료를 선택하고 AI 도우미
          탭으로 이동할 경우 **연구자료 제목이 앵커**가 되어야 함」.
        """
        if not anchor:
            return
        try:
            self._ensure_p4_tab_built(self.P4['ai'])
            self.p4_nb.select(self.p4_t13_f)
            v = getattr(self, 'ai_chat_view', None)
            if v is not None:
                v.set_ref(str(anchor))
        except Exception as e:                            # noqa: BLE001
            print('_open_ai_ref(%s): %s' % (anchor, e))

    def _open_ai_term(self, entity_id):
        """주요용어 화면 [AI] — 그 용어를 닻으로 AI 도우미(용어 갈래)를 연다."""
        if not entity_id:
            return
        try:
            self._ensure_p4_tab_built(self.P4['ai'])
            self.p4_nb.select(self.p4_t13_f)
            v = getattr(self, 'ai_chat_view', None)
            if v is not None:
                v.set_term(int(entity_id))
        except Exception as e:
            print('_open_ai_term(%s): %s' % (entity_id, e))

    def _open_ai_lemma(self, strong):
        """주요용어 화면(승격 안 된 낱말) [AI] — 그 낱말을 닻으로 AI 도우미(용어 갈래)를 연다."""
        if not strong:
            return
        try:
            self._ensure_p4_tab_built(self.P4['ai'])
            self.p4_nb.select(self.p4_t13_f)
            v = getattr(self, 'ai_chat_view', None)
            if v is not None:
                v.set_lemma(str(strong))
        except Exception as e:
            print('_open_ai_lemma(%s): %s' % (strong, e))

    def _ai_note_analysis(self, vid, end_vid=None, book=False):
        """P2 묵상노트 [AI묵상분석] — 그 구절의 내 묵상노트를 AI 에 보내 분석한다(Pick 은 직전값).

        ⚠ 개인 글이 밖으로 나가는 자리다 — **처음 한 번만** 묻고 그 뒤로는 바로 보낸다(`AI_NOTE_SEND_OK`).
        """
        if not vid:
            return
        try:
            import user_ai as _UA
            with appdb.connect(self.db_path) as c:
                ok = _UA.get_setting(c, 'AI_NOTE_SEND_OK', '') == '1'
            if not ok:
                from tkinter import messagebox
                if not messagebox.askokcancel(
                        i18n.t('NR_AI_NOTE', 'AI묵상분석'),
                        i18n.t('NR_AI_NOTE_ASK', '이 구절의 내 묵상노트를 설정한 AI 회사로 보내 분석합니다. '
                                                 '하가 앱은 받거나 모으지 않습니다. 계속할까요? (다음부터는 묻지 않습니다)'),
                        parent=self):
                    return
                with appdb.connect(self.db_path) as c:
                    _UA.set_setting(c, 'AI_NOTE_SEND_OK', '1')
            self._ensure_p4_tab_built(self.P4['ai'])
            self.p4_nb.select(self.p4_t13_f)
            v = getattr(self, 'ai_chat_view', None)
            if v is not None:
                v.analyze_notes_now(int(vid), end_vid, book=book)
        except Exception as e:                            # noqa: BLE001
            print('_ai_note_analysis(%s): %s' % (vid, e))

    def _open_ai_book(self, unit_id):
        """도서 화면 [AI 묵상] — P4 AI 도우미를 그 편 닻으로 열고 첫 걸음을 보낸다(docs/1.txt 81)."""
        try:
            self._ensure_p4_tab_built(self.P4['ai'])
            self.p4_nb.select(self.p4_t13_f)
            v = getattr(self, 'ai_chat_view', None)
            if v is not None:
                v.on_book_note = lambda uid, txt: self.p1_reading_view.save_ai_note(uid, txt)
                v.ask_book_now(int(unit_id))
        except Exception as e:
            print('_open_ai_book(%s): %s' % (unit_id, e))

    def _open_ai_chat(self, start_vid=None, end_vid=None):
        """[AI] 단추 — 지금 구절(또는 구간)을 닻으로 P4 「AI 도우미」 탭을 연다.

        ★ 구절 하나에서 시작한 대화는 그 구절에 매인 자산 하나다(사용자 확정).
        """
        vid = start_vid or getattr(self, '_p1_verse_id', None)
        if not vid:
            return
        try:
            self._ensure_p4_tab_built(self.P4['ai'])
            self.p4_nb.select(self.p4_t13_f)
            v = getattr(self, 'ai_chat_view', None)
            if v is not None:
                v.set_anchor(vid, end_vid)
        except Exception as e:
            print('_open_ai_chat(%s): %s' % (vid, e))

    def _setup_shop_tab(self):
        """Tab — 쇼핑몰(제휴 상품 링크). 좌=안내 / 우=상품 격자."""
        try:
            from shop_view import ShopView
            self.shop_view = ShopView(
                self.p4_t11_f, self.db_path,
                lang_getter=lambda: getattr(self, 'lang', 'KO'))
            self.shop_view.pack(fill='both', expand=True)
        except Exception as e:
            print('[shop tab] %s' % e)

    def _sync_shop_tab(self):
        """상품이 있으면 탭을 보이고 없으면 감춘다.

        ★ **세는 문은 `shop_view.item_count` 하나**다 — 화면이 따로 세면
          「탭은 있는데 비었다」가 난다.
        ⚠ `hide()`/`add()` 는 **번호를 안 밀고 원래 자리로 되돌린다**(실측).
        ⚠ 서버 config 는 시작 몇 초 뒤에 온다 — 한 번 늦게 다시 잰다.
        """
        try:
            from db_shop import item_count
            n = item_count(self.db_path, getattr(self, 'lang', 'KO'))
        except Exception:
            n = 0
        try:
            if n:
                self.p4_nb.add(self.p4_t11_f)
                # ⚠ 이미 지어 둔 화면이면 **다시 그린다** — 지연 빌드는
                #   한 번뿐이라 상품 0일 때 지어졌으면 빈 채로 남는다.
                sv = getattr(self, 'shop_view', None)
                if sv is not None:
                    sv.refresh()
            else:
                # ⚠⚠ 감추기 전에 **그 자리를 비운다** — 고른 탭을 감추면
                #   Tk 가 이웃을 고르고, 그 뒤 누가 `select` 를 한 번만 불러도
                #   감춰 둔 탭이 **도로 살아난다**(hidden → normal).
                if str(self.p4_nb.select()) == str(self.p4_t11_f):
                    self._p4_select_raw(self.P4['link'])
                # ⚠ 직전 탭 기억도 함께 되돌린다 — 안 그러면 지연 빌드가
                #   없는 탭을 지어 **상품 0인 화면이 굽는다**.
                if getattr(self, 'last_p4_tab_idx', 0) == self.P4.get('shop'):
                    self.last_p4_tab_idx = self.P4['link']
                self.p4_nb.hide(self.p4_t11_f)
        except Exception:
            pass
        return n

    def _open_license(self):
        """데이터 출처·라이선스 고지 모달 (현재 언어 적용)."""
        try:
            from license_info import show_license
            show_license(self, lang=getattr(self, 'lang', 'KO'))
        except Exception as e:
            print(f'[license] {e}')

    def _setup_pilgrimage_tab(self):
        """Tab7 — 성지순례 지도 (1단계: 좌표·핀). 배경 이미지는 추후 교체."""
        try:
            from pilgrimage_view import PilgrimageView
            self.pilgrimage_view = PilgrimageView(
                self.p4_t7_f, db_path=self.db_path,
                lang_getter=lambda: getattr(self, 'lang', 'KO'),
                on_place_jump=self._on_genealogy_entity_jump,  # 핀 더블클릭 → Entity Info
                on_verse_jump=self._plan_verse_navigate,       # 정류장·발자취 → P1 본문+P2 주석
                open_license=self._open_license,
                state_get=self._load_state, state_set=self._save_state)
            self.pilgrimage_view.pack(fill='both', expand=True)
        except Exception as e:
            print(f'[pilgrimage tab] {e}')
            tk.Label(self.p4_t7_f, text=f'성지순례 화면 로드 오류: {e}',
                     fg='red').pack(padx=10, pady=10)

    def _setup_kids_tab(self):
        """Tab8 — 온라인 영상. 어린이 영상 / 연결된 영상 / 수화 영상 세 갈래.

        ⚠ P2 링크탭의 오른쪽 플레이어를 없애면서 영상을 이 탭으로 모았다.
          `EmbeddedPlayer` 는 앱을 통틀어 여기 한 벌만 산다(§30).
        """
        try:
            # ★★★ **갈래 둘** (2026-09-10 0.txt 2-3 사용자 「미리 맞춤형 화면」).
            #   [찾아보기] = 대상·유형으로 거르고 검색하는 일반 목록
            #   [맞춤 화면] = 성경듣기 **책 바둑판** · 내 즐겨찾기 **이어듣기**
            #   ⚠ 플레이어를 두 벌 만들지 않는다(§30) — 갈래를 바꿔도 서로의
            #     플레이어를 죽이지 않고, 각 화면이 제 것을 파괴될 때만 끈다.
            # ★★★ **1단은 하나뿐이다** (2026-09-10 0.txt 1-(1) 사용자 배치) —
            #   `Focus │ 검색 ✕ │ 유형·언어 │ 목록·성경듣기·찬양듣기·즐겨찾기
            #   │ 어린이 수화`. 옛 갈래 단추([찾아보기][맞춤 화면])는 걷었다 —
            #   그 자리가 1단의 **화면 단추 넷**이다.
            #   ⚠⚠ 갈래를 걷으면서 **P2 영상링크가 숨은 위젯으로 가던 버그**도
            #     함께 사라진다(`_open_video_online` 이 목록으로 돌아온다).
            from kids_view import KidsView
            self.kids_view = KidsView(
                self.p4_t8_f, db_path=self.db_path,
                lang_getter=lambda: getattr(self, 'lang', 'KO'),
                state_get=self._load_state, state_set=self._save_state)
            self.kids_view.pack(fill='both', expand=True)
            self.kids_view.on_count = self._badges_soon
            # ★ 51-3 — 이미 사람이 고른 구절이 있으면 그 구절로 걸고 연다
            # ⚠ 80-2 — 목록이 따르는 구절(`_list_vid` — 배지가 센 그 구절)로 건다
            _kvid = getattr(self, '_list_vid', None) or getattr(self, '_ai_picked_vid', None)
            if _kvid:
                self.kids_view.after_idle(
                    lambda: self.kids_view.set_verse_filter(_kvid))

            # ⚠⚠ **`PickVideoView` 를 더는 안 만든다**(2026-09-17 · 1.txt 5 재편)
            #   — 성경듣기·찬양듣기·즐겨찾기가 **같은 왼쪽 트리**로 들어왔다.
            #   숨은 채로 만들어 두면 썸네일 스레드까지 함께 도는 낭비다.
            #   파일은 남긴다(되돌릴 자리 · `--selftest` 가 산다).
        except Exception as e:
            print(f'[kids tab] {e}')
            tk.Label(self.p4_t8_f, text=f'온라인 영상 화면 오류: {e}',
                     fg='red').pack(padx=10, pady=10)

    def _setup_version_compare_tab(self):
        """「역본비교」 탭 — 구절 자체의 정보(51-4(2) ①). 말씀의 흐름은 제 탭으로 떼었다."""
        try:
            from version_compare_view import VersionCompareView
            self.version_compare_view = VersionCompareView(
                self.p4_t9_f, self.db_path,
                lang_getter=lambda: getattr(self, 'lang', 'KO'),
                verse_getter=lambda: getattr(self, '_p1_verse_id', None),
                ver_getter=lambda: getattr(self, 'ver', 'KRV'))
            self.version_compare_view.pack(fill='both', expand=True)
            # ⚠ 옛 갈래 단추(`_p4_br_compare.select('compare'|'chain')`)를 부르는 자리가 여럿이다 —
            #   이제 갈래가 아니라 **탭**이므로 그 문을 탭 고르기로 잇는다.
            self._p4_br_compare = _P4BranchShim(self)
        except Exception as e:
            print(f'[version compare tab] {e}')
            tk.Label(self.p4_t9_f, text=f'역본 비교 로드 오류: {e}', fg='red').pack(padx=10, pady=10)

    def _setup_flow_tab(self):
        """「말씀의 흐름」 탭(51-4(2) ② — 구절간 연결). 흐름 단추 줄은 탭 맨 위 띠다."""
        try:
            bar = tk.Frame(self.p4_t14_f)
            ui_theme.bar_height(bar)
            bar.pack(fill='x')
            from chain_detail_view import ChainDetailView
            self.chain_detail_view = ChainDetailView(
                self.p4_t14_f, self.db_path,
                ext_bar=bar,
                lang_getter=lambda: getattr(self, 'lang', 'KO'),
                ver_getter=lambda: getattr(self, 'ver', 'KRV'),
                on_verse_jump=self._chain_goto_verse,
                on_route_jump=self._route_jump)
            self.chain_detail_view.on_link_open = self._tag_asset_jump
            self.chain_detail_view.pack(fill='both', expand=True)
            try:
                self.chain_detail_view.set_bar_visible(True)
            except Exception:
                pass
            if not hasattr(self, '_p4_br_compare'):
                self._p4_br_compare = _P4BranchShim(self)
            self.after_idle(lambda: self.chain_detail_view.show())
        except Exception as e:
            print(f'[flow tab] {e}')
            tk.Label(self.p4_t14_f, text=f'말씀의 흐름 로드 오류: {e}', fg='red').pack(padx=10, pady=10)

    def _setup_comm_tab(self):
        """「주석」 탭(51-4 — P2 에서 옮겨 왔다). 지금 구절(P1·P4 에서 누른 것)을 따른다."""
        try:
            self.p4_commentary_panel = CommentaryPanel(self.p4_t15_f, self.db_path)
            self.p4_commentary_panel.on_download_jump = self._open_download_tab
            self.p4_commentary_panel.pack(fill='both', expand=True)
            vid = getattr(self, '_ai_picked_vid', None) or getattr(self, '_p1_verse_id', None)
            if vid:
                self.p4_commentary_panel.load(vid)
        except Exception as e:
            print(f'[comm tab] {e}')
            tk.Label(self.p4_t15_f, text=f'주석 로드 오류: {e}', fg='red').pack(padx=10, pady=10)

    def _sync_compare_bar(self, key):
        """역본·흐름 탭 갈래 줄 — 흐름 단추(이전·다음·노트·My Edit…)는
        「말씀의 흐름」 갈래에서만 편다 (0.txt 1번 배치)."""
        cd = getattr(self, 'chain_detail_view', None)
        if cd is not None:
            try:
                cd.set_bar_visible(key == 'chain')
            except Exception:
                pass

    def _chain_goto_verse(self, vid):
        """흐름 화면 [이 구절을 중심으로 성경읽기] — P1 성경탐색 탭과 P2
        설명 탭에 포커스 (2026-09-03 0.txt 1번 사용자 지시)."""
        self._plan_verse_navigate(vid)
        try:
            self.p1_nb.select(0)
        except Exception:
            pass
        try:
            self._p2_tabs.select('DESC')
        except Exception:
            pass

    def _open_song_online(self, song_id):
        """P2 찬양에서 곡을 누르면 → P4 「온라인 영상」 탭 (2026-09-17 사용자
        「왼쪽 패널에 클릭한 곡의 곡/판/영상 목록을 모두 표시하면서, 가장 대표적인
        영상을 자동 플레이」). 대표 고르기·자동재생은 `kids_view.show_song` 이 한다."""
        self._ensure_p4_tab_built(self.P4['kids'])
        try:
            self.p4_nb.select(self.p4_t8_f)
        except Exception:
            pass
        kv = getattr(self, 'kids_view', None)
        if kv is None or not hasattr(kv, 'show_song'):
            return
        try:
            kv.show_song(int(song_id))
        except Exception as e:
            print(f'[_open_song_online] {e}')

    def _open_video_online(self, video_id, title=''):
        """링크 탭 영상 → P4 「온라인 영상」 탭에서 재생 (2026-08-19 사용자 —
        예전에는 자료 탭/별도 창으로 열렸다)."""
        self._ensure_p4_tab_built(self.P4['kids'])
        try:
            self.p4_nb.select(self.p4_t8_f)
        except Exception:
            pass
        # ⚠⚠⚠ **재생 자리가 화면에 올라와 있어야 한다**(2026-09-10 실측으로 잡음).
        #   갈래가 「맞춤 화면」이면 KidsView 가 통째로 숨겨져 있어 영상이
        #   **보이지 않는 위젯**으로 간다 — 소리도 그림도 없이 조용히 실패한다.
        #   ⚠ 처음 켠 앱은 갈래 기본값이 `pick`(마지막에 담은 것)이라
        #     **P2 영상링크를 눌러도 아무 일이 안 일어났다.**
        kv = getattr(self, 'kids_view', None)
        if kv is not None:
            try:
                # ★ `play_video` 가 알아서 한다 — 곡 화면을 걷고, **왼쪽 칸을
                #   접고**(1.txt 5-4(1)) 오른쪽에서 튼다.
                kv.play_video(video_id, title)
            except Exception as e:
                print(f'[video online] {e}')

    def _open_chain_detail(self, chain_code, vid=None):
        """구속사연결 탭(P2·오른쪽 패널) → P4 「구속사 연결 설명」 (2026-08-19).

        싱글클릭 규약의 목적지 — **P1 은 여기서 절대 움직이지 않는다.**"""
        self._ensure_p4_tab_built(self.P4['flow'])
        try:
            self.p4_nb.select(self.p4_t14_f)
            self.chain_detail_view.show(chain_code, vid)
        except Exception as e:
            print(f'[chain detail] {e}')

    def _setup_ref_detail_tab(self):
        """연구자료 탭 = [검색하기][작성툴] 두 갈래 (2026-08-20 0.txt 3번 승인).

        검색하기 = 기존 화면(RefDetailView) **그대로 한 칸 아래** — P2·도서 칩·
        플랜·주요용어에서 들어오는 연결(`_open_ref_detail` 4갈래)은 전부 이
        갈래로 떨어진다(밖에서 밀어 넣을 때 갈래를 강제 선택).
        작성툴 = 사용자 user db 연구자료 조립 도구 — 골격만, 내용은 ④에서.
        """
        try:
            from p4_ref_view import RefDetailView
            from branch_tabs import BranchTabs
            bt = BranchTabs(self.p4_t10_f, self.db_path, state_key='P4_BR_REFS')
            self._p4_br_refs = bt
            f_search = bt.frame_for('search')
            self.ref_detail_view = RefDetailView(
                f_search, self.db_path,
                lang_getter=lambda: getattr(self, 'lang', 'KO'),
                on_verse_jump=self._plan_verse_navigate,
                # 연결된 용어를 더블클릭하면 P4 탭4 주요용어로 (가계도와 같은 길)
                on_entity_jump=self._on_genealogy_entity_jump,
                # 도서·설교 콤보 [▶ 보기] → P1 도서/설교 읽기 화면 (2026-08-19 0.txt)
                on_book_jump=self._open_sermon_unit,
                on_my_edit=self._open_verse_link_editor,
                # ★★★ 303차 — [AI] : 지금 보는 연구자료를 **닻으로** AI 도우미를 연다
                #   (docs/1.txt 1번 3열 「연구자료 제목이 앵커가 되어야 함」).
                on_ai=self._open_ai_ref)
            self.ref_detail_view.on_count = self._badges_soon
            # ★ 연결하기 창 결과 → 그 화면으로 (2026-08-24)
            self.ref_detail_view.on_link_open = self._tag_asset_jump
            self.ref_detail_view.pack(fill='both', expand=True)
            # ★ 51-3 — 이미 사람이 고른 구절이 있으면 그 구절로 걸고 연다
            _rf = getattr(self, '_ref_follow', None)        # 마지막으로 걸린 것(구절이든 자리든)
            if _rf and _rf[0] == 'CTX':
                self.ref_detail_view.set_context(_rf[1])
            elif getattr(self, '_ai_picked_vid', None):
                self.ref_detail_view.set_verse(self._ai_picked_vid)
            # 작성툴 (2026-08-20 ④) — 후보 트리 + 발췌 담기 + 블록 초안
            from ref_compose import ComposeView
            f_tool = bt.frame_for('compose')
            self.compose_view = ComposeView(
                f_tool, self.db_path,
                lang_getter=lambda: getattr(self, 'lang', 'KO'),
                ver_getter=lambda: getattr(self, 'ver', 'KRV'),
                # 저장하면 옆 갈래(검색하기) 목록을 갱신하고 그 글을 띄운다
                on_saved=self._on_compose_saved)
            self.compose_view.pack(fill='both', expand=True)
            # ★★★ **「태그 탐색」 갈래를 걷었다**(2026-09-18 사용자 A안 —
            #   「용어 분류값에 하나 추가하고 주요용어 관리화면에서 모두 관리」).
            #   ⚠ 되살릴 까닭이 없다: 그 화면은 **sys 태그만 그렸는데**
            #     2026-09-01 통합 수술로 배포 태그가 0 이 되어 갈래가 이미
            #     감춰져 있었고(`set_visible('tags', bool(_ntag))`), 그 뒤로
            #     **한 줄도 뜬 적이 없다**(실측 목록 0줄).
            #   ⇒ 그 일(태그 하나로 구절·자산을 가로질러 찾기)은 이제
            #     **주요용어 화면**이 한다 — 용례구절·연결 갈래가 그 자리다.
            #   `tag_search_view.py`·`tag_derive.py` 는 `참고코드/` 에 있다.
            # ★ **통합검색** (2026-08-21 사용자 판단) — 팝업이 아니라 **태그 탐색
            #   다음 갈래**로. 「사용자는 태그와 검색의 차이를 모른다. 태그 화면은
            #   P4 에 숨어 있어 검색창으로 접근하려 할 것이다」 — 두 화면을 나란히
            #   두어 차이를 저절로 배우게 한다. P1 상단 [통합검색] 이 이리로 온다.
            # ⚠ 2026-10-11 (docs/1.txt 4-1) — 통합검색은 이 탭의 갈래가 아니다. P4 위에 **덮이는 층**
            #   (`_open_search_all`)으로 옮겼다 — 검색은 앱 전체를 찾는데 한 탭의 하위에 있어 애매했다.
            # ⚠ 갈래 **열쇠는 그대로**(`search`) — 밖에서 들어오는 진입점 넷이
            #   그 키로 이 갈래를 강제 선택한다. 바뀐 것은 **보이는 이름**뿐이다
            #   (2026-08-21 사용자 — 「검색하기가 거슬린다. 자료목록이라 할까」.
            #    그 갈래가 실제로 하는 일은 목록에서 골라 읽는 것이고 검색창은
            #    그 목록을 좁히는 필터일 뿐이라 이름이 실제와 어긋나 있었다).
            # ★ 51-4(3) — P2 에서 걷은 「내부연결」(도서·설교·문답 연결)과 「텍스트」(설교·강해·
            #   읽는 자료 링크)가 갈 곳이 여기다. 두 패널은 P2 의 것과 같은 부품이고 지금 구절을 따른다.
            try:
                # ⚠ 2026-10-11 (docs/1.txt 4-2) — 「내부연결」 갈래를 걷었다. 그것은 읽을 거리가 아니라
                #   다른 화면으로 가는 **길 안내**라 P1 구절 아래 한 줄(「이 구절이 나오는 곳」)로 옮겼다
                #   (`_refresh_nav_here` · `_open_nav_menu`).
                self.p4_refs_nav = None
                from links_panel import LinksPanel as _LP
                self.p4_refs_text = _LP(
                    bt.frame_for('text'), self.db_path,
                    lang_getter=lambda: getattr(self, 'lang', 'KO'),
                    on_video_open=self._open_video_online, mode='TEXT')
                self.p4_refs_text.pack(fill='both', expand=True)
                _v0 = getattr(self, '_ai_picked_vid', None) or getattr(self, '_p1_verse_id', None)
                if _v0:
                    self.p4_refs_text.load(_v0)
            except Exception as _e:
                print('[refs nav/text] %s' % _e)
            bt.add('search', 'REFS_BR_SEARCH', '자료목록')
            bt.add('text', 'P2T_TEXT', '텍스트')
            bt.add('compose', 'REFS_BR_COMPOSE', '작성도구')
            bt.finish()
            bt.pack(fill='both', expand=True)
            # ★ **M402~M405 — 갈래 넷이 한 자리를 나눠 쓴다** (2026-08-22).
            #   갈래마다 단추를 두면 한 줄에 넷이 늘어선다. 자리는 하나이고
            #   **지금 갈래의 매뉴얼**이 열린다(`set_screen_code` 로 갈아 끼운다 —
            #   그 함수는 캔버스/트리뷰 전환용으로 이미 있던 것이다).
            self._REF_MANUAL = {'search': 'U_P4_R_LIST',
                                'compose': 'U_P4_R_COMPOSE'}
            # ⚠ `bar()` 가 아니라 **`manual_slot()`** — M 은 늘 맨 오른쪽이다
            #   (2026-08-30. `side='right'` 는 부른 차례로 쌓여, 늦게 붙는 M 이
            #   오히려 왼쪽에 놓인다).
            self._refs_manual = self._manual_at(
                bt.manual_slot(),
                self._REF_MANUAL.get(bt.current(), 'U_P4_R_LIST'))
            bt.on_change = self._on_refs_branch_manual
            # 갈래 단추 줄 오른쪽에 Focus/Restore (2026-08-20 사용자 — 「화면이
            # 커야 작업하기 쉽다」). P4 를 전체 폭으로 = 기존 캔버스 확장과 같은
            # 장치(v_pw 에서 위 패널을 떼었다 붙인다)를 그대로 쓴다.
            # ⚠⚠ **여기 있던 [Focus]/[Restore] 도 걷었다** (2026-08-30) —
            #   P4 노트북 위 **공통 띠**가 여덟 탭 전부를 맡는다. 같은 일에
            #   단추가 셋(캔버스·연구자료·공통)이면 어느 것이 진짜인지 모른다.
            self._refs_focus_btn = self._refs_restore_btn = None
            ui_theme.bar_height(bt.bar())   # P4 서브탭 공통 높이(32px)
        except Exception as e:
            print(f'[ref detail tab] {e}')
            tk.Label(self.p4_t10_f, text=f'자료 화면 로드 오류: {e}',
                     fg='red').pack(padx=10, pady=10)

    # ── 통합검색 ↔ 태그 탐색 (2026-08-21) ────────────────────────────────
    def _open_search_all(self, q=None):
        """P1 상단 [통합검색] — **P4 위에 덮이는 검색 층**(2026-10-11 docs/1.txt 4-1).

        ★ 팝업도 새 탭도 아니다 — P4 영역 전체를 덮고 [✕ 닫기](Esc)로 걷으면 **보던 탭 그대로**다.
          P1 본문은 그대로 보이고(팝업의 장점) 탭 줄 자리를 안 먹는다(다국어에서 탭이 넘친다).
        ⚠ 결과를 누르면 층을 걷고 그 자료의 탭으로 간다(`_search_jump` 그대로).
        """
        try:
            ov = getattr(self, '_search_ov', None)
            if ov is None or not ov.winfo_exists():
                ov = tk.Frame(self.p4_host, bg=ui_theme.C('panel') or 'white')
                bar = tk.Frame(ov, bg=ui_theme.C('accent_bg') or '#D6EAF8')
                bar.pack(fill='x')
                ui_theme.bar_height(bar)
                _tl = tk.Label(bar, text=i18n.t('REFS_BR_ALL', '통합검색'),
                               bg=ui_theme.C('accent_bg') or '#D6EAF8',
                               fg=ui_theme.C('fg_title') or '#1B2631')
                _tl.pack(side='left', padx=(8, 4))
                try:
                    theme_font.register(_tl, self.db_path, 'ui')
                except Exception:
                    pass
                tk.Button(bar, text='✕ ' + i18n.t('COMMON_CLOSE', '닫기'),
                          command=self._close_search_all,
                          **ui_theme.flat_btn()).pack(side='left', padx=4, pady=2)
                self._manual_at(bar, 'U_P4_R_SEARCH')
                from search_view import SearchView
                self.search_view = SearchView(
                    ov, self.db_path,
                    lang_getter=lambda: getattr(self, 'lang', 'KO'),
                    ver_getter=lambda: getattr(self, 'ver', 'KRV'),
                    on_jump=self._search_jump_close)
                self.search_view.pack(fill='both', expand=True)
                ov.bind_all('<Escape>', lambda _e: self._close_search_all(), add='+')
                self._search_ov = ov
            ov.place(x=0, y=0, relwidth=1, relheight=1)
            ov.lift()
            v = self.search_view
            self.after(120, lambda: v.focus_search(q))
        except Exception as e:
            print('[open search] %s' % e)

    def _close_search_all(self):
        ov = getattr(self, '_search_ov', None)
        if ov is not None and ov.winfo_exists() and ov.winfo_ismapped():
            ov.place_forget()

    def _search_jump_close(self, *a, **k):
        """검색 결과 한 줄 → 층을 걷고 그 화면으로."""
        self._close_search_all()
        return self._search_jump(*a, **k)

    def _search_to_tag(self, tag_id):
        """통합검색 → **주요용어 화면**의 그 「내 용어」 줄 (2026-09-18).

        ⚠ 그전에는 P4 자료 ▸ 「태그 탐색」 갈래로 보냈는데 그 갈래는 sys 태그
          0 이라 **감춰져 있고**, 게다가 그 화면이 내 용어를 안 그렸다 — 눌러도
          아무 일이 없었다(실측). 이제 내 용어도 주요용어 목록에 함께 있다."""
        try:
            self._ensure_p4_tab_built(self.P4['entity'])
            self.p4_nb.select(self.P4['entity'])
            v = getattr(self, 'entity_browser', None)
            if v is not None and hasattr(v, 'select_my_term'):
                self.after(120, lambda: v.select_my_term(int(tag_id)))
        except Exception as e:
            print('[search→myterm] %s' % e)

    def _search_jump(self, kind, tid):
        """통합검색 결과 한 줄 → 그 화면 (2026-08-21).

        ★ **세부 자산이 목적지를 정한다** (사용자 지시 — 「실제 연결은 각 세부
          자산별로 연결되어야 한다. 중요하다」). 화면의 체크칸은 묶음이지만
          여기서는 줄이 들고 온 종류대로 보낸다.
        ⚠ 설명문은 `clicked_id` 의 뜻이 유형마다 달라 **닻을 풀어야** 한다 —
          단락은 그 단락 첫 절, 장은 그 장 1절, 연결설명문은 그 링크의 한쪽 절.
          전부 구절로 여겼다가 「아무것도 연결 안됨」이 됐다(사용자 신고).
        """
        try:
            tid = int(tid)
        except Exception:
            return
        try:
            if kind == 'VERSE':
                self._verse_and_tab(tid, 'DESC', 'lay')
            elif kind == 'PERI':
                self._verse_and_tab(self._first_vid_of_peri(tid), 'DESC', 'peri')
            elif kind == 'CHAP':
                self._verse_and_tab(self._first_vid_of_chap(tid), 'DESC', 'chap')
            elif kind == 'LINK':
                # 연결설명문은 **P4 구절연결**의 것이다 — 그 절을 띄우고 그리로
                self._verse_and_tab(self._one_vid_of_link(tid), None, None,
                                    p4='link')
            elif kind == 'NOTE_VERSE':
                self._verse_and_tab(tid, 'NOTE', 'note')
            elif kind == 'NOTE_NODE':
                self._jump_lens_node(tid)
            elif kind == 'NOTE_BOOK':
                self._tag_asset_jump('BOOK_UNIT', tid)
            elif kind == 'TAG':
                self._search_to_tag(tid)
            elif kind == 'ENTITY':
                self._on_genealogy_entity_jump(tid)
            elif kind == 'PLAN':
                self._tag_asset_jump('PLAN', tid)
            elif kind == 'PLAN_DAY':
                self._jump_plan_day(tid)
            elif kind in ('LENS', 'ULENS'):
                self._tag_asset_jump('LENS', tid)
            elif kind in ('LENS_NODE', 'ULENS_NODE'):
                self._jump_lens_node(tid, user=(kind == 'ULENS_NODE'))
            elif kind in ('BOOK', 'BOOK_UNIT'):
                self._tag_asset_jump('BOOK_UNIT' if kind == 'BOOK_UNIT' else 'BOOK',
                                     tid)
            elif kind == 'REF_UNIT':
                self._open_ref_detail('ARTICLE', tid)
            elif kind == 'USER_REF':
                self._open_ref_detail('USER', tid)
            elif kind == 'VIDEO':
                # ★ 2026-10-22 통합검색 유튜브 — 그 영상을 연구/설교노트 칸의 재생기로(내부자료 영상과 같은 문)
                import re as _re
                _c = appdb.connect(self.db_path)
                try:
                    _r = _c.execute("SELECT url, title FROM sys_media_asset WHERE media_id=?", (tid,)).fetchone()
                finally:
                    _c.close()
                if _r:
                    _m = _re.search(r'(?:v=|youtu\.be/|embed/|shorts/)([A-Za-z0-9_-]{11})', _r[0] or '')
                    if _m:
                        self._open_ref_detail('VIDEO', _m.group(1), _r[1] or '')
            elif kind == 'COMM':
                # 주석본문은 주석/링크 탭으로 이사 (2026-08-26 2안)
                self._verse_and_tab(self._one_vid_of_entry(tid), 'LINKS', 'comm')
            else:
                print('[search jump] 모르는 종류 %s' % kind)
        except Exception as e:
            print('[search jump %s] %s' % (kind, e))

    def _verse_and_tab(self, vid, p2_group=None, branch=None, p4=None):
        """그 절로 가고 **목적지 갈래까지 연다** (2026-08-21 사용자 신고 —
        「구절은 바뀌는데 탭1을 열지 못한다 … 화면만 떨린다」).

        ⚠ 원인은 `_plan_verse_navigate` 가 끝에 **직전 P4 탭으로 되돌리는** 것.
          그래서 통합검색 갈래에 그대로 남아 「떨리기만」 했고, P2 는 아무도
          안 골라 설명 탭이 안 열렸다.
          ⇒ 그 함수는 그대로 두고(플랜·Focus 는 지금 동작이 맞다) **여기서
            한 박자 뒤에 원하는 탭을 명시적으로 고른다.** 구절이 바뀌면 패널이
            다시 그려지므로 `after` 로 그 뒤에 얹는다.
        """
        if not vid:
            return
        self._plan_verse_navigate(int(vid))
        if p4:
            self.after(160, lambda: self._select_p4(p4))
        if p2_group:
            self.after(220, lambda: self._select_p2(p2_group, branch))

    def _open_lens(self, container_id):
        """P1 렌즈묵상 탭 + 그 렌즈 (2026-08-21).

        ⚠ 여기 있던 `self._plan_scope_jump('LENS')` 는 **인자가 모자라 늘
          TypeError** 였다 — 그 함수는 `(enr_or_scope, enrollment_id)` 둘을
          받는다. `_tag_asset_jump` 가 예외를 삼켜 **넉 달째 조용히 아무 일도
          안 했다**(태그 탐색에서 렌즈를 눌러도 안 열렸다. 통합검색 실측에서
          드러났다). ⇒ 탭을 직접 고른다.
        """
        try:
            self._ensure_p1_tab(self._tab_plan)
            self.p1_nb.select(self._tab_plan)
            idx = next((i for i, t in enumerate(self.PLAN_TABS)
                        if t[4] == 'p1_lens_view'), None)
            if idx is not None and hasattr(self, 'p1_plan_nb'):
                self.p1_plan_nb.select(idx)
            v = getattr(self, 'p1_lens_view', None)
            if v is not None and hasattr(v, 'select_container'):
                self.after(200, lambda: v.select_container(int(container_id)))
        except Exception as e:
            print('[open lens] %s' % e)

    def _select_p4(self, key):
        try:
            idx = self.P4.get(key)
            if idx is not None:
                self._ensure_p4_tab_built(idx)
                self.p4_nb.select(idx)
        except Exception as e:
            print('[select p4] %s' % e)

    def _select_p2(self, group, branch=None):
        """「그 갈래로 가라」 — P2 에 있는 것(설명·묵상노트)은 P2 탭으로, 나머지는 그것을 맡은 P4 탭으로.

        부르는 쪽이 옛 이름(그룹·갈래)을 그대로 쓴다: ('DESC', 'lay'|'expert'…) · ('NOTE','note'|'refr'|'nav') ·
        ('LINKS','comm'|'video'|'text'|'song') · 'FLOW'."""
        try:
            b = (branch or '').lower()
            if group == 'DESC':
                key = 'DESC'
            elif group == 'NOTE':
                key = {'refr': 'REFR', 'nav': 'NAV'}.get(b, 'NOTE')
            elif group == 'LINKS':
                key = {'comm': 'COMM', 'text': 'TEXT', 'song': 'SONG', 'lex': 'LEX'}.get(b, 'VIDEO')
            else:
                key = str(group or '').upper()
            if key == 'NAV':
                self._open_nav_menu()
                return
            to_p4 = {'COMM': 'comm', 'REFR': 'refs', 'TEXT': 'refs', 'VIDEO': 'kids',
                     'SONG': 'kids', 'FLOW': 'flow', 'LEX': 'entity'}
            if key in to_p4:
                self._select_p4(to_p4[key])
                br = {'TEXT': 'text', 'REFR': 'search'}.get(key)
                if br and getattr(self, '_p4_br_refs', None) is not None:
                    try:
                        self._p4_br_refs.select(br)
                    except Exception:
                        pass
                return
            if key in ('DESC', 'NOTE'):
                self._p2_tabs.select(key)
                if key == 'DESC' and branch:
                    self._p2_dg.select(branch)          # book/chap/peri/lay/expert
        except Exception as e:
            print('[select p2] %s' % e)

    # ── 닻 풀기 (설명문·주석은 clicked_id 가 구절이 아니다) ────────────────
    def _first_vid_of_peri(self, peri_id):
        with appdb.connect(self.db_path) as c:
            r = c.execute("SELECT start_vid FROM sys_pericope_asset "
                          "WHERE pericope_id=?", (peri_id,)).fetchone()
        return r[0] if r else None

    def _first_vid_of_chap(self, key):
        """`bcode*1000 + 장` → 그 장 1절 (verse_tier.chap_key 의 거울)."""
        b, ch = divmod(int(key), 1000)
        with appdb.connect(self.db_path) as c:
            r = c.execute("SELECT MIN(verse_id) FROM bible_index "
                          "WHERE bcode=? AND chapter=?", (b, ch)).fetchone()
        return r[0] if r else None

    def _one_vid_of_link(self, link_id):
        with appdb.connect(self.db_path) as c:
            r = c.execute("SELECT clicked_id FROM sys_link_asset "
                          "WHERE sys_link_id=?", (link_id,)).fetchone()
        return r[0] if r else None

    def _one_vid_of_entry(self, entry_id):
        with appdb.connect(self.db_path) as c:
            r = c.execute("SELECT start_vid FROM sys_commentary_entry "
                          "WHERE entry_id=?", (entry_id,)).fetchone()
        return r[0] if r else None

    def _jump_plan_day(self, schedule_id):
        with appdb.connect(self.db_path) as c:
            r = c.execute("SELECT plan_id FROM sys_plan_schedule "
                          "WHERE schedule_id=?", (schedule_id,)).fetchone()
        if r:
            self._tag_asset_jump('PLAN', r[0])

    def _jump_lens_node(self, node_id, user=False):
        """노드 → 그 노드를 품은 렌즈를 열고 그 노드를 선택한다."""
        tbl = 'user_link_asset' if user else 'sys_link_asset'
        with appdb.connect(self.db_path) as c:
            r = c.execute("SELECT clicked_id FROM %s WHERE link_type='CONT_NODE' "
                          "AND target_id=? AND COALESCE(record_status,'LIVE')!='HIDE' "
                          "LIMIT 1" % tbl, (node_id,)).fetchone()
        if r:
            self._open_lens(r[0])

    def _tag_asset_jump(self, kind, target_id):
        """자산 한 줄 → 그 화면. **태그 탐색과 연결하기 창이 함께 쓴다.**

        ★★ **연결의 목적은 클릭해서 넘어가는 것**이다(2026-08-24 사용자).
          그런데 연결하기 창의 결과 목록에는 **바인딩이 하나도 없었다** —
          창이 「잇는 도구」로만 만들어지고 「가는 도구」로는 안 만들어졌다.
          ⇒ 여기 한 곳으로 모은다. 갈래가 늘면 여기만 늘린다.
        ⚠ 이미 있는 진입점을 **재사용**한다 — 새 길을 내면 그 길만 또 낡는다.
        """
        kind = str(kind or '').upper()
        try:
            tid = int(target_id)
        except (TypeError, ValueError):
            print('[jump] 번호가 아니다 —', kind, target_id)
            return
        try:
            if kind == 'VERSE':
                self._plan_verse_navigate(tid)
            elif kind == 'TAG':
                self._search_to_tag(tid)
            elif kind in ('LENS', 'ULENS'):
                self._open_lens(tid)
            elif kind in ('NODE', 'UNODE'):
                # ⚠ 노드는 **혼자 열 수 없다** — 부모 렌즈를 찾아 연다.
                #   못 찾으면 조용히 넘어가지 않고 알린다.
                cid = self._lens_of_node(tid, kind == 'UNODE')
                if cid:
                    self._open_lens(cid)
                else:
                    print('[jump] 노드의 렌즈를 못 찾았다 —', kind, tid)
            elif kind == 'BOOK':
                # ⚠⚠ **`BOOK` 은 book_id 다** — 예전에 `BOOK_UNIT` 과 같이 묶어
                #   `_open_sermon_unit(book_id)` 로 보내고 있었다. 그러면 **번호가
                #   겹치는 엉뚱한 편**이 열리거나 아무 일도 안 난다(오류 없음).
                self._route_jump('BOOK', tid)
            elif kind == 'BOOK_UNIT':
                self._open_sermon_unit(tid)
            elif kind == 'REF_UNIT':
                self._open_ref_detail('ARTICLE', tid)
            elif kind == 'USER_REF':
                self._open_ref_detail('USER', tid)
            elif kind == 'PLAN':
                # ⚠ `_plan_view_for` 는 **찾아만 준다**(탭 번호, 뷰) — 옮기고
                #   고르는 것은 여기서(실측으로 확인).
                idx, view = self._plan_view_for(tid)
                self.p1_nb.select(self._tab_plan)
                self.p1_plan_nb.select(idx)
                if view is not None and hasattr(view, 'select_plan'):
                    self.after(200, lambda: view.select_plan(tid))
            # ⚠⚠ **아래 다섯은 길이 없어 「눌러도 아무 일이 없었다」**
            #   (2026-08-31 사용자 신고 「아직도 클릭해도 이동하지 않는 연결자산
            #   들이 있다」). 실측 — 도서 편에 걸린 것 중 **ENTITY 가 171건으로
            #   가장 많은데** 그것이 빠져 있었다. 오류도 안 났다(else 로 흘러
            #   `print` 만 했다). **가장 흔한 것이 가장 늦게 배선됐다.**
            elif kind == 'ENTITY':
                self._on_entity_select(tid)          # P4 주요용어
            elif kind == 'UTAG':
                self._search_to_tag(tid)             # 내 태그도 같은 길
            elif kind == 'PERICOPE':
                v = self._peri_first_vid(tid)
                if v:
                    self._plan_verse_navigate(v)
            elif kind == 'CHAIN':
                # ⚠⚠ **`_select_p4('link')` 은 탭만 바꾸고 아무것도 안 보였다**
                #   (2026-08-31 사용자 신고 「캔버스/연구자료로 연결되는데
                #   표시되는 것은 없다」). 흐름 화면은 **글자 코드**를 받는다 —
                #   통합 표의 번호(`chain_id`)를 `sys_chain_master` 로 되돌린다.
                r = None
                with appdb.connect(self.db_path) as c:
                    r = c.execute("SELECT chain_code FROM sys_chain_master "
                                  " WHERE chain_id=?", (tid,)).fetchone()
                if r:
                    self._open_chain_detail(r[0])
                else:
                    print('[jump] 흐름 코드를 못 찾았다 —', tid)
            elif kind == 'NOTE':
                # ⚠ 노트는 **그 절로 먼저** 가야 목록에 뜬다 — 노트 자체가
                #   구절에 닻을 내리고 있다(`user_text_asset.clicked_id`).
                v = self._note_vid(tid)
                if v:
                    self._plan_verse_navigate(v)
                self._focus_verse_note()
            elif kind == 'MEDIA':
                # ⚠⚠ `_open_ref_detail('VIDEO', …)` 는 **유튜브 id** 를 받는데
                #   여기 넘어오는 것은 `sys_media_asset.media_id` 다 — 그래서
                #   아무것도 안 떴다. url 을 읽어 갈래를 가른다.
                #   ★ 판정은 **`media_link.yt_id` 한 문**(§96차 정본) — 유튜브면
                #     앱 안에서 재생하고, 아니면 브라우저로 연다.
                self._open_media_asset(tid)
            else:
                print('[jump] 아직 길이 없다 —', kind)
        except Exception as e:
            print(f'[jump] {kind} #{target_id}: {e}')

    def _open_media_asset(self, media_id):
        """`sys_media_asset` 한 줄 → 재생 또는 브라우저."""
        # ⚠ 주소를 찾는 문은 `media_link` 하나다 — 화면이 `sys_media_asset` 을
        #   직접 물으면 덮개 검사기(`db_overlay_audit`)가 자리 수를 올린다.
        try:
            import media_link
            with appdb.connect(self.db_path) as c:
                url, title = media_link.asset_url(c, media_id)
        except Exception as e:
            print('[media] %s' % e)
            return
        if not url:
            print('[media] url 이 없다 —', media_id)
            return
        try:
            vid = media_link.yt_id(url)
        except Exception:
            vid = None
        if vid:
            self._open_video_online(vid, title)
        else:
            import webbrowser
            webbrowser.open(url)

    def _peri_first_vid(self, peri_id):
        """단락 → 그 단락의 첫 절. 못 찾으면 None."""
        try:
            with appdb.connect(self.db_path) as c:
                r = c.execute("SELECT start_vid FROM sys_pericope_asset "
                              " WHERE pericope_id=?", (int(peri_id),)).fetchone()
            return r[0] if r else None
        except Exception:
            return None

    def _note_vid(self, note_id):
        """묵상노트 → 그 노트가 닻을 내린 절. 못 찾으면 None."""
        try:
            with appdb.connect(self.db_path) as c:
                r = c.execute("SELECT clicked_id FROM userdb.user_text_asset "
                              " WHERE user_text_id=?", (int(note_id),)).fetchone()
            return r[0] if r else None
        except Exception:
            return None

    def _lens_of_node(self, node_id, is_user=False):
        """노드 → 그 노드를 담은 렌즈(컨테이너) 번호. 없으면 None."""
        tbl = 'user_link_asset' if is_user else 'sys_link_asset'
        col = 'user_link_id' if is_user else 'sys_link_id'
        try:
            with appdb.connect(self.db_path) as c:
                r = c.execute(
                    "SELECT clicked_id FROM %s "
                    " WHERE link_type='CONT_NODE' AND target_id=? "
                    "   AND COALESCE(record_status,'LIVE')='LIVE' "
                    " ORDER BY %s LIMIT 1" % (tbl, col), (int(node_id),)
                ).fetchone()
            return r[0] if r else None
        except Exception as e:
            print('[lens of node] %s' % e)
            return None

    def _research_from_plan(self, ctx):
        """플랜 일차 화면의 연구자료 진입점 (2026-08-19 0.txt ⑩).

        칩 클릭(`open_ref`)이면 그 글을 열고, 아니면 새 글(그 날 첫 구간이 미리
        걸린다). 연결의 앵커는 언제나 **구절**이다 — 플랜은 출처 라벨일 뿐.
        """
        if ctx.get('open_ref'):
            self._open_ref_detail('USER', ctx['open_ref'])
        else:
            self._research_from_reading(ctx)

    def _research_from_reading(self, ctx):
        """도서·설교를 읽다가 [✎ 연구자료 기록하기] → P4 내부자료 탭의 새 글.

        ⚠ 도서 유닛에 기준 구절이 있으면 그것을 미리 걸어 준다. 없으면 구절 없이
          연다 — 도서·엔티티는 구절과 안 이어질 때가 많고, 그것이 연구자료가
          맡는 자리다(별도 「도서묵상노트」를 만들지 않기로 한 이유).
        """
        try:
            if not hasattr(self, 'ref_detail_view'):
                self._setup_ref_detail_tab()
                # ⚠ **9번 탭은 없다** — 0~8 이다. 2026-08-12 통합으로 밀린 옛 번호가
                #   또 남아 있었다(2026-08-16 실측). 그래서 이 탭이 「지어졌다」로
                #   기록되지 않아 다음에 또 짓는다.
                self._built_lazy_tabs.add(self.P4['refs'])
            self.p4_nb.select(self.p4_t10_f)
            br = getattr(self, '_p4_br_refs', None)
            if br is not None:
                br.select('search')
            self.ref_detail_view.show_new(ctx.get('start_vid'), src=ctx)
        except Exception as e:
            print('_research_from_reading: %s' % e)

    #: 탭 줄 칸에 심는 단추의 자리 — **칸을 통째로 채운다**(둘이 같은 크기가 되고 좌우 빈칸이 없다).
    FOCUS_FILL = dict(x=0, y=0, relwidth=1.0, relheight=1.0)

    @staticmethod
    def _focus_swap(hide, show, kw):
        """단추 한 쌍을 바꿔 낀다 — 탭 줄 칸은 `place`, 보통 줄은 `pack`."""
        try:
            if 'relwidth' in kw:
                hide.place_forget()
                show.place(**kw)
            else:
                hide.pack_forget()
                show.pack(**kw)
        except Exception:
            pass

    def _focus_strip(self, nb, style_name):
        """노트북 **탭 줄의 맨 왼쪽** 단추 칸 — 알맹이는 `ui_theme.tab_strip`.

        (2026-09-16 · 1.txt 28 「가장 왼쪽 메인탭의 가장 왼쪽에 배치하라.
         하나만 배치해도 모든 탭에서 자동배치」)
        ⚠⚠ **여기서 다시 짜지 않는다**(2026-09-17) — 주요용어 화면도 같은 칸을
          쓰게 되어 단일 소스로 옮겼다. 두 벌이면 한쪽만 테마 전환에서 깨진다.
        """
        return ui_theme.tab_strip(nb, style_name)

    def _add_p1_focus(self, host, padx=(2, 2)):
        """P1 탭 띠의 **맨 왼쪽**에 [Focus]/[Restore] 한 쌍 (2026-09-16 · 1.txt 10번).
        P1 쪽 Focus 는 **P4 를 접는다**. 쌍은 `_p1_focus_pairs` 에 모아 두고
        `_p1_focus` 가 함께 뒤집는다 — 어느 탭에서 접어도 다른 탭에서 풀 수 있다.
        색 = 테마 역할(`ui_theme.focus_kw` — 분홍/초록 파스텔 · 1.txt 13번)."""
        try:
            f = tk.Button(host, text=i18n.t('UM_FOCUS', 'Focus'),
                          command=lambda: self._p1_focus(True), **ui_theme.focus_kw())
            r = tk.Button(host, text=i18n.t('UM_RESTORE', 'Restore'),
                          command=lambda: self._p1_focus(False),
                          **ui_theme.focus_kw(restore=True))
            if hasattr(host, 'fit'):
                kw = dict(self.FOCUS_FILL)            # 탭 줄 칸 — 칸을 통째로 채운다
            else:
                kw = dict(side='left', padx=padx)
                kids = [k for k in host.winfo_children()
                        if k not in (f, r) and k.winfo_manager()]
                if kids:
                    kw['before'] = kids[0]      # 늘 맨 왼쪽 — 나중에 지어도 앞자리
            pairs = getattr(self, '_p1_focus_pairs', None)
            if pairs is None:
                pairs = self._p1_focus_pairs = []
            pairs.append((f, r, kw))
            _on = getattr(self, '_p1_focused', False)
            (r if _on else f).place(**kw) if 'relwidth' in kw else (r if _on else f).pack(**kw)
            if not hasattr(self, 'btn_p1_focus'):     # 옛 이름 호환
                self.btn_p1_focus, self.btn_p1_restore = f, r
            if hasattr(host, 'fit'):
                host.fit()                            # 탭 줄 칸이면 폭을 맞춘다
            return f, r
        except Exception as e:
            print('[p1 focus add] %s' % e)
            return None, None

    def _p1_focus(self, on):
        """P1 [Focus] — **P4 를 접어** 읽는 화면을 넓힌다 (2026-08-30 사용자 지시).

        ⚠ P4 쪽 `activate_p4_focus_mode` 와 **방향이 반대**다 — 그것은 위(P1·P2)를
          접는다. 같은 이름이지만 접는 대상이 다르므로 한 함수로 합치지 않는다.
        (2026-09-16) 쌍이 여럿이다 — 모든 P1 탭의 쌍을 함께 뒤집는다.
        """
        try:
            if on:
                if str(self.p4_host) in [str(x) for x in self.v_pw.panes()]:
                    self._p4_height = self.p4_host.winfo_height()
                    self.v_pw.forget(self.p4_host)
            else:
                if str(self.p4_host) not in [str(x) for x in self.v_pw.panes()]:
                    self.v_pw.add(self.p4_host,
                                  height=getattr(self, '_p4_height', 300),
                                  minsize=PANE_MIN)
            self._p1_focused = bool(on)
            for f, r, kw in getattr(self, '_p1_focus_pairs', ()):
                try:
                    self._focus_swap(f if on else r, r if on else f, kw)
                    _ = kw
                except Exception:
                    pass
        except Exception as e:
            print('[p1 focus] %s' % e)

    def _refs_focus(self, on):
        """(호환 껍데기) — 2026-08-30 부터 **P4 공통 띠**가 맡는다.

        ⚠ 옛 호출부가 남아 있을 수 있어 이름은 지우지 않는다."""
        (self.activate_p4_focus_mode if on
         else self.deactivate_p4_focus_mode)()

    # ── 연구자료 작성도구 (2026-08-20 ④) ────────────────────────────────
    def _canvas_material(self):
        """지금 캔버스를 작성툴 재료로 — map_source 표준 dict (저장 불필요).

        [✎ 작성툴로] 버튼과 작성툴의 [현재 캔버스] 단추가 함께 쓴다. 살아
        있는 화면을 그대로 넘기므로 「저장하고 오라」는 한 단계가 없다."""
        view = getattr(self, 'p4_view', None)
        if not view or not getattr(view, 'nodes', None):
            return None
        struct = {vid: {'node_id': i.get('node_id'), 'p_id': i.get('p_id'),
                        'x': i.get('x'), 'y': i.get('y'),
                        'rel_label': i.get('rel_label', '')}
                  for vid, i in view.nodes.items()}
        import map_source
        return map_source.parse_struct(
            json.dumps(struct, ensure_ascii=False),
            "|".join(getattr(self, 'current_journey_list', [])))

    def _open_compose_tool(self, from_canvas=True):
        """캔버스/트리뷰 → 연구자료 탭 [작성툴] 갈래 (재료를 들고 간다)."""
        try:
            mat = self._canvas_material() if from_canvas else None
            if not hasattr(self, 'ref_detail_view'):
                self._setup_ref_detail_tab()
                self._built_lazy_tabs.add(self.P4['refs'])
            self.p4_nb.select(self.p4_t10_f)
            br = getattr(self, '_p4_br_refs', None)
            if br is not None:
                br.select('compose')
            # ⚠ **트리가 비어 있을 때만** 자동으로 담는다 (2026-08-20 사용자 —
            #   「경로맵과 무관하게 페리코프로 작업하려는데 추가만 된다」).
            #   이미 재료가 있으면 손대지 않는다 — 담고 싶으면 그쪽 단추로.
            cv = getattr(self, 'compose_view', None)
            if cv is not None and mat and not getattr(cv, '_mat_order', None):
                cv.add_parsed(mat)
        except Exception as e:
            print(f'[compose open] {e}')

    def _on_compose_saved(self, ref_id, doc_lang=None):
        """작성도구 저장 뒤 — 검색하기 갈래에서 그 글을 띄운다.

        ⚠ 검색하기의 목록은 **그 화면 표시 언어**로 걸러진다 — 문서 언어와
          다르면 방금 저장한 글이 목록에 없다(2026-08-20 사용자 혼란의 정체:
          「영어로 되어 있는 상태에서 저장했는데 한국어로 검색되었다」).
          ⇒ 문서 언어에 맞춰 그 화면 언어를 함께 옮긴다."""
        try:
            br = getattr(self, '_p4_br_refs', None)
            if br is not None:
                br.select('search')
            v = self.ref_detail_view
            if doc_lang:
                try:
                    import lang_combo
                    v._lang.set_items(lang_combo.lang_items(),
                                      select=(None, doc_lang))
                    v._on_view_lang()
                except Exception as e2:
                    print(f'[compose saved lang] {e2}')
            v.show_user(ref_id)
        except Exception as e:
            print(f'[compose saved] {e}')

    def _open_ref_detail(self, kind, item_id, title=''):
        """P2 내부자료 목록 → P4 자료 탭. kind: ARTICLE | USER | NEW | VIDEO."""
        try:
            if not hasattr(self, 'ref_detail_view'):
                self._setup_ref_detail_tab()
                # ⚠ 옛 리터럴 9(없는 탭)가 남아 있던 자리 — 표로 (2026-08-20)
                self._built_lazy_tabs.add(self.P4['refs'])
            self.p4_nb.select(self.p4_t10_f)
            # 밖에서 밀어 넣는 글은 언제나 「검색하기」 갈래의 화면이 받는다
            br = getattr(self, '_p4_br_refs', None)
            if br is not None:
                br.select('search')
            v = self.ref_detail_view
            if   kind == 'ARTICLE': v.show_article(item_id)
            elif kind == 'USER':    v.show_user(item_id)
            elif kind == 'NEW':     v.show_new(item_id)
            elif kind == 'VIDEO':   v.show_video(item_id, title)
        except Exception as e:
            print(f'_open_ref_detail({kind}, {item_id}): {e}')

    def _show_version_compare_current(self):
        """역본 비교 탭 진입 시 — 빌드 보장 + 현재 P1 구절로 새로고침.

        ⚠ **`self.P4['refs']`(=8 연구자료)를 짓고 있었다** — 역본비교는 7 이다
          (2026-08-16 실측). 그래서 역본비교 탭을 눌러도 아무 일이 없었다.
          §3 이 「탭 번호를 화면 코드에 흩지 말 것」이라 적어 두고 표(`self.P4`)까지
          만들었는데 **호출부를 다 못 옮긴 자리**다.
        """
        self._ensure_p4_tab_built(self.P4['compare'])
        v = getattr(self, 'version_compare_view', None)
        if v is not None:
            try:
                v.refresh()
            except Exception:
                pass

    def _open_version_compare(self):
        """P1 바 ⇄ → 역본 비교 탭 빌드·선택 + 현재 구절 로드."""
        self._ensure_p4_tab_built(self.P4['compare'])
        try:
            self.p4_nb.select(self.p4_t9_f)
            self._p4_br_compare.select('compare')   # ⇄ 는 역본비교 갈래를 뜻한다
        except Exception:
            pass
        vid = getattr(self, '_p1_verse_id', None)
        if hasattr(self, 'version_compare_view'):
            if vid:
                self.version_compare_view.load(vid)
            else:
                self.version_compare_view.refresh()

    def _open_chapter_compare(self, vid: int):
        """도서 화면 [⇄ 장 비교] → 역본 비교 탭을 **장 비교 모드로** 연다.

        ★ 2026-08-22 사용자 지시 — 「클릭하자마자 장 비교 단추를 누른 것과
          같은 효과」. `_open_version_compare` 와 갈래는 같고 모드만 못 박는다.
        """
        self._ensure_p4_tab_built(self.P4['compare'])
        try:
            self.p4_nb.select(self.p4_t9_f)
            self._p4_br_compare.select('compare')
        except Exception:
            pass
        v = getattr(self, 'version_compare_view', None)
        if v is not None and vid:
            v.load(vid, mode='chapter')

    def _open_sermon_unit(self, unit_id: int):
        """참고자료 탭 설교 클릭 → P1 도서/설교 탭으로 이동."""
        if hasattr(self, 'p1_nb'):
            self._ensure_p1_tab(self._tab_reading); self.p1_nb.select(self._tab_reading)
        if hasattr(self, 'p1_reading_view'):
            self.p1_reading_view.jump_to_unit(unit_id)

    def _open_doctrine_unit(self, ref_unit_id: int):
        """참고자료 탭 '교리 탭으로 이동' 클릭 → P1 교리/자료 탭으로 이동."""
        if hasattr(self, 'p1_nb'):
            self._ensure_p1_tab(self._tab_reading); self.p1_nb.select(self._tab_reading)
        if hasattr(self, 'p1_reading_view'):
            self.p1_reading_view.jump_to_doctrine_unit(ref_unit_id)

    def _on_entity_select(self, entity_id: int, from_vid=None):
        """P2 탭2 / focus_nb 엔티티 클릭 → Tab4 Entity Info 로드.

        ★ `from_vid` — **어느 절에서 눌렀나**(2026-09-01). 의미연결은 본문에
          낱말이 없어 「왜 연결됐지」가 되므로, 주요용어에 **도착하자마자**
          그 연결설명문이 보여야 한다. 화면이 그것을 알려면 출발지가 필요하다.
        ⚠ 검색으로 들어오면 `from_vid` 가 없고, 그때는 설명문을 안 보인다.
        """
        self._ensure_p4_tab_built(self.P4['entity'])   # 객체가 있어야 load_entity 가능
        self._select_p4_quiet(self.p4_t4_f)
        if hasattr(self, 'entity_browser'):
            self.entity_browser.load_entity(
                entity_id,
                # ⚠ 폴백은 **P1 이 지금 보는 절**이다. `last_clicked_vid` 는
                #   P4 캔버스 노드 클릭 값이라 여기서는 틀린 값이다(실측).
                from_vid=from_vid or getattr(self, '_p1_verse_id', None))
            # ★ 라벨로 왔다 — 왼쪽 칸을 접는다(2026-09-15 3모드 「닫힘」)
            try:
                self.entity_browser.set_left_mode('HIDDEN')
            except Exception:
                pass

    def _select_p4_quiet(self, tab):
        """P4 탭을 **프로그램이** 선택한다 — 탭 전환 이벤트가 「사용자가 직접
        눌렀다」로 읽히지 않게 표식을 세운다(주요용어 왼쪽 칸 3모드가 본다).
        ⚠ 이미 그 탭이면 이벤트가 안 나므로 표식도 안 세운다(다음 손 클릭을
          삼키지 않기 위해)."""
        try:
            if self.p4_nb.select() != str(tab):
                self._p4_prog_sel = True
            self.p4_nb.select(tab)
        except Exception:
            self._p4_prog_sel = False

    def _open_lexicon(self):
        """P1 하단 [Lexicon] — 지금 절의 낱말 전부를 P4 주요용어 **원어 모드**로.
        ⚠ 절이 없으면 까닭을 말한다(§0-1)."""
        vid = getattr(self, '_p1_verse_id', None)
        if not vid:
            try:
                import tag_picker
                tag_picker.need_target(self, i18n.t('OC_K_VERSE', '구절'))
            except Exception:
                pass
            return
        self._ensure_p4_tab_built(self.P4['entity'])
        self._select_p4_quiet(self.p4_t4_f)
        if hasattr(self, 'entity_browser'):
            try:
                self.entity_browser.show_lexicon(vid)
            except Exception as e:
                print('[lexicon] %s' % e)

    def _sync_lexicon(self, vid):
        """P1 에서 절이 바뀌면 낱말 칸을 그 절로 다시 편다.

        ⚠ 탭이 아직 안 지어졌으면 **아무 일도 안 한다** — 여기서 지으면 절을
          누를 때마다 안 보는 화면이 올라온다(§29 지연 빌드).
        ⚠ 같은 절이면 다시 안 그린다 — 첫 낱말이 다시 골라져 읽던 자리를 잃는다.
        """
        eb = getattr(self, 'entity_browser', None)
        if eb is None or not vid:
            return
        try:
            if eb.left_mode() != 'LEX' or getattr(eb, '_lex_vid', None) == vid:
                return
            eb.show_lexicon(vid)
        except Exception as e:                       # noqa: BLE001
            print('[lexicon sync] %s' % e)

    def _on_entity_person_select(self, entity_id: int):
        """하위 호환 alias — _on_entity_select 로 위임."""
        self._on_entity_select(entity_id)

    def _on_person_tree_click(self, entity_id: int):
        """Entity Info 탭의 '족보 보기' 버튼 → Tab5."""
        self._ensure_p4_tab_built(self.P4['messiah'])  # 객체가 있어야 highlight 가능
        self.p4_nb.select(self.p4_t5_f)
        if hasattr(self, 'figure_tree'):
            self.figure_tree.highlight(entity_id)

    def _on_person_net_click(self, entity_id: int):
        """⚠ **부르는 곳이 0 이다**(2026-09-26 · 1.txt 20번 1).

        제자 가계도 탭을 걷으면서 `entity_browser` 의 [네트워크 보기] 단추도
        함께 걷었다 — 갈 곳이 없어진 단추는 **빈 서랍**이다(§0-1).
        ★ 되돌릴 자리로 남긴다(탭을 되살리면 이 문과 단추를 함께 되살린다).
        """
        return

    def _figure_peri_nav(self, verse_id: int):
        pass

    def _stop_manual_resize(self, event):
        """[수리] 다른 패널과 간섭 없이, 오직 하단 패널 높이만 저장합니다."""
        if not hasattr(self, 'p4_desc_panel'): return
        
        final_h = self.p4_desc_panel.winfo_height()
        is_focus = not self.top_pw.winfo_ismapped() if hasattr(self, 'top_pw') else False
        
        # 🎯 지정된 높이값만 저장하고 깔끔하게 종료 (raw_id 에러 원천 차단)
        mode_key = "p4_desc_h_focus" if is_focus else "p4_desc_h_normal"
        self._save_state(mode_key, final_h)

    # 3가지 연결범위(VV/+Node/+Cont), 배치옵션 설정 변경시 즉시 반응
    def _on_scope_changed_immediate(self, json_key, var_obj):
        """[수정 2026-06-01] 범위 설정 저장 + 캔버스 자동 reload (실시간 적용)."""
        val = var_obj.get()
        self._save_state(json_key, val)
        self._reload_p4_canvas_if_any()

    # 🎯 [신설 2026-06-01] VERS_VERS 등급 필터 변경 핸들러
    def _on_link_tier_changed(self):
        """등급 라디오(핵심/+확장/+참조) 변경 시 state 저장 + 캔버스 reload."""
        val = self.link_tier_var.get()
        if val not in ('A', 'AB', 'ABC'):
            val = 'AB'
            self.link_tier_var.set(val)
        self.link_tier_filter = val
        self._save_state('link_tier_filter', val)
        self._reload_p4_canvas_if_any()

    def _reload_p4_canvas_if_any(self):
        """[신설 2026-06-01] 현재 P4 캔버스에 root 가 있다면 동일 root 로 reload.
        옵션(scope, tier) 변경 시 즉시 새 데이터로 다시 그림."""
        if not hasattr(self, 'p4_view') or not getattr(self.p4_view, 'nodes', None):
            return
        # 현재 root 노드 찾기 (parent_id 없거나 self 인 노드)
        try:
            root_vid = None
            for vid, info in self.p4_view.nodes.items():
                if not info.get('parent_id') or info.get('parent_id') == vid:
                    root_vid = vid
                    break
            if root_vid is None:
                # fallback: 첫 노드
                root_vid = next(iter(self.p4_view.nodes.keys()), None)
            if root_vid is None:
                return
            pure_id = int(str(root_vid).split('@')[0].split(':')[-1])
            self.p4_view.clear_all()
            self._init_default_map(pure_id)
            self.after(50, self._sync_p4_tree_from_canvas)
        except Exception as e:
            print(f'[reload p4] error: {e}')

    def _sync_opt_btn(self):
        """[캔버스 설정] 오른쪽 **라벨**에 지금 값을 적는다 (2026-09-01 개편).

        옵션을 팝업으로 감추면 「무슨 범위로 보고 있나」가 화면에서 사라진다 —
        `구절연결/핵심/토글` 처럼 한 눈에 남긴다.
        ⚠ 예전에는 단추 라벨 자체에 붙여 단추 폭이 값마다 출렁였다 —
          사용자 지시(0.txt 3번)로 단추 이름은 고정, 값은 옆 라벨로."""
        lbl = getattr(self, '_opt_lbl', None)
        if lbl is None or not lbl.winfo_exists():
            return
        try:
            sc = {1: i18n.t('UM_SCOPE_VERSE', '구절연결'),
                  2: i18n.t('UM_SCOPE_NODE', '+노드')}.get(self.scope_t1_var.get(), '')
            pm = {1: i18n.t('UM_PATH_TOGGLE', '토글'),
                  2: i18n.t('UM_PATH_MULTI', '다중')}.get(self.path_mode_var.get(), '')
            lbl.config(text='(%s/%s)' % (sc, pm))
        except Exception as e:
            print(f'[opt btn] {e}')

    # ====   캔버스 연결범위, 배치항목, 폰트, 맵저장  =====
    def _setup_scope_ctrl(self, parent, var_obj, json_key):
        """[최종종결] 8개 항목 풀세트, 1cm/2cm 간격 준수, 태그 검색 버튼 통합 배치"""
        # ⚠ 예전에는 `side='top'` 이라 **부모 bar 안에 둘째 줄**이 생겼다
        #   (전환 단추 줄 28 + 이 줄 36 = 64px — P4 다른 서브탭의 두 배).
        #   2026-08-20 사용자 「모든 서브탭 bar 높이를 통일하라」 ⇒ 같은 줄에
        #   이어 붙인다. 캔버스 화면(last_scope_t1)만 해당 — 남은 호출부가
        #   생기면 종전대로 제 줄을 쓴다.
        main_f = tk.Frame(parent, bg="#FDFDFD")
        if json_key == "last_scope_t1":
            main_f.pack(side='left', padx=(10, 5), pady=0)
        else:
            main_f.pack(side='top', fill='x', padx=5, pady=5)

        # ★ **옵션 라디오 3묶음(범위·등급·경로)을 [설정] 팝업으로 옮겼다**
        #   (2026-08-20 사용자 — 「캔버스 설정과 검색 옵션을 하나로 통합하면
        #   심플하겠다. 어차피 수시로 수정하지 않는다」). 상단은 **단추 하나**만
        #   남고, 지금 값은 그 단추 라벨에 붙는다(감췄더니 무엇으로 보는지
        #   모르겠다가 되지 않게 — `_sync_opt_btn`).
        #   ⚠ 변수(scope_t1_var·link_tier_var·path_mode_var)는 그대로다.
        #     라디오를 만드는 자리만 팝업으로 옮겼다.
        g1 = None
        try:
            if int(var_obj.get()) > 2:
                var_obj.set(2)
        except Exception:
            pass
        if json_key == "last_scope_t1":
            if not hasattr(self, 'path_mode_var'):
                self.path_mode_var = tk.IntVar(value=getattr(self, 'path_mode', 1))
            if not hasattr(self, 'view_follow_var'):
                self.view_follow_var = tk.IntVar(
                    value=int(self._load_state('canvas_follow', 1) or 0))
            # ★ 2026-09-01 (0.txt 3번) — 이름은 「캔버스 설정」으로 고정하고
            #   지금 값은 **오른쪽 라벨**로 뗐다(_opt_lbl). 서식은 Recent 와
            #   같은 flat_btn(§102차 단추 통일).
            import ui_theme as _uit
            self._opt_btn = tk.Button(
                main_f, text=' %s ' % i18n.t('UM_CANVAS_CFG', '캔버스 설정'),
                command=self.open_layout_settings,
                **_uit.flat_btn(font=("Malgun Gothic", 8, "bold")))
            self._opt_btn.pack(side='left', padx=2)
            # ★ 옵션 값 라벨은 **My Edit 앞** + (괄호) 로 묶는다
            #   (2026-09-01 사용자 지시 — 단추 사이에 끼는 값이라 괄호가
            #   「이건 단추가 아니라 상태」임을 말해 준다).
            self._opt_lbl = tk.Label(main_f, text='',
                                     font=("Malgun Gothic", 8))
            self._opt_lbl.pack(side='left', padx=(2, 2))
            # [MY] — 내 것 총괄 창 (2026-08-27 사용자 「E, My, My Lens,
            #   내자료 … 모든 명칭을 하나로 통합하자」 — 진입 단추 = MY,
            #   95차 전 언어 통일 결정을 끝까지 적용)
            tk.Button(main_f, text=' My Edit ',
                      command=self._open_verse_link_editor,
                      **_uit.flat_btn(font=("Malgun Gothic", 8, "bold"))
                      ).pack(side='left', padx=2)
            # ⚠ 298차의 [AI] 단추를 걷었다(2026-10-11 docs/1.txt 2 · 사용자 「왜 배치되어 있는지 설명하라」 →
            #   의견 「걷는다」에 「진행하라」). 299차부터 AI 탭이 P1 구절을 스스로 따라오고 탭 안에
            #   구절 고르기가 있어 하는 일이 겹쳤고, 캔버스에서 고른 노드가 아니라 P1 구절을 써서 헷갈렸다.
            self._ai_btn = None
            self._sync_opt_btn()
            g1 = self._opt_btn

            # ⚠⚠ **여기 있던 [Focus]/[Restore] 를 걷었다** (2026-08-30) —
            #   P4 노트북 위 **공통 띠**로 올라갔다(모든 탭에서 같은 자리).
            #   색도 함께 사라졌다 — `#E67E22`·`#5D6D7E` 하드코딩이었고 P1 의
            #   Focus 와 모양이 달랐다(사용자 「서식을 통일하라」).
            self.action_btn_area = tk.Frame(main_f)   # 호환용 빈 자리
        # [수리 완료] 이 위치에 있던 중복 티커 바(h_f) 생성 코드를 제거하여 2중 표시 문제를 해결했습니다.
        pass

    def _open_map_manager_popup(self):
        """수동 저장 맵 관리 창을 실행합니다."""
        from map_manager import MapManager 
        
        # 2026-08-12 — 예전에는 여기서 **화면 글자를 읽어** 판정했다
        # (`"Saved Map" in status_text or "수동저장" in status_text`).
        # ⚠ 그 "수동저장" 분기는 **이미 죽어 있었다** — 그 문자열을 라벨에 넣는 코드가
        #   어디에도 없다. 이제 `_update_ui_status_labels` 가 남긴 플래그를 본다.
        is_manual = bool(getattr(self, '_p4_map_is_manual', False))
        
        # 🎯 [확인] 6개 인자(self 포함)가 map_manager.py의 __init__ 순서와 완벽히 일치해야 합니다.
        # self, db_path, lang, ver, current_rid, is_manual
        mgr = MapManager(self, self.db_path, self.lang, self.ver, 
                         current_rid=self.active_node_id, is_manual=is_manual)
        
        mgr.grab_set() 
        self.wait_window(mgr)
        self._refresh_map_switcher_list()

    # 루트를 왼쪽에서 이만큼 띄운다 — 1cm ≈ 40px (2026-08-20 사용자 지시
    # 「최초부모가 왼쪽 화면에서 1cm 이내에」. 옛 기본값 300px 이 5~7cm 였다).
    ROOT_MARGIN_X = 40

    def _focus_home(self):
        """최상위 루트 노드를 왼쪽 1cm · 상하 중앙에 소환합니다."""
        if not hasattr(self, 'p4_view') or not self.p4_view.nodes: return

        # 🎯 [수리] p_id가 None이거나 빈 값인 진짜 루트 노드를 정밀 검색합니다.
        root_vid = next((vid for vid, info in self.p4_view.nodes.items()
                         if info.get('p_id') is None or info.get('p_id') == ""), None)

        if root_vid:
            node = self.p4_view.nodes[root_vid]
            # 🎯 [수리] 캔버스가 좌표를 인지할 시간을 준 뒤 시점을 이동합니다.
            self.p4_view.update_idletasks()
            self.p4_view.focus_on_coordinate(node['x'], node['y'],
                                             margin_x=self.ROOT_MARGIN_X)

    ### [확정] 리셋, 화면의 수동 배치(user_layout_maps)를 삭제하고 자동 배치로 새로고침
    def _reset_current_layout(self):
        """[수정] AUTO 기록을 삭제하고 모든 저장 상태를 무시하여 초기값으로 강제 복구합니다."""
        v_id = getattr(self, 'active_node_id', None)
        if not v_id: return
        pure_id = str(v_id).split(':')[-1]
        label = self.get_asset_name(pure_id, 'BIBLE')
        
        # ★ **AUTO 만 지운다** (2026-08-20 사용자 지적 — 「Reset 이 수동저장된
        #   맵까지 삭제하면 안 된다」). 옛 코드는 종류를 안 가려서 **보존본은
        #   물론 ⚑ 기준점 스냅샷까지** 함께 날렸다(실측 확인 — 데이터 손실).
        #   Reset 의 뜻은 「지금 배치를 초기값으로」이지 「이 구절의 기록 말소」가
        #   아니다. 보존본 삭제는 Manage Maps 가 맡는다.
        with appdb.connect(self.db_path) as conn:
            conn.execute("DELETE FROM user_saved_maps WHERE root_id=? "
                         "AND save_type='AUTO'", (pure_id,))
            conn.commit()

        self.p4_view.clear_all()
        self._update_ui_status_labels(i18n.t('UM_INITSTATUS', '초기화 상태'), False, is_manual=False)
        self._refresh_map_switcher_list()
        self._init_default_map(pure_id)
        self.after(50, self._sync_p4_tree_from_canvas)

    def _fill_text_widget(self, widget, content):
        """구절 설명문 위젯(P2 탭1 · P4 트리뷰 우측 탭1)에 내용을 채운다.

        폰트는 '지원/설정 ▸ 폰트'(READING_FONT)를 따른다 — 이 위젯들은 길게 읽는 본문이다
        (2026-07-30). 이전에는 레거시 `cfg_font_family/size`(app_state)를 **채울 때마다**
        다시 씌워서, 생성 시 적용한 읽기 폰트가 첫 렌더에 바로 덮어써졌다.
        """
        widget.config(state='normal')
        theme_font.apply(widget, self.db_path, 'desc')   # 채울 때마다 — 등록은 생성부에서
        widget.delete('1.0', tk.END)
        widget.insert('1.0', content)
        widget.config(state='disabled')

    def _ensure_p4_tab_built(self, idx):
        """지연 대상 P4 탭(3~5)을 최초 1회만 빌드한다. 탭0~2/이미 빌드된 탭은 no-op.
        주의: 무거운 빌드이므로 탭 클릭 핸들러(<<NotebookTabChanged>>) 안에서 직접 호출 금지.
        jump 경로(객체가 먼저 존재해야 하는 경우)와 시작 시 직전값 탭, 백그라운드 프리빌드에서만 호출."""
        builder = getattr(self, '_lazy_tab_builders', {}).get(idx)
        if builder is None or idx in self._built_lazy_tabs:
            return
        builder()
        self._built_lazy_tabs.add(idx)
        # (P4 Focus/Restore 는 구절연결 탭에만 — 2026-09-16 1.txt 28. `_attach_p4_focus` 는 안 부른다)
        # ⚠ **그 노트북만** 칠한다 — 앱 전체를 칠하면 지연 탭 여덟 번에 전체
        #   훑기가 열여섯 번 돈다(§29 시작 성능).
        self._paint_built(getattr(self, 'p4_nb', None))

    def _post_paint_build_last_p4(self):
        """첫 페인트 후, 직전 P4 탭 내용을 빌드(무거운 가계도면 창 표시 뒤 채워짐). 이후 일반 동작."""
        self._p4_startup = False
        self._tlog('p4 last-tab build start (idx=%s)' % getattr(self, 'last_p4_tab_idx', '?'))
        self._ensure_p4_tab_built(self.last_p4_tab_idx)
        self._tlog('p4 last-tab build done')

    def _prebuild_next_lazy_tab(self):
        """첫 페인트 후, 가벼운 지연 탭(엔티티 등)만 하나씩 백그라운드 빌드한다.
        무거운 가계도(4,5)·미디어(7,8)는 프리빌드 제외 → 첫 클릭 시 빌드(시작 멈춤 방지).
        한 번에 하나만 빌드하고 다음 사이클로 양보."""
        for idx in (3,):
            if idx not in self._built_lazy_tabs:
                self._tlog('prebuild entity(idx3) start')
                self._ensure_p4_tab_built(idx)
                self._tlog('prebuild entity(idx3) done')
                self.after(50, self._prebuild_next_lazy_tab)
                return

    # 캔버스/트리뷰 탭 사이에 변경시  index를 DB에 저장, on_verse_selected를 재호출, 범위에 맞는 데이터가 즉시 탐색
    def _on_p4_tab_changed(self, event):
        """P4 탭 변경 시 index 저장 + 족보↔네트워크 탭 간 인물 동기화."""
        idx = self.p4_nb.index("current")
        # 지연 탭이 아직 안 빌드됐으면 유휴 시간에 빌드한다(거의 발생 안 함 — 프리빌드가 선점).
        # 핸들러 안에서 동기 빌드하면 UI 블로킹 + 1×1 geometry 회귀 → 절대 금지. after_idle로 양보.
        # 시작 시 직전탭 선택(_p4_startup)에서는 빌드를 페인트 후 타이머가 맡으므로 여기선 생략.
        if (idx in getattr(self, '_lazy_tab_builders', {}) and idx not in self._built_lazy_tabs
                and not getattr(self, '_p4_startup', False)):
            self.after_idle(lambda i=idx: self._ensure_p4_tab_built(i))
        self._save_state("last_p4_tab", idx)
        self.last_p4_tab_idx = idx
        # ★ 주요용어 탭을 **손으로** 누르면 검색 모드 (2026-09-15 3모드).
        #   프로그램이 고른 것(라벨·Lexicon)은 `_p4_prog_sel` 표식이 가린다.
        try:
            if self.p4_nb.select() == str(getattr(self, 'p4_t4_f', None)):
                if getattr(self, '_p4_prog_sel', False):
                    self._p4_prog_sel = False
                elif hasattr(self, 'entity_browser') \
                        and not getattr(self, '_p4_startup', False):
                    self.entity_browser.set_left_mode('SEARCH')
        except Exception:
            pass
        # ⚠ 지연 탭이 아닌 탭(빌드 고리를 안 탄다)도 여기서 붙는다. 멱등이다.

        current_tab = self.p4_nb.select()
        # ★ 299차 — AI 도우미 탭이면 지금 구절/용어로 닻을 맞춘다(지연 빌드 뒤에도 한 번 더)
        try:
            if current_tab == str(getattr(self, 'p4_t13_f', None)):
                self._ai_sync_now()
                self.after(300, self._ai_sync_now)
        except Exception:
            pass

        # ── 이용통계: P4 화면 히트 ──
        #   ★ 2026-10-20 — 탭 위젯 이름 대신 self.P4 이름으로 고른다(탭이 늘거나 옮겨도 안 갈린다).
        #   ⚠ 옛 「어린이 모드 게이트」는 그 탭이 온라인 영상이 된 뒤로 뜻을 잃었다 —
        #     영상 탭을 여는 동안 모든 기록이 멈춰 있었다. 걷는다(늘 꺼짐).
        #   ⚠ 코드 p4_canvas · media 는 그대로(바꾸면 지난 값과 갈린다).
        try:
            import usage_stats
            usage_stats.set_kids_mode(False)
            _idx = self.p4_nb.index(current_tab)
            _name = {v: k for k, v in self.P4.items()}.get(_idx)
            _c = {'compare': 'p4_compare', 'link': 'p4_canvas', 'flow': 'p4_flow',
                  'comm': 'p4_comm', 'entity': 'p4_terms', 'refs': 'p4_refs',
                  'kids': 'p4_video', 'ai': 'p4_ai', 'messiah': 'p4_geneal_m',
                  'pilgrimage': 'p4_pilgrim', 'news': 'media', 'shop': 'p4_shop'}.get(_name)
            if _c:
                usage_stats.screen_hit(_c)
        except Exception:
            pass

        # Tab5(메시아 가계도) 활성화 시
        if current_tab == str(self.p4_t5_f):
            self._last_entity_tab = 'messianic'
        # ⚠ 제자 가계도 분기는 탭 폐지(2026-09-26)로 걷었다.
        # ★ **번호를 적지 않는다** (2026-08-16). 2026-08-12 통합으로 탭이 하나씩
        #   당겨졌는데 여기 세 분기가 옛 번호를 그대로 써서 **엉뚱한 탭에서** 돌았다:
        #     `idx==2` → 리포트가 아니라 **주요용어**에서 리포트 목록을 새로 읽고
        #     `idx==8` → 역본비교가 아니라 **연구자료**에서 역본비교를 새로고침했다.
        #   그래서 「역본비교 탭을 누르면 빈 화면」이었다(사용자 지적).
        #   ⚠ `idx==1` 의 `_sync_p4_tree_from_canvas` 는 **없어진 트리뷰 탭**의 것이라 뺐다.
        if idx == self.P4['link']:
            self._sync_canvas_from_tree()
        elif idx == self.P4['compare']:
            # 역본 비교 탭 진입 — 빌드 후 현재 구절로 새로고침(빈 화면 방지)
            self.after_idle(self._show_version_compare_current)

    def _migrate_p4_tab_numbers(self):
        """저장된 P4 탭 번호 이주 — 리포트 폐지·연구자료 1번 이사 (2026-08-20, 1회).

        옛 배열 [0 구절연결, 1 리포트, …, 8 연구자료] → 새 배열에서 바뀌는 것은
        **연구자료 8→1** 과 사라진 **리포트 1→0** 둘뿐이다(2~7 그대로).
        대상 = `last_p4_tab` · ⚑ 핀 스냅샷의 P4 탭 칸.
        ⚠ 두 번 돌면 1(연구자료)이 0 으로 밀린다 — 깃발로 한 번만."""
        FLAG = 'p4_tab_migrated_20260820'
        try:
            if self._load_state(FLAG, 0):
                return
            remap = {8: 1, 1: 0}
            old = int(self._load_state('last_p4_tab', 0) or 0)
            if old in remap:
                self._save_state('last_p4_tab', remap[old])
            pins = self._load_state('pin_points', []) or []
            changed = False
            for p in pins:
                try:
                    if len(p) > 3 and p[3] in remap:
                        p[3] = remap[p[3]]
                        changed = True
                except Exception:
                    continue
            if changed:
                self._save_state('pin_points', pins)
            self._save_state(FLAG, 1)
        except Exception as e:
            print(f'[p4 tab migrate] {e}')

    def _migrate_p1_tab_20260926(self):
        """저장된 P1 탭 번호 이주 — 최신 콘텐츠가 P4 로 떠났다 (1회).

        옛 배열 [0 성경읽기, **1 최신콘텐츠**, 2 묵상플랜, 3 도서/설교,
        4 나의묵상, 5 공지/소통, 6 설정]
        새 배열 [0 성경읽기, 1 묵상플랜, 2 도서/설교, 3 나의묵상,
        4 공지/소통, 5 설정]

        ⚠ **최신콘텐츠(1)는 갈 곳이 없다** — 성경읽기(0)로 보낸다.
        ⚠ 2 이상은 **한 칸씩 당겨진다.** 안 옮기면 켤 때 엉뚱한 탭이 열린다.
        ⚠ **깃발로 한 번만** — 두 번 돌면 또 당겨진다.
        """
        FLAG = 'p1_tab_migrated_20260926'
        try:
            if self._load_state(FLAG, 0):
                return
            old = int(self._load_state('last_p1_tab', 0) or 0)
            new = 0 if old <= 1 else old - 1
            if new != old:
                self._save_state('last_p1_tab', new)
            self._save_state(FLAG, 1)
        except Exception as e:
            print('[p1 tab migrate 0926] %s' % e)

    def _migrate_p4_tab_20261007(self):
        """저장된 P4 탭 번호 이주 — 51-4 재편 (1회 · 깃발).

        옛 [0 구절연결, 1 역본·흐름, 2 연구, 3 용어, 4 메시아, 5 발자취, 6 영상, 7 최신, 8 쇼핑, 9 AI]
        새 [0 역본, 1 구절연결, 2 흐름, 3 주석, 4 용어, 5 연구, 6 영상, 7 AI, 8 메시아, 9 발자취,
           10 최신, 11 쇼핑]
        ⚠ 대상 = `last_p4_tab` · ⚑ 핀 스냅샷의 P4 탭 칸(옛 이주와 같은 자리)."""
        FLAG = 'p4_tab_migrated_20261007'
        try:
            if self._load_state(FLAG, 0):
                return
            remap = {0: 1, 1: 0, 2: 5, 3: 4, 4: 8, 5: 9, 6: 6, 7: 10, 8: 11, 9: 7}
            old = int(self._load_state('last_p4_tab', 0) or 0)
            if old in remap:
                self._save_state('last_p4_tab', remap[old])
            pins = self._load_state('pin_points', []) or []
            changed = False
            for p in pins:
                try:
                    if len(p) > 3 and p[3] in remap:
                        p[3] = remap[p[3]]
                        changed = True
                except Exception:
                    continue
            if changed:
                self._save_state('pin_points', pins)
            self._save_state(FLAG, 1)
        except Exception as e:
            print('[p4 tab migrate 1007] %s' % e)

    def _migrate_p4_tab_20260926(self):
        """저장된 P4 탭 번호 이주 — 제자 가계도 폐지 · 역본·말씀흐름 이사 (1회).

        옛 배열 [0 구절연결, 1 연구자료, 2 주요용어, 3 메시아, **4 제자**,
        5 발자취, 6 온라인영상, **7 역본**, 8 쇼핑몰]
        새 배열 [0 구절연결, **1 역본**, 2 연구자료, 3 주요용어, 4 메시아,
        5 발자취, 6 온라인영상, 7 쇼핑몰]

        ⚠ **제자(4)는 갈 곳이 없다** — 구절연결(0)로 보낸다. 조용히 사라지는
          대신 늘 있는 탭으로 떨어뜨린다.
        ⚠ 5·6 은 그대로라 표에 안 적는다(적으면 두 번 도는 사고가 잘 난다).
        ⚠ 대상 = `last_p4_tab` · ⚑ 핀 스냅샷의 P4 탭 칸. **깃발로 한 번만.**
        """
        FLAG = 'p4_tab_migrated_20260926'
        try:
            if self._load_state(FLAG, 0):
                return
            remap = {1: 2, 2: 3, 3: 4, 4: 0, 7: 1, 8: 7}
            old = int(self._load_state('last_p4_tab', 0) or 0)
            if old in remap:
                self._save_state('last_p4_tab', remap[old])
            pins = self._load_state('pin_points', []) or []
            changed = False
            for p in pins:
                try:
                    if len(p) > 3 and p[3] in remap:
                        p[3] = remap[p[3]]
                        changed = True
                except Exception:
                    continue
            if changed:
                self._save_state('pin_points', pins)
            self._save_state(FLAG, 1)
        except Exception as e:
            print('[p4 tab migrate 0926] %s' % e)

    def _build_canvas_action_btns(self, bar):
        """[Home][Reset][Maps ▾][Save] — 상단 bar 오른쪽.

        2026-08-20 사용자 지시로 캔버스 전용 줄에서 여기로 옮겼다. 캔버스 줄은
        Journey 경로만 남는다. ⚠ side='right' 는 **먼저 pack 한 것이 오른쪽**
        이므로 원하는 차례의 역순으로 붙인다.
        ⚠ [연구자료작성] 단추는 2026-09-01 사용자 지시(0.txt 3번)로 걷었다 —
          연구자료 작성은 P4 연구자료 탭·P2 [My Edit] 이 맡는다.
          `_open_compose_tool` 은 남겨 둔다(다른 진입점이 부른다).
        ⚠ [Manage] 단추도 걷었다 (2026-09-01 0.txt 3번) — 그 기능(보존 맵의
          이름 고치기·삭제)은 **Maps ▾ 팝업 머리의 [관리…]** 로 들어간다.
          맵을 고르는 자리와 맵을 관리하는 자리가 한 문이어야 찾는다."""
        _kw = dict(font=("Malgun Gothic", 8, "bold"), bd=0, padx=6, pady=2)
        tk.Button(bar, text=" Save ", command=self._save_manual_layout,
                  bg="#27AE60", fg="white", **_kw).pack(side='right', padx=2, pady=2)
        # 맵 목록은 Recent 팝업 문법(콤보 폐지 — 출발·종착·종류를 함께 보인다)
        self._map_btn = tk.Button(bar, text=i18n.t('UM_MAPS', ' Maps ▾ '),
                                  bg="#D6EAF8", fg="#1A5276",
                                  command=self._open_map_popup, **_kw)
        self._map_btn.pack(side='right', padx=2, pady=2)
        self._map_pop = None
        tk.Button(bar, text=" Reset ", command=self._reset_current_layout,
                  bg="#E74C3C", fg="white", **_kw).pack(side='right', padx=2, pady=2)
        tk.Button(bar, text=" Home ", command=self._focus_home,
                  bg="#3498DB", fg="white", **_kw).pack(side='right', padx=(8, 2), pady=2)

    def _sync_canvas_style(self):
        """저장된 캔버스 설정(글꼴·크기·굵기·상자 폭)을 캔버스에 심는다.

        ★ 2026-08-20 — 다시 그리는 자리(구절 클릭·옵션 변경·맵 복원)가
          스타일을 안 넘겨서 **설정이 초기값으로 되돌아간 것처럼** 보였다.
          값은 저장돼 있었다. 이제 캔버스가 마지막 설정을 들고 있는다."""
        v = getattr(self, 'p4_view', None)
        if v is None:
            return
        try:
            v.style_defaults = {
                'font_family': getattr(self, 'cfg_font_family', 'Malgun Gothic'),
                'font_size': int(getattr(self, 'cfg_font_size', 9) or 9),
                'line_bold': int(getattr(self, 'cfg_line_bold', 1) or 0),
                # 렌즈노드 박스 규격 — 캔버스가 이름을 줄바꿈할 때 쓴다
                'node_mode': str(getattr(self, 'cfg_node_mode', 'H') or 'H').upper(),
                'node_lines': int(getattr(self, 'cfg_node_lines', 1) or 1),
                'node_chars': int(getattr(self, 'cfg_node_chars', 14) or 14),
            }
        except Exception as e:
            print(f'[canvas style] {e}')

    def _auto_focus(self, x, y, margin_x=None):
        """**자동** 시점 이동 — 「고정」 이면 아무 일도 안 한다 (2026-08-20).

        사용자: 「새 박스가 펼쳐지면서 과거 박스가 왼쪽으로 자동이동해 보고
        있던 맥락을 놓친다. 고정/자동이동을 옵션으로」.
        ⚠ **사람이 직접 시킨 이동은 이 함수를 쓰지 않는다** — [Home] 단추,
          ⚑ 기준점 복귀, 맵 열기는 그 자체가 「거기로 가겠다」는 뜻이라
          `focus_on_coordinate` 를 그대로 부른다."""
        try:
            if not int(getattr(self, 'view_follow_var', None).get()
                       if hasattr(self, 'view_follow_var')
                       else self._load_state('canvas_follow', 1) or 0):
                return
        except Exception:
            pass
        if margin_x is None:
            self.p4_view.focus_on_coordinate(x, y)
        else:
            self.p4_view.focus_on_coordinate(x, y, margin_x=margin_x)

    def _sync_canvas_from_tree(self):
        """Tab1(Tree)→Tab0(Canvas) 전환 시 트리 선택 노드로 캔버스를 pan합니다."""
        if not hasattr(self, 'focus_tree'): return
        sel = self.focus_tree.selection()
        if not sel: return
        v_id = self.focus_tree.item(sel[0], "values")[0]
        info = self.p4_view.nodes.get(v_id)
        if info:
            self._auto_focus(info['x'], info['y'])     # 「고정」이면 안 움직인다

    def on_node_click(self, raw_id, view_id):
        """[완전수리] 계보 계산, 여정 누적, DB 자동저장, 화면 갱신을 한 번에 처리합니다."""
        self.last_clicked_vid = raw_id
        # 트리 동기화가 남기는 선택 메아리를 가려내기 위한 표식(2026-08-20)
        self._last_canvas_click_vid = view_id
        
        # 1. 🧬 계보 엔진: 현재 클릭한 노드로부터 루트까지의 경로를 계산
        lineage = self._calculate_id_lineage(view_id)
        if lineage:
            self.current_journey_list = list(reversed(lineage))
        
        # 2. 🧩 화면 정돈: Toggle_off 모드일 때 형제 가지 제거
        if hasattr(self, 'path_mode_var') and self.path_mode_var.get() == 1:
            self.p4_view.clear_sibling_branches(view_id)
            self._sync_p4_tree_from_canvas()

        # 3. 👣 티커 동기화: 상단 'Journey' 라벨 업데이트
        self._update_journey_ticker()
        
        # 4. 💾 DB 저장: 누적된 여정을 path_string 컬럼에 즉시 기록
        self._safe_auto_save_workbench() 
        
        # 5. 🎞️ 화면 표시: 하단 패널에 미디어 및 상세 정보 출력
        self.refresh_p4_film_strip(int(str(raw_id).split(':')[-1]))
        # ★ 317차 — 캔버스 구절을 눌러도 AI 도우미가 그 구절로 온다(P1 과 같은 규칙)
        try:
            self._ai_picked_vid = int(str(raw_id).split(':')[-1])
            self._ai_follow_verse(self._ai_picked_vid)
            self._p4_verse_follow(self._ai_picked_vid)
        except Exception:
            pass

        # 6. 통합 슬라이딩 패널 표시 (옵션 C — 노드 클릭 → 탭1 컨텍스트)
        try:
            parent_view_id = self.p4_view.nodes.get(view_id, {}).get('p_id')
            self.p4_node_panel.show_node(view_id, parent_view_id)
        except Exception as _e:
            print(f'[NodePanel show_node] {_e}')

        # [2026-06-04 옵션 B] P4 노드 클릭은 P2를 갱신하지 않음.
        # P2 5탭은 오직 P1 구절 클릭(on_verse_selected)에만 반응.
        # P4 노드의 상세는 위 NodePanel(p4_node_panel)이 단독으로 표시.

        # 8. (2026-08-12) 예전에는 여기서 트리뷰 워크벤치의 `focus_links` 를 따로 갱신했다.
        #    통합 뒤에는 바로 위 `show_node` 가 NodePanel 의 링크 탭까지 함께 채우므로
        #    같은 일을 두 번 하지 않는다.

    def _refresh_nav_here(self, verse_id):
        """P1 「이 구절이 나오는 곳 N」 — 도서·설교·문답 편 수(2026-10-11 docs/1.txt 4-2)."""
        btn = getattr(self, '_ticker_nav_btn', None)
        if btn is None:
            return
        try:
            from refr_unified_panel import nav_rows
            self._nav_here = nav_rows(self.db_path, verse_id, getattr(self, 'lang', 'KO')) if verse_id else []
        except Exception as e:
            print('[nav here] %s' % e)
            self._nav_here = []
        n = len(self._nav_here)
        if n:
            btn.config(text='%s (%d) ▾' % (i18n.t('UM_NAV_HERE', '이 구절을 다룬 자료'), n))
            if not btn.winfo_ismapped():
                btn.pack(side='left', padx=(0, 4), after=self._ticker_lex_btn)
                self._ticker_nav_sep.pack(side='left', fill='y', pady=4, padx=(0, 4), after=btn)
        else:
            btn.pack_forget()
            self._ticker_nav_sep.pack_forget()

    def _open_nav_menu(self, *_a):
        """「이 구절이 나오는 곳」 목록 — 선택하면 도서/설교집 화면의 그 편으로 간다."""
        rows = list(getattr(self, '_nav_here', []) or [])
        btn = getattr(self, '_ticker_nav_btn', None)
        if not rows or btn is None:
            return
        try:
            from refr_unified_panel import _navkind_label
        except Exception:
            _navkind_label = lambda k: k
        m = tk.Menu(self, tearoff=0)
        for r in rows[:60]:
            kind = r.get('kind') or r.get('nav_type')
            lbl = '%s  %s' % (_navkind_label(kind).lstrip('▸'), r.get('line') or '')
            if r.get('nav_type') == 'REF':
                cmd = (lambda i=r['id']: self._open_doctrine_unit(int(i)))
            else:
                cmd = (lambda i=r['id']: self._open_sermon_unit(int(i)))
            m.add_command(label=lbl[:110], command=cmd)
        try:
            m.tk_popup(btn.winfo_rootx(), btn.winfo_rooty() - min(len(rows), 60) * 22 - 6)
        finally:
            m.grab_release()

    def _refresh_entity_ticker(self, verse_id: int):
        """구절에 연결된 엔티티를 조회해 티커 칩을 재구성한다."""
        if not hasattr(self, '_ticker_inner'):
            return
        self._refresh_nav_here(verse_id)
        for w in self._ticker_inner.winfo_children():
            w.destroy()

        # 유형 정렬 — 빠진 것이 있으면 회색 기본값으로 맨 뒤에 밀린다.
        # NATION(23)·DOCTRINE(51)이 실제로 그렇게 밀려 있었다 (2026-08-09 발견).
        _type_order = ['PERSON', 'PLACE', 'FEAST', 'OBJECT', 'SYSTEM',
                       'GROUP', 'NATION', 'IDOL', 'DOCTRINE', 'TERM']

        try:
            with appdb.connect(self.db_path) as conn:
                peri_row = conn.execute(
                    "SELECT pericope_id FROM sys_pericope_asset p "
                    "WHERE p.peri_type='BODY' AND "
                    + _vr.covers_sql('p', 'start_vid', 'end_vid')
                    + " ORDER BY (p.end_vid - p.start_vid) ASC LIMIT 1",
                    _vr.covers_args(verse_id)
                ).fetchone()
                if not peri_row:
                    return
                peri_id = peri_row[0]

                lang = getattr(self, 'lang', 'KO')
                rows = conn.execute(
                    "SELECT em.entity_id, em.entity_type, "
                    "  COALESCE("
                    "    (SELECT ta.contents FROM sys_text_asset ta "
                    "     WHERE ta.text_type='ENTITY_NAME' AND ta.clicked_id=em.entity_id "
                    "     AND ta.lang_code=? AND ta.record_status='LIVE' LIMIT 1), "
                    "    (SELECT ta.contents FROM sys_text_asset ta "
                    "     WHERE ta.text_type='ENTITY_NAME' AND ta.clicked_id=em.entity_id "
                    "     AND ta.lang_code='EN' AND ta.record_status='LIVE' LIMIT 1), "
                    "    (SELECT ta.contents FROM sys_text_asset ta "
                    "     WHERE ta.text_type='ENTITY_NAME' AND ta.clicked_id=em.entity_id "
                    "     AND ta.lang_code='KO' AND ta.record_status='LIVE' LIMIT 1)"
                    "  ) AS name "
                    # ★ 2026-08-24 통합 표(`ENTI_PERI`) — A=용어 · B=단락
                    "FROM sys_link_asset ep "
                    "JOIN sys_entity_master em ON em.entity_id=ep.clicked_id "
                    "WHERE ep.link_type='ENTI_PERI' AND ep.target_id=? "
                    "  AND COALESCE(ep.record_status,'LIVE')='LIVE' "
                    "  AND em.record_status='LIVE' "
                    "ORDER BY (ep.milestone_type IS NOT NULL) DESC, ep.importance DESC",
                    (lang, peri_id)
                ).fetchall()
        except Exception:
            return

        # ★ 절 단위 연결(sys_entity_verse)을 함께 읽어 **앞에** 놓는다 (2026-08-09).
        #   페리코프 연결은 「이 단락 어딘가에 있다」이고 절 연결은 「이 절에 있다」다.
        #   클릭한 그 절에 실제로 있는 것이 먼저 와야 한다. 층위가 다르므로
        #   색만으로 구분하지 않고 순서로도 구분한다.
        vrows = []
        try:
            with appdb.connect(self.db_path) as conn:
                vrows = conn.execute(
                    "SELECT em.entity_id, em.entity_type, "
                    "  COALESCE("
                    "    (SELECT ta.contents FROM sys_text_asset ta "
                    "     WHERE ta.text_type='ENTITY_NAME' AND ta.clicked_id=em.entity_id "
                    "     AND ta.lang_code=? AND ta.record_status='LIVE' LIMIT 1), "
                    "    (SELECT ta.contents FROM sys_text_asset ta "
                    "     WHERE ta.text_type='ENTITY_NAME' AND ta.clicked_id=em.entity_id "
                    "     AND ta.lang_code='EN' AND ta.record_status='LIVE' LIMIT 1)"
                    "  ) AS name "
                    # ★ 2026-08-24 통합 표(`ENTI_VERS`) — A=용어 · B=구절
                    ", ev.rel_code "
                    "FROM sys_link_asset ev "
                    "JOIN sys_entity_master em ON em.entity_id=ev.clicked_id "
                    "WHERE ev.link_type='ENTI_VERS' "
                    # ★ **구간 연결도 잡는다**(2026-09-01) — `창1:3~5` 로 이었으면
                    #   4절을 눌러도 그 용어가 티커에 떠야 한다.
                    "  AND ? BETWEEN ev.target_id "
                    "      AND COALESCE(ev.end_id, ev.target_id) "
                    "  AND COALESCE(ev.record_status,'LIVE')='LIVE' "
                    "  AND COALESCE(em.record_status,'LIVE')='LIVE' "
                    "ORDER BY ev.is_key DESC",
                    (getattr(self, 'lang', 'KO'), verse_id)
                ).fetchall()
        except Exception:
            vrows = []                     # 표가 아직 없으면 조용히 넘어간다

        seen = set()
        items = []
        # ★★★ **의미연결에는 표식을 붙인다** (2026-09-01 사용자 지시 —
        #   「엔티티 표시공간에 **의미연결이라는 것을 기호로 표시**해야 한다.
        #   단어가 없기 때문에 **연결성이 없다고 오해할 소지가 많으므로**」).
        #   ⚠ 목록(연결구절 탭)에서는 이 기호를 **걷었다** — 거기엔 「의미」라는
        #     갈래 칸이 있어 기호가 같은 말을 두 번 한다. 티커엔 칸이 없으므로
        #     기호가 제 몫을 한다. **말해 줄 것이 있을 때만 기호를 쓴다.**
        #   ⚠ 새 글리프를 만들지 않는다 — `◈` 는 이 앱이 이미 그리고 있는 것이다
        #     (§overlay_mark 「맑은 고딕에 없는 글자를 쓰지 않는다」).
        self._ticker_them = set()
        for eid, etype, name, _rel in vrows:   # ① 이 절에 실제로 있는 것
            if name and eid not in seen:
                seen.add(eid)
                if _rel == 'THEMATIC':
                    self._ticker_them.add(eid)
                    name = '◈ ' + name
                items.append((name, etype, eid))
        peri_items = sorted(
            [(name, etype, eid) for eid, etype, name in rows
             if name and eid not in seen],
            key=lambda x: _type_order.index(x[1]) if x[1] in _type_order else 99
        )
        items += peri_items                # ② 이 단락에 있는 것

        # ★★★ **내가 이 절에 단 용어·태그** (2026-08-30 사용자 신고 수리 —
        #   「P1 하단에 배치한 My Edit 태그/용어 연결은 안된다」).
        #   ⚠⚠ 원인 = **저장소와 읽는 곳이 갈려 있었다.** [My Edit] 은
        #     `tag_picker.save_links` 로 **`user_link_asset`(TAG_VERS·UTAG_VERS)**
        #     에 잘 저장했는데(실측 +2행), 이 티커는 위에서 보듯 **`sys_link_asset`
        #     (ENTI_VERS·ENTI_PERI)만** 읽는다. 오류도 안 나고 한 개도 안 뜬다 —
        #     §95차 「저장은 되는데 안 보인다」의 정확한 재현이다.
        #   ⚠ 여기서 SQL 을 또 쓰지 않는다 — 목록의 정본은 `tag_picker` 다.
        #     이름·덮개(내가 고친 이름·가린 태그)를 그쪽이 이미 판정한다.
        #   ⚠ **이름으로 겹침을 막는다** — 연동 태그(엔티티에서 이름을 빌리는
        #     태그)를 달면 위 엔티티 칩과 같은 글자가 두 번 뜬다. 사용자가 보는
        #     것은 이름이므로 이름으로 거른다.
        my_tags = []
        try:
            import tag_picker as _tp
            _lang = getattr(self, 'lang', 'KO') or 'KO'
            _seen_nm = {nm for nm, _t, _e in items}
            # ★★★ **배포 + 개인을 합쳐 읽는다** (2026-09-01). 여기서
            #   `tags_of(scope='USER')` 를 부르고 있었는데 그것은 **개인 표만**
            #   보는 낮은 층 문이라, 구절에 배포 태그를 이어도 티커에 한 개도
            #   안 떴다 — §118차가 My Edit 에서 고친 것과 **같은 병**이다.
            #   그때는 `links_of` 안에서만 합쳐 이 자리가 그대로 샜다.
            #   ⇒ 합치는 문 `tags_read` 하나를 부른다.
            for _src, _tid, _nm, _cat in _tp.tags_read(
                    self.db_path, 'VERSE', verse_id, _lang):
                if _nm and _nm not in _seen_nm:
                    _seen_nm.add(_nm)
                    # ⚠ **출처를 함께 안고 간다** — 배포 태그에 사용자 표식을
                    #   붙이면 거짓말이 된다(합쳐 읽게 되면서 실제로 그랬다).
                    #   순수 태그는 갈 화면이 없다 → eid=None(클릭 없음).
                    my_tags.append((_nm, str(_src or '').upper() == 'USER',
                                    None))
            # ★★ 2026-09-01 통합 수술 — 사용자가 붙였던 태그는 **개인 표의
            #   용어 연결**로 재지향해 보존했다(사용자 지시 「제거하지 마라.
            #   표시방법을 정하면 된다」). 용어가 실재하므로 누르면 그
            #   용어로 간다(eid 를 안고 간다).
            import link_picker as _lpk
            with appdb.connect(self.db_path) as _c9:
                for _eid, _nm in _lpk.user_verse_entity_marks(
                        _c9, verse_id, _lang):
                    if _nm and _nm not in _seen_nm:
                        _seen_nm.add(_nm)
                        my_tags.append((_nm, True, _eid))
        except Exception as e:
            print('[ticker my tags] %s' % e)

        def _ticker_wheel(e):
            self._ticker_cvs.xview_scroll(-1 if e.delta > 0 else 1, 'units')

        _cbg, _cfg = _C('accent_bg', '#EAF2FB'), _C('fg_title', '#1A5276')
        for name, etype, entity_id in items:
            chip = tk.Label(
                self._ticker_inner, text=f'  {name}  ',
                bg=_cbg, fg=_cfg, font=('Malgun Gothic', 9),
                padx=0, pady=3, cursor='hand2', relief='flat')
            chip.pack(side='left', padx=(0, 3), pady=3)
            # ★★★ **칩이 자기 절을 안고 간다** (2026-09-01) — 이 칩은 `verse_id`
            #   때문에 만들어진 것이므로 출발지가 그 절이다. 밖에서 짐작할
            #   필요가 없다.
            #   ⚠⚠ 처음에 `last_clicked_vid` 로 폴백했는데 **그것은 P4 캔버스
            #     노드 클릭 값**이라 P1 에서 누르면 엉뚱하거나 비어 있었다
            #     (실측 — 단추가 안 떴다). **가진 값을 넘긴다.**
            chip.bind('<Button-1>',
                      lambda e, eid=entity_id, v=verse_id:
                      self._on_entity_select(eid, from_vid=v))
            chip.bind('<MouseWheel>', _ticker_wheel)

        # ─ 내가 단 것은 **뒤에 · `[u]` 접두로** (2026-09-01 표시정책 확정) ──
        #   ⚠ 표식은 `overlay_mark` 한 곳에서 온다(글리프를 새로 짓지 않는다).
        #   ★ 클릭은 표식이 아니라 **「갈 곳이 있는가」**로 갈린다(사용자 확정
        #     「순수 태그는 클릭 자체가 필요 없다」) — 용어를 안은 표(eid 있음)는
        #     그 용어로 가고, 순수 태그는 클릭 없는 평문 라벨이다.
        if my_tags:
            import overlay_mark as _om
            _nbg, _nfg = _C('success_bg', '#E8F6EF'), _C('success', '#1E8449')
            _sbg, _sfg = _C('panel_alt', '#EDEFF1'), _C('fg', '#000000')
            for name, _mine, _eid in my_tags:
                _click = _eid is not None
                chip = tk.Label(
                    self._ticker_inner,
                    text=('  %s %s  ' % (_om.NEW, name)) if _mine
                    else ('  %s  ' % name),
                    bg=_nbg if _mine else _sbg,
                    fg=_nfg if _mine else _sfg, font=('Malgun Gothic', 9),
                    padx=0, pady=3,
                    cursor='hand2' if _click else '', relief='flat')
                chip.pack(side='left', padx=(0, 3), pady=3)
                if _click:
                    chip.bind('<Button-1>',
                              lambda e, eid=_eid, v=verse_id:
                              self._on_entity_select(eid, from_vid=v))
                chip.bind('<MouseWheel>', _ticker_wheel)

        self._ticker_cvs.config(scrollregion=self._ticker_cvs.bbox('all'))

    def _update_desc_tab(self, view_id):
        """P4 설명 갱신 (P4 흐름 전용). P2 desc_txt 는 `_update_p1_desc(vid)` 가 맡는다.

        2026-08-12 — 트리뷰 워크벤치(`focus_desc_txt`)가 사라져 NodePanel 로 넘긴다.
        모드·언어 툴바가 이 함수를 `on_change` 콜백으로 부르므로 **경로는 남겨 둔다.**"""
        self._focus_view_id = view_id   # 인라인 티어 토글 새로고침용
        panel = getattr(self, 'p4_node_panel', None)
        if panel is None or not view_id:
            return
        try:
            panel._refresh_desc(view_id)
        except Exception:
            pass

    def _update_p1_desc(self, vid):
        """[2026-06-04 옵션 B] P2 desc_txt 전용 갱신 — P1 구절 클릭 시점에만 호출.
        페리코프 + VERS_DESC + 묵상질문 + 묵상기도. 연결설명문(VERS_VERS_DESC) 미포함."""
        widget = getattr(self, 'desc_txt', None)
        if not widget:
            return
        # ★ **지금 무슨 절인지 단추 줄에 적는다** (2026-08-23 사용자 「여러 곳에서
        #   구절을 클릭하면 P2 에서 표시되는데 과연 클릭한 구절의 설명문인지 알
        #   수가 없다」). P4 는 이미 보여 주고 있었다 — P2 만 없었다.
        try:
            self._p2_dg.set_ref(vid)
        except Exception:
            pass
        text = self._fetch_p1_desc(vid)
        placeholder = "(설명문이 없습니다.)" if getattr(self, 'lang', 'KO') == 'KO' else "(No description available.)"
        try:
            self._fill_text_widget(widget, text if text else placeholder)
        except Exception:
            pass
        if text:
            self._desc_ai_marks(widget, vid)

    def _desc_ai_marks(self, widget, vid):
        """★ 2026-10-21 (docs/1.txt 15번 · 사용자 「PC 설명문 : AI 분석 배치하라. 각 항목별로 따로」) —
        설명 · 묵상질문 · 묵상기도 · 전문 설명 · 연구질문 머리 줄 끝에 [AI 분석](그 칸 글만 보낸다).
        머리 줄 = `_verse_asset_sections` 가 만든 「▶ 이름」 — 이름은 verse_tier.SECTION_LABELS(KO) · 영어 이름."""
        import verse_tier
        names = {}
        for code, en in (('DESC_LAY', 'Plain Description'), ('Q_DEV', 'Meditation Question'),
                         ('PRAYER', 'Meditation Prayer'), ('DESC_EXP', 'Expert Description'),
                         ('Q_RES', 'Research Question')):
            names[verse_tier.SECTION_LABELS[code][0]] = code
            names[en] = code
        try:
            lines = widget.get('1.0', 'end-1c').split(chr(10))
        except Exception:
            return
        heads = []
        for i, ln in enumerate(lines):
            if not ln.startswith('▶ ') or ' · ' in ln:
                continue                      # 「▶ 설명 · 연결」 = 연결설명문(구절 칸이 아니다)
            nm = ln[2:].split(' (')[0].strip()
            if nm in names:
                heads.append((i, names[nm], nm))
        # ★ 2026-10-25 (docs/1.txt 6-1 「분야별 전문설명문 버튼은 매우 어색하다 · 별도 탭이 아니라 제목 오른쪽에 「AI 분석」처럼」) —
        #   「▶ 분야별 도움말」 머리 줄 끝에 [목회 ▾](분야 하나 선택) · [AI 분석](그 분야 관점으로 묻기)
        role_head = None
        role_names = {i18n.t('SEC_ROLE', verse_tier.SECTION_LABELS['ROLE'][0]), verse_tier.SECTION_LABELS['ROLE'][0]}
        for i, ln in enumerate(lines):
            if ln.startswith('▶ ') and ln[2:].strip() in role_names:
                role_head = i
        if not heads and role_head is None:
            return
        starts = [i for i, ln in enumerate(lines) if ln.startswith('▶ ')]
        try:
            widget.config(state='normal')
            for i, code, nm in heads:
                nxt = min([j for j in starts if j > i] or [len(lines)])
                body = chr(10).join(l.strip() for l in lines[i + 1:nxt]).strip()
                if not body:
                    continue
                b = tk.Label(widget, text=i18n.t('PFV_NOTE_AI', 'AI 분석'), cursor='hand2',
                             fg=ui_theme.C('accent') or '#1A5276', bg=widget.cget('bg'),
                             font=('', 8, 'underline'), padx=6)
                b.bind('<Button-1>', lambda _e, c=code, n=nm, t=body: self._ai_desc_analyze(vid, c, n, t))
                widget.window_create('%d.end' % (i + 1), window=b)
            if role_head is not None:
                # ★ 2026-10-26 [일반]은 평신도 분야(사업가·직장인…) · [전문]은 사역자 분야 — 칸 이름으로 층을 가른다
                _tier = 'EXPERT' if any(h[1] in ('DESC_EXP', 'Q_RES') for h in heads) else 'LAY'
                self._role_head_marks(widget, vid, role_head, _tier)
        except Exception as e:
            print('[desc ai marks] %s' % e)
        finally:
            try:
                widget.config(state='disabled')
            except Exception:
                pass

    def _role_head_marks(self, widget, vid, row, tier='EXPERT'):
        """분야별 도움말 머리 줄 — [목회 ▾] 누르면 분야 하나를 고르는 메뉴 · [AI 분석] = 그 분야 관점으로 AI 도우미.
        [일반](tier LAY)은 평신도 분야 일곱(docs/1.txt 6-2) · [전문]은 사역자 분야 셋 — 기억도 층마다 따로."""
        import role_tips as RT
        cs = RT.codes(tier)
        try:
            with appdb.connect(self.db_path) as c:
                cur = (RT.get_show(c, tier) or [cs[0]])[0]
        except Exception:
            cur = cs[0]
        fg = ui_theme.C('accent') or '#1A5276'
        pick = tk.Label(widget, text='%s ▾' % RT.label(cur), cursor='hand2', fg=fg, bg=widget.cget('bg'),
                        font=('', 8, 'bold'), padx=6)

        def _menu(_e, w=pick):
            m = tk.Menu(w, tearoff=0)
            for code in cs:
                m.add_command(label=('● ' if code == cur else '○ ') + RT.label(code),
                              command=lambda c=code: self._role_head_pick(vid, c))
            m.tk_popup(w.winfo_rootx(), w.winfo_rooty() + w.winfo_height())
        pick.bind('<Button-1>', _menu)
        ask = tk.Label(widget, text=i18n.t('PFV_NOTE_AI', 'AI 분석'), cursor='hand2', fg=fg, bg=widget.cget('bg'),
                       font=('', 8, 'underline'), padx=6)
        ask.bind('<Button-1>', lambda _e, c=cur: self._p2_role_ask(c))
        widget.window_create('%d.end' % (row + 1), window=pick)
        widget.window_create('%d.end' % (row + 1), window=ask)
        widget._role_marks = (pick, ask)          # 시험이 찾는다
        widget._role_tier = tier

    def _role_head_pick(self, vid, code):
        import role_tips as RT
        try:
            with appdb.connect(self.db_path) as c:
                RT.set_show(c, [code])
        except Exception as e:
            print('[role head pick] %s' % e)
        self._update_p1_desc(vid)

    def _ai_desc_analyze(self, vid, code, label, text):
        """설명 칸 하나 [AI 분석] — P4 AI 도우미에서 그 칸만 살피게 바로 묻는다."""
        try:
            self._ensure_p4_tab_built(self.P4['ai'])
            self.p4_nb.select(self.p4_t13_f)
            v = getattr(self, 'ai_chat_view', None)
            if v is not None:
                v.analyze_desc_now(int(vid), code, label, text)
        except Exception as e:
            print('_ai_desc_analyze(%s): %s' % (code, e))

    def _desc_lang(self):
        """구절 설명문 표시 언어(전역 공유·직전값). P2 탭1·P4 탭2·P4 캔버스 슬라이드 공통.
        미설정 시 UI 언어로 초기화. 실제 데이터 없으면 fetch 계층이 EN→KO 폴백."""
        d = getattr(self, 'lang', 'KO')
        try:
            import verse_tier
            with appdb.connect(self.db_path) as c:
                r = c.execute("SELECT config_val FROM user_config WHERE config_key='LANGSEL_DESC'").fetchone()
                if r and r[0]:
                    return str(r[0]).upper()
                verse_tier.set_desc_lang(c, d)
        except Exception:
            pass
        return d

    def _desc_mode(self):
        """설명 탭 표시 모드(전역 공유·직전값).
        'CHAP'(장) | 'PERI'(단락) | 'LAY' | 'EXPERT' — 2026-08-09 개편으로 티어를 겸한다."""
        try:
            import verse_tier
            with appdb.connect(self.db_path) as c:
                return verse_tier.get_desc_mode(c)
        except Exception:
            return 'LAY'

    def _peri_desc_contents(self, conn, peri_id, lang):
        """PERI_DESC 본문 **+ 표식** → `(글, 표식)` (2026-08-30 반환 바뀜).

        ⚠ 장 설명문과 **같은 버그를 갖고 있었다** — sys 직접 읽기라 내가 고친
          단락 설명문이 안 나왔다. `_ov_text` 한 문으로 옮겼다.
        ⚠ **표식을 함께 돌려준다** — 글 따로·표식 따로 물으면 또 갈린다."""
        return self._ov_text(conn, 'PERI_DESC', peri_id, lang)

    def _book_short(self, conn, bcode, lang):
        """책 약명 — 요청 언어 → EN 폴백. 없으면 ''."""
        for lc in (lang, 'EN'):
            try:
                r = conn.execute("SELECT short_name FROM book_names "
                                 "WHERE book_code=? AND lang_code=?", (bcode, lc)).fetchone()
            except Exception:
                r = None
            if r and r[0]:
                return r[0]
        return ''

    def _peri_ref_label(self, conn, peri_id, lang):
        """페리코프 범위 표기 — 예 '창1:1~15' / '창1:1~2:3'. 실패하면 ''."""
        try:
            r = conn.execute("SELECT start_vid, end_vid FROM sys_pericope_asset "
                             "WHERE pericope_id=?", (peri_id,)).fetchone()
            if not r:
                return ''
            a = conn.execute("SELECT bcode, chapter, verse FROM bible_index "
                             "WHERE verse_id=?", (r[0],)).fetchone()
            b = conn.execute("SELECT bcode, chapter, verse FROM bible_index "
                             "WHERE verse_id=?", (r[1],)).fetchone()
        except Exception:
            return ''
        if not a or not b:
            return ''
        # ★ 형식은 `verse_ref` 가 정한다 (2026-08-14). 세 군데가 물결·붙임표로
        #   갈려 있던 것을 모았다 — 같은 것을 가리키는 표기가 화면마다 다르면
        #   사용자는 다른 것으로 읽는다.
        nm2 = self._book_short(conn, b[0], lang) if a[0] != b[0] else None
        return verse_ref.range_label(self._book_short(conn, a[0], lang),
                                     a[1], a[2], b[1], b[2], nm2)

    def _peri_only_text(self, vid):
        """'단락설명' 모드 본문 — 그 구절이 속한 BODY 페리코프의 제목·범위·설명문만.
        구절을 옮겨도 같은 단락 안이면 내용이 그대로라, 절마다 같은 글이 반복되던
        문제가 사라진다(2026-08-01)."""
        if not vid:
            return ''
        try:
            vid = int(vid)
        except (ValueError, TypeError):
            return ''
        lang = self._desc_lang()
        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = None
                row = conn.execute(
                    "SELECT pericope_id FROM sys_pericope_asset p "
                    "WHERE p.peri_type='BODY' AND "
                    + _vr.covers_sql('p', 'start_vid', 'end_vid') + " LIMIT 1",
                    _vr.covers_args(vid)).fetchone()
                if not row:
                    return ''
                peri_id = row[0]
                title = self._peri_title(conn, peri_id, lang)
                ref = self._peri_ref_label(conn, peri_id, lang)
                body, mark = self._peri_desc_contents(conn, peri_id, lang)
        except Exception as e:
            print(f"[_peri_only_text] {e}")
            return ''
        if not (title or body):
            return ''
        head = '▶ ' + ('단락설명' if lang == 'KO' else 'Passage Description')
        if title:
            head += f": {title}"
        if ref:
            head += f" ({ref})"
        head = self._hdr(head, mark)
        return head + (f"\n  {body.strip()}" if body else '')

    def _book_full(self, conn, bcode, lang):
        """책 이름(전체) — 요청 언어 → EN → 약명 폴백."""
        for lc in (lang, 'EN'):
            try:
                r = conn.execute("SELECT full_name FROM book_names "
                                 "WHERE book_code=? AND lang_code=?", (bcode, lc)).fetchone()
            except Exception:
                r = None
            if r and r[0]:
                return r[0]
        return self._book_short(conn, bcode, lang)

    def _chap_only_text(self, vid):
        """'장 설명' 모드 본문 — 그 구절이 속한 장의 CHAP_DESC (chapter.md).

        장은 사람이 실제로 읽는 단위인데 그 층만 비어 있었다. 페리코프가 자기 바깥
        (책 전체에서 어디쯤인지)을 말하려다 같은 소리를 되풀이하던 몫이 여기로 온다.
        키는 verse_tier.chap_key(bcode, chapter) — 장에는 자연 PK 가 없다."""
        if not vid:
            return ''
        try:
            vid = int(vid)
        except (ValueError, TypeError):
            return ''
        lang = self._desc_lang()
        try:
            import verse_tier
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = None
                r = conn.execute("SELECT bcode, chapter FROM bible_index WHERE verse_id=?",
                                 (vid,)).fetchone()
                if not r:
                    return ''
                bcode, chapter = r
                key = verse_tier.chap_key(bcode, chapter)
                # ★ **덮개를 탄다** (2026-08-30 사용자 신고 수리) — 그전에는
                #   sys 를 직접 읽어 **내가 고친 장 설명문이 P2 에 안 나왔다.**
                #   글과 표식을 `_ov_text` 한 문에서 함께 받는다.
                body, mark = self._ov_text(conn, 'CHAP_DESC', key, lang)
                name = self._book_full(conn, bcode, lang)
        except Exception as e:
            print(f"[_chap_only_text] {e}")
            return ''
        if not body.strip():
            return ''
        if lang == 'KO':
            head = f'▶ 장 설명: {name} {chapter}장'
        else:
            head = f'▶ Chapter Overview: {name} {chapter}'
        head = self._hdr(head, mark)
        return head + f"\n  {body.strip()}"

    def _book_only_text(self, vid):
        """'책' 모드 본문 — 그 구절이 속한 책의 개요(BOOK_DESC, clicked_id=bcode).

        2안(2026-08-26 사용자 승인) — 숲(책)→장→단락→절 계층의 맨 위 층.
        아직 0편이라 비어 있으면 **안내 한 줄**을 보인다(빈 화면은 고장으로
        읽힌다). 편집은 관리자 성경구절관리 ▸ 책 개요."""
        if not vid:
            return ''
        try:
            vid = int(vid)
        except (ValueError, TypeError):
            return ''
        lang = self._desc_lang()
        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = None
                r = conn.execute("SELECT bcode FROM bible_index WHERE verse_id=?",
                                 (vid,)).fetchone()
                if not r:
                    return ''
                bcode = r[0]
                # ★ 장·단락과 **같은 문**으로 (2026-08-30). `BOOK_DESC` 는 아직
                #   덮개 유형이 아니라 sys 그대로가 나온다 — 유형에 올리는 날
                #   이 자리는 손댈 것이 없다(그래서 지금 함께 옮긴다).
                body, mark = self._ov_text(conn, 'BOOK_DESC', bcode, lang)
                name = self._book_full(conn, bcode, lang)
        except Exception as e:
            print(f"[_book_only_text] {e}")
            return ''
        if lang == 'KO':
            head = f'▶ 책 개요: {name}'
            empty = i18n.t('DESC_BOOK_EMPTY',
                           '이 책의 개요는 아직 준비되지 않았습니다.')
        else:
            head = f'▶ Book Overview: {name}'
            empty = i18n.t('DESC_BOOK_EMPTY',
                           'The overview for this book is not ready yet.')
        head = self._hdr(head, mark)
        if not body.strip():
            return head + f"\n  {empty}"
        return head + f"\n  {body.strip()}"

    def _fetch_p1_desc(self, vid):
        """P2 DESC 탭 내용 생성 (vid 단위, 연결설명문 미포함).
        섹션 순서는 체크박스 순서(verse_tier.SECTION_CODES)를 따른다.
        페리코프 설명문은 '단락설명', 장 설명문은 '장 설명', 책 개요는 '책'
        모드로 분리했다 — 여긴 없다."""
        if not vid:
            return ""
        try:
            vid = int(vid)
        except (ValueError, TypeError):
            return ""
        mode = self._desc_mode()
        if mode == 'BOOK':
            return self._book_only_text(vid)
        if mode == 'CHAP':
            return self._chap_only_text(vid)
        if mode == 'PERI':
            return self._peri_only_text(vid)
        lang = self._desc_lang()
        sections = []   # 섹션 헤더는 _verse_asset_sections 가 만든다(라벨 단일 소스)

        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = None

                import verse_tier
                secs = set(verse_tier.sections_for_mode(mode))
                # 구절 설명문(전문/일반) + 연구질문/묵상질문/기도 — P4와 동일한 공유 헬퍼.
                # (P1 클릭 구절 = 부모 없는 root → 연결설명 없음, P4 root와 동일.)
                # 설명·질문·기도를 체크박스 순서대로 한 번에 (2026-07-31, 9.txt ①)
                for h, r in self._verse_asset_sections(conn, secs, vid, lang):
                    sections.append((h, r))
        except Exception as e:
            print(f"[_fetch_p1_desc] {e}")
            return ""

        if not sections:
            return ""
        blocks = []
        for header, rows in sections:
            # ⚠ 자리표는 rows 가 비어 있다 — 그대로 한 블록으로 내보낸다
            #   (`add()` 는 rows 가 비면 버리므로 자리표는 직접 append 한다).
            lines = [header]
            for title, contents in rows:
                if title:
                    lines.append(f"  [{title}]")
                if contents:
                    lines.append(f"  {contents.strip()}")
            blocks.append("\n".join(lines))
        return "\n\n".join(blocks)

    # 여행경로 티커
    def _update_journey_ticker(self):
        """[수리] 갱신된 current_journey_list를 바탕으로 모든 탭의 여정 티커를 동기화합니다."""
        if not hasattr(self, 'current_journey_list') or not self.current_journey_list: 
            return
            
        names = []
        for vid in self.current_journey_list:
            node_info = self.p4_view.nodes.get(vid)
            if node_info:
                # view_id에서 논리 ID(BIBLE:1) 추출 후 약명 사냥
                v_t, v_n = self._split_logic_id(node_info['node_id'])
                name = self.get_asset_name(v_n, v_t)
                if name: names.append(name)
        
        # 🎯 [표시] 최근 10개의 여정만 화살표로 연결
        # ⚠ 옛 `➔`(U+2794)는 **맑은 고딕·굴림체에 둘 다 없어** Segoe UI Symbol
        #   폴백으로 그려졌다(cmap 실측 — 굵기·높이가 옆 글자와 어긋난다).
        #   두 글꼴이 함께 가진 것은 → ⇒ ▶ » 뿐이라 `⇒` 로 맞춘다(2026-08-21).
        ticker_text = "" + " ⇒ ".join(names[-10:])
        
        # 캔버스 탭 및 리포트 탭 등의 모든 티커 라벨 일괄 갱신
        for lbl in self.history_labels.values():
            if lbl and lbl.winfo_exists():
                lbl.config(text=ticker_text)

    # ── P1 서브탭 지연빌드 ───────────────────────────────────────────
    def _ensure_p1_tab(self, frame):
        """P1 지연 서브탭을 최초 1회 빌드. 점프/탭선택 전 호출(이미 빌드됐으면 no-op)."""
        b = getattr(self, '_p1_builders', {}).get(frame)
        if b and frame not in self._p1_built:
            b()
            self._p1_built.add(frame)
            self._paint_built(frame)

    def _post_paint_build_p1(self):
        """첫 페인트 후, 직전 P1 탭(보이는 것) 먼저 빌드 → 나머지 유휴 체인."""
        self._p1_startup = False
        try:
            cur = self.p1_nb.nametowidget(self.p1_nb.select())
            self._ensure_p1_tab(cur)
            # 직전 탭이 공지/문의면 열람 처리(배지 0)
            if cur is getattr(self, '_tab_announce', None) and hasattr(self, 'p1_announce_view'):
                self.p1_announce_view.mark_seen()
            if cur is getattr(self, '_tab_feedback', None) and hasattr(self, 'p1_feedback_view'):
                self.p1_feedback_view.mark_seen()
        except Exception:
            pass
        # ★ 공지/소통 배지 — 탭을 안 짓고 DB 만 읽어 개수를 띄운다(0.txt 둘째 8번).
        #   ⚠ 화면이 이미 있으면 그쪽이 정확하므로 건드리지 않는다.
        self._refresh_announce_badge()
        # 프리빌드 비활성(2026-06-16, 사용자 요청): 나머지 P1 서브탭은 첫 클릭 시 빌드(순수 on-click).
        # (되살리려면 복원: self.after(60, self._prebuild_next_p1))

    def _prebuild_next_p1(self):
        for fr in list(getattr(self, '_p1_builders', {}).keys()):
            if fr not in self._p1_built:
                self._ensure_p1_tab(fr)
                self.after(60, self._prebuild_next_p1)
                return

    def _build_p1_plan(self):
        """묵상플랜 탭 내용 지연 빌드 — PlanMainView×3(BIBLE/DIAG/BOOK) + 렌즈묵상."""
        parent = self._tab_plan
        self.p1_plan_nb = ttk.Notebook(parent)
        self.p1_plan_nb.pack(expand=True, fill='both')

        def _make_plan_action_bar(p, manual=None):
            """서브탭마다 있는 32px 띠. **여기에 진행중 콤보와 매뉴얼이 들어간다.**

            ⚠ 예전에는 이 띠가 거의 비어 있고 매뉴얼만 **노트북 위 딴 띠**에 있었다.
              띠가 둘이라 세로 56px 를 쓰면서 둘 다 텅 비어 보였다(사용자 지적).
            """
            bar = tk.Frame(p, bg="#EAF2FB", height=32)
            bar.pack(side='top', fill='x'); bar.pack_propagate(False)
            # ★ 2026-10-13 docs/1.txt 76-8 — M 은 **그 서브탭 것 하나만**. 그전에는 서브탭마다 묵상플랜 탭 전체
            #   설명(U_P1_T2)이 붙고 렌즈묵상에는 제 설명과 함께 **둘**이 붙었다.
            if manual:
                attach_manual_icon(
                    bar, manual,
                    lang_provider=lambda: getattr(self, 'lang', 'KO')
                ).pack(side='right', padx=8)
            # (Focus/Restore 는 P1 첫 탭에만 — 2026-09-16 1.txt 28 「하나만 배치해도 모두 해결」)
            # ★ 묵상후보 단추·팝업을 걷었다 (2026-10-13 docs/1.txt 76-4 「화면이 너무 복잡하고 실용적이지 않다」).
            #   찜해 둔 데이터(user_favorite PLAN_WISH)는 지우지 않는다.
            # ⏸ 묵상경로 통합 팝업 단추 — **보류** (2026-08-18 사용자 결정
            #   「모든 묵상 데이터 채워진 후에 재검토. 이런 식으로는 의미없다.
            #   거미줄같은 연결성이 보이면 채택, 아니면 기각」).
            #   `_open_route_map` 코드는 남긴다 — 재검토 때 이 pack 만 되살린다.
            #   「다음/이전 단계」 줄(플랜·렌즈·도서)은 그대로 산다.
            # tk.Button(bar, text=i18n.t('ROUTE_TITLE', '묵상경로'),
            #           font=('', 9), bd=1, relief='solid', padx=8, pady=1,
            #           cursor='hand2',
            #           command=self._open_route_map).pack(side='right', padx=(0, 4))
            return bar

        _lang_getter    = lambda: getattr(self, 'lang', 'KO')
        _version_getter = lambda: getattr(self, 'ver', 'KRV')

        # ★ **서브탭 여섯** — 가르는 축은 `scope` 가 아니라 카테고리다
        #   (2026-08-16 사용자 지시 「탭 내부 트리 중에서 중요한 것을 서브탭으로
        #   격상시키자. 서브탭만 보면 알 수 있게 된다. 갯수는 표시하지 마라」).
        #   목록은 `PLAN_TABS` 한 곳 — 늘리거나 순서를 바꿀 때 여기만 고친다.
        #   ⚠ 「내가 만드는 묵상」 탭은 아직 만들지 않는다 — 빈 탭이 된다(§0-6 C-3).
        _sub_scope = {1: 'BIBLE', 2: 'BIBLE', 3: 'DIAG', 4: 'BOOK', 216: 'BIBLE'}
        def _build_plan_view(key, dflt, roots, hide, attr):
            sub = tk.Frame(self.p1_plan_nb)
            self.p1_plan_nb.add(sub, text=' ' + i18n.t(key, dflt) + ' ')
            bar = _make_plan_action_bar(sub, self.PLAN_MANUAL.get(key))
            view = PlanMainView(
                sub, self.db_path,
                lang_getter=_lang_getter, version_getter=_version_getter,
                on_verse_select=self._plan_verse_navigate,
                on_day_complete=self._on_plan_day_complete,
                scope=_sub_scope.get(roots[0]) if roots[0] != 'MINE' else 'BIBLE',
                cat_roots=roots, cat_hide=hide,
                bar_host=bar,
                on_scope_jump=self._plan_scope_jump,
                on_wish_jump=self._plan_wish_jump,
                on_wish_change=self._refresh_plan_wishes,
                on_route_jump=self._route_jump)
            view.on_research_new = self._research_from_plan
            view.on_note_ai = self._ai_note_analysis
            view.on_context = self._ref_ctx_follow
            view.on_mine_changed = self._mine_plans_changed
            try:
                view._detail_f.on_asset_jump = self._tag_asset_jump
            except Exception:
                pass
            view.pack(expand=True, fill='both')
            setattr(self, attr, view)

        for key, dflt, roots, hide, attr in self.PLAN_TABS:
            if not roots or roots == ['MINE']:
                continue                      # 렌즈묵상·내 플랜은 아래에서 따로(탭 차례)
            sub = tk.Frame(self.p1_plan_nb)
            self.p1_plan_nb.add(sub, text=' ' + i18n.t(key, dflt) + ' ')
            bar = _make_plan_action_bar(sub, self.PLAN_MANUAL.get(key))
            view = PlanMainView(
                sub, self.db_path,
                lang_getter=_lang_getter, version_getter=_version_getter,
                on_verse_select=self._plan_verse_navigate,
                on_day_complete=self._on_plan_day_complete,
                # ⚠ `scope` 는 **버리지 않는다** — `PlanFocusView` 가 녹음 단추를
                #   보일지 이 값으로 가른다(§6). 가르는 축만 카테고리로 옮겼다.
                scope=_sub_scope.get(roots[0]),
                cat_roots=roots, cat_hide=hide,
                bar_host=bar,
                on_scope_jump=self._plan_scope_jump,   # 진행중 콤보 → 그 탭으로
                on_wish_jump=self._plan_wish_jump,     # 묵상후보 → 그 탭 + 상세
                # ★ 찜을 바꾸면 **여섯 탭의 후보 콤보를 다 새로** 읽는다
                #   (찜은 탭을 가리지 않으므로 목록이 같아야 한다)
                on_wish_change=self._refresh_plan_wishes,
                on_route_jump=self._route_jump)   # 묵상경로 「다음 걸음」
            # 연구자료 쓰기/열기 (2026-08-19 0.txt ⑩ — 플랜 일차 화면의 진입점)
            view.on_research_new = self._research_from_plan
            # 그날 묵상노트 [AI 분석] (2026-10-13 76-15) — P2 [AI묵상분석] 과 같은 문
            view.on_note_ai = self._ai_note_analysis
            view.on_context = self._ref_ctx_follow      # P4 연구/설교노트 자리 거르개(79-2)
            # ★ 상세의 [연결된 자산 보기] 클릭 → 만능 점프 (2026-09-03)
            try:
                view._detail_f.on_asset_jump = self._tag_asset_jump
            except Exception:
                pass
            view.pack(expand=True, fill='both')
            view.on_mine_changed = self._mine_plans_changed   # 내 플랜은 「내 플랜」 탭으로(2026-10-15)
            setattr(self, attr, view)

        plan_sub4 = tk.Frame(self.p1_plan_nb)
        self.p1_plan_nb.add(plan_sub4, text=' '+i18n.t('TAB_PLAN_LENS','렌즈묵상')+' ')
        _bar4 = _make_plan_action_bar(plan_sub4)          # M 은 아래 U_P1_LENS 하나(76-8)
        # M104 — 「렌즈」가 무엇이고 렌즈→노드→구절 계단을 어떻게 읽나
        self._manual_at(_bar4, 'U_P1_LENS')
        # ★ **렌즈묵상도 같은 띠를 갖는다** (2026-08-14 사용자 지시
        #   「렌즈묵상 : 진행중 콤보상자, Font 배치하라」).
        #   ⚠ 이 탭은 `PlanMainView` 가 아니라 콤보가 아예 없었다. 그래서 네 서브탭의
        #     「표시되는 원리」가 갈렸다. 목록은 `plan_active_bar` 한 곳에서 온다.
        from plan_active_bar import ActivePlanBar
        self._lens_enr_bar = ActivePlanBar(
            _bar4, self.db_path, lang_getter=_lang_getter,
            on_pick=lambda enr: self._plan_scope_jump(enr.get('scope'),
                                                      enr['enrollment_id']),
            on_font=self._open_font_prose)
        self._lens_enr_bar.refresh()
        # ★ **렌즈묵상에도 표시 언어 콤보** (2026-08-14 사용자 지시).
        #   렌즈 설명·노드 설명·구절 설명문이 전부 `lang_code` 로 갈리는데
        #   이 화면에는 고를 길이 없어 전역 UI 언어에 묶여 있었다.
        # ★ **My Lens 단추** (2026-08-16 — `0.app수정.txt` 4-3 「상단 bar 오른쪽에
        #   사용자의 관리버튼」). 팝업이 내 렌즈 만들기·수정·삭제를 모아 담는다.
        #   ⚠ 색을 적지 않는다 — `ui_theme.paint` 가 역할로 칠한다(font.md §36-3).
        # ★ 2026-10-13 77-3 — 검은 테두리 걷음(Font 와 같은 라벨 꼴 `ui_theme.flat_btn`)
        import ui_theme as _uth77
        # ★ 2026-10-15 88-9 — [My Lens] 단추 걷음: 사용자 모드 콤보 「나의 렌즈 만들기」가 맡는다(`LensView.attach_bar`).
        # ★ [공유하기] 걷음(2026-10-15) — 내보내기·가져오기는 띠의 통일 단추(Font 오른쪽 · `LensView.attach_bar`)
        # ★ 언어 콤보를 걷었다 (2026-10-13 docs/1.txt 77-1 · 76-9 와 같은 규칙) — 설정 언어로 보인다.
        try:
            from user_lens_manager import LensView
            self.p1_lens_view = LensView(
                plan_sub4, self.db_path, lang_getter=_lang_getter,
                version_getter=_version_getter, on_verse_navigate=self._plan_verse_navigate,
                on_route_jump=self._route_jump)   # 묵상경로 「다음 걸음」
            # 태그 칩 — 연동 태그(◈) 클릭 → P4 주요용어 (2026-08-18)
            self.p1_lens_view.on_entity_jump = self._on_entity_select
            self.p1_lens_view.on_link_open = self._tag_asset_jump
            self.p1_lens_view.pack(fill='both', expand=True)
            # ★ 2026-10-15 — 묵상플랜 탭과 같은 단추(수정하기 · 원본 가리기/표시하기 · 내보내기 · 가져오기 · 삭제)
            self.p1_lens_view.attach_bar(_bar4, getattr(self._lens_enr_bar, 'combo', None))
        except Exception as e:
            import traceback
            tk.Label(plan_sub4, text=f'렌즈묵상 로드 실패:\n{e}\n\n{traceback.format_exc()}',
                     bg='#FAFAFA', fg='#C0392B', font=('Consolas', 8), justify='left').pack(expand=True, padx=20, pady=20)

        # ── ★★ 내 플랜 (렌즈묵상 오른쪽 · 2026-10-15) ────────────────
        for _t in self.PLAN_TABS:
            if _t[2] == ['MINE']:
                _build_plan_view(*_t)

        # ── ★★★ 함께 묵상 ────────────────────────────────────────
        plan_sub5 = tk.Frame(self.p1_plan_nb)
        self.p1_plan_nb.add(plan_sub5,
                            text=' ' + i18n.t('TAB_PLAN_ROOM', '함께 묵상') + ' ')
        try:
            from room_medi_view import RoomMediView
            self.p1_room_view = RoomMediView(
                plan_sub5, self.db_path, lang_getter=_lang_getter,
                # ★ 그날 몫을 누르면 **그 구절로** 간다(P1 이 따라온다)
                on_verse_open=self._plan_verse_navigate)
            self.p1_room_view.pack(fill='both', expand=True)
            # M — 함께 묵상 사용 설명(방장 절차 포함). 자리는 그 화면 머리 줄 맨 오른쪽.
            self._manual_at(self.p1_room_view.manual_slot(), 'U_P1_ROOM')
        except Exception as e:
            import traceback
            tk.Label(plan_sub5,
                     text='함께 묵상 로드 실패:' + chr(10) + str(e) + chr(10)
                          + traceback.format_exc(),
                     bg='#FAFAFA', fg='#C0392B', font=('Consolas', 8),
                     justify='left').pack(expand=True, padx=20, pady=20)

        # ★★ 2026-10-15 87 — 함께 묵상 방은 **감춘다**(지우지 않는다). 사용자 「별도 방이 아니라 그 플랜의 그날 묵상노트에
        #   덧붙이는 방식」 — 함께 읽기는 SNS(카톡·텔레그램 …)로 하고, 남의 묵상노트는 「+Hagah」·[복사한 글 붙이기]로
        #   그 플랜에서 그 구절이 든 날의 내 노트에 담는다(plan_share · 폰 plan_receive). 되살리려면 user_config ROOM_TAB=1.
        self._room_hidden = False
        try:
            with appdb.connect(self.db_path) as _c:
                _r = _c.execute("SELECT config_val FROM user_config WHERE config_key='ROOM_TAB'").fetchone()
            if not (_r and str(_r[0]).strip() == '1'):
                self.p1_plan_nb.hide(plan_sub5)
                self._room_hidden = True
                self._room_tab = plan_sub5
        except Exception as e:
            print('[room tab hide] %s' % e)

        self.p1_plan_nb.bind('<<NotebookTabChanged>>', self._on_plan_sub_tab_changed)

    def _on_plan_sub_tab_changed(self, event=None):
        """플랜 서브탭(전체/진단/도서/렌즈) 화면 히트 + 미룬 새로고침."""
        # ★ 더러움 표시된 서브탭에 들어오면 그때 읽는다(2026-08-27 — 위
        #   `_refresh_plan_views` 의 짝. 등록·해제 반영이 이 시점으로 미뤄진다).
        try:
            idx = self.p1_plan_nb.index('current')
            attr = self.PLAN_TABS[idx][4] if idx < len(self.PLAN_TABS) else None
            # ★ 함께 묵상은 **들어올 때마다 다시 읽는다** — 방·공지·남의 글이
            #   설정 화면이나 다른 PC 에서 바뀌었을 수 있다.
            if attr == 'p1_room_view' and getattr(self, '_room_hidden', False):
                # ⚠ ttk 는 감춘 탭을 select() 하면 도로 보인다 — 다시 감추고 첫 탭으로(저장된 직전 탭이 방이었을 때)
                self.p1_plan_nb.hide(self._room_tab)
                self.p1_plan_nb.select(0)
                return
            if attr == 'p1_room_view':
                v = getattr(self, 'p1_room_view', None)
                if v is not None:
                    self.after_idle(v.reload)
            if attr and attr in getattr(self, '_plan_dirty', ()):
                self._plan_dirty.discard(attr)
                v = getattr(self, attr, None)
                if v is not None and hasattr(v, 'refresh'):
                    v.refresh()
        except Exception as e:
            print('[plan subtab refresh] %s' % e)
        try:
            import usage_stats
            # ⚠ 서브탭이 4→6 으로 늘면서 번호가 밀렸다 (2026-08-16).
            #   ★ **옛 이름은 그대로 둔다** — 바꾸면 지금까지 쌓인 집계가 두 갈래로
            #     갈린다(§3 `p4_canvas` 에서 같은 판단을 했다).
            # ★ 2026-10-20 — 번호로 고르던 것이 탭 차례가 바뀐 뒤 엉뚱한 이름으로 갔다
            #   (회복묵상이 plan_diag 가 아니라 다른 칸에) → 그 탭 안에 든 뷰로 고른다.
            _sel = self.p1_plan_nb.select()
            _c = None
            for _a, _code in (('p1_plan_view', 'plan_whole'), ('p1_theme_plan_view', 'plan_theme'),
                              ('p1_diag_plan_view', 'plan_diag'), ('p1_lens_view', 'plan_lens'),
                              ('p1_mine_plan_view', 'plan_mine'), ('p1_room_view', 'plan_room')):
                _v = getattr(self, _a, None)
                if _v is not None and str(_v).startswith(_sel + '.'):
                    _c = _code
                    break
            if _c:
                usage_stats.screen_hit(_c)
        except Exception:
            pass

    def _build_p1_reading(self):
        """도서/설교 탭 지연 빌드."""
        f = self._tab_reading
        # ⓜ만 있던 최상단 빈 띠(hdr)는 제거 (2026-08-18 `0.txt` 1번 — ⓜ는
        # ReadingView 2단 bar 오른쪽에 있다. 두 곳이면 하나는 잉여다)
        self.p1_reading_view = ReadingView(
            f, self.db_path,
            lang_getter=lambda: getattr(self, 'lang', 'KO'),
            version_getter=lambda: getattr(self, 'ver', 'KRV'),
            last_reading=getattr(self, 'last_reading', {}),
            on_research_new=self._research_from_reading,
            on_research_open=self._open_ref_detail,   # 연구자료 줄 클릭 → P4 연구자료 탭
            on_reading_changed=lambda s: self._save_state('last_reading', s))
        # 도서노트 [AI 분석](79-3) — ★ 2026-10-21 라이브러리 「도서노트 분석」 자리의 Pick
        self.p1_reading_view.on_note_ai = lambda v, e=None: self._ai_note_analysis(v, e, book=True)
        self.p1_reading_view.on_context = self._ref_ctx_follow
        self.p1_reading_view.on_ai_book = self._open_ai_book        # [AI 묵상](81)
        # 묵상경로 — 「이 도서로 하는 묵상」 줄의 점프 (2026-08-17)
        self.p1_reading_view.on_route_jump = self._route_jump
        self.p1_reading_view.on_link_open = self._tag_asset_jump
        # 태그 칩 — 연동 태그(◈) 클릭 → P4 주요용어 (2026-08-18)
        self.p1_reading_view.on_entity_jump = self._on_entity_select
        # 2단 bar — 진행중 콤보(플랜 탭 점프)·Font (2026-08-18 `0.txt` 1번)
        self.p1_reading_view.on_enr_pick = lambda enr: self._plan_scope_jump(
            enr.get('scope'), enr['enrollment_id'])
        self.p1_reading_view.on_font_open = self._open_font_prose
        # ★ [묵상플랜] — 이 책을 하루치로 (2026-08-30, 도서묵상 탭 대체)
        self.p1_reading_view.on_book_plan = self._open_plan_for_book
        # ★ 서재에서 **아직 안 받은 자료**를 누르면 다운로드 화면으로(2026-08-24
        #   사용자 「도서/설교 탭으로 가면 안 된다. 다운로드 화면으로 가야 한다」).
        self.p1_reading_view.on_download_jump = self._open_download_tab
        # 기준 구절로 가는 두 단추 (2026-08-22 사용자 지적 — 길이 없었다)
        self.p1_reading_view.on_verse_jump = self._plan_verse_navigate
        self.p1_reading_view.on_chapter_compare = self._open_chapter_compare
        # ★★ 연결 자산 칩 (2026-08-31 `0.txt` 1번 6) — **유형마다 갈 곳이 다르다.**
        #   구절은 **P4 「구절 연결」** 로 — 거기 NodePanel 이 본문·설명·주석·자료를
        #   한 화면에 담으므로 **P1 은 도서 화면 그대로** 둘 수 있다(사용자가 물은
        #   「탭을 바꾸지 않는 대안」의 답).
        self.p1_reading_view.on_verse_side = self._verse_to_p4
        self.p1_reading_view.on_user_open = lambda i: self._open_ref_detail(
            'USER', i)
        self.p1_reading_view.pack(expand=True, fill='both')
        # 왼쪽 탭 막대가 갈래를 고를 때 쓰는 문(서재 닫기·위 띠 단추까지 함께)
        try:
            self.p1_reading_view._left_nb._rail_pick = self.p1_reading_view._pick_sub
            # 왼쪽 막대가 갈래를 맡는 동안 위 띠의 갈래 단추는 감춘다(묵상 플랜과 같게 · 317차-28)
            self.p1_reading_view._left_nb._rail_own = self.p1_reading_view.set_branch_buttons
        except Exception:
            pass

    def _build_p1_mypath(self):
        """나의 묵상 탭 지연 빌드."""
        f = self._tab_mypath
        # ★ **빈 띠를 걷었다** (2026-08-23 사용자 「나의묵상 아래에 상단 bar
        #   공백이 있다. 한칸씩 위로 올려라」).
        #   ⚠ 2026-08-22 에 매뉴얼 단추를 뗐는데(「특별히 복잡한 내용이 없는
        #     화면에는 굳이 배치할 필요가 없다」) **그 단추가 들어 있던 24px 띠를
        #     안 걷었다.** 안이 텅 빈 채로 자리만 먹고 있었다.
        #   ⇒ **위젯을 뗄 때 그것을 담고 있던 칸도 함께 본다.**
        try:
            from my_path_view import MyPathView
            self.p1_my_path = MyPathView(
                f, self.db_path,
                lang_getter=lambda: getattr(self, 'lang', 'KO'),
                last_reading_getter=lambda: getattr(self, 'last_reading', {}),
                on_plan_jump=self._my_path_jump_plan, on_book_jump=self._my_path_jump_book,
                on_favorite_jump=self._my_path_jump_favorite,
                # 최근 구절 — 목록의 주인은 여기다. 저쪽이 사본을 들면 두 곳이 어긋난다.
                recent_getter=lambda: list(getattr(self, '_recent_verse_ids', [])),
                ver_getter=lambda: getattr(self, 'ver', 'KRV'),
                on_verse_jump=self._goto_recent_verse,
                on_note_focus=self._focus_verse_note)
            self.p1_my_path.pack(fill='both', expand=True)
        except Exception as e:
            tk.Label(f, text=f'나의 길 로드 실패:\n{e}', bg='#FAFAFA', fg='#C0392B',
                     font=('Malgun Gothic', 9), justify='left').pack(expand=True, padx=20, pady=20)

    def _build_p1_news(self):
        """⚠ **부르는 곳이 0 이다**(2026-09-26 · 1.txt 20번 3).

        최신 콘텐츠는 **P4 온라인 영상 오른쪽**으로 옮겼다 —
        지금 짓는 자리는 `_setup_news_tab` 이다.
        ★ 되돌릴 자리로 이름만 남긴다(P1 으로 되돌리면 그 등록 줄과 함께).
        """
        return

    def _build_p1_announce(self):
        """공지/소통 탭 지연 빌드 (2026-08-19 재편 — 공지·FAQ·내 문의·개인정보·
        정보를 한 탭으로. FeedbackView mode='COMM' 이 공지를 임베드한다)."""
        f = self._tab_announce
        try:
            from feedback_view import FeedbackView
            self.p1_announce_view = FeedbackView(
                f, self.db_path, lang_getter=lambda: getattr(self, 'lang', 'KO'),
                on_count_change=self._update_announce_badge,
                on_saved=self._on_settings_saved, mode='COMM')
            self.p1_announce_view.pack(fill='both', expand=True)
        except Exception as e:
            import traceback
            tk.Label(f, text=f'공지/소통 로드 실패:\n{e}\n\n{traceback.format_exc()}',
                     bg='#FAFAFA', fg='#C0392B', font=('Consolas', 8), justify='left').pack(expand=True, padx=20, pady=20)

    def _build_p1_feedback(self):
        """설정 탭 지연 빌드 (2026-08-19 재편 — 다운로드·언어·성경버전·폰트·
        화면색·시작화면. 소통 성격은 공지/소통 탭으로 옮겨 갔다)."""
        f = self._tab_feedback
        try:
            from feedback_view import FeedbackView
            self.p1_feedback_view = FeedbackView(
                f, self.db_path, lang_getter=lambda: getattr(self, 'lang', 'KO'),
                on_count_change=None,               # 설정 탭에는 배지가 없다
                on_saved=self._on_settings_saved,   # 설정 저장 시 P1 즉시 갱신
                mode='SET')
            self.p1_feedback_view.pack(fill='both', expand=True)
        except Exception as e:
            import traceback
            tk.Label(f, text=f'설정 로드 실패:\n{e}\n\n{traceback.format_exc()}',
                     bg='#FAFAFA', fg='#C0392B', font=('Consolas', 8), justify='left').pack(expand=True, padx=20, pady=20)

    def _open_download_tab(self, book_id=None):
        """서재의 「안 받은 자료」 → **설정 ▸ 다운로드**.

        ⚠ **임시 페이지를 만들지 않았다** — 그 화면이 이미 있다
          (`feedback_view._build_download`). 없는 화면을 또 지으면 두 곳이 된다.
        ⚠ 탭은 **지연 빌드**라 고른 뒤에 서브탭을 골라야 한다. 바로 부르면
          `p1_feedback_view` 가 아직 없다(§29).
        """
        try:
            self.p1_nb.select(self._tab_feedback)
        except Exception as e:
            print('[download jump] %s' % e)
            return

        def _pick():
            v = getattr(self, 'p1_feedback_view', None)
            nb = getattr(v, 'nb', None) or getattr(v, '_nb', None)
            if nb is None:
                return
            try:
                nb.select(0)        # 설정 모드의 첫 서브탭 = 다운로드
            except Exception as e:
                print('[download jump sub] %s' % e)
        self.after(120, _pick)

    def _update_feedback_badge(self, count):
        """(2026-08-19 재편 후 사실상 미사용 — 설정 탭에는 배지가 없다.
        옛 호출부 호환으로만 남긴다. 문의 배지는 공지/소통 탭에 합산된다.)"""
        try:
            base = getattr(self, '_feedback_base', '설정')
            txt = f' {base} ({count}) ' if count else f' {base} '
            self.p1_nb.tab(self._tab_feedback, text=txt)
        except Exception:
            pass

    # P1 성경본문 패널
    def _setup_p1_ui(self, parent_pw):
        """P1: ttk.Notebook 2탭 구조 (성경 탐색 / 묵상 플랜)."""
        self._tlog('p1.t1: setup start')
        # 라벨 제거 2026-08-15 — `LabelFrame` 그대로 두고 text 만 비우면 테두리·여백이 남는다
        self.p1_f = ttk.Frame(parent_pw)
        parent_pw.add(self.p1_f, width=self.p1_width, minsize=PANE_MIN)

        self.p1_nb = ttk.Notebook(self.p1_f)
        self.p1_nb.pack(expand=True, fill='both')
        # ★ [Focus]/[Restore] = P1 탭 줄 맨 왼쪽 한 쌍(2026-09-16 · 1.txt 28) — 어느 탭에서도 보인다
        self._p1_focus_strip = self._focus_strip(self.p1_nb, 'P1Focus.TNotebook')
        self._add_p1_focus(self._p1_focus_strip, padx=(2, 2))
        self._p1_builders = {}   # P1 서브탭 지연빌드: frame -> builder
        self._p1_built = set()

        # ── Tab 1: 성경 탐색 ─────────────────────────────────────────────────
        tab1_f = tk.Frame(self.p1_nb, bg='#FFFFFF')
        self.p1_nb.add(tab1_f, text=' '+i18n.t('TAB_P1_BIBLE','성경읽기')+' ')
        self._tab_bible = tab1_f   # 이용통계 p1_bible

        p1_ctrl = tk.Frame(tab1_f, bg="#FFFFFF")
        p1_ctrl.pack(side='top', fill='x', padx=5, pady=5)

        # 매뉴얼 아이콘 (우측 끝, 화면코드 U_P1_T1)
        attach_manual_icon(p1_ctrl, 'U_P1_T1',
                            lang_provider=lambda: getattr(self, 'lang', 'KO')).pack(side='right', padx=4)
        self._tlog('p1.t1: manual icon done')

        # ★★ **오른쪽 묶음 자리를 여기서 미리 잡는다** (2026-08-23).
        #   ⚠⚠ **`side='right'` 만으로는 안 된다** — Tk 는 **pack 을 부른 차례대로**
        #     남은 자리를 나눠 준다. 왼쪽 도구들이 먼저 붙으면 그것들이 폭을 다
        #     먹고, 나중에 붙는 오른쪽 묶음은 **줄 밖으로 사라진다**(실측: 창
        #     1024 에서 녹음 ⏺·설정 ⚙ 가 통째로 없어졌다. `side='right'` 로
        #     바꿔도 그대로였다).
        #   ⇒ **빈 칸을 먼저 잡아 두고** 도구는 나중에 그 안에 채운다.
        #     이제 좁아지면 **가운데 핀 칩이 줄어들 뿐** 도구는 안 사라진다.
        self._p1_right_f = tk.Frame(p1_ctrl, bg="#FFFFFF")
        self._p1_right_f.pack(side='right')

        # ★★ **[Focus]/[Restore] 는 모든 P1 탭에서 맨 왼쪽** (2026-09-16 · 1.txt 10번
        #   「P1 모든 탭에서 Focus 버튼이 가장 왼쪽에 배치되도록」). 자리를 먼저 잡고
        #   한 쌍을 심는다 — 다른 탭(묵상플랜 띠·도서/설교·나의 묵상)도 같은 문
        #   (`_add_p1_focus`)으로 심고, 어느 탭에서 접어도 다른 탭에서 풀 수 있다.
        # (Focus/Restore 는 P1 탭 줄 맨 왼쪽 한 쌍 — 2026-09-16 1.txt 28. 여기서는 안 짓는다.
        #  ⚠ `_p1_focus_pairs` 를 여기서 비우면 탭 줄의 쌍이 지워진다 — 안 건드린다)

        # 읽기 설정(Font) 버튼은 아래 Recent 옆으로 옮겼다 (2026-08-12 사용자 지시).

        # 전역 환경설정 ⚙ 제거 — 진입점 단일화: '지원/설정(Support & Settings)' 탭에 통합 (2026-06-17)
        # (_open_settings/SettingsDialog 팝업 경로는 보존 — 필요 시 직접 호출 가능, 평소 미사용)

        # ── 성경 버전 콤보 — 선호버전만, 현지명 표시 ──
        self._build_p1_version_combo(p1_ctrl)
        self._tlog('p1.t1: version combo done')

        # height=20 — **ttk.Combobox 의 기본값이 10 이라** 그동안 10줄만 펼쳐졌다.
        # 값의 개수 문제가 아니라 드롭다운 줄 수 문제다(2026-08-12 실측).
        self.cb_book = ttk.Combobox(p1_ctrl, state="readonly", width=12, height=20); self.cb_book.pack(side='left', padx=2)
        self.cb_chap = ttk.Combobox(p1_ctrl, state="readonly", width=5, height=20); self.cb_chap.pack(side='left', padx=2)
        self.cb_book.bind("<<ComboboxSelected>>", self.on_book_selected)
        self.cb_chap.bind("<<ComboboxSelected>>", self.on_chapter_selected)

        # ★ bar 도구 높이 통일 (2026-08-19 사용자 지시 — 기준 = Recent/Font 류
        #   28px). pady·글자크기가 이 높이를 만든다 — 실측으로 맞춘 값이니
        #   바꾸면 그 도구만 줄에서 튀어나온다.
        # ★★ **장 이동 = `←  →`** (2026-08-23 사용자 「`<>` 표시 대신 … 좌우
        #   방향을 가리키는 다른 기호. 다양한 언어코드에도 일그러지지 않는 것.
        #   음성 play 버튼과 혼동이 안되는 것」).
        #   실측으로 골랐다 — cmap(맑은 고딕·굴림·바탕)에 다 있는 후보 넷을
        #   **재생 단추 옆에 나란히 그려** 비교:
        #     `‹ ›` 너무 얇아 안 보인다 · `« »` 여전히 작다
        #     `◁ ▷` **재생 `▶` 와 헷갈린다**(사용자 우려 그대로) · `← →` **승자**
        #   ⚠ `⇐` 는 세 글꼴에 **없다**(`⇒` 는 있다) — `⇐ ⇒` 짝은 못 쓴다.
        _nav_kw = dict(font=("Malgun Gothic", 9, "bold"), bd=0, padx=5, pady=2,
                       bg=_C('panel_alt', '#E8E8E8'),
                       activebackground=_C('border', '#C8C8C8'),
                       relief='flat', cursor='hand2')
        # ★★ **이 줄의 단추는 전부 테두리 없는 라벨 꼴이다** (2026-08-30 사용자
        #   지시 「현재 음각 방식에서 테두리 없는 라벨 방식(← → 버튼처럼)으로」).
        #   ⚠ `pady=2` 를 빼면 안 된다 — bar 높이 28px 가 그 값으로 맞춰져 있어
        #     하나만 빼면 그 단추만 줄에서 튄다(§2026-08-19 실측).
        import ui_theme as _uthf
        _flat_kw = _uthf.flat_btn()
        tk.Button(p1_ctrl, text="←", command=lambda: self._navigate_chapter(-1), **_nav_kw).pack(side='left', padx=(4, 1))
        tk.Button(p1_ctrl, text="→", command=lambda: self._navigate_chapter(+1), **_nav_kw).pack(side='left', padx=(1, 4))
        self._tlog('p1.t1: book/chap/nav done')

        # ★★ **상단 bar 를 두 묶음으로 갈랐다** (2026-08-23 사용자 「이동경로
        #   장치를 오른쪽으로 모으자」 — 즐겨찾기↔통합검색↔역본비교 3자 교대).
        #       [보는 도구] 역본비교 · 통합검색
        #       [이동경로]  ☆ · Recent · ⚑ · 핀 칩
        #   ⚠ `← →` 는 이동경로가 아니라 **책/장 콤보의 짝**이라 왼쪽에 남는다
        #     (「어디를 볼까」이지 「갔던 곳으로 돌아가기」가 아니다).
        self._p1_verse_id = None

        # ── 보는 도구 ────────────────────────────────────────────────────
        # ⚠⚠ **옛 `🕮🕮` 를 글자로 바꿨다.** `🕮`(U+1F56E)는 **맑은 고딕·굴림·
        #   바탕 어디에도 없다**(cmap 실측 2026-08-23) — 폴백 글꼴로 그려지고
        #   있었다(§54 `➔` 와 같은 계열). 글자로 두면 통합검색과 나란한 두 글자
        #   단추가 되어 **묶음이 눈에 보인다**(실측 폭 48 → 71px, 여유 127px).
        #   ⚠ 글꼴 이름도 함께 걷었다(§36).
        #   ⚠⚠ **글꼴 이름을 여기서만 빼면 안 된다** — 빼 봤더니 이 단추만
        #     21px 가 되어 옆의 Recent(28px)와 어긋났다(실측). bar 높이 28px 는
        #     **하드코딩된 `Malgun Gothic 9` 로 맞춰 둔 값**이라, 하나만 통합
        #     폰트로 바꾸면 그것만 줄에서 튄다. ⇒ 지금은 옆줄과 **똑같이** 두고
        #     §36 글꼴 정리는 **이 줄 전체를 한꺼번에** 할 때 한다.
        # ★ **[Focus] / [Restore]** — 역본비교 왼쪽 (2026-08-30 사용자 지시).
        #   P4 를 접어 읽는 화면을 넓힌다. P4 쪽 Focus 와 **방향이 반대**다 —
        #   그쪽은 위(P1·P2)를 접는다(`activate_p4_focus_mode`).
        #   (2026-09-16) 단추 쌍은 줄 맨 왼쪽 `_fslot` 으로 옮겼다 — 위 `_add_p1_focus`.
        # ★ 2026-10-13 (docs/1.txt 74-8) — [역본비교] 단추를 걷고 그 자리에 「통합검색」 글자(오른쪽 검색 칸의 이름).
        #   역본비교는 P4 탭이 구절을 따라가므로 단추가 필요 없다.
        _cmp_btn = tk.Label(p1_ctrl, text=i18n.t('SEARCH_ALL', '통합검색'),
                            bg=_C('bg', '#FFFFFF'), fg=_C('fg_dim', '#566573'))
        _cmp_btn.pack(side='left', padx=(14, 4))      # ← → 뒤 (공백)
        # ⚠⚠ **자리를 잡아 둘 기준이 필요하다** (2026-08-30 사용자 지시
        #   「Focus 버튼을 배치한 같은 장소에 Restore 를 배치하라. 항상
        #   역본비교 왼쪽에」). `pack(side='left')` 는 **그 시점의 맨 뒤**에
        #   붙으므로, 나중에 파는 Restore 는 줄 끝으로 날아간다.
        #   ⇒ 늘 이 단추 **앞에**(`before=`) 붙인다.
        self._p1_cmp_btn = _cmp_btn

        # 직전값 복원: app_state.json['recent_verses'] = [[vid, label], ...]
        _saved_recent = self._load_state('recent_verses', [])
        self._recent_verse_ids: list[tuple[int, str]] = []
        if isinstance(_saved_recent, list):
            for it in _saved_recent:
                try:
                    self._recent_verse_ids.append((int(it[0]), str(it[1])))
                except Exception:
                    pass
        self._recent_verse_ids = self._recent_verse_ids[:RECENT_VERSE_MAX]
        # 콤보가 아니라 버튼 + 팝업이다 (2026-08-12 사용자 결정).
        # ⚠ ttk 콤보 드롭다운은 **줄바꿈이 안 되고 폭이 콤보에 묶인다** — 약명 옆에 본문을
        #   보이려 하면 잘린 꼬리만 남는다. Toplevel 은 폭 제약이 없어 그 한계를 벗어난다.
        # ★ **[통합검색]** (2026-08-21 사용자 지시 — 「P1 탭1 상단 검색버튼 표시
        #   항상 보이도록. Recent 버튼 왼쪽에」). 누르면 오른쪽 P4 가 통합검색
        #   갈래로 바뀐다 — **P4 는 P1 과 좌우로 나뉜 패널이라 읽던 본문은 그대로
        #   있다**(팝업이 하던 「본문을 안 가린다」를 그대로 지킨다).
        #   ⚠ 이름을 도착지와 **같게** 둔다 — 「검색」을 눌렀는데 「통합검색」이
        #     열리면 어디로 가는지 한 박자 어긋난다(실측 폭 44 → 68px, 여유 128px).
        # ★ (2026-09-16 · 1.txt 10번) 단추 하나가 아니라 **검색창 + [찾기]** — 여기서
        #   낱말을 치고 Enter/[찾기] 하면 P4 통합검색이 그 낱말로 바로 돈다.
        self._p1_search_var = tk.StringVar()
        self.ent_search_all = ttk.Entry(p1_ctrl, textvariable=self._p1_search_var, width=16)
        self.ent_search_all.pack(side='left', padx=(2, 0))
        self.ent_search_all.bind(
            '<Return>', lambda _e: self._open_search_all(self._p1_search_var.get().strip() or None))
        self.btn_search_all = tk.Button(
            p1_ctrl, text=i18n.t('COMMON_SEARCH', '찾기'),
            command=lambda: self._open_search_all(self._p1_search_var.get().strip() or None),
            **_flat_kw)
        self.btn_search_all.pack(side='left', padx=(2, 14))

        # ── 이동경로 ─────────────────────────────────────────────────────
        #   ☆ 는 「누르면 이동」은 아니지만 **나중에 다시 올 곳을 표시**하는
        #   것이라 Recent·⚑ 와 같은 묶음이다(셋 다 구절 단위 개인 기록).
        self._verse_fav_btn = tk.Button(
            p1_ctrl, text="☆", font=("Malgun Gothic", 10, "bold"), pady=0,
            bg="#FFFFFF", fg="#BBBBBB", bd=0, relief='flat', cursor='hand2',
            activebackground="#FFFFFF", command=self._toggle_verse_favorite)
        self._verse_fav_btn.pack(side='left', padx=(0, 10))   # ★ History 와 띄운다(74-9)
        self._attach_tooltip(self._verse_fav_btn, lambda: i18n.t('UM_VERSE_FAV', '구절 즐겨찾기'))
        self.btn_recent_verse = tk.Button(
            p1_ctrl, text=i18n.t('UM_RECENT_VERSES', 'Recent verses'),
            command=self._open_recent_popup, **_flat_kw)
        self.btn_recent_verse.pack(side='left', padx=(0, 2))
        self._recent_pop = None

        # ── 기준점(⚑ 핀) — 「다른 구절을 중심으로 묵상하기」 (2026-08-19 확정 설계)
        #    ⚑ = 지금 구절을 기준점으로(스냅샷 저장) · 칩 = 약명, 클릭=복귀, ✕=해제
        #    최대 3 · 저장순(최신 앞) · 자동 해제 없음 · 재핀=덮어쓰기 · 재시작 유지
        import ui_theme as _uth0
        # ⚠ 글꼴을 안 적으면 TkDefaultFont 로 그려져 이 버튼만 33px 로 솟았다
        #   (⚑ 글리프는 Segoe 폴백이지만 높이는 요청 글꼴이 정한다 — 실측).
        # ⚠⚠⚠ **글꼴을 「가진 폰트」로 적어야 한다** (2026-09-05 실측 — 이 단추
        #   **하나가 220ms**였다. `⚑`(U+2691)가 맑은 고딕에 없어 Tk 가 시스템
        #   폰트를 훑어 폴백을 찾는다).
        #   ⇒ **`Segoe UI Symbol` 로 명시**하면 **107ms → 6ms**, 모양은 그대로다
        #     (다른 기호 `⚙`15 · `⏺`6 · `◈`1 은 문제가 없다 — 이 글자만이다).
        #   ★ §29 ④ 「컬러 이모지 금지 — 첫 렌더 시 콜드로드」와 **같은 자리**다.
        _pin_btn = tk.Button(p1_ctrl, text='⚑',
                             command=self._pin_current,
                             **{**_flat_kw, 'padx': 5,
                                'font': ('Segoe UI Symbol', 9),   # ★ 74 — 10 이면 다른 단추보다 5px 높았다(33 vs 28)
                                'fg': _C('accent', '#2C3E50')})
        _pin_btn.pack(side='left', padx=(0, 2))
        self._attach_tooltip(_pin_btn,
                             lambda: i18n.t('UM_PIN_TIP', '이 구절을 복귀 기준점으로'))
        self._pin_chips_f = tk.Frame(p1_ctrl, bg=_uth0.C('bg') or '#FFFFFF')
        self._pin_chips_f.pack(side='left', padx=(0, 4))
        self._render_pin_chips()

        # ── Recent · Font · 재생/녹음 4개를 나란히 (2026-08-12 사용자 지시) ──────
        #   예전에는 이 넷이 `side='right'` 로 오른쪽 끝에 흩어져 있어서, 가운데
        #   지도 콤보들에 밀려 서로 멀리 떨어져 있었다.
        _rs_btn = tk.Button(p1_ctrl, text=i18n.t('RS_BTN', 'Font'),
                            command=self._open_reading_setup, **_flat_kw)
        # ★★ **Font·재생 묶음을 오른쪽 끝에 못 박는다** (2026-08-23).
        #   실측 — 창을 1024 로 줄이면 이 묶음이 **줄 밖으로 밀려 녹음(⏺)·
        #   설정(⚙) 단추가 통째로 사라졌다.** 왼쪽부터 차례로 쌓는 방식이라
        #   가운데 핀 칩(223px)이 늘면 끝에 있는 것부터 잘린다(내 변경 이전에도
        #   37px 넘쳤고, 「역본비교」 글자로 바꾸며 66px 이 됐다).
        #   ⇒ `side='right'` 로 **오른쪽에 고정**하면 좁아질 때 가운데(핀 칩)가
        #     줄어들 뿐 도구는 안 사라진다.
        #   ⚠ 자리는 위에서 미리 잡은 `_p1_right_f` 다(`in_=`). 그 안에서는
        #     `side='left'` 로 자연스러운 왼→오 순서를 쓴다 — `side='right'` 를
        #     쓰면 순서가 뒤집힌다(§50 함정).
        _rs_btn.pack(in_=self._p1_right_f, side='left', padx=(2, 16))   # ★ ▶ 와 더 띄운다(74-10)
        self._attach_tooltip(_rs_btn, lambda: i18n.t('RS_TITLE', '읽기 설정'))

        _pb = dict(font=("Malgun Gothic", 9, "bold"), bd=0, padx=8, pady=2)
        # ⚠⚠⚠ **맑은 고딕에 없는 기호는 폰트를 함께 적는다** (2026-09-05 실측).
        #   `⚑` 를 고치자 비용이 `⏺` 로 **옮겨갔다**(275ms) — 즉 **첫 폴백 글자
        #   하나가 비싸고** 그 뒤는 캐시된다. 기호 단추마다 「가진 폰트」를
        #   적으면 그 탐색 자체가 없어진다.
        #   ⚠ `▶ ` 는 맑은 고딕에 있어 그대로 둔다 — **없는 글자만** 바꾼다.
        _sb = dict(_pb, font=("Segoe UI Symbol", 9, "bold"))
        _play_btn = tk.Button(p1_ctrl, text="▶", command=self._p1_play_start,
                              bg="#1E8449", fg="white", **_pb)
        _play_btn.pack(in_=self._p1_right_f, side='left', padx=1)

        # ★ 2026-10-13 (74-5) — 정지 기호 ■ 를 되돌린다. 「제목 앞 ■ 걷기」(2026-09-07)의 예외였는데 함께 지워져 빈 단추였다.
        _stop_btn = tk.Button(p1_ctrl, text="■", command=self._p1_play_stop,
                              bg="#D5D8DC", fg="#922B21", **_pb)
        _stop_btn.pack(in_=self._p1_right_f, side='left', padx=1)

        _rec_btn = tk.Button(p1_ctrl, text="⏺", command=self._show_voice_bible,
                             bg="#922B21", fg="white", **{**_sb, 'padx': 5})
        _rec_btn.pack(in_=self._p1_right_f, side='left', padx=1)

        self._p1_settings_btn = tk.Button(p1_ctrl, text="⚙",
                                          command=self._p1_open_settings,
                                          bg="#D5D8DC", fg="#333", **_sb)
        self._p1_settings_btn.pack(in_=self._p1_right_f, side='left', padx=(1, 6))
        # ★ 2026-10-13 (docs/1.txt 74-1) — ▶ ■ ⏺ ⚙ 마우스 풍선 걷음(사용자 「오히려 걸림돌」)
        self._tlog('p1.t1: fav/cmp/recent done')

        self._cov_lbl = tk.Label(p1_ctrl, text='', font=('Malgun Gothic', 8, 'bold'),
                                 fg='white', padx=5, pady=1)

        # ── 맵 콤보 2종(장 맵·전역 최근)·✕·개수 Entry 는 2026-08-20 이관·폐지
        #    (0.txt 2번 승인 — P1 bar 는 성경 읽기 도구만. 맵 열기·삭제 =
        #     P4 구절연결 bar 의 콤보 + MapManager. 단일 슬롯 시대라 고를
        #     목록 자체가 줄었다. 자동 복원은 콤보와 무관하게 그대로다.)
        self._tlog('p1.t1: ctrl bar done')

        if not hasattr(self, 'map_switchers'):
            self.map_switchers = {}

        # ── 엔티티 티커 (구절 관련 용어) ─────────────────────────────────────
        # ★★ **칩 색을 유형으로 가르지 않는다** (2026-08-30 사용자 지시
        #   「종류에 따라 색상을 차별화하고 있는데 통일하자 · 표준 테마에 잘
        #   어울리는 배경색/글자로」).
        # ⚠⚠ 유형별 파스텔이 **클릭하면 색이 변하는** 정체였다 — 열 쌍 가운데
        #   `#D6EAF8`(인물)·`#1A5276` 만 `ui_theme` 의 색→역할 표에 들어 있어서,
        #   P4 가 지어지며 도는 `paint` 가 **그 칩만** 다시 칠했다. 나머지는 굳은
        #   채 남아 한 줄 안에서 색이 갈렸다. 오류도 안 났다.
        #   ⇒ 유형은 이름이 말한다. 색은 **역할 한 쌍**뿐이다(§0 하드코딩 금지).

        _tbg = _C('panel_alt', '#F0F3F4')
        self._ticker_f = tk.Frame(tab1_f, bg=_tbg, height=30)
        self._ticker_f.pack(side='bottom', fill='x', padx=2, pady=(0, 2))
        self._ticker_f.pack_propagate(False)

        # ★★ **[My Edit] — 이 줄의 맨 왼쪽에 고정** (2026-08-30 사용자 지시
        #   「엔티티 열거하는 P1 하단 화면의 가장 왼쪽에 My Edit 버튼 고정
        #   배치하라 · 구절이 클릭된 상태에서 클릭하면 재고창고의 **태그 고르기**
        #   버튼을 누른 것과 같은 팝업」).
        #   ⚠ 스크롤 칸(`_ticker_cvs`) **밖**에 둔다 — 안에 넣으면 칩을 옆으로
        #     밀 때 단추까지 밀려 사라진다(「고정 배치」가 그 뜻이다).
        # ★★★ 차례 = `[Lexicon] │ 라벨들 … › │ [My Edit]` (2026-09-15 `1.txt`
        #   3번 5) 사용자 「Lexicon | 엔티티 라벨들, 더보기 표시(>>>), My Edit」).
        #   Lexicon 은 **이 절의 낱말 전부**를 P4 주요용어(원어 모드)에 펴는
        #   문이다 — 라벨(승격된 용어)과 같은 화면으로 가되 왼쪽 칸이 다르다.
        self._ticker_lex_btn = tk.Button(
            self._ticker_f, text=i18n.t('EB_LEX_BTN', 'Lexicon'),
            command=self._open_lexicon, **_flat_kw)
        self._ticker_lex_btn.pack(side='left', padx=(6, 4))
        tk.Frame(self._ticker_f, bg=_C('border', '#D5D8DC'), width=1).pack(
            side='left', fill='y', pady=4, padx=(0, 4))
        # ★ 2026-10-11 (docs/1.txt 4-2) — 「이 구절이 나오는 곳 N」: 도서·설교·문답 편으로 가는 길 안내.
        #   P4 「내부연결」 갈래를 걷고 여기로 옮겼다(읽을 거리가 아니라 길이다). 0 이면 안 보인다.
        self._ticker_nav_btn = tk.Button(
            self._ticker_f, text='', command=self._open_nav_menu, **_flat_kw)
        self._ticker_nav_sep = tk.Frame(self._ticker_f, bg=_C('border', '#D5D8DC'), width=1)
        self._nav_here = []
        # [My Edit] — 오른쪽 끝(스크롤 칸 밖 — 칩을 밀어도 안 밀린다)
        self._ticker_edit_btn = tk.Button(
            self._ticker_f, text=i18n.t('OE_BTN', 'My Edit'),
            command=self._ticker_pick_tags, **_flat_kw)
        self._ticker_edit_btn.pack(side='right', padx=(4, 6))

        # › 버튼: side='right' 을 expand 위젯보다 먼저 pack 해야 공간 확보됨
        tk.Button(
            self._ticker_f, text='›', bg=_tbg, fg=_C('fg_dim', '#555555'),
            font=('Malgun Gothic', 11), relief='flat', bd=0,
            padx=5, cursor='hand2', activebackground=_C('accent_bg', '#D0D0D0'),
            command=lambda: self._ticker_cvs.xview_scroll(3, 'units')
        ).pack(side='right', padx=(2, 4), pady=2)

        self._ticker_cvs = tk.Canvas(
            self._ticker_f, bg=_tbg, height=30,
            bd=0, highlightthickness=0)
        self._ticker_cvs.pack(side='left', fill='both', expand=True)

        self._ticker_inner = tk.Frame(self._ticker_cvs, bg=_tbg)
        self._ticker_cvs.create_window((0, 0), window=self._ticker_inner, anchor='nw')

        def _ticker_conf(e):
            self._ticker_cvs.config(scrollregion=self._ticker_cvs.bbox('all'))
        self._ticker_inner.bind('<Configure>', _ticker_conf)

        def _ticker_wheel(e):
            self._ticker_cvs.xview_scroll(-1 if e.delta > 0 else 1, 'units')
        self._ticker_cvs.bind('<MouseWheel>', _ticker_wheel)
        self._ticker_inner.bind('<MouseWheel>', _ticker_wheel)
        self._tlog('p1.t1: ticker done')

        # ─────────────────────────────────────────────────────────────────────
        p1_ls_frame = tk.Frame(tab1_f)
        p1_ls_frame.pack(expand=True, fill='both', padx=2, pady=2)

        # ★ Listbox → Text (2026-08-12 사용자 지시).
        #   `tk.Listbox` 는 **한 항목 = 한 줄이고 wrap 이 없어** 폭이 좁으면 본문 뒤가
        #   잘렸다. 가로 스크롤바로 밀어 보는 수밖에 없었다.
        #   `VerseTextList` 가 Listbox 와 **같은 이름의 메서드**를 제공하므로 아래
        #   호출부(selection_set·curselection·see·get·nearest…)는 그대로 둔다.
        #   ⚠ 가로 스크롤바는 없앴다 — wrap 이 있으면 가로로 넘칠 일이 없다.
        self.p1_ls = VerseTextList(p1_ls_frame, db_path=self.db_path)
        self.p1_ls.pack(expand=True, fill='both')
        self.p1_ls.bind("<<ListboxSelect>>", self.on_verse_selected)

        # ── Tab 2: 묵상 플랜 ──────────────────────────────────────────────────
        self._mark('p1.tab1(bible) done')
        tab2_f = tk.Frame(self.p1_nb)
        self.p1_nb.add(tab2_f, text=' '+i18n.t('TAB_P1_PLAN','묵상 플랜')+' ')
        self._tab_plan = tab2_f   # 탭 인덱스 하드코딩 대신 위젯 참조 (재배치 안전)

        # ★ **매뉴얼 아이콘 전용 띠를 없앴다** (2026-08-14 사용자 지적
        #   「현재 m 버튼 이외에는 텅 비어있다」). 아이콘 하나가 24px 를 통째로
        #   먹고 있었다. 그 자리는 **서브탭 헤더**가 쓰고, 아이콘은 그 아래
        #   서브탭 안의 빈 bar 로 내려간다(`_build_p1_plan`).

        # 묵상플랜 내용(PlanMainView×3 + 렌즈)은 무거움(~0.8s) → 지연 빌드 등록.
        # 첫 페인트 후/탭 선택 시 _build_p1_plan 으로 채워진다(점프 경로는 _ensure_p1_tab 으로 안전).
        self._p1_builders[tab2_f] = self._build_p1_plan

        # ── Tab 3: 도서읽기 + 설교집 통합 ────────────────────────────────────
        self._mark('p1.tab2(plan x3 + lens) done')
        # Tab3 도서/설교 · Tab4 나의묵상 · 최신콘텐츠 · 공지 — 모두 지연빌드(프레임만 등록)
        tab3_f = tk.Frame(self.p1_nb)
        self.p1_nb.add(tab3_f, text=' '+i18n.t('TAB_P1_READING','도서/설교집')+' ')
        self._tab_reading = tab3_f
        self._p1_builders[tab3_f] = self._build_p1_reading

        tab4_f = tk.Frame(self.p1_nb)
        self.p1_nb.add(tab4_f, text=' '+i18n.t('TAB_P1_MYPATH','나의 묵상')+' ')
        self._tab_mypath = tab4_f
        self._p1_builders[tab4_f] = self._build_p1_mypath

        # ⚠ **최신 콘텐츠는 P4 로 옮겼다**(2026-09-26 · 1.txt 20번 3) —
        #   사용자 「P1 은 성경구절과 서비스 중심으로」 · 그 탭은 성경구절·
        #   묵상플랜과 무관하다. 지금 자리 = P4 **온라인 영상 오른쪽**.
        #   ★ 배너 슬롯 `p1_latest` 도 함께 따라갔다 — 그래서 앱을 켜자마자
        #     배너를 보는 일이 없어졌다(찾아 들어간 사람에게만 보인다).

        # 공지/소통 — 맨 끝, 지연빌드 (2026-08-19 재편: 공지·FAQ·내문의·개인정보·정보)
        announce_f = tk.Frame(self.p1_nb)
        self._announce_base = i18n.t('TAB_P1_ANNOUNCE', '공지/소통')
        self._tab_announce = announce_f
        self.p1_nb.add(announce_f, text=' '+self._announce_base+' ')
        self._p1_builders[announce_f] = self._build_p1_announce

        # ── 설정 (다운로드 + 환경설정) — 2026-08-19 재편 ────────────────────
        feedback_f = tk.Frame(self.p1_nb)
        self._feedback_base = i18n.t('TAB_P1_FEEDBACK', '설정')
        self._tab_feedback = feedback_f
        self.p1_nb.add(feedback_f, text=' '+self._feedback_base+' ')
        self._p1_builders[feedback_f] = self._build_p1_feedback
        self._mark('p1.tabs registered (lazy)')

        self.p1_nb.bind('<<NotebookTabChanged>>', self._on_p1_tab_change)
        # ★ 왼쪽 탭 막대(설정 ▸ 화면 배치 · 317차-26) — 서브탭이 있는 탭은 고르면 그 아래에
        #   서브탭이 펼쳐진다. 서브 노트북은 지연 빌드라 **물어보는 함수**로 넘긴다.
        #   ★ 도서/설교집도 넘긴다(317차-27 사용자 「서브메뉴 표시가 안된다」) — 갈래 노트북
        #     (`_left_nb` · 원래 줄이 감춰져 있다)을 막대에 펼치고, 고르는 것은 그 화면의 문
        #     `_pick_sub` 로 한다(`_rail_pick` · 서재 닫기·위 띠 단추가 함께 맞는다).
        try:
            import side_rail
            _sv = lambda a: (lambda: getattr(getattr(self, a, None), '_nb', None))
            self.p1_rail = side_rail.SideRail(
                self.p1_f, self.p1_nb, self.db_path, 'P1', 'P1Focus.TNotebook',
                strip=self._p1_focus_strip,
                subs={str(tab2_f): lambda: getattr(self, 'p1_plan_nb', None),
                      str(tab3_f): lambda: getattr(getattr(self, 'p1_reading_view', None),
                                                   '_left_nb', None),
                      str(tab4_f): _sv('p1_my_path'),
                      str(announce_f): _sv('p1_announce_view'),
                      str(feedback_f): _sv('p1_feedback_view')},
                focus_builder=lambda h: self._add_p1_focus(h, padx=(4, 2)))
            self.p1_rail.apply(side_rail.get_mode(self.db_path, 'P1'))
        except Exception as e:
            print('[p1 rail] %s' % e)
        # 직전 P1 서브탭 복원 — 사용자 습관 화면을 먼저 보여줌(없으면 성경읽기=0).
        # 지연 서브탭 내용은 첫 페인트 후 빌드(_p1_startup 중 선택은 핸들러 빌드 생략).
        self._p1_startup = True
        try:
            _lp1 = int(self._load_state('last_p1_tab', 0))
            if 0 <= _lp1 < self.p1_nb.index('end'):
                self.p1_nb.select(_lp1)
        except Exception:
            pass
        self.after(240, self._post_paint_build_p1)

    def _post_paint_build_p2_ui(self):
        """첫 페인트 후 P2(연구 워크벤치) 빌드 — phased build. 시작 단일 최대비용(~1.0s)을 페인트 뒤로.
        P2 접근부는 모두 가드돼 있어, 첫 구절 로드(after 500ms)는 P2 빌드(120ms) 후라 정상 반영."""
        if hasattr(self, '_p2_tabs'):
            return
        self._mark('p2 build (post-paint) start')
        self._setup_p2_ui(self.top_pw)
        self._mark('p2 build (post-paint) done')
        # 빌드 전 이미 선택된 구절이 있으면 P2 DESC를 채움
        vid = getattr(self, '_p1_verse_id', None)
        if vid:
            try:
                self._update_p1_desc(vid)
            except Exception:
                pass

    def _setup_p2_ui(self, parent_pw):
        """P2 — **설명 · 묵상노트 두 탭**(2026-10-13 docs/1.txt 75 다시 지음).

        ★ 사용자 「P2 화면을 깔끔하게 정리하라 · 예전 코드 모두 제거하고 영향이 없도록 · 두 버튼은 윗줄 유지」.
          주석·영상·연구자료·말씀흐름·찬양은 P4 탭이 맡는다(2026-10-07 51-4) — 그때 「지우지 않고 잠근」 9탭 장치
          (더보기·통합목록·탭 설정·갈래 표 넷)를 걷었다. 그 잠금 때문에 **시작할 때 숨은 「더보기」 몸통이 열리던**
          결함도 함께 사라진다.
        · 윗줄 = [약명] [설명] [묵상노트(N)] …… [My Edit] [M] — My Edit·M 은 두 탭 공통이라 윗줄에 둔다.
        · 설명 탭 첫 줄 = [책][장][단락][일반][전문] …… [언어] — 언어 콤보는 설명에만 있다(P4 오른쪽 칸과 같은 모양).
        """
        self.p2_f = ttk.Frame(parent_pw)
        parent_pw.add(self.p2_f, minsize=PANE_MIN)

        from branch_tabs import SplitTabs
        self.P2_ORDER = ('DESC', 'NOTE')
        self._p2_tabs = SplitTabs(self.p2_f, db_path=self.db_path, state_key='P2_TAB',
                                  main=list(self.P2_ORDER), on_change=self._on_p2_tab)
        self._p2_tabs.pack(expand=True, fill='both')
        T = self._p2_tabs

        # 윗줄 오른쪽 — [My Edit] [M] (두 탭 공통 · M 은 탭마다 제 사용방법)
        self._p2_m_of = {'DESC': 'U_P2_DESC', 'NOTE': 'U_P2_NOTE'}
        tools = tk.Frame(T.bar())
        tools.pack(side='right', padx=(0, 2))
        m_slot = tk.Frame(tools)                  # ★ M 자리를 먼저 잡는다 — M 은 늘 맨 오른쪽
        m_slot.pack(side='right')
        self._p2_m_icons = {}
        for code in ('U_P2_DESC', 'U_P2_NOTE'):
            ic = self._manual_at(m_slot, code, padx=(0, 4))
            if ic is not None:
                ic.pack_forget()
                self._p2_m_icons[code] = ic
        self._p2_me_btn = tk.Button(tools, text=i18n.t('OE_BTN', 'My Edit'),
                                    command=self._p2_my_edit_click, **ui_theme.flat_btn())
        self._p2_me_btn.pack(side='right', padx=(4, 4))
        self._p2_tools_f = tools

        from desc_comm_group import DescCommGroup
        self._p2_dg = DescCommGroup(
            T.frame_for('DESC'), self.db_path,
            refresh_desc=lambda: self._update_p1_desc(getattr(self, '_p1_verse_id', None)),
            make_comm=None, state_key='P2_DG',
            ref_host=T.left_slot(),               # 약명은 윗줄 맨 왼쪽(1.txt 22)
            lang_only=True,                       # 언어 콤보 = 설명 언어만(주석 변형 없음)
            on_role_ask=self._p2_role_ask)        # [전문] 「분야 ▾ ▸ AI 에게 묻기」(76-3)
        self._p2_dg.pack(fill='both', expand=True)
        self.desc_txt = scrolledtext.ScrolledText(self._p2_dg.desc_frame(),
                                                  font=("Malgun Gothic", 10), bd=0)
        self.desc_txt.pack(expand=True, fill='both', padx=5, pady=5)
        self.desc_txt.config(state='disabled', wrap='word')
        theme_font.register(self.desc_txt, self.db_path, 'desc')   # 읽는 본문
        try:
            from reading_pane import enable_copy
            enable_copy(self.desc_txt)      # 드래그 선택 + Ctrl+C (2026-08-17)
        except Exception:
            pass
        self._p2_dg.finish()

        T.add('DESC', 'P2T_DESC', '설명')
        T.add('NOTE', 'P2T_NOTE', '묵상노트')
        note_f = T.frame_for('NOTE')
        self._p2_lazy = {'NOTE': [('p2_note_panel', lambda fr=note_f: self._build_p2_note(fr))]}

        self.vb_panel = None      # 누를 때 만든다(_voice_panel)

        self._p2_startup = True
        T.finish()                # 옛 저장값(MORE 등)은 첫 탭(설명)으로 물러난다
        self.after(260, self._post_paint_build_p2)

    def _post_paint_build_p2(self):
        """첫 페인트 후, 직전 P2 서브탭(보이는 것) 내용 빌드."""
        self._p2_startup = False
        if not hasattr(self, '_p2_tabs'):
            return
        try:
            self._ensure_p2_tab_built(self._p2_tabs.current())
        except Exception:
            pass

    # Focus 트리뷰 동기화
    def _sync_p4_tree_from_canvas(self):
        """탭 전환 시 캔버스 상태를 Research Tree 탭에 반영합니다."""
        if not hasattr(self, 'focus_tree'): return
        if not hasattr(self.p4_view, 'nodes') or not self.p4_view.nodes: return

        journey = getattr(self, 'current_journey_list', [])
        ref_vid = next((v for v in reversed(journey) if v in self.p4_view.nodes), None)

        if not ref_vid:
            roots = [v for v, d in self.p4_view.nodes.items() if not d.get('p_id')]
            if not roots: return
            ref_vid = roots[0]

        self._populate_focus_tree_root(ref_vid)

    # ── 영상 연결 델타 — 앱 안 자동 수신 (2026-09-29 293차) ─────────────
    #: 다시 깨어나기 상한·하한 — 계산이 어긋나도 이 사이에서 한 번은 다시 묻는다.
    _PACK_WAKE_MIN = 60
    _PACK_WAKE_MAX = 6 * 3600

    # ── 유튜브 간편 저장 (2026-10-09 1.txt 59-3) ─────────────────────────
    def _yt_setup(self):
        """**하가로 돌아올 때** 클립보드를 한 번 본다 + 127.0.0.1 받는 곳(확장 프로그램).
        ★ 1초마다 보던 감지를 걷었다(2026-10-09 사용자 「다른 목적으로 복사한 것일 수도
          있다」 → 「하가 앱이 포커스가 주어질 때」).
        ⚠ 받는 자리를 트레이가 이미 쓰고 있으면 여기서는 안 연다 — 그때는 트레이가
          알림 창을 따로 띄운다."""
        try:
            import yt_intake as YT
            YT.HOOKS['cfg'] = self._yt_cfg
            YT.HOOKS['edit'] = lambda uid, url, title: self._yt_offer(url, title, uid=uid)
            # ★ 2026-10-12 사용자 — 주소 복사는 **늘 묻는다** · 확장 단추는 **늘 받는다**(체크상자 둘 걷음)
            self._yt_watch = YT.ReturnWatch(self, self._yt_offer, enabled=lambda: True,
                                            db_path=self.db_path)
            self._yt_watch.start()
            self._yt_srv = YT.LinkServer()
            self._yt_srv.start()
            self.after(500, self._yt_poll)
        except Exception as e:
            print('[yt setup] %s' % e)

    def _yt_cfg(self, key, on):
        import yt_intake as YT
        srv = getattr(self, '_yt_srv', None)
        if key == YT.CFG_SERVER and srv is not None:
            if on and srv.httpd is None:
                srv.start()
            elif not on:
                srv.stop()

    def _yt_poll(self):
        srv = getattr(self, '_yt_srv', None)
        self._yt_keep_port(srv)
        try:
            while srv is not None:
                url, title = srv.q.get_nowait()
                import yt_intake as YT
                if YT.quiet_on(self.db_path):        # 조용히 저장 — 받은 목록에만 · 연결은 나중에
                    import threading
                    threading.Thread(target=lambda u=url, t=title: (
                        YT.quiet_save(self.db_path, u, t, getattr(self, 'lang', 'KO')),
                        self.after(0, lambda: self._yt_saved(None))), daemon=True).start()
                else:
                    self._yt_offer(url, title)
        except Exception:
            pass
        self.after(500, self._yt_poll)

    def _yt_keep_port(self, srv):
        """확장 프로그램 단추 받는 자리를 지킨다 (2026-10-12 사용자 「크롬 단추가 안 된다」).

        ⚠⚠ 앱이 켜질 때 **옛 판 트레이**가 자리를 쥐고 있어 앱은 물러났고, 옛 트레이는 확장이
          못 읽는 답(웹 화면)을 내서 확장이 「하가를 켜세요」라고 보였다. 그 트레이가 꺼진 뒤에는
          아무도 안 듣는 자리가 되었다.
          ① 자리가 비면 몇 초마다 다시 잡는다(`ensure`) ② 남이 쥐고 있는데 **옛 판**이면
          트레이를 새 판으로 바꾼다(한 번만 · 새 트레이가 옛 것을 닫는다).
        """
        if srv is None or srv.httpd is not None:
            return
        try:
            import time as _time
            if srv.ensure():
                return
            now = _time.time()
            if now - getattr(self, '_yt_old_chk', 0.0) < 30 or getattr(self, '_yt_replaced', False):
                return
            self._yt_old_chk = now

            def _probe():
                if srv.holder_old():
                    self._yt_replaced = True
                    import tray_agent as _tray
                    _tray.launch(replace=True)
                    print('[yt] 옛 판 트레이가 단추 받는 자리를 쥐고 있어 새 판으로 바꿉니다.')
            import threading
            threading.Thread(target=_probe, daemon=True).start()
        except Exception as e:
            print('[yt port] %s' % e)

    def _yt_offer(self, url, title='', uid=None):
        try:
            import yt_save_win
            yt_save_win.offer(self, self.db_path, url, title, getattr(self, 'lang', 'KO'),
                              on_saved=self._yt_saved, uid=uid)
        except Exception as e:
            print('[yt offer] %s' % e)

    def _yt_saved(self, uid):
        """저장 뒤 — 받은 영상 목록·배지를 다시 그린다."""
        for holder in (getattr(self, 'p1_feedback_view', None), getattr(self, 'p1_announce_view', None)):
            v = getattr(holder, 'ytsave', None) if holder is not None else None
            if v is not None:
                try:
                    v.refresh()
                except Exception:
                    pass
        try:
            self._on_lang_badges()
        except Exception:
            pass

    def _housekeep_once(self):
        try:
            import threading
            import app_housekeep
            threading.Thread(target=app_housekeep.run_daily, daemon=True).start()
        except Exception as e:
            print('[housekeep] %s' % e)

    def _pack_sync_tick(self):
        """차례면 일꾼 스레드로 받고, 아니면 **다음 차례에 맞춰 한 번만** 다시 깨어난다.

        ⚠ 10분 폴링을 걷었다(사용자 「과도하다」) — `sync_schedule.seconds_until`
          이 다음 때를 준다(부팅 지터·주기·백오프 모두 같은 잣대).
        ⚠ Tk 는 스레드 안전하지 않다(§279차 ⑭) — 스레드는 **DB 만** 만지고
          화면 갱신은 메인이 `after` 폴링으로 한다.
        """
        if getattr(self, '_closing', False):
            return
        try:
            self._ai_models_tick()
        except Exception as e:                               # noqa: BLE001
            self._quiet('[AI모델] 수신 판정 오류: %s' % e)
        try:
            self._yt_playlist_tick()
        except Exception as e:                               # noqa: BLE001
            self._quiet('[재생목록] %s' % e)
        try:
            self._pack_sync_start()
        except Exception as e:                               # noqa: BLE001
            self._quiet('[pack] 자동 수신 판정 실패: %s' % e)
        wait = self._pack_next_wait()
        try:
            self.after(int(wait * 1000), self._pack_sync_tick)
        except Exception:
            pass

    def _yt_playlist_tick(self):
        """「+Hagah」 재생목록을 몇 시간마다 읽는다(2026-10-11) — 일꾼 스레드는 DB·망만 · 화면은 안 만진다."""
        import threading
        if getattr(self, '_ytl_busy', False) or getattr(self, '_closing', False):
            return
        self._ytl_busy = True

        def _work():
            try:
                import yt_intake as _YT
                _YT.playlist_tick(self.db_path)
            except Exception as e:                           # noqa: BLE001
                print('[재생목록] %s' % e)
            finally:
                self._ytl_busy = False
        threading.Thread(target=_work, daemon=True).start()

    def _ai_models_tick(self):
        """AI 모델 목록을 **하루 한 번** 받는다(일꾼 스레드 + 큐 + `after` 폴링).

        ★★★ 왜 팩과 따로인가 — ⓐ **자료 자동받기 스위치를 안 탄다**(설정값이지
          자료가 아니다 · 트레이 `check_once` 와 같은 판단) ⓑ 팩 실패가
          백오프를 걸어도 이것은 그대로 받아야 한다(회사가 판을 물리면 404 다).
        ⚠ 제 차례는 제 시계로 잰다(`should_auto_sync` 24시간) — 팩 일정에 얹으면
          자동받기를 끈 사람이 영영 못 받는다.
        ⚠ Tk 는 스레드 안전하지 않다(§279차 ⑭) — 스레드는 **DB·망만** 만진다.
        """
        import queue
        import threading
        if getattr(self, '_aim_busy', False) or getattr(self, '_closing', False):
            return
        self._aim_busy = True
        q = queue.Queue()

        def _work():
            try:
                import rss_reader as _R
                import rss_transport as _RT
                with appdb.connect(self.db_path) as c:
                    if not _R.should_auto_sync(c, 'aimodels', min_hours=24):
                        q.put(('SKIP', ''))
                        return
                    r = _R.sync_aimodels(c, _RT.client_servers())
                    # ★ 2026-10-24 앱이 받는 채널 번호(내가 모은 채널과 겹치면 제 받기를 멈춘다)
                    try:
                        _R.sync_app_channels(c, _RT.client_servers())
                    except Exception:                         # noqa: BLE001
                        pass
                    # ★ 2026-10-23 추천몰도 같은 일꾼이 받는다(하루 한 번 · 받으면 쇼핑몰 탭을 다시 잰다)
                    try:
                        _s = _R.sync_shop(c, _RT.client_servers())
                        if _s.get('status') == 'UPDATED' or _s.get('images'):
                            self._shop_dirty = True
                    except Exception:                         # noqa: BLE001
                        pass
                    # ⚠⚠ **결과와 상관없이 때를 적는다** — 안 적으면 아직 발행 전
                    #   (`NO_MODELS`)이거나 망이 없을 때 **깨어날 때마다**(자동받기를
                    #   끄면 하한 60초) 서버를 두드린다. 최신 콘텐츠 화면과 같은 규칙.
                    _R.mark_auto_sync(c, 'aimodels')
                    q.put((r.get('status') or '?', r.get('message') or ''))
            except Exception as e:                           # noqa: BLE001
                q.put(('ERROR', str(e)[:80]))

        threading.Thread(target=_work, daemon=True).start()
        self._ai_models_poll(q)

    # ── 앱 새 판(2026-10-25) — 하루 한 번 확인 · 받아 두고 · 위에 알림 한 줄 · 다음 시작 때 바뀐다 ─────────
    def _app_update_tick(self, force=False):
        """일꾼 스레드가 판 목록을 보고 새 판을 미리 받는다(데이터는 안 건드린다 · `app_update`).

        ★ 사용자 「설정화면에 배치해야 하는가 아니면 업데이트 알림을 보내서」 → 알림이 기본(이 띠) · 설정 ▸ 앱 관리가 보조.
        ⚠ Tk 는 스레드 안전하지 않다 — 스레드는 망·파일만, 화면은 메인이 `after` 로.
        """
        import queue
        import threading
        if getattr(self, '_upd_busy', False) or getattr(self, '_closing', False):
            return
        self._upd_busy = True
        q = queue.Queue()

        def _work():
            try:
                import app_update
                import rss_reader as _R
                with appdb.connect(self.db_path) as c:
                    if not force and not _R.should_auto_sync(c, 'appupdate', min_hours=24):
                        q.put({'status': 'SKIP'})
                        return
                    _R.mark_auto_sync(c, 'appupdate')
                q.put(app_update.check())
            except Exception as e:                           # noqa: BLE001
                q.put({'status': 'ERROR', 'message': str(e)[:80]})

        threading.Thread(target=_work, daemon=True).start()
        self._app_update_poll(q)

    def _app_update_poll(self, q):
        import queue
        try:
            r = q.get_nowait()
        except queue.Empty:
            if not getattr(self, '_closing', False):
                self.after(700, lambda: self._app_update_poll(q))
            return
        self._upd_busy = False
        self._upd_last = r
        if r.get('status') == 'READY':
            self._show_update_bar(r)
        if not getattr(self, '_closing', False):
            self.after(6 * 3600 * 1000, self._app_update_tick)   # 켜 둔 채로도 하루에 한 번은 본다(판정이 24시간을 지킨다)
        cb = getattr(self, '_upd_cb', None)
        if cb:
            self._upd_cb = None
            try:
                cb(r)
            except Exception:                                # noqa: BLE001
                pass

    def _show_update_bar(self, r):
        """앱 맨 위 알림 한 줄 — 「새 판 … — 다시 켜면 바뀝니다 [바뀐 점] [지금 다시 시작] ✕」(팝업으로 막지 않는다)."""
        try:
            if getattr(self, '_upd_bar', None) is not None:
                self._upd_bar.destroy()
            bar = tk.Frame(self, bg=ui_theme.C('warning_bg') or '#FFF4D6')
            bg = bar.cget('bg')
            tk.Label(bar, text=i18n.t('UPD_BAR', '새 판 %s 이 준비되었습니다 — 앱을 다시 켜면 바뀝니다(내 자료는 그대로).')
                     % r.get('version', ''), bg=bg, fg=ui_theme.C('fg') or '#222222', anchor='w').pack(side='left', padx=(10, 6), pady=3)
            if (r.get('notes') or '').strip():
                tk.Button(bar, text=i18n.t('UPD_NOTES', '바뀐 점'), relief='flat', bg=bg,
                          command=lambda n=r.get('notes'): messagebox.showinfo(i18n.t('UPD_NOTES', '바뀐 점'), n, parent=self)
                          ).pack(side='left', padx=2)
            tk.Button(bar, text=i18n.t('UPD_RESTART', '지금 다시 시작'), relief='flat', bg=bg,
                      fg=ui_theme.C('accent') or '#2471A3', command=self._update_restart).pack(side='left', padx=2)
            tk.Button(bar, text='✕', relief='flat', bg=bg, command=bar.destroy).pack(side='right', padx=6)
            bar.pack(side='top', fill='x', before=self.v_pw)
            self._upd_bar = bar
        except Exception as e:                               # noqa: BLE001
            print('[update bar] %s' % e)

    def _update_restart(self):
        """지금 끄고 다시 켠다 — 새 판은 다시 켤 때 들어간다(트레이에 두기 묻지 않고 완전히 끈다)."""
        try:
            import app_update
            app_update.relaunch()
        except Exception as e:                               # noqa: BLE001
            messagebox.showerror(i18n.t('UPD_RESTART', '지금 다시 시작'), str(e), parent=self)
            return
        try:
            self.destroy()
        except Exception:                                    # noqa: BLE001
            os._exit(0)

    def _ai_models_poll(self, q):
        """일꾼이 끝났나 — 메인 스레드에서만 화면·기록을 만진다."""
        import queue
        try:
            st, msg = q.get_nowait()
        except queue.Empty:
            if not getattr(self, '_closing', False):
                self.after(700, lambda: self._ai_models_poll(q))
            return
        self._aim_busy = False
        if getattr(self, '_shop_dirty', False):
            self._shop_dirty = False
            try:
                self._sync_shop_tab()
            except Exception:                                # noqa: BLE001
                pass
        if st == 'UPDATED':
            self._quiet('[AI모델] 목록 갱신 — %s' % msg)
        elif st in ('ERROR', 'CORRUPT', 'NO_SERVER'):
            # ⚠ **조용히 넘어가지 않는다**(§0-1) — 다만 팩 백오프에는 안 건다
            self._quiet('[AI모델] 못 받았다(%s) %s' % (st, msg))

    def _pack_next_wait(self):
        """다음 깨어날 때까지(초) — 상한 6시간·하한 1분. MANUAL 이면 상한."""
        try:
            import sync_schedule as _SS
            with appdb.connect(self.db_path) as c:
                secs = _SS.seconds_until(c, getattr(self, '_pack_started', 0) or 0)
        except Exception:                                    # noqa: BLE001
            secs = None
        if secs is None:
            return self._PACK_WAKE_MAX
        # ⚠ 방금 받았으면(secs 0 인데 busy) 다음 주기까지 — 0 이면 하한으로
        return max(self._PACK_WAKE_MIN, min(int(secs) + 5, self._PACK_WAKE_MAX))

    def _pack_sync_due(self):
        """받을 차례인가 → (참/거짓, 까닭). 자동받기 스위치 + 주기 판정."""
        import tray_agent as _tray
        import sync_schedule as _SS
        if not _tray.auto_sync_on(self.db_path):
            return False, 'AUTO_OFF'
        with appdb.connect(self.db_path) as c:
            return _SS.should_fetch(c, getattr(self, '_pack_started', 0) or 0)

    def _pack_sync_start(self):
        import queue
        import threading
        import time as _t
        if getattr(self, '_pack_busy', False):
            return
        if not getattr(self, '_pack_started', 0):
            self._pack_started = _t.time()
        go, why = self._pack_sync_due()
        if not go:
            return
        self._pack_busy = True
        q = queue.Queue()

        def _work():
            try:
                import tray_agent as _tray
                n = _tray.fetch_pack_deltas(db_path=self.db_path)
                q.put(('OK', int(n or 0)))
            except Exception as e:                           # noqa: BLE001
                q.put(('FAIL', str(e)[:80]))

        threading.Thread(target=_work, daemon=True).start()
        self._pack_sync_poll(q)

    def _pack_sync_poll(self, q):
        import queue
        try:
            st, val = q.get_nowait()
        except queue.Empty:
            if not getattr(self, '_closing', False):
                self.after(500, lambda: self._pack_sync_poll(q))
            return
        self._pack_busy = False
        try:
            import tray_agent as _tray
            _tray._note_result(st == 'OK', self.db_path)
        except Exception:
            pass
        if st != 'OK':
            self._quiet('[pack] 영상 연결 수신 실패: %s' % val)
            return
        self._quiet('[pack] 영상 연결 델타 %d건 적용' % val)
        if val:
            self._pack_sync_refresh()

    def _pack_sync_refresh(self):
        """받은 것이 **그 세션 안에** 보이게 — 지금 열린 영상 화면을 다시 그린다.

        ⚠ 지어지지 않은 탭은 건드리지 않는다(§29 지연 빌드) — 열 때 새로 읽는다.
        """
        try:
            kv = getattr(self, 'kids_view', None)
            if kv is not None and hasattr(kv, '_reload_tree'):
                kv._reload_tree()
        except Exception as e:                               # noqa: BLE001
            self._quiet('[pack] 온라인 영상 탭 새로 그리기 실패: %s' % e)

    def _tray_touch(self):
        """실행 표식을 5분마다 만진다 — 트레이가 나이로 생사를 판정한다."""
        if getattr(self, '_closing', False):
            return
        try:
            import tray_agent as _tray
            _tray.mark_running()
        except Exception:
            return
        try:
            self.after(5 * 60 * 1000, self._tray_touch)
        except Exception:
            pass

    def _ask_close(self):
        """끄기 대화 (2026-09-03 190차 · 사용자 확정 설계).

        ★ **완전 종료 / 트레이에 두기** 두 길. 트레이를 고르면 본체는 완전히
          꺼지고(메모리 0) 초소형 에이전트만 남아 공지·링크 팩을 받아 둔다.
        ★ **선택을 기억한다** — 매번 묻지 않는다(`user_config['CLOSE_MODE']`).
          다시 묻게 하려면 설정에서 지운다.
        ⚠ 윈도우가 아니면 트레이가 없다 — 대화를 띄우지 않고 그냥 닫는다.
        """
        # ⚠⚠⚠ **X 를 눌렀는데 아무 일도 안 일어나면 안 된다** (2026-09-05
        #   사용자 신고 「사용자 화면 닫기가 안된다」 — 강제 종료해야 했다).
        #   §193차에 같은 증상이 있었고 그때 정체는 **조용히 삼켜진 예외**였다.
        #   ⇒ 여기서부터 끝까지가 한 덩이로 보호된다 — 무엇이 터지든
        #     `finally` 가 창을 닫는다. **닫는 일은 실패할 수 없어야 한다.**
        # ⚠ **남의 창이 grab 을 쥐고 있으면 X 가 메인에 안 온다** — 모달
        #   팝업이 남아 있으면 여기까지 오지도 못하므로 그것부터 푼다.
        # ★ 닫기 시간을 단계별로 적는다(2026-10-09 사용자 「닫으려고 하면 매우 반응이 늦다」) —
        #   늦으면 어디서인지 `close_timing.log` 가 말한다(마지막 한 번만 · 앱 폴더).
        _close_t0 = __import__('time').perf_counter()

        def _ct(label):
            try:
                with open(appdb.app_path('close_timing.log'), 'a', encoding='utf-8') as f:
                    f.write('%s  +%.2fs  %s\n' % (datetime.now().strftime('%H:%M:%S'),
                                                   __import__('time').perf_counter() - _close_t0, label))
            except Exception:
                pass
        try:
            open(appdb.app_path('close_timing.log'), 'w').close()
        except Exception:
            pass
        _ct('X 누름')
        try:
            g = self.grab_current()
            if g is not None and g is not self:
                try:
                    g.grab_release()
                except Exception:
                    pass
        except Exception:
            pass
        mode = ''
        try:
            with appdb.connect(self.db_path) as conn:
                r = conn.execute("SELECT config_val FROM user_config"
                                 " WHERE config_key='CLOSE_MODE'").fetchone()
                mode = (r[0] if r else '') or ''
        except Exception:
            pass
        if sys.platform != 'win32':
            mode = 'EXIT'
        if mode not in ('EXIT', 'TRAY'):
            try:
                mode = self._close_dialog()
            except Exception as e:          # 대화가 못 뜨면 그냥 닫는다
                self._quiet('[close] 대화 실패: %s' % e)
                mode = 'EXIT'
            if mode is None:
                return                      # 취소 — 안 닫는다
        _ct('닫기 방식 = %s' % (mode or '?'))
        self._save_window_state()        # ★ 창 모양 직전값(destroy 전에 — 그 뒤엔 저장이 잠긴다)
        try:
            if mode == 'TRAY':
                self._start_tray()
                _ct('트레이 처리 끝')
        except Exception as e:
            # ⚠ **트레이를 못 띄워도 앱은 닫혀야 한다** — 여기서 막히면
            #   사용자에게는 「X 가 안 먹는다」로 보인다.
            self._quiet('[close] 트레이 시작 실패(무시하고 닫는다): %s' % e)
        finally:
            try:
                self.destroy()
                _ct('창 정리 끝')
                try:
                    import atexit
                    atexit.register(lambda: _ct('프로세스 끝'))
                except Exception:
                    pass
            except Exception as e:
                # 마지막 수단 — Tk 가 못 닫으면 프로세스를 끝낸다.
                self._quiet('[close] destroy 실패 → 강제 종료: %s' % e)
                try:
                    self.quit()
                except Exception:
                    pass
                os._exit(0)

    def _close_dialog(self):
        """끄기 대화 — 'EXIT' | 'TRAY' | None(취소). 선택 기억 체크."""
        import tkinter as _tk
        win = _tk.Toplevel(self)
        win.title(i18n.t('TRAY_CLOSE_TITLE', '앱 종료'))
        win.transient(self)
        win.resizable(False, False)
        try:
            ui_theme.adopt(win)
        except Exception:
            pass
        out = {'v': None}
        _tk.Label(win, text=i18n.t(
            'TRAY_CLOSE_ASK',
            '앱을 완전히 끌까요, 트레이에 두고 소식을 받을까요?'),
            anchor='w', justify='left', padx=14, pady=10).pack(fill='x')
        _tk.Label(win, text=i18n.t(
            'TRAY_CLOSE_HINT',
            '트레이에 두면 본체는 완전히 꺼지고, 아주 작은 프로그램만 남아'
            ' 공지와 링크 자료를 미리 받아 둡니다.'),
            anchor='w', justify='left', padx=14, fg=ui_theme.C('fg_dim'),
            wraplength=380).pack(fill='x', pady=(0, 8))
        # ★ **어디서 바꾸는지 알린다** (2026-09-03 사용자 지적 「종료할 때
        #   비로소 팝업이 나오면 이상하게 생각할 것이다」). 미리 정하는 자리는
        #   설정에 두었고, 여기서는 그 자리를 가리킨다.
        # ⚠ **화면 이름을 글에 박지 않는다** — 탭 이름을 i18n 에서 읽어 넣는다.
        #   박아 두면 이름을 바꿀 때 안내가 거짓이 된다(옛 「나의 길」 사고).
        _tk.Label(win, text=i18n.t(
            'TRAY_CLOSE_WHERE', '이 선택은 설정 ▸ %s 에서 언제든 바꿀 수'
            ' 있습니다.') % i18n.t('SET_TAB_STARTEND', '시작/종료 화면'),
            anchor='w', justify='left', padx=14,
            fg=ui_theme.C('fg_dim'), wraplength=380).pack(fill='x',
                                                          pady=(0, 6))
        remember = _tk.IntVar(value=1)
        _tk.Checkbutton(win, text=i18n.t('TRAY_CLOSE_REMEMBER',
                                         '이 선택을 기억하기'),
                        variable=remember).pack(anchor='w', padx=12)
        row = _tk.Frame(win)
        row.pack(fill='x', padx=12, pady=10)

        def pick(v):
            out['v'] = v
            if remember.get():
                try:
                    with appdb.connect(self.db_path) as conn:
                        cur = conn.execute(
                            "UPDATE user_config SET config_val=?"
                            " WHERE config_key='CLOSE_MODE'", (v,))
                        if cur.rowcount == 0:
                            conn.execute(
                                "INSERT INTO user_config(config_key,"
                                " config_val) VALUES('CLOSE_MODE',?)", (v,))
                        conn.commit()
                except Exception:
                    pass
            win.destroy()

        _tk.Button(row, text=i18n.t('TRAY_CLOSE_TRAY', '트레이에 두기'),
                   command=lambda: pick('TRAY'),
                   **ui_theme.flat_btn()).pack(side='right', padx=(6, 0))
        _tk.Button(row, text=i18n.t('TRAY_CLOSE_EXIT', '완전히 끄기'),
                   command=lambda: pick('EXIT'),
                   **ui_theme.flat_btn()).pack(side='right')
        win.protocol('WM_DELETE_WINDOW', win.destroy)
        # ⚠ 자리를 안 잡으면 화면 맨 구석(+0+0)에 뜬다 — 큰 창 뒤에 묻히거나
        #   모니터가 여럿이면 엉뚱한 곳에 나온다. **부모 가운데**로.
        try:
            win.update_idletasks()
            w, h = win.winfo_width(), win.winfo_height()
            x = self.winfo_rootx() + max(0, (self.winfo_width() - w) // 2)
            y = self.winfo_rooty() + max(0, (self.winfo_height() - h) // 3)
            win.geometry('+%d+%d' % (x, y))
        except Exception:
            pass
        try:
            win.grab_set()
            self.wait_window(win)
        except Exception:
            pass
        return out['v']

    @staticmethod
    def _quiet(msg):
        """⚠⚠⚠ **종료 경로에서 `print` 를 쓰지 않는다** (2026-09-05 사용자
        신고 「사용자 화면 닫기가 안된다」의 **진짜 원인**).

        이 앱은 실행 중에 `sys.stdout` 을 닫는다(§97차). 그 뒤 `print` 는
        `ValueError: I/O operation on closed file` 을 내는데, 그것이
        `_start_tray` 의 `except` 안에서 **또** 터지면서 예외가 `_ask_close`
        밖으로 나갔고, Tk 콜백이 그것을 조용히 삼켜 **X 를 눌러도 아무 일도
        일어나지 않았다**.
        ⚠ 트레이가 이미 떠 있을 때만 나는 조건이라 오래 안 보였다.
        """
        try:
            sys.stderr.write(msg + chr(10))
        except Exception:
            pass

    def _refresh_tray(self):
        """앱이 켜질 때 — 떠 있는 트레이가 옛 판이면 닫고 새 판을 띄운다.
        (트레이가 안 떠 있으면 손대지 않는다 — 트레이는 앱을 닫을 때 뜬다.)"""
        try:
            import subprocess
            import tray_agent as _tray
            if not (_tray.tray_open() and _tray.tray_stale()):
                return
            _tray.launch(replace=True)     # 새 트레이가 옛 것을 닫고 기다린다(앱은 안 기다린다)
            self._quiet('[tray] 옛 판 트레이를 새 판으로 바꿉니다.')
        except Exception as e:
            self._quiet('[tray] 새 판으로 바꾸지 못했습니다: %s' % e)

    def _start_tray(self):
        """트레이 에이전트를 띄운다 — **본체와 별개 프로세스**(앱은 완전히 꺼진다).

        ⚠⚠ **이미 떠 있으면 안 띄운다**(2026-09-05 사용자 신고 「트래이가
          여러개 표시되고 있다」 — 실측 **6개**였다). 트레이 쪽에도 뮤텍스가
          있지만 여기서 막으면 **프로세스조차 안 뜬다**.
        """
        try:
            import subprocess
            import tray_agent as _tray
            if _tray.tray_open():
                if not _tray.tray_stale():
                    self._quiet('[tray] 이미 떠 있어 새로 띄우지 않습니다.')
                    _tray.clear_running()
                    return
                # ★ 옛 판 트레이 — 닫고 새로 띄운다(2026-10-09 · 그렇지 않으면
                #   PC 를 다시 켤 때까지 고친 기능이 트레이에 안 닿는다)
                self._quiet('[tray] 옛 판 트레이를 새 판으로 바꿉니다.')
                _tray.clear_running()
                # ⚠ 기다리지 않는다 — 새 트레이가 옛 것을 닫고 꺼지기를 기다린다(--replace).
                #   여기서 기다리면 X 를 누른 뒤 창이 늦게 닫힌다(2026-10-09 사용자 신고).
                _tray.launch(replace=True)
                return
            _tray.clear_running()          # 곧 꺼진다 — 표식을 먼저 걷는다
            subprocess.Popen(
                [sys.executable, appdb.app_path('tray_agent.py')],
                cwd=appdb.app_path(''),
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        except Exception as e:
            self._quiet('[tray] 시작 실패: %s' % e)

    ### [확정] 캔버스 설정 옵션을 app_state.json 파일에 즉시 저장
    def destroy(self):
        """★ 2026-09-01 (0.txt 1번) — 종료 중 직전값 저장을 잠근다.

        ⚠⚠ **닫힐 때 탭들이 차례로 파괴되면서 선택이 남은 탭으로 밀리고**
          `<<NotebookTabChanged>>` 가 발화해 그 값이 저장됐다 — 캔버스에서
          작업하고 닫았는데 재실행 첫 화면이 역본 비교(마지막 탭 7)였던
          정체다(실측: `last_p4_tab=7 · p4_link_view=CANVAS` 모순 상태).
        ⇒ 파괴가 시작되면 `_closing` 을 세우고 `_save_state` 가 전부 무시한다 —
          열쇠마다 빗장을 달면 하나는 반드시 빠진다."""
        self._closing = True
        # 실행 표식을 걷는다 — 트레이가 곧바로 일할 수 있게(나이 판정 대기 없이)
        try:
            import tray_agent as _tray
            _tray.clear_running()
        except Exception:
            pass
        try:
            super().destroy()
        except Exception:
            pass

    def _save_state(self, key, val):
        """[수리] UI 상태를 JSON에 즉시 기록하며, 에러 시 파일을 초기화하여 안전성을 확보합니다.

        ⚠ 종료 중(`_closing`)에는 **아무것도 저장하지 않는다** — 파괴 연쇄가
          만드는 이벤트 값은 사용자의 마지막 선택이 아니다(0.txt 1번)."""
        if getattr(self, '_closing', False):
            return
        state_file = appdb.app_path("app_state.json")   # CWD 아닌 앱 폴더 기준
        state = {}
        if os.path.exists(state_file):
            with open(state_file, "r", encoding="utf-8") as f:
                try: state = json.load(f)
                except: state = {}
        
        state[key] = val
        with open(state_file, "w", encoding="utf-8") as f:
            json.dump(state, f, indent=4, ensure_ascii=False)

    def _attach_tooltip(self, widget, text_getter):
        """간단 호버 툴팁 — text_getter()는 호출 시점 평가라 i18n/언어 전환 반영. 아이콘 버튼 접근성용."""
        tip = {'win': None}

        def _enter(_e=None):
            try:
                txt = text_getter() if callable(text_getter) else str(text_getter)
            except Exception:
                txt = ''
            if not txt:
                return
            tip['win'] = tk.Toplevel(widget)
            tip['win'].wm_overrideredirect(True)
            tip['win'].wm_geometry(f"+{widget.winfo_rootx() + 10}+{widget.winfo_rooty() + 26}")
            # ★ **툴팁도 표준 서식** (2026-08-23 사용자 「M버튼에 마우스 대면
            #   팝업 라벨이 표시되는데 배경색 등이 표준서식이 아니다」).
            #   ⚠ `overrideredirect` 창이라 **`ui_theme.paint` 가 영영 못 닿는다**
            #     — 박아 둔 `#FFF8DC`(크림색)가 검정 테마에서 그대로 남았다.
            #     그릴 때마다 역할색을 읽으면 테마를 따라온다(§36-5b 동적 렌더).
            tk.Label(tip['win'], text=txt,
                     bg=ui_theme.C('panel_alt') or '#F4F6F7',
                     fg=ui_theme.C('fg') or '#2C3E50',
                     padx=8, pady=3, relief='solid', borderwidth=1,
                     highlightbackground=ui_theme.C('border') or '#BDC3C7').pack()

        def _leave(_e=None):
            if tip['win']:
                try:
                    tip['win'].destroy()
                except Exception:
                    pass
                tip['win'] = None

        widget.bind('<Enter>', _enter)
        widget.bind('<Leave>', _leave)

    def _load_state(self, key, default):
        """[수리] NameError 박멸: os와 json 모듈을 사용하여 안전하게 상태를 로드합니다."""
        state_file = appdb.app_path("app_state.json")   # CWD 아닌 앱 폴더 기준
        if not os.path.exists(state_file): 
            return default
            
        with open(state_file, "r", encoding="utf-8") as f:
            try:
                state = json.load(f)
                return state.get(key, default)
            except (json.JSONDecodeError, ValueError): 
                return default

    def _on_p4_resize(self, event):
        """[수리] 현재 모드(Normal/Focus)를 판별하여 바닥 높이를 각각 따로 기억합니다."""
        try:
            current_h = self.p4_strip_area.winfo_height()
            if current_h < 20: return # 비정상 크기 무시
            
            # 🎯 현재 '확대(Focus) 모드'인지 여부에 따라 키를 분리하여 저장
            mode_key = "p4_desc_h_focus" if not hasattr(self, 'top_pw') or not self.top_pw.winfo_ismapped() else "p4_desc_h_normal"
            self._save_state(mode_key, current_h)
        except:
            pass

    def on_scope_changed(self):
        """[신설] 연결 범위 옵션 변경 시 현재 노드 기준으로 캔버스를 재사냥합니다."""
        if hasattr(self, 'active_node_id') and self.active_node_id:
            self.p4_view.delete("all")
            # 현재 노드를 거점으로 다시 전개 (선택된 범위 필터 적용)
            self.on_verse_selected(None)

    def initiate_explorer_from_db(self):
        self._tlog('explorer: start')
        self.load_books_to_combo()
        self._tlog('explorer: books loaded')
        
        # P4 탭별 범위(Scope) 라디오 버튼 상태 복구
        # ⚠ 3(+Container)은 2026-08-19 폐기 — 저장값이 3 이던 사용자는 2 로 내린다.
        if hasattr(self, 'scope_t1_var'):
            self.scope_t1_var.set(min(int(self.last_scope_t1 or 1), 2))
        if hasattr(self, 'scope_t2_var'): self.scope_t2_var.set(self.last_scope_t2)
        
        # 안전장치: 유효한 ID가 아니면 창세기 1:1(ID 1)로 설정
        target_vid = self.active_node_id if (self.active_node_id and self.active_node_id > 0) else 1
        
        with appdb.connect(self.db_path) as conn:
            sql = "SELECT bcode, chapter FROM bible_index WHERE verse_id = ?"
            row = conn.execute(sql, (target_vid,)).fetchone()
            if not row: # ID가 DB에 없을 경우의 이중 안전장치
                target_vid = 1
                row = conn.execute(sql, (target_vid,)).fetchone()
        
        b_code, chap_num = row[0], row[1]

        # 책/장 콤보박스 시뮬레이션
        for name, code in self.book_map.items():
            if code == b_code:
                self.cb_book.set(name); self.on_book_selected(None); break
        
        self.cb_chap.set(str(chap_num)); self.on_chapter_selected(None)
        self._tlog('explorer: book+chapter rendered (on_chapter_selected done)')

        # 2. UI 렌더링 동기화 (기존 유지)
        self.update_idletasks()
        
        # 3. 🎯 [최종 수리] 리스트박스 줄 번호 사냥 및 정밀 조준 로직
        target_list_idx = None
        for list_idx, data_idx in enumerate(self.p1_idx_map):
            # 진짜 구절 데이터가 들어있는 줄인지 장부에서 확인
            if data_idx is not None:
                # 그 줄에 배정된 성경 ID가 우리가 찾는 target_vid와 일치하는지 대조
                if self.p1_data[data_idx][2] == target_vid:
                    target_list_idx = list_idx
                    break # 찾았으면 루프 탈출
        
        # 4. 🎯 [최종 수리] 루프 밖에서 찾은 인덱스로 UI 액션 실행
        if target_list_idx is not None:
            self.p1_ls.selection_set(target_list_idx) # 정확한 줄 선택
            self.p1_ls.see(target_list_idx)           # 잘못된 변수 i를 target_list_idx로 수정
            self.active_node_id = target_vid
            
            # 첫 기동 시에도 중앙 정렬을 강제하도록 플래그 주입
            self.force_refocus = True 
            # 캔버스 지도 생성 is_loading=True를 넘겨주어야 초기 로딩 시 return 되지 않고 화면을 그립니다.
            self.on_verse_selected(is_loading=True)

    def _get_verse_short_label(self, verse_id: int) -> str:
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT bn.short_name, bi.chapter, bi.verse "
                    "FROM bible_index bi "
                    "JOIN book_names bn ON bi.bcode=bn.book_code AND bn.lang_code=? "
                    "WHERE bi.verse_id=?", (_ref_lang(), verse_id)).fetchone()
            if row:
                # ★ 표기는 `verse_ref` 가 정한다 (2026-08-21 사용자 — 「룻1:16 과
                #   같이 약명 사이의 공백을 제거하자」).
                #   ⚠ 어제 `_get_bible_label_direct` 를 고쳤는데 **약명을 만드는
                #     함수가 하나가 아니었다** — 여기도 손으로 한 칸을 넣고 있었다.
                #     핀 칩·즐겨찾기·최근 목록이 이 함수를 쓴다.
                return verse_ref.label(verse_ref.SCOPE_BOOK, row[0], row[1], row[2])
        except Exception:
            pass
        return ""

    def _refresh_verse_fav_btn(self):
        """현재 P1 구절의 즐겨찾기 상태로 별표 아이콘 갱신."""
        btn = getattr(self, '_verse_fav_btn', None)
        vid = getattr(self, '_p1_verse_id', None)
        if btn is None:
            return
        fav = False
        if vid:
            try:
                with appdb.connect(self.db_path) as conn:
                    fav = conn.execute(
                        "SELECT 1 FROM user_favorite WHERE fav_type='VERSE' AND verse_id=? "
                        "AND record_status='LIVE' LIMIT 1", (vid,)).fetchone() is not None
            except Exception:
                fav = False
        btn.config(text="★" if fav else "☆", fg="#F39C12" if fav else "#BBBBBB")

    def _toggle_verse_favorite(self):
        """현재 P1 구절 즐겨찾기 토글 (user_favorite VERSE). 기존 HIDE 행 재사용."""
        vid = getattr(self, '_p1_verse_id', None)
        if not vid:
            return
        try:
            from datetime import datetime
            with appdb.connect(self.db_path) as conn:
                live = conn.execute(
                    "SELECT fav_id FROM user_favorite WHERE fav_type='VERSE' AND verse_id=? "
                    "AND record_status='LIVE' LIMIT 1", (vid,)).fetchone()
                if live:
                    conn.execute("UPDATE user_favorite SET record_status='HIDE' WHERE fav_id=?", (live[0],))
                else:
                    hid = conn.execute(
                        "SELECT fav_id FROM user_favorite WHERE fav_type='VERSE' AND verse_id=? "
                        "AND record_status='HIDE' LIMIT 1", (vid,)).fetchone()
                    if hid:
                        conn.execute("UPDATE user_favorite SET record_status='LIVE' WHERE fav_id=?", (hid[0],))
                    else:
                        label = self._get_verse_short_label(vid) or ''
                        conn.execute(
                            "INSERT INTO user_favorite(fav_type,target_id,verse_id,source_code,label,note,created_at,record_status) "
                            "VALUES('VERSE',?,?,?,?,?,?,'LIVE')",
                            (vid, vid, 'USER', label, '', datetime.now().isoformat(timespec='seconds')))
                        try:
                            import usage_stats; usage_stats.bump('favorite_add')
                        except Exception:
                            pass
                conn.commit()
        except Exception as e:
            print(f"[verse_fav] {e}")
        self._refresh_verse_fav_btn()
        # ★ 2026-10-25 P1 절 번호의 빨강을 그 자리에서 맞춘다
        try:
            on = not live
            for row, idx in enumerate(self.p1_idx_map):
                if idx is not None and self.p1_data[idx][2] == vid:
                    self.p1_ls.set_num_mark(row, 'fav', on)
                    break
        except Exception:
            pass

    def _add_recent_verse(self, verse_id: int):
        label = self._get_verse_short_label(verse_id)
        if not label:
            return
        self._recent_verse_ids = [(v, l) for v, l in self._recent_verse_ids if v != verse_id]
        self._recent_verse_ids.insert(0, (verse_id, label))
        self._recent_verse_ids = self._recent_verse_ids[:RECENT_VERSE_MAX]
        # 영속화 — 앱 재시작 후에도 최근 본 구절 유지
        self._save_state('recent_verses', [[v, l] for v, l in self._recent_verse_ids])

    def open_font_settings(self, scope='bible'):
        """폰트 컨트롤 타워를 연다. **화면의 「가」 버튼은 전부 이것 하나를 부른다.**

        (2026-08-13 · `font.md` 3단계) 예전에는 P1 전용 읽기 팝업(`reading_setup`)이
        따로 있었는데 지원/설정 폰트 탭과 **기능이 겹쳤다**(사용자 지적).
        ⇒ 설정 위젯을 **한 벌만** 두고 어디서 열든 같은 창을 띄운다. `scope` 를 주면
          그 구역을 펼쳐 강조하므로 「어디를 고치는 것인가」가 사라진다.
        """
        try:
            import font_settings
            font_settings.open_font_settings(
                self, self.db_path, scope=scope,
                on_change=self._apply_reading_font)
        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), str(e))

    # 옛 이름으로 부르는 자리가 남아 있어도 같은 창이 열리게 둔다
    _open_reading_setup = open_font_settings

    # ── 최근 구절 팝업 ──────────────────────────────────────────────────────
    def _open_recent_popup(self):
        """버튼 바로 아래에 목록을 펼친다. 구절을 누르면 이동하고 팝업은 닫힌다."""
        if getattr(self, '_recent_pop', None) is not None:
            self._close_recent_popup()
            return
        if not self._recent_verse_ids:
            return

        btn = self.btn_recent_verse
        pop = tk.Toplevel(self)
        pop.overrideredirect(True)          # 테두리 없는 드롭다운
        pop.attributes('-topmost', True)
        # ★ 색은 전부 역할 (2026-08-19 사용자 신고 — 「클릭하려고 하면 위에 있는
        #   목록까지 밝은 색으로 반전」: 다크 테마에서 팝업은 테마색으로 칠해지는데
        #   hover 의 <Leave> 복원색이 하드코딩 'white' 라, 마우스가 지나간 행이
        #   전부 흰색으로 남았다).
        import ui_theme as _uth
        _bg = _uth.C('panel') or 'white'
        _hov = _uth.C('accent_bg') or '#EAF2F8'
        pop.configure(bg=_uth.C('border') or '#7F8C8D')
        self._recent_pop = pop

        inner = tk.Frame(pop, bg=_bg); inner.pack(padx=1, pady=1, fill='both', expand=True)

        # 머리 줄 = 기준점 체크 (2026-08-19 확정 — 「체크하는 즉시 칩 표시」.
        #  옛 「다른 화면에서 보기」 자리를 ⚑ 이 이어받았다)
        head = tk.Frame(inner, bg=_uth.C('panel_alt') or '#F4F6F7')
        head.pack(fill='x')
        # ★ **닫기 단추** (2026-08-23 사용자 「Recent 버튼 클릭하면 나타나는
        #   화면의 상단 오른쪽에 닫기 버튼을 추가하자」).
        #   ⚠ 이 창은 `overrideredirect` 라 **OS 제목줄이 없다** — 매뉴얼 팝업
        #     (Toplevel + 제목줄)과 반대로, 여기는 우리가 그려야 한다
        #     (`journey_story` 겹침 카드와 같은 경우).
        #   ⚠ 글자는 `✕`(U+2715)가 아니라 **`×`(U+00D7)** — `✕` 는 맑은 고딕·
        #     굴림·바탕 **어디에도 없다**(cmap 실측). `×` 는 셋 다 있다.
        tk.Button(head, text='×', bd=0, padx=6, pady=0, cursor='hand2',
                  bg=_uth.C('panel_alt') or '#F4F6F7', fg=_uth.C('fg_dim') or '#7F8C8D',
                  activebackground=_uth.C('accent_bg') or '#EAF2F8',
                  command=self._close_recent_popup).pack(side='right', padx=(0, 4))
        _cur_vid = getattr(self, '_p1_verse_id', None)
        if _cur_vid:
            _cur_lbl = self._get_verse_short_label(_cur_vid) or str(_cur_vid)
            _pin_var = tk.IntVar(value=1 if self._is_pinned(_cur_vid) else 0)

            def _pin_toggle():
                if _pin_var.get():
                    self._pin_current()
                    _pin_var.set(1 if self._is_pinned(_cur_vid) else 0)
                else:
                    self._unpin(_cur_vid)
            tk.Checkbutton(
                head, variable=_pin_var,
                bg=_uth.C('panel_alt') or '#F4F6F7', fg=_uth.C('fg') or '#333',
                selectcolor=_uth.C('panel') or 'white',
                text=i18n.t('UM_PIN_SET', '⚑ {ref} 을(를) 복귀 기준점으로'
                            ).format(ref=_cur_lbl),
                command=_pin_toggle).pack(side='left', padx=4, pady=2)

        ver = getattr(self, 'ver', 'KRV') or 'KRV'
        vids = [v for v, _ in self._recent_verse_ids]
        body = {}
        try:
            with appdb.connect(self.db_path) as conn:
                # ★ 합쳐진 절·없는 절도 **읽을 수 있는 글**로 온다
                for vid, d in _vt.texts(conn, vids, ver, self.lang).items():
                    body[vid] = d['text']
        except Exception:
            pass

        # 스크롤 되는 목록 — tk.Frame 은 스스로 스크롤하지 못하므로 Canvas 안에 넣는다.
        # (P1 엔티티 티커 `_ticker_cvs` 와 같은 방식. 그쪽은 가로, 이쪽은 세로다.)
        body_f = tk.Frame(inner, bg=_bg); body_f.pack(fill='both', expand=True)
        cvs = tk.Canvas(body_f, bg=_bg, highlightthickness=0, bd=0)
        vsb = ttk.Scrollbar(body_f, orient='vertical', command=cvs.yview)
        cvs.configure(yscrollcommand=vsb.set)
        # ⚠ **스크롤바를 캔버스보다 먼저 pack 한다.** `expand=True` 인 캔버스를 먼저 놓으면
        #   남은 공간을 전부 가져가 버려서 뒤에 pack 한 스크롤바가 자리를 못 얻는다 —
        #   설정값은 멀쩡한데 화면에만 안 나온다(2026-08-12 픽셀 확인으로 잡았다).
        #   필요 없을 때는 아래에서 pack_forget 한다.
        vsb.pack(side='right', fill='y')
        cvs.pack(side='left', fill='both', expand=True)
        rows = tk.Frame(cvs, bg=_bg)
        _win = cvs.create_window((0, 0), window=rows, anchor='nw')
        # 안쪽 프레임이 캔버스 폭을 따라가게 한다 — 없으면 본문이 제 폭만큼만 그려져
        # 오른쪽이 허옇게 남고 클릭 영역도 좁아진다.
        cvs.bind('<Configure>', lambda e: cvs.itemconfigure(_win, width=e.width))

        def _wheel(e):
            cvs.yview_scroll(-1 if e.delta > 0 else 1, 'units')
        for w in (pop, inner, cvs, rows):
            w.bind('<MouseWheel>', _wheel)
        self._recent_wheel = _wheel      # 행 위젯에도 같은 핸들러를 건다

        for vid, label in self._recent_verse_ids:
            txt = (body.get(vid) or '').strip()
            if len(txt) > POPUP_TEXT_CHARS:
                txt = txt[:POPUP_TEXT_CHARS] + '…'
            row = tk.Frame(rows, bg=_bg, cursor='hand2')
            row.pack(fill='x')
            l1 = tk.Label(row, text=label, bg=_bg,
                          fg=_uth.C('accent') or '#1A5276', width=12, anchor='w',
                          font=('', 9, 'bold'))
            l1.pack(side='left', padx=(6, 4), pady=1)
            l2 = tk.Label(row, text=txt, bg=_bg,
                          fg=_uth.C('fg_dim') or '#566573', anchor='w')
            l2.pack(side='left', fill='x', expand=True, padx=(0, 8))
            for w in (row, l1, l2):
                w.bind('<Button-1>', lambda e, v=vid: self._pick_recent_verse(v))
                # hover 복원색도 같은 역할값 — 하드코딩 'white' 가 반전 버그의 뿌리였다
                w.bind('<Enter>', lambda e, r=row, a=l1, b=l2: [x.config(bg=_hov) for x in (r, a, b)])
                w.bind('<Leave>', lambda e, r=row, a=l1, b=l2: [x.config(bg=_bg) for x in (r, a, b)])
                # 행 위에서도 휠이 먹어야 한다 — 자식 위젯은 부모 바인딩을 물려받지 않는다
                w.bind('<MouseWheel>', _wheel)

        pop.update_idletasks()
        cvs.configure(scrollregion=cvs.bbox('all'))
        x = btn.winfo_rootx()
        y = btn.winfo_rooty() + btn.winfo_height() + 2
        w = max(rows.winfo_reqwidth(), POPUP_MIN_W)

        # 높이 — 목록이 길면 잘라서 스크롤한다. 화면 아래로 넘치지 않게 남은 공간도 본다.
        head_h = head.winfo_reqheight()
        want = rows.winfo_reqheight()
        room = self.winfo_screenheight() - y - 40
        view_h = max(120, min(want, POPUP_MAX_H, room))
        cvs.configure(height=view_h)
        if want > view_h:                      # 넘칠 때만 스크롤바를 남긴다
            w += 16
        else:
            vsb.pack_forget()
        # 화면 밖으로 나가면 왼쪽으로 당긴다
        x = min(x, self.winfo_screenwidth() - w - 10)
        pop.geometry(f'{w}x{head_h + view_h + 2}+{x}+{y}')
        # ⚠ 포커스를 잃으면 닫는다. 없으면 팝업이 뜬 채 남는다.
        pop.bind('<FocusOut>', lambda e: self._close_recent_popup())
        pop.bind('<Escape>', lambda e: self._close_recent_popup())
        pop.focus_force()

    def _close_recent_popup(self):
        pop = getattr(self, '_recent_pop', None)
        self._recent_pop = None
        if pop is not None:
            try:
                pop.destroy()
            except Exception:
                pass

    def _pick_recent_verse(self, vid: int):
        """구절을 선택하면 **먼저 팝업을 닫고** 이동한다(사용자 지시).
        (「다른 화면에서 보기」 갈래는 2026-08-19 폐지 — 기준점(⚑ 핀)이
        그 의도의 답이다.)"""
        self._close_recent_popup()
        self._goto_recent_verse(vid)

    # ── 기준점(⚑ 핀) — 2026-08-19 확정 설계 구현 ─────────────────────────
    #   복귀 = 기준점 구절 **재방송**(_plan_verse_navigate — 구절 클릭 1회와
    #   동일 디스패치. 구절 복종 화면은 이것이 자동 복원) + 스냅샷 복원
    #   (재방송으로 안 돌아오는 것만: 캔버스 맵 PIN 슬롯 · P4/P2 탭 위치).

    PIN_MAX = 3

    def _load_pins(self):
        out = []
        for it in (self._load_state('pin_points', []) or []):
            try:
                out.append({'vid': int(it[0]), 'label': str(it[1]),
                            'map_root': (int(it[2]) if it[2] else None),
                            'p4': (int(it[3]) if it[3] is not None else None),
                            # ★ 2026-10-13 (docs/1.txt 74-4) — P2 탭은 이제 이름('DESC'·'NOTE')이다.
                            #   int() 로 읽다 터져 **꽂은 핀이 읽을 때마다 버려졌다**(깃발이 「반응 없음」의 정체).
                            #   옛 핀(번호)은 그대로 읽는다 — `_pin_return` 이 번호를 이름으로 옮긴다.
                            'p2': it[4] if (it[4] is None or isinstance(it[4], (int, str))) else None})
            except Exception:
                continue
        return out[:self.PIN_MAX]

    def _save_pins(self, pins):
        self._save_state('pin_points',
                         [[p['vid'], p['label'], p['map_root'],
                           p['p4'], p['p2']] for p in pins[:self.PIN_MAX]])

    def _pin_current(self):
        """지금 구절을 기준점으로 — 스냅샷(캔버스 맵·탭 위치) 저장 + 칩 표시."""
        vid = getattr(self, '_p1_verse_id', None)
        if not vid:
            return
        label = self._get_verse_short_label(vid) or str(vid)
        pins = self._load_pins()
        pins = [p for p in pins if p['vid'] != vid]     # 재핀 = 덮어쓰기
        if len(pins) >= self.PIN_MAX:
            old = pins[-1]
            if not messagebox.askyesno(
                    i18n.t('UM_PIN_TIP', '기준점'),
                    i18n.t('UM_PIN_FULL',
                           '기준점은 {n}개까지입니다.\n가장 오래된 {old} 을(를) 교체할까요?'
                           ).format(n=self.PIN_MAX, old=old['label'])):
                return
            self._unpin(old['vid'], _render=False)
            pins = [p for p in self._load_pins() if p['vid'] != vid]

        # 스냅샷 ① 캔버스 맵 — 지금 펼쳐진 그대로 PIN 슬롯에 (비었으면 생략)
        map_root = None
        try:
            nodes = getattr(getattr(self, 'p4_view', None), 'nodes', None) or {}
            if nodes:
                v_id = getattr(self, 'active_node_id', None)
                if v_id is not None:
                    map_root = int(str(v_id).split('@')[0].split(':')[-1])
                    snap = {nid: {'node_id': info.get('node_id'),
                                  'p_id': info.get('p_id'),
                                  'x': info.get('x'), 'y': info.get('y'),
                                  'rel_label': info.get('rel_label', '')}
                            for nid, info in nodes.items()}
                    # ⚠ 표의 CHECK 가 save_type 을 AUTO/MANUAL 로 못 박아 두었다
                    #   (실측) — PIN 은 **이름 접두 `PIN_`** 로 가른다. 목록
                    #   쿼리들이 이 접두를 제외한다.
                    with appdb.connect(self.db_path) as conn:
                        conn.execute(
                            "INSERT OR REPLACE INTO user_saved_maps "
                            "(root_id, save_type, map_name, path_string,"
                            " full_structure, updated_at) "
                            "VALUES (?, 'MANUAL', ?, ?, ?, datetime('now'))",
                            (map_root, f'PIN_{vid}',
                             '|'.join(getattr(self, 'current_journey_list', [])),
                             json.dumps(snap, ensure_ascii=False)))
                        conn.commit()
        except Exception as e:
            print(f'[pin] map snapshot: {e}')
            map_root = None
        # 스냅샷 ② 탭 위치
        try:
            p4 = self.p4_nb.index('current') if hasattr(self, 'p4_nb') else None
        except Exception:
            p4 = None
        try:
            p2 = self._p2_tabs.current() if hasattr(self, '_p2_tabs') else None
        except Exception:
            p2 = None

        pins.insert(0, {'vid': vid, 'label': label, 'map_root': map_root,
                        'p4': p4, 'p2': p2})
        self._save_pins(pins)
        self._render_pin_chips()

    def _unpin(self, vid, _render=True):
        pins = [p for p in self._load_pins() if p['vid'] != vid]
        self._save_pins(pins)
        try:                       # PIN 맵 슬롯도 함께 정리 (이름 접두로 가른다)
            with appdb.connect(self.db_path) as conn:
                conn.execute("DELETE FROM user_saved_maps WHERE map_name=?",
                             (f'PIN_{vid}',))
                conn.commit()
        except Exception:
            pass
        if _render:
            self._render_pin_chips()

    def _is_pinned(self, vid):
        return any(p['vid'] == vid for p in self._load_pins())

    def _pin_return(self, vid):
        """칩 클릭 = 복귀. 재방송 후 스냅샷(탭·캔버스 맵)을 되살린다.
        ⚠ 자동 해제하지 않는다 — 같은 기준점으로 여러 번 돌아오는 것이 정상."""
        pin = next((p for p in self._load_pins() if p['vid'] == vid), None)
        if pin is None:
            return
        self._plan_verse_navigate(vid)          # 재방송 — 구절 복종 화면 복원

        def _restore():
            try:
                if pin['p4'] is not None and hasattr(self, 'p4_nb'):
                    self.p4_nb.select(pin['p4'])
                if pin['p2'] is not None and hasattr(self, '_p2_tabs'):
                    _v = pin['p2']
                    if isinstance(_v, int):     # 옛 핀 — 그룹 번호(4탭 시절)
                        _v = (('DESC', 'NOTE', 'VIDEO', 'FLOW')[_v]
                              if 0 <= _v < 4 else None)
                    if _v:
                        # ★ 51-4 — 잠긴 갈래(주석·영상…)를 담은 옛 핀은 P4 탭으로 간다
                        self._select_p2(_v)
            except Exception:
                pass
            if pin['map_root']:
                try:                            # 캔버스를 꽂던 순간의 모양으로
                    self._apply_saved_research_data(pin['map_root'],
                                                    f'PIN_{vid}')
                except Exception as e:
                    print(f'[pin] map restore: {e}')
        # 재방송의 캔버스 초기화가 끝난 뒤에 덮는다
        self.after(450, _restore)

    def _ticker_pick_tags(self):
        """P1 하단 [My Edit] — 지금 구절에 **용어를 새로 만들어 잇는다**.

        ★★★ 2026-08-31 `0.txt` 3번 4) — 「엔티티를 클릭하지 않은 상태이므로
          수정할 대상이 없고 **새롭게 추가할 의사가 있다고 추정됨** : 연결팝업
          화면 가운데에 **신규입력 화면** 표시」. 그전에는 옛 [태그 고르기…]
          팝업을 열었다 — §106차에 **My Edit 으로 흡수한 창**이라 같은 일에
          입구가 둘이었다.
        ⇒ `INTENT_NEW` 로 My Edit — 구절이 출발지, 재고는 **용어 갈래**,
          가운데는 **만들기 폼**.
        ⚠ 구절이 없으면 **왜 안 되는지 말한다** — 조용히 아무 일도 안 하면
          고장으로 읽힌다(§0-1).
        ⚠ 옛 팝업 경로는 **폴백으로 남긴다** — My Edit 이 못 뜨는 자리에서
          조용히 아무 일도 안 하면 그것이 더 나쁘다.
        """
        vid = getattr(self, '_p1_verse_id', None)
        import tag_picker
        if not vid:
            tag_picker.need_target(self, i18n.t('OC_K_VERSE', '구절'))
            return
        try:
            import my_edit
            my_edit.open(self, kind='VERSE', asset_id=int(vid),
                         intent=my_edit.INTENT_NEW, pick_kind='ENTITY',
                         pick_label=i18n.t('LP_B_ENTITY', '용어'),
                         on_changed=lambda *_a: self._refresh_entity_ticker(vid))
            return
        except Exception as e:
            print('[ticker my edit] %s' % e)
        try:
            lang = getattr(self, 'lang', 'KO') or 'KO'
            cur = {(s2, t) for s2, t, _n, _c
                   in tag_picker.tags_of(self.db_path, 'VERSE', vid, lang,
                                         scope='USER')}
            got = tag_picker.pick(self, self.db_path, cur, lang,
                                  mode='EDIT', scope='USER')
            if got is None:
                return
            tag_picker.save_links(self.db_path, 'VERSE', vid, got, scope='USER')
            self._refresh_entity_ticker(vid)
        except Exception as e:
            print('[ticker tags] %s' % e)

    def _render_pin_chips(self):
        """P1 상단 칩 — `약명 ✕` 나란히(약명만 — 공간이 좁다, 사용자 지시).

        ⚠ **칩에는 깃발을 안 붙인다** (2026-08-21 사용자 — 「고정핀 자체는
          깃발 모양 좋다. 그런데 등록된 구절을 표시할 때 매번 깃발 표시는
          제거하자」). 깃발은 **꽂는 단추**의 것이고, 칩은 이미 그 줄에 모여
          있어 무엇인지 알 수 있다."""
        f = getattr(self, '_pin_chips_f', None)
        if f is None or not f.winfo_exists():
            return
        for w in f.winfo_children():
            w.destroy()
        import ui_theme as _uth
        bg = _uth.C('accent_bg') or '#EAF2F8'
        fg = _uth.C('accent') or '#1A5276'
        dim = _uth.C('fg_dim') or '#888'
        base = _uth.C('bg') or '#FFFFFF'
        f.configure(bg=base)
        for p in self._load_pins():
            # ⚠ **저장된 이름을 그대로 믿지 않는다** — 꽂을 때의 글자라
            #   ① 표기 규칙을 고쳐도 옛 핀은 옛 모양(`룻 1:16`)으로 남고
            #   ② 화면 언어를 바꿔도 따라오지 않는다. 지금 규칙으로 다시
            #   짓고, 못 지으면 그때만 저장값으로 (묵상후보 목록과 같은 원칙).
            label = self._get_verse_short_label(p['vid']) or p['label']
            # ⚠ **공백을 완전히 없앤다** (2026-08-30 사용자 「Gen 1:1 x 라고
            #   표시하고 있다. Gen1:1x 라고 수정하라 (space 완전 제거)」).
            #   라틴 약명은 규칙상 한 칸 띄운다(`Mark 6:30`, §3-1) — 그 규칙은
            #   본문 자리의 것이고, **좁은 칩에서는 한 덩이로 읽혀야** 한다.
            label = ''.join(str(label).split())
            chip = tk.Frame(f, bg=bg)
            chip.pack(side='left', padx=(0, 3))
            # ⚠ **약명과 ✕ 사이에 틈을 두지 않는다** (2026-08-21 사용자 —
            #   「룻3:12 ✕ 로 보인다. 공백을 완전히 없애라」). 안쪽 padx 를
            #   0 으로 두고 **칩 바깥쪽에만** 여백을 남긴다 — 안 그러면 두
            #   낱말처럼 읽힌다.
            # ⚠ **글꼴을 정한다** (2026-08-30 사용자 「Recent, Font 와 같은
            #   버튼보다 글자/버튼이 크다. 동일한 크기로」). 그전에는 글꼴을
            #   안 적어 `TkDefaultFont` 로 그려졌고, 그 줄의 다른 도구는 전부
            #   `Malgun Gothic 9` 라 이 칩만 솟았다.
            _cf = ("Malgun Gothic", 9)
            lb = tk.Label(chip, text=label, bg=bg, fg=fg, font=_cf,
                          padx=0, pady=2, cursor='hand2')
            lb.pack(side='left', padx=(4, 0))
            lb.bind('<Button-1>', lambda _e, v=p['vid']: self._pin_return(v))
            x = tk.Label(chip, text='✕', bg=bg, fg=dim, font=_cf,
                         padx=0, pady=2, cursor='hand2')
            x.pack(side='left', padx=(0, 4))
            x.bind('<Button-1>', lambda _e, v=p['vid']: self._unpin(v))

    def _focus_verse_note(self):
        """P2 를 묵상노트로. 통합 화면에서 메모를 누르면 그것부터 보여야 한다.

        4탭 체제(2026-08-19) — 「자료·노트」 그룹 탭 + 묵상노트 갈래."""
        try:
            self._p2_tabs.select('NOTE')
        except Exception as e:
            print('_focus_verse_note: %s' % e)

    def _adopt_popup(self, event=None):
        """새로 뜬 팝업에 테마·글꼴을 입힌다.

        ⚠ **`<Map>` 은 자식 위젯에서도 올라온다.** 그 창 자신일 때만 한다 —
          아니면 위젯 하나가 보일 때마다 창 전체를 훑는다.
        ⚠ 멱등은 `ui_theme.adopt` 가 맡는다(테마 이름을 창에 적어 둔다).
        """
        w = getattr(event, 'widget', None)
        if not isinstance(w, tk.Toplevel) or w is self:
            return
        try:
            import ui_theme
            ui_theme.adopt(w)
            # ⚠⚠ **한 번으로는 모자란다** (2026-08-30 실측). `<Map>` 때 칠하고
            #   `adopt` 가 창에 테마 이름을 적어 두는데, **그 뒤에 내용을 더
            #   짓는 창**이 있다(폰트 설정의 `_on_mode`·`_load`). 그 위젯들은
            #   영영 안 칠해진다 — `adopt` 가 두 번째 호출을 건너뛰기 때문이다.
            #   ⇒ 잠시 뒤 `paint` 를 한 번 더 부른다(`paint` 는 표식을 안 본다).
            w.after(250, lambda: ui_theme.paint(w) if w.winfo_exists() else 0)
        except Exception as e:
            print('[adopt popup] %s' % e)

    def _goto_recent_verse(self, vid: int):
        """P1 본문을 그 구절로 옮긴다(예전 콤보가 하던 일)."""
        with appdb.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT bcode, chapter FROM bible_index WHERE verse_id=?", (vid,)).fetchone()
        if not row:
            return
        b_code, chap_num = row
        for name, code in self.book_map.items():
            if code == b_code:
                self.cb_book.set(name)
                self.on_book_selected(None)
                break
        self.cb_chap.set(str(chap_num))
        self.on_chapter_selected(None)
        self.update_idletasks()
        for list_idx, data_idx in enumerate(self.p1_idx_map):
            if data_idx is not None and self.p1_data[data_idx][2] == vid:
                self.p1_ls.selection_clear(0, tk.END)
                self.p1_ls.selection_set(list_idx)
                self.p1_ls.see(list_idx)
                self.on_verse_selected(is_loading=True)
                break

    def _get_preferred_versions(self):
        """**P1 에서 읽을 역본 목록.** `user_config['READING_VERSIONS']` 를 쓰고,
        없으면 옛 `PREFERRED_VERSIONS`, 그것도 없으면
        현재버전 + UI언어 역본 전부 + BSB + KJV (중복 제거, 실존 코드만).

        ★★ **읽기 목록과 비교 목록은 다른 것이다** (2026-08-23 사용자 지적 —
          「P1 성경읽기 상단 bar 에서 … **모든 성경이 표시됨**」).
          예전에 두 목록을 `PREFERRED_VERSIONS` 하나로 합쳐 두어서 **콥틱 신약
          3종과 히브리 원문(WLC)이 P1 읽기 목록에** 들어 있었다(실측 13개 중 4개).
          비교용으로는 옳고 읽기용으로는 말이 안 된다 — **고르는 기준이 다르다.**
        ⚠ **옛 키를 재해석하지 않았다** — `PREFERRED_VERSIONS` 는 비교 목록으로
          그대로 살려 두고(`version_compare_view` 가 읽는다) 읽기용 키를 새로
          만들었다. 재해석했으면 지금 사용자 설정이 조용히 뜻을 바꿨을 것이다.
        ⚠ 이름은 안 바꿨다 — 부르는 곳이 여럿이라 뜻만 좁혔다.
        """
        import json
        with appdb.connect(self.db_path) as conn:
            allcodes = {r[0] for r in conn.execute("SELECT version_code FROM bible_version")}
            row = conn.execute(
                "SELECT config_val FROM user_config WHERE config_key='READING_VERSIONS'").fetchone()
            if row and row[0]:
                try:
                    valid = [c for c in json.loads(row[0]) if c in allcodes]
                    if valid:
                        return valid
                except Exception:
                    pass
            # ── 읽기 목록을 아직 안 고른 사용자 ─────────────────────────────
            # ★ 비교 목록을 물려받되 **성경 전체를 담은 역본만**(`coverage_scope
            #   ='FULL'`). 콥틱 신약 3종(NT_ONLY)·헬라어 신약(NT_ONLY)·히브리
            #   원문 WLC(OT_ONLY)가 그렇게 빠진다 — 실측으로 딱 그 넷이다.
            #   ⚠ **막는 것이 아니라 기본값일 뿐**이다. 부분 역본을 읽고 싶으면
            #     설정에서 체크하면 그대로 목록에 들어간다.
            full = {r[0] for r in conn.execute(
                "SELECT version_code FROM bible_version "
                "WHERE COALESCE(coverage_scope,'FULL')='FULL'")}
            row = conn.execute(
                "SELECT config_val FROM user_config "
                "WHERE config_key='PREFERRED_VERSIONS'").fetchone()
            if row and row[0]:
                try:
                    valid = [c for c in json.loads(row[0])
                             if c in allcodes and c in full]
                    if valid:
                        return valid
                except Exception:
                    pass
            langvers = [r[0] for r in conn.execute(
                "SELECT version_code FROM bible_version WHERE lang_code=? ORDER BY version_code",
                (self.lang,))]
        out = []
        for c in [self.ver] + langvers + ['BSB', 'KJV']:
            if c and c in allcodes and c not in out:
                out.append(c)
        return out or [self.ver]

    def _refresh_ver_coverage(self, code):
        with appdb.connect(self.db_path) as conn:
            r = conn.execute(
                "SELECT coverage_scope, versification_system FROM bible_version WHERE version_code=?",
                (code,)).fetchone()
        self._ver_coverage      = r[0] if r else 'FULL'
        self._ver_versification = r[1] if r else 'MT'

    def _build_p1_version_combo(self, parent):
        pref = self._get_preferred_versions()
        with appdb.connect(self.db_path) as conn:
            dn = {r[0]: (r[1] or r[2] or r[0]) for r in conn.execute(
                "SELECT version_code, display_name, version_name FROM bible_version")}
        # ── 현재 버전 확정 — 단일 소스 = user_config['v1_code'] ──────────────
        # (2026-07-30) 이전에는 app_state.json['last_p1_version'] 이 여기서 self.ver 를
        # 덮어써서, '지원/설정 ▸ 성경버전'에서 고른 기본 버전이 무시됐다. 저장이 안 된 게
        # 아니라 두 소스가 경쟁해 P1 콤보 직전값이 이긴 것. 이제 v1_code 하나만 본다.
        if self.ver not in pref and pref:
            # 선호 목록에서 빠진 버전이 저장돼 있으면 첫 항목으로 교정(빈 콤보 방지)
            self.ver = pref[0]
            self._save_current_version(self.ver)
        self._refresh_ver_coverage(self.ver)
        # ── 버튼 + 팝업 (2026-08-19 사용자 지시 — 「어차피 콤보로는 이름이
        #    제대로 표시되지 못한다」). 콤보 접힌 칸은 폭 15 로도 긴 이름이
        #    잘렸고, 드롭다운은 폭이 콤보에 묶여 정식이름·언어를 나란히 못
        #    보였다(Recent verses 가 콤보→버튼이 된 것과 같은 이유).
        #    버튼 표시 = 버전 코드, 팝업 행 = 약명 | 정식이름 | 언어.
        self._ver_pref = pref                 # 팝업 목록 (선호버전 순서)
        self._ver_names = dn                  # code → 정식이름 (툴팁·팝업)
        import ui_theme as _uthv
        self._ver_btn = tk.Button(
            parent, text=self.ver, font=("Malgun Gothic", 9),
            bg=_uthv.C('panel') or '#EFF3F6', fg=_uthv.C('accent') or '#2C3E50',
            bd=1, relief='groove', cursor='hand2', padx=6,
            command=self._open_version_popup)
        self._ver_btn.pack(side='left', padx=(2, 6))
        self._ver_pop = None
        # 풀네임 툴팁(코드만으로 모를 때)
        self._attach_tooltip(self._ver_btn, self._ver_btn_tip)

    # ── 성경버전 버튼 글자 ────────────────────────────────────────
    #  ★★★ **고른 역본과 지금 읽히는 역본이 다를 수 있다** — 반쪽 역본으로
    #    반대쪽에 오면 짝이 본문을 채운다. 그때 버튼이 고른 코드만 보이면
    #    **사용자는 그 역본을 읽고 있다고 믿는다**(2026-09-24 사용자 지적
    #    「안그러면 오해 소지가 있다」).
    #  ⚠ **글자를 정하는 자리는 여기 하나뿐이다** — 버튼을 만들 때·버전을
    #    바꿀 때·장을 읽을 때 셋이 각자 적으면 갈린다.
    VER_ARROW = '\u203a'          # ›  선택한 것 › 지금 읽히는 것

    def _ver_btn_label(self):
        """버튼에 적을 글자 — 짝으로 읽는 중이면 `WLC › DHNT`."""
        src = getattr(self, '_p1_src_ver', None)
        if src and src != self.ver:
            return '%s %s %s' % (self.ver, self.VER_ARROW, src)
        return self.ver

    def _ver_btn_tip(self):
        """툴팁 — 선택한 역본의 정식 이름 + 지금 이 장을 누가 채웠는지."""
        names = getattr(self, '_ver_names', {}) or {}
        t = names.get(self.ver, self.ver)
        src = getattr(self, '_p1_src_ver', None)
        if src and src != self.ver:
            t += '\n' + i18n.t(
                'UM_VER_FROM', '이 장은 {v} 본문입니다 (선택한 역본에 없습니다)'
            ).format(v='%s · %s' % (src, names.get(src, src)))
        return t

    def _sync_ver_btn(self):
        """버튼 글자를 지금 상태에 맞춘다 — **바뀔 때만** 손댄다."""
        b = getattr(self, '_ver_btn', None)
        if b is None:
            return
        try:
            want = self._ver_btn_label()
            if b.cget('text') != want:
                b.config(text=want)
        except Exception:                                     # noqa: BLE001
            pass

    def _save_current_version(self, code):
        """현재 성경버전을 단일 소스(user_config['v1_code'])에 저장.

        P1 버전 콤보와 '지원/설정 ▸ 성경버전'의 기본 버전이 같은 값을 쓰도록 일원화한다
        (2026-07-30). 어느 쪽에서 바꾸든 같은 키에 쓰이므로 다음 실행에서도 유지된다.
        """
        try:
            with appdb.connect(self.db_path) as c:
                cur = c.execute(
                    "UPDATE user_config SET config_val=? WHERE config_key='v1_code'", (code,))
                if cur.rowcount == 0:
                    c.execute(
                        "INSERT INTO user_config(config_key, config_val) VALUES('v1_code', ?)",
                        (code,))
                c.commit()
        except Exception as e:
            print(f'[version save] {e}')

    def _open_version_popup(self):
        """버전 버튼 아래에 목록을 펼친다 — Recent verses 팝업과 같은 문법.

        행 = `약명 | 정식이름 | 언어`. 콤보 드롭다운은 폭이 콤보에 묶여 이
        세 칸을 나란히 못 보였다. 현재 버전 행은 accent_bg 로 표시.
        """
        if getattr(self, '_ver_pop', None) is not None:
            self._close_version_popup()
            return
        pref = getattr(self, '_ver_pref', None) or []
        if not pref:
            return
        # 언어 칸 — bible_version.lang_code → 현지어명(lang_config)
        vlang = {}
        try:
            with appdb.connect(self.db_path) as conn:
                for code, lc in conn.execute(
                        "SELECT version_code, lang_code FROM bible_version"):
                    vlang[code] = (lc or '').upper()
        except Exception:
            pass
        try:
            import lang_config as _lcfg
            def _lang_disp(lc):
                try:
                    return _lcfg.lang_name(lc) or lc
                except Exception:
                    return lc
        except Exception:
            def _lang_disp(lc):
                return lc

        btn = self._ver_btn
        pop = tk.Toplevel(self)
        pop.overrideredirect(True)
        pop.attributes('-topmost', True)
        import ui_theme as _uth
        _bg = _uth.C('panel') or 'white'
        _hov = _uth.C('accent_bg') or '#EAF2F8'
        pop.configure(bg=_uth.C('border') or '#7F8C8D')
        self._ver_pop = pop
        inner = tk.Frame(pop, bg=_bg)
        inner.pack(padx=1, pady=1, fill='both', expand=True)

        # ★ 짝이 채운 장이면 **맨 위에 한 줄로 알린다** — 목록에는 고른 역본만
        #   표시되므로, 이 줄이 없으면 짝이 어디에서 왔는지 알 길이 없다.
        _src = getattr(self, '_p1_src_ver', None)
        if _src and _src != self.ver:
            tk.Label(inner, bg=_uth.C('panel_alt') or '#F4F6F7',
                     fg=_uth.C('fg_dim') or '#566573', anchor='w',
                     font=('', 8), padx=6, pady=2, justify='left',
                     text=i18n.t(
                         'UM_VER_FROM',
                         '이 장은 {v} 본문입니다 (선택한 역본에 없습니다)'
                     ).format(v='%s \u00b7 %s' % (
                         _src, self._ver_names.get(_src, _src)))
                     ).pack(fill='x')

        for code in pref:
            name = self._ver_names.get(code, code)
            try:
                name = bidi.for_display(name)   # RTL 이름은 표시 직전 되돌림
            except Exception:
                pass
            cur = (code == self.ver)
            row_bg = _hov if cur else _bg
            row = tk.Frame(inner, bg=row_bg, cursor='hand2')
            row.pack(fill='x')
            l1 = tk.Label(row, text=code, bg=row_bg,
                          fg=_uth.C('accent') or '#1A5276', width=8, anchor='w',
                          font=('', 9, 'bold'))
            l1.pack(side='left', padx=(6, 4), pady=1)
            l2 = tk.Label(row, text=name, bg=row_bg,
                          fg=_uth.C('fg') or '#2C3E50', anchor='w')
            l2.pack(side='left', fill='x', expand=True, padx=(0, 8))
            l3 = tk.Label(row, text=_lang_disp(vlang.get(code, '')), bg=row_bg,
                          fg=_uth.C('fg_dim') or '#888', anchor='e')
            l3.pack(side='right', padx=(0, 8))
            for w in (row, l1, l2, l3):
                w.bind('<Button-1>', lambda e, c=code: self._apply_version_code(c))
                # 현재 버전 행은 hover 복원색도 accent_bg — 표시가 유지돼야 한다
                w.bind('<Enter>', lambda e, r=row, a=l1, b=l2, c=l3:
                       [x.config(bg=_hov) for x in (r, a, b, c)])
                w.bind('<Leave>', lambda e, r=row, a=l1, b=l2, c=l3, v=row_bg:
                       [x.config(bg=v) for x in (r, a, b, c)])

        pop.update_idletasks()
        x = btn.winfo_rootx()
        y = btn.winfo_rooty() + btn.winfo_height() + 2
        w = max(inner.winfo_reqwidth(), 260)
        h = inner.winfo_reqheight() + 2
        x = min(x, self.winfo_screenwidth() - w - 10)
        room = self.winfo_screenheight() - y - 40
        h = min(h, max(120, room))
        pop.geometry(f'{w}x{h}+{x}+{y}')
        pop.bind('<FocusOut>', lambda e: self._close_version_popup())
        pop.bind('<Escape>', lambda e: self._close_version_popup())
        pop.focus_force()

    def _close_version_popup(self):
        pop = getattr(self, '_ver_pop', None)
        self._ver_pop = None
        if pop is not None:
            try:
                pop.destroy()
            except Exception:
                pass

    def _apply_version_code(self, code, event=None):
        """버전 전환의 본체 — 팝업 선택·선호버전 변경 반영이 함께 쓴다."""
        self._close_version_popup()
        if not code or code == self.ver:
            return
        self.ver = code
        # ⚠ 아직 새 장을 안 읽었다 — 옛 짝 표시를 걷고 고른 코드만 보인다.
        #   장을 읽고 나면 `on_chapter_selected` 가 다시 맞춘다.
        self._p1_src_ver = code
        self._sync_ver_btn()
        self._refresh_ver_coverage(code)
        self._save_current_version(code)            # 단일 소스(user_config.v1_code)에 기록
        # 구절약명은 역본을 따른다 — 역본이 바뀌었으니 캐시를 비운다(2026-08-15)
        try:
            import lang_config
            lang_config.clear_ref_cache()
        except Exception:
            pass
        try:
            self.title('::: Hagah Dabar :::')
        except Exception:
            pass
        cur_book = self.cb_book.get()
        self.load_books_to_combo()           # 책목록 + 커버리지 배지 갱신
        if cur_book in self.book_map:
            self.cb_book.set(cur_book)
            self.on_chapter_selected(None)   # 새 버전으로 본문 재렌더
        else:                                # 새 버전 커버리지에서 사라진 책
            self.cb_book.set('')
            self.cb_chap.set('')

    def _reload_p1_version_combo(self):
        """선호버전 변경 후 P1 버전 버튼·팝업 데이터 재구성(위젯 재생성 없이)."""
        if not hasattr(self, '_ver_btn'):
            return
        pref = self._get_preferred_versions()
        with appdb.connect(self.db_path) as conn:
            dn = {r[0]: (r[1] or r[2] or r[0]) for r in conn.execute(
                "SELECT version_code, display_name, version_name FROM bible_version")}
        self._ver_pref = pref
        self._ver_names = dn
        # '지원/설정 ▸ 성경버전'에서 기본 버전을 바꿨으면 재시작 없이 즉시 반영 (2026-07-30).
        # 단일 소스 user_config['v1_code'] 를 다시 읽어 현재 버전과 다르면 전환한다.
        newv = None
        try:
            with appdb.connect(self.db_path) as c:
                r = c.execute(
                    "SELECT config_val FROM user_config WHERE config_key='v1_code'").fetchone()
            newv = r[0] if r else None
        except Exception:
            newv = None
        if newv and newv != self.ver and newv in pref:
            self._apply_version_code(newv)   # 본문·책목록·커버리지 일괄 갱신
        elif self.ver not in pref and pref:  # 현재 버전이 선호목록에서 빠짐 → 첫 항목 전환
            self._apply_version_code(pref[0])
        else:
            self._sync_ver_btn()

    def _open_settings(self):
        try:
            import usage_stats
            usage_stats.screen_hit('settings')
        except Exception:
            pass
        try:
            from settings_view import SettingsDialog
            SettingsDialog(self, self.db_path, on_saved=self._on_settings_saved)
        except Exception as e:
            print(f'[settings] {e}')

    def _on_settings_saved(self):
        """환경설정 저장 후 즉시 반영 — 선호버전→P1 콤보 갱신 + 읽기 폰트 재적용.
        (언어는 재시작 후)"""
        try:
            self._reload_p1_version_combo()
        except Exception as e:
            print(f'[settings reload] {e}')
        try:
            self._apply_reading_font()
        except Exception as e:
            print(f'[font reload] {e}')

    def _apply_reading_font(self):
        """폰트 설정을 읽는 본문 위젯에 다시 입힌다.

        (2026-08-13) `reading_font` → **`theme_font` 로 갈아탔다.** 구역이 갈리므로
        성경 본문(`bible`)과 설명문(`desc`)에 서로 다른 값이 걸릴 수 있다.
        ⚠ 컨트롤 타워가 값을 만질 때마다 이 함수를 부른다 — **여기가 「즉시 확인」의 통로**다.

        ⚠ 도서/설교 본문은 `p1_reading_view` 가 자체 갱신한다(구역 `book`).
        """
        # ★ **등록된 위젯을 전부 다시 입힌다** (2026-08-13).
        # ⚠ 예전에는 여기에 위젯을 하나씩 적어 두었는데, 새로 배선한 주석·묵상노트·
        #   도서 본문이 **이 목록에 없어 설정을 바꿔도 따라오지 않았다.**
        #   화면이 `theme_font.register` 로 등록하면 여기서 저절로 따라온다.
        self._font_need = None      # ⚠ 설정이 바뀌었다 — 기억한 판단을 버린다
        theme_font.reapply_all(self.db_path, self)
        # ★ **박힌 크기를 「기본」 대비 단계로 다시 잡는다** (2026-08-13 · font.md §22).
        #   화면 코드에 `font=('Malgun Gothic', 9)` 이 537곳 박혀 있어, 이것이 없으면
        #   「기본 하나로 전체 적용」이 그 자리에서 멈춘다.
        #   ⚠ `register` 로 등록된 위젯은 건드리지 않는다 — 그쪽은 역할이 통제한다.
        try:
            theme_font.scale(self, self.db_path)
        except Exception as e:
            print(f'[font scale] {e}')

    def load_books_to_combo(self):
        """책 이름 콤보 — **화면 UI 언어**를 따른다 (2026-08-30 사용자 확정).

        ⚠⚠ **역본을 따르게 고쳤다가 되돌렸다.** 사용자 교정 — 「P1 bar 의 버전
          콤보는 **표시되는 구절을 바꾸는 것**이지 언어 또는 책이름 콤보를 바꾸는
          것은 아니다. 그러나 **설정화면에서 언어를 바꾸면** 그 언어에 따라
          책이름 콤보가 표시되어야 한다.」
        ★ **콤보는 고르는 도구(UI)이고 역본은 읽는 글이다** — 축이 다르다.
          바로 옆 **구절 약명이 역본을 따르는 것**(`_ref_lang()`, 2026-08-15)과
          규칙이 다른 것은 어긋남이 아니라 **약명은 본문에 딸린 표기**여서다.
        ⚠ 그러므로 여기서 `_ref_lang()` 을 쓰지 말 것.
        ⚠ 실측 — `book_names` 는 **UI 언어 11개 전부** 66권을 갖고 있다(폴백 불필요).
        ★★★ **역본 범위로 책을 거르지 않는다 — 언제나 66권**
          (2026-09-23 사용자 「히브리어 구약 선택하면 구약 책 이름만 표시됨.
          신약책 선택하면 구약책 이름 콤보상자가 전혀 안보인다. **이 자체만으로
          비정상이다**」).
          ⚠⚠ 그전에는 `NT_ONLY`/`OT_ONLY` 면 반쪽만 담아서 **반대쪽으로 갈 길이
            콤보에서 통째로 사라졌다.** 히브리어 구약을 읽던 사람은 신약을
            고를 수조차 없었다 — 「없는 서랍」이 아니라 **문을 잠근 것**이다.
          ★ 반대쪽 본문은 이제 짝 역본이 채우고(`verse_text.partner_of`),
            못 채우면 그 자리에서 **까닭을 적는다**(`VT_NO_NT`·`VT_NO_OT`).
            ⇒ 목록에서 빼야 할 까닭이 없어졌다.
          ⚠ 배지(`_cov_lbl` 「구약만」)는 **남긴다** — 그 역본이 반쪽인 것은
            사실이고, 그 한 줄이 짝 본문이 나오는 까닭을 미리 알린다.
          ⚠ 책 목록을 역본으로 거르는 자리는 **저장소에서 여기 하나뿐**이었다
            (전수 확인 — 다른 화면·팝업은 모두 66권을 낸다).
        """
        lang = self.lang
        conn = appdb.connect(self.db_path)
        rows = conn.execute(
            'SELECT book_code, full_name FROM book_names'
            ' WHERE lang_code=? ORDER BY book_code', (lang,)).fetchall()
        conn.close()
        coverage = getattr(self, '_ver_coverage', 'FULL')

        self.book_map = {name: code for code, name in rows}
        self.cb_book['values'] = list(self.book_map.keys())

        if hasattr(self, '_cov_lbl'):
            # ★ 반쪽 역본이면 **반대쪽을 누가 채우는지 함께 적는다** — 목록에
            #   66권이 다 있는데 배지만 「구약만」이면 어긋나 보인다.
            mate = ''
            if coverage in ('NT_ONLY', 'OT_ONLY'):
                try:
                    with appdb.connect(self.db_path) as _c:
                        mate = _vt.partner_of(
                            _c, self.ver, _vt._user_partner(_c, self.ver)) or ''
                except Exception:
                    mate = ''
            if coverage == 'NT_ONLY':
                t = i18n.t('UM_NTONLY', 'NT 전용')
                self._cov_lbl.config(text=(t + ' · ' + mate) if mate else t,
                                     bg='#1A5276')
                self._cov_lbl.pack(side='left', padx=(4, 2))
            elif coverage == 'OT_ONLY':
                t = i18n.t('UM_OTONLY', 'OT 전용')
                self._cov_lbl.config(text=(t + ' · ' + mate) if mate else t,
                                     bg='#6E2F1A')
                self._cov_lbl.pack(side='left', padx=(4, 2))
            else:
                self._cov_lbl.pack_forget()

    def _toast(self, text, ms=2000, under=None):
        """2초쯤 떴다 사라지는 알림 — **누를 것이 없다**.

        ★ 사용자 지시(2026-08-23): 「팝업을 다시 닫을 필요는 없이 2초 정도
          표시되고 사라지도록 하자」.
        ⚠ **`Toplevel` 로 만들지 않는다** — 창을 띄우면 포커스를 뺏어 읽던
          자리에서 키보드 흐름이 끊긴다. `place()` 로 **화면 위에 겹치는 라벨**
          이면 아무것도 안 뺏는다(`journey_story` 카드와 같은 방식).
        ⚠ 색은 역할로 — 겹쳐 뜨는 것이라 바탕과 대비돼야 읽힌다.

        `under` 에 위젯을 주면 **그 위젯 바로 아래**에 뜬다 (2026-09-24 사용자
        「성경버전 버튼 아래쪽에 표시되었다가 사라지면」). 안 주면 종전대로
        화면 위쪽 가운데.
        ⚠ `place` 는 **부모(self) 기준 좌표**다 — 위젯의 화면 좌표에서 창의
          화면 좌표를 빼야 한다. 그냥 `winfo_x()` 를 쓰면 **그 위젯의 부모
          안에서의 자리**라 엉뚱한 데 뜬다.
        """
        try:
            old = getattr(self, '_toast_lbl', None)
            if old is not None:
                try:
                    old.destroy()
                except Exception:
                    pass
            lbl = tk.Label(self, text=text,
                           bg=ui_theme.C('dark_bg') or '#2C4259',
                           fg=ui_theme.C('fg_on_dark') or '#FFFFFF',
                           padx=14, pady=6, relief='flat')
            spot = None
            if under is not None:
                try:
                    if under.winfo_ismapped():
                        spot = (under.winfo_rootx() - self.winfo_rootx(),
                                under.winfo_rooty() - self.winfo_rooty()
                                + under.winfo_height() + 4)
                except Exception:                                 # noqa: BLE001
                    spot = None
            if spot and spot[0] >= 0 and spot[1] >= 0:
                lbl.place(x=spot[0], y=spot[1], anchor='nw')
            else:
                lbl.place(relx=0.5, rely=0.05, anchor='n')
            lbl.lift()
            self._toast_lbl = lbl

            def _gone(w=lbl):
                if getattr(self, '_toast_lbl', None) is w:
                    self._toast_lbl = None
                try:
                    w.destroy()
                except Exception:
                    pass
            self.after(int(ms), _gone)
        except Exception as e:
            print(f'[toast] {e}')

    def _ver_swap_toast(self, bcode):
        """짝으로 **넘어가는 그 순간** 버전 버튼 아래에 한 번 알린다.

        사용자 「"구약성경은 B 버전으로 표시합니다."라는 다국어 메시지가 잠깐
        성경버전 버튼 아래쪽에 표시되었다가 사라지면 어떨까?」

        ⚠ **바뀔 때 한 번만** — 짝으로 계속 읽는 동안 장마다 뜨면 성가시다.
          직전에 무엇으로 읽었는지를 기억해 **달라졌을 때만** 띄운다.
        ⚠ 제 본문으로 돌아올 때는 **안 띄운다** — 그것은 정상이고, 알림은
          예외를 알리는 자리다(버튼은 그때도 `WLC` 로 돌아가 있다).
        """
        src = getattr(self, '_p1_src_ver', None) or self.ver
        last = getattr(self, '_ver_toast_src', None)
        self._ver_toast_src = src
        if src == self.ver or src == last:
            return
        try:
            nm = (getattr(self, '_ver_names', {}) or {}).get(src, src)
            key = 'UM_VER_SWAP_OT' if (bcode or 0) <= 39 else 'UM_VER_SWAP_NT'
            dflt = ('구약성경은 {v} 본문으로 표시합니다.' if (bcode or 0) <= 39
                    else '신약성경은 {v} 본문으로 표시합니다.')
            self._toast(i18n.t(key, dflt).format(v='%s (%s)' % (src, nm)),
                        ms=3000, under=getattr(self, '_ver_btn', None))
        except Exception:                                         # noqa: BLE001
            pass

    def _navigate_chapter(self, delta: int):
        """← → 버튼: 이전/다음 장. **책 끝에서는 옆 책으로 넘어간다.**

        ★ 사용자 지시(2026-08-23): 「마지막 장, 첫 장에서 다른 책으로 이동한다는
          것을 팝업으로 알리고 **이동하도록 허용**하자」.
          그전에는 책 경계에서 **조용히 아무 일도 안 했다** — 단추가 죽은 것처럼
          보였다.
        ⚠ 성경의 처음·끝에서도 **말은 한다** — 안 그러면 여전히 고장으로 읽힌다.
        """
        chaps = list(self.cb_chap['values'])
        if not chaps:
            return
        try:
            cur = chaps.index(self.cb_chap.get())
        except ValueError:
            return
        nxt = cur + delta
        if 0 <= nxt < len(chaps):
            self.cb_chap.set(chaps[nxt])
            self.on_chapter_selected(None)
            return

        # ── 책 경계 — 옆 책으로 ──────────────────────────────────────────
        books = list(self.cb_book['values'])
        try:
            bi = books.index(self.cb_book.get())
        except ValueError:
            return
        bj = bi + delta
        if not (0 <= bj < len(books)):
            self._toast(i18n.t('UM_BIBLE_EDGE', '성경의 처음입니다.') if delta < 0
                        else i18n.t('UM_BIBLE_END', '성경의 마지막입니다.'))
            return
        target = books[bj]
        self.cb_book.set(target)
        self.on_book_selected(None)          # 장 목록을 그 책 것으로 갈고 1장으로
        # ⚠ 뒤로 갈 때는 **그 책의 마지막 장**이라야 「이어서 읽는」 느낌이 된다
        if delta < 0:
            new_chaps = list(self.cb_chap['values'])
            if new_chaps:
                self.cb_chap.set(new_chaps[-1])
                self.on_chapter_selected(None)
        # ⚠ **조사를 붙이지 않는다** — 한국어 「로/으로」는 앞 글자의 받침에
        #   따라 갈린다(출애굽**기로** / 사무엘**상으로**). 자리표 뒤에 조사를
        #   두면 반드시 하나는 틀린다(실측: 「출애굽기 으로 넘어갑니다」).
        #   ⇒ 조사는 **고정 낱말**(「책으로」)에만 붙이고 책 이름은 뒤에 둔다.
        _msg = (i18n.t('UM_BOOK_PREV', '이전 책으로 넘어갑니다 · {book}')
                if delta < 0 else
                i18n.t('UM_BOOK_NEXT', '다음 책으로 넘어갑니다 · {book}'))
        self._toast(_msg.format(book=target))

    def on_book_selected(self, event):
        book_name = self.cb_book.get()
        self._save_state("last_book", book_name) # 선택한 책의 명칭을 JSON에 저장
        
        b_code = self.book_map[book_name]
        conn = appdb.connect(self.db_path)
        chaps = conn.execute("SELECT DISTINCT chapter FROM bible_index WHERE bcode = ? ORDER BY chapter", 
                             (b_code,)).fetchall()
        conn.close()
        self.cb_chap['values'] = [c[0] for c in chaps]
        if chaps:
            self.cb_chap.set(chaps[0][0])
            self.on_chapter_selected(None)
        else:
            self.cb_chap.set("")

    # P1 장 선택
    def on_chapter_selected(self, event):
        """[리스트박스 유지] 페리코프(BODY) 제목을 아이템으로 끼워 넣고 인덱스를 매핑합니다."""
        book_name = self.cb_book.get()
        chap = self.cb_chap.get()
        if not book_name or not chap or book_name not in self.book_map:
            return
        b_code = self.book_map[book_name]
        
        with appdb.connect(self.db_path) as conn:
            # 1. 본문 데이터 사냥 (기존 로직)
            sql = """
                SELECT bi.verse, bc.verse_text, bi.verse_id
                FROM bible_index bi
                JOIN bible_content bc ON bi.verse_id = bc.verse_id
                WHERE bi.bcode = ? AND bi.chapter = ? AND bc.version_code = ?
                ORDER BY bi.verse
            """
            self.p1_data = conn.execute(sql, (b_code, chap, self.ver)).fetchall()

            # ★★★ **반쪽 역본은 짝에게 빌린다** (279차 사용자 「히브리어 사용자는
            #   구약버전을 선택하고 읽다가 신약으로 이동하려면 또 다른 버전을
            #   선택해야 한다」). 구약만 있는 역본으로 신약에 오면 지금까지는
            #   「본문이 없습니다」였다 — 히브리어로 읽던 사람이 거기서 막힌다.
            #   ⚠⚠ **여기서 폴백 차례를 또 적지 않는다** — 절 하나를
            #     `verse_text.resolve` 에 물어 **그것이 고른 역본**을 그대로
            #     쓴다. 그 문이 ① 사용자가 고른 짝 ② 역본이 아는 기본 짝
            #     ③ 같은 언어 ④ 기준 역본을 차례로 본다.
            #   ⚠⚠⚠ 처음에는 짝만 봤는데, **짝이 없는 역본**(콥트어 — 콥트어
            #     구약이 없다)으로 구약에 가면 **화면이 통째로 비었다**(실측
            #     32자). 66권을 다 보이기로 한 이상 어느 책을 눌러도 읽을 글이
            #     나와야 한다(§0-1).
            self._p1_src_ver = self.ver
            if not self.p1_data:
                try:
                    _v0 = conn.execute(
                        'SELECT verse_id FROM bible_index WHERE bcode=? AND'
                        ' chapter=? ORDER BY verse LIMIT 1',
                        (b_code, chap)).fetchone()
                    _alt = _vt.resolve(
                        conn, _v0[0], self.ver,
                        _vt._ver_lang(conn, self.ver))['src_version'] if _v0 \
                        else None
                    if _alt and _alt != self.ver:
                        _rows = conn.execute(sql, (b_code, chap, _alt)).fetchall()
                        if _rows:
                            self.p1_data = _rows
                            self._p1_src_ver = _alt
                except Exception:
                    pass

            # 2. 🎯 [신설] 현재 장 범위 내의 BODY 페리코프 사냥
            pericopes = {}
            if self.p1_data:
                start_id, end_id = self.p1_data[0][2], self.p1_data[-1][2]
                # 제목 = 사용자 언어 → EN → KO 순 폴백(코드는 최후수단). 코드 노출 방지.
                p_sql = """
                    SELECT p.start_vid,
                           COALESCE(
                             (SELECT title FROM sys_text_asset
                               WHERE clicked_id=p.pericope_id AND text_type='PERI_TITLE'
                                 AND lang_code=? AND title IS NOT NULL AND title<>'' AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1),
                             (SELECT title FROM sys_text_asset
                               WHERE clicked_id=p.pericope_id AND text_type='PERI_TITLE'
                                 AND lang_code='EN' AND title IS NOT NULL AND title<>'' AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1),
                             (SELECT title FROM sys_text_asset
                               WHERE clicked_id=p.pericope_id AND text_type='PERI_TITLE'
                                 AND lang_code='KO' AND title IS NOT NULL AND title<>'' AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1),
                             p.peri_code, '') AS title
                    FROM sys_pericope_asset p
                    WHERE p.peri_type = 'BODY'
                      AND p.start_vid BETWEEN ? AND ?
                """
                # ★ 2026-10-10 1.txt 54-3 — 본문 옆 단락 제목은 **보이는 역본의 언어**를 따른다
                #   (BSB 를 고르면 영어 제목). 목록·트리 같은 다른 자리의 제목은 화면 언어 그대로다.
                #   그 언어 제목이 없으면 영어 → 한국어(위 SQL 폴백).
                try:
                    _peri_lang = (_vt._ver_lang(conn, getattr(self, '_p1_src_ver', None) or self.ver)
                                  or self.lang)
                except Exception:
                    _peri_lang = self.lang
                pericopes = {r[0]: r[1] for r in conn.execute(p_sql, (_peri_lang, start_id, end_id)).fetchall()}

            # ★★★ **히브리 절 번호 병기** (279차 사용자 「히브리 절 번호 병기
            #   진행하라」). 우리 좌표축은 영어 번호인데 히브리어 성경은 번호가
            #   다르다 — 시편 표제가 한 절을 먹고, 요엘·말라기는 장이 통째로
            #   밀린다. 나란히 펴 놓은 사람이 같은 절을 찾을 수 있어야 한다.
            #   ⚠ **히브리어 역본을 읽을 때만** 그린다 — 한국어로 읽는 사람에게는
            #     군더더기다(고르지 않아도 알아서 되는 것이 요점이다).
            #   ⚠ 번호가 **다른 절만** 온다(`sys_heb_verse_ref`) — 같은 자리에는
            #     아무것도 안 그린다(§0-1).
            self._p1_hebnum = {}
            try:
                if self.p1_data and _heb_lang(
                        conn, getattr(self, '_p1_src_ver', self.ver)):
                    import db_heb_versemap as _hv
                    _ch = int(chap)
                    for _v, _r in _hv.heb_refs(
                            conn, [r[2] for r in self.p1_data]).items():
                        self._p1_hebnum[_v] = _hv.label(_r, _ch)
            except Exception:
                self._p1_hebnum = {}

        # 3. UI 렌더링 및 매핑 테이블 구축
        self.p1_ls.delete(0, tk.END)
        self.p1_idx_map = []

        if not self.p1_data:
            self.p1_ls.insert(tk.END, i18n.t('MSG_NO_CHAPTER_TEXT', '   {ver} 역본에 이 장의 본문이 없습니다.').format(ver=self.ver), kind='plain')
            self._p1_verse_ids = []
            self.after(10, self._refresh_map_switcher_list)
            return

        self._sync_ver_btn()       # ★ 짝으로 읽었으면 버튼이 그것을 말한다
        self._ver_swap_toast(b_code)
        if getattr(self, '_p1_src_ver', self.ver) != self.ver:
            # ⚠ 빌려 온 본문임을 **화면이 말한다** — 말 안 하면 사용자는 고른
            #   역본을 읽고 있다고 믿는다(§0-1).
            self.p1_ls.insert(tk.END, i18n.t(
                'VT_FROM', '{v} 본문').format(v=self._p1_src_ver), kind='title')
            self.p1_idx_map.append(None)

        # ★ 2026-10-25 (docs/1.txt 1-3) 즐겨찾기 구절 · 녹음 있는 구절 — 절 번호에 표시(폰과 같은 뜻)
        _fav_v, _rec_v = set(), set()
        try:
            _ids = [r[2] for r in self.p1_data]
            _ph = ','.join('?' * len(_ids))
            with appdb.connect(self.db_path) as _c:
                _fav_v = {r[0] for r in _c.execute(
                    "SELECT COALESCE(verse_id, target_id) FROM user_favorite WHERE fav_type='VERSE' "
                    "AND COALESCE(record_status,'LIVE')='LIVE' AND COALESCE(verse_id, target_id) IN (%s)" % _ph, _ids)}
                # ★ 2026-10-28 표식 = 파일이 있는 녹음만(PC [삭제]는 진척 줄을 남긴다 — docs/1.txt 1-(3))
                #   (voice_bible 은 소리 꾸러미를 끌어와 무겁다 — 칸이 아직 없으면 옛 물음으로)
                try:
                    _rec_v = {r[0] for r in _c.execute(
                        'SELECT DISTINCT verse_id FROM user_voice_asset WHERE verse_id IN (%s)'
                        ' AND COALESCE(has_file,1)=1' % _ph, _ids)}
                except Exception:                     # noqa: BLE001
                    _rec_v = {r[0] for r in _c.execute(
                        'SELECT DISTINCT verse_id FROM user_voice_asset WHERE verse_id IN (%s)' % _ph, _ids)}
            if hasattr(self.p1_ls, 'mark_tags'):
                self.p1_ls.mark_tags()
        except Exception as _e:
            print('[P1 marks] %s' % _e)
        for i, (v_num, v_txt, v_id) in enumerate(self.p1_data):
            # 1. 단락 제목 삽입
            if v_id in pericopes:
                self.p1_ls.insert(tk.END, pericopes[v_id], kind='title')
                self.p1_idx_map.append(None)

            # 2. 실제 구절 삽입 (들여쓰기 주의)
            # 절 번호는 탭으로 벌리고 이어지는 줄은 본문 시작선에 맞춘다(lmargin2)
            self.p1_ls.insert(tk.END, v_txt, kind='verse', num=v_num,
                              num2=getattr(self, '_p1_hebnum', {}).get(v_id),
                              marks=tuple(m for m, on in (('fav', v_id in _fav_v), ('rec', v_id in _rec_v)) if on))
            self.p1_idx_map.append(i)

        # 한 장을 다 채웠다 — 이제야 최대 절 번호를 알 수 있어 번호 칸 폭을 확정한다
        if hasattr(self.p1_ls, 'finish_fill'):
            self.p1_ls.finish_fill()

        # 현재 장 verse_id 목록 캐시
        self._p1_verse_ids = [row[2] for row in self.p1_data] if self.p1_data else []

        # 🎯 [교정] 루프가 완전히 끝난 뒤 단 한 번 실행되도록 내어쓰기 합니다.
        self.after(10, self._refresh_map_switcher_list)

    def _start_manual_resize(self, event):
        self._drag_start_y = event.y_root

    def _do_manual_resize(self, event):
        """[무진동] 드래그 중에는 파일 저장 없이 시각적 높이만 즉시 변경합니다."""
        delta_y = event.y_root - self._drag_start_y
        new_h = self.p4_desc_panel.winfo_height() - delta_y 
        if 80 < new_h < 800:
            self.p4_desc_panel.config(height=new_h)
            self._drag_start_y = event.y_root
            self.update_idletasks()

    # 자녀숫자 계산, 부모 이외의 모든 연결 데이터를 표시하며 양방향은 하나로 합산
    def _get_valid_links_with_utility(self, a_id, a_type, p_vid=None):
        """[수리] 신규 ID 규격(@)을 반영하여 부모로의 역행(Back-link)을 차단합니다."""
        raw_links = self._fetch_links_integrated(a_id, a_type)
        if not raw_links: return []

        # 🎯 [수리] p_vid(예: NODE:5@ROOT)에서 순수 논리 ID(NODE:5)만 추출
        parent_logic_id = None
        if p_vid:
            parent_logic_id = str(p_vid).split('@')[0]

        unique_links = []
        seen_targets = set()
        for L in raw_links:
            target_vid = f"{L['target_type']}:{L['target_id']}"
            # 🎯 부모와 자식의 신분이 같으면 (역방향) 목록에서 제외
            if parent_logic_id and target_vid == parent_logic_id: continue
            if L['link_type'] == 'VERS_VERS':
                if target_vid in seen_targets: continue
            seen_targets.add(target_vid)
            unique_links.append(L)
        return unique_links

    ### ----  캔버스 경로 맵 저장 관련 메서드 모음 - 시작

    def _get_predicted_child_count(self, asset_id, asset_type, parent_vid):
        """[재설계] 현재 노드의 자식 중 부모(B)를 제외한 순수 연결 숫자를 계산합니다."""
        valid_children = self._get_valid_links_with_utility(asset_id, asset_type, p_vid=parent_vid)
        return len(valid_children)

    # 캔버스에 노드 배치방식
    def _calculate_layout_pos(self, layout_type, i, total, px, py):
        """자녀 수에 따라 단일 수직 또는 본문 공간을 확보한 이중 수직 열 배치를 수행합니다."""
        h_gap = self.cfg_h_gap
        v_gap = self.cfg_v_gap
        # 렌즈노드 박스를 여러 줄로 쓰면 박스가 그만큼 높아진다 — 세로 간격이
        # 그대로면 박스끼리 겹친다. **설정한 간격을 줄이지는 않고** 필요한 만큼만
        # 벌린다(2026-08-20 렌즈노드 박스 규격 신설과 함께).
        try:
            if str(getattr(self, 'cfg_node_mode', 'H')).upper() == 'W':
                # 폭 기준은 줄 수가 이름마다 다르다 — 평균 이름 길이(11자)로 어림한다
                _ln = max(1, -(-11 // max(2, int(getattr(self, 'cfg_node_chars', 14) or 14))))
            else:
                _ln = max(1, int(getattr(self, 'cfg_node_lines', 1) or 1))
            if _ln > 1:
                v_gap = max(v_gap, int(getattr(self, 'cfg_font_size', 9) or 9) * 2 * _ln + 24)
        except Exception:
            pass

        # 🎯 갯수에 상관없이 부모의 X축에서 h_gap만큼 떨어진 단일 수직열 배치
        nx = px + h_gap
        ny = py + (i - (total - 1) / 2) * v_gap
            
        return nx, ny

    # 맵 수동저장 : 좌표, 부모ID, 라벨, 타입, 태그
    def _save_manual_layout(self):
        """[수리] 사용자 UI를 유지하며 탐색 계보와 배치 상태를 user_saved_maps에 확정 저장합니다."""
        v_id = getattr(self, 'active_node_id', 1)
        # 이름은 **출발_종착_** 까지 지어 준다 — 태그만 붙이면 된다(2026-08-20)
        prefix = self._suggest_map_name(v_id)

        pop = tk.Toplevel(self)
        pop.title(i18n.t('WIN_SAVE_MAP', "수동 맵 저장"))
        pop.transient(self)

        tk.Label(pop, text=i18n.t('UM_ENTERMAPNAME','저장할 맵 이름을 입력하세요:'),
                 anchor='w').pack(fill='x', padx=10, pady=(10, 0))
        ent_name = tk.Entry(pop, width=44)
        ent_name.insert(0, prefix)
        ent_name.pack(fill='x', padx=10, pady=5)

        # ── 분류 태그 ────────────────────────────────────────────────────
        # ★ **태그 고르기를 붙였다** (2026-08-23 사용자 「태그검색창을 추가하여
        #   선택하면 자동입력하거나 2) 수작업 입력 하고 저장」).
        #   ⚠ **저장 자리는 그대로**다 — `user_saved_maps.tag_list`(자유 글).
        #     고르기는 **글을 채워 주는 도우미**일 뿐이고, 손으로 치는 길도
        #     그대로 산다(사용자가 둘 다 요구했다).
        #   ⚠ 부품을 새로 만들지 않는다 — `tag_picker.pick()` 이 검색·축 필터·
        #     내 태그 만들기·중복 안내를 이미 다 한다(§55).
        tk.Label(pop, text=i18n.t('UM_ENTERTAGS','분류 태그를 입력하세요 (예: a, b, c):'),
                 anchor='w').pack(fill='x', padx=10, pady=(10, 0))
        _tagrow = tk.Frame(pop)
        _tagrow.pack(fill='x', padx=10, pady=5)
        ent_tags = tk.Entry(_tagrow, width=34)
        ent_tags.pack(side='left', fill='x', expand=True)

        def _pick_tags():
            """선택한 태그 **이름**을 태그 칸과 **맵 이름 칸 둘 다**에 붙인다.

            ★ 후보 = 용어(엔티티) + 내 태그 (2026-09-01 0.txt 3번). 152차 수술로
              배포 태그가 0 이라 all_tags 만으로는 목록이 비었다. 여기 저장은
              자유 글(tag_list)이라 이름만 필요하다 — `term_rows` 가 맞다.
            ★ 이름 칸에도 `_` 로 결합해 붙인다 (2026-09-02 0.txt 1번 사용자
              지시 「태그이름을 선택해서 저장했는데 경로맵 이름에 추가되지
              않는다. 여러 개라면 _ 로 결합하라」 — 이름 규약이
              `출발_종착_태그1_태그2` 다. 이미 든 이름은 다시 안 붙인다)."""
            try:
                import tag_picker
                _lang = getattr(self, 'lang', 'KO')
                _prov = lambda: tag_picker.term_rows(self.db_path, _lang)
                got = tag_picker.pick(pop, self.db_path, lang=_lang,
                                      rows_provider=_prov)
                if not got:
                    return
                names = {(s, i): nm for s, i, nm, _ax, _full, *_m in _prov()}
                cur = [t.strip() for t in ent_tags.get().split(',') if t.strip()]
                for key in got:
                    nm = names.get(tuple(key))
                    if nm and nm not in cur:
                        cur.append(nm)
                ent_tags.delete(0, 'end')
                ent_tags.insert(0, ', '.join(cur))
                # 이름 칸 — 출발_종착_ 뒤에 태그를 _ 로 이어 붙인다
                base = ent_name.get().strip()
                have = [p for p in base.split('_') if p]
                add = [t for t in cur if t not in have]
                if add:
                    joined = (base if base.endswith('_') or not base
                              else base + '_') + '_'.join(add)
                    ent_name.delete(0, 'end')
                    ent_name.insert(0, joined)
            except Exception as e:
                print(f'[map tag pick] {e}')

        tk.Button(_tagrow, text=i18n.t('TAG_PICK_BTN', '태그 선택하기…'),
                  bd=1, relief='groove', padx=6, cursor='hand2',
                  command=_pick_tags).pack(side='left', padx=(6, 0))

        def do_save():
            map_name = ent_name.get().strip()
            tag_list = ent_tags.get().strip()
            if not map_name: return
            # ★ **보존본은 여러 개 저장한다** (2026-08-20 사용자 재확정 —
            #   「출발지가 같아도 중간 경로·종착지가 다르면 사실상 내용·관점이
            #   다르다」. 8-20 오전의 단일 슬롯 결정을 되돌린다. 맵은 산출물이
            #   아니라 **작업대**라 묶음이 여럿인 것이 자연스럽다).
            #   같은 이름이면 그것만 덮어쓴다.
            old = None
            try:
                with appdb.connect(self.db_path) as conn:
                    old = conn.execute(
                        "SELECT 1 FROM user_saved_maps WHERE root_id=? "
                        "AND save_type='MANUAL' AND map_name=?",
                        (v_id, map_name)).fetchone()
            except Exception:
                pass
            if old and not messagebox.askyesno(
                    i18n.t('MSG_T_SAVECONFIRM', '저장 확인'),
                    i18n.t('UM_MAP_OVERWRITE_Q',
                           "같은 이름의 맵이 있습니다.\n'{name}' 을(를) 덮어쓸까요?"
                           ).format(name=map_name), parent=pop):
                return
            if self._write_manual_map(map_name, tag_list):
                self._refresh_map_switcher_list()
                pop.destroy()
                messagebox.showinfo(i18n.t('MSG_T_SAVEDONE', "저장 완료"), i18n.t('MSG_JOURNEY_SAVED', "태그 '{tags}'와 함께 여정이 저장되었습니다.").format(tags=tag_list))

        # ⚠ 색은 역할로(§0) — 옛 `bg="#27AE60"` 는 검정 테마에서 그대로 굳었다.
        tk.Button(pop, text=i18n.t('UM_CONFIRMSAVE', ' 확정 저장 '), command=do_save,
                  bg=ui_theme.C('success') or '#27AE60',
                  fg=ui_theme.C('fg_on_dark') or '#FFFFFF',
                  bd=0, padx=12, pady=4, cursor='hand2').pack(pady=16)
        # ⚠ **다 지은 뒤 한 번** — 창을 만들자마자 부르면 뒤에 붙는 위젯이 안
        #   칠해지고 `adopt` 는 멱등이라 나중 호출이 그냥 돌아간다(§65).
        try:
            ui_theme.adopt(pop)
        except Exception:
            pass
        pop.update_idletasks()
        pop.geometry('%dx%d' % (max(360, pop.winfo_reqwidth()),
                                pop.winfo_reqheight()))

    def _write_manual_map(self, map_name, tag_list=''):
        """수동 맵 저장의 본체 — 팝업과 (앞으로) 작성툴이 함께 쓴다 (2026-08-20).

        ★ **여러 개 저장된다**(2026-08-20 재확정) — 같은 이름이면 그것만 덮어쓴다
          (PK 가 (root, type, name) 이라 INSERT OR REPLACE 가 그대로 맞다).
        ★ rel_label 도 박제한다 — AUTO 스냅샷과 같은 모양이어야 어댑터가
          한 가지 포맷만 읽는다(복원 화면은 어차피 DB 재조회).
        """
        v_id = getattr(self, 'active_node_id', None)
        if not v_id or not getattr(self.p4_view, 'nodes', None):
            return False
        layout_struct = {nid: {'node_id': info.get('node_id'), 'p_id': info.get('p_id'),
                               'x': info.get('x'), 'y': info.get('y'),
                               'rel_label': info.get('rel_label', "")}
                         for nid, info in self.p4_view.nodes.items()}
        d_path = "|".join(getattr(self, 'current_journey_list', []))
        try:
            with appdb.connect(self.db_path) as conn:
                conn.execute("""
                    INSERT OR REPLACE INTO user_saved_maps
                    (root_id, save_type, map_name, path_string, tag_list, full_structure, updated_at)
                    VALUES (?, 'MANUAL', ?, ?, ?, ?, datetime('now'))
                """, (v_id, map_name, d_path, tag_list,
                      json.dumps(layout_struct, ensure_ascii=False)))
                conn.commit()
            return True
        except Exception as e:
            print(f"Save Error: {e}")
            return False

    # 맵 자동저장 
    def _safe_auto_save_workbench(self):
        """[KeyError 수리] p_view_id 키 대신 p_id 키를 사용하여 장부 무결성을 유지합니다."""
        v_id = getattr(self, 'active_node_id', None)
        if not v_id or not self.p4_view.nodes: return

        snapshot_data = {
            vid: {
                'node_id': info['node_id'], 
                'p_id': info.get('p_id'), 
                'x': info['x'], 'y': info['y'],
                'rel_label': info.get('rel_label', "") # [핵심] 관계명을 JSON에 박제
            }
            for vid, info in self.p4_view.nodes.items()
        }
        
        # 2. 🎯 [path_string] View ID의 여정 순서 (v1|v5|v12)
        journey_path = "|".join(getattr(self, 'current_journey_list', []))
        
        try:
            with appdb.connect(self.db_path) as conn:
                pure_id = int(str(v_id).split(':')[-1] if ':' in str(v_id) else v_id)
                conn.execute("""
                    INSERT OR REPLACE INTO user_saved_maps (root_id, save_type, map_name, path_string, full_structure, updated_at)
                    VALUES (?, 'AUTO', ?, ?, ?, datetime('now'))
                """, (pure_id, f"AUTO_{pure_id}", journey_path, json.dumps(snapshot_data, ensure_ascii=False)))
                conn.commit()
        except Exception as e:
            print(f"Save Error: {e}")

    def _get_collision_free_y(self, target_x, target_y):
        """[신설] 새로 등장하는 노드가 기존 노드와 겹치지 않게 Y축을 보정합니다."""
        safe_y = target_y
        collision = True
        threshold = getattr(self, 'cfg_v_gap', 210) * 0.8 # 간격 기준

        while collision:
            collision = False
            # 캔버스 장부를 전수 조사하여 같은 X열에 겹치는 녀석이 있는지 확인
            for nid, info in self.p4_view.nodes.items():
                if abs(info['x'] - target_x) < 50: # 같은 열
                    if abs(info['y'] - safe_y) < threshold:
                        safe_y += getattr(self, 'cfg_v_gap', 210) # 겹치면 아래로 밀기
                        collision = True
                        break
        return safe_y

    def _sync_node_memory_from_canvas(self):
        """[실측] 캔버스의 실제 위치를 장부에 동기화하되 tag는 건드리지 않습니다."""
        for nid, info in self.p4_view.nodes.items():
            items = self.p4_view.find_withtag(nid)
            if items:
                # 🎯 첫 번째 아이템(보통 사각형/원)의 좌표 추출
                coords = self.p4_view.coords(items[0])
                if coords and len(coords) >= 2:
                    # 캔버스의 중심 좌표를 계산하여 장부에 기록
                    new_x, new_y = coords[0], coords[1]
                    info.update({'x': float(new_x), 'y': float(new_y)})

    def _finalize_smart_layout(self, x, y, mx, v_id, is_new, is_loading=False):
        """ 캔버스 맵 복구 상황(is_loading)일 때는 자동 노드 전개를 중단하여 좌표를 보호합니다."""
        if is_new or getattr(self, 'force_refocus', False):
            # 🎯 지정된 좌표로 캔버스 시점 이동
            self.p4_view.focus_on_coordinate(x, y, margin_x=mx)
        elif hasattr(self, 'last_vx'):
            # 🎯 이전 스크롤 위치 유지
            self.p4_view.xview_moveto(self.last_vx)
            self.p4_view.yview_moveto(self.last_vy)
            
        # 🎯 [핵심수정] 괄호 닫기 완료 및 로딩 중이 아닐 때만 자동 사냥 가동
        if not is_loading:
            self.handle_p4_node_click(v_id, 'BIBLE', x, y)

    def _rel_labels_between(self, conn, p_pure, v_n):
        """두 구절 사이 연결의 관점 라벨 — **전부 모아 '·' 병합** (2026-08-20).

        복원 두 경로(_apply_saved_research_data · on_verse_selected)가 LIMIT 1
        로 한 관점만 살려서, 펼침 경로(_fetch_links_integrated 의 병합)와
        복원 화면의 라벨이 달랐다. 이제 세 경로가 같은 모양을 그린다."""
        sql = """
            SELECT R.rel_name, L.rel_code FROM (
                SELECT rel_code FROM user_link_asset
                WHERE ((clicked_id=? AND target_id=?) OR (clicked_id=? AND target_id=?)) AND record_status != 'HIDE'
                UNION ALL
                SELECT rel_code FROM sys_link_asset
                WHERE ((clicked_id=? AND target_id=?) OR (clicked_id=? AND target_id=?))
                AND COALESCE(record_status,'LIVE')='LIVE'
                AND sys_link_id NOT IN (SELECT origin_id FROM user_link_asset WHERE origin_id IS NOT NULL)
            ) L JOIN sys_rel_catalog R ON L.rel_code = R.rel_code AND R.lang_code IN (?, 'KO', 'EN')
            ORDER BY CASE R.lang_code WHEN ? THEN 1 WHEN 'EN' THEN 2 ELSE 3 END
        """
        _lang = (getattr(self, 'lang', 'KO') or 'KO').upper()
        best = {}                      # rel_code → 언어 우선순위 첫 이름
        try:
            for name, code in conn.execute(
                    sql, (p_pure, v_n, v_n, p_pure, p_pure, v_n, v_n, p_pure,
                          _lang, _lang)):
                if code not in best and name:
                    best[code] = str(name)
        except Exception:
            return ""
        out = []
        for nm in best.values():
            if nm not in out:
                out.append(nm)
        return '·'.join(out)

    def _restore_cap_struct(self, struct):
        """복원 지도에도 **표시 상한**을 적용 — (버릴 nid 집합, {부모 view: 묶음표}).

        ★★ 왜 (2026-08-27 사용자 — 「최초부모는 10개 자녀, 그 자녀를 누르면
          3/15 정상. 구절마다 다른 것이 이해할 수 없다」): AUTO 지도 61장 중
          **25장**이 상한 이전에 저장돼 부모당 최대 24자식을 담고 있었고,
          복원은 그대로 다 그렸다 — 같은 화면의 규칙이 「언제 저장했느냐」로
          갈렸다. 이제 복원도 펼침과 **같은 정렬·같은 상한**을 탄다.
        · 자식을 펼쳐 둔 가지는 남긴다(§46 보호 — 파고든 가지를 끊지 않는다).
        · 버린 자식의 자손도 함께 버린다.
        · 분모(grand)는 지도가 아니라 **DB 로 센다** — 지도가 10개만 담고
          있어도 실제 연결이 15개면 「3/15」다.
        """
        limit = self._canvas_link_limit()
        kids = {}
        for nid, info in struct.items():
            p = info.get('p_id')
            if p:
                kids.setdefault(str(p), []).append(nid)
        drop, metas = set(), {}
        for p, lst in kids.items():
            if len(lst) <= limit:
                continue
            prot = [n for n in lst if kids.get(str(n))]      # 자식이 있는 가지
            unprot = [n for n in lst if n not in prot]
            p_info = struct.get(p) or {}
            try:
                v_t, v_n = self._split_logic_id(p_info.get('node_id'))
            except Exception:
                continue
            # 점수는 펼침과 같은 사냥꾼에게 묻는다 — 규칙이 갈리면 또 「구절마다
            # 다르다」가 된다
            fetched = self._fetch_links_integrated(v_n, v_t)
            score = {'%s:%s' % (L['target_type'], L['target_id']):
                     L.get('score') for L in fetched}
            # 조상(이 부모의 계보) — 분모에서 뺀다(펼침의 _grand 와 같은 셈)
            anc = set()
            cur = p
            while cur:
                ci = struct.get(cur) or {}
                if ci.get('node_id'):
                    anc.add(str(ci['node_id']))
                cur = str(ci.get('p_id')) if ci.get('p_id') else None
            grand = sum(1 for L in fetched
                        if '%s:%s' % (L['target_type'], L['target_id'])
                        not in anc)

            def _rk(nid2):
                lid = str(struct[nid2].get('node_id') or '')
                try:
                    tid = int(lid.split(':')[-1])
                except Exception:
                    tid = 0
                return self._child_rank_key(
                    {'score': score.get(lid), 'target_id': tid})
            unprot.sort(key=_rk)
            keep = set(prot) | set(unprot[:max(0, limit - len(prot))])
            if not keep:                      # 보호 0 + 상한 0 방지
                keep = set(unprot[:1])
            for n in lst:
                if n not in keep:
                    drop.add(n)
            metas[str(p)] = {'page': 0,
                             'pages': max(1, (max(grand, len(lst)) + limit - 1)
                                          // limit),
                             'start': 1, 'end': len(keep),
                             'grand': max(grand, len(lst))}
        # 버린 자식의 자손도 걷는다
        changed = True
        while changed:
            changed = False
            for nid, info in struct.items():
                if nid in drop:
                    continue
                if str(info.get('p_id')) in drop:
                    drop.add(nid)
                    changed = True
        return drop, metas

    def _apply_restore_page_badges(self, metas):
        """복원 상한이 자른 부모에 「n/전체」 두 줄 배지를 단다(펼침 4.5 와 동형)."""
        if not metas:
            return
        meta_map = getattr(self, '_p4_page_meta', None)
        if meta_map is None:
            meta_map = self._p4_page_meta = {}
        for p, m in metas.items():
            meta_map[p] = m
            try:
                _n = m['end'] - m['start'] + 1
                self.p4_view.update_badge(p, _n,
                                          text='%d\n/%d' % (_n, m['grand']),
                                          plus=(_n < m['grand']))
            except Exception:
                pass

    ###  JSON 파일에 저장된 좌표에 따라서 캔버스를 재현
    def _apply_saved_research_data(self, root_id, map_name):
        """[Live-Sync] JSON 정보는 '지도'로만 쓰고, 알맹이(관계명/숫자)는 DB 원본에서 실시간 사냥합니다."""
        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                row = conn.execute("SELECT full_structure FROM user_saved_maps WHERE root_id=? AND map_name=?", (root_id, map_name)).fetchone()
                if not row: return
                
                struct = json.loads(row['full_structure'])
                self.p4_view.clear_all()
                # ★ 복원도 표시 상한을 탄다 (2026-08-27 — 위 helper 참조)
                _drop, _pg_metas = self._restore_cap_struct(struct)

                for nid, info in struct.items():
                    if nid in _drop:
                        continue
                    n_id_val = info.get('node_id')
                    if not n_id_val: continue

                    v_t, v_n = self._split_logic_id(n_id_val)
                    p_id = info.get('p_id')
                    
                    # 🎯 [해결 1] 관계명 DB 역추적 — 병합 헬퍼 (LIMIT 1 폐기, 2026-08-20)
                    rel_label = ""
                    if p_id and v_t == 'BIBLE':
                        p_pure = p_id.split('@')[0].split(':')[-1]
                        rel_label = self._rel_labels_between(conn, p_pure, v_n)

                    # ★ 노드 생성은 **모든 노드**에 대해 (2026-08-19 잠복 버그 수리 —
                    #   위 if 안에 들여져 있어 **루트 노드(p_id 없음)와 NODE/CONTAINER
                    #   가 복원에서 통째로 빠졌다**. 저장 14개 → 복원 13개 실측으로
                    #   잡음. 관계명 역추적만 p_id 있는 구절 노드의 몫이다.)
                    # ⚠ 옛 코드는 루트를 0 으로 박았다 — 이제 펼쳐진 노드는
                    #   배지를 고정하므로(2026-08-20) 루트가 영영 0 으로 남는다.
                    #   복원에서도 「펼치기 전 개수」를 제대로 세어 둔다.
                    b_count = self._get_child_count(v_n, v_t, parent_id=p_id, conn=conn)

                    self.p4_view.add_enhanced_node(
                        p_id, nid, n_id_val, self.get_asset_name(v_n, v_t),
                        self._truncate_text(self._get_bible_text_for_p4(v_n)) if v_t == 'BIBLE' else "",
                        float(info['x']), float(info['y']), v_t,
                        badge_count=b_count,
                        rel_label=rel_label
                    )

                self.p4_view.redraw_edges()
                self._refresh_all_badges()
                self._apply_restore_page_badges(_pg_metas)
        except Exception as e: print(f"Restore Error: {e}")

    def _get_children_from_asset(self, raw_id, a_type):
        """[신설] DB 자산맵에서 연결된 자식들의 정보를 정교하게 추출합니다."""
        children = []
        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                # 🎯 link_type에 따른 동적 타입 결정 로직 (BIBLE, NODE, CONTAINER)
                query = "SELECT * FROM sys_link_asset WHERE clicked_id=? ORDER BY sort_order"
                rows = conn.execute(query, (raw_id,)).fetchall()
                for r in rows:
                    t_id = r['target_id']
                    # link_type에서 자식의 실제 타입을 판별 (예: CONT_NODE -> NODE)
                    l_type = r['link_type']
                    c_type = 'BIBLE' if 'VERS' in l_type.split('_')[1] else 'NODE' if 'NODE' in l_type.split('_')[1] else 'CONTAINER'
                    
                    children.append({
                        'id': t_id,
                        'type': c_type,
                        'name': self.get_asset_name(t_id, c_type),
                        'text': self._truncate_text(self._get_bible_text_for_p4(t_id)) if c_type == 'BIBLE' else ""
                    })
        except Exception as e: print(f"Asset Fetch Error: {e}")
        return children

    def _init_default_map(self, v_id):
        pure_id = str(v_id).split(':')[-1] if ':' in str(v_id) else v_id
        root_node_id = f"BIBLE:{pure_id}" 
        # 🎯 [수리] 구형 메서드 대신 신규 발급기 호출
        root_inst_id = self.generate_node_view_id(root_node_id) 
        
        self.p4_view.clear_all()
        self.p4_view.nodes.clear()
        
        # ⚠ 배지를 안 주면 0 으로 그려지는데, 펼친 뒤에는 값을 고정하므로
        #   (2026-08-20) **영영 0 으로 남는다** — 옵션을 바꿔 다시 그릴 때
        #   루트가 0 이 되던 원인(실측). 여기서 「펼치면 나올 개수」를 센다.
        # 잘리는 루트(연결 > 상한)는 배지가 「1~10/42」+＋ 로 자라므로
        # 만들 때 그 폭을 예약한다(§47 · 2026-08-26 ③) — 안 하면 루트에서만
        # ＋ 가 자리가 없어 안 그려진다.
        _bt, _bv = self._get_child_count(pure_id, 'BIBLE', parent_id=None, with_vv=True)
        _b, _btxt, _brsv = self._badge_spec(_bt, _bv)
        self.p4_view.add_enhanced_node(None, root_inst_id, root_node_id,
                                       self.get_asset_name(pure_id, 'BIBLE'),
                                       self._truncate_text(self._get_bible_text_for_p4(pure_id)),
                                       float(self.cfg_start_x), 0.0, 'BIBLE',
                                       badge_count=_b,
                                       badge_text=_btxt, badge_reserve=_brsv)
        
        self.handle_p4_node_click(pure_id, 'BIBLE', float(self.cfg_start_x), 0.0, root_inst_id, auto_save=False)

    def _calculate_id_lineage(self, start_vid):
        """[재설계] 모든 ID를 문자열로 정규화하여 순환 참조 시 0.01초 내에 탈출합니다."""
        lineage = []
        curr = str(start_vid) if start_vid else None
        seen = set()
        
        while curr and curr in self.p4_view.nodes and curr not in seen:
            seen.add(curr)
            lineage.append(curr)
            parent_id = self.p4_view.nodes[curr].get('p_id')
            curr = str(parent_id) if parent_id else None
            
        return lineage

    def _generate_report_v2(self, path_list, coord_data):
        """[리포트] 클릭 순서(Path)를 따르되, 물리적 계보(p_id)를 분석하여 인덴트를 적용합니다."""
        report_text = "[Bible Meditation Research Report]\n" + "="*50 + "\n\n"
        
        for vid_s in path_list:
            # 🎯 [계보 분석] full_structure(coord_data)에서 루트까지의 깊이(Depth) 계산
            depth = 0
            curr = vid_s
            while curr in coord_data and coord_data[curr].get('p_id'):
                depth += 1
                curr = coord_data[curr]['p_id']
            
            indent = "    " * depth
            v_type, v_num = vid_s.split(':')
            name = self.get_asset_name(v_num, v_type)
            
            # 리포트 본문 작성
            report_text += f"{indent}● {name}\n"
            # (이후 본문 및 묵상노트 추출 로직 결합...)
        return report_text

    def _get_map_prefix(self, v_id, conn=None):
        """[신설] 언어 설정에 따른 구절 약명(창1:1 / GEN1:1)을 추출합니다.

        ★ 약명은 불변이라 (v_id, 언어) 로 캐시한다 (2026-09-01 0.txt 3번 —
          Maps 팝업이 줄마다 새 연결을 열어 7초가 걸렸다. 실측 후 수리)."""
        key = (v_id, self.lang)
        cache = getattr(self, '_vid_label_cache', None)
        if cache is None:
            cache = self._vid_label_cache = {}
        got = cache.get(key)
        if got is None:
            got = self._get_bible_label_direct(v_id, conn=conn).replace(" ", "")
            cache[key] = got
        return got

    def _map_end_label(self):
        """지금 여정의 **종착지 약명** — 이름 자동 제안에 쓴다 (2026-08-20).

        같은 출발지라도 종착지가 다르면 다른 맵이라는 것이 복수 저장의 근거다
        (사용자: 「창1:1_계5:5_사랑, 창1:1_계20:5_영광」). 여정 마지막에서
        거꾸로 훑어 **구절 노드**를 찾는다 — 끝이 렌즈 노드일 수 있다."""
        try:
            for vid in reversed(getattr(self, 'current_journey_list', []) or []):
                info = self.p4_view.nodes.get(vid)
                if info:
                    v_t, v_n = self._split_logic_id(info.get('node_id'))
                else:
                    # ⚠ 표시 상한·묶음 교체(§84차)로 캔버스에서 걷힌 노드는
                    #   nodes 에 없다 — 그래서 이름이 「창1:3_」에서 끊겼다
                    #   (2026-09-01 사용자 신고). 여정 항목의 view_id 자체가
                    #   `BIBLE:123@…` 꼴이라 **글자에서 바로 읽는다.**
                    v_t, v_n = self._split_logic_id(vid)
                if v_t == 'BIBLE':
                    return self._get_map_prefix(v_n)
        except Exception as e:
            print(f'[map end label] {e}')
        return ''

    def _suggest_map_name(self, v_id):
        """`창1:1_계22:21` 까지 지어 준다 — 태그만 손으로 붙이면 된다."""
        start = self._get_map_prefix(v_id)
        end = self._map_end_label()
        return f'{start}_{end}_' if (end and end != start) else f'{start}_'

    ### 편집 중인 데이터를 데이터베이스(SQLite)에 자동으로 저장하는 역할
    def _coordinate_monitor(self):
        """[정밀 진단] 장부(Memory) vs 현실(Canvas)의 괴리를 실시간으로 추적합니다."""
        print("\n" + "="*90)
        print("🖥️ [좌표 무결성 진단 모니터] 가동 중...")
        print("="*90)
        print("{:<15} | {:<20} | {:<20} | {:<10}".format("Node ID", "Memory(Dict)", "Canvas(Physics)", "Status"))
        print("-" * 90)

        for nid, info in self.p4_view.nodes.items():
            # 1. 📖 장부 기록 (Dictionary)
            mx, my = round(info.get('x', 0), 1), round(info.get('y', 0), 1)
            
            # 2. 🎯 현실 실측 (Canvas Widget)
            items = self.p4_view.find_withtag(nid)
            if items:
                # 위젯의 실제 물리적 중심 좌표를 추출
                rx, ry = self.p4_view.coords(items[0])[:2]
                rx, ry = round(rx, 1), round(ry, 1)
                
                # 3. 괴리율 판정
                diff = abs(mx-rx) + abs(my-ry)
                status = "MATCH" if diff < 1 else "DRIFT"
                canvas_pos = "({0}, {1})".format(rx, ry)
            else:
                status = "LOST"
                canvas_pos = "NOT_FOUND"

            print("{:<15} | ({:<7}, {:<7}) | {:<20} | {:<10}".format(nid, mx, my, canvas_pos, status))
        print("="*90 + "\n")

    def _final_truth_tester(self):
        """[최종 진단] 캔버스의 모든 객체를 전수 조사하여 숨겨진 좌표와 이름표를 찾아냅니다."""
        print("\n" + "!"*40 + " [ THE TRUTH REPORT ] " + "!"*40)
        all_items = self.p4_view.find_all()
        print(f"1. 캔버스 물리 객체 총량: {len(all_items)}개")
        print("-" * 100)
        print(f"{'Item ID':<10} | {'Found Tags':<30} | {'Real Coords (Physics)':<25} | {'Match Status'}")
        print("-" * 100)

        for item in all_items:
            tags = self.p4_view.gettags(item)
            # 🎯 노드 ID(BIBLE:1 등)가 포함된 태그 추출
            node_id = next((t for t in tags if ":" in t and not t.startswith("link_")), None)
            
            # 🎯 물리 좌표 실측
            pos = self.p4_view.coords(item)
            coords_str = f"({round(pos[0],1)}, {round(pos[1],1)})" if pos else "NULL"
            
            # 🎯 장부(nodes)와의 대조
            in_dict = "IN_DICT" if node_id in self.p4_view.nodes else "MISS_DICT"
            if not node_id: in_dict = "---"

            print(f"{item:<10} | {str(tags):<30} | {coords_str:<25} | {in_dict}")
        print("!"*102 + "\n")

    ### 캔버스 경로맵 저장 관련 메서드  - 끝 

    ### P1에서 구절 선택시 캔버스 초기화, 1)user_saved_maps에서 노드정보 조회하여 저장데이터를 좌표대로 배치, 2)저장데이터가 없으면 최초부모를 배치하고 링크자산 탐색
    def _show_focus_overlay(self, plan_id, current_day):
        """묵상플랜 관리탭 ▶ Focus 모드 → P1 Tab2로 전환 후 해당 플랜 로드."""
        if hasattr(self, 'p1_nb'):
            self._ensure_p1_tab(self._tab_plan); self.p1_nb.select(self._tab_plan)
        # ★ 그 플랜이 사는 탭으로 (2026-08-16 서브탭 6개)
        idx, v = self._plan_view_for(plan_id)
        if hasattr(self, 'p1_plan_nb'):
            self.p1_plan_nb.select(idx)
        if v is not None:
            v.show_focus_by_plan(plan_id, current_day)

    # ── P2 서브탭 지연 빌드(시작 속도) ──

    def _on_lang_badges(self, key=None):
        """어느 화면의 언어 콤보가 바뀌었다 → P2·P4 머리·구절 연결 오른쪽 칸 배지를
        그 자리에서 다시 센다(2026-10-09 1.txt 59-1). 한 번에 몰아 센다(이벤트가
        잇달아도 한 번)."""
        if getattr(self, '_lang_badge_job', None):
            try:
                self.after_cancel(self._lang_badge_job)
            except Exception:
                pass

        def go():
            self._lang_badge_job = None
            # ⚠ 배지가 **마지막으로 센 구절**을 다시 센다 — `last_clicked_vid` 는
            #   캔버스 클릭만 적는 이름이라 P1 에서 고른 구절을 모른다(시험이 잡았다).
            vid = getattr(self, '_p2_badge_vid', None)
            if vid:
                try:
                    self._update_p2_tab_counts(vid)
                except Exception as e:
                    print('[lang badges p2] %s' % e)
            vid4 = getattr(self, '_p4_badge_vid', None)
            try:
                if vid4:
                    self._update_p4_badges(vid4)
            except Exception as e:
                print('[lang badges p4] %s' % e)
            np_ = getattr(self, 'p4_node_panel', None)
            if np_ is not None and getattr(np_, '_curr_vid', None):
                try:
                    np_._update_tab_counts(np_._curr_vid, getattr(np_, '_chain_n', None))
                except Exception as e:
                    print('[lang badges node] %s' % e)
        try:
            self._lang_badge_job = self.after(150, go)
        except Exception:
            go()

    def _update_p2_tab_counts(self, vid, chain_n=None):
        """P2 탭 배지 — 묵상노트 수 하나(설명은 셈이 없다). `chain_n` 은 옛 호출 보호용으로 받기만 한다."""
        if not hasattr(self, '_p2_tabs'):
            return
        if not getattr(self, '_lang_badge_hooked', False):
            try:
                import lang_combo as _LC
                _LC.listen(self._on_lang_badges)
                self._lang_badge_hooked = True
            except Exception:
                pass
        self._p2_badge_vid = vid
        try:
            import note_refr_panel as _nrp
            n = self._p2_note_count_memo(vid, _nrp)
            self._p2_tabs.set_count('NOTE', n)
        except Exception:
            pass

    def _p2_note_count_memo(self, vid, nrp):
        return appdb.memo(('p2_note_count', vid), lambda: nrp.count_for(self.db_path, vid))


    def _p2_note_my_edit(self):
        """자료·노트 세 갈래 공통 [My Edit] — **의도가 화면을 정한다**.

        ★★★ 2026-08-31 사용자 확정(0.txt 3번) — 「목록을 클릭하지 않고 **버튼만
          눌렀다는 것은 노트를 작성하겠다는 의도**」 · 「목록을 클릭한 것은
          **수정하거나 다른 자산과 연결/숨기기 하겠다는 의도**」.
        · 노트를 고르고 눌렀다 → `EDIT` · 출발지 = **그 노트** · 가운데 수정화면
        · 그냥 눌렀다        → `NEW`  · 출발지 = **구절** · 재고 「묵상노트」
                                포커스 · 가운데 **빈 입력화면**
        ⚠ 노트가 없어도 **알리지 않는다** — 새로 쓰려는 것이 분명하기 때문이다
          (그전에는 「노트를 클릭하세요」를 띄웠는데, 규칙이 서니 군더더기다).
        """
        try:
            import my_edit
            key = self._p2_tabs.current()
            vid = getattr(self, '_p1_verse_id', None)
            done = lambda _w=None: self._p2_note_reload()
            if key == 'NOTE':
                np = getattr(self, 'p2_note_panel', None)
                nid = getattr(np, 'current_record_id', None) if np else None
                if nid:
                    my_edit.open(self, kind='NOTE', asset_id=int(nid),
                                 intent=my_edit.INTENT_EDIT, on_changed=done)
                else:
                    my_edit.open(self, kind='VERSE', asset_id=vid,
                                 intent=my_edit.INTENT_NEW, pick_kind='NOTE',
                                 pick_label=i18n.t('LP_B_NOTE', '묵상노트'),
                                 on_changed=done)
                return
            # 연구자료·내부연결 — 목록을 고르는 길이 이 단추와 갈리지 않으므로
            # 늘 「새로 쓰기」로 본다(연구 글은 P4 가 고치는 자리다).
            my_edit.open(self, kind='VERSE', asset_id=vid,
                         intent=(my_edit.INTENT_NEW if key == 'REFR' else None),
                         pick_kind=('USER_REF' if key == 'REFR' else None),
                         on_changed=done)
        except Exception as e:
            print('[p2 note my edit] %s' % e)

    def _p2_note_reload(self):
        """[My Edit] 저장 뒤 — 묵상노트를 다시 읽는다."""
        vid = getattr(self, '_p1_verse_id', None)
        w = getattr(self, 'p2_note_panel', None)
        if w is not None and vid:
            try:
                w.load(vid)
            except Exception:
                pass






    def _goto_verse_from_lex(self, vid):
        """원어 화면에서 선택한 절로 간다 — P1 본문이 따라온다."""
        try:
            self._plan_verse_navigate(vid)
        except Exception:
            try:
                self.load_verse_by_id(vid)
            except Exception:
                pass

    def _build_p2_note(self, frame):
        self.p2_note_panel = NoteRefrPanel(frame, self.db_path, 'VERS_NOTE',
                                           lambda: getattr(self, 'lang', 'KO'))
        self.p2_note_panel.on_changed = lambda: self._update_p2_tab_counts(
            getattr(self, '_p1_verse_id', None))
        self.p2_note_panel.pack(expand=True, fill='both')
        try:
            self.p2_note_panel.set_ai_note(self._ai_note_analysis)
        except Exception as e:                            # noqa: BLE001
            print('[p2 ai note] %s' % e)














    def _apply_tab_pref_of(self, cfg_key, keys):
        """탭 설정 [적용] — **세 화면을 맞추는 한 문**(2026-09-17).

        ⚠ [T] 가 P2 윗줄과 **주요용어 모서리** 두 자리에 있다 — 적용 코드가
          두 벌이면 「여기서 열면 저기가 안 바뀐다」가 난다.
        """
        try:
            if cfg_key == 'P4_NODE_MAIN_TABS':
                npnl = getattr(self, 'p4_node_panel', None)
                if npnl is not None and getattr(npnl, 'tabs', None) is not None:
                    # ★ 표시방식(서브탭/통합탭)까지 함께 — `apply_more_mode` 가
                    #   `set_main` 을 먼저 부른다(P2 와 같은 차례).
                    npnl.apply_more_mode()
            elif cfg_key == 'EB_MAIN_TABS':
                eb = getattr(self, 'entity_browser', None)
                if eb is not None and hasattr(eb, '_apply_tab_prefs'):
                    eb._apply_tab_prefs()
        except Exception as e:
            print('[tab settings apply] %s' % e)


    def _p2_role_ask(self, role):
        """[전문] 「분야 ▾ ▸ AI 에게 … 관점으로 묻기」 — AI 도우미를 지금 구절 · 그 분야 요구사항으로 연다(보내지는 않는다)."""
        vid = getattr(self, '_p1_verse_id', None)
        if not vid:
            return
        try:
            self._ensure_p4_tab_built(self.P4['ai'])
            self.p4_nb.select(self.p4_t13_f)
            v = getattr(self, 'ai_chat_view', None)
            if v is not None:
                v.ask_role_now(int(vid), role)
        except Exception as e:                            # noqa: BLE001
            print('[p2 role ask] %s' % e)

    def _p2_my_edit_click(self):
        """윗줄 [My Edit] — 설명 탭이면 내 설명(덮개 편집), 묵상노트 탭이면 노트 규칙(`_p2_note_my_edit`)."""
        try:
            key = self._p2_tabs.current()
        except Exception:
            key = None
        if key == 'DESC':
            return self._open_p2_overlay_editor()
        return self._p2_note_my_edit()

    def _p2_sync_tools(self, key):
        """윗줄 [M] 을 지금 탭의 사용방법으로 갈아 끼운다([My Edit] 은 늘 있다)."""
        want = getattr(self, '_p2_m_of', {}).get(key)
        for code, ic in getattr(self, '_p2_m_icons', {}).items():
            try:
                if code == want:
                    if not ic.winfo_manager():
                        ic.pack(side='right', padx=(0, 4))
                else:
                    ic.pack_forget()
            except Exception:
                pass

    def _on_p2_tab(self, key):
        """P2 탭 전환 — [M] · 지연 빌드 · 이용통계. 시작 때 첫 선택은 짓지 않는다(첫 페인트 뒤 `_post_paint_build_p2`)."""
        self._p2_sync_tools(key)
        if not getattr(self, '_p2_startup', False):
            self._ensure_p2_tab_built(key)
            try:
                import usage_stats
                usage_stats.screen_hit({'DESC': 'p2_desc', 'NOTE': 'p2_note'}.get(key, 'p2_desc'))
            except Exception:
                pass

    def _ensure_p2_tab_built(self, sel):
        """그 탭의 패널을 처음 한 번 짓고 지금 구절을 읽힌다."""
        infos = getattr(self, '_p2_lazy', {}).get(sel)
        vid = getattr(self, '_p1_verse_id', None)
        for attr, builder in (infos or ()):
            if not hasattr(self, attr):
                builder()
                if vid:
                    try:
                        getattr(self, attr).load(vid)
                    except Exception:
                        pass
        self._p2_sync_tools(sel)

    def _on_p1_tab_change(self, event=None):
        """P1 탭 전환 시 Tab2(묵상플랜) 선택이면 자동 refresh. 직전 탭 저장."""
        if not hasattr(self, 'p1_nb'):
            return
        try:
            self._save_state("last_p1_tab", self.p1_nb.index('current'))
        except Exception:
            pass
        # ── 이용통계: P1 탭 화면 히트 ──
        try:
            import usage_stats
            _sel = self.p1_nb.select()
            for _attr, _code in (('_tab_bible', 'p1_bible'),
                                 ('_tab_reading', 'p1_read'), ('_tab_plan', 'p1_plan'),
                                 ('_tab_mypath', 'mypath'),
                                 ('_tab_announce', 'announce'), ('_tab_feedback', 'inquiry')):
                _w = getattr(self, _attr, None)
                if _w is not None and str(_w) == _sel:
                    usage_stats.screen_hit(_code)
                    break
        except Exception:
            pass
        # 선택된 지연 서브탭이 아직 미빌드면 빌드(시작 시 선택은 페인트 후 빌드가 맡으므로 제외)
        if not getattr(self, '_p1_startup', False):
            try:
                self._ensure_p1_tab(self.p1_nb.nametowidget(self.p1_nb.select()))
            except Exception:
                pass
        try:
            if self.p1_nb.index('current') == self.p1_nb.index(self._tab_plan):
                self._refresh_plan_views()
        except Exception:
            pass
        # ★★ **나의 묵상 탭도 들어올 때마다 다시 읽는다** (2026-08-23 사용자 신고
        #   「즐겨찾기 버튼을 클릭해도 나의묵상 ▸ 즐겨찾기 ▸ 구절 서브탭에 전혀
        #   표시되지 않는다」). 실측 — `user_favorite` 에 VERSE LIVE 48행이 있고
        #   새 인스턴스로 그리면 48행이 다 나온다. **데이터도 화면도 멀쩡했고,
        #   `p1_my_path.refresh()` 를 부르는 곳이 어디에도 없던 것**이 원인이다
        #   (탭은 처음 만들 때 한 번 채우고 그 뒤로 다시 안 채운다) — 그래서
        #   앱을 껐다 켜야만 나타났다.
        #   ⚠ 첫 진입은 바로 위 `_ensure_p1_tab` 이 방금 지은 직후라 한 번 겹쳐
        #     읽는다 — 실측 **28ms** 라 그냥 겹치게 두었다(겹침을 피하려고
        #     「방금 지었나」 깃발을 두면 그 깃발이 또 어긋난다).
        try:
            if (hasattr(self, '_tab_mypath') and hasattr(self, 'p1_my_path')
                    and self.p1_nb.index('current') == self.p1_nb.index(self._tab_mypath)):
                self.p1_my_path.refresh()
        except Exception as e:
            print(f"[mypath refresh] {e}")
        # 공지사항/문의 탭 표시 → 열람 처리(배지 0)
        try:
            if (hasattr(self, '_tab_announce') and hasattr(self, 'p1_announce_view')
                    and self.p1_nb.index('current') == self.p1_nb.index(self._tab_announce)):
                self.p1_announce_view.mark_seen()
            if (hasattr(self, '_tab_feedback') and hasattr(self, 'p1_feedback_view')
                    and self.p1_nb.index('current') == self.p1_nb.index(self._tab_feedback)):
                self.p1_feedback_view.mark_seen()
        except Exception:
            pass

    def _announce_unread_total(self) -> int:
        """공지 + 문의의 미열람 수 — **탭을 짓지 않고** DB 만 읽는다.

        ★ 2026-09-09(0.txt 둘째 8번) — 그전에는 개수를 화면(FeedbackView)이
          알려 줬는데 그 화면은 **탭을 처음 열 때** 지어지고, 여는 순간 열람
          처리가 되어 **배지가 뜰 자리가 없었다**. 시작할 때 여기서 한 번 잰다.
        """
        n = 0
        try:
            import rss_reader as R
            import user_feedback as F
            with appdb.connect(self.db_path) as conn:
                try:
                    n += int(R.unread_announcements(conn, getattr(self, 'lang', 'KO')) or 0)
                except Exception:
                    pass
                try:
                    n += int(F.unread_count(conn) or 0)
                except Exception:
                    pass
        except Exception:
            pass
        return n

    def _refresh_announce_badge(self):
        """탭을 안 짓고 배지만 갱신한다 — 시작할 때·공지를 받은 뒤."""
        try:
            if getattr(self, 'p1_announce_view', None) is not None:
                return                      # 화면이 있으면 그쪽이 정확하다
            self._update_announce_badge(self._announce_unread_total())
        except Exception:
            pass

    def _update_announce_badge(self, count):
        """공지 미열람 수를 탭 제목에 표시: '공지사항 (N)' / 0이면 라벨만."""
        try:
            base = getattr(self, '_announce_base', '공지사항')
            txt = f' {base} ({count}) ' if count else f' {base} '
            self.p1_nb.tab(self._tab_announce, text=txt)
        except Exception:
            pass

    # 갈래 → 묵상플랜 서브탭 번호. ⚠ 번호를 화면 코드에 흩지 않는다(§3 교훈).
    def _open_font_prose(self):
        """통합 폰트 창을 열고 「문장」 줄을 짚어 준다 — 읽는 화면 옆 [Font] 단추."""
        try:
            import font_settings
            return font_settings.open_font_settings(
                self, self.db_path, scope='prose',
                on_change=self._apply_reading_font)
        except Exception as e:
            print(f'[font open] {e}')

    # ★ 묵상플랜 서브탭 — **카테고리가 가른다** (2026-08-16 사용자 지시).
    #   `scope` 로는 못 가른다: 전체읽기·주제읽기·골라담기가 전부 BIBLE 이다.
    #   ⚠ **탭이 늘거나 순서가 바뀌면 이 표 하나만 고친다.** 번호를 화면 코드에
    #     흩지 말 것(§3 P4 탭 번호에서 겪은 함정과 같다).
    # 서브탭마다 제 사용방법(M) — 2026-10-13 76-8
    PLAN_MANUAL = {'TAB_PLAN_WHOLE2': 'U_P1_WHOLE', 'TAB_PLAN_THEME': 'U_P1_THEME',
                   'TAB_PLAN_DIAG': 'U_P1_DIAG',
                   'TAB_PLAN_MINE': 'U_P1_MINE'}
    PLAN_TABS = [
        # (탭 이름 열쇠, 기본 이름, 꼭대기 카테고리, 뺄 카테고리, 뷰 속성)
        ('TAB_PLAN_WHOLE2', '전체읽기',   [1],   [],    'p1_plan_view'),
        # ★ 2026-10-20 docs/1.txt 5-2 — 골라담기 탭을 걷고 셋(성경의 인물·기적·기도)을 주제읽기 안 묶음으로(cat 229~232)
        ('TAB_PLAN_THEME',  '주제읽기',   [2],   [],    'p1_theme_plan_view'),
        ('TAB_PLAN_DIAG',   '회복묵상',   [3],   [],    'p1_diag_plan_view'),
        ('TAB_PLAN_LENS',   '렌즈묵상',   None,  [],    'p1_lens_view'),
        # ★★ 2026-10-15 **내 플랜** — 사용자가 가진 플랜을 모두 한 곳에(만든 것 · 수정한 것 · 받은 것 · 골라 담은 것) ·
        #   새 플랜 만들기 마법사(plan_wizard)는 이 탭 「사용자 모드」 콤보에서 연다.
        ('TAB_PLAN_MINE',   '내 플랜',    ['MINE'], [], 'p1_mine_plan_view'),
        # ★★★ **함께 묵상**(2026-09-08 사용자 「공동체 묵상보기 화면은 별도
        #   제작」 · 「플랜 날자 단위로 처리하는 것이 기본」) — 방을 골라
        #   **그날 읽은 범위 전체**를 놓고 나눈다. P2 묵상노트와 축이 다르다.
        ('TAB_PLAN_ROOM',   '함께 묵상',  None,  [],    'p1_room_view'),
    ]
    # ★★ **도서묵상 탭을 걷었다** (2026-08-30 사용자 판단 — 「도서/설교를
    #   묵상플랜처럼 재구성했다. 따라서 진행상황을 체크할 수 있으므로 도서묵상
    #   탭 자체를 제거해도 된다」 + 「책을 선택한 후에 단순읽기모드와 묵상모드의
    #   갈래를 제공하는 것은 어떨까」).
    #   ⇒ **같은 책을 읽는 자리가 둘이던 것**을 하나로 모았다. 도서묵상 플랜
    #     82개는 그대로 살아 있고, 들어가는 길이 **도서/설교 [묵상플랜]** 으로
    #     바뀌었을 뿐이다(`_open_plan_for_book`).
    #   ⚠ 진행중 플랜은 **도서/설교의 그 편으로** 데려간다(`_book_plan_jump`) —
    #     탭만 없애고 길을 안 놓으면 등록해 둔 플랜이 미아가 된다.
    LENS_TAB_IDX = 4
    # 옛 이름 — `scope` 로 옮기던 자리가 남아 있어 남긴다.
    # ⚠ `BOOK` 은 **일부러 없다** — 갈 탭이 없고 `_plan_tab_of` 가 None 을 돌려
    #   `_plan_scope_jump` 가 도서/설교로 보낸다.
    PLAN_TAB = {'BIBLE': 0, 'DIAG': 2, 'LENS': 4}

    def _plan_tab_of(self, enr):
        """이 등록이 어느 서브탭에 속하나. 못 찾으면 `None`."""
        if not isinstance(enr, dict):
            return self.PLAN_TAB.get(enr)          # 옛 호출 — scope 문자열
        if enr.get('user_plan_id'):               # ★ 내 플랜은 「내 플랜」 탭(2026-10-15)
            for i, t in enumerate(self.PLAN_TABS):
                if t[2] == ['MINE']:
                    return i
        cid, root = enr.get('cat_id'), enr.get('root_cat')
        for i, (_k, _d, roots, hide, _v) in enumerate(self.PLAN_TABS):
            if not roots:
                continue
            if cid in roots:
                return i
            if root in roots and cid not in hide:
                return i
        return self.PLAN_TAB.get(enr.get('scope'))

    def _plan_cat_of_plan(self, plan_id):
        """그 sys 플랜의 (카테고리, 뿌리 카테고리). 못 찾으면 (None, None)."""
        try:
            with appdb.connect(self.db_path) as conn:
                r = conn.execute("SELECT cat_id FROM sys_bible_plan WHERE plan_id=?",
                                 (plan_id,)).fetchone()
                cid = r[0] if r else None
                par = {a: b for a, b in conn.execute(
                    "SELECT cat_id, parent_id FROM sys_plan_category "
                    "WHERE COALESCE(record_status,'LIVE')='LIVE'")}
            root, g = cid, 0
            while root is not None and par.get(root) is not None and g < 12:
                root, g = par[root], g + 1
            return cid, root
        except Exception:
            return None, None

    def _open_route_map(self):
        """묵상경로 지도 팝업 (2026-08-17 설계 확정 — 새 탭 아님).

        경로가 있는 자산을 뿌리로 놓고 「다음 걸음」을 2단까지 편다. 내 진행
        상태를 겹쳐 그린다 — ✓ 완료 · ● 진행중 · ♥ 찜(기호 사전 그대로).
        더블클릭 = 그 자산으로 점프(팝업은 남긴다 — 지도를 보며 오간다).
        """
        import plan_route
        import appdb as _appdb
        win = getattr(self, '_route_map_win', None)
        if win is not None and win.winfo_exists():
            win.lift()
            return
        win = tk.Toplevel(self)
        self._route_map_win = win
        win.title(i18n.t('ROUTE_TITLE', '묵상경로'))
        win.geometry('600x540+%d+%d' % (self.winfo_rootx() + 120,
                                        self.winfo_rooty() + 80))
        try:
            import ui_theme
            ui_theme.adopt(win)
        except Exception:
            pass

        top = ttk.Frame(win)
        top.pack(fill='x', padx=8, pady=(8, 2))
        ttk.Label(top, text=i18n.t(
            'ROUTE_HINT', '✓ 완료   ● 진행중   ♥ 찜  ·  들여쓴 줄 = 다음 단계'
                          '  ·  더블클릭 = 그 화면으로'),
            foreground='#7F8C8D').pack(side='left')

        tv = ttk.Treeview(win, columns=('note',), show='tree headings',
                          selectmode='browse')
        tv.heading('#0', text=i18n.t('ROUTE_COL_ASSET', '자산'))
        tv.column('#0', width=250)
        tv.heading('note', text=i18n.t('ROUTE_COL_NOTE', '다음 단계 안내'))
        tv.column('note', width=300)
        vsb = ttk.Scrollbar(win, orient='vertical', command=tv.yview)
        tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y', padx=(0, 8), pady=(0, 8))
        tv.pack(fill='both', expand=True, padx=(8, 0), pady=(0, 8))

        lang = getattr(self, 'lang', 'KO')
        conn = _appdb.connect(self.db_path)
        try:
            done = {r[0] for r in conn.execute(
                "SELECT DISTINCT plan_id FROM user_plan_enrollment "
                "WHERE enrollment_status='COMPLETED' AND user_plan_id IS NULL "
                "AND record_status='LIVE'")}
            active = {r[0] for r in conn.execute(
                "SELECT DISTINCT plan_id FROM user_plan_enrollment "
                "WHERE enrollment_status='ACTIVE' AND user_plan_id IS NULL "
                "AND record_status='LIVE'")}
            wish = {r[0] for r in conn.execute(
                "SELECT target_id FROM user_favorite WHERE fav_type='PLAN_WISH'"
                " AND COALESCE(source_code,'SYS')='SYS' "
                "AND record_status='LIVE'")}

            def mark(kind, tid):
                if kind != 'PLAN':
                    return ''
                if tid in active:
                    return '● '
                if tid in done:
                    return '✓ '
                if tid in wish:
                    return '♥ '
                return ''

            # ★ 2026-08-24 통합 표(`rel_code='NEXT'`)
            _w, _wa = plan_route._route_filter()
            froms = [(plan_route.KIND_OF.get(a, a), fi)
                     for a, fi in conn.execute(
                         "SELECT DISTINCT substr(link_type,1,instr(link_type,'_')-1), clicked_id "
                         "FROM %s WHERE %s "
                         "  AND COALESCE(record_status,'LIVE')='LIVE' "
                         "ORDER BY 1, 2" % (plan_route.LINK_TBL, _w), _wa)
                     if plan_route._exists(conn,
                                           plan_route.KIND_OF.get(a, a), fi)]
            self._route_map_items = {}

            def insert(parent, kind, tid, note, depth, seen):
                lbl = '%s%s (%s)' % (mark(kind, tid),
                                     plan_route._label(conn, kind, tid, lang),
                                     plan_route.KIND_LABEL.get(kind, kind))
                iid = tv.insert(parent, 'end', text=lbl, values=(note,),
                                open=(depth == 0))
                self._route_map_items[iid] = (kind, tid)
                if depth >= 2:
                    return
                for r in plan_route.routes_from(conn, kind, tid, lang,
                                                limit=6):
                    key = (r['kind'], r['id'])
                    if key in seen:
                        continue
                    insert(iid, r['kind'], r['id'], r['note'],
                           depth + 1, seen | {key})

            for fk, fi in froms:
                # 다른 경로의 「다음 걸음」으로만 나오는 자산은 뿌리로 또 그리지
                # 않는다 — 뿌리 = 어디서도 안 이어져 오는 출발점 + 플랜 전부
                insert('', fk, fi, '', 0, {(fk, fi)})
        finally:
            conn.close()

        def _go(_e=None):
            sel = tv.selection()
            if sel and sel[0] in self._route_map_items:
                k, i = self._route_map_items[sel[0]]
                self._route_jump(k, i)
        tv.bind('<Double-1>', _go)

    def _plan_lens_tab_index(self):
        """렌즈묵상 서브탭 번호 — PLAN_TABS 에서 찾는다(번호 박기 금지)."""
        for i, t in enumerate(self.PLAN_TABS):
            if t[4] == 'p1_lens_view':
                return i
        return len(self.PLAN_TABS) - 1

    def _route_jump(self, kind, tid):
        """묵상경로 「다음 걸음」 클릭 — 자산 종류별로 그 화면으로 (2026-08-17).

        kind: PLAN(플랜 상세) · LENS(렌즈 컨테이너) · BOOK(도서 첫 유닛) ·
        REF(교리자료 첫 유닛). 기존 점프 경로를 전부 재사용한다.
        """
        try:
            if kind == 'PLAN':
                self._ensure_p1_tab(self._tab_plan)
                self.p1_nb.select(self._tab_plan)
                idx, v = self._plan_view_for(tid)
                if hasattr(self, 'p1_plan_nb'):
                    self.p1_plan_nb.select(idx)
                if v is not None and hasattr(v, 'select_plan'):
                    self.after_idle(lambda: v.select_plan(tid, None))
            elif kind == 'LENS':
                self._ensure_p1_tab(self._tab_plan)
                self.p1_nb.select(self._tab_plan)
                if hasattr(self, 'p1_plan_nb'):
                    self.p1_plan_nb.select(self._plan_lens_tab_index())
                if hasattr(self, 'p1_lens_view'):
                    self.after_idle(
                        lambda: self.p1_lens_view.select_container(tid, 'SYS'))
            elif kind == 'BOOK':
                import appdb
                conn = appdb.connect(self.db_path)
                try:
                    r = conn.execute(
                        "SELECT unit_id FROM sys_book_unit WHERE book_id=? "
                        "AND record_status='LIVE' ORDER BY sequence LIMIT 1",
                        (tid,)).fetchone()
                finally:
                    conn.close()
                if r:
                    self._my_path_jump_book(r[0])
            elif kind == 'REF':
                import appdb
                conn = appdb.connect(self.db_path)
                try:
                    r = conn.execute(
                        "SELECT ref_unit_id FROM sys_ref_unit WHERE "
                        "ref_src_id=? AND record_status='LIVE' "
                        "ORDER BY sequence LIMIT 1", (tid,)).fetchone()
                finally:
                    conn.close()
                if r:
                    self._ensure_p1_tab(self._tab_reading)
                    self.p1_nb.select(self._tab_reading)
                    if hasattr(self, 'p1_reading_view') and hasattr(
                            self.p1_reading_view, 'jump_to_doctrine_unit'):
                        self.p1_reading_view.jump_to_doctrine_unit(r[0])
        except Exception as e:
            print('[route jump] %s' % e)

    def _plan_view_for(self, plan_id, scope_raw=None):
        """그 플랜이 사는 (서브탭 번호, PlanMainView). 못 찾으면 (0, 전체읽기).

        ⚠ 예전에는 `scope_raw` 로 골랐다 — 서브탭이 여섯이 되면서
          전체읽기·주제읽기·골라담기가 **전부 BIBLE** 이라 셋이 한 탭으로 몰린다.
        """
        cid, root = self._plan_cat_of_plan(plan_id)
        idx = self._plan_tab_of({'cat_id': cid, 'root_cat': root, 'scope': scope_raw})
        if idx is None:
            idx = 0
        attr = self.PLAN_TABS[idx][4] if idx < len(self.PLAN_TABS) else None
        if attr == 'p1_lens_view':
            return idx, None
        return idx, getattr(self, attr, None) if attr else None

    def _open_wish_list(self):
        """지금 보고 있는 서브탭의 뷰로 후보 팝업을 연다.

        ⚠ 어느 탭에서 열든 **목록은 같다** — 찜은 탭을 가리지 않는다. 고른 플랜이
          다른 탭에 살면 그 탭으로 옮겨 준다(`_on_wish_pick`).
        """
        try:
            idx = self.p1_plan_nb.index('current')
            attr = self.PLAN_TABS[idx][4] if idx < len(self.PLAN_TABS) else None
            v = getattr(self, attr, None) if attr else None
            if v is None or not hasattr(v, 'open_wish_list'):
                # 렌즈묵상 탭 등 — 아무 PlanMainView 로나 연다
                v = next((getattr(self, a, None) for _k, _d, r, _h, a in self.PLAN_TABS
                          if r and getattr(self, a, None) is not None), None)
            if v is not None:
                v.open_wish_list()
        except Exception as e:
            print('[wish popup] %s' % e)

    def _plan_wish_jump(self, w):
        """묵상후보에서 선택한 플랜이 **다른 탭**에 살 때 — 그 탭으로 옮겨 상세를 연다.

        ⚠ `_plan_scope_jump` 를 재활용하면 안 된다 — 그쪽은 **등록번호**를 받아
          Focus 화면을 여는 길이다. 후보는 아직 등록 전이라 번호가 없어
          `_show_focus_mode(None)` 이 불려 **빈 화면**이 떴다(사용자 지적).
        """
        try:
            idx = self._plan_tab_of(w)
            if idx is None:
                return
            self.p1_plan_nb.select(idx)
            attr = self.PLAN_TABS[idx][4] if idx < len(self.PLAN_TABS) else None
            v = getattr(self, attr, None) if attr else None
            if v is None or not hasattr(v, 'select_plan'):
                return
            # ⚠ 탭 전환이 끝난 뒤에 고른다 — 바로 부르면 아직 크기가 1x1 이다
            self.after_idle(lambda: v.select_plan(w.get('plan_id'),
                                                  w.get('user_plan_id')))
        except Exception as e:
            print('[wish jump] %s' % e)

    def _refresh_plan_wishes(self):
        """묵상후보를 여섯 탭에서 함께 새로 그린다 (2026-08-16).

        ⚠ 한 탭에서 찜하고 다른 탭으로 가면 **거기 트리에는 안 보인다** — 찜은
          탭을 가리지 않으므로 목록이 갈리면 안 된다.
        ⚠ 되돌아오는 호출을 막는다 — 각 뷰의 `_refresh_wishes` 가 다시 이것을 부른다.
        """
        if getattr(self, '_in_wish_refresh', False):
            return
        self._in_wish_refresh = True
        try:
            for _k, _d, _r, _h, attr in self.PLAN_TABS:
                v = getattr(self, attr, None)
                if v is not None and hasattr(v, '_load_plans'):
                    try:
                        v._load_plans()      # 후보 마디·★ 표시가 함께 따라온다
                    except Exception as e:
                        print('[wish refresh] %s %s' % (attr, e))
        finally:
            self._in_wish_refresh = False

    def _refresh_plan_views(self):
        """묵상플랜 서브탭을 다시 읽는다 (2026-08-16 서브탭 6개).

        ⚠ 예전에는 `p1_plan_view` 하나만 불렀다. 탭이 여섯이 되면 등록·해제가
          한 탭에만 반영되고 나머지는 옛 상태로 남는다.
        ★ **보이는 서브탭만 즉시, 나머지는 들어올 때** (2026-08-27 「P1 탭
          깜빡」 수리). 여섯을 동기로 다 읽으면 묵상플랜 탭 진입이 매번
          ~230ms 였다(실측). 안 보이는 다섯은 더러움 표시만 남기고, 그
          서브탭에 실제로 들어올 때(`_on_plan_sub_tab_changed`) 읽는다 —
          「등록·해제가 다른 탭에 반영」은 그 시점이면 충분하다.
        """
        cur_attr = None
        try:
            idx = self.p1_plan_nb.index('current')
            if idx < len(self.PLAN_TABS):
                cur_attr = self.PLAN_TABS[idx][4]
        except Exception:
            pass
        self._plan_dirty = set()
        for _k, _d, _r, _h, attr in self.PLAN_TABS:
            v = getattr(self, attr, None)
            if v is None or not hasattr(v, 'refresh'):
                continue
            if cur_attr is not None and attr != cur_attr:
                self._plan_dirty.add(attr)
                continue
            try:
                v.refresh()
            except Exception as e:
                print('[plan refresh] %s %s' % (attr, e))
        # 도서/설교 탭 2단 bar 의 진행중 콤보도 함께 (2026-08-18)
        rb = getattr(getattr(self, 'p1_reading_view', None), '_enr_bar', None)
        if rb is not None:
            try:
                rb.refresh()
            except Exception as e:
                print('[reading enr refresh] %s' % e)

    def _open_plan_for_book(self, plan_id):
        """도서/설교 [묵상플랜] → 묵상플랜 탭에서 그 플랜을 연다 (2026-08-30).

        ⚠ **탭을 짐작하지 않는다** — 플랜의 카테고리를 물어 `_plan_tab_of` 가
          고르게 한다(도서묵상 탭을 걷은 뒤에도 그 표만 고치면 따라온다).
        """
        try:
            cid, root = self._plan_cat_of_plan(plan_id)
            idx = self._plan_tab_of({'cat_id': cid, 'root_cat': root})
            if idx is None:
                idx = 0
            self._ensure_p1_tab(self._tab_plan)
            self.p1_nb.select(self._tab_plan)
            self.p1_plan_nb.select(idx)
            view = getattr(self, self.PLAN_TABS[idx][4], None)
            if view is not None and hasattr(view, 'select_plan'):
                self.after(200, lambda: view.select_plan(plan_id))
        except Exception as e:
            print('[book plan] %s' % e)

    def _book_plan_jump(self, enr):
        """도서묵상 등록 → **도서/설교의 오늘 읽을 편**으로 (2026-08-30).

        도서묵상 탭을 걷었으므로 진행중 플랜이 갈 곳이 여기다.
        ⚠ 잇는 열쇠는 스케줄의 `unit_key`(`BOOK:<unit_id>`) — 도서와 플랜을
          직접 잇는 칸이 없다.
        ⚠ 오늘 몫이 없으면(등록 직후·범위 밖) **첫 편**으로 — 아무 데도 못 가면
          사용자에게는 「눌러도 반응 없음」이다.
        """
        if not isinstance(enr, dict):
            return False
        pid, day = enr.get('plan_id'), enr.get('current_day') or 1
        if not pid:
            return False
        try:
            with appdb.connect(self.db_path) as conn:
                r = conn.execute(
                    "SELECT unit_key FROM sys_plan_schedule"
                    "  WHERE plan_id=? AND stage_type='BOOK_TEXT' AND day=?"
                    "  ORDER BY sort_order LIMIT 1", (pid, day)).fetchone()
                if not r:
                    r = conn.execute(
                        "SELECT unit_key FROM sys_plan_schedule"
                        "  WHERE plan_id=? AND stage_type='BOOK_TEXT'"
                        "  ORDER BY day, sort_order LIMIT 1", (pid,)).fetchone()
            if not r or not r[0]:
                return False
            # ⚠ 열쇠 꼴은 **`BOOK_<unit_id>`** 다(실측 2,872행 전부).
            #   `:` 로 가르려다 `BOOK_1` 을 통째로 int() 에 넣어 터뜨렸다 —
            #   `plan_main_view` 가 쓰는 `SUBSTR(...,6)` 과 같은 자리다.
            uid = int(str(r[0])[5:])
        except Exception as e:
            print('[book plan jump] %s' % e)
            return False
        self._ensure_p1_tab(self._tab_reading)
        self.p1_nb.select(self._tab_reading)
        self.after(200, lambda: self.p1_reading_view.jump_to_unit(uid))
        return True

    def _plan_scope_jump(self, enr_or_scope, enrollment_id):
        """진행중 콤보에서 **다른 갈래** 플랜을 골랐을 때 그 탭으로 옮긴다.

        ★ 2026-08-14 사용자 결정 — 「묵상중 플랜 모두를 표시하라. 탭 이동기능을 넣어라.」
          ⚠ 옮기지 않으면 왼쪽 목록과 오른쪽 본문이 **다른 갈래**가 되어
            지금 무엇을 보는지 알 수 없다.
        ⚠ 첫 인자가 **등록 dict 또는 옛 scope 문자열** 둘 다 올 수 있다 —
          렌즈묵상 탭은 아직 `scope` 를 넘긴다.
        """
        idx = self._plan_tab_of(enr_or_scope)
        if idx is None:
            # ★ 도서묵상 — 탭이 없다. **읽는 화면 그 편으로** 데려간다.
            if self._book_plan_jump(enr_or_scope):
                return
        if idx is None or not hasattr(self, 'p1_plan_nb'):
            return
        try:
            self.p1_plan_nb.select(idx)
            view = self.PLAN_TABS[idx][4] if idx < len(self.PLAN_TABS) else None
            if view == 'p1_lens_view':
                # ★ 렌즈 플랜 — Focus 화면 대신 **그 렌즈를 바로 열고 첫 노드까지**
                #   선택한다 (2026-08-17 사용자 「콤보에서 클릭하면 묵상화면이 즉시
                #   나타나지 않는다」— 예전에는 탭만 바꾸고 돌아가 빈 화면이었다).
                #   plan_code 규칙 `LENS_<container_id>` (db_lens_plan)로 찾는다.
                pid = (enr_or_scope.get('plan_id')
                       if isinstance(enr_or_scope, dict) else None)
                if pid:
                    try:
                        conn = appdb.connect(self.db_path)
                        r = conn.execute(
                            'SELECT plan_code FROM sys_bible_plan WHERE plan_id=?',
                            (pid,)).fetchone()
                        conn.close()
                        code = (r and r[0]) or ''
                        if code.startswith('LENS_'):
                            cid = int(code.split('_')[1])

                            # ⚠ select_container 의 <<TreeviewSelect>> 는 **이벤트
                            #   큐**로 온다 — 바로 노드를 읽으면 목록이 아직 비어
                            #   있다(실측). 한 박자 뒤에 첫 노드를 고른다.
                            def _pick():
                                lvw = self.p1_lens_view
                                kids = lvw._node_tv.get_children('')
                                if kids:
                                    lvw._node_tv.selection_set(kids[0])
                                    lvw._on_node_select(None)

                            def _open(cid=cid):
                                self.p1_lens_view.select_container(cid)
                                self.after(120, _pick)
                            self.after_idle(_open)
                    except Exception as e:
                        print('[lens jump] %s' % e)
                return
            v = getattr(self, view, None) if view else None
            if v is not None:
                # ⚠ 탭 전환이 끝난 뒤에 그린다 — 바로 부르면 아직 크기가 1x1 이다
                self.after_idle(lambda: v._show_focus_mode(enrollment_id))
        except Exception as e:
            print(f'[plan scope jump] {e}')

    def _mine_plans_changed(self, uid=None, jump=False):
        """내 플랜이 생기거나 바뀌었을 때 — 모든 플랜 탭을 다시 읽고(원본 가리기가 바뀌었을 수 있다),
        다른 탭에서 생긴 것이면 「내 플랜」 탭으로 옮겨 그 줄을 고른다(2026-10-15)."""
        mv = getattr(self, 'p1_mine_plan_view', None)
        for t in self.PLAN_TABS:
            v = getattr(self, t[4], None)
            if v is None or v is mv or not hasattr(v, '_load_plans') or t[2] is None:
                continue
            try:
                v._load_plans()
            except Exception as e:
                print('[plan reload] %s' % e)
        if mv is None:
            return
        if jump:
            try:
                idx = next(i for i, t in enumerate(self.PLAN_TABS) if t[2] == ['MINE'])
                self.p1_plan_nb.select(idx)
            except Exception:
                pass
            if uid:
                self.after_idle(lambda: mv._plans_changed(uid))
            else:
                mv._load_plans()
        elif uid is None:
            try:
                mv._load_plans()
            except Exception as e:
                print('[mine reload] %s' % e)

    def _on_plan_day_complete(self):
        """PlanMainView에서 묵상완료 처리 후 진행중 목록 동기화."""
        self._refresh_plan_views()

    # ── 음성 부품 — **누를 때 끌어온다**(2026-09-05) ────────────────
    @property
    def _p1_play_settings(self):
        """재생 설정 — 처음 읽을 때 만든다.

        ⚠ **property 로 둔 까닭** — 이 이름을 읽는 자리가 여럿이라, 각 자리를
          고치면 하나는 반드시 빠진다. 읽는 순간 저절로 만들어지게 한다.
        """
        if self.__ps is None:
            from voice_play_bar import PlaySettings
            self.__ps = PlaySettings()
        return self.__ps

    @property
    def _p1_player(self):
        """재생기 — 처음 재생할 때 만든다(`sounddevice` 를 그때 끌어온다)."""
        if self.__player is None:
            from voice_bible import Player
            self.__player = Player()
        return self.__player

    def _voice_panel(self):
        """음성 성경 패널 — **단추를 눌렀을 때** 만든다.

        ⚠ 예전에는 P2 빌드에서 미리 만들어 `voice_bible_ui` 를 끌어왔다.
          그 한 줄이 시작에 290ms 를 얹고 있었다.
        """
        if getattr(self, 'vb_panel', None) is None:
            from voice_bible_ui import VoiceBiblePanel
            self.vb_panel = VoiceBiblePanel(
                self, db_path=self.db_path,
                lang_getter=lambda: getattr(self, 'lang', 'KO'),
                version_getter=lambda: getattr(self, 'ver', 'KRV'),
                on_restore=self._hide_voice_bible,
            )
        return self.vb_panel

    def _show_voice_bible(self):
        book_name = self.cb_book.get()
        chap_str  = self.cb_chap.get()
        if not book_name or not chap_str:
            return
        bcode = self.book_map.get(book_name)
        if not bcode:
            return
        self._voice_panel().show(bcode, int(chap_str))

    def _hide_voice_bible(self):
        # VoiceBiblePanel._restore() 가 place_forget() 까지 처리함.
        # ★ 2026-10-28 docs/1.txt 1-(3) — 녹음 화면에서 녹음·삭제한 것을 P1 절 번호 표식(초록 밑줄)에 곧바로(장을 다시 그리지 않는다)
        self._p1_refresh_rec_marks()

    def _p1_refresh_rec_marks(self):
        ids = list(getattr(self, '_p1_verse_ids', []) or [])
        ls = getattr(self, 'p1_ls', None)
        if not ids or ls is None or not hasattr(ls, 'set_num_mark'):
            return
        try:
            with appdb.connect(self.db_path) as c:
                rec = {r[0] for r in c.execute(
                    'SELECT DISTINCT verse_id FROM user_voice_asset WHERE verse_id IN (%s) AND COALESCE(has_file,1)=1'
                    % ','.join('?' * len(ids)), ids)}
            for row, di in enumerate(getattr(self, 'p1_idx_map', []) or []):
                if di is not None and di < len(self.p1_data):
                    ls.set_num_mark(row, 'rec', self.p1_data[di][2] in rec)
        except Exception as e:                            # noqa: BLE001
            print('[P1 rec marks] %s' % e)

    def _p1_play_start(self, _next_chapter=False):
        """[▶] — **누른 구절부터** 장 끝까지 읽고, 끝나면 다음 장으로 넘어가 [■] 를 누를 때까지 이어 읽는다.
        ★ 2026-10-13 (docs/1.txt 74-1) — 그전에는 ⓐ 목소리를 [⚙] 에서 고르지 않으면 재생 목록이 비어
          **아무 일도 안 했고**(말도 없이) ⓑ 장 처음부터만 ⓒ 장이 끝나면 멈췄고 ⓓ 읽는 구절 표시가 안 됐다."""
        import queue as _q
        vids = list(getattr(self, '_p1_verse_ids', []) or [])
        if not vids:
            return
        cur = getattr(self, '_p1_verse_id', None)
        if cur in vids:
            vids = vids[vids.index(cur):]
        ver = getattr(self, 'ver', 'KRV')
        ps = self._p1_play_settings
        from voice_play_bar import build_playlist, default_source
        play_ver = ver
        if not ps.owners:                      # 목소리를 안 골랐다 — 이 절들에 녹음이 있는 목소리로
            owner, v2 = default_source(self.db_path, vids, ver)
            if owner:
                ps.owners = [owner]
                play_ver = v2 or ver
        else:
            _o, v2 = default_source(self.db_path, vids, ver)
            if v2 and v2 != ver:
                play_ver = v2
        playlist = build_playlist(self.db_path, vids, play_ver, ps)
        if not playlist:
            self._toast(i18n.t('UM_PLAY_NONE_NEXT', '다음 장에는 녹음이 없어 멈췄습니다.') if _next_chapter else
                        i18n.t('UM_PLAY_NONE', '이 장에는 녹음이 없습니다 — ⏺ 로 녹음하거나 ⚙ 에서 목소리를 선택하세요.'))
            return
        self._play_tok = getattr(self, '_play_tok', 0) + 1
        tok = self._play_tok
        q = self._play_q = _q.Queue()
        self._play_last_vid = vids[-1]
        self._p1_player.play_sequence(
            playlist, gap_sec=ps.gap_sec,
            on_verse_start=lambda v: q.put(('v', v)),
            on_done=lambda: q.put(('done', None)))
        self.after(100, lambda: self._p1_play_pump(tok))

    def _p1_play_pump(self, tok):
        """재생 일꾼이 큐에 넣은 소식을 화면 스레드에서 처리한다(Tk 는 화면 스레드만)."""
        import queue as _q
        if tok != getattr(self, '_play_tok', 0):
            return
        done = False
        try:
            while True:
                kind, v = self._play_q.get_nowait()
                if kind == 'v':
                    self._p1_play_mark(v)
                else:
                    done = True
        except _q.Empty:
            pass
        if not done:
            self.after(150, lambda: self._p1_play_pump(tok))
            return
        # 장 끝 — 다음 장으로 넘어가 이어 읽는다([■] 를 누르면 tok 이 바뀌어 여기 안 온다)
        # ★ 2026-10-25 (docs/1.txt 1-2) 장 통째 ∞ 면 같은 장을 처음부터 다시 · 「자동 다음 장」을 껐으면 멈춘다
        ps = self._p1_play_settings
        if ps.repeat == 0 and getattr(ps, 'repeat_unit', 'VERSE') == 'RANGE':
            first = next(iter(getattr(self, '_p1_verse_ids', []) or []), None)
            if first:
                self._plan_verse_navigate(first)
                self.after(800, lambda: (tok == getattr(self, '_play_tok', 0)) and self._p1_play_start(_next_chapter=True))
            return
        if not getattr(ps, 'auto_next', True):
            return
        try:
            with appdb.connect(self.db_path) as conn:
                r = conn.execute('SELECT MIN(verse_id) FROM bible_index WHERE verse_id > ?'
                                 ' AND (bcode, chapter) <> (SELECT bcode, chapter FROM bible_index WHERE verse_id=?)',
                                 (self._play_last_vid, self._play_last_vid)).fetchone()
            nxt = r[0] if r else None
        except Exception:
            nxt = None
        if not nxt:
            return
        self._plan_verse_navigate(nxt)
        self.after(800, lambda: (tok == getattr(self, '_play_tok', 0)) and self._p1_play_start(_next_chapter=True))

    def _p1_play_mark(self, vid):
        """지금 읽는 구절을 P1 목록에서 고른 줄로 보인다(무거운 구절 따라가기는 안 한다)."""
        if not getattr(self._p1_play_settings, 'highlight', True):
            return
        try:
            for row, idx in enumerate(self.p1_idx_map):
                if idx is not None and self.p1_data[idx][2] == vid:
                    self.p1_ls.selection_clear(0, 'end')
                    self.p1_ls.selection_set(row)
                    self.p1_ls.see(row)
                    break
        except Exception:
            pass

    def _p1_play_stop(self):
        self._play_tok = getattr(self, '_play_tok', 0) + 1     # 장 끝 이어 읽기를 막는다
        if self.__player is not None:
            self.__player.stop()

    def _p1_open_settings(self):
        vids = getattr(self, '_p1_verse_ids', [])
        ver  = getattr(self, 'ver', 'KRV')
        from voice_play_bar import open_play_settings_popup
        open_play_settings_popup(
            self._p1_settings_btn,
            self.db_path, ver, vids,
            self._p1_play_settings,
            on_confirm=lambda s: None,
        )

    def _handle_chain_marker_click(self, vid, chain_codes):
        """P4 캔버스 C 마커 클릭 → 통합 슬라이딩 패널의 동적 탭(연쇄) 표시."""
        if not vid or not chain_codes:
            return
        try:
            self.p4_node_panel.show_chain(vid, chain_codes)
        except Exception as e:
            print(f'[NodePanel show_chain] {e}')

    def _verse_to_p4(self, verse_id):
        """**P1 을 건드리지 않고** 그 구절을 P4 「구절 연결」에서 연다.

        ★★ 2026-08-31 `0.txt` 1번 6) — 사용자 물음 「구절 본문의 내용을 보려면
          P1 탭1로 탭을 바꾸어야 한다 … 혹시라도 대안이 있다면 제안하라」의 답.
          P4 의 NodePanel 이 **본문·설명·주석·자료·노트·링크**를 한 화면에
          담으므로, 도서를 읽던 P1 을 그대로 두고 오른쪽에서 구절을 읽는다.
        ⚠ `_plan_verse_navigate` 와 **일부러 다르다** — 그쪽은 P1 을 그 구절로
          옮긴다(묵상플랜에서는 그것이 맞다). 한 함수로 합치지 말 것.
        """
        if not verse_id:
            return
        try:
            self._select_p4('link')
            self.p4_node_panel.show_node(int(verse_id), None)
        except Exception as e:
            print('[verse to p4] %s' % e)

    def _plan_verse_navigate(self, verse_id):
        """묵상플랜/Focus 오버레이에서 구절 클릭 시 P1 + P4 캔버스로 이동."""
        if not verse_id:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT bcode, chapter FROM bible_index WHERE verse_id=?",
                    (verse_id,)
                ).fetchone()
            if not row:
                return
        except Exception:
            return
        b_code, chap_num = row
        for name, code in self.book_map.items():
            if code == b_code:
                self.cb_book.set(name)
                self.on_book_selected(None)
                break
        self.cb_chap.set(str(chap_num))
        self.on_chapter_selected(None)
        self.update_idletasks()

        found = False
        for list_idx, data_idx in enumerate(self.p1_idx_map):
            if data_idx is not None and self.p1_data[data_idx][2] == verse_id:
                self.p1_ls.selection_clear(0, 'end')
                self.p1_ls.selection_set(list_idx)
                self.p1_ls.see(list_idx)
                found = True
                break

        # 직전 탭으로 복원 (JSON 저장값 사용)
        if hasattr(self, 'p4_nb'):
            self._p4_select_raw(getattr(self, 'last_p4_tab_idx', 0))   # 기본 = 구절 연결(통합 탭)
        self.force_refocus = True
        self.on_verse_selected(is_loading=True, override_verse_id=verse_id)

    # ── [Phase 2-C'] 나의 길 점프 콜백 ──────────────────────────────────
    def _my_path_jump_plan(self, info):
        """묵상 진행중 → P1 탭2 + scope에 맞는 서브탭 + 해당 플랜 진행중 화면 진입."""
        try:
            self._ensure_p1_tab(self._tab_plan); self.p1_nb.select(self._tab_plan)  # P1 탭2 (묵상플랜)
            # ★ **플랜의 카테고리가 탭을 정한다** (2026-08-16 서브탭 6개).
            #   `scope_raw` 로는 전체읽기·주제읽기·골라담기가 한 탭으로 몰린다.
            plan_id     = info.get('plan_id')
            current_day = info.get('current_day') or 1
            idx, target_view = self._plan_view_for(plan_id, info.get('scope_raw'))
            if hasattr(self, 'p1_plan_nb'):
                self.p1_plan_nb.select(idx)
            if target_view and plan_id and hasattr(target_view, 'show_focus_by_plan'):
                target_view.show_focus_by_plan(plan_id, current_day)
        except Exception:
            pass

    def _my_path_jump_book(self, unit_id):
        """독서 진행중 → P1 탭3 + jump_to_unit."""
        if not unit_id:
            return
        try:
            self._ensure_p1_tab(self._tab_reading); self.p1_nb.select(self._tab_reading)  # P1 탭3 (도서/설교)
            if hasattr(self, 'p1_reading_view') and hasattr(self.p1_reading_view, 'jump_to_unit'):
                self.p1_reading_view.jump_to_unit(unit_id)
        except Exception:
            pass

    def _my_path_jump_favorite(self, info):
        """즐겨찾기 → 각 자산 화면으로 점프."""
        ftype = info.get('fav_type')
        tid = info.get('target_id')
        vid = info.get('verse_id')
        try:
            if ftype in ('VERSE', 'COMMENTARY', 'PERICOPE') and vid:
                # 구절·주석·페리코프 — verse_id 기반 P1 점프 (P4 캔버스/P2 탭 자동 갱신)
                self._plan_verse_navigate(vid)
            elif ftype in ('BOOK_UNIT', 'SERMON_UNIT') and tid:
                self._my_path_jump_book(tid)
            elif ftype == 'REF_UNIT' and tid:
                self._ensure_p1_tab(self._tab_reading); self.p1_nb.select(self._tab_reading)
                if hasattr(self, 'p1_reading_view') and hasattr(self.p1_reading_view, 'jump_to_doctrine_unit'):
                    self.p1_reading_view.jump_to_doctrine_unit(tid)
            elif ftype == 'CONTAINER' and tid:
                # 렌즈묵상 컨테이너 → P1 탭2 → 렌즈 서브탭 → 컨테이너 선택
                # ⚠ 서브탭 번호를 박지 않는다 — 6탭 개편 때 3이 도서묵상이 됐다
                #   (2026-08-17 잠복 버그 수정 — PLAN_TABS 에서 찾는다)
                src = info.get('source_code') or 'SYS'
                self._ensure_p1_tab(self._tab_plan); self.p1_nb.select(self._tab_plan)
                if hasattr(self, 'p1_plan_nb'):
                    self.p1_plan_nb.select(self._plan_lens_tab_index())
                if hasattr(self, 'p1_lens_view') and hasattr(self.p1_lens_view, 'select_container'):
                    self.p1_lens_view.select_container(tid, src)
            # ENTITY 등은 향후 확장
        except Exception:
            pass

    def on_verse_selected(self, *args, **kwargs):
        """구절 선택 — ★ 2026-10-13 (docs/1.txt 74-11) 한 번의 처리 동안 DB 연결 하나·같은 계산 한 번
        (`appdb.scope` — 실측 7.8~10초의 절반이 연결 109번 · 같은 링크 계산 11번이었다)."""
        self._verse_memo = {}                       # 이 구절 선택 한 번 동안의 계산 기억(바로·조금 뒤 단계가 나눠 쓴다)
        with appdb.scope(self._verse_memo):
            return self._on_verse_selected_body(*args, **kwargs)

    def _on_verse_selected_body(self, *args, **kwargs):
        """[최종수리] 구절 선택 시 캔버스를 초기화하고 맵 또는 초기 노드를 배치합니다. (SyntaxError 및 폭 연동 해결)"""
        if not hasattr(self, 'p4_view'): return

        # Focus 오버레이 등 외부에서 직접 verse_id를 넘길 때 curselection 우회
        override_vid = kwargs.get('override_verse_id')
        if override_vid:
            new_v_id = override_vid
        else:
            sel = self.p1_ls.curselection()
            if not sel: return
            idx = self.p1_idx_map[sel[0]]
            if idx is None: return
            new_v_id = self.p1_data[idx][2]

        if hasattr(self, 'active_node_id') and self.active_node_id == new_v_id:
            if not kwargs.get('is_loading'):
                # ★ 2026-10-07 (51-3) — 같은 구절을 다시 눌렀다 = 그 구절로 다시 거른다
                #   (X·칩으로 풀었던 연구노트·온라인영상 거르개를 다시 건다).
                try:
                    self._p4_verse_follow(int(str(new_v_id).split(':')[-1]))
                except Exception:
                    pass
                return

        self.active_node_id = new_v_id
        self._save_state("last_verse_id", new_v_id)

        pure_root_id = int(str(new_v_id).split(':')[-1] if ':' in str(new_v_id) else new_v_id)
        self._p1_verse_id = pure_root_id
        # ★ 317차 — 시작할 때 복원한 구절은 「사람이 고른 것」이 아니다(AI 도우미는 Free 로 시작)
        # ★ 2026-10-13 (74-11) — **눈에 보이는 엔티티 줄을 맨 먼저** 그리고 화면에 내보낸다
        #   (그전에는 P4 따라가기·P2·배지를 다 채운 뒤 맨 끝이었다).
        self._refresh_entity_ticker(pure_root_id)
        try:
            self.update_idletasks()
        except Exception:
            pass
        _follow = not kwargs.get('is_loading')
        if _follow:
            self._ai_picked_vid = pure_root_id
            self._ai_follow_verse(pure_root_id)
            # ★ 2026-10-13 (74-11) — P4 따라가기(주석·역본비교·연구노트·영상 거르개·배지)는 **화면이 먼저 그려진 뒤**
            #   (`_schedule_p4_follow`) — 그 사이 다른 구절을 누르면 앞의 일은 버린다.
            self._schedule_p4_follow(pure_root_id)
        self._refresh_verse_fav_btn()
        self._add_recent_verse(pure_root_id)
        # P2 DESC 탭 — P1 클릭 시점에만 갱신 (페리코프+VERS_DESC+질문+기도)
        self._update_p1_desc(pure_root_id)
        if getattr(self, 'p2_note_panel', None):
            self.p2_note_panel.load(pure_root_id)
        self._update_p2_tab_counts(pure_root_id)
        if not _follow:                            # 따라가기가 배지까지 한다(같은 일을 두 번 하지 않는다)
            self._update_p4_badges(pure_root_id)   # ★ 51-4 — P4 탭 머리 배지
        # 온라인 영상 탭의 「연결된 영상」 갈래도 따라온다 (탭이 지어져 있을 때만).
        # ⚠ 그 갈래가 아니면 아무 일도 안 한다 — 어린이 영상을 보다 절을 바꿔도 안 끊긴다.
        if getattr(self, 'kids_view', None):
            try:
                self.kids_view.set_verse(pure_root_id)
                # ★★ **Focus 가 지금 절을 말한다**(2026-09-10 0.txt 1-(1)
                #   배치). 라벨만 만들어 두고 **부르는 곳이 없어** 늘 비어
                #   있었다(실측으로 잡았다 — `unwired.md` 그 자리).
                import db_media_range as _mr
                with appdb.connect(self.db_path) as _c:
                    # ★ Focus 라벨은 걷었다(1.txt 5-2) — 약명만 넘긴다.
                    #   그 글은 **P2 에서 들어왔을 때만** 오른쪽 줄에 보인다.
                    self.kids_view.set_focus_label(_mr.ref(_c, pure_root_id))
            except Exception:
                pass
        # 역본 비교 탭이 빌드돼 있으면 현재 절로 즉시 갱신(탭9 보는 중 다른 절 클릭 시 live 반영)
        #   ⚠ 따라가기가 할 때는 건너뛴다(같은 일을 두 번 하지 않는다 — 74-11)
        if not _follow and getattr(self, 'version_compare_view', None):
            try:
                self.version_compare_view.load(pure_root_id)
            except Exception:
                pass
        # ★★ **[Lexicon] 도 절을 따라온다** (2026-09-24 사용자 「다른 구절을
        #   클릭하면 엔티티가 자동으로 업데이트 되는 것처럼 … Lexicon 버튼을
        #   새로 누른 것처럼 자동 리프레시」).
        #   ⚠ **낱말 칸을 켜 둔 때만** 한다 — 검색으로 용어를 찾아 읽는 중에
        #     절을 옮겼다고 그 화면을 낱말 목록으로 갈아 끼우면 보던 것을 잃는다
        #     (온라인 영상 탭이 「연결된 영상 갈래일 때만」 따라오는 것과 같은 규칙).
        if not _follow:                            # 따라가기가 한다(74-11)
            self._sync_lexicon(pure_root_id)
        # ★★ My Edit 창이 **앱을 따라온다** (2026-08-27 사용자 신고 「기준
        #   구절 바꾸어도 목록에 변화없다. 지금 연결된 구절이 그대로다」).
        #   창을 열어 둔 채 P1 에서 절을 옮기면 창은 옛 절에 머물렀다 —
        #   창 안에서 기준을 바꾸는 길만 있고 **밖에서 바뀌면 안 따라오는**
        #   반쪽 배선이었다. 창이 살아 있으면 새 기준으로 다시 그린다.
        #   ⚠ 미저장 수정이 있으면 `set_anchor` 가 먼저 묻는다(그 문을 그대로
        #     쓴다 — 여기서 조용히 덮으면 쓰던 글이 날아간다).
        try:
            _oc = getattr(self, '_overlay_center_win', None)
            if _oc is not None and _oc.winfo_exists():
                _oc.set_anchor(pure_root_id)
        except Exception:
            pass
        # ★ 패키지 주방도 따라온다 — 단, **구절 출발지일 때만**(용어·렌즈를
        #   잡고 있는데 절을 옮겼다고 기준을 뺏으면 하던 일이 끊긴다).
        try:
            _me = getattr(self, '_my_edit_win', None)
            if _me is not None and _me.winfo_exists() and _me.kind == 'VERSE':
                _me.set_anchor('VERSE', pure_root_id)
        except Exception:
            pass

        self.p4_view.clear_all()
        self._refresh_map_switcher_list()

        vid_node_root = f"BIBLE:{pure_root_id}"
        restored = False   # 저장맵 복원 여부 — 복원 시 사후 재전개(clear_sibling) 금지
        _pg_metas = {}     # 복원 상한이 자른 부모들의 묶음표

        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                # ★ 자동 복원은 **AUTO 전용** (2026-08-20 사용자 확정 — AUTO=하던
                #   작업 이어가기 / MANUAL=보존본은 목록에서 명시적으로 열 때만.
                #   예전 「종류 무관 최신」은 수동맵·⚑핀 스냅샷까지 후보라
                #   언제 무엇이 복원될지 예측이 안 됐다).
                sql = ("SELECT path_string, map_name, full_structure FROM user_saved_maps "
                       "WHERE root_id=? AND save_type='AUTO' ORDER BY updated_at DESC LIMIT 1")
                row = conn.execute(sql, (pure_root_id,)).fetchone()

                if row and row['full_structure']:
                    # is_saved=True 는 '저장본을 띄웠다'(글자 색) — AUTO 는 수동 아님
                    self._update_ui_status_labels("AUTO 저장본", True, is_manual=False)
                    restored = True
                    
                    struct = json.loads(row['full_structure'])
                    self.current_journey_list = row['path_string'].split('|') if row['path_string'] else [self.generate_node_view_id(vid_node_root, None)]
                    # ★ 복원도 표시 상한을 탄다 (2026-08-27 — _restore_cap_struct)
                    _drop, _pg_metas = self._restore_cap_struct(struct)

                    for vid, info in struct.items():
                        if vid in _drop:
                            continue
                        v_t, v_n = self._split_logic_id(info['node_id'])
                        p_id = info.get('p_id')
                        
                        rel_label = ""
                        if p_id and v_t == 'BIBLE':
                            p_pure = p_id.split('@')[0].split(':')[-1]
                            # 병합 헬퍼 — 복원 라벨이 펼침 경로와 같아야 한다 (2026-08-20)
                            rel_label = self._rel_labels_between(conn, p_pure, v_n)

                        b_count = self._get_child_count(v_n, v_t, parent_id=p_id, conn=conn)
                        v_txt = self._truncate_text(self._get_bible_text_for_p4(v_n)) if v_t == 'BIBLE' else ""

                        self.p4_view.add_enhanced_node(
                            p_id, vid, info['node_id'], self.get_asset_name(v_n, v_t), v_txt,
                            info['x'], info['y'], v_t, badge_count=b_count,
                            rel_label=rel_label
                        )

                else:
                    self._update_ui_status_labels(i18n.t('UM_INITSTATUS', '초기화 상태'), False, is_manual=False)
                    vid_view = self.generate_node_view_id(vid_node_root, None)
                    b_count = self._get_child_count(pure_root_id, 'BIBLE', parent_id=None)
                    v_txt = self._truncate_text(self._get_bible_text_for_p4(pure_root_id))

                    self.p4_view.add_enhanced_node(None, vid_view, vid_node_root,
                                                   self.get_asset_name(pure_root_id, 'BIBLE'),
                                                   v_txt, 0, 0, 'BIBLE',
                                                   badge_count=b_count)
                    self.current_journey_list = [vid_view]
                    self.handle_p4_node_click(pure_root_id, 'BIBLE', 0, 0, vid_view, auto_save=False)
                    self._update_desc_tab(vid_view)
        except Exception as e:
            print(f"❌ Selection Error: {e}")

        self.p4_view.redraw_edges()
        self._refresh_all_badges()      # 복원·초기 배치 뒤에도 배지 뜻을 통일
        if restored:
            self._apply_restore_page_badges(_pg_metas)
        self._update_journey_ticker()

        if hasattr(self, 'current_journey_list') and self.current_journey_list:
            last_vid = self.current_journey_list[-1]
            if last_vid in self.p4_view.nodes:
                # ★★ 재전개를 없앴다 (2026-08-27 사용자 신고 「캔버스 옵션값이
                #   작동하지 않고 구절이 여러 개 표시된다」).
                #   비복원 가지는 위(§초기 배치)에서 **이미 뿌리를 펼쳤는데**
                #   여기서 같은 뿌리를 또 펼치고 있었다. 옛날에는 두 번째 호출이
                #   「화면에 있는 것 제외」 필터에 걸려 0건이라 안 보였지만,
                #   표시 상한(2026-08-26 ③)이 생기자 두 번째 호출이 **남은 것들의
                #   다음 묶음**을 더 그렸다 — 상한 3에 6개. 잠복 이중 호출이
                #   상한 기능으로 드러난 것이다.
                #   (복원 가지의 재전개 금지는 2026-08-20 에 이미 했다 — 이제
                #   양쪽 다 재전개하지 않으니 조건이 필요 없다.)
                self._update_desc_tab(last_vid)

        # 구절연결 탭을 보는 중이면 트리뷰도 새 캔버스에 맞춘다.
        # ⚠ 2026-08-20 까지 이 조건이 **리포트 탭**이었다 — 트리뷰가 그 탭에 있던
        #   시절의 잔재라, 트리뷰를 보며 P1 구절을 눌러도 트리가 안 따라왔다.
        if hasattr(self, 'p4_nb') and self.p4_nb.index("current") == self.P4['link']:
            self.after(120, self._sync_p4_tree_from_canvas)

        self.after(100, self._focus_home)
        # ★ **연결이 없으면 그렇다고 말한다** (2026-08-16 사용자 지적 「캔버스가
        #   빈 화면이다 — p1구절과 자동연결되지 않는 것 같다」).
        #   ⚠ 실측하니 **배선은 멀쩡했다.** 구절연결이 있는 절이 31,104 중 **2,011(6.5%)**
        #     뿐이라, 아무 절이나 고르면 94%는 그릴 것이 자기 자신뿐이다.
        #     ⇒ 고장이 아니라 **아직 없는 것**이다. 빈 캔버스는 그 둘을 구분해 주지 않는다.
        self.after(150, self._canvas_empty_hint)

    def _canvas_empty_hint(self):
        """구절연결이 하나도 없으면 캔버스 한가운데에 한 줄로 알린다."""
        try:
            cv = getattr(self, 'p4_view', None)
            if cv is None or not cv.winfo_exists():
                return
            cv.delete('EMPTY_HINT')
            if len(getattr(cv, 'nodes', {}) or {}) > 1:
                return                      # 그릴 것이 있다 — 안내하지 않는다
            w = max(cv.winfo_width(), 200)
            h = max(cv.winfo_height(), 120)
            import ui_theme
            cv.create_text(w // 2, h // 2 + 40, tags=('EMPTY_HINT',),
                           fill=ui_theme.C('fg_dim'), justify='center',
                           text=i18n.t('P4_NO_LINK',
                                       '이 구절에는 아직 연결된 구절이 없습니다.' + chr(10) +
                                       '연결이 있는 구절을 선택하면 여기에 관계가 펼쳐집니다.'))
        except Exception as e:
            print('[canvas hint] %s' % e)

    def generate_node_view_id(self, node_id, p_view_id=None):
        """[근본해결] 부모와 자신의 관계를 신분증으로 사용하여 드래그 무결성과 멀티패스를 동시에 해결합니다."""
        # 부모ID를 신분증 뒤에 고정 주소(@)로 붙입니다.
        p_tag = str(p_view_id) if p_view_id else "ROOT"
        return f"{node_id}@{p_tag}"

    def _restore_journey_ticker_from_list(self, path_list):
        """[기능] DB에서 불러온 여정 리스트를 티커 창에 순서대로 재건합니다."""
        if hasattr(self, 'p4_ticker_box') and self.p4_ticker_box.winfo_exists():
            self.p4_ticker_box.config(state='normal')
            self.p4_ticker_box.delete('1.0', tk.END) # 기존 티커 초기화
            for name in path_list:
                if name.strip():
                    now = datetime.now().strftime("%H:%M:%S")
                    self.p4_ticker_box.insert('end', f"[{now}] {name}\n")
            self.p4_ticker_box.see('end')
            self.p4_ticker_box.config(state='disabled')

    def _is_hidden_asset(self, v_num, v_type, conn):
        """[신규] 특정 자산이 DB에서 HIDE 상태인지 즉시 확인합니다."""
        if v_type == 'BIBLE': return False # 성경 구절은 기본적으로 HIDE 정책 없음
        
        # 타입에 따라 테이블과 PK 컬럼 결정
        table = "sys_unit_asset" if v_type == 'CONTAINER' else "user_unit_asset"
        pk_col = "sys_unit_id" if v_type == 'CONTAINER' else "user_unit_id"
        
        try:
            row = conn.execute(f"SELECT record_status FROM {table} WHERE {pk_col}=?", (v_num,)).fetchone()
            return row and row['record_status'] == 'HIDE'
        except: return False

    def _hunt_fresh_children_optimized(self, conn):
        """[수리] _f_ 구분자를 _v로 교체하여 최신 노드뷰 체계와 동기화합니다."""
        has_new = False
        existing_inst_ids = set(self.p4_view.nodes.keys())
        
        for inst_id in list(self.p4_view.nodes.keys()):
            # 🎯 [수리] _f_ 대신 _v를 사용하여 논리 파트 추출
            logical_part = inst_id.split('_v')[0]
            v_t, v_n = self._split_logic_id(logical_part)
            
            # 해당 노드에 연결된 최신 자식들 사냥
            fresh_links = self._fetch_links_integrated(v_n, v_t)
            for i, L in enumerate(fresh_links):
                c_inst_id = f"{L['target_type']}:{L['target_id']}_f_{inst_id}"
                
                # 🎯 [NEW 발견] 캔버스 장부에 없는 새로운 자식 발견 시 자동 배치
                if c_inst_id not in existing_inst_ids:
                    p_info = self.p4_view.nodes[inst_id]
                    nx, ny = self._calculate_layout_pos("VERTICAL", i, len(fresh_links), p_info['x'], p_info['y'])
                    
                    c_name = self.get_asset_name(L['target_id'], L['target_type'])
                    c_txt = self._truncate_text(self._get_bible_text_for_p4(L['target_id'])) if L['target_type'] == 'BIBLE' else ""
                    
                    self.p4_view.add_enhanced_node(inst_id, c_inst_id, c_name, c_txt, nx, ny, L['target_type'])
                    existing_inst_ids.add(c_inst_id)
                    has_new = True
        return has_new

    def _get_bible_label_direct(self, v_id, v_num=None, conn=None):
        """[원상복구] 시그니처를 처음으로 되돌리고 JOIN 쿼리로만 무결하게 사냥합니다.

        ★ `conn` — 목록 하나를 그리며 수십 번 부르는 자리(Maps 팝업)가 연결을
          재사용한다 (2026-09-01 0.txt 3번 — 연결 여닫이가 느림의 뿌리였다)."""
        try:
            import contextlib
            with (appdb.connect(self.db_path) if conn is None
                  else contextlib.nullcontext(conn)) as conn:
                # 🎯 [철칙] 어떠한 분기 없이 DB 데이터(self.lang)에만 의존합니다.
                sql = """
                    SELECT bn.short_name, bi.chapter, bi.verse 
                    FROM bible_index bi 
                    JOIN book_names bn ON bi.bcode = bn.book_code 
                    WHERE bi.verse_id = ? AND bn.lang_code = ?
                """
                row = conn.execute(sql, (v_id, self.lang)).fetchone()
                if row:
                    # ★ 표기는 `verse_ref` 가 정한다 (2026-08-21 사용자 —
                    #   「계 3:13 이 아니라 계3:13」). 여기서 손으로 한 칸을
                    #   넣고 있어서 그 규칙 밖에 있었다.
                    #   ⚠ 라틴 약명은 한 칸 띄운다(`Gen 1:1`) — 붙이면 안 읽힌다.
                    return verse_ref.label(verse_ref.SCOPE_BOOK,
                                           row[0], row[1], row[2])
        except: pass
        return f"V{v_id}"

    def _get_bible_full_info(self, v_id):
        """[신설] 대시보드 포스트잇용: 레이블과 본문을 한 번에 사냥합니다."""
        label = self._get_bible_label_direct(v_id)
        conn = appdb.connect(self.db_path)
        # ★ 「본문 없음」으로 끝내지 않는다 — 까닭과 빌려 온 본문을 함께
        d = _vt.resolve(conn, v_id, self.ver, self.lang)
        conn.close()
        return {'label': label, 'text': d['text']}

    def create_tab(self, notebook, title):
        """[수리] 탭 생성 시 필요한 ScrolledText 위젯 배선"""
        frame = tk.Frame(notebook, bg="#FFFFFF")
        notebook.add(frame, text=title)
        txt = scrolledtext.ScrolledText(frame, font=("Malgun Gothic", 10), bd=0)
        txt.pack(expand=True, fill='both', padx=5, pady=5)
        return txt

    def get_asset_name(self, tid, u_type):
        """[수리] 사용자의 편집(UPDATE), 신규(NEW), 숨김(HIDE)을 완벽히 반영하여 최종 이름을 반환합니다."""
        # 🎯 타입 규격화: UI의 'CONT'를 자산맵 표준인 'CONTAINER'로 정밀 조준합니다.
        if u_type == 'BIBLE': return self._get_bible_label_direct(tid)
        db_type = 'CONTAINER' if u_type == 'CONT' else u_type
        try:
            with appdb.connect(self.db_path) as conn:
                # ★ **번호가 겹친다** (2026-08-20 실측으로 잡은 잠복 버그).
                #   `sys_unit_asset.sys_unit_id` 와 `user_unit_asset.user_unit_id`
                #   는 서로 다른 번호 흐름이라 **우연히 같은 값**이 존재한다
                #   (지금 2건 — sys 15「해가 필요 없는 성」 ↔ 내 노드 15「111」).
                #   옛 코드는 `user_unit_id = ? OR origin_id = ?` 로 물어서
                #   **남의 번호를 자기 이름으로 덮어썼다** — 캔버스에 「111」이
                #   떴다. 사용자 플랜 iid 에서 겪은 것과 같은 계열의 함정.
                #   ⇒ 순서: ① 진짜 수정본(origin_id) ② sys 원본
                #           ③ 사용자 전용 유닛(sys 에 그 번호가 없을 때만)
                u_row = conn.execute(
                    "SELECT unit_name_sid, record_status FROM user_unit_asset "
                    "WHERE origin_id = ? AND unit_type = ?", (tid, db_type)).fetchone()
                if u_row:
                    if u_row[1] == 'HIDE':
                        return None                     # [상태] 숨김 처리
                    if u_row[0]:
                        return u_row[0]
                s_row = conn.execute(
                    "SELECT unit_name_sid FROM sys_unit_asset "
                    "WHERE sys_unit_id=? AND unit_type=?", (tid, db_type)).fetchone()
                if s_row and s_row[0]:
                    return s_row[0]
                o_row = conn.execute(
                    "SELECT unit_name_sid, record_status FROM user_unit_asset "
                    "WHERE user_unit_id = ? AND unit_type = ?", (tid, db_type)).fetchone()
                if o_row:
                    if o_row[1] == 'HIDE':
                        return None
                    if o_row[0]:
                        return o_row[0]
                return f"Unknown {u_type}({tid})"
        except: return f"Error({tid})"


    def _create_empty_notice(self):
        """[수리] AttributeError 해결: 데이터 부재 알림"""
        f = tk.Frame(self.p4_strip_frame, width=300, height=150, bg="#F9F9F9")
        f.pack(side='left', padx=10)
        tk.Label(f, text=i18n.t('UM_NODESC','설명(DESC) 데이터가 없습니다.'), bg="#F9F9F9", fg="#999999").place(relx=0.5, rely=0.5, anchor='center')

    def _execute_7way_match(self, asset_id):
        """[철칙] sys_text_id 스키마 완벽 준수 - 신분 통합 정밀 사냥"""
        conn = appdb.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        
        # 🎯 [수리] sys_text_id와 user_text_id를 각각 정확히 호출하여 통합
        sql = """
            SELECT * FROM (
                SELECT user_text_id AS text_id, clicked_id, text_type, contents, 'USER' AS src 
                FROM user_text_asset WHERE record_status != 'HIDE'
                UNION ALL
                SELECT sys_text_id AS text_id, clicked_id, text_type, contents, 'SYS' AS src 
                FROM sys_text_asset 
                WHERE COALESCE(record_status,'LIVE')='LIVE'
                  AND sys_text_id NOT IN (SELECT origin_id FROM user_text_asset WHERE origin_id IS NOT NULL)
            ) WHERE (clicked_id = ? 
               OR clicked_id IN (SELECT origin_id FROM user_unit_asset WHERE user_unit_id = ?)
               OR clicked_id IN (SELECT user_unit_id FROM user_unit_asset WHERE origin_id = ?)
               OR clicked_id IN (SELECT origin_id FROM user_link_asset WHERE user_link_id = ?)
               OR clicked_id IN (SELECT user_link_id FROM user_link_asset WHERE origin_id = ?)
               OR clicked_id IN (SELECT origin_id FROM user_text_asset WHERE user_text_id = ?)
               OR clicked_id IN (SELECT user_text_id FROM user_text_asset WHERE origin_id = ?)
            ) AND text_type LIKE '%_DESC%'
            ORDER BY text_id ASC
        """
        try:
            rows = conn.execute(sql, [asset_id] * 7).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def _sync_desc_height_by_mode(self):
        """[수리] PanedWindow 참조를 제거하고 독립 프레임의 높이를 직접 조절합니다."""
        if not hasattr(self, 'p4_desc_panel'): return
        
        is_focus = not getattr(self, 'top_pw', tk.Frame()).winfo_ismapped() if hasattr(self, 'top_pw') else False
        mode_key = "p4_desc_h_focus" if is_focus else "p4_desc_h_normal"
        saved_h = int(self._load_state(mode_key, 200))
        
        try:
            # 🎯 p4_t1_pw 참조를 삭제하고 직접 height를 설정합니다.
            self.p4_desc_panel.config(height=saved_h)
            self.update_idletasks()
        except Exception as e:
            print(f"DEBUG: Sync Error - {e}")

    def _get_combined_dashboard_content(self, a_id, a_type):
        """[신설] 성경 본문과 7-Way 매치 자산을 하나로 결합하여 통합 텍스트를 생성합니다."""
        label = self.get_asset_name(a_id, a_type)
        header = f"[통합 분석] {label}\n" + "="*50 + "\n\n"

        # 성경 본문과 연관 설명(7-Way Match)을 하나의 패키지로 구성
        bible_text = f"[본문]\n{self._get_bible_text_for_p4(a_id)}\n\n" if a_type == 'BIBLE' else ""
        
        desc_text = "[연관 설명]\n"
        descriptors = self._execute_7way_match(a_id)
        if descriptors:
            for d in descriptors:
                desc_text += f"▶ {d['text_type']} ({d['src']}):\n{d['contents']}\n\n"
        else:
            desc_text += "정보가 없습니다.\n"

        return header + bible_text + desc_text

    # (구) _delete_selected_map — P1 맵 콤보 ✕ 버튼의 짝이었다. 콤보와 함께
    # 2026-08-20 폐지. 맵 삭제는 MapManager(Manage Maps 팝업)가 맡는다.

    # ── [Focus]/[Restore] — **P4 탭 전부** (2026-08-31 `0.txt` 1-3) ──────────
    #
    # ★★★ 사용자 지시 「캔버스 버튼의 바로 왼쪽에 배치하라. **다른 탭도 모두
    #   이 자리에**」. 접는 것은 P1·P2 이므로 **기능은 P4 전체의 것**인데
    #   단추는 탭 0 에만 있었다 — 다른 탭에서는 넓게 볼 길이 없었다.
    # ⚠⚠ **노트북 위에 공통 띠를 두는 안은 반려됐다**(「상식 밖의 장소에
    #   배치했다. 당장 제거하라」). 그러므로 **탭마다 제 띠의 왼쪽 끝**에 둔다 —
    #   탭 0 에서 캔버스 단추 바로 왼쪽인 것과 같은 자리다.
    # ⚠ **Tk 는 위젯을 다른 부모로 옮겨 심을 수 없다** — 한 쌍을 돌려쓸 수
    #   없으므로 탭마다 한 쌍을 짓고 상태만 함께 맞춘다(`_p4_focus_pairs`).
    # ⚠ 띠를 **찾아서** 붙인다 — 일곱 화면의 코드를 각각 고치면 새 탭이 늘 때
    #   빠진다. 실측: P4 탭 1~7 은 전부 `탭프레임 ▸ 첫 자식 ▸ 첫 자식` 이
    #   높이 32px 짜리 제 띠다.
    def _p4_tab_bar(self, idx):
        """그 탭의 위쪽 띠(없으면 None).

        ★ 화면이 `_p4_focus_bar` 속성으로 띠를 **직접 지정**할 수 있다
          (2026-09-02 — 주요용어 탭이 전폭 bar 를 걷고 머리띠를 왼쪽 기둥
          안으로 내렸다. 「첫 자식의 첫 자식」 규칙으로는 그 띠를 못 찾는다)."""
        try:
            w = self.nametowidget(self.p4_nb.tabs()[idx])
            for _ in range(2):
                hb = getattr(w, '_p4_focus_bar', None)
                if hb is not None:
                    return hb
                ch = w.winfo_children()
                if not ch:
                    return None
                w = ch[0]
            hb = getattr(w, '_p4_focus_bar', None)
            if hb is not None:
                return hb
            return w if isinstance(w, tk.Frame) else None
        except Exception:
            return None

    def _attach_p4_focus(self, idx):
        """그 탭 띠의 **맨 왼쪽**에 [Focus]/[Restore] 한 쌍. 멱등."""
        pairs = getattr(self, '_p4_focus_pairs', None)
        if pairs is None:
            pairs = self._p4_focus_pairs = {}
        if idx in pairs or idx == self.P4.get('link', 0):
            return                     # 탭 0 은 `_build_link_switch_bar` 가 짓는다
        bar = self._p4_tab_bar(idx)
        if bar is None:
            return
        try:
            f = tk.Button(bar, text=i18n.t('UM_FOCUS', 'Focus'),
                          command=self.activate_p4_focus_mode, **ui_theme.focus_kw())
            r = tk.Button(bar, text=i18n.t('UM_RESTORE', 'Restore'),
                          command=self.deactivate_p4_focus_mode,
                          **ui_theme.focus_kw(restore=True))
            kids = [k for k in bar.winfo_children() if k not in (f, r)]
            kw = dict(side='left', padx=(4, 2), pady=2)
            if kids:
                kw['before'] = kids[0]     # 늘 맨 왼쪽 — 나중에 지어도 앞자리
            pairs[idx] = (f, r, kw)
            (r if getattr(self, 'is_p4_focused', False) else f).pack(**kw)
            ui_theme.paint(bar)
        except Exception as e:
            print('[p4 focus %s] %s' % (idx, e))

    def _rail_p4_focus(self, host):
        """왼쪽 탭 막대 맨 위의 P4 [Focus]/[Restore] 한 쌍 — 탭 줄 칸과 함께 뒤집힌다."""
        f = tk.Button(host, text=i18n.t('UM_FOCUS', 'Focus'),
                      command=self.activate_p4_focus_mode, **ui_theme.focus_kw())
        r = tk.Button(host, text=i18n.t('UM_RESTORE', 'Restore'),
                      command=self.deactivate_p4_focus_mode,
                      **ui_theme.focus_kw(restore=True))
        kw = dict(side='left', padx=(4, 2), pady=2)
        pairs = getattr(self, '_p4_focus_pairs', None)
        if pairs is None:
            pairs = self._p4_focus_pairs = {}
        pairs['rail'] = (f, r, kw)
        (r if getattr(self, 'is_p4_focused', False) else f).pack(**kw)

    def _sync_p4_focus_btns(self, focused):
        """탭마다 지어 둔 쌍을 **함께** 뒤집는다 — 한 탭에서 접고 다른 탭으로
        가면 거기서 풀 수 있어야 한다."""
        for f, r, kw in getattr(self, '_p4_focus_pairs', {}).values():
            self._focus_swap(f if focused else r, r if focused else f, kw)

    def activate_p4_focus_mode(self):
        """[수정] 캔버스 확장 시 버튼을 Restore로 교체하여 복구 경로를 확보합니다."""
        if hasattr(self, 'top_pw'): self.v_pw.forget(self.top_pw)

        # 🎯 버튼 스왑 로직 (사라진 Restore 버튼 복구)
        if hasattr(self, 'btn_focus') and hasattr(self, 'btn_restore'):
            self._focus_swap(self.btn_focus, self.btn_restore, self.FOCUS_FILL)
        self._sync_p4_focus_btns(True)
        self.is_p4_focused = True

    def deactivate_p4_focus_mode(self):
        """[수정] 캔버스 환원 시 버튼을 Focus로 복구합니다."""
        if hasattr(self, 'top_pw'):
            h = getattr(self, 'p1_height', 350)
            self.v_pw.add(self.top_pw, height=h, before=self.p4_host,
                          minsize=PANE_MIN)

        # 🎯 버튼 복구 로직
        if hasattr(self, 'btn_focus') and hasattr(self, 'btn_restore'):
            self._focus_swap(self.btn_restore, self.btn_focus, self.FOCUS_FILL)
        self._sync_p4_focus_btns(False)
        self.is_p4_focused = False

    # 🎯 [캔버스 배치 규격 사용자 설정 팝업창] 
    # 배치 규격 항목 — 이 목록 하나가 팝업의 내용을 정한다.
    # (i18n 키, 기본 라벨, 저장 속성명, 고를 값들). 항목을 늘리려면 여기 한 줄만 더한다.
    # ⚠ **클래스 속성은 import 시점에 한 번 평가된다** — 여기서 `i18n.t()` 를 부르면
    #   언어를 바꿔도 라벨이 안 따라온다(CLAUDE.md §A4). 그래서 키만 담고
    #   푸는 것은 사용처(`open_layout_settings`)에서 런타임에 한다.
    # 예전 라벨은 `W-Size`·`Font-F` 같은 영문 약어였다 — 옮겨 오면서 말로 풀었다.
    # ★ **무엇을 조절하는 값인지 묶음 제목으로 밝힌다** (2026-08-20 사용자 —
    #   「왼쪽 숫자들이 무엇을 조절하는지 알 수 없다. 헤더를 명확하게」).
    #   실측: 「줄 수」·「상자 폭」은 **박스가 아니라 구절 본문 자르기**에만
    #   쓰이고(`_truncate_text`), 간격·글꼴·선 굵기는 구절 박스와 렌즈노드
    #   박스에 **함께** 걸린다. 그래서 셋으로 갈랐다.
    # ★ 옵션 정리 (2026-09-02 0.txt 5-1 사용자 확정) — 「옵션은 축 하나만」:
    #   · 세로 간격 제거 — 본문 높이에 맞춰 **자동**(겹치지 않는 최소 간격)
    #   · 본문 줄 수 제거 — 축약을 없애고 **전체 본문을 줄바꿈**하므로 줄수는
    #     본문 길이 ÷ 폭에서 저절로 나온다
    #   · 선 굵기 제거 — 이름은 「선」인데 실제는 본문 굵게 토글이었고 테두리는
    #     1px 고정이었다(「전혀 제대로 작동하지 않는다」 — 정확한 지적)
    _CANVAS_CFG_GROUPS = [
        ("UM_CFG_G_LAYOUT", "배치 — 박스 사이 간격", [
            ("UM_CFG_WIDTH",  "가로 간격", "cfg_h_gap", [300, 400, 500, 600, 700]),
        ]),
        ("UM_CFG_G_FONT", "글꼴 — 박스·본문 공통", [
            ("UM_CFG_FONTF",  "글꼴",      "cfg_font_family",
             ["Malgun Gothic", "NanumGothic", "Consolas", "Arial"]),
            ("UM_CFG_FONTSZ", "글자 크기", "cfg_font_size", [9, 10, 11, 12, 14]),
        ]),
    ]
    # 옛 이름 — 저장 키 목록으로 쓰는 자리가 있어 평평하게도 남겨 둔다
    _CANVAS_CFG_ITEMS = [it for _k, _t, _items in _CANVAS_CFG_GROUPS for it in _items]

    def open_layout_settings(self):
        """캔버스 배치·글꼴 설정 팝업 (2026-08-12).

        ★ **이 함수는 원래 있었는데 아무 버튼도 연결돼 있지 않았다**(unwired.md).
          그때는 `cfg_v_gap` 하나만 다루는 반쪽이라 그냥 붙일 수 없었고,
          상단 줄에 흩어져 있던 콤보 7개를 이리로 옮기면서 채워 넣었다.

        ⚠ 콤보를 `self.combos["last_scope_t1_<속성>"]` 키로 등록하는 규약을 지킨다 —
          `_apply_and_refresh()` 가 그 키로 값을 읽어 간다. 키가 어긋나면 조용히
          아무것도 안 바뀐다.
        """
        if getattr(self, '_layout_pop', None) is not None:
            try:
                self._layout_pop.lift(); self._layout_pop.focus_force(); return
            except Exception:
                self._layout_pop = None

        pop = tk.Toplevel(self)
        self._layout_pop = pop
        pop.title(i18n.t('WIN_CANVAS_LAYOUT', "캔버스 배치 설정"))
        pop.transient(self)
        # ★ 리사이즈·최대화 허용 (2026-09-02 사용자 신고 「화면 리사이즈/최대화
        #   기능이 안된다」 — resizable(False,False) 가 막고 있었다)
        pop.resizable(True, True)

        tk.Label(pop, text=i18n.t('UM_CANVAS_CFG_HINT', '선택하면 캔버스에 곧바로 반영됩니다.'),
                 fg='#7F8C8D', font=("Malgun Gothic", 8)).grid(
                     row=0, column=0, columnspan=3, sticky='w', padx=12, pady=(10, 6))

        # ── 왼쪽 = 세 묶음(배치 / 구절 본문 / 글꼴) ────────────────────────
        _left = tk.Frame(pop)
        _left.grid(row=1, column=0, sticky='nw', padx=(12, 6), pady=(0, 6))
        for gi, (g_key, g_txt, items) in enumerate(self._CANVAS_CFG_GROUPS):
            gf = tk.LabelFrame(_left, text=i18n.t(g_key, g_txt),
                               font=("Malgun Gothic", 8, "bold"))
            gf.grid(row=gi, column=0, sticky='ew', pady=(0, 6))
            for r, (key, dflt, var_name, values) in enumerate(items):
                tk.Label(gf, text=i18n.t(key, dflt), font=("Malgun Gothic", 9),
                         width=11, anchor='w').grid(row=r, column=0, sticky='w',
                                                    padx=(8, 6), pady=3)
                # 글꼴만 직접 입력을 받는다(설치된 글꼴 이름을 다 나열할 수 없다).
                is_font = (var_name == "cfg_font_family")
                cb = ttk.Combobox(gf, values=values,
                                  state="normal" if is_font else "readonly",
                                  font=("Consolas", 9), width=16 if is_font else 8)
                cb.set(getattr(self, var_name, values[0]))
                cb.grid(row=r, column=1, sticky='w', pady=3)
                self.combos[f"last_scope_t1_{var_name}"] = cb
                cb.bind("<<ComboboxSelected>>", lambda _e: self._apply_and_refresh())
                if is_font:
                    cb.bind("<Return>", lambda _e: self._apply_and_refresh())
                    tk.Button(gf, text=i18n.t('UM_FONT_PICK', ' 찾기 '),
                              command=self._open_font_picker, bg="#EBEDEF",
                              font=("Malgun Gothic", 8)).grid(row=r, column=2, padx=(4, 8))

        # ── 검색 옵션(범위·등급·경로) — 상단 bar 에서 옮겨 왔다 (2026-08-20).
        #    「성격은 다소 다르지만 어차피 수시로 바꾸지 않는다」(사용자).
        # ★ 모든 옵션 그룹 = **왼쪽 한 기둥** (2026-09-02 0.txt 5-2 사용자
        #   확정 — 「모든 옵션그룹을 가장 왼쪽에 배치하라」). _left 에 이어 붙인다.
        _opt = tk.LabelFrame(_left, text=i18n.t('UM_OPT_GROUP', '연결 옵션'),
                             font=("Malgun Gothic", 8, "bold"))
        _opt.grid(row=len(self._CANVAS_CFG_GROUPS), column=0, sticky='ew',
                  pady=(0, 6))
        _rows = (
            (i18n.t('UM_SCOPE', '대상'), self.scope_t1_var,
             [(i18n.t('UM_SCOPE_VERSE', '구절연결'), 1), (i18n.t('UM_SCOPE_NODE', '+노드'), 2)],
             lambda: (self._on_scope_changed_immediate('last_scope_t1', self.scope_t1_var),
                      self._sync_opt_btn())),
            # 범위(핵심/확장/참조) 줄은 2026-09-02 폐지 — 유형별 점수가 대체
            (i18n.t('UM_PATHMODE', '경로'), self.path_mode_var,
             [(i18n.t('UM_PATH_TOGGLE', '토글'), 1), (i18n.t('UM_PATH_MULTI', '다중'), 2)],
             lambda: (self._save_state('path_mode', self.path_mode_var.get()),
                      self._sync_opt_btn())),
            # 시점 = 화면이 새 노드를 따라갈지 (2026-08-20 사용자 — 「보고 있던
            # 맥락을 놓친다. 고정/자동이동을 옵션으로」)
            (i18n.t('UM_VIEWMODE', '표시'), self.view_follow_var,
             [(i18n.t('UM_VIEW_FIX', '고정'), 0), (i18n.t('UM_VIEW_FOLLOW', '자동이동'), 1)],
             lambda: (self._save_state('canvas_follow', self.view_follow_var.get()),
                      self._sync_opt_btn())),
        )
        for gi, (title, var, opts, cb) in enumerate(_rows):
            box = tk.Frame(_opt)
            box.grid(row=gi, column=0, sticky='w', padx=6, pady=2)
            tk.Label(box, text=title, width=4, anchor='w',
                     font=("Malgun Gothic", 8)).pack(side='left')
            for txt, val in opts:
                tk.Radiobutton(box, text=txt, variable=var, value=val,
                               font=("Malgun Gothic", 8), command=cb
                               ).pack(side='left', padx=1)
        # 표시 갯수 — 구절연결 자식을 몇 개까지 펼칠지 (2026-08-26 ③.
        # 입력은 무제한, 캔버스 표시만 제한 — 1~10, 사용자 확정 「10개 이상은
        # 표시하기 너무 복잡하다」. 나머지는 배지 옆 ＋ 로 묶음 교체.)
        _lim_box = tk.Frame(_opt)
        _lim_box.grid(row=len(_rows), column=0, sticky='w', padx=6, pady=2)
        tk.Label(_lim_box, text=i18n.t('UM_LINK_LIMIT', '갯수'), width=4, anchor='w',
                 font=("Malgun Gothic", 8)).pack(side='left')
        _lim_cb = ttk.Combobox(_lim_box, values=[str(n) for n in range(1, 11)],
                               state='readonly', width=3, font=("Consolas", 9))
        _lim_cb.set(str(self._canvas_link_limit()))
        _lim_cb.pack(side='left', padx=1)
        _lim_cb.bind("<<ComboboxSelected>>",
                     lambda _e: self._set_canvas_link_limit(_lim_cb.get()))
        tk.Label(_lim_box, text=i18n.t('UM_LINK_LIMIT2', '개 이하 표시'),
                 font=("Malgun Gothic", 8)).pack(side='left', padx=(2, 0))
        # ★ 계산기준은 별도 팝업이 아니라 **이 팝업의 오른쪽 칸** (2026-09-02
        #   0.txt 5번 「캔버스 설정 팝업화면과 계산기준 팝업 화면을 하나로
        #   통합하자 … 연결옵션의 아래 또는 오른쪽에 배치」). 단추는 걷었다.
        try:
            ttk.Separator(pop, orient='vertical').grid(
                row=1, column=1, sticky='ns', padx=(4, 4), pady=(0, 6))
            import rank_setup as _rs
            _rk = _rs.build_rank_frame(pop, self.db_path,
                                       on_applied=self._rank_applied)
            _rk.grid(row=1, column=2, sticky='nsw', padx=(4, 12), pady=(0, 6))
        except Exception as _e:
            print('[layout rank frame] %s' % _e)

        # ── 렌즈노드 박스 — 연결 옵션 **오른쪽** (2026-08-20 사용자 지시) ──
        #   구절 박스는 약명이라 규격이 정해져 있지만 렌즈노드 이름은 길이가
        #   제각각이다. **한 축을 정하면 나머지는 글자에서 자동으로 나온다.**
        _nb = tk.LabelFrame(_left, text=i18n.t('UM_CFG_G_NODE', '렌즈노드 박스'),
                            font=("Malgun Gothic", 8, "bold"))
        _nb.grid(row=len(self._CANVAS_CFG_GROUPS) + 1, column=0, sticky='ew',
                 pady=(0, 6))
        tk.Label(_nb, text=i18n.t('UM_NODE_HINT', '한 축을 정하면 나머지는 자동'),
                 fg='#7F8C8D', font=("Malgun Gothic", 8)).grid(
                     row=0, column=0, columnspan=2, sticky='w', padx=8, pady=(4, 2))
        if not hasattr(self, 'node_mode_var'):
            self.node_mode_var = tk.StringVar(
                value=str(getattr(self, 'cfg_node_mode', 'H') or 'H').upper())

        def _mode_changed():
            self.cfg_node_mode = self.node_mode_var.get()
            self._save_state('cfg_node_mode', self.cfg_node_mode)
            _sync_node_rows()
            self._apply_and_refresh()

        for r, (val, txt) in enumerate(
                (('H', i18n.t('UM_NODE_MODE_H', '높이(줄 수)를 정한다')),
                 ('W', i18n.t('UM_NODE_MODE_W', '폭(글자 수)을 정한다'))), start=1):
            tk.Radiobutton(_nb, text=txt, variable=self.node_mode_var, value=val,
                           font=("Malgun Gothic", 8), command=_mode_changed
                           ).grid(row=r, column=0, columnspan=2, sticky='w', padx=6)

        _rows_node = (
            ('UM_NODE_LINES', '줄 수', 'cfg_node_lines', [1, 2, 3, 4, 5], 3),
            ('UM_NODE_CHARS', '폭(글자)', 'cfg_node_chars', [8, 10, 12, 14, 16, 20], 4),
        )
        self._node_row_w = {}
        for key, dflt, var_name, values, gr in _rows_node:
            lb = tk.Label(_nb, text=i18n.t(key, dflt), font=("Malgun Gothic", 9),
                          width=8, anchor='w')
            lb.grid(row=gr, column=0, sticky='w', padx=(8, 4), pady=3)
            cb = ttk.Combobox(_nb, values=values, state='readonly',
                              font=("Consolas", 9), width=6)
            cb.set(getattr(self, var_name, values[0]))
            cb.grid(row=gr, column=1, sticky='w', pady=3, padx=(0, 8))
            self.combos[f"last_scope_t1_{var_name}"] = cb
            cb.bind("<<ComboboxSelected>>", lambda _e: self._apply_and_refresh())
            self._node_row_w[var_name] = (lb, cb)

        def _sync_node_rows():
            """선택한 기준의 칸만 켠다 — 안 쓰는 값이 켜져 있으면 무엇이 먹는지 모른다."""
            on = self.node_mode_var.get()
            for var_name, (lb, cb) in self._node_row_w.items():
                live = (var_name == 'cfg_node_lines') == (on == 'H')
                lb.config(fg='#2C3E50' if live else '#B0B7BC')
                cb.config(state='readonly' if live else 'disabled')
        _sync_node_rows()

        tk.Button(pop, text=i18n.t('COMMON_CLOSE', '닫기'),
                  command=lambda: (setattr(self, '_layout_pop', None), pop.destroy()),
                  bg="#5D6D7E", fg="white", font=("Malgun Gothic", 9, "bold"), width=10
                  ).grid(row=2, column=0, columnspan=3, pady=(4, 12))

        pop.protocol("WM_DELETE_WINDOW",
                     lambda: (setattr(self, '_layout_pop', None), pop.destroy()))
        # ★ 초기 크기 = **좌우 최대 · 상단 배치** (2026-09-02 사용자 지시 —
        #   「그래야 캔버스에 실시간 수정되는 것을 확인하기 쉽다」. 팝업이 위에
        #   붙어 있으면 아래로 캔버스가 보인다).
        # ⚠ 옛 「부모 가운데 위쪽」 배치는 걷었다 — 위 상단 배치를 도로 151px
        #   아래로 밀고 있었다(실측으로 잡음). 상단 한 곳에서만 정한다.
        try:
            pop.update_idletasks()
            _w = pop.winfo_screenwidth() - 24
            _h = pop.winfo_reqheight()
            pop.geometry('%dx%d+%d+%d' % (_w, _h, 8, 0))
        except Exception:
            pass

    def _open_font_picker(self):
        """시스템 폰트를 선택해 Font-F 콤보에 넣는다(목록에도 남긴다)."""
        import tkinter.font as tkfont
        f_pop = tk.Toplevel(self)
        f_pop.title(i18n.t('WIN_FONT_PICKER', "글꼴 선택하기"))
        f_pop.geometry("300x450")
        f_pop.transient(self._layout_pop or self)

        lb = tk.Listbox(f_pop, font=("Malgun Gothic", 10), selectmode='single')
        lb.pack(expand=True, fill='both', padx=10, pady=10)
        for f in sorted(tkfont.families()):
            if not f.startswith("@"):      # 세로쓰기용 @폰트 제외
                lb.insert(tk.END, f)

        def select_f():
            if not lb.curselection():
                return
            f_name = lb.get(lb.curselection())
            target = self.combos.get("last_scope_t1_cfg_font_family")
            if target is not None:
                target.set(f_name)
                vals = list(target['values'])
                if f_name not in vals:
                    vals.append(f_name)
                    target['values'] = vals
                self._apply_and_refresh()      # 예전에는 Apply 를 또 눌러야 했다
            f_pop.destroy()

        tk.Button(f_pop, text=i18n.t('UM_FONT_SELECT', ' 이 글꼴 쓰기 '), command=select_f,
                  bg="#2E86C1", fg="white", font=("Malgun Gothic", 9, "bold")).pack(pady=10)

    # 배치 옵션을 실시간으로 반영하고 상태를 표시
    def _apply_and_refresh(self):
        """[수리] Height 등 배치 옵션 변경 시 화면을 리셋하지 않고 현재 상태를 유지하며 재배치합니다."""
        # 1. 배치옵션 설정값 로드 및 저장
        for var_name in ["cfg_start_x", "cfg_h_gap", "cfg_v_gap", "cfg_box_limit",
                        "cfg_font_size", "cfg_line_bold", "cfg_font_family",
                        "cfg_node_lines", "cfg_node_chars"]:
            combo = self.combos.get(f"last_scope_t1_{var_name}")
            if combo:
                val = combo.get()
                if var_name != "cfg_font_family":
                    try: setattr(self, var_name, int(val))
                    except: pass
                else: setattr(self, var_name, val)
                self._save_state(var_name, val)
        self._sync_canvas_style()      # 캔버스가 새 설정을 기억하게 (2026-08-20)

        # 🎯 [수리] 기존 AUTO 세이브를 지워야 엔진이 새로운 설정값으로 좌표를 재계산합니다.
        if not self.p4_view.nodes: return

        # 🎯 [수리] 현재 캔버스에 펼쳐진 모든 노드의 '계보 데이터'를 스냅샷으로 찍습니다.
        snapshot = {vid: {'node_id': info['node_id'], 'p_id': info.get('p_id')} 
                    for vid, info in self.p4_view.nodes.items()}
        
        # 🎯 [수리] 화면을 비우되, 계보(snapshot)를 바탕으로 처음부터 끝까지 다시 건설합니다.
        self.p4_view.clear_all()
        self.p4_view.nodes = {} 

        # 1단계: 루트 노드(p_id가 없는 노드)를 먼저 찾아 배치합니다.
        roots = [vid for vid, info in snapshot.items() if info.get('p_id') is None]
        for r_vid in roots:
            node_id = snapshot[r_vid]['node_id']
            v_t, v_n = self._split_logic_id(node_id)
            v_txt = self._truncate_text(self._get_bible_text_for_p4(v_n)) if v_t == 'BIBLE' else ""
            b_count = self._get_child_count(v_n, v_t, parent_id=None)
            
            # 🎯 [수리] 최초 부모에게도 스타일(Font, Size, Stroke)을 전달해야 겹침과 미적용이 해결됩니다.
            self.p4_view.add_enhanced_node(None, r_vid, node_id, self.get_asset_name(v_n, v_t),
                                           v_txt, float(self.cfg_start_x), 0.0, v_t,
                                           badge_count=b_count,
                                           font_family=self.cfg_font_family,
                                           font_size=self.cfg_font_size,
                                           line_bold=self.cfg_line_bold)
            
            self._recursive_layout_refresh(r_vid, snapshot, float(self.cfg_start_x), 0.0)

        # 🎯 [수리] 배치가 끝난 후 연결선을 복구하고 시점을 최적화합니다.
        self.p4_view.redraw_edges()
        self._refresh_all_badges()
        self.after(100, self._focus_home)

    # 배치규격 옵션 변경에 따라 기존 노드 전체의 규격과 좌표를 재계산
    def _recursive_layout_refresh(self, p_view_id, snapshot, px, py):
        """설정 변경 시 DB에서 관계명, 자녀 숫자, Q&P를 실시간 사냥하여 재배치합니다."""
        children = [vid for vid, info in snapshot.items() if info.get('p_id') == p_view_id]
        if not children: return

        with appdb.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            for i, c_vid in enumerate(children):
                node_id = snapshot[c_vid]['node_id']
                v_t, v_n = self._split_logic_id(node_id)
                
                # 🎯 [해결 1] 관계명 DB 실시간 역추적
                rel_label = ""
                if p_view_id and v_t == 'BIBLE':
                    p_pure = p_view_id.split('@')[0].split(':')[-1]
                    r_sql = """
                        SELECT R.rel_name FROM (
                            SELECT rel_code FROM user_link_asset 
                            WHERE ((clicked_id=? AND target_id=?) OR (clicked_id=? AND target_id=?)) AND record_status != 'HIDE'
                            UNION ALL
                            SELECT rel_code FROM sys_link_asset 
                            WHERE ((clicked_id=? AND target_id=?) OR (clicked_id=? AND target_id=?))
                            AND sys_link_id NOT IN (SELECT origin_id FROM user_link_asset WHERE origin_id IS NOT NULL)
                        ) L JOIN sys_rel_catalog R ON L.rel_code = R.rel_code
                          AND R.lang_code IN (?, 'KO', 'EN')
                        ORDER BY CASE R.lang_code WHEN ? THEN 1 WHEN 'EN' THEN 2 ELSE 3 END LIMIT 1
                    """
                    _lang = (getattr(self, 'lang', 'KO') or 'KO').upper()
                    r_row = conn.execute(r_sql, (p_pure, v_n, v_n, p_pure, p_pure, v_n, v_n, p_pure, _lang, _lang)).fetchone()
                    rel_label = r_row[0] if r_row else ""

                # 🎯 [해결 2] 배치 — 자동 세로 간격 (2026-09-02 본문 높이 기반)
                v_txt = self._truncate_text(self._get_bible_text_for_p4(v_n)) if v_t == 'BIBLE' else ""
                if i == 0:
                    _rtexts = []
                    for _cv2 in children:
                        _t2, _n2 = self._split_logic_id(snapshot[_cv2]['node_id'])
                        _rtexts.append(self._truncate_text(
                            self._get_bible_text_for_p4(_n2))
                            if _t2 == 'BIBLE' else "")
                    self._rl_pos = self._auto_child_pos(
                        self._child_row_heights(_rtexts), px, py)
                nx, ny = self._rl_pos[i]
                b_count = self._get_child_count(v_n, v_t, parent_id=p_view_id, conn=conn)
                
                self.p4_view.add_enhanced_node(p_view_id, c_vid, node_id, self.get_asset_name(v_n, v_t),
                                               v_txt, nx, ny, v_t, badge_count=b_count,
                                               rel_label=rel_label,
                                               font_family=self.cfg_font_family,
                                               font_size=self.cfg_font_size,
                                               line_bold=self.cfg_line_bold)
                
                self._recursive_layout_refresh(c_vid, snapshot, nx, ny)

    # 현재 선택된 책의 약명과 장절을 조합
    def _get_current_label(self, v_id):
        """[헬퍼] 현재 선택된 책의 약명과 장절을 조합합니다."""
        return f"{self.cb_book.get()[:2]} {self.cb_chap.get()}:{self.p1_ls.verse_num(tk.ACTIVE)}"

    ###  (폐기) P4 「리포트 출력」 탭 — 2026-08-20 사용자 결정으로 탭을 없앴다.
    #   그 일(경로 → 텍스트)은 **연구자료 작성툴의 [⚙ 초안 생성]** 이 흡수했고,
    #   직계/방계 구분도 거기 범위 라디오로 옮겼다. 아래 `_setup_p4_report_tab`
    #   과 report_* 메서드들은 **부르는 곳이 없다**(p4_t3_f 도 없다).
    #   ⚠ 다음 정리 때 `참고코드/` 로 보낼 것 — 지금 통째로 지우면 공유 헬퍼
    #     (`_execute_7way_match` 등)까지 흔들 위험이 있어 남겨 둔다(§0-5).
    def _setup_p4_report_tab(self):
        """[폐기] 호출부 0 — 위 주석 참조."""
        p_pw = tk.PanedWindow(self.p4_t3_f, orient='horizontal', bg="#F2F4F4", sashwidth=4)
        p_pw.pack(expand=True, fill='both')

        # [좌측 설정 패널]
        ctrl_p = tk.Frame(p_pw, bg="#F4F6F7", width=300); p_pw.add(ctrl_p, minsize=PANE_MIN)
        tk.Label(ctrl_p, text="Report Configuration", bg="#D5DBDB", font=("Malgun Gothic", 10, "bold")).pack(fill='x', pady=5)

        # 🎯 [여정 티커 복구] 리포트 탭에서도 현재 여정을 확인할 수 있도록 상단에 배치
        t_f = tk.Frame(ctrl_p, bg="#F2F4F4", height=30)
        t_f.pack(fill='x', padx=5, pady=5)
        tk.Label(t_f, text="Journey: ", bg="#F2F4F4", font=("Malgun Gothic", 8, "bold"), fg="#2E86C1").pack(side='left')
        self.report_history_lbl = tk.Label(t_f, text="", bg="#F2F4F4", font=("Malgun Gothic", 8), fg="#7F8C8D", anchor='w')
        self.report_history_lbl.pack(side='left', fill='x', expand=True)
        # 🎯 통합 티커 관리 장부에 등록
        self.history_labels["report_tab"] = self.report_history_lbl

        # 1. 소스 선택 (기존 로직 유지)
        self.report_src_var = tk.StringVar(value="MAP")
        tk.Radiobutton(ctrl_p, text="Saved Research Map", variable=self.report_src_var, value="MAP", 
                       command=self._on_report_source_toggle, bg="#F4F6F7", font=("Malgun Gothic", 9, "bold")).pack(anchor='w', padx=10, pady=(10, 2))
        
        self.report_book_sel = ttk.Combobox(ctrl_p, state="readonly", width=28)
        self.report_book_sel.pack(padx=30, pady=2); self.report_book_sel.bind("<<ComboboxSelected>>", self._on_report_book_selected)
        self.report_map_sel = ttk.Combobox(ctrl_p, state="readonly", width=28); self.report_map_sel.pack(padx=30, pady=2)

        tk.Radiobutton(ctrl_p, text="Container (Tag)", variable=self.report_src_var, value="CONT", 
                       command=self._on_report_source_toggle, bg="#F4F6F7", font=("Malgun Gothic", 9, "bold")).pack(anchor='w', padx=10, pady=(10, 2))
        
        self.report_tag_sel = ttk.Combobox(ctrl_p, state="disabled", width=28)
        self.report_tag_sel.pack(padx=30, pady=2); self.report_tag_sel.bind("<<ComboboxSelected>>", self._on_report_tag_selected)
        self.report_cont_sel = ttk.Combobox(ctrl_p, state="disabled", width=28); self.report_cont_sel.pack(padx=30, pady=2)

        # 🎯 [신규] 2. 표시대상 연결 범위 (직계 vs 방계 포함)
        tk.Label(ctrl_p, text="2. Connection Scope", bg="#F4F6F7", font=("Malgun Gothic", 9, "bold")).pack(anchor='w', padx=10, pady=(15, 2))
        if not hasattr(self, 'report_scope_var'): self.report_scope_var = tk.StringVar(value="DIRECT") # DIRECT vs COLLATERAL
        tk.Radiobutton(ctrl_p, text=i18n.t('UM_DIRECTPATH','직계 경로만 포함 (Direct Path)'), variable=self.report_scope_var, value="DIRECT", bg="#F4F6F7").pack(anchor='w', padx=30)
        tk.Radiobutton(ctrl_p, text=i18n.t('UM_COLLATERAL','방계 노드 포함 (Incl. Collateral)'), variable=self.report_scope_var, value="COLLATERAL", bg="#F4F6F7").pack(anchor='w', padx=30)

        # 3. 리포트 항목 옵션 (생략 없이 유지)
        tk.Label(ctrl_p, text="3. Options", bg="#F4F6F7", font=("Malgun Gothic", 9, "bold")).pack(anchor='w', padx=10, pady=(15, 2))
        self.items_vars = {"Bible Verse": tk.BooleanVar(value=True), "Unit Descriptions": tk.BooleanVar(value=True), "Vers_Notes": tk.BooleanVar(value=True)}
        for text, var in self.items_vars.items():
            tk.Checkbutton(ctrl_p, text=text, variable=var, bg="#F4F6F7").pack(anchor='w', padx=30)

        tk.Button(ctrl_p, text="Generate Research Report", command=self._generate_p4_report, 
                  bg="#2E86C1", fg="white", font=("Malgun Gothic", 10, "bold")).pack(fill='x', padx=10, pady=20)

        self.report_text_area = scrolledtext.ScrolledText(p_pw, font=("Malgun Gothic", 11)); p_pw.add(self.report_text_area, minsize=PANE_MIN)



    def _export_report_file(self):
        """[신설] 에러 해결을 위한 파일 내보내기 메서드입니다."""
        from tkinter import filedialog
        content = self.report_text_area.get("1.0", "end-1c")
        if not content.strip(): return

        f_ext = self.report_format.get().split(' ')[1][1:-1]
        path = filedialog.asksaveasfilename(defaultextension=f_ext, filetypes=[("Document", f_ext)])
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write(content)
            messagebox.showinfo(i18n.t('MSG_T_SAVEDONE', "저장 완료"), i18n.t('MSG_REPORT_SAVED', "보고서가 {path}에 저장되었습니다.").format(path=path))

    #### handle 시리즈 시작

    ### 캔버스에서 노드를 클릭할때 DB에서 하위노드를 탐색, 겹치지 않도록 상대좌표를 계산, 노드/연결선 생성, user_layout_maps에 자동저장 
    def _badge_spec(self, total, vv=None):
        """(눌렀을 때 나올 수, 배지 글, 예약 글) — 안 펼친 노드용 (2026-08-26 ③).

        ★★ **상한은 자녀 전체에 걸린다** (2026-08-26 사용자 정정 — 「+노드를
          선택한 상태이므로 **노드의 갯수까지 자녀 박스에 포함**해서 계산해야
          한다. 5개로 제한했는데 렌즈노드 포함 6개가 표시된다」).
          처음에 VERS_VERS 만 제한했던 것을 고쳤다 — 렌즈노드·컨테이너도
          상한·묶음에 함께 태운다(vv 인자는 옛 호출부 호환으로만 남김).
        잘리면 앞 숫자 = **약속 수**(§45 — 누르면 실제로 나올 개수) = 상한.
        표기 = 「10(엔터)/38」 두 줄·상하 확장(사용자 확정 — 예약 글도 두 줄,
        §47 안정: 묶음이 바뀌어도 박스가 안 흔들린다)."""
        k = self._canvas_link_limit()
        if total > k:
            return (k, '%d\n/%d' % (k, total),
                    '%d\n/%d' % (total, total))
        return (total, None, None)

    @staticmethod
    def _child_rank_key(L):
        """자식 정렬의 단일 규칙 — 점수 내림·동점 정경순·점수 없음(노드)은 뒤.
        펼침(4.5)과 복원 상한(`_restore_cap_struct`)이 **같은 이 규칙**을 쓴다."""
        s = L.get('score')
        return (-(s if s is not None else -1.0), L['target_id'])

    def handle_p4_node_click(self, asset_id, asset_type, px, py, p_view_id=None,
                             auto_save=True, page=0, append_below=False):
        """[최종완결] 무한루프를 차단하고 토글오프(Single-Path)를 실시간으로 집행합니다.

        page — VERS_VERS 자식이 상한(1~10)을 넘을 때의 묶음 번호.
        append_below — ＋ 추가 방식(2026-09-02 사용자 확정 0.txt 5번):
          기존 자식을 걷지 않고 **다음 묶음을 그 아래에 덧붙인다.**
          valid_children 이 「화면에 없는 것」에서 뽑히므로 page=0 슬라이스가
          곧 다음 순위 묶음이다 — 순위 계산을 두 벌 두지 않는다."""
        
        # 0. 🎯 화면에 이미 있는 정체성 — **가지치기 전에** 모은다.
        #    배지는 「지금 화면」을 기준으로 약속한 수다. 토글오프가 형제 가지를
        #    쳐낸 뒤에 세면 방금 사라진 구절이 되살아나 **약속보다 하나 더**
        #    나온다(2026-08-20 실측: 배지 6 → 실제 7).
        shown_ids = set()
        for _i in self.p4_view.nodes.values():
            try:
                _t, _n = self._split_logic_id(_i.get('node_id'))
                shown_ids.add(f"{_t}:{_n}")
            except Exception:
                pass

        # ★ 2026-10-07 (docs/1.txt 52-1) — 배지가 약속한 수를 **펼치기 전에** 적어 둔다.
        #   처음 펼치는 노드(자녀가 아직 없는 노드)만 잰다 — 이미 펼친 노드의 재클릭은
        #   옛 규칙 그대로(아무 일 없음 / 잘린 부모는 접기).
        _promised, _had_kids = None, True
        if (p_view_id is not None and not append_below
                and p_view_id in self.p4_view.nodes):
            _had_kids = any(str(d.get('p_id')) == str(p_view_id)
                            for d in self.p4_view.nodes.values())
            _promised = self.p4_view.nodes[p_view_id].get('badge')

        # 1. 🎯 [토글오프] 모드 강제 집행
        # Toggle_off(1) 모드라면, 현재 노드를 펼치기 전에 같은 층의 다른 형제들 가지만 칩니다.
        if (hasattr(self, 'path_mode_var') and self.path_mode_var.get() == 1
                and not append_below):
            if p_view_id: # 루트 노드가 아닐 때만 실행
                self.p4_view.clear_sibling_branches(p_view_id)

        # 2. 🎯 [무한루프 방지] 직계 조상(Ancestors) 전수 조사
        # 나를 낳아준 부모, 조부모 등의 Node ID를 수집하여 자식 목록에서 원천 배제합니다.
        ancestor_node_ids = []
        if p_view_id:
            # _calculate_id_lineage는 [본인_vid, 부모_vid, ...] 순으로 반환합니다.
            lineage_vids = self._calculate_id_lineage(p_view_id)
            for vid in lineage_vids:
                if vid in self.p4_view.nodes:
                    ancestor_node_ids.append(self.p4_view.nodes[vid]['node_id'])

        # 3. 🎯 자녀 데이터 사냥 (ID 정규화가 적용된 메서드)
        raw_children = self._fetch_links_integrated(asset_id, asset_type)
        
        # 4. 🎯 [핵심 필터] 조상 + **화면에 이미 있는 것 전부** 제외
        # ★ 2026-08-20 수리 — 배지와 펼치기가 **다른 규칙**을 쓰고 있었다.
        #   배지는 「화면에 이미 있는 것」을 빼고 세는데(사용자 정의: 누르면
        #   나올 개수), 펼칠 때는 **조상만** 빼고 전부 그렸다. 그래서
        #   「배지 2 인데 누르니 4개가 나온다」(사용자 신고) — 남는 2개는
        #   화면 다른 자리에 이미 있는 구절을 **또 그린 것**이었다.
        #   실측: 계 21:23 배지 0 / 실제 펼침 5(전부 이미 화면에) ·
        #         창 1:3 배지 10 / 실제 펼침 11.
        #   ⇒ 배지가 약속한 수와 실제로 나오는 수가 같아야 한다.
        #   (shown_ids 는 위 0단계 — 가지치기 전에 모아 둔 것)
        valid_children = [
            L for L in raw_children
            if f"{L['target_type']}:{L['target_id']}" not in ancestor_node_ids
            and f"{L['target_type']}:{L['target_id']}" not in shown_ids]
        
        # ★ 52-1 — 배지에는 세었지만 **이미 화면에 있어서** 안 그리는 자녀.
        #   배지는 자신·부모만 빼고 센다(`parent_id=`) — 그래서 그 둘은 여기서도 뺀다.
        _skip = set()
        try:
            _pi = self.p4_view.nodes.get(p_view_id) or {}
            if _pi:
                _skip.add('%s:%s' % self._split_logic_id(_pi.get('node_id')))
            _gp = self.p4_view.nodes.get(_pi.get('p_id')) or {}
            if _gp:
                _skip.add('%s:%s' % self._split_logic_id(_gp.get('node_id')))
        except Exception:
            pass
        _onscreen = set(shown_ids)
        for _a in ancestor_node_ids:
            try:
                _onscreen.add('%s:%s' % self._split_logic_id(_a))
            except Exception:
                pass
        _blocked, _seen_b = [], set()
        for L in raw_children:
            _k = f"{L['target_type']}:{L['target_id']}"
            if _k in _onscreen and _k not in _skip and _k not in _seen_b:
                _seen_b.add(_k)
                _blocked.append(L)

        if not valid_children:
            self._p4_mark_shortfall(p_view_id, 0, _promised, _had_kids, _blocked)
            # ⚠ **그냥 나가면 안 된다** (2026-08-20 실측으로 잡음).
            #   토글오프 모드는 위 1단계에서 이미 형제 가지를 쳐냈다 —
            #   화면은 달라졌는데 여기서 반환하면 배지도 안 고쳐지고
            #   **그 변화가 저장되지 않는다**(다음에 열면 되살아난다).
            self.p4_view.redraw_edges()
            self._refresh_all_badges()
            self._p4_show_shortfall()
            if auto_save:
                self._safe_auto_save_workbench()
            return

        # 4.5 🎯 [표시 상한 · 묶음] 자녀 **전체**를 상한·묶음에 태운다
        #     (2026-08-26 사용자 정정 — 「+노드 상태면 노드 갯수까지 포함해서
        #     계산해야 한다. 5개로 제한했는데 렌즈노드 포함 6개가 표시된다」.
        #     처음의 「VERS_VERS 만 제한」을 고쳤다).
        #   · 차례 = 렌즈노드·컨테이너 먼저(소수·구조 자산) → 구절은
        #     rank_score 내림 + 동점 정경순(db_link_rank.top 과 같은 규칙,
        #     점수 없는 행은 뒤로).
        #   · 묶음(page)은 **아직 화면에 없는 것들** 위에서 돈다 — §45(배지 약속
        #     수 = 실제로 나오는 수)가 §46(자식 펼친 노드 보호)보다 우선이다.
        #   · 분모(grand)는 조상만 뺀 전체 자녀 수 — 묶음이 바뀌어도 「/38」이
        #     흔들리지 않는다.
        _limit = self._canvas_link_limit()
        # ★★ 정렬 = **점수 내림 · 동점 정경순 · 점수 없는 것은 뒤** (2026-08-27
        #   사용자 — 「점수에 따라서 계산해야 하는데 노드는 점수가 없을 것이다.
        #   그런데 구절보다 노드가 먼저 표시된다」). 8-26 의 「렌즈노드·컨테이너
        #   먼저」 배치를 뒤집었다 — 상한 셈에 노드가 포함되는 것은 그대로다.
        #   상한에 안 걸릴 때도 같은 차례로 그린다(구절마다 차례가 다르면
        #   이해할 수 없다 — 같은 신고).
        valid_children.sort(key=self._child_rank_key)
        page_meta = None
        if len(valid_children) > _limit:
            _grand = sum(1 for L in raw_children
                         if f"{L['target_type']}:{L['target_id']}" not in ancestor_node_ids)
            _merged = valid_children
            _pages = (len(_merged) + _limit - 1) // _limit
            _pg = int(page or 0) % _pages          # 마지막 뒤 순환
            _batch = _merged[_pg * _limit:(_pg + 1) * _limit]
            valid_children = _batch
            _off = _grand - len(_merged)           # 이미 화면에 있는 이 부모의 자녀 수
            page_meta = {'page': _pg, 'pages': _pages,
                         'start': _off + _pg * _limit + 1,
                         'end': _off + _pg * _limit + len(_batch),
                         'grand': _grand}
        if p_view_id is not None:
            meta_map = getattr(self, '_p4_page_meta', None)
            if meta_map is None:
                meta_map = self._p4_page_meta = {}
            if page_meta:
                meta_map[str(p_view_id)] = page_meta
            elif not append_below:
                # ⚠ 추가 모드에서는 장부를 지우지 않는다 (2026-09-02 실측으로
                #   잡음) — 마지막 묶음이 상한 안에 들면 page_meta 가 None 인데,
                #   여기서 pop 하면 ±·접기·배지 표기가 전부 죽는다(장부가 곧
                #   「이 부모는 잘린 부모다」라는 기억이다). 지우는 문은
                #   _collapse_children 하나다.
                meta_map.pop(str(p_view_id), None)

        # 5. 🎯 물리적 노드 생성 및 배치
        #    (2026-08-19 — 묵상질문 qp·노트 N 배지는 캔버스에서 폐기, 조회도 뺐다)
        # ★ 추가 방식 기준선 — 이 부모의 기존 자식 중 **실제 화면 최하단**
        #   (2026-09-02. 좌표 y 가 아니라 bbox 바닥 — 본문이 길면 y 보다 훨씬
        #   아래까지 내려가 있다). 다음 묶음은 그 아래에 이어 붙는다.
        _base_y = None
        if append_below and p_view_id is not None:
            for cid, d in self.p4_view.nodes.items():
                if str(d.get('p_id')) != str(p_view_id):
                    continue
                try:
                    bb = self.p4_view.bbox(cid)
                    bottom = bb[3] if bb else d.get('y', 0)
                except Exception:
                    bottom = d.get('y', 0)
                if bottom is not None:
                    _base_y = bottom if _base_y is None else max(_base_y, bottom)
        # ★ 두 단계 — 본문(전체 줄바꿈)을 먼저 만들어 높이를 재고, 자리를
        #   한꺼번에 계산한 뒤 그린다 (2026-09-02 자동 세로 간격. 균일 간격은
        #   본문 줄수가 제각각이라 겹치거나 벌어졌다).
        _texts = []
        for L in valid_children:
            _texts.append(self._truncate_text(
                self._get_bible_text_for_p4(L['target_id']))
                if L['target_type'] == 'BIBLE' else "")
        _pos = self._auto_child_pos(self._child_row_heights(_texts),
                                    px, py, base_y=_base_y)
        for i, L in enumerate(valid_children):
            c_type, t_id = L['target_type'], L['target_id']
            rel_label = L.get('rel_name', "")
            c_node_id = f"{c_type}:{t_id}"

            c_view_id = self.generate_node_view_id(c_node_id, p_view_id)
            c_name = self.get_asset_name(t_id, c_type)
            b_tot, b_vv = self._get_child_count(t_id, c_type, parent_id=p_view_id,
                                                with_vv=True)
            b_count, b_text, b_reserve = self._badge_spec(b_tot, b_vv)
            nx, ny = _pos[i]
            c_txt = _texts[i]

            self.p4_view.add_enhanced_node(p_view_id, c_view_id, c_node_id, c_name, c_txt, nx, ny, c_type,
                                           badge_count=b_count, rel_label=rel_label,
                                           badge_text=b_text, badge_reserve=b_reserve)

        self._p4_mark_shortfall(p_view_id, len(valid_children), _promised,
                                _had_kids, _blocked)
        self.p4_view.redraw_edges()
        # ★ 배지 재계산 (2026-08-19 수리) — 방금 펼친 노드들이 화면에 들어왔으므로
        #   모든 노드의 「눌렀을 때 새로 나올 수」가 변했다. 토글오프 정리도 이 앞
        #   에서 일어나므로 여기 한 번이면 펼침·접힘 둘 다 덮는다.
        self._refresh_all_badges()
        # ★ 잘린 부모의 배지 = **「지금 묶음 수 ↵ /전체」 두 줄** (2026-08-26
        #   사용자 확정 — 상하 확장·작은 글자. 배지 재클릭 = 다음 묶음이므로
        #   ＋ 는 안 그린다). _refresh_all_badges 는 펼친 노드를 건너뛰므로
        #   (§46) 여기서 한 번 그리면 유지된다.
        if p_view_id is not None and (page_meta or append_below):
            self._sync_parent_batch_badge(p_view_id)
        self._p4_show_shortfall()
        if auto_save:
            self._safe_auto_save_workbench()

    # ── 52-1 배지 약속보다 적게 나왔을 때 (2026-10-07 사용자 확정) ───────────────
    #   배지는 그대로 「자녀 전체 수」(분모 고정 — 2026-09-17)다. 눌렀는데 그 가운데
    #   일부가 이미 화면 다른 자리에 있어 덜 나오면 ① 배지를 **실제로 나온 수**로
    #   바꾸고(0 이면 옅게) ② 「이미 표시된 구절: 창 1:1」 풍선을 띄우고 ③ 그 상자를
    #   잠깐 반짝인다. 숫자만 바뀌면 에러처럼 보인다 — 까닭을 그 자리에서 말한다.
    #   장부 = `_p4_badge_fix[view_id] = {'n': 나온 수, 'block': {막은 정체성}}`.
    def _p4_mark_shortfall(self, p_view_id, drawn, promised, had_kids, blocked):
        self._p4_pending_note = None
        if p_view_id is None or had_kids or promised is None:
            return
        fix = getattr(self, '_p4_badge_fix', None)
        if fix is None:
            fix = self._p4_badge_fix = {}
        try:
            promised = int(promised)
        except Exception:
            return
        # ⚠ 이미 0 으로 고친 배지를 다시 누르면 약속도 0 이다 — 그래도 막힌 것이
        #   있으면 같은 풍선을 다시 띄운다(안 그러면 0 이 전체 수로 되돌아간다).
        if not blocked or (drawn >= promised and drawn > 0):
            fix.pop(str(p_view_id), None)
            return
        block = {f"{L['target_type']}:{L['target_id']}" for L in blocked}
        fix[str(p_view_id)] = {'n': int(drawn), 'block': block}
        # 토글오프가 방금 형제 가지를 걷었으면 막던 구절이 이미 사라졌을 수 있다 —
        # 풍선에는 **지금 화면에 있는 것만** 적는다(없는 것을 「표시됐다」고 하지 않는다).
        now = set()
        for d in self.p4_view.nodes.values():
            try:
                now.add('%s:%s' % self._split_logic_id(d.get('node_id')))
            except Exception:
                pass
        blocked = [L for L in blocked
                   if f"{L['target_type']}:{L['target_id']}" in now]
        if not blocked:
            return
        names = []
        for L in blocked[:3]:
            try:
                names.append(self.get_asset_name(L['target_id'], L['target_type']))
            except Exception:
                names.append(str(L['target_id']))
        txt = ' · '.join(n for n in names if n)
        if len(blocked) > 3:
            txt += ' ' + (i18n.t('UM_P4_MORE_N', '외 %d') % (len(blocked) - 3))
        msg = i18n.t('UM_P4_SHOWN', '이미 표시된 구절: %s') % txt
        vids = []
        for v, d in self.p4_view.nodes.items():
            try:
                if '%s:%s' % self._split_logic_id(d.get('node_id')) in block:
                    vids.append(v)
            except Exception:
                pass
        self._p4_pending_note = (str(p_view_id), msg, vids)
        self._p4_last_note = self._p4_pending_note

    def _p4_show_shortfall(self):
        pend = getattr(self, '_p4_pending_note', None)
        self._p4_pending_note = None
        if not pend:
            return
        vid, msg, vids = pend
        try:
            self.p4_view.show_note(vid, msg)
            self.p4_view.flash_nodes(vids)
        except Exception:
            pass

    def _refresh_all_badges(self):
        """캔버스 배지 재계산 — **아직 안 펼친 노드만** (2026-08-20 사용자 지시).

        ★★★ 배지의 뜻 = **그 노드에 달린 자녀 전체 수**(자신·부모만 뺀다 ·
          범위 옵션(구절연결/+노드)을 그대로 따른다). 2026-09-17 사용자 확정 —
          「4/25 의 뜻은 25개 중에서 사용자가 설정한 대로 4개가 표시된다는
          것이다 … **클릭할 때마다 분모가 바뀌지 않도록** 수정하자」.
        ⚠⚠ **옛 규칙(2026-08-19)은 「눌렀을 때 새로 나올 수」였다** — 화면에
          이미 뜬 것을 전부 빼고 세어(`exclude=shown`) 가지를 펼 때마다 분모가
          움직였다(실측 25 → 21 → 25). 뜻은 정확했지만 **읽히지 않았다** —
          분수는 「몇 개 중 몇 개」로 읽힌다. 이제 **처음 그릴 때와 같은 문**
          (`parent_id=`)으로 세므로 **그려진 뒤 숫자가 변하지 않는다.**
        ⚠ 그래서 앞 숫자(상한 k)는 **「한 번에 나올 수」의 약속**이고, 형제
          가지에 이미 뜬 구절이 있으면 실제로는 그보다 적게 나올 수 있다.

        ★ **이미 펼친 노드는 건드리지 않는다** — 어차피 0이 될 값을 다시 세는
          것은 낭비고, 화면 숫자도 흔들린다(사용자: 「이미 펼쳐진 배지를 다시
          0으로 바꾸는 것은 매우 비효율적이다. 자녀가 펼쳐지기 이전 상태를
          유지하는 것이 좋다」). 펼쳤는지 여부는 **자녀 선**이 말해 주므로
          그 노드의 숫자는 「여기서 몇 개가 나왔나」로 읽힌다.
        ★ **자녀가 사라지면 다시 살아난다** — 토글오프로 가지를 쳐서 할아버지·
          삼촌·조카 쪽으로 돌아가면 그 노드는 더 이상 펼쳐진 상태가 아니므로
          이 함수가 다시 세어 준다(사용자: 「고정되었던 배지가 다시 활성화」).
        """
        view = getattr(self, 'p4_view', None)
        if not view or not getattr(view, 'nodes', None):
            return
        # ⚠ 옛 `shown`(화면에 뜬 정체성 집합)은 더 안 쓴다 — 그것으로 빼서
        #   세던 것이 분모가 흔들리던 까닭이다(2026-09-17).
        # 옛 `shown`(화면에 뜬 정체성 집합)은 더 안 쓴다 — 그것으로 빼서
        # 세던 것이 분모가 흔들리던 까닭이다(2026-09-17).
        metas, expanded, onscreen = [], set(), set()
        for v_id, info in list(view.nodes.items()):
            try:
                v_t, v_n = self._split_logic_id(info.get('node_id'))
                p = info.get('p_id')
                metas.append((v_id, v_t, v_n, p))
                onscreen.add(f"{v_t}:{v_n}")
                if p:
                    expanded.add(str(p))       # 이 부모는 자녀가 붙어 있다
            except Exception:
                pass
        # ★ 52-1 — 「약속보다 적게 나왔다」 장부(`_p4_mark_shortfall`)
        fix = getattr(self, '_p4_badge_fix', None) or {}
        for k in list(fix):
            if k not in view.nodes:
                fix.pop(k, None)
        meta_map0 = getattr(self, '_p4_page_meta', None) or {}
        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                for v_id, v_t, v_n, p_id in metas:
                    f = fix.get(str(v_id))
                    if f is not None:
                        if str(v_id) in expanded:
                            if str(v_id) not in meta_map0:
                                # 펼쳐진 노드 = 실제로 나온 수
                                view.update_badge(v_id, f['n'])
                            continue
                        if f['n'] == 0 and f['block'] <= onscreen:
                            # 연결은 있는데 이미 다 화면에 있다 — 0 · 옅게
                            view.update_badge(v_id, 0, faint=True)
                            continue
                        # 접혔거나 막던 구절이 사라졌다 — 다시 전체 수로
                        fix.pop(str(v_id), None)
                    if str(v_id) in expanded:
                        continue               # 펼쳐진 노드 — 값 고정
                    # ★ 처음 그릴 때와 **같은 문**으로 센다(parent_id) —
                    #   그래야 클릭해도 분모가 안 바뀐다(2026-09-17 사용자).
                    tot, vv = self._get_child_count(v_n, v_t, conn=conn,
                                                    parent_id=p_id, with_vv=True)
                    # 잘릴 자리는 「10/42」 (2026-08-26 ③ — 앞 = 누르면 나올 수)
                    cnt, txt, _rsv = self._badge_spec(tot, vv)
                    view.update_badge(v_id, cnt, text=txt)
            # 묶음 장부 청소 — 화면에서 사라졌거나 접힌 부모의 것은 버린다
            meta_map = getattr(self, '_p4_page_meta', None)
            if meta_map:
                for k in list(meta_map.keys()):
                    if k not in view.nodes or k not in expanded:
                        meta_map.pop(k, None)
        except Exception as e:
            print(f'[refresh badges] {e}')

    # 토글오프 기능
    def _exec_toggle_cleanup(self, current_vid, p_vid):
        """[최종수리] 본인 삭제를 원천 차단하고 형제의 자손만 정밀 타격합니다."""
        if not p_vid: return
        
        # 🎯 [수리] 비교를 위해 ID 형식을 강제로 통일(Normalize)
        curr_vid_s = str(current_vid).replace("CONT:", "CONTAINER:")
        p_vid_s = str(p_vid).replace("CONT:", "CONTAINER:")

        node_keys = list(self.p4_view.nodes.keys())
        # 🎯 부모가 같으면서 '나'가 아닌 형제들만 정확히 선별
        siblings = []
        for nid in node_keys:
            info = self.p4_view.nodes[nid]
            norm_nid = str(nid).replace("CONT:", "CONTAINER:")
            norm_p_id = str(info.get('p_id', '')).replace("CONT:", "CONTAINER:")
            
            if norm_p_id == p_vid_s and norm_nid != curr_vid_s:
                siblings.append(nid)
        
        for snid in siblings:
            # 🎯 형제 본인은 살려두고 그들의 자손만 삭제 (사용자 정의 토글오프)
            self.p4_view.remove_descendants(snid)
            # 🎯 선이 꼬이지 않도록 형제의 incoming_line만 재정렬
            self.p4_view.redraw_edges()

    def _apply_styles_to_canvas(self):
        """[신설] 캔버스 객체에 직접 접근하여 폰트와 스트로크 설정을 강제 주입합니다."""
        f_fam = getattr(self, 'cfg_font_family', "Malgun Gothic")
        f_size = getattr(self, 'cfg_font_size', 10)
        # ★ 「선 굵기」 옵션 폐지 (2026-09-02 0.txt 5-1) — 본문은 늘 보통 굵기
        f_weight = "normal"

        for item in self.p4_view.find_all():
            i_type = self.p4_view.type(item)
            if i_type == "text":
                # 🎯 텍스트 아이템에만 두께(weight) 적용
                self.p4_view.itemconfig(item, font=(f_fam, f_size, f_weight))
            elif i_type == "rectangle":
                # 박스 테두리는 기본 1px로 고정하여 둔탁함을 제거
                self.p4_view.itemconfig(item, width=1)

    def _exec_smart_focus(self, positions):
        """[수리] 새 노드가 가시 영역 밖으로 나갈 때만 부드럽게 화면을 옮겨줍니다."""
        avg_nx, avg_ny = sum(p[0] for p in positions)/len(positions), sum(p[1] for p in positions)/len(positions)
        vc = (self.p4_view.canvasx(0), self.p4_view.canvasy(0), self.p4_view.canvasx(self.p4_view.winfo_width()), self.p4_view.canvasy(self.p4_view.winfo_height()))
        if not (vc[0] < avg_nx < vc[2] and vc[1] < avg_ny < vc[3]):
            self.p4_view.focus_on_coordinate(avg_nx, avg_ny)

    #### handle 시리즈 끝

    def _update_history_ticker(self, label, mode='append'):
        """[완전수리] 모든 탭의 티커를 강제 동기화하며 예외를 원천 차단합니다."""
        if not hasattr(self, 'journey_path'): 
            self.journey_path = []
        
        # 1. 경로 데이터 갱신 (중복 진입 방지 로직 포함)
        if mode == 'reset':
            self.journey_path = [label]
        else:
            if not self.journey_path or self.journey_path[-1] != label:
                self.journey_path.append(label)
        
        # 2. 표시용 텍스트 생성 (최근 10개 경로 유지)
        display_path = " ➔ ".join(self.journey_path[-10:])
        if len(self.journey_path) > 10: 
            display_path = "... " + display_path
        
        # 3. 🎯 [핵심] history_labels에 등록된 모든 위젯(탭1, 탭2 공통)을 일괄 갱신
        if hasattr(self, 'history_labels'):
            full_text = f"History: {display_path}"
            for lbl in self.history_labels.values():
                try:
                    if lbl.winfo_exists():
                        lbl.config(text=full_text)
                        lbl.update_idletasks()
                except:
                    continue # 파괴된 위젯은 무시하고 다음 위젯 진행

    def _split_logic_id(self, logic_id):
        """[수리] @ 규격을 지원하여 관계 정보가 포함된 ID에서도 논리 파트만 정확히 분리합니다."""
        # 🎯 [수리] BIBLE:1@ROOT -> BIBLE:1 추출 후 파싱
        pure_logic = str(logic_id).split('@')[0]
        parts = pure_logic.split(':')
        return parts[0], (parts[1] if len(parts) > 1 else parts[0])

    def _update_ui_status_labels(self, text, is_saved, is_manual=None):
        """상태 라벨을 일괄 갱신하고 **판정 플래그를 남긴다** (2026-08-12).

        ★ 예전에는 「수동 저장 맵인가」를 **화면 글자에서 읽었다** —
          `"Saved Map" in self.p4_status_lbl.cget("text")`. 라벨 문구를 조금만 고쳐도
          (다국어를 붙이기만 해도) 조용히 틀어지는 구조였고, 예외도 안 나서 알아채기 어렵다.

        ⚠ **`is_saved` 와 `is_manual` 은 다른 개념이다. 섞지 말 것.**
          - `is_saved`  : 저장본을 불러온 상태인가 → **글자 색**(파랑/빨강). AUTO 저장본도 참이다.
          - `is_manual` : 그것이 **수동 저장 맵**인가 → 맵 관리 팝업이 받는 값.
          예전 문자열 판정이 이 둘을 우연히 갈라 주고 있었다("AUTO 저장본"에는
          `Saved Map` 이 없다). 하나로 합치면 AUTO 저장본이 수동으로 잘못 판정된다.
          `None` 을 넘기면 플래그를 건드리지 않는다(색만 바꾸는 호출용).
        """
        if is_manual is not None:
            self._p4_map_is_manual = bool(is_manual)
        for attr in ['p4_status_lbl', 'p4_t2_status_lbl']:
            # p4_t2_status_lbl 은 (구) 트리뷰 탭의 상태 라벨이다. 2026-08-12 통합으로
            # 그 탭이 없어져 지금은 존재하지 않지만, getattr 로 걸러지므로 그대로 둔다.
            lbl = getattr(self, attr, None)
            if lbl and lbl.winfo_exists():
                lbl.config(text=text, fg="#2E86C1" if is_saved else "red")

    # ── 맵 목록 팝업 (2026-08-20 — 콤보 폐지, P1 Recent 문법) ────────────
    # ★ 50 (2026-08-23 사용자 「Maps 클릭하는데 표시되는 목록의 길이가 너무
    #   짧다 늘려라」). 옛 20 은 AUTO 가 절마다 쌓이는 것을 걱정한 값인데,
    #   실측 61개 중 20개만 보여 **직접 저장한 보존본이 목록 밖으로 밀렸다.**
    #   ⚠ 늘리면 팝업이 길어져 화면 아래로 넘친다 — 아래 `_fit` 이 잘라 준다.
    MAP_POPUP_LIMIT = 50

    def _refresh_map_switcher_list(self):
        """옛 콤보 갱신 자리 — 팝업은 열 때 읽으므로 할 일이 없다(호환용)."""
        return

    def _map_rows(self, scope):
        """[(root_id, map_name, save_type, 출발약명, 종착약명, updated_at, 태그)] 최신순.

        scope: ALL | MANUAL | AUTO. ⚑ 핀 스냅샷은 늘 뺀다(칩이 관리).
        ★ 태그(tag_list)를 함께 낸다 (2026-09-02 사용자 신고 「태그이름을
          등록했는데 저장된 맵에 그 이름이 추가되지 않았다」 — 실측: 저장은
          정상이었고 **목록에 태그를 보여 주는 자리가 없던 것**이 병이었다)."""
        wc = ["map_name NOT LIKE 'PIN\\_%' ESCAPE '\\'"]
        if scope in ('MANUAL', 'AUTO'):
            wc.append("save_type='%s'" % scope)
        sql = ("SELECT root_id, map_name, save_type, path_string, updated_at,"
               " tag_list "
               "FROM user_saved_maps WHERE " + " AND ".join(wc) +
               " ORDER BY updated_at DESC LIMIT %d" % self.MAP_POPUP_LIMIT)
        out = []
        try:
            with appdb.connect(self.db_path) as conn:
                # ★ 약명 조회가 이 연결을 함께 쓴다 — 줄마다 여닫지 않는다
                #   (2026-09-01 0.txt 3번. 50줄 × 출발·종착 = 연결 100회였다).
                for rid, name, stype, path, upd, tags in list(conn.execute(sql)):
                    s_lab = self._get_map_prefix(rid, conn=conn)
                    e_lab = self._path_end_label(path, conn=conn)
                    # 아직 아무 데도 안 갔으면 화살표를 안 보인다(출발=종착)
                    out.append((rid, name, stype, s_lab,
                                ('' if e_lab == s_lab else e_lab), upd,
                                (tags or '').strip()))
        except Exception as e:
            print(f'[map rows] {e}')
        return out

    def _path_end_label(self, path_string, conn=None):
        """저장된 여정 문자열의 **종착지 약명** (없으면 빈 칸)."""
        try:
            for vid in reversed((path_string or '').split('|')):
                if not vid:
                    continue
                pure = vid.split('@')[0]
                if pure.startswith('BIBLE:'):
                    return self._get_map_prefix(int(pure.split(':')[-1]), conn=conn)
        except Exception:
            pass
        return ''

    def _open_map_popup(self):
        """맵 목록 — 갈래(전체/수동/자동) + 출발·종착 약명. 직전 갈래 기억."""
        if getattr(self, '_map_pop', None) is not None:
            self._close_map_popup()
            return
        import ui_theme as _uth
        _bg = _uth.C('panel') or 'white'
        _hov = _uth.C('accent_bg') or '#EAF2F8'
        _alt = _uth.C('panel_alt') or '#F4F6F7'
        scope = str(self._load_state('map_popup_scope', 'ALL') or 'ALL').upper()
        if scope not in ('ALL', 'MANUAL', 'AUTO'):
            scope = 'ALL'
        pop = tk.Toplevel(self)
        pop.overrideredirect(True)
        pop.attributes('-topmost', True)
        pop.configure(bg=_uth.C('border') or '#7F8C8D')
        self._map_pop = pop
        inner = tk.Frame(pop, bg=_bg)
        inner.pack(padx=1, pady=1, fill='both', expand=True)
        head = tk.Frame(inner, bg=_alt)
        head.pack(fill='x')
        body = tk.Frame(inner, bg=_bg)
        body.pack(fill='both', expand=True)

        def _fill(sc):
            self._save_state('map_popup_scope', sc)
            for w in head.winfo_children():
                try:
                    w.config(bg=(_uth.C('dark_bg') or '#2C4259') if w._sc == sc else _alt,
                             fg=(_uth.C('fg_on_dark') or 'white') if w._sc == sc
                             else (_uth.C('fg') or '#2C3E50'))
                except Exception:
                    pass
            for w in body.winfo_children():
                w.destroy()
            rows = self._map_rows(sc)
            if not rows:
                tk.Label(body, text=i18n.t('UM_MAP_NONE', '저장된 맵이 없습니다.'),
                         bg=_bg, fg=_uth.C('fg_dim') or '#888').pack(padx=10, pady=8)
            # ★★ **줄 = Text 위젯 하나** (2026-09-01 0.txt 3번 「Maps 표시 속도」).
            #   그전에는 50줄 × (Frame + Label 4) = **위젯 250개**를 만들었다 —
            #   생성 자체에 더해 `<Map>` 폭풍이 전역 폰트 재기(`_scale_on_map`)를
            #   불러 열 때마다 1~2초가 나갔다(프로파일 실측). Text 하나에 태그로
            #   그리면 위젯 1개다 — 폭풍도 재기도 없다. hover·클릭은 줄 태그
            #   `tag_bind` 가 그대로 한다. 칸 정렬은 탭 자리(픽셀)로 맞춘다
            #   (CJK 는 글자수 ljust 로 안 맞는다).
            if rows:
                txt = tk.Text(body, bg=_bg, bd=0, highlightthickness=0,
                              cursor='hand2', wrap='none',
                              tabs=('76', '170', '212'), spacing1=2, spacing3=2)
                txt.pack(fill='both', expand=True, padx=6)
                txt.tag_configure('c_start', foreground=_uth.C('accent') or '#1A5276',
                                  font=('', 9, 'bold'))
                txt.tag_configure('c_dim', foreground=_uth.C('fg_dim') or '#888')
                _au = i18n.t('UM_MAP_AUTO', '자동')
                _ma = i18n.t('UM_MAP_MANUAL', '수동')
                for idx, (rid, name, stype, s_lab, e_lab, upd, tags) in enumerate(rows):
                    rt = 'row%d' % idx
                    txt.insert('end', s_lab, ('c_start', rt))
                    txt.insert('end', '\t' + (('→ ' + e_lab) if e_lab else ''), (rt,))
                    txt.insert('end', '\t' + (_au if stype == 'AUTO' else _ma),
                               ('c_dim', rt))
                    txt.insert('end', '\t' + name[:22], (rt,))
                    # ★ 분류 태그 표기 (2026-09-02 사용자 신고 「태그이름이
                    #   추가되지 않았다」 — 저장은 정상, **보이는 자리가 없던
                    #   것**이 병이었다). 이름 뒤 #태그, 흐린 색.
                    if tags:
                        txt.insert('end', '  ' + ' '.join(
                            '#' + t.strip() for t in tags.split(',')
                            if t.strip())[:40], ('c_dim', rt))
                    txt.insert('end', '\n', (rt,))
                    txt.tag_bind(rt, '<Button-1>',
                                 lambda _e, r=rid, n=name: self._pick_map(r, n))
                    txt.tag_bind(rt, '<Enter>',
                                 lambda _e, t=rt: txt.tag_configure(t, background=_hov))
                    txt.tag_bind(rt, '<Leave>',
                                 lambda _e, t=rt: txt.tag_configure(t, background=''))
                txt.config(state='disabled', height=len(rows), width=52)
                # 잘리면 휠로 굴린다 — Text 는 disabled 여도 yview 가 산다
                txt.bind('<MouseWheel>',
                         lambda e: (txt.yview_scroll(-1 * (e.delta // 120) * 3,
                                                     'units'), 'break')[1])
            pop.update_idletasks()
            w = max(inner.winfo_reqwidth(), 340)
            h = inner.winfo_reqheight() + 2
            btn = self._map_btn
            sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
            x = min(btn.winfo_rootx(), sw - w - 10)
            y = btn.winfo_rooty() + btn.winfo_height() + 2
            # ★ **화면 아래를 넘지 않는다** (2026-08-23) — 50줄이면 그냥 두면
            #   목록 절반이 화면 밖으로 나간다. 남는 높이에 맞춰 자른다 —
            #   Text 라 휠 스크롤은 저절로 된다.
            #   ⚠ 위로 올리지는 않는다 — 단추 바로 아래가 이 팝업의 자리다.
            avail = max(160, sh - y - 12)
            if h > avail:
                h = avail
            pop.geometry(f'{w}x{h}+{max(0, x)}+{y}')

        # ★ **갈래 단추에 개수를 적는다** (2026-08-23 사용자 「Maps 클릭하는데
        #   표시되는 목록의 길이가 너무 짧다」). 실측하니 목록이 짧았던 진짜
        #   이유는 **직전 갈래가 「수동」**이었고 수동 맵이 2개뿐이었던 것이다
        #   (전체 50 · 수동 2 · 자동 50). 개수가 안 보이니 「고장」으로 읽힌다.
        #   ⇒ 「수동 (2)」처럼 적어 두면 **왜 짧은지가 그 자리에서 보이고**
        #     어느 갈래로 가야 할지도 함께 보인다(§45 배지와 같은 원칙 —
        #     약속한 수와 실제 나오는 수를 맞춘다).
        # ★ 개수는 가벼운 질의로 센다 (2026-09-01 0.txt 3번) — 그전에는
        #   갈래마다 전체 목록(약명 조회 포함)을 만들어 세느라 3회분이 나갔다.
        #   ⚠ **갈래마다 제 LIMIT 안에서** 센다(§45 배지 원칙 — 단추의 수 =
        #     그 갈래를 눌렀을 때 나오는 목록의 수. 전체 상위 50 안에서 세면
        #     수동 (1)인데 수동 목록은 4줄이 되는 어긋남이 났다 — 2026-09-02).
        _cnt = {'ALL': 0, 'MANUAL': 0, 'AUTO': 0}
        try:
            with appdb.connect(self.db_path) as _c:
                for _sc2 in ('ALL', 'MANUAL', 'AUTO'):
                    _w = "" if _sc2 == 'ALL' else (" AND save_type='%s'" % _sc2)
                    _cnt[_sc2] = _c.execute(
                        "SELECT COUNT(*) FROM ("
                        " SELECT 1 FROM user_saved_maps"
                        " WHERE map_name NOT LIKE 'PIN\\_%' ESCAPE '\\'" + _w +
                        " LIMIT ?)", (self.MAP_POPUP_LIMIT,)).fetchone()[0]
        except Exception:
            pass
        for sc, lbl in (('ALL', i18n.t('COMMON_ALL', '전체')),
                        ('MANUAL', i18n.t('UM_MAP_MANUAL', '수동')),
                        ('AUTO', i18n.t('UM_MAP_AUTO', '자동'))):
            b = tk.Button(head, text='%s (%d)' % (lbl, _cnt.get(sc, 0)),
                          font=('', 9), bd=0, padx=10, pady=2,
                          cursor='hand2', command=lambda s=sc: _fill(s))
            b._sc = sc
            b.pack(side='left')
        # ★ [관리…] — 옛 상단 bar [Manage] 를 여기로 흡수 (2026-09-01 0.txt 3번).
        #   맵을 고르다가 이름을 고치거나 지우고 싶어지는 자리가 바로 이 목록이다.
        #   ⚠ head 색 갱신 루프가 `w._sc` 를 읽으므로 이 단추에도 표식을 단다
        #     (없으면 AttributeError 를 try 가 삼켜 색이 안 돌 뿐이지만, 값을
        #     None 으로 두면 어느 갈래와도 안 겹친다).
        _mg = tk.Button(head, text=i18n.t('UM_MAP_MANAGE', '관리…'),
                        font=('', 9), bd=0, padx=10, pady=2, cursor='hand2',
                        command=lambda: (self._close_map_popup(),
                                         self._open_map_manager_popup()))
        _mg._sc = None
        _mg.pack(side='right')
        _fill(scope)
        pop.bind('<FocusOut>', lambda e: self._close_map_popup())
        pop.bind('<Escape>', lambda e: self._close_map_popup())
        pop.focus_force()

    def _map_scrollable(self, body):
        """맵 목록이 화면을 넘칠 때 **휠로 굴릴 수 있게** 한다 (2026-08-23).

        ⚠ 목록 프레임을 Canvas 안으로 옮기지 않는다 — 이미 그려 둔 줄을 다시
          짓게 되고 hover 바인딩이 끊긴다. 대신 **`place` 로 위아래 이동**만
          시킨다(가장 적은 손질로 굴러간다).
        """
        try:
            if getattr(body, '_scroll_on', False):
                return
            body._scroll_on = True
            body._off = 0

            def _wheel(e):
                try:
                    need = body.winfo_reqheight() - body.winfo_height()
                    if need <= 0:
                        return
                    step = 40 * (1 if e.delta < 0 else -1)
                    body._off = max(-need, min(0, body._off - step))
                    body.place_configure(y=body._off)
                except Exception:
                    pass

            body.pack_forget()
            body.place(x=0, y=0, relwidth=1.0)
            pop = getattr(self, '_map_pop', None)
            if pop is not None:
                pop.bind_all('<MouseWheel>', _wheel, add='+')
                body._wheel_fn = _wheel
        except Exception as e:
            print(f'[map scroll] {e}')

    def _close_map_popup(self):
        pop = getattr(self, '_map_pop', None)
        self._map_pop = None
        if pop is not None:
            try:
                pop.destroy()
            except Exception:
                pass

    def _pick_map(self, rid, name):
        self._close_map_popup()
        self._open_saved_map(rid, name)

    # (구) _save_journey_manually — 호출부 0 인 죽은 코드였고, 없는 컬럼
    # (journey_path)에 save_type 없이 INSERT 해 실행됐다면 CHECK 위반으로
    # 터졌을 것이다. 수동 저장의 유일한 문은 _write_manual_map (2026-08-20 정리).

    def _refresh_report_selectors(self):
        """[최종수리] 과거 검색값을 초기화하고 sys_tag_id를 기반으로 분류 태그를 사냥합니다."""
        if self.report_book_sel.get() and "Step" not in self.report_book_sel.get():
            self._update_journey_ticker() # 티커만 최신화
            return

        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                # 성경책 목록 (66권) 로드
                books = conn.execute("SELECT full_name FROM book_names WHERE lang_code=? ORDER BY book_code", (self.lang,)).fetchall()
                self.report_book_sel['values'] = [r['full_name'] for r in books]
                
                # 태그 분류 로드
                tags = conn.execute("SELECT sys_tag_id, tag_name_sid FROM sys_tag_asset WHERE tag_category='CLASSIFICATION' AND " + _ST + " ORDER BY tag_name_sid ASC").fetchall()
                self.report_tag_sel['values'] = [f"{r['sys_tag_id']} | {r['tag_name_sid']}" for r in tags]
                
                self._update_journey_ticker()
        except Exception as e: print(f"Report Selector Error: {e}")

    def _on_report_book_selected(self, event):
        """[신규] 선택된 책(Book)에 해당하는 수동저장 맵만 2단계 콤보에 노출합니다."""
        book_name = self.report_book_sel.get()
        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                # 🎯 [필터링] 해당 책의 verse_id 범위 내에 있는 root_id를 가진 MANUAL 맵 사냥
                sql = """
                    SELECT root_id, map_name FROM user_saved_maps 
                    WHERE save_type='MANUAL' AND root_id IN (
                        SELECT verse_id FROM bible_index 
                        WHERE bcode = (SELECT book_code FROM book_names WHERE full_name = ? AND lang_code = ?)
                    ) ORDER BY updated_at DESC
                """
                maps = conn.execute(sql, (book_name, self.lang)).fetchall()
                self.report_map_sel['values'] = [f"{r[0]} | {r[1]}" for r in maps]
                self.report_map_sel.set(f"{len(maps)} maps found")
        except Exception as e: print(f"Book Filter Error: {e}")

    def _on_report_tag_selected(self, event):
        # 선택된 태그의 sys_tag_id를 추출하여 연결된 컨테이너 목록을 사냥합니다.
        raw_sel = self.report_tag_sel.get()
        if " | " not in raw_sel: return
        t_id = raw_sel.split(" | ")[0] # sys_tag_id 추출

        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                # 🎯 [정교화] sys_tag_id를 clicked_id와 매칭하여 TAG_CONT 링크 사냥
                sql = """
                    SELECT u_id, name FROM (
                        SELECT sys_unit_id AS u_id, unit_name_sid AS name FROM sys_unit_asset 
                        WHERE unit_type='CONTAINER' AND sys_unit_id IN (
                            SELECT target_id FROM sys_link_asset 
                            WHERE link_type='TAG_CONT' AND clicked_id = ?
                        )
                        UNION ALL
                        SELECT user_unit_id AS u_id, unit_name_sid AS name FROM user_unit_asset 
                        WHERE unit_type='CONTAINER' AND record_status != 'HIDE' AND user_unit_id IN (
                            SELECT target_id FROM sys_link_asset 
                            WHERE link_type='TAG_CONT' AND clicked_id = ?
                        )
                    ) GROUP BY u_id ORDER BY name ASC
                """
                conts = conn.execute(sql, (t_id, t_id)).fetchall()
                self.report_cont_sel['values'] = [f"{r['u_id']} | {r['name']}" for r in conts]
                self.report_cont_sel.set(f"{len(conts)} containers found")
        except Exception as e: print(f"Tag Filter Error: {e}")

    def _on_report_source_toggle(self):
        """[복구] 라디오 버튼 선택에 따라 콤보박스의 활성화 상태를 배타적으로 제어합니다."""
        mode = self.report_src_var.get()
        if mode == "MAP":
            self.report_book_sel.config(state="readonly")
            self.report_map_sel.config(state="readonly")
            self.report_tag_sel.set(""); self.report_tag_sel.config(state="disabled")
            self.report_cont_sel.set(""); self.report_cont_sel.config(state="disabled")
        else:
            self.report_tag_sel.config(state="readonly")
            self.report_cont_sel.config(state="readonly")
            self.report_book_sel.set(""); self.report_book_sel.config(state="disabled")
            self.report_map_sel.set(""); self.report_map_sel.config(state="disabled")

    def _handle_p1_double_click(self, event):
        """더블클릭 시 해당 구절을 즉시 사냥하고 집중 모드로 전환합니다."""
        idx = self.p1_ls.nearest(event.y)
        if idx < 0 or idx >= self.p1_ls.size(): return 
        
        self.p1_ls.selection_clear(0, tk.END)
        self.p1_ls.selection_set(idx)
        self.p1_ls.activate(idx)
        self.update_idletasks() 
        
        # 'True' 인자를 전달하여 신규 전개 모드(중앙 정렬)를 발동시킵니다.
        self.on_verse_selected(True)

    def _open_saved_map(self, rid, map_name):
        """보존본(수동 맵) 열기의 본체 — P4 콤보와 MapManager 가 함께 쓴다 (2026-08-20).

        자동 복원은 AUTO 전용이므로, 보존본은 **이 길로만** 화면에 온다."""
        try:
            rid = int(rid)
            self.active_node_id = rid
            # _apply_saved_research_data 내부의 clear_all() 하나만 믿고 간다
            self._apply_saved_research_data(rid, map_name)
            # 로딩 완료 즉시 주인공 노드 위치로 카메라 이동
            self._focus_home()
            # 자동도 목록에 오르므로(2026-08-20 팝업) 종류를 실제로 확인한다
            _man = True
            try:
                with appdb.connect(self.db_path) as c:
                    r = c.execute("SELECT save_type FROM user_saved_maps "
                                  "WHERE root_id=? AND map_name=?",
                                  (rid, map_name)).fetchone()
                _man = not (r and r[0] == 'AUTO')
            except Exception:
                pass
            self._update_ui_status_labels(
                (f"Saved Map : {map_name}" if _man else "AUTO 저장본"),
                True, is_manual=_man)
        except Exception as e: print(f"Load Asset Error: {e}")

    # (구) _load_selected_map_asset — 맵 콤보의 짝이었다. 콤보를 팝업으로
    # 바꾸며 2026-08-20 폐지(`_pick_map` → `_open_saved_map`).

    def _generate_p4_report(self):
        """[최종수리] ID 분리 로직을 보강하여 'too many values to unpack' 에러를 방지합니다."""
        v_id = getattr(self, 'active_node_id', None)
        if not v_id: return
        
        self.report_text_area.delete("1.0", "end")
        journey = getattr(self, 'current_journey_list', [])
        nodes_dict = self.p4_view.nodes
        
        if not journey: return

        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                self.report_text_area.insert("end", f"[명상 연구 리포트: {getattr(self, 'active_map_name', 'Current View')}]\n" + "="*60 + "\n\n")

                for vid_s in journey:
                    # 🎯 [해결] 언팩 에러 방지를 위해 _split_logic_id 사용
                    v_type, v_num = self._split_logic_id(vid_s)
                    self._print_node_to_report(vid_s, nodes_dict, conn, is_collateral=False)
                    
                    if self.report_scope_var.get() == "COLLATERAL":
                        collaterals = [nid for nid, info in nodes_dict.items() if info.get('p_id') == vid_s and nid not in journey]
                        collaterals.sort(key=lambda x: int(x.split(':')[-1] if ':' in x else 0))
                        for col_vid in collaterals:
                            self._print_node_to_report(col_vid, nodes_dict, conn, is_collateral=True)

                self.report_text_area.insert("end", "\n" + "="*60 + f"\n{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        except Exception as e: print(f"Report Engine Error: {e}")


    def _print_node_to_report(self, vid_s, nodes_dict, conn, is_collateral=False):
        """[헬퍼] 개별 노드의 깊이를 계산하여 인덴트와 함께 리포트에 삽입합니다."""
        depth = 0; curr = vid_s
        # 계보 추적을 통한 인덴트 계산
        while curr in nodes_dict and nodes_dict[curr].get('p_id'):
            depth += 1; curr = nodes_dict[curr]['p_id']
        
        indent = "    " * depth
        v_type, v_num = vid_s.split(':') if ':' in vid_s else ('BIBLE', vid_s)
        name = self.get_asset_name(v_num, v_type)
        
        marker = "○" if is_collateral else "●"
        self.report_text_area.insert("end", f"{indent}{marker} {name}\n")
        self._insert_report_items(v_num, v_type, indent, conn, is_collateral=is_collateral)

    def _insert_report_items(self, t_id, t_type, indent, conn, is_collateral=False):
        """[최종수리] 직계/방계 여부와 사용자 옵션에 따라 본문, 설명, 묵상을 인덴트와 함께 출력합니다."""
        
        # 1. 📖 성경 본문 처리 (Bible Verse)
        if self.items_vars["Bible Verse"].get() and t_type == 'BIBLE':
            # 🎯 [해결] 방계 노드이면서 '제목만 요약' 옵션이 켜져 있는 경우 본문을 생략합니다.
            if is_collateral and self.collateral_detail_var.get() == "SUMMARY":
                self.report_text_area.insert("end", f"{indent}   └ 본문: (방계 본문 요약 생략)\n")
            else:
                txt = self._get_bible_text_for_p4(t_id)
                self.report_text_area.insert("end", f"{indent}   └ 본문: {txt}\n")
        
        # 2. 📝 유닛 설명 처리 (Unit Descriptions)
        # BIBLE 타입이 아닐 때만 출력하도록 설계되었습니다.
        if self.items_vars["Unit Descriptions"].get() and t_type != 'BIBLE':
            desc = self._get_asset_content_integrated(t_id, t_type)
            if desc:
                self.report_text_area.insert("end", f"{indent}   └ 설명: {desc}\n")

        # 3. 🙏 묵상 기록 처리 (Vers_Notes)
        # 🎯 [확인] 생략되지 않고 직계/방계 구분 없이 사용자가 체크했다면 모두 가져옵니다.
        if self.items_vars["Vers_Notes"].get():
            try:
                # 🎯 clicked_id를 기준으로 저장된 묵상을 사냥합니다.
                note_row = conn.execute("""
                    SELECT contents FROM user_text_asset 
                    WHERE clicked_id=? AND text_type='VERS_NOTE'
                """, (t_id,)).fetchone()
                
                if note_row and note_row[0]:
                    self.report_text_area.insert("end", f"{indent}   └ 묵상: {note_row[0]}\n")
            except Exception as e:
                print(f"Report Note Fetch Error for {t_id}: {e}")

        # 노드 간 가독성을 위한 한 줄 띄움
        self.report_text_area.insert("end", "\n")


    def _get_link_description_direct(self, parent_vid_s, child_vid_s, conn):
        """[신설] 두 노드 사이의 링크 설명이나 관계 명칭을 사냥합니다.
        [수정 2026-06-01] sys_rel_catalog 다국어 lang 필터 — KO 우선 + EN fallback."""
        p_id = parent_vid_s.split(':')[1]
        c_id = child_vid_s.split(':')[1]
        _lang = (getattr(self, 'lang', 'KO') or 'KO').upper()
        sql = """
            SELECT COALESCE(R.rel_name, L.link_type)
            FROM sys_link_asset L
            LEFT JOIN sys_rel_catalog R ON L.rel_code = R.rel_code
              AND R.lang_code IN (?, 'KO', 'EN')
            WHERE (L.clicked_id = ? AND L.target_id = ?)
               OR (L.clicked_id = ? AND L.target_id = ?)
            ORDER BY CASE R.lang_code WHEN ? THEN 1 WHEN 'EN' THEN 2 ELSE 3 END LIMIT 1
        """
        res = conn.execute(sql, (_lang, p_id, c_id, c_id, p_id, _lang)).fetchone()
        return res[0] if res else ""

    def _get_asset_content_integrated(self, asset_id, asset_type):
        """[통합 뷰 모델] 자산 유형에 따라 사용자가 편집한 최종 설명(DESC) 또는 본문을 사냥합니다."""
        # 1. 성경 본문 추출 (BIBLE)
        if asset_type == 'BIBLE':
            return self._get_bible_text_for_p4(asset_id)

        content = ""
        try:
            with appdb.connect(self.db_path) as conn:
                # 🎯 [핵심] 사용자 수정본(priority 1)을 시스템 기본값(priority 2)보다 우선순위에 둠
                # record_status가 'HIDE'인 사용자의 수정 기록은 결과에서 제외됩니다.
                sql = """
                    SELECT contents FROM (
                        SELECT contents, 1 as priority FROM user_text_asset
                        WHERE clicked_id = ? AND text_type LIKE '%DESC%' AND record_status != 'HIDE'
                        UNION ALL
                        SELECT contents, 2 as priority FROM sys_text_asset
                        WHERE clicked_id = ? AND text_type LIKE '%DESC%'
                        AND COALESCE(record_status,'LIVE')='LIVE'
                        AND sys_text_id NOT IN (
                            SELECT origin_id FROM user_text_asset 
                            WHERE origin_id IS NOT NULL AND record_status != 'NEW'
                        )
                    ) ORDER BY priority ASC LIMIT 1
                """
                row = conn.execute(sql, (asset_id, asset_id)).fetchone()
                
                if row and row[0]:
                    content = row[0]
                else:
                    content = "(작성된 메모나 설명이 없습니다.)"
                    
        except Exception as e:
            content = f"데이터 추출 오류: {str(e)}"

        # 보고서 가독성을 위해 줄바꿈을 공백으로 치환하여 반환
        return content.strip().replace('\n', ' ')

    def _get_asset_info_by_type(self, tid, t_type):
        """[신규] 신분에 따라 성경 본문 혹은 유닛의 설명을 사냥합니다."""
        if t_type == 'BIBLE':
            return {
                'label': self._get_bible_label_direct(tid),
                'text': self._get_bible_text_for_p4(tid)
            }
        else:
            # 유닛(NODE/CONT)은 이름을 라벨로, 요약 설명(UNIT_DESC)을 본문으로 사용
            name = self.get_asset_name(tid, t_type)
            with appdb.connect(self.db_path) as conn:
                sql = "SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type='UNIT_DESC'"
                row = conn.execute(sql, (tid,)).fetchone()
            return {'label': name, 'text': row[0] if row else f"{t_type} 상세 설명이 없습니다."}

    def _get_link_description(self, l_id, l_type, src):
        """[신규] 링크 ID에 매핑된 구체적인 연결관계 설명문을 사냥합니다."""
        tbl = "user_text_asset" if src == 'USER' else "sys_text_asset"
        # 타입에 따른 매칭 [cite: 2026-03-25]
        t_map = {'CONT_NODE': 'CONT_NODE_DESC', 'NODE_VERS': 'NODE_VERS_DESC', 'VERS_VERS': 'VERS_VERS_DESC'}
        target_type = t_map.get(l_type, 'LINK_DESC')
        
        with appdb.connect(self.db_path) as conn:
            row = conn.execute(f"SELECT contents FROM {tbl} WHERE clicked_id=? AND text_type=?", 
                               (l_id, target_type)).fetchone()
            return row[0] if row else ""

    def _get_note_count(self, verse_id, conn=None):
        try:
            vid = int(str(verse_id).split('@')[0].split(':')[-1])
            sql = "SELECT COUNT(*) FROM user_text_asset WHERE clicked_id=? AND text_type='VERS_NOTE'"
            if conn:
                return conn.execute(sql, (vid,)).fetchone()[0]
            with appdb.connect(self.db_path) as c:
                return c.execute(sql, (vid,)).fetchone()[0]
        except Exception:
            return 0

    # ──────────────────────────────────────────────────────────────
    # 설명문 결합 (Description Combo) — View Model 포함
    # ──────────────────────────────────────────────────────────────

    def _text_with_view_model(self, conn, clicked_id, text_type, lang, variant='__AUTO__'):
        """sys/user 통합 View Model + 언어 폴백(요청→EN→KO).
        variant: '__AUTO__'(전역 티어로 1건) / 'EXPERT'·'LAY'(그 변형, 없으면 레거시NULL) / None(레거시만)."""
        order = [lang]
        for fb in ('EN', 'KO'):
            if fb not in order:
                order.append(fb)
        for lg in order:
            res, hidden = self._text_one_lang_ex(conn, clicked_id, text_type,
                                                 lg, variant)
            if res:
                return res
            if hidden:
                # ★ 가려서 빈 것이다 — 다음 언어로 폴백하면 가림이 무효가
                #   된다(2026-08-26 사용자 신고 「가렸더니 영어로 폴백」).
                return []
        return []

    def _text_variant_genuine(self, conn, clicked_id, text_type, lang, variant):
        """해당 변형(EXPERT/LAY) **진짜** 행만 — 레거시(NULL) 폴백 없음. lang 폴백(요청→EN→KO).
        sys/user 통합(EDIT 우선·HIDE 숨김·NEW 추가). 티어 섹션 배분에서 진짜 변형 유무 판정용."""
        def _one(lg):
            res = []
            seen = set()
            hidden_any = [False]
            for row in conn.execute(
                    "SELECT sys_text_id, title, contents, text_variant FROM sys_text_asset "
                    "WHERE clicked_id=? AND text_type=? AND lang_code=? AND text_variant=? AND " + _ST,
                    (clicked_id, text_type, lg, variant)).fetchall():
                # ★ 덮개 — 자연 열쇠 (2026-08-26 읽기 배선)
                ov = self._text_overlay_user(conn, text_type, clicked_id,
                                             lg, row[3])
                if ov is not None:
                    seen.add('%s|%s|%s|%s' % (text_type, clicked_id,
                                              (lg or '').upper(), row[3] or ''))
                    if ov[0] != 'HIDE':
                        res.append(ov[1])
                    else:
                        hidden_any[0] = True
                    continue
                # (폴백) 옛 PK 짝짓기 — 실측 0행
                user = conn.execute(
                    "SELECT title, contents, record_status FROM user_text_asset "
                    "WHERE origin_id=? AND text_type=? AND lang_code=?",
                    (row[0], text_type, lg)).fetchone()
                if user:
                    if user[2] == 'EDIT':
                        res.append((user[0], user[1]))
                    else:
                        hidden_any[0] = True    # HIDE → 표시 안 함
                else:
                    res.append((row[1], row[2]))
            for row in conn.execute(
                    "SELECT title, contents FROM user_text_asset "
                    "WHERE clicked_id=? AND text_type=? AND lang_code=? AND record_status='NEW' "
                    "AND origin_id IS NULL AND text_variant=?",
                    (clicked_id, text_type, lg, variant)).fetchall():
                res.append((row[0], row[1]))
            # 덮개 NEW (LIVE + origin_key, 이 변형만 — 소비된 열쇠 제외)
            try:
                for row in conn.execute(
                        "SELECT title, contents, origin_key FROM user_text_asset "
                        "WHERE clicked_id=? AND text_type=? AND lang_code=? "
                        "AND record_status='LIVE' AND origin_key IS NOT NULL "
                        "AND COALESCE(text_variant,'')=?",
                        (clicked_id, text_type, lg, variant)).fetchall():
                    if row[2] not in seen:
                        res.append((row[0], row[1]))
            except Exception:
                pass
            return res, hidden_any[0]
        order = [lang] + [x for x in ('EN', 'KO') if x != lang]
        for lg in order:
            r, hid = _one(lg)
            if r:
                return r
            if hid:
                return []   # 가려서 빈 것 — 다음 언어로 폴백하지 않는다
        return []

    @staticmethod
    def _assign_tier_rows(want_exp, want_lay, exp_rows, lay_rows, legacy_rows):
        """전문/일반 섹션에 표시할 행 배분. 진짜 변형이 있으면 그걸, 없으면 **레거시(NULL)로 보충**.
        켜진 섹션은 절대 비우지 않는다(데이터가 있으면 무조건 보이게) — 아직 전문/일반으로 분리되지
        않은 레거시는 양쪽에 같은 글로 보충되며, 신표준 콘텐츠가 입력되면 자동으로 각자 분리됨.
        섹션 간 중복제거는 호출부에서 **섹션별로만** 처리(공유 금지)해야 양쪽 모두 보인다.
        반환: [('EXPERT'|'LAY', rows), ...] (켜진 섹션만)."""
        out = []
        if want_exp:
            out.append(('EXPERT', exp_rows if exp_rows else legacy_rows))
        if want_lay:
            out.append(('LAY', lay_rows if lay_rows else legacy_rows))
        return out

    # 연결설명문(VERS_VERS_DESC)은 2026-07-31 티어 폐지 — 전문/일반 구분 없이 단일 본문.
    # (짧은 보조 텍스트라 두 벌 저작 비용이 과했다. 9.txt ③ / CLAUDE.md §28-11)
    _TIERED_TYPES = ('VERS_DESC', 'VERS_QUESTION')

    def _open_verse_link_editor(self):
        """[E] — 총괄 창(내 수정)을 연다.

        ★ 첫 화면 = **연결 작업대**(2026-08-27 사용자 — 「관리자 연결편집
        팝업의 구조를 수용」. 옛 focus='LINK' 는 구절연결 탭으로 곧장 들어가
        **새 작업대를 건너뛰었다** — 「아무것도 달라진 것 없다」의 정체).
        구절연결(VERS_VERS 전용)은 바로 옆 제 탭에 있다."""
        vid = getattr(self, 'active_node_id', None) \
            or getattr(self, '_p1_verse_id', None)
        if not vid:
            return
        # ★ 1단계 — **패키지 주방**으로 (2026-08-27 · 0.txt 1번).
        #   옛 총괄 창(overlay_center)은 부품 공급처로 남는다(설명문·구절연결
        #   ·태그용어 탭이 2단계에서 이 골격 안으로 옮겨온다).
        import my_edit
        my_edit.open(self, 'VERSE',
                     int(str(vid).split(':')[-1].split('_')[0]))

    def _overlay_center_changed(self, kind):
        """총괄 창(내 수정)의 저장·가림·되돌림 뒤 — **앱이 지금 보는 절**을
        다시 그린다(총괄 창의 기준이 다른 절이면 화면 변화가 없는 것이 정상)."""
        try:
            if kind == 'LINK':
                vid = getattr(self, 'active_node_id', None)
                if vid:
                    self._init_default_map(vid)
                    self.after(50, self._sync_p4_tree_from_canvas)
            elif kind == 'TEXT':
                self._update_p1_desc(getattr(self, '_p1_verse_id', None))
            elif kind == 'LENS':
                lv = getattr(self, 'p1_lens_view', None)
                if lv is not None:
                    try:
                        lv._load_category_tree()
                    except Exception:
                        pass
            elif kind == 'ENTITY':
                # 총괄 창 용어 앵커(13-53 ②)에서 저장 — 주요용어 화면 갱신
                eb = getattr(self, 'entity_browser', None)
                if eb is not None and getattr(eb, '_current_eid', None):
                    try:
                        eb._alias_cache = None
                        eb.load_entity(eb._current_eid)
                    except Exception:
                        pass
        except Exception as e:
            print('[overlay center changed]', e)

    def _rank_applied(self):
        """점수표 재계산 뒤 — 지금 절의 맵을 다시 그린다 (정렬·묶음이 새
        점수를 따르도록. 캔버스 설정 팝업에 임베드된 계산기준이 부른다)."""
        try:
            vid = getattr(self, 'active_node_id', None)
            if vid:
                self._init_default_map(vid)
                self.after(50, self._sync_p4_tree_from_canvas)
        except Exception as e:
            print('[rank applied]', e)

    def _open_rank_setup(self):
        """호환 입구 — 계산기준은 캔버스 설정 팝업에 통합됐다 (2026-09-02)."""
        import rank_setup
        rank_setup.open_setup(self, self.db_path, on_applied=self._rank_applied)

    def _open_p2_overlay_editor(self):
        """P2 설명 탭 「내 설명」 — 지금 절의 덮개 편집 팝업 (2026-08-26)."""
        vid = getattr(self, '_p1_verse_id', None)
        if not vid:
            return
        import overlay_edit
        import verse_tier
        try:
            with appdb.connect(self.db_path) as conn:
                lang = verse_tier.get_desc_lang(conn)
                mode = verse_tier.get_desc_mode(conn)
        except Exception:
            lang, mode = 'KO', 'LAY'
        overlay_edit.open_editor(
            self, self.db_path, 'BIBLE', int(vid), lang, mode=mode,
            on_saved=lambda: self._update_p1_desc(
                getattr(self, '_p1_verse_id', None)))

    @staticmethod
    def _text_overlay_user(conn, text_type, clicked_id, lang, variant):
        """덮개 행 조회 — **자연 열쇠(origin_key)** 로 (2026-08-26 읽기 배선).

        반환: None(덮개 없음) · ('HIDE', None) · ('EDIT'|'LIVE', (title, contents)).
        ⚠ 옛 방식(origin_id = sys PK 짝짓기)은 배포마다 PK 가 0% 보존이라
          재적재에서 죽는다 — overlay.py 엔진과 같은 열쇠를 쓴다.
          LIVE(NEW 로 쓴 것이 재적재로 sys 와 겹친 경우)도 EDIT 처럼 대체한다
          (engine.resolve 와 같은 규칙 — HIDE 가 아니면 내 버전이 이긴다).
        ⚠ **렌즈 글(NODE_DESC 등)의 열쇠는 번호가 아니라 유닛 이름**이다
          (overlay.LENS_TEXT_TYPES) — 단일 소스 `overlay.text_override` 가
          그 변환까지 맡는다(렌즈 화면도 같은 함수를 쓴다)."""
        try:
            import overlay as _ov
            return _ov.text_override(conn, text_type, clicked_id, lang, variant)
        except Exception:
            return None

    def _ov_mark(self, conn, text_type, clicked_id, lang, variant=None):
        """이 구획을 내가 손댔는가 → `'E'`(고침) · `'N'`(새로 씀) · `''`(그대로).

        ★★ **표식은 덮개의 단위에 붙는다** (2026-08-30 사용자 지시 「사용자가
          설명문을 수정하면 E 표시를 해야 한다」). 덮개 한 건 = `sys_text_asset`
          한 행 = **구획 하나**이므로, 표식도 구획에 붙는다.
        ★ 자리는 **제목 뒤**다 — `묵상질문 (E)` (사용자 지시 「삼각형 앞에
          표시하면 인덴트가 너무 많이 들어가서 글자 공간이 좁아진다」).
          갈래 단추에는 **붙이지 않는다**(같은 지시).
        ⚠ **읽는 화면이라 `H` 는 안 보인다** — 가린 줄에 표를 달아 목록에
          남기면 그것은 가린 것이 아니다(`overlay_mark` 의 `for_reading` 규칙).
        ⚠ 새로 묻지 않는다 — `overlay.text_override` 가 이미 이 값을 알고 있고
          그동안 **글자만 꺼내 쓰고 버리고 있었다.**
        """
        try:
            import overlay as _ov
            import overlay_mark as _om
            hit = _ov.text_override(conn, text_type, clicked_id, lang, variant)
            if not hit:
                return ''
            st = hit[0]
            if st == 'HIDE':
                return _om.mark_of('SYS', True, True)      # 읽는 화면 → ''
            # sys 짝이 있으면 **고친 것**(E), 없으면 **새로 쓴 것**(N)
            q = ("SELECT 1 FROM sys_text_asset WHERE clicked_id=? AND text_type=?"
                 "  AND UPPER(lang_code)=UPPER(?)"
                 "  AND COALESCE(record_status,'LIVE')='LIVE'")
            args = [clicked_id, text_type, lang or 'KO']
            if variant:
                q += " AND text_variant=?"
                args.append(variant)
            has_sys = bool(conn.execute(q, args).fetchone())
            return _om.mark_of('EDIT' if has_sys else 'NEW', False, True)
        except Exception:
            return ''

    @staticmethod
    def _hdr(head, mark):
        """제목 뒤에 표식을 단다 — `▶ 묵상질문 (Updated)` / `▶ 묵상질문 [u]`.

        ★★★ **글자 하나는 눈에 안 들어온다** (2026-09-22 사용자 「(E) 표시가
          잘 식별되지 않는다 — "(Updated)"라고 명시적으로」). 읽는 자리는 폭이
          넉넉하므로 **낱말**로 적는다. 말은 `overlay_mark.label()` 한 곳에서
          온다 — 화면마다 적으면 갈린다.
        ⚠ `[u]` 는 이미 감싼 꼴이라 괄호를 또 씌우지 않는다(`([u])` 방지).
        ⚠ **목록 칸은 그대로 글자 하나**다(`overlay_mark.prefix` · `SLOT=4`) —
          거기서 낱말을 쓰면 이름 시작선이 통째로 밀린다."""
        if not mark:
            return head
        if mark.startswith('['):
            return '%s %s' % (head, mark)
        try:
            import overlay_mark as _om
            m = '(%s)' % (_om.label(mark) or mark)
        except Exception:
            m = '(%s)' % mark
        return '%s %s' % (head, m)

    def _ov_text(self, conn, text_type, clicked_id, lang, variant=None):
        """**글과 표식을 한 문에서** 낸다 → `(내용, 표식)` (2026-08-30 신설).

        ⚠⚠ **이 함수가 없어서 버그가 났다** (사용자 신고 「장 설명문을 수정해도
          P2 에서 수정되기 전만 표시된다」). 장·단락·책 세 모드가 **글은
          `sys_text_asset` 을 직접 읽고 표식만 `_ov_mark` 로 덮개에 물었다.**
          그래서 「(E) 라고 써 놓고 옛 글을 보여 주는」 최악의 꼴이 됐다 —
          고쳐지지 않은 것을 고쳐졌다고 말한 것이다.
        ★ **한 번만 묻는다.** 글과 표식이 같은 판정에서 나오므로 정의상 갈릴 수
          없다. 두 번 물으면 반드시 언젠가 어긋난다.
        ⚠ **가림은 언어 폴백을 이긴다** (§88차 사고) — 요청 언어에서 가렸으면
          영어로 넘어가지 않는다. 안 그러면 가렸는데 영어가 튀어나온다.
        ⚠ 읽는 화면이라 `H` 는 안 낸다(`overlay_mark` 의 `for_reading` 규칙).
          「가린 것 보기」가 켜져 있으면 `overlay_read` 가 내용째 돌려주고
          그때만 표식이 `H` 로 보인다.
        ⚠ 덮개 유형이 아닌 글(BOOK_DESC 등)은 `text_override` 가 None 이라
          **sys 그대로**가 나온다 — 지금까지의 동작과 같다.
        """
        import overlay_read as _orr
        import overlay_mark as _om
        try:
            opt = _orr.show_hidden(conn)
        except Exception:
            opt = False
        for lc in ([lang, 'EN'] if (lang or '').upper() != 'EN' else ['EN']):
            row, st = _orr.text_lang(conn, text_type, clicked_id, lc, variant,
                                     opt_show_hidden=opt)
            if st == 'HIDE':
                # 가림 — 폴백하지 않는다. 옵션이 켜져 있으면 내용째 보이고 H.
                body = (row or {}).get('contents') if row else ''
                return (body or ''), (_om.HIDE if row else '')
            if row is not None:
                mark = _om.mark_of(st, False, True)
                return ((row.get('contents') or ''), mark)
        return '', ''

    def _text_one_lang(self, conn, clicked_id, text_type, lang, variant='__AUTO__'):
        """(호환 껍데기) — 아래 `_text_one_lang_ex` 의 결과 목록만."""
        return self._text_one_lang_ex(conn, clicked_id, text_type, lang,
                                      variant)[0]

    def _text_one_lang_ex(self, conn, clicked_id, text_type, lang, variant='__AUTO__'):
        """단일 언어 sys/user 통합 → (목록, 가림 여부).
        티어 대상은 variant에 따라 1건: 특정 변형(없으면 레거시) / None(레거시) / __AUTO__(전역 티어).
        ★ 덮개(2026-08-26 배선) — sys 행마다 자연 열쇠로 user 덮개를 물어
          EDIT 는 대체·HIDE 는 숨김. 옛 origin_id(PK) 짝짓기는 폴백으로만 남긴다.
        ★ 둘째 반환값 = **이 언어에서 가린 것이 있었나** (2026-08-26 사용자
          신고 「설명문을 가렸더니 영어 설명문으로 폴백한다」) — 가려서 빈
          것과 원래 없는 것을 밖(언어 폴백)이 갈라야 한다. 가린 것이면
          다음 언어로 넘어가지 않는다."""
        results = []
        tiered = text_type in self._TIERED_TYPES
        if tiered and variant != '__AUTO__':
            if variant is None:   # 레거시(NULL)만
                sys_sql = ("SELECT sys_text_id, title, contents, text_variant FROM sys_text_asset "
                           "WHERE clicked_id=? AND text_type=? AND lang_code=? "
                           "AND text_variant IS NULL AND %s LIMIT 1" % _ST)
                sys_params = (clicked_id, text_type, lang)
                usr_sql = ("SELECT title, contents FROM user_text_asset "
                           "WHERE clicked_id=? AND text_type=? AND lang_code=? AND record_status='NEW' "
                           "AND origin_id IS NULL AND text_variant IS NULL LIMIT 1")
                usr_params = (clicked_id, text_type, lang)
            else:                 # 특정 변형 우선, 없으면 레거시(NULL)
                sys_sql = ("SELECT sys_text_id, title, contents, text_variant FROM sys_text_asset "
                           "WHERE clicked_id=? AND text_type=? AND lang_code=? "
                           "AND (text_variant=? OR text_variant IS NULL) AND %s "
                           "ORDER BY (CASE WHEN text_variant=? THEN 0 ELSE 1 END) LIMIT 1" % _ST)
                sys_params = (clicked_id, text_type, lang, variant, variant)
                usr_sql = ("SELECT title, contents FROM user_text_asset "
                           "WHERE clicked_id=? AND text_type=? AND lang_code=? AND record_status='NEW' "
                           "AND origin_id IS NULL AND (text_variant=? OR text_variant IS NULL) "
                           "ORDER BY (CASE WHEN text_variant=? THEN 0 ELSE 1 END) LIMIT 1")
                usr_params = (clicked_id, text_type, lang, variant, variant)
        elif tiered:
            import verse_tier
            _t = verse_tier.tier_for_mode(verse_tier.get_desc_mode(conn))
            sys_sql = ("SELECT sys_text_id, title, contents, text_variant FROM sys_text_asset "
                       "WHERE clicked_id=? AND text_type=? AND lang_code=? "
                       f"AND {_ST} ORDER BY {verse_tier.TIER_ORDER} LIMIT 1")
            sys_params = (clicked_id, text_type, lang, _t)
            usr_sql = ("SELECT title, contents FROM user_text_asset "
                       "WHERE clicked_id=? AND text_type=? AND lang_code=? "
                       "AND record_status='NEW' AND origin_id IS NULL "
                       f"ORDER BY {verse_tier.TIER_ORDER} LIMIT 1")
            usr_params = (clicked_id, text_type, lang, _t)
        else:
            sys_sql = ("SELECT sys_text_id, title, contents, text_variant FROM sys_text_asset "
                       "WHERE clicked_id=? AND text_type=? AND lang_code=? AND %s" % _ST)
            sys_params = (clicked_id, text_type, lang)
            usr_sql = ("SELECT title, contents FROM user_text_asset "
                       "WHERE clicked_id=? AND text_type=? AND lang_code=? "
                       "AND record_status='NEW' AND origin_id IS NULL")
            usr_params = (clicked_id, text_type, lang)
        # 1. sys 레코드 기준으로 우선 조회 (lang_code 일치 필수)
        seen_okeys = set()
        hidden_any = False
        for row in conn.execute(sys_sql, sys_params).fetchall():
            # ★ 덮개 — 자연 열쇠(그 sys 행의 변형 그대로)로 user 를 묻는다
            ov = self._text_overlay_user(conn, text_type, clicked_id, lang, row[3])
            if ov is not None:
                seen_okeys.add('%s|%s|%s|%s' % (text_type, clicked_id,
                                                (lang or '').upper(),
                                                row[3] or ''))
                if ov[0] != 'HIDE':
                    results.append(ov[1])
                else:
                    hidden_any = True
                    # ★ 「가린 것 보기」 (2026-08-27 사용자 옵션) — 켜져 있으면
                    #   가린 **원본 sys 글**을 그대로 보인다. 가림 표식은
                    #   유지(hidden_any) — 화면이 H 로 알린다.
                    try:
                        import overlay_read as _orr
                        if _orr.show_hidden(conn):
                            # ★ **H 표식을 글 앞에 붙인다** (2026-08-27 사용자
                            #   「가린 것 보기 체크해도 표시 안 된다」 — 실은
                            #   본문은 나왔는데 **가린 것인지 표시가 없어서**
                            #   그냥 원래 글로 보였다. 읽는 화면에서 H 는 안
                            #   그린다는 규칙(overlay_mark)의 예외 —
                            #   **옵션을 켠 사용자에게는 그것이 요점**이다).
                            import overlay_mark as _om
                            _hd = _om.HIDE + ' '
                            results.append((row[1],
                                            _hd + (row[2] or '')))
                    except Exception:
                        pass
                continue
            # (폴백) 옛 PK(origin_id) 짝짓기 — 실측 데이터 0행. 혹시 남아
            # 있을 옛 행을 위해 남겨 둔다 — 새 쓰기는 전부 origin_key 로.
            user = conn.execute(
                "SELECT title, contents, record_status FROM user_text_asset "
                "WHERE origin_id=? AND text_type=? AND lang_code=?",
                (row[0], text_type, lang)
            ).fetchone()
            if user:
                if user[2] == 'EDIT':
                    results.append((user[0], user[1]))
                else:
                    hidden_any = True       # (옛 경로의) HIDE → 표시하지 않음
            else:
                results.append((row[1], row[2]))
        # 2. user 단독 신규 레코드 (NEW + origin_id IS NULL, lang_code 일치 필수)
        for row in conn.execute(usr_sql, usr_params).fetchall():
            results.append((row[0], row[1]))
        # 2b. 덮개 NEW — 엔진이 sys 미매칭으로 쓴 것(LIVE + origin_key).
        #     pass 1 에서 sys 와 짝지어 소비된 열쇠는 뺀다(두 번 안 나온다).
        try:
            for row in conn.execute(
                    "SELECT title, contents, COALESCE(text_variant,''), "
                    "origin_key FROM user_text_asset "
                    "WHERE clicked_id=? AND text_type=? AND lang_code=? "
                    "AND record_status='LIVE' AND origin_key IS NOT NULL",
                    (clicked_id, text_type, lang)).fetchall():
                if row[3] in seen_okeys:
                    continue
                v = row[2]
                if variant is None and v != '':
                    continue
                if variant not in (None, '__AUTO__') and v not in (variant, ''):
                    continue
                results.append((row[0], row[1]))
        except Exception:
            pass                            # origin_key 칼럼 없는 옛 DB
        return results, hidden_any

    def _desc_tier_sections(self, conn, secs, clicked_id, text_type, lang, name='', conn_label=None):
        """체크된 설명 티어별로 (헤더, 행) 섹션 리스트 반환 — 전문설명/일반설명 제목 분리(P2와 통일).
        같은 내용 중복은 1회. name=구절명(괄호로 표기), conn_label=연결설명 라벨(주면 연결용 헤더)."""
        out = []
        import verse_tier   # KO 라벨은 체크박스와 동일 문구(위 _qa_sections 주석 참조)
        he = verse_tier.SECTION_LABELS['DESC_EXP'][0] if lang == 'KO' else 'Expert Description'
        hl = verse_tier.SECTION_LABELS['DESC_LAY'][0] if lang == 'KO' else 'Plain Description'
        sfx = f"({name})" if name else ""
        want_exp = 'DESC_EXP' in secs
        want_lay = 'DESC_LAY' in secs
        if not (want_exp or want_lay):
            return out
        exp_rows = self._text_variant_genuine(conn, clicked_id, text_type, lang, 'EXPERT') if want_exp else []
        lay_rows = self._text_variant_genuine(conn, clicked_id, text_type, lang, 'LAY') if want_lay else []
        legacy_rows = self._text_with_view_model(conn, clicked_id, text_type, lang, None)
        labels = {'EXPERT': he, 'LAY': hl}
        codes = {'EXPERT': 'DESC_EXP', 'LAY': 'DESC_LAY'}
        for which, rows in self._assign_tier_rows(want_exp, want_lay, exp_rows, lay_rows, legacy_rows):
            seen, picked = set(), []  # 섹션별 중복제거(섹션 간 공유 금지 — 레거시가 양쪽에 보이도록)
            for r in rows:
                t = r[1] or ''
                if t and t not in seen:
                    seen.add(t); picked.append(r)
            if picked:
                lbl = labels[which]
                head = f"▶ {lbl} · {conn_label}" if conn_label else f"▶ {lbl}{sfx}"
                head = self._hdr(head, self._ov_mark(
                    conn, text_type, clicked_id, lang, which))
                out.append((codes[which], head, picked))
        return out

    @staticmethod
    def _mark_questions(rows):
        """질문 여러 개를 ◇ 로 갈라 준다 (2026-08-09).

        한 셀에 질문 2~3개를 빈 줄로 나눠 담는다(lay.md §5). 표시가 없으면 어디까지가
        한 질문인지 안 보인다. `→` 로 시작하는 줄은 힌트라 표시를 붙이지 않는다.
        **저장은 건드리지 않는다** — 표시는 화면의 몫이라 기존 자산도 함께 따라온다.
        """
        out = []
        for title, body in rows:
            t = (body or '').strip()
            paras = [x for x in t.split("\n\n") if x.strip()]
            if len(paras) > 1:
                t = "\n\n".join(p if p.lstrip().startswith("→") else "◇ " + p
                                for p in paras)
            out.append((title, t))
        return out

    def _qa_sections(self, conn, secs, vid, lang):
        """연구질문/묵상질문/묵상기도 섹션(모드가 선택한 것만) — P1·P4 공통 헬퍼."""
        out = []
        # KO 라벨은 verse_tier.SECTION_LABELS(=체크박스 문구)와 **글자 그대로 같아야** 한다.
        # 체크박스가 '묵상질문'인데 본문 헤더가 '묵상 질문'이면 같은 것을 가리키는지
        # 알 수 없다(§0-3 같은 개념은 같은 단어). EN 은 체크박스가 좁아 줄임말을 쓰므로
        # 본문 헤더만 온전한 형태를 쓴다 — 이건 의도된 차이다.
        import verse_tier
        lbl_q  = verse_tier.SECTION_LABELS['Q_DEV'][0]  if lang == 'KO' else 'Meditation Question'
        lbl_qr = verse_tier.SECTION_LABELS['Q_RES'][0]  if lang == 'KO' else 'Research Question'
        lbl_pr = verse_tier.SECTION_LABELS['PRAYER'][0] if lang == 'KO' else 'Meditation Prayer'
        # ★ 표식은 **제목 뒤**에 (2026-08-30) — `▶ 묵상질문 (E)`
        if 'Q_RES' in secs:
            r = self._text_with_view_model(conn, vid, 'VERS_QUESTION', lang, 'EXPERT')
            if r:
                m = self._ov_mark(conn, 'VERS_QUESTION', vid, lang, 'EXPERT')
                out.append(('Q_RES', self._hdr(f"▶ {lbl_qr}", m),
                            self._mark_questions(r)))
        if 'Q_DEV' in secs:
            r = self._text_with_view_model(conn, vid, 'VERS_QUESTION', lang, 'LAY')
            if r:
                m = self._ov_mark(conn, 'VERS_QUESTION', vid, lang, 'LAY')
                out.append(('Q_DEV', self._hdr(f"▶ {lbl_q}", m),
                            self._mark_questions(r)))
        if 'PRAYER' in secs:
            r = self._text_with_view_model(conn, vid, 'VERS_PRAYER', lang)
            if r:
                m = self._ov_mark(conn, 'VERS_PRAYER', vid, lang)
                out.append(('PRAYER', self._hdr(f"▶ {lbl_pr}", m), r))
        return out

    def _verse_asset_sections(self, conn, secs, vid, lang, name=''):
        """구절 자산 섹션을 **체크박스와 같은 순서**로 반환 (2026-07-31, 9.txt ①).

        순서의 단일 소스는 `verse_tier.SECTION_CODES` 다 — 체크박스 배치도 같은 상수를
        쓰므로, 앞으로 순서를 바꾸려면 그 한 곳만 고치면 화면과 본문이 함께 따라온다.
        (이전에는 설명(전문→일반) 다음에 질문·기도가 뒤에 붙는 순서가 코드에 박혀 있어
         체크박스 순서를 바꿔도 본문 배치가 따라오지 않았다.)
        반환: [(헤더, 행들), ...]
        """
        import verse_tier
        pool = {}
        for code, head, rows in self._desc_tier_sections(conn, secs, vid, 'VERS_DESC', lang, name):
            pool[code] = (head, rows)
        for code, head, rows in self._qa_sections(conn, secs, vid, lang):
            pool[code] = (head, rows)
        for code, head, rows in self._view_sections(conn, secs, vid, lang):
            pool[code] = (head, rows)
        for code, head, rows in self._role_sections(conn, secs, vid, lang):
            pool[code] = (head, rows)
        out = [pool[c] for c in verse_tier.SECTION_CODES if c in pool]
        # Expert 모드인데 그 절에 전문 자산이 없으면 폴백(TIER_ORDER)으로 일반 설명이 나온다.
        # 두 버튼이 같은 글을 보이면 고장 난 것처럼 보이므로 한 줄로 알린다(2026-08-09 사용자 결정).
        if 'DESC_EXP' in secs and out:
            try:
                if not self._text_variant_genuine(conn, vid, 'VERS_DESC', lang, 'EXPERT'):
                    note = ('이 절의 전문 설명은 아직 준비되지 않아 일반 설명을 보이고 있습니다.'
                            if lang == 'KO' else
                            'No expert description yet for this verse — showing the plain one.')
                    out.insert(0, ('', [('', note)]))
            except Exception:
                pass
        return out

    def _role_sections(self, conn, secs, vid, lang):
        """[전문] 맨 아래 **분야별 도움말** — 「분야 ▾」에서 고른 분야만(`role_tips` · 2026-10-13 76-3).
        고른 분야에 글이 없으면 그렇다고 한 줄(지어내지 않는다 · 「분야 ▾ ▸ AI 에게 묻기」를 알려 준다)."""
        if 'ROLE' not in secs:
            return []
        import verse_tier
        import role_tips as RT
        show = RT.get_show(conn, 'LAY' if 'DESC_LAY' in secs else 'EXPERT')
        if not show:
            return []
        rows = RT.fetch(conn, vid, lang, show)
        lbl = i18n.t('SEC_ROLE', verse_tier.SECTION_LABELS['ROLE'][0])
        if not rows:
            note = i18n.t('ROLE_TIP_NONE', '이 구절에는 선택한 분야의 도움말이 아직 없습니다 — AI 에게 그 분야 관점으로 물어 받아 볼 수 있습니다.')
            return [('ROLE', f"▶ {lbl}", [('', note)])]
        mine = i18n.t('ROLE_TIP_MINE', '내 도움말')
        body = (chr(10) * 2).join("◆ %s%s%s%s" % (nm, (' (%s)' % mine) if m else '', chr(10), t)
                                  for _c, nm, t, m in rows)
        return [('ROLE', f"▶ {lbl}", [('', body)])]

    def _view_sections(self, conn, secs, vid, lang):
        """EXPERT 모드의 관점(◈)과 관점 정리(▶) — **데이터가 없으면 아무것도 그리지 않는다.**

        관점은 EXPERT 전용이라 Lay 모드에서는 secs 에 코드가 없어 자동으로 빠진다.
        조건 분기를 늘리지 않으려고 이렇게 뒀다(2026-08-09)."""
        out = []
        if 'VIEW' not in secs and 'VIEWMAP' not in secs:
            return out
        import verse_tier
        try:
            import db_verse_view
        except Exception:
            return out
        if 'VIEW' in secs:
            rows = db_verse_view.fetch(conn, vid, lang)
            if rows:
                # ⚠ 행 제목(title)으로 넘기면 렌더가 `[제목]` 으로 대괄호를 씌운다.
                #    그래서 한 덩이 본문으로 만들어 넘긴다 — 관점 사이는 빈 줄로 벌린다.
                lbl = verse_tier.SECTION_LABELS['VIEW'][0] if lang == 'KO' else 'Views'
                body = "\n\n".join("◈ %s\n%s" % (l, (t or '').strip()) for l, t in rows)
                out.append(('VIEW', f"▶ {lbl}", [('', body)]))
        if 'VIEWMAP' in secs:
            r = self._text_with_view_model(conn, vid, 'VERS_VIEWMAP', lang)
            if r:
                lbl = verse_tier.SECTION_LABELS['VIEWMAP'][0] if lang == 'KO' else 'Mapping the views'
                out.append(('VIEWMAP', f"▶ {lbl}", r))
        return out

    def _no_verse_assets_note(self, lang):
        """설명 자료가 없는 절에 붙이는 한 줄 (2026-10-07 · 51-2)."""
        return [('', i18n.t('UM_VERSE_NO_ASSET',
                            '이 구절의 설명문·묵상질문·묵상기도는 아직 준비되지 않았습니다.'))]

    def _fetch_combined_desc(self, view_id):
        """클릭 노드와 부모 관계에 따라 설명문을 조합합니다. 언어독립 헤더 형식 사용.

        구절→구절(VERS_VERS)일 때 순서 (2026-07-31, 9.txt ②):
          페리코프 설명문 → 연결설명문(앞구절 & 클릭구절) → 클릭 구절 자산(체크박스 순서)
        앞(부모) 구절의 설명문은 넣지 않는다 — 그 구절을 클릭하면 그대로 나오므로 중복.
        부모 없음(root) = P1 클릭과 동일(연결설명 없음)."""
        info = self.p4_view.nodes.get(view_id)
        if not info:
            return ""
        v_t, v_n = self._split_logic_id(info['node_id'])
        try:
            asset_id = int(str(v_n).split('@')[0].split(':')[-1])
        except Exception:
            return ""

        _mode = self._desc_mode()
        if _mode in ('BOOK', 'CHAP', 'PERI'):
            # 구절 노드에만 소속 책·장·페리코프가 있다. NODE/CONTAINER 는 해당 없음.
            if v_t != 'BIBLE':
                return ''
            if _mode == 'BOOK':
                return self._book_only_text(asset_id)
            return (self._chap_only_text(asset_id) if _mode == 'CHAP'
                    else self._peri_only_text(asset_id))

        p_vid = info.get('p_id')
        p_info = self.p4_view.nodes.get(p_vid) if p_vid else None
        p_type = p_id_val = None
        if p_info:
            p_type, p_n = self._split_logic_id(p_info['node_id'])
            try:
                p_id_val = int(str(p_n).split('@')[0].split(':')[-1])
            except Exception:
                pass

        lang = self._desc_lang()
        lbl_d = '설명문' if lang == 'KO' else 'Description'
        lbl_l = '연결설명문' if lang == 'KO' else 'Linked Description'

        # 헤더: label(name) 또는 label(name1 & name2) 형식
        def hdr(label, n1, n2=None):
            return f"▶ {label}({n1})" if n2 is None else f"▶ {label}({n1} & {n2})"

        self_name = self.get_asset_name(asset_id, v_t) or str(asset_id)
        p_name = (self.get_asset_name(p_id_val, p_type) or str(p_id_val)) if p_id_val is not None else ""

        # sections: list of (header_str, [(title, contents), ...])
        sections = []
        qa_done = False        # 정렬 헬퍼가 질문·기도까지 포함했으면 말미 중복 추가를 막는다

        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = None
                import verse_tier
                secs = set(verse_tier.sections_for_mode(_mode))

                def add(header, rows):
                    if rows:
                        sections.append((header, rows))

                # 페리코프 설명문은 '단락설명' 모드로 분리했다(2026-08-01) — 여기엔 없다.
                if p_type is None:
                    # 2) 루트 노드: 자신의 설명문만 (VERS_DESC는 티어별 제목 분리, NODE/CONT는 그대로)
                    tt = {'BIBLE': 'VERS_DESC', 'NODE': 'NODE_DESC',
                          'CONTAINER': 'CONT_DESC'}.get(v_t)
                    if tt == 'VERS_DESC':
                        # ⚠ 루트에도 자리표를 심는다 — 여기서도 접힘줄이 맨 끝이라
                        #   설명문이 길면 화면 밖으로 밀렸다(자녀 노드와 같은 사고).
                        #   부모 연결설명문이 없으므로 **맨 위**가 그 자리다.
                        sections.append((FOLD_MARK, []))
                        _vs = self._verse_asset_sections(conn, secs, asset_id, lang, self_name)
                        for h, r in _vs:
                            add(h, r)
                        if not _vs:
                            add(hdr(lbl_d, self_name), self._no_verse_assets_note(lang))
                        qa_done = True
                    elif tt:
                        add(hdr(lbl_d, self_name),
                            self._text_with_view_model(conn, asset_id, tt, lang))

                elif v_t == 'BIBLE' and p_type == 'BIBLE':
                    # 3) VERS_VERS (2026-07-31, 9.txt ②)
                    #    페리코프 → **연결설명문** → 클릭 구절 자산(체크박스 순서).
                    #    앞(부모) 구절의 설명문은 넣지 않는다 — 그 구절을 클릭하면 그대로
                    #    나오므로 중복이고, 두 구절분이 겹쳐 스크롤만 길어졌다.
                    link_rows = conn.execute(
                        "SELECT sys_link_id FROM sys_link_asset "
                        " WHERE link_type='VERS_VERS' AND record_status='LIVE' "
                        "   AND ((clicked_id=? AND target_id=?) "
                        "     OR (clicked_id=? AND target_id=?))",
                        (asset_id, p_id_val, p_id_val, asset_id)).fetchall()
                    _cl = f"{lbl_l}({p_name} & {self_name})"
                    link_ids = [lid for (lid,) in link_rows]

                    # 연결설명문 — 티어 구분 없이 단일 본문(9.txt ③). 페리코프 바로 아래.
                    vv, seen_vv = [], set()
                    for lid in link_ids:
                        for row in self._text_with_view_model(conn, lid, 'VERS_VERS_DESC', lang):
                            t = row[1] or ''
                            if t and t not in seen_vv:
                                seen_vv.add(t); vv.append(row)
                    if vv:
                        add(f"▶ {_cl}", vv)

                    # ★★ **자녀 연결 접힘줄이 들어갈 자리** (2026-08-23 사용자
                    #   신고 「창1:14 클릭하니 연결설명문은 표시되는데 **자녀와의
                    #   설명문 접힘줄은 없다**」).
                    #   ⚠ **있었는데 화면 밖이었다** — 실측: 접힘줄이 13번째 줄
                    #     이고 위젯에 57% 만 들어가 `bbox=None`(스크롤해야 보인다).
                    #   그리고 0.txt 7-2 가 적은 순서와도 달랐다:
                    #     「부모와의 연결설명문 → **자신과 펼쳐진 자녀와의
                    #      연결설명문** → 아래에 구절설명문/묵상질문/묵상기도」
                    #   ⇒ 맨 끝이 아니라 **여기**다. 자리표를 심고 화면이 바꿔 끼운다.
                    sections.append((FOLD_MARK, []))

                    # 클릭한 구절의 자산 — 체크박스 순서
                    _vs = self._verse_asset_sections(conn, secs, asset_id, lang, self_name)
                    for h, r in _vs:
                        add(h, r)
                    # ★ 2026-10-07 (51-2) — 그 절에 설명·묵상질문·기도가 **아직 없으면 그렇다고 말한다**.
                    #   실측 느 9:6 · 욥 38:4 — 느헤미야·욥기는 구절 설명 자료가 0편이라 연결설명문만
                    #   나왔고, 사용자는 「자녀의 설명문이 표시되지 않는다」로 읽었다(§0-1 침묵 금지).
                    if not _vs:
                        add(hdr(lbl_d, self_name), self._no_verse_assets_note(lang))
                    qa_done = True

                elif v_t == 'BIBLE' and p_type == 'NODE':
                    # 4) NODE_VERS 정방향 (부모=NODE, 자신=VERSE)
                    # 노드 우선, 구절, 연결설명문 순서
                    add(hdr(lbl_d, p_name),
                        self._text_with_view_model(conn, p_id_val, 'NODE_DESC', lang))
                    add(hdr(lbl_d, self_name),
                        self._text_with_view_model(conn, asset_id, 'VERS_DESC', lang))
                    add(hdr(lbl_l, p_name, self_name),
                        self._text_with_view_model(conn, p_id_val, 'NODE_VERS_DESC', lang))

                elif v_t == 'NODE' and p_type == 'BIBLE':
                    # 5) NODE_VERS 역방향 (부모=VERSE, 자신=NODE)
                    # 노드 우선
                    add(hdr(lbl_d, self_name),
                        self._text_with_view_model(conn, asset_id, 'NODE_DESC', lang))
                    add(hdr(lbl_d, p_name),
                        self._text_with_view_model(conn, p_id_val, 'VERS_DESC', lang))
                    add(hdr(lbl_l, self_name, p_name),
                        self._text_with_view_model(conn, asset_id, 'NODE_VERS_DESC', lang))

                elif v_t == 'NODE' and p_type == 'CONTAINER':
                    # 6/7) CONT_NODE: 컨테이너 → 노드 → 연결설명문
                    add(hdr(lbl_d, p_name),
                        self._text_with_view_model(conn, p_id_val, 'CONT_DESC', lang))
                    add(hdr(lbl_d, self_name),
                        self._text_with_view_model(conn, asset_id, 'NODE_DESC', lang))
                    add(hdr(lbl_l, p_name, self_name),
                        self._text_with_view_model(conn, p_id_val, 'CONT_NODE_DESC', lang))

                else:
                    # fallback: 자신의 설명문
                    tt = {'BIBLE': 'VERS_DESC', 'NODE': 'NODE_DESC',
                          'CONTAINER': 'CONT_DESC'}.get(v_t)
                    if tt:
                        add(hdr(lbl_d, self_name),
                            self._text_with_view_model(conn, asset_id, tt, lang))

                # BIBLE 노드일 때 연구질문/묵상질문/묵상기도 — P1과 동일한 공유 헬퍼.
                # (위 분기에서 _verse_asset_sections 로 이미 포함했으면 건너뛴다.)
                if v_t == 'BIBLE' and not qa_done:
                    for _c, h, r in self._qa_sections(conn, secs, asset_id, lang):
                        sections.append((h, r))

        except Exception as e:
            print(f"[desc_combo] error: {e}")
            return ""

        if not sections:
            return ""

        blocks = []
        for header, rows in sections:
            # ⚠ 자리표는 rows 가 비어 있다 — 그대로 한 블록으로 내보낸다
            #   (`add()` 는 rows 가 비면 버리므로 자리표는 직접 append 한다).
            lines = [header]
            for title, contents in rows:
                if title:
                    lines.append(f"  [{title}]")
                if contents:
                    lines.append(f"  {contents.strip()}")
            blocks.append("\n".join(lines))
        return "\n\n".join(blocks)

    def _show_desc_combo(self, view_id):
        """싱글클릭 시 설명문 결합 박스를 토글합니다 (모드 무관)."""
        info = self.p4_view.nodes.get(view_id)
        if not info:
            return
        text = self._fetch_combined_desc(view_id)
        self.p4_view.show_desc_box(view_id, text, info['x'], info['y'])

    def _get_child_count(self, asset_id, asset_type, parent_id=None, conn=None,
                         exclude=None, with_vv=False):
        """[Live-Sync] 현재 활성화된 탭의 범위를 실시간 감지하여 DB 원본 자녀 숫자를 반환합니다.

        exclude — 화면에 이미 표시된 정체성('BIBLE:123' 꼴) 집합 (2026-08-19
        배지 수리). 주면 자신·부모 대신 **이 집합 전체**를 빼고 센다 —
        「눌렀을 때 새로 나올 노드 수」가 배지의 뜻이다(사용자 확정).
        with_vv — True 면 (전체 수, 그중 VERS_VERS 수) 튜플 (2026-08-26 ③ —
        표시 상한은 VERS_VERS 에만 걸리므로 배지 「n/전체」 표기가 이 분리를
        필요로 한다). 기존 호출부는 무수정(기본 False = int 그대로).
        """
        is_internal = False
        if conn is None:
            conn = appdb.connect(self.db_path); conn.row_factory = sqlite3.Row
            is_internal = True
        
        pure_id = int(str(asset_id).split('@')[0].split(':')[-1])
        my_identity = f"{asset_type}:{pure_id}"
        p_identity = str(parent_id).split('@')[0] if parent_id else ""

        # 🎯 [핵심일치] 현재 활성화된 탭(Canvas vs Tree)을 조사하여 해당 scope_var를 선택합니다.
        # 2026-08-12 통합 — 캔버스·트리뷰가 한 탭이라 범위 옵션도 하나다(scope_t1_var).
        # 예전에는 활성 탭을 보고 t1/t2 를 갈랐다.
        scope = self.scope_t1_var.get() if hasattr(self, 'scope_t1_var') else 1

        allowed = ["'VERS_VERS'"]
        if scope >= 2: allowed.append("'NODE_VERS'")
        if scope >= 3: allowed.append("'CONT_NODE'")
        t_filter = f"AND link_type IN ({', '.join(allowed)})"

        # 🎯 [신설 2026-06-01] VERS_VERS 등급 필터
        tier_str = getattr(self, 'link_tier_var', None)
        tier_val = tier_str.get() if tier_str is not None else 'AB'
        if tier_val not in ('A', 'AB', 'ABC'):
            tier_val = 'AB'
        tier_in = ','.join(f"'{c}'" for c in tier_val)
        vv_tier_filter = (
            f"AND (link_type != 'VERS_VERS' OR rel_code IN "
            f"(SELECT DISTINCT rel_code FROM sys_rel_catalog WHERE rel_tier IN ({tier_in})))"
        )

        if asset_type == 'BIBLE':
            wc = f"((link_type='VERS_VERS' AND (clicked_id={pure_id} OR target_id={pure_id})) OR (link_type='NODE_VERS' AND target_id={pure_id})) {t_filter} {vv_tier_filter}"
        elif asset_type == 'NODE':
            wc = f"((link_type='NODE_VERS' AND clicked_id={pure_id}) OR (link_type='CONT_NODE' AND target_id={pure_id})) {t_filter} {vv_tier_filter}"
        else: # CONTAINER
            wc = f"(link_type='CONT_NODE' AND clicked_id={pure_id}) {t_filter} {vv_tier_filter}"

        # 제외 조건 — exclude(화면 표시분 전체) 또는 자신+부모 (기존 동작)
        if exclude:
            _items = ', '.join("'%s'" % str(s).replace("'", "''") for s in exclude)
            excl_clause = f"t_identity NOT IN ({_items})"
        else:
            excl_clause = (f"t_identity != '{my_identity}' "
                           f"AND t_identity != '{p_identity}'")
        try:
            sql = f"""
                SELECT COUNT(DISTINCT t_identity),
                       COUNT(DISTINCT CASE WHEN lt='VERS_VERS' THEN t_identity END)
                FROM (
                    SELECT link_type AS lt,
                        CASE
                            WHEN link_type='VERS_VERS' THEN 'BIBLE:'||(CASE WHEN clicked_id={pure_id} THEN target_id ELSE clicked_id END)
                            WHEN link_type='NODE_VERS' THEN (CASE WHEN '{asset_type}'='BIBLE' THEN 'NODE:'||clicked_id ELSE 'BIBLE:'||target_id END)
                            WHEN link_type='CONT_NODE' THEN (CASE WHEN '{asset_type}'='NODE' THEN 'CONTAINER:'||clicked_id ELSE 'NODE:'||target_id END)
                        END as t_identity
                    FROM sys_link_asset
                    WHERE {wc} AND COALESCE(sys_link_asset.record_status,'LIVE')='LIVE'
                    AND sys_link_id NOT IN (SELECT origin_id FROM user_link_asset WHERE origin_id IS NOT NULL)
                    AND NOT EXISTS (SELECT 1 FROM user_link_asset h
                        WHERE h.record_status='HIDE'
                        AND h.link_type=sys_link_asset.link_type
                        AND h.clicked_id=sys_link_asset.clicked_id
                        AND h.target_id=sys_link_asset.target_id
                        AND COALESCE(h.rel_code,'')=COALESCE(sys_link_asset.rel_code,'')
                        AND COALESCE(h.end_id,h.target_id)
                            =COALESCE(sys_link_asset.end_id,sys_link_asset.target_id))
                    UNION ALL
                    SELECT link_type AS lt,
                        CASE
                            WHEN link_type='VERS_VERS' THEN 'BIBLE:'||(CASE WHEN clicked_id={pure_id} THEN target_id ELSE clicked_id END)
                            WHEN link_type='NODE_VERS' THEN (CASE WHEN '{asset_type}'='BIBLE' THEN 'NODE:'||clicked_id ELSE 'BIBLE:'||target_id END)
                            WHEN link_type='CONT_NODE' THEN (CASE WHEN '{asset_type}'='NODE' THEN 'CONTAINER:'||clicked_id ELSE 'NODE:'||target_id END)
                        END as t_identity
                    FROM user_link_asset WHERE {wc} AND record_status != 'HIDE'
                ) WHERE {excl_clause}
            """
            res = conn.execute(sql).fetchone()
            if with_vv:
                return (int(res[0]), int(res[1] or 0)) if res else (0, 0)
            return int(res[0]) if res else 0
        except:
            return (0, 0) if with_vv else 0
        finally:
            if is_internal: conn.close()

    def _p4_body_chars(self):
        """구절 본문 폭(글자 수)을 **가로 간격에서 자동 산출** (2026-09-01 0.txt 2번).

        본문은 박스 오른쪽(x + half_w + 5)에서 시작해 다음 열(x + h_gap)의
        박스 왼쪽 절반 앞에서 끝나야 다음 구절을 덮지 않는다:
          사용 px = 가로간격 − 제 박스 오른쪽 절반 − 시작 여백 − 다음 박스 왼쪽 절반 − 여유
        글자 수 = px ÷ 한글 한 자 실측 폭. 대표 박스는 구절 약명(「창12:34」)으로 잰다.
        ⚠ 글꼴 폭을 어림 상수로 박지 않는다 — 크기·글꼴을 바꾸면 함께 틀어진다.
        측정 결과는 (글꼴, 크기, 간격) 열쇠로 캐시한다(노드마다 부르는 함수다)."""
        fam = getattr(self, 'cfg_font_family', 'Malgun Gothic')
        size = int(getattr(self, 'cfg_font_size', 9) or 9)
        gap = int(getattr(self, 'cfg_h_gap', 300) or 300)
        key = (fam, size, gap)
        cached = getattr(self, '_body_chars_cache', None)
        if cached and cached[0] == key:
            return cached[1]
        try:
            import tkinter.font as tkfont
            cjk = max(6, tkfont.Font(family=fam, size=size).measure('한'))
            half_box = tkfont.Font(family=fam, size=size, weight='bold').measure('창12:34') // 2 + 8
            # 여유 = 두 글자 폭 (2026-09-01 사용자 실측 신고 「아직도 글자가
            # 1~2개 정도 가려진다」 — 박스 폭이 약명 길이마다 달라 어림 상수
            # 만으로는 긴 약명에서 넘쳤다. 두 글자를 더 비워 둔다.)
            avail = gap - half_box * 2 - 5 - 12 - cjk * 2
            chars = max(8, min(80, avail // cjk))
        except Exception:
            chars = 20
        self._body_chars_cache = (key, chars)
        return chars

    def _truncate_text(self, text):
        """구절 본문을 **전체** 줄바꿈으로 편다 (2026-09-02 0.txt 5-1 사용자
        확정 — 「축약은 절대로 발생해서는 안된다. 가로간격에 닿으면 줄바꿈」).
        폭 = 가로 간격에서 자동 산출(_p4_body_chars) · 줄수 = 저절로.
        세로 겹침은 자동 세로 간격(_child_row_heights)이 막는다."""
        if text is None or not isinstance(text, str): return ""

        import textwrap
        char_width = self._p4_body_chars()
        clean_text = text.replace('\n', ' ').strip()
        if not clean_text: return ""
        return "\n".join(textwrap.wrap(clean_text, width=char_width))

    #: 형제 박스 사이 고정 세로 여백(px ≈ 5mm) — 옵션이 아니라 상수다
    #  (0.txt 5-1 「겹치지 않는 최소한의 간격을 자동으로」)
    V_PAD = 18

    def _child_row_heights(self, texts):
        """자식마다 차지할 세로 높이 — 본문 줄수 기반 (2026-09-02 자동 간격).
        박스 최소 높이(34px)와 본문 높이 중 큰 쪽."""
        try:
            import tkinter.font as tkfont
            lh = tkfont.Font(family=getattr(self, 'cfg_font_family', ''),
                             size=int(getattr(self, 'cfg_font_size', 9) or 9)
                             ).metrics('linespace')
        except Exception:
            lh = 16
        out = []
        for t in texts:
            lines = (t.count('\n') + 1) if t else 1
            out.append(max(34, lines * lh + 6))
        return out

    def _auto_child_pos(self, heights, px, py, base_y=None):
        """자식들의 (nx, ny) 목록 — 높이 합에 맞춰 부모 중심으로 쌓는다.
        base_y 가 있으면(＋ 추가 묶음) 그 아래에서부터 쌓는다."""
        nx = px + getattr(self, 'cfg_h_gap', 300)
        n = len(heights)
        if n == 0:
            return []
        if base_y is not None:
            y = base_y + self.V_PAD
        else:
            total = sum(heights) + self.V_PAD * (n - 1)
            y = py - total / 2
        out = []
        for h in heights:
            out.append((nx, y + h / 2))
            y += h + self.V_PAD
        return out

    def _get_bible_text_for_p4(self, v_id):
        # ★ 합쳐진 절·없는 절도 뜻이 통하게(§verse_text)
        with appdb.connect(self.db_path) as conn:
            return _vt.resolve(conn, v_id, self.ver, self.lang)['text']

    # [2026-06-04] _check_pericope_range 제거 — LINK 페리코프 폐기에 따라 P 마커 사용 안 함.

    def _select_node_in_tree_by_vid(self, target_vid):
        """[신설] 트리뷰 내에서 특정 view_id를 찾아 선택 및 스크롤합니다."""
        def recurse(parent):
            for item in self.focus_tree.get_children(parent):
                if self.focus_tree.item(item, "values")[0] == target_vid:
                    self.focus_tree.selection_set(item)
                    self.focus_tree.see(item)
                    return True
                if recurse(item): return True
            return False
        recurse("")

    def refresh_p4_film_strip(self, asset_id, parent_id=None):
        """[완전수리] 미디어, 본인 정보, 연관 설명, 맵 상태를 하단 패널에 정밀 출력합니다."""
        if not hasattr(self, 'p4_strip_frame'):
            return
        if not self.p4_strip_frame.winfo_exists(): return
        for child in self.p4_strip_frame.winfo_children(): child.destroy()

        with appdb.connect(self.db_path) as conn:
            sql = "SELECT media_type, title, url, lang_code FROM sys_media_asset WHERE verse_id=? ORDER BY sort_order ASC"
            all_media = conn.execute(sql, (asset_id,)).fetchall()
        
        show_all = self.dash_show_all_lang.get()
        filtered_media = []
        for r in all_media:
            if show_all or r[3] == self.lang:
                # 🎯 [핵심] 튜플을 딕셔너리로 변환 (media['title'] 참조 가능하게 함)
                filtered_media.append({'type': r[0], 'title': r[1], 'url': r[2]})
        
        self._create_p4_post_it({'media_list': filtered_media, 'src': 'SYS'}, 
                                "Dashboard", self.p4_strip_frame, is_dash=True, asset_id=asset_id)

        # 🎯 2. [본인 정보] 현재 노드의 성경 본문 및 라벨 사냥
        vid_s = getattr(self, 'last_clicked_vid', None) or f"BIBLE:{asset_id}"
        asset_type = vid_s.split(':')[0]
        info = self._get_asset_info_by_type(asset_id, asset_type)
        
        self._create_p4_post_it({'contents': f"현재: {info['label']}\n\n{info['text']}", 'src': 'SYS'}, 
                                "본인", self.p4_strip_frame)

        # 🎯 3. [연관 설명] 7-Way 매치 데이터 사냥
        for d in self._execute_7way_match(asset_id):
            self._create_p4_post_it(d, "연관 설명", self.p4_strip_frame)

        # 🎯 4. [Map List] 저장된 배치 맵 존재 여부 확인
        with appdb.connect(self.db_path) as conn:
            map_check = conn.execute("SELECT COUNT(*) FROM user_layout_maps WHERE root_id=?", 
                                     (asset_id,)).fetchone()
        
        map_status = f"저장된 맵: {info['label']}\n(수정 가능)" if map_check[0] > 0 else "등록된 배치 맵이 없습니다."
        self._create_p4_post_it({'contents': map_status, 'src': 'SYS'}, "Map List", self.p4_strip_frame)


    # <완성> DB로부터 구절/유닛간의 연결 데이터를 3가지 옵션에 따라 검색하여 방향성에 따라 추출하여 SYS와 USER 데이터 통합
    # ── 캔버스 표시 상한·점수 (2026-08-26 ③, 확정 설계 = 할일 13-46) ──────
    def _link_rank_cols(self, conn):
        """(sys rank_score 칼럼 유무, userdb.user_link_rank 표 유무) — 1회 캐시.

        배포 DB 교체 직후에는 rank_score 칼럼이 없을 수 있다 — 짐작하지 말고
        스키마에 묻는다(§0-5). 없으면 NULL 로 흘려 화면이 죽지 않는다."""
        c = getattr(self, '_rankcol_cache', None)
        if c is None:
            try:
                has_sys = any(r[1] == 'rank_score'
                              for r in conn.execute("PRAGMA table_info(sys_link_asset)"))
            except Exception:
                has_sys = False
            try:
                has_usr = bool(conn.execute(
                    "SELECT 1 FROM userdb.sqlite_master WHERE type='table'"
                    " AND name='user_link_rank'").fetchone())
            except Exception:
                has_usr = False
            c = (has_sys, has_usr)
            self._rankcol_cache = c
        return c

    def _canvas_link_limit(self):
        """캔버스 VERS_VERS 자식 표시 상한 — 1~10 · 기본 10 (사용자 확정:
        「10개 이상은 표시하기 너무 복잡하다. 입력숫자를 10 이하로 제한」).
        입력은 무제한, **캔버스 표시만** 제한한다(13-46)."""
        v = getattr(self, '_link_limit', None)
        if v is None:
            v = 10
            try:
                with appdb.connect(self.db_path) as conn:
                    r = conn.execute("SELECT config_val FROM user_config"
                                     " WHERE config_key='CANVAS_LINK_LIMIT'").fetchone()
                if r:
                    v = int(r[0])
            except Exception:
                pass
            v = max(1, min(10, v))
            self._link_limit = v
        return v

    def _set_canvas_link_limit(self, v):
        try:
            v = max(1, min(10, int(v)))
        except Exception:
            return
        self._link_limit = v
        try:
            with appdb.connect(self.db_path) as conn:
                cur = conn.execute("UPDATE user_config SET config_val=?"
                                   " WHERE config_key='CANVAS_LINK_LIMIT'", (str(v),))
                if cur.rowcount == 0:
                    conn.execute("INSERT INTO user_config(config_key,config_val)"
                                 " VALUES('CANVAS_LINK_LIMIT',?)", (str(v),))
                conn.commit()
        except Exception as e:
            print(f'[link limit] save error: {e}')
        # ★ 즉시 반영 (2026-09-02 사용자 신고 「최대표시갯수 수정한 경우 등
        #   즉시 캔버스가 바뀌지 않는 것이 있다」) — 배지 숫자만 고치고 이미
        #   펼쳐진 묶음은 옛 상한 그대로였다. 대상(scope)·점수표 재계산과 같은
        #   길(_reload_p4_canvas_if_any)로 지금 맵을 새 상한으로 다시 그린다.
        self._refresh_all_badges()
        self._reload_p4_canvas_if_any()

    def _fetch_links_integrated(self, parent_id, parent_type):
        """[최종완결] parent_id(BIBLE:1_v1 등)에서 순수 숫자(1)를 추출하여 DB 사냥을 성공시킵니다."""
        # 1. 🎯 ID 정규화: 문자열에서 순수 숫자(Pure ID)만 정밀 추출
        # 콤보박스나 캔버스에서 넘어오는 "BIBLE:1", "BIBLE:1_v1" 등을 모두 순수 정수(1)로 변환합니다.
        try:
            # 🎯 [수리] 기존 split('_v')를 split('@')으로 교체합니다.
            pure_id = int(str(parent_id).split('@')[0].split(':')[-1])
        except (ValueError, IndexError):
            return []

        # 2. 범위(Scope) — 통합 뒤 화면이 하나라 scope_t1_var 하나만 본다(2026-08-12)
        scope = self.scope_t1_var.get()
        
        allowed_types = ["'VERS_VERS'"]
        if scope >= 2: allowed_types.append("'NODE_VERS'")
        if scope >= 3: allowed_types.append("'CONT_NODE'")
        type_filter = f"AND link_type IN ({', '.join(allowed_types)})"

        # 🎯 [신설 2026-06-01] VERS_VERS 등급 필터 (A=핵심 / AB=+확장 / ABC=+참조)
        tier_str = getattr(self, 'link_tier_var', None)
        tier_val = tier_str.get() if tier_str is not None else 'AB'
        if tier_val not in ('A', 'AB', 'ABC'):
            tier_val = 'AB'
        tier_in = ','.join(f"'{c}'" for c in tier_val)
        vv_tier_filter = (
            f"AND (link_type != 'VERS_VERS' OR rel_code IN "
            f"(SELECT DISTINCT rel_code FROM sys_rel_catalog WHERE rel_tier IN ({tier_in})))"
        )

        # 3. 🎯 타겟 신분 판별기 (수정: 모든 'CONT'를 'CONTAINER'로 통합 대응)
        def identify_target(s_type, l_type):
            norm_s = 'CONTAINER' if s_type in ['CONT', 'CONTAINER'] else s_type
            if l_type == 'VERS_VERS': return 'BIBLE'
            if l_type == 'NODE_VERS': return 'NODE' if norm_s == 'BIBLE' else 'BIBLE'
            if l_type == 'CONT_NODE': return 'NODE' if norm_s == 'CONTAINER' else 'CONTAINER'
            return 'UNKNOWN'

        # 4. 🎯 신분별 SQL Where 절 구성 (pure_id 적용)
        if parent_type == 'BIBLE':
            wc = f"((link_type='VERS_VERS' AND (clicked_id=? OR target_id=?)) OR (link_type='NODE_VERS' AND target_id=?)) {type_filter} {vv_tier_filter}"
            params = [pure_id, pure_id, pure_id]
        elif parent_type == 'NODE':
            wc = f"((link_type='NODE_VERS' AND clicked_id=?) OR (link_type='CONT_NODE' AND target_id=?)) {type_filter} {vv_tier_filter}"
            params = [pure_id, pure_id]
        else: # CONTAINER
            wc = f"(link_type='CONT_NODE' AND clicked_id=?) {type_filter} {vv_tier_filter}"
            params = [pure_id]

        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                # 5. 🎯 [수리] NOT IN 로직: EDIT(수정) 데이터가 원본 SYS 데이터를 가리도록 배선 (중복 방지)
                # 🎯 [버그fix 2026-06-01] sys_rel_catalog JOIN 에 lang_code 누락 → 임의 행(ZH 등) 매칭됨
                lang = (getattr(self, 'lang', 'KO') or 'KO').upper()
                # ★ 연결 점수(2026-08-26 ③ 캔버스 표시) — sys 는 rank_score 칸,
                #   user 는 userdb.user_link_rank(자연 열쇠) 조회. **칼럼·표가
                #   없는 DB(배포 직후·시험 DB)에서도 죽지 않게** PRAGMA 로 먼저
                #   물어보고 없으면 NULL 을 싣는다(§0-5 「스키마에 묻는다」).
                has_sys_rank, has_usr_rank = self._link_rank_cols(conn)
                sys_rs = "rank_score" if has_sys_rank else "NULL"
                if has_usr_rank:
                    # ★ 개인 점수가 있으면 그것이 이긴다 (2026-08-26 중요도
                    #   설정 — 사용자가 배점을 바꾸면 user_link_rank 에 자연
                    #   열쇠로 재계산돼 담기고, 없으면 sys 기본 점수).
                    sys_rs = ("COALESCE((SELECT r.score FROM user_link_rank r"
                              " WHERE r.link_type=s.link_type"
                              " AND r.clicked_id=s.clicked_id"
                              " AND r.target_id=s.target_id"
                              " AND r.rel_key=COALESCE(s.rel_code,'')"
                              " AND r.end_key=COALESCE(s.end_id,s.target_id)),"
                              " %s)" % sys_rs)
                usr_rs = ("(SELECT r.score FROM user_link_rank r"
                          " WHERE r.link_type=u.link_type AND r.clicked_id=u.clicked_id"
                          " AND r.target_id=u.target_id"
                          " AND r.rel_key=COALESCE(u.rel_code,'')"
                          " AND r.end_key=COALESCE(u.end_id,u.target_id))"
                          ) if has_usr_rank else "NULL"
                # ★ 덮개 가림 (2026-08-26 읽기 배선) — 자연 열쇠가 같은 user
                #   HIDE 행이 있으면 그 sys 연결은 안 그린다(overlay.LinkOverlay
                #   와 같은 규칙 — E 팝업에서 숨긴 것이 캔버스에서도 사라진다).
                #   ⚠ 옛 origin_id(PK) 제외만으로는 가림이 안 걸렸다(1단계
                #   엔진만 만들고 이 읽기 길을 안 이었던 자리).
                # ★ sys 링크 자신의 상태(2026-09-09 덮개 전수 조사 — 이 조건이 없어
                #   관리자가 걷은(HIDE)·후보(PEND) 연결이 캔버스에 그대로 펼쳐졌다)
                nk_hide = (" AND COALESCE(s.record_status,'LIVE')='LIVE'"
                           " AND NOT EXISTS (SELECT 1 FROM user_link_asset h"
                           " WHERE h.record_status='HIDE'"
                           " AND h.link_type=s.link_type"
                           " AND h.clicked_id=s.clicked_id"
                           " AND h.target_id=s.target_id"
                           " AND COALESCE(h.rel_code,'')=COALESCE(s.rel_code,'')"
                           " AND COALESCE(h.end_id,h.target_id)"
                           "     =COALESCE(s.end_id,s.target_id))")
                sql = f"""
                    SELECT L.*, R.rel_name FROM (
                        SELECT CASE WHEN clicked_id=? THEN target_id ELSE clicked_id END as t_id,
                               link_type, rel_code, {sys_rs} AS rscore FROM sys_link_asset s
                        WHERE {wc} AND sys_link_id NOT IN (SELECT origin_id FROM user_link_asset WHERE origin_id IS NOT NULL)
                        {nk_hide}
                        UNION ALL
                        SELECT CASE WHEN clicked_id=? THEN target_id ELSE clicked_id END as t_id,
                               link_type, rel_code, {usr_rs} AS rscore FROM user_link_asset u
                        WHERE {wc} AND record_status != 'HIDE'
                    ) L
                    LEFT JOIN sys_rel_catalog R ON L.rel_code = R.rel_code AND R.lang_code = ?
                """
                # UNION 전후에 pure_id와 params가 각각 필요하므로 물리적 순서 엄수
                final_params = [pure_id] + params + [pure_id] + params + [lang]
                rows = conn.execute(sql, final_params).fetchall()
                
                # ★ 같은 상대는 한 자식으로 접는다 (2026-08-20 배치 점검에서 잡음).
                #   한 구절 짝에 rel_code 가 여러 행(다중 관점 — §28-1 PRG+TYP 등)
                #   이면 행마다 자식 슬롯을 차지하는데, 노드 view id 는 같아서
                #   덮어써지고 **그 슬롯 자리가 뻥 뚫렸다**(간격 100·200·300 실측,
                #   중앙 정렬도 뒤로 밀림). 배지(_get_child_count)는 원래
                #   COUNT(DISTINCT) 라 이 목록만 어긋나 있었다.
                #   관점 라벨은 버리지 않고 '·' 로 이어 함께 보인다.
                results = []
                by_identity = {}
                for r in rows:
                    t_id, l_type = r['t_id'], r['link_type']
                    t_type = identify_target(parent_type, l_type)
                    # 🎯 타입이 불분명할 경우 DB 실측 사냥
                    if t_type == 'UNKNOWN':
                        check = conn.execute("SELECT unit_type FROM sys_unit_asset WHERE sys_unit_id=?", (t_id,)).fetchone()
                        t_type = check[0] if check else 'BIBLE'

                    display_rel = str(r['rel_name'] or "") if l_type == 'VERS_VERS' else ""
                    try:
                        sc = r['rscore']
                    except Exception:
                        sc = None
                    key = (t_type, t_id)
                    if key in by_identity:
                        prev = by_identity[key]
                        if display_rel and display_rel not in prev['rel_name']:
                            prev['rel_name'] = (prev['rel_name'] + '·' + display_rel
                                                ) if prev['rel_name'] else display_rel
                        # 다중 관점 행이 접힐 때 점수는 **최고값**을 남긴다
                        if sc is not None and (prev.get('score') is None or sc > prev['score']):
                            prev['score'] = sc
                        continue
                    item = {'target_id': t_id, 'target_type': t_type,
                            'link_type': l_type, 'rel_name': display_rel,
                            'score': sc}
                    by_identity[key] = item
                    results.append(item)
                return results
        except Exception as e:
            print(f"DEBUG Error: {e}"); return []

    # ── P4 설명 탭 「이 구절의 연결」 접힘줄 (2026-08-21 `0.txt` 4번) ─────
    def _fold_children(self, view_id):
        """지금 옵션이 허용하는 **이웃 목록** → [{key, label, rel}].

        > 「부모구절 클릭하고 설명 탭에서 연결설명 접힘 줄 클릭하면 자녀들과
        >  연결설명문을 열거하는 기능」 (사용자)

        ★ **표시 범위는 옵션(범위·등급)을 그대로 따른다** — 캔버스 펼치기와
          같은 문(`_get_valid_links_with_utility`)을 쓴다. 두 길이 다른 규칙을
          쓰면 「배지는 6인데 줄은 9」가 된다(45차에서 겪은 그것).
        ⚠ 부모는 뺀다 — 부모와의 연결설명문은 이미 이 탭 맨 위에 있다.
        """
        out = []
        try:
            info = (getattr(self, 'p4_view', None)
                    and self.p4_view.nodes.get(view_id)) or None
            if not info:
                return out
            v_t, _v_n = self._split_logic_id(info['node_id'])
            for L in self._get_valid_links_with_utility(
                    info['node_id'], v_t, p_vid=info.get('p_id')):
                t_t, t_id = L['target_type'], L['target_id']
                out.append({'key': '%s:%s' % (t_t, t_id),
                            'label': (self.get_asset_name(t_id, t_t)
                                      or str(t_id)),
                            'rel': str(L.get('rel_name') or '')})
        except Exception as e:
            print('[fold children] %s' % e)
        return out

    def _ai_link_analyze(self, view_id, key):
        """★ 2026-10-14 접힘줄의 연결 하나 [AI 분석] — P4 AI 도우미에서 「연결 살펴보기」로 바로 묻는다."""
        try:
            info = (getattr(self, 'p4_view', None) and self.p4_view.nodes.get(view_id)) or None
            if not info:
                return
            v_t, v_n = self._split_logic_id(info['node_id'])
            a_id = int(str(v_n).split('@')[0].split(':')[-1])
            t_id = int(str(key).split(':')[1])
            with appdb.connect(self.db_path) as conn:
                r = conn.execute(
                    "SELECT sys_link_id FROM sys_link_asset WHERE link_type='VERS_VERS' AND record_status='LIVE'"
                    " AND ((clicked_id=? AND target_id=?) OR (clicked_id=? AND target_id=?))"
                    " ORDER BY sys_link_id LIMIT 1", (a_id, t_id, t_id, a_id)).fetchone()
            if not r:
                return
            self._ensure_p4_tab_built(self.P4['ai'])
            self.p4_nb.select(self.p4_t13_f)
            v = getattr(self, 'ai_chat_view', None)
            if v is not None:
                v.analyze_link_now(int(r[0]), a_id)
        except Exception as e:
            print('_ai_link_analyze(%s): %s' % (key, e))

    def _fold_link_desc(self, view_id, key):
        """그 이웃 하나와의 **연결설명문**. 없으면 빈 문자열.

        ⚠ 자산 종류마다 설명문이 매달린 곳이 다르다 — VERS_VERS 는 **링크
          번호**, NODE_VERS 는 **노드 번호**, CONT_NODE 는 **컨테이너 번호**
          (`_fetch_combined_desc` 와 같은 규칙. 한 곳만 보면 절반이 빈다).
        """
        try:
            info = (getattr(self, 'p4_view', None)
                    and self.p4_view.nodes.get(view_id)) or None
            if not info:
                return ''
            v_t, v_n = self._split_logic_id(info['node_id'])
            a_id = int(str(v_n).split('@')[0].split(':')[-1])
            t_t, t_id = str(key).split(':')
            t_id = int(t_id)
            lang = self._desc_lang()
            rows, seen = [], set()
            with appdb.connect(self.db_path) as conn:
                if v_t == 'BIBLE' and t_t == 'BIBLE':
                    lids = [r[0] for r in conn.execute(
                        "SELECT sys_link_id FROM sys_link_asset "
                        " WHERE link_type='VERS_VERS' AND record_status='LIVE' "
                        "   AND ((clicked_id=? AND target_id=?) "
                        "     OR (clicked_id=? AND target_id=?))",
                        (a_id, t_id, t_id, a_id))]
                    for lid in lids:
                        for row in self._text_with_view_model(
                                conn, lid, 'VERS_VERS_DESC', lang):
                            rows.append(row)
                else:
                    if 'NODE' in (v_t, t_t) and 'BIBLE' in (v_t, t_t):
                        tt, cid = 'NODE_VERS_DESC', (a_id if v_t == 'NODE' else t_id)
                    else:                       # CONTAINER ↔ NODE
                        tt, cid = 'CONT_NODE_DESC', (a_id if v_t == 'CONTAINER'
                                                     else t_id)
                    rows = self._text_with_view_model(conn, cid, tt, lang)
            out = []
            for r in rows:
                s = (r[1] or '').strip()
                if s and s not in seen:
                    seen.add(s)
                    out.append(s)
            return '\n'.join(out)
        except Exception as e:
            print('[fold desc] %s' % e)
            return ''

    def _get_unit_info_direct(self, tid):
        """[철칙] 추측하지 말고 DB의 unit_type을 직접 사냥하여 신분을 확인합니다."""
        with appdb.connect(self.db_path) as conn:
            # 🎯 [자산맵 규격] user와 sys 테이블에서 unit_type을 통합 사냥합니다.
            sql = """
                SELECT unit_type FROM user_unit_asset WHERE user_unit_id = ?
                UNION
                SELECT unit_type FROM sys_unit_asset WHERE sys_unit_id = ?
            """
            row = conn.execute(sql, (tid, tid)).fetchone()
            if row:
                u_type = row[0]
                # 사용자 읽기 편하게 신분 명칭 변환
                type_map = {'CONTAINER': '컨테이너', 'NODE': '노드'}
                return {'type_name': type_map.get(u_type, u_type)}
            return {'type_name': '유닛'}

    def _fetch_link_specific_desc(self, p_id, c_id):
        """[철칙] 두 자산 사이의 '링크'에 정의된 고유 설명을 자산맵에서 사냥합니다."""
        conn = appdb.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        sql = """
            SELECT contents, 'LINK_DESC' as text_type, 'SYS' as src FROM sys_text_asset 
            WHERE COALESCE(record_status,'LIVE')='LIVE'
              AND clicked_id IN (SELECT sys_link_id FROM sys_link_asset WHERE clicked_id=? AND target_id=?
                                 AND COALESCE(record_status,'LIVE')='LIVE')
            UNION ALL
            SELECT contents, 'LINK_DESC' as text_type, 'USER' as src FROM user_text_asset 
            WHERE clicked_id IN (SELECT user_link_id FROM user_link_asset WHERE clicked_id=? AND target_id=?)
        """
        try:
            rows = conn.execute(sql, (p_id, c_id, p_id, c_id)).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()

    def _create_p4_post_it(self, data, tag, parent, is_dash=False, asset_id=None):
        """[최종수리] 클릭 가능한 하이퍼링크와 다국어 토글 버튼을 지원합니다."""
        bg_color = '#D1F2EB' if is_dash else '#FDFDFD'
        
        f = tk.Frame(parent, width=300, height=170, bg=bg_color, bd=1, relief='solid')
        f.pack(side='left', padx=10, pady=5); f.pack_propagate(False)

        # 🎯 [요구 해결] 대시보드 상단 헤더 영역 구성 [cite: 2026-03-25]
        header = tk.Frame(f, bg=bg_color)
        header.pack(fill='x', padx=5, pady=2)
        
        tk.Label(header, text=f"【 {tag} 】", bg=bg_color, font=("Malgun Gothic", 9, "bold")).pack(side='left')
        
        if is_dash:
            # 🎯 다국어 선택 토글 버튼 (가장 오른쪽에 배치) [cite: 2026-03-25]
            chk = tk.Checkbutton(header, text="Global", variable=self.dash_show_all_lang, 
                                 command=lambda: self.refresh_p4_film_strip(asset_id),
                                 bg=bg_color, font=("Consolas", 8), activebackground=bg_color)
            chk.pack(side='right')

        # 지능형 스크롤바와 텍스트 위젯 배선 [cite: 2026-03-25]
        s_bar = tk.Scrollbar(f, orient="vertical")
        t = tk.Text(f, bg=bg_color, bd=0, font=("Malgun Gothic", 10), cursor="hand2", yscrollcommand=s_bar.set)
        
        if is_dash:
            # 🎯 [요구 해결] title만 표시하고 하이퍼링크 태그를 심습니다. [cite: 2026-03-25]
            for media in data.get('media_list', []):
                start_idx = t.index(tk.INSERT)
                t.insert(tk.INSERT, f"▶ {media['title']}\n\n")
                end_idx = t.index(tk.INSERT + "-2c") # 줄바꿈 제외
                
                # 클릭 이벤트 태그 바인딩 [cite: 2026-03-25]
                tag_name = f"link_{media['title']}"
                t.tag_add(tag_name, start_idx, end_idx)
                t.tag_config(tag_name, foreground="#2E86C1", underline=True)
                t.tag_bind(tag_name, "<Button-1>", lambda e, url=media['url']: webbrowser.open(url))
        else:
            t.insert('1.0', str(data.get('contents', i18n.t('MSG_NO_CONTENT', '내용 없음'))))

        t.config(state='disabled')
        t.pack(side="left", expand=True, fill='both', padx=10)

    def _journey_precision_monitor(self, stage_name, data):
        """[진단] 여정 데이터의 상태를 단계별로 감시하여 콘솔에 출력합니다."""
        print(f"\n{'='*20} [STAGE: {stage_name}] {'='*20}")
        print(f"📊 Current Journey List: {data}")
        print(f"📏 List Length: {len(data) if data else 0}")
        if data:
            print(f"📍 Last Footprint (Current): {data[-1]}")
        print(f"{'='*50}\n")

    def _verify_lineage_engine(self, view_id):
        """[진단] 계보 계산 엔진이 조상을 제대로 찾는지 검증합니다."""
        lineage = self._calculate_id_lineage(view_id)
        print(f"🧬 Lineage Trace for {view_id}: {' ➔ '.join(lineage)}")
        return lineage

    def _on_tree_select_focus(self, event):
        # 트리 재구성 중 programmatic selection_set이 유발한 이벤트는 무시
        if getattr(self, '_is_populating_tree', False): return
        sel = self.focus_tree.selection()
        if not sel: return

        v_id = self.focus_tree.item(sel[0], "values")[0]
        # ★ 2026-10-07 (51-1) — 자리표 줄. 「＋ 다음 묶음」은 누르면 펼치고, 「…」는
        #   부모 줄을 연 것과 같다(▸ 를 놓치고 줄을 누른 사람도 펼쳐진다).
        if str(v_id).startswith('__PLUS__'):
            self.after_idle(lambda p=str(v_id)[8:]: self._tree_plus(p))
            return
        if str(v_id).startswith('__EXPAND__'):
            self.after_idle(lambda p=str(v_id)[10:]: self._tree_expand(p))
            return
        if self._sync_diagnostics_monitor("Tree_Select", v_id): return

        if getattr(self, 'is_syncing', False): return

        # ★ **메아리 차단** (2026-08-20) — 캔버스 박스를 누르면 트리를 다시
        #   그리며 그 노드를 선택하는데, 그 `<<TreeviewSelect>>` 가 핸들러
        #   복구 뒤에 뒤늦게 도착해 **여기서 시점을 옮겼다**(실측 440px —
        #   사용자 「과거 박스가 왼쪽으로 자동이동해 맥락을 놓친다」).
        #   방금 캔버스에서 누른 그 노드면 할 일이 없다.
        if v_id == getattr(self, '_last_canvas_click_vid', None):
            self._last_canvas_click_vid = None
            return

        info = self.p4_view.nodes.get(v_id)
        if info:
            try:
                self.is_syncing = True

                self._auto_focus(info['x'], info['y'])   # 「고정」이면 안 움직인다
                # ★ **트리 선택은 읽기다 — 펼치지 않는다** (2026-08-20 사용자 설계
                #   「펼치는 것과 읽는 것을 분리」). 여기서 펼치던 것이
                #   **박스를 클릭했을 뿐인데 자녀가 쏟아지던 우회로**였다:
                #   박스 클릭 → on_node_click → 트리 동기화 → 그때 건 selection_set
                #   이 남긴 <<TreeviewSelect>> 가 **핸들러 복구 뒤에 발화** →
                #   여기서 펼침(실측 스택으로 확인, 노드 12→19).
                #   ⚠ 옛 주석은 `update_idletasks()` 가 그 이벤트를 비운다고 했지만
                #     **가상 이벤트는 idle 처리로 안 빠진다** — 막지 못했다.
                #   트리는 캔버스를 비추는 거울이라 여기서 펼칠 이유도 없다.
                #   펼치기는 **배지 클릭**뿐이다.
                # 오른쪽 패널을 NodePanel 하나로 통합했다(2026-08-12).
                # `show_node` 가 설명(=`_fetch_combined_desc`) · 주석 · 내부자료 · 링크 ·
                # 묵상노트 · 페리코프를 한꺼번에 채우므로, 예전처럼 위젯을 하나씩
                # 골라 `load()` 할 필요가 없다.
                panel = getattr(self, 'p4_node_panel', None)
                if panel is not None:
                    try:
                        panel.show_node(v_id)
                    except Exception as _fe:
                        print(f'[tree→NodePanel] {_fe}')
                # _populate_focus_tree_root 호출 제거:
                # 트리 아이템을 클릭했을 때는 트리가 이미 올바른 상태이므로 재구성 불필요.
                # 재구성하면 selection_set → <<TreeviewSelect>> → 이 함수 재진입 → 무한루프 발생.
                # 대신 브레드크럼만 갱신한다.
                self._update_focus_breadcrumbs(v_id)

            finally:
                self.after(100, lambda: setattr(self, 'is_syncing', False))

    def _setup_pure_treeview(self, parent):
        # ★★★ 2026-10-11 (docs/1.txt 2) — `ttk.Treeview` 를 걷고 **줄바꿈이 되는 글상자 나무**로
        #   (`text_tree.TextTree`). Treeview 는 줄바꿈을 못 해 본문이 잘렸다(사용자 「P1 구절 본문
        #   화면처럼 줄바꿈」) · 줄 = 관계명 (약명) 본문 · 단계 바탕색 고정값을 걷었다(어두운 화면색에서
        #   펼칠 때 반전처럼 보이던 자리). ⚠ Treeview 와 같은 말을 받으므로 캔버스↔트리 연동 코드는 그대로다.
        from text_tree import TextTree
        tree_frame = tk.Frame(parent)
        tree_frame.pack(expand=True, fill='both')
        self.focus_tree = TextTree(tree_frame, self.db_path, font_scope='list')
        self.focus_tree.pack(expand=True, fill='both')

        self.focus_tree.bind("<<TreeviewSelect>>", self._on_tree_select_focus)
        self.focus_tree.bind("<Double-1>", self._on_tree_select_focus)
        # ★ 2026-10-07 (51-1) — ▸ 를 누르면 캔버스 지도에 펼친다 · ▾ 는 보기만 접는다
        self.focus_tree.bind("<<TreeviewOpen>>", self._on_tree_open)
        self.focus_tree.bind("<<TreeviewClose>>", self._on_tree_close)

    def _on_badge_expand(self, node_id, view_id):
        """배지 클릭 — **자녀만 펼친다. 탭모음은 건드리지 않는다.**

        사용자 설계(2026-08-20): 「아버지 배지를 클릭하면 여전히 아버지 중심의
        설명문이 유지되지만, 자녀들이 펼쳐지고 자녀 중 하나를 클릭하기 전에는
        그 상태가 유지된다」 — 펼치는 것과 읽는 것의 분리.
        ⚠ 그래서 `on_node_click`(여정·저장·탭모음 갱신)을 부르지 않는다.
        """
        info = self.p4_view.nodes.get(view_id)
        if not info:
            return
        # ★ **배지 클릭도 Journey 를 옮긴다** (2026-08-20 사용자 지시 —
        #   「배지를 클릭할 때 맵이 반응해야 한다」).
        #   Journey 는 **지금 작업 중인 자리**(루트→그 노드의 조상 사슬)다.
        #   맵의 모양을 바꾸는 것은 오직 배지(펼침)인데 여정만 박스 클릭을
        #   따르고 있어, 배지로 한참 펼쳐 놓아도 라벨과 `path_string` 이
        #   **마지막으로 읽은 구절**에 멈춰 있었다(실측 — 저장 노드는 12→29 로
        #   늘었는데 path 는 그대로). 그래서 맵 목록의 「종착 약명」과 자동
        #   이름 제안이 실제 도달점과 어긋났다.
        #   ⚠ 탭모음(읽기)은 그대로 둔다 — 47차 「읽기와 펼치기 분리」는 유지.
        lineage = self._calculate_id_lineage(view_id)
        if lineage:
            self.current_journey_list = list(reversed(lineage))
        self._update_journey_ticker()
        # ★ 이미 펼쳐진 **잘린** 노드의 배지를 다시 누르면 = **통째로 접기**
        #   (2026-09-02 사용자 확정 — 다음 묶음은 박스 바깥 ＋ 가 맡는다.
        #   − 는 한 층씩, 배지 재클릭은 전부 — 되돌리는 길이 둘이고 겹치지
        #   않는다). 옛 「재클릭 = 다음 묶음 교체」는 ± 신설로 폐기.
        meta = (getattr(self, '_p4_page_meta', None) or {}).get(str(view_id))
        if meta and any(str(x.get('p_id')) == str(view_id)
                        for x in self.p4_view.nodes.values()):
            self._collapse_children(view_id)
            return
        v_t, v_n = self._split_logic_id(info.get('node_id'))
        # 저장은 여기서 하지 않는다 — 펼침 끝에서 `_safe_auto_save_workbench`
        # 가 **새 여정과 새 노드를 함께** 기록한다(두 번 쓰지 않는다).
        self.handle_p4_node_click(v_n, v_t, info['x'], info['y'],
                                  p_view_id=view_id)

    def _parent_kids(self, view_id):
        """이 부모에 붙어 있는 자식 view_id 목록."""
        return [cid for cid, d in self.p4_view.nodes.items()
                if str(d.get('p_id')) == str(view_id)]

    def _parent_more_left(self, view_id):
        """이 부모에게 **아직 화면에 없는** 자식이 몇 남았나 — ＋ 깃발의 잣대.

        펼침 4.5 의 valid_children 과 같은 규칙(조상·화면 제외)으로 센다 —
        다른 규칙으로 세면 「＋를 눌렀는데 아무것도 안 나온다」가 된다."""
        info = self.p4_view.nodes.get(view_id)
        if not info:
            return 0
        try:
            v_t, v_n = self._split_logic_id(info.get('node_id'))
            shown = set()
            for _i in self.p4_view.nodes.values():
                _t, _n = self._split_logic_id(_i.get('node_id'))
                shown.add(f"{_t}:{_n}")
            anc = set()
            for vid in self._calculate_id_lineage(view_id):
                if vid in self.p4_view.nodes:
                    anc.add(self.p4_view.nodes[vid]['node_id'])
            raw = self._fetch_links_integrated(v_n, v_t)
            return sum(1 for L in raw
                       if f"{L['target_type']}:{L['target_id']}" not in anc
                       and f"{L['target_type']}:{L['target_id']}" not in shown)
        except Exception:
            return 0

    def _sync_parent_batch_badge(self, view_id):
        """잘린 부모의 배지 = **「펼친 수 ↵ /전체」 누적 표기** + 바깥 ±
        (2026-09-02 사용자 확정 — 추가 방식이라 구간(11~20)이 아니라 누적).
        ＋ = 남은 자식이 있을 때만 · − = 추가로 펼친 층이 있을 때만."""
        meta = (getattr(self, '_p4_page_meta', None) or {}).get(str(view_id))
        if not meta:
            return
        shown_kids = len(self._parent_kids(view_id))
        layers = (getattr(self, '_p4_layers', None) or {}).get(str(view_id)) or []
        more = self._parent_more_left(view_id)
        self.p4_view.update_badge(
            view_id, shown_kids,
            text='%d\n/%d' % (shown_kids, meta['grand']),
            plus=(more > 0), minus=bool(layers))

    def _on_plus_next(self, node_id, view_id):
        """＋ 클릭 = **다음 묶음을 아래에 추가** (2026-09-02 사용자 확정 —
        0.txt 5번 「이미 펼쳐진 구절박스 아래에 추가로 펼친다면 기존에 펼쳐진
        구절과의 관계도 동시에 보여진다」. 옛 「교체」 방식 폐기).

        걷는 길은 둘 — − 가 마지막 층만, 배지 재클릭이 전부.
        층 장부(`_p4_layers`)에 이번에 추가된 view_id 들을 쌓아 − 가 쓴다."""
        info = self.p4_view.nodes.get(view_id)
        meta = (getattr(self, '_p4_page_meta', None) or {}).get(str(view_id))
        if not info or not meta:
            return
        before = set(self._parent_kids(view_id))
        v_t, v_n = self._split_logic_id(info.get('node_id'))
        # valid_children 이 「화면에 없는 것」에서 뽑히므로 page=0 이 곧 다음 묶음
        self.handle_p4_node_click(v_n, v_t, info['x'], info['y'],
                                  p_view_id=view_id, page=0, append_below=True)
        new = [cid for cid in self._parent_kids(view_id) if cid not in before]
        if new:
            layer_map = getattr(self, '_p4_layers', None)
            if layer_map is None:
                layer_map = self._p4_layers = {}
            layer_map.setdefault(str(view_id), []).append(new)
        self._sync_parent_batch_badge(view_id)

    def _on_minus_prev(self, node_id, view_id):
        """− 클릭 = **마지막에 추가한 묶음만 걷기** (2026-09-02 사용자 확정 A안).

        ⚠ §46 보호 — 그 층의 노드라도 **자식을 펼쳐 둔 것은 남긴다.**
          사용자가 파고 들어간 가지를 걷기가 끊으면 안 된다."""
        layer_map = getattr(self, '_p4_layers', None) or {}
        layers = layer_map.get(str(view_id)) or []
        if not layers:
            return
        last = layers.pop()
        kept = []
        for cid in last:
            if cid not in self.p4_view.nodes:
                continue
            has_kids = any(str(x.get('p_id')) == str(cid)
                           for x in self.p4_view.nodes.values())
            if has_kids:
                kept.append(cid)              # §46 — 펼친 가지는 남긴다
            else:
                self.p4_view.remove_descendants(cid)
        if kept:
            layers.append(kept)               # 남은 것은 층으로 되돌린다
        if not layers:
            layer_map.pop(str(view_id), None)
        self.p4_view.redraw_edges()
        self._refresh_all_badges()
        self._sync_parent_batch_badge(view_id)
        self._safe_auto_save_workbench()

    def _collapse_children(self, view_id):
        """배지 재클릭 = **이 부모의 자식 전부 접기** (2026-09-02 사용자 확정 —
        − 는 한 층씩, 이것은 통째로. 하위 가지까지 함께 접는다)."""
        for cid in self._parent_kids(view_id):
            self.p4_view.remove_descendants(cid)
        (getattr(self, '_p4_layers', None) or {}).pop(str(view_id), None)
        (getattr(self, '_p4_page_meta', None) or {}).pop(str(view_id), None)
        (getattr(self, '_p4_badge_fix', None) or {}).pop(str(view_id), None)
        self.p4_view.redraw_edges()
        self._refresh_all_badges()
        self._safe_auto_save_workbench()

    def handle_p4_node_double_click(self, node_id, view_id):
        """[수리] 더블 클릭 시 자녀 전개 및 Q&P 서브 박스 노출을 제어합니다."""
        info = self.p4_view.nodes.get(view_id)
        if not info: return

        v_t, v_n = self._split_logic_id(info['node_id'])
        
        # 1. 🧬 [기본] 자녀 노드 전개 효과
        self.handle_p4_node_click(v_n, v_t, info['x'], info['y'], p_view_id=view_id)

        # 캔버스 Q&P 박스 토글 (설명문 표시/숨김)
        qp_tag = f"qp_{view_id}"
        tags = self.p4_view.find_withtag(qp_tag)
        if tags:
            current_state = self.p4_view.itemcget(tags[0], 'state')
            new_state = 'hidden' if current_state in ('normal', '') else 'normal'
            for t in tags:
                self.p4_view.itemconfig(t, state=new_state)

        self._sync_p4_tree_from_canvas()

    # [2026-06-04] handle_peri_click 제거 — P 마커 폐기. 페리코프 탭은 노드 클릭 시 자동 로드.

    def _mirror_canvas_to_tree(self, parent_item, v_id, depth):
        """캔버스의 실시간 상태를 Focus 트리뷰에 복제합니다. note count, P, 자녀 수 포함."""
        nodes = self.p4_view.nodes
        if v_id not in nodes: return

        info = nodes[v_id]
        v_t, v_n = self._split_logic_id(info['node_id'])
        try: pure_n = int(str(v_n).split('@')[0].split(':')[-1])
        except: pure_n = v_n

        name  = self.get_asset_name(pure_n, v_t) or str(pure_n)
        text  = self._get_bible_text_for_p4(pure_n) if v_t == 'BIBLE' else ""
        rel   = info.get('rel_label', "")

        children = [cv for cv, cd in nodes.items() if str(cd.get('p_id')) == str(v_id)]
        disp     = name

        tag = f'depth{depth}'   # ⚠ 바탕색은 박지 않는다(2026-10-11 — 어두운 화면색에서 반전처럼 보였다)

        # [수정 2026-06-01] columns 순서 변경 (rel_name → verse_text 앞)
        new_item = self.focus_tree.insert(parent_item, "end", text=disp,
                                          values=(v_id, rel, text), tags=(tag,))
        # ★ 2026-10-07 (docs/1.txt 51-1) — 접은 줄은 다시 그려도 접힌 채로 둔다.
        #   트리에서 접는 것은 **보기만** 접는다(캔버스 지도는 그대로 — 사용자 확정
        #   「양방향 100% 연동」 · 지우는 일은 캔버스의 −·배지 재클릭이 한다).
        closed = getattr(self, '_tree_closed', set())
        if parent_item:
            self.focus_tree.item(parent_item,
                                 open=str(self.focus_tree.item(parent_item, 'values')[0])
                                 not in closed)

        for c_vid in children:
            self._mirror_canvas_to_tree(new_item, c_vid, depth + 1)

        # ★ 아직 안 펼친 자녀가 있으면 **▸ 를 단다** — 그 자리에 빈 자리표 줄 하나를
        #   넣어야 Tk 가 ▸ 를 그린다. 누르면 `_on_tree_open` 이 캔버스 지도에 펼친다.
        #   잣대는 캔버스 배지 수(장부 `badge`) — 세는 문을 둘로 두지 않는다.
        if not children:
            if (int(info.get('badge') or 0) > 0
                    and str(v_id) not in getattr(self, '_tree_noexpand', set())):
                self.focus_tree.insert(new_item, 'end', text='…',
                                       values=('__EXPAND__' + str(v_id), '', ''))
        else:
            # ★ 잘린 부모(묶음)면 「＋ 다음 묶음」 줄 — 캔버스 박스 바깥 ＋ 와 같은 일
            meta = (getattr(self, '_p4_page_meta', None) or {}).get(str(v_id))
            if meta:
                left = self._parent_more_left(v_id)
                if left > 0:
                    self.focus_tree.insert(
                        new_item, 'end',
                        text='＋ %s (%d)' % (i18n.t('UM_TREE_MORE', '다음 묶음'), left),
                        values=('__PLUS__' + str(v_id), '', ''))

    # 삭제됨: `_load_focus_research_data` (2026-08-12) — 채우던 위젯 `focus_desc_txt` 가
    # 사라졌고 부르는 곳도 없다. 하던 일은 NodePanel `show_node` 안의 `_refresh_desc` 가
    # 그대로 한다(둘 다 `_fetch_combined_desc` 를 쓰고 있었다).

    def _populate_focus_tree_root(self, focus_view_id):
        """[수리] 재진입 방지 플래그로 무한루프를 차단하고 트리뷰를 미러링합니다."""
        if not hasattr(self, 'focus_tree'): return
        if getattr(self, '_is_populating_tree', False): return

        self._sync_diagnostics_monitor("Tree_Populate", focus_view_id)
        self._is_populating_tree = True
        self.focus_tree.bind("<<TreeviewSelect>>", lambda e: "break")

        try:
            self.focus_tree.delete(*self.focus_tree.get_children())

            lineage = self._calculate_id_lineage(focus_view_id)
            true_root_vid = lineage[-1] if lineage else focus_view_id

            self._update_focus_breadcrumbs(focus_view_id)
            self._mirror_canvas_to_tree("", true_root_vid, 0)

            self._select_node_in_tree_by_vid(focus_view_id)
            self._auto_resize_focus_tree_col0()
            # 핸들러 복구 전에 대기 중인 모든 이벤트를 소진하여 루프 차단
            self.focus_tree.update_idletasks()

        finally:
            # _is_populating_tree를 after_idle 콜백 안에서 해제:
            # selection_set()이 <<TreeviewSelect>>를 tail 큐에 넣으므로,
            # after_idle이 실행될 때까지 "break" 바인딩과 플래그를 함께 유지한다.
            def _restore_handler():
                self._is_populating_tree = False
                self.focus_tree.bind("<<TreeviewSelect>>", self._on_tree_select_focus)
            self.after_idle(_restore_handler)

    # ── 트리뷰 ↔ 캔버스 양방향 연동 (2026-10-07 · docs/1.txt 51-1) ─────────────
    #   사용자 확정 「양방향 100% 연동방식. 버튼 클릭할 때에 한번에 표시하기」.
    #   ★ 지도는 하나(`p4_view.nodes`)다. 트리에서 ▸ 를 누르면 **캔버스 지도에 펼치고**
    #     (캔버스가 숨어 있어도 지도는 자란다) 트리는 그 지도를 다시 비춘다.
    #     캔버스에서 펼친 것은 [트리뷰] 단추를 누를 때 한 번에 비춘다(`_show_link_view`).
    #   ⚠ 펼치는 문은 캔버스 배지·＋ 와 **같은 문**(`_on_badge_expand`·`_on_plus_next`)이다 —
    #     트리 전용 펼침을 두면 상한·묶음·배지 약속 수가 두 벌이 된다. 옛 트리 전용
    #     펼침(`_expand_focus_tree_node` · 3단계 제한 · 부르는 곳 0)은 걷었다.
    def _tree_vid_of(self, item):
        try:
            return str(self.focus_tree.item(item, 'values')[0])
        except Exception:
            return ''

    def _tree_refresh_keep(self, keep_vid=None, see_vid=None):
        """트리를 지도에서 다시 그리되 **선택한 줄과 보던 자리**를 지킨다."""
        if keep_vid is None:
            sel = self.focus_tree.selection()
            keep_vid = self._tree_vid_of(sel[0]) if sel else None
        root = keep_vid if keep_vid in self.p4_view.nodes else (see_vid or keep_vid)
        if not root or root not in self.p4_view.nodes:
            return self._sync_p4_tree_from_canvas()
        y0 = self.focus_tree.yview()[0]
        self._populate_focus_tree_root(root)
        try:
            self.focus_tree.yview_moveto(y0)
            if see_vid:
                def _see(parent=''):
                    for it in self.focus_tree.get_children(parent):
                        if self._tree_vid_of(it) == see_vid:
                            self.focus_tree.see(it)
                            return True
                        if _see(it):
                            return True
                    return False
                _see()
        except Exception:
            pass

    def _on_tree_open(self, _e=None):
        """▸ 를 눌렀다 — 자리표 줄이 달린 줄이면 **캔버스 지도에 펼친다**."""
        if getattr(self, '_is_populating_tree', False):
            return
        item = self.focus_tree.focus()
        vid = self._tree_vid_of(item)
        if not vid or vid.startswith('__'):
            return
        self._tree_closed = getattr(self, '_tree_closed', set())
        self._tree_closed.discard(vid)
        kids = self.focus_tree.get_children(item)
        if not (len(kids) == 1 and self._tree_vid_of(kids[0]).startswith('__EXPAND__')):
            return                                  # 이미 펼친 줄 — 보기만 연다
        self.after_idle(lambda v=vid: self._tree_expand(v))

    def _tree_expand(self, vid):
        info = self.p4_view.nodes.get(vid)
        if not info:
            return
        before = len(self.p4_view.nodes)
        self._p4_last_note = None
        try:
            self._on_badge_expand(info.get('node_id'), vid)
        except Exception as e:
            print(f'[tree expand] {e}')
        if len(self.p4_view.nodes) == before:
            # 더 나올 것이 없었다(자녀가 이미 지도 다른 자리에 있다) — ▸ 를 다시 안 단다
            self._tree_noexpand = getattr(self, '_tree_noexpand', set())
            self._tree_noexpand.add(vid)
        self._tree_refresh_keep(see_vid=vid)
        # 52-1 — 캔버스 풍선과 같은 말을 트리 줄 아래에도
        note = getattr(self, '_p4_last_note', None)
        if note and note[0] == str(vid):
            self._tree_toast(vid, note[1])

    def _tree_toast(self, vid, msg):
        """트리 줄 바로 아래에 작은 풍선 글(52-1 · 캔버스 풍선과 같은 말)."""
        tv = getattr(self, 'focus_tree', None)
        if tv is None or not msg:
            return
        found = []

        def _walk(parent=''):
            for it in tv.get_children(parent):
                if found:
                    return
                if self._tree_vid_of(it) == str(vid):
                    found.append(it)
                    return
                _walk(it)
        try:
            _walk()
            old = getattr(self, '_tree_toast_w', None)
            if old is not None and old.winfo_exists():
                old.destroy()
            bb = tv.bbox(found[0]) if found else None
            y = (bb[1] + bb[3] + 2) if bb else 4
            x = (bb[0] + 24) if bb else 8
            w = tk.Label(tv, text=msg,
                         bg=ui_theme.C('warning_bg') or '#FFF4D6',
                         fg=ui_theme.C('fg') or '#2C3E50',
                         bd=1, relief='solid', padx=6, pady=2)
            try:
                theme_font.register(w, self.db_path, 'ui')
            except Exception:
                pass
            w.place(x=x, y=y)
            self._tree_toast_w = w
            self.after(3500, lambda ww=w: ww.winfo_exists() and ww.destroy())
        except Exception as e:
            print(f'[tree toast] {e}')

    def _on_tree_close(self, _e=None):
        """▾ 를 눌렀다 — **보기만 접는다**(지도의 노드는 그대로)."""
        if getattr(self, '_is_populating_tree', False):
            return
        vid = self._tree_vid_of(self.focus_tree.focus())
        if vid and not vid.startswith('__'):
            self._tree_closed = getattr(self, '_tree_closed', set())
            self._tree_closed.add(vid)

    def _tree_plus(self, parent_vid):
        """트리의 「＋ 다음 묶음」 줄 — 캔버스 박스 바깥 ＋ 와 같은 문."""
        info = self.p4_view.nodes.get(parent_vid)
        if not info:
            return
        try:
            self._on_plus_next(info.get('node_id'), parent_vid)
        except Exception as e:
            print(f'[tree plus] {e}')
        self._tree_refresh_keep(see_vid=parent_vid)

    def _auto_resize_focus_tree_col0(self):
        """#0 컬럼 너비를 트리 깊이와 텍스트 길이에 맞게 자동 조절합니다."""
        try:
            import tkinter.font as tkfont
            f = tkfont.Font(family="Malgun Gothic", size=9)
            indent = 8
            max_w = 100
            def walk(item, depth):
                nonlocal max_w
                txt = self.focus_tree.item(item, 'text')
                w = indent * depth + f.measure(txt) + 20
                if w > max_w:
                    max_w = w
                for child in self.focus_tree.get_children(item):
                    walk(child, depth + 1)
            for root_item in self.focus_tree.get_children():
                walk(root_item, 0)
            self.focus_tree.column("#0", width=min(max_w, 350))
        except Exception:
            pass

    def _update_focus_breadcrumbs(self, target_id):
        """[신설] 상단 경로바를 '할아버지 > 아버지 > 나' 형태로 갱신하며 클릭 시 해당 지점으로 이동합니다."""
        for child in self.breadcrumb_f.winfo_children(): child.destroy()
        
        # 1. 🧬 계보 사냥: [나, 부모, 조부모, ...] 순으로 가져옴
        lineage = self._calculate_id_lineage(target_id)
        display_lineage = list(reversed(lineage[-3:])) # 최근 3대만 추출
        
        # 2. 버튼식 경로바 생성
        for i, vid in enumerate(display_lineage):
            v_t, v_n = self._split_logic_id(vid)
            name = self.get_asset_name(v_n, v_t)
            
            btn = tk.Button(self.breadcrumb_f, text=name, font=("Malgun Gothic", 9), bg="white", fg="#2E86C1",
                            relief='flat', cursor="hand2", command=lambda v=vid: self._populate_focus_tree_root(v))
            btn.pack(side='left')
            
            if i < len(display_lineage) - 1:
                tk.Label(self.breadcrumb_f, text=" > ", bg="white", fg="#ABB2B9").pack(side='left')

    def _sync_diagnostics_monitor(self, method_name, v_id):
        """[테스터기] 재귀 호출의 빈도와 경로를 실시간으로 감시합니다."""
        if not hasattr(self, '_sync_trace_log'): self._sync_trace_log = []
        now = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        
        # 최근 0.5초 내에 동일 노드가 동일 메서드에서 호출되었는지 확인
        self._sync_trace_log.append((datetime.now(), method_name, v_id))
        recent = [log for log in self._sync_trace_log if (datetime.now() - log[0]).total_seconds() < 0.5]

        # [제거 2026-06-01] 진단용 SYNC_LOG print 제거 (사용자 요청)
        if len([log for log in recent if log[1] == method_name and log[2] == v_id]) > 2:
            print(f"🚨🚨 [재귀 경보] {method_name}에서 무한 루프가 탐지되었습니다! 🚨🚨")
            return True
        return False

    def _fetch_qp_content(self, asset_id):
        """[수리] AI의 임의 가공(필터링, 접두어)을 모두 제거하고 DB 원본 contents만 반환합니다."""
        with appdb.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            q = conn.execute("SELECT contents FROM user_text_asset WHERE clicked_id=? AND text_type='VERS_QUESTION' AND record_status!='HIDE'", (asset_id,)).fetchone()
            if not q: q = conn.execute("SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type='VERS_QUESTION' AND " + _ST, (asset_id,)).fetchone()
            p = conn.execute("SELECT contents FROM user_text_asset WHERE clicked_id=? AND text_type='VERS_PRAYER' AND record_status!='HIDE'", (asset_id,)).fetchone()
            if not p: p = conn.execute("SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type='VERS_PRAYER' AND " + _ST, (asset_id,)).fetchone()
        
        # 🎯 [수리] DB의 contents를 있는 그대로 가져와서 결합만 합니다. (엔터키 보존)
        res_list = [r['contents'] for r in [q, p] if r and r['contents']]
        return self._truncate_qp_text("\n".join(res_list)) if res_list else ""

    def _truncate_qp_text(self, text):
        """[수리] 자동 산출 폭을 준수하며, 원문의 엔터키(줄바꿈)를 물리적으로 보존합니다."""
        if not text: return ""
        import textwrap
        width = self._p4_body_chars()
        
        # 🎯 [핵심] replace('\n', ' ')를 삭제하여 사용자의 엔터 입력을 보존합니다.
        # drop_whitespace=False를 통해 사용자가 의도한 줄바꿈을 최대한 유지합니다.
        wrapper = textwrap.TextWrapper(width=width, break_long_words=False, replace_whitespace=False)
        lines = []
        for line in text.splitlines(): # 원문의 엔터키를 기준으로 먼저 나눔
            lines.extend(wrapper.wrap(line))
            
        res = "\n".join(lines[:2]) # 2라인 제한 유지
        if len(lines) > 2: res += " ..."
        return res


# (옛 시작 절차는 걷었다 — 맨 위에서 `run.main()` 으로 넘긴다 · 2026-10-09)


class _P4BranchShim:
    """옛 「역본·말씀흐름」 갈래 단추를 부르던 자리를 **탭 선택하기**로 잇는다(51-4 · 2026-10-07).

    `_p4_br_compare.select('compare'|'chain')` 을 부르는 자리가 여럿이라 그 이름을 남긴다."""

    def __init__(self, app):
        self._app = app

    def select(self, key, save=True):
        a = self._app
        k = 'flow' if key == 'chain' else 'compare'
        try:
            a._ensure_p4_tab_built(a.P4[k])
            a.p4_nb.select(a.P4[k])
        except Exception as e:
            print('[p4 shim] %s' % e)

    def current(self):
        a = self._app
        try:
            return 'chain' if a.p4_nb.index('current') == a.P4['flow'] else 'compare'
        except Exception:
            return 'compare'
