# -*- coding: utf-8 -*-
"""medi_note.py — 묵상노트 통합 저장 계층 + 쓰기 띠 (영구 모듈, 2026-08-19).

★ 7원칙 (0.txt 토론에서 사용자 확정 — notes.md 「묵상노트 통합 불변식」):
  ① 한 이름 — 전 화면 「묵상노트」.
  ② 한 저장소 — user_text_asset, text_type='VERS_NOTE' 하나.
     (MEDI_NOTE 로 개명하지 않았다 — P2 구절노트가 이미 이 유형을 커버 조회로
      읽고 있어, 이름을 바꾸면 코드만 흔들리고 얻는 것이 없다.)
  ③ 닻의 사다리 — 구절/구간 닻(1층, P2 에도 보임) ← 이 모듈의 몫.
     인용문+유닛 닻(2층)은 밑줄 메모(highlight_notes)가 담당하고 통합 화면에서 합류.
  ④ 한 노트 = 한 닻 — 여러 구절 모두에 걸지 않는다. 더 넓게 걸 글은 「내 자료」.
  ⑤ 닻은 사용자가 결정 — 쓰기 띠에 약명이 항상 보이고(▸ 창 22:1-14) 후보에서 바꾼다.
  ⑥ 질문 스냅샷 — 노드 질문에 대한 답은 질문 본문을 노트에 복사해 자기완결로.
  ⑦ 명시적 저장 + 미아 게이트 — 자동저장 경로를 복제하지 않고, 닻 없으면 거부.

행 모양 (note_refr_panel 과 완전히 같은 계약):
    clicked_id = 시작 verse_id (필수)
    target_id  = 끝 verse_id (단일이면 0)
    title      = 사용자 제목 (없으면 '')
    contents   = 규약 줄 + 본문:
        관련구절 창 22:1~14                  ← note_refr_panel 기존 규약 그대로
        출처 LENS:희생제사와 피:모리아산의 시험|렌즈 · 희생제사와 피 · 모리아산의 시험
        질문 여호와 이레를 …?
        (본문)

★ 출처 줄 = 「키|라벨」. 키는 쓴 화면이 제 노트를 되찾는 **글자 키**다 — FK 가
  아니라서 렌즈가 개편·회수·개명돼도 노트는 구절 밑에서 영원히 살고, 원래
  화면에서만 조용히 안 보이게 된다(우아한 퇴화 — 밑줄 메모의 인용문 닻과 같은 철학).
⚠ 규약 줄은 **글의 일부**라 P2 편집기에 그대로 노출되면 사용자가 지웠다 쓰게 된다.
  note_refr_panel 이 관련구절 줄에 하던 「따로 보이고 편집칸에서는 뺀다」를
  출처·질문 줄에도 확장한다(_split_meta).

    python medi_note.py --selftest        (의무)
"""
import tkinter as tk
from tkinter import ttk

import appdb
import i18n

TYPE = 'VERS_NOTE'

# ★★ **유닛 닻** (2026-08-24 사용자 확정 「묵상노트의 닻을 유닛으로」).
#   구절 닻만 있던 동안 **기준 구절이 없는 496편(12권 통째)** 에서 쓰기 단추가
#   잠겨 있었다 — 에더샤임·고백록·팡세에 노트를 달 수 없었다. 「고백록 3권을
#   읽고 쓰는 글」에 구절을 강제할 까닭이 없다.
#
#   ⇒ **도서·설교·교리 노트는 언제나 편(유닛)에 단다.** 사용자가 고를 것이 없다.
#      그 편에 기준 구절이 있으면 P2 묵상노트에도 저절로 뜨고(유닛→구절 조인),
#      없으면 안 뜬다. 연결될 구절이 없으니 당연하다.
#
# ⚠⚠ **밑줄 메모와 이름이 겹치면 안 된다.** 밑줄 메모(`highlight_notes`)가 이미
#   `BUNT_MEMO`/`REFU_MEMO` 로 유닛을 닻 삼는다. 같은 이름을 쓰면 밑줄 메모 조회
#   (`load_notes`)가 묵상노트를 주워 **본문에 끼우려 든다.** 그래서 `*_MEDI`.
#   ⚠ 2026-08-25 개명 — 닻이 도서가 아니라 **편**이라 넉 자 코드로 맞췄다.
UNIT_TYPE = {'BOOK': 'BUNT_MEDI', 'REF': 'REFU_MEDI'}
ALL_TYPES = (TYPE,) + tuple(UNIT_TYPE.values())

PREFIX_VERSE = '관련구절 '     # note_refr_panel._VERSE_PREFIX 와 같은 값이어야 한다
# ⚠ 기계 줄 접두는 **산문 첫머리에 나올 수 없는 꼴**이어야 한다 — 「출처 를 밝히는
#   것이 좋다」로 시작하는 본문을 규약 줄로 오인해 먹은 것을 selftest 가 잡았다.
#   낱말 뒤에 곧바로 `|` 를 붙인다.
PREFIX_SRC = '출처|'
PREFIX_Q = '질문|'

# ★★ 2026-10-21 도서노트 「구절에도 연결」 — 사람이 고른다(사용자 「도서 유닛에 구절이 있는 경우에는
#   구절연결을 할 것인지 사용자가 선택하도록」). 표식 = **관련구절 줄이 있느냐** — 그 줄이 곧 「이 노트가
#   걸린 구절」이라 따로 칸을 두면 두 벌이 된다. 옛 편 노트는 전부 그 줄이 있어 그대로 구절에도 뜬다.
#   ⚠ 이 조각을 쓰는 곳 = P2 노트(`_SQL_UNIT_COVER`) · AI 노트 원천(`user_ai._NOTE_SRC`).
UNIT_LINKED_SQL = "{n}.contents LIKE '" + PREFIX_VERSE + "%'"


# ── 규약 줄 조립·해체 ────────────────────────────────────────────────────────

def compose(body, verse_label='', src_key='', src_label='', question=''):
    """본문 앞에 규약 줄을 끼운다. 값이 없는 줄은 만들지 않는다."""
    lines = []
    if verse_label:
        lines.append(PREFIX_VERSE + verse_label)
    if src_key or src_label:
        lines.append(PREFIX_SRC + (src_key or '') + '|' + (src_label or ''))
        # → 「출처|LENS:렌즈:노드|렌즈 · 노드」 꼴
    if question:
        # ⚠ 질문이 여러 줄이면 규약이 깨진다 — 한 줄로 누른다(렌즈 글 규칙과 동일)
        lines.append(PREFIX_Q + ' '.join(str(question).split()))
    lines.append(body or '')
    return '\n'.join(lines)


def parse(contents):
    """contents → dict(verse_label, src_key, src_label, question, body).

    규약 줄은 앞머리에서만 읽는다 — 본문 중간의 「출처 …」 문장을 먹지 않기 위해.
    """
    out = {'verse_label': '', 'src_key': '', 'src_label': '', 'question': '',
           'body': ''}
    lines = (contents or '').split('\n')
    i = 0
    while i < len(lines):
        ln = lines[i]
        if ln.startswith(PREFIX_VERSE) and not out['verse_label']:
            out['verse_label'] = ln[len(PREFIX_VERSE):].strip()
        elif ln.startswith(PREFIX_SRC) and not out['src_key'] and not out['src_label']:
            rest = ln[len(PREFIX_SRC):]
            key, _, label = rest.partition('|')
            out['src_key'] = key.strip()
            out['src_label'] = label.strip()
        elif ln.startswith(PREFIX_Q) and not out['question']:
            out['question'] = ln[len(PREFIX_Q):].strip()
        else:
            break
        i += 1
    out['body'] = '\n'.join(lines[i:]).lstrip('\n')
    return out


# ── 약명 ─────────────────────────────────────────────────────────────────────

def verse_label(db_path, start_vid, end_vid=None, lang='KO'):
    """(start, end) → 「창 22:1」 / 「창 22:1~14」 / 장을 넘으면 「막 6:30~7:2」."""
    if not start_vid:
        return ''
    try:
        with appdb.connect(db_path) as conn:
            def _one(vid):
                return conn.execute(
                    "SELECT bn.short_name, bi.chapter, bi.verse FROM bible_index bi "
                    "JOIN book_names bn ON bn.book_code=bi.bcode "
                    " AND bn.lang_code IN (?,'EN','KO') "
                    "WHERE bi.verse_id=? "
                    "ORDER BY CASE bn.lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1 "
                    "         ELSE 2 END LIMIT 1", (lang, vid, lang)).fetchone()
            s = _one(start_vid)
            if not s:
                return str(start_vid)
            sn, ch, vs = s
            if not end_vid or end_vid == start_vid:
                return f'{sn} {ch}:{vs}'
            e = _one(end_vid)
            if not e:
                return f'{sn} {ch}:{vs}'
            if e[1] == ch:
                return f'{sn} {ch}:{vs}~{e[2]}'
            return f'{sn} {ch}:{vs}~{e[1]}:{e[2]}'
    except Exception:
        return str(start_vid)


# ── 저장·조회 ────────────────────────────────────────────────────────────────

def save_new(db_path, start_vid, end_vid, body, *, src_key='', src_label='',
             question='', lang='KO', title='', unit=None):
    """새 노트. ⚠ 미아 게이트 — **닻과 본문**이 없으면 저장하지 않는다.

    닻은 둘 중 하나다:
      · **구절** — `start_vid`(+`end_vid`) · `text_type='VERS_NOTE'`
      · **편**   — `unit=('BOOK'|'REF', unit_id)` · `text_type=UNIT_TYPE[갈래]`

    `unit` 을 주면 `start_vid` 는 **관련구절 줄을 적는 데만** 쓰이고 닻이 아니다
    (없어도 된다). 화면 표시는 그 편의 구절을 그때그때 조인해서 정한다.
    """
    if not (body or '').strip():
        raise ValueError('본문이 비었다')
    if unit is not None:
        kind, uid = unit
        if kind not in UNIT_TYPE:
            raise ValueError('모르는 편 갈래: %r' % (kind,))
        if not uid:
            raise ValueError('편 닻이 없다 — 미아 노트를 만들지 않는다')
        ttype, anchor, tgt = UNIT_TYPE[kind], int(uid), 0
        vl = verse_label(db_path, start_vid, end_vid, lang) if start_vid else ''
    else:
        if not start_vid:
            raise ValueError('구절 닻이 없다 — 미아 노트를 만들지 않는다')
        ttype, anchor = TYPE, start_vid
        tgt = end_vid if (end_vid and end_vid != start_vid) else 0
        vl = verse_label(db_path, start_vid, end_vid, lang)
    contents = compose(body.strip(), vl, src_key, src_label, question)
    with appdb.connect(db_path) as conn:
        # ★ 같은 자리에 같은 글이 이미 살아 있으면 **그것을 돌려준다**
        #   (2026-10-09 · 1.txt 58 — 사용자 「사용자 db에 중복이 있다면 앱의
        #   결함이다」). 두 번 눌림·자동저장이 겹쳐도 한 편만 남는다.
        same = conn.execute(
            "SELECT user_text_id FROM user_text_asset WHERE clicked_id=? "
            " AND text_type=? AND COALESCE(target_id,0)=? AND contents=? "
            " AND COALESCE(lang_code,'')=? "
            " AND COALESCE(record_status,'LIVE')<>'HIDE' ORDER BY user_text_id",
            (anchor, ttype, tgt, contents, lang)).fetchone()
        if same:
            return same[0]
        cur = conn.execute(
            "INSERT INTO user_text_asset (clicked_id, target_id, text_type, "
            " title, contents, lang_code, record_status, created_at, updated_at) "
            "VALUES (?,?,?,?,?,?, 'NEW', DATETIME('now','localtime'), "
            "        DATETIME('now','localtime'))",
            (anchor, tgt, ttype, title or '', contents, lang))
        conn.commit()
        return cur.lastrowid


def update_note(db_path, note_id, body, start_vid=None, end_vid=None, lang='KO', link=None):
    """본문(과 선택적으로 닻)을 고친다. 출처·질문 규약 줄은 **보존**한다.

    `link` — 편 노트만: True = 구절에도 연결(관련구절 줄을 `start_vid~end_vid` 로 다시 적는다) ·
    False = 연결 풀기(그 줄을 뺀다) · None = 그대로.
    """
    if not (body or '').strip():
        raise ValueError('본문이 비었다')
    with appdb.connect(db_path) as conn:
        row = conn.execute(
            "SELECT contents, clicked_id, target_id, text_type FROM user_text_asset "
            "WHERE user_text_id=?", (note_id,)).fetchone()
        if not row:
            raise ValueError('노트가 없다: %s' % note_id)
        meta = parse(row[0])
        # ⚠⚠ **편 닻 노트는 `clicked_id` 를 건드리지 않는다** — 그 값은
        #   verse_id 가 아니라 unit_id 다. 구절 닻처럼 다루면 ① 닻이 엉뚱한
        #   유닛으로 옮겨가고 ② `verse_label` 이 unit_id 를 절로 읽어 **엉뚱한
        #   약명**을 적는다. 둘 다 오류를 안 낸다.
        if row[3] in UNIT_TYPE.values():
            sv, ev, vl = row[1], (row[2] or 0), meta['verse_label']
            if link is False:
                vl = ''
            elif link and start_vid:
                vl = verse_label(db_path, start_vid, end_vid or None, lang)
        else:
            sv = start_vid or row[1]
            ev = end_vid if end_vid is not None else (row[2] or 0)
            vl = (verse_label(db_path, sv, ev or None, lang) if sv
                  else meta['verse_label'])
        contents = compose(body.strip(), vl, meta['src_key'],
                           meta['src_label'], meta['question'])
        conn.execute(
            "UPDATE user_text_asset SET clicked_id=?, target_id=?, contents=?, "
            " record_status='EDIT', updated_at=DATETIME('now','localtime') "
            "WHERE user_text_id=?",
            (sv, (ev if (ev and ev != sv) else 0), contents, note_id))
        conn.commit()


def hide_note(db_path, note_id):
    with appdb.connect(db_path) as conn:
        conn.execute("UPDATE user_text_asset SET record_status='HIDE' "
                     "WHERE user_text_id=?", (note_id,))
        conn.commit()


def notes_for_context(db_path, src_key):
    """그 화면(맥락 키)에서 쓴 노트들 — 최근 것부터.

    ⚠ LIKE 로 찾는다 — 개인 데이터 규모(수백~수천 행)라 충분하고, 키가 글자라
      FK 개편에 흔들리지 않는다. `|` 까지 붙여 접두 겹침(「LENS:a」vs「LENS:ab」)을 막는다.
    """
    if not src_key:
        return []
    pat = '%' + PREFIX_SRC + src_key + '|%'   # 「출처|<키>|」 — 접두 겹침 차단
    # ⚠ **세 유형을 다 훑는다** — 도서 노트는 편 닻(`*_MEDI`)으로 옮겼지만
    #   그 전에 구절 닻으로 저장된 옛 노트가 남아 있다. 한 유형만 보면 그것들이
    #   **화면에서 조용히 사라진다.**
    ph = ','.join('?' * len(ALL_TYPES))
    try:
        with appdb.connect(db_path) as conn:
            rows = conn.execute(
                "SELECT user_text_id, title, contents, created_at, updated_at, "
                "       clicked_id, target_id "
                "FROM user_text_asset "
                "WHERE text_type IN (" + ph + ") "
                "  AND record_status IN ('LIVE','NEW','EDIT') "
                "  AND contents LIKE ? "
                "ORDER BY COALESCE(updated_at, created_at) DESC, user_text_id DESC",
                ALL_TYPES + (pat,)).fetchall()
    except Exception:
        rows = []
    out = []
    for r in rows:
        d = parse(r[2])
        d.update({'id': r[0], 'title': r[1], 'contents': r[2],
                  'created_at': r[3], 'updated_at': r[4],
                  'start_vid': r[5], 'end_vid': r[6] or r[5]})
        out.append(d)
    return out


# ── 편 닻 노트를 구절로 되찾기 (2026-08-24) ──────────────────────────────────
#
# ★★ **간접 연결**이다 — 노트 → 편 → 그 편의 기준 구절 → P2 표시.
#   직접 닻보다 나은 까닭 둘:
#     ① **기준 구절은 실제로 바뀐다** — §75차에 「아침과 저녁」 732편의
#        `start_vid` 를 고쳤다. 직접 닻이면 노트가 **옛 구절에 남는다.**
#     ② 편의 99.9%가 한 장 안이고 폭 중앙값이 1절이라 부정확해질 여지가 없다.
# ★ 값도 공짜다 — 조인 실측 **회당 0.032ms**.
# ⚠ 편에 구절이 없으면(496편) 여기서 **안 나온다.** 연결될 구절이 없으니 맞다.
# ⏭ 교리자료(`REFU_MEDI`)는 구절이 `sys_ref_verse_link` 에 있어 조인이 다르다 —
#   쓰기 진입점이 생길 때 함께 만든다. 지금 만들면 부르는 곳 없는 코드가 된다.

import verse_range as _vr          # §verse_range — 구간 판정 단일 문
import book_link as _BL            # 도서 편이 어느 절에 걸리나(원본마다)

_SQL_UNIT_COVER = (
    "SELECT n.user_text_id, n.title, n.contents, n.created_at, n.updated_at, "
    "       u.start_vid, COALESCE(NULLIF(u.end_vid,0), u.start_vid) "
    "  FROM user_text_asset n "
    "  JOIN sys_book_unit u ON u.unit_id = n.clicked_id "
    "  JOIN sys_book_asset ua ON ua.book_id = u.book_id "
    " WHERE n.text_type = '" + UNIT_TYPE['BOOK'] + "' "
    "   AND n.record_status IN ('LIVE','NEW','EDIT') "
    "   AND u.start_vid IS NOT NULL AND " + UNIT_LINKED_SQL.format(n='n') + " AND "
    # ⚠⚠ 구간 판정은 **`verse_range` 한 문**(§verse_range) — 번호로 재면
    #   마이어 「아가서 6장」 편의 노트가 요한계시록 전체에서 뜬다.
    # ★ 2026-10-13 — 어느 절에 거나는 원본이 정한다(`book_link` — 마이어는 주제 구절만)
    + _BL.hit_sql('u', 'ua'))


def unit_notes_for_verse(conn, verse_id):
    """그 구절을 덮는 **편 닻 노트** 행들. 모양은 구절 닻 조회와 같다."""
    if not verse_id:
        return []
    try:
        return conn.execute(_SQL_UNIT_COVER,
                            _BL.hit_args(verse_id)).fetchall()
    except Exception as e:
        print('[medi_note unit cover] %s' % e)
        return []


def full_label(conn, src_key, lang='KO', fallback=''):
    """출처 키로 **전체 이름을 다시 짓는다** — 목록엔 짧게, 풍선엔 전문.

    ★ §54 원칙 — **저장된 이름을 그대로 믿지 않는다.** `src_label` 은 쓸 때의
      글자라 책 제목을 고치거나 화면 언어를 바꿔도 안 따라온다. 키(`BOOK:코드:순번`)
      는 안 변하므로 그것으로 그때그때 짓는다.
    ⚠ 도서 키만 짓는다 — 렌즈·플랜 키는 저장된 라벨을 그대로 돌려준다(그쪽 화면이
      바뀌면 그때 더한다). 못 지으면 **조용히 빈 값을 주지 않고** fallback.
    """
    s = (src_key or '')
    if not s.startswith('BOOK:'):
        return fallback
    try:
        _h, bcode, seq = s.split(':', 2)
        import book_label
        r = conn.execute(
            "SELECT u.unit_id, u.book_id FROM sys_book_unit u "
            "  JOIN sys_book_asset a ON a.book_id = u.book_id "
            " WHERE a.book_code = ? AND u.sequence = ?", (bcode, int(seq))
        ).fetchone()
        if not r:
            return fallback
        bt = book_label.book_title(conn, r[1], lang) or bcode
        ut = book_label.unit_title(conn, r[0], lang, str(seq))
        return '%s · %s · %s' % (i18n.t('MN_SRC_BOOK', '도서'), bt, ut)
    except Exception:
        return fallback


def count_unit_notes_for_verse(conn, verse_id):
    if not verse_id:
        return 0
    try:
        return conn.execute(
            "SELECT COUNT(*) FROM (" + _SQL_UNIT_COVER + ")",
            # ⚠ 2026-10-13 — 인자를 둘만 넘겨(조각은 셋을 묻는다) **늘 0** 이었다. 한 문으로.
            _BL.hit_args(verse_id)).fetchone()[0]
    except Exception:
        return 0


# ── 쓰기 띠 (공용 위젯) ──────────────────────────────────────────────────────

class NoteBar(tk.Frame):
    """묵상노트 쓰기 띠 — 렌즈·플랜·도서가 같은 것을 쓴다.

    구성: [묵상노트 쓰기 — 라벨]  ▸ [닻 콤보]   [저장][삭제*][취소]
          [본문 입력칸]
    · candidates = [(약명, start_vid, end_vid)] — 첫째가 기본. **약명만 보인다**
      (2026-08-19 사용자 지시 — 「…에 답니다」 같은 문구 없이).
    · rec 가 있으면 수정 모드(본문 교체 + 닻 변경 가능 · 출처·질문 줄 보존).
    ⚠ pack 은 호출자가 한다 — expand 위젯이 있는 프레임에서는 `before=` 로
      순서를 당겨야 한다(렌즈 쓰기 띠에서 실측한 1×1 함정).
    """

    def __init__(self, parent, db_path, candidates, *, src_key='', src_label='',
                 question='', lang='KO', rec=None, on_done=None, title_text=None,
                 unit=None):
        super().__init__(parent, bd=1, relief='solid')
        self.db_path = db_path
        self._cands = [c for c in (candidates or []) if c and c[1]]
        self._src_key = src_key
        self._src_label = src_label
        self._question = question
        self._lang = lang
        self._rec = rec
        self._on_done = on_done
        # ★ 편 닻이면 **고를 것이 없다** — 콤보 대신 약명을 글자로만 보인다
        #   (구절이 없는 편이면 그 자리도 비운다). 사용자가 판단할 것이 없는데
        #   콤보를 두면 「무엇을 고르라는 것인가」가 된다.
        self._unit = unit

        bar = tk.Frame(self)
        bar.pack(fill='x')
        tk.Label(bar, text=(title_text
                            or i18n.t('MN_WRITE', '묵상노트 쓰기'))
                 ).pack(side='left', padx=6, pady=2)
        # 닻 — 약명 콤보 (작은 글씨). 후보가 하나뿐이어도 **보인다** (사용자 결정 원칙)
        self._anchor = None
        if unit is not None:
            # 편 닻 — 고를 것이 없다. 그 편의 구절이 있으면 참고로만 보인다.
            # ★ 2026-10-21 구절이 있으면 「구절에도 연결」을 사람이 고른다(처음 = 켬 · 수정은 그 노트대로)
            self._link_v = tk.BooleanVar(value=bool(rec.get('verse_label')) if rec else True)
            if self._cands:
                tk.Checkbutton(bar, variable=self._link_v,
                               text=i18n.t('MN_LINK_VERSE', '구절에도 연결') + '  ▸ ' + self._cands[0][0],
                               font=('', 9)).pack(side='left', padx=(2, 0))
        else:
            tk.Label(bar, text='▸', font=('', 9)).pack(side='left')
            self._anchor = ttk.Combobox(bar, state='readonly', width=14,
                                        font=('', 9),
                                        values=[c[0] for c in self._cands])
            self._anchor.pack(side='left', padx=(2, 0))
            if self._cands:
                idx = 0
                if rec:  # 수정 — 기존 닻과 같은 후보를 찾아 미리 고른다
                    for i, c in enumerate(self._cands):
                        if c[1] == rec.get('start_vid') and \
                           (c[2] or c[1]) == (rec.get('end_vid')
                                              or rec.get('start_vid')):
                            idx = i
                            break
                self._anchor.current(idx)

        # ★ **기호 단추** (2026-08-23 사용자 「묵상노트 화면에 한줄로 배치하면
        #   공간이 좁으므로 버튼 배치하고 클릭하면 Recent 클릭할 때 표시되는
        #   방식으로 표시해라」) — 목록은 공용 부품 `symbol_picker` 가 갖는다.
        #   ⚠ 글칸은 아래에서 만든다 — 그래서 **위젯이 아니라 함수로** 넘긴다.
        try:
            import symbol_picker
            symbol_picker.button(
                bar, lambda: getattr(self, 'txt', None),
                text=i18n.t('MP_SYMBOLS', '기호')).pack(side='right', padx=(2, 8))
        except Exception as e:
            print('[NoteBar symbol] %s' % e)

        tk.Button(bar, text=i18n.t('COMMON_CANCEL', '취소'), bd=0, padx=8,
                  cursor='hand2', command=self._close).pack(side='right', padx=2)
        if rec:
            tk.Button(bar, text=i18n.t('COMMON_DELETE', '삭제'), bd=0, padx=8,
                      cursor='hand2', command=self._delete).pack(side='right', padx=2)
        tk.Button(bar, text=i18n.t('COMMON_SAVE', '저장'), bd=0, padx=8,
                  cursor='hand2', command=self._save).pack(side='right', padx=2)

        self.txt = tk.Text(self, height=5, wrap='word', bd=0)
        try:
            import theme_font
            theme_font.register(self.txt, db_path, 'prose')
        except Exception:
            pass
        if rec:
            self.txt.insert('1.0', rec.get('body') or '')
        self.txt.pack(fill='x', padx=6, pady=(0, 6))
        self.txt.focus_set()

    def _picked(self):
        try:
            return self._cands[self._anchor.current()]
        except Exception:
            return self._cands[0] if self._cands else (None, None, None)

    def _has_body(self):
        return bool(self.txt.get('1.0', 'end-1c').strip())

    def _save(self):
        body = self.txt.get('1.0', 'end-1c').strip()
        if not body:
            self._close()
            return
        _lbl, sv, ev = self._picked()
        link = None
        if self._unit is not None:
            link = bool(self._cands) and bool(self._link_v.get())
            if not link:
                sv = ev = None          # 편에만 — 관련구절 줄을 안 적는다(= 구절에 안 뜬다)
        try:
            if self._rec:
                update_note(self.db_path, self._rec['id'], body,
                            start_vid=sv, end_vid=ev or 0, lang=self._lang, link=link)
            else:
                save_new(self.db_path, sv, ev, body, src_key=self._src_key,
                         src_label=self._src_label, question=self._question,
                         lang=self._lang, unit=self._unit)
        except Exception as e:
            print('[medi_note save] %s' % e)
        self._close(done=True)

    def _delete(self):
        from tkinter import messagebox
        if not self._rec:
            return
        if not messagebox.askyesno(i18n.t('LENS_NOTE_DELT', '삭제'),
                                   i18n.t('LENS_NOTE_DELQ', '이 글을 삭제할까요?')):
            return
        try:
            hide_note(self.db_path, self._rec['id'])
        except Exception as e:
            print('[medi_note del] %s' % e)
        self._close(done=True)

    def _close(self, done=False):
        cb = self._on_done
        if self.winfo_exists():
            self.destroy()
        if done and callable(cb):
            cb()


# ── 자가 검증 ────────────────────────────────────────────────────────────────

def _selftest():
    import os
    db = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                      'bible_master.db')
    ok = True

    def chk(name, cond):
        nonlocal ok
        print(('  PASS ' if cond else '  FAIL ') + name)
        ok = ok and cond

    # 1) 조립↔해체 왕복
    c = compose('본문 첫 줄\n둘째 줄', '창 22:1~14', 'LENS:렌즈:노드', '렌즈 · 노드',
                '질문인가?')
    p = parse(c)
    chk('왕복: 약명', p['verse_label'] == '창 22:1~14')
    chk('왕복: 키', p['src_key'] == 'LENS:렌즈:노드')
    chk('왕복: 라벨', p['src_label'] == '렌즈 · 노드')
    chk('왕복: 질문', p['question'] == '질문인가?')
    chk('왕복: 본문', p['body'] == '본문 첫 줄\n둘째 줄')
    # 2) 규약 없는 옛 글 — 본문이 통째로 산다
    p2 = parse('그냥 쓴 옛 노트\n둘째 줄')
    chk('옛 글 무손상', p2['body'] == '그냥 쓴 옛 노트\n둘째 줄' and not p2['src_key'])
    # 3) 본문 중간의 「출처 」 문장은 먹지 않는다
    p3 = parse(compose('출처 를 밝히는 것이 좋다', '창 1:1'))
    chk('본문 속 출처 낱말 보존', p3['body'].startswith('출처 를'))
    # 4) 약명 (실 DB)
    vl = verse_label(db, 1, 14)          # 창 1:1~14
    chk('약명 구간', ':' in vl and '~' in vl)
    chk('약명 단일', '~' not in verse_label(db, 1))
    # 5) 미아 게이트
    try:
        save_new(db, None, None, '몸')
        chk('미아 게이트', False)
    except ValueError:
        chk('미아 게이트', True)
    try:
        save_new(db, 1, None, '   ')
        chk('빈 본문 게이트', False)
    except ValueError:
        chk('빈 본문 게이트', True)
    # 6) 저장→맥락 조회→수정(규약 보존)→숨김 (실 userdb, 끝나면 물리 삭제)
    nid = save_new(db, 300, 303, '시험 본문', src_key='TEST:셀프', src_label='시험 · 라벨',
                   question='시험 질문?')
    try:
        rows = notes_for_context(db, 'TEST:셀프')
        chk('맥락 조회', len(rows) == 1 and rows[0]['body'] == '시험 본문'
            and rows[0]['start_vid'] == 300 and rows[0]['end_vid'] == 303)
        chk('접두 겹침 차단', notes_for_context(db, 'TEST:셀') == [])
        update_note(db, nid, '고친 본문', start_vid=300, end_vid=0)
        r2 = notes_for_context(db, 'TEST:셀프')[0]
        chk('수정: 본문', r2['body'] == '고친 본문')
        chk('수정: 질문 보존', r2['question'] == '시험 질문?')
        chk('수정: 단일 닻', r2['end_vid'] == 300)
        hide_note(db, nid)
        chk('숨김', notes_for_context(db, 'TEST:셀프') == [])
    finally:
        with appdb.connect(db) as conn:      # 시험 잔재 물리 삭제 (원칙)
            conn.execute("DELETE FROM user_text_asset WHERE user_text_id=?", (nid,))
            conn.commit()
    # 7) 편(유닛) 닻 — 구절이 없어도 저장된다 (2026-08-24)
    #    ⚠ 검사를 **데이터 상태에 걸지 않는다**(§0-5) — 실제 유닛 하나를 그때그때
    #      고르고, 구절이 없는 상황은 `start_vid=None` 으로 **만들어서** 잰다.
    with appdb.connect(db) as conn:
        uid = conn.execute("SELECT unit_id FROM sys_book_unit LIMIT 1").fetchone()[0]
    try:
        save_new(db, None, None, '몸', unit=('BOOK', None))
        chk('편 닻: id 없으면 거부', False)
    except ValueError:
        chk('편 닻: id 없으면 거부', True)
    try:
        save_new(db, None, None, '몸', unit=('XX', uid))
        chk('편 닻: 모르는 갈래 거부', False)
    except ValueError:
        chk('편 닻: 모르는 갈래 거부', True)
    nid2 = save_new(db, None, None, '편에 쓴 글', src_key='TEST:편', src_label='도서 · x',
                    unit=('BOOK', uid))
    try:
        with appdb.connect(db) as conn:
            tt, cid, tgt = conn.execute(
                "SELECT text_type, clicked_id, target_id FROM user_text_asset "
                "WHERE user_text_id=?", (nid2,)).fetchone()
        chk('편 닻: 구절 없이도 저장', bool(nid2))
        chk('편 닻: 유형이 갈렸다', tt == UNIT_TYPE['BOOK'])
        # ⚠ 밑줄 메모(highlight_notes.KINDS)와 절대 같으면 안 된다 —
        #   같으면 밑줄 조회가 묵상노트를 주워 본문에 끼운다(§78).
        import highlight_notes as _HN
        chk('편 닻: 밑줄 메모와 안 겹친다',
            tt not in _HN.KINDS.values())
        chk('편 닻: clicked_id = unit_id', cid == uid and tgt == 0)
        rows = notes_for_context(db, 'TEST:편')
        chk('편 닻: 맥락 조회에 잡힌다', len(rows) == 1)
        # ⚠ 수정해도 닻이 안 옮겨가야 한다 — 옛 코드는 clicked_id 를 덮어썼다
        update_note(db, nid2, '고쳤다', start_vid=300, end_vid=303)
        with appdb.connect(db) as conn:
            cid2, tgt2 = conn.execute(
                "SELECT clicked_id, target_id FROM user_text_asset "
                "WHERE user_text_id=?", (nid2,)).fetchone()
        chk('편 닻: 수정해도 닻 불변', cid2 == uid and tgt2 == 0)
        chk('편 닻: 수정 본문', notes_for_context(db, 'TEST:편')[0]['body'] == '고쳤다')
        # ★ 2026-10-21 구절 연결 고르기 — 관련구절 줄이 곧 표식(구절 없이 쓴 편 노트는 구절에 안 뜬다)
        with appdb.connect(db) as conn:
            sv0 = conn.execute("SELECT start_vid FROM sys_book_unit WHERE unit_id=?", (uid,)).fetchone()[0]

        def _on_verse():
            if not sv0:
                return None
            with appdb.connect(db) as conn:
                return any(r[0] == nid2 for r in unit_notes_for_verse(conn, sv0))
        if sv0:
            chk('연결 안 함: 구절에 안 뜬다', _on_verse() is False)
            update_note(db, nid2, '고쳤다', start_vid=sv0, end_vid=sv0, link=True)
            chk('연결 켬: 관련구절 줄이 생긴다', bool(notes_for_context(db, 'TEST:편')[0]['verse_label']))
            chk('연결 켬: 구절에 뜬다', _on_verse() is True)
            update_note(db, nid2, '고쳤다', link=False)
            chk('연결 끔: 다시 안 뜬다', _on_verse() is False and
                not notes_for_context(db, 'TEST:편')[0]['verse_label'])
    finally:
        with appdb.connect(db) as conn:
            conn.execute("DELETE FROM user_text_asset WHERE user_text_id=?", (nid2,))
            conn.commit()

    with appdb.connect(db) as conn:
        left = conn.execute(
            "SELECT COUNT(*) FROM user_text_asset "
            "WHERE contents LIKE '%TEST:셀프%' OR contents LIKE '%TEST:편%'"
        ).fetchone()[0]
    chk('잔재 0', left == 0)
    print('결과: ' + ('전부 통과' if ok else '실패 있음'))
    return 0 if ok else 1


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(_selftest())
    print(__doc__)
