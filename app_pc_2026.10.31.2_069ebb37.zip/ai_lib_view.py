# -*- coding: utf-8 -*-
"""AI 도우미 ▸ 프롬프트 라이브러리 화면(PC).

★★★ 2026-10-21 (docs/AI도우미.txt 2·3) **1:1 로 다시 지었다** — 사용자 「공통 프롬프트 자산을 여기저기에서
  사용하려고 만든 것인데 현실적으로 불가능 · 프롬프트와 사용할 화면/기능을 1:1 로 · 추가/수정/삭제」.

세 칸 = ① 나무(화면/기능 → 질문프롬프트 · 맨 위 「공통」 = 사용자 · 출력서식 · 금지사항 · 성경인용 …)
        ② 고른 것의 목록(질문프롬프트면 그 글 · 역할 · 그 질문의 Pick / 공통이면 그 칸의 항목들)
        ③ 고치기(이름 · 내용 · 고치면 저절로 저장 · [초기값으로] · [지우기/숨기기] · 공통은 [이것으로 쓰기])

★ 항목은 **그 자리 하나에만** 산다 — 다른 자리와 같이 쓰지 않는다(옛 「같이 쓰던」 것은 `ai_lib.split_shared` 가 나눴다).
★ 기도 프롬프트는 **질문프롬프트 하나**(「기도 노트 · 폰」 ▸ 기도 도우미)로 다룬다 — 기도 업무 여섯은 그 질문의 Pick 이다
  (폰에서 여럿을 함께 고르는 칩). 글은 지금처럼 `user_ai_prompt` 에 있어 폰 꾸러미는 그대로다.
⚠ 팝업 없음 · 단추는 위 · 색은 역할 · 글꼴은 부르는 화면의 `_refont` 가 입힌다.
"""
import json
import tkinter as tk
from tkinter import ttk

import appdb
import ai_lib as AL
import i18n
import user_ai as UA

try:
    import ui_theme
except Exception:                                         # noqa: BLE001
    ui_theme = None

#: 공통 칸 — (열쇠, 이름) · 축(사용자)은 셋
COMMON_AX = [('STATE', '사용자 · 상태'), ('FAITH', '사용자 · 신앙 배경'), ('VIEW', '사용자 · 관점')]
COMMON_PT = [('FORMAT', '출력서식'), ('BAN', '금지사항'), ('CITE', '성경인용'), ('STYLE', '문체'),
             ('MUST', '반드시'), ('LENGTH', '분량'), ('EXAMPLE', '예시')]
#: Free 화면에 보일 공통 칸(`AI_FREE_SHOW`) — 사용자 = 축 셋 함께
FREE_SHOW_KEY = 'AI_FREE_SHOW'
FREE_SHOW_DEFAULT = ['USER']
#: 갈래 → 화면 묶음 이름
SCOPE_GROUP = [('VERSE', '구절'), ('TERM', '용어'), ('REF', '연구/설교노트')]
BOOK_PLACES = ('REF:BOOKMEDI', 'BOOK:NOTE')
PRAYER = 'PRAYER'
TASK_ROW, ROLE_ROW = 'TASK', 'ROLE'
def book_user_tasks(c):
    """내가 더한 도서 질문프롬프트(갈래 BOOK · 자리 `REF:UT_n` — 도서 편 닻의 AI 에 뜬다)."""
    return [u['key'] for u in UA.user_tasks(c) if 'BOOK' in u.get('scopes', [])]


NEW_PLACES = {'HOME:MEDI', 'HOME:STUDY', 'HOME:SOCIAL', 'NEWS', 'CARD'}     # 옛 이름(부르는 곳 호환)


def T(key, ko):
    return i18n.t(key, ko)


def _C(role, fb):
    try:
        return (ui_theme.C(role) if ui_theme else '') or fb
    except Exception:                                     # noqa: BLE001
        return fb


def _btn(parent, text, cmd):
    try:
        o = ui_theme.flat_btn() if ui_theme else {}
    except Exception:                                     # noqa: BLE001
        o = {}
    o.pop('font', None)
    return tk.Button(parent, text=' %s ' % text, command=cmd, **o)


def place_task(place):
    """앱 질문 자리 → (갈래, 질문 열쇠) · 라이브러리 안에 질문 글을 가진 자리(홈·뉴스·카드)면 None."""
    if ':' not in place or place.split(':')[0] not in ('VERSE', 'TERM', 'REF', 'BOOK', 'ERA', 'HOME'):
        return None
    sc, tk_ = place.split(':', 1)
    # ★ 2026-10-28 docs/1.txt 6-1 — 홈 AI 대화의 앱 질문(묵상·성경공부·사회현상)은 글이 라이브러리 자리에 있다(None) ·
    #   내가 더한 홈 질문프롬프트(UT_)는 업무 글이다 · 연대 조사(ERA:ERAAN)도 업무 글이라 여기서 고친다
    if sc == 'HOME' and not tk_.startswith('UT_'):
        return None
    if place == 'VERSE:FREE':
        return None
    if sc == 'BOOK':                       # 도서노트 분석 = 묵상노트 분석 질문 글(Pick 만 따로)
        return 'VERSE', tk_
    return sc, tk_


def free_show(conn):
    try:
        v = json.loads(UA.get_setting(conn, FREE_SHOW_KEY, '') or 'null')
    except ValueError:
        v = None
    return [str(x) for x in v] if isinstance(v, list) else list(FREE_SHOW_DEFAULT)


def set_free_show(conn, key, on):
    cur = [k for k in free_show(conn) if k != key]
    if on:
        cur.append(key)
    UA.set_setting(conn, FREE_SHOW_KEY, json.dumps(cur, ensure_ascii=False))


class LibView(tk.Frame):
    def __init__(self, parent, db_path=None, lang='KO', place='VERSE:ASK', on_close=None, on_changed=None,
                 on_prayer=None):
        bg = _C('bg', '#FFFFFF')
        super().__init__(parent, bg=bg)
        self.db_path = db_path
        self.lang = (lang or 'KO').upper()
        self.on_close = on_close
        self.on_changed = on_changed
        self._bg = bg
        self._node = None             # 나무에서 고른 것 — 'Q|자리' · 'A|축' · 'S|칸'
        self._sel = None              # 가운데에서 고른 줄
        self._dirty = False
        self._job = None
        self._build()
        self._fill_tree()
        self.select_node('Q|' + place if place else None)

    def _conn(self):
        c = appdb.connect(self.db_path) if self.db_path else appdb.connect()
        AL.ensure(c)
        return c

    # ── 짓기 ──────────────────────────────────────────────────────────
    def _build(self):
        bg = self._bg
        top = tk.Frame(self, bg=bg)
        top.pack(fill='x', pady=(2, 4))
        self._back_btn = tk.Button(top, text=T('AI_LIB_BACK', '◀ AI 도우미로'), command=self.close, cursor='hand2',
                                   relief='flat', bd=1, padx=8, pady=0,
                                   bg=_C('select_bg', '#5D6D7E'), fg=_C('fg_on_dark', '#FFFFFF'),
                                   activebackground=_C('select_bg', '#5D6D7E'), activeforeground=_C('fg_on_dark', '#FFFFFF'))
        # ★ 2026-10-21 (AI도우미.txt 1) [◀ AI 도우미로] · 제목 줄 걷음 — [닫기] · Esc 가 돌아간다
        self.bind_all('<Escape>', lambda _e: self.close() if self.winfo_exists() and self.winfo_ismapped() else None, add='+')
        self._title = tk.Label(top, text=T('AI_LIB_TITLE', 'AI 도우미 ▸ 프롬프트 라이브러리'), bg=bg,
                               fg=_C('accent', '#1A5276'))
        self._addq_btn = _btn(top, T('AI_LIB_ADD_Q', '+ 질문프롬프트'), self.add_question)
        self._addq_btn.pack(side='left', padx=(4, 0))
        self._add_btn = _btn(top, T('AI_LIB_ADD_ITEM', '+ 항목'), self.add_item)
        self._add_btn.pack(side='left', padx=(6, 0))
        self._close_btn = _btn(top, T('AI_LIB_CLOSE', '닫기'), self.close)
        self._close_btn.pack(side='right', padx=4)
        self._msg = tk.Label(top, text='', bg=bg, fg=_C('fg_dim', '#5D6D7E'))
        self._msg.pack(side='right', padx=8)

        pw = tk.PanedWindow(self, orient='horizontal', bg=_C('border', '#DCE6EE'), sashwidth=4)
        pw.pack(fill='both', expand=True)
        # ① 나무 — 화면/기능 → 질문프롬프트
        lf = tk.Frame(pw, bg=bg)
        self._head_tr = tk.Label(lf, text=T('AI_LIB_TREE', '화면 · 질문프롬프트'), bg=bg, anchor='w')
        self._head_tr.pack(fill='x')
        self._tr = ttk.Treeview(lf, show='tree', selectmode='browse')
        tsb = ttk.Scrollbar(lf, orient='vertical', command=self._tr.yview)
        self._tr.configure(yscrollcommand=tsb.set)
        tsb.pack(side='right', fill='y')
        self._tr.pack(fill='both', expand=True)
        self._tr.bind('<<TreeviewSelect>>', self._on_node)
        pw.add(lf, minsize=180, width=270)
        # ② 목록
        mf = tk.Frame(pw, bg=bg)
        self._head_lib = tk.Label(mf, text='', bg=bg, anchor='w', justify='left')
        self._head_lib.pack(fill='x')
        mf.bind('<Configure>', lambda e: self._head_lib.config(wraplength=max(120, e.width - 8)), add='+')
        self._free_v = tk.BooleanVar(value=False)
        self._free_cb = tk.Checkbutton(mf, text=T('AI_LIB_FREE_SHOW', 'Free 화면에도 보이기'), variable=self._free_v,
                                       command=self._toggle_free, bg=bg, anchor='w')
        cols = ('on', 'name', 'kind')
        self._tv = ttk.Treeview(mf, columns=cols, show='headings', selectmode='browse')
        for c, nk, ko, w in (('on', 'AI_LIB_COL_ON', '표시', 50), ('name', 'AI_LIB_COL_NAME', '이름', 260),
                             ('kind', 'AI_LIB_COL_KIND', '갈래', 90)):
            self._tv.heading(c, text=T(nk, ko))
            self._tv.column(c, width=w, stretch=(c == 'name'), anchor='center' if c == 'on' else 'w')
        sb = ttk.Scrollbar(mf, orient='vertical', command=self._tv.yview)
        self._tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._tv.pack(fill='both', expand=True)
        self._tv_sb = sb
        self._tv.bind('<<TreeviewSelect>>', self._on_item)
        self._tv.bind('<Button-1>', self._on_click, add='+')
        pw.add(mf, minsize=260, width=420)
        # ③ 고치기
        rf = tk.Frame(pw, bg=bg)
        eh = tk.Frame(rf, bg=bg)
        eh.pack(fill='x')
        self._ed_head = tk.Label(eh, text='', bg=bg, anchor='w')
        self._ed_head.pack(side='left')
        self._reset_btn = _btn(eh, T('AI_LIB_RESET', '초기값으로'), self._reset)
        self._reset_btn.pack(side='right')
        self._del_btn = _btn(eh, T('AI_LIB_DEL2', '지우기'), self._delete)
        self._del_btn.pack(side='right', padx=4)
        self._use_btn = _btn(eh, T('AI_LIB_USE', '이것으로 쓰기'), self._use_this)
        self._dn_btn = _btn(eh, '▼', lambda: self._move(1))
        self._up_btn = _btn(eh, '▲', lambda: self._move(-1))
        self._auto = tk.Label(rf, text=T('AI_LIB_AUTOSAVE', '고치면 저절로 저장됩니다'), bg=bg,
                              fg=_C('fg_dim', '#5D6D7E'), anchor='w')
        # ★ 2026-10-21 (AI도우미.txt 1) 「고치면 저절로 저장됩니다」 걷음
        self._name_lbl = tk.Label(rf, text=T('AI_LIB_NAME', '이름'), bg=bg, anchor='w')
        self._name_lbl.pack(fill='x', pady=(4, 0))
        self._name = tk.Entry(rf)
        self._name.pack(fill='x')
        self._body_lbl = tk.Label(rf, text=T('AI_LIB_BODY', '내용'), bg=bg, anchor='w')
        self._body_lbl.pack(fill='x', pady=(4, 0))
        self._uses = tk.Label(rf, text='', bg=bg, fg=_C('fg_dim', '#5D6D7E'), anchor='w', justify='left',
                              wraplength=320)
        self._uses.pack(side='bottom', fill='x', pady=(4, 0))
        self._body = tk.Text(rf, wrap='word', height=8, width=20, undo=True)
        self._body.pack(fill='both', expand=True)
        for w in (self._name, self._body):
            w.bind('<KeyRelease>', self._touched, add='+')
            w.bind('<FocusOut>', lambda _e: self.save(), add='+')
        pw.add(rf, minsize=240)
        self._edit_state(False)

    # ── 나무 ──────────────────────────────────────────────────────────
    def _qname(self, c, sc, t):
        # ★ 2026-10-21 (AI도우미.txt 5) AI 도우미 왼쪽 칸과 **같은 이름**(한 문 `UA.task_title`)
        return UA.task_title(c, sc, t, self.lang)

    def questions(self, c, sc):
        """그 갈래의 질문프롬프트 — 앱 것(숨긴 것 포함) + 내 것. → [(자리, 이름, 숨김)]"""
        hid = set(UA.hidden_tasks(c))
        out = []
        for t in list(UA.TASKS_OF.get(sc, [])) + [u['key'] for u in UA.user_tasks(c) if sc in u.get('scopes', [])]:
            if sc == 'REF' and t in UA.BOOK_TASKS:
                continue
            pl = '%s:%s' % (sc, t)
            out.append((pl, self._qname(c, sc, t), pl in hid))
        return out

    def _fill_tree(self):
        tr = self._tr
        tr.delete(*tr.get_children())
        with self._conn() as c:
            tr.insert('', 'end', iid='G|COMMON', text=T('AI_LIB_G_COMMON', '공통 (어느 화면에서도)'), open=True)
            for k, ko in COMMON_AX:
                tr.insert('G|COMMON', 'end', iid='A|' + k, text=T('AI_LIB_AX_' + k, ko))
            for k, ko in COMMON_PT:
                tr.insert('G|COMMON', 'end', iid='S|' + k, text=T('AI_LIB_PT_' + k, ko))
            # ★ 2026-10-21 대화 통합 지시 둘 — 대화통합화면의 [대화 통합] · [모든AI 대화내용 통합]이 보내는 글
            tr.insert('G|COMMON', 'end', iid='M|MERGE', text=T('AI_LIB_M_MERGE', '대화 통합 지시 (AI 하나)'))
            tr.insert('G|COMMON', 'end', iid='M|INTEG', text=T('AI_LIB_M_INTEG', '모든 AI 통합 지시'))
            for sc, ko in SCOPE_GROUP:
                g = 'G|' + sc
                tr.insert('', 'end', iid=g, text=T('AI_LIB_G_' + sc, ko), open=True)
                for pl, nm, hid in self.questions(c, sc):
                    tr.insert(g, 'end', iid='Q|' + pl, text=nm + ((' ' + T('AI_LIB_HIDDEN', '(숨김)')) if hid else ''))
            tr.insert('', 'end', iid='G|BOOK', text=T('AI_LIB_G_BOOK', '도서/설교집'), open=True)
            for pl in BOOK_PLACES:
                tr.insert('G|BOOK', 'end', iid='Q|' + pl, text=AL.PLACE_NAME.get(pl, pl))
            # ★ 2026-10-28 (docs/1.txt 6-1) 내가 더한 도서 질문프롬프트 — 도서 화면 AI(연구/설교노트 갈래 · 도서 편 닻)에 뜬다
            for t in book_user_tasks(c):
                tr.insert('G|BOOK', 'end', iid='Q|REF:' + t, text=UA.task_title(c, 'REF', t, self.lang))
            tr.insert('', 'end', iid='G|FREE', text='Free', open=True)
            tr.insert('G|FREE', 'end', iid='Q|VERSE:FREE', text=T('AI_LIB_FREE_PICK', 'Free 대화 Pick'))
            grp = None
            for pl, g, nm in AL.all_places(c, self.lang):
                if ':' in pl and pl.split(':')[0] in ('VERSE', 'TERM', 'REF', 'BOOK'):
                    continue
                if g != grp:
                    grp = g
                    tr.insert('', 'end', iid='G|' + g, text=g, open=True)
                tr.insert('G|' + g, 'end', iid='Q|' + pl, text=nm)
            hg = next((g for pl, g, _n in AL.PLACES if pl == 'HOME:MEDI'), None)
            if hg and tr.exists('G|' + hg):
                for u in UA.user_tasks(c):
                    if 'HOME' in u.get('scopes', []):
                        tr.insert('G|' + hg, 'end', iid='Q|HOME:' + u['key'], text=UA.task_title(c, 'HOME', u['key'], self.lang))
            tr.insert('', 'end', iid='G|PRAYER', text=T('AI_LIB_G_PRAYER', '기도 노트 (폰)'), open=True)
            # ★ 2026-10-21 (AI도우미.txt 5-1) 폰 화면 차례대로 — 역할 · 공통 Pick · 기도 갈래(개인 · 교회 · 셀 · 선교지 · 나라 · 감사)마다 제 Pick
            tr.insert('G|PRAYER', 'end', iid='Q|' + PRAYER, text=T('AI_LIB_PRAYER_ROLE', '기도 도우미 역할'))
            tr.insert('G|PRAYER', 'end', iid='Q|PRAYER:COMMON', text=T('AI_LIB_PRAYER_COMMON', '공통 Pick (어느 기도에나)'))
            b = UA.prayer_bundle(c, self.lang)
            tt = {d['key']: d['title'] for d in b['tasks']}
            for mode in ('ME', 'US', 'THANKS'):
                for main, _picks in b['groups'].get(mode, []):
                    tr.insert('G|PRAYER', 'end', iid='Q|PRAYER:' + main, text=tt.get(main) or main)

    def select_node(self, iid):
        if not iid or not self._tr.exists(iid):
            iid = 'Q|VERSE:ASK' if self._tr.exists('Q|VERSE:ASK') else self._tr.get_children()[0]
        self._tr.selection_set(iid)
        self._tr.see(iid)
        self._on_node()

    def _on_node(self, _e=None):
        s = self._tr.selection()
        if not s or s[0] == self._node:
            return
        self.save()
        if s[0].startswith('G|'):
            kids = self._tr.get_children(s[0])
            if kids:
                self._tr.selection_set(kids[0])
            return
        self._node = s[0]
        self._sel = None
        self._edit_state(False)
        self._fill_list()
        self._sync_addq()
        if self._tv.exists(TASK_ROW):
            self._tv.selection_set(TASK_ROW)
            self.open(TASK_ROW)

    # ── 목록 ──────────────────────────────────────────────────────────
    def _place(self):
        return self._node[2:] if self._node and self._node.startswith('Q|') else None

    def _fill_list(self):
        tv = self._tv
        tv.delete(*tv.get_children())
        n = self._node or ''
        with self._conn() as c:
            if n.startswith('M|'):
                if self._free_cb.winfo_manager():
                    self._free_cb.pack_forget()
                self._head_lib.config(text=T('AI_LIB_HEAD_M', '대화통합화면에서 대화를 한 글로 엮을 때 AI 에게 보내는 지시입니다'))
                tv.insert('', 'end', iid='m|' + n[2:], values=('●', self._tr.item(n, 'text'), T('AI_LIB_K_M', '지시')))
                return
            if n.startswith('A|') or n.startswith('S|'):
                key = 'USER' if n.startswith('A|') else n[2:]
                self._free_v.set(key in free_show(c))
                if not self._free_cb.winfo_manager():
                    self._free_cb.pack(fill='x', before=tv, padx=2)
                self._head_lib.config(text=T('AI_LIB_HEAD_C', '어느 화면에서도 쓰는 칸입니다 — 「표시」 ● 가 지금 보내는 것입니다'))
                if n.startswith('A|'):
                    ax = n[2:]
                    cur = UA.get_axis(c, ax)
                    for k, t, _b in UA.axis_rows(c, ax, self.lang):
                        tv.insert('', 'end', iid='a|' + k, values=('●' if k == cur else '', t or k, T('AI_LIB_K_VAL', '항목')))
                else:
                    d = UA.part_sets(c, n[2:])
                    ck = set(d.get('checked') or [])
                    for i, it in enumerate(d['items']):
                        on = (i in ck) if it.get('multi') else (i == d['on'])
                        tv.insert('', 'end', iid='s|%d' % i, values=(
                            '●' if on else '', it.get('name') or T('AI_LIB_UNNAMED', '(이름 없음)'), T('AI_LIB_K_SET', '서식')))
            else:
                if self._free_cb.winfo_manager():
                    self._free_cb.pack_forget()
                pl = self._place()
                if not pl:
                    return
                self._head_lib.config(text=T('AI_LIB_HEAD_Q2', '질문프롬프트 구성항목')
                                      if not pl.startswith(PRAYER) else
                                      T('AI_LIB_HEAD_PR', '폰 기도 노트의 AI — 폰에서는 고르기만 하고 글은 여기서 고칩니다'))
                if pl.startswith(PRAYER):
                    b = UA.prayer_bundle(c, self.lang)
                    tk_ = {d['key']: d for d in b['tasks']}
                    common = ['PR_VERSE', 'PR_TODO'] + [d['key'] for d in b['tasks'] if d['mine']]
                    if pl == PRAYER:
                        tv.insert('', 'end', iid=ROLE_ROW, values=('●', UA.task_row(c, 'R_PRAYER', self.lang)[1] or
                                                                  T('AI_LIB_ROLE', '역할'), T('AI_LIB_K_ROLE', '역할')))
                    elif pl == 'PRAYER:COMMON':
                        for k in common:
                            if k in tk_:
                                tv.insert('', 'end', iid='r|' + tk_[k]['kind'], values=('✓', tk_[k]['title'] or k, 'Pick'))
                    else:
                        main = pl.split(':', 1)[1]
                        if main in tk_:
                            tv.insert('', 'end', iid='r|' + tk_[main]['kind'],
                                      values=('●', tk_[main]['title'] or main, T('AI_LIB_K_Q', '질문프롬프트')))
                        for mode in b['groups'].values():
                            for m_, picks in mode:
                                if m_ != main:
                                    continue
                                for k in picks:
                                    if k in tk_ and k not in common:
                                        tv.insert('', 'end', iid='r|' + tk_[k]['kind'], values=('✓', tk_[k]['title'] or k, 'Pick'))
                    return
                pt = place_task(pl)
                if pt:
                    sc, t = pt
                    k = UA.task_kind(sc, t) if not t.startswith('UT_') else t
                    if k:
                        tv.insert('', 'end', iid=TASK_ROW, values=('●', UA.task_title(c, sc, t, self.lang),
                                                                  T('AI_LIB_K_Q', '질문프롬프트')))
                    rk = UA.role_kind(t)
                    if rk:
                        tv.insert('', 'end', iid=ROLE_ROW, values=('●', T('AI_LIB_ROLE', '역할'), T('AI_LIB_K_ROLE', '역할')))
                for k, title, _b, it, _lg, on in AL.place_all(c, pl, self.lang):
                    kind = T('AI_LIB_K_Q', '질문프롬프트') if it == 'TASK' else 'Pick'
                    tv.insert('', 'end', iid='p|' + k, values=('✓' if (on or it == 'TASK') else '', title or k, kind))
        if self._sel and tv.exists(self._sel):
            tv.selection_set(self._sel)
            tv.see(self._sel)

    def _on_click(self, e):
        if self._tv.identify_region(e.x, e.y) != 'cell' or self._tv.identify_column(e.x) != '#1':
            return
        r = self._tv.identify_row(e.y)
        if r.startswith('p|') and self._tv.set(r, 'kind') == 'Pick':
            self.toggle(r[2:])
            return 'break'
        if r.startswith('a|') or r.startswith('s|'):
            self._tv.selection_set(r)
            self._use_this()
            return 'break'
        return None

    def toggle(self, key, on=None):
        """이 질문에서 이 Pick 을 화면에 보이나 — 켜고 끈다(자리에는 남는다)."""
        pl = self._place()
        with self._conn() as c:
            cur = pl in AL.places_of(c, key)
            AL.set_used(c, pl, key, (not cur) if on is None else bool(on))
        self._fill_list()
        self._say(T('AI_LIB_TOGGLED2', '표시를 바꿨습니다'))
        self._changed()

    def _toggle_free(self):
        n = self._node or ''
        key = 'USER' if n.startswith('A|') else n[2:]
        with self._conn() as c:
            set_free_show(c, key, self._free_v.get())
        self._say(T('AI_LIB_FREE_SAID', 'Free 화면 표시를 바꿨습니다'))
        self._changed()

    def _on_item(self, _e=None):
        s = self._tv.selection()
        if not s or s[0] == self._sel:
            return
        self.save()
        self.open(s[0])

    # ── 고치기 ────────────────────────────────────────────────────────
    def _edit_state(self, on, reset_ok=False, del_ok=False, del_txt=None, use=False, move=False):
        st = 'normal' if on else 'disabled'
        for w in (self._name, self._body):
            w.configure(state='normal')
            if not on:
                w.delete(0, 'end') if w is self._name else w.delete('1.0', 'end')
            w.configure(state=st)
        self._reset_btn.configure(state='normal' if reset_ok else 'disabled')
        self._del_btn.configure(state='normal' if del_ok else 'disabled',
                                text=' %s ' % (del_txt or T('AI_LIB_DEL2', '지우기')))
        for b, want in ((self._use_btn, use), (self._up_btn, move), (self._dn_btn, move)):
            if want and not b.winfo_manager():
                b.pack(side='right', padx=2)
            elif not want and b.winfo_manager():
                b.pack_forget()
        if not on:
            self._ed_head.config(text='')            # ★ 2026-10-21 (AI도우미.txt 1) 안내 줄 걷음
            self._uses.config(text='')

    def _sel_kind(self, row):
        """줄 → (갈래, 열쇠) — TASK · ROLE · PICK · PRAYER · AXIS · PART"""
        pl = self._place()
        if row == TASK_ROW:
            sc, t = place_task(pl)
            return 'TASK', (UA.task_kind(sc, t) if not t.startswith('UT_') else t)
        if row == ROLE_ROW:
            if pl == PRAYER:
                return 'TASK', 'R_PRAYER'
            return 'ROLE', UA.role_kind(place_task(pl)[1])
        if row.startswith('p|'):
            return 'PICK', row[2:]
        if row.startswith('r|'):
            return 'PRAYER', row[2:]
        if row.startswith('a|'):
            return 'AXIS', row[2:]
        if row.startswith('s|'):
            return 'PART', int(row[2:])
        if row.startswith('m|'):
            return 'MERGE', row[2:]
        return '', None

    def open(self, row):
        self._sel = row
        g, key = self._sel_kind(row)
        info = ''
        with self._conn() as c:
            if g in ('TASK', 'ROLE'):
                _p, title, body = UA.task_row(c, key, self.lang)
                pl = self._place()
                pt = place_task(pl) if pl != PRAYER else None
                if g == 'TASK' and pt:
                    title = UA.task_title(c, pt[0], pt[1], self.lang)     # 왼쪽 칸과 같은 이름
                hidable = bool(pt) and g == 'TASK'
                if hidable and pt[1].startswith('UT_'):
                    dtxt = T('AI_LIB_DELQ', '질문프롬프트 지우기')
                elif hidable:
                    dtxt = (T('AI_LIB_SHOWQ', '다시 보이기') if pl in UA.hidden_tasks(c) else T('AI_LIB_DELQ', '질문프롬프트 지우기'))
                else:
                    dtxt = None
                self._edit_state(True, reset_ok=not str(key).startswith(('UT_', 'UR_')), del_ok=hidable, del_txt=dtxt)
                info = (T('AI_LIB_ROLE_NOTE', 'AI 에게 맡기는 역할입니다 — 이 질문프롬프트에만 붙습니다') if g == 'ROLE'
                        else T('AI_LIB_TASK_NOTE2', '이 질문프롬프트의 할 일입니다 — 이 자리에서만 씁니다'))
            elif g == 'PICK':
                r = AL._pick_lang(c, key, self.lang)
                if not r:
                    self._edit_state(False)
                    return
                _lid, title, body, itype, lg = r
                seed = c.execute("SELECT seed_body FROM user_ai_lib WHERE item_key=? AND lang_code=?", (key, lg)).fetchone()
                self._edit_state(True, reset_ok=bool(seed and seed[0] is not None), del_ok=itype != 'TASK',
                                 move=itype != 'TASK')
                info = T('AI_LIB_PICK_NOTE', '이 질문프롬프트에서만 쓰는 Pick 입니다')
                if lg != self.lang:
                    info += '\n' + T('AI_LIB_FALLBACK', '이 언어 글이 아직 없어 %s 글을 보입니다 — 고치면 이 언어 글로 저장됩니다') % lg
            elif g == 'PRAYER':
                _p, title, body = UA.task_row(c, key, self.lang)
                mine = key.startswith('T_PR_U')
                self._edit_state(True, reset_ok=not mine, del_ok=mine)
                info = T('AI_LIB_PR_NOTE', '폰 기도 노트에서 선택하는 Pick 입니다 — 앱이 정한 여섯은 지우지 못하고 처음 글로 되돌릴 수 있습니다')
            elif g == 'AXIS':
                title = body = ''
                for k, t, b in UA.axis_rows(c, self._node[2:], self.lang):
                    if k == key:
                        title, body = t, b
                ax = self._node[2:]
                self._edit_state(True, reset_ok=key in (UA.AXIS_KINDS.get(ax) or []),
                                 del_ok=key != UA.AXIS_DEFAULT.get(ax), use=True)
                info = T('AI_LIB_AX_NOTE', '[이것으로 쓰기]를 누르면 보내는 글의 「사용자」 칸이 이것이 됩니다')
            elif g == 'MERGE':
                if key == 'MERGE':
                    _p, title, body = UA.merge_prompt_row(c, self.lang)
                else:
                    title, body = self._tr.item(self._node, 'text'), UA.integ_prompt(c, self.lang)
                self._edit_state(True, reset_ok=True, del_ok=False)
                info = T('AI_LIB_M_NOTE', '[초기값으로]를 누르면 앱이 처음 넣은 글로 돌아갑니다')
            elif g == 'PART':
                d = UA.part_sets(c, self._node[2:])
                it = d['items'][key] if 0 <= key < len(d['items']) else {}
                title, body = it.get('name') or '', it.get('body') or ''
                self._edit_state(True, reset_ok=False, del_ok=len(d['items']) > 1, use=True)
                info = T('AI_LIB_PT_NOTE', '[이것으로 쓰기]를 누르면 보내는 글의 이 칸이 이것이 됩니다')
            else:
                self._edit_state(False)
                return
        self._ed_head.config(text=title or str(key))
        self._name.delete(0, 'end')
        self._name.insert(0, title or '')
        self._body.delete('1.0', 'end')
        self._body.insert('1.0', body or '')
        self._body.edit_reset()
        self._uses.config(text=info)
        self._dirty = False

    def _touched(self, _e=None):
        self._dirty = True
        if self._job:
            self.after_cancel(self._job)
        self._job = self.after(700, self.save)

    def _commit_ime(self, w):
        try:
            import ime_hint
            if ime_hint.commit(w.winfo_id()):
                self.update()
        except Exception:                                 # noqa: BLE001
            pass

    def save(self):
        """고친 것을 적는다 — 바뀐 것이 있을 때만."""
        if self._job:
            try:
                self.after_cancel(self._job)
            except Exception:                             # noqa: BLE001
                pass
            self._job = None
        if not self._sel or not self._dirty:
            return False
        for w in (self._name, self._body):
            self._commit_ime(w)
        title = (self._name.get() or '').strip()
        body = self._body.get('1.0', 'end').strip()
        g, key = self._sel_kind(self._sel)
        with self._conn() as c:
            if g in ('TASK', 'ROLE'):
                pt = place_task(self._place() or '') if g == 'TASK' and self._place() != PRAYER else None
                if pt and UA.is_title_default(c, pt[0], pt[1], self.lang, title):
                    title = None                        # 화면이 저절로 보이는 이름 그대로 — 「고친 이름」으로 굳히지 않는다
                UA.put_task_text(c, key, self.lang, body=body, title=title or None)
            elif g == 'PICK':
                AL.save_item(c, key, self.lang, title or None, body)
            elif g == 'PRAYER':
                UA.put_prayer_prompt(c, key, self.lang, title=title or None, body=body)
            elif g == 'AXIS':
                pid = UA.axis_prompt_id(c, key, self.lang)
                if pid is None:
                    c.execute("INSERT INTO user_ai_prompt(lang_code, kind, title, body, sort_order, scope, genre)"
                              " VALUES(?,?,?,?,?,'AXIS','ANAL')", (self.lang, key, title or key, body, 900))
                else:
                    UA.save_prompt(c, pid, title or key, body)
            elif g == 'PART':
                UA.part_write(c, self._node[2:], key, name=title, body=body)
            elif g == 'MERGE':
                if key == 'MERGE':
                    pid = UA.merge_prompt_row(c, self.lang)[0]
                    if pid:
                        UA.save_prompt(c, pid, title or UA.merge_prompt_row(c, self.lang)[1], body)
                else:
                    UA.set_setting(c, 'AI_INTEG_PROMPT', body)
            c.commit()
        self._dirty = False
        self._ed_head.config(text=title or str(key))
        keep = self._sel
        self._fill_list()
        if g in ('TASK',) and self._place() and self._place() != PRAYER:
            self._fill_tree_keep()
        self._sel = keep
        self._say(T('AI_LIB_SAVED', '저장했습니다'))
        self._changed()
        return True

    def _fill_tree_keep(self):
        n = self._node
        self._fill_tree()
        if n and self._tr.exists(n):
            self._tr.selection_set(n)
            self._tr.see(n)

    def _reset(self):
        if not self._sel:
            return
        self._dirty = False
        g, key = self._sel_kind(self._sel)
        with self._conn() as c:
            if g in ('TASK', 'ROLE', 'PRAYER'):
                ok = UA.reset_task(c, key, self.lang)
            elif g == 'PICK':
                ok = AL.reset_item(c, key, self.lang)
            elif g == 'AXIS':
                ok = UA.restore_axis(c, self._node[2:], key, self.lang)
            elif g == 'MERGE':
                if key == 'MERGE':
                    pid = UA.merge_prompt_row(c, self.lang)[0]
                    sd = UA.SEED_PROMPTS['MERGE'].get(self.lang) or UA.SEED_PROMPTS['MERGE']['EN']
                    if pid:
                        UA.save_prompt(c, pid, sd[0], sd[1])
                else:
                    c.execute("DELETE FROM user_config WHERE config_key='AI_INTEG_PROMPT'")
                c.commit()
                ok = True
            else:
                ok = False
        if ok:
            self.open(self._sel)
            self._fill_list()
            self._say(T('AI_LIB_RESET_DONE', '처음 글로 되돌렸습니다'))
            self._changed()

    def _use_this(self):
        if not self._sel:
            s = self._tv.selection()
            if not s:
                return
            self._sel = s[0]
        self.save()
        g, key = self._sel_kind(self._sel)
        with self._conn() as c:
            if g == 'AXIS':
                UA.set_axis(c, self._node[2:], key)
            elif g == 'PART':
                UA.part_select(c, self._node[2:], key)
            else:
                return
            c.commit()
        keep = self._sel
        self._fill_list()
        self._sel = keep
        if self._tv.exists(keep):
            self._tv.selection_set(keep)
        self._say(T('AI_LIB_USED', '이것으로 보냅니다'))
        self._changed()

    def _move(self, step):
        g, key = self._sel_kind(self._sel or '')
        if g != 'PICK':
            return
        with self._conn() as c:
            AL.move_item(c, self._place(), key, step)
        keep = self._sel
        self._fill_list()
        self._sel = keep
        if self._tv.exists(keep):
            self._tv.selection_set(keep)
            self._tv.see(keep)
        self._changed()

    def _delete(self):
        """지운다(숨긴다) — 한 번 더 눌러야 한다(팝업 없음)."""
        k = self._sel
        if not k:
            return
        g, key = self._sel_kind(k)
        if getattr(self, '_del_armed', None) != k:
            self._del_armed = k
            self._say(T('AI_LIB_DEL_ASK2', '한 번 더 누르면 지웁니다(숨기기는 되살릴 수 있습니다)'))
            return
        self._del_armed = None
        pl = self._place()
        tree = False
        with self._conn() as c:
            if g == 'TASK' and place_task(pl):
                sc, t = place_task(pl)
                if t.startswith('UT_'):
                    UA.hide_user_task(c, t)
                else:
                    UA.set_task_hidden(c, sc, t, pl not in UA.hidden_tasks(c))
                tree = True
            elif g == 'PICK':
                # ★ 2026-10-28 내가 더한 카드 갈래의 갈래 글(TASK)을 지우면 갈래째 걷는다
                if pl in AL._user_place_keys(c) and self._tv.set(k, 'kind') != 'Pick':
                    AL.remove_place(c, pl)
                    tree = True
                else:
                    AL.hide_item(c, key)
            elif g == 'PRAYER':
                UA.hide_prayer_prompt(c, key)
            elif g == 'AXIS':
                UA.hide_axis_item(c, key)
            elif g == 'PART':
                UA.part_del(c, self._node[2:], key)
            c.commit()
        self._sel = None
        self._edit_state(False)
        if tree:
            self._fill_tree_keep()
            if not self._tr.exists(self._node or ''):
                self._node = None
                self.select_node(None)
        self._fill_list()
        self._say(T('AI_LIB_DELETED', '지웠습니다') if g != 'TASK' else T('AI_LIB_HID_DONE', '바꿨습니다'))
        self._changed()

    # ── 더하기 ────────────────────────────────────────────────────────
    def add_question(self):
        """지금 묶음(구절 · 용어 · 연구/설교노트)에 내 질문프롬프트를 더한다."""
        self.save()
        sc = self._addq_scope()
        if not sc:
            # ★ 2026-10-21 (AI도우미.txt 5) 옛 코드는 여기서 말없이 「구절」에 더했다(공통·도서·Free·홈·기도를 고른 채 누르면)
            self._say(T('AI_LIB_ADDQ_WHERE2', '질문프롬프트는 구절 · 용어 · 연구/설교노트 · 도서/설교집 · 홈 AI 대화 · 말씀카드 묶음에 더합니다 — 왼쪽에서 그 묶음을 먼저 선택하세요'))
            return None
        with self._conn() as c:
            if sc == 'CARD':
                # ★ 2026-10-28 (docs/1.txt 6-1) 말씀카드 묶음 = 새 카드 갈래(폰 말씀카드에도 그 갈래가 뜬다)
                pl = AL.add_card_place(c, self.lang, T('AI_NEW_CARD', '새 갈래'))
                c.commit()
                node, t = 'Q|' + pl, pl
            else:
                t = UA.add_user_task(c, sc, self.lang, T('AI_NEW_TASK', '새 질문프롬프트'), '')
                c.commit()
                node = 'Q|%s:%s' % ('REF' if sc == 'BOOK' else sc, t)
        self._fill_tree()
        self.select_node(node)
        if sc == 'CARD':
            row = next((r for r in self._tv.get_children() if r.startswith('p|')), None)
            if row:
                self._tv.selection_set(row)
                self.open(row)
                self._name.focus_set()
                self._name.select_range(0, 'end')
            self._say(T('AI_LIB_ADDED_CARD', '새 카드 갈래를 더했습니다 — 이름(「말씀카드 · 」 뒤)과 글을 고치고 Pick 을 더하세요'))
            self._changed()
            return t
        self._changed()
        if self._tv.exists(TASK_ROW):
            self._tv.selection_set(TASK_ROW)
            self.open(TASK_ROW)
            self._name.focus_set()
            self._name.select_range(0, 'end')
        self._say(T('AI_LIB_ADDED_Q', '새 질문프롬프트를 더했습니다 — 이름과 할 일을 적으세요'))
        self._changed()
        return t

    def add_item(self):
        """지금 고른 것에 항목을 더한다 — 질문프롬프트면 Pick · 공통이면 서식/항목."""
        self.save()
        n = self._node or ''
        row = None
        with self._conn() as c:
            if n.startswith('Q|'):
                pl = n[2:]
                if pl.startswith(PRAYER):
                    _nt = T('AI_NEW_PROMPT_TITLE', '새 프롬프트')
                    k = UA.add_prayer_prompt(c, self.lang, _nt, _nt)     # ⚠ 빈 글은 안 만든다(put_prayer_prompt)
                    row = 'r|' + k
                    n = 'Q|PRAYER:COMMON'                      # 사람이 더한 기도 Pick 은 어느 기도에나 붙는다(폰 규칙)
                else:
                    k = AL.add_item(c, self.lang, T('AI_NEW_PROMPT_TITLE', '새 프롬프트'), '', places=(pl,))
                    row = 'p|' + k
            elif n.startswith('A|'):
                k = UA.add_axis_item(c, n[2:], self.lang, T('AI_NEW_ITEM', '새 항목'), '')
                row = 'a|' + k if k else None
            elif n.startswith('S|'):
                i = UA.part_add(c, n[2:], T('AI_NEW_SET', '새 서식'))
                row = 's|%d' % i
            c.commit()
        if n != (self._node or ''):
            self._tr.selection_set(n)
            self._node = n
        self._fill_list()
        if row and self._tv.exists(row):
            self._tv.selection_set(row)
            self._tv.see(row)
            self.open(row)
            self._name.focus_set()
            self._name.select_range(0, 'end')
        self._say(T('AI_LIB_ADDED2', '더했습니다 — 이름과 내용을 적으세요'))
        self._changed()
        return row

    def _say(self, s):
        self._msg.config(text=s)

    def _addq_scope(self):
        """[+ 질문프롬프트]를 더할 갈래 — 구절 · 용어 · 연구/설교노트 · 홈 AI 대화(★ 2026-10-28 docs/1.txt 6-1)."""
        n = self._node or ''
        if not n.startswith('Q|') or n[2:] == 'VERSE:FREE':
            return None
        pl = n[2:]
        head = pl.split(':')[0]
        if pl in BOOK_PLACES:
            return 'BOOK'
        if head == 'CARD':                        # 말씀카드 묶음 = 새 카드 갈래
            return 'CARD'
        if head == 'REF' and pl[4:].startswith('UT_'):
            with self._conn() as c:
                if pl[4:] in book_user_tasks(c):
                    return 'BOOK'
        if head in ('VERSE', 'TERM', 'REF'):
            return head
        if head in ('HOME', 'NEWS'):              # 홈 AI 대화 묶음(묵상 · 성경공부 · 사회현상 · 뉴스 · 내 홈 질문)
            return 'HOME'
        return None

    def _sync_addq(self):
        """[+ 질문프롬프트] — 더할 수 있는 묶음(구절 · 용어 · 연구/설교노트 · 홈 AI 대화)을 골랐을 때만 진하게."""
        try:
            self._addq_btn.configure(state='normal' if self._addq_scope() else 'disabled')
        except Exception:                                 # noqa: BLE001
            pass

    def _changed(self):
        if self.on_changed:
            try:
                self.on_changed()
            except Exception:                             # noqa: BLE001
                pass

    def close(self):
        self.save()
        if self.on_close:
            self.on_close()


def selftest():
    ok, fails = 0, []

    def ck(c, m):
        nonlocal ok
        if c:
            ok += 1
        else:
            fails.append(m)
    ck(place_task('VERSE:ASK') == ('VERSE', 'ASK'), '앱 자리 → (갈래, 질문)')
    ck(place_task('BOOK:NOTE') == ('VERSE', 'NOTE'), '도서노트 분석은 묵상노트 분석 글')
    ck(place_task('VERSE:FREE') is None and place_task('NEWS') is None and place_task('HOME:MEDI') is None,
       '라이브러리 안에 질문 글이 있는 자리')
    ck(set(BOOK_PLACES) <= set(AL.PLACE_KEYS), '도서 자리가 자리 목록에')
    print('ai_lib_view selftest %d/%d' % (ok, ok + len(fails)))
    for f in fails:
        print('  FAIL', f)
    return not fails


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
