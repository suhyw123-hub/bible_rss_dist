"""
plan_hierarchy.py  —  공유 플랜 계층 로더
세 화면(plan_main_view, panel_plan_manager, panel_plan_list)이
모두 이 함수를 통해 동일한 데이터를 얻는다.
"""

import sqlite3


def load_plan_hierarchy(conn: sqlite3.Connection,
                        lang: str = 'KO') -> tuple[dict, dict]:
    """
    Returns (cats, plans)

    cats[cat_id] = {
        'cat_id', 'parent_id', 'sort_order',
        'name',              # lang 우선, KO 폴백
        'children',          # [cat_id, ...] sort_order 순
        'plans',             # [plan_id, ...] sort_order 순 (해당 cat 직속)
        'root_ancestor_id',  # 루트 cat_id (자신이 루트면 자기 자신)
    }

    plans[plan_id] = {
        'plan_id', 'code', 'ptype', 'plan_category',
        'cat_id', 'sort_order', 'status',
        'title_ko', 'title_en',
    }
    """
    lang_upper = lang.upper()

    # ── 카테고리 ──────────────────────────────────────────────────────────────
    cat_rows = conn.execute(
        "SELECT c.cat_id, c.parent_id, c.sort_order "
        "FROM sys_plan_category c WHERE c.record_status='LIVE' "
        "ORDER BY COALESCE(c.parent_id, c.cat_id), c.sort_order"
    ).fetchall()

    name_rows = conn.execute(
        "SELECT clicked_id, UPPER(lang_code), contents "
        "FROM sys_text_asset "
        "WHERE text_type='PLAN_CAT_NAME' AND record_status='LIVE'"
    ).fetchall()
    name_map: dict = {}
    for cid, lc, val in name_rows:
        name_map[(cid, lc)] = val or ''

    cats: dict[int, dict] = {}
    for cat_id, parent_id, sort_order in cat_rows:
        name = (name_map.get((cat_id, lang_upper))
                or name_map.get((cat_id, 'KO'))
                or f'카테고리{cat_id}')
        cats[cat_id] = dict(
            cat_id=cat_id, parent_id=parent_id,
            sort_order=sort_order or 0,
            name=name, children=[], plans=[],
            root_ancestor_id=cat_id,
        )

    for d in cats.values():
        pid = d['parent_id']
        if pid is not None and pid in cats:
            cats[pid]['children'].append(d['cat_id'])

    for d in cats.values():
        d['children'].sort(key=lambda cid: cats[cid]['sort_order'])

    # root_ancestor_id 계산 (순환 방지)
    def _root_of(cid: int) -> int:
        seen: set[int] = set()
        while True:
            seen.add(cid)
            pid = cats[cid]['parent_id']
            if pid is None or pid not in cats or pid in seen:
                return cid
            cid = pid

    for cid in cats:
        cats[cid]['root_ancestor_id'] = _root_of(cid)

    # ── 플랜 ─────────────────────────────────────────────────────────────────
    plan_cols = {r[1] for r in conn.execute("PRAGMA table_info(sys_bible_plan)")}
    so_expr = ("COALESCE(p.sort_order, p.plan_id*10)"
               if 'sort_order' in plan_cols else "p.plan_id*10")

    plan_rows = conn.execute(f"""
        SELECT p.plan_id, p.plan_code, p.plan_type,
               COALESCE(p.plan_category, 'THEMATIC'), p.cat_id,
               {so_expr}, p.record_status,
               (SELECT ta.contents FROM sys_text_asset ta
                WHERE ta.text_type='PLAN_TITLE' AND ta.clicked_id=p.plan_id
                  AND ta.lang_code='KO' AND ta.record_status='LIVE' LIMIT 1),
               (SELECT ta.contents FROM sys_text_asset ta
                WHERE ta.text_type='PLAN_TITLE' AND ta.clicked_id=p.plan_id
                  AND ta.lang_code='EN' AND ta.record_status='LIVE' LIMIT 1)
        FROM sys_bible_plan p
        WHERE p.record_status IN ('LIVE','HIDE')
        ORDER BY {so_expr}, p.plan_id
    """).fetchall()

    plans: dict[int, dict] = {}
    for pid, code, ptype, category, cat_id, so, status, tko, ten in plan_rows:
        plans[pid] = dict(
            plan_id=pid, code=code, ptype=ptype,
            plan_category=category, cat_id=cat_id,
            sort_order=so, status=status,
            title_ko=tko or code, title_en=ten or '',
        )
        if cat_id is not None and cat_id in cats:
            cats[cat_id]['plans'].append(pid)

    for d in cats.values():
        d['plans'].sort(key=lambda pid: plans[pid]['sort_order'])

    return cats, plans


def sorted_root_cats(cats: dict) -> list[dict]:
    """루트 카테고리를 sort_order 순으로 반환."""
    roots = [d for d in cats.values() if d['parent_id'] is None]
    roots.sort(key=lambda d: d['sort_order'])
    return roots
