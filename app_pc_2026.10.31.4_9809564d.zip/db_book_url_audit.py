# -*- coding: utf-8 -*-
"""db_book_url_audit.py — 적어 둔 출처 주소가 **그 책이 맞는가** (영구·selftest)

`python db_book_url_audit.py --selftest`  — 의무
`python db_book_url_audit.py --check`     — 전수 점검 (내려받지 않는다)

━━ 왜 만들었나 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
적어 둔 구텐베르크 번호가 **딴 책**인 일이 2026-08-22 하루에 넷 나왔다.
  · 바운즈  #16905 → 『The Great Red Frog』
  · 번연 은혜 #4186 → 『Diary of Samuel Pepys 제62권』
  · 셸던    #289  → 『The Wind in the Willows』
  · 로렌스  #13790 → 없는 번호
그리고 CCEL 주소 둘(`murray/abide`·`miller/comeyeapart`)은 **404** 였다.
⇒ 출처가 틀리면 **저작권 고지 자체가 거짓**이 된다. 기계가 세어야 한다.

★ **본문을 내려받지 않는다.** 구텐베르크 목록(gutendex)에 번호만 물어보고,
  CCEL·IA 는 주소가 살아 있는지만 두드린다. 값싸므로 자주 돌릴 수 있다.
"""
import json
import re
import subprocess
import sys

sys.path.insert(0, __file__.rsplit('\\', 1)[0] if '\\' in __file__ else '.')
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import appdb
import db_book_source_match as SM

DB = 'bible_master.db'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/125.0 Safari/537.36'


def _get(url, timeout='60'):
    return subprocess.run(['curl', '-sL', '--max-time', timeout, '-A', UA, url],
                          capture_output=True).stdout.decode('utf-8', 'replace')


def _head_code(url):
    r = subprocess.run(['curl', '-sIL', '--max-time', '60', '-A', UA,
                        '-o', 'NUL', '-w', '%{http_code}', url],
                       capture_output=True)
    s = r.stdout.decode('utf-8', 'replace').strip().split()
    return s[-1] if s else '?'


def pg_id(url):
    m = re.search(r'gutenberg\.org/(?:ebooks|files|cache/epub)/(\d+)',
                  url or '')
    return m.group(1) if m else None


def pg_meta(num):
    """구텐베르크 목록이 밝히는 제목·저자. 없으면 (None, None)."""
    try:
        d = json.loads(_get('https://gutendex.com/books/%s' % num))
    except Exception:
        return None, None
    if not d or d.get('detail'):
        return None, None
    return (d.get('title') or '').replace('\n', ' '), \
           ', '.join(a['name'] for a in d.get('authors', []))


def audit(conn, only=None):
    """→ [(book_code, 판정, 설명)] · 판정 = OK | WRONG | DEAD | SKIP"""
    out = []
    rows = conn.execute("""
        SELECT book_code, title, author, source_url FROM sys_book_asset
         WHERE COALESCE(record_status,'LIVE')='LIVE' ORDER BY book_code"""
                        ).fetchall()
    for code, title, author, url in rows:
        if only and code not in only:
            continue
        if not (url or '').strip():
            out.append((code, 'SKIP', '주소가 비어 있다'))
            continue
        num = pg_id(url)
        if num:
            t, a = pg_meta(num)
            if t is None:
                out.append((code, 'DEAD', '구텐베르크 #%s — 목록에 없다' % num))
                continue
            ok, why = SM.meta_ok(title, author, t, a)
            out.append((code, 'OK' if ok else 'WRONG',
                        '구텐베르크 #%s = 「%s」 / %s%s'
                        % (num, t[:44], a[:26], '' if ok else '  ← ' + why)))
            continue
        code_http = _head_code(url)
        if code_http.startswith('2'):
            out.append((code, 'OK', '%s (HTTP %s)' % (url[:58], code_http)))
        else:
            out.append((code, 'DEAD', '%s (HTTP %s)' % (url[:58], code_http)))
    return out



def rule_count(conn):
    """룰엔진이 부르는 한 문 → `(어긋난 수, 짧은 설명)`.

    ★ **여기서 다시 세지 않는다** — 이 도구가 이미 하는 일을 그대로 받는다.
      두 벌로 세면 한쪽만 고쳐진다(§db_rules 머리말).
    """
    # ⚠⚠ **네트워크를 타지 않는다** — 룰엔진은 조용히 세는 자리다.
    #   실제 주소 점검은 `--check` 로 사람이 돌린다. 여기서는 **DB 안에서
    #   알 수 있는 것**(출처가 비었나)만 본다.
    try:
        n = conn.execute(
            "SELECT COUNT(*) FROM sys_book_asset b"
            " WHERE COALESCE(b.record_status,'LIVE')='LIVE'"
            "   AND NOT EXISTS(SELECT 1 FROM sys_book_source s"
            "     WHERE s.book_code=b.book_code)").fetchone()[0]
    except Exception:
        return 0, '(sys_book_source 가 아직 없다)'
    return n, ('출처 기록 없는 책 %d권' % n) if n else ''


def _selftest():
    fails = []

    def ck(n, ok, got=''):
        print(('  OK  ' if ok else '  FAIL') + ' ' + n +
              ('  | ' + str(got) if got != '' else ''))
        if not ok:
            fails.append(n)

    ck('번호를 뽑는다',
       pg_id('https://www.gutenberg.org/ebooks/654') == '654')
    ck('cache 주소도', pg_id('https://www.gutenberg.org/cache/epub/131/pg131.txt')
       == '131')
    ck('구텐베르크가 아니면 None',
       pg_id('https://ccel.org/ccel/bunyan/grace') is None)

    # ★ 탐지력 — **딴 책을 실제로 잡아내는가** (바운즈가 겪은 그 번호)
    t, a = pg_meta('16905')
    ck('#16905 를 물어본다', t is not None, t)
    if t:
        ok, why = SM.meta_ok('Power Through Prayer', 'E.M. Bounds', t, a)
        ck('#16905 는 바운즈가 아니라고 잡는다', not ok, '%s → %s' % (t[:40], why))
    t, a = pg_meta('65115')
    if t:
        ok, _ = SM.meta_ok('Power Through Prayer', 'E.M. Bounds', t, a)
        ck('#65115 는 바운즈가 맞다고 한다', ok, t[:40])
    ck('없는 번호는 None', pg_meta('99999999')[0] is None)

    conn = appdb.connect(DB)
    r = audit(conn, only={'BOUNDS_PTP'})
    ck('실제 DB 한 권을 잰다', r and r[0][1] in ('OK', 'WRONG', 'DEAD'), r)
    conn.close()
    print('\n=== %s (%d fail) ===' %
          ('PASS' if not fails else 'FAIL: ' + ', '.join(fails), len(fails)))
    return 0 if not fails else 1


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        raise SystemExit(_selftest())
    if '--check' in a:
        conn = appdb.connect(DB)
        res = audit(conn)
        conn.close()
        bad = [x for x in res if x[1] in ('WRONG', 'DEAD')]
        for code, verdict, why in res:
            mark = {'OK': '  ', 'WRONG': '✗✗', 'DEAD': '✗ ', 'SKIP': '· '}[verdict]
            print('%s %-18s %s' % (mark, code, why))
        print()
        print('%d권 · 어긋남 %d건' % (len(res), len(bad)))
        raise SystemExit(1 if bad else 0)
    print(__doc__)


if __name__ == '__main__':
    main()
