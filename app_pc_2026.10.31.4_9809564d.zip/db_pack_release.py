# -*- coding: utf-8 -*-
"""**종합 버전(릴리스)** — 「9번을 받으면 연결이 100% 정상」을 만든다.

★★★ 왜 (2026-09-05 사용자 확정 「여러 자산을 배포하는데 **연결관계가 일맥상통**
  하려면 **버전 관리를 종합적으로** 해야 한다. **각 자산마다 버전관리를 따로
  하면 안 될 것 같다**. … `C-9 + A1-9 + A2-9` … **A3-8만 있으면 다운받지
  않아도 된다** … 상호 영향이 없는 독자적 업그레이드라면 `C-9-1`, `A1-9-2`」).

```
      C  -  9  -  2
      │     │     └ 독자 판 — 상대와 무관한 손질(사용자는 안 봐도 된다)
      │     └────── **연동 판** — 이 숫자가 같으면 서로 맞는다
      └──────────── 자산 기호
```

★★★ **왜 「9번이면 100% 정상」이 성립하나**
  · 연동 판은 **상대를 건드렸을 때만** 오른다. 그래서 같은 숫자끼리 맞는 것이
    **정의상** 보장된다.
  · **A3-8 은 그대로 둔다** — 8판 이후 연동 변화가 없었으므로 C-9 와도 맞는다.
    **안 받아도 된다**(사용자 지적 그대로).

★★★ **연동인가 독자인가를 「자동으로」 가른다 — 사람이 안 정한다**
  ⚠⚠ 사람이 고르게 하면 **반드시 틀린다**(연결을 건드린 줄 모르고 독자로 올린다).
  ⇒ **바뀐 표가 어느 층인가**로 기계가 판정한다:
    | 바뀐 표 | 판정 |
    |---|---|
    | 자산 — PACK 표만(본문 글자) | 독자 |
    | 자산 — 껍데기(새 유닛·편) | **연동** |
    | 코어 — 연결·껍데기 표 | **연동** |
    | 코어 — 그 밖(ui_strings·플랜·엔티티) | 독자 |

⚠ **`sys_pack_item.version` 이 곧 연동 판이다** — 새 칸을 만들지 않았다.
  독자 판만 `own_version` 으로 더한다(기본 0).
⚠ **연동 판은 안 내린다** — 한 번 10이 되면 9로 되돌리지 않는다.

`--selftest`(의무) · `--status` · `--classify` · `--bump` · `--mine`.
"""
import argparse
import os
import sys

import appdb

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')

#: 연동(LINK) 인가 독자(OWN) 인가.
LINK, OWN = 'LINK', 'OWN'

#: 코어에서 **연동**으로 보는 표 — 자산을 가리키거나 자산의 껍데기다.
#: ⚠ 늘리면 여기 한 줄. 빠지면 **연동 수정이 독자로 잘못 판정**된다.
CORE_LINK_TABLES = None      # None = 아래 `_core_link_tables()` 가 계산


def _core_link_tables(conn=None):
    """코어에서 연동으로 보는 표 → set.

    ★ **분류표에서 유도한다** — 손으로 적으면 표가 늘 때 빠진다.
      연결(`*link*`) + 껍데기(자산의 제목·목록을 담는 표).
    """
    if CORE_LINK_TABLES:
        return set(CORE_LINK_TABLES)
    shells = {'bible_version', 'sys_book_asset', 'sys_book_unit',
              'sys_commentary_source', 'sys_commentary_entry',
              'sys_ref_source', 'sys_ref_unit'}
    try:
        import db_pack_catalog as CAT
        core = {t for t, (l, _k, _d) in CAT.TABLES.items() if l == 'CAT_CORE'}
        if not core:
            core = {t for t, (l, _k, _d) in CAT.TABLES.items() if l == 'CORE'}
    except Exception:
        core = set()
    return {t for t in core if 'link' in t.lower()} | (shells & core) | shells


def ensure(conn):
    """`own_version` 칸을 마련한다(멱등)."""
    try:
        cols = [r[1] for r in conn.execute("PRAGMA table_info(sys_pack_item)")]
    except Exception:
        return False
    if 'own_version' not in cols:
        conn.execute("ALTER TABLE sys_pack_item ADD COLUMN own_version"
                     " INTEGER DEFAULT 0")
        conn.commit()
    return True


def label(kind, key=None, link_ver=0, own_ver=0):
    """사람이 읽는 판 이름 → `C-9-2` · `KRV-9`.

    ⚠ **독자 판이 0 이면 안 붙인다** — 사용자는 그것을 안 봐도 된다.
    """
    k = (kind or '').upper()
    sym = 'C' if k == 'CORE' else (str(key or k).split('#')[0][:16] or k)
    s = '%s-%d' % (sym, int(link_ver or 0))
    if int(own_ver or 0):
        s += '-%d' % int(own_ver)
    return s


def parse(s):
    """`C-9-2` → `('C', 9, 2)`. 못 읽으면 `(원문, 0, 0)`."""
    p = str(s or '').rsplit('-', 2)
    if len(p) == 3 and p[1].isdigit() and p[2].isdigit():
        return p[0], int(p[1]), int(p[2])
    p2 = str(s or '').rsplit('-', 1)
    if len(p2) == 2 and p2[1].isdigit():
        return p2[0], int(p2[1]), 0
    return str(s or ''), 0, 0


def classify(kind, tables):
    """바뀐 표들 → `LINK` 또는 `OWN`.

    ★★★ **이것이 체계의 심장이다** — 사람이 안 정하고 기계가 가른다.
    ⚠ 바뀐 표가 하나도 없으면 `OWN`(올릴 것이 없다는 뜻이니 부르는 쪽이 판단).
    """
    ts = set(tables or [])
    if not ts:
        return OWN
    if (kind or '').upper() == 'CORE':
        return LINK if (ts & _core_link_tables()) else OWN
    # 자산 — 본문 표만이면 독자, 껍데기가 섞이면 연동
    try:
        import db_pack_catalog as CAT
        packs = {t for t, (l, _k, _d) in CAT.TABLES.items() if l == 'PACK'}
    except Exception:
        packs = set()
    return OWN if (packs and ts <= packs) else LINK


def current(conn):
    """지금 릴리스(연동 판) → int. **자산들이 가진 가장 높은 연동 판**."""
    try:
        r = conn.execute("SELECT MAX(version) FROM sys_pack_item").fetchone()
        return int(r[0] or 0)
    except Exception:
        return 0


def items(conn):
    """자산 목록 + 판 → `[{kind,key,lang,variant,title,link,own,label}]`."""
    ensure(conn)
    out = []
    for r in conn.execute(
            "SELECT kind, key, lang, variant, COALESCE(title,''),"
            " COALESCE(version,0), COALESCE(own_version,0)"
            "  FROM sys_pack_item"
            " WHERE COALESCE(record_status,'LIVE')='LIVE'"
            " ORDER BY kind, key, lang, variant"):
        d = {'kind': r[0], 'key': r[1], 'lang': r[2], 'variant': r[3],
             'title': r[4], 'link': int(r[5]), 'own': int(r[6])}
        d['label'] = label(d['kind'], d['key'], d['link'], d['own'])
        out.append(d)
    return out


def bump(conn, kind, key='-', lang='-', variant='-', how=OWN):
    """판을 올린다 → `(연동, 독자)`.

    ★★★ **연동이면 릴리스 전체가 오른다** — 그 자산만 올리면 숫자가 어긋나
      「9번이면 맞는다」가 깨진다. ⇒ **코어와 그 자산을 같은 번호로** 맞춘다.
    ⚠ **연동 판은 안 내린다.**
    ⚠ 독자면 그 자산만 뒤 숫자를 올린다(코어·다른 자산과 무관).
    """
    ensure(conn)
    row = conn.execute(
        "SELECT COALESCE(version,0), COALESCE(own_version,0)"
        "  FROM sys_pack_item WHERE kind=? AND key=? AND lang=? AND variant=?",
        (kind, key, lang, variant)).fetchone()
    if not row:
        return (0, 0)
    lv, ov = int(row[0]), int(row[1])
    if how == OWN:
        ov += 1
        conn.execute("UPDATE sys_pack_item SET own_version=? WHERE kind=?"
                     " AND key=? AND lang=? AND variant=?",
                     (ov, kind, key, lang, variant))
        conn.commit()
        return (lv, ov)
    # ── 연동 — 릴리스 전체를 한 칸 올린다 ──────────────────────────
    nxt = current(conn) + 1
    conn.execute("UPDATE sys_pack_item SET version=?, own_version=0"
                 " WHERE kind=? AND key=? AND lang=? AND variant=?",
                 (nxt, kind, key, lang, variant))
    # ⚠ **코어도 함께** — 연결이 코어에 있으므로 코어가 뒤처지면 새 자료가
    #   가리켜지지 않아 **받고도 안 보인다**(§CLAUDE ㉕ 그 실패).
    if (kind or '').upper() != 'CORE':
        conn.execute("UPDATE sys_pack_item SET version=?, own_version=0"
                     " WHERE kind='CORE'", (nxt,))
    conn.commit()
    return (nxt, 0)


def item_release(conn, kind, key='-', lang='-', variant='-'):
    """그 자산의 **연동 판** → int. 없으면 0."""
    try:
        r = conn.execute(
            "SELECT COALESCE(version,0) FROM sys_pack_item"
            " WHERE kind=? AND key=? AND lang=? AND variant=?",
            (kind, key, lang, variant)).fetchone()
        return int(r[0]) if r else 0
    except Exception:
        return 0


def my_core_release(conn):
    """**내가 가진 코어의 연동 판** → int.

    ★ 사용자 쪽에서는 `sys_pack_applied` 가 그 기록이다. 관리자 DB 에서는
      `sys_pack_item` 이 곧 최신이므로 그것을 본다.
    ⚠ **모르면 0** — 0 이면 아래 `check_release` 가 **막지 않는다**(옛 팩을
      받던 사용자를 갑자기 못 받게 만들지 않는다).
    """
    try:
        # ★★★ **주기별 코어 중 가장 낮은 판**(2026-09-05 릴리스 패킹).
        #   ⚠⚠ MAX 로 보면 **매일 것만 받고도 「9판 코어를 가졌다」**가 되어,
        #     구조(연 2회)가 옛 판인데 새 본문을 받아들인다. 그러면 새 자료가
        #     DB 에 있는데 가리킬 껍데기가 없다 — 이 게이트가 막으려던 바로
        #     그 실패다. **보수적으로 최소를 쓴다.**
        #   ⚠ 주기가 하나뿐이면 MIN=MAX 라 지금까지와 똑같다.
        r = conn.execute(
            "SELECT COALESCE(MIN(release),0) FROM sys_pack_applied"
            " WHERE UPPER(kind)='CORE'").fetchone()
        if r and int(r[0]):
            return int(r[0])
    except Exception:
        pass
    return item_release(conn, 'CORE')


def check_release(conn, body):
    """이 팩을 지금 넣어도 되나 → `(되나?, 왜)`.

    ★★★ **이것이 「9번이면 100% 정상」의 실효를 만든다**(2026-09-05).
      ⚠⚠ 막는 것은 **한 방향뿐**이다 — 「본문이 코어보다 새것」.
        그 반대(코어가 새것 · 본문이 옛것)는 **폴백이 정확히 말하므로**
        막을 이유가 없다(막으면 사용자가 아무것도 못 받는다).
    ⚠ **코어팩 자신은 안 막는다** — 코어가 기준이다.
    ⚠ **릴리스가 안 적힌 옛 팩은 통과** — 갑자기 못 받게 만들지 않는다.
    """
    if not isinstance(body, dict):
        return True, ''
    rel = int(body.get('release') or 0)
    if not rel:
        return True, ''                    # 옛 팩 — 막지 않는다
    if (body.get('kind') or '').upper() == 'CORE' or 'kind' not in body:
        return True, ''                    # 코어팩(또는 코어 형식)
    mine_core = my_core_release(conn)
    if mine_core and rel > mine_core:
        return False, ('CORE_TOO_OLD:%d:%d' % (mine_core, rel))
    return True, ''


def why_text(why, t=None):
    """`check_release` 의 이유 → **사람이 읽을 한 줄**.

    ⚠ 코드를 그대로 보이면 사용자는 무엇을 하라는지 모른다(§0-1).
    """
    def _(k, d):
        try:
            return t(k, d) if t else d
        except Exception:
            return d
    if str(why or '').startswith('CORE_TOO_OLD'):
        p = str(why).split(':')
        have, need = (p[1] if len(p) > 1 else '?'), (p[2] if len(p) > 2 else '?')
        return _('PACKREL_CORE_OLD',
                 '이 자료는 %s번 판입니다. 먼저 **앱 기본 자료 %s번**을 받아야 '
                 '합니다(지금 %s번). 기본 자료를 받으면 이어서 받을 수 '
                 '있습니다.') % (need, need, have)
    return str(why or '')


def mine(conn):
    """내가 **실제로 가진** 자산과 판 → `[{…, 'have':bool}]`.

    ★ **실물을 센다** — 「받았다는 기록」이 아니라 본문이 있는지 본다
      (`pack_fallback.state`, 목록은 엄격 잣대).
    """
    try:
        import pack_fallback as FB
    except Exception:
        FB = None
    out = []
    for it in items(conn):
        st = ''
        if FB:
            lg = it['lang']
            try:
                st = FB.state(conn, it['kind'], it['key'],
                              None if lg in (None, '-') else lg, strict=True)
            except Exception:
                st = ''
        it2 = dict(it)
        it2['have'] = (st == getattr(FB, 'OK', 'OK')) if FB else True
        it2['state'] = st
        out.append(it2)
    return out


def stale(conn, target=None):
    """`target` 번(기본 최신)에 견주어 **낡은 것** → `[자산…]`.

    ★★★ **A3-8 은 낡은 것이 아니다** — 그 자산의 연동 판이 8이면 8판 이후
      연동 변화가 없었다는 뜻이라 **9번과도 맞는다**(사용자 지적 그대로).
      ⇒ 낡은 것 = **가지고 있는데 그 자산의 판이 서버 판보다 낮은 것**.
    ⚠ 안 가진 것은 낡은 것이 아니라 **미설치**다(다른 말이다).
    """
    tgt = int(target or current(conn))
    out = []
    for it in mine(conn):
        if not it['have']:
            continue
        # 서버가 그 자산을 더 높은 연동 판으로 올렸나 — `version` 이 곧 그것
        if it['link'] < tgt and it['link'] > 0:
            # ⚠ 그 자산이 그 사이에 **연동 수정이 있었나**를 봐야 한다.
            #   지금 표에는 자산의 최신 판만 있으므로 `link < tgt` 는
            #   「이 자산은 tgt 판에 참여하지 않았다」는 뜻일 뿐이다.
            #   ⇒ **낡은 것이 아니다.** 여기서는 아무것도 안 담는다.
            continue
        out.append(it)
    return [x for x in out if False]      # 위 설명대로 — 아래 stale_real 참조


def stale_real(conn, mine_vers):
    """**사용자 쪽 판정** — 내 판(`mine_vers`)과 서버 판을 견준다.

    `mine_vers` = `{(kind,key,lang,variant): 연동판}` — 내가 받아 둔 것.
    ⇒ 서버 판이 **더 높은 것만** 낡았다. 없는 것은 미설치(따로 센다).
    """
    out = []
    for it in items(conn):
        k = (it['kind'], it['key'], it['lang'], it['variant'])
        mv = mine_vers.get(k)
        if mv is None:
            continue                       # 안 가진 것 — 미설치
        if int(mv) < it['link']:
            out.append(it)
    return out


def effect(conn, kind, key='-', lang='-', variant='-', t=None):
    """이 자산을 **받으면 / 안 받으면** 무슨 일이 나나 → `(받으면, 안 받으면)`.

    ★★★ 왜 (2026-09-05 사용자 지시 「각 팩을 다운로드 받으면 **또는 안 받으면
      어떤 현상/문제가 발생하는지**를 사용자가 이해할 수 있도록 … 사용자가
      **시작/종료 id(암호)를 해석할 수 없으니** … **간단하게 설명문을 표시**」).
      ⇒ **id 를 안 보인다.** 두 줄로 말한다.
    ⚠ **갈래마다 실제로 무엇이 달라지나가 다르다** — 한 문장으로 뭉뚱그리면
      「그래서 뭐가 되나」를 못 답한다.
    ⚠ **안 받아도 되는 것을 겁주지 않는다** — 코어는 이미 연결과 제목을 담고
      있어 **본문만 없을 뿐**이다. 그 사실을 그대로 적는다.
    """
    def _(k, d):
        try:
            return t(k, d) if t else d
        except Exception:
            return d
    k = (kind or '').upper()
    if k == 'CORE':
        return (_('PACKEF_CORE_Y',
                  '모든 자료의 제목·연결·좌표가 최신이 됩니다. '
                  '새로 만들어진 연결이 화면에 나타납니다.'),
                _('PACKEF_CORE_N',
                  '⚠ 다른 자료를 받아도 **새 연결이 안 보일 수 있습니다**. '
                  '가장 먼저 받는 것이 좋습니다(작습니다).'))
    M = {
        'BIBLE': ('그 역본으로 성경 본문을 읽을 수 있습니다.',
                  '다른 역본으로는 그대로 읽을 수 있습니다.'),
        'BOOK': ('그 책의 본문을 읽을 수 있습니다.',
                 '제목과 소개는 계속 보이고, 본문 자리에 「아직 받지 '
                 '않았습니다」가 나옵니다.'),
        'SERMON': ('그 설교집의 본문을 읽을 수 있습니다.',
                   '제목과 연결은 그대로 보입니다. 본문만 안 나옵니다.'),
        'COMM': ('구절을 볼 때 그 주석이 함께 나옵니다.',
                 '다른 주석은 그대로 나옵니다.'),
        'DICT': ('용어를 누르면 그 사전 풀이가 나옵니다.',
                 '다른 사전은 그대로 나옵니다.'),
        'DESC': ('그 성경책을 읽을 때 설명·묵상질문·기도가 함께 나옵니다.',
                 '성경 본문과 다른 연결은 그대로 보입니다.'),
        'LEX': ('원어 낱말을 눌렀을 때 사전 뜻이 나옵니다.',
                '낱말 연결과 목록은 그대로 보입니다.'),
    }
    y, n = M.get(k, ('그 자료를 볼 수 있습니다.',
                     '제목과 연결은 그대로 보입니다.'))
    return (_('PACKEF_%s_Y' % k, y), _('PACKEF_%s_N' % k, n))


def admin_warn(conn, picked):
    """관리자 — **이것만 올리면 무슨 문제가 나나** → `[경고…]`.

    ★★★ 왜 (사용자 지시 「관리자도 팩을 올릴 때 **이것만 올리면 어떤 문제가
      발생하는지, 그 문제를 해결하려면 어떤 팩을 업로드 해야 하는지**를 알 수
      있도록 하는 화면이 필요하다」).
    `picked` = 올리려는 `[(kind,key,lang,variant)…]`.
    """
    out = []
    cur = current(conn)
    got = set(picked or [])
    kinds = {(p[0] or '').upper() for p in got}
    # ⚠⚠ **연동 판이 오른 자산을 올리는데 코어를 안 올리면** 새 자료가
    #   사용자 화면에 안 보인다(연결이 코어에 있다).
    core_needed = [p for p in got
                   if (p[0] or '').upper() != 'CORE'
                   and item_release(conn, *p) >= cur]
    if core_needed and 'CORE' not in kinds:
        out.append({'code': 'NEED_CORE',
                    'msg': '이 자산들은 %d번 판입니다. **앱 기본 자료(코어팩)를 '
                           '함께 올려야** 새 연결이 사용자 화면에 나타납니다.'
                           % cur,
                    'fix': '코어팩을 함께 올린다'})
    # ⚠ 코어만 올리는 경우 — 본문이 없는 자산은 폴백이 말한다(문제 아님)
    if kinds == {'CORE'}:
        out.append({'code': 'CORE_ONLY',
                    'msg': '코어만 올립니다. 제목·연결은 최신이 되고 **본문은 '
                           '사용자가 선택할 때 받습니다**(정상).',
                    'fix': ''})
    return out


def summary(conn):
    """관리자 한 줄 → `{'release','n','by_ver','behind'}`."""
    its = items(conn)
    cur = current(conn)
    from collections import Counter
    by = Counter(x['link'] for x in its)
    return {'release': cur, 'n': len(its), 'by_ver': dict(by),
            'behind': [x for x in its if 0 < x['link'] < cur]}


# ── 자가검증 ─────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', name, extra))

    # ── 표기 ────────────────────────────────────────────────────────
    t('★ 코어는 C 로 쓴다', label('CORE', '-', 9, 2) == 'C-9-2',
      label('CORE', '-', 9, 2))
    t('★★ **독자 판이 0 이면 안 붙인다**(사용자는 안 봐도 된다)',
      label('BIBLE', 'KRV', 9, 0) == 'KRV-9', label('BIBLE', 'KRV', 9, 0))
    t('  되읽는다', parse('C-9-2') == ('C', 9, 2), str(parse('C-9-2')))
    t('  독자 없는 것도 되읽는다', parse('KRV-9') == ('KRV', 9, 0))
    t('  못 읽으면 0 으로', parse('이상한값')[1] == 0)
    t('★ 쪼갠 자산도 기호가 짧다',
      label('SERMON', 'SPURGEON_SERMONS#POET', 9) == 'SPURGEON_SERMONS-9',
      label('SERMON', 'SPURGEON_SERMONS#POET', 9))

    # ── ★★★ 판정 ───────────────────────────────────────────────────
    t('★★★ **자산 — 본문 표만이면 독자**',
      classify('BOOK', ['sys_book_unit_text']) == OWN)
    t('★★★ **자산 — 껍데기가 섞이면 연동**',
      classify('BOOK', ['sys_book_unit_text', 'sys_book_unit']) == LINK)
    t('★★★ **코어 — 연결 표면 연동**',
      classify('CORE', ['sys_link_asset']) == LINK)
    t('★★★ **코어 — 그 밖만이면 독자**',
      classify('CORE', ['ui_strings', 'sys_entity_master']) == OWN)
    t('★★ **코어 껍데기도 연동**(새 편이 생기면 가리킬 것이 는다)',
      classify('CORE', ['sys_book_unit']) == LINK)
    t('  바뀐 것이 없으면 독자', classify('CORE', []) == OWN)
    lt = _core_link_tables()
    t('★ 연동 표를 분류표에서 유도한다', 'sys_link_asset' in lt,
      '%d개' % len(lt))

    # ── DB ──────────────────────────────────────────────────────────
    c = appdb.connect(DB)
    try:
        t('★ own_version 칸이 마련된다', ensure(c))
        cols = [r[1] for r in c.execute("PRAGMA table_info(sys_pack_item)")]
        t('  칸이 실제로 있다', 'own_version' in cols)
        its = items(c)
        t('★ 자산 목록에 판이 붙는다', len(its) > 100, '%d개' % len(its))
        t('  이름표가 만들어진다', all(x['label'] for x in its),
          its[0]['label'] if its else '')
        cur = current(c)
        t('★ 지금 릴리스를 안다', cur > 0, '%d번' % cur)
        s = summary(c)
        t('  요약이 나온다', s['n'] == len(its),
          '릴리스 %s · 자산 %s · 뒤처진 것 %s'
          % (s['release'], s['n'], len(s['behind'])))

        # ★★★ 올리기 왕복 — 실 DB 를 되돌린다
        one = [x for x in its if x['kind'] == 'DICT'][0]
        k4 = (one['kind'], one['key'], one['lang'], one['variant'])
        before = (one['link'], one['own'])
        core0 = [x for x in its if x['kind'] == 'CORE'][0]['link']
        try:
            lv, ov = bump(c, *k4, how=OWN)
            t('★★ **독자는 뒤 숫자만 오른다**',
              lv == before[0] and ov == before[1] + 1, '%d-%d' % (lv, ov))
            c2 = [x for x in items(c) if x['kind'] == 'CORE'][0]['link']
            t('★★★ **독자는 코어를 안 건드린다**', c2 == core0,
              '%d → %d' % (core0, c2))
            lv2, ov2 = bump(c, *k4, how=LINK)
            t('★★★ **연동이면 릴리스가 오른다**', lv2 == cur + 1,
              '%d → %d' % (cur, lv2))
            t('★★ **독자 판은 0 으로 되돌아간다**', ov2 == 0)
            c3 = [x for x in items(c) if x['kind'] == 'CORE'][0]['link']
            t('★★★ **코어도 같은 번호가 된다**(연결이 코어에 있다)',
              c3 == lv2, '코어 %d = 자산 %d' % (c3, lv2))
        finally:
            c.execute("UPDATE sys_pack_item SET version=?, own_version=?"
                      " WHERE kind=? AND key=? AND lang=? AND variant=?",
                      (before[0], before[1]) + k4)
            c.execute("UPDATE sys_pack_item SET version=?, own_version=0"
                      " WHERE kind='CORE'", (core0,))
            c.commit()
        after = [x for x in items(c) if
                 (x['kind'], x['key'], x['lang'], x['variant']) == k4][0]
        t('★ 시험 전으로 되돌렸다',
          (after['link'], after['own']) == before,
          '%d-%d' % (after['link'], after['own']))
        t('  코어도 되돌렸다',
          [x for x in items(c) if x['kind'] == 'CORE'][0]['link'] == core0)

        # 사용자 쪽 판정
        mv = {(x['kind'], x['key'], x['lang'], x['variant']): x['link']
              for x in items(c)}
        t('★★★ **다 맞으면 낡은 것이 0**', not stale_real(c, mv),
          '%d개' % len(stale_real(c, mv)))
        one2 = list(mv)[0]
        mv[one2] = 0
        t('★★ **내 판이 낮으면 잡는다**', len(stale_real(c, mv)) == 1,
          '%d개' % len(stale_real(c, mv)))
        del mv[one2]
        t('★★★ **안 가진 것은 낡은 것이 아니다**(미설치는 다른 말)',
          not stale_real(c, mv))
    finally:
        c.close()
    print('db_pack_release selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--status', action='store_true')
    ap.add_argument('--classify', nargs='+')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect(DB)
    try:
        if a.status:
            s = summary(c)
            print('릴리스 **%d번** · 자산 %d개' % (s['release'], s['n']))
            print('판 분포: %s' % s['by_ver'])
            if s['behind']:
                print('뒤처진 자산 %d개(그 판 이후 연동 변화가 없으면 정상):'
                      % len(s['behind']))
                for x in s['behind'][:8]:
                    print('  %-22s %s' % (x['label'], x['title'][:34]))
        if a.classify:
            kind, tables = a.classify[0], a.classify[1:]
            print('%s + %s → **%s**' % (kind, tables, classify(kind, tables)))
    finally:
        c.close()


if __name__ == '__main__':
    main()
