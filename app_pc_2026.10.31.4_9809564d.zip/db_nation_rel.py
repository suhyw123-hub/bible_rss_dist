# -*- coding: utf-8 -*-
"""민족·그룹 ↔ 인물·우상 관계 적재 — 2026-09-02 (0.txt 1번 관계 확대).

그룹-인물(신약 그룹 — 바리새·산헤드린·서기관·레위인)도 같은 집단 갈래를
쓴다(지파 12개 제외 — 조상 1:1). 아래 원 머리말:

우상-인물 서브트리(94건)와 같은 문법을 민족으로 넓힌다. 저장 = 통합 표
`sys_link_asset` `ENTI_ENTI`(clicked=민족 · target=인물|우상), 어휘 =
`entity_relation.NATION`(FOUNDER·KING·MEMBER·PROPHET_TO·COURT·NATIONAL_GOD).

★ **대표 몇 명만 — 전수가 아니다** (사용자: 「다양하게 연결되는 것은 유익한데,
  활용도 낮으면서 너무 복잡한 것도 문제다」). 행마다 성경 근거를 주석으로
  적었고, **엔티티가 없는 인물(발람·고레스·빌라도·하만…)은 잇지 않는다**
  (지어내지 않는다 — §0-1b).
⚠ 장소-인물은 **일부러 없다** — 발자취(sys_place_route_stop)가 이미 갖고
  있어 손으로 또 넣으면 두 벌이 된다(사용자 승인 의견).
⚠ 들릴라는 안 이었다 — 삿16:4 「소렉 골짜기」일 뿐 블레셋 여인이라는 명시가
  성경에 없다(블레셋 방백들이 접근했을 뿐). 추정으로 잇지 않는다.

사용:
    python db_nation_rel.py --selftest   (의무)
    python db_nation_rel.py --check
    python db_nation_rel.py --apply     (멱등)
    python db_nation_rel.py --status
"""
import argparse
import io
import sys

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

import appdb  # noqa: E402
import entity_relation  # noqa: E402

DB = 'bible_master.db'

# (민족 코드, 관계, 대상 코드) — 근거는 주석.
ROWS = (
    # ── 조상 (FOUNDER) ──
    ('N_MOABITE', 'FOUNDER', 'P_LOT'),          # 창19:37 — 큰딸의 아들 모압
    ('N_AMMONITE', 'FOUNDER', 'P_LOT'),         # 창19:38 — 벤암미
    ('N_EDOMITE', 'FOUNDER', 'P_ESAU'),         # 창36:1 — 에서 곧 에돔
    ('N_MIDIANITE', 'FOUNDER', 'P_MIDIAN'),     # 창25:2 — 아브라함과 그두라의 아들
    # ── 왕 (KING) ──
    ('N_EGYPTIAN', 'KING', 'P_PHARAOH'),        # 출애굽의 바로
    ('N_ASSYRIAN', 'KING', 'P_SENNACHERIB'),    # 왕하18:13
    ('N_BABYLONIAN', 'KING', 'P_NEBUCHADNEZZAR'),  # 왕하24:1
    ('N_PHILISTINE', 'KING', 'P_ABIMELECH'),    # 창26:1 「블레셋 왕 아비멜렉」
    # ── 그 민족 사람 (MEMBER) ──
    ('N_MOABITE', 'MEMBER', 'P_RUTH'),          # 룻1:4 모압 여인
    ('N_EGYPTIAN', 'MEMBER', 'P_HAGAR'),        # 창16:1 애굽 여인
    ('N_ARAMEAN', 'MEMBER', 'P_NAAMAN'),        # 왕하5:1 아람 왕의 군대장관
    ('N_ARAMEAN', 'MEMBER', 'P_LABAN'),         # 창25:20 아람 사람 라반
    ('N_MIDIANITE', 'MEMBER', 'P_JETHRO'),      # 출3:1 미디안 제사장
    ('N_MIDIANITE', 'MEMBER', 'P_ZIPPORAH'),    # 출2:21
    ('N_PHILISTINE', 'MEMBER', 'P_GOLIATH'),    # 삼상17:4 가드 사람
    ('N_CANAANITE', 'MEMBER', 'P_RAHAB'),       # 수2:1 여리고
    ('N_PHOENICIAN', 'MEMBER', 'P_JEZEBEL'),    # 왕상16:31 시돈 왕 엣바알의 딸
    ('N_HITTITE', 'MEMBER', 'P_URIAH'),         # 삼하11:3 헷 사람 우리아
    # ── 보냄 받은 선지자 (PROPHET_TO) ──
    ('N_ASSYRIAN', 'PROPHET_TO', 'P_JONAH'),    # 욘1:2 니느웨로
    # ── 궁정에 선 사람 (COURT) ──
    ('N_EGYPTIAN', 'COURT', 'P_JOSEPH'),        # 창41:41 총리
    ('N_EGYPTIAN', 'COURT', 'P_MOSES'),         # 출2:10 · 행7:22 바로의 궁정
    ('N_BABYLONIAN', 'COURT', 'P_DANIEL'),      # 단2:48
    ('N_PERSIAN', 'COURT', 'P_ESTHER'),         # 에2:17 왕후
    # ── 그룹-인물 (2026-09-02 확장 — 신약 그룹만 · 지파 12개 제외:
    #     조상과 1:1 이라 관계 행이 정보를 더하지 않는다) ──
    ('G_PHARISEE', 'MEMBER', 'P_NICODEMUS'),    # 요3:1 바리새인 니고데모
    ('G_PHARISEE', 'MEMBER', 'P_PAUL'),         # 빌3:5 「바리새인이요」· 행23:6
    ('G_SANHEDRIN', 'MEMBER', 'P_NICODEMUS'),   # 요3:1 유대인의 관원 · 요7:50
    ('G_SCRIBE', 'MEMBER', 'P_EZRA'),           # 스7:6 — 설명문도 「모범 서기관」
    ('GRP_LEVITE', 'MEMBER', 'P_BARNABAS'),     # 행4:36 「레위족 사람」
    # ⚠ 아론·모세는 **안 이었다** — GRP_LEVITE 설명문이 「제사장 보조 봉사자
    #   직책」으로 못 박는다. 아론은 제사장(보좌를 받는 쪽)이고 모세는
    #   혈통만 레위다 — 설명문과 어긋난 연결은 만들지 않는다.
    # ⚠ 가야바·안나스(사두개)·시몬(열심당)·가말리엘은 엔티티가 없다.
    #   에세네파·동방박사·사마리아인은 성경에 이름 있는 실재 인물이 없다(정상).
    # ── 민족의 신 (NATIONAL_GOD) ──
    ('N_PHILISTINE', 'NATIONAL_GOD', 'IDL_DAGON'),        # 삿16:23
    ('N_PHILISTINE', 'NATIONAL_GOD', 'IDL_BAALZEBUB'),    # 왕하1:2 에그론
    ('N_AMMONITE', 'NATIONAL_GOD', 'IDL_MOLECH'),         # 왕상11:7
    ('N_AMMONITE', 'NATIONAL_GOD', 'IDL_MILCOM'),         # 왕상11:5
    ('N_MOABITE', 'NATIONAL_GOD', 'IDL_CHEMOSH'),         # 민21:29
    ('N_MOABITE', 'NATIONAL_GOD', 'IDL_BAALPEOR'),        # 민25:3 브올의 바알
    ('N_ARAMEAN', 'NATIONAL_GOD', 'IDL_RIMMON'),          # 왕하5:18 다메섹
    ('N_ASSYRIAN', 'NATIONAL_GOD', 'IDL_NISROCH'),        # 왕하19:37
    ('N_BABYLONIAN', 'NATIONAL_GOD', 'IDL_BEL'),          # 사46:1
    ('N_BABYLONIAN', 'NATIONAL_GOD', 'IDL_NEBO'),         # 사46:1
    ('N_BABYLONIAN', 'NATIONAL_GOD', 'IDL_GOLDEN_STATUE'),  # 단3:1
    ('N_BABYLONIAN', 'NATIONAL_GOD', 'IDL_TAMMUZ'),       # 겔8:14
    ('N_CANAANITE', 'NATIONAL_GOD', 'IDL_BAAL'),          # 삿2:11
    ('N_CANAANITE', 'NATIONAL_GOD', 'IDL_ASHERAH'),       # 삿3:7
    ('N_CANAANITE', 'NATIONAL_GOD', 'IDL_ASHTORETH'),     # 삿2:13
    ('N_PHOENICIAN', 'NATIONAL_GOD', 'IDL_BAAL'),         # 왕상16:31 시돈의 바알
    ('N_PHOENICIAN', 'NATIONAL_GOD', 'IDL_ASHTORETH'),    # 왕상11:5 시돈의 여신
    ('N_GREEK', 'NATIONAL_GOD', 'IDL_ZEUS_HERMES'),       # 행14:12 루스드라
    ('N_GREEK', 'NATIONAL_GOD', 'IDL_ARTEMIS'),           # 행19:28 에베소
)


def _eid(conn, code):
    r = conn.execute(
        "SELECT entity_id, entity_type FROM sys_entity_master"
        " WHERE entity_code=? AND COALESCE(record_status,'LIVE')='LIVE'",
        (code,)).fetchone()
    return r if r else (None, None)


def resolve(conn):
    """→ (해석된 행, 오류 목록). 오류가 있으면 적재하지 않는다."""
    out, err = [], []
    seen = set()
    for ncode, rel, tcode in ROWS:
        if rel not in entity_relation.NATION:
            err.append('%s: 어휘에 없는 관계 %s' % (ncode, rel))
            continue
        if (ncode, rel, tcode) in seen:
            err.append('중복 행: %s %s %s' % (ncode, rel, tcode))
            continue
        seen.add((ncode, rel, tcode))
        nid, ntype = _eid(conn, ncode)
        tid, ttype = _eid(conn, tcode)
        if nid is None:
            err.append('민족 엔티티 없음: ' + ncode)
            continue
        if tid is None:
            err.append('대상 엔티티 없음: ' + tcode)
            continue
        if ntype not in ('NATION', 'GROUP'):
            err.append('%s 는 NATION/GROUP 이 아니다(%s)' % (ncode, ntype))
            continue
        if ntype == 'GROUP' and rel == 'NATIONAL_GOD':
            err.append('%s: 그룹에는 민족의 신을 걸지 않는다' % ncode)
            continue
        want = 'IDOL' if rel == 'NATIONAL_GOD' else 'PERSON'
        if ttype != want:
            err.append('%s: %s 는 %s 여야 한다(%s)' % (rel, tcode, want, ttype))
            continue
        out.append((nid, rel, tid, ncode, tcode))
    return out, err


def apply(conn, verbose=True):
    rows, err = resolve(conn)
    if err:
        for e in err:
            print('  ⚠', e)
        print('오류 %d — 적재하지 않는다' % len(err))
        return 0
    n = 0
    for nid, rel, tid, ncode, tcode in rows:
        dup = conn.execute(
            "SELECT 1 FROM sys_link_asset WHERE link_type='ENTI_ENTI'"
            " AND clicked_id=? AND target_id=? AND rel_code=?"
            " AND COALESCE(record_status,'LIVE')='LIVE'",
            (nid, tid, rel)).fetchone()
        if dup:
            continue
        conn.execute(
            "INSERT INTO sys_link_asset (link_type, clicked_id, target_id,"
            " rel_code, record_status) VALUES ('ENTI_ENTI', ?, ?, ?, 'LIVE')",
            (nid, tid, rel))
        n += 1
        if verbose:
            print('  + %s %s %s' % (ncode, rel, tcode))
    conn.commit()
    print('새 관계 %d건 (전체 정의 %d건)' % (n, len(rows)))
    return n


def check(conn):
    rows, err = resolve(conn)
    for e in err:
        print('  ⚠', e)
    have = 0
    for nid, rel, tid, ncode, tcode in rows:
        dup = conn.execute(
            "SELECT 1 FROM sys_link_asset WHERE link_type='ENTI_ENTI'"
            " AND clicked_id=? AND target_id=? AND rel_code=?"
            " AND COALESCE(record_status,'LIVE')='LIVE'",
            (nid, tid, rel)).fetchone()
        have += bool(dup)
    print('정의 %d · 이미 있음 %d · 새로 넣을 것 %d · 오류 %d'
          % (len(rows), have, len(rows) - have, len(err)))


def status(conn):
    w, a = entity_relation.nation_where('l')
    rows = conn.execute(
        "SELECT l.rel_code, COUNT(*) FROM sys_link_asset l WHERE %s"
        " AND COALESCE(l.record_status,'LIVE')='LIVE' GROUP BY 1" % w,
        a).fetchall()
    print('민족 관계:', dict(rows) or '없음')


def selftest():
    conn = appdb.connect(DB)
    ok = fail = 0

    def t(name, cond, e=''):
        nonlocal ok, fail
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', name, e))
        ok += cond
        fail += (not cond)

    rows, err = resolve(conn)
    t('정의 행 전부 해석된다(엔티티 실재·유형 맞음)', not err, err[:3])
    t('행 수가 뜻대로다', len(rows) == len(ROWS), (len(rows), len(ROWS)))
    # 탐지력 — 없는 엔티티·틀린 유형을 실제로 잡는가
    # ⚠ `import db_nation_rel` 로 바꾸면 `__main__` 실행 때 **딴 모듈 인스턴스**
    #   가 로드돼 resolve 가 안 보는 ROWS 를 바꾸게 된다(실측으로 잡음) —
    #   globals() 로 제자리를 바꾼다.
    g = globals()
    old = g['ROWS']
    try:
        for bad, name in (
                ((('N_MOABITE', 'MEMBER', 'ZZ_NOPE'),),
                 '★ 탐지력 — 없는 엔티티를 잡는다'),
                ((('N_MOABITE', 'NATIONAL_GOD', 'P_RUTH'),),
                 '★ 탐지력 — 민족의 신 자리에 인물이 오면 잡는다'),
                ((('P_RUTH', 'MEMBER', 'P_LOT'),),
                 '★ 탐지력 — 민족 아닌 것이 앞자리에 오면 잡는다')):
            g['ROWS'] = bad
            _r, _e = resolve(conn)
            t(name, bool(_e), _e)
    finally:
        g['ROWS'] = old
    # 멱등 재료 검사 — 있는 것 + 넣을 것 = 정의 수 (⚠ selftest 는 **적재하지
    #   않는다** — 검사가 쓰기를 하면 「selftest 만 돌렸는데 DB 가 바뀐다」)
    have = 0
    for nid, rel, tid, _nc, _tc in rows:
        if conn.execute(
                "SELECT 1 FROM sys_link_asset WHERE link_type='ENTI_ENTI'"
                " AND clicked_id=? AND target_id=? AND rel_code=?"
                " AND COALESCE(record_status,'LIVE')='LIVE'",
                (nid, tid, rel)).fetchone():
            have += 1
    t('있는 것+넣을 것=정의 수(멱등 재료)', 0 <= have <= len(rows),
      (have, len(rows)))
    conn.close()
    print('db_nation_rel selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--status', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(DB)
    if a.apply:
        apply(conn)
        status(conn)
    elif a.check:
        check(conn)
    else:
        status(conn)
    conn.close()


if __name__ == '__main__':
    main()
