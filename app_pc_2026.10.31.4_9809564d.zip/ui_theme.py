"""
ui_theme.py — 앱 전체 **색** 중앙 관리 (2026-08-13 재작성).

폰트는 `theme_font.py`, 색은 여기. **저장소도 각각 하나씩만 둔다**
(폰트에서 저장소가 둘로 갈려 「재실행하면 안 걸린다」가 났다 — font.md §19).

    import ui_theme
    ui_theme.use(db_path, 'BLACK')      # 선택하고 저장
    ui_theme.paint(root)                # **지금 떠 있는 화면까지** 즉시 바꾼다

★ **핵심 — 코드에 박힌 색을 안 고치고 바꾼다.**
  사용자 화면에 색이 박힌 곳이 **1,696곳 · 191가지**다(2026-08-13 실측). 그런데
  그 191가지가 곧 **지금의 밝은 테마**다. 그래서 색을 하나하나 상수로 갈아치우는
  대신 **「이 색은 무슨 역할인가」 표**(`ROLE_OF`)를 두고, 테마를 바꿀 때 화면을
  훑으며 **역할이 같은 다른 색으로 바꿔 칠한다.**
    · 원본 소스를 안 건드리므로 되돌릴 것이 없다
    · 표에 없는 색은 **그대로 둔다** — 모르는 색을 함부로 바꾸지 않는다
    · 위젯마다 처음 색을 기억해 두므로 테마를 오가도 원본이 살아 있다

⚠ **윈도우 기본 테마는 ttk 위젯 색을 조용히 무시한다.** 탭에서 이미 겪었다
  (`apply_notebook_tabs` 주석). 확인은 **화면 픽셀**로 한다 — `style.lookup` 은
  「설정은 맞는데 안 보인다」를 못 잡는다.
"""

import json

import appdb

CONFIG_KEY = 'UI_THEME'
DEFAULT = 'GREY'

# ── 역할 20가지 ───────────────────────────────────────────────────────────────
# ⚠ **바탕과 글자를 같은 역할로 묶지 말 것.** 초록 버튼은 바탕 `#A9DFBF` + 글자
#   `#1E8449` 인데 둘 다 'success' 로 묶으면 **같은 색이 되어 글자가 사라진다.**
#   그래서 `success` / `success_bg` 처럼 짝으로 나눈다.
ROLES = (
    'bg', 'panel', 'panel_alt', 'accent_bg', 'dark_bg', 'dark_panel',
    'fg', 'fg_dim', 'fg_label', 'fg_title', 'fg_on_dark',
    'border', 'accent', 'success', 'success_bg', 'danger', 'danger_bg',
    'warning', 'warning_bg', 'select_bg',
    # 2026-09-16 · 1.txt 13번 — [Focus] 분홍 파스텔 · [Restore] 초록 파스텔 바탕.
    #   색을 화면에 적지 않는다(§0) — 역할로 두고 조리법이 벌마다 만든다.
    'focus_bg', 'restore_bg',
    # 2026-09-25 · 사용자 「수정가능한 텍스트 상자는 바탕색을 밝은 색으로
    #   고정하라 — 회색도 있고 흰색도 있어서 수정해도 된다는 것인지 애매하다」.
    #   ★★★ **원칙: 고칠 수 있는 칸은 바탕보다 밝고, 읽기만 하는 칸은 어둡다.**
    #     어느 테마에서나 같은 방향이라 검정 테마에서도 뜻이 뒤집히지 않는다.
    #   ⚠ 순백으로 두지 않는다 — 검정 테마에서 눈부시고, 역인덱스에서 이미
    #     흰색을 쓰는 `fg_on_dark` 와 부딪친다.
    'edit_bg', 'view_bg',
)

# ── 테마 — 계열마다 여러 벌 (2026-08-13 사용자 지시) ─────────────────────────
# 「회색 계열, 푸른색 계열, 검은색 계열을 각각 3~5개씩 표시하고 클릭하면 바뀌게」
#
# ★ **손으로 20개 색 × 12벌 = 240개를 적지 않는다.** 그러면 반드시 어긋난다
#   (초록 버튼의 바탕과 글자가 같은 색이 되는 부류의 사고가 240칸에서 난다).
#   ⇒ **바탕 밝기 하나와 색조 하나**를 주면 나머지 19개를 조리법이 만든다.
#     대비 규칙은 selftest 가 **모든 벌에** 건다 — 늘려도 안전하다.
#
# ⚠ **Black 계열에 순흑 바탕·순백 글자를 쓰지 않는다.** 대비가 최대일 때 글자가
#   번져 보여 밤에 가장 눈이 아프다.
# ⚠ **회색·파랑이 너무 연하면 흰색과 구분이 안 된다** (2026-08-13 사용자 지적:
#   「지금 회색 푸른색이 너무 연한 색이다」). 그래서 계열의 기본값은 흰색보다
#   **눈에 띄게 내려 잡았다** — 회색 기본 `L=0.90`, 파랑 기본 `L=0.88`.

import colorsys


def _hex(h, s, l):                                   # noqa: E741
    r, g, b = colorsys.hls_to_rgb(h / 360.0, max(0.0, min(1.0, l)),
                                  max(0.0, min(1.0, s)))
    return '#%02X%02X%02X' % (round(r * 255), round(g * 255), round(b * 255))


def _brew(hue, sat, bg_l, dark):
    """바탕 밝기와 색조에서 20가지 역할색을 만든다.

    밝은 벌은 글자가 **검정**, 어두운 벌은 **밝은 회색**(사용자 지정).
    """
    if not dark:
        # ⚠ **채도를 깎으면 계열이 사라진다** — 처음에 `sat*.45` 로 잡았더니
        #   파랑 기본이 `#DBE0E6`(거의 회색)이 나왔다. 바탕은 색조를 거의 그대로 쓴다.
        d = dict(
            bg=_hex(hue, sat * .90, bg_l),
            panel=_hex(hue, sat * 1.05, bg_l - .045),
            panel_alt=_hex(hue, sat * 1.15, bg_l - .095),
            accent_bg=_hex(hue, sat * 1.30, bg_l - .065),
            dark_bg=_hex(hue, min(.55, sat * 1.6 + .18), .26),
            dark_panel=_hex(hue, min(.48, sat * 1.4 + .15), .33),
            fg='#000000',
            fg_dim=_hex(hue, sat * .55, .46),
            fg_label=_hex(hue, sat * .70, .32),
            fg_title=_hex(hue, min(.65, sat * 1.7 + .22), .27),
            fg_on_dark='#FFFFFF',
            border=_hex(hue, sat * .95, bg_l - .17),
            accent=_hex(hue, min(.62, sat * 1.5 + .25), .43),
            success='#1E8449', success_bg=_hex(145, .42, bg_l - .07),
            danger='#B03A2E', danger_bg=_hex(6, .55, bg_l - .05),
            warning='#9C6708', warning_bg=_hex(40, .62, bg_l - .04),
            select_bg=_hex(hue, min(.55, sat * 1.3 + .18), bg_l - .12),
            focus_bg=_hex(345, .55, min(.93, bg_l - .05)),     # 분홍 파스텔
            restore_bg=_hex(140, .40, min(.92, bg_l - .06)),   # 초록 파스텔
            # 고칠 수 있는 칸 = 바탕보다 **밝게**(거의 흰색, 색조는 아주 옅게)
            edit_bg=_hex(hue, sat * .22, min(.995, bg_l + .055)),
            # 읽기만 하는 칸 = 바탕보다 **어둡게**
            view_bg=_hex(hue, sat * 1.10, bg_l - .075),
        )
    else:
        d = dict(
            bg=_hex(hue, sat * .85, bg_l),
            panel=_hex(hue, sat * .90, bg_l + .035),
            panel_alt=_hex(hue, sat * .95, bg_l + .075),
            accent_bg=_hex(hue, min(.35, sat + .12), bg_l + .09),
            dark_bg=_hex(hue, sat * .55, max(.03, bg_l - .045)),
            dark_panel=_hex(hue, sat * .55, max(.05, bg_l - .02)),
            fg=_hex(hue, sat * .10, .82),           # ★ 밝은 회색 — 순백 아님
            fg_dim=_hex(hue, sat * .14, .55),
            fg_label=_hex(hue, sat * .12, .70),
            fg_title=_hex(hue if sat > .05 else 205, .45, .70),
            fg_on_dark=_hex(hue, sat * .10, .82),
            border=_hex(hue, sat * .30, bg_l + .13),
            accent=_hex(hue if sat > .05 else 205, .55, .62),
            success='#7DCB9A', success_bg=_hex(145, .28, bg_l + .06),
            danger='#E48A80', danger_bg=_hex(6, .32, bg_l + .06),
            warning='#E0B65C', warning_bg=_hex(40, .32, bg_l + .05),
            select_bg=_hex(hue if sat > .05 else 205, .32, bg_l + .13),
            focus_bg=_hex(345, .30, bg_l + .10),
            restore_bg=_hex(140, .26, bg_l + .10),
            # ⚠ 검정 테마에서도 **편집 칸이 더 밝다** — 방향이 뒤집히면
            #   사용자가 배운 규칙이 화면마다 달라진다.
            edit_bg=_hex(hue, sat * .45, min(.42, bg_l + .13)),
            view_bg=_hex(hue, sat * .70, max(.03, bg_l - .030)),
        )
    return d


# (키, 계열, 보일 이름, 색조, 채도, 바탕 밝기, 어두운가)
# ⚠ 계열마다 **기본**을 하나 둔다 — 옛 저장값(WHITE/GREY/BLUE/BLACK)이 그대로 산다.
_SPEC = [
    ('WHITE',   'GREY',  '흰색',       210, .04, .995, False),
    ('GREY_L',  'GREY',  '밝은 회색',   210, .07, .955, False),
    ('GREY',    'GREY',  '회색',       210, .10, .900, False),
    ('GREY_D',  'GREY',  '진한 회색',   210, .12, .840, False),

    # ⚠ 파랑과 청회색이 **밝기가 같아** 눈으로 안 갈렸다(0.005 차). 단계를 벌렸다.
    # ★ 2026-10-15 docs/1.txt 77 — 가장 진한 것(BLUE_D #ABC0DF)이 너무 강해 걷고 한 칸씩 밀어
    #   맨 왼쪽에 더 연한 것을 더했다. 옛 저장값 BLUE_D 는 `load` 가 BLUE_S 로 옮긴다(`RETIRED`).
    ('BLUE_LL', 'BLUE',  '아주 연한 하늘', 205, .80, .978, False),
    ('BLUE_L',  'BLUE',  '연한 하늘',   205, .30, .940, False),
    ('BLUE',    'BLUE',  '파랑',       210, .42, .880, False),
    ('BLUE_S',  'BLUE',  '청회색',     200, .24, .828, False),

    # ★ 갈색 계열 — 원래 회색 계열에 넣었던 「따뜻한 회색」이 갈색으로 보인다는
    #   지적(2026-08-13)에 따라 **따로 계열로 세웠다.** 그 색이 이 계열의 밝은 끝이다.
    ('BROWN_LL', 'BROWN', '아주 밝은 갈색', 30, .55, .968, False),
    ('BROWN_L', 'BROWN', '밝은 갈색',   32,  .20, .930, False),
    ('BROWN',   'BROWN', '갈색',       30,  .22, .880, False),
    ('BROWN_D', 'BROWN', '진한 갈색',   26,  .27, .825, False),

    # ★ 검은색 계열 재구성 (2026-08-13 사용자 지적 「2~4번째가 비슷하다」).
    #   먹빛·남색 검정은 검정과 밝기 차가 0.03 뿐이라 **눈으로 안 갈렸다.** 빼고,
    #   기존 1·2번(진한 회색·검정)은 그대로 두고 **1번보다 밝은 것 둘**을 더했다.
    #   늘어놓는 차례는 밝은 것부터 — 그래야 단계가 보인다.
    ('BLACK_LL', 'BLACK', '흐린 먹',    210, .05, .300, True),
    ('BLACK_L', 'BLACK', '옅은 먹',     210, .05, .245, True),
    ('BLACK_S', 'BLACK', '진한 회색',   210, .04, .195, True),
    ('BLACK',   'BLACK', '검정',       210, .03, .118, True),
]

PALETTE = {k: _brew(h, s, l, d) for k, _f, _n, h, s, l, d in _SPEC}

# ★★ **테마를 타지 않는 역할** (2026-08-24 사용자 지시 — 여백메모 단추).
#   「영역을 선택하면 표시되는 메모 버튼이 잘 안보인다. **예외적으로 하드코딩**
#     하라 … 화면색을 어떤 테마로 하든지 글자가 잘 보여야 한다」
# ⚠⚠ **글자색만 바꾸면 안 된다.** 「진한 빨강이면 다 보일 것 같다」를 16개 테마
#   전부에서 쟀더니(WCAG 4.5:1) **검정 계열 넷에서 전부 실패**했다 —
#   `#8B0000` 이 `#262728` 바탕에서 **1.5:1**(거의 안 보인다). 어두운 바탕에
#   어두운 빨강이라 당연하다.
# ⇒ **바탕까지 고정한다.** 흰 바탕 + 진한 빨강 = **10.0:1**, 그리고 검정 테마에서는
#   하얀 단추가 통째로 튀어 「두드러지게」도 만족한다.
# ★ 화면에 색을 박지 않는다 — **팔레트에 역할로 등록**하고 위젯은 `C(역할)` 를
#   쓴다. 그래야 §36 검사기(굳은 색 0)를 지나고 나중에 한 곳에서 바꾼다.
# ⚠ 이 단추는 `overrideredirect` 창이라 `paint()` 가 **영영 닿지 않는다**(§72차) —
#   만들 때 색을 넣어야 하고, 그래서 더욱 테마를 안 타야 한다.
FIXED_ROLES = {
    'marginalia_bg': '#FFFFFF',
    'marginalia_fg': '#8B0000',
    'marginalia_bd': '#8B0000',
}
for _p in PALETTE.values():
    _p.update(FIXED_ROLES)

THEME_NAMES = list(PALETTE)

#: 걷은 테마 → 옮겨 갈 테마(2026-10-15 docs/1.txt 77 — 너무 강한 두 색). 저장값은 읽을 때 옮긴다.
RETIRED = {'BLUE_D': 'BLUE_S', 'BROWN_DD': 'BROWN_D'}

# 계열 → 그 계열의 벌 목록 (화면이 줄로 늘어놓는다)
FAMILIES = ('GREY', 'BLUE', 'BROWN', 'BLACK')
FAMILY_LABELS = {'GREY': ('THEME_FAM_GREY', '회색 계열'),
                 'BLUE': ('THEME_FAM_BLUE', '푸른색 계열'),
                 'BROWN': ('THEME_FAM_BROWN', '갈색 계열'),
                 'BLACK': ('THEME_FAM_BLACK', '검은색 계열')}
FAMILY_OF = {k: f for k, f, _n, *_ in _SPEC}
# 화면에 보일 이름 — i18n 키가 없으면 이 말을 쓴다
LABELS = {k: ('THEME_' + k, n) for k, _f, n, *_ in _SPEC}


def by_family(fam):
    return [k for k, f, *_ in _SPEC if f == fam]

# ── 색 → 역할 (실측 191가지에서 뽑았다) ───────────────────────────────────────
# ⚠ 여기 없는 색은 **손대지 않는다.** 모르는 색을 짐작해 바꾸면 화면이 망가지는데
#   무엇이 바뀐 것인지 알 수도 없다. 표를 넓히는 것이 안전한 방향이다.
_M = {
    'bg': ('white', '#FFF', '#FFFFFF', '#FAFAFA', '#FDFEFE', '#FCFCFC',
           '#F8F9FA', '#F9F9F9', '#FEFEFE'),
    'panel': ('#F4F6F7', '#F2F4F4', '#ECF0F1', '#EEF2F7', '#F0F3F4',
              '#EAEAEA', '#F5F5F5', '#EFEFEF', '#F0F0F0', '#F2F3F4',
              '#FDFDFD', '#FBFCFC', '#F4F8FB', '#F0F4F8', '#EFF3F6',
               # 2026-08-30 0.txt 1번 — 짚어 주신 화면의 굳은 색
               '#ECEFF1', '#ECECEC', '#E0E4E7', '#F8F9F9', '#EFF3F5',
               # 2026-09-02 테마 전수 — 안내 박스(panel_help_box) 굳은 색.
               #   연결 작업대의 연결정책 안내가 이 헬퍼를 써서 My Edit
               #   팝업까지 검정 테마에 밝은 칸으로 남았다.
               '#F8F9FB'),
    'panel_alt': ('#E5E8E8', '#E8E8E8', '#DDDDDD', '#E0E0E0', '#E9ECEF',
                  '#EAECEE', '#EAEDED', '#D5DBDB', '#E5E7E9',
               # 2026-08-30 0.txt 1번 — 짚어 주신 화면의 굳은 색
               '#DCE3E7', '#DCDDE1',
               # 2026-08-30 다크모드 전수 — 팝업에 남아 있던 밝은 회색
               '#EBEDEF', '#ECECEC', '#E0E4E7', '#F8F9F9', '#F2F2F3',
               '#EFF3F5', '#C8C8C8', '#D0D0D0', '#BBBBBB', '#C8C8C8'),
    'accent_bg': ('#EBF5FB', '#D6EAF8', '#EAF2FB', '#E8F6F3', '#D4E6F1',
                  '#AED6F1', '#A9CCE3', '#D5F5E3',
                  '#E8EAF6', '#F5F6FA', '#F4ECF7', '#EBDEF0', '#E8DAEF',
                  # 믿음의 발자취 상단 바·패널 (2026-08-13 실측)
                  '#EAF2F8', '#BFD3E6', '#D4E6F1',
                  # 어린이 탭 파스텔
                  '#FFF6E5', '#FDEBC8', '#FBF0D8', '#FAD7A0', '#E8C97A',
                  '#C9B998', '#FDF2E9', '#FAE5D3',
                  '#E8DCF0', '#B0C8E0', '#D2B4DE', '#D6DBDF',
               # 2026-08-30 0.txt 1번 — 짚어 주신 화면의 굳은 색
               '#E4EAEF', '#EAF2FF', '#D1F2EB', '#EAFAF1', '#D7BDE2', '#E8F1F8'),
    'dark_bg': ('#1C2833', '#17202A', '#212F3D', '#1A2B3C'),
    'dark_panel': ('#243342', '#2C3A47', '#34495E'),
    'fg': ('#000000', 'black', '#212121', '#2C3E50', '#333', '#333333',
           '#212F3D'),
    'fg_dim': ('#888', '#888888', '#999', '#999999', 'gray', 'grey',
               '#95A5A6', '#7F8C8D', '#AAAAAA', '#B3B3B3', '#85929E',
               '#909497', '#ABB2B9', '#AAB7B8', '#A6ACAF',
               # 2026-08-30 0.txt 1번 — 짚어 주신 화면의 굳은 색
               '#808B96', '#7B7D7D', '#8A96A0', '#B0B7BC'),
    'fg_label': ('#555', '#555555', '#666', '#666666', '#566573', '#5D6D7E',
                 '#4A4A4A'),
    'fg_title': ('#1A5276', '#154360', '#1B4F72', '#21618C',
               # 2026-08-30 0.txt 1번 — 짚어 주신 화면의 굳은 색
               '#1F618D', '#1A3A5C', '#2C4259'),
    'border': ('#BDC3C7', '#D5D8DC', '#CCCCCC', '#C0C0C0', '#AEB6BF',
               '#C8CDD2', '#B2BABB'),
    'accent': ('#2E86C1', '#3498DB', '#2874A6', '#5DADE2',
               '#5499C7', '#69A7D3', '#A569BD', '#8E44AD', '#7D3C98',
               '#3F51B5',            # 2026-08-16 주요용어 머리 — 남보라
               '#4A235A',
               # 2026-08-30 0.txt 1번 — 짚어 주신 화면의 굳은 색
               '#1565C0', '#2980B9', '#2E6DA4'),           # 2026-08-16 주요용어 페리코프 설명 — 진보라
    'success': ('#1E8449', '#229954', '#27AE60',
               # 2026-08-30 0.txt 1번 — 짚어 주신 화면의 굳은 색
               '#1A7A4A', '#1E5631', '#117A65', '#0E6655', '#1E7B3A'),
    'success_bg': ('#A9DFBF', '#D5F5E3', '#E8F8F5'),
    'danger': ('#C0392B', '#922B21', '#E74C3C',
               # 2026-08-30 0.txt 1번 — 짚어 주신 화면의 굳은 색
               '#8B0000', '#B03A2E', '#7B241C'),
    'danger_bg': ('#F5B7B1', '#FADBD8', '#FDEDEC'),
    'warning': ('#B7770D', '#E67E22', '#F39C12', '#9A6500', '#D4AC0D',
                '#B9770E',
                # 2026-08-16 — 렌즈묵상·묵상후보·주요용어의 짙은 겨자색.
                # 전수 실측에서 마지막까지 굳어 있던 글자색이다(검정 테마에서 안 읽혔다).
                '#7D6608', '#7E5109',
               # 2026-08-30 0.txt 1번 — 짚어 주신 화면의 굳은 색
               '#9C6708', '#784212', '#6E2F00', '#9A6A1B'),
    'warning_bg': ('#FBF3DC', '#FFF8EE', '#FFE082',
                   # 2026-08-30 묵상노트·태그 칩 · 폰트 설정의 강조 바탕
                   '#FEF9E7', '#FCF3CF', '#FDEBD0', '#FFF3CD',
                   '#F9FBE7',        # 2026-08-16 주요용어 사전 본문 바탕
                   '#FEF5E7'),       # 2026-08-17 렌즈 연결설명 카드·체인 표시 바탕
    'select_bg': ('#D6EAF8', '#AED6F1'),
}
# 색은 대소문자를 섞어 쓰므로 **대문자로 맞춰** 담는다
ROLE_OF = {}
for _r, _cs in _M.items():
    for _c in _cs:
        ROLE_OF.setdefault(_c.upper(), _r)

# ★ **같은 색이 바탕일 때와 글자일 때 뜻이 다르다** (2026-08-13 실측으로 잡았다).
#   `#1A5276` 은 글자로 61번(진한 파랑 제목) · 바탕으로 24번(어두운 머리띠) 쓰인다.
#   글자 기준으로만 바꿨더니 **검정 테마에서 머리띠가 밝은 하늘색이 됐다**(59곳).
#   ⇒ 바탕으로 쓰였을 때의 역할을 따로 적는다. 여기 없으면 위 표를 따른다.
_MB = {
    'dark_bg': ('#1A5276', '#154360', '#1B4F72', '#21618C', '#2C3E50',
                '#212F3D', '#17202A', '#1C2833', '#000000', 'black'),
    'dark_panel': ('#566573', '#5D6D7E', '#555', '#555555', '#666', '#666666',
                   '#333', '#333333'),
    'panel_alt': ('#888', '#888888', '#999', '#999999', 'gray', 'grey',
                  '#95A5A6', '#7F8C8D'),
    # 강조색을 **바탕**으로 쓴 자리는 부드러운 쪽으로 — 어두운 테마에서 눈이 편하다
    'success_bg': ('#1E8449', '#229954', '#27AE60'),
    'danger_bg': ('#C0392B', '#922B21', '#E74C3C'),
    'warning_bg': ('#B7770D', '#E67E22', '#F39C12'),
    'accent_bg': ('#2E86C1', '#3498DB', '#2874A6', '#5DADE2'),
}
# ★ **2026-08-16 보탬** — 전수 실측에서 마지막까지 남던 색들.
#   ⚠ **바탕 자리만** 넣는다. `#6C3483`·`#2471A3` 은 언어 식별색으로도 쓰여서
#     (`'LA'`·`'JA'`·`'EN'`) 글자까지 번역하면 언어가 구분되지 않는다.
#   ⚠ 연한 노랑·초록은 `bg` 가 아니라 제 뜻(`warning_bg`·`success_bg`)으로 넣는다 —
#     전부 `bg` 로 밀면 「알림」과 「보통」이 같아진다.
_MB['dark_bg'] += ('#2471A3', '#6C3483', '#4A235A', '#2E4053',
                   '#0E2A38')       # 2026-08-16 주요용어 「여정」 판 바탕
_MB['warning_bg'] += ('#FBF7E0',)
_MB['success_bg'] += ('#D4EFDF',)
# ★ 2026-10-24 관리자 어두운 화면 — 언어 배지(admin/lang_badge) 파스텔 · 읽기 칸 회색이 밝은 채로 남았다(실측)
_MB['success_bg'] += ('#DCF2E3',)
_MB['panel_alt'] = tuple(_MB.get('panel_alt', ())) + ('#F1F2F3', '#CDD2D7')
_MB.setdefault('bg', ())
_MB['bg'] += ('#FFFEF8', '#F7F9F9')
ROLE_OF_BG = {}
for _r, _cs in _MB.items():
    for _c in _cs:
        ROLE_OF_BG.setdefault(_c.upper(), _r)

# 바탕 역할 → 그 위에 얹을 글자 역할 (글자색을 안 정한 위젯에 쓴다)
_FG_FOR_BG = {
    'dark_bg': 'fg_on_dark', 'dark_panel': 'fg_on_dark',
    'success_bg': 'success', 'danger_bg': 'danger', 'warning_bg': 'warning',
}

# 밝은 테마에서의 원래 색 — 「지금 화면 색 → 역할」을 찾을 때 쓴다
_OPT_BG = ('bg', 'background', 'activebackground', 'highlightbackground',
           'selectbackground', 'insertbackground', 'troughcolor',
           'selectcolor',            # 체크박스·라디오 **네모 안쪽** — 이게 빠져서 희미했다
           'readonlybackground', 'inactiveselectbackground', 'highlightcolor')
_OPT_FG = ('fg', 'foreground', 'activeforeground', 'selectforeground',
           'disabledforeground')

# ★ **OS 가 정해 준 기본 바탕** — 여기가 빠져 있어서 색이 안 먹는 곳이 많았다
#   (2026-08-13 사용자 지적: 「어떤 색을 선택해도 바탕이 흰색인 것들이 많다」).
#   `tk.Text`·`Entry`·`Listbox` 는 `bg` 를 안 주면 `SystemWindow`(흰색)이고,
#   `Button`·`Checkbutton`·`Frame` 은 `SystemButtonFace`(연회색)다. 화면이 색을
#   **적지 않은 자리**라 191가지 표에 있을 리가 없었다. ⇒ 이것도 역할로 본다.
_SYS_ROLE = {
    'systemwindow': 'bg',                 # 글 쓰는 칸·목록·검색창의 흰 바탕
    'systembuttonface': 'panel',          # 버튼·체크박스·대화상자 바탕
    'systemmenu': 'panel',
    'system3dlight': 'panel_alt',
    'system3dface': 'panel',
    'systeminfobackground': 'warning_bg',
    'systemhighlight': 'select_bg',
    'systemscrollbar': 'panel_alt',
}

# ── 지금 테마 ────────────────────────────────────────────────────────────────

_active = DEFAULT


def current():
    return _active


def C(role):
    """지금 테마의 그 역할 색. `C('bg')`, `C('fg_dim')`."""
    return PALETTE[_active].get(role, PALETTE[DEFAULT].get(role, ''))


def is_dark(name=None):
    return FAMILY_OF.get(name or _active) == 'BLACK'


# ── 상단 도구 bar 표준 높이 ────────────────────────────────────────────────
#   화면마다 pady 를 눈대중으로 주다 보니 P4 서브탭 bar 가 27~64px 로
#   제각각이었다(2026-08-20 실측). 탭을 옮길 때마다 그 줄이 몇 px 씩
#   오르내리면 아래 화면 전체가 흔들린다. **표준값 하나로 못 박는다.**
BAR_H = 32


def bar_height(frame, h=BAR_H):
    """상단 도구 bar 의 높이를 표준값으로 고정한다.

    ⚠ `height=` 만 주면 Tk 는 자식 크기를 따라간다 —
      `pack_propagate(False)` 가 있어야 선언 높이를 실제로 지킨다.
    ⚠ 자식이 이 높이보다 크면 잘린다. 단추는 `pady` 를 2 이하로 둘 것."""
    try:
        frame.configure(height=h)
        frame.pack_propagate(False)
        frame.grid_propagate(False)
    except Exception:
        pass
    return frame


def load(db_path=None):
    """저장된 테마를 읽어 활성으로. 없으면 기본(GREY)."""
    global _active
    try:
        c = appdb.connect(db_path) if db_path else appdb.connect()
        r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                      (CONFIG_KEY,)).fetchone()
        c.close()
        v = r[0] if r else None
        v = RETIRED.get(v, v)
        if v in PALETTE:
            _active = v
    except Exception:
        pass
    return _active


def use(db_path, name):
    """테마를 선택하고 **저장**한다. 화면 반영은 `paint()` 가 한다."""
    global _active
    if name not in PALETTE:
        return False
    _active = name
    forget_styles()                    # 전용 스타일을 새 테마로 다시 칠하게
    try:
        c = appdb.connect(db_path) if db_path else appdb.connect()
        c.execute("INSERT INTO user_config (config_key, config_val) VALUES (?,?) "
                  "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                  (CONFIG_KEY, name))
        c.commit()
        c.close()
        return True
    except Exception as e:
        # ⚠ 조용히 실패하면 「눌러도 아무 일이 없다」가 된다 — 폰트에서 겪었다
        import sys
        print(f'[ui_theme.use] 저장 실패: {e}', file=sys.stderr)
        return False


# ── 지금 떠 있는 화면을 다시 칠한다 ──────────────────────────────────────────

SAMPLE = '_hagah_sample'   # ★ **색을 보여 주는 견본** — 칠하면 그 뜻이 사라진다

_ORIG_ATTR = '_hagah_orig_colors'


_LAST_ATTR = '_hagah_last_colors'

# ── 팔레트 역방향 표 (2026-08-16) ────────────────────────────────────────────
#
# ★ **이것이 없어서 「테마마다 오류 패턴이 다르다」가 났다.**
#   `ROLE_OF` 는 「화면에 박힌 옛 색 → 역할」 표다. 그런데 요즘 화면은 색을 박지 않고
#   `C('panel')` 로 가져다 쓴다. 그러면 그 위젯의 색은 **그때 켜 둔 테마의 팔레트 색**
#   이고, 테마를 바꾸면 `paint` 가 그게 무슨 역할인지 몰라 **그대로 굳는다.**
#   실측(2026-08-16) — 위젯 947개 중 202개(21%)가 그렇게 남았고, 남은 색의 대부분이
#   시작할 때 켜 두었던 테마의 `panel`·`panel_alt`·`bg` 였다.
#
# ⚠ **바탕 자리와 글자 자리를 따로 본다.** 한 표로 합치면 어두운 바 위의 흰 글자가
#   바탕 역할로 번역돼 글자와 바탕이 같은 색이 된다.
# ⚠ 겹치는 색은 실측상 **하나뿐**(`#D1D1D1` → fg / fg_on_dark)이다. 지금 켠 테마의
#   역할을 먼저 보고, 없으면 아래 차례로 고른다.

_BG_ROLES = ('bg', 'panel', 'panel_alt', 'accent_bg', 'dark_bg', 'dark_panel',
             'success_bg', 'danger_bg', 'warning_bg', 'select_bg', 'border',
             'focus_bg', 'restore_bg')
_FG_ROLES = ('fg', 'fg_dim', 'fg_label', 'fg_title', 'fg_on_dark',
             'accent', 'success', 'danger', 'warning')

# 글자용 역할을 **바탕으로 썼을 때** 옮겨 갈 자리
_BG_TWIN = {'success': 'success_bg', 'danger': 'danger_bg',
            'warning': 'warning_bg', 'accent': 'accent_bg'}

PAL_BG = {}      # 색 → 바탕 역할
PAL_FG = {}      # 색 → 글자 역할


def _build_palette_index():
    """모든 테마의 팔레트를 「색 → 역할」로 뒤집는다. 멱등."""
    PAL_BG.clear()
    PAL_FG.clear()
    for roles, table in ((_BG_ROLES, PAL_BG), (_FG_ROLES, PAL_FG)):
        # 뒤 차례가 앞을 덮지 않도록 **역순**으로 넣는다 — 앞선 역할이 이긴다
        for role in reversed(roles):
            for pal in PALETTE.values():
                v = (pal.get(role) or '').upper()
                if v:
                    table[v] = role


def focus_kw(restore=False, **over):
    """[Focus]/[Restore] 단추 서식 — flat_btn + 역할 바탕(2026-09-16 · 1.txt 13번).
    Focus = `focus_bg`(분홍 파스텔) · Restore = `restore_bg`(초록 파스텔)."""
    kw = flat_btn(**over)
    # ★ 규격 = 노트북 탭(2026-09-16 사용자 「focus / restore 규격을 탭 규격과 일치시켜라」) —
    #   `apply_notebook_tabs` 의 `TNotebook.Tab` 과 같은 여백(10, 3)·테두리 1px(`border` 색).
    #   단추가 이제 P1·P4 **탭 줄 맨 왼쪽**에 살아 탭과 나란히 보이기 때문이다(1.txt 28).
    kw.update(padx=10, pady=3, highlightthickness=1,
              highlightbackground=C('border') or '#C8C8C8',
              highlightcolor=C('border') or '#C8C8C8')
    kw.update(over)
    role = 'restore_bg' if restore else 'focus_bg'
    col = C(role)
    if col:
        kw['bg'] = col
        kw['activebackground'] = col
    return kw


def flat_btn(**over):
    """**테두리 없는 라벨 꼴 단추**의 단일 소스 (2026-08-30 사용자 지시
    「현재 음각 방식에서 테두리 없는 라벨 방식(← → 버튼처럼)으로」 ·
    「모든 Font 버튼은 디자인을 통일」).

    ⚠ 화면마다 손으로 베끼면 반드시 갈라진다 — 실측으로 잡았다: P1 의 Font 는
      `Malgun Gothic 9 · groove`, 묵상플랜 띠의 Font 는 `('', 8) · solid` 였다.
    ⚠ `pady=2` 를 빼지 말 것 — 상단 bar 높이 28px 가 그 값에 맞춰져 있다.
    """
    kw = dict(font=("Malgun Gothic", 9), bd=0, relief='flat',
              padx=6, pady=2, cursor='hand2',
              bg=C('panel') or '#EFF3F6', fg=C('fg') or '#2C3E50',
              activebackground=C('panel_alt') or '#E8E8E8')
    kw.update(over)
    return kw


def _pal_role(color, is_bg):
    """그 색의 역할. 지금 켠 테마의 것을 먼저 본다."""
    c = (color or '').upper()
    if not c:
        return None
    cur = PALETTE.get(_active) or {}
    for role in (_BG_ROLES if is_bg else _FG_ROLES):
        if (cur.get(role) or '').upper() == c:
            return role
    hit = (PAL_BG if is_bg else PAL_FG).get(c)
    if hit is None and is_bg:
        # ★ **강조색을 바탕으로 쓴 자리** (2026-08-16). `success`·`danger`·`warning`·
        #   `accent` 는 글자용 역할이라 바탕 표에 없다. 그런데 화면들은 그 색을
        #   초록/빨강 띠의 **바탕**으로도 쓴다 — 그러면 어느 표에도 안 걸려 굳는다.
        #   ⇒ 짝이 되는 부드러운 바탕 역할로 옮긴다(`_MB` 가 옛 색에 하던 것과 같다).
        hit = _BG_TWIN.get(PAL_FG.get(c))
    return hit


# ⚠ **정의 바로 뒤에서 만든다.** 위쪽(`current()` 옆)에 두었더니 정의보다 먼저
#   불려 NameError 가 났다 — `_LAST_ATTR` 이 파일 아래쪽에 있기 때문이다.
_build_palette_index()




def _orig(w):
    """그 위젯의 **화면이 정한** 색. 테마 번역의 근거가 된다.

    ⚠ 이것이 없으면 테마를 오갈 때 「바뀐 색」을 다시 번역하게 되어 원본을 잃는다.

    ★ **화면이 나중에 색을 바꾸면 그것을 새 원본으로 받는다** (2026-08-13 사용자 지적
      「버튼이 여러개 있을 때 색상 반전기능이 모두 문제다」).
      고른 버튼을 표시하는 흔한 방법이 **누를 때 `config(bg=...)` 로 색을 갈아 끼우는 것**
      인데, 그 값은 화면에 박힌 밝은 색이라 어두운 테마에서 혼자 튄다.
      그렇다고 처음 색으로 되돌리면 **고른 표시가 사라진다.**
      ⇒ 우리가 마지막으로 쓴 값(`_last`)과 지금 값을 견줘 **다르면 화면이 바꾼 것**으로
        보고 원본을 갱신한다. 그러면 고른 버튼과 안 고른 버튼이 **서로 다른 역할**로
        번역돼 테마 안에서 제대로 갈린다.
    """
    d = getattr(w, _ORIG_ATTR, None)
    last = getattr(w, _LAST_ATTR, None)
    if d is None:
        d, last = {}, {}
        setattr(w, _ORIG_ATTR, d)
        setattr(w, _LAST_ATTR, last)
        for opt in _OPT_BG + _OPT_FG:
            try:
                v = str(w.cget(opt))
            except Exception:
                continue
            if v:
                d[opt] = v
        return d
    for opt in list(d):
        try:
            now = str(w.cget(opt))
        except Exception:
            continue
        if opt in last and now != last[opt]:
            d[opt] = now              # 화면이 갈아 끼웠다 — 새 원본으로 받는다
    return d


#: `only_new` 에서도 늘 다시 보는 위젯 — 내용물(캔버스 아이템·트리 태그)을
#  **화면이 나중에 그리는** 것들이다. 위젯 자체는 칠해졌어도 내용은 새로 생긴다
#  (2026-08-19 실측 — 점프 직후 도서/설교 트리 태그). `_paint_extra` 가 제
#  표식으로 diff 하므로 다시 봐도 싸다.
_CONTENT_CLS = ('Canvas', 'BibleP4TreeCanvas', 'Treeview')


def paint(widget, _n=None, only_new=False):
    """이 위젯과 그 아래 전부를 지금 테마로 다시 칠한다. **바꾼 개수**를 돌려준다.

    ⚠ 표에 없는 색은 건드리지 않는다. 그래서 처음에는 화면 일부만 바뀐다 —
      `ROLE_OF` 를 넓히는 만큼 따라온다. **모르는 색을 짐작하지 않는 것이 원칙이다.**

    ★ `only_new=True` — **탭 전환 고리 전용** (2026-08-27 사용자 신고 「P1 탭이
      깜빡하며 느려졌다」). 전환마다 위젯 1,900개의 cget 폭풍(실측 전환당
      ~160ms)을 돌던 것을, **표식(`_ORIG_ATTR`)이 없는 새 위젯만** 칠하는
      모드로 줄인다. 지연 빌드가 만든 위젯은 표식이 없어 온전히 칠해진다.
    ⚠ 이 모드는 「화면이 색을 갈아 끼운 옛 위젯」을 다시 번역하지 않는다 —
      그 몫은 여전히 클릭 고리(`_paint_after_click`)와 전체 칠(시작·설정 변경)
      이다. 전체 칠 자리에서 only_new 를 켜지 말 것.
    """
    n = 0 if _n is None else _n
    # ★ 2026-10-13 — 미뤄 둔 칠(after_idle·after 250)이 도는 사이 팝업이 닫히면 이미 없는 창을
    #   칠하려다 오류가 났다(오류 기록 실측 — AI 도우미 팝업 · 9/27~10/10 21건). 없는 창은 건너뛴다.
    if _n is None and hasattr(widget, 'winfo_exists'):
        try:
            if not widget.winfo_exists():
                return n
        except Exception:                 # 닫힌 창의 Tcl 오류
            return n
    # ★★★ **Treeview 태그 색은 화면이 다시 걸어야 한다** (2026-08-31 사용자
    #   「도서/설교 왼쪽 책 이름 글자가 **화면색 테마를 변경하면 제대로
    #   보여지지 않는다. 다크모드 이외에는 흐릿하다**」).
    #   ⚠⚠ `paint` 는 **위젯 옵션**을 칠한다 — Treeview 의 `tag_configure` 색은
    #     옵션이 아니라 못 본다(§36-5b). 그래서 BLACK 에서 만든 트리를 밝은
    #     테마로 바꾸면 `fg_title` 이 **`#90B8D5`(연한 하늘색) 그대로 남아**
    #     흰 바탕에서 흐릿했다.
    #   ⚠⚠ 일곱 화면이 각자 `_retag`/`_retag_trees` 를 갖고 있었는데 **테마를
    #     바꿀 때 부르는 공통 고리가 없었다** — 화면마다 배선하면 빠진다.
    #   ⇒ `theme_font._poke` 가 `apply_font` 를 찾아 부르는 그 문법으로,
    #     **전체 칠(테마 변경·시작)에서만** 찾아 부른다.
    #   ⚠ `only_new`(탭 전환 고리)에서는 안 부른다 — 전환마다 돌면 느려진다.
    if not only_new:
        for _nm in ('_retag', '_retag_trees'):
            _fn = getattr(widget, _nm, None)
            if callable(_fn):
                try:
                    _fn()
                except Exception as e:
                    print('[paint retag %s] %s' % (_nm, e))
                break
    if only_new and getattr(widget, _ORIG_ATTR, None) is not None:
        if widget.__class__.__name__ in _CONTENT_CLS:
            n += _paint_extra(widget)      # 내용물만 — 아이템·태그는 늦게 생긴다
        for ch in widget.winfo_children():
            n = paint(ch, n, only_new)
        return n
    # ★ **폰트 쪽이 글자색을 정한 위젯은 글자색을 건드리지 않는다** (2026-08-14).
    #   두 손이 한 위젯을 만지면 반드시 하나가 진다 — 경계를 코드로 긋는다.
    _fg_locked = bool(getattr(widget, '_hagah_fg_owned', False))
    # ★ 견본은 **자기 색이 곧 내용**이다 — 칠하면 무슨 색인지 알 수 없게 된다
    #   (2026-08-14: 보라를 골랐는데 견본이 강조색으로 번역돼 딴 색을 보였다).
    if getattr(widget, SAMPLE, False):
        # ⚠ **자식으로 내려가지 않는다** (2026-08-16). 예전에는 이 위젯만 건너뛰고
        #   자식은 칠했는데, 색칩은 색이 **자식(면·띠·라벨)에 있어서** 아무 소용이
        #   없었다. 팔레트 역방향 표가 생긴 뒤로는 16벌 견본이 전부 한 색이 됐다.
        return n
    o = _orig(widget)
    _last = getattr(widget, _LAST_ATTR, None)
    if _last is None:
        _last = {}
        setattr(widget, _LAST_ATTR, _last)
    bg_role = None
    for opt, was in o.items():
        if _fg_locked and opt in _OPT_FG:
            continue
        is_bg = opt in _OPT_BG
        role = (ROLE_OF_BG.get(was.upper()) if is_bg else None) \
            or ROLE_OF.get(was.upper())
        if not role and is_bg:
            role = _SYS_ROLE.get(was.lower())      # OS 기본 바탕
        if not role:
            # ★ **역할색으로 지어진 위젯** — 요즘 화면은 색을 박지 않고 `C(역할)` 을
            #   쓴다. 그 색이 무슨 역할인지 여기서 알아본다(2026-08-16).
            role = _pal_role(was, is_bg)
        if not role:
            # ★ 2026-10-27 (docs/1.txt 14-1) 표에 없는 **진한 글자색**(언어·갈래 식별색 · 「#444」)이 어두운 바탕에서
            #   안 읽혔다. 역할을 지어내지 않고 **같은 빛깔을 밝게** 해 대비만 맞춘다(갈래끼리 색 구분은 남는다).
            if opt in ('fg', 'foreground') and not _fg_locked:
                try:
                    want = readable(was, widget.cget('bg'), widget)
                    if want and str(widget.cget(opt)) != want:
                        widget.configure(**{opt: want})
                        n += 1
                    if want:
                        _last[opt] = want
                except Exception:
                    pass
            continue
        if opt in _OPT_FG and role in ('bg', 'panel', 'panel_alt', 'accent_bg'):
            # 밝은 바탕색을 **글자**로 쓴 자리(어두운 바 위의 흰 글자) — 뒤집힌다
            role = 'fg_on_dark'
        if opt in ('bg', 'background'):
            bg_role = role
        want = C(role)
        try:
            if str(widget.cget(opt)) != want:
                widget.configure(**{opt: want})
                n += 1
            _last[opt] = want          # 우리가 쓴 값 — 다음에 화면이 바꿨는지 가린다
        except Exception:
            pass

    # ★ **바탕만 정하고 글자는 안 정한 위젯이 아주 많다** (2026-08-13 실측).
    #   그런 위젯의 글자는 OS 기본값(`SystemWindowText` = 검정)이라, 바탕을 어둡게
    #   바꾸면 **검은 바탕에 검은 글자**가 된다. 실제로 P1 본문이 그랬다.
    #   ⇒ 바탕을 우리가 바꿨는데 글자가 「정해진 적 없는 값」이면 글자도 정해 준다.
    if bg_role:
        want_fg = C(_FG_FOR_BG.get(bg_role, 'fg'))
        for opt in (() if _fg_locked else ('fg', 'foreground')):
            was = o.get(opt)
            if was is None or ROLE_OF.get(was.upper()):
                continue                     # 없거나, 이미 위에서 제대로 바꿨다
            if not _is_default(was):
                continue                     # 화면이 일부러 고른 색 — 건드리지 않는다
            try:
                if str(widget.cget(opt)) != want_fg:
                    widget.configure(**{opt: want_fg})
                    n += 1
                _last[opt] = want_fg
            except Exception:
                pass
        # ★ 2026-10-27 (docs/1.txt 14-1) **비활성 글자** — OS 기본(SystemDisabledText 회색)이 어두운 바탕에서 안 읽혔다
        #   (관리자 화면 실측 81곳 · 대비 2.5~2.9). 바탕을 우리가 칠했으면 비활성 글자도 흐린 글자 역할로.
        if not _fg_locked and _is_default(o.get('disabledforeground', '')) and o.get('disabledforeground'):
            try:
                if str(widget.cget('disabledforeground')) != C('fg_dim'):
                    widget.configure(disabledforeground=C('fg_dim'))
                    n += 1
                _last['disabledforeground'] = C('fg_dim')
            except Exception:
                pass
        # 글자 커서도 안 보이면 입력칸에서 어디를 치는지 알 수 없다
        try:
            if _is_default(o.get('insertbackground', '')):
                widget.configure(insertbackground=want_fg)
        except Exception:
            pass

    n += _paint_extra(widget)
    n += _paint_style(widget)          # 화면 전용 ttk 스타일도 함께
    for ch in widget.winfo_children():
        n = paint(ch, n, only_new)
    return n


_ORIG_ITEMS = '_hagah_orig_items'


def _paint_extra(w):
    """위젯 **옵션이 아닌 것**들 — 그림 안의 글자, 콤보의 펼친 목록.

    ⚠ 이 둘은 `cget` 으로 안 잡혀서 훑기가 통째로 지나친다
      (2026-08-13 사용자 지적: 「캔버스 노드박스 내부의 글자가 다크모드에서
      밝은색으로 바뀌지 않음」·「콤보상자는 어떻게 해야 하는가」).
    """
    n = 0
    cls = w.__class__.__name__

    # ── 그림(Canvas) 안의 항목 ──
    if cls in ('Canvas', 'BibleP4TreeCanvas'):
        try:
            items = w.find_all()
        except Exception:
            items = ()
        keep = getattr(w, _ORIG_ITEMS, None)
        if keep is None:
            keep = {}
            setattr(w, _ORIG_ITEMS, keep)
        for it in items:
            try:
                kind = w.type(it)
            except Exception:
                continue
            if it not in keep:
                d = {}
                for o in ('fill', 'outline'):
                    try:
                        d[o] = str(w.itemcget(it, o))
                    except Exception:
                        pass
                keep[it] = d
            for o, was in keep[it].items():
                if not was:
                    continue        # 비어 있으면 「칠하지 않음」이다 — 채우면 안 된다
                if o == 'outline':
                    role = 'border'
                elif kind == 'text':
                    # 글자다 — **바탕용 표를 쓰면 안 된다**(검정이 어두운 바탕색이 된다)
                    role = ROLE_OF.get(was.upper())
                else:
                    role = ROLE_OF_BG.get(was.upper()) or ROLE_OF.get(was.upper())
                if not role:
                    continue
                try:
                    if str(w.itemcget(it, o)) != C(role):
                        w.itemconfigure(it, **{o: C(role)})
                        n += 1
                except Exception:
                    pass

    # ── 글상자(Text)의 **태그 색** ★ 2026-10-27 (docs/1.txt 14-1) ──
    # 안내 박스(panel_help_box)의 머리·단추 이름·경고·코드 색이 태그라 옵션 훑기가 못 닿아
    # 어두운 화면에서 진한 파랑·회색 글자가 그대로 남았다(관리자 실측 70곳). 원래 색을 기억해 두고 역할로 옮긴다.
    elif getattr(w, 'winfo_class', lambda: '')() == 'Text':
        keep = getattr(w, _ORIG_ITEMS, None)
        if keep is None:
            keep = {}
            setattr(w, _ORIG_ITEMS, keep)
        try:
            tags = [t for t in w.tag_names() if t not in ('sel',)]
            wbg = str(w.cget('bg'))
        except Exception:
            tags, wbg = [], ''
        for t in tags:
            for o in ('foreground', 'background'):
                k = (t, o)
                try:
                    now = str(w.tag_cget(t, o) or '')
                except Exception:
                    continue
                if k not in keep:
                    keep[k] = now
                was = keep[k]
                if not was:
                    continue
                role = (ROLE_OF_BG.get(was.upper()) if o == 'background' else None) or ROLE_OF.get(was.upper())
                want = C(role) if role else None
                if not want and o == 'foreground':
                    want = readable(was, wbg, w) or (was if not is_dark() else None)
                if not want:
                    continue
                try:
                    if now != want:
                        w.tag_configure(t, **{o: want})
                        n += 1
                except Exception:
                    pass

    # ── 표(Treeview)의 **줄 태그** ──
    # 화면이 `tag_configure('user', foreground='#1E8449')` 처럼 줄마다 색을 준다.
    # 태그는 위젯 옵션이 아니라 훑기가 못 닿는다.
    # ★ 목록은 `tag names` 로 받는다 (2026-08-27 — 「P1 탭 깜빡」 수리).
    #   예전에는 「Tk 가 태그 목록을 주지 않는다」고 알고 **전 행을 훑어**
    #   거뒀는데, 그 짐작이 틀렸다 — Tk 8.6 의 ttk::treeview 는 `tag names`
    #   를 지원한다. 3천 행 트리에서 전환당 ttk.item 14,900회를 돌던 것이
    #   호출 한 번이 됐고, **설정만 되고 아직 줄에 안 쓰인 태그까지 잡아**
    #   더 정확하다(옛 방식은 그런 태그를 놓쳤다).
    elif cls == 'Treeview':
        try:
            tags = set(map(str, w.tk.call(w._w, 'tag', 'names')))
        except Exception:
            # 폴백 — 옛 방식(전 행 훑기). `tag names` 가 없는 옛 Tk 용.
            tags = set()
            try:
                stack = list(w.get_children(''))
                while stack:
                    iid = stack.pop()
                    tags.update(w.item(iid, 'tags') or ())
                    stack.extend(w.get_children(iid))
            except Exception:
                pass
        keep = getattr(w, _ORIG_ITEMS, None)
        if keep is None:
            keep = {}
            setattr(w, _ORIG_ITEMS, keep)
        for t in tags:
            for o in ('background', 'foreground'):
                k = (t, o)
                try:
                    now = str(w.tag_configure(t, o) or '')
                except Exception:
                    continue
                if k not in keep:
                    keep[k] = now
                was = keep[k]
                if not was:
                    continue
                role = (ROLE_OF_BG.get(was.upper()) if o == 'background'
                        else None) or ROLE_OF.get(was.upper())
                want = C(role) if role else None
                if not want and o == 'foreground':
                    # ★ 2026-10-27 표에 없는 진한 줄 색(갈래 식별색) — 같은 빛깔을 밝게(어두운 테마일 때만)
                    want = readable(was, C('bg'), w) or (was if not is_dark() else None)
                if not want:
                    continue
                try:
                    if now != want:
                        w.tag_configure(t, **{o: want})
                        n += 1
                except Exception:
                    pass

    # ── 콤보상자의 **펼친 목록** ──
    # 그 목록은 자식 위젯이 아니라 딴 창(popdown)에 있어 훑기가 못 닿는다.
    elif cls == 'Combobox':
        try:
            path = w.tk.eval(f'ttk::combobox::PopdownWindow {w}') + '.f.l'
            for o, role in (('background', 'bg'), ('foreground', 'fg'),
                            ('selectBackground', 'select_bg'),
                            ('selectForeground', 'fg')):
                w.tk.call(path, 'configure', '-' + o.lower(), C(role))
            n += 1
        except Exception:
            pass
    return n


def _contrast(w, a, b):
    try:
        ra = [x / 65535 for x in w.winfo_rgb(a)]
        rb = [x / 65535 for x in w.winfo_rgb(b)]
    except Exception:
        return None

    def L(c):
        c = [x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4 for x in c]
        return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]
    la, lb = L(ra), L(rb)
    return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)


def readable(fg, bg, w, need=4.5):
    """★ 2026-10-27 어두운 테마에서 **바탕과 대비가 모자라는 글자색** → 같은 빛깔을 흰색 쪽으로 섞어 대비를 맞춘 색.
    밝은 테마이거나 이미 읽히면 None(손대지 않는다). 바탕이 밝으면(어두운 테마의 밝은 칩) 손대지 않는다.
    """
    if not is_dark() or not fg or not bg or _is_default(fg):
        return None
    r = _contrast(w, fg, bg)
    if r is None or r >= 3.0:
        return None
    try:
        rb = [x / 65535 for x in w.winfo_rgb(bg)]
        if 0.299 * rb[0] + 0.587 * rb[1] + 0.114 * rb[2] > 0.5:
            return None
        c = [x / 65535 for x in w.winfo_rgb(fg)]
    except Exception:
        return None
    for k in range(1, 11):
        t = k / 10
        m = [x + (1 - x) * t for x in c]
        h = '#%02X%02X%02X' % tuple(int(round(x * 255)) for x in m)
        if (_contrast(w, h, bg) or 0) >= need:
            return h
    return C('fg')


def _mix_to(fg, bg, w, need=4.5):
    """같은 빛깔을 바탕 반대쪽(어두운 바탕 → 흰색 · 밝은 바탕 → 검정)으로 섞어 대비를 맞춘 색. 이미 3.0 넘으면 None."""
    r = _contrast(w, fg, bg)
    if r is None or r >= 3.0:
        return None
    try:
        rb = [x / 65535 for x in w.winfo_rgb(bg)]
        c = [x / 65535 for x in w.winfo_rgb(fg)]
    except Exception:
        return None
    # 바탕 반대쪽을 먼저 · 안 되면 다른 쪽(중간 밝기 바탕 — 초록 단추 위 흰 글자는 흰 쪽이 맞다)
    first = 0.0 if (0.299 * rb[0] + 0.587 * rb[1] + 0.114 * rb[2]) > 0.5 else 1.0
    best = None
    for to in (first, 1.0 - first):
        for k in range(1, 11):
            t = k / 10
            m = [x + (to - x) * t for x in c]
            h = '#%02X%02X%02X' % tuple(int(round(x * 255)) for x in m)
            if (_contrast(w, h, bg) or 0) >= need:
                if best is None or t < best[0]:
                    best = (t, h)
                break
    if best:
        return best[1]
    return '#000000' if first == 0.0 else '#FFFFFF'


def fix_contrast(root):
    """★ 2026-10-27 (docs/1.txt 14-1) **읽히지 않는 글자만** 고친다 — 밝은·어두운 화면 둘 다.

    관리자 화면은 수백 곳에 색을 박아 두었고(「없음」 #B0B0B0 · 「저장됨」 #27AE60 · 갈래 식별색 …) 그중 일부는
    바탕과 대비가 3.0 이 안 돼 안 읽혔다(실측 밝은 화면 176곳 · 어두운 화면 174곳). 화면마다 고치면 또 빠진다 ⇒
    **그려진 뒤 대비만 잰다** — 3.0 아래인 글자색을 같은 빛깔로 바탕 반대쪽에 섞는다(색 구분은 남는다 · 3.0 넘는 것은 안 건드린다).
    위젯 글자(fg · 비활성 글자) · ttk 위젯 foreground · 글상자 태그 · 표 줄 태그를 본다. 바꾼 개수를 돌려준다.
    """
    n = 0
    stack = [root]
    try:
        from tkinter import ttk as _ttk
        st = _ttk.Style()
    except Exception:
        st = None
    while stack:
        w = stack.pop()
        try:
            stack.extend(w.winfo_children())
            cls = w.winfo_class()
        except Exception:
            continue
        try:
            if cls == 'Treeview':
                sn = str(w.cget('style')) or 'Treeview'
                fb = (st.lookup(sn, 'fieldbackground') or st.lookup('Treeview', 'fieldbackground')) if st else ''
                if fb:
                    for t in map(str, w.tk.call(w._w, 'tag', 'names')):
                        f = str(w.tag_configure(t, 'foreground') or '')
                        b = str(w.tag_configure(t, 'background') or '') or fb
                        if f:
                            want = _mix_to(f, b, w)
                            if want:
                                w.tag_configure(t, foreground=want)
                                n += 1
                continue
            if cls == 'Text':
                wb = str(w.cget('bg'))
                for t in w.tag_names():
                    if t == 'sel':
                        continue
                    f = str(w.tag_cget(t, 'foreground') or '')
                    b = str(w.tag_cget(t, 'background') or '') or wb
                    if f:
                        want = _mix_to(f, b, w)
                        if want:
                            w.tag_configure(t, foreground=want)
                            n += 1
            if cls in ('Label', 'Button', 'Checkbutton', 'Radiobutton', 'Message', 'Menubutton', 'Text', 'Listbox', 'Entry'):
                b = str(w.cget('bg'))
                for o in ('fg', 'disabledforeground'):
                    try:
                        f = str(w.cget(o))
                    except Exception:
                        continue
                    if not f:
                        continue
                    want = _mix_to(f, b, w)
                    if want:
                        w.configure(**{o: want})
                        n += 1
            elif cls in ('TEntry', 'TCombobox') and st is not None:
                sn = str(w.cget('style')) or cls
                f = str(w.cget('foreground') or '') or str(st.lookup(sn, 'foreground') or '')
                if f:
                    b = st.lookup(sn, 'fieldbackground') or st.lookup(cls, 'fieldbackground')
                    if b:
                        want = _mix_to(f, b, w)
                        if want:
                            w.configure(foreground=want)
                            n += 1
            elif cls in ('TLabel', 'TCheckbutton', 'TRadiobutton') and st is not None:
                f = str(w.cget('foreground') or '')
                if f:
                    sn = str(w.cget('style')) or cls
                    b = st.lookup(sn, 'background') or st.lookup(cls, 'background')
                    if b:
                        want = _mix_to(f, b, w)
                        if want:
                            w.configure(foreground=want)
                            n += 1
        except Exception:
            pass
    return n


def _is_default(v):
    """OS 가 정해 준 기본값인가 — 화면이 일부러 선택한 색이 아니다."""
    v = (v or '').strip()
    return v.lower().startswith('system') or v in ('', 'SystemWindowText')


def apply_ttk(root=None):
    """ttk 위젯 전부에 지금 테마를 건다. 스타일은 인터프리터 전역이다.

    ★ **`ttk` 위젯에는 `bg`/`fg` 옵션이 아예 없다** (2026-08-13 실측).
      그래서 `paint()` 의 훑기가 **구조적으로 닿을 수 없다** — `ttk.Frame`·`Label`·
      `Button`·`Combobox`·`Treeview`·`PanedWindow` 는 오직 여기를 통해서만 바뀐다.
      사용자가 「일일이 지적하는 게 의미없다」며 든 자리가 전부 이것이었다
      (콤보 접힌 칸 · 묵상플랜/도서설교 왼쪽 패널 · 목록 아래 빈 공간 ·
       공지 버튼 · 정보 탭 글자색).

    ★ **그리고 윈도우 `vista` 테마는 색 설정을 조용히 무시한다** — OS 가 직접
      그리기 때문이다. `style.lookup` 은 넣은 값을 그대로 돌려주므로 **설정만 보면
      다 된 것처럼 보인다.** 실제로 그래서 몇 차례 헛짚었다.
      ⇒ **`clam` 으로 갈아탄다.** 요소 하나씩 빌려 오는 방법(예전 `_borrow_clam`)은
        탭에서는 통했지만 위젯 수십 종에는 대지 못한다.
      ⚠ 대가 — 위젯 생김새가 조금 납작해진다. 색이 통째로 안 먹는 것보다 낫다는
        판단이고, 네 계열 전부에 같은 모양이 걸린다.
    """
    from tkinter import ttk
    st = ttk.Style(root) if root is not None else ttk.Style()
    try:
        if st.theme_use() != 'clam':
            st.theme_use('clam')
    except Exception as e:
        print(f'[ui_theme.apply_ttk] clam 전환 실패: {e}')

    bg, fg = C('bg'), C('fg')
    panel, alt, bd = C('panel'), C('panel_alt'), C('border')
    sel, dim = C('select_bg'), C('fg_dim')

    # 뿌리 스타일 — 이름 없는 ttk 위젯이 전부 여기를 따른다
    st.configure('.', background=bg, foreground=fg, fieldbackground=bg,
                 bordercolor=bd, darkcolor=panel, lightcolor=panel,
                 troughcolor=alt, arrowcolor=fg, insertcolor=fg,
                 selectbackground=sel, selectforeground=fg, focuscolor=C('accent'))

    st.configure('TFrame', background=bg)
    st.configure('TLabel', background=bg, foreground=fg)
    st.configure('TLabelframe', background=bg, bordercolor=bd)
    st.configure('TLabelframe.Label', background=bg, foreground=C('fg_title'))
    st.configure('TPanedwindow', background=bg)
    st.configure('Sash', background=alt, bordercolor=bd)
    st.configure('TSeparator', background=bd)
    st.configure('TSizegrip', background=bg)

    st.configure('TButton', background=panel, foreground=fg,
                 bordercolor=bd, lightcolor=panel, darkcolor=panel, relief='flat')
    st.map('TButton', background=[('pressed', alt), ('active', alt)],
           foreground=[('disabled', dim)])

    for s in ('TCheckbutton', 'TRadiobutton'):
        st.configure(s, background=bg, foreground=fg, indicatorcolor=C('bg'))
        st.map(s, background=[('active', panel)],
               indicatorcolor=[('selected', C('accent'))],
               foreground=[('disabled', dim)])

    st.configure('TEntry', fieldbackground=bg, foreground=fg,
                 bordercolor=bd, lightcolor=bd, darkcolor=bd, insertcolor=fg)
    # ★ 2026-10-27 (docs/1.txt 14-1) 막힌 입력칸 글자 — clam 기본 #999999 가 밝은 화면에서 대비 2.3 이었다(값을 보이는 칸이라 읽혀야 한다)
    st.map('TEntry', fieldbackground=[('readonly', panel), ('disabled', panel)],
           foreground=[('disabled', C('fg_label'))])

    # ⚠ 콤보는 **접힌 칸**(field)과 **펼친 목록**(popdown)이 따로다.
    #   목록은 자식 위젯이 아니라 `paint()` 의 `_paint_extra` 가 맡는다.
    st.configure('TCombobox', fieldbackground=bg, foreground=fg,
                 background=panel, bordercolor=bd, arrowcolor=fg,
                 lightcolor=bd, darkcolor=bd, insertcolor=fg)
    st.map('TCombobox',
           fieldbackground=[('readonly', bg), ('disabled', panel)],
           foreground=[('readonly', fg), ('disabled', dim)],
           background=[('readonly', panel), ('active', alt)],
           arrowcolor=[('disabled', dim)])

    st.configure('TSpinbox', fieldbackground=bg, foreground=fg,
                 background=panel, bordercolor=bd, arrowcolor=fg)
    st.configure('TScrollbar', background=panel, troughcolor=alt,
                 bordercolor=bd, arrowcolor=fg)
    st.map('TScrollbar', background=[('active', alt)])
    st.configure('TProgressbar', background=C('accent'), troughcolor=alt,
                 bordercolor=bd)
    st.configure('TScale', background=bg, troughcolor=alt)

    # 표 — **행이 없는 아래쪽 빈 공간이 `fieldbackground`** 다(사용자 지적 4번)
    st.configure('Treeview', background=bg, fieldbackground=bg, foreground=fg,
                 bordercolor=bd, lightcolor=bg, darkcolor=bg, relief='flat')
    st.configure('Treeview.Heading', background=panel, foreground=fg,
                 bordercolor=bd, relief='flat')
    st.map('Treeview', background=[('selected', sel)],
           foreground=[('selected', fg)])
    st.map('Treeview.Heading', background=[('active', alt)])

    # ★ **전용 스타일 전부** — 그 화면이 아직 안 지어졌어도 미리 칠한다 (2026-08-16)
    for stl in sorted(KNOWN_STYLES):
        try:
            conf, mp = _style_for(stl.split('.')[-1])
            st.configure(stl, **conf)
            if mp:
                st.map(stl, **mp)
            if stl.endswith('.Treeview'):
                st.configure(stl + '.Heading', background=panel, foreground=fg,
                             relief='flat')
            elif stl.endswith('.TNotebook'):
                st.configure(stl + '.Tab', background=alt, foreground=fg,
                             padding=(10, 3), borderwidth=1)
                st.map(stl + '.Tab',
                       background=[('selected', C('dark_bg')), ('active', bd)],
                       foreground=[('selected', C('fg_on_dark')), ('active', fg)])
        except Exception:
            pass

    # ★ **콤보를 펼쳤을 때 나오는 목록은 `Listbox` 다** — ttk 가 아니라서
    #   `Style` 이 닿지 않는다. 검은 테마에서도 흰 채로 남던 자리다(2026-08-16).
    #   `option_add` 말고는 손이 닿지 않는다.
    if root is not None:
        for opt, val in (('*TCombobox*Listbox.background', bg),
                         ('*TCombobox*Listbox.foreground', fg),
                         ('*TCombobox*Listbox.selectBackground', sel),
                         ('*TCombobox*Listbox.selectForeground', fg)):
            try:
                root.option_add(opt, val)
            except Exception:
                pass

    apply_notebook_tabs(root)
    return True


# ★ **전용 스타일 이름** (2026-08-16).
#   `_paint_style` 은 살아 있는 위젯을 통해서만 스타일에 닿는다. 지연 빌드로 아직
#   안 지어진 화면의 스타일은 영영 안 칠해져 **테마를 바꿔도 그 표만 흰 채로 남는다**
#   (실측: `Enr.Treeview` 가 밝은/검은 테마 양쪽 다 `#EBF5FB`).
#   ⇒ 이름을 미리 알아 두고 `apply_ttk` 가 전부 칠한다. 스타일은 위젯이 없어도 존재한다.
#   ⚠ 손으로 적은 목록만 두면 새 화면이 또 빠진다 — `_paint_style` 이 본 것을 더한다.
KNOWN_STYLES = {
    'BM.Treeview', 'CM.Treeview', 'DM.Treeview', 'EB.Treeview', 'EP.Treeview',
    'Enr.Treeview', 'Kids.Treeview', 'Lens.Treeview', 'PL.Treeview',
    'PM.Treeview', 'Peri.Treeview', 'Plan.Treeview', 'Reading.Treeview',
    'Center.TNotebook',
}


def _style_for(base):
    """그 밑바탕 스타일에 넣을 값. **파생 스타일에도 같은 것을 먹인다.**

    ★ 화면들이 `Plan.Treeview`·`Reading.Treeview`·`EB.Treeview`·`Lens.Treeview`·
      `Center.TNotebook` 처럼 **전용 스타일을 만들어 흰색을 직접 박아 둔다**
      (2026-08-13 사용자 지적 「왼쪽 패널이 여전히 흰색」의 진짜 원인).
      ttk 는 파생 스타일에 **명시된 값이 밑바탕을 이기므로**, `Treeview` 를 칠해도
      그 화면만 흰 채로 남는다. ⇒ 파생 스타일도 찾아서 같이 칠한다.
    """
    bg, fg = C('bg'), C('fg')
    panel, alt, bd = C('panel'), C('panel_alt'), C('border')
    if base == 'Treeview':
        return (dict(background=bg, fieldbackground=bg, foreground=fg,
                     bordercolor=bd, lightcolor=bg, darkcolor=bg, relief='flat'),
                dict(background=[('selected', C('select_bg'))],
                     foreground=[('selected', fg)]))
    if base == 'TNotebook':
        return (dict(background=bg, bordercolor=bd,
                     lightcolor=bg, darkcolor=bg), None)
    if base == 'TFrame':
        return (dict(background=bg), None)
    if base == 'TLabel':
        return (dict(background=bg, foreground=fg), None)
    if base == 'TButton':
        return (dict(background=panel, foreground=fg, bordercolor=bd,
                     lightcolor=panel, darkcolor=panel), None)
    if base in ('TEntry', 'TCombobox'):
        return (dict(fieldbackground=bg, foreground=fg, bordercolor=bd), None)
    return (dict(background=bg, foreground=fg), None)


def _paint_style(w):
    """이 위젯이 **전용 스타일**을 쓰면 그 스타일도 지금 테마로 칠한다."""
    try:
        stl = str(w.cget('style') or '')
    except Exception:
        return 0
    if not stl or '.' not in stl:
        return 0
    # ⚠ **한 번 칠했다고 건너뛰면 안 된다.** 늦게 만들어지는 화면(지연 빌드)이
    #   자기 스타일을 **그 뒤에** 하드코딩으로 다시 잡아 버린다 — 주요용어 서브탭이
    #   실제로 그랬다(`Center.TNotebook.Tab` 이 푸른색으로 되돌아왔다).
    #   스타일 설정은 값싸므로 볼 때마다 다시 건다. `seen` 은 세는 용도로만 둔다.
    seen = _paint_style.seen
    base = stl.split('.')[-1]
    conf, mp = _style_for(base)
    try:
        from tkinter import ttk
        st = ttk.Style(w)
        st.configure(stl, **conf)
        if mp:
            st.map(stl, **mp)
        if base == 'TNotebook':
            # 서브탭 **머리글**도 파생된다 (사용자 지적 「서브탭 헤더 바탕색이 흰색」)
            st.configure(stl + '.Tab', background=C('panel_alt'),
                         foreground=C('fg'), padding=(10, 3), borderwidth=1)
            st.map(stl + '.Tab',
                   background=[('selected', C('dark_bg')), ('active', C('border'))],
                   foreground=[('selected', C('fg_on_dark')), ('active', C('fg'))])
        if base == 'Treeview':
            st.configure(stl.replace('.Treeview', '.Treeview.Heading'),
                         background=C('panel'), foreground=C('fg'), relief='flat')
        seen.add(stl)
        KNOWN_STYLES.add(stl)      # 다음 테마 전환 때는 위젯이 없어도 칠한다
        return 1
    except Exception:
        return 0


_paint_style.seen = set()


def forget_styles():
    """테마를 바꿀 때 **다시 칠하도록** 기억을 비운다."""
    _paint_style.seen = set()


_ADOPT = '_hagah_adopted'


def adopt(win):
    """새로 뜬 창에 지금 테마·글꼴을 입힌다. **멱등**.

    ★ 팝업은 `paint` 가 닿지 않아 `SystemButtonFace`(#F0F0F0) 로 남는다.
      실측(2026-08-16) — 기적묵상 팝업의 창 바탕과 캔버스가 그랬고, `paint` 한 번에
      9곳이 고쳐졌다. 사용자 앱 팝업 파일 20개 중 스스로 테마를 걸던 것은 2개뿐이었다.

    ⚠ **한 번만 입힌다.** 테마 이름을 창에 적어 두고 같으면 건너뛴다 — 창을 다시
      보일 때마다 전수 훑기가 돌면 느리다.
    """
    if getattr(win, _ADOPT, None) == _active:
        return 0
    n = 0
    try:
        n = paint(win)
        try:
            import theme_font
            theme_font.scale(win)
        except Exception:
            pass
        setattr(win, _ADOPT, _active)
        # ★★ 317차-12 — **내용을 다 지은 뒤 한 번 더 칠한다.** 팝업 17곳이 창을 만들자마자(아직 빈 창일 때)
        #   이 문을 불러, 그 뒤에 지은 글상자·체크상자·단추가 시스템 기본색(흰 바탕 · 밝은 체크)으로 남았다
        #   (사용자 「팝업 각 화면마다 글자의 배경색이 제멋대로」 · 검정 테마 실측). 부르는 자리를 하나하나
        #   옮기면 새 팝업이 또 빠뜨린다 — **여기 한 곳에서** 지금 짓는 일이 끝난 다음(after_idle)에 칠한다.
        try:
            win.after_idle(lambda w=win: _late_paint(w))
        except Exception:
            pass
    except Exception as e:
        print('[adopt] %s' % e)
    return n


def _late_paint(win):
    try:
        if win.winfo_exists():
            paint(win)
    except Exception:
        pass


# ★★★ 317차-21 (docs/1.txt 50-1) — **목록 상자 아래 빈 곳을 누르면 아무 일도 없다.**
#   사용자 「대화목록의 아래 빈 공간을 클릭하면 가장 아래 대화목록을 클릭한 것과 동일하게 팝업을
#   작동시킨다 · 이전에도 목록 아래 빈 공간이 작동한 적이 있었다 · 절대로 하지 마라」.
#   ⚠ 까닭은 Tk Listbox 의 기본 동작이다 — 빈 곳을 누르면 **가장 가까운 줄(= 마지막 줄)**을 고르고
#     <<ListboxSelect>> 를 낸다. 앱에 목록 상자가 68곳이라 화면마다 고치면 하나가 반드시 빠진다
#     ⇒ **만들어지는 모든 Listbox 에** 위젯 차례 바인딩(클래스 바인딩보다 먼저 돈다)을 붙인다.
#   ⚠ 고른 것을 풀지도 않는다 — 그냥 아무 일도 없게 한다.
def _lb_below(e):
    lb = e.widget
    try:
        n = int(lb.size())
        if n <= 0:
            return 'break'
        bb = lb.bbox(n - 1)
        if bb is not None and e.y > bb[1] + bb[3]:
            return 'break'
    except Exception:                                     # noqa: BLE001
        pass
    return None


_LB_GUARDED = [False]


def guard_listboxes():
    """앱 시작에 한 번 — 이후 만들어지는 모든 `tk.Listbox` 가 빈 곳 클릭을 무시한다(멱등)."""
    if _LB_GUARDED[0]:
        return
    import tkinter as _tk
    _orig = _tk.Listbox.__init__

    def _init(self, *a, **k):
        _orig(self, *a, **k)
        for seq in ('<Button-1>', '<Double-Button-1>', '<B1-Motion>'):
            try:
                self.bind(seq, _lb_below, add='+')
            except Exception:                             # noqa: BLE001
                pass
    _tk.Listbox.__init__ = _init
    _LB_GUARDED[0] = True


def apply_all(db_path, root):
    """선택한 테마를 **한 번에** 건다 — ttk + 지금 떠 있는 위젯 전부."""
    apply_ttk(root)
    return paint(root)


# ── 탭 색 (2026-08-10 사용자 지시) ───────────────────────────────────────────
# 「지금 보고 있는 탭이 너무 미미하게 밝아서 어느 탭인지 눈에 안 들어온다.」
#
# ⚠ 윈도우 기본 테마(vista/winnative)에서는 `TNotebook.Tab` 의 background 가
#    **조용히 무시된다.** 탭을 OS 테마 엔진이 그리기 때문이다. 색을 넣어도 아무 일이
#    안 일어나고, 오류도 안 난다 — 그래서 「했는데 안 보인다」가 된다.
#    그렇다고 테마를 통째로 clam 으로 바꾸면 앱 전체 위젯 모양이 달라진다.
#    ⇒ **clam 의 탭 요소 하나만 빌려 와 레이아웃에 끼운다.** 나머지는 그대로 둔다.
_TAB_ELEMENT = 'HagahTab.tab'


# ── 체크 표시 — clam 은 X 를 그린다 ─────────────────────────────────────────
_CHECK_IMGS = {}


# ═══════════════════════════════════════════════════════════════════════
#  편집 칸 색 — 「고칠 수 있나」를 바탕색이 말한다 (2026-09-25)
# ═══════════════════════════════════════════════════════════════════════
#
# 사용자 「내가 수정가능한 텍스트 상자는 **바탕색을 밝은 색으로 고정**하라.
#   회색도 있고 흰색도 있어서 혼란스럽다. **수정해도 된다는 것인지 애매하다**」.
#
# ★★★ **원인은 Tk 의 성질이다 — 규칙을 지켜도 안 갈린다.**
#   `tk.Text` 는 `state='disabled'` 로 막아도 **바탕이 흰색 그대로**다
#   (글자만 회색). 반면 `ttk.Entry` 는 회색이 된다. 그래서 흰 바탕 칸 중에
#   고칠 수 있는 것과 없는 것이 섞인다. 실측 관리자 `tk.Text` **106칸**.
#
# ★★★ **자리마다 고치지 않는다** — 40파일 106칸을 쫓으면 반드시 몇이 빠지고,
#   빠진 자리는 아무 표시 없이 옛 모습으로 남는다(§272차 ⑥ `lang_ui.retrofit`
#   과 같은 판단). ⇒ **창을 훑어 한 번에 걸고, `state` 가 바뀌면 따라온다.**
#
# ⚠ **`configure` 를 감싸는 까닭** — 읽기 전용 칸은 글을 넣을 때만 잠깐
#   `normal` 이 되었다가 되돌아간다(실측 `_prev`·`_rv_src`·`_rv_gate`).
#   한 번 칠하고 마는 방식으로는 그 칸이 영영 흰색으로 굳는다.
# ⚠ **덮어쓰지 않는다** — 화면이 제 손으로 `bg=` 를 준 칸(경고 빨강 등)은
#   그대로 둔다(`_EDIT_SKIP_BG`).

_EDIT_MARK = '_ui_edit_hooked'
# 화면이 뜻을 담아 준 바탕색 — 건드리면 그 뜻이 사라진다
_EDIT_SKIP_BG = ('#FFF0F0', '#FFFBE6', '#FDEDEC', '#FEF9E7', '#EAF2F8')


def _edit_kind(w):
    """그 칸이 지금 **고칠 수 있나** — `True`/`False`/`None`(잴 수 없다)."""
    try:
        st = str(w.cget('state') or '').lower()
    except Exception:                                     # noqa: BLE001
        return None
    if st in ('disabled',):
        return False
    if st in ('readonly',):
        # ⚠ 읽기전용 **콤보**는 고르는 칸이라 편집 쪽이다 — 값을 바꿀 수 있다.
        return w.winfo_class() in ('TCombobox', 'Combobox')
    return True


def _paint_edit_one(w):
    """한 칸에 색을 입힌다. `tk` 위젯만 — `ttk` 는 스타일이 맡는다."""
    if w.winfo_class() not in ('Text', 'Entry', 'Listbox', 'Spinbox'):
        return False
    try:
        cur = str(w.cget('background') or '').upper()
    except Exception:                                     # noqa: BLE001
        return False
    if cur in _EDIT_SKIP_BG:
        return False
    k = _edit_kind(w)
    if k is None:
        return False
    want = C('edit_bg' if k else 'view_bg')
    if not want or cur == want.upper():
        return False
    try:
        w.configure(background=want)
    except Exception:                                     # noqa: BLE001
        return False
    return True


def _hook_edit(w):
    """`state` 가 바뀌면 색이 따라오게 — 위젯의 `configure` 를 한 번 감싼다."""
    if getattr(w, _EDIT_MARK, False):
        return
    try:
        setattr(w, _EDIT_MARK, True)
    except Exception:                                     # noqa: BLE001
        return
    orig = w.configure

    def wrapped(cnf=None, **kw):
        r = orig(cnf, **kw) if cnf is not None else orig(**kw)
        try:
            touched = ('state' in kw) or (isinstance(cnf, dict)
                                          and 'state' in cnf)
            if touched:
                _paint_edit_one(w)
        except Exception:                                 # noqa: BLE001
            pass
        return r

    try:
        w.configure = wrapped
        w.config = wrapped
    except Exception:                                     # noqa: BLE001
        pass


_EDIT_CLASSES = ('Text', 'Entry', 'Listbox', 'Spinbox')


def bind_edit_class(root):
    """**화면에 올라오는 순간** 건다 — 지연 빌드된 칸까지 빠짐없이.

    ⚠⚠⚠ `retrofit_edits` 를 패널 만든 뒤 한 번만 부르면 **서브탭 안쪽을
      놓친다** — 관리자 화면은 서브탭을 처음 열 때 짓는다(§29). 실측
      `research_mgr` 의 본문 칸 둘이 그렇게 빠졌다.
    ★ `<Map>` 은 자주 오지만 걸어 두는 일도 칠하는 일도 **멱등**이라
      값이 그대로면 아무 일도 안 한다(§256차 ⑰ 의 끝없는 고리를 피한다 —
      색을 바꾸는 것은 배치를 안 건드리므로 `<Map>` 을 다시 내지 않는다).
    ⚠ `bind_class(..., add='+')` — 남이 건 것을 안 걷는다.
    """
    def _on_map(ev):
        try:
            w = ev.widget
            _hook_edit(w)
            _paint_edit_one(w)
        except Exception:                                 # noqa: BLE001
            pass
    for cls in _EDIT_CLASSES:
        try:
            root.bind_class(cls, '<Map>', _on_map, add='+')
        except Exception:                                 # noqa: BLE001
            pass


def retrofit_edits(root):
    """창 안의 편집 칸에 색을 입히고 **앞으로도 따라오게** 한다.

    ⚠ 화면 만든 뒤에 **한 번** 부른다. 여러 번 불러도 안 겹친다(멱등).
    ⚠ 지연 빌드는 이것만으로 못 잡는다 — `bind_edit_class` 를 함께 건다.
    ⚠ `ttk.Entry`·`ttk.Spinbox` 는 `apply_ttk` 의 스타일이 맡으므로
      여기서는 `tk` 위젯만 본다 — 두 곳에서 칠하면 갈린다.
    """
    n = 0
    stack = [root]
    while stack:
        w = stack.pop()
        try:
            stack.extend(w.winfo_children())
        except Exception:                                 # noqa: BLE001
            pass
        try:
            if w.winfo_class() in ('Text', 'Entry', 'Listbox', 'Spinbox'):
                _hook_edit(w)
                if _paint_edit_one(w):
                    n += 1
        except Exception:                                 # noqa: BLE001
            pass
    return n


def apply_check_indicator(root=None) -> bool:
    """`ttk.Checkbutton` 의 표시를 **✓ 로**(2026-09-16 · 1.txt 17-4 사용자 「필터규칙
    팝업: 체크박스가 x표를 하고 있다. 해당하면 체크하라는 것인지 미해당일때 체크하라는
    것인지 혼란스럽다. v체크 또는 Yes 표시를 하라」).

    ★ 실측(화면을 찍어 견줌) — clam 테마의 체크 표시는 **X** 이고 윈도우 기본
      (`tk.Checkbutton`)은 ✓ 다. 앱이 탭 색 때문에 clam 을 쓰므로(§apply_ttk) 앱의
      모든 ttk 체크박스가 X 였다. 표시 요소를 **그림**으로 갈아 끼운다 —
      네모 + ✓ 를 테마 색으로 그때그때 그린다(파일·PIL 없이 `PhotoImage.put`).
    ⚠ 그림은 모듈 변수에 붙들어 둔다 — 놓치면 Tk 가 지워 빈 네모가 된다.
    ⚠ `element_create` 는 한 번만 된다 — 이름이 있으면 스타일 map 만 다시 건다.
    """
    import tkinter as tk
    from tkinter import ttk
    st = ttk.Style(root) if root is not None else ttk.Style()
    N = 13
    border, fill, mark, dis = C('border') or '#8A8A8A', C('bg') or '#FFFFFF', C('accent') or '#1A5276', C('fg_dim') or '#9A9A9A'

    def _img(checked, disabled=False):
        im = tk.PhotoImage(width=N, height=N)
        b = dis if disabled else border
        rows = []
        for y in range(N):
            row = []
            for x in range(N):
                row.append(b if (x in (0, N - 1) or y in (0, N - 1)) else fill)
            rows.append(row)
        if checked:
            m = dis if disabled else mark
            # ✓ — 왼쪽 아래로 내려갔다 오른쪽 위로 길게 (두께 2)
            pts = [(3, 6), (4, 7), (5, 8), (6, 9), (7, 8), (8, 7), (9, 6), (10, 5), (11, 4)]
            for (x, y) in pts:
                for dy in (0, 1):
                    if 0 < x < N - 1 and 0 < y + dy < N - 1:
                        rows[y + dy][x] = m
        im.put(' '.join('{' + ' '.join(r) + '}' for r in rows))
        return im
    key = _active
    imgs = {'off': _img(False), 'on': _img(True), 'off_d': _img(False, True), 'on_d': _img(True, True)}
    _CHECK_IMGS[key] = imgs             # 붙들어 둔다
    try:
        st.element_create('Hagah.Check.indicator', 'image', imgs['off'],
                          ('disabled', 'selected', imgs['on_d']),
                          ('disabled', imgs['off_d']),
                          ('selected', imgs['on']),
                          sticky='', padding=(0, 0, 4, 0))
    except Exception as e:
        # 이미 있으면(테마 바꿈) 그림만 갈아 끼운다 — 요소는 새로 못 만든다
        if 'Duplicate' not in str(e) and 'already' not in str(e):
            print('[ui_theme.apply_check_indicator] %s' % e)
            return False
        try:
            # 같은 PhotoImage 이름을 쓰는 요소라 그림을 그 자리에서 고쳐 넣는다
            for k2, im in imgs.items():
                old = _CHECK_IMGS.get('_first', {}).get(k2)
                if old is not None:
                    old.blank()
                    old.copy_from = None
                    old.tk.call(old, 'copy', im)
            imgs = _CHECK_IMGS.get('_first', imgs)
        except Exception:
            pass
    if '_first' not in _CHECK_IMGS:
        _CHECK_IMGS['_first'] = imgs
    try:
        st.layout('TCheckbutton', [
            ('Checkbutton.padding', {'sticky': 'nswe', 'children': [
                ('Hagah.Check.indicator', {'side': 'left', 'sticky': ''}),
                ('Checkbutton.focus', {'side': 'left', 'sticky': 'w', 'children': [
                    ('Checkbutton.label', {'sticky': 'nswe'})]})]})])
    except Exception as e:
        print('[ui_theme.apply_check_indicator layout] %s' % e)
        return False
    return True


def apply_notebook_tabs(root=None) -> bool:
    """모든 `ttk.Notebook` 의 탭 색을 지금 테마로. 멱등.

    ⚠ 예전에는 여기서 **clam 의 탭 요소만 빌려 와** 끼웠다 — 윈도우 기본 테마가
      탭 색을 무시했기 때문이다. 2026-08-13 부터 `apply_ttk` 가 아예 clam 을 쓰므로
      빌려 올 것이 없다. **빌리는 코드를 되살리지 말 것** — clam 위에서 그렇게 하면
      요소가 자기 자신에서 파생돼 이상해진다.
    """
    from tkinter import ttk
    st = ttk.Style(root) if root is not None else ttk.Style()
    ok = True
    # ⚠ **clam 이 아니면 탭 배경이 조용히 무시된다** — 그런데 글자색은 먹어서
    #   **흰 바탕에 흰 글자**가 된다(2026-08-15 관리자 앱에서 실제로 그랬다).
    #   실측 — vista 에서 진한 파랑 픽셀 0개, clam 에서 1,595개.
    #   여기서 갈아타 준다. 부르는 쪽이 `apply_ttk` 를 잊어도 탭은 살아야 한다.
    try:
        if st.theme_use() != 'clam':
            print('[ui_theme.apply_notebook_tabs] 탭 색이 먹으려면 clam 이어야 한다 '
                  '— 갈아탄다 (지금: %s)' % st.theme_use())
            st.theme_use('clam')
    except Exception as e:
        print(f'[ui_theme.apply_notebook_tabs] clam 전환 실패: {e}')
        ok = False
    st.configure('TNotebook', background=C('bg'), bordercolor=C('border'),
                 lightcolor=C('bg'), darkcolor=C('bg'))
    st.configure('TNotebook.Tab', background=C('panel_alt'),
                 foreground=C('fg'), padding=(10, 3), borderwidth=1)
    # ★★ **잠긴 탭(disabled)을 갈라 준다** (2026-08-29 사용자 신고 —
    #   「다크모드에서 **비활성화된 탭의 모양이 차이가 없다**」).
    #   `map` 에 `disabled` 가 없으면 `configure` 값이 그대로 쓰여 잠긴 탭이
    #   보통 탭과 **똑같이** 보인다. 밝은 테마에서는 우연히 구별됐다.
    #   ⚠ **`disabled` 를 `selected` 보다 앞에** 둔다 — ttk 는 앞에서부터
    #     맞는 것을 쓰므로, 뒤에 두면 고른 탭이 잠겨도 선택 색으로 그려진다.
    st.map('TNotebook.Tab',
           background=[('disabled', C('bg')),
                       ('selected', C('dark_bg')), ('active', C('border'))],
           foreground=[('disabled', C('fg_dim')),
                       ('selected', C('fg_on_dark')), ('active', C('fg'))],
           expand=[('selected', [1, 1, 1, 0])])
    try:
        apply_check_indicator(root)      # 체크 표시 ✓ (clam 은 X 다 — 2026-09-16)
    except Exception as _e:
        print('[ui_theme.apply_notebook_tabs] check indicator: %s' % _e)
    return ok


# ── 자가 검증 ────────────────────────────────────────────────────────────────

def _selftest_palette():
    """모든 테마의 팔레트 색이 제 역할로 되돌아오는가 (2026-08-16 신설).

    ⚠ 이 검사가 없으면 팔레트를 늘렸을 때 **조용히** 다시 굳는다.
    """
    ok = True
    miss = []
    for th, pal in PALETTE.items():
        for role, v in pal.items():
            if not v:
                continue
            is_bg = role in _BG_ROLES
            if role not in _BG_ROLES and role not in _FG_ROLES:
                continue
            got = _pal_role(v, is_bg)
            if got is None:
                miss.append((th, role, v))
    if miss:
        print('FAIL 역할로 못 되돌리는 팔레트 색 %d개 — 예: %s' % (len(miss), miss[:3]))
        ok = False
    # 바탕과 글자를 갈라 보는가 — 합치면 어두운 바 위 흰 글자가 뒤집힌다
    for th, pal in PALETTE.items():
        fg_on_dark = (pal.get('fg_on_dark') or '').upper()
        if fg_on_dark and _pal_role(fg_on_dark, True) == 'fg_on_dark':
            print('FAIL 글자색이 바탕 역할로 잡힌다:', th, fg_on_dark)
            ok = False
            break
    # 강조색을 바탕으로 쓴 자리가 잡히는가
    for th, pal in PALETTE.items():
        for role, twin in _BG_TWIN.items():
            v = pal.get(role)
            if v and _pal_role(v, True) is None:
                print('FAIL %s 의 %s(%s) 를 바탕으로 쓰면 못 잡는다' % (th, role, v))
                ok = False
                break

    # 2026-08-16 에 보탠 장식색이 살아 있는가 — 빠지면 그 화면만 흰 채로 남는다
    for c, want in (('#2471A3', 'dark_bg'), ('#6C3483', 'dark_bg'),
                    ('#4A235A', 'dark_bg'), ('#2E4053', 'dark_bg'),
                    ('#FBF7E0', 'warning_bg'), ('#D4EFDF', 'success_bg'),
                    ('#FFFEF8', 'bg'), ('#F7F9F9', 'bg')):
        if ROLE_OF_BG.get(c) != want:
            print('FAIL %s 가 %s 로 안 잡힌다 (지금 %s)'
                  % (c, want, ROLE_OF_BG.get(c)))
            ok = False

    # 전용 스타일 목록이 비면 위 고침이 통째로 죽는다
    if len(KNOWN_STYLES) < 10:
        print('FAIL 전용 스타일 목록이 비었다 — 그 화면들이 다시 흰색으로 남는다')
        ok = False
    print('palette selftest', 'OK' if ok else 'FAIL', '(%d색 · 전용스타일 %d개)'
          % (len(PAL_BG | PAL_FG), len(KNOWN_STYLES)))
    return ok


def _selftest():
    bad = []

    # ① 네 테마가 역할을 빠짐없이 갖는가
    for name, p in PALETTE.items():
        miss = [r for r in ROLES if r not in p]
        if miss:
            bad.append(f'{name} 에 빠진 역할: {miss}')

    # ② 바탕과 글자가 같은 색이면 글자가 사라진다
    for name, p in PALETTE.items():
        for b, f in (('bg', 'fg'), ('panel', 'fg'), ('success_bg', 'success'),
                     ('danger_bg', 'danger'), ('warning_bg', 'warning'),
                     ('dark_bg', 'fg_on_dark')):
            if p[b].upper() == p[f].upper():
                bad.append(f'{name}: {b} 와 {f} 가 같은 색이다')

    # ③ ★ 계열 규칙을 **모든 벌**에 건다 (손으로 적지 않는 이유가 이것이다)
    for k, fam, _n, _h, _s, _l, dark in _SPEC:
        p = PALETTE[k]
        if dark:
            if p['bg'].upper() in ('#000000', '#000'):
                bad.append(f'{k}: 바탕이 순흑이다 — 밤에 눈이 아프다')
            if p['fg'].upper() in ('#FFFFFF', '#FFF'):
                bad.append(f'{k}: 글자가 순백이다 — 번져 보인다')
            # ⚠ 바탕은 0.35 아래, 층(panel)은 조금 더 여유 — 「흐린 먹」처럼 밝은
            #   어두운 벌은 층이 0.4 근처가 정상이다.
            if _lum(p['bg']) > 0.35:
                bad.append(f'{k}: 바탕이 어둡지 않다')
            for r in ('panel', 'panel_alt'):
                if _lum(p[r]) > 0.46:
                    bad.append(f'{k}: {r} 가 어둡지 않다')
            if not 0.60 <= _lum(p['fg']) <= 0.90:
                bad.append(f'{k}: 글자가 밝은 회색 범위를 벗어났다')
        else:
            if _lum(p['fg']) > 0.3:
                bad.append(f'{k}: 밝은 벌인데 글자가 검지 않다 — 사용자 지정 위반')
            if _lum(p['bg']) < 0.7:
                bad.append(f'{k}: 밝은 벌인데 바탕이 어둡다')
        # 바탕과 글자가 붙어 있으면 못 읽는다 (밝기 차 최소 0.35)
        if abs(_lum(p['bg']) - _lum(p['fg'])) < 0.35:
            bad.append(f'{k}: 바탕과 글자의 밝기가 너무 가깝다')
        # 흐린 글자도 바탕에서 떨어져 있어야 한다
        if abs(_lum(p['bg']) - _lum(p['fg_dim'])) < 0.15:
            bad.append(f'{k}: 흐린 글자가 바탕에 묻힌다')
        # 층이 구분돼야 한다 (바탕 ≠ 패널 ≠ 테두리)
        if p['bg'].upper() == p['panel'].upper():
            bad.append(f'{k}: 바탕과 패널이 같은 색이다')

    # ③-2 ★ **회색·파랑이 흰색과 구분돼야 한다** (2026-08-13 사용자 지적
    #      「지금 회색 푸른색이 너무 연한 색이다」)
    w = _lum(PALETTE['WHITE']['bg'])
    for k in ('GREY', 'BLUE'):
        if w - _lum(PALETTE[k]['bg']) < 0.05:
            bad.append(f'{k} 가 흰색과 구분이 안 될 만큼 연하다')

    # ③-2b ★ **푸른색 계열은 실제로 푸르러야 한다.** 채도를 깎았더니 파랑 기본이
    #        `#DBE0E6`(거의 회색)으로 나온 적이 있다 — 계열 이름이 거짓말이 된다.
    def _tint(c):
        c = c.lstrip('#')
        return int(c[4:6], 16) - int(c[0:2], 16)      # 파랑 − 빨강

    for k in by_family('BLUE'):
        if _tint(PALETTE[k]['bg']) < 6:
            bad.append(f'{k}: 푸른색 계열인데 파란 기운이 없다')
    if _tint(PALETTE['BLUE']['bg']) < 15:
        bad.append('파랑 기본이 회색에 가깝다')
    if abs(_tint(PALETTE['GREY']['bg'])) > 12:
        bad.append('회색 기본이 너무 색을 띤다')

    # ③-2c ★ **갈색 계열은 붉은 기운이 있어야 한다** (회색과 안 갈리면 계열이 헛것이다)
    for k in by_family('BROWN'):
        if _tint(PALETTE[k]['bg']) > -6:
            bad.append(f'{k}: 갈색 계열인데 따뜻한 기운이 없다')

    # ③-2d ★ **같은 계열 안에서 벌끼리 눈으로 갈려야 한다**
    #        (2026-08-13 사용자 지적 「검은색 계열은 2~4번째가 비슷하다」 —
    #         먹빛·남색 검정이 검정과 밝기 차 0.03 뿐이었다)
    for fam in FAMILIES:
        ks = by_family(fam)
        for a, b in zip(ks, ks[1:]):
            gap = abs(_lum(PALETTE[a]['bg']) - _lum(PALETTE[b]['bg']))
            if gap < 0.035:
                bad.append(f'{a} 와 {b} 가 너무 닮았다 (밝기 차 {gap:.3f})')

    # ③-3 계열마다 3~5벌 (사용자 지시)
    for fam in FAMILIES:
        n = len(by_family(fam))
        if not 3 <= n <= 5:
            bad.append(f'{fam} 계열이 {n}벌이다 — 3~5벌이어야 한다')

    # ④ 색→역할 표가 실제로 뒤집히는가
    if ROLE_OF.get('#FAFAFA') != 'bg' or ROLE_OF.get('WHITE') != 'bg':
        bad.append('밝은 바탕색이 bg 로 안 잡힌다')
    if ROLE_OF.get('#1A5276') != 'fg_title':
        bad.append('진한 파랑 제목색이 fg_title 로 안 잡힌다')
    if '#A9DFBF' not in ROLE_OF or ROLE_OF['#A9DFBF'] == ROLE_OF.get('#1E8449'):
        bad.append('초록 버튼의 바탕과 글자가 같은 역할로 묶였다 — 글자가 사라진다')

    # ⑤ ★ paint 가 **가짜 위젯**으로 도는가 (Tk 를 띄우지 않는다)
    class _W:
        def __init__(self, bg=None, fg=None, kids=()):
            self._v = {}
            if bg:
                self._v['bg'] = bg
            if fg:
                self._v['fg'] = fg
            self._kids = kids

        def cget(self, o):
            if o not in self._v:
                raise Exception('no such option')
            return self._v[o]

        def configure(self, **kw):
            self._v.update(kw)

        def winfo_children(self):
            return self._kids

    global _active
    keep = _active
    try:
        leaf = _W(bg='#FAFAFA', fg='#888')
        root = _W(bg='white', kids=(leaf,))
        _active = 'BLACK'
        n = paint(root)
        if n < 3:
            bad.append(f'paint 가 바꾼 것이 너무 적다({n})')
        if _lum(leaf.cget('bg')) > 0.35:
            bad.append('BLACK 인데 바탕이 밝은 채로 남았다')
        # 되돌아오는가 — 원본을 기억하지 않으면 여기서 깨진다
        _active = 'WHITE'
        paint(root)
        if root.cget('bg').upper() != PALETTE['WHITE']['bg'].upper():
            bad.append('테마를 되돌렸는데 원본에서 다시 번역하지 못했다')
        # 표에 없는 색은 그대로
        odd = _W(bg='#123456')
        paint(odd)
        if odd.cget('bg') != '#123456':
            bad.append('표에 없는 색을 함부로 바꿨다')

        # ⑥ ★ 바탕만 있고 글자는 OS 기본인 위젯 — **검은 바탕에 검은 글자**가 되면 안 된다
        _active = 'BLACK'
        w = _W(bg='#FAFAFA', fg='SystemWindowText')
        paint(w)
        if _lum(w.cget('fg')) < 0.4:
            bad.append('어두운 바탕인데 글자가 OS 기본(검정)으로 남았다')
        # 화면이 **일부러 고른** 글자색은 건드리지 않는다
        w2 = _W(bg='#FAFAFA', fg='#E74C3C')
        paint(w2)
        if w2.cget('fg').upper() == C('fg').upper():
            bad.append('일부러 선택한 글자색을 덮어썼다')

        # ⑥-2 ★ **버튼 반전** — 화면이 누른 뒤 색을 갈아 끼우면 그것을 새 원본으로 받는다
        #      (안 그러면 되돌려 버려 「고른 표시」가 사라진다)
        _active = 'BLACK'
        b = _W(bg='white', fg='#2C3E50')
        paint(b)                                  # 안 고른 상태
        off = b.cget('bg')
        b.configure(bg='#D6EAF8')                 # 화면이 「고름」으로 갈아 끼웠다
        paint(b)
        on = b.cget('bg')
        if on == '#D6EAF8':
            bad.append('반전 색을 테마로 번역하지 않았다')
        if on == off:
            bad.append('선택한 버튼과 안 선택한 버튼이 같은 색이 됐다')
        if _lum(on) > 0.5:
            bad.append('어두운 테마인데 선택한 버튼이 밝다')

        # ⑦ ★ 같은 색이라도 **바탕이면 어두운 머리띠**다 (검정 테마에서 밝아지면 안 된다)
        hd = _W(bg='#1A5276', fg='white')
        paint(hd)
        if _lum(hd.cget('bg')) > 0.35:
            bad.append('어두운 머리띠 바탕이 검정 테마에서 밝아졌다')
        if _lum(hd.cget('fg')) < 0.4:
            bad.append('머리띠 위 글자가 어두워져 안 보인다')
        # 같은 색이 **글자**면 제목색이어야 한다
        ttl = _W(bg='white', fg='#1A5276')
        paint(ttl)
        if ttl.cget('fg').upper() != C('fg_title').upper():
            bad.append('글자로 쓴 진한 파랑이 제목색으로 안 갔다')
    finally:
        _active = keep

    print('ui_theme selftest: ' + ('OK' if not bad else 'FAIL'))
    for b in bad:
        print('  X', b)
    return 1 if bad else 0


def _lum(c):
    """대충의 밝기(0~1). 검사에만 쓴다."""
    c = c.lstrip('#')
    if len(c) == 3:
        c = ''.join(x * 2 for x in c)
    try:
        r, g, b = (int(c[i:i + 2], 16) / 255 for i in (0, 2, 4))
    except Exception:
        return 0.5
    return 0.299 * r + 0.587 * g + 0.114 * b


# ══════════════════════════════════════════════════════════════════════
#  탭 줄 맨 왼쪽 칸 — `ttk.Notebook` 은 탭 줄에 위젯을 못 넣는다
#  ⚠ 쓰는 곳 둘 — P1·P4 [Focus]/[Restore](`user_main._focus_strip`) ·
#    주요용어 [검색창 닫기/표시](2026-09-17 사용자 「Focus 버튼과 같은 자리」).
#    **여기 하나다** — 두 벌로 두면 테마 전환에서 한쪽만 깨진다(256차 ⑰).
# ══════════════════════════════════════════════════════════════════════

def tab_strip(nb, style_name):
    """노트북 **탭 줄의 맨 왼쪽**(첫 탭보다 왼쪽)에 단추 칸 하나.

    ★ 칸을 노트북 **위에 `place`** 하고 그 노트북만의 스타일에 `tabmargins` 를
      주어 **첫 탭이 칸 오른쪽에서 시작**하게 한다. 탭을 바꿔도 칸은 노트북의
      것이라 그대로 있다.
    ⚠ 칸 폭은 **자식 중 가장 넓은 것**으로 못 박는다(`pack_propagate(False)`) —
      글자 폭이 다른 짝을 바꿔 끼울 때 탭이 흔들리지 않게.
    ⚠ 칸 높이는 **노트북 몸통이 시작하는 y** 에서 읽는다(사용자 「탭 규격과
      100% 동일하게」). 자기 pady 로 정하면 4px 어긋난다(실측 26 ↔ 30).
    ⚠⚠⚠ **`tabmargins` 는 값이 다를 때만 적는다** — `ttk::style configure` 는
      그 자체가 모든 위젯에 `<<ThemeChanged>>` 를 보내므로, 무조건 적으면 아래
      바인딩과 맞물려 **끝없는 idle 고리**가 되어 앱이 통째로 멎는다(실측).
    ⚠ 그렇다고 한 번만 적어도 안 된다 — 테마가 vista → clam 으로 갈아타면
      적어 둔 `tabmargins` 가 사라져 **첫 탭이 단추 밑으로 돌아온다**.
    """
    import tkinter as tk
    from tkinter import ttk

    strip = tk.Frame(nb)
    strip.place(x=2, y=2)
    _tries = [0]

    def _fit(_e=None):
        try:
            kids = list(strip.winfo_children())
            if not kids:
                return
            # ⚠ **고른 탭의 몸통**만 본다 — 노트북 위에 `place` 된 딴 칸
            #   (오른쪽 모서리 단추 줄)이 섞이면 y=2 가 나와 영영 못 잰다.
            body_y = 0
            try:
                _sel = nb.select()
                if _sel:
                    body_y = nb.nametowidget(_sel).winfo_y()
            except Exception:
                body_y = 0
            if body_y < 10:            # 몸통이 아직 안 올라왔다 — 조금 뒤에 다시
                _tries[0] += 1
                if _tries[0] < 20:
                    nb.after(150, _fit)
                return
            w = max(k.winfo_reqwidth() for k in kids)
            h = body_y - 4
            if int(strip.cget('width') or 0) != w or \
               int(strip.cget('height') or 0) != h:
                strip.configure(width=w, height=h)
                strip.pack_propagate(False)
            want = '%d 2 2 0' % (w + 6)
            cur = ttk.Style().lookup(style_name, 'tabmargins')
            cur_s = (' '.join(str(v) for v in cur)
                     if isinstance(cur, (tuple, list)) else str(cur or ''))
            if cur_s != want:
                ttk.Style().configure(style_name, tabmargins=[w + 6, 2, 2, 0])
            if str(nb.cget('style')) != style_name:
                nb.configure(style=style_name)
        except Exception as e:
            print('[tab strip] %s' % e)

    def _refit(_e=None):
        # ⚠ 밖에서 온 신호면 **헛돈 횟수를 되돌린다** — 지연 빌드된 노트북은
        #   지을 때 몸통이 없어 스무 번을 헛돌고 포기한다. 그 뒤 탭을 골라도
        #   다시 안 재면 칸이 1×1 로 남는다(실측 — 주요용어에서 그랬다).
        _tries[0] = 0
        nb.after_idle(_fit)

    strip.fit = _refit
    nb.after_idle(_fit)
    nb.bind('<<ThemeChanged>>', _refit, add='+')
    nb.bind('<Map>', _refit, add='+')
    nb.bind('<<NotebookTabChanged>>', _refit, add='+')
    return strip



if __name__ == '__main__':
    import sys
    sys.exit(_selftest())
