# -*- coding: utf-8 -*-
"""상태 조건 검사기 — `record_status` 를 가진 표를 읽는 SQL 에 상태 조건이 있는가.

2026-09-09 226차(사용자 「사용자의 오버레이 기능 자체가 심각한 문제가 있구나.
철저하게 조사하라」). 관리자가 걷은(HIDE)·후보(PEND)로 내린 연결과 글이
**사용자 화면에 그대로 떴다** — 조회 문 대부분이 표만 보고 `record_status` 를
안 봤다. `db_overlay_audit` 는 「sys 표를 직접 읽는가」만 세고 **상태 조건은
보지 않는다** — 그래서 이 검사기가 따로 있다.

무엇을 재나
  · 사용자 앱 폐포(`db_overlay_audit._closure`)의 모든 `execute(...)` 첫 인자를
    AST 로 평평하게 편다(`+` 이어 붙임 · f-string · `%` · `.format` · 모듈 상수).
  · `FROM/JOIN <표> [별칭]` 마다 그 표가 상태 칸을 가지면 **그 별칭의
    `record_status`** 가 SQL 안에 있는지 본다(별칭 없으면 그 절 안의 맨 이름).
  · 파일마다 「없는 자리 수」를 세고 **기준선보다 늘면 실패**(ratchet).

⚠ 자리 수가 0 이 목표가 아니다 — PK 하나로 읽는 조회(`WHERE unit_id=?`)는 상태를
  안 봐도 무해하고, 그런 자리가 수백이다. **늘지 않는 것**을 지킨다. 새 조회를
  쓸 때 조건을 넣으면 안 는다.
⚠ 기준선을 올리는 rebase 는 이 도구가 거부한다 — 줄어든 값으로만 다시 쓴다.

명령
  --selftest   탐지력(조건 없는 SQL 을 잡는가 · 상수·f-string·별칭을 푸는가) +
               실 DB 탐침(HIDE·PEND 연결이 조회 문에서 안 나오는가)
  --baseline   지금 값으로 기준선을 (처음) 만든다 / 줄어든 값으로 갱신
  --list [파일] 걸린 자리 목록
"""
import ast
import io
import json
import os
import re
import sys

APP = os.path.dirname(os.path.abspath(__file__))
BASELINE = os.path.join(APP, 'status_audit_baseline.json')

_TBL_RX = re.compile(
    r'\b(?:FROM|JOIN|INTO|UPDATE)\s+(?:main\.|userdb\.)?(sys_\w+|user_\w+)'
    r'(?:\s+(?:AS\s+)?([A-Za-z_]\w*))?', re.I)
#: 「이 자리는 상태를 안 봐도 된다」 + **까닭**. 까닭이 없으면 안 쳐준다.
_OKMARK = re.compile(r'#\s*status-ok\s*:\s*(.*)$')

_KW = {'where', 'on', 'left', 'join', 'inner', 'group', 'order', 'limit', 'set',
       'select', 'and', 'or', 'as', 'using', 'cross', 'values', 'natural', 'outer',
       'union', 'except', 'intersect'}


def status_tables(conn=None):
    """record_status 칸을 가진 표 이름(main + userdb)."""
    close = False
    if conn is None:
        import appdb
        conn = appdb.connect(os.path.join(APP, 'bible_master.db'))
        close = True
    out = set()
    try:
        for db in ('main', 'userdb'):
            try:
                names = [r[0] for r in conn.execute(
                    "SELECT name FROM %s.sqlite_master WHERE type='table'" % db)]
            except Exception:
                continue
            for name in names:
                cols = [r[1] for r in conn.execute("PRAGMA %s.table_info(%s)" % (db, name))]
                if 'record_status' in cols:
                    out.add(name)
    finally:
        if close:
            conn.close()
    return out


#: 다른 파일의 top-level 문자열 상수 — 한 번 읽어 둔다.
_MODC = {}


def _mod_consts(mod):
    """`media_link` → {'TBL': 'sys_link_asset', …}. 못 읽으면 빈 표."""
    if mod in _MODC:
        return _MODC[mod]
    d = {}
    try:
        path = os.path.join(APP, *mod.split('.')) + '.py'
        tree = ast.parse(io.open(path, encoding='utf-8').read())
        for node in tree.body:
            if isinstance(node, ast.Assign) and len(node.targets) == 1 \
                    and isinstance(node.targets[0], ast.Name) \
                    and isinstance(node.value, ast.Constant) \
                    and isinstance(node.value.value, str):
                d[node.targets[0].id] = node.value.value
    except Exception:
        pass
    _MODC[mod] = d
    return d


class _Flat(object):
    """SQL 문자열 조립을 평평하게 — 모듈 상수(`_ST` 같은)까지 푼다.

    ⚠⚠ **`TBL` 을 `sys_link_asset` 으로 못 박고 있었다**(2026-09-10 발견).
      그런데 `TBL` 은 파일마다 다르다 — `db_worship_artist` 는
      `sys_worship_artist`, `db_media_linkcheck` 는 `sys_media_check` 다.
      그래서 검사기가 **있지도 않은 표를 읽는다고 신고**했다(실측 거짓 신고
      11자리). 이제 ⓐ 제 파일의 상수 ⓑ `ML.TBL` 처럼 남의 것이면 그 파일을
      읽어서 푼다. **모르면 지어내지 않고 `{TBL}` 로 둔다.**
    """

    def __init__(self, consts, aliases=None):
        self.consts = consts
        self.aliases = aliases or {}

    def __call__(self, node):
        f = self
        if isinstance(node, ast.Constant) and isinstance(node.value, str):
            return node.value
        if isinstance(node, ast.BinOp):
            if isinstance(node.op, ast.Add):
                return f(node.left) + f(node.right)
            if isinstance(node.op, ast.Mod):
                left = f(node.left)
                # `"... %s ..." % _ST` — 자리표에 상수를 넣는다
                vals = node.right.elts if isinstance(node.right, ast.Tuple) else [node.right]
                for v in vals:
                    left = left.replace('%s', f(v), 1)
                return left
        if isinstance(node, ast.JoinedStr):
            out = ''
            for v in node.values:
                if isinstance(v, ast.Constant):
                    out += str(v.value)
                elif isinstance(v, ast.FormattedValue):
                    out += f(v.value)
            return out
        if isinstance(node, ast.Attribute):
            # `ML.TBL` — 그 파일이 무엇을 import 했는지 보고 거기서 읽는다
            base = node.value
            if isinstance(base, ast.Name):
                mod = self.aliases.get(base.id)
                if mod:
                    got = _mod_consts(mod).get(node.attr)
                    if got:
                        return got
            return '{%s}' % node.attr
        if isinstance(node, ast.Name):
            # ★ **제 파일의 상수가 먼저다** — 이름이 같아도 값은 다르다
            if node.id in self.consts:
                return self.consts[node.id]
            return '{%s}' % node.id
        if isinstance(node, ast.Call):
            fn = node.func
            if isinstance(fn, ast.Attribute) and fn.attr in ('format', 'join', 'replace', 'strip'):
                base = f(fn.value)
                if fn.attr == 'format':
                    for a in node.args:
                        base = base.replace('{}', f(a), 1)
                    for kw in node.keywords:
                        base = base.replace('{%s}' % kw.arg, f(kw.value))
                return base
            return ''
        if isinstance(node, (ast.Tuple, ast.List)):
            return ''.join(f(e) for e in node.elts)
        return ''


def missing_in(sql, tables):
    """[(표, 별칭)] — 상태 조건 없이 읽는 자리."""
    out = []
    if not re.search(r'\bSELECT\b', sql, re.I):
        return out
    for m in _TBL_RX.finditer(sql):
        tbl, alias = m.group(1), m.group(2)
        if tbl not in tables:
            continue
        if alias and alias.lower() in _KW:
            alias = None
        if alias:
            ok = re.search(r'\b%s\.record_status\b' % re.escape(alias), sql) is not None
        else:
            seg = sql[m.end(): m.end() + 600]
            cut = re.search(r'\b(?:FROM|JOIN)\b', seg, re.I)
            seg = seg[:cut.start()] if cut else seg
            ok = (re.search(r'(?<![\w.])record_status\b', seg) is not None
                  or re.search(r'\b%s\.record_status\b' % re.escape(tbl), sql) is not None)
        if not ok:
            out.append((tbl, alias))
    return out


def _local_env(func, base, aliases):
    """함수 안에서 만든 **SQL 조각 지역 변수**를 푼다.

    ⚠⚠⚠ **이것이 없으면 거짓 신고가 난다**(2026-09-17 실측) —
      `collect_channels` 가 `where = "WHERE c.enabled=1 AND c.record_status=..."`
      를 지역 변수로 만들어 f-string 에 끼우는데, 평탄화가 모듈 상수만 풀어서
      **조건이 있는데도 없다고** 신고했다(§238차 ⑫ 「거짓 신고 11자리」와 같은 결).
    ⚠ 갈래(`if`)마다 다른 조각을 이어 붙이면 **합집합**이 된다 — 한 갈래에만
      조건이 있어도 통과한다. 그만큼 무르지만 모듈 상수도 이미 같은 무름을 갖고,
      거짓 신고로 래칫이 통째로 죽는 것보다 낫다.
    """
    env = dict(base)
    f = _Flat(env, aliases)
    for sub in ast.walk(func):
        if isinstance(sub, ast.Assign) and len(sub.targets) == 1 \
                and isinstance(sub.targets[0], ast.Name):
            got = f(sub.value)
            if got:
                env[sub.targets[0].id] = got
        elif isinstance(sub, ast.AugAssign) and isinstance(sub.target, ast.Name) \
                and isinstance(sub.op, ast.Add):
            got = f(sub.value)
            if got:
                env[sub.target.id] = env.get(sub.target.id, '') + got
    return env


def scan_source(src, tables):
    """한 파일의 소스 → [(줄, [(표,별칭)], sql 앞머리)]."""
    try:
        tree = ast.parse(src)
    except Exception:
        return []
    # ★ `import x as y` · `from a import b as c` → 별칭 → 모듈 이름
    aliases = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for al in node.names:
                aliases[al.asname or al.name.split('.')[0]] = al.name
        elif isinstance(node, ast.ImportFrom) and node.module and not node.level:
            for al in node.names:
                aliases[al.asname or al.name] = node.module + '.' + al.name
    consts = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 \
                and isinstance(node.targets[0], ast.Name) \
                and isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
            consts[node.targets[0].id] = node.value.value
    flat = _Flat(consts, aliases)
    # ★ 호출이 든 함수의 **지역 조각**까지 푼다(바깥 → 안쪽 차례라 안쪽이 이긴다)
    env_of = {}
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            _env = _local_env(node, consts, aliases)
            for sub in ast.walk(node):
                if isinstance(sub, ast.Call):
                    env_of[id(sub)] = _env
    # ★ **자가 검증(selftest) 안은 세지 않는다** (2026-09-09) — 그 안의 SQL 은 메모리
    #   DB 로 만든 시험 표를 읽는 것이라 사용자 화면과 무관하다. 시험을 늘릴 때마다
    #   기준선이 올라가면 이 검사기가 「시험을 쓰지 마라」는 뜻이 되어 죽는다.
    skip = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))                 and node.name.lstrip('_').startswith('selftest'):
            for sub in ast.walk(node):
                if hasattr(sub, 'lineno'):
                    skip.add(sub.lineno)
    # ★★★ **근거를 적은 자리는 뺀다** — `# status-ok: <왜 안 봐도 되는가>`
    #   ⚠⚠ 기준선을 그냥 올리면 래칫이 아니라 **눈금자**다(`data.md` Z-1p).
    #     그렇다고 고칠 수 없는 자리(있는 줄을 다시 만들지 않으려는 UPSERT 확인,
    #     수집 도구의 장부)를 영영 신고하게 두면 그 신고를 아무도 안 읽는다.
    #   ⇒ **그 줄에 까닭을 적게 한다.** 자리마다 사람이 한 번 보고 글로 남긴다.
    #   ⚠ **까닭 없는 표식은 안 쳐준다** — 표식만으로 입을 막을 수 없다.
    lines = src.splitlines()
    okmark = set()
    for i, ln in enumerate(lines, 1):
        m = _OKMARK.search(ln)
        if m and len(m.group(1).strip()) >= 4:
            okmark.add(i)
    hits = []
    for node in ast.walk(tree):
        if getattr(node, 'lineno', None) in skip:
            continue
        a, b = getattr(node, 'lineno', 0), getattr(node, 'end_lineno', 0) or 0
        if a and any(i in okmark for i in range(a, max(a, b) + 1)):
            continue
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) \
                and node.func.attr in ('execute', 'executemany') and node.args:
            sql = flat(node.args[0])
            # ★ **이미 보이는 SQL 안에 못 푼 조각이 있을 때만** 지역 변수를 푼다.
            #   ⚠⚠ 조건 없이 다 풀면 **그전에는 통째로 안 보이던 SQL** 이 무더기로
            #     드러나 자리가 462 → 494 로 뛴다(실측). 그것은 회귀가 아니라
            #     탐지력이 세진 것이지만, 래칫은 「늘지 않는 것」을 지키는 장치라
            #     한 번에 섞으면 무엇이 회귀이고 무엇이 새 탐지인지 못 가른다.
            #   ⇒ 지금은 **거짓 신고를 없애는 데만** 쓴다(`{where}` 빈칸 메우기).
            #     ⏭ 못 보던 SQL 까지 여는 것은 자리를 하나씩 보고 난 다음 일이다.
            if '{' in sql and re.search(r'\bSELECT\b', sql, re.I):
                _env = env_of.get(id(node))
                if _env:
                    sql = _Flat(_env, aliases)(node.args[0])
            if not sql:
                continue
            miss = missing_in(sql, tables)
            if miss:
                hits.append((node.lineno, miss, re.sub(r'\s+', ' ', sql)[:160]))
    return hits


def scan(files=None, tables=None):
    import db_overlay_audit as OA
    tables = tables or status_tables()
    out = {}
    for f in (files or OA._closure()):
        try:
            src = io.open(os.path.join(APP, f), encoding='utf-8').read()
        except Exception:
            continue
        hits = scan_source(src, tables)
        if hits:
            out[f.replace(os.sep, '/')] = hits
    return out


def counts(rep):
    return {f: len(h) for f, h in rep.items()}


def load_baseline():
    try:
        return json.load(io.open(BASELINE, encoding='utf-8'))
    except Exception:
        return None


def check(rep=None, log=print):
    """기준선 대비 — 늘어난 파일이 있으면 False."""
    rep = rep if rep is not None else scan()
    now = counts(rep)
    base = load_baseline()
    if base is None:
        log('기준선이 없다 — `--baseline` 으로 먼저 만든다. 지금 자리 %d' % sum(now.values()))
        return True
    worse = {f: (base.get(f, 0), n) for f, n in now.items() if n > base.get(f, 0)}
    log('상태 조건 없는 조회 자리 %d (기준선 %d)' % (sum(now.values()), sum(base.values())))
    for f, (b, n) in sorted(worse.items()):
        log('  ✗ 늘었다 %s  %d → %d' % (f, b, n))
        for ln, miss, s in rep[f]:
            log('      L%d %s  %s' % (ln, miss, s[:100]))
    return not worse


def write_baseline(rep=None, log=print):
    rep = rep if rep is not None else scan()
    now = counts(rep)
    base = load_baseline()
    if base is not None:
        bad = [f for f, n in now.items() if n > base.get(f, 0)]
        if bad:
            log('기준선을 올릴 수 없다 — 늘어난 파일: %s' % ', '.join(bad))
            return False
    json.dump(now, io.open(BASELINE, 'w', encoding='utf-8'), ensure_ascii=False, indent=1, sort_keys=True)
    log('기준선 기록 — 파일 %d · 자리 %d' % (len(now), sum(now.values())))
    return True


# ── selftest ─────────────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0 if cond else 1] += 1
        print(('  PASS ' if cond else '  FAIL ') + name + ('' if cond else '  ' + str(extra)))

    T = {'sys_link_asset', 'sys_text_asset', 'user_link_asset'}
    # 탐지력 — 조건이 없으면 잡고, 있으면 안 잡는다(별칭·맨 이름·상수·f-string·%)
    t('조건 없는 조회를 잡는다',
      missing_in("SELECT 1 FROM sys_link_asset WHERE clicked_id=?", T) == [('sys_link_asset', None)])
    t('맨 이름 조건이 있으면 통과',
      missing_in("SELECT 1 FROM sys_link_asset WHERE clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'", T) == [])
    t('별칭 조건 — 딴 별칭의 조건은 안 쳐준다',
      missing_in("SELECT 1 FROM sys_link_asset a JOIN sys_text_asset b ON b.clicked_id=a.sys_link_id WHERE a.record_status='LIVE'", T) == [('sys_text_asset', 'b')])
    t('상태 칸 없는 표는 안 본다',
      missing_in("SELECT 1 FROM bible_index WHERE verse_id=?", T) == [])
    t('SELECT 가 아니면 안 본다',
      missing_in("UPDATE sys_link_asset SET note=?", T) == [])
    src = (
        "_ST = \"COALESCE(record_status,'LIVE')='LIVE'\"\n"
        "def f(conn):\n"
        "    conn.execute(\"SELECT 1 FROM sys_text_asset WHERE clicked_id=? AND \" + _ST)\n"
        "    conn.execute(\"SELECT 1 FROM sys_text_asset WHERE x=? AND %s\" % _ST)\n"
        "    conn.execute(f\"SELECT 1 FROM sys_link_asset WHERE y=? AND {_ST}\")\n"
        "    conn.execute(\"SELECT 1 FROM sys_link_asset s WHERE s.a=?\")\n"
    )
    hits = scan_source(src, T)
    t('모듈 상수 `_ST` 를 + · % · f-string 에서 푼다 — 넷 중 마지막 하나만 걸린다',
      [h[0] for h in hits] == [6], hits)
    # ★★★ 표 이름 풀기 — `TBL` 은 **파일마다 다르다**(2026-09-10)
    _J = "\n".join
    src2 = _J(["import media_link as ML",
               "TBL = 'sys_worship_artist'",
               "def f(conn):",
               "    conn.execute('SELECT 1 FROM %s WHERE a=?' % TBL)",
               "    conn.execute('SELECT 1 FROM %s WHERE b=?' % ML.TBL)", ""])
    h2 = scan_source(src2, {'sys_link_asset', 'sys_worship_artist'})
    got = sorted(m[0] for _l, ms, _s in h2 for m in ms)
    t('★★★ 제 파일의 `TBL` 을 쓴다(옛 코드는 `sys_link_asset` 으로 못 박았다)',
      got == ['sys_link_asset', 'sys_worship_artist'], got)
    t('★★ 모르는 이름은 **지어내지 않는다**',
      scan_source(_J(["def f(c):",
                      "    c.execute('SELECT 1 FROM %s WHERE a=?' % WAT)", ""]),
                  {'sys_link_asset'}) == [])

    # ★★★ 근거 표식 — 까닭을 적으면 빼되, **까닭이 없으면 안 뺀다**
    _CALL = "    c.execute('SELECT 1 FROM sys_link_asset WHERE a=?')"
    t('★ 표식이 없으면 잡는다',
      len(scan_source(_J(["def f(c):", _CALL, ""]), {'sys_link_asset'})) == 1)
    t('★★★ **까닭을 적으면 뺀다**',
      scan_source(_J(["def f(c):",
                      _CALL + "  # status-ok: 있는 줄 확인이라 상태를 보면 안 된다",
                      ""]), {'sys_link_asset'}) == [])
    t('★★★ **까닭 없는 표식은 안 쳐준다**(표식만으로 입을 막을 수 없다)',
      len(scan_source(_J(["def f(c):", _CALL + "  # status-ok:", ""]),
                      {'sys_link_asset'})) == 1)
    t('★★ 딴 줄의 표식은 **새지 않는다**',
      len(scan_source(_J(["def f(c):",
                          "    x = 1  # status-ok: 여기는 상관없는 줄이다",
                          _CALL, ""]), {'sys_link_asset'})) == 1)
    t('★★ 여러 줄에 걸친 부름은 **그 안 어디든** 통한다',
      scan_source(_J(["def f(c):", "    c.execute(",
                      "        'SELECT 1 FROM sys_link_asset WHERE a=?'"
                      "  # status-ok: 까닭을 여기 적어도 통한다",
                      "    )", ""]), {'sys_link_asset'}) == [])

    # 실 DB 탐침 — 조회 문이 HIDE·PEND 를 실제로 안 낸다
    try:
        import appdb
        import overlay_read as OR
        conn = appdb.connect(os.path.join(APP, 'bible_master.db'))
        r = conn.execute("SELECT clicked_id, target_id FROM sys_link_asset WHERE link_type='MEDI_ENTI'"
                         " AND record_status='PEND' LIMIT 1").fetchone()
        if r:
            mid, eid = r
            live = conn.execute("SELECT 1 FROM sys_link_asset WHERE link_type='MEDI_ENTI' AND clicked_id=?"
                                " AND target_id=? AND record_status='LIVE'", (mid, eid)).fetchone()
            rows = OR.media(conn, eid, 'ALL', 'KO')
            def _mid(x):
                try:
                    return int(x['media_id'])
                except Exception:
                    return None
            got = any(_mid(x) == int(mid) for x in rows)
            t('★ 실 DB — 후보(PEND) 용어 연결의 영상이 용어 화면 조회에 안 나온다', live or not got, (mid, eid))
        r = conn.execute("SELECT clicked_id, target_id FROM sys_link_asset WHERE link_type='ENTI_VERS'"
                         " AND record_status='HIDE' LIMIT 1").fetchone()
        if r:
            eid, vid = r
            live = conn.execute("SELECT 1 FROM sys_link_asset WHERE link_type='ENTI_VERS' AND clicked_id=?"
                                " AND target_id=? AND record_status='LIVE'", (eid, vid)).fetchone()
            vids = set()
            for x in OR.entity_verses(conn, eid, 'KO'):
                try:
                    vids.add(int(x['verse_id'] if hasattr(x, 'keys') else x[0]))
                except Exception:
                    pass
            t('★ 실 DB — 걷은(HIDE) 용어→절 연결이 연결구절 조회에 안 나온다',
              live or int(vid) not in vids, (eid, vid, len(vids)))
        conn.close()
    except Exception as e:
        t('실 DB 탐침', False, repr(e))
    # ★★ 지역 조각 평탄화 — 거짓 신고를 없애되 **탐지력은 안 무뎌진다**
    #   (2026-09-17 · `collect_channels` 의 `where` 가 거짓 신고를 냈다)
    _L = chr(10)
    _head = 'def f(c):' + _L + '    where = '
    _tail = _L + '    c.execute(f"SELECT a FROM sys_unit_asset {where}")' + _L
    _ok_src = _head + repr("WHERE record_status='LIVE'") + _tail
    _no_src = _head + repr('WHERE 1=1') + _tail
    t('★★ 지역 변수에 든 조건을 푼다(거짓 신고 0)',
      not scan_source(_ok_src, {'sys_unit_asset'}))
    t('★★ 그래도 **조건이 없으면 잡는다**(탐지력 불변)',
      len(scan_source(_no_src, {'sys_unit_asset'})) == 1)

    # 기준선 — 늘지 않았는가
    rep = scan()
    t('★ 기준선 대비 늘어난 파일 0', check(rep, log=lambda *a: None))
    print('db_status_audit selftest %d/%d' % (ok[0], ok[0] + ok[1]))
    return ok[1] == 0


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    elif '--baseline' in a:
        sys.exit(0 if write_baseline() else 1)
    elif '--list' in a:
        rep = scan()
        want = [x for x in a if x != '--list']
        for f, hits in sorted(rep.items(), key=lambda x: -len(x[1])):
            if want and f not in want:
                continue
            print('%3d  %s' % (len(hits), f))
            if want:
                for ln, miss, s in hits:
                    print('      L%-5d %-38s %s' % (ln, str(miss)[:38], s[:110]))
    else:
        sys.exit(0 if check() else 1)
