# plan_focus_view.py
"""P1 Tab2 묵상플랜 활용화면.

상단 컨트롤: 플랜선택 콤보 / day 탐색 / 묵상완료 / 묵상플랜 등록 버튼
하단 바디  : FocusOverlay 스타일 페리코프 카드 + 구절 클릭 연동
"""
import sqlite3
import verse_ref
import link_picker                        # 자산 연결 (§자산간 연결)
import appdb
import i18n
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date
from i18n import t

# ⚠⚠⚠ **여기서 import 하지 않는다** (2026-09-05 실측 — `voice_bible` 이
#   `sounddevice`(134ms) + `numpy`(68ms) 를 끌어와 **앱 시작을 214ms** 늦춘다).
#   음성은 **재생 단추를 눌렀을 때** 필요하다 ⇒ 그때 만든다(`_get_player`).
# ⚠⚠ **여기서 import 하지 않는다** — `voice_play_bar` 가 `voice_bible` →
#   `sounddevice`(149ms)+`numpy`(67ms) 를 끌어와 **앱 시작을 228ms** 늦춘다.
#   음성은 **단추를 눌렀을 때** 필요하다(2026-09-05 사용자 지시).
import bidi
from reading_pane import ReadingPane   # 책 읽는 화면 한 벌 (font.md §22)

_STAGE_LABEL = {
    'EVENT':       '사건',
    'LAW':         '율법',
    'EXPANSION':   '확장',
    'FULFILLMENT': '성취',
    'APPLICATION': '적용',
    'READ':        '읽기',
    'MIRACLE':     '기적',
    'OT_TYPE':     '예표',
    'EXPAND':      '확장본문',
    'CONFIRM':     '확인',
    'PSA':         '시편',
    'PSA_INTRO':   '시편서론',
    'CORE':        '핵심 말씀',
    'AUXILIARY':   '보조',
    # DIAGNOSTIC 전용 블록
    'RESONANCE':   '공명 (이야기)',
    'PIVOT':       '보조 본문',
    # 도서기반 플랜 전용
    'BOOK_TEXT':   '도서 본문',
    'QUOTED':      '직접 인용',
    'SUPPORT':     '맥락 지지',
    'COMPLEMENT':  '보완 읽기',
    'CONTRAST':    '대비 읽기',
}
_STAGE_BG = {
    'EVENT':       '#1A5276',
    'LAW':         '#6E2F00',
    'EXPANSION':   '#1E5631',
    'FULFILLMENT': '#4A235A',
    'APPLICATION': '#7B241C',
    'READ':        '#2E4053',
    'MIRACLE':     '#6C3483',
    'OT_TYPE':     '#1A5276',
    'EXPAND':      '#1E5631',
    'CONFIRM':     '#4A235A',
    'PSA':         '#784212',
    'PSA_INTRO':   '#784212',
    'CORE':        '#1A5276',
    # DIAGNOSTIC 전용 블록
    'RESONANCE':   '#1B4F72',
    'PIVOT':       '#1E5631',
    # 도서기반 플랜 전용
    'BOOK_TEXT':   '#17202A',
    'QUOTED':      '#1A5276',
    'SUPPORT':     '#1E5631',
    'COMPLEMENT':  '#4A235A',
    'CONTRAST':    '#7B241C',
}




def _ref_lang():
    """구절약명에 쓸 언어 — **성경 역본**을 따른다(표시언어 콤보가 아니다).

    2026-08-15 사용자 지시: 「구절약명은 버전을 바꿀 때에만 바뀌어야 한다」.
    ⚠ `book_names` 에 EL·HE·COP 가 없어 원문 역본(GNT·WLC·COP*)은 **영어**로 떨어진다.
    """
    try:
        import lang_config
        return lang_config.ref_lang()
    except Exception:
        return 'EN'

def _c(role, dflt):
    """테마 색. **띠·버튼 바탕을 여기서 가져온다** (2026-08-14 사용자 지적
    「버튼이 표시되는 배경색은 흰색/투명색이다」).
    ⚠ 짙은 남색을 걷어낼 때 `#ECEFF1` 처럼 **너무 옅게** 잡아 띠가 사라져 보였다.
      옅게 하는 것과 없애는 것은 다르다 — 테마의 `panel` 을 그대로 쓴다."""
    try:
        import ui_theme
        return ui_theme.C(role)
    except Exception:
        return dflt


def _ok_bg(soft=False):
    """완료 단추 바탕 — **테마의 「좋음」 색**을 쓴다 (2026-08-14 사용자 지적
    「오늘 묵상완료 버튼의 배경이 표준을 따르지 않고 있다」).
    ⚠ `#27AE60` 을 박아 두면 테마를 바꿔도 그 초록만 남는다."""
    try:
        import ui_theme
        return ui_theme.C('success_bg' if soft else 'success')
    except Exception:
        return '#A9DFBF' if soft else '#1E8449'


def _tf(w, db):
    """성경 구절 위젯에 「성경」 역할 글꼴을 입힌다 (font.md §22).

    ⚠ 그릴 때마다 새로 만드는 위젯이라 `register` 하지 않는다.
    """
    try:
        import theme_font
        theme_font.apply(w, db, 'bible')
    except Exception:
        pass

class PlanFocusView(ttk.Frame):
    """P1 Tab2: 묵상플랜 활용화면."""

    def __init__(self, parent, db_path, lang_getter, version_getter,
                 on_verse_select=None, on_open_plan_tab=None,
                 on_day_complete=None, embedded=False, scope=None):
        super().__init__(parent)
        # ★ **갈래에 따라 녹음 단추를 감춘다** (2026-08-14 사용자 지시 · `0.app수정.txt`).
        #   「도서묵상, 렌즈묵상 : 녹음, 중지, 중단 버튼 삭제 (성경 본문읽기의 비중이
        #   매우 낮기 때문)」 — 도서·설교집에는 **녹음된 낭독이 아예 없다.**
        #   ⚠ 지우지 않고 감춘다 — 재생 기능 자체는 전체읽기·주제읽기·자가진단에서 산다.
        self.scope            = scope
        self._show_audio      = scope not in ('BOOK', 'LENS')
        self.db_path          = db_path
        self.lang_getter      = lang_getter
        self.version_getter   = version_getter
        self.on_verse_select  = on_verse_select
        self.on_open_plan_tab = on_open_plan_tab
        self.on_day_complete  = on_day_complete
        self._embedded        = embedded  # True이면 콤보/등록 버튼 숨김

        self._active_enrollments: list[dict] = []
        self._sel_enr:  dict | None = None
        self._plan_type = ''
        self._view_day  = 1
        self.__pset = None       # 처음 쓸 때 만든다
        self._player         = None   # 처음 재생할 때 만든다
        self._play_verse_ids: list[int] = []

        self._build()

    # ── UI 구성 ───────────────────────────────────────────────────────────────

    def _build(self):
        # ── 상단 컨트롤 바 ────────────────────────────────────────────────────
        ctrl = tk.Frame(self, bg=_c('panel', '#ECEFF1'), pady=3)
        ctrl.pack(fill='x')
        self._ctrl_bar = ctrl   # week bar 삽입 기준점

        _b = dict(font=('Malgun Gothic', 8, 'bold'), bd=0, padx=6, pady=2)

        # ★ **「오늘 묵상완료」를 맨 왼쪽에** (2026-08-14 사용자 지시).
        #   가장 자주 누르는 단추라 오른쪽 끝에 있으면 매번 눈이 건너가야 한다.
        # ⚠ 완료·중단은 **뜻이 있는 색**이라 남긴다 — 나머지만 걷어냈다
        self._btn_complete = tk.Button(ctrl, text=i18n.t('PFV_MEDDONE', '✓ 오늘 묵상완료'),
                                       command=self._complete_day,
                                       bg=_ok_bg(), fg='white', **_b)
        self._btn_complete.pack(side='left', padx=(6, 2))
        # ★ **언어 콤보를 걷었다** (2026-10-13 docs/1.txt 76-9·12 사용자 「묵상플랜에서는
        #   언어콤보가 필요하지 않다 · 사용자가 세팅한 언어값만 표시하면 된다」).
        #   글은 환경설정 언어(`lang_getter`)로 · 없으면 영어로 물러서고 그렇다고 한 줄 적는다.
        self._lang = None
        # 좌측: 플랜 선택 콤보 + 등록 버튼 (embedded=True이면 숨김)
        self._enr_var = tk.StringVar()
        self._enr_combo = ttk.Combobox(ctrl, textvariable=self._enr_var,
                                       state='readonly', width=36)  # 글꼴 표준(0.txt ④)
        self._enr_combo.bind('<<ComboboxSelected>>', self._on_enr_select)
        self._btn_register = tk.Button(ctrl, text=i18n.t('PFV_ENROLL','+ 묵상플랜 등록'),
                                       command=self._open_plan_tab_cb,
                                       bg='#1E8449', fg='white',
                                       font=('Malgun Gothic', 8, 'bold'),
                                       bd=0, padx=6, pady=2)
        if not self._embedded:
            self._enr_combo.pack(side='left', padx=(6, 2), pady=2)
            self._btn_register.pack(side='left', padx=(4, 0))

        # ★ **쓰기 단추는 상단에** (2026-08-22 사용자 지시 「도서묵상은 하단에
        #   배치되어 불편하다. 상단으로 옮기자」). 그전에는 읽는 칸 **맨 끝**에
        #   그려서 하루치를 다 내려야 보였다 — §0 「버튼은 항상 상단」 위반.
        #   ⚠ 쓴 노트 **목록**은 읽는 칸 아래에 그대로 둔다(읽을 거리다).
        #   ★ 서식은 **도서/설교 동작 줄과 똑같이** (2026-08-22 사용자
        #     「작지만 깔끔하다」) — 바탕색 없이 글자색만, 글꼴 이름은 안 박는다
        #     (§36 표준 서식). `p1_reading_view._BTN` 과 같은 값이다.
        # ★ 2026-10-13 76-10·11 — 양각 단추를 걷고 **Font 단추와 같은 라벨 꼴**(`ui_theme.flat_btn` 단일 소스).
        import ui_theme as _uth
        _WBTN = _uth.flat_btn(font=('', 9))
        _WBTN.pop('fg', None)
        self._write_bar = tk.Frame(ctrl, bg=_c('panel', '#ECEFF1'))
        self._write_bar.pack(side='left', padx=(16, 0))
        self._btn_note = tk.Button(
            self._write_bar, text=i18n.t('MN_WRITE', '묵상노트 쓰기'),
            fg=_c('success', '#1E8449'),
            command=lambda: self._open_note_editor(), **_WBTN)
        self._btn_res = tk.Button(
            self._write_bar, text=i18n.t('PR_RESEARCH_NEW', '연구/설교노트'),
            fg=_c('accent', '#2E86C1'),
            command=self._write_research, **_WBTN)

        # 중단은 되돌릴 수 없는 것이라 오른쪽 끝에 떼어 둔다
        act_grp = tk.Frame(ctrl, bg=_c('panel', '#ECEFF1'))
        act_grp.pack(side='right', padx=(50, 6))
        self._btn_abandon = tk.Button(act_grp, text=i18n.t('PFV_ABORT','✕ 중단'),
                                      command=self._abandon_plan,
                                      bg=_c('danger', '#C0392B'), fg='white', **_b)
        self._btn_abandon.pack(side='left', padx=(0, 2))

        # 그룹 2 (중간): ▶ 재생 / ■ 중지 / ⚙ 설정  — **녹음이 있는 갈래에서만**
        aud_grp = tk.Frame(ctrl, bg=_c('panel', '#ECEFF1'))
        self._btn_play = tk.Button(aud_grp, text=i18n.t('COMMON_PLAY','▶ 재생'), command=self._play_start,
                                   bg='#1E8449', fg='white', **_b)
        self._btn_stop = tk.Button(aud_grp, text='■', command=self._play_stop,
                                   bg=_c('panel', '#ECEFF1'), fg=_c('danger', '#B03A2E'), **_b)
        self._btn_pset = tk.Button(aud_grp, text='⚙', command=self._open_play_settings,
                                   bg=_c('panel', '#ECEFF1'), fg=_c('fg', '#1A5276'), **_b)
        if self._show_audio:
            aud_grp.pack(side='right', padx=(50, 4))
            self._btn_play.pack(side='left', padx=(0, 2))
            self._btn_stop.pack(side='left', padx=1)
            self._btn_pset.pack(side='left', padx=1)
        # ⚠ **`? 단계` 는 녹음과 상관없다** — 교회력 플랜의 단계 안내다.
        #   예전에는 위 세 단추와 같은 프레임에 있어서, 녹음을 감추면 이것까지
        #   딸려 사라졌다. 부모를 갈라 두 관심사를 떼어 놓는다.
        self._stg_grp = tk.Frame(ctrl, bg=_c('panel', '#ECEFF1'))
        self._btn_stage_guide = tk.Button(self._stg_grp, text=i18n.t('FOCUS_STAGEHELP','? 단계'),
                                          command=self._open_stage_guide,
                                          bg=_c('panel', '#ECEFF1'), fg=_c('warning', '#9C6708'), **_b)
        # LITURGICAL일 때만 _render()에서 pack

        # 그룹 1 (왼쪽): 진도 / Day / ◀ / 입력 / ▶ / 오늘로
        nav_grp = tk.Frame(ctrl, bg=_c('panel', '#ECEFF1'))
        nav_grp.pack(side='right', padx=(16, 50))
        self.lbl_progress = tk.Label(nav_grp, text='', bg=_c('panel', '#ECEFF1'), fg=_c('success', '#1E8449'),
                                     font=('Malgun Gothic', 8))
        self.lbl_progress.pack(side='left', padx=(0, 4))
        self.lbl_day = tk.Label(nav_grp, text='', bg=_c('panel', '#ECEFF1'), fg=_c('fg', '#1A5276'),
                                font=('Malgun Gothic', 9, 'bold'))
        self.lbl_day.pack(side='left', padx=(0, 4))
        tk.Button(nav_grp, text='◀', command=self._nav_prev,
                  bg=_c('panel_alt', '#E0E4E7'), fg=_c('fg', '#1A5276'), **_b).pack(side='left', padx=1)
        self._day_var = tk.StringVar(value='1')
        self._day_entry = tk.Entry(nav_grp, textvariable=self._day_var,
                                   width=4, font=('Malgun Gothic', 8),
                                   justify='center')
        self._day_entry.pack(side='left', padx=1)
        self._day_entry.bind('<Return>',   lambda e: self._nav_jump())
        self._day_entry.bind('<FocusOut>', lambda e: self._nav_jump())
        tk.Button(nav_grp, text='▶', command=self._nav_next,
                  bg=_c('panel_alt', '#E0E4E7'), fg=_c('fg', '#1A5276'), **_b).pack(side='left', padx=1)
        tk.Button(nav_grp, text=i18n.t('PP_TOTODAY','오늘로'), command=self._nav_today,
                  bg=_c('panel_alt', '#E0E4E7'), fg=_c('fg', '#1A5276'), **_b).pack(side='left', padx=(4, 0))

        # ── 주차 컨텍스트 바 (LITURGICAL 전용) ──────────────────────────────
        self._week_bar = tk.Frame(self, bg=_c('panel_alt', '#E4EAEF'))
        # pack on demand in _show_week_bar
        wbar_top = tk.Frame(self._week_bar, bg=_c('panel_alt', '#E4EAEF'))
        wbar_top.pack(fill='x')
        self.lbl_week_title = tk.Label(wbar_top, text='', bg=_c('panel_alt', '#E4EAEF'), fg=_c('fg', '#1A5276'),
                                       font=('Malgun Gothic', 9, 'bold'),
                                       padx=10, pady=3, anchor='w')
        self.lbl_week_title.pack(side='left', fill='x', expand=True)
        self._btn_week = tk.Button(wbar_top, text='▼',
                                   command=self._toggle_week_bar,
                                   bg=_c('panel_alt', '#E4EAEF'), fg=_c('fg', '#1A5276'),
                                   activebackground='#1A5276',
                                   font=('Malgun Gothic', 8), bd=0, padx=8, pady=3)
        self._btn_week.pack(side='right')
        self._week_body = tk.Frame(self._week_bar, bg=_c('panel_alt', '#E4EAEF'))
        self.lbl_week_desc = tk.Label(self._week_body, text='',
                                      bg=_c('panel_alt', '#E4EAEF'), fg='#D6EAF8',
                                      font=('Malgun Gothic', 9),
                                      wraplength=600, justify='left',
                                      padx=12, pady=6, anchor='w')
        self.lbl_week_desc.pack(fill='x')
        self._week_bar_expanded = False

        # ── 읽는 몸체 ────────────────────────────────────────────────────────
        # ★★ **책 읽는 화면으로 바꿨다** (2026-08-14 사용자 지시
        #   「책 읽는 느낌이 들도록」). 예전에는 `Canvas` 위에 `Frame` 을 얹고
        #   한 절마다 `Frame → Frame → Label` 을 쌓았다. 실측한 문제 넷:
        #     ① 색이 다섯 겹이라 눈이 **글자보다 상자 경계**를 먼저 봤다
        #     ② 절마다 배경이 끊겨 **목록으로 읽혔다**
        #     ③ `wraplength` 가 460·500·520 으로 박혀 **창을 넓혀도 안 늘어났다**
        #     ④ `Canvas` 라 휠·키보드·복사·검색이 전부 안 됐다
        #   ⇒ `ReadingPane`(Text 한 덩어리) 하나로 바꾼다. 구분은 색 상자가 아니라
        #     **여백과 글자색**이고, 서식은 폰트 총괄화면의 역할을 그대로 따른다.
        #   ⚠ **기능은 하나도 안 버린다** — 절 약명은 여전히 눌리고(P2·엔티티로 감),
        #     도서 본문의 변형 라디오는 `pane.widget()` 으로 본문 안에 그대로 심는다.
        self._pane = ReadingPane(self, self.db_path,
                                 on_ref_click=self._on_ref_click)
        self._pane.pack(expand=True, fill='both')
        # 옛 이름을 쓰던 곳들이 있어 이름만 이어 둔다(구분선·안내문 등)
        self._inner = self._pane.text

        self._show_placeholder('등록된 묵상플랜이 없습니다.\n"+ 묵상플랜 등록" 버튼을 클릭하세요.')

    # ── 공개 API ──────────────────────────────────────────────────────────────

    def load(self, plan_id: int, day: int):
        """plan_panel의 ▶ Focus 모드에서 호출: 특정 플랜+일 표시."""
        self._load_enrollments()
        enr = self._find_enr_for_plan(plan_id)
        if enr:
            self._sel_enr = enr
        # plan_id 직접 지정 (등록이 없어도 내용 표시 가능하도록)
        self._view_day = day
        self._sync_combo()
        self._render(plan_id)

    def refresh(self):
        """탭 헤더 클릭 시 자동 호출: 현재 활성 플랜 로드."""
        self._load_enrollments()
        if not self._active_enrollments:
            self._week_bar.pack_forget()
            self._show_placeholder(
                '등록된 묵상플랜이 없습니다.\n"+ 묵상플랜 등록" 버튼을 클릭하세요.')
            self._enr_var.set(i18n.t('PFV_NO_ENROLLED', '(등록된 플랜 없음)'))
            self.lbl_day.config(text='')
            self.lbl_progress.config(text='')
            return

        # 직전 선택 우선, 없으면 enrollment_id 가장 작은(먼저 등록한) 것
        if self._sel_enr:
            still = self._find_enr_by_id(self._sel_enr['enrollment_id'])
            self._sel_enr = still if still else self._active_enrollments[0]
        else:
            self._sel_enr = self._active_enrollments[0]

        self._view_day = self._sel_enr['current_day']
        self._sync_combo()
        self._render(self._sel_enr['plan_id'])

    # ── 데이터 로드 ───────────────────────────────────────────────────────────

    def _load_enrollments(self):
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT e.enrollment_id, e.plan_id, e.user_plan_id, e.current_day, "
                    "       e.enrollment_status, e.start_date, "
                    "       CASE WHEN e.user_plan_id IS NOT NULL "
                    "            THEN u.duration_days ELSE p.duration_days END, "
                    "       CASE WHEN e.user_plan_id IS NOT NULL "
                    "            THEN u.plan_type ELSE p.plan_type END "
                    "FROM user_plan_enrollment e "
                    "LEFT JOIN sys_bible_plan p ON p.plan_id=e.plan_id "
                    "LEFT JOIN user_bible_plan u ON u.user_plan_id=e.user_plan_id "
                    "WHERE e.record_status='LIVE' AND e.enrollment_status='ACTIVE' "
                    "  AND (p.plan_id IS NOT NULL OR u.user_plan_id IS NOT NULL) "
                    "ORDER BY e.enrollment_id"
                ).fetchall()
        except Exception:
            rows = []

        _DUR_CODE = {365: '1Y', 364: '1Y', 730: '2Y', 1095: '3Y'}
        self._active_enrollments = []
        combo_vals = []
        for enr_id, pid, uid, cur_day, status, start, dur, ptype in rows:
            group_lbl = t(f'UI_PLAN_TGRP_{ptype}', ptype) if ptype else str(pid)
            dur_code = _DUR_CODE.get(dur, f'{dur}d')
            year2 = (start or '')[:4][2:] or '??'
            label = f"{group_lbl} - {dur_code} · '{year2}"
            combo_vals.append(label)
            self._active_enrollments.append(dict(
                enrollment_id=enr_id, plan_id=pid, user_plan_id=uid,
                current_day=cur_day, status=status, start_date=start,
                duration_days=dur, title=label, label=label,
            ))
        self._enr_combo['values'] = combo_vals

    def _get_plan_title(self, plan_id: int, lang: str) -> str:
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT contents FROM sys_text_asset "
                    "WHERE clicked_id=? AND text_type='PLAN_TITLE' "
                    "AND lang_code=? AND record_status='LIVE' LIMIT 1",
                    (plan_id, lang)
                ).fetchone()
                if row and row[0]:
                    return row[0]
                row2 = conn.execute(
                    "SELECT plan_code FROM sys_bible_plan WHERE plan_id=?",
                    (plan_id,)
                ).fetchone()
                if row2:
                    return row2[0]
                row3 = conn.execute(
                    "SELECT plan_code FROM user_bible_plan WHERE origin_plan_id=?",
                    (plan_id,)
                ).fetchone()
                return row3[0] if row3 else str(plan_id)
        except Exception:
            return str(plan_id)

    def _find_enr_for_plan(self, plan_id: int) -> dict | None:
        return next((e for e in self._active_enrollments
                     if e['plan_id'] == plan_id), None)

    def _find_enr_by_id(self, enr_id: int) -> dict | None:
        return next((e for e in self._active_enrollments
                     if e['enrollment_id'] == enr_id), None)

    def select_by_enr_id(self, enr_id: int):
        """외부(PlanMainView)에서 enrollment_id를 지정하여 해당 플랜을 표시한다."""
        self._load_enrollments()
        enr = self._find_enr_by_id(enr_id)
        if enr:
            self._sel_enr = enr
            self._view_day = enr.get('current_day', 1)
            self._render(enr['plan_id'])

    def _sync_combo(self):
        if self._sel_enr:
            self._enr_var.set(self._sel_enr.get('label', ''))

    def _on_enr_select(self, event=None):
        idx = self._enr_combo.current()
        if idx < 0 or idx >= len(self._active_enrollments):
            return
        self._sel_enr = self._active_enrollments[idx]
        self._view_day = self._sel_enr['current_day']
        self._render(self._sel_enr['plan_id'])

    # ── 표시 언어 ─────────────────────────────────────────────────────────────

    def _disp_lang(self):
        """이 화면의 글을 어느 언어로 볼까. 밖에서 받은 `lang_getter` 는 첫 기본값이다.

        ⚠ **성경 본문은 여기 안 걸린다** — 그쪽은 역본(`version_getter`)이 정한다.
        ⚠ 구절 약명은 전역 UI 언어를 그대로 쓴다. 약명은 읽는 글이 아니라 **가리키는
          표시**라 `verse_ref` 가 정한 규칙을 따르고, 화면마다 흔들리면 안 된다.
        """
        lc = getattr(self, '_lang', None)
        if lc is not None:
            cur = lc.current()
            if cur and cur[1]:
                return str(cur[1]).upper()
        return (self.lang_getter() or 'KO').upper()

    def _disp_variant(self):
        """도서 본문을 어느 판으로 볼까. 없으면 None."""
        lc = getattr(self, '_lang', None)
        cur = lc.current() if lc is not None else None
        return (cur[0] if cur else None)

    def _on_lang_pick(self, _cur=None):
        self._render()

    def _fill_lang(self, pid=None, uid=None, day=None):
        """표시 언어 목록 — **고정이다. DB 를 묻지 않는다** (2026-08-14 설계 확정).

        ★ 사용자 지시 — 「화면을 열 때부터 언어콤보를 표시하기 위해서 언어별 텍스트
          존재여부를 검사하는 방식의 느리게 만드는 요소는 제거하라. 어차피 모든
          텍스트 데이터가 나중에는 저장될 것이기 때문이다.」
          ⚠ 실제로 그 검사가 이 화면에서 가장 비쌌다 — 도서 판 조회 74.75ms ·
            페리코프 언어 28.2ms(`font.md` §28). 지금은 **0.003ms**(조회 없음).
        ⚠ 없는 것은 **영어로 폴백**해서 보인다. 폴백은 고르게 하는 수단이 아니라
          만일의 공백에 대비하는 것이다.
        """
        return                      # 언어 콤보를 걷었다(76-9·12) — 채울 것이 없다

    # ── 렌더링 ────────────────────────────────────────────────────────────────

    def _render(self, plan_id: int | None = None):
        pid = plan_id or (self._sel_enr['plan_id'] if self._sel_enr else None)
        uid = (self._sel_enr or {}).get('user_plan_id')
        if not pid and not uid:
            return
        self._view_uid = uid           # 구간 제목 띠가 읽는다(내 플랜 · 87)
        self._fill_lang()
        lang = self._disp_lang()
        ver  = self.version_getter()

        # 플랜 유형
        try:
            with appdb.connect(self.db_path) as conn:
                if uid:
                    row = conn.execute(
                        "SELECT plan_type FROM user_bible_plan WHERE user_plan_id=?", (uid,)
                    ).fetchone()
                else:
                    row = conn.execute(
                        "SELECT plan_type FROM sys_bible_plan WHERE plan_id=?", (pid,)
                    ).fetchone()
            self._plan_type = row[0] if row else ''
        except Exception:
            self._plan_type = ''

        # 단계 안내 버튼 (LITURGICAL 전용) — 담는 프레임도 함께 들고 난다
        if self._plan_type == 'LITURGICAL':
            self._stg_grp.pack(side='right', padx=(8, 4))
            self._btn_stage_guide.pack(side='left', padx=(4, 0))
        else:
            self._btn_stage_guide.pack_forget()
            self._stg_grp.pack_forget()

        # Day 표시
        week   = (self._view_day - 1) // 7 + 1
        day_in = (self._view_day - 1) % 7 + 1
        # ★ 내 플랜은 주차가 없다(2026-10-14 87 · 사용자 「주차 개념에 집착할 생각은 없다」) — 일차만
        self.lbl_day.config(
            text=(f"Day {self._view_day}" if uid else f"Day {self._view_day}  (W{week}/D{day_in})"))
        self._day_var.set(str(self._view_day))

        # 완료 버튼 상태
        enr = self._sel_enr
        enr_id  = enr['enrollment_id'] if enr else None
        cur_day = enr['current_day']    if enr else 0
        dur     = enr['duration_days']  if enr else 1
        already = self._is_day_done(enr_id, pid, self._view_day, uid) if enr_id else False
        can_complete = (
            enr_id and
            self._view_day <= dur and
            not already
        )
        # ⚠ **여기서 색과 이름을 다시 박고 있었다.** 만들 때 「오늘 묵상완료」로
        #   지어도 새로 그릴 때마다 「묵상완료」로 되돌아갔고, 배경도 `#27AE60` 이
        #   다시 박혀 테마를 따르지 않았다(2026-08-14 사용자 지적 ⑨).
        #   ⇒ 이름은 한 곳(만들 때)에서만 정하고, 색은 테마의 「좋음」 색을 쓴다.
        _done = i18n.t('PFV_MEDDONE', '✓ 오늘 묵상완료')
        if already:
            self._btn_complete.config(state='disabled',
                                      text=i18n.t('PP_DONEMARK', '✓ 완료됨'),
                                      bg=_ok_bg(True), fg='white')
        elif can_complete:
            self._btn_complete.config(state='normal', text=_done,
                                      bg=_ok_bg(), fg='white')
        else:
            self._btn_complete.config(state='disabled', text=_done,
                                      bg=_ok_bg(True), fg='white')

        # 진도율
        if enr:
            done = max(0, cur_day - 1)
            pct  = int(done * 100 / dur) if dur else 0
            self.lbl_progress.config(text=f"{done}/{dur}일  {pct}%")
        else:
            self.lbl_progress.config(text='')

        # 주차 바
        self._show_week_bar(pid, week, lang)

        # 본문 — 읽는 화면 한 덩어리로 그린다
        self._pane.start()
        # ⚠ **그리기 전에 비운다** — 안 비우면 일차를 옮겼는데 단추가 어제
        #   구간을 붙들고 있어 노트가 엉뚱한 날에 달린다.
        self._note_ctx = self._res_ctx = None
        self._sync_write_btns()
        rows = self._load_rows(pid, self._view_day, lang, uid)
        self._play_verse_ids = self._collect_verse_ids(rows)

        if not rows:
            self._show_placeholder('읽기 데이터가 없습니다.')
        else:
            for i, r in enumerate(rows):
                self._build_section(r, ver, last=(i == len(rows) - 1))
            # ★ 묵상노트 통합 (2026-08-19) — 일차의 끝에 쓰기 단추 + 이 날의 노트.
            #   닻은 그 날의 구절 구간들 중에서 사용자가 고른다(기본 첫 구간).
            self._build_note_block(rows, pid, uid, lang)
        self._pane.finish()

    def _show_placeholder(self, msg: str):
        self._pane.start()
        self._pane.gap()
        self._pane.aside(msg)
        self._pane.finish()

    # ── 일자 탐색 ─────────────────────────────────────────────────────────────

    def _nav_prev(self):
        if self._view_day > 1:
            self._view_day -= 1
            self._render()

    def _nav_next(self):
        dur = self._sel_enr['duration_days'] if self._sel_enr else 365
        if self._view_day < dur:
            self._view_day += 1
            self._render()

    def _nav_today(self):
        if self._sel_enr:
            self._view_day = self._sel_enr['current_day']
            self._render()

    def _nav_jump(self):
        try:
            day = int(self._day_var.get())
        except (ValueError, tk.TclError):
            return
        dur = self._sel_enr['duration_days'] if self._sel_enr else 365
        self._view_day = max(1, min(day, dur))
        self._render()

    # ── 완료 처리 ─────────────────────────────────────────────────────────────

    def _complete_day(self):
        enr = self._sel_enr
        if not enr:
            return
        enr_id   = enr['enrollment_id']
        plan_id  = enr['plan_id']
        uid      = enr.get('user_plan_id')
        view_day = self._view_day
        dur      = enr['duration_days']

        try:
            with appdb.connect(self.db_path) as conn:
                # ★ 317차 — 규칙은 `plan_progress.mark_day` **한 곳**에 있다.
                #   모바일에서 온 「오늘 완료」도 같은 문을 쓴다(두 벌이면 갈린다).
                import plan_progress
                res = plan_progress.mark_day(conn, enr_id, view_day,
                                             date.today().isoformat())
                if not res['ok']:
                    raise ValueError(res['why'])
                try:
                    import usage_stats; usage_stats.bump('plan_progress')
                except Exception:
                    pass
                if res['completed']:
                    try:
                        import usage_stats; usage_stats.bump('plan_complete')
                    except Exception:
                        pass
                    # 묵상경로 — 완주 순간의 「다음 걸음」 추천 (2026-08-17).
                    # 경로가 없으면 조용히 지나간다(팝업 없음).
                    try:
                        import plan_route
                        plan_route.show_completion_popup(
                            self, self.db_path, 'PLAN', plan_id,
                            lang=(self.lang_getter() or 'KO'),
                            on_jump=getattr(self, 'on_route_jump', None))
                    except Exception as _e:
                        print('[route done popup] %s' % _e)
        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), str(e))
            return

        self._load_enrollments()
        new_enr = self._find_enr_for_plan(plan_id)
        if new_enr:
            self._sel_enr = new_enr
            self._view_day = new_enr['current_day']
            self._sync_combo()
            self._render(plan_id)
        else:
            # 플랜이 COMPLETED 상태가 됨 — 다른 활성 플랜으로 전환하거나 빈 화면
            self._sel_enr = (self._active_enrollments[0]
                             if self._active_enrollments else None)
            if self._sel_enr:
                self._view_day = self._sel_enr['current_day']
                self._sync_combo()
                self._render(self._sel_enr['plan_id'])
            else:
                self._enr_var.set(i18n.t('PFV_NO_ENROLLED', '(등록된 플랜 없음)'))
                self._week_bar.pack_forget()
                self._show_placeholder('모든 묵상플랜을 완독했습니다!')
                self.lbl_day.config(text='')
                self.lbl_progress.config(text='')

        if self.on_day_complete:
            self.on_day_complete()

    def _abandon_plan(self):
        """현재 선택된 플랜을 포기/중단 처리한다. 진행 기록은 보존된다."""
        enr = self._sel_enr
        if not enr:
            return
        if not messagebox.askyesno(
            i18n.t('MSG_T_ABORTPLAN', '플랜 중단'),
            i18n.t('MSG_ABORT_PLAN_Q', "진행 중인 플랜을 중단하시겠습니까?\n\n• 지금까지의 묵상 기록은 보존됩니다.\n• 중단된 플랜은 진행중 목록에서 제거됩니다.\n• 다시 시작하려면 '등록하기'를 새로 눌러야 합니다.")
        ):
            return
        try:
            with appdb.connect(self.db_path) as conn:
                conn.execute(
                    "UPDATE user_plan_enrollment "
                    "SET enrollment_status='ABANDONED' "
                    "WHERE enrollment_id=?",
                    (enr['enrollment_id'],)
                )
        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), str(e))
            return
        self._load_enrollments()
        self._sel_enr = self._active_enrollments[0] if self._active_enrollments else None
        if self._sel_enr:
            self._view_day = self._sel_enr['current_day']
            self._sync_combo()
            self._render(self._sel_enr['plan_id'])
        else:
            self._week_bar.pack_forget()
            self._show_placeholder('진행 중인 묵상플랜이 없습니다.')
            self.lbl_day.config(text='')
        if self.on_day_complete:
            self.on_day_complete()

    # ── 데이터 쿼리 ───────────────────────────────────────────────────────────

    def _is_day_done(self, enr_id: int, plan_id: int, day: int,
                     user_plan_id: int | None = None) -> bool:
        try:
            with appdb.connect(self.db_path) as conn:
                if user_plan_id:
                    total = conn.execute(
                        "SELECT COUNT(*) FROM user_plan_schedule "
                        "WHERE user_plan_id=? AND day=?", (user_plan_id, day)
                    ).fetchone()[0]
                    if total == 0:
                        return False
                    done = conn.execute(
                        "SELECT COUNT(*) FROM user_plan_progress upp "
                        "JOIN user_plan_schedule ups ON ups.sched_id=upp.schedule_id "
                        "WHERE upp.enrollment_id=? AND ups.user_plan_id=? AND ups.day=? "
                        "AND upp.record_status='LIVE'",
                        (enr_id, user_plan_id, day)
                    ).fetchone()[0]
                else:
                    total = conn.execute(
                        "SELECT COUNT(*) FROM sys_plan_schedule "
                        "WHERE plan_id=? AND day=?", (plan_id, day)
                    ).fetchone()[0]
                    if total == 0:
                        return False
                    done = conn.execute(
                        "SELECT COUNT(*) FROM user_plan_progress upp "
                        "JOIN sys_plan_schedule ps ON ps.schedule_id=upp.schedule_id "
                        "WHERE upp.enrollment_id=? AND ps.plan_id=? AND ps.day=? "
                        "AND upp.record_status='LIVE'",
                        (enr_id, plan_id, day)
                    ).fetchone()[0]
            return done >= total
        except Exception:
            return False

    def _load_rows(self, plan_id: int, day: int, lang: str,
                   user_plan_id: int | None = None) -> list:
        # ★ 2026-10-13 docs/1.txt 76-14 — 자가진단 플랜의 포커스·질문 `title` 칸에 **내부 코드**(DIAG_P37_D1 ·
        #   DIAG_S38509)가 들어 있어 화면에 그대로 찍혔다. 데이터는 안 고치고(관리자 화면이 그 코드로 찾는다)
        #   읽을 때 가른다 — 제목이 대문자·숫자·밑줄뿐이면 코드다: 포커스는 본문을, 질문 제목은 비운다.
        try:
            with appdb.connect(self.db_path) as conn:
                if user_plan_id:
                    rows = conn.execute(
                        """
                        SELECT ups.sched_id,
                               ups.stage_type, ups.connection_level,
                               ups.start_vid, ups.end_vid, ups.sort_order,
                               COALESCE(CASE WHEN (pf.title GLOB '[A-Z]*_*' AND pf.title NOT GLOB '*[^A-Z0-9_]*') THEN NULLIF(pf.contents,'') ELSE pf.title END, CASE WHEN (pf_en.title GLOB '[A-Z]*_*' AND pf_en.title NOT GLOB '*[^A-Z0-9_]*') THEN NULLIF(pf_en.contents,'') ELSE pf_en.title END,
                                        ups.meditation_focus)         AS focus,
                               COALESCE(CASE WHEN (pq.title GLOB '[A-Z]*_*' AND pq.title NOT GLOB '*[^A-Z0-9_]*') THEN NULL ELSE pq.title END, CASE WHEN (pq_en.title GLOB '[A-Z]*_*' AND pq_en.title NOT GLOB '*[^A-Z0-9_]*') THEN NULL ELSE pq_en.title END)          AS q_title,
                               COALESCE(pq.contents, pq_en.contents)    AS q_body,
                               COALESCE(pt.title, pt_en.title)          AS peri_title,
                               COALESCE(pd.contents, pd.title,
                                        pd_en.contents, pd_en.title)    AS peri_desc,
                               ups.unit_key
                        FROM user_plan_schedule ups
                        LEFT JOIN sys_text_asset pf
                               ON 0 AND pf.clicked_id=ups.sched_id
                              AND pf.text_type='PLAN_FOCUS' AND pf.lang_code=?
                              AND pf.record_status='LIVE'
                        LEFT JOIN sys_text_asset pq
                               ON 0 AND pq.clicked_id=ups.sched_id
                              AND pq.text_type='PLAN_QUESTION' AND pq.lang_code=?
                              AND pq.record_status='LIVE'
                        -- ★ 폴백은 언제나 영어
                        LEFT JOIN sys_text_asset pf_en
                               ON 0 AND pf_en.clicked_id=ups.sched_id
                              AND pf_en.text_type='PLAN_FOCUS' AND pf_en.lang_code='EN'
                              AND pf_en.record_status='LIVE'
                        LEFT JOIN sys_text_asset pq_en
                               ON 0 AND pq_en.clicked_id=ups.sched_id
                              AND pq_en.text_type='PLAN_QUESTION' AND pq_en.lang_code='EN'
                              AND pq_en.record_status='LIVE'
                        LEFT JOIN sys_pericope_asset pa
                               ON pa.start_vid=ups.start_vid AND pa.end_vid=ups.end_vid
                              AND pa.peri_type='BODY'
                        LEFT JOIN sys_text_asset pt
                               ON pt.clicked_id=pa.pericope_id
                              AND pt.text_type='PERI_TITLE' AND pt.lang_code=?
                              AND COALESCE(pt.record_status,'LIVE')='LIVE'
                        LEFT JOIN sys_text_asset pt_en
                               ON pt_en.clicked_id=pa.pericope_id
                              AND pt_en.text_type='PERI_TITLE' AND pt_en.lang_code='EN'
                              AND COALESCE(pt_en.record_status,'LIVE')='LIVE'
                        LEFT JOIN sys_text_asset pd
                               ON pd.clicked_id=pa.pericope_id
                              AND pd.text_type='PERI_DESC' AND pd.lang_code=?
                              AND pd.record_status='LIVE'
                        LEFT JOIN sys_text_asset pd_en
                               ON pd_en.clicked_id=pa.pericope_id
                              AND pd_en.text_type='PERI_DESC' AND pd_en.lang_code='EN'
                              AND pd_en.record_status='LIVE'
                        WHERE ups.user_plan_id=? AND ups.day=?
                        ORDER BY ups.sort_order
                        """,
                        (lang, lang, lang, lang, user_plan_id, day)
                    ).fetchall()
                    # ★ 2026-10-14 87 — 내 플랜의 포커스는 제 칸(meditation_focus), 질문은 plan_config.questions[일차].
                    #   ⚠ 그전에는 sys_text_asset 의 PLAN_FOCUS 를 sched_id 로 찾았다 — schedule_id 와 다른 번호 공간이라
                    #     남의 플랜 포커스가 떴다(위 JOIN 은 `ON 0` 으로 껐다).
                    try:
                        import plan_share as _PS
                        _q = (_PS._cfg(conn, user_plan_id).get('questions') or {}).get(str(day)) or ''
                    except Exception:
                        _q = ''
                    if _q and rows:
                        rows = [tuple(rows[0][:7]) + (None, _q) + tuple(rows[0][9:])] + list(rows[1:])
                    return rows
                return conn.execute(
                    """
                    SELECT ps.schedule_id,
                           ps.stage_type, ps.connection_level,
                           ps.start_vid, ps.end_vid, ps.sort_order,
                           COALESCE(CASE WHEN (pf.title GLOB '[A-Z]*_*' AND pf.title NOT GLOB '*[^A-Z0-9_]*') THEN NULLIF(pf.contents,'') ELSE pf.title END, CASE WHEN (pf_en.title GLOB '[A-Z]*_*' AND pf_en.title NOT GLOB '*[^A-Z0-9_]*') THEN NULLIF(pf_en.contents,'') ELSE pf_en.title END,
                                    ps.meditation_focus)            AS focus,
                           COALESCE(CASE WHEN (pq.title GLOB '[A-Z]*_*' AND pq.title NOT GLOB '*[^A-Z0-9_]*') THEN NULL ELSE pq.title END, CASE WHEN (pq_en.title GLOB '[A-Z]*_*' AND pq_en.title NOT GLOB '*[^A-Z0-9_]*') THEN NULL ELSE pq_en.title END, CASE WHEN (ppq.title GLOB '[A-Z]*_*' AND ppq.title NOT GLOB '*[^A-Z0-9_]*') THEN NULL ELSE ppq.title END)      AS q_title,
                           COALESCE(pq.contents, pq_en.contents,
                                    ppq.contents)                   AS q_body,
                           COALESCE(pt.title, pt_en.title)          AS peri_title,
                           COALESCE(pd.contents, pd.title,
                                    pd_en.contents, pd_en.title)    AS peri_desc,
                           ps.unit_key
                    FROM sys_plan_schedule ps
                    LEFT JOIN sys_text_asset pf
                           ON pf.clicked_id=ps.schedule_id
                          AND pf.text_type='PLAN_FOCUS' AND pf.lang_code=?
                          AND pf.record_status='LIVE'
                    LEFT JOIN sys_text_asset pq
                           ON pq.clicked_id=ps.schedule_id
                          AND pq.text_type='PLAN_QUESTION' AND pq.lang_code=?
                          AND pq.record_status='LIVE'
                    -- ★ **폴백은 언제나 영어** (2026-08-14 설계 확정)
                    LEFT JOIN sys_text_asset pf_en
                           ON pf_en.clicked_id=ps.schedule_id
                          AND pf_en.text_type='PLAN_FOCUS' AND pf_en.lang_code='EN'
                          AND pf_en.record_status='LIVE'
                    LEFT JOIN sys_text_asset pq_en
                           ON pq_en.clicked_id=ps.schedule_id
                          AND pq_en.text_type='PLAN_QUESTION' AND pq_en.lang_code='EN'
                          AND pq_en.record_status='LIVE'
                    LEFT JOIN sys_pericope_asset pa
                           ON pa.start_vid=ps.start_vid AND pa.end_vid=ps.end_vid
                          AND pa.peri_type='BODY'
                    LEFT JOIN sys_text_asset ppq
                           ON ppq.clicked_id=pa.pericope_id
                          AND ppq.text_type='PERI_QUESTION' AND ppq.lang_code=?
                          AND ppq.record_status='LIVE'
                    LEFT JOIN sys_text_asset pt
                           ON pt.clicked_id=pa.pericope_id
                          AND pt.text_type='PERI_TITLE' AND pt.lang_code=?
                    LEFT JOIN sys_text_asset pt_en
                           ON pt_en.clicked_id=pa.pericope_id
                          AND pt_en.text_type='PERI_TITLE' AND pt_en.lang_code='EN'
                    LEFT JOIN sys_text_asset pd
                           ON pd.clicked_id=pa.pericope_id
                          AND pd.text_type='PERI_DESC' AND pd.lang_code=?
                          AND pd.record_status='LIVE'
                    LEFT JOIN sys_text_asset pd_en
                           ON pd_en.clicked_id=pa.pericope_id
                          AND pd_en.text_type='PERI_DESC' AND pd_en.lang_code='EN'
                          AND pd_en.record_status='LIVE'
                    WHERE ps.plan_id=? AND ps.day=?
                    ORDER BY ps.sort_order
                    """,
                    (lang, lang, lang, lang, lang, plan_id, day)
                ).fetchall()
        except Exception:
            return []

    def _passage_label(self, vid: int | None) -> str:
        if not vid:
            return '—'
        lang = self.lang_getter()
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT bn.short_name, bi.chapter, bi.verse "
                    "FROM bible_index bi "
                    "JOIN book_names bn ON bi.bcode=bn.book_code AND bn.lang_code=? "
                    "WHERE bi.verse_id=?", (_ref_lang(), vid)
                ).fetchone()
            return (verse_ref.label(verse_ref.SCOPE_BOOK, row[0], row[1], row[2])
                    if row else str(vid))
        except Exception:
            return str(vid)

    def _load_verse_rows(self, svid: int | None, evid: int | None,
                         ver: str) -> list:
        if not svid:
            return []
        end  = evid if evid else svid
        lang = self.lang_getter()
        # ⚠⚠ 구간 나열은 **차례(sort_order)로**(§verse_range) — 번호로
        #   세면 마이어 「아가서 6장」 하루치가 13,488절이 된다(실측).
        import verse_range as _vr
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT bi.verse_id, bn.short_name, bi.chapter, bi.verse, "
                    "       COALESCE(bc.verse_text, '') "
                    "FROM bible_index bi "
                    "JOIN book_names bn ON bi.bcode=bn.book_code AND bn.lang_code=? "
                    "LEFT JOIN bible_content bc "
                    "  ON bc.verse_id=bi.verse_id AND bc.version_code=? "
                    "WHERE " + _vr.between_sql('bi.verse_id') +
                    " ORDER BY bi.sort_order",
                    [lang, ver] + _vr.between_args(svid, end)
                ).fetchall()
            return [(r[0], f"{r[1]} {r[2]}:{r[3]}", r[4]) for r in rows]
        except Exception:
            return []

    def _collect_verse_ids(self, rows: list) -> list[int]:
        pairs = [(r[3], r[4]) for r in rows if r[3] and r[4]]
        if not pairs:
            return []
        import verse_range as _vr          # §verse_range — 차례로 나열
        try:
            with appdb.connect(self.db_path) as conn:
                result = []
                for svid, evid in pairs:
                    result.extend(r[0] for r in conn.execute(
                        "SELECT bi.verse_id FROM bible_index bi WHERE "
                        + _vr.between_sql('bi.verse_id')
                        + " ORDER BY bi.sort_order",
                        _vr.between_args(svid, evid)
                    ).fetchall())
            seen: set[int] = set()
            return [v for v in result if not (v in seen or seen.add(v))]
        except Exception:
            return []

    # ── 섹션 렌더링 ───────────────────────────────────────────────────────────

    # ⚠ 판을 늘어놓는 순서는 `lang_combo.sort_key` 가 단일 소스다.

    def _get_ui_str(self, string_id: str, lang: str, fallback: str = '') -> str:
        """ui_strings에서 string_id를 lang_code 기준으로 조회. 없으면 fallback."""
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT string_value FROM ui_strings "
                    "WHERE string_id=? AND UPPER(lang_code)=UPPER(?)",
                    (string_id, lang)
                ).fetchone()
                return row[0] if row else fallback
        except Exception:
            return fallback

    _CJK_LANGS = frozenset({'KO', 'ZH', 'JA'})

    def _build_book_section(self, unit_key: str, sort_ord: int, focus: str | None):
        """BOOK_TEXT stage 전용 렌더러.
        사용자 lang_code에 해당하는 variant만 표시 (엄격한 필터).
        라벨은 ui_strings에서 조회 (하드코딩 없음).
        """
        try:
            unit_id = int(unit_key[5:])
        except (ValueError, TypeError, AttributeError):
            return

        lang = self._disp_lang()

        try:
            with appdb.connect(self.db_path) as conn:
                # ⚠ 제목은 **번역 덮개를 먼저** 본다 (2026-08-23). 도서 화면
                #   (`p1_reading_view`)은 진작 `BOOK_UNIT_LABEL` 을 COALESCE 로
                #   읽는데 플랜 화면 두 곳만 `unit_label` 을 직접 읽어, 마이어
                #   제목을 두 언어로 채운 뒤에도 여기만 영어 원제가 남았다.
                meta = conn.execute(
                    "SELECT COALESCE(ta.contents, bu.unit_label) "
                    "  FROM sys_book_unit bu "
                    "  LEFT JOIN sys_text_asset ta "
                    "         ON ta.text_type='BOOK_UNIT_LABEL' "
                    "        AND ta.clicked_id = bu.unit_id "
                    "        AND UPPER(ta.lang_code) = ? "
                    "        AND ta.record_status = 'LIVE' "
                    " WHERE bu.unit_id = ?",
                    (lang.upper(), unit_id)
                ).fetchone()
                # ⚠ **여기서 언어로 거르지 않는다** (2026-08-14). 예전에는 EN 판과
                #   사용자 언어 판만 뽑아 왔는데, 그러면 상단 콤보에 올라온 줄을
                #   골라도 이 함수가 그것을 안 갖고 있어 빈 화면이 됐다.
                #   **콤보가 있는 것을 올리고, 여기서는 그 고른 것을 꺼낸다.**
                var_rows = conn.execute(
                    "SELECT text_variant, UPPER(lang_code), body_text "
                    "FROM sys_book_unit_text "
                    "WHERE unit_id=? AND record_status='LIVE' ORDER BY text_id",
                    (unit_id,)
                ).fetchall()
        except Exception:
            return

        if not meta:
            return

        unit_label = meta[0] or ''
        # (변형, 언어) → 본문
        by_pair = {(v, lc): bt for v, lc, bt in var_rows}

        # ★ 도서 본문도 **읽는 흐름 안에** 그린다 (2026-08-14).
        p = self._pane
        p.title(f'{sort_ord}. {_STAGE_LABEL["BOOK_TEXT"]}', level=2)
        if unit_label:
            p.aside(unit_label)
        if focus:
            p.aside(f'◆ {focus}')

        if not by_pair:
            p.aside(self._get_ui_str('BOOK_NO_CONTENT', lang,
                                     'Translation not yet available.'))
            return

        # ★ **어느 판을 볼지는 상단 표시 언어 콤보가 정한다** (2026-08-14).
        #   ⚠ 예전에는 이 함수가 콤보를 **자기가 만들어** 상단에 심었다. 그래서
        #     묵상플랜 네 갈래 가운데 도서묵상만 콤보가 있었고, 설명문 언어는
        #     아예 고를 수 없었다. 지금은 만들지 않고 **고른 값을 읽기만** 한다.
        want = (self._disp_variant(), lang)
        body = by_pair.get(want)
        if not body:
            body = next((b for (v, lc), b in by_pair.items() if lc == lang), None)
        # ★ **폴백은 언제나 영어** (2026-08-14 설계 확정)
        if not body and lang != 'EN':
            # 언어 콤보를 걷었으므로(76-9) 다른 언어를 보일 때는 그렇다고 적는다
            p.aside(i18n.t('PFV_LANG_FALLBACK', '이 글은 아직 설정한 언어로 준비되지 않아 영어로 보입니다.'))
        if not body:
            body = (by_pair.get(('ORIGINAL', 'EN'))
                    or by_pair.get(('MODERN_EN', 'EN')))
        if not body:
            body = next(iter(by_pair.values()), '')

        # ⚠⚠ **여기서 `state='disabled'` 로 잠그면 안 된다** (2026-08-22 실측).
        #   `ReadingPane` 은 `start()`=normal → 쓰기 → `finish()`=disabled 인데,
        #   중간에 잠그면 **그 뒤에 쓰는 것이 전부 조용히 버려진다** — 도서묵상
        #   플랜에서 BOOK_TEXT 다음의 **CORE 구절·SUPPORT·묵상노트 목록·연구자료
        #   칩이 통째로 안 그려지고 있었다**(사용자 「연결구절 표시항목이 전혀
        #   없다」의 정체. 오류도 안 났다).
        #   ⇒ 날것으로 넣지 말고 **pane 의 API 를 쓴다** — 같은 `book` 태그다.
        # ★ `body` → `book_text` (2026-08-28) — 운문을 한 단 안쪽으로 그린다.
        #   ⚠ 도서 본문 전용이다. 설명문·포커스는 그대로 `body`/`aside`.
        p.book_text(body or '')
        p.gap()

    def _build_section(self, row: tuple, ver: str, last: bool = False):
        (sched_id, stage, conn_lvl, svid, evid, sort_ord,
         focus, q_title, q_body, peri_title, peri_desc, unit_key) = row

        if stage == 'BOOK_TEXT':
            self._build_book_section(unit_key, sort_ord, focus)
            return

        stage_str = (peri_title or i18n.t('UI_PLAN_STAGE_'+str(stage), _STAGE_LABEL.get(stage, stage or '—'))
                     if self._plan_type != 'LITURGICAL'
                     else i18n.t('UI_PLAN_STAGE_'+str(stage), _STAGE_LABEL.get(stage, stage or '—')))
        display_str = (stage_str[:50] + '…') if len(stage_str) > 50 else stage_str
        bg_hdr = _STAGE_BG.get(stage, '#2E4053')

        # ★ 읽는 화면으로 그린다 — 상자를 쌓지 않고 **글의 흐름**으로 (2026-08-14).
        p = self._pane
        s_lbl = self._passage_label(svid)
        e_lbl = self._passage_label(evid)
        range_str = f'{s_lbl} ~ {e_lbl}' if e_lbl and e_lbl != s_lbl else s_lbl
        # ★ 차례는 **제목 → 범위 → 구절 → 설명문** (2026-08-14 사용자 지정).
        #   ⚠ 설명문을 구절 **앞**에 두면 본문을 읽기 전에 해설부터 읽게 된다.
        #     읽는 순서는 본문이 먼저다.
        p.title(f'{sort_ord}. {display_str}', level=2)
        if range_str:
            p.aside(range_str)

        # 구절 — 약명은 **눌리는 글자**로 남는다(P2·엔티티 연동 그대로)
        verse_rows = self._load_verse_rows(svid, evid, ver)
        if verse_rows:
            for vid, ref, vtext in verse_rows:
                p.verse(ref, vtext, payload=vid)
        else:
            p.aside(i18n.t('COMMON_NOBODYDATA', '(본문 데이터 없음)'))

        # 묵상 설명문 — 본문 **뒤**. ⚠ 빈 줄 하나로 확실히 가른다(2026-08-14).
        if focus or peri_desc or q_title or q_body:
            p.gap()
        if focus:
            p.aside(f'◆ {focus}')
        if peri_desc:
            p.aside(peri_desc)
        if q_title:
            p.aside(f'? {q_title}')
        if q_body:
            p.aside(q_body)
        if not last:
            p.gap()

    # ── 묵상노트 (일차 단위 블록) — 통합 저장소 (2026-08-19) ───────────────────

    def _note_src(self, pid, uid, lang):
        """이 플랜·일차의 맥락 (키, 라벨). 키는 plan_code 기반 글자 키."""
        code = title = ''
        try:
            with appdb.connect(self.db_path) as conn:
                if uid:
                    r = conn.execute("SELECT plan_code FROM user_bible_plan "
                                     "WHERE user_plan_id=?", (uid,)).fetchone()
                    code = (r[0] or 'U%d' % uid) if r else 'U%d' % uid
                    r = conn.execute(
                        "SELECT COALESCE(NULLIF(contents,''), title) "
                        "FROM user_text_asset WHERE text_type='PLAN_TITLE' "
                        "AND clicked_id=? LIMIT 1", (uid,)).fetchone()
                else:
                    r = conn.execute("SELECT plan_code FROM sys_bible_plan "
                                     "WHERE plan_id=?", (pid,)).fetchone()
                    code = (r[0] or str(pid)) if r else str(pid)
                    r = conn.execute(
                        "SELECT COALESCE(NULLIF(contents,''), title) "
                        "FROM sys_text_asset WHERE text_type='PLAN_TITLE' "
                        "AND clicked_id=? AND UPPER(lang_code)=UPPER(?) LIMIT 1",
                        (pid, lang)).fetchone()
                title = (r[0] or '') if r else ''
        except Exception:
            pass
        key = 'PLAN:%s:%d' % (code, self._view_day)
        label = '%s · %s · %d%s' % (
            i18n.t('MN_SRC_PLAN', '플랜'), title or code, self._view_day,
            i18n.t('PFV_DAY_SUFFIX', '일차'))
        return key, label

    on_context = None           # P4 연구/설교노트 자리 거르개 (ctx) — 79-2
    on_note_ai = None           # 노트 [AI 분석] 콜백 (vid, end_vid) — 2026-10-13 76-15 · user_main 배선
    on_research_new = None      # 연구자료 새 글 콜백 (2026-08-19 0.txt ⑩ — user_main 배선)

    # ── 상단 쓰기 단추 (2026-08-22 사용자 지시로 하단에서 올라왔다) ──────────
    #   ⚠ 단추는 위에 있고 **문맥은 그릴 때 아래에서 채워진다.** 그리기 전에
    #     비워 두지 않으면 **어제 날짜의 구간에 오늘 노트가 달린다.**
    _note_ctx: dict | None = None
    _res_ctx: dict | None = None

    def _sync_write_btns(self):
        """문맥이 있는 것만 보인다 — 눌러도 아무 일 없는 단추는 고장으로 읽힌다."""
        for btn, ctx in ((getattr(self, '_btn_note', None), self._note_ctx),
                         (getattr(self, '_btn_res', None), self._res_ctx)):
            if btn is None:
                continue
            if ctx:
                if not btn.winfo_ismapped():
                    btn.pack(side='left', padx=(0, 4))
            else:
                btn.pack_forget()
        # ★ 2026-10-13 79-3 (2) — 그날 쓴 노트 수를 단추에(도서노트와 같다 · 0 이면 안 적는다)
        b = getattr(self, '_btn_note', None)
        if b is not None and self._note_ctx:
            n = 0
            try:
                import medi_note
                n = len(medi_note.notes_for_context(self.db_path, self._note_ctx['key']))
            except Exception:
                pass
            b.config(text=i18n.t('MN_WRITE', '묵상노트 쓰기') + (' (%d)' % n if n else ''))

    def _open_note_editor(self, rec=None):
        """묵상노트 쓰기 띠 — 상단 단추와 목록의 [수정] 이 함께 쓴다."""
        ctx = self._note_ctx
        if not ctx:
            return
        import medi_note
        old = getattr(self, '_note_editor_f', None)
        if old is not None and old.winfo_exists():
            old.destroy()
        f = medi_note.NoteBar(self, self.db_path, ctx['cands'],
                              src_key=ctx['key'], src_label=ctx['label'],
                              lang=ctx['lang'], rec=rec,
                              on_done=lambda: self._render())
        self._note_editor_f = f
        # ★ 2026-10-13 76-11 — **보이기 전에 칠한다**. 그전에는 띄운 뒤 앱의 칠하기가 돌 때까지
        #   흰 바탕이 잠깐 비쳤다(다크 모드 · 본문을 눌러야 색이 바뀌었다).
        try:
            import ui_theme as _uth
            _uth.paint(f)
        except Exception:
            pass
        # ⚠ expand 자식 뒤에 pack 한 bottom 띠는 1×1 로 안 보인다 — 순서를 당긴다
        kids = [c for c in self.winfo_children()
                if c is not f and c.winfo_ismapped()]
        if kids:
            f.pack(side='bottom', fill='x', padx=4, pady=4, before=kids[0])
        else:
            f.pack(side='bottom', fill='x', padx=4, pady=4)

    def _write_research(self):
        """연구자료 새 글 — 그 날 첫 구간을 미리 걸어 준다."""
        ctx = self._res_ctx
        if not ctx or not callable(self.on_research_new):
            return
        self.on_research_new({
            'ref_type': 'STUDY',
            'book_title': ctx['label'],   # 출처 줄에 「플랜 · 제목 · N일차」
            'unit_label': '',
            'start_vid': ctx['start_vid'],
        })

    def _build_research_line(self, rows, pid, uid, lang):
        """그 날 구간에 **구절로** 연결된 연구자료 + [연구자료 쓰기] (0.txt ⑩ 절충안).

        ★ 플랜을 연결의 **앵커로 쓰지 않는다** (사용자 확정) — 글은 구절에 연결되고,
          여기서는 그 날 구간과 겹치는 글을 **표시만** 한다. 쓰기 버튼은 그 날 첫
          구간을 미리 걸어 준 새 글로 보낸다(도서 화면의 [연구자료]와 같은 흐름).
        """
        ranges = []
        for r in rows:
            if r[3]:
                ranges.append((r[3], r[4] or r[3]))
        if not ranges:
            return
        found, seen = [], set()
        # ⚠⚠ 겹침 판정도 **차례로**(§verse_range) — `a.verse_id` 는 대표 칸이라
        #   번호로 견주면 절체계 이형 절이 엉뚱한 날에 걸린다.
        import verse_range as _vr
        try:
            with appdb.connect(self.db_path) as conn:
                for sv, ev in ranges:
                    _so2 = [r[0] for r in conn.execute(
                        "SELECT (SELECT sort_order FROM bible_index"
                        "         WHERE verse_id=?) UNION ALL"
                        " SELECT (SELECT sort_order FROM bible_index"
                        "         WHERE verse_id=?)", (sv, ev))]
                    if len(_so2) != 2 or None in _so2:
                        continue
                    _so2 = [min(_so2), max(_so2)]
                    for rid, title in conn.execute(
                        "SELECT DISTINCT a.ref_id, "
                        "       COALESCE(NULLIF(a.title,''), '(제목 없음)') "
                        "FROM user_ref_asset a "
                        # ★ 2026-08-24 통합 표(`UREF_VERS`)
                        "LEFT JOIN userdb.user_link_asset l "
                        "  ON l.clicked_id=a.ref_id AND l.link_type='UREF_VERS' "
                        " AND COALESCE(l.record_status,'LIVE')='LIVE' "
                        "WHERE a.record_status='LIVE' "
                        "  AND ((SELECT sort_order FROM bible_index"
                        "         WHERE verse_id=a.verse_id) BETWEEN ? AND ? "
                        "    OR (%s) "
                        # ★ 새 연결 표 — 2026-08-21 이후 붙인 것은 여기에 있다.
                        "    OR a.ref_id IN (%s))"
                        % (_vr.overlaps_sql('l', 'target_id', 'end_id'),
                           link_picker.refs_overlapping_sql()),
                            _so2 + _vr.overlaps_args(sv, ev)
                            + link_picker.refs_overlapping_args(sv, ev)):
                        if rid not in seen:
                            seen.add(rid)
                            found.append((rid, title))
        except Exception as e:
            print('[plan research] %s' % e)
        # ★ 쓰기에 필요한 문맥을 **상태로 넘긴다** — 단추가 상단 bar 로 갔으므로
        #   그 자리에서 이 날의 구간·출처를 알 수 없다(2026-08-22 사용자
        #   「버튼 이동할 때 연결된 부분이 유실되지 않도록 주의하라」).
        _k, _lb = self._note_src(pid, uid, lang)
        self._res_ctx = {'label': _lb, 'start_vid': ranges[0][0]}
        self._sync_write_btns()
        # ★ 79-2 — P4 연구/설교노트가 이 하루로 미리 걸린다
        if callable(self.on_context):
            try:
                self.on_context({'vid': ranges[0][0], 'label': _lb[:40],
                                 'user_ids': {r for r, _t in found},
                                 'src': {'ref_type': 'STUDY', 'book_title': _lb, 'unit_label': '',
                                         'start_vid': ranges[0][0]}})
            except Exception as e:
                print('[plan ctx] %s' % e)
        p = self._pane
        p.gap()
        if not found:
            return                        # 칩이 없으면 줄 자체를 안 그린다

        def _mk(parent):
            fr = tk.Frame(parent)
            for rid, title in found[:6]:
                short = title if len(title) <= 22 else title[:22] + '…'
                lb = tk.Label(fr, text='· ' + short, fg='#2E86C1',
                              font=('', 9), cursor='hand2')
                lb.pack(side='left', padx=(0, 8))
                lb.bind('<Button-1>',
                        lambda _e, r=rid: (callable(self.on_research_new)
                                           and self.on_research_new({'open_ref': r})))
            return fr
        p.widget(_mk, pad=(0, 1))

    def _build_note_block(self, rows, pid, uid, lang):
        """읽는 칸 끝의 **노트 목록**. 쓰기 단추는 상단 bar 에 있다(2026-08-22)."""
        import medi_note
        self._build_research_line(rows, pid, uid, lang)
        key, label = self._note_src(pid, uid, lang)
        # 닻 후보 — 이 날의 구절 구간들 (중복 제거, 스케줄 순서)
        cands, seen = [], set()
        for r in rows:
            svid, evid = r[3], r[4]
            if not svid or (svid, evid) in seen:
                continue
            seen.add((svid, evid))
            cands.append((medi_note.verse_label(self.db_path, svid, evid, lang),
                          svid, evid or svid))
        if not cands:
            return
        # ★ 닻 후보·출처를 **상태로** — 쓰기 단추가 상단 bar 에 있어 그 자리에서
        #   이 날의 구간을 알 수 없다. 유실되면 노트가 미아가 된다(notes.md §0-1).
        self._note_ctx = {'cands': cands, 'key': key, 'label': label,
                          'lang': lang}
        self._sync_write_btns()
        p = self._pane
        p.gap()
        _open = self._open_note_editor
        for n in medi_note.notes_for_context(self.db_path, key):
            date = (n['updated_at'] or n['created_at'] or '')[:10]
            head = date + '  ▸ ' + (n.get('verse_label') or '')

            def _mk(parent, rec=n, h=head):
                fr = tk.Frame(parent)
                tk.Label(fr, text=h).pack(side='left', padx=(0, 4))
                tk.Button(fr, text=i18n.t('COMMON_EDIT', '수정'), bd=1, padx=4,
                          pady=0, font=('', 8), cursor='hand2',
                          command=lambda: _open(rec)).pack(side='left')
                # ★ 2026-10-13 76-15 — 그 노트의 구간으로 AI 묵상분석(P2 [AI묵상분석] 과 같은 문).
                #   공유(SNS)는 폰에서만 한다(사용자 확정) — PC 에는 두지 않는다.
                if callable(self.on_note_ai) and rec.get('start_vid'):
                    tk.Button(fr, text=i18n.t('PFV_NOTE_AI', 'AI 분석'), bd=1, padx=4,
                              pady=0, font=('', 8), cursor='hand2',
                              command=lambda r=rec: self.on_note_ai(
                                  r['start_vid'], r.get('end_vid'))).pack(side='left', padx=(4, 0))
                return fr
            p.widget(_mk, pad=(1, 0))
            p.aside(n.get('body') or '')

    def _on_ref_click(self, payload):
        """읽는 화면의 절 약명을 눌렀을 때 — 예전 버튼과 **같은 곳으로** 간다."""
        if isinstance(payload, int):
            self._on_click(payload)

    # ── 클릭 연동 ─────────────────────────────────────────────────────────────

    def _on_click(self, vid: int):
        if vid and self.on_verse_select:
            self.on_verse_select(vid)

    # ── 주차 바 ───────────────────────────────────────────────────────────────

    def _show_section_bar(self, uid: int, day: int):
        """내 플랜의 「구간 제목」 — 오늘이 든 구간(그 날 이전에 시작한 마지막 구간) (2026-10-14 87 · 주차 대신)."""
        try:
            import plan_share as _PS
            with appdb.connect(self.db_path) as conn:
                secs = _PS._cfg(conn, uid).get('sections') or {}
        except Exception:
            secs = {}
        starts = sorted(int(k) for k in secs if str(k).isdigit() and int(k) <= day)
        if not starts:
            self._week_bar.pack_forget()
            return
        d0 = starts[-1]
        self.lbl_week_title.config(text='  ' + secs[str(d0)])
        self.lbl_week_desc.config(text='')
        self._week_bar.pack(fill='x', after=self._ctrl_bar)

    def _show_week_bar(self, plan_id: int, week: int, lang: str):
        _uid = getattr(self, '_view_uid', None)
        if _uid:
            self._show_section_bar(_uid, getattr(self, '_view_day', 1))
            return
        if self._plan_type != 'LITURGICAL':
            self._week_bar.pack_forget()
            return
        clicked_id = plan_id * 10000 + week
        try:
            with appdb.connect(self.db_path) as conn:
                t_row = conn.execute(
                    "SELECT title FROM sys_text_asset "
                    "WHERE clicked_id=? AND text_type='WEEK_TITLE' "
                    "AND lang_code=? AND record_status='LIVE' LIMIT 1",
                    (clicked_id, lang)
                ).fetchone()
                d_row = conn.execute(
                    "SELECT contents FROM sys_text_asset "
                    "WHERE clicked_id=? AND text_type='WEEK_DESC' "
                    "AND lang_code=? AND record_status='LIVE' LIMIT 1",
                    (clicked_id, lang)
                ).fetchone()
        except Exception:
            self._week_bar.pack_forget()
            return
        title = (t_row[0] if t_row and t_row[0] else '').strip()
        desc  = (d_row[0] if d_row and d_row[0] else '').strip()
        if not title and not desc:
            self._week_bar.pack_forget()
            return
        self.lbl_week_title.config(
            text=f"  Week {week}" + (f"  —  {title}" if title else ''))
        self.lbl_week_desc.config(text=desc)
        self._week_bar.pack(fill='x', after=self._ctrl_bar)
        self._week_bar_expanded = True
        self._week_body.pack(fill='x')
        self._btn_week.config(text='▲')

    def _toggle_week_bar(self):
        if self._week_bar_expanded:
            self._week_body.pack_forget()
            self._btn_week.config(text='▼')
            self._week_bar_expanded = False
        else:
            self._week_body.pack(fill='x')
            self._btn_week.config(text='▲')
            self._week_bar_expanded = True

    # ── 오디오 ────────────────────────────────────────────────────────────────

    @property
    def _play_settings(self):
        """재생 설정 — 처음 읽을 때 만든다.

        ⚠ **property 다** — 이 이름을 읽는 자리가 여럿이라 각각 고치면 하나는
          빠진다. 읽는 순간 저절로 만들어지게 한다.
        """
        if self.__pset is None:
            from voice_play_bar import PlaySettings
            self.__pset = PlaySettings()
        return self.__pset

    def _get_player(self):
        """음성 재생기 — **처음 쓸 때 만든다**(무거운 import 를 시작에서 뺀다).

        ⚠ 실측 `voice_bible` 은 `sounddevice`·`numpy` 를 끌어와 **214ms** 다.
          앱을 켤 때마다 그 값을 치를 이유가 없다.
        """
        if self._player is None:
            from voice_bible import Player
            self._player = Player()
        return self._player

    def _play_start(self):
        from voice_play_bar import build_playlist
        playlist = build_playlist(self.db_path, self._play_verse_ids,
                                  self.version_getter(), self._play_settings)
        if not playlist:
            return
        self._get_player().play_sequence(
            playlist,
            gap_sec=self._play_settings.gap_sec,
            on_verse_start=(lambda vid: self.on_verse_select(vid))
                if self._play_settings.highlight and self.on_verse_select else None,
        )

    def _play_stop(self):
        if self._player is not None:
            self._player.stop()

    def _open_play_settings(self):
        from voice_play_bar import open_play_settings_popup
        open_play_settings_popup(
            self._btn_play,
            self.db_path,
            self.version_getter(),
            self._play_verse_ids,
            self._play_settings,
            on_confirm=lambda s: None,
        )

    # ── 단계 안내 팝업 ────────────────────────────────────────────────────────

    def _open_stage_guide(self):
        top = tk.Toplevel(self)
        top.title(i18n.t('FOCUS_STAGEGUIDE', '묵상 단계 안내'))
        top.geometry('440x340')
        top.configure(bg=_c('bg', '#FAFAFA'))
        top.grab_set()
        tk.Label(top, text=i18n.t('FOCUS_STAGEGUIDE','묵상 단계 안내'),
                 bg=_c('bg', '#FAFAFA'), fg=_c('fg', '#1A5276'),
                 font=('Malgun Gothic', 11, 'bold'), pady=10).pack(fill='x')
        guide = [
            ('사건  (EVENT)',       '#1A5276',
             '성경의 역사적 사건/이야기 본문을 읽고 그 흐름을 파악합니다.'),
            ('율법  (LAW)',         '#6E2F00',
             '사건과 연결된 율법/규례를 읽으며 하나님의 요구를 확인합니다.'),
            ('확장  (EXPANSION)',   '#1E5631',
             '선지자/시편 등 관련 본문을 통해 주제를 더 넓게 바라봅니다.'),
            ('성취  (FULFILLMENT)', '#4A235A',
             '신약에서 이 주제가 예수님 안에서 어떻게 성취되었는지 봅니다.'),
            ('적용  (APPLICATION)', '#7B241C',
             '오늘 나의 삶에 어떻게 적용할지 묵상하고 결단합니다.'),
            ('읽기  (READ)',        '#2E4053',
             '통독 구간: 흐름을 따라 읽어 나갑니다.'),
        ]
        inner = tk.Frame(top, bg=_c('bg', '#FAFAFA'))
        inner.pack(expand=True, fill='both', padx=12, pady=(0, 8))
        for label, bg, desc in guide:
            row = tk.Frame(inner, bg=_c('bg', '#FAFAFA'), pady=2)
            row.pack(fill='x')
            tk.Label(row, text=label, bg=bg, fg=_c('fg', '#1A5276'),
                     font=('Malgun Gothic', 9, 'bold'),
                     width=18, anchor='w', padx=6, pady=4).pack(side='left')
            tk.Label(row, text=desc, bg=_c('panel', '#F4F6F7'), fg='#D5D8DC',
                     font=('Malgun Gothic', 9),
                     wraplength=270, justify='left', anchor='w',
                     padx=8, pady=4).pack(side='left', fill='x', expand=True)
        tk.Button(top, text=t('COMMON_CLOSE','닫기'), command=top.destroy,
                  bg='#922B21', fg=_c('fg', '#1A5276'),
                  font=('Malgun Gothic', 9, 'bold'),
                  bd=0, padx=16, pady=4).pack(pady=(0, 10))

    def _open_plan_tab_cb(self):
        if self.on_open_plan_tab:
            self.on_open_plan_tab()
