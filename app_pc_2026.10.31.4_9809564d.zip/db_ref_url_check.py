# -*- coding: utf-8 -*-
"""db_ref_url_check.py — 외부 참조 사이트 URL 표본 점검 (영구 도구)

왜 표본인가
    사이트 14곳 × 31,104절 = **약 43만 개**의 URL 이 있다. 전수를 두드리면
    한 사이트가 3만 번을 받게 되고 그건 점검이 아니라 긁어 가는 행위다.
    그런데 이 URL 들은 **규칙으로 만들어진다.** 규칙이 맞으면 전부 맞고
    틀리면 전부 틀린다. 확인할 것은 3만 개가 아니라 규칙 하나이므로
    사이트당 수십 개면 판정된다.

무엇을 확인하나 (`is_alive` 의 세 가지 뜻)
    2026-08-03 실측 — `is_alive=0` 인 행이 **전체에 0건**이었다.
    죽었다고 판정된 URL 은 하나도 없고, 값에 세 뜻이 섞여 있었다.
        1 + last_checked 있음 : 눌러 보고 확인함
        1 + last_checked 없음 : **안 눌러 보고 만들 때 1 로 넣음**
        NULL                  : 만들어만 두고 손 안 댐
    화면은 `is_alive IS NULL OR is_alive=1` 로 읽으므로 미점검도 보인다(맞는 처리).
    이 도구는 그 뒤섞임을 **실제 확인 기록으로 바꾼다.**

쓰는 법
    python db_ref_url_check.py --report                 지금 상태만 (요청 없음)
    python db_ref_url_check.py --plan                   뽑힐 표본만 보기 (요청 없음)
    python db_ref_url_check.py --check                  실제 점검 (외부 요청 발생)
    python db_ref_url_check.py --check --apply          점검 + is_alive/last_checked 기록
    python db_ref_url_check.py --site BLB --sample 20
    python db_ref_url_check.py --selftest               표본 뽑기 검증 (요청 없음)

⚠ `--apply` 는 DB 를 쓴다. 워크트리에서 실행하지 말 것(CLAUDE.md §1).
"""
from __future__ import annotations
import argparse, os, sys, time, urllib.request, urllib.error

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb

DB = 'bible_master.db'
UA = 'Mozilla/5.0 (compatible; HagahBibleApp/1.0; local link check)'
DELAY   = 1.0      # 같은 사이트에 보내는 요청 사이 간격(초)
TIMEOUT = 12
DEAD_PCT = 30      # 표본에서 이만큼 넘게 죽으면 규칙이 틀린 것으로 본다


# ── 표본 뽑기 ─────────────────────────────────────────────────────────
def pick_sample(conn, site_id, scope, n):
    """무작위로 뽑지 않는다. **규칙이 깨지는 자리**를 선택해 넣는다.

    주소는 책 약자·장·절로 조립되므로 구멍이 나는 곳이 정해져 있다.
        · 책마다 다른 약자        → 여러 책을 고루
        · 한 장짜리 책            → 옵 · 몬 · 요이 · 요삼 · 유
        · 장 번호가 큰 곳         → 시 119
        · 책의 첫 절과 끝 절      → 경계
    무작위 40개는 창세기 언저리만 뽑혀 이 구멍들을 전부 지나칠 수 있다.
    """
    picks, seen = [], set()

    def add(rows):
        for vid, url, bc, ch, vs in rows:
            if vid in seen:
                continue
            seen.add(vid)
            picks.append((vid, url, bc, ch, vs))

    base = ("SELECT m.verse_id, m.url, bi.bcode, bi.chapter, bi.verse "
            "FROM sys_ref_verse_map m JOIN bible_index bi ON bi.verse_id=m.verse_id "
            "WHERE m.site_id=? ")

    # ① 한 장짜리 책 — 약자·장 처리가 가장 잘 깨지는 자리
    add(conn.execute(base + "AND bi.bcode IN (31,57,63,64,65) LIMIT 8", (site_id,)))
    # ② 시편 119 — 장·절 번호가 가장 큰 곳
    add(conn.execute(base + "AND bi.bcode=19 AND bi.chapter=119 LIMIT 3", (site_id,)))
    # ③ 각 책의 첫 절 — 책 약자를 최대한 많이 지나간다
    add(conn.execute(base + "AND bi.chapter=1 AND bi.verse=1 "
                            "ORDER BY bi.bcode LIMIT ?", (site_id, max(n // 2, 10))))
    # ④ 책의 마지막 절 — 경계
    add(conn.execute(base + "AND bi.verse_id IN "
                            "(SELECT MAX(verse_id) FROM bible_index GROUP BY bcode) "
                            "ORDER BY bi.bcode LIMIT 6", (site_id,)))
    # ⑤ 남는 자리는 골고루
    if len(picks) < n:
        add(conn.execute(base + "ORDER BY m.verse_id LIMIT ?", (site_id, n * 3)))
    return picks[:n]


# ── 한 개 두드리기 ────────────────────────────────────────────────────
def probe(url):
    """살았으면 (True, 상태코드).

    ⚠ 서버가 **응답했다는 것 자체**가 주소가 맞다는 뜻이다. 내용이 마음에
      안 든다는 응답(405 HEAD 거부, 416 Range 거부)을 죽음으로 세면 안 된다.
      2026-08-03 첫 실행에서 Sefaria 가 `Range` 헤더 때문에 416 을 돌려주었고,
      멀쩡한 사이트가 **100% 죽음**으로 찍혔다. 살아 있는 자리를 죽었다고
      기록하는 것이 못 본 것보다 나쁘다.

    ⚠⚠⚠ **HEAD 의 404 도 「그 방식이 싫다」였다**(2026-09-06 실측으로 잡았다).
      한국 기독교 언론 CMS 넷(뉴스앤조이·기독신문·주간기독신문·당당뉴스)이
      **HEAD 에 404 를 돌려주는데 GET 은 200** 이다 — **홈페이지조차** 그렇다.
      그런데 옛 코드는 403·405·416·501 만 GET 으로 재시도하고 **404 는 그
      자리에서 죽음으로 찍었다** ⇒ 멀쩡한 글 **90건**을 죽었다고 기록했다.
      ⇒ **HEAD 에서 무슨 코드가 나든 GET 으로 한 번 더 묻는다.** 판정은
        **GET 의 답으로만** 한다. 위 교훈을 한 걸음 더 밀어붙인 것이다.
    ⚠⚠ **403 은 살아 있는 것으로 센다** — Cloudflare 등이 우리를 막은 것이지
      글이 없어진 것이 아니다(실측 RNS 9건). 코드를 함께 돌려주므로 화면이
      `403` 을 보이고 사람이 판단한다. **못 보는 것과 없는 것은 다르다.**
    """
    if not url or not str(url).lower().startswith(('http://', 'https://')):
        return False, 'NO_URL'               # 주소 자체가 없다 — 요청을 보내지 않는다
    for method in ('HEAD', 'GET'):
        headers = {'User-Agent': UA}
        if method == 'GET':
            headers['Range'] = 'bytes=0-2048'   # 본문을 통째로 받지 않으려는 것뿐
        req = urllib.request.Request(url, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
                return True, r.status
        except urllib.error.HTTPError as e:
            if method == 'HEAD':
                continue                      # ★ 코드를 안 가리고 GET 으로 재시도
            if e.code in (403, 405, 416, 501):   # 응답은 왔다 = 주소는 있다
                return True, e.code
            return False, e.code
        except Exception as e:
            if method == 'HEAD':
                continue
            return False, type(e).__name__
    return False, '?'


# ── 현재 상태 ─────────────────────────────────────────────────────────
def report(conn):
    print('사이트별 is_alive 상태 (요청 없음)')
    print('  %-16s %8s %10s %10s %10s' % ('사이트', '전체', '확인함', '안보고1', '미점검'))
    for r in conn.execute("""
            SELECT s.site_code, COUNT(*),
              SUM(CASE WHEN m.is_alive=1 AND m.last_checked IS NOT NULL THEN 1 ELSE 0 END),
              SUM(CASE WHEN m.is_alive=1 AND m.last_checked IS NULL THEN 1 ELSE 0 END),
              SUM(CASE WHEN m.is_alive IS NULL THEN 1 ELSE 0 END),
              SUM(CASE WHEN m.is_alive=0 THEN 1 ELSE 0 END)
            FROM sys_ref_verse_map m JOIN sys_ref_site s ON s.site_id=m.site_id
            GROUP BY 1 ORDER BY 1"""):
        print('  %-16s %8d %10d %10d %10d%s'
              % (r[0], r[1], r[2], r[3], r[4],
                 f'  · 죽음 {r[5]}' if r[5] else ''))
    print('\n  "안보고1" 은 만들 때 1 을 넣은 것이지 확인한 것이 아니다.')
    print('  화면은 NULL 도 보여 준다(`is_alive IS NULL OR is_alive=1`) — 미점검을 숨기지 않는다.')


# ── 점검 ──────────────────────────────────────────────────────────────
def run(conn, only_site, n, do_apply, dry):
    sites = conn.execute(
        "SELECT site_id, site_code, site_name_ko, scope, url_template "
        "FROM sys_ref_site WHERE record_status='LIVE' AND is_active=1 "
        + ("AND site_code=? " if only_site else "")
        + "ORDER BY site_id", (only_site,) if only_site else ()).fetchall()
    if not sites:
        print('대상 사이트가 없다.'); return

    total_req = 0
    for sid, code, name, scope, tpl in sites:
        picks = pick_sample(conn, sid, scope, n)
        if not picks:
            print(f'  {code:<16} URL 이 없다 (건너뜀)'); continue
        if dry:
            print(f'\n## {code} ({name}) — 표본 {len(picks)}개')
            for vid, url, bc, ch, vs in picks[:6]:
                print(f'   {bc:>2} {ch}:{vs}  {url[:88]}')
            if len(picks) > 6:
                print(f'   … 외 {len(picks)-6}개')
            total_req += len(picks)
            continue

        alive = dead = nourl = 0
        bad = []
        print(f'\n## {code} ({name}) — 표본 {len(picks)}개, 요청 간격 {DELAY}초')
        for i, (vid, url, bc, ch, vs) in enumerate(picks):
            ok, st = probe(url)
            if st == 'NO_URL':
                # ⚠ 주소가 없는 것과 주소가 죽은 것은 다르다. Mechon Mamre 는
                #   히브리어 구약 사이트라 **신약 260장에 주소가 없는 것이 정상**이다
                #   (2026-08-03). 이것을 죽음으로 세면 멀쩡한 사이트가 26% 죽은 것이 된다.
                #   확인할 것이 없으므로 요청도 보내지 않고 기록도 남기지 않는다.
                nourl += 1
                bad.append((f'{bc} {ch}:{vs}', st, url))
                continue
            total_req += 1
            if ok:
                alive += 1
            else:
                dead += 1
                bad.append((f'{bc} {ch}:{vs}', st, url))
            if do_apply:
                conn.execute("UPDATE sys_ref_verse_map SET is_alive=?, last_checked=? "
                             "WHERE site_id=? AND verse_id=?",
                             (1 if ok else 0, time.strftime('%Y-%m-%d'), sid, vid))
            if i < len(picks) - 1:
                time.sleep(DELAY)
        tried = alive + dead
        pct = dead * 100 // max(tried, 1)
        verdict = ('두드릴 것이 없다' if tried == 0 else
                   '규칙이 맞다' if pct == 0 else
                   f'대부분 맞다 (죽음 {pct}%)' if pct < DEAD_PCT else
                   f'★ 규칙을 의심할 것 (죽음 {pct}%)')
        print(f'   두드린 {tried}개 — 살아있음 {alive} · 죽음 {dead} → {verdict}'
              + (f'   (주소 없는 행 {nourl}개는 셈에서 뺐다)' if nourl else ''))
        for ref, st, url in bad[:5]:
            print(f'     X {ref:<10} {st}  {(url or "(주소 없음)")[:76]}')
        if do_apply:
            conn.commit()

    print(f'\n{"뽑기만 했다" if dry else "보낸 요청"} — 모두 {total_req}건'
          + ('' if dry else f' (사이트당 최대 {n})'))
    if do_apply and not dry:
        print('점검한 행만 is_alive·last_checked 를 기록했다. 나머지는 그대로 둔다.')


# ── 자가 검사 (요청 없음) ─────────────────────────────────────────────
def selftest(conn):
    ok = True
    sid = conn.execute("SELECT site_id FROM sys_ref_site WHERE site_code='BIBLEHUB'").fetchone()
    if not sid:
        print('  X BIBLEHUB 사이트가 없다'); return False
    picks = pick_sample(conn, sid[0], 'VERSE', 40)
    books = {p[2] for p in picks}
    print(f'  표본 {len(picks)}개 · 서로 다른 책 {len(books)}권')
    checks = [
        ('한 장짜리 책이 들어갔나', bool(books & {31, 57, 63, 64, 65})),
        ('시편 119 가 들어갔나',    any(p[2] == 19 and p[3] == 119 for p in picks)),
        ('책이 10권 이상인가',      len(books) >= 10),
        ('중복이 없나',             len({p[0] for p in picks}) == len(picks)),
        ('URL 이 다 있나',          all(p[1] for p in picks)),
    ]
    for name, good in checks:
        print(f'  {"OK " if good else "X  "}{name}')
        ok &= good
    # 무작위로 뽑았다면 이 조건들이 깨진다는 것도 함께 보인다
    rnd = conn.execute("SELECT bcode FROM bible_index ORDER BY verse_id LIMIT 40").fetchall()
    print(f'  (참고: 앞에서 40개를 그냥 자르면 책 {len({r[0] for r in rnd})}권뿐 — 그래서 선택해 뽑는다)')
    print('\n  자가 검사 PASS' if ok else '\n  자가 검사 FAIL')
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--report', action='store_true')
    ap.add_argument('--plan', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--site')
    ap.add_argument('--sample', type=int, default=40)
    ap.add_argument('--db', default=DB)
    a = ap.parse_args()
    conn = appdb.connect(a.db)

    if a.selftest:
        sys.exit(0 if selftest(conn) else 1)
    if a.report:
        report(conn); return
    if a.plan:
        run(conn, a.site, a.sample, False, dry=True); return
    if a.check:
        run(conn, a.site, a.sample, a.apply, dry=False); return
    ap.print_help()


if __name__ == '__main__':
    main()
