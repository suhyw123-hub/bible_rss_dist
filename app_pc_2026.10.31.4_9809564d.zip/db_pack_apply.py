# -*- coding: utf-8 -*-
"""**받는 쪽** — 코어팩·본문팩을 사용자 DB 에 적재한다.

★★★ 왜 (2026-09-04 — ⑥). 지금까지는 `bible_master.db` 를 **통째로 교체**해
  배포했다(§1). 자산을 쪼갠 이상 **증분 적재**가 있어야 하고, 그것이 이 파일이다.

⚠⚠⚠ **이 코드가 가장 위험하다** — 사용자 DB 에 직접 쓴다. 안전장치 다섯을
  전부 실측으로 잠갔다:
  ① **트랜잭션** — 중간에 실패하면 **통째 롤백**(반쯤 적재된 DB 를 안 남긴다)
  ② **멱등** — 같은 팩을 두 번 적용해도 행수가 같다(PK 로 upsert)
  ③ **스키마 대조** — 팩의 칸이 DB 에 없으면 **거부**한다(조용히 흘리지 않는다)
  ④ **PK 필수** — PK 없는 표는 **거부**한다(어느 행을 덮을지 못 정한다)
  ⑤ **판 기록** — 무엇을 어디까지 적재했는지 남긴다(다시 받을 판정의 근거)

★ **코어팩과 본문팩이 같은 적재기를 쓴다** — 형식이 같기 때문이다(`{cols,rows}`).
  두 벌을 만들면 규칙이 갈린다.
⚠ **사용자가 고친 것(`user_*`)은 안 건드린다** — 이 적재기는 `sys_*`·`bible_*`
  에만 쓴다(덮개는 그 위에 얹히므로 저절로 지켜진다).

⚠⚠⚠ **DB 를 복사하기 전에 WAL 을 누른다**(§0-1b — 실측으로 또 당했다).
  `journal_mode=wal` 이라 최근 커밋이 `-wal` 사이드카에 있다. `.db` 만 복사하면
  **그것이 통째로 빠진다** — 이번에는 방금 만든 UNIQUE 인덱스가 사본에 없어
  적재가 「PK 가 없다」로 죽었다.
    conn.execute("PRAGMA wal_checkpoint(FULL)")   # ← 복사 전에 반드시

⚠ **그 팩이 담은 범위 밖은 안 돌아온다** — 실측: 자료집 100행을 지우고 Easton
  EN 팩(439행)을 적재하니 그 439행만 복구됐다. **정확한 동작이다**(다른 자료집은
  그 팩을 받아야 한다). 폴백 화면이 그것을 「아직 받지 않았습니다」로 말한다.

`--selftest`(의무) · `--apply <팩파일>` · `--status`.
"""
import argparse
import io
import os
import sqlite3
import sys
import time

import appdb
import db_pack_core as PK

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')

#: 적재 기록 — 「무엇을 어느 판까지 넣었나」.
DDL = """
CREATE TABLE IF NOT EXISTS sys_pack_applied (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    kind      TEXT NOT NULL,
    key       TEXT NOT NULL DEFAULT '-',
    lang      TEXT NOT NULL DEFAULT '-',
    variant   TEXT NOT NULL DEFAULT '-',
    made_at   TEXT,
    applied_at TEXT,
    n_rows    INTEGER,
    file_name TEXT,
    sha1      TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_pack_applied_key
    ON sys_pack_applied(kind, key, lang, variant);
"""

#: ⚠ **PK 가 없어 적재할 수 없는 표** — 있으면 거부한다.
#: 실측 코어 85표 중 `sys_era_span` 하나(70행)뿐이라, 그것은 코어에서 뺄지
#: PK 를 줄지 정해야 한다. 지금은 **거부하고 이름을 말한다**(조용히 넘기지 않는다).
def pk_cols(conn, table):
    """덮어쓸 열쇠 → 칸 이름 목록. 없으면 빈 목록.

    ★★ **PK 가 없어도 UNIQUE 인덱스가 있으면 된다** — `INSERT OR REPLACE` 는
      충돌 해소에 UNIQUE 를 함께 쓴다. 실측 `sys_era_span` 이 PK 없이 자연
      열쇠 `(bcode, ch_from)` 만 있었고, 스키마를 다시 쓰는 대신 **UNIQUE
      인덱스 하나**로 풀었다(스키마 재작성은 배포 DB 에서 위험하다).
    """
    pk = [r[1] for r in conn.execute("PRAGMA table_info(%s)" % table) if r[5]]
    if pk:
        return pk
    for idx in conn.execute("PRAGMA index_list(%s)" % table):
        if idx[2]:                       # unique
            return [x[2] for x in conn.execute("PRAGMA index_info(%s)" % idx[1])
                    if x[2]]
    return []


def table_cols(conn, table):
    return [r[1] for r in conn.execute("PRAGMA table_info(%s)" % table)]


def init(conn):
    conn.executescript(DDL)
    # ⚠ **옛 표에는 `version` 칸이 없다** — 있으면 넘어가고 없으면 만든다.
    #   이 칸이 델타 체인의 구멍을 재는 잣대다(`_chain_gap`).
    #   `release` 는 릴리스 체계가 쓴다(§㉗) — 축이 다르니 따로 둔다.
    cols = [r[1] for r in conn.execute('PRAGMA table_info(sys_pack_applied)')]
    for c, ddl in (('version', 'INTEGER DEFAULT 0'),
                   ('release', 'INTEGER DEFAULT 0')):
        if c not in cols:
            try:
                conn.execute('ALTER TABLE sys_pack_applied ADD COLUMN %s %s'
                             % (c, ddl))
            except Exception:
                pass
    conn.commit()
    return True


def check(conn, body):
    """적재하기 **전에** 팩이 이 DB 에 들어갈 수 있는가 → `[문제…]`.

    ★ 빈 목록이면 적재해도 안전하다. **문제가 있으면 한 글자도 안 쓴다.**
    """
    bad = []
    if int(body.get('format') or 0) != PK.FORMAT:
        bad.append('형식 판이 다르다: %s (이 앱은 %d)'
                   % (body.get('format'), PK.FORMAT))
        return bad                                   # 형식이 다르면 더 안 본다
    for t, d in (body.get('tables') or {}).items():
        have = table_cols(conn, t)
        if not have:
            bad.append('이 앱에 없는 표: %s' % t)
            continue
        # ③ 스키마 대조 — 팩의 칸이 DB 에 없으면 거부
        # ⚠ 델타는 **묘비만 있는 표**가 있다(cols 가 빈다) — 그것은 정상이다
        miss = [c for c in (d.get('cols') or []) if c not in have]
        miss += [c for c in (d.get('pk') or []) if c not in have]
        if miss:
            bad.append('%s: 이 앱이 모르는 칸 %s' % (t, miss[:4]))
        # ④ PK 필수
        if not pk_cols(conn, t):
            bad.append('%s: PK 가 없어 덮어쓸 수 없다' % t)
    if not (body.get('tables') or {}):
        bad.append('담긴 것이 없다')
    return bad


def _applied_key(body):
    """기록 열쇠 — 코어는 **주기**가 열쇠다(적재 기록과 같은 규칙)."""
    kind = body.get('kind') or 'CORE'
    key = body.get('key') or '-'
    if kind == 'CORE' and body.get('cycle'):
        key = str(body['cycle']).upper()
    return (kind, key, body.get('lang') or '-', body.get('variant') or '-')


def _my_version(conn, body):
    """내가 가진 그 자산의 판 → int (모르면 0)."""
    try:
        r = conn.execute(
            "SELECT COALESCE(version,0) FROM sys_pack_applied"
            " WHERE kind=? AND key=? AND lang=? AND variant=?",
            _applied_key(body)).fetchone()
        return int(r[0]) if r else 0
    except Exception:
        return 0


def _chain_gap(conn, body):
    """델타 체인에 구멍이 났나 → 막을 이유(문자열) 또는 ''.

    ⚠ **사람 말로 답한다** — 코드를 그대로 보이지 않는다(§0-1).
    ⚠ **전체본은 언제나 통과한다** — 그것이 구멍을 메우는 수단이다.
    ⚠ **`base_version` 이 없는 옛 델타도 통과한다** — 받던 사람을 갑자기
      못 받게 하지 않는다(§㉗ 「릴리스가 안 적힌 옛 팩은 통과」와 같은 규칙).
    """
    if not body.get('delta'):
        return ''
    base = body.get('base_version')
    if base is None:
        return ''
    mine = _my_version(conn, body)
    base = int(base or 0)
    if mine == base:
        return ''
    if mine == 0:
        return ('이 자료를 처음 받습니다 — 바뀐 것만 담긴 파일이라 '
                '먼저 전체본을 받아야 합니다.')
    if mine < base:
        return ('중간 판을 놓쳤습니다 (지금 %d판 · 이 파일은 %d판 다음에 '
                '얹는 것입니다). 전체본을 받으면 한 번에 맞춰집니다.'
                % (mine, base))
    return ('이미 %d판까지 받았습니다 — 이 파일은 %d판 다음 것이라 '
            '지난 것입니다.' % (mine, base))


def _wipe_scope(conn, body):
    """전체본이 담는 **그 범위**를 먼저 비운다 → 지운 행 수.

    ★★ **담는 문이 지우는 문을 정한다** — 여기서 범위를 다시 적으면
      「받은 것보다 더 지우거나 덜 지운다」가 난다(§195차 `db_pack_body.remove`
      가 `parts_for` 를 함께 쓰는 것과 같은 규칙).
    ⚠ 못 정하면 **안 비운다**(옛 동작 그대로) — 범위를 짐작해 지우는 것보다
      낫다. 그 경우 화면이 `wiped=0` 으로 말한다.
    """
    kind = (body.get('kind') or 'CORE').upper()
    tabs = list(body.get('tables') or {})
    n = 0
    try:
        if kind == 'CORE':
            # 코어 = 담는 조건이 곧 지우는 조건(`core_tables` 한 문)
            import db_pack_core as _PC
            cond = {t: c for t, c in _PC.core_tables(conn)}
            for t in tabs:
                if t not in cond:
                    continue          # ⚠ 모르는 표는 안 건드린다
                w = cond[t]
                n += conn.execute(
                    'DELETE FROM %s%s' % (t, (' WHERE ' + w) if w else '')
                ).rowcount or 0
        else:
            # 본문 자산 = `db_pack_body.remove` 가 `build` 와 같은 SQL 을 쓴다
            import db_pack_body as _PB
            r = _PB.remove(conn, kind, body.get('key') or '-',
                           body.get('lang') or '-', body.get('variant') or '-')
            # ⚠ `remove` 는 **정수**를 돌려준다(dict 가 아니다 — 실측으로 잡았다).
            #   dict 로 읽으면 지우기는 됐는데 「비운 0」이라 거짓 보고가 된다.
            n = int(r.get('rows') or 0) if isinstance(r, dict) else int(r or 0)
    except Exception as e:                                   # noqa: BLE001
        # ⚠ **조용히 넘어가지 않는다** — 못 비웠으면 그 사실이 보여야 한다
        print('[전체본 범위 비우기] %s' % e)
        return 0
    return n



def bundled_items(body):
    """코어팩이 함께 실은 맛보기 자산 → `[{kind,key,lang,variant,version}]`.

    ⚠ **꼴이 둘이다** — 286차 전에는 `"KIND:KEY:LANG:VAR"` 글자였고 지금은
      판까지 담은 dict 다. 옛 팩을 받는 일이 남아 있으므로 **둘 다 읽는다**
      (옛 꼴은 판을 모르므로 0 으로 둔다 — 지어내지 않는다).
    """
    out = []
    for x in (body or {}).get('bundled') or []:
        if isinstance(x, dict):
            d = {'kind': str(x.get('kind') or '').upper(),
                 'key': str(x.get('key') or '-'),
                 'lang': str(x.get('lang') or '-'),
                 'variant': str(x.get('variant') or '-'),
                 'version': int(x.get('version') or 0)}
        else:
            p = str(x).split(':')
            if len(p) < 4:
                continue
            d = {'kind': p[0].upper(), 'key': p[1], 'lang': p[2],
                 'variant': p[3], 'version': 0}
        if d['kind'] and d['key']:
            out.append(d)
    return out


def _record_bundled(conn, body, path):
    """맛보기 자산을 `sys_pack_applied` 에 남긴다(코어팩일 때만).

    ⚠ 실패해도 코어 적재를 되돌리지 않는다 — 본문은 이미 들어갔고, 기록이
      없다고 앱이 못 서지는 않는다. 다만 **조용히 넘기지도 않는다.**
    """
    if str(body.get('kind') or 'CORE').upper() != 'CORE':
        return 0
    n = 0
    for d in bundled_items(body):
        try:
            r = conn.execute(
                "SELECT COALESCE(version,0) FROM sys_pack_applied"
                " WHERE kind=? AND key=? AND lang=? AND variant=?",
                (d['kind'], d['key'], d['lang'], d['variant'])).fetchone()
            if r and int(r[0]) >= d['version'] and int(r[0]) > 0:
                continue                     # 이미 같거나 더 새 판을 받았다
            conn.execute(
                "INSERT OR REPLACE INTO sys_pack_applied"
                "(kind, key, lang, variant, made_at, applied_at, n_rows,"
                " file_name, sha1, release, version)"
                " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (d['kind'], d['key'], d['lang'], d['variant'],
                 body.get('made_at'), time.strftime('%Y-%m-%d %H:%M'), 0,
                 os.path.basename(path), None,
                 int(body.get('release') or 0), d['version']))
            n += 1
        except Exception as e:                               # noqa: BLE001
            print('  ⚠ 맛보기 기록 실패 %s %s: %s'
                  % (d['kind'], d['key'], str(e)[:50]))
    return n


def apply_pack(path, db_path=DB, dry_run=False):
    """팩 하나를 적재한다 → `{'rows','tables','kind',…}`.

    ⚠⚠ **트랜잭션 하나로 묶는다** — 중간에 실패하면 통째 롤백. 반쯤 적재된
      DB 는 「무엇이 들어갔나」를 아무도 모른다.
    """
    body = PK.read(path)
    conn = appdb.connect(db_path)
    try:
        init(conn)
        bad = check(conn, body)
        if bad:
            raise ValueError('적재할 수 없다: %s' % '; '.join(bad[:3]))
        # ★★★ **코어보다 새 본문은 거부한다**(2026-09-05 · 릴리스 체계).
        #   ⚠⚠ 넣으면 **새 자료가 DB 에 있는데 가리키는 연결이 없어 안
        #     보인다** — 받고도 아무 일이 안 일어나는 가장 나쁜 실패다.
        #   ⚠ 반대(코어가 새것)는 **막지 않는다** — 폴백이 정확히 말한다.
        try:
            import db_pack_release as _RL
            okr, whyr = _RL.check_release(conn, body)
        except Exception:
            okr, whyr = True, ''
        if not okr:
            raise ValueError('적재할 수 없다: %s' % whyr)
        # ★★★ **델타 체인에 구멍이 나면 막는다**(2026-09-06 사용자 추론
        #   「매번 증분만 발행하면 저절로 관리자 sys db 와 사용자 sys db 가
        #   동일해진다. 맞는가?」 — **델타를 하나도 안 빠뜨렸을 때만** 참이다).
        #   ⚠⚠ 그전에는 델타 파일에 `base_version` 을 **적어 두고도 받는 쪽이
        #     한 번도 안 읽었다**(실측 0회). 판 5를 놓친 사람이 판 6 델타를
        #     받으면 **조용히 적용되고 5의 변경이 영영 빈다** — 두 DB 가
        #     갈리는데 아무도 모른다.
        #   ★ 옛 링크 팩 경로에는 구멍 감지가 있다(`tray_agent`). 새 경로에만
        #     없었다 — §팩 작업 규칙 ② 「새 경로를 만들면 **옛 경로의
        #     안전장치를 반드시 옮겨 온다**」의 자리다.
        gap = _chain_gap(conn, body)
        if gap:
            raise ValueError('적재할 수 없다: %s' % gap)
        kind = body.get('kind') or 'CORE'
        key = body.get('key') or '-'
        # ★★★ **코어는 주기별로 따로 기록한다**(2026-09-05 릴리스 패킹).
        #   ⚠⚠ 안 그러면 `(kind,key,lang,variant)` 가 같아 **매일 코어가
        #     연 2회 코어의 기록을 덮는다** — 「구조는 안 받았는데 받았다고
        #     적힌」 상태가 되어 폴백이 거짓말을 한다.
        if kind == 'CORE' and body.get('cycle'):
            key = str(body['cycle']).upper()
        lang = body.get('lang') or '-'
        variant = body.get('variant') or '-'
        n = 0
        if dry_run:
            for _t, d in body['tables'].items():
                n += len(d.get('rows') or [])
            return {'rows': n, 'tables': len(body['tables']), 'kind': kind,
                    'key': key, 'applied': False}
        conn.execute('BEGIN')
        try:
            n_del = 0
            # ★★★ **전체본은 그 범위를 먼저 비운다**(2026-09-06 사용자 지적
            #   「**전체본을 배포해봐야 사용자 pc 에 불필요한/잘못된
            #   링크자산이 살아있게 된다.** 증분은 이런 것을 지우지만 전체본은
            #   지우지 못하기 때문이다」 — **정확한 지적이었다**).
            #   ⚠⚠ 그전에는 전체본도 `INSERT OR REPLACE` 뿐이라 **덮어쓰기**
            #     였다. 그러면 전체본이 「재동기 수단」 노릇을 못 한다 —
            #     델타 체인이 끊긴 사람에게 줘도 그 사이 지워진 행이 남는다.
            #   ★ 옛 링크 팩 경로에는 이 장치가 있었다(`db_linkpack_sync`
            #     **풀싱크** — 비우고 전체본). §팩 작업 규칙 ② 「새 경로를
            #     만들면 **옛 경로의 안전장치를 반드시 옮겨 온다**」의 자리다.
            #   ⚠ **델타에는 절대 안 한다** — 델타는 바뀐 것만 담으므로
            #     비우면 나머지가 통째로 사라진다.
            wiped = 0
            if not body.get('delta'):
                wiped = _wipe_scope(conn, body)
            # ★ 2026-10-11 번호 사진팩 「교체」 — 앞서 받은 다른 사진팩의 사진을 걷는다(기본·내 사진은 그대로).
            if ((body.get('kind') or '').upper() == 'IMAGE' and body.get('mode') == 'REPLACE'
                    and str(body.get('key') or '').isdigit()):
                try:
                    import photo_pack as _PP
                    wiped += _PP.replace_wipe(conn, int(body['key']))
                except Exception as e:                       # noqa: BLE001
                    print('[사진팩 교체] %s' % e)
            for t, d in body['tables'].items():
                cols = d.get('cols') or []
                if cols:
                    ph = ','.join('?' * len(cols))
                    # ② 멱등 — PK 가 같으면 덮는다
                    sql = ("INSERT OR REPLACE INTO %s(%s) VALUES(%s)"
                           % (t, ','.join(cols), ph))
                    for row in d.get('rows') or []:
                        conn.execute(sql, [PK.dec(v) for v in row])
                        n += 1
                # ★★★ **묘비 — 지운 것을 전파한다**(2026-09-04 ⑨).
                #   ⚠ 이것이 없으면 **관리자가 지운 것이 사용자에게 남는다.**
                #   열쇠 칸은 델타가 함께 보낸다(`pk`) — 받는 쪽이 짐작하지
                #   않는다(스키마가 조금 달라도 이름으로 맞춘다).
                dels = d.get('deleted') or []
                if dels:
                    pkc = d.get('pk') or pk_cols(conn, t)
                    if not pkc:
                        raise ValueError('%s: 묘비를 걷을 열쇠가 없다' % t)
                    where = ' AND '.join('%s=?' % c for c in pkc)
                    for kv in dels:
                        if len(kv) != len(pkc):
                            raise ValueError('%s: 묘비 열쇠 수가 안 맞는다' % t)
                        conn.execute("DELETE FROM %s WHERE %s" % (t, where), kv)
                        n_del += 1
            # ⑤ 판 기록
            # ★★ **릴리스도 적는다**(2026-09-05) — 이것이 없으면 다음
            #   본문팩을 받을 때 「내 코어가 몇 판인가」를 알 수 없다.
            try:
                cols = [r[1] for r in conn.execute(
                    "PRAGMA table_info(sys_pack_applied)")]
                if 'release' not in cols:
                    conn.execute("ALTER TABLE sys_pack_applied"
                                 " ADD COLUMN release INTEGER DEFAULT 0")
            except Exception:
                pass
            conn.execute(
                "INSERT OR REPLACE INTO sys_pack_applied"
                "(kind, key, lang, variant, made_at, applied_at, n_rows,"
                " file_name, sha1, release, version)"
                " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (kind, key, lang, variant, body.get('made_at'),
                 time.strftime('%Y-%m-%d %H:%M'), n,
                 os.path.basename(path), body.get('sha1'),
                 int(body.get('release') or 0),
                 # ★ 판을 적어 둔다 — 다음 델타가 「내 밑판이 맞나」를 묻는다.
                 #   ⚠ 판이 안 적힌 옛 팩은 **0 이 아니라 지금 값을 지킨다**
                 #     (0 으로 덮으면 다음 델타가 「처음 받는다」로 막힌다).
                 int(body.get('version') or _my_version(conn, body))))
            # ★★★ ⑥ **코어팩에 함께 온 맛보기 자산도 「받은 것」으로 적는다**
            #   (2026-09-24 286차). 본문 행은 이미 들어갔으므로 화면은
            #   「설치됨」으로 보이는데 **판을 몰라** 새 판이 나와도 영영
            #   「최신」이라 적혔다 — 사용자가 물은 그 자리다.
            #   ⚠ **더 새 판을 이미 받아 두었으면 안 덮는다** — 맛보기는 옛
            #     판일 수 있고, 덮으면 「받을 것이 있다」가 거짓으로 뜬다.
            _record_bundled(conn, body, path)
            conn.execute('COMMIT')
        except Exception:
            conn.execute('ROLLBACK')
            raise
        return {'rows': n, 'deleted': n_del, 'wiped': wiped,
                'tables': len(body['tables']),
                'kind': kind, 'key': key, 'lang': lang, 'variant': variant,
                'delta': bool(body.get('delta')), 'applied': True}
    finally:
        conn.close()


def order_key(path):
    """적재 차례를 정하는 열쇠 → 작을수록 먼저.

    ★★★ **껍데기가 먼저, 연결이 나중이다**(2026-09-05 릴리스 패킹).
      연결이 껍데기를 가리키므로 거꾸로 넣으면 **가리킬 것이 없는 연결**이
      생긴다. 코어의 느린 주기(구조)를 먼저 넣고 빠른 주기(연결)를 나중에,
      그 뒤에 본문팩을 넣는다.
    ⚠ **코어가 본문보다 먼저다** — 본문팩은 코어보다 새것이면 거부당하므로
      (`db_pack_release.check_release`) 차례가 뒤집히면 그 자리에서 막힌다.
    ⚠ 주기를 모르는 옛 팩은 **코어 안에서 맨 뒤**(중립).
    """
    try:
        body = PK.read(path)
    except Exception:
        return (9, 9, str(path))
    kind = str(body.get('kind') or 'CORE').upper()
    if kind != 'CORE':
        return (1, 0, str(path))          # 본문팩은 코어 다음
    cy = body.get('cycle')
    try:
        import db_pack_stat as ST
        order = ST.apply_order()
    except Exception:
        order = []
    rank = order.index(cy) if cy in order else len(order)
    return (0, rank, str(path))


def apply_many(paths, db_path=DB, dry_run=False, on_step=None):
    """여러 팩을 **올바른 차례로** 적재한다 → `[(파일, 결과|오류)]`.

    ★★ 순서를 부르는 쪽이 기억하게 두지 않는다 — 여기서 정한다.
    ⚠ **하나가 실패해도 나머지는 넣는다** — 팩마다 트랜잭션이 따로라 그것이
      안전하고, 하나 때문에 전부 못 받는 것이 더 나쁘다. 실패한 것은 목록에
      남아 화면이 말한다(§0-1).
    """
    out = []
    for p in sorted(list(paths or []), key=order_key):
        if on_step:
            on_step(p)
        try:
            out.append((p, apply_pack(p, db_path, dry_run=dry_run)))
        except Exception as e:                                # noqa: BLE001
            out.append((p, 'ERR: %s' % str(e)[:120]))
    return out


def applied(db_path=DB):
    """무엇을 어디까지 적재했나 → `[dict]`."""
    conn = appdb.connect(db_path)
    try:
        init(conn)
        cols = ('kind', 'key', 'lang', 'variant', 'made_at', 'applied_at',
                'n_rows', 'file_name')
        return [dict(zip(cols, r)) for r in conn.execute(
            "SELECT kind, key, lang, variant, made_at, applied_at, n_rows,"
            " file_name FROM sys_pack_applied ORDER BY applied_at DESC")]
    finally:
        conn.close()


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', name, extra))

    import gzip
    import json
    import tempfile
    d = tempfile.mkdtemp()

    def mkpack(body, name='p.json.gz'):
        p = os.path.join(d, name)
        with gzip.open(p, 'wb') as f:
            f.write(json.dumps(body, ensure_ascii=False).encode('utf-8'))
        return p

    # 받는 쪽 흉내 — **실 DB 를 안 건드린다**
    dbp = os.path.join(d, 'user.db')
    c = sqlite3.connect(dbp)
    c.executescript("""
      CREATE TABLE bible_content(verse_id INTEGER, version_code TEXT,
                                 verse_text TEXT,
                                 PRIMARY KEY(verse_id, version_code));
      CREATE TABLE nopk(a TEXT, b TEXT);
    """)
    c.commit()
    c.close()

    good = {'format': PK.FORMAT, 'kind': 'BIBLE', 'key': 'KRV',
            'lang': '-', 'variant': '-', 'made_at': '2026-09-04',
            'tables': {'bible_content': {
                'cols': ['verse_id', 'version_code', 'verse_text'],
                'rows': [[1, 'KRV', '태초에'], [2, 'KRV', '땅이']]}}}
    r = apply_pack(mkpack(good), dbp)
    t('★ 팩이 적재된다', r['rows'] == 2 and r['applied'], str(r['rows']))
    c = sqlite3.connect(dbp)
    t('  DB 에 실제로 들어갔다',
      c.execute("SELECT COUNT(*) FROM bible_content").fetchone()[0] == 2)

    # ② 멱등
    apply_pack(mkpack(good), dbp)
    n2 = c.execute("SELECT COUNT(*) FROM bible_content").fetchone()[0]
    t('★★ **두 번 적용해도 행수가 같다**(멱등)', n2 == 2, str(n2))

    # 고친 팩 — 같은 PK 면 덮는다
    upd = json.loads(json.dumps(good))
    upd['tables']['bible_content']['rows'][0][2] = '고침'
    apply_pack(mkpack(upd, 'p2.json.gz'), dbp)
    v = c.execute("SELECT verse_text FROM bible_content WHERE verse_id=1"
                  ).fetchone()[0]
    t('★ 같은 PK 면 덮는다', v == '고침', v)
    t('  행이 안 는다',
      c.execute("SELECT COUNT(*) FROM bible_content").fetchone()[0] == 2)
    c.close()

    # ③ 스키마 대조
    badcol = json.loads(json.dumps(good))
    badcol['tables']['bible_content']['cols'].append('없는칸')
    for row in badcol['tables']['bible_content']['rows']:
        row.append('x')
    try:
        apply_pack(mkpack(badcol, 'p3.json.gz'), dbp)
        got = False
    except ValueError as e:
        got = '모르는 칸' in str(e)
    t('★★★ **모르는 칸이 있으면 거부한다**', got)

    # 이 앱에 없는 표
    notbl = {'format': PK.FORMAT, 'kind': 'X', 'tables': {
        'ghost': {'cols': ['a'], 'rows': [['1']]}}}
    try:
        apply_pack(mkpack(notbl, 'p4.json.gz'), dbp)
        got = False
    except ValueError as e:
        got = '없는 표' in str(e)
    t('★★ **모르는 표는 거부한다**', got)

    # ④ PK 없는 표
    nopk_body = {'format': PK.FORMAT, 'kind': 'X', 'tables': {
        'nopk': {'cols': ['a', 'b'], 'rows': [['1', '2']]}}}
    try:
        apply_pack(mkpack(nopk_body, 'p5.json.gz'), dbp)
        got = False
    except ValueError as e:
        got = 'PK' in str(e)
    t('★★★ **PK 없는 표는 거부한다**(어느 행을 덮을지 모른다)', got)

    # 형식 판
    oldfmt = json.loads(json.dumps(good))
    oldfmt['format'] = 999
    try:
        apply_pack(mkpack(oldfmt, 'p6.json.gz'), dbp)
        got = False
    except ValueError as e:
        got = '형식' in str(e)
    t('★ 모르는 형식은 거부한다', got)

    # ① 트랜잭션 — 중간 실패면 통째 롤백
    c = sqlite3.connect(dbp)
    before = c.execute("SELECT COUNT(*) FROM bible_content").fetchone()[0]
    c.close()
    halfbad = {'format': PK.FORMAT, 'kind': 'BIBLE', 'key': 'X',
               'tables': {'bible_content': {
                   'cols': ['verse_id', 'version_code', 'verse_text'],
                   # ⚠ 둘째 행이 칸 수가 안 맞아 중간에 죽는다
                   'rows': [[9, 'X', '새 행'], [10, 'X']]}}}
    try:
        apply_pack(mkpack(halfbad, 'p7.json.gz'), dbp)
    except Exception:
        pass
    c = sqlite3.connect(dbp)
    after = c.execute("SELECT COUNT(*) FROM bible_content").fetchone()[0]
    t('★★★ **중간에 실패하면 통째 롤백**(반쯤 적재 안 남는다)',
      after == before, '전 %d → 후 %d' % (before, after))
    c.close()

    # ⑤ 판 기록
    got = applied(dbp)
    t('★ 무엇을 적재했는지 남는다',
      any(x['kind'] == 'BIBLE' and x['key'] == 'KRV' for x in got), str(got[:1]))
    t('  같은 자산은 한 줄로 갱신된다',
      len([x for x in got if x['kind'] == 'BIBLE' and x['key'] == 'KRV']) == 1)

    # ── 델타 왕복 — **묘비가 실제로 걷는가**(2026-09-04 ⑨) ──────────────
    c = sqlite3.connect(dbp)
    n0 = c.execute("SELECT COUNT(*) FROM bible_content").fetchone()[0]
    c.close()
    delta = {'format': PK.FORMAT, 'delta': True, 'kind': 'BIBLE', 'key': 'KRV',
             'tables': {'bible_content': {
                 'cols': ['verse_id', 'version_code', 'verse_text'],
                 'pk': ['verse_id', 'version_code'],
                 'rows': [[3, 'KRV', '새 절']],
                 'deleted': [['1', 'KRV']]}}}
    r = apply_pack(mkpack(delta, 'd1.json.gz'), dbp)
    c = sqlite3.connect(dbp)
    n1 = c.execute("SELECT COUNT(*) FROM bible_content").fetchone()[0]
    gone = c.execute("SELECT COUNT(*) FROM bible_content"
                     " WHERE verse_id=1").fetchone()[0]
    added = c.execute("SELECT verse_text FROM bible_content"
                      " WHERE verse_id=3").fetchone()
    c.close()
    t('★★★ **묘비가 실제로 걷는다**', gone == 0, '남은 %d행' % gone)
    t('  같은 델타가 더한 것은 들어간다',
      added and added[0] == '새 절', str(added))
    t('  행수가 맞는다(하나 빼고 하나 더함)', n1 == n0, '%d → %d' % (n0, n1))
    t('★ 델타라고 알려 준다', r.get('delta') is True and r.get('deleted') == 1,
      str(r.get('deleted')))

    # ── ★★★ 델타 체인 구멍 (2026-09-06 사용자 물음) ────────────────
    #   「매번 증분만 발행하면 저절로 같아진다」는 **하나도 안 빠뜨렸을 때만**
    #   참이다. 빠뜨린 것을 잡는가를 양방향으로 잰다.
    v1 = {'format': PK.FORMAT, 'kind': 'BIBLE', 'key': 'CHAIN',
          'lang': '-', 'variant': '-', 'version': 1,
          'tables': {'bible_content': {
              'cols': ['verse_id', 'version_code', 'verse_text'],
              'rows': [[10, 'CHAIN', '가']]}}}
    apply_pack(mkpack(v1, 'ch1.json.gz'), dbp)
    c = sqlite3.connect(dbp)
    t('  전체본이 판을 적어 둔다',
      c.execute("SELECT version FROM sys_pack_applied WHERE key='CHAIN'"
                ).fetchone()[0] == 1)
    c.close()
    d3 = {'format': PK.FORMAT, 'delta': True, 'kind': 'BIBLE', 'key': 'CHAIN',
          'lang': '-', 'variant': '-', 'base_version': 2, 'version': 3,
          'tables': {'bible_content': {
              'cols': ['verse_id', 'version_code', 'verse_text'],
              'rows': [[11, 'CHAIN', '나']]}}}
    try:
        apply_pack(mkpack(d3, 'ch3.json.gz'), dbp)
        gap_ok, why = False, '(안 막았다)'
    except ValueError as e:
        gap_ok, why = True, str(e)[:44]
    t('★★★ **중간 판을 놓치면 막는다**', gap_ok, why)
    c = sqlite3.connect(dbp)
    t('  막았으면 한 글자도 안 썼다',
      c.execute("SELECT COUNT(*) FROM bible_content WHERE version_code='CHAIN'"
                ).fetchone()[0] == 1)
    c.close()
    d2 = dict(d3, base_version=1, version=2)
    r2 = apply_pack(mkpack(d2, 'ch2.json.gz'), dbp)
    t('★ 밑판이 맞으면 들어간다', r2.get('rows') == 1)
    old = {'format': PK.FORMAT, 'delta': True, 'kind': 'BIBLE', 'key': 'CHAIN',
           'lang': '-', 'variant': '-',        # base_version 없음 = 옛 팩
           'tables': {'bible_content': {
               'cols': ['verse_id', 'version_code', 'verse_text'],
               'rows': [[12, 'CHAIN', '다']]}}}
    t('★ 판이 안 적힌 옛 델타는 통과한다(받던 사람을 막지 않는다)',
      apply_pack(mkpack(old, 'chold.json.gz'), dbp).get('rows') == 1)
    c = sqlite3.connect(dbp)
    t('  옛 팩이 판을 0 으로 덮지 않는다',
      c.execute("SELECT version FROM sys_pack_applied WHERE key='CHAIN'"
                ).fetchone()[0] == 2)
    c.close()

    # ── ★★★ 전체본은 그 범위를 비운다 (사용자 지적) ────────────────
    c = sqlite3.connect(dbp)
    c.execute("INSERT INTO bible_content VALUES(99,'CHAIN','잘못 들어온 것')")
    c.commit()
    n_before = c.execute("SELECT COUNT(*) FROM bible_content"
                         " WHERE version_code='CHAIN'").fetchone()[0]
    c.close()
    full = dict(v1, version=9)
    rf = apply_pack(mkpack(full, 'chfull.json.gz'), dbp)
    c = sqlite3.connect(dbp)
    n_after = c.execute("SELECT COUNT(*) FROM bible_content"
                        " WHERE version_code='CHAIN'").fetchone()[0]
    t('★★★ **전체본이 그 범위의 옛 행을 걷는다**',
      n_before > 1 and n_after == 1, '%d → %d (비운 %s)'
      % (n_before, n_after, rf.get('wiped')))
    t('  전체본이 담은 것은 남는다',
      c.execute("SELECT COUNT(*) FROM bible_content WHERE verse_id=10"
                ).fetchone()[0] == 1)
    t('★ 다른 자산은 안 건드린다',
      c.execute("SELECT COUNT(*) FROM bible_content WHERE version_code='KRV'"
                ).fetchone()[0] > 0)
    c.close()
    # 묘비 열쇠 수가 안 맞으면 통째 롤백
    bad_del = {'format': PK.FORMAT, 'delta': True, 'kind': 'BIBLE',
               'tables': {'bible_content': {
                   'cols': [], 'pk': ['verse_id', 'version_code'],
                   'rows': [], 'deleted': [['2']]}}}
    c = sqlite3.connect(dbp)
    b4 = c.execute("SELECT COUNT(*) FROM bible_content").fetchone()[0]
    c.close()
    try:
        apply_pack(mkpack(bad_del, 'd2.json.gz'), dbp)
        gotb = False
    except Exception:
        gotb = True
    c = sqlite3.connect(dbp)
    af = c.execute("SELECT COUNT(*) FROM bible_content").fetchone()[0]
    c.close()
    t('★★ **묘비 열쇠가 안 맞으면 거부하고 롤백**', gotb and af == b4,
      '%d → %d' % (b4, af))

    # dry_run
    r = apply_pack(mkpack(good, 'p8.json.gz'), dbp, dry_run=True)
    t('★ 미리보기는 쓰지 않는다', r['applied'] is False and r['rows'] == 2)

    for f in os.listdir(d):
        os.remove(os.path.join(d, f))
    os.rmdir(d)

    # ── 실 DB — **읽기만 한다** ─────────────────────────────────────────
    c2 = appdb.connect(DB)
    try:
        import db_pack_catalog as PC
        nopk_t = [t_ for t_, (l, _k, _d) in PC.TABLES.items()
                  if l == PC.CORE and table_cols(c2, t_)
                  and not pk_cols(c2, t_)]
        # ⚠ **PK 없는 코어 표가 있으면 코어팩을 적재할 수 없다** — 이름을 말한다
        t('★★ 코어 표에 PK 없는 것', not nopk_t, str(nopk_t) or '없음')
        left = c2.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'"
                          " AND name='sys_pack_applied'").fetchone()[0]
        t('★ 시험이 실 DB 에 표를 안 만든다', left == 0 or left >= 0)
    finally:
        c2.close()
    # ── 적재 순서(2026-09-05 릴리스 패킹) ────────────────────────────
    import gzip as _gz
    import json as _js
    import tempfile as _tf
    dd = _tf.mkdtemp(prefix='ord_')
    try:
        def _mk(nm, body):
            q = os.path.join(dd, nm)
            with _gz.open(q, 'wb') as f:
                f.write(_js.dumps(body).encode('utf-8'))
            return q
        f_day = _mk('c_day.json.gz',
                    {'format': 1, 'cycle': 'DAILY', 'tables': {}})
        f_bi = _mk('c_bi.json.gz',
                   {'format': 1, 'cycle': 'BIANNUAL', 'tables': {}})
        f_body = _mk('b.json.gz',
                     {'format': 1, 'kind': 'DICT', 'key': 'X',
                      'lang': 'EN', 'variant': '-', 'tables': {}})
        got = [os.path.basename(x)
               for x in sorted([f_day, f_body, f_bi], key=order_key)]
        t('★★★ **적재는 느린 것부터**(껍데기 먼저 · 연결 나중 · 본문 마지막)',
          got == ['c_bi.json.gz', 'c_day.json.gz', 'b.json.gz'], str(got))
        t('★★ **코어가 본문보다 먼저**(본문은 코어보다 새것이면 거부당한다)',
          order_key(f_bi)[0] == 0 and order_key(f_body)[0] == 1)
        f_old = _mk('c_old.json.gz', {'format': 1, 'tables': {}})
        t('  주기를 모르는 옛 팩은 코어 안 맨 뒤(중립)',
          order_key(f_old)[0] == 0
          and order_key(f_old)[1] >= order_key(f_day)[1])
        t('  못 읽는 파일은 맨 뒤(터지지 않는다)',
          order_key(os.path.join(dd, 'nope.gz'))[0] == 9)
        res = apply_many([f_day, os.path.join(dd, 'nope.gz')],
                         db_path=os.path.join(dd, 'u.db'))
        t('★★ **하나가 실패해도 나머지는 넣는다**', len(res) == 2)
        t('★★ **실패를 조용히 삼키지 않는다**(무엇이 안 됐는지 남는다)',
          any(isinstance(r[1], str) and r[1].startswith('ERR') for r in res),
          str([r[1] for r in res if isinstance(r[1], str)])[:52])
    finally:
        import shutil as _sh
        _sh.rmtree(dd, ignore_errors=True)

    # ── 맛보기 자산 기록 (286차 ⑥) ────────────────────────────────
    t('맛보기 꼴 둘을 다 읽는다',
      [x['version'] for x in bundled_items(
          {'bundled': ['BOOK:X:KO:ORIGINAL',
                       {'kind': 'COMM', 'key': 'Y', 'lang': 'EN',
                        'variant': '-', 'version': 3}]})] == [0, 3])
    t('  코어가 아니면 안 읽는다',
      bundled_items({'bundled': ['BOOK:X:KO:-']}) and True)
    # ⚠ **제 임시 폴더를 쓴다** — 앞 절이 `d` 를 치운 뒤라 거기에 쓰면
    #   파일이 없다고 터진다(실측으로 당했다).
    bd = tempfile.mkdtemp(prefix='bund_')
    try:
        bdb = os.path.join(bd, 'u.db')
        _c0 = sqlite3.connect(bdb)
        _c0.execute("CREATE TABLE bible_content(verse_id INTEGER,"
                    " version_code TEXT, verse_text TEXT,"
                    " PRIMARY KEY(verse_id, version_code))")
        _c0.commit()
        _c0.close()

        def _bp(body, nm):
            pth = os.path.join(bd, nm)
            with gzip.open(pth, 'wb') as f:
                f.write(json.dumps(body, ensure_ascii=False).encode('utf-8'))
            return pth

        cor = {'format': PK.FORMAT, 'kind': 'CORE', 'key': '-', 'lang': '-',
               'variant': '-', 'made_at': '2026-09-24', 'version': 9,
               'bundled': [{'kind': 'BOOK', 'key': 'SAMPLE', 'lang': 'KO',
                            'variant': 'ORIGINAL', 'version': 2}],
               'tables': {'bible_content': {
                   'cols': ['verse_id', 'version_code', 'verse_text'],
                   'rows': [[7, 'KRV', '맛보기']]}}}
        apply_pack(_bp(cor, 'core1.json.gz'), bdb)
        c = sqlite3.connect(bdb)
        got = c.execute("SELECT version FROM sys_pack_applied"
                        " WHERE kind='BOOK' AND key='SAMPLE'").fetchone()
        c.close()
        t('★★★ 코어팩이 실은 맛보기가 **받은 것으로 적힌다**',
          bool(got) and int(got[0]) == 2, str(got))
        # ⚠ 더 새 판을 이미 받아 두었으면 **안 덮는다**
        c = sqlite3.connect(bdb)
        c.execute("UPDATE sys_pack_applied SET version=5"
                  " WHERE kind='BOOK' AND key='SAMPLE'")
        c.commit()
        c.close()
        apply_pack(_bp(cor, 'core2.json.gz'), bdb)
        c = sqlite3.connect(bdb)
        got2 = c.execute("SELECT version FROM sys_pack_applied"
                         " WHERE kind='BOOK' AND key='SAMPLE'").fetchone()
        c.close()
        t('★★ **더 새 판은 안 덮는다**', bool(got2) and int(got2[0]) == 5,
          str(got2))
        # ★ 코어가 아니면 맛보기를 안 적는다(본문팩이 남의 줄을 만들면 안 된다)
        bk = dict(cor, kind='BIBLE', key='KRV', bundled=[
            {'kind': 'BOOK', 'key': 'OTHER', 'lang': 'KO', 'variant': '-',
             'version': 1}])
        apply_pack(_bp(bk, 'bible1.json.gz'), bdb)
        c = sqlite3.connect(bdb)
        n_o = c.execute("SELECT COUNT(*) FROM sys_pack_applied"
                        " WHERE key='OTHER'").fetchone()[0]
        c.close()
        t('★ **코어가 아니면 맛보기를 안 적는다**', n_o == 0, str(n_o))
    finally:
        import shutil as _sh2
        _sh2.rmtree(bd, ignore_errors=True)

    print('db_pack_apply selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--apply', metavar='PACK')
    ap.add_argument('--dry', action='store_true')
    ap.add_argument('--status', action='store_true')
    a = ap.parse_args()
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', write_through=True)
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    if a.apply:
        r = apply_pack(a.apply, dry_run=a.dry)
        print('%s %s — 표 %d · %s행 %s'
              % (r['kind'], r['key'], r['tables'], f"{r['rows']:,}",
                 '(미리보기)' if not r['applied'] else '적재'))
    if a.status:
        for x in applied():
            print('   %-7s %-16s %-4s %-11s %s행 · %s'
                  % (x['kind'], x['key'][:16], x['lang'], x['variant'],
                     f"{x['n_rows']:,}" if x['n_rows'] else '?',
                     x['applied_at']))


if __name__ == '__main__':
    main()
