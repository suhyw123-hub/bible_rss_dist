# -*- coding: utf-8 -*-
"""WLC(히브리 원문 + Strong 번호)를 **로컬 전용 검증 데이터**로 만든다.

왜 필요한가 (2026-08-04 실측) — EXPERT 설명문의 **63.7%**가 괄호 원어 표기를 담고 있는데
(11,603회), **그 낱말이 그 절에 실제로 있는지 확인된 것은 0건**이다. `db_vers_gate` 의
원어 검사는 표기 **형식**만 본다(순서·과밀·전체 음독). 어휘집을 우리가 쓴 글에서 만들기 때문이다.
주석으로도 못 메운다 — 전 주석 6종에 히브리 문자가 0자다(Gill 은 49.8%에서 히브리어를
논하지만 영어 뜻풀이로 가리킬 뿐 음역을 주지 않는다).

★ **배포하지 않는다.** 저장 위치는 `wlc_verify.db`(앱 폴더, gitignore) 다.
  `bible_master.db` 는 사용자에게 통째로 나가므로 절대 넣지 않는다.
  근거: WLC 본문은 Public Domain 이지만 **lemma(Strong 번호)는 CC BY 4.0**
  (Open Scriptures Hebrew Bible Project). 목적이 검증이라 배포할 이유가 없고,
  로컬 전용이면 재배포 문제가 생기지 않는다. §18-7 의 STEPBible TVTMS 와 같은 취급.

★ **정렬을 추측하지 않는다.** 히브리 절체계는 우리 영어축과 138개 장에서 어긋난다.
  밀린 채 저장하면 검증이 통째로 거짓말이 된다(FreJND·SpaRV 전례 §18-7).
  그래서 **닫힌 구역**(누적 절수가 양 끝에서 맞는 구간)에서만 순차 평탄화하고,
  닫히지 않는 구간은 **`검증 안 함`으로 남긴다.**

사용:
    python -X utf8 db_wlc_verify.py --selftest    # 정렬 탐지력 (의무)
    python -X utf8 db_wlc_verify.py --align       # 정렬 결과만 보고, 저장 안 함
    python -X utf8 db_wlc_verify.py --build       # wlc_verify.db 생성
"""
import os, re, sys, sqlite3, argparse, collections

APP = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(APP, '_wlc_raw')
SRC_DB = os.path.join(APP, 'bible_master.db')
OUT_DB = os.path.join(APP, 'wlc_verify.db')       # ★ 배포 대상 아님

OSIS = ['Gen', 'Exod', 'Lev', 'Num', 'Deut', 'Josh', 'Judg', 'Ruth', '1Sam', '2Sam',
        '1Kgs', '2Kgs', '1Chr', '2Chr', 'Ezra', 'Neh', 'Esth', 'Job', 'Ps', 'Prov',
        'Eccl', 'Song', 'Isa', 'Jer', 'Lam', 'Ezek', 'Dan', 'Hos', 'Joel', 'Amos',
        'Obad', 'Jonah', 'Mic', 'Nah', 'Hab', 'Zeph', 'Hag', 'Zech', 'Mal']
PSALMS = 19

VERSE = re.compile(r'(?s)<verse\b[^>]*osisID="([^"]+)"[^>]*>(.*?)</verse>')
WORD = re.compile(r'(?s)<w\b[^>]*?lemma="([^"]*)"[^>]*?>(.*?)</w>')
TAG = re.compile(r'<[^>]+>')
STRONG = re.compile(r'(\d+)')


def read_book(name):
    """[(chapter, verse, 히브리본문, [Strong번호])] — 파일 순서 그대로."""
    raw = open(os.path.join(RAW, name + '.xml'), encoding='utf-8').read()
    out = []
    for m in VERSE.finditer(raw):
        p = m.group(1).split('.')
        if len(p) != 3:
            continue
        body = m.group(2)
        heb, st = [], []
        for w in WORD.finditer(body):
            lemma, txt = w.group(1), TAG.sub('', w.group(2))
            heb.append(txt)
            # lemma 는 'c/1961' · '8199' · '1254 a' 꼴. 접두사와 동음이의 꼬리를 걷어낸다.
            for n in STRONG.findall(lemma):
                st.append('H' + n)
        out.append((int(p[1]), int(p[2]), ' '.join(heb), st))
    return out


def our_index(conn):
    """bcode -> [(chapter, verse, verse_id)] 읽기 순서."""
    d = collections.defaultdict(list)
    for b, ch, v, vid in conn.execute(
            'SELECT bcode, chapter, verse, verse_id FROM bible_index '
            'WHERE bcode<=39 ORDER BY verse_id'):
        d[b].append((ch, v, vid))
    return d


def regions(wlc, ours):
    """닫힌 구역으로 나눈다.

    장 경계마다 누적 절수를 견주어, 양쪽이 같아지는 지점에서 구역을 닫는다.
    구역 안에서는 **읽기 순서 위치 매핑**이 장경계 이동을 자동으로 흡수한다
    (§18-7 의 순차 평탄화). 닫히지 않은 채 끝나면 그 구역은 버린다.
    """
    wi = collections.OrderedDict()
    for ch, v, *_ in wlc:
        wi.setdefault(ch, 0)
        wi[ch] += 1
    oi = collections.OrderedDict()
    for ch, v, _ in ours:
        oi.setdefault(ch, 0)
        oi[ch] += 1

    out, wpos, opos, wacc, oacc, start = [], 0, 0, 0, 0, (0, 0)
    wchs, ochs = list(wi), list(oi)
    i = j = 0
    while i < len(wchs) or j < len(ochs):
        if wacc <= oacc and i < len(wchs):
            wacc += wi[wchs[i]]
            i += 1
        elif j < len(ochs):
            oacc += oi[ochs[j]]
            j += 1
        else:
            wacc += wi[wchs[i]]
            i += 1
        if wacc == oacc:
            out.append((start, (wacc, oacc)))
            start = (wacc, oacc)
    if start != (wacc, oacc):
        out.append((start, None))          # 닫히지 않음 → 버린다
    return out


def _corr(pairs):
    """히브리 낱말수 ↔ KJV 낱말수 상관. 밀리면 무너지는 신호다."""
    if len(pairs) < 8:
        return -1.0
    xs = [a for a, b in pairs]
    ys = [b for a, b in pairs]
    n = len(xs)
    mx, my = sum(xs) / n, sum(ys) / n
    sx = sum((a - mx) ** 2 for a in xs) ** .5
    sy = sum((b - my) ** 2 for b in ys) ** .5
    if sx == 0 or sy == 0:
        return -1.0
    return sum((a - mx) * (b - my) for a, b in zip(xs, ys)) / (sx * sy)


def solve_single_point(seg_w, seg_o, kjv):
    """구역이 정확히 ±1 어긋날 때, 그 **단일 병합·분할 지점**을 찾는다.

    §18-7 이 FreJND·SpaRV 에서 확인한 것과 같은 자리다(삼상20:42=히20:42+21:1 · 대상12:4 ·
    아·사64 분할점). 어디인지 **추측하지 않고**, 후보마다 낱말수 상관을 재서 고른다 —
    자료가 스스로 답을 말하게 하는 방식(`db_commentary_audit` 과 같은 원리).

    돌려주는 것: (매핑, 빈 절들) 또는 판정 실패 시 None.
    """
    dw, do = len(seg_w), len(seg_o)
    if abs(dw - do) != 1:
        return None
    wl = [len(w[2].split()) for w in seg_w]
    ol = [len((kjv.get(o[2]) or '').split()) for o in seg_o]
    if not any(ol):
        return None

    best, best_k = -2.0, None
    rng = range(do) if dw > do else range(dw)
    for k in rng:
        pairs = []
        if dw > do:                       # WLC 가 하나 많다 → k 에서 둘을 하나로 합친다
            for i in range(k):
                pairs.append((wl[i], ol[i]))
            pairs.append((wl[k] + wl[k + 1], ol[k]))
            for i in range(k + 1, do):
                pairs.append((wl[i + 1], ol[i]))
        else:                             # 우리가 하나 많다 → k+1 은 빈 절
            for i in range(k):
                pairs.append((wl[i], ol[i]))
            pairs.append((wl[k], ol[k]))
            for i in range(k + 1, dw):
                pairs.append((wl[i], ol[i + 1]))
        c = _corr(pairs)
        if c > best:
            best, best_k = c, k
    if best_k is None or best < 0.55:     # 신호가 약하면 고르지 않는다
        return None

    mapped, gaps = [], []
    if dw > do:
        for i in range(best_k):
            mapped.append((seg_o[i][2], seg_w[i][2], seg_w[i][3]))
        mapped.append((seg_o[best_k][2],
                       seg_w[best_k][2] + ' ' + seg_w[best_k + 1][2],
                       seg_w[best_k][3] + seg_w[best_k + 1][3]))
        for i in range(best_k + 1, do):
            mapped.append((seg_o[i][2], seg_w[i + 1][2], seg_w[i + 1][3]))
    else:
        for i in range(best_k + 1):
            mapped.append((seg_o[i][2], seg_w[i][2], seg_w[i][3]))
        gaps.append(seg_o[best_k + 1][2])
        for i in range(best_k + 1, dw):
            mapped.append((seg_o[i + 1][2], seg_w[i][2], seg_w[i][3]))
    return mapped, gaps, best


# ── 구역 검증 (2026-08-08) ──────────────────────────────────────────
# 구역이 **우연히** 닫히는 일이 있다. 안에 분할 하나와 병합 하나가 함께 들어
# 총절수만 맞아떨어지는 경우다. 길이가 같다는 이유로 순차 평탄화하면 그 구역이
# 통째로 한 절씩 밀린 채 저장된다 — 실제로 두 곳에서 그랬다(2026-08-08 발견).
#     삼상 21~23  히 21장 +1 · 23장 −1   67절
#     민  25~29   히 25장 +1 · 29장 −1  177절
# **길이만 보지 말고 내용을 봐야 한다.**
SHIFT_MIN = 0.55      # 밀린 쪽 상관이 이보다 높아야 「밀렸다」고 본다
SHIFT_GAP = 0.30      # 그리고 offset 0 보다 이만큼은 나아야 한다


def _off_corr(seg_w, seg_o, kjv, off):
    wl = [len(w[2].split()) for w in seg_w]
    ol = [len((kjv.get(o[2]) or '').split()) for o in seg_o]
    if not any(ol):
        return -1.0
    return _corr([(wl[i + off], ol[i]) for i in range(len(ol))
                  if 0 <= i + off < len(wl)])


def flat_ok(seg_w, seg_o, kjv):
    """1:1 위치 매핑을 그대로 받아들여도 되는가.

    ⚠ 시가서에서 길이 상관은 무디다(§18-10 이 애가에서 겪은 오탐). 그래서
      **절대 점수가 낮다고 물리치지 않는다.** 한쪽으로 민 것이 뚜렷하게 더 나을
      때만 물리친다. 실측 바닥값(길이가 같은 전 구역) — 욥·잠·애는 밀린 쪽 상관이
      최대 0.44 로 SHIFT_MIN 아래이고, 삼상 21~23 은 0.92(격차 0.94) ·
      민 25~29 는 0.61(격차 0.38) 이었다. 이 둘만 걸린다.
    """
    if kjv is None or len(seg_w) != len(seg_o) or len(seg_w) < 8:
        return True
    s0 = _off_corr(seg_w, seg_o, kjv, 0)
    best = max(_off_corr(seg_w, seg_o, kjv, -1), _off_corr(seg_w, seg_o, kjv, 1))
    return not (best >= SHIFT_MIN and best - s0 >= SHIFT_GAP)


def resolve_regions(segs, wlc, ours, kjv):
    """내용 검사에 걸린 구역을 이웃과 합쳐 다시 푼다.

    그 구역만 보면 답이 없다 — 삼상의 진짜 병합점은 구역 **앞**(우리 20:42 ←
    히 20:42+21:1)에 있다. 그래서 앞뒤로 넓힌 창을 모두 재 보고 **가장 높은 점수**를
    고른다. 첫 성공을 받지 않는 이유: 엉뚱한 창에서도 solve_single_point 가
    0.55 를 넘길 수 있다.

    segs 는 (wlc시작, wlc끝, 우리시작, 우리끝, 받아들일지) 5짝.
    """
    if not kjv:
        return segs
    for _ in range(len(segs) + 4):        # 합칠 때마다 다시 훑는다(진행 보장)
        target = None
        for i, (ws, we, os_, oe, ok) in enumerate(segs):
            if ok and (we - ws) == (oe - os_) \
                    and not flat_ok(wlc[ws:we], ours[os_:oe], kjv):
                target = i
                break
        if target is None:
            break
        best = None
        for lo in range(max(0, target - 2), target + 1):
            for hi in range(target, min(len(segs), target + 3)):
                if lo == hi:
                    continue
                a, c = segs[lo][0], segs[lo][2]
                b, d = segs[hi][1], segs[hi][3]
                if abs((b - a) - (d - c)) != 1:
                    continue
                got = solve_single_point(wlc[a:b], ours[c:d], kjv)
                if got and (best is None or got[2] > best[0]):
                    best = (got[2], lo, hi, (a, b, c, d, True))
        if best is None:                  # 풀 수 없다 → 검증 안 함으로 남긴다
            ws, we, os_, oe, _ok = segs[target]
            segs[target] = (ws, we, os_, oe, False)
            continue
        _, lo, hi, span = best
        segs[lo:hi + 1] = [span]
    return segs



# ── 손으로 확정한 자리 (2026-09-24 285차) ────────────────────────────
# ★★★ **자동 정렬이 두 자리를 놓쳤다 — 본문을 읽어 확정했다**(§268차 `CHAP_FIX`
#   와 같은 문법: 짐작이 아니라 원문과 BSB 를 나란히 읽고, 근거를 표 옆에 적는다).
#   찾은 방법 = `db_wlc_align_check.py` — 같은 칸의 BSB 스트롱 집합과 원문
#   스트롱 집합을 견주어 **제자리보다 이웃이 뚜렷하게 나은 절**을 잡는다.
#   실측 23,143절 가운데 **다섯 절**만 걸렸고 그 다섯이 아래 두 자리다.
#
# ⚠⚠⚠ **시편 13편 — 「우연히 닫히는 장」이었다.**
#   아래 시편 갈래는 `extra = 히브리 절수 − 우리 절수` 를 **전부 표제 몫**으로
#   본다. 그런데 시 13 은 표제(+1)와 병합(히 6 = 영 5+6, −1)이 **함께** 있어
#   `extra = 0` 이 된다. 그래서 표제가 없는 시편으로 보고 1:1 로 부어
#   **통째로 한 칸 밀렸다.** §18-7 이 삼상 21~23 · 민 25~29 에서 겪은
#   「길이만 보면 닫힌 것처럼 보이는 구역」과 **같은 병**이고, 일반 갈래에는
#   `flat_ok` 문지기가 있는데 **시편 갈래에는 없었다.**
#   근거(스트롱 자카드) — 시 13:3·13:4·13:5 는 **한 칸 앞과 1.00** 이다.
#   본문 — 우리 13:1 칸의 원문이 `למנצח מזמור לדוד`(표제뿐)인데 BSB 13:1 은
#   표제 + 「How long, O LORD?」다.
#
# ⚠⚠ **이사야 64:1 — 빈 칸을 한 칸 뒤에 두었다.**
#   히브리 63:19 가 영어 63:19 와 64:1 을 함께 덮는다(끝이 `לוא קרעת שמים`).
#   그러면 빈 칸은 **64:1** 이라야 하는데 `solve_single_point` 의 낱말 수
#   상관이 64:2 를 골랐다(히 64:1 을 우리 64:1 에 부었다).
#   근거 — 우리 64:1 칸의 원문이 BSB **64:2**(「as fire kindles the
#   brushwood…」)와 스트롱 1.00 으로 맞고, 64:3 부터는 이미 제자리다.
#
# 적는 법 = `(bcode, 장): {우리 절: (히브리 절 번호들)}` — 빈 튜플이면
#   **그 칸은 비운다**(짝 절이 덮는다). 병합·분할을 지어내지 않는다는 이
#   파일의 계약 그대로다 — 원문을 쪼개지 않고 앞 칸에 모아 둔다.
MANUAL_FIX = {
    (19, 13): {1: (1, 2), 2: (3,), 3: (4,), 4: (5,), 5: (6,), 6: ()},
    (23, 64): {1: (), 2: (1,), 3: (2,), 4: (3,), 5: (4,), 6: (5,),
               7: (6,), 8: (7,), 9: (8,), 10: (9,), 11: (10,), 12: (11,)},
}

#: 비운 칸을 **누가 덮고 있나** — `<병합 N:M>` 표식을 적을 자리다(§18-8 ④).
#: ⚠ 「이 역본에 없는 절」(느 7:68 · 아 6:14)과 **다른 사실**이라 갈라 적는다.
MERGE_PARTNER = {
    (19, 13, 6): (13, 5),        # 히 13:6 이 영 13:5 와 13:6 을 함께 덮는다
    (23, 64, 1): (63, 19),       # 히 63:19 가 영 63:19 와 64:1 을 함께 덮는다
}


def apply_manual(bcode, wlc, ours, mapped, unmapped):
    """`MANUAL_FIX` 에 적힌 장을 표대로 다시 깐다.

    ⚠ **차례를 지켜야 한다** — `db_heb_versemap._refs_for_book` 가 본문을
      원문 차례와 **앞으로만 가며** 맞추므로, 섞이면 번호를 되살리지 못하고
      그 절을 버린다. 그래서 끝에 읽기 차례(verse_id)로 다시 세운다.
    """
    chs = {ch for (b, ch) in MANUAL_FIX if b == bcode}
    if not chs:
        return mapped, unmapped
    wi = {(ch, v): (heb, st) for ch, v, heb, st in wlc}
    oi = {(ch, v): vid for ch, v, vid in ours}
    touched = {vid for (ch, v), vid in oi.items() if ch in chs}
    out = [m for m in mapped if m[0] not in touched]
    un = [v for v in unmapped if v not in touched]
    for (b, ch), table in MANUAL_FIX.items():
        if b != bcode:
            continue
        for v, hvs in sorted(table.items()):
            vid = oi.get((ch, v))
            if vid is None:
                continue
            if not hvs:
                un.append(vid)
                continue
            parts = [wi.get((ch, h)) for h in hvs]
            if any(p is None for p in parts):   # 원문이 그 번호를 안 가졌다
                un.append(vid)
                continue
            out.append((vid, ' '.join(p[0] for p in parts),
                        [x for p in parts for x in p[1]]))
    out.sort(key=lambda m: m[0])
    return out, un


def align_book(bcode, wlc, ours, kjv=None):
    """[(verse_id, heb, strongs)] + 검증 못 한 절 목록."""
    mapped, unmapped = [], []

    if bcode == PSALMS:
        # 시편은 표제가 별도 1절이다(+66). 시편마다 남는 앞 절을 1절에 합친다.
        byw = collections.OrderedDict()
        for ch, v, heb, st in wlc:
            byw.setdefault(ch, []).append((heb, st))
        byo = collections.OrderedDict()
        for ch, v, vid in ours:
            byo.setdefault(ch, []).append(vid)
        for ch, ws in byw.items():
            os_ = byo.get(ch)
            if not os_:
                continue
            extra = len(ws) - len(os_)
            if extra < 0:
                unmapped.extend(os_)
                continue
            head = ws[:extra + 1]                       # 표제 + 첫 절
            rest = ws[extra + 1:]
            mapped.append((os_[0], ' '.join(h for h, _ in head),
                           [s for _, ss in head for s in ss]))
            for vid, (heb, st) in zip(os_[1:], rest):
                mapped.append((vid, heb, st))
            if len(rest) != len(os_) - 1:
                unmapped.extend(os_[1 + len(rest):])
        return apply_manual(bcode, wlc, ours, mapped, unmapped)

    segs = []
    for (ws, os_), end in regions(wlc, ours):
        we, oe = end if end else (len(wlc), len(ours))
        # 닫히지 않은 구역(end is None)도 종전대로 solve_single_point 에 맡긴다.
        # ok=False 는 resolve_regions 가 「풀 수 없다」고 판정했을 때만 붙는다.
        segs.append((ws, we, os_, oe, True))
    segs = resolve_regions(segs, wlc, ours, kjv)

    for ws, we, os_, oe, ok in segs:
        seg_w, seg_o = wlc[ws:we], ours[os_:oe]
        if not ok:                        # 내용 검사에 걸렸는데 풀리지도 않았다
            unmapped.extend(v[2] for v in seg_o)
            continue
        if len(seg_w) == len(seg_o):
            for (ch, v, heb, st), (_, _, vid) in zip(seg_w, seg_o):
                mapped.append((vid, heb, st))
            continue
        # ±1 이면 단일 병합·분할 지점을 자료로 찾아본다
        got = solve_single_point(seg_w, seg_o, kjv) if kjv else None
        if got:
            m, gaps, _score = got
            mapped.extend(m)
            unmapped.extend(gaps)
        else:
            unmapped.extend(v[2] for v in seg_o)
    return apply_manual(bcode, wlc, ours, mapped, unmapped)


def run(build=False):
    conn = sqlite3.connect(SRC_DB)
    ours = our_index(conn)
    kjv = dict(conn.execute("SELECT verse_id, verse_text FROM bible_content "
                            "WHERE version_code='KJV'"))
    all_map, all_un = [], []
    per = []
    for i, name in enumerate(OSIS):
        b = i + 1
        wlc = read_book(name)
        m, u = align_book(b, wlc, ours[b], kjv)
        per.append((name, b, len(wlc), len(ours[b]), len(m), len(u)))
        all_map.extend(m)
        all_un.extend(u)

    tot_ours = sum(len(v) for v in ours.values())
    print('WLC 절 %d · 우리 구약 절 %d' % (sum(p[2] for p in per), tot_ours))
    print('정렬 성공 %d (%.1f%%) · 검증 안 함 %d'
          % (len(all_map), 100.0 * len(all_map) / tot_ours, len(all_un)))
    print()
    bad = [p for p in per if p[5]]
    if bad:
        print('검증 못 한 절이 있는 책 %d:' % len(bad))
        for name, b, w, o, m, u in sorted(bad, key=lambda x: -x[5]):
            print('  %-6s WLC %5d / 우리 %5d — 정렬 %5d · 미검증 %4d (%.0f%%)'
                  % (name, w, o, m, u, 100.0 * u / o))
    else:
        print('전 권 정렬 성공.')

    if build:
        if os.path.exists(OUT_DB):
            os.remove(OUT_DB)
        out = sqlite3.connect(OUT_DB)
        out.executescript(
            'CREATE TABLE wlc_verse (verse_id INTEGER PRIMARY KEY, heb TEXT, strongs TEXT);'
            'CREATE TABLE wlc_meta (k TEXT PRIMARY KEY, v TEXT);')
        out.executemany('INSERT OR REPLACE INTO wlc_verse VALUES (?,?,?)',
                        [(vid, heb, ' '.join(st)) for vid, heb, st in all_map])
        out.executemany('INSERT INTO wlc_meta VALUES (?,?)', [
            ('source', 'openscriptures/morphhb (OSHB)'),
            ('text_license', 'WLC text: Public Domain (Christopher Kimball)'),
            ('lemma_license', 'Lemma/morphology: CC BY 4.0 — Open Scriptures Hebrew Bible Project'),
            ('distribution', 'LOCAL ONLY. Never ship in bible_master.db.'),
            ('aligned', str(len(all_map))), ('unaligned', str(len(all_un))),
        ])
        out.commit()
        out.close()
        print()
        print('저장: %s (%d행) — ★ 배포 금지, gitignore' % (OUT_DB, len(all_map)))
    return 0


def selftest():
    """정렬이 정말 맞는지 — 히브리 낱말 수와 KRV 자수가 따라 움직이는가."""
    ok = True

    def chk(c, m):
        nonlocal ok
        print(('  OK   ' if c else '  FAIL ') + m)
        ok = ok and c

    conn = sqlite3.connect(SRC_DB)
    ours = our_index(conn)
    kjv = dict(conn.execute("SELECT verse_id, verse_text FROM bible_content "
                            "WHERE version_code='KJV'"))

    # 룻기 — 총절수 일치 책, 장경계 이동 없음
    m, u = align_book(8, read_book('Ruth'), ours[8], kjv)
    chk(len(u) == 0, '룻기 미검증 0 (실제 %d)' % len(u))
    chk(len(m) == len(ours[8]), '룻기 전절 정렬 %d/%d' % (len(m), len(ours[8])))

    # 요엘 — 히브리 4장 / 영어 3장. 구역 평탄화가 흡수해야 한다
    m, u = align_book(29, read_book('Joel'), ours[29], kjv)
    chk(len(u) == 0, '요엘(장경계 이동) 미검증 0 (실제 %d)' % len(u))

    # 삼상 — 총절수 +1. 단일 병합 지점을 자료로 찾아야 한다
    m, u = align_book(9, read_book('1Sam'), ours[9], kjv)
    chk(len(u) == 0, '삼상(단일 병합점) 미검증 0 (실제 %d)' % len(u))

    # ★ 우연히 닫힌 구역 (2026-08-08 신설 — 이 검사가 없어서 넉 달간 밀린 채 있었다)
    #   구역 안에 분할 하나와 병합 하나가 함께 들어 총절수만 맞으면, 길이가 같다는
    #   이유로 순차 평탄화되어 구역 전체가 한 절씩 밀린다. 두 곳에서 실제로 그랬다.
    #   길이로는 못 잡는다 — **내용을 대야 한다.**
    ANCHORS = [
        (9, '1Sam', 21,  1, ['H5011'],          '놉 — 삼상 21~23 구역(67절)'),
        (9, '1Sam', 22, 18, ['H646', 'H906'],   '세마포 에봇 팔십오 인'),
        (9, '1Sam', 23,  6, ['H646'],           '아비아달이 에봇을 가지고'),
        (9, '1Sam', 23, 29, ['H5872'],          '엔게디 요새(우리 23:29 ← 히 24:1)'),
        (4, 'Num',  26,  1, ['H4046', 'H499'],  '염병+엘르아살 — 민 25~29 구역(177절)'),
        (4, 'Num',  26,  2, ['H5375', 'H7218'], '총수를(나사 로쉬)'),
        (4, 'Num',  29, 40, ['H4872'],          '모세가 고하니라'),
    ]
    cache = {}
    for b, nm, ch, v, need, what in ANCHORS:
        if b not in cache:
            mm, _uu = align_book(b, read_book(nm), ours[b], kjv)
            cache[b] = {vid: st for vid, heb, st in mm}
        r = conn.execute('SELECT verse_id FROM bible_index WHERE bcode=? '
                         'AND chapter=? AND verse=?', (b, ch, v)).fetchone()
        got = set(cache[b].get(r[0], []) if r else [])
        chk(bool(r) and all(s in got for s in need),
            '%s %d:%d 앵커 — %s (%s)' % (nm, ch, v, what, ' '.join(need)))

    # flat_ok 자체의 탐지력 — 인위로 한 절 민 구역을 만들면 잡아야 한다
    wl_ok = read_book('1Sam')[:60]
    ou_ok = ours[9][:60]
    chk(flat_ok(wl_ok, ou_ok, kjv), 'flat_ok — 맞는 구역은 통과')
    chk(not flat_ok(wl_ok[1:], ou_ok[:-1], kjv), 'flat_ok — 한 절 민 구역은 물리침')

    # 시편 23편 — 표제 있음. 우리 1절에 표제가 합쳐져야 한다
    mp, _ = align_book(PSALMS, read_book('Ps'), ours[PSALMS], kjv)
    d = {vid: (heb, st) for vid, heb, st in mp}
    vid23 = conn.execute('SELECT verse_id FROM bible_index WHERE bcode=19 AND chapter=23 '
                         'AND verse=1').fetchone()[0]
    chk(vid23 in d, '시 23:1 정렬됨')
    if vid23 in d:
        chk('H4210' in d[vid23][1] or 'H1732' in d[vid23][1],
            '시 23:1 에 표제 낱말(미즈모르 H4210 / 다윗 H1732) 포함 — %s'
            % ' '.join(d[vid23][1][:4]))

    # 정렬 검증 — 히브리 낱말 수와 KJV 낱말 수의 상관 (밀리면 무너진다)
    m, _ = align_book(1, read_book('Gen'), ours[1], kjv)

    def corr(shift):
        xs, ys = [], []
        for i, (vid, heb, st) in enumerate(m):
            j = i + shift
            if 0 <= j < len(m):
                t = kjv.get(m[j][0])
                if t:
                    xs.append(len(heb.split()))
                    ys.append(len(t.split()))
        n = len(xs)
        mx, my = sum(xs) / n, sum(ys) / n
        cov = sum((a - mx) * (b - my) for a, b in zip(xs, ys))
        sx = sum((a - mx) ** 2 for a in xs) ** .5
        sy = sum((b - my) ** 2 for b in ys) ** .5
        return cov / (sx * sy)

    c0, cm, cp = corr(0), corr(-1), corr(1)
    chk(c0 > 0.75, '창세기 낱말수 상관 offset0 = %.2f (>0.75)' % c0)
    chk(c0 > cm + 0.2 and c0 > cp + 0.2,
        '이웃 오프셋보다 뚜렷이 높다 (−1 %.2f · +1 %.2f)' % (cm, cp))

    # 애가 이합체 — 길이 신호보다 훨씬 강한 근거.
    # ⚠ 애가는 절 길이가 고르게 짧아 **길이 상관으로는 오탐이 난다**(off0 0.93 vs 이웃 0.86).
    #   시가서에서 길이 신호를 믿지 말 것. 여기서는 알파벳 순서가 정답을 말한다.
    ALEPHBET = 'אבגדהוזחטיכלמנסעפצקרשת'
    ref = dict(conn.execute("SELECT verse_id, chapter || ':' || verse "
                            "FROM bible_index WHERE bcode=25"))
    ml, _ = align_book(25, read_book('Lam'), ours[25], kjv)
    bych = {}
    for vid, heb, st in ml:
        r = ref.get(vid)
        if r:
            c, v = (int(x) for x in r.split(':'))
            bych.setdefault(c, []).append((v, heb))

    def first(h):
        for c in h:
            if c in ALEPHBET:
                return c
        return '?'

    for ch in (1, 2, 4):
        vs = sorted(bych.get(ch, []))
        L = [first(h) for _, h in vs]
        # 2·3·4장은 히브리 원문에서 ע/פ 가 도치돼 있다 — 그것까지 정상으로 본다
        good = len(L) == 22 and all(a == b for a, b in zip(L, ALEPHBET)
                                    if a not in 'עפ' and b not in 'עפ')
        chk(good, '애가 %d장 이합체 알파벳 순서 (%d절)' % (ch, len(vs)))
    v3 = [first(h) for _, h in sorted(bych.get(3, []))]
    chk(len(v3) == 66 and all(v3[i] == v3[i + 1] == v3[i + 2] for i in range(0, 64, 3)),
        '애가 3장 66절 3연속 동일 문자')

    print('SELFTEST', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--align', action='store_true')
    ap.add_argument('--build', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    return run(build=a.build)


if __name__ == '__main__':
    sys.exit(main())
