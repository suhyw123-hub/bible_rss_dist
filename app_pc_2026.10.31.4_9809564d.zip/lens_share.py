# -*- coding: utf-8 -*-
"""lens_share.py — 내 렌즈 내보내기/가져오기 (영구, 2026-08-17 의견서 10 채택 1단계).

★ **포맷 = `db_lens_load` 초안 JSON 그대로다.** 멱등 열쇠가 번호가 아니라 이름이고
  구절이 약명 참조(`창 22:1-14`)라, 처음부터 DB 가 다른 컴퓨터로 옮겨도 되는
  구조였다. 여기에 `made_by`(만든이, 선택)와 `app`(표식)만 얹는다.
★ **가져오기는 언제나 user 영역으로만** — sys 는 불가침. 이름이 겹치면 ` (2)`
  꼬리표(plan_builder 와 같은 규칙). 순수 데이터라 실행 위험이 없다.
★ 전달은 파일 그대로(이메일·메신저·USB) — 오프라인 원칙. 서버 공유(우편함
  모델)는 2단계, 사용자 결정으로 **보류**.
⚠ **구절 참조는 KO 약명으로 적는다** — `scripture_ref_kr.resolve` 가 푸는 표기다.
  받은 쪽 언어 설정과 무관하다(참조는 데이터, 표시는 화면 몫).
⚠ 사용자 글은 언어 필터 없이 **전부** 내보낸다(2026-08-17 언어 공통원칙).

    python lens_share.py --selftest        (의무)
"""
import json
import sys

import appdb

APP_MARK = 'hagah-lens'
FMT = 1

NODE_TT = {'desc': 'NODE_DESC', 'question': 'NODE_QUESTION',
           'prayer': 'NODE_PRAYER'}


def _texts(conn, tbl, tt, cid):
    """글 하나의 언어별 dict — user 는 lang 필터 없이 전부."""
    out = {}
    for lang, body in conn.execute(
            f"SELECT lang_code, contents FROM {tbl} WHERE text_type=? "
            "AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'",
            (tt, cid)):
        if body and (body or '').strip():
            out[(lang or 'KO').upper()] = body.strip()
    return out


def _ref_of(conn, a, b=None):
    """verse_id (구간) → KO 약명 참조 `창 22:1-14`."""
    # ⚠ book_names 의 칼럼은 `book_code` 다 — `bcode=bi.bcode` 로 쓰면 둘 다
    #   바깥(bi.bcode)으로 묶여 **항상 참**이 되어 아무 책이나 잡힌다(실제로
    #   요한복음이 '창' 으로 나갔다. 오류도 안 났다 — 상관 하위질의 함정).
    r = conn.execute(
        "SELECT bi.chapter, bi.verse, "
        "(SELECT short_name FROM book_names WHERE book_code=bi.bcode "
        " AND UPPER(lang_code)='KO' LIMIT 1) "
        "FROM bible_index bi WHERE bi.verse_id=?", (a,)).fetchone()
    if not r:
        return None
    ref = '%s %s:%s' % (r[2], r[0], r[1])
    if b and b != a:
        r2 = conn.execute("SELECT chapter, verse FROM bible_index "
                          "WHERE verse_id=?", (b,)).fetchone()
        if r2:
            ref += ('-%s' % r2[1]) if r2[0] == r[0] else ('-%s:%s' % r2)
    return ref


def export_lens(conn, user_unit_id, made_by=''):
    """USER 렌즈 하나 → 초안 dict. 없으면 None."""
    row = conn.execute(
        "SELECT unit_name_sid FROM user_unit_asset WHERE user_unit_id=? "
        "AND unit_type='CONTAINER' AND COALESCE(record_status,'LIVE')='LIVE'",
        (user_unit_id,)).fetchone()
    if not row:
        return None
    d = {'app': APP_MARK, 'fmt': FMT, 'lens': row[0]}
    if made_by:
        d['made_by'] = made_by
    d['desc'] = _texts(conn, 'user_text_asset', 'CONT_DESC', user_unit_id)
    d['nodes'] = []
    for nid, nm in conn.execute(
            "SELECT u.user_unit_id, u.unit_name_sid FROM user_link_asset l "
            "JOIN user_unit_asset u ON u.user_unit_id=l.target_id "
            "WHERE l.link_type='CONT_NODE' AND l.clicked_id=? "
            "AND COALESCE(l.record_status,'LIVE')='LIVE' "
            "ORDER BY l.sort_order, l.user_link_id", (user_unit_id,)):
        nd = {'name': nm}
        for key, tt in NODE_TT.items():
            t = _texts(conn, 'user_text_asset', tt, nid)
            if t:
                nd[key] = t
        nd['verses'] = []
        for lid, a, e in conn.execute(
                "SELECT user_link_id, target_id, end_id FROM user_link_asset "
                "WHERE link_type='NODE_VERS' AND clicked_id=? "
                "AND COALESCE(record_status,'LIVE')='LIVE' "
                "ORDER BY sort_order, user_link_id", (nid,)):
            ref = _ref_of(conn, a, e)
            if not ref:
                continue
            v = {'ref': ref}
            t = _texts(conn, 'user_text_asset', 'NODE_VERS_DESC', lid)
            if t:
                v['desc'] = t
            nd['verses'].append(v)
        d['nodes'].append(nd)
    return d


def preview(draft):
    """가져오기 전에 보여줄 요약 한 줄."""
    nodes = draft.get('nodes') or []
    n_v = sum(len(nd.get('verses') or []) for nd in nodes)
    who = draft.get('made_by') or ''
    return ('렌즈 「%s」 · 노드 %d · 구절 참조 %d%s'
            % (draft.get('lens', '?'), len(nodes), n_v,
               (' · 만든이 %s' % who) if who else ''))


def _unique_name(conn, base):
    """user 자산 이름 겹침 — ` (2)` 꼬리표 (plan_builder 규칙).

    ⚠ `user_unit_asset.unit_name_sid` 에 **UNIQUE 제약이 있다**(실측 — 렌즈든
      노드든 이름이 전역에서 겹치면 INSERT 가 터진다). 그래서 unit_type 을
      가리지 않고, HIDE 행까지 포함해 센다.
    """
    name, n = base, 1
    while conn.execute(
            "SELECT 1 FROM user_unit_asset WHERE unit_name_sid=? LIMIT 1",
            (name,)).fetchone():
        n += 1
        name = '%s (%d)' % (base, n)
    return name


def import_lens(conn, draft, cat_id=None, name=None):
    """초안 → **user 영역**에 새 렌즈로. (user_unit_id, 이름)을 돌려준다.

    ⚠ 멱등이 아니라 **새로 만든다** — 공유받은 렌즈는 남의 것이라 덮어쓸 원본이
      없다. `name` 을 주면 그 이름으로(UI 가 중복 검사 후 사용자에게 물어 정한
      이름 — 2026-08-17 사용자 지시). 그래도 겹치면 ` (2)` 안전망이 잡는다.
    cat_id=None 이면 「나의 렌즈」(사용자 전용 카테고리)로 들어간다.
    """
    import scripture_ref_kr
    if draft.get('app') != APP_MARK:
        raise ValueError('이 앱의 렌즈 파일이 아닙니다')
    try:
        return _import_body(conn, draft, cat_id, scripture_ref_kr, name)
    except Exception:
        conn.rollback()                 # 반쪽짜리 렌즈를 남기지 않는다
        raise


def _import_body(conn, draft, cat_id, scripture_ref_kr, name_override=None):
    base = (name_override or draft.get('lens') or '이름 없는 렌즈').strip()
    name = _unique_name(conn, base)

    def put_texts(tt, cid, d):
        for lang, body in (d or {}).items():
            body = ' '.join((body or '').split())     # 엔터 금지 정책
            if body:
                conn.execute(
                    "INSERT INTO user_text_asset (text_type, clicked_id, "
                    "lang_code, contents, record_status, created_at, updated_at) "
                    "VALUES (?,?,?,?,'LIVE',DATETIME('now','localtime'),"
                    "DATETIME('now','localtime'))", (tt, cid, lang, body))

    r = conn.execute(
        "SELECT COALESCE(MAX(sort_order),0) FROM user_unit_asset "
        "WHERE unit_type='CONTAINER' AND COALESCE(cat_id,-1)=COALESCE(?,-1)",
        (cat_id,)).fetchone()
    cur = conn.execute(
        "INSERT INTO user_unit_asset (unit_type, unit_name_sid, sort_order, "
        "record_status, cat_id) VALUES ('CONTAINER',?,?,'LIVE',?)",
        (name, (r[0] or 0) + 10, cat_id))
    lens_id = cur.lastrowid
    put_texts('CONT_DESC', lens_id, draft.get('desc'))

    for order, nd in enumerate(draft.get('nodes') or [], 1):
        # ⚠ 노드 이름도 전역 UNIQUE — 다른 렌즈에 같은 이름의 노드가 있으면 꼬리표
        nd_name = _unique_name(conn, (nd.get('name') or '노드').strip())
        cur = conn.execute(
            "INSERT INTO user_unit_asset (unit_type, unit_name_sid, sort_order, "
            "record_status) VALUES ('NODE',?,?,'LIVE')", (nd_name, order * 10))
        nid = cur.lastrowid
        conn.execute(
            "INSERT INTO user_link_asset (clicked_id, target_id, link_type, "
            "sort_order, record_status) VALUES (?,?,'CONT_NODE',?,'LIVE')",
            (lens_id, nid, order * 10))
        for key, tt in NODE_TT.items():
            put_texts(tt, nid, nd.get(key))
        for vorder, v in enumerate(nd.get('verses') or [], 1):
            a, b = scripture_ref_kr.resolve(conn, (v.get('ref') or '').strip())
            if a is None:                       # ⚠ 실패는 (None, None) — §21-4
                continue
            cur = conn.execute(
                "INSERT INTO user_link_asset (clicked_id, target_id, end_id, "
                "link_type, sort_order, record_status) "
                "VALUES (?,?,?,'NODE_VERS',?,'LIVE')",
                (nid, a, (b if b != a else None), vorder * 10))
            put_texts('NODE_VERS_DESC', cur.lastrowid, v.get('desc'))
    conn.commit()
    return lens_id, name


# ── 자가검증 ──────────────────────────────────────────────────────────────

def selftest():
    ok = True
    conn = appdb.connect('bible_master.db')
    made = []                                    # 정리할 user_unit_id
    try:
        draft = {'app': APP_MARK, 'fmt': FMT, 'lens': '검사 공유렌즈',
                 'made_by': '검사자',
                 'desc': {'KO': '검사 설명'},
                 'nodes': [{'name': '검사 노드', 'desc': {'KO': '노드 설명'},
                            'question': {'KO': '질문'}, 'prayer': {'KO': '기도'},
                            'verses': [{'ref': '창 1:3'},
                                       {'ref': '요 1:1-5',
                                        'desc': {'KO': '구간 설명'}}]}]}
        # ① 미리보기
        if '검사 공유렌즈' not in preview(draft) or '노드 1' not in preview(draft):
            print('FAIL preview: %s' % preview(draft)); ok = False
        # ② 가져오기 → 구조 확인
        lid, name = import_lens(conn, draft)
        made.append(lid)
        rng = conn.execute(
            "SELECT l.target_id, l.end_id FROM user_link_asset l "
            "JOIN user_link_asset cn ON cn.link_type='CONT_NODE' "
            " AND cn.clicked_id=? AND cn.target_id=l.clicked_id "
            "WHERE l.link_type='NODE_VERS' AND l.end_id IS NOT NULL",
            (lid,)).fetchone()
        if not rng or rng[1] - rng[0] != 4:
            print('FAIL 구간 end_id: %s' % (rng,)); ok = False
        # ③ 내보내기 → 원본과 같은 내용인가 (열쇠 칸만 대조)
        out = export_lens(conn, lid, made_by='검사자')
        if out['lens'] != name or len(out['nodes']) != 1:
            print('FAIL export 머리: %s' % out.get('lens')); ok = False
        nd = out['nodes'][0]
        if nd.get('prayer', {}).get('KO') != '기도':
            print('FAIL prayer 왕복'); ok = False
        refs = [v['ref'] for v in nd['verses']]
        if refs != ['창 1:3', '요 1:1-5']:
            print('FAIL 참조 왕복: %s' % refs); ok = False
        if nd['verses'][1].get('desc', {}).get('KO') != '구간 설명':
            print('FAIL 구간 desc 왕복'); ok = False
        # ④ 겹침 — 같은 파일을 또 가져오면 ` (2)`
        lid2, name2 = import_lens(conn, draft)
        made.append(lid2)
        if name2 != '검사 공유렌즈 (2)':
            print('FAIL 겹침 꼬리표: %r' % name2); ok = False
        # ⑤ 남의 파일 거절
        try:
            import_lens(conn, {'lens': 'x'})
            print('FAIL 표식 없는 파일을 받았다'); ok = False
        except ValueError:
            pass
    finally:
        # 정리 — 새 프로세스 확인은 못 하지만 개수로 검증한다
        for lid in made:
            nodes = [r[0] for r in conn.execute(
                "SELECT target_id FROM user_link_asset WHERE link_type='CONT_NODE' "
                "AND clicked_id=?", (lid,))]
            if nodes:
                q = ','.join('?' * len(nodes))
                links = [r[0] for r in conn.execute(
                    "SELECT user_link_id FROM user_link_asset "
                    "WHERE link_type='NODE_VERS' AND clicked_id IN (%s)" % q, nodes)]
                if links:
                    conn.execute("DELETE FROM user_text_asset WHERE "
                                 "text_type='NODE_VERS_DESC' AND clicked_id IN (%s)"
                                 % ','.join('?' * len(links)), links)
                conn.execute("DELETE FROM user_link_asset WHERE "
                             "link_type='NODE_VERS' AND clicked_id IN (%s)" % q, nodes)
                conn.execute("DELETE FROM user_text_asset WHERE text_type IN "
                             "('NODE_DESC','NODE_QUESTION','NODE_PRAYER') "
                             "AND clicked_id IN (%s)" % q, nodes)
                conn.execute("DELETE FROM user_unit_asset WHERE user_unit_id IN (%s)"
                             % q, nodes)
            conn.execute("DELETE FROM user_link_asset WHERE link_type='CONT_NODE' "
                         "AND clicked_id=?", (lid,))
            conn.execute("DELETE FROM user_text_asset WHERE text_type='CONT_DESC' "
                         "AND clicked_id=?", (lid,))
            conn.execute("DELETE FROM user_unit_asset WHERE user_unit_id=?", (lid,))
        conn.commit()
        left = conn.execute("SELECT COUNT(*) FROM user_unit_asset "
                            "WHERE unit_name_sid LIKE '검사%'").fetchone()[0]
        if left:
            print('FAIL 검사 자료가 남았다: %d' % left); ok = False
        conn.close()
    print('lens_share selftest', 'OK' if ok else 'FAIL')
    return ok


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print(__doc__.split('\n')[0])
