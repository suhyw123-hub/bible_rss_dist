# -*- coding: utf-8 -*-
"""desc_comm_group.py — 「설명」 그룹 탭의 5갈래 단추 줄 (v2 — 2026-08-26).

★ 2안(사용자 승인 「2안으로 진행하라」): [책][장][단락][일반][전문] + 언어콤보.
  주석 두 갈래(주석본문·주석링크)는 **「주석/링크」 탭**(옛 링크 탭)으로 갔다 —
  이 줄은 전부 **우리가 쓴 글**(책 개요→장→단락→절 계층 + 티어)만 남는다.
  6갈래 513px → 5갈래 402px 로 P2 기본 폭(420px) 한 줄에 다시 들어간다(실측).

  · 책/장/단락/일반/전문 = 설명 화면 + verse_tier 모드(BOOK/CHAP/PERI/LAY/EXPERT)
  · 언어콤보 = variant_items(English/Modern English/각 언어).
    verse_tier.set_desc_lang(변형이면 EN). 직전값 key='LANGSEL_DESCCOMM'.
    ⚠ LANGSEL_DESC 에는 **언어 코드만** 다시 써 준다 — fetch 계층
      (verse_tier.get_desc_lang)이 그 열쇠로 읽는다.

⚠ make_comm 인자는 **호환용으로 받기만 한다**(옛 호출부 보호) — 주석 패널
  생성은 이제 「주석/링크」 탭의 몫이다.
"""

import tkinter as tk
import i18n
import appdb

def _flat(**over):
    """My Edit·Recent 류 **테두리 없는 단추** — 모양의 단일 소스는 `ui_theme`.

    ⚠ 화면마다 손으로 적으면 갈라진다(실측 7곳이 bd·padx·글꼴이 제각각이었다 —
      2026-08-30 사용자 지시 「My Edit 버튼의 디자인을 통일하라. Recent 버튼과
      동일하게」).
    """
    try:
        import ui_theme
        return ui_theme.flat_btn(**over)
    except Exception:
        return dict(bd=1, padx=6, pady=2, cursor='hand2', **over)


BAR_H = 27


def _C(role, fallback):
    try:
        import ui_theme
        return ui_theme.C(role)
    except Exception:
        return fallback


class DescCommGroup(tk.Frame):

    DESC_KEYS = ('book', 'chap', 'peri', 'lay', 'expert')
    MODE = {'book': 'BOOK', 'chap': 'CHAP', 'peri': 'PERI',
            'lay': 'LAY', 'expert': 'EXPERT'}
    LABELS = (('book', 'DG_BOOK', '책'),
              ('chap', 'DG_CHAP', '장'),
              ('peri', 'DG_PERI', '단락'),
              ('lay', 'DG_LAY', '일반'),
              ('expert', 'DG_EXPERT', '전문'))

    def __init__(self, parent, db_path, refresh_desc, make_comm,
                 state_key, on_edit=None, ext_bar=None, ref_host=None, lang_only=False,
                 on_role_ask=None, **kw):
        """refresh_desc() — 모드·언어가 바뀐 뒤 설명문을 다시 그리는 콜백.
        make_comm(parent_frame) → CommentaryPanel — 첫 주석 갈래에서 지연 생성.
        on_edit() — 「내 설명」 팝업(덮개 편집)을 여는 콜백(2026-08-26). 주면
        약명 오른쪽에 작은 단추가 생긴다.
        ext_bar — **밖의 줄**(2026-09-16 · 1.txt 19-1 「언어콤보·My Edit·M 을
        최상단 오른쪽에 공통 배치」). 주면 언어콤보·[My Edit] 을 그 줄의 자식으로
        만들되 **pack 하지 않는다** — 호스트가 `tools()` 로 받아 지금 갈래일 때만
        보인다. 이 줄에는 약명 + 다섯 단추만 남고 접이(`_bar2`)도 없다.
        `manual_slot()` 은 None — M 도 호스트 줄의 것이다.
        ⚠ 주석 패널은 반드시 external_nav=True, ext_lang=self.combo 로 만들 것."""
        super().__init__(parent, **kw)
        self.db_path = db_path
        self.refresh_desc = refresh_desc
        self.make_comm = make_comm
        self.state_key = state_key
        self.on_edit = on_edit
        self.on_role_ask = on_role_ask   # (분야 코드) → AI 도우미를 「이 구절 · 이 분야」로 연다(없으면 메뉴 줄을 안 둔다)
        self._ext_bar = ext_bar
        self.extra_on_lang = None      # 호스트가 건다 — 공유 콤보가 바뀌면 주석도 다시 그린다
        self._comm = None
        self._cur = None
        self._btns = {}

        # ── 단추 줄 (27px) + 자동 접이용 둘째 줄 ──
        self._bar = tk.Frame(self, height=BAR_H)
        self._bar.pack(fill='x')
        self._bar.pack_propagate(False)
        self._bar2 = tk.Frame(self, height=BAR_H)   # 좁을 때만 나타난다

        # ★★★ **구절 약명은 맨 왼쪽 고정** (2026-08-30 사용자 지시 0.txt 1-1
        #   「수정후 배치순서 : 현재 구절라벨(예: 창1:8), 책/장/단락/일반/전문,
        #   (공백), 언어콤보, My Edit, (공백) M버튼」).
        #   ⚠ 그전에는 오른쪽 끝(`side='right'`)이라 좁아지면 **콤보와 함께
        #     둘째 줄로 밀려** 「지금 무슨 절인지」가 갈래 단추에서 멀어졌다.
        #     실측 P2(399px)에서 라벨이 둘째 줄 x=99 에 있었다.
        #   ⚠ 여기서는 **접지 않는다** — 「지금 무슨 절인가」는 갈래 단추와 붙어
        #     있어야 뜻이 산다(그것을 알리려고 만든 라벨이다).
        #   ★ `ref_host`(2026-09-16 · 1.txt 22) — 주면 약명을 **그 칸**에 그린다. P2 는
        #     SplitTabs 윗줄 맨 왼쪽 칸(`left_slot`)을 주어 어떤 갈래를 눌러도 보인다.
        self._ref_lbl = tk.Label(ref_host if ref_host is not None else self,
                                 text='', anchor='w',
                                 fg=_C('accent', '#1A5276'), font=('', 9, 'bold'))
        if ref_host is not None:
            self._ref_lbl.pack(side='left', padx=(4, 8))
        else:
            self._ref_lbl.pack(in_=self._bar, side='left', padx=(2, 8))

        for i, (key, ikey, dflt) in enumerate(self.LABELS):
            b = tk.Button(self._bar, text=' %s ' % i18n.t(ikey, dflt),
                          bd=0, relief='flat', padx=6, pady=3, cursor='hand2',
                          command=lambda k=key: self.select(k))
            b.pack(side='left', padx=(0 if i == 0 else 2, 0))
            self._btns[key] = b

        # ⚠⚠ **부모를 `self` 로 둔다 — `self._bar` 가 아니다.** (2026-08-23 실측)
        #   좁아지면 이 콤보를 `_bar2` 로 내리는데, Tk 의 `pack(in_=X)` 는
        #   **X 가 그 위젯의 master 이거나 master 의 자손일 때만** 된다.
        #   부모가 `_bar` 이면 `_bar2`(형제)로는 **옮길 수 없어 TclError** 가 나고,
        #   그 자리가 `except: pass` 라 **콤보가 조용히 사라졌다** — 실측하니
        #   P2(폭 377px)에서 언어 콤보가 아예 안 보이고 있었다(내 변경 이전부터).
        #   부모를 `self` 로 두면 `_bar`·`_bar2` 둘 다 자손이라 오갈 수 있다.
        # ★★★ **M 자리를 먼저 잡아 둔다 — 그래야 M 이 「항상」 맨 오른쪽이다**
        #   (2026-08-30 사용자 지시 「항상 M 버튼은 가장 오른쪽에 배치하라.
        #   시간이 지나면 사용빈도가 높지 않기 때문이다」).
        #   ⚠⚠ 그전에는 호스트가 `_manual_at(dg.bar())` 로 **나중에** 붙였다.
        #     `pack(side='right')` 는 **부른 차례로 오른쪽부터 쌓이므로**, 늦게
        #     붙은 M 이 오히려 **콤보·약명보다 왼쪽**에 놓였다(실측 x=375 로
        #     세 번째). ⇒ 빈 프레임을 **가장 먼저** 오른쪽에 못 박고 호스트는
        #     `manual_slot()` 안에 심는다. 붙이는 차례가 자리를 못 바꾼다.
        # ★ 2026-10-13 (docs/1.txt 76-3) — 「분야 ▾」 = [전문] 일 때만 · 보일 분야 체크 · AI 에게 내 분야 관점으로 묻기
        self._role_mb = tk.Menubutton(self._bar, text=' %s ▾ ' % i18n.t('ROLE_MENU', '분야'),
                                      relief='flat', bd=0, padx=6, pady=3, cursor='hand2')
        self._role_menu = tk.Menu(self._role_mb, tearoff=0, postcommand=self._fill_role_menu)
        self._role_mb.configure(menu=self._role_menu)
        self._role_vars = {}

        _tp = self._ext_bar if self._ext_bar is not None else self
        self._m_slot = None
        if self._ext_bar is None:
            self._m_slot = tk.Frame(self)
            self._m_slot.pack(in_=self._bar, side='right', padx=(0, 2))

        import lang_combo
        # ★ 2026-10-13 (docs/1.txt 75) — `lang_only` = **설명 언어만**(P2 — 주석이 없다). 주석 변형(Modern English …)을
        #   빼고 제 열쇠로 기억한다. 처음 값은 지금 설명 언어(LANGSEL_DESC)라 화면이 갑자기 바뀌지 않는다.
        _dl = (i18n.get_lang() or 'KO').upper()
        if lang_only:
            try:
                import verse_tier
                with appdb.connect(db_path) as _c:
                    _dl = verse_tier.get_desc_lang(_c, _dl)
            except Exception:
                pass
        self.langsel = lang_combo.LangCombo(
            _tp, db_path=db_path, on_change=self._on_lang,
            width=8, gap=6, pady=0, side='right',
            default_lang=_dl,
            key=('LANGSEL_P2_DESC' if lang_only else 'LANGSEL_DESCCOMM'))
        self.langsel.combo.pack_forget()
        self.langsel.set_items(lang_combo.lang_items() if lang_only else lang_combo.variant_items())
        self.combo = self.langsel        # 주석 패널의 ext_lang 으로 넘긴다

        # ★★ **지금 무슨 절인지 적는다** (2026-08-23 사용자 「여러 곳에서 구절을
        #   클릭하면 P2 에서 표시되는데 **과연 클릭한 구절의 설명문인지 알 수가
        #   없다**」). P4 는 이미 구절을 보여 준다 — P2 만 없었다.
        #   ★ 자리는 **모드 단추 오른쪽·언어 콤보 왼쪽**이다.
        #     ⚠ 「일반설명(창1:1)」처럼 **단추 글자에 붙이지 않는다** — 모드가
        #       넷이라 같은 약명이 네 번 반복되고, 다국어에서 단추가 길어져
        #       좁은 P2(420px)에서 줄이 접힌다.
        #     ⚠ 사용자가 말한 「빈 공간」은 **예비된 자리가 아니다** — 좁을 때만
        #       나타나는 접이 줄(`_bar2`)에 언어 콤보 하나만 들어 있어 오른쪽이
        #       비는 것이다. 그래서 **콤보와 같은 줄**에 태워 함께 접힌다.
        # ── 「내 설명」 편집 입구 (2026-08-26 덮개 읽기 배선과 한 쌍) ──
        #   보고 있는 기본 설명문을 내 버전으로 고치기/가리기/되돌리기 팝업.
        #   콜백(on_edit)을 준 호스트에서만 그린다 — 자리는 약명 라벨 오른쪽
        #   (언어 콤보 왼쪽), 부모는 콤보와 같은 이유로 `self`.
        # ★★ **오른쪽 묶음 = 언어콤보 · My Edit · M** (2026-08-30 사용자 지시
        #   0.txt 1-1 의 차례 그대로). `side='right'` 는 부른 차례로 오른쪽부터
        #   쌓이므로 **거꾸로 붙인다** — M 자리(위) → My Edit → 콤보.
        #   ⚠ 부모는 `self` 다 — 좁아지면 셋이 **함께** `_bar2` 로 내려가야
        #     한다. `pack(in_=X)` 는 X 가 master 이거나 그 자손일 때만 되므로
        #     부모가 `_bar` 이면 형제 `_bar2` 로 못 옮기고 조용히 사라진다.
        self._edit_btn = None
        if self.on_edit is not None:
            self._edit_btn = tk.Button(
                _tp, text=i18n.t('OE_BTN', 'My Edit'),
                command=lambda: self.on_edit(), **_flat())
            if self._ext_bar is None:
                self._edit_btn.pack(in_=self._bar, side='right', padx=(6, 4))
        if self._ext_bar is None:
            self.langsel.combo.pack(in_=self._bar, side='right', padx=(6, 0))
            self._bar.bind('<Configure>', self._on_bar_cfg, add='+')
        self._combo_row = 1
        self._bar_w = 0

        # ── 내용: 설명 / 주석 (pack_forget 전환) ──
        self._body = tk.Frame(self)
        self._body.pack(fill='both', expand=True)
        self._desc_f = tk.Frame(self._body)
        self._comm_f = tk.Frame(self._body)

    # ── 구성 API ─────────────────────────────────────────────────

    def tools(self):
        """밖의 줄에 심을 도구 — `{'combo': 언어콤보, 'edit': My Edit 단추|None}`.
        `ext_bar` 를 준 호스트가 지금 갈래일 때만 pack 한다(2026-09-16)."""
        return {'combo': self.langsel.combo, 'edit': self._edit_btn}

    def bar(self):
        """갈래 단추 줄 — 오른쪽 끝에 매뉴얼 단추를 붙일 때 쓴다(2026-08-22).

        ⚠ `branch_tabs.BranchTabs.bar()` 와 **같은 이름**으로 둔다 — 붙이는
          쪽이 어느 부품인지 몰라도 되게."""
        return self._bar

    def desc_frame(self):
        """설명 내용(desc_txt)을 심을 프레임."""
        return self._desc_f

    def comm_frame(self):
        return self._comm_f

    def commentary(self):
        return self._comm

    def finish(self):
        """직전 갈래 복원 — 없으면 지금 설명 모드에서 유도."""
        want = self._load_state()
        if want not in self._btns:
            try:
                import verse_tier
                with appdb.connect(self.db_path) as c:
                    mode = verse_tier.get_desc_mode(c)
                want = {v: k for k, v in self.MODE.items()}.get(mode, 'lay')
            except Exception:
                want = 'lay'
        self.select(want, save=False)

    # ── 동작 ─────────────────────────────────────────────────────

    def select(self, key, save=True):
        # 옛 저장값 'comm'/'clink'(주석 갈래 — 주석/링크 탭으로 이사)는 흘려보낸다
        if key not in self._btns:
            return
        self._cur = key
        try:
            import verse_tier
            with appdb.connect(self.db_path) as c:
                verse_tier.set_desc_mode(c, self.MODE[key])
        except Exception:
            pass
        if not self._desc_f.winfo_manager():
            self._desc_f.pack(fill='both', expand=True)
        try:
            self.refresh_desc()
        except Exception:
            pass
        self._sync_btns()
        self._sync_role_mb()
        if save:
            self._save_state(key)

    def current(self):
        return self._cur

    # ── 분야별 도움말 메뉴 ────────────────────────────────────────────
    def _sync_role_mb(self):
        try:
            try:
                import ui_theme
                self._role_mb.config(bg=ui_theme.C('panel_alt'), fg=ui_theme.C('fg'),
                                     activebackground=ui_theme.C('panel_alt'))
            except Exception:
                pass
            # ★ 2026-10-25 P2(묻기 콜백이 있는 화면)는 분야 고르기·묻기가 「▶ 분야별 도움말」 머리 줄 끝에 있다 — 띠의 단추는 안 둔다
            if self._cur == 'expert' and not callable(self.on_role_ask):
                if not self._role_mb.winfo_manager():
                    self._role_mb.pack(side='left', padx=(2, 0), after=self._btns['expert'])
            else:
                self._role_mb.pack_forget()
        except Exception:
            pass

    def _fill_role_menu(self):
        """메뉴를 열 때마다 지금 값으로 다시 짓는다(다른 화면에서 바꾼 것도 따라온다)."""
        import role_tips as RT
        m = self._role_menu
        m.delete(0, 'end')
        try:
            with appdb.connect(self.db_path) as c:
                show = set(RT.get_show(c))
        except Exception:
            show = set()
        # ★ 2026-10-21 사용자 「3개 선택방식이 너무 싫다 … 아니라면 하나씩만 선택하도록」 — 분야는 **하나만**(라디오).
        #   그전에는 셋을 체크할 수 있는데 묻기는 내 상태(목사) 하나뿐이라, 셋을 골라도 목회만 세 번 갔다.
        #   이제 고른 그 분야가 보이고, 묻기도 그 분야 하나다.
        if getattr(self, '_role_one', None) is None:
            self._role_one = tk.StringVar(master=self)
        cur = next((c for c in RT.CODES if c in show), RT.CODES[0])
        self._role_one.set(cur)
        for code, _k, _ko, _en in RT.ROLES:
            m.add_radiobutton(label=RT.label(code), value=code, variable=self._role_one,
                              command=self._on_role_pick)
        if callable(self.on_role_ask):
            m.add_separator()
            m.add_command(label=i18n.t('ROLE_ASK', 'AI 에게 「%s」 관점으로 묻기') % RT.label(cur),
                          command=lambda c=cur: self.on_role_ask(c))

    def _on_role_pick(self):
        import role_tips as RT
        codes = [self._role_one.get()] if getattr(self, '_role_one', None) is not None else []
        try:
            with appdb.connect(self.db_path) as c:
                RT.set_show(c, codes)
        except Exception as e:
            print('[role pick] %s' % e)
        try:
            self.refresh_desc()
        except Exception:
            pass

    def load(self, vid):
        """구절이 바뀌었다 — 약명을 갈아 끼우고, 주석 패널이 지어져 있으면 함께."""
        self.set_ref(vid)
        if self._comm is not None and vid:
            try:
                self._comm.load(vid)
            except Exception:
                pass

    def set_ref(self, vid):
        """단추 줄 오른쪽에 **지금 보고 있는 절**을 적는다.

        ⚠ 저장된 글자를 쓰지 않고 **그릴 때마다 다시 짓는다**(§54) — 화면 언어를
          바꾸면 따라와야 한다. 못 지으면 비운다(엉뚱한 글자를 남기지 않는다)."""
        txt = ''
        try:
            if vid:
                import verse_ref
                lang = (i18n.get_lang() or 'KO').upper()
                with appdb.connect(self.db_path) as c:
                    r = c.execute(
                        "SELECT bn.short_name, bi.chapter, bi.verse "
                        "  FROM bible_index bi JOIN book_names bn "
                        "       ON bn.book_code = bi.bcode "
                        "      AND bn.lang_code IN (?, 'EN', 'KO') "
                        " WHERE bi.verse_id=? "
                        " ORDER BY CASE bn.lang_code WHEN ? THEN 0 "
                        "               WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                        (lang, int(vid), lang)).fetchone()
                if r:
                    # ⚠ 약명 표기는 `verse_ref` 한 곳이 정한다 — 손으로 공백을
                    #   넣으면 CJK/라틴 규칙이 갈린다(§60 에서 5곳을 고쳤다).
                    txt = verse_ref.label(verse_ref.SCOPE_BOOK, r[0], r[1], r[2])
        except Exception as e:
            print('[desc_comm_group set_ref] %s' % e)
            txt = ''
        try:
            self._ref_lbl.config(text=txt)
        except Exception:
            pass

    # ── 내부 ─────────────────────────────────────────────────────

    def _ensure_comm(self):
        if self._comm is None and callable(self.make_comm):
            try:
                self._comm = self.make_comm(self._comm_f)
            except Exception as e:
                print('[desc_comm_group make_comm] %s' % e)

    def _on_lang(self, _cur=None):
        """통합 콤보 — 설명 언어(LANGSEL_DESC)와 주석 변형을 함께 정한다."""
        try:
            lang = self.langsel.lang()
            variant = self.langsel.variant()
            desc_lang = 'EN' if variant in ('ORIGINAL', 'MODERN_EN') else lang
            import verse_tier
            with appdb.connect(self.db_path) as c:
                verse_tier.set_desc_lang(c, desc_lang)
        except Exception:
            pass
        if self._comm is not None:
            try:
                self._comm._on_lang_pick(None)
            except Exception:
                pass
        if callable(self.extra_on_lang):
            try:
                self.extra_on_lang()
            except Exception as e:
                print('[desc_comm_group extra_on_lang] %s' % e)
        if self._cur in self.DESC_KEYS:
            try:
                self.refresh_desc()
            except Exception:
                pass

    def _sync_btns(self):
        try:
            import ui_theme
            on = (ui_theme.C('dark_bg'), ui_theme.C('fg_on_dark'))
            off = (ui_theme.C('panel_alt'), ui_theme.C('fg'))
        except Exception:
            on, off = ('#5D6D7E', '#FFFFFF'), ('#ECECEC', '#000000')
        for k, b in self._btns.items():
            bg, fg = on if k == self._cur else off
            try:
                b.config(bg=bg, fg=fg, activebackground=bg, activeforeground=fg)
            except Exception:
                pass

    def _right_group(self):
        """접을 때 **함께 옮기는** 오른쪽 묶음 — 오른쪽부터의 차례로 돌려준다.

        ★ **셋을 통째로 옮긴다** (2026-08-30). 한둘만 내리면 화면 전체로 읽을
          때 차례가 깨진다 — 실제로 M 만 첫 줄에 남아 「항상 맨 오른쪽」 규칙이
          무너져 있었다. 묶음째 내려가면 접히더라도 위→아래·왼→오로 읽는 차례가
          `구절라벨 · 갈래5 / 콤보 · My Edit · M` 로 지시 그대로다.
        """
        if self._ext_bar is not None:
            return []                      # 도구가 밖의 줄에 있다 — 접을 것이 없다
        out = [self._m_slot]
        if self._edit_btn is not None:
            out.append(self._edit_btn)
        out.append(self.langsel.combo)
        return out

    def manual_slot(self):
        """[M] 을 심을 자리 — **줄의 맨 오른쪽으로 못 박아 둔 빈 프레임**.

        ⚠ 호스트가 `bar()` 에 직접 pack 하면 **나중에 붙는 만큼 왼쪽**에 놓인다
          (`side='right'` 는 부른 차례로 쌓인다). 그래서 자리를 미리 잡는다."""
        return self._m_slot

    def _on_bar_cfg(self, e):
        """폭 자동 접이 — 한 줄이 모자라면 **오른쪽 묶음 셋**을 둘째 줄로."""
        if self._ext_bar is not None or abs(e.width - self._bar_w) <= 4:
            return
        self._bar_w = e.width
        try:
            need = (self._ref_lbl.winfo_reqwidth() + 10
                    + sum(b.winfo_reqwidth() + 2 for b in self._btns.values())
                    + (self._role_mb.winfo_reqwidth() + 2 if self._role_mb.winfo_manager() else 0)
                    + sum(w.winfo_reqwidth() + 8 for w in self._right_group())
                    + 12)
            want_row = 2 if e.width < need else 1
            if want_row == self._combo_row:
                return
            self._combo_row = want_row
            grp = self._right_group()
            for w in grp:
                w.pack_forget()
            if want_row == 1:
                self._bar2.pack_forget()
                for w in grp:                      # 오른쪽부터 M · My Edit · 콤보
                    w.pack(in_=self._bar, side='right', padx=(6, 2))
            else:
                self._bar2.pack(fill='x', after=self._bar)
                self._bar2.pack_propagate(False)
                for w in grp:
                    w.pack(in_=self._bar2, side='right', padx=(6, 2))
        except Exception as e:
            # ⚠ **조용히 넘어가지 않는다** — 여기가 `pass` 였던 탓에 콤보가
            #   사라지는 것을 넉 달 동안 아무도 못 봤다(2026-08-23 실측).
            print('[desc_comm_group fold] %s' % e)

    def _load_state(self):
        try:
            with appdb.connect(self.db_path) as c:
                r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                              (self.state_key,)).fetchone()
            return r[0] if r and r[0] else None
        except Exception:
            return None

    def _save_state(self, key):
        try:
            with appdb.connect(self.db_path) as c:
                c.execute("INSERT INTO user_config (config_key, config_val) VALUES (?,?) "
                          "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                          (self.state_key, key))
                c.commit()
        except Exception:
            pass
