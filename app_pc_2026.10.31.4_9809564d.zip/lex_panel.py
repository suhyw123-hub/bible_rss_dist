# -*- coding: utf-8 -*-
"""원어 낱말 화면 — 이 절의 낱말, 그 낱말이 있는 절.

2026-09-12 사용자 지시 — 「시1:1의 복=아쉐르, 다른 곳의 복=바라크 … 한글로는
다른데 **원어로는 큰 차이**가 있는 것 같다 · 시1:4 **바람에 나는 겨** … 겨라는
단어가 들어간 구절들은? · **우리 용어사전이 매우 빈약하다**」 → 「진행하라」.

  위 : 이 절의 낱말 — 원어 글자 · 음역 · 뜻 · **몇 절에 나오나**
  아래: 고른 낱말이 있는 절 — 더블클릭하면 그 절로 간다

★★★ **설명문을 쓰지 않는다** — 절을 나란히 놓는 것만으로 뜻이 드러난다.
  실측이 그것을 증명했다: 「겨」 8절이 **전부 심판에서 날려 가는 것**이고
  아쉐르 42절이 **전부 「복이 있도다」**다. 14,057낱말에 글을 쓰는 것은
  불가능하고 **안 써도 된다.**
⚠⚠⚠ **한국어 이름을 만들지 않는다** — 그 낱말이 든 절들의 한국어를 세어 뽑아
  보니 **절반이 조용히 틀렸다**(모츠→「같으·바람」 · 루아흐→전부 · 헤세드→
  「인자」를 못 찾음). **어느 것이 틀렸는지 기계가 모른다.** 이름은
  **원어 글자 + 음역**이고 뜻은 사전의 영어를 그대로 보인다.
⚠⚠ **히브리·아랍 글자는 원문 그대로 그린다**(2026-09-16 실측 — Tk 가 스스로 바로
  그린다. 뒤집으면 거꾸로 된다. `bidi.py` 머리). `_rtl` 은 이름만 남은 항등이다.
⚠ 조회는 `db_lex_link` 두 문(`lemmas_of`·`verses_of`)만 쓴다 — 여기서 SQL 을
  다시 짜면 두 벌이 된다.
"""
import tkinter as tk
from tkinter import ttk

import appdb
import db_lex_link as LL
import i18n
import theme_font
import ui_theme

#: 절 목록 상한 — 「물」이 525절, 「사람」이 1,851절이다. 다 그리면 화면이 멎는다.
LIST_CAP = 300


def _C(role, fallback):
    try:
        return ui_theme.C(role)
    except Exception:
        return fallback


def _rtl(s):
    """히브리·헬라 글자를 화면에 바로 놓는다. ⚠ **그릴 때 한 번만.**"""
    try:
        import bidi
        return bidi.for_display(s or '')
    except Exception:
        return s or ''


class LexPanel(tk.Frame):
    """그 구절의 원어 낱말 — P2 갈래와 NodePanel 이 함께 쓴다."""

    def __init__(self, parent, db_path, on_verse_go=None, **kw):
        """on_verse_go(verse_id) — 절을 더블클릭했을 때 그리로 가는 콜백."""
        super().__init__(parent, **kw)
        self.db_path = db_path
        self.on_verse_go = on_verse_go
        self._vid = None
        self._words = []          # [(strong, info), …] — 본문 차례
        self._cur = None          # 지금 고른 낱말
        self._rows = []           # 아래 목록의 절 번호(줄 차례대로)

        # ── 머리 띠 — 몇 개인지 여기 한 곳에만 적는다 ──
        bar = tk.Frame(self, height=24)
        bar.pack(fill='x')
        bar.pack_propagate(False)
        self._head = tk.Label(bar, text='', anchor='w',
                              fg=_C('accent', '#1A5276'), font=('', 9, 'bold'))
        self._head.pack(side='left', padx=(4, 8))
        self._m_slot = tk.Frame(bar)          # 호스트가 [M] 을 심는 자리
        self._m_slot.pack(side='right', padx=(0, 2))

        pw = ttk.PanedWindow(self, orient='vertical')
        pw.pack(fill='both', expand=True)

        # ── 위: 이 절의 낱말 ──
        top = tk.Frame(pw)
        pw.add(top, weight=1)
        self.tv_w = ttk.Treeview(top, columns=('form', 'tr', 'gloss', 'n'),
                                 show='headings', selectmode='browse')
        for c, w, a, t, d in (('form', 92, 'center', 'LEX_COL_FORM', '원어'),
                              ('tr', 104, 'w', 'LEX_COL_TR', '음역'),
                              ('gloss', 240, 'w', 'LEX_COL_GLOSS', '뜻'),
                              ('n', 56, 'e', 'LEX_COL_N', '절')):
            self.tv_w.heading(c, text=i18n.t(t, d))
            self.tv_w.column(c, width=w, anchor=a,
                             stretch=(c == 'gloss'), minwidth=40)
        _scroll(top, self.tv_w)
        theme_font.list_style('LexWord.Treeview', db_path)
        self.tv_w.config(style='LexWord.Treeview')
        self.tv_w.bind('<<TreeviewSelect>>', self._on_pick_word)

        # ── 아래: 그 낱말이 있는 절 ──
        bot = tk.Frame(pw)
        pw.add(bot, weight=2)
        self._sub = tk.Label(bot, text='', anchor='w',
                             fg=_C('fg_dim', '#666666'))
        self._sub.pack(fill='x', padx=4)
        self.tv_v = ttk.Treeview(bot, columns=('ref', 'text'),
                                 show='headings', selectmode='browse')
        self.tv_v.heading('ref', text=i18n.t('LEX_COL_REF', '구절'))
        self.tv_v.heading('text', text=i18n.t('LEX_COL_TEXT', '본문'))
        self.tv_v.column('ref', width=86, anchor='w', stretch=False, minwidth=60)
        self.tv_v.column('text', width=420, anchor='w', stretch=True, minwidth=80)
        _scroll(bot, self.tv_v)
        theme_font.list_style('LexVerse.Treeview', db_path)
        self.tv_v.config(style='LexVerse.Treeview')
        self.tv_v.bind('<Double-1>', self._on_go)

    # ── 호스트가 쓰는 문 ────────────────────────────────────────────
    def manual_slot(self):
        """[M] 을 붙일 자리 — 이름을 `DescCommGroup` 과 맞춘다."""
        return self._m_slot

    def load(self, vid):
        """그 절의 낱말을 그린다. ⚠ **없으면 까닭을 적는다**(§0-1)."""
        self._vid = vid
        self._cur = None
        for t in (self.tv_w, self.tv_v):
            t.delete(*t.get_children())
        self._words, self._rows = [], []
        self._sub.config(text='')
        if not vid:
            self._head.config(text='')
            return
        try:
            with appdb.connect(self.db_path) as conn:
                sts = LL.lemmas_of(conn, vid)
                for st in sts:
                    info = LL.word_info(conn, st)
                    if info:
                        self._words.append((st, info))
        except Exception as e:
            self._head.config(text=str(e)[:60])
            return
        if not self._words:
            # ⚠ 조용히 비우지 않는다 — 원어가 없는 절(이형 절·미적재)이 있다.
            self._head.config(text=i18n.t('LEX_NONE', '이 구절의 원어 낱말 자료가 없습니다'))
            return
        self._head.config(text=i18n.t('LEX_HEAD', '이 구절의 낱말 %d개') % len(self._words))
        for st, i in self._words:
            self.tv_w.insert('', 'end', iid=st, values=(
                _rtl(i['form']), i['translit'], i['gloss'][:70],
                format(i['n_verse'] or 0, ',')))

    def count_for(self, vid):
        """배지용 — 그 절의 낱말 수. ⚠ 조회를 두 번 하지 않게 가볍게."""
        try:
            with appdb.connect(self.db_path) as conn:
                return len(LL.lemmas_of(conn, vid))
        except Exception:
            return 0

    # ── 안쪽 ────────────────────────────────────────────────────────
    def _on_pick_word(self, _e=None):
        sel = self.tv_w.selection()
        if not sel:
            return
        st = sel[0]
        self._cur = st
        self.tv_v.delete(*self.tv_v.get_children())
        self._rows = []
        info = dict(self._words).get(st) or {}
        try:
            with appdb.connect(self.db_path) as conn:
                vids = LL.verses_of(conn, st)
                shown = vids[:LIST_CAP]
                rows = _verse_rows(conn, shown)
        except Exception as e:
            self._sub.config(text=str(e)[:70])
            return
        # ★ 「몇 절 중 몇 줄」을 적는다 — 잘렸는지 사람이 알아야 한다(§0-1)
        if len(vids) > len(shown):
            self._sub.config(text=i18n.t(
                'LEX_SUB_CUT', '%s %s — %d절 가운데 앞 %d줄')
                % (info.get('translit', st), info.get('gloss', '')[:28],
                   len(vids), len(shown)))
        else:
            self._sub.config(text=i18n.t('LEX_SUB', '%s %s — %d절')
                             % (info.get('translit', st),
                                info.get('gloss', '')[:28], len(vids)))
        for vid, ref, txt in rows:
            self._rows.append(vid)
            self.tv_v.insert('', 'end', iid=str(vid), values=(ref, txt))

    def _on_go(self, _e=None):
        sel = self.tv_v.selection()
        if not sel or self.on_verse_go is None:
            return
        try:
            self.on_verse_go(int(sel[0]))
        except Exception:
            pass


def _verse_rows(conn, vids):
    """절 번호 목록 → [(vid, 약명, 본문)] — **한 번의 조회로**.

    ⚠ 절마다 물으면 300번이 된다. `IN` 으로 한 번에 받고 차례는 여기서 맞춘다.
    """
    if not vids:
        return []
    ph = ','.join('?' * len(vids))
    ver = _pref_version(conn)
    rows = {}
    for vid, bk, ch, vs, txt in conn.execute(
            "SELECT i.verse_id, COALESCE(b.short_name,''), i.chapter, i.verse,"
            "       COALESCE(c.verse_text,'')"
            "  FROM bible_index i"
            "  LEFT JOIN book_names b ON b.book_code=i.bcode AND b.lang_code=?"
            "  LEFT JOIN bible_content c ON c.verse_id=i.verse_id"
            "       AND c.version_code=?"
            " WHERE i.verse_id IN (%s)" % ph,
            [(i18n.get_lang() or 'KO').upper(), ver] + list(vids)):
        sep = '' if _cjk(bk) else ' '
        rows[vid] = ('%s%s%d:%d' % (bk, sep, ch, vs), (txt or '').strip())
    return [(v, rows.get(v, ('', ''))[0], rows.get(v, ('', ''))[1])
            for v in vids if v in rows]


def _cjk(s):
    return any('　' <= ch <= '鿿' or '가' <= ch <= '힣'
               for ch in (s or ''))


def _pref_version(conn):
    """사용자가 보는 역본 — 없으면 한국어/영어 순으로 떨어진다."""
    try:
        r = conn.execute("SELECT config_val FROM user_config "
                         "WHERE config_key='PREFERRED_VERSIONS'").fetchone()
        if r and r[0]:
            first = str(r[0]).replace('[', '').replace(']', '').replace('"', '')
            first = first.split(',')[0].strip()
            if first:
                return first
    except Exception:
        pass
    return 'KRV' if (i18n.get_lang() or 'KO').upper() == 'KO' else 'BSB'


def _scroll(parent, widget):
    """세로·가로 스크롤. ⚠ **스크롤바를 먼저 담는다** — 나중에 담으면 목록이
    남는 자리를 다 먹어 스크롤바가 0px 이 된다(§238차 ①)."""
    vs = ttk.Scrollbar(parent, orient='vertical', command=widget.yview)
    vs.pack(side='right', fill='y')
    hs = ttk.Scrollbar(parent, orient='horizontal', command=widget.xview)
    hs.pack(side='bottom', fill='x')
    widget.config(yscrollcommand=vs.set, xscrollcommand=hs.set)
    widget.pack(side='left', fill='both', expand=True)


# ── 자가검증 ───────────────────────────────────────────────────────
def selftest():
    import sqlite3
    ok = fail = 0

    def t(name, cond, extra=''):
        nonlocal ok, fail
        if cond:
            ok += 1
        else:
            fail += 1
            print('  FAIL %s %s' % (name, extra))

    t('상한이 있다(큰 낱말이 화면을 멎게 하지 않는다)',
      isinstance(LIST_CAP, int) and 50 <= LIST_CAP <= 1000, LIST_CAP)
    src = open(__file__, encoding='utf-8').read()
    t('★ 조회를 여기서 다시 짜지 않는다',
      ('SELECT ' + 'verse_ids') not in src)
    t('  ⚠ 한국어 이름을 만들지 않는다', ('name' + '_ko') not in src)

    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE bible_index(verse_id INTEGER, bcode INTEGER,"
              " chapter INTEGER, verse INTEGER)")
    c.execute("CREATE TABLE book_names(book_code INTEGER, lang_code TEXT,"
              " full_name TEXT, short_name TEXT)")
    c.execute("CREATE TABLE bible_content(verse_id INTEGER, version_code TEXT,"
              " verse_text TEXT)")
    c.executemany("INSERT INTO bible_index VALUES(?,?,?,?)",
                  [(10, 19, 1, 1), (11, 19, 1, 4), (12, 40, 5, 3)])
    c.executemany("INSERT INTO book_names VALUES(?,?,?,?)",
                  [(19, 'KO', '시편', '시'), (40, 'KO', '마태복음', '마'),
                   (19, 'EN', 'Psalms', 'Ps'), (40, 'EN', 'Matthew', 'Mt')])
    c.executemany("INSERT INTO bible_content VALUES(?,?,?)",
                  [(10, 'KRV', '복 있는 사람은'), (11, 'KRV', '바람에 나는 겨'),
                   (12, 'KRV', '심령이 가난한 자는')])
    rows = _verse_rows(c, [10, 11, 12])
    t('★ 절 목록을 한 번에 읽는다', len(rows) == 3, rows)
    t('  ⚠ **준 차례를 지킨다**', [r[0] for r in rows] == [10, 11, 12])
    t('  CJK 약명은 붙여 쓴다', rows[0][1] == '시1:1', rows[0][1])
    t('  본문이 실린다', rows[1][2] == '바람에 나는 겨', rows[1])
    t('빈 목록은 빈 결과', _verse_rows(c, []) == [])
    t('없는 절은 조용히 빠진다', len(_verse_rows(c, [10, 99999])) == 1)
    c.close()

    t('★ 라틴 약명은 띄어 쓴다', not _cjk('Ps') and _cjk('시'))
    # 2026-09-16 — Tk 가 히브리어를 스스로 바로 그린다(bidi.py 머리 실측). 뒤집지 않는다.
    t('  히브리 글자는 원문 그대로 그린다', _rtl('אֶשֶׁר') == 'אֶשֶׁר')
    t('  빈 글자는 그대로', _rtl('') == '' and _rtl(None) == '')

    # 화면 — 실제로 띄워 본다
    try:
        root = tk.Tk()
        root.geometry('700x520+40+40')
        errs = []
        root.report_callback_exception = lambda *a: errs.append(a)
        p = LexPanel(root, appdb.resolve_db('bible_master.db'))
        p.pack(fill='both', expand=True)
        root.update()
        t('낱말 칸이 넷', len(p.tv_w['columns']) == 4)
        t('절 칸이 둘', len(p.tv_v['columns']) == 2)
        t('★ 스크롤바가 실제로 너비를 갖는다',
          all(w.winfo_width() > 2 for w in p.tv_w.master.winfo_children()
              if isinstance(w, ttk.Scrollbar)))
        with appdb.connect() as conn:
            vid = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=19"
                               " AND chapter=1 AND verse=1").fetchone()[0]
            v14 = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=19"
                               " AND chapter=1 AND verse=4").fetchone()[0]
        p.load(vid)
        root.update()
        ws = p.tv_w.get_children()
        t('★★★ **시1:1 에 낱말이 뜬다**', len(ws) >= 8, len(ws))
        t('  ★ 아쉐르가 첫 낱말(본문 차례)', ws and ws[0] == 'H835', ws[:2])
        t('  ⚠ 조사가 없다', 'H853' not in ws and 'H3808' not in ws)
        t('  머리에 개수를 적는다', '%d' % len(ws) in p._head.cget('text'),
          p._head.cget('text'))
        p.tv_w.selection_set('H835')
        root.update()
        vs = p.tv_v.get_children()
        t('★★★ **아쉐르를 누르면 42절**', len(vs) == 42, len(vs))
        t('  그 안에 시1:1 이 있다', str(vid) in vs)
        t('  아래 띠가 몇 절인지 적는다', '42' in p._sub.cget('text'),
          p._sub.cget('text'))
        p.load(v14)
        root.update()
        p.tv_w.selection_set('H4671')
        root.update()
        t('★★★ **시1:4 의 겨는 8절**', len(p.tv_v.get_children()) == 8,
          len(p.tv_v.get_children()))
        # 더블클릭 → 콜백
        got = []
        p.on_verse_go = got.append
        p.tv_v.selection_set(p.tv_v.get_children()[0])
        p._on_go()
        t('★ 절을 누르면 그리로 간다', len(got) == 1, got)
        # 큰 낱말도 상한에서 멎는다
        p.load(vid)
        root.update()
        p.tv_w.selection_set('H376')       # 사람 — 1,851절
        root.update()
        t('★★ 큰 낱말은 상한에서 멎는다',
          len(p.tv_v.get_children()) == LIST_CAP, len(p.tv_v.get_children()))
        t('  ⚠ **잘렸다고 말한다**', '가운데' in p._sub.cget('text')
          or '1,851' in p._sub.cget('text') or '1851' in p._sub.cget('text'),
          p._sub.cget('text'))
        # 없는 절
        p.load(0)
        root.update()
        t('절이 없으면 비운다', not p.tv_w.get_children())
        root.update()
        t('Tk 오류 0', not errs, str(errs[:1])[:120])
        root.destroy()
    except tk.TclError as e:
        print('  (화면 없음 — 건너뜀: %s)' % str(e)[:40])

    print('lex_panel selftest %d/%d' % (ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print('쓰는 법: python lex_panel.py --selftest')
