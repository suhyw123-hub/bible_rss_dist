# -*- coding: utf-8 -*-
"""verse_card.py — 「오늘의 구절 + 사진」 말씀 카드 (영구 · 2026-09-26).

사용자 지시(1.txt 20번 3) — 「최신묵상/최신뉴스의 **오른쪽 화면**: 적절한
이미지나 성경구절 등을 **예쁜 디자인으로 배치**하고, 최신유투브 클릭할
때에는 유투브 재생화면으로 사용」.

★★★ **새 자료를 만들지 않는다 — 시작화면이 이미 쓰는 캐시를 그대로 읽는다.**
  `splash/bg.png`(사진)와 `splash_verse.json`(오늘의 구절)은 앱이 꺼질 때
  **이미 적어 두는 것**이다(§34). 여기서 DB 를 다시 뒤지면 ⓐ 조회가 두 벌이
  되고 ⓑ 시작화면과 **다른 구절**이 떠서 한 앱이 두 말을 하게 된다.

⚠ **PIL 을 요구하지 않는다** — 없으면 `subsample`(정수 축소)로 물러선다.
  사진이 아예 없으면 **글만** 그린다(빈 칸을 만들지 않는다 · §0-1).
⚠ **폭이 바뀔 때만 다시 그린다** — 무조건 다시 그리면 `<Configure>` 가
  되돌아와 끝없는 고리가 된다(§256차 ⑰ 에서 앱이 통째로 멎던 그 자리).

사용:
    card = verse_card.VerseCard(parent)
    card.pack(fill='both', expand=True)
"""
import os
import tkinter as tk

#: 폭이 이만큼 넘게 바뀌어야 다시 그린다(한 픽셀마다 다시 그리지 않는다)
REDRAW_STEP = 40
#: 사진이 먹을 수 있는 최대 높이 몫 — 글이 밀려나지 않게
PHOTO_MAX_RATIO = 0.62

BG = '#FFFFFF'
FG = '#2C3E50'
DIM = '#7F8C8D'


def today_verse():
    """시작화면과 **같은 캐시**에서 오늘의 구절 → (약명, 본문).

    ⚠ 여기서 DB 를 뒤지지 않는다 — 시작화면과 다른 구절이 뜨면 한 앱이 두
      말을 한다. 캐시가 비면 시작화면의 폴백 구절을 그대로 쓴다.
    """
    try:
        import splash_screen as ss
        ref, text = ss._load_verse(ss._app('splash_verse.json'))
        if text:
            return ref, text
        return ss.DEFAULT_REF, ss.DEFAULT_TEXT
    except Exception:
        return '', ''


def photo_path():
    """시작화면 사진 캐시 경로(없으면 '')."""
    try:
        import splash_screen as ss
        p = ss._app('splash', 'bg.png')
        return p if os.path.exists(p) else ''
    except Exception:
        return ''


def photo_caption():
    """사진 설명(제목·한 줄) — 없으면 ('', '')."""
    try:
        import splash_screen as ss
        cap = ss._load_photo_caption()
        if isinstance(cap, (list, tuple)) and len(cap) >= 2:
            return (cap[0] or ''), (cap[1] or '')
    except Exception:
        pass
    return '', ''


def _scaled(path, box_w, box_h):
    """`tk.PhotoImage` 를 칸에 맞춰 줄인다.

    ★ PIL 이 있으면 곱게 줄이고, 없으면 `subsample`(정수 축소)로 물러선다.
    ⚠ **키우지 않는다** — 작은 사진을 늘리면 뭉개진다.
    """
    try:
        from PIL import Image, ImageTk
        im = Image.open(path)
        im.load()
        w, h = im.size
        r = min(box_w / float(w), box_h / float(h), 1.0)
        if r < 1.0:
            im = im.resize((max(1, int(w * r)), max(1, int(h * r))))
        return ImageTk.PhotoImage(im)
    except Exception:
        pass
    try:
        ph = tk.PhotoImage(file=path)
        k = 1
        while (ph.width() // k > box_w or ph.height() // k > box_h) and k < 8:
            k += 1
        return ph.subsample(k, k) if k > 1 else ph
    except Exception:
        return None


class VerseCard(tk.Frame):
    """사진 + 오늘의 구절 한 장."""

    def __init__(self, master, **kw):
        kw.setdefault('bg', BG)
        super().__init__(master, **kw)
        # ⚠⚠⚠ **`self._w` 라 이름 짓지 말 것** — `tk.Misc._w` 는 그 위젯의
        #   **Tcl 이름**이다. 덮어쓰면 `pack` 이 그 자리에서
        #   `bad argument "0": must be name of window` 로 죽는다(실측으로 당했다).
        self._last_w = 0
        self._photo = None
        self._built = False
        # ⚠⚠⚠ **그리는 도중에 또 불린다** — 자식을 지우고 만드는 그 순간
        #   Tk 가 `<Configure>` 를 **그 자리에서** 보내, 안쪽 그리기가 먼저
        #   끝나고 바깥 그리기가 자식을 **한 벌 더** 만든다(실측 3 → 6).
        #   ★ §256차 ⑰ 「끝없는 고리」와 같은 갈래다. 문을 잠근다.
        self._rendering = False
        self.bind('<Configure>', self._on_cfg)
        # ★ **지어질 때 한 번 그린다** — `<Configure>` 만 기다리면 창이 아직
        #   안 떴거나 폭이 안 바뀐 화면에서 **영영 빈 칸**으로 남는다
        #   (실측 — 하네스가 그 자리에서 잡았다). 폭을 알게 되면 다시 그린다.
        self._render()

    # ── 다시 그리는 때 ───────────────────────────────────────────
    def _on_cfg(self, e):
        # ⚠ **폭이 실제로 달라졌을 때만** — 아니면 끝없는 고리가 된다.
        if self._rendering:
            return
        if e.width < 80 or abs(e.width - self._last_w) < REDRAW_STEP:
            return
        self._last_w = e.width
        self._render()

    def refresh(self):
        """캐시가 바뀌었을 때 밖에서 부른다(구절·사진이 하루 한 번 바뀐다)."""
        self._last_w = 0
        try:
            self._render()
        except Exception:
            pass

    # ── 그리기 ───────────────────────────────────────────────────
    def _render(self):
        if self._rendering:
            return
        self._rendering = True
        try:
            self._render_now()
        finally:
            self._rendering = False

    def _render_now(self):
        for w in self.winfo_children():
            w.destroy()
        self._photo = None
        try:
            box_w = max(120, (self.winfo_width() or self._last_w) - 40)
            box_h = max(80, int((self.winfo_height() or 400) * PHOTO_MAX_RATIO))
        except Exception:
            box_w, box_h = 400, 240

        p = photo_path()
        if p:
            ph = _scaled(p, box_w, box_h)
            if ph is not None:
                self._photo = ph      # GC 방지 — 놓치면 빈 칸이 된다
                tk.Label(self, image=ph, bg=BG, bd=0).pack(pady=(16, 10))
                ti, de = photo_caption()
                line = ' · '.join(x for x in (ti, de) if x)
                # ⚠ **없으면 줄을 안 만든다**(빈 자리 금지)
                if line:
                    tk.Label(self, text=line, bg=BG, fg=DIM, anchor='center',
                             font=('Malgun Gothic', 9),
                             wraplength=box_w).pack(fill='x', padx=20)

        ref, text = today_verse()
        if text:
            tk.Label(self, text=text, bg=BG, fg=FG, justify='center',
                     font=('Malgun Gothic', 13), wraplength=box_w
                     ).pack(fill='x', padx=20, pady=(14, 4))
        if ref:
            tk.Label(self, text=ref, bg=BG, fg=DIM, anchor='center',
                     font=('Malgun Gothic', 10, 'bold')
                     ).pack(fill='x', padx=20, pady=(0, 16))
        self._built = True

    def has_content(self):
        """그릴 것이 있나 — 없으면 부르는 쪽이 카드를 안 붙인다(§0-1)."""
        ref, text = today_verse()
        return bool(text or photo_path())


# ── 자가 검증 ────────────────────────────────────────────────────────
def _selftest():
    ok = [0]
    bad = [0]

    def t(name, cond, got=''):
        if cond:
            ok[0] += 1
            print('  OK   ' + name)
        else:
            bad[0] += 1
            print('  FAIL ' + name + ('   ' + repr(got) if got != '' else ''))

    g = globals()
    t('시작화면 캐시를 읽는다 — DB 조회가 없다',
      'appdb' not in g and 'sqlite3' not in g)
    ref, text = today_verse()
    t('구절을 낸다(캐시가 비어도 폴백)', bool(text), (ref, text[:20]))
    t('사진 경로는 있을 때만 낸다',
      photo_path() == '' or os.path.exists(photo_path()), photo_path())

    # 실제로 그려 본다 — 창을 띄우지 않고 위젯만
    root = None
    try:
        root = tk.Tk()
        root.withdraw()
        c = VerseCard(root)
        c.pack(fill='both', expand=True)
        root.geometry('520x460')
        root.update_idletasks()
        c._render()
        root.update_idletasks()
        kids = c.winfo_children()
        t('그리면 위젯이 생긴다', len(kids) >= 1, len(kids))
        txt = [str(k.cget('text')) for k in kids
               if 'text' in k.keys()]
        t('구절 본문이 실제로 들어 있다',
          any(text[:10] in x for x in txt) if text else True, txt[:3])
        # ⚠ 폭이 안 바뀌면 다시 안 그린다(끝없는 고리 방지) — 양방향으로 잰다
        c._last_w = 500
        before = len(c.winfo_children())
        c._on_cfg(type('E', (), {'width': 505, 'height': 400})())
        t('폭이 거의 같으면 다시 안 그린다', c._last_w == 500, c._last_w)
        c._on_cfg(type('E', (), {'width': 700, 'height': 400})())
        root.update_idletasks()
        t('폭이 크게 바뀌면 다시 그린다', c._last_w == 700, c._last_w)
        t('다시 그려도 위젯이 안 쌓인다',
          len(c.winfo_children()) <= before + 1,
          (before, len(c.winfo_children())))
        t('`has_content` 가 판정한다', c.has_content() in (True, False))
    except Exception as e:
        t('그리기', False, str(e))
    finally:
        try:
            if root is not None:
                root.destroy()
        except Exception:
            pass

    print('\nverse_card selftest %d/%d' % (ok[0], ok[0] + bad[0]))
    return bad[0] == 0


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if _selftest() else 1)
    print(__doc__)
