# -*- coding: utf-8 -*-
"""db_seed_multilang.py — 씨앗 낱말 다국어 정비(영구 도구 · 2026-09-09 227차)

수집된 채널(sys_media_asset 18k 영상 · 11언어 + 발굴 표 샘플)의 제목 실태로 언어마다 씨앗
낱말을 고른다(사용자 「등록된 채널만 대상으로 하지 말고 수집된 채널을 대상으로 하라.
몇 개 언어에서 공통 패턴이 발견된다면 건수가 적은 언어에 적용해도 좋다」).
  python db_seed_multilang.py            → 언어별 실태와 지정안(안 바꾼다)
  python db_seed_multilang.py --apply    → sys_mine_keyword 에 담는다(이미 있는 낱말은 근거만 갱신)
  python db_seed_multilang.py --selftest

  · 후보 = 그 언어의 분류 키워드(SERMON/WORSHIP/STUDY 묶음) ∪ 공통 패턴 낱말표(11언어에서
    되풀이 나타나는 개념 — 성경·복음·설교·성경공부·묵상·목사·교회·찬양·기도·예수 그리스도)
  · 점수 = 그 낱말이 제목에 든 **채널 수**(영상 수가 아니다 — 한 채널이 수백 편을 올린다)
  · 지정 = 채널 3개 이상인 것 중 상위 6. 그래도 4개가 안 되면 공통 패턴으로 채운다
    (사용자 「공통패턴이 발견된다면 건수가 적은 언어에 적용해도 좋다」).
  · KO 는 사용자가 정비한 것이라 손대지 않는다.
"""
import os, sys, re, io, json, collections
APP = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP); os.chdir(APP)
import appdb, db_channel_mine as CM, media_taxonomy as MT
APPLY = '--apply' in sys.argv

COMMON = {
 'EN':  ['bible', 'gospel', 'sermon', 'bible study', 'devotional', 'pastor', 'church', 'worship', 'praise', 'hymn', 'prayer', 'jesus christ', 'christian'],
 'DE':  ['bibel', 'evangelium', 'predigt', 'bibelstudium', 'andacht', 'pastor', 'gemeinde', 'kirche', 'lobpreis', 'anbetung', 'gebet', 'jesus christus', 'christlich'],
 'ES':  ['biblia', 'evangelio', 'sermón', 'predicación', 'estudio bíblico', 'devocional', 'pastor', 'iglesia', 'alabanza', 'adoración', 'oración', 'jesucristo', 'cristiano'],
 'PT':  ['bíblia', 'evangelho', 'sermão', 'pregação', 'estudo bíblico', 'devocional', 'pastor', 'igreja', 'louvor', 'adoração', 'oração', 'jesus cristo', 'cristão'],
 'FR':  ['bible', 'évangile', 'prédication', 'sermon', 'étude biblique', 'méditation', 'pasteur', 'église', 'louange', 'adoration', 'prière', 'jésus-christ', 'chrétien'],
 'RU':  ['библия', 'евангелие', 'проповедь', 'разбор', 'изучение библии', 'пастор', 'церковь', 'поклонение', 'прославление', 'молитва', 'иисус христос', 'христианский'],
 'AR':  ['الكتاب المقدس', 'إنجيل', 'عظة', 'وعظ', 'دراسة الكتاب المقدس', 'تأمل', 'أبونا', 'قس', 'كنيسة', 'ترنيم', 'ترانيم', 'تسبيح', 'صلاة', 'يسوع المسيح', 'مسيحي'],
 'ZH':  ['圣经', '福音', '讲道', '证道', '查经', '灵修', '牧师', '教会', '敬拜', '赞美', '诗歌', '祷告', '耶稣基督', '基督徒'],
 'ZHT': ['聖經', '福音', '講道', '證道', '查經', '靈修', '牧師', '教會', '敬拜', '讚美', '詩歌', '禱告', '耶穌基督', '基督徒'],
 'JA':  ['聖書', '福音', '説教', '礼拝', '聖書研究', 'デボーション', '牧師', '教会', '賛美', '賛美歌', '祈り', 'イエス・キリスト', 'クリスチャン'],
}
#: 공통 패턴 중 「채널을 찾는 힘」이 큰 순서 — 실태가 약한 언어를 채울 때 이 차례
FILL_ORDER = ['bible', 'sermon', 'gospel', 'worship']
FILL = {  # 개념 → 언어별 낱말(위 표의 색인)
 'bible': 0, 'gospel': 1, 'sermon': 2, 'worship': None,
}

if '--selftest' in sys.argv:
    import sqlite3
    c = sqlite3.connect(':memory:')
    CM.init(c)
    ok = 0
    corpus_t = [('ch1', 'predigt über genesis'), ('ch2', 'die predigt heute'), ('ch3', 'bibel lesen'),
                ('ch4', 'predigt am sonntag'), ('ch5', 'lobpreis abend')]
    def cw(word):
        return {ch for ch, t in corpus_t if word in t}
    ok += cw('predigt') == {'ch1', 'ch2', 'ch4'}
    ok += len(cw('lobpreis')) == 1 and len(cw('lobpreis')) < 3      # 3 미만 = 공통 패턴으로만 든다
    print('db_seed_multilang selftest %d/2' % ok)
    sys.exit(0 if ok == 2 else 1)

c = appdb.connect('bible_master.db')
CM.init(c)
rows = c.execute("SELECT lang_code, title, json_extract(description,'$.channel') FROM sys_media_asset "
                 "WHERE record_status='LIVE' AND json_valid(description)=1").fetchall()
for lang, title, samples in c.execute("SELECT lang, title, samples FROM sys_mine_channel WHERE samples IS NOT NULL"):
    for t in str(samples).split(' | '):
        if t.strip():
            rows.append((lang or 'EN', t.strip(), title))
corpus = collections.defaultdict(list)     # lang → [(channel, title_lower)]
for lang, title, ch in rows:
    if lang and title:
        corpus[lang].append((ch or '?', title.lower()))
sets = MT.load_classify_sets(c)

def channels_with(lang, word):
    w = word.lower()
    return {ch for ch, t in corpus[lang] if w in t}

report = {}
plan = {}
for lang, common in COMMON.items():
    cands = []
    seen = set()
    for w in common:
        if w.lower() not in seen:
            seen.add(w.lower()); cands.append((w, 'COMMON'))
    for cat in CM.SEED_CATS:
        b = sets.get(cat) or {}
        bk = ['COMMON', lang] if lang == 'EN' else [lang]
        for k in bk:
            for w in (b.get(k) or []):
                w = (w or '').strip()
                if w and w.lower() not in seen:
                    seen.add(w.lower()); cands.append((w, cat))
    scored = [(w, src, len(channels_with(lang, w))) for w, src in cands]
    scored.sort(key=lambda x: -x[2])
    n_ch = len({ch for ch, _ in corpus[lang]})
    on = [w for w, _s, n in scored if n >= 3][:6]
    filled = []
    if len(on) < 4:
        for i in (0, 2, 1):            # bible · sermon · gospel
            w = common[i]
            if w not in on:
                on.append(w); filled.append(w)
            if len(on) >= 4:
                break
    # ★ 찬양 낱말 하나는 늘 지정한다 — 수집된 채널이 설교 쪽으로 기울어(구절·용어 검색으로
    #   담았다) 찬양 낱말이 실태에 거의 없지만, KO 씨앗(찬양·찬송·워십·ccm)이 보이듯
    #   찬양 채널은 따로 찾아야 한다. 11언어에 같은 개념이 있으니 공통 패턴으로 적용.
    WORSHIP = {'EN': 'worship', 'DE': 'lobpreis', 'ES': 'alabanza', 'PT': 'louvor', 'FR': 'louange',
               'RU': 'поклонение', 'AR': 'ترنيم', 'ZH': '敬拜', 'ZHT': '敬拜', 'JA': '賛美'}
    ww = WORSHIP.get(lang)
    if ww and ww not in on:
        on.append(ww)
        if len(channels_with(lang, ww)) < 3:
            filled.append(ww)
    plan[lang] = (scored, on, filled, n_ch)
    report[lang] = n_ch

for lang, (scored, on, filled, n_ch) in plan.items():
    print('== %s  채널 %d  지정 %d%s' % (lang, n_ch, len(on), (' (공통 패턴으로 채움 %s)' % filled) if filled else ''))
    print('   ' + ' · '.join('%s%s %d' % ('●' if w in on else '', w, n) for w, _s, n in scored[:22]))

if APPLY:
    added = updated = 0
    for lang, (scored, on, filled, n_ch) in plan.items():
        for w, src, n in scored:
            # ⚠ 「실태 채널」은 내가 지어낸 말이었다(2026-09-16 사용자 「실태채널은 무슨 말인가」) — 사람 말로.
            note = '수집된 채널 %d곳의 제목에 있음' % n + (' · 공통 패턴' if w in filled else '') + (' · %s' % src if src != 'COMMON' else '')
            cur = c.execute("INSERT OR IGNORE INTO sys_mine_keyword (lang, kw, enabled, note) VALUES (?,?,?,?)",
                            (lang, w, 1 if w in on else 0, note))
            if cur.rowcount:
                added += 1
            else:
                c.execute("UPDATE sys_mine_keyword SET note=?, enabled=CASE WHEN ? THEN 1 ELSE enabled END "
                          "WHERE lang=? AND kw=?", (note, 1 if w in on else 0, lang, w))
                updated += 1
    c.commit()
    print('적재 — 새 낱말 %d · 갱신 %d' % (added, updated))
    print(c.execute("SELECT lang, COUNT(*), SUM(enabled) FROM sys_mine_keyword GROUP BY lang ORDER BY lang").fetchall())
c.close()
