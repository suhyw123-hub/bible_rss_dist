"""plan_wish.py — 묵상후보 찜하기 (영구 모듈, 2026-08-16 사용자 지시).

> 「나중에 묵상하기로 관심갖는 것까지 등록하면 너무 많아진다. 다음에 묵상할 후보를
>  미리 찜해두는 기능을 만들자.」

★ **즐겨찾기와 뜻이 다르다** (사용자 정정). 즐겨찾기는 「다시 볼 것」이고 후보는
  **「아직 안 본 것」**이다. ⇒ **기술은 빌리고 라벨만 가른다** —
  `user_favorite` 에 `fav_type='PLAN_WISH'` 한 갈래를 더한다. 표를 새로 만들지 않는다.

⚠ **「나의 길 ▸ ★ 즐겨찾기」 목록에는 넣지 않는다.** 한 목록에 섞으면 라벨을 갈라
  놓은 뜻이 없어진다(`my_path_view` 가 `fav_type` 으로 거르므로 저절로 빠진다).

★ **플랜의 신원은 (sys plan_id) 또는 (user_plan_id) 둘 중 하나**다.
  `user_bible_plan.user_plan_id` 와 `sys_bible_plan.plan_id` 는 **번호가 겹친다** —
  그래서 `source_code` 에 `'SYS'`/`'USER'` 를 함께 적는다. 이것을 빼면 사용자 플랜 4번을
  찜했는데 sys 플랜 4번(정경순서 1년)이 찜된 것으로 보인다.

⚠ 지우지 않고 **`record_status` 를 눕힌다** — 즐겨찾기와 같은 방식이라
  같은 것을 다시 찜하면 옛 행이 되살아난다(행이 쌓이지 않는다).

사용:
    python plan_wish.py --selftest     (의무)
    python plan_wish.py --list
"""
import sys

import appdb

FAV_TYPE = 'PLAN_WISH'
SYS, USER = 'SYS', 'USER'


def key_of(plan):
    """플랜 dict → `(target_id, source_code)`. 못 정하면 `(None, None)`."""
    if not plan:
        return None, None
    uid = plan.get('user_plan_id')
    if uid:
        return int(uid), USER
    pid = plan.get('plan_id')
    return (int(pid), SYS) if pid else (None, None)


def _row(conn, tid, src):
    return conn.execute(
        "SELECT fav_id, record_status FROM user_favorite "
        "WHERE fav_type=? AND target_id=? AND COALESCE(source_code,'SYS')=? "
        "ORDER BY fav_id LIMIT 1", (FAV_TYPE, tid, src)).fetchone()


def is_wished(db_path, plan):
    tid, src = key_of(plan)
    if tid is None:
        return False
    conn = appdb.connect(db_path)
    try:
        r = _row(conn, tid, src)
        return bool(r and r[1] == 'LIVE')
    finally:
        conn.close()


def toggle(db_path, plan, label=''):
    """찜하기/풀기. **바뀐 뒤 상태**를 돌려준다."""
    tid, src = key_of(plan)
    if tid is None:
        return False
    conn = appdb.connect(db_path)
    try:
        r = _row(conn, tid, src)
        if r is None:
            conn.execute(
                "INSERT INTO user_favorite (fav_type, target_id, source_code, "
                " label, record_status) VALUES (?,?,?,?,'LIVE')",
                (FAV_TYPE, tid, src, label or ''))
            new = True
        else:
            new = (r[1] != 'LIVE')
            conn.execute(
                "UPDATE user_favorite SET record_status=?, label=COALESCE(NULLIF(?,''), label) "
                "WHERE fav_id=?", ('LIVE' if new else 'HIDE', label or '', r[0]))
        conn.commit()
        return new
    finally:
        conn.close()


def wishes(db_path, lang='KO'):
    """찜해 둔 플랜 목록. 각 항목 = `target_id · source · title · plan_id ·
    user_plan_id · cat_id · root_cat`.

    ⚠ **라벨은 저장값이 아니라 지금 제목**으로 다시 짓는다. 찜한 뒤에 제목을
      고치면 옛 이름이 남는다(실제로 이번 주에 플랜 제목을 여러 번 고쳤다).
      제목을 못 찾을 때만 저장해 둔 라벨로 떨어진다.
    """
    out = []
    conn = appdb.connect(db_path)
    try:
        par = {a: b for a, b in conn.execute(
            "SELECT cat_id, parent_id FROM sys_plan_category "
            "WHERE COALESCE(record_status,'LIVE')='LIVE'")}

        def root(cid, g=0):
            while cid is not None and par.get(cid) is not None and g < 12:
                cid, g = par[cid], g + 1
            return cid

        for tid, src, label in conn.execute(
                "SELECT target_id, COALESCE(source_code,'SYS'), label "
                "FROM user_favorite WHERE fav_type=? AND record_status='LIVE' "
                "ORDER BY fav_id", (FAV_TYPE,)):
            if src == USER:
                r = conn.execute(
                    "SELECT u.plan_code, p.cat_id FROM user_bible_plan u "
                    "LEFT JOIN sys_bible_plan p ON p.plan_id=u.origin_plan_id "
                    "WHERE u.user_plan_id=? AND COALESCE(u.record_status,'LIVE')='LIVE'",
                    (tid,)).fetchone()
                if not r:
                    continue                    # 지워진 플랜 — 조용히 뺀다
                title, cid = r[0] or label, r[1]
                out.append(dict(target_id=tid, source=src, title=title,
                                plan_id=None, user_plan_id=tid,
                                cat_id=cid, root_cat=root(cid)))
            else:
                r = conn.execute(
                    "SELECT COALESCE(("
                    "  SELECT contents FROM sys_text_asset WHERE text_type='PLAN_TITLE'"
                    "   AND clicked_id=p.plan_id AND UPPER(lang_code)=UPPER(?) "
                    "   AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1), p.plan_code), "
                    "  p.cat_id FROM sys_bible_plan p "
                    "WHERE p.plan_id=? AND COALESCE(p.record_status,'LIVE')='LIVE'",
                    (lang, tid)).fetchone()
                if not r:
                    continue
                title, cid = r[0] or label, r[1]
                out.append(dict(target_id=tid, source=src, title=title,
                                plan_id=tid, user_plan_id=None,
                                cat_id=cid, root_cat=root(cid)))
        return out
    finally:
        conn.close()


def count(db_path):
    conn = appdb.connect(db_path)
    try:
        return conn.execute(
            "SELECT COUNT(*) FROM user_favorite WHERE fav_type=? AND record_status='LIVE'",
            (FAV_TYPE,)).fetchone()[0]
    finally:
        conn.close()


# ── 팝업 ──────────────────────────────────────────────────────────────────

class WishDialog:
    """「☆ 묵상후보」 목록 팝업 (2026-08-16 사용자 지시 「팝업 버튼을 만들어라」).

    ★ **왜 팝업인가** — 후보는 **탭을 가리지 않는 목록**이라 여섯 서브탭 어디서도
      같아야 한다. 트리에 넣어 봤더니 「이상하다」는 지적을 받았다(트리는 플랜의
      **분류**를 보이는 자리인데 성격이 다른 묶음이 끼어든다). 띠에 콤보를 하나 더
      두는 것도 아니다 — 진행중 콤보와 헷갈린다.
    ⚠ **단추는 상단**(§0). 목록을 고르면 **그 플랜이 사는 탭으로 옮겨** 상세를 연다.
    ⚠ 후보는 「아직 안 본 것」이라 Focus 화면이 없다 — **상세**를 연다.
    """

    def __init__(self, parent, db_path, lang='KO', on_open=None, on_change=None):
        import tkinter as tk
        from tkinter import ttk
        self.db_path, self.lang = db_path, lang
        self.on_open, self.on_change = on_open, on_change

        self.win = tk.Toplevel(parent)
        self.win.title(_t('PW_TITLE_WIN', '묵상후보'))
        self.win.geometry('420x340')
        self.win.transient(parent)
        self.win.resizable(True, True)

        bar = ttk.Frame(self.win, padding=(8, 6))
        bar.pack(fill='x')
        # ⚠ 「열기」·「찜 풀기」가 무슨 뜻인지 물었다(2026-08-16) — 말을 고친다.
        #   열기 = **그 플랜 화면으로 간다** / 후보에서 빼기 = **찜만 푼다**(플랜은 그대로).
        ttk.Button(bar, text=_t('PW_OPEN', '플랜 보기'),
                   command=self._open).pack(side='left')
        ttk.Button(bar, text=_t('PW_UNWISH', '후보 해제'),
                   command=self._unwish).pack(side='left', padx=(6, 0))
        ttk.Button(bar, text=_t('COMMON_CLOSE', '닫기'),
                   command=self.win.destroy).pack(side='right')

        body = ttk.Frame(self.win, padding=(8, 0, 8, 8))
        body.pack(fill='both', expand=True)
        self.tv = ttk.Treeview(body, columns=('grp',), show='tree headings',
                               selectmode='browse')
        self.tv.heading('#0', text=_t('PW_COL_PLAN', '플랜'))
        self.tv.heading('grp', text=_t('PW_COL_GRP', '묶음'))
        self.tv.column('#0', width=230, anchor='w')
        self.tv.column('grp', width=140, anchor='w')
        vsb = ttk.Scrollbar(body, orient='vertical', command=self.tv.yview)
        self.tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        self.tv.pack(side='left', fill='both', expand=True)
        self.tv.bind('<Double-1>', lambda e: self._open())

        self.empty = ttk.Label(self.win, text='', foreground='#7F8C8D')
        self._rows = []
        self._fill()

        try:                       # 화면색·글꼴 (§35-11)
            import ui_theme
            ui_theme.adopt(self.win)
        except Exception:
            pass
        self.win.lift()
        self.win.attributes('-topmost', True)
        self.win.after(200, lambda: self.win.attributes('-topmost', False))

    def _fill(self):
        for i in self.tv.get_children():
            self.tv.delete(i)
        self._rows = wishes(self.db_path, self.lang)
        cn = _cat_names(self.db_path, self.lang)
        for i, w in enumerate(self._rows):
            self.tv.insert('', 'end', iid=str(i), text=w['title'],
                           values=(cn.get(w['cat_id'], ''),))
        if not self._rows:
            self.tv.insert('', 'end', iid='none',
                           text=_t('PW_EMPTY2', '찜해 둔 플랜이 없습니다'), values=('',))

    def _cur(self):
        sel = self.tv.selection()
        if not sel or sel[0] == 'none':
            return None
        try:
            return self._rows[int(sel[0])]
        except (ValueError, IndexError):
            return None

    def _open(self):
        w = self._cur()
        if not w:
            return
        self.win.destroy()
        if callable(self.on_open):
            self.on_open(w)

    def _unwish(self):
        w = self._cur()
        if not w:
            return
        toggle(self.db_path, w)
        self._fill()
        if callable(self.on_change):
            self.on_change()


def _t(key, dflt):
    try:
        import i18n
        return i18n.t(key, dflt)
    except Exception:
        return dflt


def _cat_names(db_path, lang):
    conn = appdb.connect(db_path)
    try:
        return {a: b for a, b in conn.execute(
            "SELECT clicked_id, contents FROM sys_text_asset "
            "WHERE text_type='PLAN_CAT_NAME' AND UPPER(lang_code)=UPPER(?) "
            "  AND COALESCE(record_status,'LIVE')='LIVE'", (lang,))}
    finally:
        conn.close()


# ── 자가검증 ──────────────────────────────────────────────────────────────

def selftest(db_path='bible_master.db'):
    """⚠ **되돌린다** — 검사가 사용자 자료를 남기면 안 된다."""
    ok = True
    before = count(db_path)

    # 살아 있는 sys 플랜 하나를 빌린다 (§0-5 — 검사를 데이터 「없음」에 걸지 않는다)
    conn = appdb.connect(db_path)
    pid = conn.execute("SELECT plan_id FROM sys_bible_plan "
                       "WHERE COALESCE(record_status,'LIVE')='LIVE' "
                       "ORDER BY plan_id LIMIT 1").fetchone()
    conn.close()
    if not pid:
        print('FAIL sys 플랜이 하나도 없다'); return False
    pid = pid[0]
    sysp = {'plan_id': pid}

    was = is_wished(db_path, sysp)
    try:
        # ① 켜고 끄기
        if toggle(db_path, sysp, '검사') is was:
            print('FAIL 토글이 상태를 안 바꾼다'); ok = False
        if is_wished(db_path, sysp) is was:
            print('FAIL 토글 뒤 조회가 옛 상태다'); ok = False
        # ② 목록에 보이나 (켜진 쪽일 때만)
        if not was:
            lst = wishes(db_path)
            if not any(w['plan_id'] == pid for w in lst):
                print('FAIL 찜했는데 목록에 없다'); ok = False
            if any(w['title'] in ('', None) for w in lst):
                print('FAIL 제목이 빈 항목이 있다'); ok = False
        # ③ **sys 와 user 를 가르는가** — 이것이 이 모듈의 핵심 함정
        if key_of({'plan_id': 4}) == key_of({'user_plan_id': 4}):
            print('FAIL sys 4번과 user 4번을 같게 본다'); ok = False
        if key_of({'plan_id': 4, 'user_plan_id': 9})[1] != USER:
            print('FAIL 둘 다 있으면 user 가 이겨야 한다'); ok = False
        if key_of({})[0] is not None or key_of(None)[0] is not None:
            print('FAIL 빈 플랜을 걸러야 한다'); ok = False
        # ④ 다시 찜해도 **행이 늘지 않는다**
        conn = appdb.connect(db_path)
        n1 = conn.execute("SELECT COUNT(*) FROM user_favorite WHERE fav_type=? "
                          "AND target_id=?", (FAV_TYPE, pid)).fetchone()[0]
        conn.close()
        toggle(db_path, sysp); toggle(db_path, sysp)
        conn = appdb.connect(db_path)
        n2 = conn.execute("SELECT COUNT(*) FROM user_favorite WHERE fav_type=? "
                          "AND target_id=?", (FAV_TYPE, pid)).fetchone()[0]
        conn.close()
        if n1 != n2:
            print('FAIL 다시 찜하면 행이 쌓인다: %d → %d' % (n1, n2)); ok = False
    finally:
        # 되돌리기
        if is_wished(db_path, sysp) is not was:
            toggle(db_path, sysp)
    after = count(db_path)
    if after != before:
        print('FAIL 검사가 자료를 남겼다: %d → %d' % (before, after)); ok = False

    print('plan_wish selftest', 'OK' if ok else 'FAIL')
    return ok


def _list(db_path='bible_master.db'):
    ws = wishes(db_path)
    print('묵상후보 %d개' % len(ws))
    for w in ws:
        print('   %-5s %-4s cat %-5s %s'
              % (w['source'], w['target_id'], w['cat_id'], w['title']))


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    if '--list' in sys.argv:
        _list()
    else:
        print(__doc__.split('\n')[0])
