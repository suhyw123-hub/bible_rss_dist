# -*- coding: utf-8 -*-
"""db_book_catalog.py — **아직 안 받은 책**을 목록에만 올린다 (영구 · selftest 의무)
================================================================================

**왜 필요한가** (2026-08-24 사용자 지시):
  「아직 다운로드 받지 않은 책을 등록해야 도서서재 화면에서 클릭할 때 어떤
    기능이 작동하는지 알 수 있다」

실측 — 지금 **35권 전부 본문을 갖고 있어**(`sys_book_unit_text`) 「안 받은 책」이
하나도 없다. 그래서 서재의 `↓ 받기` 표식과 다운로드 점프가 **한 번도 안 열린다.**

★★ **팩 경계가 이미 실측으로 정해져 있다**(2026-08-24):
      목차·메타(책 35 · 유닛 6,863)   **0.34MB**  ← 코어팩
      본문(sys_book_unit_text)        **144MB**   ← 팩
  ⇒ **`sys_book_asset` 행만 있고 `sys_book_unit_text` 가 없으면** 그것이 곧
    「명단에는 있는데 아직 안 받은 책」이다. 새 표가 필요 없다.

⚠⚠ **가짜를 짓지 않는다**(§0-1). 여기 담는 것은 **확인 가능한 사실**뿐이다 —
  제목·저자·연대·분류·저작권. 그리고:
  ⚠ **`source_url` 은 비워 둔다** — 확인 안 한 주소를 적으면 §0-1b 가 기록한
    사고(적어 둔 CCEL 주소 셋 중 둘이 404였고 **라이선스 화면이 거짓을 알렸다**)를
    되풀이한다. 받을 때 **링크부터 보이고**(규칙 ⓪) 그때 채운다.
  ⚠ **목차(유닛)도 넣지 않는다** — 장 제목을 기억으로 적으면 그것이 곧 §0-1b 가
    금지한 「원문을 안 받고 글자로 적어 넣기」다. 진짜 팩에서는 목차가 코어팩에
    함께 오지만, **여기서는 우리가 지어낼 수 없다.**
  ⇒ 그래서 카드에 편 수가 안 뜬다. **그것이 정직한 상태다.**

사용:
    python db_book_catalog.py --selftest
    python db_book_catalog.py --list
    python db_book_catalog.py --add WESTMINSTER_CONF
    python db_book_catalog.py --remove WESTMINSTER_CONF
"""
import os
import sys
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

import appdb

DB = 'bible_master.db'

# 후보 — **문서가 「없으므로 수집할 가치가 있다」고 적어 둔 것**(§서재 「새로 수집할
# 영역」). 진짜로 받을 계획이라 **가짜 항목이 아니다.**
#   (code, 원제, 한국어 제목, 저자, 연대, 분류, 소개문)
CANDIDATES = {
    'WESTMINSTER_CONF': (
        'The Westminster Confession of Faith',
        '웨스트민스터 신앙고백서',
        'Westminster Assembly', 1646, 'DOCTRINE',
        '1643년부터 1649년까지 런던 웨스트민스터 사원에 모인 신학자 회의가 작성한 '
        '신앙고백서입니다. 성경론에서 시작해 하나님과 사람, 그리스도의 사역, 구원의 '
        '적용, 교회와 성례, 마지막 일까지를 차례로 다룹니다.\n'
        '각 항목마다 근거 구절을 함께 두는 방식이라 성경을 따라 읽으며 교리를 '
        '확인하기에 좋습니다. 오랫동안 여러 교회가 신앙을 정리하는 틀로 삼아 왔습니다.\n'
        '▸ 아직 받지 않은 자료입니다. 목록에만 올라 있고 본문은 내려받아야 읽을 수 '
        '있습니다.'),
    'BELGIC_CONF': (
        'The Belgic Confession',
        '벨직 신앙고백',
        'Guido de Brès', 1561, 'DOCTRINE',
        '1561년 귀도 드 브레가 작성한 서른일곱 조항의 신앙고백입니다. 박해 속에서 '
        '자신들이 무엇을 믿는지 밝히려고 쓴 글이라 문장이 간결하고 고백하는 어조가 '
        '살아 있습니다.\n'
        '하나님을 아는 두 길에서 시작해 성경, 삼위일체, 사람의 타락과 구원, 교회와 '
        '성례, 마지막 심판까지 이어집니다.\n'
        '▸ 아직 받지 않은 자료입니다. 목록에만 올라 있고 본문은 내려받아야 읽을 수 '
        '있습니다.'),
    'DORT_CANONS': (
        'The Canons of Dort',
        '도르트 신조',
        'Synod of Dort', 1619, 'DOCTRINE',
        '1618년부터 1619년까지 네덜란드 도르트레흐트에서 열린 회의가 내놓은 판단문입니다. '
        '당시 제기된 다섯 가지 물음에 조항별로 답하고, 이어서 오해를 하나씩 짚어 '
        '바로잡는 형식을 취합니다.\n'
        '선택과 유기, 그리스도의 죽으심, 사람의 부패, 부르심과 견인을 다룹니다.\n'
        '▸ 아직 받지 않은 자료입니다. 목록에만 올라 있고 본문은 내려받아야 읽을 수 '
        '있습니다.'),
}


def listing(conn):
    """[(book_code, 제목, 편, 본문 보유)] — 명단에만 있는 것을 가려낸다."""
    out = []
    for code, title, n, has in conn.execute(
            "SELECT a.book_code, COALESCE(k.title, a.title), "
            "  (SELECT COUNT(*) FROM sys_book_unit u WHERE u.book_id=a.book_id), "
            "  EXISTS(SELECT 1 FROM sys_book_unit u "
            "          JOIN sys_book_unit_text x ON x.unit_id=u.unit_id "
            "         WHERE u.book_id=a.book_id) "
            "  FROM sys_book_asset a "
            "  LEFT JOIN sys_book_asset_text k "
            "         ON k.book_id=a.book_id AND k.lang_code='KO' "
            " WHERE COALESCE(a.record_status,'LIVE')='LIVE' "
            " ORDER BY a.book_id"):
        out.append((code, title, n, bool(has)))
    return out


def add(conn, code):
    """명단에만 올린다 — **본문도 목차도 넣지 않는다.**"""
    if code not in CANDIDATES:
        raise SystemExit('모르는 코드: %s (가능: %s)' % (code, ', '.join(CANDIDATES)))
    orig, ko, author, year, cat, desc = CANDIDATES[code]
    r = conn.execute("SELECT book_id FROM sys_book_asset WHERE book_code=?",
                     (code,)).fetchone()
    if r:
        return r[0], False
    conn.execute(
        "INSERT INTO sys_book_asset "
        " (book_code, title, author, lang_code, copyright_type, pub_year, "
        "  description, book_category, record_status) "
        " VALUES (?,?,?,?,?,?,?,?,'LIVE')",
        (code, orig, author, 'EN', 'PUBLIC_DOMAIN', year, desc, cat))
    bid = conn.execute("SELECT book_id FROM sys_book_asset WHERE book_code=?",
                       (code,)).fetchone()[0]
    # 한국어 제목 덮개 — 서재 카드가 이것을 먼저 읽는다(§17)
    conn.execute("INSERT INTO sys_book_asset_text (book_id, lang_code, title) "
                 " VALUES (?,?,?)", (bid, 'KO', ko))
    conn.commit()
    return bid, True


def remove(conn, code):
    """되돌리기 — **본문이 생겼으면 거부한다**(진짜 책을 지우지 않는다)."""
    r = conn.execute("SELECT book_id FROM sys_book_asset WHERE book_code=?",
                     (code,)).fetchone()
    if not r:
        return 0
    bid = r[0]
    n = conn.execute(
        "SELECT COUNT(*) FROM sys_book_unit u "
        "  JOIN sys_book_unit_text x ON x.unit_id=u.unit_id "
        " WHERE u.book_id=?", (bid,)).fetchone()[0]
    if n:
        raise SystemExit('본문 %d행이 있다 — 명단 항목이 아니라 진짜 책이다. 안 지운다.' % n)
    conn.execute("DELETE FROM sys_book_asset_text WHERE book_id=?", (bid,))
    conn.execute("DELETE FROM sys_book_unit WHERE book_id=?", (bid,))
    conn.execute("DELETE FROM sys_book_asset WHERE book_id=?", (bid,))
    conn.commit()
    return 1


def selftest():
    ok = fail = 0

    def t(name, cond, extra=''):
        nonlocal ok, fail
        if cond:
            ok += 1
            print('  PASS  %s' % name)
        else:
            fail += 1
            print('  FAIL  %s  %s' % (name, extra))

    t('후보에 코드·제목·소개문이 다 있다',
      all(len(v) == 6 and all(x for x in v) for v in CANDIDATES.values()))
    t('소개문이 「아직 받지 않은」이라 밝힌다',
      all('아직 받지 않은' in v[5] for v in CANDIDATES.values()))
    # ⚠ 소개문 게이트(§67차) — 작업과정 낱말·빈 줄 금지
    t('소개문에 빈 줄이 없다',
      all('\n\n' not in v[5] for v in CANDIDATES.values()))

    try:
        conn = appdb.connect(DB)
    except Exception as e:
        print('  DB 없음: %s' % e)
        print('\n%d PASS · %d FAIL' % (ok, fail))
        return 1
    CODE = 'WESTMINSTER_CONF'
    try:
        before = len(listing(conn))
        existed = conn.execute("SELECT 1 FROM sys_book_asset WHERE book_code=?",
                               (CODE,)).fetchone() is not None
        if existed:
            print('  (건너뜀) %s 가 이미 있다 — 지우고 다시 넣지 않는다' % CODE)
        else:
            bid, made = add(conn, CODE)
            t('명단에 올랐다', made and bid)
            rows = {r[0]: r for r in listing(conn)}
            t('목록에 나온다', CODE in rows)
            t('본문이 없다 (안 받은 책)', rows[CODE][3] is False)
            t('편이 0이다 (목차도 안 지어낸다)', rows[CODE][2] == 0, rows[CODE][2])
            t('한국어 제목이 붙는다', '웨스트민스터' in rows[CODE][1], rows[CODE][1])
            t('책이 하나 늘었다', len(rows) == before + 1)

            # ★ 서재가 실제로 「안 받음」으로 읽는가
            import book_shelf
            shelf = {r['book_id']: r for r in book_shelf.fetch(DB, 'KO')}
            row = next((r for r in shelf.values() if r['book_id'] == bid), None)
            t('서재가 읽어 온다', row is not None)
            t('서재가 has_text=False 로 본다', row and row['has_text'] is False)
            t('구간에 든다 (필터에서 안 사라진다)',
              row and book_shelf.band_of(row['parts'], book_shelf.SIZE_BANDS)
              and book_shelf.band_of(row['year'], book_shelf.ERA_BANDS),
              (row['parts'], row['year']) if row else None)

            # ★ 되돌리기 — **본문이 있으면 거부하는가**(탐지력)
            u = conn.execute("SELECT COUNT(*) FROM sys_book_unit WHERE book_id=?",
                             (bid,)).fetchone()[0]
            t('유닛도 안 만들었다', u == 0, u)
            t('지워진다', remove(conn, CODE) == 1)
            t('원래대로', len(listing(conn)) == before)
            t('제목 덮개도 지워졌다',
              conn.execute("SELECT COUNT(*) FROM sys_book_asset_text "
                           " WHERE book_id=?", (bid,)).fetchone()[0] == 0)
        # 진짜 책은 못 지운다
        real = conn.execute("SELECT book_code FROM sys_book_asset "
                            " WHERE book_code='DIDACHE'").fetchone()
        if real:
            try:
                remove(conn, 'DIDACHE')
                t('진짜 책은 거부한다', False, '지워졌다!')
            except SystemExit:
                t('진짜 책은 거부한다', True)
    finally:
        conn.close()
    print('\n%d PASS · %d FAIL' % (ok, fail))
    return 0 if fail == 0 else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--db', default=DB)
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--list', action='store_true')
    ap.add_argument('--add')
    ap.add_argument('--remove')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(selftest())
    conn = appdb.connect(a.db)
    try:
        if a.add:
            bid, made = add(conn, a.add)
            print('%s → book_id %s · %s' % (a.add, bid, '등록' if made else '이미 있음'))
        elif a.remove:
            print('지움 %d' % remove(conn, a.remove))
        rows = listing(conn)
        no = [r for r in rows if not r[3]]
        print('\n전체 %d권 · **본문 없는(안 받은) 책 %d권**' % (len(rows), len(no)))
        for code, title, n, _h in no:
            print('  ↓ %-20s %-24s 편 %d' % (code, title[:24], n))
        print('\n등록할 수 있는 후보: %s' % ', '.join(CANDIDATES))
    finally:
        conn.close()


if __name__ == '__main__':
    main()
