"""
voice_bible_ui.py  —  Voice Bible 전체화면 녹음 전용 오버레이

레이아웃 (위→아래):
  ① 관리바   : ffmpeg경고·복귀 (전체 탭 공통)
  ② Notebook : 녹음(목소리·버전 상단) / 녹음결과관리 / 목소리등록 / 녹음환경점검
"""
import sqlite3
import appdb
import i18n
import threading
import tkinter as tk
from tkinter import ttk, messagebox

from voice_bible import (
    Recorder, Player, preflight, save_take, repair,
    voice_path, wav_path, existing_file, forget_file, get_voice_record,
    save_voice_record, delete_voice_record,
    get_recorded_verses, VOICES_ROOT,
)
from voice_test_popup import VoiceTestFrame
from voice_mgmt_panel import VoiceMgmtPanel
import bidi                               # 오른쪽에서 왼쪽으로 읽는 글 (font.md §8)

# ★ 2026-10-13 (docs/1.txt 74-4) — 「목소리등록」 탭을 걷고 이름 칸을 녹음 탭 맨 위로(이름 → 녹음 차례)
_REC_TAB   = 0
_MGMT_TAB  = 1
_ENV_TAB   = 2


class VoiceBiblePanel(tk.Frame):
    """앱 전체를 덮는 녹음 전용 오버레이. show(bcode, chapter)로 활성화."""

    def __init__(self, parent, db_path, lang_getter, version_getter,
                 on_restore=None):
        super().__init__(parent, bg="#1C2833")
        self.db_path        = db_path
        self.lang_getter    = lang_getter
        self.version_getter = version_getter
        self.on_restore     = on_restore

        self._owner     = tk.StringVar(value="")
        self._rec_ver   = tk.StringVar(value="")

        self._bcode     = None
        self._chapter   = None
        self._book_name = ""
        self._verses    = []    # [(verse_id, verse_num, text), ...]
        self._recorded  = set()
        self._cur_idx   = 0

        self._recorder  = Recorder()
        self._player    = Player()

        self._build()
        self._pending = None          # 저장에 실패한 녹음(vid, owner, ver, 소리) — [다시 저장] 으로 살린다
        self._repaired = False
        # ⚠ 일꾼 스레드는 화면을 직접 만지지 않는다 — 큐에 넣고 메인이 꺼낸다(「main thread is not in main loop」)
        import queue as _qm
        self._uiq = _qm.Queue()
        self._poll_id = self.after(120, self._poll_ui)

    # ── UI 구성 ─────────────────────────────────────────────────────────────

    def _build(self):
        # ① 관리바 (전체 탭 공통: ffmpeg 경고 + 복귀) ──────────────────────
        tb = tk.Frame(self, bg="#17202A", pady=6)
        tb.pack(fill="x")

        self.lbl_ffmpeg = tk.Label(tb, text="", bg="#17202A", fg="#E74C3C",
                                   font=("Malgun Gothic", 8))
        self.lbl_ffmpeg.pack(side="left", padx=10, expand=True, anchor="w")

        tk.Button(tb, text=i18n.t('VOICE_BACK','← 복귀'), command=self._restore,
                  bg="#922B21", fg="white",
                  font=("Malgun Gothic", 9, "bold"), bd=0, padx=14, pady=4
                  ).pack(side="right", padx=10)

        # ② Notebook ────────────────────────────────────────────────────────
        self._nb = ttk.Notebook(self)
        self._nb.pack(fill="both", expand=True, padx=4, pady=4)
        self._nb.bind("<<NotebookTabChanged>>", self._on_tab_change)

        self._build_rec_tab()
        self._build_mgmt_tab()
        self._build_env_tab()

    def _build_rec_tab(self):
        """Tab 0: 녹음"""
        rec_frame = tk.Frame(self._nb, bg="#1C2833")
        self._nb.add(rec_frame, text='  '+i18n.t('TAB_VOICE_RECORD','녹음')+'  ')

        # 목소리 / 버전 선택 바
        sel = tk.Frame(rec_frame, bg="#17202A", pady=5)
        sel.pack(fill="x")
        tk.Label(sel, text=i18n.t('VOICE_OWNER_LABEL','목소리 주인공 이름:'), bg="#17202A", fg="#AEB6BF",
                 font=("Malgun Gothic", 9)).pack(side="left", padx=(10, 2))
        # ★ 2026-10-28 (docs/1.txt 1-(1)) 사용자 「콤보상자는 주로 선택하는 기능인데 입력하고 저장하라니 혼란스럽다 ·
        #   이름 입력창을 별도로 배치하고 저장 · 저장하면 콤보상자에 표시 · 오른쪽 위 「등록됨」은 필요 없다」
        #   ⇒ 콤보 = 선택만(readonly) · 그 오른쪽 [새 이름 입력칸][저장] · 저장하면 곧바로 콤보에 들어가 골라진다.
        self._owner_cb = ttk.Combobox(sel, textvariable=self._owner, width=14,
                                      font=("Malgun Gothic", 9), state="readonly")
        self._owner_cb.pack(side="left", padx=2)
        self._owner_cb.bind("<<ComboboxSelected>>", lambda e: self._reload_recorded())
        tk.Label(sel, text=i18n.t('VOICE_NEWNAME', '새 이름:'), bg="#17202A", fg="#AEB6BF",
                 font=("Malgun Gothic", 9)).pack(side="left", padx=(12, 2))
        self._new_owner = tk.StringVar()
        self._new_ent = tk.Entry(sel, textvariable=self._new_owner, width=12, font=("Malgun Gothic", 9))
        self._new_ent.pack(side="left", padx=2)
        self._new_ent.bind("<Return>", lambda e: self._register_owner())
        tk.Button(sel, text=i18n.t('COMMON_SAVE', '저장'), command=self._register_owner,
                  bg="#1A5276", fg="white", font=("Malgun Gothic", 9, "bold"),
                  bd=0, padx=10, pady=2).pack(side="left", padx=(2, 10))
        # 알림 줄 — 잘못 넣었을 때만 잠깐(성공했을 때는 콤보가 말한다)
        self._reg_note = tk.Label(sel, text="", bg="#17202A", fg="#E74C3C", font=("Malgun Gothic", 8))
        self._reg_note.pack(side="right", padx=8)
        tk.Label(sel, text=i18n.t('VOICE_VER_LABEL','  버전:'), bg="#17202A", fg="#AEB6BF",
                 font=("Malgun Gothic", 9)).pack(side="left")
        self._ver_cb = ttk.Combobox(sel, textvariable=self._rec_ver, width=8,
                                    font=("Malgun Gothic", 9), state="readonly")
        self._ver_cb.pack(side="left", padx=2)
        self._ver_cb.bind("<<ComboboxSelected>>", lambda e: self._reload_verses())

        # 녹음구절창
        self.cur_frame = tk.Frame(rec_frame, bg="#212F3D", padx=16, pady=12)
        self.cur_frame.pack(fill="x")

        self.lbl_ref = tk.Label(self.cur_frame, text="—",
                                bg="#212F3D", fg="#AED6F1",
                                font=("Malgun Gothic", 17, "bold"))
        self.lbl_ref.pack(anchor="w")

        self.lbl_text = tk.Label(self.cur_frame, text="",
                                 bg="#212F3D", fg="#ECF0F1",
                                 font=("Malgun Gothic", 13),
                                 anchor="w", justify="left", wraplength=900)
        # ★ 성경 구절은 **어디에 있든 「성경」 역할**이다 (font.md §22).
        #   화면마다 크기가 달라 「같은 구절인데 다르게 느껴진다」던 것을 묶는다.
        try:
            import theme_font
            theme_font.register(self.lbl_text, self.db_path, 'bible')
        except Exception:
            pass
        self.lbl_text.pack(fill="x", pady=(6, 10))
        self.cur_frame.bind(
            "<Configure>",
            lambda e: self.lbl_text.config(wraplength=max(100, e.width - 32)))

        # 버튼 행: [레벨] [⏺녹음] [▶확인] [삭제] [상태]  (▲▼ 걷음 — 74-2 · 목록에서 누른다)
        btn_row = tk.Frame(self.cur_frame, bg="#212F3D")
        btn_row.pack(fill="x")

        tk.Label(btn_row, text=i18n.t('VOICE_LEVEL','레벨:'), bg="#212F3D", fg="#888",
                 font=("Malgun Gothic", 8)).pack(side="left")
        self._meter_canvas = tk.Canvas(btn_row, bg="#1C2833",
                                       height=14, width=200, highlightthickness=0)
        self._meter_canvas.pack(side="left", padx=4)
        self._meter_bar = self._meter_canvas.create_rectangle(
            0, 0, 0, 14, fill="#27AE60", outline="")

        self.btn_rec = tk.Button(btn_row, text=i18n.t('VOICE_REC2','⏺ 녹음'),
                                 command=self._toggle_record,
                                 bg="#922B21", fg="white",
                                 font=("Malgun Gothic", 10, "bold"),
                                 bd=0, padx=14, pady=4)
        self.btn_rec.pack(side="left", padx=(8, 3))

        # ★ 2026-10-13 (docs/1.txt 74-2) — 연속 녹음: 이 절을 녹음하고 [저장하고 다음 절]을 누르면 저장한 뒤
        #   다음 절로 옮겨 곧바로 녹음을 시작한다. 끝내려면 [연속 녹음 중단](그때 녹음 중이던 절도 저장한다).
        self._cont = False
        self.btn_cont = tk.Button(btn_row, text=i18n.t('VOICE_CONT_START', '⏺ 연속 녹음'),
                                  command=self._toggle_cont, bg="#922B21", fg="white",
                                  font=("Malgun Gothic", 10, "bold"), bd=0, padx=12, pady=4)
        # ★ 2026-10-27 (docs/1.txt 1) 폰과 같은 단추 넷 — [녹음|녹음 멈춤][들어보기|멈춤][다음 절][삭제].
        #   연속 녹음은 [다음 절]이 맡는다(녹음 중에 누르면 저장하고 다음 절을 곧바로 녹음) — btn_cont 는 안 놓는다.
        self.btn_next = tk.Button(btn_row, text=i18n.t('VOICE_NEXT2', '다음 절 ▶'),
                                  command=self._next_click, bg="#1E8449", fg="white",
                                  font=("Malgun Gothic", 10, "bold"), bd=0, padx=12, pady=4)

        self.btn_preview = tk.Button(btn_row, text=i18n.t('VOICE_LISTEN2', '▶ 들어보기'),
                                     command=self._preview_current,
                                     bg="#1A5276", fg="white",
                                     font=("Malgun Gothic", 10, "bold"),
                                     bd=0, padx=10, pady=4)
        self.btn_preview.pack(side="left", padx=3)
        self.btn_next.pack(side="left", padx=3)

        self.btn_del = tk.Button(btn_row, text=i18n.t('COMMON_DELETE','삭제'),
                                 command=self._delete_recording,
                                 bg="#4A235A", fg="white",
                                 font=("Malgun Gothic", 10), bd=0, padx=10, pady=4)
        self.btn_del.pack(side="left", padx=3)

        self.lbl_status = tk.Label(btn_row, text="", bg="#212F3D",
                                   fg="#27AE60", font=("Malgun Gothic", 9))
        self.lbl_status.pack(side="left", padx=(8, 4))

        self.btn_retry = tk.Button(btn_row, text=i18n.t('VOICE_RETRY_SAVE', '다시 저장'),
                                   command=self._retry_save, bg="#B9770E", fg="white",
                                   font=("Malgun Gothic", 9, "bold"), bd=0, padx=10, pady=4)

        # 대기열
        q_hdr = tk.Frame(rec_frame, bg="#154360", pady=3)
        q_hdr.pack(fill="x", padx=6, pady=(6, 0))
        tk.Label(q_hdr, text=i18n.t('VOICE_CHAPTER_LIST','  이 장의 구절'), bg="#154360", fg="white",
                 font=("Malgun Gothic", 9, "bold")).pack(side="left")
        self.lbl_q_count = tk.Label(q_hdr, text="", bg="#154360",
                                    fg="#AEB6BF", font=("Malgun Gothic", 8))
        self.lbl_q_count.pack(side="left", padx=4)

        q_f = tk.Frame(rec_frame, bg="#1C2833")
        q_f.pack(fill="both", expand=True, padx=6, pady=(0, 4))

        self.queue_tv = ttk.Treeview(q_f, columns=("rec", "ref", "text"),
                                     show="headings", selectmode="browse")
        self.queue_tv.heading("rec",  text="")
        self.queue_tv.heading("ref",  text=i18n.t('VOICE_VERSE','절'))
        self.queue_tv.heading("text", text=i18n.t('COMMON_CONTENT','본문'))
        self.queue_tv.column("rec",  width=30,  anchor="center", stretch=False)
        self.queue_tv.column("ref",  width=50,  anchor="center", stretch=False)
        self.queue_tv.column("text", anchor="w")
        self.queue_tv.tag_configure("recorded",   foreground="#82E0AA")
        self.queue_tv.tag_configure("unrecorded", foreground="#808B96")
        # ★ 지금 녹음할 구절 = 색 반전(74-2) — 위에 크게도 보이지만 목록에서 자리를 잃지 않게
        self.queue_tv.tag_configure("current", background="#AED6F1", foreground="#17202A")

        vsb = ttk.Scrollbar(q_f, orient="vertical", command=self.queue_tv.yview)
        self.queue_tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        self.queue_tv.pack(fill="both", expand=True)
        self.queue_tv.bind("<<TreeviewSelect>>", self._on_queue_click)

        # 키보드 바인딩
        self.bind("<Next>",  lambda e: self._nav_next())
        self.bind("<Prior>", lambda e: self._nav_prev())
        self.bind("<Down>",  lambda e: self._nav_next())
        self.bind("<Up>",    lambda e: self._nav_prev())
        # ★ 2026-10-28 (docs/1.txt 1-(1)) 「구절 사이에 화살표로 이동」 — 위 바인딩은 틀(Frame)에 걸려 키를 못 받았다.
        #   키를 받는 것은 목록(포커스)이라 거기에 건다 · 목록의 기본 이동은 막는다(지운 뒤 다시 그려 자리가 튄다).
        for _k, _f in (("<Down>", self._nav_next), ("<Up>", self._nav_prev),
                       ("<Right>", self._nav_next), ("<Left>", self._nav_prev),
                       ("<Next>", self._nav_next), ("<Prior>", self._nav_prev)):
            self.queue_tv.bind(_k, lambda e, f=_f: (f(), 'break')[1])

    def _build_mgmt_tab(self):
        """Tab 1: 녹음결과관리"""
        mgmt_frame = tk.Frame(self._nb, bg="#1C2833")
        self._nb.add(mgmt_frame, text='  '+i18n.t('TAB_VOICE_RESULT','녹음결과관리')+'  ')
        self._mgmt_panel = VoiceMgmtPanel(
            mgmt_frame, db_path=self.db_path,
            lang_getter=self.lang_getter,
            version_getter=self.version_getter,
        )
        self._mgmt_panel.pack(fill="both", expand=True)

    def _build_env_tab(self):
        """Tab 3: 녹음환경점검"""
        env_frame = tk.Frame(self._nb, bg="#1C2833")
        self._nb.add(env_frame, text='  '+i18n.t('TAB_VOICE_CHECK','녹음환경점검')+'  ')
        self._env_frame = VoiceTestFrame(env_frame)
        self._env_frame.pack(fill="both", expand=True)

    # ── 탭 변경 ─────────────────────────────────────────────────────────────

    def _on_tab_change(self, event=None):
        idx = self._nb.index("current")
        if idx == _MGMT_TAB:
            self._mgmt_panel.activate(self._owner.get(), self._rec_ver.get())

    # ── 공개 API ─────────────────────────────────────────────────────────────

    def show(self, bcode: int, chapter: int):
        self._bcode   = bcode
        self._chapter = chapter
        self._cur_idx = 0
        self._load_owners()
        self._load_versions()
        self._load_verses()
        self._nb.select(_REC_TAB)
        self._show_preflight()
        if not self._repaired:                     # 옛 녹음 정리(WAV→mp3 · 경로 · 기록 없는 파일) — 한 번
            self._repaired = True
            threading.Thread(target=lambda: repair(self.db_path), daemon=True).start()
        self.place(relx=0, rely=0, relwidth=1, relheight=1)
        self.lift()
        self.after(50, self.queue_tv.focus_set)   # 화살표가 곧바로 듣게

    # ── 초기화 ───────────────────────────────────────────────────────────────

    _PF_MSG = {'NO_MIC': ('VOICE_PF_NOMIC', '마이크를 찾지 못했습니다 — 마이크를 꽂거나 Windows 설정 ▸ 개인 정보 ▸ 마이크에서 앱의 마이크 사용을 켜 주세요.'),
               'NO_WRITE': ('VOICE_PF_NOWRITE', '녹음 파일을 저장할 폴더를 만들 수 없습니다 — 디스크 공간이나 폴더 권한을 확인해 주세요.'),
               'NO_MP3': ('VOICE_PF_NOMP3', 'MP3 로 저장할 수 없어 WAV 로 저장합니다(파일이 조금 큽니다).')}

    def _show_preflight(self):
        """녹음 전 점검(마이크 · 저장 폴더 · mp3) → 맨 위 줄에 사람 말로. 막는 문제가 있으면 True."""
        probs = preflight()
        self.lbl_ffmpeg.config(text='  '.join(i18n.t(*self._PF_MSG[k]) for k, _b in probs))
        return any(b for _k, b in probs)

    def _load_owners(self):
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT DISTINCT voice_owner FROM user_voice_asset "
                    "ORDER BY voice_owner"
                ).fetchall()
            owners = [r[0] for r in rows]
        except Exception:
            owners = []
        if VOICES_ROOT.exists():
            for p in VOICES_ROOT.iterdir():
                if p.is_dir() and p.name not in owners:
                    owners.append(p.name)
        owners.sort()
        self._owner_cb["values"] = owners
        if not self._owner.get() and owners:
            self._owner.set(owners[0])

    def _load_versions(self):
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT version_code FROM bible_version ORDER BY version_code"
                ).fetchall()
            vers = [r[0] for r in rows]
        except Exception:
            vers = []
        self._ver_cb["values"] = vers
        default = self.version_getter()
        self._rec_ver.set(default if default in vers else (vers[0] if vers else ""))

    def _load_verses(self):
        if self._bcode is None:
            return
        ver  = self._rec_ver.get() or self.version_getter()
        lang = self.lang_getter()
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT bi.verse_id, bi.verse, COALESCE(bc.verse_text,'') "
                    "FROM bible_index bi "
                    "LEFT JOIN bible_content bc "
                    "  ON bc.verse_id=bi.verse_id AND bc.version_code=? "
                    "WHERE bi.bcode=? AND bi.chapter=? ORDER BY bi.verse",
                    (ver, self._bcode, self._chapter)
                ).fetchall()
                bn = conn.execute(
                    "SELECT short_name FROM book_names "
                    "WHERE book_code=? AND lang_code=?",
                    (self._bcode, lang)
                ).fetchone()
        except Exception:
            rows, bn = [], None

        self._book_name = bn[0] if bn else str(self._bcode)
        self._verses    = [(r[0], r[1], r[2]) for r in rows]
        self._recorded  = get_recorded_verses(
            self.db_path, self._owner.get(),
            ver, self._bcode, self._chapter
        ) if self._owner.get() else set()

        self._cur_idx = 0
        self._refresh_current()
        self._refresh_queue()

    def _reload_verses(self):
        self._load_verses()

    def _reload_recorded(self):
        ver = self._rec_ver.get() or self.version_getter()
        self._recorded = get_recorded_verses(
            self.db_path, self._owner.get(),
            ver, self._bcode, self._chapter
        ) if self._owner.get() else set()
        self._refresh_current()
        self._refresh_queue()

    def _register_owner(self):
        name = self._new_owner.get().strip()
        if not name:
            self._note(i18n.t('VOICE_ENTERNAME', '이름을 입력하세요.'))
            return
        try:
            (VOICES_ROOT / name).mkdir(parents=True, exist_ok=True)
        except Exception as e:
            self._log('목소리 폴더 만들기 실패', e)
            self._show_preflight()
        current = list(self._owner_cb["values"])
        if name not in current:
            current.append(name)
            current.sort()
            self._owner_cb["values"] = current
        self._owner.set(name)
        self._new_owner.set('')
        self._note('')
        self._reload_recorded()

    def _note(self, text):
        """잘못 넣었을 때만 잠깐 보이고 4초 뒤 걷는다(늘 남는 「등록됨」은 사용자 요청으로 걷었다)."""
        self._reg_note.config(text=text)
        if getattr(self, '_note_job', None):
            try:
                self.after_cancel(self._note_job)
            except Exception:                             # noqa: BLE001
                pass
        self._note_job = self.after(4000, lambda: self._reg_note.config(text='')) if text else None

    # ── 현재 구절 / 대기열 ───────────────────────────────────────────────────

    def _refresh_current(self):
        if not self._verses or self._cur_idx >= len(self._verses):
            self.lbl_ref.config(text=i18n.t('COMMON_DONE','완료'), fg="#27AE60")
            self.lbl_text.config(text="")
            self.lbl_status.config(text="")
            return
        vid, vnum, vtext = self._verses[self._cur_idx]
        self.lbl_ref.config(
            text=f"{self._book_name}  {self._chapter}:{vnum}", fg="#AED6F1")
        # 히브리·아랍은 되돌려 오른쪽에 붙인다(없으면 배치 그대로)
        _t, _o = bidi.label(vtext or "(본문 없음)")
        self.lbl_text.config(text=_t, **({'justify': 'left', 'anchor': 'w'} | _o))
        if not self._recorder.is_recording:
            self.lbl_status.config(
                text=i18n.t('VOICE_HASREC','● 녹음 있음') if vid in self._recorded else "",
                fg="#27AE60")

    def _refresh_queue(self):
        """★ 장 전체를 늘 그린다(74-2 — 그전에는 「지금 구절 다음부터」만 그려 위로 갈 수 없었다).
        지금 녹음할 구절은 색 반전 · 보이게 굴린다."""
        self.queue_tv.delete(*self.queue_tv.get_children())
        n_rec = sum(1 for v in self._verses if v[0] in self._recorded)
        self.lbl_q_count.config(text=i18n.t('VOICE_COUNT', '(%d절 중 %d절 녹음)') % (len(self._verses), n_rec))
        cur = self._verses[self._cur_idx][0] if self._verses and self._cur_idx < len(self._verses) else None
        for vid, vnum, vtext in self._verses:
            has_rec = vid in self._recorded
            tags = ["recorded" if has_rec else "unrecorded"]
            if vid == cur:
                tags.append("current")
            self.queue_tv.insert("", "end", iid=str(vid),
                                 values=("⏺" if has_rec else "○",
                                         str(vnum), bidi.for_display(vtext[:100])),
                                 tags=tuple(tags))
        if cur is not None:
            self._syncing_q = True
            try:
                self.queue_tv.selection_set(str(cur))
                self.queue_tv.see(str(cur))
            finally:
                self.after_idle(lambda: setattr(self, '_syncing_q', False))

    # ── 탐색 ─────────────────────────────────────────────────────────────────

    def _nav_next(self):
        if self._recorder.is_recording:
            return
        if self._cur_idx + 1 < len(self._verses):
            self._cur_idx += 1
            self._refresh_current()
            self._refresh_queue()

    def _nav_prev(self):
        if self._recorder.is_recording:
            return
        if self._cur_idx > 0:
            self._cur_idx -= 1
            self._refresh_current()
            self._refresh_queue()

    def _on_queue_click(self, event):
        if getattr(self, '_syncing_q', False) or self._recorder.is_recording:
            return
        sel = self.queue_tv.selection()
        if not sel:
            return
        vid = int(sel[0])
        idx = next((i for i, v in enumerate(self._verses) if v[0] == vid), None)
        if idx is not None:
            self._cur_idx = idx
            self._refresh_current()
            self._refresh_queue()

    # ── 녹음 ─────────────────────────────────────────────────────────────────

    def _toggle_record(self):
        if not self._owner.get().strip():
            self._note(i18n.t('MSG_REGISTER_VOICENAME', "목소리 이름을 등록하세요."))
            self._new_ent.focus_set()
            return
        if not self._verses or self._cur_idx >= len(self._verses):
            return
        if self._recorder.is_recording:
            self._stop_record()
        else:
            self._start_record()

    # ── 연속 녹음 ────────────────────────────────────────────────────────────
    def _toggle_cont(self):
        if self._cont:
            self._cont_stop()
            return
        if not self._owner.get().strip():
            self._note(i18n.t('MSG_REGISTER_VOICENAME', "목소리 이름을 등록하세요."))
            self._new_ent.focus_set()
            return
        if not self._verses or self._cur_idx >= len(self._verses):
            return
        if self._recorder.is_recording:             # 낱개 녹음 중이면 그것부터 저장
            self._stop_record()
        self._start_record()
        if not self._recorder.is_recording:
            return
        self._cont = True
        self.btn_cont.config(text=i18n.t('VOICE_CONT_STOP', '■ 연속 녹음 중단'), bg="#5D6D7E")
        self.btn_next.pack(side="left", padx=3, after=self.btn_cont)
        self.btn_rec.config(state='disabled')

    def _cont_next(self):
        """지금 절을 저장하고 다음 절로 옮겨 곧바로 녹음을 시작한다 · 마지막 절이면 연속 녹음을 끝낸다."""
        if not self._cont:
            return
        if self._recorder.is_recording:
            self._stop_record()
        if self._cur_idx + 1 >= len(self._verses):
            self._cont_stop(done=True)
            return
        self._cur_idx += 1
        self._refresh_current()
        self._refresh_queue()
        self._start_record()
        if not self._recorder.is_recording:
            self._cont_stop()

    def _next_click(self):
        """[다음 절] — 녹음 중이면 이 절을 저장하고 다음 절을 곧바로 녹음한다(폰과 같다) · 아니면 옮기기만."""
        if self._recorder.is_recording:
            self._stop_record()
            if self._cur_idx + 1 >= len(self._verses):
                self.after(400, lambda: self.lbl_status.config(
                    text=i18n.t('VOICE_CONT_DONE', '마지막 절까지 녹음했습니다 — 연속 녹음을 마칩니다.'), fg="#27AE60"))
                return
            self._cur_idx += 1
            self._refresh_current()
            self._refresh_queue()
            self._start_record()
            return
        self._stop_preview()
        self._nav_next()

    def _stop_preview(self):
        if self._player.is_playing:
            self._player.stop()
        self.btn_preview.config(text=i18n.t('VOICE_LISTEN2', '▶ 들어보기'))

    def _cont_stop(self, done=False):
        if self._recorder.is_recording:
            self._stop_record()
        self._cont = False
        self.btn_cont.config(text=i18n.t('VOICE_CONT_START', '⏺ 연속 녹음'), bg="#922B21")
        self.btn_next.pack_forget()
        self.btn_rec.config(state='normal')
        if done:
            self.after(400, lambda: self.lbl_status.config(
                text=i18n.t('VOICE_CONT_DONE', '마지막 절까지 녹음했습니다 — 연속 녹음을 마칩니다.'), fg="#27AE60"))

    def _start_record(self):
        if self._show_preflight():
            return
        self._recorder.set_level_callback(self._update_meter)
        try:
            self._recorder.start()
        except Exception as e:                     # 마이크를 다른 프로그램이 쥐고 있거나 권한이 없다
            self._log('녹음 시작 실패', e)
            self.lbl_status.config(text=i18n.t('VOICE_PF_NOSTART', '마이크를 열지 못했습니다 — 다른 프로그램이 쓰고 있는지 확인해 주세요.'),
                                   fg="#E74C3C")
            return
        self.btn_rec.config(text=i18n.t('VOICE_RECSTOP2','■ 녹음 멈춤'), bg="#C0392B")
        self.lbl_ref.config(fg="#E74C3C")
        self.lbl_status.config(text=i18n.t('VOICE_RECORDING','● 녹음 중...'), fg="#E74C3C")

    def _stop_record(self):
        vid   = self._verses[self._cur_idx][0]
        owner = self._owner.get().strip()
        ver   = self._rec_ver.get() or self.version_getter()
        audio = self._recorder.stop()
        self.btn_rec.config(text=i18n.t('VOICE_REC2','⏺ 녹음'), bg="#922B21")
        self.lbl_ref.config(fg="#AED6F1")
        self._update_meter(0.0)
        if audio is None:
            self.lbl_status.config(text=i18n.t('VOICE_RECFAIL','녹음 실패'), fg="#E74C3C")
            return
        self._save_async(vid, owner, ver, audio)

    def _save_async(self, vid, owner, ver, audio):
        """저장은 일꾼 스레드에서 — 실패해도 **소리는 `_pending` 에 남는다**(다시 저장할 수 있다)."""
        self._pending = (vid, owner, ver, audio)
        self.btn_retry.pack_forget()
        self.lbl_status.config(text=i18n.t('VOICE_SAVING', '저장 중…'), fg="#F0B27A")
        m = voice_path(owner, ver, vid, self.db_path)

        def work():
            try:
                path, fmt = save_take(audio, m)
                save_voice_record(self.db_path, vid, owner, ver, str(path), fmt)
                self._uiq.put(('done', vid, fmt))
            except Exception as e:
                self._log('녹음 저장 실패', e)
                self._uiq.put(('fail', None, None))
        threading.Thread(target=work, daemon=True).start()

    def _poll_ui(self):
        try:                                       # 레벨 미터 — 화면 스레드에서 그린다(소리 스레드에서 그리면 앱이 꺼진다)
            if self._recorder.is_recording:
                self._update_meter(getattr(self._recorder, 'level', 0.0))
        except Exception:
            pass
        try:                                       # 들어보기가 끝나면 단추를 [들어보기]로
            if not self._player.is_playing and self.btn_preview.cget('text') != i18n.t('VOICE_LISTEN2', '▶ 들어보기'):
                self.btn_preview.config(text=i18n.t('VOICE_LISTEN2', '▶ 들어보기'))
        except Exception:
            pass
        try:
            while True:
                kind, vid, fmt = self._uiq.get_nowait()
                if kind == 'done':
                    self._on_record_done(vid, fmt)
                else:
                    self._on_save_fail()
        except Exception:
            pass
        try:
            if self.winfo_exists():
                self._poll_id = self.after(120, self._poll_ui)
        except Exception:
            pass

    def destroy(self):
        try:
            self.after_cancel(self._poll_id)
        except Exception:
            pass
        super().destroy()

    def _on_save_fail(self):
        self.lbl_status.config(text=i18n.t('VOICE_SAVE_FAIL', '저장하지 못했습니다 — 녹음은 남아 있습니다. [다시 저장]을 눌러 주세요.'),
                               fg="#E74C3C")
        self.btn_retry.pack(side="left", padx=3)
        self._show_preflight()

    def _retry_save(self):
        if self._pending:
            self._save_async(*self._pending)

    def _log(self, what, e):
        try:
            import errlog
            errlog.warn(what, e)
        except Exception:
            print('[voice] %s: %s' % (what, e))

    def _on_record_done(self, vid: int, fmt: str):
        self._pending = None
        self.btn_retry.pack_forget()
        self._recorded.add(vid)
        if self._recorder.is_recording:            # 연속 녹음 — 다음 절을 녹음하는 중이다
            self.lbl_status.config(text=i18n.t('VOICE_CONT_SAVED', '● 녹음 중 · 앞 절 저장됨(%s)') % fmt, fg="#E74C3C")
        else:
            self.lbl_status.config(text=f"✓ 저장({fmt})  ● 녹음 있음", fg="#27AE60")
        if self.queue_tv.exists(str(vid)):
            vals = list(self.queue_tv.item(str(vid), "values"))
            vals[0] = "⏺"
            tags = ("recorded", "current") if 'current' in self.queue_tv.item(str(vid), 'tags') else ("recorded",)
            self.queue_tv.item(str(vid), values=vals, tags=tags)

    def _update_meter(self, level: float):
        w = int(200 * level)
        self._meter_canvas.itemconfig(
            self._meter_bar, fill="#27AE60" if level < 0.7 else "#E74C3C")
        self._meter_canvas.coords(self._meter_bar, 0, 0, w, 14)

    # ── 현재 구절 미리 듣기 ───────────────────────────────────────────────────

    def _preview_current(self):
        if self._recorder.is_recording or not self._verses:
            return
        if self._player.is_playing:                 # 들어보는 중이면 [멈춤]
            self._stop_preview()
            return
        if self._cur_idx >= len(self._verses):
            return
        vid   = self._verses[self._cur_idx][0]
        owner = self._owner.get()
        ver   = self._rec_ver.get() or self.version_getter()
        p = existing_file(owner, ver, vid, self.db_path)      # mp3 · wav · 폰에서 온 Opus(.ogg)
        if p is not None:
            self._player.stop()
            self.btn_preview.config(text=i18n.t('VOICE_PSTOP2', '■ 멈춤'))
            self._player.play_sequence([(vid, p)])        # 끝나면 _poll_ui 가 단추를 되돌린다(소리 스레드에서 Tk 금지)
            self.lbl_status.config(text=i18n.t('VOICE_PLAYING','▶ 재생 중...'), fg="#AED6F1")
            return
        if get_voice_record(self.db_path, vid, owner, ver):
            # ★ 87 — 녹음은 했는데 이 PC 에 파일이 없다(폰에만 있거나 지웠다) — 진척은 그대로
            self.lbl_status.config(text=i18n.t('VOICE_NOFILE2', '녹음함 · 이 PC 에는 파일이 없습니다(폰에 있거나 지움)'),
                                   fg="#F0B27A")
            return
        self.lbl_status.config(text=i18n.t('VOICE_NOFILE','녹음 파일 없음'), fg="#E74C3C")

    def _delete_recording(self):
        if not self._verses or self._cur_idx >= len(self._verses):
            return
        vid   = self._verses[self._cur_idx][0]
        owner = self._owner.get()
        ver   = self._rec_ver.get() or self.version_getter()
        if not messagebox.askyesno(i18n.t('MSG_T_DELCONFIRM', "삭제 확인"), i18n.t('MSG_DELETE_REC_Q', "절 {vid} 녹음을 삭제하겠습니까?").format(vid=vid)):
            return
        # ★ 87 — 파일만 지우고 진척(녹음 기록)은 남긴다(사용자 「삭제하더라도 녹음 진척도를 기억」).
        #   다시 녹음하면 같은 줄을 새 파일로 덮는다. 진척에서 빼는 것은 녹음 관리 ▸ 무결성 검사의 [기록 지우기].
        for p in (voice_path(owner, ver, vid, self.db_path),
                  wav_path(owner, ver, vid, self.db_path),
                  voice_path(owner, ver, vid, self.db_path).with_suffix('.ogg')):
            try: p.unlink(missing_ok=True)
            except Exception: pass
        forget_file(self.db_path, vid, owner, ver)
        self._recorded.discard(vid)                  # ★ 표식도 그 자리에서 걷는다(2026-10-28)
        self._refresh_queue()
        self.lbl_status.config(text=i18n.t('VOICE_DELETED','삭제됨'), fg="#E74C3C")

    # ── 복귀 ─────────────────────────────────────────────────────────────────

    def _restore(self):
        if self._recorder.is_recording:
            self._recorder.cancel()
        self._player.stop()
        self._env_frame.cleanup()
        self.place_forget()
        if self.on_restore:
            self.on_restore()
