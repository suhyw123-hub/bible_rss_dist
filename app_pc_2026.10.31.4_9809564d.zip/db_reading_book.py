# -*- coding: utf-8 -*-
"""성경듣기 — **책 단위 낭독을 그 책 전체 구간으로 잇는다** (2026-09-10 신설).

사용자 요구(0.txt 2-3-1): 「책 선택 … 모세오경, 역사서, 복음서, 서신서 등을
한눈에 볼 수 있도록 바둑판처럼 배치. 책을 선택하면 여러 컨텐츠의 썸네일 표시」.

★★★ **왜 따로 읽나** — `db_media_range.read` 는 **장·절 표기**를 찾는다
  (「창1:1」·「창세기 6-10장」). 그런데 책 단위 낭독 제목에는 **장절이 없다**:
  「로마서 전체낭독」·「요한복음 전체듣기」·「Audio Bible - Genesis」.
  실측 402편 중 그 문으로 읽힌 것 **148편(37%)** 뿐이었다.

★ 이어 붙이는 것은 **새 갈래가 아니라 이미 있는 구간 링크**(`MEDI_VERS`)다 —
  그 책의 첫 절 ~ 끝 절. 화면은 `verse_range` 로 책을 묻는다.
  ⚠ 새 scope 를 만들지 않는다(`sys_media_link.scope` 는 ENTITY·PERICOPE 뿐이고
    구간은 VERSE 하나로 충분하다).

⚠⚠ **책 이름만으로 잡는 것은 위험하다** — 「요한」이 「요한계시록」·「요한일서」·
  사람 이름과 겹친다. ⇒ **정식 이름(full_name)만** 보고, 긴 이름을 먼저 잡아
  자리를 소비하며, 앞뒤에 한글이 붙으면 거른다(§228차 낱말 경계 규칙).
⚠ **장절 표기가 있으면 이 문을 쓰지 않는다** — 그것은 `db_media_range` 몫이다
  (「창세기 6-10장」을 책 전체로 걸면 안 된다).
"""
import re
import sys

import appdb

DB = 'bible_master.db'
MARK = 'READING_BOOK'

#: 책 묶음 — 바둑판 배치의 칸(사용자 「모세오경, 역사서, 복음서, 서신서 등」).
#:   ⚠ 이름은 화면이 i18n 으로 짓는다 — 여기는 **어느 책이 어느 묶음인가**만.
GROUPS = [
    ('PENT',    '모세오경',   range(1, 6)),
    ('HIST',    '역사서',     range(6, 18)),
    ('POET',    '시가서',     range(18, 23)),
    ('MAJOR',   '대선지서',   range(23, 28)),
    ('MINOR',   '소선지서',   range(28, 40)),
    ('GOSPEL',  '복음서',     range(40, 44)),
    ('ACTS',    '사도행전',   range(44, 45)),
    ('PAUL',    '바울서신',   range(45, 59)),
    ('GENERAL', '일반서신',   range(59, 66)),
    ('REV',     '요한계시록', range(66, 67)),
]

#: 「책 전체」를 뜻하는 말 — 이것이 함께 있어야 책 전체로 건다.
#:   ⚠ 없으면 「로마서 8장 강해」 같은 것도 책 전체가 된다.
WHOLE = [
    '전체', '전권', '통독', '몰아', '전부', '다 듣', '완독',
    'full', 'complete', 'entire', 'whole', 'all chapters',
    '全部', '全书', '全書', '通读', '通讀', '全巻', '全巻',
    'completo', 'completa', 'integral', 'ganze', 'entier', 'полн',
]

_HANGUL = re.compile(r'[가-힣]')


def _book_range(conn):
    """{bcode: (첫 vid, 끝 vid)} — 책 전체 구간."""
    return {r[0]: (r[1], r[2]) for r in conn.execute(
        "SELECT bcode, MIN(verse_id), MAX(verse_id) FROM bible_index"
        " GROUP BY bcode")}


def _names(conn):
    """[(정식 이름, bcode)] — 긴 것부터. 모든 언어."""
    out = []
    for bc, nm in conn.execute(
            "SELECT book_code, full_name FROM book_names"
            " WHERE full_name IS NOT NULL AND LENGTH(full_name)>=3"):
        out.append((nm, bc))
    return sorted(out, key=lambda x: -len(x[0]))


def _whole(title):
    low = (title or '').lower()
    return any(w.lower() in low for w in WHOLE)


def find_book(title, names):
    """제목에서 **책 하나**를 읽는다 → (bcode, 걸린 이름) 또는 None.

    ⚠ **긴 이름이 먼저** — 「요한계시록」이 「요한」보다 먼저 잡혀야 한다.
    ⚠ 한글 이름 뒤에 한글이 더 붙으면 거른다(「마태복음적」 같은 조어).
    ⚠ **책이 여럿 걸리면 안 건다** — 「창세기~요한계시록 통독」은 한 책이 아니다.
    """
    t = title or ''
    low = t.lower()
    hit = {}
    taken = []
    for nm, bc in names:
        n = nm.lower()
        i = low.find(n)
        while i >= 0:
            if any(a <= i < b or a < i + len(n) <= b for a, b in taken):
                i = low.find(n, i + 1)
                continue
            nxt = t[i + len(n):i + len(n) + 1]
            if _HANGUL.search(nm) and nxt and _HANGUL.match(nxt):
                i = low.find(n, i + 1)
                continue
            if not _HANGUL.search(nm):
                pre = t[i - 1:i]
                if (pre and pre.isalnum()) or (nxt and nxt.isalnum()):
                    i = low.find(n, i + 1)
                    continue
            taken.append((i, i + len(n)))
            hit.setdefault(bc, nm)
            break
    if len(hit) != 1:
        return None
    bc = next(iter(hit))
    return (bc, hit[bc])


def run(conn, apply_it=False, log=print):
    """성경듣기 영상에 **책 전체 구간**을 건다 → 요약 dict."""
    import db_media_range as MR
    import media_link
    MR.init(conn)
    names = _names(conn)
    rng = _book_range(conn)
    ty = media_link.lt('VERSE')
    out = {'seen': 0, 'has_range': 0, 'chapter_level': 0, 'linked': 0,
           'no_book': 0, 'multi': 0}
    for mid, ti, d in conn.execute(
            "SELECT media_id, title, COALESCE(description,'') FROM sys_media_asset"
            " WHERE record_status='LIVE' AND media_type='READING'"
            "   AND title IS NOT NULL").fetchall():
        out['seen'] += 1
        # ⚠ 이미 구간이 걸려 있으면 안 건드린다(장·절 표기가 더 정확하다)
        if conn.execute("SELECT 1 FROM %s WHERE link_type=? AND clicked_id=?"
                        % media_link.TBL, (ty, mid)).fetchone():  # status-ok: 이미 구간이 걸렸나 보는 자리 — **사람이 걷은 것도 걸린 적이 있는 것**이라 도로 안 건다
            out['has_range'] += 1
            continue
        # ⚠ 장·절 표기가 있으면 그쪽이 맡는다
        if MR.read(conn, ti):
            out['chapter_level'] += 1
            continue
        got = find_book(ti, names)
        if not got:
            out['no_book'] += 1
            continue
        if not _whole(ti):
            out['multi'] += 1
            continue
        bc, nm = got
        se = rng.get(bc)
        if not se:
            continue
        out['linked'] += 1
        if apply_it:
            conn.execute(
                "INSERT INTO %s (link_type, clicked_id, target_id, end_id,"
                " record_status, confidence) VALUES (?,?,?,?,'LIVE','AUTO')"
                % media_link.TBL, (ty, mid, se[0], se[1]))
    if apply_it:
        conn.commit()
    log('  성경듣기 %d편 — 이미 구간 있음 %d · 장절 표기 %d · 책을 못 읽음 %d'
        % (out['seen'], out['has_range'], out['chapter_level'], out['no_book']))
    log('  %s **책 전체로 이은 것 %d편** (「전체·통독」 같은 말이 없어 건너뜀 %d)'
        % ('' if apply_it else '(미리보기)', out['linked'], out['multi']))
    return out


def books_with_reading(conn):
    """{bcode: 편 수} — 그 책의 성경듣기 영상이 몇 편인가(바둑판이 쓴다).

    ⚠ **승인된 것만** 센다(§194차 승인=연결).
    """
    import media_link
    import verse_range as VR
    ty = media_link.lt('VERSE')
    out = {}
    rng = _book_range(conn)
    for bc, (s, e) in rng.items():
        n = conn.execute(
            "SELECT COUNT(DISTINCT l.clicked_id) FROM %s l"
            "  JOIN sys_media_asset a ON a.media_id=l.clicked_id"
            " WHERE l.link_type=? AND a.record_status='LIVE'"
            "   AND a.media_type='READING' AND a.is_active=1"
            "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
            "   AND %s" % (media_link.TBL, VR.overlaps_sql('l', 'target_id',
                                                           'end_id')),
            (ty,) + tuple(VR.overlaps_args(s, e))).fetchone()[0]
        if n:
            out[bc] = n
    return out


def _mt_cond(media_type):
    """유형 하나든 여럿이든 받는다 → (SQL 조각, 인자).

    ★ 2026-09-17 — 화면 갈래 「말씀」이 `('SERMON','STUDY')` 둘을 덮으므로
      한 값만 받던 옛 꼴로는 못 센다(사용자 「유형을 통합해야 한다」).
    ⚠ 비면 **안 거른다** — 「전체」 갈래의 뜻이다.
    """
    if not media_type:
        return '', []
    ts = [media_type] if isinstance(media_type, str) else list(media_type)
    if not ts:
        return '', []
    return (" AND a.media_type IN (%s)" % ','.join('?' * len(ts))), ts


def books_with_media(conn, media_type):
    """{bcode: 편 수} — 그 **유형**(SERMON·STUDY·READING…) 영상이 책마다 몇 편인가.

    ★ **한 조회로 센다**(2026-09-17) — 책마다 물으면 66번이고, 온라인 영상 화면의
      왼쪽 책 트리가 갈래를 바꿀 때마다 그것을 돈다(실측 한 조회 0.04초).
    ★ 연결의 **시작 절이 있는 책**으로 센다 — 구간이 책을 넘는 일은 드물고,
      넘더라도 그 영상은 시작한 책에 있는 것이 사람이 찾는 자리다.
    ⚠ **승인된 것만**(§194차 승인=연결) · 살아 있는 연결만.
    """
    import media_link
    _c, _a = _mt_cond(media_type)
    rows = conn.execute(
        "SELECT bi.bcode, COUNT(DISTINCT l.clicked_id) FROM " + media_link.TBL + " l"
        "  JOIN sys_media_asset a ON a.media_id=l.clicked_id"
        "  JOIN bible_index bi ON bi.verse_id=l.target_id"
        " WHERE l.link_type=? AND a.is_active=1"
        "   AND a.record_status='LIVE'"
        "   AND COALESCE(l.record_status,'LIVE')='LIVE'" + _c
        + " GROUP BY bi.bcode", [media_link.lt('VERSE')] + _a).fetchall()
    return {int(b): int(n) for b, n in rows if n}


def chapters_with_media(conn, media_type, bcode):
    """[(장, 편 수)] — 한 책 안에서 장마다. **책을 펼 때** 그때 센다."""
    import media_link
    _c, _a = _mt_cond(media_type)
    return [(int(c), int(n)) for c, n in conn.execute(
        "SELECT bi.chapter, COUNT(DISTINCT l.clicked_id) FROM " + media_link.TBL + " l"
        "  JOIN sys_media_asset a ON a.media_id=l.clicked_id"
        "  JOIN bible_index bi ON bi.verse_id=l.target_id"
        " WHERE l.link_type=? AND bi.bcode=?"
        "   AND a.is_active=1 AND a.record_status='LIVE'"
        "   AND COALESCE(l.record_status,'LIVE')='LIVE'" + _c
        + " GROUP BY bi.chapter ORDER BY bi.chapter",
        [media_link.lt('VERSE'), int(bcode)] + _a).fetchall() if n]


def media_of_book(conn, bcode, limit=60, hide=None):
    """그 책의 성경듣기 영상 [(media_id, 제목, url, 썸네일)].

    ⚠ `hide` = `media_pref.load(...)` — 주면 **사용자가 숨긴 것을 뺀다**.
      화면이 sys 표를 그리면서 가림을 안 보면 「숨겼는데 그대로 뜬다」가 난다
      (§226차). 안 주면 관리·집계용이라 그대로 낸다.
    """
    import json
    import media_link
    import verse_range as VR
    s, e = _book_range(conn).get(int(bcode), (None, None))
    if not s:
        return []
    rows = conn.execute(
        "SELECT DISTINCT a.media_id, a.title, a.url, COALESCE(a.description,'')"
        "  FROM %s l JOIN sys_media_asset a ON a.media_id=l.clicked_id"
        " WHERE l.link_type=? AND a.record_status='LIVE'"
        "   AND a.media_type='READING' AND a.is_active=1"
        "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
        "   AND %s LIMIT ?" % (media_link.TBL,
                               VR.overlaps_sql('l', 'target_id', 'end_id')),
        (media_link.lt('VERSE'),) + tuple(VR.overlaps_args(s, e))
        + (int(limit),)).fetchall()
    out = []
    for mid, ti, url, d in rows:
        if hide is not None:
            try:
                if hide.hidden(mid, d):
                    continue
            except Exception:
                pass
        th = ''
        if d.startswith('{'):
            try:
                th = json.loads(d).get('thumbnail') or ''
            except Exception:
                th = ''
        # ⚠ 담아 둔 것이 없으면 **영상 주소에서 만든다**(쿼터 0 · 옛 행도 산다)
        th = th or media_link.thumb_url(url)
        out.append((mid, ti or '', url or '', th))
    return out


def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    N = [('요한계시록', 66), ('요한복음', 43), ('요한일서', 62), ('로마서', 45),
         ('창세기', 1), ('Genesis', 1), ('Revelation', 66)]
    N = sorted(N, key=lambda x: -len(x[0]))
    t('★★★ 긴 이름이 먼저 — 「요한계시록」이 「요한복음」을 안 먹는다',
      find_book('요한계시록 전체낭독', N) == (66, '요한계시록'))
    t('★★ 「로마서 전체낭독」을 읽는다',
      find_book('[개역한글][성경낭독] 로마서 전체낭독 / 김소정', N) == (45, '로마서'))
    t('★★★ **책이 여럿이면 안 건다**',
      find_book('창세기부터 요한계시록까지 통독', N) is None)
    t('★★ 라틴 이름은 낱말 경계로만',
      find_book('Audio Bible - Genesis', N) == (1, 'Genesis')
      and find_book('Genesises', N) is None)
    t('★ 안 걸리면 None', find_book('오늘의 묵상', N) is None)
    t('★★★ **「전체·통독」 같은 말이 있어야 책 전체로 본다**',
      _whole('로마서 전체낭독') and _whole('Genesis complete')
      and not _whole('로마서 8장 강해'))
    t('★ 책 묶음이 66권을 빠짐없이 덮는다',
      sorted(b for _c, _k, r in GROUPS for b in r) == list(range(1, 67)))
    t('★ 묶음이 겹치지 않는다',
      len([b for _c, _k, r in GROUPS for b in r]) == 66)
    try:
        c = appdb.connect(DB)
        rng = _book_range(c)
        t('★ 실 DB — 66권 구간을 읽는다', len(rng) == 66, len(rng))
        got = run(c, apply_it=False, log=lambda s: None)
        t('★★ 실 DB — 이을 것이 있다', got['linked'] >= 0, got)
        t('★ 바둑판 조회가 돈다', isinstance(books_with_reading(c), dict))
        c.close()
    except Exception as e:
        t('★ 실 DB 탐침', False, repr(e))
    print('db_reading_book selftest %d/%d' % (ok[0], ok[1]))
    return 0 if ok[0] == ok[1] else 1


def main(argv):
    if '--selftest' in argv:
        return selftest()
    conn = appdb.connect(DB)
    try:
        if '--books' in argv:
            got = books_with_reading(conn)
            nm = dict(conn.execute("SELECT book_code, short_name FROM book_names"
                                   " WHERE UPPER(lang_code)='KO'").fetchall())
            for code, ko, rr in GROUPS:
                line = ['%s:' % ko]
                for b in rr:
                    if got.get(b):
                        line.append('%s %d' % (nm.get(b, b), got[b]))
                if len(line) > 1:
                    print('  ' + ' · '.join(line))
            print('  책 %d권에 성경듣기가 있다' % len(got))
            return 0
        run(conn, apply_it=('--apply' in argv))
        if '--apply' not in argv:
            print('  (미리보기입니다 — 실제로 걸려면 --apply)')
    finally:
        conn.close()
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
