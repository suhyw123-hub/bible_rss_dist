# -*- coding: utf-8 -*-
"""room_core.py — 공동체 묵상 2단계 · 방 열기·참여·이름 (영구, 2026-09-08).

설계 = `정책자료/0.교회묵상.txt` §5-1 · §6-0 · §8 2단계.
1단계(`share_pack.py`)가 **나눌 파일**을 만들었고, 여기서 **누구와 나누는가**를 담는다.

★★★ **이 파일이 「방」의 단일 소스다.** 화면은 여기만 부른다 —
  표 이름·초대 파일 형식·유형 목록을 화면에 적으면 두 벌이 되어 갈린다.

무엇이 되는가 (2단계 범위):
  · 방을 연다(자동승인 — 기다림 0) · 초대 파일을 만든다
  · 초대 파일로 참여한다 · **이 방에서 쓸 이름**을 정한다
  · 나간다(HIDE — 지우지 않는다)
  · 이용통계에 실을 한 줄을 낸다(유형·인원·역할만)

아직 안 하는 것 (3단계 이후):
  ⚠ **나눔글을 주고받지 않는다** — `room_<방>.db` 와 작성자 칸은 3단계다.
    사용자가 1·2단계를 실제로 써 본 뒤에 정한다(§8 「되돌리기 어려운 변경」).

★★ **`SUPPORT_UUID` 를 그대로 쓴다** — 새 신원을 만들지 않는다.
  그래서 참여자가 만들 것은 **이름 한 줄뿐**이다(회원가입·비밀번호·메일 없음).

사용:  python room_core.py --selftest | --list
"""
import io
import json
import os
import sys
import uuid as _uuid
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

APP_MARK = 'hagah-room'      #: 초대 파일 표식 — `share_pack`·`lens_share` 와 같은 문법
FMT = 1
KIND_INVITE = 'ROOM_INVITE'
EXT = '.hagah'

#: ★★★ **공동체 유형 — 단일 소스.** (코드, i18n 열쇠, 기수 기본값)
#: ⚠ **유형은 꼬리표이고 기수는 별도 스위치다**(§6-0). 유형은 **기본값만**
#:   준다 — 교회인데 기수를 안 쓸 수도 있고(구역), 친구 방인데 시즌을 나눌
#:   수도 있다. 유형에 기능을 묶으면 「교회가 아니면 기수를 못 쓴다」가 된다.
#: ⚠ **「그 밖」을 반드시 둔다** — 억지로 밀어 넣게 하면 통계가 더러워진다.
COMMUNITY_TYPES = (
    ('CHURCH_TR', 'ROOMTYPE_CHURCH_TR', True),   # 교회 · 훈련
    ('CHURCH_GR', 'ROOMTYPE_CHURCH_GR', False),  # 교회 · 소그룹
    ('FAMILY',    'ROOMTYPE_FAMILY',    False),  # 가정 — 「할아버지랑 말씀 읽기」
    ('FRIEND',    'ROOMTYPE_FRIEND',    False),  # 친구 · 또래
    ('MISSION',   'ROOMTYPE_MISSION',   True),   # 선교단체 · 기관
    ('SCHOOL',    'ROOMTYPE_SCHOOL',    True),   # 학교 · 교육기관
    ('ETC',       'ROOMTYPE_ETC',       False),  # 그 밖
)
TYPE_CODES = tuple(t[0] for t in COMMUNITY_TYPES)
#: 코드 → 기수 기본값
TYPE_COHORT = {t[0]: t[2] for t in COMMUNITY_TYPES}

ROLE_LEADER = 'LEADER'
ROLE_MEMBER = 'MEMBER'
#: ★★★ **부방장**(2026-09-08 사용자 확정 — 「방장위임은 필요 없고 방장 이외에
#:   부방장이 필요하다. 중요하다」). 방장이 지정한다(`set_co_leader`) · 방장
#:   파일이 목록을 나르고 받는 쪽이 제 역할을 바꾼다.
#:   할 수 있는 것 = 공지 · 지침·마무리 글 · 참가자 현황 · 가리기 · 방 마무리.
#:   방장만 = 이름 바꾸기 · 폴더 · 플랜·시작일 · 부방장 지정 · 방 지우기.
ROLE_CO = 'CO_LEADER'
MANAGER_ROLES = (ROLE_LEADER, ROLE_CO)

def _pfx(conn):
    """표 접두 — **연결에 따라 다르다.**

    ⚠⚠ `appdb.connect()` 는 `user_data.db` 를 **`userdb` 로 ATTACH** 하지만,
      그 파일을 **직접 여는 모듈**(`usage_stats._conn`)도 있다. 그때는
      `userdb` 스키마가 없어 `unknown database userdb` 로 터지는데
      `except: pass` 가 삼켜 **통계 줄이 조용히 빠졌다**(실측으로 잡았다).
    ⇒ **붙어 있는 스키마를 물어보고 정한다.** 짐작하지 않는다.
    """
    try:
        for r in conn.execute('PRAGMA database_list'):
            if r[1] == 'userdb':
                return 'userdb.'
    except Exception:
        pass
    return ''


_SCHEMA = """
CREATE TABLE IF NOT EXISTS %suser_room (
    room_id        TEXT PRIMARY KEY,
    room_name      TEXT NOT NULL,
    room_type      TEXT NOT NULL,
    leader_name    TEXT,
    leader_contact TEXT,
    folder_a       TEXT,
    folder_b       TEXT,
    my_name        TEXT,
    leader_uuid    TEXT,
    my_role        TEXT NOT NULL DEFAULT 'MEMBER',
    my_cohort      TEXT,
    use_cohort     INTEGER NOT NULL DEFAULT 0,
    plan_code      TEXT,
    room_status    TEXT,
    closed_at      TEXT,
    plan_start     TEXT,
    co_leaders     TEXT,
    status_at      TEXT,
    members        INTEGER NOT NULL DEFAULT 1,
    terms_at       TEXT,
    joined_at      TEXT,
    last_sync      TEXT,
    reported_at    TEXT,
    record_status  TEXT NOT NULL DEFAULT 'LIVE'
)
"""


def _now():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def ensure(conn):
    """표를 만든다 — **멱등**. 부르는 문마다 앞에서 부른다."""
    pfx = _pfx(conn)
    conn.execute(_SCHEMA % pfx)
    # ⚠ 옛 판에는 `leader_uuid` 가 없다 — 있는 방을 안 깨뜨리고 칸만 더한다.
    #   ★ 없으면 **공지를 안 받는다**(아래 `room_share.apply_notes`) — 아무나
    #     공지를 올리는 것보다 아무 공지도 안 뜨는 쪽이 안전하다.
    try:
        have = {r[1] for r in conn.execute("PRAGMA %stable_info(user_room)"
                                           % pfx)}
    except Exception:
        have = set()
    if have and 'leader_uuid' not in have:
        conn.execute("ALTER TABLE %suser_room ADD COLUMN leader_uuid TEXT" % pfx)
        conn.commit()
    # ★★★ **방이 플랜을 정한다**(2026-09-08 사용자 확정 — 「묵상플랜을
    #   교회관리자가 특정한다 … 이 플랜이 방 내부에 공유된다」). 방장이 정하고
    #   참여자는 방장 파일에서 받아 적는다(`adopt_leader_meta`).
    if have and 'plan_code' not in have:
        conn.execute("ALTER TABLE %suser_room ADD COLUMN plan_code TEXT" % pfx)
        conn.commit()
    # ★ 5단계 — 방 마무리(수료 처리). `room_status` OPEN|CLOSED · `closed_at`.
    # ★ 시작일(모두 같은 날 시작 — 사용자 확정) · 부방장 목록(JSON)
    # ★ `status_at` — 마무리/다시 열기 결정의 시각. 운영자 둘의 파일이 다투면
    #   **새 결정**이 이긴다(종단 시험이 잡았다 — 부방장의 옛 파일이 방을 되열었다).
    for col in ('room_status', 'closed_at', 'plan_start', 'co_leaders', 'status_at'):
        if have and col not in have:
            conn.execute("ALTER TABLE %suser_room ADD COLUMN %s TEXT" % (pfx, col))
            conn.commit()
    return conn


def my_uuid(conn):
    """내 익명 번호 — **문의 통로와 같은 것**(새로 만들지 않는다)."""
    import user_feedback as UF
    return UF.get_uuid(conn)


def _my_uuid_safe(conn):
    """번호를 못 만들어도 **방은 열린다**.

    ⚠ 방 열기가 번호 하나 때문에 막히면 안 된다. 못 담으면 공지만 못 쓰고
      (`can_notice` 가 그 사실을 말한다) 나머지는 그대로 돈다.
    """
    try:
        return my_uuid(conn) or ''
    except Exception:
        return ''


def can_notice(conn, room_id):
    """공지를 올릴 수 있나 → `(된다, 사유)`.

    ★★★ 2026-09-08 사용자 확정 「**방 내부의 공지사항은 방장만 올릴 수 있다**」.
    ⚠ **왜 안 되는지 말한다**(§0-1) — `NOT_LEADER`(방장이 아니다) ·
      `NO_UUID`(옛 방이라 방장 번호가 없다 — 초대장을 새로 만들면 채워진다).
    """
    r = room(conn, room_id)
    if not r:
        return False, 'NO_ROOM'
    if r.get('my_role') not in MANAGER_ROLES:
        return False, 'NOT_LEADER'
    if not (r.get('leader_uuid') or '').strip():
        return False, 'NO_UUID'
    return True, ''


# ── 방 열기 ──────────────────────────────────────────────────────────
def create_room(conn, name, rtype, leader_name, contact='', terms_ok=False,
                folder_a='', folder_b='', use_cohort=None, cohort=''):
    """방을 연다 → `room_id`.

    ★★★ **자동승인 — 기다림 0**(2026-09-08 사용자 확정 「처음부터 자동승인
      한다」). 앱이 스스로 번호를 만들고 곧바로 연다. **승인이 아니라 신고다.**
      ⚠ 그래서 **서명 증서가 없다** — 아무나 받는 증서에 서명은 뜻이 없다.
        심사제로 갈 날을 위해 자리(`cert`)만 비워 둔다.

    ⚠ **책임 선언에 동의하지 않으면 안 열린다**(`terms_ok`) — 화면이 아니라
      여기서 막는다. 입구가 늘어도 안 샌다(§97차 유령 연결과 같은 규칙).
    ⚠ **연락처는 방장만** 적는다 — 참여자는 안 적는다(§6-0 개인정보).
    """
    ensure(conn)
    name = (name or '').strip()
    if not name:
        raise ValueError('EMPTY_NAME')
    rtype = (rtype or '').strip().upper()
    if rtype not in TYPE_CODES:
        raise ValueError('BAD_TYPE:%s' % rtype)
    if not terms_ok:
        # ⚠ 동의 없이 여는 길을 두지 않는다 — 책임 선언이 이 설계의 뿌리다.
        raise ValueError('TERMS_REQUIRED')
    lead = (leader_name or '').strip()
    if not lead:
        raise ValueError('EMPTY_LEADER')
    rid = _uuid.uuid4().hex
    if use_cohort is None:
        use_cohort = TYPE_COHORT.get(rtype, False)
    conn.execute(
        ("INSERT INTO %suser_room(room_id,room_name,room_type,leader_name,"
         "leader_contact,folder_a,folder_b,my_name,leader_uuid,my_role,"
         "my_cohort,use_cohort,"
         "members,terms_at,joined_at,record_status) "
         "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'LIVE')") % _pfx(conn),
        (rid, name, rtype, lead, (contact or '').strip(),
         (folder_a or '').strip(), (folder_b or '').strip(),
         lead, _my_uuid_safe(conn), ROLE_LEADER, (cohort or '').strip(),
         1 if use_cohort else 0, 1, _now(), _now()))
    conn.commit()
    return rid


# ── 초대 파일 ────────────────────────────────────────────────────────
def invite_body(conn, room_id, note=''):
    """초대 파일에 담을 내용 → dict.

    ⚠ **비밀이 안 들어간다** — 폴더 주소가 곧 열쇠다(§5-4). 그래서 초대
      파일이 새면 그 방이 열린다. 완화는 폴더 링크를 갈아 끼우는 것이다.
    ⚠ **연락처는 안 싣는다** — 방장의 개인정보이고 참여자에게 보일 것이 아니다.
    """
    ensure(conn)
    r = conn.execute(
        ("SELECT room_id,room_name,room_type,leader_name,folder_a,folder_b,"
         "my_cohort,use_cohort,leader_uuid,plan_code,plan_start,co_leaders "
         "FROM %suser_room WHERE room_id=?")
        % _pfx(conn),
        (room_id,)).fetchone()
    if not r:
        raise ValueError('NO_ROOM')
    # ★★★ **폴더는 하나다**(2026-09-08 사용자 확정 — 「구글드라이브 하나만
    #   유지하는 방식으로 하자」). 옛 두 칸(`folder_a`·`folder_b`)은 남겨 두되
    #   **같은 값**을 넣고, 초대 파일은 `folder` 하나로 말한다. 옛 초대 파일
    #   (`folder_a`/`folder_b`)도 그대로 읽힌다(`join_room`).
    fold = (r[5] or r[4] or '').strip()
    return {
        'app': APP_MARK, 'fmt': FMT, 'kind': KIND_INVITE,
        'room_id': r[0], 'room': r[1], 'type': r[2], 'leader': r[3],
        'folder': fold, 'folder_a': fold, 'folder_b': fold,
        'plan_code': r[9] or '', 'plan_start': r[10] or '',
        'co_leaders': _co_list(r[11]),
        'cohort': r[6] or '', 'use_cohort': int(r[7] or 0),
        # ★★★ **방장 번호를 싣는다** — 받는 쪽이 「이 공지가 방장의 것인가」를
        #   가리는 유일한 근거다(2026-09-08 사용자 「방 내부의 공지사항은
        #   방장만 올릴 수 있다」).
        #   ⚠ **자물쇠가 아니라 문패다** — 파일을 손으로 고치면 우회된다.
        #     그래도 실수로 남의 글이 공지가 되는 것은 막는다(§208차 ③).
        #   ⚠ **연락처와 다르다** — 번호는 익명 uuid 라 개인정보가 아니다.
        'leader_uuid': r[8] or '',
        'made_at': _now()[:10], 'note': (note or '').strip(),
    }


def write_invite(conn, room_id, path, note=''):
    """초대 파일을 쓴다 → 경로. 확장자는 `.hagah`."""
    body = invite_body(conn, room_id, note)
    if not path.lower().endswith(EXT):
        path += EXT
    with io.open(path, 'w', encoding='utf-8') as f:
        json.dump(body, f, ensure_ascii=False, indent=1)
    return path


def read_invite(path):
    """초대 파일을 읽는다 → dict. **무엇이 잘못됐는지 말한다**(§0-1).

    ⚠ 파일이 무엇인지 **파일에게 물어본다**(§0-1b 규칙 ③) — 확장자를 믿지 않는다.
    """
    with io.open(path, encoding='utf-8') as f:
        d = json.load(f)
    if not isinstance(d, dict):
        raise ValueError('NOT_INVITE')
    if d.get('app') != APP_MARK or d.get('kind') != KIND_INVITE:
        # ★ 묶음 파일(`share_pack`)을 여기에 넣었을 때 그 사실을 말한다.
        if d.get('app') == 'hagah-share':
            raise ValueError('IS_SHARE_PACK')
        raise ValueError('NOT_INVITE')
    if int(d.get('fmt') or 0) > FMT:
        raise ValueError('NEWER_FMT:%s' % d.get('fmt'))
    if not d.get('room_id') or not d.get('room'):
        raise ValueError('BROKEN')
    if (d.get('type') or '') not in TYPE_CODES:
        d['type'] = 'ETC'      # ⚠ 모르는 유형은 「그 밖」으로 — 거부하지 않는다
    return d


def join_room(conn, invite, my_name=''):
    """초대 파일로 참여한다 → (`room_id`, 새로 들어갔나).

    ⚠ **이미 참여한 방이면 안 늘린다 — 되살린다**(멱등). 나갔다 다시 들어오는
      것이 흔하고, 그때 방이 두 줄이 되면 어느 것이 진짜인지 모른다.
    ⚠ **내 이름은 안 덮는다** — 다시 참여해도 쓰던 이름이 남는다.
    """
    ensure(conn)
    rid = invite['room_id']
    cur = conn.execute(("SELECT my_name, record_status FROM %suser_room "
                        "WHERE room_id=?") % _pfx(conn), (rid,)).fetchone()
    nm = (my_name or '').strip()
    # ★ 폴더 하나 — 새 초대(`folder`)든 옛 초대(`folder_b`/`folder_a`)든 읽는다.
    fold = (invite.get('folder') or invite.get('folder_b')
            or invite.get('folder_a') or '').strip()
    pc = (invite.get('plan_code') or '').strip()
    ps = (invite.get('plan_start') or '').strip()
    cos = [str(x) for x in (invite.get('co_leaders') or []) if x]
    me = _my_uuid_safe(conn)
    role = ROLE_CO if (me and me in cos) else ROLE_MEMBER
    if cur:
        conn.execute(
            ("UPDATE %suser_room SET room_name=?, room_type=?, leader_name=?,"
             " folder_a=?, folder_b=?, my_name=COALESCE(NULLIF(?,''), my_name),"
             " leader_uuid=COALESCE(NULLIF(?,''), leader_uuid),"
             " plan_code=COALESCE(NULLIF(?,''), plan_code),"
             " plan_start=COALESCE(NULLIF(?,''), plan_start), co_leaders=?,"
             " my_role=CASE WHEN my_role=? THEN my_role ELSE ? END,"
             " record_status='LIVE' WHERE room_id=?") % _pfx(conn),
            (invite.get('room'), invite.get('type'), invite.get('leader'),
             fold, fold, nm, invite.get('leader_uuid') or '', pc, ps,
             json.dumps(cos), ROLE_LEADER, role, rid))
        conn.commit()
        return rid, False
    conn.execute(
        ("INSERT INTO %suser_room(room_id,room_name,room_type,leader_name,"
         "folder_a,folder_b,my_name,leader_uuid,my_role,my_cohort,use_cohort,"
         "plan_code,plan_start,co_leaders,members,joined_at,record_status)"
         " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'LIVE')")
        % _pfx(conn),
        (rid, invite.get('room'), invite.get('type'), invite.get('leader'),
         fold, fold, nm, invite.get('leader_uuid') or '', role,
         invite.get('cohort') or '',
         int(invite.get('use_cohort') or 0), pc or None, ps or None,
         json.dumps(cos), 0, _now()))
    conn.commit()
    return rid, True


# ── 조회·손질 ────────────────────────────────────────────────────────
def rooms(conn, include_left=False):
    """참여 중인 방 → dict 목록(최근 참여가 위)."""
    ensure(conn)
    w = '' if include_left else " WHERE record_status='LIVE'"
    cols = ('room_id', 'room_name', 'room_type', 'leader_name', 'leader_contact',
            'folder_a', 'folder_b', 'my_name', 'leader_uuid', 'my_role',
            'my_cohort',
            'use_cohort', 'plan_code', 'room_status', 'closed_at', 'plan_start',
            'co_leaders', 'status_at', 'members', 'joined_at', 'last_sync',
            'record_status')
    sql = "SELECT %s FROM %suser_room%s ORDER BY joined_at DESC" % (
        ','.join(cols), _pfx(conn), w)
    return [dict(zip(cols, r)) for r in conn.execute(sql)]


def room(conn, room_id):
    for r in rooms(conn, include_left=True):
        if r['room_id'] == room_id:
            return r
    return None


def set_my_name(conn, room_id, name):
    """**이 방에서 쓸 이름** — 방마다 따로 정한다(§5-1).

    ⚠ 전역 이름 하나로 두면 다른 교회 방에도 따라간다.
    """
    ensure(conn)
    n = conn.execute("UPDATE %suser_room SET my_name=? WHERE room_id=?"
                     % _pfx(conn), ((name or '').strip(), room_id)).rowcount
    conn.commit()
    return n


def set_folders(conn, room_id, folder_a=None, folder_b=None):
    ensure(conn)
    sets, args = [], []
    if folder_a is not None:
        sets.append('folder_a=?'); args.append((folder_a or '').strip())
    if folder_b is not None:
        sets.append('folder_b=?'); args.append((folder_b or '').strip())
    if not sets:
        return 0
    args.append(room_id)
    n = conn.execute("UPDATE %suser_room SET %s WHERE room_id=?"
                     % (_pfx(conn), ','.join(sets)), args).rowcount
    conn.commit()
    return n


def folder_of(r):
    """**방 폴더 하나** — 옛 두 칸 중 있는 것(나눔 폴더 우선).

    2026-09-08 사용자 확정 「구글드라이브 하나만 유지하는 방식으로 하자.
    교재를 올리고 묵상방의 게시판에 첨부하면 된다.」 — 교재 폴더/나눔 폴더를
    가르던 옛 설계를 걷는다. 교재는 이제 **게시판 첨부 파일**이다.
    ⚠ 두 칸을 안 없애는 까닭 — 옛 방·옛 초대 파일이 그대로 읽혀야 한다.
    """
    if not r:
        return ''
    return ((r.get('folder_b') or r.get('folder_a') or '')).strip()


def set_folder(conn, room_id, path):
    """방 폴더 하나를 정한다 — **두 칸에 같은 값**(옛 코드가 어느 칸을
    읽어도 같은 폴더가 나온다)."""
    return set_folders(conn, room_id, path, path)


def _co_list(raw):
    try:
        v = json.loads(raw) if raw else []
        return [str(x) for x in v if x] if isinstance(v, list) else []
    except Exception:
        return []


def co_leaders(r):
    """부방장 번호 목록(방 dict 에서)."""
    return _co_list((r or {}).get('co_leaders'))


def managers_of(r):
    """★ 방을 운영하는 번호들 = 방장 + 부방장. 받는 쪽이 공지·지침·가림·마무리를
    **이 집합**과 대조한다."""
    out = set(co_leaders(r))
    lu = ((r or {}).get('leader_uuid') or '').strip()
    if lu:
        out.add(lu)
    return out


def is_manager(conn, room_id):
    r = room(conn, room_id)
    return bool(r and r['my_role'] in MANAGER_ROLES)


def set_co_leader(conn, room_id, member_uuid, on=True):
    """★★★ **부방장 지정/해제 — 방장만.** 방장 파일이 목록을 나르고 그 사람의
    앱이 받으며 제 역할을 바꾼다(`adopt_leader_meta`)."""
    ensure(conn)
    if not is_leader(conn, room_id):
        raise ValueError('NOT_LEADER')
    mid = str(member_uuid or '').strip()
    if not mid or mid == _my_uuid_safe(conn):
        raise ValueError('BAD_MEMBER')
    cur = set(co_leaders(room(conn, room_id)))
    if on:
        cur.add(mid)
    else:
        cur.discard(mid)
    conn.execute("UPDATE %suser_room SET co_leaders=? WHERE room_id=?" % _pfx(conn),
                 (json.dumps(sorted(cur)), room_id))
    conn.commit()
    return sorted(cur)


def set_plan_start(conn, room_id, ymd):
    """★★★ **시작일 — 방장이 정하고 모두 같은 날 시작한다**(2026-09-08 사용자
    확정 「시작하는 날자는 방장이 지정해야 한다 같은 날 모두 시작해야 한다」).
    참여자의 「오늘」은 등록이 아니라 **이 날짜**에서 센다(`today_day`)."""
    ensure(conn)
    if not is_leader(conn, room_id):
        raise ValueError('NOT_LEADER')
    v = (ymd or '').strip()
    if v:
        datetime.strptime(v, '%Y-%m-%d')      # 꼴이 틀리면 여기서 터진다
    conn.execute("UPDATE %suser_room SET plan_start=? WHERE room_id=?" % _pfx(conn),
                 (v or None, room_id))
    conn.commit()
    return v


def today_day(r, today=None):
    """시작일 기준 오늘 일차(1부터). 시작일이 없으면 None · 시작 전이면 1."""
    ps = ((r or {}).get('plan_start') or '').strip()
    if not ps:
        return None
    try:
        d0 = datetime.strptime(ps, '%Y-%m-%d').date()
    except Exception:
        return None
    t = today or datetime.now().date()
    return max(1, (t - d0).days + 1)


def set_plan(conn, room_id, plan_code):
    """★★★ **방의 묵상플랜을 정한다 — 방장만**(2026-09-08 사용자 확정
    「묵상플랜을 교회관리자가 특정한다 … 이 플랜이 방 내부에 공유된다」).

    ⚠ **화면이 아니라 여기서 막는다** — 입구가 늘어도 안 샌다.
    ⚠ 참여자는 이 문을 안 쓴다 — 방장 파일을 받으며 `adopt_leader_meta` 로
      적어 둔다.
    """
    ensure(conn)
    if not is_leader(conn, room_id):
        raise ValueError('NOT_LEADER')
    n = conn.execute("UPDATE %suser_room SET plan_code=? WHERE room_id=?"
                     % _pfx(conn), ((plan_code or '').strip() or None, room_id)
                     ).rowcount
    conn.commit()
    return n


def rename_room(conn, room_id, name):
    """★★ **방 이름을 바꾼다 — 방장만.** 다음 훈련에 같은 방을 다시 쓴다
    (2026-09-08 사용자 확정 — 「방이름을 바꾸고(묵상훈련_2029_1기) 다음에
    참가자를 초청하면 된다. 굳이 그 안에 있는 환경을 리셋할 필요가 없다」).
    ⚠ **기수라는 개념을 앱에 두지 않는다** — 이름이 그 몫을 한다.
    """
    ensure(conn)
    nm = (name or '').strip()
    if not nm:
        raise ValueError('EMPTY_NAME')
    if not is_leader(conn, room_id):
        raise ValueError('NOT_LEADER')
    n = conn.execute("UPDATE %suser_room SET room_name=? WHERE room_id=?"
                     % _pfx(conn), (nm, room_id)).rowcount
    conn.commit()
    return n


def adopt_leader_meta(conn, room_id, name=None, plan_code=None, status=None,
                      closed_at=None, plan_start=None, co_leaders_list=None,
                      status_at=None):
    """참여자 쪽 — **방장 파일이 말하는 이름·플랜을 받아 적는다.**

    ⚠ 부르는 쪽(`room_share.apply_notes`)이 **보낸 사람이 방장인지 먼저
      가린다.** 여기서는 다시 안 묻는다 — 방장 자신에게는 부를 일이 없다.
    ⚠ 빈 값은 안 덮는다 — 이름을 지우는 길은 없다.
    """
    ensure(conn)
    r = room(conn, room_id)
    if not r or r['my_role'] == ROLE_LEADER:
        return 0
    sets, args = [], []
    if (name or '').strip() and (name or '').strip() != (r['room_name'] or ''):
        sets.append('room_name=?'); args.append(name.strip())
    if plan_code is not None and (plan_code or '') != (r.get('plan_code') or ''):
        sets.append('plan_code=?'); args.append((plan_code or '').strip() or None)
    if status is not None and (status or 'OPEN') != (r.get('room_status') or 'OPEN'):
        # ⚠ 시각을 견준다 — 보낸 결정이 내가 가진 것보다 옛것이면 안 받는다.
        #   시각 없는 옛 파일은 내 것도 없을 때만.
        s_at, my_at = (status_at or '').strip(), (r.get('status_at') or '').strip()
        if (s_at and s_at >= my_at) or (not s_at and not my_at):
            sets.append('room_status=?'); args.append((status or 'OPEN').strip())
            sets.append('closed_at=?'); args.append((closed_at or '').strip() or None)
            sets.append('status_at=?'); args.append(s_at or None)
    if plan_start is not None and (plan_start or '') != (r.get('plan_start') or ''):
        sets.append('plan_start=?'); args.append((plan_start or '').strip() or None)
    if co_leaders_list is not None:
        cos = sorted(str(x) for x in co_leaders_list if x)
        if cos != sorted(co_leaders(r)):
            sets.append('co_leaders=?'); args.append(json.dumps(cos))
        me = _my_uuid_safe(conn)
        # ★ 내 역할이 목록을 따라 바뀐다 — 부방장으로 올라가거나 참여자로 돌아온다
        if me and me in cos and r['my_role'] == ROLE_MEMBER:
            sets.append('my_role=?'); args.append(ROLE_CO)
        elif r['my_role'] == ROLE_CO and me not in cos:
            sets.append('my_role=?'); args.append(ROLE_MEMBER)
    if not sets:
        return 0
    args.append(room_id)
    n = conn.execute("UPDATE %suser_room SET %s WHERE room_id=?"
                     % (_pfx(conn), ','.join(sets)), args).rowcount
    conn.commit()
    return n


def close_room(conn, room_id, closed=True):
    """★ 5단계 — **방 마무리**(수료 처리) · 다시 열기. **방장만.**

    사용자 확정 흐름 「다 끝나면 관리자가 마지막 인사말을 하고 서로 인사를 한
    후에 방 관리가 마무리된다」. 마무리해도 글·자료·폴더는 그대로다 — 화면이
    「마무리됨」을 적고 진도 재촉을 멈출 뿐이다. 다음 훈련은 이름을 바꾸고
    다시 열면 된다.
    ⚠ 화면이 아니라 여기서 막는다 — 참여자는 못 부른다.
    """
    ensure(conn)
    if not is_manager(conn, room_id):
        raise ValueError('NOT_LEADER')
    n = conn.execute("UPDATE %suser_room SET room_status=?, closed_at=?, status_at=? "
                     "WHERE room_id=?" % _pfx(conn),
                     ('CLOSED' if closed else 'OPEN',
                      _now()[:10] if closed else None, _now(), room_id)).rowcount
    conn.commit()
    return n


def is_closed(r):
    return bool(r) and (r.get('room_status') or 'OPEN') == 'CLOSED'


BLOCK_KEY = 'ROOM_BLOCKLIST'


def blocklist(conn):
    """★ 최종관리자 취소 목록 — `sys_config['ROOM_BLOCKLIST']`(코어팩으로 온다).

    → `{room_id: {'reason':…, 'at':…}}`. 없으면 빈 dict.
    ⚠ **자물쇠가 아니라 문패다**(설계 §6-0·§9-b ⓐ) — 막히는 것은 **이 앱의
      화면**뿐이고 폴더는 그 공동체 것이라 파일은 남는다. 화면이 그것을 적는다.
    """
    try:
        r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                         (BLOCK_KEY,)).fetchone()
        d = json.loads(r[0]) if r and r[0] else {}
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def blocked(conn, room_id):
    """그 방이 막혔나 → 사유(str) 또는 None."""
    d = blocklist(conn).get(str(room_id or ''))
    if not d:
        return None
    return (d.get('reason') if isinstance(d, dict) else str(d)) or '(사유 없음)'


def leave_room(conn, room_id):
    """방에서 나간다 — **지우지 않고 숨긴다**(`HIDE`).

    ⚠ 물리 삭제를 안 하는 까닭 = 되돌릴 수 있어야 하고, 나중에 「1기 때
      그 방에서 쓴 글」을 되짚을 수 있어야 한다(§6-0 「숨기기이지 삭제가 아니다」).
    """
    ensure(conn)
    n = conn.execute(("UPDATE %suser_room SET record_status='HIDE' "
                      "WHERE room_id=?") % _pfx(conn), (room_id,)).rowcount
    conn.commit()
    return n


def delete_room(conn, room_id):
    """방을 아주 지운다 — **연락처까지 함께 사라진다**(§6-0 ⓓ).

    ⚠ 화면은 **몇 개가 사라지는지 먼저 세어** 묻고서 부른다(§0 규칙).
    """
    ensure(conn)
    n = conn.execute("DELETE FROM %suser_room WHERE room_id=?" % _pfx(conn),
                     (room_id,)).rowcount
    conn.commit()
    return n


def is_leader(conn, room_id):
    r = room(conn, room_id)
    return bool(r and r['my_role'] == ROLE_LEADER)


# ── 등록 신고 — 관리자가 방장에게 닿는 유일한 길 ─────────────────────
def report(conn, room_id, force=False):
    """방을 연 사실을 관리자에게 **신고**한다 → `(보냈나, 사유)`.

    ★★★ **이것이 「관리자가 방장에게 이메일을 보낼 수 있습니다」를 참으로
      만드는 자리다**(2026-09-08 실측으로 잡았다).
      ⚠⚠ 그전에는 **연락처가 관리자에게 가는 길이 한 곳도 없었다** — 화면은
        보낼 수 있다고 약속하는데 주소가 이 PC 밖으로 안 나갔다. **화면이
        거짓말을 하고 있었다**(§0-1).
      ⚠ **이용통계에 실으면 안 된다** — 그것은 익명 집계이고 「이름·연락처는
        안 보낸다」고 못 박았다(§6-0). 이메일을 거기 실으면 익명이 깨진다.
      ⇒ **문의 통로로 보낸다**(`user_feedback.submit`) — 그 통로는 이미
        `uuid`·`email` 을 함께 싣고 **양방향**이라(§208차 ③), 관리자 Q&A
        화면에서 **그 자리에서 답할 수 있다.** 새 통로 0.

    ⚠ **자동승인이라 이것은 「허락을 구하는 것」이 아니다** — 신고다.
      **실패해도 방은 이미 열려 있다**(§6-0 절차 3).
    ⚠ **한 번만 보낸다**(`reported_at`) — 앱을 켤 때마다 보내면 문의함이 찬다.
    ⚠ **연락처를 안 적었으면 안 보낸다** — 보낼 것이 없고, 익명 UUID 만
      보내는 것은 이용통계가 이미 한다.
    """
    ensure(conn)
    r = room(conn, room_id)
    if not r:
        return False, 'NO_ROOM'
    if r['record_status'] != 'LIVE':
        return False, 'LEFT'
    if r['my_role'] != ROLE_LEADER:
        return False, 'NOT_LEADER'      # 참여자는 연락처를 안 적는다
    if not (r['leader_contact'] or '').strip():
        return False, 'NO_CONTACT'
    if not force:
        got = conn.execute("SELECT reported_at FROM %suser_room WHERE room_id=?"
                           % _pfx(conn), (room_id,)).fetchone()
        if got and (got[0] or '').strip():
            return False, 'ALREADY'
    try:
        import user_feedback as UF
        if not UF.is_configured(conn):
            return False, 'NOT_CONFIGURED'
        # ★ **방 번호를 함께 적는다** — 최종관리자가 문제 방을 막을 때
        #   (`db_room_block`) 그 번호가 열쇠다. 없으면 막을 길이 없다.
        body = ('[공동체 방 등록]\n'
                '이름: %s\n유형: %s\n방장: %s\n연 날짜: %s\n방 번호: %s\n'
                '\n※ 자동승인으로 열린 방의 등록 신고입니다.'
                % (r['room_name'], r['room_type'], r['leader_name'] or '',
                   (r['joined_at'] or '')[:10], room_id))
        ok, err = UF.submit(conn, 'OTHER', body,
                            email=(r['leader_contact'] or '').strip())
    except Exception as e:
        return False, str(e)[:60]
    if ok:
        conn.execute("UPDATE %suser_room SET reported_at=? WHERE room_id=?"
                     % _pfx(conn), (_now(), room_id))
        conn.commit()
        return True, ''
    return False, err or 'SEND_FAIL'


def pending_reports(conn):
    """아직 신고 못 한 방 → `room_id` 목록. **못 보낸 것은 다음에 보낸다.**"""
    ensure(conn)
    out = []
    for r in rooms(conn):
        if r['my_role'] != ROLE_LEADER:
            continue
        if not (r['leader_contact'] or '').strip():
            continue
        got = conn.execute("SELECT reported_at FROM %suser_room WHERE room_id=?"
                           % _pfx(conn), (r['room_id'],)).fetchone()
        if not (got and (got[0] or '').strip()):
            out.append(r['room_id'])
    return out


# ── 이용통계 — 「몇 개 공동체가 쓰는가」 ──────────────────────────────
def metrics_rows(conn):
    """이용통계에 실을 줄 → `[{'type','members','role'}, …]`.

    ★ **새 통로를 안 만든다** — 지금 이용통계에 한 줄 더한다(§6-0).
    ⚠⚠ **이름·연락처·글은 안 보낸다** — 유형과 인원과 역할뿐이다.
      익명이 깨지면 안 된다.
    ⚠ **한 방이 여러 번 세어진다** — 참여자 30명이 모두 보내므로.
      ⇒ 받는 쪽이 `role` 로 가른다. **방장 것만 세면 방 수**다.
    """
    ensure(conn)
    out = []
    for r in rooms(conn):
        out.append({'type': r['room_type'], 'role': r['my_role'],
                    'members': int(r['members'] or 0)})
    return out


def type_name(code, lang='KO'):
    """유형 이름 — **i18n 을 탄다**(§0-3). 교회 밖 공동체가 쓰는 말이라
    나라마다 다르다."""
    for c, key, _co in COMMUNITY_TYPES:
        if c == code:
            fb = _KO_FALLBACK.get(c, c)
            try:
                import i18n
                # ⚠⚠ **`i18n.t(key, '')` 로 부르면 안 된다** — 폴백이 비면
                #   `t()` 가 **열쇠 자체**를 돌려준다(실측: 화면에
                #   `ROOMTYPE_CHURCH_TR` 이 그대로 떴다).
                #   ⇒ **코드 폴백을 반드시 넘긴다**(§0-3).
                return i18n.t(key, fb)
            except Exception:
                return fb
    return code


#: ⚠ 코드 폴백 — `i18n.load` 가 실패한 자리(하네스·초기화 전)에서 쓴다.
#:   **DB 값과 글자가 같아야 한다**(§0-3 — 한쪽만 고치면 옛말이 나온다).
_KO_FALLBACK = {
    'CHURCH_TR': '교회 · 훈련',
    'CHURCH_GR': '교회 · 소그룹',
    'FAMILY':    '가정',
    'FRIEND':    '친구 · 또래',
    'MISSION':   '선교단체 · 기관',
    'SCHOOL':    '학교 · 교육기관',
    'ETC':       '그 밖',
}


# ── 자가 검증 ────────────────────────────────────────────────────────
def selftest():
    """⚠ **실 DB 를 한 글자도 안 건드린다** — 메모리 DB 로 잰다(§0-5)."""
    import sqlite3
    import tempfile
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    c = sqlite3.connect(':memory:')
    c.execute("ATTACH ':memory:' AS userdb")
    # ⚠ 익명 번호는 `user_config` 에서 온다(문의 통로와 같은 것)
    c.execute("CREATE TABLE userdb.user_config(config_key TEXT PRIMARY KEY,"
              " config_val TEXT)")
    ensure(c)
    ensure(c)                      # 두 번 불러도 안 깨진다
    t('★ 표를 두 번 만들어도 된다(멱등)', True)

    # ★★★ **`userdb` 가 없는 연결에서도 돈다** (2026-09-08 실측으로 잡았다)
    #   `usage_stats._conn()` 은 `user_data.db` 를 **main 으로 직접** 연다.
    #   그때 `userdb.user_room` 은 `unknown database userdb` 로 터지는데
    #   `except: pass` 가 삼켜 **통계 줄이 조용히 빠졌다.**
    #   ⇒ `_pfx` 가 붙어 있는 스키마를 물어보고 정한다.
    c_flat = sqlite3.connect(':memory:')      # userdb 없이
    c_flat.execute("CREATE TABLE user_config(config_key TEXT PRIMARY KEY,"
                   " config_val TEXT)")
    t('★★ userdb 없는 연결에서도 표를 만든다',
      ensure(c_flat) is not None and _pfx(c_flat) == '', repr(_pfx(c_flat)))
    t('  붙어 있으면 접두를 쓴다', _pfx(c) == 'userdb.', repr(_pfx(c)))
    _rid_f = create_room(c_flat, '맨연결방', 'ETC', '나', terms_ok=True)
    t('★★ userdb 없는 연결에서도 방이 열리고 읽힌다',
      len(rooms(c_flat)) == 1 and room(c_flat, _rid_f) is not None)
    t('  통계 줄도 나온다', len(metrics_rows(c_flat)) == 1,
      metrics_rows(c_flat))
    set_my_name(c_flat, _rid_f, '가')
    leave_room(c_flat, _rid_f)
    t('  이름·나가기도 돈다', len(rooms(c_flat)) == 0)
    c_flat.close()

    # ── 방 열기 ──────────────────────────────────────────────────
    rid = create_room(c, '우리교회 제자훈련 1기', 'CHURCH_TR', '김전도사',
                      contact='a@b.c', terms_ok=True, folder_a='https://A',
                      folder_b='https://B')
    r = room(c, rid)
    t('★ 방이 열린다', bool(r) and r['room_name'].endswith('1기'))
    t('  연 사람이 방장이다', r['my_role'] == ROLE_LEADER, r['my_role'])
    t('  내 이름은 방장 이름으로 시작', r['my_name'] == '김전도사', r['my_name'])
    t('★ 유형이 기수 기본값을 준다(교회·훈련=켬)',
      int(r['use_cohort']) == 1, r['use_cohort'])

    rid2 = create_room(c, '할아버지랑 말씀 읽기', 'FAMILY', '손주',
                       terms_ok=True)
    t('  가정 방은 기수 기본이 꺼짐',
      int(room(c, rid2)['use_cohort']) == 0)
    # ⚠ 유형이 기능을 묶지 않는다 — 켤 수 있어야 한다
    rid3 = create_room(c, '청년 스터디', 'FRIEND', '나', terms_ok=True,
                       use_cohort=True)
    t('★ 기수는 유형이 아니라 스위치가 정한다',
      int(room(c, rid3)['use_cohort']) == 1)

    # ── 막는 자리 ────────────────────────────────────────────────
    def boom(fn, why):
        try:
            fn()
            return False
        except ValueError as e:
            return why in str(e)
        except Exception:
            return False
    t('★ 책임 선언에 동의 안 하면 안 열린다',
      boom(lambda: create_room(c, 'x', 'ETC', 'y', terms_ok=False),
           'TERMS_REQUIRED'))
    t('  이름이 비면 안 열린다',
      boom(lambda: create_room(c, '  ', 'ETC', 'y', terms_ok=True), 'EMPTY_NAME'))
    t('  모르는 유형은 안 열린다',
      boom(lambda: create_room(c, 'x', 'NOPE', 'y', terms_ok=True), 'BAD_TYPE'))
    t('  방장 이름이 비면 안 열린다',
      boom(lambda: create_room(c, 'x', 'ETC', '', terms_ok=True), 'EMPTY_LEADER'))

    # ── 초대 파일 ────────────────────────────────────────────────
    d = tempfile.mkdtemp(prefix='room_st_')
    p = write_invite(c, rid, os.path.join(d, '우리교회_1기'), note='1기 성도용')
    t('★ 초대 파일 확장자가 .hagah', p.endswith(EXT), os.path.basename(p))
    inv = read_invite(p)
    t('  방 번호가 그대로 실린다', inv['room_id'] == rid)
    # ★★★ **폴더는 하나다**(2026-09-08 사용자 확정) — 옛 두 칸 중 나눔 폴더가
    #   그 하나가 되고, 초대 파일의 세 열쇠가 **같은 값**을 갖는다.
    t('★★★ 폴더 주소가 하나로 실린다(나눔 폴더 우선)',
      inv['folder'] == 'https://B' and inv['folder_a'] == inv['folder_b']
      == 'https://B', (inv.get('folder'), inv.get('folder_a')))
    t('  방 dict 에서도 폴더 하나', folder_of(room(c, rid)) == 'https://B')
    t('★★ 연락처는 안 실린다(개인정보)',
      'a@b.c' not in io.open(p, encoding='utf-8').read())
    t('  파일 크기가 2KB 안쪽', os.path.getsize(p) < 2048, os.path.getsize(p))

    # 잘못된 파일 — **무엇이 잘못됐는지 말한다**
    bad = os.path.join(d, 'x.hagah')
    io.open(bad, 'w', encoding='utf-8').write('{"app":"hagah-share","fmt":1}')
    t('★ 묶음 파일을 넣으면 그렇다고 말한다',
      boom(lambda: read_invite(bad), 'IS_SHARE_PACK'))
    io.open(bad, 'w', encoding='utf-8').write('{"hello":1}')
    t('  엉뚱한 파일은 거부', boom(lambda: read_invite(bad), 'NOT_INVITE'))
    io.open(bad, 'w', encoding='utf-8').write(
        '{"app":"hagah-room","kind":"ROOM_INVITE","fmt":99,"room_id":"a","room":"b"}')
    t('★ 더 새 판은 거부하고 판을 말한다',
      boom(lambda: read_invite(bad), 'NEWER_FMT'))
    io.open(bad, 'w', encoding='utf-8').write(
        '{"app":"hagah-room","kind":"ROOM_INVITE","fmt":1,'
        '"room_id":"zz","room":"모르는유형방","type":"WHAT"}')
    t('  모르는 유형은 「그 밖」으로 받는다(거부 안 함)',
      read_invite(bad)['type'] == 'ETC')

    # ── 참여 (다른 PC 흉내 — 빈 DB) ──────────────────────────────
    c2 = sqlite3.connect(':memory:')
    c2.execute("ATTACH ':memory:' AS userdb")
    ensure(c2)
    rid_j, fresh = join_room(c2, inv, my_name='김집사')
    t('★ 초대 파일로 참여한다', rid_j == rid and fresh)
    j = room(c2, rid_j)
    t('  참여자는 MEMBER 다', j['my_role'] == ROLE_MEMBER, j['my_role'])
    t('  이 방에서 쓸 이름이 담긴다', j['my_name'] == '김집사')
    t('  방 이름·방장이 함께 온다',
      j['room_name'].endswith('1기') and j['leader_name'] == '김전도사')

    n0 = len(rooms(c2))
    rid_j2, fresh2 = join_room(c2, inv)
    t('★★ 두 번 참여해도 방이 안 는다(멱등)',
      (not fresh2) and len(rooms(c2)) == n0, len(rooms(c2)))
    t('★ 다시 참여해도 내 이름은 안 덮인다',
      room(c2, rid)['my_name'] == '김집사', room(c2, rid)['my_name'])

    # ── 이름·나가기 ──────────────────────────────────────────────
    set_my_name(c2, rid, '김권사')
    t('  이름을 바꾼다', room(c2, rid)['my_name'] == '김권사')
    # ⚠ 이름은 방마다 따로 — 다른 방에 안 따라간다
    inv2 = invite_body(c, rid2)
    join_room(c2, inv2, my_name='손주')
    t('★★ 이름은 방마다 따로 정해진다',
      room(c2, rid)['my_name'] == '김권사' and room(c2, rid2)['my_name'] == '손주')

    leave_room(c2, rid2)
    t('★ 나가면 목록에서 빠진다', all(x['room_id'] != rid2 for x in rooms(c2)))
    t('  그런데 지워지지는 않는다',
      any(x['room_id'] == rid2 for x in rooms(c2, include_left=True)))
    _r, again = join_room(c2, inv2)
    t('  다시 들어오면 되살아난다',
      (not again) and any(x['room_id'] == rid2 for x in rooms(c2)))

    # ── 통계 ─────────────────────────────────────────────────────
    m = metrics_rows(c)
    t('★ 통계 줄이 나온다', len(m) == 3, len(m))
    t('★★ 이름·연락처가 안 들어간다',
      all(set(x) == {'type', 'role', 'members'} for x in m), m[:1])
    t('  방장 것만 세면 방 수',
      sum(1 for x in m if x['role'] == ROLE_LEADER) == 3)
    m2 = metrics_rows(c2)
    t('  참여자 쪽은 MEMBER 로 나간다',
      all(x['role'] == ROLE_MEMBER for x in m2), m2)

    # ── 등록 신고 ────────────────────────────────────────────────
    # ⚠ **네트워크를 안 탄다** — 막는 조건만 잰다(보내는 것은 실왕복에서).
    t('★ 연락처가 없으면 신고하지 않는다',
      report(c, rid2)[1] == 'NO_CONTACT', report(c, rid2))
    t('  참여자는 신고 대상이 아니다',
      report(c2, rid)[1] == 'NOT_LEADER', report(c2, rid))
    t('  없는 방은 NO_ROOM', report(c, 'nope')[1] == 'NO_ROOM')
    t('★ 신고 대기 목록에 연락처 있는 방만 뜬다',
      pending_reports(c) == [rid], pending_reports(c))
    # 보낸 것으로 표시하면 대기에서 빠진다
    c.execute("UPDATE %suser_room SET reported_at='2026-09-08' WHERE room_id=?"
              % _pfx(c), (rid,))
    t('  한 번 보내면 다시 안 보낸다',
      report(c)[1] if False else report(c, rid)[1] == 'ALREADY')
    t('  대기 목록에서 빠진다', pending_reports(c) == [], pending_reports(c))
    _src0 = io.open(os.path.abspath(__file__), encoding='utf-8').read()
    # ⚠⚠ **이용통계에 연락처를 싣지 않는다** — 찾는 글자는 조립한다(§199차)
    _mi = _src0[_src0.find('def metrics_rows'):]
    t('★★ 이용통계에 연락처가 안 실린다',
      ('leader_' + 'contact') not in _mi[:900])

    # ── 신원 ─────────────────────────────────────────────────────
    src = io.open(__file__, encoding='utf-8').read()
    # ⚠⚠ **찾는 글자를 검사 코드에 그대로 적으면 자기가 걸린다**(§199차) —
    #   조립해서 만든다.
    _new_id = 'uuid4' + '()'
    t('★★ 새 신원을 안 만든다(문의 통로 UUID 를 쓴다)',
      'user_feedback' in src and src.count(_new_id) == 1, src.count(_new_id))
    t('  유형 목록이 단일 소스', len(TYPE_CODES) == len(set(TYPE_CODES)) == 7)
    t('  유형마다 i18n 열쇠가 있다',
      all(k.startswith('ROOMTYPE_') for _c, k, _b in COMMUNITY_TYPES))
    t('★ 코드 폴백이 유형을 다 덮는다',
      all(x in _KO_FALLBACK for x in TYPE_CODES))
    # ⚠ 3단계 것을 미리 만들지 않았는가
    # ⚠⚠ 여기서도 **찾는 글자를 그대로 적으면 자기가 걸린다**(§199차) — 조립한다.
    _n3 = ('room_' + 'note', 'author_' + 'uuid')
    t('★ 2단계 범위를 넘지 않는다(나눔글 표 없음)',
      all(src.count(x) <= 1 for x in _n3), [src.count(x) for x in _n3])

    # 뒷정리
    for f in os.listdir(d):
        try:
            os.remove(os.path.join(d, f))
        except OSError:
            pass
    try:
        os.rmdir(d)
    except OSError:
        pass
    t('  시험 파일 잔재 0', not os.path.exists(d))

    # ── ★★★ 공지 — **방장만** ────────────────────────────────
    #   2026-09-08 사용자 「방 내부의 공지사항은 방장만 올릴 수 있다」
    okn, why = can_notice(c, rid)
    t('★★★ 방장은 공지를 올릴 수 있다', okn, why)
    lu = room(c, rid)['leader_uuid']
    t('  방장 번호가 담겼다', bool(lu), lu[:8] if lu else None)
    inv2 = invite_body(c, rid)
    t('★★ 초대장이 방장 번호를 싣는다', inv2.get('leader_uuid') == lu)
    t('⚠ 연락처는 여전히 안 싣는다',
      'a@b.c' not in json.dumps(inv2, ensure_ascii=False))

    c2 = sqlite3.connect(':memory:')
    c2.execute("ATTACH ':memory:' AS userdb")
    c2.execute("CREATE TABLE userdb.user_config(config_key TEXT PRIMARY KEY,"
               " config_val TEXT)")
    ensure(c2)
    rid2, _new = join_room(c2, inv2, my_name='박청년')
    t('★ 참여자도 방장 번호를 받는다',
      room(c2, rid2)['leader_uuid'] == lu)
    ok2, why2 = can_notice(c2, rid2)
    t('★★★ **참여자는 공지를 못 올린다**', (not ok2) and why2 == 'NOT_LEADER',
      why2)

    # ⚠ 옛 초대장(번호 없음)이면 — 방장이어도 못 쓴다 + 왜인지 말한다
    c3 = sqlite3.connect(':memory:')
    c3.execute("ATTACH ':memory:' AS userdb")
    c3.execute("CREATE TABLE userdb.user_config(config_key TEXT PRIMARY KEY,"
               " config_val TEXT)")
    ensure(c3)
    rid3 = create_room(c3, '옛방', 'ETC', '나', terms_ok=True)
    c3.execute("UPDATE userdb.user_room SET leader_uuid='' WHERE room_id=?",
               (rid3,))
    c3.commit()
    ok3, why3 = can_notice(c3, rid3)
    t('★★ 옛 방은 못 쓰되 **왜인지 말한다**',
      (not ok3) and why3 == 'NO_UUID', why3)
    # ── ★★★ 4단계 — 방이 플랜을 정한다 · 이름을 바꿔 다시 쓴다 ────────
    #   2026-09-08 사용자 확정 「묵상플랜을 교회관리자가 특정한다 … 이 플랜이
    #   방 내부에 공유된다」 · 「방이름을 바꾸고 다음에 참가자를 초청하면 된다」
    #   · 「앱은 기수 개념 필요 없다」.
    t('★ 방장이 플랜을 정한다', set_plan(c, rid, 'P1') == 1
      and room(c, rid)['plan_code'] == 'P1', room(c, rid).get('plan_code'))
    t('★★ 참여자는 플랜을 못 정한다(여기서 막는다)',
      boom(lambda: set_plan(c2, rid, 'P9'), 'NOT_LEADER'))
    inv2 = invite_body(c, rid)
    t('★ 초대 파일이 플랜을 싣는다', inv2['plan_code'] == 'P1', inv2['plan_code'])
    rid_j, _fresh = join_room(c2, inv2)
    t('★★ 참여자가 초대로 플랜을 받아 적는다',
      room(c2, rid)['plan_code'] == 'P1', room(c2, rid).get('plan_code'))
    t('★ 방장이 이름을 바꾼다(다음 기수에 같은 방)',
      rename_room(c, rid, '묵상훈련_2027_1기') == 1
      and room(c, rid)['room_name'] == '묵상훈련_2027_1기')
    t('  빈 이름은 거부', boom(lambda: rename_room(c, rid, ' '), 'EMPTY_NAME'))
    t('  참여자는 이름을 못 바꾼다',
      boom(lambda: rename_room(c2, rid, 'x'), 'NOT_LEADER'))
    n_ad = adopt_leader_meta(c2, rid, name='묵상훈련_2027_1기', plan_code='P2')
    t('★★ 참여자는 방장 파일에서 이름·플랜을 받아 적는다',
      n_ad == 1 and room(c2, rid)['room_name'] == '묵상훈련_2027_1기'
      and room(c2, rid)['plan_code'] == 'P2', (n_ad, room(c2, rid).get('plan_code')))
    t('  방장 자신에게는 아무 일도 안 한다',
      adopt_leader_meta(c, rid, name='딴이름') == 0
      and room(c, rid)['room_name'] == '묵상훈련_2027_1기')
    t('  같은 값이면 0', adopt_leader_meta(c2, rid, name='묵상훈련_2027_1기',
                                        plan_code='P2') == 0)
    # ── 5단계 — 마무리 · 차단 ──────────────────────────────────────
    t('★ 방장이 방을 마무리한다', close_room(c, rid) == 1
      and is_closed(room(c, rid)) and room(c, rid)['closed_at'])
    t('  참여자는 못 한다', boom(lambda: close_room(c2, rid), 'NOT_LEADER'))
    t('★ 참여자는 방장 파일에서 마무리를 받아 적는다',
      adopt_leader_meta(c2, rid, status='CLOSED', closed_at='2026-09-08') == 1
      and is_closed(room(c2, rid)))
    t('  다시 열기', close_room(c, rid, closed=False) == 1
      and not is_closed(room(c, rid)) and room(c, rid)['closed_at'] is None)
    c.execute("CREATE TABLE IF NOT EXISTS sys_config(config_key TEXT PRIMARY KEY,"
              " config_val TEXT)")
    t('  막힌 방이 없으면 None', blocked(c, rid) is None)
    c.execute("INSERT OR REPLACE INTO sys_config VALUES(?,?)",
              (BLOCK_KEY, json.dumps({rid: {'reason': '저작권 침해 신고', 'at': 'x'}})))
    t('★★ 취소 목록에 있으면 사유를 낸다(자물쇠가 아니라 문패)',
      blocked(c, rid) == '저작권 침해 신고', blocked(c, rid))
    t('  신고 본문에 방 번호가 있다', '방 번호' in _src0[_src0.find('def report'):])
    # ── 시작일 · 부방장 ─────────────────────────────────────────────
    t('★ 시작일은 방장만', boom(lambda: set_plan_start(c2, rid, '2026-09-01'),
                                  'NOT_LEADER'))
    t('  꼴이 틀리면 거부', boom(lambda: set_plan_start(c, rid, '9월1일'), ''))
    set_plan_start(c, rid, '2026-09-01')
    from datetime import date as _date
    t('★★★ 오늘 일차는 시작일에서 센다(모두 같은 날 시작)',
      today_day(room(c, rid), _date(2026, 9, 8)) == 8
      and today_day(room(c, rid), _date(2026, 8, 1)) == 1, today_day(room(c, rid)))
    t('  시작일이 없으면 None', today_day({'plan_start': ''}) is None)
    uid_b = my_uuid(c2)
    t('★ 부방장 지정은 방장만', boom(lambda: set_co_leader(c2, rid, 'x'), 'NOT_LEADER'))
    t('  자기 자신은 못 한다', boom(lambda: set_co_leader(c, rid, my_uuid(c)), 'BAD_MEMBER'))
    t('★★ 부방장을 지정한다', set_co_leader(c, rid, uid_b) == [uid_b]
      and uid_b in managers_of(room(c, rid)))
    inv3 = invite_body(c, rid)
    t('  초대 파일이 시작일·부방장을 싣는다',
      inv3['plan_start'] == '2026-09-01' and inv3['co_leaders'] == [uid_b])
    n_ad2 = adopt_leader_meta(c2, rid, plan_start='2026-09-01', co_leaders_list=[uid_b])
    r2 = room(c2, rid)
    t('★★★ 받는 쪽이 제 역할을 부방장으로 바꾼다',
      n_ad2 == 1 and r2['my_role'] == ROLE_CO and r2['plan_start'] == '2026-09-01',
      (n_ad2, r2['my_role']))
    t('  부방장은 공지를 쓸 수 있다', can_notice(c2, rid)[0])
    t('  부방장도 마무리는 된다', close_room(c2, rid) == 1)
    close_room(c2, rid, closed=False)
    t('  부방장이라도 이름·플랜은 못 바꾼다',
      boom(lambda: rename_room(c2, rid, 'x'), 'NOT_LEADER')
      and boom(lambda: set_plan(c2, rid, 'P1'), 'NOT_LEADER'))
    set_co_leader(c, rid, uid_b, on=False)
    adopt_leader_meta(c2, rid, co_leaders_list=[])
    t('★ 해제하면 참여자로 돌아온다', room(c2, rid)['my_role'] == ROLE_MEMBER)
    _src1 = io.open(os.path.abspath(__file__), encoding='utf-8').read()
    t('★★ 기수(cohort) 를 새로 만드는 문이 없다(이름이 그 몫이다)',
      'def ' + 'create_cohort' not in _src1 and 'def ' + 'set_cohort' not in _src1)
    for cc in (c2, c3):
        cc.close()

    print('room_core selftest: %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect()
    rs = rooms(conn)
    print('■ 참여 중인 방 %d' % len(rs))
    for r in rs:
        print('  %-10s %-24s %s · %s · %d명' %
              (r['my_role'], r['room_name'], type_name(r['room_type']),
               r['leader_name'] or '', r['members']))
    if not rs:
        print('  (없음 — 설정 ▸ 내 공동체 에서 방을 열거나 초대 파일로 참여합니다)')
