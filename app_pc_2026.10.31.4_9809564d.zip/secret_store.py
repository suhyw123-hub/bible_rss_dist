# -*- coding: utf-8 -*-
"""secret_store — 관리자 비밀 열쇠(API 키)의 **유일한 집** (2026-10-11 · 영구 · --selftest 의무).

★★★ 왜 따로 두나 — 2026-10-11 실측: 유튜브·제미나이 API 키가 `sys_config` 에 있었고 그 표는 **코어팩에
  통째로 실린다**(db_pack_catalog CORE). 이 PC 에서 만든 코어팩 두 개에 키가 실제로 들어 있었다(서버에는
  아직 안 올라갔다). 배포 꾸러미도 `bible_master.db` 를 통째로 복사한다.
  ⇒ 열쇠는 배포 DB 밖의 파일 `admin_secrets.db` 에만 둔다. 이 파일은 ⓐ 팩이 읽지 않는 파일이고
    ⓑ 배포 꾸러미가 복사하지 않는 파일이며(db_dist_build 는 bible_master.db · user_data.db 만) ⓒ git 에도 안 간다.

막는 층(하나가 뚫려도 다음이 잡는다):
  ① 집을 가른다 — 열쇠를 읽고 쓰는 문은 이 모듈 하나(`get`·`put`·`row`). 화면·수집기가 SQL 로 직접 안 읽는다.
  ② DB 가 거절한다 — `sys_config` 에 열쇠 이름·키 모양 값을 넣으면 트리거가 ABORT(`install_guard`).
     옛 코드·실수로 다시 넣는 길을 막는다.
  ③ 내보내기 전에 잰다 — 팩·모바일 팩·배포 DB·서버 올리기가 `assert_clean` 으로 **실제 열쇠 글자**와
     키 모양(정규식)을 찾으면 멈춘다.

⚠ `SUPPORT_SECRET` 은 여기 안 넣는다 — 사용자 앱이 문의 때 함께 보내는 **배포용 약한 표식**이다
  (user_feedback 머리글 「URL·약한키는 비밀 아님」). 진짜 비밀이 아니므로 ③의 정규식에도 안 걸린다.
⚠ 사용자의 AI 키(user_config AI_ACCOUNTS · user_data.db)는 사용자 제 것이고 배포 DB 밖이다 — 대상 아님.
"""
import os
import re
import sqlite3

HERE = os.path.dirname(os.path.abspath(__file__))
FILE = os.path.join(HERE, 'admin_secrets.db')      # selftest 는 이 값을 갈아 끼운다

#: 비밀 열쇠 이름 — 늘리면 트리거(②)와 이주(migrate)가 저절로 따라온다
NAMES = ('YOUTUBE_API_KEYS', 'YOUTUBE_API_KEYS_PAUSED', 'GEMINI_API_KEYS',
         'GTRANSLATE_KEY',
         'R2_ACCOUNT_ID', 'R2_ACCESS_KEY_ID', 'R2_SECRET_ACCESS_KEY',
         'GPLACES_KEY')   # ★ 2026-10-30 구글 Places(순례 장소 번호 찾기 · db_pilgrim_gplace)   # ★ 2026-10-29 Cloudflare R2 배포 저장소   # ★ 2026-10-22 Cloud Translation(최신 콘텐츠 제목 번역) — 옛 자리 app_state_admin.json

#: 키 모양 — 구글(유튜브·제미나이·번역) · OpenAI · Anthropic · xAI
PATTERNS = (re.compile(rb'AIza[0-9A-Za-z_\-]{35}'),
            re.compile(rb'sk-ant-[0-9A-Za-z_\-]{20,}'),
            re.compile(rb'sk-(?:proj-)?[0-9A-Za-z_\-]{32,}'),
            re.compile(rb'xai-[0-9A-Za-z]{32,}'),
            re.compile(rb'cf[a-z]{2}_[0-9A-Za-z_\-]{30,}'))    # Cloudflare API 토큰 (2026-10-31)


def _open():
    c = sqlite3.connect(FILE, timeout=30)
    c.execute('CREATE TABLE IF NOT EXISTS secret(name TEXT PRIMARY KEY, val TEXT NOT NULL DEFAULT \'\')')
    return c


def get(name, default=''):
    if not os.path.exists(FILE):
        return default
    try:
        c = _open()
        try:
            r = c.execute('SELECT val FROM secret WHERE name=?', (name,)).fetchone()
        finally:
            c.close()
        return r[0] if r and r[0] is not None else default
    except Exception:
        return default


def row(name):
    """옛 `conn.execute(... sys_config ...).fetchone()` 자리에 그대로 쓰는 꼴 — (값,) 또는 None."""
    v = get(name, None)
    return (v,) if v is not None else None


def put(name, val):
    c = _open()
    try:
        c.execute('INSERT INTO secret(name, val) VALUES(?,?) ON CONFLICT(name) DO UPDATE SET val=excluded.val',
                  (name, val or ''))
        c.commit()
    finally:
        c.close()


def keys_list(name='YOUTUBE_API_KEYS'):
    return [k.strip() for k in (get(name) or '').split(',') if k.strip()]


# ── ② DB 가 거절한다 ────────────────────────────────────────────────────
GUARD_SQL = """
CREATE TRIGGER IF NOT EXISTS trg_sys_config_no_secret_{op}
BEFORE {op} ON sys_config
WHEN NEW.config_key IN ({names})
  OR NEW.config_val GLOB '*AIza[0-9A-Za-z_-]*'
  OR NEW.config_val GLOB '*sk-ant-*'
  OR NEW.config_val GLOB '*sk-proj-*'
BEGIN
  SELECT RAISE(ABORT, 'secret not allowed in sys_config - use secret_store');
END
"""


def install_guard(conn):
    names = ','.join("'%s'" % n for n in NAMES)
    for op in ('INSERT', 'UPDATE'):
        conn.execute(GUARD_SQL.format(op=op, names=names))
    conn.commit()


def migrate(conn):
    """sys_config 에 남은 열쇠를 집으로 옮기고 그 줄을 지운다 → 옮긴 이름들. 멱등.

    ⚠ 집에 이미 값이 있으면 덮지 않는다(관리자가 새로 넣은 값이 이긴다) — 그래도 sys_config 줄은 지운다.
    """
    moved = []
    for n in NAMES:
        r = conn.execute('SELECT config_val FROM sys_config WHERE config_key=?', (n,)).fetchone()
        if r is None:
            continue
        if (r[0] or '').strip() and not get(n):
            put(n, r[0])
        conn.execute('DELETE FROM sys_config WHERE config_key=?', (n,))
        moved.append(n)
    conn.commit()
    install_guard(conn)
    return moved


# ── ③ 내보내기 전에 잰다 ────────────────────────────────────────────────
def _values():
    out = []
    for n in NAMES:
        for k in (get(n) or '').split(','):
            k = k.strip()
            if len(k) >= 12:
                out.append(k.encode('utf-8'))
    return out


def find_leaks(data, blob_free=None):
    """바이트(또는 글)에서 열쇠를 찾는다 → [(무엇, 앞 8글자)] · 빈 목록이면 깨끗하다.

    blob_free — 그림 바이트를 걷은 같은 자료(★ 2026-10-23). 주면 **키 모양** 검사는 그것에만 한다
    (base64 그림 글자가 우연히 AIza… 꼴이 된다). 저장된 열쇠 그대로 찾기는 언제나 data 전체에 한다."""
    if isinstance(data, str):
        data = data.encode('utf-8', 'replace')
    if isinstance(blob_free, str):
        blob_free = blob_free.encode('utf-8', 'replace')
    hits = []
    for v in _values():
        if v in data:
            hits.append(('저장된 열쇠', v[:8].decode('ascii', 'replace')))
    shape = data if blob_free is None else blob_free
    for p in PATTERNS:
        m = p.search(shape)
        if m:
            hits.append(('키 모양', m.group(0)[:8].decode('ascii', 'replace')))
    return hits


def assert_clean(data, what='', blob_free=None):
    """열쇠가 들어 있으면 ValueError — 내보내는 모든 문(팩·배포·올리기)이 부른다."""
    h = find_leaks(data, blob_free)
    if h:
        raise ValueError('⚠ 비밀 열쇠가 들어 있어 내보내지 않습니다 — %s · %s' % (what, ', '.join('%s %s…' % x for x in h)))


def blob_free(b):
    """팩 JSON 이면 그림 바이트(base64 · {"__b64__": …} — db_pack_core.B64)를 걷은 사본 · 아니면 None(★ 2026-10-23).
    키 모양 검사가 그림 글자에 우연히 걸리지 않게 — 팩을 짓는 쪽·올리는 쪽이 같은 문을 쓴다."""
    import json
    try:
        d = json.loads(b)
    except Exception:
        return None

    def go(x):
        if isinstance(x, dict):
            if len(x) == 1 and next(iter(x)) == '__b64__':
                return ''
            return {k: go(v) for k, v in x.items()}
        if isinstance(x, list):
            return [go(v) for v in x]
        return x
    return json.dumps(go(d), ensure_ascii=False).encode('utf-8')


def assert_file_clean(path):
    import gzip
    with open(path, 'rb') as f:
        b = f.read()
    if b[:2] == b'\x1f\x8b':
        try:
            b = gzip.decompress(b)
        except Exception:
            pass
    assert_clean(b, os.path.basename(path), blob_free(b))


def scrub_db(path):
    """배포용 DB 사본에서 열쇠 줄을 지운다(원본은 안 건드린다) → 지운 줄 수."""
    c = sqlite3.connect(path)
    try:
        n = 0
        try:
            n = c.execute('DELETE FROM sys_config WHERE config_key IN (%s)' % ','.join('?' * len(NAMES)),
                          NAMES).rowcount
            c.commit()
        except sqlite3.OperationalError:
            pass
        return n
    finally:
        c.close()


def selftest():
    import tempfile
    global FILE
    ok, tot = 0, 0

    def t(nm, cond, got=''):
        nonlocal ok, tot
        tot += 1
        ok += bool(cond)
        print(('PASS ' if cond else 'FAIL ') + nm + ('' if cond else '  ' + str(got)))
    old = FILE
    d = tempfile.mkdtemp(prefix='secret_st_')
    FILE = os.path.join(d, 's.db')
    try:
        fake = 'AIza' + 'B' * 35
        c = sqlite3.connect(':memory:')
        c.execute('CREATE TABLE sys_config(config_key TEXT PRIMARY KEY, config_val TEXT)')
        c.execute('INSERT INTO sys_config VALUES(?,?)', ('YOUTUBE_API_KEYS', fake + ',' + 'AIza' + 'C' * 35))
        c.execute('INSERT INTO sys_config VALUES(?,?)', ('UI_LANG', 'KO'))
        t('옮긴다', migrate(c) == ['YOUTUBE_API_KEYS'])
        t('sys_config 에 열쇠 줄이 없다', c.execute("SELECT COUNT(*) FROM sys_config WHERE config_key="
                                              "'YOUTUBE_API_KEYS'").fetchone()[0] == 0)
        t('집에서 읽는다', keys_list() == [fake, 'AIza' + 'C' * 35])
        t('row 꼴', row('YOUTUBE_API_KEYS')[0].startswith('AIza') and row('NOPE') is None)
        t('다른 설정은 그대로', c.execute("SELECT config_val FROM sys_config WHERE config_key='UI_LANG'")
          .fetchone()[0] == 'KO')
        for nm, sql, a in (('이름으로 다시 넣기', 'INSERT INTO sys_config VALUES(?,?)', ('GEMINI_API_KEYS', 'x')),
                           ('키 모양 값 넣기', 'INSERT INTO sys_config VALUES(?,?)', ('X_NOTE', 'k=' + fake)),
                           ('고쳐서 넣기', "UPDATE sys_config SET config_val=? WHERE config_key='UI_LANG'", (fake,))):
            try:
                c.execute(sql, a)
                t('② DB 가 거절 — ' + nm, False)
            except sqlite3.DatabaseError:
                t('② DB 가 거절 — ' + nm, True)
        t('② 보통 설정은 막지 않는다', c.execute("UPDATE sys_config SET config_val='EN' WHERE config_key='UI_LANG'")
          .rowcount == 1)
        t('migrate 두 번 — 멱등', migrate(c) == [] and keys_list()[0] == fake)
        t('③ 저장된 열쇠를 찾는다', find_leaks(b'{"v":"%s"}' % fake.encode()) != [])
        t('③ 키 모양을 찾는다', find_leaks('AIza' + 'Z' * 35) != [])
        t('③ 깨끗한 글은 통과', find_leaks('태초에 하나님이 천지를 창조하시니라 AIza') == [])
        try:
            assert_clean(b'x ' + fake.encode(), 'test')
            t('③ assert_clean 이 멈춘다', False)
        except ValueError:
            t('③ assert_clean 이 멈춘다', True)
        p = os.path.join(d, 'dist.db')
        dc = sqlite3.connect(p)
        dc.execute('CREATE TABLE sys_config(config_key TEXT PRIMARY KEY, config_val TEXT)')
        dc.execute("INSERT INTO sys_config VALUES('YOUTUBE_API_KEYS','zz'),('UI_LANG','KO')")
        dc.commit()
        dc.close()
        t('배포 사본 털기', scrub_db(p) == 1)
    finally:
        FILE = old
    print('%d/%d' % (ok, tot))
    return ok == tot


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    if '--migrate' in sys.argv:
        import appdb
        conn = appdb.connect(os.path.join(HERE, 'bible_master.db'))
        print('옮김:', migrate(conn))
        conn.close()
    if '--status' in sys.argv:
        for n in NAMES:
            print(n, len([k for k in (get(n) or '').split(',') if k.strip()]), '개')
