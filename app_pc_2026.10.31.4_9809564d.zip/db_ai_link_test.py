# -*- coding: utf-8 -*-
"""db_ai_link_test — AI 가 구절 연결(VERS_VERS)과 연결 갈래(rel_code)를 얼마나 잘
붙이는지 **사람이 만든 연결과 견주어** 잰다(2026-09-29 296차 · `docs/1.txt` 2번 5)).

사용자 「AI 구절연결은 몇백개 테스트해서 품질 비교하라 · **구절연결 유형분류에 대한
정보를 제공해야 한다**」.

  python db_ai_link_test.py --selftest          자가 검증(API 안 씀)
  python db_ai_link_test.py --plan [N]          표본 N절(기본 300) — 무엇을 보낼지
  python db_ai_link_test.py --run [N]           실제로 보내고 `temp_ai_link_test` 에 담는다
  python db_ai_link_test.py --report            견준 결과 → 화면 + `_ai_link_test.txt`
  python db_ai_link_test.py --review [N]        ★ 연결 점검 시험(317차-5) — 진짜 연결 사이에
                                                **틀린 연결을 심어** AI 가 해제를 추천하나 잰다
  python db_ai_link_test.py --review-report     점검 시험 결과 → `_ai_unlink_test.txt`

★★★ 잣대 — 「AI 가 잘 이었나」는 사람이 읽어야 안다. 기계가 정확히 재는 것은
  **사람이 이미 이어 둔 연결을 AI 가 되찾는가**(되찾음 = recall)와 **AI 가 낸 것 중
  사람 목록에 있는 비율**(겹침률)이다. 사람 목록 밖의 AI 연결은 「틀렸다」가 아니라
  「사람이 안 본 것」일 수 있다 — 보고서가 그 표본을 따로 낸다(사람이 읽는다).
★★★ 갈래 정보 — 열두 갈래(`REL_CODES` · §28-2)를 **정의·예와 함께** 프롬프트에 싣는다.
  갈래 이름만 주면 AI 가 제 뜻으로 읽는다.
⚠ 표본 = 사람이 **셋 이상** 이어 둔 절(창세기 1~34장이 대부분 · §28-9). 그 절만 재야
  「되찾음」이 뜻을 갖는다(이어 둔 것이 없는 절은 견줄 답이 없다).
⚠ 결과 표 `temp_ai_link_test` 는 **로컬**이다(배포·코어 어디에도 안 실린다). 배포
  링크 표(`sys_link_asset`)는 한 줄도 안 건드린다 — 이 도구는 **재기만** 한다.
"""
import io
import json
import os
import re
import sys
import time

APP = os.path.dirname(os.path.abspath(__file__))
if APP not in sys.path:
    sys.path.insert(0, APP)

import db_ai_job as AJ                                    # noqa: E402

#: 열두 갈래 — 단일 소스는 `db_ai_job.REL_CODES`(297차 · 정의·잣대·예)
REL_CODES = [(c, n, w, ex) for c, n, w, _rule, ex in AJ.REL_CODES]
CODES = tuple(r[0] for r in REL_CODES)
MAX_LINKS = 8
TABLE = 'temp_ai_link_test'
REPORT = os.path.join(APP, '_ai_link_test.txt')


def _abbr_list(conn):
    rows = conn.execute("SELECT book_code, short_name FROM book_names WHERE lang_code='KO'"
                        " ORDER BY book_code").fetchall()
    return ' '.join(r[1] for r in rows if r[1])


def ensure(conn):
    conn.execute("CREATE TABLE IF NOT EXISTS %s ("
                 " id INTEGER PRIMARY KEY AUTOINCREMENT, vid INTEGER NOT NULL,"
                 " ref TEXT, target_vid INTEGER, rel TEXT, why TEXT,"
                 " in_human INTEGER, human_rels TEXT, ran_at TEXT)" % TABLE)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_%s_vid ON %s(vid)" % (TABLE, TABLE))
    cols = [r[1] for r in conn.execute("PRAGMA table_info(%s)" % TABLE)]
    if 'round' not in cols:
        conn.execute("ALTER TABLE %s ADD COLUMN round INTEGER NOT NULL DEFAULT 1" % TABLE)


def human_links(conn, vid):
    """그 절의 사람 연결 — `{상대 절: {갈래…}}`(어느 쪽에 적혔든)."""
    out = {}
    for a, b, rel in conn.execute(
            "SELECT clicked_id, target_id, rel_code FROM sys_link_asset"
            " WHERE link_type='VERS_VERS' AND record_status='LIVE'"
            "   AND (clicked_id=? OR target_id=?)", (vid, vid)).fetchall():
        o = b if a == vid else a
        out.setdefault(int(o), set()).add(rel or '')
    return out


def candidates(conn, n=300, min_links=3):
    """사람이 `min_links` 이상 이어 둔 절 — 정경 차례로 앞에서 n개."""
    rows = conn.execute(
        "SELECT v, COUNT(*) c FROM ("
        "  SELECT clicked_id v, target_id o FROM sys_link_asset"
        "   WHERE link_type='VERS_VERS' AND record_status='LIVE'"
        "  UNION SELECT target_id v, clicked_id o FROM sys_link_asset"
        "   WHERE link_type='VERS_VERS' AND record_status='LIVE') x"
        " JOIN bible_index b ON b.verse_id=x.v"
        " GROUP BY v HAVING c>=? ORDER BY b.sort_order LIMIT ?",
        (int(min_links), int(n))).fetchall()
    return [int(r[0]) for r in rows]


def prompt_for(conn, vid, linker=True):
    """보낼 프롬프트 — 기본은 **연결기와 같은 것**(층 + 재료 · 297차). `linker=False`
    면 1회차(296차)의 짧은 프롬프트(옛 결과와 견줄 때)."""
    if linker:
        obj = AJ.compose_prompt(conn, 'VERS_LINK', '', 'NEW', 'KO')
        ctx = AJ.material(conn, 'VERS_LINK', vid, 'NEW', base='KO', lang='KO')
        # ⚠ 시험에서는 「이미 이어진 구절」을 **비운다** — 연결기는 사람 연결을 다시 내지
        #   않게 막지만, 시험은 사람 연결을 **되찾는가**를 재는 것이라 그 정보를 주면
        #   잣대가 무너진다(AI 가 답을 보고 피한다).
        for k in list(ctx):
            if str(k).startswith('이미 이어진 구절'):
                ctx[k] = '(없음)'
        return AJ.render_prompt(obj, ctx)
    return _prompt_v1(conn, vid)


def _prompt_v1(conn, vid):
    ref = AJ._ref(conn, vid)
    ko = AJ._verse_text(conn, vid, 'KRV', 'KO')
    en = AJ._verse_text(conn, vid, 'BSB', 'EN')
    lines = ['당신은 성경의 구절과 구절을 잇는 사람입니다. 아래 구절과 뜻으로 이어지는',
             '다른 구절을 최대 %d개 선택하고, 연결 갈래를 하나 붙이세요.' % MAX_LINKS, '',
             '[구절] %s' % ref, '[개역한글] %s' % ko, '[BSB] %s' % en, '',
             '[연결 갈래 — 반드시 이 열두 코드 가운데 하나]']
    for code, name, what, ex in REL_CODES:
        lines.append('  %s = %s — %s%s' % (code, name, what, (' (예: %s)' % ex) if ex else ''))
    lines += ['',
              '[규칙]',
              '· 두 본문에 실제로 있는 낱말·사건·약속으로만 잇는다. 억지 비유로 잇지 않는다.',
              '· 같은 장 안의 이웃 절은 선택하지 않는다.',
              '· 절 표기는 개역한글 약명으로: %s' % _abbr_list(conn),
              '· 출력은 JSON 배열만. 다른 말은 쓰지 않는다.',
              '  [{"ref": "요 8:12", "rel": "PRG", "why": "한 문장"}, ...]']
    return chr(10).join(lines)


def parse(conn, text, book_map=None):
    """AI 글 → `[(ref, target_vid|None, rel, why)]`. JSON 이 아니면 빈 목록."""
    import scripture_ref_kr as SR
    bm = book_map if book_map is not None else SR.book_map_ko(conn)
    out = []
    for ref, start, rel, why, _raw in AJ.link_lines_parse(conn, text, bm):
        if not ref:
            continue
        out.append((ref, start, rel if rel in CODES else ('?' + rel if rel else '?'), why))
    return out


def run(conn, n=300, model=None, _call=None, sleep=0.0, log=print, round_=2, linker=True):
    """표본 n절을 실제로 보내고 결과를 담는다 — 그 회차에 이미 담긴 절은 건너뛴다(멱등).

    회차 1 = 296차 짧은 프롬프트(JSON) · 회차 2 = **연결기와 같은 프롬프트**(층 + 갈래
    안내 + 이미 이어진 구절). 같은 표본을 두 회차로 담아 `--report` 가 나란히 견준다.
    """
    import ai_client as AC
    ensure(conn)
    call = _call or AC.call
    done = {r[0] for r in conn.execute("SELECT DISTINCT vid FROM %s WHERE round=?" % TABLE,
                                       (int(round_),)).fetchall()}
    vids = [v for v in candidates(conn, n) if v not in done]
    import scripture_ref_kr as SR
    bm = SR.book_map_ko(conn)
    ok = fail = 0
    for i, vid in enumerate(vids, 1):
        res = call(prompt_for(conn, vid, linker=linker), model=model, conn=conn)
        if not res.get('ok'):
            fail += 1
            log('  %d/%d %s 실패: %s' % (i, len(vids), AJ._ref(conn, vid), res.get('why', '')))
            continue
        items = parse(conn, res.get('text', ''), bm)
        hum = human_links(conn, vid)
        now = time.strftime('%Y-%m-%d %H:%M:%S')
        if not items:
            conn.execute("INSERT INTO %s(vid, ref, target_vid, rel, why, in_human, human_rels, ran_at, round)"
                         " VALUES(?,?,?,?,?,?,?,?,?)" % TABLE,
                         (vid, '', None, '', '(못 읽음) ' + (res.get('text') or '')[:200],
                          0, '', now, int(round_)))
        for ref, tv, rel, why in items:
            conn.execute("INSERT INTO %s(vid, ref, target_vid, rel, why, in_human, human_rels, ran_at, round)"
                         " VALUES(?,?,?,?,?,?,?,?,?)" % TABLE,
                         (vid, ref, tv, rel, why, 1 if (tv in hum) else 0,
                          ','.join(sorted(hum.get(tv, ()))) if tv in hum else '', now, int(round_)))
        conn.commit()
        ok += 1
        log('  %d/%d %s — %d개 (사람 목록 겹침 %d)'
            % (i, len(vids), AJ._ref(conn, vid), len(items),
               sum(1 for _r, tv, _rl, _w in items if tv in hum)))
        if sleep:
            time.sleep(sleep)
    return {'sent': len(vids), 'ok': ok, 'fail': fail, 'skipped': len(done)}


def metrics(rows, human):
    """순수 셈 — `rows=[(vid, target_vid, rel)]` · `human={vid: {tv: {rel…}}}`."""
    by = {}
    for vid, tv, rel in rows:
        by.setdefault(vid, []).append((tv, rel))
    n_ai = n_valid = n_hit = n_rel_ok = 0
    recall_num = recall_den = 0
    per_rel = {}
    for vid, its in by.items():
        hum = human.get(vid, {})
        recall_den += len(hum)
        hit_t = set()
        for tv, rel in its:
            n_ai += 1
            if tv is None:
                continue
            n_valid += 1
            if tv in hum:
                n_hit += 1
                hit_t.add(tv)
                if rel in hum[tv]:
                    n_rel_ok += 1
            per_rel.setdefault(rel, [0, 0])
            per_rel[rel][0] += 1
            per_rel[rel][1] += 1 if tv in hum else 0
        recall_num += len(hit_t)
    return {'verses': len(by), 'ai': n_ai, 'valid': n_valid, 'hit': n_hit,
            'rel_ok': n_rel_ok, 'recall_num': recall_num, 'recall_den': recall_den,
            'per_rel': per_rel}


def report(conn, out_path=REPORT):
    ensure(conn)
    L = []
    rounds = [r[0] for r in conn.execute("SELECT DISTINCT round FROM %s ORDER BY round" % TABLE)]
    for rd in rounds:
        L += _report_round(conn, rd)
        L.append('')
    txt = chr(10).join(L)
    io.open(out_path, 'w', encoding='utf-8').write(txt + chr(10))
    m = _metrics_round(conn, rounds[-1]) if rounds else metrics([], {})
    return txt, m


def _metrics_round(conn, rd):
    rows = conn.execute("SELECT vid, target_vid, rel FROM %s WHERE ref<>'' AND round=?" % TABLE,
                        (rd,)).fetchall()
    vids = sorted({r[0] for r in rows})
    human = {v: human_links(conn, v) for v in vids}
    return metrics([(int(a), (int(b) if b is not None else None), c) for a, b, c in rows], human)


def _report_round(conn, rd):
    m = _metrics_round(conn, rd)
    L = []
    L.append('[%d회차 — %s] AI 구절연결 시험 — 표본 %d절 · AI 연결 %d개(절 표기가 풀린 것 %d)'
             % (rd, '연결기 프롬프트(층+갈래 잣대+이미 이어진 구절)' if rd >= 2 else '짧은 프롬프트(JSON)',
                m['verses'], m['ai'], m['valid']))
    if m['valid']:
        L.append('  겹침률(AI 연결 중 사람 목록에 있는 것): %d / %d = %.1f%%'
                 % (m['hit'], m['valid'], 100.0 * m['hit'] / m['valid']))
    if m['recall_den']:
        L.append('  되찾음(사람 연결 중 AI 가 낸 것): %d / %d = %.1f%%'
                 % (m['recall_num'], m['recall_den'], 100.0 * m['recall_num'] / m['recall_den']))
    if m['hit']:
        L.append('  갈래 일치(겹친 것 가운데 rel_code 가 사람과 같은 것): %d / %d = %.1f%%'
                 % (m['rel_ok'], m['hit'], 100.0 * m['rel_ok'] / m['hit']))
    if m['ai'] - m['valid']:
        L.append('  절 표기를 못 푼 것: %d (%.1f%%)' % (m['ai'] - m['valid'],
                                                  100.0 * (m['ai'] - m['valid']) / m['ai']))
    # 규칙 위반 — 같은 장 안의 절(프롬프트가 금지한 것)
    same = conn.execute(
        "SELECT COUNT(*) FROM %s t JOIN bible_index a ON a.verse_id=t.vid"
        " JOIN bible_index b ON b.verse_id=t.target_vid"
        " WHERE a.bcode=b.bcode AND a.chapter=b.chapter AND t.round=?" % TABLE, (rd,)).fetchone()[0]
    if m['valid']:
        L.append('  같은 장 안의 절로 이은 것(규칙 위반): %d (%.1f%%)' % (same, 100.0 * same / m['valid']))
    L.append('  갈래별 — AI 가 붙인 수 / 그중 사람 목록 겹침:')
    for rel, (a, h) in sorted(m['per_rel'].items(), key=lambda x: -x[1][0]):
        L.append('    %-4s %4d / %4d' % (rel, a, h))
    # 사람 목록 밖 표본 — 사람이 읽을 자리
    ext = conn.execute("SELECT vid, ref, rel, why FROM %s WHERE in_human=0 AND target_vid IS NOT NULL"
                       " AND round=? ORDER BY id LIMIT 40" % TABLE, (rd,)).fetchall()
    L.append('')
    L.append('사람 목록 밖 AI 연결 표본(앞 %d) — 틀린 것인지 사람이 안 본 것인지는 읽어야 안다:'
             % len(ext))
    for vid, ref, rel, why in ext:
        L.append('  %s → %s [%s] %s' % (AJ._ref(conn, vid), ref, rel, (why or '')[:70]))
    hit = conn.execute("SELECT vid, ref, rel, human_rels FROM %s WHERE in_human=1"
                       " AND round=? ORDER BY id LIMIT 20" % TABLE, (rd,)).fetchall()
    L.append('')
    L.append('겹친 것 표본(앞 %d) — AI 갈래 / 사람 갈래:' % len(hit))
    for vid, ref, rel, hr in hit:
        L.append('  %s → %s  %s / %s' % (AJ._ref(conn, vid), ref, rel, hr))
    return L


# ══════════════════════════════════════════════════════════════════════════
# ★★★ 317차-5 — **연결 점검 시험**(docs/1.txt 4 구절연결기 2)(2) · 사용자 「100회 돌려라」)
#   「AI 가 부적절한 연결관계를 잘 판단하는지, 연결유형 코드가 부적절한지를 판단하는지」.
#   잣대를 기계가 정확히 알도록 **틀린 것을 우리가 심는다**:
#     PLANT = 다른 책의 아무 절을 아무 갈래로 이은 것 → **해제**가 정답
#     SWAP  = 진짜 연결의 갈래를 다른 코드로 바꾼 것 → **바꿈**(원래 갈래면 더 좋다)
#     REAL  = 진짜 연결 그대로 → **유지**가 정답(해제하면 헛해제)
#   ⚠ 심는 것은 **프롬프트 재료에만** — DB 링크 표는 한 줄도 안 건드린다.
#   ⚠ 프롬프트는 연결기 다듬기(점검)와 **같은 것**(`compose_prompt` + `link_review_material`).
# ══════════════════════════════════════════════════════════════════════════
UTABLE = 'temp_ai_unlink_test'
UREPORT = os.path.join(APP, '_ai_unlink_test.txt')
REAL_MAX = 10


def uensure(conn):
    conn.execute("CREATE TABLE IF NOT EXISTS %s ("
                 " id INTEGER PRIMARY KEY AUTOINCREMENT, vid INTEGER NOT NULL, target_vid INTEGER,"
                 " shown_rel TEXT, truth TEXT, orig_rel TEXT, verdict TEXT, new_rel TEXT, why TEXT,"
                 " ran_at TEXT)" % UTABLE)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_%s_vid ON %s(vid)" % (UTABLE, UTABLE))


def review_sample(conn, n=100):
    """표본 — 사람 연결 셋 이상인 절에서 **고르게 흩어** n절(창세기에만 몰리지 않게)."""
    pool = candidates(conn, 5000)
    if len(pool) <= n:
        return pool
    step = len(pool) / float(n)
    return [pool[int(i * step)] for i in range(n)]


def review_case(conn, vid):
    """그 절의 점검 재료 — `[(상대 절, 보여 줄 갈래, truth, 원래 갈래)]`(섞은 차례)."""
    import random
    rng = random.Random(int(vid) * 7919)
    real = [(o, rel) for _l, o, rel, _s in AJ.review_links(conn, vid)]
    rng.shuffle(real)
    real = real[:REAL_MAX]
    rows = [(o, rel, 'REAL', rel) for o, rel in real]
    if rows:
        o, rel, _t, _r = rows[0]
        rows[0] = (o, rng.choice([c for c in CODES if c != rel]), 'SWAP', rel)
    me = conn.execute("SELECT bcode FROM bible_index WHERE verse_id=?", (vid,)).fetchone()[0]
    linked = {o for o, _r in real} | {vid}
    mx = conn.execute("SELECT MAX(verse_id) FROM bible_index").fetchone()[0]
    planted = 0
    while planted < 2:
        tv = rng.randint(1, mx)
        r = conn.execute("SELECT bcode FROM bible_index WHERE verse_id=?", (tv,)).fetchone()
        if not r or r[0] == me or tv in linked or not AJ._verse_text(conn, tv, 'KRV', 'KO'):
            continue
        rows.append((tv, rng.choice(CODES), 'PLANT', ''))
        linked.add(tv)
        planted += 1
    rng.shuffle(rows)
    return rows


def review_prompt(conn, vid, rows):
    obj = AJ.compose_prompt(conn, 'VERS_LINK', '', 'EDIT', 'KO')
    ctx = AJ.link_review_material(conn, vid, links=[(o, rel) for o, rel, _t, _r in rows])
    return AJ.render_prompt(obj, ctx)


def review_run(conn, n=100, model=None, _call=None, log=print):
    """표본 n절을 보내고 판정을 담는다 — 이미 담긴 절은 건너뛴다(멱등)."""
    import ai_client as AC
    import scripture_ref_kr as SR
    uensure(conn)
    call = _call or AC.call
    bm = SR.book_map_ko(conn)
    done = {r[0] for r in conn.execute("SELECT DISTINCT vid FROM %s" % UTABLE)}
    vids = [v for v in review_sample(conn, n) if v not in done]
    ok = fail = 0
    for i, vid in enumerate(vids, 1):
        rows = review_case(conn, vid)
        res = call(review_prompt(conn, vid, rows), model=model, conn=conn)
        if not res.get('ok'):
            fail += 1
            log('  %d/%d %s 실패: %s' % (i, len(vids), AJ._ref(conn, vid), res.get('why', '')))
            continue
        got = {}
        for ref, tv, rel, verdict, new, why in AJ.link_review_parse(conn, res.get('text', ''), bm):
            if tv is not None and verdict:
                got[(tv, rel)] = (verdict, new, why)
        now = time.strftime('%Y-%m-%d %H:%M:%S')
        for o, rel, truth, orig in rows:
            v, nw, why = got.get((o, rel), ('', '', ''))
            conn.execute("INSERT INTO %s(vid, target_vid, shown_rel, truth, orig_rel, verdict, new_rel, why, ran_at)"
                         " VALUES(?,?,?,?,?,?,?,?,?)" % UTABLE,
                         (vid, o, rel, truth, orig, v, nw, why, now))
        conn.commit()
        ok += 1
        hit = sum(1 for o, rel, t, _r in rows if t == 'PLANT' and got.get((o, rel), ('',))[0] == '해제')
        log('  %d/%d %s — 줄 %d · 심은 것 해제 %d/2' % (i, len(vids), AJ._ref(conn, vid), len(rows), hit))
    return {'sent': len(vids), 'ok': ok, 'fail': fail, 'skipped': len(done)}


def review_report(conn, out_path=UREPORT):
    uensure(conn)
    rows = conn.execute("SELECT vid, target_vid, shown_rel, truth, orig_rel, verdict, new_rel, why"
                        " FROM %s ORDER BY id" % UTABLE).fetchall()
    L = []
    nv = len({r[0] for r in rows})

    def cnt(truth, verdict=None):
        return sum(1 for r in rows if r[3] == truth and (verdict is None or r[5] == verdict))
    pc, sc, rc = cnt('PLANT'), cnt('SWAP'), cnt('REAL')
    pct = lambda a, b: ('%.1f%%' % (100.0 * a / b)) if b else '-'
    L.append('연결 점검 시험 — 표본 %d절 · 판정 줄 %d' % (nv, len(rows)))
    L.append('')
    L.append('[심은 틀린 연결 PLANT %d] 해제 %d (%s) · 바꿈 %d · 유지 %d · 판정 없음 %d'
             % (pc, cnt('PLANT', '해제'), pct(cnt('PLANT', '해제'), pc), cnt('PLANT', '바꿈'),
                cnt('PLANT', '유지'), cnt('PLANT', '')))
    back = sum(1 for r in rows if r[3] == 'SWAP' and r[5] == '바꿈' and r[6] == r[4])
    L.append('[갈래를 바꿔 심은 SWAP %d] 바꿈 %d (%s) · 그중 원래 갈래로 %d (%s) · 해제 %d · 유지 %d · 없음 %d'
             % (sc, cnt('SWAP', '바꿈'), pct(cnt('SWAP', '바꿈'), sc), back, pct(back, sc),
                cnt('SWAP', '해제'), cnt('SWAP', '유지'), cnt('SWAP', '')))
    L.append('[진짜 연결 REAL %d] 유지 %d (%s) · 헛해제 %d (%s) · 바꿈 %d (%s) · 없음 %d'
             % (rc, cnt('REAL', '유지'), pct(cnt('REAL', '유지'), rc), cnt('REAL', '해제'),
                pct(cnt('REAL', '해제'), rc), cnt('REAL', '바꿈'), pct(cnt('REAL', '바꿈'), rc), cnt('REAL', '')))
    from collections import Counter
    L.append('')
    L.append('진짜 연결을 바꾸자 한 갈래(지금 → 새) 상위: ' + ' · '.join(
        '%s→%s %d' % (k[0], k[1], v) for k, v in Counter(
            (r[2], r[6]) for r in rows if r[3] == 'REAL' and r[5] == '바꿈').most_common(8)))
    for title, cond in (('── 심은 연결인데 유지한 것(놓침) 표본', lambda r: r[3] == 'PLANT' and r[5] == '유지'),
                        ('── 진짜 연결을 해제하자 한 것(사람이 읽을 것) 표본', lambda r: r[3] == 'REAL' and r[5] == '해제'),
                        ('── 진짜 연결의 갈래를 바꾸자 한 것 표본', lambda r: r[3] == 'REAL' and r[5] == '바꿈')):
        L.append('')
        L.append(title)
        for r in [r for r in rows if cond(r)][:25]:
            L.append('  %s → %s · %s%s · %s' % (AJ._ref(conn, r[0]), AJ._ref(conn, r[1]), r[2],
                                                (' → ' + r[6]) if r[6] else '', (r[7] or '')[:80]))
    txt = chr(10).join(L)
    try:
        io.open(out_path, 'w', encoding='utf-8').write(txt + chr(10))
    except OSError:
        pass
    return txt


def selftest():
    bad = []
    n = [0]

    def ck(c, m):
        n[0] += 1
        if not c:
            bad.append(m)
    ck(len(REL_CODES) == 12 and len(set(CODES)) == 12, '갈래 열둘')
    ck({'PRG', 'DEP', 'INC', 'REV', 'TYP', 'FUL', 'ALL', 'PAR', 'REF', 'SUP', 'SYN', 'COV'} == set(CODES),
       '§28-2 의 열두 코드 그대로')
    import appdb
    conn = appdb.connect()
    vid = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=1 AND chapter=1 AND verse=1").fetchone()[0]
    p = prompt_for(conn, vid)
    ck(all(code in p for code in CODES) and '예표' in p and '억지 비유' in p, '프롬프트에 열두 갈래 정의와 규칙이 든다')
    ck('창 출 레' in p, '약명 목록이 프롬프트에 든다')
    items = parse(conn, '여기 답입니다 ```json\n[{"ref":"요 1:1","rel":"PRG","why":"말씀"},'
                        '{"ref":"없는책 1:1","rel":"TYP","why":"x"},{"ref":"시 33:6","rel":"XYZ","why":"y"}]```')
    ck(len(items) == 3 and items[0][1] is not None and items[0][2] == 'PRG', '코드 울타리 속 JSON 을 푼다: %s' % (items[:1],))
    ck(items[1][1] is None, '모르는 책은 None')
    ck(items[2][2].startswith('?'), '열둘 밖 갈래는 ? 표식')
    ck(parse(conn, '그냥 말') == [], 'JSON 이 아니면 빈 목록')
    # 셈 — 양방향
    human = {1: {10: {'PRG'}, 11: {'TYP', 'ALL'}, 12: {'REF'}}}
    m = metrics([(1, 10, 'PRG'), (1, 11, 'PRG'), (1, 99, 'ALL'), (1, None, 'ALL')], human)
    ck(m['valid'] == 3 and m['hit'] == 2 and m['rel_ok'] == 1 and m['recall_num'] == 2 and m['recall_den'] == 3,
       '겹침 2 · 갈래 일치 1 · 되찾음 2/3: %s' % m)
    m2 = metrics([(1, 10, 'PRG'), (1, 11, 'TYP'), (1, 12, 'REF')], human)
    ck(m2['hit'] == 3 and m2['rel_ok'] == 3 and m2['recall_num'] == 3, '전부 맞으면 전부 센다')
    # run — 가짜 호출로 한 절 · 표는 임시 이름으로 · 자국 0
    global TABLE
    old_t = TABLE
    TABLE = 'temp_ai_link_test__selftest'
    try:
        conn.execute("DROP TABLE IF EXISTS %s" % TABLE)
        fake = lambda prompt, model=None, conn=None: {'ok': True, 'text': '[{"ref":"요 1:1","rel":"PRG","why":"말씀"}]'}
        r = run(conn, n=1, _call=fake, log=lambda *_a: None, round_=2)
        ck(r['ok'] == 1, '가짜 호출 한 절: %s' % r)
        r2 = run(conn, n=1, _call=fake, log=lambda *_a: None, round_=2)
        ck(r2['sent'] == 0 and r2['skipped'] == 1, '두 번째는 건너뛴다(멱등)')
        _pl = prompt_for(conn, candidates(conn, 1)[0])
        ck('잣대' in _pl and '이미 이어진 구절' in _pl and 'PRG' in _pl,
           '시험 프롬프트 = 연결기 프롬프트(갈래 잣대·이미 이어진 구절)')
        txt, mm = report(conn, out_path=os.path.join(APP, '_ai_link_test__selftest.txt'))
        ck('표본 1절' in txt and mm['ai'] == 1 and '2회차' in txt, '보고서가 회차마다 나온다')
        cnt = conn.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
    finally:
        conn.execute("DROP TABLE IF EXISTS %s" % TABLE)
        conn.commit()
        TABLE = old_t
        try:
            os.remove(os.path.join(APP, '_ai_link_test__selftest.txt'))
        except OSError:
            pass
    ck(conn.execute("SELECT name FROM sqlite_master WHERE name='temp_ai_link_test__selftest'").fetchone() is None,
       '시험 표 자국 0')
    # ★ 317차-5 — 점검 시험: 가짜 호출 한 절 · 심은 것 둘 · SWAP 하나 · 자국 0
    global UTABLE
    old_u = UTABLE
    UTABLE = 'temp_ai_unlink_test__selftest'
    try:
        conn.execute("DROP TABLE IF EXISTS %s" % UTABLE)
        v0 = review_sample(conn, 1)[0]
        rows = review_case(conn, v0)
        ck(sum(1 for r in rows if r[2] == 'PLANT') == 2 and sum(1 for r in rows if r[2] == 'SWAP') == 1,
           '점검 재료 — 심은 것 둘 · 갈래 바꾼 것 하나')
        ck(review_case(conn, v0) == rows, '같은 절이면 같은 재료(되풀이 가능)')
        pr = review_prompt(conn, v0, rows)
        ck('해제' in pr and '바꿈' in pr and all(AJ._ref(conn, o) in pr for o, _r, _t, _o in rows),
           '점검 프롬프트에 판정 규칙과 줄 전부가 든다')

        def fake(prompt, model=None, conn=None, _rows=rows):
            out = []
            for o, rel, t, orig in _rows:
                v = {'PLANT': '해제', 'SWAP': '바꿈:%s' % orig, 'REAL': '유지'}[t]
                out.append('%s · %s · %s · 시험입니다.' % (AJ._ref(conn, o), rel, v))
            return {'ok': True, 'text': chr(10).join(out)}
        r = review_run(conn, n=1, _call=fake, log=lambda *_a: None)
        ck(r['ok'] == 1, '점검 가짜 호출 한 절: %s' % r)
        t = review_report(conn, out_path=os.path.join(APP, '_ai_unlink_test__selftest.txt'))
        ck('해제 2 (100.0%)' in t and '원래 갈래로 1 (100.0%)' in t, '점검 보고서가 맞힌 것을 센다: %s' % t[:200])
    finally:
        conn.execute("DROP TABLE IF EXISTS %s" % UTABLE)
        conn.commit()
        UTABLE = old_u
        try:
            os.remove(os.path.join(APP, '_ai_unlink_test__selftest.txt'))
        except OSError:
            pass
    ck(cnt == conn.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0], '배포 링크 표 불변')
    conn.close()
    for b in bad:
        print('  FAIL', b)
    print('db_ai_link_test selftest: %s (%d/%d)' % ('OK' if not bad else 'FAIL', n[0] - len(bad), n[0]))
    return 0 if not bad else 1


def _main(argv):
    if '--selftest' in argv:
        return selftest()
    import appdb
    conn = appdb.connect()

    def _n(flag, default):
        i = argv.index(flag)
        return int(argv[i + 1]) if len(argv) > i + 1 and argv[i + 1].isdigit() else default
    if '--plan' in argv:
        vs = candidates(conn, _n('--plan', 300))
        print('표본 %d절 (사람 연결 3개 이상 · 정경 차례)' % len(vs))
        for v in vs[:10]:
            print('  ', AJ._ref(conn, v), '사람 연결', len(human_links(conn, v)))
        print('… 프롬프트 보기(첫 절):')
        print(prompt_for(conn, vs[0]) if vs else '')
        return 0
    if '--run' in argv:
        r = run(conn, _n('--run', 300), round_=_n('--round', 2), linker='--v1' not in argv)
        print('보냄 %(sent)d · 받음 %(ok)d · 실패 %(fail)d · 이미 있어 건너뜀 %(skipped)d' % r)
        txt, _m = report(conn)
        print(txt)
        return 0
    if '--review' in argv:
        r = review_run(conn, _n('--review', 100))
        print('보냄 %(sent)d · 받음 %(ok)d · 실패 %(fail)d · 이미 있어 건너뜀 %(skipped)d' % r)
        print(review_report(conn))
        return 0
    if '--review-report' in argv:
        print(review_report(conn))
        return 0
    if '--report' in argv:
        txt, _m = report(conn)
        print(txt)
        return 0
    print(__doc__)
    return 0


if __name__ == '__main__':
    sys.exit(_main(sys.argv[1:]))
