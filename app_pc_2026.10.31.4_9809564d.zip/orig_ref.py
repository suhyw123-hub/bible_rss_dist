# -*- coding: utf-8 -*-
"""orig_ref — 글 안의 원어 표기를 원어(스트롱 번호)로 읽는다 (2026-10-25 신설·영구 · `--selftest` 의무).

★ 사용자 지시 — 「연구설교자료에 구절뿐만 아니라 원어 넣기가 가능하다. 원어를 넣은 경우 자동으로
  원어/용어와 연결추천도 작동해야 한다. PC/폰 모두 공통」 · 「승격되지 않은 원어도 스트롱번호가 있다면
  연결 가능할 것 같다 … 승격안된 원어도 연결하자」.
★★ 읽는 꼴 = 원어 넣기 서식(`cite_format.ORIG`)이 만드는 「앞말(괄호 안 하나 또는 둘)」:
    은혜(카리스) · 은혜(카리스, χάρις) · 은혜(카리스, charis) · 카리스(χάρις) · 은혜(χάρις, G5485) · 은혜(카리스, G5485)
  괄호 안 낱말마다 확실한 것부터 본다 — ① 스트롱 번호 ② 원어 글자(낱자·악센트를 걷고 견준다)
  ③ 음독(한국어 음독 = 주요용어 앵커 · 라틴 음역 = 원어 사전). ③ 은 **앞말이 뜻과 맞거나 그 음독이 하나뿐일 때만**
  받는다 — 음역은 서로 겹친다(실측 shûwr 5곳).
★★ 결과 갈래 — 그 원어가 주요용어로 승격돼 있으면 `ENTITY`(그 용어) · 아니면 `LEMMA`(열쇠 = `user_ai.lemma_key`).
⚠ 맞힐 자신이 없으면 **내지 않는다** — 추천이 틀리면 사람이 하나씩 지워야 한다(조용한 오답보다 빈 추천이 낫다).
⚠ 폰 `lib/data/orig_ref.dart` 가 같은 규칙을 옮긴다 — 규칙을 바꾸면 둘 다(시험 벡터 `--vectors`).

    python orig_ref.py --selftest
    python orig_ref.py --find "은혜(카리스)와 인애(헤세드, H2617)"
"""
import re
import sys
import unicodedata

STRONG = re.compile(r'^[HG]\d{1,5}$', re.I)
#: 앞말(괄호 바로 앞 낱말 · 공백 하나까지) + 괄호 안(쉼표로 하나 또는 둘)
PAT = re.compile(r'([^\s()（）\[\]{}<>「」『』,.;:!?"“”]{1,24})\s?[(（]([^()（）\n]{1,48})[)）]')
_HEB_GRK = re.compile(r'[Ͱ-Ͽἀ-῿֐-׿]')


def norm_form(s):
    """원어 글자 견주기 — 히브리 점·악센트·헬라 악센트를 걷는다."""
    t = unicodedata.normalize('NFD', s or '')
    t = ''.join(ch for ch in t if not unicodedata.combining(ch) and not ('֑' <= ch <= 'ׇ'))
    return t.replace('ς', 'σ').lower().strip()


def exact_form(s):
    """원어 글자 그대로(NFC · 끝 시그마만 맞춘다) — εἰς 와 εἷς 를 가른다."""
    return unicodedata.normalize('NFC', (s or '').strip()).replace('ς', 'σ').lower()


def norm_tr(s):
    """음독 견주기 — 악센트·기호(ʻ ʼ ᵉ · - 공백)를 걷고 글자만 · 소문자."""
    t = unicodedata.normalize('NFD', s or '')
    t = ''.join(ch for ch in t if not unicodedata.combining(ch))
    t = ''.join(ch for ch in t if ch.isalnum() and ch not in 'ᵉᵒᵃ')
    return unicodedata.normalize('NFC', t).lower()


_IDX = {}
_EXTRA = {}
_LOOSE = {}

#: 라틴 음역 느슨한 견주기 — 사전 표기(cheçed · shâlôwm · bᵉrîyth)와 사람이 치는 꼴(hesed · shalom · berith)을 맞춘다
_LOOSE_SUB = (('ch', 'h'), ('kh', 'h'), ('ph', 'f'), ('th', 't'), ('sh', 's'), ('ts', 's'), ('tz', 's'),
              ('c', 's'), ('q', 'k'), ('w', ''), ('y', 'i'), ('j', 'i'))


def loose_tr(s):
    """라틴 음역 → 느슨한 열쇠(악센트·기호 걷고 · 소리가 같은 글자 묶고 · 겹친 글자 하나로). 라틴 글자가 없으면 ''."""
    t = unicodedata.normalize('NFD', s or '')
    t = ''.join(ch for ch in t if not unicodedata.combining(ch)).lower()
    t = ''.join(ch for ch in t if 'a' <= ch <= 'z')
    for a, b in _LOOSE_SUB:
        t = t.replace(a, b)
    out = []
    for ch in t:
        if not out or out[-1] != ch:
            out.append(ch)
    return ''.join(out)


def _loose_index(conn):
    key = id(conn)
    if key not in _LOOSE:
        idx = {}
        try:
            for st, t in conn.execute("SELECT strong, translit FROM sys_lemma_master WHERE translit<>''"
                                      " AND COALESCE(record_status,'LIVE')='LIVE'"):
                k = loose_tr(t)
                if k:
                    idx.setdefault(k, set()).add((st or '').upper())
        except Exception:                                 # noqa: BLE001
            pass
        _LOOSE[key] = idx
    return _LOOSE[key]


def _index(conn):
    """한 연결에 한 번 — 원어 사전 1만 4천 줄 · 용어 앵커 1만 1천 줄."""
    key = id(conn)
    if key in _IDX:
        return _IDX[key]
    form, tr, ent, gloss, exact, occ = {}, {}, {}, {}, {}, {}
    try:
        for st, f, t, g, n in conn.execute(
                "SELECT strong, form, translit, gloss, occurrences FROM sys_lemma_master"
                " WHERE COALESCE(record_status,'LIVE')='LIVE'"):
            st = (st or '').upper()
            if not st:
                continue
            occ[st] = int(n or 0)
            if f:
                form.setdefault(norm_form(f), set()).add(st)
                exact.setdefault(exact_form(f), set()).add(st)
            if t:
                tr.setdefault(norm_tr(t), set()).add(st)
            gloss[st] = (g or '').lower()
    except Exception:                                     # noqa: BLE001
        pass
    names = {}
    try:
        for eid, nm in conn.execute(
                "SELECT clicked_id, contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
                " AND COALESCE(record_status,'LIVE')='LIVE'"):
            names.setdefault(int(eid), set()).add(nm or '')
    except Exception:                                     # noqa: BLE001
        pass
    try:
        for eid, st, t, g in conn.execute(
                "SELECT l.entity_id, l.strong, l.translit, l.gloss FROM sys_entity_lemma l"
                " JOIN sys_entity_master m ON m.entity_id=l.entity_id"
                " WHERE COALESCE(l.record_status,'LIVE')='LIVE' AND COALESCE(m.record_status,'LIVE')='LIVE'"
                " ORDER BY l.sort_order, l.lemma_id"):
            st = (st or '').upper()
            if not st:
                continue
            ent.setdefault(st, int(eid))
            if t:
                tr.setdefault(norm_tr(t), set()).add(st)
            words = {(g or '')} | names.get(int(eid), set())
            gloss[st] = gloss.get(st, '') + ' ' + ' '.join(w.lower() for w in words)
    except Exception:                                     # noqa: BLE001
        pass
    _IDX[key] = (form, tr, ent, gloss)
    _EXTRA[key] = (exact, occ)
    return _IDX[key]


def _means(word, st, gloss):
    w = (word or '').strip().lower()
    return bool(w) and len(w) >= 1 and w in gloss.get(st, '')


def resolve(conn, head, inside, sure_only=False):
    """앞말 하나와 괄호 안 글 → (스트롱 번호, 확실한가) 또는 (None, False).

    확실 = 번호 · 하나뿐인 원어 글자/음독 · 앞말 뜻이 맞음 · 원어 글자와 음독이 함께 가리킴.
    짐작 = 철자가 같은 번호가 여럿(히브리·아람어 짝 · 이름과 낱말) — 가장 많이 나오는 것(승격 용어 먼저).
    ★ 짐작은 **추천으로만** 쓴다(사람이 체크해 확정) · AI 자동 연결은 확실한 것만.
    """
    form, tr, ent, gloss = _index(conn)
    exact, occ = _EXTRA.get(id(conn), ({}, {}))
    parts = [p.strip() for p in re.split(r'[,，、]', inside or '') if p.strip()]
    if not parts or len(parts) > 3:
        return None, False
    for p in parts:                                    # ① 번호
        if STRONG.match(p):
            return p.upper(), True
    cands = []                                         # 낱말마다 후보 묶음
    for p in parts + [head]:
        if _HEB_GRK.search(p or ''):
            hit = exact.get(exact_form(p)) or form.get(norm_form(p)) or set()
            if hit:
                cands.append(set(hit))
    for p in parts:
        if not _HEB_GRK.search(p):
            hit = tr.get(norm_tr(p)) or set()
            if not hit and len(loose_tr(p)) >= 3:            # ★ 2026-10-25 사람이 치는 영어 음독(hesed · shalom)
                hit = _loose_index(conn).get(loose_tr(p)) or set()
            if hit:
                cands.append(set(hit))
    if not cands:
        return None, False
    pool = set.intersection(*cands) if len(cands) > 1 else cands[0]
    if not pool:                                       # 서로 엇갈리면 원어 글자를 믿는다
        pool = cands[0]
    if len(pool) == 1:
        st = next(iter(pool))
        # 음독 하나만 맞은 것인데 앞말이 그 용어 뜻과 다르면 맞힌 게 아니다(승격 용어만 뜻을 견줄 수 있다)
        if len(cands) == 1 and not any(_HEB_GRK.search(p) for p in parts + [head])                 and st in ent and head and not _means(head, st, gloss) and not re.search('[A-Za-z]', head):
            return None, False
        return st, True
    meant = [x for x in pool if _means(head, x, gloss)]
    if len(meant) == 1:
        return meant[0], True
    if sure_only:
        return None, False
    pick = sorted(meant or pool, key=lambda x: (x not in ent, -occ.get(x, 0), x))
    return pick[0], False


def find(conn, text, lang='KO', limit=200, sure_only=False):
    """글 → `[(kind, target_id, matched, strong)]` (`find_full` 에서 확실 여부를 뺀 것)."""
    return [r[:4] for r in find_full(conn, text, lang, limit, sure_only)]


def find_full(conn, text, lang='KO', limit=200, sure_only=False):
    """글 → `[(kind, target_id, matched, strong)]` (나온 차례 · 같은 원어는 한 번).
    kind = 'ENTITY'(승격된 주요용어) · 'LEMMA'(승격 안 된 원어 · target = lemma_key).
    `sure_only` = 짐작은 뺀다(AI 답을 저장할 때의 자동 연결)."""
    out, seen = [], set()
    _form, _tr, ent, _g = _index(conn)
    for m in PAT.finditer(text or ''):
        st, sure = resolve(conn, m.group(1).lstrip("'‘’\"“"), m.group(2), sure_only=sure_only)
        if not st or st in seen:
            continue
        seen.add(st)
        if st in ent:
            out.append(('ENTITY', ent[st], m.group(0), st, sure))
        else:
            k = lemma_key(st)
            if k is not None:
                out.append(('LEMMA', k, m.group(0), st, sure))
        if len(out) >= limit:
            break
    return out


def lemma_key(strong):
    s = (strong or '').strip().upper()
    if len(s) < 2 or s[0] not in 'HG' or not s[1:].isdigit():
        return None
    return (1000000 if s[0] == 'H' else 2000000) + int(s[1:])


def strong_of(key):
    """lemma_key → 스트롱 번호(H2617)."""
    try:
        k = int(key)
    except Exception:                                     # noqa: BLE001
        return ''
    if 1000000 < k < 2000000:
        return 'H%d' % (k - 1000000)
    if k > 2000000:
        return 'G%d' % (k - 2000000)
    return ''


def label(conn, kind, tid, lang='KO'):
    """화면 이름 — 용어면 그 이름 · 원어면 「χάρις charis (G5485)」."""
    if kind == 'LEMMA':
        st = strong_of(tid)
        try:
            r = conn.execute("SELECT form, translit FROM sys_lemma_master WHERE strong=?", (st,)).fetchone()
        except Exception:                                 # noqa: BLE001
            r = None
        return ('%s %s (%s)' % (r[0] or '', r[1] or '', st)).strip() if r else st
    for lg in ((lang or 'KO').upper(), 'EN', 'KO'):
        try:
            r = conn.execute("SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
                             " AND clicked_id=? AND UPPER(lang_code)=? LIMIT 1", (int(tid), lg)).fetchone()
        except Exception:                                 # noqa: BLE001
            r = None
        if r and r[0]:
            return r[0]
    return str(tid)


def canon(conn, kind, tid):
    """폰이 보낸 (갈래, 번호)를 PC 에서 바로 세운다 — 폰 팩에 없는 용어로 승격된 원어는 폰이 LEMMA 로 보낸다.
    LEMMA 인데 그 번호가 이 PC 에서 승격돼 있으면 ('ENTITY', 그 용어) · 그 밖은 그대로."""
    if kind != 'LEMMA':
        return kind, tid
    st = strong_of(tid)
    ent = _index(conn)[2]
    if st and st in ent:
        return 'ENTITY', ent[st]
    return kind, tid


# ── 폰으로 옮기기 ─────────────────────────────────────────────────────────────
#  다트에는 유니코드 정규화가 없다 — PC 가 **분해 표 · 결합 등급 표**를 만들어 다트 파일로 내보낸다.
#  그러면 폰의 NFD 가 파이썬 unicodedata 와 글자 하나까지 같다(한글 음절은 분해해도 다시 붙으므로 뺀다).
DART_FOLD = 'mobile/lib/data/orig_fold.dart'
DART_VECTORS = 'mobile/test/fixtures/orig_vectors.json'


def dart_fold():
    dec, ccc = {}, {}
    for cp in range(0x80, 0x30000):
        if 0xAC00 <= cp <= 0xD7A3 or 0xD800 <= cp <= 0xDFFF:
            continue
        ch = chr(cp)
        d = unicodedata.normalize('NFD', ch)
        if d != ch:
            dec[cp] = [ord(x) for x in d]
        c = unicodedata.combining(ch)
        if c:
            ccc[cp] = c
    out = ['// 자동 생성 — python orig_ref.py --dart (파이썬 unicodedata %s). 손으로 고치지 말 것.'
           % unicodedata.unidata_version,
           '// ignore_for_file: lines_longer_than_80_chars', '',
           '/// 글자 하나 → NFD(완전 분해) 코드 포인트들',
           'const Map<int, List<int>> foldDecomp = {']
    line = []
    for cp in sorted(dec):
        line.append('%d: [%s]' % (cp, ','.join(str(x) for x in dec[cp])))
        if len(line) == 8:
            out.append('  ' + ', '.join(line) + ',')
            line = []
    if line:
        out.append('  ' + ', '.join(line) + ',')
    out += ['};', '', '/// 결합 등급(0 이 아닌 것만) — 분해 뒤 차례 맞추기 · 걷어 낼 글자',
            'const Map<int, int> foldCcc = {']
    line = []
    for cp in sorted(ccc):
        line.append('%d: %d' % (cp, ccc[cp]))
        if len(line) == 12:
            out.append('  ' + ', '.join(line) + ',')
            line = []
    if line:
        out.append('  ' + ', '.join(line) + ',')
    out += ['};', '']
    return '\n'.join(out)


def _vector_texts(conn):
    texts = [t for t, _w in VECTORS]
    texts += ['인애(hesed)', '평강(shalom)', '언약(berith)', '영(ruach)', '거룩(qodesh)', '사랑(agape)', '은혜(charis)',
              '창조(bara)', '말씀(logos)', '믿음(pistis)', '빛(or)', '구원(yeshuah)', '인애(헤세드)', '말씀(로고스)', '평강(샬롬, שָׁלוֹם)', '사랑(아가페)', '믿음(피스티스, πίστις)',
              '하나(εἷς)', '안으로(εἰς)', '영(루아흐)', '길(데레크)', '거룩(카도쉬)', '의(체데크)',
              '진리(ἀλήθεια, alētheia)', '창조(바라, H1254)', '복(바라크)', '구원(soteria)', '은혜(chesed)']
    try:
        for (b,) in conn.execute("SELECT body_text FROM sys_ref_text WHERE body_text LIKE '%(%' LIMIT 400"):
            for m in PAT.finditer(b or ''):
                texts.append(m.group(0))
                if len(texts) > 140:
                    break
            if len(texts) > 140:
                break
    except Exception:                                     # noqa: BLE001
        pass
    # 원어 사전에서 고르게 — 원어 글자(히브리·헬라) · 라틴 음역 · 철자가 같은 것(짐작 갈래)
    try:
        rows = conn.execute("SELECT strong, form, translit, gloss FROM sys_lemma_master WHERE form<>''"
                            " AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY strong").fetchall()
        for i, (st, f, t, g) in enumerate(rows[::max(1, len(rows) // 40)]):
            w = ((g or '').split(',')[0].split(';')[0].strip() or 'x')[:12]
            texts.append('%s(%s)' % (w, f))
            if t and i % 2 == 0:
                texts.append('%s(%s)' % (w, t))
        form_, _tr, _e, _g2 = _index(conn)
        amb = [k for k, v in form_.items() if len(v) > 1][:25]
        texts += ['뜻(%s)' % k for k in amb]
    except Exception:                                     # noqa: BLE001
        pass
    seen, out = set(), []
    for t in texts:
        if t not in seen:
            seen.add(t)
            out.append(t)
    return out


def dart_vectors(conn):
    """폰 시험 자료 — 시험 글이 건드리는 열쇠의 **모든** 원어 줄과 그 줄로만 지은 DB 에서 낸 기대값."""
    import sqlite3
    form, tr, ent, _g = _index(conn)
    exact, _occ = _EXTRA[id(conn)]
    texts = _vector_texts(conn)
    S = set()
    for t in texts:
        for m in PAT.finditer(t):
            for p in [x.strip() for x in re.split(r'[,，、]', m.group(2)) if x.strip()] + [m.group(1)]:
                S |= exact.get(exact_form(p), set()) | form.get(norm_form(p), set()) | tr.get(norm_tr(p), set())
                S |= _loose_index(conn).get(loose_tr(p), set()) if len(loose_tr(p)) >= 3 else set()
                if STRONG.match(p):
                    S.add(p.upper())
    S = sorted(S)
    q = ','.join('?' * len(S)) or "''"
    lem = [list(r) for r in conn.execute(
        "SELECT strong, form, translit, gloss, occurrences FROM sys_lemma_master WHERE strong IN (%s)"
        " AND COALESCE(record_status,'LIVE')='LIVE'" % q, S)]
    el = [list(r) for r in conn.execute(
        "SELECT l.entity_id, l.strong, l.translit, l.gloss FROM sys_entity_lemma l JOIN sys_entity_master m"
        " ON m.entity_id=l.entity_id WHERE l.strong IN (%s) AND COALESCE(l.record_status,'LIVE')='LIVE'"
        " AND COALESCE(m.record_status,'LIVE')='LIVE' ORDER BY l.sort_order, l.lemma_id" % q, S)]
    eids = sorted({r[0] for r in el})
    names = [list(r) for r in conn.execute(
        "SELECT clicked_id, contents, UPPER(lang_code) FROM sys_text_asset WHERE text_type='ENTITY_NAME' AND clicked_id IN (%s)"
        " AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY rowid" % (','.join('?' * len(eids)) or "''"), eids)]
    m = sqlite3.connect(':memory:')
    m.execute('CREATE TABLE sys_lemma_master(strong, form, translit, gloss, occurrences, record_status)')
    m.execute('CREATE TABLE sys_entity_master(entity_id, record_status)')
    m.execute('CREATE TABLE sys_entity_lemma(lemma_id INTEGER PRIMARY KEY, entity_id, strong, translit, gloss,'
              ' sort_order, record_status)')
    m.execute('CREATE TABLE sys_text_asset(clicked_id, contents, lang_code, text_type, record_status)')
    m.executemany("INSERT INTO sys_lemma_master VALUES(?,?,?,?,?,'LIVE')", lem)
    m.executemany("INSERT INTO sys_entity_master VALUES(?,'LIVE')", [(e,) for e in eids])
    m.executemany("INSERT INTO sys_entity_lemma(entity_id, strong, translit, gloss, sort_order, record_status)"
                  " VALUES(?,?,?,?,0,'LIVE')", el)
    m.executemany("INSERT INTO sys_text_asset VALUES(?,?,?,'ENTITY_NAME','LIVE')", names)
    cases = []
    for t in texts:
        cases.append({'text': t,
                      'all': [list(r) for r in find_full(m, t)],
                      'sure': [list(r) for r in find_full(m, t, sure_only=True)]})
    fold = {}
    for t in texts:
        for w in [t] + [x for x in re.split(r'[\s(),，、]', t) if x]:
            fold[w] = [norm_form(w), exact_form(w), norm_tr(w), loose_tr(w)]
    _IDX.pop(id(m), None)
    _EXTRA.pop(id(m), None)
    _LOOSE.pop(id(m), None)
    return {'lemma': lem, 'entity_lemma': el, 'names': names, 'cases': cases, 'fold': fold}


VECTORS = [
    ('은혜(카리스)', 'G5485'),
    ('인애(헤세드, H2617)', 'H2617'),
    ('은혜(카리스, χάρις)', 'G5485'),
    ('은혜(χάρις, G5485)', 'G5485'),
    ('카리스(χάρις)', 'G5485'),
    ('은혜(카리스, G5485)', 'G5485'),
    ('창 1:1(본문)', None),
    ('그 사람(아브라함)이', None),
]


def selftest():
    import appdb
    conn = appdb.connect()
    ok = [0, 0]

    def ck(c, m, got=''):
        ok[0 if c else 1] += 1
        print(('  PASS ' if c else '  FAIL ') + m + ('' if c else '  · %r' % (got,)))
    for txt, want in VECTORS:
        f = find(conn, txt)
        got = f[0][3] if f else None
        ck(got == want, '읽기 %s → %s' % (txt, want), got)
    ck(norm_form('חֶסֶד') == norm_form('חסד'), '히브리 점을 걷고 견준다')
    ck(norm_form('χάρις') == norm_form('χαρισ'), '헬라 악센트·끝 시그마')
    # 승격된 원어 = 용어 · 승격 안 된 원어 = LEMMA
    f = find(conn, '은혜(카리스, G5485)')
    ck(f and f[0][0] == 'ENTITY' and f[0][1] == 319, '승격된 원어는 그 용어로', f)
    row = conn.execute("SELECT strong FROM sys_lemma_master m WHERE NOT EXISTS (SELECT 1 FROM sys_entity_lemma l"
                       " WHERE l.strong=m.strong) AND strong LIKE 'G%' LIMIT 1").fetchone()
    if row:
        f = find(conn, '뜻(무엇, %s)' % row[0])
        ck(f and f[0][0] == 'LEMMA' and strong_of(f[0][1]) == row[0], '승격 안 된 원어는 원어 연결로', f)
    else:
        ck(True, '(승격 안 된 원어가 없음 — 건너뜀)')
    ck(lemma_key('H2617') == 1002617 and strong_of(1002617) == 'H2617' and strong_of(2005485) == 'G5485',
       '열쇠 왕복')
    try:
        import user_ai
        ck(user_ai.lemma_key('G5485') == lemma_key('G5485'), '열쇠 규칙 = user_ai.lemma_key')
    except Exception as e:                                # noqa: BLE001
        ck(False, 'user_ai 열쇠 견주기', e)
    f = find(conn, '은혜(카리스)는 … 은혜(카리스)')
    ck(len(f) == 1, '같은 원어는 한 번', f)
    ck('G5485' in label(conn, 'LEMMA', 2005485), '원어 이름')
    ck(loose_tr('cheçed') == loose_tr('hesed') == loose_tr('chesed'), '느슨한 음독 — cheçed = hesed = chesed')
    ck(loose_tr('shâlôwm') == loose_tr('shalom') and loose_tr('rûwach') == loose_tr('ruach'), '느슨한 음독 — shalom · ruach')
    ck(loose_tr('헤세드') == '', '한글은 느슨한 열쇠 없음')
    f = find(conn, '인애(hesed)')
    ck(f and f[0][3] == 'H2617', '영어로 친 음독도 읽는다 — 인애(hesed)', f)
    k = lemma_key('G5485')
    ck(canon(conn, 'LEMMA', k) == ('ENTITY', 319), '폰이 원어로 보낸 승격 원어 → 그 용어', canon(conn, 'LEMMA', k))
    if row:
        ck(canon(conn, 'LEMMA', lemma_key(row[0])) == ('LEMMA', lemma_key(row[0])), '승격 안 된 원어는 그대로')
    ck(canon(conn, 'VERSE', 5) == ('VERSE', 5), '구절은 그대로')
    v = dart_vectors(conn)
    ck(len(v['cases']) >= 20 and any(c['all'] for c in v['cases']), '폰 시험 자료 — 시험 글 %d' % len(v['cases']))
    ck(all(c['all'] == [list(r) for r in find_full(conn, c['text'])] for c in v['cases'] if c['text'] in dict(VECTORS)),
       '시험 자료의 기대값 = 실제 DB 의 결과(본보기 글)')
    d = dart_fold()
    ck('8049: [945,769]' in d, '분해 표 — ά(U+1F71) → α + ́')
    print('orig_ref selftest %d/%d' % (ok[0], sum(ok)))
    return ok[1] == 0


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:                                     # noqa: BLE001
        pass
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    elif '--dart' in a or '--vectors' in a:
        import json, os, appdb
        root = os.path.dirname(os.path.abspath(__file__))
        if '--dart' in a:
            io_ = open(os.path.join(root, DART_FOLD), 'w', encoding='utf-8', newline='\n')
            io_.write(dart_fold())
            io_.close()
            print('wrote', DART_FOLD)
        if '--vectors' in a:
            v = dart_vectors(appdb.connect())
            with open(os.path.join(root, DART_VECTORS), 'w', encoding='utf-8', newline='\n') as f:
                json.dump(v, f, ensure_ascii=False, indent=0)
            print('wrote', DART_VECTORS, len(v['cases']), 'cases ·', len(v['lemma']), 'lemma rows')
    elif '--find' in a:
        import appdb
        print(find(appdb.connect(), a[a.index('--find') + 1]))
    else:
        print(__doc__)
