# -*- coding: utf-8 -*-
"""db_term_desc.py — **주요용어 이름 점검**과 설명문 게이트 (영구 도구).

★★★ **필수는 이름 하나다** (2026-09-24 사용자 확정 — 「용어 db 에 용어의
  **이름/제목만 입력되면 충분하다**」). 설명문은 **선택**이고, 사람이 쓸 때만
  쓴다. 그러니 이 도구가 늘 재는 것은 진도가 아니라 **`--names`** 다.
  ⚠ **자동으로 설명문을 채우려 들지 말 것** — 사용자가 글쓰기를 「매우
    제한적으로」 요구한다고 못 박았다(같은 날). 게이트는 사람이 쓴 글을
    받을 때만 쓰인다.

★★★ **이름이 왜 필수인가** — 승격 용어의 이름은 `db_term_cite` 가 **우리 글의
  인용에서 기계로 지었다**. 인용이 활용형이거나 조각이면 이름이 어긋나는데,
  **설명문이 없으면 화면에서 그 이름이 그 용어의 전부**다. 실측으로 잡은 것:
  `T_H2803`(châshab)이 **「낱말 · 하샤브」** 로 등록돼 있었다. 창 15:6
  「의로 **여기시고**」 의 그 낱말, 곧 「헤아리다」 다. 사전 탭도 이것을 못 메운다.

★ **머리말이 겹치는 것은 흠이 아니다** — 「감사 · 토다」와 「감사 · 유카리스티아」
  처럼 **다른 원어가 같은 한국어로 옮겨진 자리**가 이 자산의 값이다. 음역이
  붙어 있으면 화면에서 갈린다. 그래서 `--names` 는 **음역이 붙었는가**를 잰다.

★ 설명문을 쓸 때의 규격(기존 137편에서 실측) — 스트롱 사전을 옮겨 적는 글이
  아니다. 사전은 같은 화면의 「사전」 탭이 이미 보인다. 할 일은 셋이다:
    ① **한국어만 보아서는 안 보이는 것**을 보인다(한 낱말이 여러 말로 옮겨진
       자리 · 다른 낱말이 같은 말로 옮겨진 자리)
    ② **오해를 바로잡는다**(거룩 = 착함이 아니다 · 좋다 = 도덕이 아니다)
    ③ **그 낱말이 어디에 서 있는지** 본문으로 보인다(첫 자리 · 절정 · 뒤집히는 자리)
  ⚠ 「이 낱말은 …를 뜻합니다」로 시작해 뜻풀이만 늘어놓으면 사전과 겹친다.

★ **재료는 실측으로 뽑는다**(`material`) — 절 수 · 대표 절 본문 · 어느 책에
  몰려 있나 · 스트롱 정의. **기억으로 절을 적지 않는다**(§0-1b).

게이트(`check`) — 기존 121편에서 실측한 모양을 그대로 잰다:
  · 문단 **3~7** · KO **250~1200자** · EN 있음 · 언어 짝
  · **합니다체**(어미를 못 박지 않는다 — `니다|니까`)
  · 인용한 절 표기가 **실재하는 절**인가
  · 이름을 글이 실제로 부르는가(엉뚱한 용어에 붙는 것을 막는다)

사용:
    python db_term_desc.py --selftest          (의무)
    python db_term_desc.py --names             ★ 이름 점검 (늘 이것부터)
    python db_term_desc.py --todo              설명문이 없는 용어 (선택 작업)
    python db_term_desc.py --mat 539 636 ...   재료
    python db_term_desc.py --check <json>
    python db_term_desc.py --apply <json>
    python db_term_desc.py --undo <json>
"""
import io
import json
import re
import sys

import appdb

MARK = 'TERMDESC_SEED'          # --undo 가 제 것만 지우는 표식
MIN_KO, MAX_KO = 250, 1200
MIN_PARA, MAX_PARA = 3, 7
TT = 'ENTITY_DESC'

# ── 재료 ──────────────────────────────────────────────────────────────
def todo(conn):
    """설명문이 아직 없는 **사람 용어**. `(entity_id, code, 이름KO, 절수)`"""
    return conn.execute("""
        SELECT m.entity_id, m.entity_code,
               (SELECT contents FROM sys_text_asset
                 WHERE text_type='ENTITY_NAME' AND clicked_id=m.entity_id
                   AND lang_code='KO' LIMIT 1) ko,
               (SELECT COUNT(*) FROM sys_link_asset l
                 WHERE l.link_type='ENTI_VERS' AND l.clicked_id=m.entity_id) nv
          FROM sys_entity_master m
         WHERE m.entity_type='TERM' AND m.record_status='LIVE'
           AND ko IS NOT NULL
           AND COALESCE(m.json_detail,'') NOT LIKE '%subtype%'
           AND (SELECT COUNT(*) FROM sys_text_asset
                 WHERE text_type=? AND clicked_id=m.entity_id
                   AND COALESCE(record_status,'LIVE')='LIVE')=0
         ORDER BY nv DESC, m.entity_id""", (TT,)).fetchall()


def material(conn, eid, n_verse=6):
    """그 용어를 쓰는 재료 — **짐작하지 않고 DB 에서 꺼낸다**."""
    row = conn.execute(
        "SELECT entity_code FROM sys_entity_master WHERE entity_id=?",
        (eid,)).fetchone()
    if not row:
        return None
    out = {'entity_id': eid, 'code': row[0]}
    for lg in ('KO', 'EN'):
        r = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
            " AND clicked_id=? AND lang_code=? LIMIT 1", (eid, lg)).fetchone()
        out['name_' + lg] = r and r[0]
    out['lemma'] = conn.execute(
        "SELECT strong, translit, gloss FROM sys_entity_lemma"
        " WHERE entity_id=?", (eid,)).fetchall()
    vs = conn.execute(
        "SELECT b.bcode, b.chapter, b.verse, b.verse_id"
        "  FROM sys_link_asset l JOIN bible_index b ON b.verse_id=l.target_id"
        " WHERE l.link_type='ENTI_VERS' AND l.clicked_id=?"
        " ORDER BY b.sort_order", (eid,)).fetchall()
    out['n_verse'] = len(vs)
    # 어느 책에 몰려 있나 — 그 낱말이 사는 동네를 보인다
    cnt = {}
    for b, _c, _v, _i in vs:
        cnt[b] = cnt.get(b, 0) + 1
    # ⚠ 칸 이름은 `book_code`·`short_name` 이다(`bcode`·`book_name` 아님)
    names = dict(conn.execute(
        "SELECT book_code, short_name FROM book_names WHERE lang_code='KO'"))
    out['books'] = sorted(((names.get(b, b), n) for b, n in cnt.items()),
                          key=lambda x: -x[1])[:6]
    # 대표 절 — 처음·중간·끝을 고루 집는다(앞만 보면 한 책에 쏠린다)
    pick = vs[:: max(1, len(vs) // n_verse)][:n_verse] if vs else []
    out['verses'] = []
    for b, ch, vn, vid in pick:
        t = conn.execute(
            "SELECT verse_text FROM bible_content"
            " WHERE verse_id=? AND version_code='KRV'", (vid,)).fetchone()
        out['verses'].append(('%s %d:%d' % (names.get(b, b), ch, vn),
                              (t and t[0] or '').strip()))
    return out


# ── 이름 점검 ─────────────────────────────────────────────────────────
#   ★ 필수 항목은 이름 하나다. 여기서 잡는 것만이 「고쳐야 하는 것」이다.
_SENTENCE = re.compile(r'(한다|하리로다|였다|습니다|하라)\s*(·|$)')
MAX_NAME = 26          # 실측 — 목록 칸이 그 너머를 자른다(§283차 db_term_name)


def names(conn):
    """승격 용어 이름을 잰다. `(흠 목록, 전체 수)`

    ⚠ **머리말이 겹치는 것은 흠이 아니다** — 음역이 붙어 있으면 갈린다.
      음역이 없는 채로 겹칠 때만 잡는다(그때는 화면에서 같은 줄로 보인다).
    """
    rows = conn.execute("""
        SELECT m.entity_id, m.entity_code,
               (SELECT contents FROM sys_text_asset
                 WHERE text_type='ENTITY_NAME' AND clicked_id=m.entity_id
                   AND lang_code='KO' LIMIT 1) ko,
               (SELECT contents FROM sys_text_asset
                 WHERE text_type='ENTITY_NAME' AND clicked_id=m.entity_id
                   AND lang_code='EN' LIMIT 1) en
          FROM sys_entity_master m
         WHERE m.entity_type='TERM' AND m.record_status='LIVE'
           AND COALESCE(m.json_detail,'') NOT LIKE '%subtype%'
         ORDER BY m.entity_id""").fetchall()
    bad = []
    heads = {}
    for eid, code, ko, en in rows:
        tag = '%s(%s)' % (ko or code, eid)
        if not (ko or '').strip():
            bad.append('%s: **한국어 이름이 없다**' % tag)
            continue
        if not (en or '').strip():
            bad.append('%s: 영어 이름이 없다' % tag)
        if _SENTENCE.search(ko):
            bad.append('%s: 이름이 문장 꼴이다 (표제어로 적는다)' % tag)
        if len(ko) > MAX_NAME:
            bad.append('%s: 이름이 %d자 (%d자까지)' % (tag, len(ko), MAX_NAME))
        head = ko.split('·')[0].strip()
        has_tr = '·' in ko
        if head in heads:
            o_eid, o_tr = heads[head]
            if not (has_tr and o_tr):
                bad.append('%s: 머리말 「%s」 가 %s 와 겹치는데 음역이 없다'
                           % (tag, head, o_eid))
        else:
            heads[head] = (eid, has_tr)
    return bad, len(rows)


# ── 게이트 ────────────────────────────────────────────────────────────
_REF = re.compile(r'([가-힣]{1,3})\s?(\d{1,3}):(\d{1,3})')


def _book_map(conn):
    m = {}
    for bc, full, short in conn.execute(
            "SELECT book_code, full_name, short_name FROM book_names"
            " WHERE lang_code='KO'"):
        m[short] = bc
        m.setdefault(full, bc)
    return m


def check(conn, draft):
    """`bad` 목록 하나만 돌려준다 — 경고는 찍기만 한다(§0-5)."""
    bad = []
    bm = _book_map(conn)
    seen = set()
    for it in draft:
        eid = it.get('entity_id')
        tag = '%s(%s)' % (it.get('name') or '?', eid)
        if eid in seen:
            bad.append('%s: 같은 용어가 두 번' % tag)
        seen.add(eid)
        row = conn.execute(
            "SELECT entity_type FROM sys_entity_master WHERE entity_id=?"
            "  AND record_status='LIVE'", (eid,)).fetchone()
        if not row:
            bad.append('%s: 없는 용어' % tag)
            continue
        nm = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
            " AND clicked_id=? AND lang_code='KO' LIMIT 1", (eid,)).fetchone()
        nm = (nm and nm[0]) or ''
        for lg in ('KO', 'EN'):
            d = (it.get(lg) or '').strip()
            if not d:
                bad.append('%s: %s 설명문이 없다' % (tag, lg))
                continue
            paras = [p for p in d.split('\n') if p.strip()]
            if not (MIN_PARA <= len(paras) <= MAX_PARA):
                bad.append('%s %s: 문단 %d개 (%d~%d)'
                           % (tag, lg, len(paras), MIN_PARA, MAX_PARA))
            if lg == 'KO':
                if not (MIN_KO <= len(d) <= MAX_KO):
                    bad.append('%s KO: %d자 (%d~%d)'
                               % (tag, len(d), MIN_KO, MAX_KO))
                if not re.search(r'(니다|니까)', d):
                    bad.append('%s KO: 합니다체가 아니다' % tag)
                # ★ 이름의 한국어 머리말을 글이 실제로 부르는가
                head = nm.split('·')[0].strip()
                if head and head not in d:
                    bad.append('%s KO: 글이 「%s」 를 한 번도 안 부른다'
                               % (tag, head))
                # ★ 인용한 절이 실재하는가 — 기억으로 적지 않는다
                for bk, ch, vn in _REF.findall(d):
                    bc = bm.get(bk)
                    if bc is None:
                        continue
                    ok = conn.execute(
                        "SELECT 1 FROM bible_index WHERE bcode=? AND chapter=?"
                        "  AND verse=?", (bc, int(ch), int(vn))).fetchone()
                    if not ok:
                        bad.append('%s KO: 없는 절 %s %s:%s'
                                   % (tag, bk, ch, vn))
            if '—' in d:
                bad.append('%s %s: 「—」 를 쓰지 않는다' % (tag, lg))
    return bad


# ── 적재 ──────────────────────────────────────────────────────────────
def apply_(conn, draft):
    bad = check(conn, draft)
    if bad:
        for b in bad[:12]:
            print('  ' + b)
        raise SystemExit('검사 실패 %d건' % len(bad))
    cur = conn.cursor()
    # ★ 되돌릴 자리를 먼저 뜬다 — 덮기 전에 남긴다(§0-5)
    cur.execute("CREATE TABLE IF NOT EXISTS temp_termdesc_backup"
                " (clicked_id INT, lang_code TEXT, contents TEXT, ts TEXT)")
    import datetime
    ts = datetime.datetime.now().isoformat(timespec='seconds')
    for it in draft:
        for r in cur.execute("SELECT clicked_id, lang_code, contents"
                             "  FROM sys_text_asset WHERE text_type=?"
                             "   AND clicked_id=?",
                             (TT, it['entity_id'])).fetchall():
            cur.execute("INSERT INTO temp_termdesc_backup VALUES(?,?,?,?)",
                        (r[0], r[1], r[2], ts))
    n_new = n_upd = 0
    for it in draft:
        for lg in ('KO', 'EN'):
            body = (it[lg] or '').strip()
            old = cur.execute(
                "SELECT sys_text_id, contents FROM sys_text_asset"
                " WHERE text_type=? AND clicked_id=? AND lang_code=?",
                (TT, it['entity_id'], lg)).fetchone()
            if old:
                if old[1] != body:
                    cur.execute("UPDATE sys_text_asset SET contents=?"
                                " WHERE sys_text_id=?", (body, old[0]))
                    n_upd += 1
            else:
                cur.execute(
                    "INSERT INTO sys_text_asset(text_type, clicked_id,"
                    " lang_code, contents, record_status)"
                    " VALUES(?,?,?,?, 'LIVE')",
                    (TT, it['entity_id'], lg, body))
                n_new += 1
    conn.commit()
    return n_new, n_upd


def undo(conn, draft):
    """그 초안이 넣은 것만 걷는다.

    ⚠ `sys_text_asset` 에는 `json_detail` 칸이 **없어** 표식을 못 남긴다.
      대신 `apply_` 는 **설명문이 하나도 없던 용어에만** 넣으므로(`todo`),
      그 용어들의 ENTITY_DESC 를 지우는 것이 곧 이번 적재를 되돌리는 것이다.
    ⚠ 되돌릴 자리 = `temp_termdesc_backup`(적재 전에 뜬다)."""
    cur = conn.cursor()
    n = 0
    for it in draft:
        cur.execute("DELETE FROM sys_text_asset WHERE text_type=?"
                    "  AND clicked_id=?", (TT, it['entity_id']))
        n += cur.rowcount
    conn.commit()
    return n


# ── 자가 검사 ─────────────────────────────────────────────────────────
def selftest():
    print('db_term_desc 자가 검증')
    ok = fail = 0

    def t(n, cond, e=''):
        nonlocal ok, fail
        if cond:
            ok += 1
            print('  OK   %s' % n)
        else:
            fail += 1
            print('  FAIL %s  %s' % (n, e))

    c = appdb.connect()
    left = todo(c)
    t('★ 설명문이 없는 용어를 센다(선택 작업)', isinstance(left, list), len(left))

    # ★★★ 필수 항목 — 실 DB 의 이름이 성한가
    nb, ntot = names(c)
    t('★★★ **용어 이름에 흠 0**', not nb, nb[:3])
    t('★ 용어를 센다', ntot > 0, ntot)
    # ★★ 탐지력 — 이름을 일부러 망가뜨려 보고 되돌린다(자국 0)
    eid = c.execute(
        "SELECT clicked_id FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
        "  AND lang_code='KO' AND clicked_id IN"
        "  (SELECT entity_id FROM sys_entity_master WHERE entity_type='TERM'"
        "     AND COALESCE(json_detail,'') NOT LIKE '%subtype%')"
        " LIMIT 1").fetchone()[0]
    keep = c.execute("SELECT contents FROM sys_text_asset"
                     " WHERE text_type='ENTITY_NAME' AND clicked_id=?"
                     "   AND lang_code='KO'", (eid,)).fetchone()[0]
    try:
        for hurt, why in (('찬송하리로다 · 아무개', '문장 꼴 이름'),
                          ('가' * 40, '너무 긴 이름'),
                          ('', '빈 이름')):
            c.execute("UPDATE sys_text_asset SET contents=?"
                      " WHERE text_type='ENTITY_NAME' AND clicked_id=?"
                      "   AND lang_code='KO'", (hurt, eid))
            nb2, _ = names(c)
            t('★★ %s 를 잡는다' % why, len(nb2) > len(nb), nb2[:1])
    finally:
        c.execute("UPDATE sys_text_asset SET contents=?"
                  " WHERE text_type='ENTITY_NAME' AND clicked_id=?"
                  "   AND lang_code='KO'", (keep, eid))
        c.commit()
    t('★★ 재는 동안 남긴 자국 0',
      c.execute("SELECT contents FROM sys_text_asset"
                " WHERE text_type='ENTITY_NAME' AND clicked_id=?"
                "   AND lang_code='KO'", (eid,)).fetchone()[0] == keep)

    # ★ 재료는 **있는 용어**에서 뽑는다(데이터 상태를 전제하지 않는다 §0-5)
    any_eid = c.execute(
        "SELECT clicked_id FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
        "  AND lang_code='KO' AND clicked_id IN"
        "  (SELECT entity_id FROM sys_entity_master WHERE entity_type='TERM')"
        " LIMIT 1").fetchone()[0]
    m = material(c, any_eid)
    t('★★ 재료가 나온다', m and m.get('name_KO'), m and m['name_KO'])
    t('★ 재료에 절 본문이 딸려 온다',
      all(v[1] for v in m['verses']) if m['verses'] else True,
      len(m['verses']))

    # ★★ 게이트 탐지력 — 규칙마다 일부러 어겨 본다
    nm = m['name_KO'].split('·')[0].strip()
    good = {'entity_id': any_eid, 'name': m['name_KO'],
            'KO': ('%s 는 이 낱말이 서 있는 자리를 보여 줍니다.\n'
                   '한국어만 보아서는 그 자리가 잘 보이지 않습니다.\n'
                   '그래서 본문을 나란히 놓고 읽습니다. 창 1:1 이 그 자리입니다.'
                   % nm) + '\n' + '가' * 200,
            'EN': 'One.\nTwo.\nThree.'}
    t('★★★ 성한 초안은 통과한다', not check(c, [good]), check(c, [good])[:2])

    import copy

    def bad(mut, why):
        g = copy.deepcopy(good)
        mut(g)
        e = check(c, [g])
        t('★★ %s 를 잡는다' % why, bool(e), e[:1])

    bad(lambda g: g.update(KO='한 문단뿐입니다.' + '가' * 300), '문단 하나')
    bad(lambda g: g.update(KO='짧다.\n짧다.\n짧다.'), '너무 짧은 설명문')
    bad(lambda g: g.update(KO=g['KO'].replace('니다', '다')), '합니다체 아님')
    bad(lambda g: g.update(KO=g['KO'] + ' 뜻은 이렇다 — 저렇다 입니다.'),
        '「—」 기호')
    bad(lambda g: g.update(KO=g['KO'].replace('창 1:1', '창 1:99')), '없는 절')
    bad(lambda g: g.update(KO=g['KO'].replace(nm, '엉뚱한말')),
        '★ 글이 그 용어를 안 부름')
    bad(lambda g: g.update(EN=''), 'EN 이 없음')
    bad(lambda g: g.update(entity_id=-1), '없는 용어')
    e = check(c, [good, copy.deepcopy(good)])
    t('★★ 같은 용어가 두 번인 것을 잡는다', bool(e), e[:1])

    print('db_term_desc selftest %d/%d' % (ok, ok + fail))
    return 0 if not fail else 1


def _load(p):
    return json.loads(io.open(p, encoding='utf-8').read())


if __name__ == '__main__':
    a = sys.argv[1:]
    if not a or a[0] == '--selftest':
        sys.exit(selftest())
    conn = appdb.connect()
    if a[0] == '--names':
        bad, n = names(conn)
        for b in bad:
            print('  ' + b)
        print('용어 %d개 · 이름 흠 %d건' % (n, len(bad)))
        sys.exit(1 if bad else 0)
    elif a[0] == '--todo':
        rows = todo(conn)
        for i, r in enumerate(rows):
            print('%3d %5d %-12s %-30s %4d' % (i + 1, r[0], r[1], r[2], r[3]))
        print('설명문이 없는 용어 %d개 (선택 작업 — 필수는 이름이다)'
              % len(rows))
    elif a[0] == '--mat':
        for eid in a[1:]:
            m = material(conn, int(eid))
            print('== %s %s / %s' % (m['entity_id'], m['name_KO'], m['name_EN']))
            for s, tr, gl in m['lemma']:
                print('   %s %s · %s' % (s, tr, (gl or '')[:90]))
            print('   절 %d · 책 %s' % (m['n_verse'], m['books']))
            for ref, tx in m['verses']:
                print('   %-10s %s' % (ref, tx[:88]))
    elif a[0] == '--check':
        bad = check(conn, _load(a[1]))
        for b in bad:
            print('  ' + b)
        print('검사 %s — %d건' % ('실패' if bad else '통과', len(bad)))
        sys.exit(1 if bad else 0)
    elif a[0] == '--apply':
        n, u = apply_(conn, _load(a[1]))
        print('적재 — 새로 %d · 고침 %d' % (n, u))
    elif a[0] == '--undo':
        print('되돌림 %d행' % undo(conn, _load(a[1])))
    else:
        print(__doc__)
