"""
pyqt_media_player.py
--------------------
표준 인라인 미디어 플레이어 (PyQt6 + QWebEngineView).

YouTube 영상을 앱 외부 브라우저가 아니라 "좌측 목록 + 우측 인라인 플레이어" 한 창에서
재생한다. tkinter 앱(user_main / admin)에서는 QWebEngineView를 임베드할 수 없으므로
이 모듈은 **별도 프로세스**로 실행한다 (media_player.launch() 가 띄움).

4개 영역 공용: P2 Links / P4 Entity Info 링크 / P4 캔버스 노드 링크 / 관리자 미디어 검토.
각 호출자는 자기 컨텍스트의 영상 목록만 JSON 으로 넘기면 된다 (DB 쿼리는 호출자 책임).

실행: python pyqt_media_player.py --data <spec.json>
spec.json: {"title": "...", "videos": [{"title": "...", "url": "...", "tag": "[설교]"}, ...]}

왜 PyQt 인가: Qt WebEngine 은 Chromium 을 Qt 가 관리하는 별도 프로세스로 구동하므로
tkinter+pythonnet(WebView2) 임베드에서 발생하던 COM 아파트먼트 충돌(RPC_E_CHANGED_MODE)이
구조적으로 없다. Python 3.14 에서 동작 검증 완료.
"""

import sys
import os
import re
import json
import argparse
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs


def _player_page() -> bytes:
    """YouTube IFrame Player API 페이지 (정적, 한 번만 로드).
    - 영상 전환은 페이지 재로드(setUrl)가 아니라 ytLoad(id)=loadVideoById 로 — IFrame API 가
      재로드 시 onYouTubeIframeAPIReady 를 다시 안 불러 두 번째 영상부터 검정이 되던 버그 해결.
    - 로컬 서버 origin 으로 '구성 오류 153/152-4' 해결.
    - onError(임베드 차단·Shorts·지역/연령 제한 등) → 안내 + [브라우저에서 열기] 버튼.
      버튼은 fetch('/open?v=ID') 로 페이지 이동 없이 시스템 브라우저만 연다(플레이어 유지)."""
    return (
        # ★ 창 제목으로 **지금 어느 쪽에 있나**를 밖에서 볼 수 있다(하네스가 잰다).
        #   유튜브 쪽으로 가면 그 영상 제목이, 돌아오면 이 이름이 창 제목이 된다.
        '<!DOCTYPE html><html><head><meta charset="utf-8">'
        '<title>Hagah Dabar Player</title><style>'
        'html,body{margin:0;padding:0;height:100%;background:#000;overflow:hidden;'
        'font-family:Malgun Gothic,sans-serif}'
        '#player{position:absolute;top:0;left:0;width:100%;height:100%}'
        '#err{display:none;position:absolute;top:0;left:0;width:100%;height:100%;'
        'background:#0a0a0a;color:#ddd;text-align:center;box-sizing:border-box;padding-top:16%}'
        '#err button{margin-top:16px;padding:11px 20px;background:#cc0000;border:0;cursor:pointer;'
        'color:#fff;border-radius:5px;font-size:15px;font-weight:bold}'
        '</style></head><body>'
        '<div id="player"></div>'
        '<div id="err"><div style="font-size:18px">이 영상은 인라인 재생이 제한됩니다</div>'
        '<div style="color:#999;font-size:13px;margin-top:6px">'
        '(Shorts · 임베드 차단 · 지역/연령 제한 등)<br>'
        '이어듣기 중에는 막힌 영상을 건너뜁니다.</div>'
        '<button onclick="openCur()">▶ 브라우저에서 열기</button></div>'
        # JS: 빈 플레이어 생성은 onError(2)를 유발하므로 반드시 videoId 와 함께 생성한다.
        # onError 는 실제 임베드 불가 코드(101/150 임베드차단, 100 없음/비공개, 2 잘못된 ID)만
        # 오버레이를 띄운다. 5(HTML5)·autoplay 차단 등 일시 오류는 무시(오탐 방지).
        '<script src="https://www.youtube.com/iframe_api"></script><script>'
        # ★★★ **주소로 첫 영상을 받는다** (2026-09-17 사용자 「영상+설명을 보다가
        #   다시 「영상만」으로 수정하면 클릭해도 표시되지 않는다」).
        #   까닭 — 「영상+설명」은 **유튜브 쪽으로 옮겨 가므로** 그 뒤에 보내는
        #   `ytLoad()` 는 **그 함수가 없는 쪽**에서 돌아 조용히 아무 일도 안 했다.
        #   ⇒ 돌아올 때는 이 쪽을 **다시 열되 `?v=` 로 영상을 함께 준다**.
        #   ⚠ 열자마자 `ytLoad` 를 쏘면 안 된다 — IFrame API 가 아직 안 와서
        #     졌다 이겼다 한다. **API 가 준비되면 제가 만든다**(아래 마지막 줄).
        'var _q=location.search;'
        'var _mv=_q.match(/[?&]v=([\\w-]+)/),_ml=_q.match(/[?&]list=([\\w,-]+)/);'
        'var _init=_ml?_ml[1].split(","):null;'
        'var _mt=_q.match(/[?&]try=([\\w,-]+)/);'
        'if(_mt){_init=_mt[1].split(",");}'
        'var player,curId=(_mv?_mv[1]:(_init?_init[0]:"")),inList=0,skips=0;'
        #: `tryOne` = 후보 줄 세우기 — 막히면 다음으로 가되 **끝나면 멈춘다**.
        'var tryOne=(_mt?1:0);'
        'function _err(s){document.getElementById("err").style.display=s?"block":"none";}'
        # ★★★ **101·150 만이 「임베드를 껐다」**(2026-09-24 1.txt 14번).
        #   100(없음·비공개)·2(잘못된 id)는 **어디서 열어도 못 본다** — 그것을
        #   함께 묶어 브라우저로 보내면 「없는 쪽」을 보여 주게 된다.
        #   ⇒ 임베드 차단만 부모에게 알리고, 부모가 여는 방식을 정한다.
        'function _onErr(e){var c=e.data;'
        'var emb=(c==101||c==150);'
        'var blocked=(emb||c==100||c==2);'
        'if(blocked&&inList&&player&&player.nextVideo){'
        'if(skips<60){skips++;try{player.nextVideo();return;}catch(x){}}}'
        'if(emb&&curId){try{fetch("/blocked?v="+curId);}catch(x){}}'
        'if(blocked)_err(1);}'
        'function _onState(e){if(e.data==1){skips=0;_err(0);'
        'try{var d=player.getVideoData();if(d&&d.video_id)curId=d.video_id;}catch(x){}}'
        # ⚠ 후보 줄에서는 **끝나도 다음으로 안 넘어간다** — 같은 곡의 딴 판이 이어
        #   울리면 사용자가 무엇을 듣고 있는지 알 수 없다.
        'if(e.data==0&&tryOne){try{player.stopVideo();}catch(x){}}}'
        'function _mk(id){player=new YT.Player("player",{videoId:id,'
        'playerVars:{autoplay:1,rel:0,playsinline:1},'
        'events:{onError:_onErr,onStateChange:_onState}});}'
        'function ytLoad(id){curId=id;inList=0;skips=0;_err(0);'
        'if(player&&player.loadVideoById){player.loadVideoById(id);}'
        'else if(window.YT&&window.YT.Player){_mk(id);}}'
        # ★★★ **이어서 재생** — 목록을 통째로 넘기면 순서대로 튼다.
        #   ⚠ 플레이어가 아직 없으면 첫 곡으로 만들고 나서 목록을 건다
        #     (빈 플레이어 생성은 onError(2) 를 유발한다 — 위 주석 참조).
        'function ytList(a,tm){if(!a||!a.length)return;curId=a[0];inList=1;skips=0;'
        'tryOne=tm?1:0;_err(0);'
        'if(player&&player.loadPlaylist){player.loadPlaylist({playlist:a});}'
        'else if(window.YT&&window.YT.Player){_mk(a[0]);'
        'setTimeout(function(){if(player&&player.loadPlaylist)'
        'player.loadPlaylist({playlist:a});},900);}}'
        # ★★★ **대표 후보 줄 세우기** (2026-09-17) — 목록으로 걸어 **막힌 것을
        #   저절로 건너뛰되**, 한 편이 끝나면 **다음으로 안 넘어간다**. 후보는
        #   같은 곡의 다른 판이라 이어 트는 것이 아니라 **되돌아갈 자리**다.
        #   ⚠ 실측 승인 찬양 2,826편 중 임베드 차단을 점검한 것이 91편뿐이라
        #     첫 후보가 막힐 수 있다 — 그때 검은 화면으로 끝나면 안 된다.
        'function ytTry(a){ytList(a,1);}'
        'function ytBlank(){curId="";_err(0);tryOne=0;'
        'if(player&&player.stopVideo)player.stopVideo();}'
        'function openCur(){if(curId)fetch("/open?v="+curId);_err(0);}'
        'function onYouTubeIframeAPIReady(){'
        'if(_init&&_init.length>1){ytList(_init,tryOne);}else if(curId)_mk(curId);}'
        '</script></body></html>'
    ).encode('utf-8')


def _set_chrome_ua():
    """기본 QtWebEngine UA 에는 'QtWebEngine' 이 들어가 YouTube 가 봇으로 의심('로봇 아님 확인').
    표준 Chrome UA 로 교체 + 영구 프로필(쿠키/세션 유지)로 봇 차단을 완화한다."""
    try:
        from PyQt6.QtWebEngineCore import QWebEngineProfile
        prof = QWebEngineProfile.defaultProfile()
        prof.setHttpUserAgent(
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36')
        try:
            prof.setPersistentCookiesPolicy(
                QWebEngineProfile.PersistentCookiesPolicy.AllowPersistentCookies)
        except Exception:
            pass
    except Exception:
        pass


def _open_page() -> bytes:
    return ('<html><body style="margin:0;background:#000;color:#aaa;'
            'font-family:Malgun Gothic,sans-serif;padding:30px;font-size:15px">'
            '✔ 브라우저에서 열었습니다.</body></html>').encode('utf-8')


#: 자식 → 부모 쪽지 파일(임베드 차단 보고). `embed_main` 이 채운다.
_NOTE = {'path': None}


def _start_local_server():
    """로컬 HTTP 서버. GET /?v=ID → IFrame 플레이어 페이지 / GET /open?v=ID → 시스템 브라우저로 연다.
    (포트, 서버) 반환. 데몬 스레드로 백그라운드 실행."""
    class _H(BaseHTTPRequestHandler):
        def do_GET(self):
            parsed = urlparse(self.path)
            qs = parse_qs(parsed.query)
            vid = re.sub(r'[^\w-]', '', qs.get('v', [''])[0])[:20]
            if parsed.path == '/blocked':
                # ★ **알리기만 한다** — 무엇으로 열지는 부모(`video_open`)가
                #   정한다. 여기서 정하면 규칙이 두 곳에 갈린다.
                if vid and _NOTE.get('path'):
                    try:
                        with open(_NOTE['path'], 'a', encoding='utf-8') as nf:
                            nf.write('BLOCKED %s\n' % vid)
                    except Exception:
                        pass
                body = b'ok'
                self.send_response(200)
                self.send_header('Content-Type', 'text/plain')
                self.end_headers()
                self.wfile.write(body)
                return
            if parsed.path == '/open':
                if vid:
                    try:
                        import webbrowser
                        webbrowser.open(f'https://www.youtube.com/watch?v={vid}')
                    except Exception:
                        pass
                body = _open_page()
            else:
                body = _player_page()   # 정적 플레이어 페이지 (영상은 ytLoad 로 전환)
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *a):
            pass

    srv = ThreadingHTTPServer(('127.0.0.1', 0), _H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv.server_address[1], srv


_YT_ID = re.compile(r'(?:v=|youtu\.be/|embed/|/v/|shorts/)([\w-]{11})')


def youtube_embed(url: str):
    """YouTube URL → 임베드 URL. YouTube 가 아니면 None."""
    if not url:
        return None
    if 'youtube.com' not in url and 'youtu.be' not in url:
        return None
    m = _YT_ID.search(url)
    return f'https://www.youtube.com/embed/{m.group(1)}' if m else None


def embed_main(args):
    """임베드 모드 — frameless QWebEngineView 1개. 부모(tkinter)가 SetParent 로 이식.
    자기 HWND 를 hwnd_file 에 기록, cmd_file 을 폴링해 영상 전환('__QUIT__' 면 종료)."""
    os.environ.setdefault('QTWEBENGINE_CHROMIUM_FLAGS', '--no-sandbox')
    from PyQt6.QtWidgets import QApplication
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    from PyQt6.QtCore import QUrl, Qt, QTimer

    app = QApplication(sys.argv)
    _set_chrome_ua()
    _NOTE['path'] = getattr(args, 'note_file', None)
    port, _srv = _start_local_server()
    view = QWebEngineView()
    view.setWindowFlags(Qt.WindowType.FramelessWindowHint)
    view.resize(640, 360)
    # 플레이어 페이지를 한 번만 로드 — 이후 영상 전환은 ytLoad(JS)로 (페이지 재로드 안 함)
    view.setUrl(QUrl(f'http://127.0.0.1:{port}/'))
    view.show()

    #: ★ `web` = 지금 **유튜브 쪽**(또는 딴 웹페이지)에 가 있다는 표식.
    #:   거기서는 `ytLoad`·`ytList`·`ytBlank` 가 **없다** — 돌아와야 듣는다.
    HOME = 'http://127.0.0.1:%d/' % port
    state = {'cur': None, 'ready': False, 'web': False}
    view.loadFinished.connect(lambda ok: state.update(ready=bool(ok)))
    # ★ 쪽 제목을 창 제목으로 — 밖에서 「어느 쪽에 있나」를 잴 수 있다.
    view.titleChanged.connect(view.setWindowTitle)

    def write_hwnd():
        try:
            with open(args.hwnd_file, 'w') as f:
                f.write(str(int(view.winId())))
        except Exception as e:
            print(f'[player] hwnd write err: {e}', file=sys.stderr, flush=True)

    QTimer.singleShot(700, write_hwnd)

    def _js(code):
        view.page().runJavaScript(code)

    def poll_cmd():
        try:
            if not os.path.exists(args.cmd_file):
                return
            txt = open(args.cmd_file, encoding='utf-8').read().strip()
            if txt == '__QUIT__':
                app.quit()
                return
            # 일반 URL = 브라우저 모드 (오늘의 묵상/뉴스). setUrl 직접 로드(iframe 아님 → X-Frame 무관).
            # 플레이어 페이지 ready 와 무관하게 즉시 탐색.
            if txt.startswith('http://') or txt.startswith('https://'):
                if txt != state['cur']:
                    state['cur'] = txt
                    state['web'] = True
                    view.setUrl(QUrl(txt))
                return
            if not state['ready']:
                return   # 페이지 로드 전이면 대기 (다음 폴에서 처리)
            if txt == '__BLANK__':
                if state['cur'] != '__BLANK__':
                    state['cur'] = '__BLANK__'
                    if state['web']:
                        # ⚠ 유튜브 쪽에서는 `ytBlank()` 가 없다 — **재생기 쪽으로
                        #   돌아오는 것**이 곧 소리를 멎게 하는 길이다.
                        state['web'] = False
                        state['ready'] = False
                        view.setUrl(QUrl(HOME))
                    else:
                        _js('ytBlank()')
                return
            # ★★★ **이어서 재생** — `__LIST__ id1,id2,…`
            #   ⚠ 아이디만 남긴다(따옴표·괄호가 JS 로 새면 안 된다).
            # ★ `__TRY__` = **대표 후보 줄**(2026-09-17) — 막힌 것은 건너뛰고
            #   한 편이 끝나면 멈춘다. `__LIST__`(이어듣기)와 뜻이 다르다.
            if txt.startswith('__LIST__') or txt.startswith('__TRY__'):
                _try = txt.startswith('__TRY__')
                _head = '__TRY__' if _try else '__LIST__'
                ids = [re.sub(r'[^\w-]', '', x)[:20]
                       for x in txt[len(_head):].split(',')]
                ids = [x for x in ids if x][:200]
                if ids and txt != state['cur']:
                    state['cur'] = txt
                    if state['web']:
                        state['web'] = False
                        state['ready'] = False
                        view.setUrl(QUrl(HOME + ('?try=' if _try else '?list=')
                                         + ','.join(ids)))
                    else:
                        arr = ','.join("'%s'" % x for x in ids)
                        _js('%s([%s])' % ('ytTry' if _try else 'ytList', arr))
                return
            vid = re.sub(r'[^\w-]', '', txt)[:20]
            if vid and vid != state['cur']:
                state['cur'] = vid
                if state['web']:
                    # ★★★ **유튜브 쪽에서 돌아오는 길**(2026-09-17) — 재생기 쪽을
                    #   `?v=` 와 함께 다시 연다. 열어 놓고 `ytLoad` 를 쏘면 IFrame
                    #   API 가 아직 안 와 졌다 이겼다 하므로 **쪽이 스스로 만든다**.
                    state['web'] = False
                    state['ready'] = False
                    view.setUrl(QUrl(HOME + '?v=' + vid))
                else:
                    _js(f"ytLoad('{vid}')")
        except Exception:
            pass

    t = QTimer()
    t.timeout.connect(poll_cmd)
    t.start(300)
    sys.exit(app.exec())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', help='spec JSON 파일 경로 (독립 창 모드)')
    ap.add_argument('--embed', action='store_true', help='임베드 모드(frameless, 재부모화용)')
    ap.add_argument('--hwnd-file', dest='hwnd_file', help='임베드: 자기 HWND 기록 파일')
    ap.add_argument('--cmd-file', dest='cmd_file', help='임베드: 영상 전환 명령 파일')
    ap.add_argument('--note-file', dest='note_file',
                    help='임베드: 자식이 부모에게 알리는 쪽지(임베드 차단 등)')
    args = ap.parse_args()

    if args.embed:
        if not (args.hwnd_file and args.cmd_file):
            print('[pyqt_media_player] --embed 에는 --hwnd-file, --cmd-file 필요')
            sys.exit(2)
        embed_main(args)
        return

    if not args.data:
        print('[pyqt_media_player] --data 또는 --embed 필요')
        sys.exit(2)

    try:
        with open(args.data, encoding='utf-8') as f:
            spec = json.load(f)
    except Exception as e:
        print(f'[pyqt_media_player] spec 로드 실패: {e}')
        sys.exit(1)
    # 임시 spec 파일은 읽은 즉시 삭제 (런처가 temp 에 생성 → 누적 방지)
    try:
        os.remove(args.data)
    except Exception:
        pass

    title = spec.get('title', '미디어 플레이어')
    videos = spec.get('videos', []) or []

    print(f'[player] start: videos={len(videos)} title={title!r}',
          file=sys.stderr, flush=True)
    # Chromium 샌드박스 플래그 (일부 환경 호환)
    os.environ.setdefault('QTWEBENGINE_CHROMIUM_FLAGS', '--no-sandbox')

    from PyQt6.QtWidgets import (QApplication, QWidget, QHBoxLayout, QVBoxLayout,
                                 QListWidget, QListWidgetItem, QLabel, QPushButton)
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    from PyQt6.QtCore import QUrl, Qt
    from PyQt6.QtGui import QDesktopServices

    app = QApplication(sys.argv)
    _set_chrome_ua()
    win = QWidget()
    win.setWindowTitle(title)
    win.resize(1120, 640)
    root = QHBoxLayout(win)

    # ── 좌측: 제목 + 목록 ──────────────────────────────────────────────
    left = QVBoxLayout()
    hdr = QLabel(title)
    hdr.setStyleSheet('font-weight:bold; font-size:13px; padding:6px 4px; color:#1A5276;')
    hdr.setWordWrap(True)
    left.addWidget(hdr)

    listw = QListWidget()
    listw.setStyleSheet('QListWidget{font-size:12px;} QListWidget::item{padding:5px;}')
    left.addWidget(listw, 1)

    open_btn = QPushButton('▶ 브라우저에서 열기')
    left.addWidget(open_btn)

    left_w = QWidget()
    left_w.setLayout(left)
    left_w.setMinimumWidth(280)
    left_w.setMaximumWidth(420)

    # ── 우측: 인라인 플레이어 ──────────────────────────────────────────
    browser = QWebEngineView()
    root.addWidget(left_w, 1)
    root.addWidget(browser, 3)

    # 로컬 HTTP 서버 + 플레이어 페이지 1회 로드 (전환은 ytLoad — 페이지 재로드 안 함)
    port, _srv = _start_local_server()
    dstate = {'ready': False, 'pending': None}

    def _djs(code):
        browser.page().runJavaScript(code)

    def _on_loaded(ok):
        print(f'[player] loadFinished={ok}', file=sys.stderr, flush=True)
        dstate['ready'] = bool(ok)
        if ok and dstate['pending']:
            _djs(f"ytLoad('{dstate['pending']}')")
            dstate['pending'] = None
    browser.loadFinished.connect(_on_loaded)
    browser.setUrl(QUrl(f'http://127.0.0.1:{port}/'))

    # 영상 항목 구성
    items = []
    for v in videos:
        url = (v.get('url') or '').strip()
        emb = youtube_embed(url)
        vid = emb.rsplit('/', 1)[-1] if emb else None
        items.append({
            'title': v.get('title', '(제목 없음)'),
            'url': url,
            'vid': vid,              # None 이면 비-YouTube
            'tag': v.get('tag', ''),
        })
        label = f"{v.get('tag','')} {v.get('title','(제목 없음)')}".strip()
        if vid is None:
            label = '' + label    # 비-YouTube 표시 (브라우저로 열림)
        QListWidgetItem(label, listw)

    def show_row(row):
        if not (0 <= row < len(items)):
            return
        it = items[row]
        if it['vid']:
            # 영상 전환 = ytLoad(JS). 페이지 로드 전이면 pending 으로 대기.
            if dstate['ready']:
                _djs(f"ytLoad('{it['vid']}')")
            else:
                dstate['pending'] = it['vid']
        else:
            # 비-YouTube: 플레이어 비우고 시스템 브라우저로 열기
            if dstate['ready']:
                _djs('ytBlank()')
            if it['url']:
                QDesktopServices.openUrl(QUrl(it['url']))

    def open_external():
        row = listw.currentRow()
        if 0 <= row < len(items) and items[row]['url']:
            QDesktopServices.openUrl(QUrl(items[row]['url']))

    listw.currentRowChanged.connect(show_row)
    open_btn.clicked.connect(open_external)

    if items:
        listw.setCurrentRow(0)
    else:
        browser.setHtml(
            '<div style="font-family:Malgun Gothic,sans-serif;padding:24px;color:#888">'
            '<h3>표시할 영상이 없습니다.</h3></div>')

    win.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
