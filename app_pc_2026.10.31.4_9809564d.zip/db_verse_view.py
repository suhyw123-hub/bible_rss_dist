# -*- coding: utf-8 -*-
"""절별 관점(VERS_VIEW) 스키마 + 적재 — 영구 도구 (§0-5 KEEP)

**왜 있나.** EXPERT 설명문에서 견해가 갈리는 자리를 나란히 보이려면 절 하나에 여러 행이
필요한데, `VERS_DESC` 에 붙이면 기존 읽기 경로(`TIER_ORDER … LIMIT 1`)가 깨진다.
그래서 구조 표를 따로 두고 본문만 `sys_text_asset` 에 담는다 —
`sys_entity_pericope` + `ENTITY_PERI_DESC`(§12)와 같은 얼개다.

**두 축으로 나눈다** (expert.md 「관점 설계」). 하나만으로는 「특정 관점만 골라 읽기」가 안 된다.
  · `view_kind` 무엇이 갈리는가 — LANG 원어·번역 / REF 대상 / SENSE 뜻·신학 / TIME 시기 / HIST 배경
  · `trad_id`   누구의 관점인가 — **열린 어휘. 표 한 행으로 늘린다.** NULL 허용

  sys_view_tradition (trad_id · trad_code · sort_order · record_status)
  sys_verse_view     (view_id · verse_id · view_kind · trad_id · sort_order · record_status)
  sys_text_asset     (text_type='VERS_VIEW',      clicked_id=view_id)   관점 본문
  sys_text_asset     (text_type='VIEW_TRAD_NAME', clicked_id=trad_id)   관점 이름(다국어)
  sys_text_asset     (text_type='VERS_VIEWMAP',   clicked_id=verse_id)  관점 정리(절당 하나)

⚠ **논쟁 생성기가 아니다.** 주석이 같은 말을 하면 한 줄로 적는다. 그리고
   **간접 인용을 근거로 쓰지 않는다** — 1차 자료를 직접 확인한다(expert.md 「참고 범위」).

  --selftest   (의무)
  --init       표 생성 + 관점 어휘 시드 (멱등)
  --load  <json>   초안 적재
  --show  <bcode> <chapter> <verse>
"""
import io, json, os, sys, appdb

VIEW_KINDS = {
    'LANG': ('원어·번역이 갈린다', 'Wording differs'),
    'REF':  ('가리키는 대상이 갈린다', 'Referent differs'),
    'SENSE': ('뜻이 갈린다', 'Sense differs'),
    'TIME': ('시기·순서가 갈린다', 'Timing differs'),
    'HIST': ('배경 이해가 갈린다', 'Background differs'),
    # ★ 2026-10-13 (docs/1.txt 76-3 사용자 「쟁점이 없더라도 어떤 관점에서 특별히 비중을 두고 있고 다른 관점은 무관심하다면」)
    'EMPH': ('특별히 비중을 둔다', 'Particular emphasis'),
}

# 열린 어휘 — 늘리려면 여기 한 줄. 코드도 스키마도 안 건드린다.
TRADITIONS = [
    ('PATRISTIC',   10, '초기 교부',      'Early church fathers'),
    ('RABBINIC',    20, '랍비 전통',      'Rabbinic tradition'),
    ('CATHOLIC',    30, '로마 가톨릭',    'Roman Catholic'),
    ('ORTHODOX',    40, '동방 정교',      'Eastern Orthodox'),
    ('LUTHERAN',    50, '루터파',         'Lutheran'),
    ('REFORMED',    60, '개혁주의',       'Reformed'),
    ('ARMINIAN',    70, '알미니안',       'Arminian'),
    ('WESLEYAN',    80, '웨슬리안',       'Wesleyan'),
    ('ANABAPTIST',  90, '재세례파',       'Anabaptist'),
    ('DISPENSATIONAL', 100, '세대주의',   'Dispensational'),
    ('PENTECOSTAL',  85, '오순절',        'Pentecostal'),
    ('CRITICAL',   110, '비평학',         'Critical scholarship'),
]

DDL = [
    """CREATE TABLE IF NOT EXISTS sys_view_tradition (
         trad_id INTEGER PRIMARY KEY AUTOINCREMENT,
         trad_code TEXT UNIQUE NOT NULL,
         sort_order INTEGER DEFAULT 0,
         record_status TEXT DEFAULT 'LIVE')""",
    """CREATE TABLE IF NOT EXISTS sys_verse_view (
         view_id INTEGER PRIMARY KEY AUTOINCREMENT,
         verse_id INTEGER NOT NULL,
         view_kind TEXT NOT NULL,
         trad_id INTEGER,
         sort_order INTEGER DEFAULT 0,
         record_status TEXT DEFAULT 'LIVE')""",
    "CREATE INDEX IF NOT EXISTS idx_verse_view_vid ON sys_verse_view(verse_id)",
]


def init(conn):
    cur = conn.cursor()
    for q in DDL:
        cur.execute(q)
    for code, order, ko, en in TRADITIONS:
        r = cur.execute('SELECT trad_id FROM sys_view_tradition WHERE trad_code=?', (code,)).fetchone()
        if r:
            tid = r[0]
            cur.execute('UPDATE sys_view_tradition SET sort_order=? WHERE trad_id=?', (order, tid))
        else:
            cur.execute('INSERT INTO sys_view_tradition(trad_code,sort_order) VALUES(?,?)', (code, order))
            tid = cur.lastrowid
        for lang, nm in (('KO', ko), ('EN', en)):
            cur.execute("DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type='VIEW_TRAD_NAME'"
                        " AND lang_code=?", (tid, lang))
            cur.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,contents,record_status)"
                        " VALUES(?,'VIEW_TRAD_NAME',?,?,'LIVE')", (tid, lang, nm))
    conn.commit()
    print('표 생성 + 관점 어휘 %d개 시드' % len(TRADITIONS))


def _vid(conn, b, c, v):
    r = conn.execute('SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?',
                     (b, c, v)).fetchone()
    return r[0] if r else None


def load(conn, path):
    """초안 JSON 적재 (멱등 — 그 절의 기존 관점을 지우고 다시 넣는다).

    {"verses":[{"ref":[1,6,2],
                "views":[{"kind":"SENSE","trad":"RABBINIC","KO":"…","EN":"…"}, …],
                "viewmap":{"KO":"…","EN":"…"}}]}
    """
    d = json.load(io.open(path, encoding='utf-8'))
    cur = conn.cursor()
    trads = {c: i for i, c in cur.execute('SELECT trad_id,trad_code FROM sys_view_tradition')}
    nv = nm = 0
    for item in d['verses']:
        b, c, v = item['ref']
        vid = _vid(conn, b, c, v)
        if vid is None:
            raise SystemExit('없는 절: %s' % (item['ref'],))
        old = [r[0] for r in cur.execute('SELECT view_id FROM sys_verse_view WHERE verse_id=?', (vid,))]
        for oid in old:
            cur.execute("DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type='VERS_VIEW'", (oid,))
        cur.execute('DELETE FROM sys_verse_view WHERE verse_id=?', (vid,))
        for n, w in enumerate(item.get('views', []), start=1):
            if w['kind'] not in VIEW_KINDS:
                raise SystemExit('모르는 view_kind: %s' % w['kind'])
            tid = trads.get(w.get('trad')) if w.get('trad') else None
            if w.get('trad') and tid is None:
                raise SystemExit('모르는 관점 코드: %s — TRADITIONS 에 추가할 것' % w['trad'])
            cur.execute('INSERT INTO sys_verse_view(verse_id,view_kind,trad_id,sort_order)'
                        ' VALUES(?,?,?,?)', (vid, w['kind'], tid, n * 10))
            wid = cur.lastrowid
            for lang in ('KO', 'EN'):
                if w.get(lang):
                    cur.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,contents,record_status)"
                                " VALUES(?,'VERS_VIEW',?,?,'LIVE')", (wid, lang, w[lang]))
            nv += 1
        mp = item.get('viewmap') or {}
        cur.execute("DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type='VERS_VIEWMAP'", (vid,))
        for lang in ('KO', 'EN'):
            if mp.get(lang):
                cur.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,contents,record_status)"
                            " VALUES(?,'VERS_VIEWMAP',?,?,'LIVE')", (vid, lang, mp[lang]))
                nm += 1
    conn.commit()
    print('관점 %d개 · 관점 정리 %d행 적재' % (nv, nm))


def fetch(conn, verse_id, lang='KO'):
    """화면용 — [(라벨, 본문)]. 없으면 빈 리스트."""
    out = []
    q = """SELECT w.view_kind, w.trad_id,
                  (SELECT contents FROM sys_text_asset WHERE clicked_id=w.view_id
                     AND text_type='VERS_VIEW' AND lang_code=?
                     AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1)
             FROM sys_verse_view w
            WHERE w.verse_id=? AND COALESCE(w.record_status,'LIVE')='LIVE'
            ORDER BY w.sort_order, w.view_id"""
    try:
        rows = conn.execute(q, (lang, verse_id)).fetchall()
    except Exception:
        return out                       # 표가 아직 없으면 조용히 비운다
    for kind, tid, body in rows:
        if not body:
            continue
        lbl = VIEW_KINDS.get(kind, (kind, kind))[0 if lang == 'KO' else 1]
        if tid:
            nm = conn.execute("SELECT contents FROM sys_text_asset WHERE clicked_id=?"
                              " AND text_type='VIEW_TRAD_NAME' AND lang_code=? LIMIT 1",
                              (tid, lang)).fetchone()
            if nm and nm[0]:
                lbl = '%s — %s' % (lbl, nm[0])
        out.append((lbl, body))
    return out


def show(conn, b, c, v):
    vid = _vid(conn, b, c, v)
    for lbl, body in fetch(conn, vid):
        print('◈ %s\n   %s\n' % (lbl, body[:300]))
    r = conn.execute("SELECT contents FROM sys_text_asset WHERE clicked_id=?"
                     " AND text_type='VERS_VIEWMAP' AND lang_code='KO' LIMIT 1", (vid,)).fetchone()
    if r:
        print('▶ 관점 정리\n   %s' % r[0][:400])


def selftest():
    """탐지력 확인 — 조용히 틀릴 자리를 짚는다."""
    ok = True
    checks = [('view_kind 6종', sorted(VIEW_KINDS) == sorted(['LANG', 'REF', 'SENSE', 'TIME', 'HIST', 'EMPH']), True),
              ('관점 어휘 코드 중복 없음', len({t[0] for t in TRADITIONS}) == len(TRADITIONS), True),
              ('정렬값 중복 없음', len({t[1] for t in TRADITIONS}) == len(TRADITIONS), True)]
    for lbl, got, want in checks:
        good = got == want
        ok &= good
        print('  [%s] %s' % ('PASS' if good else 'FAIL', lbl))
    # 표가 없을 때 fetch 가 죽지 않아야 한다 (LAY 전권 작업 동안 EXPERT 데이터가 없다)
    import sqlite3
    mem = sqlite3.connect(':memory:')
    good = fetch(mem, 1) == []
    ok &= good
    print('  [%s] 표 없을 때 fetch 빈 리스트' % ('PASS' if good else 'FAIL'))
    print('selftest', 'PASS' if ok else 'FAIL')
    return ok


if __name__ == '__main__':
    a = sys.argv
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect()
    if '--init' in a:
        init(conn)
    if '--load' in a:
        load(conn, a[a.index('--load') + 1])
    if '--show' in a:
        i = a.index('--show')
        show(conn, int(a[i + 1]), int(a[i + 2]), int(a[i + 3]))
