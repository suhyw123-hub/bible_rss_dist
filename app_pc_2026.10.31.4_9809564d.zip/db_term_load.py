# -*- coding: utf-8 -*-
"""주요용어(entity_type='TERM') 스키마 + 적재 — 영구 도구 (§0-5 KEEP)

**왜 있나.** 「헤세드」·「토브」처럼 **낱말 자체가 대상**인 것은 인물·장소와 달리 성경 안에
실재하는 것이 아니라서 기존 아홉 유형에 들어가지 않는다. 그렇다고 새 체계를 세울 것도
아니다 — 이름·설명 다국어 · 관리자 패널 · 외부 사이트 URL · P1 티커가 전부 엔티티에
붙어 있으므로 **유형값 하나를 더한다**(2026-06-05 DOCTRINE 을 더한 것과 같은 방식).

**핵심은 원어 앵커다.** 항목마다 앵커가 **0개 또는 여러 개**다.

    「인애 · 헤세드」  HE H2617          → 낱말이 있는 절 241개가 기계로 나온다
    「언약」           HE H1285 · EL G1242 → 두 언약이 한 항목에서 만난다  ★ 이것이 대응표다
    「삼위일체」       앵커 없음          → 낱말이 없다는 것이 사실이지 분류가 아니다

  그래서 **DOCTRINE 이냐 TERM 이냐를 물을 일이 없다.** 있는 만큼 붙고 없으면 안 붙는다.
  한 주제에 항목은 **하나**다 — 「언약」이 이미 DOCTRINE 에 있으면 「베리트」를 새로 만들지
  말고 그 항목에 앵커를 붙인다.

**표 이름이 `sys_term_*` 이 아니라 `sys_entity_*` 인 이유** (사용자 지적, 2026-08-09):
  엔티티 기능은 이미 일반화돼 있다 — 낱말이 없는 구절도 사람 판단으로 연결할 수 있다.
  용어 전용 표를 만들면 나중에 PLACE(벧엘=베이트엘)·PERSON 절 단위 연결에서 같은 표를
  하나 더 만들게 된다. **처음부터 엔티티 전체에 건다.**

    sys_entity_lemma   entity_id · lang_code(HE|EL) · strong · translit · gloss
    sys_entity_verse   entity_id · verse_id · link_kind(LEXICAL|THEMATIC) · is_key
    sys_text_asset     text_type='ENTITY_VERSE_DESC', clicked_id=ev_id   (THEMATIC 연결설명문)

⚠ **LEXICAL 은 로컬 검증 DB 에서 만든다.** `wlc_verify.db`(구약, §18-10) / `gnt_verify.db`(신약).
   둘 다 **배포하지 않는다.** 여기서 뽑아 낸 `(entity_id, verse_id)` 행만 `bible_master.db`
   에 들어가므로 스트롱 번호는 배포물에 한 글자도 실리지 않는다.
   원 자료 표기는 `license_info.py` 에 한 줄로 남긴다(CC BY 4.0).

⚠ **빈도가 23배 차이난다** — 샤마 1,072절 · 바라 46절. 전량 저장하되 `is_key` 로 대표를
   골라 화면이 그것부터 보인다. **분류로 풀 문제가 아니다.**

  --selftest              (의무)
  --init                  표 생성 (멱등)
  --load <draft.json>     용어 적재 + LEXICAL 자동 생성
  --relink [<code> …]     앵커에서 LEXICAL 다시 생성 (검증 DB 가 늘었을 때)
  --anchor-audit          두 앵커 규칙 전수 — 첫 문단에 음역이 빠진 용어 (entity.md §5)
  --show <term_code>      한 항목 확인
  --list                  전체 목록
"""
import io, json, os, re, sqlite3, sys
# ★★ 구간 판정은 **한 문**이다(§verse_range) — 차례는 `sort_order` 다.
import verse_range as _vr
import appdb

ETYPE = 'TERM'
CODE_RE = re.compile(r'^T_[A-Z0-9_]+$')
STRONG_RE = re.compile(r'^([HG])\d{1,5}$')
LEMMA_LANGS = ('HE', 'EL')
LINK_KINDS = ('LEXICAL', 'THEMATIC')

# 원어 낱말층 — 로컬 전용, 배포 안 함
VERIFY_DB = {'HE': 'wlc_verify.db', 'EL': 'gnt_verify.db'}

DDL = [
    """CREATE TABLE IF NOT EXISTS sys_entity_lemma (
         lemma_id  INTEGER PRIMARY KEY AUTOINCREMENT,
         entity_id INTEGER NOT NULL,
         lang_code TEXT    NOT NULL,
         strong    TEXT    NOT NULL,
         translit  TEXT,
         gloss     TEXT,
         sort_order INTEGER DEFAULT 0,
         record_status TEXT DEFAULT 'LIVE')""",
    "CREATE UNIQUE INDEX IF NOT EXISTS idx_entity_lemma_uq ON sys_entity_lemma(entity_id, strong)",
    "CREATE INDEX IF NOT EXISTS idx_entity_lemma_strong ON sys_entity_lemma(strong)",
]

#: ★★ 2026-08-24 — **용어 ↔ 구절 연결을 통합 표로 옮겼다**(`db_link_migrate.py`).
#   `sys_link_asset(link_type='ENTI_VERS')` 한 행이고
#   `link_kind`→`rel_code` · `is_key`·`lemma_id` 는 곁다리 칸 그대로다.
#   옛 표 `sys_entity_verse` 는 되돌릴 수 있게 남아 있지만 **읽지 않는다.**
#   ⚠ `sys_entity_lemma`(원어 낱말)는 **연결이 아니라 자산이라 그대로 있다.**
EV_TABLE = 'sys_link_asset'
EV_TYPE  = 'ENTI_VERS'
EV_A, EV_B, EV_ID = 'clicked_id', 'target_id', 'sys_link_id'
EV_WHERE = "link_type='%s'" % EV_TYPE

#: ★★★ **`ENTI_VERS` 의 `rel_code` 는 층이 둘이다** (2026-09-24 · 1.txt 15번 4)).
#:   ⓐ **낱말 층** — 원어 앵커에서 **기계로** 나온 절(색인 · 설명문 없음)
#:   ⓑ **의미 층** — **사람이 이은** 절(설명문이 본체)
#: 의미 층 안에서 `rel_code` 가 **그 연결의 성격**을 말한다:
#:   `THEMATIC`   주제 연결(기본)
#:   `POSTURE`    **그 자세가 드러난 구절** — 사조가 실제로 어떤 모습인지
#:   `DISCERN`    **성경의 분별·권면** — 그 물음에 성경이 무엇이라 답하는지
#:   `BACKGROUND` 배경 · `ANTAGONIST` 대적자
#: ⚠⚠ **읽는 쪽은 이 목록으로 좁힌다 — 등호로 좁히지 말 것.** 등호로 두면
#:   새 성격값이 생기는 날 그 절들이 **화면에서 조용히 사라진다**(실측 —
#:   `BACKGROUND` 13행·`ANTAGONIST` 3행이 그렇게 빠져 있었다).
LEX_KINDS = ('LEXICAL',)
MEANING_KINDS = ('THEMATIC', 'POSTURE', 'DISCERN', 'BACKGROUND', 'ANTAGONIST')
MEANING_DEFAULT = 'THEMATIC'


def init(conn):
    cur = conn.cursor()
    for q in DDL:
        cur.execute(q)
    conn.commit()
    print('원어 낱말 표 준비 (sys_entity_lemma) · 연결은 통합 표 sys_link_asset')


# ── 원어 낱말층 조회 ────────────────────────────────────────────────────────
def strong_verses(strong, conn=None):
    """그 Strong 번호가 있는 verse_id 목록 — **두 재료의 합집합**.

    ★★ 2026-09-15 (항목 ② · 승격 화면) — 그전에는 로컬 검증 DB(wlc/gnt_verify.db)
      **만** 읽어 그 파일이 없는 PC 에서는 승격이 절 연결 0건으로 끝났다.
      배포 DB 안의 절↔낱말 표(`sys_verse_lemma` · 254차)를 `conn` 으로 함께 읽는다.
    ⚠ **한쪽으로 바꾸지 않고 합친다** — 실측 사람 용어 앵커 229개 중 28개는
      배포 표가 더 많고(칼로스 91 vs 86), 3개는 검증 DB 만 있다(여호와 H3068
      5,519절 — 고유명사라 254차가 배포 표에서 뺐다). 어느 한쪽만 쓰면 잃는다.
    · 둘 다 없으면 None (0건과 구별) · 하나라도 있으면 그 합집합(오름차순).
    """
    lang = 'HE' if strong.startswith('H') else 'EL'
    got, any_src = set(), False
    path = VERIFY_DB[lang]
    if os.path.exists(path):
        db = sqlite3.connect(path)
        tbl = 'wlc_verse' if lang == 'HE' else 'gnt_verse'
        try:
            got.update(r[0] for r in db.execute(
                "SELECT verse_id FROM %s WHERE ' '||strongs||' ' LIKE ? ORDER BY verse_id" % tbl,
                ('%% %s %%' % strong,)).fetchall())
            any_src = True
        except sqlite3.OperationalError:
            pass
        finally:
            db.close()
    if conn is not None:
        try:
            import db_lex_link as _LL
            if conn.execute("SELECT 1 FROM sqlite_master WHERE name='sys_verse_lemma'").fetchone():
                got.update(_LL.verses_of(conn, strong))
                any_src = True
        except Exception:
            pass
    if not any_src:
        return None
    return sorted(got)


# ── 적재 ────────────────────────────────────────────────────────────────────
def _vid(conn, b, c, v):
    r = conn.execute('SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?',
                     (b, c, v)).fetchone()
    return r[0] if r else None


def _upsert_text(cur, cid, ttype, lang, body):
    cur.execute('DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type=? AND lang_code=?',
                (cid, ttype, lang))
    if body and body.strip():
        cur.execute('INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,contents,record_status)'
                    " VALUES(?,?,?,?,'LIVE')", (cid, ttype, lang, body))


def _peri_label(conn, peri_id):
    """단락 하나를 사람이 읽는 범위로 — `창1:1~2:3`. 못 찾으면 번호만."""
    r = conn.execute(
        "SELECT bn.short_name, b1.chapter, b1.verse, b2.chapter, b2.verse "
        "FROM sys_pericope_asset pa "
        "JOIN bible_index b1 ON b1.verse_id=pa.start_vid "
        "JOIN bible_index b2 ON b2.verse_id=pa.end_vid "
        "LEFT JOIN book_names bn ON bn.book_code=b1.bcode AND bn.lang_code='KO' "
        "WHERE pa.pericope_id=?", (peri_id,)).fetchone()
    if not r:
        return '#%d' % peri_id
    bk, c1, v1, c2, v2 = r
    tail = '%d:%d~%d' % (c1, v1, v2) if c1 == c2 else '%d:%d~%d:%d' % (c1, v1, c2, v2)
    return '%s%s' % (bk or '', tail)


def linked_peri_spans(conn, entity_id):
    """그 엔티티가 **단락으로** 이어 둔 구간들 — `[(peri_id, 라벨, 시작vid, 끝vid)]`.

    ⚠ 단락 연결과 절 연결은 **같은 목록에 나란히 뜬다**(연결구절 탭). 단락 구간 안의
      절을 또 이으면 사람 눈에는 같은 대목이 두 번이다. 그것을 여기서 잰다.
    """
    if conn is None or not entity_id:
        return []
    try:
        return [(r[0], _peri_label(conn, r[0]), r[1], r[2]) for r in conn.execute(
            "SELECT pa.pericope_id, pa.start_vid, pa.end_vid "
            "FROM sys_link_asset ep "
            "JOIN sys_pericope_asset pa ON pa.pericope_id=ep.target_id "
            "WHERE ep.link_type='ENTI_PERI' AND ep.clicked_id=? "
            "  AND COALESCE(ep.record_status,'LIVE')='LIVE' "
            "  AND pa.record_status='LIVE' AND pa.peri_type='BODY'",
            (entity_id,)).fetchall()]
    except Exception as e:                      # 표가 없는 DB 로 열어도 죽지 않는다
        print('[db_term_load] linked_peri_spans: %s' % e)
        return []


def thematic_vids_in_span(conn, entity_id, start_vid, end_vid):
    """반대 방향 — 그 엔티티의 **의미 절 연결** 중 이 구간 안에 있는 것.

    관리자가 단락을 새로 이을 때 쓴다(이미 절로 이어 둔 자리를 단락이 덮는 경우).
    돌려주는 것은 `[(verse_id, '창1:1')]`.
    """
    if conn is None or not entity_id:
        return []
    try:
        return [(r[0], '%s%d:%d' % (r[1] or '', r[2], r[3])) for r in conn.execute(
            "SELECT ev.target_id, bn.short_name, bi.chapter, bi.verse "
            "FROM sys_link_asset ev "
            "JOIN bible_index bi ON bi.verse_id=ev.target_id "
            "LEFT JOIN book_names bn ON bn.book_code=bi.bcode AND bn.lang_code='KO' "
            "WHERE ev.link_type=? AND ev.clicked_id=? AND ev.rel_code='THEMATIC' "
            "  AND COALESCE(ev.record_status,'LIVE')='LIVE' "
            "  AND ev.target_id BETWEEN ? AND ? "
            "ORDER BY ev.target_id",
            (EV_TYPE, entity_id, start_vid, end_vid)).fetchall()]
    except Exception as e:
        print('[db_term_load] thematic_vids_in_span: %s' % e)
        return []


def _linked_peri_spans(conn, entity_id):        # check() 안에서만 쓰는 별칭
    return linked_peri_spans(conn, entity_id)


def _span_hit(spans, vid):
    """그 절을 덮는 단락이 있으면 `(peri_id, 라벨)`, 없으면 None."""
    for pid, label, a, b in spans:
        if a is not None and b is not None and a <= vid <= b:
            return (pid, label)
    return None


def anchor_mentions(desc, translits):
    """★ 두 앵커 규칙 (2026-09-15 항목 ③ · entity.md §5) — **첫 문단에 빠진 음역**.

    앵커가 둘 이상인 용어(영광 = 카보드·독사)는 설명문 **첫 문단**이 두 낱말의
    관계를 말해야 한다. 안 그러면 끝 문단에 「신약은 독사로 받았고」가 불쑥
    나와 독자가 그 낱말이 무엇인지 모른다(실측 81용어 중 66이 그랬다).
    · 음역이 하나 이하면 빈 목록(규칙 대상이 아니다) · 첫 문단 = 첫 줄바꿈 앞.
    """
    tr = [t for t in (translits or []) if t]
    if len(tr) < 2:
        return []
    first = (desc or '').strip().split(chr(10))[0]
    return [t for t in tr if t not in first]


def audit_anchor_mentions(conn, lang='KO'):
    """DB 의 살아 있는 용어 전부에 위 규칙을 건다 → [(entity_id, code, name, [빠진 음역])]."""
    out = []
    rows = conn.execute(
        "SELECT e.entity_id, e.entity_code,"
        " (SELECT contents FROM sys_text_asset WHERE clicked_id=e.entity_id"
        "   AND text_type='ENTITY_NAME' AND lang_code=? AND record_status='LIVE' LIMIT 1),"
        " (SELECT contents FROM sys_text_asset WHERE clicked_id=e.entity_id"
        "   AND text_type='ENTITY_DESC' AND lang_code=? AND record_status='LIVE' LIMIT 1)"
        " FROM sys_entity_master e WHERE e.record_status='LIVE'"
        " AND (SELECT COUNT(*) FROM sys_entity_lemma l WHERE l.entity_id=e.entity_id"
        "      AND COALESCE(l.record_status,'LIVE')='LIVE') >= 2"
        " ORDER BY e.entity_id", (lang, lang)).fetchall()
    for eid, code, name, desc in rows:
        if not desc:
            continue
        tr = [r[0] for r in conn.execute(
            "SELECT translit FROM sys_entity_lemma WHERE entity_id=?"
            " AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY sort_order, lemma_id",
            (eid,))]
        miss = anchor_mentions(desc, tr)
        if miss:
            out.append((eid, code, name or '', miss))
    return out


def check(draft, conn=None):
    """적재 전 검증. 위반 목록을 돌려준다 (빈 리스트면 통과).

    ⚠ `conn` 을 주면 **THEMATIC 이 정말 낱말 없는 절인지**까지 본다. 이것이 두 연결
       종류를 가르는 정의다 — 낱말이 있는 절을 THEMATIC 으로 넣으면 화면에 같은 절이
       두 번 뜬다(2026-08-09 시범 적재에서 룻 2:20 · 삼상 20:14 이 실제로 그랬다).
    """
    bad = []
    seen = set()
    for t in draft.get('terms', []):
        code = t.get('code', '')
        tag = code or '(코드 없음)'
        exists = None
        if conn is not None:
            exists = conn.execute('SELECT entity_id, entity_type FROM sys_entity_master'
                                  ' WHERE entity_code=?', (code,)).fetchone()
        if not exists and not CODE_RE.match(code):
            # 새로 만드는 것만 `T_` 를 강제한다. 기존 항목(D_COVENANT 등)에 앵커를
            # 붙이는 일이 흔하고, 그때 코드를 바꾸면 연결이 통째로 끊긴다.
            bad.append('%s — 새 용어 코드 규약 위반 (T_대문자)' % tag)
        if code in seen:
            bad.append('%s — 코드 중복' % tag)
        seen.add(code)
        if not exists:
            for lang in ('KO', 'EN'):
                if not (t.get(lang) or '').strip():
                    bad.append('%s — 이름 %s 없음' % (tag, lang))
                if not (t.get('desc_' + lang) or '').strip():
                    bad.append('%s — 설명 %s 없음' % (tag, lang))
        st = set()
        for lm in t.get('lemmas', []):
            s = lm.get('strong', '')
            if not STRONG_RE.match(s):
                bad.append('%s — Strong 형식 오류: %r' % (tag, s))
            if s in st:
                bad.append('%s — 앵커 중복: %s' % (tag, s))
            st.add(s)
            if lm.get('lang') not in LEMMA_LANGS:
                bad.append('%s — lang 은 HE|EL 이어야 한다: %r' % (tag, lm.get('lang')))
            want = 'H' if lm.get('lang') == 'HE' else 'G'
            if STRONG_RE.match(s) and not s.startswith(want):
                bad.append('%s — lang(%s) 과 Strong(%s) 이 어긋난다' % (tag, lm.get('lang'), s))
        # ★ 두 앵커 규칙 (2026-09-15) — KO 설명문을 적는 초안이면 첫 문단에
        #   음역이 다 있어야 한다. 음역은 초안 lemmas 에서, 없으면 DB 앵커에서.
        if (t.get('desc_KO') or '').strip():
            _trs = [lm.get('translit', '') for lm in t.get('lemmas', [])]
            if not any(_trs) and conn is not None and exists:
                _trs = [r[0] for r in conn.execute(
                    "SELECT translit FROM sys_entity_lemma WHERE entity_id=?"
                    "  AND COALESCE(record_status,'LIVE')='LIVE'", (exists[0],))]
            _miss = anchor_mentions(t.get('desc_KO'), _trs)
            if _miss:
                bad.append('%s — 앵커가 둘 이상인데 KO 설명문 첫 문단에 음역이 빠졌다: %s'
                           ' (entity.md §5 두 앵커 규칙)' % (tag, ' · '.join(_miss)))
        lex_vids = set()
        if conn is not None:
            # ⚠⚠ **초안에 적힌 앵커만 보면 게이트가 조용히 눈을 감는다**
            #   (2026-09-01 실측으로 잡았다). 이미 있는 용어에 **의미연결만
            #   더하는 초안**에는 `lemmas` 를 다시 안 적는다 — 그게 보통이다.
            #   그러면 `lex_vids` 가 비어 「낱말 있는 절을 THEMATIC 으로」가
            #   **통과한다.** ⇒ 초안에 없으면 **DB 에 등록된 앵커를 읽는다.**
            _st = set(st)
            if not _st and exists:
                _st = {r[0] for r in conn.execute(
                    "SELECT strong FROM sys_entity_lemma WHERE entity_id=?"
                    "  AND COALESCE(record_status,'LIVE')='LIVE'", (exists[0],))
                    if r[0]}
            for s in _st:
                v = strong_verses(s)
                if v:
                    lex_vids |= set(v)
        peri_spans = _linked_peri_spans(conn, exists[0] if exists else None)
        for th in t.get('thematic', []):
            if not (th.get('KO') or '').strip():
                bad.append('%s — THEMATIC 연결에 설명이 없다 %s' % (tag, th.get('ref')))
            if conn is not None and th.get('ref'):
                vid = _vid(conn, *th['ref'])
                # ★★★ **구간이면 구간 전체를 본다** (2026-09-01) — 시작 절만
                #   보면 `창1:3~5` 의 4절에 앵커 낱말이 있어도 통과한다. 그러면
                #   화면에서 **그 절이 두 번** 뜬다(낱말 행 + 구간 안). 두 연결
                #   종류를 가르는 정의가 무너지는 것이 정확히 그 자리다.
                _span = [vid] if vid else []
                if vid and th.get('end'):
                    _e = _vid(conn, *th['end'])
                    if _e is None:
                        bad.append('%s — 없는 절 %s' % (tag, th['end']))
                    elif _e < vid:
                        bad.append('%s — 구간 끝이 시작보다 앞이다 %s~%s'
                                   % (tag, th['ref'], th['end']))
                    else:
                        _b1 = conn.execute('SELECT bcode FROM bible_index'
                                           ' WHERE verse_id=?', (vid,)).fetchone()
                        _b2 = conn.execute('SELECT bcode FROM bible_index'
                                           ' WHERE verse_id=?', (_e,)).fetchone()
                        if _b1 and _b2 and _b1[0] != _b2[0]:
                            # ⚠ `verse_id` 는 연속이 아니다(§113차 절체계 이형) —
                            #   책을 넘는 구간은 범위 질의를 폭주시킨다.
                            bad.append('%s — 구간이 책을 넘는다 %s~%s'
                                       % (tag, th['ref'], th['end']))
                        else:
                            _span = [r[0] for r in conn.execute(
                                'SELECT bi.verse_id FROM bible_index bi WHERE '
                                + _vr.between_sql('bi.verse_id'),
                                _vr.between_args(vid, _e))]
                if vid is None:
                    bad.append('%s — 없는 절 %s' % (tag, th['ref']))
                elif set(_span) & lex_vids:
                    bad.append('%s — %s 에는 앵커 낱말이 **있다**. THEMATIC 이 아니라'
                               ' key_verses 로 넣을 것 (구간이면 그 안의 절)'
                               % (tag, th['ref']))
                else:
                    hit = next((_span_hit(peri_spans, x) for x in _span
                                if _span_hit(peri_spans, x)), None)
                    if hit:
                        bad.append('%s — %s 는 이미 **단락으로 이어 둔** 구간 안이다'
                                   ' (단락 #%d %s). 한 목록에 같은 대목이 두 번 뜬다 —'
                                   ' 절 연결을 빼거나 단락 연결을 끊을 것'
                                   % (tag, th['ref'], hit[0], hit[1]))
    return bad


def load(conn, path):
    """초안을 넣는다.

    ⚠⚠⚠ **`load` 는 그 용어의 기존 연결을 「지우고 다시 넣는다」.**
      2026-09-01 에 이것을 모르고 시험용 초안(`thematic` 한 줄)을 실 DB 에
      돌려 **`T_TOV` 의 낱말연결 698건을 지웠다.** 초안에 `lemmas` 가 없으면
      LEXICAL 이 0건으로 다시 만들어지기 때문이다.
      · 되살린 길 — 낡은 표 `sys_entity_verse`(온전) + 감사 로그 `old_json`.
      · ⚠ **복구도 틀릴 수 있다** — 감사 로그를 **날짜 제한 없이** 훑어
        옛 세션이 이미 지운 시험 행 하나를 되살렸다(P_DAVID→창1:10).
        **이 세션이 지운 것만** 되살린다.
    ⇒ **시험은 실 DB 에 하지 않는다.** 꼭 해야 하면 그 용어의 연결을 먼저
      세어 두고, 끝나고 수치가 같은지 확인한다.
    """
    draft = json.load(io.open(path, encoding='utf-8'))
    # ★ 지우기 전에 몇 건을 지우는지 알린다 — 조용히 사라지지 않게.
    try:
        for _t in draft.get('terms', []):
            _r = conn.execute('SELECT entity_id FROM sys_entity_master'
                              ' WHERE entity_code=?', (_t.get('code'),)).fetchone()
            if not _r:
                continue
            _n = conn.execute(
                "SELECT COUNT(*) FROM %s WHERE %s AND %s=?"
                % (EV_TABLE, EV_WHERE, EV_A), (_r[0],)).fetchone()[0]
            if _n and not _t.get('lemmas'):
                print('  ⚠ %s — 기존 연결 %d건을 지우고 다시 넣습니다.'
                      ' 초안에 앵커(lemmas)가 없으면 **낱말연결이 사라집니다.**'
                      % (_t.get('code'), _n))
    except Exception as _e:
        print('[load] 사전 경고 실패: %s' % _e)
    bad = check(draft, conn)
    if bad:
        print('적재 거부 — 위반 %d건' % len(bad))
        for m in bad:
            print('  X ' + m)
        raise SystemExit(1)

    cur = conn.cursor()
    n_term = n_lex = n_them = 0
    for t in draft['terms']:
        code = t['code']
        r = cur.execute('SELECT entity_id, entity_type FROM sys_entity_master'
                        ' WHERE entity_code=?', (code,)).fetchone()
        if r:
            eid, cur_type = r
            # ⚠ **이미 있는 항목의 유형을 바꾸지 않는다.** 기존 DOCTRINE 에 앵커만 붙이는
            #   일이 흔한데(entity.md §1 — 한 주제에 항목은 하나), 유형을 덮으면 「언약」이
            #   교리 목록에서 사라진다. 새로 만들 때만 TERM 이 된다.
            cur.execute("UPDATE sys_entity_master SET record_status='LIVE' WHERE entity_id=?",
                        (eid,))
        else:
            cur.execute("INSERT INTO sys_entity_master(entity_code,entity_type,importance,record_status)"
                        " VALUES(?,?,?,'LIVE')", (code, ETYPE, t.get('importance', 5)))
            eid = cur.lastrowid
        for lang in ('KO', 'EN'):
            # 앵커만 붙이는 배치에서는 이름·설명을 건드리지 않는다 (기존 교리 글 보존)
            if t.get(lang):
                _upsert_text(cur, eid, 'ENTITY_NAME', lang, t[lang])
            if t.get('desc_' + lang):
                _upsert_text(cur, eid, 'ENTITY_DESC', lang, t['desc_' + lang])

        # 앵커 — 멱등 (지우고 다시)
        cur.execute('DELETE FROM sys_entity_lemma WHERE entity_id=?', (eid,))
        lemma_ids = []
        for i, lm in enumerate(t.get('lemmas', []), start=1):
            cur.execute('INSERT INTO sys_entity_lemma(entity_id,lang_code,strong,translit,gloss,sort_order)'
                        ' VALUES(?,?,?,?,?,?)',
                        (eid, lm['lang'], lm['strong'], lm.get('translit'), lm.get('gloss'), i * 10))
            lemma_ids.append((cur.lastrowid, lm['strong']))

        # 연결 — 이 항목 것만 지우고 다시
        # ★ 2026-08-24 통합 표(`ENTI_VERS`). ⚠ `link_type` 을 걸어야 그 용어의
        #   **구절 연결만** 지운다(단락·자료 연결까지 지우면 안 된다).
        old = [r[0] for r in cur.execute(
            'SELECT %s FROM %s WHERE %s AND %s=?'
            % (EV_ID, EV_TABLE, EV_WHERE, EV_A), (eid,))]
        for oid in old:
            cur.execute("DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type='ENTITY_VERSE_DESC'",
                        (oid,))
        cur.execute('DELETE FROM %s WHERE %s AND %s=?'
                    % (EV_TABLE, EV_WHERE, EV_A), (eid,))

        keys = set()
        for ref in t.get('key_verses', []):
            v = _vid(conn, *ref)
            if v is None:
                raise SystemExit('없는 절: %s (%s)' % (ref, code))
            keys.add(v)

        # ① LEXICAL — 앵커에서 기계로
        got = set()
        for lid, strong in lemma_ids:
            vids = strong_verses(strong, conn)
            if vids is None:
                print('  ! %s 검증 DB 없음 — LEXICAL 건너뜀 (%s)' % (strong, VERIFY_DB[
                    'HE' if strong.startswith('H') else 'EL']))
                continue
            for v in vids:
                if v in got:
                    continue
                got.add(v)
                cur.execute(
                    'INSERT OR IGNORE INTO %s(link_type,%s,%s,rel_code,lemma_id,is_key,record_status)'
                    " VALUES('%s',?,?,'LEXICAL',?,?,'LIVE')"
                    % (EV_TABLE, EV_A, EV_B, EV_TYPE),
                    (eid, v, lid, 1 if v in keys else 0))
                n_lex += 1

        # ② THEMATIC — 사람이 쓴 것. 설명문이 딸린다
        for th in t.get('thematic', []):
            v = _vid(conn, *th['ref'])
            if v is None:
                raise SystemExit('없는 절: %s (%s)' % (th['ref'], code))
            # ★ **구간**(`end`) — 없으면 한 절이다. 시작과 같으면 비워 둔다
            #   (§114차 `scope_label` 이 「한 절이면 빈 칸」이라 적는다).
            ev_end = None
            if th.get('end'):
                ev_end = _vid(conn, *th['end'])
                if ev_end is None:
                    raise SystemExit('없는 절: %s (%s)' % (th['end'], code))
                if ev_end == v:
                    ev_end = None
            cur.execute('INSERT INTO %s(link_type,%s,%s,rel_code,is_key,end_id,record_status)'
                        " VALUES('%s',?,?,'THEMATIC',?,?,'LIVE')"
                        % (EV_TABLE, EV_A, EV_B, EV_TYPE),
                        (eid, v, 1 if th.get('is_key') else 0, ev_end))
            ev = cur.lastrowid
            for lang in ('KO', 'EN'):
                _upsert_text(cur, ev, 'ENTITY_VERSE_DESC', lang, th.get(lang))
            n_them += 1

        n_term += 1
        nm = t.get('KO')
        if not nm:                       # 앵커만 붙이는 배치 — 이름은 DB 에 이미 있다
            r2 = cur.execute("SELECT contents FROM sys_text_asset WHERE clicked_id=?"
                             " AND text_type='ENTITY_NAME' AND lang_code='KO' LIMIT 1",
                             (eid,)).fetchone()
            nm = r2[0] if r2 else ''
        print('  %-22s %-16s 앵커 %d · 낱말있음 %4d · 낱말없음 %d'
              % (code, nm, len(lemma_ids), len(got), len(t.get('thematic', []))))
    conn.commit()
    print('용어 %d개 · LEXICAL %d행 · THEMATIC %d행' % (n_term, n_lex, n_them))


def relink(conn, codes=None, quiet=False):
    """앵커에서 LEXICAL 을 다시 만든다. THEMATIC 과 is_key 는 보존한다.
    재료 = `strong_verses(strong, conn)` 합집합(검증 DB + 배포 표)."""
    cur = conn.cursor()
    q = ("SELECT e.entity_id, e.entity_code FROM sys_entity_master e"
         " WHERE e.entity_type=? AND COALESCE(e.record_status,'LIVE')='LIVE'")
    rows = [r for r in cur.execute(q, (ETYPE,)) if not codes or r[1] in codes]
    total = 0
    for eid, code in rows:
        # ★ 2026-08-24 통합 표(`ENTI_VERS`)
        keys = {r[0] for r in cur.execute(
            "SELECT %s FROM %s WHERE %s AND %s=? AND rel_code='LEXICAL' AND is_key=1"
            % (EV_B, EV_TABLE, EV_WHERE, EV_A), (eid,))}
        cur.execute("DELETE FROM %s WHERE %s AND %s=? AND rel_code='LEXICAL'"
                    % (EV_TABLE, EV_WHERE, EV_A), (eid,))
        got = set()
        for lid, strong in cur.execute(
                'SELECT lemma_id,strong FROM sys_entity_lemma WHERE entity_id=? ORDER BY sort_order',
                (eid,)).fetchall():
            vids = strong_verses(strong, conn)
            if vids is None:
                continue
            for v in vids:
                if v in got:
                    continue
                got.add(v)
                cur.execute(
                    'INSERT OR IGNORE INTO %s(link_type,%s,%s,rel_code,lemma_id,is_key,record_status)'
                    " VALUES('%s',?,?,'LEXICAL',?,?,'LIVE')"
                    % (EV_TABLE, EV_A, EV_B, EV_TYPE),
                    (eid, v, lid, 1 if v in keys else 0))
        total += len(got)
        if not quiet:
            print('  %-14s %d절' % (code, len(got)))
    conn.commit()
    if not quiet:
        print('LEXICAL %d행 재생성' % total)


# ── 조회 ────────────────────────────────────────────────────────────────────
def fetch_verses(conn, entity_id, kind=None, key_only=False, lang='KO', limit=None,
                 lemma_id=None):
    """화면용 — [(verse_id, link_kind, is_key, 설명문)]. 표가 없으면 빈 리스트."""
    # ★ 2026-08-24 통합 표(`ENTI_VERS`). link_kind 는 rel_code 다.
    # ★★★ **다섯째 칸 = 구간 끝** (2026-09-01 사용자 「고정된 단락 단위로
    #   연결하기보다 **각 용어의 성격에 따라 구절구간을 연결**하는 것이
    #   유연할 것이다」 · 「페리코프 단위로 연결했다가는 **아무 의미도 없는
    #   단락의 구절들을 다 읽어야** 하는 문제가 생긴다」).
    #   ⚠ 칸을 늘리면 **푸는 쪽이 조용히 밀린다**(entity.md §9 「all_tags
    #     5→6칸」 사고). 호출부는 둘뿐이고 함께 고쳤다(`entity_browser`).
    q = ("SELECT v.%s, v.rel_code, v.is_key,"
         "  (SELECT contents FROM sys_text_asset WHERE clicked_id=v.%s"
         "     AND text_type='ENTITY_VERSE_DESC' AND lang_code=?"
         "     AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1),"
         "  v.end_id"
         " FROM %s v"
         " WHERE v.%s AND v.%s=? AND COALESCE(v.record_status,'LIVE')='LIVE'"
         % (EV_B, EV_ID, EV_TABLE, EV_WHERE, EV_A))
    p = [lang, entity_id]
    if kind:
        # ★ **하나든 목록이든 받는다** — 의미 층은 `rel_code` 가 여럿이다
        ks = (kind,) if isinstance(kind, str) else tuple(kind)
        q += ' AND v.rel_code IN (%s)' % ','.join('?' * len(ks))
        p += list(ks)
    if key_only:
        q += ' AND v.is_key=1'
    if lemma_id:
        # 낱말별로 가른다. 안 가르면 창 1:4(토브)와 마 5:45(아가토스)가 한 목록에 나란히
        # 놓여 **같은 말처럼 보인다** — 그것이 오해의 출처였다(entity.md ②).
        q += ' AND v.lemma_id=?'
        p.append(lemma_id)
    q += ' ORDER BY v.is_key DESC, v.%s' % EV_B
    if limit:
        q += ' LIMIT %d' % int(limit)
    try:
        return conn.execute(q, p).fetchall()
    except Exception:
        return []


def fetch_lemma_rows(conn, entity_id):
    """[(lemma_id, lang_code, strong, translit, gloss, 절수)] — 낱말별 버튼용.

    ★ 2026-08-10 신설. `fetch_lemmas` 는 lemma_id 를 안 주는데, **낱말마다 절을 갈라
      보이려면 그 번호가 있어야 한다**. 기존 호출부(db_lex_map 등)가 4-튜플을 풀고 있어
      그쪽을 건드리지 않고 따로 뺐다.
    """
    try:
        return conn.execute(
            'SELECT l.lemma_id, l.lang_code, l.strong, l.translit, l.gloss,'
            # ★ 2026-08-24 통합 표(`ENTI_VERS`) — lemma_id 는 곁다리 칸 그대로다
            '  (SELECT COUNT(*) FROM %s v WHERE v.%s AND v.lemma_id=l.lemma_id'
            "     AND COALESCE(v.record_status,'LIVE')='LIVE')" % (EV_TABLE, EV_WHERE) +
            ' FROM sys_entity_lemma l'
            " WHERE l.entity_id=? AND COALESCE(l.record_status,'LIVE')='LIVE'"
            ' ORDER BY l.sort_order, l.lemma_id', (entity_id,)).fetchall()
    except Exception:
        return []


def fetch_lemma_note(conn, lemma_id, lang='KO'):
    """그 원어 낱말의 설명문. `gloss` 는 한 줄이라 긴 주의는 여기 쓴다.

    ⚠ 번역어 주의(영어 good 같은 것)는 **언어마다 다른 원고**다. 옮기지 않는다(entity.md).
    """
    try:
        r = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE clicked_id=?"
            " AND text_type='ENTITY_LEMMA_DESC' AND lang_code=?"
            " AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1", (lemma_id, lang)).fetchone()
        return r[0] if r else ''
    except Exception:
        return ''


def fetch_lemmas(conn, entity_id):
    """[(lang_code, strong, translit, gloss)]. 표가 없으면 빈 리스트."""
    try:
        return conn.execute(
            'SELECT lang_code,strong,translit,gloss FROM sys_entity_lemma'
            " WHERE entity_id=? AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY sort_order",
            (entity_id,)).fetchall()
    except Exception:
        return []


def _ref(conn, vid):
    r = conn.execute('SELECT bcode,chapter,verse FROM bible_index WHERE verse_id=?', (vid,)).fetchone()
    if not r:
        return str(vid)
    nm = conn.execute("SELECT short_name FROM book_names WHERE book_code=? AND lang_code='KO' LIMIT 1",
                      (r[0],)).fetchone()
    return '%s %d:%d' % (nm[0] if nm else r[0], r[1], r[2])


def show(conn, code):
    r = conn.execute('SELECT entity_id FROM sys_entity_master WHERE entity_code=?', (code,)).fetchone()
    if not r:
        print('없는 코드: %s' % code)
        return
    eid = r[0]
    nm = conn.execute("SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type='ENTITY_NAME'"
                      " AND lang_code='KO' LIMIT 1", (eid,)).fetchone()
    print('%s  %s' % (code, nm[0] if nm else ''))
    for lang, strong, tr, gl in fetch_lemmas(conn, eid):
        print('  앵커 %s %-7s %s (%s)' % (lang, strong, tr or '', gl or ''))
    lex = fetch_verses(conn, eid, 'LEXICAL')
    them = fetch_verses(conn, eid, 'THEMATIC')
    print('  낱말이 있는 절 %d개 (대표 %d)' % (len(lex), sum(1 for x in lex if x[2])))
    print('    ' + ' '.join(_ref(conn, v) for v, k, ky, d, _e in lex if ky)[:300])
    print('  낱말이 없는 절 %d개' % len(them))
    for v, k, ky, d, _e in them[:5]:
        _rg = ('~%s' % _ref(conn, _e)) if _e and _e != v else ''
        print('    %s%s — %s' % (_ref(conn, v), _rg, (d or '')[:80]))


def listing(conn):
    q = ("SELECT e.entity_id, e.entity_code,"
         "  (SELECT contents FROM sys_text_asset WHERE clicked_id=e.entity_id"
         "     AND text_type='ENTITY_NAME' AND lang_code='KO' LIMIT 1)"
         " FROM sys_entity_master e WHERE e.entity_type=?"
         "   AND COALESCE(e.record_status,'LIVE')='LIVE' ORDER BY e.entity_code")
    rows = conn.execute(q, (ETYPE,)).fetchall()
    print('주요용어 %d개' % len(rows))
    for eid, code, nm in rows:
        lm = fetch_lemmas(conn, eid)
        lex = len(fetch_verses(conn, eid, 'LEXICAL'))
        them = len(fetch_verses(conn, eid, 'THEMATIC'))
        print('  %-14s %-18s 앵커 %-24s 있음 %4d · 없음 %3d'
              % (code, nm or '', ' '.join(x[1] for x in lm) or '—', lex, them))


# ── 자가 검증 ───────────────────────────────────────────────────────────────
def selftest():
    """**탐지력**을 확인한다 — 통과만 시키는 껍데기가 되지 않게 양방향으로 본다."""
    ok = True

    def chk(label, got, want=True):
        nonlocal ok
        good = bool(got) == bool(want)
        ok &= good
        print('  [%s] %s' % ('PASS' if good else 'FAIL', label))

    good = {'terms': [{'code': 'T_X', 'KO': '이름', 'EN': 'Name',
                       'desc_KO': '설명', 'desc_EN': 'desc',
                       'lemmas': [{'lang': 'HE', 'strong': 'H2617', 'translit': '헤세드'}]}]}
    chk('정상 초안을 통과시킨다', not check(good))

    def one(mut):
        import copy
        d = copy.deepcopy(good)
        mut(d['terms'][0])
        return check(d)

    def one_c(conn, mut):
        import copy
        d = copy.deepcopy(good)
        mut(d['terms'][0])
        return check(d, conn)

    # ① 코드 규약 — 소문자·접두어 누락을 잡아야 한다
    chk('코드 규약 위반을 잡는다', one(lambda t: t.update(code='hesed')))
    chk('접두어 없는 코드를 잡는다', one(lambda t: t.update(code='HESED')))
    # ② 이름·설명 결손 — 한 언어만 있는 것을 잡아야 한다
    chk('EN 이름 누락을 잡는다', one(lambda t: t.update(EN='')))
    chk('KO 설명 누락을 잡는다', one(lambda t: t.update(desc_KO='  ')))
    # ③ Strong 형식 — 이것이 죽으면 LEXICAL 이 통째로 0건이 된다
    chk('Strong 형식 오류를 잡는다', one(lambda t: t.update(lemmas=[{'lang': 'HE', 'strong': '2617'}])))
    chk('앵커 중복을 잡는다', one(lambda t: t.update(
        lemmas=[{'lang': 'HE', 'strong': 'H2617'}, {'lang': 'HE', 'strong': 'H2617'}])))
    # ④ lang 과 Strong 이 어긋나는 것 — HE 인데 G 번호를 단 실수. 조용히 0건이 된다
    chk('lang 과 Strong 불일치를 잡는다', one(lambda t: t.update(
        lemmas=[{'lang': 'HE', 'strong': 'G1656'}])))
    chk('모르는 lang 을 잡는다', one(lambda t: t.update(lemmas=[{'lang': 'GR', 'strong': 'G1656'}])))
    # ⑤ THEMATIC 은 설명문이 의무다 — 없으면 왜 이었는지 아무도 모른다
    chk('설명 없는 THEMATIC 을 잡는다', one(lambda t: t.update(thematic=[{'ref': [8, 2, 20]}])))
    # ⑤-b 기존 항목(교리)에 앵커만 붙이는 배치 — 이름·설명 없이도 통과해야 한다.
    #     막으면 「한 주제에 항목은 하나」 원칙을 지킬 수 없다(entity.md §1).
    try:
        _c2 = appdb.connect()
        _ex = _c2.execute("SELECT entity_code FROM sys_entity_master"
                          " WHERE entity_type='DOCTRINE' LIMIT 1").fetchone()
        if _ex:
            _d = {'terms': [{'code': _ex[0],
                             'lemmas': [{'lang': 'HE', 'strong': 'H1285'}]}]}
            chk('기존 교리에 앵커만 붙이는 배치를 통과시킨다 (%s)' % _ex[0],
                not check(_d, _c2))
            _d2 = {'terms': [{'code': 'HESED', 'KO': 'x', 'EN': 'x',
                              'desc_KO': 'x', 'desc_EN': 'x'}]}
            chk('새 용어 코드는 여전히 T_ 를 요구한다', check(_d2, _c2))
        _c2.close()
    except Exception as _e:
        print('  [SKIP] DB 없음 — 기존 항목 배치 검사 못 함 (%s)' % _e)

    # ⑥ 앵커가 0개인 항목은 정상이다 (삼위일체) — 이것을 막으면 설계가 무너진다
    chk('앵커 0개를 통과시킨다', not one(lambda t: t.update(lemmas=[])))
    # ⑥-0 ★ 두 앵커 규칙 (2026-09-15 항목 ③) — 양방향
    _two = [{'lang': 'HE', 'strong': 'H3519', 'translit': '카보드'},
            {'lang': 'EL', 'strong': 'G1391', 'translit': '독사'}]
    chk('두 앵커인데 첫 문단에 한 음역만 → 잡는다', any('음역이 빠졌다' in m for m in one(
        lambda t: t.update(lemmas=_two, desc_KO='카보드의 뿌리는 무겁다.' + chr(10) + '신약은 독사로 받았다.'))))
    chk('두 앵커 · 첫 문단에 둘 다 → 통과', not one(
        lambda t: t.update(lemmas=_two, desc_KO='카보드와 독사는 뿌리가 다릅니다.' + chr(10) + '둘째 문단.')))
    chk('앵커 하나면 규칙 대상이 아니다', not one(
        lambda t: t.update(desc_KO='첫 문단에 음역이 없어도 됩니다.')))
    chk('anchor_mentions — 빠진 것만 돌려준다', anchor_mentions('카보드 이야기', ['카보드', '독사']) == ['독사'])
    chk('anchor_mentions — 둘째 문단의 언급은 안 쳐준다',
        anchor_mentions('카보드 이야기' + chr(10) + '독사 이야기', ['카보드', '독사']) == ['독사'])
    # ⑥-b 낱말이 **있는** 절을 THEMATIC 으로 넣는 것 — 두 종류를 가르는 정의다.
    #     conn 을 줬을 때만 잡을 수 있다. 시범 적재에서 실제로 두 건 나왔다.
    try:
        _c = appdb.connect()
        chk('낱말 있는 절을 THEMATIC 으로 넣는 것을 잡는다',
            any('앵커 낱말이' in m for m in one_c(_c, lambda t: t.update(
                thematic=[{'ref': [8, 2, 20], 'KO': '설명'}]))))
        chk('낱말 없는 절은 THEMATIC 으로 통과시킨다',
            not one_c(_c, lambda t: t.update(thematic=[{'ref': [8, 1, 16], 'KO': '설명'}])))
        _c.close()
    except Exception as _e:
        print('  [SKIP] DB 없음 — THEMATIC 정의 검사 못 함 (%s)' % _e)

    # ⑥-c ★ 중복등록 차단 (2026-08-26) — 단락으로 이미 이어 둔 구간 안의 절.
    #     연결구절 탭이 단락 행과 절 행을 **한 목록**에 놓으므로 같은 대목이 두 번 뜬다.
    #     ⚠ 좌표를 코드에 박지 않는다 — 실제로 단락 연결을 가진 엔티티를 런타임에 고른다
    #        (§0-5 「검사를 데이터 상태에 걸지 말 것」).
    try:
        _c3 = appdb.connect()
        _row = _c3.execute(
            "SELECT em.entity_code, pa.start_vid, pa.end_vid "
            "FROM sys_link_asset ep "
            "JOIN sys_entity_master em ON em.entity_id=ep.clicked_id "
            "JOIN sys_pericope_asset pa ON pa.pericope_id=ep.target_id "
            "JOIN bible_index bi ON bi.verse_id=pa.start_vid "
            "WHERE ep.link_type='ENTI_PERI' "
            "  AND COALESCE(ep.record_status,'LIVE')='LIVE' "
            "  AND pa.record_status='LIVE' AND pa.peri_type='BODY' "
            "  AND pa.end_vid > pa.start_vid LIMIT 1").fetchone()
        if _row:
            _code, _sv, _ev2 = _row
            _in = _c3.execute('SELECT bcode, chapter, verse FROM bible_index'
                              ' WHERE verse_id=?', (_sv,)).fetchone()
            # 그 엔티티가 단락으로 덮지 않은 절 하나 — 대조군
            _out = _c3.execute('SELECT bcode, chapter, verse FROM bible_index'
                               ' WHERE verse_id=?', (_ev2 + 5000,)).fetchone()
            _mk = lambda ref: {'terms': [{'code': _code, 'thematic': [
                {'ref': list(ref), 'KO': '설명'}]}]}
            chk('단락 구간 안의 절을 THEMATIC 으로 넣는 것을 잡는다 (%s)' % _code,
                any('단락으로 이어 둔' in m for m in check(_mk(_in), _c3)))
            if _out:
                chk('단락 밖의 절은 그대로 통과시킨다',
                    not any('단락으로 이어 둔' in m for m in check(_mk(_out), _c3)))
            # 반대 방향 조회도 실제로 동작해야 한다(관리자 화면이 이것을 쓴다)
            _eid = _c3.execute('SELECT entity_id FROM sys_entity_master'
                               ' WHERE entity_code=?', (_code,)).fetchone()[0]
            chk('단락 구간 목록을 실제로 읽는다', len(linked_peri_spans(_c3, _eid)) > 0)
            chk('엔티티 번호가 없으면 빈 목록', linked_peri_spans(_c3, None) == [])
            chk('반대 방향 조회가 터지지 않는다',
                isinstance(thematic_vids_in_span(_c3, _eid, _sv, _ev2), list))
        else:
            print('  [SKIP] 단락 연결이 있는 엔티티가 없어 중복 게이트 검사 못 함')
        _c3.close()
    except Exception as _e:
        print('  [SKIP] DB 없음 — 중복 게이트 검사 못 함 (%s)' % _e)

    # ⑦ 원어 조회 — 검증 DB 가 있으면 실제로 절을 찾아야 한다.
    #    「0건」과 「DB 없음」을 구별하지 못하면 조용히 빈 용어가 만들어진다.
    if os.path.exists(VERIFY_DB['HE']):
        v = strong_verses('H2617')
        chk('H2617 을 찾는다 (241절 안팎)', v is not None and 200 < len(v) < 300)
        chk('없는 번호는 빈 목록', strong_verses('H99999') == [])
    else:
        print('  [SKIP] wlc_verify.db 없음 — 원어 조회 검사 못 함')
    chk('검증 DB 없는 언어는 None 을 준다 (0건과 구별)',
        strong_verses('G1656') is None or os.path.exists(VERIFY_DB['EL']))

    # ⑧ 표가 없어도 화면이 죽지 않아야 한다 (적재 전에도 앱이 뜬다)
    mem = sqlite3.connect(':memory:')
    chk('표 없을 때 fetch_verses 빈 리스트', fetch_verses(mem, 1) == [])
    chk('표 없을 때 fetch_lemmas 빈 리스트', fetch_lemmas(mem, 1) == [])

    print('selftest', 'PASS' if ok else 'FAIL')
    return ok


if __name__ == '__main__':
    a = sys.argv
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect()
    if '--init' in a:
        init(conn)
    if '--load' in a:
        load(conn, a[a.index('--load') + 1])
    if '--relink' in a:
        i = a.index('--relink')
        relink(conn, [x for x in a[i + 1:] if not x.startswith('--')] or None)
    if '--show' in a:
        show(conn, a[a.index('--show') + 1])
    if '--anchor-audit' in a:
        # ★ 두 앵커 규칙 전수 (2026-09-15) — 첫 문단에 음역이 빠진 용어
        bad = audit_anchor_mentions(conn)
        for eid, code, name, miss in bad:
            print('  %4d %-14s %-22s 빠짐: %s' % (eid, code, name, ' · '.join(miss)))
        print('두 앵커 규칙 위반 %d개' % len(bad))
    if '--list' in a:
        listing(conn)
