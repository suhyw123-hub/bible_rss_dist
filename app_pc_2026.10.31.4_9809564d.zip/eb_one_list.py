# -*- coding: utf-8 -*-
"""eb_one_list.py — 주요용어(P4) 「더보기」를 **한 목록**으로 (2026-09-17 신설·영구).

사용자 확정 — 「주요용어 통합 : **필수=용어사전+용례구절, 선택=나머지,
여정=삭제**」 · 「P2 에서와 마찬가지로 더보기/통합 탭 방식을 적용」.

★★★ **P2 와 같은 갈림이 여기서도 성립한다.**
    합친다  영상링크 · 텍스트링크 · 연구자료 · 내부연결 · 찬양 — 전부 **줄 목록**
    못 합친다 용어사전(읽는 글) · 용례구절(본문을 나란히 놓는 자리)
  ⇒ 그 둘을 **필수**로 못 박았으므로 더보기에 오는 것은 언제나 줄 목록뿐이다.

★ **재료를 다시 조회하지 않는다** — 서브탭이 **이미 채워 둔 것**을 읽는다
  (영상·텍스트는 그 트리의 줄 · 연구자료·내부연결은 `_study_rows` · 찬양만
  개수를 묻는다). 조회를 새로 쓰면 **목록과 탭 배지가 갈린다**(§「배지는 3인데
  목록은 2」). 그래서 이 함수는 db 가 아니라 **화면(panel)** 을 받는다.

⚠ 누르면 **원래 서브탭이 하던 일**을 그대로 한다 — 여기서 새 동작을 만들지 않는다.
"""

import sys

import i18n

#: 합칠 수 있는 갈래 다섯 — (열쇠, i18n 열쇠, 한국어). **이 표가 단일 소스다.**
#: ⚠ 열쇠는 `p2_tab_settings.SCREENS['EB_MAIN_TABS']` 와 **같은 글자**라야 한다.
KINDS = (
    ('VIDEO', 'EB_BR_VIDEO', '영상링크'),
    ('TEXT',  'EB_BR_TEXT',  '텍스트링크'),
    ('STUDY', 'TAB_RESEARCH', '연구자료'),
    ('NAV',   'REFR_SCOPE_NAV', '내부연결'),
    ('SONG',  'TAB_SONG',   '찬양'),
)
ORDER = tuple(k for k, _i, _ko in KINDS)

#: 목록 상한 — 실측 용어 41 은 영상만 2,360편이다. **개수는 안 줄이고**
#: 목록만 끊되 마지막 줄이 그 사실을 적는다(§0-1 「잘렸으면 그렇게 적는다」).
CAP = 300


def kind_label(key):
    for k, ik, ko in KINDS:
        if k == key:
            try:
                return i18n.t(ik, ko)
            except Exception:
                return ko
    return key


def rows(panel, entity_id, keys=ORDER, lang='KO'):
    """[(갈래, 갈래이름, 제목, 정보, payload, 즐겨찾기)] — 차례는 `ORDER` 그대로.

    payload = (갈래, 번호, 주소, 유튜브id) — 누를 때 쓰는 재료다.
    ⚠ 한 갈래가 터져도 **나머지는 낸다** — 목록이 통째로 비면 고장으로 읽힌다.
    """
    out = []
    want = [k for k in ORDER if k in set(keys or ())]
    if not entity_id or not want:
        return out
    lang = (lang or 'KO').upper()

    # ── 영상링크 · 텍스트링크 — 그 트리에 **이미 그려진 줄**을 읽는다 ──────
    for key, tv_at, it_at in (('VIDEO', '_url_tv', '_url_items'),
                              ('TEXT', '_txt_tv', '_txt_items')):
        if key not in want:
            continue
        try:
            tv = getattr(panel, tv_at, None)
            items = getattr(panel, it_at, None) or {}
            if tv is None:
                continue
            for iid in tv.get_children(''):
                v = list(tv.item(iid, 'values'))
                # 표준 7칸 = pick · scope · lang · kind · title · channel · fav
                title = v[4] if len(v) > 4 else ''
                meta = v[3] if len(v) > 3 else ''
                fav = (v[6] if len(v) > 6 else '') == '♪'
                mid, url, yt = (items.get(iid) or (None, '', None))
                out.append((key, kind_label(key), title, meta,
                            (key, mid, url or '', yt), bool(fav)))
        except Exception as e:
            print('[eb_one_list] %s: %s' % (key, e))

    # ── 연구자료 · 내부연결 — 화면이 이미 모아 둔 `_study_rows` ────────────
    if 'STUDY' in want or 'NAV' in want:
        try:
            src = getattr(panel, '_study_rows', None) or {}
            for key, code in (('STUDY', getattr(panel, 'ST_MINE', 'MINE')),
                              ('NAV', getattr(panel, 'ST_NAV', 'NAV'))):
                if key not in want:
                    continue
                for r in (src.get(code) or []):
                    n = r.get('n')
                    meta = ('%s %s' % (i18n.t('REFR_LINKED_VERSES', '연결 구절'),
                                       n)) if n else ''
                    out.append((key, kind_label(key), r.get('label') or '',
                                meta, (key, r.get('iid'), '', None), False))
        except Exception as e:
            print('[eb_one_list] STUDY/NAV: %s' % e)

    # ── 찬양 — 곡 목록(세 층은 제 탭이 편다) ──────────────────────────────
    if 'SONG' in want:
        try:
            import appdb
            import db_song as S
            c = appdb.connect(getattr(panel, 'db_path', None))
            for sid, nm, n_r, n_m in (S.songs_of_entity(c, int(entity_id),
                                                        lang) or []):
                out.append(('SONG', kind_label('SONG'), nm or ('#%d' % sid),
                            i18n.t('SP_META_SONG', '판 %d · 영상 %d') % (n_r, n_m),
                            ('SONG', sid, '', None), False))
            c.close()
        except Exception as e:
            print('[eb_one_list] SONG: %s' % e)

    rank = {k: i for i, k in enumerate(ORDER)}
    out.sort(key=lambda x: (rank.get(x[0], 99), (x[2] or '')))
    if len(out) > CAP:
        rest = len(out) - CAP
        out = out[:CAP]
        # ⚠ payload 가 `None` 이라 눌러도 아무 데도 안 간다(안내 줄이다)
        out.append(('', '', i18n.t('EBO_MORE_CUT',
                                   '… 여기까지 %d줄. 나머지 %d줄은 그 갈래 탭에서 봅니다')
                    % (CAP, rest), '', None, False))
    return out


# ── 자가검증 ─────────────────────────────────────────────────────────
def selftest():
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8',
                                  errors='replace', line_buffering=True)
    n = [0, 0]

    def t(name, ok, got=''):
        n[1] += 1
        if ok:
            n[0] += 1
        print(('  OK  ' if ok else '  실패 ') + name + ('' if ok else '  ' + str(got)))

    t('① 합칠 수 있는 갈래 다섯',
      ORDER == ('VIDEO', 'TEXT', 'STUDY', 'NAV', 'SONG'), ORDER)
    t('★ 필수 둘은 안 들어간다 — 읽는 글·본문 자리다',
      not ({'DICT', 'LINK'} & set(ORDER)))
    t('★ 여정은 없다(삭제)', 'JOURNEY' not in ORDER)
    t('① 이름을 화면이 안 적는다', all(ik for _k, ik, _ko in KINDS))

    import p2_tab_settings as TS
    eb = next(o for k, o, _d, _i, _l in TS.SCREENS if k == 'EB_MAIN_TABS')
    t('★★ 설정 화면의 선택 갈래와 **글자가 같다**',
      tuple(k for k in eb if k not in TS.fixed_of('EB_MAIN_TABS')) == ORDER,
      (eb, ORDER))
    t('★★ 감출 수 있는 것과도 같다',
      TS.hideable_of('EB_MAIN_TABS') == ORDER)

    class _Dummy:
        db_path = None
    t('② 용어가 없으면 빈 목록', rows(_Dummy(), 0) == [])
    t('② 선택한 갈래가 없으면 빈 목록', rows(_Dummy(), 1, ()) == [])

    class _P:
        db_path = 'bible_master.db'
        ST_MINE, ST_NAV = 'MINE', 'NAV'
        _study_rows = {'MINE': [{'iid': 'R7', 'label': '내 글', 'n': 3}],
                       'NAV': [{'iid': 'B9', 'label': '설교 한 편', 'n': 0}]}
    rs = rows(_P(), 1, ('STUDY', 'NAV'))
    t('③ 화면이 모아 둔 것을 그대로 낸다', len(rs) == 2, rs)
    t('③ 갈래 이름이 줄마다 붙는다',
      rs[0][1] == kind_label('STUDY') and rs[1][1] == kind_label('NAV'))
    t('③ payload 가 그 줄의 번호를 들고 있다',
      rs[0][4][1] == 'R7' and rs[1][4][1] == 'B9')
    t('③ 0건이면 「연결 구절」을 안 적는다', rs[1][3] == '', rs[1][3])

    class _Big:
        db_path = 'bible_master.db'
        ST_MINE, ST_NAV = 'MINE', 'NAV'
        _study_rows = {'MINE': [{'iid': 'R%d' % i, 'label': 'x%d' % i, 'n': 1}
                                for i in range(CAP + 50)], 'NAV': []}
    big = rows(_Big(), 1, ('STUDY',))
    t('★★ 상한에서 끊는다', len(big) == CAP + 1, len(big))
    t('★★ **끊었다고 적는다**(조용히 안 자른다)',
      str(big[-1][2]).startswith('…') and '50' in str(big[-1][2]), big[-1][2])
    t('★ 그 줄은 눌러도 아무 데도 안 간다', big[-1][4] is None)

    print('eb_one_list: %d/%d' % (n[0], n[1]))
    return 0 if n[0] == n[1] else 1


if __name__ == '__main__':
    sys.exit(selftest())
