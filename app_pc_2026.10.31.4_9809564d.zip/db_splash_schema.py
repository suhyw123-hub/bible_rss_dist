# -*- coding: utf-8 -*-
"""db_splash_schema.py — 시작화면(스플래시) 배경 사진 저장 테이블 생성. 멱등 안전.

- sys_splash_image  (bible_master.db) : 관리자 큐레이션 사진. 콘텐츠와 함께 배포.
- user_splash_image (user_data.db/userdb): 사용자 본인 사진. 로컬 전용(절대 미배포).

사진은 스플래시 규격으로 미리 다운스케일된 PNG 바이트(BLOB)로 저장.
런타임 스플래시는 DB에서 BLOB을 뽑아 splash/bg.png 캐시로 써두고(앱이 처리),
스플래시 자체는 그 작은 PNG 파일만 읽는다(PIL 불필요·DB 불필요·~0.6s).

실행: python db_splash_schema.py
"""
import appdb
from datetime import datetime


def main():
    conn = appdb.connect()
    c = conn.cursor()
    # 관리자 사진(배포) — bible_master.db
    c.execute("""
        CREATE TABLE IF NOT EXISTS sys_splash_image (
            img_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            png_blob    BLOB NOT NULL,
            name        TEXT,            -- 사진 제목(영어 단일, 다국어 아님)
            width       INTEGER,
            height      INTEGER,
            attribution TEXT,            -- 출처/촬영자 (남의 사진일 때 권리 증빙)
            license     TEXT,            -- PD / CC / 본인 등
            is_active   INTEGER NOT NULL DEFAULT 1,
            sort_order  INTEGER NOT NULL DEFAULT 0,
            created_at  TEXT
        )
    """)
    # ★★★ **스타일 — 유형 하나가 팩 하나**(2026-09-05 사용자 지시
    #   「이미지를 여러 **스타일에 따라 유형을 분류**할 생각이다」 ·
    #   「선호하는 사용자를 위해서 **별도 팩**으로 관리」).
    #   ⚠ **비어 있으면 기본**이다 — 기본은 **코어에 남는다**(안 그러면 팩을
    #     안 받은 사용자에게 시작 화면 사진이 하나도 없다).
    #   ⚠ 멱등 — 이미 있으면 넘어간다.
    try:
        cols = [r[1] for r in c.execute("PRAGMA table_info(sys_splash_image)")]
        if 'style' not in cols:
            c.execute("ALTER TABLE sys_splash_image ADD COLUMN style TEXT")
    except Exception:
        pass
    c.execute("CREATE INDEX IF NOT EXISTS idx_sys_splash_active ON sys_splash_image(is_active)")

    # 사용자 본인 사진(로컬 전용) — user_data.db (userdb.)
    c.execute("""
        CREATE TABLE IF NOT EXISTS userdb.user_splash_image (
            img_id     INTEGER PRIMARY KEY AUTOINCREMENT,
            png_blob   BLOB NOT NULL,
            name       TEXT,             -- 사진 제목(사용자 입력)
            width      INTEGER,
            height     INTEGER,
            label      TEXT,             -- 사용자 메모(선택)
            is_active  INTEGER NOT NULL DEFAULT 1,
            created_at TEXT
        )
    """)
    c.execute("CREATE INDEX IF NOT EXISTS userdb.idx_user_splash_active ON user_splash_image(is_active)")

    # 사용자가 '가린' 관리자 사진(특정 사진 단위 — 전체 아님). 로컬 전용.
    c.execute("""
        CREATE TABLE IF NOT EXISTS userdb.user_splash_hidden (
            sys_img_id INTEGER PRIMARY KEY,
            hidden_at  TEXT
        )
    """)

    # 멱등 마이그레이션: 기존 테이블에 name 컬럼 없으면 추가
    def _ensure_col(qualified, col, decl):
        if '.' in qualified:
            sch, tbl = qualified.split('.', 1)
            info = c.execute(f"PRAGMA {sch}.table_info({tbl})").fetchall()
        else:
            info = c.execute(f"PRAGMA table_info({qualified})").fetchall()
        if col not in [r[1] for r in info]:
            c.execute(f"ALTER TABLE {qualified} ADD COLUMN {col} {decl}")
    _ensure_col('sys_splash_image', 'name', 'TEXT')
    _ensure_col('userdb.user_splash_image', 'name', 'TEXT')

    conn.commit()
    # 확인
    n_sys = c.execute("SELECT COUNT(*) FROM sys_splash_image").fetchone()[0]
    n_usr = c.execute("SELECT COUNT(*) FROM userdb.user_splash_image").fetchone()[0]
    conn.close()
    print(f"[{datetime.now():%Y-%m-%d %H:%M}] splash schema OK : sys_splash_image={n_sys}, user_splash_image={n_usr}")


if __name__ == '__main__':
    main()
