# -*- coding: utf-8 -*-
"""참고자료(RSS 기사) 제목·요약에서 엔티티/페리코프 연결 후보를 탐지.
   자동 확정이 아니라 '후보 제시' 용도 — 관리자가 검토 탭에서 채택/거부한다.
   ENTITY_NAME(+별명) 매칭 + 성경 구절 참조 파싱(book_names 기반, 다국어).
"""
import re
import json
# ★★ 구간 판정은 **한 문**이다(§verse_range) — 차례는 `sort_order` 다.
import verse_range as _vr

# CJK 계열은 단어 경계가 없어 부분일치 허용, 라틴 계열은 단어 경계 요구
_CJK_LANGS = {'KO', 'ZH', 'ZHT', 'JA'}
_VERSE_SEP = r'[:：·장章절节]'  # : ： · 장 章 절 節


def _entity_names(conn, lang):
    """[(entity_id, name)] — ENTITY_NAME(lang, EN 폴백) + json_detail.aliases[lang]."""
    rows = conn.execute(
        "SELECT clicked_id, contents FROM sys_text_asset "
        "WHERE text_type='ENTITY_NAME' AND lang_code=? AND record_status='LIVE'",
        (lang,)).fetchall()
    seen_eid = {eid for eid, _ in rows}
    out = [(eid, (nm or '').strip()) for eid, nm in rows if (nm or '').strip()]
    if lang != 'EN':  # 해당 언어 이름 없는 엔티티는 EN 폴백
        for eid, nm in conn.execute(
                "SELECT clicked_id, contents FROM sys_text_asset "
                "WHERE text_type='ENTITY_NAME' AND lang_code='EN' AND record_status='LIVE'"):
            if eid not in seen_eid and (nm or '').strip():
                out.append((eid, nm.strip()))
    # 별명
    for eid, jd in conn.execute(
            "SELECT entity_id, json_detail FROM sys_entity_master "
            "WHERE record_status='LIVE' AND json_detail IS NOT NULL"):
        try:
            al = json.loads(jd).get('aliases', {})
        except Exception:
            continue
        for a in (al.get(lang) or []):
            if isinstance(a, str) and a.strip():
                out.append((eid, a.strip()))
    return out


def detect_entities(conn, lang, text, limit=20):
    """본문에서 엔티티명을 찾아 [(entity_id, name, matched)] 반환 (긴 이름 우선)."""
    if not text:
        return []
    low = text.lower()
    cjk = lang in _CJK_LANGS
    hits = {}  # entity_id -> (name, matched_len)
    for eid, name in _entity_names(conn, lang):
        if len(name) < 2:
            continue
        nl = name.lower()
        if cjk:
            found = nl in low
        else:
            found = re.search(r'\b' + re.escape(nl) + r'\b', low) is not None
        if found:
            prev = hits.get(eid)
            if not prev or len(name) > prev[1]:
                hits[eid] = (name, len(name))
    out = [(eid, nm, nm) for eid, (nm, _) in hits.items()]
    out.sort(key=lambda t: -len(t[1]))
    return out[:limit]


# 정밀 필터용 — 구체 엔티티만 관련성 신호로 인정(교리/추상은 거의 모든 글에 등장 → 노이즈)
_CONCRETE_TYPES = ('PERSON', 'PLACE', 'NATION', 'GROUP', 'IDOL', 'OBJECT', 'FEAST', 'SYSTEM')


def is_relevant(conn, lang, text):
    """수집 정밀 필터 — 성경 참조(페리코프) 또는 구체 엔티티가 있으면 관련.
       교리(DOCTRINE: 믿음·은혜·사랑 등)만 언급된 글은 제외(노이즈).
       반환 (relevant_bool, 페리코프수, 구체엔티티수)."""
    peris = detect_pericopes(conn, lang, text, limit=5)
    if peris:
        return True, len(peris), 0          # 명시적 성경 참조 = 강한 신호
    ents = detect_entities(conn, lang, text, limit=15)
    if not ents:
        return False, 0, 0
    eids = [e[0] for e in ents]
    eph = ','.join('?' * len(eids))
    tph = ','.join('?' * len(_CONCRETE_TYPES))
    try:
        n = conn.execute(
            f"SELECT COUNT(*) FROM sys_entity_master "
            f"WHERE entity_id IN ({eph}) AND entity_type IN ({tph})",
            eids + list(_CONCRETE_TYPES)).fetchone()[0]
    except Exception:
        n = 0
    return n > 0, 0, n


def _book_map(conn, lang):
    """{이름(소문자): bcode} — full_name + short_name (길이순 정렬용 리스트도)."""
    m = {}
    for bc, full, short in conn.execute(
            "SELECT book_code, full_name, short_name FROM book_names WHERE lang_code=?", (lang,)):
        for nm in (full, short):
            if nm and nm.strip():
                m[nm.strip().lower()] = bc
    return m


def detect_pericopes(conn, lang, text, limit=20):
    """본문의 성경 참조를 파싱 → 포함 BODY 페리코프 [(pericope_id, label, matched)] 반환."""
    if not text:
        return []
    bmap = _book_map(conn, lang)
    if not bmap:
        return []
    # 긴 이름 우선 (요한복음 > 요한 > 요) 매칭
    names = sorted(bmap.keys(), key=len, reverse=True)
    alt = '|'.join(re.escape(n) for n in names)
    pat = re.compile(r'(' + alt + r')\s*(\d{1,3})\s*(?:' + _VERSE_SEP + r'\s*(\d{1,3}))?',
                     re.IGNORECASE)
    found = {}  # pericope_id -> (label, matched_ref)
    for mt in pat.finditer(text):
        bk, ch, vs = mt.group(1), mt.group(2), mt.group(3)
        bcode = bmap.get(bk.strip().lower())
        if not bcode:
            continue
        ch = int(ch); vs = int(vs) if vs else 1
        vid_row = conn.execute(
            "SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?",
            (bcode, ch, vs)).fetchone()
        if not vid_row:
            continue
        vid = vid_row[0]
        for (pid,) in conn.execute(
                "SELECT pericope_id FROM sys_pericope_asset p "
                "WHERE p.peri_type='BODY' AND p.record_status='LIVE' AND "
                + _vr.covers_sql('p', 'start_vid', 'end_vid'),
                _vr.covers_args(vid)):
            if pid not in found:
                found[pid] = (_pericope_label(conn, pid, lang), mt.group(0).strip())
        if len(found) >= limit:
            break
    return [(pid, lbl, mr) for pid, (lbl, mr) in found.items()][:limit]


_RANGE_DASH = r'[-–—~〜]'


def detect_verse_ranges(conn, lang, text, limit=20):
    """본문의 성경 참조를 **범위 그대로** 파싱 → [(start_vid, end_vid, label, matched)].

    `detect_pericopes` 와 무엇이 다른가 — 저쪽은 절 번호를 풀어 놓고도 그 절을 버리고
    **감싸는 페리코프**만 남긴다(2026-08-03 실측). 그래서 「마 5:3~12」 설교가
    산상수훈 페리코프 하나로 뭉개지고, 「마 5~7장」처럼 페리코프를 여럿 걸치는
    설교는 범위를 표현할 방법이 아예 없었다. 이 함수는 범위를 그대로 지킨다.

    받아들이는 꼴 (10개 언어 book_names 기반이라 언어를 가리지 않는다):
        마 5:3-12 · 마태복음 5장 3~12절 · Matthew 5:3–12   → 절 범위
        마 5:3    · Matthew 5:3                            → 한 절
        마 5      · Matthew 5                              → 그 장 전체
        마 5-7    · Matthew 5-7                            → 여러 장
    """
    if not text:
        return []
    bmap = _book_map(conn, lang)
    if not bmap:
        return []
    names = sorted(bmap.keys(), key=len, reverse=True)
    alt = '|'.join(re.escape(n) for n in names)
    # 책 · 장 [ (구분자) 절 [ ~ 절 ] | ~ 장 ]
    pat = re.compile(
        r'(' + alt + r')\s*(\d{1,3})\s*'
        r'(?:' + _VERSE_SEP + r'\s*(\d{1,3})\s*(?:' + _RANGE_DASH + r'\s*(\d{1,3}))?'
        r'|' + _RANGE_DASH + r'\s*(\d{1,3})\s*(?:장|章)?)?',
        re.IGNORECASE)

    def _vid(bcode, ch, vs):
        r = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?",
                         (bcode, ch, vs)).fetchone()
        return r[0] if r else None

    def _chap_bounds(bcode, ch):
        r = conn.execute("SELECT MIN(verse_id), MAX(verse_id) FROM bible_index "
                         "WHERE bcode=? AND chapter=?", (bcode, ch)).fetchone()
        return (r[0], r[1]) if r and r[0] else (None, None)

    out, seen = [], set()
    for mt in pat.finditer(text):
        bk, ch, v1, v2, ch2 = mt.group(1), mt.group(2), mt.group(3), mt.group(4), mt.group(5)
        bcode = bmap.get(bk.strip().lower())
        if not bcode:
            continue
        ch = int(ch)
        if v1:                                   # 절이 있다
            s = _vid(bcode, ch, int(v1))
            e = _vid(bcode, ch, int(v2)) if v2 else s
            if e is None:                        # 「5:3-99」처럼 끝 절이 없으면 장 끝까지
                _, e = _chap_bounds(bcode, ch)
        else:                                    # 장만 있다
            s, _ = _chap_bounds(bcode, ch)
            _, e = _chap_bounds(bcode, int(ch2)) if ch2 else _chap_bounds(bcode, ch)
        if s is None or e is None:
            continue
        if e < s:
            s, e = e, s                          # 거꾸로 적힌 참조도 받아 준다
        if (s, e) in seen:
            continue
        seen.add((s, e))
        out.append((s, e, verse_range_label(conn, s, e, lang), mt.group(0).strip()))
        if len(out) >= limit:
            break
    return out


def verse_range_label(conn, start_vid, end_vid, lang):
    """'마 5:3~12' / 'Matthew 5:3~12' — 사용자 언어 책 약명으로."""
    s = conn.execute("SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?",
                     (start_vid,)).fetchone()
    e = conn.execute("SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?",
                     (end_vid,)).fetchone()
    if not s:
        return f'#{start_vid}'
    nm = conn.execute(
        "SELECT short_name, full_name FROM book_names WHERE book_code=? AND lang_code IN (?, 'EN') "
        "ORDER BY CASE lang_code WHEN ? THEN 0 ELSE 1 END LIMIT 1",
        (s[0], lang, lang)).fetchone()
    book = (nm[0] or nm[1]) if nm else str(s[0])
    # 라틴문자 약명은 한 칸 띄우고 CJK 는 붙인다 (§3-1 _peri_ref_label 과 같은 규칙)
    gap = '' if book and ord(book[0]) > 0x2E00 else ' '
    head = f'{book}{gap}{s[1]}:{s[2]}'
    if not e or (s[0], s[1], s[2]) == (e[0], e[1], e[2]):
        return head
    tail = f'{e[2]}' if e[1] == s[1] else f'{e[1]}:{e[2]}'
    return f'{head}~{tail}'


def _pericope_label(conn, pid, lang):
    """PERI_TITLE(lang→EN) 우선, 없으면 'book ch:v–v' 범위."""
    for lg in (lang, 'EN'):
        r = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE text_type='PERI_TITLE' "
            "AND clicked_id=? AND lang_code=? AND record_status='LIVE' LIMIT 1",
            (pid, lg)).fetchone()
        if r and (r[0] or '').strip():
            title = r[0].strip()
            return f"{title}  ({_range_str(conn, pid, lang)})"
    return _range_str(conn, pid, lang)


def _range_str(conn, pid, lang):
    r = conn.execute("SELECT start_vid, end_vid FROM sys_pericope_asset WHERE pericope_id=?",
                     (pid,)).fetchone()
    if not r:
        return f"peri#{pid}"
    s = conn.execute("SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?", (r[0],)).fetchone()
    e = conn.execute("SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?", (r[1],)).fetchone()
    if not s:
        return f"peri#{pid}"
    bn = conn.execute("SELECT short_name FROM book_names WHERE lang_code=? AND book_code=?",
                      (lang, s[0])).fetchone()
    bn = bn[0] if bn else str(s[0])
    if e and (s[1] != e[1] or s[2] != e[2]):
        return f"{bn} {s[1]}:{s[2]}–{e[1]}:{e[2]}"
    return f"{bn} {s[1]}:{s[2]}"
