# -*- coding: utf-8 -*-
"""내가 모은 채널 — PC 쪽 (2026-10-24 docs/4.txt · 폰 my_channel_repo.dart 와 같은 규칙).

사용자가 밖에서 담은 영상의 **채널**을 모으고, 그 채널의 최신 영상을 유튜브 공개 RSS 로 하루 한 번 받는다.
· 채널 목록 `userdb.user_my_channel` — PC 가 정본 · 폰으로 사본(mobile_sync MIRROR) · 폰에서 담으면 MY_CHANNEL 사건.
· 최신 영상 `userdb.user_my_channel_video` — **이 PC 에만**(서버·폰으로 안 간다).
· 관리자에게 추천 = 소통 통로 kind CHANNEL(`mobile_sync.ch_reco_text` 와 같은 글).
⚠ 이상한 자료 막기 — 주소는 채널 번호로 우리가 짓는다 · 채널 번호는 UC+22자 · 영상 번호는 11자 꼴만 · 제목은 글자로만.
⚠ 실패해도 지난 목록을 지우지 않는다 · 하루 한 번만 묻는다.

`python my_channel.py --selftest` — 의무(망 없이 가짜 get 으로 잰다).
"""
import json
import re
from datetime import datetime, timedelta
from urllib.request import Request, urlopen

CH_RX = re.compile(r'^UC[A-Za-z0-9_-]{22}$')
VID_RX = re.compile(r'^[A-Za-z0-9_-]{11}$')

DDL = (
    "CREATE TABLE IF NOT EXISTS userdb.user_my_channel (channel_id TEXT PRIMARY KEY, channel_name TEXT,"
    " channel_url TEXT, created_at TEXT DEFAULT (datetime('now','localtime')))",
    "CREATE TABLE IF NOT EXISTS userdb.user_my_channel_video (vid TEXT PRIMARY KEY, channel_id TEXT,"
    " channel TEXT, title TEXT, published TEXT, fetched_at TEXT)",
    "CREATE TABLE IF NOT EXISTS userdb.user_my_channel_ok (channel_id TEXT PRIMARY KEY, ok_at TEXT, fail_at TEXT)",
    # ★ 2026-10-24 앱(관리자)이 받는 채널 번호 — rss_reader.sync_app_channels 가 날마다 갈아 끼운다
    "CREATE TABLE IF NOT EXISTS userdb.user_app_channel (channel_id TEXT PRIMARY KEY)",
)
DUE_HOURS = 24


# ★ 2026-10-24 docs/5.txt — 라이브러리 기본 머리글은 봇으로 막힌다 · 실제 브라우저처럼(말 · 받는 꼴)
HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                         'Chrome/130.0.0.0 Safari/537.36',
           'Accept-Language': 'ko-KR,ko;q=0.9,en;q=0.8',
           'Accept': 'application/atom+xml,application/xml;q=0.9,text/html;q=0.8,*/*;q=0.7'}
GAP = (2.0, 6.0)   # 채널 사이 무작위 쉼(초) — 기계적인 차례를 숨긴다(docs/5.txt ②)


def _get(url):
    try:
        with urlopen(Request(url, headers=HEADERS), timeout=15) as r:
            return r.read().decode('utf-8', 'ignore') if r.status == 200 else None
    except Exception:
        return None


def ensure(conn):
    for s in DDL:
        conn.execute(s)


def _unesc(s):
    return (s.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>')
            .replace('&quot;', '"').replace('&#39;', "'"))


def parse_feed(xml, cid, name):
    out = []
    for e in re.findall(r'<entry>(.*?)</entry>', xml or '', re.S):
        m = re.search(r'<yt:videoId>([^<]+)</yt:videoId>', e)
        vid = (m.group(1).strip() if m else '')
        if not VID_RX.match(vid):
            continue
        t = re.search(r'<title>([^<]*)</title>', e)
        p = re.search(r'<published>([^<]+)</published>', e)
        out.append({'vid': vid, 'channel_id': cid, 'channel': name,
                    'title': _unesc(t.group(1).strip()) if t else vid, 'published': p.group(1).strip() if p else ''})
    return out


def channel_id_from_html(html):
    for rx in (r'<link rel="canonical" href="https://www\.youtube\.com/channel/(UC[A-Za-z0-9_-]{22})"',
               r'"externalId":"(UC[A-Za-z0-9_-]{22})"', r'"channelId":"(UC[A-Za-z0-9_-]{22})"'):
        m = re.search(rx, html or '')
        if m:
            return m.group(1)
    return ''


def channel_of_video(vid, get=_get):
    """영상 하나 → (번호, 이름, 주소) · 모르면 None. 사람이 누를 때만 묻는다."""
    if not VID_RX.match(vid or ''):
        return None
    o = get('https://www.youtube.com/oembed?format=json&url=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3D' + vid)
    try:
        j = json.loads(o) if o else None
    except Exception:
        j = None
    if not isinstance(j, dict):
        return None
    name = str(j.get('author_name') or '').strip()
    url = str(j.get('author_url') or '').strip()
    if not url.startswith('https://www.youtube.com/'):
        return None
    m = re.search(r'/channel/(UC[A-Za-z0-9_-]{22})', url)
    cid = m.group(1) if m else channel_id_from_html(get(url) or '')
    return (cid, name or cid, url) if CH_RX.match(cid) else None


def vid_of(url):
    m = re.search(r'(?:youtu\.be/|youtube\.com/(?:watch\?(?:[^ ]*&)?v=|shorts/|live/|embed/))([A-Za-z0-9_-]{11})', url or '')
    return m.group(1) if m else ''


def by_app(conn):
    """앱(관리자)이 이미 받는 채널 번호 — 겹치면 내 쪽 받기를 멈춘다(앱 채널에 나온다)."""
    ensure(conn)
    return {r[0] for r in conn.execute('SELECT channel_id FROM userdb.user_app_channel')}


def channels(conn):
    ensure(conn)
    ok = {r[0]: r[1] or '' for r in conn.execute('SELECT channel_id, ok_at FROM userdb.user_my_channel_ok')}
    app = by_app(conn)
    return [{'id': r[0], 'name': r[1] or r[0], 'url': r[2] or '', 'ok_at': ok.get(r[0], ''), 'by_app': r[0] in app}
            for r in conn.execute('SELECT channel_id, channel_name, channel_url FROM userdb.user_my_channel '
                                  'ORDER BY lower(channel_name)')]


def add(conn, cid, name, url=''):
    if not CH_RX.match(cid or ''):
        return False
    ensure(conn)
    if not (url or '').startswith('https://www.youtube.com/'):
        url = ''
    conn.execute('INSERT INTO userdb.user_my_channel(channel_id, channel_name, channel_url) VALUES(?,?,?) '
                 'ON CONFLICT(channel_id) DO UPDATE SET channel_name=excluded.channel_name, '
                 'channel_url=excluded.channel_url', (cid, (name or '')[:200], url[:300]))
    conn.commit()
    return True


def remove(conn, cid):
    ensure(conn)
    conn.execute('DELETE FROM userdb.user_my_channel WHERE channel_id=?', (cid,))
    conn.execute('DELETE FROM userdb.user_my_channel_video WHERE channel_id=?', (cid,))
    conn.commit()


def _cfg(conn, k, v=None):
    if v is None:
        r = conn.execute('SELECT config_val FROM user_config WHERE config_key=?', (k,)).fetchone()
        return r[0] if r else ''
    conn.execute('INSERT OR REPLACE INTO user_config(config_key, config_val) VALUES(?,?)', (k, v))


def due(conn, now=None):
    now = now or datetime.now()
    try:
        last = datetime.fromisoformat(_cfg(conn, 'MY_CH_AT'))
    except Exception:
        return True
    return now - last >= timedelta(hours=DUE_HOURS)


def fetch(conn, force=False, get=_get, now=None):
    """하루 한 번 — 채널마다 RSS → 쌓는다(30일 넘은 것은 걷는다). → 새 영상 수(채널이 없으면 0)."""
    chs = [c for c in channels(conn) if not c['by_app']]   # 앱이 받는 채널은 건너뛴다
    if not chs or (not force and not due(conn, now)):
        return 0
    n0 = (now or datetime.now()).isoformat(timespec='seconds')
    added = 0
    import random
    import time
    for i, c in enumerate(chs):
        if i and get is _get:          # 진짜 망일 때만 쉰다(시험은 안 기다린다)
            time.sleep(random.uniform(*GAP))
        added += max(_take(conn, c['id'], c['name'], get, n0), 0)
    cut = ((now or datetime.now()) - timedelta(days=30)).isoformat()
    conn.execute('DELETE FROM userdb.user_my_channel_video WHERE published < ?', (cut,))
    _cfg(conn, 'MY_CH_AT', n0)
    conn.commit()
    return added


def _take(conn, cid, name, get, n0):
    """채널 하나 RSS → 쌓는다. → 새로 쌓은 수 · RSS 가 비면 -1(실패한 때만 적는다 · 지난 목록 유지)."""
    vs = parse_feed(get('https://www.youtube.com/feeds/videos.xml?channel_id=' + cid) or '', cid, name)
    if not vs:
        conn.execute('INSERT INTO userdb.user_my_channel_ok(channel_id, fail_at) VALUES(?,?) '
                     'ON CONFLICT(channel_id) DO UPDATE SET fail_at=excluded.fail_at', (cid, n0))
        return -1
    n = 0
    for v in vs:
        n += conn.execute('INSERT OR IGNORE INTO userdb.user_my_channel_video(vid, channel_id, channel, title, '
                          'published, fetched_at) VALUES(?,?,?,?,?,?)',
                          (v['vid'], cid, name, v['title'], v['published'], n0)).rowcount
    conn.execute('INSERT INTO userdb.user_my_channel_ok(channel_id, ok_at) VALUES(?,?) '
                 'ON CONFLICT(channel_id) DO UPDATE SET ok_at=excluded.ok_at', (cid, n0))
    return n


RSS_REF = 'UCBR8-60-B28hp2BmDPdntcQ'   # 유튜브 공식 채널 — 「유튜브 RSS 전체가 멈췄나」 잣대


def probe(conn, cid, name, get=_get):
    """담는 그 자리에서 RSS 를 한 번 받아 본다 → 받은 영상 수(0 = 유튜브가 이 채널의 RSS 를 주지 않는다).
    ★ 2026-10-24 사용자 「RSS 수집 대상 지정할 때 즉시 판단할 수 있다면, 이유를 설명하고 관리자 추천을 권하자」"""
    ensure(conn)
    if cid in by_app(conn):
        return -2                      # 앱이 이미 받는다 — 묻지 않는다(「앱 채널」에 나온다)
    n0 = datetime.now().isoformat(timespec='seconds')
    got = _take(conn, cid, name, get, n0)
    conn.commit()
    if got < 0:
        # 이 채널만 안 되나 / 유튜브 RSS 전체가 멈췄나 — 공식 채널로 가른다(⚠ 2026-10-24 모든 채널 404 실측)
        ref = parse_feed(get('https://www.youtube.com/feeds/videos.xml?channel_id=' + RSS_REF) or '', RSS_REF, '')
        return 0 if ref else -1
    r = conn.execute('SELECT COUNT(*) FROM userdb.user_my_channel_video WHERE channel_id=?', (cid,)).fetchone()
    return max(r[0] or 0, 1)


def videos(conn, limit=200):
    """최신 영상 — reading_news 목록 꼴 {title,url,site,published}. 뺀 채널의 영상은 안 나온다."""
    ensure(conn)
    return [{'title': r[0], 'url': 'https://www.youtube.com/watch?v=' + r[1], 'site': r[2] or '',
             'published': r[3] or '', 'lang': ''}
            for r in conn.execute('SELECT v.title, v.vid, v.channel, v.published FROM userdb.user_my_channel_video v '
                                  'JOIN userdb.user_my_channel c ON c.channel_id=v.channel_id '
                                  'ORDER BY v.published DESC LIMIT ?', (int(limit),))
            if VID_RX.match(r[1] or '')]


def recommend(conn, name, url, cid='', vid=''):
    """관리자에게 채널 추천 → (보냄?, 까닭)."""
    import mobile_sync as MS
    import user_feedback as F
    return F.submit(conn, 'CHANNEL', MS.ch_reco_text(name, url, cid, vid))


def selftest():
    import sqlite3
    ok = []

    def ck(n, c):
        ok.append(bool(c))
        print(('OK   ' if c else 'FAIL ') + n)

    cid = 'UC' + 'b' * 22
    c = sqlite3.connect(':memory:')
    c.execute("ATTACH ':memory:' AS userdb")
    c.execute('CREATE TABLE user_config(config_key TEXT PRIMARY KEY, config_val TEXT)')
    state = {'fail': False}

    def get(u):
        if 'oembed' in u:
            return '{"author_name":"란스","author_url":"https://www.youtube.com/@rans"}'
        if u == 'https://www.youtube.com/@rans':
            return '"externalId":"%s"' % cid
        if 'feeds/videos.xml' in u:
            if state['fail']:
                return None
            now = datetime.now().isoformat()
            return ('<feed><entry><yt:videoId>dQw4w9WgXcQ</yt:videoId><title>A &amp; B</title><published>%s</published></entry>'
                    '<entry><yt:videoId>&lt;bad&gt;</yt:videoId><title>x</title><published>%s</published></entry></feed>') % (now, now)
        return None

    ck('채널이 없으면 묻지 않는다', fetch(c, get=get) == 0)
    r = channel_of_video('dQw4w9WgXcQ', get=get)
    ck('영상 → 채널 번호', r and r[0] == cid and r[1] == '란스')
    ck('채널 번호 꼴이 아니면 안 담는다', not add(c, 'bad', 'x'))
    add(c, *r)
    ck('받기 — 영상 번호 꼴만', fetch(c, get=get) == 1 and videos(c)[0]['title'] == 'A & B')
    ck('하루 한 번', fetch(c, get=get) == 0)
    state['fail'] = True
    fetch(c, force=True, get=get)
    ck('실패해도 지난 목록 유지', len(videos(c)) == 1)
    ck('주소는 우리가 짓는다', videos(c)[0]['url'] == 'https://www.youtube.com/watch?v=dQw4w9WgXcQ')
    state['fail'] = False
    c.execute('DELETE FROM userdb.user_my_channel_video')
    ck('담을 때 받아 본다 — 받은 수', probe(c, cid, '란스', get=get) == 1)
    state['fail'] = True
    ck('RSS 를 안 주면 — 유튜브 전체가 멈췄으면 -1', probe(c, cid, '란스', get=get) == -1 and len(videos(c)) == 1)
    _g0 = get
    ck('RSS 를 안 주면 — 이 채널만이면 0',
       probe(c, cid, '란스', get=lambda u: _g0(u.replace(RSS_REF, 'X')) if RSS_REF not in u else
             '<feed><entry><yt:videoId>dQw4w9WgXcQ</yt:videoId><title>t</title><published>2026</published></entry></feed>') == 0)
    state['fail'] = False
    c.execute('INSERT INTO userdb.user_app_channel VALUES(?)', (cid,))
    asked = []
    ck('앱이 받는 채널은 담을 때 안 묻는다', probe(c, cid, '란스', get=lambda u: asked.append(u)) == -2 and not asked)
    ck('앱이 받는 채널은 받기에서 건너뛴다', fetch(c, force=True, get=lambda u: asked.append(u)) == 0 and not asked
       and channels(c)[0]['by_app'])
    c.execute('DELETE FROM userdb.user_app_channel')
    ck('관리자가 빼면 다시 받는다', fetch(c, force=True, get=get) >= 0 and channels(c)[0]['by_app'] is False)
    remove(c, cid)
    ck('빼면 그 영상도 안 나온다', videos(c) == [] and channels(c) == [])
    ck('주소 → 영상 번호', vid_of('https://youtu.be/dQw4w9WgXcQ?si=1') == 'dQw4w9WgXcQ' and vid_of('https://x') == '')
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    import sys
    sys.exit(0 if selftest() else 1)
