# -*- coding: utf-8 -*-
"""구절 약명을 **어떻게 쓸지** 정하는 단 하나의 자리 (2026-08-14 신설).

★ 규칙은 하나다 — **보이는 범위가 정한다** (사용자 판단).

    같은 책·같은 장   →  `1`         절 번호만
    같은 책·여러 장   →  `1:1`       장:절
    여러 책          →  `창 1:1`     책 약명 + 장:절

  「통일」이 아니다. P1 본문이 `1` 인 것과 연쇄 슬라이드가 `창 1:1` 인 것은
  **둘 다 옳다** — 한 장을 읽는 화면과 여러 책을 잇는 화면은 필요한 정보가 다르다.
  ⚠ 그래서 **화면마다 형식을 정하지 않는다.** 지금 그리는 줄들을 넘기면
    이 함수가 정한다. 화면이 스스로 정하면 곧 규칙이 갈라진다
    (실제로 약명을 만드는 코드가 여섯 군데로 흩어져 있었다).

  ⚠ 라틴문자 약명은 한 칸 띄우고 CJK 는 붙인다 — `Mark 6:30` / `막6:30`.
    이 규칙은 `user_main._peri_ref_label` 과 `ref_candidate_detect` 에도 있다.
"""

SCOPE_VERSE = 'verse'      # 1
SCOPE_CHAP = 'chap'        # 1:1
SCOPE_BOOK = 'book'        # 창 1:1


def scope_of(rows):
    """지금 그릴 줄들을 보고 **어느 형식이 필요한지** 정한다.

    `rows` 는 `(bcode, chapter, ...)` 를 앞에 둔 것들의 모음이면 된다.
    """
    books, chaps = set(), set()
    for r in rows or ():
        try:
            books.add(r[0])
            chaps.add((r[0], r[1]))
        except Exception:
            continue
    if len(books) > 1:
        return SCOPE_BOOK
    if len(chaps) > 1:
        return SCOPE_CHAP
    return SCOPE_VERSE


def label(scope, bname, chapter, verse):
    """그 형식으로 한 줄의 약명을 만든다."""
    v = str(verse)
    if scope == SCOPE_VERSE:
        return v
    if scope == SCOPE_CHAP:
        return f'{chapter}:{v}'
    nm = str(bname or '')
    # 라틴문자 약명은 한 칸 띄우고 CJK 는 붙인다
    sep = ' ' if (nm and nm[-1].isascii()) else ''
    return f'{nm}{sep}{chapter}:{v}'


def range_label(bname, a_ch, a_v, b_ch=None, b_v=None, bname2=None):
    """구간 표기 — `창1:1` · `창1:1~15` · `창1:1~2:3` · `창1:1~출2:3`.

    ★ 이 형식이 **세 군데에서 조금씩 달랐다**(2026-08-14 실측):
      `user_main._peri_ref_label` → `창1:1~15`
      `refr_unified_panel._ref_label` / `p4_ref_view._ref_label` → `창 1:1-15`
      같은 것을 가리키는데 물결과 붙임표가 갈렸다. ⇒ **물결(`~`)로 모은다.**
    ⚠ 라틴 약명은 한 칸 띄우고 CJK 는 붙인다 — `label()` 과 같은 규칙.
    """
    head = label(SCOPE_BOOK, bname, a_ch, a_v)
    if b_ch is None or b_v is None:
        return head
    if bname2 and bname2 != bname:                 # 책을 넘는다 (사실상 없다)
        return f'{head}~{label(SCOPE_BOOK, bname2, b_ch, b_v)}'
    if b_ch != a_ch:                               # 장을 넘는다
        return f'{head}~{b_ch}:{b_v}'
    if b_v == a_v:
        return head
    return f'{head}~{b_v}'


def width_hint(scope):
    """이어지는 줄을 맞출 들여쓰기(px) — 형식이 길수록 넓다.

    ⚠ 정확한 폭은 글꼴에 따라 다르지만, **맞추는 것 자체가 요점**이라
      형식별 고정값으로 충분하다(P1 본문만 그 장의 최대 절 번호로 정밀하게 잰다).
    """
    return {SCOPE_VERSE: 24, SCOPE_CHAP: 44}.get(scope, 62)


def _selftest():
    bad = []

    # ① 범위가 형식을 정한다
    same_ch = [(1, 1, 1), (1, 1, 2), (1, 1, 3)]
    two_ch = [(1, 1, 1), (1, 2, 1)]
    two_bk = [(1, 1, 1), (40, 1, 1)]
    if scope_of(same_ch) != SCOPE_VERSE:
        bad.append('한 장인데 절 번호만 쓰지 않는다')
    if scope_of(two_ch) != SCOPE_CHAP:
        bad.append('장이 둘인데 장:절을 안 쓴다')
    if scope_of(two_bk) != SCOPE_BOOK:
        bad.append('책이 둘인데 책 약명을 안 쓴다')
    if scope_of([]) != SCOPE_VERSE:
        bad.append('빈 목록에서 터지거나 엉뚱한 형식을 준다')

    # ② 형식대로 쓰는가
    for sc, want in ((SCOPE_VERSE, '3'), (SCOPE_CHAP, '1:3'), (SCOPE_BOOK, '창1:3')):
        got = label(sc, '창', 1, 3)
        if got != want:
            bad.append(f'{sc}: {got!r} (기대 {want!r})')

    # ③ ★ 라틴 약명은 띄우고 CJK 는 붙인다
    if label(SCOPE_BOOK, 'Mark', 6, 30) != 'Mark 6:30':
        bad.append('라틴 약명을 안 띄운다')
    if label(SCOPE_BOOK, '막', 6, 30) != '막6:30':
        bad.append('CJK 약명을 띄웠다')

    # ③-2 ★ 구간 표기 — 네 경우가 다 달라야 한다
    for args, want in (
            (('창', 1, 1), '창1:1'),                      # 한 절
            (('창', 1, 1, 1, 15), '창1:1~15'),            # 같은 장
            (('창', 1, 1, 2, 3), '창1:1~2:3'),            # 장을 넘음
            (('창', 1, 1, 2, 3, '출'), '창1:1~출2:3'),    # 책을 넘음
            (('창', 1, 1, 1, 1), '창1:1')):               # 시작=끝
        got = range_label(*args)
        if got != want:
            bad.append(f'구간 표기 {args} → {got!r} (기대 {want!r})')
    if range_label('Mark', 6, 30, 6, 44) != 'Mark 6:30~44':
        bad.append('구간에서 라틴 약명을 안 띄운다')

    # ④ 들여쓰기는 형식이 길수록 넓다
    if not (width_hint(SCOPE_VERSE) < width_hint(SCOPE_CHAP) < width_hint(SCOPE_BOOK)):
        bad.append('들여쓰기가 형식 길이를 따르지 않는다')

    print('verse_ref selftest: ' + ('OK' if not bad else 'FAIL'))
    for b in bad:
        print('  X', b)
    return 1 if bad else 0


if __name__ == '__main__':
    import sys
    sys.exit(_selftest())
