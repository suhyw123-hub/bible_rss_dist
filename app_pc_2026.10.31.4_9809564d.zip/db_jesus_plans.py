# -*- coding: utf-8 -*-
"""db_jesus_plans.py — 주제읽기 완성형 플랜 2종 (영구 도구).

2026-08-18 사용자 승인 「그 배치로 진행하라 … 그대로 적재하라」(유닛 표 검수
완료). 골라담기가 아니라 **처음부터 순서를 설계해 제공하는 주제읽기** —
「선택의 여지가 다양한 경우에만 골라담기」 기준에 따른 배치.

  python db_jesus_plans.py --selftest      # 의무 (실 DB 트랜잭션 롤백)
  python db_jesus_plans.py --apply PARABLES|ENCOUNTERS

  · 「예수님의 비유」 41일 — 하나님 나라(11) · 은혜와 잃음과 찾음(10) ·
    기도와 준비함(12) · 나는 ~이다(요한 에고 에이미 7선언) · 마무리(반석).
  · 「주님을 만난 사람들」 21일 — 스무 번의 만남 + **마지막 날 「그리고,
    나」(계 3:20)** — 문을 두드리시는 분이 만나려는 사람은 읽는 이 자신.
  · 하루 = CORE 본문(+보조 SUPPORT: 가라지 해설·야이로 앞 문맥·소경 재회).
  · cat 2(주제읽기) 아래 새 묶음, 플랜 하나 = 묶음 이름. 멱등.
  · **FOOTSTEPS 「자리에 쌓인 발자취」 15일 (2026-08-18 추가 — 골라담기
    발자취 회수 후 대체안, 유닛 표 검수 「그대로 적재하라」)** — 하루 =
    수렴 장소 하나 + 그 자리를 지난 **여러 시대의 사건 2~3단락**(CORE +
    SUPPORT 복수). 모리아=골고다·요나와 베드로의 욥바·마지막 날 새
    예루살렘(지도 밖의 성). 원안 「그 자리에 쌓인 발자취」는 10자 규칙에
    맞춰 한 자 줄임.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, 'bible_master.db')
sys.path.insert(0, HERE)
import appdb
import scripture_ref_kr


def _upsert_text(c, tt, cid, lang, val):
    row = c.execute(
        "SELECT sys_text_id FROM sys_text_asset WHERE text_type=? AND "
        "clicked_id=? AND UPPER(lang_code)=?", (tt, cid, lang)).fetchone()
    if row:
        c.execute("UPDATE sys_text_asset SET contents=?, title=?, "
                  "record_status='LIVE' WHERE sys_text_id=?",
                  (val, val, row[0]))
    else:
        c.execute("INSERT INTO sys_text_asset (text_type, clicked_id, "
                  "lang_code, title, contents, record_status) "
                  "VALUES (?,?,?,?,?,'LIVE')", (tt, cid, lang, val, val))


# day = (core_ref, support_ref|None, focus)
PLANS = {
 'PARABLES': dict(
  code='JESUS_PARABLES_41D',
  titles={'KO': '예수님의 비유', 'EN': 'The Parables of Jesus'},
  descs={'KO': '하나님 나라, 은혜와 잃음과 찾음, 기도와 준비함, 그리고 '
               '요한복음의 나는 ~이다 선언까지, 예수님의 비유를 41일 동안 '
               '순서대로 읽습니다.',
         'EN': "Forty one days through Jesus' parables, ending with the "
               'I AM sayings and the house on the rock.'},
  days=[
   ('마 13:1-23', None,
    '씨 뿌리는 자: 같은 씨앗이 어디에 떨어졌는가를 묻습니다.'),
   ('마 13:24-30', '마 13:36-43',
    '가라지: 뽑는 일은 주인의 때에 맡기라 하십니다.'),
   ('막 4:26-29', None,
    '스스로 자라는 씨: 농부가 자는 동안에도 나라는 자랍니다.'),
   ('마 13:31-33', None,
    '겨자씨와 누룩: 가장 작은 시작이 가장 크게 번집니다.'),
   ('마 13:44-46', None,
    '보화와 진주: 나라를 발견한 사람은 기쁨으로 전부를 팝니다.'),
   ('마 13:47-52', None, '그물: 모으심과 가리심이 함께 옵니다.'),
   ('마 21:33-44', None,
    '악한 농부: 아들까지 보내신 주인의 오래참음입니다.'),
   ('마 22:1-14', None, '혼인 잔치: 초청은 넓고 예복은 가볍지 않습니다.'),
   ('눅 14:15-24', None,
    '큰 잔치: 핑계로 빈 자리가 길과 산울타리에서 채워집니다.'),
   ('마 21:28-32', None, '두 아들: 대답이 아니라 가는 것이 순종입니다.'),
   ('눅 5:33-39', None, '새 포도주: 새 것은 새 부대를 요구합니다.'),
   ('눅 15:1-7', None,
    '잃은 양: 아흔아홉을 두고 하나를 찾으시는 목자입니다.'),
   ('눅 15:8-10', None,
    '잃은 드라크마: 등불을 켜고 쓸며 찾기까지 찾으십니다.'),
   ('눅 15:11-24', None,
    '잃은 아들: 아직 먼 거리에 있을 때 아버지가 먼저 달려갑니다.'),
   ('눅 15:25-32', None,
    '탕자의 형: 집 안에 있으면서 아버지 마음 밖에 있던 아들입니다.'),
   ('마 20:1-16', None,
    '포도원 품꾼: 은혜는 시급이 아니라 주인의 선하심으로 계산됩니다.'),
   ('눅 7:36-50', None, '두 빚진 자: 많이 탕감받은 자가 많이 사랑합니다.'),
   ('마 18:21-35', None,
    '빚 탕감받은 종: 일만 달란트를 잊으면 일백 데나리온에 목을 조릅니다.'),
   ('눅 18:9-14', None,
    '바리새인과 세리: 의롭다 함을 받고 내려간 사람은 가슴을 친 쪽입니다.'),
   ('눅 10:25-37', None,
    '선한 사마리아인: 누가 이웃인가가 아니라 누구의 이웃이 되겠는가입니다.'),
   ('눅 13:6-9', None,
    '무화과나무의 한 해: 금년에도 그대로 두소서, 기회의 다른 이름입니다.'),
   ('눅 11:5-13', None,
    '밤중의 친구: 강청함을 들으시는 아버지는 좋은 것을 주십니다.'),
   ('눅 18:1-8', None,
    '불의한 재판장: 하물며 하나님께서 택하신 자들의 원한을 풀어 주지 '
    '않으시겠습니까.'),
   ('눅 12:13-21', None,
    '어리석은 부자: 곳간을 늘리던 밤에 영혼을 찾으십니다.'),
   ('눅 16:1-13', None,
    '불의한 청지기: 재물로 영원한 처소를 준비하는 지혜를 배웁니다.'),
   ('눅 16:19-31', None,
    '부자와 나사로: 대문 앞의 사람이 보이지 않으면 건널 수 없는 구렁이 '
    '파이고 있습니다.'),
   ('눅 14:7-11', None, '잔치의 끝자리: 낮추는 자가 높아집니다.'),
   ('눅 14:25-33', None,
    '망대와 전쟁: 제자 되기 전에 먼저 앉아 비용을 계산하라 하십니다.'),
   ('눅 12:35-48', None, '깨어 있는 종: 주인은 생각지 않은 때에 옵니다.'),
   ('마 25:1-13', None,
    '열 처녀: 등뿐 아니라 기름, 겉모양이 아니라 준비입니다.'),
   ('마 25:14-30', None,
    '달란트: 맡기신 것의 크기가 아니라 충성이 계산됩니다.'),
   ('눅 17:7-10', None,
    '무익한 종: 다 행한 후에도 우리는 마땅히 할 일을 한 종입니다.'),
   ('마 25:31-46', None,
    '양과 염소: 지극히 작은 자에게 한 것이 곧 내게 한 것입니다.'),
   ('요 6:32-40', None,
    '나는 생명의 떡이니: 주리지 않는 양식이 여기 있습니다.'),
   ('요 8:12-20', None,
    '나는 세상의 빛이니: 따르는 자는 어둠에 다니지 않습니다.'),
   ('요 10:1-10', None,
    '나는 양의 문이라: 들어가며 나오며 꼴을 얻는 문입니다.'),
   ('요 10:11-18', None,
    '나는 선한 목자라: 양들을 위하여 목숨을 버립니다.'),
   ('요 11:17-27', None,
    '나는 부활이요 생명이니: 무덤 앞에서 하신 선언입니다.'),
   ('요 14:1-7', None,
    '내가 곧 길이요 진리요 생명이니: 아버지께로 가는 길이 인격입니다.'),
   ('요 15:1-8', None,
    '나는 참 포도나무요: 붙어 있는 가지만 열매를 맺습니다.'),
   ('마 7:24-27', None,
    '반석 위의 집: 비유를 다 들은 사람에게 남는 마지막 질문은 행함입니다.'),
  ]),
 'ENCOUNTERS': dict(
  code='JESUS_ENCOUNTERS_21D',
  titles={'KO': '주님을 만난 사람들', 'EN': 'They Met the Lord'},
  descs={'KO': '복음서의 스무 번의 만남을 지켜보고, 마지막 날에는 문 밖에서 '
               '두드리시는 그분 앞에 내가 섭니다.',
         'EN': 'Twenty encounters with Jesus in the Gospels, and on the '
               'final day, you.'},
  days=[
   ('요 3:1-16', None, '니고데모: 밤에 온 선생이 거듭남 앞에 섭니다.'),
   ('요 4:5-26', None,
    '사마리아 여인: 목마르지 않는 물을 우물가에서 건네십니다.'),
   ('마 8:5-13', None,
    '백부장: 말씀만 하옵소서, 주님이 놀라신 믿음입니다.'),
   ('막 2:1-12', None,
    '네 친구: 지붕을 뜯는 우정을 보시고 죄 사함을 선언하십니다.'),
   ('마 9:9-13', None,
    '마태: 세관에 앉은 사람을 부르시고 죄인들과 한 상에 앉으십니다.'),
   ('막 5:25-34', None,
    '혈루증 여인: 옷자락 한 끝의 믿음을 딸아 하고 부르십니다.'),
   ('막 5:35-43', '막 5:21-24',
    '야이로: 두려워 말고 믿기만 하라, 죽음의 소식 앞에서 하신 말씀입니다.'),
   ('막 7:24-30', None,
    '수로보니게 여인: 부스러기로 족하다는 믿음이 칭찬받습니다.'),
   ('막 10:17-27', None,
    '부자 청년: 사랑하시며 바라보셨으나 근심하며 돌아간 사람입니다.'),
   ('눅 19:1-10', None,
    '삭개오: 나무 위의 사람을 이름으로 부르시고 그 집에 머무십니다.'),
   ('막 10:46-52', None,
    '바디매오: 조용히 하라는 무리 너머로 소리 지른 믿음입니다.'),
   ('요 9:1-12', '요 9:35-38',
    '나면서 소경 된 사람: 누구의 죄도 아니요 하나님의 일이 나타나기 '
    '위함입니다.'),
   ('눅 10:38-42', None,
    '마르다와 마리아: 많은 일로 분주함과 한 가지 좋은 편입니다.'),
   ('요 8:1-11', None,
    '간음하다 잡힌 여인: 나도 너를 정죄하지 아니하노니 다시는 죄를 범치 '
    '말라.'),
   ('요 12:1-8', None,
    '향유의 마리아: 낭비라 불린 사랑이 복음과 함께 기억됩니다.'),
   ('막 10:13-16', None,
    '어린아이들: 금하지 말라, 나라가 이런 자의 것입니다.'),
   ('눅 23:39-43', None,
    '십자가의 강도: 오늘 네가 나와 함께 낙원에 있으리라.'),
   ('요 20:24-29', None,
    '도마: 의심을 책망하지 않으시고 못 자국을 내미십니다.'),
   ('눅 24:13-35', None,
    '엠마오: 동행하시며 마음을 뜨겁게 하시고 떡을 떼실 때 알아봅니다.'),
   ('요 21:15-19', None,
    '베드로: 세 번의 부인을 세 번의 사랑 고백으로 회복시키십니다.'),
   ('계 3:20', None,
    '그리고, 나: 스무 번의 만남을 지켜본 당신 차례입니다. 문을 두드리시는 '
    '분이 만나려는 사람은 당신입니다.'),
  ]),
 'FOOTSTEPS': dict(
  code='FOOTSTEPS_PLACES_15D',
  titles={'KO': '자리에 쌓인 발자취', 'EN': 'Layers of Footsteps'},
  descs={'KO': '한 장소를 여러 시대의 발자취가 지나갔습니다. 하루에 한 '
               '자리씩, 그 땅에 겹겹이 쌓인 사건들을 함께 읽습니다.',
         'EN': 'One place, many footsteps. Fifteen sites where redemptive '
               'history piled up, read layer by layer.'},
  days=[
   ('창 12:7-9', ('창 28:10-22', '창 35:1-7'),
    '벧엘: 아브라함의 제단 자리가 야곱에게는 하늘 문이 되고, 돌아온 '
    '야곱에게 다시 제단이 됩니다.'),
   ('창 12:6-7', ('수 24:14-27', '요 4:5-15'),
    '세겜: 약속이 처음 선포된 땅에서 언약이 갱신되고, 그 우물가에서 '
    '생수가 약속됩니다.'),
   ('창 13:14-18', ('삼하 5:1-5',),
    '헤브론: 아브라함이 장막을 옮겨 제단을 쌓은 땅이 다윗의 첫 왕좌가 '
    '됩니다.'),
   ('창 26:23-25', ('창 46:1-5',),
    '브엘세바: 아버지의 우물가에서 이삭이 제단을 쌓고, 야곱은 애굽으로 '
    '내려가기 전 마지막 제사를 드립니다.'),
   ('창 45:4-8', ('출 12:37-42', '마 2:13-15'),
    '애굽: 생명을 구원하시려고 먼저 보내신 땅에서 백성이 나오고, 아들도 '
    '애굽에서 불려 나옵니다.'),
   ('출 3:1-6', ('출 19:16-20', '왕상 19:8-13'),
    '시내산: 떨기나무의 산이 율법의 산이 되고, 지친 선지자에게는 세미한 '
    '소리의 산이 됩니다.'),
   ('신 8:2-5', ('마 4:1-11',),
    '광야: 사십 년의 시험에서 넘어진 자리를 사십 일의 시험이 이깁니다.'),
   ('수 3:14-17', ('왕하 2:6-14', '마 3:13-17'),
    '요단 강: 건넘의 강이 부르심의 강이 되고, 마침내 하늘이 열리는 강이 '
    '됩니다.'),
   ('수 6:15-20', ('눅 19:1-10',),
    '여리고: 무너진 성벽의 도시에 잃어버린 자를 찾는 구원이 들어갑니다.'),
   ('창 22:1-14', ('대하 3:1-2', '요 19:16-30'),
    '모리아와 골고다: 여호와 이레의 산에 성전이 서고, 그 산에서 하나님이 '
    '친히 어린 양을 준비하십니다.'),
   ('왕상 8:27-30', ('눅 2:46-49', '행 3:1-10'),
    '성전 뜰: 솔로몬의 기도가 서린 뜰에 소년 예수가 앉고, 미문 곁에서 '
    '나사렛 예수의 이름이 일으켜 세웁니다.'),
   ('욘 1:1-3', ('행 10:9-16', '행 10:34-35'),
    '욥바: 이방을 피해 배를 탄 항구에서, 이방에게 문을 여는 환상이 '
    '열립니다.'),
   ('삼하 15:30-31', ('눅 22:39-46', '행 1:9-12'),
    '감람산: 다윗이 울며 오른 산에서 다윗의 자손이 땀이 핏방울이 되도록 '
    '기도하고, 그 산에서 하늘로 오르십니다.'),
   ('왕하 5:9-14', ('행 9:1-19',),
    '다메섹: 나아만이 씻음 받은 길목에서 사울이 눈을 뜹니다.'),
   ('사 65:17-19', ('계 21:1-5', '계 22:1-5'),
    '새 예루살렘: 발자취의 마지막 자리는 지도에 없습니다. 모든 길이 그 '
    '성을 향해 있었습니다.'),
  ]),
}


def apply(conn, which, verbose=True):
    p = PLANS[which]
    c = conn
    bm = scripture_ref_kr.book_map_ko(c)
    rows = []
    for day, (core, sup, focus) in enumerate(p['days'], 1):
        a, b = scripture_ref_kr.resolve(c, core, bm)
        if a is None:
            raise SystemExit('구절 해석 실패: %s' % core)
        # 보조는 하나(str)일 수도, 여럿(tuple — FOOTSTEPS)일 수도 있다
        sups = []
        for sr in ([sup] if isinstance(sup, str) else (sup or ())):
            sa, sb = scripture_ref_kr.resolve(c, sr, bm)
            if sa is None:
                raise SystemExit('구절 해석 실패: %s' % sr)
            sups.append((sa, sb))
        rows.append((day, (a, b), sups, focus))

    # 카테고리 — cat 2(주제읽기) 아래 새 묶음
    row = c.execute("""SELECT t.clicked_id FROM sys_text_asset t
        JOIN sys_plan_category pc ON pc.cat_id=t.clicked_id
        WHERE t.text_type='PLAN_CAT_NAME' AND t.contents=? AND
        t.lang_code='KO' AND pc.parent_id=2 LIMIT 1""",
        (p['titles']['KO'],)).fetchone()
    if row:
        cat_id = row[0]
    else:
        cat_id = c.execute('SELECT COALESCE(MAX(cat_id),0)+1 FROM '
                           'sys_plan_category').fetchone()[0]
        so = c.execute('SELECT COALESCE(MAX(sort_order),0)+10 FROM '
                       'sys_plan_category WHERE parent_id=2').fetchone()[0]
        c.execute("INSERT INTO sys_plan_category (cat_id, parent_id, "
                  "sort_order, record_status, scope) "
                  "VALUES (?,2,?,'LIVE','BIBLE')", (cat_id, so))
    for lg in ('KO', 'EN'):
        _upsert_text(c, 'PLAN_CAT_NAME', cat_id, lg, p['titles'][lg])

    # 플랜
    row = c.execute('SELECT plan_id FROM sys_bible_plan WHERE plan_code=?',
                    (p['code'],)).fetchone()
    days = len(p['days'])
    if row:
        plan_id = row[0]
        c.execute("UPDATE sys_bible_plan SET plan_type='THEMATIC', "
                  "plan_category='THEMATIC', duration_days=?, track_count=1, "
                  "cat_id=?, record_status='LIVE' WHERE plan_id=?",
                  (days, cat_id, plan_id))
    else:
        cur = c.execute("""INSERT INTO sys_bible_plan (plan_code, plan_type,
                     duration_days, track_count, record_status,
                     plan_category, cat_id)
                     VALUES (?,'THEMATIC',?,1,'LIVE','THEMATIC',?)""",
                        (p['code'], days, cat_id))
        plan_id = cur.lastrowid
    for lg in ('KO', 'EN'):
        _upsert_text(c, 'PLAN_TITLE', plan_id, lg, p['titles'][lg])
        _upsert_text(c, 'PLAN_DESC', plan_id, lg, p['descs'][lg])

    # 스케줄 — CORE(포커스) + SUPPORT(복수 가능)
    c.execute('DELETE FROM sys_plan_schedule WHERE plan_id=?', (plan_id,))
    for day, (a, b), sups, focus in rows:
        c.execute("INSERT INTO sys_plan_schedule (plan_id, day, track, "
                  "start_vid, end_vid, stage_type, sort_order, "
                  "meditation_focus) VALUES (?,?,1,?,?,'CORE',1,?)",
                  (plan_id, day, a, b, focus))
        for k, (sa, sb) in enumerate(sups, 2):
            c.execute("INSERT INTO sys_plan_schedule (plan_id, day, track, "
                      "start_vid, end_vid, stage_type, sort_order) "
                      "VALUES (?,?,1,?,?,'SUPPORT',?)",
                      (plan_id, day, sa, sb, k))
    if verbose:
        ns = c.execute('SELECT COUNT(*) FROM sys_plan_schedule WHERE '
                       'plan_id=?', (plan_id,)).fetchone()[0]
        print('플랜 %s(plan_id %d, cat %d) %d일 · 스케줄 %d행'
              % (p['code'], plan_id, cat_id, days, ns))
    return plan_id, cat_id


def selftest():
    ok = True

    def t(name, cond):
        nonlocal ok
        print('%s %s' % ('✓' if cond else '✗', name))
        ok = ok and cond

    conn = appdb.connect(DB)
    before = conn.execute('SELECT COUNT(*) FROM sys_plan_schedule').fetchone()[0]
    try:
        conn.execute('BEGIN')
        for which, days in (('PARABLES', 41), ('ENCOUNTERS', 21),
                            ('FOOTSTEPS', 15)):
            plan_id, cat_id = apply(conn, which, verbose=False)
            rows = conn.execute(
                "SELECT day, stage_type, start_vid, meditation_focus FROM "
                "sys_plan_schedule WHERE plan_id=? ORDER BY day, sort_order",
                (plan_id,)).fetchall()
            n_sup = sum(1 for r in rows if r[1] == 'SUPPORT')
            t('%s %d일·행 %d(=일+보조 %d)' % (which, days, len(rows), n_sup),
              len(rows) == days + n_sup
              and sorted({r[0] for r in rows}) == list(range(1, days + 1)))
            t('%s 포커스 전일 보유(대시 0)' % which,
              all((r[3] or '').strip() and '—' not in r[3]
                  for r in rows if r[1] == 'CORE'))
            t('%s vid 전부' % which, all(r[2] for r in rows))
            title = conn.execute(
                "SELECT contents FROM sys_text_asset WHERE "
                "text_type='PLAN_TITLE' AND clicked_id=? AND lang_code='KO'",
                (plan_id,)).fetchone()[0]
            t('%s 제목 규칙(10자 이내)' % which, len(title) <= 10)
            p2, c2 = apply(conn, which, verbose=False)
            t('%s 멱등' % which, (p2, c2) == (plan_id, cat_id))
        # 마지막 날 = 계 3:20 (「그리고, 나」)
        pe = conn.execute("SELECT plan_id FROM sys_bible_plan WHERE "
                          "plan_code='JESUS_ENCOUNTERS_21D'").fetchone()[0]
        last = conn.execute(
            "SELECT bi.bcode, bi.chapter, bi.verse FROM sys_plan_schedule s "
            "JOIN bible_index bi ON bi.verse_id=s.start_vid "
            "WHERE s.plan_id=? AND s.day=21 AND s.stage_type='CORE'",
            (pe,)).fetchone()
        t('만남 21일차 = 계 3:20', last == (66, 3, 20))
        # 발자취 — 10일차 모리아(창 22) + 15일차 보조 2건(계 21·22)
        pf = conn.execute("SELECT plan_id FROM sys_bible_plan WHERE "
                          "plan_code='FOOTSTEPS_PLACES_15D'").fetchone()[0]
        d10 = conn.execute(
            "SELECT bi.bcode, bi.chapter, bi.verse FROM sys_plan_schedule s "
            "JOIN bible_index bi ON bi.verse_id=s.start_vid "
            "WHERE s.plan_id=? AND s.day=10 AND s.stage_type='CORE'",
            (pf,)).fetchone()
        n15 = conn.execute(
            "SELECT COUNT(*) FROM sys_plan_schedule WHERE plan_id=? AND "
            "day=15 AND stage_type='SUPPORT'", (pf,)).fetchone()[0]
        t('발자취 10일차=창 22·15일차 보조 2', d10 == (1, 22, 1) and n15 == 2)
    finally:
        conn.rollback()
        conn.close()
    conn = appdb.connect(DB)
    try:
        after = conn.execute('SELECT COUNT(*) FROM sys_plan_schedule').fetchone()[0]
        t('롤백 — 실 DB 무변화(%d행 유지)' % before, after == before)
    finally:
        conn.close()
    print('selftest', 'OK' if ok else 'FAIL')
    return ok


if __name__ == '__main__':
    a = sys.argv[1:]
    if not a or a[0] == '--selftest':
        sys.exit(0 if selftest() else 1)
    if a[0] == '--apply' and len(a) >= 2 and a[1].upper() in PLANS:
        conn = appdb.connect(DB)
        try:
            apply(conn, a[1].upper())
            conn.commit()
        finally:
            conn.close()
        sys.exit(0)
    print(__doc__)
