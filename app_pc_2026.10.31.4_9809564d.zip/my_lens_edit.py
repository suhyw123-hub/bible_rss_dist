# -*- coding: utf-8 -*-
"""my_lens_edit.py — **내 렌즈 만들기**(체계 + 설명문) (2026-08-27 신설·영구).

★ 왜 (사용자 지시 「지금 렌즈묵상은 단순 연결이 아니라 **새롭게 만드는
  기능**이 필요하다 … 렌즈 / 노드 체계와 설명문을 만드는 화면을 만들어라」):
  렌즈 덮개(_LensTab)는 **있는 글에 얹는** 것뿐이라 내 렌즈를 처음부터
  지을 길이 없었다(lens_share 가져오기·plan 류만 있었다).

★ 데이터 문법은 **lens_share(가져오기)와 글자 하나까지 같다** — 렌즈 =
  `user_unit_asset(CONTAINER)` · 노드 = `(NODE)` + `CONT_NODE` · 구절 =
  `NODE_VERS(+end_id)` · 글 = `user_text_asset(clicked_id=유닛/링크 번호)`.
  같은 문법이라 LensView(P1 렌즈묵상)가 **바로 읽는다.**
⚠ `unit_name_sid` 는 **전역 UNIQUE** — 이름 겹침은 ` (2)` 꼬리표
  (`lens_share._unique_name` 재사용, 두 벌 금지).
⚠ 삭제 = **cascade HIDE**(렌즈·노드·딸린 링크) — 휴지통에서 되살린다.
  물리삭제가 아니다(삭제 동사 확정 전까지 내 것도 숨김 문법).

    python my_lens_edit.py --selftest     (의무)
"""
import sys
import tkinter as tk
from tkinter import ttk, messagebox

import appdb
import i18n

#: 노드 글 세 구획 — lens_share.NODE_TT 와 같은 유형
NODE_TT = (('desc', 'OE_S_NDESC', '노드 설명', 'NODE_DESC'),
           ('question', 'OE_S_NQ', '노드 묵상질문', 'NODE_QUESTION'),
           ('prayer', 'OE_S_NP', '노드 묵상기도', 'NODE_PRAYER'))


# ══════════════════════════════════════════════════════════════════
#  데이터 층
# ══════════════════════════════════════════════════════════════════
def my_lenses(conn):
    return conn.execute(
        "SELECT user_unit_id, unit_name_sid FROM userdb.user_unit_asset "
        "WHERE unit_type='CONTAINER' "
        "AND COALESCE(record_status,'LIVE')='LIVE' "
        "ORDER BY sort_order, user_unit_id").fetchall()


def nodes_of(conn, lens_id):
    return conn.execute(
        "SELECT u.user_unit_id, u.unit_name_sid, "
        " (SELECT COUNT(*) FROM userdb.user_link_asset v "
        "   WHERE v.link_type='NODE_VERS' AND v.clicked_id=u.user_unit_id "
        "   AND COALESCE(v.record_status,'LIVE')='LIVE') "
        "FROM userdb.user_link_asset l "
        "JOIN userdb.user_unit_asset u ON u.user_unit_id=l.target_id "
        "WHERE l.link_type='CONT_NODE' AND l.clicked_id=? "
        "AND COALESCE(l.record_status,'LIVE')='LIVE' "
        "AND COALESCE(u.record_status,'LIVE')='LIVE' "
        "ORDER BY l.sort_order, u.user_unit_id", (lens_id,)).fetchall()


def verses_of(conn, node_id, lang='KO'):
    """[(link_id, vid, end_id, 라벨, 설명문 유무)]"""
    out = []
    for lid, vid, end in conn.execute(
            "SELECT user_link_id, target_id, end_id "
            "FROM userdb.user_link_asset "
            "WHERE link_type='NODE_VERS' AND clicked_id=? "
            "AND COALESCE(record_status,'LIVE')='LIVE' "
            "ORDER BY sort_order, user_link_id", (node_id,)):
        lbl = _vlabel(conn, vid, end, lang)
        has = bool(conn.execute(
            "SELECT 1 FROM userdb.user_text_asset "
            "WHERE text_type='NODE_VERS_DESC' AND clicked_id=? "
            "AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
            (lid,)).fetchone())
        out.append((lid, vid, end, lbl, has))
    return out


def _vlabel(conn, vid, end_vid, lang='KO'):
    import verse_ref
    r = conn.execute(
        'SELECT bn.short_name, bi.chapter, bi.verse FROM bible_index bi '
        'LEFT JOIN book_names bn ON bn.book_code=bi.bcode '
        'AND UPPER(bn.lang_code)=? WHERE bi.verse_id=?',
        ((lang or 'KO').upper(), vid)).fetchone()
    if not r:
        return '#%s' % vid
    lbl = verse_ref.label(verse_ref.SCOPE_BOOK, r[0] or '', r[1], r[2])
    if end_vid and end_vid != vid:
        r2 = conn.execute('SELECT chapter, verse FROM bible_index '
                          'WHERE verse_id=?', (end_vid,)).fetchone()
        if r2:
            lbl += '~%s' % (('%d:%d' % (r2[0], r2[1]))
                            if r2[0] != r[1] else str(r2[1]))
    return lbl


def create_lens(conn, name, cat_id=None):
    import lens_share
    name = lens_share._unique_name(conn, (name or '내 렌즈').strip())
    r = conn.execute(
        "SELECT COALESCE(MAX(sort_order),0) FROM userdb.user_unit_asset "
        "WHERE unit_type='CONTAINER'").fetchone()
    cur = conn.execute(
        "INSERT INTO userdb.user_unit_asset (unit_type, unit_name_sid, "
        "sort_order, record_status, cat_id) VALUES ('CONTAINER',?,?,'LIVE',?)",
        (name, (r[0] or 0) + 10, cat_id))
    conn.commit()
    return cur.lastrowid, name


def create_node(conn, lens_id, name):
    import lens_share
    name = lens_share._unique_name(conn, (name or '노드').strip())
    r = conn.execute(
        "SELECT COALESCE(MAX(sort_order),0) FROM userdb.user_link_asset "
        "WHERE link_type='CONT_NODE' AND clicked_id=?", (lens_id,)).fetchone()
    order = (r[0] or 0) + 10
    cur = conn.execute(
        "INSERT INTO userdb.user_unit_asset (unit_type, unit_name_sid, "
        "sort_order, record_status) VALUES ('NODE',?,?,'LIVE')", (name, order))
    nid = cur.lastrowid
    conn.execute(
        "INSERT INTO userdb.user_link_asset (clicked_id, target_id, link_type,"
        " sort_order, record_status) VALUES (?,?,'CONT_NODE',?,'LIVE')",
        (lens_id, nid, order))
    conn.commit()
    return nid, name


def rename_unit(conn, unit_id, name):
    import lens_share
    name = (name or '').strip()
    if not name:
        return None
    cur = conn.execute('SELECT unit_name_sid FROM userdb.user_unit_asset '
                       'WHERE user_unit_id=?', (unit_id,)).fetchone()
    if cur and cur[0] == name:
        return name
    name = lens_share._unique_name(conn, name)
    conn.execute('UPDATE userdb.user_unit_asset SET unit_name_sid=? '
                 'WHERE user_unit_id=?', (name, unit_id))
    conn.commit()
    return name


def add_verse(conn, node_id, vid, end_vid=None):
    """구절(1절/구간) 담기 — 같은 짝이 살아 있으면 DUP, 숨김이면 되살림."""
    end = end_vid if (end_vid and end_vid != vid) else None
    r = conn.execute(
        "SELECT user_link_id, COALESCE(record_status,'LIVE') "
        "FROM userdb.user_link_asset WHERE link_type='NODE_VERS' "
        "AND clicked_id=? AND target_id=? "
        "AND COALESCE(end_id,target_id)=COALESCE(?,target_id)",
        (node_id, vid, end)).fetchone()
    if r:
        if r[1] == 'HIDE':
            conn.execute("UPDATE userdb.user_link_asset SET "
                         "record_status='LIVE' WHERE user_link_id=?", (r[0],))
            conn.commit()
            return r[0], 'REVIVED'
        return r[0], 'DUP'
    o = conn.execute(
        "SELECT COALESCE(MAX(sort_order),0) FROM userdb.user_link_asset "
        "WHERE link_type='NODE_VERS' AND clicked_id=?", (node_id,)).fetchone()
    cur = conn.execute(
        "INSERT INTO userdb.user_link_asset (clicked_id, target_id, end_id, "
        "link_type, sort_order, record_status) "
        "VALUES (?,?,?,'NODE_VERS',?,'LIVE')",
        (node_id, vid, end, (o[0] or 0) + 10))
    conn.commit()
    return cur.lastrowid, 'NEW'


def remove_verse(conn, link_id):
    """구절 빼기 — 내가 지은 구성이라 링크·딸린 글을 지운다(구성 편집)."""
    conn.execute("DELETE FROM userdb.user_text_asset "
                 "WHERE text_type='NODE_VERS_DESC' AND clicked_id=?",
                 (link_id,))
    conn.execute('DELETE FROM userdb.user_link_asset WHERE user_link_id=?',
                 (link_id,))
    conn.commit()


def get_text(conn, text_type, clicked_id, lang='KO'):
    lg = (lang or 'KO').upper()
    for l2 in [lg] + [x for x in ('EN', 'KO') if x != lg]:
        r = conn.execute(
            'SELECT contents FROM userdb.user_text_asset '
            'WHERE text_type=? AND clicked_id=? AND UPPER(lang_code)=? '
            "AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
            (text_type, clicked_id, l2)).fetchone()
        if r and (r[0] or '').strip():
            return r[0]
    return ''


def set_text(conn, text_type, clicked_id, lang, body):
    lg = (lang or 'KO').upper()
    body = (body or '').strip()
    if not body:
        conn.execute('DELETE FROM userdb.user_text_asset WHERE text_type=? '
                     'AND clicked_id=? AND UPPER(lang_code)=?',
                     (text_type, clicked_id, lg))
        conn.commit()
        return
    cur = conn.execute(
        "UPDATE userdb.user_text_asset SET contents=?, record_status='LIVE' "
        'WHERE text_type=? AND clicked_id=? AND UPPER(lang_code)=?',
        (body, text_type, clicked_id, lg))
    if cur.rowcount == 0:
        conn.execute(
            'INSERT INTO userdb.user_text_asset (text_type, clicked_id, '
            "contents, lang_code, record_status) VALUES (?,?,?,?,'LIVE')",
            (text_type, clicked_id, body, lg))
    conn.commit()


def delete_node(conn, node_id):
    """노드 삭제 = cascade **HIDE**(노드·CONT_NODE·NODE_VERS) — 휴지통 회복."""
    conn.execute("UPDATE userdb.user_unit_asset SET record_status='HIDE' "
                 'WHERE user_unit_id=?', (node_id,))
    conn.execute("UPDATE userdb.user_link_asset SET record_status='HIDE' "
                 "WHERE (link_type='CONT_NODE' AND target_id=?) "
                 "   OR (link_type='NODE_VERS' AND clicked_id=?)",
                 (node_id, node_id))
    conn.commit()


def delete_lens(conn, lens_id):
    """렌즈 삭제 = cascade HIDE(렌즈·노드 전부)."""
    for nid, _nm, _n in nodes_of(conn, lens_id):
        delete_node(conn, nid)
    conn.execute("UPDATE userdb.user_unit_asset SET record_status='HIDE' "
                 'WHERE user_unit_id=?', (lens_id,))
    conn.execute("UPDATE userdb.user_link_asset SET record_status='HIDE' "
                 "WHERE link_type='CONT_NODE' AND clicked_id=?", (lens_id,))
    conn.commit()


# ══════════════════════════════════════════════════════════════════
#  화면 — 총괄 창(My Edit)의 「렌즈 구성」 앵커가 심는다
# ══════════════════════════════════════════════════════════════════
class LensBuildPanel(ttk.Frame):
    """좌 = 내 렌즈 트리(렌즈→노드) · 우 = 선택한 것의 글/구절.

    표준 서식(§36) — 글꼴 이름·색을 적지 않는다(테마가 칠한다)."""

    def __init__(self, parent, db_path, lang_getter, on_changed=None):
        super().__init__(parent)
        _t = i18n.t
        self.db = db_path
        self._lang = lang_getter
        self._on_changed = on_changed
        self._cur = None                    # ('LENS', id) | ('NODE', id)

        bar = ttk.Frame(self)
        bar.pack(fill='x', padx=8, pady=(8, 4))
        for key, dflt, cmd in (
                ('MLE_ADD_LENS', '＋ 렌즈', self._add_lens),
                ('MLE_ADD_NODE', '＋ 노드', self._add_node),
                ('MLE_RENAME', '이름 바꾸기', self._rename),
                ('MLE_DEL', '삭제(휴지통)', self._delete)):
            tk.Button(bar, text=_t(key, dflt), bd=1, padx=8,
                      command=cmd).pack(side='left', padx=(0, 6))
        tk.Label(self, anchor='w', justify='left', text='ⓘ ' + _t(
            'MLE_HINT', '여기서 만든 렌즈는 P1 렌즈묵상의 「My 렌즈」에 바로 '
            '나타납니다. 구절은 1절도 구간(끝절)도 담을 수 있습니다.')).pack(
            fill='x', padx=10, pady=(0, 4))

        pw = ttk.Panedwindow(self, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=8, pady=(0, 8))

        lf = ttk.Frame(pw)
        pw.add(lf, weight=1)
        self._tv = ttk.Treeview(lf, show='tree', selectmode='browse')
        sb = ttk.Scrollbar(lf, orient='vertical', command=self._tv.yview)
        self._tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._tv.pack(fill='both', expand=True)
        self._tv.bind('<<TreeviewSelect>>', lambda _e: self._on_pick())

        self._right = ttk.Frame(pw)
        pw.add(self._right, weight=3)
        self._build_right()
        self.refresh()

    # ── 왼쪽 트리 ────────────────────────────────────────────────
    def refresh(self, keep=None):
        self._tv.delete(*self._tv.get_children())
        with appdb.connect(self.db) as conn:
            for lid, nm in my_lenses(conn):
                li = self._tv.insert('', 'end', iid='L%d' % lid,
                                     text=nm, open=True)
                for nid, nnm, nv in nodes_of(conn, lid):
                    self._tv.insert(li, 'end', iid='N%d' % nid,
                                    text='%s  (%d)' % (nnm, nv))
        if keep and self._tv.exists(keep):
            self._tv.selection_set(keep)
            self._tv.see(keep)
        else:
            self._show_none()

    def _sel(self):
        s = self._tv.selection()
        if not s:
            return None
        iid = s[0]
        return ('LENS' if iid[0] == 'L' else 'NODE'), int(iid[1:]), iid

    def _parent_lens(self, iid):
        p = self._tv.parent(iid)
        return int(p[1:]) if p else None

    # ── 상단 동작 ────────────────────────────────────────────────
    def _ask_name(self, title, dflt=''):
        _t = i18n.t
        win = tk.Toplevel(self)
        win.title(title)
        win.transient(self.winfo_toplevel())
        win.grab_set()
        tk.Label(win, text=_t('MLE_NAME', '이름'), anchor='w').pack(
            fill='x', padx=10, pady=(10, 2))
        e = tk.Entry(win, width=36)
        e.insert(0, dflt)
        e.pack(padx=10)
        out = {'v': None}

        def okk(_e=None):
            out['v'] = e.get().strip()
            win.destroy()
        bf = tk.Frame(win)
        bf.pack(pady=8)
        tk.Button(bf, text=_t('COMMON_SAVE', '저장'), bd=1, padx=10,
                  command=okk).pack(side='left', padx=4)
        tk.Button(bf, text=_t('BTN_CANCEL', '취소'), bd=1, padx=10,
                  command=win.destroy).pack(side='left')
        e.focus_set()
        win.bind('<Return>', okk)
        try:
            import ui_theme
            ui_theme.adopt(win)
        except Exception:
            pass
        win.wait_window()
        return out['v']

    def _add_lens(self):
        _t = i18n.t
        nm = self._ask_name(_t('MLE_ADD_LENS', '＋ 렌즈'))
        if not nm:
            return
        with appdb.connect(self.db) as conn:
            lid, nm = create_lens(conn, nm)
        self.refresh(keep='L%d' % lid)
        self._changed()

    def _add_node(self):
        _t = i18n.t
        sel = self._sel()
        if not sel:
            messagebox.showinfo(_t('MLE_TITLE', '렌즈 구성'),
                                _t('MLE_PICK_LENS', '노드를 담을 렌즈를 먼저 '
                                   '선택하세요.'), parent=self)
            return
        lens_id = sel[1] if sel[0] == 'LENS' else self._parent_lens(sel[2])
        nm = self._ask_name(_t('MLE_ADD_NODE', '＋ 노드'))
        if not nm or not lens_id:
            return
        with appdb.connect(self.db) as conn:
            nid, nm = create_node(conn, lens_id, nm)
        self.refresh(keep='N%d' % nid)
        self._changed()

    def _rename(self):
        sel = self._sel()
        if not sel:
            return
        _t = i18n.t
        cur = self._tv.item(sel[2], 'text').split('  (')[0]
        nm = self._ask_name(_t('MLE_RENAME', '이름 바꾸기'), cur)
        if not nm or nm == cur:
            return
        with appdb.connect(self.db) as conn:
            rename_unit(conn, sel[1], nm)
        self.refresh(keep=sel[2])
        self._changed()

    def _delete(self):
        sel = self._sel()
        if not sel:
            return
        _t = i18n.t
        kind_nm = _t('OC_K_LENS', '렌즈') if sel[0] == 'LENS' \
            else _t('MLE_NODE', '노드')
        if not messagebox.askyesno(
                _t('MLE_DEL', '삭제(휴지통)'),
                _t('MLE_DEL_Q', '「{name}」{kind}을(를) 휴지통으로 보냅니다. '
                   '되살리기는 휴지통 탭에서. 계속할까요?').format(
                    name=self._tv.item(sel[2], 'text').split('  (')[0],
                    kind=kind_nm), parent=self):
            return
        with appdb.connect(self.db) as conn:
            (delete_lens if sel[0] == 'LENS' else delete_node)(conn, sel[1])
        self.refresh()
        self._changed()

    # ── 오른쪽 — 글·구절 ─────────────────────────────────────────
    def _build_right(self):
        _t = i18n.t
        r = self._right
        self._none_lbl = tk.Label(
            r, anchor='w', justify='left',
            text=_t('MLE_NONE', '왼쪽에서 렌즈나 노드를 선택하세요.\n'
                    '[＋ 렌즈]로 새 렌즈를 만들 수 있습니다.'))
        self._none_lbl.pack(fill='x', padx=10, pady=10)

        self._edit_f = ttk.Frame(r)          # 고른 것의 편집 영역
        top = ttk.Frame(self._edit_f)
        top.pack(fill='x', padx=6, pady=(6, 2))
        self._name_lbl = tk.Label(top, text='', anchor='w', font=('', 12,
                                                                  'bold'))
        self._name_lbl.pack(side='left')
        self._b_save = tk.Button(top, text=_t('MLE_SAVE_TXT', '글 저장'),
                                 bd=1, padx=10, command=self._save_texts)
        self._b_save.pack(side='right')

        self._txts = {}                       # key → (라벨프레임, Text)
        self._txt_host = ttk.Frame(self._edit_f)
        self._txt_host.pack(fill='x', padx=6)

        # 노드 전용 — 구절 담기
        self._verse_f = ttk.Frame(self._edit_f)
        vb = ttk.Frame(self._verse_f)
        vb.pack(fill='x', pady=(6, 2))
        tk.Label(vb, text=_t('MLE_VERSES', '담은 구절'),
                 font=('', 9, 'bold')).pack(side='left')
        self._b_vdel = tk.Button(vb, text=_t('MLE_V_DEL', '구절 지우기'), bd=1,
                                 padx=8, state='disabled',
                                 command=self._del_verse)
        self._b_vdel.pack(side='right')
        self._b_vdesc = tk.Button(vb, text=_t('MLE_V_DESC', '연결글 저장'),
                                  bd=1, padx=8, state='disabled',
                                  command=self._save_vdesc)
        self._b_vdesc.pack(side='right', padx=(0, 6))
        add = ttk.Frame(self._verse_f)
        add.pack(fill='x', pady=(0, 2))
        with appdb.connect(self.db) as conn:
            self._books = conn.execute(
                'SELECT bn.book_code, bn.full_name FROM book_names bn '
                'WHERE UPPER(bn.lang_code)=? AND bn.book_code IN '
                '(SELECT DISTINCT bcode FROM bible_index) '
                'ORDER BY bn.book_code',
                ((self._lang() or 'KO').upper(),)).fetchall()
        self._cb_b = ttk.Combobox(add, state='readonly', width=11,
                                  values=[b[1] for b in self._books])
        self._cb_b.pack(side='left', padx=(0, 2))
        self._cb_c = ttk.Combobox(add, state='readonly', width=4)
        self._cb_c.pack(side='left', padx=2)
        self._cb_v = ttk.Combobox(add, state='readonly', width=4)
        self._cb_v.pack(side='left', padx=2)
        tk.Label(add, text='~').pack(side='left')
        self._cb_v2 = ttk.Combobox(add, state='readonly', width=4)
        self._cb_v2.pack(side='left', padx=2)
        tk.Button(add, text=_t('MLE_V_ADD', '＋ 구절 담기'), bd=1, padx=8,
                  command=self._add_verse).pack(side='left', padx=(8, 0))
        self._cb_b.bind('<<ComboboxSelected>>', lambda _e: self._fill_bc(1))
        self._cb_c.bind('<<ComboboxSelected>>', lambda _e: self._fill_bc(2))

        self._vtv = ttk.Treeview(self._verse_f, columns=('ref', 'has'),
                                 show='headings', height=6,
                                 selectmode='browse')
        self._vtv.heading('ref', text=_t('MLE_C_REF', '참조'))
        self._vtv.heading('has', text=_t('MLE_C_HAS', '연결글'))
        self._vtv.column('ref', width=130, stretch=False)
        self._vtv.column('has', width=60, stretch=False, anchor='center')
        self._vtv.pack(fill='x', pady=(2, 2))
        self._vtv.bind('<<TreeviewSelect>>', lambda _e: self._on_vpick())
        self._vdesc = tk.Text(self._verse_f, height=3, wrap='word', bd=1)
        self._vdesc.pack(fill='x', pady=(0, 6))
        self._vrows = {}

    def _show_none(self):
        self._cur = None
        self._edit_f.pack_forget()
        self._none_lbl.pack(fill='x', padx=10, pady=10)

    def _on_pick(self):
        sel = self._sel()
        if not sel:
            self._show_none()
            return
        _t = i18n.t
        self._cur = (sel[0], sel[1])
        self._none_lbl.pack_forget()
        self._edit_f.pack(fill='both', expand=True)
        self._name_lbl.config(text=self._tv.item(sel[2], 'text'))
        # 글 구획 — 렌즈 = 설명 하나 / 노드 = 설명·질문·기도
        for w in self._txt_host.winfo_children():
            w.destroy()
        self._txts = {}
        secs = ((('desc', 'OE_S_CDESC', '렌즈 설명', 'CONT_DESC'),)
                if sel[0] == 'LENS' else
                tuple((k, i, d, tt) for k, i, d, tt in NODE_TT))
        with appdb.connect(self.db) as conn:
            for key, i18k, dflt, tt in secs:
                lf = ttk.Labelframe(self._txt_host, text=_t(i18k, dflt))
                lf.pack(fill='x', pady=(2, 2))
                txt = tk.Text(lf, height=3, wrap='word', bd=0)
                txt.pack(fill='x', padx=4, pady=2)
                txt.insert('1.0', get_text(conn, tt, sel[1], self._lang()))
                self._txts[key] = (tt, txt)
        if sel[0] == 'NODE':
            self._verse_f.pack(fill='both', expand=True)
            self._load_verses()
        else:
            self._verse_f.pack_forget()

    def _save_texts(self):
        if not self._cur:
            return
        with appdb.connect(self.db) as conn:
            for _key, (tt, txt) in self._txts.items():
                set_text(conn, tt, self._cur[1], self._lang(),
                         txt.get('1.0', 'end'))
        self._changed()

    # ── 구절 ────────────────────────────────────────────────────
    def _fill_bc(self, level):
        i = self._cb_b.current()
        if i < 0:
            return
        with appdb.connect(self.db) as conn:
            if level == 1:
                chs = [str(r[0]) for r in conn.execute(
                    'SELECT DISTINCT chapter FROM bible_index WHERE bcode=? '
                    'ORDER BY chapter', (self._books[i][0],))]
                self._cb_c.config(values=chs)
                if chs:
                    self._cb_c.current(0)
            if not self._cb_c.get():
                return
            vs = [str(r[0]) for r in conn.execute(
                'SELECT verse FROM bible_index WHERE bcode=? AND chapter=? '
                'ORDER BY verse', (self._books[i][0], int(self._cb_c.get())))]
        self._cb_v.config(values=vs)
        self._cb_v2.config(values=[''] + vs)
        if vs:
            self._cb_v.current(0)
        self._cb_v2.set('')

    def _vid_at(self, verse):
        i = self._cb_b.current()
        if i < 0 or not self._cb_c.get() or not verse:
            return None
        with appdb.connect(self.db) as conn:
            r = conn.execute(
                'SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? '
                'AND verse=?', (self._books[i][0], int(self._cb_c.get()),
                                int(verse))).fetchone()
        return r and r[0]

    def _add_verse(self):
        if not self._cur or self._cur[0] != 'NODE':
            return
        vid = self._vid_at(self._cb_v.get())
        if not vid:
            return
        end = self._vid_at(self._cb_v2.get()) if self._cb_v2.get() else None
        if end and end < vid:
            vid, end = end, vid
        with appdb.connect(self.db) as conn:
            lid, _how = add_verse(conn, self._cur[1], vid, end)
        self._load_verses(keep=lid)
        self.refresh(keep='N%d' % self._cur[1])
        self._changed()

    def _load_verses(self, keep=None):
        self._vtv.delete(*self._vtv.get_children())
        self._vrows = {}
        _t = i18n.t
        with appdb.connect(self.db) as conn:
            for lid, vid, end, lbl, has in verses_of(conn, self._cur[1],
                                                     self._lang()):
                iid = 'v%d' % lid
                self._vtv.insert('', 'end', iid=iid,
                                 values=(lbl, '◈' if has else ''))
                self._vrows[iid] = lid
        self._vdesc.delete('1.0', 'end')
        self._b_vdel.config(state='disabled')
        self._b_vdesc.config(state='disabled')
        if keep and self._vtv.exists('v%d' % keep):
            self._vtv.selection_set('v%d' % keep)

    def _on_vpick(self):
        s = self._vtv.selection()
        on = 'normal' if s else 'disabled'
        self._b_vdel.config(state=on)
        self._b_vdesc.config(state=on)
        self._vdesc.delete('1.0', 'end')
        if s:
            with appdb.connect(self.db) as conn:
                self._vdesc.insert('1.0', get_text(
                    conn, 'NODE_VERS_DESC', self._vrows[s[0]], self._lang()))

    def _save_vdesc(self):
        s = self._vtv.selection()
        if not s:
            return
        with appdb.connect(self.db) as conn:
            set_text(conn, 'NODE_VERS_DESC', self._vrows[s[0]], self._lang(),
                     self._vdesc.get('1.0', 'end'))
        self._load_verses(keep=self._vrows[s[0]])
        self._changed()

    def _del_verse(self):
        s = self._vtv.selection()
        if not s:
            return
        with appdb.connect(self.db) as conn:
            remove_verse(conn, self._vrows[s[0]])
        self._load_verses()
        self.refresh(keep='N%d' % self._cur[1])
        self._changed()

    def _changed(self):
        if callable(self._on_changed):
            try:
                self._on_changed()
            except Exception:
                pass


# ══════════════════════════════════════════════════════════════════
#  My Edit — 렌즈 창 (렌즈묵상 전용 · 2026-08-27 사용자 확정
#  「렌즈 관련된 것은 렌즈묵상 탭에서만 처리하자」)
#  탭 둘 = [렌즈 구성](LensBuildPanel — 내 렌즈 만들기) ·
#          [기본 렌즈 글](overlay_center._LensTab — sys 렌즈 덮개 E)
# ══════════════════════════════════════════════════════════════════
class _LensShim:
    """_LensTab 이 기대하는 center 표면 — db_path·lang·changed 만."""

    def __init__(self, db_path, lang_getter, on_changed):
        self.db_path = db_path
        self._lg = lang_getter
        self._cb = on_changed

    @property
    def lang(self):
        try:
            return self._lg() or 'KO'
        except Exception:
            return 'KO'

    def changed(self, kind):
        if callable(self._cb):
            try:
                self._cb(kind)
            except Exception:
                pass


class _StudioWin(tk.Toplevel):
    def __init__(self, root, db_path, lang_getter, on_changed):
        super().__init__(root)
        _t = i18n.t
        self.title(_t('MLE_STUDIO', 'My Edit — 렌즈'))
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        w0, h0 = min(980, sw - 120), min(720, sh - 160)
        self.geometry('%dx%d+%d+%d' % (w0, h0, (sw - w0) // 2,
                                       max(20, (sh - h0) // 2 - 20)))
        self.minsize(760, 520)
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill='both', expand=True, padx=8, pady=8)
        self.build = LensBuildPanel(
            self.nb, db_path, lang_getter,
            on_changed=lambda: _LensShim(db_path, lang_getter,
                                         on_changed).changed('LENS'))
        self.nb.add(self.build, text=' ' + _t('OC_T_BUILD', '렌즈 구성') + ' ')
        try:
            import overlay_center
            self._shim = _LensShim(db_path, lang_getter, on_changed)
            self.lens_tab = overlay_center._LensTab(self.nb, self._shim)
            self.nb.add(self.lens_tab,
                        text=' ' + _t('MLE_T_SYSTXT', '기본 렌즈 글') + ' ')
        except Exception as e:
            print('[lens studio] lens tab:', e)
            self.lens_tab = None
        try:
            import ui_theme
            ui_theme.adopt(self)
        except Exception:
            pass

    def show_anchor(self, anchor):
        """(kind, unit_id) — 기본 렌즈 글 탭을 그 앵커로 연다."""
        if self.lens_tab is None:
            return
        try:
            self.nb.select(1)
            self.lens_tab.set_lens_anchor(anchor)
        except Exception as e:
            print('[lens studio] anchor:', e)


def open_my_lens_studio(parent, db_path, lang_getter, anchor=None,
                        on_changed=None, select=None):
    """렌즈의 My Edit 창 — 싱글턴. anchor=(kind, id)면 덮개 글 탭으로.

    select=내 렌즈 번호면 「렌즈 구성」 탭에서 그 렌즈를 골라 둔다(2026-10-13 docs/1.txt 83 —
    가져온 렌즈를 곧바로 고치는 자리 · 노드 목록·추가·이름·삭제·구절·설명문이 다 여기 있다)."""
    root = parent.winfo_toplevel()
    win = getattr(root, '_my_lens_studio', None)
    if win is None or not _alive(win):
        win = _StudioWin(root, db_path, lang_getter, on_changed)
        root._my_lens_studio = win
    else:
        win.lift()
        win.focus_force()
    if anchor:
        win.show_anchor(anchor)
    else:
        keep = ('L%d' % int(select)) if select else None
        try:
            win.nb.select(0)
        except Exception:
            pass
        win.build.refresh(keep=keep)
        if keep:
            win.build._on_pick()
    return win


def _alive(w):
    try:
        return bool(w.winfo_exists())
    except Exception:
        return False


# ══════════════════════════════════════════════════════════════════
#  자가 검증 — 데이터 층 왕복 (실DB user 표만 · 잔재 0)
# ══════════════════════════════════════════════════════════════════
def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    conn = appdb.connect()
    n0 = tuple(conn.execute('SELECT '
                            '(SELECT COUNT(*) FROM userdb.user_unit_asset),'
                            '(SELECT COUNT(*) FROM userdb.user_link_asset),'
                            '(SELECT COUNT(*) FROM userdb.user_text_asset)'
                            ).fetchone())
    sys0 = conn.execute('SELECT COUNT(*) FROM sys_unit_asset').fetchone()[0]
    made = {'u': [], 'l': []}
    try:
        lid, nm = create_lens(conn, '검사 렌즈 MLE')
        made['u'].append(lid)
        t('렌즈 신설', bool(lid) and nm.startswith('검사 렌즈 MLE'), (lid, nm))
        t('목록에 나온다', any(l[0] == lid for l in my_lenses(conn)))
        nid, nnm = create_node(conn, lid, '검사 노드 MLE')
        made['u'].append(nid)
        t('노드 신설 + CONT_NODE', nodes_of(conn, lid)[0][0] == nid)
        vl, how = add_verse(conn, nid, 3, 7)
        made['l'].append(vl)
        t('구절 구간 담기', how == 'NEW'
          and verses_of(conn, nid)[0][2] == 7)
        _l2, how2 = add_verse(conn, nid, 3, 7)
        t('같은 구간 = DUP(멱등)', how2 == 'DUP' and _l2 == vl)
        set_text(conn, 'NODE_VERS_DESC', vl, 'KO', '구간을 대변하는 글')
        t('연결글 왕복', get_text(conn, 'NODE_VERS_DESC', vl, 'KO')
          == '구간을 대변하는 글'
          and verses_of(conn, nid)[0][4] is True)
        set_text(conn, 'NODE_DESC', nid, 'KO', '노드 관점')
        t('노드 글 왕복', get_text(conn, 'NODE_DESC', nid, 'KO') == '노드 관점')
        nm2 = rename_unit(conn, lid, '검사 렌즈 MLE 개명')
        t('개명(UNIQUE 존중)', nm2 and nm2.startswith('검사 렌즈 MLE 개명'))
        # ★ P1 렌즈묵상이 읽는 문법인가 — lens_share 내보내기로 왕복 증명
        import lens_share
        draft = lens_share.export_lens(conn, lid)
        t('★ LensView 문법 정합(내보내기 왕복)',
          draft['nodes'][0]['verses'][0]['ref'] != '' and
          (draft['nodes'][0].get('desc') or {}).get('KO') == '노드 관점',
          draft['nodes'][0]['verses'][:1])
        # 삭제 = cascade HIDE
        delete_lens(conn, lid)
        t('★ 삭제 = 숨김 — 목록에서 빠진다',
          all(l[0] != lid for l in my_lenses(conn)))
        t('   노드도 함께 숨는다', conn.execute(
            "SELECT record_status FROM userdb.user_unit_asset "
            'WHERE user_unit_id=?', (nid,)).fetchone()[0] == 'HIDE')
        t('   물리 행은 남는다(휴지통 회복용)', conn.execute(
            'SELECT COUNT(*) FROM userdb.user_unit_asset '
            'WHERE user_unit_id IN (?,?)', (lid, nid)).fetchone()[0] == 2)
    finally:
        # ⚠⚠ **link_type 을 한정해서 지운다** (2026-08-27 사고 — 처음에
        #   `clicked_id=? OR target_id=?` 로 전 유형을 지워, 시험 유닛 번호와
        #   우연히 같은 번호를 가진 **다른 유형의 실데이터 3행(UREF_VERS)**
        #   이 함께 지워졌다. 감사 로그(§10-1)로 같은 PK 복원 — 실전 세 번째.
        #   번호는 유형이 다르면 **다른 자산**이다).
        for lid2 in made['l']:
            conn.execute("DELETE FROM userdb.user_text_asset "
                         "WHERE text_type='NODE_VERS_DESC' AND clicked_id=?",
                         (lid2,))
        for uid in made['u']:
            conn.execute('DELETE FROM userdb.user_text_asset '
                         'WHERE clicked_id=? AND text_type IN '
                         "('CONT_DESC','NODE_DESC','NODE_QUESTION',"
                         "'NODE_PRAYER')", (uid,))
            conn.execute("DELETE FROM userdb.user_link_asset "
                         "WHERE link_type IN ('CONT_NODE','NODE_VERS') "
                         'AND (clicked_id=? OR '
                         "     (link_type='CONT_NODE' AND target_id=?))",
                         (uid, uid))
            conn.execute('DELETE FROM userdb.user_unit_asset '
                         'WHERE user_unit_id=?', (uid,))
        conn.commit()
        n1 = tuple(conn.execute('SELECT '
                                '(SELECT COUNT(*) FROM userdb.user_unit_asset),'
                                '(SELECT COUNT(*) FROM userdb.user_link_asset),'
                                '(SELECT COUNT(*) FROM userdb.user_text_asset)'
                                ).fetchone())
        sys1 = conn.execute('SELECT COUNT(*) FROM sys_unit_asset').fetchone()[0]
        t('잔재 0 %s→%s' % (n0, n1), n0 == n1)
        t('배포 DB 불변', sys0 == sys1)
        conn.close()
    print('my_lens_edit selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)
