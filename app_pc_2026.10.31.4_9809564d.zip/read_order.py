# -*- coding: utf-8 -*-
"""read_order.py — **읽을 차례**(top 10) 단일 소스 (2026-08-31 사용자 확정).

★★★ 왜 (사용자) — 「우선순위는 **top 10 이면 충분**하다. 이것 읽고 나서 또는
  읽는 중간에 재조정하면 된다. **top100 정해봐야 의미없다**」.
  ⇒ 전 목록에 번호를 매기지 않는다. **올린 것만** 차례가 있고 나머지는 없다.

★★ **♥(담아두기)와 다른 축이다.** ♥ 는 「이 책을 담아 둔다」이고 차례는
  「먼저 읽는다」다. 한 표에 넣으면 담기만 해도 차례가 생겨 담아두기가 오염된다.
  ⇒ 저장은 **제 열쇠**(`user_config['READING_ORDER']`).

★★ **도서와 설교를 가른다** (사용자 「도서/설교를 구분해야 하며」) —
  `{"BOOK": [book_id…], "SERMON": [book_id…]}`.
  ⚠ 알갱이는 **책**이다. 설교 서재는 3,573**편**을 늘어놓지만 설교집은 5권뿐이라
    편에 차례를 매기는 것은 불가능하다(위/아래로 3,573줄을 못 옮긴다).

★★ **다 읽으면 차례에서 사라진다** (사용자 「읽기 완료 후에는 우선순위에서
  사라져야 한다」). 두 길을 다 연다:
  · ⓐ **전편 읽음** — 저절로 빠진다
  · ⓑ **[읽음] 표시** — 도중에 그만두어도 손으로 뺀다(`READING_DONE`)
  ⚠ 지우지 않고 **거른다** — 다시 읽고 싶어지면 되살릴 수 있어야 한다.

⚠ **받았는지(`has_text`)로 거르지 않는다** (사용자 「다운로드 받지 않은 것도
  읽기 순서 조정 대상에 포함되어야 한다」). 팩이 생기는 날 표식만 켜면 된다.

`--selftest` 의무.
"""
import json

import appdb

ORDER_KEY = 'READING_ORDER'
DONE_KEY = 'READING_DONE'
TOP_N = 10                      # 화면에 보이는 차례 (사용자 확정)
KINDS = ('BOOK', 'SERMON')


# ── 저장소 ────────────────────────────────────────────────────────────────
def _get(conn, key, dflt):
    try:
        r = conn.execute("SELECT config_val FROM user_config WHERE config_key=?",
                         (key,)).fetchone()
        if r and r[0]:
            return json.loads(r[0])
    except Exception:
        pass
    return dflt


def _put(conn, key, val):
    s = json.dumps(val, ensure_ascii=False)
    conn.execute(
        "INSERT INTO user_config (config_key, config_val) VALUES (?,?) "
        "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
        (key, s))
    conn.commit()


def order(conn, kind='BOOK'):
    """그 갈래의 차례 → `[book_id, …]` (올린 것만)."""
    d = _get(conn, ORDER_KEY, {})
    v = d.get(str(kind).upper()) if isinstance(d, dict) else None
    return [int(x) for x in v] if isinstance(v, list) else []


def set_order(conn, kind, ids):
    d = _get(conn, ORDER_KEY, {})
    if not isinstance(d, dict):
        d = {}
    # ⚠ 겹침을 지운다 — 위/아래로 옮기다 같은 번호가 두 번 들어가면 차례가 깨진다
    seen, out = set(), []
    for x in ids:
        try:
            i = int(x)
        except (TypeError, ValueError):
            continue
        if i not in seen:
            seen.add(i)
            out.append(i)
    d[str(kind).upper()] = out
    _put(conn, ORDER_KEY, d)
    return out


def done_ids(conn):
    """손으로 「읽음」 표시한 책 → set."""
    v = _get(conn, DONE_KEY, [])
    return {int(x) for x in v} if isinstance(v, list) else set()


def set_done(conn, book_id, on=True):
    s = done_ids(conn)
    s.discard(int(book_id)) if not on else s.add(int(book_id))
    _put(conn, DONE_KEY, sorted(s))
    return s


# ── 차례 다루기 ───────────────────────────────────────────────────────────
def add(conn, kind, book_id):
    """차례 **맨 뒤**에 담는다(멱등). 이미 있으면 자리를 안 옮긴다.

    ⚠ 맨 앞이 아니다 — 새로 담을 때마다 앞으로 끼어들면 애써 정한 차례가
      매번 뒤집힌다(§97차 `push_recent` 와 같은 판단).
    """
    ids = order(conn, kind)
    if int(book_id) not in ids:
        ids.append(int(book_id))
        set_order(conn, kind, ids)
    return ids


def remove(conn, kind, book_id):
    ids = [i for i in order(conn, kind) if i != int(book_id)]
    return set_order(conn, kind, ids)


def move(conn, kind, book_id, delta):
    """▲(-1) ▼(+1) 한 칸. 끝에서는 아무 일도 안 한다."""
    ids = order(conn, kind)
    try:
        i = ids.index(int(book_id))
    except ValueError:
        return ids
    j = i + int(delta)
    if 0 <= j < len(ids):
        ids[i], ids[j] = ids[j], ids[i]
        return set_order(conn, kind, ids)
    return ids


def move_many(conn, kind, ids, delta):
    """여러 개를 **묶음으로** 한 칸 — 순환하지 않는다.

    ⚠⚠ 하나씩 `move` 를 돌리면 **맨 위 것이 못 올라가는 사이 아래 것들이 올라와**
      차례가 순환한다(실측 `[756,1339,3211]` 에 ▲ → `1339,3211,756`).
      묶음의 끝이 벽에 닿으면 **아무것도 안 움직이는** 것이 맞다.
    """
    seq = order(conn, kind)
    pos = sorted(i for i, x in enumerate(seq) if x in set(int(v) for v in ids))
    if not pos:
        return seq
    if delta < 0 and pos[0] == 0:
        return seq
    if delta > 0 and pos[-1] == len(seq) - 1:
        return seq
    for i in (pos if delta < 0 else reversed(pos)):
        j = i + delta
        seq[i], seq[j] = seq[j], seq[i]
    return set_order(conn, kind, seq)


def rank_map(conn, kind, finished=()):
    """`{book_id: 순위(1부터)}` — **다 읽은 것은 빼고** 다시 매긴다.

    ⚠ 번호를 저장하지 않는다 — 저장하면 하나를 빼는 순간 전부 고쳐야 한다.
      차례는 **목록의 순서**이고 번호는 그때그때 센다.
    """
    fin = set(finished) | done_ids(conn)
    out, n = {}, 0
    for b in order(conn, kind):
        if b in fin:
            continue
        n += 1
        out[b] = n
    return out


def top(conn, kind, finished=(), n=TOP_N):
    """화면에 보일 차례 → `[(순위, book_id), …]` 최대 n개."""
    rm = rank_map(conn, kind, finished)
    return [(r, b) for b, r in sorted(rm.items(), key=lambda x: x[1])][:n]


def sort_key(conn, kind, finished=()):
    """서재 정렬용 — 차례에 있는 것 먼저, 없는 것은 뒤에 원래 차례로."""
    rm = rank_map(conn, kind, finished)

    def key(book_id):
        return (0, rm[book_id]) if book_id in rm else (1, 0)
    return key


# ── 자가 검증 ─────────────────────────────────────────────────────────────
def selftest(db_path='bible_master.db'):
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %-4s %s %s' % ('OK' if cond else 'FAIL', name, extra))

    conn = appdb.connect(db_path)
    keep_o = _get(conn, ORDER_KEY, None)
    keep_d = _get(conn, DONE_KEY, None)
    try:
        set_order(conn, 'BOOK', [])
        _put(conn, DONE_KEY, [])
        t('빈 차례', order(conn, 'BOOK') == [])
        add(conn, 'BOOK', 7)
        add(conn, 'BOOK', 8)
        add(conn, 'BOOK', 9)
        t('맨 뒤에 담긴다', order(conn, 'BOOK') == [7, 8, 9], order(conn, 'BOOK'))
        add(conn, 'BOOK', 7)
        t('★ 다시 담아도 자리가 안 바뀐다', order(conn, 'BOOK') == [7, 8, 9])
        move(conn, 'BOOK', 9, -1)
        t('▲ 한 칸', order(conn, 'BOOK') == [7, 9, 8], order(conn, 'BOOK'))
        move(conn, 'BOOK', 7, -1)
        t('★ 맨 위에서 ▲ 는 아무 일도 안 한다', order(conn, 'BOOK') == [7, 9, 8])
        move(conn, 'BOOK', 8, +1)
        t('★ 맨 아래에서 ▼ 도 마찬가지', order(conn, 'BOOK') == [7, 9, 8])
        t('순위는 1부터', rank_map(conn, 'BOOK') == {7: 1, 9: 2, 8: 3},
          rank_map(conn, 'BOOK'))
        t('★ 전편 읽음은 빠지고 **번호가 다시 매겨진다**',
          rank_map(conn, 'BOOK', finished={7}) == {9: 1, 8: 2},
          rank_map(conn, 'BOOK', finished={7}))
        set_done(conn, 9, True)
        t('★ 손으로 표시한 것도 빠진다',
          rank_map(conn, 'BOOK') == {7: 1, 8: 2}, rank_map(conn, 'BOOK'))
        set_done(conn, 9, False)
        t('★ 되살아난다', 9 in rank_map(conn, 'BOOK'))
        t('★ 지운 것이 아니다 — 차례에 그대로', order(conn, 'BOOK') == [7, 9, 8])
        set_order(conn, 'BOOK', [7, 7, 8])
        t('★ 겹침을 지운다', order(conn, 'BOOK') == [7, 8], order(conn, 'BOOK'))
        set_order(conn, 'SERMON', [3])
        t('★ 갈래가 섞이지 않는다',
          order(conn, 'BOOK') == [7, 8] and order(conn, 'SERMON') == [3])
        set_order(conn, 'BOOK', list(range(1, 30)))
        t('★ top 은 %d개까지' % TOP_N, len(top(conn, 'BOOK')) == TOP_N,
          len(top(conn, 'BOOK')))
        k = sort_key(conn, 'BOOK')
        t('★ 차례에 없는 것은 뒤로', k(1) < k(999))
        remove(conn, 'BOOK', 1)
        t('빼기', 1 not in order(conn, 'BOOK'))
        set_order(conn, 'BOOK', [7, 8, 9, 10])
        move_many(conn, 'BOOK', [7, 8, 9], -1)
        t('★ 묶음이 벽에 닿으면 **아무것도 안 움직인다**',
          order(conn, 'BOOK') == [7, 8, 9, 10], order(conn, 'BOOK'))
        move_many(conn, 'BOOK', [8, 9], -1)
        t('★ 묶음이 통째로 한 칸', order(conn, 'BOOK') == [8, 9, 7, 10],
          order(conn, 'BOOK'))
        move_many(conn, 'BOOK', [8, 9], +1)
        t('★ 되돌아온다', order(conn, 'BOOK') == [7, 8, 9, 10],
          order(conn, 'BOOK'))
        move_many(conn, 'BOOK', [9, 10], +1)
        t('★ 아래 벽에서도 안 움직인다', order(conn, 'BOOK') == [7, 8, 9, 10])
    finally:
        if keep_o is None:
            conn.execute("DELETE FROM user_config WHERE config_key=?",
                         (ORDER_KEY,))
        else:
            _put(conn, ORDER_KEY, keep_o)
        if keep_d is None:
            conn.execute("DELETE FROM user_config WHERE config_key=?",
                         (DONE_KEY,))
        else:
            _put(conn, DONE_KEY, keep_d)
        conn.commit()
        left = conn.execute(
            "SELECT COUNT(*) FROM user_config WHERE config_key IN (?,?)",
            (ORDER_KEY, DONE_KEY)).fetchone()[0]
        t('★ 시험 잔재 0', left == (0 if keep_o is None else 1) +
          (0 if keep_d is None else 1), left)
        conn.close()
    print('read_order selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print(__doc__)
