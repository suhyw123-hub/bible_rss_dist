# -*- coding: utf-8 -*-
"""db_gird_import.py — Girdlestone 『Synonyms of the Old Testament』 적재 (영구).

2026-09-02 (179차) 사용자 지시 「Girdlestone 적재 진행하라」.
0.txt 2번 — 「용어를 분석한 자료 … 용어 단위로 구분할 수 있다면 도서/설교집과
같이 유닛 단위로 분할하여 용어와 연결하면 된다. 용어와 연결되면 결국 구절과도
간접연결된다」.

판본 결정 (실측 비교 4본):
  · **1897 제2판(저자 최종 개정판)을 정본으로** — IA `oldtestamentsyno0000gird`
    (2022 스캔 · OCR 이 1871 구글 스캔들보다 깨끗: 'Cbatta' 오독 0).
  · 1871 초판 스캔 3본은 **대조본**(같은 책인가의 진위 검증 — §98차 방식:
    문턱을 낮추지 않고 대조군을 함께 잰다. 판이 달라 80% 게이트는 성립하지
    않으므로 음성 대조군(다른 책 Trench)과 함께 수치로 판정하고 기록한다).
  · 판권: 1897 발행 = PD (1930 이전). 표제면 실물 확인(규칙 ③) 완료.
  · 1948 재인쇄 스캔은 대출 제한(172바이트)이라 대조본이 못 된다(§0-1b).

유닛 = 장(CHAPTER) 안의 절(§) — 실측 § 표지가 OCR 로 상해 있다:
  · `$7.` (§→$ 오독) · `§ 8.]` (쪽머리 잔재 — ] 가 서명) · `§ 2)` (본문 안
    참조 — ) 가 서명) ⇒ 파서가 세 꼴을 가른다.
  · 일부 절 표지는 OCR 이 아예 삼켰다(6장 §4·§5) — 그 절은 앞 유닛에 합쳐진다.
    **지어내지 않는다** — 없는 표지를 손으로 만들어 넣지 않는다.

용어 연결 = 음역 낱말 실측 매칭 (낱말 경계 정규식 · 유닛당 3회 이상) +
6장(SIN)은 죄 의미장(F_SIN)에 전 유닛 연결. 저장은 `link_picker.add`
(scope='SYS' · verify) — 없는 자산을 거부하는 문이 거기 있다(§97차).

사용:
  python db_gird_import.py --selftest    (의무)
  python db_gird_import.py --check       (파싱·대조·연결 미리보기 — 쓰지 않음)
  python db_gird_import.py --apply       (멱등 — 지우고 다시 넣는다)
  python db_gird_import.py --status
"""
import io
import os
import re
import sys

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

NL = chr(10)
HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, '_lexicon_raw')
TODAY = '2026-09-02'                    # 받은 날 (§0-1b 기록)

CODE = 'GIRDLESTONE_OTS'
TITLE = 'Synonyms of the Old Testament'
AUTHOR = 'Robert Baker Girdlestone'
YEAR = 1897
CATEGORY = 'DOCTRINE'
PRIMARY = ('IA oldtestamentsyno0000gird (Longmans 2nd ed. 1897)',
           'https://archive.org/details/oldtestamentsyno0000gird')
CROSSES = [('gird1871.txt', 'IA synonymsofoldtes00gird (1871 1st ed.)',
            'https://archive.org/details/synonymsofoldtes00gird'),
           ('gird1871b.txt', 'IA synonymsoldtest00girdgoog (1871 1st ed.)',
            'https://archive.org/details/synonymsoldtest00girdgoog')]
NEGATIVE = 'tren1863.txt'               # 음성 대조군 — 다른 책(Trench)

DESC = NL.join([
    '히브리어 낱말들이 같은 우리말로 뭉뚱그려 옮겨질 때 잃어버리는 결을 되찾아 주는 책입니다. 죄를 뜻하는 여러 낱말, 은혜와 긍휼과 사랑, 속량과 구원처럼 비슷해 보이는 말들이 원어에서 어떻게 다른지를 장마다 하나의 주제로 묶어 살핍니다.',
    '지은이 로버트 베이커 거들스톤(1836~1923)은 성공회 사제이자 옥스퍼드 위클리프 홀의 초대 학장이었고, 영어 개역(RV) 구약 번역에 참여했습니다. 이 책은 1871년 초판 이후 1897년에 저자가 고쳐 낸 제2판이 표준이 되었습니다.',
    '각 장은 한 주제의 낱말 가족을 다룹니다. 하나님의 이름들, 사람과 영혼, 죄의 낱말들, 회개, 의와 믿음, 은혜와 사랑, 속량과 구원, 속죄와 용서, 말씀과 율법과 언약 같은 차례입니다. 이 앱의 주요용어 항목들과 장 단위로 이어져 있어, 용어를 읽다가 그 낱말을 다룬 장으로 건너갈 수 있습니다.',
    '▸ 출처: Internet Archive 스캔본(제2판, Longmans, Green, and Co., 1897). 저작권이 만료된 퍼블릭 도메인 저작입니다. 기계 판독(OCR) 원문이라 드물게 글자가 상한 자리가 있습니다.'])

# ──────────────────────────────────────────────────────────────────────
# 용어 연결 초안 — **유닛(장·절)마다 사람이 판정한 명시 지도** (2026-09-02
# 180차 사용자 확정 — 「유닛마다 용어와 연결하는 작업을 지금 진행하자 …
# 스트롱코드가 제대로 용어에 편입/연결되었다는 전제조건 하에서」).
# · 열쇠 = (장 로마숫자, 절 번호) — **순번이 아니다**. 분할을 바로잡아
#   순번이 밀려도 연결이 안 어긋난다. 절 0 = 장 머리 유닛.
# · 판정 절차: 유닛이 다루는 낱말(제목+본문 음역 실측) → 마스터로 스트롱
#   확정 → 우리 용어 보유 여부. **보유하지 않은 낱말은 잇지 않고**
#   용어명부 후보 목록에 남긴다(억지 연결 금지).
# · 옛 키워드 자동 매칭은 이 지도로 대체 — basar 가 육체(H1320)가 아니라
#   「좋은 소식을 전하다」(H1319·복음)인 XVIII§5 를 오연결한 것을 검거하고
#   폐지했다(문자열로 못 세고 사람이 봐야 한다 — §155차).
LINKS_DRAFT = {
    # II장 하나님의 이름들 — 이름 가족 등록(181차) 뒤 이름별 정밀 연결.
    # 장 전체 = 교리(하나님의 속성) + 관문(이름 가족), 절별 = 그 이름.
    ('II', 0): ['D_DIVINE_ATTRIBUTES', 'F_DIVINE_NAMES'],
    ('II', 1): ['D_DIVINE_ATTRIBUTES', 'T_ELOHIM'],
    ('II', 2): ['D_DIVINE_ATTRIBUTES', 'D_TRINITY', 'T_ELOHIM'],
    ('II', 3): ['D_DIVINE_ATTRIBUTES', 'T_ELOHIM'],
    ('II', 4): ['D_DIVINE_ATTRIBUTES', 'T_ELOHIM'],
    ('II', 5): ['D_DIVINE_ATTRIBUTES', 'T_ELOHIM'],
    ('II', 6): ['D_DIVINE_ATTRIBUTES', 'T_EL'],
    ('II', 7): ['D_DIVINE_ATTRIBUTES', 'T_SHADDAI'],
    ('II', 8): ['D_DIVINE_ATTRIBUTES', 'T_ADONAI'],
    ('II', 9): ['D_DIVINE_ATTRIBUTES', 'T_ELYON'],
    ('II', 10): ['D_DIVINE_ATTRIBUTES', 'T_YHWH'],
    ('II', 11): ['D_DIVINE_ATTRIBUTES', 'T_TSEVAOT', 'T_YHWH'],
    ('II', 12): ['D_DIVINE_ATTRIBUTES', 'T_YHWH'],
    ('II', 13): ['D_DIVINE_ATTRIBUTES', 'T_YHWH'],
    # III장 사람의 이름들 — 전수 등록(W_) 낱말
    # III장 「The Names of Man」 — §1(아담) 표지는 OCR 이 삼켜 장 머리
    # 유닛(§0)에 합쳐져 있다(179차 「지어내지 않는다」 규칙의 귀결).
    ('III', 0): ['F_MAN', 'T_ADAM'],
    ('III', 2): ['F_MAN', 'T_ISH'],
    ('III', 3): ['F_MAN', 'T_ENOSH'],
    ('III', 4): ['F_MAN', 'T_GEBER'],
    # IV장 영혼·영
    ('IV', 0): ['T_NEPHESH', 'T_RUACH'],
    ('IV', 1): ['T_NEPHESH'],
    ('IV', 2): ['T_RUACH'],
    ('IV', 3): ['T_RUACH'],
    ('IV', 4): ['T_RUACH'],
    # V장 마음
    ('V', 0): ['T_LEV'],
    ('V', 1): ['T_LEV'],
    ('V', 2): ['T_LEV'],                 # hardening of the heart
    ('V', 5): ['W_G4893'],               # conscience
    # VI장 죄 — 의미장 + 절별 낱말 (실측: §1 chatha · §2 avah · §7 pasha ·
    #   §9 breach of trust=마알 · §11 asham. §3 아말·§6 라아·§8 라샤·§10 아웬
    #   은 미등록 — 「악」 의미장 후보)
    ('VI', 0): ['F_SIN'],
    ('VI', 1): ['F_SIN', 'T_CHATAT'],
    ('VI', 2): ['F_SIN', 'T_AVON'],
    ('VI', 3): ['F_SIN', 'T_AMAL'],
    ('VI', 5): ['F_SIN', 'W_H5674'],
    ('VI', 6): ['F_SIN', 'T_RAAH'],
    ('VI', 7): ['F_SIN', 'T_PESHA'],
    ('VI', 8): ['F_SIN', 'T_RASHA'],
    ('VI', 9): ['F_SIN', 'T_MAAL'],
    ('VI', 10): ['F_SIN', 'T_AVEN'],
    ('VI', 11): ['F_SIN', 'SYS_GUILT_OFFERING'],
    ('VI', 12): ['F_SIN', 'T_CHATAT'],   # NT words for sin (hamartia 계열)
    # VII장 회개·위로
    ('VII', 0): ['T_NACHAM', 'T_SHUV'],
    ('VII', 1): ['T_NACHAM'],
    ('VII', 2): ['T_NACHAM'],            # comfort — 나함의 위로 쪽
    ('VII', 3): ['T_SHUV'],              # conversion — shub
    # VIII장 온전
    ('VIII', 2): ['T_SHALOM'],           # the word shalam
    ('VIII', 3): ['T_TAMIM'],            # 온전(타밈 H8549 — 189차 승격. 옛 W_H8552(타맘 동사)는 음역 매칭의 어긋남이었다)
    # IX장 의·믿음·소망
    ('IX', 1): ['T_YASHAR'],             # uprightness
    ('IX', 2): ['T_TSEDEQ'],
    ('IX', 3): ['T_MISHPAT'],
    ('IX', 4): ['T_EMET'],
    ('IX', 5): ['T_BATACH', 'D_FAITH'],  # trust — batach·emunah
    ('IX', 6): ['W_H8615'],              # hope
    ('IX', 7): ['D_FAITH'],
    # X장 은혜·긍휼·사랑 (racham §2 는 미등록 후보)
    ('X', 1): ['D_GRACE'],
    ('X', 2): ['T_RACHAM'],              # pity
    ('X', 3): ['T_AHAV'],
    ('X', 4): ['T_HESED'],               # mercy — chasad 실측 7회
    # XI장 속량·구원 (§8 은 §3 의 OCR 오독 — SEC_NUM_FIX)
    ('XI', 0): ['T_GAAL', 'T_PADAH'],
    ('XI', 1): ['T_GAAL', 'T_PADAH'],
    ('XI', 2): ['T_GAAL', 'T_PADAH'],
    ('XI', 3): ['D_SALVATION'],
    # XII장 대속·용서 (salach 실측 = §2)
    ('XII', 0): ['D_ATONEMENT'],
    ('XII', 1): ['D_ATONEMENT'],
    ('XII', 2): ['D_ATONEMENT', 'T_SALACH'],
    ('XII', 4): ['D_ATONEMENT'],         # sin bearing
    ('XII', 5): ['W_H7521'],             # acceptance
    # XIII장 정결·세례
    ('XIII', 1): ['T_TAHER'],
    ('XIII', 6): ['D_BAPTISM'],
    # XIV장 칭의
    ('XIV', 1): ['D_JUSTIFICATION'],
    ('XIV', 2): ['D_JUSTIFICATION', 'T_TSEDEQ'],
    ('XIV', 3): ['D_JUSTIFICATION'],
    ('XIV', 4): ['D_JUSTIFICATION'],
    ('XIV', 5): ['D_JUSTIFICATION'],     # imputation
    # XV장 성화
    ('XV', 1): ['D_SANCTIFICATION', 'T_KADOSH'],
    ('XV', 2): ['D_SANCTIFICATION', 'T_KADOSH'],
    ('XV', 3): ['W_H4886'],              # anointing
    # XVI장 제사 — 5대 제사·유월절·분향단 (169차 제도 엔티티)
    ('XVI', 1): ['W_H7133'],             # korban
    ('XVI', 3): ['SYS_BURNT_OFFERING'],
    ('XVI', 4): ['SYS_GRAIN_OFFERING'],
    ('XVI', 9): ['W_H2076'],             # to slay
    ('XVI', 10): ['FEAST_PASSOVER'],
    ('XVI', 11): ['SYS_PEACE_OFFERING'],
    ('XVI', 12): ['SYS_SIN_OFFERING'],
    ('XVI', 13): ['SYS_GUILT_OFFERING'],
    ('XVI', 16): ['OBJ_INCENSE_ALTAR'],
    # XVII장 말씀·율법·언약 (berith 실측 = §6)
    ('XVII', 1): ['T_DAVAR'],
    ('XVII', 2): ['T_TORAH'],
    ('XVII', 3): ['T_MITSVAH'],          # commandment
    ('XVII', 6): ['D_COVENANT'],
    # XVIII장 예배·찬송·전파 — §5 는 basar(H1319 좋은 소식) = 복음
    ('XVIII', 1): ['W_H7812'],           # worship
    ('XVIII', 3): ['T_TEFILLAH'],
    ('XVIII', 4): ['T_BARAK', 'T_TODAH', 'W_H1984'],
    ('XVIII', 5): ['T_EUANGELION'],
    # XIX장 성전·성막·회중
    ('XIX', 1): ['OBJ_TEMPLE'],
    ('XIX', 2): ['OBJ_TABERNACLE'],
    ('XIX', 3): ['D_CHURCH'],            # congregation — kahal
    ('XIX', 6): ['D_CHURCH'],            # the ecclesia
    # XX장 선지자·제사장
    ('XX', 4): ['SYS_HIGH_PRIESTHOOD'],
    # XXI장 왕·재판
    ('XXI', 2): ['T_MISHPAT'],
    ('XXI', 3): ['T_MISHPAT'],
    ('XXI', 4): ['W_H5358'],             # vengeance
    # XXII장 민족·백성
    ('XXII', 1): ['W_H1471'],
    # XXIII장 하늘
    ('XXIII', 4): ['D_HEAVEN'],
    # XXIV장 멸망·죽음·지옥
    ('XXIV', 7): ['T_SHEOL'],            # sheol — 186차 죽음 가족으로 승격
    ('XXIV', 8): ['D_HELL'],             # gehenna
    # XXV장 사탄·시험 (181차 P_SATAN 등록)
    ('XXV', 0): ['P_SATAN'],
    ('XXV', 1): ['P_SATAN'],
    ('XXV', 2): ['W_H5254'],             # temptation
    # XXVII장 우상
    ('XXVII', 7): ['IDL_TERAPHIM'],
    # XXVIII장 영원
    ('XXVIII', 2): ['T_AION'],
    ('XXVIII', 3): ['T_AION'],
}
# 절 번호 OCR 오독 교정 — 자리 증거로만 (XI 은 §1·2 다음이라 3 이 맞다)
SEC_NUM_FIX = {('XI', 8): 3}

# (참고) 옛 키워드 자동 매칭 — LINKS_DRAFT 로 대체되어 잇기에는 안 쓴다.
MIN_HITS = 3
KEYMAP = {
    'T_CHATAT':   r"chatt?a",
    'T_AVON':     r"avon\b",
    'T_PESHA':    r"pasha\b|pasha'",
    'T_MAAL':     r"ma'?al\b",
    'T_SHUV':     r"shub\b",
    'T_NACHAM':   r"nacham\b",
    'T_HESED':    r"chesed\b",
    'T_TSEDEQ':   r"tsedek\b|zedek\b",
    'T_GAAL':     r"ga'?al\b",
    'T_PADAH':    r"padah\b",
    'T_KADOSH':   r"kodesh\b|kadosh\b",
    'T_KAVOD':    r"[ck]abod\b",
    'T_NEPHESH':  r"nephesh\b",
    'T_RUACH':    r"ruach\b",
    'T_TORAH':    r"torah\b",
    'T_DAVAR':    r"dabar\b",
    'T_SHALOM':   r"shalom\b",
    'T_BASAR':    r"basar\b",
    'T_OR':       r"\bor\b \(light\)|\baor\b",
    'T_AION':     r"olam\b",
    'T_EMET':     r"emeth\b",
    'T_BATACH':   r"batach\b",
    'T_YARE':     r"yare\b|yirah\b",
    'T_ZAKAR':    r"zakar\b",
    'T_SHAMA':    r"shama\b",
    'T_NEPHESH2': None,   # 자리 지킴 — 쓰지 않음
    'D_COVENANT': r"berith\b",
    'D_GRACE':    r"\bchen\b",
    'D_FAITH':    r"emunah\b",
    'D_SALVATION': r"yasha\b",
}
SIN_CH = 'VI'                     # 6장 = SIN → 죄 의미장 전 유닛 연결
SIN_FIELD = 'F_SIN'
# 6장 절→용어 손 지도 (2026-09-02 실측 — 키워드가 OCR 표기·문턱에 걸려
# 못 잡은 것을 절 제목·본문 실측으로 확정: §1 chatha ×3 · §2 avah ·
# §7 pasha ×2 · §9 Breach of Trust = 마알 · §11 asham ×9 = 속건제 낱말).
# §3 Travail(아말)·§6 Evil(라아)·§8 Wickedness(라샤)·§10 Vanity(아웬)는
# 미등록 낱말이라 잇지 않는다 — 「악」 의미장 후보(용어명부 검토목록).
SIN_SECTIONS = {1: 'T_CHATAT', 2: 'T_AVON', 7: 'T_PESHA', 9: 'T_MAAL',
                11: 'SYS_GUILT_OFFERING', 12: 'T_CHATAT'}

_ROMAN = r'[IVXL]+'

# 제목 OCR 오독 — 전 라벨 전수 훑기로 확정한 것만 (2026-09-02 재점검.
# R→L·H→I 혼동이 규칙적이다). 본문은 안 고친다 — 원문 존중, 제목은 이정표라
# 읽혀야 한다.
TITLE_FIX = {
    'Lepentance': 'Repentance', 'Lighteousness': 'Righteousness',
    'Itighteousness': 'Righteousness', 'Itelation': 'Relation',
    'Ioly': 'Holy', 'Ihades': 'Hades', 'Ldols': 'Idols',
    'Llessing': 'Blessing', 'Leclesia': 'Ecclesia',
    'Ieave-Offering': 'Heave-Offering', 'Trausgression': 'Transgression',
    'Vunity': 'Vanity', 'Fire-Ofering': 'Fire-Offering', 'Greck': 'Greek',
    'Lhe': 'The', 'Etoum': 'Elohim', 'Elouim': 'Elohim', 'Exouim': 'Elohim',
    'Yechnical': 'Technical', 'Ofjering': 'Offering',
    'Witcheraft': 'Witchcraft', 'Aings': 'Kings', 'Tulers': 'Rulers',
    'Odjects': 'Objects', 'Teruphim': 'Teraphim', 'Zo': 'To',
}


def _label_title(s):
    """라벨용 제목 다듬기 — Title Case + 오독 교정 + N.T. 표기.

    ⚠ `str.title()` 은 아포스트로피 뒤를 대문자로 만든다(Lord’S) — 되돌린다."""
    t = s.title()
    t = re.sub(r"([’'])([A-Z])", lambda m: m.group(1) + m.group(2).lower(), t)
    t = (t.replace('N. 7.', 'N.T.').replace('Nv. 7.', 'N.T.')
         .replace('N. 7’', 'N.T.').replace('N. 7', 'N.T.'))
    for a, b in TITLE_FIX.items():
        t = re.sub(r'\b' + a + r'\b', b, t)
    return t


# ──────────────────────────────────────────────────────────────────────
def _clean_lines(seg):
    """쪽머리·쪽번호·잡줄 제거 + 하드랩 펴기 (빈 줄 = 문단 · 홑 NL 문단)."""
    out = []
    for ln in seg.split(NL):
        s = ln.strip()
        if re.fullmatch(r'\d+', s):
            continue                          # 쪽번호
        # 달리는 머리(왼쪽 면) — 「80 Old 'Testament Synonyms (Cur. VI.」 처럼
        # OCR 이 대소문자·따옴표를 섞는다(2026-09-02 실측) — 퍼지로 잡는다.
        if re.search(r"testament\s+s[a-z]{6,9}", s.lower()) and len(s) < 60:
            continue
        if re.match(r'^(CH|CHAP)\.\s*' + _ROMAN, s) and ']' in s:
            continue                          # 쪽머리 「CH. VI.] …」
        if re.match(r'^[§$]\s*\d+\s*\.?[\])]', s):
            continue                          # 쪽머리 「§ 8.] …」·「$11.) …」
        # 달리는 머리(오른쪽 면) — 「§ 5. The Host of Heaven 267」(제목+쪽번호).
        # 진짜 절 표지는 끝에 쪽번호가 없다 — _sections 의 거부 규칙과 짝.
        if re.match(r'^[§$]?\s*\d*\s*\.?\s*[A-Z][\w .,\'’\-]{0,50}\s\d{1,3}\s*$', s) \
                and len(s) < 60 and re.search(r'\d{1,3}$', s) \
                and not re.search(r'\d+\s*\.\s*\d+', s):
            continue
        out.append(ln)
    seg = NL.join(out)
    paras = []
    for p in re.split(r'\n\s*\n+', seg):
        # ★ 붙임표 절단 봉합 (2026-09-02 실측 611건 — 「dissen- sions」).
        #   줄끝 '-' + 다음 줄 소문자 시작 = 하드랩 하이픈이라 붙여 잇는다.
        p = re.sub(r'-\s*\n\s*(?=[a-z])', '', p)
        p = re.sub(r'\s+', ' ', p).strip()
        if p:
            paras.append(p)
    return NL.join(paras)


def _sections(chap_body):
    """장 본문 → [(절 번호|0, 절 제목, 본문)]. 0 = 절 표지 앞 머리글.

    표지 = 문단 첫머리의 `§ N. Title.` (OCR 변형 `$N.` 허용).
    ⚠ `]` 는 쪽머리, `)` 는 본문 안 참조의 서명 — 표지가 아니다.
    ⚠ 번호는 **오름차순만 받는다** — 쪽머리 잔재가 앞 번호를 다시 내밀면 버린다.
    ★ **제목 = 표지 문단 전체** (2026-09-02 사용자 신고 「3편 첫 단어가
      and the Greck N.7. — 제목인가 앞 편에서 잘린 것인가」) — 원문 제목이
      OCR 에서 두 줄로 접히는데 첫 줄만 집으면 둘째 줄이 본문 머리에 남는다.
      표지 문단(빈 줄 전까지)이 짧으면(≤140자) 통째로 제목이다.
    """
    marks = []
    for m in re.finditer(r'(?:^|\n)\s*[§$]\s*(\d{1,2})\s*[.]\s*([A-Z][^\n]{0,60})',
                         chap_body):
        num = int(m.group(1))
        title = m.group(2).strip()
        if ']' in title[:6] or ')' in title[:6]:
            continue
        # ⚠ 제목이 쪽번호로 끝나면 **오른쪽 면 쪽머리**다(「§ 5. The Host of
        #   Heaven 267」 — 2026-09-02 사용자 신고의 뿌리: 이것을 표지로 믿어
        #   §4 문장 한가운데가 잘렸다). 진짜 표지는 숫자로 안 끝난다.
        if re.search(r'\s\d{1,3}\s*$', title):
            continue
        marks.append((m.start(), num, title.rstrip('.').strip()))
    kept, last = [], 0
    for pos, num, title in marks:
        if num <= last:
            continue                          # 되돌아간 번호 = 잔재
        kept.append((pos, num, title))
        last = num
    secs = []
    if not kept:
        return [(0, '', chap_body)]
    head = chap_body[:kept[0][0]]
    if head.strip():
        secs.append((0, '', head))
    for i, (pos, num, title) in enumerate(kept):
        end = kept[i + 1][0] if i + 1 < len(kept) else len(chap_body)
        body = chap_body[pos:end]
        # 표지 문단(빈 줄 전까지)을 통째로 뗀다 — 접힌 제목 둘째 줄까지 제목이다.
        m2 = re.match(r'^\s*[§$]\s*\d{1,2}\s*[.]\s*(.{0,140}?)\s*(?:\n\s*\n|\Z)',
                      body, re.S)
        if m2:
            title = ' '.join(m2.group(1).split()).rstrip('.').strip() or title
            # 표지 문단에 딸려 온 쪽번호는 제목이 아니다
            title = re.sub(r'\s\d{1,3}$', '', title)
            body = body[m2.end():]
        else:
            # 표지 문단이 길다(제목 뒤에 곧장 산문) — 첫 줄만 뗀다
            body = re.sub(r'^\s*[§$]\s*\d{1,2}\s*[.]\s*[^\n]*\n?', '', body,
                          count=1)
        secs.append((num, title, body))
    return secs


def parse(path=None):
    """원문 → [(seq, label, body)] 유닛 목록 + 장 지도."""
    t = NL + io.open(path or os.path.join(RAW, 'gird1897.txt'),
                     encoding='utf-8', errors='replace').read()
    # 몸통 자르기 — 첫 CHAPTER 부터 INDEX(색인)·재인쇄 광고 전까지
    first = re.search(r'\n\s*CHAPTER\s+' + _ROMAN, t)
    if first is None:
        return [], []
    tail = t.find('INDEX OF SUBJECTS')
    if tail < 0:
        tail = len(t)
    t = t[first.start():tail]
    chaps = [(m.start(), m.group(1)) for m in
             re.finditer(r'\n\s*CHAPTER\s+(' + _ROMAN + r')\b', NL + t)]
    # ★ 장 번호는 **자리(차례)가 정본** (2026-09-02 실측 — OCR 이 XXI 을
    #   XXII 로 오독해 같은 번호가 둘이 됐다). 책의 장은 반드시 이어지므로
    #   자리에서 로마숫자를 다시 짓되, OCR 값과 4곳 넘게 어긋나면 구조가
    #   다른 것이니 멈춘다.
    def _rom(n):
        out, vals = '', ((50, 'L'), (40, 'XL'), (10, 'X'), (9, 'IX'),
                         (5, 'V'), (4, 'IV'), (1, 'I'))
        for v, s in vals:
            while n >= v:
                out += s
                n -= v
        return out
    fixed = [(pos, _rom(i + 1)) for i, (pos, _r) in enumerate(chaps)]
    diff = sum(1 for (p1, a), (p2, b) in zip(chaps, fixed) if a != b)
    if diff > 4:
        raise SystemExit('장 번호가 자리와 %d곳 어긋난다 — 구조 확인 필요' % diff)
    chaps = fixed
    units, chap_map, seq = [], [], 0
    for i, (pos, roman) in enumerate(chaps):
        end = chaps[i + 1][0] if i + 1 < len(chaps) else len(t)
        seg = t[max(0, pos - 1):end]
        seg = re.sub(r'^\s*CHAPTER\s+' + _ROMAN + r'\s*\.?', '', seg.strip())
        # 장 제목 = 이어지는 대문자 줄(최대 3줄) — 없으면 비워 둔다(지어내지 않음)
        title_lines = []
        rest = seg
        for _ in range(3):
            m = re.match(r'\s*\n?\s*([A-Z][A-Z ,.\'\-;]{3,70})\s*\n', rest)
            if not m:
                break
            title_lines.append(m.group(1).strip().rstrip('.'))
            rest = rest[m.end():]
        chap_title = ' '.join(title_lines).strip()
        chap_map.append((roman, chap_title))
        for num, stitle, body in _sections(rest):
            num = SEC_NUM_FIX.get((roman, num), num)
            body = _clean_lines(body)
            # 꼬리 낱자 잡음 — 문장 종결 뒤에 남은 쪽 경계 부스러기(「. R」·「|r」)
            body = re.sub(r'(?<=[.!?’”])[\s\n]+[A-Za-z]{1,2}$', '',
                          body.rstrip())
            if len(body) < 300:
                continue                      # 잡음 조각
            seq += 1
            if num:
                label = '%s. %s — § %d. %s' % (roman, _label_title(chap_title)
                                               or 'Chapter', num, _label_title(stitle))
            else:
                label = '%s. %s' % (roman, _label_title(chap_title) or 'Chapter')
            units.append((seq, label[:120], body))
    return units, chap_map


# ──────────────────────────────────────────────────────────────────────
_CROSS_CACHE = None


def crosscheck():
    """정본(1897 정리본) ↔ 1871 스캔 + 음성 대조군 — §98차 방식.

    ⚠ 문장 대조가 무겁다(752KB × 1.2MB ×3) — 한 번 재고 캐시한다.
      check() 와 apply() 의 출처 기록이 같은 수치를 쓴다."""
    global _CROSS_CACHE
    if _CROSS_CACHE is not None:
        return _CROSS_CACHE
    import db_book_source_match as SM
    units, _ = parse()
    ours = NL.join(b for _s, _l, b in units)
    out = []
    for fn, name, _url in CROSSES:
        p = os.path.join(RAW, fn)
        if not os.path.exists(p):
            continue
        other = io.open(p, encoding='utf-8', errors='replace').read()
        ab, ba, cnt = SM.crosscheck(ours, other)
        out.append((name, ab, ba))
    neg_p = os.path.join(RAW, NEGATIVE)
    neg = None
    if os.path.exists(neg_p):
        other = io.open(neg_p, encoding='utf-8', errors='replace').read()
        ab, _ba, _ = SM.crosscheck(ours, other)
        neg = ab
    _CROSS_CACHE = (out, neg)
    return _CROSS_CACHE


def _unit_key(label):
    """라벨 → (장 로마숫자, 절 번호). 절 없는 장 머리 = 0."""
    roman = label.split('.')[0].strip()
    m = re.search(r'§ (\d+)\.', label)
    return roman, (int(m.group(1)) if m else 0)


def term_links(conn, units):
    """유닛 ↔ 용어 — LINKS_DRAFT(사람 판정 명시 지도)에서만.

    반환 [(seq, entity_code, 0)], {code: entity_id}, 문제 목록.
    문제 = 초안 열쇠가 유닛과 안 맞거나(분할이 변했다) 코드가 실재하지 않음."""
    codes, problems = {}, []
    need = sorted({c for cs in LINKS_DRAFT.values() for c in cs})
    for code in need:
        r = conn.execute("SELECT entity_id FROM sys_entity_master"
                         " WHERE entity_code=?"
                         " AND COALESCE(record_status,'LIVE')='LIVE'",
                         (code,)).fetchone()
        if r:
            codes[code] = r[0]
        else:
            problems.append('실재하지 않는 코드: %s' % code)
    keys = {_unit_key(l) for _s, l, _b in units}
    for k in LINKS_DRAFT:
        if k not in keys:
            problems.append('초안 열쇠가 유닛에 없음: %s §%d' % k)
    out = []
    for seq, label, body in units:
        for code in LINKS_DRAFT.get(_unit_key(label), ()):
            if code in codes:
                out.append((seq, code, 0))
    return out, codes, problems


def check(conn=None, verbose=True):
    units, chap_map = parse()
    sizes = sorted(len(b) for _s, _l, b in units)
    errs = []
    if not (150 <= len(units) <= 320):
        errs.append('유닛 수 %d — 기대 범위(150~320) 밖' % len(units))
    if len(chap_map) < 25:
        errs.append('장 %d개 — 기대(28) 미달' % len(chap_map))
    walls = [l for _s, l, b in units if len(b) > 15000]
    if len(walls) > 8:
        errs.append('벽 유닛(15,000자+) %d개' % len(walls))
    total = sum(sizes)
    if total < 500000:
        errs.append('본문 %d자 — 기대(50만+) 미달(받다 만 것)' % total)
    cross, neg = crosscheck()
    for name, ab, ba in cross:
        if verbose:
            print('  대조 %s : %.0f%% / %.0f%%' % (name, ab * 100, ba * 100))
    if neg is not None and verbose:
        print('  음성 대조군(Trench·다른 책) : %.0f%%' % (neg * 100))
    # ⚠ 판이 다른 대조는 **한 방향만 뜻이 있다** — 우리(1897 정리본)의 문장이
    #   증인(1871)에 실재하는가(ab). 역방향은 개정 축약판이라 낮은 것이 정상
    #   (1871 이 더 길고 OCR 도 나쁘다 — 실측 78%/26%). min 으로 재면
    #   멀쩡한 진본을 떨어뜨린다.
    best = max((ab for _n, ab, _ba in cross), default=0)
    if neg is None or best < 0.50 or best < (neg or 0) * 10:
        errs.append('판본 대조 실패 — 우리→증인 최고 %.0f%% · 음성 %.0f%%'
                    % (best * 100, (neg or 0) * 100))
    if verbose:
        print('check: 유닛 %d · 장 %d · 중앙 %d자 · 최대 %d · 합계 %d자'
              % (len(units), len(chap_map), sizes[len(sizes) // 2],
                 sizes[-1], total))
        if conn is not None:
            links, _codes, probs = term_links(conn, units)
            from collections import Counter
            cc = Counter(code for _s, code, _n in links)
            print('  용어 연결 %d건: %s' % (len(links), dict(cc)))
            errs.extend(probs)
        for e in errs:
            print('  ✗', e)
    return errs


def apply(conn):
    errs = check(conn, verbose=True)
    if errs:
        raise SystemExit('check 위반 — 적재하지 않음')
    units, _chap_map = parse()
    r = conn.execute("SELECT book_id FROM sys_book_asset WHERE book_code=?",
                     (CODE,)).fetchone()
    if r:
        bid = r[0]
        conn.execute("UPDATE sys_book_asset SET title=?, author=?, pub_year=?,"
                     " description=?, book_category=?, lang_code='EN',"
                     " copyright_type='PUBLIC_DOMAIN', source_url=?"
                     " WHERE book_id=?",
                     (TITLE, AUTHOR, YEAR, DESC, CATEGORY, PRIMARY[1], bid))
    else:
        cur = conn.execute(
            "INSERT INTO sys_book_asset(book_code,title,author,lang_code,"
            "copyright_type,source_url,pub_year,description,record_status,"
            "book_category) VALUES(?,?,?,'EN','PUBLIC_DOMAIN',?,?,?,'LIVE',?)",
            (CODE, TITLE, AUTHOR, PRIMARY[1], YEAR, DESC, CATEGORY))
        bid = cur.lastrowid
    # 출처 줄 — 짓는 곳은 db_book_attrib 한 곳(§0-1b)
    import db_book_attrib
    from db_book_desc_data import EDITIONS
    att = NL + NL + db_book_attrib.line_for(AUTHOR, TITLE, EDITIONS.get(CODE))
    # ⚠⚠ **유닛을 지우기 전에 그 유닛의 용어 연결부터 걷는다** (2026-09-02
    #   실측 사고 — 재적재가 unit_id 를 갈아 첫 적재의 연결 29건이 **없는
    #   유닛을 가리키는 유령**이 됐다. 링크는 번호에 닻이라 유닛과 함께
    #   지워야 한다). 이관 전 남은 유령도 같은 기준으로 쓸어낸다 —
    #   이 도구의 대상 엔티티를 가리키면서 실재하지 않는 유닛에 붙은 것만.
    old_uids = [r[0] for r in conn.execute(
        "SELECT unit_id FROM sys_book_unit WHERE book_id=?", (bid,))]
    if old_uids:
        conn.execute("DELETE FROM sys_link_asset WHERE link_type='BUNT_ENTI'"
                     " AND clicked_id IN (%s)"
                     % ','.join('?' * len(old_uids)), old_uids)
    _links0, _codes0, _p0 = term_links(conn, units)
    if _codes0:
        eids = list(set(_codes0.values()))
        conn.execute(
            "DELETE FROM sys_link_asset WHERE link_type='BUNT_ENTI'"
            " AND target_id IN (%s)"
            " AND NOT EXISTS (SELECT 1 FROM sys_book_unit u"
            "  WHERE u.unit_id=sys_link_asset.clicked_id)"
            % ','.join('?' * len(eids)), eids)
    conn.execute("DELETE FROM sys_book_unit_text WHERE unit_id IN "
                 "(SELECT unit_id FROM sys_book_unit WHERE book_id=?)", (bid,))
    conn.execute("DELETE FROM sys_book_unit WHERE book_id=?", (bid,))
    uid_of = {}
    for seq, label, body in units:
        cur = conn.execute(
            "INSERT INTO sys_book_unit(book_id,sequence,unit_label,record_status)"
            " VALUES(?,?,?,'LIVE')", (bid, seq, label))
        uid_of[seq] = cur.lastrowid
        conn.execute(
            "INSERT INTO sys_book_unit_text(unit_id,text_variant,lang_code,"
            "body_text,record_status) VALUES(?,'ORIGINAL','EN',?,'LIVE')",
            (uid_of[seq], body + att))
    conn.execute("UPDATE sys_book_asset SET body_chars=? WHERE book_id=?",
                 (sum(len(b) for _s, _l, b in units), bid))
    # 출처 기록 (DB — §0-1b) — 대조 수치·대조군 포함(§98차)
    cross, neg = crosscheck()
    conn.execute("DELETE FROM sys_book_source WHERE book_code=?", (CODE,))
    conn.execute(
        "INSERT INTO sys_book_source(book_code,role,name,url,note,match_pct,"
        "checked_at,record_status) VALUES(?,'PRIMARY',?,?,?,NULL,?,'LIVE')",
        (CODE, PRIMARY[0], PRIMARY[1],
         '표제면 실물 확인(규칙 ③) — 1897 2nd ed. Public domain (발행 1930 이전). '
         'OCR 원문이라 드문 글자 손상 있음.', TODAY))
    url_of = {name: url for _fn, name, url in CROSSES}
    for (name, ab, ba) in cross:
        conn.execute(
            "INSERT INTO sys_book_source(book_code,role,name,url,note,match_pct,"
            "checked_at,record_status) VALUES(?,'CROSS',?,?,?,?,?,'LIVE')",
            (CODE, name, url_of.get(name, ''),
             '판이 달라(1st↔2nd ed) 80%% 게이트 비적용 — 우리→증인 방향 실측 '
             '%.0f%%/%.0f%% · 음성 대조군(다른 책) %.0f%% 대비 판정(§98차 방식).'
             % (ab * 100, ba * 100, (neg or 0) * 100),
             int(ab * 100), TODAY))
    # 용어 연결 — link_picker.add(scope='SYS') 가 실재 검증까지 한다
    import link_picker as LP
    links, codes, _probs = term_links(conn, units)
    n_link = 0
    for seq, code, _n in links:
        LP.add(conn, ('BUNT', uid_of[seq]), ('ENTI', codes[code]), scope='SYS')
        n_link += 1
    conn.commit()
    print('apply: 유닛 %d · 용어 연결 %d' % (len(units), n_link))


def status(conn):
    r = conn.execute("SELECT book_id, body_chars FROM sys_book_asset"
                     " WHERE book_code=?", (CODE,)).fetchone()
    if not r:
        print('%s 미적재' % CODE)
        return
    n = conn.execute("SELECT COUNT(*) FROM sys_book_unit WHERE book_id=?"
                     " AND COALESCE(record_status,'LIVE')='LIVE'", (r[0],)).fetchone()[0]
    lk = conn.execute(
        "SELECT COUNT(*) FROM sys_link_asset WHERE link_type='BUNT_ENTI'"
        " AND clicked_id IN (SELECT unit_id FROM sys_book_unit WHERE book_id=?)"
        " AND COALESCE(record_status,'LIVE')='LIVE'", (r[0],)).fetchone()[0]
    print('%s: book_id %d · 유닛 %d · %d자 · 용어 연결 %d'
          % (CODE, r[0], n, r[1] or 0, lk))


# ──────────────────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    # 합성 장 본문 — OCR 변형 세 꼴을 담는다
    body = NL.join([
        '   § 1. Sin.', '',
        'THE word chatta is used ' + 'x ' * 200, '',
        '§ 8.] Wickedness Br',          # 쪽머리 잔재(]) — 표지 아님
        '$2. Wrong.', '',
        'The word avel means ' + 'y ' * 200, '',
        'as we saw (§ 1) above, and further ' + 'z ' * 200])
    secs = _sections(body)
    nums = [n for n, _t2, _b in secs]
    t('절 가르기 — §1·$2 두 표지', nums == [1, 2], nums)
    t('쪽머리 「§ 8.]」 표지 아님', all(n != 8 for n in nums))
    t('본문 안 「(§ 1)」 표지 아님', len(secs) == 2)
    # 접힌 제목 — 표지 문단 둘째 줄까지 제목으로 흡수 (2026-09-02 사용자 신고)
    bw = NL.join(['§ 3. The LXX a Connecting Link between the Hebrew O.T.',
                  'and the Greek N.T.', '',
                  'We now pass from the Hebrew original ' + 'w ' * 200])
    sw = _sections(bw)
    t('접힌 제목 흡수 — 둘째 줄이 제목에', 'Greek N.T' in sw[0][1], sw[0][1][-20:])
    t('접힌 제목 — 본문은 산문부터', sw[0][2].strip().startswith('We now pass'),
      sw[0][2][:24])
    # 쪽머리(제목+쪽번호)는 표지가 아니다 — §4 문장을 자르던 사고(154편)
    bp = NL.join(['§ 4. Real Section.', '', 'prose one ' + 'p ' * 200,
                  'ends mid sentence and', '§ 5. The Host of Heaven 267',
                  'continues here ' + 'q ' * 200])
    sp = _sections(bp)
    t('쪽머리 표지 거부(제목 끝 쪽번호)', [n for n, _t2, _b in sp] == [4],
      [n for n, _t2, _b in sp])
    # 붙임표 절단 봉합
    ch = _clean_lines('religious dissen-' + NL + 'sions were')
    t('붙임표 봉합', 'dissensions' in ch, ch)
    ch2 = _clean_lines('page one' + NL + '80 Old ’Testament Synonyms (Cur. VI.' + NL + 'page two')
    t('혼합대소문자 달리는 머리 제거', 'Synonyms' not in ch2, ch2)
    # 오름차순 규칙 — 되돌아간 번호는 잔재
    b2 = NL.join(['§ 1. A.', '', 'a ' * 200, '', '§ 3. B.', '', 'b ' * 200,
                  '', '§ 2. C.', '', 'c ' * 200])
    n2 = [n for n, _t2, _b in _sections(b2)]
    t('오름차순 — 되돌아간 §2 버림', n2 == [1, 3], n2)
    # 청소 — 쪽번호·달리는 머리 제거 + 낱말 보존
    seg = 'one two' + NL + '123' + NL + 'OLD TESTAMENT SYNONYMS' + NL + 'three four'
    c = _clean_lines(seg)
    t('쪽번호·머리 제거', '123' not in c and 'SYNONYMS' not in c)
    t('낱말 차례 보존', c.split() == ['one', 'two', 'three', 'four'], c)
    # 실 파일 파싱 게이트
    if os.path.exists(os.path.join(RAW, 'gird1897.txt')):
        units, chap_map = parse()
        t('유닛 150~320', 150 <= len(units) <= 320, len(units))
        t('장 25+', len(chap_map) >= 25, len(chap_map))
        sin_units = [l for _s, l, _b in units if l.startswith('VI. ')]
        t('6장(SIN) 유닛 실재', len(sin_units) >= 5, sin_units[:2])
        t('본문 50만자+', sum(len(b) for _s, _l, b in units) > 500000)
    else:
        print('  (원문 없음 — 실파일 항목 4건 건너뜀)')
    # 탐지력 — 받다 만 파일이면 check 가 잡는가
    import tempfile
    tf = tempfile.NamedTemporaryFile('w', suffix='.txt', delete=False,
                                     encoding='utf-8')
    tf.write('CHAPTER I.' + NL + 'TINY BOOK.' + NL + '§ 1. A.' + NL + 'short ' * 100)
    tf.close()
    u3, _c3 = parse(tf.name)
    os.unlink(tf.name)
    t('탐지력 — 조각 파일은 유닛 부족', len(u3) < 150, len(u3))
    print('db_gird_import selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect('bible_master.db')
    try:
        if '--check' in sys.argv:
            check(conn)
        elif '--apply' in sys.argv:
            apply(conn)
        else:
            status(conn)
    finally:
        conn.close()
