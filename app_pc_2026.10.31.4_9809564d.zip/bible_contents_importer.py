import sqlite3
import appdb
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import os
import csv

class BibleContentsImporter:
    def __init__(self, root):
        self.root = root
        self.root.title("📖 스마트 인덱싱 - 전역 순서 정밀 검증 모드")
        self.root.geometry("1450x950")
        
        base_dir = os.path.dirname(os.path.abspath(__file__))
        self.db_path = os.path.join(base_dir, "bible_master.db")
        
        self.matched_list = []
        self.ver_code = tk.StringVar()
        self.write_mode = tk.StringVar(value="REPLACE")

        self.setup_ui()
        self.load_versions()

    def setup_ui(self):
        # 1. 상단 설정 바
        top_f = tk.Frame(self.root, bg="#34495E", pady=10)
        top_f.pack(fill="x")
        tk.Label(top_f, text=f"📂 DB: {os.path.basename(self.db_path)}", fg="white", bg="#34495E").pack(side="left", padx=15)
        
        tk.Label(top_f, text="성경 버전:", fg="white", bg="#34495E").pack(side="left", padx=10)
        self.cb_version = ttk.Combobox(top_f, textvariable=self.ver_code, width=20)
        self.cb_version.pack(side="left", padx=5)

        # 2. 저장 방식 라디오 버튼
        opt_f = tk.LabelFrame(self.root, text=" ⚙️ 저장 방식 ", padx=15, pady=5)
        opt_f.pack(fill="x", padx=20, pady=5)
        tk.Radiobutton(opt_f, text="새 데이터 교체(REPLACE)", variable=self.write_mode, value="REPLACE").pack(side="left", padx=20)
        tk.Radiobutton(opt_f, text="기존 유지(IGNORE/UPDATE)", variable=self.write_mode, value="IGNORE").pack(side="left", padx=20)

        # 3. 버튼부
        btn_f = tk.Frame(self.root, pady=10)
        btn_f.pack(fill="x", padx=20)
        tk.Button(btn_f, text="📄 TSV 불러오기", command=self.load_tsv, width=15).pack(side="left", padx=5)
        tk.Button(btn_f, text="🔍 분석 및 대조", command=self.analyze_data, width=15, bg="#E67E22", fg="white", font=("", 10, "bold")).pack(side="left", padx=5)
        tk.Button(btn_f, text="💾 스마트 저장 실행", command=self.save_db, width=20, bg="#27AE60", fg="white", font=("", 10, "bold")).pack(side="right", padx=5)

        # 4. 메인 패널 (상/하)
        paned = tk.PanedWindow(self.root, orient="vertical", sashwidth=4, bg="#CCC")
        paned.pack(fill="both", expand=True, padx=20, pady=5)

        # [상단] 매칭 리스트
        up_f = tk.Frame(paned)
        tk.Label(up_f, text="✅ 기존 인덱스 매칭 성공 (본문 업데이트 대상)", font=("", 9, "bold")).pack(anchor="w")
        self.tree = ttk.Treeview(up_f, columns=("vid", "bc", "ch", "vs", "txt"), show="headings", height=8)
        for col in [("vid","ID"), ("bc","BC"), ("ch","장"), ("vs","절"), ("txt","본문")]:
            self.tree.heading(col[0], text=col[1]); self.tree.column(col[0], width=80, anchor="center")
        self.tree.column("txt", width=700)
        self.tree.pack(fill="both", expand=True)
        paned.add(up_f, height=250)

        # [하단] 미등록 좌표 리스트 (★에러 발생했던 background 옵션 제거)
        low_f = tk.Frame(paned)
        tk.Label(low_f, text="⚠️ 미등록 좌표 (★제안 순서 더블클릭하여 수정 가능)", fg="#C0392B", font=("", 9, "bold")).pack(anchor="w")
        cols = ("prev", "bc", "ch", "vs", "suggest", "next", "txt")
        self.tree_mis = ttk.Treeview(low_f, columns=cols, show="headings", height=12)
        
        self.tree_mis.heading("prev", text="⬅️ 앞 순서"); self.tree_mis.column("prev", width=100, anchor="center")
        self.tree_mis.heading("bc", text="BC"); self.tree_mis.column("bc", width=50, anchor="center")
        self.tree_mis.heading("ch", text="장"); self.tree_mis.column("ch", width=50, anchor="center")
        self.tree_mis.heading("vs", text="절"); self.tree_mis.column("vs", width=50, anchor="center")
        self.tree_mis.heading("suggest", text="★제안(수정)"); self.tree_mis.column("suggest", width=120, anchor="center")
        self.tree_mis.heading("next", text="➡️ 뒤 순서"); self.tree_mis.column("next", width=100, anchor="center")
        self.tree_mis.heading("txt", text="본문"); self.tree_mis.column("txt", width=650)
        
        self.tree_mis.pack(fill="both", expand=True)
        self.tree_mis.bind("<Double-1>", self.on_double_click)
        paned.add(low_f, height=400)

        # 로그 영역
        self.log_txt = tk.Text(self.root, height=8, bg="#222", fg="#00FF00", font=("Consolas", 9))
        self.log_txt.pack(fill="x", padx=20, pady=10)

    def on_double_click(self, event):
        item_id = self.tree_mis.identify_row(event.y)
        column = self.tree_mis.identify_column(event.x)
        
        if column == "#5": # suggest 컬럼
            x, y, w, h = self.tree_mis.bbox(item_id, column)
            entry = tk.Entry(self.tree_mis, justify="center", font=("", 9, "bold"))
            
            current_val = self.tree_mis.item(item_id)['values'][4]
            entry.insert(0, current_val)
            entry.place(x=x, y=y, width=w, height=h)
            entry.focus_set()
            entry.select_range(0, tk.END)
            
            def commit_edit(e=None):
                new_val = entry.get()
                if new_val.isdigit():
                    vals = list(self.tree_mis.item(item_id)['values'])
                    vals[4] = int(new_val)
                    self.tree_mis.item(item_id, values=vals)
                    self.log_msg(f"📝 {vals[2]}장 {vals[3]}절 순서가 {new_val}로 수정되었습니다.")
                entry.destroy()

            entry.bind("<Return>", commit_edit)
            entry.bind("<FocusOut>", commit_edit)

    def analyze_data(self):
        """장/절 경계를 넘어 전역 순서 기반으로 앞뒤 번호를 조회하여 제안"""
        if not hasattr(self, 'path'): return
        self.tree.delete(*self.tree.get_children())
        self.tree_mis.delete(*self.tree_mis.get_children())
        self.matched_list = []
        
        conn = appdb.connect(self.db_path)
        cursor = conn.cursor()
        v_code = self.ver_code.get()
        session_last_order = None

        with open(self.path, 'r', encoding='utf-8-sig') as f:
            reader = csv.reader(f, delimiter='\t')
            for row in reader:
                if not row or not row[0].isdigit(): continue
                bc, ch, vs, txt = int(row[0]), int(row[1]), int(row[2]), row[3]
                
                cursor.execute("SELECT verse_id, sort_order FROM bible_index WHERE bcode=? AND chapter=? AND verse=?", (bc, ch, vs))
                res = cursor.fetchone()
                
                if res:
                    vid, order = res
                    self.tree.insert("", "end", values=(vid, bc, ch, vs, txt))
                    self.matched_list.append((vid, v_code, txt))
                    session_last_order = order
                else:
                    # 1. 전역 직전 순서 찾기
                    cursor.execute("""
                        SELECT sort_order FROM bible_index 
                        WHERE (bcode < ?) OR (bcode = ? AND chapter < ?) OR (bcode = ? AND chapter = ? AND verse < ?)
                        ORDER BY bcode DESC, chapter DESC, verse DESC LIMIT 1
                    """, (bc, bc, ch, bc, ch, vs))
                    p = cursor.fetchone()
                    prev_v = p[0] if p else 0
                    if session_last_order and session_last_order > prev_v: prev_v = session_last_order

                    # 2. 전역 직후 순서 찾기
                    cursor.execute("""
                        SELECT sort_order FROM bible_index 
                        WHERE (bcode > ?) OR (bcode = ? AND chapter > ?) OR (bcode = ? AND chapter = ? AND verse > ?)
                        ORDER BY bcode ASC, chapter ASC, verse ASC LIMIT 1
                    """, (bc, bc, ch, bc, ch, vs))
                    n = cursor.fetchone()
                    next_v = n[0] if n else (prev_v + 10)
                    
                    # 3. 중간값 제안 (앞 순서와 뒤 순서 사이)
                    suggested = (prev_v + next_v) // 2
                    if suggested == prev_v: suggested += 1
                    
                    self.tree_mis.insert("", "end", values=(prev_v, bc, ch, vs, suggested, next_v, txt))
                    session_last_order = suggested
        conn.close()
        self.log_msg(f"🔍 분석 완료: 매칭 {len(self.matched_list)}건 / 미등록 {len(self.tree_mis.get_children())}건")

    def save_db(self):
        mode = self.write_mode.get()
        v_code = self.ver_code.get()
        if not v_code:
            messagebox.showwarning("주의", "성경 버전을 선택하세요.")
            return

        conn = appdb.connect(self.db_path)
        cursor = conn.cursor()
        
        try:
            # 상단 매칭분 저장
            for row in self.matched_list:
                cursor.execute(f"INSERT OR {mode} INTO bible_content (verse_id, version_code, verse_text) VALUES (?, ?, ?)", row)
            
            # 하단 신규 인덱싱 저장 (화면 수정값 기준)
            cursor.execute("SELECT MAX(verse_id) FROM bible_index")
            new_id = cursor.fetchone()[0] or 31102
            
            for item in self.tree_mis.get_children():
                v = self.tree_mis.item(item)['values']
                prev, bc, ch, vs, sugg, next_v, txt = int(v[0]), int(v[1]), int(v[2]), int(v[3]), int(v[4]), int(v[5]), v[6]
                
                # 범위 검증: 앞 숫자 < 제안 < 뒤 숫자
                if next_v > prev and not (prev < sugg < next_v):
                    raise ValueError(f"❌ 범위 오류: {ch}장 {vs}절의 순서({sugg})가 {prev} ~ {next_v} 사이를 벗어났습니다.")
                
                new_id += 1
                cursor.execute("INSERT INTO bible_index VALUES (?,?,?,?,?)", (new_id, bc, ch, vs, sugg))
                cursor.execute("INSERT INTO bible_content VALUES (?,?,?)", (new_id, v_code, txt))
            
            conn.commit()
            messagebox.showinfo("성공", "수정된 순서로 저장이 완료되었습니다.")
            self.analyze_data()
        except Exception as e:
            conn.rollback()
            messagebox.showerror("저장 실패", str(e))
        finally:
            conn.close()

    def load_tsv(self):
        self.path = filedialog.askopenfilename(filetypes=[("TSV", "*.tsv")])
    
    def load_versions(self):
        try:
            conn = appdb.connect(self.db_path)
            rows = conn.execute("SELECT version_code FROM bible_version").fetchall()
            self.cb_version['values'] = [r[0] for r in rows]
            if rows: self.cb_version.current(0)
            conn.close()
        except: pass

    def log_msg(self, msg):
        self.log_txt.insert(tk.END, f"> {msg}\n")
        self.log_txt.see(tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = BibleContentsImporter(root)
    root.mainloop()