# -*- coding: utf-8 -*-
"""db_treasury_import.py — 스펄전 『Treasury of David』(시편 강해) 주석 적재 (영구, 2026-08-17).

★ **왜 주석인가** — 이 책은 도서가 아니라 **시편 전용 절별 주석**이다(사용자 합의,
  설계안 7부). `sys_commentary_*` 로 넣어야 P2 주석 탭에서 시편 어느 절을 클릭해도
  스펄전이 뜬다. 편별 서론(TITLE·DIVISION)은 **CHAPTER 항목**으로 함께 담는다 —
  나중에 「스펄전과 함께 시편」 도서 플랜의 본문 재료가 된다.

★ **소스 = The Spurgeon Archive** (archive.spurgeon.org/treasury/psNNN.php).
  ⚠ CCEL 판은 **페이지 이미지 전용**이다(2026-08-17 실측 — txt 가 50KB 껍데기,
    「Image of page N」 목록뿐. BARNES_OT 와 같은 함정). Gutenberg 에는 없다.
    §0-1b 순위에서 3순위(도서별 전용 검증 사이트)로 내려온 까닭이다.
  이번 1차는 **스펄전 본인의 글만**: 편별 서론 + 절별 EXPOSITION.
  타 저자 인용 모음(EXPLANATORY NOTES)과 설교 힌트(HINTS)는 2차로 미룬다.

구조 (실측 — ps001/013/026):
    <H1>Psalm N</H1> … TITLE./DIVISION. 문단(서론) … <A NAME="expo">EXPOSITION</A>
    Verse 1. …  Verses 4-5. …  <A NAME="expl">EXPLANATORY NOTES…
  ⚠ 절 표식은 `Verse N.` 외에 `Verses 4-5.` `Verses 1, 2.` 꼴이 있고,
    빠지는 절도 있다(시 13 은 Verse 2 부터 — 1절 논의가 서론에 녹아 있다).
    빠진 절은 빠진 대로 둔다 — 커버리지이지 오류가 아니다.
  ⚠ 원문은 남의 글이다 — 문단·문장부호(엠대시 포함)를 **그대로** 보존한다.
    렌즈 지침(— 금지)은 우리가 쓰는 글의 규칙이지 저자의 글에 적용하지 않는다.

    python db_treasury_import.py --selftest          (의무)
    python db_treasury_import.py --fetch 1 26        시편 N..M 원문 내려받기
    python db_treasury_import.py --check 1 13 26     파싱 미리보기 (적재 안 함)
    python db_treasury_import.py --apply 1 13 26     적재 (멱등 — 시편 단위 재적재)
"""
import io
import os
import re
import sys
import time
import urllib.request

import appdb

DB = 'bible_master.db'
RAW = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_treasury_raw')
URL = 'https://archive.spurgeon.org/treasury/ps%03d.php'
CODE = 'TREASURY'
PSA_BCODE = 19          # bible_index 숫자, sys_commentary_entry.bcode 는 'PSA' 문자열


# ── 내려받기 ──────────────────────────────────────────────────────────────

def fetch(n_from, n_to):
    os.makedirs(RAW, exist_ok=True)
    for n in range(n_from, n_to + 1):
        path = os.path.join(RAW, 'ps%03d.php' % n)
        if os.path.exists(path) and os.path.getsize(path) > 5000:
            continue
        req = urllib.request.Request(URL % n, headers={'User-Agent': 'Mozilla/5.0'})
        data = urllib.request.urlopen(req, timeout=30).read()
        io.open(path, 'wb').write(data)
        print('ps%03d %d bytes' % (n, len(data)))
        time.sleep(1)                       # 사이트 예의 (§21-2b)


# ── 파싱 ──────────────────────────────────────────────────────────────────

# ⚠ 숫자 실체(&#151;)만 있는 줄 알았는데 **이름 실체(&mdash;)를 쓰는 편이
#   섞여 있다**(시 35·79·84 실측 — 2026-08-17). 둘 다 받는다.
_ENT = {'&#151;': '—', '&#150;': '–', '&mdash;': '—', '&ndash;': '–',
        '&amp;': '&', '&quot;': '"',
        '&nbsp;': ' ', '&lt;': '<', '&gt;': '>', '&#146;': "'", '&#145;': "'",
        '&#147;': '"', '&#148;': '"'}


def _clean(html):
    """태그를 벗기고 실체참조를 되살린다. 문단(<P>)만 개행으로 남긴다.

    ⚠ 소스가 70자 안팎에서 **하드랩**돼 있다 — 원 개행을 먼저 공백으로 눌러야
      한다. 안 누르면 모든 줄바꿈이 본문에 그대로 남는다(첫 파싱에서 실측).
    """
    s = html.replace('\r', ' ').replace('\n', ' ')
    s = re.sub(r'(?i)<P\b[^>]*>', '\n', s)
    s = re.sub(r'(?i)<BR\b[^>]*>', '\n', s)
    s = re.sub(r'<[^>]+>', ' ', s)
    for k, v in _ENT.items():
        s = s.replace(k, v)
    # ⚠ 이중 인코딩(&amp;mdash;) — &amp;→& 가 풀리면 &mdash; 가 새로 생긴다.
    #   실측: 시 79 에서 한 건 샜다(2026-08-17). 한 번 더 돈다.
    for k, v in _ENT.items():
        s = s.replace(k, v)
    # 남은 숫자 실체는 **글자로 복원**한다 — 시 35 의 그리스어 낱말이 16진
    # (&#x3c8;)으로 적혀 있어 지우면 낱말이 사라진다(2026-08-17 실측).
    # 128~159 는 cp1252 문장부호(151=—)라 그 표로 푼다.
    def _num(n):
        if 128 <= n <= 159:
            try:
                return bytes([n]).decode('cp1252')
            except Exception:
                return ' '
        try:
            return chr(n) if n >= 32 else ' '
        except Exception:
            return ' '
    s = re.sub(r'&#x([0-9a-fA-F]+);', lambda m: _num(int(m.group(1), 16)), s)
    s = re.sub(r'&#(\d+);', lambda m: _num(int(m.group(1))), s)
    lines = [' '.join(ln.split()) for ln in s.split('\n')]
    lines = [ln for ln in lines if ln]
    return '\n'.join(lines)


_MARK = re.compile(r'Verses?\s+(\d+)\s*(?:[,\-]\s*(\d+))?\s*\.')
# 2차(EXPLANATORY NOTES) — 「Whole Psalm.」 또는 절 표식. 인용마다 표식이
# 반복된다(시 1 은 Verse 1 이 여덟 번) — 같은 구간은 한 항목으로 합친다.
_NMARK = re.compile(r'Whole Psalm\.|Verses?\s+(\d+)\s*(?:[,\-]\s*(\d+))?\s*\.')


def parse(path):
    """psNNN.php → {'psalm': n, 'intro': str, 'items': [(v1, v2, text)]}"""
    h = io.open(path, encoding='utf-8', errors='replace').read()
    # ⚠ 소스 페이지의 태그 대소문자가 편마다 다르다 — 26편 중 10편이 `<h1>`,
    #   ps004 는 `<a name="expo">` 다(2026-08-17 전량 수집에서 실측).
    #   머리글·앵커 탐색은 전부 대소문자 무관으로 한다.
    m = re.search(r'(?i)<H1>Psalm (\d+)</H1>', h)
    if not m:
        raise ValueError('%s — Psalm 머리글이 없다' % path)
    n = int(m.group(1))

    def _ifind(needle):
        i = h.find(needle)
        return i if i >= 0 else h.find(needle.lower())

    i_expo = _ifind('NAME="expo"')
    i_expl = _ifind('NAME="expl"')
    if i_expo < 0:
        raise ValueError('ps%d — EXPOSITION 이 없다' % n)
    if i_expl < 0:
        i_expl = _ifind('NAME="hint"')
    if i_expl < 0:
        i_expl = len(h)
    else:
        # ⚠ 표식이 태그 한가운데라 그냥 자르면 `<CENTER><A ` 반쪽이 남는다 —
        #   그 앞의 태그 시작까지 되감는다(selftest 가 잡았다)
        i_expl = h.rfind('<', 0, i_expl)

    # 서론 = H1 뒤 ~ EXPOSITION 앞. 안내 링크 줄(Exposition/Explanatory …)은 걷는다.
    # ⚠ i_expo 는 `<A NAME="expo"` 태그 한가운데다 — 그대로 자르면 서론 끝에
    #   반쪽 태그 `<A` 가 남아 화면까지 나갔다(2026-08-17 사용자가 잡음, 111.txt).
    #   i_expl 과 같이 그 앞의 태그 시작까지 되감는다.
    i_expo_cut = h.rfind('<', 0, i_expo)
    intro_raw = h[m.end():i_expo_cut]
    intro_raw = re.sub(r'(?is)<A HREF[^>]*>.*?</A>', ' ', intro_raw)
    intro = _clean(intro_raw)
    intro = '\n'.join(ln for ln in intro.split('\n')
                      if ln and ln.upper() not in ('EXPOSITION',))

    body = _clean(h[i_expo:i_expl])
    # 첫 줄의 'EXPOSITION' 제목 제거
    body = re.sub(r'^\s*EXPOSITION\s*', '', body)

    items = []
    marks = list(_MARK.finditer(body))
    for i, mk in enumerate(marks):
        v1 = int(mk.group(1))
        v2 = int(mk.group(2)) if mk.group(2) else v1
        if v2 < v1:
            v1, v2 = v2, v1
        end = marks[i + 1].start() if i + 1 < len(marks) else len(body)
        text = body[mk.end():end].strip()
        if text:
            items.append((v1, v2, text))
    return {'psalm': n, 'intro': intro.strip(), 'items': items}


# ── 검사 ──────────────────────────────────────────────────────────────────

def check(conn, psalms, verbose=True):
    bad = []
    out = []
    for n in psalms:
        path = os.path.join(RAW, 'ps%03d.php' % n)
        if not os.path.exists(path):
            bad.append('ps%d — 원문이 없다(--fetch 먼저)' % n)
            continue
        d = parse(path)
        maxv = conn.execute('SELECT MAX(verse) FROM bible_index WHERE bcode=? '
                            'AND chapter=?', (PSA_BCODE, n)).fetchone()[0]
        for v1, v2, text in d['items']:
            if v2 > maxv:
                bad.append('시 %d — 절 %d-%d 이 범위 밖(최대 %d)' % (n, v1, v2, maxv))
            if '<' in text and '>' in text:
                bad.append('시 %d:%d — 태그 잔재' % (n, v1))
        if not d['intro']:
            bad.append('시 %d — 서론이 비었다' % n)
        cover = set()
        for v1, v2, _ in d['items']:
            cover.update(range(v1, v2 + 1))
        out.append((n, len(d['intro']), len(d['items']), len(cover), maxv))
    if verbose:
        for n, ilen, nitem, ncov, maxv in out:
            print('시 %3d — 서론 %5d자 · 절 항목 %2d개 · 절 커버 %d/%d'
                  % (n, ilen, nitem, ncov, maxv))
        for b in bad:
            print('  ✗', b)
    return bad


# ── 적재 (멱등 — 시편 단위 delete → insert) ──────────────────────────────

def parse_notes(path):
    """psNNN.php 의 EXPLANATORY NOTES 절 → {'psalm', 'whole', 'items'}.

    2차(2026-08-17) — 타 저자 인용 모음. 스펄전 본문(TREASURY)과 갈라
    **별도 소스(TREASURY_NOTE)** 로 담는다. 경계 = NAME="expl" ~
    NAME="hint"(없으면 othe/끝). HINTS(설교자용 개요)는 넣지 않는다 —
    평신도 앱 원칙(§18-4).
    """
    h = io.open(path, encoding='utf-8', errors='replace').read()
    m = re.search(r'(?i)<H1>Psalm (\d+)</H1>', h)
    if not m:
        raise ValueError('%s — Psalm 머리글이 없다' % path)
    n = int(m.group(1))

    def _ifind(needle, start=0):
        i = h.find(needle, start)
        return i if i >= 0 else h.find(needle.lower(), start)

    i0 = _ifind('NAME="expl"')
    if i0 < 0:
        return {'psalm': n, 'whole': '', 'items': []}
    ends = [i for i in (_ifind('NAME="hint"', i0 + 1),
                        _ifind('NAME="othe"', i0 + 1)) if i > i0]
    i1 = min(ends) if ends else len(h)
    if ends:
        i1 = h.rfind('<', 0, i1)       # 반쪽 태그 되감기 (1차와 같은 교훈)
    body = _clean(h[i0:i1])

    whole_parts, agg, order = [], {}, []
    marks = list(_NMARK.finditer(body))
    for i, mk in enumerate(marks):
        end = marks[i + 1].start() if i + 1 < len(marks) else len(body)
        text = body[mk.end():end].strip()
        if not text:
            continue
        if mk.group(0).startswith('Whole'):
            whole_parts.append(text)
        else:
            v1 = int(mk.group(1))
            v2 = int(mk.group(2)) if mk.group(2) else v1
            if v2 < v1:
                v1, v2 = v2, v1
            key = (v1, v2)
            if key not in agg:
                agg[key] = []
                order.append(key)
            agg[key].append(text)
    items = [(v1, v2, '\n'.join(agg[(v1, v2)])) for v1, v2 in order]
    return {'psalm': n, 'whole': '\n'.join(whole_parts), 'items': items}


# ── 시 119 특별 경로 (2026-08-17) ─────────────────────────────────────────
# ⚠ archive.spurgeon.org 는 ps119.php 가 **HTTP 500** 이고, 목차가 시 119 만
#   외부(StudyLight)로 넘긴다 — 너무 커서 자체 페이지가 없다(미러도 같음,
#   Wayback 에도 없음). StudyLight 는 봇 차단(403), biblestudytools 는 JS 렌더.
# ⇒ GitHub 의 마크다운판(lyteword/chspurgeon-tod, **CC0**)을 쓴다. 실측 —
#   본문이 진본 ToD 이고 스펄전 본문(Exposition)과 타 저자 인용(Explanatory
#   Notes)이 이미 절 단위·섹션 단위로 갈라져 있다. 22개 옥타브 파일 + 서론.

P119_RAW_URL = ('https://raw.githubusercontent.com/lyteword/chspurgeon-tod/'
                'main/volume-6/psalm-119/')
P119_FILES = ['_index.md'] + ['verses-%d-%d.md' % (a, a + 7)
                              for a in range(1, 170, 8)]


def fetch_119():
    import time
    os.makedirs(RAW, exist_ok=True)
    for name in P119_FILES:
        p = os.path.join(RAW, 'ps119_' + name.replace('_', ''))
        if os.path.exists(p):
            continue
        req = urllib.request.Request(P119_RAW_URL + name,
                                     headers={'User-Agent': 'Mozilla/5.0'})
        data = urllib.request.urlopen(req, timeout=60).read()
        io.open(p, 'wb').write(data)
        print('119/%s %d bytes' % (name, len(data)))
        time.sleep(1)


def _md_clean(s):
    """마크다운 → 평문. 문단 = 빈 줄 → '\\n' 하나(1차 적재 문체와 동일)."""
    # front matter 제거
    s = re.sub(r'(?s)\A---\n.*?\n---\n', '', s)
    for k, v in _ENT.items():
        s = s.replace(k, v)
    s = s.replace('&mdash;', '—')
    out = []
    for ln in s.split('\n'):
        t = ln.strip()
        if t.startswith('#'):
            continue                      # 헤딩은 구조 표식 — 본문에서 뺀다
        t = re.sub(r'^>\s?', '', t)       # 인용 블록(절 본문) 벗기기
        t = t.replace('**', '').replace('*', '')
        out.append(t)
    # 빈 줄 기준 문단 되붙이기
    paras, cur = [], []
    for t in out:
        if t:
            cur.append(t)
        elif cur:
            paras.append(' '.join(cur)); cur = []
    if cur:
        paras.append(' '.join(cur))
    return '\n'.join(paras)


def parse_119():
    """→ {'psalm': 119, 'intro': str, 'items': [(v, v, text)]}"""
    idx = io.open(os.path.join(RAW, 'ps119_index.md'),
                  encoding='utf-8', errors='replace').read()
    m = re.search(r'(?m)^# Psalm 119\s*$', idx)
    n = re.search(r'(?m)^## Notes Relating', idx)
    intro = _md_clean(idx[m.end():(n.start() if n else len(idx))]) if m else ''

    items = []
    for name in P119_FILES[1:]:
        body = io.open(os.path.join(RAW, 'ps119_' + name),
                       encoding='utf-8', errors='replace').read()
        marks = list(re.finditer(r'(?m)^## Exposition Verse (\d+)\s*$', body))
        for i, mk in enumerate(marks):
            v = int(mk.group(1))
            end = marks[i + 1].start() if i + 1 < len(marks) else len(body)
            seg = body[mk.end():end]
            # 타 저자 인용·설교 힌트 섹션 앞에서 끊는다 (1차 = 스펄전 본문만)
            cut = re.search(r'(?m)^###\s', seg)
            if cut:
                seg = seg[:cut.start()]
            text = _md_clean(seg)
            if text:
                items.append((v, v, text))
    return {'psalm': 119, 'intro': intro.strip(), 'items': items}


def apply_119(conn):
    d = parse_119()
    if len(d['items']) != 176:
        raise ValueError('시 119 절 항목이 176이 아니라 %d' % len(d['items']))
    if '#' in d['intro'] or any('#' in t for _, _, t in d['items']):
        raise ValueError('시 119 — 마크다운 잔재(#)')
    sid = ensure_source(conn)
    vids = {v: vid for v, vid in conn.execute(
        'SELECT verse, verse_id FROM bible_index WHERE bcode=? AND chapter=119',
        (PSA_BCODE,))}
    old = [r[0] for r in conn.execute(
        'SELECT entry_id FROM sys_commentary_entry WHERE commentary_id=? '
        "AND bcode='PSA' AND chapter=119", (sid,))]
    if old:
        q = ','.join('?' * len(old))
        conn.execute('DELETE FROM sys_commentary_text WHERE entry_id IN (%s)'
                     % q, old)
        conn.execute('DELETE FROM sys_commentary_entry WHERE entry_id IN (%s)'
                     % q, old)
    first, last = min(vids.values()), max(vids.values())
    cur = conn.execute(
        "INSERT INTO sys_commentary_entry (commentary_id, entry_level, "
        "bcode, start_vid, end_vid, chapter, record_status) "
        "VALUES (?, 'CHAPTER', 'PSA', ?, ?, 119, 'LIVE')", (sid, first, last))
    conn.execute("INSERT INTO sys_commentary_text (entry_id, text_variant, "
                 "lang_code, body_text, record_status) "
                 "VALUES (?, 'ORIGINAL', 'EN', ?, 'LIVE')",
                 (cur.lastrowid, d['intro']))
    total = 0
    for v1, v2, text in d['items']:
        a = vids.get(v1)
        if a is None:
            continue
        cur = conn.execute(
            "INSERT INTO sys_commentary_entry (commentary_id, entry_level, "
            "bcode, start_vid, end_vid, chapter, record_status) "
            "VALUES (?, 'VERSE', 'PSA', ?, NULL, 119, 'LIVE')", (sid, a))
        conn.execute("INSERT INTO sys_commentary_text (entry_id, "
                     "text_variant, lang_code, body_text, record_status) "
                     "VALUES (?, 'ORIGINAL', 'EN', ?, 'LIVE')",
                     (cur.lastrowid, text))
        total += 1
    conn.commit()
    print('시 119 — 서론 %d자 · 절 항목 %d' % (len(d['intro']), total))
    return total


_NMARK_MD = re.compile(r'^\*\*Verses?\s+(\d+)\s*(?:-\s*(\d+))?\s*(?:&mdash;|—)?\s*\*\*\s*')


def parse_notes_119():
    """시 119 의 EXPLANATORY NOTES — 마크다운판. → {'whole', 'items'}.

    구조(실측): 옥타브 파일마다 절 단위로 `### Explanatory Notes and Quaint
    Sayings` 섹션이 있고, 항목은 `**Verses 1-8 &mdash;**`/`**Verse N &mdash;**`
    로 시작하는 문단 + 표식 없는 이어짐 문단. HINTS(`### Hints to Preachers`)는
    1차 정책대로 뺀다. 시편 전체 노트는 _index.md 의
    「Notes Relating to the Psalm as a Whole」.
    """
    idx = io.open(os.path.join(RAW, 'ps119_index.md'),
                  encoding='utf-8', errors='replace').read()
    m = re.search(r'(?m)^## Notes Relating to the Psalm as a Whole\s*$', idx)
    whole = ''
    if m:
        seg = idx[m.end():]
        cut = seg.find('{{<')            # Hugo 목차 카드 블록 — 본문이 아니다
        if cut >= 0:
            seg = seg[:cut]
        whole = _md_clean(seg)

    agg, order = {}, []
    for name in P119_FILES[1:]:
        body = io.open(os.path.join(RAW, 'ps119_' + name),
                       encoding='utf-8', errors='replace').read()
        for sec in re.finditer(
                r'(?ms)^### Explanatory Notes and Quaint Sayings\s*$'
                r'(.*?)(?=^###? |\Z)', body):
            seg = sec.group(1)
            cur_key = None
            for para in re.split(r'\n\s*\n', seg):
                para = para.strip()
                if not para:
                    continue
                mk = _NMARK_MD.match(para)
                if mk:
                    v1 = int(mk.group(1))
                    v2 = int(mk.group(2)) if mk.group(2) else v1
                    if v2 < v1:
                        v1, v2 = v2, v1
                    cur_key = (v1, v2)
                    para = para[mk.end():]
                if cur_key is None:
                    continue                     # 표식 전 머리글 등
                text = _md_clean(para)
                if not text:
                    continue
                if cur_key not in agg:
                    agg[cur_key] = []
                    order.append(cur_key)
                agg[cur_key].append(text)
    items = [(v1, v2, '\n'.join(agg[(v1, v2)])) for v1, v2 in order]
    return {'whole': whole.strip(), 'items': items}


def apply_notes_119(conn):
    d = parse_notes_119()
    if not d['items']:
        raise ValueError('시 119 노트 — 항목 0')
    sid = ensure_note_source(conn)
    vids = {v: vid for v, vid in conn.execute(
        'SELECT verse, verse_id FROM bible_index WHERE bcode=? AND chapter=119',
        (PSA_BCODE,))}
    old = [r[0] for r in conn.execute(
        'SELECT entry_id FROM sys_commentary_entry WHERE commentary_id=? '
        "AND bcode='PSA' AND chapter=119", (sid,))]
    if old:
        q = ','.join('?' * len(old))
        conn.execute('DELETE FROM sys_commentary_text WHERE entry_id IN (%s)'
                     % q, old)
        conn.execute('DELETE FROM sys_commentary_entry WHERE entry_id IN (%s)'
                     % q, old)
    total = {'chap': 0, 'verse': 0}
    if d['whole']:
        first, last = min(vids.values()), max(vids.values())
        cur = conn.execute(
            "INSERT INTO sys_commentary_entry (commentary_id, entry_level, "
            "bcode, start_vid, end_vid, chapter, record_status) "
            "VALUES (?, 'CHAPTER', 'PSA', ?, ?, 119, 'LIVE')",
            (sid, first, last))
        conn.execute("INSERT INTO sys_commentary_text (entry_id, "
                     "text_variant, lang_code, body_text, record_status) "
                     "VALUES (?, 'ORIGINAL', 'EN', ?, 'LIVE')",
                     (cur.lastrowid, d['whole']))
        total['chap'] = 1
    for v1, v2, text in d['items']:
        a = vids.get(v1)
        b = vids.get(v2)
        if a is None:
            continue
        cur = conn.execute(
            "INSERT INTO sys_commentary_entry (commentary_id, entry_level, "
            "bcode, start_vid, end_vid, chapter, record_status) "
            "VALUES (?, 'VERSE', 'PSA', ?, ?, 119, 'LIVE')",
            (sid, a, (b if b != a else None)))
        conn.execute("INSERT INTO sys_commentary_text (entry_id, "
                     "text_variant, lang_code, body_text, record_status) "
                     "VALUES (?, 'ORIGINAL', 'EN', ?, 'LIVE')",
                     (cur.lastrowid, text))
        total['verse'] += 1
    conn.commit()
    print('시 119 노트 — 전체 %(chap)d · 절 항목 %(verse)d' % total)
    return total


# ── 3차: HINTS (설교 개요) — 사역자용 확장 (2026-08-17 사용자 승인) ──────────
# 「기본=평신도용, 확장=사역자용」 — 별도 소스(TREASURY_HINT)로 갈라 두어
# 나중에 확장팩 배포·화면 토글로 켜고 끌 수 있게 한다.

HINT_CODE = 'TREASURY_HINT'


def ensure_hint_source(conn):
    r = conn.execute('SELECT commentary_id FROM sys_commentary_source '
                     'WHERE commentary_code=?', (HINT_CODE,)).fetchone()
    if r:
        return r[0]
    cur = conn.execute(
        "INSERT INTO sys_commentary_source (commentary_code, title, author, "
        "pub_year, lang_code, coverage_scope, copyright_type, source_url, "
        "description, record_status, title_ko) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (HINT_CODE, 'The Treasury of David — Hints to the Preacher',
         'C. H. Spurgeon and contributors', 1885, 'EN',
         'OT_ONLY', 'PUBLIC_DOMAIN',
         'https://archive.spurgeon.org/treasury/treasury.php',
         'Sermon outline hints from the Treasury of David ("Hints to the '
         'Village Preacher"). Kept as a separate source: base app is for '
         'lay readers, this source is the minister-oriented extension.',
         'LIVE', '스펄전 시편 설교 힌트'))
    return cur.lastrowid


def parse_hints(path):
    """psNNN.php 의 HINTS 절 → {'psalm', 'whole', 'items'} (노트와 같은 얼개).
    경계 = NAME="hint" ~ NAME="othe"(없으면 끝)."""
    h = io.open(path, encoding='utf-8', errors='replace').read()
    m = re.search(r'(?i)<H1>Psalm (\d+)</H1>', h)
    if not m:
        raise ValueError('%s — Psalm 머리글이 없다' % path)
    n = int(m.group(1))

    def _ifind(needle, start=0):
        i = h.find(needle, start)
        return i if i >= 0 else h.find(needle.lower(), start)

    i0 = _ifind('NAME="hint"')
    if i0 < 0:
        return {'psalm': n, 'whole': '', 'items': []}
    i1 = _ifind('NAME="othe"', i0 + 1)
    if i1 > i0:
        i1 = h.rfind('<', 0, i1)
    else:
        i1 = len(h)
    body = _clean(h[i0:i1])

    whole_parts, agg, order = [], {}, []
    marks = list(_NMARK.finditer(body))
    for i, mk in enumerate(marks):
        end = marks[i + 1].start() if i + 1 < len(marks) else len(body)
        text = body[mk.end():end].strip()
        if not text:
            continue
        if mk.group(0).startswith('Whole'):
            whole_parts.append(text)
        else:
            v1 = int(mk.group(1))
            v2 = int(mk.group(2)) if mk.group(2) else v1
            if v2 < v1:
                v1, v2 = v2, v1
            key = (v1, v2)
            if key not in agg:
                agg[key] = []
                order.append(key)
            agg[key].append(text)
    items = [(v1, v2, '\n'.join(agg[(v1, v2)])) for v1, v2 in order]
    return {'psalm': n, 'whole': '\n'.join(whole_parts), 'items': items}


def parse_hints_119():
    """시 119 의 HINTS — 마크다운판 `### Hints to Preachers` 섹션."""
    agg, order = {}, []
    for name in P119_FILES[1:]:
        body = io.open(os.path.join(RAW, 'ps119_' + name),
                       encoding='utf-8', errors='replace').read()
        for sec in re.finditer(
                r'(?ms)^### Hints to Preachers\s*$'
                r'(.*?)(?=^###? |\Z)', body):
            seg = sec.group(1)
            cur_key = None
            for para in re.split(r'\n\s*\n', seg):
                para = para.strip()
                if not para:
                    continue
                mk = _NMARK_MD.match(para)
                if mk:
                    v1 = int(mk.group(1))
                    v2 = int(mk.group(2)) if mk.group(2) else v1
                    if v2 < v1:
                        v1, v2 = v2, v1
                    cur_key = (v1, v2)
                    para = para[mk.end():]
                if cur_key is None:
                    continue
                text = _md_clean(para)
                if not text:
                    continue
                if cur_key not in agg:
                    agg[cur_key] = []
                    order.append(cur_key)
                agg[cur_key].append(text)
    items = [(v1, v2, '\n'.join(agg[(v1, v2)])) for v1, v2 in order]
    return {'whole': '', 'items': items}


def _apply_hint_like(conn, sid, chapter, whole, items):
    """한 시편의 (whole, items) 를 sid 소스로 멱등 적재 — 힌트·노트 공용 얼개."""
    vids = {v: vid for v, vid in conn.execute(
        'SELECT verse, verse_id FROM bible_index WHERE bcode=? AND chapter=?',
        (PSA_BCODE, chapter))}
    old = [r[0] for r in conn.execute(
        'SELECT entry_id FROM sys_commentary_entry WHERE commentary_id=? '
        "AND bcode='PSA' AND chapter=?", (sid, chapter))]
    if old:
        q = ','.join('?' * len(old))
        conn.execute('DELETE FROM sys_commentary_text WHERE entry_id IN (%s)'
                     % q, old)
        conn.execute('DELETE FROM sys_commentary_entry WHERE entry_id IN (%s)'
                     % q, old)
    total = {'chap': 0, 'verse': 0}
    if whole:
        first, last = min(vids.values()), max(vids.values())
        cur = conn.execute(
            "INSERT INTO sys_commentary_entry (commentary_id, entry_level, "
            "bcode, start_vid, end_vid, chapter, record_status) "
            "VALUES (?, 'CHAPTER', 'PSA', ?, ?, ?, 'LIVE')",
            (sid, first, last, chapter))
        conn.execute("INSERT INTO sys_commentary_text (entry_id, "
                     "text_variant, lang_code, body_text, record_status) "
                     "VALUES (?, 'ORIGINAL', 'EN', ?, 'LIVE')",
                     (cur.lastrowid, whole))
        total['chap'] = 1
    for v1, v2, text in items:
        a = vids.get(v1)
        b = vids.get(v2)
        if a is None:
            continue
        cur = conn.execute(
            "INSERT INTO sys_commentary_entry (commentary_id, entry_level, "
            "bcode, start_vid, end_vid, chapter, record_status) "
            "VALUES (?, 'VERSE', 'PSA', ?, ?, ?, 'LIVE')",
            (sid, a, (b if b != a else None), chapter))
        conn.execute("INSERT INTO sys_commentary_text (entry_id, "
                     "text_variant, lang_code, body_text, record_status) "
                     "VALUES (?, 'ORIGINAL', 'EN', ?, 'LIVE')",
                     (cur.lastrowid, text))
        total['verse'] += 1
    return total


def apply_hints(conn, psalms):
    sid = ensure_hint_source(conn)
    total = {'chap': 0, 'verse': 0}
    for n in psalms:
        if n == 119:
            d = parse_hints_119()
        else:
            d = parse_hints(os.path.join(RAW, 'ps%03d.php' % n))
        t = _apply_hint_like(conn, sid, n, d['whole'], d['items'])
        total['chap'] += t['chap']
        total['verse'] += t['verse']
    conn.commit()
    return total


NOTE_CODE = 'TREASURY_NOTE'


def ensure_note_source(conn):
    r = conn.execute('SELECT commentary_id FROM sys_commentary_source '
                     'WHERE commentary_code=?', (NOTE_CODE,)).fetchone()
    if r:
        return r[0]
    cur = conn.execute(
        "INSERT INTO sys_commentary_source (commentary_code, title, author, "
        "pub_year, lang_code, coverage_scope, copyright_type, source_url, "
        "description, record_status, title_ko) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (NOTE_CODE, 'The Treasury of David — Explanatory Notes',
         'Various authors, compiled by C. H. Spurgeon', 1885, 'EN',
         'OT_ONLY', 'PUBLIC_DOMAIN',
         'https://archive.spurgeon.org/treasury/treasury.php',
         'Explanatory Notes and Quaint Sayings from the Treasury of David: '
         'quotations from Puritan and other authors, gathered per verse by '
         'Spurgeon. Kept as a separate source so the TREASURY source stays '
         "Spurgeon's own words only.",
         'LIVE', '스펄전 시편 인용 모음'))
    return cur.lastrowid


def apply_notes(conn, psalms):
    sid = ensure_note_source(conn)
    total = {'chap': 0, 'verse': 0}
    for n in psalms:
        d = parse_notes(os.path.join(RAW, 'ps%03d.php' % n))
        vids = {v: vid for v, vid in conn.execute(
            'SELECT verse, verse_id FROM bible_index WHERE bcode=? AND chapter=?',
            (PSA_BCODE, n))}
        old = [r[0] for r in conn.execute(
            'SELECT entry_id FROM sys_commentary_entry WHERE commentary_id=? '
            "AND bcode='PSA' AND chapter=?", (sid, n))]
        if old:
            q = ','.join('?' * len(old))
            conn.execute('DELETE FROM sys_commentary_text WHERE entry_id IN (%s)'
                         % q, old)
            conn.execute('DELETE FROM sys_commentary_entry WHERE entry_id IN (%s)'
                         % q, old)
        if d['whole']:
            first, last = min(vids.values()), max(vids.values())
            cur = conn.execute(
                "INSERT INTO sys_commentary_entry (commentary_id, entry_level, "
                "bcode, start_vid, end_vid, chapter, record_status) "
                "VALUES (?, 'CHAPTER', 'PSA', ?, ?, ?, 'LIVE')",
                (sid, first, last, n))
            conn.execute("INSERT INTO sys_commentary_text (entry_id, "
                         "text_variant, lang_code, body_text, record_status) "
                         "VALUES (?, 'ORIGINAL', 'EN', ?, 'LIVE')",
                         (cur.lastrowid, d['whole']))
            total['chap'] += 1
        for v1, v2, text in d['items']:
            a = vids.get(v1)
            b = vids.get(v2)
            if a is None:
                continue
            cur = conn.execute(
                "INSERT INTO sys_commentary_entry (commentary_id, entry_level, "
                "bcode, start_vid, end_vid, chapter, record_status) "
                "VALUES (?, 'VERSE', 'PSA', ?, ?, ?, 'LIVE')",
                (sid, a, (b if b != a else None), n))
            conn.execute("INSERT INTO sys_commentary_text (entry_id, "
                         "text_variant, lang_code, body_text, record_status) "
                         "VALUES (?, 'ORIGINAL', 'EN', ?, 'LIVE')",
                         (cur.lastrowid, text))
            total['verse'] += 1
    conn.commit()
    return total


def ensure_source(conn):
    r = conn.execute('SELECT commentary_id FROM sys_commentary_source '
                     'WHERE commentary_code=?', (CODE,)).fetchone()
    if r:
        return r[0]
    cur = conn.execute(
        "INSERT INTO sys_commentary_source (commentary_code, title, author, "
        "pub_year, lang_code, coverage_scope, copyright_type, source_url, "
        "description, record_status, title_ko) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (CODE, 'The Treasury of David', 'Charles H. Spurgeon', 1885, 'EN',
         'OT_ONLY', 'PUBLIC_DOMAIN',
         'https://archive.spurgeon.org/treasury/treasury.php',
         'Spurgeon\'s verse-by-verse exposition of the Psalms. '
         'First pass: Spurgeon\'s own text only (psalm introduction + '
         'exposition). Explanatory Notes and Hints deferred.',
         'LIVE', '스펄전 시편 강해'))
    return cur.lastrowid


def apply(conn, psalms):
    sid = ensure_source(conn)
    total = {'chap': 0, 'verse': 0}
    for n in psalms:
        d = parse(os.path.join(RAW, 'ps%03d.php' % n))
        vids = {v: vid for v, vid in conn.execute(
            'SELECT verse, verse_id FROM bible_index WHERE bcode=? AND chapter=?',
            (PSA_BCODE, n))}
        # 멱등 — 이 시편의 기존 TREASURY 항목을 지우고 다시 넣는다
        old = [r[0] for r in conn.execute(
            'SELECT entry_id FROM sys_commentary_entry WHERE commentary_id=? '
            "AND bcode='PSA' AND chapter=?", (sid, n))]
        if old:
            q = ','.join('?' * len(old))
            conn.execute('DELETE FROM sys_commentary_text WHERE entry_id IN (%s)'
                         % q, old)
            conn.execute('DELETE FROM sys_commentary_entry WHERE entry_id IN (%s)'
                         % q, old)
        # 서론 = CHAPTER 항목 (GILL 장서론과 같은 자리)
        first, last = min(vids.values()), max(vids.values())
        cur = conn.execute(
            "INSERT INTO sys_commentary_entry (commentary_id, entry_level, "
            "bcode, start_vid, end_vid, chapter, record_status) "
            "VALUES (?, 'CHAPTER', 'PSA', ?, ?, ?, 'LIVE')", (sid, first, last, n))
        conn.execute("INSERT INTO sys_commentary_text (entry_id, text_variant, "
                     "lang_code, body_text, record_status) "
                     "VALUES (?, 'ORIGINAL', 'EN', ?, 'LIVE')",
                     (cur.lastrowid, d['intro']))
        total['chap'] += 1
        for v1, v2, text in d['items']:
            a = vids.get(v1)
            b = vids.get(v2)
            if a is None:
                continue
            cur = conn.execute(
                "INSERT INTO sys_commentary_entry (commentary_id, entry_level, "
                "bcode, start_vid, end_vid, chapter, record_status) "
                "VALUES (?, 'VERSE', 'PSA', ?, ?, ?, 'LIVE')",
                (sid, a, (b if b != a else None), n))
            conn.execute("INSERT INTO sys_commentary_text (entry_id, "
                         "text_variant, lang_code, body_text, record_status) "
                         "VALUES (?, 'ORIGINAL', 'EN', ?, 'LIVE')",
                         (cur.lastrowid, text))
            total['verse'] += 1
    conn.commit()
    return total


# ── 자가검증 ──────────────────────────────────────────────────────────────

FIXTURE = """<HTML><CENTER><H1>Psalm 3</H1></CENTER>
<A HREF="/treasury/ps003.php#expo">Exposition</A><BR>
<FONT SIZE="-1">TITLE. <I>A Psalm of David.</I><P>
DIVISION. <I>Two parts&#151;first the trouble, then the trust.</I><P></FONT>
<HR><CENTER><A NAME="expo">EXPOSITION</A></CENTER>
Verse 1. <I>"LORD, how are they increased"</I> the enemies multiply.<P>
Verses 2, 3. Many there be which say&#151;yet thou art a shield.<P>
Verses 5-6. I laid me down and slept.<P>
<CENTER><A NAME="expl">EXPLANATORY NOTES AND QUAINT SAYINGS</A></CENTER>
Whole Psalm. A quote about the whole psalm.&#151;John Owen.<P>
Verse 1. First quote on verse one.&#151;Thomas Watson.<P>
Verse 1. Second quote on verse one.&#151;Matthew Henry.<P>
Verses 2, 3. A quote on the pair.&#151;David Dickson.<P>
<CENTER><A NAME="hint">HINTS TO THE VILLAGE PREACHER</A></CENTER>
Verse 1. Preacher outline that must NOT be imported.<P>
</HTML>"""


def selftest():
    ok = True
    os.makedirs(RAW, exist_ok=True)
    p = os.path.join(RAW, 'ps999.php')
    io.open(p, 'w', encoding='utf-8').write(FIXTURE)
    try:
        d = parse(p)
        if d['psalm'] != 3:
            print('FAIL 시편 번호'); ok = False
        if 'TITLE' not in d['intro'] or 'DIVISION' not in d['intro']:
            print('FAIL 서론 추출: %r' % d['intro'][:60]); ok = False
        if 'EXPOSITION' in d['intro'] or 'Exposition' in d['intro']:
            print('FAIL 서론에 안내 링크·제목이 샜다'); ok = False
        if '<' in d['intro']:
            # 절단점이 <A NAME="expo"> 한가운데면 서론 끝에 반쪽 태그 `<A` 가
            # 남는다 — 실제로 새 나가 사용자가 잡았다(2026-08-17)
            print('FAIL 서론에 반쪽 태그 잔재: %r' % d['intro'][-20:]); ok = False
        spans = [(v1, v2) for v1, v2, _ in d['items']]
        if spans != [(1, 1), (2, 3), (5, 6)]:
            print('FAIL 절 표식 파싱: %s' % spans); ok = False
        if '—' not in d['items'][1][2]:
            print('FAIL 엠대시 실체참조가 안 풀렸다'); ok = False
        if any('<' in t or 'Owen' in t for _, _, t in d['items']):
            print('FAIL 태그 잔재 또는 EXPLANATORY 침범'); ok = False
        # 2차 — EXPLANATORY NOTES 파싱 (표식 반복은 절 단위로 합침, HINTS 제외)
        dn = parse_notes(p)
        if 'John Owen' not in dn['whole']:
            print('FAIL 노트 Whole Psalm: %r' % dn['whole'][:40]); ok = False
        nspans = [(v1, v2) for v1, v2, _ in dn['items']]
        if nspans != [(1, 1), (2, 3)]:
            print('FAIL 노트 절 표식/합침: %s' % nspans); ok = False
        if dn['items'] and not ('Watson' in dn['items'][0][2]
                                and 'Henry' in dn['items'][0][2]):
            print('FAIL 노트 같은 절 인용 합침'); ok = False
        if any('NOT be imported' in t for _, _, t in dn['items']) \
                or 'NOT be imported' in dn['whole']:
            print('FAIL HINTS 침범'); ok = False
        if '<' in dn['whole'] or any('<' in t for _, _, t in dn['items']):
            print('FAIL 노트 태그 잔재'); ok = False
        # 3차 — HINTS 파싱 (노트에는 없고, 힌트에는 있어야)
        dh = parse_hints(p)
        if [(v1, v2) for v1, v2, _ in dh['items']] != [(1, 1)]                 or 'NOT be imported' not in dh['items'][0][2]:
            print('FAIL 힌트 파싱: %s' % dh['items']); ok = False
        # 시 119 마크다운 정리 — front matter·헤딩 제거, 인용 벗기기, 문단 '\n'
        md = ('---\ntitle: "x"\n---\n\n# H\n\n> Blessed *are* the men.\n\n'
              'First **bold** and *italic* line\ncontinues here.\n\n'
              'Second para&mdash;with dash.\n')
        got = _md_clean(md)
        want = ('Blessed are the men.\n'
                'First bold and italic line continues here.\n'
                'Second para—with dash.')
        if got != want:
            print('FAIL 119 마크다운 정리: %r' % got); ok = False
        # 소문자 태그 판 — 실제 소스 26편 중 10편이 <h1>, ps004 는 <a name="expo">
        io.open(p, 'w', encoding='utf-8').write(
            FIXTURE.replace('<H1>', '<h1>').replace('</H1>', '</h1>')
                   .replace('<A NAME=', '<a name=').replace('</A>', '</a>'))
        d2 = parse(p)
        if d2['psalm'] != 3 or len(d2['items']) != len(d['items']) \
                or '<' in d2['intro'] or 'TITLE' not in d2['intro']:
            print('FAIL 소문자 태그 판 파싱'); ok = False
        # 실 DB 로 검사기 — 범위 밖 절을 잡는가 (시 3 은 8절까지)
        conn = appdb.connect(DB)
        try:
            if check(conn, [999] if False else [], verbose=False):
                print('FAIL 빈 검사 목록이 실패를 낸다'); ok = False
        finally:
            conn.close()
    finally:
        os.remove(p)
    print('db_treasury_import selftest', 'OK' if ok else 'FAIL')
    return ok


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--fetch', nargs=2, type=int, metavar=('FROM', 'TO'))
    ap.add_argument('--check', nargs='+', type=int)
    ap.add_argument('--apply', nargs='+', type=int)
    ap.add_argument('--apply-notes', nargs='+', type=int,
                    help='2차 — EXPLANATORY NOTES 를 TREASURY_NOTE 소스로 적재')
    ap.add_argument('--apply-hints', nargs='+', type=int,
                    help='3차 — HINTS(설교 개요)를 TREASURY_HINT 소스로 적재')
    ap.add_argument('--apply-119', action='store_true',
                    help='시 119 — GitHub 마크다운판(CC0)에서 적재')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    if a.fetch:
        fetch(a.fetch[0], a.fetch[1])
        return
    conn = appdb.connect(DB)
    try:
        if a.check:
            sys.exit(1 if check(conn, a.check) else 0)
        if a.apply:
            bad = check(conn, a.apply, verbose=True)
            if bad:
                print('검사 실패 — 적재 중단')
                sys.exit(1)
            t = apply(conn, a.apply)
            print('적재 — 서론(CHAPTER) %(chap)d · 절 항목 %(verse)d' % t)
            return
        if a.apply_notes:
            psalms = list(a.apply_notes)
            if 119 in psalms:               # 시 119 노트는 마크다운판 경로
                psalms.remove(119)
                apply_notes_119(conn)
            if psalms:
                t = apply_notes(conn, psalms)
                print('노트 적재 — 시편 전체(CHAPTER) %(chap)d · 절 항목 %(verse)d' % t)
            return
        if a.apply_hints:
            t = apply_hints(conn, a.apply_hints)
            print('힌트 적재 — 시편 전체(CHAPTER) %(chap)d · 절 항목 %(verse)d' % t)
            return
        if a.apply_119:
            fetch_119()
            apply_119(conn)
            return
        print(__doc__.split('\n')[0])
    finally:
        conn.close()


if __name__ == '__main__':
    main()
