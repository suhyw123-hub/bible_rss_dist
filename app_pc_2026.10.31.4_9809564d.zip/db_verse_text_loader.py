# -*- coding: utf-8 -*-
"""db_verse_text_loader.py — 구절 관련 2티어 텍스트 일괄 적재(sys_text_asset).

JSON 포맷(리스트):
  {"clicked_id": 71, "text_type": "VERS_DESC", "lang_code": "KO",
   "text_variant": "EXPERT"|"LAY"|null, "contents": "..."}
- text_variant 생략/null = 단일(VERS_PRAYER 등) 또는 레거시.
- VERS_VERS_DESC 의 clicked_id 는 sys_link_id(연결 PK).
키 (clicked_id, text_type, lang_code, COALESCE(text_variant,'')) 단위로 delete→insert (멱등).

사용:
  python db_verse_text_loader.py <draft.json>            # 검사 통과해야 적재된다
  python db_verse_text_loader.py <draft.json> --force     # 검사 무시하고 강행
  python db_verse_text_loader.py --selftest               # 탐지력 확인 (의무)

★ 적재 전 검사가 **기본**이다 (2026-08-07 신설).
  그전까지 이 파일은 46줄이고 검증이 한 줄도 없었다. 받은 JSON 을 그대로 넣었고,
  검사는 사람이 `db_vers_gate` 를 **자발적으로** 돌릴 때만 일어났다.
  실측이 그 구멍의 대가를 보여 준다 — 출애굽기 신규 집필 47절에서 초안 위반이 약 69건
  (절당 1.5)이었다. 매번 손으로 걸렀기에 들어가지 않았을 뿐, 그건 규율이지 보장이 아니다.
  창세기 1~8장의 얕은 EXPERT · LAY 절인용 14건 · 본문 재진술 1,114행이 전부 이 문으로 들어왔다.
  ⇒ **규칙이 아니라 문으로 만든다.** 잊어도 작동해야 한다.

⚠ 여기서 막는 것은 **절 단위 규격**이다. 장평균 길이비(`LEN_RATIO_AVG`)는 배치가 장의
  일부일 수 있어 적재 시점에 판정할 수 없다 — 그건 `db_vers_gate <bcode> <ch>` 의 몫이다.

⚠ EXPERT/LAY 짝은 **초안에 둘 다 없어도 검사한다.** 없는 쪽은 DB 에서 끌어온다.
  LAY 만 고치는 배치, EXPERT 만 보강하는 배치가 실제로 있고, 어느 쪽을 손대든 비율이 움직인다.
"""
import argparse
import sys

import appdb
from db_vers_gate import (PARA_MIN_SENT, QUOTE_RX, SENT_RX, TH, _is_yoche,
                          greek_count, has_apparatus, lay_cites,
                          new_word_ratio, new_word_ratio_en, sentences)

TIERED = ('VERS_DESC',)                       # EXPERT/LAY 짝 검사 대상
GATED = ('VERS_DESC', 'VERS_QUESTION', 'VERS_PRAYER')   # 요체·인용 검사 대상
# ★ 2026-08-09 — 문단 규격은 **설명문에만** 건다.
#   질문은 한 셀에 2~3개를 빈 줄로 나눠 담는 것이 규격이라(lay.md §5) 문단밀도가 2.0 이 된다.
#   기도문도 두 문단이 정상이다. 옛 규격(10행/절·질문 두 줄 고정)의 잔재를 여기서 끊는다.
PARA_GATED = ('VERS_DESC',)
# 설명문 문단밀도 하한. 분량 기준을 폐기하면서(lay.md §1) **2.5 → 2.0** 으로 내렸다.
# 짧은 절은 「2문단 4문장」이 정상이다 — 없는 말을 지어내 채우게 하던 문턱이었다.
PARA_DENS_MIN = 2.0
RATIO = {'KO': new_word_ratio, 'EN': new_word_ratio_en}


def _yoche_hits(txt):
    """한국어 본문의 요체 문장 수. 성경 인용 구간은 통째로 제외한다(게이트와 같은 규칙)."""
    body = QUOTE_RX.sub(' ', txt or '')
    return sum(1 for para in body.split('\n')
               for m in SENT_RX.finditer(para) if _is_yoche(m.group(0).strip()))


def _para_bad(txt):
    """문단 규격 위반 사유. 없으면 None."""
    ns = len(sentences(txt))
    if ns >= PARA_MIN_SENT and '\n\n' not in txt:
        return '문단없음 (%d문장)' % ns
    if '\n\n' in txt:
        ps = [p for p in txt.split('\n\n') if p.strip()]
        dens = sum(len(sentences(p)) for p in ps) / len(ps)
        if dens < PARA_DENS_MIN:
            return '문단밀도 %.2f (%d문장, 하한 %.1f)' % (dens, ns, PARA_DENS_MIN)
    return None


def gate(rows, conn=None):
    """적재 전 절 단위 검사. 위반 문자열 리스트를 돌려준다(빈 리스트 = 통과).

    conn 이 None 이면 DB 를 보지 않는다 — 초안 안에 짝이 다 있을 때만 짝 검사를 한다.
    """
    bad = []
    draft = {}
    for r in rows:
        key = (int(r['clicked_id']), r['text_type'], r.get('lang_code', 'KO'),
               r.get('text_variant') or None)
        draft[key] = r.get('contents') or ''

    # ── ① 행 단위: 빈 본문 · 문단 · 요체 ──────────────────────────────────
    for (cid, tt, lang, var), txt in sorted(draft.items()):
        tag = 'vid %d %s/%s/%s' % (cid, tt, lang, var or '-')
        if not txt.strip():
            bad.append('%s 비었다' % tag)
            continue
        if tt not in GATED:
            continue
        if tt in PARA_GATED:                  # 문단 규격은 설명문에만 (질문·기도 제외)
            m = _para_bad(txt)
            if m:
                bad.append('%s %s' % (tag, m))
        if lang == 'KO' and TH.get('YOCHE_ZERO', True):
            n = _yoche_hits(txt)
            if n:
                bad.append('%s 요체 %d건' % (tag, n))

    # ── ② 짝 단위: 길이비 · 신출어휘 · 학술장치 · 원어과밀 · LAY 절인용 ──
    def fetch(cid, tt, lang, var):
        if (cid, tt, lang, var) in draft:
            return draft[(cid, tt, lang, var)]
        if conn is None:
            return None
        r = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type=?"
            " AND lang_code=? AND text_variant=? AND COALESCE(record_status,'LIVE')='LIVE'",
            (cid, tt, lang, var)).fetchone()
        return r[0] if r else None

    seen = set()
    for (cid, tt, lang, var) in sorted(draft):
        if tt not in TIERED or var not in ('EXPERT', 'LAY') or (cid, tt, lang) in seen:
            continue
        seen.add((cid, tt, lang))
        e, l = fetch(cid, tt, lang, 'EXPERT'), fetch(cid, tt, lang, 'LAY')
        if not (e and l):
            continue
        tag = 'vid %d %s' % (cid, lang)
        # ★ 길이비 검사 삭제(2026-08-09 사용자 지시) — 두 티어가 다른 이야기를 하므로
        #   절에 따라 어느 쪽이든 길 수 있다. 적용이 중요한 절은 LAY 가 더 길어야 한다.
        #   길이비 0.60 이 통과하는데 문단 대각 겹침이 10.62 였다 — 자가 틀렸다(lay.md §1).
        s = RATIO.get(lang, new_word_ratio)(e, l)
        if s < TH['NEWWORD_MIN']:
            bad.append('%s 신출어휘 %.2f (하한 %.2f) — LAY 가 EXPERT 의 요약이다. 낱말을 갈 것'
                       % (tag, s, TH['NEWWORD_MIN']))
        if lang == 'KO':
            if not has_apparatus(e):
                bad.append('%s EXPERT 학술장치없음 (원어·상호참조·신학용어가 없다)' % tag)
            gk = greek_count(e)
            if gk > TH['GREEK_MAX_VERSE']:
                bad.append('%s EXPERT 원어과밀 %d (상한 %d)'
                           % (tag, gk, TH['GREEK_MAX_VERSE']))
            nc = lay_cites(l)
            if nc > TH['LAY_CITE_MAX']:
                bad.append('%s LAY 절인용 %d건' % (tag, nc))
    return bad


def load(path, force=False):
    import json
    with open(path, encoding='utf-8') as f:
        rows = json.load(f)
    conn = appdb.connect()

    bad = gate(rows, conn)
    if bad and not force:
        print('적재 거부 — 위반 %d건' % len(bad))
        for m in bad:
            print('  X ' + m)
        print()
        print('고친 뒤 다시 적재하라. 판단해 강행하려면 --force.')
        conn.close()
        return 1
    if bad:
        print('⚠ --force — 위반 %d건을 무시하고 적재한다.' % len(bad))

    c = conn.cursor()
    n_ins = 0
    for r in rows:
        cid = int(r['clicked_id'])
        tt = r['text_type']
        lang = r.get('lang_code', 'KO')
        var = r.get('text_variant') or None
        body = r.get('contents', '')
        if var is None:
            c.execute("DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type=? "
                      "AND lang_code=? AND text_variant IS NULL", (cid, tt, lang))
        else:
            c.execute("DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type=? "
                      "AND lang_code=? AND text_variant=?", (cid, tt, lang, var))
        c.execute("INSERT INTO sys_text_asset(clicked_id,text_type,contents,lang_code,"
                  "record_status,text_variant,created_at) VALUES(?,?,?,?, 'LIVE', ?, datetime('now'))",
                  (cid, tt, body, lang, var))
        n_ins += 1
    conn.commit()
    conn.close()
    print('loaded %d rows from %s' % (n_ins, path))
    return 0


def selftest():
    """★ 의무. 문이 실제로 닫히는지 본다 — **양방향**으로.

    통과만 확인하면 게이트가 통째로 죽어도 PASS 를 찍는다. 그래서 **막아야 하는 것**을
    사례별로 고정한다. 여기 든 다섯 가지는 전부 이번 세션에 실제로 난 위반이다.
    """
    print('db_verse_text_loader 자가 검증')
    bad = []

    E = ("뚜껑이 열리고 아이가 운다. 이 울음 하나가 이야기의 방향을 정한다. 아기가 한 일은 "
         "우는 것뿐인데, 그것이 제국의 칙령을 무너뜨리는 첫 힘이 된다.\n\n"
         "'불쌍히 여겨'로 옮겨진 낱말(하말, חָמַל)은 아까워 차마 해치지 못한다는 뜻을 담고 "
         "있다. 동정의 감정만이 아니라 손을 거두는 행동까지 포함하는 말이다. 그가 곧바로 "
         "히브리 사람의 아이라고 알아본 점이 중요하다.")
    GOOD = ("뚜껑이 젖혀지고 안에서 울음이 터집니다. 그 아기가 한 일이라고는 우는 것 "
            "하나뿐인데, 나라를 뒤흔든 지시가 거기서부터 무너지기 시작합니다.\n\n"
            "눈여겨볼 것은 그가 곧바로 히브리 아기임을 알아챘다는 점입니다. 몰라서 손을 내민 "
            "것이 아닙니다. 적힌 것은 무지가 아니라 선택입니다.")
    # ⚠ 이 표본은 **두 문단 전부를 경어체로 옮긴 것**이어야 한다. 한 문단만 옮기면
    #   어미 변경(된다→됩니다)만으로도 신출 어휘가 0.158 이 나와 하한을 넘는다.
    #   실제로 이번 세션에 난 실패가 바로 이 모양이다.
    SUMMARY = ("뚜껑이 열리고 아이가 웁니다. 이 울음 하나가 이야기의 방향을 정합니다. 아기가 "
               "한 일은 우는 것뿐인데, 그것이 제국의 칙령을 무너뜨리는 첫 힘이 됩니다.\n\n"
               "불쌍히 여겼다는 낱말은 아까워 차마 해치지 못한다는 뜻을 담고 있습니다. 동정의 "
               "감정만이 아니라 손을 거두는 행동까지 포함하는 말입니다. 그가 곧바로 히브리 "
               "사람의 아이라고 알아본 점이 중요합니다.")

    def rows(expert, lay, tt='VERS_DESC', lang='KO'):
        return [{'clicked_id': 9001, 'text_type': tt, 'lang_code': lang,
                 'text_variant': 'EXPERT', 'contents': expert},
                {'clicked_id': 9001, 'text_type': tt, 'lang_code': lang,
                 'text_variant': 'LAY', 'contents': lay}]

    # ① 제대로 쓴 짝은 통과해야 한다
    if gate(rows(E, GOOD)):
        bad.append('정상 초안을 거부한다 — %s' % gate(rows(E, GOOD))[:1])
    # ② EXPERT 를 요약한 LAY 는 막아야 한다 (이번 세션 최다 위반)
    if not any('신출어휘' in m for m in gate(rows(E, SUMMARY))):
        bad.append('EXPERT 요약형 LAY 를 통과시킨다 — 문이 죽었다')
    # ③ 문단밀도 미달 — 한 문장짜리 문단을 늘어놓은 설명문
    THIN = '첫 문장입니다.\n\n둘째 문장입니다.\n\n셋째 문장입니다.'
    if not any('문단밀도' in m for m in gate(rows(E, THIN))):
        bad.append('문단밀도 미달을 통과시킨다')
    # ④ 학술장치 없는 EXPERT
    BARE = ('정형구 둘째 요소 — 에노스를 낳은 후 807년의 평범한 세월·자녀들. 기록은 짧으나 '
            '그 안에 무수한 일상이 담겼다. 성경은 셋의 위대한 업적을 기록하지 않는다.')
    if not any('학술장치' in m for m in gate(rows(BARE, '짧게 적습니다.'))):
        bad.append('학술장치 없는 EXPERT 를 통과시킨다')
    # ⑤ 요체
    if not any('요체' in m for m in gate(rows(E, GOOD + '\n\n왜 그럴까요? 그렇지요.'))):
        bad.append('요체를 통과시킨다')
    # ⑥ 빈 본문
    if not any('비었다' in m for m in gate(rows(E, '   '))):
        bad.append('빈 본문을 통과시킨다')
    # ⑦ 검사 대상이 아닌 text_type 은 짝 검사·문단 검사를 하지 않는다
    if any('신출어휘' in m for m in gate(rows(E, E, tt='CONT_DESC'))):
        bad.append('티어 대상이 아닌 자산에 신출어휘를 건다')
    # ⑧ 묵상질문은 한 셀에 여러 개를 담는 것이 규격이라 문단밀도를 걸지 않는다
    if any('문단밀도' in m for m in gate(rows(THIN, THIN, tt='VERS_QUESTION'))):
        bad.append('묵상질문에 문단밀도를 건다 — 여러 질문을 빈 줄로 나누는 규격을 막는다')

    if bad:
        print('SELFTEST FAIL — %d건' % len(bad))
        for m in bad:
            print('  X ' + m)
        return 1
    print('SELFTEST PASS — 7개 항목')
    return 0


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('path', nargs='?')
    ap.add_argument('--force', action='store_true', help='검사 위반을 무시하고 적재')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if not a.path:
        ap.error('초안 JSON 경로가 필요하다')
    return load(a.path, force=a.force)


if __name__ == '__main__':
    sys.exit(main())
