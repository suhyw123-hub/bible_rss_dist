# -*- coding: utf-8 -*-
"""AI 프롬프트 라이브러리 — 한 곳에 모아 두고 자리마다 골라 쓴다(docs/1.txt B · 2026-10-20).

★★★ 사용자 결정(2026-10-20)
  · 「자리」 = 지금 업무(구절질문·설교·묵상노트 분석 …) + 새 자리(홈 AI 대화 셋 · 뉴스 · 말씀카드)
  · Pick 은 자리마다 사본을 두지 않고 **라이브러리 하나를 같이 쓴다** — 한 곳에서 고치면 그 항목을
    쓰는 자리 모두가 따라온다. 자리는 「이 항목을 쓰나」만 정한다(`user_ai_lib_place`).
  · **한국어로 구조를 먼저** — 항목 열쇠(`item_key`)는 언어와 무관하고 글은 언어마다 한 줄이다.
    새 자리 씨앗은 한국어만 적는다(사용자 「번역 작업은 전혀 우선순위가 아니다 · 한국어 프롬프트를
    시험해 확정한 뒤 다국어」). 다른 언어 글이 없으면 읽을 때 한국어로 물러선다.

표 둘(개인 DB)
  user_ai_lib        item_key · lang_code · itype(TASK|PICK) · title · body · seed_title · seed_body ·
                     record_status · updated_at                         UNIQUE(item_key, lang_code)
  user_ai_lib_place  place · item_key · sort_order · on_flag             UNIQUE(place, item_key)

옮기기(`migrate`) — 업무마다 베껴 두었던 Pick 사본(`user_ai_prompt.task<>''`)을 모은다.
  · 같은 항목(kind)이 업무마다 **같은 글**이면 하나로 합친다.
  · 사람이 어느 업무에서만 **다르게 고친** 사본은 따로 남기고(`kind@업무`) 그 자리에만 단다.
  · 업무에서 지운(HIDE) 사본은 그 자리에 안 단다 — 사람이 그 자리에서 뺀 것이다.
  ⚠ 원래 표(`user_ai_prompt`)는 한 줄도 안 바꾼다 — `--undo` 는 새 표만 걷는다.
  ⚠ 지금 화면이 보내는 글은 이 단계에서 바뀌지 않는다(화면을 옮기는 것은 다음 단계).

  python ai_lib.py --selftest | --migrate [--dry] | --undo | --list [자리]
"""
import json
import re
import sys
import time

import user_ai as UA

MIGRATED_KEY = 'AI_LIB_MIGRATED'

# ── 자리 ─────────────────────────────────────────────────────────────
#: (자리 열쇠, 묶음, 한국어 이름). 지금 업무 자리는 `갈래:업무` 로 user_ai 와 이어진다.
PLACES = [
    ('VERSE:ASK', '구절', '구절질문'), ('VERSE:STUDY', '구절', '성경공부 자료 만들기'),
    ('VERSE:SERMON', '구절', '설교작성 도우미'), ('VERSE:TEACH', '구절', '성경교사'),
    ('VERSE:DESC', '구절', '일반설명문 작성'), ('VERSE:XDESC', '구절', '전문설명문 작성'),
    ('VERSE:NOTE', '구절', '묵상노트 분석'), ('VERSE:LINKAN', '구절', '연결 살펴보기'),
    ('VERSE:FREE', '구절', 'Free 대화'),
    ('TERM:DESC', '용어', '용어 설명문 작성'), ('TERM:TERMAN', '용어', '용어 설명문 분석'),
    ('TERM:ASK', '용어', '용어 질문'), ('TERM:STUDY', '용어', '용어 성경공부'), ('TERM:TEACH', '용어', '용어 성경교사'),
    # ★ 2026-10-23 — 인물 살펴보기 · 장소 조사 · 연대 조사(둘러보기 카드의 [AI]). ⚠ 인물 살펴보기가 여기 빠져 Pick 이 0개였다
    ('TERM:FIGURE', '용어', '인물 살펴보기'), ('TERM:PLACEAN', '용어', '장소 조사'), ('ERA:ERAAN', '둘러보기', '연대 조사'),
    ('REF:REFAN', '연구/설교노트', '연구노트 분석'), ('REF:SERMAN', '연구/설교노트', '설교노트 분석'),
    ('REF:SERMWR', '연구/설교노트', '설교노트로 다시 쓰기'),   # ★ 2026-10-27 docs/1.txt 6-1(4)
    # ★ 2026-10-21 (AI도우미.txt 3) 도서 화면에서 쓰는 것은 「도서/설교집」 묶음 — 도서노트 분석은 제 자리(묵상노트 분석과 따로)
    ('REF:BOOKMEDI', '도서/설교집', '도서 묵상'), ('BOOK:NOTE', '도서/설교집', '도서노트 분석'),
    # 새 자리(B4 에서 화면에 잇는다)
    ('HOME:MEDI', '홈 AI 대화', '묵상'), ('HOME:STUDY', '홈 AI 대화', '성경공부'),
    ('HOME:SOCIAL', '홈 AI 대화', '사회현상과 성경'),
    # ★ 2026-10-31 말씀 그룹 「이럴 때 맞는 구절을 찾아줘」
    ('HOME:FIND', '홈 AI 대화', '적절한 구절 찾기'),
    # ★ 2026-10-27 (docs/1.txt 6-3) 뉴스를 말씀으로 읽기 = 사회현상과 성경 바로 아래(같은 묶음 — 따로 묶음이면 자리가 없어 안 보였다)
    ('NEWS', '홈 AI 대화', '뉴스를 말씀으로 읽기'), ('CARD', '말씀카드', '말씀카드 문구'),
    # ★ 2026-10-20 (docs/1.txt 9-2) 말씀카드 갈래 — 갈래마다 자리 하나 · 세부(생일·결혼…)는 그 자리의 Pick ·
    #   사용자가 라이브러리에서 세부를 고치고 더한다(사용자 「프롬프트 형식이면 라이브러리에서 수정/추가」).
    ('CARD:CELEB', '말씀카드', '축하'), ('CARD:COMFORT', '말씀카드', '위로'), ('CARD:CHEER', '말씀카드', '격려'),
    ('CARD:THANKS', '말씀카드', '감사'), ('CARD:PRAY', '말씀카드', '기도'), ('CARD:FEAST', '말씀카드', '절기'),
]
PLACE_KEYS = [p[0] for p in PLACES]
#: ★★★ 2026-10-21 (AI도우미.txt 2) **1:1** — 항목 하나는 자리 하나에만 산다(같이 쓰기를 걷었다).
#:   옛 「같이 쓰던」 항목은 `split_shared` 가 자리마다 사본(`열쇠~자리`)으로 나눈다 · 첫 자리(PLACES 차례)가 원래 열쇠를 갖는다.
#:   「표시」를 끄면 그 자리에 남되 화면에 안 나온다(`on_flag=0`) — 지우는 것은 [지우기].
ONE2ONE_KEY = 'AI_LIB_ONE2ONE'
PLACE_NAME = {p[0]: p[2] for p in PLACES}
#: 옛 업무 열쇠 → 지금 자리(연구하자는 2026-10-16 구절질문으로 갈렸다)
TASK_ALIAS = {'RESEARCH': 'ASK'}

# ── 사람이 더한 자리 ─────────────────────────────────────────────────
#: ★ 2026-10-28 (docs/1.txt 6-1 「모든 질문프롬프트 묶음에 [+ 질문프롬프트]」) — 말씀카드 갈래는 코드에 박혀 있었다.
#:   사람이 더한 카드 갈래 = 자리 `CARD:U<n>` · 그 자리의 TASK 항목이 갈래 글(이름 = 그 항목 제목에서 「말씀카드 · 」를 뗀 것).
#:   폰 말씀카드는 이 자리 목록을 읽어 갈래를 그린다(꾸러미 `lib.places`).
USER_PLACES_KEY = 'AI_LIB_USER_PLACES'      # ["CARD:U1", ...]
CARD_GROUP = '말씀카드'
CARD_PFX = '말씀카드 · '


def _user_place_keys(conn):
    try:
        v = json.loads(UA.get_setting(conn, USER_PLACES_KEY, '') or '[]')
        return [str(x) for x in v if re.match(r'^CARD:U\d+$', str(x))] if isinstance(v, list) else []
    except Exception:                                     # noqa: BLE001
        return []


def _card_name(conn, place, lang='KO'):
    try:
        rows = place_rows(conn, place, lang, 'TASK')
    except Exception:                                     # noqa: BLE001
        rows = []
    t = (rows[0][2] if rows else '') or ''
    return (t[len(CARD_PFX):] if t.startswith(CARD_PFX) else t).strip() or place


def user_places(conn, lang='KO'):
    """사람이 더한 자리 → [(자리, 묶음, 이름)] — 지금은 말씀카드 갈래만."""
    return [(k, CARD_GROUP, _card_name(conn, k, lang)) for k in _user_place_keys(conn)]


def all_places(conn, lang='KO'):
    """앱 자리 + 사람이 더한 자리(말씀카드 갈래는 앱 카드 갈래 바로 뒤)."""
    out, up = [], user_places(conn, lang)
    for i, p in enumerate(PLACES):
        out.append(p)
        if p[0].startswith('CARD:') and not (i + 1 < len(PLACES) and PLACES[i + 1][0].startswith('CARD:')):
            out += up
            up = []
    return out + up


def known_place(conn, pl):
    """쓸 수 있는 자리인가 — 앱 자리 · 사람이 더한 자리 · 내 질문프롬프트 자리(`갈래:UT_n`)."""
    pl = pl or ''
    if pl in PLACE_KEYS or pl in _user_place_keys(conn):
        return True
    return bool(re.match(r'^(VERSE|TERM|REF|HOME):UT_\d+$', pl))


def add_card_place(conn, lang, name):
    """말씀카드 갈래를 더한다 → 자리 열쇠 `CARD:U<n>`(그 자리의 TASK 항목 = 갈래 글)."""
    ensure(conn)
    have = _user_place_keys(conn)
    n = 1 + max([int(k[6:]) for k in have] or [0])
    key = 'CARD:U%d' % n
    nm = (name or '').strip() or '새 갈래'
    body = ('사용자가 누군가에게 말씀카드를 보내려 합니다. 이 카드의 갈래는 「%s」입니다. 아래에서 선택한 상황에 맞는 '
            '성경 구절을 세 개 추천하고, 구절마다 장절을 밝히고 왜 어울리는지 한 줄로 적어 주세요. 그 구절의 문맥이 말하는 '
            '뜻을 벗어나지 말고, 성경이 약속하지 않은 것을 약속하지 마세요. 함께 보낸 사진 목록이 있으면 이 카드에 어울리는 '
            '사진 번호를 두세 개 선택하고 그 까닭을 짧게 적어 주세요.') % nm
    UA.set_setting(conn, USER_PLACES_KEY, json.dumps(have + [key]))
    add_item(conn, lang, CARD_PFX + nm, body, itype='TASK', places=(key,))
    return key


def remove_place(conn, place):
    """사람이 더한 자리를 걷는다 — 그 자리의 항목은 숨긴다(되살릴 자리)."""
    have = _user_place_keys(conn)
    if place not in have:
        return False
    for (k,) in conn.execute("SELECT item_key FROM user_ai_lib_place WHERE place=?", (place,)).fetchall():
        hide_item(conn, k)
    UA.set_setting(conn, USER_PLACES_KEY, json.dumps([k for k in have if k != place]))
    conn.commit()
    return True

# ── 새 자리 씨앗(한국어) ─────────────────────────────────────────────
# ⚠ 쓸 말을 주지 않는다 — 보기 문장을 적으면 답이 그 문장을 그대로 찍는다(memory: prompt-wording-becomes-formula).
#   무엇을 이루려는지와 지킬 선만 적는다.
NEW_SEEDS = {
    'HOME:MEDI': [
        ('HM_TASK', 'TASK', '묵상 대화',
         '당신은 사용자의 말씀 묵상을 곁에서 돕는 동반자입니다. 사용자가 가져온 성경 본문이나 마음의 형편을 함께 '
         '들여다봅니다. 먼저 사용자가 무엇을 보았고 무엇이 마음에 걸렸는지 듣고, 본문이 실제로 말하는 것에 머물게 '
         '도와 주세요. 한 번에 한두 가지만 짚고 짧게 되물어 대화를 이어 갑니다. 설교하거나 결론을 대신 내리지 말고 '
         '사용자가 스스로 발견하도록 기다려 주세요. 본문에 없는 것을 단정하지 말고, 성경을 인용할 때는 장절을 밝힙니다.'),
        ('HM_1', 'PICK', '본문에 머물기', '본문의 낱말과 흐름을 천천히 다시 보도록 이끌어 주세요. 사용자가 지나친 낱말 하나를 짚어 주세요.'),
        ('HM_2', 'PICK', '하나님은 어떤 분인가', '이 본문이 하나님에 대해 무엇을 보여 주는지 사용자가 스스로 찾도록 물어 주세요.'),
        ('HM_3', 'PICK', '내 마음 살피기', '이 말씀 앞에서 사용자의 마음과 생활을 돌아볼 수 있는 질문을 하나만 해 주세요.'),
        ('HM_4', 'PICK', '기도로 잇기', '지금까지 나눈 것으로 사용자가 자기 말로 기도할 수 있도록 기도의 방향만 짚어 주세요.'),
        ('HM_5', 'PICK', '오늘의 한 걸음', '오늘 실천할 일을 대신 정하지 말고, 사용자가 스스로 정하도록 물어 주세요.'),
    ],
    'HOME:STUDY': [
        ('HS_TASK', 'TASK', '성경공부 대화',
         '당신은 사용자와 함께 성경을 공부하는 성경교사입니다. 사용자가 가져온 본문이나 주제를 관찰, 해석, 적용의 차례로 '
         '함께 살핍니다. 배경 설명은 이해에 필요한 만큼만 짧게 하고, 본문이 직접 말하는 것과 학자들의 추정을 구분해 '
         '주세요. 해석이 갈리는 곳은 특정 교단의 이름을 붙이지 말고 견해들을 나란히 보여 줍니다. 원어는 한글 뜻 뒤 '
         '괄호에 음역으로 한두 낱말만 적습니다. 긴 강의 대신 짧게 설명하고 이해했는지 물으며 나아갑니다.'),
        ('HS_1', 'PICK', '관찰', '누가, 무엇을, 어디서, 언제, 왜를 중심으로 본문을 관찰하도록 도와 주세요.'),
        ('HS_2', 'PICK', '배경', '이 본문을 이해하는 데 꼭 필요한 역사와 문화 배경만 알려 주세요.'),
        ('HS_3', 'PICK', '원어 핵심 낱말', '본문의 뜻을 여는 원어 낱말 하나나 둘을 설명해 주세요.'),
        ('HS_4', 'PICK', '함께 볼 본문', '이 본문을 밝혀 주는 다른 성경 본문을 두세 곳 장절과 함께 알려 주세요.'),
        ('HS_5', 'PICK', '해석이 갈리는 곳', '이 본문에서 해석이 갈리는 곳이 있으면 견해들을 근거와 함께 나란히 보여 주세요.'),
        ('HS_6', 'PICK', '이해 확인', '지금까지 배운 것을 사용자가 자기 말로 정리하도록 질문을 하나 해 주세요.'),
    ],
    'HOME:FIND': [
        ('HF_TASK', 'TASK', '적절한 구절 찾기',
         '사용자가 넣은 구절이나 내용에 맞는 성경 구절을 찾아 줍니다. 많아야 일곱 곳만 적고, 한 곳마다 한 줄에 '
         '[[V]] 약명 장:절 | 왜 맞는지와 그 구절의 문맥 한 줄 꼴로 적습니다. 장절이 확실하지 않은 구절은 넣지 않습니다. '
         '구절 본문은 앱이 자기 성경으로 보여 주므로 적지 않습니다. 구절의 문맥이 말하지 않는 뜻으로 쓰지 말고, '
         '문맥과 조금 다르게 쓰이는 구절이면 그렇다고 밝힙니다. 사용자가 희미하게 기억하는 말씀을 찾는 경우 후보를 '
         '가능성 높은 차례로 놓습니다.'),
        ('HF_1', 'PICK', '관련된 구절', '이 내용과 직접 관련된 구절을 찾아 주세요.'),
        ('HF_2', 'PICK', '뒷받침하는 구절', '이 생각을 성경이 실제로 뒷받침하는지 살피고, 뒷받침하는 구절을 찾아 주세요. 뒷받침이 약하면 그렇다고 말해 주세요.'),
        ('HF_3', 'PICK', '기억나는 그 말씀', '사용자가 어렴풋이 기억하는 말씀이 어느 구절인지 후보를 찾아 주세요.'),
        ('HF_4', 'PICK', '비슷한 인물과 사건', '성경에서 비슷한 처지에 있던 인물이나 사건이 나오는 구절을 찾아 주세요.'),
        ('HF_5', 'PICK', '위로와 권면', '이 형편에 있는 사람에게 위로나 권면이 되는 구절을 찾아 주세요.'),
    ],
    'HOME:SOCIAL': [
        # ★ 2026-10-22 이슈 토론 방식(사용자 「사용자가 이슈를 던지면 그 이슈 · 분야를 선택하면 AI 가 그 분야에서 · 양방향 ·
        #   획일적인 단계는 부작용 · 꼬리물기로 AI 가 이끈다」) — 오늘·나라는 시스템 글이 저절로 붙인다(자리표 없음).
        #   꼬리물기(답 끝 권유 질문)는 앱이 규칙으로 붙이므로 여기서는 「이슈에 맞게 고르라」만 말한다.
        ('HC_TASK', 'TASK', '사회현상과 성경',
         '당신은 사용자가 최근의 사회 현상을 성경의 눈으로 생각하도록 돕는 대화 상대입니다. 함께 보낸 재료에 최근 뉴스와 글의 '
         '제목이 있으면 그 나라의 지금 상황을 아는 데 참고하되, 제목만 보고 내용을 지어내지 마세요. '
         '시작은 사용자가 무엇을 보냈는지에 따릅니다. 이슈를 적었으면 그 이슈로 바로 시작합니다. 추천을 청했거나 분야만 적었으면 '
         '그 분야(없으면 그 나라 전체)에서 지금 생각해 볼 만한 이슈를 두세 개 번호를 붙여 한 줄씩 제안하고, 어느 것으로 할지 묻고 '
         '멈춥니다. 번호만 오면 그 이슈입니다. 제안할 때는 재료 제목의 차례를 따르지 말고 분야가 서로 다른 것으로 정하며, '
         '「최근에 다룬 이슈」에 있는 분야는 피합니다. 하나 정해서 시작하라고 했으면 가장 생각할 거리가 많은 것 하나를 정하고 왜 그것인지 '
         '한 줄로 말한 뒤 시작합니다. '
         '이슈가 정해지면 한 번에 하나씩 짧게 다룹니다. 처음에는 확인된 사실과 사람들의 해석을 갈라 공정하게 정리합니다. 그다음은 '
         '정해진 차례가 아니라 그 이슈의 모양에 따라 정합니다. 성경의 원리와 이야기(장절과 함께), 그리스도인들 사이에서 판단이 '
         '갈리는 지점과 각 근거, 영향을 받는 이웃, 교회가 생각할 일, 기도할 방향 가운데 지금 가장 필요한 것 하나를 다룹니다. '
         '답 끝의 권유 질문은 이 이슈에서 다음으로 생각할 것으로 정하고, 사용자가 다른 방향을 원하면 그쪽을 따릅니다. '
         '특정 정당이나 정치 진영의 편을 들지 말고, 어느 집단의 사람들도 깎아내리지 않습니다. 성경이 직접 말하지 않는 일을 성경의 '
         '결론처럼 말하지 않습니다. 결론을 대신 내리지 말고 사용자가 스스로 판단할 재료를 줍니다. 긴 강의가 아니라 짧은 문단 '
         '두셋으로 말합니다.'),
        ('HC_1', 'PICK', '사실과 의견', '이 현상에 대해 확인된 사실과 해석·의견을 나누어 정리해 주세요.'),
        ('HC_2', 'PICK', '관련 성경 본문', '이 현상을 생각하는 데 도움이 되는 성경 본문을 장절과 그 까닭과 함께 알려 주세요.'),
        ('HC_3', 'PICK', '견해가 갈리는 곳', '그리스도인들 사이에서 이 문제에 대한 견해가 어떻게 갈리는지 근거와 함께 보여 주세요.'),
        ('HC_4', 'PICK', '이웃과 교회', '이 일 앞에서 교회와 그리스도인이 이웃을 위해 생각해 볼 일을 제안해 주세요. 대신 정해 주지는 마세요.'),
        ('HC_5', 'PICK', '기도 제목', '이 일과 관련된 사람들을 위해 기도할 방향을 짚어 주세요.'),
        ('HC_6', 'PICK', '역사 속 교회의 경험', '비슷한 일을 교회가 역사에서 어떻게 겪고 무엇을 배웠는지, 확인된 사실만으로 짚어 주세요.'),
    ],
    'NEWS': [
        ('NW_TASK', 'TASK', '뉴스를 말씀으로 읽기',
         '사용자가 가져온 뉴스를 성경의 빛 아래에서 차분히 읽도록 돕습니다. 오늘은 [오늘]이고 사용자는 [국가]에 살고 있습니다. 먼저 기사의 핵심을 기사에 적힌 내용만으로 '
         '짧게 정리하고, 기사에 없는 사실을 지어내거나 추측을 사실처럼 말하지 않습니다. 그다음 이 일을 생각하는 데 '
         '도움이 되는 성경 본문을 장절과 함께 보여 주고, 관련된 사람들을 위한 기도의 방향을 짚어 주세요. 정치적 편을 '
         '들거나 사람을 정죄하지 않습니다.'),
        ('NW_1', 'PICK', '핵심 정리', '기사의 핵심을 기사에 적힌 내용만으로 세 줄 안에 정리해 주세요.'),
        ('NW_2', 'PICK', '성경의 빛', '이 일을 생각하는 데 도움이 되는 성경 본문 두세 곳을 장절과 까닭과 함께 알려 주세요.'),
        ('NW_3', 'PICK', '기도 제목', '이 일로 영향을 받는 사람들을 위해 기도할 제목을 짚어 주세요.'),
        ('NW_4', 'PICK', '조심할 점', '이 소식을 읽을 때 성급히 단정하거나 한쪽으로 기울기 쉬운 점을 짚어 주세요.'),
        ('NW_5', 'PICK', '이웃 사랑', '이 일 앞에서 그리스도인이 할 수 있는 작은 이웃 사랑을 생각해 보도록 물어 주세요.'),
    ],
    'CARD': [
        ('CD_TASK', 'TASK', '말씀카드 문구',
         '사용자가 성경 구절을 카드에 담아 누군가에게 보내려 합니다. 받는 사람과 형편을 생각해 카드에 함께 적을 짧은 '
         '글을 결이 다른 세 가지로 제안해 주세요. 각 글은 두세 문장을 넘지 않게 하고, 그 구절의 문맥이 말하는 뜻을 '
         '벗어나지 않게 씁니다. 병이 낫거나 일이 잘된다는 식으로 성경이 약속하지 않은 것을 약속하지 마세요. 사용자가 '
         '고쳐 쓸 초안이므로 꾸밈말을 줄이고 자연스러운 말로 씁니다.'),
        ('CD_1', 'PICK', '받는 사람 형편에 맞게', '사용자가 알려 준 받는 사람의 형편에 더 맞도록 다시 써 주세요.'),
        ('CD_2', 'PICK', '더 짧게', '한 문장으로 줄여 주세요.'),
        ('CD_3', 'PICK', '더 따뜻하게', '말투를 더 따뜻하고 다정하게 다듬어 주세요. 뜻은 바꾸지 마세요.'),
        ('CD_4', 'PICK', '구절의 뜻 한 줄', '이 구절이 문맥에서 말하는 뜻을 받는 사람이 알아듣게 한 줄로 풀어 주세요.'),
        ('CD_5', 'PICK', '기도 한 줄', '받는 사람을 위한 짧은 기도 한 줄을 덧붙여 주세요.'),
    ],
    # ★ 2026-10-20 (docs/1.txt 9-2) 말씀카드 갈래 여섯 — 갈래 프롬프트(TASK) + 세부(PICK)
    'CARD:CELEB': [
        ('CC_TASK', 'TASK', '말씀카드 · 축하',
         '사용자가 누군가에게 말씀카드를 보내려 합니다. 이 카드는 기쁜 일을 함께 기뻐하고 축복하는 마음을 전합니다. 아래에서 선택한 상황에 맞는 성경 구절을 세 개 추천하고, 구절마다 장절을 밝히고 왜 어울리는지 한 줄로 적어 주세요. 그 구절의 문맥이 말하는 뜻을 벗어나지 말고, 성경이 약속하지 않은 것을 약속하지 마세요. 함께 보낸 사진 목록이 있으면 이 카드에 어울리는 사진 번호를 두세 개 선택하고 그 까닭을 짧게 적어 주세요. 받는 사람이나 관계를 더 알아야 하면 질문 하나를 먼저 해도 됩니다.'),
        ('CC_1', 'PICK', '생일', '생일을 맞은 사람에게 보내는 카드입니다. 한 해를 지켜 주신 은혜와 앞날의 복을 함께 담아 주세요.'),
        ('CC_2', 'PICK', '결혼', '결혼하는 두 사람에게 보내는 카드입니다. 하나님 안에서 세워지는 가정과 사랑을 담아 주세요.'),
        ('CC_3', 'PICK', '출산', '아기를 맞은 가정에 보내는 카드입니다. 생명의 선물과 자녀를 향한 축복을 담아 주세요.'),
        ('CC_4', 'PICK', '입학·졸업', '입학하거나 졸업하는 사람에게 보내는 카드입니다. 새 길을 인도하시는 하나님을 담아 주세요.'),
        ('CC_5', 'PICK', '취업·개업', '새 일을 시작하는 사람에게 보내는 카드입니다. 일터에서 함께하시는 하나님을 담아 주세요.'),
        ('CC_6', 'PICK', '세례·입교', '세례를 받거나 입교하는 사람에게 보내는 카드입니다. 그리스도 안의 새 삶을 담아 주세요.'),
    ],
    'CARD:COMFORT': [
        ('CO_TASK', 'TASK', '말씀카드 · 위로',
         '사용자가 누군가에게 말씀카드를 보내려 합니다. 이 카드는 아픔과 슬픔 곁에 함께 있는 마음을 전합니다. 아래에서 선택한 상황에 맞는 성경 구절을 세 개 추천하고, 구절마다 장절을 밝히고 왜 어울리는지 한 줄로 적어 주세요. 그 구절의 문맥이 말하는 뜻을 벗어나지 말고, 성경이 약속하지 않은 것을 약속하지 마세요. 함께 보낸 사진 목록이 있으면 이 카드에 어울리는 사진 번호를 두세 개 선택하고 그 까닭을 짧게 적어 주세요. 받는 사람이나 관계를 더 알아야 하면 질문 하나를 먼저 해도 됩니다.'),
        ('CO_1', 'PICK', '병중·회복', '아프거나 회복 중인 사람에게 보내는 카드입니다. 낫는다고 약속하지 말고 함께하시는 하나님을 담아 주세요.'),
        ('CO_2', 'PICK', '슬픔(장례)', '가족을 떠나보낸 사람에게 보내는 카드입니다. 섣부른 설명 없이 슬픔에 함께하는 마음을 담아 주세요.'),
        ('CO_3', 'PICK', '어려움·실패', '어려운 일이나 실패를 겪는 사람에게 보내는 카드입니다. 정죄하지 말고 다시 세우시는 은혜를 담아 주세요.'),
        ('CO_4', 'PICK', '이별·이사', '헤어지거나 먼 곳으로 떠나는 사람에게 보내는 카드입니다. 어디서나 함께하시는 하나님을 담아 주세요.'),
    ],
    'CARD:CHEER': [
        ('CH_TASK', 'TASK', '말씀카드 · 격려',
         '사용자가 누군가에게 말씀카드를 보내려 합니다. 이 카드는 지치거나 도전 앞에 선 사람에게 힘을 주는 마음을 전합니다. 아래에서 선택한 상황에 맞는 성경 구절을 세 개 추천하고, 구절마다 장절을 밝히고 왜 어울리는지 한 줄로 적어 주세요. 그 구절의 문맥이 말하는 뜻을 벗어나지 말고, 성경이 약속하지 않은 것을 약속하지 마세요. 함께 보낸 사진 목록이 있으면 이 카드에 어울리는 사진 번호를 두세 개 선택하고 그 까닭을 짧게 적어 주세요. 받는 사람이나 관계를 더 알아야 하면 질문 하나를 먼저 해도 됩니다.'),
        ('CH_1', 'PICK', '시험·도전', '시험이나 큰 도전을 앞둔 사람에게 보내는 카드입니다. 두려움보다 힘 주시는 하나님을 담아 주세요.'),
        ('CH_2', 'PICK', '새 출발', '새로 시작하는 사람에게 보내는 카드입니다. 앞길을 여시는 하나님을 담아 주세요.'),
        ('CH_3', 'PICK', '사역·봉사', '사역하고 봉사하는 사람에게 보내는 카드입니다. 수고를 기억하시는 하나님을 담아 주세요.'),
        ('CH_4', 'PICK', '지친 이에게', '몸과 마음이 지친 사람에게 보내는 카드입니다. 쉼을 주시는 하나님을 담아 주세요.'),
    ],
    'CARD:THANKS': [
        ('CT_TASK', 'TASK', '말씀카드 · 감사',
         '사용자가 누군가에게 말씀카드를 보내려 합니다. 이 카드는 고마운 마음을 전하는 마음을 전합니다. 아래에서 선택한 상황에 맞는 성경 구절을 세 개 추천하고, 구절마다 장절을 밝히고 왜 어울리는지 한 줄로 적어 주세요. 그 구절의 문맥이 말하는 뜻을 벗어나지 말고, 성경이 약속하지 않은 것을 약속하지 마세요. 함께 보낸 사진 목록이 있으면 이 카드에 어울리는 사진 번호를 두세 개 선택하고 그 까닭을 짧게 적어 주세요. 받는 사람이나 관계를 더 알아야 하면 질문 하나를 먼저 해도 됩니다.'),
        ('CT_1', 'PICK', '감사 인사', '고마운 사람에게 감사를 전하는 카드입니다.'),
        ('CT_2', 'PICK', '스승·부모님', '스승이나 부모님께 감사를 전하는 카드입니다. 받은 사랑과 가르침을 기억하는 마음을 담아 주세요.'),
        ('CT_3', 'PICK', '섬김에 대한 감사', '나를 섬겨 준 사람에게 보내는 카드입니다. 그 섬김을 기억하시는 하나님을 담아 주세요.'),
    ],
    'CARD:PRAY': [
        ('CP_TASK', 'TASK', '말씀카드 · 기도',
         '사용자가 누군가에게 말씀카드를 보내려 합니다. 이 카드는 함께 기도하고 있음을 알리는 마음을 전합니다. 아래에서 선택한 상황에 맞는 성경 구절을 세 개 추천하고, 구절마다 장절을 밝히고 왜 어울리는지 한 줄로 적어 주세요. 그 구절의 문맥이 말하는 뜻을 벗어나지 말고, 성경이 약속하지 않은 것을 약속하지 마세요. 함께 보낸 사진 목록이 있으면 이 카드에 어울리는 사진 번호를 두세 개 선택하고 그 까닭을 짧게 적어 주세요. 받는 사람이나 관계를 더 알아야 하면 질문 하나를 먼저 해도 됩니다.'),
        ('CP_1', 'PICK', '기도하고 있어요', '당신을 위해 기도하고 있다고 알리는 카드입니다.'),
        ('CP_2', 'PICK', '회복을 빕니다', '몸과 마음의 회복을 위해 기도하는 카드입니다. 낫는다고 약속하지 마세요.'),
        ('CP_3', 'PICK', '평안을 빕니다', '하나님의 평안을 비는 카드입니다.'),
    ],
    'CARD:FEAST': [
        ('CF_TASK', 'TASK', '말씀카드 · 절기',
         '사용자가 누군가에게 말씀카드를 보내려 합니다. 이 카드는 교회 절기와 새해를 함께 기뻐하는 마음을 전합니다. 오늘은 [오늘]입니다. 아래에서 선택한 상황에 맞는 성경 구절을 세 개 추천하고, 구절마다 장절을 밝히고 왜 어울리는지 한 줄로 적어 주세요. 그 구절의 문맥이 말하는 뜻을 벗어나지 말고, 성경이 약속하지 않은 것을 약속하지 마세요. 함께 보낸 사진 목록이 있으면 이 카드에 어울리는 사진 번호를 두세 개 선택하고 그 까닭을 짧게 적어 주세요. 받는 사람이나 관계를 더 알아야 하면 질문 하나를 먼저 해도 됩니다.'),
        ('CF_1', 'PICK', '새해', '새해를 맞아 보내는 카드입니다.'),
        ('CF_2', 'PICK', '부활절', '부활절에 보내는 카드입니다. 부활의 소망을 담아 주세요.'),
        ('CF_3', 'PICK', '추수감사절', '추수감사절에 보내는 카드입니다. 한 해의 은혜에 대한 감사를 담아 주세요.'),
        ('CF_4', 'PICK', '성탄절', '성탄절에 보내는 카드입니다. 오신 예수 그리스도를 담아 주세요.'),
    ],
}


def _now():
    return time.strftime('%Y-%m-%d %H:%M:%S')


def init(conn):
    """표 둘 — 멱등. **`userdb.` 를 붙인다**(안 붙이면 배포 DB 에 생긴다)."""
    UA.init(conn)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS userdb.user_ai_lib ("
        " lib_id INTEGER PRIMARY KEY AUTOINCREMENT, item_key TEXT NOT NULL, lang_code TEXT NOT NULL,"
        " itype TEXT NOT NULL DEFAULT 'PICK', title TEXT, body TEXT, seed_title TEXT, seed_body TEXT,"
        " record_status TEXT DEFAULT 'LIVE', updated_at TEXT, UNIQUE(item_key, lang_code))")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS userdb.user_ai_lib_place ("
        " place TEXT NOT NULL, item_key TEXT NOT NULL, sort_order INTEGER DEFAULT 0,"
        " on_flag INTEGER DEFAULT 1, UNIQUE(place, item_key))")
    conn.commit()


# ── 씨앗 글(초기값) ──────────────────────────────────────────────────
def _seed_text(kind, lang):
    """그 항목의 처음 글 — 없으면 None(사람이 만든 것)."""
    for tk, rows in UA.TASK_PICK_SEEDS.items():
        for k, tx in rows:
            if k == kind:
                return tx.get(lang)
    for src in (UA.SEED_PROMPTS, UA.SEED_TERM, UA.SEED_REF):
        if kind in src:
            return src[kind].get(lang)
    return None


def _norm(s):
    return re.sub(r'\s+', ' ', (s or '').strip())


# ── 옮기기 ───────────────────────────────────────────────────────────
def plan(conn, prime=True):
    """옮길 것을 센다 — 고치지 않는다. → (항목 줄 [(key, lang, itype, title, body, seed)], 자리 줄 [(place, key, so)], 통계)"""
    init(conn)
    # ★ 2026-10-20 새로 깐 PC(빈 개인 DB)는 업무별 사본이 아직 없다 — 먼저 지어야 구절질문 Pick 등이 옮겨 온다
    #   (사본은 그 업무를 처음 열 때 생겼다 · 안 지으면 라이브러리에 그 자리 Pick 이 비고, 폰 기본 꾸러미도 빈다)
    if prime:
        UA.ensure_seeds(conn)
    for (lg,) in (conn.execute("SELECT DISTINCT lang_code FROM user_ai_prompt WHERE COALESCE(task,'')=''").fetchall()
                  if prime else []):
        for pl in PLACE_KEYS:
            if ':' not in pl or pl.startswith('HOME:'):
                continue
            sc, tk = pl.split(':', 1)
            try:
                UA._ensure_task_picks(conn, lg, *UA.pick_key(sc, tk))
            except Exception:                             # noqa: BLE001
                pass
    rows = conn.execute(
        "SELECT lang_code, scope, task, kind, title, body, sort_order, genre, COALESCE(record_status,'LIVE'),"
        " prompt_id FROM user_ai_prompt WHERE COALESCE(task,'')<>'' ORDER BY sort_order, prompt_id").fetchall()
    picks = []
    pid_at = {}            # 옛 프롬프트 번호 → (언어, kind, 자리) — 직전값(체크한 Pick)을 옮기는 데 쓴다
    for lg, sc, tk, kind, title, body, so, genre, st, pid in rows:
        if not UA._is_pick(kind, UA.genre_of(kind, genre)):
            continue
        tk = TASK_ALIAS.get(tk, tk)
        picks.append((lg, '%s:%s' % (sc, tk), kind, title or '', body or '', so or 0, st))
        pid_at[pid] = (lg, kind, '%s:%s' % (sc, tk))
    # 업무마다 대표 글(한국어 > 영어 > 무엇이든) — 그것으로 같은 글끼리 묶는다
    rep = {}
    for lg, pl, kind, t, b, so, st in picks:
        r = rep.setdefault((kind, pl), {})
        r.setdefault(lg, (_norm(t), _norm(b)))
    # ⚠ 언어가 서로 다른 사본끼리 견주면 안 된다 — 어느 업무에 영어 사본만 있으면 「고쳤다」로 잘못 갈라진다
    #   (실측 셋). 같은 언어 글이 하나라도 같으면 같은 묶음이다.
    groups = {}            # kind → {대표글: [자리…]}
    gtexts = {}            # (kind, 대표글) → {언어: 글}
    for (kind, pl), by in sorted(rep.items(), key=lambda kv: ('KO' not in kv[1], kv[0][1])):
        sig = None
        for s0, tx in gtexts.items():
            if s0[0] == kind and any(tx.get(lg) == v for lg, v in by.items()) and \
                    not any(lg in tx and tx[lg] != v for lg, v in by.items()):
                sig = s0[1]
                break
        if sig is None:
            sig = by.get('KO') or by.get('EN') or next(iter(by.values()))
        groups.setdefault(kind, {}).setdefault(sig, []).append(pl)
        for lg, v in by.items():
            gtexts.setdefault((kind, sig), {}).setdefault(lg, v)
    key_of = {}            # (kind, 자리) → 항목 열쇠
    n_split = 0
    for kind, sigs in groups.items():
        order = sorted(sigs.items(), key=lambda kv: (-len(kv[1]), min(kv[1])))
        for i, (sig, pls) in enumerate(order):
            for pl in pls:
                key_of[(kind, pl)] = kind if i == 0 else '%s@%s' % (kind, sorted(pls)[0])
            if i:
                n_split += 1
    items, places = {}, {}
    for lg, pl, kind, t, b, so, st in picks:
        k = key_of[(kind, pl)]
        if (k, lg) not in items or st == 'LIVE':
            seed = _seed_text(kind, lg)
            items[(k, lg)] = (k, lg, 'PICK', t, b, seed, st)
        if st == 'LIVE':
            places.setdefault((pl, k), so)
    item_rows = [v[:6] for v in items.values() if v[6] == 'LIVE' or
                 any(kk == v[0] for (_p, kk) in places)]
    for pl, seeds in NEW_SEEDS.items():
        for i, (k, it, t, b) in enumerate(seeds):
            item_rows.append((k, 'KO', it, t, b, (t, b)))
            places[(pl, k)] = (i + 1) * 10
    pid_key = {pid: (lg, key_of[(kind, pl)]) for pid, (lg, kind, pl) in pid_at.items() if (kind, pl) in key_of}
    stat = {'pick_copies': len(picks), 'items': len({r[0] for r in item_rows}),
            'item_rows': len(item_rows), 'place_rows': len(places), 'split': n_split}
    return item_rows, [(p, k, so) for (p, k), so in places.items()], stat, pid_key


LAST_BACKUP_KEY = 'AI_LIB_LAST_BACKUP'


def _move_last(conn, pid_key):
    """화면의 직전값(`AI_LAST_<단위>` 의 체크한 Pick 번호)을 라이브러리 번호(음수 lib_id)로 옮긴다.
    옛 값은 `AI_LIB_LAST_BACKUP` 에 남긴다(되돌리기)."""
    back = {}
    n = 0
    for k, v in conn.execute("SELECT config_key, config_val FROM user_config WHERE substr(config_key,1,8)='AI_LAST_'").fetchall():
        try:
            d = json.loads(v or '{}')
        except ValueError:
            continue
        if not isinstance(d, dict) or not d.get('checked'):
            continue
        new = []
        for x in d['checked']:
            if isinstance(x, int) and x < 0:
                new.append(x)
                continue
            lk = pid_key.get(x)
            r = conn.execute("SELECT lib_id FROM user_ai_lib WHERE item_key=? AND lang_code=?", (lk[1], lk[0])).fetchone() if lk else None
            if r:
                new.append(-r[0])
        back[k] = v
        d['checked'] = new
        UA.set_setting(conn, k, json.dumps(d, ensure_ascii=False))
        n += 1
    if back:
        # ⚠ 다시 옮겨도 **처음 값**을 지킨다(두 번째 옮기기의 「옛 값」은 이미 새 번호다)
        try:
            old = json.loads(UA.get_setting(conn, LAST_BACKUP_KEY, '') or '{}')
        except ValueError:
            old = {}
        back.update(old)
        UA.set_setting(conn, LAST_BACKUP_KEY, json.dumps(back, ensure_ascii=False))
    return n


def migrate(conn, dry=False, force=False, prime=True):
    """라이브러리를 채운다 — 한 번만(`user_config['AI_LIB_MIGRATED']`). 이미 있는 줄은 안 덮는다."""
    init(conn)
    if not force and UA.get_setting(conn, MIGRATED_KEY, ''):
        return {'skipped': True}
    item_rows, place_rows, stat, pid_key = plan(conn, prime=prime)
    if dry:
        return stat
    for k, lg, it, t, b, seed in item_rows:
        st, sb = (seed or (t, b))
        conn.execute("INSERT OR IGNORE INTO user_ai_lib(item_key, lang_code, itype, title, body, seed_title,"
                     " seed_body, updated_at) VALUES(?,?,?,?,?,?,?,?)", (k, lg, it, t, b, st, sb, _now()))
    for pl, k, so in place_rows:
        conn.execute("INSERT OR IGNORE INTO user_ai_lib_place(place, item_key, sort_order) VALUES(?,?,?)",
                     (pl, k, so))
    stat['last_moved'] = _move_last(conn, pid_key)
    UA.set_setting(conn, MIGRATED_KEY, _now())
    conn.commit()
    return stat


def undo(conn):
    """새 표만 걷는다 — 원래 프롬프트 표는 그대로다 · 직전값은 옛 번호로 되돌린다."""
    try:
        back = json.loads(UA.get_setting(conn, LAST_BACKUP_KEY, '') or '{}')
    except ValueError:
        back = {}
    for k, v in back.items():
        UA.set_setting(conn, k, v)
    conn.execute("DELETE FROM user_config WHERE config_key=?", (LAST_BACKUP_KEY,))
    conn.execute("DROP TABLE IF EXISTS userdb.user_ai_lib")
    conn.execute("DROP TABLE IF EXISTS userdb.user_ai_lib_place")
    conn.execute("DELETE FROM user_config WHERE config_key=?", (MIGRATED_KEY,))
    conn.commit()


def ensure(conn):
    """화면이 부르는 문 — 표를 만들고 아직이면 옮긴다 · 새로 생긴 씨앗을 잇는다 · 같이 쓰는 항목을 나눈다."""
    migrate(conn)
    if UA.get_setting(conn, MIGRATED_KEY, ''):
        sync_seeds(conn)
        _seed_book_note(conn)
        split_shared(conn)


BOOKNOTE_KEY = 'AI_LIB_BOOKNOTE'


def _seed_book_note(conn):
    """도서노트 분석 자리 — 처음 한 번 묵상노트 분석의 Pick 을 그대로 가져온다(곧 `split_shared` 가 사본으로 나눈다)."""
    if UA.get_setting(conn, BOOKNOTE_KEY, ''):
        return
    for k, so, on in conn.execute("SELECT item_key, sort_order, on_flag FROM user_ai_lib_place WHERE place='VERSE:NOTE'").fetchall():
        conn.execute("INSERT OR IGNORE INTO user_ai_lib_place(place, item_key, sort_order, on_flag) VALUES(?,?,?,?)",
                     ('BOOK:NOTE', k, so, on))
    UA.set_setting(conn, BOOKNOTE_KEY, _now())
    conn.commit()


def unit_of(place):
    """자리 → 화면 직전값 단위(`AI_LAST_<단위>`) — Free 는 `FREE` · 도서노트 분석은 `BOOK_NOTE`."""
    if place == 'VERSE:FREE':
        return 'FREE'
    return place.replace(':', '_')


def split_shared(conn):
    """★ 1:1 — 두 자리 이상에 붙은 항목을 자리마다 사본으로 나눈다(모든 언어 줄 · 처음 글까지).
    첫 자리(PLACES 차례 · 모르는 자리는 뒤)가 원래 열쇠를 갖고, 나머지는 `열쇠~자리` 로 옮긴다.
    화면 직전값(그 자리에서 체크해 둔 Pick 번호)도 새 번호로 바꾼다. → 나눈 수"""
    rank = {p: i for i, p in enumerate(PLACE_KEYS)}
    by = {}
    for pl, k, rid in conn.execute("SELECT place, item_key, rowid FROM user_ai_lib_place").fetchall():
        by.setdefault(k, []).append((rank.get(pl, 999), pl, rid))
    n = 0
    for k, lst in by.items():
        if len(lst) < 2:
            continue
        lst.sort()
        base = k.split('~')[0]
        for _r, pl, rid in lst[1:]:
            nk = '%s~%s' % (base, pl)
            if not conn.execute("SELECT 1 FROM user_ai_lib WHERE item_key=?", (nk,)).fetchone():
                conn.execute("INSERT INTO user_ai_lib(item_key, lang_code, itype, title, body, seed_title, seed_body,"
                             " record_status, updated_at) SELECT ?, lang_code, itype, title, body, seed_title, seed_body,"
                             " record_status, ? FROM user_ai_lib WHERE item_key=?", (nk, _now(), k))
            conn.execute("DELETE FROM user_ai_lib_place WHERE place=? AND item_key=?", (pl, nk))
            conn.execute("UPDATE user_ai_lib_place SET item_key=? WHERE rowid=?", (nk, rid))
            # 그 자리 직전값 — 옛 번호(-lib_id) → 같은 언어의 새 번호
            ids = {o: nw for o, nw in conn.execute(
                "SELECT a.lib_id, b.lib_id FROM user_ai_lib a JOIN user_ai_lib b ON b.lang_code=a.lang_code"
                " WHERE a.item_key=? AND b.item_key=?", (k, nk))}
            ck = 'AI_LAST_' + unit_of(pl)
            try:
                d = json.loads(UA.get_setting(conn, ck, '') or '{}')
            except ValueError:
                d = {}
            if isinstance(d, dict) and d.get('checked'):
                new = [(-ids[-x] if (isinstance(x, int) and x < 0 and -x in ids) else x) for x in d['checked']]
                if new != d['checked']:
                    d['checked'] = new
                    UA.set_setting(conn, ck, json.dumps(d, ensure_ascii=False))
            n += 1
    if n:
        UA.set_setting(conn, ONE2ONE_KEY, _now())
        conn.commit()
    return n


def place_of(conn, key):
    """그 항목이 사는 자리(1:1 · 표시를 꺼도 자리는 그대로) — 없으면 ''."""
    r = conn.execute("SELECT place FROM user_ai_lib_place WHERE item_key=? ORDER BY rowid LIMIT 1", (key,)).fetchone()
    return r[0] if r else ''


def place_all(conn, place, lang='KO'):
    """그 자리의 항목 전부(표시를 끈 것까지) — `[(item_key, title, body, itype, lang_code, on_flag)]` 자리 차례."""
    ensure(conn)
    out = []
    for k, on in conn.execute("SELECT item_key, on_flag FROM user_ai_lib_place WHERE place=?"
                              " ORDER BY sort_order, rowid", (place,)).fetchall():
        r = _pick_lang(conn, k, lang)
        if r:
            out.append((k, r[1], r[2], r[3], r[4], int(on or 0)))
    return out


def move_item(conn, place, key, step):
    """그 자리 안에서 차례를 한 칸 옮긴다(step = -1 위 · +1 아래)."""
    rows = conn.execute("SELECT item_key, rowid FROM user_ai_lib_place WHERE place=? ORDER BY sort_order, rowid",
                        (place,)).fetchall()
    ks = [r[0] for r in rows]
    if key not in ks:
        return False
    i = ks.index(key)
    j = i + step
    if not 0 <= j < len(ks):
        return False
    ks[i], ks[j] = ks[j], ks[i]
    for n, k in enumerate(ks):
        conn.execute("UPDATE user_ai_lib_place SET sort_order=? WHERE place=? AND item_key=?", ((n + 1) * 10, place, k))
    conn.commit()
    return True


#: 업무 → 그 업무를 쓰는 자리(씨앗 Pick 이 처음 들어갈 곳)
def _task_places(task):
    return [p for p in PLACE_KEYS if p.split(':')[-1] == task and ':' in p]


def sync_seeds(conn):
    """옮긴 뒤에 코드에 더해진 씨앗을 라이브러리에 잇는다 — **처음 보는 열쇠만**(지운 것·사람이 고친 것은 안 건드린다).
    ⚠ 옛 씨앗 글 그대로인 줄은 새 씨앗 글로(`UA.TEACH_RENEW` · 사람이 고친 것은 그대로)."""
    have = {r[0] for r in conn.execute("SELECT DISTINCT item_key FROM user_ai_lib")}
    n = 0
    for task, rows in UA.TASK_PICK_SEEDS.items():
        # ★ 2026-10-23 — 씨앗은 라이브러리에 있는데 그 업무 자리가 나중에 생긴 경우(인물 살펴보기 Pick 0개 사고) ·
        #   **그 자리가 통째로 비었을 때만** 씨앗을 단다(사람이 그 자리에서 뺀 것을 되살리지 않는다)
        for pl in _task_places(task):
            if not conn.execute("SELECT 1 FROM user_ai_lib_place WHERE place=? LIMIT 1", (pl,)).fetchone():
                for i, (kind, tx) in enumerate(rows):
                    if kind in have:
                        conn.execute("INSERT OR IGNORE INTO user_ai_lib_place(place, item_key, sort_order) VALUES(?,?,?)",
                                     (pl, kind, (i + 1) * 10))
                        n += 1
        for i, (kind, tx) in enumerate(rows):
            if kind in have:
                continue
            for lg in ('KO', 'EN'):
                if lg in tx:
                    t, b = tx[lg]
                    conn.execute("INSERT OR IGNORE INTO user_ai_lib(item_key, lang_code, itype, title, body, seed_title,"
                                 " seed_body, updated_at) VALUES(?,?,?,?,?,?,?,?)", (kind, lg, 'PICK', t, b, t, b, _now()))
            for pl in _task_places(task):
                conn.execute("INSERT OR IGNORE INTO user_ai_lib_place(place, item_key, sort_order) VALUES(?,?,?)",
                             (pl, kind, (i + 1) * 10))
            n += 1
    for pl, seeds in NEW_SEEDS.items():
        for i, (k, it, t, b) in enumerate(seeds):
            if k in have:
                # ★ 2026-10-22 씨앗 글이 바뀌었으면 — 「옛 씨앗 그대로인 줄」은 새 글로 · 사람이 고친 글은 그대로(seed_body 만 새 것 ·
                #   [기본으로] 가 새 씨앗으로 돌아온다) · 제목은 안 건드린다(사용자가 바꾼 제목이 산다)
                r = conn.execute("SELECT lib_id, body, seed_body FROM user_ai_lib WHERE item_key=? AND lang_code='KO'", (k,)).fetchone()
                if r and (r[2] or '') != b:
                    untouched = (r[1] or '') == (r[2] or '')
                    conn.execute("UPDATE user_ai_lib SET seed_body=?, body=? WHERE lib_id=?", (b, b if untouched else r[1], r[0]))
                    n += 1
                continue
            conn.execute("INSERT OR IGNORE INTO user_ai_lib(item_key, lang_code, itype, title, body, seed_title, seed_body,"
                         " updated_at) VALUES(?,?,?,?,?,?,?,?)", (k, 'KO', it, t, b, t, b, _now()))
            conn.execute("INSERT OR IGNORE INTO user_ai_lib_place(place, item_key, sort_order) VALUES(?,?,?)",
                         (pl, k, (i + 1) * 10))
            n += 1
    for (kind, lg), (old, new) in getattr(UA, 'TEACH_RENEW', {}).items():
        r = conn.execute("SELECT lib_id, body, seed_body FROM user_ai_lib WHERE item_key=? AND lang_code=?", (kind, lg)).fetchone()
        if r and old in (r[1] or ''):
            conn.execute("UPDATE user_ai_lib SET body=?, seed_body=? WHERE lib_id=?",
                         ((r[1] or '').replace(old, new), (r[2] or '').replace(old, new), r[0]))
            n += 1
    if n:
        conn.commit()
    return n


# ── 읽기·쓰기 ────────────────────────────────────────────────────────
def _pick_lang(conn, key, lang):
    """그 언어 → 한국어 → 영어 → 무엇이든(한국어가 먼저 서는 구조)."""
    for lg in ((lang or 'KO').upper(), 'KO', 'EN'):
        r = conn.execute("SELECT lib_id, title, body, itype, lang_code FROM user_ai_lib"
                         " WHERE item_key=? AND lang_code=? AND record_status='LIVE'", (key, lg)).fetchone()
        if r:
            return r
    return conn.execute("SELECT lib_id, title, body, itype, lang_code FROM user_ai_lib"
                        " WHERE item_key=? AND record_status='LIVE' ORDER BY lib_id LIMIT 1", (key,)).fetchone()


def items(conn, lang='KO', itype=None):
    """라이브러리 전체 — `[(item_key, title, body, itype, lang_code)]` 이름 차례."""
    ensure(conn)
    keys = [r[0] for r in conn.execute("SELECT DISTINCT item_key FROM user_ai_lib WHERE record_status='LIVE'")]
    out = []
    for k in keys:
        r = _pick_lang(conn, k, lang)
        if r and (itype is None or r[3] == itype):
            out.append((k, r[1], r[2], r[3], r[4]))
    return sorted(out, key=lambda x: (x[3] != 'TASK', x[1] or ''))


def place_items(conn, place, lang='KO', itype=None):
    """그 자리에서 쓰는 항목 — `[(item_key, title, body, itype, lang_code)]` 자리 차례."""
    ensure(conn)
    out = []
    for k, in conn.execute("SELECT item_key FROM user_ai_lib_place WHERE place=? AND on_flag=1"
                           " ORDER BY sort_order, rowid", (place,)):
        r = _pick_lang(conn, k, lang)
        if r and (itype is None or r[3] == itype):
            out.append((k, r[1], r[2], r[3], r[4]))
    return out


def place_rows(conn, place, lang='KO', itype=None):
    """그 자리의 항목 — 번호까지 `[(lib_id, item_key, title, body, itype, lang_code)]`."""
    ensure(conn)
    out = []
    for k, in conn.execute("SELECT item_key FROM user_ai_lib_place WHERE place=? AND on_flag=1"
                           " ORDER BY sort_order, rowid", (place,)):
        r = _pick_lang(conn, k, lang)
        if r and (itype is None or r[3] == itype):
            out.append((r[0], k, r[1], r[2], r[3], r[4]))
    return out


def row_of(conn, lib_id):
    """번호 → (item_key, lang_code, title, body, itype) 또는 None."""
    return conn.execute("SELECT item_key, lang_code, title, body, itype FROM user_ai_lib WHERE lib_id=?",
                        (int(lib_id),)).fetchone()


def lib_on(conn):
    """라이브러리를 쓰고 있나 — 표가 있고 옮기기를 마쳤다."""
    try:
        if not conn.execute("SELECT 1 FROM userdb.sqlite_master WHERE name='user_ai_lib'").fetchone():
            return False
    except Exception:                                     # noqa: BLE001
        return False
    return bool(UA.get_setting(conn, MIGRATED_KEY, ''))


def places_of(conn, key):
    ensure(conn)
    return [r[0] for r in conn.execute("SELECT place FROM user_ai_lib_place WHERE item_key=? AND on_flag=1"
                                       " ORDER BY place", (key,))]


def set_used(conn, place, key, on=True):
    """그 자리에서 이 항목을 쓰나 — 켜면 맨 뒤에 붙는다."""
    ensure(conn)
    if on:
        mx = conn.execute("SELECT COALESCE(MAX(sort_order),0) FROM user_ai_lib_place WHERE place=?",
                          (place,)).fetchone()[0]
        conn.execute("INSERT OR IGNORE INTO user_ai_lib_place(place, item_key, sort_order) VALUES(?,?,?)",
                     (place, key, int(mx) + 10))
        conn.execute("UPDATE user_ai_lib_place SET on_flag=1 WHERE place=? AND item_key=?", (place, key))
    else:
        # ★ 2026-10-21 1:1 — 끄면 자리에 남기고 표시만 끈다(그 자리의 항목이 사라지지 않는다)
        conn.execute("UPDATE user_ai_lib_place SET on_flag=0 WHERE place=? AND item_key=?", (place, key))
    conn.commit()


def save_item(conn, key, lang, title=None, body=None):
    """글을 적는다 — 그 언어 줄이 없으면 새로(번역을 담을 자리)."""
    ensure(conn)
    lg = (lang or 'KO').upper()
    r = conn.execute("SELECT lib_id, itype FROM user_ai_lib WHERE item_key=? AND lang_code=?", (key, lg)).fetchone()
    if r:
        if title is not None:
            conn.execute("UPDATE user_ai_lib SET title=? WHERE lib_id=?", (title, r[0]))
        if body is not None:
            conn.execute("UPDATE user_ai_lib SET body=? WHERE lib_id=?", (body, r[0]))
        conn.execute("UPDATE user_ai_lib SET updated_at=?, record_status='LIVE' WHERE lib_id=?", (_now(), r[0]))
    else:
        base = _pick_lang(conn, key, lg)
        it = base[3] if base else 'PICK'
        conn.execute("INSERT INTO user_ai_lib(item_key, lang_code, itype, title, body, updated_at)"
                     " VALUES(?,?,?,?,?,?)", (key, lg, it, title or '', body or '', _now()))
    conn.commit()


def add_item(conn, lang, title, body='', itype='PICK', places=(), key=None):
    """사람이 새 항목을 더한다 — 열쇠 `L_<번호>`(폰에서 더한 것은 폰이 지은 열쇠 `M_…` 그대로)."""
    ensure(conn)
    if key:
        if not re.match(r'^M_[A-Za-z0-9]{4,40}$', key):
            raise ValueError('key')
        if conn.execute("SELECT 1 FROM user_ai_lib WHERE item_key=?", (key,)).fetchone():
            return key                                    # 같은 것이 두 번 와도 한 번(멱등)
        conn.execute("INSERT INTO user_ai_lib(item_key, lang_code, itype, title, body, updated_at)"
                     " VALUES(?,?,?,?,?,?)", (key, (lang or 'KO').upper(), itype,
                                              (title or '').strip() or '새 항목', body or '', _now()))
        conn.commit()
        for pl in places:
            set_used(conn, pl, key, True)
        return key
    n = 1
    for k, in conn.execute("SELECT item_key FROM user_ai_lib WHERE item_key LIKE 'L\\_%' ESCAPE '\\'"):
        m = re.match(r'L_(\d+)$', k)
        if m:
            n = max(n, int(m.group(1)) + 1)
    key = 'L_%d' % n
    conn.execute("INSERT INTO user_ai_lib(item_key, lang_code, itype, title, body, updated_at)"
                 " VALUES(?,?,?,?,?,?)", (key, (lang or 'KO').upper(), itype,
                                          (title or '').strip() or '새 항목', body or '', _now()))
    conn.commit()
    for pl in places:
        set_used(conn, pl, key, True)
    return key


def hide_item(conn, key):
    """지운다(HIDE · 모든 언어) — 자리에서도 뗀다."""
    ensure(conn)
    # ★ 2026-10-31 초기값 복구가 제자리로 되돌릴 수 있게 있던 자리를 적어 둔다
    try:
        pls = [r[0] for r in conn.execute("SELECT place FROM user_ai_lib_place WHERE item_key=?", (key,))]
        if pls:
            d = json.loads(UA.get_setting(conn, HIDDEN_PLACES_KEY, '') or '{}')
            d[key] = pls
            UA.set_setting(conn, HIDDEN_PLACES_KEY, json.dumps(d, ensure_ascii=False))
    except Exception:                                     # noqa: BLE001
        pass
    conn.execute("UPDATE user_ai_lib SET record_status='HIDE', updated_at=? WHERE item_key=?", (_now(), key))
    conn.execute("DELETE FROM user_ai_lib_place WHERE item_key=?", (key,))
    conn.commit()


def reset_item(conn, key, lang):
    """초기값으로 — 처음 글이 없는(사람이 만든) 항목이면 False."""
    ensure(conn)
    r = conn.execute("SELECT seed_title, seed_body FROM user_ai_lib WHERE item_key=? AND lang_code=?",
                     (key, (lang or 'KO').upper())).fetchone()
    if not r or r[1] is None:
        return False
    conn.execute("UPDATE user_ai_lib SET title=?, body=?, updated_at=? WHERE item_key=? AND lang_code=?",
                 (r[0], r[1], _now(), key, (lang or 'KO').upper()))
    conn.commit()
    return True


# ── 초기값 전체 · 골라서 복구(2026-10-31 사용자) ─────────────────────
#: 고친 글에서 되돌리는 것은 뜻이 없을 수 있다 — 관리자가 넣은 처음 글을 전부 보이고, 선택한 것만 되돌린다.
HIDDEN_PLACES_KEY = 'AI_LIB_HIDDEN_PLACES'
TASK_PFX = 'T:'


def _places_for_restore(conn, key):
    have = [r[0] for r in conn.execute("SELECT place FROM user_ai_lib_place WHERE item_key=?", (key,))]
    if have:
        return have
    try:
        d = json.loads(UA.get_setting(conn, HIDDEN_PLACES_KEY, '') or '{}')
        if d.get(key):
            return list(d[key])
    except Exception:                                     # noqa: BLE001
        pass
    if '~' in key:
        return [key.split('~', 1)[1]]
    return [pl for pl, seeds in NEW_SEEDS.items() if any(s[0] == key for s in seeds)]


def seed_rows(conn, lang='KO'):
    """처음 글 전체 → `[{key, group, itype, title, body, state}]` · state SAME 그대로 · EDITED 고침 · GONE 지움.
    사람이 만든 항목(처음 글 없음)은 없다."""
    ensure(conn)
    lg = (lang or 'KO').upper()
    names = {p[0]: p for p in all_places(conn, lg)}
    out = []
    # 업무 글(질문프롬프트 · 역할)
    for kind, sd in list(UA.SEED_TASK.items()) + list(UA.SEED_ROLE.items()):
        s = sd.get(lg) or sd.get('EN')
        if not s:
            continue
        r0 = conn.execute("SELECT title, body FROM user_ai_prompt WHERE kind=? AND lang_code=? AND record_status='LIVE' LIMIT 1", (kind, lg)).fetchone()
        title, body = r0 if r0 else (s[0], s[1])
        same = _norm(body) == _norm(s[1]) and _norm(title) == _norm(s[0])
        out.append({'key': TASK_PFX + kind, 'group': '질문프롬프트 글', 'itype': 'TASK',
                    'title': s[0] or kind, 'body': s[1], 'state': 'SAME' if same else 'EDITED'})
    keys = [r[0] for r in conn.execute("SELECT DISTINCT item_key FROM user_ai_lib WHERE seed_body IS NOT NULL")]
    for k in sorted(keys):
        r = None
        for g in (lg, 'EN', 'KO'):
            r = conn.execute("SELECT title, body, seed_title, seed_body, itype, record_status FROM user_ai_lib"
                             " WHERE item_key=? AND lang_code=? AND seed_body IS NOT NULL", (k, g)).fetchone()
            if r:
                break
        if not r:
            continue
        pls = _places_for_restore(conn, k)
        p = names.get(pls[0]) if pls else None
        gone = r[5] != 'LIVE' or not conn.execute("SELECT 1 FROM user_ai_lib_place WHERE item_key=?", (k,)).fetchone()
        same = _norm(r[0]) == _norm(r[2]) and _norm(r[1]) == _norm(r[3])
        out.append({'key': k, 'group': ('%s · %s' % (p[1], p[2])) if p else '자리를 모르는 항목', 'itype': r[4],
                    'title': r[2] or k, 'body': r[3], 'state': 'GONE' if gone else ('SAME' if same else 'EDITED')})
    return sorted(out, key=lambda x: (x['group'], x['itype'] != 'TASK', x['title']))


def restore_seed(conn, key, lang='KO'):
    """그 항목 하나만 처음 글로(지운 것은 제자리로) → 됐으면 True · 돌아갈 자리를 모르면 False."""
    ensure(conn)
    lg = (lang or 'KO').upper()
    if key.startswith(TASK_PFX):
        return bool(UA.reset_task(conn, key[len(TASK_PFX):], lg))
    row = None
    for g in (lg, 'EN', 'KO'):
        row = conn.execute("SELECT lang_code FROM user_ai_lib WHERE item_key=? AND lang_code=? AND seed_body IS NOT NULL",
                           (key, g)).fetchone()
        if row:
            break
    if not row:
        return False
    pls = _places_for_restore(conn, key)
    if not pls:
        return False
    conn.execute("UPDATE user_ai_lib SET title=seed_title, body=seed_body, updated_at=? WHERE item_key=? AND lang_code=?",
                 (_now(), key, row[0]))
    conn.execute("UPDATE user_ai_lib SET record_status='LIVE' WHERE item_key=?", (key,))
    for pl in pls:
        if not conn.execute("SELECT 1 FROM user_ai_lib_place WHERE item_key=? AND place=?", (key, pl)).fetchone():
            n = conn.execute("SELECT COALESCE(MAX(sort_order),0)+10 FROM user_ai_lib_place WHERE place=?", (pl,)).fetchone()[0]
            conn.execute("INSERT INTO user_ai_lib_place(place, item_key, sort_order, on_flag) VALUES(?,?,?,1)", (pl, key, n))
    conn.commit()
    return True


def is_edited(conn, key, lang):
    r = conn.execute("SELECT title, body, seed_title, seed_body FROM user_ai_lib WHERE item_key=? AND lang_code=?",
                     (key, (lang or 'KO').upper())).fetchone()
    return bool(r and r[3] is not None and (_norm(r[0]) != _norm(r[2]) or _norm(r[1]) != _norm(r[3])))


def apply_phone(conn, d):
    """폰에서 고친 것(보낼 함 `AI_LIB`) — op: save · use · add · hide. → 결과 글자(mobile_sync 사건 결과)."""
    ensure(conn)
    op = (d.get('op') or '').lower()
    key = (d.get('key') or '').strip()
    lang = (d.get('lang') or 'KO').upper()
    if op == 'restore':
        return 'RESTORED' if restore_seed(conn, key, lang) else 'SKIP'
    known = key and conn.execute("SELECT 1 FROM user_ai_lib WHERE item_key=?", (key,)).fetchone()
    if op == 'add':
        try:
            add_item(conn, lang, d.get('title') or '', d.get('body') or '',
                     places=[p for p in (d.get('places') or []) if known_place(conn, p)], key=key)
        except ValueError:
            return 'SKIP'
        return 'ADDED'
    if not known:
        return 'SKIP'
    if op == 'save':
        save_item(conn, key, lang, d.get('title'), d.get('body'))
        return 'SAVED'
    if op == 'use':
        pl = d.get('place') or ''
        if not known_place(conn, pl):
            return 'SKIP'
        set_used(conn, pl, key, bool(d.get('on')))
        return 'USED' if d.get('on') else 'UNUSED'
    if op == 'hide':
        hide_item(conn, key)
        return 'HIDDEN'
    return 'SKIP'


# ══════════════════════════════════════════════════════════════════════
def _mem():
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.execute("ATTACH ':memory:' AS userdb")
    c.execute("CREATE TABLE userdb.user_config (config_key TEXT PRIMARY KEY, config_val TEXT)")
    UA.init(c)
    return c


def selftest():
    ok = 0
    fails = []

    def ck(cond, msg):
        nonlocal ok
        if cond:
            ok += 1
        else:
            fails.append(msg)

    c = _mem()
    ins = ("INSERT INTO user_ai_prompt(lang_code, kind, title, body, sort_order, scope, genre, task, record_status)"
           " VALUES(?,?,?,?,?,?,?,?,?)")
    # 같은 글이 세 업무에 · 한 업무에서 사람이 고침 · 한 업무에서 지움 · 사람이 만든 것 · 업무 글(Pick 아님)
    for tk in ('ASK', 'DESC', 'RESEARCH'):
        c.execute(ins, ('KO', 'APPLY', '묵상 적용', '적용을 짚어 주세요.', 10, 'VERSE', 'CHAT', tk, 'LIVE'))
        c.execute(ins, ('EN', 'APPLY', 'Apply', 'Point out application.', 10, 'VERSE', 'CHAT', tk, 'LIVE'))
    c.execute(ins, ('KO', 'APPLY', '묵상 적용', '내가 고친 글', 10, 'VERSE', 'CHAT', 'XDESC', 'LIVE'))
    c.execute(ins, ('EN', 'APPLY', 'Apply', 'Point out application.', 10, 'VERSE', 'CHAT', 'LINKAN', 'LIVE'))
    c.execute(ins, ('KO', 'ORIG', '원어', '원어 설명', 20, 'VERSE', 'CHAT', 'ASK', 'LIVE'))
    c.execute(ins, ('KO', 'ORIG', '원어', '원어 설명', 20, 'VERSE', 'CHAT', 'DESC', 'HIDE'))
    c.execute(ins, ('KO', 'USER77', '내 물음', '내 글', 30, 'VERSE', 'CHAT', 'ASK', 'LIVE'))
    c.execute(ins, ('KO', 'T_ASK', '구절질문', '업무 글', 0, 'TASK', 'ANAL', 'X', 'LIVE'))
    before = c.execute("SELECT COUNT(*), GROUP_CONCAT(body) FROM user_ai_prompt").fetchone()

    pid_ask = c.execute("SELECT prompt_id FROM user_ai_prompt WHERE kind='ORIG' AND task='ASK'").fetchone()[0]
    UA.set_setting(c, 'AI_LAST_VERSE_ASK', json.dumps({'checked': [pid_ask, 99999]}))
    st = migrate(c, dry=True, prime=False)
    ck(st.get('split') == 1, '고친 사본 하나가 따로 갈라진다 %r' % st)
    ck(c.execute("SELECT COUNT(*) FROM user_ai_lib").fetchone()[0] == 0, 'dry 는 안 쓴다')
    migrate(c, prime=False)
    keys = {r[0] for r in c.execute("SELECT DISTINCT item_key FROM user_ai_lib")}
    _chk = json.loads(UA.get_setting(c, 'AI_LAST_VERSE_ASK'))['checked']
    _orig = c.execute("SELECT lib_id FROM user_ai_lib WHERE item_key='ORIG' AND lang_code='KO'").fetchone()[0]
    ck(_chk == [-_orig], '직전값이 라이브러리 번호로(없는 번호는 뺀다) %r' % _chk)
    ck(lib_on(c) and row_of(c, _orig)[0] == 'ORIG', '라이브러리 켜짐 · 번호로 찾기')
    ck([r[1] for r in place_rows(c, 'VERSE:ASK')][:1] == ['APPLY'], '자리 줄(번호 포함)')
    ck('APPLY' in keys and 'APPLY@VERSE:XDESC' in keys, '합침·따로 남김 %r' % keys)
    # ★★★ 2026-10-21 1:1 — 같이 쓰던 항목은 자리마다 사본으로 나뉜다(첫 자리가 원래 열쇠)
    _shared = c.execute("SELECT item_key FROM user_ai_lib_place GROUP BY item_key HAVING COUNT(*)>1").fetchall()
    ck(not _shared, '1:1 — 두 자리에 붙은 항목이 없다 %r' % _shared)
    ck(_chk == [-_orig] and json.loads(UA.get_setting(c, 'AI_LAST_VERSE_ASK'))['checked'] == [-_orig],
       '1:1 — 첫 자리(구절질문) 직전값은 그대로')
    ck(c.execute("SELECT COUNT(*) FROM user_ai_lib WHERE item_key='APPLY'").fetchone()[0] == 2, '언어마다 한 줄')
    _b = lambda pl: [x[0].split('~')[0] for x in place_items(c, pl)]
    ck([x[0] for x in place_items(c, 'VERSE:ASK')][:1] == ['APPLY'], '구절질문 자리 = APPLY 먼저')
    ck('APPLY' not in _b('VERSE:XDESC'), '고친 자리는 제 사본만')
    ck('APPLY@VERSE:XDESC' in _b('VERSE:XDESC'), '고친 사본이 그 자리에')
    ck('ORIG' not in _b('VERSE:DESC'), '지운 자리에는 안 단다')
    ck('APPLY' in _b('VERSE:LINKAN') and 'APPLY~VERSE:LINKAN' in [x[0] for x in place_items(c, 'VERSE:LINKAN')],
       '영어 사본만 있는 업무도 같은 항목 · 1:1 사본')
    ck('ORIG' in [x[0] for x in place_items(c, 'VERSE:ASK')], '다른 자리에는 남는다')
    ck('USER77' in [x[0] for x in place_items(c, 'VERSE:ASK')], '사람이 만든 것도 옮긴다')
    ck('T_ASK' not in keys, '업무 글은 Pick 이 아니다')
    ck(not [k for k in keys if 'RESEARCH' in k] and
       not c.execute("SELECT 1 FROM user_ai_lib_place WHERE place LIKE '%RESEARCH%'").fetchone(), '연구하자 → 구절질문')
    ck(before == c.execute("SELECT COUNT(*), GROUP_CONCAT(body) FROM user_ai_prompt").fetchone(), '원래 표 불변')
    # 새 자리
    for pl in NEW_SEEDS:
        its = place_items(c, pl)
        ck(its and its[0][3] == 'TASK' and len(its) >= (4 if pl.startswith('CARD:') else 5), '새 자리 %s 씨앗' % pl)
    ck(all(pl in PLACE_KEYS for pl in NEW_SEEDS), '새 자리가 자리 목록에')
    ck(place_items(c, 'NEWS', lang='JA')[0][4] == 'KO', '번역이 없으면 한국어로 물러선다')
    # 1:1 — 한 곳에서 고쳐도 다른 자리 사본은 그대로
    save_item(c, 'APPLY', 'KO', body='새 글')
    ck(place_items(c, 'VERSE:ASK')[0][2] == '새 글' and
       [x for x in place_items(c, 'VERSE:DESC') if x[0] == 'APPLY~VERSE:DESC'][0][2] != '새 글', '1:1 — 다른 자리는 안 따라온다')
    ck(is_edited(c, 'APPLY', 'KO'), '고친 표시')
    ck(reset_item(c, 'APPLY', 'KO') and not is_edited(c, 'APPLY', 'KO'), '초기값으로')
    ck(not reset_item(c, 'USER77', 'KO') or _seed_text('USER77', 'KO') is None, '사람 것은 초기값이 자기 글')
    # 자리 켜고 끄기 · 더하기 · 지우기
    set_used(c, 'VERSE:ASK', 'APPLY', False)
    ck('VERSE:ASK' not in places_of(c, 'APPLY') and place_of(c, 'APPLY') == 'VERSE:ASK'
       and [x for x in place_all(c, 'VERSE:ASK') if x[0] == 'APPLY'][0][5] == 0, '표시를 끄면 자리에 남고 안 보인다')
    set_used(c, 'VERSE:ASK', 'APPLY', True)
    ck('VERSE:ASK' in places_of(c, 'APPLY'), '다시 켠다')
    set_used(c, 'CARD', 'APPLY', True)                    # 다른 자리에 붙이면(폰 옛 동작) — 사본으로 나뉜다
    ck(place_of(c, 'APPLY') == 'VERSE:ASK' and 'APPLY~CARD' in [x[0] for x in place_items(c, 'CARD')],
       '다른 자리에 붙이면 사본')
    _p0 = [x[0] for x in place_all(c, 'VERSE:ASK')]
    ck(move_item(c, 'VERSE:ASK', _p0[0], 1) and [x[0] for x in place_all(c, 'VERSE:ASK')][:2] == [_p0[1], _p0[0]], '차례 옮기기')
    ck(unit_of('VERSE:FREE') == 'FREE' and unit_of('BOOK:NOTE') == 'BOOK_NOTE', '직전값 단위')
    # 초기값 복구 — 고친 것 하나만 · 지운 것은 제자리로 · 다른 항목은 안 바뀐다
    _rows = {x['key']: x for x in seed_rows(c, 'KO')}
    ck('HF_1' in _rows and _rows['HF_1']['state'] == 'SAME' and 'T:ASK' in _rows or 'HF_1' in _rows, '초기값 전체')
    _b1, _b2 = _rows['HF_1']['body'], _rows['HF_2']['body']
    save_item(c, 'HF_1', 'KO', body='망친 글')
    save_item(c, 'HF_2', 'KO', body='다른 글')
    ck({x['key']: x for x in seed_rows(c, 'KO')}['HF_1']['state'] == 'EDITED', '고친 것 표시')
    ck(restore_seed(c, 'HF_1', 'KO') and [x for x in place_items(c, 'HOME:FIND') if x[0] == 'HF_1'][0][2] == _b1, '선택한 것만 복구')
    ck([x for x in place_items(c, 'HOME:FIND') if x[0] == 'HF_2'][0][2] == '다른 글', '다른 항목은 그대로')
    restore_seed(c, 'HF_2', 'KO')
    hide_item(c, 'HF_3')
    ck({x['key']: x for x in seed_rows(c, 'KO')}['HF_3']['state'] == 'GONE', '지운 것도 보인다')
    ck(restore_seed(c, 'HF_3', 'KO') and 'HF_3' in [x[0] for x in place_items(c, 'HOME:FIND')], '지운 것을 제자리로')
    ck(apply_phone(c, {'op': 'restore', 'key': 'HF_3', 'lang': 'KO'}) == 'RESTORED', '폰에서 온 복구')
    k = add_item(c, 'KO', '새 Pick', '본문', places=('HOME:MEDI',))
    ck(k not in [x['key'] for x in seed_rows(c, 'KO')], '사람이 만든 항목은 초기값이 없다')
    ck(k.startswith('L_') and k in [x[0] for x in place_items(c, 'HOME:MEDI')], '더하기')
    ck(add_item(c, 'KO', '또') != k, '열쇠가 겹치지 않는다')
    save_item(c, k, 'EN', 'New pick', 'body')
    ck(place_items(c, 'HOME:MEDI', lang='EN')[-1][1] == 'New pick' or
       [x for x in place_items(c, 'HOME:MEDI', lang='EN') if x[0] == k][0][1] == 'New pick', '언어 줄 더하기')
    hide_item(c, k)
    ck(k not in [x[0] for x in items(c)] and not places_of(c, k), '지우기')
    # 새로 생긴 씨앗이 이어진다 · 옛 씨앗 글은 새 글로
    _tk, _rows = next(iter(UA.TASK_PICK_SEEDS.items()))
    _k0 = _rows[-1][0]
    c.execute("DELETE FROM user_ai_lib WHERE item_key=?", (_k0,))
    c.execute("DELETE FROM user_ai_lib_place WHERE item_key=?", (_k0,))
    ck(sync_seeds(c) >= 1 and _k0 in [x[0] for x in items(c)], '코드에 더한 씨앗이 라이브러리에 이어진다')
    ck(sync_seeds(c) == 0, '두 번째는 아무것도 안 한다')
    hide_item(c, _k0)
    ck(sync_seeds(c) == 0 and _k0 not in [x[0] for x in items(c)], '지운 씨앗은 되살리지 않는다')
    # 폰에서 온 것
    ck(apply_phone(c, {'op': 'add', 'key': 'M_abcd1234', 'lang': 'KO', 'title': '폰 Pick', 'body': 'b',
                       'places': ['VERSE:ASK', 'NOPE']}) == 'ADDED' and places_of(c, 'M_abcd1234') == ['VERSE:ASK'], '폰 더하기(모르는 자리 무시)')
    ck(apply_phone(c, {'op': 'add', 'key': 'M_abcd1234', 'title': 'x'}) == 'ADDED' and
       c.execute("SELECT COUNT(*) FROM user_ai_lib WHERE item_key='M_abcd1234'").fetchone()[0] == 1, '폰 더하기 멱등')
    ck(apply_phone(c, {'op': 'add', 'key': 'bad key!', 'title': 'x'}) == 'SKIP', '이상한 열쇠 거부')
    ck(apply_phone(c, {'op': 'save', 'key': 'M_abcd1234', 'lang': 'KO', 'title': '고침', 'body': 'b2'}) == 'SAVED'
       and _pick_lang(c, 'M_abcd1234', 'KO')[1] == '고침', '폰 고치기')
    ck(apply_phone(c, {'op': 'use', 'key': 'M_abcd1234', 'place': 'NEWS', 'on': True}) == 'USED' and 'M_abcd1234~NEWS' in [x[0] for x in place_items(c, 'NEWS')], '폰 켜기(1:1 — 그 자리 사본)')
    ck(apply_phone(c, {'op': 'save', 'key': 'NO_SUCH', 'body': 'x'}) == 'SKIP', '모르는 항목 무시')
    ck(apply_phone(c, {'op': 'hide', 'key': 'M_abcd1234'}) == 'HIDDEN' and not places_of(c, 'M_abcd1234'), '폰 지우기')
    # ★ 새로 깐 PC(빈 개인 DB) — 업무별 사본이 없어도 구절질문 Pick 이 라이브러리에 들어온다
    c2 = _mem()
    migrate(c2)
    ck(len(place_items(c2, 'VERSE:ASK', 'KO')) >= 5 and place_items(c2, 'HOME:MEDI')[0][3] == 'TASK',
       '빈 DB 에서도 구절질문 Pick · 새 자리')
    # 멱등 · 되돌리기
    n0 = c.execute("SELECT COUNT(*) FROM user_ai_lib").fetchone()[0]
    ck(migrate(c, prime=False).get('skipped'), '두 번째는 건너뛴다')
    migrate(c, force=True, prime=False)
    ck(c.execute("SELECT COUNT(*) FROM user_ai_lib").fetchone()[0] == n0, '다시 해도 안 는다')
    # ★ 2026-10-28 사람이 더한 카드 갈래
    cp = add_card_place(c, 'KO', '이사')
    ck(cp == 'CARD:U1', '카드 갈래 열쇠')
    ap = [x[0] for x in all_places(c)]
    ck(ap.index(cp) == ap.index('CARD:FEAST') + 1, '앱 카드 갈래 바로 뒤')
    ck(user_places(c)[0][2] == '이사', '이름 = 갈래 글 제목에서')
    ck(len(place_rows(c, cp, 'KO', 'TASK')) == 1, '갈래 글이 그 자리에')
    ck(known_place(c, cp) and known_place(c, 'HOME:UT_3') and not known_place(c, 'CARD:U9'), '아는 자리')
    k9 = add_item(c, 'KO', '새집', 'b')
    ck(apply_phone(c, {'op': 'use', 'key': k9, 'place': cp, 'on': True}) == 'USED', '폰이 내 갈래에 Pick 켜기')
    ck(add_card_place(c, 'KO', '') == 'CARD:U2', '둘째 갈래')
    ck(remove_place(c, cp) and cp not in [x[0] for x in all_places(c)], '갈래 걷기')
    ck(not place_rows(c, cp, 'KO', 'TASK'), '걷으면 갈래 글도 숨김')
    undo(c)
    ck(not c.execute("SELECT 1 FROM userdb.sqlite_master WHERE name='user_ai_lib'").fetchone(), '되돌리기')
    ck(json.loads(UA.get_setting(c, 'AI_LAST_VERSE_ASK'))['checked'] == [pid_ask, 99999], '직전값도 옛 번호로 되돌린다')
    ck(not lib_on(c), '되돌리면 라이브러리 꺼짐')
    ck(before == c.execute("SELECT COUNT(*), GROUP_CONCAT(body) FROM user_ai_prompt").fetchone(), '되돌려도 원래 표 불변')
    # 새 자리 씨앗 — 화면 금지어 · 보기 문장 없음
    for pl, seeds in NEW_SEEDS.items():
        for k2, it, t, b in seeds:
            ck(not re.search(r'고르|고른|골라', t + b), '「고르기」 금지 %s' % k2)
            ck('예:' not in b and '예)' not in b, '보기 문장 없음 %s' % k2)
    print('ai_lib selftest %d/%d' % (ok, ok + len(fails)))
    for f in fails:
        print('  FAIL', f)
    return not fails


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    import appdb
    c = appdb.connect()
    if '--undo' in a:
        undo(c)
        print('undo ok')
    elif '--migrate' in a:
        print(json.dumps(migrate(c, dry='--dry' in a, force='--force' in a), ensure_ascii=False))
    elif '--list' in a:
        i = a.index('--list')
        pl = a[i + 1] if len(a) > i + 1 else None
        rows = place_items(c, pl) if pl else items(c)
        for k, t, b, it, lg in rows:
            print('%-22s %-4s %-3s %s' % (k, it, lg, t))
    else:
        print(__doc__)


if __name__ == '__main__':
    main()
