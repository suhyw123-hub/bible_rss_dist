# -*- coding: utf-8 -*-
"""asset_strip.py — 「연결된 자산 보기」 공용 부품 (2026-09-03 0.txt 1번 · 영구).

도서/설교 3단의 연결 자산 판(§121~122차)이 원형이다 — 종류별 줄 · 빈 묶음
생략 · 실측 폭 줄바꿈 · 접이. 화면마다 베끼면 §111차류 칸 밀림이 재발하므로
**새로 다는 화면은 이 부품 하나를 심는다** (말씀의 흐름이 첫 사용처 —
사용자 확정 「연결자산보기 기능은 공간이 허용된다면 모두 도서/설교의 모델
기준으로 통일하자」).

⚠ 도서/설교 화면 자체(p1_reading_view)는 아직 자기 구현을 쓴다 — 그쪽은
  USER_REF 특례·도서 이동 경고(askyesno)가 얽혀 있어 옮기는 일은 별도
  정리 과제다. 묶음 표(GROUPS)와 i18n 열쇠(PR_G_*)는 같은 것을 쓴다.

사용:
    strip = AssetStrip(parent, db_path, lang_getter, on_jump)
    n = strip.load('CHAIN', chain_id)   # 그리고 개수 — 0 이면 판이 빈다
    strip.pack(...) / pack_forget()     # 접이는 호스트 단추가 한다

python asset_strip.py --selftest  (의무)
"""
import io
import sys
import tkinter as tk

import i18n

# 묶음 표 — p1_reading_view._ASSET_GROUPS 와 같은 축(열쇠도 공유)
GROUPS = (
    ('PR_G_TERM',  '용어/태그',  ('ENTITY', 'TAG', 'UTAG')),
    ('PR_G_VERSE', '구절',      ('VERSE', 'PERICOPE')),
    ('PR_G_BOOK',  '도서/설교',  ('BOOK', 'BOOK_UNIT')),
    ('PR_G_PLAN',  '묵상플랜',   ('PLAN', 'LENS', 'ULENS', 'NODE', 'UNODE')),
    ('PR_G_REF',   '연구자료',   ('REF_UNIT', 'USER_REF')),
    ('PR_G_NOTE',  '묵상노트',   ('NOTE',)),
    ('PR_G_MEDIA', '영상·링크',  ('MEDIA',)),
    ('PR_G_CHAIN', '구속사 흐름', ('CHAIN',)),
    ('PR_G_ETC',   '기타연결',   ()),          # 남는 것 전부
)


def _C(role, fb):
    try:
        import ui_theme
        return ui_theme.C(role) or fb
    except Exception:
        return fb


# ★ 자기 구조는 연결이 아니다 (2026-09-03 실측) — 렌즈의 links_of 에는
#   제 노드(CONT_NODE)가 11개씩 섞여 나온다. 그 줄을 자산 판에 올리면
#   「묵상플랜: 노드…」 잡음이 판을 덮는다. 앵커별 구조 자식을 거른다.
STRUCT_CHILD = {
    'LENS': ('NODE', 'UNODE'),
    'ULENS': ('NODE', 'UNODE'),
}


def fetch(conn, kind, aid, lang='KO'):
    """그 자산에 붙은 것 전부 → [(종류, 이름, 번호)].

    ⚠ 조회는 `link_picker.links_of` 한 문(§97차) — 여기서 SQL 을 또 쓰면
      덮개·가림 규칙이 갈라진다. 가린 줄은 기본에서 이미 빠져 온다."""
    import link_picker
    rows = []
    skip = STRUCT_CHILD.get(str(kind).upper(), ())
    for x in link_picker.links_of(conn, kind, aid, lang):
        k = (x.get('kind') or '').upper()
        if k in skip:
            continue
        label = (x.get('label') or '') or '#%s' % x.get('id')
        # 태그 이름 뒤의 축(`· THEME`)은 뗀다 — 묶음 이름이 이미 말한다
        if k in ('TAG', 'UTAG'):
            label = label.split('  ·')[0].strip()
        rows.append((k, label, x.get('id')))
    return rows


def group_rows(rows):
    """묶음별로 가른다 → [(i18n열쇠, 기본이름, [(종류,이름,번호)…])].

    빈 묶음은 내지 않는다 · 어느 묶음에도 없는 종류는 「기타연결」로."""
    out, seen = [], set()
    for key, dflt, kinds in GROUPS:
        if kinds:
            grp = [r for r in rows if r[0] in kinds]
        else:
            grp = [r for r in rows if r[0] not in seen]
        seen |= set(kinds)
        if grp:
            out.append((key, dflt, grp))
    return out


class AssetStrip(tk.Frame):
    """종류별 줄 + 실측 폭 줄바꿈 판. 접이는 호스트가 pack/pack_forget."""

    def __init__(self, parent, db_path, lang_getter=None, on_jump=None, **kw):
        kw.setdefault('bg', _C('panel', '#FDFEFE'))
        super().__init__(parent, **kw)
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.on_jump = on_jump          # on_jump(kind, id)
        self.count = 0

    def load(self, kind, aid):
        """자산 하나의 연결을 채운다 → 개수."""
        rows = []
        try:
            import appdb
            with appdb.connect(self.db_path) as conn:
                rows = fetch(conn, kind, aid, self.lang_getter() or 'KO')
        except Exception as e:
            print('[asset_strip] %s' % e)
        self._render(rows)
        self.count = len(rows)
        return self.count

    def _render(self, rows):
        for w in self.winfo_children():
            w.destroy()
        if not rows:
            return
        try:
            import tkinter.font as tkfont
            fnt = tkfont.Font(font=('Malgun Gothic', 9))
        except Exception:
            fnt = None

        def _w(s):
            return (fnt.measure(s) if fnt else len(s) * 8)

        self.update_idletasks()
        avail = max(self.winfo_width() - 12,
                    self.master.winfo_width() - 24, 240)
        bg = _C('panel', '#FDFEFE')
        self.configure(bg=bg)
        for key, dflt, grp in group_rows(rows):
            head = '%s: ' % i18n.t(key, dflt)
            row, used = None, 0
            for i, (k, text, aid) in enumerate(grp):
                w = _w(text) + 18
                if row is None or (used + w > avail and used > 0):
                    row = tk.Frame(self, bg=bg)
                    row.pack(fill='x', anchor='w')
                    used = 0
                    tk.Label(row, text=(head if i == 0 else ' ' * len(head)),
                             bg=bg, font=('', 9),
                             fg=_C('fg_dim', '#7F8C8D')).pack(side='left')
                    used += _w(head)
                lb = tk.Label(row, text=text, bg=bg, font=('', 9),
                              fg=_C('accent', '#2E86C1'))
                if callable(self.on_jump):
                    lb.config(cursor='hand2')
                    lb.bind('<Button-1>',
                            lambda _e, kk=k, ii=aid: self.on_jump(kk, ii))
                lb.pack(side='left', padx=(0, 12))
                used += w


def selftest():
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', errors='replace')
    ok = [0, 0]

    def t(name, cond):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s' % ('OK ' if cond else 'FAIL', name))

    # 묶음 표 불변식 — 한 종류가 두 묶음에 들지 않는다
    all_kinds = [k for _key, _d, ks in GROUPS for k in ks]
    t('묶음 표 — 종류 중복 0', len(all_kinds) == len(set(all_kinds)))
    t('묶음 표 — 기타연결이 마지막·빈 목록', GROUPS[-1][2] == ())
    rows = [('ENTITY', '갈렙', 1), ('MEDIA', '영상', 2),
            ('ZZZ', '낯선 종류', 3)]
    g = group_rows(rows)
    t('빈 묶음은 안 나온다', all(grp for _k, _d, grp in g))
    t('낯선 종류는 기타연결로', any(
        k == 'PR_G_ETC' and grp == [('ZZZ', '낯선 종류', 3)]
        for k, _d, grp in g))
    t('묶음 수 3', len(g) == 3)
    # 도서/설교 원형과 묶음 표가 같은가 — 갈라지면 두 화면이 딴 말을 한다
    try:
        import re
        src = open('p1_reading_view.py', encoding='utf-8').read()
        m = re.search(r'_ASSET_GROUPS = \((.*?)\n    \)', src, re.S)
        keys = re.findall(r"\('(PR_G_\w+)'", m.group(1)) if m else []
        t('원형(도서/설교)과 묶음 열쇠 일치',
          keys == [k for k, _d, _ks in GROUPS])
    except Exception:
        t('원형(도서/설교)과 묶음 열쇠 일치', False)
    print('asset_strip selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print(__doc__)
