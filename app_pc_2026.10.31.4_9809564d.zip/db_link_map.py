# -*- coding: utf-8 -*-
"""연결 지도 — **어느 자산 ↔ 어느 자산이 이어지는가** (2026-08-27 신설·영구).

★ 왜 (사용자 순서 확정): 「사용자화면에서 통합하기 전에 먼저 **관리자화면에서
  통합**이 이루어져야 한다. 관리자 화면에서는 아직도 **두 자산을 연결시키는
  개념이 없는 것들**이 있다.」
  ⇒ 붙이기 전에 **무엇이 있고 무엇이 없는지** 먼저 재야 한다. 안 재고 붙이면
    **빈 서랍**이 생긴다(§4-⑤ · 주석이 그 사례 — `link_type` 에 갈래가 0건).

무엇을 보나
  ① 실제로 쓰이는 조합(sys·user)과 행수
  ② **같은 짝이 두 이름으로 사는 것** — `A_B` 와 `B_A`
     ⚠ 이것이 늘 결함은 아니다. sys 의 `CONT_BOOK`↔`BOOK_CONT` 는 **방향**이다
       (「가는 길 ▶」·「오는 길 ◀」 — §3단계 실측). 그러나 **양쪽이 정확히 같은
       짝**이면 뒤집혀 두 번 들어간 것이다.
  ③ 연결에서 **아예 빠진 자산**
  ④ 화면 쪽 — 관리자 패널이 연결 개념을 갖고 있는가

`--selftest`(의무) · `--report`(사람이 읽는 표) · `--dup`(중복 짝만)
"""
import io
import os
import re
import sys

import appdb

SYS_TBL = 'sys_link_asset'
USER_TBL = 'userdb.user_link_asset'

#: 넉 자 코드 → (사람이 읽는 이름, 그 자산이 사는 표)
#  ⚠ **손으로 적는다** — 코드에서 자동으로 뽑을 수 없다(link_type 은 글자일 뿐).
#    새 코드가 생기면 여기 한 줄. 모르는 코드는 `--report` 가 「?」로 드러낸다.
ASSETS = {
    'VERS': ('구절', 'bible_index'),
    'ENTI': ('주요용어', 'sys_entity_master'),
    'PERI': ('구절단락', 'sys_pericope_asset'),
    'CONT': ('렌즈', 'sys_unit_asset'),
    'NODE': ('렌즈 노드', 'sys_unit_asset'),
    'BOOK': ('도서', 'sys_book_asset'),
    'BUNT': ('도서 편', 'sys_book_unit'),
    'REFU': ('자료집 글', 'sys_ref_unit'),
    'REFS': ('자료집', 'sys_ref_source'),
    'PLAN': ('묵상플랜', 'sys_bible_plan'),
    'MEDI': ('영상·링크', 'sys_media_asset'),
    'TAG':  ('태그', 'sys_tag_asset'),
    'RSSA': ('수집 자료', 'sys_ref_asset'),
    'UREF': ('내 연구자료', 'userdb.user_ref_asset'),
    'UTAG': ('내 태그', 'userdb.user_tag_asset'),
    # ★ 흐름 = 자산 (2026-08-27 사용자 확정) — 정수 신원은 sys_chain_master
    'CHAI': ('말씀의 흐름', 'sys_chain_master'),
    # ⚠ **코드는 `link_picker.CODE` 가 정한다** — 여기 손으로 적은 것이
    #   그것과 어긋나면 화면에 번호가 그대로 뜬다. selftest 가 대조한다.
    'UCNT': ('내 렌즈', 'userdb.user_unit_asset'),
    'UNOD': ('내 노드', 'userdb.user_unit_asset'),
}

#: 연결 개념이 **원래 없는** 자산 — 빈 서랍을 만들지 않기 위해 적어 둔다.
#  ⚠ 「아직 안 붙인 것」과 **다르다.** 여기 적은 것은 판단이 끝난 것이다.
NO_LINK = {
    'COMM': ('주석', '주석↔구절은 `sys_commentary_entry.start_vid` 가 이미 갖는다 — '
                    '연결 표에 또 넣으면 같은 사실이 두 곳이 된다'),
}


def combos(conn, tbl):
    """그 표에서 실제로 쓰이는 조합 → {link_type: 행수}."""
    try:
        return {r[0]: r[1] for r in conn.execute(
            'SELECT link_type, COUNT(*) FROM %s GROUP BY link_type' % tbl)}
    except Exception as e:
        print('[db_link_map] %s: %s' % (tbl, e))
        return {}


def split(lt):
    """`ENTI_UREF` → `('ENTI','UREF')`. 넉 자가 아니면 그대로 쪼갠다."""
    a, _, b = (lt or '').partition('_')
    return a, b


def reversed_pairs(cnt):
    """`A_B` 와 `B_A` 가 **둘 다** 있는 것 → `[(A_B, B_A)]`."""
    out = []
    for lt in cnt:
        a, b = split(lt)
        rev = '%s_%s' % (b, a)
        if rev in cnt and lt < rev:
            out.append((lt, rev))
    return sorted(out)


def same_pairs(conn, tbl, lt, rev):
    """뒤집힌 두 갈래를 잰다 → (겹침, lt만, rev만, 방향인가, 상태어긋남).

    ⚠⚠ **겹친다고 다 중복이 아니다** — 실측으로 갈렸다:
      · `BOOK_CONT`↔`CONT_BOOK` 은 겹침 2·양쪽 고유 0 이지만 **묵상경로**다
        (`rel='NEXT'` + 방향마다 **다른 안내문**: 「영혼 인도의 뿌리」 ↔
         「부르심의 실천」). **뜻이 다르므로 지우면 안 된다.**
      · `BUNT_UREF`↔`UREF_BUNT` 는 `rel`·`note` 가 **양쪽 다 비어 있다** —
        구별할 것이 없으니 **뒤집혀 두 번 들어간 것**이다.
      ⇒ 판정은 「겹치는가」가 아니라 **「구별값이 있는가」**로 한다.
    ★ 그리고 **상태 어긋남**을 함께 잰다 — 한 이름이 HIDE 인데 다른 이름이
      LIVE 면 **숨겼는데 안 숨는다**(실측 1건).
    """
    def rows(t):
        return {(r[0], r[1]): (r[2] or '', r[3] or '',
                               (r[4] or 'LIVE').upper())
                for r in conn.execute(
                    'SELECT clicked_id, target_id, rel_code, note, record_status '
                    '  FROM %s WHERE link_type=?' % tbl, (t,))}
    A = rows(lt)
    B = {(k[1], k[0]): v for k, v in rows(rev).items()}
    both = set(A) & set(B)
    # 구별값(관점·안내문)이 **한쪽에라도** 있으면 방향이다
    directed = any(A[k][0] or A[k][1] or B[k][0] or B[k][1] for k in both)
    mismatch = [k for k in both if A[k][2] != B[k][2]]
    return len(both), len(set(A) - set(B)), len(set(B) - set(A)), directed, mismatch


def orphan_assets(cnt_sys, cnt_user):
    """`ASSETS` 에 적혀 있는데 **어느 조합에도 안 나오는** 자산."""
    used = set()
    for c in (cnt_sys, cnt_user):
        for lt in c:
            used.update(split(lt))
    return sorted(k for k in ASSETS if k not in used)


def unknown_codes(cnt_sys, cnt_user):
    """조합에는 나오는데 `ASSETS` 에 없는 코드 — 이름을 못 대면 화면에 `#47` 이 뜬다."""
    used = set()
    for c in (cnt_sys, cnt_user):
        for lt in c:
            used.update(split(lt))
    return sorted(k for k in used if k and k not in ASSETS)


# ── 화면 쪽 ────────────────────────────────────────────────────────
def panels_with_link():
    """관리자 패널이 연결 개념을 갖고 있는가 → (있음, 없음).

    ⚠ **글자로 센다** — `link_tab`·`link_picker` 를 부르는지 본다. 정확한 판정은
      아니지만 「어디에 없나」를 훑는 데는 충분하다(§0-5 오분류 주의).
    """
    here = os.path.dirname(os.path.abspath(__file__))
    if here not in sys.path:
        sys.path.insert(0, here)
    try:
        import admin_main
    except Exception as e:
        print('[db_link_map] admin_main: %s' % e)
        return [], []
    have, lack = [], []
    for key, spec in admin_main.PANEL_REGISTRY.items():
        path = os.path.join(here, spec[0].replace('.', os.sep) + '.py')
        try:
            src = io.open(path, encoding='utf-8').read()
        except Exception:
            src = ''
        hit = bool(re.search(r'link_tab|link_picker|sys_link_asset', src))
        (have if hit else lack).append(key)
    return sorted(have), sorted(lack)


# ── 보고 ───────────────────────────────────────────────────────────
def report():
    conn = appdb.connect()
    cs, cu = combos(conn, SYS_TBL), combos(conn, USER_TBL)
    print('연결 지도 — %s' % appdb.MAIN_DB)
    print('\n[1] 쓰이는 조합  sys %d종 %s행 · user %d종 %s행'
          % (len(cs), format(sum(cs.values()), ','),
             len(cu), format(sum(cu.values()), ',')))

    def show(name, cnt):
        print('\n  ── %s ──' % name)
        for lt, n in sorted(cnt.items(), key=lambda x: -x[1]):
            a, b = split(lt)
            print('    %-14s %7d   %s ↔ %s'
                  % (lt, n,
                     ASSETS.get(a, ('?', ''))[0],
                     ASSETS.get(b, ('?', ''))[0]))
    show('sys (배포)', cs)
    show('user (내 것)', cu)

    print('\n[2] ★ 같은 짝이 두 이름으로 사는 것')
    print('    판정 = **구별값(관점·안내문)이 있으면 방향, 없으면 중복**')
    bad = []
    for tbl, cnt, tag in ((SYS_TBL, cs, 'sys'), (USER_TBL, cu, 'user')):
        for lt, rev in reversed_pairs(cnt):
            same, only_a, only_b, directed, mism = same_pairs(conn, tbl, lt, rev)
            if same and directed:
                flag = '  ← 방향(정상)'
            elif same:
                flag = '  ⚠ 중복'
                bad.append((tag, lt, rev, same))
            else:
                flag = '  ← 겹침 없음 · 이름만 갈림'
            print('    [%s] %-12s ↔ %-12s  겹침 %d · %s만 %d · %s만 %d%s'
                  % (tag, lt, rev, same, lt, only_a, rev, only_b, flag))
            if mism:
                print('        ⚠⚠ 상태 어긋남 %d짝 — 한쪽 HIDE 인데 다른 이름이 '
                      'LIVE (숨겼는데 안 숨는다): %s' % (len(mism), mism))
    if not bad:
        print('    (중복 없음)')

    print('\n[3] 연결에서 빠진 자산')
    orp = orphan_assets(cs, cu)
    for k in orp:
        print('    %-6s %s' % (k, ASSETS[k][0]))
    if not orp:
        print('    (없음)')
    unk = unknown_codes(cs, cu)
    if unk:
        print('    ⚠ 이름을 모르는 코드(화면에 번호가 그대로 뜬다): %s'
              % ' '.join(unk))
    print('\n    연결 개념이 원래 없는 것:')
    for k, (nm, why) in NO_LINK.items():
        print('    %-6s %s — %s' % (k, nm, why))

    print('\n[4] 관리자 화면')
    have, lack = panels_with_link()
    print('    연결 개념 있음 %d개' % len(have))
    print('      %s' % ' '.join(have))
    print('    연결 개념 없음 %d개' % len(lack))
    print('      %s' % ' '.join(lack))
    conn.close()
    return bad


# ══════════════════════════════════════════════════════════════════
def selftest():
    ok = [0, 0]

    def t(label, cond, got=''):
        ok[1] += 1
        if cond:
            ok[0] += 1
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', label, got))

    t('split 이 넉 자 코드를 가른다', split('ENTI_UREF') == ('ENTI', 'UREF'))
    t('밑줄이 없으면 뒤가 빈다', split('TAG') == ('TAG', ''))
    # ★ 뒤집힌 짝 탐지 — 이 부품의 핵심
    t('★ A_B 와 B_A 를 잡는다',
      reversed_pairs({'A_B': 1, 'B_A': 1}) == [('A_B', 'B_A')])
    t('   한쪽만 있으면 안 잡는다', reversed_pairs({'A_B': 1}) == [])
    t('   자기 자신끼리는 안 잡는다(VERS_VERS)',
      reversed_pairs({'VERS_VERS': 9}) == [])
    t('   한 번만 낸다(중복 보고 없음)',
      len(reversed_pairs({'A_B': 1, 'B_A': 1, 'C_D': 1, 'D_C': 1})) == 2)
    # 빠진 자산 / 모르는 코드
    t('쓰이지 않는 자산을 찾는다', 'PLAN' in orphan_assets({'ENTI_VERS': 1}, {}))
    t('모르는 코드를 드러낸다', unknown_codes({'ZZZZ_VERS': 1}, {}) == ['ZZZZ'])
    t('아는 코드는 안 드러낸다', unknown_codes({'ENTI_VERS': 1}, {}) == [])
    # ★ 이름표가 `link_picker.CODE` 와 어긋나면 화면에 번호가 그대로 뜬다
    try:
        import link_picker as LP
        miss = sorted(set(LP.CODE.values()) - set(ASSETS))
        t('★ link_picker.CODE 의 코드를 다 안다', not miss, miss)
    except Exception as e:
        print('  [SKIP] link_picker (%s)' % e)
    # ★ 방향 ↔ 중복 판정 — 구별값이 가른다
    t('★ 구별값이 있으면 방향으로 본다', True)  # 아래 실 DB 검사가 잰다
    # 실 DB
    try:
        conn = appdb.connect()
        cs = combos(conn, SYS_TBL)
        cu = combos(conn, USER_TBL)
        t('실 DB sys 조합을 읽는다 (%d종)' % len(cs), len(cs) > 10)
        t('실 DB user 조합을 읽는다 (%d종)' % len(cu), len(cu) > 5)
        t('모르는 코드 0 (이름표가 최신이다)',
          unknown_codes(cs, cu) == [], unknown_codes(cs, cu))
        # ★ 탐지력 — 실제로 중복이 있는 것을 잡는가
        rp = reversed_pairs(cu)
        t('★ user 쪽 뒤집힌 짝을 실제로 잡는다 (%d쌍)' % len(rp), rp, rp)
        if rp:
            lt, rev = rp[0]
            s_, a_, b_, d_, m_ = same_pairs(conn, USER_TBL, lt, rev)
            t('   겹침을 셀 수 있다 (%s↔%s 겹침 %d)' % (lt, rev, s_),
              isinstance(s_, int))
        # ★ 탐지력 — sys 의 묵상경로(BOOK_CONT↔CONT_BOOK)는 **방향**이라야 한다
        if 'BOOK_CONT' in cs and 'CONT_BOOK' in cs:
            s_, _a, _b, d_, _m = same_pairs(conn, SYS_TBL, 'BOOK_CONT', 'CONT_BOOK')
            t('★ 묵상경로는 방향으로 판정한다(중복 아님)', d_ and s_)
        # ★ 그리고 구별값 없는 것은 중복으로 잡아야 한다
        if 'BUNT_UREF' in cu and 'UREF_BUNT' in cu:
            s_, _a, _b, d_, m_ = same_pairs(conn, USER_TBL, 'BUNT_UREF', 'UREF_BUNT')
            t('★ 구별값 없는 겹침은 중복으로 잡는다', s_ and not d_)
            t('   상태 어긋남도 잰다 (%d짝)' % len(m_), isinstance(m_, list))
        conn.close()
    except Exception as e:
        print('  [SKIP] 실 DB 검사 못 함 (%s)' % e)
    # 화면
    have, lack = panels_with_link()
    t('관리자 패널을 훑는다 (%d + %d)' % (len(have), len(lack)),
      len(have) + len(lack) >= 30)
    print('db_link_map selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    report()
