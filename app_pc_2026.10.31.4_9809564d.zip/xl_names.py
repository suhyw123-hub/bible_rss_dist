# -*- coding: utf-8 -*-
"""번역 금지 이름표 — 단체·매체·사역·브랜드 이름과 연재·조사·책·행사 제목을 제목 번역에서 지킨다
(2026-10-25 신설·영구 · `--selftest` 의무 · `--scan` 후보 모으기 · `--list`).

★ 사용자 지시 — 「고유명사들이기 때문에 원래는 번역하지 않는 것이 제일 좋다. 단체, 사역이름 등을 식별할 수 있다면
  번역표가 아니라 **번역금지표**를 만들어야겠다」 · 「원문이 영어가 아니라면 원어(영어), 원문이 영어라면 영어(번역어)」.

★★★ 합의한 원칙 — 「이름은 소리로, 제목은 뜻으로」
  · NAME(단체·매체·사역·브랜드) → 그 언어 글자로 소리 옮김 · TITLE(연재·조사·책·행사) → 뜻 옮김.
  · 영어 이름: 영어 독자는 이름만 · 다른 독자는 `English(번역어)`.
  · 영어 아닌 이름: 같은 언어 독자는 원어만 · 다른 독자는 `원어(영어)`.
  · 괄호 안이 이름과 같거나 비면 괄호를 뺀다.
  · 예외 1 — 공식·관행 현지 이름이 이긴다(Our Daily Bread(오늘의 양식) · Gemini(제미나이)) — 그 값을 forms 에 적는다.
  · 예외 2 — 같은 글자 독자에게 NAME 은 괄호 없이(독일 독자에게 Desiring God) · TITLE 은 그래도 뜻을 붙인다.
  · 사람 이름은 넣지 않는다(지금처럼 소리 옮김).
  · 제미나이가 갈래·형태를 제안하고 관리자가 확정한다 — **확정(OK)된 것만** 번역에 쓴다.

⚠ 표는 관리자 PC 의 번역 캐시(`admin_xl_cache.db`) 안에 둔다 — 배포 안 됨(번역 결과만 발행된다).
"""
import os
import re
import json
import sqlite3
from datetime import datetime

LANGS = ('KO', 'EN', 'ZH', 'ZHT', 'JA', 'DE', 'FR', 'ES', 'PT', 'RU', 'AR')
LANG_NAME = {'KO': 'Korean', 'EN': 'English', 'ZH': 'Simplified Chinese', 'ZHT': 'Traditional Chinese',
             'JA': 'Japanese', 'DE': 'German', 'FR': 'French', 'ES': 'Spanish', 'PT': 'Portuguese',
             'RU': 'Russian', 'AR': 'Arabic'}
KINDS = ('NAME', 'TITLE')
KIND_NAME = {'NAME': '이름(소리)', 'TITLE': '제목(뜻)'}
STATUS_NAME = {'CAND': '후보', 'OK': '확정', 'DROP': '버림'}

#: 그 언어가 쓰는 글자 — 같은 글자 독자에게 NAME 은 괄호 없이(예외 2)
SCRIPT_OF_LANG = {'EN': 'LATN', 'DE': 'LATN', 'FR': 'LATN', 'ES': 'LATN', 'PT': 'LATN',
                  'RU': 'CYRL', 'AR': 'ARAB', 'KO': 'HANG', 'JA': 'JPAN', 'ZH': 'HANS', 'ZHT': 'HANT'}

_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'admin_xl_cache.db')


def conn(path=None):
    return ensure(sqlite3.connect(path or _PATH))


def ensure(c):
    """번역 캐시 연결에 이름표를 마련한다(멱등) — cloud_translate 가 제 연결로 읽을 때도 쓴다."""
    c.execute("CREATE TABLE IF NOT EXISTS xl_name ("
              " name_id INTEGER PRIMARY KEY AUTOINCREMENT,"
              " name TEXT NOT NULL, src_lang TEXT NOT NULL,"
              " kind TEXT NOT NULL DEFAULT 'NAME', en TEXT, forms TEXT,"
              " status TEXT NOT NULL DEFAULT 'CAND', seen INTEGER DEFAULT 0,"
              " site TEXT, note TEXT, added_at TEXT, updated_at TEXT,"
              " UNIQUE(name, src_lang))")
    return c


def _now():
    return datetime.now().isoformat(timespec='seconds')


def script_of(text):
    """이름이 쓰인 글자 — 글자 하나라도 한글이면 HANG … 라틴만이면 LATN · 모르면 ''."""
    t = text or ''
    if re.search(r'[가-힣]', t):
        return 'HANG'
    if re.search(r'[぀-ヿ]', t):
        return 'JPAN'
    if re.search(r'[一-鿿]', t):
        return 'HAN'
    if re.search(r'[Ѐ-ӿ]', t):
        return 'CYRL'
    if re.search(r'[؀-ۿ]', t):
        return 'ARAB'
    if re.search(r'[A-Za-zÀ-ɏ]', t):
        return 'LATN'
    return ''


def _same_script(name, lang):
    s, ls = script_of(name), SCRIPT_OF_LANG.get(lang, '')
    if not s or not ls:
        return False
    if s == 'HAN':                      # 한자만 쓴 이름 — 중국어 두 갈래(일본어는 따로 본다)
        return ls in ('HANS', 'HANT')
    return s == ls


def _forms(row):
    f = row.get('forms')
    if isinstance(f, str):
        try:
            f = json.loads(f or '{}')
        except ValueError:
            f = {}
    return f or {}


def render(row, target):
    """그 언어 독자에게 보일 꼴 — 합의한 원칙 그대로(위 머리글)."""
    name = (row.get('name') or '').strip()
    src = (row.get('src_lang') or '').upper()
    kind = (row.get('kind') or 'NAME').upper()
    target = (target or '').upper()
    forms = _forms(row)
    en = (row.get('en') or '').strip()
    if target == src:
        return name
    if src == 'EN':
        if kind == 'NAME' and _same_script(name, target):
            return name
        inner = (forms.get(target) or '').strip()
    else:
        if kind == 'NAME' and _same_script(name, target):
            return name
        inner = en                      # 다른 독자 = 원어(영어) — 영어 독자도 같다
    if not inner or inner == name:
        return name
    return '%s(%s)' % (name, inner)


# ── 표 읽기·쓰기 ────────────────────────────────────────────────
def _row(r):
    keys = ('name_id', 'name', 'src_lang', 'kind', 'en', 'forms', 'status', 'seen', 'site', 'note',
            'added_at', 'updated_at')
    d = dict(zip(keys, r))
    d['forms'] = _forms(d)
    return d


_COLS = 'name_id, name, src_lang, kind, en, forms, status, seen, site, note, added_at, updated_at'


def all_rows(c, status=None):
    sql = 'SELECT %s FROM xl_name' % _COLS
    args = []
    if status:
        sql += ' WHERE status=?'
        args.append(status)
    sql += " ORDER BY CASE status WHEN 'CAND' THEN 0 WHEN 'OK' THEN 1 ELSE 2 END, seen DESC, name"
    return [_row(r) for r in c.execute(sql, args)]


def get(c, name_id):
    r = c.execute('SELECT %s FROM xl_name WHERE name_id=?' % _COLS, (name_id,)).fetchone()
    return _row(r) if r else None


def upsert_cand(c, name, src_lang, kind='NAME', en='', forms=None, site='', note=''):
    """후보를 넣는다 — 이미 있으면 **확정·버린 것은 안 건드리고** 후보면 비어 있는 칸만 채운다 → 새로 든 수(0/1)."""
    name = (name or '').strip()
    src_lang = (src_lang or '').upper()
    kind = kind if kind in KINDS else 'NAME'
    if not name or src_lang not in LANGS:
        return 0
    forms = {k: v for k, v in (forms or {}).items() if k in LANGS and (v or '').strip()}
    old = c.execute('SELECT name_id, status, en, forms, site FROM xl_name WHERE name=? AND src_lang=?',
                    (name, src_lang)).fetchone()
    if old:
        nid, st, oen, ofo, osite = old
        if st != 'CAND':
            return 0
        f = _forms({'forms': ofo})
        for k, v in forms.items():
            f.setdefault(k, v)
        c.execute('UPDATE xl_name SET en=?, forms=?, site=?, updated_at=? WHERE name_id=?',
                  (oen or en, json.dumps(f, ensure_ascii=False), osite or site, _now(), nid))
        return 0
    c.execute('INSERT INTO xl_name(name, src_lang, kind, en, forms, status, site, note, added_at, updated_at)'
              " VALUES(?,?,?,?,?,'CAND',?,?,?,?)",
              (name, src_lang, kind, en, json.dumps(forms, ensure_ascii=False), site, note, _now(), _now()))
    return 1


def save(c, name_id, kind=None, en=None, forms=None, status=None, note=None):
    """관리자가 고친 것을 적는다(바꾼 칸만)."""
    sets, args = [], []
    if kind in KINDS:
        sets.append('kind=?')
        args.append(kind)
    if en is not None:
        sets.append('en=?')
        args.append(en.strip())
    if forms is not None:
        sets.append('forms=?')
        args.append(json.dumps({k: v.strip() for k, v in forms.items() if k in LANGS and (v or '').strip()},
                               ensure_ascii=False))
    if status in STATUS_NAME:
        sets.append('status=?')
        args.append(status)
    if note is not None:
        sets.append('note=?')
        args.append(note)
    if not sets:
        return
    sets.append('updated_at=?')
    args += [_now(), name_id]
    c.execute('UPDATE xl_name SET %s WHERE name_id=?' % ', '.join(sets), args)


# ── 제목 안에서 찾기 ─────────────────────────────────────────────
def _pat(name):
    """라틴·키릴 이름은 낱말 경계로(「Gospel」이 「The Gospel Coalition」 안에서 안 걸리게 — 긴 이름이 먼저 잡힌다)."""
    e = re.escape(name)
    if script_of(name) in ('LATN', 'CYRL'):
        return re.compile(r'(?<![\w])' + e + r'(?![\w])')
    return re.compile(e)


def spans(rows, title):
    """그 제목에서 이름이 든 자리들 → [(시작, 끝, 행)] — 긴 이름 먼저 차지하고 겹치는 짧은 것은 그 자리만 뺀다."""
    t = title or ''
    taken = []
    for r in sorted(rows, key=lambda d: -len(d.get('name') or '')):
        for m in _pat(r['name']).finditer(t):
            a, b = m.span()
            if any(a < y and x < b for x, y, _r in taken):
                continue
            taken.append((a, b, r))
    return sorted(taken, key=lambda x: x[0])


def found(rows, title):
    """그 제목에 든 이름들(겹치지 않게 · 긴 것 먼저)."""
    out, seen = [], set()
    for _a, _b, r in sorted(spans(rows, title), key=lambda x: -len(x[2].get('name') or '')):
        k = id(r)
        if k not in seen:
            seen.add(k)
            out.append(r)
    return out


def confirmed(c=None):
    own = c is None
    c = c or conn()
    try:
        return all_rows(c, 'OK')
    finally:
        if own:
            c.close()


def count_seen(c):
    """이름마다 그 이름이 든 제목 수(대기열 전체) — 목록의 「제목 수」."""
    titles = [r[0] for r in c.execute('SELECT title FROM xl_q')]
    for r in all_rows(c):
        p = _pat(r['name'])
        n = sum(1 for t in titles if p.search(t))
        c.execute('UPDATE xl_name SET seen=? WHERE name_id=?', (n, r['name_id']))


# ── 번역에 쓴다 ─────────────────────────────────────────────────
def prompt_block(names, titles_langs):
    """제미나이 번역 묶음에 붙일 글 — 그 묶음 제목에 든 확정 이름만, 언어마다 정확한 꼴로."""
    used = {}
    for t, langs in titles_langs:
        for r in found(names, t):
            d = used.setdefault(r['name_id'], (r, set()))
            d[1].update(langs)
    if not used:
        return ''
    lines = ['Protected names — copy these EXACTLY as given for each target language '
             '(do not translate, re-spell or drop the parentheses):']
    for r, langs in used.values():
        forms = {lg: render(r, lg) for lg in LANGS if lg in langs}
        lines.append(json.dumps({'name': r['name'], 'write': forms}, ensure_ascii=False))
    return '\n'.join(lines) + '\n\n'


def protect_html(title, names, lang):
    """구글 번역용 — 이름을 그 언어 꼴로 바꾸고 `<span translate="no">` 로 감싼 HTML."""
    import html
    sp = [(a, b, render(r, lang)) for a, b, r in spans(names, title)]
    if not sp:
        return None
    out, pos = [], 0
    for a, b, rep in sp:
        out.append(html.escape(title[pos:a]))
        out.append('<span translate="no">%s</span>' % html.escape(rep))
        pos = b
    out.append(html.escape(title[pos:]))
    return ''.join(out)


def unprotect_html(text):
    import html
    t = re.sub(r'</?span[^>]*>', '', text or '')
    return html.unescape(t).strip()


def check_out(names, title, lang, out):
    """번역 결과에 확정 이름이 제 꼴로 있나 → 빠진 이름 꼴들(빈 목록이면 됨)."""
    miss = []
    for r in found(names, title):
        want = render(r, lang)
        if want and want not in (out or ''):
            miss.append(want)
    return miss


# ── 다시 번역 ───────────────────────────────────────────────────
def affected(c, names=None):
    """확정 이름이 든 제목들 → [(id, h)]."""
    names = names if names is not None else all_rows(c, 'OK')
    if not names:
        return []
    out = []
    for i, h, t in c.execute('SELECT id, h, title FROM xl_q ORDER BY id'):
        if found(names, t):
            out.append((i, h))
    return out


def retranslate_prepare(c, names=None, set_last=None):
    """확정 이름이 든 제목의 번역을 지우고 「끝낸 번호」를 그 앞으로 — [번역하기]가 다시 옮긴다 → 지운 제목 수.
    ⚠ 원문 언어 칸은 없으므로 지울 것이 없다 · 다른 제목은 그대로(캐시가 있어 돈을 다시 안 쓴다)."""
    hits = affected(c, names)
    if not hits:
        return 0
    for _i, h in hits:
        c.execute('DELETE FROM xl WHERE h=?', (h,))
    c.commit()
    low = min(i for i, _h in hits) - 1
    if set_last is None:
        import cloud_translate as CT
        if low < CT.last_done():
            CT._set_last_done(low)
    else:
        set_last(low)
    return len(hits)


# ── 후보 모으기(제미나이) ─────────────────────────────────────────
_FORM_RULE = (
    '  "en": the official English name it uses itself (for an English name repeat it; for a TITLE the English title),\n'
    '  "forms": an object with EVERY language code above → for NAME: the name sounded out in that '
    'language\'s script, BUT use an established official/customary local name when one exists '
    '(e.g. Our Daily Bread → KO "오늘의 양식", Hillsong → KO "힐송"); for TITLE: the translated title.\n')


def _scan_prompt(sites, titles):
    """후보 찾기 글 — 사이트 이름 묶음과 제목 묶음은 따로 보낸다(함께 보내면 사이트를 건너뛰었다 · 2026-10-25 실측)."""
    langs = ', '.join('%s=%s' % (k, LANG_NAME[k]) for k in LANGS)
    if sites:
        return (
            'Below are the names of Christian news/devotional WEBSITES as written in their RSS feeds (%s).\n'
            'For EACH site give its clean proper name (strip feed noise such as "» Feed", " - 전체기사", '
            '"Top News", "Articles", "Blog feed"; skip a line that is no name at all, e.g. "home-/-all-rss").\n'
            'Fields: "site" (the line as given), "name" (clean name exactly as the site writes it), '
            '"lang" (language code of that name), "kind": "NAME",\n' % langs
            + _FORM_RULE +
            'Answer with ONE JSON array only. No notes.\n\n'
            + '\n'.join(json.dumps({'site': s, 'lang': lg}, ensure_ascii=False) for s, lg in sites))
    return (
        'You help build a do-not-translate list for Christian news and devotional headlines (%s).\n'
        'Read the HEADLINES below and pick out only proper names that appear INSIDE them:\n'
        '  kind "NAME" = an organization, media outlet, ministry, church, school, publisher, company or brand;\n'
        '  kind "TITLE" = the title of a named series, column, survey, report, book, film, album, podcast or event.\n'
        'NEVER return a headline itself or a sentence — only the name (usually 1-6 words) exactly as written '
        'inside the headline. Do NOT list people\'s names, Bible books or verses, countries/cities/regions, '
        'God/Jesus, or ordinary words. Most headlines contain no such name — skip them.\n'
        'Fields: "name", "lang" (language code of the name), "kind",\n' % langs
        + _FORM_RULE +
        'Answer with ONE JSON array only: [{"name":…,"lang":…,"kind":…,"en":…,"forms":{…}}, …]. No notes.\n\n'
        + '\n'.join(json.dumps({'headline': t, 'lang': lg}, ensure_ascii=False) for t, lg in titles))


def plausible(name, titles):
    """제미나이가 낸 것이 이름다운가 — 기사 제목을 통째로 낸 것 · 문장 · 어디에도 없는 것을 거른다."""
    n = (name or '').strip()
    if not n or len(n) > 60 or len(n.split()) > 8:
        return False
    if re.search(r'[?!…]|\.\.\.|[.。]$', n):
        return False
    if any(t.strip() == n for t in titles):
        return False
    return any(_pat(n).search(t) for t in titles) if titles else True


def _parse_array(text):
    t = (text or '').strip()
    a, b = t.find('['), t.rfind(']')
    if a < 0 or b < a:
        return []
    try:
        v = json.loads(t[a:b + 1])
        return v if isinstance(v, list) else []
    except ValueError:
        out = []
        for m in re.finditer(r'\{[^{}]*"forms"\s*:\s*\{[^{}]*\}[^{}]*\}', t[a:b + 1]):
            try:
                out.append(json.loads(m.group(0)))
            except ValueError:
                continue
        return out


def site_list(master_path=None):
    """등록 사이트 이름(살아 있는 것) → [(이름, 언어)]."""
    p = master_path or os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bible_master.db')
    try:
        m = sqlite3.connect(p)
        rows = m.execute("SELECT DISTINCT site_name, UPPER(lang_code) FROM sys_rss_feed"
                         " WHERE COALESCE(record_status,'LIVE')='LIVE' AND COALESCE(enabled,1)=1"
                         " AND COALESCE(site_name,'')<>''").fetchall()
        m.close()
        return [(s, lg) for s, lg in rows if lg in LANGS]
    except sqlite3.Error:
        return []


def scan(call=None, c=None, chunk=160, progress=None, sites=None, titles=None):
    """대기열 제목 + 등록 사이트 이름을 제미나이에게 보여 후보를 모은다 → {'new': n, 'calls': k, 'errors': [...]}."""
    own = c is None
    c = c or conn()
    if call is None:
        import ai_client as AC
        call = lambda p: AC.call(p, temperature=0, max_out=65536, timeout=300)   # noqa: E731
    sites = site_list() if sites is None else sites
    if titles is None:
        titles = [(t, lg) for t, lg in c.execute('SELECT title, lang FROM xl_q ORDER BY id')]
    all_t = [t for t, _lg in titles]
    out = {'new': 0, 'calls': 0, 'dropped': 0, 'errors': []}
    jobs = ([('S', sites)] if sites else []) + [('T', titles[a:a + chunk]) for a in range(0, len(titles), chunk)]
    try:
        for k, (kind, g) in enumerate(jobs):
            if progress:
                progress('후보 찾는 중… (%d/%d)' % (k + 1, len(jobs)))
            res = call(_scan_prompt(g if kind == 'S' else [], g if kind == 'T' else []))
            out['calls'] += 1
            if not res.get('ok'):
                out['errors'].append(res.get('why') or '답 없음')
                continue
            for d in _parse_array(res.get('text')):
                if not isinstance(d, dict):
                    continue
                nm = (d.get('name') or '').strip()
                if kind == 'T' and not plausible(nm, all_t):      # 기사 제목 통째·문장·어디에도 없는 것
                    out['dropped'] += 1
                    continue
                f = d.get('forms') if isinstance(d.get('forms'), dict) else {}
                kd = 'NAME' if kind == 'S' else (d.get('kind') or 'NAME').upper()
                out['new'] += upsert_cand(c, nm, d.get('lang'), kd, (d.get('en') or '').strip(), f,
                                          site=(d.get('site') or '') if kind == 'S' else '')
            c.commit()
        count_seen(c)
        c.commit()
        return out
    finally:
        if own:
            c.close()


# ── 자가 검증 ───────────────────────────────────────────────────
def selftest():
    import tempfile
    ok = [0, 0]

    def ck(m, cond):
        ok[0 if cond else 1] += 1
        print(('  PASS ' if cond else '  FAIL ') + m)

    odb = {'name': 'Our Daily Bread', 'src_lang': 'EN', 'kind': 'NAME', 'en': 'Our Daily Bread',
           'forms': {'KO': '오늘의 양식', 'JA': 'デイリーブレッド', 'DE': 'Our Daily Bread'}}
    ck('영어 이름 · 영어 독자 = 이름만', render(odb, 'EN') == 'Our Daily Bread')
    ck('영어 이름 · 한국 독자 = 이름(현지 이름)', render(odb, 'KO') == 'Our Daily Bread(오늘의 양식)')
    ck('영어 이름 · 같은 글자(독일) = 괄호 없이', render(odb, 'DE') == 'Our Daily Bread')
    nj = {'name': '뉴스앤조이', 'src_lang': 'KO', 'kind': 'NAME', 'en': 'Newsnjoy', 'forms': {}}
    ck('한국어 이름 · 한국 독자 = 원어만', render(nj, 'KO') == '뉴스앤조이')
    ck('한국어 이름 · 영어 독자 = 원어(영어)', render(nj, 'EN') == '뉴스앤조이(Newsnjoy)')
    ck('한국어 이름 · 일본 독자 = 원어(영어)', render(nj, 'JA') == '뉴스앤조이(Newsnjoy)')
    srv = {'name': 'State of Theology', 'src_lang': 'EN', 'kind': 'TITLE', 'en': 'State of Theology',
           'forms': {'DE': 'Stand der Theologie', 'KO': '신학 현황'}}
    ck('영어 제목 · 같은 글자(독일)라도 뜻을 붙인다', render(srv, 'DE') == 'State of Theology(Stand der Theologie)')
    ck('꼴이 비면 괄호를 뺀다', render(srv, 'FR') == 'State of Theology')
    lc = {'name': '靈命日糧', 'src_lang': 'ZHT', 'kind': 'NAME', 'en': 'Our Daily Bread', 'forms': {}}
    ck('한자 이름 · 간체 독자 = 같은 글자라 원어만', render(lc, 'ZH') == '靈命日糧')
    ck('한자 이름 · 한국 독자 = 원어(영어)', render(lc, 'KO') == '靈命日糧(Our Daily Bread)')
    gc = {'name_id': 2, 'name': 'Gospel', 'src_lang': 'EN', 'kind': 'NAME', 'en': '', 'forms': {}}
    tgc = {'name_id': 1, 'name': 'The Gospel Coalition', 'src_lang': 'EN', 'kind': 'NAME', 'en': '',
           'forms': {'KO': '복음연합'}}
    h = found([gc, tgc], 'The Gospel Coalition says Gospel matters')
    ck('긴 이름 먼저 · 겹친 짧은 것은 그 자리에서 빠진다', [r['name_id'] for r in h] == [1, 2])
    ck('낱말 경계 — Gospels 안의 Gospel 은 안 잡힌다', not found([gc], 'Four Gospels'))
    pb = prompt_block([tgc], [('The Gospel Coalition at 20', ['KO', 'EN'])])
    ck('번역 묶음에 든 이름만 · 언어마다 꼴', '복음연합' in pb and 'The Gospel Coalition(복음연합)' in pb)
    ck('이름이 없으면 덧붙이지 않는다', prompt_block([tgc], [('Grace', ['KO'])]) == '')
    ph = protect_html('Join The Gospel Coalition & friends', [tgc], 'KO')
    ck('구글용 — 이름을 꼴로 바꿔 번역 금지 표시', '<span translate="no">The Gospel Coalition(복음연합)</span>' in ph
       and '&amp;' in ph)
    ck('구글 답에서 표시를 걷는다', unprotect_html('<span translate="no">A(복)</span> &amp; b') == 'A(복) & b')
    ck('번역 결과 점검 — 빠진 꼴을 말한다', check_out([tgc], 'The Gospel Coalition', 'KO', '복음 연합') ==
       ['The Gospel Coalition(복음연합)'])
    p = os.path.join(tempfile.mkdtemp(), 'n.db')
    c = conn(p)
    c.execute("CREATE TABLE xl_q (id INTEGER PRIMARY KEY, h TEXT, title TEXT, lang TEXT, added_at TEXT, kind TEXT)")
    c.execute("CREATE TABLE xl (h TEXT, lang TEXT, dst TEXT, src TEXT, PRIMARY KEY(h, lang))")
    c.executemany('INSERT INTO xl_q(id,h,title,lang) VALUES(?,?,?,?)',
                  [(1, 'a', 'Grace today', 'EN'), (2, 'b', 'Desiring God on prayer', 'EN'), (3, 'c', '은혜', 'KO')])
    c.executemany('INSERT INTO xl VALUES(?,?,?,?)', [('a', 'KO', '오늘의 은혜', 'G'), ('b', 'KO', '하나님을 갈망', 'G')])

    def fake(prompt):
        if 'WEBSITES' in prompt:
            return {'ok': True, 'text': '[{"site":"Desiring God » Feed","name":"Desiring God","lang":"EN",'
                                        '"kind":"NAME","en":"Desiring God","forms":{"KO":"디자이어링 갓"}}]'}
        return {'ok': True, 'text': '```json\n[{"name":"Desiring God on prayer","lang":"EN","kind":"TITLE","forms":{}},'
                                    '{"name":"Nowhere Org","lang":"EN","kind":"NAME","forms":{}}]\n```'}
    r = scan(call=fake, c=c, sites=[('Desiring God » Feed', 'EN')])
    ck('후보 모으기 — 사이트 이름을 후보로 · 제목 수를 센다', r['new'] == 1 and all_rows(c)[0]['seen'] == 1
       and all_rows(c)[0]['site'] == 'Desiring God » Feed')
    ck('기사 제목 통째 · 어디에도 없는 이름은 거른다', r['dropped'] == 2)
    ck('같은 후보는 두 번 안 든다', scan(call=fake, c=c, sites=[])['new'] == 0)
    nid = all_rows(c)[0]['name_id']
    save(c, nid, status='OK', forms={'KO': '디자이어링 갓', 'JA': ''})
    ck('확정 · 빈 꼴은 버린다', get(c, nid)['status'] == 'OK' and get(c, nid)['forms'] == {'KO': '디자이어링 갓'})
    ck('확정 뒤에는 후보 모으기가 덮지 않는다',
       upsert_cand(c, 'Desiring God', 'EN', forms={'JA': 'x'}) == 0 and 'JA' not in get(c, nid)['forms'])
    got = []
    n = retranslate_prepare(c, set_last=got.append)
    ck('다시 번역 — 그 이름이 든 제목만 번역을 지우고 번호를 그 앞으로',
       n == 1 and got == [1] and c.execute("SELECT COUNT(*) FROM xl WHERE h='b'").fetchone()[0] == 0
       and c.execute("SELECT COUNT(*) FROM xl WHERE h='a'").fetchone()[0] == 1)
    c.close()
    print('xl_names selftest %d/%d' % (ok[0], sum(ok)))
    return ok[1] == 0


def _cli():
    import sys
    sys.stdout.reconfigure(encoding='utf-8')
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    if '--scan' in a:
        r = scan(progress=print)
        print(r)
        return
    c = conn()
    for r in all_rows(c):
        print('%-4s %-5s %-3s %3d  %s | %s | %s' % (STATUS_NAME[r['status']], r['kind'], r['src_lang'], r['seen'],
                                                    r['name'], r['en'], json.dumps(r['forms'], ensure_ascii=False)))
    c.close()


if __name__ == '__main__':
    _cli()
