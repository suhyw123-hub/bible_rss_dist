# -*- coding: utf-8 -*-
"""용어사전 덮개 **종합 화면** — 「내수정」 창 (2026-08-26 신설).

★ 사용자 확정: 「E 버튼: 용어사전에 관한 사용자 덮개 모델의 **종합화면**으로
  만들어라. **별명 / 설명문 / 영상링크 / 텍스트링크 / 연구자료 / 연결구절**
  관리기능을 포괄하라. 유형분류 수정기능도 추가하라. **탭 화면**으로 만들어라.
  상단에 **큼직하게 용어 이름**을 표시해라. 무엇이 기준인지 명확해야 한다.
  구절연결은 **1구절, 구절구간 모두** 가능해야 한다. **구절연결설명문**도 수정할
  수 있어야 한다.」

★ 권한(사용자 확정) — 설명·연결구절·링크·연구자료·별명·유형 = **고칠 수 있다** /
  **이름은 못 고친다**(별명으로 받는다) / 사전·여정 = 손댈 수 없다.

⚠⚠ **배포 DB(`sys_*`)를 한 글자도 안 건드린다.** 전부 `userdb` 쪽으로 간다
  (§0-6 C-2). 어느 줄이 내 것인지는 **N/E/H 표식**(`overlay_mark`)이 말한다.

`--selftest` 의무(데이터 층).
"""
import sys
import tkinter as tk
from tkinter import ttk, messagebox

import appdb
import i18n
import link_picker as LP
import overlay
import overlay_mark as OM

# 연결구절 — 통합 표의 갈래
EV = 'ENTI_VERS'
THEMATIC = 'THEMATIC'
EV_DESC = 'ENTITY_VERSE_DESC'


def _C(role, fallback):
    from entity_browser import _C as f
    return f(role, fallback)


def _tfr(w, db, scope='prose', delta=0):
    from entity_browser import _tfr as f
    return f(w, db, scope, delta)


def _TYPE_KO_get():
    from entity_browser import _TYPE_KO
    return _TYPE_KO



# ══════════════════════════════════════════════════════════════════
#  데이터 층 — 화면이 부르는 문
# ══════════════════════════════════════════════════════════════════
def entity_head(conn, entity_id, lang='KO'):
    """상단에 큼직하게 놓을 것 — (이름, code, 유형)."""
    r = conn.execute('SELECT entity_code, entity_type FROM sys_entity_master '
                     'WHERE entity_id=?', (entity_id,)).fetchone()
    if not r:
        return ('', '', '')
    nm = conn.execute(
        "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME' "
        "AND clicked_id=? AND lang_code IN (?,'EN','KO') AND record_status='LIVE' "
        "ORDER BY CASE lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
        (entity_id, (lang or 'KO').upper(), (lang or 'KO').upper())).fetchone()
    return ((nm[0] if nm else r[0]), r[0], r[1])


# ── 유형분류 덮개 ───────────────────────────────────────────────────
def type_override(conn, entity_code):
    """사용자가 고친 유형(없으면 None). `user_entity_asset` 한 행에 산다."""
    try:
        r = conn.execute(
            'SELECT entity_type FROM userdb.user_entity_asset '
            "WHERE entity_code=? AND COALESCE(record_status,'LIVE')<>'HIDE'",
            (entity_code,)).fetchone()
    except Exception:
        return None
    return r[0] if r and r[0] else None


def save_type(conn, entity_code, entity_type):
    """유형분류를 고친다 — 사용자 지시 「유형분류 오류가 있을 수도 있으니」.

    ⚠ **가림·별명과 같은 행**을 쓴다. `record_status` 와 `json_detail` 을
      건드리지 않는다 — 유형을 고쳤다고 가림이 풀리면 안 된다.
    ⚠ 빈 값이면 **되돌린다**(칸을 비운다) — 「기본으로」가 없으면 한 번 고치고
      영영 못 돌아온다.
    """
    row = conn.execute('SELECT 1 FROM userdb.user_entity_asset WHERE entity_code=?',
                       (entity_code,)).fetchone()
    v = (entity_type or '').strip() or None
    if row:
        conn.execute('UPDATE userdb.user_entity_asset SET entity_type=? '
                     'WHERE entity_code=?', (v, entity_code))
    else:
        conn.execute('INSERT INTO userdb.user_entity_asset '
                     '(entity_code, entity_type, record_status) VALUES (?,?,?)',
                     (entity_code, v, 'LIVE'))
    conn.commit()


# ── 사전 연결 (REFU_ENTI · 자료집 = DICTIONARY) ─────────────────────
#  0.txt 1번 「사전 연결 탭이 없음」 — 사용자 결정 **「연결하기」**.
#  ⚠ 사전 **본문은 못 고친다**(남의 저작 — 8-26 확정 「사전은 손댈 수 없다」).
#    할 수 있는 것은 **어느 사전 항목을 이 용어에 잇는가**뿐이다.
DICT_SRC_CODES = ('EASTON_DICT', 'SMITH_DICT', 'MEYER_BC')


def dict_links(conn, entity_id, lang='KO'):
    """이 용어에 걸린 사전 항목 — sys + 내 것, 표식 포함.

    돌려주는 것: `[{src, mark, unit_id, src_code, label, is_user}]`
    (src = SYS · NEW · HIDE — 관리 목록이라 가린 것도 H 로 낸다)
    """
    out, seen = [], set()
    ph = ','.join('?' * len(DICT_SRC_CODES))
    mine, hidden = {}, set()
    try:
        for uid, st in conn.execute(
                "SELECT clicked_id, COALESCE(record_status,'LIVE') "
                "FROM userdb.user_link_asset "
                "WHERE link_type='REFU_ENTI' AND target_id=?", (entity_id,)):
            if (st or 'LIVE') == 'HIDE':
                hidden.add(uid)
            else:
                mine[uid] = True
    except Exception as e:
        print('[entity_overlay] dict_links(user): %s' % e)
    try:
        for uid, code, label in conn.execute(
                "SELECT u.ref_unit_id, s.src_code, u.unit_label "
                "  FROM sys_link_asset el "
                "  JOIN sys_ref_unit u ON u.ref_unit_id=el.clicked_id "
                "  JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id "
                " WHERE el.link_type='REFU_ENTI' AND el.target_id=? "
                "   AND COALESCE(el.record_status,'LIVE')='LIVE' "
                "   AND COALESCE(u.record_status,'LIVE')='LIVE' "
                "   AND s.src_code IN (%s) "
                " ORDER BY s.ref_src_id, u.sequence" % ph,
                (entity_id,) + DICT_SRC_CODES):
            seen.add(uid)
            out.append(dict(src=('HIDE' if uid in hidden else 'SYS'),
                            unit_id=uid, src_code=code, label=label or '',
                            is_user=False))
    except Exception as e:
        print('[entity_overlay] dict_links(sys): %s' % e)
    # ⚠ **내가 잇고 가린 것도 낸다** — 이 목록은 관리 화면이라 H 로 남아야
    #   [되돌리기]를 누를 수 있다(읽는 화면이면 뺐다). 2026-08-27 selftest
    #   가 이 자리를 잡았다.
    for uid in list(mine) + [u for u in hidden if u not in seen]:
        if uid in seen:
            continue
        try:
            r = conn.execute(
                "SELECT s.src_code, u.unit_label FROM sys_ref_unit u "
                "  JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id "
                " WHERE u.ref_unit_id=?", (uid,)).fetchone()
        except Exception:
            r = None
        if not r:
            continue
        out.append(dict(src=('HIDE' if uid in hidden else 'NEW'),
                        unit_id=uid, src_code=r[0],
                        label=r[1] or '', is_user=True))
    for d in out:
        d['mark'] = OM.mark_of(d['src'])
    return out


def add_dict_link(conn, entity_id, unit_id):
    """사전 항목을 이 용어에 잇는다 — 멱등(가려 뒀으면 되살림)."""
    r = conn.execute(
        "SELECT user_link_id, COALESCE(record_status,'LIVE') "
        "FROM userdb.user_link_asset WHERE link_type='REFU_ENTI' "
        "AND clicked_id=? AND target_id=?", (unit_id, entity_id)).fetchone()
    if r:
        if r[1] == 'HIDE':
            conn.execute("UPDATE userdb.user_link_asset SET "
                         "record_status='LIVE' WHERE user_link_id=?", (r[0],))
            conn.commit()
            return 'REVIVED'
        return 'DUP'
    conn.execute("INSERT INTO userdb.user_link_asset(link_type, clicked_id, "
                 "target_id, record_status) VALUES('REFU_ENTI', ?, ?, 'LIVE')",
                 (unit_id, entity_id))
    conn.commit()
    return 'NEW'


def hide_dict_link(conn, entity_id, unit_id, hide=True):
    """사전 연결 가리기/되돌리기 — sys 연결은 덮개 행으로 가린다."""
    r = conn.execute(
        "SELECT user_link_id FROM userdb.user_link_asset "
        "WHERE link_type='REFU_ENTI' AND clicked_id=? AND target_id=?",
        (unit_id, entity_id)).fetchone()
    st = 'HIDE' if hide else 'LIVE'
    if r:
        conn.execute("UPDATE userdb.user_link_asset SET record_status=? "
                     "WHERE user_link_id=?", (st, r[0]))
    else:
        conn.execute("INSERT INTO userdb.user_link_asset(link_type, "
                     "clicked_id, target_id, record_status) "
                     "VALUES('REFU_ENTI', ?, ?, ?)", (unit_id, entity_id, st))
    conn.commit()


# ── 용어 자체 가리기 (2026-08-27 사용자 지시) ────────────────────────
def entity_hidden(conn, entity_code):
    """이 용어를 내 화면에서 가렸나."""
    try:
        r = conn.execute(
            "SELECT record_status FROM userdb.user_entity_asset "
            'WHERE entity_code=?', (entity_code,)).fetchone()
    except Exception:
        return False
    return bool(r and (r[0] or 'LIVE') == 'HIDE')


def set_entity_hidden(conn, entity_code, hide=True):
    """용어 가리기/되돌리기 — **별명·유형과 같은 행**의 record_status 만
    만진다(그 칸들을 지우지 않는다 — 되돌리면 별명이 그대로 살아 있어야).

    ⚠ 가림은 목록·검색·태그에서 함께 빠진다(`db_tag_system.
      user_hidden_entity_codes` 를 여러 화면이 읽는다) — 그래서 이 한 행이
      곧 「내 화면에서 이 용어를 안 본다」는 뜻이다.
    """
    row = conn.execute('SELECT 1 FROM userdb.user_entity_asset '
                       'WHERE entity_code=?', (entity_code,)).fetchone()
    st = 'HIDE' if hide else 'LIVE'
    if row:
        conn.execute('UPDATE userdb.user_entity_asset SET record_status=? '
                     'WHERE entity_code=?', (st, entity_code))
    else:
        conn.execute('INSERT INTO userdb.user_entity_asset '
                     '(entity_code, record_status) VALUES (?,?)',
                     (entity_code, st))
    conn.commit()


# ── 연결구절 (ENTI_VERS · THEMATIC) ─────────────────────────────────
def _vid_of(conn, bcode, chapter, verse):
    r = conn.execute('SELECT verse_id FROM bible_index WHERE bcode=? '
                     'AND chapter=? AND verse=?', (bcode, chapter, verse)).fetchone()
    return r[0] if r else None


def verse_links(conn, entity_id, lang='KO'):
    """연결구절 목록 — sys + 내 것을 **한 목록**으로. 각 줄에 N/E/H 표식.

    돌려주는 것: `[{src, mark, vid, end_vid, ref, note, is_user}]`
    ⚠ 가린 sys 줄은 **여기서 뺀다**(읽는 목록이 아니라 관리 목록이므로 H 로 남긴다).
    """
    lg = (lang or 'KO').upper()
    # ★ **짝(vid, end_vid)으로 합친다.** sys 짝이 있으면 내 행은 「고침(E)」이고
    #   없으면 「더함(N)」이다 — 이 구별을 안 하면 고친 줄이 새 줄로 보이고
    #   목록에 **같은 구절이 두 번** 뜬다.
    mine = {}
    try:
        for r in conn.execute(
                "SELECT target_id, COALESCE(end_id, target_id), "
                "COALESCE(record_status,'LIVE') "
                "FROM userdb.user_link_asset WHERE link_type=? AND clicked_id=? "
                "AND COALESCE(rel_code,?)=?", (EV, entity_id, THEMATIC, THEMATIC)):
            mine[(r[0], r[1])] = dict(status=r[2], note='')
    except Exception as e:
        print('[entity_overlay] verse_links(user): %s' % e)
    # ★★ 연결설명문은 **통합 텍스트 자산 표**에 산다(사용자 지시 「링크자산,
    #   텍스트자산 통합 테이블에 저장하는 것 잊지 마라」). 링크의 `note` 칸이
    #   아니다 — sys 도 `sys_text_asset('ENTITY_VERSE_DESC')` 를 쓴다.
    #   ⚠ 쓰는 곳과 읽는 곳이 다른 표를 보면 **저장은 되는데 안 보인다**
    #     (2026-08-27 연구자료에서 그 사고가 실제로 났다).
    try:
        for k, body in conn.execute(
                'SELECT origin_key, contents FROM userdb.user_text_asset '
                "WHERE text_type=? AND origin_key LIKE ? "
                "AND COALESCE(record_status,'LIVE')='LIVE'",
                (EV_DESC, '%s|%%' % EV_DESC)):
            try:
                _tt, _code, _rng, _lg = k.split('|')
                if _lg != lg:
                    continue
                _a, _b = (int(x) for x in _rng.split('-'))
            except Exception:
                continue
            if (_a, _b) in mine:
                mine[(_a, _b)]['note'] = body or ''
            else:
                mine[(_a, _b)] = dict(status='LIVE', note=body or '')
    except Exception as e:
        print('[entity_overlay] verse_links(note): %s' % e)

    out, seen = [], set()
    try:
        for r in conn.execute(
                "SELECT ev.target_id, COALESCE(ev.end_id, ev.target_id), "
                "  (SELECT ta.contents FROM sys_text_asset ta "
                "   WHERE ta.text_type=? AND ta.clicked_id=ev.sys_link_id "
                "   AND ta.lang_code IN (?,'EN','KO') AND ta.record_status='LIVE' "
                "   ORDER BY CASE ta.lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1 "
                "            ELSE 2 END LIMIT 1) "
                "FROM sys_link_asset ev WHERE ev.link_type=? AND ev.clicked_id=? "
                "AND ev.rel_code=? AND COALESCE(ev.record_status,'LIVE')='LIVE'",
                (EV_DESC, lg, lg, EV, entity_id, THEMATIC)):
            key = (r[0], r[1])
            seen.add(key)
            u = mine.get(key)
            if u is None:
                src, note = 'SYS', (r[2] or '')
            elif u['status'] == 'HIDE':
                src, note = 'HIDE', (r[2] or '')
            else:
                src, note = 'EDIT', (u['note'] or r[2] or '')
            out.append(dict(src=src, vid=key[0], end_vid=key[1], note=note,
                            is_user=False))
    except Exception as e:
        print('[entity_overlay] verse_links(sys): %s' % e)

    for key, u in mine.items():
        if key in seen:
            continue                      # sys 짝이 있는 것은 위에서 이미 냈다
        out.append(dict(src='HIDE' if u['status'] == 'HIDE' else 'NEW',
                        vid=key[0], end_vid=key[1], note=u['note'],
                        is_user=True))
    for d in out:
        d['mark'] = OM.mark_of(d['src'])
        d['ref'] = verse_label(conn, d['vid'], d['end_vid'], lg)
    out.sort(key=lambda d: (d['vid'], d['end_vid']))
    return out


def verse_label(conn, vid, end_vid=None, lang='KO'):
    """`창1:1` / 구간이면 `창1:1~2:3`."""
    r = conn.execute(
        'SELECT bn.short_name, bi.chapter, bi.verse FROM bible_index bi '
        'LEFT JOIN book_names bn ON bn.book_code=bi.bcode AND bn.lang_code=? '
        'WHERE bi.verse_id=?', ((lang or 'KO').upper(), vid)).fetchone()
    if not r:
        return '#%s' % vid
    lab = '%s%d:%d' % (r[0] or '', r[1], r[2])
    if end_vid and end_vid != vid:
        r2 = conn.execute('SELECT chapter, verse FROM bible_index '
                          'WHERE verse_id=?', (end_vid,)).fetchone()
        if r2:
            lab += '~%d' % r2[1] if r2[0] == r[1] else '~%d:%d' % (r2[0], r2[1])
    return lab


def add_verse_link(conn, entity_id, vid, end_vid=None, note=''):
    """연결구절 추가 — **1구절도 구간도** 된다(사용자 확정).

    ⚠ 같은 짝이 이미 있으면 안 넣는다 — 목록에 같은 줄이 두 번 뜬다.
    ⚠ 중복등록 차단(§13-50)은 **단락 연결과의 겹침**을 본다 — 그것은
      `db_term_load.linked_peri_spans` 가 단일 소스다.
    """
    end_vid = end_vid or vid
    if end_vid < vid:
        vid, end_vid = end_vid, vid
    dup = conn.execute(
        'SELECT 1 FROM userdb.user_link_asset WHERE link_type=? AND clicked_id=? '
        'AND target_id=? AND COALESCE(end_id,target_id)=?',
        (EV, entity_id, vid, end_vid)).fetchone()
    if dup:
        return False
    conn.execute(
        'INSERT INTO userdb.user_link_asset '
        '(link_type, clicked_id, target_id, end_id, rel_code, note, record_status) '
        'VALUES (?,?,?,?,?,?,?)',
        (EV, entity_id, vid, end_vid, THEMATIC, note or None, 'LIVE'))
    conn.commit()
    return True


def note_key(conn, entity_id, vid, end_vid, lang='KO'):
    """연결설명문의 **자연 열쇠** — `ENTITY_VERSE_DESC|P_DAVID|1-3|KO`.

    ⚠ sys 는 이 글을 링크 **PK**(`ev_id`)에 매단다 — PK 는 배포마다 바뀌므로
      사용자 쪽은 못 쓴다. `entity_code` + 절 범위 + 언어로 짓는다.
    """
    r = conn.execute('SELECT entity_code FROM sys_entity_master WHERE entity_id=?',
                     (entity_id,)).fetchone()
    return '%s|%s|%s-%s|%s' % (EV_DESC, (r[0] if r else entity_id), vid,
                               end_vid or vid, (lang or 'KO').upper())


def save_verse_note(conn, entity_id, vid, end_vid, note, is_user, lang='KO'):
    """연결설명문 수정 — 사용자 지시 「구절연결설명문도 수정할 수 있어야 한다」.

    ★★ **통합 텍스트 자산 표에 쓴다** (`userdb.user_text_asset`) — 사용자 지시
      「링크자산, 텍스트자산 **통합 테이블**에 저장하는 것 잊지 마라」.
      ⚠ 처음에는 링크 행의 `note` 칸에 적었는데, sys 는 같은 글을
        `sys_text_asset('ENTITY_VERSE_DESC')` 에 둔다 — **두 층이 다른 자리에
        살면 화면이 한쪽만 읽는다**(방금 연구자료에서 그 사고가 났다).
    ⚠ 열쇠는 **자연 열쇠**(`note_key`) — 링크 PK 는 배포마다 바뀐다.
    ⚠ **sys 연결의 설명문을 고쳐도 배포 DB 는 안 건드린다** — 내 행만 생긴다.
      그 짝이 sys 에 있으면 화면이 그것을 `E`(고침)로 읽는다.
    """
    end_vid = end_vid or vid
    okey = note_key(conn, entity_id, vid, end_vid, lang)
    body = (note or '').strip() or None
    row = conn.execute('SELECT user_text_id FROM userdb.user_text_asset '
                       'WHERE origin_key=?', (okey,)).fetchone()
    if row:
        if body is None:
            conn.execute('DELETE FROM userdb.user_text_asset WHERE user_text_id=?',
                         (row[0],))
        else:
            conn.execute('UPDATE userdb.user_text_asset SET contents=?, '
                         "record_status='LIVE' WHERE user_text_id=?",
                         (body, row[0]))
    elif body is not None:
        conn.execute(
            'INSERT INTO userdb.user_text_asset '
            '(text_type, clicked_id, contents, lang_code, origin_key, '
            ' record_status) VALUES (?,?,?,?,?,?)',
            (EV_DESC, vid, body, (lang or 'KO').upper(), okey, 'LIVE'))
    # 내 연결이 아직 없으면 만들어 둔다 — sys 짝을 고친 것이면 그 행이 `E` 표식이다
    if not is_user:
        has = conn.execute(
            'SELECT 1 FROM userdb.user_link_asset WHERE link_type=? '
            'AND clicked_id=? AND target_id=? AND COALESCE(end_id,target_id)=?',
            (EV, entity_id, vid, end_vid)).fetchone()
        if not has and body is not None:
            conn.execute(
                'INSERT INTO userdb.user_link_asset '
                '(link_type, clicked_id, target_id, end_id, rel_code, record_status)'
                ' VALUES (?,?,?,?,?,?)',
                (EV, entity_id, vid, end_vid, THEMATIC, 'EDIT'))
    conn.commit()


def hide_verse_link(conn, entity_id, vid, end_vid, hide=True):
    """sys 연결 가리기 / 내 연결 지우기 — 둘 다 되돌릴 수 있다."""
    end_vid = end_vid or vid
    row = conn.execute(
        'SELECT user_link_id, record_status FROM userdb.user_link_asset '
        'WHERE link_type=? AND clicked_id=? AND target_id=? '
        'AND COALESCE(end_id,target_id)=?',
        (EV, entity_id, vid, end_vid)).fetchone()
    if hide:
        if row:
            conn.execute('UPDATE userdb.user_link_asset SET record_status=? '
                         'WHERE user_link_id=?', ('HIDE', row[0]))
        else:
            conn.execute(
                'INSERT INTO userdb.user_link_asset '
                '(link_type, clicked_id, target_id, end_id, rel_code, record_status) '
                'VALUES (?,?,?,?,?,?)',
                (EV, entity_id, vid, end_vid, THEMATIC, 'HIDE'))
    elif row:
        # sys 를 가린 것이면 물리 삭제(=기본 부활) · 내 것이면 되살린다
        has_sys = conn.execute(
            'SELECT 1 FROM sys_link_asset WHERE link_type=? AND clicked_id=? '
            'AND target_id=? AND COALESCE(end_id,target_id)=?',
            (EV, entity_id, vid, end_vid)).fetchone()
        if has_sys:
            conn.execute('DELETE FROM userdb.user_link_asset WHERE user_link_id=?',
                         (row[0],))
        else:
            conn.execute('UPDATE userdb.user_link_asset SET record_status=? '
                         'WHERE user_link_id=?', ('LIVE', row[0]))
    conn.commit()


# ── 링크(영상·텍스트) ───────────────────────────────────────────────
def media_links(conn, entity_id, kind='VIDEO', lang='KO'):
    """그 용어의 링크 — sys + 내 것. `kind` = 'VIDEO' | 'TEXT'.

    ★ 조회의 정본은 **`overlay_read.media`** 다(C 단계 이관 — 링크 탭과 이
    창이 같은 문을 읽어야 「저장은 되는데 안 보인다」가 안 난다). 여기서는
    표식만 얹는다.
    ⚠ 위키(WIKI%)는 정본이 뺀다 — 사전 탭으로 일원화(§95차)라 이 창의
      링크 탭에도 안 보이는 것이 맞다.
    """
    import overlay_read
    out = overlay_read.media(conn, entity_id, kind, lang)
    for d in out:
        d['mark'] = OM.mark_of(d['src'])
    return out


def add_media(conn, entity_id, title, url, lang='KO'):
    """내가 만난 링크를 이 용어에 붙인다(0.txt 2번 — 서핑하다 만난 것)."""
    url = (url or '').strip()
    if not url:
        return False
    dup = conn.execute(
        'SELECT um.user_media_id FROM userdb.user_media_asset um '
        'JOIN userdb.user_link_asset ul ON ul.clicked_id=um.user_media_id '
        "WHERE ul.link_type='MEDI_ENTI' AND ul.target_id=? AND um.url=?",
        (int(entity_id), url)).fetchone()
    if dup:
        return False
    # ★ 같은 주소의 내 영상이 이미 있으면 그 줄에 연결만(2026-10-09 · 1.txt 58)
    ex = conn.execute('SELECT user_media_id FROM userdb.user_media_asset WHERE url=?'
                      ' ORDER BY user_media_id', (url,)).fetchone()
    if ex:
        conn.execute("UPDATE userdb.user_media_asset SET record_status='LIVE'"
                     ' WHERE user_media_id=?', (ex[0],))
        conn.execute(
            'INSERT INTO userdb.user_link_asset '
            "(link_type, clicked_id, target_id, record_status) VALUES ('MEDI_ENTI',?,?,?)",
            (ex[0], int(entity_id), 'LIVE'))
        conn.commit()
        return True
    # ⚠⚠ `user_media_asset.verse_id` 는 **NOT NULL** 이다 — 그 표는 원래
    #   「이 구절에 붙인 영상」용이라 구절 앵커를 강제한다. 용어 링크의 앵커는
    #   **`user_link_asset(MEDI_ENTI)`** 가 들고 있으므로 여기서는 쓰지 않는다.
    #   ⇒ **0 = 구절 앵커 없음**(`bible_index` 는 1부터라 부딪히지 않는다).
    #     가짜 절 번호를 넣지 않는다 — 넣으면 엉뚱한 구절에 영상이 붙는다.
    cur = conn.execute(
        'INSERT INTO userdb.user_media_asset '
        '(verse_id, category, title, url, lang_code, record_status) '
        'VALUES (?,?,?,?,?,?)',
        (0, 'ENTITY', (title or url)[:200], url,
         (lang or 'KO').upper(), 'LIVE'))
    conn.execute(
        'INSERT INTO userdb.user_link_asset '
        "(link_type, clicked_id, target_id, record_status) VALUES ('MEDI_ENTI',?,?,?)",
        (cur.lastrowid, int(entity_id), 'LIVE'))
    conn.commit()
    return True


def hide_media(conn, mid, is_user, hide=True):
    if is_user:
        conn.execute('UPDATE userdb.user_media_asset SET record_status=? '
                     'WHERE user_media_id=?', ('HIDE' if hide else 'LIVE', mid))
    elif hide:
        conn.execute('INSERT OR IGNORE INTO userdb.user_media_hide(media_id) '
                     'VALUES (?)', (mid,))
    else:
        conn.execute('DELETE FROM userdb.user_media_hide WHERE media_id=?', (mid,))
    conn.commit()


# ══════════════════════════════════════════════════════════════════
def selftest():
    import sqlite3
    ok = [0, 0]

    def t(label, cond, got=''):
        ok[1] += 1
        if cond:
            ok[0] += 1
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', label, got))

    db = sqlite3.connect(':memory:')
    db.execute("ATTACH ':memory:' AS userdb")
    db.execute('CREATE TABLE sys_entity_master (entity_id INTEGER PRIMARY KEY, '
               'entity_code TEXT, entity_type TEXT, record_status TEXT)')
    db.execute("INSERT INTO sys_entity_master VALUES (7,'P_X','PERSON','LIVE')")
    db.execute('CREATE TABLE sys_text_asset (sys_text_id INTEGER PRIMARY KEY, '
               'text_type TEXT, clicked_id INT, contents TEXT, lang_code TEXT, '
               'record_status TEXT)')
    db.execute('CREATE TABLE bible_index (verse_id INTEGER PRIMARY KEY, '
               'bcode TEXT, chapter INT, verse INT)')
    for i, (b, c, v) in enumerate([('GEN', 1, 1), ('GEN', 1, 2), ('GEN', 1, 3)], 1):
        db.execute('INSERT INTO bible_index VALUES (?,?,?,?)', (i, b, c, v))
    db.execute('CREATE TABLE book_names (book_code TEXT, lang_code TEXT, '
               'short_name TEXT)')
    db.execute("INSERT INTO book_names VALUES ('GEN','KO','창')")
    db.execute('CREATE TABLE sys_link_asset (sys_link_id INTEGER PRIMARY KEY, '
               'link_type TEXT, clicked_id INT, target_id INT, end_id INT, '
               'rel_code TEXT, record_status TEXT)')
    db.execute('CREATE TABLE userdb.user_link_asset (user_link_id INTEGER '
               'PRIMARY KEY, link_type TEXT, clicked_id INT, target_id INT, '
               'end_id INT, rel_code TEXT, note TEXT, origin_id INT, '
               'record_status TEXT)')
    db.execute('CREATE TABLE userdb.user_entity_asset (entity_code TEXT PRIMARY KEY,'
               ' entity_type TEXT, json_detail TEXT, record_status TEXT)')
    # ★ 연결설명문이 사는 **통합 텍스트 자산 표**(링크의 note 칸이 아니다)
    db.execute('CREATE TABLE userdb.user_text_asset (user_text_id INTEGER '
               'PRIMARY KEY, text_type TEXT, clicked_id INT, contents TEXT, '
               'lang_code TEXT, origin_key TEXT, record_status TEXT)')
    db.commit()

    # ① 유형분류 덮개
    t('처음엔 유형 덮개 없음', type_override(db, 'P_X') is None)
    save_type(db, 'P_X', 'GROUP')
    t('★ 유형을 고칠 수 있다', type_override(db, 'P_X') == 'GROUP')
    save_type(db, 'P_X', '')
    t('   비우면 기본으로 되돌아온다', type_override(db, 'P_X') is None)
    # ⚠ 가림과 같은 행을 쓰므로 서로를 안 건드려야 한다
    db.execute("UPDATE userdb.user_entity_asset SET record_status='HIDE'")
    save_type(db, 'P_X', 'IDOL')
    st = db.execute('SELECT record_status FROM userdb.user_entity_asset '
                    "WHERE entity_code='P_X'").fetchone()[0]
    t('★ 유형을 고쳐도 가림이 안 풀린다', st == 'HIDE', st)
    db.execute("UPDATE userdb.user_entity_asset SET record_status='LIVE', "
               'entity_type=NULL')
    db.commit()

    # ② 연결구절 — 1구절과 구간
    db.execute("INSERT INTO sys_link_asset (link_type, clicked_id, target_id, "
               "rel_code, record_status) VALUES ('ENTI_VERS',7,1,'THEMATIC','LIVE')")
    db.commit()
    r = verse_links(db, 7)
    t('sys 연결이 보이고 표식이 없다',
      len(r) == 1 and r[0]['mark'] == '' and r[0]['ref'] == '창1:1', r)
    t('★ 1구절 추가', add_verse_link(db, 7, 2))
    t('★ 구간 추가', add_verse_link(db, 7, 2, 3))
    t('   같은 짝은 두 번 안 들어간다', not add_verse_link(db, 7, 2))
    r = verse_links(db, 7)
    t('내가 더한 줄은 N', sorted(d['mark'] for d in r) == ['', OM.NEW, OM.NEW],
      [d['mark'] for d in r])
    rng = [d for d in r if d['end_vid'] != d['vid']]
    t('★ 구간이 범위로 보인다', rng and rng[0]['ref'] == '창1:2~3',
      rng[0]['ref'] if rng else '')

    # ③ 연결설명문 — sys 줄을 고치면 EDIT
    save_verse_note(db, 7, 1, 1, '내가 쓴 연결설명', is_user=False)
    # ★★ **통합 텍스트 자산 표에 들어갔는가** (사용자 지시). 링크의 note 칸이
    #    아니다 — 두 층이 다른 자리에 살면 화면이 한쪽만 읽는다.
    _tk = db.execute('SELECT origin_key, contents FROM userdb.user_text_asset '
                     'WHERE text_type=?', (EV_DESC,)).fetchone()
    t('★★ 연결설명문이 통합 텍스트 표에 들어간다', _tk is not None, _tk)
    t('   열쇠가 자연 열쇠(code 포함)', _tk and _tk[0].split('|')[1] == 'P_X', _tk)
    r = {(d['vid'], d['end_vid']): d for d in verse_links(db, 7)}
    t('★ sys 연결의 설명문을 고치면 E', r[(1, 1)]['mark'] == OM.EDIT,
      r[(1, 1)]['mark'])
    t('   배포 DB 는 안 바뀐다',
      db.execute("SELECT COUNT(*) FROM sys_text_asset").fetchone()[0] == 0)
    save_verse_note(db, 7, 2, 2, '내 연결의 설명', is_user=True)
    r = {(d['vid'], d['end_vid']): d for d in verse_links(db, 7)}
    t('   내 연결의 설명문도 저장된다', r[(2, 2)]['note'] == '내 연결의 설명')

    # ④ 가리기 / 되돌리기
    hide_verse_link(db, 7, 1, 1, True)
    r = {(d['vid'], d['end_vid']): d for d in verse_links(db, 7)}
    t('★ sys 연결을 가리면 H', r[(1, 1)]['mark'] == OM.HIDE, r[(1, 1)]['mark'])
    hide_verse_link(db, 7, 1, 1, False)
    r = {(d['vid'], d['end_vid']): d for d in verse_links(db, 7)}
    # ⚠ 가림만 풀린다 — **내가 쓴 설명문은 그대로**이므로 표식은 `E` 다.
    #   여기서 `''` 를 기대하면 「가림 해제」가 「내 글까지 지움」이 된다.
    t('   가림을 풀면 E 로 돌아온다 (내 설명문은 남는다)',
      r[(1, 1)]['mark'] == OM.EDIT and r[(1, 1)]['note'] == '내가 쓴 연결설명',
      r[(1, 1)]['mark'])
    hide_verse_link(db, 7, 2, 2, True)
    r = {(d['vid'], d['end_vid']): d for d in verse_links(db, 7)}
    t('   내 연결을 가려도 H', r[(2, 2)]['mark'] == OM.HIDE)
    hide_verse_link(db, 7, 2, 2, False)
    r = {(d['vid'], d['end_vid']): d for d in verse_links(db, 7)}
    t('   되살리면 다시 N', r[(2, 2)]['mark'] == OM.NEW)

    # ⑤ 머리글
    db.execute("INSERT INTO sys_text_asset (text_type, clicked_id, contents, "
               "lang_code, record_status) VALUES ('ENTITY_NAME',7,'엑스','KO','LIVE')")
    db.commit()
    t('머리글 = (이름, code, 유형)', entity_head(db, 7) == ('엑스', 'P_X', 'PERSON'),
      entity_head(db, 7))

    db.close()
    # ── 사전 연결 왕복 (0.txt 1번 · 2026-08-27) ──
    try:
        c3 = appdb.connect()
        eid3 = c3.execute("SELECT entity_id FROM sys_entity_master "
                          "WHERE record_status='LIVE' LIMIT 1").fetchone()[0]
        # ⚠ **아직 안 걸린 항목**을 골라야 왕복이 성립한다(이미 걸린 것을
        #   고르면 시험 블록이 통째로 건너뛴다 — 실제로 그렇게 조용히 넘어갔다).
        uid3 = c3.execute(
            "SELECT u.ref_unit_id FROM sys_ref_unit u "
            "  JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id "
            " WHERE s.src_code='EASTON_DICT' "
            "   AND u.ref_unit_id NOT IN (SELECT clicked_id FROM "
            "       userdb.user_link_asset WHERE link_type='REFU_ENTI') "
            " LIMIT 1").fetchone()[0]
        n_b = len(dict_links(c3, eid3))
        had3 = c3.execute("SELECT 1 FROM userdb.user_link_asset WHERE "
                          "link_type='REFU_ENTI' AND clicked_id=? AND "
                          "target_id=?", (uid3, eid3)).fetchone()
        if not had3:
            t('★ 사전 잇기 = NEW',
              add_dict_link(c3, eid3, uid3) == 'NEW')
            rows3 = dict_links(c3, eid3)
            mine3 = [d for d in rows3 if d['unit_id'] == uid3]
            t('   목록에 N 으로 나온다',
              len(rows3) == n_b + 1 and mine3 and mine3[0]['src'] == 'NEW')
            t('   같은 것 다시 = DUP',
              add_dict_link(c3, eid3, uid3) == 'DUP')
            hide_dict_link(c3, eid3, uid3, True)
            t('★ 가리면 H', [d for d in dict_links(c3, eid3)
                            if d['unit_id'] == uid3][0]['src'] == 'HIDE')
            hide_dict_link(c3, eid3, uid3, False)
            t('   되돌리면 N', [d for d in dict_links(c3, eid3)
                              if d['unit_id'] == uid3][0]['src'] == 'NEW')
            c3.execute("DELETE FROM userdb.user_link_asset WHERE "
                       "link_type='REFU_ENTI' AND clicked_id=? AND target_id=?",
                       (uid3, eid3))
            c3.commit()
            t('   잔재 0', len(dict_links(c3, eid3)) == n_b)
        c3.close()
    except Exception as e:
        t('사전 연결 왕복', False, e)

    # ── 용어 가리기 왕복 (2026-08-27) ──
    try:
        conn2 = appdb.connect()
        code0 = conn2.execute("SELECT entity_code FROM sys_entity_master "
                              "WHERE record_status='LIVE' LIMIT 1").fetchone()[0]
        had = bool(conn2.execute('SELECT 1 FROM userdb.user_entity_asset '
                                 'WHERE entity_code=?', (code0,)).fetchone())
        was = entity_hidden(conn2, code0)
        if not was:
            set_entity_hidden(conn2, code0, True)
            t('★ 용어 가리기', entity_hidden(conn2, code0))
            import db_tag_system as _T
            t('   목록·검색에서 빠지는 집합에 들어간다',
              code0 in _T.user_hidden_entity_codes(conn2))
            set_entity_hidden(conn2, code0, False)
            t('   가림 풀기', not entity_hidden(conn2, code0))
            if not had:                       # 시험이 만든 행은 지운다
                conn2.execute('DELETE FROM userdb.user_entity_asset '
                              'WHERE entity_code=? AND entity_type IS NULL '
                              'AND json_detail IS NULL', (code0,))
                conn2.commit()
        conn2.close()
    except Exception as e:
        t('용어 가리기 왕복', False, e)

    print('entity_overlay selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)


# ══════════════════════════════════════════════════════════════════
#  창 — 탭 일곱 (2026-08-26 사용자 확정 구성)
# ══════════════════════════════════════════════════════════════════
def open_win(host, entity_id):
    """host = EntityBrowserPanel. 이미 열려 있으면 들어 올린다."""
    import tkinter as tk
    w = getattr(host, '_my_win', None)
    try:
        if w is not None and w.winfo_exists():
            w.load(entity_id)
            w.lift()
            w.focus_force()
            return w
    except Exception:
        pass
    w = _MyWin(host, entity_id)
    host._my_win = w
    return w


class MyBody(ttk.Frame):
    """「MY」 몸통 — 탭 일곱. 상단에 **큼직하게 용어 이름**(무엇이 기준인지).

    ★ 2026-08-27 (13-53 조각 ②) — 창(Toplevel)에서 몸통을 **Frame 으로
    떼어냈다**. 작업대를 팝업에서 뗀 것(`build_workbench`)과 같은 수술 —
    같은 몸통을 MY 창(`_MyWin` 래퍼)과 총괄 창(내 수정)의 용어 앵커가 심는다.
    호스트 결합은 콜백 셋으로만: `lang_getter`(표시 언어) ·
    `on_changed(eid)`(저장 뒤 호스트 갱신) · `on_ref_open(row|None)`(연구자료
    열기 — 없는 호스트에서는 조용히 무시).
    """

    # ⚠ 유형분류 탭은 뺐다 (2026-08-27 사용자 — 「유형분류 수정하는 기능을
    #   제거하자. 실수로 입력한 경우 가리기/지우기를 해야 하는데 없다」.
    #   95차의 「분류값 덮개는 보류」 결정과도 한 결 — 걸리는 범위(트리·개수·
    #   지도)가 너무 넓다). 데이터 층(save_type/type_override)은 남긴다 —
    #   overlay_read.entity 가 읽고, 되살릴 때 화면만 다시 달면 된다.
    #   제거 시점 실측 — 실사용 유형 덮개 0건(발 묶인 데이터 없음).
    TABS = (('ALIAS', 'EBM_T_ALIAS', '별명'),
            ('DESC', 'EBM_T_DESC', '설명문'),
            ('VERSE', 'EBM_T_VERSE', '연결구절'),
            ('DICT', 'EBM_T_DICT', '사전'),
            ('VIDEO', 'EB_BR_VIDEO', '영상링크'),
            ('TEXT', 'EB_BR_TEXT', '텍스트링크'),
            ('REF', 'EBM_T_REF', '연구자료'))

    def __init__(self, parent, db_path, lang_getter, on_changed=None,
                 on_ref_open=None, title_setter=None):
        super().__init__(parent)
        self.db = db_path
        self._lang_getter = lang_getter
        self._on_changed = on_changed
        self._on_ref_open = on_ref_open
        self._title_setter = title_setter
        self.eid = None

        # ── 상단 — 큼직한 이름 + 무엇이 기준인지 ──────────────────
        head = tk.Frame(self)
        head.pack(fill='x', padx=12, pady=(10, 2))
        self._name_lbl = tk.Label(head, text='', anchor='w',
                                  font=('', 18, 'bold'))
        self._name_lbl.pack(side='left')
        self._sub_lbl = tk.Label(head, text='', anchor='w')
        self._sub_lbl.pack(side='left', padx=(10, 0), pady=(8, 0))
        # 범례 — 표식만 있고 뜻을 안 알려 주면 「이 N 이 뭐지」가 된다
        self._leg = tk.Label(self, anchor='w')
        self._leg.pack(fill='x', padx=12)

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill='both', expand=True, padx=10, pady=(4, 10))
        self._panes = {}
        for key, k18, dflt in self.TABS:
            f = ttk.Frame(self.nb)
            self.nb.add(f, text=' %s ' % i18n.t(k18, dflt))
            self._panes[key] = f
        self._build_alias(self._panes['ALIAS'])
        self._build_desc(self._panes['DESC'])
        self._build_verse(self._panes['VERSE'])
        self._build_dict(self._panes['DICT'])
        self._build_media(self._panes['VIDEO'], 'VIDEO')
        self._build_media(self._panes['TEXT'], 'TEXT')
        self._build_ref(self._panes['REF'])

    # ── 공통 ────────────────────────────────────────────────────
    def _lang(self):
        try:
            return self._lang_getter() or 'KO'
        except Exception:
            return 'KO'

    def _bar(self, parent):
        b = tk.Frame(parent)
        b.pack(fill='x', padx=8, pady=(8, 4))
        return b

    def _btn(self, bar, key, dflt, cmd):
        b = tk.Button(bar, text=i18n.t(key, dflt), bd=1, padx=8, pady=2,
                      cursor='hand2', command=cmd)
        b.pack(side='left', padx=(0, 6))
        return b

    def _tree(self, parent, cols, widths):
        f = tk.Frame(parent)
        f.pack(fill='both', expand=True, padx=8, pady=(0, 6))
        sb = ttk.Scrollbar(f)
        sb.pack(side='right', fill='y')
        tv = ttk.Treeview(f, columns=cols, show='headings',
                          yscrollcommand=sb.set, selectmode='browse')
        for c, w in zip(cols, widths):
            tv.column(c, width=w, anchor='w')
        sb.config(command=tv.yview)
        tv.pack(fill='both', expand=True)
        return tv

    def _done(self, reload_host=True):
        self.load(self.eid)
        if reload_host and callable(self._on_changed):
            try:
                self._on_changed(self.eid)
            except Exception as e:
                print('[MY] on_changed: %s' % e)

    def load(self, entity_id):
        self.eid = entity_id
        with appdb.connect(self.db) as conn:
            name, code, etype = entity_head(conn, entity_id, self._lang())
        self.code, self.etype = code, etype
        self._name_lbl.config(text=name or code)
        self._sub_lbl.config(
            text=i18n.t('EBM_SUB', '기준 용어 · {code}').format(code=code),
            fg=_C('fg_dim', '#7F8C8D'))
        self._leg.config(text=OM.legend(), fg=_C('fg_dim', '#7F8C8D'))
        if callable(self._title_setter):
            self._title_setter(name or code)
        self._fill_alias()
        self._sync_hide_btn()
        self._fill_desc()
        self._fill_verse()
        self._fill_dict()
        self._fill_media('VIDEO')
        self._fill_media('TEXT')
        self._fill_ref()

    # ── ① 별명 ──────────────────────────────────────────────────
    def _build_alias(self, p):
        bar = self._bar(p)
        self._btn(bar, 'COMMON_SAVE', '저장', self._save_alias)
        # ★ 용어 자체 가리기 (2026-08-27 사용자 — 「용어 자체를 가리는 기능은
        #   없는 것 같다」). 목록·검색·태그에서 함께 빠진다. 되돌리기는 같은
        #   단추(상태에 따라 글자가 바뀐다) — 「가린 것을 어디서 푸나」가
        #   안 생긴다.
        self._hide_btn = self._btn(bar, 'EB_OV_HIDE_ENT', '용어 숨기기',
                                   self._toggle_hide_entity)
        self._hide_lbl = tk.Label(bar, text='', anchor='w')
        self._hide_lbl.pack(side='left', padx=(8, 0))
        tk.Label(p, anchor='w', justify='left', wraplength=760,
                 text=i18n.t('EB_OV_ALIAS_HINT',
                             '이름 자체는 바꾸지 않습니다 — 바꾸면 그 이름을 쓰는 '
                             '태그·연결·검색이 모두 어긋납니다. 쉼표로 나눠 적으세요.')
                 ).pack(fill='x', padx=10)
        self._al_sys = tk.Label(p, anchor='w')
        self._al_sys.pack(fill='x', padx=10, pady=(2, 0))
        self._al_var = tk.StringVar()
        tk.Entry(p, textvariable=self._al_var).pack(fill='x', padx=10, pady=8)

    def _fill_alias(self):
        from entity_aliases import aliases_for_lang, format_csv
        lg = self._lang()
        with appdb.connect(self.db) as conn:
            mine = overlay.entity_aliases_user(conn, lg).get(self.code, [])
            jd = conn.execute('SELECT json_detail FROM sys_entity_master '
                              'WHERE entity_id=?', (self.eid,)).fetchone()
        self._al_var.set(format_csv(mine))
        sysal = aliases_for_lang(jd[0] if jd else None, lg)
        self._al_sys.config(
            text=(i18n.t('EB_OV_ALIAS_SYS', '기본 별명: ') + ', '.join(sysal))
            if sysal else '', fg=_C('fg_dim', '#7F8C8D'))

    def _sync_hide_btn(self):
        """가림 상태 → 단추 글자·안내 (별명 탭 상단)."""
        if not getattr(self, '_hide_btn', None) or not self.code:
            return
        with appdb.connect(self.db) as conn:
            hid = entity_hidden(conn, self.code)
        self._hide_btn.config(text=i18n.t(
            'EB_OV_SHOW_ENT', '다시 보이기') if hid else i18n.t(
            'EB_OV_HIDE_ENT', '용어 숨기기'))
        self._hide_lbl.config(
            text=(i18n.t('EB_OV_HIDDEN_NOW',
                         '지금 이 용어는 내 화면에서 가려져 있습니다.')
                  if hid else ''),
            fg=_C('danger', '#C0392B') if hid else _C('fg_dim', '#7F8C8D'))

    def _toggle_hide_entity(self):
        if not self.code:
            return
        with appdb.connect(self.db) as conn:
            hid = entity_hidden(conn, self.code)
            if not hid and not messagebox.askyesno(
                    i18n.t('EB_OV_HIDE_ENT', '용어 숨기기'),
                    i18n.t('EB_OV_HIDE_ENT_Q',
                           '이 용어를 내 화면에서 가립니다 — 목록·검색·태그에서 '
                           '빠집니다. 언제든 여기서 되돌릴 수 있습니다. '
                           '계속할까요?'), parent=self):
                return
            set_entity_hidden(conn, self.code, not hid)
        self._sync_hide_btn()
        self._done()

    def _save_alias(self):
        from entity_aliases import parse_csv
        with appdb.connect(self.db) as conn:
            overlay.save_entity_aliases(conn, self.code, self._lang(),
                                        parse_csv(self._al_var.get()))
        self._done()

    # ── ② 설명문 ────────────────────────────────────────────────
    def _build_desc(self, p):
        bar = self._bar(p)
        self._btn(bar, 'COMMON_SAVE', '저장', self._save_desc)
        self._btn(bar, 'EB_OV_HIDE_DESC', '숨기기', self._hide_desc)
        self._btn(bar, 'EB_OV_REVERT', '기본으로 되돌리기', self._revert_desc)
        self._ds_lbl = tk.Label(p, anchor='w')
        self._ds_lbl.pack(fill='x', padx=10)
        f = tk.Frame(p)
        f.pack(fill='both', expand=True, padx=10, pady=(2, 8))
        sb = ttk.Scrollbar(f)
        sb.pack(side='right', fill='y')
        self._ds_txt = tk.Text(f, wrap='word', yscrollcommand=sb.set)
        sb.config(command=self._ds_txt.yview)
        self._ds_txt.pack(fill='both', expand=True)
        _tfr(self._ds_txt, self.db, 'prose')

    def _fill_desc(self):
        import overlay_edit
        with appdb.connect(self.db) as conn:
            _v, st, body = overlay_edit.target_state(
                conn, 'ENTITY_DESC', self.eid, self._lang(), '')
        mk = {'EDIT': OM.EDIT, 'NEW': OM.NEW, 'HIDDEN': OM.HIDE}.get(st, '')
        self._ds_lbl.config(
            text='%s %s' % (mk or ' ',
                            OM.describe(mk) if mk
                            else i18n.t('EB_OV_ST_SYS', '기본 설명입니다')),
            fg=OM.color(mk) or _C('fg_dim', '#7F8C8D'))
        self._ds_txt.delete('1.0', 'end')
        self._ds_txt.insert('1.0', body or '')

    def _save_desc(self):
        import overlay_edit
        v = self._ds_txt.get('1.0', 'end').strip()
        if not v:
            messagebox.showinfo('MY', i18n.t('EB_OV_EMPTY',
                                             '빈 글은 저장하지 않습니다. '
                                             '숨기려면 [숨기기]를 쓰세요.'),
                                parent=self)
            return
        with appdb.connect(self.db) as conn:
            overlay_edit.save_mine(conn, 'ENTITY_DESC', self.eid,
                                   self._lang(), '', v)
        self._done()

    def _hide_desc(self):
        import overlay_edit
        with appdb.connect(self.db) as conn:
            overlay_edit.hide_sys(conn, 'ENTITY_DESC', self.eid, self._lang(), '')
        self._done()

    def _revert_desc(self):
        import overlay_edit
        with appdb.connect(self.db) as conn:
            overlay_edit.revert_mine(conn, 'ENTITY_DESC', self.eid,
                                     self._lang(), '')
        self._done()

    def _build_verse(self, p):
        bar = self._bar(p)
        self._btn(bar, 'EBM_V_ADD', '구절 추가', self._add_verse)
        self._btn(bar, 'COMMON_SAVE', '설명문 저장', self._save_vnote)
        self._btn(bar, 'EBM_V_HIDE', '숨기기', lambda: self._hide_verse(True))
        self._btn(bar, 'EBM_V_SHOW', '되돌리기', lambda: self._hide_verse(False))
        self._vs_tv = self._tree(p, ('mk', 'ref', 'note'), (40, 130, 480))
        for c, k, d in (('mk', 'EBM_C_MARK', '표시'), ('ref', 'EBM_C_REF', '구절'),
                        ('note', 'EBM_C_NOTE', '연결설명문')):
            self._vs_tv.heading(c, text=i18n.t(k, d))
        self._vs_tv.bind('<<TreeviewSelect>>', lambda _e: self._on_vsel())
        tk.Label(p, anchor='w', text=i18n.t('EBM_V_NOTE', '연결설명문')
                 ).pack(fill='x', padx=8)
        self._vn_txt = tk.Text(p, wrap='word', height=5)
        self._vn_txt.pack(fill='x', padx=8, pady=(0, 8))
        _tfr(self._vn_txt, self.db, 'prose')

    def _fill_verse(self):
        tv = self._vs_tv
        tv.delete(*tv.get_children())
        OM.configure_tree(tv)
        self._vs_rows = {}
        with appdb.connect(self.db) as conn:
            rows = verse_links(conn, self.eid, self._lang())
        for d in rows:
            iid = tv.insert('', 'end',
                            values=(d['mark'], d['ref'],
                                    (d['note'] or '').replace('\n', ' ')[:120]),
                            tags=((OM.tag_name(d['mark']),) if d['mark'] else ()))
            self._vs_rows[iid] = d
        self._vn_txt.delete('1.0', 'end')

    def _cur_verse(self):
        s = self._vs_tv.selection()
        return self._vs_rows.get(s[0]) if s else None

    def _on_vsel(self):
        d = self._cur_verse()
        self._vn_txt.delete('1.0', 'end')
        if d:
            self._vn_txt.insert('1.0', d['note'] or '')

    def _add_verse(self):
        dlg = _VersePick(self, self.db, self._lang())
        self.wait_window(dlg)
        if not getattr(dlg, 'result', None):
            return
        sv, ev = dlg.result
        with appdb.connect(self.db) as conn:
            # ⚠ 중복등록 차단 — 단락 연결 구간과 겹치면 막는다(§13-50 단일 소스)
            try:
                import db_term_load as T
                hit = T._span_hit(T.linked_peri_spans(conn, self.eid), sv)
            except Exception:
                hit = None
            if hit:
                messagebox.showwarning(
                    'MY', i18n.t('EBM_V_DUP',
                                 '이 구절은 이미 단락으로 이어져 있습니다 ({p}). '
                                 '한 목록에 같은 대목이 두 번 뜹니다.'
                                 ).format(p=hit[1]), parent=self)
                return
            if not add_verse_link(conn, self.eid, sv, ev):
                messagebox.showinfo('MY', i18n.t('EBM_V_EXIST', '이미 있는 연결입니다.'),
                                    parent=self)
                return
        self._done()

    def _save_vnote(self):
        d = self._cur_verse()
        if not d:
            return
        with appdb.connect(self.db) as conn:
            save_verse_note(conn, self.eid, d['vid'], d['end_vid'],
                            self._vn_txt.get('1.0', 'end').strip(), d['is_user'])
        self._done()

    def _hide_verse(self, on):
        d = self._cur_verse()
        if not d:
            return
        with appdb.connect(self.db) as conn:
            hide_verse_link(conn, self.eid, d['vid'], d['end_vid'], on)
        self._done()

    # ── ⑤⑥ 영상 / 텍스트 링크 ───────────────────────────────────
    # ── 사전 (연결하기 · 0.txt 1번) ────────────────────────────
    def _build_dict(self, p):
        bar = self._bar(p)
        self._btn(bar, 'EBM_D_ADD', '사전 항목 잇기…', self._add_dict)
        self._btn(bar, 'EBM_V_HIDE', '숨기기',
                  lambda: self._hide_dict(True))
        self._btn(bar, 'EBM_V_SHOW', '되돌리기',
                  lambda: self._hide_dict(False))
        tk.Label(p, anchor='w', justify='left', wraplength=760,
                 text=i18n.t('EBM_D_HINT',
                             '사전 본문은 고칠 수 없습니다(남의 저작). 이 '
                             '용어에 **어느 사전 항목을 잇는가**만 정합니다 '
                             '— 이은 것은 주요용어 「용어사전」 탭에 함께 '
                             '보입니다.')).pack(fill='x', padx=8, pady=(0, 4))
        self._dc_tv = self._tree(p, ('mk', 'src', 'label'), (40, 90, 320))
        for c, k, d in (('mk', 'EBM_C_MARK', '표시'),
                        ('src', 'EBM_D_C_SRC', '사전'),
                        ('label', 'EBM_D_C_ITEM', '항목')):
            self._dc_tv.heading(c, text=i18n.t(k, d))
        self._dc_rows = {}

    def _fill_dict(self):
        if not getattr(self, '_dc_tv', None):
            return
        self._dc_tv.delete(*self._dc_tv.get_children())
        self._dc_rows = {}
        OM.configure_tree(self._dc_tv)
        with appdb.connect(self.db) as conn:
            for i, d in enumerate(dict_links(conn, self.eid, self._lang())):
                iid = 'd%d' % i
                self._dc_tv.insert('', 'end', iid=iid,
                                   values=(d['mark'], d['src_code'],
                                           d['label']),
                                   tags=((OM.tag_name(d['mark']),)
                                         if d['mark'] else ()))
                self._dc_rows[iid] = d

    def _add_dict(self):
        """사전 항목 선택하기 — 표제어로 찾아 잇는다."""
        _t = i18n.t
        win = tk.Toplevel(self)
        win.title(_t('EBM_D_ADD', '사전 항목 잇기…'))
        win.transient(self.winfo_toplevel())
        win.grab_set()
        f = tk.Frame(win)
        f.pack(fill='both', expand=True, padx=10, pady=8)
        q = tk.Entry(f, width=26)
        q.pack(anchor='w')
        lb = tk.Listbox(f, height=12, width=46)
        lb.pack(fill='both', expand=True, pady=(4, 4))
        hits = []

        def find(_e=None):
            lb.delete(0, 'end')
            hits.clear()
            like = '%%%s%%' % (q.get() or '').strip()
            ph = ','.join('?' * len(DICT_SRC_CODES))
            with appdb.connect(self.db) as conn:
                for uid, code, label in conn.execute(
                        "SELECT u.ref_unit_id, s.src_code, u.unit_label "
                        "  FROM sys_ref_unit u "
                        "  JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id "
                        " WHERE s.src_code IN (%s) "
                        "   AND COALESCE(u.record_status,'LIVE')='LIVE' "
                        "   AND u.unit_label LIKE ? "
                        " ORDER BY u.unit_label LIMIT 200" % ph,
                        DICT_SRC_CODES + (like,)):
                    hits.append(uid)
                    lb.insert('end', '%s · %s' % (code, label or ''))
        q.bind('<Return>', find)
        bf = tk.Frame(f)
        bf.pack(fill='x')
        tk.Button(bf, text=_t('BTN_FIND', '찾기'), bd=1, padx=8,
                  command=find).pack(side='left')

        def okk(_e=None):
            sel = lb.curselection()
            if not sel:
                return
            with appdb.connect(self.db) as conn:
                add_dict_link(conn, self.eid, hits[sel[0]])
            win.destroy()
            self._done()
        tk.Button(bf, text=_t('OC_TT_LINKIT', '잇기'), bd=1, padx=10,
                  command=okk).pack(side='left', padx=(6, 0))
        lb.bind('<Double-1>', okk)
        try:
            import ui_theme
            ui_theme.adopt(win)
        except Exception:
            pass
        q.focus_set()
        find()

    def _hide_dict(self, hide):
        sel = self._dc_tv.selection() if getattr(self, '_dc_tv', None) else ()
        if not sel:
            return
        d = self._dc_rows.get(sel[0])
        if not d:
            return
        with appdb.connect(self.db) as conn:
            hide_dict_link(conn, self.eid, d['unit_id'], hide)
        self._done()

    def _build_media(self, p, kind):
        bar = self._bar(p)
        self._btn(bar, 'EBM_M_ADD', '링크 추가', lambda k=kind: self._add_media(k))
        self._btn(bar, 'EBM_V_HIDE', '숨기기',
                  lambda k=kind: self._hide_media(k, True))
        self._btn(bar, 'EBM_V_SHOW', '되돌리기',
                  lambda k=kind: self._hide_media(k, False))
        tv = self._tree(p, ('mk', 'title', 'url'), (40, 300, 380))
        for c, k, d in (('mk', 'EBM_C_MARK', '표시'),
                        ('title', 'EBM_C_TITLE', '제목'),
                        ('url', 'EBM_C_URL', '주소')):
            tv.heading(c, text=i18n.t(k, d))
        setattr(self, '_md_tv_' + kind, tv)
        setattr(self, '_md_rows_' + kind, {})

    def _fill_media(self, kind):
        tv = getattr(self, '_md_tv_' + kind)
        tv.delete(*tv.get_children())
        OM.configure_tree(tv)
        rows = {}
        with appdb.connect(self.db) as conn:
            for d in media_links(conn, self.eid, kind, self._lang()):
                iid = tv.insert('', 'end',
                                values=(d['mark'], d['title'], d['url']),
                                tags=((OM.tag_name(d['mark']),) if d['mark'] else ()))
                rows[iid] = d
        setattr(self, '_md_rows_' + kind, rows)

    def _add_media(self, kind):
        dlg = _LinkAdd(self)
        self.wait_window(dlg)
        if not getattr(dlg, 'result', None):
            return
        title, url = dlg.result
        with appdb.connect(self.db) as conn:
            if not add_media(conn, self.eid, title, url, self._lang()):
                messagebox.showinfo('MY', i18n.t('EBM_M_EXIST', '이미 있는 링크입니다.'),
                                    parent=self)
                return
        self._done()

    def _hide_media(self, kind, on):
        tv = getattr(self, '_md_tv_' + kind)
        s = tv.selection()
        if not s:
            return
        d = getattr(self, '_md_rows_' + kind).get(s[0])
        if not d:
            return
        with appdb.connect(self.db) as conn:
            hide_media(conn, d['mid'], d['is_user'], on)
        self._done()

    # ── ⑦ 연구자료 ──────────────────────────────────────────────
    def _build_ref(self, p):
        # ★ **그 자리에서 불러와 연결한다** (2026-08-26 사용자 지시 —
        #   「연구자료 탭 연구목록에서 「연결」 버튼 클릭하면 나타나는 것처럼」).
        #   화면을 새로 짓지 않고 **`link_picker` 를 그대로 부른다** — 검색·중복
        #   안내·저장이 이미 그 안에 있고, 두 곳에 지으면 규칙이 갈라진다.
        bar = self._bar(p)
        self._btn(bar, 'EBM_R_LINK', '연결…', self._pick_ref)
        self._btn(bar, 'EBM_R_OPEN', '연구자료 화면으로', self._go_ref)
        tk.Label(p, anchor='w', justify='left', wraplength=760,
                 text=i18n.t('EBM_R_HINT2',
                             '[연결…] 로 이미 쓴 연구자료를 이 용어에 붙입니다. '
                             '글을 새로 쓰고 고치는 것은 연구자료 화면에서 합니다.')
                 ).pack(fill='x', padx=10, pady=(0, 6))
        self._rf_tv = self._tree(p, ('mk', 'title'), (40, 660))
        for c, k, d in (('mk', 'EBM_C_MARK', '표시'),
                        ('title', 'EBM_C_TITLE', '제목')):
            self._rf_tv.heading(c, text=i18n.t(k, d))

    def _fill_ref(self):
        tv = self._rf_tv
        tv.delete(*tv.get_children())
        OM.configure_tree(tv)
        self._rf_rows = {}
        # ⚠⚠ **통합 표를 읽는다** (2026-08-27 사용자 신고 「연구자료 연결시켰다.
        #   안된다」의 정체). `link_picker` 는 §82 통합 이후 **`user_link_asset`**
        #   (`ENTI_UREF`)에 쓰는데 이 목록은 **옛 표**(`user_ref_asset_link`)를
        #   읽고 있었다 — **저장은 되는데 목록에 안 나왔다.** 오류도 안 났다.
        #   ⇒ 통합 표 ∪ 옛 표 ∪ 옛 단일 칸 셋을 함께 본다(옛 것 15건·4건이
        #     아직 살아 있으므로 버리면 그것들이 화면에서 사라진다).
        # ★★ 통합 표는 **`link_picker.targets_of`** 로만 묻는다 —
        #   이름 앞뒤(`ENTI_UREF`/`UREF_ENTI`)를 화면이 알 필요가 없다.
        try:
            with appdb.connect(self.db) as conn:
                ids = {i for i, _e in
                       LP.targets_of(conn, 'ENTITY', self.eid, 'USER_REF')}
                for r in conn.execute(
                        'SELECT ra.ref_id FROM userdb.user_ref_asset ra '
                        "WHERE COALESCE(ra.record_status,'LIVE')='LIVE' AND ("
                        '  ra.entity_id=? '
                        '  OR EXISTS (SELECT 1 FROM userdb.user_ref_asset_link rl '
                        "     WHERE rl.ref_id=ra.ref_id AND rl.link_kind='ENTITY' "
                        '       AND rl.target_id=?))', (self.eid, self.eid)):
                    ids.add(r[0])
                for rid, title in ([] if not ids else conn.execute(
                        'SELECT ref_id, title FROM userdb.user_ref_asset '
                        " WHERE COALESCE(record_status,'LIVE')='LIVE' "
                        '   AND ref_id IN (%s) ORDER BY ref_id'
                        % ','.join('?' * len(ids)), tuple(sorted(ids)))):
                    iid = tv.insert('', 'end', values=(OM.NEW, title or ''),
                                    tags=(OM.tag_name(OM.NEW),))
                    self._rf_rows[iid] = rid
        except Exception as e:
            print('[MY] refs: %s' % e)

    def _pick_ref(self):
        """연결하기 창 — 이 용어를 기준으로 (owner = ENTITY).

        ⚠ `scope='USER'` — 사용자 동작이므로 **내 DB 에만** 쌓인다(§0-6 C-2).
        """
        try:
            import link_picker
        except Exception as e:
            messagebox.showerror('MY', str(e), parent=self)
            return
        link_picker.open_picker(
            self, self.db, 'ENTITY', self.eid, scope='USER',
            lang_getter=self._lang, on_saved=lambda *_a: self._done())

    def _go_ref(self):
        if not callable(self._on_ref_open):
            return                        # 열 길이 없는 호스트 — 조용히 무시
        s = self._rf_tv.selection()
        self._on_ref_open(self._rf_rows.get(s[0]) if s else None)


class _MyWin(tk.Toplevel):
    """「MY」 창 — `MyBody` 를 담는 얇은 껍데기(기존 진입점 호환)."""

    def __init__(self, host, entity_id):
        super().__init__(host)
        self.host = host
        self.geometry('820x680')
        self.transient(host.winfo_toplevel())

        def _changed(eid):
            host._alias_cache = None
            host.load_entity(eid)

        def _ref_open(row):
            fn = getattr(host, 'on_user_open', None)
            if row is not None and callable(fn):
                fn(row)
            elif callable(getattr(host, 'on_article_open', None)):
                host.on_article_open(None)

        self.body = MyBody(
            self, host.db_path, host._desc_lang,
            on_changed=_changed, on_ref_open=_ref_open,
            title_setter=lambda nm: self.title('My Edit — %s' % nm))
        self.body.pack(fill='both', expand=True)
        self.body.load(entity_id)
        try:
            import ui_theme
            import theme_font as _tf
            ui_theme.adopt(self)          # ⚠ 다 지은 뒤 한 번(§36-5b)
            _tf.scale(self, host.db_path)
        except Exception as e:
            print('[MY] theme: %s' % e)

    def load(self, entity_id):
        self.body.load(entity_id)


class _VersePick(tk.Toplevel):
    """구절 선택하기 — **1구절도 구간도**(사용자 확정). 끝 절을 비우면 1구절."""

    def __init__(self, parent, db, lang):
        super().__init__(parent)
        self.db, self.lang, self.result = db, lang, None
        self.title(i18n.t('EBM_V_ADD', '구절 추가'))
        self.transient(parent)
        self.grab_set()
        with appdb.connect(db) as conn:
            self.books = conn.execute(
                'SELECT bn.book_code, bn.full_name FROM book_names bn '
                'WHERE UPPER(bn.lang_code)=? AND bn.book_code IN '
                '(SELECT DISTINCT bcode FROM bible_index) ORDER BY bn.book_code',
                ((lang or 'KO').upper(),)).fetchall()
        bar = tk.Frame(self)
        bar.pack(fill='x', padx=10, pady=10)
        tk.Button(bar, text=i18n.t('COMMON_SAVE', '저장'), bd=1, padx=8,
                  command=self._ok).pack(side='left', padx=(0, 6))
        tk.Button(bar, text=i18n.t('COMMON_CLOSE', '닫기'), bd=1, padx=8,
                  command=self.destroy).pack(side='left')
        row = tk.Frame(self)
        row.pack(fill='x', padx=10, pady=(0, 10))
        self.cb_b = ttk.Combobox(row, state='readonly', width=14,
                                 values=[b[1] for b in self.books])
        self.cb_b.pack(side='left')
        self.cb_c = ttk.Combobox(row, state='readonly', width=5)
        self.cb_c.pack(side='left', padx=3)
        self.cb_v = ttk.Combobox(row, state='readonly', width=5)
        self.cb_v.pack(side='left', padx=3)
        tk.Label(row, text=' ~ ').pack(side='left')
        self.cb_c2 = ttk.Combobox(row, state='readonly', width=5)
        self.cb_c2.pack(side='left', padx=3)
        self.cb_v2 = ttk.Combobox(row, state='readonly', width=5)
        self.cb_v2.pack(side='left', padx=3)
        tk.Label(self, anchor='w', wraplength=420,
                 text=i18n.t('EBM_V_RANGE_HINT',
                             '끝 장·절을 비우면 한 구절만 잇습니다.')
                 ).pack(fill='x', padx=10, pady=(0, 10))
        self.cb_b.bind('<<ComboboxSelected>>', lambda _e: self._chaps())
        self.cb_c.bind('<<ComboboxSelected>>', lambda _e: self._verses())
        self.cb_c2.bind('<<ComboboxSelected>>', lambda _e: self._verses2())
        # ★ 끝 칸을 건드리면 시작 장을 미리 넣는다 — 문은 하나다
        LP.bind_end_autofill(self.cb_c, self.cb_c2, self.cb_v2,
                             self._verses2)
        if self.books:
            self.cb_b.current(0)
            self._chaps()
        try:
            import ui_theme
            ui_theme.adopt(self)
        except Exception:
            pass

    def _bcode(self):
        i = self.cb_b.current()
        return self.books[i][0] if i >= 0 else None

    def _chaps(self):
        with appdb.connect(self.db) as conn:
            ch = [r[0] for r in conn.execute(
                'SELECT DISTINCT chapter FROM bible_index WHERE bcode=? '
                'ORDER BY chapter', (self._bcode(),))]
        self.cb_c['values'] = ch
        self.cb_c2['values'] = [''] + ch
        if ch:
            self.cb_c.current(0)
        self.cb_c2.set('')
        self._verses()
        self.cb_v2.set('')
        self.cb_v2['values'] = ['']

    def _vlist(self, ch):
        if not ch:
            return []
        with appdb.connect(self.db) as conn:
            return [r[0] for r in conn.execute(
                'SELECT verse FROM bible_index WHERE bcode=? AND chapter=? '
                'ORDER BY verse', (self._bcode(), int(ch)))]

    def _verses(self):
        vs = self._vlist(self.cb_c.get())
        self.cb_v['values'] = vs
        if vs:
            self.cb_v.current(0)

    def _verses2(self):
        vs = self._vlist(self.cb_c2.get())
        self.cb_v2['values'] = [''] + vs
        self.cb_v2.set('')

    def _ok(self):
        b = self._bcode()
        if not b or not self.cb_c.get() or not self.cb_v.get():
            return
        with appdb.connect(self.db) as conn:
            sv = _vid_of(conn, b, int(self.cb_c.get()), int(self.cb_v.get()))
            ev = sv
            if self.cb_c2.get() and self.cb_v2.get():
                ev = _vid_of(conn, b, int(self.cb_c2.get()),
                             int(self.cb_v2.get())) or sv
        if sv:
            self.result = (sv, ev)
        self.destroy()


class _LinkAdd(tk.Toplevel):
    """링크 붙이기 — 서핑하다 만난 것을 이 용어에(0.txt 2번)."""

    def __init__(self, parent):
        super().__init__(parent)
        self.result = None
        self.title(i18n.t('EBM_M_ADD', '링크 추가'))
        self.transient(parent)
        self.grab_set()
        bar = tk.Frame(self)
        bar.pack(fill='x', padx=10, pady=10)
        tk.Button(bar, text=i18n.t('COMMON_SAVE', '저장'), bd=1, padx=8,
                  command=self._ok).pack(side='left', padx=(0, 6))
        tk.Button(bar, text=i18n.t('COMMON_CLOSE', '닫기'), bd=1, padx=8,
                  command=self.destroy).pack(side='left')
        self.t_var, self.u_var = tk.StringVar(), tk.StringVar()
        for lb, var in ((i18n.t('EBM_C_TITLE', '제목'), self.t_var),
                        (i18n.t('EBM_C_URL', '주소'), self.u_var)):
            r = tk.Frame(self)
            r.pack(fill='x', padx=10, pady=(0, 8))
            tk.Label(r, text=lb, width=6, anchor='w').pack(side='left')
            tk.Entry(r, textvariable=var, width=60).pack(side='left', fill='x',
                                                         expand=True)
        try:
            import ui_theme
            ui_theme.adopt(self)
        except Exception:
            pass

    def _ok(self):
        u = self.u_var.get().strip()
        if u:
            self.result = (self.t_var.get().strip(), u)
        self.destroy()
