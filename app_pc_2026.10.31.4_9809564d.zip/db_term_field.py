# -*- coding: utf-8 -*-
"""db_term_field.py — 낱말 승격 + 의미장(semantic field) 이관 도구 (영구).

2026-09-02 사용자 확정 설계 (177차):
  · **뜻이 구별되는 낱말은 부속 기록(sys_entity_lemma)에서 정식 TERM 엔티티로
    승격**한다 — 「약간의 차이가 있다면 두 단어가 명확히 독립적으로 관리되어야
    하고 서로 비교할 수 있도록」.
  · **뜻이 확실히 같은 짝만 한 엔티티가 여러 낱말(여러 이름)을 유지**한다 —
    「동명이인이 아니라 동일인 여러 이름」(하타트↔하마르티아 · 아웰↔아디키아).
  · **연결은 별명(문자열)이 아니라 데이터**다 — 의미장 엔티티 + 소속 링크
    (`ENTI_ENTI` rel_code='FIELD_WORD'). 별명은 검색 입구 보조일 뿐이다.
    (별명 공유 방식은 언어마다 다시 만들어야 하고(×11) 문자열 오탐을 낳는다.)

무엇을 하나:
  ① 승격 — 낱말 행(sys_entity_lemma)의 entity_id 를 새 TERM 으로 옮긴다.
     lemma_id 가 보존되므로 낱말별 설명문(ENTITY_LEMMA_DESC, lemma_id 닻)이
     따라온다. 낱말연결(LEXICAL)은 `db_term_load.relink` 재생성 — 옮기는
     헬라 행들은 is_key·note·설명문 전부 0 임을 실측하고 택한 방식이다
     (2026-09-02 — 메타데이터가 있는 낱말을 옮길 때는 UPDATE 이관으로 바꿀 것).
  ② 새 앵커 — 검증 DB(wlc/gnt_verify)에 있는 스트롱을 새 낱말 행으로 넣고
     relink 가 절을 벌인다.
  ③ 의미장 — 개념 노드 엔티티(json_detail.subtype='FIELD') + 소속 링크.
     화면(비교 칸)은 `overlay_read.field_siblings` 가 이 링크에서 형제를
     자동 유도한다 — N² 비교 짝 유지가 필요 없어진다.

사용:
  python db_term_field.py --selftest     (의무 — 메모리 DB, 실 DB 안 건드림)
  python db_term_field.py --check        (게이트만)
  python db_term_field.py --apply        (멱등)
  python db_term_field.py --undo         (낱말 원위치 + 새 것 걷기)
  python db_term_field.py --status

⚠ 게이트: 옮길 낱말 실재 · 새 앵커가 검증 DB 에 실재 · KO 설명문 「—」 금지 ·
  빈 줄 금지 · 길이 하한 · 소속 코드 실재.
⚠ 백업 = temp_termfield_backup (lemma_id, old_entity_id, batch). selftest 는
  메모리 DB 라 실 백업을 건드리지 않는다(§139차).
"""
import io
import json
import sys

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

NL = chr(10)
BK = 'temp_termfield_backup'

# ──────────────────────────────────────────────────────────────────────
# 죄 시범 초안 (2026-09-02 승인 — 「일단 죄에 대해서 먼저 시도해보자」)
# 측정 근거: 파라바시스 NT 7절(범함·범법 100%) · 파라프토마 19절(죄 계열 84%) ·
# 아디키아 24 · 아노미아 13 · 아웰 51절(불의 49%, LXX 다리 아디키아 1위 →
# 동일 의미 판정으로 아디키아와 한 몸) · 마알 명 28+동 35(범과·범죄·신실치 못함) ·
# 아세베이아 6+아세베스 9(경건치 않음 100%). 레샤(악 90%)는 「악」 의미장
# 후보로 보류 — 죄 가족이 아니다(용어명부 검토목록).
DRAFT = {
    'field': {
        'code': 'F_SIN', 'subtype': 'FIELD',
        'KO': '죄의 낱말 가족', 'EN': 'The Sin Word Family',
        'desc_ko': NL.join([
            '성경은 죄를 한 낱말로 말하지 않습니다. 여러 낱말이 저마다 한 그림씩 맡아 죄의 다른 국면을 보여 줍니다.',
            '과녁을 벗어난 빗나감(죄·하타트·하마르티아), 굽어 뒤틀린 상태와 그 짐(죄악·아온), 언약을 깨뜨리는 반역(허물·페샤), 그어진 법을 넘는 일(범법·파라바시스), 곁으로 헛디딘 실족(범죄·파라프토마), 마땅함에서 벗어난 기움(불의·아웰·아디키아), 법을 없는 것으로 치는 태도(불법·아노미아), 맡겨진 신뢰를 저버리는 배임(범과·마알), 하나님을 하나님으로 대하지 않음(경건치 않음·아세베이아)입니다.',
            '낱말이 다른 것은 어느 하나가 다른 것에 포함되어서가 아니라, 죄라는 한 실체의 다른 얼굴들이기 때문입니다. 시32:1~2와 사53:5~6은 히브리 낱말들을, 롬1:18은 헬라 낱말들을 나란히 세워 함께 읽게 합니다.',
            '각 낱말의 항목에서 그 낱말의 결을 읽고, 서로 비교하며 죄의 전체 그림을 그려 보십시오.']),
        'desc_en': NL.join([
            'Scripture does not speak of sin with a single word. Several words each carry one picture, showing a different face of the same reality.',
            'Missing the mark (chattat, hamartia), a twisted condition and its burden (avon), covenant-breaking rebellion (pesha), stepping over a drawn line (parabasis), a false step beside the path (paraptoma), a tilt away from what is due (avel, adikia), treating the law as nothing (anomia), betraying an entrusted faithfulness (maal), and refusing God the reverence that is his (asebeia).',
            'The words differ not because one contains the others, but because they are different faces of one reality. Psalm 32:1-2 and Isaiah 53:5-6 set the Hebrew words side by side; Romans 1:18 does the same for the Greek.',
            'Read each word in its own entry, and compare them to see the whole picture of sin.']),
    },
    'words': [
        {'code': 'T_PARABASIS',
         'KO': '범법 · 파라바시스', 'EN': 'Transgression of the Law (parabasis)',
         'move': [('T_PESHA', 'G3847')], 'new': [],
         'alias_ko': ['범함'], 'alias_en': ['Parabasis'],
         'desc_ko': NL.join([
             '범법으로 옮겨지는 이 낱말의 그림은 그어 놓은 선을 넘어가는 것입니다. 걸음을 뜻하는 말에 「곁으로 지나」가 붙어, 정해진 길 밖으로 발을 내딛는 모습을 그립니다.',
             '그래서 이 낱말은 선이 있어야 성립합니다. 「율법이 없는 곳에는 범함도 없느니라」(롬4:15)가 이 낱말의 정의 구절입니다. 알려 주신 계명이 있고, 그것을 알면서 넘어간 것이 파라바시스입니다.',
             '성경은 아담과 하와의 일을 이 낱말로 부릅니다(롬5:14, 딤전2:14). 히브리서는 첫 언약 아래에서 「범한 죄」를 속량하시려고 그리스도께서 죽으셨다고 합니다(히9:15).',
             '히브리어 페샤가 언약을 깨뜨리는 반역이라면, 파라바시스는 그어진 법을 넘는 일에 초점이 있습니다. 결이 가까워 서로 비교하며 읽으면 좋습니다.']),
         'desc_en': NL.join([
             'The word rendered transgression pictures stepping over a drawn line: a word for walking with "beside, past" attached, a foot planted outside the appointed path.',
             'So the word requires a line. "Where there is no law, neither is there transgression" (Romans 4:15) is its defining verse: a commandment was given, and it was knowingly crossed.',
             'Scripture calls the deed of Adam and Eve by this word (Romans 5:14; 1 Timothy 2:14), and Hebrews says Christ died to redeem the transgressions under the first covenant (Hebrews 9:15).',
             'Where Hebrew pesha is covenant-breaking rebellion, parabasis focuses on crossing a drawn law. The two are close kin and reward comparison.'])},
        {'code': 'T_PARAPTOMA',
         'KO': '범죄 · 파라프토마', 'EN': 'Trespass (paraptoma)',
         'move': [('T_PESHA', 'G3900')], 'new': [],
         'alias_ko': ['허물', '과실'], 'alias_en': ['Paraptoma'],
         'desc_ko': NL.join([
             '범죄로 옮겨지는 이 낱말의 그림은 곁으로 헛디뎌 넘어지는 것입니다. 「넘어지다」에서 나온 말로, 길을 걷다가 발을 잘못 디딘 실족을 그립니다.',
             '개역한글은 이 낱말을 범죄, 허물, 과실로 옮깁니다. 「너희의 허물과 죄로 죽었던 너희를 살리셨도다」(엡2:1)의 허물이 이 낱말이고, 「사람이 만일 무슨 범죄한 일이 드러나거든」(갈6:1)처럼 드러난 잘못에도 쓰입니다.',
             '로마서 5장은 아담 「한 사람의 범죄」와 그리스도의 은혜를 이 낱말로 견줍니다. 한 번의 실족이 모두에게 미쳤으나 은혜는 그보다 넘칩니다.',
             '주기도문 뒤에 이어지는 「너희가 사람의 과실을 용서하면」(마6:14)도 이 낱말입니다. 서로 용서할 것으로 다루어지는, 걸려 넘어진 자리의 죄입니다.']),
         'desc_en': NL.join([
             'The word rendered trespass pictures a false step beside the path: it comes from the verb for falling, a foot set wrong while walking.',
             'It is the "trespasses" in which we were dead (Ephesians 2:1), and the fault in which someone is "overtaken" (Galatians 6:1).',
             'Romans 5 weighs the one man\'s trespass against the grace of Christ: one false step reached all, yet grace abounds far beyond it.',
             'It is also the word after the Lord\'s Prayer, "if you forgive men their trespasses" (Matthew 6:14): the sin of the stumbling place, handled between people with forgiveness.'])},
        {'code': 'T_AVEL',
         'KO': '불의 · 아웰 · 아디키아', 'EN': 'Injustice (avel / adikia)',
         'move': [('T_AVON', 'G93')],
         'new': [('HE', 'H5766', '아웰', '불의 · 마땅함에서 벗어난 기움')],
         'alias_ko': [], 'alias_en': ['Avel', 'Adikia'],
         'desc_ko': NL.join([
             '불의로 옮겨지는 이 낱말의 그림은 마땅함에서 벗어난 것입니다. 재판과 저울의 낱말로, 공평해야 할 자리가 한쪽으로 기운 상태를 가리킵니다.',
             '「재판할 때에 불의를 행치 말며」(레19:15)가 이 낱말의 자리를 보여 줍니다. 저울추와 되를 속이는 일도 같은 계열입니다.',
             '성경은 하나님께 이 낱말이 없다고 거듭 말합니다. 「공의로우시고 정직하시니」(신32:4), 「그에게는 불의가 없도다」(시92:15).',
             '신약의 아디키아가 이 낱말을 받았습니다. 70인역이 아웰을 옮긴 으뜸 낱말이 아디키아이고 뜻이 같아, 한 낱말의 두 이름으로 다룹니다. 「모든 불의에서 우리를 깨끗케 하실 것이요」(요일1:9)가 이 낱말입니다.']),
         'desc_en': NL.join([
             'The word rendered injustice pictures a tilt away from what is due: a word of courts and scales, where a place that should be level leans to one side.',
             '"You shall do no injustice in judgment" (Leviticus 19:15) shows its home ground; false weights and measures belong to the same family.',
             'Scripture repeats that God has none of it: "just and right is he" (Deuteronomy 32:4); "there is no unrighteousness in him" (Psalm 92:15).',
             'New Testament adikia received this word: it is the Septuagint\'s chief rendering of avel, and the meanings match, so the two are treated as one word with two names. "To cleanse us from all unrighteousness" (1 John 1:9) is this word.'])},
        {'code': 'T_ANOMIA',
         'KO': '불법 · 아노미아', 'EN': 'Lawlessness (anomia)',
         'move': [('T_AVON', 'G458')], 'new': [],
         'alias_ko': [], 'alias_en': ['Anomia'],
         'desc_ko': NL.join([
             '불법으로 옮겨지는 이 낱말의 그림은 법을 없는 것으로 치는 태도입니다. 법을 뜻하는 노모스에 부정하는 말이 붙었습니다.',
             '「죄를 짓는 자마다 불법을 행하나니 죄는 불법이라」(요일3:4)가 이 낱말의 정의 구절입니다. 죄의 본질이 하나님의 법을 무시하는 데 있다는 선언입니다.',
             '예수님은 마지막 날에 「불법을 행하는 자들아 내게서 떠나가라」(마7:23) 하실 것을 미리 말씀하셨고, 마지막 때에 「불법이 성하므로 많은 사람의 사랑이 식어지리라」(마24:12) 하셨습니다.',
             '낱낱의 잘못이라기보다 법 자체를 우습게 여기는 방향을 가리키는 낱말입니다.']),
         'desc_en': NL.join([
             'The word rendered lawlessness pictures treating the law as nothing: nomos, law, with the negating prefix attached.',
             '"Everyone who sins practices lawlessness; sin is lawlessness" (1 John 3:4) is its defining verse: the heart of sin is disregard for God\'s law.',
             'Jesus foretold the last day\'s "depart from me, you workers of lawlessness" (Matthew 7:23), and that "because lawlessness is multiplied, the love of many will grow cold" (Matthew 24:12).',
             'Less a single misdeed than a direction: holding the law itself in contempt.'])},
        {'code': 'T_MAAL',
         'KO': '범과 · 마알', 'EN': 'Unfaithfulness (maal)',
         'move': [],
         'new': [('HE', 'H4603', '마알', '신실치 못하게 범과하다 (동사)'),
                 ('HE', 'H4604', '마알', '범과 · 맡은 신뢰를 저버림 (명사)')],
         'alias_ko': ['범죄', '신실치 못함'], 'alias_en': ['Maal'],
         'desc_ko': NL.join([
             '범과로 옮겨지는 이 낱말의 그림은 맡겨진 신뢰를 등 뒤에서 저버리는 것입니다. 「여호와의 성물에 대하여 그릇 범과하였거든」(레5:15), 「여호와께 신실치 못하여 범죄하되」(레6:2)가 이 낱말의 자리입니다.',
             '성물을 사사로이 쓰는 일, 혼인의 신의를 깨는 일(민5:12), 바친 물건에 손대는 일에 쓰입니다. 아간이 바친 물건을 감춘 일(수7:1)과 사울이 여호와께 범죄한 일(대상10:13)이 이 낱말로 기록됩니다.',
             '드러난 반역이라기보다 몰래 저지르는 배임이 이 낱말의 결입니다. 믿고 맡긴 관계가 전제되어 있고, 그 신뢰를 속에서 깨뜨리는 것입니다.']),
         'desc_en': NL.join([
             'The word rendered trespass in the sense of unfaithfulness pictures betraying an entrusted trust behind its back. "If anyone commits a trespass against the holy things of the LORD" (Leviticus 5:15) is its home.',
             'It is used of taking holy things for oneself, of breaking marriage faith (Numbers 5:12), and of touching what was devoted: Achan\'s hidden spoil (Joshua 7:1) and Saul\'s unfaithfulness to the LORD (1 Chronicles 10:13) are recorded with this word.',
             'Its grain is not open rebellion but hidden breach of trust: a relationship of entrusting is assumed, and it is broken from within.'])},
        {'code': 'T_ASEBEIA',
         'KO': '경건치 않음 · 아세베이아', 'EN': 'Ungodliness (asebeia)',
         'move': [],
         'new': [('EL', 'G763', '아세베이아', '경건치 않음 (명사)'),
                 ('EL', 'G765', '아세베스', '경건치 않은 (형용사)')],
         'alias_ko': ['불경건'], 'alias_en': ['Asebeia'],
         'desc_ko': NL.join([
             '경건치 않음으로 옮겨지는 이 낱말의 그림은 하나님을 하나님으로 대하지 않는 것입니다. 경외를 뜻하는 말에 부정하는 말이 붙어, 마땅히 드릴 공경을 드리지 않는 방향을 가리킵니다.',
             '「하나님의 진노가 불의로 진리를 막는 사람들의 모든 경건치 않음과 불의에 대하여 하늘로 좇아 나타나나니」(롬1:18)에서 이 낱말은 불의(아디키아)와 나란히 섭니다. 사람을 향한 죄보다 먼저, 하나님을 향한 자세가 무너진 것을 짚습니다.',
             '그런데 복음은 바로 그 사람들을 향합니다. 「기약대로 그리스도께서 경건치 않은 자를 위하여 죽으셨도다」(롬5:6).',
             '죄의 여러 낱말 가운데 수직의 축, 곧 하나님과의 관계가 틀어진 국면을 맡는 낱말입니다.']),
         'desc_en': NL.join([
             'The word rendered ungodliness pictures refusing God the reverence that is his: the word for awe with the negating prefix, a direction of withholding due honor.',
             'In Romans 1:18 it stands beside injustice (adikia): "the wrath of God is revealed from heaven against all ungodliness and unrighteousness of men." Before sin against neighbor, it names the collapse of posture toward God.',
             'Yet the gospel aims precisely there: "at the right time Christ died for the ungodly" (Romans 5:6).',
             'Among the words for sin, this one carries the vertical axis: the disordered relation to God himself.'])},
    ],
    'members': ['T_CHATAT', 'T_AVON', 'T_PESHA', 'T_PARABASIS', 'T_PARAPTOMA',
                'T_AVEL', 'T_ANOMIA', 'T_MAAL', 'T_ASEBEIA'],
}


# ──────────────────────────────────────────────────────────────────────
# 둘째 초안 — 하나님의 이름 가족 + 사탄·마귀 (2026-09-02 181차 사용자 지시
# 「사탄·마귀 엔티티를 등록하라. 측정 후 판단하라. 추가적으로 야훼, 엘로힘,
# 여호와, 아도나이, 샤다이, 체바오트,,, 모두 없다」).
# 측정: 사탄 H7854 사단14·대적7 · 사타나스 G4567 사단 97% · 디아볼로스 G1228
# 마귀 89% — 계12:9 가 「마귀라고도 하고 사단이라고도 하는」이라 직접 말하므로
# **동일 존재 여러 이름 = 한 엔티티**. 아도나이 주 91% · 샤다이 전능 100% ·
# 체바오트 만군 45%(군대 21% — 일반명사 용법 공존, 설명문이 가른다) ·
# 엘로힘 2,600회 · 여호와 H3068+H3069 6,827회 · 엘로아흐 H433 은 엘로힘의
# 홑 꼴이라 같은 항목의 둘째 앵커.
DRAFT_NAMES = {
    'field': {
        'code': 'F_DIVINE_NAMES', 'subtype': 'FIELD',
        'KO': '하나님의 이름 가족', 'EN': 'The Names of God',
        'desc_ko': NL.join([
            '성경은 하나님을 한 이름으로 부르지 않습니다. 이름마다 하나님의 다른 얼굴을 보여 줍니다.',
            '신성 그 자체를 부르는 엘로힘(하나님), 언약과 관계의 이름 여호와, 주인과 종의 관계를 담는 아도나이(주), 족장들에게 알리신 샤다이(전능자), 하늘 군대를 거느리시는 체바오트(만군), 그리고 가장 짧고 오래된 엘입니다.',
            '출애굽기 6장 3절이 이 이름들의 관계를 스스로 말합니다. 「내가 아브라함과 이삭과 야곱에게 전능의 하나님으로 나타났으나 나의 이름을 여호와로는 그들에게 알리지 아니하였고」.',
            '각 이름의 항목에서 그 이름의 결을 읽고, 서로 비교하며 하나님이 자신을 어떻게 알려 오셨는지 따라가 보십시오.']),
        'desc_en': NL.join([
            'Scripture does not call God by a single name. Each name shows a different face.',
            'Elohim names deity itself; Jehovah (YHWH) is the covenant name; Adonai sets the speaker as servant before the Lord; Shaddai, the Almighty, was the name known to the patriarchs; Tsevaot, of Hosts, marshals the armies of heaven; and El is the oldest and shortest of them all.',
            'Exodus 6:3 states their relation: "I appeared unto Abraham, unto Isaac, and unto Jacob, by the name of God Almighty, but by my name JEHOVAH was I not known to them."',
            'Read each name in its own entry, and compare them to trace how God has made himself known.']),
    },
    'words': [
        {'code': 'T_ELOHIM', 'KO': '하나님 · 엘로힘', 'EN': 'God (elohim)',
         'move': [],
         'new': [('HE', 'H430', '엘로힘', '하나님 (겹 꼴)'),
                 ('HE', 'H433', '엘로아흐', '하나님 (홑 꼴 · 욥기)')],
         'alias_ko': ['엘로아흐'], 'alias_en': ['Elohim'],
         'desc_ko': NL.join([
             '구약이 하나님을 부르는 가장 흔한 이름입니다. 「태초에 하나님이 천지를 창조하시니라」(창1:1)의 하나님이 엘로힘입니다.',
             '꼴은 복수인데 동사는 단수로 받습니다. 위엄과 충만을 담는 히브리어의 어법으로 읽혀 왔고, 교회는 여기서 삼위의 여지를 함께 보아 왔습니다.',
             '참 하나님만 아니라 이방 신들과 재판장들에게도 쓰입니다(시82:1). 그래서 이 이름은 관계의 이름이라기보다 신성 그 자체의 이름입니다.',
             '홑 꼴 엘로아흐는 주로 욥기에 나옵니다. 같은 낱말의 홑과 겹이라 한 항목으로 다룹니다.']),
         'desc_en': NL.join([
             'The most common Old Testament name for God: the God of "In the beginning God created" (Genesis 1:1) is Elohim.',
             'The form is plural, yet it takes a singular verb, a Hebrew idiom of majesty and fullness in which the church has also seen room for the Trinity.',
             'It is used not only of the true God but of the gods of the nations and even of judges (Psalm 82:1), so it names deity itself rather than a relationship.',
             'The singular Eloah appears chiefly in Job; being the same word in singular form, it is kept in this entry.'])},
        {'code': 'T_YHWH', 'KO': '여호와 · 야훼', 'EN': 'Jehovah / YHWH (yahweh)',
         'move': [],
         'new': [('HE', 'H3068', '여호와', '언약의 이름 YHWH'),
                 ('HE', 'H3069', '여호와', '아도나이와 겹칠 때의 꼴')],
         'alias_ko': ['야웨', '야훼'], 'alias_en': ['Yahweh', 'Jehovah', 'LORD'],
         'desc_ko': NL.join([
             '하나님의 언약 이름입니다. 출애굽기 3장에서 「나는 스스로 있는 자니라」 하시며 알리신 그 이름으로, 개역한글은 여호와로 옮깁니다.',
             '히브리어 네 글자로 적히고, 유대인들은 이 이름을 감히 읽지 않아 주(아도나이)로 바꾸어 읽었습니다. 여호와라는 표기는 그 관습에서 나온 것이고, 본디 야훼로 읽었을 것으로 봅니다.',
             '엘로힘이 신성의 이름이라면 여호와는 언약과 관계의 이름입니다. 「여호와는 나의 목자시니」(시23:1)처럼 자기 백성에게 자신을 매시는 자리에서 이 이름이 나옵니다.',
             '구약에 육천팔백 회 넘게 나오는 가장 흔한 고유명사입니다. 아도나이와 나란히 설 때 「주」로 읽게 한 꼴이 따로 전해집니다.']),
         'desc_en': NL.join([
             'The covenant name of God, made known in Exodus 3: "I AM THAT I AM."',
             'Written with four Hebrew letters, it was held too sacred to pronounce; readers substituted Adonai, and the spelling Jehovah grew out of that custom. The original was likely Yahweh.',
             'Where Elohim names deity, YHWH names covenant relation: "The LORD is my shepherd" (Psalm 23:1) binds this name to his own people.',
             'It occurs more than six thousand eight hundred times, the most frequent proper name in the Old Testament.'])},
        {'code': 'T_ADONAI', 'KO': '주 · 아도나이', 'EN': 'Lord (adonai)',
         'move': [], 'new': [('HE', 'H136', '아도나이', '주 · 주인이신 하나님')],
         'alias_ko': [], 'alias_en': ['Adonai'],
         'desc_ko': NL.join([
             '주로 옮겨지는 이 이름의 그림은 주인과 종의 관계입니다. 다스리시는 분 앞에 자기를 종으로 놓는 부름입니다.',
             '사람 사이의 주인과 구별해 이 꼴은 하나님께만 씁니다. 「주 여호와여」(창15:2)처럼 여호와와 나란히 서기도 합니다.',
             '유대인들이 여호와의 이름을 읽지 않을 때 대신 읽은 것이 이 이름이라, 70인역과 신약의 「주(퀴리오스)」로 이어지는 다리가 됩니다.']),
         'desc_en': NL.join([
             'The name rendered Lord pictures the relation of master and servant: the speaker sets himself as servant before the one who rules.',
             'Distinct from the ordinary word for a human master, this form is reserved for God, and stands beside YHWH in addresses like "Lord GOD" (Genesis 15:2).',
             'Since readers pronounced this name in place of YHWH, it became the bridge to the Septuagint and New Testament "Lord" (kyrios).'])},
        {'code': 'T_SHADDAI', 'KO': '전능자 · 샤다이', 'EN': 'The Almighty (shaddai)',
         'move': [], 'new': [('HE', 'H7706', '샤다이', '전능자')],
         'alias_ko': ['전능하신 하나님', '엘샤다이'], 'alias_en': ['Shaddai', 'El Shaddai'],
         'desc_ko': NL.join([
             '전능자로 옮겨지는 이름입니다. 개역한글이 마흔여덟 번 모두 「전능」으로 옮길 만큼 결이 한결같습니다.',
             '족장들에게 자신을 알리신 이름입니다. 「나는 전능한 하나님이라 너는 내 앞에서 행하여 완전하라」(창17:1). 출애굽기 6장 3절은 아브라함과 이삭과 야곱에게는 전능의 하나님으로 나타났고 여호와라는 이름으로는 알리지 않았다고 말합니다.',
             '욥기가 이 이름을 가장 자주 씁니다. 고난 속에서 마주 서는 하나님이 전능자라는 것이 욥기의 무게입니다.']),
         'desc_en': NL.join([
             'The name rendered the Almighty; its grain is so consistent that the Korean Bible renders all forty-eight occurrences alike.',
             'It is the patriarchal name: "I am the Almighty God; walk before me, and be thou perfect" (Genesis 17:1). Exodus 6:3 says God appeared to Abraham, Isaac and Jacob by this name before the name YHWH was made known.',
             'Job uses it most of all: the God met in suffering is the Almighty.'])},
        {'code': 'T_TSEVAOT', 'KO': '만군 · 체바오트', 'EN': 'Hosts (tsevaot)',
         'move': [], 'new': [('HE', 'H6635', '체바오트', '만군 · 군대')],
         'alias_ko': ['만군의 여호와'], 'alias_en': ['Sabaoth', 'Tsevaot'],
         'desc_ko': NL.join([
             '만군으로 옮겨지는 이 낱말의 그림은 군대, 곧 줄지어 선 무리입니다. 낱말 자체는 사람의 군대와 군무에도 두루 쓰입니다.',
             '「만군의 여호와」라는 짝에서 하나님의 이름이 됩니다. 하늘의 별들과 천사들의 군대를 거느리시는 분이라는 고백으로, 사무엘서와 선지서가 즐겨 씁니다(삼상1:3, 사6:3).',
             '이 이름은 전쟁과 위기의 자리에서 특히 힘을 냅니다. 다윗이 골리앗 앞에서 「만군의 여호와의 이름으로 네게 가노라」(삼상17:45) 한 것이 그 표본입니다.']),
         'desc_en': NL.join([
             'The word rendered hosts pictures an army, ranks drawn up in order; the word itself also serves for human armies and service.',
             'In the pair "the LORD of hosts" it becomes a name of God, who commands the armies of heaven, beloved of Samuel and the prophets (1 Samuel 1:3; Isaiah 6:3).',
             'The name carries special weight in war and crisis: David met Goliath "in the name of the LORD of hosts" (1 Samuel 17:45).'])},
        {'code': 'T_EL', 'KO': '하나님 · 엘', 'EN': 'God (el)',
         'move': [], 'new': [('HE', 'H410', '엘', '하나님 · 뿌리는 힘')],
         'alias_ko': [], 'alias_en': ['El'],
         'desc_ko': NL.join([
             '하나님을 뜻하는 가장 짧고 오래된 낱말로, 뿌리 그림은 힘입니다. 셈족 여러 말이 함께 쓰던 신 이름이지만, 성경 안에서는 참 하나님을 부르는 자리에 굳게 섰습니다.',
             '홀로도 쓰이지만 조합에서 빛납니다. 엘 샤다이(전능의 하나님), 엘 엘욘(지극히 높으신 하나님, 창14:18), 엘 로이(감찰하시는 하나님, 창16:13), 임마누엘(하나님이 우리와 함께, 사7:14).',
             '시편이 이 이름을 즐겨 씁니다. 「하나님이여 주는 나의 하나님이시라」 같은 부름의 짧은 호흡에 이 낱말이 어울리기 때문입니다.',
             '이사야 9장 6절이 오실 아기를 「전능하신 하나님(엘 깁보르)」이라 부릅니다. 가장 오래된 이름이 마지막 약속에까지 이어집니다.']),
         'desc_en': NL.join([
             'The shortest and oldest word for God, rooted in the picture of strength. Though shared across the Semitic languages, within Scripture it stands firmly for the true God.',
             'It appears alone but shines in combinations: El Shaddai (God Almighty), El Elyon (God Most High, Genesis 14:18), El Roi (the God who sees, Genesis 16:13), Immanuel (God with us, Isaiah 7:14).',
             'The Psalms love this name; its short breath suits the cry "O God, thou art my God."',
             'Isaiah 9:6 names the coming child "the mighty God" (El Gibbor): the oldest name carried into the last promise.'])},
        {'code': 'P_SATAN', 'KO': '사탄 · 마귀', 'EN': 'Satan · the Devil',
         'etype': 'PERSON', 'move': [],
         'new': [('HE', 'H7854', '사탄', '대적자 · 참소하는 자'),
                 ('EL', 'G4567', '사타나스', '사탄 (신약)'),
                 ('EL', 'G1228', '디아볼로스', '마귀 · 비방하는 자')],
         'alias_ko': ['사단', '마귀', '대적자'], 'alias_en': ['Devil', 'Satan'],
         'desc_ko': NL.join([
             '사탄으로 옮겨지는 히브리어의 그림은 대적자, 곧 맞서서 고발하는 자입니다. 개역한글은 사단으로 적습니다. 욥기 1~2장과 스가랴 3장에서 하나님 앞에서 성도를 참소하는 자로 나옵니다.',
             '신약의 사타나스는 그 이름을 그대로 받았고, 마귀로 옮겨지는 디아볼로스는 비방하는 자라는 뜻입니다. 두 이름이 같은 존재를 가리킵니다. 「큰 용이 내어쫓기니 옛 뱀 곧 마귀라고도 하고 사단이라고도 하는 온 천하를 꾀는 자라」(계12:9).',
             '광야에서 예수님을 시험하고(마4장), 성도를 밤낮 참소하다가(계12:10), 마침내 불못에 던져집니다(계20:10).',
             '성경은 그를 두려워하라 하지 않고 대적하라 합니다. 「마귀를 대적하라 그리하면 너희를 피하리라」(약4:7).']),
         'desc_en': NL.join([
             'The Hebrew rendered Satan pictures the adversary, the one who stands against and accuses. In Job 1-2 and Zechariah 3 he accuses the saints before God.',
             'New Testament Satanas carries the name over, and diabolos, rendered devil, means the slanderer. The two names point to one being: "that old serpent, called the Devil, and Satan" (Revelation 12:9).',
             'He tempts Jesus in the wilderness (Matthew 4), accuses the brethren day and night (Revelation 12:10), and is cast at last into the lake of fire (Revelation 20:10).',
             'Scripture bids us not fear but resist him: "Resist the devil, and he will flee from you" (James 4:7).'])},
    ],
    'members': ['T_ELOHIM', 'T_YHWH', 'T_ADONAI', 'T_SHADDAI', 'T_TSEVAOT', 'T_EL'],
}


# ──────────────────────────────────────────────────────────────────────
# 셋째 초안 — 악의 낱말 가족 (2026-09-03 185차 · 1차 승격 배치).
# 측정(용어명부 표): 라아 623(악 63%·재앙 16%) · 라샤 248(악인 95%)+레샤 29 ·
# 아웬 79(악 41%·죄악 37% — 결은 허망·우상) · 아말 54(수고 48%) ·
# **아바르 493 은 보류**(지나/건너 일반 동사 — 측정 게이트가 막음).
# 승격 방식 = promote(자리 승격 — W_ 번호 보존, Girdlestone 연결 유지).
DRAFT_EVIL = {
    'field': {
        'code': 'F_EVIL', 'subtype': 'FIELD',
        'KO': '악의 낱말 가족', 'EN': 'The Evil Word Family',
        'desc_ko': NL.join([
            '성경은 악을 한 낱말로 말하지 않습니다. 죄가 하나님 앞에서 어긋난 자리를 가리킨다면, 악의 낱말들은 그 어긋남의 성질과 열매를 그립니다.',
            '나쁨과 재앙을 한 낱말로 덮는 라아(악), 악을 삶의 길로 삼은 사람 라샤(악인), 속이 빈 헛것과 우상을 그리는 아웬(허망), 죄가 낳는 짐스러운 해악 아말(수고)입니다.',
            '「여호와께서 사람의 죄악이 세상에 관영함과 그 마음의 생각의 모든 계획이 항상 악할 뿐임을 보시고」(창6:5)에서 악이 마음의 계획에까지 스민 것을 보시고, 시편 제 1편은 악인의 길과 의인의 길을 갈라 세웁니다.',
            '죄의 낱말 가족과 나란히 읽으십시오. 죄가 어긋남 그 자체라면, 악은 그 어긋남이 세상에 내는 맛과 무게입니다.']),
        'desc_en': NL.join([
            'Scripture does not speak of evil with one word. Where the sin words name the breach before God, the evil words picture its character and fruit.',
            'Ra covers both badness and calamity; rasha names the person who has made evil his way; aven pictures hollow nothingness and idols; amal, the burdensome toil that wrong brings forth.',
            'Genesis 6:5 sees evil soaked into every intent of the heart, and Psalm 1 sets the way of the wicked against the way of the righteous.',
            'Read this family beside the sin words: sin is the breach itself; evil is the taste and weight that breach leaves in the world.']),
    },
    'words': [
        {'code': 'T_RAAH', 'KO': '악 · 라아', 'EN': 'Evil (ra)',
         'promote': 'W_H7451', 'move': [], 'new': [],
         'alias_ko': ['재앙'], 'alias_en': ['Ra', 'Raah'],
         'desc_ko': NL.join([
             '악으로 옮겨지는 이 낱말은 구약에서 가장 넓은 악의 낱말입니다. 도덕의 나쁨과 삶에 닥치는 재앙을 한 낱말로 덮습니다.',
             '「그 마음의 생각의 모든 계획이 항상 악할 뿐임을 보시고」(창6:5)가 도덕의 결이라면, 「나는 평안도 짓고 환난도 창조하나니」(사45:7)의 환난은 재앙의 결입니다. 같은 낱말입니다.',
             '그래서 이 낱말은 악이 어디서 오는가를 묻게 만듭니다. 성경은 하나님이 재앙을 심판의 도구로 쓰신다고 말하면서도, 도덕의 악은 언제나 사람의 마음에서 나온다고 말합니다(막7:21의 정신과 같은 결).',
             '토브(좋다·선)의 맞은편에 서는 낱말입니다. 에덴의 「선악을 알게 하는 나무」에서 두 낱말이 처음부터 짝으로 나옵니다.']),
         'desc_en': NL.join([
             'The broadest Old Testament word for evil, covering both moral badness and the calamity that falls on a life.',
             '"Every imagination of the thoughts of his heart was only evil continually" (Genesis 6:5) is its moral grain; "I make peace, and create evil" (Isaiah 45:7) is its grain of calamity. One word carries both.',
             'So the word presses the question where evil comes from. Scripture lets God wield calamity as judgment, yet always traces moral evil to the human heart.',
             'It stands opposite tov (good): the two are paired from the beginning in the tree of the knowledge of good and evil.'])},
        {'code': 'T_RASHA', 'KO': '악인 · 라샤', 'EN': 'The Wicked (rasha)',
         'promote': 'W_H7562', 'move': [('W_H7563', 'H7563')], 'new': [],
         'alias_ko': ['악한 자'], 'alias_en': ['Rasha'],
         'desc_ko': NL.join([
             '악인으로 옮겨지는 이 낱말은 악을 한 번 저지른 사람이 아니라 악을 길로 삼은 사람을 가리킵니다. 시편과 잠언이 의인의 맞은편에 세우는 그 사람입니다.',
             '「복 있는 사람은 악인의 꾀를 좇지 아니하며」(시1:1). 시편 제 1편이 이 낱말로 두 길을 엽니다.',
             '그런데 성경은 악인의 멸망을 고소해하지 않습니다. 「내가 어찌 악인의 죽는 것을 조금인들 기뻐하랴」(겔18:23). 하나님은 그가 돌이켜 사는 것을 기뻐하십니다.',
             '같은 뿌리의 명사 레샤는 그 사람됨이 내는 악 자체를 가리킵니다. 한 항목에서 함께 다룹니다.']),
         'desc_en': NL.join([
             'The word rendered the wicked names not one who has done an evil deed but one who has made evil his way: the figure Psalms and Proverbs set opposite the righteous.',
             '"Blessed is the man that walketh not in the counsel of the ungodly" (Psalm 1:1): the first Psalm opens the two ways with this word.',
             'Yet Scripture takes no pleasure in his ruin: "Have I any pleasure at all that the wicked should die?" (Ezekiel 18:23). God delights that he turn and live.',
             'The cognate noun resha names the wickedness such a person produces; the two are kept in one entry.'])},
        {'code': 'T_AVEN', 'KO': '허망 · 아웬', 'EN': 'Naught (aven)',
         'promote': 'W_H205', 'move': [], 'new': [],
         'alias_ko': ['죄악'], 'alias_en': ['Aven'],
         'desc_ko': NL.join([
             '이 낱말의 그림은 속이 빈 것, 곧 헛것입니다. 개역한글은 문맥을 따라 악과 죄악으로 자주 옮기지만, 낱말의 결은 힘없고 실체 없는 허망입니다.',
             '그래서 우상 숭배의 낱말이 됩니다. 호세아는 금송아지가 선 벧엘(하나님의 집)을 벧아웬(헛것의 집)이라 바꿔 부릅니다(호4:15).',
             '시편의 굳은 표현 「죄악을 행하는 자들」이 이 낱말입니다. 헛것을 지어내는 자들이라는 그림이 그 안에 있습니다.',
             '아온(죄악·굽음)과 소리가 비슷하지만 다른 낱말입니다. 아온이 굽어 뒤틀린 상태라면, 아웬은 속이 빈 헛됨입니다.']),
         'desc_en': NL.join([
             'The picture in this word is hollowness: a thing with nothing inside. The Korean Bible often renders it evil or iniquity by context, but its grain is powerless, substanceless naught.',
             'Hence it becomes an idolatry word: Hosea renames Bethel, house of God, Beth-aven, house of naught, once the calf stands there (Hosea 4:15).',
             'The fixed psalm phrase "workers of iniquity" carries this word: makers of empty things.',
             'It sounds like avon (iniquity, crookedness) but differs: avon is a state bent out of line; aven is emptiness with nothing in it.'])},
        {'code': 'T_AMAL', 'KO': '수고 · 아말', 'EN': 'Toil (amal)',
         'promote': 'W_H5999', 'move': [], 'new': [],
         'alias_ko': ['잔해'], 'alias_en': ['Amal'],
         'desc_ko': NL.join([
             '수고로 옮겨지는 이 낱말의 그림은 짐스러운 고생, 무겁고 지치게 하는 노고입니다.',
             '전도서의 열쇠 낱말입니다. 「사람이 해 아래서 수고하는 모든 수고가 자기에게 무엇이 유익한고」(전1:3). 시편 90편도 인생의 날을 「수고와 슬픔뿐」이라 합니다(시90:10).',
             '그런데 이 낱말은 남에게 끼치는 해악에도 쓰입니다. 「악인이 죄악을 해산함이여 잔해를 잉태하며 궤휼을 낳았도다」(시7:14)의 잔해가 이 낱말입니다. 제가 낳은 고생이 남의 짐이 되는 그림입니다.',
             '악의 가족에서 이 낱말은 결과의 자리를 맡습니다. 어긋남이 세상에 내는 무게와 아픔입니다.']),
         'desc_en': NL.join([
             'The word rendered toil pictures burdensome labour: heavy, wearying trouble.',
             'It is the key word of Ecclesiastes: "What profit hath a man of all his labour which he taketh under the sun?" (Ecclesiastes 1:3). Psalm 90 calls the strength of our years "labour and sorrow."',
             'Yet the word also serves for the harm one deals to others: the "mischief" the wicked conceives in Psalm 7:14 is this word — trouble of my own making that becomes another\'s burden.',
             'In the evil family this word holds the place of consequence: the weight and ache that wrong leaves in the world.'])},
    ],
    'members': ['T_RAAH', 'T_RASHA', 'T_AVEN', 'T_AMAL'],
}

# ──────────────────────────────────────────────────────────────────────
# 넷째 초안 — 사람의 낱말 가족 (2026-09-03 186차 · 2차 승격 배치).
# 수요 신호 = Girdlestone III장 「The Names of Man」 문헌연결(W_ 3건 대기).
# 측정(개역한글 옮김새): 아담 H120 526절(사람 63%·인생 9%) · 이쉬 H376
# 1,851절(사람 56% · 각기7·남편4·남자2 — **대응 분산형**: 한 뜻 「개인」의
# 여러 대응) · 에노쉬 H582 41절(사람 66%·인생 27%) · 게베르 H1397 64절
# (사람 42%·남자 14%·「~하는 자」 12% — 무일치 표본 전수 확인 = 전부 사내 결).
# 이름은 아웬 선례(변별 우선): 에노쉬 「인생」 · 게베르 「장정」.
DRAFT_MAN = {
    'field': {
        'code': 'F_MAN', 'subtype': 'FIELD',
        'KO': '사람의 낱말 가족', 'EN': 'The Words for Man',
        'desc_ko': NL.join([
            '성경은 사람을 네 낱말로 부릅니다. 어느 낱말을 골랐는가가 그 자리에서 사람의 어떤 면을 보고 있는가를 말해 줍니다.',
            '흙에서 지어진 인류 아담(사람), 상대와의 관계 속에 선 개인 이쉬(사람·남편), 연약하여 죽을 수밖에 없는 에노쉬(인생), 힘 있는 사내 게베르(장정)입니다.',
            '「여호와 하나님이 흙으로 사람을 지으시고 생기를 그 코에 불어넣으시니」(창2:7)의 사람이 아담이고, 「사람이 무엇이관대 주께서 저를 생각하시며」(시8:4)의 사람이 에노쉬입니다. 같은 「사람」이라도 원어가 다른 것을 보고 있습니다.',
            '하나님의 이름 가족이 하나님을 여러 이름으로 부르듯, 사람의 낱말들도 저마다 다른 결을 담습니다. 사람의 존엄과 연약이 이 네 낱말 사이에서 함께 읽힙니다.']),
        'desc_en': NL.join([
            'Scripture calls man by four words, and the choice tells what side of man is in view.',
            'Adam, mankind formed from the ground; ish, the individual standing in relation — husband before wife, each before neighbour; enosh, man frail and mortal; gever, man in his strength.',
            'The man formed of dust in Genesis 2:7 is adam; the man God is mindful of in Psalm 8:4 is enosh. The same English word hides a different Hebrew choice.',
            'As the divine-name family calls God by many names, these words each carry their own grain: the dignity and the frailty of man are read together across them.']),
    },
    'words': [
        {'code': 'T_ADAM', 'KO': '사람 · 아담', 'EN': 'Man (adam)',
         'promote': 'W_H120', 'move': [], 'new': [],
         'alias_ko': ['인류'], 'alias_en': ['Adam'],
         'desc_ko': NL.join([
             '사람으로 옮겨지는 이 낱말은 개인이 아니라 인류를 가리키는 가장 넓은 사람 낱말입니다. 첫 사람의 이름 아담이 곧 이 낱말입니다.',
             '흙(아다마)과 소리를 나눕니다. 「여호와 하나님이 흙으로 사람을 지으시고 생기를 그 코에 불어넣으시니」(창2:7). 흙에서 온 존재라는 그림이 이름 안에 들어 있습니다.',
             '그래서 이 낱말은 하나님의 형상과 흙의 연약함을 한 몸에 담습니다. 위로는 형상을 받았고 아래로는 흙에서 왔습니다.',
             '인물 아담과 낱말 아담은 한 뿌리입니다. 첫 사람의 이야기가 곧 모든 사람의 이야기라는 것을 히브리어가 이름으로 말합니다.']),
         'desc_en': NL.join([
             'The broadest word for man, naming not the individual but mankind. The name of the first man is this very word.',
             'It shares its sound with the ground (adamah): the man formed of dust in Genesis 2:7 carries his origin in his name.',
             'So the word holds together the image of God and the frailty of dust — made in the image, taken from the ground.',
             'The person Adam and the word adam are one root: the story of the first man is the story of every man.'])},
        {'code': 'T_ISH', 'KO': '사람 · 남편 · 이쉬', 'EN': 'Man, Husband (ish)',
         'promote': 'W_H376', 'move': [], 'new': [],
         'alias_ko': ['남자'], 'alias_en': ['Ish'],
         'desc_ko': NL.join([
             '사람으로 가장 자주 옮겨지는 이 낱말은 인류가 아니라 개인을 가리킵니다. 아내 앞의 남편, 이웃 앞의 각 사람처럼 상대가 있는 자리에서 쓰입니다.',
             '여자(이샤)와 짝을 이루는 낱말입니다. 「이것을 남자에게서 취하였은즉 여자라 칭하리라」(창2:23). 남자와 여자가 낱말부터 짝입니다.',
             '「복 있는 사람은 악인의 꾀를 좇지 아니하며」(시1:1)의 사람이 이 낱말입니다. 무리가 아니라 길을 스스로 선택하는 한 사람입니다.',
             '개역한글이 각기·각각으로 옮기는 자리도 이 낱말입니다. 저마다 하나씩이라는 개인의 결이 거기서도 보입니다.']),
         'desc_en': NL.join([
             'The most frequent word for man, naming not mankind but the individual — man where he stands in relation: husband before wife, each before his neighbour.',
             'It pairs with woman (ishshah): "she shall be called Woman, because she was taken out of Man" (Genesis 2:23) — man and woman are paired from the word up.',
             'The blessed man of Psalm 1:1 is this word: not a crowd but one person choosing his way.',
             'Where the Korean Bible renders "each" or "every one," this word stands — the grain of one-by-one individuality.'])},
        {'code': 'T_ENOSH', 'KO': '인생 · 에노쉬', 'EN': 'Mortal Man (enosh)',
         'promote': 'W_H582', 'move': [], 'new': [],
         'alias_ko': [], 'alias_en': ['Enosh'],
         'desc_ko': NL.join([
             '인생으로 자주 옮겨지는 이 낱말은 연약하여 죽을 수밖에 없는 존재로서의 사람을 그립니다.',
             '「사람이 무엇이관대 주께서 저를 생각하시며 인자가 무엇이관대 주께서 저를 권고하시나이까」(시8:4)의 사람이 이 낱말입니다. 광대한 하늘 아래 작은 존재가 오히려 돌보심을 받는 놀라움이 이 낱말 위에 서 있습니다.',
             '시들고 지나가고 흙으로 돌아가는 존재를 말하는 자리에서 즐겨 쓰이는 낱말입니다. 그래서 겸손의 낱말입니다.',
             '아담이 흙에서 온 인류라면 에노쉬는 그 인류의 연약함을 정면으로 부르는 이름입니다.']),
         'desc_en': NL.join([
             'Often rendered "mortal man" or "frail man," this word pictures man as weak and bound to die.',
             '"What is man, that thou art mindful of him?" (Psalm 8:4) — the wonder that so small a being under so vast a sky is cared for stands on this word.',
             'It is the word of choice where Scripture speaks of man fading, passing, returning to dust — a word of humility.',
             'If adam is mankind from the ground, enosh names that mankind in its frailty, face on.'])},
        {'code': 'T_GEBER', 'KO': '장정 · 게베르', 'EN': 'Mighty Man (geber)',
         'promote': 'W_H1397', 'move': [], 'new': [],
         'alias_ko': ['대장부'], 'alias_en': ['Geber'],
         'desc_ko': NL.join([
             '장정으로 옮길 수 있는 이 낱말은 힘 있는 사내, 한창때의 남자를 가리킵니다. 힘과 용맹의 뿌리에서 왔습니다.',
             '「너는 대장부처럼 허리를 묶고 내가 네게 묻는 것을 대답할지니라」(욥38:3). 하나님이 욥을 부르실 때 쓰신 낱말이 이것입니다.',
             '「여호와의 노하신 매로 인하여 고난당한 자는 내로다」(애3:1)의 자도 이 낱말입니다. 힘 있는 사내가 꺾이는 자리에서 이 낱말이 선택해지면 그 대비가 말을 합니다.',
             '에노쉬가 사람의 연약을 정면으로 본다면 게베르는 사람의 힘을 봅니다. 그리고 성경은 그 힘도 하나님 앞에서는 자랑이 못 됨을 같은 낱말로 보입니다.']),
         'desc_en': NL.join([
             'The word for man in his strength — the able-bodied man in his prime, from a root of might.',
             '"Gird up now thy loins like a man; for I will demand of thee, and answer thou me" (Job 38:3) — the word God chose when he summoned Job.',
             'It is also the word of Lamentations 3:1, "I am the man that hath seen affliction": when the strong man is the one broken, the choice of word does the talking.',
             'Where enosh looks straight at human frailty, gever looks at human strength — and Scripture shows, with the same word, that this strength too is no boast before God.'])},
    ],
    'members': ['T_ADAM', 'T_ISH', 'T_ENOSH', 'T_GEBER'],
}

# ──────────────────────────────────────────────────────────────────────
# 다섯째 초안 — 죽음의 낱말 가족 (2026-09-03 186차 · 3차 승격 배치).
# 수요 신호 = Girdlestone XXIV장 문헌연결(W_H7585 대기) + D_HEAVEN/D_HELL
# 의미장 빈칸. 측정(개역한글 옮김새): 스올 H7585 64절(음부 97%) · 마베트
# H4194 153절(사망 32%+죽음 계열 ~74% — 대응 분산형 · 무일치 표본 전수 확인 =
# 죽는/돌아가시) · 무트 H4191 695절(죽 96% — 같은 뿌리 동사, 라샤 선례로
# 흡수) · 케베르 H6913 62절(묘 50%·무덤 39%·장사 34%) · 아바돈 H11 5절
# (멸망 80%·유명 20%).
# 두 언어 한 몸 판정(LXX 다리 실측): 마베트→타나토스 71.4% 1위 ·
# 스올→하데스 75.0% 1위 — 「동일 의미가 확실할 때에만 하나」 조건 충족.
DRAFT_DEATH = {
    'field': {
        'code': 'F_DEATH', 'subtype': 'FIELD',
        'KO': '죽음의 낱말 가족', 'EN': 'The Death Word Family',
        'desc_ko': NL.join([
            '성경이 죽음을 말하는 낱말들입니다. 죽음 그 자체(마베트·타나토스), 죽은 자들이 내려가는 음부(스올·하데스), 몸이 눕는 무덤(케베르), 삼키는 멸망의 자리(아바돈)가 저마다 다른 자리를 맡습니다.',
            '「사망아 네 재앙이 어디 있느냐 음부야 네 멸망이 어디 있느냐」(호13:14). 사망과 음부가 나란히 불리고, 바울이 부활 장에서 이 노래를 받아 부릅니다.',
            '신약도 같은 짝으로 끝을 맺습니다. 「사망과 음부도 불못에 던지우니」(계20:14). 죽음의 낱말들은 마지막에 함께 폐하여집니다.',
            '이 가족은 죽음을 미화하지도 얼버무리지도 않습니다. 낱말마다 죽음의 다른 얼굴을 정직하게 부르고, 그 모든 얼굴 위에 부활의 소망이 서 있습니다.']),
        'desc_en': NL.join([
            'The words Scripture uses for death: death itself (mavet, thanatos), the place of the dead (sheol, hades), the grave where the body lies (qeber), and the devouring place of ruin (abaddon). Each keeps its own post.',
            '"O death, where are thy plagues? O grave, where is thy destruction?" (Hosea 13:14). Death and sheol are summoned side by side, and Paul takes up the taunt in the resurrection chapter.',
            'The New Testament closes with the same pair: "death and hades were cast into the lake of fire" (Revelation 20:14). The death words are abolished together.',
            'This family neither prettifies death nor mumbles about it. Each word names another face of death honestly, and over every face stands the hope of resurrection.']),
    },
    'words': [
        {'code': 'T_MAVET', 'KO': '사망 · 마베트 · 타나토스',
         'EN': 'Death (mavet / thanatos)',
         'promote': 'W_H4194',
         'move': [('W_H4191', 'H4191'), ('W_G2288', 'G2288'),
                  ('W_G599', 'G599')],
         'new': [],
         'alias_ko': ['죽음'], 'alias_en': ['Mavet', 'Thanatos'],
         'desc_ko': NL.join([
             '사망으로 자주 옮겨지는 이 낱말은 죽음 그 자체를 가리키는 명사입니다. 같은 뿌리의 동사(무트, 죽다)와 헬라어 타나토스, 그 동사 아포드네스코까지 한 항목에서 함께 다룹니다.',
             '「네가 먹는 날에는 정녕 죽으리라」(창2:17). 성경에서 죽음은 자연의 순리이기 전에 죄의 삯으로 들어온 것입니다.',
             '그래서 죽음은 마지막까지 원수라 불립니다. 「맨 나중에 멸망받을 원수는 사망이니라」(고전15:26). 성경은 죽음과 화해하지 않고 죽음의 폐지를 기다립니다.',
             '「사망과 음부도 불못에 던지우니 이것은 둘째 사망 곧 불못이라」(계20:14). 첫째 사망이 끝이 아니며, 둘째 사망을 피하는 길이 복음의 핵심입니다.']),
         'desc_en': NL.join([
             'The noun for death itself. The cognate verb muth (to die), the Greek thanatos, and its verb apothnesko are kept in this one entry.',
             '"In the day that thou eatest thereof thou shalt surely die" (Genesis 2:17): in Scripture death enters as the wages of sin before it is ever the course of nature.',
             'So death is called an enemy to the last: "The last enemy that shall be destroyed is death" (1 Corinthians 15:26). Scripture makes no peace with death; it waits for its abolition.',
             '"Death and hades were cast into the lake of fire. This is the second death" (Revelation 20:14): the first death is not the end, and escaping the second is the heart of the gospel.'])},
        {'code': 'T_SHEOL', 'KO': '음부 · 스올 · 하데스',
         'EN': 'Sheol / Hades',
         'promote': 'W_H7585',
         'move': [('W_G86', 'G86')],
         'new': [],
         'alias_ko': ['스올'], 'alias_en': ['Sheol', 'Hades'],
         'desc_ko': NL.join([
             '음부로 옮겨지는 이 낱말은 죽은 자들이 내려가는 자리를 가리킵니다. 70인역이 하데스로 옮겼고 신약이 그 낱말을 그대로 받았으므로 한 항목에서 함께 다룹니다.',
             '「사망 중에서는 주를 기억함이 없사오니 음부에서 주께 감사할 자 누구리이까」(시6:5). 구약의 기도는 음부를 찬양이 끊어지는 자리로 봅니다.',
             '그러나 같은 시편이 그 너머를 봅니다. 「내 영혼을 음부에 버리지 아니하시며 주의 거룩한 자로 썩지 않게 하실 것임이니이다」(시16:10). 사도들은 이 노래를 그리스도의 부활로 읽었습니다.',
             '지옥(게헨나)과는 다른 낱말입니다. 스올은 죽은 자들의 자리이고 최후 심판의 불은 다른 낱말이 맡습니다. 개역한글의 음부라는 옮김이 그 구별을 지켜 줍니다.']),
         'desc_en': NL.join([
             'The word for the place to which the dead go down. The Septuagint rendered it hades and the New Testament took that word over, so the two are kept in one entry.',
             '"In death there is no remembrance of thee: in sheol who shall give thee thanks?" (Psalm 6:5). The Old Testament prayers see it as the place where praise falls silent.',
             'Yet the same Psalter looks beyond it: "Thou wilt not leave my soul in sheol; neither wilt thou suffer thine Holy One to see corruption" (Psalm 16:10). The apostles read that song of the resurrection of Christ.',
             'It is not the word for hell (gehenna): sheol is the place of the dead, and the fire of final judgment belongs to another word. The rendering "the grave / the pit" keeps that distinction.'])},
        {'code': 'T_QEBER', 'KO': '무덤 · 케베르', 'EN': 'Grave (qeber)',
         'promote': 'W_H6913', 'move': [], 'new': [],
         'alias_ko': ['묘'], 'alias_en': ['Qeber'],
         'desc_ko': NL.join([
             '무덤과 묘로 옮겨지는 이 낱말은 몸이 눕는 자리를 가리킵니다. 스올이 보이지 않는 저편이라면 케베르는 손으로 팔 수 있는 이편의 자리입니다.',
             '족장들의 이야기는 무덤 사는 일에서 시작합니다. 아브라함이 가나안에서 처음 산 땅이 막벨라 굴 곧 매장지였습니다. 약속의 땅에서 처음 가진 것이 무덤이었다는 사실이 소망의 씨앗처럼 남습니다.',
             '「오늘까지 그 묘를 아는 자 없으니라」(신34:6). 모세의 무덤은 감추어졌고, 성경은 무덤을 숭배의 자리로 만들지 않습니다.',
             '복음서가 빈 무덤에서 절정에 이르는 것도 이 자리에서 읽으면 선명합니다. 무덤은 끝이 아니라 열릴 수 있는 문이 되었습니다.']),
         'desc_en': NL.join([
             'The word for the grave where the body lies. If sheol is the unseen far side, qeber is the near side a hand can dig.',
             'The patriarchal story begins with the buying of a grave: the first ground Abraham owned in Canaan was the cave of Machpelah, a burial plot. That his first holding in the land of promise was a grave remains like a seed of hope.',
             '"No man knoweth of his sepulchre unto this day" (Deuteronomy 34:6): the grave of Moses was hidden, and Scripture never lets the tomb become a shrine.',
             'Read from this word, the climax of the Gospels at an empty tomb stands out sharply: the grave has become not an end but a door that can open.'])},
        {'code': 'T_ABADDON', 'KO': '멸망 · 아바돈', 'EN': 'Abaddon',
         'move': [],
         'new': [('HE', 'H11', '아바돈', 'destruction'),
                 ('EL', 'G3', '아바돈', 'Abaddon')],
         'alias_ko': ['유명'], 'alias_en': ['Abaddon', 'Apollyon'],
         'desc_ko': NL.join([
             '멸망으로 옮겨지는 이 낱말은 삼켜 없애는 파멸의 자리를 가리키는 이름입니다. 욥기와 잠언의 지혜문학이 음부와 짝으로 부릅니다.',
             '「음부와 유명은 만족함이 없고 사람의 눈도 만족함이 없느니라」(잠27:20). 개역한글의 유명이라는 옛 옮김이 이 낱말입니다.',
             '「하나님 앞에는 음부도 드러나며 멸망의 웅덩이도 가리움이 없음이니라」(욥26:6). 멸망의 자리조차 하나님 앞에서는 벌거벗은 듯 드러납니다.',
             '신약에 딱 한 번, 이름으로 나옵니다. 「히브리 음으로 이름은 아바돈이요 헬라 음으로 이름은 아볼루온이더라」(계9:11). 무저갱의 사자의 이름이 곧 멸망입니다.']),
         'desc_en': NL.join([
             'A name for the place of devouring ruin. The wisdom books pair it with sheol.',
             '"Hell and destruction are never full; so the eyes of man are never satisfied" (Proverbs 27:20): the old rendering "destruction" is this word.',
             '"Hell is naked before him, and destruction hath no covering" (Job 26:6): even the place of ruin lies bare before God.',
             'Once in the New Testament it appears as a name: "in the Hebrew tongue Abaddon, but in the Greek tongue Apollyon" (Revelation 9:11) — the angel of the abyss is named Destruction itself.'])},
    ],
    'members': ['T_MAVET', 'T_SHEOL', 'T_QEBER', 'T_ABADDON'],
}

# ──────────────────────────────────────────────────────────────────────
# 4차 승격 배치 (2026-09-03 189차) — 사랑·정결·의·말씀 가족 + 지존자 엘욘.
# 측정(개역한글 옮김새): 라함 43절(긍휼 79%) · 타헤르 80(정결+정하+깨끗 95%) ·
# 타메 142(더럽+부정 98%) · 야샤르 119(정직 71%) · 타밈 H8549 85(흠없+완전+
# 온전 83%) · 미츠바 177(명령+계명+명하+법 — 대응 분산형) · 엘욘 53(지존+
# 지극히높 58% · 무일치 42% = 「윗 문」류 형용사 용법 — 표본 전수 확인,
# 설명문이 가른다 = 체바오트 선례). **타맘 H8552 는 보류**(무일치 79% —
# 끝나다·소멸하다 일반 동사. Girdlestone VIII장 초안 열쇠는 T_TAMIM 으로 교정).
# 기존 용어를 가족 구성원으로 함께 잇는다(F_SIN 선례) — 새 표 0.
DRAFT_LOVE = {
    'field': {
        'code': 'F_LOVE', 'subtype': 'FIELD',
        'KO': '사랑의 낱말 가족', 'EN': 'The Love Word Family',
        'desc_ko': NL.join([
            '성경이 사랑을 말하는 낱말들입니다. 뜻을 정해 선택하는 사랑 아하브, 언약에 매인 한결같은 사랑 헤세드(인애), 태에서 난 자식을 향한 몸 깊은 사랑 라함(긍휼)이 저마다 다른 결을 맡습니다.',
            '아하브가 선택하는 사랑이라면, 헤세드는 맺은 언약을 끝까지 지키는 사랑이고, 라함은 어미의 창자가 움직이는 사랑입니다.',
            '「아비가 자식을 불쌍히 여김같이 여호와께서 자기를 경외하는 자를 불쌍히 여기시나니」(시103:13). 시편은 이 낱말들을 한 하나님의 사랑 안에서 번갈아 부릅니다.',
            '신약의 아가페는 이 세 갈래를 한 몸에 받았습니다. 십자가에서 고르시고, 끝까지 지키시고, 아파하시는 사랑입니다.']),
        'desc_en': NL.join([
            'The words Scripture uses for love: ahav, love that chooses; hesed, steadfast love bound to covenant; racham, the deep bodily compassion of a mother for the child of her womb.',
            'Ahav elects, hesed keeps faith to the end, racham is love felt in the depths.',
            '"Like as a father pitieth his children, so the LORD pitieth them that fear him" (Psalm 103:13): the Psalms call on these words in turn within the one love of God.',
            'The agape of the New Testament inherits all three strands: love that chooses at the cross, keeps to the end, and suffers with us.']),
    },
    'words': [
        {'code': 'T_RACHAM', 'KO': '긍휼 · 라함', 'EN': 'Compassion (racham)',
         'promote': 'W_H7355', 'move': [], 'new': [],
         'alias_ko': ['자비'], 'alias_en': ['Racham'],
         'desc_ko': NL.join([
             '긍휼로 옮겨지는 이 낱말은 태를 가리키는 낱말과 한 뿌리입니다. 어미가 자기 태에서 난 자식에게 갖는, 몸 깊은 곳이 움직이는 사랑입니다.',
             '「여인이 어찌 그 젖 먹는 자식을 잊겠으며 자기 태에서 난 아들을 긍휼히 여기지 않겠느냐 그들은 혹시 잊을지라도 나는 너를 잊지 아니할 것이라」(사49:15). 하나님은 당신의 긍휼을 어미의 사랑에 견주시고, 그보다 크다 하십니다.',
             '호세아는 이 낱말로 복음을 미리 보여 줍니다. 「긍휼히 여김을 받지 못하였던 자를 긍휼히 여기며」(호2:23). 버림받았던 자가 다시 품에 안기는 이야기입니다.',
             '헤세드가 언약을 지키는 사랑이라면 라함은 창자가 움직이는 사랑입니다. 복음서가 예수님을 두고 자주 쓰는 「민망히 여기사」가 이 결을 잇습니다.']),
         'desc_en': NL.join([
             'The word rendered compassion shares its root with the word for womb: the love a mother has for the child of her own body, felt in the depths.',
             '"Can a woman forget her sucking child, that she should not have compassion on the son of her womb? yea, they may forget, yet will I not forget thee" (Isaiah 49:15). God compares his compassion to a mother\'s and calls it greater.',
             'Hosea preaches the gospel in advance with this word: "I will have mercy upon her that had not obtained mercy" (Hosea 2:23) — the cast-off gathered back into the arms.',
             'Where hesed keeps covenant, racham is love that moves the inward parts; the Gospels\' "moved with compassion" over Jesus carries this grain.'])},
    ],
    'members': ['T_AHAV', 'T_HESED', 'T_RACHAM'],
}

DRAFT_PURITY = {
    'field': {
        'code': 'F_PURITY', 'subtype': 'FIELD',
        'KO': '정결의 낱말 가족', 'EN': 'The Purity Word Family',
        'desc_ko': NL.join([
            '성경이 정결을 말하는 낱말들입니다. 하나님께 속하여 구별된 거룩(코데시), 깨끗하게 된 상태 타헤르(정결), 그 맞은편의 타메(부정)가 한 가족을 이룹니다.',
            '거룩과 정결은 다릅니다. 거룩이 누구에게 속했는가의 문제라면, 정결은 그 앞에 설 수 있는 상태인가의 문제입니다. 레위기가 이 두 축으로 짜여 있습니다.',
            '「우슬초로 나를 정결케 하소서 내가 정하리이다」(시51:7). 다윗은 제의의 낱말을 마음의 자리로 가져와 기도로 만들었습니다.',
            '「맑은 물로 너희에게 뿌려서 너희로 정결케 하되」(겔36:25). 정결은 마지막에 하나님이 친히 이루시겠다 약속하신 새 언약의 일입니다.']),
        'desc_en': NL.join([
            'The words of purity: qodesh, holiness as belonging to God; taher, the state of being made clean; and opposite them tame, uncleanness.',
            'Holiness and cleanness differ: holiness asks to whom a thing belongs, cleanness asks whether it may stand before him. Leviticus is built on these two axes.',
            '"Purge me with hyssop, and I shall be clean" (Psalm 51:7): David carries the ritual word into the heart and makes it a prayer.',
            '"Then will I sprinkle clean water upon you, and ye shall be clean" (Ezekiel 36:25): cleansing is finally a work God promises to do himself, a new covenant promise.']),
    },
    'words': [
        {'code': 'T_TAHER', 'KO': '정결 · 타헤르', 'EN': 'Clean (taher)',
         'promote': 'W_H2891', 'move': [], 'new': [],
         'alias_ko': ['깨끗'], 'alias_en': ['Taher'],
         'desc_ko': NL.join([
             '정결로 옮겨지는 이 낱말은 더러움이 씻겨 깨끗하게 된 상태를 가리킵니다. 나은 몸, 씻은 그릇, 제련된 금에 두루 쓰입니다.',
             '「우슬초로 나를 정결케 하소서 내가 정하리이다 나를 씻기소서 내가 눈보다 희리이다」(시51:7). 다윗의 참회가 이 낱말을 제의에서 마음으로 옮겼습니다.',
             '「맑은 물로 너희에게 뿌려서 너희로 정결케 하되 곧 너희 모든 더러운 것에서와 모든 우상을 섬김에서 너희를 정결케 할 것이며」(겔36:25). 스스로 씻을 수 없는 것을 하나님이 씻으십니다.',
             '부정(타메)의 맞은편에 서는 낱말입니다. 부정은 옮지만 정결은 저절로 옮지 않습니다. 그래서 정결케 하시는 분이 필요합니다.']),
         'desc_en': NL.join([
             'The word for being made clean: a healed body, a washed vessel, refined gold.',
             '"Purge me with hyssop, and I shall be clean: wash me, and I shall be whiter than snow" (Psalm 51:7). David\'s penitence moved the word from ritual into the heart.',
             '"Then will I sprinkle clean water upon you... from all your filthiness, and from all your idols, will I cleanse you" (Ezekiel 36:25): what cannot wash itself, God washes.',
             'It stands opposite tame (unclean). Uncleanness spreads by touch; cleanness does not. Hence the need for One who cleanses.'])},
        {'code': 'T_TAME', 'KO': '부정 · 타메', 'EN': 'Unclean (tame)',
         'promote': 'W_H2930', 'move': [], 'new': [],
         'alias_ko': ['더러움'], 'alias_en': ['Tame'],
         'desc_ko': NL.join([
             '부정으로 옮겨지는 이 낱말은 하나님 앞에 나아갈 수 없게 만드는 더러움을 가리킵니다. 시체와 병과 부정한 짐승이 그 대표입니다.',
             '부정의 무서움은 옮는다는 데 있습니다. 부정한 것이 닿으면 깨끗하던 것이 부정해지고, 그 반대는 일어나지 않습니다. 레위기의 규례들이 그 방향을 가르칩니다.',
             '「화로다 나여 망하게 되었도다 나는 입술이 부정한 사람이요」(사6:5). 거룩하신 분 앞에서 사람이 처음 아는 것이 자기의 부정입니다.',
             '그래서 복음서의 한 장면이 놀랍습니다. 예수님이 문둥병자에게 손을 대시자 부정이 옮는 대신 깨끗함이 옮았습니다. 방향이 뒤집힌 것입니다.']),
         'desc_en': NL.join([
             'The word for the defilement that bars approach to God: corpse, disease, unclean beast.',
             'Its terror is that it spreads. The unclean defiles the clean by touch, never the reverse; the rules of Leviticus teach that direction.',
             '"Woe is me! for I am undone; because I am a man of unclean lips" (Isaiah 6:5): before the Holy One, the first thing a man knows is his own uncleanness.',
             'Hence the wonder of the Gospel scene: Jesus touches the leper, and instead of uncleanness spreading, cleanness does. The direction is reversed.'])},
    ],
    'members': ['T_KADOSH', 'T_TAHER', 'T_TAME'],
}

DRAFT_RIGHT = {
    'field': {
        'code': 'F_RIGHTEOUS', 'subtype': 'FIELD',
        'KO': '의의 낱말 가족', 'EN': 'The Righteousness Word Family',
        'desc_ko': NL.join([
            '성경이 바르게 사는 것을 말하는 낱말들입니다. 기준에 맞음 체데크(의), 바르게 판단함 미슈파트(공의), 흔들리지 않는 견고함 에메트(진실), 굽지 않고 곧음 야샤르(정직), 흠 없이 온전함 타밈이 서로 다른 각도에서 한 삶을 그립니다.',
            '「여호와는 선하시고 정직하시니」(시25:8). 이 낱말들은 먼저 하나님의 성품이고, 그다음에 사람에게 요구되는 길입니다.',
            '사사기의 마지막이 반대의 그림을 보여 줍니다. 「사람마다 자기 소견에 옳은 대로 행하였더라」(삿17:6). 옳음의 기준이 저마다의 눈이 될 때 일어나는 일을 그 책 전체가 증언합니다.',
            '이 가족의 낱말들은 시편 19편에 나란히 모입니다. 율법은 완전하고, 교훈은 정직하고, 계명은 순결합니다. 하나님의 말씀이 이 낱말들의 본입니다.']),
        'desc_en': NL.join([
            'The words for living rightly: tsedeq, conformity to the standard; mishpat, right judgment; emet, unshakable faithfulness; yashar, straightness; tamim, wholeness without blemish. Each draws the same life from a different angle.',
            '"Good and upright is the LORD" (Psalm 25:8): these words are first the character of God, and only then the way required of man.',
            'The last line of Judges shows the opposite picture: "every man did that which was right in his own eyes" (Judges 17:6). The whole book testifies what happens when rightness is measured by every man\'s own eye.',
            'The family gathers in Psalm 19: the law perfect, the precepts right, the commandment pure. The word of God is the pattern of these words.']),
    },
    'words': [
        {'code': 'T_YASHAR', 'KO': '정직 · 야샤르', 'EN': 'Upright (yashar)',
         'promote': 'W_H3477', 'move': [], 'new': [],
         'alias_ko': ['옳음'], 'alias_en': ['Yashar'],
         'desc_ko': NL.join([
             '정직으로 옮겨지는 이 낱말의 그림은 굽지 않고 곧게 뻗은 길입니다. 마음과 길이 휘지 않은 사람을 가리킵니다.',
             '「여호와는 선하시고 정직하시니 그러므로 그 도로 죄인을 교훈하시리로다」(시25:8). 정직은 먼저 하나님의 성품입니다.',
             '「사람마다 자기 소견에 옳은 대로 행하였더라」(삿17:6)의 옳음이 같은 낱말입니다. 기준이 하나님이 아니라 저마다의 눈이 되면, 같은 낱말이 무질서의 이름이 됩니다.',
             '체데크(의)가 재판정의 기준이라면 야샤르는 길의 그림입니다. 곧은 길은 어디서 보아도 곧습니다.']),
         'desc_en': NL.join([
             'The picture in this word is a road that runs straight: a person whose heart and way are unbent.',
             '"Good and upright is the LORD: therefore will he teach sinners in the way" (Psalm 25:8). Uprightness is first the character of God.',
             'The "right" of Judges 17:6, "every man did that which was right in his own eyes," is the same word: measured by one\'s own eye, it becomes the name of chaos.',
             'Where tsedeq is the standard of the court, yashar is the picture of the road. A straight road is straight from wherever you look.'])},
        {'code': 'T_TAMIM', 'KO': '온전 · 타밈', 'EN': 'Blameless (tamim)',
         'promote': 'W_H8549', 'move': [], 'new': [],
         'alias_ko': ['완전'], 'alias_en': ['Tamim'],
         'desc_ko': NL.join([
             '완전과 흠 없음으로 옮겨지는 이 낱말은 결함 없는 온전함을 가리킵니다. 제물에 쓰면 흠 없는 짐승이고, 사람에 쓰면 흠 잡을 데 없는 삶입니다.',
             '「노아는 의인이요 당세에 완전한 자라 그가 하나님과 동행하였으며」(창6:9). 완전은 무죄가 아니라 하나님과 동행하는 삶의 한결같음입니다.',
             '「나는 전능한 하나님이라 너는 내 앞에서 행하여 완전하라」(창17:1). 아브라함에게 주신 이 명령이 이 낱말의 자리를 정합니다. 하나님 앞에서 걷는 걸음의 문제입니다.',
             '「여호와의 율법은 완전하여 영혼을 소성케 하고」(시19:7). 흠 없는 제물의 낱말이 말씀에도 쓰이고, 마침내 흠 없는 어린 양에게도 쓰입니다.']),
         'desc_en': NL.join([
             'The word for wholeness without defect: of a sacrifice, an animal without blemish; of a person, a life without reproach.',
             '"Noah was a just man and perfect in his generations, and Noah walked with God" (Genesis 6:9): perfection here is not sinlessness but the constancy of a walk with God.',
             '"I am the Almighty God; walk before me, and be thou perfect" (Genesis 17:1): the charge to Abraham fixes the word\'s place — a matter of how one walks before God.',
             '"The law of the LORD is perfect, converting the soul" (Psalm 19:7): the word for the unblemished offering serves for the word of God, and at last for the Lamb without blemish.'])},
    ],
    'members': ['T_TSEDEQ', 'T_MISHPAT', 'T_EMET', 'T_YASHAR', 'T_TAMIM'],
}

DRAFT_WORD = {
    'field': {
        'code': 'F_WORD', 'subtype': 'FIELD',
        'KO': '말씀의 낱말 가족', 'EN': 'The Word Family',
        'desc_ko': NL.join([
            '성경이 하나님의 말씀을 부르는 낱말들입니다. 말씀이자 사건인 다바르, 가르침이자 길인 토라(율법), 하나하나의 지시인 미츠바(계명)가 한 가족입니다.',
            '다바르는 말씀이 곧 일이 되는 낱말이고, 토라는 아버지가 자식을 가르치듯 길을 보여 주는 낱말이며, 미츠바는 그 길 위의 구체적인 걸음들입니다.',
            '「여호와의 율법은 완전하여 영혼을 소성케 하고」, 「여호와의 계명은 순결하여 눈을 밝게 하도다」(시19:7~8). 시편 19편과 119편이 이 가족의 낱말들을 보석처럼 번갈아 답니다.',
            '계명이 무거운 짐이 아니라 눈을 밝게 하는 빛이라는 것, 그것이 이 가족이 함께 가르치는 결입니다.']),
        'desc_en': NL.join([
            'The words for the word of God: davar, word that is also deed; torah, teaching that shows the way as a father teaches a child; mitsvah, the particular steps upon that way.',
            'Davar acts, torah directs, mitsvah specifies.',
            '"The law of the LORD is perfect, converting the soul... the commandment of the LORD is pure, enlightening the eyes" (Psalm 19:7-8). Psalms 19 and 119 wear these words in turn like jewels.',
            'That the commandment is not a burden but light for the eyes — this is the grain the family teaches together.']),
    },
    'words': [
        {'code': 'T_MITSVAH', 'KO': '계명 · 미츠바', 'EN': 'Commandment (mitsvah)',
         'promote': 'W_H4687', 'move': [], 'new': [],
         'alias_ko': ['명령'], 'alias_en': ['Mitsvah'],
         'desc_ko': NL.join([
             '계명과 명령으로 옮겨지는 이 낱말은 하나님이 명하신 하나하나의 구체적인 지시를 가리킵니다.',
             '토라가 길 전체라면 미츠바는 그 길 위의 걸음들입니다. 그래서 복수형으로 자주 나옵니다.',
             '「여호와의 계명은 순결하여 눈을 밝게 하도다」(시19:8). 시편은 계명을 짐이 아니라 빛으로 노래합니다.',
             '예수님은 모든 계명을 하나님 사랑과 이웃 사랑, 두 계명으로 요약하셨습니다. 계명들의 심장이 사랑이라는 뜻입니다.']),
         'desc_en': NL.join([
             'The word for each particular charge God has commanded.',
             'If torah is the whole way, mitsvah is the steps upon it; hence it comes so often in the plural.',
             '"The commandment of the LORD is pure, enlightening the eyes" (Psalm 19:8): the Psalms sing of commandment as light, not burden.',
             'Jesus summed all the commandments in two, love of God and love of neighbour: the heart of the commandments is love.'])},
    ],
    'members': ['T_DAVAR', 'T_TORAH', 'T_MITSVAH'],
}

DRAFT_ELYON = {
    'field': {
        'code': 'F_DIVINE_NAMES', 'subtype': 'FIELD',
        'KO': '하나님의 이름 가족', 'EN': 'The Divine Name Family',
        # ⚠ 이 의미장은 181차에 이미 있다 — 설명문은 기존 것이 유지되고
        #   (있으면 안 덮는 규칙) 여기서는 구성원 링크만 는다.
        'desc_ko': NL.join([
            '성경이 하나님을 부르는 이름들입니다. 엘로힘과 여호와와 아도나이와 샤다이와 체바오트와 엘, 그리고 지존자 엘욘이 저마다 다른 결을 담습니다.',
            '이름마다 하나님의 다른 얼굴이 보입니다. 창조의 능력, 언약의 신실, 다스리시는 주권, 전능, 만군, 그리고 가장 높으심입니다.',
            '한 분 하나님을 여러 이름으로 부르는 것은 그분이 여럿이어서가 아니라, 한 이름으로 다 담을 수 없어서입니다.',
            '이름을 배우는 일은 그분을 아는 일의 첫걸음입니다.']),
        'desc_en': NL.join([
            'The names by which Scripture calls God: Elohim, YHWH, Adonai, Shaddai, Tsevaot, El, and Elyon the Most High, each with its own grain.',
            'Each name shows another face: creating power, covenant faithfulness, ruling lordship, almightiness, the hosts, and supreme height.',
            'One God is called by many names not because he is many, but because no one name can hold him.',
            'To learn the names is a first step in knowing him.']),
    },
    'words': [
        {'code': 'T_ELYON', 'KO': '지존자 · 엘욘', 'EN': 'Most High (Elyon)',
         'promote': 'W_H5945', 'move': [], 'new': [],
         'alias_ko': ['지극히 높으신 하나님'], 'alias_en': ['Elyon', 'Most High'],
         'desc_ko': NL.join([
             '지존자로 옮겨지는 이 이름은 가장 높으신 분이라는 뜻입니다. 높다는 낱말에서 나와, 모든 것 위에 계신 하나님을 부릅니다.',
             '「살렘 왕 멜기세덱이 떡과 포도주를 가지고 나왔으니 그는 지극히 높으신 하나님의 제사장이었더라」(창14:18). 이스라엘 밖의 제사장이 부른 이름으로 처음 등장합니다. 열방 위에 계신 분이라는 결이 처음부터 담겨 있습니다.',
             '「지존자의 은밀한 곳에 거하는 자는 전능하신 자의 그늘 아래 거하리로다」(시91:1). 시편에서 이 이름은 피난처의 이름입니다. 가장 높으신 분의 그늘이 가장 안전한 자리입니다.',
             '같은 낱말이 윗 문과 윗 못처럼 자리의 높음에도 쓰입니다. 이름으로 쓰일 때와 형용사로 쓰일 때를 문맥이 가릅니다.']),
         'desc_en': NL.join([
             'The name means the Highest: from the word for high, it names God above all.',
             '"Melchizedek king of Salem... was the priest of the most high God" (Genesis 14:18): it first appears on the lips of a priest outside Israel, carrying from the start the grain of the God above the nations.',
             '"He that dwelleth in the secret place of the most High shall abide under the shadow of the Almighty" (Psalm 91:1): in the Psalms it is a refuge name — the shadow of the Highest is the safest place.',
             'The same word also serves for the "upper" gate or pool; context tells the name from the adjective.'])},
    ],
    'members': ['T_ELYON'],
}

DRAFTS_B4 = (DRAFT_LOVE, DRAFT_PURITY, DRAFT_RIGHT, DRAFT_WORD, DRAFT_ELYON)


# ──────────────────────────────────────────────────────────────────────
def _eid(conn, code):
    r = conn.execute("SELECT entity_id FROM sys_entity_master WHERE entity_code=?",
                     (code,)).fetchone()
    return r[0] if r else None


def _text_get(conn, eid, ttype, lang):
    r = conn.execute(
        "SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type=?"
        " AND lang_code=? AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
        (eid, ttype, lang)).fetchone()
    return r[0] if r else None


def _text_put(conn, eid, ttype, lang, body):
    """없으면 넣고, 있으면 그대로 둔다 — 나중의 손질을 덮지 않는다."""
    if _text_get(conn, eid, ttype, lang) is None:
        conn.execute(
            "INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,contents,record_status)"
            " VALUES(?,?,?,?,'LIVE')", (eid, ttype, lang, body))
        return 1
    return 0


def _gate_desc(errs, code, lang, body):
    if not body or len(body) < 200:
        errs.append('%s %s 설명문 길이 부족' % (code, lang))
        return
    if lang == 'KO' and '—' in body:
        errs.append('%s KO 설명문에 「—」' % code)
    if NL + NL in body:
        errs.append('%s %s 설명문에 빈 줄' % (code, lang))


def check(conn, draft=DRAFT, verbose=True):
    """게이트. 오류 목록을 돌려준다 — 비면 통과."""
    import db_term_load as TL
    errs = []
    for w in draft['words']:
        for lang, body in (('KO', w['desc_ko']), ('EN', w['desc_en'])):
            _gate_desc(errs, w['code'], lang, body)
        for src_code, strong in w['move']:
            src = _eid(conn, src_code)
            dst = _eid(conn, w['code'])
            owner = None
            r = conn.execute("SELECT entity_id FROM sys_entity_lemma WHERE strong=?",
                             (strong,)).fetchone()
            owner = r[0] if r else None
            if owner is None:
                errs.append('%s: 옮길 낱말 %s 이 어디에도 없다' % (w['code'], strong))
            elif owner not in (src, dst):
                errs.append('%s: %s 의 주인이 %s 도 %s 도 아니다(entity %s)'
                            % (w['code'], strong, src_code, w['code'], owner))
        for _lg, strong, _tr, _gl in w['new']:
            vids = TL.strong_verses(strong)
            if not vids:
                errs.append('%s: 새 앵커 %s 가 검증 DB 에 없다' % (w['code'], strong))
        prom = w.get('promote')
        if prom and _eid(conn, prom) is None and _eid(conn, w['code']) is None:
            errs.append('%s: 승격 대상 %s 이 없다' % (w['code'], prom))
    f = draft['field']
    for lang, body in (('KO', f['desc_ko']), ('EN', f['desc_en'])):
        _gate_desc(errs, f['code'], lang, body)
    known = {w['code'] for w in draft['words']}
    for m in draft['members']:
        if m not in known and _eid(conn, m) is None:
            errs.append('소속 코드 실재하지 않음: %s' % m)
    if verbose:
        print('check: %s' % ('통과' if not errs else '%d건 위반' % len(errs)))
        for e in errs:
            print('  ✗', e)
    return errs


def _ensure_entity(conn, code, ko, en, desc_ko, desc_en, subtype=None,
                   etype='TERM'):
    eid = _eid(conn, code)
    made = 0
    if eid is None:
        jd = json.dumps({'subtype': subtype}) if subtype else None
        conn.execute(
            "INSERT INTO sys_entity_master(entity_code,entity_type,importance,"
            "json_detail,record_status) VALUES(?, ?, 5, ?, 'LIVE')",
            (code, etype, jd))
        eid = _eid(conn, code)
        made = 1
    _text_put(conn, eid, 'ENTITY_NAME', 'KO', ko)
    _text_put(conn, eid, 'ENTITY_NAME', 'EN', en)
    _text_put(conn, eid, 'ENTITY_DESC', 'KO', desc_ko)
    _text_put(conn, eid, 'ENTITY_DESC', 'EN', desc_en)
    return eid, made


def apply(conn, draft=DRAFT):
    errs = check(conn, draft, verbose=False)
    if errs:
        for e in errs:
            print('  ✗', e)
        raise SystemExit('check 위반 — 적용하지 않음')
    conn.execute("CREATE TABLE IF NOT EXISTS %s("
                 "lemma_id INTEGER, old_entity_id INTEGER, kind TEXT)" % BK)
    import db_term_load as TL
    import entity_aliases as EA
    relink_codes = set()
    n_ent = n_move = n_new = n_link = 0
    for w in draft['words']:
        # ★ 자리 승격 (2026-09-03 185차) — W_ 낱말 엔티티의 **번호를 보존**한
        #   채 코드·이름·중요도를 올린다(이미 받은 연결이 끊기지 않는다 —
        #   유령 연결 사고의 교훈). 기계 이름(W_ EN)은 걷고 새 이름을 심는다.
        prom = w.get('promote')
        if prom and _eid(conn, w['code']) is None:
            _pe = _eid(conn, prom)
            if _pe is not None:
                conn.execute("INSERT INTO %s VALUES(?,?,?)" % BK,
                             (_pe, 0, 'PROM ' + prom))
                conn.execute(
                    "UPDATE sys_entity_master SET entity_code=?, importance=5,"
                    " json_detail=NULL WHERE entity_id=?", (w['code'], _pe))
                conn.execute("DELETE FROM sys_text_asset WHERE clicked_id=?"
                             " AND text_type='ENTITY_NAME'", (_pe,))
                # W_ 시절에는 LEXICAL 을 일부러 안 만들었다(티커 보호) —
                # 승격하면 보통 용어이므로 여기서 처음 만든다
                if w.get('etype', 'TERM') == 'TERM':
                    relink_codes.add(w['code'])
        eid, made = _ensure_entity(conn, w['code'], w['KO'], w['EN'],
                                   w['desc_ko'], w['desc_en'],
                                   etype=w.get('etype', 'TERM'))
        n_ent += made
        # 별명 — 있는 것에 더하기만 한다
        for lang, key in (('KO', 'alias_ko'), ('EN', 'alias_en')):
            add = w.get(key) or []
            if not add:
                continue
            jd = conn.execute("SELECT json_detail FROM sys_entity_master"
                              " WHERE entity_id=?", (eid,)).fetchone()[0]
            cur = EA.aliases_for_lang(jd, lang)
            new = cur + [a for a in add if a not in cur]
            if new != cur:
                EA.update_aliases(conn, eid, lang, new)
        # 낱말 옮기기 — lemma_id 보존(낱말별 설명문이 따라온다)
        for src_code, strong in w['move']:
            src = _eid(conn, src_code)
            row = conn.execute(
                "SELECT lemma_id, entity_id FROM sys_entity_lemma WHERE strong=?",
                (strong,)).fetchone()
            lid, owner = row
            if owner == eid:
                continue                     # 이미 옮겨짐 — 멱등
            conn.execute("INSERT INTO %s VALUES(?,?, 'MOVE')" % BK, (lid, owner))
            conn.execute("UPDATE sys_entity_lemma SET entity_id=? WHERE lemma_id=?",
                         (eid, lid))
            # W_ 껍데기 청소 — 낱말을 내준 전수 등록 항목이 빈 몸이면 걷는다
            #   (연결이 붙어 있으면 남긴다 — 잃는 쪽이 더 나쁘다)
            if src_code and src_code.startswith('W_'):
                left = conn.execute("SELECT COUNT(*) FROM sys_entity_lemma"
                                    " WHERE entity_id=?", (owner,)).fetchone()[0]
                used = conn.execute(
                    "SELECT COUNT(*) FROM sys_link_asset WHERE"
                    " (link_type LIKE 'ENTI%' AND clicked_id=?)"
                    " OR (link_type LIKE '%_ENTI' AND target_id=?)",
                    (owner, owner)).fetchone()[0]
                if left == 0 and used == 0:
                    conn.execute("DELETE FROM sys_text_asset WHERE clicked_id=?"
                                 " AND text_type='ENTITY_NAME'", (owner,))
                    conn.execute("DELETE FROM sys_entity_master"
                                 " WHERE entity_id=?", (owner,))
            relink_codes.add(src_code)
            if w.get('etype', 'TERM') == 'TERM':
                relink_codes.add(w['code'])
            n_move += 1
        # 새 앵커
        for lg, strong, tr, gl in w['new']:
            r = conn.execute("SELECT lemma_id FROM sys_entity_lemma"
                             " WHERE entity_id=? AND strong=?", (eid, strong)).fetchone()
            if r:
                continue
            so = conn.execute("SELECT COALESCE(MAX(sort_order),0)+1 FROM"
                              " sys_entity_lemma WHERE entity_id=?", (eid,)).fetchone()[0]
            conn.execute(
                "INSERT INTO sys_entity_lemma(entity_id,lang_code,strong,translit,"
                "gloss,sort_order,record_status) VALUES(?,?,?,?,?,?,'LIVE')",
                (eid, lg, strong, tr, gl, so))
            lid = conn.execute("SELECT lemma_id FROM sys_entity_lemma"
                               " WHERE entity_id=? AND strong=?", (eid, strong)).fetchone()[0]
            conn.execute("INSERT INTO %s VALUES(?,?, 'NEW')" % BK, (lid, eid))
            if w.get('etype', 'TERM') == 'TERM':
                relink_codes.add(w['code'])
            n_new += 1
    # 의미장 노드 + 소속 링크
    f = draft['field']
    fid, made = _ensure_entity(conn, f['code'], f['KO'], f['EN'],
                               f['desc_ko'], f['desc_en'], subtype=f.get('subtype'))
    n_ent += made
    for m in draft['members']:
        mid = _eid(conn, m)
        r = conn.execute(
            "SELECT 1 FROM sys_link_asset WHERE link_type='ENTI_ENTI'"
            " AND clicked_id=? AND target_id=? AND rel_code='FIELD_WORD'"
            " AND COALESCE(record_status,'LIVE')='LIVE'", (fid, mid)).fetchone()
        if not r:
            conn.execute(
                "INSERT INTO sys_link_asset(link_type,clicked_id,target_id,"
                "rel_code,record_status) VALUES('ENTI_ENTI',?,?,'FIELD_WORD','LIVE')",
                (fid, mid))
            n_link += 1
    conn.commit()
    if relink_codes:
        TL.relink(conn, sorted(relink_codes))
    print('apply: 엔티티 +%d · 낱말 이동 %d · 새 앵커 %d · 소속 링크 +%d'
          % (n_ent, n_move, n_new, n_link))


def undo(conn, draft=DRAFT):
    """낱말을 원위치로, 새 낱말·소속 링크·새 엔티티를 걷는다."""
    import db_term_load as TL
    rows = conn.execute("SELECT lemma_id, old_entity_id, kind FROM %s" % BK).fetchall()
    if not rows:
        print('undo: 백업 없음')
        return
    relink_codes = set()
    for lid, old, kind in rows:
        if kind.startswith('PROM '):
            print('  (안내) 자리 승격 %s 은 undo 대상이 아니다 — 파일 원장'
                  ' 재적재가 복구 수단' % kind[5:])
            continue
        if kind == 'MOVE':
            cur = conn.execute("SELECT entity_id FROM sys_entity_lemma"
                               " WHERE lemma_id=?", (lid,)).fetchone()
            if cur:
                for e in (cur[0], old):
                    r = conn.execute("SELECT entity_code FROM sys_entity_master"
                                     " WHERE entity_id=?", (e,)).fetchone()
                    if r:
                        relink_codes.add(r[0])
                conn.execute("UPDATE sys_entity_lemma SET entity_id=?"
                             " WHERE lemma_id=?", (old, lid))
        else:
            conn.execute("DELETE FROM sys_link_asset WHERE link_type='ENTI_VERS'"
                         " AND lemma_id=?", (lid,))
            conn.execute("DELETE FROM sys_entity_lemma WHERE lemma_id=?", (lid,))
    fid = _eid(conn, draft['field']['code'])
    if fid:
        conn.execute("DELETE FROM sys_link_asset WHERE link_type='ENTI_ENTI'"
                     " AND clicked_id=? AND rel_code='FIELD_WORD'", (fid,))
    for w in draft['words'] + [draft['field']]:
        eid = _eid(conn, w['code'])
        if eid:
            conn.execute("UPDATE sys_entity_master SET record_status='HIDE'"
                         " WHERE entity_id=?", (eid,))
    conn.execute("DELETE FROM %s" % BK)
    conn.commit()
    if relink_codes:
        TL.relink(conn, sorted(relink_codes))
    print('undo: 완료 (%d건 원복)' % len(rows))


def status(conn, draft=DRAFT):
    fid = _eid(conn, draft['field']['code'])
    print('의미장 %s: %s' % (draft['field']['code'], '있음' if fid else '없음'))
    for w in draft['words']:
        eid = _eid(conn, w['code'])
        if eid is None:
            print('  %-13s 미승격' % w['code'])
            continue
        n = conn.execute(
            "SELECT COUNT(*) FROM sys_link_asset WHERE link_type='ENTI_VERS'"
            " AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'",
            (eid,)).fetchone()[0]
        lems = conn.execute("SELECT COUNT(*) FROM sys_entity_lemma"
                            " WHERE entity_id=?", (eid,)).fetchone()[0]
        print('  %-13s 앵커 %d · 절 %d' % (w['code'], lems, n))
    if fid:
        n = conn.execute(
            "SELECT COUNT(*) FROM sys_link_asset WHERE link_type='ENTI_ENTI'"
            " AND clicked_id=? AND rel_code='FIELD_WORD'"
            " AND COALESCE(record_status,'LIVE')='LIVE'", (fid,)).fetchone()[0]
        print('  소속 낱말 %d' % n)


# ──────────────────────────────────────────────────────────────────────
# ──────────────────────────────────────────────────────────────────────
# 손질 원장(PATCHES) — **DB 에만 있던 정성 손질을 파일로 되살릴 수 있게**
# (2026-09-03 사용자 지시 「TERM 으로 db 에 저장한 후에 데이터를 다른 곳으로
# 이동해야 할 상황이 생기면 위험이 크다. 별도로 py, md 파일에 저장해 두는
# 것이 좋겠다」). 규칙: **용어 콘텐츠의 정본은 이 파일의 초안이다** — DB 가
# 무너져도 `--apply` · `--apply-names` · `--apply-patches` 로 재현된다.
# 여기 담는 것 = 초안(DRAFT·DRAFT_NAMES) 밖에서 한 손질(설명문 개정·별명).
PATCHES = {
    # 죄 3형제 설명문 175차 개정판 — 초입은 자기 낱말부터 · 세 얼굴 열거는
    # 끝의 가족 문단 전담(사용자 「a,b,c를 열거하면서 세개를 말해야」).
    'T_PESHA': {
        'alias_ko': ['범죄'], 'alias_en': ['Trespass'],
        'desc_ko': NL.join([
            '허물로 옮겨지는 이 낱말의 그림은 반역입니다. 실수로 어긋난 것이 아니라 알면서 등을 돌리는 일입니다.',
            '이 낱말은 원래 나라와 나라 사이에 쓰였습니다. 속국이 종주국에 반기를 드는 것이 페샤입니다. 열왕기에서 모압이 이스라엘을 「배반하였다」고 할 때 그 낱말입니다.',
            '그것을 하나님과 사람 사이에 가져다 쓴 것입니다. 실수가 아니라 관계를 끊는 일이라는 뜻입니다. 그래서 이 낱말에는 「모르고 그랬다」가 없습니다.',
            '시편 51편에서 다윗이 맨 먼저 부르는 낱말이 이것이고, 이사야 53장은 그가 우리의 허물 때문에 찔렸다고 합니다.',
            '성경은 죄를 여러 낱말로 말합니다. 언약을 깨뜨리는 반역(허물·페샤)과 함께, 과녁을 벗어난 빗나감(죄·하타트)과 굽어 뒤틀린 상태(죄악·아온)가 있습니다. 셋이 함께 죄의 세 얼굴을 그리며, 시32:1~2와 사53:5~6이 이 낱말들을 나란히 씁니다.']),
        'desc_en': NL.join([
            "The word rendered transgression pictures rebellion: not slipping by mistake, but knowingly turning one's back.",
            'It first belonged between nations. A vassal state rising against its overlord was pesha. When Kings says Moab rebelled against Israel, that is the word.',
            'It was then carried over into what lies between God and people. Not a slip, but the breaking of a bond. So this word has no room for "I did not know."',
            'It is the first word David reaches for in Psalm 51, and Isaiah 53 says he was pierced for our transgressions.',
            'Scripture speaks of sin in several words: beside covenant-breaking rebellion (pesha) stand missing the mark (chattat) and the twisted condition (avon). Together they draw the three faces of sin, set side by side in Psalm 32:1-2 and Isaiah 53:5-6.'])},
    'T_AVON': {
        'desc_ko': NL.join([
            '죄악으로 옮겨지는 이 낱말의 그림은 굽음입니다. 곧아야 할 것이 휘었다는 뜻입니다.',
            '그리고 이 낱말은 죄만 가리키지 않고 그 죄가 불러온 결과까지 함께 가리킵니다. 개역한글이 이 낱말을 「죄악」으로도 「벌」로도 옮긴 것은 그래서입니다. 가인이 「내 죄벌이 지기가 너무 무겁다」고 할 때 죄와 벌이 한 낱말입니다.',
            '죄를 지고 다닌다는 그림이 여기서 나옵니다. 굽은 것은 그대로 남아서 사람이 그것을 지고 삽니다.',
            '이사야 53장이 이 낱말로 종을 말합니다. 우리의 죄악을 그가 담당하였다는 것, 곧 지고 다니던 것을 다른 이가 대신 진다는 것입니다.',
            '성경은 죄를 여러 낱말로 말합니다. 굽어 뒤틀린 상태(죄악·아온)와 함께, 과녁을 벗어난 빗나감(죄·하타트)과 언약을 깨뜨리는 반역(허물·페샤)이 있습니다. 셋이 함께 죄의 세 얼굴을 그리며, 시32:1~2와 사53:5~6이 이 낱말들을 나란히 씁니다.']),
        'desc_en': NL.join([
            'The word rendered iniquity pictures crookedness: what should be straight has bent.',
            'And it names not only the wrong but what the wrong brings on. That is why the Korean Bible renders it both as iniquity and as punishment; when Cain says his punishment is more than he can bear, sin and its weight are one word.',
            "The picture of carrying one's sin comes from here. What is bent stays bent, and a person lives carrying it.",
            'Isaiah 53 uses this word of the servant: he bore our iniquities. What had been carried is taken up by another.',
            'Scripture speaks of sin in several words: beside the twisted condition (avon) stand missing the mark (chattat) and covenant-breaking rebellion (pesha). Together they draw the three faces of sin, set side by side in Psalm 32:1-2 and Isaiah 53:5-6.'])},
    'T_CHATAT': {
        'desc_ko': NL.join([
            '뿌리 뜻은 과녁을 빗나감입니다. 사사기에서 물매로 돌을 던져 「털끝만큼도 틀림이 없다」고 할 때 그 「틀리다」가 이 낱말입니다.',
            '그러니 죄는 나쁜 짓을 했다는 말이기 전에 가야 할 곳에 이르지 못했다는 말입니다. 악의가 없어도 빗나갈 수 있습니다.',
            '이 낱말은 죄를 가리키기도 하고 그 죄를 덮는 제사를 가리키기도 합니다. 개역한글의 「속죄제」가 실은 그냥 「죄」와 같은 낱말입니다. 죄와 그 해결이 한 낱말에 들어 있습니다.',
            '신약이 하마르티아로 받았고, 그 낱말도 헬라어에서 「과녁을 못 맞힘」이었습니다.',
            '성경은 죄를 여러 낱말로 말합니다. 과녁을 벗어난 빗나감(죄·하타트), 굽어 뒤틀린 상태(죄악·아온), 언약을 깨뜨리는 반역(허물·페샤)입니다. 개역한글이 죄, 죄악, 허물로 갈라 옮기지만 셋이 함께 죄의 세 얼굴을 그립니다. 시32:1~2와 사53:5~6이 이 낱말들을 나란히 씁니다.']),
        'desc_en': NL.join([
            'The root sense is missing the mark. When Judges says the slingers could sling a stone and not miss, that verb is this word.',
            'So sin, before it means doing something wicked, means failing to arrive where one should. One can miss without malice.',
            'The same word names both the sin and the sacrifice that covers it. What the Korean Bible calls a sin offering is literally the word sin. The trouble and its remedy sit in one word.',
            'The New Testament received it as hamartia, which in Greek likewise meant a missed mark.',
            'Scripture speaks of sin in several words: missing the mark (chattat), a twisted condition (avon), covenant-breaking rebellion (pesha). Translated variously as sin, iniquity, and transgression, together they draw the three faces of sin, set side by side in Psalm 32:1-2 and Isaiah 53:5-6.'])},
}


def apply_patches(conn):
    """PATCHES → DB (멱등 — 같으면 0). 설명문은 덮고 별명은 더한다."""
    import entity_aliases as EA
    n = 0
    for code, p in PATCHES.items():
        eid = _eid(conn, code)
        if eid is None:
            print('  ✗ 없음:', code)
            continue
        for lang, key in (('KO', 'desc_ko'), ('EN', 'desc_en')):
            body = p.get(key)
            if not body:
                continue
            cur = conn.execute(
                "SELECT sys_text_id, contents FROM sys_text_asset"
                " WHERE text_type='ENTITY_DESC' AND clicked_id=? AND lang_code=?"
                " AND COALESCE(record_status,'LIVE')='LIVE'", (eid, lang)).fetchone()
            if cur and cur[1] != body:
                conn.execute("UPDATE sys_text_asset SET contents=?"
                             " WHERE sys_text_id=?", (body, cur[0]))
                n += 1
            elif not cur:
                conn.execute(
                    "INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,"
                    "contents,record_status) VALUES(?,'ENTITY_DESC',?,?,'LIVE')",
                    (eid, lang, body))
                n += 1
        for lang, key in (('KO', 'alias_ko'), ('EN', 'alias_en')):
            add = p.get(key) or []
            if not add:
                continue
            jd = conn.execute("SELECT json_detail FROM sys_entity_master"
                              " WHERE entity_id=?", (eid,)).fetchone()[0]
            cur = EA.aliases_for_lang(jd, lang)
            new = cur + [a for a in add if a not in cur]
            if new != cur:
                EA.update_aliases(conn, eid, lang, new)
                n += 1
    conn.commit()
    print('apply_patches: %d건' % n)


def selftest():
    """메모리 DB — 실 DB·실 백업표를 건드리지 않는다(§139차)."""
    import sqlite3
    import db_term_load as TL
    ok = [0, 0]

    def t(name, cond):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s' % ('OK ' if cond else 'FAIL', name))

    conn = sqlite3.connect(':memory:')
    conn.execute("CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY,"
                 " entity_code TEXT UNIQUE, entity_type TEXT, importance INT,"
                 " json_detail TEXT, record_status TEXT)")
    conn.execute("CREATE TABLE sys_entity_lemma(lemma_id INTEGER PRIMARY KEY,"
                 " entity_id INT, lang_code TEXT, strong TEXT, translit TEXT,"
                 " gloss TEXT, sort_order INT, record_status TEXT)")
    conn.execute("CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY,"
                 " link_type TEXT, clicked_id INT, target_id INT, rel_code TEXT,"
                 " lemma_id INT, is_key INT, end_id INT, record_status TEXT)")
    conn.execute("CREATE TABLE sys_text_asset(sys_text_id INTEGER PRIMARY KEY,"
                 " clicked_id INT, text_type TEXT, lang_code TEXT, contents TEXT,"
                 " text_variant TEXT, record_status TEXT)")
    # 출발 상태 — 용어 하나에 낱말 둘
    conn.execute("INSERT INTO sys_entity_master VALUES(1,'T_SRC','TERM',5,NULL,'LIVE')")
    conn.execute("INSERT INTO sys_entity_lemma VALUES(10,1,'HE','H1','알파','a',1,'LIVE')")
    conn.execute("INSERT INTO sys_entity_lemma VALUES(11,1,'EL','G1','베타','b',2,'LIVE')")
    old_sv = TL.strong_verses
    TL.strong_verses = lambda s: {'H1': [100, 101], 'G1': [200], 'H2': [300, 301, 302]}.get(s)
    old_relink = TL.relink

    def _mini_relink(c2, codes=None):
        for eid, code in c2.execute("SELECT entity_id, entity_code FROM"
                                    " sys_entity_master WHERE entity_type='TERM'"):
            if codes and code not in codes:
                continue
            c2.execute("DELETE FROM sys_link_asset WHERE link_type='ENTI_VERS'"
                       " AND clicked_id=? AND rel_code='LEXICAL'", (eid,))
            for lid, st in c2.execute("SELECT lemma_id,strong FROM sys_entity_lemma"
                                      " WHERE entity_id=?", (eid,)).fetchall():
                for v in (TL.strong_verses(st) or []):
                    c2.execute("INSERT INTO sys_link_asset(link_type,clicked_id,"
                               "target_id,rel_code,lemma_id,is_key,record_status)"
                               " VALUES('ENTI_VERS',?,?,'LEXICAL',?,0,'LIVE')", (eid, v, lid))
    TL.relink = _mini_relink
    _mini_relink(conn)
    body = ('가' * 100 + NL + '나' * 120)
    draft = {
        'field': {'code': 'F_T', 'subtype': 'FIELD', 'KO': '장', 'EN': 'F',
                  'desc_ko': body, 'desc_en': body},
        'words': [{'code': 'T_NEW', 'KO': '새 · 베타', 'EN': 'New (beta)',
                   'move': [('T_SRC', 'G1')],
                   'new': [('HE', 'H2', '감마', 'g')],
                   'alias_ko': [], 'alias_en': [],
                   'desc_ko': body, 'desc_en': body}],
        'members': ['T_SRC', 'T_NEW'],
    }
    try:
        t('check 통과', not check(conn, draft, verbose=False))
        apply(conn, draft)
        nid = _eid(conn, 'T_NEW')
        t('새 엔티티 생성', nid is not None)
        t('낱말 이동(lemma_id 보존)', conn.execute(
            "SELECT entity_id FROM sys_entity_lemma WHERE lemma_id=11").fetchone()[0] == nid)
        t('새 앵커 절 생성(3절)', conn.execute(
            "SELECT COUNT(*) FROM sys_link_asset WHERE clicked_id=? AND lemma_id="
            "(SELECT lemma_id FROM sys_entity_lemma WHERE strong='H2')",
            (nid,)).fetchone()[0] == 3)
        t('원 용어에 헬라 절 잔재 0', conn.execute(
            "SELECT COUNT(*) FROM sys_link_asset WHERE clicked_id=1 AND lemma_id=11"
        ).fetchone()[0] == 0)
        t('소속 링크 2', conn.execute(
            "SELECT COUNT(*) FROM sys_link_asset WHERE link_type='ENTI_ENTI'"
            " AND rel_code='FIELD_WORD'").fetchone()[0] == 2)
        c0 = conn.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
        apply(conn, draft)
        t('멱등(두 번 적용 행수 불변)', conn.execute(
            "SELECT COUNT(*) FROM sys_link_asset").fetchone()[0] == c0)
        undo(conn, draft)
        t('undo — 낱말 원위치', conn.execute(
            "SELECT entity_id FROM sys_entity_lemma WHERE lemma_id=11").fetchone()[0] == 1)
        t('undo — 새 낱말 걷힘', conn.execute(
            "SELECT COUNT(*) FROM sys_entity_lemma WHERE strong='H2'").fetchone()[0] == 0)
        t('undo — 새 엔티티 HIDE', conn.execute(
            "SELECT record_status FROM sys_entity_master WHERE entity_code='T_NEW'"
        ).fetchone()[0] == 'HIDE')
        # 자리 승격 — W_ 번호 보존 · 기계 이름 교체 · LEXICAL 첫 생성 (185차)
        TL.strong_verses = lambda s: {'H1': [100, 101], 'G1': [200],
                                      'H2': [300, 301, 302], 'H9': [400]}.get(s)
        conn.execute("INSERT INTO sys_entity_master VALUES(50,'W_H9','TERM',1,"
                     "'{\"subtype\": \"LEX\"}','LIVE')")
        conn.execute("INSERT INTO sys_entity_lemma VALUES"
                     "(30,50,'HE','H9','감','g',1,'LIVE')")
        conn.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,"
                     "contents,record_status)"
                     " VALUES(50,'ENTITY_NAME','EN','gam (machine)','LIVE')")
        pd = {'field': {'code': 'F_T', 'subtype': 'FIELD', 'KO': '장', 'EN': 'F',
                        'desc_ko': body, 'desc_en': body},
              'words': [{'code': 'T_GAM', 'KO': '감 · 감', 'EN': 'Gam (gam)',
                         'promote': 'W_H9', 'move': [], 'new': [],
                         'alias_ko': [], 'alias_en': [],
                         'desc_ko': body, 'desc_en': body}],
              'members': ['T_GAM']}
        apply(conn, pd)
        t('승격 — 번호 보존', _eid(conn, 'T_GAM') == 50)
        jd9 = conn.execute("SELECT json_detail FROM sys_entity_master"
                           " WHERE entity_id=50").fetchone()[0]
        t('승격 — LEX 표식 벗김', '"subtype": "LEX"' not in (jd9 or ''))
        nm9 = conn.execute("SELECT contents FROM sys_text_asset WHERE clicked_id=50"
                           " AND text_type='ENTITY_NAME' AND lang_code='EN'"
                           ).fetchone()[0]
        t('승격 — 기계 이름 교체', nm9 == 'Gam (gam)')
        t('승격 — LEXICAL 첫 생성', conn.execute(
            "SELECT COUNT(*) FROM sys_link_asset WHERE clicked_id=50"
            " AND rel_code='LEXICAL'").fetchone()[0] == 1)
        apply(conn, pd)
        t('승격 멱등(재적용 무해)', _eid(conn, 'T_GAM') == 50 and conn.execute(
            "SELECT COUNT(*) FROM sys_link_asset WHERE clicked_id=50"
            " AND rel_code='LEXICAL'").fetchone()[0] == 1)
        # 탐지력 — 게이트가 실제로 잡는가
        bad = json.loads(json.dumps(draft))
        bad['words'][0]['desc_ko'] = body + ' — 대시'
        t('탐지력 — KO 대시', any('—' in e for e in check(conn, bad, verbose=False)))
        bad2 = json.loads(json.dumps(draft))
        bad2['words'][0]['move'] = [('T_SRC', 'G999')]
        t('탐지력 — 없는 낱말', bool(check(conn, bad2, verbose=False)))
    finally:
        TL.strong_verses = old_sv
        TL.relink = old_relink
        conn.close()
    print('db_term_field selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect('bible_master.db')
    try:
        if '--check' in sys.argv:
            check(conn)
        elif '--check-names' in sys.argv:
            check(conn, DRAFT_NAMES)
        elif '--apply-names' in sys.argv:
            apply(conn, DRAFT_NAMES)
        elif '--check-evil' in sys.argv:
            check(conn, DRAFT_EVIL)
        elif '--apply-evil' in sys.argv:
            apply(conn, DRAFT_EVIL)
        elif '--check-man' in sys.argv:
            check(conn, DRAFT_MAN)
        elif '--apply-man' in sys.argv:
            apply(conn, DRAFT_MAN)
        elif '--check-death' in sys.argv:
            check(conn, DRAFT_DEATH)
        elif '--apply-death' in sys.argv:
            apply(conn, DRAFT_DEATH)
        elif '--check-b4' in sys.argv:
            for _d in DRAFTS_B4:
                print('──', _d['field']['code'])
                check(conn, _d)
        elif '--apply-b4' in sys.argv:
            for _d in DRAFTS_B4:
                print('──', _d['field']['code'])
                apply(conn, _d)
        elif '--apply-patches' in sys.argv:
            apply_patches(conn)
        elif '--apply' in sys.argv:
            apply(conn)
        elif '--undo' in sys.argv:
            undo(conn)
        else:
            status(conn)
    finally:
        conn.close()
