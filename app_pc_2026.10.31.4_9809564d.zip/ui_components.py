# -*- coding: utf-8 -*-
import tkinter as tk
import i18n
from tkinter import ttk, messagebox
import sqlite3
import appdb
import os


try:
    # 사용자님의 시스템 환경에 맞는 표준 폰트 설정
    DEFAULT_FONT = ("Pretendard", 11)
    BOLD_FONT = ("Pretendard", 11, "bold")
except:
    DEFAULT_FONT = ("맑은 고딕", 10)
    BOLD_FONT = ("맑은 고딕", 10, "bold")

# =========================================================
# 🎯 Cascade HIDE/DELETE - TAG 
# =========================================================
class UniversalCascadeFrame(tk.Frame):
    """[최종 확정] 태그 팝업 전용: 콤보박스 상시 노출, 색상 식별, RESULT 열 완비 버전"""
    def __init__(self, master, engine, asset_type, asset_id=None, action_type="HIDE", callback=None, **kwargs):
        super().__init__(master, bg="white", **kwargs)
        self.engine, self.asset_type, self.asset_id = engine, asset_type, asset_id
        self.action_type, self.callback = action_type, callback
        
        self.rows_data = []
        self._setup_ui()
        if self.asset_id: self.load_data(self.asset_id)

    def _setup_ui(self):
        # 🎯 1. 전략 옵션 선택 (상단 바)
        s_frame = tk.Frame(self, bg="#F4F6F7", pady=10)
        s_frame.pack(fill="x")
        
        tk.Label(s_frame, text=i18n.t('UC_STRATEGY',' [전략 선택] '), font=BOLD_FONT, bg="#F4F6F7").pack(side="left", padx=10)
        self.strategy_var = tk.StringVar(value="HIDE_ALL" if self.action_type == 'HIDE' else "SHOW_SYS")
        
        for text, val in [("전체 숨김 (HIDE ALL)", "HIDE_ALL"), ("원본 노출 (SHOW SYS)", "SHOW_SYS")]:
            tk.Radiobutton(s_frame, text=text, variable=self.strategy_var, value=val, 
                          font=("맑은 고딕", 9), bg="#F4F6F7", command=self._apply_strategy_to_all).pack(side="left", padx=20)

        # 🎯 2. 헤더 영역 (규격 정렬 사수)
        header_f = tk.Frame(self, bg="#4A6984", pady=5)
        header_f.pack(fill="x", pady=(5, 0))
        
        # AS-IS(70) | TO-BE(110) | ASSET(70) | TYPE(90) | NAME/VERSE(380) | RESULT(100)
        headers = [("AS-IS", 70), ("TO-BE", 110), ("ASSET", 70), ("TYPE", 90), ("NAME/VERSE", 380), ("RESULT", 100)]
        for txt, w in headers:
            lbl = tk.Label(header_f, text=txt, width=w//8, fg="white", bg="#4A6984", font=BOLD_FONT, anchor="center")
            if txt == "NAME/VERSE": lbl.config(anchor="w")
            lbl.pack(side="left")

        # 🎯 3. 스크롤 본문 영역
        canvas_f = tk.Frame(self, bg="white")
        canvas_f.pack(fill="both", expand=True)
        
        self.canvas = tk.Canvas(canvas_f, bg="white", highlightthickness=0)
        scroll = ttk.Scrollbar(canvas_f, orient="vertical", command=self.canvas.yview)
        self.scroll_frame = tk.Frame(self.canvas, bg="white")
        
        self.canvas.create_window((0, 0), window=self.scroll_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=scroll.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.scroll_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

        # 🎯 4. 하단 집행 버튼
        b_frame = tk.Frame(self, bg="#F4F6F7", pady=10)
        b_frame.pack(fill="x")
        tk.Button(b_frame, text=i18n.t('UC_EXEC_CASCADE',' 연쇄 조치 집행 (EXECUTE) '), bg="#2E86C1", fg="white", 
                  font=BOLD_FONT, relief="flat", command=self._on_execute).pack(side="right", padx=15)

    def load_data(self, asset_id):
        self.asset_id = asset_id
        for w in self.scroll_frame.winfo_children(): w.destroy()
        self.rows_data = []
        
        res = self.engine.process('CASCADE_INFO', self.asset_type, filters={'pk': self.asset_id})
        if res.get('status') == 'success':
            for item in res.get('data', []):
                self._add_row(item)
            self._apply_strategy_to_all()

    def _add_row(self, item):
        row_f = tk.Frame(self.scroll_frame, bg="white", pady=2)
        row_f.pack(fill="x")
        
        asis = BibleUI.get_safe_status(item.get('status'))

        # 1. AS-IS
        tk.Label(row_f, text=asis, width=9, bg="white", font=("Arial", 9)).pack(side="left")

        # 2. TO-BE (콤보박스 즉시 노출)
        combo = ttk.Combobox(row_f, values=['HIDE', 'DELETE', 'LIVE'], width=11, state="readonly")
        combo.pack(side="left", padx=5)
        combo.bind("<<ComboboxSelected>>", lambda e, r=row_f: self._update_colors(r))
        # 3. ASSET & TYPE
        tk.Label(row_f, text=item['type'], width=9, bg="white", font=("Arial", 8)).pack(side="left")
        tk.Label(row_f, text=item['subtype'], width=11, bg="white", font=("Arial", 8)).pack(side="left")
        # 4. NAME (인덴트 적용)
        indent = "    " * item['depth']
        tk.Label(row_f, text=f"{indent}{item['name']}", width=48, bg="white", font=DEFAULT_FONT, anchor="w").pack(side="left")
        # 5. RESULT
        res_lbl = tk.Label(row_f, text="-", width=12, bg="white", font=("Arial", 9, "bold"), fg="#BDC3C7")
        res_lbl.pack(side="right", padx=5)
        
        self.rows_data.append({'item': item, 'asis': asis, 'combo': combo, 'res_lbl': res_lbl})

    def _update_colors(self, row_data):
        """[색상 정책] DELETE: 빨강, 변경: 파랑, 유지: 검정"""
        asis, tobe = row_data['asis'], row_data['combo'].get()
        if tobe == 'DELETE': color = "#C0392B"
        elif asis != tobe: color = "#2980B9"
        else: color = "black"
        row_data['combo'].config(foreground=color)

    def _apply_strategy_to_all(self):
        """[철저 점검] 태그 연쇄 조치에도 출처 우선 로직을 이식합니다."""
        strat = self.strategy_var.get()
        for r in self.rows_data:
            item = r['item']
            src = item['data_src']
            asis = r['asis']
            
            if strat == "HIDE_ALL":
                # 🎯 SYS는 가리고, USER는 상태에 따라 유지 또는 삭제
                tobe = 'HIDE' if src == 'SYS' or asis in ['EDIT', 'HIDE'] else 'DELETE'
            else: # SHOW SYS
                tobe = 'DELETE' if src == 'USER' else asis
            
            r['combo'].set(tobe)
            self._update_colors(r)

    def _on_execute(self):
        """[집행] 팝업 없이 RESULT 열에 직접 결과 기록"""
        choices = []
        for r in self.rows_data:
            asis, tobe = r['asis'], r['combo'].get()
            if asis == tobe and tobe != 'DELETE':
                r['res_lbl'].config(text="SKIPPED", fg="#BDC3C7"); continue
            
            action = 'LIVE' if tobe == 'LIVE' and r['item']['data_src'] == 'USER' else tobe
            choices.append({'type': r['item']['type'], 'pk': r['item']['pk'], 'action': action, 
                            'data_src': r['item']['data_src'], 'row_ref': r})

        if choices:
            success = self.engine.execute_cascade_action(choices)
            for c in choices:
                c['row_ref']['res_lbl'].config(text="SUCCESS" if success else "FAIL", 
                                              fg="#27AE60" if success else "#C0392B")
            if success and self.callback: self.callback()

# =========================================================
# 🎯 Cascade HIDE/DELETE - UNIT / LINK / TEXT
# =========================================================

class UniversalCascadeDialog(tk.Toplevel):
    """[최종 확정] 콤보박스 상시 노출, 색상 식별, RESULT 열 추가 및 팝업 제거 버전"""
    def __init__(self, master, engine, asset_type, asset_id, action_type, callback):
        super().__init__(master)
        self.engine, self.asset_type, self.asset_id = engine, asset_type, asset_id
        self.action_type, self.callback = action_type, callback
        
        self.title(i18n.t('WIN_CASCADE_DASH', "연쇄 조치 상태 대시보드"))
        self.geometry("1150x700")
        self.configure(bg="#F0F3F4")
        self.grab_set()
        
        self.rows_data = [] # 각 행의 위젯과 데이터를 관리
        self._setup_ui()
        self._load_data()

    def _setup_ui(self):
        # 🎯 1. 상단 타이틀
        tk.Label(self, text=i18n.t('UC_CASCADE_DASH','연쇄 조치 상태 대시보드 (Cascade Action Dashboard)'), 
                 font=("맑은 고딕", 16, "bold"), bg="#F0F3F4", pady=20, fg="#2C3E50").pack(fill="x")

        # 🎯 2. 전략 옵션 선택
        s_frame = tk.Frame(self, bg="#F0F3F4", pady=10)
        s_frame.pack(fill="x", padx=20)
        self.strategy_var = tk.StringVar(value="HIDE_ALL" if self.action_type == 'HIDE' else "SHOW_SYS")
        
        for text, val in [("전체 숨김 (HIDE ALL)", "HIDE_ALL"), ("원본 노출 (SHOW SYS)", "SHOW_SYS")]:
            tk.Radiobutton(s_frame, text=text, variable=self.strategy_var, value=val, 
                          font=BOLD_FONT, bg="#F0F3F4", command=self._apply_strategy_to_all).pack(side="left", padx=30)

        # 🎯 3. 헤더 영역 (반듯한 정렬을 위한 그리드 설정)
        header_f = tk.Frame(self, bg="#34495E", pady=8)
        header_f.pack(fill="x", padx=20, pady=(10, 0))
        
        # 컬럼 규격: AS-IS(80) | TO-BE(120) | ASSET(80) | TYPE(100) | NAME/VERSE(450) | RESULT(120)
        headers = [("AS-IS", 80), ("TO-BE", 120), ("ASSET", 80), ("TYPE", 100), ("NAME/VERSE", 450), ("RESULT", 120)]
        for i, (txt, w) in enumerate(headers):
            lbl = tk.Label(header_f, text=txt, width=w//8, fg="white", bg="#34495E", font=BOLD_FONT, anchor="center")
            if txt == "NAME/VERSE": lbl.config(anchor="w")
            lbl.pack(side="left")

        # 🎯 4. 스크롤 가능한 본문 영역
        canvas_f = tk.Frame(self, bg="white")
        canvas_f.pack(fill="both", expand=True, padx=20, pady=(0, 10))
        
        self.canvas = tk.Canvas(canvas_f, bg="white", highlightthickness=0)
        scroll = ttk.Scrollbar(canvas_f, orient="vertical", command=self.canvas.yview)
        self.scroll_frame = tk.Frame(self.canvas, bg="white")
        
        self.canvas.create_window((0, 0), window=self.scroll_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=scroll.set)
        
        self.canvas.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.scroll_frame.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))

        # 🎯 5. 하단 실행 버튼
        b_frame = tk.Frame(self, bg="#F0F3F4", pady=15)
        b_frame.pack(fill="x")
        tk.Button(b_frame, text=i18n.t('UC_EXECUTE',' 조치 집행 (Execute) '), width=22, bg="#2E86C1", fg="white", 
                  font=BOLD_FONT, relief="flat", command=self._execute_action).pack(side="right", padx=30)
        tk.Button(b_frame, text=i18n.t('COMMON_CANCEL','취소'), width=10, relief="flat", command=self.destroy).pack(side="right")

    def _load_data(self):
        res = self.engine.process('CASCADE_INFO', self.asset_type, filters={'pk': self.asset_id})
        if res.get('status') == 'success':
            for item in res.get('data', []):
                self._add_row(item)
            self._apply_strategy_to_all()

    def _add_row(self, item):
        row_f = tk.Frame(self.scroll_frame, bg="white", pady=2)
        row_f.pack(fill="x")
        
        asis = BibleUI.get_safe_status(item.get('status'))
        
        # 1. AS-IS (Label)
        tk.Label(row_f, text=asis, width=10, bg="white", font=DEFAULT_FONT).pack(side="left")
        
        # 2. TO-BE (Combobox - 처음부터 표시)
        combo = ttk.Combobox(row_f, values=['HIDE', 'DELETE', 'LIVE'], width=12, state="readonly")
        combo.pack(side="left", padx=10)
        combo.bind("<<ComboboxSelected>>", lambda e, r=row_f: self._update_row_colors(row_f))
        
        # 3. ASSET & TYPE
        tk.Label(row_f, text=item['type'], width=10, bg="white", font=DEFAULT_FONT).pack(side="left")
        tk.Label(row_f, text=item['subtype'], width=12, bg="white", font=DEFAULT_FONT).pack(side="left")
        
        # 4. NAME/VERSE (인덴트 적용)
        indent = "    " * item['depth']
        tk.Label(row_f, text=f"{indent}{item['name']}", width=60, bg="white", font=DEFAULT_FONT, anchor="w").pack(side="left")
        
        # 5. RESULT (Label)
        res_lbl = tk.Label(row_f, text="-", width=15, bg="white", font=BOLD_FONT, fg="#BDC3C7")
        res_lbl.pack(side="right", padx=10)
        
        self.rows_data.append({
            'item': item, 'asis': asis, 'combo': combo, 'res_lbl': res_lbl, 'frame': row_f
        })

    def _update_row_colors(self, row_frame_data):
        """[지시 반영] DELETE는 빨간색, 변경은 파란색, 유지는 검은색 적용"""
        asis = row_frame_data['asis']
        tobe = row_frame_data['combo'].get()
        
        if tobe == 'DELETE':
            color = "#C0392B" # 빨간색
        elif asis != tobe:
            color = "#2980B9" # 파란색
        else:
            color = "black"   # 검은색
            
        # 콤보박스 텍스트 색상 변경 (일부 OS/테마 제약이 있을 수 있어 폰트 스타일 병행)
        row_frame_data['combo'].config(foreground=color)

    def _apply_strategy_to_all(self):
        """[철저 점검] 출처(Source) 우선 로직으로 전략 매핑을 재설계합니다."""
        strat = self.strategy_var.get()
        for r in self.rows_data:
            item = r['item']
            src = item['data_src'] # 데이터 소스 (SYS 또는 USER)
            asis = r['asis']       # 현재 상태
            
            if strat == "HIDE_ALL":
                # 🎯 HIDE ALL 전략: 저승(SYS)은 무조건 가리고, 이승(USER)은 상태에 따라 조치
                if src == 'SYS':
                    tobe = 'HIDE' # SYS는 어떤 상태(DRAFT 등)든 가림막 생성
                else: # USER 레코드인 경우
                    # EDIT, HIDE는 유지/전환하고, 뿌리 없는 NEW는 제거
                    tobe = 'HIDE' if asis in ['EDIT', 'HIDE'] else 'DELETE'
            
            else: # SHOW SYS 전략: 이승의 가림막을 모두 걷어냄
                if src == 'USER':
                    tobe = 'DELETE' # USER 레코드를 지워 SYS를 부활시킴
                else:
                    tobe = asis     # SYS는 현재 상태(LIVE/DRAFT)를 그대로 유지
            
            r['combo'].set(tobe)
            self._update_row_colors(r)


    def _execute_action(self):
        """[집행] 팝업 없이 RESULT 열에 직접 결과 기록"""
        choices = []
        for r in self.rows_data:
            asis, tobe = r['asis'], r['combo'].get()
            if asis == tobe and tobe != 'DELETE': # 변화 없는 항목은 스킵 (단, DELETE는 항상 집행)
                r['res_lbl'].config(text="SKIPPED", fg="#BDC3C7")
                continue
                
            item = r['item']
            action = 'LIVE' if tobe == 'LIVE' and item['data_src'] == 'USER' else tobe
            choices.append({'type': item['type'], 'pk': item['pk'], 'action': action, 'data_src': item['data_src'], 'row_ref': r})

        if not choices:
            self.destroy()
            return

        success = self.engine.execute_cascade_action(choices)
        
        # 🎯 RESULT 열 업데이트 (팝업 메시지 삭제)
        for choice in choices:
            r = choice['row_ref']
            r['res_lbl'].config(text="SUCCESS" if success else "FAIL", 
                                fg="#27AE60" if success else "#C0392B")
        
        if success:
            self.callback()
            # 💡 집행 성공 후 사용자가 결과를 확인할 수 있도록 창을 바로 닫지 않고 '완료' 상태 유지
            # 사용자가 수동으로 닫거나 취소를 누를 때 닫힘


# =========================================================
# 🎯 [표준 규격 매트릭스] 데이터와 표시 장소의 일관성 헌법
# =========================================================
# 사용자님이 정의하신 20개의 마이크로 부품 규격을 공식 등록합니다.
COMPONENT_MATRIX = {
    # 1. 유닛 리스트 (Treeview)
    'CONT_list': {'base': 'LIST', 'cols': [("이름", 150), ("ID", 40), ("상태", 70)], 'tools': 'CRUD'},
    'NODE_list': {'base': 'LIST', 'cols': [("이름", 150), ("ID", 40), ("상태", 70)], 'tools': 'CRUD'},

    # 2. 링크 리스트 (Treeview)
    'CN_list':   {'base': 'LIST', 'cols': [("이름", 150), ("ID", 40), ("링크상태", 60), ("자산상태", 60)], 'tools': 'LINK'},
    'NV_list':   {'base': 'LIST', 'cols': [("본문", 400), ("ID", 40), ("상태", 70)], 'tools': 'LINK'},
    'VV_list':   {'base': 'LIST', 'cols': [("본문", 400), ("ID", 40), ("상태", 70)], 'tools': 'LINK'},

    # 3. 유닛/연결 설명문 (Text + Header)
    'CONT_desc': {'base': 'DESC', 'has_header': True,  'title': '컨테이너 설명'},
    'NODE_desc': {'base': 'DESC', 'has_header': True,  'title': '노드 상세 설명'},
    'CN_desc':   {'base': 'DESC', 'has_header': True,  'title': '연결 사유 (C-N)'},
    'NV_desc':   {'base': 'DESC', 'has_header': True,  'title': '연결 사유 (N-V)'},
    'VV_desc':   {'base': 'DESC', 'has_header': True,  'title': '대등 연결 사유'},

    # 4. 순수 텍스트 (Text Only)
    'COMM_desc': {'base': 'DESC', 'has_header': True,  'title': '성경 주석'},
    'NOTE_desc':     {'base': 'DESC', 'has_header': True, 'title': '참조 및 노트'},
    'QUESTION_desc': {'base': 'DESC', 'has_header': True, 'title': '묵상 질문'},
    'PRAYER_desc':   {'base': 'DESC', 'has_header': True, 'title': '기도문'},

    # 5. 태그 전용 (Header Only)
    'CONT_tag': {'base': 'TAG', 'title': '컨테이너 태그'},
    'NODE_tag': {'base': 'TAG', 'title': '노드 태그'},
    'VERS_tag': {'base': 'TAG', 'title': '구절 태그'},
}

class ComponentFactory:
    """[표준 부품 공장] 명칭에 맞는 마이크로 패널을 찍어내는 조립 장치"""
    
    @staticmethod
    def create(parent, comp_name, mode='user_query'):
        """사용자 정의 명칭(comp_name)을 해석하여 규격 부품을 생성합니다."""
        spec = COMPONENT_MATRIX.get(comp_name)
        if not spec:
            raise ValueError(f"[설계 오류] '{comp_name}'은 정의되지 않은 규격입니다.")

        if spec['base'] == 'LIST':
            title = spec.get('title', comp_name)
            frame, widgets = BibleUI.ListPanel(parent, title, spec['cols'], mode=mode, tools=spec['tools'])

            # 🎯 [배관 확인] NV_list 전용 성경 선택 허브 삽입
            if comp_name == 'NV_list':
                # t_frame(상단 툴바)에 허브를 이식하고 widgets 주머니에 담습니다.
                hub = VerseSelectorHub(widgets['t_frame'], lambda v, l: None)
                hub.frame.pack(side="left", fill="x", expand=True)
                widgets['verse_hub'] = hub
        
        elif spec['base'] == 'DESC' or spec['base'] == 'TAG':
            frame, widgets = BibleUI.DescPanel(parent, spec['title'], mode=mode)
            if spec['base'] == 'DESC' and not spec.get('has_header', True):
                widgets['header_f'].pack_forget()
            if spec['base'] == 'TAG':
                widgets['desc'].pack_forget()

        # 안전장치: 부품 코드명 주입
        widgets['comp_name'] = comp_name
        return frame, widgets

#############################
## 
#############################

class BibleUI:
    @staticmethod
    def get_db_config(mode, key):
        """[본질] 설정값은 엔진을 통하지 않고 직접 DB에서 읽어 대문자로 반환합니다."""
        table = "sys_config" if mode == "sys" else "user_config"
        try:
            conn = appdb.connect("bible_master.db")
            res = conn.execute(f"SELECT config_val FROM {table} WHERE config_key = ?", (key,)).fetchone()
            conn.close()
            return res[0].upper() if res else "KO"
        except: return "KO"

    @staticmethod
    def get_status_list(mode, tools='CRUD'):
        """[최종] 패널 타입(유닛/링크/설명)에 따라 콤보박스 액션을 정밀하게 주입합니다."""
        # 🎯 1. DESC 패널 전용: 수정을 자동으로 하므로 집행(HIDE, DELETE)만 노출
        if tools == 'DESC':
            return ['HIDE', 'DELETE']

        # 2. 리스트 패널(UNIT/LINK) 전용 액션
        if mode == 'sys':
            # 관리자 영토: DRAFT/LIVE 제어 + 물리 삭제 + [NEW/ADD_LINK]
            base = ['LIVE', 'DRAFT', 'DELETE']
            if tools == 'CRUD': base.append('NEW')       # 유닛 리스트(P1, P3)
            if tools == 'LINK': base.append('ADD_LINK')  # 링크 리스트(P2, P6)
            return base
        elif mode == 'user_admin':
            # 사용자 영토: NEW/EDIT 제어 + 가리기(HIDE) + 물리 삭제 + [ADD_LINK]
            base = ['LIVE', 'NEW', 'EDIT', 'HIDE', 'DELETE']
            if tools == 'LINK': base.append('ADD_LINK')  # 링크 리스트(P2, P6)
            return base
        else: # user_query (조회 전용)
            return ['LIVE', 'NEW', 'EDIT']

    @staticmethod
    def get_safe_status(status, record_exists=True):
        """[최종 수리] null, None, 빈값, 'NONE' 문자열을 모두 'LIVE'로 강제 치환합니다."""
        if not record_exists: 
            return "NO DATA"
        s = str(status).upper() if status else "LIVE"
        if s in ['NONE', 'NULL', '']:
            return "LIVE"
        return s

###############################
#  상단 언어, 버전 설정/저장 기능
###############################

    @staticmethod
    def ConfigBar(parent, engine, on_save_callback=None):
        """[3단계 모드 확장] sys, user_admin, user_query 선택 가능"""
        frame = tk.Frame(parent, bg="#D5D8DC", pady=5)
        
        # 1. 모드 선택 (3단계 세분화)
        mode_f = tk.Frame(frame, bg="#D5D8DC")
        mode_f.pack(side="right", padx=10)
        tk.Label(mode_f, text=i18n.t('UC_MODE','모드:')).pack(side="left")
        # 💡 테스트와 운영을 동시에 잡는 3단계 콤보
        mode_combo = ttk.Combobox(mode_f, values=["sys", "user_admin", "user_query"], width=12, state="readonly")
        mode_combo.set("user_query"); mode_combo.pack(side="left")

        # 2. 언어 콤보 (sys_language: lang_code, lang_name_en)
        tk.Label(frame, text=''+i18n.t('COMMON_LANG','언어')+':', bg="#D5D8DC", font=("맑은 고딕", 9, "bold")).pack(side="left", padx=5)
        l_res = engine.process('FETCH', 'LANGUAGE')
        l_list = [f"{r['lang_code'].upper()} | {r['lang_name_en']}" for r in l_res.get('data', [])] if l_res.get('status') == 'success' else []
        l_combo = ttk.Combobox(frame, values=l_list, width=20, state="readonly")
        
        init_l = BibleUI.get_db_config(mode_combo.get(), "sys_lang" if mode_combo.get()=="sys" else "user_lang")
        l_combo.set(next((s for s in l_list if s.startswith(init_l)), ""))
        l_combo.pack(side="left", padx=5)

        # 3. 버전 콤보 (bible_version: version_code, version_name)
        tk.Label(frame, text=i18n.t('UC_BIBLEVER','성경버전:'), bg="#D5D8DC").pack(side="left", padx=5)
        v_res = engine.process('FETCH', 'VERSION')
        v_list = [f"{r['version_code'].upper()} | {r['version_name']}" for r in v_res.get('data', [])] if v_res.get('status') == 'success' else []
        v_combo = ttk.Combobox(frame, values=v_list, width=20, state="readonly")
        
        init_v = BibleUI.get_db_config(mode_combo.get(), "v1_code")
        v_combo.set(next((v for v in v_list if v.startswith(init_v)), ""))
        v_combo.pack(side="left", padx=5)

        # 4. 저장 버튼
        tk.Button(frame, text=i18n.t('UC_SAVESETTINGS',' 설정저장 '), bg="#ccffcc", font=("맑은 고딕", 9),
                  command=on_save_callback).pack(side="left", padx=5)

        return frame, l_combo, v_combo, mode_combo

###############################
#  CRUD 버튼 + record_status
###############################
    @staticmethod
    def CRUDBar(parent, mode, on_add=None, on_del=None, on_save=None):
        frame = tk.Frame(parent, bg="#D5D8DC")
        
        # 💡 모드에 따른 상태 리스트 분기
        if mode == 'sys':
            status_vals = ['DRAFT', 'LIVE', 'DEACT', 'DELT']
        elif mode == 'user_admin':
            status_vals = ['NEW', 'EDIT', 'HIDE', 'UNSHOW']
        else: # user_query
            status_vals = ['LIVE', 'NEW', 'EDIT']

        tk.Label(frame, text=i18n.t('COMMON_STATUS','상태')+':', bg="#D5D8DC").pack(side="left", padx=2)
        status_combo = ttk.Combobox(frame, values=status_vals, width=10, state="readonly")
        status_combo.set(status_vals[0]); status_combo.pack(side="left", padx=5)

        # 💡 관리자(sys)만 '추가/삭제' 버튼 노출 (사용자는 수정 위주)
        if mode == 'sys':
            if on_add: tk.Button(frame, text='➕ '+i18n.t('COMMON_ADD','추가'), command=on_add, width=5).pack(side="left", padx=2)
            if on_del: tk.Button(frame, text=''+i18n.t('COMMON_DELETE','삭제'), command=on_del, width=5).pack(side="left", padx=2)
        
        if on_save:
            tk.Button(frame, text="SAVE", command=on_save, width=7, bg="#e3f2fd").pack(side="left", padx=5)
            
        return frame, status_combo

###############################
#  LINK 버튼 + sort_order
###############################
    @staticmethod
    def LinkBar(parent, mode, on_link, on_unlink, on_up, on_down, on_save):
        """[확정] 중앙/성경 패널 상단: LINK 및 상태관리"""
        frame = tk.Frame(parent, bg="#D5D8DC")
        
        # 상태 관리 (LINK 자체의 상태)
        tk.Label(frame, text=i18n.t('COMMON_STATUS','상태')+':', bg="#D5D8DC").pack(side="left", padx=2)
        status_values = ['DRAFT', 'LIVE', 'DEACT', 'DELT'] if mode == 'sys' else ['NEW', 'EDIT', 'HIDE', 'UNSHOW']
        status_combo = ttk.Combobox(frame, values=status_values, width=8, state="readonly")
        status_combo.pack(side="left", padx=5)

        # LINK 버튼 (가로 배치로 상단 일관성 유지)
        tk.Button(frame, text=i18n.t('UC_CONNECT','▶ 연결'), command=on_link, bg="#ebf5fb").pack(side="left", padx=2)
        tk.Button(frame, text=i18n.t('UC_DISCONNECT','◀ 해제'), command=on_unlink, bg="#fdedec").pack(side="left", padx=2)
        tk.Button(frame, text="▲", command=on_up, width=3).pack(side="left", padx=1)
        tk.Button(frame, text="▼", command=on_down, width=3).pack(side="left", padx=1)
        tk.Button(frame, text="SAVE", command=on_save, bg="#ccffcc", font=("맑은 고딕", 9, "bold")).pack(side="left", padx=5)

        return frame, status_combo

###############################
#  패널 : 컨테이너, 노드, 구절
###############################

    @staticmethod
    def ListPanel(parent, title, columns, mode='user_query', tools='CRUD'):
        """[수리] 사라진 버튼들을 복구하고, 하단에 좁은 칩 영역(footer_f)을 신설합니다."""
        frame = tk.LabelFrame(parent, text=title, bg="#F4F6F7", font=("맑은 고딕", 10, "bold"))
        w = {}

        # 1. 상단 툴바 (버튼 복구)
        t_frame = tk.Frame(frame, bg="#D5D8DC")
        t_frame.pack(fill="x", side="top")
        w['t_frame'] = t_frame 

        # 🎯 콤보박스 배치
        vals = BibleUI.get_status_list(mode, tools=tools)
        w['combo'] = ttk.Combobox(t_frame, values=vals, width=10, state="readonly")
        w['combo'].set(vals[0]); w['combo'].pack(side="left", padx=5, pady=2)

        # 🎯 [복구] 위/아래 순서 조절 버튼 (UI 일관성 사수)
        icons = {'up':'▲', 'down':'▼'}
        for b in ['up', 'down']:
            # 💡 버튼 디자인을 더 작고 정교하게 수정
            w[b] = tk.Button(t_frame, text=icons[b], width=3, relief="flat", bg="#D5D8DC", overrelief="raised")
            w[b].pack(side="left", padx=1)

        # 2. 중앙 트리뷰 (공간 효율을 위해 height를 4로 소폭 조정)
        tree_f = tk.Frame(frame); tree_f.pack(fill="both", expand=True)
        w['tree'] = ttk.Treeview(tree_f, columns=[c[0] for c in columns], show="headings", height=4)
        for name, width in columns:
            w['tree'].heading(name, text=name); w['tree'].column(name, width=width, anchor="center")
        w['tree'].pack(fill="both", expand=True)

        # 🎯 3. [신설] 하단 칩 영역 (공간이 좁으므로 높이 최소화)
        w['footer_f'] = tk.Frame(frame, bg="#F8F9F9", height=20)
        w['footer_f'].pack(side="bottom", fill="x", padx=2, pady=1)

        return frame, w


##################
### Panel Desc  설명문 표준
##################

    @staticmethod
    def DescPanel(parent, title, mode, show_tags=False, show_parent=False, layout='flow'):
        """[최종] 저장 버튼을 제거하고 DESC 전용 콤보박스(HIDE/DELETE)를 구성합니다."""
        f = tk.LabelFrame(parent, text=title, bg="white", font=("Malgun Gothic", 10, "bold"))
        widgets = {}

        # 1. 헤더 컨테이너 (render_flow_header가 위젯들을 배치할 장소)
        widgets['header_f'] = tk.Frame(f, bg="#F8F9F9")
        widgets['header_f'].pack(side="top", fill="x", padx=2, pady=2)

        # 2. 본문 텍스트 영역
        widgets['desc'] = tk.Text(f, font=("Malgun Gothic", 11), undo=True, relief="flat", wrap="word")
        widgets['desc'].pack(fill="both", expand=True, padx=5, pady=5)

        # 🎯 [수정] 콤보박스: DESC 전용 (HIDE, DELETE) 액션 주입
        # 💡 get_status_list(mode, tools='DESC') 호출로 메뉴 필터링
        vals = BibleUI.get_status_list(mode, tools='DESC')
        widgets['combo'] = ttk.Combobox(f, values=vals, width=12, state="readonly")
        widgets['combo'].set("LIVE") # 기본값 고정
        
        # 🎯 [확정] widgets['save_btn'] 객체 생성 로직 삭제 (FocusOut 자동 저장 체계로 전환)

        return f, widgets

######################################
##  태그이름표  (class BibleUI 에 위치해야 함) 
######################################

    @staticmethod
    def render_flow_header(widgets, parents, tags, mode, current_status, 
                           combo_values=None, on_add_tag=None):
        """[정석 수리] 아이콘 생략, #기호 추가, 색상 구분을 통해 다중 계보를 압축 렌더링합니다."""
        if 'header_f' not in widgets: return 
        
        container = widgets['header_f']
        for child in container.winfo_children(): child.destroy()
        
        # 1. 🎯 [상단 행] 컨트롤 영역 (콤보박스 및 상태 배지)
        ctrl_row = tk.Frame(container, bg="#F8F9F9")
        ctrl_row.pack(side="top", fill="x", pady=2)

        if 'combo' in widgets:
            if combo_values: widgets['combo']['values'] = combo_values
            # 💡 폭을 6으로 압축하여 가로 공간을 확보합니다.
            widgets['combo'].config(width=6) 
            widgets['combo'].set(current_status if current_status else "LIVE")
            widgets['combo'].pack(in_=ctrl_row, side="left", padx=5)

        # 💡 [보완] current_status가 명시적으로 존재할 때만 배지를 그립니다.
        if current_status and current_status != "LIVE":
            color_map = {"NEW": "#27AE60", "EDIT": "#E67E22", "HIDE": "#7B241C", "DRAFT": "#8E44AD"}
            tk.Label(ctrl_row, text=f" {current_status} ", bg="#EBEDEF", 
                     fg=color_map.get(current_status, "#2E4053"), 
                     font=("Consolas", 8, "bold"), width=8).pack(side="left", padx=5)

        # 2. 🎯 [하단 행] 계보 칩 영역 (Parents & Tags)
        chip_container = tk.Frame(container, bg="#F8F9F9")
        chip_container.pack(side="top", fill="x", padx=5, pady=1)

        # (1) 📁 부모(Parents) 칩: 아이콘 생략, 연청색 배경
        for p_name in parents:
            tk.Label(chip_container, text=p_name, bg="#EBF5FB", fg="#2E86C1", 
                     font=("맑은 고딕", 8, "bold"), padx=6, pady=1).pack(side="left", padx=2)
            
        # (2) # 태그(Tags) 칩: '#' 기호 추가, 연노랑 배경
        for t_name in tags:
            display_tag = f"#{t_name}" if not t_name.startswith('#') else t_name
            tk.Label(chip_container, text=display_tag, bg="#FEF9E7", fg="#7D6608", 
                     font=("맑은 고딕", 8), padx=6, pady=1).pack(side="left", padx=2)

        if on_add_tag:
            tk.Button(chip_container, text="+", width=2, relief="flat", 
                      bg="#D5DBDB", font=("Arial", 7, "bold"), command=on_add_tag).pack(side="left", padx=5)

################################################################
### 성경구절(창1:1 ...) 표시기 : bible_index + bible_content + book_names 결합
################################################################

class BibleRenderer:
    @staticmethod
    def render_full_verse(row):
        """
        [징검다리 핵심] 성경 자산 데이터를 받아 '창1:1 본문' 형태로 조립
        사용자님의 방어 로직(BIBLE ID 출력)을 그대로 보존합니다.
        """
        if not row: return ""
        try:
            # sqlite3.Row와 dict 모두 대응
            bname = row.get('short_name') or row.get('bcode') or ""
            chap = row.get('chapter') or ""
            vers = row.get('verse') or ""
            address = f"{bname}{chap}:{vers}" if bname else ""
            content = row.get('verse_text') or ""
            return f"{address} {content}".strip()
        except (AttributeError, TypeError):
            # 💡 사용자님의 우수한 디버깅 로직을 유지합니다.
            return f"BIBLE ID: {row.get('verse_id') if row else 'Unknown'}"

    @staticmethod
    def verse_line(row):
        """3단 리스트 표시 형식: 창1:1 본문내용"""
        return f"{row.get('book_abbr','')}{row.get('chapter','')}:{row.get('verse','')} {row.get('verse_text','')}"

def get_verse_display(data):
    """엔진이나 UI에서 직관적으로 호출하기 위한 래퍼 함수"""
    return BibleRenderer.render_full_verse(data)

###############################################################################
### rel_name 표시기 : VERS_VERS 연결관계의 유형 표시기, sys_rel_catalog와 조인 , 엔진가동에 필수품
###############################################################################

class RelRenderer:
    @staticmethod
    def get_rel_name(conn, rel_code, lang='KO'):
        """[수정 2026-06-01] rel_code → 실명. lang 누락 시 SQLite가 임의 lang 행을 반환하여
        아랍어·중국어 등이 섞여 표시되던 버그 fix. KO 우선 → 사용자 lang → EN fallback."""
        if not rel_code: return ""
        try:
            lang_u = (lang or 'KO').upper()
            # 사용자 lang 우선 → KO fallback → EN fallback
            sql = """
                SELECT rel_name FROM sys_rel_catalog
                 WHERE rel_code = ?
                   AND lang_code IN (?, 'KO', 'EN')
                 ORDER BY CASE lang_code WHEN ? THEN 1 WHEN 'KO' THEN 2 ELSE 3 END
                 LIMIT 1
            """
            res = conn.execute(sql, (rel_code, lang_u, lang_u)).fetchone()
            return res[0] if res else rel_code
        except Exception:
            return rel_code

###############################################################################
### ###############################################################################

class AssetRenderer:
    @staticmethod
    def get_name(conn, asset_type, row, rel_code=None, lang='KO'):
        """
        [최종 수리] 엔진의 다국어 정책과 3단계 모드 상태를 이름에 완벽 투사합니다.
        - rel_name: [관계명] 형식으로 접두어 부착
        - fetch_name: 언어설정(KO/EN) 및 (H) 가림막 표시가 반영된 실명 최우선
        [수정 2026-06-01] lang 매개변수 추가 — sys_rel_catalog 다국어 행에서 사용자 lang 선택.
        """
        if not row: return "NO ROW"

        # 1. 🎯 [관계명 사냥] rel_code를 실명(예: [평행])으로 변환하여 접두어 생성
        # RelRenderer는 sys_rel_catalog를 참조하여 이름을 가져옵니다.
        rel_name = RelRenderer.get_rel_name(conn, rel_code, lang) if rel_code else ""
        rel_prefix = f"[{rel_name}] " if rel_name else ""

        # 2. 🎯 [실명 우선 원칙] 엔진의 _apply_display_policy가 생성한 'fetch_name'을 최우선 신뢰
        # 여기에는 이미 'Gen 1:1' 또는 '창 1:1'과 상태 배지 (H)가 포함되어 있습니다.
        name = row.get('fetch_name')

        # 3. 🎯 [데이터 보정] fetch_name이 없을 경우를 대비한 자산별 수동 로직
        if not name:
            if asset_type == 'BIBLE':
                # 직접 BibleRenderer를 호출하여 주소 조립
                name = BibleRenderer.render_full_verse(row)
            elif asset_type == 'TEXT':
                # 텍스트 자산은 타입과 내용 일부를 표시
                name = f"{row.get('text_type')}: {str(row.get('contents', ''))[:30]}"
            else:
                # 유닛 또는 태그의 원본 필드 탐색
                name = row.get('unit_name_sid') or row.get('tag_name_sid') or row.get('contents')

        # 4. 🎯 [최후의 보루] 이름이 여전히 없다면 ID를 출력하여 시스템 미아 방지
        if not name:
            # sys/user 테이블의 다양한 PK 컬럼명을 전수 조사
            pk = (row.get('pk') or row.get('user_unit_id') or 
                  row.get('sys_unit_id') or row.get('user_link_id') or "Unknown")
            name = f"미식별 자산 (ID: {pk})"
            
        return f"{rel_prefix}{name}"


########################
#  성경구절 선택 + 프리뷰 
########################

class VerseSelectorHub:
    """[수리] selected_verse_id 속성을 추가하여 AttributeError를 해결합니다."""
    def __init__(self, parent, on_preview_request):
        self.frame = tk.Frame(parent, bg="#D5D8DC", pady=2)
        self.on_preview = on_preview_request
        self.combos = {}
        # 🎯 [핵심 추가] 연결(Link) 시 엔진에 전달할 성경 구절 PK 저장소
        self.selected_verse_id = None 
        
        # 권, 장, 절 선택 콤보박스 배치
        ctrl_f = tk.Frame(self.frame, bg="#D5D8DC")
        ctrl_f.pack(side="top", fill="x")
        for label in ["Book", "Chap", "Vers"]:
            tk.Label(ctrl_f, text=label, bg="#D5D8DC", font=("Arial", 8)).pack(side="left", padx=1)
            cb = ttk.Combobox(ctrl_f, width=6, state="readonly")
            cb.pack(side="left", padx=1)
            cb.bind("<<ComboboxSelected>>", self._trigger_preview)
            self.combos[label] = cb

        # 본문 프리뷰 라벨
        self.preview_lbl = tk.Label(self.frame, text=i18n.t('UC_SELECTVERSE','... 구절을 선택하세요 ...'), 
                                    bg="white", fg="#2E4053", anchor="w", font=("맑은 고딕", 8), height=1)
        self.preview_lbl.pack(side="bottom", fill="x", padx=5, pady=1)

    def _trigger_preview(self, event):
        """콤보박스 선택 시 부모에게 프리뷰 데이터를 요청합니다."""
        vals = {k: v.get() for k, v in self.combos.items()}
        if all(vals.values()):
            self.on_preview(vals, self.preview_lbl)

