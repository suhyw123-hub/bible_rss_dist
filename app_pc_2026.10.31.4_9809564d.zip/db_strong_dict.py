# -*- coding: utf-8 -*-
"""스트롱 사전을 **사전 목록에 등록한다** — 행을 복제하지 않고.

    python db_strong_dict.py --selftest
    python db_strong_dict.py --check     # 무엇이 달라지나(안 건드린다)
    python db_strong_dict.py --apply     # 등록(멱등)
    python db_strong_dict.py --undo      # 등록만 걷는다(낱말은 안 건드린다)

★★★ **「추가」가 아니라 「등록」이다**(2026-09-18 사용자 「스트롱사전 추가
  필요」). 스트롱은 **이미 다 있다** — `sys_lemma_master` **14,298 낱말 ·
  정의문 13,938**이고 주요용어 앵커도 **11,068 낱말**에 붙어 있다.
  없던 것은 **사전 목록에 이름이 없다는 것**뿐이라 사전관리 화면이 그것을
  못 봤다(`sys_ref_source` 에 Easton·Smith 둘뿐).

★★★ **`sys_ref_unit` 을 만들지 않는다 — 가상 사전이다.**
  ⚠⚠ 14,298행을 복제하면 ⓐ 같은 글이 두 자리에 살아 **반드시 갈라지고**
    ⓑ 코어팩이 그만큼 부풀고 ⓒ 고치는 문이 둘이 된다.
  ⇒ 등록하는 것은 **`sys_ref_source` 한 줄**뿐이고, 항목은 화면이
    `sys_lemma_master` 에서 그때 읽는다(`units` · `count`).

⚠ **빈 서랍을 만들지 않는다**(§0-1) — 세는 문(`count`)과 읽는 문(`units`)을
  여기 두어 화면이 그것을 쓴다. 등록만 하고 화면이 `sys_ref_unit` 을 세면
  **「0개」짜리 사전**이 목록에 뜬다.
⚠ **고치는 자리는 여기가 아니다** — 낱말 정의문은 우리가 쓴 글이 아니라
  퍼블릭 도메인 사전이고, 번역문은 `LEMMA_DEF`(`overlay_read.lemma_text`)가
  맡는다. 화면이 그 사실을 한 줄로 말한다(`WHERE_TO_EDIT`).
"""
import sys

#: 가상 사전의 코드 — 화면·도구가 이 이름으로 가른다
CODE = 'STRONG_LEX'
TBL = 'sys_lemma_master'

#: 사전 목록에 보일 이름(짧은 것 · `panel_dict_manager._DICT_NAME` 과 짝)
NAME = 'Strong'

#: 화면이 「여기서 못 고친다」를 말할 때 쓰는 글
WHERE_TO_EDIT = (
    '스트롱 사전 항목은 여기서 고치지 않습니다. 번역문은 주요용어 화면의 '
    '원어 사전이 맡고, 용어와 잇는 것은 주요용어 관리 ▸ 승격/원복 입니다.')

_META = {
    'src_code': CODE,
    'src_type': 'DICTIONARY',
    'mapping_type': 'STRONG',
    'title': "Strong's Exhaustive Concordance — Hebrew/Greek Lexicon",
    'author': 'James Strong',
    'pub_year': 1890,
    'lang_code': 'EN',
    'coverage_scope': 'FULL',
    'copyright_type': 'PUBLIC_DOMAIN',
    'source_url': '',
    'title_ko': '스트롱 원어사전',
}
_DESC = ('스트롱 번호별 히브리·헬라 낱말 사전. **항목을 여기에 복제하지 '
         '않는다** — 낱말 마스터(sys_lemma_master)가 그대로 정본이고 이 줄은 '
         '사전 목록에 이름을 세우는 자리다(가상 사전).')


# ── 재료 ─────────────────────────────────────────────────────────────
def _has(conn, tbl):
    return bool(conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
        (tbl,)).fetchone())


def src_id(conn):
    """등록된 가상 사전의 `ref_src_id` 또는 None."""
    r = conn.execute("SELECT ref_src_id FROM sys_ref_source WHERE src_code=?",
                     (CODE,)).fetchone()
    return r[0] if r else None


def is_virtual(conn, ref_src_id):
    """그 사전이 **가상 사전**인가 — 화면이 이것으로 가른다."""
    if ref_src_id is None:
        return False
    return src_id(conn) == ref_src_id


def count(conn):
    """스트롱 낱말 수(LIVE). 표가 없으면 0."""
    if not _has(conn, TBL):
        return 0
    return int(conn.execute(
        "SELECT COUNT(*) FROM %s WHERE COALESCE(record_status,'LIVE')='LIVE'"
        % TBL).fetchone()[0])


def fold(s):
    """분음 기호를 걷고 소문자로 — **찾기 전용**.

    ★ 저장된 글자는 안 바꾼다. 견주는 순간에만 접는다.
    ⚠ `ʼ`(U+02BC)·`ʻ` 는 결합 문자가 아니라 **낱 글자**라 따로 걷는다.
    """
    import unicodedata
    s = unicodedata.normalize('NFD', str(s or ''))
    out = []
    for ch in s:
        if unicodedata.combining(ch):
            continue
        if ch in '\u02bc\u02bb\u2018\u2019\u00b4`\'':
            continue
        out.append(ch)
    return ''.join(out).lower()


def units(conn, q='', limit=500, offset=0):
    """항목 목록 → `[(strong, 원어, 음역, 뜻, 정의앞부분, 이어진 용어 수)]`.

    ⚠ **상한이 있다**(기본 500) — 14,298개를 한 번에 그리면 화면이 멎는다.
      잘렸으면 부르는 쪽이 그렇게 적는다(§0-1).
    """
    if not _has(conn, TBL):
        return []
    sql = ("SELECT m.strong, COALESCE(m.form,''), COALESCE(m.translit,''),"
           " COALESCE(m.gloss,''), COALESCE(m.def_en,''),"
           " (SELECT COUNT(*) FROM sys_entity_lemma el"
           "   WHERE el.strong = m.strong)"
           "  FROM %s m"
           " WHERE COALESCE(m.record_status,'LIVE')='LIVE'"
           # ★ 히브리(구약)를 먼저 — 글자 정렬이면 EL 이 HE 앞에 온다
           " ORDER BY CASE m.lang_code WHEN 'HE' THEN 0 ELSE 1 END,"
           "          CAST(substr(m.strong,2) AS INTEGER)" % TBL)
    q = (q or '').strip()
    if not q:
        # ⚠ 찾지 않을 때는 SQL 이 자르게 둔다(14,174행을 다 읽지 않는다)
        return [tuple(r) for r in conn.execute(
            sql + ' LIMIT ? OFFSET ?', [int(limit), int(offset)])]
    # ★★ 찾을 때는 **접어서** 견준다 — `LIKE` 로는 `agápē` 를 못 찾는다
    key = fold(q)
    out, skipped = [], 0
    for r in conn.execute(sql):
        hay = fold('%s %s %s %s' % (r[0], r[1], r[2], r[3]))
        if key not in hay:
            continue
        if skipped < int(offset):
            skipped += 1
            continue
        out.append(tuple(r))
        if len(out) >= int(limit):
            break
    return out


# ── 등록 ─────────────────────────────────────────────────────────────
def check(conn):
    """무엇이 달라지나 → `(할 일 있음?, 사람이 읽는 말)`. **안 건드린다.**"""
    n = count(conn)
    if not n:
        return False, '낱말 마스터가 비어 있다 — 등록할 것이 없다'
    sid = src_id(conn)
    if sid:
        return False, ('이미 등록돼 있다(ref_src_id=%d) · 낱말 %s개'
                       % (sid, f'{n:,}'))
    return True, ('사전 목록에 「%s」 한 줄을 세운다 · 낱말 %s개 '
                  '(**항목은 복제하지 않는다**)' % (CODE, f'{n:,}'))


def apply(conn):
    """등록한다(멱등) → `ref_src_id`."""
    sid = src_id(conn)
    cols = list(_META.keys()) + ['description', 'record_status']
    vals = list(_META.values()) + [_DESC, 'LIVE']
    if sid:
        conn.execute("UPDATE sys_ref_source SET %s WHERE ref_src_id=?"
                     % ', '.join('%s=?' % c for c in cols), vals + [sid])
    else:
        conn.execute("INSERT INTO sys_ref_source (%s) VALUES (%s)"
                     % (', '.join(cols), ','.join('?' * len(cols))), vals)
        sid = src_id(conn)
    conn.commit()
    return sid


def undo(conn):
    """등록만 걷는다 → 걷었는가.

    ⚠⚠ **낱말 마스터는 한 줄도 안 건드린다** — 이 도구가 만든 것이 아니다.
    ⚠ 혹시 사람이 `sys_ref_unit` 을 붙였으면 **지우지 않고 거부한다**
      (남의 것을 지우지 않는다).
    """
    sid = src_id(conn)
    if not sid:
        return False
    n = conn.execute("SELECT COUNT(*) FROM sys_ref_unit WHERE ref_src_id=?",
                     (sid,)).fetchone()[0]
    if n:
        raise RuntimeError('항목 %d개가 붙어 있다 — 손으로 살펴본다' % n)
    conn.execute("DELETE FROM sys_ref_source WHERE ref_src_id=?", (sid,))
    conn.commit()
    return True


# ── 자가 검증 ────────────────────────────────────────────────────────
def _selftest():
    import sqlite3
    ok, bad = [0], []

    def chk(n, cond, extra=''):
        if cond:
            ok[0] += 1
        else:
            bad.append(n)
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', n, extra))

    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE sys_ref_source(ref_src_id INTEGER PRIMARY KEY, src_code TEXT,
        src_type TEXT, mapping_type TEXT, title TEXT, author TEXT,
        pub_year INTEGER, lang_code TEXT, coverage_scope TEXT,
        copyright_type TEXT, source_url TEXT, description TEXT,
        record_status TEXT, title_ko TEXT, description_ko TEXT);
      INSERT INTO sys_ref_source(src_code, src_type, record_status)
        VALUES('EASTON_DICT','DICTIONARY','LIVE');
      CREATE TABLE sys_ref_unit(ref_unit_id INTEGER PRIMARY KEY,
        ref_src_id INTEGER, unit_label TEXT, record_status TEXT);
      CREATE TABLE sys_lemma_master(strong TEXT, lang_code TEXT, form TEXT,
        translit TEXT, gloss TEXT, def_en TEXT, record_status TEXT);
      CREATE TABLE sys_entity_lemma(entity_id INTEGER, strong TEXT);
      INSERT INTO sys_lemma_master VALUES
        ('H835','HE','אֶשֶׁר','esher','복','blessedness','LIVE'),
        ('H1','HE','אָב','ab','아버지','father','LIVE'),
        ('G26','EL','ἀγάπη','agape','사랑','love','LIVE'),
        ('H999','HE','x','x','x','x','HIDE');
      INSERT INTO sys_entity_lemma VALUES(1,'H835'),(2,'G26'),(3,'G26');
    """)
    try:
        chk('낱말은 LIVE 만 센다', count(c) == 3, count(c))
        # ⓐ check 는 안 건드린다
        todo, why = check(c)
        n0 = c.execute('SELECT COUNT(*) FROM sys_ref_source').fetchone()[0]
        chk('할 일이 있다고 말한다', todo and '복제하지 않는다' in why, why)
        chk('check 는 안 건드린다', n0 == 1, n0)

        # ⓑ 등록
        sid = apply(c)
        chk('사전 목록에 한 줄', src_id(c) == sid and sid is not None, sid)
        chk('★★ **항목을 복제하지 않는다**',
            c.execute('SELECT COUNT(*) FROM sys_ref_unit').fetchone()[0] == 0)
        chk('가상 사전으로 가른다', is_virtual(c, sid))
        chk('Easton 은 가상이 아니다', not is_virtual(c, 1))
        chk('없는 번호도 가상이 아니다', not is_virtual(c, None))
        chk('퍼블릭 도메인으로 적는다',
            c.execute("SELECT copyright_type FROM sys_ref_source"
                      " WHERE src_code=?", (CODE,)).fetchone()[0]
            == 'PUBLIC_DOMAIN')

        # ⓒ 멱등
        again = apply(c)
        chk('두 번 걸어도 한 줄',
            again == sid and c.execute(
                "SELECT COUNT(*) FROM sys_ref_source WHERE src_code=?",
                (CODE,)).fetchone()[0] == 1)
        todo2, why2 = check(c)
        chk('이미 등록됐다고 말한다', (not todo2) and '이미' in why2, why2)

        # ⓓ 항목 목록
        rows = units(c)
        chk('항목이 낱말에서 온다', len(rows) == 3, len(rows))
        chk('이어진 용어 수를 함께 센다',
            dict((r[0], r[5]) for r in rows).get('G26') == 2,
            [(r[0], r[5]) for r in rows])
        chk('가린 낱말은 안 낸다', all(r[0] != 'H999' for r in rows))
        chk('★ 히브리가 먼저 · 번호 차례(글자 정렬이 아니다)',
            [r[0] for r in rows] == ['H1', 'H835', 'G26'],
            [r[0] for r in rows])
        chk('찾기가 원어로도 듣는다',
            [r[0] for r in units(c, 'agape')] == ['G26'],
            [r[0] for r in units(c, 'agape')])
        chk('접기 — 분음 기호를 걷는다',
            fold('agápē') == 'agape' and fold('ʼesher') == 'esher'
            and fold('cheçed') == 'checed',
            (fold('agápē'), fold('ʼesher'), fold('cheçed')))
        chk('찾기가 번호로도 듣는다',
            [r[0] for r in units(c, 'H835')] == ['H835'])
        chk('상한이 듣는다', len(units(c, limit=1)) == 1)
        chk('건너뛰기가 듣는다', units(c, limit=1, offset=1)[0][0] == 'H835',
            units(c, limit=1, offset=1)[0][0])
        chk('상한에 닿으면 부르는 쪽이 안다', len(units(c, limit=2)) == 2)

        # ⓔ 되돌리기
        chk('되돌린다', undo(c) and src_id(c) is None)
        chk('낱말은 안 건드린다', count(c) == 3)
        chk('없는데 또 되돌려도 조용하다', undo(c) is False)

        # ⓕ 항목이 붙어 있으면 거부한다
        sid = apply(c)
        c.execute("INSERT INTO sys_ref_unit(ref_src_id, unit_label,"
                  " record_status) VALUES(?,?,'LIVE')", (sid, 'x'))
        try:
            undo(c)
            chk('★ 남의 항목이 있으면 거부한다', False, '지웠다')
        except RuntimeError:
            chk('★ 남의 항목이 있으면 거부한다', True)
        c.execute('DELETE FROM sys_ref_unit')
        undo(c)

        # ⓖ 낱말 마스터가 비면 등록하지 않는다
        c.execute('DELETE FROM sys_lemma_master')
        todo3, why3 = check(c)
        chk('낱말이 없으면 등록 안 한다', (not todo3) and '비어' in why3, why3)
    finally:
        c.close()

    # ⓗ 실 DB — 읽기만
    try:
        import appdb
        rc = appdb.connect()
        n = count(rc)
        r = units(rc, limit=3)
        chk('실 DB 낱말 수가 나온다', n > 10000, f'{n:,}')
        # ★★ **사람이 치는 대로 찾아지는가** — 실 DB 로 잰다
        for typed, want in (('agape', 'G26'), ('esher', 'H835'),
                            ('checed', 'H2617')):
            got = [x[0] for x in units(rc, typed, limit=50)]
            chk('「%s」로 %s 를 찾는다' % (typed, want), want in got, got[:4])
        chk('실 DB 항목이 나온다 — 히브리부터',
            len(r) == 3 and [x[0] for x in r] == ['H1', 'H2', 'H3'],
            [x[0] for x in r])
        rc.close()
    except Exception as e:                                    # noqa: BLE001
        chk('실 DB', False, e)

    print('db_strong_dict selftest %d/%d' % (ok[0], ok[0] + len(bad)))
    for n in bad:
        print('  X', n)
    return not bad


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--undo', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return 0 if _selftest() else 1
    import appdb
    c = appdb.connect()
    try:
        if a.apply:
            print('등록: ref_src_id =', apply(c))
        elif a.undo:
            print('걷음' if undo(c) else '등록돼 있지 않다')
        else:
            todo, why = check(c)
            print('%s %s' % ('할 일 있음 ·' if todo else '할 일 없음 ·', why))
        return 0
    finally:
        c.close()


if __name__ == '__main__':
    sys.exit(main())
