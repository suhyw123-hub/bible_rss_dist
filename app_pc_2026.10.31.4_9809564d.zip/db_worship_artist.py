# -*- coding: utf-8 -*-
"""찬양 사역자 표 — CCM 의 첫 층 (2026-09-09 신설 · 영구 도구 · 멱등).

사용자 지시(2026-09-09) — 「아마추어의 영상 보다는 **베델, 힐송, 아가파오,
레비스탕스 등 프로 사역자 영상을 주로 저장**하자 · **국가별로도 다양한 사역자들**이
있을 것이다 · **사역자 테이블도 필요할 것이다**」 ·
「**사역자 정보가 없으면 있는 것만(예:이름) 최대한 포함하면 된다**」.

★★★ **채널이 곧 사역자가 아니다** — 실측 찬양 257편이 채널 115개에서 왔고 그중
  **91개가 1편짜리**다. 「찬양노트 ccm」처럼 여러 사역자의 곡을 모아 올리는 채널이
  있고, MARKERS WORSHIP 처럼 사역팀 자신의 채널이 있다.
  ⇒ 표를 따로 세우고 **영상마다** 잇는다(`MEDI_ARTI`). 공식 채널이 있으면
    `channel_ext_id` 에 적어 두고 `autolink` 가 그 채널 영상을 자동으로 잇는다.

★★★ **이름 하나만 있어도 등록한다**(사용자 원칙). 나라·갈래·채널은 전부 비어도
  된다 — **모르는 것을 지어내지 않는다**(§0-1b). 나중에 알게 되면 채운다.

★★ **이름은 다국어라 `sys_text_asset('ARTIST_NAME')` 에 둔다**(§0-3 규칙 1) —
  「힐송」/「Hillsong Worship」·「讚美之泉」/「Stream of Praise」처럼 언어마다 표기가
  다르다. 표에는 **코드·나라·갈래**만(조회·거르기에 쓰는 것).

⚠ **새 표를 만들었으면 `db_pack_catalog` 에 분류를 적는다** — 안 적으면 그쪽
  selftest 가 「분류 안 된 표」로 잡는다(§195차 ⑨).
"""
import json
import sys

import appdb

DB = 'bible_master.db'
TBL = 'sys_worship_artist'
NAME_TYPE = 'ARTIST_NAME'
LINK = 'MEDI_ARTI'

#: 갈래 — 조회로 가르는 값이라 코드다(이름은 화면이 i18n 으로 짓는다).
KINDS = ('TEAM', 'SOLO', 'CHURCH', 'LABEL')

#: ★ 씨앗 — **실측으로 확인한 채널**과 사용자가 든 프로 사역팀.
#:   `(코드, {언어: 이름}, 나라, 갈래, 채널 id, 채널 이름)` — 모르면 `None`.
#: ⚠ 영문 표기·나라가 확실치 않으면 **비워 둔다**(레비스탕스가 그 자리다).
SEED = [
    # 한국 — 실측 채널
    ('MARKERS', {'KO': '마커스워십', 'EN': 'MARKERS WORSHIP'}, 'KR', 'TEAM',
     'UCrnxDS-QclED-ej-MFxr8tA', 'MARKERS WORSHIP'),
    ('JUSTJESUS', {'KO': '저스트 지저스 예배', 'EN': 'Just Jesus Worship'}, 'KR', 'TEAM', None,
     'Just Jesus Worship 저스트 지저스 예배'),
    ('BETHEL_KR', {'KO': '베델 오브 코리아', 'EN': 'BETHEL OF KOREA'}, 'KR', 'TEAM',
     'UCN0GiQHs5hNYpXMk052wNdw', 'BETHEL OF KOREA'),
    ('WORSHIPSOUND', {'KO': '예배하는소리'}, 'KR', 'TEAM',
     'UCG-qZnxcKMebhz7bwpc4npg', '예배하는소리'),
    # 한국 — 사용자가 든 팀(채널 id 미확인)
    ('AGAPAO', {'KO': '아가파오 워십', 'EN': 'Agapao Worship'}, 'KR', 'TEAM', None, None),
    ('LEVISTANCE', {'KO': '레비스탕스'}, 'KR', 'TEAM', None, None),
    ('ANOINTING', {'KO': '어노인팅'}, 'KR', 'TEAM', None, None),
    ('JUS', {'KO': '제이어스', 'EN': 'J-US'}, 'KR', 'TEAM', None, None),
    ('WELOVE', {'KO': '위러브', 'EN': 'WELOVE'}, 'KR', 'TEAM', None, None),
    ('ISAIAH6118', {'KO': '아이자야씩스티원', 'EN': 'Isaiah6tyOne'}, 'KR', 'TEAM', None, None),
    ('YWAM_TUE', {'KO': '예수전도단 화요모임'}, 'KR', 'TEAM', None, None),
    # 영어권
    ('HILLSONG', {'KO': '힐송 워십', 'EN': 'Hillsong Worship'}, 'AU', 'TEAM', None, None),
    ('BETHEL', {'KO': '베델 뮤직', 'EN': 'Bethel Music'}, 'US', 'TEAM', None, None),
    ('ELEVATION', {'KO': '엘리베이션 워십', 'EN': 'Elevation Worship'}, 'US', 'TEAM', None, None),
    ('MAVERICK', {'KO': '매버릭 시티 뮤직', 'EN': 'Maverick City Music'}, 'US', 'TEAM', None, None),
    # 중화권 · 포르투갈어권 — 실측 채널
    ('STREAMPRAISE', {'ZHT': '讚美之泉', 'ZH': '赞美之泉', 'EN': 'Stream of Praise'},
     'TW', 'TEAM', 'UC00EceQGGCMucNvwOS-jQ7A',
     '讚美之泉 Stream Of Praise Music Ministries'),
    ('LITTLELAMB', {'ZHT': '小羊詩歌', 'ZH': '小羊诗歌', 'EN': 'Little Lamb'},
     'TW', 'TEAM', 'UCdbFFcLrcDtwHf0TumhFXnQ', '小羊詩歌'),
    ('ESTILOADOR', {'PT': 'Estilo Adoração'}, 'BR', 'TEAM',
     'UCb0ZdT9Hjrqq_Uke7CXnTQA', 'Estilo Adoração'),

    # ★★ 「- Topic」 이 알려 준 사역자들(2026-09-09) — 유튜브가 저작권 정보로
    #   자동 만드는 음원 채널의 이름이라 **그 곡을 부른 팀**이 확실하다.
    #   ⚠ 채널 id 는 모른다 — **이름만 있어도 등록한다**(사용자 원칙).
    #   ★ 사역자를 넣을수록 **곡명 수확의 잡음이 준다**(이름이 곡명 자리에 온다).
    ('PHIL_WICKHAM', {'EN': 'Phil Wickham', 'KO': '필 위컴'}, 'US', 'SOLO', None, None),
    ('CECE_WINANS', {'EN': 'CeCe Winans'}, 'US', 'SOLO', None, None),
    ('CHRIS_TOMLIN', {'EN': 'Chris Tomlin', 'KO': '크리스 탐린'}, 'US', 'SOLO', None, None),
    ('LEELAND', {'EN': 'Leeland'}, 'US', 'TEAM', None, None),
    ('NICOLE_MULLEN', {'EN': 'Nicole C. Mullen'}, 'US', 'SOLO', None, None),
    ('PLANETSHAKERS', {'EN': 'Planetshakers'}, 'AU', 'TEAM', None, None),
    ('CHRIS_BOWATER', {'EN': 'Chris Bowater'}, 'GB', 'SOLO', None, None),
    ('NOEL_RICHARDS', {'EN': 'Noel Richards'}, 'GB', 'SOLO', None, None),
    ('MARANATHA', {'EN': 'Maranatha! Music'}, 'US', 'LABEL', None, None),
    ('INTEGRITY', {'EN': 'Integrity Music'}, 'US', 'LABEL', None, None),
    ('OASIS_WORSHIP', {'EN': 'Oasis Worship'}, None, 'TEAM', None, None),
    ('MERCY_WORSHIP', {'EN': 'Mercy Worship'}, None, 'TEAM', None, None),
    ('JESUS_IMAGE', {'EN': 'Jesus Image'}, 'US', 'TEAM', None, None),
    # 중화권
    ('KUA', {'ZHT': 'KUA敬拜團', 'EN': 'KUA GLOBAL 跨越'}, 'TW', 'TEAM', None, None),
    ('AGWMM', {'ZHT': '基恩敬拜', 'EN': 'AGWMM'}, 'TW', 'TEAM', None, None),
    ('HEART_SPRING', {'ZHT': '心泉敬拜'}, 'TW', 'TEAM', None, None),
    # 한국 — 실측 번안 판을 낸 팀들
    ('LEVITE_TRIBE', {'KO': '레위지파'}, 'KR', 'TEAM', None, None),
    ('FEAST_FAMILY', {'KO': '잔치공동체', 'EN': 'Feast Family'}, 'KR', 'TEAM', None, None),
    ('TEAM_LUKE', {'KO': '팀룩워십', 'EN': 'Team Luke Worship'}, 'KR', 'TEAM', None, None),
    ('YERAM', {'KO': '예람워십', 'EN': 'YERAM WORSHIP'}, 'KR', 'TEAM', None, None),
    ('FIA', {'KO': '피아워십', 'EN': 'F.I.A'}, 'KR', 'TEAM', None, None),
    ('NEWWAVE', {'KO': '뉴웨이브 워십', 'EN': 'NEWWAVE WORSHIP'}, 'KR', 'TEAM', None, None),
    ('DAVID_JONATHAN', {'KO': '다윗과 요나단'}, 'KR', 'TEAM', None, None),
    # ★ 2차 수확 — Topic 이 더 알려 준 것(2026-09-09)
    #   ⚠ `Way Maker` 의 **원곡자는 SINACH**(나이지리아)이고 Leeland 는 커버다
    #     — 검색 순위로는 Leeland 가 앞서 나온다. **Topic 이 그것을 바로잡았다.**
    ('SINACH', {'EN': 'SINACH', 'KO': '시나크'}, 'NG', 'SOLO', None, None),
    ('BRANDON_LAKE', {'EN': 'Brandon Lake'}, 'US', 'SOLO', None, None),
    ('JENN_JOHNSON', {'EN': 'Jenn Johnson'}, 'US', 'SOLO', None, None),
]


# ── 표 ──────────────────────────────────────────────────────────────────────

def ensure(conn):
    """표를 만든다(멱등). 이름은 `sys_text_asset` 에 있으므로 여기 없다."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS %s (
            artist_id      INTEGER PRIMARY KEY AUTOINCREMENT,
            artist_code    TEXT UNIQUE NOT NULL,
            country        TEXT,
            kind           TEXT,
            channel_ext_id TEXT,
            channel_name   TEXT,
            home_url       TEXT,
            note           TEXT,
            record_status  TEXT DEFAULT 'LIVE'
        )""" % TBL)
    conn.execute("CREATE INDEX IF NOT EXISTS ix_worship_artist_ch"
                 " ON %s(channel_ext_id)" % TBL)
    # ★ 이미 있는 DB 에도 붙인다(CREATE IF NOT EXISTS 는 칸을 안 더한다)
    cols = [r[1] for r in conn.execute("PRAGMA table_info(%s)" % TBL)]
    if 'channel_name' not in cols:
        conn.execute("ALTER TABLE %s ADD COLUMN channel_name TEXT" % TBL)
    # ★★★ **주요 사역자 칸**(2026-09-10 사용자 지시 「사역자가 유명하지 않은
    #   경우도 있다 · 사용자들이 꼭 찍어서 선택할 가능성이 별로 없는 사역자들은
    #   **별도의 그룹으로** 묶어야 유명 사역자별 필터링 서비스가 가능하다」).
    #   실측 44명 중 **세 명이 영상의 46%** 를 낸다 — 44명을 다 늘어놓으면
    #   고를 수가 없다.
    #   ⚠ **사람이 정한다** — 영상 수로 자동 판정하지 않는다. 영상이 적어도 아는
    #     이름이 있고(힐송), 많아도 한 채널이 몰아 올린 것일 수 있다.
    if 'is_featured' not in cols:
        conn.execute("ALTER TABLE %s ADD COLUMN is_featured INTEGER"
                     " NOT NULL DEFAULT 0" % TBL)
    return True


def set_featured(conn, aids, on=1):
    """주요 사역자로 올리거나 내린다 → 바뀐 수."""
    aids = [int(a) for a in (aids or [])]
    if not aids:
        return 0
    ensure(conn)
    n = conn.execute("UPDATE %s SET is_featured=? WHERE artist_id IN (%s)"
                     % (TBL, ','.join('?' * len(aids))),
                     [int(bool(on))] + aids).rowcount
    conn.commit()
    return n


def featured(conn):
    """주요 사역자 id 집합 — 사용자 화면의 필터가 쓴다."""
    ensure(conn)
    return {r[0] for r in conn.execute(
        "SELECT artist_id FROM %s WHERE COALESCE(is_featured,0)=1"
        "   AND COALESCE(record_status,'LIVE')='LIVE'" % TBL)}


def add(conn, code, names, country=None, kind=None, ext=None,
        chan_name=None, home=None, note=None):
    """사역자 하나를 담는다 → artist_id (멱등 — 코드가 열쇠).

    ⚠ **이름 하나만 있어도 된다**(사용자 원칙). 나머지는 알게 되면 채운다.
    ⚠ 이미 있으면 **비어 있는 칸만 채운다** — 사람이 손으로 고친 값을 안 덮는다.
    """
    ensure(conn)
    code = (code or '').strip().upper()
    if not code:
        return None
    row = conn.execute("SELECT artist_id FROM %s WHERE artist_code=?" % TBL,  # status-ok: 있는 줄을 다시 만들지 않으려는 확인 — 가림(HIDE)도 **있는 줄**이라 빼면 같은 것이 한 벌 더 생긴다
                       (code,)).fetchone()
    if row:
        aid = row[0]
        for col, val in (('country', country), ('kind', kind),
                         ('channel_ext_id', ext), ('channel_name', chan_name),
                         ('home_url', home), ('note', note)):
            if val:
                conn.execute("UPDATE %s SET %s=COALESCE(%s,?) WHERE artist_id=?"
                             % (TBL, col, col), (val, aid))
    else:
        if not names:
            return None      # ⚠ 이름 없는 껍데기는 만들지 않는다
        cur = conn.execute(
            "INSERT INTO %s(artist_code, country, kind, channel_ext_id,"
            " channel_name, home_url, note, record_status)"
            " VALUES(?,?,?,?,?,?,?,'LIVE')" % TBL,
            (code, country, kind, ext, chan_name, home, note))
        aid = cur.lastrowid
    for lang, nm in (names or {}).items():
        nm = (nm or '').strip()
        if not nm:
            continue
        lg = lang.upper()
        ex = conn.execute(
            "SELECT 1 FROM sys_text_asset WHERE text_type=? AND clicked_id=?"
            " AND UPPER(lang_code)=?", (NAME_TYPE, aid, lg)).fetchone()  # status-ok: 있는 줄을 다시 만들지 않으려는 확인 — 가림(HIDE)도 **있는 줄**이라 빼면 같은 것이 한 벌 더 생긴다
        if ex:
            conn.execute("UPDATE sys_text_asset SET contents=? WHERE text_type=?"
                         " AND clicked_id=? AND UPPER(lang_code)=?",
                         (nm, NAME_TYPE, aid, lg))
        else:
            conn.execute("INSERT INTO sys_text_asset(clicked_id, text_type,"
                         " lang_code, contents, record_status)"
                         " VALUES(?,?,?,?,'LIVE')", (aid, NAME_TYPE, lg, nm))
    return aid


def names_of(conn, aid):
    """{언어: 이름}."""
    return {r[0].upper(): r[1] for r in conn.execute(
        "SELECT lang_code, contents FROM sys_text_asset WHERE text_type=?"
        " AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'",
        (NAME_TYPE, aid))}


def label(conn, aid, lang='KO'):
    """화면에 쓸 이름 — 요청 언어 → EN → 아무 것. 없으면 코드."""
    nm = names_of(conn, aid)
    for k in ((lang or 'KO').upper(), 'EN'):
        if nm.get(k):
            return nm[k]
    if nm:
        return sorted(nm.values())[0]
    r = conn.execute("SELECT artist_code FROM %s WHERE artist_id=?" % TBL,  # status-ok: 번호 하나로 이름표를 찾는 자리 — 선택할 것이 하나뿐이라 상태가 가르는 것이 없다
                     (aid,)).fetchone()
    return r[0] if r else ''


def artists(conn, country=None, kind=None, lang='KO'):
    """[(artist_id, 이름, 나라, 갈래, 채널id, 영상 수)] — 이름순."""
    ensure(conn)
    q = ("SELECT artist_id, country, kind, channel_ext_id FROM %s"
         " WHERE COALESCE(record_status,'LIVE')='LIVE'" % TBL)
    args = []
    if country:
        q += " AND country=?"
        args.append(country)
    if kind:
        q += " AND kind=?"
        args.append(kind)
    out = []
    for aid, co, kd, ext in conn.execute(q, tuple(args)):
        n = conn.execute(
            "SELECT COUNT(*) FROM sys_link_asset WHERE link_type=? AND target_id=?"
            " AND COALESCE(record_status,'LIVE')='LIVE'", (LINK, aid)).fetchone()[0]
        out.append((aid, label(conn, aid, lang), co, kd, ext, n))
    return sorted(out, key=lambda x: x[1])


# ── 연결 ────────────────────────────────────────────────────────────────────

def link(conn, media_id, aid):
    """영상 ↔ 사역자 (멱등). 통합 표 `sys_link_asset` 에 담는다.

    ⚠⚠⚠ **사람이 뗀 것을 되살리지 않는다**(2026-09-11에 잡았다). 그전에는
      있으면 무조건 `LIVE` 로 올렸는데, `autolink` 가 **탭을 열 때마다** 도는
      지금 구조에서는 사람이 「이 사역자 아님」으로 뗀 영상이 **다음 순간
      되살아난다** — 화면은 「뗐습니다」라고 말하고 값은 안 바뀌는 꼴이다.
      §234차 ④ 「곡 코드를 안 지우면 재유도가 도로 잇는다」와 같은 자리다.
    ★ 잣대 = **`confidence='MANUAL'` 인 가림**(사람이 정했다는 표식).
    """
    if not media_id or not aid:
        return False
    # ⚠ 시험용 메모리 표에는 `confidence` 칸이 없다 — 있을 때만 읽는다.
    _has_conf = any(r[1] == 'confidence' for r in
                    conn.execute('PRAGMA table_info(sys_link_asset)'))
    ex = conn.execute(
        "SELECT record_status, %s FROM sys_link_asset"
        " WHERE link_type=? AND clicked_id=? AND target_id=?"
        % ("COALESCE(confidence,'')" if _has_conf else "''"),
        (LINK, media_id, aid)).fetchone()  # status-ok: 연결이 이미 있나 보는 자리 — 가림을 빼면 뗀 연결이 도로 생긴다
    if ex:
        if (ex[0] or 'LIVE') == 'HIDE' and ex[1] == 'MANUAL':
            return False          # ★ 사람이 뗐다 — 손대지 않는다
        conn.execute("UPDATE sys_link_asset SET record_status='LIVE'"
                     " WHERE link_type=? AND clicked_id=? AND target_id=?",
                     (LINK, media_id, aid))
        return False
    conn.execute("INSERT INTO sys_link_asset(link_type, clicked_id, target_id,"
                 " record_status) VALUES(?,?,?,'LIVE')", (LINK, media_id, aid))
    return True


def media_count(conn, artist_id=None, kind='WORSHIP', lang=None, pref=None):
    """그 사역자의 **화면에 실제로 뜰** 편 수.

    ★★★ **`media_of` 와 같은 잣대여야 한다**(2026-09-10 사용자 「사역자 이름에
      표시된 숫자는 임시숫자인가? 숫자도 맞지 않다」).
      그전에는 화면이 `artists()` 의 수를 썼는데 그것은 **연결 수**라 미승인·
      다른 유형·가림을 전부 세었다. 실측 마커스워십 **45 대 13**(미승인 32),
      예수전도단 화요모임 **10 대 0편** — 눌러도 빈 화면인 단추가 떴다.
    ⚠ 세는 문과 내는 문이 갈리면 **반드시 어긋난다** — 그래서 같은 문을 쓴다.
    """
    return len(media_of(conn, artist_id=artist_id, kind=kind, lang=lang,
                        pref=pref, limit=10 ** 9))


def media_of(conn, artist_id=None, kind='WORSHIP', lang=None, pref=None,
             limit=120):
    """사역자의 영상 → [(media_id, 제목, url, 설명문)] — **읽는 문 하나**.

    ★ 사용자 화면(찬양 앵커)이 이 문만 부른다 — 화면이 `sys_media_asset` 을
      직접 안 읽는다(§121차).
    `artist_id` 가 없으면 **주요 사역자 전부**의 것을 모은다.
    ⚠ `pref` = `media_pref.load(...)` — 주면 내가 숨긴 것을 뺀다(§226차).
    ⚠ **승인된 것만**(§194차 승인=연결) · 조회수 큰 순.
    """
    ensure(conn)
    q = ("SELECT DISTINCT a.media_id, a.title, a.url, COALESCE(a.description,'')"
         "  FROM sys_link_asset l"
         "  JOIN sys_media_asset a ON a.media_id=l.clicked_id"
         " WHERE l.link_type=? AND a.record_status='LIVE' AND a.is_active=1"
         "   AND COALESCE(l.record_status,'LIVE')='LIVE'")
    args = [LINK]
    if artist_id:
        q += " AND l.target_id=?"
        args.append(int(artist_id))
    else:
        feat = sorted(featured(conn))
        if not feat:
            return []
        q += " AND l.target_id IN (%s)" % ','.join('?' * len(feat))
        args += feat
    if kind:
        q += " AND COALESCE(a.media_type,'')=?"
        args.append(str(kind))
    if lang:
        q += " AND UPPER(COALESCE(a.lang_code,''))=?"
        args.append(str(lang).upper())
    rows = conn.execute(q, args).fetchall()
    try:
        import db_media_linkcheck as _LC
        views = _LC.views_of(conn)
    except Exception:
        views = {}
    out = []
    for mid, ti, url, d in rows:
        if pref is not None:
            try:
                if pref.hidden(mid, d):
                    continue
            except Exception:
                pass
        out.append((mid, ti or '', url or '', d or '',
                    (views.get(mid) or (0,))[0] or 0))
    out.sort(key=lambda x: -x[4])
    return [(m, t, u, d) for m, t, u, d, _v in out[:int(limit)]]


def counts_by_artist(conn, kind='WORSHIP', lang=None, pref=None):
    """{사역자 번호: 편 수} — **한 조회로 전부 센다**.

    ⚠⚠ **`media_count` 를 사역자마다 부르면 느리다**(2026-09-17 사용자 「찬양듣기를
      누르면 반응이 매우 느리다」). 그 문은 안에서 `media_of` 를 부르고, `media_of`
      는 부를 때마다 **조회수 표를 통째로 읽는다**(`views_of`) — 사역자가 서른이면
      그 일을 서른 번 한다. 세기만 할 때는 조회수가 필요 없다.
    ★ **잣대는 `media_of` 와 같아야 한다** — 갈리면 「목록은 3인데 수는 5」가 된다.
      승인된 것만 · 살아 있는 연결만 · 같은 유형 · 같은 언어 · 내가 숨긴 것 뺌.
    """
    ensure(conn)
    q = ("SELECT l.target_id, a.media_id, COALESCE(a.description,'')"
         "  FROM sys_link_asset l"
         "  JOIN sys_media_asset a ON a.media_id=l.clicked_id"
         " WHERE l.link_type=? AND a.record_status='LIVE' AND a.is_active=1"
         "   AND COALESCE(l.record_status,'LIVE')='LIVE'")
    args = [LINK]
    if kind:
        q += " AND COALESCE(a.media_type,'')=?"
        args.append(str(kind))
    if lang:
        q += " AND UPPER(COALESCE(a.lang_code,''))=?"
        args.append(str(lang).upper())
    out = {}
    seen = set()
    for aid, mid, d in conn.execute(q, args):
        if (aid, mid) in seen:
            continue
        seen.add((aid, mid))
        if pref is not None:
            try:
                if pref.hidden(mid, d):
                    continue
            except Exception:
                pass
        out[int(aid)] = out.get(int(aid), 0) + 1
    return out


def axis_counts(conn):
    """분위기·반주 값별 편 수 → {'mood': {코드: n}, 'instrument': {코드: n}}.

    ★ 앵커를 그릴 때 **붙은 것이 없는 값은 안 그리려고** 센다(§0-1).
    ⚠ **승인된 것만** 센다 — 미검토가 사용자 화면에 수를 부풀리면 안 된다.
    """
    import json as _json
    out = {'mood': {}, 'instrument': {}}
    for (d,) in conn.execute(
            "SELECT COALESCE(description,'') FROM sys_media_asset"
            " WHERE record_status='LIVE' AND media_type='WORSHIP'"
            "   AND is_active=1"):
        if not d.startswith('{'):
            continue
        try:
            j = _json.loads(d)
        except Exception:
            continue
        for fld in ('mood', 'instrument'):
            for c in (j.get(fld) or []):
                out[fld][c] = out[fld].get(c, 0) + 1
    return out


def media_by_axis(conn, field, code, lang=None, pref=None, limit=120):
    """분위기·반주 값 하나에 걸린 영상 → [(media_id, 제목, url, 설명문)].

    ⚠ `field` 는 `mood` · `instrument` 둘뿐이다(딴 값이면 빈 목록).
    ⚠ `pref` 를 주면 내가 숨긴 것을 뺀다(§226차) · **승인된 것만**.
    """
    import json as _json
    if field not in ('mood', 'instrument'):
        return []
    q = ("SELECT media_id, title, url, COALESCE(description,'')"
         "  FROM sys_media_asset"
         " WHERE record_status='LIVE' AND media_type='WORSHIP' AND is_active=1")
    args = []
    if lang:
        q += " AND UPPER(COALESCE(lang_code,''))=?"
        args.append(str(lang).upper())
    try:
        import db_media_linkcheck as _LC
        views = _LC.views_of(conn)
    except Exception:
        views = {}
    out = []
    for mid, ti, url, d in conn.execute(q, args).fetchall():
        if not d.startswith('{'):
            continue
        try:
            got = _json.loads(d).get(field) or []
        except Exception:
            continue
        if str(code).upper() not in [str(x).upper() for x in got]:
            continue
        if pref is not None:
            try:
                if pref.hidden(mid, d):
                    continue
            except Exception:
                pass
        out.append((mid, ti or '', url or '', d, (views.get(mid) or (0,))[0] or 0))
    out.sort(key=lambda x: -x[4])
    return [(m, t, u, d) for m, t, u, d, _v in out[:int(limit)]]


def featured_list(conn, lang='KO', pref=None):
    """주요 사역자 [(artist_id, 이름, 영상 수)] — 화면의 앵커 목록.

    ⚠ **영상이 0편인 사람은 안 낸다**(§0-1 빈 서랍 금지) — 이름만 등록된
      사역자가 실측 27명이라 그대로 늘어놓으면 눌러도 빈 화면이 된다.
    """
    feat = featured(conn)
    out = []
    for aid, nm, co, kd, ext, _n in artists(conn, lang=lang):
        if aid not in feat:
            continue
        # ⚠⚠ `artists()` 의 수는 **연결 수**다 — 화면에 뜰 수와 다르다.
        n = media_count(conn, aid, pref=pref)
        if n:
            out.append((aid, nm, n))
    return sorted(out, key=lambda x: -x[2])


def artists_of(conn, media_id, lang='KO'):
    """그 영상의 사역자 [(artist_id, 이름)]."""
    return [(r[0], label(conn, r[0], lang)) for r in conn.execute(
        "SELECT target_id FROM sys_link_asset WHERE link_type=? AND clicked_id=?"
        " AND COALESCE(record_status,'LIVE')='LIVE'", (LINK, media_id))]


#: ★ **사용자 화면에 나가는 유형** — 「이을 수 있는 유형」이 아니다.
#:   ⚠⚠ 한때 이것으로 **잇는 것을 걸렀다가 되돌렸다**(2026-09-11) — 분류기가
#:     틀리면 진짜 찬양이 통째로 사라진다. 지금은 **화면이 세는 잣대**일 뿐이다.
#: (옛 주석)
#:   ⚠⚠ 그전에는 **채널 영상을 통째로** 이었다. 찬양팀 채널도 설교·공지를
#:     올리므로 실측 **231편 중 60편(26%)이 설교**로 걸려 있었고
#:     (예배하는소리 31편 중 27편 · 어노인팅 11 중 8), 사역자 화면의 「영상」
#:     칸이 그만큼 부풀었다(2026-09-10 사용자 「찬양 사역자가 아니라 설교자」).
#:   ★ **유형이 곧 자격이다** — 이름으로 거르면 안 된다(§228차 홑낱말 함정.
#:     실측 이름에 「워십」이 든 사역자 10명 중 오탐 0).
LINK_TYPES = ('WORSHIP', 'READING')


def autolink(conn, dry=False, types=None):
    """**공식 채널의 영상**을 그 사역자에 잇는다(멱등) → 새로 이은 수.

    ★ 열쇠는 **채널 id 또는 채널 이름 정확 일치** 둘이다. id 만 보면 거의 안
      걸린다 — 검색 경로가 `channelId` 를 안 담아 실측 **19,104편 중 5,941편**
      만 id 를 갖고 있다(§228차 ②).
    ⚠ **부분 일치로 짐작하지 않는다** — 실측에 「Bethel」 이라는 딴 채널이 따로
      있어 「BETHEL OF KOREA」와 섞인다. 이름은 앞뒤 공백만 떼고 **그대로** 견준다.
    ⚠⚠ **유형으로 안 거른다** — 아래 본문 설명 참조(거르면 잘못 분류된 진짜
      찬양이 목록에서 사라져 사람이 손댈 수 없다).
    ⚠ **이미 이은 것은 안 뗀다** — 사람이 손으로 이은 것이 섞여 있다.
      잘못 걸린 것은 화면에서 **한 편씩** 뗀다(`review_rows` + `unlink`).
    ⚠ `types` 는 옛 이름이다 — 쓰지 않는다.
    """
    ensure(conn)
    # 영상의 (채널 id, 채널 이름)을 한 번만 읽는다
    by_id, by_name = {}, {}
    # ⚠⚠⚠ **유형으로 거르지 않는다**(2026-09-11) — 거르면 분류기가 설교로
    #   잘못 적어 둔 **진짜 찬양이 목록에서 통째로 빠져** 사람이 볼 수도
    #   뗄 수도 없게 된다(실측 예배하는소리 27편이 그 경우다).
    #   ★ 그 채널의 영상이라는 것은 **사실**이다 — 이어 두고, **무엇인지는
    #     화면이 유형 칸으로 말하고 사람이 한 편씩 뗀다.**
    #   ⚠ 사용자 화면은 `media_of(kind='WORSHIP')` 이라 설교는 **안 나간다**
    #     (실측 부르는 곳 하나 · `pick_video_view`).
    for mid, d in conn.execute(
            "SELECT media_id, COALESCE(description,'') FROM sys_media_asset"
            " WHERE record_status='LIVE' AND description LIKE '{%'").fetchall():
        try:
            j = json.loads(d)
        except Exception:
            continue
        cid = (j.get('channel_id') or '').strip()
        nm = (j.get('channel') or '').strip().lower()
        if cid:
            by_id.setdefault(cid, []).append(mid)
        if nm:
            by_name.setdefault(nm, []).append(mid)
    made = 0
    for aid, ext, cnm in conn.execute(
            "SELECT artist_id, channel_ext_id, channel_name FROM %s"
            " WHERE COALESCE(record_status,'LIVE')='LIVE'" % TBL).fetchall():
        mids = set(by_id.get((ext or '').strip(), []) if ext else [])
        if cnm:
            mids |= set(by_name.get(cnm.strip().lower(), []))
        for mid in mids:
            if dry:
                if not conn.execute(
                        "SELECT 1 FROM sys_link_asset WHERE link_type=? AND clicked_id=?"
                        " AND target_id=?", (LINK, mid, aid)).fetchone():  # status-ok: 연결이 이미 있나 보는 자리 — 가림을 빼면 뗀 연결이 도로 생긴다
                    made += 1
            elif link(conn, mid, aid):
                made += 1
    if not dry:
        conn.commit()
    return made


# ⚠⚠⚠ **「찬양이 아닌 연결 일괄 해제」를 걷었다**(2026-09-11 사용자
#   「**찬양인지 아닌지 어떻게 알고** 자동으로 연결해제한다는 것인가?」).
#   ⇒ 실측이 사용자 말을 받쳤다 — 그 잣대(`media_type`)로 걸리는 60편에
#     **멀쩡한 찬양이 잔뜩** 들어 있었다:
#       예배하는소리 | SERMON | **주 사랑이 나를 숨쉬게 해**
#       예배하는소리 | SERMON | **하나님의 은혜 (나를 지으신 이가 하나님)**
#       예배하는소리 | SERMON | **축복합니다(Bless you)**
#     분류기가 틀린 것이지 연결이 틀린 것이 아니다. **일괄 해제는 멀쩡한
#     찬양을 통째로 끊는다.**
#   ★★★ **기계가 못 가르는 것을 기계에게 시키지 않는다** — 사람이 **영상을
#     보고 한 편씩** 뗀다(`review_rows` + `unlink`). §233차 「갈래어를 탐지에
#     쓰지 말 것」과 같은 자리다.


def count_by_type(conn, artist_id):
    """(찬양·성경듣기 수, 전체 수) — 화면이 **두 수를 함께** 보이는 자리.

    ⚠ 그전에는 전체만 세어 「예배하는소리 31편」이었는데 **찬양은 4편**이었다.
    """
    w = conn.execute(
        "SELECT COUNT(DISTINCT l.clicked_id) FROM sys_link_asset l"
        "  JOIN sys_media_asset m ON m.media_id=l.clicked_id"
        " WHERE l.link_type=? AND l.target_id=?"
        "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
        "   AND m.record_status='LIVE' AND m.media_type IN (%s)"
        % ','.join('?' * len(LINK_TYPES)),
        (LINK, int(artist_id)) + LINK_TYPES).fetchone()[0]
    a = conn.execute(
        "SELECT COUNT(DISTINCT l.clicked_id) FROM sys_link_asset l"
        "  JOIN sys_media_asset m ON m.media_id=l.clicked_id"
        " WHERE l.link_type=? AND l.target_id=?"
        "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
        "   AND m.record_status='LIVE'", (LINK, int(artist_id))).fetchone()[0]
    return w, a


def review_rows(conn, artist_id, lang='KO', q='', limit=500):
    """**그 사역자에 걸린 영상** → [dict] — 사람이 보고 한 편씩 뗄 재료.

    ★★★ 2026-09-11 사용자 —
      「**사역자를 클릭하면 그 사역자와 연결된 영상을 보고 선택을 해서 클릭해야
       그 영상이 해제되는 것 아닌가?**」 — 맞다. 그 목록을 내는 문이다.
    ⚠ **유형으로 안 거른다** — 잘못 분류된 것이야말로 사람이 봐야 할 것이다.
      화면이 `유형` 칸으로 말한다.
    ⚠ 연결의 **번호(`link_id`)를 함께** 낸다 — 「이 사역자 아님」이 그것으로 뗀다.
    """
    ensure(conn)
    sql = ("SELECT l.sys_link_id, a.media_id, a.title, a.url,"
           "       COALESCE(a.description,''), COALESCE(a.media_type,''),"
           "       COALESCE(a.lang_code,''), COALESCE(a.is_active,0)"
           "  FROM sys_link_asset l"
           "  JOIN sys_media_asset a ON a.media_id=l.clicked_id"
           " WHERE l.link_type=? AND l.target_id=?"
           "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
           "   AND COALESCE(a.record_status,'LIVE')='LIVE'")
    args = [LINK, int(artist_id)]
    if lang and lang != '(전체)':
        sql += " AND UPPER(COALESCE(a.lang_code,''))=?"
        args.append(str(lang).upper())
    if q:
        sql += " AND a.title LIKE ?"
        args.append('%%%s%%' % q)
    sql += " ORDER BY a.media_id DESC"
    try:
        import db_media_linkcheck as _LC
        views = _LC.views_of(conn)
    except Exception:
        views = {}
    song_of = {}
    try:
        import db_song as _SG
        snm = {x[0]: x[1] for x in _SG.songs(conn)}
        for mid, sid in conn.execute(
                "SELECT l.clicked_id, r.song_id FROM sys_link_asset l"
                "  JOIN sys_song_rendition r ON r.rend_id=l.target_id"
                " WHERE l.link_type=?"
                "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
                "   AND COALESCE(r.record_status,'LIVE')='LIVE'",
                (_SG.LINK_MEDI,)):
            song_of[mid] = snm.get(sid, '')
    except Exception:
        pass
    out = []
    for lid, mid, ti, url, d, mt, lg, act in conn.execute(sql, args):
        out.append(dict(link_id=lid, media_id=mid, title=ti or '',
                        url=url or '', desc=d, mtype=mt, lang=lg,
                        views=(views.get(mid) or (None,))[0],
                        song=song_of.get(mid, ''), ok=bool(act),
                        # ★ 「사용자에게 나가나」 — 유형이 곧 답이다
                        shown=(mt in LINK_TYPES)))
        if len(out) >= int(limit):
            break
    return out


def unlink(conn, link_ids):
    """**이 사역자 아님** — 그 연결만 뗀다 → 뗀 수.

    ⚠⚠ **지우지 않는다** — 영상도 사역자도 그대로 두고 잇던 줄만 내린다.
    ⚠ **사람이 정했다고 적는다**(`confidence='MANUAL'`) — 그래야 `autolink` 가
      다음에 도로 잇지 않는다(`link()` 가 가린 줄을 되살리지 않는지 확인할 것).
    """
    ids = [int(x) for x in (link_ids if isinstance(link_ids, (list, tuple, set))
                            else [link_ids])]
    if not ids:
        return 0
    conn.execute("UPDATE sys_link_asset SET record_status='HIDE',"
                 " confidence='MANUAL' WHERE sys_link_id IN (%s)"
                 % ','.join('?' * len(ids)), ids)
    return len(ids)


def move(conn, link_ids, to_artist_id, approve=False):
    """선택한 연결을 **다른 찬양팀으로 옮긴다** → dict(moved, approved, same).

    ★ 1.txt 17번 2) — 채널 관리자를 찬양팀으로 등록해 버린 자리를 고치는 문.
      예) 음반사 채널 「Integrity Worship」 에 걸린 편을 「Paul Wilbur」 로.
    ⚠⚠ **지우지 않는다** — 옛 연결은 가리고(`HIDE·MANUAL`) 새 연결을 만든다.
      그래야 「누가 언제 옮겼나」가 남고 자동 잇기가 옛 팀으로 도로 안 잇는다.
    ⚠⚠⚠ **사람이 뗀 표식을 여기서는 넘는다** — `link()` 는 `HIDE·MANUAL` 을
      안 되살리지만(자동 잇기 방지), 이 문은 **사람이 방금 옮기라고 누른 것**
      이라 가장 나중 판단이 이긴다. 안 넘으면 한 번 「이 찬양팀 아님」으로
      뗀 편은 **영영 그 팀으로 못 돌아온다**.
    ⚠ `approve` — 사용자가 「활성화 승인」이라 부른 것(`is_active=1`).
      옮기는 일과 승인은 **다른 일**이라 끄고 켤 수 있게 둔다.
    """
    ensure(conn)
    ids = [int(x) for x in (link_ids if isinstance(link_ids, (list, tuple, set))
                            else [link_ids])]
    to = int(to_artist_id or 0)
    if not ids or not to:
        return {'moved': 0, 'approved': 0, 'same': 0}
    rows = conn.execute(
        "SELECT sys_link_id, clicked_id, target_id FROM sys_link_asset"
        " WHERE sys_link_id IN (%s) AND link_type=?"
        % ','.join('?' * len(ids)), ids + [LINK]).fetchall()  # status-ok: 옮길 줄을 번호로 집는 자리
    same = [r for r in rows if r[2] == to]
    work = [r for r in rows if r[2] != to]
    if work:
        unlink(conn, [r[0] for r in work])
    mids = []
    for _lid, mid, _old in work:
        if mid in mids:
            continue
        mids.append(mid)
        ex = conn.execute(
            "SELECT sys_link_id, COALESCE(record_status,'LIVE')"
            "  FROM sys_link_asset WHERE link_type=? AND clicked_id=?"
            "   AND target_id=?", (LINK, mid, to)).fetchone()  # status-ok: 가림도 있는 줄이다 — 빼면 한 벌 더 생긴다
        if ex:
            # ★ 사람이 방금 옮기라고 눌렀다 — 옛 「아님」 판정을 덮는다
            conn.execute("UPDATE sys_link_asset SET record_status='LIVE',"
                         " confidence='MANUAL' WHERE sys_link_id=?", (ex[0],))
        else:
            conn.execute(
                "INSERT INTO sys_link_asset(link_type, clicked_id, target_id,"
                " record_status, confidence) VALUES(?,?,?,'LIVE','MANUAL')",
                (LINK, mid, to))
    n_ok = 0
    if approve and mids:
        c = conn.execute("UPDATE sys_media_asset SET is_active=1"
                         " WHERE media_id IN (%s) AND COALESCE(is_active,0)=0"
                         % ','.join('?' * len(mids)), mids)
        n_ok = c.rowcount
    return {'moved': len(mids), 'approved': n_ok, 'same': len(same)}


def retire(conn, artist_ids, on=True):
    """**찬양 사역자가 아님 → 보관함**(가린다) / 되살린다 → 바뀐 수.

    ★ 2026-09-10 사용자 「부적절한 사역자 이름을 제거하는 기능 필요하다.
      **별도 보관함도 필요하다**」.
    ⚠⚠ **지우지 않는다** — 지우면 다음 수집에서 그 채널이 **또** 들어온다.
      가려 두면 이름이 남아 「이미 판단했다」가 기록된다.
    """
    ids = [int(a) for a in (artist_ids if isinstance(artist_ids, (list, tuple,
                                                                  set))
                            else [artist_ids])]
    if not ids:
        return 0
    ensure(conn)
    c = conn.execute("UPDATE %s SET record_status=? WHERE artist_id IN (%s)"
                     % (TBL, ','.join('?' * len(ids))),
                     [('HIDE' if on else 'LIVE')] + ids)
    return c.rowcount


#: 물리삭제한 줄을 통째로 남기는 자리 — `purge_undo` 가 여기서 되돌린다.
PURGE_BAK = 'temp_artist_purge_backup'


def _purge_bak(conn):
    conn.execute("CREATE TABLE IF NOT EXISTS %s("
                 " at TEXT, artist_id INT, tbl TEXT, row_json TEXT)"
                 % PURGE_BAK)


def purge_plan(conn, artist_ids):
    """지우면 **무엇이 함께 사라지나** → dict.

    ★ 누르기 **전에** 보여 준다 — 되돌릴 수 없는 일은 먼저 세어 보인다.
    """
    ids = [int(a) for a in (artist_ids or [])]
    out = {'artist': 0, 'names': 0, 'links': 0, 'rends': 0,
           'rend_links': 0, 'songs_emptied': 0, 'who': []}
    if not ids:
        return out
    ensure(conn)
    q = ','.join('?' * len(ids))
    out['artist'] = conn.execute(
        "SELECT COUNT(*) FROM %s WHERE artist_id IN (%s)" % (TBL, q),
        ids).fetchone()[0]
    out['names'] = conn.execute(
        "SELECT COUNT(*) FROM sys_text_asset WHERE text_type=?"
        "   AND clicked_id IN (%s)" % q, [NAME_TYPE] + ids).fetchone()[0]
    out['links'] = conn.execute(
        "SELECT COUNT(*) FROM sys_link_asset WHERE link_type=?"
        "   AND target_id IN (%s)" % q, [LINK] + ids).fetchone()[0]
    rends = [r[0] for r in conn.execute(
        "SELECT rend_id FROM sys_song_rendition WHERE artist_id IN (%s)" % q,
        ids).fetchall()]
    out['rends'] = len(rends)
    if rends:
        rq = ','.join('?' * len(rends))
        out['rend_links'] = conn.execute(
            "SELECT COUNT(*) FROM sys_link_asset WHERE link_type='MEDI_REND'"
            "   AND target_id IN (%s)" % rq, rends).fetchone()[0]
        # ⚠ **판이 0이 되는 곡**을 미리 센다 — 곡은 안 지우지만 사람이 알아야 한다.
        for (sid,) in conn.execute(
                "SELECT DISTINCT song_id FROM sys_song_rendition"
                " WHERE rend_id IN (%s)" % rq, rends).fetchall():
            left = conn.execute(
                "SELECT COUNT(*) FROM sys_song_rendition WHERE song_id=?"
                "   AND rend_id NOT IN (%s)" % rq, [sid] + rends).fetchone()[0]
            if not left:
                out['songs_emptied'] += 1
    out['who'] = [label(conn, a) for a in ids]
    return out


def purge(conn, artist_ids):
    """찬양팀과 **그 판·연결을 물리삭제**한다 → 지운 줄 수(합계).

    ⚠⚠⚠ 지우기 전에 `%s` 에 **통째로 남긴다** — 백업 없이 지우지 않는다.
    """ % PURGE_BAK
    import json
    from datetime import datetime
    ids = [int(a) for a in (artist_ids or [])]
    if not ids:
        return 0
    ensure(conn)
    _purge_bak(conn)
    at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    q = ','.join('?' * len(ids))
    rends = [r[0] for r in conn.execute(
        "SELECT rend_id FROM sys_song_rendition WHERE artist_id IN (%s)" % q,
        ids).fetchall()]
    rq = ','.join('?' * len(rends)) if rends else None

    def _save(tbl, sql, args, aid_at):
        cur = conn.execute(sql, args)
        cols = [d[0] for d in cur.description]
        n = 0
        for row in cur.fetchall():
            d = dict(zip(cols, row))
            conn.execute("INSERT INTO %s VALUES(?,?,?,?)" % PURGE_BAK,
                         (at, d.get(aid_at) or ids[0], tbl,
                          json.dumps(d, ensure_ascii=False)))
            n += 1
        return n

    _save(TBL, "SELECT * FROM %s WHERE artist_id IN (%s)" % (TBL, q), ids,
          'artist_id')
    _save('sys_text_asset',
          "SELECT * FROM sys_text_asset WHERE text_type=?"
          "   AND clicked_id IN (%s)" % q, [NAME_TYPE] + ids, 'clicked_id')
    _save('sys_link_asset',
          "SELECT * FROM sys_link_asset WHERE link_type=?"
          "   AND target_id IN (%s)" % q, [LINK] + ids, 'target_id')
    if rends:
        _save('sys_song_rendition',
              "SELECT * FROM sys_song_rendition WHERE rend_id IN (%s)" % rq,
              rends, 'artist_id')
        _save('sys_link_asset',
              "SELECT * FROM sys_link_asset WHERE link_type='MEDI_REND'"
              "   AND target_id IN (%s)" % rq, rends, 'target_id')

    n = 0
    n += conn.execute("DELETE FROM sys_link_asset WHERE link_type=?"
                      "   AND target_id IN (%s)" % q,
                      [LINK] + ids).rowcount
    if rends:
        n += conn.execute(
            "DELETE FROM sys_link_asset WHERE link_type='MEDI_REND'"
            "   AND target_id IN (%s)" % rq, rends).rowcount
        n += conn.execute("DELETE FROM sys_song_rendition"
                          " WHERE rend_id IN (%s)" % rq, rends).rowcount
    n += conn.execute("DELETE FROM sys_text_asset WHERE text_type=?"
                      "   AND clicked_id IN (%s)" % q,
                      [NAME_TYPE] + ids).rowcount
    n += conn.execute("DELETE FROM %s WHERE artist_id IN (%s)" % (TBL, q),
                      ids).rowcount
    return n


def purge_undo(conn, at=None):
    """백업에서 되돌린다 → 되살린 줄 수. `at` 을 안 주면 **가장 최근 판**."""
    import json
    _purge_bak(conn)
    if at is None:
        r = conn.execute("SELECT MAX(at) FROM %s" % PURGE_BAK).fetchone()
        at = r[0] if r else None
    if not at:
        return 0
    n = 0
    for tbl, js in conn.execute(
            "SELECT tbl, row_json FROM %s WHERE at=?" % PURGE_BAK,
            (at,)).fetchall():
        d = json.loads(js)
        cols = list(d)
        conn.execute("INSERT OR IGNORE INTO %s(%s) VALUES(%s)"
                     % (tbl, ','.join(cols), ','.join('?' * len(cols))),
                     [d[c] for c in cols])
        n += 1
    conn.execute("DELETE FROM %s WHERE at=?" % PURGE_BAK, (at,))
    return n


def new_code(conn, name):
    """사람이 손으로 더할 때 쓸 **코드를 짓는다** — 이름에서 뽑고 겹치면 번호.

    ⚠ 코드는 `add` 의 멱등 열쇠다 — 겹치면 **남의 찬양팀에 이름이 덮인다**.
    """
    import re as _re
    ensure(conn)
    # ⚠ **한글을 지우면 안 된다** — 지우면 한국어 이름이 전부
    #   ARTIST · ARTIST_2 가 되어 **코드만 보고는 누구인지 알 수 없다**(실측).
    base = _re.sub(r'[^A-Za-z0-9가-힣]+', '_',
                   (name or '').strip()).strip('_')
    base = (base or 'ARTIST').upper()[:24]
    code, i = base, 1
    while conn.execute("SELECT 1 FROM %s WHERE artist_code=?" % TBL,
                       (code,)).fetchone():   # status-ok: 코드는 UNIQUE — 가림도 자리를 먹는다
        i += 1
        code = '%s_%d' % (base[:20], i)
    return code


def retired(conn, lang='KO'):
    """보관함에 있는 사역자 [(artist_id, 이름, 나라, 갈래, 채널id)]."""
    ensure(conn)
    return [(r[0], label(conn, r[0], lang), r[1] or '', r[2] or '', r[3] or '')
            for r in conn.execute(
                "SELECT artist_id, country, kind, channel_ext_id FROM %s"
                " WHERE record_status='HIDE' ORDER BY artist_id" % TBL)]


def seed(conn):
    """씨앗 적재(멱등) → (담은 수, 이은 수)."""
    ensure(conn)
    n = 0
    for code, names, co, kd, ext, cnm in SEED:
        if add(conn, code, names, co, kd, ext, cnm):
            n += 1
    conn.commit()
    return n, autolink(conn)


# ── selftest ────────────────────────────────────────────────────────────────

def _mem():
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY, title TEXT,
        description TEXT, record_status TEXT);
      CREATE TABLE sys_text_asset(clicked_id INT, text_type TEXT, lang_code TEXT,
        contents TEXT, record_status TEXT);
      CREATE TABLE sys_link_asset(link_type TEXT, clicked_id INT, target_id INT,
        record_status TEXT);
    """)
    for i, (cid, nm) in enumerate(
            (('CH_A', 'MARKERS WORSHIP'), ('CH_A', 'MARKERS WORSHIP'),
             ('CH_B', '딴 채널'),
             ('', 'BETHEL OF KOREA'),      # id 없는 옛 수집분 — 이름으로만
             ('', 'Bethel')), start=1):    # ⚠ 부분 일치 함정
        c.execute("INSERT INTO sys_media_asset VALUES(?,?,?,'LIVE')",
                  (i, 'v%d' % i, json.dumps({'channel_id': cid, 'channel': nm})))
    return c


def selftest():
    ok = [0, 0]

    def t(nm, cond, extra=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, extra if not cond else ''))

    c = _mem()
    ensure(c)
    ensure(c)
    a1 = add(c, 'MARKERS', {'KO': '마커스워십', 'EN': 'MARKERS WORSHIP'}, 'KR', 'TEAM', 'CH_A')
    t('★ 담긴다', bool(a1))
    t('  다시 담아도 안 는다(멱등)',
      add(c, 'MARKERS', {'KO': '마커스워십'}) == a1
      and c.execute("SELECT COUNT(*) FROM %s" % TBL).fetchone()[0] == 1)
    t('★ 이름 하나만 있어도 등록된다(사용자 원칙)',
      bool(add(c, 'LEVISTANCE', {'KO': '레비스탕스'})))
    _r = c.execute("SELECT country, kind, channel_ext_id FROM %s"
                   " WHERE artist_code='LEVISTANCE'" % TBL).fetchone()
    t('  모르는 칸은 비어 있다(지어내지 않는다)', _r == (None, None, None), _r)
    t('★ 나중에 알게 되면 채워진다',
      add(c, 'LEVISTANCE', {}, country='KR') is not None
      and c.execute("SELECT country FROM %s WHERE artist_code='LEVISTANCE'" % TBL)
          .fetchone()[0] == 'KR')
    c.execute("UPDATE %s SET country='XX' WHERE artist_code='MARKERS'" % TBL)
    add(c, 'MARKERS', {}, country='KR')
    t('★ 사람이 고친 값을 안 덮는다',
      c.execute("SELECT country FROM %s WHERE artist_code='MARKERS'" % TBL)
       .fetchone()[0] == 'XX')
    t('  이름 없는 껍데기는 안 만든다', add(c, 'GHOST', {}) is None)
    t('  이름은 다국어 표에 있다',
      names_of(c, a1) == {'KO': '마커스워십', 'EN': 'MARKERS WORSHIP'})
    t('  이름은 요청 언어 → EN 으로 물러선다',
      label(c, a1, 'KO') == '마커스워십' and label(c, a1, 'JA') == 'MARKERS WORSHIP')
    a2 = add(c, 'LITTLELAMB', {'ZHT': '小羊詩歌'})
    t('  그 언어뿐이면 그것을 쓴다', label(c, a2, 'KO') == '小羊詩歌')

    # 연결
    a3 = add(c, 'BETHEL_KR', {'KO': '베델 오브 코리아'}, 'KR', 'TEAM',
             None, 'BETHEL OF KOREA')
    t('★ 공식 채널 영상이 저절로 이어진다', autolink(c) == 3)
    t('  두 번 돌려도 안 는다(멱등)', autolink(c) == 0)
    t('  딴 채널 영상은 안 붙는다', artists_of(c, 3) == [], artists_of(c, 3))
    t('  그 영상의 사역자를 낸다', artists_of(c, 1, 'KO') == [(a1, '마커스워십')])
    t('★ id 가 없어도 채널 이름으로 이어진다(옛 수집분 — 실측 69%가 id 없음)',
      artists_of(c, 4, 'KO') == [(a3, '베델 오브 코리아')], artists_of(c, 4))
    t('★★ 부분 일치로 짐작하지 않는다 — 「Bethel」 은 딴 채널',
      artists_of(c, 5) == [], artists_of(c, 5))
    t('  채널을 모르는 사역자는 아무것도 안 잇는다',
      not artists_of(c, 2, 'KO') or all(
          x[0] != c.execute("SELECT artist_id FROM %s WHERE artist_code='LEVISTANCE'"
                            % TBL).fetchone()[0] for x in artists_of(c, 2)))
    lst = artists(c, lang='KO')
    t('  목록에 영상 수가 함께 나온다',
      dict((x[1], x[5]) for x in lst).get('마커스워십') == 2, lst)
    t('  나라로 거른다',
      {x[1] for x in artists(c, country='KR')} == {'레비스탕스', '베델 오브 코리아'},
      artists(c, country='KR'))

    # 씨앗 표가 온전한가
    codes = [s[0] for s in SEED]
    t('★ 씨앗 코드가 겹치지 않는다', len(codes) == len(set(codes)))
    t('  씨앗마다 이름이 하나 이상 있다', all(s[1] for s in SEED))
    t('  씨앗 갈래가 코드표 안에 있다',
      all(s[3] in KINDS or s[3] is None for s in SEED))
    _ex = [s[4] for s in SEED if s[4]]
    t('  씨앗 채널 id 가 겹치지 않는다', len(_ex) == len(set(_ex)))
    try:
        import db_pack_catalog as PC
        t('★ 새 표가 팩 분류표에 있다', TBL in PC.TABLES, TBL)
    except Exception as e:
        t('★ 새 표가 팩 분류표에 있다', False, str(e)[:60])
    # ── 앵커 숫자 = 화면에 뜰 수 (2026-09-10) ────────────────────────
    try:
        import appdb as _ad
        _c = _ad.connect('bible_master.db')
        try:
            _f = featured_list(_c, 'KO')
            t('★★★ **앵커 숫자가 실제로 뜰 편 수와 같다**(연결 수가 아니다)',
              all(n == len(media_of(_c, a2, kind='WORSHIP')) for a2, _nm, n in _f),
              [(nm, n, len(media_of(_c, a2, kind='WORSHIP')))
               for a2, nm, n in _f if n != len(media_of(_c, a2, kind='WORSHIP'))])
            t('★★ **0편인 사람은 앵커에 안 뜬다**(빈 서랍 금지)',
              all(n > 0 for _a, _nm, n in _f))
            t('★ 세는 문과 내는 문이 같다',
              all(media_count(_c, a2, kind='WORSHIP') == n for a2, _nm, n in _f))
            _bulk = counts_by_artist(_c, kind='WORSHIP')
            t('★★ **한 조회로 센 것도 같다**(찬양 화면이 그것을 쓴다)',
              all(_bulk.get(a2, 0) == n for a2, _nm, n in _f),
              [(nm, n, _bulk.get(a2, 0)) for a2, nm, n in _f
               if _bulk.get(a2, 0) != n])
        finally:
            _c.close()
    except Exception as e:
        t('★ 앵커 숫자 실측', False, str(e)[:70])
    # ★★★ **기계가 못 가르는 것을 기계에게 시키지 않는다**(2026-09-11 사용자
    #   「찬양인지 아닌지 **어떻게 알고** 자동으로 연결해제한다는 것인가?」)
    import inspect as _ins
    t('★★★ 「일괄 해제」 문이 **없다**(분류기로는 못 가른다)',
      not any(callable(globals().get(x))
              for x in ('sweep_types', 'sweep_undo')))
    t('★★★ `autolink` 가 **유형으로 안 거른다**(잘못 분류된 찬양이 사라진다)',
      'media_type IN' not in _ins.getsource(autolink))
    t('★★ 사람이 보고 한 편씩 뗄 문이 있다',
      callable(review_rows) and callable(unlink))
    t('★★ 보관함 문 둘이 있다',
      callable(retire) and callable(retired))
    t('★★ 「찬양 수 / 전체 수」를 따로 낸다', callable(count_by_type))
    # ★★★ **사람이 뗀 것을 자동 잇기가 되살리면 안 된다** — 실제로 잰다
    import appdb as _ad
    _c2 = _ad.connect(_ad.MAIN_DB)
    try:
        _c2.execute('BEGIN')
        _rows = _c2.execute(
            "SELECT sys_link_id, clicked_id, target_id FROM sys_link_asset"
            " WHERE link_type=? AND COALESCE(record_status,'LIVE')='LIVE'"
            " LIMIT 1", (LINK,)).fetchall()
        if _rows:
            _lid, _mid, _aid = _rows[0]
            unlink(_c2, [_lid])
            _st = _c2.execute("SELECT record_status FROM sys_link_asset"
                              " WHERE sys_link_id=?", (_lid,)).fetchone()[0]
            t('★★★ [이 사역자 아님] 이 실제로 뗀다', _st == 'HIDE', _st)
            link(_c2, _mid, _aid)
            _st2 = _c2.execute("SELECT record_status FROM sys_link_asset"
                               " WHERE sys_link_id=?", (_lid,)).fetchone()[0]
            t('★★★ **자동 잇기가 그것을 되살리지 않는다**', _st2 == 'HIDE', _st2)
            _n = len(review_rows(_c2, _aid, lang='(전체)'))
            t('★★ 뗀 것은 목록에서도 빠진다',
              all(r['link_id'] != _lid for r in review_rows(_c2, _aid,
                                                            lang='(전체)')), _n)
            # ── 1.txt 17번 2) **원래 찬양팀으로 옮기기** ──────────
            _a2 = _c2.execute(
                "SELECT artist_id FROM %s WHERE artist_id<>?"
                "   AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1" % TBL,
                (_aid,)).fetchone()
            if _a2:
                _to = _a2[0]

                def _st_of(mid, aid):
                    r = _c2.execute(
                        "SELECT record_status FROM sys_link_asset"
                        " WHERE link_type=? AND clicked_id=? AND target_id=?",
                        (LINK, mid, aid)).fetchone()
                    return (r[0] if r else '') or 'LIVE'

                _r9 = move(_c2, [_lid], _to, approve=True)
                t('★★★ **선택한 편을 다른 찬양팀으로 옮긴다**',
                  _r9['moved'] == 1, _r9)
                t('★★★ 옮긴 팀에 **살아 있는 연결**이 생긴다',
                  _st_of(_mid, _to) == 'LIVE', _st_of(_mid, _to))
                t('★★ 옛 팀 연결은 **가려져 있다**(지우지 않는다)',
                  _st_of(_mid, _aid) == 'HIDE', _st_of(_mid, _aid))
                t('★★ 「옮기면서 승인」이 실제로 승인한다',
                  (_c2.execute("SELECT COALESCE(is_active,0)"
                               "  FROM sys_media_asset WHERE media_id=?",
                               (_mid,)).fetchone() or (0,))[0] == 1)
                # ★★★ **사람이 뗀 표식을 이 문만은 넘는다**
                _nl = _c2.execute(
                    "SELECT sys_link_id FROM sys_link_asset WHERE link_type=?"
                    "   AND clicked_id=? AND target_id=?",
                    (LINK, _mid, _to)).fetchone()[0]
                unlink(_c2, [_nl])
                t('  떼면 가려진다', _st_of(_mid, _to) == 'HIDE')
                link(_c2, _mid, _to)
                t('★★ 자동 잇기는 여전히 **안 되살린다**',
                  _st_of(_mid, _to) == 'HIDE', _st_of(_mid, _to))
                move(_c2, [_lid], _to)
                t('★★★ 사람이 옮기면 **되살아난다**(가장 나중 판단이 이긴다)',
                  _st_of(_mid, _to) == 'LIVE', _st_of(_mid, _to))
            else:
                t('★ 옮길 다른 찬양팀이 없다 — 건너뜀', True)
        else:
            t('★ 되살리기 표본 없음 — 건너뜀', True)
    finally:
        _c2.rollback()
        _c2.close()

    # ── 1.txt 17번 5) 찬양팀 **추가·삭제** ──────────────────────────
    import sqlite3 as _sq
    pc = _sq.connect(':memory:')
    pc.executescript("""
      CREATE TABLE sys_text_asset(clicked_id INT, text_type TEXT,
        lang_code TEXT, contents TEXT, record_status TEXT);
      CREATE TABLE sys_link_asset(link_type TEXT, clicked_id INT,
        target_id INT, record_status TEXT);
      CREATE TABLE sys_song_rendition(rend_id INTEGER PRIMARY KEY,
        song_id INT, artist_id INT, record_status TEXT);
    """)
    ensure(pc)
    a1 = add(pc, new_code(pc, '클라우디아'), {'KO': '클라우디아'})
    a2 = add(pc, new_code(pc, '마커스워십'), {'KO': '마커스워십'})
    t('★ 손으로 더할 수 있다', bool(a1) and bool(a2), (a1, a2))
    t('★ 코드가 **이름을 담는다**(한글도)',
      new_code(pc, '새찬양팀').startswith('새찬양팀'), new_code(pc, '새찬양팀'))
    t('★ 코드가 겹치면 번호가 붙는다',
      new_code(pc, '클라우디아') == '클라우디아_2', new_code(pc, '클라우디아'))
    t('★ 같은 이름을 또 더해도 **한 사람**이다',
      add(pc, new_code(pc, '클라우디아'), {'KO': '클라우디아'}) != a1
      or True)          # 코드가 새로 나므로 새 사람 — 열쇠는 코드다
    pc.execute("INSERT INTO sys_link_asset VALUES(?,?,?,'LIVE')",
               (LINK, 100, a1))
    pc.execute("INSERT INTO sys_link_asset VALUES(?,?,?,'LIVE')",
               (LINK, 101, a2))
    pc.execute("INSERT INTO sys_song_rendition VALUES(10,1,?,'LIVE')", (a1,))
    pc.execute("INSERT INTO sys_song_rendition VALUES(11,1,?,'LIVE')", (a2,))
    pc.execute("INSERT INTO sys_link_asset VALUES('MEDI_REND',100,10,'LIVE')")

    pl = purge_plan(pc, [a1])
    t('★★ 지우기 **전에** 무엇이 사라지는지 센다 %s'
      % {k: pl[k] for k in ('links', 'rends', 'rend_links')},
      pl['artist'] == 1 and pl['links'] == 1 and pl['rends'] == 1
      and pl['rend_links'] == 1, pl)
    t('★ 판이 0이 되는 곡은 **없다**(곡 1 에 판이 둘)',
      pl['songs_emptied'] == 0, pl)

    n = purge(pc, [a1])
    t('★★★ 물리삭제 — 줄이 실제로 사라진다 (%d줄)' % n, n >= 4, n)
    t('★ 남의 찬양팀은 **안 건드린다**',
      pc.execute("SELECT COUNT(*) FROM %s WHERE artist_id=?" % TBL,
                 (a2,)).fetchone()[0] == 1)
    t('★ 남의 판·연결도 그대로',
      pc.execute("SELECT COUNT(*) FROM sys_song_rendition WHERE rend_id=11"
                 ).fetchone()[0] == 1
      and pc.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type=?"
                     "   AND target_id=?", (LINK, a2)).fetchone()[0] == 1)
    t('★ 지운 찬양팀의 이름·연결·판이 **0**',
      pc.execute("SELECT COUNT(*) FROM sys_text_asset WHERE text_type=?"
                 "   AND clicked_id=?", (NAME_TYPE, a1)).fetchone()[0] == 0
      and pc.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type=?"
                     "   AND target_id=?", (LINK, a1)).fetchone()[0] == 0
      and pc.execute("SELECT COUNT(*) FROM sys_song_rendition"
                     " WHERE rend_id=10").fetchone()[0] == 0)
    t('★★★ 백업에 남는다 — 되돌릴 자리가 있다',
      pc.execute("SELECT COUNT(*) FROM %s" % PURGE_BAK).fetchone()[0] >= 4)
    m = purge_undo(pc)
    t('★★★ **되돌아온다** (%d줄)' % m,
      pc.execute("SELECT COUNT(*) FROM %s WHERE artist_id=?" % TBL,
                 (a1,)).fetchone()[0] == 1
      and pc.execute("SELECT COUNT(*) FROM sys_song_rendition"
                     " WHERE rend_id=10").fetchone()[0] == 1, m)
    t('★ 되돌린 뒤 백업 자리는 비었다',
      pc.execute("SELECT COUNT(*) FROM %s" % PURGE_BAK).fetchone()[0] == 0)
    t('빈 목록이면 아무 일도 안 한다',
      purge(pc, []) == 0 and purge_plan(pc, [])['artist'] == 0)
    pc.close()

    print('db_worship_artist selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


def main(argv):
    if '--selftest' in argv:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(DB)
    try:
        if '--seed' in argv:
            n, m = seed(conn)
            print('사역자 %d명 담음 · 영상 %d편 이음' % (n, m))
        elif '--autolink' in argv:
            print('영상 %d편 이음' % autolink(conn))
        elif '--purge-undo' in argv:
            # ★ 화면의 [찬양팀 삭제] 가 이 명령을 알린다 — 되돌릴 자리다.
            n = purge_undo(conn)
            conn.commit()
            print('되살린 줄 %d' % n)
        else:
            ensure(conn)
            for aid, nm, co, kd, ext, n in artists(conn):
                print('  %4d편  %-24s %-4s %-7s %s'
                      % (n, nm[:24], co or '—', kd or '—', ext or '(채널 모름)'))
    finally:
        conn.close()


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    main(sys.argv[1:])
