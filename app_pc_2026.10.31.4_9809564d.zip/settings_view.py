# -*- coding: utf-8 -*-
"""환경설정 창 (SettingsDialog) — 언어 / 성경버전(기본·선호·비교) / 읽기폰트.

배너 ⚙ 아이콘에서 진입. user_config에 저장. 저장 시 on_saved 콜백으로 P1 즉시 갱신.
(다크모드는 ui_theme 인프라 존재하나 메인 UI 미배선 — 별도 테마 작업으로 분리.)
"""
import json
import sqlite3
import sys

import appdb


def _C(role, fallback):
    try:
        import ui_theme
        return ui_theme.C(role) or fallback
    except Exception:
        return fallback

import tkinter as tk
from tkinter import ttk, messagebox
from tkinter import font as tkfont
from tkinter.scrolledtext import ScrolledText

import i18n
import lang_config
import ads
import theme_font
import ui_theme

# 종료 화면 안내 — 한국어 폴백(정본은 ui_strings `SET_CLOSE_HELP` 11언어).
# ⚠ 자원 수치는 **실측**이다(2026-09-03 · 본체 145MB · 트레이 18.6MB).
#   짐작으로 적지 않는다 — 틀리면 안내문이 거짓이 된다.
_CLOSE_HELP_KO = (
    '앱을 끌 때 무엇을 할지 미리 정해 둡니다. 정해 두면 끌 때 묻지 않습니다.\n'
    '\n'
    '완전히 끄기\n'
    '  앱이 통째로 종료됩니다. 새 공지와 자료는 다음에 앱을 켤 때 받습니다.\n'
    '\n'
    '트레이에 두기\n'
    '  · 하는 일 — 본체는 완전히 꺼지고, 아주 작은 프로그램 하나만 작업'
    ' 표시줄 오른쪽(트레이)에 남습니다. 3시간마다 새 공지와 링크 자료를'
    ' 미리 받아 둡니다.\n'
    '  · 자원 — 본체가 약 145MB 를 쓰는 데 견주어 트레이는 약 19MB 로'
    ' 8분의 1입니다. 성경 본문도 화면도 불러오지 않고, 받아 두는 일만'
    ' 합니다.\n'
    '  · 편리 — 다음에 앱을 켜면 이미 받아 둔 자료가 있어 기다리지 않습니다.'
    ' 새 소식이 오면 알림으로 알려 줍니다.\n'
    '  · 트레이 아이콘을 오른쪽 단추로 누르면 [지금 확인] [앱 열기] [종료]'
    ' 가 나옵니다.\n'
    '  · 앱이 켜져 있는 동안에는 아무 일도 하지 않습니다 — 같은 자료를 두'
    ' 곳에서 건드리지 않습니다.\n'
    '\n'
    '끌 때마다 묻기\n'
    '  끌 때 어느 쪽으로 할지 그때그때 선택합니다.\n'
    '\n'
    '※ 트레이는 윈도우에서만 동작합니다. 여기서 정한 것은 언제든 바꿀 수'
    ' 있습니다.')

# ⚠ 데이터 목록(읽기 폰트 선택지)이다 — 서식 하드코딩이 아니라 콤보 항목.
#   (2026-08-19 일괄 치환이 여기까지 지웠던 것을 복원 — 치환은 위젯 옵션만.)
_FONT_FAMILIES = ['Georgia', 'Malgun Gothic', 'Times New Roman', 'Batang',
                  'Gulim', 'Arial']
_FONT_SIZES = [str(n) for n in range(8, 17)]
_SPACINGS = ['기본', '넓게', '아주 넓게']


def _cfg_get(db, key, default=None):
    with appdb.connect(db) as c:
        r = c.execute("SELECT config_val FROM user_config WHERE config_key=?", (key,)).fetchone()
    return r[0] if r and r[0] is not None else default


def _cfg_set(db, key, val):
    with appdb.connect(db) as c:
        if c.execute("SELECT 1 FROM user_config WHERE config_key=?", (key,)).fetchone():
            c.execute("UPDATE user_config SET config_val=? WHERE config_key=?", (val, key))
        else:
            c.execute("INSERT INTO user_config(config_key,config_val) VALUES(?,?)", (key, val))
        c.commit()


# 역본 라이선스 판정 → (행 앞 표시, 색 역할). **판정을 숨기지 않는다** —
# 미확인·저작권 있는 역본은 고를 때 보여야 한다(db_version_license.py).
# ⚠ 색은 역할 이름으로 적고 쓰는 자리에서 _C 로 푼다 — 모듈 레벨에서 C() 를
#   부르면 import 시점 테마로 굳는다(§36-5b).
_LIC_MARK = {
    'PUBLIC_DOMAIN': ('',    ('accent',  '#1A5276')),
    'PERMISSIVE':    ('',    ('accent',  '#1A5276')),
    'COPYRIGHTED':   ('△ ',  ('danger',  '#922B21')),
    'UNVERIFIED':    ('? ',  ('warning', '#7E5109')),
}
_LIC_KO = {
    'PUBLIC_DOMAIN': '저작권 소멸',
    'PERMISSIVE':    '자유 이용 허용',
    'COPYRIGHTED':   '저작권 있음',
    'UNVERIFIED':    '라이선스 미확인',
}


_SPLASH_HELP_KO = (
    '시작 화면은 앱을 켤 때 가장 먼저 뜨는 화면입니다. 배경 사진과 '
    '즐겨찾기 구절이 함께 나옵니다.\n\n'
    '· 사진은 아래 목록에서 켜고 끕니다. 관리자가 보낸 사진과 내가 넣은 '
    '사진이 함께 쓰입니다.\n'
    '· [내 사진 추가] 사진을 선택하고 제목과 장면을 적으면 시작 화면 크기로 '
    '줄여 저장합니다(폰 원본 그대로 넣어도 됩니다).\n'
    '· 장면을 선택해 두면 그 뜻에 어울리는 구절이 나올 때 그 사진이 보입니다.\n'
    '· 목록에서 사진을 누르면 오른쪽에 보이고, 두 번 누르면 크게 열립니다.\n'
    '· ☑ 로 선택한 뒤 [켜기/끄기]로 시작 화면에 낼지 정합니다. 내 사진은 '
    '[삭제]로 지울 수 있고, 관리자가 끈 사진은 켤 수 없습니다.\n'
    '· 내 사진은 이 PC 에만 저장되며 밖으로 나가지 않습니다.\n'
    '· 본인이 찍었거나 쓸 권한이 있는 사진만 넣어 주세요.')


class SettingsTabsMixin:
    """언어/성경버전/폰트/시작화면/개인정보 탭 빌더 — 환경설정 팝업과 '지원/설정' 탭이 공용.
    호스트는 self.db(DB 경로)·self.on_saved(저장 후 콜백, 없어도 됨)를 제공한다."""

    def _load_vers(self):
        with appdb.connect(self.db) as c:
            self._vers = c.execute(
                "SELECT version_code, COALESCE(display_name, version_name, version_code), "
                "lang_code, COALESCE(versification_system,'MT') "
                "FROM bible_version ORDER BY version_code COLLATE NOCASE").fetchall()
            # 역본 라이선스 (db_version_license.py --init 로 생긴 컬럼).
            # ★ 역본을 고르는 자리에 보인다 — 켤지 말지를 정하는 데 필요한 정보이기 때문이다.
            #   앱 전체 고지(지도·폰트·Qt·원어 자료)는 여기가 아니라 '정보' 탭에 있다.
            try:
                self._ver_lic = {r[0]: (r[1] or 'UNVERIFIED', r[2] or '')
                                 for r in c.execute(
                                     'SELECT version_code, copyright_type, license_note'
                                     ' FROM bible_version')}
            except Exception:
                self._ver_lic = {}          # 컬럼이 아직 없으면 조용히 넘어간다
            # ★ 범위(구약만·신약만)와 기본 짝 — 반쪽 역본의 나머지 절반을
            #   무엇으로 채울지 고르는 자리에 쓴다(279차).
            try:
                self._ver_scope = {
                    r[0]: ((r[1] or 'FULL').upper(), r[2] or '')
                    for r in c.execute('SELECT version_code, coverage_scope,'
                                       ' partner_code FROM bible_version')}
            except Exception:
                self._ver_scope = {}

    def build_all_tabs(self, nb):
        """주어진 노트북에 설정 탭을 추가 — 언어·성경버전·폰트·시작화면·개인정보·정보."""
        self._load_vers()
        self._build_lang(nb)
        self._build_version(nb)
        self._build_font(nb)
        self._build_theme(nb)
        self._build_splash(nb)
        self._build_privacy(nb)
        self._build_about(nb)

    # ── 화면 색 (2026-08-13 사용자 지시) ──
    def _build_theme(self, nb):
        """테마 4가지. **선택하는 즉시 화면이 바뀐다** (2026-08-13 사용자 지시
        「미리보기 기능을 만들거나 즉시 변경되는 방식으로」).

        ⚠ 저장 버튼을 따로 두지 않는다 — 고른 것이 곧 결과이고, 마음에 안 들면
          다른 것을 고르면 된다. 「미리보기 따로 · 적용 따로」는 한 번 더 누르게 만든다.
        """
        import ui_theme
        f = tk.Frame(nb, bg=_C('bg', '#FAFAFA'))
        nb.add(f, text=' ' + i18n.t('SET_TAB_THEME', '화면 색') + ' ')

        # ★ 2026-10-15 docs/1.txt 77 — 맨 위·맨 아래 안내 줄 걷음 · 판 사이 간격 0 · 판 높이 절반.

        self._theme_cur = ui_theme.load(self.db_path)
        self._theme_cards = {}
        box = tk.Frame(f, bg=_C('bg', '#FAFAFA'))
        box.pack(anchor='w', padx=14, pady=(10, 0))

        for r, fam in enumerate(ui_theme.FAMILIES):
            fkey, fko = ui_theme.FAMILY_LABELS[fam]
            tk.Label(box, text=i18n.t(fkey, fko), bg=_C('bg', '#FAFAFA'), fg=_C('fg_dim', '#566573'),
                     font=('', 9, 'bold'), width=11, anchor='w'
                     ).grid(row=r, column=0, sticky='w')
            for c, name in enumerate(ui_theme.by_family(fam)):
                self._theme_cards[name] = self._theme_chip(box, name)
                self._theme_cards[name].grid(row=r, column=c + 1, sticky='w')
        self._theme_mark()


    # 색칩 크기 — 한 곳에서 정한다 (2026-08-13 사용자 지적 「미리보기 공간이 너무 좁아서
    # 아무런 도움이 되지 않는다」). 계열 4줄 × 4벌 이 한 화면에 들어가는 최대치로 잡았다.
    # ★ 2026-10-15 docs/1.txt 77 — 높이를 절반으로(84 → 42 · 아래 띠 16 → 10).
    _CHIP_W, _CHIP_H, _CHIP_BAR = 152, 42, 10

    def _theme_chip(self, parent, name):
        """색칩 하나 — **큼직한 색 판 + 색상코드**. 누르면 바로 바뀐다.

        ⚠ 이름(「진한 회색」·「청회색」)으로는 무슨 색인지 알 수 없다는 지적에 따라
          **이름을 빼고 색과 코드를 보인다**(2026-08-13 사용자 지시).
        ⚠ `tk` 의 width/height 는 **글자 수**다 — 픽셀로 못 박으려면
          `pack_propagate(False)` 를 꺼야 한다. 안 그러면 자식 크기를 따라간다.
        """
        import ui_theme
        p = ui_theme.PALETTE[name]
        # 바깥 테두리가 「고른 것」 표시를 맡는다 (안쪽 색을 건드리지 않는다)
        outer = tk.Frame(parent, bg=_C('bg', '#FAFAFA'), highlightthickness=3,
                         highlightbackground=_C('bg', '#FAFAFA'))
        # ★ **견본 표시** (2026-08-16). 이 표시가 있으면 `ui_theme.paint` 가 이 아래를
        #   통째로 건너뛴다. 예전에는 표시를 안 붙이고 **칠한 뒤 되돌리고** 있었는데,
        #   `paint` 는 화면이 바꾼 색을 새 원본으로 받으므로
        #   「칠한다 → 되돌린다 → 새 원본 → 또 칠한다」가 되어 색이 왔다갔다 했다.
        setattr(outer, ui_theme.SAMPLE, True)
        chip = tk.Frame(outer, bg=p['bg'], bd=1, relief='solid',
                        width=self._CHIP_W, height=self._CHIP_H, cursor='hand2')
        chip.pack(padx=1, pady=1)
        chip.pack_propagate(False)

        # 위: 큰 색 판 — 그 테마의 바탕색이 넓게 보이고 그 위에 코드가 얹힌다
        face = tk.Frame(chip, bg=p['bg'])
        face.pack(fill='both', expand=True)
        tk.Label(face, text=p['bg'].upper(), bg=p['bg'], fg=p['fg'],
                 font=('Consolas', 10, 'bold')).pack(expand=True)

        # 아래: 그 테마가 함께 쓰는 색들 — 머리띠·층·강조·흐린 글자
        bar = tk.Frame(chip, bg=p['panel'], height=self._CHIP_BAR)
        bar.pack(fill='x', side='bottom')
        bar.pack_propagate(False)
        for role in ('dark_bg', 'panel', 'accent'):
            tk.Frame(bar, bg=p[role], width=26).pack(side='left', fill='y')
        tk.Label(bar, text=' ' + p['fg'].upper(), bg=p['panel'], fg=p['fg_dim'],
                 font=('Consolas', 6)).pack(side='left', fill='y')

        # 칩 안 어디를 눌러도 골라져야 한다 — 자식 위젯이 클릭을 먹는다
        def bind_all(w):
            w.bind('<Button-1>', lambda _e, n=name: self._on_theme_pick(n))
            try:
                w.config(cursor='hand2')
            except Exception:
                pass
            for c in w.winfo_children():
                bind_all(c)
        bind_all(chip)
        return outer

    def _theme_mark(self):
        """지금 선택한 칩에 테두리를 두른다 — 표시색은 역할(warning), 바탕은 bg."""
        on, off = _C('warning', '#E67E22'), _C('bg', '#FAFAFA')
        for n, w in self._theme_cards.items():
            w.config(highlightbackground=on if n == self._theme_cur else off,
                     highlightcolor=on if n == self._theme_cur else off)

    def _on_theme_pick(self, name):
        """색칩을 누른 즉시 저장하고 **떠 있는 창 전부**를 다시 칠한다."""
        import ui_theme
        if name not in ui_theme.PALETTE:
            return
        self._theme_cur = name
        ui_theme.use(self.db_path, name)
        try:
            root = self.winfo_toplevel()
            ui_theme.apply_ttk(root)
            n = ui_theme.paint(root)
            # 이 창 말고 떠 있는 다른 창(팝업)도 함께
            for tl in root.winfo_children():
                if isinstance(tl, tk.Toplevel):
                    n += ui_theme.paint(tl)
            print(f'[theme] {name} — {n}곳 다시 칠함')
        except Exception as e:
            print(f'[theme apply] {e}')
        # ⚠ 색칩 자체는 **그 테마의 색을 보여 주는 견본**이라 다시 칠하면 안 된다.
        #   `paint` 가 훑고 지나갔을 수 있으므로 원래 색으로 되돌린다.
        try:
            self._theme_repaint_chips()
        except Exception:
            pass

    def _theme_repaint_chips(self):
        """견본 칩을 제 색으로 되돌리고 선택한 것에 테두리를 두른다.

        ⚠ 칩은 **그 테마를 보여 주는 견본**이라 `paint` 가 훑고 지나가면 안 된다.
          그런데 훑기는 위젯을 가리지 않으므로, 지나간 뒤 여기서 되돌린다.
        """
        import ui_theme
        for n, outer in self._theme_cards.items():
            p = ui_theme.PALETTE[n]
            chip = outer.winfo_children()[0]
            chip.config(bg=p['bg'])
            kids = chip.winfo_children()
            if len(kids) < 2:
                continue
            face, bar = kids[0], kids[1]
            face.config(bg=p['bg'])
            for w in face.winfo_children():
                w.config(bg=p['bg'], fg=p['fg'])
            bar.config(bg=p['panel'])
            bw = bar.winfo_children()
            for w, role in zip(bw, ('dark_bg', 'panel', 'accent')):
                w.config(bg=p[role])
            if len(bw) >= 4:
                bw[3].config(bg=p['panel'], fg=p['fg_dim'])
        self._theme_mark()

    # ── 정보 (출처·라이선스 고지) ──
    def _build_about(self, nb):
        """앱 전체 고지 — **두 탭**(2026-09-06 사용자 0.txt 8-3).

        ★ 사용자 지시 — 「**수록된 컨텐츠 라이센서와 이 앱의 라이센스를 구별**
          하여 표시하자. **두 탭으로 나누어라**. 우리가 만든 앱과 번역한 자료에
          대해서는 **별도의 라이선스 정보**를 표시해야 한다. 번역 자료는
          **번역스타일 등에 대해서 언급**하면 좋겠다.」
          ⇒ 「담긴 것(수록 자료)」과 「담는 것(이 앱)」으로 가른다.
          ⚠ 바깥 탭을 둘로 늘리지 않았다 — 공지/소통이 이미 여섯이라 이름이
            안 보인다. 안쪽 노트북 둘이면 지시(두 탭)를 그대로 지킨다.

        ★ 역본 라이선스는 여기가 아니라 **성경버전 탭**에 있다. 성격이 다르기 때문이다 —
          역본 라이선스는 「이 역본을 켤까」를 정하는 데 쓰는 정보이고, 여기 있는 것은
          읽을 일이 드문 고지다. 한 화면에 묶으면 역본 고르는 사람이 Qt 라이선스를 지난다.
        """
        f = tk.Frame(nb, bg=_C('bg', '#FAFAFA'))
        nb.add(f, text=' ' + i18n.t('SET_TAB_ABOUT', '라이선스정보') + ' ')
        tk.Label(f, bg=_C('bg', '#FAFAFA'), fg=_C('fg_dim', '#5D6D7E'), anchor='w', justify='left', wraplength=560,
                 font=('', 8),
                 text=i18n.t('SET_ABOUT_HINT',
                             '각 성경 역본의 라이선스는 「성경버전」 탭에서 역본 이름을 누르면 보입니다.')
                 ).pack(fill='x', padx=12, pady=(8, 2))
        inner = ttk.Notebook(f)
        inner.pack(fill='both', expand=True, padx=10, pady=(0, 10))
        try:
            from license_info import build_license_body
            lang = i18n.get_lang() or 'KO'
            # ★★ **성경 역본을 제 탭으로 뺐다**(2026-09-06 사용자 1-1) —
            #   역본은 하나하나 라이선스가 다르고 앞으로 유료 역본이 들어올
            #   자리다(§18-3). 「수록 자료」의 한 줄로 뭉뚱그리면 어느 역본이
            #   어느 조건인지 못 말하고, 역본을 더하는 날 그 줄이 거짓이 된다.
            #   ⚠ 성경버전 탭의 표식과 **역할이 다르다** — 그쪽은 「이 역본을
            #     켤까」를 정하는 자리이고 여기는 **배포물에 무엇이 실렸나**를
            #     적는 고지다. 둘 다 `bible_version` 한 표를 읽으므로 안 갈린다.
            # ★ 차례·이름은 **0.txt 1-1 지시 그대로**(2026-09-06):
            #   「현재 : 수록자료, 이 앱 → 수정 : **애플리케이션 / 수록자료 /
            #   성경버전**」. 담는 것(앱) → 담긴 것(자료) → 역본 순이다.
            for scope, key, dflt in (
                    ('APP', 'SET_LIC_APP', '애플리케이션'),
                    ('CONTENT', 'SET_LIC_CONTENT', '수록 자료'),
                    ('VERSION', 'SET_LIC_VERSION', '성경버전')):
                page = tk.Frame(inner, bg=_C('bg', '#FAFAFA'))
                inner.add(page, text=' ' + i18n.t(key, dflt) + ' ')
                build_license_body(page, lang, scope=scope).pack(
                    fill='both', expand=True)
        except Exception as e:
            tk.Label(f, bg=_C('bg', '#FAFAFA'), fg=_C('danger', '#922B21'),
                     text='%s' % e).pack(padx=12, pady=12)

    # ── 앱소개 / 후원 ──
    def _build_support(self, nb):
        """앱소개·후원 — **라이선스정보 오른쪽**(2026-09-06 사용자 0.txt 8-2).

        ⚠ **후원 계좌·링크를 지어내지 않는다**(§0-1b). 후원 자리는 `ads` 의
          `support_tab` 슬롯이고, 관리자가 켜기 전에는 **아무것도 안 그린다**.
          대신 왜 비어 있는지 한 줄로 말한다(빈 화면은 고장으로 읽힌다).
        ★ 소개 숫자는 **DB 에서 센다** — 손으로 적으면 자라는 앱에서 곧 거짓이 된다.
        """
        f = tk.Frame(nb, bg=_C('bg', '#FAFAFA'))
        nb.add(f, text=' ' + i18n.t('SET_TAB_SUPPORT', '앱소개/후원') + ' ')
        wrap = tk.Frame(f, bg=_C('bg', '#FAFAFA'))
        wrap.pack(fill='both', expand=True, padx=14, pady=12)

        tk.Label(wrap, bg=_C('bg', '#FAFAFA'), fg=_C('fg_title', '#1A5276'),
                 anchor='w', justify='left', font=('', 12, 'bold'),
                 text=i18n.t('SUP_TITLE', '하가 — 성경을 읽고 묵상하는 앱')
                 ).pack(fill='x', pady=(0, 6))
        tk.Label(wrap, bg=_C('bg', '#FAFAFA'), fg=_C('fg', '#333'),
                 anchor='w', justify='left', wraplength=620,
                 text=i18n.t(
                     'SUP_INTRO',
                     '성경 본문과 옛 신앙 고전을 한자리에 담고, 구절마다 설명문·'
                     '묵상 질문·기도를 붙여 두었습니다. 구절과 구절, 구절과 '
                     '용어를 이어 두어 한 대목에서 다른 대목으로 걸어갈 수 '
                     '있습니다. 인터넷이 없어도 대부분 그대로 읽힙니다.')
                 ).pack(fill='x', pady=(0, 10))

        # ★ 담긴 것 — 실측
        stat = tk.Label(wrap, bg=_C('bg', '#FAFAFA'), fg=_C('fg_dim', '#5D6D7E'),
                        anchor='w', justify='left', wraplength=620)
        stat.pack(fill='x', pady=(0, 12))
        try:
            stat.config(text=self._support_stats())
        except Exception:
            stat.pack_forget()

        tk.Label(wrap, bg=_C('bg', '#FAFAFA'), fg=_C('fg_title', '#1A5276'),
                 anchor='w', font=('', 11, 'bold'),
                 text=i18n.t('SUP_SPONSOR', '후원')).pack(fill='x', pady=(6, 4))
        tk.Label(wrap, bg=_C('bg', '#FAFAFA'), fg=_C('fg', '#333'),
                 anchor='w', justify='left', wraplength=620,
                 text=i18n.t(
                     'SUP_SPONSOR_NOTE',
                     '이 앱은 광고 추적을 하지 않습니다. 여러분이 무엇을 읽는지, '
                     '어디에 사는지 우리는 모읍니다 — 아래 자리는 앱을 돕는 곳을 '
                     '소개하는 자리이고, 누르기 전에는 아무것도 오가지 않습니다.')
                 ).pack(fill='x', pady=(0, 8))
        try:
            import ads
            self._sup_ad = ads.AdBanner(
                wrap, self.db_path, 'support_tab',
                lang_getter=lambda: i18n.get_lang() or 'KO',
                i18n_t=i18n.t, bg=_C('bg', '#FAFAFA'))
            self._sup_ad.pack(fill='x')
            if not self._sup_ad.winfo_children():
                tk.Label(wrap, bg=_C('bg', '#FAFAFA'),
                         fg=_C('fg_dim', '#7F8C8D'), anchor='w',
                         justify='left', wraplength=620,
                         text=i18n.t('SUP_NONE',
                                     '지금은 소개할 곳이 없습니다.')
                         ).pack(fill='x')
        except Exception:
            pass

    def _support_stats(self):
        """앱에 담긴 것 — **`app_facts` 한 문**이 센다(화면이 SQL 을 안 쓴다)."""
        import app_facts
        d = app_facts.library(self.db_path)
        return i18n.t(
            'SUP_STATS',
            '담긴 것 — 역본 %d · 도서·설교 %d권 · 주석 %d종 · '
            '구절 설명문 %s편 · 묵상플랜 %d개') % (
                d['versions'], d['books'], d['commentaries'],
                format(d['verse_notes'], ',d'), d['plans'])

    def _tab_savebar(self, parent, command):
        """각 설정 탭 상단 '저장' 버튼 — 위치 통일(§0: 액션은 상단)."""
        bar = tk.Frame(parent, bg=_C('bg', '#FAFAFA')); bar.pack(fill='x', padx=10, pady=(8, 0))
        tk.Button(bar, text=i18n.t('COMMON_SAVE', '저장'),
                  bg=_C('success', '#1E8449'), fg=_C('fg_on_dark', 'white'), bd=0,
                  padx=16, pady=4, font=('', 9, 'bold'),
                  command=command).pack(side='right')
        return bar

    def _notify_saved(self):
        if callable(getattr(self, 'on_saved', None)):
            try:
                self.on_saved()
            except Exception as e:
                print(f'[settings on_saved] {e}')

    # ── 시작 화면 사진(내 사진) ──
    def _build_splash(self, nb):
        """시작/종료 화면 — **갈래 둘**(2026-09-03 사용자 지시 「설정탭의
        서브탭이 많으니까 시작화면을 시작/종료화면이라고 수정하고 시작화면
        버튼, 종료화면 버튼을 배치하는 것은 어떨까」).

        ★ **종료 방식을 미리 정해 둔다** — 사용자 지적 「종료할 때 비로소
          팝업이 나오면 이상하게 생각할 것이다」. 옳다. 끄는 순간에 처음 보는
          선택지를 들이미는 것은 나쁘다. 여기서 정해 두면 끌 때 안 묻는다.
        ★ 시작과 종료는 **짝**이라 한 자리에 묶는다 — 서브탭도 안 는다.
        """
        f = tk.Frame(nb, bg=_C('bg', '#FAFAFA'))
        nb.add(f, text=' ' + i18n.t('SET_TAB_STARTEND', '시작/종료 화면') + ' ')

        bar = tk.Frame(f, bg=_C('bg', '#FAFAFA'))
        bar.pack(fill='x', padx=10, pady=(8, 0))
        host = tk.Frame(f, bg=_C('bg', '#FAFAFA'))
        host.pack(fill='both', expand=True)
        self._se_start = tk.Frame(host, bg=_C('bg', '#FAFAFA'))
        self._se_end = tk.Frame(host, bg=_C('bg', '#FAFAFA'))
        self._se_btn = {}
        for key, label, dflt in (('START', 'SET_SE_START', '시작 화면'),
                                 ('END', 'SET_SE_END', '종료 화면')):
            b = tk.Button(bar, text=i18n.t(label, dflt),
                          command=lambda k=key: self._se_show(k),
                          **ui_theme.flat_btn())
            b.pack(side='left', padx=(0, 4))
            self._se_btn[key] = b
        self._build_splash_body(self._se_start)
        self._build_close_body(self._se_end)
        self._se_show('START')

    def _se_show(self, key):
        """갈래 전환 — **파괴하지 않고 갈아 끼운다**(§3-1 문법). 파괴하면
        목록·미리보기를 매번 다시 지어야 한다."""
        for k, fr in (('START', self._se_start), ('END', self._se_end)):
            if k == key:
                fr.pack(fill='both', expand=True)
            else:
                fr.pack_forget()
        for k, b in self._se_btn.items():
            on = (k == key)
            try:
                b.configure(bg=_C('accent' if on else 'panel_alt', '#5D6D7E'),
                            fg=_C('fg_on_dark' if on else 'fg', '#FFFFFF'))
            except Exception:
                pass
        if key == 'END':
            self._close_load()

    # ── 종료 화면 — 끌 때 무엇을 할까 ──
    def _build_close_body(self, f):
        """종료 화면 — **좌우 분할**(2026-09-05 사용자 지시 0.txt 2-2
        「화면을 좌우로 분할하라. **좌측에 설명, 오른쪽에 옵션버튼들**을
        배치하라. 리사이즈」).

        ⚠ 예전에는 설명이 위, 옵션이 아래라 설명 17줄에 밀려 **옵션이 화면
          밖으로 나갔다**. 좌우로 두면 둘 다 한눈에 들어온다.
        """
        _pw = tk.PanedWindow(f, orient='horizontal', sashwidth=6,
                             bg=_C('bg', '#FAFAFA'), bd=0)
        _pw.pack(fill='both', expand=True, padx=6, pady=6)
        _L = tk.Frame(_pw, bg=_C('bg', '#FAFAFA'))
        _R = tk.Frame(_pw, bg=_C('bg', '#FAFAFA'))
        _pw.add(_L, minsize=260)
        _pw.add(_R, minsize=300)
        info = tk.Text(_L, wrap='word', bg=_C('panel', '#F4F8FB'),
                       relief='flat', font=('', 9), fg=_C('fg', '#333'),
                       padx=10, pady=8)
        info.pack(fill='both', expand=True, padx=4, pady=4)
        info.insert('1.0', i18n.t('SET_CLOSE_HELP', _CLOSE_HELP_KO))
        info.config(state='disabled')
        try:
            theme_font.register(info, self.db, 'ui')
        except Exception:
            pass

        box = tk.LabelFrame(
            _R, text=' ' + i18n.t('SET_CLOSE_MODE', '앱을 끌 때') + ' ',
            bg=_C('bg', '#FAFAFA'), fg=_C('fg', '#333'), padx=10, pady=6)
        box.pack(fill='x', padx=10, pady=(6, 4))
        self._close_var = tk.StringVar(value='ASK')
        for val, key, dflt in (
                ('TRAY', 'SET_CLOSE_TRAY', '트레이에 두기 (권장)'),
                ('EXIT', 'SET_CLOSE_EXIT', '완전히 끄기'),
                ('ASK', 'SET_CLOSE_ASK', '끌 때마다 묻기')):
            tk.Radiobutton(box, text=i18n.t(key, dflt), value=val,
                           variable=self._close_var, anchor='w',
                           command=self._close_save,
                           bg=_C('bg', '#FAFAFA'), fg=_C('fg', '#333'),
                           selectcolor=_C('panel', '#F4F8FB'),
                           activebackground=_C('bg', '#FAFAFA')).pack(
                fill='x', anchor='w')
        # ── 자동 수집 주기 (2026-09-03 사용자 지시 「3시간 주기로 서버에
        #    접근하면 그 자체로 부하가 될 수 있다 … 하루 1회 정도로 제한해야
        #    한다. 자동수집 주기를 설정하도록 하자」) ──
        sb = tk.LabelFrame(
            _R, text=' ' + i18n.t('SET_SYNC_BOX', '자동 수집') + ' ',
            bg=_C('bg', '#FAFAFA'), fg=_C('fg', '#333'), padx=10, pady=6)
        sb.pack(fill='x', padx=10, pady=(6, 4))
        row = tk.Frame(sb, bg=_C('bg', '#FAFAFA'))
        row.pack(fill='x')
        tk.Label(row, text=i18n.t('SET_SYNC_PERIOD', '주기'),
                 bg=_C('bg', '#FAFAFA'), fg=_C('fg', '#333')).pack(side='left')
        self._sync_p = ttk.Combobox(row, state='readonly', width=12)
        self._sync_p.pack(side='left', padx=(4, 16))
        self._sync_p.bind('<<ComboboxSelected>>', self._sync_save)
        tk.Label(row, text=i18n.t('SET_SYNC_WINDOW', '받는 시간대'),
                 bg=_C('bg', '#FAFAFA'), fg=_C('fg', '#333')).pack(side='left')
        self._sync_w = ttk.Combobox(row, state='readonly', width=12)
        self._sync_w.pack(side='left', padx=(4, 0))
        self._sync_w.bind('<<ComboboxSelected>>', self._sync_save)
        # ★ 「내 기기는 몇 시에 받나」를 계산해서 보인다 — 추상적인 설정만
        #   보이면 무슨 일이 일어나는지 모른다.
        self._sync_when = tk.Label(sb, text='', anchor='w',
                                   bg=_C('bg', '#FAFAFA'),
                                   fg=_C('fg_dim', '#777'), justify='left',
                                   wraplength=560)
        self._sync_when.pack(fill='x', pady=(6, 0))
        self._sync_box = sb

        self._close_msg = tk.Label(_R, text='', anchor='w',
                                   bg=_C('bg', '#FAFAFA'),
                                   fg=_C('fg_dim', '#777'))
        self._close_msg.pack(fill='x', padx=12, pady=(0, 8))
        if sys.platform != 'win32':
            self._close_msg.configure(
                text=i18n.t('SET_CLOSE_WINONLY',
                            '트레이는 윈도우에서만 동작합니다.'))

    # ── 자동 수집 ─────────────────────────────────────────────────────
    #: (코드, i18n 열쇠, 한국어 폴백) — 늘리려면 sync_schedule 과 함께 한 줄.
    _SYNC_P = [('DAILY', 'SET_SYNC_DAILY', '하루 1회'),
               ('H12', 'SET_SYNC_H12', '12시간마다'),
               ('H6', 'SET_SYNC_H6', '6시간마다'),
               ('MANUAL', 'SET_SYNC_MANUAL', '수동으로만')]
    _SYNC_W = [('ANY', 'SET_SYNC_ANY', '아무 때나'),
               ('DAWN', 'SET_SYNC_DAWN', '새벽(3~6시)'),
               ('MORNING', 'SET_SYNC_MORNING', '아침(6~9시)'),
               ('NOON', 'SET_SYNC_NOON', '점심(12~14시)'),
               ('EVENING', 'SET_SYNC_EVENING', '저녁(18~21시)'),
               ('NIGHT', 'SET_SYNC_NIGHT', '밤(22~1시)')]

    def _sync_load(self):
        import sync_schedule as SS
        self._sync_p['values'] = [i18n.t(k, d) for _, k, d in self._SYNC_P]
        self._sync_w['values'] = [i18n.t(k, d) for _, k, d in self._SYNC_W]
        try:
            with appdb.connect(self.db) as conn:
                p, w = SS.period(conn), SS.window(conn)
        except Exception:
            p, w = SS.DEFAULT_PERIOD, SS.DEFAULT_WINDOW
        self._sync_p.current([c for c, _, _ in self._SYNC_P].index(p))
        self._sync_w.current([c for c, _, _ in self._SYNC_W].index(w))
        self._sync_when_update()
        self._sync_gate()

    def _sync_save(self, _e=None):
        import sync_schedule as SS
        try:
            with appdb.connect(self.db) as conn:
                SS.set_period(conn, self._SYNC_P[self._sync_p.current()][0])
                SS.set_window(conn, self._SYNC_W[self._sync_w.current()][0])
        except Exception as e:
            self._close_msg.configure(text='%s' % e)
            return
        self._sync_when_update()
        self._sync_gate()
        self._close_msg.configure(text=i18n.t('SET_CLOSE_SAVED', '저장했습니다.'))

    def _sync_when_update(self):
        """이 기기가 받을 시각을 계산해 한 줄로."""
        import sync_schedule as SS
        try:
            with appdb.connect(self.db) as conn:
                d = SS.describe(conn)
        except Exception:
            d = None
        if not d:
            self._sync_when.configure(text=i18n.t(
                'SET_SYNC_WHEN_MANUAL',
                '자동으로 받지 않습니다. 트레이 아이콘의 [지금 확인] 으로만'
                ' 받습니다.'))
            return
        self._sync_when.configure(text=i18n.t(
            'SET_SYNC_WHEN',
            '이 기기는 약 %02d시 %02d분에 받습니다. 이 시각은 기기마다 다르게'
            ' 정해집니다 — 모두가 같은 순간에 몰리지 않도록 흩어 놓습니다.') % d)

    def _sync_gate(self):
        """트레이가 아니면 자동 수집 설정은 뜻이 없다 — 잠그고 이유를 말한다."""
        on = (getattr(self, '_close_var', None) is not None
              and self._close_var.get() == 'TRAY')
        for w in (self._sync_p, self._sync_w):
            try:
                w.configure(state='readonly' if on else 'disabled')
            except Exception:
                pass
        if not on:
            self._sync_when.configure(text=i18n.t(
                'SET_SYNC_NEED_TRAY',
                '「트레이에 두기」를 선택하면 자동 수집 주기를 정할 수 있습니다.'))
        else:
            self._sync_when_update()

    def _close_load(self):
        """저장된 값을 읽어 라디오에 반영. 없으면 「끌 때마다 묻기」."""
        v = 'ASK'
        try:
            with appdb.connect(self.db) as conn:
                r = conn.execute("SELECT config_val FROM user_config"
                                 " WHERE config_key='CLOSE_MODE'").fetchone()
            if r and r[0] in ('EXIT', 'TRAY'):
                v = r[0]
        except Exception:
            pass
        try:
            self._close_var.set(v)
        except Exception:
            pass
        try:
            self._sync_load()
        except Exception:
            pass

    def _close_save(self):
        """선택한 즉시 저장 — 저장 버튼을 따로 두지 않는다(테마와 같은 문법).

        ⚠ 「끌 때마다 묻기」는 **행을 지운다** — `user_main._ask_close` 가
          「값이 EXIT/TRAY 가 아니면 묻는다」로 읽기 때문이다. 빈 문자열을
          넣어 두면 같은 뜻이지만, 지우는 편이 「설정 안 함」을 정확히 말한다.
        """
        v = self._close_var.get()
        try:
            with appdb.connect(self.db) as conn:
                if v in ('EXIT', 'TRAY'):
                    cur = conn.execute(
                        "UPDATE user_config SET config_val=?"
                        " WHERE config_key='CLOSE_MODE'", (v,))
                    if cur.rowcount == 0:
                        conn.execute(
                            "INSERT INTO user_config(config_key, config_val)"
                            " VALUES('CLOSE_MODE',?)", (v,))
                else:
                    conn.execute("DELETE FROM user_config"
                                 " WHERE config_key='CLOSE_MODE'")
                conn.commit()
            self._close_msg.configure(
                text=i18n.t('SET_CLOSE_SAVED', '저장했습니다.'))
            self._sync_gate()          # 트레이를 골랐을 때만 주기 설정이 산다
        except Exception as e:
            self._close_msg.configure(text='%s' % e)

    def _build_splash_body(self, f):
        """시작 화면 — **상하 분할**(2026-09-05 사용자 지시 0.txt 2-1).

        ★ **상단** = 좌(사용법 설명) · 우(표시 방법: 표시여부 · 구절 표시 ·
          미리보기)  ·  **하단** = 버튼 줄 + 좌(사진 목록) · 우(썸네일).
        ★★ **사시로 나눈다**(PanedWindow) — 사진이 늘면 아래를 넓히면 된다
          (사용자 「사진목록 등이 길어질 가능성을 생각해서」).
        ⚠ **관리자사진/내사진 필터를 걷었다**(사용자 — 「불필요함, 아래
          목록에서 선택하면 되기 때문」). 목록의 「출처」 칸이 이미 말한다.
        ⚠ **저장 단추가 없다**(사용자 — 「모두 즉시 저장하면 버튼 필요 없음」)
          — 고르는 즉시 저장한다. 테마·글꼴 설정과 같은 문법.
        """
        try:   # 신규/빈 user_data.db 대비 테이블 보장
            import splash_screen as _ss0
            with appdb.connect(self.db) as _c0:
                _ss0.ensure_schema(_c0)
        except Exception:
            pass
        import splash_screen as _ss
        import tkinter.font as _tkf
        _stl = _ss.load_style()
        BG = _C('bg', '#FAFAFA')

        pw = tk.PanedWindow(f, orient='vertical', sashwidth=6,
                            bg=BG, bd=0)
        pw.pack(fill='both', expand=True, padx=8, pady=6)
        top = tk.Frame(pw, bg=BG)
        bot = tk.Frame(pw, bg=BG)
        pw.add(top, minsize=180)
        pw.add(bot, minsize=160)

        # ══ 상단 좌 — 사용법 ═══════════════════════════════════════
        tl = tk.Frame(top, bg=BG)
        tl.pack(side='left', fill='both', expand=True)
        info = tk.Text(tl, height=9, wrap='word', bg=_C('panel', '#F4F8FB'),
                       relief='flat', font=('', 9), fg=_C('fg', '#333'),
                       padx=10, pady=8)
        info.pack(fill='both', expand=True)
        info.insert('1.0', i18n.t('SET_SPLASH_HELP2', _SPLASH_HELP_KO))
        info.config(state='disabled')
        # ★ **표준서식**(§36) — 글꼴을 박지 않고 설정을 따른다.
        try:
            theme_font.register(info, self.db, 'ui')
        except Exception:
            pass

        # ══ 상단 우 — 표시 방법 ════════════════════════════════════
        tr = tk.LabelFrame(top, text=' ' + i18n.t('SET_SPLASH_HOW',
                                                  '표시 방법') + ' ',
                           bg=BG, font=('', 9, 'bold'))
        tr.pack(side='right', fill='y', padx=(8, 0))

        # ① 시작화면을 볼까 — **끄면 곧장 앱으로**
        r0 = tk.Frame(tr, bg=BG)
        r0.pack(fill='x', padx=8, pady=(6, 2))
        tk.Label(r0, text=i18n.t('SET_SPLASH_SHOWQ', '시작 화면'), bg=BG,
                 width=7, anchor='w').pack(side='left')
        self._sp_show = tk.IntVar(value=int(_stl.get('show', 1)))
        for val, key, dflt in ((1, 'SET_SPLASH_SHOW_ON', '표시'),
                               (0, 'SET_SPLASH_SHOW_OFF', '표시 안 함')):
            tk.Radiobutton(r0, text=i18n.t(key, dflt), variable=self._sp_show,
                           value=val, bg=BG,
                           command=self._splash_save_style).pack(side='left',
                                                                 padx=4)

        # ② 구절 표시 — 자리·크기·폰트·색
        r1 = tk.Frame(tr, bg=BG)
        r1.pack(fill='x', padx=8, pady=(8, 3))
        tk.Label(r1, text=i18n.t('SET_SPLASH_POS', '글자 띠'), bg=BG,
                 width=7, anchor='w').pack(side='left')
        self._sp_pos = tk.StringVar(value=_stl['pos'])
        for val, lbl in (('top', i18n.t('SET_SPLASH_TOP', '사진 위')),
                         ('bottom', i18n.t('SET_SPLASH_BOT', '사진 아래'))):
            tk.Radiobutton(r1, text=lbl, variable=self._sp_pos, value=val,
                           bg=BG,
                           command=self._splash_save_style).pack(side='left',
                                                                 padx=4)
        r2 = tk.Frame(tr, bg=BG)
        r2.pack(fill='x', padx=8, pady=3)
        tk.Label(r2, text=i18n.t('SET_SPLASH_SIZE', '크기'), bg=BG,
                 width=7, anchor='w').pack(side='left')
        self._sp_size = tk.IntVar(value=_stl['size'])
        tk.Spinbox(r2, from_=10, to=48, width=5, textvariable=self._sp_size,
                   command=self._splash_save_style).pack(side='left')
        tk.Label(r2, text=i18n.t('SET_SPLASH_FONT', '폰트'),
                 bg=BG).pack(side='left', padx=(14, 4))
        _fams = sorted(set(_tkf.families()))
        self._sp_font = ttk.Combobox(r2, values=_fams, width=18,
                                     state='readonly')
        self._sp_font.set(_stl['font'] if _stl['font'] in _fams else '')
        self._sp_font.pack(side='left')
        self._sp_font.bind('<<ComboboxSelected>>',
                           lambda _e: self._splash_save_style())
        r3 = tk.Frame(tr, bg=BG)
        r3.pack(fill='x', padx=8, pady=3)
        tk.Label(r3, text=i18n.t('SET_SPLASH_COLOR', '글자색'), bg=BG,
                 width=7, anchor='w').pack(side='left')
        self._sp_color = _stl['color']
        # ★ 색 견본 — 고른 색 자체가 내용이라 표준서식 예외(§36-5b SAMPLE).
        self._sp_color_btn = tk.Button(r3, text='     ', bg=self._sp_color,
                                       width=5,
                                       command=self._splash_pick_color)
        try:
            import ui_theme as _uth
            setattr(self._sp_color_btn, _uth.SAMPLE, True)
        except Exception:
            pass
        self._sp_color_btn.pack(side='left')
        # ★ **띠 배경색도 고른다**(2026-09-05 사용자 지시) — 사진마다 어울리는
        #   결이 달라 중립 하나로는 부족하다.
        tk.Label(r3, text=i18n.t('SET_SPLASH_BG', '배경색'),
                 bg=BG).pack(side='left', padx=(14, 4))
        self._sp_bg = _stl.get('bg', '#1C1C1E')
        self._sp_bg_btn = tk.Button(r3, text='     ', bg=self._sp_bg, width=5,
                                    command=self._splash_pick_bg)
        try:
            import ui_theme as _uth2
            setattr(self._sp_bg_btn, _uth2.SAMPLE, True)
        except Exception:
            pass
        self._sp_bg_btn.pack(side='left')
        # ★ **설명 글꼴 크기** — 사진 설명은 구절보다 작아야 하지만 얼마나
        #   작을지는 사람마다 다르다(사용자 지시).
        r3b = tk.Frame(tr, bg=BG)
        r3b.pack(fill='x', padx=8, pady=3)
        tk.Label(r3b, text=i18n.t('SET_SPLASH_DESCSZ', '설명 크기'), bg=BG,
                 width=7, anchor='w').pack(side='left')
        self._sp_dsize = tk.IntVar(value=int(_stl.get('desc_size', 10)))
        tk.Spinbox(r3b, from_=7, to=28, width=5,
                   textvariable=self._sp_dsize,
                   command=self._splash_save_style).pack(side='left')
        tk.Label(r3b, text=i18n.t('SET_SPLASH_DESCSZ_HINT',
                                  '(사진 설명 · 구절 아래 한 줄)'),
                 bg=BG, fg=_C('fg_dim', '#888'), font=('', 8)
                 ).pack(side='left', padx=(8, 0))

        # ③ 미리보기 — **진짜 시작 화면을 띄운다**(사진 + 구절)
        r4 = tk.Frame(tr, bg=BG)
        r4.pack(fill='x', padx=8, pady=(8, 8))
        tk.Button(r4, text=i18n.t('SET_SPLASH_PREVIEW_BTN',
                                  '미리보기 (실제 화면)'),
                  command=self._splash_preview_real,
                  **ui_theme.flat_btn()).pack(side='left')

        # ══ 하단 — 버튼 줄 ═════════════════════════════════════════
        bar = tk.Frame(bot, bg=BG)
        bar.pack(fill='x', pady=(6, 4))
        # ★★ **켜기/끄기를 갈랐다**(2026-09-05 사용자 지시 「Turn ON,
        #   Turn OFF (관리자 사진을 **숨기기 하는 것도 OFF**)」) — 토글은
        #   누르기 전에 무엇이 될지 모른다.
        for key, dflt, cmd in (
                ('SET_SPLASH_ADD', '내 사진 추가', self._splash_add),
                ('SET_SPLASH_TURNON', 'Turn ON',
                 lambda: self._splash_turn(True)),
                ('SET_SPLASH_TURNOFF', 'Turn OFF',
                 lambda: self._splash_turn(False)),
                ('SET_SPLASH_DEL', '삭제', self._splash_delete_checked),
                ('COMMON_REFRESH', '새로고침', self._splash_reload)):
            tk.Button(bar, text=i18n.t(key, dflt), command=cmd,
                      **ui_theme.flat_btn()).pack(side='left', padx=3)

        # ★★ **목록 위 오른쪽에 필터 둘**(2026-09-05 사용자 지시
        #   「사진목록 표시 상단 오른쪽에 … 전체/관리자사진/내사진 ·
        #    전체/켜진것/꺼진것/가린것」).
        #   ⚠ **라디오다** — 「전체」가 있는 이상 배타적 선택이고, 체크박스로
        #     두면 「전체 + 내사진」 같은 뜻 없는 조합이 생긴다.
        # ★ **필터를 명령 단추와 한 줄에**(사용자 지시). 글자는 단추만큼
        #   작게 — 사용자가 「예외적으로 버튼처럼 작은 글자 하드코딩」을
        #   허용했다(§0 표준서식의 명시적 예외).
        # ⚠ **가린 것도 OFF 에 넣는다**(사용자 지시) — 사용자에게는 「안 나온다」
        #   한 가지이고, 왜 안 나오는지는 상태 칸이 말한다.
        _RF = dict(bg=BG, font=('', 8), padx=0, pady=0)
        self._sp_src = tk.StringVar(value='ALL')
        self._sp_state = tk.StringVar(value='ALL')
        for val, key, dflt in (('ALL', 'SET_SPLASH_F_ALL', '전체'),
                               ('SYS', 'SET_SPLASH_F_SYS', '관리자'),
                               ('USER', 'SET_SPLASH_F_USER', '사용자')):
            tk.Radiobutton(bar, text=i18n.t(key, dflt), value=val,
                           variable=self._sp_src,
                           command=self._splash_reload,
                           **_RF).pack(side='left')
        tk.Label(bar, text='   ', bg=BG).pack(side='left')      # 공백
        for val, key, dflt in (('ALL', 'SET_SPLASH_F_ALL', '전체'),
                               ('ON', 'SET_SPLASH_F_ON2', 'ON'),
                               ('OFF', 'SET_SPLASH_F_OFF2', 'OFF')):
            tk.Radiobutton(bar, text=i18n.t(key, dflt), value=val,
                           variable=self._sp_state,
                           command=self._splash_reload,
                           **_RF).pack(side='left')

        # ══ 하단 — 좌(목록) · 우(썸네일) ═══════════════════════════
        body = tk.Frame(bot, bg=BG)
        body.pack(fill='both', expand=True)
        # ★★ **어떤 사진인지 보고 고른다** — 제목만으로는 무엇을 가릴지
        #   정할 수 없다(2026-09-05) ⇒ **장면 · 대륙** 칸.
        # ⚠ **상태가 출처보다 앞**이다(사용자 지시) — 무엇을 켜고 끌지가
        #   먼저 눈에 들어와야 한다.
        cols = ('chk', 'state', 'src', 'name', 'where')
        lf = tk.Frame(body, bg=BG)
        lf.pack(side='left', fill='both', expand=True)
        self._splash_tree = ttk.Treeview(lf, columns=cols, show='headings',
                                         height=8)
        for c, t, w, a in (
                ('chk', '☐', 34, 'center'),
                ('state', i18n.t('SET_SPLASH_COL_STATE', '상태'), 96,
                 'center'),
                ('src', i18n.t('SET_SPLASH_COL_SRC', '출처'), 72, 'center'),
                ('name', i18n.t('SET_SPLASH_COL_NAME', '제목'), 160, 'w'),
                ('where', i18n.t('SET_SPLASH_COL_WHERE', '장면 · 대륙'),
                 150, 'w')):
            self._splash_tree.heading(c, text=t)
            self._splash_tree.column(c, width=w, anchor=a)
        sb = ttk.Scrollbar(lf, orient='vertical',
                           command=self._splash_tree.yview)
        self._splash_tree.configure(yscrollcommand=sb.set)
        self._splash_tree.pack(side='left', fill='both', expand=True)
        sb.pack(side='right', fill='y')
        self._splash_tree.tag_configure('off',
                                        foreground=_C('fg_dim', '#aaaaaa'))
        self._splash_tree.bind('<Button-1>', self._on_splash_click)
        self._splash_tree.bind('<<TreeviewSelect>>', self._on_splash_select)
        # ★★ **더블클릭 = 내 사진 고치기**(2026-09-05 사용자 지시 「더블클릭
        #   하면 사용자가 **자신이 올린 사진은 제목, 설명문, 콤보값 등을
        #   수정**할 수 있도록 하라」). 크게 보기는 걷었다.
        self._splash_tree.bind('<Double-1>', self._splash_edit_mine)

        rf = tk.Frame(body, bg=BG, width=320)
        rf.pack(side='right', fill='y', padx=(8, 0))
        rf.pack_propagate(False)
        # ⚠ 라벨을 걷었다(사용자 지시) — 썸네일 자체가 무엇인지 말한다.
        self._sp_thumb = tk.Label(
            rf, bg=_C('panel', '#FFFFFF'), bd=1, relief='solid',
            text=i18n.t('SET_SPLASH_PREVIEW_EMPTY', '목록에서 사진을 클릭하세요'),
            fg=_C('fg_dim', '#999'), font=('', 9))
        self._sp_thumb.pack(fill='both', expand=True, pady=(2, 0))

        self._sp_checked = set()
        self._splash_reload()
        # ⚠ 사시는 위젯이 실제로 그려진 뒤에 놓는다(그전에는 폭이 1이다).
        self.after(160, lambda: self._sash_init(pw))

    def _sash_init(self, pw):
        try:
            h = pw.winfo_height()
            if h > 260:
                pw.sash_place(0, 0, int(h * 0.42))
        except Exception:
            pass

    def _splash_preview_real(self):
        """**진짜 시작 화면**을 그대로 띄운다 (사용자 지시 「미리보기 버튼 배치
        (사진+구절표시, **실제 팝업화면을 보여주기**)」).

        ⚠ **다시 그리지 않는다** — `show_splash` 를 그대로 부른다. 흉내를 내면
          진짜 화면과 어긋나서 미리보기가 거짓말이 된다.
        ⚠ 지금 고른 값이 바로 보이도록 **먼저 저장**한다(파일 캐시를 읽으므로).
        """
        try:
            self._splash_save_style()
            import splash_screen as _ss
            win = _ss.show_splash(root=self.winfo_toplevel())
            _ss.arm_dismiss(win, lambda *_a: win.destroy())
            try:
                win.attributes('-topmost', True)
            except Exception:
                pass
        except Exception as e:
            from tkinter import messagebox
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), str(e))

    def _splash_blob(self, iid):
        """목록 iid('S%d'/'U%d')의 PNG 바이트 조회."""
        try:
            tbl = 'sys_splash_image' if iid.startswith('S') else 'user_splash_image'
            with appdb.connect(self.db) as c:
                r = c.execute(f"SELECT png_blob FROM {tbl} WHERE img_id=?", (int(iid[1:]),)).fetchone()
            return r[0] if r and r[0] else None
        except Exception:
            return None

    def _on_splash_select(self, _e=None):
        """선택 사진을 저장 버튼 왼쪽 라벨에 작은 썸네일로 미리보기."""
        tv = getattr(self, '_splash_tree', None)
        sel = tv.selection() if tv else None
        if not sel:
            return
        blob = self._splash_blob(sel[0])
        if not blob:
            self._sp_thumb.config(image='', text='')
            return
        try:
            from PIL import Image, ImageTk
            import io as _io
            im = Image.open(_io.BytesIO(blob)); im.thumbnail((290, 140))
            self._sp_thumb_img = ImageTk.PhotoImage(im)   # 참조 유지(GC 방지)
            self._sp_thumb.config(image=self._sp_thumb_img, text='')
        except Exception:
            self._sp_thumb.config(image='', text='[미리보기 불가]')

    def _splash_open_preview(self, _e=None):
        """더블클릭 — 선택 사진을 큰 창으로 미리보기."""
        from tkinter import messagebox
        tv = getattr(self, '_splash_tree', None)
        sel = tv.selection() if tv else None
        if not sel:
            return
        blob = self._splash_blob(sel[0])
        if not blob:
            return
        # ⚠⚠ **PIL 이 없으면 아무것도 안 보였다** (2026-09-05 사용자 신고
        #   「지금은 더블클릭해도 크게 보이지 않음」). 사진은 이미 PNG 라
        #   **Tk 가 그대로 그린다** — PIL 은 줄이는 데만 쓰였다.
        #   ⇒ PIL 이 있으면 매끄럽게 줄이고, 없으면 `subsample` 로 줄인다.
        #     어느 쪽이든 **크게 보인다**(§db_splash_scene.make_thumb 과 같은 문법).
        win = None
        try:
            win = tk.Toplevel(self)
            win.title(i18n.t('SET_SPLASH_PREVIEW', '미리보기'))
            win.transient(self.winfo_toplevel())
            try:
                ui_theme.adopt(win)
            except Exception:
                pass
            ph = None
            try:
                from PIL import Image, ImageTk
                import io as _io
                im = Image.open(_io.BytesIO(blob))
                im.thumbnail((900, 620))
                ph = ImageTk.PhotoImage(im)
            except Exception:
                src = tk.PhotoImage(data=blob)
                k = 1
                while src.width() // k > 900 or src.height() // k > 620:
                    k += 1
                ph = src.subsample(k, k) if k > 1 else src
            lbl = tk.Label(win, image=ph)
            lbl.image = ph            # ⚠ 참조를 잡아 두지 않으면 GC 로 빈 창
            lbl.pack(padx=6, pady=6)
            tk.Button(win, text=i18n.t('COMMON_CLOSE', '닫기'),
                      command=win.destroy,
                      **ui_theme.flat_btn()).pack(pady=(0, 8))
            win.bind('<Escape>', lambda _e: win.destroy())
        except Exception as e:
            try:
                if win is not None:
                    win.destroy()
            except Exception:
                pass
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), str(e))

    def _splash_pick_color(self):
        from tkinter import colorchooser
        c = colorchooser.askcolor(color=getattr(self, '_sp_color', '#FFFFFF'),
                                  title=i18n.t('SET_SPLASH_COLOR', '글자색'))
        if c and c[1]:
            self._sp_color = c[1]
            self._sp_color_btn.config(bg=self._sp_color)

    def _splash_pick_bg(self):
        """띠 배경색 — 선택하면 바로 저장한다."""
        from tkinter import colorchooser
        c = colorchooser.askcolor(color=getattr(self, '_sp_bg', '#1C1C1E'),
                                  title=i18n.t('SET_SPLASH_BG', '배경색'))
        if c and c[1]:
            self._sp_bg = c[1]
            self._sp_bg_btn.config(bg=self._sp_bg)
            self._splash_save_style()

    def _splash_save_style(self):
        """★ **즉시 저장**(2026-09-05 사용자 지시) — 저장 단추가 없다.

        ⚠ **알림 상자를 띄우지 않는다** — 값을 고칠 때마다 뜨면 방해가 된다.
          고른 것이 곧 저장이라는 것은 화면이 이미 보인다(값이 남아 있다).
        """
        import splash_screen as _ss
        try:
            _ss.save_style(
                pos=self._sp_pos.get(),
                color=getattr(self, '_sp_color', '#FFFFFF'),
                size=self._sp_size.get(), font=self._sp_font.get(),
                show=self._sp_show.get() if hasattr(self, '_sp_show') else None,
                bg=getattr(self, '_sp_bg', None),
                desc_size=(self._sp_dsize.get()
                           if hasattr(self, '_sp_dsize') else None))
        except Exception as e:
            from tkinter import messagebox
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), str(e))

    def _sp_mark(self, iid):
        return '☑' if iid in getattr(self, '_sp_checked', set()) else '☐'

    def _on_splash_click(self, e):
        tv = self._splash_tree
        if tv.identify_region(e.x, e.y) != 'cell':
            return
        if tv.identify_column(e.x) != '#1':   # 체크 칸만
            return
        iid = tv.identify_row(e.y)
        if not iid:
            return
        if iid in self._sp_checked:
            self._sp_checked.discard(iid)
        else:
            self._sp_checked.add(iid)
        tv.set(iid, 'chk', self._sp_mark(iid))

    def _sp_scene_mod(self, c):
        """장면 모듈 — 없거나 표가 아직 없으면 None(화면은 그대로 돈다)."""
        try:
            import db_splash_scene as _sc
            _sc.init(c)
            return _sc
        except Exception:
            return None

    def _sp_where(self, sc, scene, continent):
        """`장면 · 대륙` 한 칸. 둘 다 없으면 빈 칸."""
        if not sc:
            return ''
        parts = []
        if scene and scene in sc.SCENE_BY:
            parts.append(sc.SCENE_BY[scene][2])
        if continent:
            parts.append(sc.continent_name(continent, i18n.get_lang()))
        return ' · '.join(parts)

    def _splash_reload(self):
        tv = getattr(self, '_splash_tree', None)
        if tv is None:
            return
        tv.delete(*tv.get_children())
        # ★ 필터 둘 — 출처(전체/관리자/내 사진) · 상태(전체/켜짐/꺼짐/가림)
        src_f = (self._sp_src.get() if hasattr(self, '_sp_src') else 'ALL')
        st_f = (self._sp_state.get() if hasattr(self, '_sp_state') else 'ALL')
        show_sys = src_f in ('ALL', 'SYS')
        show_user = src_f in ('ALL', 'USER')

        def _keep(tag, hidden_me):
            """상태 필터 — `ON` 나옴 · `OFF` 안 나옴.

            ⚠ **가린 것도 OFF 다**(2026-09-05 사용자 지시) — 사용자에게는
              「안 나온다」 한 가지이고, 관리자가 껐는지 내가 가렸는지는
              켜려 할 때 알려 준다(`_splash_turn`).
            """
            if st_f == 'ALL':
                return True
            if st_f == 'ON':
                return tag != 'off'
            return tag == 'off'
        live = set()
        try:
            with appdb.connect(self.db) as c:
                hidden = {r[0] for r in c.execute("SELECT sys_img_id FROM user_splash_hidden")}
                # ★ 장면·대륙을 함께 읽는다 — 없으면 빈 칸(칸을 지어내지 않는다)
                _sc, _lang = self._sp_scene_mod(c), (i18n.get_lang() or 'KO')
                if show_sys:
                    for img_id, name, act, _scn, _cnt in c.execute(
                            "SELECT img_id, COALESCE(name,''), is_active,"
                            " COALESCE(scene,''), COALESCE(continent,'')"
                            " FROM sys_splash_image ORDER BY img_id"):
                        iid = 'S%d' % img_id; live.add(iid)
                        # ★★ **그 언어의 제목이 이긴다** — 다국어를 적어 두고도
                        #   목록이 영문 이름만 보이면 적은 뜻이 없다.
                        if _sc:
                            _t, _ = _sc.photo_text(c, img_id, _lang, 'SYS')
                            name = _t or name
                        # ★ **상태는 ON / OFF 두 글자**(2026-09-05 사용자 지시).
                        #   ⚠ 왜 꺼졌는지는 여기 안 적는다 — 켜려다 막히면
                        #     그때 말한다(`_splash_turn`). 목록은 짧아야 읽힌다.
                        if img_id in hidden or not act:
                            state, tag = 'OFF', 'off'
                        else:
                            state, tag = 'ON', ''
                        if not _keep(tag, img_id in hidden):
                            live.discard(iid)
                            continue
                        tv.insert('', 'end', iid=iid, tags=(tag,) if tag else (),
                                  values=(self._sp_mark(iid), state,
                                          i18n.t('SET_SPLASH_F_SYS', '관리자'),
                                          name or '(제목 없음)',
                                          self._sp_where(_sc, _scn, _cnt)))
                if show_user:
                    for img_id, name, act, _scn in c.execute(
                            "SELECT img_id, COALESCE(name,''), is_active,"
                            " COALESCE(scene,'') FROM user_splash_image"
                            " ORDER BY img_id DESC"):
                        iid = 'U%d' % img_id; live.add(iid)
                        state = 'ON' if act else 'OFF'
                        if not _keep('' if act else 'off', False):
                            live.discard(iid)
                            continue
                        tv.insert('', 'end', iid=iid, tags=() if act else ('off',),
                                  values=(self._sp_mark(iid), state,
                                          i18n.t('SET_SPLASH_F_USER', '사용자'),
                                          name or '(제목 없음)',
                                          self._sp_where(_sc, _scn, '')))
        except Exception:
            pass
        self._sp_checked &= live
        # 탭 열면 첫 사진 자동 선택 → 오른쪽에 바로 미리보기(빈 칸 방지)
        kids = tv.get_children()
        if kids and not tv.selection():
            tv.selection_set(kids[0])

    def _splash_add(self):
        from tkinter import filedialog, messagebox, simpledialog
        try:
            import splash_prep
        except Exception:
            messagebox.showwarning(i18n.t('SET_SPLASH_NEEDPIL_T', 'Pillow 필요'),
                                   i18n.t('SET_SPLASH_NEEDPIL', '사진 변환에는 Pillow(PIL)가 필요합니다.'))
            return
        path = filedialog.askopenfilename(
            title=i18n.t('SET_SPLASH_PICK', '시작화면 사진 선택'),
            filetypes=[(i18n.t('SET_SPLASH_IMG', '이미지'), '*.jpg *.jpeg *.png *.bmp *.gif *.webp'),
                       (i18n.t('COMMON_ALL', '전체'), '*.*')])
        if not path:
            return
        # ★★ **제목과 장면을 한 창에서 받는다** (2026-09-05 사용자 지시
        #   「사용자의 시작화면 탭이 좁다. 사진 첨부할 때 **장면선택을
        #    편리하게**」) — 좁은 탭에 칸을 늘리지 않고 넣는 순간에 묻는다.
        #   ⚠ 창이 안 뜨면 **옛 길로 물러선다**(제목만) — 조용히 못 넣게
        #     되는 것이 더 나쁘다.
        name, scene, desc = '', None, ''
        try:
            import scene_pick
            r = scene_pick.ask(self, '')
            if r is None:
                return                      # 취소 — 아무것도 안 넣는다
            name, scene, desc = r
        except Exception:
            name = simpledialog.askstring(
                i18n.t('SET_SPLASH_NAME', '사진 제목'),
                i18n.t('SET_SPLASH_NAME_Q', '사진 제목을 입력하세요 (선택):'),
                parent=self)
        try:
            png, ow, oh = splash_prep.to_png_bytes(path, 960, 600)
            with appdb.connect(self.db) as c:
                try:
                    import db_splash_scene as _sc
                    _sc.init(c)             # scene 칸이 없으면 만든다
                except Exception:
                    pass
                cur = c.execute(
                    "INSERT INTO user_splash_image(png_blob,name,width,height,label,scene,is_active,created_at) "
                    "VALUES(?,?,?,?,?,?,1,datetime('now'))",
                    (png, (name or '').strip(), 960, 600, '', scene))
                # ★ 설명도 함께 담는다(2026-09-05) — 넣는 자리에서 다 받는다.
                try:
                    self._save_my_desc(c, cur.lastrowid, desc)
                except Exception:
                    pass
                c.commit()
        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'),
                                 i18n.t('SET_SPLASH_FAIL', '사진 추가 실패') + f':\n{e}')
            return
        self._splash_reload()

    def _splash_delete_checked(self):
        from tkinter import messagebox
        ids = [int(i[1:]) for i in self._sp_checked if i.startswith('U') and self._splash_tree.exists(i)]
        if not ids:
            messagebox.showinfo(i18n.t('COMMON_DELETE', '삭제'),
                                i18n.t('SET_SPLASH_DEL_HINT', "삭제할 '내 사진'을 체크하세요. (관리자 사진은 삭제 대신 숨기기)"))
            return
        if not messagebox.askyesno(i18n.t('COMMON_DELETE', '삭제'),
                                   i18n.t('SET_SPLASH_DEL_Q2', '체크한 내 사진 {n}장을 삭제할까요?').format(n=len(ids))):
            return
        try:
            with appdb.connect(self.db) as c:
                c.executemany("DELETE FROM user_splash_image WHERE img_id=?", [(i,) for i in ids])
                c.commit()
        except Exception:
            pass
        self._sp_checked = {i for i in self._sp_checked if not i.startswith('U')}
        self._splash_reload()

    def _splash_turn(self, on):
        """체크한 사진을 **켜거나 끈다** — 토글이 아니라 명시적 두 단추.

        ★ 사용자 지시(2026-09-05) 「Turn ON, Turn OFF (**관리자 사진을 숨기기
          하는 것도 OFF**)」. 토글은 누르기 전에 무엇이 될지 알 수 없다.
        ⚠ **관리자가 끈 사진은 켤 수 없다** — 몇 장이 그래서 안 됐는지 말한다.
        """
        from tkinter import messagebox
        tv = self._splash_tree
        sys_ids = [int(i[1:]) for i in self._sp_checked
                   if i.startswith('S') and tv.exists(i)]
        usr_ids = [int(i[1:]) for i in self._sp_checked
                   if i.startswith('U') and tv.exists(i)]
        if not sys_ids and not usr_ids:
            messagebox.showinfo(
                i18n.t('SET_SPLASH_TURNON' if on else 'SET_SPLASH_TURNOFF',
                       'Turn ON' if on else 'Turn OFF'),
                i18n.t('SET_SPLASH_ONOFF_HINT',
                       '켜거나 끌 사진을 ☑ 체크한 뒤 누르세요.'))
            return
        blocked = 0
        try:
            with appdb.connect(self.db) as c:
                admin_off = {r[0] for r in c.execute(
                    "SELECT img_id FROM sys_splash_image WHERE is_active=0")}
                for i in sys_ids:
                    if on:
                        if i in admin_off:
                            blocked += 1
                            continue
                        c.execute("DELETE FROM user_splash_hidden"
                                  " WHERE sys_img_id=?", (i,))
                    else:
                        # ⚠ 관리자 사진을 끄는 것 = **내 화면에서 가리기**
                        c.execute("INSERT OR IGNORE INTO user_splash_hidden"
                                  "(sys_img_id,hidden_at)"
                                  " VALUES(?,datetime('now'))", (i,))
                for i in usr_ids:
                    c.execute("UPDATE user_splash_image SET is_active=?"
                              " WHERE img_id=?", (1 if on else 0, i))
                c.commit()
        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), str(e))
            return
        self._splash_reload()
        if blocked:
            messagebox.showinfo(
                i18n.t('SET_SPLASH_TURNON', 'Turn ON'),
                i18n.t('SET_SPLASH_BLOCKED',
                       '%d장은 관리자가 꺼 둔 사진이라 켤 수 없습니다.')
                % blocked)

    def _splash_edit_mine(self, _e=None):
        """더블클릭 — **내가 올린 사진의 제목·설명·장면을 고친다**.

        ★ 사용자 지시(2026-09-05) — 「사용자가 추가할 때 팝업으로 처리한 이후
          **올린 사진에 대해 수정할 화면 자체가 없다**」.
        ⚠ **관리자 사진은 못 고친다** — 배포된 자산이다. 그 사실을 말한다.
        """
        from tkinter import messagebox
        tv = self._splash_tree
        sel = tv.selection()
        if not sel:
            return
        iid = sel[0]
        if not iid.startswith('U'):
            messagebox.showinfo(
                i18n.t('SET_SPLASH_EDIT', '사진 정보 수정하기'),
                i18n.t('SET_SPLASH_EDIT_SYS',
                       '관리자가 보낸 사진은 고칠 수 없습니다.'
                       ' 내가 넣은 사진만 고칠 수 있습니다.'))
            return
        img_id = int(iid[1:])
        try:
            import scene_pick
            with appdb.connect(self.db) as c:
                r = c.execute("SELECT COALESCE(name,''), COALESCE(scene,'')"
                              " FROM user_splash_image WHERE img_id=?",
                              (img_id,)).fetchone()
            got = scene_pick.ask(self.winfo_toplevel(),
                                 name=(r[0] if r else ''),
                                 scene=(r[1] if r else ''),
                                 desc=self._my_photo_desc(img_id))
            if got is None:
                return
            name, scene, desc = got
            with appdb.connect(self.db) as c:
                c.execute("UPDATE user_splash_image SET name=?, scene=?"
                          " WHERE img_id=?", (name, scene or None, img_id))
                self._save_my_desc(c, img_id, desc)
                c.commit()
        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), str(e))
            return
        self._splash_reload()

    def _my_photo_desc(self, img_id):
        """내 사진의 설명 — `user_text_asset('SPLASH_DESC')`."""
        try:
            with appdb.connect(self.db) as c:
                r = c.execute(
                    "SELECT contents FROM user_text_asset"
                    " WHERE text_type='SPLASH_DESC' AND clicked_id=?"
                    " AND COALESCE(record_status,'NEW')<>'HIDE' LIMIT 1",
                    (int(img_id),)).fetchone()
            return (r[0] if r else '') or ''
        except Exception:
            return ''

    def _save_my_desc(self, c, img_id, desc):
        """설명 저장 — **비면 행을 지운다**(빈 껍데기를 남기지 않는다).

        ⚠ 내 사진 설명은 **`user_text_asset`** 이다(관리자 것은 `sys_`).
          한 표에 섞으면 배포 DB 에 사용자 글이 들어간다(§0-6 C-2).
        """
        desc = (desc or '').strip()
        c.execute("DELETE FROM user_text_asset WHERE text_type='SPLASH_DESC'"
                  " AND clicked_id=?", (int(img_id),))
        if desc:
            c.execute(
                "INSERT INTO user_text_asset"
                "(clicked_id,text_type,lang_code,contents,record_status)"
                " VALUES(?,?,?,?,'NEW')",
                (int(img_id), 'SPLASH_DESC', (i18n.get_lang() or 'KO'), desc))

    def _splash_toggle_onoff(self):
        """체크한 사진의 시작화면 표시 상태(켜짐↔꺼짐) 전환.
        · 관리자 사진(S): user_splash_hidden 토글(가리기↔복원). 단 관리자가 끈 사진은 켤 수 없음.
        · 내 사진(U): is_active 토글."""
        from tkinter import messagebox
        sys_ids = [int(i[1:]) for i in self._sp_checked if i.startswith('S') and self._splash_tree.exists(i)]
        usr_ids = [int(i[1:]) for i in self._sp_checked if i.startswith('U') and self._splash_tree.exists(i)]
        if not sys_ids and not usr_ids:
            messagebox.showinfo(i18n.t('SET_SPLASH_ONOFF', '켜기/끄기'),
                                i18n.t('SET_SPLASH_ONOFF_HINT', '켜거나 끌 사진을 ☑ 체크한 뒤 누르세요.'))
            return
        blocked = 0
        try:
            with appdb.connect(self.db) as c:
                hidden = {r[0] for r in c.execute("SELECT sys_img_id FROM user_splash_hidden")}
                admin_off = {r[0] for r in c.execute("SELECT img_id FROM sys_splash_image WHERE is_active=0")}
                for i in sys_ids:
                    if i in admin_off:
                        blocked += 1; continue   # 관리자가 끈 사진 — 사용자가 켤 수 없음
                    if i in hidden:
                        c.execute("DELETE FROM user_splash_hidden WHERE sys_img_id=?", (i,))   # 다시 켬
                    else:
                        c.execute("INSERT OR IGNORE INTO user_splash_hidden(sys_img_id,hidden_at) "
                                  "VALUES(?,datetime('now'))", (i,))                            # 끔(가림)
                for i in usr_ids:
                    c.execute("UPDATE user_splash_image SET is_active=CASE WHEN is_active=1 THEN 0 ELSE 1 END "
                              "WHERE img_id=?", (i,))
                c.commit()
        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), str(e)); return
        self._splash_reload()
        if blocked:
            messagebox.showinfo(i18n.t('SET_SPLASH_ONOFF', '켜기/끄기'),
                                i18n.t('SET_SPLASH_ADMIN_OFF', '관리자가 끈 사진 {n}장은 켤 수 없습니다.').format(n=blocked))

    # ── 개인정보(익명 이용통계) ──
    def _build_privacy(self, nb):
        """개인정보수집 — **두 묶음**(2026-09-06 사용자 0.txt 8-4).

        ★ 사용자 지시 — 「글자 : **표준 서식**을 따르라 / 배치1 : **동의 설명문
          + 동의 버튼** / 배치2 : **동의취소 설명문 + 동의 취소 사유 + 버튼**
          (**취소사유 박스가 작음**) / 약관 자세히 보기」.
        ⚠ 예전에는 동의와 취소가 뒤섞여 있었다 — 유도 문구 → 상태 → 중단 경고
          → 취소 사유 → [동의][취소]. **취소 사유가 [동의] 위에** 있어 무엇에
          딸린 칸인지 알 수 없었다. 이제 상자 둘로 갈라 각 묶음이 제 단추를 안는다.
        ⚠ 글꼴은 `theme_font.register` 로 등록한다 — `font=('', 10, 'bold')`
          처럼 크기를 박으면 설정에서 글자를 키워도 이 탭만 안 따라온다(§36).
        """
        import queue
        self._wq = queue.Queue()
        f = tk.Frame(nb, bg=_C('bg', '#FAFAFA')); nb.add(f, text=' ' + i18n.t('SET_TAB_PRIVACY', '개인정보수집') + ' ')

        def _reg(w, scope='ui', delta=0, weight=None):
            """표준 서식 — 크기를 박지 않는다(§36)."""
            try:
                import theme_font
                theme_font.register(w, self.db_path, scope, size_delta=delta)
            except Exception:
                pass
            if weight:
                try:
                    fo = tkfont.Font(font=w.cget('font'))
                    fo.configure(weight=weight)
                    w.configure(font=fo)
                except Exception:
                    pass
            return w

        # 현재 상태 — 어느 묶음에도 안 딸린 「지금 어떤가」
        self._consent_status = tk.Label(f, bg=_C('bg', '#FAFAFA'), anchor='w')
        _reg(self._consent_status, delta=1, weight='bold')
        self._consent_status.pack(fill='x', padx=16, pady=(14, 8))
        self._refresh_consent_status()

        # ── 묶음 ① 동의 ──────────────────────────────────────────
        b1 = tk.LabelFrame(f, bg=_C('bg', '#FAFAFA'), fg=_C('fg_title', '#1A5276'),
                           text=' ' + i18n.t('SET_PRIV_G_AGREE', '동의') + ' ')
        _reg(b1)
        b1.pack(fill='x', padx=16, pady=(0, 10))
        l1 = tk.Label(b1, bg=_C('bg', '#FAFAFA'), fg=_C('fg', '#333'),
                      justify='left', wraplength=560, anchor='w',
                      text=i18n.t('SET_PRIV_PROMOTE',
                                  '익명 이용통계에 동의해 주시면 앱 성능을 고도화하는 데 큰 도움이 됩니다. '))
        _reg(l1)
        l1.pack(fill='x', padx=10, pady=(6, 2))
        l2 = tk.Label(b1, bg=_C('bg', '#FAFAFA'), fg=_C('fg_dim', '#888'),
                      justify='left', wraplength=560, anchor='w',
                      text='※ ' + i18n.t('SET_PRIV_NOTE',
                                        '이용통계에는 개인정보·노트 내용·검색어·IP·국가를 넣지 않습니다. '
                                        '사용 횟수와 받아 둔 자료의 이름표·판 번호만 익명으로 보냅니다. '
                                        '동의 안 해도 모든 기능 사용 가능. 공동체 방을 여실 때 적는 '
                                        '이름·연락처는 방 등록 신고로 관리자에게 한 번 전해집니다'
                                        '(방을 연 사람만).'))
        _reg(l2, delta=-1)
        l2.pack(fill='x', padx=10, pady=(0, 6))
        ba = tk.Button(b1, text=i18n.t('SET_PRIV_BTN_AGREE', '동의'),
                       bg=_C('success', '#1E8449'), fg=_C('fg_on_dark', 'white'),
                       padx=22, pady=4, command=self._do_consent)
        _reg(ba, delta=1, weight='bold')
        ba.pack(anchor='w', padx=10, pady=(0, 10))

        # ── 묶음 ② 동의 취소 ─────────────────────────────────────
        b2 = tk.LabelFrame(f, bg=_C('bg', '#FAFAFA'), fg=_C('fg_title', '#1A5276'),
                           text=' ' + i18n.t('SET_PRIV_G_WD', '동의 취소') + ' ')
        _reg(b2)
        b2.pack(fill='both', expand=True, padx=16, pady=(0, 10))
        l3 = tk.Label(b2, bg=_C('bg', '#FAFAFA'), fg=_C('danger', '#C0392B'),
                      justify='left', wraplength=560, anchor='w',
                      text=i18n.t('SET_PRIV_STOPNOTE',
                                  '동의를 취소하면 즉시 정보 수집이 중단됩니다 (관리자 승인 불필요).'))
        _reg(l3, weight='bold')
        l3.pack(fill='x', padx=10, pady=(6, 4))
        l4 = tk.Label(b2, bg=_C('bg', '#FAFAFA'), fg=_C('fg', '#333'), anchor='w',
                      text=i18n.t('SET_PRIV_REASON', '취소 사유(선택)') + ':')
        _reg(l4)
        l4.pack(anchor='w', padx=10)
        # ⚠ **한 줄 Entry 32칸이 너무 작았다**(사용자 지적) — 여러 줄 상자로
        self._reason_txt = tk.Text(b2, height=4, wrap='word')
        _reg(self._reason_txt, scope='prose')
        self._reason_txt.pack(fill='x', padx=10, pady=(2, 6))
        bw = tk.Button(b2, text=i18n.t('SET_PRIV_BTN_WD', '동의 취소'),
                       bg=_C('border', '#D5D8DC'), fg=_C('fg', '#333'),
                       padx=16, pady=4, command=self._do_withdraw)
        _reg(bw, delta=1)
        bw.pack(anchor='w', padx=10, pady=(0, 8))
        self._withdraw_result = tk.Label(b2, bg=_C('bg', '#FAFAFA'),
                                         fg=_C('success', '#1E8449'),
                                         justify='left', wraplength=560, anchor='w')
        _reg(self._withdraw_result, delta=-1)
        self._withdraw_result.pack(fill='x', padx=10, pady=(0, 8))

        # ── 묶음 ③ 지금 보내는 것 ────────────────────────────────
        # ★★ **약관이 약속한 것을 화면이 실제로 보인다** (2026-09-06).
        #   약관에 「UUID는 [설정 › 개인정보]에서 확인 가능」이라 적어 두고
        #   **이 화면에 UUID 가 없었다** — 없는 것을 있다고 적은 자리다.
        # ⚠ **동의 안 해도 보인다** — 제 식별자를 확인하는 것은 권리이고,
        #   「지금 보내는가」는 맨 위 상태 줄이 이미 말한다.
        # ⚠ 목록은 `usage_stats.summary_lines` 가 **실제 payload 에서** 짓는다
        #   (여기서 손으로 적으면 항목을 늘린 날 화면만 옛말을 한다).
        b3 = tk.LabelFrame(f, bg=_C('bg', '#FAFAFA'), fg=_C('fg_title', '#1A5276'),
                           text=' ' + i18n.t('SET_PRIV_G_SEND', '지금 보내는 것') + ' ')
        _reg(b3)
        b3.pack(fill='x', padx=16, pady=(0, 10))
        self._priv_send = tk.Frame(b3, bg=_C('bg', '#FAFAFA'))
        self._priv_send.pack(fill='x', padx=10, pady=(6, 8))
        self._reg_priv = _reg
        self._refresh_send_list()

        bm = tk.Button(f, text=i18n.t('SET_PRIV_MORE', '약관 자세히 보기'),
                       command=self._show_consent_full)
        _reg(bm)
        bm.pack(anchor='w', padx=16, pady=(0, 12))

    def _refresh_send_list(self):
        """[설정 ▸ 개인정보] 「지금 보내는 것」 다시 그리기."""
        box = getattr(self, '_priv_send', None)
        if box is None:
            return
        try:
            if not box.winfo_exists():
                return
        except Exception:
            return
        for w in list(box.winfo_children()):
            w.destroy()
        import usage_stats
        # ⚠ 환경값을 여기서 짐작하지 않는다 — 앱이 알려 준 값
        #   (`usage_stats.remember_env`)을 그대로 읽는다.
        try:
            rows = usage_stats.summary_lines()
        except Exception:
            rows = []
        # ⚠ **이름이 거짓이 되지 않게 한다** — 동의 안 하면 아무것도 안 보내는데
        #   묶음 이름은 「지금 보내는 것」이다. 그 상태를 첫 줄이 말한다(§0-1).
        try:
            on = usage_stats.has_consent()
        except Exception:
            on = True
        if not on:
            wl = tk.Label(box, bg=_C('bg', '#FAFAFA'), fg=_C('fg_dim', '#888'),
                          anchor='w', justify='left', wraplength=560,
                          text=i18n.t('SET_PRIV_SEND_OFF',
                                      '지금은 동의하지 않아 아무것도 보내지 않습니다. '
                                      '아래는 동의하면 보낼 내용입니다.'))
            self._reg_priv(wl, delta=-1)
            wl.pack(fill='x', pady=(0, 6))
        if not rows:
            # ⚠ 빈 칸을 두지 않는다 — 왜 없는지 말한다(§0-1)
            lb = tk.Label(box, bg=_C('bg', '#FAFAFA'), fg=_C('fg_dim', '#888'),
                          anchor='w', justify='left', wraplength=560,
                          text=i18n.t('SET_PRIV_SEND_NONE',
                                      '아직 보낼 집계가 없습니다.'))
            self._reg_priv(lb, delta=-1)
            lb.pack(fill='x')
            return
        for i, (k, v) in enumerate(rows):
            r = tk.Frame(box, bg=_C('bg', '#FAFAFA'))
            r.pack(fill='x')
            a = tk.Label(r, bg=_C('bg', '#FAFAFA'), fg=_C('fg_dim', '#888'),
                         anchor='w', width=16, text=k)
            self._reg_priv(a, delta=-1)
            a.pack(side='left')
            b = tk.Label(r, bg=_C('bg', '#FAFAFA'), fg=_C('fg', '#333'),
                         anchor='w', justify='left', text=v)
            self._reg_priv(b, delta=-1)
            b.pack(side='left', fill='x', expand=True)

    def _refresh_consent_status(self):
        import usage_stats
        dt = usage_stats.consent_date()
        if dt is None:
            self._consent_status.config(
                text='● ' + i18n.t('SET_PRIV_OFF', '동의 안 함 (정보 수집 중단됨)'), fg=_C('fg_dim', '#888'))
        else:
            self._consent_status.config(
                text='' + i18n.t('SET_PRIV_ON_DATE', '동의함 — 동의한 날짜') + f': {dt}', fg=_C('success', '#1E8449'))

    def _do_consent(self):
        import usage_stats
        usage_stats.set_consent(True)
        self._refresh_consent_status()
        self._refresh_send_list()
        self._withdraw_result.config(
            text=i18n.t('SET_PRIV_AGREED', '동의되었습니다. 익명 이용통계 수집이 시작됩니다. 감사합니다!'),
            fg=_C('success', '#1E8449'))

    def _do_withdraw(self):
        import usage_stats, threading
        if usage_stats.has_consent() is not True:
            self._withdraw_result.config(
                text=i18n.t('SET_PRIV_NOT_ON', '현재 동의 상태가 아닙니다.'), fg=_C('fg_dim', '#888'))
            return
        reason = self._reason_txt.get('1.0', 'end').strip()
        usage_stats.set_consent(False)              # 즉시 수집 중단
        self._refresh_consent_status()
        self._refresh_send_list()
        self._wd_base = i18n.t('SET_PRIV_WD_DONE', '동의를 취소했습니다. 정보 수집이 즉시 중단되었습니다.') + '\n'
        self._withdraw_result.config(
            text=self._wd_base + i18n.t('SET_PRIV_WD_SENDING', '취소 처리 중…'), fg=_C('danger', '#C0392B'))
        av = getattr(self.master, '_app_ver', '1.0')
        lang = i18n.get_lang()

        def _w():
            self._wq.put(usage_stats.send_withdraw(reason, lang, av))
        threading.Thread(target=_w, daemon=True).start()
        self.after(150, self._poll_withdraw)

    def _poll_withdraw(self):
        import queue
        try:
            ok = self._wq.get_nowait()
        except queue.Empty:
            self.after(150, self._poll_withdraw); return
        base = getattr(self, '_wd_base', '')
        if ok:
            self._withdraw_result.config(
                text=base + i18n.t('SET_PRIV_WD_OK', '취소 처리 완료(통계 반영).'), fg=_C('success', '#1E8449'))
        else:
            self._withdraw_result.config(
                text=base + i18n.t('SET_PRIV_WD_FAIL', '통계 전송 실패(네트워크) — 수집은 이미 중단됨.'), fg=_C('danger', '#C0392B'))

    def _show_consent_full(self):
        import consent_text
        consent_text.show_full_notice(self, i18n.get_lang())

    # ── 언어 ──
    def _build_lang(self, nb):
        f = tk.Frame(nb, bg=_C('bg', '#FAFAFA')); nb.add(f, text=' ' + i18n.t('SET_TAB_LANG', '언어') + ' ')
        self._tab_savebar(f, self._save_lang)
        tk.Label(f, text=i18n.t('SET_UILANG', 'UI 언어') + ':', bg=_C('bg', '#FAFAFA'),
                 font=('', 10)).pack(anchor='w', padx=16, pady=(18, 4))
        self._lang_codes = lang_config.ui_langs()
        # ⚠⚠ **내부 코드를 그대로 보인다** (2026-08-30 사용자 신고 「언어코드를
        #   KO 라고 하지 않고 ko 라고 소문자 표시하고 있다」).
        #   그전에는 국제 표준(BCP-47) 표기를 썼는데 그것은 소문자다(`ko`·`zh-Hant`).
        #   앱이 쓰는 코드는 `KO`·`ZHT` 이고, 화면에 둘이 섞이면 같은 언어가 두
        #   이름으로 보인다. ⇒ **앱의 코드 하나로 통일한다.**
        labels = [f'{lang_config.lang_name(c)} ({c})' for c in self._lang_codes]
        self._lang_cb = ttk.Combobox(f, state='readonly', values=labels, width=28)
        cur = _cfg_get(self.db, 'user_lang', 'KO')
        if cur in self._lang_codes:
            self._lang_cb.current(self._lang_codes.index(cur))
        self._lang_cb.pack(anchor='w', padx=16)
        tk.Label(f, text='※ ' + i18n.t('SET_RESTART_NOTE', '언어 변경은 재시작 후 적용됩니다.'),
                 bg=_C('bg', '#FAFAFA'), fg=_C('fg_dim', '#888'), font=('', 8)).pack(anchor='w', padx=16, pady=(6, 0))

        # ── 국가/지역 (광고·제휴·추천 지역맞춤 — 기기에만 저장, 위치정보 미수집) ──
        tk.Label(f, text=i18n.t('SET_COUNTRY', '국가/지역') + ':', bg=_C('bg', '#FAFAFA'),
                 font=('', 10)).pack(anchor='w', padx=16, pady=(16, 4))
        self._country_codes = [c for c, _ in ads.COUNTRIES]
        self._country_cb = ttk.Combobox(f, state='readonly',
                                        values=[n for _, n in ads.COUNTRIES], width=28)
        _cur_cc = ads.get_country(self.db)
        if _cur_cc in self._country_codes:
            self._country_cb.current(self._country_codes.index(_cur_cc))
        self._country_cb.pack(anchor='w', padx=16)
        tk.Label(f, text='※ ' + i18n.t('SET_COUNTRY_NOTE',
                 '추천·후원 콘텐츠를 지역에 맞추는 데만 사용합니다 (기기에만 저장, IP·위치정보 수집 안 함).'),
                 bg=_C('bg', '#FAFAFA'), fg=_C('fg_dim', '#888'), font=('', 8), wraplength=520, justify='left'
                 ).pack(anchor='w', padx=16, pady=(6, 0))

    # ── 성경 버전 ──────────────────────────────────────────────────
    #  갈래 둘 — [역본 고르기] · [반쪽 역본의 짝]
    #  ⚠ 짝은 **예외 상황**이다. 반쪽 역본(구약만·신약만)을 실제로 켠 사람만
    #    쓰는 자리이므로 늘 화면을 먹지 않는다(2026-09-23 사용자 지시).
    def _build_version(self, nb):
        outer = tk.Frame(nb, bg=_C('bg', '#FAFAFA'))
        nb.add(outer, text=' ' + i18n.t('SET_TAB_VERSION', '성경 버전') + ' ')
        self._tab_savebar(outer, self._save_version)

        self._vbar = tk.Frame(outer, bg=_C('bg', '#FAFAFA'))
        self._vbar.pack(fill='x', padx=16, pady=(6, 0))
        self._vbody = tk.Frame(outer, bg=_C('bg', '#FAFAFA'))
        self._vbody.pack(fill='both', expand=True)

        f = tk.Frame(self._vbody, bg=_C('bg', '#FAFAFA'))
        self._vpage = {'LIST': f, 'PAIR': None}
        self._vkey = 'LIST'
        f.pack(fill='both', expand=True)

        # ── 기본 버전 한 줄 ──
        top = tk.Frame(f, bg=_C('bg', '#FAFAFA'))
        top.pack(fill='x', padx=16, pady=(10, 4))
        tk.Label(top, text=i18n.t('SET_DEFAULT_VER', '기본 버전') + ':',
                 bg=_C('bg', '#FAFAFA'), font=('', 10)).pack(side='left')
        self._dv_labels = [f'{nm} ({code})' for code, nm, _lc, _vs in self._vers]
        self._dv_codes = [code for code, _nm, _lc, _vs in self._vers]
        self._dv_cb = ttk.Combobox(top, state='readonly',
                                   values=self._dv_labels, width=30)
        dv = _cfg_get(self.db, 'v1_code', 'KRV')
        if dv in self._dv_codes:
            self._dv_cb.current(self._dv_codes.index(dv))
        self._dv_cb.pack(side='left', padx=6)

        # ★★ **읽기 대상과 비교 대상을 갈랐다** (2026-08-23 사용자 「P1 성경읽기
        #   상단 bar 에서 성경버전을 선택할 수 있는데 **모든 성경이 표시됨** …
        #   목록 헤더에 "비교대상", "성경읽기 대상"으로 구분하여 따로 체크 가능」).
        #   `PREFERRED_VERSIONS` = 비교 · `READING_VERSIONS` = 읽기.
        tk.Label(f, text=i18n.t('SET_VER_HDR2',
                                '역본을 두 가지로 선택합니다 — 읽기 목록은 P1 버전 단추, '
                                '비교 목록은 역본비교 화면에 나옵니다.'),
                 bg=_C('bg', '#FAFAFA'), fg=_C('fg_dim', '#555'),
                 font=('', 9, 'bold'), anchor='w', justify='left'
                 ).pack(anchor='w', padx=16, pady=(4, 2))

        # ── 좌우 두 칸 — 왼쪽 목록 · 오른쪽 설명 ──
        # ⚠ 위아래로 두면 설명 패널(8줄)이 목록을 밀어 **체크 칸이 눌린다**.
        pw = tk.PanedWindow(f, orient='horizontal', sashwidth=6,
                            bg=_C('bg', '#FAFAFA'), bd=0)
        pw.pack(fill='both', expand=True, padx=16, pady=(0, 12))

        wrap = tk.Frame(pw, bg=_C('bg', '#FAFAFA'))
        pw.add(wrap, minsize=360, stretch='always')
        cv = tk.Canvas(wrap, bg=_C('panel', '#FFFFFF'), highlightthickness=1,
                       highlightbackground='#DDD')
        sb = ttk.Scrollbar(wrap, orient='vertical', command=cv.yview)
        inner = tk.Frame(cv, bg=_C('panel', '#FFFFFF'))
        inner.bind('<Configure>',
                   lambda e: cv.configure(scrollregion=cv.bbox('all')))
        cv.create_window((0, 0), window=inner, anchor='nw')
        cv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        cv.pack(side='left', fill='both', expand=True)

        pref = set(self._load_codes('PREFERRED_VERSIONS'))
        # ★ 읽기 목록이 아직 없으면(옛 설정) **비교 목록을 그대로 물려받는다**.
        read = set(self._load_codes('READING_VERSIONS')) or set(pref)
        self._pref_vars = {}
        self._read_vars = {}
        mt = [v for v in self._vers if (v[3] or 'MT') == 'MT']
        nonmt = [v for v in self._vers if (v[3] or 'MT') != 'MT']
        _rc = [0]

        _hf = tk.Frame(inner, bg=_C('panel_alt', '#F4F6F7'))
        _hf.grid(row=_rc[0], column=0, columnspan=3, sticky='ew'); _rc[0] += 1
        tk.Label(_hf, text='', bg=_C('panel_alt', '#F4F6F7'),
                 width=34).pack(side='left', padx=2)
        tk.Label(_hf, text=i18n.t('SET_VER_COL_READ', '성경읽기 대상'),
                 bg=_C('panel_alt', '#F4F6F7'), fg=_C('fg', '#2C3E50'),
                 font=('', 8, 'bold')).pack(side='left', padx=(0, 6))
        tk.Label(_hf, text=i18n.t('SET_VER_COL_CMP', '비교대상'),
                 bg=_C('panel_alt', '#F4F6F7'), fg=_C('fg', '#2C3E50'),
                 font=('', 8, 'bold')).pack(side='left')

        def _grp_header(title, sub=''):
            hr = tk.Frame(inner, bg=_C('accent_bg', '#D6EAF8'))
            hr.grid(row=_rc[0], column=0, columnspan=3, sticky='ew')
            _rc[0] += 1
            tk.Label(hr, text=title, bg=_C('accent_bg', '#D6EAF8'), anchor='w',
                     fg=_C('accent', '#1A5276'),
                     font=('', 9, 'bold')).pack(side='left', padx=4, pady=1)
            if sub:
                tk.Label(hr, text=sub, bg=_C('accent_bg', '#D6EAF8'),
                         fg=_C('danger', '#922B21'),
                         font=('', 8)).pack(side='left', padx=6)

        def _ver_rows(lst):
            scope = getattr(self, '_ver_scope', {}) or {}
            for code, nm, lc, _vs in lst:
                ct = (getattr(self, '_ver_lic', {}).get(code) or ('', ''))[0]
                mark, _role = _LIC_MARK.get(ct, ('', ('accent', '#1A5276')))
                sc = scope.get(code, ('FULL', ''))[0]
                # ★ 반쪽 역본임을 **목록에서 바로** 알린다 — 그래야 짝 갈래가
                #   왜 생기는지 스스로 설명된다.
                half = ''
                if sc == 'OT_ONLY':
                    half = ' · ' + i18n.t('SET_PARTNER_OT', '구약만')
                elif sc == 'NT_ONLY':
                    half = ' · ' + i18n.t('SET_PARTNER_NT', '신약만')
                lbl = tk.Label(inner, text=f'{mark}{nm}  ({code}/{lc}){half}',
                               bg=_C('panel', '#FFFFFF'), anchor='w',
                               font=('', 9), width=34, fg=_C(*_role),
                               cursor='hand2')
                lbl.grid(row=_rc[0], column=0, sticky='w', padx=2)
                lbl.bind('<Button-1>', lambda e, cc=code: self._show_ver_desc(cc))
                rv = tk.IntVar(value=1 if code in read else 0)
                self._read_vars[code] = rv
                tk.Checkbutton(inner, variable=rv, bg=_C('panel', '#FFFFFF'),
                               command=self._build_vbar
                               ).grid(row=_rc[0], column=1)
                pv = tk.IntVar(value=1 if code in pref else 0)
                self._pref_vars[code] = pv
                tk.Checkbutton(inner, variable=pv, bg=_C('panel', '#FFFFFF'),
                               command=self._build_vbar
                               ).grid(row=_rc[0], column=2)
                _rc[0] += 1

        _grp_header(i18n.t('SET_VER_GRP_MT', 'MT 계열 (표준 장절 체계)'))
        _ver_rows(mt)
        if nonmt:
            _grp_header(i18n.t('SET_VER_GRP_NONMT', '비-MT 계열 (LXX·기타)'),
                        i18n.t('SET_VER_GRP_NONMT_NOTE',
                               '※ 시편 등 절번호 체계가 달라 매핑 주의'))
            _ver_rows(nonmt)

        # 오른쪽 — 버전 설명
        dfrm = tk.LabelFrame(pw, text=i18n.t('SET_VER_DESC', '버전 설명 (이름을 클릭)'),
                             bg=_C('bg', '#FAFAFA'), font=('', 8, 'bold'))
        pw.add(dfrm, minsize=260, stretch='always')
        self._ver_desc = ScrolledText(dfrm, height=8, wrap='word', font=('', 9),
                                      bg=_C('panel', 'white'), fg=_C('fg', '#222'),
                                      relief='flat', padx=6, pady=4)
        self._ver_desc.pack(fill='both', expand=True, padx=4, pady=4)
        self._dv_cb.bind('<<ComboboxSelected>>', lambda e: self._show_ver_desc(
            self._dv_codes[self._dv_cb.current()]
            if self._dv_cb.current() >= 0 else None))
        if self._dv_cb.current() >= 0:
            self._show_ver_desc(self._dv_codes[self._dv_cb.current()])

        self._build_vbar()

    # ── 갈래 단추 ──────────────────────────────────────────────────
    def half_versions(self):
        """**켠 반쪽 역본** — 짝을 정할 자리가 있는 역본만.

        ★ 읽기·비교 어느 쪽이든 체크했으면 그 역본으로 반대쪽에 갈 수 있다.
        ⚠ 체크를 하나도 안 했으면 **빈 목록** — 그러면 갈래 단추도 안 그린다.
        """
        scope = getattr(self, '_ver_scope', {}) or {}
        on = set()
        for d in (getattr(self, '_read_vars', {}), getattr(self, '_pref_vars', {})):
            for code, var in d.items():
                try:
                    if var.get():
                        on.add(code)
                except Exception:                                 # noqa: BLE001
                    pass
        return [(c, n) for c, n, _lc, _vs in self._vers
                if c in on and scope.get(c, ('FULL', ''))[0] in
                ('OT_ONLY', 'NT_ONLY')]

    def _build_vbar(self):
        """갈래 단추를 다시 그린다 — 체크가 바뀔 때마다 불린다."""
        bar = getattr(self, '_vbar', None)
        if bar is None or not bar.winfo_exists():
            return
        for w in bar.winfo_children():
            w.destroy()
        halves = self.half_versions()
        pages = [('LIST', i18n.t('SET_VER_PG_LIST', '역본 선택하기'))]
        if halves:
            pages.append(('PAIR', '%s (%d)' % (
                i18n.t('SET_VER_PG_PAIR', '반쪽 역본의 짝'), len(halves))))
        elif self._vkey == 'PAIR':
            self._vshow('LIST')          # 마지막 반쪽을 껐다 — 되돌아온다
        for key, name in pages:
            on = (key == self._vkey)
            tk.Button(bar, text=name, font=('', 9, 'bold' if on else 'normal'),
                      bg=(_C('accent', '#1A5276') if on
                          else _C('panel_alt', '#F4F6F7')),
                      fg=(_C('fg_on_dark', '#FFFFFF') if on
                          else _C('fg', '#2C3E50')),
                      relief='flat', bd=0, padx=12, pady=4, cursor='hand2',
                      command=lambda k=key: self._vshow(k)).pack(side='left',
                                                                 padx=(0, 4))
        if self._vkey == 'PAIR':
            self._pair_rows(halves)

    def _vshow(self, key):
        """갈래를 바꾼다 — 몸통은 `pack_forget` 으로만 갈아 끼운다.

        ⚠ 부수고 다시 지으면 체크 상태를 잃는다(저장 전 값이 날아간다).
        """
        if key == 'PAIR' and self._vpage.get('PAIR') is None:
            self._build_partner(self._vbody)
        cur = self._vpage.get(self._vkey)
        if cur is not None and cur.winfo_exists():
            cur.pack_forget()
        self._vkey = key
        nxt = self._vpage.get(key)
        if nxt is not None and nxt.winfo_exists():
            nxt.pack(fill='both', expand=True)
        self._build_vbar()

    # ── 반쪽 역본의 짝 ────────────────────────────────────────────
    def _build_partner(self, parent):
        """구약만·신약만 있는 역본이 **나머지 절반에서 쓸 역본**을 선택한다.

        사용자 「히브리어 사용자는 구약버전을 선택하고 읽다가 **신약으로
        이동하려면 또 다른 버전을 선택**해야 한다 … **성경버전 탭 화면에서
        설정**하는 것도 좋다. 그런데 **선택하지 않은 사용자를 위한 기능**을
        고려해야 한다.」 · 「**콥틱 버전 선택하면 구약 짝을 다른 책으로 선택할
        수 있어야 한다**」.

        ★ 「선택하지 않은 사용자」의 답 = 맨 앞 **「기본」** 줄이다. 아무것도 안
          해도 역본이 스스로 아는 짝(`bible_version.partner_code`)이 쓰이고,
          그것도 없으면 여느 폴백(같은 언어 → 기준 역본)으로 간다.
        ★ **콥트어처럼 기본 짝이 없는 역본도 여기서 고를 수 있다** — 후보에
          반대쪽 절반을 담은 역본이 전부 올라온다.
        ⚠ **켠 반쪽 역본만 줄을 그린다** — 안 쓰는 역본의 짝을 묻지 않는다.
        """
        page = tk.Frame(parent, bg=_C('bg', '#FAFAFA'))
        self._vpage['PAIR'] = page
        tk.Label(page, text=i18n.t(
            'SET_PARTNER_NOTE',
            '구약만 또는 신약만 있는 역본입니다. 반대쪽으로 넘어가면 여기서 '
            '선택한 역본의 본문이 나옵니다. 선택하지 않으면 기본 짝을 씁니다.'),
            bg=_C('bg', '#FAFAFA'), fg=_C('fg_dim', '#777'), font=('', 9),
            anchor='w', justify='left', wraplength=760
        ).pack(anchor='w', padx=16, pady=(12, 8))
        self._pair_host = tk.Frame(page, bg=_C('bg', '#FAFAFA'))
        self._pair_host.pack(fill='both', expand=True, padx=16)
        return page

    def _pair_rows(self, halves):
        """켠 반쪽 역본마다 한 줄 — 이름 · 범위 · 짝 콤보."""
        host = getattr(self, '_pair_host', None)
        if host is None or not host.winfo_exists():
            return
        for w in host.winfo_children():
            w.destroy()
        if not hasattr(self, '_pt_sel'):
            try:
                self._pt_sel = json.loads(
                    _cfg_get(self.db, 'VERSION_PARTNER', '') or '{}')
            except Exception:                                     # noqa: BLE001
                self._pt_sel = {}
        scope = getattr(self, '_ver_scope', {}) or {}
        name_of = {c: n for c, n, _lc, _vs in self._vers}
        for code, nm in halves:
            sc, dflt = scope.get(code, ('FULL', ''))
            row = tk.Frame(host, bg=_C('bg', '#FAFAFA'))
            row.pack(fill='x', pady=3)
            tag = i18n.t('SET_PARTNER_OT', '구약만') if sc == 'OT_ONLY' \
                else i18n.t('SET_PARTNER_NT', '신약만')
            tk.Label(row, text='%s (%s) · %s' % (nm, code, tag),
                     bg=_C('bg', '#FAFAFA'), fg=_C('fg', '#2C3E50'),
                     font=('', 9), width=42, anchor='w').pack(side='left')
            # 후보 = 반대쪽 절반을 **실제로 담은** 역본
            want = 'NT_ONLY' if sc == 'OT_ONLY' else 'OT_ONLY'
            cands = [c for c, _n, _lc, _vs in self._vers
                     if c != code
                     and scope.get(c, ('FULL', ''))[0] in ('FULL', want)]
            head = (i18n.t('SET_PARTNER_DEFAULT', '기본') +
                    ((' (%s)' % dflt) if dflt else
                     ' (' + i18n.t('SET_PARTNER_AUTO', '자동') + ')'))
            vals = [head] + ['%s (%s)' % (name_of.get(c, c), c) for c in cands]
            cb = ttk.Combobox(row, state='readonly', values=vals, width=34)
            pick = self._pt_sel.get(code)
            cb.current(cands.index(pick) + 1 if pick in cands else 0)
            cb.pack(side='left', padx=6)

            def _on(_e=None, cc=code, w=cb, lst=cands):
                k = w.current()
                # ⚠ 「기본」이면 **저장값을 지운다** — 빈 글자를 넣으면
                #   「짝 없음」이 되어 뜻이 달라진다.
                if k > 0:
                    self._pt_sel[cc] = lst[k - 1]
                else:
                    self._pt_sel.pop(cc, None)
            cb.bind('<<ComboboxSelected>>', _on)

    def _show_ver_desc(self, code):
        if not code or not hasattr(self, '_ver_desc'):
            return
        lang = i18n.get_lang() or 'KO'
        with appdb.connect(self.db) as c:
            row = c.execute(
                "SELECT body_text FROM bible_version_text "
                "WHERE version_code=? AND lang_code IN (?,'EN','KO') "
                "  AND COALESCE(record_status,'LIVE')='LIVE' "
                "ORDER BY CASE lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                (code, lang, lang)).fetchone()
        self._ver_desc.config(state='normal')
        self._ver_desc.delete('1.0', 'end')
        lic = self._lic_line(code)
        if lic:
            self._ver_desc.insert('1.0', lic, 'lic')
        self._ver_desc.insert('end', row[0] if row and row[0] else i18n.t('COMMON_NODESC', '(설명 없음)'))
        self._ver_desc.tag_configure('lic', foreground=_C('fg_dim', '#5D6D7E'),
                                     font=('', 8))
        self._ver_desc.config(state='disabled')

    def _load_codes(self, key):
        raw = _cfg_get(self.db, key, None)
        if raw:
            try:
                v = json.loads(raw)
                if isinstance(v, list):
                    return v
            except Exception:
                pass
        return []

    def _lic_line(self, code):
        """역본 라이선스 한 줄 — 설명 패널 맨 위에 놓는다. 근거까지 보인다."""
        ct, note = (getattr(self, '_ver_lic', {}).get(code) or ('', ''))
        if not ct:
            return ''
        lbl = i18n.t('SET_LIC_' + ct, _LIC_KO.get(ct, ct))
        head = '%s %s' % (_LIC_MARK.get(ct, ('', ''))[0].strip() or '·', lbl)
        return head + (('\n' + note) if note else '') + '\n\n'

    # ── 읽기 폰트 ──
    def _build_font(self, nb):
        """폰트 탭 = **컨트롤 타워로 가는 입구**만 둔다 (2026-08-13 · `font.md` 3단계).

        ⚠ 예전에는 여기에 글꼴·크기·줄간격 콤보가 있었는데 문제가 둘이었다.
          ① **줄간격 콤보가 죽어 있었다** — `READING_FONT['spacing']` 을 저장했으나
             `apply_text()` 는 그 값을 쓰지 않아 **아무 일도 일어나지 않았다.**
          ② P1 읽기 팝업과 **기능이 중복**됐다(사용자 지적).
        ⇒ 설정은 `font_settings` 창 한 곳에만 둔다. 여기서는 그 창을 연다.
          **탭이 P1 자리를 차지하면 성경 본문을 보면서 조절할 수 없기 때문이다.**
        """
        f = tk.Frame(nb, bg=_C('bg', '#FAFAFA')); nb.add(f, text=' ' + i18n.t('SET_TAB_FONT', '폰트') + ' ')
        box = tk.Frame(f, bg=_C('bg', '#FAFAFA')); box.pack(anchor='w', padx=18, pady=18, fill='x')
        tk.Label(box, text=i18n.t('SET_FONT_TOWER',
                                  '글꼴·크기·줄간격을 화면 종류별로 조절합니다.'),
                 bg=_C('bg', '#FAFAFA'), font=('', 10)).pack(anchor='w')
        tk.Label(box, text=i18n.t('SET_FONT_TOWER_NOTE',
                                  '설정 창은 따로 열립니다. 옆으로 비켜 두면 성경 본문과 '
                                  '설명문이 바뀌는 모습을 그 자리에서 볼 수 있습니다.'),
                 bg=_C('bg', '#FAFAFA'), fg=_C('fg_dim', '#777'), font=('', 9), justify='left').pack(anchor='w', pady=(4, 10))
        tk.Button(box, text=i18n.t('SET_FONT_OPEN', '폰트 설정 열기'),
                  font=('', 10), padx=14, pady=4,
                  command=self._open_font_tower).pack(anchor='w')

        try:
            import theme_font as _tf
            n = len(_tf.loaded_files())
            if n:
                tk.Label(box, text='※ ' + i18n.t('SET_FONT_BUNDLED',
                                                 '원어용 폰트 {n}개를 함께 싣고 있습니다 '
                                                 '(히브리·콥트·아랍).').format(n=n),
                         bg=_C('bg', '#FAFAFA'), fg=_C('fg_dim', '#888'), font=('', 8)).pack(anchor='w', pady=(10, 0))
            tk.Label(box, text='※ ' + i18n.t('SET_FONT_USERDIR',
                                             'fonts_user 폴더에 폰트를 넣으면 설치 없이 쓸 수 있습니다.'),
                     bg=_C('bg', '#FAFAFA'), fg=_C('fg_dim', '#888'), font=('', 8)).pack(anchor='w')
        except Exception:
            pass

    def _open_font_tower(self, scope=None):
        try:
            import font_settings
            font_settings.open_font_settings(self.winfo_toplevel(), self.db,
                                             scope=scope, on_change=self._notify_saved)
        except Exception as e:
            messagebox.showerror(i18n.t('SET_TAB_FONT', '폰트'), str(e))

    # ── 저장 (탭별) ──
    def _save_lang(self):
        li = self._lang_cb.current()
        if li >= 0:
            _cfg_set(self.db, 'user_lang', self._lang_codes[li])
        ci = self._country_cb.current() if hasattr(self, '_country_cb') else -1
        if ci >= 0:
            ads.set_country(self.db, self._country_codes[ci])
        self._notify_saved()
        messagebox.showinfo(i18n.t('SET_TAB_LANG', '언어'),
                            i18n.t('SET_SAVED_LANG', '저장되었습니다. 언어 변경은 재시작 후 적용됩니다.'))

    def _save_version(self):
        di = self._dv_cb.current()
        if di >= 0:
            _cfg_set(self.db, 'v1_code', self._dv_codes[di])
        _base = self._dv_codes[di] if di >= 0 else 'KRV'
        pref = [c for c, v in self._pref_vars.items() if v.get()]
        if not pref:   # 최소 1개 보장 — 기본버전
            pref = [_base]
        _cfg_set(self.db, 'PREFERRED_VERSIONS', json.dumps(pref, ensure_ascii=False))
        # ★ **읽기 목록에는 기본 버전이 반드시 들어간다** — 빠지면 지금 읽고 있는
        #   역본이 P1 목록에서 사라진다(체크를 안 했어도 넣는다).
        read = [c for c, v in self._read_vars.items() if v.get()]
        if _base not in read:
            read.insert(0, _base)
        _cfg_set(self.db, 'READING_VERSIONS', json.dumps(read, ensure_ascii=False))
        # ★ 반쪽 역본의 짝 — **고른 것만** 담는다. 「기본」은 아예 안 적어야
        #   역본이 스스로 아는 짝(`partner_code`)이 그대로 산다.
        # ⚠ 짝 갈래를 한 번도 안 열었으면 `_pt_sel` 이 없다 — 그때는 **저장값을
        #   건드리지 않는다**(안 그러면 열지도 않고 지우게 된다).
        if hasattr(self, '_pt_sel'):
            _cfg_set(self.db, 'VERSION_PARTNER',
                     json.dumps(self._pt_sel, ensure_ascii=False))
        with appdb.connect(self.db) as _c:   # CMP_VERSIONS 폐기 — PREFERRED_VERSIONS로 일원화
            _c.execute("DELETE FROM user_config WHERE config_key='CMP_VERSIONS'"); _c.commit()
        self._notify_saved()
        messagebox.showinfo(i18n.t('SET_TAB_VERSION', '성경 버전'),
                            i18n.t('SET_SAVED_OK', '저장되었습니다.'))

    def _save_font(self):
        """더 이상 여기서 저장하지 않는다 — `font_settings` 창이 만질 때마다 즉시 저장한다."""
        self._notify_saved()

    def __init__(self, master, db_path, on_saved=None):
        super().__init__(master)
        self.db = db_path
        self.on_saved = on_saved
        self.title(i18n.t('SET_TITLE', '환경설정'))
        self.geometry('580x640')
        self.transient(master); self.grab_set()
        bar = tk.Frame(self, bg=_C('dark_bg', '#1B2631'), height=46); bar.pack(fill='x'); bar.pack_propagate(False)
        tk.Label(bar, text=i18n.t('SET_TITLE', '환경설정'), bg=_C('dark_bg', '#1B2631'), fg=_C('fg_on_dark', 'white'),
                 font=('', 12, 'bold')).pack(side='left', padx=14)
        tk.Button(bar, text=i18n.t('COMMON_CLOSE', '닫기'), bg=_C('border', '#D5D8DC'), fg=_C('fg', '#333'), bd=0,
                  padx=12, pady=5, command=self.destroy).pack(side='right', padx=8, pady=7)
        nb = ttk.Notebook(self); nb.pack(fill='both', expand=True, padx=8, pady=8)
        self.build_all_tabs(nb)
