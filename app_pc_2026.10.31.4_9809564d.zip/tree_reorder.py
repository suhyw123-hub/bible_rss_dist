# -*- coding: utf-8 -*-
"""tree_reorder.py — 목록(Treeview) 줄을 **마우스로 끌어** 차례를 바꾸고 기억한다 (2026-10-15 · docs/1.txt 88 후속).

사용자 「마우스로 목록을 이동하는 방식이 P1 화면의 도서/설교, 다른 플랜 목록화면에서도 가능하다면 적용하라」.

· `enable(tv, key, db_path, movable=None)` — 끌기를 건다(한 번만). 같은 부모 안에서만 옮긴다(분류를 넘지 않는다).
· `apply(tv, key, db_path)` — 목록을 다시 채운 **뒤에** 부른다. 기억한 차례대로 놓고, 기억에 없는 줄(새로 생긴 것)은
  원래 자리 차례대로 뒤에 둔다.
· 저장 = `user_config[key]` JSON {부모 iid: [자식 iid, …]} — 화면마다 열쇠가 따로다.
⚠ 누르기만 하면 안 옮긴다 — 6px 넘게 끌어야 끌기로 친다(클릭으로 고르는 일을 방해하지 않는다).
⚠ 줄 이름(iid)이 열쇠다 — 화면이 줄 이름을 바꾸면 기억이 끊긴다(그 줄은 원래 차례로 돌아갈 뿐 깨지지 않는다).
"""
import json
import sys

import appdb


def _load(db_path, key):
    try:
        with appdb.connect(db_path) as conn:
            r = conn.execute("SELECT config_val FROM user_config WHERE config_key=?", (key,)).fetchone()
        d = json.loads(r[0]) if r and r[0] else {}
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _save(db_path, key, d):
    val = json.dumps(d, ensure_ascii=False)
    with appdb.connect(db_path) as conn:
        if conn.execute("SELECT 1 FROM user_config WHERE config_key=?", (key,)).fetchone():
            conn.execute("UPDATE user_config SET config_val=? WHERE config_key=?", (val, key))
        else:
            conn.execute("INSERT INTO user_config (config_key, config_val) VALUES (?,?)", (key, val))
        conn.commit()


def apply(tv, key, db_path):
    """기억한 차례로 놓는다. 돌려주는 값 = 옮긴 부모 수."""
    d = _load(db_path, key)
    n = 0
    for parent, order in d.items():
        p = '' if parent == '.' else parent
        try:
            if p and not tv.exists(p):
                continue
            kids = list(tv.get_children(p))
        except Exception:
            continue
        known = [i for i in order if i in kids]
        if not known:
            continue
        rest = [i for i in kids if i not in known]
        want = known + rest
        if want != kids:
            for idx, iid in enumerate(want):
                tv.move(iid, p, idx)
            n += 1
    return n


def enable(tv, key, db_path, movable=None):
    """끌어서 차례 바꾸기를 건다. movable(iid) → 이 줄을 옮겨도 되나(없으면 모두)."""
    if getattr(tv, '_reorder_key', None):
        tv._reorder_key = key
        return
    tv._reorder_key = key
    st = {'iid': None, 'y': 0, 'moved': False}

    def press(e):
        iid = tv.identify_row(e.y)
        st.update(iid=iid if iid and (movable is None or movable(iid)) else None, y=e.y, moved=False)

    def motion(e):
        src = st['iid']
        if not src or (not st['moved'] and abs(e.y - st['y']) < 6):
            return
        tgt = tv.identify_row(e.y)
        if not tgt or tgt == src:
            return
        par = tv.parent(src)
        if tv.parent(tgt) != par:
            return
        st['moved'] = True
        tv.move(src, par, tv.index(tgt))
        try:
            tv.configure(cursor='sb_v_double_arrow')
        except Exception:
            pass

    def release(_e):
        src, moved = st['iid'], st['moved']
        st.update(iid=None, moved=False)
        try:
            tv.configure(cursor='')
        except Exception:
            pass
        if not (src and moved):
            return
        try:
            par = tv.parent(src)
            d = _load(db_path, tv._reorder_key)
            d[par or '.'] = list(tv.get_children(par))
            _save(db_path, tv._reorder_key, d)
        except Exception as ex:
            print('[tree_reorder] %s' % ex)

    tv.bind('<ButtonPress-1>', press, add='+')
    tv.bind('<B1-Motion>', motion, add='+')
    tv.bind('<ButtonRelease-1>', release, add='+')


def selftest():
    import tkinter as tk
    from tkinter import ttk
    ok = [0, 0]

    def t(name, cond, got=''):
        ok[1] += 1
        ok[0] += bool(cond)
        print(('  OK   ' if cond else '  FAIL ') + name, '' if cond else got)
    key = 'TREE_ORDER_SELFTEST'
    root = tk.Tk()
    root.withdraw()
    try:
        tv = ttk.Treeview(root)
        tv.pack()

        def fill():
            tv.delete(*tv.get_children())
            tv.insert('', 'end', iid='G1', text='g1', open=True)
            tv.insert('', 'end', iid='G2', text='g2')
            for i in range(4):
                tv.insert('G1', 'end', iid='A%d' % i, text='a%d' % i)
        fill()
        enable(tv, key, 'bible_master.db')
        tv.move('A3', 'G1', 0)
        _save('bible_master.db', key, {'G1': list(tv.get_children('G1')), '.': ['G2', 'G1']})
        fill()
        apply(tv, key, 'bible_master.db')
        t('기억한 차례대로', list(tv.get_children('G1')) == ['A3', 'A0', 'A1', 'A2'], tv.get_children('G1'))
        t('맨 위 층도', list(tv.get_children('')) == ['G2', 'G1'])
        fill()
        tv.insert('G1', 0, iid='NEW', text='new')
        apply(tv, key, 'bible_master.db')
        t('새 줄은 기억한 줄 뒤에', list(tv.get_children('G1'))[-1] == 'NEW', tv.get_children('G1'))
    finally:
        with appdb.connect('bible_master.db') as conn:
            conn.execute("DELETE FROM user_config WHERE config_key=?", (key,))
            conn.commit()
        root.destroy()
    print('tree_reorder selftest: %d/%d' % tuple(ok))
    return ok[0] == ok[1]


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    sys.exit(0 if selftest() else 1)
