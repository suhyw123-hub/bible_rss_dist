# -*- coding: utf-8 -*-
"""John Gill, Exposition of the Old and New Testament (1746-63) 임포터.

원본 = sacred-texts.com (퍼블릭 도메인 선언 · robots.txt Allow). HTML 은
`temp_code_gill_fetch.py` 가 `_gill_raw/` 에 받아 둔다. 이 파일은 그것만 읽는다.

왜 이 주석인가 — 2026-08-04 실측으로 구약 23,146절 중 8,679절(37.5%)에
절 단위 주석이 아예 없었다(대상 66% · 민 65% · 레 60% · 대하 55% · 신 54%).
Gill 은 전권 절별이라 그 빈칸을 그대로 메운다. K&D 는 단락 단위라 못 메운다.

★ 파싱이 추측이 아니다. sacred-texts 판은 절마다
    <A NAME="an_001">ch1 5:1</A>
앵커가 박혀 있어 책·장·절을 본문이 스스로 말한다. BARNES 의 `Verse 12.` 나
CLARKE 의 KJV 표제어를 미루어 짐작하던 것과 다르다.

★ end_vid 를 반드시 채운다. 기존 33,178행 중 29,716행이 end_vid NULL 이라
  `start_vid<=? AND end_vid>=?` 가 조용히 0건을 냈다(§8). 같은 함정을
  새 소스에서 되풀이하지 않는다.

사용:
    python -X utf8 db_gill_import.py --selftest      # 파서 탐지력 (의무)
    python -X utf8 db_gill_import.py --fetch         # 원본 HTML 내려받기 (이어받기)
    python -X utf8 db_gill_import.py --check         # 파싱만, DB 미변경
    python -X utf8 db_gill_import.py --sample 3 13   # 한 장 눈으로 보기 (bcode 장)
    python -X utf8 db_gill_import.py --apply         # 적재 (멱등)
"""
import os, re, sys, html, glob, time, sqlite3, argparse
import urllib.request

APP = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(APP, '_gill_raw')
DB  = os.path.join(APP, 'bible_master.db')

CODE = {
    1:'gen',  2:'exo',  3:'lev',  4:'num',  5:'deu',  6:'jos',  7:'jdg',
    8:'rut',  9:'sa1', 10:'sa2', 11:'kg1', 12:'kg2', 13:'ch1', 14:'ch2',
   15:'ezr', 16:'neh', 17:'est', 18:'job', 19:'psa', 20:'pro', 21:'ecc',
   22:'sol', 23:'isa', 24:'jer', 25:'lam', 26:'eze', 27:'dan', 28:'hos',
   29:'joe', 30:'amo', 31:'oba', 32:'jon', 33:'mic', 34:'nah', 35:'hab',
   36:'zep', 37:'hag', 38:'zac', 39:'mal',
}
BY_CODE = {v: k for k, v in CODE.items()}

# ★ `sys_commentary_entry.bcode` 는 숫자가 아니라 **세 글자 책 약자**다.
#   기존 5개 소스(CLARKE·BARNES_NT·PULPIT_COM·JFB·HENRY_MHC)가 전부 이 규약을 쓴다.
#   2026-08-04 첫 적재에서 숫자('1'~'39')를 넣었다가 규약을 깼다 — 아래 표로 바로잡았다.
#   sacred-texts 파일 코드와 다섯 군데가 다르다: kg1→KI1 · kg2→KI2 · sol→SOS · joe→JOL · zac→ZEC.
#   ⚠ 컬럼 선언이 TEXT 라 숫자를 넣으면 `bcode<=39` 가 사전순 비교가 된다('4' > '39').
#     범위 조건에 쓰지 말고 `start_vid` 로 걸 것.
ABBR = {
    1:'GEN',  2:'EXO',  3:'LEV',  4:'NUM',  5:'DEU',  6:'JOS',  7:'JDG',
    8:'RUT',  9:'SA1', 10:'SA2', 11:'KI1', 12:'KI2', 13:'CH1', 14:'CH2',
   15:'EZR', 16:'NEH', 17:'EST', 18:'JOB', 19:'PSA', 20:'PRO', 21:'ECC',
   22:'SOS', 23:'ISA', 24:'JER', 25:'LAM', 26:'EZE', 27:'DAN', 28:'HOS',
   29:'JOL', 30:'AMO', 31:'OBA', 32:'JON', 33:'MIC', 34:'NAH', 35:'HAB',
   36:'ZEP', 37:'HAG', 38:'ZEC', 39:'MAL',
}

SRC = dict(
    commentary_code='GILL',
    title='Exposition of the Old and New Testament',
    author='John Gill',
    pub_year=1763,
    lang_code='EN',
    coverage_scope='FULL',
    copyright_type='PUBLIC_DOMAIN',
    source_url='https://sacred-texts.com/bib/cmt/gill/',
    description=(
        "John Gill's Exposition of the Entire Bible (1746-63) is a verse-by-verse "
        "commentary covering every chapter of Scripture. Gill, a Baptist minister and "
        "Hebraist, draws steadily on rabbinic sources, the Targums and the Talmud, and "
        "so supplies Jewish background that most English commentaries of his century "
        "leave untouched. His notes open with the biblical phrase itself and then "
        "unfold it clause by clause, which makes the work unusually easy to consult "
        "one verse at a time. Because it is complete rather than selective, it covers "
        "the narrative and legal books of the Old Testament that verse-level "
        "commentaries commonly pass over."),
    description_ko=(
        '존 길의 「구약과 신약 강해」(1746-63)는 성경 전권을 절 단위로 다룬 주석이다. '
        '길은 히브리어에 밝은 목회자였고 탈무드와 타르굼 같은 유대 문헌을 꾸준히 '
        '인용해, 같은 시대 영어 주석이 잘 다루지 않던 유대적 배경을 채워 준다. '
        '각 항목이 성경 어구를 먼저 인용한 뒤 구절을 마디마디 풀어 가는 방식이라 '
        '한 절씩 찾아보기에 좋다. 발췌가 아니라 전권을 고르게 다루기 때문에, '
        '절 단위 주석이 대개 건너뛰는 구약의 서사서와 율법서까지 포함한다.'),
)

FILENAV = re.compile(r'(?i)<div\s+class="filenav"')

# 절 머리 = (가운데 정렬 표제) + margnote 안의 <A NAME="an_NNN">책 장:절</A>
VHEAD = re.compile(
    r'(?is)(?:<p\s+align="center">\s*<a\b[^>]*>[^<]*</a>\s*</p>\s*)?'
    r'<p>\s*<span\s+class="margnote">.*?'
    r'<a\s+name="an_(\d+)"[^>]*>(.*?)</a>.*?</span>\s*</p>')

# 장 제목 — 이 뒤가 본문이다
CHTITLE = re.compile(r'(?is)at\s+sacred-texts\.com\s*</?[a-z][^>]*>')


def clean(frag):
    """태그를 걷어내되 상호참조 링크의 글자(`Gen 49:3`)는 살린다."""
    s = re.sub(r'(?is)<(script|style)\b.*?</\1>', ' ', frag)
    s = re.sub(r'(?is)<span\s+class="margnote">.*?</span>', ' ', s)
    s = re.sub(r'(?i)<br\s*/?>', '\n', s)
    s = re.sub(r'(?i)</?p\b[^>]*>', '\n\n', s)
    s = re.sub(r'<[^>]+>', '', s)          # 남은 태그 제거 (a 의 글자는 남는다)
    s = html.unescape(s)
    s = s.replace(' ', ' ')
    s = re.sub(r'[ \t]+', ' ', s)
    s = re.sub(r' *\n *', '\n', s)
    s = re.sub(r'\n{3,}', '\n\n', s)
    return s.strip()


def parse_chapter(raw):
    """한 장 HTML → [(verse|0, 본문)]. verse 0 = 장 서론.

    ⚠ `filenav` 는 페이지 위아래 둘 다에 있다. 앞의 것에서 자르면 본문이
      통째로 날아간다(2026-08-04 selftest 가 0개로 잡아냈다).
      그래서 앵커를 먼저 찾고 **마지막 앵커 뒤의** filenav 에서 자른다.
    """
    heads_raw = list(VHEAD.finditer(raw))

    m = CHTITLE.search(raw)
    start = m.end() if m else 0
    if heads_raw and start > heads_raw[0].start():
        start = 0                       # 장 제목이 본문 뒤라면 믿지 않는다

    tail_from = heads_raw[-1].end() if heads_raw else start
    m_end = FILENAV.search(raw, tail_from)
    end = m_end.start() if m_end else len(raw)

    body = raw[start:end]
    heads = list(VHEAD.finditer(body))
    out = []

    if heads:
        intro = clean(body[:heads[0].start()])
        # 장 제목 한 줄만 남는 경우가 있어 길이로 거른다
        if len(intro) > 200:
            out.append((0, intro))
    else:
        whole = clean(body)
        if len(whole) > 200:
            out.append((0, whole))
        return out

    for i, h in enumerate(heads):
        vnum = int(h.group(1))
        tail = heads[i + 1].start() if i + 1 < len(heads) else len(body)
        txt = clean(body[h.end():tail])
        if not txt:
            continue
        if vnum == 0:
            # an_000 = 장 서론. 앞서 넣은 intro 가 있으면 합친다.
            if out and out[0][0] == 0:
                out[0] = (0, out[0][1] + '\n\n' + txt)
            else:
                out.insert(0, (0, txt))
        else:
            out.append((vnum, txt))
    return out


def vid_map(conn, bcode, chapter):
    return dict(conn.execute(
        'SELECT verse, verse_id FROM bible_index WHERE bcode=? AND chapter=?',
        (bcode, chapter)))


def collect(conn, only=None):
    """_gill_raw 전체를 파싱해 적재 단위로 만든다."""
    rows, warn = [], []
    for path in sorted(glob.glob(os.path.join(RAW, '*.html'))):
        base = os.path.basename(path)[:-5]
        code, ch = base[:3], int(base[3:])
        bcode = BY_CODE.get(code)
        if bcode is None:
            continue
        if only and (bcode, ch) != only:
            continue
        raw = open(path, 'rb').read().decode('utf-8', 'replace')
        vm = vid_map(conn, bcode, ch)
        if not vm:
            warn.append('%s %d: bible_index 에 없는 장' % (code, ch))
            continue
        lo, hi = min(vm.values()), max(vm.values())
        for vnum, txt in parse_chapter(raw):
            if vnum == 0:
                rows.append(dict(level='CHAPTER', bcode=ABBR[bcode], chapter=ch,
                                 start=lo, end=hi, body=txt))
            elif vnum in vm:
                rows.append(dict(level='VERSE', bcode=ABBR[bcode], chapter=ch,
                                 start=vm[vnum], end=vm[vnum], body=txt))
            else:
                warn.append('%s %d:%d — bible_index 에 없는 절' % (code, ch, vnum))
    return rows, warn


UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36')
URL = 'https://sacred-texts.com/bib/cmt/gill/%s%03d.htm'
DELAY = 0.9          # 요청 간격. 줄이지 말 것 — 929장을 남의 서버에서 받는다.


def do_fetch(conn):
    """구약 39권 장별 HTML 을 `_gill_raw/` 로 받는다. 이미 받은 것은 건너뛴다.

    robots.txt 가 전 크롤러에 Allow: / 이고, 각 페이지가
    <meta name="copyright" content="Public Domain and Creative Commons"> 를
    선언한다. 본문도 1746-63 년 저작이라 저작권이 소멸했다.
    """
    os.makedirs(RAW, exist_ok=True)
    nch = dict(conn.execute(
        'SELECT bcode, MAX(chapter) FROM bible_index '
        'WHERE bcode BETWEEN 1 AND 39 GROUP BY bcode'))
    got = skip = fail = 0
    for bcode in sorted(CODE):
        code = CODE[bcode]
        for ch in range(1, nch.get(bcode, 0) + 1):
            path = os.path.join(RAW, '%s%03d.html' % (code, ch))
            if os.path.exists(path) and os.path.getsize(path) > 2000:
                skip += 1
                continue
            req = urllib.request.Request(URL % (code, ch), headers={'User-Agent': UA})
            try:
                with urllib.request.urlopen(req, timeout=40) as r:
                    data = r.read()
            except Exception as e:
                fail += 1
                print('  FAIL %s %d: %s' % (code, ch, str(e)[:60]), flush=True)
                time.sleep(DELAY)
                continue
            open(path, 'wb').write(data)
            got += 1
            if got % 50 == 0:
                print('  %d 받음 (건너뜀 %d, 실패 %d)' % (got, skip, fail), flush=True)
            time.sleep(DELAY)
        print('%-4s %2d권 %3d장' % (code, bcode, nch.get(bcode, 0)), flush=True)
    print('받음 %d · 건너뜀 %d · 실패 %d' % (got, skip, fail))
    return 1 if fail else 0


def source_id(conn, create):
    r = conn.execute('SELECT commentary_id FROM sys_commentary_source '
                     'WHERE commentary_code=?', (SRC['commentary_code'],)).fetchone()
    if r:
        return r[0]
    if not create:
        return None
    cols = list(SRC) + ['record_status']
    vals = [SRC[k] for k in SRC] + ['LIVE']
    conn.execute('INSERT INTO sys_commentary_source (%s) VALUES (%s)'
                 % (','.join(cols), ','.join('?' * len(cols))), vals)
    return conn.execute('SELECT commentary_id FROM sys_commentary_source '
                        'WHERE commentary_code=?',
                        (SRC['commentary_code'],)).fetchone()[0]


def do_apply(conn, rows):
    cid = source_id(conn, create=True)
    old = conn.execute('SELECT COUNT(*) FROM sys_commentary_entry '
                       'WHERE commentary_id=?', (cid,)).fetchone()[0]
    if old:
        print('기존 %d 항목 삭제 후 재적재 (멱등)' % old)
        conn.execute('DELETE FROM sys_commentary_text WHERE entry_id IN '
                     '(SELECT entry_id FROM sys_commentary_entry WHERE commentary_id=?)',
                     (cid,))
        conn.execute('DELETE FROM sys_commentary_entry WHERE commentary_id=?', (cid,))
    for r in rows:
        cur = conn.execute(
            'INSERT INTO sys_commentary_entry '
            '(commentary_id, entry_level, bcode, chapter, start_vid, end_vid, record_status) '
            'VALUES (?,?,?,?,?,?,?)',
            (cid, r['level'], r['bcode'], r['chapter'], r['start'], r['end'], 'LIVE'))
        conn.execute(
            'INSERT INTO sys_commentary_text '
            '(entry_id, text_variant, lang_code, body_text, record_status) '
            'VALUES (?,?,?,?,?)',
            (cur.lastrowid, 'ORIGINAL', 'EN', r['body'], 'LIVE'))
    conn.commit()
    print('적재 완료: %d 항목' % len(rows))


def report(conn, rows, warn):
    v = [r for r in rows if r['level'] == 'VERSE']
    c = [r for r in rows if r['level'] == 'CHAPTER']
    print('항목 %d — 절 %d · 장서론 %d' % (len(rows), len(v), len(c)))
    if v:
        ln = sorted(len(r['body']) for r in v)
        print('절 본문 자수: 중앙값 %d · 평균 %d · 최소 %d · 최대 %d'
              % (ln[len(ln) // 2], sum(ln) // len(ln), ln[0], ln[-1]))
    have = {r['start'] for r in v}
    tot = conn.execute('SELECT COUNT(*) FROM bible_index WHERE bcode<=39').fetchone()[0]
    print('구약 절 커버: %d / %d = %.1f%%' % (len(have), tot, 100.0 * len(have) / tot))

    cur = set(x[0] for x in conn.execute(
        'SELECT DISTINCT e.start_vid FROM sys_commentary_entry e '
        'JOIN sys_commentary_source s USING(commentary_id) '
        'WHERE s.commentary_code IN ("CLARKE","PULPIT_COM") '
        'AND e.entry_level="VERSE" AND e.start_vid<=?', (tot,)))
    print('기존(CLARKE·PULPIT) 커버 %d → Gill 합산 %d (%.1f%%)'
          % (len(cur), len(cur | have), 100.0 * len(cur | have) / tot))
    print('Gill 이 새로 메우는 절: %d' % len(have - cur))
    if warn:
        print('경고 %d건 (앞 15)' % len(warn))
        for w in warn[:15]:
            print('  ', w)


def selftest():
    """파서가 실제로 잡아내는지 확인한다. 통과 없이는 신뢰하지 않는다."""
    p = os.path.join(RAW, 'ch1005.html')
    if not os.path.exists(p):
        print('SKIP — 표본 %s 없음 (먼저 내려받을 것)' % p)
        return 0
    raw = open(p, 'rb').read().decode('utf-8', 'replace')
    got = parse_chapter(raw)
    d = dict(got)
    ok = True

    def chk(cond, msg):
        nonlocal ok
        print(('  OK   ' if cond else '  FAIL ') + msg)
        ok = ok and cond

    chk(len(got) >= 20, '항목 %d개 (>=20)' % len(got))
    chk(0 in d, '장 서론(an_000) 추출')
    chk(1 in d and d[1].startswith('Now the sons of Reuben'),
        '5:1 본문이 성경 어구로 시작 — %r' % (d.get(1, '')[:40]))
    chk(1 in d and 'Gen 49:3' in d[1], '상호참조 링크 글자 보존 (Gen 49:3)')
    joined = '\n'.join(t for _, t in got)
    for bad in ('Sacred Texts', 'Next:', 'Previous:', 'filenav', 'margnote', '<'):
        chk(bad not in joined, '탐색·꼬리 잔재 없음: %r' % bad)
    chk('\n\n' in d.get(1, ''), '문단 구분 보존')
    chk(26 in d, '마지막 절(5:26) 추출')
    print('SELFTEST', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--fetch', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--sample', nargs=2, metavar=('BCODE', 'CHAPTER'))
    a = ap.parse_args()

    if a.selftest:
        return selftest()

    conn = sqlite3.connect(DB)
    if a.fetch:
        rc = do_fetch(conn)
        conn.close()
        return rc
    if a.sample:
        only = (int(a.sample[0]), int(a.sample[1]))
        rows, warn = collect(conn, only=only)
        for r in rows[:6]:
            print('-' * 60)
            print('%s %s장 vid %s~%s' % (r['level'], r['chapter'], r['start'], r['end']))
            print(r['body'][:700])
        print('=' * 60)
        print('%d 항목' % len(rows))
        return 0

    rows, warn = collect(conn)
    report(conn, rows, warn)
    if a.apply:
        do_apply(conn, rows)
    else:
        print('\n(--apply 를 주지 않아 DB 는 건드리지 않았다)')
    conn.close()
    return 0


if __name__ == '__main__':
    sys.exit(main())
