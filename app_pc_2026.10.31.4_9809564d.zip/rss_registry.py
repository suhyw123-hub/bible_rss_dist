"""
rss_registry.py
---------------
RSS 피드 주소록 배포 표준 포맷 (관리자앱 ↔ 서버파일 ↔ 사용자앱 공유).

순수 포맷 계층 — Tkinter/DB 의존성 없음. build/parse/hash 만 제공.
  · 관리자: sys_rss_feed → build_feeds_tsv/html + build_manifest → 서버 업로드
  · 사용자: 서버에서 manifest/feeds 받음 → parse → (rss_reader 가 user_data.db 에 적용)

== 표준 파일 ==
feeds.tsv     : 피드 주소록 전체 스냅샷 (LIVE/HIDE + DELETED 묘비행)
feeds.html    : 같은 내용 사람용 미러
manifest.tsv  : 배포 매니페스트 (published_at = 업로드시각 = 통제 키)

== 동기화 모델 (날짜 기준 증분) ==
사용자 접속 시점 불규칙 → "매일 가져간다" 가정 금지.
  ① manifest 먼저 받음 (서버A→B 절체)
  ② manifest.published_at > 로컬 last_published_at  →  변경 있음
  ③ feeds.tsv 받아 멱등 upsert(LIVE/HIDE) + record_status=DELETED 행은 로컬 삭제(묘비)
  ④ last_published_at = manifest.published_at 로 갱신
주소록은 작음 → 전체 스냅샷 매번 OK. 접속 공백이 길어도 현재 진실로 수렴.
(2단계 items.tsv 는 누적·대용량이라 published 기준 진짜 날짜-델타 적용 예정.)
"""

import hashlib

FORMAT_VERSION = "1"

# feeds.tsv 표준 컬럼 (순서 고정 — 3주체 공통)
FEEDS_COLUMNS = [
    "feed_id", "feed_url", "site_name", "lang", "feed_kind",
    "record_status", "note", "updated_at",
]

# items.tsv 표준 컬럼 (2단계 항목 색인 — 제목·URL·날짜만. 본문/요약 절대 미포함=법적 선)
# collected: 유튜브 '수집 시각'(늦게 수집해도 최신처럼 정렬). items 는 빈값.
ITEMS_COLUMNS = [
    "feed_url", "site_name", "lang", "feed_kind", "title", "item_url", "published", "collected",
    # ★ 2026-10-22 (docs/제목번역.txt 2·3) 폰 「번역해서 읽기 / 원문 읽기」 —
    #   title_orig = 원문 제목 · translated = 이 파일의 title 이 번역본이면 1 · xl_ok = 그 사이트가 구글 자동번역 페이지로 열리나(1/0 · 모르면 빈칸)
    #   받는 쪽은 머리줄 이름으로 읽으므로(parse_items_tsv · 폰 parseTsv) 옛 앱은 모르는 칸을 그냥 지나친다.
    "title_orig", "translated", "xl_ok",
    # ★ 2026-10-24 제목을 옮긴 기계(GEMINI · GOOGLE) — 폰이 「Gemini 번역」처럼 표시한다(사용자 「누가 번역했는지 기계 이름」)
    "xl_by",
    # ★ 2026-10-24 그 사이트의 나라(ISO 두 글자 · 모르면 빈칸) — 폰이 「미국 · Gemini 번역 · …」처럼 보인다
    "country",
]

# 방식 A: items.tsv 에 11개 UI 언어 제목번역 칼럼(t_<LANG>)을 선택적으로 부가한다.
# (헤더 기반 파싱이라 칼럼 추가는 하위호환. 원본언어=대상언어면 빈값 → 클라가 원문 표시.)
XL_LANGS = ["KO", "EN", "ZH", "ZHT", "JA", "DE", "FR", "ES", "AR", "RU", "PT"]
XL_COLUMNS = ["t_" + lg for lg in XL_LANGS]


def item_xl(row, ui_lang):
    """row 에서 UI 언어 번역제목 추출(없으면 ''). ui_lang = KO/EN/… ."""
    return (row.get("t_" + (ui_lang or "").upper()) or "").strip()

# manifest.tsv 표준 컬럼
MANIFEST_COLUMNS = [
    # ⚠ `file` 은 **논리 이름**(옛 앱이 이 이름으로 찾는다 — 바꾸지 말 것).
    #   `path` 가 **실제로 받을 이름**이고 내용 지문이 붙어 있다.
    #   ⚠ 칸을 더해도 옛 앱은 안 깨진다 — `parse_manifest_tsv` 가 머리줄을
    #     읽어 칸을 만든다(모르는 칸은 그냥 담긴다).
    "file", "published_at", "row_count", "content_sha1", "format_version",
    "path",
]

#: 이름에 붙이는 지문 길이 — 8자면 우리 파일 수에서 겹칠 일이 없다
VER_HEX = 8

FEEDS_FILE = "feeds.tsv"
FEEDS_HTML = "feeds.html"
ITEMS_FILE = "items.tsv"
YOUTUBE_FILE = "youtube.tsv"   # 최신 유튜브(관리자 수집결과 배포, ITEMS_COLUMNS 재사용)
ANN_FILE = "announcements.json"   # 공지(1차 콘텐츠 — 본문 포함, 다국어). 줄바꿈 위해 JSON
#: AI 모델 목록(2026-09-29 299차-3) — 회사별 후보·기본·**물린 이름 → 별칭**.
#  ⚠ 키는 한 글자도 안 들어간다(§C-2 · `db_ai_models.export_payload` 가 만든다).
AIMODELS_FILE = "ai_models.json"
SHOP_FILE = "shop.json"           # ★ 2026-10-23 추천몰(db_shop) — 날마다 · 그림은 shopimg_<지문>.jpg 로 따로
APPINFO_FILE = "app_info.json"   # ★ 2026-10-21 앱 소개(app_info) — 글만 · 폰이 앱 소개를 열 때 받는다
#: ★ 2026-10-24 앱이 받는 유튜브 채널 번호(UC…) — 한 줄에 하나. 사용자가 「내가 모은 채널」로 같은 채널을 담으면
#   그 기기는 제 받기를 멈춘다(관리자가 이미 받아 「앱 채널」에 나온다 · 관리자가 빼면 저절로 이어 받는다).
APP_CHANNELS_FILE = "app_channels.txt"
MANIFEST_FILE = "manifest.tsv"

# feed_kind 허용값
FEED_KINDS = ("DEVOTIONAL", "NEWS")
# record_status: LIVE(노출) / HIDE(숨김, 클라 보관) / DELETED(묘비 — 클라 삭제)
RECORD_STATUSES = ("LIVE", "HIDE", "DELETED")


# ── TSV 안전 처리 ────────────────────────────────────────────────────

def _esc(v):
    """탭/개행을 공백으로 치환(TSV 1행 1레코드 보장). None→''."""
    if v is None:
        return ""
    return str(v).replace("\t", " ").replace("\r", " ").replace("\n", " ").strip()


def _tsv_line(values):
    return "\t".join(_esc(v) for v in values)


# ── feeds.tsv build / parse ──────────────────────────────────────────

def build_feeds_tsv(rows):
    """rows: dict 리스트(FEEDS_COLUMNS 키). → TSV 문자열(헤더 포함, \\n 종료)."""
    out = [_tsv_line(FEEDS_COLUMNS)]
    for r in rows:
        out.append(_tsv_line([r.get(c, "") for c in FEEDS_COLUMNS]))
    return "\n".join(out) + "\n"


def parse_feeds_tsv(text):
    """TSV 문자열 → dict 리스트. 헤더 순서에 맞춰 매핑(컬럼 추가/순서변경 견딤)."""
    lines = [ln for ln in (text or "").replace("\r\n", "\n").split("\n") if ln != ""]
    if not lines:
        return []
    header = lines[0].split("\t")
    rows = []
    for ln in lines[1:]:
        cells = ln.split("\t")
        d = {}
        for i, col in enumerate(header):
            d[col] = cells[i] if i < len(cells) else ""
        rows.append(d)
    return rows


# ── items.tsv build / parse (2단계 항목 색인) ────────────────────────

def build_items_tsv(rows, with_xl=False):
    """rows: dict 리스트(ITEMS_COLUMNS 키). 본문/요약 없음(제목·URL·날짜만).
    with_xl=True 면 11개 언어 번역칼럼(t_<LANG>)도 포함(구 단일파일 방식)."""
    cols = ITEMS_COLUMNS + (XL_COLUMNS if with_xl else [])
    out = [_tsv_line(cols)]
    for r in rows:
        out.append(_tsv_line([r.get(c, "") for c in cols]))
    return "\n".join(out) + "\n"


# ── 방식 A(언어별 파일): 한 언어의 파일 = ITEMS_COLUMNS, title=그 언어 번역본, lang=원본언어 ──
def items_lang_file(lang):
    return f"items_{(lang or '').upper()}.tsv"


def youtube_lang_file(lang):
    return f"youtube_{(lang or '').upper()}.tsv"


def build_items_lang_tsv(rows, lang):
    """언어별 배포 파일. title=t_<lang>(번역본, 없으면 원문), lang 칼럼=원본 언어코드 보존.
    (사용자는 자기 언어 파일만 받음. 원본 언어코드는 '내 언어만' 필터·원문언어 표시에 필요.)"""
    lang = (lang or '').upper()
    tcol = "t_" + lang
    out = [_tsv_line(ITEMS_COLUMNS)]
    for r in rows:
        tr = (r.get(tcol) or '').strip()
        title = tr or r.get("title", "")   # 번역 우선, 없으면 원문
        row = dict(r)
        row["title"] = title           # 그 언어 제목으로 치환
        row["title_orig"] = r.get("title", "")
        row["translated"] = "1" if tr and (r.get("lang") or "EN").upper() != lang else "0"
        row.setdefault("xl_ok", "")
        row["xl_by"] = (r.get("xb_" + lang) or "") if row["translated"] == "1" else ""
        if not row.get("country"):
            try:
                import rss_slots
                row["country"] = rss_slots.country_of(r.get("feed_url") or "", r.get("lang") or "")
            except Exception:
                row["country"] = ""
        # lang 칼럼은 원본 언어 그대로 유지(번역 대상언어로 바꾸지 않음)
        out.append(_tsv_line([row.get(c, "") for c in ITEMS_COLUMNS]))
    return "\n".join(out) + "\n"


def parse_items_tsv(text):
    lines = [ln for ln in (text or "").replace("\r\n", "\n").split("\n") if ln != ""]
    if not lines:
        return []
    header = lines[0].split("\t")
    rows = []
    for ln in lines[1:]:
        cells = ln.split("\t")
        rows.append({col: (cells[i] if i < len(cells) else "") for i, col in enumerate(header)})
    return rows


# ── feeds.html (사람용 미러) ─────────────────────────────────────────

def build_feeds_html(rows, published_at=""):
    import html as _h
    th = "".join(f"<th>{_h.escape(c)}</th>" for c in FEEDS_COLUMNS)
    body = []
    for r in rows:
        tds = "".join(f"<td>{_h.escape(_esc(r.get(c, '')))}</td>" for c in FEEDS_COLUMNS)
        cls = ""
        st = (r.get("record_status") or "").upper()
        if st == "DELETED":
            cls = ' style="color:#999;text-decoration:line-through"'
        elif st == "HIDE":
            cls = ' style="color:#b58900"'
        body.append(f"<tr{cls}>{tds}</tr>")
    return (
        "<!DOCTYPE html>\n<html><head><meta charset='utf-8'>"
        "<title>RSS Feed Registry</title>"
        "<style>body{font-family:sans-serif;font-size:13px}"
        "table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:3px 6px}"
        "th{background:#eef}</style></head><body>"
        f"<h3>RSS Feed Registry</h3><p>published_at: {_h.escape(_esc(published_at))} "
        f"&middot; rows: {len(rows)} &middot; format: v{FORMAT_VERSION}</p>"
        f"<table><thead><tr>{th}</tr></thead><tbody>{''.join(body)}</tbody></table>"
        "</body></html>\n"
    )


# ── manifest build / parse ───────────────────────────────────────────

def sha1_text(s):
    return hashlib.sha1((s or "").encode("utf-8")).hexdigest()


def build_manifest_tsv(entries):
    """entries: dict 리스트(MANIFEST_COLUMNS 키). → TSV 문자열."""
    out = [_tsv_line(MANIFEST_COLUMNS)]
    for e in entries:
        out.append(_tsv_line([e.get(c, "") for c in MANIFEST_COLUMNS]))
    return "\n".join(out) + "\n"


def parse_manifest_tsv(text):
    lines = [ln for ln in (text or "").replace("\r\n", "\n").split("\n") if ln != ""]
    if not lines:
        return []
    header = lines[0].split("\t")
    out = []
    for ln in lines[1:]:
        cells = ln.split("\t")
        d = {}
        for i, col in enumerate(header):
            d[col] = cells[i] if i < len(cells) else ""
        out.append(d)
    return out


def build_announcements_json(rows):
    """공지 rows(dict 리스트: ann_id·lang·title·body·published·pin·record_status) → JSON 문자열.
    1차 콘텐츠(우리 저작)라 본문(body) 포함 — feeds/items 의 본문금지 선과 무관."""
    import json
    keys = ["ann_id", "lang", "title", "body", "published", "pin", "audience", "record_status"]
    out = [{k: r.get(k, "") for k in keys} for r in rows]
    return json.dumps(out, ensure_ascii=False, indent=1, sort_keys=True) + "\n"


def parse_announcements_json(text):
    import json
    try:
        data = json.loads(text or "[]")
        return data if isinstance(data, list) else []
    except Exception:
        return []


def build_aimodels_json(payload):
    """AI 모델 꾸러미(dict) → JSON 문자열.

    ★ **글자가 늘 같아야 한다** — `sort_keys` 로 못 박는다. 안 그러면 내용이 같은데
      sha1 이 달라져 날마다 새 파일이 올라가고(지문 이름이 쌓이고) 받는 쪽도 날마다
      표를 다시 쓴다(감사 트리거가 행마다 남는다).
    """
    import json
    return json.dumps(payload or {}, ensure_ascii=False, indent=1, sort_keys=True) + "\n"


def parse_aimodels_json(text):
    """JSON → dict. 깨졌으면 **빈 dict**(받는 쪽이 아무것도 안 쓴다)."""
    import json
    try:
        d = json.loads(text or "{}")
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


_UC_RX = None


def _uc_ok(s):
    global _UC_RX
    import re as _re
    if _UC_RX is None:
        _UC_RX = _re.compile(r'^UC[A-Za-z0-9_-]{22}$')
    return bool(_UC_RX.match(s or ''))


def build_app_channels_txt(ids):
    """채널 번호들 → 글(정렬 · 겹침 없음 · 꼴이 아니면 버림). 글자가 늘 같아야 지문이 안 흔들린다."""
    return ''.join(x + '\n' for x in sorted({str(i).strip() for i in (ids or []) if _uc_ok(str(i).strip())}))


def parse_app_channels_txt(text):
    """글 → 채널 번호 집합(꼴이 아닌 줄은 버린다 — 이상한 자료가 표에 못 들어간다)."""
    return {ln.strip() for ln in (text or '').replace('\r\n', '\n').split('\n') if _uc_ok(ln.strip())}


def versioned_name(file_name, sha1):
    """논리 이름 + 내용 지문 → 실제로 올릴 이름.

        youtube_KO.tsv  +  a1b2c3d4…  →  youtube_KO.a1b2c3d4.tsv

    ★ **내용 주소다** — 같은 내용이면 같은 이름(캐시 적중), 바뀌면 처음 보는
      이름(CDN 에 옛것이 있을 수 없다).
    ⚠ 지문이 없으면 **논리 이름 그대로** 돌려준다(조용히 이상한 이름을
      만들지 않는다).
    """
    h = (sha1 or '')[:VER_HEX]
    if not h:
        return file_name
    base, dot, ext = str(file_name or '').rpartition('.')
    if not dot:
        return '%s.%s' % (file_name, h)
    return '%s.%s.%s' % (base, h, ext)


def looks_versioned(name):
    """그 이름이 **지문 이름**인가 — `xxx.<8자 16진>.tsv` 꼴.

    ★ purge 를 가르는 데 쓴다 — 지문 이름은 처음 보는 주소라 CDN 에 캐시가
      있을 수 없으므로 **지울 것이 없다**.
    """
    import re as _re
    return bool(_re.search(r'\.[0-9a-f]{%d}(\.[^.]+)?$' % VER_HEX,
                           str(name or '')))


def entry_path(entry):
    """manifest 행 → **실제로 받을 파일 이름**. 여기가 단일 소스다.

    ⚠ 옛 발행분에는 `path` 가 없다 — 그때는 논리 이름으로 떨어진다.
    """
    e = entry or {}
    return (e.get('path') or '').strip() or e.get('file', '')


def make_manifest_entry(file_name, content_text, published_at, row_count):
    """파일 1개에 대한 manifest 행 생성(sha1·내용 주소 이름 자동)."""
    sha = sha1_text(content_text)
    return {
        "file": file_name,
        "published_at": published_at,
        "row_count": str(row_count),
        "content_sha1": sha,
        "format_version": FORMAT_VERSION,
        "path": versioned_name(file_name, sha),
    }


# ── 자가 검증 ────────────────────────────────────────────────────────
def selftest():
    """`python rss_registry.py --selftest`"""
    ok, bad = [0], []

    def chk(n, cond, extra=''):
        if cond:
            ok[0] += 1
        else:
            bad.append(n)
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', n, extra))

    # ⓐ 이름 짓기
    chk('지문이 이름에 들어간다',
        versioned_name('youtube_KO.tsv', 'a1b2c3d4ffff') ==
        'youtube_KO.a1b2c3d4.tsv',
        versioned_name('youtube_KO.tsv', 'a1b2c3d4ffff'))
    chk('확장자가 없어도 짓는다',
        versioned_name('feeds', 'a1b2c3d4ffff') == 'feeds.a1b2c3d4',
        versioned_name('feeds', 'a1b2c3d4ffff'))
    chk('점이 여럿이면 **마지막** 확장자 앞에',
        versioned_name('a.b.tsv', 'deadbeef00') == 'a.b.deadbeef.tsv',
        versioned_name('a.b.tsv', 'deadbeef00'))
    chk('⚠ 지문이 없으면 논리 이름 그대로',
        versioned_name('youtube_KO.tsv', '') == 'youtube_KO.tsv')

    # ⓑ manifest 행
    e1 = make_manifest_entry('youtube_KO.tsv', 'a\tb\n', '2026-09-18', 1)
    e2 = make_manifest_entry('youtube_KO.tsv', 'a\tb\n', '2026-09-19', 1)
    e3 = make_manifest_entry('youtube_KO.tsv', 'a\tc\n', '2026-09-19', 1)
    chk('논리 이름은 안 바뀐다', e1['file'] == 'youtube_KO.tsv')
    chk('★ 내용이 같으면 이름도 같다(캐시 적중)', e1['path'] == e2['path'],
        (e1['path'], e2['path']))
    chk('★★ 내용이 바뀌면 이름이 바뀐다(stale 불가)',
        e1['path'] != e3['path'], (e1['path'], e3['path']))
    chk('지문이 sha1 앞 %d자' % VER_HEX,
        e1['path'] == 'youtube_KO.%s.tsv' % e1['content_sha1'][:VER_HEX])

    # ⓒ 읽는 문
    chk('entry_path 가 path 를 쓴다', entry_path(e1) == e1['path'])
    chk('⚠ 옛 발행분(path 없음)은 논리 이름으로',
        entry_path({'file': 'youtube_KO.tsv'}) == 'youtube_KO.tsv')
    chk('path 가 빈 글자여도 논리 이름으로',
        entry_path({'file': 'x.tsv', 'path': '  '}) == 'x.tsv')

    # ⓓ 왕복 — 칸을 더해도 읽힌다
    txt = build_manifest_tsv([e1, e3])
    back = {e['file']: e for e in parse_manifest_tsv(txt)}
    chk('왕복해도 path 가 산다',
        entry_path(back['youtube_KO.tsv']) == e3['path'],
        entry_path(back['youtube_KO.tsv']))
    chk('머리줄에 path 가 있다', 'path' in txt.split('\n')[0])

    # ⓔ ★★ **옛 앱이 안 깨진다** — path 칸이 없던 꼴로 읽어 본다
    old_cols = [c for c in MANIFEST_COLUMNS if c != 'path']
    old_txt = ('\t'.join(old_cols) + '\n'
               + '\t'.join(str(e1.get(c, '')) for c in old_cols) + '\n')
    ob = parse_manifest_tsv(old_txt)
    chk('★ 옛 manifest 를 읽으면 논리 이름으로 떨어진다',
        len(ob) == 1 and entry_path(ob[0]) == 'youtube_KO.tsv',
        ob[:1])
    chk('옛 manifest 에서도 sha1 은 산다',
        ob[0]['content_sha1'] == e1['content_sha1'])

    # ⓕ 새 manifest 를 **옛 앱처럼** 읽어도 논리 이름을 찾는다
    chk('새 manifest 에서 옛 앱이 file 로 찾는다',
        'youtube_KO.tsv' in {e['file'] for e in parse_manifest_tsv(txt)})

    chk('지문 이름을 알아본다',
        looks_versioned('youtube_KO.a1b2c3d4.tsv')
        and not looks_versioned('youtube_KO.tsv')
        and not looks_versioned('manifest.tsv'))
    chk('확장자 없는 지문도 알아본다', looks_versioned('feeds.a1b2c3d4'))
    chk('⚠ 16진이 아니면 지문이 아니다',
        not looks_versioned('youtube_KO.zzzzzzzz.tsv'))

    # ⓖ AI 모델 목록 — 글자가 늘 같아야 지문이 안 흔들린다
    _p1 = {'version': 3, 'updated': 'x', 'providers': {'GEMINI': {'models': ['b', 'a']}}}
    _p2 = {'providers': {'GEMINI': {'models': ['b', 'a']}}, 'updated': 'x', 'version': 3}
    chk('AI 목록 — 칸 차례가 달라도 같은 글자(지문이 안 흔들린다)',
        build_aimodels_json(_p1) == build_aimodels_json(_p2))
    chk('AI 목록 왕복', parse_aimodels_json(build_aimodels_json(_p1)) == _p1)
    chk('AI 목록 — 깨졌으면 빈 dict(아무것도 안 쓴다)',
        parse_aimodels_json('{{{') == {} and parse_aimodels_json('[1,2]') == {})
    chk('AI 목록 파일 이름', AIMODELS_FILE.endswith('.json') and 'ai_model' in AIMODELS_FILE)
    print('rss_registry selftest %d/%d' % (ok[0], ok[0] + len(bad)))
    for n in bad:
        print('  X', n)
    return not bad


if __name__ == '__main__':
    import sys as _sys
    if '--selftest' in _sys.argv:
        _sys.exit(0 if selftest() else 1)
    print(__doc__ or 'rss_registry')
