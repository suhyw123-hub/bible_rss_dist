"""
manual_widget.py
----------------
매뉴얼 아이콘 + 팝업 공통 위젯.

사용:
    from manual_widget import attach_manual_icon, ManualRegistry

    icon = attach_manual_icon(parent, 'U_P1_T1', icon_key='MAIN',
                                lang_provider=lambda: self.lang)
    icon.pack(side='right', padx=4)

기능:
  - 아이콘 = 네모 안에 `M` 한 글자
  - 클릭 → ManualPopup (번호 M203 은 그 팝업 제목에 나온다)
  ⚠ **호버 쪽지는 없다** — 2026-08-23 사용자 지시로 걷었다(아래 `__init__` 주석).
  - 단축키 토글 (Ctrl+H) → 아이콘 옆에 코드 라벨 표시/숨김

ManualRegistry:
  생성된 모든 매뉴얼 아이콘 추적 → 단축키 토글 시 일괄 처리.
"""

import os
import i18n
import sqlite3
import appdb
import tkinter as tk
from tkinter import ttk, messagebox

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')


class ManualRegistry:
    """모든 매뉴얼 아이콘을 등록 → 단축키 토글 일괄 적용."""
    _icons: list = []
    _show_codes: bool = False

    @classmethod
    def register(cls, icon):
        cls._icons.append(icon)

    @classmethod
    def unregister(cls, icon):
        try:
            cls._icons.remove(icon)
        except ValueError:
            pass

    @classmethod
    def toggle_codes(cls):
        cls._show_codes = not cls._show_codes
        # destroyed 아이콘 정리
        cls._icons = [i for i in cls._icons if cls._is_alive(i)]
        for ic in cls._icons:
            try:
                ic._update_code_label()
            except Exception:
                pass

    @classmethod
    def is_showing_codes(cls):
        return cls._show_codes

    @classmethod
    def _is_alive(cls, widget):
        try:
            return widget.winfo_exists()
        except Exception:
            return False


class ManualIcon(tk.Frame):
    """매뉴얼 아이콘 + 코드 라벨 (토글 시 표시)."""

    def __init__(self, parent, screen_code, icon_key='MAIN',
                  lang_provider=None, db_path=None, **kwargs):
        super().__init__(parent, **kwargs)
        self.screen_code = screen_code
        self.icon_key = icon_key
        self.lang_provider = lang_provider or (lambda: 'KO')
        self.db_path = db_path or DB

        # ★★ **네모 안에 `M` 한 글자** (2026-08-22 사용자 확정).
        #   그전에는 `ⓜ` 였는데 **글꼴을 `Arial` 로 박아 두었고 Arial 에는 그
        #   글자가 없다**(cmap 실측). 그래서 그 글자만 다른 글꼴로 대체돼
        #   크기·기준선이 옆 글자와 어긋났다 — 「동그라미가 어색하다」의 정체.
        #   ⚠ 네모 M(`🄼`·`🅼`)도 **맑은 고딕·굴림 둘 다 없다**(실측). 글자로는
        #     답이 없다 ⇒ **테두리는 Tk 가 그리는 선**으로. 어디서나 같다.
        #   ⚠ 글꼴을 적지 않는다(§36) — 통합 폰트를 그대로 따른다.
        #   번호(M203)는 **누를 때 팝업 제목**에 나온다(사용자 지시) —
        #   배지에 적으면 화면마다 네 글자가 늘어서 어수선하다.
        self._icon_lbl = tk.Label(self, text='M', width=2,
                                    relief='solid', bd=1,
                                    cursor='question_arrow')
        self._icon_lbl.pack(side='left', pady=1)
        try:
            import theme_font
            theme_font.register(self._icon_lbl, self.db_path, 'ui', size_delta=-1)
        except Exception:
            pass
        self._icon_lbl.bind('<Button-1>', lambda e: self._open_popup())
        # ★★ **호버 쪽지를 없앴다** (2026-08-23 사용자 「M버튼에 마우스를 올리면
        #   클릭하지 않아도 라벨이 표시된다. 라벨을 제거하자. 자주 사용하다보면
        #   알게 될 것이다」).
        #   ⚠ 이 쪽지는 `overrideredirect` 창이라 **`ui_theme.paint` 가 영영 못
        #     닿았고**, 그래서 박아 둔 크림색(`#FFF8DC`)이 검정 테마에서 그대로
        #     떴다. 색을 고치는 대신 **없애는 것이 사용자 결정**이다 — 단추가
        #     `M` 한 글자뿐이라 누르면 무엇인지 바로 알 수 있다.
        #   ⏭ 되살릴 일이 있으면 색을 `ui_theme.C()` 로 **그릴 때마다** 읽을 것.

        # 번호 라벨 — Ctrl+H 로 켤 때만 보인다.
        # ⚠ 글꼴을 박지 않는다(§36). 한 단계 작게만 — `size_delta`.
        # ★ 코드가 아니라 **번호**(M801)를 보인다(2026-08-22) — 이제 사람이
        #   화면을 부르는 이름이 번호다.
        self._code_lbl = tk.Label(self, text='')

        try:
            import theme_font
            theme_font.register(self._code_lbl, self.db_path, 'ui', size_delta=-2)
        except Exception:
            pass

        ManualRegistry.register(self)
        self._update_code_label()
        self.bind('<Destroy>', lambda e: ManualRegistry.unregister(self))


    def set_screen_code(self, screen_code, icon_key='MAIN'):
        """가리키는 화면을 바꾼다 (2026-08-12).

        한 자리에서 두 화면을 오갈 때 쓴다 — P4 「구절 연결」의 캔버스/트리뷰가 그렇다.
        ⚠ **매뉴얼 내용을 합치는 것이 아니다**(사용자 지시). 아이콘만 하나이고
          여는 글은 화면마다 따로다(`U_P4_T1` / `U_P4_T2`).
        제목·본문은 누를 때·hover 할 때 그때그때 읽으므로 코드만 갈아 두면 된다.
        """
        self.screen_code = screen_code
        self.icon_key = icon_key
        self._sync_code_label()

    def _sync_code_label(self):
        """번호 라벨 글자 — 보일 때만 읽는다(DB 조회가 붙어 있다)."""
        try:
            self._code_lbl.config(text=' ' + self.manual_no())
        except Exception:
            pass

    def _update_code_label(self):
        if ManualRegistry.is_showing_codes():
            self._sync_code_label()
            if not self._code_lbl.winfo_ismapped():
                self._code_lbl.pack(side='left')
        else:
            if self._code_lbl.winfo_ismapped():
                self._code_lbl.pack_forget()

    def manual_no(self):
        """`M203` 꼴 이름표. 번호가 없으면 화면 코드를 그대로 (2026-08-22)."""
        try:
            import db_manual
            with appdb.connect(self.db_path) as c:
                return db_manual.label_of(c, self.screen_code)
        except Exception:
            return str(self.screen_code)

    def _fetch_title(self):
        lang = (self.lang_provider() or 'KO').upper()
        try:
            with appdb.connect(self.db_path) as c:
                # 사용자 lang → EN 폴백
                row = c.execute(
                    "SELECT COALESCE(u.title, s.title) "
                    "  FROM sys_manual_asset_v2 s "
                    "  LEFT JOIN user_manual_asset_v2 u "
                    "    ON u.origin_id=s.manual_id "
                    "   AND UPPER(u.lang_code)=UPPER(s.lang_code) "
                    "   AND COALESCE(u.record_status,'EDIT')='EDIT' "
                    " WHERE s.screen_code=? AND s.icon_key=? "
                    "   AND s.record_status='LIVE' "
                    "   AND UPPER(s.lang_code) IN (?, 'EN') "
                    " ORDER BY CASE UPPER(s.lang_code) "
                    "                  WHEN ? THEN 0 ELSE 1 END LIMIT 1",
                    (self.screen_code, self.icon_key, lang, lang)).fetchone()
                return row[0] if row else None
        except Exception:
            return None

    def _open_popup(self):
        try:
            from manual_popup import ManualPopup
            ManualPopup(self, self.screen_code, self.icon_key,
                          self.lang_provider, self.db_path)
        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), f'Manual popup error: {e}')


def attach_manual_icon(parent, screen_code, icon_key='MAIN',
                        lang_provider=None, db_path=None):
    """매뉴얼 아이콘 ManualIcon Frame 생성 (pack/grid는 호출자가)."""
    return ManualIcon(parent, screen_code, icon_key=icon_key,
                       lang_provider=lang_provider, db_path=db_path,
                       bg=parent.cget('bg') if 'bg' in parent.keys() else '#FFFFFF')


def bind_toggle_hotkey(root, hotkey='<Control-h>'):
    """루트 윈도우에 단축키 바인딩 — 모든 ManualIcon의 코드 라벨 토글."""
    root.bind_all(hotkey, lambda e: ManualRegistry.toggle_codes())
