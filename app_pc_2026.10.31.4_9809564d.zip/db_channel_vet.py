# -*- coding: utf-8 -*-
"""**채널 등록 심사** — 그 채널이 정말 우리가 담을 채널인가.

★★★ **왜 필요한가**(2026-09-12 실측) — 「수집한 영상 1편이 승인됐다」만으로
  채널을 등록하자 **기타 교습소·색소폰·바이올린 채널**(소만마을기타교습소 ·
  김철희색소폰TV · 바이올린 장한샘)과 **세속 음악 믹스**(DJ 38K · Greatest
  Hits Music Only Mix)가 함께 들어왔다. 한 편이 우연히 걸린 것이다.
★★★ **RSS 는 쿼터 0 이다** — 그래서 이 잣대는 **몇 번이고 다시 걸 수 있다**.
  검색(100 units)·`videos.list`(50개당 1) 어느 것과도 값이 다르다.

⚠⚠⚠ **성경 낱말 하나로 재면 찬양 채널이 통째로 떨어진다** — 첫 판이 그랬다.
  실측 WEAK 469곳 안에 **Passion · CeCe Winans · Upperroom Worship ·
  제주열방대학 Worship** 이 들어 있었다. 찬양 제목은 **곡 이름**이라 성경
  낱말이 없다(§233차 「갈래어를 탐지에 쓰지 말 것」의 뒤집힌 자리).
  ⇒ 신호를 **넷으로 나눈다** — 좌표 · 분류 낱말 · **곡 이름** · **사역자 이름**.
⚠ **제목만 본다** — RSS 는 설명문을 거의 안 준다. 그래서 문턱을 낮게 잡는다
  (§0-1 — 모르면 안 자른다).
⚠ **채널을 지우지 않는다** — `enabled=0` 으로 **수집만 멈춘다**. 지우면 다음
  발굴이 같은 채널을 다시 올린다(§222차 삭제 보관함과 같은 자리).

씀: `--selftest` · `--scan [--only-new] [--limit N]` · `--apply` · `--undo`
    · `--card <채널ext id>`(한 채널의 심사 카드)
    · `--cards [--apply]`(등록 채널 전수 심사 — 규모·수집분까지 본다)
"""
import json
import re
import sys
import threading
import time
import urllib.request

import appdb
import media_exclude as ME
import media_taxonomy as MT

FEED = 'https://www.youtube.com/feeds/videos.xml?channel_id=%s'
#: 표식 — 되돌릴 수 있게 남긴다
NOTE = 'CHAN_VET'
#: **문턱** — 최근 제목 가운데 신호가 이만큼은 있어야 한다.
PASS_RATE = 0.20
#: 받은 편 수가 이보다 적으면 **판정하지 않는다**(재료가 모자란다)
MIN_N = 5
#: 이름이 이보다 짧으면 제목 대조에 안 쓴다 — 짧은 이름은 딴 말을 먹는다
NAME_MIN = 4
#: ⚠⚠⚠ **RSS 는 쿼터 0 이지만 무한하지 않다**(2026-09-12 실측으로 당했다) —
#:   1,799곳을 **8스레드 무휴식**(≈16 req/s)으로 두 번 훑자 같은 채널 id 가
#:   **404·500** 을 쏟아냈다. 30분 전에는 되던 것이다.
#:   ⇒ 실 하나당 한 번 받고 **쉰다**. 실 4 × 1초면 4 req/s.
WORKERS = 4
GAP = 1.0
#: 잇달아 이만큼 실패하면 한 번 물러선다
BACKOFF_AFTER = 5
BACKOFF_SEC = 30
#: 신호 갈래 이름
SIGNALS = {'VERSE': '성경 좌표', 'KW': '성경·설교 낱말',
           'SONG': '곡 이름', 'ARTIST': '사역자 이름', 'SERVICE': '예배·기도회'}
#: ★★★ **예배 이름** — 한국 교회 영상 제목의 대부분이 이것이다.
#:   ⚠⚠ 이 말들은 **오프토픽 낱말로만 등록돼 있다**(§241차 ⑨ — 구절 수집에서는
#:     설교 실황을 거르는 말이다). 그래서 분류 낱말로 재면 **혜성교회 ·
#:     은혜샘물교회 · Gordon-Conwell 이 통째로 떨어졌다**(실측).
#:   ★ 같은 낱말이 **거르는 자리에서는 「아니다」, 채널을 보는 자리에서는
#:     「맞다」** — 쓰는 자리가 다르면 뜻이 뒤집힌다(§237차 ⓪ 그 원리).
SERVICE_WORDS = (
    '주일예배', '새벽기도', '수요예배', '금요기도', '철야', '주일설교', '예배실황',
    '온라인예배', '주일2부', '주일1부', '대예배', '청년예배', '학생예배', '기도회',
    'sunday service', 'sunday worship', 'worship service', 'chapel',
    'prayer meeting', 'morning prayer', 'bible study', 'sermon',
    'culto', 'gottesdienst', 'богослужение', 'قداس', '主日崇拜', '礼拝',
)
#: 심사 등급
GRADES = {'GOOD': '등록 권함', 'FAIR': '볼 만함',
          'WEAK': '권하지 않음', 'UNKNOWN': '판단 못 함'}
#: ★★★ **이름이 스스로 말하는 채널** — 제목이 안 걸려도 채널이다.
#:   실측 「김형길 목사 설교 방송」·「한국개혁주의 설교연구원」·「복음의 향기」가
#:   제목만 보면 신호 0 이었다. **이름을 안 보면 그런 채널을 통째로 잃는다.**
#:   ⚠ 여기에 홑낱말을 넣을 때는 **그 말이 딴 뜻으로 쓰이는지** 먼저 잰다
#:     (§228차 홑낱말 함정) — 「성경」·「찬양」은 딴 뜻이 없고, 「믿음」·「사랑」은
#:     있어서 안 넣었다.
NAME_WORDS = (
    '교회', '성당', '목사', '전도사', '설교', '말씀', '성경', '복음', '선교',
    '찬양', '찬송', '기도', '예배', '신학', '큐티', '묵상', '사역', '제자훈련',
    'church', 'chapel', 'parish', 'cathedral', 'ministry', 'ministries',
    'pastor', 'preach', 'sermon', 'gospel', 'bible', 'scripture', 'worship',
    'seminary', 'theolog', 'devotional', 'psalm', 'christ', 'jesus',
    'iglesia', 'igreja', 'église', 'eglise', 'kirche', 'gemeinde',
    'evangel', 'mission', 'проповед', 'церковь', 'библия', 'христ',
    # ⚠ 아랍어를 빠뜨려 **「يسوع المسيح」(예수 그리스도) 채널이 통째로 떨어졌다**
    #   (실측 14곳). 이름이 곧 「예수 그리스도」인데 못 알아봤다.
    'كنيسة', 'الكتاب', 'يسوع', 'المسيح', 'مسيحي', 'انجيل', 'إنجيل', 'صلاة',
    'biblia', 'cristian', 'cristão', 'predica', 'pregação', 'alabanza',
    'louvor', 'palabra de dios', 'evangelho', 'adoración',
    '教会', '教會', '敎會', '聖書', '圣经', '聖經', '福音', '牧師', '牧师',
    '讚美', '赞美', '礼拝', '賛美',
)
#: **우리가 이미 승인한 편수** — 이만큼이면 그 자체가 신호다.
#:   ⚠ 실측 Millstone TV 는 **승인 24편**인데 제목에 성경 낱말이 없어 잘릴
#:     뻔했다. 승인은 이미 사람·자동이 한 번 판단한 것이라 **가장 믿을 만한
#:     신호**인데 제목 신호가 없으면 안 보고 있었다.
MINE_OK = 3


def name_signal(name):
    """채널 **이름**이 스스로 기독교 채널이라고 말하는가 → 걸린 낱말 | None."""
    low = (name or '').lower()
    for w in NAME_WORDS:
        if w in low:
            return w
    return None


def ensure(conn):
    """비고 칸 — 멱등 ALTER. 심사 자국을 여기에 적는다."""
    cols = {r[1] for r in conn.execute("PRAGMA table_info(sys_media_channel)")}
    if 'note' not in cols:
        conn.execute("ALTER TABLE sys_media_channel ADD COLUMN note TEXT")
        conn.commit()


def _unescape(s):
    import html
    return html.unescape(s or '').strip()


def feed_titles(cid, timeout=20):
    """그 채널의 최근 제목들 → list. 못 받으면 None(빈 목록과 다르다)."""
    try:
        req = urllib.request.Request(
            FEED % cid, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read().decode('utf-8', 'replace')
    except Exception:
        return None
    out = []
    for m in re.finditer(r'<entry>(.*?)</entry>', body, re.S):
        t = re.search(r'<title>(.*?)</title>', m.group(1), re.S)
        if t:
            out.append(_unescape(t.group(1)))
    return out


def name_index(conn):
    """제목 대조에 쓸 **곡·사역자 이름** → {'SONG': [...], 'ARTIST': [...]}.

    ⚠ **짧은 이름을 뺀다**(`NAME_MIN`) — 「피」·「빛」이 아무 제목에나 걸린다
      (§228차 홑낱말 함정과 같은 자리).
    ⚠ 한 번 읽어 두고 돌려 쓴다 — 채널마다 다시 읽으면 조회가 1,800배 된다.
    """
    out = {'SONG': set(), 'ARTIST': set()}
    try:
        for _sid, nm in conn.execute(
                "SELECT s.song_id, t.contents FROM sys_song s"
                "  JOIN sys_text_asset t ON t.clicked_id=s.song_id"
                "   AND t.text_type IN ('SONG_TITLE','SONG_ALIAS')"
                "   AND t.record_status='LIVE'"
                " WHERE s.record_status='LIVE'"):
            for one in re.split(r'[·/|]', nm or ''):
                one = one.strip()
                if len(one) >= NAME_MIN:
                    out['SONG'].add(one.lower())
    except Exception:
        pass
    try:
        for nm, in conn.execute(
                "SELECT t.contents FROM sys_worship_artist a"
                "  JOIN sys_text_asset t ON t.clicked_id=a.artist_id"
                "   AND t.text_type='ARTIST_NAME' AND t.record_status='LIVE'"
                " WHERE a.record_status='LIVE'"):
            for one in re.split(r'[·/|]', nm or ''):
                one = one.strip()
                if len(one) >= NAME_MIN:
                    out['ARTIST'].add(one.lower())
    except Exception:
        pass
    return {k: sorted(v, key=len, reverse=True) for k, v in out.items()}


def signal(conn, title, lang, sets, names=None):
    """그 제목이 무엇으로 걸리나 → 'VERSE'|'KW'|'SERVICE'|'SONG'|'ARTIST'|None."""
    try:
        import db_media_range as MR
        if MR.read(conn, title):
            return 'VERSE'
    except Exception:
        pass
    low = (title or '').lower()
    for cat in MT.CONTENT_KW_CATS:
        for k in MT.kw_for_lang(sets.get(cat, {}), lang):
            if k and k.lower() in low:
                return 'KW'
    for w in SERVICE_WORDS:
        if w in low:
            return 'SERVICE'
    if names:
        for kind in ('SONG', 'ARTIST'):
            for nm in names.get(kind, ()):
                if nm in low:
                    return kind
    return None


def score(conn, cid, lang, sets, names=None, titles=None):
    """한 채널의 RSS 점수 → dict(n, hit, rate, by, titles). 못 받으면 n=-1."""
    ts = feed_titles(cid) if titles is None else titles
    if ts is None:
        return {'n': -1, 'hit': 0, 'rate': 0.0, 'by': {}, 'titles': []}
    by = {}
    hit = 0
    for t in ts:
        s = signal(conn, t, lang, sets, names)
        if s:
            hit += 1
            by[s] = by.get(s, 0) + 1
    return {'n': len(ts), 'hit': hit, 'by': by,
            'rate': (hit / len(ts)) if ts else 0.0, 'titles': ts[:4]}


def verdict(s):
    """RSS 판정 → 'OK' | 'WEAK' | 'UNKNOWN'."""
    if s['n'] < 0 or s['n'] < MIN_N:
        return 'UNKNOWN'          # 못 받았거나 재료가 모자란다 — 안 자른다
    return 'OK' if s['rate'] >= PASS_RATE else 'WEAK'


# ── 심사 카드 ────────────────────────────────────────────────────────────
def collected(conn, cid):
    """우리가 **이미 담은** 그 채널의 영상 → dict.

    ★ 「어떤 성격의 영상인가」를 수로 말한다 — 사용자 지시(2026-09-12).
    ⚠ 조회수는 `sys_media_check.views` 에 있다(`sys_media_asset` 이 아니다).
    """
    out = {'n': 0, 'ok': 0, 'type': {}, 'lang': {}, 'views': [], 'name': ''}
    q = ("SELECT a.media_id, COALESCE(a.media_type,''), COALESCE(a.lang_code,''),"
         "       COALESCE(a.is_active,0), COALESCE(a.description,''),"
         "       (SELECT c.views FROM sys_media_check c"
         "          WHERE c.media_id=a.media_id)"
         "  FROM sys_media_asset a WHERE a.record_status='LIVE'"
         "   AND a.description LIKE ?")
    for _mid, mt, lang, act, desc, views in conn.execute(q, ('%' + cid + '%',)):
        try:
            j = json.loads(desc) if desc.startswith('{') else {}
        except Exception:
            j = {}
        if (j.get('channel_id') or '').strip() != cid:
            continue
        out['n'] += 1
        out['ok'] += int(act)
        out['type'][mt] = out['type'].get(mt, 0) + 1
        out['lang'][lang] = out['lang'].get(lang, 0) + 1
        if views:
            out['views'].append(int(views))
        if not out['name']:
            out['name'] = (j.get('channel') or '').strip()
    return out


def scale(conn, cid):
    """그 채널의 **규모** → dict(subs, n_video, views). 모르면 값이 None.

    ⚠ 재료는 `sys_channel_stat`(§237차 ⑯) — **없으면 지어내지 않는다**.
    """
    r = conn.execute("SELECT subs, n_video, views FROM sys_channel_stat"
                     "  WHERE channel_ext_id=?", (cid,)).fetchone()  # status-ok: 주소 하나로 제 줄을 읽는다
    if not r:
        return {'subs': None, 'n_video': None, 'views': None}
    return {'subs': r[0], 'n_video': r[1], 'views': r[2]}


def _median(xs):
    if not xs:
        return None
    xs = sorted(xs)
    return xs[len(xs) // 2]


def card(conn, cid, lang=None, sets=None, names=None, rss=True):
    """**심사 카드 하나** → dict. 화면과 도구가 같은 문을 쓴다."""
    sets = sets if sets is not None else MT.load_classify_sets(conn)
    names = names if names is not None else name_index(conn)
    col = collected(conn, cid)
    if not lang:
        lang = max(col['lang'], key=col['lang'].get) if col['lang'] else 'EN'
    s = score(conn, cid, lang, sets, names) if rss else {
        'n': -1, 'hit': 0, 'rate': 0.0, 'by': {}, 'titles': []}
    p = {'cid': cid, 'name': col['name'], 'lang': lang,
         'col': col, 'rss': s, 'scale': scale(conn, cid),
         'med_views': _median(col['views'])}
    p['grade'], p['why'] = judge(conn, p)
    return p


#: 규모 잣대 — 사용자 지시(조회수·구독자수를 함께 본다)
SUBS_GOOD = 10000
MED_VIEWS_GOOD = 1000


def judge(conn, p):
    """심사 → ('GOOD'|'FAIR'|'WEAK'|'UNKNOWN', [까닭…]).

    ★ **까닭을 함께 낸다** — 등급만 주면 사람이 다시 확인할 길이 없다(§0-1).
    ⚠ **거르는 말이 가장 세다** — 이단·타종교·세속은 규모가 커도 안 된다.
    """
    why = []
    nm = p.get('name') or ''
    lang = p.get('lang') or 'EN'
    try:
        hit = ME.match_channel(nm, kw_list=ME.get_channel_kw(conn, lang), lang=lang)
    except Exception:
        hit = None
    if hit:
        return 'WEAK', ['채널 거르는 말 「%s」' % hit]

    # ★★★ **이름이 스스로 말하면 그 자체가 신호다** — 작은 교회는 제목이
    #   「2026.9.12.」 처럼 날짜뿐일 때가 많다(실측 혜성교회·은혜샘물교회).
    nw = name_signal(nm)

    rv = verdict(p['rss'])
    s = p['rss']
    if nw:
        why.append('이름이 스스로 말한다 「%s」' % nw)
    if rv == 'OK':
        by = ' · '.join('%s %d' % (SIGNALS.get(k, k), v)
                        for k, v in sorted(s['by'].items(), key=lambda x: -x[1]))
        why.append('최근 %d편 중 %d편이 걸린다 (%s)' % (s['n'], s['hit'], by))
    elif rv == 'WEAK':
        why.append('최근 %d편 중 걸리는 것 %d편뿐' % (s['n'], s['hit']))
    else:
        why.append('최근 영상을 못 받았다')

    col = p['col']
    if col['n']:
        top = sorted(col['type'].items(), key=lambda x: -x[1])
        why.append('담은 것 %d편(승인 %d) — %s'
                   % (col['n'], col['ok'],
                      ' · '.join('%s %d' % t for t in top[:3])))
    sc = p['scale']
    if sc['subs'] is not None:
        why.append('구독 %s · 영상 %s' % (f"{sc['subs']:,}", f"{sc['n_video'] or 0:,}"))
    if p['med_views'] is not None:
        why.append('우리 수집분 조회수 중앙 %s' % f"{p['med_views']:,}")

    big = (sc['subs'] or 0) >= SUBS_GOOD or (p['med_views'] or 0) >= MED_VIEWS_GOOD
    if rv == 'OK' and (big or col['ok'] >= 3 or nw):
        return 'GOOD', why
    if rv == 'OK':
        return 'FAIR', why
    if rv == 'UNKNOWN':
        return 'UNKNOWN', why
    # ★ 이름이 말하는데 **우리가 이미 승인까지 한 것**이면 등록 권함
    if nw and col.get('ok', 0) >= 2:
        return 'GOOD', why
    # ★★★ **우리 승인분이 쌓였으면 자르지 않는다** — 이미 한 번 판단한 것이다.
    if col.get('ok', 0) >= MINE_OK:
        return 'FAIR', why
    # ⚠⚠ **RSS 가 약해도 자르지 않는 자리 둘** — 규모가 크거나, **이름이 스스로
    #   말하거나**. 셋 다 아닐 때만 권하지 않는다(모르면 안 자른다 §0-1).
    return ('FAIR' if (big or nw) else 'WEAK'), why


def card_text(p):
    """심사 카드를 사람이 읽는 글로 → str. 화면이 그대로 쓴다."""
    L = ['%s  [%s]' % (p.get('name') or p['cid'], GRADES.get(p['grade'], p['grade']))]
    for w in p['why']:
        L.append('  · ' + w)
    if p['rss'].get('titles'):
        L.append('  최근 제목')
        for t in p['rss']['titles']:
            L.append('    - ' + t[:60])
    return '\n'.join(L)


def channels(conn, only_new=False, limit=None):
    """볼 채널 목록 → [(channel_id, ext_id, name, lang)]."""
    q = ("SELECT channel_id, channel_ext_id, channel_name,"
         "       COALESCE(lang_code,'EN')"
         "  FROM sys_media_channel"
         " WHERE record_status='LIVE' AND enabled=1"
         "   AND channel_ext_id IS NOT NULL AND channel_ext_id<>''")
    if only_new:
        q += " AND (last_checked IS NULL OR last_checked='')"
    q += " ORDER BY channel_id DESC"
    rows = conn.execute(q).fetchall()
    return rows[:int(limit)] if limit else rows


def scan(conn, only_new=False, limit=None, workers=WORKERS, log=print):
    """RSS 를 받아 점수를 매긴다 → list of dict. **쿼터 0**."""
    sets = MT.load_classify_sets(conn)
    names = name_index(conn)
    rows = channels(conn, only_new, limit)
    log('  [심사] 채널 %d곳 · RSS(쿼터 0) · 곡 %d · 사역자 %d'
        % (len(rows), len(names['SONG']), len(names['ARTIST'])))
    out, lock, idx, fail = [], threading.Lock(), [0], [0]

    def work():
        c2 = appdb.connect()
        c2.execute("PRAGMA busy_timeout=60000")
        while True:
            with lock:
                i = idx[0]
                idx[0] += 1
            if i >= len(rows):
                break
            chid, cid, nm, lang = rows[i]
            s = score(c2, cid, lang, sets, names)
            s.update({'channel_id': chid, 'cid': cid, 'name': nm,
                      'lang': lang, 'verdict': verdict(s)})
            with lock:
                out.append(s)
                if s['n'] < 0:
                    fail[0] += 1
                else:
                    fail[0] = 0
                hit = fail[0] >= BACKOFF_AFTER
                if hit:
                    fail[0] = 0
                if len(out) % 200 == 0:
                    log('    %d / %d' % (len(out), len(rows)))
            if hit:
                log('    … 잇달아 막혀 %d초 쉽니다' % BACKOFF_SEC)
                time.sleep(BACKOFF_SEC)
            time.sleep(GAP)
        c2.close()

    ths = [threading.Thread(target=work, daemon=True) for _ in range(workers)]
    for t in ths:
        t.start()
    for t in ths:
        t.join()
    return out


def collected_all(conn):
    """채널마다 **우리가 담은 것** → {cid: dict}. 한 번에 읽는다.

    ⚠ 채널마다 `collected()` 를 부르면 21,000행을 채널 수만큼 훑는다 —
      1,800곳이면 조회가 1,800배다.
    """
    out = {}
    for mt, lang, act, desc, v in conn.execute(
            "SELECT COALESCE(a.media_type,''), COALESCE(a.lang_code,''),"
            "       COALESCE(a.is_active,0), COALESCE(a.description,''),"
            "       (SELECT c.views FROM sys_media_check c"
            "          WHERE c.media_id=a.media_id)"
            "  FROM sys_media_asset a WHERE a.record_status='LIVE'"):
        try:
            j = json.loads(desc) if desc.startswith('{') else {}
        except Exception:
            j = {}
        cid = (j.get('channel_id') or '').strip()
        if not cid:
            continue
        c = out.setdefault(cid, {'n': 0, 'ok': 0, 'type': {}, 'lang': {},
                                 'views': [], 'name': ''})
        c['n'] += 1
        c['ok'] += int(act)
        c['type'][mt] = c['type'].get(mt, 0) + 1
        c['lang'][lang] = c['lang'].get(lang, 0) + 1
        if v:
            c['views'].append(int(v))
        if not c['name']:
            c['name'] = (j.get('channel') or '').strip()
    return out


def cards(conn, rows=None, only_new=False, limit=None, log=print):
    """등록 채널 **전수 심사** → list of card dict. **쿼터 0**.

    `rows` 를 주면 RSS 를 다시 안 받는다(이미 받아 둔 `scan` 결과).
    """
    rows = rows if rows is not None else scan(conn, only_new, limit, log=log)
    col = collected_all(conn)
    out = []
    for r in rows:
        cid = r['cid']
        c = col.get(cid) or {'n': 0, 'ok': 0, 'type': {}, 'lang': {},
                             'views': [], 'name': r.get('name', '')}
        p = {'cid': cid, 'name': r.get('name') or c['name'],
             'lang': r.get('lang', 'EN'), 'channel_id': r.get('channel_id'),
             'col': {'n': c['n'], 'ok': c['ok'], 'type': dict(c['type']),
                     'lang': dict(c['lang'])},
             'rss': r, 'scale': scale(conn, cid),
             'med_views': _median(c['views'])}
        p['grade'], p['why'] = judge(conn, p)
        out.append(p)
    return out


def apply_weak(conn, rows, log=print):
    """`WEAK` 인 채널의 수집을 **멈춘다**(`enabled=0`) → 멈춘 수.

    ⚠ **지우지 않는다** · 표식을 남겨 `--undo` 가 되돌린다.
    """
    ensure(conn)
    n = 0
    for s in rows:
        if s.get('verdict') != 'WEAK':
            continue
        cur = conn.execute(
            "SELECT enabled, COALESCE(note,'') FROM sys_media_channel"
            "  WHERE channel_id=?", (s['channel_id'],)).fetchone()  # status-ok: 번호 하나로 제 줄을 읽는다
        if not cur or not cur[0]:
            continue
        mark = '%s:%d/%d' % (NOTE, s['hit'], s['n'])
        note = ((cur[1] + ' ') if cur[1] else '') + mark
        conn.execute("UPDATE sys_media_channel SET enabled=0, note=?"
                     "  WHERE channel_id=?", (note.strip(), s['channel_id']))
        n += 1
    conn.commit()
    log('  [심사] 수집 멈춤 %d곳' % n)
    return n


def undo(conn, log=print):
    """표식이 있는 채널을 다시 켠다 → 되돌린 수."""
    ensure(conn)
    rows = conn.execute("SELECT channel_id, note FROM sys_media_channel"
                        "  WHERE note LIKE ?",
                        ('%' + NOTE + '%',)).fetchall()  # status-ok: 되돌리기 장부 — 멈춘 채널을 찾는 자리라 상태로 거르면 되돌릴 것이 사라진다
    for chid, note in rows:
        clean = re.sub(r'\s*' + NOTE + r':\d+/\d+', '', note or '').strip()
        conn.execute("UPDATE sys_media_channel SET enabled=1, note=?"
                     "  WHERE channel_id=?", (clean or None, chid))
    conn.commit()
    log('  [심사] 되돌림 %d곳' % len(rows))
    return len(rows)


def selftest():
    import io
    import sqlite3
    ok = fail = 0

    def t(name, cond):
        nonlocal ok, fail
        if cond:
            ok += 1
        else:
            fail += 1
            print('  FAIL', name)

    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE sys_media_channel (channel_id INTEGER PRIMARY KEY,"
              " channel_ext_id TEXT, channel_name TEXT, lang_code TEXT,"
              " enabled INTEGER DEFAULT 1, last_checked TEXT,"
              " record_status TEXT DEFAULT 'LIVE')")
    for i, (cid, nm) in enumerate([('UC1', '가'), ('UC2', '나'), ('UC3', '다')], 1):
        c.execute("INSERT INTO sys_media_channel (channel_id, channel_ext_id,"
                  " channel_name, lang_code) VALUES (?,?,?,'KO')", (i, cid, nm))

    # ⓪ 비고 칸을 스스로 만든다(멱등)
    t('note 칸이 없다', 'note' not in {r[1] for r in
                                   c.execute("PRAGMA table_info(sys_media_channel)")})
    ensure(c)
    ensure(c)
    t('note 칸을 만든다(멱등)', 'note' in {r[1] for r in
                                     c.execute("PRAGMA table_info(sys_media_channel)")})

    # ① 판정 — 문턱 앞뒤
    t('문턱 위는 OK', verdict({'n': 15, 'hit': 3, 'rate': 3 / 15}) == 'OK')
    t('문턱 아래는 WEAK', verdict({'n': 15, 'hit': 2, 'rate': 2 / 15}) == 'WEAK')
    t('못 받으면 UNKNOWN', verdict({'n': -1, 'hit': 0, 'rate': 0}) == 'UNKNOWN')
    t('재료가 적으면 UNKNOWN', verdict({'n': 3, 'hit': 0, 'rate': 0}) == 'UNKNOWN')
    t('UNKNOWN 은 WEAK 가 아니다', verdict({'n': 0, 'hit': 0, 'rate': 0}) != 'WEAK')

    # ② 멈춤 · 되돌리기 왕복
    rows = [{'channel_id': 1, 'verdict': 'WEAK', 'hit': 0, 'n': 15},
            {'channel_id': 2, 'verdict': 'OK', 'hit': 9, 'n': 15},
            {'channel_id': 3, 'verdict': 'UNKNOWN', 'hit': 0, 'n': -1}]
    t('WEAK 만 멈춘다', apply_weak(c, rows, log=lambda *a: None) == 1)
    st = dict(c.execute("SELECT channel_id, enabled FROM sys_media_channel"))
    t('WEAK 이 꺼졌다', st[1] == 0)
    t('OK 는 그대로', st[2] == 1)
    t('UNKNOWN 도 그대로', st[3] == 1)
    t('표식을 남긴다', NOTE in (c.execute(
        "SELECT note FROM sys_media_channel WHERE channel_id=1").fetchone()[0] or ''))
    t('지우지 않는다', c.execute(
        "SELECT COUNT(*) FROM sys_media_channel").fetchone()[0] == 3)
    t('두 번 걸어도 한 번만(멱등)',
      apply_weak(c, rows, log=lambda *a: None) == 0)
    t('되돌린다', undo(c, log=lambda *a: None) == 1)
    t('되돌리면 다시 켜진다', dict(c.execute(
        "SELECT channel_id, enabled FROM sys_media_channel"))[1] == 1)
    c.execute("UPDATE sys_media_channel SET note='사람이 적은 말' WHERE channel_id=1")
    apply_weak(c, rows, log=lambda *a: None)
    undo(c, log=lambda *a: None)
    t('남의 비고는 남는다', c.execute(
        "SELECT note FROM sys_media_channel WHERE channel_id=1").fetchone()[0]
        == '사람이 적은 말')

    # ③ 제목 읽기
    body = ('<feed><entry><title>창세기 1장 강해</title></entry>'
            '<entry><title>Bass &amp; Tone</title></entry></feed>')
    got = []
    for m in re.finditer(r'<entry>(.*?)</entry>', body, re.S):
        mm = re.search(r'<title>(.*?)</title>', m.group(1), re.S)
        if mm:
            got.append(_unescape(mm.group(1)))
    t('제목 둘을 읽는다', len(got) == 2)
    t('HTML 기호를 푼다', got[1] == 'Bass & Tone')

    # ④ 짧은 이름은 안 쓴다
    t('짧은 이름 문턱', NAME_MIN >= 3)

    # ⑤ 신호 갈래 — 실 DB 로
    try:
        rc = appdb.connect()
        sets = MT.load_classify_sets(rc)
        names = name_index(rc)
        t('좌표는 VERSE', signal(rc, '창세기 1장 1절 강해', 'KO', sets, names) == 'VERSE')
        t('설교 낱말은 KW', signal(rc, '주일예배 설교', 'KO', sets, names) == 'KW')
        t('기타 리뷰는 안 걸린다',
          signal(rc, 'Bass Comparison Both pickups SLAP', 'EN', sets, names) is None)
        t('세속 믹스는 안 걸린다',
          signal(rc, 'BEST OF MBOSSO LATEST MIX VOL.2 - DJ 38K', 'EN', sets,
                 names) is None)
        # ★★★ 예배 이름 — 오프토픽 낱말로만 있던 자리(실측으로 잡았다)
        t('새벽기도회는 SERVICE',
          signal(rc, '새벽기도회ㅣ2026.9.12.', 'KO', sets, names) == 'SERVICE')
        t('Wednesday Chapel 은 SERVICE',
          signal(rc, 'September 9 2026 || Wednesday Chapel', 'EN', sets,
                 names) == 'SERVICE')
        # ★ 이름이 교회면 제목이 날짜뿐이어도 GOOD
        g1, _w1 = judge(rc, {'name': '혜성교회', 'lang': 'KO',
                             'rss': {'n': 15, 'hit': 0, 'rate': 0.0, 'by': {}},
                             'col': {'n': 4, 'ok': 3, 'type': {}, 'lang': {}},
                             'scale': {'subs': 100, 'n_video': 1, 'views': 1},
                             'med_views': 3})
        t('이름이 교회면 GOOD', g1 == 'GOOD')
        t('이름에 설교가 있으면 신호', name_signal('김형길 목사 설교 방송'))
        t('이름에 church 가 있으면 신호', name_signal('First Baptist Church'))
        t('기타 채널 이름은 신호 없음', name_signal('Adrian Guardia') is None)
        t('사주 채널 이름은 신호 없음', name_signal('bluerosebook') is None)
        t('아랍어 예수 그리스도는 신호', name_signal('يسوع المسيح'))
        t('스페인어 예배 이름은 신호', name_signal('Predicas y Alabanzas'))
        g4, _w4 = judge(rc, {'name': 'Millstone TV', 'lang': 'KO',
                             'rss': {'n': 15, 'hit': 1, 'rate': 1 / 15, 'by': {}},
                             'col': {'n': 24, 'ok': 24, 'type': {}, 'lang': {}},
                             'scale': {'subs': 3380, 'n_video': 1, 'views': 1},
                             'med_views': 5})
        t('승인분이 쌓였으면 안 자른다', g4 != 'WEAK')
        g3, _w3 = judge(rc, {'name': '김형길 목사 설교 방송', 'lang': 'KO',
                             'rss': {'n': 15, 'hit': 0, 'rate': 0.0, 'by': {}},
                             'col': {'n': 2, 'ok': 0, 'type': {}, 'lang': {}},
                             'scale': {'subs': 1890, 'n_video': 1, 'views': 1},
                             'med_views': 5})
        t('이름이 말하면 안 자른다', g3 != 'WEAK')
        g2, _w2 = judge(rc, {'name': 'Adrian Guardia', 'lang': 'EN',
                             'rss': {'n': 15, 'hit': 0, 'rate': 0.0, 'by': {}},
                             'col': {'n': 3, 'ok': 1, 'type': {}, 'lang': {}},
                             'scale': {'subs': 7950, 'n_video': 1, 'views': 1},
                             'med_views': 20})
        t('기타 채널은 WEAK', g2 == 'WEAK')
        t('곡·사역자 이름을 읽어 둔다',
          len(names['SONG']) > 0 and len(names['ARTIST']) > 0)
        # ★★★ **찬양 채널이 떨어지지 않는가** — 첫 판이 여기서 틀렸다
        picked = None
        for nm in names['ARTIST']:
            if len(nm) >= 6:
                picked = nm
                break
        if picked:
            t('사역자 이름이 든 제목은 걸린다',
              signal(rc, 'Live - %s (Official)' % picked, 'EN', sets,
                     names) in ('ARTIST', 'KW', 'SONG'))
        picked = None
        for nm in names['SONG']:
            if len(nm) >= 6:
                picked = nm
                break
        if picked:
            t('곡 이름이 든 제목은 걸린다',
              signal(rc, picked + ' (Lyric Video)', 'EN', sets,
                     names) in ('SONG', 'KW', 'ARTIST', 'VERSE'))
        # ⑥ 심사 카드 — 실제로 나온다
        cid = rc.execute("SELECT channel_ext_id FROM sys_media_channel"
                         " WHERE channel_ext_id IS NOT NULL AND enabled=1"
                         " LIMIT 1").fetchone()
        if cid:
            p = card(rc, cid[0], sets=sets, names=names, rss=False)
            t('카드에 등급이 있다', p['grade'] in GRADES)
            t('카드에 까닭이 있다', len(p['why']) >= 1)
            t('카드에 담은 것이 있다', 'n' in p['col'])
            t('카드에 규모 칸이 있다', 'subs' in p['scale'])
            t('카드 글이 나온다', len(card_text(p)) > 10)
            # ⚠ 모르면 지어내지 않는다
            p2 = card(rc, 'UC_NO_SUCH_CHANNEL_ZZZ', sets=sets, names=names,
                      rss=False)
            t('모르는 채널은 규모가 None', p2['scale']['subs'] is None)
            t('모르는 채널은 담은 것 0', p2['col']['n'] == 0)
        # ⑦ 거르는 말이 가장 세다
        g, w = judge(rc, {'name': '신천지 예수교회', 'lang': 'KO',
                          'rss': {'n': 15, 'hit': 15, 'rate': 1.0, 'by': {}},
                          'col': {'n': 99, 'ok': 99, 'type': {}, 'lang': {}},
                          'scale': {'subs': 999999, 'n_video': 1, 'views': 1},
                          'med_views': 99999})
        t('거르는 말이 규모를 이긴다', g == 'WEAK')
        rc.close()
    except Exception as e:
        print('  (실 DB 검사 건너뜀:', e, ')')

    # ⑧ 문 하나 — 여기서 채널을 지우는 SQL 을 쓰지 않는다
    src = io.open(__file__, encoding='utf-8').read()
    t('채널을 지우지 않는다',
      ('DELETE FROM ' + 'sys_media_channel') not in src)
    body = src.split('def selftest')[0]
    t('채널을 여기서 담지 않는다',
      ('INSERT INTO ' + 'sys_media_channel') not in body)
    # ★★★ **남의 서버를 몰아치지 않는다**(2026-09-12 실측으로 당했다)
    t('실이 넷 이하', WORKERS <= 4)
    t('한 번 받고 1초 이상 쉰다', GAP >= 1.0)
    t('막히면 물러선다', BACKOFF_AFTER >= 3 and BACKOFF_SEC >= 5)
    t('전수 심사 문이 있다', callable(cards) and callable(collected_all))

    c.close()
    print('db_channel_vet selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect()
    conn.execute("PRAGMA busy_timeout=60000")
    if '--undo' in a:
        undo(conn)
        conn.close()
        return
    if '--card' in a:
        print(card_text(card(conn, a[a.index('--card') + 1])))
        conn.close()
        return
    lim = int(a[a.index('--limit') + 1]) if '--limit' in a else None
    if '--cards' in a:
        ps = cards(conn, only_new='--only-new' in a, limit=lim)
        cnt = {}
        for p in ps:
            cnt[p['grade']] = cnt.get(p['grade'], 0) + 1
        print()
        print('  등록 채널 %d곳 심사' % len(ps))
        for g in ('GOOD', 'FAIR', 'WEAK', 'UNKNOWN'):
            if cnt.get(g):
                print('   %-8s %s  %d곳' % (g, GRADES[g], cnt[g]))
        weak = sorted((p for p in ps if p['grade'] == 'WEAK'),
                      key=lambda p: -(p['scale']['subs'] or 0))
        print()
        print('  ── %s %d곳' % (GRADES['WEAK'], len(weak)))
        for p in weak[:30]:
            print('   구독 %9s 승인%3d  %-28s | %s'
                  % ('{:,}'.format(p['scale']['subs'] or 0), p['col']['ok'],
                     (p['name'] or '')[:28],
                     (p['rss']['titles'][0] if p['rss']['titles'] else '')[:34]))
        json.dump(ps, open('_chan_cards.json', 'w', encoding='utf-8'),
                  ensure_ascii=False)
        if '--apply' in a:
            apply_weak(conn, [{'channel_id': p['channel_id'], 'verdict': 'WEAK',
                               'hit': p['rss']['hit'], 'n': max(p['rss']['n'], 0)}
                              for p in ps if p['grade'] == 'WEAK'])
        conn.close()
        return
    rows = scan(conn, only_new='--only-new' in a, limit=lim)
    cnt = {}
    for s in rows:
        cnt[s['verdict']] = cnt.get(s['verdict'], 0) + 1
    print('  판정 —', ' · '.join('%s %d' % kv for kv in sorted(cnt.items())))
    weak = sorted((s for s in rows if s['verdict'] == 'WEAK'),
                  key=lambda s: s['rate'])
    for s in weak[:30]:
        print('   WEAK %2d/%2d %-30s | %s'
              % (s['hit'], s['n'], s['name'][:30],
                 (s['titles'][0] if s['titles'] else '')[:40]))
    json.dump(rows, open('_chan_vet.json', 'w', encoding='utf-8'),
              ensure_ascii=False)
    if '--apply' in a:
        apply_weak(conn, rows)
    conn.close()


if __name__ == '__main__':
    main()
