# -*- coding: utf-8 -*-
"""통합 표 감시기 — 옛 표를 걷어도 되는지 며칠 지켜본 뒤 판정한다 (2026-08-25).

사용자 확정 절차 —
  「테스트 도구를 만들면 앞으로 며칠간 추가·수정 작업을 하면서 히스토리를
    저장해두었다가 일시에 점검해서 제대로 작동하는지를 검사한다」

★ **무엇을 지켜보나** (네 가지)
  ① **옛 표가 얼어 있는가** — 지문(내용 해시)이 기준선과 같아야 한다.
     한 글자라도 바뀌면 **어딘가가 아직 옛 표에 쓰고 있다**는 뜻이다.
  ② **옮긴 행이 통합 표에 살아 있는가** — `sys_linkmig_log` 가 「옛 몇 번이
     새 몇 번이 됐나」를 갖고 있다. 그 새 번호가 실제로 있는지 하나씩 확인한다.
     사라졌으면 **이전한 것을 잃은 것**이다.
  ③ **설명문 닻이 살아 있는가** — `sys_linkmig_desc`(1,746편).
  ④ **그동안 무슨 일이 있었나** — 감사 로그(§10-1)로 추가·수정·삭제를 센다.
     ⇒ **새로 생긴 것은 정상**이다. 우리가 보는 것은 「없어진 것」이다.

⚠ **옛 표와 통합 표의 행 수가 벌어지는 것은 정상이다.** 옛 표는 얼어 있고
  통합 표만 자란다. 그래서 「수를 맞춘다」로 재면 안 되고 **옮긴 행이 남아
  있는가**로 재야 한다(②).

⚠ **감사 로그가 꺼져 있으면 ④를 못 잰다.** `db_audit_triggers --status` 로
  확인한다. 이 도구는 꺼져 있으면 **그렇다고 말한다**(조용히 0건으로 넘기지 않는다).

사용:
    python db_link_watch.py --selftest      (의무)
    python db_link_watch.py --snap "이전 직후 기준선"
    …며칠 작업…
    python db_link_watch.py --check
    python db_link_watch.py --history
"""
import hashlib
import sys
import appdb
import db_link_migrate as M

SNAP = 'sys_linkwatch'
UNIFIED = (('main', 'sys_link_asset', 'sys_link_id'),
           ('userdb', 'user_link_asset', 'user_link_id'))


def _ensure(conn):
    conn.execute(
        'CREATE TABLE IF NOT EXISTS %s ('
        ' snap_id INTEGER PRIMARY KEY AUTOINCREMENT,'
        ' taken_at TEXT, note TEXT, tbl TEXT, n INTEGER, fp TEXT)' % SNAP)
    conn.execute('CREATE INDEX IF NOT EXISTS ix_linkwatch ON %s(tbl, snap_id)'
                 % SNAP)


def fingerprint(conn, sch, tbl, pk):
    """그 표의 내용 지문. **행 수만으로는 못 잡는다** — 값을 고쳐도 수는 같다."""
    h = hashlib.md5()
    n = 0
    for row in conn.execute('SELECT * FROM %s.%s ORDER BY %s'
                            % (sch, tbl, pk)):
        h.update(repr(row).encode('utf-8', 'replace'))
        n += 1
    return n, h.hexdigest()


def _old_tables():
    return [(M.BY_KEY[k].sch, k, M.BY_KEY[k].pk) for k in sorted(M.BY_KEY)]


def snap(conn, note=''):
    _ensure(conn)
    rows = []
    for sch, tbl, pk in _old_tables():
        n, fp = fingerprint(conn, sch, tbl, pk)
        rows.append((note, tbl, n, fp))
    for sch, tbl, pk in UNIFIED:
        n = conn.execute('SELECT COUNT(*) FROM %s.%s' % (sch, tbl)).fetchone()[0]
        rows.append((note, tbl, n, ''))          # 통합 표는 자라므로 지문 안 쓴다
    conn.executemany(
        "INSERT INTO %s (taken_at, note, tbl, n, fp) "
        "VALUES (datetime('now','localtime'),?,?,?,?)" % SNAP, rows)
    conn.commit()
    print('기준선 저장 — 표 %d개 (메모: %s)' % (len(rows), note or '없음'))
    return len(rows)


def _baseline(conn):
    """가장 처음 스냅샷(표별)."""
    out = {}
    try:
        for tbl, n, fp, at in conn.execute(
                'SELECT tbl, n, fp, taken_at FROM %s '
                'WHERE snap_id IN (SELECT MIN(snap_id) FROM %s GROUP BY tbl)'
                % (SNAP, SNAP)):
            out[tbl] = (n, fp, at)
    except Exception:
        pass
    return out


def check(conn, quiet=False):
    """→ (문제 목록, 요약 dict). 문제가 비면 걷어도 된다."""
    _ensure(conn)
    bad = []
    base = _baseline(conn)
    p = (lambda *a: None) if quiet else print

    # ① 옛 표가 얼어 있는가
    p('① 옛 표가 그대로인가 (기준선 대비 지문)')
    if not base:
        p('   기준선이 없다 — 먼저 `--snap` 을 한 번 돌린다.')
    for sch, tbl, pk in _old_tables():
        n, fp = fingerprint(conn, sch, tbl, pk)
        if tbl not in base:
            p('   %-26s %6d행  (기준선 없음)' % (tbl, n))
            continue
        b_n, b_fp, b_at = base[tbl]
        if fp == b_fp:
            p('   %-26s %6d행  그대로' % (tbl, n))
        else:
            bad.append('옛 표 %s 가 바뀌었다 (%d→%d행) — 아직 여기에 쓰는 코드가 있다'
                       % (tbl, b_n, n))
            p('   %-26s %6d행  ⚠ **바뀌었다**(기준선 %d행 · %s)'
              % (tbl, n, b_n, b_at))

    # ② 옮긴 행이 통합 표에 살아 있는가
    p('\n② 옮긴 행이 통합 표에 살아 있는가')
    try:
        tot = conn.execute('SELECT COUNT(*) FROM %s' % M.LOG).fetchone()[0]
    except Exception:
        tot = 0
    if not tot:
        p('   이전 이력이 없다 — 확인할 것이 없다.')
    else:
        lost = []
        for sch, tbl in conn.execute(
                'SELECT DISTINCT dst_schema, src_table FROM %s' % M.LOG):
            t = 'sys_link_asset' if sch == 'main' else 'user_link_asset'
            pk = 'sys_link_id' if sch == 'main' else 'user_link_id'
            miss = conn.execute(
                'SELECT COUNT(*) FROM %s g LEFT JOIN %s.%s l '
                ' ON l.%s = g.dst_id '
                'WHERE g.src_table=? AND g.dst_schema=? AND l.%s IS NULL'
                % (M.LOG, sch, t, pk, pk), (tbl, sch)).fetchone()[0]
            n = conn.execute('SELECT COUNT(*) FROM %s WHERE src_table=?'
                             % M.LOG, (tbl,)).fetchone()[0]
            if miss:
                lost.append((tbl, miss, n))
                p('   %-26s %6d행 중 **%d행 사라짐**' % (tbl, n, miss))
            else:
                p('   %-26s %6d행 전부 있다' % (tbl, n))
        for tbl, miss, n in lost:
            bad.append('%s 에서 옮긴 %d행이 통합 표에서 사라졌다' % (tbl, miss))

    # ③ 설명문 닻
    p('\n③ 옮긴 설명문이 새 닻에 붙어 있는가')
    try:
        rows = conn.execute(
            'SELECT text_type, sys_text_id, new_clicked FROM %s' % M.DESC_LOG
        ).fetchall()
    except Exception:
        rows = []
    if not rows:
        p('   옮긴 설명문이 없다.')
    else:
        off = 0
        for tt, tid, newc in rows:
            r = conn.execute(
                'SELECT clicked_id FROM sys_text_asset WHERE sys_text_id=?',
                (tid,)).fetchone()
            if not r or r[0] != newc:
                off += 1
        if off:
            bad.append('설명문 %d편이 옮긴 자리에 없다' % off)
            p('   %d편 중 **%d편이 어긋났다**' % (len(rows), off))
        else:
            p('   %d편 전부 제자리' % len(rows))

    # ④ 그동안 무슨 일이 있었나
    p('\n④ 기준선 이후 통합 표에 무슨 일이 있었나 (감사 로그)')
    since = min((v[2] for v in base.values()), default=None)
    on = conn.execute(
        "SELECT COUNT(*) FROM sqlite_master WHERE type='trigger' "
        "AND name LIKE 'trg_audit%'").fetchone()[0]
    if not on:
        p('   ⚠ 감사 로그 트리거가 없다 — 무슨 일이 있었는지 못 잰다'
          ' (`db_audit_triggers.py` 로 켠다).')
    elif not since:
        p('   기준선이 없어 못 잰다.')
    else:
        got = False
        for tbl, act, n in conn.execute(
                'SELECT tbl, action, COUNT(*) FROM sys_audit_log '
                "WHERE tbl IN ('sys_link_asset','sys_text_asset') AND ts>=? "
                'GROUP BY 1,2 ORDER BY 1,2', (since,)):
            p('   %-18s %-8s %d건' % (tbl, act, n)); got = True
        if not got:
            p('   (기준선 %s 이후 바뀐 것 없음)' % since)

    # 통합 표가 얼마나 자랐나 — 정상 활동
    p('\n통합 표 (자라는 것이 정상이다)')
    for sch, tbl, pk in UNIFIED:
        n = conn.execute('SELECT COUNT(*) FROM %s.%s' % (sch, tbl)).fetchone()[0]
        b = base.get(tbl)
        p('   %-18s %6d행  %s' % (tbl, n,
                                  ('기준선 %d → %+d' % (b[0], n - b[0]))
                                  if b else ''))

    p('\n' + ('✅ 문제 없음 — 옛 표를 걷어도 된다.' if not bad else
              '⚠ 문제 %d건 — 걷기 전에 봐야 한다:' % len(bad)))
    for b in bad:
        p('   · ' + b)
    return bad, base


def history(conn):
    _ensure(conn)
    rows = conn.execute(
        'SELECT snap_id, taken_at, note, COUNT(*) FROM %s '
        'GROUP BY taken_at, note ORDER BY snap_id' % SNAP).fetchall()
    if not rows:
        print('스냅샷이 없다.')
        return
    print('  %-6s %-20s %-6s %s' % ('id', '시각', '표', '메모'))
    for sid, at, note, n in rows:
        print('  %-6s %-20s %-6d %s' % (sid, at, n, note or ''))


def selftest():
    ok = fail = 0

    def t(n, cond, e=''):
        nonlocal ok, fail
        if cond:
            ok += 1
            print('  OK   %s' % n)
        else:
            fail += 1
            print('  FAIL %s  %s' % (n, e))

    conn = appdb.connect()
    _ensure(conn)

    t('옛 표 목록이 이전 도구와 같다',
      len(_old_tables()) == len(M.BY_KEY), len(_old_tables()))

    # 지문이 **내용 변화를 실제로 잡는가** — 탐지력을 먼저 잰다
    # ⚠ 빈 표를 고르면 시험이 못 돈다(첫 실행에서 실제로 그랬다). 그렇다고
    #   표 이름을 박지 않는다(§0-5) — **행이 있는 것을 그때 고른다**.
    pick = None
    for sch, tbl, pk in _old_tables():
        if conn.execute('SELECT COUNT(*) FROM %s.%s' % (sch, tbl)).fetchone()[0]:
            pick = (sch, tbl, pk)
            break
    if not pick:
        print('  --   행이 있는 옛 표가 없다 — 지문 검사 건너뜀')
        conn.close()
        print('\ndb_link_watch selftest %d/%d' % (ok, ok + fail))
        return fail == 0
    sch, tbl, pk = pick
    n0, fp0 = fingerprint(conn, sch, tbl, pk)
    conn.execute('BEGIN')
    try:
        rid = conn.execute('SELECT %s FROM %s.%s LIMIT 1'
                           % (pk, sch, tbl)).fetchone()[0]
        cols = [r[1] for r in conn.execute('PRAGMA %s.table_info(%s)'
                                           % (sch, tbl))]
        col = next((c for c in cols if c != pk), None)
        conn.execute('UPDATE %s.%s SET %s=%s WHERE %s=?'
                     % (sch, tbl, col, col, pk), (rid,))
        n1, fp1 = fingerprint(conn, sch, tbl, pk)
        t('값을 안 바꾸면 지문도 같다', fp1 == fp0)
        # 실제로 값을 바꿔 본다
        conn.execute('UPDATE %s.%s SET %s=? WHERE %s=?'
                     % (sch, tbl, col, pk), ('__watch_probe__', rid))
        n2, fp2 = fingerprint(conn, sch, tbl, pk)
        t('값이 바뀌면 지문이 달라진다 (탐지력)', fp2 != fp0, (fp0[:8], fp2[:8]))
        t('행 수는 그대로다 — 수로만 재면 못 잡는다', n2 == n0, (n0, n2))
    finally:
        conn.rollback()
    n3, fp3 = fingerprint(conn, sch, tbl, pk)
    t('되돌리기로 지문 원복', fp3 == fp0, (fp0[:8], fp3[:8]))

    # check 가 지금 상태에서 돌아가는가 (데이터 상태에 결과를 안 건다 — §0-5)
    bad, base = check(conn, quiet=True)
    t('check 가 돈다 (문제 %d건)' % len(bad), isinstance(bad, list))
    t('감사 로그 트리거가 켜져 있다',
      conn.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='trigger' "
                   "AND name LIKE 'trg_audit%'").fetchone()[0] > 0)
    conn.close()
    print('\ndb_link_watch selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    a = sys.argv[1] if len(sys.argv) > 1 else '--check'
    if a == '--selftest':
        return 0 if selftest() else 1
    conn = appdb.connect()
    if a == '--snap':
        snap(conn, ' '.join(sys.argv[2:]))
    elif a == '--history':
        history(conn)
    else:
        bad, _ = check(conn)
        conn.close()
        return 1 if bad else 0
    conn.close()
    return 0


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
    sys.exit(main())
