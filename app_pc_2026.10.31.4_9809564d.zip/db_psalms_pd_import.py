# -*- coding: utf-8 -*-
"""시편 PD 자료 적재 — 매클라렌·칼빈·어거스틴 (영구 도구, 2026-08-17 사용자 승인)

  python db_psalms_pd_import.py --selftest            # 의무
  python db_psalms_pd_import.py --fetch               # 원문 수집 (_psalms_raw/)
  python db_psalms_pd_import.py --apply maclaren      # 주석 MACLAREN_PSA (시편 150)
  python db_psalms_pd_import.py --apply david         # 도서 MACLAREN_DAVID (15장)
  python db_psalms_pd_import.py --apply calvin        # 주석 CALVIN_PSA
  python db_psalms_pd_import.py --apply augustine     # 주석 AUGUSTINE_PSA

저장 자리 — **원본의 성격이 정한다** (2026-08-17 사용자 위임):
  · 시편을 편/절 단위로 따라가는 글  → **주석**(sys_commentary_*) — 절을 누르면 뜬다
  · 줄거리로 읽는 책(다윗 전기)      → **도서**(sys_book_*) — P1 도서읽기·플랜 재료
소스 — 전부 public domain 실측 확인:
  · Maclaren, Expositor's Bible: The Psalms 3권 (Gutenberg 42445/42488/44027, 교정 텍스트)
  · Maclaren, The Life of David as Reflected in His Psalms (Gutenberg 21872)
  · Calvin, Commentary on the Psalms 5권 (CCEL calcom08~12)
  · Augustine, Expositions on the Psalms (CCEL npnf108)
⚠ 교단 중립 원칙(§28-11)은 **우리가 쓰는 글**의 규칙 — 저작물(칼빈 등)에는
  적용하지 않는다(2026-08-17 사용자 재확인).

파싱 함정 (실측):
  · 매클라렌 헤딩은 가운데 정렬 `PSALM LIII.[1]`(각주표)·`PSALM LXXXIX`(마침표
    없음)·`PSALMS XLII., XLIII.`(42·43 합편) 꼴이 섞여 있다 — 전부 받는다.
  · 목차(TOC)의 같은 글줄은 끝에 쪽수가 붙어 있어 줄끝 매칭이면 안 걸린다.
  · 시 번역(운문) 블록은 줄바꿈이 뜻이다 — 들여쓴 줄이 많은 문단은 개행 보존,
    산문 문단만 하드랩을 되붙인다.
  · 다윗 전기 장 헤딩은 `I.--INTRODUCTION.` 과 `XV. THE SONGS OF THE FUGITIVE.`
    두 꼴이다.
"""
import io
import os
import re
import sys
import time
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, '_psalms_raw')
DB = os.path.join(HERE, 'bible_master.db')
PSA_BCODE = 19

SOURCES = {
    'maclaren_psa1': 'https://www.gutenberg.org/files/42445/42445-0.txt',
    'maclaren_psa2': 'https://www.gutenberg.org/files/42488/42488-0.txt',
    'maclaren_psa3': 'https://www.gutenberg.org/files/44027/44027-0.txt',
    'maclaren_david': 'https://www.gutenberg.org/cache/epub/21872/pg21872.txt',
    'calvin_psa1': 'https://ccel.org/ccel/c/calvin/calcom08/cache/calcom08.txt',
    'calvin_psa2': 'https://ccel.org/ccel/c/calvin/calcom09/cache/calcom09.txt',
    'calvin_psa3': 'https://ccel.org/ccel/c/calvin/calcom10/cache/calcom10.txt',
    'calvin_psa4': 'https://ccel.org/ccel/c/calvin/calcom11/cache/calcom11.txt',
    'calvin_psa5': 'https://ccel.org/ccel/c/calvin/calcom12/cache/calcom12.txt',
    'augustine_psa': 'https://ccel.org/ccel/s/schaff/npnf108/cache/npnf108.txt',
}


def fetch():
    os.makedirs(RAW, exist_ok=True)
    for name, url in SOURCES.items():
        p = os.path.join(RAW, name + '.txt')
        if os.path.exists(p) and os.path.getsize(p) > 10000:
            continue
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        data = urllib.request.urlopen(req, timeout=120).read()
        io.open(p, 'wb').write(data)
        print(name, len(data), 'bytes')
        time.sleep(1)


# ── 공통 정리 ─────────────────────────────────────────────────────────────

def _strip_gutenberg(t):
    m = re.search(r'\*\*\* ?START OF.*?\*\*\*', t)
    if m:
        t = t[m.end():]
    m = re.search(r'\*\*\* ?END OF', t)
    if m:
        t = t[:m.start()]
    return t


def _unwrap(seg):
    """하드랩 문단 되붙이기 — 들여쓴 줄이 많은 문단(운문)은 개행 보존."""
    paras, cur = [], []
    for ln in seg.split('\n'):
        if ln.strip():
            cur.append(ln)
        elif cur:
            paras.append(cur)
            cur = []
    if cur:
        paras.append(cur)
    out = []
    for p in paras:
        indented = sum(1 for ln in p if ln[:1] == ' ')
        if len(p) > 1 and indented >= max(2, int(len(p) * 0.6)):
            out.append('\n'.join(ln.strip() for ln in p))       # 운문 — 줄 보존
        else:
            out.append(' '.join(' '.join(ln.split()) for ln in p))
    body = '\n'.join(x for x in out if x)
    return body.replace('_', '')


_ROM = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100, 'D': 500, 'M': 1000}


def _unroman(s):
    t = 0
    for i, ch in enumerate(s):
        v = _ROM[ch]
        t += -v if i + 1 < len(s) and _ROM[s[i + 1]] > v else v
    return t


# ── 매클라렌 시편 강해 (주석 MACLAREN_PSA) ─────────────────────────────────

_MAC_HEAD = re.compile(
    r'(?m)^[ \t]*PSALMS? ((?:[IVXLCD]+\.?[, ]*(?:AND )?)+?)(?:\[\d+\])?\s*$')


def parse_maclaren():
    """→ [(chapters(list), text)] — 합편(XLII., XLIII.)은 chapters 가 여럿."""
    out = []
    for name in ('maclaren_psa1', 'maclaren_psa2', 'maclaren_psa3'):
        t = _strip_gutenberg(io.open(os.path.join(RAW, name + '.txt'),
                                     encoding='utf-8-sig').read())
        marks = [m for m in _MAC_HEAD.finditer(t)]
        for i, m in enumerate(marks):
            chs = [_unroman(x) for x in re.findall(r'[IVXLCD]+', m.group(1))]
            end = marks[i + 1].start() if i + 1 < len(marks) else len(t)
            seg = t[m.end():end]
            # 권말 각주 목록·FOOTNOTES 절은 그대로 둔다(본문 일부)
            body = _unwrap(seg)
            if len(body) > 500:
                out.append((chs, body))
    return out


def _ranges(conn):
    out = {}
    for n, a, b in conn.execute(
            'SELECT chapter, MIN(verse_id), MAX(verse_id) FROM bible_index '
            'WHERE bcode=? GROUP BY chapter', (PSA_BCODE,)):
        out[n] = (a, b)
    return out


def _ensure_comm_source(conn, code, title, author, year, desc, title_ko):
    r = conn.execute('SELECT commentary_id FROM sys_commentary_source '
                     'WHERE commentary_code=?', (code,)).fetchone()
    if r:
        return r[0]
    cur = conn.execute(
        "INSERT INTO sys_commentary_source (commentary_code, title, author, "
        "pub_year, lang_code, coverage_scope, copyright_type, source_url, "
        "description, record_status, title_ko) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
        (code, title, author, year, 'EN', 'OT_ONLY', 'PUBLIC_DOMAIN',
         '', desc, 'LIVE', title_ko))
    return cur.lastrowid


def _replace_chapter_entries(conn, sid, sections, ranges):
    """sections = [(chapters, text)] → CHAPTER 항목 멱등 재적재."""
    old = [r[0] for r in conn.execute(
        'SELECT entry_id FROM sys_commentary_entry WHERE commentary_id=?',
        (sid,))]
    if old:
        q = ','.join('?' * len(old))
        conn.execute('DELETE FROM sys_commentary_text WHERE entry_id IN (%s)'
                     % q, old)
        conn.execute('DELETE FROM sys_commentary_entry WHERE entry_id IN (%s)'
                     % q, old)
    n = 0
    for chs, text in sections:
        a = ranges[min(chs)][0]
        b = ranges[max(chs)][1]
        cur = conn.execute(
            "INSERT INTO sys_commentary_entry (commentary_id, entry_level, "
            "bcode, start_vid, end_vid, chapter, record_status) "
            "VALUES (?, 'CHAPTER', 'PSA', ?, ?, ?, 'LIVE')",
            (sid, a, b, min(chs)))
        conn.execute("INSERT INTO sys_commentary_text (entry_id, text_variant, "
                     "lang_code, body_text, record_status) "
                     "VALUES (?, 'ORIGINAL', 'EN', ?, 'LIVE')",
                     (cur.lastrowid, text))
        n += 1
    return n


def apply_maclaren(conn):
    secs = parse_maclaren()
    covered = sorted({c for chs, _ in secs for c in chs})
    if covered != list(range(1, 151)):
        missing = sorted(set(range(1, 151)) - set(covered))
        raise ValueError('매클라렌 — 시편 누락 %s' % missing)
    if any('<' in t for _, t in secs):
        raise ValueError('매클라렌 — 태그 잔재')
    sid = _ensure_comm_source(
        conn, 'MACLAREN_PSA', "The Expositor's Bible: The Psalms",
        'Alexander Maclaren', 1893,
        "Maclaren's psalm-by-psalm exposition (3 vols) with his own verse "
        'translation. Warm, pastoral tone — a gentler companion to the '
        'Treasury of David. Source: Project Gutenberg 42445/42488/44027.',
        '매클라렌 시편 강해')
    n = _replace_chapter_entries(conn, sid, secs, _ranges(conn))
    conn.commit()
    print('MACLAREN_PSA — 편 항목 %d (시편 150 커버)' % n)


# ── 매클라렌 다윗 전기 (도서 MACLAREN_DAVID) ──────────────────────────────

# ⚠ 2장 헤딩만 마침표가 없다(`II.--EARLY DAYS`) — 마침표는 선택.
#   목차 줄은 끝에 쪽수(숫자)가 붙어 있어 여전히 안 걸린다.
_DAV_HEAD = re.compile(r"(?m)^([IVXLCD]+)\.(?:--|\s+)([A-Z][A-Z ,'\-_]+?)\.?\s*$")
DAVID_ATTRIB = ('— Alexander Maclaren, The Life of David as Reflected in '
                'His Psalms (1880)')


def parse_david():
    t = _strip_gutenberg(io.open(os.path.join(RAW, 'maclaren_david.txt'),
                                 encoding='utf-8-sig').read())
    marks = list(_DAV_HEAD.finditer(t))
    out = []
    for i, m in enumerate(marks):
        seq = _unroman(m.group(1))
        title = ' '.join(m.group(2).replace('_', '').split()).title()
        end = marks[i + 1].start() if i + 1 < len(marks) else len(t)
        body = _unwrap(t[m.end():end])
        # 권말 INDEX·광고가 마지막 장 뒤에 붙으면 잘라낸다
        cut = re.search(r'(?m)^INDEX\.?$', body)
        if cut:
            body = body[:cut.start()].rstrip()
        if len(body) > 500:
            out.append((seq, title, body))
    return out


def apply_david(conn):
    chapters = parse_david()
    if len(chapters) != 15:
        raise ValueError('다윗 전기 — 장이 15가 아니라 %d' % len(chapters))
    c = conn.cursor()
    row = c.execute("SELECT book_id FROM sys_book_asset WHERE book_code="
                    "'MACLAREN_DAVID'").fetchone()
    if row:
        book_id = row[0]
    else:
        c.execute(
            """INSERT INTO sys_book_asset (book_code, title, author, lang_code,
               copyright_type, source_url, pub_year, description,
               record_status, book_category)
               VALUES ('MACLAREN_DAVID',?,?,?,?,?,?,?,'LIVE','BIOGRAPHY')""",
            ('The Life of David as Reflected in His Psalms',
             'Alexander Maclaren', 'EN', 'PUBLIC_DOMAIN',
             'https://www.gutenberg.org/ebooks/21872', 1880,
             "David's life traced through the psalms he wrote — devotional "
             'biography in 15 chapters. Source: Project Gutenberg 21872.'))
        book_id = c.lastrowid
    for seq, title, body in chapters:
        row = c.execute('SELECT unit_id FROM sys_book_unit WHERE book_id=? '
                        'AND sequence=?', (book_id, seq)).fetchone()
        if row:
            uid = row[0]
            c.execute("UPDATE sys_book_unit SET unit_label=?, session_type="
                      "'CHAPTER', record_status='LIVE' WHERE unit_id=?",
                      (title, uid))
        else:
            c.execute("INSERT INTO sys_book_unit (book_id, sequence, "
                      "session_type, unit_label, record_status) "
                      "VALUES (?,?,'CHAPTER',?,'LIVE')", (book_id, seq, title))
            uid = c.lastrowid
        c.execute("DELETE FROM sys_book_unit_text WHERE unit_id=? AND "
                  "text_variant='ORIGINAL' AND UPPER(lang_code)='EN'", (uid,))
        c.execute("INSERT INTO sys_book_unit_text (unit_id, text_variant, "
                  "lang_code, body_text, record_status) "
                  "VALUES (?,'ORIGINAL','EN',?,'LIVE')",
                  (uid, body + '\n' + DAVID_ATTRIB))
    conn.commit()
    print('MACLAREN_DAVID(book_id %d) — 장 %d' % (book_id, len(chapters)))


# ── 칼빈 시편 주석 (주석 CALVIN_PSA — 절 단위) ────────────────────────────

def _ccel_sections(text):
    """CCEL txt → [(heading, body)] — 구분선(____) 단위. 각주 섹션([n] 머리)은
    버리고, 본문 안 각주 표시([19])도 걷는다. 본문은 균일 들여쓰기 산문이라
    문단(빈 줄) 단위로 하드랩을 되붙인다."""
    lines = text.split('\n')
    seps = [i for i, l in enumerate(lines)
            if set(l.strip()) == {'_'} and len(l.strip()) > 20]
    out = []
    bounds = seps + [len(lines)]
    for k in range(len(seps)):
        seg = lines[bounds[k] + 1:bounds[k + 1]]
        ti = next((j for j, l in enumerate(seg) if l.strip()), None)
        if ti is None:
            continue
        head = seg[ti].strip()
        paras, cur = [], []
        for l in seg[ti + 1:]:
            tl = l.strip()
            if tl:
                cur.append(tl)
            elif cur:
                paras.append(' '.join(cur))
                cur = []
        if cur:
            paras.append(' '.join(cur))
        body = re.sub(r'\s*\[\d+\]', '', '\n'.join(paras))
        out.append((head, body))
    return out


_CAL_CH = re.compile(r'(?i)^PSALM (\d+)\.?$')
_CAL_VS = re.compile(r'^Psalm (\d+):(\d+)(?:-(\d+))?$')


def parse_calvin():
    """→ {'chap': {n: 편 서론}, 'verse': [(n, v1, v2, text)]}"""
    chap, verse = {}, []
    for name in ('calvin_psa1', 'calvin_psa2', 'calvin_psa3',
                 'calvin_psa4', 'calvin_psa5'):
        t = io.open(os.path.join(RAW, name + '.txt'),
                    encoding='utf-8', errors='replace').read()
        for head, body in _ccel_sections(t):
            if not body or len(body) < 120:
                continue
            m = _CAL_CH.match(head)
            if m:
                n = int(m.group(1))
                chap[n] = (chap.get(n, '') + '\n' + body).strip()
                continue
            m = _CAL_VS.match(head)
            if m:
                n, v1 = int(m.group(1)), int(m.group(2))
                v2 = int(m.group(3)) if m.group(3) else v1
                verse.append((n, v1, v2, body))
    return {'chap': chap, 'verse': verse}


def apply_calvin(conn):
    d = parse_calvin()
    covered = sorted({n for n, _, _, _ in d['verse']})
    missing = sorted(set(range(1, 151)) - set(covered))
    if missing:
        raise ValueError('칼빈 — 시편 누락 %s' % missing)
    if any('<' in t for _, _, _, t in d['verse']):
        raise ValueError('칼빈 — 태그 잔재')
    sid = _ensure_comm_source(
        conn, 'CALVIN_PSA', 'Commentary on the Book of Psalms',
        'John Calvin', 1557,
        "Calvin's verse-by-verse commentary on the Psalms (5 vols, "
        'Calvin Translation Society tr.). Source: CCEL calcom08-12.',
        '칼빈 시편 주석')
    old = [r[0] for r in conn.execute(
        'SELECT entry_id FROM sys_commentary_entry WHERE commentary_id=?',
        (sid,))]
    if old:
        q = ','.join('?' * len(old))
        conn.execute('DELETE FROM sys_commentary_text WHERE entry_id IN (%s)'
                     % q, old)
        conn.execute('DELETE FROM sys_commentary_entry WHERE entry_id IN (%s)'
                     % q, old)
    ranges = _ranges(conn)
    vmap = {}
    for ch, vs, vid in conn.execute(
            'SELECT chapter, verse, verse_id FROM bible_index WHERE bcode=?',
            (PSA_BCODE,)):
        vmap[(ch, vs)] = vid
    nc = nv = 0
    for n, text in sorted(d['chap'].items()):
        a, b = ranges[n]
        cur = conn.execute(
            "INSERT INTO sys_commentary_entry (commentary_id, entry_level, "
            "bcode, start_vid, end_vid, chapter, record_status) "
            "VALUES (?, 'CHAPTER', 'PSA', ?, ?, ?, 'LIVE')", (sid, a, b, n))
        conn.execute("INSERT INTO sys_commentary_text (entry_id, text_variant,"
                     " lang_code, body_text, record_status) "
                     "VALUES (?, 'ORIGINAL', 'EN', ?, 'LIVE')",
                     (cur.lastrowid, text))
        nc += 1
    for n, v1, v2, text in d['verse']:
        a = vmap.get((n, v1))
        b = vmap.get((n, v2))
        if a is None:
            continue
        cur = conn.execute(
            "INSERT INTO sys_commentary_entry (commentary_id, entry_level, "
            "bcode, start_vid, end_vid, chapter, record_status) "
            "VALUES (?, 'VERSE', 'PSA', ?, ?, ?, 'LIVE')",
            (sid, a, (b if b and b != a else None), n))
        conn.execute("INSERT INTO sys_commentary_text (entry_id, text_variant,"
                     " lang_code, body_text, record_status) "
                     "VALUES (?, 'ORIGINAL', 'EN', ?, 'LIVE')",
                     (cur.lastrowid, text))
        nv += 1
    conn.commit()
    print('CALVIN_PSA — 편 서론 %d · 절 항목 %d' % (nc, nv))


# ── 어거스틴 시편 강해 (주석 AUGUSTINE_PSA — 편 단위) ─────────────────────

_AUG_HEAD = re.compile(r'(?m)^[ \t]*Psalm ([IVXLCD]+)\.?\s*(?:\[\d+\])?\s*$')


def parse_augustine():
    """→ [(n, text)] — 편 단위.

    ⚠ NPNF 원문 오식: 13편 헤딩이 XII 로 중복 표기돼 있다(XI, XII, XII,
      XIV — 실측). 순서가 1..150 연속임을 이용해 **자리 번호**로 보정하고,
      선언 번호와 1 넘게 어긋나면 실패시킨다(조용한 오배치 방지)."""
    t = io.open(os.path.join(RAW, 'augustine_psa.txt'),
                encoding='utf-8', errors='replace').read()
    marks = list(_AUG_HEAD.finditer(t))
    out = []
    for i, m in enumerate(marks):
        declared = _unroman(m.group(1))
        n = i + 1
        if abs(declared - n) > 1:
            raise ValueError('어거스틴 — %d번째 헤딩이 Psalm %d (어긋남 큼)'
                             % (n, declared))
        end = marks[i + 1].start() if i + 1 < len(marks) else len(t)
        seg = t[m.end():end]
        paras, cur = [], []
        for l in seg.split('\n'):
            tl = l.strip()
            if set(tl) == {'_'} and len(tl) > 20:
                break                  # 각주 블록 구분선 앞에서 끊는다
            if tl:
                cur.append(tl)
            elif cur:
                paras.append(' '.join(cur))
                cur = []
        if cur:
            paras.append(' '.join(cur))
        body = re.sub(r'\s*\[\d+\]', '', '\n'.join(paras))
        if len(body) > 300:
            out.append((n, body))
    return out


def apply_augustine(conn):
    secs = parse_augustine()
    covered = sorted(n for n, _ in secs)
    missing = sorted(set(range(1, 151)) - set(covered))
    if missing:
        raise ValueError('어거스틴 — 시편 누락 %s' % missing)
    sid = _ensure_comm_source(
        conn, 'AUGUSTINE_PSA', 'Expositions on the Book of Psalms',
        'Augustine of Hippo', 420,
        "Augustine's expositions on the Psalms (Enarrationes in Psalmos), "
        'NPNF series 1 vol. 8 translation. Source: CCEL npnf108.',
        '어거스틴 시편 강해')
    old = [r[0] for r in conn.execute(
        'SELECT entry_id FROM sys_commentary_entry WHERE commentary_id=?',
        (sid,))]
    if old:
        q = ','.join('?' * len(old))
        conn.execute('DELETE FROM sys_commentary_text WHERE entry_id IN (%s)'
                     % q, old)
        conn.execute('DELETE FROM sys_commentary_entry WHERE entry_id IN (%s)'
                     % q, old)
    n_ins = _replace_chapter_entries(
        conn, sid, [([n], text) for n, text in secs], _ranges(conn))
    conn.commit()
    print('AUGUSTINE_PSA — 편 항목 %d' % n_ins)


# ── selftest ──────────────────────────────────────────────────────────────

def selftest():
    ok = True
    # 헤딩 회귀 — 실측으로 잡은 네 꼴
    for line, want in (('     PSALM LIII.[1]', [53]),
                       ('     PSALM LXXXIX', [89]),
                       ('  PSALMS XLII., XLIII.', [42, 43]),
                       ('     PSALM I.', [1])):
        m = _MAC_HEAD.match(line + '\n')
        got = ([_unroman(x) for x in re.findall(r'[IVXLCD]+', m.group(1))]
               if m else None)
        if got != want:
            print('FAIL 매클라렌 헤딩 %r → %s' % (line, got)); ok = False
    # 목차 줄(쪽수 붙음)은 안 걸려야
    if _MAC_HEAD.match('    PSALM I.                            1\n'):
        print('FAIL 목차 줄이 헤딩으로 걸림'); ok = False
    for line, want in (('I.--INTRODUCTION.', (1, 'Introduction')),
                       ('XV. THE SONGS OF THE FUGITIVE.',
                        (15, 'The Songs Of The Fugitive'))):
        m = _DAV_HEAD.match(line + '\n')
        got = ((_unroman(m.group(1)),
                ' '.join(m.group(2).split()).title()) if m else None)
        if got != want:
            print('FAIL 다윗 헤딩 %r → %s' % (line, got)); ok = False
    # 운문 보존 / 산문 되붙이기
    seg = ('  1  Happy the man\n  2  Who walks aright\n\n'
           'This is prose that was\nhard wrapped by the printer.\n')
    body = _unwrap(seg)
    if '1  Happy the man\n2  Who walks aright' not in body:
        print('FAIL 운문 줄 보존: %r' % body); ok = False
    if 'prose that was hard wrapped' not in body:
        print('FAIL 산문 되붙이기'); ok = False
    print('db_psalms_pd_import selftest', 'OK' if ok else 'FAIL')
    return ok


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--fetch', action='store_true')
    ap.add_argument('--check', choices=['maclaren', 'david'])
    ap.add_argument('--apply', choices=['maclaren', 'david',
                                        'calvin', 'augustine'])
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    if a.fetch:
        fetch()
        return
    if a.check == 'maclaren':
        secs = parse_maclaren()
        for chs, t in secs[:5] + secs[-3:]:
            print(chs, len(t), repr(t[:60]))
        print('구획 %d · 커버 시편 %d' %
              (len(secs), len({c for chs, _ in secs for c in chs})))
        return
    if a.check == 'david':
        for seq, title, body in parse_david():
            print(seq, title, len(body))
        return
    if a.apply:
        conn = appdb.connect(DB)
        try:
            if a.apply == 'maclaren':
                apply_maclaren(conn)
            elif a.apply == 'david':
                apply_david(conn)
            elif a.apply == 'calvin':
                apply_calvin(conn)
            elif a.apply == 'augustine':
                apply_augustine(conn)
        finally:
            conn.close()
        return
    ap.print_help()


if __name__ == '__main__':
    main()
