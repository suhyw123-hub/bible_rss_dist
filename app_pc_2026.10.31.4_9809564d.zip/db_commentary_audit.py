# -*- coding: utf-8 -*-
"""db_commentary_audit.py — 주석 DB 구절 매핑 정합성 검사 (영구 도구, 읽기 전용)

  python -X utf8 db_commentary_audit.py             # 신약 전권
  python -X utf8 db_commentary_audit.py --book 44   # 한 책
  python -X utf8 db_commentary_audit.py --coverage  # 커버리지만
  python -X utf8 db_commentary_audit.py --selftest  # 탐지력 확인(의무)

**왜 필요한가.** 2026-08-02 부터 페리코프·장 설명문의 **배경**을 이 DB 에서 가져온다
(peri.md §3-3b). 그런데 매핑이 어긋나면 **그럴듯하고 구체적인데 엉뚱한 절에 붙은 배경**이
설명문으로 옮아간다. 문체 게이트는 문체만 보고 겹침 검사는 KRV 어휘만 보므로
**아무것도 이 오류를 잡지 못한다.** 실제로 이 DB 는 과거에 PULPIT_COM 877건 중복 +
41건 장 오배치를 겪었다(CLAUDE.md §0-1).

**검사 원리 — 주석 본문이 자기 절 번호를 스스로 말한다.** 외부 자료가 필요 없다.
  BARNES_NT : 본문이 `Verse 12.` 로 시작한다 → start_vid 의 절 번호와 대조
  CLARKE    : 본문이 KJV 표제어로 시작하고 `]` 로 닫는다 → 그 표제어 낱말이
              매핑된 절의 KJV 본문에 실제로 있는지 대조(절반 이상이면 일치)
JFB·HENRY_MHC 는 단락·장 단위라 절 번호를 말하지 않으므로 이 검사의 대상이 아니다.

**판정**: 불일치율이 `FAIL_PCT`(1.0%)를 넘으면 실패로 끝낸다. 0 을 요구하지 않는 것은
범위 항목(`Verse 23-24.`)과 철자 이형(`lowring`/`Ænon`)이 구조적으로 섞이기 때문이다.
"""
import argparse
import re
import sys

import appdb

DB = 'bible_master.db'
FAIL_PCT = 1.0

VERSE_NO = re.compile(r'^\s*Verse\s+(\d+)', re.I)
LEMMA = re.compile(r'^(.{4,90}?)\]')
VERSE_LEVEL = ('BARNES_NT', 'CLARKE', 'PULPIT_COM')
ALL_SRC = ('BARNES_NT', 'CLARKE', 'JFB', 'HENRY_MHC', 'PULPIT_COM')


def nt_books(conn):
    return [(b, n) for b, n in conn.execute(
        "SELECT DISTINCT bi.bcode, (SELECT full_name FROM book_names "
        " WHERE book_code=bi.bcode AND lang_code='KO') "
        "FROM bible_index bi WHERE bi.bcode BETWEEN 40 AND 66 ORDER BY bi.bcode")]


def span(conn, bcode):
    return conn.execute('SELECT MIN(verse_id), MAX(verse_id), COUNT(*) '
                        'FROM bible_index WHERE bcode=?', (bcode,)).fetchone()


def entries(conn, code, lo, hi):
    return conn.execute(
        """SELECT e.start_vid, x.body_text FROM sys_commentary_entry e
             JOIN sys_commentary_source s ON s.commentary_id = e.commentary_id
             JOIN sys_commentary_text  x ON x.entry_id = e.entry_id
            WHERE s.commentary_code = ? AND e.start_vid BETWEEN ? AND ?
              AND x.text_variant = 'ORIGINAL'
              AND COALESCE(e.record_status,'LIVE') = 'LIVE'
              AND COALESCE(x.record_status,'LIVE') = 'LIVE'""",
        (code, lo, hi)).fetchall()


def check_verse_no(conn, rows):
    """BARNES 계열 — 본문의 'Verse N.' 과 매핑된 절 번호 대조."""
    ok = bad = skip = 0
    hits = []
    for vid, body in rows:
        m = VERSE_NO.match(body or '')
        if not m:
            skip += 1
            continue
        r = conn.execute('SELECT chapter, verse FROM bible_index WHERE verse_id=?',
                         (vid,)).fetchone()
        if not r:
            skip += 1
        elif int(m.group(1)) == r[1]:
            ok += 1
        else:
            bad += 1
            hits.append((vid, f'{r[0]}:{r[1]}', m.group(1), ' '.join((body or '').split())[:60]))
    return ok, bad, skip, hits


def check_lemma(conn, rows):
    """CLARKE 계열 — 표제어 낱말이 그 절의 KJV 본문에 있는지."""
    ok = bad = skip = 0
    hits = []
    for vid, body in rows:
        m = LEMMA.match(' '.join((body or '').split()))
        if not m:
            skip += 1
            continue
        words = [w for w in re.sub(r'[^a-zA-Z ]', ' ', m.group(1)).split() if len(w) > 3]
        kjv = conn.execute("SELECT verse_text FROM bible_content WHERE verse_id=? "
                           "AND version_code='KJV'", (vid,)).fetchone()
        if not words or not kjv or not kjv[0]:
            skip += 1
            continue
        src = kjv[0].lower()
        if sum(1 for w in words if w.lower() in src) / len(words) >= 0.5:
            ok += 1
        else:
            bad += 1
            r = conn.execute('SELECT chapter, verse FROM bible_index WHERE verse_id=?',
                             (vid,)).fetchone()
            hits.append((vid, f'{r[0]}:{r[1]}' if r else '?', ' '.join(words)[:40],
                         (kjv[0] or '')[:55]))
    return ok, bad, skip, hits


def coverage(conn, books):
    print('=== 커버리지 — 절 몇 %가 그 주석을 가지고 있나 ===')
    print(f'{"책":<10}{"절수":>6}  ' + ''.join(f'{c:>12}' for c in ALL_SRC))
    for bcode, nm in books:
        lo, hi, nv = span(conn, bcode)
        cells = []
        for code in ALL_SRC:
            n = conn.execute(
                """SELECT COUNT(DISTINCT bi.verse_id) FROM bible_index bi
                     JOIN sys_commentary_entry e
                       ON (e.start_vid = bi.verse_id
                           OR (e.start_vid <= bi.verse_id AND e.end_vid >= bi.verse_id))
                     JOIN sys_commentary_source s ON s.commentary_id = e.commentary_id
                    WHERE bi.bcode = ? AND s.commentary_code = ?""",
                (bcode, code)).fetchone()[0]
            cells.append(f'{100 * n / nv:.0f}%' if nv else '-')
        print(f'{(nm or bcode):<10}{nv:>6}  ' + ''.join(f'{c:>12}' for c in cells))
    print('\n  ⚠ JFB(단락 단위·평균 16.5절)·HENRY_MHC(장 단위·평균 30.8절)의 높은 %는'
          '\n    항목이 넓은 범위를 덮기 때문이다. 절별 정밀도가 아니다.')


def audit(conn, books, verbose=True):
    print('=== 매핑 검증 ===')
    tot = totbad = 0
    allhits = []
    for code, fn in (('BARNES_NT', check_verse_no), ('CLARKE', check_lemma),
                     ('PULPIT_COM', check_verse_no)):
        c_ok = c_bad = c_skip = 0
        for bcode, nm in books:
            lo, hi, _ = span(conn, bcode)
            rows = entries(conn, code, lo, hi)
            if not rows:
                continue
            o, b, s, h = fn(conn, rows)
            c_ok += o; c_bad += b; c_skip += s
            allhits += [(nm, code) + x for x in h]
        n = c_ok + c_bad
        if not n:
            print(f'  {code:<12} 검사 대상 없음')
            continue
        pct = 100 * c_bad / n
        tot += n; totbad += c_bad
        mark = 'OK ' if pct <= FAIL_PCT else 'NG '
        print(f'  {mark}{code:<12} 판정 {n:>5}  일치 {c_ok:>5}  '
              f'불일치 {c_bad:>4} ({pct:.2f}%)  판정불가 {c_skip:>4}')
    if verbose and allhits:
        print('\n  불일치 전체:')
        for h in allhits[:40]:
            print('   ', h)
        if len(allhits) > 40:
            print(f'    … 외 {len(allhits) - 40}건')
    pct = 100 * totbad / tot if tot else 0
    print(f'\n  합계 {tot}건 중 불일치 {totbad}건 ({pct:.2f}%) — 상한 {FAIL_PCT}%')
    return pct <= FAIL_PCT


def selftest(conn):
    """탐지력 확인 — 일부러 어긋낸 것이 반드시 걸려야 한다."""
    ok = True
    bad_rows = [(26925, 'Verse 99. This is deliberately wrong.')]     # 행 1:1 슬롯
    o, b, _s, _h = check_verse_no(conn, bad_rows)
    print(f'  [{"PASS" if b else "FAIL"}] 절 번호 어긋남 탐지 (BARNES 방식)')
    ok = ok and bool(b)
    good = conn.execute(
        """SELECT e.start_vid, x.body_text FROM sys_commentary_entry e
             JOIN sys_commentary_source s ON s.commentary_id=e.commentary_id
             JOIN sys_commentary_text x ON x.entry_id=e.entry_id
            WHERE s.commentary_code='BARNES_NT' AND x.text_variant='ORIGINAL'
              AND x.body_text LIKE 'Verse %' LIMIT 200""").fetchall()
    o, b, _s, _h = check_verse_no(conn, good)
    print(f'  [{"PASS" if b == 0 else "FAIL"}] 정상 항목 200개 오탐 없음 (불일치 {b})')
    ok = ok and b == 0
    lem_bad = [(26925, 'And there appeared unto them cloven tongues] Not this verse.')]
    o, b, _s, _h = check_lemma(conn, lem_bad)
    print(f'  [{"PASS" if b else "FAIL"}] 표제어 불일치 탐지 (CLARKE 방식)')
    return ok and bool(b)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--book', type=int)
    ap.add_argument('--coverage', action='store_true')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    conn = appdb.connect(DB)

    if a.selftest:
        print('=== 자가 탐지력 ===')
        sys.exit(0 if selftest(conn) else 1)

    books = ([(a.book, conn.execute("SELECT full_name FROM book_names WHERE book_code=? "
                                    "AND lang_code='KO'", (a.book,)).fetchone()[0])]
             if a.book else nt_books(conn))
    coverage(conn, books)
    if a.coverage:
        return
    print()
    sys.exit(0 if audit(conn, books) else 1)


if __name__ == '__main__':
    main()
