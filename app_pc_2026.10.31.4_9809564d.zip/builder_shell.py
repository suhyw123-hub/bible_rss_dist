# -*- coding: utf-8 -*-
"""「성경의 xxx」 만들기 창 공통 틀 (2026-10-20 · docs/1.txt 5-2).

사용자 지시 — 「주제읽기로 편입하고 화면 통일한다」 · 「플랜 이름 입력화면을 상단에」 ·
「체크상자 오른쪽을 분리하라. 체크할 때마다 수정되는 유닛, 묵상기간 값을 오른쪽에 크게」 ·
성경의 기도 「좌우 대비하지 말고 하나로 통합」.

    ┌ 플랜 이름 [______________] (고쳐 써도 됩니다) ……… [플랜 만들기][취소] ┐
    ├ 선택해 담기 (체크 줄들) ………………………………… │  유닛  12개         ┤
    │                                                   │  묵상기간 12일     │
    └ 목록 하나 (화면마다 다름) ─────────────────────────────────────────┘

★ 세 창(성경의 인물 · 기적 · 기도 · 그리고 고난)이 **이 한 문**으로 틀을 짓는다 —
  창마다 따로 지으면 다시 갈린다(사용자가 고친 자리가 셋으로 흩어져 있던 까닭).
★ 단추는 맨 위(§0) · 색은 역할(`ui_theme.C`) · 글꼴 이름을 적지 않는다.
"""
import tkinter as tk
from tkinter import ttk
import tkinter.font as tkfont

import i18n

try:
    import ui_theme
    _C = ui_theme.C
except Exception:                                           # noqa: BLE001
    def _C(_role, dflt=''):
        return dflt


def _col(role, dflt):
    try:
        v = _C(role, dflt)
    except TypeError:
        v = _C(role)
    return v or dflt


class Shell:
    """틀만 짓는다. 쓰는 쪽이 받는 것 — `name_var` · `filters`(체크 줄을 놓을 칸) ·
    `body`(목록 칸) · `set_count(유닛, 일)`."""

    def __init__(self, win, on_create, filter_title=None):
        self.win = win
        base = tkfont.nametofont('TkDefaultFont')
        size = abs(int(base.cget('size') or 9))

        # ① 맨 위 — 플랜 이름 + 단추
        top = ttk.Frame(win, padding=(8, 6, 8, 2))
        top.pack(fill='x')
        ttk.Label(top, text=i18n.t('PB_PLANNAME', '플랜명:')).pack(side='left', padx=(0, 4))
        self.name_var = tk.StringVar()
        self.name_entry = ttk.Entry(top, textvariable=self.name_var, width=34)
        self.name_entry.pack(side='left', fill='x', expand=True)
        ttk.Label(top, text=i18n.t('PB_NAMEHINT', '고쳐 써도 됩니다'),
                  foreground=_col('fg_dim', '#888')).pack(side='left', padx=(6, 12))
        ttk.Button(top, text=i18n.t('COMMON_CANCEL', '취소'),
                   command=win.destroy).pack(side='right')
        self.create_btn = ttk.Button(top, text=i18n.t('PB_CREATE_TOP', '플랜 만들기'),
                                     command=on_create)
        self.create_btn.pack(side='right', padx=(0, 6))

        # ② 가운데 — 왼쪽 체크 줄 · 오른쪽 큰 수
        mid = ttk.Frame(win, padding=(4, 2, 4, 0))
        mid.pack(fill='x')
        self.filters = ttk.LabelFrame(
            mid, text=filter_title or i18n.t('PB_FILTER', ' 선택해 담기 '), padding=(6, 4))
        self.filters.pack(side='left', fill='both', expand=True)
        cnt = tk.Frame(mid, bg=_col('panel_alt', '#F4F6F7'), padx=16, pady=8,
                       highlightthickness=1, highlightbackground=_col('border', '#D5D8DC'))
        cnt.pack(side='right', fill='y', padx=(8, 0))
        big = (base.cget('family'), size + 9, 'bold')
        small = (base.cget('family'), size + 1)
        fg = _col('accent', '#1A5276')
        bg = _col('panel_alt', '#F4F6F7')
        tk.Label(cnt, text=i18n.t('PB_CNT_UNITS', '유닛'), font=small, bg=bg,
                 fg=_col('fg_dim', '#666')).grid(row=0, column=0, sticky='w')
        self._n_lbl = tk.Label(cnt, text='0', font=big, bg=bg, fg=fg)
        self._n_lbl.grid(row=1, column=0, sticky='w')
        tk.Label(cnt, text=i18n.t('PB_CNT_DAYS', '묵상기간'), font=small, bg=bg,
                 fg=_col('fg_dim', '#666')).grid(row=0, column=1, sticky='w', padx=(18, 0))
        self._d_lbl = tk.Label(cnt, text='0', font=big, bg=bg, fg=fg)
        self._d_lbl.grid(row=1, column=1, sticky='w', padx=(18, 0))

        # ③ 아래 — 목록 하나
        self.body = ttk.Frame(win, padding=(4, 4, 4, 4))
        self.body.pack(fill='both', expand=True)

    def set_count(self, units, days=None):
        days = units if days is None else days
        self._n_lbl.config(text=i18n.t('PB_CNT_N', '%s개').replace('%s', str(units)))
        self._d_lbl.config(text=i18n.t('PB_CNT_D', '%s일').replace('%s', str(days)))

    def counts(self):
        return self._n_lbl.cget('text'), self._d_lbl.cget('text')


def selftest():
    ok = []
    r = tk.Tk(); r.withdraw()
    w = tk.Toplevel(r)
    hit = []
    s = Shell(w, lambda: hit.append(1))
    s.set_count(12, 15)
    ok.append(('수가 크게 보인다', s.counts() == ('12개', '15일')))
    s.create_btn.invoke()
    ok.append(('만들기 단추가 부른다', hit == [1]))
    sl = w.pack_slaves()
    ok.append(('이름 칸이 맨 위 · 목록이 맨 아래', sl[0] is s.name_entry.master and sl[-1] is s.body))
    r.destroy()
    bad = [m for m, v in ok if not v]
    print('builder_shell selftest %d/%d' % (len(ok) - len(bad), len(ok)), *bad)
    return not bad


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        raise SystemExit(0 if selftest() else 1)
