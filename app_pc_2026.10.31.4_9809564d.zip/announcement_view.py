# -*- coding: utf-8 -*-
"""공지사항 — P1 최상위 탭6 (RSS-on-GitHub 배포, 다국어, 미열람 배지).

- 1차 콘텐츠(우리 저작) → 본문 포함. announcements.json 을 sync_announcements 로 받아
  user_announcement(user_data.db)에 누적, 사용자 언어로 표시(EN 폴백).
- 탭이 표시되면 '열람'으로 기록 → 배지(미열람 수) 0. on_count_change 콜백으로 탭 제목 갱신.
"""
import threading
import tkinter as tk
from tkinter import ttk

import appdb
import rss_reader as R


def _C(role, fallback):
    try:
        import ui_theme
        return ui_theme.C(role) or fallback
    except Exception:
        return fallback

try:
    import i18n
    def _t(k, d):
        try:
            return i18n.t(k, d)
        except Exception:
            return d
except Exception:
    def _t(k, d):
        return d


class AnnouncementView(ttk.Frame):
    def __init__(self, master, db_path, lang_getter=None, on_count_change=None):
        super().__init__(master)
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.on_count_change = on_count_change
        self._items = []

        bar = ttk.Frame(self); bar.pack(fill='x', padx=6, pady=4)
        ttk.Button(bar, text='' + _t('COMMON_REFRESH', '새로고침'),
                   command=self.refresh).pack(side='left')
        self._status = ttk.Label(bar, text='', foreground=_C('accent', '#1A5276'))
        self._status.pack(side='left', padx=10)

        pw = ttk.Panedwindow(self, orient='horizontal'); pw.pack(fill='both', expand=True, padx=6, pady=4)
        left = ttk.Frame(pw); pw.add(left, weight=1)
        self._tv = ttk.Treeview(left, columns=('date', 'title'), show='headings', height=14)
        self._tv.heading('date', text=_t('ANN_COL_DATE', '게시일'))
        self._tv.heading('title', text=_t('ANN_COL_TITLE', '제목'))
        self._tv.column('date', width=110, anchor='w')
        self._tv.column('title', width=240, anchor='w')
        sb = ttk.Scrollbar(left, orient='vertical', command=self._tv.yview)
        self._tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y'); self._tv.pack(fill='both', expand=True)
        self._tv.bind('<<TreeviewSelect>>', self._on_select)

        right = ttk.Frame(pw); pw.add(right, weight=2)
        self._title = tk.Label(right, text='', font=('', 12, 'bold'),
                               anchor='w', justify='left', wraplength=420)
        self._title.pack(fill='x', padx=8, pady=(6, 2))
        self._meta = tk.Label(right, text='', fg=_C('fg_dim', '#888'), anchor='w')
        self._meta.pack(fill='x', padx=8)
        self._body = tk.Text(right, wrap='word', relief='flat',
                             bg=_C('panel', '#FFFFFF'), fg=_C('fg', '#222'),
                             padx=10, pady=8)
        try:
            import theme_font
            theme_font.register(self._body, self.db_path, 'prose')
        except Exception:
            pass
        self._body.pack(fill='both', expand=True, padx=6, pady=4)
        self._body.config(state='disabled')

        self._render()                 # 캐시 즉시 표시
        self._notify_count()           # 캐시 기준 배지 먼저
        self._first = False
        self.bind('<Map>', self._on_map)   # 탭이 처음 보일 때만 동기화(지연 로딩)

    # ── 표시 ─────────────────────────────────────────────────────────
    def _render(self):
        self._tv.delete(*self._tv.get_children())
        with appdb.connect(self.db_path) as conn:
            self._items = R.announcement_items(conn, self.lang_getter())
        for it in self._items:
            mark = '' if it['pin'] else ''
            self._tv.insert('', 'end', iid=str(it['ann_id']),
                            values=((it['published'] or '')[:10], mark + (it['title'] or '')))
        if self._items:
            first = str(self._items[0]['ann_id'])
            self._tv.selection_set(first); self._show(self._items[0])
        else:
            self._set_body('', '', _t('ANN_EMPTY', '공지사항이 없습니다.'))

    def _on_select(self, _e=None):
        sel = self._tv.selection()
        if not sel:
            return
        for it in self._items:
            if str(it['ann_id']) == sel[0]:
                self._show(it); break

    def _show(self, it):
        self._set_body(it.get('title', ''), it.get('published', ''), it.get('body', ''))

    def _set_body(self, title, published, body):
        self._title.config(text=title or '')
        self._meta.config(text=(published or ''))
        self._body.config(state='normal')
        self._body.delete('1.0', 'end')
        self._body.insert('end', body or '')
        self._body.config(state='disabled')

    # ── 동기화 + 열람 ────────────────────────────────────────────────
    def _on_map(self, _e):
        if not self._first:
            self._first = True
            self.after(150, lambda: self._sync(force=False))

    def refresh(self):
        self._sync(force=True)          # [새로고침] = 강제 동기화

    def _sync(self, force=False):
        if not force:
            # throttle: 최근 자동 동기화했으면 네트워크 생략(캐시만). 앱 매 실행 재수집 방지
            try:
                with appdb.connect(self.db_path) as conn:
                    if not R.should_auto_sync(conn, 'announce'):
                        self._status.config(text=_t('ANN_CACHED', '최신(캐시)'))
                        return
            except Exception:
                pass
        self._status.config(text=_t('ANN_SYNCING', '동기화 중...'))

        def work():
            try:
                import rss_transport as RT
                with appdb.connect(self.db_path) as conn:
                    R.sync_announcements(conn, RT.client_servers())
                    R.mark_auto_sync(conn, 'announce')
            except Exception:
                pass
            # ⚠ 데몬 실은 **창이 닫힌 뒤에** 깨어날 수 있다 — 그때 `after` 를
            #   부르면 「main thread is not in main loop」 로 트레이스백이 난다
            #   (`feedback_view`·`reading_news_view` 와 **같은 자리 세 번째**).
            try:
                if self.winfo_exists():
                    self.after(0, self._after_sync)
            except Exception:
                pass
        threading.Thread(target=work, daemon=True).start()

    def _after_sync(self):
        self._render()
        # 사용자에게 보이는 건수로 표시(내부 적용/삭제 수가 아니라 — 혼동 방지)
        self._status.config(text=_t('ANN_COUNT', '공지 {n}건').format(n=len(self._items)))
        self._notify_count()

    def mark_seen(self):
        """탭이 표시됐을 때 호출 — 열람 시각 기록 → 배지 0."""
        try:
            with appdb.connect(self.db_path) as conn:
                R.set_announce_last_seen(conn)
        except Exception:
            pass
        if self.on_count_change:
            self.on_count_change(0)

    def _notify_count(self):
        if not self.on_count_change:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                self.on_count_change(R.unread_announcements(conn, self.lang_getter()))
        except Exception:
            pass
