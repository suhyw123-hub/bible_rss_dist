# -*- coding: utf-8 -*-
"""모바일 코어팩 — 언어마다 한 파일(2026-10-08 사용자 확정 · data.md Z-2y).

  python db_mobile_core.py --selftest
  python db_mobile_core.py --plan KO          무엇이 얼마나 실리나(만들지 않는다)
  python db_mobile_core.py --build KO [EN …]  공통 코어팩·언어팩(mobile_common · mobile_lang_KO)
  python db_mobile_core.py --build-all        공통 + 언어 11 + 유튜브 팩
  python db_mobile_core.py --build-server     서버에 올릴 폰 팩 전부(+ 사진 · AI 기본 꾸러미 · 도서)
  python db_mobile_core.py --build-store [판] 스토어 초판 묶기(_store_dist)
  ⚠ 2026-10-12 옛 판(언어마다 통째 mobile_core_<언어> · 언어마다 찬양 mobile_worship_<언어>)을 만드는 코드는 걷었다.

★★★ PC 코어팩을 폰에 보내지 않는다 — 폰 몫은 따로 정의한다(사용자 「모바일 코어팩 개념과 범위를
  제대로 정의하지 않고 진행한 것이 부적절했다」 · 처음 판은 PC 코어팩 100표 33 MB 를 그대로 담았다).

  | 갈래 | 범위 |
  |---|---|
  | 성경 본문 | 그 언어 대표 역본(`db_cite_gate.VERSION_OF`) + BSB · 전권 |
  | 구절 설명·묵상질문·기도 | 그 언어 · 전권 · 일반(LAY) + **전문 설명문·연구질문(EXPERT)** — 2026-10-14 폰 「설명」 갈래 [일반][전문] |
  | 구절 연결 + 연결설명 | 모든 짝 · 설명은 그 언어 |
  | 주석 | **창세기 1장만**(맛보기) · 그 언어 + 영어 원문 |
  | 플랜 | 플랜·분류·일정 + 제목·설명·포커스·질문(그 언어 + 영어) · **골라담기(분류 216) 제외** |
  | 렌즈묵상 | 렌즈·마디·구절 연결 + 설명문(그 언어) |
  | 단락·장 | 단락(제목·설명) · 장 설명(그 언어) |
  | 영상 | **그 언어 영상만 · 성경 전권** 구절 연결 + 제목·주소(설명문은 안 싣는다 — 저작권 · 2026-09-17 반려) |
  | AI 필수 지침 | 그 언어 + 영어 |
  | 책 이름·화면 글자 | 그 언어 + 영어 |
  | 빼는 것 | 도서·설교집(PC 에서 고른 것만 따로 보낸다) · 주요용어 · 가계도 · 다른 언어 글 |
  (2026-10-08 2판 — 사용자 「용량이 작으면 코어팩에 포함하라」 · 「골라담기 필요없다」)

⚠ 팩 형식은 PC 팩과 같다(폰 `PackLoader` 가 그대로 읽는다) · kind = 'MCORE' · lang = 그 언어.
⚠ 폰 화면이 새 표를 읽게 되면 `SPEC` 과 폰 `pack_loader.keep` 에 함께 한 줄을 더한다.
"""
import gzip
import hashlib
import json
import re
import os
import sys
import time

APP = os.path.dirname(os.path.abspath(__file__))
if APP not in sys.path:
    sys.path.insert(0, APP)

OUT_DIR = os.path.join(APP, '_mobile_dist')
FORMAT = 1
TEXT_TYPES = ('VERS_DESC', 'VERS_QUESTION', 'VERS_PRAYER', 'VERS_VERS_DESC',
              'PERI_TITLE', 'PERI_DESC', 'CHAP_DESC', 'BOOK_DESC',
              'CONT_DESC', 'CONT_NODE_DESC', 'NODE_DESC', 'NODE_VERS_DESC',
              'CONT_NAME', 'NODE_NAME', 'NODE_QUESTION', 'NODE_PRAYER',
              'PLAN_FOCUS', 'PLAN_QUESTION')
TITLE_TYPES = ('ROUTE_THEME_NAME', 'ROUTE_VARIANT_NAME', 'ROUTE_VARIANT_BASIS', 'ROUTE_STOP_DESC',  # ★ 2026-10-23 믿음의 발자취
               'PLAN_TITLE', 'PLAN_DESC', 'PLAN_CAT_NAME', 'WEEK_TITLE', 'WEEK_DESC',
               'TL_EVENT_TITLE', 'TL_EVENT_WORLD', 'TL_EVENT_EVIDENCE', 'TL_EVENT_DESC', 'TL_EVENT_PLACE')   # 그 언어 + 영어(연대표 글은 2026-10-22)
PICK_CAT = 216               # 골라담기 — 폰에 없다(사용자)
# ★ 2026-10-20 셋을 주제읽기 안으로 옮겼다 — 앵커(만들기 창) 묶음은 폰에 안 싣는다(만든 플랜은 내 플랜 사본으로 간다)
PICK_CATS = (216, 229, 230, 231, 232)
MEDIA_COLS = ('media_id', 'media_type', 'format_type', 'title', 'url', 'lang_code', 'is_active',
              'record_status', 'audience', 'embed_ok')      # ⚠ description 은 안 싣는다
TASTE_COMM = (1, 1)          # 주석 맛보기 = 창세기 1장
LIVE = "COALESCE(record_status,'LIVE')='LIVE'"


def langs_all(conn):
    import lang_config
    return [l.upper() for l in lang_config.ui_langs()]


def version_for(lang):
    import db_cite_gate
    return db_cite_gate.version_for(lang)


def _gen1(conn):
    b, c = TASTE_COMM
    r = conn.execute('SELECT MIN(verse_id), MAX(verse_id) FROM bible_index WHERE bcode=? AND chapter=?',
                     (b, c)).fetchone()
    return r[0], r[1]


COMMON = 'COMMON'                       # 공통 코어팩의 「언어」 자리 표식
COMMON_FILE = 'mobile_common.json.gz'


#: 좌표 있는 장소 + 여정 주제의 인물 — 발자취 화면이 이름을 읽는 용어(설명문이 없어도 이름은 있어야 핀이 말을 한다)
_GEO = ("SELECT entity_id FROM sys_entity_master WHERE entity_type='PLACE' AND geo_lat IS NOT NULL AND %s "
        "UNION SELECT entity_id FROM sys_place_route_theme WHERE entity_id IS NOT NULL AND %s" % (LIVE, LIVE))


def spec_common(conn):
    """**공통 코어팩** — 언어와 상관없는 것 + 영어 기본분(모든 언어가 빈 칸을 영어로 채운다).

    ★ 2026-10-10 사용자 「코어팩은 언어에 의존하지 않아야 할 것 같다 · 다른 언어 코어팩을 지운다는
      개념도 이상하다」 → 「공통 코어팩 + 언어팩으로 나누어 진행하라」. 언어마다 만든 코어팩이 각자
      구절 목록·BSB 를 통째로 담아, 폰에 두 언어가 들면 **구절이 두 번씩** 보였다(실기기).
      ⇒ 구절 목록·BSB 는 **여기에만** 있다 — 언어팩을 몇 개 담아도 겹칠 수 없다.
    """
    a, b = _gen1(conn)
    _pc = ','.join(str(x) for x in PICK_CATS)
    pick = ('SELECT cat_id FROM sys_plan_category WHERE cat_id IN (%s) OR parent_id IN (%s)' % (_pc, _pc))
    q_ent = ('commentary_id IN (SELECT commentary_id FROM sys_commentary_source WHERE %s) '
             'AND %s AND start_vid BETWEEN ? AND ?' % (LIVE, LIVE))
    return [
        ('bible_index', None, ()),
        # 역본 목록(이름·언어 · 20줄) — 폰 역본 고르기에 정식 이름 · 단락 제목을 역본 언어로(1.txt 54-3)
        ('bible_version', None, ()),
        ('bible_content', "version_code='BSB'", ()),
        # ★ 2026-10-20 (docs/1.txt 7-3) 화면 글자 · 책 이름 = **11언어 전부** 공통팩에 — 언어를 바꾸면 팩을 받기 전에도
        #   화면이 그 언어로 바뀐다(그전에는 언어팩에 있어 영어·한국어가 섞였다). 언어팩 = 그 언어의 **콘텐츠만**.
        ('book_names', None, ()),
        ('ui_strings', None, ()),
        ('sys_text_asset', "%s AND text_type IN (%s) AND UPPER(lang_code)='EN'"
         % (LIVE, ','.join('?' * len(TITLE_TYPES))), TITLE_TYPES),
        ('sys_link_asset', "%s AND link_type IN ('VERS_VERS','CONT_NODE','NODE_VERS')" % LIVE, ()),
        ('sys_commentary_source', LIVE, ()),
        # ★ 2026-10-28 항목(어느 주석이 어느 구절을 다루나)은 **전부** — 본문을 안 받은 주석도 구절 주석 탭에
        #   이름이 「다운로드 필요」로 보인다(사용자 「구절과 연결된 주석 이름을 회색으로」). 본문은 아래 맛보기 + 주석 팩.
        ('sys_commentary_entry', LIVE, ()),
        ('sys_commentary_text',
         "entry_id IN (SELECT entry_id FROM sys_commentary_entry WHERE %s) AND UPPER(lang_code)='EN' AND %s"
         % (q_ent, LIVE), (a, b)),
        ('sys_plan_category', '%s AND cat_id NOT IN (%s)' % (LIVE, pick), ()),
        ('sys_bible_plan', '%s AND COALESCE(cat_id,0) NOT IN (%s)' % (LIVE, pick), ()),
        ('sys_plan_schedule', 'plan_id IN (SELECT plan_id FROM sys_bible_plan WHERE %s AND COALESCE(cat_id,0) NOT IN (%s))'
         % (LIVE, pick), ()),
        ('sys_unit_asset', '%s AND (sys_unit_id IN (SELECT sys_unit_id FROM sys_unit_asset WHERE unit_type=\'CONTAINER\' AND %s) '
         'OR sys_unit_id IN (SELECT target_id FROM sys_link_asset WHERE link_type=\'CONT_NODE\' AND %s))'
         % (LIVE, LIVE, LIVE), ()),
        ('sys_pericope_asset', LIVE, ()),
        # ★ 2026-10-22 둘러보기 ▸ 메시아 가계도 — 인물·관계(언어 중립) · 카드 글은 언어팩. 제자 계보(TEACHER)는 아직 안 싣는다
        ('sys_genealogy_person', "%s AND lineage_type IN ('MESSIANIC','BOTH')" % LIVE, ()),
        ('sys_genealogy_relation', "%s AND rel_type<>'TEACHER'" % LIVE, ()),
        # ★ 2026-10-22 둘러보기 ▸ 성경 연대표 — 시대(sys_era_*)와 사건·연대
        ('sys_era_code', None, ()),
        ('sys_era_span', None, ()),
        ('sys_timeline_event', LIVE, ()),
        ('sys_timeline_date', LIVE, ()),
        # ★ 2026-10-25 연대표 사건의 구절 여럿 · 장소 용어(통합 연결 표 · 언어 중립)
        ('sys_link_asset', "%s AND link_type IN ('TLEV_VERS','TLEV_ENTI')" % LIVE, ()),
        # ★ 2026-10-23 둘러보기 ▸ 믿음의 발자취 — 여정 주제(인물)·경로(학설)·정류장 + **좌표 있는 장소 용어**(언어 중립 · 106개)
        #   와 그 영어 이름. 장소 설명문은 언어팩의 용어 설명(있는 것만) · 글(ROUTE_*)은 TITLE_TYPES 규칙(영어 공통 · 그 언어 언어팩).
        ('sys_place_route_theme', LIVE, ()),
        ('sys_place_route', LIVE, ()),
        ('sys_place_route_stop', LIVE, ()),
        # ★ 2026-10-28 성지순례 도로(거리·시간·선 모양 · db_place_road) — 2026-10-29 PC 계산(GH_PC)으로(외부와 거리 차 중앙 4.5% · 외부 공개 서버는 시험용)
        ('sys_place_road', "src='GH_PC'", ()),
        ('sys_entity_master', "%s AND entity_type='PLACE' AND geo_lat IS NOT NULL" % LIVE, ()),
        # 장소↔단락(sys_entity_pericope · 장소 카드 「연결 구절」 — 장소는 ENTI_VERS 가 거의 없고 단락·정류장 약명으로 이어진다)
        ('sys_entity_pericope', '%s AND entity_id IN (%s)' % (LIVE, _GEO), ()),
        # ★ 2026-10-29 장소 ↔ 구절(원어 앵커 db_place_anchor · 사람 연결 포함) — 성경 본문의 장소 칩 · 장소 카드 「이 장소가 나오는 구절」
        ('sys_entity_verse', '%s AND entity_id IN (%s)' % (LIVE, _GEO), ()),
        # ★ 2026-10-23 둘러보기 ▸ 성경 유적 사진 — 사진 링크(작다 · 그림 없음). 사진 자체는 사진 팩(photo_body)
        ('sys_photo_link', LIVE, ()),
        ('sys_pilgrim_site', "status='LIVE' AND COALESCE(same_place,0)=0", ()),   # 성경 장소 그 자체인 것은 빼고(두 번 뜨지 않게)
        ('sys_pilgrim_base', "COALESCE(record_status,'LIVE')='LIVE'", ()),   # ★ 2026-10-29 거점(숙박 도시)
        ('sys_pilgrim_base_road', None, ()),
        ('sys_pilgrim_leg', "COALESCE(record_status,'LIVE')='LIVE'", ()),
        ('sys_pilgrim_walk_zone', None, ()),                                  # ★ 2026-10-30 도보 구역 · 추천 걷기 코스
        ('sys_pilgrim_walk_course', None, ()),
        ('sys_pilgrim_walk_path', None, ()),
        ('sys_pilgrim_line', None, ()),                                       # ★ 2026-10-30 거점·10km 단계의 도로 선 모양                                  # ★ 2026-10-30 실제 걷는 길(도보 엔진)
        ('sys_pilgrim_near', None, ()),                                       # ★ 장소 ↔ 장소 도로 거리(둘레 넓히기)   # ★ 2026-10-29 구간(12 + 확장)                                  # ★ 거점 → 둘레 차 시간   # ★ 2026-10-28 순례 장소(승인한 것만)
        ('sys_text_asset', "%s AND text_type='ENTITY_NAME' AND UPPER(lang_code)='EN' AND clicked_id IN (%s)" % (LIVE, _GEO), ()),
        ('sys_ai_guard', "UPPER(lang_code)='EN' AND %s" % LIVE, ()),
        # ★ 관리자 추천 구절 — 폰 홈 「오늘의 말씀」 재료(PC 시작화면과 같은 규칙).
        ('sys_verse_highlight', "highlight_type='FEATURED' AND %s" % LIVE, ()),
        # ★ 말씀카드 세부마다 추천 구절 + 한 줄 설명(모든 언어 · 작다) — 2026-10-21
        ('sys_card_verse', LIVE, ()),
        ('sys_card_verse_text', None, ()),
        ('sys_verse_topic', LIVE, ()),       # ★ 2026-10-29 때에 맞는 말씀 주제(구절은 위 sys_card_verse 와 같은 표)
        # ★ 앱 소개 글(모든 언어 · 수 KB) — 처음 깐 폰의 바탕(그 뒤로는 앱 소개를 열 때 app_info.json 을 받는다)
        ('sys_app_info', None, ()),
        # ★ 2026-10-22 (docs/1.txt 7-8) 외부주석링크 — 사이트(주소 틀) + 사이트별 책 이름(792줄). 주소는 폰이 틀로 짓는다
        #   (PC sys_ref_verse_map 은 34만 줄이 거의 다 틀로 지은 AUTO — 사람이 고친 줄만 싣는다).
        ('sys_ref_site', "%s AND is_active=1 AND (media_type IN ('COMMENTARY','SERMON') OR scope IN ('STRONG','ENTITY'))" % LIVE, ()),
        # ★ 2026-10-25 (docs/1.txt 2-5) 용어·원어 외부 링크 — **열리는 것만**(db_ext_link_check 가 미리 잰다 · is_active)
        ('sys_ref_entity_url', "%s AND is_active=1 AND http_status=200" % LIVE, ()),
        ('sys_ref_site_bookmap', None, ()),
        ('sys_ref_verse_map', "map_status<>'AUTO'", ()),
        # ★ 원어(2026-10-10 1.txt 54) — 언어와 상관없다: 낱말 사전(뜻은 영어) + 절 → 낱말.
        #   절별 출현 목록(verse_ids)은 싣지 않는다 — 폰은 「이 낱말이 나오는 구절」을 절 → 낱말 표로 거꾸로 찾는다.
        ('sys_lemma_master', LIVE, ()),
        ('sys_verse_lemma', None, ()),
        # ★ 2026-10-24 폰이 관리자 소통 통로로 바로 보낸다(채널·상품 추천 · PC 동기화와 상관없이) — PC user_feedback 과 같은
        #   주소·약한 표식(비밀 아님) + 구글 일시 중단 스위치. ⚠ 키·비밀은 여기 없다(secret_store).
        ('sys_config', "config_key IN ('SUPPORT_ENDPOINT_URL','SUPPORT_SECRET','GCLOUD_PAUSED')", ()),
    ]


# 연구자료 = 우리가 쓴 글(STUDY)만 — 문답·사전 같은 수입 자료집은 내서재 몫(1.txt 54)
_STUDY = "SELECT ref_src_id FROM sys_ref_source WHERE src_type='STUDY' AND %s" % LIVE
# 용어 = 그 언어 설명문이 있는 것만 — 이름뿐인 TERM 11,000개는 원어 사전과 겹친다
_ENT = ("SELECT clicked_id FROM sys_text_asset WHERE text_type='ENTITY_DESC' AND UPPER(lang_code)=? AND %s"
        % LIVE)


def spec_lang(conn, lang):
    """**언어팩** — 그 언어의 것만(대표 역본 · 설명문 · 영상 · 화면 글자 …). 영어의 기본분은 공통에 있다."""
    L = lang.upper()
    a, b = _gen1(conn)
    q_ent = ('commentary_id IN (SELECT commentary_id FROM sys_commentary_source WHERE %s) '
             'AND %s AND start_vid BETWEEN ? AND ?' % (LIVE, LIVE))
    v = version_for(L)
    out = []
    if v and v != 'BSB':
        out.append(('bible_content', 'version_code=?', (v,)))
    out.append(('sys_text_asset',
                "%s AND ((text_type IN (%s) AND UPPER(lang_code)=? AND COALESCE(text_variant,'') IN ('','LAY'))"
                " OR (text_type IN ('VERS_DESC','VERS_QUESTION') AND UPPER(lang_code)=? AND text_variant='EXPERT')"
                # ★ 2026-10-26 분야별 도움말 — text_variant 가 분야 코드(S_*·L_*)라 위 거르개에 안 걸린다
                " OR (text_type='VERS_ROLE_TIP' AND UPPER(lang_code)=?)%s)"
                % (LIVE, ','.join('?' * len(TEXT_TYPES)),
                   '' if L == 'EN' else " OR (text_type IN (%s) AND UPPER(lang_code)=?)"
                   % ','.join('?' * len(TITLE_TYPES))),
                TEXT_TYPES + (L, L, L) + (() if L == 'EN' else TITLE_TYPES + (L,))))
    # ★ 2026-10-12 영상(설교·찬양·기도)은 언어팩에 없다 — 모든 언어를 「유튜브 팩」 하나로 보낸다(youtube_body).
    #   사용자 「유투브 영상은 언어팩 없이 하나로 · 음악은 언어를 초월한다 · 외국어 설교도 한번쯤」.
    # ★ 2026-10-20 연구자료는 따로 팩(spec_ref · MREF) — 받고 지우는 것을 사람이 정한다(docs/1.txt 7-4)
    # 주요용어 — 그 언어 설명문이 있는 것(이름·설명 · 그 용어가 걸린 구절 · 닻 낱말)
    out += [
        ('sys_entity_master', '%s AND entity_id IN (%s)' % (LIVE, _ENT), (L,)),
        ('sys_text_asset', "%s AND text_type IN ('ENTITY_NAME','ENTITY_DESC','ENTITY_COV_TAG','ENTITY_COV_ROLE') AND UPPER(lang_code)=? "
         'AND clicked_id IN (%s)' % (LIVE, _ENT), (L, L)),
        # ★ 2026-10-29 장소↔구절은 공통팩에(언어 무관 · db_place_anchor) — 여기서는 빼야 두 팩이 같은 줄을 안 다툰다
        ('sys_entity_verse', '%s AND entity_id IN (%s) AND entity_id NOT IN (%s)' % (LIVE, _ENT, _GEO), (L,)),
        # ★ 2026-10-22 절 단위 연결설명문(언약 구절 한 줄 설명 등) — 그 언어 · 그 용어의 것만
        ('sys_text_asset', "%s AND text_type='ENTITY_VERSE_DESC' AND UPPER(lang_code)=? AND clicked_id IN "
         "(SELECT sys_link_id FROM sys_link_asset WHERE link_type='ENTI_VERS' AND clicked_id IN (%s))" % (LIVE, _ENT), (L, L)),
        ('sys_entity_lemma', '%s AND entity_id IN (%s)' % (LIVE, _ENT), (L,)),
    ]
    # ★ 2026-10-23 발자취 — 장소·여정 인물의 이름은 설명문이 없어도 그 언어로(영어는 공통팩에)
    out.append(('sys_text_asset', "%s AND text_type='ENTITY_NAME' AND UPPER(lang_code)=? AND clicked_id IN (%s)"
                % (LIVE, _GEO), (L,)))
    if L != 'EN':
        # 그 언어 이름이 없는 용어는 영어 이름으로 보인다
        out.append(('sys_text_asset', "%s AND text_type='ENTITY_NAME' AND UPPER(lang_code)='EN' "
                    'AND clicked_id IN (%s)' % (LIVE, _ENT), (L,)))
        out += [
            ('sys_commentary_text',
             'entry_id IN (SELECT entry_id FROM sys_commentary_entry WHERE %s) AND UPPER(lang_code)=? AND %s'
             % (q_ent, LIVE), (a, b, L)),
            ('sys_ai_guard', 'UPPER(lang_code)=? AND %s' % LIVE, (L,)),
            # ★ 2026-10-22 가계도 카드 글 — 그 언어 + 영어(폴백)
            # KO 행도 싣는다 — 인물의 group_card_id 가 KO 카드 번호를 가리켜 열쇠(card_key)를 거기서 찾는다
            ('sys_genealogy_card', "%s AND lineage_type IN ('MESSIANIC','BOTH') AND UPPER(lang_code) IN (?, 'EN', 'KO')" % LIVE, (L,)),
        ]
    return out


def spec_ref(conn, lang):
    """**연구자료 팩** — 그 언어 본문이 있는 우리 글(STUDY) + 구절 연결 + 표(2026-10-20 언어팩에서 뗐다)."""
    L = lang.upper()
    units = ("ref_src_id IN (%s) AND %s AND ref_unit_id IN "
             "(SELECT ref_unit_id FROM sys_ref_text WHERE UPPER(lang_code)=? AND %s)" % (_STUDY, LIVE, LIVE))
    return [
        ('sys_ref_source', "src_type='STUDY' AND %s" % LIVE, ()),
        ('sys_ref_unit', units, (L,)),
        ('sys_ref_text', 'UPPER(lang_code)=? AND %s AND ref_unit_id IN '
         '(SELECT ref_unit_id FROM sys_ref_unit WHERE ref_src_id IN (%s))' % (LIVE, _STUDY), (L,)),
        # ★ 2026-10-22 (docs/1.txt 7-6) 용어 ↔ 연구노트(REFU_ENTI)도 — 폰 원어 탭의 용어 아래에 그 용어의 연구/설교노트
        ('sys_link_asset', "%s AND link_type IN ('REFU_VERS','REFU_ENTI') AND clicked_id IN "
         "(SELECT ref_unit_id FROM sys_ref_unit WHERE %s)" % (LIVE, units), (L,)),
        # ★ 2026-10-15 연구노트 표(본문 자리표 [[Tn]]) — 폰은 보여주기만 · 칸 글은 그 언어 + 물러설 EN·KO
        ('sys_ref_table', '%s AND ref_unit_id IN (SELECT ref_unit_id FROM sys_ref_unit WHERE %s)' % (LIVE, units), (L,)),
        ('sys_ref_table_text', "UPPER(lang_code) IN (?,'EN','KO') AND table_id IN (SELECT table_id FROM sys_ref_table "
         'WHERE %s AND ref_unit_id IN (SELECT ref_unit_id FROM sys_ref_unit WHERE %s))' % (LIVE, units), (L, L)),
    ]


# ★ 2026-10-20 (docs/1.txt 7-4 「성경버전 다운로드 기능이 없다」) — 역본 팩(MVER).
#   BSB(공통팩)와 언어마다의 대표 역본(언어팩)은 **안 만든다** — 같은 본문이 두 팩에 들면 절이 두 번 보인다.
#   저작권 미확인·유료 역본도 안 만든다.
def ver_codes(conn):
    reps = {version_for(L) for L in langs_all(conn)} | {'BSB'}
    out = []
    for code, cr in conn.execute("SELECT version_code, COALESCE(copyright_type,'') FROM bible_version ORDER BY version_code"):
        if code in reps or cr not in ('PUBLIC_DOMAIN', 'PERMISSIVE'):
            continue
        if conn.execute('SELECT 1 FROM bible_content WHERE version_code=? LIMIT 1', (code,)).fetchone():
            out.append(code)
    return out


def spec_ver(conn, code):
    return [('bible_content', 'version_code=?', (code,))]


def comm_codes(conn):
    """본문이 있는 주석 코드들(폰 주석 팩 갈래)."""
    return [r[0] for r in conn.execute(
        "SELECT s.commentary_code FROM sys_commentary_source s WHERE %s AND EXISTS (SELECT 1 FROM sys_commentary_entry e "
        "JOIN sys_commentary_text t ON t.entry_id=e.entry_id WHERE e.commentary_id=s.commentary_id) "
        "ORDER BY s.commentary_id" % LIVE)]


def spec_comm(conn, code):
    """★ 2026-10-28 주석 팩 — 그 주석의 본문 전부(모든 언어 · 변형) · 맛보기(창 1장)는 공통·언어팩에 이미 있어 뺀다
    (같은 줄을 두 팩이 쥐면 한 팩을 지울 때 엉킨다). 항목(entry)은 공통에 전부 있다."""
    a, b = _gen1(conn)
    ent = ("SELECT entry_id FROM sys_commentary_entry WHERE commentary_id IN (SELECT commentary_id FROM sys_commentary_source "
           "WHERE commentary_code=?) AND %s AND NOT (start_vid BETWEEN ? AND ?)" % LIVE)
    return [('sys_commentary_text', 'entry_id IN (%s) AND %s' % (ent, LIVE), (code, a, b))]


def spec(conn, lang):
    """(옛 이름) 한 언어의 코어 = 공통 + 그 언어팩 — 무엇이 얼마나 실리나(`--plan`)를 보이는 데만 쓴다."""
    return spec_common(conn) + spec_lang(conn, lang)



# 원어 사전 — 폰이 쓰는 칸만(절별 출현 목록 verse_ids · KJV 뜻풀이 · 어원은 안 싣는다)
LEMMA_COLS = ('strong', 'lang_code', 'form', 'translit', 'pron', 'pos', 'gloss', 'def_en', 'occurrences',
              'n_verse', 'record_status')


def _dump(conn, table, where, args):
    import db_pack_core as PC
    cols = [r[1] for r in conn.execute('PRAGMA table_info(%s)' % table)]
    if not cols:
        return None
    if table == 'sys_media_asset':
        cols = [c for c in cols if c in MEDIA_COLS]
    if table == 'sys_lemma_master':
        cols = [c for c in cols if c in LEMMA_COLS]
    if table == 'sys_splash_image':
        cols = [c for c in cols if c in PHOTO_COLS]
    src = table
    if table == 'sys_entity_verse':
        # ★ 2026-10-22 용어↔구절의 정본은 `sys_link_asset(ENTI_VERS)` 다(2026-08-24 통합) — `sys_entity_verse` 는 옛 표라
        #   그대로 실으면 폰이 옛 연결(2만)만 본다(실측 정본 5.3만 · 옛 표에만 있는 것 1.9천). 정본을 옛 표 모양으로 바꿔 싣는다
        #   (폰 코드·열쇠 이름 그대로) + end_id(구간) · link_kind = rel_code(THEMATIC · LEXICAL · COV_* …).
        cols = ['ev_id', 'entity_id', 'verse_id', 'link_kind', 'lemma_id', 'is_key', 'sort_order', 'record_status', 'end_id']
        src = ("(SELECT sys_link_id ev_id, clicked_id entity_id, target_id verse_id, COALESCE(rel_code,'THEMATIC') link_kind, "
               "lemma_id, COALESCE(is_key,0) is_key, COALESCE(sort_order,0) sort_order, record_status, end_id "
               "FROM sys_link_asset WHERE link_type='ENTI_VERS')")
    sql = 'SELECT %s FROM %s' % (','.join(cols), src) + (' WHERE ' + where if where else '')
    rows = [[PC._enc(v) for v in r] for r in conn.execute(sql, args)]
    return {'cols': cols, 'rows': rows}


def is_common(key):
    return str(key).upper() == COMMON


def set_of(lang):
    """한 언어 사용자가 폰에 담는 코어 = **공통 + 그 언어팩** 두 파일의 열쇠."""
    return [COMMON, lang.upper()]


def build_body(conn, key):
    """key = 'COMMON'(공통 코어팩) 또는 언어 코드(언어팩).

    ★ 만든 때를 안 담는다 — 내용이 같으면 파일도 같아(sha) 폰에 다시 안 보낸다.
    """
    if is_common(key):
        body = {'format': FORMAT, 'kind': 'MCORE', 'key': COMMON, 'lang': '-', 'variant': '-',
                'release': 0, 'made_at': '', 'tables': {}}
        sp = spec_common(conn)
    elif str(key).startswith('VER:'):
        code = key[4:]
        lg = (conn.execute('SELECT lang_code FROM bible_version WHERE version_code=?', (code,)).fetchone() or ['-'])[0]
        body = {'format': FORMAT, 'kind': 'MVER', 'key': code, 'lang': str(lg).upper(), 'variant': '-',
                'release': 0, 'made_at': '', 'tables': {}}
        sp = spec_ver(conn, code)
    elif str(key).startswith('REF:'):
        body = {'format': FORMAT, 'kind': 'MREF', 'key': '-', 'lang': key[4:].upper(), 'variant': '-',
                'release': 0, 'made_at': '', 'tables': {}}
        sp = spec_ref(conn, key[4:])
    elif str(key).startswith('COMM:'):
        body = {'format': FORMAT, 'kind': 'MCOMM', 'key': key[5:], 'lang': '-', 'variant': '-',
                'release': 0, 'made_at': '', 'tables': {}}
        sp = spec_comm(conn, key[5:])
    else:
        body = {'format': FORMAT, 'kind': 'MLANG', 'key': '-', 'lang': key.upper(), 'variant': '-',
                'release': 0, 'made_at': '', 'tables': {}}
        sp = spec_lang(conn, key)
    for t, w, a in sp:
        d = _dump(conn, t, w, a)
        if d is None:
            continue
        if t in body['tables']:                      # 같은 표가 두 줄(sys_link_asset 등)이면 잇는다
            body['tables'][t]['rows'] += d['rows']
        else:
            body['tables'][t] = d
    return body


def file_name(key):
    if is_common(key):
        return COMMON_FILE
    if str(key).startswith('VER:'):
        return 'mobile_ver_%s.json.gz' % key[4:]
    if str(key).startswith('REF:'):
        return 'mobile_ref_%s.json.gz' % key[4:].upper()
    if str(key).startswith('COMM:'):
        return 'mobile_comm_%s.json.gz' % key[5:]
    return 'mobile_lang_%s.json.gz' % key.upper()




def build(conn, key, out_dir=OUT_DIR):
    body = build_body(conn, key)
    if is_common(key) and not body['tables'].get('bible_content', {}).get('rows'):
        raise ValueError('성경 본문(BSB)이 없다')          # 빈 팩은 만들지 않는다
    if not any(t.get('rows') for t in body['tables'].values()):
        raise ValueError('담을 것이 없다: %s' % key)
    if str(key).startswith('REF:') and not body['tables'].get('sys_ref_unit', {}).get('rows'):
        raise ValueError('그 언어 연구자료가 없다: %s' % key)      # 빈 껍데기 팩은 안 만든다(§0-1)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, file_name(key))
    raw = json.dumps(body, ensure_ascii=False, sort_keys=True).encode('utf-8')
    import secret_store as _SS          # ★ 2026-10-11 — 열쇠가 섞였으면 내보내지 않는다(③)
    _SS.assert_clean(raw, file_name(key))
    tmp = path + '.tmp'
    with open(tmp, 'wb') as fo:
        with gzip.GzipFile(fileobj=fo, mode='wb', compresslevel=6, mtime=0) as f:
            f.write(raw)
    os.replace(tmp, path)
    return path, len(raw), os.path.getsize(path), hashlib.sha1(raw).hexdigest()[:12]


# ══════════════════════════════════════════════════════════════════════
#  도서·설교집 — PC 가 가진 책 가운데 사람이 고른 것만 폰으로(2026-10-08 사용자
#  「Pc에서 다운로드 한 것 중에서 모바일로 전송하면 된다」) · 서버에 안 올린다
# ══════════════════════════════════════════════════════════════════════
BOOK_TABLES = ('sys_book_asset', 'sys_book_asset_text', 'sys_book_unit', 'sys_book_unit_text')
BOOK_VARIANTS_ANY = ('ORIGINAL', 'MODERN_EN')        # 원문(언어 무관) · 현대 영어
BOOK_VARIANTS_L = ('TRANSLATED', 'SUMMARY')           # 그 언어 번역


def book_spec(conn, book_code, lang):
    """책 한 권 팩의 정의 — (표, WHERE, 인자)."""
    L = lang.upper()
    two = (L, 'EN') if L != 'EN' else ('EN', 'EN')
    bid = 'book_id IN (SELECT book_id FROM sys_book_asset WHERE book_code=?)'
    uid = ('unit_id IN (SELECT unit_id FROM sys_book_unit WHERE %s AND %s)' % (bid, LIVE))
    return [
        ('sys_book_asset', 'book_code=? AND %s' % LIVE, (book_code,)),
        ('sys_book_asset_text', '%s AND UPPER(lang_code) IN (?,?) AND %s' % (bid, LIVE),
         (book_code,) + two),
        ('sys_book_unit', '%s AND %s' % (bid, LIVE), (book_code,)),
        ('sys_book_unit_text',
         "%s AND %s AND (text_variant IN ('ORIGINAL','MODERN_EN') OR "
         "(text_variant IN ('TRANSLATED','SUMMARY') AND UPPER(lang_code)=?))" % (uid, LIVE),
         (book_code, L)),
    ]


def book_body(conn, book_code, lang):
    body = {'format': FORMAT, 'kind': 'MBOOK', 'key': book_code, 'lang': lang.upper(),
            'variant': '-', 'release': 0, 'made_at': '', 'tables': {}}
    for t, w, a in book_spec(conn, book_code, lang):
        d = _dump(conn, t, w, a)
        if d is not None:
            body['tables'][t] = d
    return body


# ══════════════════════════════════════════════════════════════════════
#  사진(2026-10-11) — 폰 홈 「오늘의 말씀」 사진 카드 · 공유할 때 사진 고르기
#  ★ PC 가 지금 가진 사진(받은 사진팩의 「추가」/「교체」가 이미 반영된 것)을 그대로 비춘다 —
#    폰과 PC 가 같은 사진을 쓴다. 카드용(1080×729 JPEG)만 싣는다(시작화면용은 폰에 필요 없다).
# ══════════════════════════════════════════════════════════════════════
PHOTO_COLS = ('img_id', 'name', 'scene', 'basic', 'photo_pack', 'is_active', 'jpg_card', 'continent', 'country')
PHOTO_FILE = 'mobile_photo.json.gz'
# ★ 2026-10-23 사용자 「사진팩이 크다면 별도 팩으로 분리」·「작은 것만 샘플로 필수팩에 넣어라」 —
#   유적 사진 원본(jpg)이 51 MB 라 필수 사진팩이 53 MB 가 됐다(jsDelivr 20 MB · GitHub 50 MB 경고를 넘었다).
#   필수(MPHOTO) = 말씀 카드 사진 + 유적 사진 **작은 그림 전부** + 원본은 **작은 샘플 몇 장만**.
#   나머지 원본 = 따로 받는 팩(MSPHOTO) — 조각마다 그림 바이트 SITE_PART_MAX 아래(jsDelivr 가 줄 수 있게).
#: ★ 2026-10-25 카드 사진 작은 그림(사진 관리 원칙 — coding.md) · 폰 목록이 1080x1350 원본을 통째로 읽고 있었다
CARD_THUMB = (400, 270)   # ★ 2026-10-30 카드가 가로로 긴 모양이 됐다(1080×729)
CARD_THUMB_Q = 80


def card_thumb(jpg):
    """카드 그림(1080x729 JPEG) → 목록용 작은 그림(400x270 JPEG) · 못 만들면 None."""
    if not jpg:
        return None
    try:
        import io as _io
        from PIL import Image
        im = Image.open(_io.BytesIO(jpg)).convert('RGB')
        im.thumbnail(CARD_THUMB, Image.LANCZOS)
        out = _io.BytesIO()
        im.save(out, 'JPEG', quality=CARD_THUMB_Q, optimize=True)
        return out.getvalue()
    except Exception:                                   # noqa: BLE001
        return None


SITE_FILE = 'mobile_sitephoto_%d.json.gz'
SITE_PART_MAX = 17_000_000          # 조각 하나의 원본 그림 합(바이트) — gzip 뒤 ≈ 18 MB · jsDelivr 한도 20 MB 아래
SAMPLE_MAX = 8                      # 필수팩에 원본을 싣는 샘플 수 — 곳마다 가장 작은 한 장 가운데 작은 것부터
SAMPLE_BYTES = 2_000_000            # 샘플 원본 합 상한


def site_samples(conn):
    """필수팩에 원본을 싣는 유적 사진 번호 — 곳마다 가장 작은 사진 한 장, 그 가운데 작은 것부터 SAMPLE_MAX 장 · 합 SAMPLE_BYTES 이하."""
    best = {}
    for pid, eid, n in conn.execute("SELECT photo_id, entity_id, LENGTH(jpg) FROM sys_site_photo "
                                    "WHERE COALESCE(record_status,'LIVE')='LIVE' AND jpg IS NOT NULL"):
        if eid not in best or n < best[eid][1]:
            best[eid] = (pid, n)
    out, tot = [], 0
    for pid, n in sorted(best.values(), key=lambda x: x[1]):
        if len(out) >= SAMPLE_MAX or tot + n > SAMPLE_BYTES:
            break
        out.append(pid)
        tot += n
    return sorted(out)


def site_parts(conn, skip=()):
    """샘플을 뺀 원본을 조각으로 → [[photo_id …] …] · 조각마다 원본 합 SITE_PART_MAX 이하(차례 = 사진 번호)."""
    parts, cur, tot = [], [], 0
    for pid, n in conn.execute("SELECT photo_id, LENGTH(jpg) FROM sys_site_photo WHERE COALESCE(record_status,'LIVE')='LIVE' "
                               "AND jpg IS NOT NULL ORDER BY photo_id"):
        if pid in skip:
            continue
        if cur and tot + n > SITE_PART_MAX:
            parts.append(cur)
            cur, tot = [], 0
        cur.append(pid)
        tot += n
    if cur:
        parts.append(cur)
    return parts


def photo_body(conn):
    body = {'format': FORMAT, 'kind': 'MPHOTO', 'key': 'ALL', 'lang': '-', 'variant': '-',
            'release': 0, 'made_at': '', 'tables': {}}
    for t, w, a in (('sys_splash_image', "COALESCE(is_active,1)=1 AND jpg_card IS NOT NULL", ()),
                    # ★ 2026-10-23 유적 사진(jpg 1600 + 작은 그림) — 둘러보기 ▸ 성경 유적 사진
                    ('sys_site_photo', LIVE, ()),          # ★ 원본(jpg)은 샘플만 — 아래에서 걷는다
                    ('sys_scene_map', "COALESCE(record_status,'LIVE')='LIVE'", ()),
                    ('sys_scene_pack', None, ()),
                    ('sys_config', "config_key='PHOTO_CREDIT'", ()),
                    # 사진 설명(찍은 곳 등 · 2026-10-11) — 모든 언어 · 카드가 있는 사진만
                    ('sys_text_asset', "text_type IN ('SPLASH_TITLE','SPLASH_DESC','PHOTO_AI') "
                     "AND COALESCE(record_status,'LIVE')='LIVE' AND clicked_id IN (SELECT img_id FROM "
                     "sys_splash_image WHERE COALESCE(is_active,1)=1 AND jpg_card IS NOT NULL)", ())):
        d = _dump(conn, t, w, a)
        if d is not None:
            body['tables'][t] = d
    si = body['tables'].get('sys_splash_image')
    if si and 'jpg_card' in si['cols']:
        # ★ 2026-10-25 목록용 작은 그림 칸 `thumb_card` — 실을 때 만든다(원본 표에는 안 둔다 · 카드 그림이 바뀌면 저절로 따라온다)
        import db_pack_core as PC
        ji = si['cols'].index('jpg_card')
        si['cols'].append('thumb_card')
        for r in si['rows']:
            raw = PC.dec(r[ji])
            r.append(PC._enc(card_thumb(raw)))
    sp = body['tables'].get('sys_site_photo')
    if sp:
        keep = set(site_samples(conn))
        ji, ii = sp['cols'].index('jpg'), sp['cols'].index('photo_id')
        for r in sp['rows']:
            if r[ii] not in keep:
                r[ji] = None
    return body


def site_body(conn, ids, part):
    """유적 사진 원본 조각 — 표 `sys_site_photo_jpg(photo_id, jpg)` · 폰은 필수팩에 원본이 없을 때 여기서 읽는다."""
    import db_pack_core as PC
    q = ','.join('?' * len(ids))
    rows = [[pid, PC._enc(b)] for pid, b in conn.execute(
        'SELECT photo_id, jpg FROM sys_site_photo WHERE photo_id IN (%s) ORDER BY photo_id' % q, list(ids))]
    return {'format': FORMAT, 'kind': 'MSPHOTO', 'key': str(part), 'lang': '-', 'variant': '-',
            'release': 0, 'made_at': '', 'tables': {'sys_site_photo_jpg': {'cols': ['photo_id', 'jpg'], 'rows': rows}}}


def build_site_photos(conn, out_dir):
    """원본 조각 팩 전부 → [(경로, 원본 바이트, gzip 바이트, sha)] · 옛 조각(더 많던 번호)은 걷는다."""
    os.makedirs(out_dir, exist_ok=True)
    parts = site_parts(conn, set(site_samples(conn)))
    out = []
    for i, ids in enumerate(parts, 1):
        body = site_body(conn, ids, i)
        raw = json.dumps(body, ensure_ascii=False, sort_keys=True).encode('utf-8')
        import secret_store as _SS
        _SS.assert_clean(raw, SITE_FILE % i, blob_free=json.dumps(_no_blobs(body), ensure_ascii=False).encode('utf-8'))
        path = os.path.join(out_dir, SITE_FILE % i)
        with open(path, 'wb') as fo:
            with gzip.GzipFile(fileobj=fo, mode='wb', compresslevel=6, mtime=0) as f:
                f.write(raw)
        out.append((path, len(raw), os.path.getsize(path), hashlib.sha1(raw).hexdigest()[:12]))
    for n in os.listdir(out_dir):
        m = re.match(r'mobile_sitephoto_(\d+)\.json\.gz$', n)
        if m and int(m.group(1)) > len(parts):
            os.remove(os.path.join(out_dir, n))
    return out


def _no_blobs(x):
    """그림 바이트(base64)를 걷은 사본 — ★ 2026-10-23 사진 바이트의 아무 글자가 키 모양(AIza…)에 우연히 맞는다(실측).
    키 모양 검사는 이 사본에만 하고, 저장된 열쇠 그대로 찾기는 팩 전체에 한다(secret_store.assert_clean)."""
    import db_pack_core as PC
    if isinstance(x, dict):
        if PC.B64 in x and len(x) == 1:
            return ''
        return {k: _no_blobs(v) for k, v in x.items()}
    if isinstance(x, list):
        return [_no_blobs(v) for v in x]
    return x


def build_photos(conn, out_dir):
    """→ (경로, 원본 바이트, gzip 바이트, sha) · 카드 사진이 하나도 없으면 ValueError."""
    body = photo_body(conn)
    if not body['tables'].get('sys_splash_image', {}).get('rows'):
        raise ValueError('카드 사진이 없다 — 관리자 「시작화면·말씀카드 사진」에서 [다시 만들기]')
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, PHOTO_FILE)
    raw = json.dumps(body, ensure_ascii=False, sort_keys=True).encode('utf-8')
    import secret_store as _SS          # ★ 2026-10-11 — 열쇠가 섞였으면 내보내지 않는다(③)
    _SS.assert_clean(raw, PHOTO_FILE, blob_free=json.dumps(_no_blobs(body), ensure_ascii=False).encode('utf-8'))
    with open(path, 'wb') as fo:
        with gzip.GzipFile(fileobj=fo, mode='wb', compresslevel=6, mtime=0) as f:
            f.write(raw)
    return path, len(raw), os.path.getsize(path), hashlib.sha1(raw).hexdigest()[:12]


# ── 찬양 팩 (2026-10-11 사용자 「언어별 찬양 팩 · 영어는 공통」) ─────────────────────────────
#   공통(WOR_COMMON) = 곡·판·찬양팀 + 그 이름(모든 언어) + 영어 찬양 영상 · 언어(WOR_L) = 그 언어 찬양 영상.
#   ★ 폰 표 이름은 `wor_*` 로 따로 둔다 — 언어팩의 sys_media_asset 에 같은 영상이 또 들어가면 구절 판에 두 번 뜬다
#     (폰 적재기는 기본 키 없이 넣는다). 찬양 탭은 wor_* 만 읽는다.
#   ⚠ 가사(sys_song.lyrics)·메모는 안 싣는다(저작권 · 관리자 글).
# ★ 2026-10-16 채널 이름 — 폰 채널 ♥·숨김(PC `media_pref` 와 같은 열쇠 = 설명문 JSON 의 channel).
#   설명문 자체는 안 싣는다(저작권) — 이름 한 칸만 뽑는다. 깨진 JSON 이면 빈칸.
CHANNEL_SQL = ("TRIM(COALESCE(CASE WHEN json_valid(description) THEN json_extract(description,'$.channel') END,'')) channel")
# ★ 2026-10-22 유튜브 실제 게시일(유튜브가 알려 준 published) — 폰 유튜브 「최신」이 게시일 순으로 세운다(배포한 날 아님)
PUBLISHED_SQL = ("TRIM(COALESCE(CASE WHEN json_valid(description) THEN json_extract(description,'$.published') END,'')) published")
YT_FILE = 'mobile_youtube.json.gz'          # ★ 2026-10-12 유튜브 팩 — 설교·찬양·기도 영상 모든 언어 하나
YT_KEY = 'ALL'
WOR_TEXT = ('SONG_TITLE', 'SONG_REND_TITLE', 'ARTIST_NAME', 'SONG_ALIAS')


def worship_body(conn, key, all_langs=False):
    """→ 팩 몸통(MWOR). key = 'COMMON' 또는 언어 코드 · all_langs = 영상을 모든 언어로(유튜브 팩)."""
    common = is_common(key)
    L = 'EN' if common else str(key).upper()
    body = {'format': FORMAT, 'kind': 'MWOR', 'key': 'COMMON' if common else L, 'lang': '-' if common else L,
            'variant': '-', 'release': 0, 'made_at': '', 'tables': {}}

    def put(name, sql, args=()):
        cur = conn.execute(sql, args)
        cols = [d[0] for d in cur.description]
        import db_pack_core as PC
        body['tables'][name] = {'cols': cols, 'rows': [[PC._enc(v) for v in r] for r in cur.fetchall()]}

    live = "COALESCE(record_status,'LIVE')='LIVE'"
    # ★ 2026-10-12 기도 영상도 이 팩에 싣는다(사용자 「설교/기도/찬양」) — 구절 연결이 없어도 듣는 영상이라
    #   언어팩(구절 연결분만)에는 안 들어간다. 폰은 media_type 으로 찬양·기도를 가른다.
    media_where = ("is_active=1 AND media_type IN ('WORSHIP','PRAYER') AND " +
                   ('' if all_langs else 'UPPER(lang_code)=? AND ') + live)
    ma = () if all_langs else (L,)
    put('wor_media', 'SELECT media_id, media_type, title, url, UPPER(lang_code) lang_code, format_type, '
        'COALESCE(embed_ok,1) embed_ok, ' + CHANNEL_SQL + ', ' + PUBLISHED_SQL + ' FROM sys_media_asset WHERE '
        + media_where, ma)
    put('wor_link', "SELECT link_type, clicked_id, target_id, end_id FROM sys_link_asset WHERE " + live +
        " AND link_type IN ('MEDI_REND','MEDI_ARTI') AND clicked_id IN (SELECT media_id FROM sys_media_asset WHERE "
        + media_where + ')', ma)
    if common:
        put('wor_song', 'SELECT song_id, song_code, orig_lang, orig_artist_id, genre, anchor_rend_id FROM sys_song WHERE '
            + live)
        put('wor_rend', 'SELECT rend_id, song_id, UPPER(lang_code) lang_code, artist_id, is_original, title_key '
            'FROM sys_song_rendition WHERE ' + live)
        put('wor_artist', 'SELECT artist_id, artist_code, country, kind, channel_name, is_featured '
            'FROM sys_worship_artist WHERE ' + live)
        put('wor_text', 'SELECT clicked_id, text_type, UPPER(lang_code) lang_code, contents FROM sys_text_asset '
            'WHERE text_type IN (%s) AND %s' % (','.join("'%s'" % t for t in WOR_TEXT), live))
        put('wor_verse', "SELECT clicked_id song_id, target_id, end_id FROM sys_link_asset WHERE link_type='SONG_VERS' "
            "AND " + live)
    return body


def youtube_body(conn):
    """→ 유튜브 팩 몸통(MWOR · key ALL) — 설교·찬양·기도 영상을 **모든 언어로** 하나에.

    ★ 2026-10-12 사용자 「설교영상, 찬양, 기도 등 유투브 영상은 언어팩 없이 하나로 보내자 · 나중에 용량이
      너무 커진다면 그때 분할」. 실측 11언어 합계 gzip ≈ 2.8 MB(언어팩 하나가 1.5~9.7 MB).
    · 찬양·기도 = wor_* (곡·판·팀·이름 + 영상 · media_type 으로 가른다)
    · 구절에 걸린 영상(설교 등) = sys_media_asset + sys_link_asset(MEDI_VERS) — 구절 판 · 유튜브 ▸ 설교가 읽는다.
    """
    body = worship_body(conn, 'COMMON', all_langs=True)
    body['key'] = YT_KEY
    import db_pack_core as PC
    # ★ 2026-10-23 발자취 — 장소 용어에 걸린 영상(MEDI_ENTI · PLACE)도 함께(1,720편 · 장소 카드 「유튜브」)
    _pl = ("SELECT clicked_id FROM sys_link_asset WHERE link_type='MEDI_ENTI' AND %s AND target_id IN "
           "(SELECT entity_id FROM sys_entity_master WHERE entity_type='PLACE' AND geo_lat IS NOT NULL)" % LIVE)
    for name, where in (
            ('sys_media_asset', 'is_active=1 AND %s AND (media_id IN '
             "(SELECT clicked_id FROM sys_link_asset WHERE link_type='MEDI_VERS' AND %s) OR media_id IN (%s))" % (LIVE, LIVE, _pl)),
            ('sys_link_asset', "%s AND ((link_type='MEDI_VERS') OR (link_type='MEDI_ENTI' AND target_id IN "
             "(SELECT entity_id FROM sys_entity_master WHERE entity_type='PLACE' AND geo_lat IS NOT NULL))) AND clicked_id IN "
             "(SELECT media_id FROM sys_media_asset WHERE is_active=1 AND %s)" % (LIVE, LIVE))):
        cols = [r[1] for r in conn.execute('PRAGMA table_info(%s)' % name)]
        if name == 'sys_media_asset':
            cols = [c for c in cols if c in MEDIA_COLS]
        else:
            cols = [c for c in cols if c in ('sys_link_id', 'link_type', 'clicked_id', 'target_id', 'end_id',
                                             'record_status')]
        sel = ','.join(cols) + (', ' + CHANNEL_SQL + ', ' + PUBLISHED_SQL if name == 'sys_media_asset' else '')
        cur = conn.execute('SELECT %s FROM %s WHERE %s' % (sel, name, where))
        body['tables'][name] = {'cols': [d[0] for d in cur.description],
                                'rows': [[PC._enc(v) for v in r] for r in cur.fetchall()]}
    return body


def build_youtube(conn, out_dir=OUT_DIR):
    """→ (경로, 원본 바이트, gzip 바이트, sha)."""
    body = youtube_body(conn)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, YT_FILE)
    raw = json.dumps(body, ensure_ascii=False, sort_keys=True).encode('utf-8')
    import secret_store as _SS
    _SS.assert_clean(raw, YT_FILE)
    with open(path, 'wb') as f:
        with gzip.GzipFile(fileobj=f, mode='wb', mtime=0) as g:
            g.write(raw)
    return path, len(raw), os.path.getsize(path), sha16(path)



# ★ 2026-10-28 큰 책은 성경 묶음으로 나눠 서버에 — 스펄전 설교집 한 팩이 50 MB(jsDelivr 한도 20 MB 넘음 · 사용자
#   「PC 의 8권 분류가 적절하다면 … 가장 좋은 방향으로 통일」). 묶음 = PC 본문팩과 같은 `db_pack_body.BOOK_GROUPS` 여덟.
#   · 폰에는 묶음마다 **따로 한 권**(가짜 책 번호 base+묶음 차례 · 책 코드 <원래>_<묶음>) — 한 권을 여러 팩이 나눠 쥐면
#     한 팩을 지울 때 책 줄이 함께 사라진다. 설교(편) 번호는 원래 그대로라 PC 와 읽음 기록이 맞는다(PC 는 base 를 원래 책으로 읽는다).
#   · 본문 구절이 없는 편은 뺀다(사용자 「구절과 연결되지 않았다면 의미 없다」).
SPLIT_BOOKS = {'SPURGEON_SERMONS': {'base': 1900, 'en': "Spurgeon's Sermons", 'ko': '스펄전 설교'}}
GROUP_EN = {'PENT': 'Pentateuch', 'HIST': 'Historical Books', 'POET': 'Poetry & Wisdom', 'MAJP': 'Major Prophets',
            'MINP': 'Minor Prophets', 'GOSP': 'Gospels & Acts', 'PAUL': "Paul's Letters", 'GENE': 'General Letters & Revelation'}


def split_parts(code):
    """나누는 책 → [(묶음 코드, 가짜 책 번호, 첫 책, 끝 책, 한국어 묶음 이름)] · 안 나누는 책이면 []."""
    sp = SPLIT_BOOKS.get(code)
    if not sp:
        return []
    import db_pack_body as PB
    return [(g, sp['base'] + i, a, b, nm) for i, (g, nm, a, b) in enumerate(PB.BOOK_GROUPS, 1)]


def split_of(part_code):
    """조각 책 코드(SPURGEON_SERMONS_PENT) → (원래 책 코드, 묶음 코드, 가짜 번호, 첫 책, 끝 책, 한국어 이름) | None."""
    for code in SPLIT_BOOKS:
        for g, bid, a, b, nm in split_parts(code):
            if part_code == '%s_%s' % (code, g):
                return code, g, bid, a, b, nm
    return None


def real_book_id(book_id):
    """폰의 가짜 책 번호(조각) → PC 의 원래 책 번호(모르면 그대로) — 읽던 곳 · 읽는 중 기록을 PC 책에 맞춘다."""
    try:
        b = int(book_id)
    except (TypeError, ValueError):
        return book_id
    import appdb
    for code, sp in SPLIT_BOOKS.items():
        if sp['base'] < b <= sp['base'] + 8:
            c = appdb.connect('bible_master.db')
            try:
                r = c.execute('SELECT book_id FROM sys_book_asset WHERE book_code=?', (code,)).fetchone()
            finally:
                c.close()
            return r[0] if r else b
    return b


def part_body(conn, part_code):
    """조각 한 권 팩(영어) — 원래 책의 그 묶음 편들 · 책 줄은 가짜 번호로."""
    code, g, fid, a, b, nm = split_of(part_code)
    sp = SPLIT_BOOKS[code]
    real = conn.execute('SELECT book_id FROM sys_book_asset WHERE book_code=?', (code,)).fetchone()[0]
    body = {'format': FORMAT, 'kind': 'MBOOK', 'key': part_code, 'lang': 'EN',
            'variant': '-', 'release': 0, 'made_at': '', 'tables': {}}
    d = _dump(conn, 'sys_book_asset', 'book_id=?', (real,))
    ci = {c: i for i, c in enumerate(d['cols'])}
    title_en = '%s — %s' % (sp['en'], GROUP_EN.get(g, g))
    title_ko = '%s — %s' % (sp['ko'], nm)
    for r in d['rows']:
        r[ci['book_id']] = fid
        r[ci['book_code']] = part_code
        r[ci['title']] = title_en
        if 'description' in ci:
            r[ci['description']] = ('Sermons on texts from %s, taken from the full collection.' % GROUP_EN.get(g, g))
    body['tables']['sys_book_asset'] = d
    body['tables']['sys_book_asset_text'] = {
        'cols': ['text_id', 'book_id', 'lang_code', 'title', 'author', 'description', 'record_status'],
        'rows': [[-(fid * 10 + 1), fid, 'EN', title_en, 'C.H. Spurgeon', '', 'LIVE'],
                 [-(fid * 10 + 2), fid, 'KO', title_ko, '찰스 스펄전', '', 'LIVE']]}
    uq = ('book_id=? AND %s AND start_vid IN (SELECT verse_id FROM bible_index WHERE bcode BETWEEN ? AND ?)' % LIVE)
    du = _dump(conn, 'sys_book_unit', uq, (real, a, b))
    bi = du['cols'].index('book_id')
    for r in du['rows']:
        r[bi] = fid
    body['tables']['sys_book_unit'] = du
    body['tables']['sys_book_unit_text'] = _dump(
        conn, 'sys_book_unit_text',
        "unit_id IN (SELECT unit_id FROM sys_book_unit WHERE %s) AND %s AND text_variant IN ('ORIGINAL','MODERN_EN','SUMMARY')"
        " AND UPPER(lang_code)='EN'" % (uq, LIVE), (real, a, b))
    return body


def build_part(conn, part_code, out_dir=OUT_DIR):
    body = part_body(conn, part_code)
    if not body['tables']['sys_book_unit_text']['rows']:
        raise ValueError('본문이 없는 조각: %s' % part_code)
    os.makedirs(out_dir, exist_ok=True)
    n = book_file_name(part_code, 'EN')
    path = os.path.join(out_dir, n)
    raw = json.dumps(body, ensure_ascii=False, sort_keys=True).encode('utf-8')
    import secret_store as _SS
    _SS.assert_clean(raw, n)
    with open(path, 'wb') as fo:
        with gzip.GzipFile(fileobj=fo, mode='wb', compresslevel=6, mtime=0) as f:
            f.write(raw)
    return path, len(raw), os.path.getsize(path), hashlib.sha1(raw).hexdigest()[:12]


def book_file_name(book_code, lang):
    return 'mobile_book_%s_%s.json.gz' % (book_code, lang.upper())


def build_book(conn, book_code, lang, out_dir):
    """→ (경로, 원본 바이트, gzip 바이트, sha). 본문이 없으면 ValueError(빈 팩은 안 만든다).

    ⚠ 만든 때를 몸통에 안 넣는다 — 같은 책이면 같은 sha 라야 폰에 다시 보낼지 가를 수 있다.
    """
    body = book_body(conn, book_code, lang)
    if not body['tables'].get('sys_book_unit_text', {}).get('rows'):
        raise ValueError('본문이 없는 책: %s' % book_code)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, book_file_name(book_code, lang))
    raw = json.dumps(body, ensure_ascii=False, sort_keys=True).encode('utf-8')
    import secret_store as _SS
    _SS.assert_clean(raw, book_file_name(book_code, lang))
    with open(path, 'wb') as fo:
        with gzip.GzipFile(fileobj=fo, mode='wb', compresslevel=6, mtime=0) as f:
            f.write(raw)
    return path, len(raw), os.path.getsize(path), hashlib.sha1(raw).hexdigest()[:12]


_BOOK_STATS = {}   # (지문) → {book_id: {(언어, 변형): (편 수, 글자)} , 'langs': {book_id: {언어}}}


def _book_stats(conn):
    """책마다 (언어, 변형) → (편 수, 글자 수) — 한 번의 묶음 조회 · 본문 표가 그대로면 기억한 것을 쓴다.

    ★ 2026-10-28 PC 「모바일 연결 ④」 콤보가 느리던 까닭 — 책·언어마다 본문 글자를 다시 세어
      콤보 하나에 15초가 걸렸다(실측 언어 하나 7초 · 책 41권 × 쿼리 넷). 지문 = 본문 행 수·마지막 번호.
    """
    fp = conn.execute("SELECT COUNT(*), COALESCE(MAX(text_id),0) FROM sys_book_unit_text").fetchone()
    fp = (fp[0], fp[1], conn.execute("SELECT COUNT(*) FROM sys_book_unit").fetchone()[0])
    hit = _BOOK_STATS.get('fp')
    if hit == fp:
        return _BOOK_STATS['data']
    data = {}
    for bid, lg, var, n, ch in conn.execute(
            "SELECT u.book_id, UPPER(COALESCE(t.lang_code,'')), t.text_variant, COUNT(DISTINCT u.unit_id),"
            " COALESCE(SUM(LENGTH(t.body_text)),0)"
            " FROM sys_book_unit u JOIN sys_book_unit_text t ON t.unit_id=u.unit_id"
            " WHERE COALESCE(u.record_status,'LIVE')='LIVE' AND COALESCE(t.record_status,'LIVE')='LIVE'"
            " GROUP BY 1,2,3").fetchall():
        data.setdefault(bid, {})[(lg, var)] = (n, ch)
    _BOOK_STATS['fp'] = fp
    _BOOK_STATS['data'] = data
    return data


def book_full(conn, code, lang):
    """그 팩 언어의 글이 있는 편이 원문 편 수의 90% 이상인가(조각 책은 영어 원문이라 참)"""
    if split_of(code):
        return True
    r = conn.execute('SELECT book_id FROM sys_book_asset WHERE book_code=?', (code,)).fetchone()
    if not r:
        return True
    st = _book_stats(conn).get(r[0]) or {}
    base = max([n for (_l, v), (n, _c) in st.items() if v == 'ORIGINAL'] or [0])
    here = max([n for (l, _v), (n, _c) in st.items() if l == (lang or '').upper()] or [0])
    return not base or here >= base * 0.9


def books_on_pc(conn, lang):
    """이 PC 에 본문이 있는 책 → [{code, title, kind, units, chars, has_lang}] (그 언어 제목 먼저).

    ★ 「받아 둔 것」= 이 PC 의 DB 에 본문 행이 있는 책이다 — 팩 파일은 적용 뒤 지워지므로
      DB 가 유일한 증거다(pack_status 가 받은 팩을 적용하고 지운다).
    ⚠ 편 수는 원문 쪽과 그 언어 번역 쪽 중 큰 값(번역 편은 원문 편 안에 있다) — 화면 어림이다.
    """
    L = lang.upper()
    stats = _book_stats(conn)
    titles = {}
    for bid, t in conn.execute("SELECT book_id, title FROM sys_book_asset_text WHERE UPPER(lang_code)=?"
                               " AND COALESCE(title,'')<>''", (L,)).fetchall():
        titles.setdefault(bid, t)
    out = []
    for bid, code, title, cat in conn.execute(
            "SELECT book_id, book_code, title, COALESCE(book_category,'') FROM sys_book_asset"
            " WHERE %s ORDER BY book_category, book_id" % LIVE).fetchall():
        st = stats.get(bid) or {}
        base = [v for (lg, var), v in st.items() if var in ('ORIGINAL', 'MODERN_EN')]
        tr = [v for (lg, var), v in st.items() if var in ('TRANSLATED', 'SUMMARY') and lg == L]
        units = max([n for n, _c in base + tr] or [0])
        if not units:
            continue
        out.append({'code': code, 'title': titles.get(bid) or title or code, 'kind': cat,
                    'units': units, 'chars': sum(c for _n, c in base + tr), 'has_lang': bool(tr),
                    'langs': {lg for (lg, _v) in st if lg}})
    return out


def book_intro(conn, book_code, lang):
    """책 소개 → (제목, 지은이, 소개문) — 그 언어 → 영어 → 한국어 → 책 줄."""
    row = conn.execute("SELECT book_id, title, author, description FROM sys_book_asset"
                       " WHERE book_code=?", (book_code,)).fetchone()
    if not row:
        return '', '', ''
    bid, title, author, desc = row
    for L in (lang.upper(), 'EN', 'KO'):
        r = conn.execute("SELECT title, author, description FROM sys_book_asset_text"
                         " WHERE book_id=? AND UPPER(lang_code)=? AND %s" % LIVE, (bid, L)).fetchone()
        if r and (r[2] or '').strip():
            return (r[0] or title or book_code), (r[1] or author or ''), r[2].strip()
    return title or book_code, author or '', (desc or '').strip()


def book_code_of(file_name):
    """`mobile_book_<코드>_<언어>.json.gz` → (코드, 언어) | None."""
    if not (file_name or '').startswith('mobile_book_') or not file_name.endswith('.json.gz'):
        return None
    core = file_name[len('mobile_book_'):-len('.json.gz')]
    code, _s, lg = core.rpartition('_')
    return (code, lg.upper()) if code else None


# ══════════════════════════════════════════════════════════════════════
#  서버 — 관리자는 올리고 사용자 PC 는 받는다(PC 팩과 같은 서버 · 이름만 다르다)
# ══════════════════════════════════════════════════════════════════════
UP_STATE = 'uploaded.json'


def _up_state(out_dir):
    try:
        with open(os.path.join(out_dir, UP_STATE), encoding='utf-8') as f:
            return json.load(f)
    except Exception:                                            # noqa: BLE001
        return {}


def _sig(path):
    """내용의 sha — 같은 내용을 다시 만들어도 「올림」이 안 풀린다(만든 때를 안 담으므로)."""
    with open(path, 'rb') as f:
        return hashlib.sha1(f.read()).hexdigest()


UP_TIME = 'uploaded_at.json'   # ★ 2026-10-29 파일마다 마지막으로 올린 때(epoch) — 「올림」은 만든 뒤에 올린 것만


def _up_time(out_dir):
    try:
        with open(os.path.join(out_dir, UP_TIME), encoding='utf-8') as f:
            return json.load(f)
    except Exception:                                    # noqa: BLE001
        return {}


def up_status(lang, out_dir=OUT_DIR):
    """★ 2026-10-29 있는 그대로(사용자 「만든 시간 이후로 올린 것만 올림 · 올릴필요 없음, 수정사항없음 등이 더 정확」) →
    (코드, 화면 글):
      NONE   아직 안 만듦
      UP     올림(HH:MM) — 만든 뒤에 올렸다
      SAME   수정사항 없음 · 올릴 필요 없음 — 다시 만들었지만 서버에 있는 것과 내용이 똑같다
      NEW    만듦 · 안 올림 — 한 번도 안 올렸다
      DIFF   만듦 · 바뀜 · 안 올림 — 서버에 있는 것과 내용이 다르다"""
    n = file_name(lang)
    p = os.path.join(out_dir, n)
    if not os.path.exists(p):
        return 'NONE', '아직 안 만듦'
    up = _up_state(out_dir).get(n)
    if not up:
        return 'NEW', '만듦 · 안 올림'
    if up != _sig(p):
        return 'DIFF', '만듦 · 바뀜 · 안 올림'
    at = _up_time(out_dir).get(n)
    if at and at >= os.path.getmtime(p) - 1:
        return 'UP', '올림 ' + time.strftime('%m-%d %H:%M', time.localtime(at))
    return 'SAME', '수정사항 없음 · 올릴 필요 없음'


def is_uploaded(lang, out_dir=OUT_DIR):
    p = os.path.join(out_dir, file_name(lang))
    return os.path.exists(p) and _up_state(out_dir).get(file_name(lang)) == _sig(p)


def uploaded_only(idx, st, out_dir=OUT_DIR):
    """★ 2026-10-28 서버 목록에는 **서버에 실제로 있는 판**만 — 폴더에 만들어만 둔 팩이 목록에 실려 폰이 없는 파일을
    받으려던 흠(관리자 화면이 공통·언어팩만 올리고 목록은 폴더 전부로 썼다).
      · 올린 판 그대로 = 그 줄 · 예전 판을 올리고 새로 만들어만 둔 것 = 예전 판의 지문으로(sha = 올린 파일 sha1 앞 16자)
      · 한 번도 안 올린 것 = 뺀다."""
    out = {}
    for n, e in idx.items():
        up = st.get(n)
        if not up:
            continue
        cur = _sig(os.path.join(out_dir, n)) if os.path.exists(os.path.join(out_dir, n)) else ''
        if up == cur:
            out[n] = dict(e, file=fp_name(n, e.get('sha') or up))
        else:
            out[n] = dict(e, sha=up[:16], file=fp_name(n, up))
    return out


# ★ 2026-10-29 지문 이름 — `mobile_common.<sha16>.json.gz`. 내용이 바뀌면 이름이 바뀌어 캐시(jsDelivr)가 옛 파일을 내줄 수 없다
#   (실측: 이름이 늘 같아 캐시 비우기가 막히자 폰이 옛 판을 받았다). 늘 새것이어야 하는 것은 작은 목록(mobile_index.json) 하나뿐.
#   옛 이름도 함께 올린다 — 지금 깔린 앱은 옛 이름으로 받는다(다음 앱 판부터 목록의 `file` 을 쓴다).
FP_RE = re.compile(r'^(.+)\.([0-9a-f]{16})\.json\.gz$')


def fp_name(name, sha):
    """'mobile_common.json.gz' + 지문 16자 → 'mobile_common.<지문>.json.gz'"""
    base = name[:-len('.json.gz')] if name.endswith('.json.gz') else name
    return '%s.%s.json.gz' % (base, sha[:16])


def upload(langs, servers, out_dir=OUT_DIR, names=None):
    """만든 모바일 팩을 서버에 올린다 → {'ok', 'files', 'msgs'}.

    ⚠ 바이너리(`put_bytes`) · 서버마다 `flush` · 다 된 것만 「올림」으로 적는다.
    ★ `names` 를 주면 그 파일들을 올린다(폰 팩 전부 — upload_all).
    """
    import rss_transport as RT
    if names is None:
        names = [file_name(l) for l in langs if os.path.exists(os.path.join(out_dir, file_name(l)))]
    if not names:
        return {'ok': False, 'files': [], 'msgs': ['올릴 파일이 없습니다(먼저 만드세요)']}
    msgs, ok_all, n_srv = [], True, 0
    for srv in (servers or []):
        if not srv.get('enabled', True):
            continue
        n_srv += 1
        tp = RT.make_transport(srv)
        for n in names:
            try:
                if not hasattr(tp, 'put_bytes'):
                    raise RuntimeError('이 전송 수단은 바이너리를 못 올린다')
                with open(os.path.join(out_dir, n), 'rb') as f:
                    data = f.read()
                ok, m = tp.put_bytes(n, data)
                if ok:
                    ok, m = tp.put_bytes(fp_name(n, hashlib.sha1(data).hexdigest()), data)
            except Exception as e:                               # noqa: BLE001
                ok, m = False, str(e)[:90]
            ok_all = ok_all and ok
            if not ok:
                msgs.append('%s: %s' % (n, m))
        if hasattr(tp, 'flush'):
            fok, fm = tp.flush()
            ok_all = ok_all and fok
            msgs.append('%s: %s' % (srv.get('label', '?'), fm))
    if not n_srv:
        return {'ok': False, 'files': [], 'msgs': ['켜진 서버가 없습니다']}
    if ok_all:
        st = _up_state(out_dir)
        for n in names:
            st[n] = _sig(os.path.join(out_dir, n))
        with open(os.path.join(out_dir, UP_STATE), 'w', encoding='utf-8') as f:
            json.dump(st, f, ensure_ascii=False, indent=1)
        ut = _up_time(out_dir)
        now = time.time()
        for n in names:
            ut[n] = now
        with open(os.path.join(out_dir, UP_TIME), 'w', encoding='utf-8') as f:
            json.dump(ut, f, ensure_ascii=False, indent=1)
        msgs += put_index(servers, out_dir, names)
    return {'ok': ok_all, 'files': names, 'msgs': msgs}


INDEX_FILE = 'mobile_index.json'


def write_index(out_dir=OUT_DIR, conn=None):
    """그 폴더에 목록 파일(mobile_index.json)을 쓴다 — 올리기 전에도 폰 시험·확인이 같은 목록을 본다."""
    raw = json.dumps(index_of(out_dir, conn), ensure_ascii=False, sort_keys=True).encode('utf-8')
    with open(os.path.join(out_dir, INDEX_FILE), 'wb') as f:
        f.write(raw)
    return os.path.join(out_dir, INDEX_FILE)


# ── 스토어 초판(2026-10-12 사용자 「개별팩도 초판은 앱스토어에서 · 수정본은 무료 서버 · 1년에 한 번 스토어」) ──
#   서버용으로 만든 폰 팩을 **스토어 자산 팩** 단위로 묶는다. 폰은 앱에 함께 실린 `store_index.json` 으로
#   「스토어에 이 판이 있다」를 알고, 서버 목록의 sha 가 다르면 서버에서 새 판만 받는다.
#   · 구글 Play Asset Delivery — 팩 하나 ≤ 1.5 GB · 설치 때 받는 것(install-time) 합 ≤ 4 GB(앱 본체 포함) ·
#     요청할 때 받는 것(on-demand) 합 ≤ 30 GB · 개수 상한은 문서에 뚜렷하지 않아 30개 안으로 묶는다.
#   · 애플 Apple-hosted Background Assets — 합 ≤ 200 GB · 팩 ≤ 200개 · 앱 버전과 따로 올릴 수 있다(심사는 받는다).
STORE_DIR = os.path.join(APP, '_store_dist')
STORE_LIMITS = {'pack_max': 1.5e9, 'install_max': 1.0e9, 'ondemand_max': 30e9, 'count_max': 30,
                'apple_total_max': 200e9, 'apple_count_max': 200}


def store_plan(out_dir=OUT_DIR):
    """서버용 폰 팩 → 스토어 자산 팩 묶음 {팩 이름: {'delivery', 'files':[이름], 'bytes'}}.

    · core(설치 때) = 공통 · 유튜브 · 사진 · AI 기본 꾸러미 11 — 처음 켜자마자 망 없이 쓴다
    · lang_<언어>(요청할 때) = 그 언어팩 · books_<언어>(요청할 때) = 그 언어 도서 전부
    ⚠ 자산 팩 이름은 영문 소문자·숫자·밑줄만(구글 규칙).
    """
    plan = {}
    for n in sorted(os.listdir(out_dir)) if os.path.isdir(out_dir) else []:
        k = kind_of_file(n)
        if not k:
            continue
        kind, L = k[0], k[1].lower()
        if kind in ('COMMON', 'YOUTUBE', 'PHOTO', 'AI'):
            pk, dl = 'core', 'install-time'
        elif kind == 'LANG':
            pk, dl = 'lang_' + L, 'on-demand'
        elif kind == 'SITEPHOTO':
            pk, dl = 'site_photos', 'on-demand'
        else:
            pk, dl = 'books_' + L, 'on-demand'
        e = plan.setdefault(pk, {'delivery': dl, 'files': [], 'bytes': 0})
        e['files'].append(n)
        e['bytes'] += os.path.getsize(os.path.join(out_dir, n))
    return plan


def store_checks(plan):
    """스토어 상한 점검 → [(무엇, 값, 상한, 통과)]."""
    L = STORE_LIMITS
    inst = sum(v['bytes'] for v in plan.values() if v['delivery'] == 'install-time')
    ond = sum(v['bytes'] for v in plan.values() if v['delivery'] == 'on-demand')
    big = max([v['bytes'] for v in plan.values()] or [0])
    tot = inst + ond
    return [('가장 큰 자산 팩', big, L['pack_max'], big <= L['pack_max']),
            ('설치 때 받는 팩 합(구글)', inst, L['install_max'], inst <= L['install_max']),
            ('요청할 때 받는 팩 합(구글)', ond, L['ondemand_max'], ond <= L['ondemand_max']),
            ('자산 팩 개수', len(plan), L['count_max'], len(plan) <= L['count_max']),
            ('전체 합(애플)', tot, L['apple_total_max'], tot <= L['apple_total_max'])]


_GRADLE = """// 하가 자산 팩 — db_mobile_core.build_store 가 만든다(손으로 고치지 말 것)
plugins {
    id 'com.android.asset-pack'
}

assetPack {
    packName = "%s"
    dynamicDelivery {
        deliveryType = "%s"
    }
}
"""


def build_store(edition=None, out_dir=OUT_DIR, store_dir=STORE_DIR):
    """스토어 초판을 묶는다 → {'dir', 'index', 'plan', 'checks'}.

    · `<store_dir>/<판>/android/<팩>/build.gradle` + `src/main/assets/<팩>/<파일>` — 구글 앱 번들에 넣는 모양
    · `<store_dir>/<판>/apple/<팩>/<파일>` — 애플 자산 팩으로 묶을 재료
    · `<store_dir>/<판>/store_index.json` — 폰 앱 assets 에 넣는다(어느 팩이 스토어에 어떤 판으로 있나)
    ★ 같은 팩을 다시 묶어도 파일 내용이 같으면 sha 가 같다(만든 때를 안 담는다).
    """
    import shutil
    edition = edition or time.strftime('%Y-%m-%d')
    plan = store_plan(out_dir)
    if not plan:
        raise ValueError('묶을 폰 팩이 없습니다 — 먼저 [서버용 전부 만들기]')
    root = os.path.join(store_dir, edition)
    if os.path.isdir(root):
        shutil.rmtree(root)
    idx = {'format': 1, 'edition': edition, 'packs': {}}
    for pk, e in plan.items():
        a_dir = os.path.join(root, 'android', pk)
        os.makedirs(os.path.join(a_dir, 'src', 'main', 'assets', pk), exist_ok=True)
        with open(os.path.join(a_dir, 'build.gradle'), 'w', encoding='utf-8') as f:
            f.write(_GRADLE % (pk, 'install-time' if e['delivery'] == 'install-time' else 'on-demand'))
        i_dir = os.path.join(root, 'apple', pk)
        os.makedirs(i_dir, exist_ok=True)
        files = {}
        for n in e['files']:
            src = os.path.join(out_dir, n)
            shutil.copy2(src, os.path.join(a_dir, 'src', 'main', 'assets', pk, n))
            shutil.copy2(src, os.path.join(i_dir, n))
            files[n] = sha16(src)
        idx['packs'][pk] = {'delivery': e['delivery'], 'bytes': e['bytes'], 'files': files}
    raw = json.dumps(idx, ensure_ascii=False, sort_keys=True, indent=1)
    with open(os.path.join(root, 'store_index.json'), 'w', encoding='utf-8') as f:
        f.write(raw)
    return {'dir': root, 'index': idx, 'plan': plan, 'checks': store_checks(plan)}


def put_index(servers, out_dir=OUT_DIR, names=()):
    """서버 목록(mobile_index.json)을 지금 코드로 지어 올린다 — **서버에 실제로 있는 판만**(uploaded_only) · jsDelivr 캐시 비움 → 알림 줄들."""
    import rss_transport as RT
    msgs = []
    st = _up_state(out_dir)
    # ★ 서버 목록 — 사용자 PC 가 9 MB 를 받기 전에 「서버 판이 내 것과 같은가」를 본다(1.txt 54)
    #   ★ 폰 「자료 받기」도 이 목록으로 고른다(2026-10-12 · 종류·언어·도서 제목)
    try:
        import appdb as _AD
        _c = _AD.connect()
        idx = index_of(out_dir, _c)
        _c.close()
    except Exception:                                # noqa: BLE001
        idx = index_of(out_dir)
    idx = uploaded_only(idx, st, out_dir)
    # ★ 2026-10-30 지문 이름은 **서버에 실제로 있을 때만** 목록에 적는다 — 지문 이름이 생기기 전(317차-177)에 올린 팩은
    #   옛 이름만 있는데 목록이 지문 이름을 가리켜, 폰이 팩마다 404 를 한 번 받고 옛 이름으로 되받았다(실측 137줄 중 125줄).
    #   서버가 여럿이면 모두에 있어야 적는다(한쪽에만 있으면 다른 쪽에서 받는 폰이 404).
    present = None
    for srv in (servers or []):
        if not srv.get('enabled', True):
            continue
        try:
            tp0 = RT.make_transport(srv)
            if hasattr(tp0, 'listdir'):
                names0 = set(tp0.listdir())
                present = names0 if present is None else (present & names0)
        except Exception:                            # noqa: BLE001
            pass
    if present is not None:
        idx = {n: ({k: v for k, v in e.items() if k != 'file'} if e.get('file') not in present else e)
               for n, e in idx.items()}
    raw = json.dumps(idx, ensure_ascii=False, sort_keys=True).encode('utf-8')
    # ★ 지문 파일 걷기 — 새 목록과 바로 앞 목록이 가리키는 것만 남긴다(앞 목록을 아직 쥔 폰이 받을 수 있게)
    keep = {e.get('file') for e in idx.values()}
    try:
        with open(os.path.join(out_dir, INDEX_FILE), encoding='utf-8') as f:
            keep |= {e.get('file') for e in json.load(f).values() if isinstance(e, dict)}
    except Exception:                                # noqa: BLE001
        pass
    with open(os.path.join(out_dir, INDEX_FILE), 'wb') as f:
        f.write(raw)
    for srv in (servers or []):
        if not srv.get('enabled', True):
            continue
        tp = RT.make_transport(srv)
        try:
            if hasattr(tp, 'listdir') and hasattr(tp, 'remove'):
                gone = [n for n in tp.listdir() if FP_RE.match(n) and n not in keep]
                for n in gone:
                    tp.remove(n)
                if gone:
                    msgs.append('옛 지문 파일 %d개 걷음' % len(gone))
            tp.put_bytes(INDEX_FILE, raw)
            if hasattr(tp, 'flush'):
                tp.flush()
        except Exception as e:                       # noqa: BLE001
            msgs.append('%s: %s' % (INDEX_FILE, str(e)[:60]))
    # ★ 2026-10-22 jsDelivr 캐시 비우기 — 안 비우면 폰이 최대 12시간 옛 목록·옛 팩을 받는다(실측: 목록이 옛 sha 라 「받을 것이 없다」).
    try:
        pg = RT.purge_jsdelivr(list(names) + [INDEX_FILE])
        bad = [k for k, v in pg.items() if v != 200]
        msgs.append('jsDelivr 캐시 비움 %d%s' % (len(pg) - len(bad), (' · 실패 ' + ', '.join(bad)) if bad else ''))
        thr = [str(pg[k]) for k in bad if str(pg[k]).startswith('THROTTLED')]
        if thr:
            msgs.append('⚠ jsDelivr 가 캐시 비우기를 막았습니다(%s 뒤 풀림) — 그동안 폰은 옛 목록을 봅니다. '
                        '풀린 뒤 [올리기]를 한 번 더 누르세요(여러 번 나눠 올리면 막힙니다 — 여럿을 골라 한 번에)' % thr[0].split(' ', 1)[1])
    except Exception as e:                           # noqa: BLE001
        msgs.append('jsDelivr 캐시 비우기 실패: %s' % str(e)[:60])
    return msgs


def upload_all(servers, out_dir=OUT_DIR):
    """폰 팩 전부 중 **바뀐 것만** 올린다(같은 파일은 건너뛴다) → upload 결과.
    ★ 2026-10-28 바뀐 팩이 없어도 **서버 목록은 지금 코드로 다시 쓴다** — 목록 꼴이 바뀌었을 때(도서 갈래 cat) 옛 목록이 남지 않게."""
    st = _up_state(out_dir)
    names = [n for n in sorted(os.listdir(out_dir)) if kind_of_file(n)
             and st.get(n) != _sig(os.path.join(out_dir, n))]
    if not names:
        msgs = put_index(servers, out_dir, [])
        return {'ok': True, 'files': [], 'msgs': ['바뀐 팩이 없습니다 — 서버 목록만 다시 썼습니다'] + msgs}
    return upload([], servers, out_dir, names=names)


def sha16(path):
    """파일 지문 — mobile_sync.file_sha 와 같은 꼴(폰 pack_list 의 sha 와 견준다)."""
    h = hashlib.sha1()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()[:16]


# ★★ 2026-10-12 사용자 「다운로드 처음 시작은 PC 가 아니라 모바일 앱」 — 폰이 혼자서 서버에서 받는다.
#   서버(jsDelivr/GitHub)에 폰 팩 **전부**를 올리고 목록(mobile_index.json)에 종류·언어·제목을 싣는다.
#   · 옛 판(mobile_core_<언어> · mobile_worship_*)은 목록에 안 싣는다.
AI_FILE = 'mobile_ai_%s.json.gz'          # AI 기본 꾸러미(업무·프롬프트 · 키 없음) — PC 와 안 이은 폰의 AI


def kind_of_file(n):
    """팩 파일 이름 → (종류, 언어, 책 코드). 모르는 이름이면 None."""
    if n == COMMON_FILE:
        return ('COMMON', '-', '')
    if n == YT_FILE:
        return ('YOUTUBE', '-', '')
    if n == PHOTO_FILE:
        return ('PHOTO', '-', '')
    m = re.match(r'mobile_sitephoto_(\d+)\.json\.gz$', n)
    if m:
        return ('SITEPHOTO', '-', m.group(1))
    m = re.match(r'mobile_lang_([A-Z]+)\.json\.gz$', n)
    if m:
        return ('LANG', m.group(1), '')
    m = re.match(r'mobile_ai_([A-Z]+)\.json\.gz$', n)
    if m:
        return ('AI', m.group(1), '')
    m = re.match(r'mobile_ver_([A-Za-z]+)\.json\.gz$', n)
    if m:
        return ('VER', '', m.group(1))
    m = re.match(r'mobile_ref_([A-Z]+)\.json\.gz$', n)
    if m:
        return ('REF', m.group(1), '')
    m = re.match(r'mobile_comm_([A-Z0-9_]+)\.json\.gz$', n)
    if m:
        return ('COMM', '-', m.group(1))
    m = re.match(r'mobile_book_(.+)_([A-Z]+)\.json\.gz$', n)
    if m:
        return ('BOOK', m.group(2), m.group(1))
    return None


def index_of(out_dir=OUT_DIR, conn=None):
    """그 폴더의 모바일 팩 목록 → {이름: {sha, bytes, made, kind, lang[, book, title]}}.

    ★ 폰 「자료 받기」가 이 목록 하나로 고른다 — 도서는 그 언어 제목을 함께 싣는다(conn 을 주면).
    """
    out = {}
    if not os.path.isdir(out_dir):
        return out
    titles = {}
    if conn is not None:
        for code, L, t in conn.execute(
                "SELECT a.book_code, UPPER(x.lang_code), x.title FROM sys_book_asset a JOIN sys_book_asset_text x"
                " ON x.book_id=a.book_id WHERE COALESCE(x.title,'')<>''"):
            titles[(code, L)] = t
        for code, t in conn.execute("SELECT book_code, title FROM sys_book_asset"):
            titles.setdefault((code, '-'), t)
    cats = {}
    if conn is not None:                    # ★ 2026-10-28 도서/설교집 갈래 — 폰이 안 받은 책도 제 탭에 회색으로 보인다
        cats = {code: (cat or 'BOOK') for code, cat in conn.execute(
            "SELECT book_code, COALESCE(book_category,'') FROM sys_book_asset")}
    for n in sorted(os.listdir(out_dir)):
        k = kind_of_file(n)
        if not k:
            continue
        fp = os.path.join(out_dir, n)
        e = {'sha': sha16(fp), 'bytes': os.path.getsize(fp), 'kind': k[0], 'lang': k[1],
             'made': time.strftime('%Y-%m-%d', time.localtime(os.path.getmtime(fp)))}
        if k[0] == 'LANG':
            e['version'] = version_for(k[1]) or ''      # 그 언어팩에 든 대표 역본(폰 첫 설정 · 역본 목록)
        if k[0] == 'VER':
            e['version'] = k[2]
            r = conn.execute('SELECT lang_code, COALESCE(display_name, version_name) FROM bible_version '
                             'WHERE version_code=?', (k[2],)).fetchone() if conn is not None else None
            e['lang'] = str(r[0]).upper() if r else '-'
            e['title'] = r[1] if r else k[2]
        if k[0] == 'SITEPHOTO':
            e['title'] = '#' + k[2]
        if k[0] == 'COMM':
            e['comm'] = k[2]
            r = conn.execute('SELECT COALESCE(author,\'\'), COALESCE(title,\'\') FROM sys_commentary_source WHERE commentary_code=?',
                             (k[2],)).fetchone() if conn is not None else None
            e['title'] = ('%s — %s' % (r[0], r[1]) if r and r[0] else (r[1] if r else k[2])) if r else k[2]
        if k[0] == 'BOOK':
            e['book'] = k[2]
            e['cat'] = 'SERMON' if cats.get(k[2]) == 'SERMON' else 'BOOK'
            e['title'] = titles.get((k[2], k[1])) or titles.get((k[2], 'EN')) or titles.get((k[2], '-')) or k[2]
            # ★ 2026-10-31 그 언어 번역이 90% 이상인가 — 폰 내서재가 번역 없는 책을 감추는 잣대(docs/통계_설계.md §9)
            if conn is not None:
                e['full'] = book_full(conn, k[2], k[1])
            sp = split_of(k[2])
            if sp:                                       # ★ 조각 — 원래 책의 갈래 · 언어마다 제목(폰이 고른다)
                e['cat'] = 'SERMON' if cats.get(sp[0]) == 'SERMON' else 'BOOK'
                e['title'] = '%s — %s' % (SPLIT_BOOKS[sp[0]]['en'], GROUP_EN.get(sp[1], sp[1]))
                e['titles'] = {'EN': e['title'], 'KO': '%s — %s' % (SPLIT_BOOKS[sp[0]]['ko'], sp[5])}
        out[n] = e
    return out


def ai_default_bundle(lang):
    """AI 기본 꾸러미 — 빈 개인 DB 에 씨앗만 심고 PC 와 같은 문(user_ai.phone_bundle)으로 짓는다.

    ⚠ 관리자의 개인 프롬프트·키가 섞이지 않게 **빈 개인 DB** 로 짓는다(키는 애초에 없다).
    """
    import sqlite3
    import tempfile
    import appdb
    import db_dist_build as DB
    import user_ai as UA
    tmp = tempfile.mkdtemp(prefix='hagah_aidef_')
    u = os.path.join(tmp, 'u.db')
    DB.empty_user_db(u, log=lambda *a: None)
    c = sqlite3.connect(appdb.resolve_db('bible_master.db'))
    try:
        c.execute('ATTACH DATABASE ? AS userdb', (u,))
        UA.ensure_seeds(c)
        import ai_lib as AL                          # ★ 2026-10-20 프롬프트 라이브러리(홈 AI 대화 · 라이브러리 화면)도 함께
        AL.migrate(c)
        return UA.phone_bundle(c, lang.upper())
    finally:
        c.close()


def build_ai(lang, out_dir=OUT_DIR):
    """→ (경로, 원본 바이트, gzip 바이트, sha)."""
    L = lang.upper()
    body = {'format': FORMAT, 'kind': 'MAI', 'key': L, 'lang': L, 'ai': ai_default_bundle(L)}
    raw = json.dumps(body, ensure_ascii=False, sort_keys=True).encode('utf-8')
    import secret_store as _SS
    _SS.assert_clean(raw, AI_FILE % L)
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, AI_FILE % L)
    with open(path, 'wb') as fo:
        with gzip.GzipFile(fileobj=fo, mode='wb', compresslevel=6, mtime=0) as f:
            f.write(raw)
    return path, len(raw), os.path.getsize(path), hashlib.sha1(raw).hexdigest()[:12]


def build_server_set(conn, out_dir=OUT_DIR, log=print):
    """서버에 올릴 폰 팩 전부를 만든다 → [경로]. 공통 · 언어 11 · 유튜브 · 사진 · AI 11 · 도서(언어마다).

    ★ 도서는 「번역본이 있는 언어」마다 하나 + 원문(EN) 하나 — 번역이 없는 언어는 EN 팩을 받는다.
    """
    paths = []

    def run(name, fn):
        try:
            p = fn()[0]
            paths.append(p)
            log('  %-44s %7.2f MB' % (os.path.basename(p), os.path.getsize(p) / 1e6))
        except Exception as e:                            # noqa: BLE001
            log('  %-44s 건너뜀: %s' % (name, str(e)[:70]))
    langs = langs_all(conn)
    run(COMMON_FILE, lambda: build(conn, COMMON, out_dir))
    for L in langs:
        run('lang ' + L, lambda L=L: build(conn, L, out_dir))
        run('ai ' + L, lambda L=L: build_ai(L, out_dir))
    for L in langs:
        run('ref ' + L, lambda L=L: build(conn, 'REF:' + L, out_dir))
    for v in ver_codes(conn):
        run('ver ' + v, lambda v=v: build(conn, 'VER:' + v, out_dir))
    run(YT_FILE, lambda: build_youtube(conn, out_dir))
    run(PHOTO_FILE, lambda: build_photos(conn, out_dir))
    for cc in comm_codes(conn):                       # ★ 2026-10-28 주석 팩(주석 하나 = 팩 하나)
        run('comm ' + cc, lambda cc=cc: build(conn, 'COMM:' + cc, out_dir))
    try:
        for p in build_site_photos(conn, out_dir):
            paths.append(p[0])
            log('  %-44s %7.2f MB' % (os.path.basename(p[0]), os.path.getsize(p[0]) / 1e6))
    except Exception as e:                                # noqa: BLE001
        log('  %-44s 건너뜀: %s' % ('sitephoto', str(e)[:70]))
    seen = set()
    for code in SPLIT_BOOKS:                          # ★ 큰 책은 조각으로(통째 팩은 만들지 않는다)
        for g, *_x in split_parts(code):
            run('part %s_%s' % (code, g), lambda pc='%s_%s' % (code, g): build_part(conn, pc, out_dir))
    for L in langs:
        for b in books_on_pc(conn, L):
            if b['code'] in SPLIT_BOOKS:
                continue
            want = L if b['has_lang'] else 'EN'
            if (b['code'], want) in seen:
                continue
            seen.add((b['code'], want))
            run('book %s %s' % (b['code'], want), lambda b=b, w=want: build_book(conn, b['code'], w, out_dir))
    return paths


def fetch_index(servers=None):
    """서버에 올라간 모바일 팩 목록 → dict | None(못 받음)."""
    import rss_transport as RT
    import tray_agent as TA
    try:
        data = TA.download_bytes(servers if servers is not None else RT.client_servers(), INDEX_FILE)
        return json.loads(data.decode('utf-8')) if data else None
    except Exception:                                    # noqa: BLE001
        return None


def compare(lang, phone_packs=None, server=None):
    """한 언어 사용자의 코어(공통 + 언어팩)를 서버 · PC · 폰으로 견준다 →
    [{name, server, pc, phone, pc_made, state}] — state = SAME · PC_OLD · PHONE_OLD · NO_PC · NO_SERVER."""
    ph = {x.get('name'): x for x in (phone_packs or [])}
    out = []
    for k in set_of(lang):
        n = file_name(k)
        p = core_path(k)
        pc = sha16(p) if p else ''
        sv = ((server or {}).get(n) or {}).get('sha', '') if server is not None else None
        phs = (ph.get(n) or {}).get('sha', '')
        if not pc:
            st = 'NO_PC'
        elif sv is not None and sv and sv != pc:
            st = 'PC_OLD'
        elif phs != pc:
            st = 'PHONE_OLD'
        else:
            st = 'SAME'
        out.append({'name': n, 'server': sv, 'pc': pc, 'phone': phs, 'state': st,
                    'pc_made': time.strftime('%Y-%m-%d', time.localtime(os.path.getmtime(p))) if p else '',
                    'pc_mb': os.path.getsize(p) / 1048576.0 if p else 0.0})
    return out


CACHE_DIR = os.path.join(APP, '_mobile_cache')   # 사용자 PC 가 받아 둔 모바일 코어팩(폰에 보낼 것)


def fetch_core(lang, servers=None, cache_dir=CACHE_DIR):
    """사용자 PC 가 서버에서 그 언어 모바일 코어팩을 받는다 → 경로 | None.

    ★ 폰에 보내려고 받는다 — PC 에 적용하지 않는다(PC 팩과 다른 것이다).
    """
    import rss_transport as RT
    import tray_agent as TA
    data = TA.download_bytes(servers if servers is not None else RT.client_servers(), file_name(lang))
    if not data:
        return None
    json.loads(gzip.decompress(data).decode('utf-8'))           # 깨진 파일이면 여기서 터진다
    os.makedirs(cache_dir, exist_ok=True)
    p = os.path.join(cache_dir, file_name(lang))
    tmp = p + '.tmp'
    with open(tmp, 'wb') as f:
        f.write(data)
    os.replace(tmp, p)
    return p


def core_path(key):
    """폰에 보낼 팩 하나 — 받아 둔 것(사용자 PC) 먼저, 없으면 만든 것(관리자 PC)."""
    for d in (CACHE_DIR, OUT_DIR):
        p = os.path.join(d, file_name(key))
        if os.path.exists(p):
            return p
    return None


def core_paths(lang):
    """그 언어 사용자의 코어 = 공통 + 언어팩 → 있는 것만 [경로]."""
    return [p for p in (core_path(k) for k in set_of(lang)) if p]


def plan(conn, key):
    out = []
    for t, w, a in (spec_common(conn) if is_common(key) else spec_lang(conn, key)):
        try:
            n = conn.execute('SELECT COUNT(*) FROM %s' % t + (' WHERE ' + w if w else ''), a).fetchone()[0]
        except Exception as e:                                   # noqa: BLE001
            n = 'ERR %s' % e
        out.append((t, n))
    return out


def selftest():
    import appdb
    import tempfile
    ok = [0, 0]

    def ck(name, cond, got=''):
        ok[0 if cond else 1] += 1
        print(('PASS ' if cond else 'FAIL ') + name + ('' if cond else '  got=%r' % (got,)))

    conn = appdb.connect('bible_master.db')
    cm = build_body(conn, COMMON)['tables']
    lk = build_body(conn, 'KO')['tables']
    ck('공통 = kind MCORE · 언어 없음', build_body(conn, COMMON)['kind'] == 'MCORE')
    ck('언어팩 = kind MLANG · lang KO', build_body(conn, 'KO')['kind'] == 'MLANG')
    ck('★ 구절 목록은 공통에만', 'bible_index' in cm and 'bible_index' not in lk)
    vi = cm['bible_content']['cols'].index('version_code')
    ck('공통 본문 = BSB 만', {r[vi] for r in cm['bible_content']['rows']} == {'BSB'})
    vk = lk['bible_content']['cols'].index('version_code')
    ck('★ 언어팩 본문 = 개역한글 전권만(BSB 없음)',
       {r[vk] for r in lk['bible_content']['rows']} == {'KRV'} and len(lk['bible_content']['rows']) > 31000)
    ck('영어팩에는 BSB 를 또 싣지 않는다', 'bible_content' not in build_body(conn, 'EN')['tables'])
    ck('공통 — 도서·설교집이 없다 · 가계도 사람·관계는 공통에(2026-10-22)',
       not any(t.startswith('sys_book') for t in cm) and 'sys_genealogy_person' in cm and 'sys_genealogy_relation' in cm)
    # ★ 2026-10-23 발자취 — 경로 표 셋 + 좌표 있는 장소(용어는 그것뿐) + 장소 영어 이름이 공통에
    _ge = cm['sys_entity_master']
    _gt = (_ge['cols'].index('entity_type'), _ge['cols'].index('geo_lat'))
    ck('★ 발자취 — 경로 표 셋이 공통에', all(t in cm for t in ('sys_place_route_theme', 'sys_place_route', 'sys_place_route_stop'))
       and len(cm['sys_place_route_stop']['rows']) > 150)
    ck('★ 발자취 — 공통의 용어 = 좌표 있는 장소뿐', _ge['rows'] and all(r[_gt[0]] == 'PLACE' and r[_gt[1]] is not None for r in _ge['rows']),
       len(_ge['rows']))
    _gn = {r[cm['sys_text_asset']['cols'].index('clicked_id')] for r in cm['sys_text_asset']['rows']
           if r[cm['sys_text_asset']['cols'].index('text_type')] == 'ENTITY_NAME'}
    ck('★ 발자취 — 장소마다 영어 이름이 공통에', {r[_ge['cols'].index('entity_id')] for r in _ge['rows']} <= _gn)
    ck('KO — 도서·설교집이 없다 · 가계도 카드(KO+EN)는 언어팩에', not any(t.startswith('sys_book') for t in lk)
       and 'sys_genealogy_card' in lk and 'anchor_gp_id' in lk['sys_genealogy_card']['cols'])
    # ★ 용어는 그 언어 설명문이 있는 것만(1.txt 54) — 이름뿐인 TERM 은 안 싣는다
    em = lk['sys_entity_master']
    with_desc = {r[0] for r in conn.execute("SELECT clicked_id FROM sys_text_asset WHERE text_type='ENTITY_DESC' "
                                            "AND UPPER(lang_code)='KO' AND %s" % LIVE)}
    ck('★ KO 용어 = 한국어 설명문이 있는 것만', em['rows'] and
       {r[em['cols'].index('entity_id')] for r in em['rows']} <= with_desc, len(em['rows']))
    # ★ 2026-10-22 용어↔구절은 정본(ENTI_VERS)에서 — 옛 표 sys_entity_verse 가 아니다
    ev = lk['sys_entity_verse']
    # ★ 2026-10-29 장소(좌표 있는 것)는 공통팩에 — 언어팩 쪽 잣대에서도 뺀다
    n_canon = conn.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type='ENTI_VERS' AND %s AND clicked_id IN (%s)"
                           " AND clicked_id NOT IN (%s)" % (LIVE, _ENT, _GEO), ('KO',)).fetchone()[0]
    ck('★ KO 용어 구절 = 정본 ENTI_VERS 행수와 같다 · end_id 칸이 있다',
       len(ev['rows']) == n_canon and 'end_id' in ev['cols'] and 'link_kind' in ev['cols'], (len(ev['rows']), n_canon))
    ck('★ 언약 갈래(COV_*)가 실린다', any(r[ev['cols'].index('link_kind')].startswith('COV_') for r in ev['rows']))
    tt = lk['sys_text_asset']['cols'].index('text_type')
    ck('★ 절 단위 연결설명문(ENTITY_VERSE_DESC)이 언어팩에', any(r[tt] == 'ENTITY_VERSE_DESC' for r in lk['sys_text_asset']['rows']))
    ck('★ 원어 사전·절 낱말은 공통에(출현 목록 칸은 안 싣는다)',
       'sys_lemma_master' in cm and 'sys_verse_lemma' in cm and 'verse_ids' not in cm['sys_lemma_master']['cols'])
    rk = build_body(conn, 'REF:KO')
    rs = rk['tables']['sys_ref_source']
    ck('★ 연구자료 = 따로 팩(MREF) · 우리 글(STUDY)만', rk['kind'] == 'MREF' and rs['rows'] and
       {r[rs['cols'].index('src_type')] for r in rs['rows']} == {'STUDY'} and 'sys_ref_unit' not in lk)
    vc = ver_codes(conn)
    ck('★ 역본 팩 = 대표 역본·BSB 밖 공개 역본만', vc and 'BSB' not in vc and 'KRV' not in vc and 'JLV' not in vc, vc)
    vb = build_body(conn, 'VER:' + vc[0])
    ck('역본 팩 = 그 역본 본문 하나', vb['kind'] == 'MVER' and
       {r[vb['tables']['bible_content']['cols'].index('version_code')] for r in vb['tables']['bible_content']['rows']} == {vc[0]})
    ck('★ 화면 글자 11언어가 공통에 · 언어팩엔 없다',
       len({str(r[cm['ui_strings']['cols'].index('lang_code')]).upper() for r in cm['ui_strings']['rows']}) >= 11
       and 'ui_strings' not in lk and 'book_names' not in lk)
    ta = lk['sys_text_asset']
    li, ti, vv = (ta['cols'].index(c) for c in ('lang_code', 'text_type', 'text_variant'))
    ck('언어팩 글은 그 언어만(용어 이름의 영어 폴백만 예외)',
       {r[li] for r in ta['rows'] if r[ti] != 'ENTITY_NAME'} == {'KO'})
    ck('전문 설명(EXPERT)은 설명문·연구질문만', {r[ti] for r in ta['rows'] if r[vv] == 'EXPERT'} == {'VERS_DESC', 'VERS_QUESTION'})
    ck('설명문 전권(1만 편 넘게)', sum(1 for r in ta['rows'] if r[ti] == 'VERS_DESC') > 10000)
    ct = cm['sys_text_asset']
    ck('공통 글 = 영어 제목만(+ 장소·여정 인물 이름)', {r[ct['cols'].index('lang_code')] for r in ct['rows']} == {'EN'} and
       {r[ct['cols'].index('text_type')] for r in ct['rows']} <= set(TITLE_TYPES) | {'ENTITY_NAME'})
    ce = cm['sys_commentary_entry']
    si = ce['cols'].index('start_vid')
    a, b = _gen1(conn)
    # ★ 2026-10-28 항목은 전부(받지 않은 주석도 이름이 보이게) · **본문**은 창 1장만
    ein = {r[ce['cols'].index('entry_id')]: r[si] for r in ce['rows']}
    ctx = cm['sys_commentary_text']
    ck('주석 항목은 전부 · 본문은 창세기 1장만', len(ein) > 10000 and ctx['rows'] and
       all(a <= ein.get(r[ctx['cols'].index('entry_id')], 0) <= b for r in ctx['rows']), len(ctx['rows']))
    cb = build_body(conn, 'COMM:JFB')
    cr = cb['tables']['sys_commentary_text']['rows']
    ck('주석 팩 = 그 주석 본문 · 맛보기(창 1장)는 뺀다', cb['kind'] == 'MCOMM' and len(cr) > 1000 and
       not any(a <= ein.get(r[cb['tables']['sys_commentary_text']['cols'].index('entry_id')], 0) <= b for r in cr))
    ck('주석 팩 이름 ↔ 종류', kind_of_file(file_name('COMM:JFB')) == ('COMM', '-', 'JFB'))
    _pb = part_body(conn, 'SPURGEON_SERMONS_PENT')
    _bu = _pb['tables']['sys_book_unit']
    ck('★ 스펄전 조각 = 가짜 책 번호 · 오경 본문 편만 · 편 번호는 원래 그대로',
       _pb['tables']['sys_book_asset']['rows'][0][_pb['tables']['sys_book_asset']['cols'].index('book_id')] == 1901
       and 150 < len(_bu['rows']) < 400 and all(r[_bu['cols'].index('book_id')] == 1901 for r in _bu['rows']))
    ck('조각 이름 ↔ 원래 책', split_of('SPURGEON_SERMONS_GOSP')[:3] == ('SPURGEON_SERMONS', 'GOSP', 1906)
       and split_of('SPURGEON_SERMONS') is None and len(split_parts('SPURGEON_SERMONS')) == 8)
    ck('PC 는 조각 번호를 원래 책으로', real_book_id(1904) == conn.execute(
        "SELECT book_id FROM sys_book_asset WHERE book_code='SPURGEON_SERMONS'").fetchone()[0] and real_book_id(5) == 5)
    import tempfile as _tf
    _d = _tf.mkdtemp(prefix='hagah_uponly_')
    for _n, _b in (('mobile_comm_JFB.json.gz', b'new'), ('mobile_lang_KO.json.gz', b'v2'), ('mobile_lang_EN.json.gz', b'same')):
        open(os.path.join(_d, _n), 'wb').write(_b)
    _st = {'mobile_lang_KO.json.gz': hashlib.sha1(b'v1').hexdigest(), 'mobile_lang_EN.json.gz': hashlib.sha1(b'same').hexdigest()}
    _o = uploaded_only(index_of(_d), _st, _d)
    ck('★ 서버 목록 = 올린 판만(안 올린 팩은 빼고 · 새로 만들어만 둔 팩은 올린 판 지문)',
       'mobile_comm_JFB.json.gz' not in _o and _o['mobile_lang_KO.json.gz']['sha'] == hashlib.sha1(b'v1').hexdigest()[:16]
       and _o['mobile_lang_EN.json.gz']['sha'] == sha16(os.path.join(_d, 'mobile_lang_EN.json.gz')))
    for nm, T, want in (('공통', cm, {'EN'}), ('KO', lk, {'KO'})):
        for t in ('sys_commentary_text',):
            c2 = T[t]['cols'].index('lang_code')
            ck('%s %s 는 %s 만' % (nm, t, '·'.join(want)), {str(r[c2]).upper() for r in T[t]['rows']} <= want)
    lt = cm['sys_link_asset']
    ck('공통 연결 = 구절·렌즈 셋', {r[lt['cols'].index('link_type')] for r in lt['rows']} ==
       {'VERS_VERS', 'CONT_NODE', 'NODE_VERS', 'TLEV_VERS', 'TLEV_ENTI'})   # ★ 317차-115 연대표 세부 사건
    ck('골라담기 플랜이 없다',
       all(r[cm['sys_plan_category']['cols'].index('cat_id')] not in PICK_CATS for r in cm['sys_plan_category']['rows']))
    ck('렌즈 40개 넘게 실린다', sum(1 for r in cm['sys_unit_asset']['rows']
                             if r[cm['sys_unit_asset']['cols'].index('unit_type')] == 'CONTAINER') >= 40)
    # ★ 2026-10-12 영상은 언어팩·공통팩에 없다 — 유튜브 팩 하나에 모든 언어
    ck('영상은 언어팩·공통팩에 없다', 'sys_media_asset' not in cm and 'sys_media_asset' not in lk
       and not any(r[lk['sys_link_asset']['cols'].index('link_type')] == 'MEDI_VERS'
                   for r in lk.get('sys_link_asset', {'rows': []})['rows']))
    yb = youtube_body(conn)['tables']
    ma = yb['sys_media_asset']
    ck('유튜브 팩 — 모든 언어 영상', len({r[ma['cols'].index('lang_code')] for r in ma['rows']}) >= 5)
    ck('영상 설명문은 안 싣는다', 'description' not in ma['cols'])
    ck('★ 유튜브 게시일(published)을 싣는다 — 폰 「최신」', 'published' in ma['cols'] and 'published' in yb['wor_media']['cols']
       and sum(1 for r in ma['rows'] if r[ma['cols'].index('published')]) > len(ma['rows']) * 0.9)
    mids = {r[ma['cols'].index('media_id')] for r in ma['rows']}
    ml = yb['sys_link_asset']['rows']
    ck('영상 연결이 실린 영상만 가리킨다', ml and all(r[yb['sys_link_asset']['cols'].index('clicked_id')] in mids
                                         for r in ml), len(ml))
    wm = yb['wor_media']
    ck('찬양·기도도 모든 언어', len({r[wm['cols'].index('lang_code')] for r in wm['rows']}) >= 5
       and {r[wm['cols'].index('media_type')] for r in wm['rows']} <= {'WORSHIP', 'PRAYER'})
    ck('AI 필수 지침 — 공통 EN · 언어팩 KO', cm['sys_ai_guard']['rows'] and lk['sys_ai_guard']['rows'])
    ck('추천 구절은 공통에', 'sys_verse_highlight' in cm)
    with tempfile.TemporaryDirectory() as d:
        p0 = build(conn, COMMON, d)
        p1 = build(conn, 'KO', d)
        p2 = build(conn, 'KO', d)
        ck('파일 이름', os.path.basename(p0[0]) == 'mobile_common.json.gz' and
           os.path.basename(p1[0]) == 'mobile_lang_KO.json.gz')
        ck('★ 다시 만들어도 같은 sha(다시 안 보낸다)', p1[3] == p2[3], (p1[3], p2[3]))
        # ★ 2026-10-30 6 → 8 MB — 순례 장소·도로·도보 구역이 늘어 6.02 MB(jsDelivr 20 MB 한도 · R2 는 한도 없음)
        ck('압축 크기 — 공통 8 MB · KO 16 MB 아래(전문 설명 포함)', p0[2] < 8e6 and p1[2] < 16e6, (p0[2], p1[2]))
        print('  공통 gzip %.1f MB · KO gzip %.1f MB' % (p0[2] / 1e6, p1[2] / 1e6))
    ck('일본어(기준 역본 없음) 언어팩엔 본문이 없다', 'bible_content' not in build_body(conn, 'JA')['tables'])
    # ── 도서 팩 ──
    bs = books_on_pc(conn, 'KO')
    ck('PC 에 있는 책 목록이 나온다', len(bs) >= 1, len(bs))
    ck('책마다 본문이 있는 언어', all(b['langs'] for b in bs))
    ck('책 소개 — 제목·소개문', all(book_intro(conn, bs[0]['code'], 'KO')[:1]))
    ck('파일 이름 → 책 코드', book_code_of('mobile_book_SPURGEON_ME_KO.json.gz') == ('SPURGEON_ME', 'KO')
       and book_code_of('mobile_common.json.gz') is None)
    small = min(bs, key=lambda b: b['chars'])
    bb = book_body(conn, small['code'], 'KO')
    ck('도서 팩은 그 책 한 권만', len({r[bb['tables']['sys_book_asset']['cols'].index('book_code')]
                                for r in bb['tables']['sys_book_asset']['rows']}) == 1)
    ut = bb['tables']['sys_book_unit_text']
    vi, li = ut['cols'].index('text_variant'), ut['cols'].index('lang_code')
    ck('번역은 그 언어만', all(r[vi] in BOOK_VARIANTS_ANY or str(r[li]).upper() == 'KO' for r in ut['rows']))
    with tempfile.TemporaryDirectory() as d:
        p1 = build_book(conn, small['code'], 'KO', d)
        p2 = build_book(conn, small['code'], 'KO', d)
        ck('같은 책은 같은 sha(다시 보낼지 가른다)', p1[3] == p2[3], (p1[3], p2[3]))
        ck('파일 이름', os.path.basename(p1[0]) == book_file_name(small['code'], 'KO'))
        # ── 올리기 — 로컬 폴더 서버 ──
        srv = os.path.join(d, 'srv')
        os.makedirs(srv)
        build(conn, COMMON, d)
        build(conn, 'EN', d)
        r = upload([COMMON, 'EN'], [{'label': 'L', 'transport': 'LOCAL_DIR', 'location': srv, 'enabled': True}], d)
        ck('★ 올리기가 서버 폴더에 두 파일을 둔다', r['ok'] and os.path.exists(os.path.join(srv, file_name('EN')))
           and os.path.exists(os.path.join(srv, COMMON_FILE)), r)
        ck('  「올림」으로 적힌다', is_uploaded('EN', d))
        ix = json.loads(open(os.path.join(srv, INDEX_FILE), encoding='utf-8').read())
        fpf = ix.get(COMMON_FILE, {}).get('file', '')
        ck('★ 지문 이름 — 목록의 file 이 서버에 있고 내용이 같다', bool(FP_RE.match(fpf)) and os.path.exists(os.path.join(srv, fpf))
           and open(os.path.join(srv, fpf), 'rb').read() == open(os.path.join(d, COMMON_FILE), 'rb').read(), fpf)
        open(os.path.join(srv, fp_name(COMMON_FILE, '0' * 16)), 'wb').write(b'x')        # 아무도 안 가리키는 옛 지문 파일
        put_index([{'label': 'L', 'transport': 'LOCAL_DIR', 'location': srv, 'enabled': True}], d)
        ck('  아무 목록도 안 가리키는 지문 파일은 걷는다 · 지금 것은 남는다',
           not os.path.exists(os.path.join(srv, fp_name(COMMON_FILE, '0' * 16))) and os.path.exists(os.path.join(srv, fpf)))
        ck('★ 서버 목록이 함께 올라간다(공통 + EN · 그 폴더의 도서도 · 종류·언어)',
           {COMMON_FILE, file_name('EN')} <= set(ix) and ix[file_name('EN')].get('kind') == 'LANG'
           and all(v.get('kind') for v in ix.values())
           and ix[COMMON_FILE]['sha'] == sha16(os.path.join(d, COMMON_FILE)), sorted(ix))
        cmp_ = compare('EN', [{'name': COMMON_FILE, 'sha': ix[COMMON_FILE]['sha']}], ix)
        ck('  견주기 — 폰에 없는 언어팩은 PHONE_OLD', [c['state'] for c in cmp_][1] in ('PHONE_OLD', 'NO_PC'),
           cmp_)
        ck('  받기 — 같은 서버에서 다시 받는다',
           fetch_core('EN', [{'location': srv, 'enabled': True}], os.path.join(d, 'cache')) is not None)
        with gzip.open(os.path.join(d, file_name('EN')), 'wb') as f:
            f.write(b'{"tables": {}}')
        ck('  다시 만들면(바뀌면) 「올림」이 풀린다', not is_uploaded('EN', d))
    # ★ 2026-10-23 유적 사진 원본 나누기 — 필수팩엔 샘플만 · 나머지는 조각 팩(빠짐·겹침 없이)
    smp = site_samples(conn)
    allp = {r[0] for r in conn.execute("SELECT photo_id FROM sys_site_photo WHERE COALESCE(record_status,'LIVE')='LIVE' "
                                       "AND jpg IS NOT NULL")}
    if allp:
        sb = sum(conn.execute('SELECT LENGTH(jpg) FROM sys_site_photo WHERE photo_id=?', (i,)).fetchone()[0] for i in smp)
        ck('★ 사진 샘플 = 작은 것 몇 장(수·합 상한)', 0 < len(smp) <= SAMPLE_MAX and sb <= SAMPLE_BYTES, (len(smp), sb))
        pb = photo_body(conn)['tables']['sys_site_photo']
        ji, ii = pb['cols'].index('jpg'), pb['cols'].index('photo_id')
        ck('  필수 사진팩의 원본 = 샘플뿐 · 작은 그림은 전부',
           {r[ii] for r in pb['rows'] if r[ji] is not None} == set(smp)
           and all(r[pb['cols'].index('thumb')] is not None for r in pb['rows']))
        parts = site_parts(conn, set(smp))
        flat = [i for p in parts for i in p]
        ck('  조각 팩 = 샘플 밖 원본 전부 · 겹침 없음', set(flat) | set(smp) == allp and len(flat) == len(set(flat))
           and not set(flat) & set(smp))
        szs = [sum(conn.execute('SELECT LENGTH(jpg) FROM sys_site_photo WHERE photo_id=?', (i,)).fetchone()[0] for i in p)
               for p in parts]
        ck('  조각마다 원본 합 ≤ SITE_PART_MAX(한 장이 넘는 것은 혼자)',
           all(s <= SITE_PART_MAX or len(p) == 1 for s, p in zip(szs, parts)), szs)
        ck('  파일 이름 → SITEPHOTO', kind_of_file(SITE_FILE % 2) == ('SITEPHOTO', '-', '2'))
    print('\n%d/%d' % (ok[0], ok[0] + ok[1]))
    return ok[1] == 0


def main(argv):
    import appdb
    if not argv or argv[0] == '--selftest':
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect('bible_master.db')
    if argv[0] == '--plan':
        for t, n in plan(conn, argv[1]):
            print('%-24s %s' % (t, n))
    elif argv[0] == '--build-store':            # ★ 스토어 초판 묶기(2026-10-12)
        r = build_store(argv[1] if len(argv) > 1 else None)
        print('스토어 초판 %s → %s' % (r['index']['edition'], r['dir']))
        for pk, e in sorted(r['plan'].items()):
            print('  %-12s %-12s 파일 %3d  %7.2f MB' % (pk, e['delivery'], len(e['files']), e['bytes'] / 1e6))
        for what, v, lim, ok in r['checks']:
            print('  %s %-22s %s / 상한 %s' % ('✔' if ok else '✘', what,
                                            ('%d' % v) if what == '자산 팩 개수' else '%.1f MB' % (v / 1e6),
                                            ('%d' % lim) if what == '자산 팩 개수' else '%.0f MB' % (lim / 1e6)))
    elif argv[0] == '--build-server':           # ★ 폰이 먼저 — 서버에 올릴 폰 팩 전부(2026-10-12)
        paths = build_server_set(conn)
        print('만든 팩 %d개 · 합계 %.1f MB' % (len(paths), sum(os.path.getsize(p) for p in paths) / 1e6))
    elif argv[0] in ('--build', '--build-all'):
        ls = ([COMMON] + langs_all(conn) + ['REF:' + L for L in langs_all(conn)]
              + ['VER:' + v for v in ver_codes(conn)]) if argv[0] == '--build-all' else argv[1:]
        for l in ls:
            p, raw, gz, sha = build(conn, l)
            print('%-4s %s  원본 %.1f MB → gzip %.1f MB  %s' % (l, os.path.basename(p), raw / 1e6, gz / 1e6, sha))
        if argv[0] == '--build-all':          # ★ 유튜브 팩(모든 언어 하나 · 2026-10-12)
            p, raw, gz, sha = build_youtube(conn)
            print('YT   %s  원본 %.1f MB → gzip %.1f MB  %s' % (os.path.basename(p), raw / 1e6, gz / 1e6, sha))
            for cc in comm_codes(conn):                 # ★ 2026-10-28 주석 팩
                p, raw, gz, sha = build(conn, 'COMM:' + cc)
                print('COMM %s  원본 %.1f MB → gzip %.1f MB  %s' % (os.path.basename(p), raw / 1e6, gz / 1e6, sha))
            print('목록', write_index(OUT_DIR, conn))


if __name__ == '__main__':
    main(sys.argv[1:])
