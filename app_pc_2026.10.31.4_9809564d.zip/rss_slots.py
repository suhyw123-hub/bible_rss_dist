# -*- coding: utf-8 -*-
"""뉴스 채널 하루 세 번 수집 — 사이트마다 그 나라 시각으로 (2026-10-24 신설·영구).

사용자 지시 — 「뉴스 채널만 따로 하루에 3번 · 회차별 수집건수·중복·적절한 간격을 판단 ·
매체별로 뉴스 생산 시점이 다르다(일간지는 10시~17시) · 수집주기를 국가별로 달리 할 수 있는가」.

★ 나라가 아니라 **사이트마다 시간대**를 정한다 — 영어는 미국·영국이 섞이고 스페인어·포르투갈어도
  대륙이 갈린다. 언어로 기본값을 주고(`TZ_OF_LANG`) 사이트 주소로 덮는다(`TZ_OF_HOST`).
★ 회차 = 그 사이트 시각 `SLOTS` (12시 · 17시 · 22시) — 오전 생산분 · 오후 생산분 · 저녁·늦은 글.
  매시 도는 작업(`db_rss_collect.py --news`)이 「지난 회차 뒤로 아직 안 거둔 뉴스 채널」만 거둔다.
  PC 가 꺼져 회차를 놓치면 켜졌을 때 한 번만 거둔다(밀린 회차를 몰아 여러 번 하지 않는다).
★ 회차마다 기록 `sys_rss_collect_log`(LOCAL) — 받은 수 · 새 글 · 이미 있던 글 · 글의 게시 시각 범위.
  `report()` 가 사이트마다 회차 평균 · **넘침**(받은 것이 전부 새 글 = 그사이 놓친 글이 있을 수 있다) ·
  **게시 시각 분포**(그 사이트 시각) 를 낸다 — 그것이 「적절한 간격」의 근거다.
⚠ 묵상 채널은 이 길을 안 탄다 — 하루 한 번(`due_feed_ids` · 05:00 작업).
"""
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse
from zoneinfo import ZoneInfo

SLOTS = (12, 17, 22)

TZ_OF_LANG = {
    'KO': 'Asia/Seoul', 'JA': 'Asia/Tokyo', 'ZH': 'Asia/Shanghai', 'ZHT': 'Asia/Hong_Kong',
    'EN': 'America/New_York', 'DE': 'Europe/Berlin', 'FR': 'Europe/Paris', 'ES': 'Europe/Madrid',
    'PT': 'America/Sao_Paulo', 'RU': 'Europe/Moscow', 'AR': 'Africa/Cairo',
}
TZ_OF_HOST = {   # 언어 기본값과 다른 곳만
    'christiantoday.com': 'Europe/London',
    'premierchristianity.com': 'Europe/London',
}

LOG_DDL = ("CREATE TABLE IF NOT EXISTS sys_rss_collect_log("
           " log_id INTEGER PRIMARY KEY AUTOINCREMENT, run_at TEXT, feed_id INTEGER, slot TEXT,"
           " received INTEGER, new INTEGER, dup INTEGER, oldest_pub TEXT, newest_pub TEXT, err TEXT)")


def ensure(conn):
    conn.execute(LOG_DDL)
    cols = {r[1] for r in conn.execute('PRAGMA table_info(sys_ref_asset)')}
    if 'published' not in cols:
        conn.execute('ALTER TABLE sys_ref_asset ADD COLUMN published TEXT')


# ★ 2026-10-24 사이트의 나라(ISO 두 글자) — 폰 기사 목록에 나라 이름을 보인다(사용자 「같은 나라 안의 국민을 상대하므로
#   기사 내용으로는 나라를 알 수 없는 경우가 많다」). 차례 = 사이트 주소 → 나라 도메인 → 언어 기본값.
#   ⚠ 확실하지 않으면 비운다(지어내지 않는다) — 여러 나라에 내는 국제 사역(오늘의 양식 언어판 · TGC 언어판)은 빈칸.
COUNTRY_OF_HOST = {
    'christiantoday.com': 'GB', 'premierchristianity.com': 'GB',
    'christianismeaujourdhui.info': 'CH', 'toutpoursagloire.com': 'CA',
    'odbkorea.org': 'KR', 'behold.oc.org': 'US',
    'arabic-odb.org': '', 'japanese-odb.org': '', 'russian-odb.org': '', 'simplified-odb.org': '',
    'traditional-odb.org': '', 'nuestropandiario.org': '', 'tgcchinese.org': '',
    'coalicionporelevangelio.org': '', 'coalizaopeloevangelho.org': 'BR',
}
COUNTRY_OF_TLD = {'kr': 'KR', 'jp': 'JP', 'de': 'DE', 'fr': 'FR', 'br': 'BR', 'ru': 'RU', 'hk': 'HK',
                  'uk': 'GB', 'cn': 'CN', 'tw': 'TW', 'ca': 'CA', 'ch': 'CH'}
COUNTRY_OF_LANG = {'KO': 'KR', 'JA': 'JP', 'DE': 'DE', 'FR': 'FR', 'PT': 'BR', 'RU': 'RU', 'EN': 'US'}


def country_of(feed_url, lang):
    host = (urlparse(feed_url or '').hostname or '').lower()
    if host.startswith('www.'):
        host = host[4:]
    for k, v in COUNTRY_OF_HOST.items():
        if host == k or host.endswith('.' + k):
            return v
    tld = host.rsplit('.', 1)[-1] if '.' in host else ''
    if tld in COUNTRY_OF_TLD:
        return COUNTRY_OF_TLD[tld]
    return COUNTRY_OF_LANG.get((lang or '').upper(), '')


def tz_of(feed_url, lang):
    host = (urlparse(feed_url or '').hostname or '').lower()
    if host.startswith('www.'):
        host = host[4:]
    return ZoneInfo(TZ_OF_HOST.get(host) or TZ_OF_LANG.get((lang or 'EN').upper(), 'UTC'))


def _aware_local(iso):
    """last_checked 는 이 PC 시각(naive)으로 적힌다 — 이 PC 시간대로 읽는다."""
    d = datetime.fromisoformat(iso)
    return d.astimezone() if d.tzinfo is None else d


def last_slot(now_utc, tz):
    """now 이전(같거나 이전) 가장 가까운 회차 시각(aware)과 그 이름."""
    loc = now_utc.astimezone(tz)
    for back in range(0, 2):
        day = (loc - timedelta(days=back)).date()
        for h in sorted(SLOTS, reverse=True):
            t = datetime(day.year, day.month, day.day, h, tzinfo=tz)
            if t <= loc:
                return t, 'NEWS-%02d' % h
    return None, ''


def news_due(conn, now_utc=None):
    """[(feed_id, 회차 이름)] — 뉴스 채널 중 마지막 회차 뒤로 아직 안 거둔 것."""
    now_utc = now_utc or datetime.now(timezone.utc)
    out = []
    for fid, url, lang, last in conn.execute(
            "SELECT feed_id, feed_url, lang_code, last_checked FROM sys_rss_feed "
            "WHERE record_status='LIVE' AND enabled=1 AND COALESCE(feed_kind,'NEWS')='NEWS' ORDER BY feed_id"):
        slot_t, name = last_slot(now_utc, tz_of(url, lang))
        if slot_t is None:
            continue
        try:
            done = last and _aware_local(last) >= slot_t
        except Exception:
            done = False
        if not done:
            out.append((fid, name))
    return out


def log(conn, feed_id, slot, received, new, dup, pubs, err=''):
    pubs = sorted(p for p in pubs if p)
    conn.execute("INSERT INTO sys_rss_collect_log(run_at, feed_id, slot, received, new, dup, oldest_pub, newest_pub, err) "
                 "VALUES(?,?,?,?,?,?,?,?,?)",
                 (datetime.now().isoformat(timespec='seconds'), feed_id, slot, received, new, dup,
                  pubs[0] if pubs else '', pubs[-1] if pubs else '', err[:200]))


def report(conn, days=14):
    """사이트마다 — 회차 수 · 평균 받은 수/새 글/이미 있던 글 · 넘친 회차 · 게시 시각(그 사이트 시각) 분포."""
    since = (datetime.now() - timedelta(days=days)).isoformat(timespec='seconds')
    lines = []
    feeds = conn.execute("SELECT feed_id, site_name, feed_url, lang_code, COALESCE(feed_kind,'NEWS') FROM sys_rss_feed "
                         "WHERE record_status='LIVE' ORDER BY 5 DESC, 4, 2").fetchall()
    for fid, name, url, lang, kind in feeds:
        rs = conn.execute("SELECT received, new, dup, err FROM sys_rss_collect_log WHERE feed_id=? AND run_at>=?",
                          (fid, since)).fetchall()
        if not rs:
            continue
        ok = [r for r in rs if not r[3]]
        n = len(ok) or 1
        over = sum(1 for r in ok if r[0] and r[1] >= r[0])
        tz = tz_of(url, lang)
        hours = [0] * 24
        for (p,) in conn.execute("SELECT published FROM sys_ref_asset WHERE site_id=? AND published IS NOT NULL "
                                 "AND collected_at>=?", (fid, since)):
            try:
                d = datetime.fromisoformat(p)
                d = d if d.tzinfo else d.replace(tzinfo=timezone.utc)
                hours[d.astimezone(tz).hour] += 1
            except Exception:
                pass
        hist = ' '.join('%02d:%d' % (h, c) for h, c in enumerate(hours) if c)
        lines.append('%-4s %-3s %-30s 회차 %2d  받음 %4.1f  새 글 %4.1f  이미 %4.1f  넘침 %d  오류 %d\n      게시 시각(%s) %s' % (
            kind[:4], lang, (name or '')[:30], len(ok), sum(r[0] for r in ok) / n, sum(r[1] for r in ok) / n,
            sum(r[2] for r in ok) / n, over, len(rs) - len(ok), tz.key, hist or '-'))
    return '\n'.join(lines)


def selftest():
    import sqlite3
    ok = []

    def ck(name, cond):
        ok.append(bool(cond))
        print(('OK   ' if cond else 'FAIL ') + name)

    seoul, ny = ZoneInfo('Asia/Seoul'), ZoneInfo('America/New_York')
    ck('언어 기본 시간대', tz_of('https://www.kidok.com/rss', 'KO').key == 'Asia/Seoul')
    ck('사이트 주소가 언어를 덮는다', tz_of('https://www.christiantoday.com/rss.xml', 'EN').key == 'Europe/London')
    ck('나라 — 언어 기본값', country_of('https://www.kidok.com/rss', 'KO') == 'KR')
    ck('나라 — 도메인', country_of('https://www.leboncombat.fr/feed/', 'FR') == 'FR'
       and country_of('https://www.gospelherald.com.hk/rss.xml', 'ZHT') == 'HK')
    ck('나라 — 사이트 주소가 덮는다', country_of('https://www.christiantoday.com/rss.xml', 'EN') == 'GB')
    ck('나라 — 국제 사역은 빈칸', country_of('https://japanese-odb.org/feed/', 'JA') == ''
       and country_of('https://tgcchinese.org/feed', 'ZH') == '')
    t, nm = last_slot(datetime(2026, 10, 24, 4, 30, tzinfo=timezone.utc), seoul)   # 서울 13:30
    ck('서울 13:30 → 12시 회차', nm == 'NEWS-12' and t.hour == 12)
    t, nm = last_slot(datetime(2026, 10, 24, 1, 0, tzinfo=timezone.utc), seoul)    # 서울 10:00
    ck('서울 10:00 → 어제 22시 회차', nm == 'NEWS-22' and t.day == 23)
    t, nm = last_slot(datetime(2026, 10, 24, 21, 30, tzinfo=timezone.utc), ny)      # 뉴욕 17:30
    ck('뉴욕 17:30 → 17시 회차', nm == 'NEWS-17')
    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE sys_rss_feed(feed_id INTEGER, feed_url TEXT, lang_code TEXT, last_checked TEXT, "
              "record_status TEXT, enabled INTEGER, feed_kind TEXT)")
    c.execute("CREATE TABLE sys_ref_asset(ref_id INTEGER)")
    ensure(c)
    now = datetime(2026, 10, 24, 4, 30, tzinfo=timezone.utc)                       # 서울 13:30 · 뉴욕 00:30
    after = now.astimezone().replace(tzinfo=None).isoformat()                       # 지금 막 거둠
    before = (now - timedelta(hours=3)).astimezone().replace(tzinfo=None).isoformat()
    c.executemany("INSERT INTO sys_rss_feed VALUES(?,?,?,?, 'LIVE', 1, ?)", [
        (1, 'https://a.kr/rss', 'KO', before, 'NEWS'),      # 12시 회차 전에 거둠 → 할 차례
        (2, 'https://b.kr/rss', 'KO', after, 'NEWS'),       # 막 거둠 → 아님
        (3, 'https://c.kr/rss', 'KO', None, 'NEWS'),        # 한 번도 → 할 차례
        (4, 'https://d.kr/rss', 'KO', before, 'DEVOTIONAL'),  # 묵상은 이 길 아님
    ])
    due = dict(news_due(c, now))
    ck('회차 뒤 안 거둔 뉴스만', set(due) == {1, 3} and due[1] == 'NEWS-12')
    log(c, 1, 'NEWS-12', 30, 5, 25, ['2026-10-24T01:00:00+00:00', '2026-10-23T09:00:00+00:00'])
    r = c.execute('SELECT received, new, dup, oldest_pub FROM sys_rss_collect_log').fetchone()
    ck('기록', r[:3] == (30, 5, 25) and r[3].startswith('2026-10-23'))
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    with appdb.connect() as c:
        ensure(c)
        print(report(c))
