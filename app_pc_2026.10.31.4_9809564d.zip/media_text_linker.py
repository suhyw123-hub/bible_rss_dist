"""
media_text_linker.py
--------------------
영상 제목+설명 → 페리코프·엔티티 **통합 분석** (§19-11 근본 재설계, 언어 파라미터화).

핵심 = consume-first: ① 성경 책 참조를 먼저 인식·"소비"(글자 구간 점유) ② 소비 안 된
나머지 글자에서만 엔티티 매칭. → "요한복음"의 '요한', "출애굽기"의 '애굽' 등 **책 참조가
엔티티로 새는 오탐을 원천 차단**. 덕분에 인물 외 모든 유형도 안전하게 켤 수 있다.

언어별:
  · 책 이름 = book_names[lang] (현지 + EN 폴백)
  · 참조 마커 = LANG_MARKERS[lang] (장/절/편 vs : vs 章/節/篇 …)
  · KO 정밀 튜닝. 다른 언어는 그 언어 데이터 수집·분석 후 마커/충돌 보정.

범위: 페리코프(절 정밀 EXACT / 장만 CHAPTER) + 엔티티 8유형(PERSON·PLACE·NATION·GROUP·
IDOL·OBJECT·FEAST·SYSTEM). **TERM·DOCTRINE 은 언어마다 다르다** — `TYPES_BY_LANG` 참조
(EN 만 열려 있다. 한국어는 이름이 일상어라 오탐이 70%다 — 실측).
"""

import re
import unicodedata

import media_link               # 영상 연결 단일 소스(통합 표 이름·link_type)

try:
    import media_entity_link as _mel
except ImportError:
    from admin import media_entity_link as _mel

import db_media_range as _mr   # 낱말 경계 판정 단일 소스

# 교리 제외 8유형
ENTITY_TYPES = ('PERSON', 'PLACE', 'NATION', 'GROUP', 'IDOL', 'OBJECT', 'FEAST', 'SYSTEM')

#: ★★★ **언어마다 여는 유형이 다르다** (2026-09-09 실측).
#:   연결을 **만드는** 이 문과 재판정하는 `db_term_link_audit.JUDGE_TYPES` 의 목록이
#:   갈려 있었다 — 재판정은 TERM·DOCTRINE 을 보는데 만드는 쪽은 안 봤다. 그래서
#:   「부활」·「창조」·「신뢰」 용어가 있는데도 새로 담기는 영상에 안 붙었다
#:   (0.txt 13번 사용자 지적의 진짜 원인).
#:   ⚠ 그런데 **통째로 열면 언어에 따라 결과가 정반대다**(무작위 표본 25편을 읽어서):
#:     · EN — 596편 더 걸리고 **24/25 정당**. 영어 이름은 `Faith`·`Covenant`·
#:       `Original Sin`·`Total Depravity` 처럼 **신학 용어**라 제목에 나오면 그 주제다.
#:     · KO — 2,500편 중 962편 걸리는데 **8/25 만 정당**. 한국어 이름은 「하나님」·
#:       「말씀」·「사람」·「생명」·「교회」처럼 **일상어**이고 게다가 **채널 이름**에
#:       들어 있다(「생명의삶」·「매일성경 말씀 묵상」·「한마음교회」). 열면 안 된다.
#:   ⇒ 언어를 늘릴 때는 **그 언어로 먼저 재고** 여기에 적는다. 안 잰 언어는 기본값.
TYPES_BY_LANG = {
    'EN': ENTITY_TYPES + ('TERM', 'DOCTRINE'),
}


def types_for(lang) -> tuple:
    """그 언어에서 이름으로 걸 유형 — 안 잰 언어는 기본 8종."""
    return TYPES_BY_LANG.get((lang or '').upper(), ENTITY_TYPES)

# 언어별 참조 마커 (KO 정밀, 나머지 기본값 — 데이터 후 보정)
LANG_MARKERS = {
    'KO': {'chap': ['장', '편'], 'verse': ['절'], 'sep': [':'],
           'cues': ['통독', '낭독', '전체', '듣기', '읽기', '강해', '읽어주는', '듣는', '1독', '일독'],
           # 책 접미 — 인물명에 붙어 "책 참조"임을 나타냄(이사야'서'·사무엘'기'·요한'복음'). 길이 긴 것 먼저.
           'book_suffix': ['복음', '전서', '후서', '일서', '이서', '삼서', '애가', '계시록', '서', '기']},
    'EN': {'chap': [], 'verse': [], 'sep': [':'],
           'cues': ['chapter', 'reading', 'audio bible', 'full book']},
    'ZH': {'chap': ['章', '篇'], 'verse': ['節', '节'], 'sep': [':'], 'cues': ['通读', '朗读', '全本']},
    'JA': {'chap': ['章'], 'verse': ['節'], 'sep': [':'], 'cues': ['通読', '朗読']},
    'ES': {'chap': [], 'verse': [], 'sep': [':'], 'cues': ['capítulo', 'lectura']},
    'PT': {'chap': [], 'verse': [], 'sep': [':'], 'cues': ['capítulo', 'leitura']},
    'DE': {'chap': [], 'verse': [], 'sep': [':'], 'cues': ['Kapitel']},
    'FR': {'chap': [], 'verse': [], 'sep': [':'], 'cues': ['chapitre', 'lecture']},
    'RU': {'chap': [], 'verse': [], 'sep': [':'], 'cues': ['глава', 'чтение']},
}


def _nfc(s):
    return unicodedata.normalize('NFC', s or '')


def _markers(lang):
    return LANG_MARKERS.get((lang or 'KO').upper(), LANG_MARKERS['KO'])


def _tail_regex(mk):
    """책이름 뒤에 붙는 '장:절' 꼬리 정규식. group1=장, group2=절시작, group3=절끝."""
    chap = mk.get('chap', []) + mk.get('sep', [])
    chap_alt = '|'.join(re.escape(m) for m in chap) or ':'
    vmk = mk.get('verse', [])
    v_suf = ('(?:%s)?' % '|'.join(re.escape(m) for m in vmk)) if vmk else ''
    return (r'\s*[\-\s]?\s*(\d{1,3})\s*(?:' + chap_alt + r')\s*'
            r'(?:(\d{1,3})\s*' + v_suf + r')?'
            r'(?:\s*[-~∼]\s*(\d{1,3})\s*' + v_suf + r')?')


# ── 책 용어 / 페리코프 / verse_id ────────────────────────────────────────
def load_book_terms(conn, lang):
    """[(term, bcode, is_bare)] 긴 이름 우선. is_bare = 엔티티 이름과 완전 동일(다니엘·요나 등)."""
    L = (lang or 'KO').upper()
    ent_names = {r[0].strip() for r in conn.execute(
        "SELECT t.contents FROM sys_text_asset t JOIN sys_entity_master em "
        "ON em.entity_id=t.clicked_id WHERE t.text_type='ENTITY_NAME' "
        "AND UPPER(t.lang_code)=? AND em.record_status='LIVE' "
        # ⚠ 엔티티의 가림만 보고 **이름 자체의 가림**은 안 봤다 — 사람이 걷은
        #   이름 표기로 자동 연결이 계속 만들어진다(2026-09-10).
        "AND COALESCE(t.record_status,'LIVE')='LIVE'", (L,)) if r[0]}
    pairs = []
    for code in {L, 'EN'}:
        for col in ('full_name', 'short_name'):
            for bc, nm in conn.execute(
                    f"SELECT book_code, {col} FROM book_names WHERE UPPER(lang_code)=?", (code,)):
                if nm and nm.strip():
                    pairs.append((nm.strip(), bc))
    seen, out = set(), []
    for nm, bc in sorted(pairs, key=lambda x: -len(x[0])):
        if (nm, bc) in seen:
            continue
        seen.add((nm, bc))
        out.append((nm, bc, nm in ent_names))
    return out


def _peri_by_book(conn):
    m = {}
    for pid, sv, ev, bc in conn.execute(
            "SELECT p.pericope_id, p.start_vid, p.end_vid, bs.bcode "
            "FROM sys_pericope_asset p LEFT JOIN bible_index bs ON bs.verse_id=p.start_vid "
            "WHERE p.record_status='LIVE' AND p.peri_type='BODY'"):
        if bc is not None:
            m.setdefault(bc, []).append((pid, sv, ev))
    return m


def _chap_range(conn, bc, ch, _cache):
    k = (bc, ch)
    if k not in _cache:
        r = conn.execute("SELECT MIN(verse_id), MAX(verse_id) FROM bible_index "
                         "WHERE bcode=? AND chapter=?", (bc, ch)).fetchone()
        _cache[k] = (r[0], r[1]) if r and r[0] else (None, None)
    return _cache[k]


def _vid(conn, bc, ch, vs, _cache):
    k = (bc, ch, vs)
    if k not in _cache:
        r = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?",
                         (bc, ch, vs)).fetchone()
        _cache[k] = r[0] if r else None
    return _cache[k]


#: 약명 경계 규칙 스위치 — **db_media_badlink 가 「옛 규칙으로는 걸리는가」를 잴 때만**
#: 끈다(잣대 = 경계 없이는 걸리는데 경계로는 안 걸리는 것). 화면·수집은 늘 켠 채.
BOOK_STRICT = True


def _book_ok(text, s, term):
    """책 이름표가 그 자리에서 **낱말로** 쓰였는가 — 약명 앞 글자만 본다.
    긴 이름(사도행전·Genesis)은 안 가리고, 짧은 약명(전·수·Ps·Jn)만 앞이 한글·라틴이면 거부."""
    if s <= 0 or len(term) > 3:
        return True
    p = text[s - 1]
    if '가' <= p <= '힣' or p.isascii() and p.isalpha():
        return False
    return True


def _in_spans(span, spans):
    s, e = span
    return any(s < se and e > ss for ss, se in spans)


def match_terms(text, ent_terms, consumed=None, ctx_check=True, persons=None):
    """제목·설명문에서 엔티티 이름을 찾는다 → {eid: (term, start)}. **단일 문.**

    ★★★ **긴 이름이 먼저 걸리고 그 자리를 소비한다**(2026-09-09 실측 — 엘·레아·한나
      링크 조사). 한자는 낱말 경계가 없어 「亞伯」(아벨)이 亞伯拉罕(아브라함) 속에,
      「利亞」(레아)가 撒迦利亞(스가랴) 속에, 「以利」(엘리)가 以利亞(엘리야) 속에
      걸렸다(한자 이름 1,712건 중 1,575건이 다른 한자에 붙어 있었다). 경계 규칙으로는
      못 가르지만 **긴 이름을 먼저 잡고 그 자리를 소비하면** 짧은 조각은 자리를 잃는다.
    ⚠ `db_media_range.name_ok` 가 문자체계별 경계를 판정한다 — 여기서 다시 짜지 않는다.
    ⚠ 같은 엔티티의 여러 이름표가 있어도 한 번 걸리면 끝(첫 자리).
    ★ `ctx_check` — 이름 앞뒤 문맥(`db_media_range.name_context` — 성직 호칭·성·
      보통 낱말)까지 본다. 재판정 도구가 「문맥 때문에 떨어졌나」를 가를 때만 끈다.
    """
    text = text or ''
    low = text.lower()
    spans = list(consumed or [])
    flat = []
    for eid, terms in (ent_terms or {}).items():
        for term in terms:
            flat.append((term, eid))
    flat.sort(key=lambda x: (-len(x[0]), x[0]))
    out = {}
    for term, eid in flat:
        if eid in out:
            continue
        tl = term.lower()
        idx = low.find(tl)
        while idx != -1:
            end = idx + len(term)
            if not _in_spans((idx, end), spans) and _mr.name_ok(low, idx, end, term) \
                    and not (ctx_check and _mr.name_context(
                        text, idx, end, term, person=(persons is None or eid in persons))):
                out[eid] = (term, idx)
                spans.append((idx, end))
                break
            idx = low.find(tl, idx + 1)
    return out


def _clean_terms(ent_terms):
    """이름표에서 **낱말과 못 가리는 것**을 걷는다 (§195차 규칙).

    ⚠⚠ **가운뎃점을 가른다** — 우리 이름 규약이 「대표어 · 음역」이라
      통짜로 두면 「사망 · 마베트」가 통째로 안 걸린다.
    ⚠ 라틴 짧은 이름은 뺀다 — `Er`·`Eve`·`Ai` 는 경계를 지켜도 영어
      제목에서 이름인지 낱말인지 가릴 수 없다(`chapt-er`·`Expl-ai-ned`).
    """
    out = {}
    for eid, terms in (ent_terms or {}).items():
        keep = set()
        for t in terms:
            for part in str(t or '').split('·'):
                part = part.strip()
                if len(part) < 2:
                    continue
                if _mr._script(part) == 'LAT' \
                        and len(part) < _mr._LAT_MIN:
                    continue
                keep.add(part)
        if keep:
            out[eid] = keep
    return out


#: ★★★ **설명문이 있는 용어만 제목으로 건다**(2026-10-10 찬양 연결 점검).
#:   EN 은 TERM·DOCTRINE 이 열려 있는데(`TYPES_BY_LANG`), TERM 11,017 가운데
#:   설명문이 있는 것은 137개뿐이고 나머지는 원어 사전에서 **기계로 승격**한
#:   낱말이다. 그 이름이 「음역 · 뜻풀이」라 뜻풀이가 그대로 이름이 되어
#:   `worship`(1,298건) · `prayer` · `daily` · `what` · `this` · `from` · `time` ·
#:   `black` · `elevation`(Elevation Worship) 이 영어 제목 어디에나 걸렸다
#:   (실측 제목 연결 5,922건 — 거의 다 그 꼴).
#:   ⇒ 그 갈래는 **사람이 설명문을 쓴 것만** 이름으로 건다. 설명문을 쓰면
#:     저절로 다시 걸리기 시작한다(목록을 손으로 적지 않는다).
CURATED_TYPES = ('TERM', 'DOCTRINE')


def _curated(conn, ent_terms):
    """CURATED_TYPES 가운데 설명문(ENTITY_DESC)이 없는 것을 걷는다."""
    if not ent_terms:
        return ent_terms
    ph = ','.join('?' * len(CURATED_TYPES))
    drop = {r[0] for r in conn.execute(
        "SELECT em.entity_id FROM sys_entity_master em"
        " WHERE em.entity_type IN (%s)"
        "   AND NOT EXISTS(SELECT 1 FROM sys_text_asset d"
        "        WHERE d.clicked_id=em.entity_id AND d.text_type='ENTITY_DESC'"
        "          AND COALESCE(d.record_status,'LIVE')='LIVE'"
        "          AND LENGTH(TRIM(COALESCE(d.contents,'')))>0)" % ph,
        CURATED_TYPES)}
    return {e: t for e, t in ent_terms.items() if e not in drop}


#: 이름으로 소비할 최소 길이 — 짧은 채널 이름(「Joy」)이 진짜 낱말을 먹지 않게
SKIP_MIN = 4


def _owner_names(conn):
    """찬양 사역자 이름(모든 언어) + 등록 채널 이름 → 소비할 이름들(긴 것 먼저).

    ★★★ **이름이 성경 이름을 품는다**(2026-10-10 실측) — 「다윗과요나단」(찬양팀)이
      다윗·요나단에, 「갈렙 찬양대」가 갈렙에, `Elevation Worship` 이 낱말
      `elevation` 에, `Jesús Adrián Romero` 가 인물에 걸렸다. 그 자리는 **누가
      불렀나**이지 노래가 말하는 인물이 아니다 ⇒ 3패스 전에 자리를 소비한다.
    ⚠ 표가 없으면(사본 DB) 빈 목록 — 조용히 옛 동작.
    """
    out = set()
    for sql in ("SELECT contents FROM sys_text_asset WHERE text_type='ARTIST_NAME'"
                " AND COALESCE(record_status,'LIVE')='LIVE'",
                "SELECT channel_name FROM sys_media_channel"
                " WHERE COALESCE(record_status,'LIVE')='LIVE'"):
        try:
            for (nm,) in conn.execute(sql):
                nm = _nfc((nm or '').strip())
                if len(nm) >= SKIP_MIN:
                    out.add(nm)
                    # ⚠ 한글 이름은 띄어 쓰기도 붙여 쓰기도 한다(「다윗과 요나단」·「다윗과요나단」)
                    if ' ' in nm and any('가' <= ch <= '힣' for ch in nm):
                        out.add(nm.replace(' ', ''))
        except Exception:
            pass
    return sorted(out, key=lambda x: (-len(x), x))


def _consume_names(t, names, consumed):
    """t 안의 이름 자리를 consumed 에 더한다(경계를 지킨다 · 겹치면 건너뜀)."""
    low = t.lower()
    for nm in names or ():
        nl = nm.lower()
        i = low.find(nl)
        while i != -1:
            e = i + len(nl)
            if not _in_spans((i, e), consumed) and _mr.name_ok(low, i, e, nm):
                consumed.append((i, e))
            i = low.find(nl, i + 1)


# ── 컨텍스트(미리 로드해 재사용) ─────────────────────────────────────────
def build_context(conn, lang, types=None):
    types = types or types_for(lang)      # ⚠ 언어마다 다르다(TYPES_BY_LANG)
    mk = _markers(lang)
    L = (lang or 'KO').upper()
    # 충돌 이름(엔티티명이 책이름의 부분문자열) + 책접미 → "이름+접미"를 책으로 소비
    book_strings = {r[0].strip() for r in conn.execute(
        "SELECT full_name FROM book_names WHERE UPPER(lang_code)=? UNION "
        "SELECT short_name FROM book_names WHERE UPPER(lang_code)=?", (L, L)) if r[0]}
    ent_names = {r[0].strip() for r in conn.execute(
        "SELECT t.contents FROM sys_text_asset t JOIN sys_entity_master em "
        "ON em.entity_id=t.clicked_id WHERE t.text_type='ENTITY_NAME' "
        "AND UPPER(t.lang_code)=? AND em.record_status='LIVE' "
        # ⚠ 엔티티의 가림만 보고 **이름 자체의 가림**은 안 봤다 — 사람이 걷은
        #   이름 표기로 자동 연결이 계속 만들어진다(2026-09-10).
        "AND COALESCE(t.record_status,'LIVE')='LIVE'", (L,)) if r[0]}
    collision = {en for en in ent_names if len(en) >= 2 and any(en in b for b in book_strings)}
    suffix_rx = None
    sufs = mk.get('book_suffix', [])
    if collision and sufs:
        names = '|'.join(re.escape(n) for n in sorted(collision, key=len, reverse=True))
        sfx = '|'.join(re.escape(s) for s in sufs)
        suffix_rx = re.compile('(?:' + names + ')(?:' + sfx + ')')
    return {
        'lang': lang, 'mk': mk, 'tail': _tail_regex(mk),
        'books': load_book_terms(conn, lang),
        'pbb': _peri_by_book(conn),
        'ent_terms': _curated(conn, _clean_terms(_mel.load_entity_terms(conn, types=types))),
        'suffix_rx': suffix_rx,
        # ★ 사역자·채널 이름 — 그 자리는 용어로 안 읽는다(`_owner_names`)
        'owner_names': _owner_names(conn),
        # ★ 인물 번호 — 이름 앞뒤 문맥(호칭·성)은 인물에만 건다(`match_terms`)
        'person_ids': {r[0] for r in conn.execute(
            "SELECT entity_id FROM sys_entity_master WHERE entity_type='PERSON'"
            "   AND COALESCE(record_status,'LIVE')='LIVE'")},
        'rng': {}, 'vid': {},   # verse_id 캐시
    }


def analyze(conn, text, ctx):
    """text → {'pericope':[(pid,conf)], 'entity':[eid]}. ctx=build_context 결과(재사용)."""
    t = _nfc(text)
    mk, tail, books, pbb = ctx['mk'], ctx['tail'], ctx['books'], ctx['pbb']
    has_cue = any(c in t for c in mk.get('cues', []))
    consumed = []
    peri = {}
    # ★★★ **구간을 버리지 않고 그대로 낸다** (2026-09-03 사용자 지시 「구절
    #   구간 단위로 연결하도록 개선하라」). 아래 1패스는 이미 `lo~hi` 를
    #   계산해 놓고 **그것을 겹치는 페리코프 전부로 바꿔** 버렸다 — 「민수기
    #   26장」 영상 하나가 그 장을 나눈 페리코프 16개에 16줄로 걸린 원인이
    #   바로 그 자리다. 이제 구간을 `ranges` 로 함께 내보내고 링크는 그것으로
    #   건다. `pericope` 는 옛 호출부(rebuild_all·검토 화면)를 위해 남긴다.
    ranges = []

    # 1패스: 책 + 장:절  → 페리코프 + 소비
    # ★★★ 두 가지를 본다(2026-09-09 구절 연결 전수 조사 — 「사도행전 2:1」이 행2:1 과
    #   **전2:1** 둘로, 「오전 11:00」이 전도서 11장으로 걸려 있었다):
    #   ⓐ 긴 이름이 소비한 자리는 짧은 약명이 다시 못 읽는다(consumed 를 실제로 본다 —
    #      그전에는 적어 두기만 하고 안 봤다) ⓑ 약명 앞에 한글·라틴 글자가 붙어
    #      있으면 낱말 속이다(`_book_ok` — db_media_range 의 약명 규칙과 같은 판정).
    for term, bc, _bare in books:
        peris = pbb.get(bc)
        for m in re.finditer(re.escape(term) + tail, t):
            if BOOK_STRICT and (_in_spans(m.span(), consumed)
                                or not _book_ok(t, m.start(), term)):
                continue
            consumed.append(m.span())
            if not peris:
                continue
            ch = int(m.group(1))
            vs = int(m.group(2)) if m.group(2) else None
            ve = int(m.group(3)) if m.group(3) else vs
            if vs is not None:
                cmin, cmax = _chap_range(conn, bc, ch, ctx['rng'])
                rs = _vid(conn, bc, ch, vs, ctx['vid']) or cmin
                re_ = _vid(conn, bc, ch, ve, ctx['vid']) or cmax
                if rs is None:
                    continue
                lo, hi, conf = min(rs, re_), max(rs, re_), 'EXACT'
            else:
                lo, hi = _chap_range(conn, bc, ch, ctx['rng'])
                if lo is None:
                    continue
                conf = 'CHAPTER'
            if (lo, hi, conf) not in ranges:
                ranges.append((lo, hi, conf))
            for pid, psv, pev in peris:
                if psv <= hi and pev >= lo and peri.get(pid) != 'EXACT':
                    peri[pid] = conf

    # 1.5패스: "충돌이름+책접미"(이사야서·베드로서·사무엘기) 소비 — book_names에 없는 KO 책 형태
    if ctx.get('suffix_rx'):
        for m in ctx['suffix_rx'].finditer(t):
            consumed.append(m.span())

    # 2패스: 책 이름만(장 없음) 소비 — 엔티티 누수 차단. bare는 cue 있을 때만, 2자 이상만.
    #
    # ★★★ **여기도 낱말 경계를 지킨다** (2026-09-08 — 미탐의 뿌리).
    #   경계를 안 보면 라틴 약명이 낱말 속에서 소비를 만들어 **진짜 이름을
    #   먹는다**: `Isa`(이사야)가 `Isaac` 앞 세 글자를 소비해 「Abraham and
    #   Isaac」에서 **이삭이 통째로 사라졌다**(실측).
    #   ⚠ 오연결(3패스)과 **반대 방향의 같은 병**이다 — 한쪽만 고치면 남는다.
    for term, bc, is_bare in books:
        if len(term) < 2:
            continue
        if is_bare and not has_cue:
            continue
        for m in re.finditer(re.escape(term), t):
            if not _in_spans(m.span(), consumed) \
                    and _mr.name_ok(t, m.start(), m.end(), term):
                consumed.append(m.span())

    # 3패스: 소비 안 된 나머지서 엔티티 매칭(8유형, 교리 제외)
    #
    # ★★★ **낱말 경계를 지킨다** (2026-09-08 — 오연결 11,308건의 뿌리).
    #   여기는 `low.find` 로 **부분 문자열**만 봤다: 「엘」(EN `Er`)이
    #   `chapter` 에 2,024건 · 「아이」(`Ai`)가 `Explained` 에 1,773건 ·
    #   「벨」(`Bel`)이 `Abel` 에 · 「함」(`Ham`)이 `Abraham` 에 걸렸다.
    #   §195차가 `db_media_range.name_ok` 로 경계 판정을 만들어 두었는데
    #   **이 자리가 그것을 안 썼다** — 판정의 집은 거기 하나다.
    #   ⇒ 2026-09-09 — **긴 이름 우선·소비**(`match_terms`)로 옮겼다. 한자 이름
    #     조각(亞伯 in 亞伯拉罕)은 경계로 못 가르고 이것으로 가른다.
    # ★★★ **왜 걸렸는지를 버리지 않는다**(2026-09-11 사용자 「연결추천한 용어를
    #   내가 해제한 것들이 많다. **기록이 남아 있다면 분석해 보아라**」).
    #   ⚠⚠⚠ 실측 — 사람이 뗀 264건의 `source` 가 **전부 비어 있었다.** 무엇을
    #     뗐는지는 알아도 **왜 걸렸는지를 몰라** 규칙을 고칠 재료가 안 됐다.
    #     `match_terms` 는 **걸린 말과 자리를 이미 돌려주는데** 여기서
    #     `.keys()` 로 버리고 있었다.
    _consume_names(t, ctx.get('owner_names'), consumed)
    hits = match_terms(t, ctx['ent_terms'], consumed,
                       persons=ctx.get('person_ids'))
    return {'pericope': list(peri.items()), 'entity': sorted(hits),
            'entity_why': hits, 'ranges': ranges}


# ── 수집기 공용: 분석 → 링크 삽입(멱등) ────────────────────────────────
#: ★★★ **유형마다 안 잇는 용어 이름**(2026-09-11 사용자 「찬양에서 **「가사」를
#:   주제로 연결**하고 있다. 지명으로 등록된 「가사」는 찬양에서는 빼야겠다」).
#:   ⚠⚠ **거르는 말에 넣으면 안 된다** — 그것은 **영상을 통째로 안 담는** 문이라
#:     멀쩡한 찬양 19편이 함께 사라진다(실측). 여기는 **잇지만 않는** 자리다.
#:   ★ 같은 글자가 갈래마다 딴 뜻인 자리 — 「가사」는 유대 지명(Gaza)이고
#:     찬양 제목의 「가사」는 lyrics 다. **설교에서는 지명이 맞다** — 그래서
#:     통째로 걷지 않고 **갈래로 가른다.**
SKIP_ENTITY_BY_TYPE = {
    'WORSHIP': {'가사'},
}
_SKIP_CACHE = {}


def skip_reset():
    """기억한 것을 버린다 — **갈래가 바뀌면**(찬양이 아님 등) 부른다."""
    _SKIP_CACHE.clear()


def _skip_names():
    """안 잇는 이름 전부(합집합) — 거의 모든 용어가 여기서 걸러진다."""
    if 'all' not in _SKIP_CACHE:
        u = set()
        for v in SKIP_ENTITY_BY_TYPE.values():
            u |= set(v)
        _SKIP_CACHE['all'] = u
    return _SKIP_CACHE['all']


def _skip_entity(conn, mid, eid):
    """이 영상 갈래에서 **그 용어를 안 잇는가**.

    ⚠ **이름을 먼저 본다** — 그래야 용어 수천 개 중 걸릴 수 있는 몇 개만
      갈래를 묻는다(조회가 늘지 않는다).
    """
    allow = _skip_names()
    if not allow:
        return False
    nk = ('n', eid)
    if nk not in _SKIP_CACHE:
        _SKIP_CACHE[nk] = {
            (x[0] or '').strip() for x in conn.execute(
                "SELECT contents FROM sys_text_asset"
                "  WHERE text_type='ENTITY_NAME' AND clicked_id=?"
                "    AND COALESCE(record_status,'LIVE')='LIVE'", (eid,))}
    names = _SKIP_CACHE[nk] & allow
    if not names:
        return False
    tk = ('t', mid)
    if tk not in _SKIP_CACHE:
        r = conn.execute(
            "SELECT COALESCE(media_type,'') FROM sys_media_asset"
            # status-ok: 번호 하나로 갈래만 읽는다 — 가린 영상도 갈래는 같다
            "  WHERE media_id=?", (mid,)).fetchone()
        _SKIP_CACHE[tk] = (r[0] if r else '')
    return bool(names & set(SKIP_ENTITY_BY_TYPE.get(_SKIP_CACHE[tk]) or ()))


#: 걷은 자국을 남기는 표식 — 되돌릴 수 있게
SKIP_SWEEP_NOTE = 'SKIP_ENTITY_SWEEP'


def sweep_skip(conn, dry=False, log=print):
    """**이미 걸린 연결**에 갈래 규칙을 다시 건다 -> 걷은 수.

    ★★★ **왜 필요한가**(2026-09-12 실측) — `_ins_link` 는 **담을 때** 갈래를
      본다. 그런데 **분류가 나중에 바뀌면**(설교 -> 찬양) 그때 걸린 연결이
      그대로 남는다. 실측 §241차 ⑫ 에서 걷은 「가사」 연결이 **5건 다시**
      생겨 있었다 — 새로 걸린 것이 아니라 **분류가 옮겨 온 것**이다.
    ⚠ **사람이 이은 것은 안 건드린다**(`confidence='MANUAL'`).
    ⚠ **쿼터 0** — DB 만 읽는다.
    """
    names = _skip_names()
    if not names:
        return 0
    ph = ','.join('?' * len(names))
    rows = conn.execute(
        "SELECT l.sys_link_id, COALESCE(a.media_type,''), t.contents"
        "  FROM sys_link_asset l"
        # status-ok: 가린 영상의 잘못된 연결도 걷는다 — 상태로 거르면
        #            되살리는 날 틀린 연결이 함께 살아난다(§241차 ⑥)
        "  JOIN sys_media_asset a ON a.media_id=l.clicked_id"
        "  JOIN sys_text_asset t ON t.clicked_id=l.target_id"
        "       AND t.text_type='ENTITY_NAME'"
        "       AND COALESCE(t.record_status,'LIVE')='LIVE'"
        " WHERE l.link_type='MEDI_ENTI'"
        "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
        "   AND COALESCE(l.confidence,'') <> 'MANUAL'"
        "   AND t.contents IN (%s)" % ph, tuple(sorted(names))).fetchall()
    hit = [r[0] for r in rows
           if (r[2] or '').strip() in (SKIP_ENTITY_BY_TYPE.get(r[1]) or ())]
    if hit and not dry:
        for lid in hit:
            conn.execute(
                "UPDATE sys_link_asset SET record_status='HIDE', source=?"
                "  WHERE sys_link_id=?", (SKIP_SWEEP_NOTE, lid))
        conn.commit()
    log('  [갈래 규칙] 다시 걸어 걷은 연결 %d건%s'
        % (len(hit), ' (미리보기)' if dry else ''))
    return len(hit)


def _title_len(text):
    """`제목 + 줄바꿈 + 설명문` 에서 **제목이 어디까지인가**.

    ⚠ 줄바꿈이 없으면 통째로 제목으로 본다(설명문이 없는 영상).
    """
    t = str(text or '')
    i = t.find(chr(10))
    return len(t) if i < 0 else i


def why_src(hit, title_len):
    """`match_terms` 결과 한 줄 → 근거 글자(`'TITLE:다윗'`).

    ★ **제목에서 걸렸나 설명문에서 걸렸나**가 갈린다 — 실측 사람이 뗀 것의
      상당수가 **앨범 소개문**에서 걸린 것이었다(「긍휼_김단비」의 「십자가의
      사랑만이 우리의 온전한 구원이…」). 그 사실을 적어 두어야 규칙을 고친다.
    ⚠ 못 만들면 `None` — **지어내지 않는다.**
    """
    if not hit:
        return None
    try:
        term, start = hit[0], hit[1]
    except (TypeError, IndexError, KeyError):
        return None
    try:
        return media_link.src(
            'TITLE' if int(start) < int(title_len or 0) else 'DESC',
            hint=str(term or '')[:40])
    except Exception:
        return None


def _ins_link(conn, mid, scope, key, conf, dry_run, source=None):
    """통합 표에 멱등 삽입. ⚠ `target_id` 는 숫자다(옛 `str(key)` 아님).

    ★ `source` 를 주면 **왜 걸렸는지**를 함께 적는다(⑤ 주제 탭의 「어떻게」 칸이
      그것을 읽는다). ⚠ **있는 줄의 근거는 안 덮는다** — 처음 건 까닭이 맞다.
    """
    if dry_run or not mid or mid <= 0:
        return 0
    ty = media_link.lt(scope)
    tgt = media_link.key_int(key)
    if not ty or tgt is None:
        return 0
    if scope == 'ENTITY' and _skip_entity(conn, mid, tgt):
        return 0
    ex = conn.execute(
        "SELECT 1 FROM %s WHERE link_type=? AND clicked_id=? AND target_id=?"
        % media_link.TBL, (ty, mid, tgt)).fetchone()  # status-ok: 연결이 이미 있나 보는 자리 — 가림을 빼면 뗀 연결이 도로 생긴다
    if ex:
        return 0
    conn.execute(
        "INSERT INTO %s (link_type, clicked_id, target_id, record_status, "
        "confidence, source) VALUES (?,?,?,'LIVE',?,?)" % media_link.TBL,
        (ty, mid, tgt, conf, source))
    return 1


def _ins_range(conn, mid, lo, hi, conf, dry_run):
    """구절 구간 연결(`MEDI_VERS` + `end_id`) 멱등 삽입."""
    if dry_run or not mid or mid <= 0:
        return 0
    ty = media_link.lt('VERSE')
    if not ty:
        return 0
    ex = conn.execute(
        "SELECT sys_link_id FROM %s WHERE link_type=? AND clicked_id=?"
        " AND target_id=?" % media_link.TBL, (ty, mid, lo)).fetchone()  # status-ok: 연결이 이미 있나 보는 자리 — 가림을 빼면 뗀 연결이 도로 생긴다
    if ex:
        conn.execute("UPDATE %s SET end_id=?, record_status='LIVE'"
                     " WHERE sys_link_id=?" % media_link.TBL, (hi, ex[0]))
        return 0
    conn.execute(
        "INSERT INTO %s (link_type, clicked_id, target_id, end_id,"
        " record_status, confidence) VALUES (?,?,?,?,'LIVE',?)"
        % media_link.TBL, (ty, mid, lo, hi, conf))
    return 1


def link_media(conn, media_id, text, ctx, also_entity=None, dry_run=False,
               scope='ENTI'):
    """consume-first 분석 → **구절 구간** + ENTITY 링크 멱등 삽입.

    ★★★ **연결 대상이 페리코프에서 구절 구간으로 바뀌었다** (2026-09-03
      사용자 지시). 그전에는 `analyze` 가 구한 구간에 **겹치는 페리코프
      전부**에 한 줄씩 걸어, 장 하나를 다룬 영상이 16줄이 됐다.
      ⇒ 이제 구간 하나 = 링크 하나(`MEDI_VERS` + `end_id`).
    ★ **구간을 못 정하면 보관함**(`sys_media_pending`)에 담는다 — 근거 없는
      연결을 자동으로 만드느니 담아 두고 사람이 정한다.
      ⚠ 엔티티 연결은 그대로 만든다 — 주제 강해는 구절이 아니라 **용어**에
        걸리는 것이 맞다(실측: 구간을 못 읽는 것 대부분이 주제 강해다).

    → (신규 엔티티수, 신규 구간수).
    """
    r = analyze(conn, text, ctx)
    ent_ids = set(r['entity'])
    if also_entity:
        try:
            ent_ids.add(int(also_entity))
        except (TypeError, ValueError):
            pass
    _why = r.get('entity_why') or {}
    _tl = _title_len(text)
    ne = sum(_ins_link(conn, media_id, 'ENTITY', eid, 'AUTO', dry_run,
                       source=why_src(_why.get(eid), _tl))
             for eid in ent_ids)
    rng = r.get('ranges') or []
    nv = sum(_ins_range(conn, media_id, lo, hi, conf, dry_run)
             for lo, hi, conf in rng)
    if not rng and not dry_run and media_id and media_id > 0:
        try:
            import db_media_range as _mr
            _mr.init(conn)
            _mr.hold(conn, media_id, scope,
                     _mr.R_NONE if not ent_ids else _mr.R_NONE,
                     note=('용어 %d개는 연결됨' % len(ent_ids)) if ent_ids else None)
        except Exception as _e:
            print('[보관함] %s' % _e)
    return ne, nv


# ── 백업 + 전체 재구축 (consume-first) ──────────────────────────────────
def _ensure_conf_col(conn):
    """통합 표에 `confidence` 칸이 있는지. (`db_link_unify` 가 만든다)"""
    cols = [r[1] for r in conn.execute("PRAGMA table_info(%s)" % media_link.TBL)]
    if 'confidence' not in cols:
        conn.execute("ALTER TABLE %s ADD COLUMN confidence TEXT" % media_link.TBL)


def _ensure_backup_tbl(conn):
    """백업표 — **`end_id` 를 함께 담는다**.

    ⚠⚠ 그전에는 그 칸이 없어 **구간 링크를 되살릴 수 없었다**(범위가 사라진다).
      구간 축을 백업 범위에 넣은 날 함께 열어야 하는 자리였다.
    ⚠ 옛 백업 행의 `end_id` 는 NULL 이고 그것이 맞다 — 그때는 구간이 없었다.
    """
    conn.execute("CREATE TABLE IF NOT EXISTS sys_media_link_backup "
                 "(link_id INTEGER, media_id INTEGER, scope TEXT, "
                 " scope_key TEXT, record_status TEXT, link_confidence TEXT, "
                 " backed_at TEXT)")
    cols = [r[1] for r in conn.execute(
        "PRAGMA table_info(sys_media_link_backup)")]
    if 'end_id' not in cols:
        conn.execute("ALTER TABLE sys_media_link_backup "
                     "ADD COLUMN end_id INTEGER")


def backup_rounds(conn, limit=20):
    """백업 회차 목록 → [(때, 건수)] — 화면이 「무엇으로 되돌릴까」를 묻는다."""
    _ensure_backup_tbl(conn)
    return conn.execute(
        "SELECT backed_at, COUNT(*) FROM sys_media_link_backup "
        "GROUP BY backed_at ORDER BY backed_at DESC LIMIT ?",  # status-ok: 백업 장부다 — 여기서 `record_status` 는 **되돌릴 값**이지 거를 조건이 아니다
        (int(limit),)).fetchall()


def restore_backup(conn, at=None, log=print):
    """백업 회차로 **되돌린다** — 지금 자동 링크를 걷고 그 회차를 되살린다.

    ★★★ **되돌릴 길이 없으면 [풀 재연결]은 되돌릴 수 없는 대량 변경이다.**
      백업표는 2026-06-14 부터 쌓이기만 하고 **읽는 곳이 0곳**이었다 —
      화면은 「되돌리기 가능」이라 적고 있었다(§0-1 거짓말).
    ⚠⚠ **`MANUAL` 은 양쪽에서 다 지킨다** — 걷을 때도 안 걷고, 백업에 있어도
      지금 것을 덮지 않는다. 사람의 판단이 백업 회차보다 뒤에 올 수 있다.
    ⚠ 상태·confidence 를 **그대로** 되살린다(HIDE 였으면 HIDE 로).

    → (되살린 수, 걷은 수)
    """
    _ensure_backup_tbl(conn)
    if at is None:
        r = conn.execute(
            "SELECT MAX(backed_at) FROM sys_media_link_backup").fetchone()  # status-ok: 백업 장부다 — 여기서 `record_status` 는 **되돌릴 값**이지 거를 조건이 아니다
        at = r[0] if r else None
    if not at:
        log('되돌릴 백업이 없습니다.')
        return 0, 0
    rows = conn.execute(
        "SELECT media_id, scope, scope_key, record_status,"
        "       COALESCE(link_confidence,''), end_id"  # status-ok: 백업 장부다 — 여기서 `record_status` 는 **되돌릴 값**이지 거를 조건이 아니다
        "  FROM sys_media_link_backup WHERE backed_at=?", (at,)).fetchall()
    if not rows:
        log('그 회차에 담긴 것이 없습니다: %s' % at)
        return 0, 0
    _ty = media_link.types(['PERICOPE', 'ENTITY', 'VERSE'])
    _ph = ','.join('?' * len(_ty))
    gone = conn.execute(
        "DELETE FROM %s WHERE link_type IN (%s)"
        " AND COALESCE(confidence,'') <> 'MANUAL'"
        % (media_link.TBL, _ph), _ty).rowcount
    back = 0
    for mid, scope, key, st, conf, eid in rows:
        ty = media_link.lt(scope)
        tgt = media_link.key_int(key)
        if not ty or tgt is None or not mid:
            continue
        if conf.upper() == 'MANUAL':
            continue                     # 지금 것이 이미 살아 있다
        conn.execute(
            "INSERT INTO %s (link_type, clicked_id, target_id, end_id,"
            " record_status, confidence) VALUES (?,?,?,?,?,?)"
            % media_link.TBL,
            (ty, mid, tgt, eid, st or 'LIVE', conf or None))
        back += 1
        if back % 2000 == 0:
            conn.commit()
    conn.commit()
    log('%s 회차로 되돌렸습니다 — 되살린 %d · 걷은 %d' % (at, back, gone))
    return back, gone


def rebuild_all(conn, types=ENTITY_TYPES, log=print, dry_run=False):
    """자동 링크를 백업 → 걷고 → 전부 다시 잇는다(consume-first).

    ★★★ **구간 축을 함께 다룬다** (2026-09-08 수리). 그전에는 지우고 만드는
      범위가 `PERICOPE+ENTITY` 뿐이라 ⓐ **구간(`MEDI_VERS`)을 손도 안 대고**
      ⓑ §193차에 폐기된 **단락 축을 새로 만들었다**(실측 `MEDI_PERI` 0건 ·
      `MEDI_VERS` 9,000건). 이제 셋을 함께 걷고 **구간으로** 다시 잇는다.
    ★★★ **사람이 이은 것(`MANUAL`)은 안 걷는다** — 실측 17건. 자동 재구축이
      사람의 판단을 지우면 되돌릴 길이 없다.
    ★ **링크를 만드는 문은 `_ins_link`·`_ins_range` 하나다** — 여기서 INSERT 를
      또 쓰면 멱등·구간 규칙이 두 벌이 되어 한쪽만 고쳐진다(§199차).
    ⚠ **보관함은 안 건드린다** — 대기줄은 사람이 정리하는 자리이고, 재구축이
      그것을 다시 채우면 이미 판정한 것이 되살아난다.

    미디어는 자기 lang_code 로 분석(언어별 컨텍스트 재사용). → stats.
    """
    _ensure_conf_col(conn)
    if not dry_run:
        # ⚠⚠ **여기가 이 파일에서 가장 위험한 자리다.** 옛 표에서는 그 표에
        #   영상 연결밖에 없어 `scope IN(...)` 한 줄이면 됐지만, 통합 표에서
        #   그렇게 하면 **남의 연결까지 지운다**(배포 경로 사고와 같은 계열).
        #   ⇒ **온전한 link_type 목록**으로만 좁힌다(`substr(...,-4)` 금지).
        _ty = media_link.types(['PERICOPE', 'ENTITY', 'VERSE'])
        _ph = ','.join('?' * len(_ty))
        _ensure_backup_tbl(conn)
        bk = conn.execute(
            "SELECT COUNT(*) FROM %s WHERE link_type IN (%s)"
            % (media_link.TBL, _ph), _ty).fetchone()[0]  # status-ok: 걷기 전후를 세는 자리 — 가림까지 세어야 「몇 개를 걷었나」가 맞는다
        # 백업 표는 **옛 칸 이름 그대로** 둔다(옛 백업과 나란히 읽힌다) —
        # 값만 옛 꼴(scope/scope_key)로 되돌려 적는다.
        conn.execute(
            "INSERT INTO sys_media_link_backup "
            "(link_id, media_id, scope, scope_key, record_status,"
            " link_confidence, backed_at, end_id) "  # status-ok: **가림까지 통째로** 떠 놓아야 되돌릴 수 있다
            "SELECT sys_link_id, clicked_id, "
            "       CASE link_type %s END, CAST(target_id AS TEXT), "
            "       record_status, COALESCE(confidence,''), datetime('now'),"
            "       end_id "
            "FROM %s WHERE link_type IN (%s)"
            % (' '.join("WHEN '%s' THEN '%s'" % (t, media_link.SCOPE_OF[t[5:]])
                        for t in _ty), media_link.TBL, _ph), _ty)
        # ⚠⚠ **`MANUAL` 은 남긴다** — 사람이 이은 연결이다.
        conn.execute(
            "DELETE FROM %s WHERE link_type IN (%s)"
            " AND COALESCE(confidence,'') <> 'MANUAL'"
            % (media_link.TBL, _ph), _ty)
        _man = conn.execute(
            "SELECT COUNT(*) FROM %s WHERE link_type IN (%s)"
            " AND COALESCE(confidence,'')='MANUAL'"
            % (media_link.TBL, _ph), _ty).fetchone()[0]  # status-ok: 걷기 전후를 세는 자리 — 가림까지 세어야 「몇 개를 걷었나」가 맞는다
        log("영상 링크 %d개 백업(sys_media_link_backup) 후 걷음"
            " — 사람이 이은 %d개는 그대로 둡니다" % (bk, _man))
        _bkat = conn.execute(
            "SELECT MAX(backed_at) FROM sys_media_link_backup").fetchone()[0]  # status-ok: 백업 장부다 — 여기서 `record_status` 는 **되돌릴 값**이지 거를 조건이 아니다
    # 미디어를 lang 별로 묶어 컨텍스트 재사용. 제목+영상설명(yt_desc)을 함께 분석.
    import json as _json
    by_lang = {}
    for mid, title, lang, desc in conn.execute(
            "SELECT media_id, title, COALESCE(lang_code,'KO'), description FROM sys_media_asset "
            "WHERE COALESCE(record_status,'LIVE')='LIVE'"):
        ytd = ''
        if desc:
            try:
                ytd = (_json.loads(desc) or {}).get('yt_desc', '') or ''
            except Exception:
                ytd = ''
        # ⚠ **이음쇠는 줄바꿈 하나** — `_title_len` 이 그것으로 제목 끝을
        #   찾는다(빈칸으로 이으면 제목과 설명문을 못 가른다).
        text = ((title or '') + chr(10) + ytd).rstrip()
        by_lang.setdefault((lang or 'KO').upper(), []).append((mid, text))
    st = {'media_e': 0, 'media_p': 0, 'ent': 0, 'exact': 0,
          'chapter': 0, 'removed': 0, 'manual': 0, 'at': None}
    for lang, rows in by_lang.items():
        log(f"[{lang}] {len(rows)}개 분석…")
        ctx = build_context(conn, lang, types=types)
        for i, (mid, title) in enumerate(rows):
            r = analyze(conn, title, ctx)
            if r['entity']:
                st['media_e'] += 1
            if r.get('ranges'):
                st['media_p'] += 1
            _why = r.get('entity_why') or {}
            _tl = _title_len(title)
            for eid in r['entity']:
                st['ent'] += _ins_link(
                    conn, mid, 'ENTITY', eid, 'AUTO', dry_run,
                    source=why_src(_why.get(eid), _tl)) if not dry_run else 1
            for lo, hi, conf in (r.get('ranges') or []):
                if not dry_run:
                    _ins_range(conn, mid, lo, hi, conf, dry_run)
                st['exact' if conf == 'EXACT' else 'chapter'] += 1
            if (i + 1) % 1000 == 0:
                if not dry_run:
                    conn.commit()
                log(f"  {i+1}/{len(rows)}")
        if not dry_run:
            conn.commit()
    if not dry_run:
        try:
            st['removed'], st['manual'], st['at'] = bk, _man, _bkat
        except NameError:
            pass
    return st
