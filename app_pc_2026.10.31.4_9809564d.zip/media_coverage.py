"""
media_coverage.py
-----------------
미디어 커버리지 집계(순수 로직, Tk 없음) — §32 하이브리드 수집의 ④단계.

엔티티/페리코프별로 "연결된 영상 수"를 집계해 **빈틈(임계 미만) 타겟**을 산출한다.
이 빈틈 목록이 ⑤단계(빈틈 타겟만 API 검색)의 입력이 된다.

count 정의:
  total  = 그 타겟에 연결된 LIVE 미디어 수(검토 전 포함)
  active = is_active=1 (승인되어 사용자에게 보이는) 미디어 수  ← 커버리지 판단 기준

⚠⚠⚠ **2026-09-06 — 두 값이 다 고장 나 있었다**(사용자 물음에서 실측으로 잡았다).
  이 파일이 **커버리지 화면**과 **저밀도 집중수집**의 재료라서 둘 다 틀린 것을
  보고 있었고, 그대로 돌리면 예산이 엉뚱한 데로 간다.

  | | 고치기 전 | **실측(고친 뒤)** |
  |---|---|---|
  | 엔티티 빈틈 | 11,022 / 11,435 | **130 / 543** |
  | 페리코프 빈틈 | 3,061 / 3,061 | **1,963 / 3,061** |

  ⓐ **기계 낱말(`subtype='LEX'`) 10,892개가 대상에 섞여 있었다** — LIVE
     엔티티의 95%다. §181차에 스트롱 사전을 통째로 엔티티로 올린 것이고,
     §194차가 「**분류 단추의 일은 훑어보기**」라는 잣대로 **엔티티 수집기
     목록에서 뺐는데 이 파일은 빠졌다.** 「아마르(말하다)」로 유튜브를 찾으면
     쓸모없는 결과가 나오고 쿼터만 탄다.
  ⓑ **페리코프 커버가 0으로 굳어 있었다** — `MEDI_PERI` 를 셌는데 §193차에
     연결이 **구간(`MEDI_VERS`)**으로 바뀌어 **그 유형이 0건**이다. 이미 덮인
     1,098단락을 「빈틈」이라 부르고 다시 검색하러 갔다.
     ★ §194차가 수집 탭에서, 이번에 링크 점검에서 **같은 병**을 고쳤다 —
       「연결 구조를 바꾸면 그것을 **읽는 곳 전부**를 함께 봐야 한다」.
"""

import appdb
import media_link as ML

#: 기계 낱말(스트롱 사전에서 통째로 올린 것). 훑어보는 목록에서는 뺀다.
LEX_SUBTYPE = 'LEX'


def _link_counts(conn, scope, media_lang=None):
    """{target_id(int): (total, active)} — 통합 표 JOIN sys_media_asset GROUP BY target_id.

    ★★ `media_lang` 을 주면 **그 언어 영상만** 센다(2026-09-06 사용자 지시
      「다국어 모드가 편리하게 정리되어야 한다」).
      ⚠⚠ 그전에는 언어를 안 봤다 — 실측 정성 엔티티 543 중 **KO 영상 보유
        365 · EN 298 · 한 언어에만 있는 것 149**인데 화면은 「커버 413」 하나로
        말했다. **영어 영상만 있는 용어는 한국어 사용자에게 빈 화면**인데
        「커버됨」이라 세니 저밀도 집중수집이 영영 안 메운다.
      ⚠ `None` 이면 언어 무관(옛 동작) — 「전체」 보기가 필요하다.
    """
    out = {}
    ty = ML.lt(scope)
    if not ty:
        return out
    args = [ty]
    lang_clause = ''
    if media_lang and media_lang != '전체':
        lang_clause = ' AND UPPER(a.lang_code)=?'
        args.append(str(media_lang).upper())
    for key, total, active in conn.execute(
            "SELECT l.target_id, COUNT(DISTINCT l.clicked_id), "
            "COUNT(DISTINCT CASE WHEN a.is_active=1 THEN l.clicked_id END) "
            "FROM %s l JOIN sys_media_asset a ON a.media_id=l.clicked_id "
            "WHERE l.link_type=? AND COALESCE(l.record_status,'LIVE')='LIVE' "
            "AND COALESCE(a.record_status,'LIVE')='LIVE'%s GROUP BY l.target_id"
            % (ML.TBL, lang_clause), args):
        if key is None:
            continue
        out[int(key)] = (total or 0, active or 0)
    return out


def entity_rows(conn, lang='KO', etype=None, include_lex=False,
                media_lang=None):
    """LIVE 엔티티별 커버리지. → [{id,code,type,name,total,active}] (active 오름차순=빈틈 먼저).

    ⚠ **기계 낱말은 기본으로 뺀다**(§194차 잣대) — 실측 11,435 중 10,892 가
      그것이라, 안 빼면 목록의 95%가 「아마르(말하다)」류가 되고 빈틈 수가
      84배로 부풀어 예산이 통째로 그리로 간다.
    """
    counts = _link_counts(conn, 'ENTITY', media_lang)
    lang = (lang or 'KO').upper()
    q = ("SELECT em.entity_id, em.entity_code, em.entity_type, "
         "COALESCE(nk.contents, ne.contents, em.entity_code) "
         "FROM sys_entity_master em "
         "LEFT JOIN sys_text_asset nk ON nk.clicked_id=em.entity_id AND nk.text_type='ENTITY_NAME' AND UPPER(nk.lang_code)=? "
         "LEFT JOIN sys_text_asset ne ON ne.clicked_id=em.entity_id AND ne.text_type='ENTITY_NAME' AND ne.lang_code='EN' "
         "WHERE em.record_status='LIVE'")
    args = [lang]
    if not include_lex:
        q += (" AND COALESCE(json_extract(em.json_detail,'$.subtype'),'')<>?")
        args.append(LEX_SUBTYPE)
    if etype and etype != '전체':
        q += " AND em.entity_type=?"; args.append(etype)
    rows = []
    for eid, code, etyp, name in conn.execute(q, args):
        t, a = counts.get(eid, (0, 0))
        rows.append({'id': eid, 'code': code, 'type': etyp, 'name': name, 'total': t, 'active': a})
    rows.sort(key=lambda r: (r['active'], r['total'], r['name'] or ''))
    return rows


def book_short_map(conn, lang):
    """{book_code(int): short_name} (lang, EN 폴백). bible_index.bcode = book_names.book_code (정수)."""
    m = {}
    for bc, short in conn.execute(
            "SELECT book_code, short_name FROM book_names WHERE UPPER(lang_code)='EN'"):
        m[bc] = short
    if (lang or 'EN').upper() != 'EN':
        for bc, short in conn.execute(
                "SELECT book_code, short_name FROM book_names WHERE UPPER(lang_code)=?", ((lang or 'EN').upper(),)):
            if short:
                m[bc] = short
    return m


def _peri_counts(conn, media_lang=None):
    """{pericope_id: (total, active)} — **구간이 그 단락과 겹치면** 커버로 센다.

    ⚠⚠ 옛 `MEDI_PERI`(단락 정확 일치)는 **실측 0건**이다 — §193차에 미디어
      연결이 구절 **구간**(`MEDI_VERS` · `target_id`~`end_id`)으로 바뀌었다.
      그래서 겹침으로 세야 하고, 옛 유형도 함께 본다(다른 DB 에는 남아 있을
      수 있다 — 있으면 세고 없으면 0이라 해가 없다).
    ⚠ **같은 책 안일 것**을 함께 본다 — `verse_id` 는 연속이 아니라(§113차)
      범위 조건만 쓰면 아가서 한 편이 요한복음까지 덮는 일이 실제로 났다.
    ⚠ **SQL 범위 조인으로 하면 12.3초**다(실측 3,061단락 × 7,520링크). 탭을
      열 때마다 도는 화면이라 못 쓴다 ⇒ **책별로 갈라 파이썬에서 훑는다.**
      값이 같은지는 SQL 방식과 대조해 확인한다.
    """
    from bisect import bisect_right
    lang_clause, largs = '', []
    if media_lang and media_lang != '전체':
        lang_clause = ' AND UPPER(a.lang_code)=?'
        largs = [str(media_lang).upper()]
    # ① 구간 연결을 책별로 모은다
    by_book = {}
    for mid, s, e, bc, act in conn.execute(
            "SELECT l.clicked_id, l.target_id,"
            " COALESCE(l.end_id, l.target_id), bi.bcode, a.is_active"
            "  FROM %s l"
            "  JOIN bible_index bi ON bi.verse_id = l.target_id"
            "  JOIN sys_media_asset a ON a.media_id = l.clicked_id"
            "   AND COALESCE(a.record_status,'LIVE')='LIVE'"
            " WHERE l.link_type='MEDI_VERS'"
            "   AND COALESCE(l.record_status,'LIVE')='LIVE'%s"
            % (ML.TBL, lang_clause), largs):
        by_book.setdefault(bc, []).append((s, e, mid, act))
    starts = {}
    for bc, lst in by_book.items():
        lst.sort()
        starts[bc] = [x[0] for x in lst]

    # ② 옛 유형(단락 정확 일치) — 지금 0건이지만 있으면 함께 센다
    exact = {}
    for pid, mid, act in conn.execute(
            "SELECT l.target_id, l.clicked_id, a.is_active FROM %s l"
            "  JOIN sys_media_asset a ON a.media_id = l.clicked_id"
            "   AND COALESCE(a.record_status,'LIVE')='LIVE'"
            " WHERE l.link_type='MEDI_PERI'"
            "   AND COALESCE(l.record_status,'LIVE')='LIVE'%s"
            % (ML.TBL, lang_clause), largs):
        exact.setdefault(int(pid), []).append((mid, act))

    out = {}
    for pid, sv, ev, bc in conn.execute(
            "SELECT p.pericope_id, p.start_vid, p.end_vid, bi.bcode"
            "  FROM sys_pericope_asset p"
            "  JOIN bible_index bi ON bi.verse_id = p.start_vid"
            " WHERE p.record_status='LIVE'"):
        tot, act = set(), set()
        lst = by_book.get(bc)
        if lst:
            # 시작이 단락 끝보다 뒤인 것은 볼 필요가 없다
            for s, e, mid, a in lst[:bisect_right(starts[bc], ev)]:
                if e >= sv:
                    tot.add(mid)
                    if a == 1:
                        act.add(mid)
        for mid, a in exact.get(int(pid), ()):
            tot.add(mid)
            if a == 1:
                act.add(mid)
        if tot:
            out[int(pid)] = (len(tot), len(act))
    return out


def pericope_rows(conn, lang='KO', book=None, peri_type='BODY',
                  media_lang=None):
    """LIVE 페리코프별 커버리지. → [{id,code,ref,bcode,total,active}] (active 오름차순)."""
    counts = _peri_counts(conn, media_lang)
    bmap = book_short_map(conn, lang)
    q = ("SELECT p.pericope_id, p.peri_code, p.start_vid, p.end_vid, "
         "bs.bcode, bs.chapter, bs.verse, be.chapter, be.verse "
         "FROM sys_pericope_asset p "
         "LEFT JOIN bible_index bs ON bs.verse_id=p.start_vid "
         "LEFT JOIN bible_index be ON be.verse_id=p.end_vid "
         "WHERE p.record_status='LIVE'")
    args = []
    if peri_type and peri_type != '전체':
        q += " AND p.peri_type=?"; args.append(peri_type)
    if book and book != '전체':
        q += " AND bs.bcode=?"; args.append(book)
    rows = []
    for pid, code, svid, evid, bc, sch, svs, ech, evs in conn.execute(q, args):
        short = bmap.get(bc, bc or '?')
        if sch is None:
            ref = code
        elif ech == sch:
            ref = f"{short} {sch}:{svs}" + (f"-{evs}" if evs and evs != svs else "")
        else:
            ref = f"{short} {sch}:{svs}-{ech}:{evs}"
        t, a = counts.get(pid, (0, 0))
        rows.append({'id': pid, 'code': code, 'ref': ref, 'bcode': bc, 'total': t, 'active': a})
    rows.sort(key=lambda r: (r['active'], r['total'], r['code'] or ''))
    return rows


def summary(rows, threshold=1):
    """(전체, 커버=active>=threshold, 빈틈=active<threshold)."""
    total = len(rows)
    covered = sum(1 for r in rows if r['active'] >= threshold)
    return total, covered, total - covered


def gaps(rows, threshold=1):
    return [r for r in rows if r['active'] < threshold]


def books_present(conn, peri_type='BODY'):
    """페리코프가 존재하는 bcode 목록(정렬)."""
    q = ("SELECT DISTINCT bs.bcode FROM sys_pericope_asset p "
         "LEFT JOIN bible_index bs ON bs.verse_id=p.start_vid WHERE p.record_status='LIVE'")
    args = []
    if peri_type and peri_type != '전체':
        q += " AND p.peri_type=?"; args.append(peri_type)
    return [r[0] for r in conn.execute(q + " AND bs.bcode IS NOT NULL ORDER BY bs.bcode", args)]
