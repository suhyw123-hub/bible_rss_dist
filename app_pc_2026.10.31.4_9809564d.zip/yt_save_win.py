"""유튜브·웹 글 간편 저장 — 알림 창 (2026-10-09 · docs/1.txt 59-3 · 웹 글 2026-10-11).

★ 2026-10-11 — 확장 프로그램·북마크로 **유튜브가 아닌 쪽**(기사·블로그·설교 원고 …)도 받는다.
  그때는 「웹 글」 한 갈래로 제목·주소만 「내 자료」(연구/설교노트)에 담고, 구절·용어는 사람이
  이 창에서 고른 것만 건다(사용자 결정 — 자동 추천·갈래 나누기 없음 · My Edit 대신 이 작은 창).

링크 복사·북마크 단추로 들어온 주소를 화면 오른쪽 아래 작은 창으로 묻는다.
  [저장]            = 내 영상으로만 담는다(받은 영상 목록에 남는다)
  [연결하며 저장 ▾] = 제목에서 읽은 구절·용어를 체크로 골라 함께 건다
단추는 맨 위(§0) · 색은 테마 역할 · 글꼴은 표준 글꼴에서 굵기만.
엔진은 `yt_intake` 한 곳 — 이 창은 고르는 자리다.

트레이(앱이 꺼져 있을 때)는 이 파일을 따로 띄운다:
  python yt_save_win.py --url <주소> [--title <제목>]
"""
import os
import queue
import sys
import threading
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import appdb      # noqa: E402
import yt_intake as YT  # noqa: E402

try:
    import i18n
    _t = i18n.t
except Exception:          # pragma: no cover
    def _t(k, d=''):
        return d

try:
    import ui_theme
except Exception:          # pragma: no cover
    ui_theme = None


def _C(role, fb):
    try:
        v = ui_theme.C(role) if ui_theme else ''
        return v or fb
    except Exception:
        return fb


_CUR = [None]          # 한 번에 하나만


def offer(master, db_path, url, title='', lang='KO', on_saved=None, uid=None):
    """창을 띄운다 — 이미 떠 있으면 그것을 닫고 새로 연다(가장 최근 복사가 이긴다)."""
    old = _CUR[0]
    if old is not None:
        try:
            if old.url == ((YT.parse(url) or (None, None))[1] or YT.parse_web(url) or url) and uid is None:
                old.lift()
                return old
            old.close()
        except Exception:
            pass
    w = SaveToast(master, db_path, url, title, lang, on_saved, uid)
    _CUR[0] = w
    return w


def _fetch(q, db_path, url, title, lang):
    """일꾼 — 제목(oEmbed)과 추천을 구해 큐에 넣는다. 창 객체는 모른다."""
    d = YT.oembed(url) if not title else {}
    q.put(('meta', d))
    try:
        conn = appdb.connect(db_path)
        try:
            q.put(('sug', YT.suggest(conn, title or d.get('title') or '', lang)))
        finally:
            conn.close()
    except Exception as e:
        q.put(('sug', {'verses': [], 'terms': []}))
        print('[yt_save_win] %s' % e)


class SaveToast(tk.Toplevel):
    LIFE_MS = 20000     # 손대지 않으면 20초 뒤 닫힌다

    def __init__(self, master, db_path, url, title='', lang='KO', on_saved=None, uid=None):
        super().__init__(master)
        self.db_path = db_path
        p = YT.parse(url)
        self.web = p is None and bool(YT.parse_web(url))      # 유튜브가 아닌 쪽 = 웹 글
        self.url = p[1] if p else (YT.parse_web(url) or url)
        self.lang = (lang or 'KO').upper()
        self.on_saved = on_saved
        self.uid = uid
        self._touched = uid is not None
        self._q = queue.Queue()
        self._vchk, self._tchk = [], []
        self._sug_done = False
        self.title_txt = title or ''
        self.author = ''
        self.withdraw()
        self.overrideredirect(True)
        try:
            self.attributes('-topmost', True)
        except Exception:
            pass
        self._build()
        try:
            if ui_theme:
                ui_theme.adopt(self)
        except Exception:
            pass
        self._place()
        self.deiconify()
        self.bind('<Enter>', lambda e: self._touch())
        self.after(self.LIFE_MS, self._expire)
        if uid is not None:
            self._load_existing()
        # ⚠ 스레드가 **창을 붙들지 않게** 값만 넘긴다 — 붙들면 창이 닫힌 뒤 그 스레드에서
        #   창이 정리되며 Tk 변수가 엉뚱한 스레드에서 지워진다(시험이 잡았다).
        if self.web:
            # 웹 글 — 제목은 브라우저가 준 것 · 추천을 구하지 않는다(사람이 고른다)
            self._sug_done = True
            self._author_lbl.config(text=YT.site_name(self.url))
            self._title_lbl.config(text=self.title_txt or self.url)
        else:
            threading.Thread(target=_fetch, args=(self._q, self.db_path, self.url,
                                                  self.title_txt, self.lang), daemon=True).start()
        self.after(150, self._pump)

    # ── 짓기 ───────────────────────────────────────────────────────
    def _build(self):
        bd = tk.Frame(self, bd=1, relief='solid', highlightthickness=1,
                      highlightbackground=_C('accent', '#2E86C1'))
        bd.pack(fill='both', expand=True)
        self._body = bd
        top = tk.Frame(bd)
        top.pack(fill='x', padx=8, pady=(6, 2))
        self._btn_save = tk.Button(top, text=_t('YTS_SAVE', '저장'), command=self._save,
                                   bd=1, relief='raised', padx=8)
        self._btn_save.pack(side='left')
        self._btn_more = tk.Button(top, text=_t('YTS_LINK', '연결하며 저장 ▾'),
                                   command=self._toggle, bd=1, relief='raised', padx=8)
        self._btn_more.pack(side='left', padx=(6, 0))
        tk.Button(top, text='✕', command=self.close, bd=0, relief='flat',
                  cursor='hand2').pack(side='right')
        off = tk.Label(top, text=_t('YTS_OFF', '이렇게 묻지 않기'), cursor='hand2',
                       fg=_C('fg_dim', '#7F8C8D'))
        # ★ 2026-10-12 사용자 — 주소 복사는 늘 묻는다 · 「묻지 않기」 글은 안 놓는다(옛 자리만 남김)
        off.bind('<Button-1>', lambda e: self._turn_off())

        f = tkfont.nametofont('TkDefaultFont').copy()
        f.configure(weight='bold')
        self._bold = f
        self._head = tk.Label(bd, text=(_t('YTS_ASK_WEB', '이 웹 글을 하가에 저장할까요? (연구/설교노트 ▸ 내 자료)')
                                        if self.web else
                                        _t('YTS_ASK', '방금 복사한 유튜브 영상을 하가에 저장할까요?')),
                              anchor='w', fg=_C('fg_dim', '#7F8C8D'))
        self._head.pack(fill='x', padx=10)
        self._title_lbl = tk.Label(bd, text=self.title_txt or _t('YTS_LOADING', '제목을 불러오는 중…'),
                                   anchor='w', justify='left', wraplength=340, font=f)
        self._title_lbl.pack(fill='x', padx=10, pady=(2, 0))
        self._author_lbl = tk.Label(bd, text='', anchor='w', fg=_C('fg_dim', '#7F8C8D'))
        self._author_lbl.pack(fill='x', padx=10)
        self._status = tk.Label(bd, text='', anchor='w', fg=_C('success', '#1E8449'))
        self._status.pack(fill='x', padx=10, pady=(0, 6))

        # 펼치는 칸
        self._more = tk.Frame(bd)
        kr = tk.Frame(self._more)
        if not self.web:                     # 웹 글은 갈래를 묻지 않는다(사용자 결정)
            kr.pack(fill='x', padx=10, pady=(2, 2))
        tk.Label(kr, text=_t('YTS_KIND', '갈래')).pack(side='left')
        self._kind = tk.StringVar(value=YT.guess_type(self.title_txt))
        for code, ko in (('SERMON', '설교'), ('WORSHIP', '찬양'), ('STUDY', '성경공부')):
            tk.Radiobutton(kr, text=_t('YTS_K_' + code, ko), value=code,
                           variable=self._kind).pack(side='left', padx=(6, 0))
        tk.Label(self._more, text=_t('YTS_VERSES', '구절'), anchor='w', font=f).pack(fill='x', padx=10)
        self._vbox = tk.Frame(self._more)
        self._vbox.pack(fill='x', padx=18)
        vr = tk.Frame(self._more)
        vr.pack(fill='x', padx=18, pady=(0, 4))
        self._vent = tk.Entry(vr, width=18)
        self._vent.pack(side='left')
        self._vent.bind('<Return>', lambda e: self._add_verse())
        tk.Button(vr, text=_t('YTS_ADD_V', '구절 더하기'), command=self._add_verse,
                  bd=1, relief='raised', padx=4).pack(side='left', padx=(4, 0))
        tk.Label(self._more, text=_t('YTS_TERMS', '주요용어'), anchor='w', font=f).pack(fill='x', padx=10)
        self._tbox = tk.Frame(self._more)
        self._tbox.pack(fill='x', padx=18)
        tr = tk.Frame(self._more)
        tr.pack(fill='x', padx=18, pady=(0, 8))
        self._tent = tk.Entry(tr, width=18)
        self._tent.pack(side='left')
        self._tent.bind('<Return>', lambda e: self._add_term())
        tk.Button(tr, text=_t('YTS_FIND_T', '용어 찾기'), command=self._add_term,
                  bd=1, relief='raised', padx=4).pack(side='left', padx=(4, 0))

    def _place(self):
        self.update_idletasks()
        w = max(self.winfo_reqwidth(), 380)
        h = self.winfo_reqheight()
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        top = sh - h - 70          # 작업표시줄 위
        try:
            import ctypes
            from ctypes import wintypes
            r = wintypes.RECT()
            if ctypes.windll.user32.SystemParametersInfoW(0x30, 0, ctypes.byref(r), 0):
                sw, top = r.right, r.bottom - h - 12
        except Exception:
            pass
        self.geometry('%dx%d+%d+%d' % (w, h, max(0, sw - w - 16), max(0, top)))

    # ── 움직임 ─────────────────────────────────────────────────────
    def _touch(self):
        self._touched = True

    def _expire(self):
        if not self._touched:
            self.close()

    def close(self):
        if _CUR[0] is self:
            _CUR[0] = None
        try:
            self.destroy()
        except Exception:
            pass
        # ⚠ Tk 변수는 **주 스레드에서** 놓는다 — 남겨 두면 다른 스레드(북마크 받는 곳)의
        #   쓰레기 수거가 정리하다 「main thread is not in main loop」 가 난다(시험이 잡았다).
        self._vchk, self._tchk, self._kind = [], [], None

    def _turn_off(self):
        YT.cfg_set(YT.CFG_RETURN, False, self.db_path)
        self._status.config(text=_t('YTS_OFF_DONE', '이제 묻지 않습니다 — 설정 ▸ 유튜브 간편 저장에서 다시 켭니다.'),
                            fg=_C('fg_dim', '#7F8C8D'))
        self._touched = False
        self.after(2500, self.close)

    def _pump(self):
        try:
            while True:
                k, d = self._q.get_nowait()
                if k == 'meta':
                    if d.get('title') and not self.title_txt:
                        self.title_txt = d['title']
                        self._kind.set(YT.guess_type(self.title_txt))
                    self.author = d.get('author') or ''
                    self._title_lbl.config(text=self.title_txt or self.url)
                    self._author_lbl.config(text=self.author)
                elif k == 'sug':
                    for s, e, nm in d.get('verses') or ():
                        self._add_vchk(s, e, nm, on=True)
                    for eid, nm in d.get('terms') or ():
                        self._add_tchk(eid, nm, on=True)
                    self._sug_done = True
                    n = len(self._vchk) + len(self._tchk)
                    if n and not self._more.winfo_ismapped():
                        self._btn_more.config(text=_t('YTS_LINK_N', '연결하며 저장 ▾ (추천 %d)') % n)
                self._replace()
        except queue.Empty:
            pass
        except Exception as e:
            print('[yt_save_win pump] %s' % e)
        if self.winfo_exists():
            self.after(150, self._pump)

    def _replace(self):
        if self.winfo_ismapped():
            self._place()

    def _toggle(self):
        self._touch()
        if self._more.winfo_ismapped():
            self._more.pack_forget()
            self._btn_more.config(text=_t('YTS_LINK', '연결하며 저장 ▾'))
        else:
            self._more.pack(fill='x', before=self._status)
            self._btn_more.config(text=_t('YTS_LINK_CLOSE', '연결 접기 ▴'))
        self._place()

    def _add_vchk(self, s, e, name, on=True):
        for v, ss, ee, _cb in self._vchk:
            if (ss, ee) == (s, e):
                v.set(True)
                return
        v = tk.BooleanVar(value=on)
        cb = tk.Checkbutton(self._vbox, text=name, variable=v, anchor='w')
        cb.pack(fill='x')
        self._vchk.append((v, s, e, cb))

    def _add_tchk(self, eid, name, on=True):
        for v, ee, _cb in self._tchk:
            if ee == eid:
                v.set(True)
                return
        v = tk.BooleanVar(value=on)
        cb = tk.Checkbutton(self._tbox, text=name, variable=v, anchor='w')
        cb.pack(fill='x')
        self._tchk.append((v, eid, cb))

    def _add_verse(self):
        self._touch()
        txt = self._vent.get().strip()
        if not txt:
            return
        try:
            import scripture_ref
            conn = appdb.connect(self.db_path)
            try:
                hits = scripture_ref.find(conn, txt, self.lang)
                for s, e, _m, _k in hits:
                    self._add_vchk(s, e, YT.verse_name(conn, s, e, self.lang))
            finally:
                conn.close()
        except Exception as ex:
            hits = []
            print('[yt_save_win verse] %s' % ex)
        if hits:
            self._vent.delete(0, 'end')
            self._status.config(text='', fg=_C('success', '#1E8449'))
        else:
            self._status.config(text=_t('YTS_NO_VERSE', '구절을 읽지 못했습니다 — 예: 롬 8:28'),
                                fg=_C('warning', '#B9770E'))
        self._place()

    def _add_term(self):
        self._touch()
        q = self._tent.get().strip()
        if not q:
            return
        conn = appdb.connect(self.db_path)
        try:
            rows = conn.execute(
                "SELECT t.clicked_id, t.contents FROM sys_text_asset t JOIN sys_entity_master m"
                " ON m.entity_id=t.clicked_id AND COALESCE(m.record_status,'LIVE')='LIVE'"
                " WHERE t.text_type='ENTITY_NAME' AND UPPER(t.lang_code)=? AND t.contents LIKE ?"
                " ORDER BY LENGTH(t.contents) LIMIT 5", (self.lang, '%' + q + '%')).fetchall()
        finally:
            conn.close()
        for eid, nm in rows:
            self._add_tchk(eid, nm, on=(len(rows) == 1))
        if rows:
            self._tent.delete(0, 'end')
            self._status.config(text='')
        else:
            self._status.config(text=_t('YTS_NO_TERM', '그런 용어가 없습니다'),
                                fg=_C('warning', '#B9770E'))
        self._place()

    def _load_existing(self):
        """받은 영상에서 다시 열었다 — 걸린 것을 체크된 채로 보인다."""
        conn = appdb.connect(self.db_path)
        try:
            lk = YT.links_of(conn, self.uid)
            for s, e in lk['verses']:
                self._add_vchk(s, e, YT.verse_name(conn, s, e, self.lang))
            for eid in lk['terms']:
                self._add_tchk(eid, YT.entity_name(conn, eid, self.lang))
            r = conn.execute("SELECT title, COALESCE(category,'STUDY') FROM userdb.user_media_asset"
                             ' WHERE user_media_id=?', (int(self.uid),)).fetchone()
            if r:
                self.title_txt = r[0] or self.title_txt
                self._title_lbl.config(text=self.title_txt)
                if r[1] in YT.MEDIA_TYPES:
                    self._kind.set(r[1])
        finally:
            conn.close()
        self._head.config(text=_t('YTS_EDIT', '연결을 고칩니다'))
        self._toggle()

    def _save(self):
        self._touch()
        expanded = self._more.winfo_ismapped()
        vs = [(s, e) for v, s, e, _c in self._vchk if v.get()] if expanded else []
        ts = [eid for v, eid, _c in self._tchk if v.get()] if expanded else []
        conn = appdb.connect(self.db_path)
        try:
            if self.uid is not None:
                # 다시 연 창 — 체크를 푼 연결은 숨긴다(지우지 않는다)
                for v, s, e, _c in self._vchk:
                    if not v.get():
                        conn.execute(
                            "UPDATE userdb.user_link_asset SET record_status='HIDE'"
                            " WHERE clicked_id=? AND link_type IN ('UMED_VERS','MEDI_VERS')"
                            ' AND target_id=? AND COALESCE(end_id,target_id)=?', (self.uid, s, e))
                for v, eid, _c in self._tchk:
                    if not v.get():
                        conn.execute(
                            "UPDATE userdb.user_link_asset SET record_status='HIDE'"
                            " WHERE clicked_id=? AND link_type='MEDI_ENTI' AND target_id=?",
                            (self.uid, eid))
                conn.execute('UPDATE userdb.user_media_asset SET category=? WHERE user_media_id=?',
                             (self._kind.get(), self.uid))
            if self.web:
                uid, n = YT.save_web(conn, self.url, self.title_txt, vs, ts, self.lang)
            else:
                uid, n = YT.save(conn, self.url, self.title_txt, self._kind.get(), vs, ts, self.lang)
        except Exception as e:
            self._status.config(text=str(e), fg=_C('danger', '#C0392B'))
            conn.close()
            return
        conn.close()
        msg = _t('YTS_SAVED', '저장했습니다')
        if vs or ts:
            msg += ' · ' + (_t('YTS_SAVED_N', '구절 %d · 용어 %d') % (len(vs), len(ts)))
        elif self.web:
            msg += ' · ' + _t('YTS_SAVED_WEB', '연구/설교노트 ▸ 내 자료에 있습니다')
        else:
            msg += ' · ' + _t('YTS_SAVED_INBOX', '받은 영상에서 나중에 연결합니다')
        self._status.config(text=msg, fg=_C('success', '#1E8449'))
        self._btn_save.config(state='disabled')
        if callable(self.on_saved):
            try:
                self.on_saved(uid)
            except Exception:
                pass
        self._touched = False
        self.after(1800, self.close)


def main(argv):
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--url', required=True)
    ap.add_argument('--title', default='')
    ap.add_argument('--lang', default='')
    a = ap.parse_args(argv)
    os.chdir(HERE)
    root = tk.Tk()
    root.withdraw()
    lang = a.lang
    if not lang:
        try:
            c = appdb.connect('bible_master.db')
            r = c.execute("SELECT config_val FROM user_config WHERE config_key='user_lang'").fetchone()
            c.close()
            lang = (r[0] if r and r[0] else 'KO')
        except Exception:
            lang = 'KO'
    try:
        i18n.load('bible_master.db', lang)
    except Exception:
        pass
    try:
        if ui_theme:
            ui_theme.load('bible_master.db')
            ui_theme.apply_ttk(root)
    except Exception:
        pass
    w = offer(root, 'bible_master.db', a.url, a.title, lang)
    w.bind('<Destroy>', lambda e: root.after(50, root.destroy) if e.widget is w else None)
    root.mainloop()


if __name__ == '__main__':
    main(sys.argv[1:])
