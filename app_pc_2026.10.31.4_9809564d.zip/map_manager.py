import json
import sqlite3
import appdb
import i18n
import tkinter as tk
from tkinter import ttk, messagebox
from p4_tree import BibleP4TreeCanvas

class MapManager(tk.Toplevel):
    # 🎯 [수리] 호출부 규격에 맞춰 lang, ver 인자를 정식으로 추가합니다.
    def __init__(self, parent, db_path, lang, ver, current_rid=None, is_manual=False):
        """[수리] 상단에 책/장/절 선택 기능을 추가하여 네비게이션이 가능하게 합니다."""
        super().__init__(parent)
        self.parent = parent
        self.db_path = db_path
        self.lang = lang
        self.ver = ver
        self.title("Manual Map Manager")
        self.geometry("1100x800")
        
        # 1. 상단 네비게이션부 (책/장/절 콤보박스)
        top_f = tk.Frame(self, pady=10, bg="#F2F4F4")
        top_f.pack(side="top", fill="x")
        
        # [책 선택]
        tk.Label(top_f, text=" 책:", bg="#F2F4F4").pack(side="left", padx=(10, 2))
        self.cb_book = ttk.Combobox(top_f, width=12, state="readonly")
        self.cb_book.pack(side="left", padx=2)
        self.cb_book.bind("<<ComboboxSelected>>", self._on_mgr_book_selected)

        # [장 선택]
        tk.Label(top_f, text=" 장:", bg="#F2F4F4").pack(side="left", padx=(5, 2))
        self.cb_chap = ttk.Combobox(top_f, width=5, state="readonly")
        self.cb_chap.pack(side="left", padx=2)
        self.cb_chap.bind("<<ComboboxSelected>>", self._on_mgr_chap_selected)

        # [절 선택]
        tk.Label(top_f, text=" 절:", bg="#F2F4F4").pack(side="left", padx=(5, 2))
        self.cb_vers = ttk.Combobox(top_f, width=5, state="readonly")
        self.cb_vers.pack(side="left", padx=2)
        self.cb_vers.bind("<<ComboboxSelected>>", self._on_mgr_vers_selected)

        # [삭제 버튼]
        btn_del = tk.Button(top_f, text="이 구절의 모든 맵 삭제 (AUTO 포함)", fg="white", bg="#C0392B",
                            font=("Arial", 10, "bold"), command=self._delete_selected)
        btn_del.pack(side="right", padx=15)
        # [열기 버튼] — 목록의 보존본을 메인 캔버스에 띄운다 (2026-08-20 신설.
        #  자동 복원이 AUTO 전용이 되면서 보존본을 여는 길은 P4 콤보와 여기뿐)
        btn_open = tk.Button(top_f, text=i18n.t('UM_MAP_OPEN', '▶ 캔버스에 열기'),
                             fg="white", bg="#27AE60",
                             font=("Arial", 10, "bold"), command=self._open_selected)
        btn_open.pack(side="right", padx=2)

        # 🎯 [수리] 현재 연구 중인 구절의 RID를 기억할 변수
        self.target_rid = current_rid


        # 메인 레이아웃 (좌: 목록 / 우: 상세 및 프리뷰)
        pw = tk.PanedWindow(self, orient="horizontal", sashrelief=tk.RAISED, sashwidth=4)
        pw.pack(fill="both", expand=True, padx=10, pady=10)

        # 좌측: 수동저장 목록
        self.list_tree = ttk.Treeview(pw, columns=("Name", "Time"), show="headings")
        self.list_tree.heading("Name", text="맵 이름"); self.list_tree.heading("Time", text="저장 시각")
        self.list_tree.column("Name", width=150); self.list_tree.column("Time", width=150)
        pw.add(self.list_tree)

        # 우측: 상세 정보 프레임
        detail_f = tk.Frame(pw)
        pw.add(detail_f)
        
        # 상세 상단 (태그/설명)
        info_f = tk.LabelFrame(detail_f, text="Map Details", padx=10, pady=10)
        info_f.pack(fill="x", padx=5, pady=5)
        
        self.tag_lbl = tk.Label(info_f, text="Tags: ", fg="blue", anchor="w")
        self.tag_lbl.pack(fill="x")
        
        self.desc_view = tk.Text(info_f, height=4, bg="#F9F9F9", state="disabled")
        self.desc_view.pack(fill="x", pady=5)

        # 상세 하단 (프리뷰 캔버스)
        preview_label = tk.Label(detail_f, text="◈ Map Preview (Drag to Move) ◈", fg="#666")
        preview_label.pack()
        
        # 🎯 [수리] 읽기 전용 캔버스: BibleP4TreeCanvas 생성 (노드 클릭 바인딩 미실시)
        self.preview_canvas = BibleP4TreeCanvas(detail_f, self.db_path, self.lang, self.ver, 
                                               width=700, height=400, bg="#FFFFFF")
        self.preview_canvas.pack(fill="both", expand=True, padx=5, pady=5)

        # 이벤트 및 초기 로드
        self.list_tree.bind("<<TreeviewSelect>>", self._on_map_select)
        self._load_map_list(current_rid)
        # 초기 데이터 로드 (책 목록 및 현재 구절 자동 선택)
        self._init_combos(current_rid)

    def _load_map_list(self, rid):
        """해당 구절의 수동 저장 목록을 불러옵니다.

        ⚠ PIN(기준점 스냅샷)은 제외 — save_type 이 MANUAL 이라 그냥 두면
          여기 노출된다(칩이 관리하는 슬롯이다. 2026-08-20 실측으로 잡음)."""
        for item in self.list_tree.get_children(): self.list_tree.delete(item)
        if not rid: return
        with appdb.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                "SELECT map_name, updated_at FROM user_saved_maps "
                "WHERE root_id=? AND save_type='MANUAL' "
                "AND map_name NOT LIKE 'PIN\\_%' ESCAPE '\\' "
                "ORDER BY updated_at DESC", (rid,)).fetchall()
            for r in rows:
                self.list_tree.insert("", "end", values=(r['map_name'], r['updated_at']))

    def _open_selected(self):
        """선택한 보존본을 메인 캔버스에 띄우고 창을 닫는다 (2026-08-20)."""
        sel = self.list_tree.selection()
        if not sel:
            messagebox.showwarning("선택", "열어 볼 맵을 목록에서 먼저 선택하세요.", parent=self)
            return
        m_name = self.list_tree.item(sel[0])['values'][0]
        rid = self.target_rid
        if not rid:
            messagebox.showwarning("오류", "구절 정보가 없습니다.", parent=self)
            return
        try:
            self.parent._open_saved_map(int(rid), m_name)
            self.destroy()
        except Exception as e:
            print(f"[map open] {e}")

    def _on_map_select(self, event):
        """목록 선택 시 설명 로드 및 캔버스 프리뷰를 수행합니다."""
        sel = self.list_tree.selection()
        if not sel: return
        m_name = self.list_tree.item(sel[0])['values'][0]

        with appdb.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            # ⚠ root_id 를 함께 건다 — 이름만으로 찾으면 **다른 구절의 동명 맵**
            #   이 걸린다(단일 슬롯 시대에 이름은 자유라 겹칠 수 있다. 2026-08-20)
            row = conn.execute(
                "SELECT tag_list, description, full_structure FROM user_saved_maps "
                "WHERE root_id=? AND map_name=?",
                (self.target_rid, m_name)).fetchone()
            
            if row:
                self.tag_lbl.config(text=f"Tags: {row['tag_list']}")
                self.desc_view.config(state="normal"); self.desc_view.delete("1.0", tk.END)
                self.desc_view.insert("1.0", row['description'] if row['description'] else ""); self.desc_view.config(state="disabled")
                
                # 프리뷰 캔버스 갱신
                self.preview_canvas.clear_all()
                struct = json.loads(row['full_structure'])
                for vid, info in struct.items():
                    # 🎯 [핵심] 부모 앱의 메서드를 호출하여 노드의 실제 이름을 가져옵니다.
                    v_type, v_num = self.parent._split_logic_id(info['node_id'])
                    node_name = self.parent.get_asset_name(v_num, v_type)
                    
                    # 🎯 [수리] 이름을 인자로 전달하여 캔버스에 글자가 나타나게 합니다.
                    self.preview_canvas.add_enhanced_node(info.get('p_id'), vid, info['node_id'], 
                                                           node_name, "", info['x'], info['y'], v_type)
                self.preview_canvas.redraw_edges()

    def _delete_selected(self):
        """테스터기 1.py의 성공 로직을 그대로 집행하여 AUTO까지 물리적으로 소거합니다."""
        sel = self.list_tree.selection()
        if not sel: 
            messagebox.showwarning("선택", "삭제할 수동 맵을 목록에서 먼저 선택하세요."); return
        
        m_name = self.list_tree.item(sel[0])['values'][0]
        
        # 🎯 [수리] rid_var.get() 대신 네비게이션에서 선택된 target_rid를 사용합니다.
        rid = self.target_rid
        
        if not rid:
            messagebox.showwarning("오류", "삭제할 구절 정보가 없습니다."); return

        if messagebox.askyesno("박멸 확인", f"[{m_name}]과 해당 구절의 모든 자동저장을 삭제할까요?"):
            conn = appdb.connect(self.db_path)
            try:
                with conn:
                    # 🚨 테스터기 성공 공식: 명시적 Commit 보장
                    sql = "DELETE FROM user_saved_maps WHERE root_id=? AND (map_name=? OR save_type='AUTO')"
                    conn.execute(sql, (int(rid), m_name))
                
                messagebox.showinfo("완료", "DB에서 모든 흔적이 소멸되었습니다.")
                # 🎯 메인 앱(Tab 1) 상태 초기화
                self.parent.active_node_id = None 
                self.parent.p4_view.clear_all()
                self.destroy() 
            finally:
                conn.close()

    def _init_combos(self, current_rid):
        """[수리] 책 목록을 로드하고, 전달받은 current_rid가 있다면 자동으로 선택합니다."""
        self.cb_book['values'] = list(self.parent.book_map.keys())
        # (중략: current_rid를 바탕으로 책/장/절 역추적하여 set() 하는 로직)
        self._load_map_list(current_rid)

    def _on_mgr_book_selected(self, event):
        """책 선택 시 장 목록을 갱신합니다."""
        b_name = self.cb_book.get(); b_code = self.parent.book_map[b_name]
        with appdb.connect(self.db_path) as conn:
            chaps = conn.execute("SELECT DISTINCT chapter FROM bible_index WHERE bcode=? ORDER BY chapter", (b_code,)).fetchall()
            self.cb_chap['values'] = [c[0] for c in chaps]; self.cb_chap.set("")

    def _on_mgr_chap_selected(self, event):
        """장 선택 시 절 목록을 갱신합니다."""
        b_name = self.cb_book.get(); b_code = self.parent.book_map[b_name]
        chap = self.cb_chap.get()
        with appdb.connect(self.db_path) as conn:
            verses = conn.execute("SELECT verse, verse_id FROM bible_index WHERE bcode=? AND chapter=? ORDER BY verse", (b_code, chap)).fetchall()
            self.vers_map = {str(v[0]): v[1] for v in verses}
            self.cb_vers['values'] = list(self.vers_map.keys()); self.cb_vers.set("")

    def _on_mgr_vers_selected(self, event):
        """절 선택 시 해당 RID의 수동 맵 목록을 로드합니다."""
        self.target_rid = self.vers_map[self.cb_vers.get()]
        self._load_map_list(self.target_rid)


if __name__ == "__main__":
    # 이 부분은 map_manager.py를 단독으로 실행했을 때만 작동합니다.
    # 실제 운영은 user_main.py에서 이 클래스를 호출하여 사용하게 됩니다.
    root = tk.Tk()
    root.withdraw() # 메인 창 숨김
    print("MapManager 모듈이 준비되었습니다. user_main.py에서 호출하여 사용하세요.")
    root.mainloop()
