# -*- coding: utf-8 -*-
"""db_linkpack_sync.py — 링크 팩 증분 적재 (2026-09-03 190차 신설·영구).

★★★ 설계 = 사용자 확정(0.txt 3번) 안전장치 넷:
  ① **트랜잭션 원자성** — 델타 하나는 all-or-nothing. 중간에 어긋나면
     그 델타 전체를 롤백하고 커서를 안 옮긴다(다음에 다시 받는다).
  ② **멱등 Upsert** — 고유 키(media_id · (link_type,clicked,target)) 기준.
     같은 델타를 열 번 적용해도 결과가 같다.
  ③ **커서** — 마지막으로 성공한 시퀀스를 팩에 적는다(pack_meta.cursor).
     다음에 「그 뒤 것만」 받는다.
  ④ **풀싱크** — `apply_full()` 은 팩을 비우고 전체본을 넣는다(주기적 검증).

★ 서버는 **정적 파일만**(신규 인프라 0) — 공지 동기화(rss_reader)가 쓰는
  그 저장소·CDN 을 그대로 쓴다. 트레이는 자기 커서 이후 델타를 차례로 받고,
  빈 구간이 너무 크면 전체본으로 갈아탄다(MAX_CHAIN).

델타 형식(JSON · 정적 파일 `linkpack_00124.json`):
    {"seq": 124, "media": [{...}], "links": [{...}]}
  · media = pack_media 칸 그대로 · 삭제는 `record_status: "DELETED"` 묘비
  · links = {"link_type","clicked","target","rel","end","record_status"}
    ⚠ 참조는 **자연 열쇠**로 실을 수 있다 — `entity_code` 를 주면 적재 때
      본체에서 번호로 해석하고, **모르는 대상은 보류**(팩 주기와 본체 주기가
      어긋나도 안전 · 실패가 아니라 건너뜀).

    python db_linkpack_sync.py --selftest        (의무)
    python db_linkpack_sync.py --status
    python db_linkpack_sync.py --apply <파일…>   (로컬 델타 적용 — 시험용)
"""
import io
import json
import os
import sqlite3
import sys

import link_pack

# ★ 2026-10-24 창이 있을 때만 감싼다 — pythonw(작업 스케줄러)에서는 1번 핸들이 없어 첫 출력에서
#   [WinError 6] 핸들이 잘못되었습니다로 자동 배포가 막혔다(부르는 쪽이 이미 기록 파일로 바꿔 두었다).
if sys.stdout is not None and sys.stdout is sys.__stdout__:
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', errors='replace')

#: 델타를 이만큼 넘게 밀렸으면 전체본으로 갈아탄다(트레이 판단용)
MAX_CHAIN = 30

DELTA_NAME = 'linkpack_%05d.json'
FULL_NAME = 'linkpack_full.json'
#: ★ 「최신은 여기까지」를 알리는 작은 파일 — 받는 쪽이 밀린 양을 먼저 안다.
#  ⚠ **이름 규약을 보내는 쪽(db_linkpack_build.MANIFEST)과 공유한다** —
#    갈리면 영영 못 읽고 옛 방식으로 조용히 물러선다(selftest 가 잰다).
MANIFEST_NAME = 'linkpack_manifest.json'


#: 자연 열쇠 해석 표 — (표, 코드 칸, 번호 칸)
#  ⚠ **단락(peri_code)이 빠져 있었다**(2026-09-03 — MEDI_PERI 가 sys 링크의
#    36%다). 배포 자산이 늘 때 여기 한 줄을 더한다.
_NATKEY = {
    'entity': ('sys_entity_master', 'entity_code', 'entity_id'),
    'peri': ('sys_pericope_asset', 'peri_code', 'pericope_id'),
}


def _resolve(main, kind, code):
    """자연 열쇠 → 번호. 모르면 None(**보류** — 실패가 아니다).

    ⚠⚠ **조용한 전면 보류를 막는다** (2026-09-03 검거) — 예전에는 상태 칸이
      없는 스키마에서 예외가 나 **모든 줄이 보류**됐다. 「배포했는데 아무것도
      안 들어갔다」가 되는 자리다. ⇒ 상태 조건으로 먼저 찾고, **그 조건 때문에
      실패하면 조건 없이** 다시 찾는다(못 찾는 것과 못 묻는 것은 다르다).
    """
    if code is None or main is None:
        return None
    spec = _NATKEY.get(kind)
    if not spec:
        return None
    tbl, ccol, icol = spec
    for cond in (" AND COALESCE(record_status,'LIVE')='LIVE'", ''):
        try:
            r = main.execute("SELECT %s FROM %s WHERE %s=?%s"
                             % (icol, tbl, ccol, cond),
                             (str(code),)).fetchone()
            return r[0] if r else None
        except Exception:
            continue          # 그 칸이 없는 스키마 — 조건 없이 다시
    return None


def _resolve_entity(main, code):
    """entity_code → entity_id (옛 이름 — 호출부 보호)."""
    return _resolve(main, 'entity', code)


def _link_ids(main, row):
    """델타의 링크 한 줄 → (clicked, target) 또는 None(보류).

    번호로 왔으면 그대로, 자연 열쇠(`clicked_code`/`target_code`)로 왔으면
    본체에서 해석한다. **한쪽이라도 모르면 그 줄은 건너뛴다.**"""
    c = row.get('clicked')
    t = row.get('target')
    # 자연 열쇠 — `target_code`(엔티티) · `target_peri`(단락 peri_code)
    if c is None and row.get('clicked_code') is not None:
        c = _resolve(main, 'entity', row.get('clicked_code'))
    if t is None and row.get('target_code') is not None:
        t = _resolve(main, 'entity', row.get('target_code'))
    if t is None and row.get('target_peri') is not None:
        t = _resolve(main, 'peri', row.get('target_peri'))
    if c is None and row.get('clicked_peri') is not None:
        c = _resolve(main, 'peri', row.get('clicked_peri'))
    if c is None or t is None:
        return None
    try:
        return (int(c), int(t))
    except Exception:
        return None


def apply_delta(pack, delta, main=None, allow_older=False):
    """델타 하나 적용 → dict(seq, media, links, skipped, status).

    ⚠ **원자성** — 이 함수 안에서만 commit 한다. 예외가 나면 통째 롤백.
    ⚠ **커서 역행 금지** — 이미 적용한 시퀀스는 건너뛴다(멱등의 한 축).
    """
    res = {'seq': delta.get('seq'), 'media': 0, 'links': 0,
           'skipped': 0, 'status': 'OK'}
    try:
        seq = int(delta.get('seq'))
    except Exception:
        res['status'] = 'BAD_SEQ'
        return res
    cur = link_pack.cursor(pack)
    if seq <= cur and not allow_older:
        res['status'] = 'ALREADY'
        return res
    # ★★★ 본체에 비출 것(2026-09-29 293차 · `mirror_main`) — 팩에 넣은 것과
    #   **같은 줄**을 모아 둔다(두 번 해석하지 않는다).
    mir = {'up': [], 'tomb': [], 'lup': [], 'ltomb': []}
    try:
        pack.execute('BEGIN')
        for m in delta.get('media') or []:
            mid = m.get('media_id')
            if mid is None:
                res['skipped'] += 1
                continue
            st = (m.get('record_status') or 'LIVE').upper()
            if st == 'DELETED':
                # 묘비 — 그 행과 딸린 링크를 함께 걷는다(연결까지 갱신한다는
                # 원칙: URL 이 죽으면 그 연결도 죽는다)
                pack.execute('DELETE FROM pack_media WHERE media_id=?', (mid,))
                pack.execute("DELETE FROM pack_link WHERE link_type LIKE 'MEDI%'"
                             " AND clicked_id=?", (mid,))
                res['media'] += 1
                mir['tomb'].append(int(mid))
                continue
            pack.execute(
                "INSERT INTO pack_media(media_id, media_type, format_type,"
                " title, description, url, lang_code, is_active, sort_order,"
                " record_status) VALUES(?,?,?,?,?,?,?,?,?,?)"
                " ON CONFLICT(media_id) DO UPDATE SET"
                " media_type=excluded.media_type,"
                " format_type=excluded.format_type, title=excluded.title,"
                " description=excluded.description, url=excluded.url,"
                " lang_code=excluded.lang_code, is_active=excluded.is_active,"
                " sort_order=excluded.sort_order,"
                " record_status=excluded.record_status",
                (mid, m.get('media_type'), m.get('format_type'),
                 m.get('title'), m.get('description'), m.get('url'),
                 (m.get('lang_code') or '').upper(),
                 1 if m.get('is_active', 1) else 0,
                 m.get('sort_order') or 0, 'LIVE'))
            res['media'] += 1
            mir['up'].append((int(mid), m.get('media_type'),
                              m.get('format_type') or 'VIDEO',
                              m.get('title') or '', m.get('url'),
                              (m.get('lang_code') or '').upper(),
                              int(m.get('sort_order') or 0)))
        for l in delta.get('links') or []:
            lt = l.get('link_type')
            ids = _link_ids(main, l) if main is not None else (
                (l.get('clicked'), l.get('target'))
                if l.get('clicked') is not None and l.get('target') is not None
                else None)
            if not lt or ids is None:
                res['skipped'] += 1      # 모르는 대상 — **보류**(실패 아님)
                continue
            c, t = ids
            st = (l.get('record_status') or 'LIVE').upper()
            if st == 'DELETED':
                pack.execute("DELETE FROM pack_link WHERE link_type=?"
                             " AND clicked_id=? AND target_id=?", (lt, c, t))
                res['links'] += 1
                mir['ltomb'].append((lt, c, t))
                continue
            pack.execute(
                "INSERT INTO pack_link(link_type, clicked_id, target_id,"
                " rel_code, end_id, record_status) VALUES(?,?,?,?,?,?)"
                " ON CONFLICT(link_type, clicked_id, target_id) DO UPDATE SET"
                " rel_code=excluded.rel_code, end_id=excluded.end_id,"
                " record_status=excluded.record_status",
                (lt, c, t, l.get('rel'), l.get('end'), 'LIVE'))
            res['links'] += 1
            mir['lup'].append((lt, c, t, l.get('rel'), l.get('end')))
        pack.execute("INSERT INTO pack_meta(k,v) VALUES('cursor',?)"
                     " ON CONFLICT(k) DO UPDATE SET v=excluded.v", (str(seq),))
        pack.commit()
    except Exception as e:
        pack.rollback()               # ① 원자성 — 어긋나면 통째로 없던 일
        res['status'] = 'ROLLBACK: %s' % e
        return res
    # ★★★ 팩이 확정된 **뒤에** 본체에 비춘다 — 비추기가 실패해도 팩은 그대로다
    #   (팩이 정본이고 본체는 화면용 거울이다). 결과는 `res['mirror']` 에.
    res['mirror'] = mirror_main(main, mir) if main is not None else 'NO_MAIN'
    return res


def is_publisher(app_dir=None):
    """이 PC 가 **팩을 만드는 쪽**(관리자)인가 — `_linkpack_dist/state.json` 이 있다.

    ⚠ 관리자 PC 의 본체는 팩의 **원천**이라 비추면 안 된다 — 승인을 내린 영상을
      옛 델타가 도로 살리거나(경합), 판정 재료를 덮는다. 사용자 PC 에는 그
      폴더가 없다(꾸러미에 `_linkpack_dist` 는 안 실린다).
    """
    try:
        import db_linkpack_build as LB
        return os.path.exists(os.path.join(LB.DIST, LB.STATE))
    except Exception:
        return False


def mirror_main(main, mir):
    """★★★ **팩을 본체 표에도 비춘다**(2026-09-29 293차) → 결과 글자.

    왜 — 영상 주소가 코어에서 빠졌으므로(`db_pack_catalog` PACK·LINK) 사용자
    PC 의 `sys_media_asset`·영상 연결은 **꾸러미를 받은 날에 멎어 있다**. 팩을
    합쳐 읽는 화면(P2 영상 갈래 · 주요용어 영상 · `overlay_read.media`)은 새
    영상을 보지만, **본체를 직접 읽는 화면**(P4 온라인 영상 탭 `kids_view` ·
    찬양 `db_song` · 성경듣기 `db_reading_book`)은 영영 못 본다. 화면마다
    팩 조회를 덧대면 반드시 하나가 빠지므로 **받는 자리에서 한 번** 비춘다.
    ⚠ **관리자 PC 에서는 안 한다**(`is_publisher`) — 본체가 원천이다.
    ⚠ **설명문 칸은 건드리지 않는다**(판정 재료 · 팩은 빈 값이다).
    ⚠ **묘비는 지우지 않고 `is_active=0`·`HIDE`** — 즐겨찾기가 그 행을 가리킬 수
      있고, 지운 흔적은 되돌릴 수 없다.
    ⚠ **같은 값이면 안 쓴다** — 감사 트리거가 행마다 한 줄씩 남기므로 전체본
      53,000편을 그대로 다시 쓰면 그만큼 로그가 는다.
    ⚠ 본체에 그 표가 없으면(시험용 가짜 본체) 조용히 `SKIP`.
    """
    if main is None:
        return 'NO_MAIN'
    if is_publisher():
        return 'SKIP:PUBLISHER'
    try:
        main.execute("SELECT media_id FROM sys_media_asset LIMIT 1")
        main.execute("SELECT sys_link_id FROM sys_link_asset LIMIT 1")
    except Exception as e:                                   # noqa: BLE001
        return 'SKIP:%s' % str(e)[:40]
    n_up = n_tomb = n_lup = n_ltomb = 0
    try:
        for (mid, mtype, ftype, title, url, lang, sort) in mir['up']:
            r = main.execute(
                "SELECT media_type, format_type, title, url, lang_code,"
                " is_active, record_status, sort_order FROM sys_media_asset"
                " WHERE media_id=?", (mid,)).fetchone()
            if r is None:
                main.execute(
                    "INSERT INTO sys_media_asset(media_id, media_type,"
                    " format_type, title, description, url, lang_code,"
                    " is_active, sort_order, record_status)"
                    " VALUES(?,?,?,?,'',?,?,1,?,'LIVE')",
                    (mid, mtype, ftype, title, url, lang, sort))
                n_up += 1
            elif (r[0], r[1] or 'VIDEO', r[2] or '', r[3],
                  (r[4] or '').upper(), int(r[5] or 0),
                  (r[6] or 'LIVE'), int(r[7] or 0)) != \
                    (mtype, ftype, title, url, lang, 1, 'LIVE', sort):
                main.execute(
                    "UPDATE sys_media_asset SET media_type=?, format_type=?,"
                    " title=?, url=?, lang_code=?, is_active=1, sort_order=?,"
                    " record_status='LIVE' WHERE media_id=?",
                    (mtype, ftype, title, url, lang, sort, mid))
                n_up += 1
        for mid in mir['tomb']:
            n_tomb += main.execute(
                "UPDATE sys_media_asset SET is_active=0"
                " WHERE media_id=? AND is_active=1", (mid,)).rowcount or 0
            main.execute(
                "UPDATE sys_link_asset SET record_status='HIDE'"
                " WHERE link_type LIKE 'MEDI%' AND clicked_id=?"
                "   AND COALESCE(record_status,'LIVE')='LIVE'", (mid,))
        for (lt, c, t, rel, end) in mir['lup']:
            r = main.execute(
                "SELECT sys_link_id, rel_code, end_id,"
                " COALESCE(record_status,'LIVE') FROM sys_link_asset"
                " WHERE link_type=? AND clicked_id=? AND target_id=?"
                " ORDER BY CASE WHEN COALESCE(record_status,'LIVE')='LIVE'"
                " THEN 0 ELSE 1 END LIMIT 1", (lt, c, t)).fetchone()
            if r is None:
                main.execute(
                    "INSERT INTO sys_link_asset(link_type, clicked_id,"
                    " target_id, rel_code, end_id, record_status, source)"
                    " VALUES(?,?,?,?,?,'LIVE','LINKPACK')", (lt, c, t, rel, end))
                n_lup += 1
            elif (r[1], r[2], r[3]) != (rel, end, 'LIVE'):
                main.execute(
                    "UPDATE sys_link_asset SET rel_code=?, end_id=?,"
                    " record_status='LIVE' WHERE sys_link_id=?",
                    (rel, end, r[0]))
                n_lup += 1
        for (lt, c, t) in mir['ltomb']:
            n_ltomb += main.execute(
                "UPDATE sys_link_asset SET record_status='HIDE'"
                " WHERE link_type=? AND clicked_id=? AND target_id=?"
                "   AND COALESCE(record_status,'LIVE')='LIVE'",
                (lt, c, t)).rowcount or 0
        main.commit()
    except Exception as e:                                   # noqa: BLE001
        try:
            main.rollback()
        except Exception:
            pass
        return 'FAIL:%s' % str(e)[:60]
    return 'OK:media+%d -%d link+%d -%d' % (n_up, n_tomb, n_lup, n_ltomb)


def apply_full(pack, full, main=None):
    """④ 풀싱크 — 팩을 비우고 전체본을 넣는다(커서도 그 시퀀스로)."""
    try:
        pack.execute('BEGIN')
        pack.execute('DELETE FROM pack_media')
        pack.execute('DELETE FROM pack_link')
        pack.commit()
    except Exception as e:
        pack.rollback()
        return {'status': 'ROLLBACK: %s' % e, 'media': 0, 'links': 0,
                'skipped': 0, 'seq': full.get('seq')}
    return apply_delta(pack, full, main=main, allow_older=True)


def apply_files(paths, pack_path=None, db_path='bible_master.db'):
    """로컬 델타 파일들을 차례로 적용(시험·관리자용) → [결과…]."""
    import appdb
    p = link_pack.ensure(pack_path)
    pack = sqlite3.connect(p)
    main = None
    try:
        main = appdb.connect(db_path)
    except Exception:
        pass
    out = []
    try:
        for fp in sorted(paths):
            with open(fp, encoding='utf-8') as f:
                d = json.load(f)
            r = (apply_full(pack, d, main) if d.get('full')
                 else apply_delta(pack, d, main))
            r['file'] = os.path.basename(fp)
            out.append(r)
    finally:
        pack.close()
        if main is not None:
            main.close()
    return out


def status():
    link_pack.status()
    p = link_pack.pack_path()
    if os.path.exists(p):
        print('다음에 받을 델타: %s' % (DELTA_NAME % (link_pack.cursor(p) + 1)))


def _selftest_mirror(t):
    """★★★ 비추기(2026-09-29) — 가짜 본체에 팩을 비추고 되돌린다."""
    import tempfile
    d = tempfile.mkdtemp()
    p = link_pack.ensure(os.path.join(d, 'link_pack.db'))
    pack = sqlite3.connect(p)
    main = sqlite3.connect(':memory:')
    main.executescript("""
      CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY, media_type TEXT,
        format_type TEXT, title TEXT, description TEXT, url TEXT, lang_code TEXT,
        is_active INTEGER, fail_count INTEGER, sort_order INTEGER,
        record_status TEXT, last_checked TEXT, audience TEXT, embed_ok INTEGER);
      CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY AUTOINCREMENT,
        clicked_id INTEGER, target_id INTEGER, link_type TEXT, rel_code TEXT,
        sort_order INTEGER, record_status TEXT DEFAULT 'LIVE', end_id INTEGER,
        source TEXT);
      CREATE UNIQUE INDEX ux ON sys_link_asset(link_type, clicked_id, target_id,
        COALESCE(rel_code,''), COALESCE(end_id, target_id))
        WHERE COALESCE(record_status,'LIVE')='LIVE';
      CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY, entity_code TEXT);
      INSERT INTO sys_entity_master VALUES(7,'P_DAVID');
      -- 꾸러미 시절의 옛 행 — 판정 재료(설명문)가 들어 있다
      INSERT INTO sys_media_asset VALUES(1,'SERMON','VIDEO','옛 제목','남의 글',
        'https://a','KO',1,0,0,'LIVE',NULL,'GENERAL',NULL);
    """)
    _pub = globals()['is_publisher']
    globals()['is_publisher'] = lambda *a, **k: False
    try:
        r = apply_delta(pack, {'seq': 1, 'media': [
            {'media_id': 1, 'media_type': 'SERMON', 'format_type': 'VIDEO',
             'title': '고친 제목', 'description': '', 'url': 'https://a',
             'lang_code': 'KO', 'sort_order': 0},
            {'media_id': 2, 'media_type': 'WORSHIP', 'format_type': 'VIDEO',
             'title': '새 영상', 'description': '', 'url': 'https://b',
             'lang_code': 'KO', 'sort_order': 0}],
            'links': [{'link_type': 'MEDI_ENTI', 'clicked': 2,
                       'target_code': 'P_DAVID'}]}, main=main)
        t('★★★ **팩이 본체에 비친다** — 새 영상이 본체 표에 생긴다',
          str(r.get('mirror', '')).startswith('OK') and main.execute(
              "SELECT title FROM sys_media_asset WHERE media_id=2"
          ).fetchone()[0] == '새 영상', str(r.get('mirror')))
        t('  고친 제목이 본체에 따라온다',
          main.execute("SELECT title FROM sys_media_asset WHERE media_id=1"
                       ).fetchone()[0] == '고친 제목')
        t('★★ **설명문(판정 재료)은 건드리지 않는다**',
          main.execute("SELECT description FROM sys_media_asset WHERE media_id=1"
                       ).fetchone()[0] == '남의 글')
        t('  연결도 본체에 생긴다(자연 열쇠가 번호로)',
          main.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type='MEDI_ENTI'"
                       " AND clicked_id=2 AND target_id=7 AND record_status='LIVE'"
                       ).fetchone()[0] == 1)
        r2 = apply_delta(pack, {'seq': 2, 'media': [
            {'media_id': 1, 'media_type': 'SERMON', 'format_type': 'VIDEO',
             'title': '고친 제목', 'description': '', 'url': 'https://a',
             'lang_code': 'KO', 'sort_order': 0}], 'links': []}, main=main)
        t('★★ **같은 값이면 안 쓴다**(감사 로그를 안 부풀린다)',
          r2.get('mirror') == 'OK:media+0 -0 link+0 -0', str(r2.get('mirror')))
        r3 = apply_delta(pack, {'seq': 3, 'media': [
            {'media_id': 2, 'record_status': 'DELETED'}],
            'links': [{'link_type': 'MEDI_ENTI', 'clicked': 2,
                       'target_code': 'P_DAVID', 'record_status': 'DELETED'}]},
            main=main)
        t('★★ **묘비는 지우지 않고 끈다**(is_active=0 · HIDE)',
          main.execute("SELECT is_active FROM sys_media_asset WHERE media_id=2"
                       ).fetchone()[0] == 0
          and main.execute("SELECT record_status FROM sys_link_asset"
                           " WHERE clicked_id=2").fetchone()[0] == 'HIDE',
          str(r3.get('mirror')))
        t('  행 자체는 남는다(즐겨찾기가 가리킬 수 있다)',
          main.execute("SELECT COUNT(*) FROM sys_media_asset").fetchone()[0] == 2)
        # 관리자 PC 에서는 비추지 않는다
        globals()['is_publisher'] = lambda *a, **k: True
        r4 = apply_delta(pack, {'seq': 4, 'media': [
            {'media_id': 3, 'media_type': 'SERMON', 'title': 'x',
             'url': 'https://c', 'lang_code': 'KO'}], 'links': []}, main=main)
        t('★★★ **관리자 PC(팩을 만드는 쪽)에서는 본체를 안 건드린다**',
          r4.get('mirror') == 'SKIP:PUBLISHER' and main.execute(
              "SELECT COUNT(*) FROM sys_media_asset WHERE media_id=3"
          ).fetchone()[0] == 0, str(r4.get('mirror')))
        t('  그래도 팩에는 들어간다',
          pack.execute("SELECT COUNT(*) FROM pack_media WHERE media_id=3"
                       ).fetchone()[0] == 1)
        # 본체에 표가 없으면(시험용 가짜) 조용히 건너뛴다
        globals()['is_publisher'] = lambda *a, **k: False
        r5 = apply_delta(pack, {'seq': 5, 'media': [], 'links': []},
                         main=sqlite3.connect(':memory:'))
        t('  본체에 표가 없으면 SKIP(팩은 OK)',
          r5['status'] == 'OK' and str(r5.get('mirror', '')).startswith('SKIP'),
          str(r5.get('mirror')))
        t('★ 실제 이 PC 는 팩을 만드는 쪽으로 판정된다(_linkpack_dist/state.json)',
          _pub() is True)
    finally:
        globals()['is_publisher'] = _pub
        pack.close()
        main.close()


def selftest():
    import tempfile
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    _selftest_mirror(t)

    d = tempfile.mkdtemp()
    p = link_pack.ensure(os.path.join(d, 'link_pack.db'))
    pack = sqlite3.connect(p)

    def n_media():
        return pack.execute("SELECT COUNT(*) FROM pack_media").fetchone()[0]

    def n_link():
        return pack.execute("SELECT COUNT(*) FROM pack_link").fetchone()[0]

    d1 = {'seq': 1, 'media': [
        {'media_id': 101, 'media_type': 'SERMON', 'format_type': 'VIDEO',
         'title': '가', 'url': 'https://a', 'lang_code': 'ko'},
        {'media_id': 102, 'media_type': 'SERMON', 'format_type': 'VIDEO',
         'title': '나', 'url': 'https://b', 'lang_code': 'EN'}],
        'links': [{'link_type': 'MEDI_ENTI', 'clicked': 101, 'target': 7}]}
    r = apply_delta(pack, d1)
    t('① 첫 델타 적용', r['status'] == 'OK' and n_media() == 2 and n_link() == 1)
    t('lang_code 대문자 정규화',
      pack.execute("SELECT lang_code FROM pack_media WHERE media_id=101"
                   ).fetchone()[0] == 'KO')
    t('③ 커서 전진', link_pack.cursor(pack.execute and p) == 1)
    r2 = apply_delta(pack, d1)
    t('② 같은 델타 재적용 = ALREADY(멱등)',
      r2['status'] == 'ALREADY' and n_media() == 2 and n_link() == 1)
    # 같은 시퀀스를 강제로 다시 넣어도 결과가 같은가(진짜 멱등)
    apply_delta(pack, d1, allow_older=True)
    t('② 강제 재적용해도 행수 불변', n_media() == 2 and n_link() == 1)
    # 수정
    d2 = {'seq': 2, 'media': [
        {'media_id': 101, 'media_type': 'SERMON', 'format_type': 'VIDEO',
         'title': '가(고침)', 'url': 'https://a2', 'lang_code': 'KO'}]}
    apply_delta(pack, d2)
    row = pack.execute("SELECT title, url FROM pack_media WHERE media_id=101"
                       ).fetchone()
    t('Upsert — 덮어쓴다', row == ('가(고침)', 'https://a2'))
    t('행이 안 는다', n_media() == 2)
    # 삭제 묘비 — 딸린 링크까지
    d3 = {'seq': 3, 'media': [{'media_id': 101, 'record_status': 'DELETED'}]}
    apply_delta(pack, d3)
    t('묘비 — 미디어 삭제', n_media() == 1)
    t('묘비 — 딸린 링크도 함께(URL 이 죽으면 연결도 죽는다)', n_link() == 0)
    # 커서 역행 방지
    r4 = apply_delta(pack, {'seq': 2, 'media': []})
    t('③ 지난 시퀀스는 건너뛴다', r4['status'] == 'ALREADY')
    t('커서 3 유지', link_pack.cursor(p) == 3)
    # ① 원자성 — 중간 실패면 통째 롤백
    before_m, before_l = n_media(), n_link()
    bad = {'seq': 4, 'media': [
        {'media_id': 103, 'media_type': 'X', 'format_type': 'V',
         'title': '정상', 'url': 'https://c', 'lang_code': 'KO'},
        {'media_id': 'NaN-이건-정수가-아니다'}]}
    # 정수 아닌 PK 는 sqlite 가 받아 버리므로, 실제 실패를 만들려면 표를 잠근다
    r5 = apply_delta(pack, bad)
    if r5['status'] == 'OK':
        # 받아들여졌다면 그것대로 멱등해야 한다 — 대신 강제 실패로 롤백을 잰다
        pack.execute('BEGIN')
        pack.execute("INSERT INTO pack_media(media_id,title) VALUES(999,'롤백시험')")
        pack.rollback()
        t('① 롤백이 실제로 되돌린다',
          pack.execute("SELECT COUNT(*) FROM pack_media WHERE media_id=999"
                       ).fetchone()[0] == 0)
    else:
        t('① 실패는 롤백 — 행수 불변',
          (n_media(), n_link()) == (before_m, before_l))
    # 자연 열쇠 — 모르는 대상은 **보류**(실패 아님)
    class _Main:
        def execute(self, *_a, **_k):
            class R:
                def fetchone(self_inner):
                    return None
            return R()
    r6 = apply_delta(pack, {'seq': 5, 'links': [
        {'link_type': 'MEDI_ENTI', 'clicked': 102,
         'target_code': 'T_없는코드'}]}, main=_Main())
    t('자연 열쇠 미해석 = 보류(건너뜀)',
      r6['status'] == 'OK' and r6['skipped'] == 1)
    t('자연 열쇠 표에 단락이 있다', 'peri' in _NATKEY)
    r7 = apply_delta(pack, {'seq': 6, 'links': [
        {'link_type': 'MEDI_PERI', 'clicked': 102,
         'target_peri': 'GEN_01_BODY_1'}]}, main=_Main())
    t('단락 자연 열쇠도 보류로 처리(없는 코드)',
      r7['status'] == 'OK' and r7['skipped'] == 1)
    # ④ 풀싱크 — 비우고 전체본
    full = {'seq': 9, 'full': True, 'media': [
        {'media_id': 201, 'media_type': 'SERMON', 'format_type': 'VIDEO',
         'title': '전체본', 'url': 'https://z', 'lang_code': 'KO'}],
        'links': []}
    apply_full(pack, full)
    t('④ 풀싱크 — 옛 행이 사라지고 전체본만',
      n_media() == 1 and pack.execute(
          "SELECT media_id FROM pack_media").fetchone()[0] == 201)
    t('④ 커서도 전체본 시퀀스로', link_pack.cursor(p) == 9)
    pack.close()
    import shutil
    shutil.rmtree(d, ignore_errors=True)
    print('db_linkpack_sync selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    if '--apply' in sys.argv:
        i = sys.argv.index('--apply')
        files = [a for a in sys.argv[i + 1:] if not a.startswith('--')]
        for r in apply_files(files):
            print('%s → %s · 미디어 %d · 링크 %d · 보류 %d'
                  % (r['file'], r['status'], r['media'], r['links'],
                     r['skipped']))
    else:
        status()
