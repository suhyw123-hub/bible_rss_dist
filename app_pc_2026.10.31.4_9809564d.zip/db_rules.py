# -*- coding: utf-8 -*-
"""데이터 정합성 **룰엔진** — 규칙을 한 표에 모은다.

★★★ 왜 (2026-09-05 사용자 지시 「**데이터 정합성 점검용 종합 룰엔진**을
  만들어야 할 것 같다」 · 「운영관리 항목 중에서 일부는 일반적인 데이터
  정합성을 위한 운영관리, 다른 일부는 **전송배포를 하기 직전에 반드시 해야
  하는** 운영관리가 있는 것 같다」).
  ⚠⚠ 실측 — 점검 도구가 **15개로 흩어져** 있어 「배포 전에 무엇을 돌리나」가
    **기억에 의존**했다. 그러다 **미승인 미디어 10,863건이 코어팩으로 새는**
    것을 갈아타기 직전에야 잡았다(2026-09-04).

★★★ **점검은 「언제 도는가」로 갈린다 — 그것이 이 표의 첫 칸이다**
  · `ALWAYS`  상시 — 데이터가 앞뒤가 맞는가(끊긴 참조·고아)
  · `PREPACK` **추출 전** — **무엇이 나갈 자격이 있나**(미승인·판권 미확인)
  · `PREPUB`  배포 직전 — 만든 것이 온전한가(빈 팩·한도·판 어긋남)
  ⇒ 그전에는 `ALWAYS` 만 도구가 있었고 **`PREPACK` 이 통째로 빈칸**이었다.
    사용자가 든 예(한 url 이 같은 구절에 여러 번 · 도서집 두 번 등록 ·
    제목만 있고 본문 없음 · 구절-도서 연결 중복)가 전부 그 자리다.

⚠ **규칙을 늘리면 `RULES` 에 한 줄** — 화면·배포 게이트가 저절로 따라온다
  (`db_pack_catalog` 가 표 124개를 그렇게 다루는 것과 같은 문법).
⚠ **흩어진 도구를 지우지 않는다** — 룰엔진이 **부른다**(사용자 지시 「개발된
  것을 삭제하지 마라」). 도구가 깊이 보는 것을 여기서 다시 짜지 않는다.
⚠ **판정(FAIL)과 사실(INFO)을 가른다** — 사실을 빨갛게 칠하면 늘 빨개서
  아무도 안 본다(§115차). 색은 판정에만.

`--selftest`(의무) · `--run [when]` · `--list` · `--fix-hint 코드`.
"""
import argparse
import os
import sys
import time

import appdb

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')

#: 언제 도는가.
ALWAYS, PREPACK, PREPUB = 'ALWAYS', 'PREPACK', 'PREPUB'
WHEN_NAME = {ALWAYS: '상시', PREPACK: '추출 전', PREPUB: '배포 직전'}

#: 얼마나 나쁜가. ⚠ `BLOCK` 은 **배포를 막는다**.
BLOCK, WARN, INFO = 'BLOCK', 'WARN', 'INFO'
SEV_NAME = {BLOCK: '막음', WARN: '경고', INFO: '사실'}


def _q(sql, args=()):
    """세는 규칙 — 결과가 0 이어야 한다."""
    return ('SQL', sql, args)


#: ★★★ **규칙 표 — 여기가 단일 소스**.
#:  `(코드, 이름, 언제, 심각도, 검사, 고치는 법)`
#:  검사 = `('SQL', 질의, 인자)` 또는 `('FN', 함수이름)`.
#:  ⚠ SQL 은 **어긋난 것의 수**를 돌려준다(0 이면 통과).
RULES = [
    # ── 상시 — 데이터가 앞뒤가 맞는가 ────────────────────────────────
    ('LINK_DEAD_MEDIA', '미디어가 없는 연결', ALWAYS, WARN,
     _q("SELECT COUNT(*) FROM sys_link_asset l WHERE l.link_type LIKE 'MEDI%'"
        " AND NOT EXISTS(SELECT 1 FROM sys_media_asset m"
        "   WHERE m.media_id=l.clicked_id)"),
     '연결 관리에서 그 줄을 걷거나 미디어를 되살린다'),
    ('LINK_NULL_STATUS', '상태가 빈 연결', ALWAYS, WARN,
     _q("SELECT COUNT(*) FROM sys_link_asset"
        " WHERE record_status IS NULL"),
     "LIVE 로 채운다 — 빈 값은 세는 문마다 다르게 읽힌다"),
    ('BOOK_UNIT_NO_BOOK', '책이 없는 편', ALWAYS, BLOCK,
     _q("SELECT COUNT(*) FROM sys_book_unit u WHERE NOT EXISTS("
        "  SELECT 1 FROM sys_book_asset b WHERE b.book_id=u.book_id)"),
     '도서 관리에서 그 편의 책을 지정한다'),

    ('TAG_LINK_ORPHAN', '없는 태그를 가리키는 연결', ALWAYS, WARN,
     ('FN', '_chk_tag_orphan'),
     'TAG_* 를 ENTI_* 로 재지향한다 — 152차 태그 통합의 잔재다'),
    ('ENTI_LINK_ORPHAN', '없는 용어를 가리키는 연결', ALWAYS, BLOCK,
     ('FN', '_chk_enti_orphan'),
     '그 줄을 걷거나 용어를 되살린다 — 화면이 「찾지 못했습니다」를 낸다'),

    # ★★★ **절의 차례(sort_order)** — 새 역본을 담을 때의 안전망 (2026-09-10).
    #   끼어드는 절은 `verse_id` 를 맨 뒤에서 받으므로(31115, 31116 …) 차례는
    #   `sort_order` 만 안다. 그 칸이 비면 그 절은 **어떤 구간에도 안 들어가고
    #   조용하다** — 오류도 안 난다. 그래서 검사로 세운다(§verse_range).
    ('VERSE_ORDER_BROKEN', '절의 차례가 성하지 않다', ALWAYS, BLOCK,
     ('FN', '_chk_verse_order'),
     'bible_contents_importer 가 새 절에 sort_order 를 주었는지 본다 —'
     ' 비면 그 절이 어느 단락·플랜·주석에도 안 들어간다'),
    ('VERSE_CONTENT_ORPHAN', '좌표 없는 본문', ALWAYS, BLOCK,
     _q("SELECT COUNT(*) FROM bible_content"
        " WHERE verse_id NOT IN (SELECT verse_id FROM bible_index)"),
     '역본을 담고 코어팩을 다시 만든다 — 본문은 있는데 좌표가 없으면'
     ' 사용자 화면에 그 절이 영영 안 나온다'),

    # ── 추출 전 — **무엇이 나갈 자격이 있나**(사용자가 든 예들) ──────
    ('MEDIA_UNAPPROVED_IN_PACK', '미승인 미디어가 팩에 섞이나', PREPACK, BLOCK,
     ('FN', '_chk_media_approved'),
     'db_pack_catalog.RULE_ONLY 에 승인 조건이 걸려 있어야 한다'),
    ('URL_DUP_ON_VERSE', '같은 구절에 같은 url 이 여러 번', PREPACK, WARN,
     _q("SELECT COUNT(*) FROM (SELECT l.target_id, m.url, COUNT(*) k"
        "  FROM sys_link_asset l JOIN sys_media_asset m"
        "    ON m.media_id=l.clicked_id"
        " WHERE l.link_type='MEDI_VERS' AND m.is_active=1"
        "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
        " GROUP BY 1,2 HAVING k>1)"),
     '검토·연결 화면에서 중복 줄을 뗀다'),
    ('BOOK_DUP_CODE', '같은 책이 두 번 등록', PREPACK, BLOCK,
     _q("SELECT COUNT(*) FROM (SELECT book_code, COUNT(*) k"
        "  FROM sys_book_asset WHERE COALESCE(record_status,'LIVE')='LIVE'"
        " GROUP BY 1 HAVING k>1)"),
     '도서 관리에서 하나를 HIDE 한다'),
    ('BOOK_UNIT_NO_TEXT', '제목만 있고 본문이 없는 편', PREPACK, WARN,
     _q("SELECT COUNT(*) FROM sys_book_unit u"
        "  JOIN sys_book_asset b ON b.book_id=u.book_id"
        " WHERE COALESCE(b.record_status,'LIVE')='LIVE'"
        "   AND NOT EXISTS(SELECT 1 FROM sys_book_unit_text t"
        "     WHERE t.unit_id=u.unit_id"
        "       AND COALESCE(t.body_text,'')<>'')"),
     '본문을 채우거나 그 편을 HIDE 한다 — 받아도 빈 화면이 된다'),
    ('REFU_VERS_DUP', '같은 글이 같은 구절에 여러 번', PREPACK, WARN,
     _q("SELECT COUNT(*) FROM (SELECT clicked_id, target_id, COUNT(*) k"
        "  FROM sys_link_asset WHERE link_type='REFU_VERS'"
        "   AND COALESCE(record_status,'LIVE')='LIVE'"
        " GROUP BY 1,2 HAVING k>1)"),
     '연결 작업대에서 중복을 뗀다'),
    ('VERSION_NO_LICENSE', '판권을 모르는 역본', PREPACK, BLOCK,
     ('FN', '_chk_version_license'),
     'db_version_license --init 뒤 판권을 채운다'),
    ('PACK_ITEM_STALE', '판을 올렸는데 팩이 낡음', PREPACK, WARN,
     ('FN', '_chk_pack_stale'),
     'db_pack_publish --build 로 다시 만든다'),

    # ── 배포 직전 — 만든 것이 온전한가 ───────────────────────────────
    ('PACK_SIZE_LIMIT', '팩이 서버 한도를 넘나', PREPUB, BLOCK,
     ('FN', '_chk_pack_size'),
     '그 자산을 쪼갠다(db_pack_body.SPLIT) — 20MB 넘으면 CDN 이 거부한다'),
    ('PACK_EMPTY', '담긴 것이 없는 팩', PREPUB, BLOCK,
     ('FN', '_chk_pack_empty'),
     '만들기를 다시 한다 — 받고도 아무 일이 안 생기는 가장 나쁜 실패다'),
    ('DELTA_BASE_GAP', '델타가 건너뛴 판을 전제하나', PREPUB, BLOCK,
     ('FN', '_chk_delta_base'),
     '건너뛴 사용자에게는 **전체본**을 준다 — 델타는 차이만 담는다'),
    ('MANIFEST_ITEMS_NO_PACK', '목록에 있는데 팩이 없다', PREPUB, BLOCK,
     ('FN', '_chk_manifest_pack'),
     '팩을 **먼저** 올리고 목록을 나중에 — 반대면 「서버에 없다」만 난다'),
    # ★★★ **팩을 만든 뒤에 DB 가 바뀌었나**(2026-09-18 사용자 「고쳐 놓고
    #   배포할 때 과거 버전으로 배포해버릴 위험」 — 실측으로 맞았다).
    #   ⚠⚠ `PACK_ITEM_STALE` 로는 못 잡는다 — 그것은 「**판을 올렸는데**
    #     다시 안 만들었나」이고 판은 팩을 만들 때 오른다. 내용만 바뀌면
    #     판이 안 올라 영영 「성하다」로 나온다(실측 2026-09-04 팩에
    #     코어 표 536,377번 변경이 안 잡혔다).
    #   ⚠ **배포 직전**이라야 한다 — 추출 전에 막으면 고치는 길(다시
    #     만들기)까지 함께 막힌다.
    ('PACK_CORE_DRIFT', '팩을 만든 뒤 DB 가 바뀌었다', PREPUB, BLOCK,
     ('FN', '_chk_pack_drift'),
     '코어팩을 **다시 만든다** — 릴리스 패킹 화면 [코어팩 만들기]'),
]


# ── 함수형 검사 ──────────────────────────────────────────────────────
def _chk_media_approved(conn):
    """코어팩에 미승인 미디어가 들어가나 → (어긋난 수, 설명)."""
    try:
        import db_pack_core as PK
        ct = {t: cd for t, cd in PK.core_tables()}
    except Exception as e:                                    # noqa: BLE001
        return 1, '코어 표를 읽을 수 없다: %s' % str(e)[:50]
    bad = 0
    for tbl, idcol in (('sys_media_asset', 'media_id'),
                       ('sys_media_link', 'media_id')):
        cond = ct.get(tbl)
        if not cond:
            return 1, '%s 에 승인 조건이 없다' % tbl
        try:
            n = conn.execute(
                "SELECT COUNT(*) FROM %s x WHERE (%s)"
                "  AND NOT EXISTS(SELECT 1 FROM sys_media_asset m"
                "    WHERE m.media_id=x.%s AND m.is_active=1)"
                % (tbl, cond.replace(tbl + '.', 'x.')
                   .replace('is_active=1 AND', 'x.is_active=1 AND')
                   .replace('COALESCE(record_status',
                            'COALESCE(x.record_status'), idcol)).fetchone()[0]
        except Exception:
            n = 0
        bad += n
    return bad, '미승인이 %d건 섞인다' % bad if bad else ''


def _chk_tag_orphan(conn):
    """없는 태그를 가리키는 연결 → (수, 설명).

    ★★★ 왜 (2026-09-05 사용자 신고 「**이 자산을 찾지 못했습니다. 용어 #191**
      에러가 뜬다」). ⚠⚠ 실측 — `sys_tag_asset` 이 **0개**인데(152차 태그 통합
      수술로 배포 태그를 엔티티에 흡수했다) `user_link_asset` 에 **10행**이
      남아 있었다. 그 번호가 곧 엔티티 번호라 화면이 「용어 #191」이라 불렀다
      (`LP_K_TAG` 를 「용어」로 바꾼 뒤라 더 헷갈렸다).
    ⚠ **걷지 않고 재지향한다** — 대상 엔티티가 살아 있으면 사용자가 붙인
      연결이 정당하다(실측 10행 전부 아데미·겟세마네·노아 … 살아 있었다).
    """
    n = 0
    for t in ('sys_link_asset', 'user_link_asset'):
        try:
            n += conn.execute(
                "SELECT COUNT(*) FROM %s l WHERE l.link_type LIKE 'TAG!_%%'"
                " ESCAPE '!' AND NOT EXISTS(SELECT 1 FROM sys_tag_asset x"
                "   WHERE x.sys_tag_id=l.clicked_id)" % t).fetchone()[0]
        except Exception:
            pass
    return n, ('미아 %d행 — 화면이 「찾지 못했습니다」를 낸다' % n) if n else ''


def _chk_enti_orphan(conn):
    """없는 용어를 가리키는 연결 → (수, 설명)."""
    n = 0
    for t in ('sys_link_asset', 'user_link_asset'):
        try:
            n += conn.execute(
                "SELECT COUNT(*) FROM %s l WHERE"
                " (l.link_type LIKE 'ENTI!_%%' ESCAPE '!' AND NOT EXISTS("
                "   SELECT 1 FROM sys_entity_master e"
                "    WHERE e.entity_id=l.clicked_id))"
                " OR (l.link_type LIKE '%%!_ENTI' ESCAPE '!' AND NOT EXISTS("
                "   SELECT 1 FROM sys_entity_master e"
                "    WHERE e.entity_id=l.target_id))" % t).fetchone()[0]
        except Exception:
            pass
    return n, ('미아 %d행' % n) if n else ''


def _chk_verse_order(conn):
    """절의 차례가 성한가 → (문제 수, 설명). 판정은 `verse_range.health` 한 문."""
    try:
        import verse_range as _vr
        bad, _n = _vr.health(conn)
        # ⚠ 「좌표 없는 본문」은 제 규칙이 따로 있다 — 여기서 두 번 세지 않는다
        bad = [x for x in bad if '좌표 없는 본문' not in x]
        return len(bad), ' · '.join(bad)
    except Exception as e:                                    # noqa: BLE001
        return -1, str(e)[:60]


def _chk_version_license(conn):
    try:
        n = conn.execute(
            "SELECT COUNT(*) FROM bible_version"
            " WHERE COALESCE(copyright_type,'')=''").fetchone()[0]
    except Exception:
        return 0, '(판권 칸이 아직 없다 — db_version_license --init)'
    return n, ('판권 미확인 %d역본' % n) if n else ''


def _chk_pack_drift(conn):
    """코어팩을 만든 뒤 코어 표가 바뀌었나 → (바뀐 표 수, 까닭)."""
    try:
        import db_pack_fresh as FR
        return FR.check(conn)
    except Exception as e:                                    # noqa: BLE001
        return 0, '(잴 수 없다: %s)' % str(e)[:40]


def _chk_pack_stale(conn):
    try:
        import db_pack_publish as PP
        p = PP.plan(conn)
        n = len([t for t in p['rows'] if t.get('stale')])
        return n, ('낡은 팩 %d개' % n) if n else ''
    except Exception as e:                                    # noqa: BLE001
        return 0, '(잴 수 없다: %s)' % str(e)[:40]


def _chk_pack_size(conn):
    try:
        import db_pack_publish as PP
        p = PP.plan(conn)
        big = [t for t in p['rows'] if t['bytes'] >= PP.LIMIT_CDN]
        return len(big), '; '.join(
            '%s %.1fMB' % (t['file'][:28], t['bytes'] / PP.MB)
            for t in big[:3])
    except Exception as e:                                    # noqa: BLE001
        return 0, '(잴 수 없다: %s)' % str(e)[:40]


def _chk_pack_empty(conn):
    """만들어 둔 팩 중 담긴 것이 0 인 것."""
    try:
        import db_pack_core as PK
        import db_pack_publish as PP
    except Exception:
        return 0, ''
    bad = []
    for t in PP.plan(conn)['rows']:
        p = PP._dist(t['file'])
        if not os.path.exists(p):
            continue
        try:
            body = PK.read(p)
            n = sum(len(d.get('rows') or [])
                    for d in (body.get('tables') or {}).values())
            if n == 0:
                bad.append(t['file'])
        except Exception:
            bad.append(t['file'] + '(못 읽음)')
    return len(bad), '; '.join(bad[:3])


def _chk_delta_base(conn):
    """델타 파일이 **건너뛴 판**을 전제하나.

    ★★★ 왜 (2026-09-05 사용자 물음 「8번 다운로드 하지 않았더라도 9번을
      다운로드 하면 8번 파일에 있었던 것까지 모두 흡수되는 것으로 이해하겠다」).
      ⚠⚠ **전체본은 그 말이 맞고 델타는 아니다** — `delta_8_9` 는 차이만 담아
        7번인 사람이 먹으면 **8번 변경분이 빠진다.** 그런데 `db_pack_apply` 가
        그것을 **검사하지 않는다**(실측). ⇒ 여기서 잡는다.
    """
    try:
        import db_pack_publish as PP
        d = PP.DIST
    except Exception:
        return 0, ''
    import re
    bad = []
    for f in (os.listdir(d) if os.path.isdir(d) else []):
        m = re.search(r'_(\d+)_(\d+)\.json\.gz$', f)
        if not m or not f.startswith('delta'):
            continue
        a, b = int(m.group(1)), int(m.group(2))
        if b - a != 1:
            bad.append('%s (%d→%d 은 한 칸이 아니다)' % (f, a, b))
    return len(bad), '; '.join(bad[:3])


def _chk_manifest_pack(conn):
    """manifest 목록에 있는데 팩 파일이 없나."""
    try:
        import db_linkpack_build as LB
        import db_pack_body as PB
        import db_pack_core as PK
        import db_pack_publish as PP
        mf = LB._load(LB.MANIFEST, {}) or {}
    except Exception:
        return 0, ''
    bad = []
    for it in (mf.get('items') or []):
        k = (it.get('kind') or '').upper()
        fn = (PK.CORE_NAME if k == 'CORE'
              else PB.pack_name(k, it.get('key'), it.get('lang'),
                                it.get('variant')))
        if not os.path.exists(PP._dist(fn)):
            bad.append(fn)
    return len(bad), '; '.join(bad[:3])


#: ★★★ **흩어진 도구를 규칙으로 흡수한다 — 지우지 않고 부른다**.
#:  `(코드, 이름, 언제, 심각도, 모듈, 부를 함수, 고치는 법)`
#:  ⚠⚠ 실측 — 점검 도구가 15개라 **배포 전에 무엇을 돌리나가 기억에 의존**했다.
#:    여기 적으면 룰엔진 한 번에 다 돈다.
#:  ⚠ **도구가 깊이 보는 것을 여기서 다시 짜지 않는다** — 그러면 두 벌이 되고
#:    한쪽만 고쳐진다. 도구는 그대로 두고 **결과만 받는다.**
#:  ⚠ 도구가 없거나 느리면 **그렇게 말하고 넘어간다**(INFO) — 하나가 막으면
#:    나머지를 못 본다.
#: ★★ **시작 이미지** — 2026-09-05. 기본 사진이 코어에 남아 있나.
RULES += [
    ('SPLASH_NO_BASIC', '코어에 기본 시작 사진이 없다', PREPACK, WARN,
     _q("SELECT CASE WHEN (SELECT COUNT(*) FROM sys_splash_image"
        "   WHERE COALESCE(style,'')='' AND COALESCE(is_active,1)=1)=0"
        "  AND (SELECT COUNT(*) FROM sys_splash_image)>0"
        " THEN 1 ELSE 0 END"),
     '사진 하나의 style 을 비운다 — 스타일이 붙은 사진은 팩으로 나가므로, '
     '팩을 안 받은 사용자에게는 시작 화면 사진이 하나도 없게 된다'),
]


#: ★★ **릴리스 패킹** — 2026-09-05 신설. 스몰팩을 어떻게 묶었나를 잰다.
RULES += [
    ('CYCLE_CROSS', '주기를 넘는 연결', PREPUB, WARN,
     ('FN', '_chk_cycle_cross'),
     '릴리스 패킹에서 두 스몰팩을 같은 주기로 묶거나, 자연 열쇠로 싣고 '
     '모르는 것은 보류한다'),
    ('CYCLE_ADVICE', '빈도와 주기가 어긋난다', PREPACK, INFO,
     ('FN', '_chk_cycle_advice'),
     '릴리스 패킹 화면에서 주기를 옮긴다 — **통계는 권하고 사람이 정한다**'),
]


TOOLS = [
    ('INTEGRITY_ALL', '무결성 전수(39검사)', ALWAYS, BLOCK,
     'db_integrity', 'rule_count',
     'db_integrity --check 로 어느 검사가 걸렸는지 본다'),
    ('LINKPACK_CHECK', '링크 팩 왕복 점검', PREPUB, WARN,
     'db_linkpack_check', 'rule_count',
     'db_linkpack_check 를 직접 돌려 어느 시나리오가 깨졌는지 본다'),
    ('BOOK_URL_AUDIT', '도서 출처 주소', PREPACK, WARN,
     'db_book_url_audit', 'rule_count',
     'db_book_url_audit --check — 죽은 주소는 소개문이 거짓이 된다'),
    ('PLAN_BOOK_AUDIT', '도서 플랜 정합성', PREPACK, WARN,
     'db_plan_book_audit', 'rule_count',
     'db_plan_book_audit --check'),
    # ⚠⚠ **화면을 띄우는 도구는 여기 넣지 않는다** — `db_myedit_check` 를
    #   넣었더니 `--run` 이 **Tk 창을 열고 52항목을 눌렀다**(실측). 룰엔진은
    #   조용히 세는 자리다. 그런 도구는 사람이 직접 돌린다.
    #   (여기 넣을 것 = `import` 만으로 아무 일도 안 하는 도구)
]


def _tool_count(mod, fn):
    """도구를 불러 **어긋난 수**를 받는다 → `(수, 설명)`.

    ⚠ 도구마다 이름이 다르므로 `rule_count(conn)` 한 문을 **도구 쪽에** 둔다.
      없으면 **INFO 로 넘어간다**(막지 않는다).
    """
    try:
        m = __import__(mod)
    except Exception as e:                                    # noqa: BLE001
        return None, '도구가 없다: %s' % str(e)[:40]
    f = getattr(m, fn, None)
    if not callable(f):
        return None, '%s.%s 가 아직 없다(도구를 직접 돌린다)' % (mod, fn)
    try:
        c = appdb.connect(DB)
        try:
            r = f(c)
        finally:
            c.close()
        if isinstance(r, tuple):
            return int(r[0]), str(r[1])[:60]
        return int(r), ''
    except Exception as e:                                    # noqa: BLE001
        return None, '도구가 답을 못 냈다: %s' % str(e)[:50]


# ── 실행 ─────────────────────────────────────────────────────────────
def _chk_cycle_cross(conn):
    """**주기를 넘는 연결** — 빠른 스몰팩이 느린 것을 가리킨다.

    ★★★ 이것이 릴리스 패킹의 진짜 위험이다 — A 는 매일 나가는데 A 가
      가리키는 B 가 연 2회 묶음에 있으면, **B 가 아직 안 온 사용자에게
      A 의 연결이 미아**가 된다.
    ⚠ **막지 않는다**(WARN) — 자연 열쇠로 싣고 보류하는 길이 이미 있고
      (`db_linkpack_sync`), 폴백이 말해 주면 되는 경우도 있다.
      실측 지금 25줄이라 막으면 **늘 빨개서 아무도 안 본다**(§115차).
    """
    try:
        import db_pack_stat as ST
        xs = ST.cross_cycle(conn)
    except Exception as e:                                    # noqa: BLE001
        return 0, '(잴 수 없다: %s)' % str(e)[:40]
    if not xs:
        return 0, ''
    top = xs[0]
    return len(xs), ('%s(%s) → %s(%s) %s행 …'
                     % (top['label'][:20], top['mine'], top['other'][:20],
                        top['theirs'], format(top['rows'], ',')))


def _chk_cycle_advice(conn):
    """**빈도와 주기가 어긋난다** — 릴리스를 다시 짤 때가 됐다는 신호.

    ⚠⚠ **자동으로 안 바꾼다**(사용자 지시) — 감사 로그 기간이 대표성이
      없을 수 있다. 화면이 보이고 사람이 누른다.
    """
    try:
        import db_pack_stat as ST
        ad = ST.advice(conn, 30)
        lo, hi, n = ST.log_span(conn)
    except Exception as e:                                    # noqa: BLE001
        return 0, '(잴 수 없다: %s)' % str(e)[:40]
    if not ad:
        return 0, ''
    return len(ad), ('%s 등 · 로그 %s~%s'
                     % (', '.join(a['label'][:18] for a in ad[:2]), lo, hi))


def run(conn, when=None, only=None, skip_tools=False):
    """규칙을 돈다 → `[{code,name,when,sev,bad,note,fix,ok}]`.

    ⚠ **한 규칙이 터져도 나머지는 돈다** — 하나가 막으면 아무것도 못 본다.
    ⚠ `skip_tools` — 흩어진 도구는 느린 것이 있다(화면을 띄우는 것도 있다).
      화면이 자주 부를 때는 끄고, 배포 게이트에서는 켠다.
    """
    out = []
    for code, name, w, sev, chk, fix in RULES:
        if when and w != when:
            continue
        if only and code not in only:
            continue
        bad, note = 0, ''
        try:
            if chk[0] == 'SQL':
                bad = conn.execute(chk[1], chk[2]).fetchone()[0]
            else:
                fn = globals().get(chk[1])
                bad, note = fn(conn) if fn else (0, '(검사 없음)')
        except Exception as e:                                # noqa: BLE001
            bad, note = -1, '검사 실패: %s' % str(e)[:70]
        out.append({'code': code, 'name': name, 'when': w, 'sev': sev,
                    'bad': bad, 'note': note, 'fix': fix,
                    'ok': (bad == 0)})
    # ★ 흩어진 도구도 함께 — **없으면 넘어간다**(INFO)
    for code, name, w, sev, mod, fn, fix in TOOLS:
        if when and w != when:
            continue
        if only and code not in only:
            continue
        if skip_tools:
            continue
        n, note = _tool_count(mod, fn)
        if n is None:
            out.append({'code': code, 'name': name, 'when': w, 'sev': INFO,
                        'bad': 0, 'note': note, 'fix': fix, 'ok': True,
                        'tool': True})
        else:
            out.append({'code': code, 'name': name, 'when': w, 'sev': sev,
                        'bad': n, 'note': note, 'fix': fix, 'ok': (n == 0),
                        'tool': True})
    return out


def blocked(rows):
    """배포를 막아야 하나 → `[막는 규칙…]`.

    ⚠ **검사가 터진 것(-1)도 막는다** — 「모르는 것」을 통과시키지 않는다.
    """
    return [r for r in rows if r['sev'] == BLOCK and r['bad'] != 0]


def gate(conn, when=PREPACK):
    """배포 게이트 → `(통과?, [막는 규칙…])`. 화면·발행 도구가 부른다."""
    rows = run(conn, when)
    b = blocked(rows)
    return (not b), b


# ── 자가검증 ─────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', name, extra))

    codes = [r[0] for r in RULES]
    t('★ 규칙 코드가 겹치지 않는다', len(codes) == len(set(codes)),
      '%d개' % len(codes))
    t('★★ **세 때가 다 있다**',
      set(r[2] for r in RULES) == {ALWAYS, PREPACK, PREPUB},
      str(sorted(set(r[2] for r in RULES))))
    t('  심각도가 정해진 값이다',
      all(r[3] in (BLOCK, WARN, INFO) for r in RULES))
    t('★★★ **규칙마다 고치는 법이 있다**(§0-1 — 무엇을 하라는지 말한다)',
      all((r[5] or '').strip() for r in RULES))
    miss = [r[4][1] for r in RULES
            if r[4][0] == 'FN' and r[4][1] not in globals()]
    t('★★ **함수형 검사가 실제로 있다**', not miss, str(miss))

    tc = [x[0] for x in TOOLS]
    t('★★ **흩어진 도구가 표에 있다**', len(tc) >= 4, '%d개' % len(tc))
    # ⚠ 화면을 띄우는 도구가 섞이면 룰엔진이 창을 연다(실측으로 잡았다)
    t('★★★ **화면을 띄우는 도구가 안 섞였다**',
      not [x for x in TOOLS if 'myedit' in x[4] or 'view' in x[4]],
      str([x[4] for x in TOOLS]))
    t('  도구 코드도 안 겹친다', not (set(tc) & set(codes)))
    t('★★ **도구마다 고치는 법이 있다**',
      all((x[6] or '').strip() for x in TOOLS))

    c = appdb.connect(DB)
    try:
        rows = run(c, skip_tools=True)
        t('★ 전 규칙이 돈다', len(rows) == len(RULES), '%d개' % len(rows))
        err = [r for r in rows if r['bad'] == -1]
        t('★★★ **검사가 터지지 않는다**', not err,
          '; '.join('%s: %s' % (r['code'], r['note']) for r in err[:2]))
        for w in (ALWAYS, PREPACK, PREPUB):
            n = len(run(c, w))
            t('  %s 만 선택해 돈다' % WHEN_NAME[w], n > 0, '%d개' % n)
        okg, b = gate(c, PREPACK)
        t('★★ 게이트가 답을 낸다', isinstance(okg, bool),
          '통과=%s · 막는 것 %d' % (okg, len(b)))

        # ★★★ 탐지력 — 일부러 깨뜨려 잡는가(롤백)
        c.execute('BEGIN')
        try:
            c.execute("INSERT INTO sys_link_asset(link_type, clicked_id,"
                      " target_id, record_status)"
                      " VALUES('MEDI_VERS', 99999901, 1, 'LIVE')")
            r2 = run(c, only=['LINK_DEAD_MEDIA'])[0]
            t('★★★ **깨뜨리면 잡는다**(탐지력)', r2['bad'] > 0,
              '%d건' % r2['bad'])
        finally:
            c.rollback()
        r3 = run(c, only=['LINK_DEAD_MEDIA'])[0]
        t('★ 되돌리면 원래대로', r3['bad'] >= 0, '%d건' % r3['bad'])

        # ⚠ 지금 실 DB 상태를 남긴다(판정이 아니라 기록)
        print('  ── 지금 상태 ──')
        for r in rows:
            mark = 'OK ' if r['ok'] else ('막음' if r['sev'] == BLOCK else '경고')
            print('     %-4s %-26s %-7s %s %s'
                  % (mark, r['code'], WHEN_NAME[r['when']],
                     r['bad'], r['note'][:40]))
    finally:
        c.close()
    print('db_rules selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--run', nargs='?', const='ALL')
    ap.add_argument('--list', action='store_true')
    ap.add_argument('--fix-hint')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    if a.list:
        for code, name, w, sev, _c, fix in RULES:
            print('%-26s %-7s %-4s %s' % (code, WHEN_NAME[w], SEV_NAME[sev],
                                          name))
        return
    if a.fix_hint:
        for code, name, _w, _s, _c, fix in RULES:
            if code == a.fix_hint:
                print('%s — %s\n  고치는 법: %s' % (code, name, fix))
        return
    if a.run:
        c = appdb.connect(DB)
        try:
            when = None if a.run == 'ALL' else a.run.upper()
            rows = run(c, when)
            t0 = time.time()
            nb = 0
            for r in rows:
                mark = '  OK' if r['ok'] else (
                    '  ✕ ' if r['sev'] == BLOCK else '  ⚠ ')
                if not r['ok']:
                    nb += 1
                print('%s %-26s %-7s %6s  %s'
                      % (mark, r['code'], WHEN_NAME[r['when']], r['bad'],
                         r['note'][:52]))
                if not r['ok']:
                    print('        고치는 법: %s' % r['fix'])
            b = blocked(rows)
            print('\n%d규칙 · 어긋남 %d · **막는 것 %d** · %.1f초'
                  % (len(rows), nb, len(b), time.time() - t0))
        finally:
            c.close()


if __name__ == '__main__':
    main()
