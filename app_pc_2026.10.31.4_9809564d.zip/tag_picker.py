# -*- coding: utf-8 -*-
"""
tag_picker.py — **태그를 고르는 한 자리** (2026-08-21 신설)
------------------------------------------------------------
사용자가 자기 글(연구자료)에 태그를 여러 개 붙이는 장치. 화면마다 따로 만들면
곧 서식과 규칙이 갈라지므로 **부품 두 개**로 낸다:

  · `TagChips(parent, db_path, …)` — 고른 태그를 칩으로 보여 주는 한 줄.
    `[+ 태그]` 를 누르면 아래 팝업이 열리고, 칩의 `✕` 로 하나씩 뗀다.
  · `pick(parent, db_path, chosen, lang)` — 고르는 팝업. 축(6가지) 단추 +
    검색 + 체크. **고른 것들의 집합**을 돌려준다(취소하면 None).

★ **저장은 이 부품이 하지 않는다.** 화면이 글을 저장해 번호(ref_id)를 얻은
  **뒤에** `save_links()` 를 부른다 — 새 글은 저장 전에 번호가 없다.

★ **태그는 sys 79개를 고르는 것이 기본**(6축 · db_tag_system). 사용자가 없는
  말을 쓰고 싶으면 **내 태그**를 만든다(`user_tag_asset`, `tag_source='USER'`).
  ⚠ 자유 입력만 두면 분류가 무너진다 — 고르기를 앞에 두고 만들기는 뒤에 둔다.

★ 연결은 **`userdb.user_link_asset`** 한 표에 남는다(2026-08-24 통합).
  sys 태그를 붙여도 사용자의 선택이므로 **배포 DB 에는 쓰지 않는다.**
  `target_type` 은 화면이 정한다 — 연구자료는 `'USER_REF'`.
  ⚠ 옛 표 `user_tag_link` 은 되돌릴 수 있게 남아 있지만 읽지 않는다.

`python tag_picker.py --selftest` — 의무.
"""
import tkinter as tk
from tkinter import ttk, simpledialog

import appdb
import i18n
import db_tag_system as T
import overlay_mark as OM

# 축 — **단일 소스는 `db_tag_system.axes()`** (2026-08-21). 여기에 목록을
# 베껴 두면 축을 늘릴 때 한 곳을 빠뜨린다(실제로 세 곳에 있었다).
AXES = list(T.ALL_AXES)

#: ★ 2026-08-24 통합 표(개인 쪽). `tag_source` 는 link_type 앞부분이 된다.
LINK_TBL = 'userdb.user_link_asset'

#: ★★ **범위** — 관리자는 배포 표에, 사용자는 개인 표에 (2026-08-27).
#  그전에는 개인 표뿐이라 관리자 연결 창의 [태그 고르기…] 가 **잠겨 있었다**
#  (사용자 신고 「태그 고르기 버튼 비활성화되어 있다」). 잠근 까닭은 옳았다 —
#  그대로 누르면 배포되지 않는데 붙은 것처럼 보였다. 이제 표를 갈아 끼운다.
#  ⚠ 실측 — 배포 표에 이미 태그 연결이 있다(`TAG_BUNT` 229 · `TAG_CONT` 41 ·
#    `TAG_BOOK` 2 · `TAG_PLAN` 1). 새 개념이 아니라 **닿을 길이 없던 것**이다.
TBL_BY_SCOPE = {'USER': LINK_TBL, 'SYS': 'sys_link_asset'}
PK_BY_SCOPE = {'USER': 'user_link_id', 'SYS': 'sys_link_id'}


def _tbl(scope='USER'):
    if scope not in TBL_BY_SCOPE:
        raise ValueError('모르는 범위: %r (SYS 또는 USER)' % (scope,))
    return TBL_BY_SCOPE[scope]


def _pk(scope='USER'):
    return PK_BY_SCOPE[scope]


def _lts_scoped(target_type, scope='USER'):
    """그 범위에서 읽고 쓸 태그 연결 갈래.

    ⚠ **SYS 에는 `UTAG_` 를 넣지 않는다** — 내가 만든 태그는 개인 것이라
      배포 표에 실으면 남의 PC 에만 있는 번호를 가리킨다(§USER_ONLY 규칙).
    """
    c = _code(target_type)
    return ('TAG_%s' % c,) if scope == 'SYS' else ('TAG_%s' % c, 'UTAG_%s' % c)


def _code(target_type):
    """대상 종류 → 넉 자 코드. `db_tag_system.TGT_CODE` 가 단일 소스다."""
    return T.TGT_CODE.get(target_type, target_type)


def _lt(source, target_type):
    """`TAG_UREF`(관리자 태그) · `UTAG_UREF`(내가 만든 태그)."""
    head = 'UTAG' if (source or '').upper() == 'USER' else 'TAG'
    return '%s_%s' % (head, _code(target_type))


def _lts(target_type):
    """그 대상의 **태그 연결 두 종류**.

    ⚠⚠ **`substr(link_type,-4)` 만으로 고르면 안 된다** — `BUNT_UREF`
      (도서 편 ↔ 내 자료)처럼 **끝 넉 자가 같은 딴 연결**이 함께 걸린다.
      그러면 그 행의 `clicked_id` 를 태그 번호로 잘못 읽는다(실측으로 잡았다).
    """
    c = _code(target_type)
    return ('TAG_%s' % c, 'UTAG_%s' % c)


def axes_for(db_path=None, lang='KO', only_used=True):
    """지금 쓸 축 목록. **태그가 있는 축만** — 빈 서랍에 단추를 만들지 않는다."""
    try:
        with _conn(db_path) as conn:
            got = T.axes(conn, lang, only_used=only_used)
        return got or list(T.ALL_AXES)
    except Exception:
        return list(T.ALL_AXES)

# 연결된 태그 칩의 파스텔 바탕 — 단추와 헷갈리지 않게 **글자 + 옅은 색**.
# ⚠ 팔레트 역할색이 아니라 고정값이다(§0 예외) — 어느 테마에서도 「칩」으로
#   읽혀야 하고, 역할색을 쓰면 축 단추와 같은 색이 되어 구분이 사라진다.
# ★ **태그 단추 규격 — 도서읽기 동작 줄과 같게** (2026-08-21 사용자 지시
#   「무지막지한 무기들 같다. 도서읽기에 표시된 사이즈면 매우 적절」).
#   태그는 메인 기능이 아니다 — 커야 할 이유가 없다.
# 축 필터처럼 **곁다리** 단추 — 작게(2026-08-21 사용자 「무지막지한 무기」)
_SMALL_BTN = dict(font=('', 9), bd=1, relief='raised', cursor='hand2',
                  padx=6, pady=0)
# ★ **동작 단추** — 표준 크기(2026-08-21 사용자 「버튼 자체의 크기도 너무 작다」).
#   ⚠ 글꼴을 적지 않는다(§36) — TkDefaultFont = 통합 폰트를 따라간다.
_ACT_BTN = dict(bd=1, relief='raised', cursor='hand2', padx=12, pady=3)
# 필터 단추 — 작게 두되 크기는 `theme_font.register(size_delta=-2)` 가 정한다.
_FILT_BTN = dict(bd=1, relief='raised', cursor='hand2', padx=6, pady=0)

_PASTEL_SYS = '#E8F1F8'      # 시스템 태그
_PASTEL_MINE = '#FBF3DC'     # 내 태그


def _conn(db_path=None):
    return appdb.connect(db_path or appdb.MAIN_DB)


def need_target(parent, what=''):
    """대상이 없을 때 **한 가지 말로** 알린다 (2026-08-21 사용자 지시 —
    「대상을 클릭하지 않고 [태그]를 누르면 반응이 없다. 메시지를 통일하라」).

    ⚠ 잠긴 단추는 「고장」으로 읽히고, 화면마다 다른 말은 **다른 규칙**으로
      읽힌다. 네 화면이 이 함수 하나를 쓴다."""
    from tkinter import messagebox
    msg = i18n.t('TAG_NEED_PICK', '먼저 목록에서 대상을 선택하세요.')
    if what:
        msg = '%s\n(%s)' % (msg, what)
    messagebox.showinfo(i18n.t('TAG_BTN', '태그'), msg, parent=parent)


def ensure(db_path=None):
    """표가 없으면 만든다(멱등)."""
    try:
        T.init_user_schema(db_path or appdb.MAIN_DB)
    except Exception:
        pass


# ── 조회 ────────────────────────────────────────────────────────────────
def all_tags(db_path=None, lang='KO'):
    """선택할 수 있는 태그 전부 → [(source, tag_id, 표시이름, 축, 검색이름, 표식)].

    ★ **표시는 짧게, 검색은 원어까지** (2026-08-21 사용자 지시). 태그 이름은
      `사랑` 으로 보이지만 「아가페」로도 찾힌다 — 다섯째 칸이 원본이다.
    ★ **여섯째 = N/E/H 표식**(2026-08-26 — 덮개가 도는 모든 화면에 부착).
      이름을 고친 sys 태그는 `E`, 내가 만든 태그는 `N`. 숨긴 것은 여기서 이미
      빠지므로 `H` 는 안 나온다(읽는 목록이다).
    ⚠ 칸을 늘렸다 — **다섯 칸으로 언패킹하던 곳이 있으면 터진다.** 실측으로
      호출부를 전부 고쳤다(`for a, b, c, d, e in ...` → 여섯 칸 또는 `*_`)."""
    out = []
    with _conn(db_path) as conn:
        # ★ **원천이 숨으면 태그도 숨는다** (2026-08-21 사용자 확정 — 「엔티티를
        #   hide 하면 당연히 따라서 숨긴다」). 연동 태그는 이름을 엔티티에서
        #   빌려 오므로, 엔티티가 내려가면 이름 없는 태그가 남는다.
        #   ⚠ 지우거나 따라 쓰지 않고 **조회에서 뺀다** — 엔티티를 되살리면
        #     태그도 저절로 돌아온다(맞춰 쓰는 코드가 없어 어긋날 일이 없다).
        # ★ 덮개 (2026-08-26 읽기 배선) — 내가 숨긴 태그·가린 엔티티는 목록에서
        #   뺀다. 이름은 tag_display_name 이 내 이름(덮개)을 먼저 본다.
        _hid_codes = T.user_hidden_entity_codes(conn)
        for tid, sid, kind, eid, dref, cat, ecode in conn.execute(
                "SELECT t.sys_tag_id, t.tag_name_sid, COALESCE(t.tag_kind,'PLAIN'),"
                " t.entity_id, t.dict_ref, t.tag_category, e.entity_code "
                "FROM sys_tag_asset t "
                "LEFT JOIN sys_entity_master e ON e.entity_id = t.entity_id "
                "WHERE COALESCE(t.record_status,'LIVE')='LIVE' "
                "  AND (t.entity_id IS NULL "
                "       OR COALESCE(e.record_status,'LIVE')='LIVE') "
                "ORDER BY t.tag_category, t.sys_tag_id"):
            ov = T.tag_overlay(conn, sid, kind, eid)
            if ov is not None and ov[0] == 'HIDE':
                continue
            if ecode and ecode in _hid_codes:
                continue
            full = T.tag_display_name(conn, (sid, kind, eid, dref), lang, short=False)
            mk = OM.EDIT if (ov is not None and (ov[1] or '').strip()) else ''
            out.append(('SYS', tid, T.short_label(full), cat, full, mk))
        try:
            for tid, sid, cat in conn.execute(
                    "SELECT user_tag_id, tag_name_sid, tag_category "
                    "FROM user_tag_asset "
                    "WHERE COALESCE(record_status,'LIVE')='LIVE' ORDER BY user_tag_id"):
                _nm = sid or ('#%s' % tid)
                out.append(('USER', tid, _nm, cat or 'THEME', _nm, OM.NEW))
        except Exception:
            pass
    return out


def term_rows(db_path=None, lang='KO'):
    """이름 후보 = **용어(엔티티) + 내 태그** — all_tags 와 같은 6칸 꼴.

    ★ 152차 통합 수술로 배포 태그가 0 이 됐다(「태그/용어/엔티티는 한 단어」).
      그 뒤로 [태그 고르기…] 목록이 사실상 비었다(2026-09-01 0.txt 3번 신고
      「아무런 태그이름도 표시되지 않는다」). **이름만 쓰는 자리**(지도 분류
      태그 등 자유 글)는 이 목록을 `pick(rows_provider=…)` 로 넣는다.
    ⚠ 연결 저장(save_links) 경로에는 쓰지 말 것 — 키가 ('ENTI', entity_id) 라
      태그 표 번호가 아니다.
    축 칸 = 엔티티 유형 코드(PERSON·TERM…) — 축 필터 단추는 실제로 있는
    값만 만들어지므로 그대로 통한다."""
    out = []
    with _conn(db_path) as conn:
        try:
            _hid = T.user_hidden_entity_codes(conn)
        except Exception:
            _hid = set()
        for eid, ecode, etype, nm in conn.execute(
                "SELECT m.entity_id, m.entity_code, m.entity_type,"
                " COALESCE((SELECT contents FROM sys_text_asset"
                "  WHERE text_type='ENTITY_NAME' AND clicked_id=m.entity_id"
                "    AND lang_code=? AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1),"
                " (SELECT contents FROM sys_text_asset"
                "  WHERE text_type='ENTITY_NAME' AND clicked_id=m.entity_id"
                "    AND lang_code='EN' AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1),"
                " m.entity_code) "
                "FROM sys_entity_master m "
                "WHERE COALESCE(m.record_status,'LIVE')='LIVE' "
                "ORDER BY m.entity_type, m.entity_id", (lang,)):
            if ecode in _hid:
                continue
            out.append(('ENTI', eid, T.short_label(nm), etype, nm, ''))
        try:
            for tid, sid, cat in conn.execute(
                    "SELECT user_tag_id, tag_name_sid, tag_category "
                    "FROM user_tag_asset "
                    "WHERE COALESCE(record_status,'LIVE')='LIVE' ORDER BY user_tag_id"):
                _nm = sid or ('#%s' % tid)
                out.append(('USER', tid, _nm, cat or 'THEME', _nm, OM.NEW))
        except Exception:
            pass
    return out


def tags_of(db_path, target_type, target_id, lang='KO', scope='USER'):
    """그 자산에 붙어 있는 태그 → [(source, tag_id, 이름, 축)]."""
    ensure(db_path)
    if not target_id:
        return []
    names = {(s, t): (n, c) for s, t, n, c, _f, *_m in all_tags(db_path, lang)}
    out = []
    with _conn(db_path) as conn:
        # ★ 2026-08-24 통합 표. `tag_source` 는 **link_type 앞부분**이 된다
        #   (`TAG_…` = 관리자 태그 · `UTAG_…` = 내가 만든 태그).
        # ★ 범위가 표를 정한다(2026-08-27) — SYS 는 배포 표만 본다
        _lts2 = _lts_scoped(target_type, scope)
        _ph = ','.join('?' * len(_lts2))
        # ★★ **구간을 본다** (2026-09-01 — 용어 티커에서 고친 것과 같은 자리).
        #   `target_id=?` 만 보면 `창1:1~31` 로 이어 둔 태그가 **첫 절에만**
        #   뜬다 — 넣어도 화면에 없는 꼴이라 「저장은 되는데 안 보인다」다.
        #   ⚠ `end_id` 가 빈 옛 행은 `COALESCE` 가 제자리로 돌려놓는다
        #     (실측 279행 전부 NULL — 동작 불변).
        for lt, tid in conn.execute(
                "SELECT link_type, clicked_id FROM %s "
                "WHERE link_type IN (%s) "
                "AND ? BETWEEN target_id AND COALESCE(end_id, target_id) "
                "AND COALESCE(record_status,'LIVE')='LIVE'"
                % (_tbl(scope), _ph),
                _lts2 + (int(target_id),)):
            src = 'USER' if lt.startswith('UTAG_') else 'SYS'
            nm, cat = names.get((src, tid), ('#%s' % tid, ''))
            out.append((src, tid, nm, cat))
    return out


def tags_read(db_path, target_type, target_id, lang='KO'):
    """**사용자가 보는 태그 = 배포 + 개인** → [(source, tag_id, 이름, 축)].

    ★★★ **읽는 문을 하나로** (2026-09-01 신설). `tags_of` 는 **한 표만** 보는
      낮은 층 문이라, 화면이 그것을 `scope='USER'` 로 부르면 **배포 태그가
      통째로 안 보인다.** 실제로 두 번 났다:
        · §118차 — My Edit 에 배포 태그 279건이 안 보였다
        · 2026-09-01 — P1 티커에 배포 태그가 안 보였다(같은 병, 다른 화면)
      §118차는 `link_picker.links_of` **안에서만** 합쳐 고쳤기 때문에 티커는
      그대로 새고 있었다. ⇒ **합치는 일을 이 문 하나가 맡는다.**

    ⚠ **`tags_of` 를 이것으로 바꾸지 말 것** — 저장 쪽(`save_links` 의 지금
      상태 비교)은 **개인 표만** 봐야 한다. 배포 태그를 「내가 고른 것」으로
      읽으면 저장할 때 그것을 떼려 든다.
    ⚠ 겹치면 **배포가 먼저**다(같은 태그 번호가 두 표에 있으면 한 줄로).
    """
    out, seen = [], set()
    for sc in ('SYS', 'USER'):
        try:
            rows = tags_of(db_path, target_type, target_id, lang, scope=sc)
        except Exception as e:
            print('[tags_read %s] %s' % (sc, e))
            continue
        for r in rows:
            if r[1] in seen:
                continue
            seen.add(r[1])
            out.append(r)
    return out


def save_links(db_path, target_type, target_id, chosen, scope='USER'):
    """선택한 것만 남긴다 — 빠진 것은 HIDE, 새 것은 INSERT(멱등).

    `chosen` = {(source, tag_id), …}. 반환 (더한 수, 뗀 수).
    `scope='SYS'` 면 **배포 표**에 쓴다(관리자). 2026-08-27."""
    ensure(db_path)
    if not target_id:
        return (0, 0)
    tid_i = int(target_id)
    add = rm = 0
    T_, PK_ = _tbl(scope), _pk(scope)
    lts = _lts_scoped(target_type, scope)
    ph = ','.join('?' * len(lts))
    with _conn(db_path) as conn:
        cur = {}
        for lid, lt, t, st in conn.execute(
                "SELECT %s, link_type, clicked_id, "
                "       COALESCE(record_status,'LIVE') "
                "FROM %s WHERE link_type IN (%s) AND target_id=?"
                % (PK_, T_, ph), lts + (tid_i,)):
            src = 'USER' if lt.startswith('UTAG_') else 'SYS'
            cur[(src, t)] = (lid, st)
        for key in chosen:
            if key in cur:
                if cur[key][1] != 'LIVE':
                    conn.execute("UPDATE %s SET record_status='LIVE' "
                                 "WHERE %s=?" % (T_, PK_), (cur[key][0],))
                    add += 1
            else:
                # ⚠ SYS 에는 개인 태그(UTAG)를 넣지 않는다 — 조용히 건너뛴다
                if scope == 'SYS' and (key[0] or '').upper() == 'USER':
                    continue
                conn.execute("INSERT INTO %s (link_type, clicked_id, target_id) "
                             "VALUES (?,?,?)" % T_,
                             (_lt(key[0], target_type), key[1], tid_i))
                add += 1
        for key, (lid, st) in cur.items():
            if key not in chosen and st == 'LIVE':
                conn.execute("UPDATE %s SET record_status='HIDE' "
                             "WHERE %s=?" % (T_, PK_), (lid,))
                rm += 1
        conn.commit()
    return (add, rm)


def _norm(s):
    """견줄 때 쓰는 꼴 — 공백·대소문자·가운뎃점을 지운다."""
    return ''.join(str(s or '').lower().split()).replace('·', '').replace('-', '')


def find_similar(rows, name, limit=6):
    """비슷한 말 → [(source, id, 이름, 축, 점수)] 높은 순.

    ★ **왜 필요한가** — 사용자가 「은혜로움」을 새로 만들면 이미 있는 「은혜」와
      갈라져, 나중에 같은 뜻을 두 태그로 찾게 된다. 만들기 전에 **먼저
      보여 준다**(2026-08-21 사용자 지시 「중복체크. 비슷한 말 보여주기」).
    ⚠ 외부 라이브러리를 쓰지 않는다 — `difflib` 은 표준이다."""
    import difflib
    q = _norm(name)
    if not q:
        return []
    out = []
    for row in rows:
        src, tid, nm, cat = row[0], row[1], row[2], row[3]
        full = row[4] if len(row) > 4 else nm
        # 비슷한 말은 **원어까지** 견준다 — 「아가페」로 쳐도 「사랑」이 잡힌다
        n = _norm(full)
        if not n:
            continue
        score = difflib.SequenceMatcher(None, q, n).ratio()
        if q in n or n in q or q in _norm(nm):   # 한쪽이 다른 쪽을 품으면
            score = max(score, 0.75)
        if score >= 0.45:
            out.append((src, tid, nm, cat, round(score, 3)))
    out.sort(key=lambda r: -r[4])
    return out[:limit]


def exact_tag(rows, name):
    """똑같은 이름이 이미 있으면 그것 → (source, id, 이름, 축). 없으면 None.

    ⚠ 표시 이름과 **원본(원어 병기)** 둘 다 견준다 — 「아가페」를 새로 만들려
      하면 이미 있는 「사랑 · 아하브 · 아가페」를 준다."""
    q = _norm(name)
    for row in rows:
        src, tid, nm, cat = row[0], row[1], row[2], row[3]
        full = row[4] if len(row) > 4 else nm
        if _norm(nm) == q or _norm(full) == q:
            return (src, tid, nm, cat)
    return None


def add_user_tag(db_path, name, category='THEME'):
    """내 태그를 만든다 → (source, tag_id). 같은 이름이 있으면 그것을 준다."""
    ensure(db_path)
    nm = ' '.join(str(name or '').split())
    if not nm:
        return None
    with _conn(db_path) as conn:
        r = conn.execute("SELECT user_tag_id FROM user_tag_asset "
                         "WHERE tag_name_sid=?", (nm,)).fetchone()
        if r:
            conn.execute("UPDATE user_tag_asset SET record_status='LIVE' "
                         "WHERE user_tag_id=?", (r[0],))
            conn.commit()
            return ('USER', r[0])
        conn.execute("INSERT INTO user_tag_asset (tag_name_sid, tag_category, "
                     "record_status) VALUES (?,?,'LIVE')", (nm, category))
        conn.commit()
        return ('USER', conn.execute("SELECT last_insert_rowid()").fetchone()[0])


# ── 고르는 팝업 ──────────────────────────────────────────────────────────
def new_tag_dialog(parent, db_path, rows, lang='KO'):
    """내 태그 만들기 — **중복은 막고 비슷한 말은 보여 준다**.

    돌려주는 것: (source, id) 또는 None.
    ⚠ 똑같은 이름이 있으면 **새로 만들지 않고 그것을 준다**(조용히 둘로 갈리지
      않게). 비슷한 말이 있으면 목록에서 골라 쓸 수 있다."""
    pop = tk.Toplevel(parent)
    pop.title(i18n.t('TAG_NEW', '내 태그 만들기'))
    pop.transient(parent.winfo_toplevel())
    try:
        import ui_theme
        ui_theme.adopt(pop)
    except Exception:
        pass
    res = {'key': None}

    tk.Label(pop, text=i18n.t('TAG_NEW_Q', '태그 이름'), anchor='w').pack(
        fill='x', padx=12, pady=(12, 2))
    var = tk.StringVar()
    ent = ttk.Entry(pop, textvariable=var, width=28)
    ent.pack(fill='x', padx=12)
    ent.focus_set()

    axis_var = tk.StringVar(value='THEME')
    af = tk.Frame(pop)
    af.pack(fill='x', padx=12, pady=(6, 2))
    tk.Label(af, text=i18n.t('TAG_AXIS', '축')).pack(side='left')
    ttk.Combobox(af, textvariable=axis_var, width=12, state='readonly',
                 values=[c for c, _k in T.CONCEPT_AXES]).pack(side='left', padx=6)

    msg = tk.Label(pop, text='', anchor='w', justify='left', fg='#7F8C8D')
    msg.pack(fill='x', padx=12, pady=(6, 0))
    box = tk.Frame(pop)
    box.pack(fill='both', expand=True, padx=12, pady=(2, 6))
    sim_tv = ttk.Treeview(box, columns=('name', 'axis'), show='headings', height=5)
    sim_tv.heading('name', text=i18n.t('TAG_SIMILAR', '비슷한 말'))
    sim_tv.heading('axis', text=i18n.t('TAG_AXIS', '축'))
    sim_tv.column('name', width=200, anchor='w')
    sim_tv.column('axis', width=90, anchor='center', stretch=False)
    sim_tv.pack(fill='both', expand=True)
    sim_map = {}

    def refresh(_e=None):
        nm = var.get()
        sim_tv.delete(*sim_tv.get_children())
        sim_map.clear()
        same = exact_tag(rows, nm)
        if same:
            msg.config(text=i18n.t('TAG_DUP', '「%s」 은(는) 이미 있습니다 — 그것을 씁니다.')
                       % same[2])
        else:
            sims = find_similar(rows, nm)
            msg.config(text=(i18n.t('TAG_SIMILAR_HINT',
                                    '비슷한 말이 있습니다. 새로 만들기 전에 살펴보세요.')
                             if sims else ''))
            for src, tid, s_nm, cat, _sc in sims:
                iid = '%s:%s' % (src, tid)
                sim_tv.insert('', 'end', iid=iid,
                              values=(s_nm + ('' if src == 'SYS' else ' ◈'),
                                      dict(T.ALL_AXES).get(cat, cat or '')))
                sim_map[iid] = (src, tid)
    ent.bind('<KeyRelease>', refresh)

    def use_similar():
        sel = sim_tv.selection()
        if not sel:
            return
        res['key'] = sim_map.get(sel[0])
        pop.destroy()
    sim_tv.bind('<Double-1>', lambda _e: use_similar())

    def create():
        nm = var.get().strip()
        if not nm:
            return
        same = exact_tag(rows, nm)
        if same:                       # 중복 — 새로 만들지 않고 그것을 쓴다
            res['key'] = (same[0], same[1])
            pop.destroy()
            return
        res['key'] = add_user_tag(db_path, nm, axis_var.get())
        pop.destroy()

    bar = tk.Frame(pop)
    bar.pack(fill='x', padx=12, pady=(0, 12))
    tk.Button(bar, text=i18n.t('TAG_USE_SIMILAR', '선택한 것 쓰기'), command=use_similar,
              **_SMALL_BTN).pack(side='left')
    tk.Button(bar, text=i18n.t('COMMON_CANCEL', '취소'), command=pop.destroy,
              **_SMALL_BTN).pack(side='right')
    tk.Button(bar, text=i18n.t('TAG_CREATE', '새로 만들기'), command=create,
              **_SMALL_BTN).pack(side='right', padx=4)
    ent.bind('<Return>', lambda _e: create())

    pop.grab_set()
    parent.wait_window(pop)
    return res['key']


def after_save(parent, db_path, target_type, target_id, lang='KO'):
    """★ **저장 직후 태그 입력** (2026-08-21 사용자 지시 — 「저장되자마자
    태그 입력 화면을 보여주고, [입력 안 함] 이면 그대로 종료」).

    이미 붙어 있던 태그를 들고 열리므로 수정에도 그대로 쓴다.
    반환 (더한 수, 뗀 수) — 건너뛰면 (0, 0)."""
    cur = {(s, t) for s, t, _n, _c in tags_of(db_path, target_type, target_id, lang)}
    got = pick(parent, db_path, cur, lang, mode='SAVE')
    if got is None:
        return (0, 0)
    return save_links(db_path, target_type, target_id, got)


def pick(parent, db_path, chosen=None, lang='KO', mode='EDIT', scope='USER',
         rows_provider=None):
    """태그 선택하기 팝업. 선택한 집합 {(source, id)} 을 주고, 건너뛰면 None.

    mode='SAVE' 면 저장 직후 자리라 단추가 **[입력 안 함] / [태그 저장]** 이다.

    ★★ `scope='SYS'`(관리자)면 **내가 만든 태그를 아예 안 보인다**
      (2026-08-27 사용자 확정 — 「**관리자는 사용자가 입력한 태그를 볼 수도
      없고 봐서도 안 된다.** 사용자는 sys 태그 + user 태그 모두 사용할 수
      있다」). 개인 태그는 그 사람 PC 에만 있으므로 배포 표에 실을 수도 없다.
    ★ `rows_provider` — 후보 목록을 밖에서 줄 때 (2026-09-01 0.txt 3번).
      152차 통합 수술로 배포 태그가 0 이 되어, **이름만 필요한 자리**(지도
      분류 태그 = 자유 글)는 용어(엔티티) 목록을 넣어야 고를 것이 생긴다.
      ⚠ 태그를 **연결하는** 여섯 화면은 이 인자를 쓰지 말 것 — 고른 키가
        `save_links` 로 가는 자리에 ENTI 키가 섞이면 조용히 유실된다.
    """
    ensure(db_path)
    sel = set(chosen or ())
    _provider = rows_provider or (lambda: all_tags(db_path, lang))
    rows = list(_provider())
    # ★ **용어사전 등록 태그** (2026-08-27 사용자 지시 「태그 목록에서 용어사전
    #   등록된 것을 목록에 표시. 필터링 추가」) — 태그 509개 중 451개가
    #   주요용어를 품는다(`tag_kind='ENTITY'`). 어떤 태그가 용어인지 목록에서
    #   보이고, [용어사전] 단추로 걸러진다.
    try:
        with _conn(db_path) as _c:
            _ent_tags = {r[0] for r in _c.execute(
                "SELECT sys_tag_id FROM sys_tag_asset "
                " WHERE tag_kind='ENTITY' AND entity_id IS NOT NULL")}
    except Exception:
        _ent_tags = set()
    if scope == 'SYS':
        # ⚠ 목록만이 아니라 **이미 고른 것**에서도 뺀다 — 안 빼면 화면에는
        #   안 보이는데 저장 때 딸려 들어간다(조용한 잘못된 쓰기).
        rows = [r for r in rows if (r[0] or '').upper() != 'USER']
        sel = {k for k in sel if (k[0] or '').upper() != 'USER'}
    # 축은 **열 때 읽는다** — 승격으로 축이 늘어도 코드를 안 고친다
    axes = axes_for(db_path, lang, only_used=True)
    axmap = dict(axes)
    result = {'ok': False}

    pop = tk.Toplevel(parent)
    pop.title(i18n.t('TAG_PICK_TITLE', '태그 선택하기'))
    pop.transient(parent.winfo_toplevel())
    # ⚠⚠ **`adopt` 는 맨 끝에서 한 번**(아래) — 여기서 부르면 그 뒤에 붙는
    #   위젯이 안 칠해지고, `adopt` 는 **멱등**이라 나중 호출이 그냥 돌아간다.
    #   그래서 「배경이 흰색 같은 것이 어른거린다」가 됐다(2026-08-21 실측).

    # ── ① 맨 위 = **지금 붙어 있는 태그** (2026-08-21 사용자 지시) ──────
    #    무엇이 이미 들어 있는지 목록을 훑지 않고 한눈에 본다. ✕ 로 바로 뗀다.
    head = tk.Frame(pop)
    head.pack(fill='x', padx=10, pady=(10, 2))
    tk.Label(head, text=i18n.t('TAG_CURRENT', '연결된 태그'),
             fg='#7F8C8D').pack(side='left', padx=(0, 6))
    chip_box = tk.Frame(head)
    chip_box.pack(side='left', fill='x', expand=True)

    top = tk.Frame(pop)
    top.pack(fill='x', padx=10, pady=(6, 4))
    axis_var = tk.StringVar(value='')
    q_var = tk.StringVar()
    # 찾기 칸은 **넓게** — 단추만 크고 입력창이 좁으면 균형이 안 맞는다(사용자).
    srow = tk.Frame(pop)
    srow.pack(fill='x', padx=10, pady=(0, 4))
    tk.Label(srow, text=i18n.t('COMMON_SEARCH', '검색')).pack(side='left', padx=(0, 6))

    body = tk.Frame(pop)
    body.pack(fill='both', expand=True, padx=10)
    tv = ttk.Treeview(body, columns=('mark', 'name', 'axis'), show='headings', height=14)
    tv.heading('mark', text='')
    tv.heading('name', text=i18n.t('COMMON_NAME', '이름'))
    tv.heading('axis', text=i18n.t('TAG_AXIS', '축'))
    tv.column('mark', width=34, anchor='center', stretch=False)
    tv.column('name', width=260, anchor='w')
    tv.column('axis', width=90, anchor='center', stretch=False)
    sb = ttk.Scrollbar(body, command=tv.yview)
    tv.configure(yscrollcommand=sb.set)
    sb.pack(side='right', fill='y')
    tv.pack(side='left', fill='both', expand=True)
    iid_key = {}

    def axis_label(code):
        return axmap.get(code, code or '')

    def name_of(key):
        for row in rows:
            if (row[0], row[1]) == key:
                return row[2]
        return '#%s' % key[1]

    def draw_chips():
        """맨 위 칩 줄 — 지금 선택한 것."""
        for w in chip_box.winfo_children():
            w.destroy()
        if not sel:
            tk.Label(chip_box, text=i18n.t('TAG_NONE', '(태그 없음)'),
                     fg='#95A5A6').pack(side='left')
            return
        # ★ **칩은 단추가 아니라 글자다** (2026-08-21 사용자 지시 — 「버튼 방식으로
        #   하지 마라. 텍스트 라벨 + 파스텔 배경. 그래야 분류 버튼과 혼동이 없다」).
        #   ⚠ 위 축 단추와 모양이 같으면 「눌러서 거르는 것」으로 읽힌다.
        for key in sorted(sel, key=name_of):
            pastel = _PASTEL_MINE if key[0] == 'USER' else _PASTEL_SYS
            chip = tk.Frame(chip_box, bg=pastel)
            chip.pack(side='left', padx=2, pady=1)
            tk.Label(chip, text=name_of(key), bg=pastel, fg='#34495E',
                     padx=5, pady=1).pack(side='left')
            x = tk.Label(chip, text='✕', bg=pastel, fg='#7F8C8D',
                         padx=3, cursor='hand2')
            x.pack(side='left')
            x.bind('<Button-1>', lambda _e, k=key: drop(k))

    def fill():
        tv.delete(*tv.get_children())
        # ⚠ 표식 태그 색은 `ui_theme.paint` 가 못 본다 — **그릴 때마다**(§36-5b)
        OM.configure_tree(tv)
        iid_key.clear()
        ax = axis_var.get()
        q = (q_var.get() or '').strip().lower()
        for row in rows:
            src, tid, nm, cat = row[0], row[1], row[2], row[3]
            full = row[4] if len(row) > 4 else nm
            # ★ **내 태그를 따로 가른다** (사용자 지시) — 축 단추 [내 태그] 와
            #   목록의 「내 태그」 표시. 앞서 쓰던 ◈ 한 글자로는 눈에 안 띄었다.
            if ax == '_USER_':
                if src != 'USER':
                    continue
            elif ax == '_ENTITY_':
                # 용어사전 등록 태그만(sys 엔티티 태그)
                if src != 'SYS' or tid not in _ent_tags:
                    continue
            elif ax and (cat != ax or src != 'SYS'):
                continue
            # 검색은 **원어까지** — 「아가페」로 쳐도 「사랑」이 나온다
            if q and q not in (nm or '').lower() and q not in (full or '').lower():
                continue
            iid = '%s:%s' % (src, tid)
            # ★ **N/E/H 표식**(2026-08-26 — 덮개가 도는 모든 화면에 부착).
            #   내 태그 = N · 이름을 고친 sys 태그 = E. 숨긴 것은 `all_tags` 가
            #   이미 뺐으므로 H 는 안 나온다(읽는 목록이다).
            mk = row[5] if len(row) > 5 else ''
            tv.insert('', 'end', iid=iid,
                      values=('☑' if (src, tid) in sel else '☐',
                              OM.prefix(nm, mk),
                              # ★ 용어사전 등록 태그는 축 칸에 그것을 보인다
                              #   (2026-08-27 사용자 지시 — 「목록에 표시」)
                              (i18n.t('TAG_ENTITY', '용어사전')
                               if (src == 'SYS' and tid in _ent_tags
                                   and not axis_label(cat))
                               else ('%s · %s' % (axis_label(cat),
                                                  i18n.t('TAG_ENTITY', '용어사전'))
                                     if (src == 'SYS' and tid in _ent_tags)
                                     else axis_label(cat)))
                              if src == 'SYS'
                              else i18n.t('TAG_MINE', '내 태그')),
                      tags=((OM.tag_name(mk),) if mk
                            else (('mine',) if src == 'USER' else ('sysrow',))))
            iid_key[iid] = (src, tid)

    def sync():
        fill()
        draw_chips()
        cnt.config(text=i18n.t('TAG_PICK_N', '선택한 태그 %d개') % len(sel))

    def flip(key):
        if key in sel:
            sel.discard(key)
        else:
            sel.add(key)
        sync()

    def drop(key):
        sel.discard(key)
        sync()

    def on_click(e):
        """★ **체크 칸을 눌러 넣고 뺀다** (사용자 지시 — [넣기/빼기] 단추 폐지).

        ⚠ `identify_column` 은 셀 경계 ±4px 에서 옆 칸을 준다(태그 관리 화면에서
          겪은 것과 같다) — 그래서 **첫 칸일 때만** 토글하고 나머지는 그냥 선택."""
        if tv.identify_region(e.x, e.y) != 'cell':
            return
        iid = tv.identify_row(e.y)
        k = iid_key.get(iid)
        if not k:
            return
        if tv.identify_column(e.x) == '#1':
            flip(k)
            return 'break'

    # 축 단추 — [전체] + 6축 + [내 태그]
    def set_axis(a):
        axis_var.set(a)
        for code, b in ax_btns.items():
            on = (code == a)
            # ⚠ **기본은 올라온 모양(raised), 고른 것만 눌린 모양(sunken)** —
            #   앱의 갈래 단추와 같은 규약이다(2026-08-21 사용자 지적: 「왜 항상
            #   밑으로 들어간 모양을 기본값으로 두는가」. 이유 없었다 — 습관).
            b.config(relief='sunken' if on else 'raised')
        fill()

    ax_btns = {}
    # 축 라벨은 `TAGCAT_*`(db_tag_system 이 시드한 것)를 그대로 읽는다.
    # ⚠ **두 줄로 접는다** — 축이 16개라 한 줄에 늘어놓으면 팝업이 1,089px 이
    #   된다(실측). 관리자 태그 관리도 두 줄이다.
    _all = ([('', i18n.t('COMMON_ALL', '전체'))] + list(axes)
            + [('_ENTITY_', i18n.t('TAG_ENTITY', '용어사전'))]
            + ([('_USER_', i18n.t('TAG_MINE', '내 태그'))]
               if scope != 'SYS' else []))
    _per = -(-len(_all) // 2)          # 위아래로 반씩
    for i, (code, ko) in enumerate(_all):
        # ⚠ **작게** (2026-08-21 사용자 「무지막지한 무기들 같다」) — 도서읽기
        #   동작 줄과 같은 규격. 태그는 곁다리 기능이라 커야 할 이유가 없다.
        b = tk.Button(top, text=ko, **_FILT_BTN,
                      command=lambda a=code: set_axis(a))
        b.grid(row=i // _per, column=i % _per, padx=1, pady=1, sticky='w')
        # ★ 작게 두되 **통합 폰트를 따라간다**(§36) — 글꼴 이름·크기를 박지
        #   않고 한 단계만 줄인다. 박으면 폰트 설정이 이 창만 비껴간다.
        try:
            import theme_font
            theme_font.register(b, db_path, 'ui', size_delta=-2)
        except Exception:
            pass
        ax_btns[code] = b
    ent = ttk.Entry(srow, textvariable=q_var)
    ent.pack(side='left', fill='x', expand=True)
    ent.bind('<KeyRelease>', lambda _e: fill())
    tv.tag_configure('mine', foreground='#7D6608')
    tv.bind('<Button-1>', on_click, add='+')

    # 더블클릭·Enter 로도 넣고 뺀다(체크 칸 클릭이 기본)
    tv.bind('<Double-1>', lambda _e: [flip(iid_key[i]) for i in tv.selection()
                                      if i in iid_key])
    tv.bind('<Return>', lambda _e: [flip(iid_key[i]) for i in tv.selection()
                                    if i in iid_key])

    # ★★ **단추 줄은 목록 *위*, 검색창 바로 아래** (2026-08-21 사용자 지시
    #   「중요한 버튼이 바닥에 배치되어 있다. **화면을 줄이면 버튼이 사라진다.**
    #    어렵다면 버튼을 검색창 아래에 배치하여라」).
    #   ⚠ expand 하는 목록 **뒤에** pack 한 바닥 줄은 창을 줄이면 남는 자리가
    #     0 이라 통째로 사라진다(§0 「버튼은 항상 상단」 · 문서에 네 번째).
    #   ⇒ `before=body` 로 순서를 당긴다. 그냥 다시 pack 하면 맨 아래로 간다.
    bar = tk.Frame(pop)
    bar.pack(fill='x', padx=10, pady=(0, 6), before=body)
    cnt = tk.Label(bar, text=i18n.t('TAG_PICK_N', '선택한 태그 %d개') % len(sel))
    cnt.pack(side='left')

    def new_tag():
        key = new_tag_dialog(pop, db_path, rows, lang)
        if not key:
            return
        if not any(r[0] == key[0] and r[1] == key[1] for r in rows):
            rows[:] = _provider()      # 새로 만든 것을 목록에 들인다
        sel.add(key)
        sync()
    # ★ **동작 단추는 표준 크기로** (2026-08-21 사용자 「버튼 자체의 크기도
    #   너무 작다」). 작게 둔 것은 **축 필터**뿐이다 — 그건 곁다리가 맞다.
    tk.Button(bar, text=i18n.t('TAG_NEW', '내 태그 만들기'), command=new_tag,
              **_ACT_BTN).pack(side='left', padx=(10, 0))

    # ── 태그 덮개 입구 (2026-08-26 — 이름 수정·숨김. 저장은 user db 뿐) ──
    def _sel_sys_tag():
        for i in tv.selection():
            k = iid_key.get(i)
            if k and k[0] == 'SYS':
                return k[1]
        return None

    def rename_tag():
        from tkinter import messagebox
        tid = _sel_sys_tag()
        if tid is None:
            messagebox.showinfo(i18n.t('TAG_PICK_TITLE', '태그 선택하기'),
                                i18n.t('TAG_OV_PICK1', '기본 태그를 먼저 '
                                       '선택하세요(내 태그는 그대로 고쳐 쓰면 '
                                       '됩니다).'), parent=pop)
            return
        cur = next((r[2] for r in rows if r[0] == 'SYS' and r[1] == tid), '')
        new = simpledialog.askstring(
            i18n.t('TAG_OV_RENAME', '태그 이름 수정하기'),
            i18n.t('TAG_OV_RENAME_Q', '내가 쓸 이름(기본 자산은 안 바뀝니다):'),
            initialvalue=cur, parent=pop)
        if not new or not new.strip():
            return
        import overlay
        with _conn(db_path) as conn:
            row = T.tag_overlay_row(conn, tid)
            if row:
                row['tag_name_sid'] = new.strip()
                overlay.save(conn, overlay.TagOverlay(), row)
        rows[:] = _provider()
        sync()

    def hide_tag():
        from tkinter import messagebox
        tid = _sel_sys_tag()
        if tid is None:
            messagebox.showinfo(i18n.t('TAG_PICK_TITLE', '태그 선택하기'),
                                i18n.t('TAG_OV_PICK1', '기본 태그를 먼저 '
                                       '선택하세요(내 태그는 그대로 고쳐 쓰면 '
                                       '됩니다).'), parent=pop)
            return
        if not messagebox.askyesno(
                i18n.t('TAG_OV_HIDE', '태그 숨기기'),
                i18n.t('TAG_OV_HIDE_Q', '이 태그를 내 화면에서 숨깁니다. '
                       '되돌리기는 설정 ▸ 휴지통에서. 계속할까요?'),
                parent=pop):
            return
        import overlay
        with _conn(db_path) as conn:
            row = T.tag_overlay_row(conn, tid)
            if row:
                overlay.hide(conn, overlay.TagOverlay(), row)
        sel.discard(('SYS', tid))
        rows[:] = _provider()
        sync()

    tk.Button(bar, text=i18n.t('TAG_OV_RENAME', '태그 이름 수정하기'),
              command=rename_tag, **_ACT_BTN).pack(side='left', padx=(6, 0))
    tk.Button(bar, text=i18n.t('TAG_OV_HIDE', '태그 숨기기'),
              command=hide_tag, **_ACT_BTN).pack(side='left', padx=(6, 0))

    def ok():
        result['ok'] = True
        pop.destroy()
    # ★ 두 자리 모두 **「태그연결」** 이라고 말한다 (2026-08-21 사용자 지시).
    #   「취소·확인」은 글 저장까지 취소되는 것처럼 읽히고, 「입력」은 글을
    #   쓰는 것과 헷갈린다 — 여기서 하는 일은 **연결**이다.
    ok_txt = i18n.t('TAG_SAVE', '태그연결 저장')
    no_txt = i18n.t('TAG_SKIP', '태그연결 안함')
    tk.Button(bar, text=ok_txt, command=ok, **_ACT_BTN).pack(side='right')
    tk.Button(bar, text=no_txt, command=pop.destroy,
              **_ACT_BTN).pack(side='right', padx=4)

    set_axis('')
    draw_chips()
    # ⚠ 테마·글꼴은 **다 지은 뒤** — 창을 만들자마자 `adopt` 하면 그 뒤에 붙는
    #   위젯이 통째로 흰 바탕으로 남는다(2026-08-21 사용자 신고).
    try:
        import ui_theme
        ui_theme.adopt(pop)
    except Exception:
        pass
    pop.minsize(560, 380)
    pop.grab_set()
    parent.wait_window(pop)
    return sel if result['ok'] else None


# ── 칩 줄 ────────────────────────────────────────────────────────────────
class TagChips(tk.Frame):
    """선택한 태그를 보여 주는 한 줄 + `[+ 태그]`.

    화면은 `chosen` 을 읽어 저장 뒤 `save_links` 로 넘기면 된다."""

    def __init__(self, parent, db_path, lang_getter=None, **kw):
        super().__init__(parent, **kw)
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.chosen = set()
        self._names = {}
        self._btn = tk.Button(self, text=i18n.t('TAG_ADD', '+ 태그'),
                              command=self._open, **_SMALL_BTN)
        self._btn.pack(side='left', padx=(0, 6))
        self._box = tk.Frame(self)
        self._box.pack(side='left', fill='x', expand=True)
        self._redraw()

    # 밖에서 쓰는 것 ------------------------------------------------------
    def load(self, target_type, target_id):
        """이미 붙어 있는 태그를 불러온다(수정 화면)."""
        rows = tags_of(self.db_path, target_type, target_id, self._lang())
        self.chosen = {(s, t) for s, t, _n, _c in rows}
        self._names = {(s, t): n for s, t, n, _c in rows}
        self._redraw()

    def clear(self):
        self.chosen = set()
        self._redraw()

    def save(self, target_type, target_id):
        return save_links(self.db_path, target_type, target_id, self.chosen)

    # 안쪽 ---------------------------------------------------------------
    def _lang(self):
        try:
            return (self.lang_getter() or 'KO').upper()
        except Exception:
            return 'KO'

    def _open(self):
        got = pick(self, self.db_path, self.chosen, self._lang())
        if got is None:
            return
        self.chosen = set(got)
        self._names = {}
        self._redraw()

    def _redraw(self):
        for w in self._box.winfo_children():
            w.destroy()
        if not self.chosen:
            tk.Label(self._box, text=i18n.t('TAG_NONE', '(태그 없음)'),
                     fg='#95A5A6').pack(side='left')
            return
        if len(self._names) < len(self.chosen):
            self._names = {(s, t): n for s, t, n, _c, _f, *_m
                           in all_tags(self.db_path, self._lang())}
        for key in sorted(self.chosen, key=lambda k: self._names.get(k, '')):
            nm = self._names.get(key, '#%s' % key[1])
            chip = tk.Frame(self._box, bd=1, relief='raised')
            chip.pack(side='left', padx=2, pady=1)
            tk.Label(chip, text=nm, padx=4).pack(side='left')
            tk.Button(chip, text='✕', bd=0, padx=2,
                      command=lambda k=key: self._drop(k)).pack(side='left')

    def _drop(self, key):
        self.chosen.discard(key)
        self._redraw()


# ── 자가 검증 ────────────────────────────────────────────────────────────
def _selftest():
    ok = True

    def chk(name, cond):
        nonlocal ok
        print(('  PASS ' if cond else '  FAIL ') + name)
        ok = ok and bool(cond)

    print('tag_picker selftest')
    ensure(None)
    rows = all_tags(None)
    # ★ 2026-09-01 통합 수술 — 배포 태그는 용어로 흡수됐다. 목록 = 배포 순수
    #   태그(0) + 내 태그. **개수를 못 박지 않고 DB 와 견준다**(§0-5).
    with _conn(None) as _c0:
        _npure = _c0.execute(
            "SELECT COUNT(*) FROM sys_tag_asset WHERE entity_id IS NULL"
            " AND COALESCE(record_status,'LIVE')='LIVE'").fetchone()[0]
    chk('목록 = 배포 순수 태그 + 내 태그 (%d)' % len(rows),
        sum(1 for r in rows if r[0] == 'SYS') <= _npure + 451)
    chk('여섯 칸(표시·검색·표식 분리)', all(len(r) == 6 for r in rows))
    # ★ 표식 — 덮개가 없으면 빈칸, 내 태그면 N (2026-08-26)
    import overlay_mark as _OM
    chk('sys 태그 표식은 빈칸이거나 E',
        all(r[5] in ('', _OM.EDIT) for r in rows if r[0] == 'SYS'))
    chk('내 태그 표식은 N',
        all(r[5] == _OM.NEW for r in rows if r[0] == 'USER'))
    _long = [r for r in rows if '·' in (r[4] or '')]
    chk('원어 병기는 짧게 표시', all('·' not in r[2] for r in _long) if _long else True)
    # ⚠ 축 개수를 못 박지 않는다 — 승격이 늘면 축도 는다(2026-08-21).
    #   대신 **쓰이는 축이 정의된 목록 안에 있는지**를 본다.
    used = {r[3] for r in rows if r[0] == 'SYS'}
    chk('쓰는 축이 모두 정의돼 있다', used <= {c for c, _n in T.ALL_AXES})
    # ★ 2026-09-18 — 축 = **주요용어 유형 하나**다(개념 축 여섯 폐기).
    #   개수를 못 박지 않고 **주요용어 화면의 목록과 같은가**를 잰다 —
    #   유형이 늘면 저절로 따라오고, 갈리면 그 자리에서 잡힌다.
    chk('축 = 주요용어 유형 그대로', T.ALL_AXES == T.ENTITY_AXES)
    try:
        import entity_browser as _EBx
        chk('주요용어 유형 목록과 같다',
            {c for c, _n in T.ALL_AXES} == set(_EBx._TYPE_CODES))
    except Exception as _e:
        print('   (유형 목록 확인 실패: %s)' % _e)
        chk('주요용어 유형 목록과 같다', False)
    au = axes_for(None, 'KO', only_used=True)
    # ⚠ 배포 태그가 0이면 `axes_for` 가 전체 목록으로 폴백한다 — 그때는 비교 무의미
    chk('빈 축은 안 준다', ({c for c, _n in au} == used) or not used)
    chk('축 이름이 있다', all(n for _c, n in au))
    chk('이름이 있다', all(r[2] for r in rows[:20]))

    TT, TID = '__SELFTEST__', 999999
    # ★★★ **재료가 없으면 시험이 만들어서 잰다**(§0-5 · 2026-09-18).
    #   ⚠ 그전에는 `rows[:3]` — **DB 에 태그가 세 개는 있다**를 전제해서,
    #     태그 층을 걷자 그날부터 넷이 FAIL 이었다(`tag_derive` 가 열이레
    #     빨갛던 그 자리 §264차 ⑤). 재는 것은 「지금 태그가 있나」가 아니라
    #     **「연결 문이 도는가」**다.
    _made = []
    _keys = [(r[0], r[1]) for r in rows[:3]]
    while len(_keys) < 3:
        _nm = '__selftest_link%d__' % (len(_keys) + 1)
        _k = add_user_tag(None, _nm, 'PHASE')
        _made.append(_nm)
        if _k:
            _keys.append(_k)
        else:
            break
    keys = set(_keys)
    a, r = save_links(None, TT, TID, keys)
    chk('세 개 연결', a == 3 and r == 0)
    chk('되읽기', {(s, t) for s, t, _n, _c in tags_of(None, TT, TID)} == keys)
    # 하나 빼기
    less = set(list(keys)[:2])
    a2, r2 = save_links(None, TT, TID, less)
    chk('하나 뗀다', a2 == 0 and r2 == 1)
    chk('되읽기 2개', len(tags_of(None, TT, TID)) == 2)
    # 되살리기 (HIDE 행 재사용 — 행이 늘지 않아야)
    a3, _r3 = save_links(None, TT, TID, keys)
    with _conn(None) as conn:
        n = conn.execute("SELECT COUNT(*) FROM %s WHERE link_type IN (?,?)"
                         % LINK_TBL, _lts(TT)).fetchone()[0]
    chk('되살리기(행 안 늘어남)', a3 == 1 and n == 3)

    # 내 태그
    key = add_user_tag(None, '__selftest_tag__')
    chk('내 태그 생성', key and key[0] == 'USER')
    chk('같은 이름은 하나', add_user_tag(None, '__selftest_tag__') == key)

    # 중복 판정 · 비슷한 말
    rows2 = all_tags(None)
    nm0 = rows2[0][2]
    chk('똑같은 이름 잡기', exact_tag(rows2, nm0) is not None)
    chk('공백·대소문자 무시', exact_tag(rows2, ' ' + nm0.upper() + ' ') is not None)
    chk('없는 이름', exact_tag(rows2, '__없는태그__') is None)
    sim = find_similar(rows2, nm0)
    chk('비슷한 말에 자기 자신', any(n == nm0 for _s, _t, n, _c, _sc in sim))
    chk('한 글자만 달라도 걸린다', bool(find_similar(rows2, nm0 + '들')))
    chk('전혀 다른 말은 조용', not find_similar(rows2, 'zzqqxx'))

    # 정리
    with _conn(None) as conn:
        conn.execute("DELETE FROM %s WHERE link_type IN (?,?)"
                     % LINK_TBL, _lts(TT))
        conn.execute("DELETE FROM user_tag_asset WHERE tag_name_sid='__selftest_tag__'")
        # ⚠ **번호로 좁혀 제 것만** 지운다 — 남의 태그를 지운 청소가 있었다(§241차 ㈱).
        for _nm in _made:
            conn.execute("DELETE FROM user_tag_asset WHERE tag_name_sid=?", (_nm,))
        conn.commit()
        # ⚠ 2026-08-25 정정 — 옛 표에서 세고 있었다(늘 0이라 통과했다).
        #   잔재는 **실제로 쓰는 통합 표**에서 센다.
        left = conn.execute("SELECT COUNT(*) FROM %s WHERE link_type IN (?,?)"
                            % LINK_TBL, _lts(TT)).fetchone()[0]
        left2 = conn.execute("SELECT COUNT(*) FROM user_tag_asset "
                             "WHERE tag_name_sid='__selftest_tag__'").fetchone()[0]
    chk('잔재 없음', left == 0 and left2 == 0)
    print('RESULT:', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        raise SystemExit(_selftest())
    print(__doc__)
