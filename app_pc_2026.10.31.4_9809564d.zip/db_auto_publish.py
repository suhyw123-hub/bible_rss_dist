# -*- coding: utf-8 -*-
"""db_auto_publish.py — **자동 배포 한 바퀴**: 점검 → 최신 콘텐츠 → 영상 연결 델타 →
올리기 → 기록 (2026-09-29 293차 신설 · 영구).

★★★ 왜 (사용자 「매일 일정 시간에 자동으로 링크팩을 "점검하기" 후에 "델타 만들기"
  수행한 후에 자동으로 배포 올리기 … **점검결과 오류가 없어야** 할 것이다. …
  **자동배포 기능을 모아서 모니터링하는 화면**도 필요할 것이다」).
  · 돌리는 자리 = **독립 작업** `BibleMatrix_AutoDeploy`(작업 스케줄러 · `--run`) 와
    배포 센터 ▸ **자동 배포** 탭의 [지금 실행].
    ⚠⚠ **수집 작업 끝에 즉시 돌리지 않는다**(사용자 「6시간 정도 시차를 두어야 한다.
      관리자가 수작업 심사해야 하기 때문이다」). 배포 시각은 그 탭에서 정한다 —
      권장 = 수집 시각 + `GAP_HOURS`(6).
  · **점검이 막으면 아무것도 올리지 않는다** — 막은 까닭을 기록에 남긴다.
  · 매 바퀴가 `sys_auto_deploy_log`(LOCAL · 관리자 PC 만) 에 한 줄 — 화면이 그것을
    보인다. 「돌았는가 · 왜 안 올렸는가 · 무엇을 올렸는가」를 기록 없이는 알 수 없다.

★ 점검 잣대(`check`) — **막는 것**과 **알리는 것**을 가른다(§0-5 `db_study_gate` 와
  같은 문법):
  | 잣대 | 막나 | 왜 |
  |---|---|---|
  | 자동 배포 스위치 | 막음 | 꺼져 있으면 사람이 끈 것이다 |
  | 올릴 서버 | 막음 | 없으면 올릴 곳이 없다 |
  | 승인된 영상 주소 0 | 막음 | 빈 팩은 받는 쪽 팩을 비운다 |
  | 전체본을 한 번도 안 만듦 | 막음 | 첫 전체본은 **사람이** 만든다(받는 쪽이 통째로 갈아 끼운다) |
  | 삭제(묘비)가 승인분의 절반 넘음 | 막음 | 스냅샷이 깨진 징후 — 사용자 화면이 통째로 빈다 |
  | 지난 바퀴 실패 | 알림 | 막지 않는다 — 이번에 되면 그만이다 |

    python db_auto_publish.py --selftest   (의무)
    python db_auto_publish.py --check
    python db_auto_publish.py --run         (스위치가 켜져 있어야 올린다)
    python db_auto_publish.py --status
"""
import io
import json
import os
import sys
import time

import appdb

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bible_master.db')
TABLE = 'sys_auto_deploy_log'
DDL = ("CREATE TABLE IF NOT EXISTS %s("
       " run_id INTEGER PRIMARY KEY AUTOINCREMENT,"
       " ts TEXT NOT NULL, trigger TEXT, status TEXT NOT NULL,"
       " check_json TEXT, kinds_json TEXT,"
       " link_seq INTEGER, link_files TEXT, message TEXT)" % TABLE)

#: 결과 상태 → 사람 말. **화면이 이 표를 읽는다** — 코드를 화면에 적지 않는다.
STATUS_LABEL = {
    'OK':          '올렸다',
    'OK_NOCHANGE': '바뀐 것 없음',
    'SKIP_OFF':    '스위치 꺼짐',
    'FAIL_CHECK':  '점검에 막힘',
    'FAIL_UPLOAD': '올리기 실패',
    'ERROR':       '오류',
}
#: 삭제(묘비)가 이 비율을 넘으면 사람이 본다 — 스냅샷이 깨진 징후.
DEL_RATIO = 0.5
DEL_MIN = 100

#: 작업 스케줄러 이름 — 자동 배포(독립) · 수집(권장 시각의 기준)
TASK_NAME = 'BibleMatrix_AutoDeploy'
COLLECT_TASK = 'BibleMatrix_ChannelCollect'
#: 수집 뒤 관리자가 수작업 심사할 시간(시) — 배포 권장 시각 = 수집 시각 + 이만큼
GAP_HOURS = 6
#: 수집 작업이 등록돼 있지 않을 때의 권장 시각
FALLBACK_TIME = (18, 0)


def collect_time():
    """수집 작업의 등록 시각 → (hh, mm) · 없으면 None."""
    try:
        import task_sched as TS
        rd = TS.read(COLLECT_TASK)
        return (int(rd['hh']), int(rd['mm'])) if rd else None
    except Exception:
        return None


def suggest_time(collect=None):
    """권장 배포 시각 = 수집 시각 + GAP_HOURS(자정을 넘으면 감는다) · 수집이 없으면 18:00.

    ⚠ **수집 시각을 그대로 쓰지 않는다** — 그 사이가 관리자의 심사 시간이다.
    """
    ct = collect if collect is not None else collect_time()
    if not ct:
        return FALLBACK_TIME
    hh, mm = ct
    return ((hh + GAP_HOURS) % 24, mm)


def task_state():
    """자동 배포 작업 → {'registered', 'hh', 'mm', 'days', 'last_run', 'next_run', 'result_text'}."""
    out = {'registered': False, 'hh': None, 'mm': None, 'days': None,
           'last_run': '', 'next_run': '', 'result_text': ''}
    try:
        import task_sched as TS
        rd = TS.read(TASK_NAME)
        if rd:
            out.update(registered=True, hh=int(rd['hh']), mm=int(rd['mm']),
                       days=rd.get('days'))
            inf = TS.info(TASK_NAME) or {}
            out.update(last_run=inf.get('last_run') or '',
                       next_run=inf.get('next_run') or '',
                       result_text=inf.get('result_text') or '')
    except Exception as e:                                   # noqa: BLE001
        out['error'] = str(e)[:80]
    return out


def task_xml(hh, mm, days=None):
    """등록 XML — 명령은 **이 파일 `--run`**(파이썬은 지금 인터프리터)."""
    import task_sched as TS
    exe = sys.executable
    pw = os.path.join(os.path.dirname(exe), 'pythonw.exe')
    py = '"%s"' % (pw if os.path.exists(pw) else exe)   # 창 없이(stdout 은 위 main 이 기록 파일로)
    args = '"%s" --run' % os.path.abspath(__file__)
    return TS.build_xml(py, args, hh, mm, days,
                        description='Hagah Dabar — 자동 배포(점검→델타→올리기)')


def task_register(hh, mm, days=None):
    """배포 시각으로 작업을 등록한다(있으면 덮어쓴다) → (ok, 메시지)."""
    import task_sched as TS
    hh, mm = int(hh), int(mm)
    if not (0 <= hh <= 23 and 0 <= mm <= 59):
        return False, '시각이 범위를 벗어났다: %02d:%02d' % (hh, mm)
    return TS.register(TASK_NAME, task_xml(hh, mm, days))


def task_set_enabled(on):
    import task_sched as TS
    return TS.set_enabled(TASK_NAME, bool(on))


def ensure(conn):
    conn.execute(DDL)
    conn.commit()


def _servers(servers):
    import rss_publish as RP
    ss = servers if servers is not None else RP.get_servers()
    return [x for x in ss if x.get('enabled', True)]


def check(conn, servers=None):
    """점검 → `[(항목, 통과, 막나, 값)]`. **막는 항목이 하나라도 실패면 올리지 않는다.**"""
    import rss_publish as RP
    out = []
    on = bool(RP.get_auto().get('enabled'))
    out.append(('자동 배포 스위치', on, True, '켜짐' if on else '꺼짐 — 배포 센터 ▸ 자동 배포'))
    live = _servers(servers)
    out.append(('올릴 서버', bool(live), True,
                ' · '.join(x.get('label', '?') for x in live) or '없음 — 서버 관리 탭'))
    try:
        import db_linkpack_build as LB
        st = LB.status(conn)
    except Exception as e:                                   # noqa: BLE001
        out.append(('영상 연결 현황', False, True, '못 읽었다: %s' % str(e)[:60]))
        return out
    out.append(('승인된 영상 주소', st['media'] > 0, True,
                '%s편 · 연결 %s건' % (f"{st['media']:,}", f"{st['links']:,}")))
    out.append(('전체본', not st['first'], True,
                '있다(시퀀스 %d)' % st['seq'] if not st['first']
                else '아직 없다 — 첫 전체본은 배포 관리 ▸ 영상 연결에서 사람이 만든다'))
    d = st['stats']
    n_del = int(d.get('del') or 0)
    too_many = (not st['first']) and n_del >= DEL_MIN and n_del > st['media'] * DEL_RATIO
    out.append(('삭제(묘비) 비율', not too_many, True,
                '주소 +%d ~%d -%d · 연결 +%d -%d' % (d['add'], d['mod'], n_del,
                                                    d['link_add'], d['link_del'])
                + (' — 승인분의 절반을 넘는다. 스냅샷을 사람이 본다' if too_many else '')))
    # ★ 2026-10-25 배포 저장소 기록이 크면 알린다(막지 않는다) — 한 판으로 다시 세우기는 사람이(자동 배포 탭)
    try:
        import dist_squash as DS
        sq = DS.status()
        if sq.get('ok'):
            out.append(('배포 저장소 기록', not sq['warn'], False,
                        sq['msg'] + (' — 자동 배포 탭 [한 판으로 다시 세우기]' if sq['warn'] else '')))
    except Exception:
        pass
    try:
        last = recent(conn, 1)
        if last and last[0]['status'] in ('FAIL_UPLOAD', 'ERROR'):
            out.append(('지난 바퀴', False, False,
                        '%s — %s' % (STATUS_LABEL.get(last[0]['status']),
                                     (last[0]['message'] or '')[:60])))
        else:
            out.append(('지난 바퀴', True, False,
                        (last[0]['ts'] + ' ' + STATUS_LABEL.get(last[0]['status'], ''))
                        if last else '기록 없음'))
    except Exception:
        pass
    return out


def blocked(rows):
    """막는 항목 가운데 실패한 것 → `[(항목, 값)]`."""
    return [(n, v) for n, ok, blk, v in rows if blk and not ok]


def _record(conn, status, trigger, rows, kinds, link, msg):
    ensure(conn)
    conn.execute(
        "INSERT INTO %s(ts, trigger, status, check_json, kinds_json, link_seq,"
        " link_files, message) VALUES(?,?,?,?,?,?,?,?)" % TABLE,
        (time.strftime('%Y-%m-%d %H:%M:%S'), trigger, status,
         json.dumps(rows, ensure_ascii=False), json.dumps(kinds, ensure_ascii=False),
         (link or {}).get('seq'), ','.join((link or {}).get('uploaded') or []),
         (msg or '')[:400]))
    conn.commit()


def run_auto(conn=None, servers=None, trigger='SCHED', log=print,
             publish_kinds=True):
    """한 바퀴 → dict(status, check, kinds, link, message). **기록을 남긴다.**

    ⚠ 점검이 막으면 최신 콘텐츠도 올리지 않는다 — 「자동 배포」는 한 스위치다.
    ⚠ 최신 콘텐츠 종류는 내용이 같으면 SKIP(`rss_publish.publish_kind`) · 영상 연결은
      델타(`db_linkpack_build.publish`) — 둘 다 **바뀐 것만** 나간다.
    """
    own = conn is None
    if own:
        conn = appdb.connect(DB)
    res = {'status': 'ERROR', 'check': [], 'kinds': {}, 'link': None, 'message': ''}
    try:
        rows = check(conn, servers)
        res['check'] = rows
        bad = blocked(rows)
        if bad:
            st = 'SKIP_OFF' if any(n == '자동 배포 스위치' for n, _v in bad) else 'FAIL_CHECK'
            msg = ' · '.join('%s: %s' % (n, v) for n, v in bad)
            res.update(status=st, message=msg)
            _record(conn, st, trigger, rows, {}, None, msg)
            log('  자동 배포 — %s: %s' % (STATUS_LABEL[st], msg))
            return res
        live = _servers(servers)
        import rss_publish as RP
        kinds = {}
        import cloud_translate as CT
        del CT._RUNS[:]
        if publish_kinds:
            from datetime import datetime
            pub = datetime.now().isoformat(sep=' ', timespec='seconds')
            for k in RP.KIND_ALL:
                try:
                    r = RP.publish_kind(conn, live, k, pub, skip_unchanged=True)
                    kinds[k] = r.get('status') or '?'
                except Exception as e:                       # noqa: BLE001
                    kinds[k] = 'ERROR: %s' % str(e)[:60]
                log('  %-9s %s' % (k, kinds[k]))
        res['kinds'] = kinds
        import db_linkpack_build as LB
        link = LB.publish(conn, live, full=False, log=log)
        res['link'] = link
        oks = [x for x in (link.get('results') or []) if x['status'] == 'OK']
        fails = [x for x in (link.get('results') or []) if x['status'] != 'OK']
        kind_fail = [k for k, v in kinds.items() if str(v).startswith(('FAIL', 'ERROR'))]
        if fails or kind_fail:
            st = 'FAIL_UPLOAD'
            msg = ' · '.join(['영상 연결 %s: %s' % (x['server'], x['message'][:50]) for x in fails]
                             + ['%s %s' % (k, kinds[k]) for k in kind_fail])
        elif oks or any(v == 'OK' for v in kinds.values()):
            st = 'OK'
            msg = '영상 연결 시퀀스 %s · 파일 %d' % (link.get('seq'), len(link.get('uploaded') or [])) \
                if link.get('uploaded') else '최신 콘텐츠만'
        else:
            st = 'OK_NOCHANGE'
            msg = link.get('msg') or '바뀐 것 없음'
        # ★ 2026-10-25 이번 바퀴의 제목 번역(발행 안에서 돈다) — 몇 칸 · 어느 기계 · 멈춘 까닭
        xr = xl_summary(CT._RUNS)
        res['xl'] = xr
        if xr:
            msg = (msg + ' · ' if msg else '') + xr
        res.update(status=st, message=msg)
        _record(conn, st, trigger, rows, kinds, link, msg)
        log('  자동 배포 — %s: %s' % (STATUS_LABEL[st], msg))
        return res
    except Exception as e:                                   # noqa: BLE001
        res.update(status='ERROR', message=str(e)[:200])
        try:
            _record(conn, 'ERROR', trigger, res['check'], res['kinds'], res['link'], str(e))
        except Exception:
            pass
        log('  자동 배포 — 오류: %s' % str(e)[:120])
        return res
    finally:
        if own:
            conn.close()


def xl_summary(runs):
    """번역 결과 여럿 → 한 줄(「제목 번역 120칸(제미나이 120) · 남은 것 0」 · 멈췄으면 까닭) · 돈 것이 없으면 ''."""
    if not runs:
        return ''
    import cloud_translate as CT
    cells = sum(r.get('cells', 0) for r in runs)
    by = {}
    for r in runs:
        for k, v in (r.get('by') or {}).items():
            by[k] = by.get(k, 0) + v
    s = '제목 번역 %d칸' % cells
    if by:
        s += '(%s)' % ' · '.join('%s %d' % (CT.ENGINE_NAME.get(k, k), v) for k, v in by.items())
    s += ' · 남은 것 %d' % runs[-1].get('left', 0)
    stop = [r['stopped'] for r in runs if r.get('stopped')]
    if stop:
        s += ' · 멈춤: %s' % stop[-1][:80]
    return s


def recent(conn, n=30):
    """최근 기록 → `[dict]`(새것이 먼저)."""
    ensure(conn)
    out = []
    for r in conn.execute(
            "SELECT run_id, ts, trigger, status, check_json, kinds_json, link_seq,"
            " link_files, message FROM %s ORDER BY run_id DESC LIMIT ?" % TABLE, (n,)):
        try:
            ck = json.loads(r[4] or '[]')
        except Exception:
            ck = []
        try:
            kd = json.loads(r[5] or '{}')
        except Exception:
            kd = {}
        out.append({'run_id': r[0], 'ts': r[1], 'trigger': r[2], 'status': r[3],
                    'check': ck, 'kinds': kd, 'link_seq': r[6],
                    'link_files': (r[7] or '').split(',') if r[7] else [],
                    'message': r[8] or ''})
    return out


def summary(conn):
    """화면 머리 한 줄 — 마지막 성공 · 마지막 바퀴."""
    rows = recent(conn, 50)
    last = rows[0] if rows else None
    ok = next((x for x in rows if x['status'] == 'OK'), None)
    return {'last': last, 'last_ok': ok, 'n': len(rows)}


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def selftest():
    import sqlite3
    import tempfile
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    import db_linkpack_build as LB
    import rss_publish as RP
    import rss_transport as RT
    from admin import admin_state as A
    tmp = tempfile.mkdtemp()
    keep = (LB.DIST, RP.get_auto, RP._append_log, A.set_, RT.purge_jsdelivr)
    LB.DIST = os.path.join(tmp, 'dist')
    RP._append_log = lambda *a, **k: None
    A.set_ = lambda *a, **k: None
    RT.purge_jsdelivr = lambda *a, **k: {}
    switch = {'on': True}
    RP.get_auto = lambda: {'enabled': switch['on'], 'last_published_at': ''}
    srvdir = os.path.join(tmp, 'srv')
    srv = [{'label': 't', 'role': 'PRIMARY', 'transport': 'LOCAL_DIR',
            'location': srvdir, 'enabled': True}]
    conn = sqlite3.connect(':memory:')
    conn.executescript("""
      CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY, media_type TEXT,
        format_type TEXT, title TEXT, description TEXT, url TEXT, lang_code TEXT,
        sort_order INT, is_active INT, record_status TEXT);
      CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY, link_type TEXT,
        clicked_id INT, target_id INT, rel_code TEXT, end_id INT, record_status TEXT);
      CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY, entity_code TEXT);
      CREATE TABLE sys_pericope_asset(pericope_id INTEGER PRIMARY KEY, peri_code TEXT);
      INSERT INTO sys_entity_master VALUES(7,'P_DAVID');
      INSERT INTO sys_media_asset VALUES(1,'SERMON','VIDEO','a','','https://a','KO',0,1,'LIVE');
      INSERT INTO sys_link_asset VALUES(1,'MEDI_ENTI',1,7,NULL,NULL,'LIVE');
    """)
    try:
        t('기록 표 이름이 카탈로그에 있다(LOCAL)',
          __import__('db_pack_catalog').TABLES.get(TABLE, ('',))[0] == 'LOCAL')
        # ① 전체본이 없으면 막는다
        r = run_auto(conn, srv, trigger='TEST', log=lambda *a: None, publish_kinds=False)
        t('★★★ 첫 전체본이 없으면 **막는다**(사람이 만든다)', r['status'] == 'FAIL_CHECK'
          and '전체본' in r['message'], r['message'][:60])
        t('  막혀도 기록이 남는다', recent(conn)[0]['status'] == 'FAIL_CHECK')
        t('  막힌 바퀴는 올리지 않았다', not os.path.exists(srvdir))
        # 사람이 전체본을 만들어 올렸다
        LB.publish(conn, srv, full=True)
        # ② 스위치가 꺼져 있으면 SKIP_OFF
        switch['on'] = False
        r = run_auto(conn, srv, trigger='TEST', log=lambda *a: None, publish_kinds=False)
        t('★★ 스위치가 꺼져 있으면 아무것도 안 올린다', r['status'] == 'SKIP_OFF', r['status'])
        switch['on'] = True
        # ③ 바뀐 것 없음
        r = run_auto(conn, srv, trigger='TEST', log=lambda *a: None, publish_kinds=False)
        t('★ 바뀐 것 없으면 「바뀐 것 없음」', r['status'] == 'OK_NOCHANGE', r['status'])
        # ④ 바뀐 것 → 델타를 만들어 올린다
        conn.execute("INSERT INTO sys_media_asset VALUES(2,'SERMON','VIDEO','b','','https://b','KO',0,1,'LIVE')")
        conn.execute("INSERT INTO sys_link_asset VALUES(2,'MEDI_ENTI',2,7,NULL,NULL,'LIVE')")
        conn.commit()
        r = run_auto(conn, srv, trigger='TEST', log=lambda *a: None, publish_kinds=False)
        t('★★★ 점검 통과 → 델타 만들기 → 올리기가 한 바퀴에 돈다',
          r['status'] == 'OK' and r['link']['seq'] == 1
          and 'linkpack_00001.json' in r['link']['uploaded'], str(r['link'].get('uploaded')))
        t('  기록에 시퀀스·파일이 남는다', recent(conn)[0]['link_seq'] == 1
          and 'linkpack_00001.json' in recent(conn)[0]['link_files'])
        # ⑤ 삭제가 승인분의 절반을 넘으면 막는다
        conn.execute("INSERT INTO sys_media_asset SELECT media_id+100, media_type, format_type,"
                     " title, description, url||'x', lang_code, sort_order, 1, 'LIVE'"
                     " FROM sys_media_asset")
        for i in range(2, 200):
            conn.execute("INSERT INTO sys_media_asset VALUES(?,'SERMON','VIDEO','m','','https://m%d','KO',0,1,'LIVE')"
                         % i, (1000 + i,))
        conn.commit()
        run_auto(conn, srv, trigger='TEST', log=lambda *a: None, publish_kinds=False)
        conn.execute("UPDATE sys_media_asset SET is_active=0 WHERE media_id>=1000")
        conn.commit()
        r = run_auto(conn, srv, trigger='TEST', log=lambda *a: None, publish_kinds=False)
        t('★★★ 삭제가 승인분의 절반을 넘으면 **막는다**(스냅샷이 깨진 징후)',
          r['status'] == 'FAIL_CHECK' and '삭제' in r['message'], r['message'][:70])
        # ⑥ 요약
        s = summary(conn)
        t('  요약이 마지막 성공을 안다', s['last_ok'] and s['last_ok']['status'] == 'OK'
          and s['last']['status'] == 'FAIL_CHECK')
        t('  상태마다 사람 말이 있다', all(k in STATUS_LABEL for k in
                                      ('OK', 'OK_NOCHANGE', 'SKIP_OFF', 'FAIL_CHECK',
                                       'FAIL_UPLOAD', 'ERROR')))
        # ⑦ 배포 시각 — 수집 시각 + 6시간 · 자정을 감는다 · 수집이 없으면 18:00
        t('★★ 권장 배포 시각 = 수집 시각 + %d시간' % GAP_HOURS,
          suggest_time((12, 0)) == (18, 0) and suggest_time((13, 30)) == (19, 30))
        t('  자정을 넘으면 감는다', suggest_time((20, 15)) == (2, 15))
        t('  수집 작업이 없으면 18:00', suggest_time(None) == FALLBACK_TIME
          and suggest_time(()) == FALLBACK_TIME)
        x = task_xml(18, 0)
        t('★ 작업 XML 이 이 파일을 --run 으로 부른다',
          'db_auto_publish.py" --run' in x and 'T18:00:00' in x)
        t('  시각이 틀리면 등록을 거부한다', task_register(25, 0)[0] is False)
        # 실 DB 에 자국을 안 남겼다(메모리 DB 만 썼다)
        rc = appdb.connect(DB)
        try:
            n_real = rc.execute("SELECT COUNT(*) FROM sqlite_master WHERE name=?", (TABLE,)).fetchone()[0]
            t('★ 시험이 실 DB 에 표를 만들지 않는다(있으면 이미 있던 것)', n_real in (0, 1))
        finally:
            rc.close()
    finally:
        (LB.DIST, RP.get_auto, RP._append_log, A.set_, RT.purge_jsdelivr) = keep
        conn.close()
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)
    print('db_auto_publish selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    # ★ 2026-10-24 작업 스케줄러는 pythonw(창 없음) — 그때는 기록 파일로(db_rss_collect 와 같은 흠을 막는다)
    if sys.stdout is None:
        sys.stdout = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '_auto_deploy.log'),
                          'a', encoding='utf-8')
        sys.stderr = sys.stdout
    else:
        sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                      encoding='utf-8', errors='replace')
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect(DB)
    try:
        if '--check' in sys.argv:
            for n, okk, blk, v in check(c):
                print('  %s %s%-16s %s' % ('OK ' if okk else '·  ', '막음 ' if blk else '알림 ', n, v))
        elif '--run' in sys.argv:
            r = run_auto(c, trigger='CLI')
            print('→ %s: %s' % (STATUS_LABEL.get(r['status'], r['status']), r['message']))
        else:
            for r in recent(c, 20):
                print('  %s  %-12s %-8s %s' % (r['ts'], STATUS_LABEL.get(r['status'], r['status']),
                                              r['trigger'], r['message'][:70]))
            if not recent(c, 1):
                print('  기록이 없다 — 아직 한 바퀴도 안 돌았다')
    finally:
        c.close()
