# -*- coding: utf-8 -*-
"""낱말(원어) 설명 적재 — 2026-09-02 (사용자 승인 「계획대로 진행하라」).

사용자 지적: 「사랑에 아하브, 아가페 버튼을 제시하는데 이런 개념에 어떤
차이가 있는지 전혀 설명이 없다.」 실측 — 자리는 이미 배선돼 있었다
(`ENTITY_LEMMA_DESC` · `db_term_load.fetch_lemma_note` · 연결구절 탭의
낱말 단추 오른쪽 기본 글). **낱말 134개 중 채워진 것이 0건**이었다.

1차 = 신학 비중 큰 다낱말 용어 19개의 낱말 45건(KO+EN) + 죄 가족 문단 3편.
2차(용어명부 일괄 적재)에 나머지 34개 용어 + 파라바시스 앵커 검토.

★ 초안 열쇠 = **(entity_code, strong)** — lemma_id 는 PK 라 용어 재적재
  (`db_term_load --load`)가 번호를 갈 수 있다(§149차 T_TOV 사고 계열).
  재적재 뒤 이 도구를 다시 돌리면 새 번호에 다시 닻을 내린다(멱등).
★ 죄 가족 문단(FAMILY)은 설명문 끝에 **한 문단 덧붙임** — 표식 문장이
  이미 있으면 건너뛴다(멱등).

사용:
    python db_lemma_note.py --selftest   (의무)
    python db_lemma_note.py --check
    python db_lemma_note.py --apply     (멱등)
    python db_lemma_note.py --status
"""
import argparse
import io
import sys

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

import appdb  # noqa: E402

DB = 'bible_master.db'

# (entity_code, strong) → {KO, EN}. 그 낱말의 **결**(어근 그림 · 쓰임새 ·
# 형제 낱말과의 차이)을 말한다 — 용어 설명문의 되풀이가 아니다.
NOTES = {
    # ── 사랑 ──
    ('T_AHAV', 'H157'): {
        'KO': '구약의 사랑 동사입니다. 하나님이 이스라엘을 택하신 사랑(신7:8)부터 부부와 친구의 사랑까지 폭넓게 쓰입니다. 선택하고 붙드는 의지가 중심이라 명령이 될 수 있습니다(신6:5).',
        'EN': "The Old Testament verb for love, ranging from God's electing love (Deut 7:8) to the love of spouses and friends. Its center is choosing and holding fast, which is why it can be commanded (Deut 6:5)."},
    ('T_AHAV', 'H160'): {
        'KO': '아하브에서 나온 명사로, 사랑 그 자체를 가리킵니다. 「내가 무궁한 사랑으로 너를 사랑하는 고로」(렘31:3)의 그 사랑입니다.',
        'EN': 'The noun formed from ahav: love itself. "I have loved thee with an everlasting love" (Jer 31:3).'},
    ('T_AHAV', 'G25'): {
        'KO': '신약이 하나님의 사랑을 말할 때 선택한 동사입니다. 감정보다 뜻과 행동이 중심이라, 원수를 사랑하라는 명령(마5:44)에도 이 낱말이 쓰입니다.',
        'EN': "The verb the New Testament chose for God's love. Will and act stand before feeling, so even the command to love enemies (Matt 5:44) uses this word."},
    ('T_AHAV', 'G26'): {
        'KO': '헬라어에서 드물고 밋밋하던 명사를 신약이 집어 들어 하나님이 하시는 일의 이름으로 삼았습니다. 「하나님은 사랑이심이라」(요일4:8)와 고린도전서 13장의 사랑이 이 낱말입니다.',
        'EN': 'A rare, colorless Greek noun that the New Testament took up and made the name of what God does. "God is love" (1 John 4:8) and the love of 1 Corinthians 13 are this word.'},
    # ── 죄 가족 ──
    ('T_CHATAT', 'H2403'): {
        'KO': '과녁을 벗어난다는 그림의 낱말입니다. 죄를 목표에서 빗나간 것으로 봅니다. 속죄제가 같은 낱말인 것은 이 죄를 처리하는 제사이기 때문입니다. 반역(허물·페샤)과 뒤틀림(죄악·아온)에 견주면 빗나감 전반을 덮는 가장 넓은 죄 낱말입니다.',
        'EN': 'The picture is missing the mark: sin as falling short of the target. The sin offering bears the same word because it deals with this sin. Beside rebellion (pesha) and crookedness (avon), it is the broadest of the sin words.'},
    # ── 죄 의미장 승격분 새 앵커 (2026-09-02 177차) ──
    ('T_AVEL', 'H5766'): {
        'KO': '재판과 저울의 낱말로, 마땅함에서 벗어난 기움을 가리킵니다. 「재판할 때에 불의를 행치 말며」(레19:15)가 그 자리이고, 70인역이 이 낱말을 아디키아로 옮겨 신약과 이어집니다.',
        'EN': 'A word of courts and scales: a tilt away from what is due. "You shall do no injustice in judgment" (Lev 19:15); the Septuagint renders it adikia, bridging to the New Testament.'},
    ('T_MAAL', 'H4603'): {
        'KO': '신실치 못하게 배임하다라는 동사입니다. 아간이 바친 물건에 손댄 일(수7:1)과 사울이 여호와께 범죄한 일(대상10:13)이 이 동사로 기록됩니다.',
        'EN': "The verb of acting unfaithfully: Achan's hidden spoil (Josh 7:1) and Saul's unfaithfulness to the LORD (1 Chr 10:13) are recorded with it."},
    ('T_MAAL', 'H4604'): {
        'KO': '그 배임 행위 자체를 가리키는 명사입니다. 「여호와의 성물에 대하여 그릇 범과하였거든」(레5:15)에서 동사와 겹쳐 쓰여 뜻을 힘주어 말합니다.',
        'EN': 'The noun for the act of unfaithfulness itself. In "commits a trespass against the holy things of the LORD" (Lev 5:15) it doubles with the verb for emphasis.'},
    ('T_ASEBEIA', 'G763'): {
        'KO': '하나님께 드릴 공경을 드리지 않는 상태의 명사입니다. 「하나님의 진노가 … 모든 경건치 않음과 불의에 대하여」(롬1:18)에서 불의와 나란히 섭니다.',
        'EN': 'The noun for withholding from God the reverence that is his. In Romans 1:18 it stands beside unrighteousness.'},
    ('T_ASEBEIA', 'G765'): {
        'KO': '같은 뿌리의 형용사로 「경건치 않은 자」를 가리킵니다. 「기약대로 그리스도께서 경건치 않은 자를 위하여 죽으셨도다」(롬5:6).',
        'EN': 'The adjective of the same root: "the ungodly." "At the right time Christ died for the ungodly" (Rom 5:6).'},
    ('T_CHATAT', 'G266'): {
        'KO': '하타트에 대응하는 신약의 죄 낱말로, 역시 과녁을 벗어남이 뿌리 그림입니다. 로마서가 죄의 힘과 삯을 말할 때(롬6:23) 쓰는 낱말입니다.',
        'EN': "The New Testament counterpart of chattat, again rooted in the picture of missing the mark. Romans uses it for sin's power and wages (Rom 6:23)."},
    ('T_AVON', 'H5771'): {
        'KO': '굽었다, 뒤틀렸다는 그림의 낱말입니다. 죄를 비뚤어진 상태와 그 무게, 곧 죄책까지 함께 봅니다. 「여호와께서는 우리 무리의 죄악을 그에게 담당시키셨도다」(사53:6)의 죄악이 이 낱말입니다.',
        'EN': 'The picture is being bent or twisted: sin as a crooked condition together with its weight of guilt. "The LORD hath laid on him the iniquity of us all" (Isa 53:6) uses this word.'},
    ('T_AVEL', 'G93'): {
        'KO': '불의, 곧 의(디카이오쉬네)가 아닌 것입니다. 바른 기준에서 어긋난 상태를 가리킵니다. 「모든 불의에서 우리를 깨끗케 하실 것이요」(요일1:9).',
        'EN': 'Unrighteousness: what righteousness (dikaiosyne) is not. "To cleanse us from all unrighteousness" (1 John 1:9).'},
    ('T_ANOMIA', 'G458'): {
        'KO': '법 없음, 곧 율법을 무시하는 무법입니다. 「죄를 짓는 자마다 불법을 행하나니 죄는 불법이라」(요일3:4)가 이 낱말로 죄를 정의합니다.',
        'EN': 'Lawlessness: disregard of the law. "Sin is the transgression of the law" (1 John 3:4) defines sin with this word.'},
    ('T_PESHA', 'H6588'): {
        'KO': '반역의 낱말입니다. 종주에게 등을 돌리는 배반에서 온 그림으로, 죄를 언약을 깨뜨리는 고의의 반역으로 봅니다. 「그가 찔림은 우리의 허물을 인함이요」(사53:5)의 허물입니다. 빗나감(하타트), 뒤틀림(아온)과 나란히 죄의 세 얼굴을 이룹니다.',
        'EN': 'The word of rebellion, drawn from turning against one\'s lord: sin as willful breach of covenant. "He was wounded for our transgressions" (Isa 53:5). With chattat (missing) and avon (twisted) it forms the three faces of sin.'},
    # ── 진노 ──
    ('T_HEMAH', 'H2534'): {
        'KO': '뜨거움에서 온 낱말로, 타오르는 분노를 가리킵니다. 하나님의 진노가 뜨겁게 일어나는 자리에 쓰입니다.',
        'EN': 'From heat: burning anger, used where God\'s wrath rises hot.'},
    ('T_HEMAH', 'G3709'): {
        'KO': '신약의 진노 낱말로, 순간의 화가 아니라 자리 잡은 의로운 반응을 가리킵니다. 「하나님의 진노가 하늘로 좇아 나타나나니」(롬1:18)가 이 낱말입니다.',
        'EN': 'The New Testament word for settled, righteous wrath rather than a flash of temper: "the wrath of God is revealed from heaven" (Rom 1:18).'},
    ('T_HEMAH', 'G2372'): {
        'KO': '끓어오르는 격정의 진노입니다. 계시록이 「진노의 포도주」(계14:10)를 말할 때 이 낱말을 씁니다.',
        'EN': 'Wrath as boiling passion. Revelation\'s "wine of the wrath of God" (Rev 14:10) uses this word.'},
    # ── 거룩 ──
    ('T_KADOSH', 'H6944'): {
        'KO': '잘라 내어 따로 둔다는 뿌리에서 온 명사입니다. 거룩한 것, 성소, 성물이 다 이 낱말이라 사람만 아니라 장소와 물건에도 붙습니다.',
        'EN': 'From the root "cut off, set apart." Holy things, the sanctuary, and holy objects all bear this noun; it attaches to places and things as well as people.'},
    ('T_KADOSH', 'G40'): {
        'KO': '코데시를 받은 신약 낱말입니다. 성령과 성도가 다 이 낱말입니다. 성도란 따로 떼어 놓인 사람들이라는 뜻입니다.',
        'EN': 'The New Testament heir of qodesh. The Holy Spirit and the saints both carry this word: saints are the set-apart ones.'},
    # ── 공의·의 ──
    ('T_MISHPAT', 'H4941'): {
        'KO': '재판에서 온 낱말로, 바르게 판결하고 다스리는 질서 전체를 가리킵니다. 규례로도 옮겨집니다. 「오직 공법을 물같이」(암5:24)의 공법이 이 낱말입니다.',
        'EN': 'From the courtroom: the whole order of right judgment and governance, also rendered "ordinances." "Let judgment run down as waters" (Amos 5:24).'},
    ('T_MISHPAT', 'G2917'): {
        'KO': '판결, 곧 재판의 결과를 가리키는 신약 낱말입니다. 「너희가 비판하는 그 비판으로 너희가 비판을 받을 것이요」(마7:2)의 비판이 이 낱말입니다.',
        'EN': 'The verdict, the outcome of judgment: "with what judgment ye judge, ye shall be judged" (Matt 7:2) carries this word.'},
    ('T_MISHPAT', 'G2920'): {
        'KO': '심판하는 행위와 그 과정을 가리킵니다. 「심판이 하나님의 집에서 시작할 때가 되었나니」(벧전4:17).',
        'EN': 'The act and process of judging: "judgment must begin at the house of God" (1 Pet 4:17).'},
    ('T_TSEDEQ', 'H6664'): {
        'KO': '기준에 맞음, 곧 바름입니다. 하나님의 바르심과 그 기준에 맞는 상태를 두루 가리킵니다. 공의(미슈파트)가 재판의 질서라면 체데크는 그 재판이 맞춰야 할 기준입니다.',
        'EN': 'Conformity to the standard: rightness. Where mishpat is the order of judgment, tsedeq is the standard judgment must answer to.'},
    ('T_TSEDEQ', 'H6666'): {
        'KO': '체데크의 짝 명사로 거의 같은 뜻이며, 의로운 행위 쪽으로 기웁니다. 「여호와께서 이를 그의 의로 여기시고」(창15:6)의 의가 이 낱말입니다.',
        'EN': 'The twin noun of tsedeq, leaning toward righteous act. "He counted it to him for righteousness" (Gen 15:6).'},
    ('T_TSEDEQ', 'G1343'): {
        'KO': '신약의 의입니다. 로마서가 「하나님의 의」(롬1:17)를 말할 때 쓰는 낱말이고, 의롭다 하신다는 동사(디카이오오)와 한 가족입니다.',
        'EN': 'New Testament righteousness: "the righteousness of God" (Rom 1:17), kin to the verb "to justify" (dikaioo).'},
    # ── 구원 ──
    ('D_SALVATION', 'H3467'): {
        'KO': '구원하다는 동사입니다. 좁고 눌린 데서 넓은 데로 건져 낸다는 그림이며, 여호수아와 예수라는 이름이 이 뿌리에서 왔습니다.',
        'EN': 'The verb "to save": bringing out of straits into a broad place. The names Joshua and Jesus grow from this root.'},
    ('D_SALVATION', 'H3444'): {
        'KO': '야샤에서 온 명사, 구원 그 자체입니다. 「여호와는 나의 힘과 노래시며 나의 구원이시로다」(출15:2).',
        'EN': 'The noun from yasha: salvation itself. "The LORD is my strength and song, and he is become my salvation" (Exod 15:2).'},
    ('D_SALVATION', 'G4982'): {
        'KO': '구원하다, 낫게 하다는 동사입니다. 병 고침과 영혼 구원에 같은 낱말이 쓰여, 구원이 전인적임을 보여 줍니다(막5:34).',
        'EN': 'To save and to heal: the same verb serves both (Mark 5:34), showing salvation reaches the whole person.'},
    ('D_SALVATION', 'G4991'): {
        'KO': '신약의 구원 명사입니다. 「모든 믿는 자에게 구원을 주시는 하나님의 능력」(롬1:16).',
        'EN': 'The New Testament noun for salvation: "the power of God unto salvation to every one that believeth" (Rom 1:16).'},
    # ── 믿음·은혜 ──
    ('D_FAITH', 'H530'): {
        'KO': '굳고 든든하다는 뿌리에서 온 명사로, 아멘과 한 가족입니다. 신실함과 미쁨을 가리킵니다. 「의인은 그 믿음으로 말미암아 살리라」(합2:4)의 믿음입니다.',
        'EN': 'From the root "firm, steady," kin to amen: faithfulness and trustworthiness. "The just shall live by his faith" (Hab 2:4).'},
    ('D_FAITH', 'G4102'): {
        'KO': '신약의 믿음입니다. 신뢰와 맡김이 중심이며, 히브리서 11장이 이 낱말의 전시장입니다.',
        'EN': 'New Testament faith, centered on trust and entrusting. Hebrews 11 is its gallery.'},
    ('D_GRACE', 'H2580'): {
        'KO': '은혜, 곧 호의를 가리킵니다. 「노아는 여호와께 은혜를 입었더라」(창6:8)의 그 은혜입니다.',
        'EN': 'Favor: "Noah found grace in the eyes of the LORD" (Gen 6:8).'},
    ('D_GRACE', 'G5485'): {
        'KO': '신약의 은혜입니다. 값없이 주시는 호의로, 「너희가 그 은혜를 인하여 믿음으로 말미암아 구원을 얻었나니」(엡2:8)의 낱말입니다.',
        'EN': 'New Testament grace: favor freely given. "By grace are ye saved through faith" (Eph 2:8).'},
    # ── 평강·인애 ──
    ('T_SHALOM', 'H7965'): {
        'KO': '온전함에서 온 낱말입니다. 전쟁 없음만이 아니라 모자람 없이 온전한 상태 전체를 가리켜, 인사말로도 쓰입니다.',
        'EN': 'From wholeness: not merely absence of war but the whole state of well-being, serving even as a greeting.'},
    ('T_SHALOM', 'G1515'): {
        'KO': '샬롬을 받은 신약의 평강입니다. 「모든 지각에 뛰어난 하나님의 평강」(빌4:7).',
        'EN': 'The New Testament heir of shalom: "the peace of God, which passeth all understanding" (Phil 4:7).'},
    ('T_HESED', 'H2617'): {
        'KO': '언약에 붙는 변함없는 사랑입니다. 인자, 인애로 옮겨지며, 시편이 「그 인자하심이 영원함이로다」라고 반복하는 그 낱말입니다.',
        'EN': 'Covenant-bound steadfast love, rendered "lovingkindness" or "mercy" — the word the Psalms repeat: "his mercy endureth for ever."'},
    ('T_HESED', 'G1656'): {
        'KO': '긍휼, 자비입니다. 칠십인역이 헤세드를 주로 이 낱말로 옮겨, 신약의 긍휼 배후에 언약의 사랑이 서 있습니다.',
        'EN': 'Mercy. The Septuagint rendered hesed chiefly with this word, so covenant love stands behind New Testament mercy.'},
    # ── 회개 계열 ──
    ('T_SHUV', 'H7725'): {
        'KO': '돌아오다, 돌이키다입니다. 길을 되짚는 것부터 언약으로 돌아오는 회개까지 폭넓게 쓰입니다. 선지자들의 「돌아오라」가 이 낱말입니다.',
        'EN': 'To return, to turn back: from retracing a road to covenant repentance. The prophets\' "Return!" is this word.'},
    ('T_SHUV', 'G1994'): {
        'KO': '돌이켜 향한다는 신약 낱말입니다. 「우상을 버리고 하나님께로 돌아와서」(살전1:9).',
        'EN': 'To turn toward: "ye turned to God from idols" (1 Thess 1:9).'},
    ('T_NACHAM', 'H5162'): {
        'KO': '깊이 숨 쉰다는 그림에서 온 낱말로, 뉘우침과 위로 두 갈래로 쓰입니다. 하나님이 뜻을 돌이키실 때와 백성을 위로하실 때(사40:1)에 다 나옵니다.',
        'EN': 'From drawing a deep breath, it branches into both relenting and comforting: God\'s relenting, and "Comfort ye my people" (Isa 40:1).'},
    ('T_NACHAM', 'G3870'): {
        'KO': '곁으로 불러 위로하고 권면한다는 낱말입니다. 보혜사(파라클레토스)와 한 가족입니다.',
        'EN': 'To call alongside, to comfort and exhort: kin to the Paraclete.'},
    # ── 속량 계열 ──
    ('T_PADAH', 'H6299'): {
        'KO': '값을 주고 빼낸다는 속량의 낱말입니다. 장자를 대속하는 규례(출13:13)에 쓰입니다. 가알이 친족의 의무라면 파다는 값 치름 일반입니다.',
        'EN': 'To ransom at a price, as in the redemption of the firstborn (Exod 13:13). Where gaal is the kinsman\'s duty, padah is payment in general.'},
    ('T_PADAH', 'G3084'): {
        'KO': '몸값을 치러 놓아준다는 신약 낱말입니다. 「너희가 구속된 것은 그리스도의 보배로운 피로 한 것이니라」(벧전1:18~19).',
        'EN': 'To release by ransom: "ye were redeemed... with the precious blood of Christ" (1 Pet 1:18-19).'},
    ('T_GAAL', 'H1350'): {
        'KO': '기업 무를 자, 곧 친족이 값을 치르고 되찾는 제도의 낱말입니다(룻4). 파다가 값 치름 일반이라면 가알은 친족의 의무가 중심입니다.',
        'EN': 'The kinsman-redeemer\'s word (Ruth 4): a relative paying to reclaim. Where padah is payment in general, gaal centers on the kinsman\'s duty.'},
    ('T_GAAL', 'G3084'): {
        'KO': '몸값을 치러 놓아준다는 신약 낱말로, 칠십인역이 가알과 파다를 다 이 낱말로 받았습니다.',
        'EN': 'To release by ransom; the Septuagint received both gaal and padah with this one word.'},
    # ── 말씀·영 ──
    ('T_DAVAR', 'H1697'): {
        'KO': '말과 일을 다 가리키는 낱말입니다. 하나님의 말씀은 소리에 그치지 않고 일이 되어 이루어집니다(사55:11).',
        'EN': 'Both word and deed: God\'s word does not stop at sound but becomes event (Isa 55:11).'},
    ('T_DAVAR', 'G3056'): {
        'KO': '말, 이치, 말씀입니다. 요한복음이 「태초에 말씀이 계시니라」(요1:1)로 그리스도를 부르는 그 낱말입니다.',
        'EN': 'Word, reason, message: the word by which John names Christ, "In the beginning was the Word" (John 1:1).'},
    ('T_RUACH', 'H7307'): {
        'KO': '바람, 숨, 영을 한 낱말로 가리킵니다. 창1:2의 하나님의 신과 에스겔 37장의 생기가 다 이 낱말입니다.',
        'EN': 'Wind, breath, and spirit in one word: the Spirit of God in Gen 1:2 and the breath of Ezekiel 37.'},
    ('T_RUACH', 'G4151'): {
        'KO': '루아흐를 받은 신약 낱말입니다. 성령과 사람의 영, 바람이 같은 낱말이라 니고데모 대화(요3:8)의 말놀이가 성립합니다.',
        'EN': 'The New Testament heir of ruach. Spirit and wind share the word, which carries the play in the Nicodemus dialogue (John 3:8).'},
}

# ── 2차 (2026-09-02 사용자 「2차진행하라」) — 나머지 전 낱말 + 파라바시스 ──
#   파라바시스(G3847)는 측정 뒤 T_PESHA 에 앵커 추가: 신약 7회 전부 개역한글
#   「범함·범법」(롬4:15 「율법이 없는 곳에는 범함도 없느니라」). 70인역 다리는
#   0회지만(페샤→아세베이아 35%·하마르티아 20%) 뜻이 정확히 겹친다 —
#   §12-0 바라 판정 선례(빈도가 아니라 뜻으로 고른다).
NOTES2 = {
    # 교리 앵커 낱말
    ('D_ADOPTION', 'G5206'): {
        'KO': '아들로 삼는다는 법률 용어입니다. 로마의 입양 제도에서 온 그림으로, 종이 아니라 아들의 자리를 받는 일입니다. 「너희는 다시 무서워하는 종의 영을 받지 아니하였고 양자의 영을 받았으므로」(롬8:15).',
        'EN': 'A legal term for placing as a son, drawn from Roman adoption: receiving the standing not of a slave but of a son. "Ye have received the Spirit of adoption" (Rom 8:15).'},
    ('D_ATONEMENT', 'H3722'): {
        'KO': '덮는다는 그림의 낱말입니다. 속죄한다로 옮겨지며, 속죄소(카포레트)와 속죄일(욤 키푸르)이 이 뿌리에서 나왔습니다. 죄가 피로 덮여 하나님과 사람 사이가 회복되는 일입니다.',
        'EN': 'The picture is covering. Rendered "to make atonement," it is the root behind the mercy seat (kapporet) and the Day of Atonement (Yom Kippur): sin covered by blood, the breach repaired.'},
    ('D_BAPTISM', 'G907'): {
        'KO': '물에 담근다는 동사입니다. 씻음과 함께 죽고 다시 사는 그림까지 담습니다. 「무릇 그리스도 예수와 합하여 세례를 받은 우리는 그의 죽으심과 합하여 세례 받은 줄을 알지 못하느뇨」(롬6:3).',
        'EN': 'To immerse in water: carrying both washing and the picture of dying and rising. "So many of us as were baptized into Jesus Christ were baptized into his death" (Rom 6:3).'},
    ('D_CHURCH', 'H6951'): {
        'KO': '회중, 곧 부름 받아 모인 이스라엘 총회를 가리키는 구약 낱말입니다. 칠십인역이 이 낱말을 에클레시아로 옮겨, 교회라는 말의 구약 뿌리가 됩니다.',
        'EN': 'The assembly: Israel gathered at summons. The Septuagint rendered it ekklesia, giving the word "church" its Old Testament root.'},
    ('D_CHURCH', 'G1577'): {
        'KO': '불러 모은 무리라는 낱말입니다. 헬라 도시의 시민 총회를 가리키던 말을 신약이 받아, 그리스도께서 불러 모으신 백성의 이름으로 삼았습니다(마16:18).',
        'EN': 'The called-out assembly. A word for the citizen assembly of a Greek city, taken up as the name of the people Christ calls together (Matt 16:18).'},
    ('D_COVENANT', 'H1285'): {
        'KO': '언약의 구약 낱말입니다. 언약을 세운다를 히브리어는 「언약을 자른다」고 말하는데, 쪼갠 제물 사이를 지나는 의식(창15장)이 그 뒤에 있습니다.',
        'EN': 'The Old Testament word for covenant. Hebrew says one "cuts" a covenant, remembering the rite of passing between divided pieces (Gen 15).'},
    ('D_COVENANT', 'G1242'): {
        'KO': '칠십인역이 베리트를 옮긴 낱말입니다. 헬라어에서는 유언이라는 뜻도 있어, 히브리서가 죽음이 있어야 효력이 나는 언약을 말할 때 그 겹뜻을 씁니다(히9:16~17).',
        'EN': "The Septuagint's word for berit. In Greek it can also mean a will, a double sense Hebrews uses of the covenant that takes force through death (Heb 9:16-17)."},
    ('D_GIFTS_OF_SPIRIT', 'G5486'): {
        'KO': '카리스(은혜)에서 나온 낱말로, 은혜가 손에 잡히는 꼴을 한 선물입니다. 「각 사람에게 성령의 나타남을 주심은 유익하게 하려 하심이라」(고전12:7).',
        'EN': 'From charis (grace): grace taking the form of a gift. "The manifestation of the Spirit is given to every man to profit withal" (1 Cor 12:7).'},
    ('D_HELL', 'G1067'): {
        'KO': '예루살렘 남쪽 힌놈의 골짜기라는 지명에서 온 낱말입니다. 몰렉에게 아이를 불사르던 그 골짜기(왕하23:10)가 심판의 자리 이름이 되었습니다.',
        'EN': "From the valley of Hinnom south of Jerusalem, where children were burned to Molech (2 Kgs 23:10) — a place-name become the name of judgment."},
    ('D_IMAGO_DEI', 'H6754'): {
        'KO': '형상, 곧 새겨 만든 상을 가리키는 낱말입니다. 왕이 제 상을 세워 통치를 알리듯, 사람이 하나님의 형상으로 세워졌다는 그림이 창1:26~27에 있습니다.',
        'EN': 'Image: a carved likeness. As a king set up his image to mark his rule, so humanity is set up in the image of God (Gen 1:26-27).'},
    ('D_IMAGO_DEI', 'H1823'): {
        'KO': '모양, 닮음을 가리키는 낱말로, 창1:26에서 첼렘(형상)과 짝을 이룹니다. 두 낱말이 서로를 풀이하며 사람이 하나님을 닮게 지어졌음을 말합니다.',
        'EN': 'Likeness, paired with tselem in Gen 1:26; the two words interpret each other, saying humanity is made to resemble God.'},
    ('D_INSPIRATION', 'G2315'): {
        'KO': '하나님이 숨을 불어넣으셨다는 낱말로, 신약에 딤후3:16 한 곳뿐입니다. 「모든 성경은 하나님의 감동으로 된 것으로」의 감동이 이 낱말입니다.',
        'EN': 'God-breathed: found once, 2 Tim 3:16 — "All scripture is given by inspiration of God."'},
    ('D_JUSTIFICATION', 'G1344'): {
        'KO': '의롭다고 선언한다는 법정의 동사입니다. 의롭게 만들어 가는 과정이 아니라 재판장의 판결입니다. 「의롭다 하신 이는 하나님이시니 누가 정죄하리요」(롬8:33~34).',
        'EN': 'The courtroom verb: to declare righteous, a judge\'s verdict rather than a gradual making-righteous. "It is God that justifieth. Who is he that condemneth?" (Rom 8:33-34).'},
    ('D_PAROUSIA', 'G3952'): {
        'KO': '오심, 임하심입니다. 왕이 도시를 찾아오는 공식 방문을 가리키던 말로, 신약이 주님의 다시 오심을 부르는 이름입니다(살전4:15).',
        'EN': "Coming, arrival: the word for a king's official visit to a city, taken up for the Lord's return (1 Thess 4:15)."},
    ('D_PREDESTINATION', 'G4309'): {
        'KO': '미리 경계를 긋다, 미리 정하다는 동사입니다. 「미리 정하신 그들을 또한 부르시고」(롬8:30)의 그 낱말로, 구원의 시작이 사람보다 앞선다는 것을 말합니다.',
        'EN': 'To mark out beforehand: "whom he did predestinate, them he also called" (Rom 8:30) — salvation begins before us.'},
    ('D_REGENERATION', 'G3824'): {
        'KO': '다시 남이라는 낱말로 신약에 두 번뿐입니다. 딛3:5는 개인의 거듭남을, 마19:28은 만물이 새로워지는 때를 이 한 낱말로 부릅니다.',
        'EN': 'New birth, twice in the New Testament: the washing of regeneration (Titus 3:5) and the renewal of all things (Matt 19:28).'},
    ('D_REPENTANCE', 'G3341'): {
        'KO': '생각을 돌이킨다는 낱말입니다. 후회하는 감정이 아니라 마음의 방향을 바꾸는 일이며, 세례 요한과 예수님의 첫 선포가 이 낱말로 시작됩니다(막1:15).',
        'EN': 'A change of mind: not a feeling of regret but a turning of direction. The first preaching of John and of Jesus opens with this word (Mark 1:15).'},
    ('D_REVELATION', 'G602'): {
        'KO': '덮개를 벗긴다는 낱말입니다. 감춰져 있던 것이 드러나는 일로, 요한계시록의 제목이 바로 이 낱말입니다(계1:1).',
        'EN': 'An unveiling: what was hidden brought to light. It is the very title of the book of Revelation (Rev 1:1).'},
    ('D_SANCTIFICATION', 'G38'): {
        'KO': '거룩하게 됨을 가리키는 명사입니다. 단번의 판결(칭의)과 달리 자라 가는 과정을 말합니다. 「하나님의 뜻은 이것이니 너희의 거룩함이라」(살전4:3).',
        'EN': 'Being made holy: unlike the once-for-all verdict of justification, a growing work. "This is the will of God, even your sanctification" (1 Thess 4:3).'},
    ('D_TYPOLOGY', 'G5179'): {
        'KO': '두드려 남은 자국, 본을 가리키는 낱말입니다. 아담이 「오실 자의 표상」(롬5:14)이라 불릴 때의 그 낱말로, 예표론이라는 말이 여기서 왔습니다.',
        'EN': 'The mark left by a blow; a pattern. Adam is "the figure of him that was to come" (Rom 5:14) — the word behind "typology."'},
    # 용어 낱말
    ('T_AION', 'G165'): {
        'KO': '시대, 세대, 영원을 한 낱말로 가리킵니다. 「이 세대」와 「영원부터 영원까지」가 같은 낱말이라, 시간의 결을 문맥이 정합니다.',
        'EN': 'Age, era, eternity in one word: "this age" and "for ever and ever" share it, context setting the span.'},
    ('T_AION', 'H5769'): {
        'KO': '아득한 때, 영원을 가리키는 구약 낱말입니다. 칠십인역이 대부분을 아이온으로 옮겨 두 낱말이 짝이 되었습니다.',
        'EN': 'The Old Testament word for remotest time, everlastingness; the Septuagint rendered most of it with aion, pairing the two.'},
    ('T_ANASTASIS', 'G386'): {
        'KO': '일어남, 곧 부활입니다. 눕고 잠든 자가 일으켜 세워진다는 그림이며, 예수님은 이 낱말을 자기 이름으로 삼으셨습니다(요11:25).',
        'EN': 'A standing up: the sleeper raised to his feet. Jesus took the word as his own name (John 11:25).'},
    ('T_BARA', 'H1254'): {
        'KO': '창조하다입니다. 구약에서 이 동사의 주어는 언제나 하나님이라, 낱말 자체가 창조가 하나님만의 일임을 증언합니다(창1:1).',
        'EN': 'To create. In the Old Testament its subject is always God: the word itself testifies that creation is God\'s work alone (Gen 1:1).'},
    ('T_BARA', 'G2936'): {
        'KO': '신약이 창조를 말할 때 쓰는 동사입니다. 「만물이 그에게 창조되되」(골1:16)가 이 낱말로, 창조의 자리에 그리스도를 세웁니다.',
        'EN': 'The New Testament verb of creation: "by him were all things created" (Col 1:16), setting Christ at creation\'s center.'},
    ('T_BARAK', 'H1288'): {
        'KO': '복 주다와 송축하다가 한 낱말입니다. 하나님이 사람에게 내리시면 복이고 사람이 하나님께 올리면 송축이라, 한 낱말이 두 방향으로 흐릅니다.',
        'EN': 'To bless and to praise in one word: from God to us it is blessing, from us to God it is praise — one word flowing both ways.'},
    ('T_BARAK', 'G2127'): {
        'KO': '좋게 말하다가 본뜻입니다. 복을 빌고 찬송하는 신약 낱말로, 축복이라는 말의 헬라 뿌리입니다.',
        'EN': 'Literally "to speak well of": the New Testament word of blessing and praise, the Greek root of "eulogy."'},
    ('T_BASAR', 'H1320'): {
        'KO': '살, 고기, 육체를 가리킵니다. 사람의 연약하고 스러지는 됨됨이를 말할 때 쓰입니다. 「모든 육체는 풀이요」(사40:6).',
        'EN': 'Flesh: the frail, fading stuff of humanity. "All flesh is grass" (Isa 40:6).'},
    ('T_BASAR', 'G4561'): {
        'KO': '신약의 육체입니다. 몸이라는 중립적 뜻과 함께, 바울에게서는 하나님을 거스르는 옛 사람의 자리도 가리킵니다(롬8:5~8). 「말씀이 육신이 되어」(요1:14)의 육신도 이 낱말입니다.',
        'EN': 'New Testament flesh: neutrally the body, but in Paul also the seat of the old self against God (Rom 8:5-8). "The Word was made flesh" (John 1:14) uses it too.'},
    ('T_BASILEIA', 'G932'): {
        'KO': '나라이자 다스림입니다. 영토보다 왕의 통치가 중심이라, 하나님의 나라는 하나님이 왕으로 다스리시는 일 그 자체입니다(막1:15).',
        'EN': 'Kingdom as kingship: not territory first but reign. The kingdom of God is God reigning (Mark 1:15).'},
    ('T_BASILEIA', 'H4438'): {
        'KO': '왕권, 나라를 가리키는 구약 낱말입니다. 「주의 나라는 영원한 나라이니」(시145:13)의 나라가 이 낱말입니다.',
        'EN': 'Kingship, realm: "Thy kingdom is an everlasting kingdom" (Ps 145:13).'},
    ('T_BASILEIA', 'H4467'): {
        'KO': '왕국을 가리키는 구약 낱말로, 말쿠트와 거의 같게 쓰입니다. 「제사장 나라가 되며」(출19:6)의 나라입니다.',
        'EN': 'Kingdom, nearly synonymous with malkut: "a kingdom of priests" (Exod 19:6).'},
    ('T_BATACH', 'H982'): {
        'KO': '온 무게를 실어 기댄다는 신뢰의 낱말입니다. 시편이 사랑하는 낱말로, 피난처와 요새와 나란히 쓰입니다. 「여호와를 의뢰하고 선을 행하라」(시37:3).',
        'EN': 'To lean one\'s whole weight: the Psalms\' beloved word of trust, at home beside refuge and fortress. "Trust in the LORD, and do good" (Ps 37:3).'},
    ('T_BATACH', 'G3982'): {
        'KO': '설득되어 확신하고 의지한다는 신약 낱말입니다. 「너희 속에 착한 일을 시작하신 이가 이루실 줄을 우리가 확신하노라」(빌1:6).',
        'EN': 'To be persuaded, confident: "being confident of this very thing, that he which hath begun a good work in you will perform it" (Phil 1:6).'},
    ('T_BOSH', 'H954'): {
        'KO': '수치를 당한다는 낱말입니다. 기대던 것이 무너져 낯을 들 수 없게 되는 일로, 시편의 기도가 거듭 구하는 것이 「수치를 당치 않게 하소서」입니다(시25:2).',
        'EN': 'To be put to shame: what one leaned on collapsing, leaving no face to lift. The Psalms pray again and again, "let me not be ashamed" (Ps 25:2).'},
    ('T_DYNAMIS', 'G1411'): {
        'KO': '능력, 힘이 나타난 일을 가리킵니다. 복음서의 기적들이 이 낱말로 불리고, 복음 자체가 「구원을 주시는 하나님의 능력」(롬1:16)이라 불립니다.',
        'EN': 'Power, and power shown in act: the Gospels call miracles by this word, and the gospel itself is "the power of God unto salvation" (Rom 1:16).'},
    ('T_EMET', 'H571'): {
        'KO': '진실, 미쁨입니다. 아멘과 같은 뿌리라, 참되어 기댈 수 있다는 뜻이 중심입니다. 「인애(헤세드)와 진실」이 짝으로 자주 다닙니다(출34:6).',
        'EN': 'Truth as trustworthiness, sharing the root of amen. It often travels paired with hesed: "abundant in goodness and truth" (Exod 34:6).'},
    ('T_EMET', 'G225'): {
        'KO': '신약의 진리입니다. 요한복음이 이 낱말을 들어 올려 「내가 곧 길이요 진리요 생명이니」(요14:6)에 이릅니다.',
        'EN': 'New Testament truth, lifted by John to its height: "I am the way, the truth, and the life" (John 14:6).'},
    ('T_EUANGELION', 'G2098'): {
        'KO': '좋은 소식, 복음입니다. 전쟁의 승전보나 황제의 즉위 소식을 부르던 말을 신약이 받아, 그리스도의 일을 알리는 소식의 이름으로 삼았습니다(막1:1).',
        'EN': 'Good news: a word for victory dispatches and imperial announcements, taken up as the name of the news of Christ (Mark 1:1).'},
    ('T_EUANGELION', 'G2097'): {
        'KO': '좋은 소식을 전한다는 동사입니다. 복음은 명사이기 전에 전해지는 일이라, 신약은 이 동사를 쉼 없이 씁니다(눅4:18).',
        'EN': 'To bring good news: before the gospel is a noun it is an act of telling, and the New Testament uses this verb without rest (Luke 4:18).'},
    ('T_EUANGELION', 'H1319'): {
        'KO': '좋은 소식을 전한다는 구약 동사입니다. 「좋은 소식을 가져오며 평화를 공포하며」(사52:7)의 그 낱말로, 복음이라는 말의 구약 뿌리입니다.',
        'EN': 'The Old Testament verb of bringing good tidings: "that bringeth good tidings, that publisheth peace" (Isa 52:7) — the gospel\'s Old Testament root.'},
    ('T_HALAK', 'H1980'): {
        'KO': '걷다이자 살다입니다. 히브리어는 삶의 방식을 걸음으로 말합니다. 「에녹이 하나님과 동행하더니」(창5:24)의 동행이 이 낱말입니다.',
        'EN': 'To walk, and so to live: Hebrew speaks of a way of life as a way of walking. "Enoch walked with God" (Gen 5:24).'},
    ('T_HALAK', 'G4043'): {
        'KO': '두루 걷는다는 동사로, 신약이 삶의 방식을 말할 때 쓰는 낱말입니다. 「그 안에서 행하되」(골2:6)의 행함이 이 낱말입니다.',
        'EN': 'To walk about: the New Testament\'s word for a manner of life. "So walk ye in him" (Col 2:6).'},
    ('T_HYPOMONE', 'G5281'): {
        'KO': '밑에 남아 있음이 글자 뜻입니다. 짐 밑에서 버티고 자리를 지키는 인내로, 「인내로써 우리 앞에 당한 경주를 경주하며」(히12:1)의 인내입니다.',
        'EN': 'Literally "remaining under": endurance that holds its place beneath the load. "Let us run with patience the race that is set before us" (Heb 12:1).'},
    ('T_KAVOD', 'H3519'): {
        'KO': '뿌리가 「무겁다」입니다. 영광은 번쩍임이기 전에 무게, 곧 존재의 묵직함입니다. 여호와의 영광이 성막에 「충만하매」(출40:34) 모세가 들어가지 못했습니다.',
        'EN': 'Its root is "heavy": glory is weight before it is shine. When the glory filled the tabernacle, Moses could not enter (Exod 40:34).'},
    ('T_KAVOD', 'G1391'): {
        'KO': '신약의 영광입니다. 본래 평판이라는 뜻이던 낱말을 칠십인역이 카보드의 옮김말로 세워, 하나님의 무게 있는 임재를 가리키게 되었습니다(요1:14).',
        'EN': 'New Testament glory: a word once meaning "opinion," established by the Septuagint as kavod\'s equivalent for the weighty presence of God (John 1:14).'},
    ('T_KOINONIA', 'G2842'): {
        'KO': '함께 가짐, 나눔, 교제입니다. 물건을 나누는 일과 삶을 나누는 일이 한 낱말이라, 초대교회의 「서로 교제하며」(행2:42)에는 유무상통이 함께 담겨 있습니다.',
        'EN': 'Having in common: fellowship and sharing in one word. The first church\'s "fellowship" (Acts 2:42) carried shared goods and shared life together.'},
    ('T_LEV', 'H3820'): {
        'KO': '히브리어의 마음은 감정보다 생각과 판단과 결정의 자리입니다. 「무릇 지킬 만한 것보다 더욱 네 마음을 지키라 생명의 근원이 이에서 남이니라」(잠4:23).',
        'EN': 'The Hebrew heart is the seat of thought, judgment, and decision more than of feeling. "Keep thy heart with all diligence; for out of it are the issues of life" (Prov 4:23).'},
    ('T_LEV', 'H3824'): {
        'KO': '레브의 긴 꼴로 같은 낱말입니다. 「마음을 다하고 성품을 다하고」(신6:5)의 마음이 이 꼴로 나옵니다.',
        'EN': 'The longer form of lev, the same word: "with all thine heart" (Deut 6:5) uses this form.'},
    ('T_LEV', 'G2588'): {
        'KO': '신약의 마음입니다. 히브리어의 결을 이어받아 믿음과 생각과 뜻이 사는 안쪽 사람을 가리킵니다. 「사람이 마음으로 믿어 의에 이르고」(롬10:10).',
        'EN': 'The New Testament heart, heir to the Hebrew: the inner person where faith, thought, and will live. "With the heart man believeth unto righteousness" (Rom 10:10).'},
    ('T_MABBUL', 'H3999'): {
        'KO': '노아의 홍수만을 가리키는 낱말입니다. 여느 큰물이 아니라 그 심판의 물을 부르는 고유한 이름에 가깝습니다(창6:17).',
        'EN': 'A word reserved for Noah\'s flood: not any deluge, but nearly a proper name for those waters of judgment (Gen 6:17).'},
    ('T_MABBUL', 'G2627'): {
        'KO': '아래로 쏟아져 씻어 내린다는 낱말로, 신약이 노아의 홍수를 부를 때 씁니다(마24:38~39). 대격변이라는 말의 어원입니다.',
        'EN': 'A washing-down: the New Testament\'s word for Noah\'s flood (Matt 24:38-39), and the origin of "cataclysm."'},
    ('T_MYSTERION', 'G3466'): {
        'KO': '비밀이되 영영 감춰진 것이 아니라, 감춰졌다가 때가 되어 드러난 것입니다. 「영세 전부터 감취었다가 이제는 나타내신 바 된 그 비밀」(롬16:25~26).',
        'EN': 'A mystery not forever hidden but hidden and now disclosed: "kept secret since the world began, but now is made manifest" (Rom 16:25-26).'},
    ('T_MYSTERION', 'H7328'): {
        'KO': '다니엘서의 아람어 낱말로, 왕의 꿈처럼 하나님만 여실 수 있는 은밀한 것을 가리킵니다. 「오직 은밀한 것을 나타내실 자는 하늘에 계신 하나님이시라」(단2:28).',
        'EN': 'The Aramaic word of Daniel: a secret only God can open, like the king\'s dream. "There is a God in heaven that revealeth secrets" (Dan 2:28).'},
    ('T_NEPHESH', 'H5315'): {
        'KO': '뿌리는 목구멍입니다. 숨 쉬고 목말라하는 생명 그 자체, 곧 나 자신을 가리킵니다. 영혼, 생명, 마음, 사람으로 두루 옮겨지는 넓은 낱말입니다(창2:7).',
        'EN': 'Its root is the throat: breathing, thirsting life itself — one\'s very self. A wide word rendered soul, life, heart, person (Gen 2:7).'},
    ('T_NEPHESH', 'G5590'): {
        'KO': '네페쉬를 받은 신약 낱말입니다. 목숨과 혼을 함께 가리켜, 「사람이 만일 온 천하를 얻고도 제 목숨을 잃으면」(마16:26)의 목숨이 이 낱말입니다.',
        'EN': 'The New Testament heir of nephesh: life and soul together. "What is a man profited, if he shall gain the whole world, and lose his own soul?" (Matt 16:26).'},
    ('T_OR', 'H216'): {
        'KO': '빛입니다. 창조의 첫 말씀이 부른 것이며(창1:3), 시편에서 구원과 생명의 그림이 됩니다. 「여호와는 나의 빛이요 나의 구원이시니」(시27:1).',
        'EN': 'Light: the first thing creation\'s word called forth (Gen 1:3), and in the Psalms a picture of salvation. "The LORD is my light and my salvation" (Ps 27:1).'},
    ('T_OR', 'G5457'): {
        'KO': '신약의 빛입니다. 요한복음이 이 낱말로 그리스도를 부릅니다. 「나는 세상의 빛이니」(요8:12).',
        'EN': 'New Testament light, by which John names Christ: "I am the light of the world" (John 8:12).'},
    ('T_PARAKLETOS', 'G3875'): {
        'KO': '곁에 부름 받은 이라는 뜻으로, 변호인과 돕는 이를 가리킵니다. 예수님이 성령을 「또 다른 보혜사」(요14:16)라 부르신 그 이름입니다.',
        'EN': 'One called alongside: advocate and helper. Jesus names the Spirit "another Comforter" (John 14:16) with this word.'},
    ('T_PARABASIS', 'G3847'): {
        'KO': '그어진 선을 넘는다는 낱말입니다. 신약 일곱 번 모두 율법과 붙어 나오며 개역한글은 범함, 범법으로 옮깁니다. 「율법이 없는 곳에는 범함도 없느니라」(롬4:15). 페샤의 반역과 결이 닿는 신약 낱말입니다.',
        'EN': 'Stepping over a drawn line. All seven New Testament uses stand beside the law: "where no law is, there is no transgression" (Rom 4:15) — the New Testament word nearest to pesha\'s rebellion.'},
    ('T_PARAPTOMA', 'G3900'): {
        'KO': '곁으로 넘어진다는 그림의 낱말로, 개역한글은 허물, 범죄, 과실로 옮깁니다. 「너희의 허물과 죄로 죽었던 너희를 살리셨도다」(엡2:1). 로마서 5장이 아담의 일을 이 낱말로 거듭 부릅니다.',
        'EN': 'A falling aside: rendered trespass, offence, fault. "You... were dead in trespasses and sins" (Eph 2:1); Romans 5 names Adam\'s deed with this word again and again.'},
    ('T_QABAR', 'H6912'): {
        'KO': '장사하다, 묻다입니다. 족장들이 막벨라 굴에 장사되는 기사부터, 죽음을 존중히 다루는 성경의 결이 이 낱말에 담깁니다(창25:9~10).',
        'EN': 'To bury: from the patriarchs laid in Machpelah onward, Scripture\'s care for the dead lives in this word (Gen 25:9-10).'},
    ('T_QABAR', 'G2290'): {
        'KO': '신약의 장사하다입니다. 「장사 지낸 바 되었다가 성경대로 사흘 만에 다시 살아나사」(고전15:4)로 복음의 뼈대에 들어 있는 낱말입니다.',
        'EN': 'To bury in the New Testament: "he was buried, and... rose again the third day" (1 Cor 15:4) — a word inside the gospel\'s skeleton.'},
    ('T_SALACH', 'H5545'): {
        'KO': '사하다, 용서하다입니다. 구약에서 이 동사의 주어는 언제나 하나님이라, 낱말 자체가 사죄는 하나님만 하실 수 있는 일임을 증언합니다. 「저가 네 모든 죄악을 사하시며」(시103:3).',
        'EN': 'To forgive. In the Old Testament its subject is always God: the word itself testifies that pardon belongs to God alone. "Who forgiveth all thine iniquities" (Ps 103:3).'},
    ('T_SALACH', 'G859'): {
        'KO': '놓아줌, 사함입니다. 빚을 탕감하고 묶인 자를 풀어 준다는 그림으로, 「죄 사함을 얻게 하려고 흘리는 바 나의 피」(마26:28)의 사함이 이 낱말입니다.',
        'EN': 'Release: debt cancelled, the bound set free. "My blood... shed for many for the remission of sins" (Matt 26:28).'},
    ('T_SHABA', 'H7650'): {
        'KO': '맹세하다입니다. 일곱이라는 낱말과 한 뿌리로 읽혀 왔습니다. 하나님이 아브라함에게 「내가 나를 가리켜 맹세하노니」(창22:16) 하신 그 낱말입니다.',
        'EN': 'To swear, long linked with the word for seven. "By myself have I sworn" (Gen 22:16), said God to Abraham.'},
    ('T_SHABA', 'G3660'): {
        'KO': '신약의 맹세하다입니다. 예수님은 이 낱말로 맹세 남용을 막으십니다. 「도무지 맹세하지 말지니」(마5:34).',
        'EN': 'To swear in the New Testament. With this word Jesus checks the abuse of oaths: "Swear not at all" (Matt 5:34).'},
    ('T_SHAMA', 'H8085'): {
        'KO': '듣다와 순종하다가 한 낱말입니다. 히브리어는 둘을 나누지 않아, 들었다면 행하는 것입니다. 「이스라엘아 들으라」(신6:4)의 들으라가 이 낱말입니다.',
        'EN': 'To hear and to obey in one word: Hebrew does not divide them — to have heard is to do. "Hear, O Israel" (Deut 6:4).'},
    ('T_SHAMA', 'G191'): {
        'KO': '신약의 듣다입니다. 「믿음은 들음에서 나며 들음은 그리스도의 말씀으로 말미암았느니라」(롬10:17).',
        'EN': 'To hear: "faith cometh by hearing, and hearing by the word of God" (Rom 10:17).'},
    ('T_SHEM', 'H8034'): {
        'KO': '이름입니다. 성경에서 이름은 부르는 표가 아니라 그 사람의 됨됨이와 명성입니다. 그래서 하나님이 이름을 바꾸시는 것은 사람을 새로 지으시는 일입니다(창17:5).',
        'EN': 'Name: in Scripture not a label but character and renown. When God changes a name, he remakes the person (Gen 17:5).'},
    ('T_SHEM', 'G3686'): {
        'KO': '신약의 이름입니다. 이름으로 모이고 이름으로 구원을 받습니다. 「천하 인간에 구원을 얻을 만한 다른 이름을 우리에게 주신 일이 없음이니라」(행4:12).',
        'EN': 'Name in the New Testament: gathered in it, saved by it. "None other name under heaven given among men, whereby we must be saved" (Acts 4:12).'},
    ('T_SIMCHAH', 'H8057'): {
        'KO': '기쁨입니다. 잔치와 추수와 예배의 자리에서 나는 소리 있는 즐거움으로, 「주의 앞에는 기쁨이 충만하고」(시16:11)의 기쁨입니다.',
        'EN': 'Joy: the sounding gladness of feast, harvest, and worship. "In thy presence is fulness of joy" (Ps 16:11).'},
    ('T_SIMCHAH', 'G5479'): {
        'KO': '신약의 기쁨으로, 은혜(카리스)와 소리가 닿아 있는 낱말입니다. 옥중서신이 기뻐하라를 거듭 말할 때의 그 기쁨입니다(빌4:4).',
        'EN': 'New Testament joy, close in sound to charis (grace): the joy the prison letters keep commanding — "Rejoice in the Lord alway" (Phil 4:4).'},
    ('T_SPLANCHNA', 'G4697'): {
        'KO': '뿌리는 창자입니다. 속이 끊어지도록 불쌍히 여기는 일로, 복음서에서 예수님의 긍휼을 그리는 낱말입니다(마9:36).',
        'EN': 'Its root is the bowels: compassion felt in the gut. The Gospels\' word for the compassion of Jesus (Matt 9:36).'},
    ('T_TEFILLAH', 'H8605'): {
        'KO': '기도를 가리키는 구약의 으뜸 명사입니다. 시편 여러 편의 표제가 「다윗의 기도」로 이 낱말을 답니다(시86편).',
        'EN': 'The Old Testament\'s chief noun for prayer, heading several Psalms: "A Prayer of David" (Ps 86).'},
    ('T_TEFILLAH', 'G4336'): {
        'KO': '기도하다는 신약 동사입니다. 「쉬지 말고 기도하라」(살전5:17)가 이 낱말입니다.',
        'EN': 'To pray: "Pray without ceasing" (1 Thess 5:17).'},
    ('T_TEFILLAH', 'G4335'): {
        'KO': '기도라는 신약 명사입니다. 「기도와 간구로 너희 구할 것을 감사함으로 하나님께 아뢰라」(빌4:6).',
        'EN': 'Prayer the noun: "in every thing by prayer and supplication with thanksgiving let your requests be made known unto God" (Phil 4:6).'},
    ('T_TODAH', 'H3034'): {
        'KO': '감사하다, 찬송하다는 동사입니다. 손을 내뻗는 그림에서 온 낱말로, 「여호와께 감사하라 그는 선하시며」(시136:1)의 감사가 이 낱말입니다.',
        'EN': 'To thank and to praise, from the picture of outstretched hands: "O give thanks unto the LORD; for he is good" (Ps 136:1).'},
    ('T_TODAH', 'H8426'): {
        'KO': '감사라는 명사이며, 감사제의 이름이기도 합니다. 감사가 말에 그치지 않고 제물로 드려졌다는 것을 이 낱말이 보여 줍니다(레7:12).',
        'EN': 'Thanksgiving the noun, and the name of the thank offering: gratitude brought not in words only but as sacrifice (Lev 7:12).'},
    ('T_TODAH', 'G2168'): {
        'KO': '감사하다는 신약 낱말입니다. 「범사에 감사하라」(살전5:18)가 이 낱말이고, 성찬을 가리키는 유카리스트가 여기서 왔습니다.',
        'EN': 'To give thanks: "In every thing give thanks" (1 Thess 5:18) — the word behind "Eucharist."'},
    ('T_TORAH', 'H8451'): {
        'KO': '뿌리는 가리키다입니다. 법조문이기 전에 길을 가리키는 가르침이라, 율법과 가르침 두 옮김이 다 맞습니다. 「여호와의 율법을 즐거워하여」(시1:2).',
        'EN': 'Its root is "to point": instruction that shows the way before it is legal code — both "law" and "teaching" are right. "His delight is in the law of the LORD" (Ps 1:2).'},
    ('T_TORAH', 'G3551'): {
        'KO': '칠십인역이 토라를 옮긴 낱말입니다. 헬라어에서는 법이라는 결이 강해, 바울의 율법 논의가 이 낱말 위에서 벌어집니다(롬3:20).',
        'EN': 'The Septuagint\'s rendering of torah. In Greek the legal note is stronger, and Paul\'s argument about the law runs on this word (Rom 3:20).'},
    ('T_TOV', 'H2896'): {
        'KO': '좋다, 선하다입니다. 제 자리에서 제 구실을 다한다는 결이 있어, 창조의 후렴 「하나님이 보시기에 좋았더라」(창1장)가 이 낱말입니다.',
        'EN': 'Good: fit for its place, doing what it was made for. Creation\'s refrain "God saw that it was good" (Gen 1) is this word.'},
    ('T_TOV', 'G18'): {
        'KO': '도덕적으로 선하다는 결의 신약 낱말입니다. 「선한 일을 위하여 지으심을 받은 자니」(엡2:10)의 선함입니다.',
        'EN': 'Good with a moral note: "created in Christ Jesus unto good works" (Eph 2:10).'},
    ('T_TOV', 'G2570'): {
        'KO': '좋고 아름답다는 결의 신약 낱말입니다. 「나는 선한 목자라」(요10:11)의 선한이 이 낱말이라, 좋음이 눈에 보이는 아름다움까지 담습니다.',
        'EN': 'Good shading into beautiful: "I am the good shepherd" (John 10:11) — goodness that can be seen.'},
    ('T_YADA', 'H3045'): {
        'KO': '겪어서, 관계로 아는 것입니다. 정보가 아니라 사귐의 앎이라, 부부의 동침에도 이 낱말이 쓰입니다. 「나의 아는 자는 내 계명을 지키는 자니라」 계열의 앎입니다(호6:6).',
        'EN': 'Knowing by experience and relationship, not information — used even of marital union. The knowledge God desires more than sacrifice (Hos 6:6).'},
    ('T_YADA', 'G1097'): {
        'KO': '신약의 알다입니다. 야다의 결을 이어 사귐의 앎을 가리킬 수 있어, 「영생은 곧 유일하신 참 하나님과 그의 보내신 자 예수 그리스도를 아는 것이니이다」(요17:3)에 이릅니다.',
        'EN': 'To know, heir to yada\'s relational depth: "this is life eternal, that they might know thee" (John 17:3).'},
    ('T_YARE', 'H3372'): {
        'KO': '두려워하다와 경외하다가 한 낱말입니다. 무서움과 우러름이 갈리지 않은 채, 「여호와를 경외하는 것이 지식의 근본이니라」(잠1:7)에 이릅니다.',
        'EN': 'Fear and reverence undivided in one word, rising to "The fear of the LORD is the beginning of knowledge" (Prov 1:7).'},
    ('T_YARE', 'G5399'): {
        'KO': '신약의 두려워하다입니다. 칠십인역이 야레의 대부분을 이 낱말로 받아, 하나님을 경외하는 자들이 「하나님을 두려워하는 사람들」(행13:16)로 불립니다.',
        'EN': 'To fear: the Septuagint\'s main heir of yare. God-fearers are "whosoever among you feareth God" (Acts 13:16).'},
    ('T_ZAKAR', 'H2142'): {
        'KO': '기억하다입니다. 머리로 떠올리는 것이 아니라 기억한 대로 움직이는 것이라, 하나님이 노아를 「권념하사」(창8:1) 물을 물리치셨습니다.',
        'EN': 'To remember as acting on what is remembered, not mere recall: "God remembered Noah" (Gen 8:1), and the waters turned.'},
    ('T_ZAKAR', 'G3415'): {
        'KO': '신약의 기억하다입니다. 십자가 곁의 간구 「예수여 당신의 나라에 임하실 때에 나를 생각하소서」(눅23:42)가 이 낱말입니다.',
        'EN': 'To remember: the plea beside the cross, "Lord, remember me when thou comest into thy kingdom" (Luke 23:42).'},
}
NOTES.update(NOTES2)

# 죄 가족 문단 — 세 용어의 설명문 끝에 덧붙인다(서로를 가리키는 같은 취지).
#   멱등 표식 = 「죄의 세 얼굴」/three faces 문구.
FAMILY = {
    'T_CHATAT': {
        'KO': '성경은 죄를 여러 낱말로 말합니다. 과녁을 벗어난 빗나감(죄·하타트), 굽어 뒤틀린 상태(죄악·아온), 언약을 깨뜨리는 반역(허물·페샤)입니다. 개역한글이 죄, 죄악, 허물로 갈라 옮기지만 셋이 함께 죄의 세 얼굴을 그립니다. 시32:1~2와 사53:5~6이 이 낱말들을 나란히 씁니다.',
        'EN': 'Scripture speaks of sin in several words: missing the mark (chattat), a twisted condition (avon), covenant-breaking rebellion (pesha). Translated variously as sin, iniquity, and transgression, together they draw the three faces of sin, set side by side in Psalm 32:1-2 and Isaiah 53:5-6.'},
    'T_AVON': {
        'KO': '성경은 죄를 여러 낱말로 말합니다. 굽어 뒤틀린 상태(죄악·아온)와 함께, 과녁을 벗어난 빗나감(죄·하타트)과 언약을 깨뜨리는 반역(허물·페샤)이 있습니다. 셋이 함께 죄의 세 얼굴을 그리며, 시32:1~2와 사53:5~6이 이 낱말들을 나란히 씁니다.',
        'EN': 'Scripture speaks of sin in several words: beside the twisted condition (avon) stand missing the mark (chattat) and covenant-breaking rebellion (pesha). Together they draw the three faces of sin, set side by side in Psalm 32:1-2 and Isaiah 53:5-6.'},
    'T_PESHA': {
        'KO': '성경은 죄를 여러 낱말로 말합니다. 언약을 깨뜨리는 반역(허물·페샤)과 함께, 과녁을 벗어난 빗나감(죄·하타트)과 굽어 뒤틀린 상태(죄악·아온)가 있습니다. 셋이 함께 죄의 세 얼굴을 그리며, 시32:1~2와 사53:5~6이 이 낱말들을 나란히 씁니다.',
        'EN': 'Scripture speaks of sin in several words: beside covenant-breaking rebellion (pesha) stand missing the mark (chattat) and the twisted condition (avon). Together they draw the three faces of sin, set side by side in Psalm 32:1-2 and Isaiah 53:5-6.'},
}
_FAM_MARK = {'KO': '죄의 세 얼굴', 'EN': 'three faces of sin'}


def _lemma_id(conn, code, strong):
    r = conn.execute(
        "SELECT l.lemma_id FROM sys_entity_lemma l"
        " JOIN sys_entity_master m ON m.entity_id=l.entity_id"
        " WHERE m.entity_code=? AND l.strong=?"
        "   AND COALESCE(m.record_status,'LIVE')='LIVE'",
        (code, strong)).fetchone()
    return r[0] if r else None


def check(conn, verbose=True):
    err = []
    for (code, strong), texts in NOTES.items():
        if _lemma_id(conn, code, strong) is None:
            err.append('낱말 없음: %s %s' % (code, strong))
        for lang in ('KO', 'EN'):
            d = texts.get(lang, '')
            if len(d) < 40:
                err.append('%s %s %s: %d자(너무 짧다)' % (code, strong, lang, len(d)))
            if '\n' in d:
                err.append('%s %s %s: 개행(낱말 설명은 한 문단)' % (code, strong, lang))
        if '—' in texts.get('KO', ''):
            err.append('%s %s KO: 「—」' % (code, strong))
    for code, texts in FAMILY.items():
        r = conn.execute(
            "SELECT 1 FROM sys_entity_master WHERE entity_code=?"
            " AND COALESCE(record_status,'LIVE')='LIVE'", (code,)).fetchone()
        if not r:
            err.append('가족 문단 — 엔티티 없음: ' + code)
        for lang in ('KO', 'EN'):
            if _FAM_MARK[lang] not in texts.get(lang, ''):
                err.append('%s %s: 멱등 표식 문구가 없다' % (code, lang))
    if verbose:
        for e in err:
            print('  ⚠', e)
        print('낱말 설명 %d · 가족 문단 %d · 오류 %d'
              % (len(NOTES), len(FAMILY), len(err)))
    return err


def apply(conn, verbose=True):
    err = check(conn, verbose=False)
    if err:
        for e in err:
            print('  ⚠', e)
        print('오류 %d — 적재하지 않는다' % len(err))
        return 0
    n_new = n_upd = n_fam = 0
    for (code, strong), texts in NOTES.items():
        lid = _lemma_id(conn, code, strong)
        for lang in ('KO', 'EN'):
            body = texts[lang]
            cur = conn.execute(
                "SELECT sys_text_id, contents FROM sys_text_asset"
                " WHERE text_type='ENTITY_LEMMA_DESC' AND clicked_id=?"
                "   AND lang_code=? AND COALESCE(record_status,'LIVE')='LIVE'",
                (lid, lang)).fetchone()
            if cur is None:
                conn.execute(
                    "INSERT INTO sys_text_asset (clicked_id, text_type,"
                    " lang_code, contents, record_status)"
                    " VALUES (?, 'ENTITY_LEMMA_DESC', ?, ?, 'LIVE')",
                    (lid, lang, body))
                n_new += 1
            elif cur[1] != body:
                conn.execute("UPDATE sys_text_asset SET contents=?"
                             " WHERE sys_text_id=?", (body, cur[0]))
                n_upd += 1
    for code, texts in FAMILY.items():
        eid = conn.execute(
            "SELECT entity_id FROM sys_entity_master WHERE entity_code=?",
            (code,)).fetchone()[0]
        for lang in ('KO', 'EN'):
            cur = conn.execute(
                "SELECT sys_text_id, contents FROM sys_text_asset"
                " WHERE text_type='ENTITY_DESC' AND clicked_id=?"
                "   AND lang_code=? AND COALESCE(record_status,'LIVE')='LIVE'",
                (eid, lang)).fetchone()
            if cur is None:
                continue
            if _FAM_MARK[lang] in (cur[1] or ''):
                continue                       # 이미 붙어 있다(멱등)
            conn.execute("UPDATE sys_text_asset SET contents=? WHERE sys_text_id=?",
                         ((cur[1] or '').rstrip() + '\n' + texts[lang], cur[0]))
            n_fam += 1
    conn.commit()
    print('낱말 설명 +%d · 갱신 %d · 가족 문단 +%d' % (n_new, n_upd, n_fam))
    return n_new + n_upd + n_fam


def status(conn):
    n = conn.execute(
        "SELECT COUNT(*) FROM sys_text_asset WHERE text_type='ENTITY_LEMMA_DESC'"
        " AND COALESCE(record_status,'LIVE')='LIVE'").fetchone()[0]
    tot = conn.execute("SELECT COUNT(*) FROM sys_entity_lemma").fetchone()[0]
    print('낱말 설명 %d행 (낱말 %d · 초안 %d×2언어)' % (n, tot, len(NOTES)))


def selftest():
    """게이트·탐지력 — 적재하지 않는다."""
    conn = appdb.connect(DB)
    ok = fail = 0

    def t(name, cond, e=''):
        nonlocal ok, fail
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', name, e))
        ok += cond
        fail += (not cond)

    err = check(conn, verbose=False)
    t('초안 전체가 게이트를 넘는다', not err, err[:3])
    t('낱말 설명 141건(1차 45 + 2차 90 + 파라프토마 + 승격분 5)', len(NOTES) == 141, len(NOTES))
    g = globals()
    old = g['NOTES']
    try:
        g['NOTES'] = {('T_AHAV', 'H9999'): {'KO': '없는 낱말 시험용 사십 자를 채우기 위한 문장입니다. 길이를 넘겨야 게이트 하나만 걸립니다.', 'EN': 'A test sentence long enough to pass the length gate so only one error fires.'}}
        t('★ 탐지력 — 없는 낱말을 잡는다', bool(check(conn, verbose=False)))
        g['NOTES'] = {('T_AHAV', 'H157'): {'KO': '짧다', 'EN': 'short'}}
        t('★ 탐지력 — 짧은 글을 잡는다', bool(check(conn, verbose=False)))
    finally:
        g['NOTES'] = old
    # 화면 조회 문이 실제로 읽는가 (적재 뒤에만 값이 나온다)
    import db_term_load as T
    lid = _lemma_id(conn, 'T_AHAV', 'G26')
    note = T.fetch_lemma_note(conn, lid, 'KO') if lid else ''
    t('fetch_lemma_note 경로 살아 있음(적재 전 빈 값 허용)', note is not None)
    conn.close()
    print('db_lemma_note selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--status', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(DB)
    if a.apply:
        apply(conn)
        status(conn)
    elif a.check:
        check(conn)
    else:
        status(conn)
    conn.close()


if __name__ == '__main__':
    main()
