# -*- coding: utf-8 -*-
"""EN 본문의 한 절짜리 괄호 표기 `(N)` 을 `(verse N)` 으로 고친다.

게이트가 `(1)(2)` 형식 번호로 잡는다. 행 6장·고후 7장·골 4장·살전 1장·살후 1장에서
같은 실수를 다섯 번 반복했으므로, 적재 전에 이 스크립트를 돌린다.
범위(`(1-5)`)와 두 자리 이상은 건드리지 않는다.
"""
import json, io, re, sys, os
RX = re.compile(r'\((\d{1,3})\)')
n = 0
for path in sys.argv[1:]:
    if not os.path.exists(path):
        print('  ! 없음', path); continue
    d = json.load(io.open(path, encoding='utf-8'))
    ch = 0
    for k, v in d.get('chaps', {}).items():
        en = v.get('EN', '')
        new = RX.sub(lambda m: '(verse %s)' % m.group(1), en)
        if new != en:
            v['EN'] = new; ch += 1
    if ch:
        json.dump(d, io.open(path, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        print('  %s — %d장 고침' % (os.path.basename(path), ch)); n += ch
print('합계 %d장' % n)
