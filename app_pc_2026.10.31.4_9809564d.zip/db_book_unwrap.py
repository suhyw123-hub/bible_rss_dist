# -*- coding: utf-8 -*-
"""db_book_unwrap.py — 하드랩(hard wrap)된 도서 본문을 **문단 단위로** 되돌린다.

    python db_book_unwrap.py --selftest        (의무)
    python db_book_unwrap.py --check [CODE…]   DB 안 건드림
    python db_book_unwrap.py --apply [CODE…]   멱등 · 되돌릴 수 있다
    python db_book_unwrap.py --scan            어느 책이 하드랩인가

━━ 왜 필요한가 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
2026-08-30 사용자 신고 — 「번연의 책 … 원문 문장이 이어지지 않고 엔터키로
잘린 것 같다」. 실측이 그대로였다:

    책               줄당 자수 중앙   한 편 줄 수
    BUNYAN_PP            71            545
    BUNYAN_GRACE         70            423
    (대조) KEMPIS_IOC   475              7
    (대조) MEYER_ODH    349              9

원본 텍스트 파일이 **72~74자에서 줄을 접어 둔 것**이 그대로 들어왔다.
`\\n` 은 우리 규약에서 **문단**이므로(§28-11) 화면이 한 편을 545문단으로
벌려 놓는다.

━━ ★★★ 같은 「빈 줄 하나」가 두 권에서 정반대 뜻이다 ━━━━━━━━━━━━━━━━
**빈 줄 묶음의 길이**를 세어야 알 수 있다(실측):

    BUNYAN_PP     묶음 1 = 2,507 · 묶음 2 = 125
        → 줄과 줄 사이에 빈 줄이 **없다**. 빈 줄 하나가 **문단 경계**다.
    BUNYAN_GRACE  묶음 1 = 4,023 · 묶음 3 = 611 · 그 위 36
        → 글줄마다 빈 줄이 하나씩 끼어 있다(구텐베르크 두 줄 간격).
          **묶음 1 은 줄 이어짐**이고 **묶음 3 이상이 문단 경계**다.

⇒ **책마다 문턱을 실측해서 정한다**(`PROFILE`). 한 규칙을 두 권에 쓰면
  한쪽은 문단이 통째로 붙고 다른 쪽은 통째로 갈라진다.

⚠⚠ **운문을 이어 붙이면 안 된다.** 번연은 시를 많이 쓴다(PP 에서 짧은 줄이
  잇단 덩이 182개·1,154줄). 이어 붙이면 시가 산문이 된다.
  ⇒ **한 줄짜리 덩이가 짧으면**(`VERSE_MAX`) 그 줄을 그대로 둔다.
    `book_blocks` 가 화면에서 운문을 알아보는 잣대(짧은 줄이 잇달면 운문)와
    같은 문법이다.

⚠ **낱말을 하나도 잃지 않는다.** 바꾸는 것은 공백뿐이므로 `' '.join(split())`
  이 앞뒤로 같아야 한다 — 다르면 그 편은 건드리지 않는다. `--check` 가 잰다.

⚠ 되돌릴 수 있다 — `temp_bookunwrap_backup` 에 옛 글을 담고 `--restore`.

⚠⚠⚠ **순서 — 이 도구를 먼저, `db_book_artifact` 를 나중에.**
  구텐베르크 머리글은 `db_book_artifact` 가 걷는다. 그런데 그 도구는 줄을
  지우면서 **빈 줄 묶음을 눌러 버린다** — 번연 『넘치는 은혜』에서 문단 경계
  611개가 **237개로 줄었고**(실측), 그 상태로 이 도구를 돌리자 문단이 통째로
  붙어 **줄당 8,453자**가 됐다.
  ⇒ **빈 줄 구조가 온전할 때 먼저 문단을 세우고**, 그 뒤에 흔적을 걷는다.
    바로잡은 뒤 523자(정상).
  ⚠ 되돌리려면 `db_book_unwrap --restore` **다음에** `db_book_artifact --restore`
    (건 차례의 역순). 그 `--restore` 는 이 일 때문에 2026-08-30 에 만들었다 —
    **백업을 두는 도구는 쓰는 길까지 있어야 한다.**
"""
import argparse
import io
import re
import sys

try:  # 2026-10-29 제자리에서 — 새 래퍼를 만들면 버려지는 옛 래퍼가 진짜 출력을 닫는다
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:  # noqa: BLE001
    pass

import appdb                                    # noqa: E402

BACKUP = 'temp_bookunwrap_backup'

#: 책마다 다른 문턱 — **실측으로 정한다**(위 표).
#:   `break_run` : 빈 줄이 이만큼 잇달면 **문단 경계**. 그보다 짧으면 줄 이어짐.
#:   `verse_max` : 한 줄짜리 덩이가 이보다 짧으면 **운문·제목**으로 보고 안 잇는다.
PROFILE = {
    'BUNYAN_PP':    dict(break_run=1, verse_max=55),
    'BUNYAN_GRACE': dict(break_run=2, verse_max=55),
    # ★ `--scan` 이 **찾아 준 세 번째 책** (2026-08-30). 실측 묶음 1=2,325 ·
    #   3=227 로 GRACE 와 같은 꼴이다 — 구텐베르크 두 줄 간격.
    'MULLER_ATP':   dict(break_run=2, verse_max=55),
    # ★ `--scan` 이 **네 번째 책**을 찾아 줬다 (2026-09-18 · 메이어 인물 묵상집).
    #   실측 3장 — 줄바꿈 묶음 1=240 · 2=35 이라 **빈 줄 하나가 문단 경계**다.
    #   IA 스캔이라 낱말 사이가 두 칸인데 그래도 줄당 중앙이 69자다.
    # ⚠⚠ **`break_run` 은 「빈 줄 수」지 「줄바꿈 글자 수」가 아니다** —
    #   이 책은 문단 사이가 **빈 줄 하나**라 1 이다. 2 로 두었더니
    #   `blocks` 가 한 번도 안 갈라 **한 편이 통째로 한 줄**이 됐다
    #   (실측 2장 줄 1개 · 출처 줄까지 문단에 붙어 원문 대조에서 튀었다).
    # ⚠ 28장 중 23장은 이미 문단이고 **다섯 장만 하드랩**이라 섞였다
    #   (2026-09-18 사용자 지적). 그래서 `mixed` — 덩이마다 잰다.
    'MEYER_MOSES':  dict(break_run=1, verse_max=55, mixed=True),
}
# ⚠ **`SPURGEON_ME` 는 하드랩이 아니다** — 줄당 중앙이 67자라 의심스러웠지만
#   90퍼센타일이 1,804자다(짧은 줄은 운문·성구 표시이고 산문은 문단으로 담겨
#   있다). `looks_wrapped` 가 732편 전부를 옳게 걸렀다.
#   ⇒ **중앙값만 보고 판정하지 않는다.**

#: 하드랩 판정 — 줄당 자수가 이보다 짧으면 접힌 것이다(`booktrans.md` §1-6 의
#: `WRAP_MAX=200` 과 같은 잣대. 문단으로 담긴 책은 300~500자다).
WRAP_MAX = 120


# ── 재기 ─────────────────────────────────────────────────────────────────────
def line_stats(text):
    """→ (글줄 수, 줄당 자수 중앙, 최대). 빈 줄은 안 센다."""
    ls = [l.rstrip() for l in (text or '').split('\n') if l.strip()]
    if not ls:
        return 0, 0, 0
    n = sorted(len(l) for l in ls)
    return len(ls), n[len(n) // 2], n[-1]


def looks_wrapped(text):
    """하드랩인가 — **줄당 자수**로 본다(빈 줄 유무가 아니다)."""
    n, mid, mx = line_stats(text)
    return n >= 8 and mid <= WRAP_MAX and mx <= WRAP_MAX + 20


# ── 되돌리기 ──────────────────────────────────────────────────────────────────
def blocks(text, break_run):
    """빈 줄 묶음으로 덩이를 가른다 → [[줄, …], …]

    ⚠ **묶음 길이가 `break_run` 보다 짧으면 덩이를 안 가른다** — 그 빈 줄은
      문단 경계가 아니라 두 줄 간격일 뿐이다(구텐베르크 판).
    """
    out, cur, run = [], [], 0
    for raw in (text or '').split('\n'):
        if raw.strip():
            if run and run >= break_run and cur:
                out.append(cur)
                cur = []
            run = 0
            cur.append(raw.strip())
        else:
            run += 1
    if cur:
        out.append(cur)
    return out


def unwrap(text, break_run=1, verse_max=55, mixed=False):
    """하드랩을 풀어 문단으로. **바꾸는 것은 공백뿐이다.**

    ⚠⚠ **이미 풀린 글은 손대지 않는다** — 그러지 않으면 멱등이 깨진다.
      푼 글에는 빈 줄이 없으므로 두 번째 호출에서 덩이가 하나가 되고
      **문단이 통째로 붙어 버린다**(selftest 가 잡았다).
      ⇒ 하드랩인지 먼저 보고, 아니면 그대로 돌려준다.

    ★★★ `mixed=True` — **한 책 안에 두 가지가 섞인 경우**(2026-09-18).
      `MEYER_MOSES` 28장 가운데 23장은 이미 문단이고 **다섯 장만 하드랩**
      이었다. 그런데 `looks_wrapped` 는 **편 전체**를 재므로, 그 다섯 장에
      긴 줄이 섞여 있자(중앙 59자인데 최대 181자) 통째로 「문단 글」로 보고
      **아무것도 안 풀었다**. 사용자가 화면에서 그것을 보고 지적했다.
      ⇒ 섞인 책은 **덩이(문단)마다** 잰다 — 그 덩이 줄들의 **중앙값**이
        `WRAP_MAX` 이하면 하드랩이라 잇고, 아니면 이미 문단이라 둔다.
      ⚠ **최대 길이로 재면 안 된다** — 한 덩이에 긴 줄이 하나만 섞여도
        그 문단이 통째로 안 풀린다(위 다섯 장이 정확히 그 자리였다).
      ⚠ **기본은 꺼 둔다** — 켜면 이미 풀린 책에서 짧은 줄이 잇단 덩이
        (운문)를 이을 위험이 있다. **책마다 실측하고 `PROFILE` 에 적는다.**
    """
    if not mixed and not looks_wrapped(text):
        return text or ''
    out = []
    for blk in blocks(text, break_run):
        if len(blk) == 1 and len(blk[0]) < verse_max:
            # ★ 한 줄짜리 짧은 덩이 = 운문 한 행·제목 — **잇지 않는다**
            out.append(blk[0])
            continue
        if mixed and len(blk) > 1:
            mid = sorted(len(l) for l in blk)[len(blk) // 2]
            if mid > WRAP_MAX:          # 이미 문단이다 — 손대지 않는다
                out.extend(blk)
                continue
        out.append(' '.join(blk))
    return '\n'.join(out)


def words(text):
    """낱말 차례 — 공백만 다른지 재는 잣대."""
    return ' '.join((text or '').split())


# ── DB ───────────────────────────────────────────────────────────────────────
def _rows(conn, code):
    return conn.execute(
        "SELECT t.text_id, t.body_text FROM sys_book_unit_text t"
        "  JOIN sys_book_unit u USING(unit_id)"
        "  JOIN sys_book_asset a USING(book_id)"
        " WHERE a.book_code=? AND t.text_variant='ORIGINAL'"
        "   AND t.record_status='LIVE' AND u.record_status='LIVE'"
        " ORDER BY u.sequence", (code,)).fetchall()


def check(conn, code, verbose=True):
    """→ (편 수, 바뀔 편, 낱말이 어긋난 편, 줄당 자수 전/후)"""
    prof = PROFILE.get(code)
    if not prof:
        raise SystemExit('%s 는 `PROFILE` 에 없다 — 문턱을 실측해서 넣을 것.' % code)
    rows = _rows(conn, code)
    n_ch = n_bad = 0
    mid0 = mid1 = 0
    for _tid, body in rows:
        new = unwrap(body, prof['break_run'], prof['verse_max'],
                     prof.get('mixed', False))
        if new != (body or ''):
            n_ch += 1
        if words(new) != words(body):
            n_bad += 1
        mid0 += line_stats(body)[1]
        mid1 += line_stats(new)[1]
    k = max(1, len(rows))
    if verbose:
        print('  %-15s 편 %3d · 바뀔 편 %3d · 낱말 어긋남 %d · 줄당 %d자 → %d자'
              % (code, len(rows), n_ch, n_bad, mid0 // k, mid1 // k))
        if n_bad:
            print('       ⚠ 낱말이 어긋난 편이 있다 — 적재하지 않는다')
    return len(rows), n_ch, n_bad, mid0 // k, mid1 // k


def apply(conn, code, dry=True):
    prof = PROFILE[code]
    _n, _c, bad, _a, _b = check(conn, code, verbose=True)
    if bad:
        raise SystemExit('[%s] 낱말이 어긋난다 — 멈춘다.' % code)
    if dry:
        return
    conn.execute("CREATE TABLE IF NOT EXISTS %s ("
                 " text_id INTEGER PRIMARY KEY, book_code TEXT, body_text TEXT)"
                 % BACKUP)
    for tid, body in _rows(conn, code):
        new = unwrap(body, prof['break_run'], prof['verse_max'],
                     prof.get('mixed', False))
        if new == (body or ''):
            continue
        if not conn.execute("SELECT 1 FROM %s WHERE text_id=?" % BACKUP,
                            (tid,)).fetchone():
            conn.execute("INSERT INTO %s VALUES (?,?,?)" % BACKUP,
                         (tid, code, body))
        conn.execute("UPDATE sys_book_unit_text SET body_text=? WHERE text_id=?",
                     (new, tid))
    conn.execute("UPDATE sys_book_asset SET body_chars="
                 " (SELECT SUM(LENGTH(t.body_text)) FROM sys_book_unit_text t"
                 "   JOIN sys_book_unit u USING(unit_id)"
                 "  WHERE u.book_id=sys_book_asset.book_id)"
                 " WHERE book_code=?", (code,))
    conn.commit()
    print('       → 적재')


def restore(conn, code):
    try:
        rows = conn.execute("SELECT text_id, body_text FROM %s WHERE book_code=?"
                            % BACKUP, (code,)).fetchall()
    except Exception:
        rows = []
    for tid, body in rows:
        conn.execute("UPDATE sys_book_unit_text SET body_text=? WHERE text_id=?",
                     (body, tid))
    conn.execute("DELETE FROM %s WHERE book_code=?" % BACKUP, (code,))
    conn.commit()
    print('  %s 되돌림 %d편' % (code, len(rows)))


def scan(conn):
    """어느 책이 하드랩인가 — 표에 없는 책도 함께 보인다."""
    print('  책               편   줄당자수  판정')
    for code, in conn.execute(
            "SELECT book_code FROM sys_book_asset WHERE record_status='LIVE'"
            " ORDER BY book_code"):
        rows = _rows(conn, code)
        if not rows:
            continue
        mids = [line_stats(b)[1] for _t, b in rows]
        mid = sorted(mids)[len(mids) // 2]
        w = sum(1 for _t, b in rows if looks_wrapped(b))
        tag = ''
        if w * 2 > len(rows):
            tag = '**하드랩**' + ('' if code in PROFILE else '  ← PROFILE 없음')
        print('  %-15s %4d  %6d    %s' % (code, len(rows), mid, tag))


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def selftest():
    ok = True

    def t(name, cond, extra=''):
        nonlocal ok
        print('  %-4s %s %s' % ('OK' if cond else 'FAIL', name, extra))
        if not cond:
            ok = False

    # ⚠ 시험 자료는 **실제와 같은 크기**여야 한다 — `looks_wrapped` 가 8줄
    #   미만을 걸러 내므로(짧은 글은 함부로 안 건드린다) 두세 줄짜리로는
    #   아무 일도 안 일어난다. 처음에 그렇게 짜서 네 항목이 헛돌았다.
    W = ('word ' * 13).strip()             # 64자 — 접힌 한 줄
    # ① 빈 줄 하나가 **이어짐**인 판 (GRACE 꼴 — 글줄마다 빈 줄이 낀다)
    g = '\n\n'.join([W] * 6) + '\n\n\n\n' + '\n\n'.join([W] * 6) + '\n'
    r = unwrap(g, break_run=2, verse_max=55)
    t('★ 묶음 1 은 잇는다 (GRACE 꼴)', len(r.split('\n')) == 2, len(r.split('\n')))
    t('★ 묶음 3 은 가른다', r.split('\n')[0].count('word') == 78,
      r.split('\n')[0].count('word'))

    # ② 빈 줄 하나가 **문단 경계**인 판 (PP 꼴 — 줄 사이에 빈 줄이 없다)
    p = '\n'.join([W] * 5) + '\n\n' + '\n'.join([W] * 5) + '\n'
    r2 = unwrap(p, break_run=1, verse_max=55)
    t('★ 묶음 1 은 가른다 (PP 꼴)', len(r2.split('\n')) == 2, len(r2.split('\n')))

    # ③ **운문을 잇지 않는다** — 짧은 줄이 빈 줄로 나뉘어 잇달아 온다
    v = '\n\n'.join(['Short verse line %d' % i for i in range(10)])
    r3 = unwrap(v + '\n\n' + '\n'.join([W] * 4), break_run=1, verse_max=55)
    t('★★ 한 줄짜리 짧은 덩이는 안 잇는다',
      sum(1 for x in r3.split('\n') if x.startswith('Short verse')) == 10,
      sum(1 for x in r3.split('\n') if x.startswith('Short verse')))

    # ④ **낱말을 하나도 잃지 않는다** — 이것이 이 도구의 안전선이다
    for src, br in ((g, 2), (p, 1), (v, 1)):
        t('★★ 낱말 차례 보존 (br=%d)' % br,
          words(unwrap(src, br, 55)) == words(src))

    # ⑤ 멱등 — 두 번 풀어도 같다
    once = unwrap(g, 2, 55)
    t('★ 멱등', unwrap(once, 2, 55) == once)

    # ⑥ 하드랩 판정
    wrapped = '\n'.join(['x' * 70] * 12)
    para = '\n'.join(['y' * 400] * 12)
    t('★ 하드랩을 알아본다', looks_wrapped(wrapped))
    t('★ 문단 글은 안 잡는다', not looks_wrapped(para))

    # ⑦ 표에 없는 책은 **거부한다** — 짐작으로 문턱을 쓰지 않는다
    try:
        conn = appdb.connect()
        try:
            check(conn, 'MEYER_ODH', verbose=False)
            t('★ PROFILE 없는 책은 거부', False)
        except SystemExit:
            t('★ PROFILE 없는 책은 거부', True)
        conn.close()
    except Exception as e:
        t('★ PROFILE 없는 책은 거부', False, str(e)[:40])

    # ★ 섞인 글 — 하드랩 문단만 잇고 이미 풀린 문단은 그대로(2026-09-18)
    _long = ('It was on a very unfriendly world that the little babe opened '
             'his eyes, and the mighty Nile rolled between its reedy banks, '
             'reflecting on its broad bosom the deep azure of the heavens.')
    _mix = (_long + '\n\nPast that cottage-home would go royal\n'
            'processions, as in solemn state the monarch\nwent forth to war.')
    _got = unwrap(_mix, 1, 55, mixed=True)
    t('★ 섞인 글 — 하드랩 문단을 잇는다',
      'royal processions, as in solemn state the monarch went forth' in _got)
    t('★ 섞인 글 — 이미 풀린 문단은 안 건드린다', _long in _got)
    t('★ 섞인 글도 낱말은 그대로(공백만 바꾼다)',
      words(_got) == words(_mix))
    t('★ mixed 는 두 번 돌려도 같다(멱등)',
      unwrap(_got, 1, 55, mixed=True) == _got)
    t('★ mixed 를 안 켜면 옛 동작 그대로', unwrap(_mix, 1, 55) == _mix)

    print('db_book_unwrap selftest', 'OK' if ok else 'FAIL')
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--scan', action='store_true')
    ap.add_argument('--check', nargs='*')
    ap.add_argument('--apply', nargs='*')
    ap.add_argument('--restore', nargs='*')
    a = ap.parse_args()
    if a.selftest:
        raise SystemExit(0 if selftest() else 1)
    conn = appdb.connect()
    if a.scan:
        scan(conn)
    elif a.restore is not None:
        for c in (a.restore or list(PROFILE)):
            restore(conn, c)
    else:
        codes = a.check if a.check is not None else a.apply
        codes = codes or list(PROFILE)
        for c in codes:
            apply(conn, c, dry=(a.apply is None))
    conn.close()


if __name__ == '__main__':
    main()
