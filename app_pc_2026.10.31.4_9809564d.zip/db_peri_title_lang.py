# -*- coding: utf-8 -*-
"""db_peri_title_lang.py — 페리코프 제목의 **다국어 오역**을 본문으로 잡아낸다 (영구 도구)

왜 필요한가
    제목은 3,413개 × 11개 언어 = **37,543행**이다. 눈으로 볼 수 없다.
    그런데 실제로 이런 것들이 들어 있었다(2026-08-03 실측).
        마 16:1-4 「표적을 구하다」  JA 看板への需要(가게 간판) · ES letrero(간판)
                                    RU вывеска(간판) · ZH 对标志的需求(로고)
        마 17:14-18 「귀신 들린 아이」 ZH **与恶魔同行 = 악마와 함께 걷다**
        마 17:1-13 「산에서 변형되시다」 ZH **变形记 = 카프카 소설 제목**
    영어 sign 을 낱말만 보고 옮기면 간판이 된다. **낱말이 아니라 그 단락이
    무엇을 말하는지를 보아야** 하고, 그 답은 그 언어 성경 본문 안에 이미 있다.

원리 — 자료가 스스로 정답을 말한다 (`db_commentary_audit` 와 같은 방식)
    제목에 쓰인 알맹이 낱말은 **그 언어 성경이 그 단락에서 실제로 쓰는 낱말**이어야 한다.
    CUV 는 마 16:1 에서 `神蹟` 을 쓰지 `标志` 를 쓰지 않는다. RusSyn 은 `знамение` 을
    쓰지 `вывеска` 를 쓰지 않는다. 그러니 제목 낱말이 본문에 몇이나 박혀 있는지를 세면
    외부 사전 없이 오역이 드러난다.

    그리고 **언어끼리 견준다**(사용자 지시). 같은 단락에서 아홉 언어가 잘 박히는데
    한 언어만 0 이면, 그 하나가 틀린 것이다. 절대 점수가 아니라 **편차**로 잡는다.

⚠ 이 도구가 하는 일과 못 하는 일
    한다   37,543 행을 **사람이 볼 만한 목록으로 줄인다.**
    못 한다 옳고 그름을 판정한다. 특히 **중국어는 맞는 제목도 0 점이 나온다** —
           和合本 표제 `登山变像` 이 CUVS 본문 `变了形像` 과 두 글자 뭉치가 어긋나
           0/3 이었다(2026-08-03). 그래서 ZH·ZHT 는 ERROR 로 올리지 않고 CHECK 까지만 한다.
    판정   ERROR = 낱말 경계가 있는 언어에서 하나도 안 박힘 → 거의 확실히 틀림
           CHECK = 남들과 어긋남 → **사람이 본문과 대조해야 한다**

본문이 있는 언어 / 없는 언어
    있음(9) KO=KRV · EN=BSB · ZH=CUVS · ZHT=CUV · ES=SpaRV · RU=RusSyn
            DE=GerElb · FR=FreLSG · PT=PorBL · AR=ARB
    없음(1) **JA — JLV 가 껍데기(신약 0행)** 라 본문 정박을 못 한다.
            JA 는 한자 겹침으로 ZH/ZHT 와 견주는 보조 검사만 한다(§JA).

쓰는 법
    python db_peri_title_lang.py --selftest            탐지력 검증 (의무)
    python db_peri_title_lang.py --scan --book 40      한 책 점검
    python db_peri_title_lang.py --scan                전권 점검
    python db_peri_title_lang.py --show 7357           한 페리코프 11개 언어 나란히
    python db_peri_title_lang.py --apply fixes.json    교정 적재

⚠ `--apply` 는 DB 를 쓴다. 워크트리에서 실행하지 말 것(CLAUDE.md §1).
"""
from __future__ import annotations
import argparse, json, io, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb

DB = 'bible_master.db'

# 언어 → 그 언어 성경 (본문 정박의 기준). JA 는 본문이 없다.
LANG_VER = {
    'KO': 'KRV', 'EN': 'BSB', 'ZH': 'CUVS', 'ZHT': 'CUV', 'ES': 'SpaRV',
    'RU': 'RusSyn', 'DE': 'GerElb', 'FR': 'FreLSG', 'PT': 'PorBL', 'AR': 'ARB',
}
NO_TEXT = ('JA',)
ALL_LANGS = list(LANG_VER) + list(NO_TEXT)

CJK = ('ZH', 'ZHT', 'JA', 'KO')

# 제목에 흔한 기능어 — 알맹이가 아니므로 점수에서 뺀다.
STOP = {
 'KO': {'대한','위한','것은','것이','하다','하시다','되다','에서','으로','에게','그리고','그의','이는'},
 'EN': {'the','of','and','a','an','to','in','for','with','on','at','by','his','her','their','is','are','who','that','from'},
 'ES': {'el','la','los','las','de','del','y','un','una','en','a','que','con','por','su','sus'},
 'PT': {'o','a','os','as','de','do','da','dos','das','e','um','uma','em','com','por','seu','sua','que'},
 'FR': {'le','la','les','de','du','des','et','un','une','en','a','au','aux','qui','que','son','sa','ses','dans','pour'},
 'DE': {'der','die','das','des','dem','den','und','ein','eine','einem','einen','von','zu','im','in','mit','fur','fur','auf'},
 'RU': {'и','в','на','с','о','об','по','к','из','от','его','ее','их','что','который'},
 'AR': {'في','من','على','الى','عن','مع','ال'},
}
PREFIX = 5    # 굴절어는 앞 5글자만 맞으면 같은 낱말로 본다 (знамение/знамения)

# ⚠ 아랍어 본문(ARB)에는 모음기호가 촘촘히 붙어 있는데(وَجَاءَ) 제목에는 없다.
#   그대로 대조하면 **아랍어가 전부 빗나간다**(2026-08-03 실측 — 3/3·2/2 전멸).
#   글자만 남기고 기호를 떼어 낸 뒤 견준다.
_AR_MARKS = re.compile(r'[ؐ-ًؚ-ٰٟۖ-ۭـ]')


def strip_ar(t):
    """모음기호 제거 + 알리프/타마르부타 정규화.

    ⚠ 이것만으로는 모자란다(2026-08-03 실측 — 153개 중 105개가 헛걸림).
      ① 본문은 알리프 와슬라 `ٱ` 를 쓰는데 제목은 보통 `ا` 를 쓴다.
      ② 제목에는 정관사가 붙고(`المجوس`) 본문에는 안 붙는다(`مجوس`).
      둘 다 처리하지 않으면 아랍어는 통째로 못 쓴다.
    """
    t = _AR_MARKS.sub('', t or '')
    for a in 'ٱأإآ':
        t = t.replace(a, 'ا')
    return t.replace('ة', 'ه').replace('ى', 'ي')


_AR_PRE = ('وال', 'فال', 'بال', 'كال', 'لل', 'ال', 'و', 'ف', 'ب', 'ك', 'ل')


def ar_stem(w):
    """정관사·접속사 접두사를 떼어 낸 어간."""
    w = strip_ar(w)
    for p in _AR_PRE:
        if len(w) > len(p) + 2 and w.startswith(p):
            return w[len(p):]
    return w


# ── 토큰 ──────────────────────────────────────────────────────────────
def tokens(text, lang):
    """제목에서 알맹이 낱말만 뽑는다."""
    if not text:
        return []
    if lang in ('ZH', 'ZHT', 'JA'):
        # 한자 두 글자 뭉치 — 띄어쓰기가 없어 n-gram 으로 본다
        han = re.findall(r'[一-鿿]+', text)
        out = []
        for run in han:
            out += [run[i:i+2] for i in range(len(run) - 1)] if len(run) > 1 else [run]
        return out
    if lang == 'KO':
        return [w for w in re.findall(r'[가-힣]{2,}', text) if w not in STOP['KO']]
    if lang == 'AR':
        w = re.findall(r'[ؠ-ي]{3,}', strip_ar(text))
        return [x for x in w if x not in STOP['AR']]
    words = re.findall(r'[^\W\d_]{2,}', text.lower(), re.UNICODE)
    return [w for w in words if w not in STOP.get(lang, set())]


def anchored(tok, body, lang):
    """이 낱말이 본문에 박혀 있는가."""
    if lang == 'AR':
        return ar_stem(tok)[:4] in strip_ar(body)
    if lang in ('ZH', 'ZHT', 'JA'):
        return tok in body
    if lang == 'KO':
        return tok[:2] in body                      # 조사가 붙으므로 어간만
    return tok[:PREFIX] in body if len(tok) > PREFIX else tok in body


def score(title, body, lang):
    """(박힌 수, 전체 수, 비율). 알맹이가 없으면 (0,0,None)."""
    ts = tokens(title, lang)
    if not ts:
        return 0, 0, None
    hit = sum(1 for t in ts if anchored(t, body, lang))
    if lang in ('ZH', 'ZHT', 'JA'):
        # n-gram 은 하나만 박혀도 그 낱말을 아는 것으로 본다
        return hit, len(ts), (1.0 if hit else 0.0)
    return hit, len(ts), hit / len(ts)


# ── DB ────────────────────────────────────────────────────────────────
def body_text(conn, ver, s, e):
    rows = conn.execute(
        'SELECT verse_text FROM bible_content WHERE version_code=? '
        'AND verse_id BETWEEN ? AND ?', (ver, s, e)).fetchall()
    return ' '.join((r[0] or '') for r in rows).lower()


def titles_of(conn, pid):
    return {lg: t for lg, t in conn.execute(
        "SELECT lang_code, title FROM sys_text_asset WHERE text_type='PERI_TITLE' "
        "AND clicked_id=? AND record_status='LIVE'", (pid,))}


def peris(conn, book=None):
    sql = ("SELECT p.pericope_id, p.start_vid, p.end_vid, bi.bcode, bi.chapter, bi.verse "
           "FROM sys_pericope_asset p JOIN bible_index bi ON bi.verse_id=p.start_vid "
           "WHERE p.peri_type='BODY' AND p.record_status='LIVE' ")
    if book:
        sql += f"AND bi.bcode={int(book)} "
    return conn.execute(sql + "ORDER BY p.start_vid").fetchall()


# ── 점검 ──────────────────────────────────────────────────────────────
def check_peri(conn, pid, s, e, cache=None, override=None):
    """한 페리코프의 언어별 정박 점수 + 편차 판정.
       override 는 자가 검사용 — 제목을 바꿔 끼워 실제 판정 경로를 그대로 태운다."""
    tt = titles_of(conn, pid)
    if override:
        tt = dict(tt); tt.update(override)
    res = {}
    for lg, ver in LANG_VER.items():
        if lg not in tt:
            continue
        key = (ver, s, e)
        if cache is not None:
            body = cache.get(key)
            if body is None:
                body = cache[key] = body_text(conn, ver, s, e)
        else:
            body = body_text(conn, ver, s, e)
        h, n, r = score(tt[lg], body, lg)
        res[lg] = {'title': tt[lg], 'hit': h, 'n': n, 'ratio': r}

    # ── 편차 판정 (사용자 지시: 다른 버전과 차이가 크면 오류로 본다)
    rs = [v['ratio'] for v in res.values() if v['ratio'] is not None]
    med = sorted(rs)[len(rs) // 2] if rs else None
    for lg, v in res.items():
        v['verdict'] = ''
        if v['ratio'] is None:
            continue
        # ⚠ 절대 점수로 재지 않는다. 요약형 제목(「4천 명을 먹이신 기적」)은 본문 낱말을
        #   안 써도 정상이라 낮게 나온다(KO 7356 실측 0/3). **언어끼리 견주는 편차**만 쓴다.
        if v['ratio'] == 0.0 and med is not None and med >= 0.5:
            # ⚠ 한중일은 ERROR 로 올리지 않는다. 띄어쓰기가 없어 두 글자 뭉치로 재는데,
            #   **맞는 제목도 0 이 나온다** — 和合本 표제 `登山变像` 이 CUVS 본문
            #   `变了形像` 과 뭉치가 어긋나 0/3 이었다(2026-08-03 실측).
            #   그래서 CJK 는 「사람이 보라」까지만 하고 판정하지 않는다.
            v['verdict'] = 'CHECK' if lg in ('ZH', 'ZHT') else 'ERROR'
        elif med is not None and v['ratio'] < med - 0.3:
            v['verdict'] = 'CHECK'      # 일부만 어긋난다 — 사람이 본다
    if 'JA' in tt:
        res['JA'] = {'title': tt['JA'], 'hit': 0, 'n': 0, 'ratio': None,
                     'verdict': ja_verdict(tt, res)}
    return res, med


def ja_verdict(tt, res):
    """§JA — 일본어는 본문이 없다(JLV 껍데기). 한자를 ZH/ZHT 와 견주는 보조 검사만.

    ZH/ZHT 가 본문에 잘 박혀 있는데 JA 가 그 한자를 하나도 안 쓰면 갈라진 것이다.
    한자를 안 쓰고 가나로만 적은 제목은 판정하지 않는다(정상일 수 있다).
    """
    ja = set(re.findall(r'[一-鿿]', tt.get('JA') or ''))
    if not ja:
        return ''
    ref = set()
    for lg in ('ZHT', 'ZH'):
        if res.get(lg, {}).get('ratio') == 1.0:
            ref |= set(re.findall(r'[一-鿿]', tt.get(lg) or ''))
    if not ref:
        return ''
    return '' if (ja & ref) else 'CHECK_JA'


# ── 자가 검사 ─────────────────────────────────────────────────────────
def selftest(conn):
    """⚠ 의무. 아는 오역을 못 잡으면 이 도구는 쓸모가 없다.
       (`temp_code_greek_check` 가 어휘집이 빈 채 수십 번 PASS 를 찍은 전례가 있다.)

    ★ 반드시 **실제 판정 경로**(check_peri 의 편차 비교)를 태운다. 점수만 따로 재면
      요약형 제목이 죄다 오탐으로 뜬다 — 첫 판에 실제로 그랬다(2026-08-03).
    """
    print('자가 검사 — 아는 오역/정상 제목을 바꿔 끼워 실제 판정을 본다\n')
    cases = [
        (7357, 'ZH',  '对标志的需求',                      'CHECK'),  # 실제 오역이나 CJK 는 CHECK 까지
        (7357, 'RU',  'Требование о вывеске',            'ERROR'),  # 실제 오역(간판)
        (7357, 'ZH',  '求神迹',                            ''),      # CUVS 본문 낱말
        (7357, 'RU',  'Требование знамения',             ''),      # RusSyn 본문 낱말
        (7357, 'DE',  'Die Forderung nach einem Zeichen', ''),      # 정상
        (7363, 'ZH',  '与恶魔同行',                        'CHECK'),  # 실제 오역(악마와 동행)
        (7363, 'ZH',  '被鬼附的孩子',                       ''),      # CUVS 본문 낱말
        (7362, 'ZH',  '变形记',                            'CHECK'),  # 카프카 소설
        (7362, 'ZH',  '登山变像',                          'CHECK'),  # ★ 맞는 제목도 CHECK 로 뜬다(한계)
    ]
    ok = 0
    for pid, lg, title, want in cases:
        r = conn.execute('SELECT start_vid,end_vid FROM sys_pericope_asset WHERE pericope_id=?',
                         (pid,)).fetchone()
        res, med = check_peri(conn, pid, r[0], r[1], override={lg: title})
        got = res[lg]['verdict']
        good = (got == want) if want else (got != 'ERROR')
        ok += good
        print('  %-4s %-34s %d/%-2d  중앙 %.2f  판정 %-6s %s'
              % (lg, title[:34], res[lg]['hit'], res[lg]['n'], med or 0,
                 got or '정상', 'O' if good else 'X  ← 틀림'))
    print('\n  %d/%d 통과' % (ok, len(cases)))
    return ok == len(cases)


# ── 출력 ──────────────────────────────────────────────────────────────
def show(conn, pid):
    r = conn.execute('SELECT start_vid,end_vid FROM sys_pericope_asset WHERE pericope_id=?',
                     (pid,)).fetchone()
    res, med = check_peri(conn, pid, r[0], r[1])
    print(f'peri {pid}  (언어 중앙 정박률 {med})')
    for lg in ALL_LANGS:
        if lg in res:
            v = res[lg]
            print('  %-4s %-40s %s %s' % (
                lg, (v['title'] or '')[:40],
                ('%d/%d' % (v['hit'], v['n'])) if v['n'] else '  - ',
                v['verdict']))


def scan(conn, book, limit):
    cache, bad, n_peri = {}, [], 0
    for pid, s, e, bc, ch, vs in peris(conn, book):
        n_peri += 1
        res, med = check_peri(conn, pid, s, e, cache)
        for lg, v in res.items():
            if v['verdict']:
                bad.append((pid, f'{bc} {ch}:{vs}', lg, v['title'], v['verdict']))
        if len(cache) > 400:
            cache.clear()
    print(f'페리코프 {n_peri}개 · 언어 {len(ALL_LANGS)}개 = 제목 {n_peri*len(ALL_LANGS)}행 점검\n')
    by_lang, by_verdict = {}, {}
    for _, _, lg, _, vd in bad:
        by_lang[lg] = by_lang.get(lg, 0) + 1
        by_verdict[vd] = by_verdict.get(vd, 0) + 1
    print('판정별:', ' · '.join(f'{k} {v}' for k, v in sorted(by_verdict.items())))
    print('언어별:', ' · '.join(f'{k} {v}' for k, v in sorted(by_lang.items(), key=lambda x: -x[1])))
    print()
    for row in bad[:limit]:
        print('  [%s] peri %-5s %-9s %-4s %s' % (row[4], row[0], row[1], row[2], row[3][:46]))
    if len(bad) > limit:
        print(f'  … 외 {len(bad)-limit}건')
    return bad


# ── 이름 미번역 (§8-2) ────────────────────────────────────────────────
# 영어 성경이 실제로 쓰는 고유명사가 대상 언어 제목에 **영어 철자 그대로** 남았는데
# 그 언어 성경에는 그 철자가 없는 경우. 판단이 필요 없는 객관적 오류다.
#   Sarah→SpaRV `Sara` · Hagar→FreLSG `Agar` · Moses→GerElb `Mose` · Babylon→`Babel`
# ⚠ 라틴문자 언어만 대상. 다른 문자권은 철자 비교 자체가 성립하지 않는다.
NAME_LANGS = ('ES', 'PT', 'FR', 'DE')
_EN_STOP = {'the','of','and','a','an','to','in','for','with','on','at','by','his','her',
            'who','is','from','into','are','that','be','not','but','as','it','he','she'}


def _en_proper(text, accents=False):
    """문장 첫 낱말을 뺀 대문자 낱말 = 고유명사.

    ⚠ accents=True 를 안 주면 **스페인어·포르투갈어 이름이 잘린다**
      (2026-08-03 실측 — Gosén→`Gos` · Leví→`Lev` · Sehón→`Seh`).
      영어 쪽은 ASCII 만 봐야 하므로 기본은 꺼 둔다.
    """
    pat = r"[A-Za-zÀ-ÿ]+" if accents else r"[A-Za-z]+"
    out = set()
    for sent in re.split(r'(?<=[.!?])\s+', text or ''):
        for i, w in enumerate(re.findall(pat, sent)):
            if i > 0 and w[:1].isupper():
                out.add(w)
    return out


def _sim(a, b):
    """두 이름이 같은 이름의 다른 표기인가 (0~1)."""
    import unicodedata, difflib
    n = lambda x: ''.join(c for c in unicodedata.normalize('NFD', x.lower())
                          if unicodedata.category(c) != 'Mn')
    return difflib.SequenceMatcher(None, n(a), n(b)).ratio()


SIM_MIN = 0.55    # 이보다 낮으면 자동 교체하지 않는다 — 같은 절의 **짝 이름**을 집을 수 있다
                  # (Zebah→Zalmunna · Abednego→Mesach · Anath→Samgar 가 실제로 그랬다)


def scan_names(conn, book=None):
    """제목에 영어 철자가 남은 이름을 찾는다."""
    cache, bad = {}, []
    for pid, s, e, bc, ch, vs in peris(conn, book):
        tt = titles_of(conn, pid)
        en_t = tt.get('EN', '')
        cand = [w for i, w in enumerate(re.findall(r"[A-Za-z]+", en_t))
                if i > 0 and w[:1].isupper() and w.lower() not in _EN_STOP and len(w) > 2]
        if not cand:
            continue
        key = ('BSB', s, e)
        eb = cache.setdefault(key, body_text(conn, 'BSB', s, e))
        # 원문 대소문자가 필요해 다시 읽는다(body_text 는 소문자로 내린다)
        raw = ' '.join((r[0] or '') for r in conn.execute(
            'SELECT verse_text FROM bible_content WHERE version_code=? AND verse_id BETWEEN ? AND ?',
            ('BSB', s, e)))
        real = _en_proper(raw)
        names = [n for n in set(cand) if n in real]
        if not names:
            continue
        for lg in NAME_LANGS:
            tgt = tt.get(lg, '')
            if not tgt:
                continue
            b = cache.setdefault((LANG_VER[lg], s, e), body_text(conn, LANG_VER[lg], s, e))
            if not b:
                continue
            for nm in names:
                if re.search(r'\b' + re.escape(nm) + r'\b', tgt) and nm.lower() not in b:
                    bad.append((pid, s, e, lg, nm, tgt))
        if len(cache) > 400:
            cache.clear()
    return bad


def learn_name(conn, lang, name, cap=400):
    """성경 전체에서 이 영어 이름과 함께 나오는 대상 언어 낱말을 세어 대응을 찾는다.

    이름은 여러 곳에 나오므로 공기(共起) 빈도가 분명하게 갈린다.
    `db_verse_align_cross` 가 쓰는 것과 같은 원리다.
    """
    ver = LANG_VER[lang]
    rows = conn.execute(
        "SELECT b.verse_id, b.verse_text FROM bible_content b "
        "WHERE b.version_code='BSB' AND b.verse_text LIKE ? LIMIT ?",
        (f'%{name}%', cap)).fetchall()
    vids = [v for v, t in rows if re.search(r'\b' + re.escape(name) + r'\b', t or '')]
    if len(vids) < 2:
        return None
    hit = {}
    for vid in vids:
        r = conn.execute('SELECT verse_text FROM bible_content WHERE version_code=? AND verse_id=?',
                         (ver, vid)).fetchone()
        for w in _en_proper(r[0] if r else '', accents=True):
            hit[w] = hit.get(w, 0) + 1
    if not hit:
        return None
    # 그 낱말이 전체에서 얼마나 흔한지로 나눠 준다 — 흔한 낱말(Jesus 등)이 이기지 않게
    best, best_sc = None, 0.0
    for w, n in hit.items():
        if n < max(2, len(vids) * 0.5):
            continue
        tot = conn.execute('SELECT COUNT(*) FROM bible_content WHERE version_code=? '
                           'AND verse_text LIKE ?', (ver, f'%{w}%')).fetchone()[0]
        sc = n / (tot or 1)
        if sc > best_sc:
            best, best_sc = w, sc
    return best


def names_fix(conn, book, out_path):
    bad = scan_names(conn, book)
    print(f'이름 미번역 후보 {len(bad)}건')
    learned, fixes, unknown = {}, {}, []
    for pid, s, e, lg, nm, tgt in bad:
        k = (lg, nm)
        if k not in learned:
            learned[k] = learn_name(conn, lg, nm)
        rep = learned[k]
        if not rep or rep.lower() == nm.lower():
            unknown.append((pid, lg, nm, tgt, '대응 없음')); continue
        if _sim(nm, rep) < SIM_MIN:
            unknown.append((pid, lg, nm, tgt, f'닮지 않음 → {rep}')); continue
        new = re.sub(r'\b' + re.escape(nm) + r'\b', rep, tgt)
        if new != tgt:
            fixes.setdefault(str(pid), {})[lg] = new
    print(f'  대응을 찾은 것 {sum(len(v) for v in fixes.values())}건 · 못 찾은 것 {len(unknown)}건')
    json.dump(fixes, io.open(out_path, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    print(f'  → {out_path}')
    seen = set()
    print('\n  배운 대응(중복 제외):')
    for (lg, nm), rep in sorted(learned.items()):
        if rep and rep.lower() != nm.lower() and (lg, nm) not in seen:
            seen.add((lg, nm)); print('    %-3s %-14s → %s' % (lg, nm, rep))
    if unknown:
        print('\n  대응을 못 찾아 그대로 둔 것 %d건 (앞 10):' % len(unknown))
        for pid, lg, nm, t, why in unknown[:14]:
            print('    peri %-5s %-3s %-12s %-22s %s' % (pid, lg, nm, why, t[:34]))
    return fixes


def apply_fixes(conn, path):
    data = json.load(io.open(path, encoding='utf-8'))
    n = 0
    for pid, langs in data.items():
        for lg, new in langs.items():
            cur = conn.execute(
                "SELECT title FROM sys_text_asset WHERE text_type='PERI_TITLE' "
                "AND clicked_id=? AND lang_code=? AND record_status='LIVE'", (int(pid), lg)).fetchone()
            if not cur:
                print(f'  ! peri {pid} {lg} 행이 없다 — 건너뜀'); continue
            if cur[0] == new:
                continue
            conn.execute("UPDATE sys_text_asset SET title=? WHERE text_type='PERI_TITLE' "
                         "AND clicked_id=? AND lang_code=? AND record_status='LIVE'",
                         (new, int(pid), lg))
            print(f'  peri {pid} [{lg}] {cur[0]} -> {new}')
            n += 1
    conn.commit()
    print(f'\n{n}행 갱신')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--scan', action='store_true')
    ap.add_argument('--show', type=int)
    ap.add_argument('--apply')
    ap.add_argument('--names-fix', metavar='OUT')
    ap.add_argument('--book', type=int)
    ap.add_argument('--limit', type=int, default=60)
    a = ap.parse_args()
    conn = appdb.connect(DB)
    if a.selftest:
        sys.exit(0 if selftest(conn) else 1)
    if a.names_fix:
        names_fix(conn, a.book, a.names_fix); return
    if a.show:
        show(conn, a.show)
    elif a.apply:
        apply_fixes(conn, a.apply)
    elif a.scan:
        scan(conn, a.book, a.limit)
    else:
        ap.print_help()


if __name__ == '__main__':
    main()
