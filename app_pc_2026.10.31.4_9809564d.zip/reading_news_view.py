# -*- coding: utf-8 -*-
"""오늘의 묵상 / 교계 뉴스 — 사용자 화면 (P1 최상위 탭 '오늘의 묵상').

설계 (CLAUDE.md §21 트랙 B, 자동번역 저작권 원칙):
- 앱은 '링크만 전달' — 콘텐츠를 가로채/가공/배포하지 않는다. 클릭 시 외부 브라우저로 원본 열기.
- 본문 번역은 이용자 브라우저(크롬) 자체 번역 기능 사용(가장 안전). 앱은 본문 미저장/미가공.
- 제목 자동번역(translate_a/single)은 각 사용자 로컬(user_data.db) 캐시(사적 이용, 비공유).
- 실시간 fetch + 로컬 누적 캐시 → 서버 없이 매일 최신.
"""
import os
import subprocess
import threading
import webbrowser
import tkinter as tk
from tkinter import ttk, messagebox

import appdb
import rss_reader as R

try:
    import i18n
    _t = i18n.t
except Exception:
    def _t(k, d=''):
        return d

_DISCLAIMER = ('본 앱은 링크 정보만 제공합니다. 클릭 시 원본 사이트가 브라우저로 열립니다. '
               '제목 번역은 Powered by Google Translate(기계번역)이며 부정확할 수 있습니다. '
               '본문 번역은 브라우저(크롬)의 번역 기능을 사용하세요. 저작권은 각 사이트에 있습니다.')
_YT_NOTICE = ('본 앱은 YouTube 공식 임베드 플레이어로 영상을 재생하며, 영상의 제목·썸네일·저작권은 '
              '각 채널과 YouTube에 있습니다. 본 앱은 영상을 저장·배포하지 않습니다. '
              'YouTube™는 Google LLC의 상표입니다.')

_PAGE = 50   # 한 번에 표시 개수


def _quiet(msg):
    """오류를 조용히 알린다 — **`print` 를 쓰지 않는다**(§193차 ⑧).

    ⚠⚠ 이 앱은 실행 중에 `sys.stdout` 을 닫는다(§97차). 그 뒤 `print` 는
    `ValueError: I/O operation on closed file` 을 내는데, 여기가 데몬 실이면
    그 예외가 아무도 안 잡는 자리에서 다시 터진다(실측으로 재현했다).
    ⇒ stderr 에 쓰고 그것도 실패하면 조용히 넘어간다. **알리는 일이 앱을
      죽이면 안 된다.**
    """
    try:
        import sys as _s
        _s.stderr.write('%s\n' % msg)
    except Exception:
        pass


def _cfg_get(db, key, default=''):
    try:
        with appdb.connect(db) as c:
            r = c.execute("SELECT config_val FROM user_config WHERE config_key=?", (key,)).fetchone()
        return r[0] if r else default
    except Exception:
        return default


def _cfg_set(db, key, val):
    try:
        with appdb.connect(db) as c:
            c.execute("INSERT INTO user_config(config_key,config_val) VALUES(?,?) "
                      "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                      (key, str(val)))
            c.commit()
    except Exception:
        pass


def _find_chrome():
    """Windows에서 chrome.exe 경로 (위치 지정 실행용). 없으면 None."""
    if os.name != 'nt':
        return None
    for c in (os.path.expandvars(r'%ProgramFiles%\Google\Chrome\Application\chrome.exe'),
              os.path.expandvars(r'%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe'),
              os.path.expandvars(r'%LocalAppData%\Google\Chrome\Application\chrome.exe')):
        if c and os.path.exists(c):
            return c
    try:
        import winreg
        for hive in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
            try:
                k = winreg.OpenKey(hive, r'SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe')
                p, _ = winreg.QueryValueEx(k, '')
                if p and os.path.exists(p):
                    return p
            except Exception:
                pass
    except Exception:
        pass
    return None


def _open_external(top, url):
    """원본을 외부 브라우저로 — 가능하면 화면 우측에 배치(앱 왼쪽 안 가림). 폴백 기본 브라우저."""
    try:
        chrome = _find_chrome()
        if chrome and top is not None:
            sw = top.winfo_screenwidth()
            sh = top.winfo_screenheight()
            x = sw // 3   # 왼쪽 1/3은 앱 영역, 오른쪽 2/3을 브라우저로
            w = max(sw - x - 8, 480)
            h = max(sh - 80, 400)
            subprocess.Popen([chrome, '--new-window',
                              f'--window-position={x},30', f'--window-size={w},{h}', url])
            return
    except Exception:
        pass
    try:
        webbrowser.open(url)
    except Exception:
        pass


class ReadingNewsView(ttk.Frame):
    """P1 '최신 콘텐츠' 탭 — 내부에 최신묵상/최신뉴스/최신유튜브/즐겨찾기 서브탭."""
    def __init__(self, master, db_path, lang_getter=None):
        super().__init__(master)
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        # [방식 A] 새 코드 확인용 표시 + 자가복구: 폐지된 자체수집(fetch_live) 잔재(feed_id≠NULL) 1회 제거.
        # 관리자 배포분은 모두 feed_id=NULL 이므로 feed_id≠NULL 행은 옛 자체수집 잔재 → 안전 삭제.
        _quiet('[ReadingNews] build — 자체수집 폐지·언어별 동기화 (NEW CODE)')
        try:
            with appdb.connect(db_path) as _c:
                d = _c.execute("DELETE FROM user_rss_cache WHERE feed_id IS NOT NULL "
                               "AND feed_kind IN ('DEVOTIONAL','NEWS','YOUTUBE')").rowcount
                _c.commit()
                if d:
                    _quiet(f'[ReadingNews] 옛 자체수집 잔재 {d}건 자동 정리')
        except Exception as _e:
            _quiet('[ReadingNews] 자가복구 오류: %s' % _e)
        nb = ttk.Notebook(self)
        nb.pack(fill='both', expand=True)
        self._dev = _KindPanel(nb, db_path, 'DEVOTIONAL', self.lang_getter)
        self._news = _KindPanel(nb, db_path, 'NEWS', self.lang_getter)
        self._yt = _KindPanel(nb, db_path, 'YOUTUBE', self.lang_getter)
        self._fav = _FavoritesPanel(nb, db_path, self.lang_getter)
        nb.add(self._dev,  text=' ' + _t('RN_TAB_DEVOTION', '최신 묵상') + ' ')
        nb.add(self._news, text=' ' + _t('RN_TAB_NEWS', '최신 뉴스') + ' ')
        nb.add(self._yt,   text=' ▶ ' + _t('RN_TAB_YOUTUBE', '최신 유튜브') + ' ')
        nb.add(self._fav,  text=' ★ ' + _t('RN_TAB_FAV', '즐겨찾기') + ' ')


class _KindPanel(ttk.Frame):
    def __init__(self, master, db_path, kind, lang_getter):
        super().__init__(master)
        self.db_path = db_path
        self.kind = kind
        self.lang_getter = lang_getter
        self._busy = False
        self._all = []          # 전체 항목
        self._items = []        # 현재 표시 슬라이스
        self._shown = _PAGE     # 표시 개수
        self._first_shown = False
        self._player = None     # 유튜브 인라인 플레이어(YOUTUBE 탭, 지연 생성)
        self._build()
        self.bind('<Map>', self._on_first_map)
        self.bind('<Destroy>', self._on_destroy)

    # ── 설정 헬퍼 ────────────────────────────────────────────────
    def _excluded(self):
        raw = _cfg_get(self.db_path, 'RSS_EXCLUDE_FEEDS', '')
        return {int(x) for x in raw.split(',') if x.strip().isdigit()}

    def _tr_lang(self):
        # 제목 언어(어느 언어 파일을 받을지). 기본 = 사용자 UI 언어. 설정에서 변경 가능.
        return _cfg_get(self.db_path, 'RSS_TRANSLATE_LANG', '') or (self.lang_getter() or 'KO')

    # ── 유튜브 채널 표시제외 / 즐겨찾기 (채널명 set, JSON 저장) ────────
    # ★ 2026-10-24 docs/4.txt — 「최신 유튜브」의 채널 즐겨찾기·제외를 **폰과 같은 표**로(media_pref ·
    #   user_channel_fav / user_channel_hide · 동기화로 폰에도 간다). 그전에는 이 화면만 따로
    #   user_config(YT_FAV_CHANNELS · YT_EXCLUDE_CHANNELS)에 적어 온라인 영상·폰과 갈렸다.
    #   옛 값은 처음 읽을 때 표로 옮기고 그 열쇠를 비운다(멱등).
    _CHAN_TBL = {'YT_FAV_CHANNELS': 'user_channel_fav', 'YT_EXCLUDE_CHANNELS': 'user_channel_hide'}

    def _yt_chan_set(self, key):
        import json as _j
        tbl = self._CHAN_TBL[key]
        try:
            with appdb.connect(self.db_path) as c:
                import media_pref as _MP
                _MP.init(c)
                v = _cfg_get(self.db_path, key, '')
                old = _j.loads(v) if v else []
                if isinstance(old, list) and old:
                    for n in old:
                        if str(n).strip():
                            c.execute('INSERT OR IGNORE INTO userdb.%s(channel_name) VALUES(?)' % tbl, (str(n).strip(),))
                    c.commit()
                    _cfg_set(self.db_path, key, '')
                return {r[0] for r in c.execute('SELECT channel_name FROM userdb.%s' % tbl) if r[0]}
        except Exception:
            return set()

    def _yt_chan_save(self, key, s):
        tbl = self._CHAN_TBL[key]
        try:
            with appdb.connect(self.db_path) as c:
                have = {r[0] for r in c.execute('SELECT channel_name FROM userdb.%s' % tbl)}
                for n in set(s) - have:
                    c.execute('INSERT OR IGNORE INTO userdb.%s(channel_name) VALUES(?)' % tbl, (n,))
                for n in have - set(s):
                    c.execute('DELETE FROM userdb.%s WHERE channel_name=?' % tbl, (n,))
                c.commit()
        except Exception as e:
            _quiet('[ReadingNews] chan save: %s' % e)

    def _excluded_channels(self):
        return self._yt_chan_set('YT_EXCLUDE_CHANNELS')

    def _fav_channels(self):
        return self._yt_chan_set('YT_FAV_CHANNELS')

    def _cur_site(self):
        """현재 선택된 항목의 채널명(site)."""
        sel = self._tv.selection()
        if not sel:
            return ''
        try:
            return self._items[int(sel[0])].get('site', '')
        except (ValueError, IndexError):
            return ''

    def _yt_exclude_current(self):
        site = self._cur_site()
        if not site:
            messagebox.showinfo(_t('RN_TAB_YOUTUBE', '최신 유튜브'),
                                _t('RN_PICK_FIRST', '먼저 목록에서 채널(영상)을 선택하세요.'),
                                parent=self.winfo_toplevel())
            return
        s = self._excluded_channels()
        s.add(site)
        self._yt_chan_save('YT_EXCLUDE_CHANNELS', s)
        # 즐겨찾기에서 제거(상충 방지)
        fav = self._fav_channels()
        if site in fav:
            fav.discard(site)
            self._yt_chan_save('YT_FAV_CHANNELS', fav)
        self._load_cache_now()

    def _yt_fav_current(self):
        site = self._cur_site()
        if not site:
            messagebox.showinfo(_t('RN_TAB_YOUTUBE', '최신 유튜브'),
                                _t('RN_PICK_FIRST', '먼저 목록에서 채널(영상)을 선택하세요.'),
                                parent=self.winfo_toplevel())
            return
        fav = self._fav_channels()
        if site in fav:
            fav.discard(site)          # 토글: 이미 즐겨찾기면 해제
        else:
            fav.add(site)
            ex = self._excluded_channels()
            if site in ex:
                ex.discard(site)
                self._yt_chan_save('YT_EXCLUDE_CHANNELS', ex)
        self._yt_chan_save('YT_FAV_CHANNELS', fav)
        self._load_cache_now()

    def _yt_manage_channels(self):
        """채널 관리 — 즐겨찾는 채널 · 표시 제외 · 내가 모은 채널(2026-10-24 docs/4.txt).
        내가 모은 채널 = 밖에서 본 영상 주소로 채널을 담는다 · 최신 영상은 하루 한 번 유튜브 공개 RSS(이 PC 에만) ·
        관리자에게 추천(그 채널 하나만 · 이름·주소만)."""
        import my_channel as MC
        old = getattr(self, '_chan_dlg', None)
        if old is not None and old.winfo_exists():
            old.destroy()
        ex = sorted(self._excluded_channels())
        fav = sorted(self._fav_channels())
        with appdb.connect(self.db_path) as c:
            mine = MC.channels(c)
        dlg = tk.Toplevel(self); dlg.title(_t('RN_CHAN_MANAGE2', '채널 관리'))
        self._chan_dlg = dlg
        dlg.transient(self.winfo_toplevel()); dlg.geometry('560x560')
        top = tk.Frame(dlg); top.pack(side='top', fill='x', padx=8, pady=6)
        tk.Button(top, text=_t('COMMON_CLOSE', '닫기'), command=dlg.destroy,
                  bg='#85929E', fg='white', bd=0, padx=10).pack(side='right')
        msg = tk.Label(top, text='', fg='#2471A3', anchor='w'); msg.pack(side='left', fill='x', expand=True)

        def reopen(text=''):
            dlg.destroy(); self._sync_seg(); self._load_cache_now(); self._yt_manage_channels()
            if text:
                self._chan_dlg_msg.config(text=text)

        def _section(label, items, key):
            lf = tk.LabelFrame(dlg, text=label, font=('Malgun Gothic', 9, 'bold'))
            lf.pack(fill='x', padx=8, pady=4)
            if not items:
                tk.Label(lf, text=_t('COMMON_NONE', '(없음)'), fg='#999').pack(anchor='w', padx=6)
                return
            for name in items:
                row = tk.Frame(lf); row.pack(fill='x', padx=6, pady=1)
                tk.Label(row, text=name, anchor='w', font=('Malgun Gothic', 9)).pack(side='left')

                def _rm(n=name, k=key):
                    st = self._yt_chan_set(k); st.discard(n); self._yt_chan_save(k, st); reopen()
                tk.Button(row, text=_t('RN_CHAN_UNSET', '해제'), command=_rm,
                          bd=0, fg='#C0392B', cursor='hand2').pack(side='right')

        _section(_t('M_MP_FAVS', '즐겨찾는 채널'), fav, 'YT_FAV_CHANNELS')
        _section(_t('RN_EXCL_CHANNELS', '표시제외 채널'), ex, 'YT_EXCLUDE_CHANNELS')
        lf = tk.LabelFrame(dlg, text=_t('M_MYCH_MINE', '내가 모은 채널'), font=('Malgun Gothic', 9, 'bold'))
        lf.pack(fill='both', expand=True, padx=8, pady=4)
        add = tk.Frame(lf); add.pack(fill='x', padx=6, pady=(4, 2))
        tk.Label(add, text=_t('RN_MYCH_URL', '유튜브 영상 주소'), font=('Malgun Gothic', 9)).pack(side='left')
        ent = tk.Entry(add); ent.pack(side='left', fill='x', expand=True, padx=4)

        def _add():
            vid = MC.vid_of(ent.get().strip())
            if not vid:
                msg.config(text=_t('RN_MYCH_BADURL', '유튜브 영상 주소를 넣으세요')); return
            msg.config(text=_t('M_MYCH_FINDING', '채널을 찾는 중…'))
            box = []

            def work():
                # 채널 찾기 → 담기 → 그 자리에서 RSS 를 받아 본다(일꾼 스레드 · 연결도 여기서)
                try:
                    r = MC.channel_of_video(vid)
                    got = -1
                    if r:
                        with appdb.connect(self.db_path) as c:
                            MC.add(c, *r)
                            got = MC.probe(c, r[0], r[1])
                    box.append((r, got))
                except Exception:
                    box.append((None, -1))
            threading.Thread(target=work, daemon=True).start()

            def poll():
                if not box:
                    dlg.after(200, poll); return
                r, got = box[0]
                if not r:
                    msg.config(text=_t('M_MYCH_NOTFOUND', '이 영상의 채널을 알아내지 못했습니다')); return
                if got == -2:
                    reopen(_t('M_MYCH_BYAPP', '「%s」을(를) 담았습니다 — 이 채널은 앱이 이미 받고 있어 「앱 채널」에서 최신 영상이 보입니다. 앱이 받지 않게 되면 저절로 이어 받습니다').replace('%s', r[1]))
                    return
                if got < 0:
                    reopen(_t('M_MYCH_RSS_DOWN', '「%s」을(를) 담았습니다 — 지금은 유튜브가 새 영상 목록(RSS)을 어느 채널에도 주지 않고 있습니다. 다시 주면 저절로 받습니다').replace('%s', r[1]))
                    return
                if got == 0:
                    # ★ 유튜브가 이 채널의 RSS 를 안 준다 — 까닭을 말하고 관리자 추천을 권한다
                    if messagebox.askyesno(
                            _t('M_MYCH_NORSS_T', '이 채널의 새 영상은 받을 수 없습니다'),
                            '%s\n\n%s' % (r[1], _t('M_MYCH_NORSS', '유튜브가 이 채널의 새 영상 목록(RSS)을 주지 않습니다. 채널은 담아 두었지만 최신 영상이 오지 않을 수 있습니다.\n\n관리자에게 추천하면 관리자가 확인하고 등록해 모든 사용자의 「최신 유튜브」에 나오게 합니다.')
                                             + '\n\n' + _t('RN_MYCH_RECO_ASK', '관리자에게 추천할까요?')),
                            parent=dlg):
                        with appdb.connect(self.db_path) as c:
                            ok, err = MC.recommend(c, r[1], r[2], r[0], vid)
                        reopen(_t('RN_MYCH_RECO_OK', '관리자에게 보냈습니다') if ok
                               else _t('RN_MYCH_RECO_FAIL', '보내지 못했습니다: %s').replace('%s', str(err or '')))
                    else:
                        reopen(_t('M_MYCH_ADDED', '「%s」을(를) 내가 모은 채널에 담았습니다').replace('%s', r[1]))
                    return
                reopen(_t('M_MYCH_ADDED2', '「%s」을(를) 내가 모은 채널에 담았습니다 — 최신 영상 %d개')
                       .replace('%s', r[1]).replace('%d', str(max(got, 0))))
            dlg.after(200, poll)
        tk.Button(add, text=_t('M_MYCH_ADD', '내가 모은 채널에 담기'), command=_add, bd=1, cursor='hand2').pack(side='left')

        def _fetch():
            msg.config(text=_t('RN_UPDATING', '갱신 중…'))
            box = []

            def work():
                try:
                    with appdb.connect(self.db_path) as c:
                        box.append(MC.fetch(c, force=True))
                except Exception:
                    box.append(-1)
            threading.Thread(target=work, daemon=True).start()

            def poll():
                if not box:
                    dlg.after(300, poll); return
                reopen(_t('M_MYCH_GOT', '새 영상 %d개를 받았습니다').replace('%d', str(max(box[0], 0))))
            dlg.after(300, poll)
        if mine:
            tk.Button(add, text=_t('M_MYCH_FETCH', '지금 받기'), command=_fetch, bd=1, cursor='hand2').pack(side='left', padx=4)
        tk.Label(lf, text=_t('RN_MYCH_HOW', '밖에서 본 유튜브 영상의 주소를 넣으면 그 채널이 담깁니다. 최신 영상은 하루에 한 번 유튜브에서 받아 이 PC 에만 둡니다.'),
                 fg='#777', font=('Malgun Gothic', 8), wraplength=520, justify='left').pack(anchor='w', padx=6)
        if not mine:
            tk.Label(lf, text=_t('COMMON_NONE', '(없음)'), fg='#999').pack(anchor='w', padx=6)
        for ch in mine:
            row = tk.Frame(lf); row.pack(fill='x', padx=6, pady=1)
            when = (_t('M_MYCH_BYAPP_SUB', '앱이 받고 있습니다 — 「앱 채널」에서 보입니다') if ch.get('by_app')
                    else _t('M_MYCH_LAST', '마지막으로 받은 때 %s').replace('%s', ch['ok_at'][:10]) if ch['ok_at']
                    else _t('M_MYCH_NOTYET', '아직 받지 않음'))
            tk.Label(row, text='%s  · %s' % (ch['name'], when), anchor='w', font=('Malgun Gothic', 9)).pack(side='left')

            def _del(cid=ch['id']):
                with appdb.connect(self.db_path) as c:
                    MC.remove(c, cid)
                reopen()

            def _reco(x=ch):
                box = []

                def work():
                    try:
                        with appdb.connect(self.db_path) as c:
                            box.append(MC.recommend(c, x['name'], x['url'], x['id']))
                    except Exception as e:
                        box.append((False, str(e)[:60]))
                threading.Thread(target=work, daemon=True).start()

                def poll():
                    if not box:
                        dlg.after(200, poll); return
                    ok, err = box[0]
                    msg.config(text=_t('RN_MYCH_RECO_OK', '관리자에게 보냈습니다') if ok
                               else _t('RN_MYCH_RECO_FAIL', '보내지 못했습니다: %s').replace('%s', str(err or '')))
                dlg.after(200, poll)
            tk.Button(row, text=_t('M_MYCH_DEL', '내가 모은 채널에서 빼기'), command=_del,
                      bd=0, fg='#C0392B', cursor='hand2').pack(side='right')
            tk.Button(row, text=_t('M_MYCH_RECO', '관리자에게 채널 추천'), command=_reco,
                      bd=0, fg='#2471A3', cursor='hand2').pack(side='right', padx=6)
        self._chan_dlg_msg = msg

    def _site_manage(self):
        """사이트 관리 — 내가 모은 사이트(글 RSS · 2026-10-24).
        글·사이트 주소를 넣으면 그 사이트의 새 글 목록(RSS/Atom)을 찾아 담고 그 자리에서 받는다 ·
        앱이 이미 받는 사이트면 그렇다고 말한다 · 못 찾으면 까닭을 말하고 관리자 추천을 권한다."""
        import my_site as MS
        old = getattr(self, '_site_dlg', None)
        if old is not None and old.winfo_exists():
            old.destroy()
        with appdb.connect(self.db_path) as c:
            mine = MS.sites(c, self.kind)
        dlg = tk.Toplevel(self); dlg.title(_t('M_MYSITE_MANAGE', '사이트 관리'))
        self._site_dlg = dlg
        dlg.transient(self.winfo_toplevel()); dlg.geometry('600x520')
        top = tk.Frame(dlg); top.pack(side='top', fill='x', padx=8, pady=6)
        tk.Button(top, text=_t('COMMON_CLOSE', '닫기'), command=dlg.destroy,
                  bg='#85929E', fg='white', bd=0, padx=10).pack(side='right')
        msg = tk.Label(top, text='', fg='#2471A3', anchor='w', wraplength=480, justify='left')
        msg.pack(side='left', fill='x', expand=True)

        def reopen(text=''):
            dlg.destroy(); self._sync_seg(); self._load_cache_now(); self._site_manage()
            if text:
                self._site_dlg_msg.config(text=text)

        def _reco(name, page, feed):
            box = []

            def work():
                try:
                    with appdb.connect(self.db_path) as c:
                        box.append(MS.recommend(c, name, page, feed))
                except Exception as e:
                    box.append((False, str(e)[:60]))
            threading.Thread(target=work, daemon=True).start()

            def poll():
                if not box:
                    dlg.after(200, poll); return
                ok, err = box[0]
                self._site_dlg_msg.config(text=_t('RN_MYCH_RECO_OK', '관리자에게 보냈습니다') if ok
                                          else _t('RN_MYCH_RECO_FAIL', '보내지 못했습니다: %s').replace('%s', str(err or '')))
            dlg.after(200, poll)

        lf = tk.LabelFrame(dlg, text=_t('M_MYSITE_MINE', '내가 모은 사이트'), font=('Malgun Gothic', 9, 'bold'))
        lf.pack(fill='both', expand=True, padx=8, pady=4)
        add = tk.Frame(lf); add.pack(fill='x', padx=6, pady=(4, 2))
        tk.Label(add, text=_t('M_MYSITE_URL', '글 또는 사이트 주소'), font=('Malgun Gothic', 9)).pack(side='left')
        ent = tk.Entry(add); ent.pack(side='left', fill='x', expand=True, padx=4)
        try:   # ★ 저장한 글을 고른 채 열면 그 글의 주소를 미리 넣는다 — 그 사이트의 새 글을 받기 쉽게
            sel = self._tv.selection()
            if sel and self._mine_on() and self._seg_var.get() == 'SAVED':
                ent.insert(0, self._items[int(sel[0])]['url'])
        except Exception:
            pass

        def _add():
            url = ent.get().strip()
            if not MS.ok_url(url):
                msg.config(text=_t('M_MYSITE_BADURL', 'http 로 시작하는 주소를 넣으세요')); return
            msg.config(text=_t('M_MYSITE_FINDING', '이 사이트의 새 글 목록을 찾는 중…'))
            box = []

            def work():
                try:
                    with appdb.connect(self.db_path) as c:
                        box.append(MS.probe(c, url, self.kind))
                except Exception:
                    box.append(('NOFEED', {'name': url, 'page': url, 'feed': ''}, 0))
            threading.Thread(target=work, daemon=True).start()

            def poll():
                if not box:
                    dlg.after(200, poll); return
                st, s, n = box[0]
                if st == 'BYAPP':
                    reopen(_t('M_MYSITE_BYAPP', '「%s」을(를) 담았습니다 — 이 사이트는 앱이 이미 받고 있어 「앱 사이트」에서 새 글이 보입니다').replace('%s', s['name']))
                elif st == 'ADDED':
                    reopen(_t('M_MYSITE_ADDED', '「%s」을(를) 내가 모은 사이트에 담았습니다 — 새 글 %d개').replace('%s', s['name']).replace('%d', str(n)))
                elif messagebox.askyesno(
                        _t('M_MYSITE_NOFEED_T', '이 사이트의 새 글은 받을 수 없습니다'),
                        '%s\n\n%s' % (s['name'], _t('M_MYSITE_NOFEED', '이 사이트는 새 글 목록(RSS)을 내놓지 않거나 찾을 수 없습니다. 그래서 담지 않았습니다.\n\n관리자에게 추천하면 관리자가 확인하고, 받을 수 있으면 등록해 모든 사용자의 「최신 콘텐츠」에 나오게 합니다.')
                                        + '\n\n' + _t('RN_MYCH_RECO_ASK', '관리자에게 추천할까요?')),
                        parent=dlg):
                    _reco(s['name'], s['page'], '')
            dlg.after(200, poll)
        tk.Button(add, text=_t('M_MYSITE_ADD', '내가 모은 사이트에 담기'), command=_add, bd=1, cursor='hand2').pack(side='left')

        def _fetch():
            msg.config(text=_t('RN_UPDATING', '갱신 중…'))
            box = []

            def work():
                try:
                    with appdb.connect(self.db_path) as c:
                        box.append(MS.fetch(c, force=True))
                except Exception:
                    box.append(-1)
            threading.Thread(target=work, daemon=True).start()

            def poll():
                if not box:
                    dlg.after(300, poll); return
                reopen(_t('M_MYSITE_GOT', '새 글 %d개를 받았습니다').replace('%d', str(max(box[0], 0))))
            dlg.after(300, poll)
        if mine:
            tk.Button(add, text=_t('M_MYCH_FETCH', '지금 받기'), command=_fetch, bd=1, cursor='hand2').pack(side='left', padx=4)
        tk.Label(lf, text=_t('M_MYSITE_HOW', '밖에서 본 글이나 사이트의 주소를 넣으면 그 사이트의 새 글 목록(RSS)을 찾아 담습니다. 새 글은 하루에 한 번 받아 이 기기에만 둡니다(제목과 주소만).'),
                 fg='#777', font=('Malgun Gothic', 8), wraplength=560, justify='left').pack(anchor='w', padx=6)
        if not mine:
            tk.Label(lf, text=_t('COMMON_NONE', '(없음)'), fg='#999').pack(anchor='w', padx=6)
        for s in mine:
            row = tk.Frame(lf); row.pack(fill='x', padx=6, pady=1)
            when = (_t('M_MYSITE_BYAPP_SUB', '앱이 받고 있습니다 — 「앱 사이트」에서 보입니다') if s['by_app']
                    else _t('M_MYCH_LAST', '마지막으로 받은 때 %s').replace('%s', s['ok_at'][:10]) if s['ok_at']
                    else _t('M_MYCH_NOTYET', '아직 받지 않음'))
            tk.Label(row, text='%s  · %s' % (s['name'], when), anchor='w', font=('Malgun Gothic', 9)).pack(side='left')

            def _del(f=s['feed']):
                with appdb.connect(self.db_path) as c:
                    MS.remove(c, f)
                reopen()
            tk.Button(row, text=_t('M_MYSITE_DEL', '빼기'), command=_del,
                      bd=0, fg='#C0392B', cursor='hand2').pack(side='right')
            tk.Button(row, text=_t('M_MYSITE_RECO', '관리자에게 추천'),
                      command=lambda x=s: _reco(x['name'], x['page'], x['feed']),
                      bd=0, fg='#2471A3', cursor='hand2').pack(side='right', padx=6)
        self._site_dlg_msg = msg

    def _sync_seg(self):
        """[앱 채널][내가 모은 채널] · [앱 사이트][내가 모은 사이트] — 내가 모은 것이 있을 때만 보인다."""
        if not hasattr(self, '_seg_f'):
            return
        try:
            with appdb.connect(self.db_path) as c:
                if self.kind == 'YOUTUBE':
                    import my_channel as MC
                    n = len(MC.channels(c))
                else:
                    import my_site as MS
                    n = len(MS.sites(c, self.kind))
                    nsv = len(MS.saved_web(c, 1)) if self.kind == 'NEWS' else 0
                    self._sync_saved_radio(nsv > 0)
                    n += nsv
        except Exception:
            n = 0
        if n:
            if not self._seg_f.winfo_manager():
                self._seg_f.pack(side='left', padx=(6, 2), before=self._seg_anchor)
        else:
            self._seg_f.pack_forget()
            self._seg_var.set('APP')

    def _sync_saved_radio(self, on):
        """[저장한 글] 라디오 — 최신 뉴스 탭에서 저장한 글이 있을 때만(★ 2026-10-24)."""
        rb = getattr(self, '_saved_rb', None)
        if rb is None:
            return
        if on and not rb.winfo_manager():
            rb.pack(side='left')
        elif not on:
            rb.pack_forget()
            if self._seg_var.get() == 'SAVED':
                self._seg_var.set('APP')

    def _seg_key(self):
        return 'RN_YT_SEG' if self.kind == 'YOUTUBE' else 'RN_SITE_SEG_' + self.kind

    def _on_seg(self):
        _cfg_set(self.db_path, self._seg_key(), self._seg_var.get())
        self._load_cache_now()

    def _mine_on(self):
        return hasattr(self, '_seg_var') and self._seg_var.get() in ('MINE', 'SAVED') and bool(self._seg_f.winfo_manager())

    # ── UI ───────────────────────────────────────────────────────
    def _build(self):
        bar = tk.Frame(self, bg='#EAF2FB', height=34)
        bar.pack(fill='x', side='top')
        bar.pack_propagate(False)
        tk.Button(bar, text='' + _t('RN_REFRESH', '새로고침'), bd=0, bg='#2471A3', fg='white',
                  font=('Malgun Gothic', 9, 'bold'), padx=8, cursor='hand2',
                  command=self.refresh).pack(side='left', padx=(6, 4), pady=4)
        # 더보기 (상단 배치 — §0)
        self._more_btn = tk.Button(bar, text='▼ ' + _t('RN_MORE', '더보기'), bd=0, bg='#5499C7',
                                   fg='white', font=('Malgun Gothic', 9, 'bold'), padx=8,
                                   cursor='hand2', command=self._show_more)
        # 내 언어만 / 전체 언어 토글 (사용자 설정 언어와 일치하는 콘텐츠만 표시)
        self._langonly_var = tk.BooleanVar(
            value=_cfg_get(self.db_path, 'RSS_LANG_ONLY', '0') == '1')
        tk.Checkbutton(bar, text=_t('RN_LANGONLY', '내 언어만'), variable=self._langonly_var,
                       bg='#EAF2FB', font=('Malgun Gothic', 9), activebackground='#EAF2FB',
                       command=self._toggle_langonly).pack(side='left', padx=4)
        # 제목은 서버에서 사용자 언어로 번역돼 옴(방식 A·언어별 파일). 언어 변경은 [설정]에서.
        # ★ 2026-10-24 유튜브 탭에는 안 붙인다 — 본문 번역 안내가 맞지 않고 채널 단추 자리가 모자랐다(1300px 에서 잘림)
        if self.kind != 'YOUTUBE':
            # ★ 2026-10-24 글 RSS — 갈래 [앱 사이트][내가 모은 사이트](내가 모은 사이트가 있을 때만) · [사이트 관리]
            self._seg_var = tk.StringVar(value=_cfg_get(self.db_path, self._seg_key(), 'APP') or 'APP')
            self._seg_f = tk.Frame(bar, bg='#EAF2FB')
            for v, k, ko in (('APP', 'M_ND_AUTO', '자동수집'), ('MINE', 'M_MYSITE_MINE', '내가 모은 사이트')):
                tk.Radiobutton(self._seg_f, text=_t(k, ko), value=v, variable=self._seg_var, bg='#EAF2FB',
                               activebackground='#EAF2FB', font=('Malgun Gothic', 9),
                               command=self._on_seg).pack(side='left')
            # ★ 2026-10-24 +Hagah 로 저장한 글(폰·PC) — 최신 뉴스 탭에만 · 있을 때만 보인다
            self._saved_rb = tk.Radiobutton(self._seg_f, text=_t('M_ND_BOX', '내 수집함'), value='SAVED',
                                            variable=self._seg_var, bg='#EAF2FB', activebackground='#EAF2FB',
                                            font=('Malgun Gothic', 9), command=self._on_seg) if self.kind == 'NEWS' else None
            self._seg_anchor = tk.Frame(bar, bg='#EAF2FB', width=1)
            self._seg_anchor.pack(side='left')
            tk.Button(bar, text=_t('M_MYSITE_MANAGE', '사이트 관리'), bd=0, bg='#5D6D7E',
                      fg='white', font=('Malgun Gothic', 9), padx=6, cursor='hand2',
                      command=self._site_manage).pack(side='left', padx=2)
        if self.kind != 'YOUTUBE':
            tk.Label(bar, text=_t('RN_BODYHINT', '· 제목: 설정 언어로 번역 제공 · 본문: 브라우저(크롬) 번역'),
                     bg='#EAF2FB', fg='#888', font=('Malgun Gothic', 8)).pack(side='left', padx=2)
        tk.Button(bar, text='⚙ ' + _t('RN_SETTINGS', '설정'), bd=0, bg='#85929E', fg='white',
                  font=('Malgun Gothic', 9), padx=6, cursor='hand2',
                  command=self._open_settings).pack(side='left', padx=4)
        # 선택 항목 즐겨찾기(영구 보존) — 전 종류 공통. 즐겨찾기 탭에서 모아 봄.
        tk.Button(bar, text='★ ' + _t('RN_FAV_ITEM_BTN', '즐겨찾기'), bd=0, bg='#D4AC0D',
                  fg='white', font=('Malgun Gothic', 9, 'bold'), padx=8, cursor='hand2',
                  command=self._toggle_favorite_current).pack(side='left', padx=4)
        # 유튜브 전용: 선택 채널 표시제외 / 즐겨찾기 (선택 영상의 채널 기준)
        if self.kind == 'YOUTUBE':
            # ★ 2026-10-24 갈래 [앱 채널][내가 모은 채널] — 내가 모은 채널이 있을 때만(_sync_seg)
            self._seg_var = tk.StringVar(value=_cfg_get(self.db_path, 'RN_YT_SEG', 'APP') or 'APP')
            self._seg_f = tk.Frame(bar, bg='#EAF2FB')
            for v, k, ko in (('APP', 'M_MYCH_APP', '앱 채널'), ('MINE', 'M_MYCH_MINE', '내가 모은 채널')):
                tk.Radiobutton(self._seg_f, text=_t(k, ko), value=v, variable=self._seg_var, bg='#EAF2FB',
                               activebackground='#EAF2FB', font=('Malgun Gothic', 9),
                               command=self._on_seg).pack(side='left')
            self._seg_anchor = tk.Frame(bar, bg='#EAF2FB', width=1)
            self._seg_anchor.pack(side='left')
            tk.Button(bar, text='⊘ ' + _t('RN_EXCL_CHAN_BTN', '이 채널 제외'), bd=0, bg='#A569BD',
                      fg='white', font=('Malgun Gothic', 9), padx=6, cursor='hand2',
                      command=self._yt_exclude_current).pack(side='left', padx=2)
            tk.Button(bar, text=_t('RN_FAV_CHAN_BTN2', '즐겨찾는 채널에 넣기'), bd=0, bg='#E67E22',
                      fg='white', font=('Malgun Gothic', 9), padx=6, cursor='hand2',
                      command=self._yt_fav_current).pack(side='left', padx=2)
            tk.Button(bar, text=_t('RN_CHAN_MANAGE2', '채널 관리'), bd=0, bg='#5D6D7E',
                      fg='white', font=('Malgun Gothic', 9), padx=6, cursor='hand2',
                      command=self._yt_manage_channels).pack(side='left', padx=2)
        self._status = tk.Label(bar, text='', bg='#EAF2FB', fg='#555', font=('Malgun Gothic', 8))
        self._status.pack(side='right', padx=8)

        # 면책 (하단 상시) — 유튜브 탭은 YouTube 전용 문구
        _disc = (_t('RN_YT_NOTICE', _YT_NOTICE) if self.kind == 'YOUTUBE'
                 else _t('RN_DISCLAIMER', _DISCLAIMER))
        tk.Label(self, text='ⓘ ' + _disc, bg='#FBFCFC', fg='#7F8C8D',
                 font=('Malgun Gothic', 8), anchor='w', justify='left',
                 wraplength=1000).pack(fill='x', side='bottom')

        # 본문: 좌(목록) / 우(빈 공간 — 추후 콘텐츠). 싱글클릭 = 외부 브라우저.
        body = tk.PanedWindow(self, orient='horizontal', sashwidth=6,
                              bg='#C8CDD2', sashrelief='raised', opaqueresize=False)
        body.pack(fill='both', expand=True)
        left = tk.Frame(body)
        self._right = tk.Frame(body, bg='#F4F6F7')
        # 왼쪽 목록 축소 / 오른쪽 영역 2배 (왼:오 ≈ 1:2)
        body.add(left, minsize=240, width=320, stretch='never')
        body.add(self._right, minsize=300, width=640, stretch='always')
        # 우측 넓은 영역 — 최신묵상/뉴스에는 후원·광고 배너(자체서빙, IP/추적 0). 좌/중/우 카드.
        # 유튜브 탭은 인라인 플레이어가 self._right 를 쓰므로 배너 미배치.
        # (자리표시 안내 텍스트는 제거 — 배너 없으면 빈 공간. 추후 말씀카드 이미지로 채움.)
        if self.kind != 'YOUTUBE':
            try:
                import ads as _ads
                self._ad_banner = _ads.AdBanner(self._right, self.db_path, 'p1_latest',
                                                lang_getter=self.lang_getter, i18n_t=_t)
                self._ad_banner.pack(fill='x', anchor='n', padx=8, pady=8)
            except Exception as _e:
                _quiet('[ReadingNews] ad: %s' % _e)
            # ★★ **명소 빈 칸이던 자리를 말씀 카드로** (1.txt 20번 3).
            #   사진도 구절도 **시작화면이 이미 적어 둔 캐시**를 그대로
            #   읽는다(조회를 두 벌로 지으면 시작화면과 다른 구절이 뜨는다).
            # ⚠ 그릴 것이 아무것도 없으면 **붙이지 않는다**(§0-1).
            try:
                import verse_card as _vc
                card = _vc.VerseCard(self._right)
                if card.has_content():
                    self._verse_card = card
                    card.pack(fill='both', expand=True, padx=8, pady=(0, 8))
                else:
                    card.destroy()
            except Exception as _e:
                _quiet('[ReadingNews] card: %s' % _e)

        cols = ('site', 'title', 'date')
        tv = ttk.Treeview(left, columns=cols, show='headings', selectmode='browse')
        tv.heading('site', text=_t('RN_COL_SITE', '사이트'))
        tv.heading('title', text=_t('RN_COL_TITLE', '제목'))
        tv.heading('date', text=_t('RN_COL_DATE', '날짜'))
        tv.column('site', width=120, anchor='w', stretch=False)
        tv.column('title', width=380, anchor='w')
        tv.column('date', width=80, anchor='center', stretch=False)
        vsb = ttk.Scrollbar(left, orient='vertical', command=tv.yview)
        tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        tv.pack(side='left', fill='both', expand=True)
        # 싱글클릭으로 외부 브라우저 열기
        tv.bind('<ButtonRelease-1>', self._on_click)
        tv.bind('<Return>', lambda e: self._open_current())
        try:
            import ui_theme as _UT
            tv.tag_configure('favch', foreground=_UT.C('accent') or '#2471A3')
        except Exception:
            tv.tag_configure('favch', foreground='#2471A3')
        self._tv = tv
        self._sync_seg()

    def _on_first_map(self, _e):
        if not self._first_shown:
            self._first_shown = True
            self.after(100, self._load_cache_now)
            self.after(300, self._bg_fetch)

    # ── 캐시 즉시 표시 ────────────────────────────────────────────
    def _load_cache_now(self):
        if self._mine_on():
            try:
                with appdb.connect(self.db_path) as conn:
                    if self.kind == 'YOUTUBE':
                        import my_channel as MC
                        self._all = MC.videos(conn)
                    else:
                        import my_site as MS
                        self._all = (MS.saved_web(conn) if self._seg_var.get() == 'SAVED'
                                     else MS.items(conn, self.kind))
            except Exception as e:
                self._all = []
                _quiet('[ReadingNews] mine: %s' % e)
            self._shown = _PAGE
            self._render()
            return
        ex = self._excluded()
        try:
            with appdb.connect(self.db_path) as conn:
                # 방식 A: sys_ref_asset 베이스라인 흡수(sync_baseline) 폐지 — 미번역 원문이 캐시로 새어들어옴.
                # 최신 콘텐츠는 관리자 번역 배포본(items_<lang>.tsv) 한 경로로만 들어온다.
                items = R.reading_items(conn, self.kind, exclude_ids=ex, langs=self._lang_filter(),
                                        exclude_channels=self._excluded_channels(),
                                        fav_channels=self._fav_channels())
        except Exception as e:
            items = []
            _quiet('[ReadingNews] cache: %s' % e)
        self._all = items
        self._shown = _PAGE
        self._render()
        self._ensure_xl_language()   # 현재 UI 언어의 공식 번역제목이 적용돼 있도록 보장

    def _ensure_xl_language(self):
        """방식 A: 제목은 서버의 언어별 파일(items_<lang>/youtube_<lang>)에서 사용자 언어로 받아 옴.
        설정 제목언어가 바뀌었으면(또는 아직 적용 전이면) 그 언어 파일을 강제 재동기화해
        전 항목 제목을 새 언어로 갱신(백그라운드 후 재렌더). gtx 호출 없음."""
        cur = (self._tr_lang() or 'KO').upper()
        key = 'RSS_XL_LANG_YT' if self.kind == 'YOUTUBE' else 'RSS_XL_LANG_ITEMS'
        if _cfg_get(self.db_path, key, '') == cur:
            return
        langs = self._lang_filter()   # ⚠ Tk 는 주 실에서 읽는다(위 `_bg_fetch` 와 같은 규칙)

        def work():
            try:
                import rss_transport as RT
                ex = self._excluded()
                srv = RT.client_servers()
                with appdb.connect(self.db_path) as conn:
                    if self.kind == 'YOUTUBE':
                        R.sync_youtube(conn, srv, force=True, ui_lang=cur)
                    else:
                        R.sync_items(conn, srv, force=True, ui_lang=cur)
                    items = R.reading_items(conn, self.kind, exclude_ids=ex,
                                            langs=langs,
                                            exclude_channels=self._excluded_channels(),
                                            fav_channels=self._fav_channels())
                self._safe_after(lambda: self._apply_translated(items))
            except Exception as e:
                _quiet('[ReadingNews] xl-lang: %s' % e)
        threading.Thread(target=work, daemon=True).start()

    def _safe_after(self, fn):
        """창이 닫힌 **뒤에** 깨어난 데몬 실이 `after` 를 부르면 Tk 가
        「main thread is not in main loop」 로 트레이스백을 뱉는다(종료할 때
        실제로 났다). 살아 있을 때만 돌려보낸다 — `feedback_view` 와 같은 처방."""
        try:
            if self.winfo_exists():
                self.after(0, fn)
        except Exception:
            pass

    def _apply_translated(self, items):
        self._all = items
        self._render()

    def refresh(self):
        self._load_cache_now()
        self._bg_fetch(force=True)        # [새로고침] = 강제 수집

    def _bg_fetch(self, force=False):
        if self._busy:
            return
        if not force:
            # throttle: 최근 자동 수집했으면 네트워크 생략(캐시만). 앱 매 실행 재수집 방지
            try:
                with appdb.connect(self.db_path) as conn:
                    # ★ 2026-10-22 받기 설정 한 벌(news_pref — 폰과 동기화) · 끄거나 「누를 때만」이면 자동으로 안 받는다
                    import news_pref as _NP
                    _mh = _NP.min_hours(conn)
                    if _mh is None or not R.should_auto_sync(conn, self.kind, min_hours=_mh):
                        self._status.config(text=_t('RN_CACHED', '최신(캐시)'))
                        return
            except Exception:
                pass
        self._busy = True
        self._force_fetch = force
        self._status.config(text=_t('RN_UPDATING', '갱신 중…'))
        # ⚠⚠ **콤보·체크박스는 주 실에서 읽어 넘긴다**(§199차 ⑨) — Tk 는 스레드
        #   안전이 아니라 데몬 실에서 읽으면 창이 닫힌 순간 「main thread is not
        #   in main loop」 로 터진다(실측으로 재현했다). 나머지 셋(`_excluded`·
        #   `_excluded_channels`·`_fav_channels`)은 DB·설정만 읽으므로 실에 둔다.
        langs = self._lang_filter()
        threading.Thread(target=self._fetch_worker, args=(langs,),
                         daemon=True).start()

    def _fetch_worker(self, langs=None):
        ex = self._excluded()
        ui = (self._tr_lang() or 'KO').upper()   # 표시(render)와 동일한 번역언어로 적용
        try:
            with appdb.connect(self.db_path) as conn:
                # 서버 주소록·항목색인 동기화(있으면) — 새 피드 자동 반영 + 집계 헤드라인 수신
                try:
                    import rss_transport as RT
                    srv = RT.client_servers()
                    _force = getattr(self, '_force_fetch', False)  # [새로고침]이면 강제 재다운로드
                    R.sync_registry(conn, srv, force=_force)
                    if self.kind == 'YOUTUBE':
                        # 방식 A: 언어별 youtube_<ui>.tsv 수신(번역제목·원본lang)
                        R.sync_youtube(conn, srv, force=_force, ui_lang=ui)
                    else:
                        # 방식 A: 언어별 items_<ui>.tsv 수신(번역제목·원본lang)
                        R.sync_items(conn, srv, force=_force, ui_lang=ui)
                except Exception:
                    pass
                # 방식 A: 클라이언트 자체수집(fetch_live) 폐지 — 최신 콘텐츠는 관리자 번역 배포본만 사용.
                try:
                    R.purge_cache(conn, self.kind)   # 유한 롤링 캐시(90일/피드당 300) 유지
                except Exception:
                    pass
                R.mark_auto_sync(conn, self.kind)    # throttle 기준 갱신
                if self.kind == 'YOUTUBE':
                    try:   # ★ 내가 모은 채널 — 하루 한 번(채널이 없으면 아무것도 안 묻는다)
                        import my_channel as _MC
                        _MC.fetch(conn)
                    except Exception:
                        pass
                else:
                    try:   # ★ 내가 모은 사이트 — 하루 한 번(사이트가 없으면 아무것도 안 묻는다)
                        import my_site as _MS
                        _MS.fetch(conn)
                    except Exception:
                        pass
                items = R.reading_items(conn, self.kind, exclude_ids=ex, langs=langs,
                                        exclude_channels=self._excluded_channels(),
                                        fav_channels=self._fav_channels())
        except Exception as e:
            items = []
            _quiet('[ReadingNews] fetch: %s' % e)
        self._safe_after(lambda: self._done(items))

    def _done(self, items):
        self._busy = False
        if self._mine_on():          # 내가 모은 채널을 보고 있으면 그 목록을 다시 읽는다
            self._load_cache_now()
            return
        self._all = items
        self._render()

    # ── 렌더 (50개 + 더보기) ──────────────────────────────────────
    def _render(self):
        # 방식 A: title 은 이미 사용자 언어로 번역돼 저장됨(언어별 파일). 그대로 표시.
        self._items = self._all[:self._shown]
        favch = self._fav_channels() if self.kind == 'YOUTUBE' else set()
        try:
            with appdb.connect(self.db_path) as conn:
                favset = R.favorite_urls(conn)   # 즐겨찾기된 항목엔 제목 앞에 ★
        except Exception:
            favset = set()
        self._tv.delete(*self._tv.get_children())
        for i, it in enumerate(self._items):
            title = ('★ ' + it['title']) if it.get('url') in favset else it['title']
            site = it['site']
            self._tv.insert('', 'end', iid=str(i), tags=(('favch',) if site in favch else ()),
                            values=(site[:22], title, (it['published'] or '')[:10]))
        total = len(self._all)
        self._status.config(text=f'{len(self._items)}/{total}')
        # 더보기 버튼 표시/숨김
        if total > self._shown:
            self._more_btn.pack(side='left', padx=4)
            self._more_btn.config(text=f'▼ ' + _t('RN_MORE', '더보기') + f' (+{min(_PAGE, total - self._shown)})')
        else:
            self._more_btn.pack_forget()

    def _show_more(self):
        self._shown += _PAGE
        self._render()

    # ── 외부 브라우저 열기 (왼쪽 안 가리게 우측 배치) ─────────────
    def _on_click(self, event):
        if self._tv.identify_region(event.x, event.y) != 'cell':
            return
        self._open_current()

    def _open_current(self):
        sel = self._tv.selection()
        if not sel:
            return
        try:
            url = self._items[int(sel[0])].get('url')
        except (ValueError, IndexError):
            url = None
        if not url:
            return
        # 유튜브는 우측 패널에 인라인 재생(웹뷰), 나머지는 외부 브라우저
        if self.kind == 'YOUTUBE':
            self._play_youtube(url)
        else:
            self._open_browser(url)

    def _toggle_favorite_current(self):
        """선택 항목을 즐겨찾기 토글(영구 보존). 이미 즐겨찾기면 해제."""
        sel = self._tv.selection()
        if not sel:
            messagebox.showinfo(_t('RN_FAV_ITEM_BTN', '즐겨찾기'),
                                _t('RN_PICK_FIRST', '먼저 목록에서 항목을 선택하세요.'),
                                parent=self.winfo_toplevel())
            return
        try:
            it = self._items[int(sel[0])]
        except (ValueError, IndexError):
            return
        url = it.get('url')
        if not url:
            return
        with appdb.connect(self.db_path) as conn:
            if R.is_favorite(conn, url):
                R.remove_favorite(conn, url)
            else:
                R.add_favorite(conn, {'url': url, 'feed_kind': self.kind, 'site': it.get('site'),
                                      'lang': it.get('lang'), 'title': it.get('title'),
                                      'published': it.get('published')})
        self._render()   # ★ 표시 갱신

    def _play_youtube(self, url):
        """우측 패널 안에서 유튜브 인라인 재생(EmbeddedPlayer). 불가 시 외부 브라우저 폴백."""
        import re as _re
        m = (_re.search(r'[?&]v=([\w-]+)', url) or _re.search(r'youtu\.be/([\w-]+)', url)
             or _re.search(r'/embed/([\w-]+)', url))
        vid = m.group(1) if m else None
        if not vid:
            self._open_browser(url); return
        try:
            import media_player
            if not media_player.embed_available():
                self._open_browser(url); return
            if getattr(self, '_player', None) is None:
                for w in self._right.winfo_children():
                    w.destroy()
                self._player = media_player.EmbeddedPlayer(self._right)
            self._player.play(vid)
        except Exception:
            self._open_browser(url)

    def _on_destroy(self, e):
        if e.widget is self and getattr(self, '_player', None) is not None:
            try:
                self._player.stop()
            except Exception:
                pass

    def _open_browser(self, url):
        _open_external(self.winfo_toplevel(), url)

    def _lang_filter(self):
        """'내 언어만' ON 이면 {사용자언어} 집합, OFF면 None(전체 언어)."""
        if getattr(self, '_langonly_var', None) and self._langonly_var.get():
            return {(self.lang_getter() or 'KO').upper()}
        return None

    def _toggle_langonly(self):
        on = self._langonly_var.get()
        _cfg_set(self.db_path, 'RSS_LANG_ONLY', '1' if on else '0')
        self._load_cache_now()   # 캐시에서 필터만 다시 적용(재수집 불필요)

    # ── 설정 다이얼로그 (탭: 사이트/번역 · 내 피드 · 캐시 · 안내) ──
    def _open_settings(self):
        dlg = tk.Toplevel(self)
        kind_label = (_t('RN_TAB_DEVOTION', '최신 묵상') if self.kind == 'DEVOTIONAL'
                      else _t('RN_TAB_YOUTUBE', '최신 유튜브') if self.kind == 'YOUTUBE'
                      else _t('RN_TAB_NEWS', '최신 뉴스'))
        dlg.title(_t('RN_SETTINGS', '설정') + ' — ' + kind_label)
        dlg.transient(self.winfo_toplevel())
        dlg.geometry('540x560')

        # ===== 상단 저장/취소 (모든 버튼은 상단 — CLAUDE.md §0) =====
        def _save():
            new_ex = [str(fid) for fid, v in vars_.items() if not v.get()]
            _cfg_set(self.db_path, 'RSS_EXCLUDE_FEEDS', ','.join(new_ex))
            _cfg_set(self.db_path, 'RSS_TRANSLATE_LANG', tr_lang.get())
            try:
                import news_pref as _NP
                _k = [k for k, n in _np_items if n == np_var.get()]
                if _k:
                    with appdb.connect(self.db_path) as _c:
                        if _k[0] == 'OFF':
                            _NP.set_pref(_c, on=0)
                        else:
                            _NP.set_pref(_c, on=1, period=_k[0])
            except Exception as _e:
                print('[news_pref save] %s' % _e)
            dlg.destroy()
            self.refresh()
        btnf = tk.Frame(dlg)
        btnf.pack(fill='x', padx=12, pady=(8, 2), side='top')
        tk.Button(btnf, text=_t('COMMON_SAVE', '저장'), bg='#1A5276', fg='white', bd=0,
                  font=('Malgun Gothic', 9, 'bold'), padx=12, pady=4,
                  command=_save).pack(side='right')
        tk.Button(btnf, text=_t('COMMON_CANCEL', '취소'), bg='#85929E', fg='white', bd=0,
                  font=('Malgun Gothic', 9), padx=12, pady=4,
                  command=dlg.destroy).pack(side='right', padx=6)

        nb = ttk.Notebook(dlg)
        nb.pack(fill='both', expand=True, padx=6, pady=6)

        # ===== 탭1: 사이트 / 번역 =====
        t1 = ttk.Frame(nb); nb.add(t1, text=' ' + _t('RN_SET_TAB_SITES', '사이트/번역') + ' ')
        lf = tk.Frame(t1); lf.pack(fill='x', padx=10, pady=(10, 6))
        tk.Label(lf, text=_t('RN_SET_TRLANG', '제목 언어(받을 번역):'),
                 font=('Malgun Gothic', 9, 'bold')).pack(side='left')
        tr_lang = tk.StringVar(value=self._tr_lang())
        ttk.Combobox(lf, textvariable=tr_lang, width=8, state='readonly',
                     values=['KO', 'EN', 'ZH', 'ZHT', 'JA', 'DE', 'FR', 'ES', 'RU', 'PT', 'AR']
                     ).pack(side='left', padx=6)
        # ★ 2026-10-22 자동 받기 — 폰과 함께 쓰는 한 벌(news_pref · 어느 쪽에서 고쳐도 늦게 고친 것이 이긴다)
        _np_items = [('DAILY', _t('NP_DAILY', '하루 한 번')), ('H12', _t('NP_H12', '12시간마다')),
                     ('H6', _t('NP_H6', '6시간마다')), ('MANUAL', _t('NP_MANUAL', '누를 때만')),
                     ('OFF', _t('NP_OFF', '받지 않기'))]
        try:
            import news_pref as _NP
            with appdb.connect(self.db_path) as _c:
                _cur = _NP.get(_c)
            _ck = 'OFF' if not _cur['on'] else _cur['period']
        except Exception:
            _ck = 'DAILY'
        np_var = tk.StringVar(value=dict(_np_items).get(_ck, _np_items[0][1]))
        npf = tk.Frame(t1); npf.pack(fill='x', padx=10, pady=(0, 6))
        tk.Label(npf, text=_t('NP_LABEL', '자동 받기(폰과 같은 설정):'),
                 font=('Malgun Gothic', 9, 'bold')).pack(side='left')
        ttk.Combobox(npf, textvariable=np_var, width=12, state='readonly',
                     values=[n for _k, n in _np_items]).pack(side='left', padx=6)
        tk.Label(t1, text=_t('RN_SET_SITES', '기본 제공 사이트 (체크 해제 = 제외)'),
                 font=('Malgun Gothic', 10, 'bold')).pack(anchor='w', padx=10, pady=(8, 2))
        filt = tk.Frame(t1); filt.pack(fill='x', padx=10)
        tk.Label(filt, text=_t('RN_SET_LANGFILTER', '언어:'),
                 font=('Malgun Gothic', 9)).pack(side='left')
        with appdb.connect(self.db_path) as conn:
            feeds = conn.execute(
                "SELECT feed_id, site_name, lang_code FROM sys_rss_feed "
                "WHERE record_status='LIVE' AND feed_kind=? ORDER BY lang_code, site_name",
                (self.kind,)).fetchall()
        langs_present = sorted({(f[2] or 'EN') for f in feeds})
        allv = _t('COMMON_ALL', '전체')
        lang_filter = tk.StringVar(value=allv)
        ttk.Combobox(filt, textvariable=lang_filter, width=10, state='readonly',
                     values=[allv] + langs_present).pack(side='left', padx=6)
        ex = self._excluded()
        # 사이트 목록 — 스크롤 가능(피드 수십 개라 넘침)
        _scrollwrap = tk.Frame(t1); _scrollwrap.pack(fill='both', expand=True, padx=10, pady=(4, 0))
        _canv = tk.Canvas(_scrollwrap, highlightthickness=0)
        _vsb = ttk.Scrollbar(_scrollwrap, orient='vertical', command=_canv.yview)
        _canv.configure(yscrollcommand=_vsb.set)
        _vsb.pack(side='right', fill='y')
        _canv.pack(side='left', fill='both', expand=True)
        box = tk.Frame(_canv)
        _winid = _canv.create_window((0, 0), window=box, anchor='nw')
        box.bind('<Configure>', lambda e: _canv.configure(scrollregion=_canv.bbox('all')))
        _canv.bind('<Configure>', lambda e: _canv.itemconfigure(_winid, width=e.width))
        _wheel = lambda e: _canv.yview_scroll(int(-e.delta / 120), 'units')
        _canv.bind('<MouseWheel>', _wheel)
        box.bind('<MouseWheel>', _wheel)
        vars_ = {}

        def _rebuild_sites(*_a):
            for w in box.winfo_children():
                w.destroy()
            sel = lang_filter.get()
            for fid, name, lang in feeds:
                lg = lang or 'EN'
                if sel != allv and lg != sel:
                    continue
                if fid not in vars_:
                    vars_[fid] = tk.BooleanVar(value=(fid not in ex))
                tk.Checkbutton(box, text=f'[{lg}] {name}', variable=vars_[fid],
                               font=('Malgun Gothic', 9), anchor='w').pack(fill='x', anchor='w')
        lang_filter.trace_add('write', _rebuild_sites)
        _rebuild_sites()

        # ===== (제거됨) 탭2 '내 피드' — 자체수집(fetch_live) 기반 기능 폐지(방식 A: 관리자 배포만) =====

        # ===== 탭3: 캐시 =====
        t3 = ttk.Frame(nb); nb.add(t3, text=' ' + _t('RN_SET_TAB_CACHE', '캐시') + ' ')
        with appdb.connect(self.db_path) as conn:
            ccount = conn.execute("SELECT COUNT(*) FROM user_rss_cache WHERE feed_kind=?",
                                  (self.kind,)).fetchone()[0]
        cache_lbl = tk.Label(t3, text=_t('RN_SET_CACHE_CNT', '현재 캐시: {n}건').format(n=ccount)
                             if '{n}' in _t('RN_SET_CACHE_CNT', '현재 캐시: {n}건')
                             else f'현재 캐시: {ccount}건',
                             font=('Malgun Gothic', 10, 'bold'))
        cache_lbl.pack(anchor='w', padx=12, pady=(14, 6))
        tk.Label(t3, text=_t('RN_SET_CACHE_DESC',
                 '제목·요약만 이 PC에 임시 저장됩니다(본문 미저장).\n'
                 '오래된 항목(90일 초과)과 피드당 300건 초과분은 자동 삭제됩니다.'),
                 fg='#555', font=('Malgun Gothic', 9), justify='left').pack(anchor='w', padx=12)

        def _do_clear():
            if not messagebox.askyesno(_t('RN_SET_TAB_CACHE', '캐시'),
                                       _t('RN_SET_CACHE_ASK', '이 PC의 캐시를 모두 비울까요?'), parent=dlg):
                return
            with appdb.connect(self.db_path) as conn:
                n = R.clear_cache(conn, self.kind)
            cache_lbl.config(text=f'현재 캐시: 0건 (삭제 {n})')
            self._all = []
            self._render()
        # ── 죽은 URL 정리 ──
        ttk.Separator(t3, orient='horizontal').pack(fill='x', padx=12, pady=(12, 6))
        tk.Label(t3, text=_t('RN_SET_DEAD_TITLE', '죽은 링크 정리'),
                 font=('Malgun Gothic', 10, 'bold')).pack(anchor='w', padx=12)
        tk.Label(t3, text=_t('RN_SET_DEAD_DESC',
                 '접속이 안 되는(404/삭제된) 링크를 점검해 표시에서 제외하고 비웁니다.\n'
                 '한 번에 50개씩 점검 — 여러 번 누르면 전체를 점진 점검합니다.'),
                 fg='#555', font=('Malgun Gothic', 9), justify='left').pack(anchor='w', padx=12)
        dead_lbl = tk.Label(t3, text='', fg='#1A5276', font=('Malgun Gothic', 9))
        dead_lbl.pack(anchor='w', padx=12, pady=(4, 0))

        def _do_check_dead():
            dead_lbl.config(text=_t('RN_SET_DEAD_CHECKING', '점검 중...'))
            dlg.update_idletasks()

            def work():
                try:
                    with appdb.connect(self.db_path) as conn:
                        chk, dead = R.check_dead_items(conn, self.kind, limit=50)
                    msg = _t('RN_SET_DEAD_RESULT', '점검 {c}개 · 죽은 링크 {d}개').format(c=chk, d=dead)
                except Exception as e:
                    msg = f'오류: {str(e)[:40]}'
                # ⚠ 팝업이 먼저 닫히면 `dead_lbl` 도 파괴돼 있다 — 살아 있을 때만.
                def _show(_m=msg):
                    try:
                        if dead_lbl.winfo_exists():
                            dead_lbl.config(text=_m)
                    except Exception:
                        pass
                self._safe_after(_show)
            threading.Thread(target=work, daemon=True).start()

        def _do_purge_dead():
            with appdb.connect(self.db_path) as conn:
                n = R.purge_dead(conn, self.kind)
                ccount2 = conn.execute("SELECT COUNT(*) FROM user_rss_cache WHERE feed_kind=?",
                                       (self.kind,)).fetchone()[0]
            dead_lbl.config(text=_t('RN_SET_DEAD_PURGED', '죽은 링크 {n}개 삭제됨').format(n=n))
            cache_lbl.config(text=f'현재 캐시: {ccount2}건')
            self._load_cache_now()

        brow = tk.Frame(t3); brow.pack(anchor='w', padx=12, pady=8)
        tk.Button(brow, text='' + _t('RN_SET_DEAD_CHECK', '죽은 링크 점검'), bd=0, bg='#2471A3', fg='white',
                  font=('Malgun Gothic', 9, 'bold'), padx=10, pady=4, command=_do_check_dead).pack(side='left')
        tk.Button(brow, text='' + _t('RN_SET_DEAD_PURGE', '죽은 링크 삭제'), bd=0, bg='#c0392b', fg='white',
                  font=('Malgun Gothic', 9, 'bold'), padx=10, pady=4, command=_do_purge_dead).pack(side='left', padx=6)

        tk.Button(t3, text='' + _t('RN_SET_CACHE_CLEAR', '캐시 비우기'), bd=0, bg='#c0392b', fg='white',
                  font=('Malgun Gothic', 9, 'bold'), padx=10, pady=4,
                  command=_do_clear).pack(anchor='w', padx=12, pady=10)

        # ===== 탭4: 안내 =====
        t4 = ttk.Frame(nb); nb.add(t4, text=' ' + _t('RN_SET_TAB_INFO', 'ⓘ 안내') + ' ')
        info = tk.Text(t4, wrap='word', font=('Malgun Gothic', 9), relief='flat',
                       bg='#FBFCFC', padx=10, pady=8)
        info.pack(fill='both', expand=True, padx=6, pady=6)
        info.insert('1.0', _t('RN_SET_INFO_TEXT',
            '이 화면은 무엇인가요?\n'
            '신뢰할 만한 묵상·교계 사이트의 RSS 최신글 "제목"을 모아 보여주는 읽을거리 도구입니다.\n\n'
            '앱은 콘텐츠를 저장·배포하지 않습니다\n'
            '· 제목을 클릭하면 원본 사이트가 브라우저로 열립니다(원저작자의 방문·광고 보장).\n'
            '· 본문 전체는 앱에 저장하지 않습니다. 앱은 "링크 전달" 역할만 합니다.\n\n'
            '캐시(이 PC에만 임시 저장)\n'
            '· 빠른 표시를 위해 제목·요약만 이 PC에 임시 저장합니다.\n'
            '· 90일 초과/피드당 300건 초과분은 자동 삭제됩니다. [캐시] 탭에서 언제든 비울 수 있습니다.\n'
            '· 저장 내용은 다른 사용자와 공유·배포되지 않습니다.\n\n'
            '번역\n'
            '· 제목 번역은 선택사항이며 이 PC에만 저장됩니다.\n'
            '· 본문 전체 번역은 브라우저(크롬)의 자체 번역 기능을 사용하세요.\n\n'
            '내 피드\n'
            '· 기본 제공 목록은 제외할 수 있고, [내 피드] 탭에서 원하는 RSS를 직접 추가할 수 있습니다.\n'
            '· 직접 추가한 피드는 이 PC에만 저장됩니다.\n\n'
            '저작권은 각 원본 사이트에 있습니다. 번역 결과의 책임은 이용자에게 있습니다.'))
        info.config(state='disabled')


class _FavoritesPanel(ttk.Frame):
    """★ 즐겨찾기 탭 — 전 종류(묵상·뉴스·유튜브) 즐겨찾기 항목을 모아 영구 표시.
    롤링 캐시와 독립한 user_rss_favorite 스냅샷이라 90일 지나도 사라지지 않는다."""

    KIND_LABEL = {'DEVOTIONAL': '묵상', 'NEWS': '뉴스', 'YOUTUBE': '유튜브'}

    def __init__(self, master, db_path, lang_getter=None):
        super().__init__(master)
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self._items = []
        self._build()
        self.bind('<Map>', lambda _e: self._reload())

    def _build(self):
        bar = tk.Frame(self, bg='#FBF7E0', height=34)
        bar.pack(fill='x', side='top'); bar.pack_propagate(False)
        tk.Button(bar, text='⟳ ' + _t('RN_REFRESH', '새로고침'), bd=0, bg='#2471A3', fg='white',
                  font=('Malgun Gothic', 9, 'bold'), padx=8, cursor='hand2',
                  command=self._reload).pack(side='left', padx=(6, 4), pady=4)
        tk.Button(bar, text='✖ ' + _t('RN_FAV_REMOVE', '즐겨찾기 해제'), bd=0, bg='#C0392B', fg='white',
                  font=('Malgun Gothic', 9, 'bold'), padx=8, cursor='hand2',
                  command=self._remove_current).pack(side='left', padx=4)
        self._status = tk.Label(bar, text='', bg='#FBF7E0', fg='#555', font=('Malgun Gothic', 8))
        self._status.pack(side='right', padx=8)

        cols = ('site', 'title', 'date', 'kind')
        tv = ttk.Treeview(self, columns=cols, show='headings', selectmode='browse')
        tv.heading('site', text=_t('RN_COL_SITE', '사이트'))
        tv.heading('title', text=_t('RN_COL_TITLE', '제목'))
        tv.heading('date', text=_t('RN_COL_DATE', '날짜'))
        tv.heading('kind', text=_t('RN_COL_KIND', '종류'))
        tv.column('site', width=140, anchor='w', stretch=False)
        tv.column('title', width=520, anchor='w')
        tv.column('date', width=80, anchor='center', stretch=False)
        tv.column('kind', width=60, anchor='center', stretch=False)
        vsb = ttk.Scrollbar(self, orient='vertical', command=tv.yview)
        tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        tv.pack(side='left', fill='both', expand=True)
        tv.bind('<ButtonRelease-1>', self._on_click)
        tv.bind('<Return>', lambda e: self._open_current())
        self._tv = tv

    def _reload(self):
        try:
            with appdb.connect(self.db_path) as conn:
                self._items = R.list_favorites(conn)
        except Exception as e:
            self._items = []
            _quiet('[Favorites] load: %s' % e)
        self._tv.delete(*self._tv.get_children())
        for i, it in enumerate(self._items):
            kind = self.KIND_LABEL.get(it.get('feed_kind', ''), it.get('feed_kind', ''))
            self._tv.insert('', 'end', iid=str(i),
                            values=(it['site'][:22], it['title'], (it['published'] or '')[:10], kind))
        self._status.config(text=f"{len(self._items)}")

    def _on_click(self, event):
        if self._tv.identify_region(event.x, event.y) != 'cell':
            return
        self._open_current()

    def _cur(self):
        sel = self._tv.selection()
        if not sel:
            return None
        try:
            return self._items[int(sel[0])]
        except (ValueError, IndexError):
            return None

    def _open_current(self):
        it = self._cur()
        if it and it.get('url'):
            _open_external(self.winfo_toplevel(), it['url'])   # 유튜브 포함 외부 브라우저로 열기

    def _remove_current(self):
        it = self._cur()
        if not it or not it.get('url'):
            messagebox.showinfo(_t('RN_TAB_FAV', '즐겨찾기'),
                                _t('RN_PICK_FIRST', '먼저 목록에서 항목을 선택하세요.'),
                                parent=self.winfo_toplevel())
            return
        with appdb.connect(self.db_path) as conn:
            R.remove_favorite(conn, it['url'])
        self._reload()
