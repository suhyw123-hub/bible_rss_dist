# -*- coding: utf-8 -*-
"""db_ai_run.py — **작업을 만들고 돌린다** (영구 도구, 2026-09-23 277차).

1.txt 11번 ④단계.
`db_ai_job`(무엇을) → `ai_client`(시킨다) → **여기**(묶고·돌리고·재고·담는다)
→ 사람 검수 → 적재.

    python db_ai_run.py --selftest                   (의무 · 망을 안 탄다)
    python db_ai_run.py --jobs                       작업 목록
    python db_ai_run.py --run <job_id> [--limit N]   이어서 돌린다
    python db_ai_run.py --show <job_id>              건별 상태

★★★ **중단·재개가 설계의 중심이다.** 시편 절 설명문만 2,461자리이고 무료
  등급은 하루 1,000회다 — **한 번에 끝나는 일이 아니다.** 그래서
  ⓐ 건별로 행을 만들어 두고 ⓑ 돌릴 때 **아직 안 한 것만** 집는다.
  중간에 죽어도 다시 `--run` 하면 그 자리에서 이어진다.

★★★ **상태 여섯** — 무엇이 남았는지 한 낱말로 말한다:
  | 상태 | 뜻 |
  |---|---|
  | `PENDING` | 아직 안 시켰다 |
  | `DONE` | 받았다 — **사람이 볼 차례** |
  | `FAIL` | 못 받았다(까닭이 적혀 있다) — 다시 돌리면 또 집는다 |
  | `OK` | 사람이 승인 |
  | `REJ` | 사람이 반려 |
  | `LOADED` | 적재까지 끝 |

⚠⚠⚠ **여기서 배포 DB 에 글을 넣지 않는다.** 받은 글은 `sys_ai_item.out_text`
  에만 있고, 게이트도 **초안 겹치기**(`db_vers_gate.draft`)로 잰다. 적재는
  사람이 승인한 뒤 따로 한다 — 그것이 §0-1 의 「검증된 뒤 입력」이다.

⚠ **한 건이 터져도 다음 건으로 간다** — 배치 도중 멎으면 남은 것을 다시
  집어야 하고, 그 사이 무엇이 됐는지 알 수 없다.
"""
import datetime
import json
from collections import Counter
import re
import os
import sys

APP = os.path.dirname(os.path.abspath(__file__))
if APP not in sys.path:
    sys.path.insert(0, APP)

import ai_client as AC          # noqa: E402
import db_ai_job as AJ          # noqa: E402

STATES = ('PENDING', 'DONE', 'FAIL', 'OK', 'REJ', 'LOADED')
STATE_NAME = {
    'PENDING': '대기', 'DONE': '검수 대기', 'FAIL': '실패',
    'OK': '승인', 'REJ': '반려', 'LOADED': '적재됨',
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS sys_ai_job (
    job_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT,
    asset_kind  TEXT NOT NULL,
    scope_value TEXT DEFAULT '',
    task        TEXT NOT NULL,
    base_lang   TEXT NOT NULL,
    lang        TEXT NOT NULL,
    profile_id  INTEGER,
    profile_ver INTEGER,
    model       TEXT,
    cap_chars   INTEGER DEFAULT 6000,
    created_at  TEXT,
    note        TEXT DEFAULT '',
    parts       TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS sys_ai_item (
    item_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id    INTEGER NOT NULL,
    slot_id   INTEGER NOT NULL,
    label     TEXT,
    state     TEXT NOT NULL DEFAULT 'PENDING',
    out_text  TEXT,
    why       TEXT,
    gate_json TEXT,
    n_in      INTEGER DEFAULT 0,
    n_out     INTEGER DEFAULT 0,
    ran_at    TEXT,
    UNIQUE(job_id, slot_id)
);
CREATE INDEX IF NOT EXISTS idx_ai_item_state ON sys_ai_item(job_id, state);
"""


def ensure(conn):
    conn.executescript(SCHEMA)
    # ⚠ **옛 DB 에도 칸을 더한다**(멱등) — `CREATE TABLE IF NOT EXISTS` 는
    #   이미 있는 표에 칸을 안 붙인다.
    try:
        cols = [r[1] for r in conn.execute("PRAGMA table_info(sys_ai_job)")]
        if 'parts' not in cols:
            conn.execute("ALTER TABLE sys_ai_job ADD COLUMN parts TEXT "
                         "DEFAULT ''")
        # ★ 317차-5 — 적재 방식(docs/1.txt 4-2)) · `STUDY`(연구질문)·`NOTE`(연구자료) 가 들면 그 칸은 **덧붙인다**
        #   · `LINKDESC` 면 구절연결기가 연결설명문을 **한 번에** 쓴다
        if 'add_mode' not in cols:
            conn.execute("ALTER TABLE sys_ai_job ADD COLUMN add_mode TEXT DEFAULT ''")
        # ★ 317차-5 — 게이트 반영 다시 쓰기(docs/1.txt 「게이트 걸림」) · 몇 번 고쳤나
        icols = [r[1] for r in conn.execute("PRAGMA table_info(sys_ai_item)")]
        if 'fix_note' not in icols:
            conn.execute("ALTER TABLE sys_ai_item ADD COLUMN fix_note TEXT")
        if 'fix_n' not in icols:
            conn.execute("ALTER TABLE sys_ai_item ADD COLUMN fix_n INTEGER DEFAULT 0")
        # ★ 317차-5 (docs/1.txt 4-2)) — 묶음 승인 때 **지금 글을 남길 칸**(설명문·묵상질문·묵상기도)
        if 'keep_parts' not in icols:
            conn.execute("ALTER TABLE sys_ai_item ADD COLUMN keep_parts TEXT DEFAULT ''")
        # ★ 2026-10-30 「원문 의심」 — 번역하며 AI 가 원문에서 본 흠(지적만 · 번역 글에는 안 섞는다)
        if 'src_note' not in icols:
            conn.execute("ALTER TABLE sys_ai_item ADD COLUMN src_note TEXT")
        conn.execute("CREATE TABLE IF NOT EXISTS sys_ai_srccheck (asset_kind TEXT NOT NULL, slot_id TEXT NOT NULL,"
                     " lang TEXT, checked_at TEXT, PRIMARY KEY (asset_kind, slot_id))")
    except Exception:                                     # noqa: BLE001
        pass
    conn.commit()


def _now():
    return datetime.datetime.now().isoformat(timespec='seconds')


# ══════════════════════════════════════════════════════════════════
#  작업 만들기
# ══════════════════════════════════════════════════════════════════

def create_job(conn, kind, scope, task, lang, slots, base=None,
               profile_id=None, model=None, cap=6000, name='', parts=None,
               add_mode=''):
    """작업 하나를 만들고 **건별 행을 미리 깐다**.

    `slots` = `[(자리번호, 이름)]` 또는 `[자리번호]`.
    `parts` = **묶음에서 이번에 쓸 칸**(1.txt 16-2 · 2 사용자 「내가 선택할
    수 있도록 하라」). 안 주면 표 그대로다(지금까지의 동작).
    ⚠ 미리 까 두는 까닭 — 그래야 「몇 개 중 몇 개 했다」를 셀 수 있고,
      중간에 죽어도 **무엇이 남았는지** 표가 알고 있다.
    """
    ensure(conn)
    base = (base or AJ.base_lang(kind, scope, conn)).upper()
    lang = (lang or base).upper()
    # ★★★ **남의 글은 다듬지 않는다** — 목록에서 빠져도 여기서 한 번 더 막는다
    #   (밖에서 자리를 직접 넘겨 만들 수 있다).
    _blk = AJ.edit_blocked(kind, task, lang, scope, conn)
    assert not _blk, _blk
    # ★★★ **프로필을 요구하지 않는다**(2026-09-29 294차 · 1.txt 1번 7)).
    #   옛 판은 `sys_ai_profile` 행이 없으면 「프롬프트 프로필이 없습니다」로
    #   막았고, 프로필이 없는 자산 11종(주석·연구 자료…)은 화면에 업무가
    #   보이는데 **누르면 안 되는 자리**였다(§0-1). 프롬프트의 집은 이제
    #   **층(`sys_ai_prompt`) 하나**다 — 층을 합쳐 역할·할 일이 있으면 된다.
    #   ⚠ `profile_id` 인자는 옛 호출부를 위해 받기만 한다(안 쓴다).
    _ok, _why = AJ.has_prompt(conn, kind, scope, task, lang)
    assert _ok, _why
    cur = conn.execute(
        "INSERT INTO sys_ai_job(name, asset_kind, scope_value, task, base_lang,"
        " lang, profile_id, profile_ver, model, cap_chars, created_at, parts, add_mode) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (name or ('%s · %s · %s→%s' % (AJ.ASSET[kind]['name'],
                                       AJ.TASK_NAME[task], base, lang)),
         kind, str(scope or ''), task, base, lang,
         None, 0,
         model or AC.task_model(conn, task), int(cap), _now(),
         ','.join(parts) if parts else '',
         (','.join(add_mode) if isinstance(add_mode, (list, tuple)) else (add_mode or ''))))
    job_id = cur.lastrowid
    n = 0
    for s in slots:
        sid, label = (s if isinstance(s, (tuple, list)) else (s, ''))
        conn.execute(
            "INSERT OR IGNORE INTO sys_ai_item(job_id, slot_id, label) "
            "VALUES(?,?,?)", (job_id, int(sid), label or ''))
        n += 1
    conn.commit()
    return job_id, n


def job(conn, job_id):
    ensure(conn)
    r = conn.execute(
        "SELECT job_id, name, asset_kind, scope_value, task, base_lang, lang,"
        " profile_id, profile_ver, model, cap_chars, created_at, note,"
        " COALESCE(parts,''), COALESCE(add_mode,'') "
        "FROM sys_ai_job WHERE job_id=?", (job_id,)).fetchone()
    if not r:
        return None
    # ★★★ 317차-5 — **`parts` 를 읽는다**. 옛 판은 이 칸을 안 읽어 실행·적재가 늘 「표 그대로」
    #   (다섯 칸)로 돌았다 — 연구질문·연구자료를 풀어도 써서 담았다(실측 작업 589).
    return dict(zip(('job_id', 'name', 'asset_kind', 'scope_value', 'task',
                     'base_lang', 'lang', 'profile_id', 'profile_ver', 'model',
                     'cap_chars', 'created_at', 'note', 'parts', 'add_mode'), r))


def add_modes(j):
    """그 작업의 적재 방식 낱말들 — `{'STUDY','NOTE','LINKDESC','NODESC'}` 의 부분집합
    (`NODESC` = 구절연결을 담아도 연결설명문 작업을 안 만든다 · 2026-10-11)."""
    return {x.strip().upper() for x in str((j or {}).get('add_mode') or '').split(',') if x.strip()}


def jobs(conn):
    ensure(conn)
    return conn.execute(
        "SELECT j.job_id, j.name, j.created_at, "
        " (SELECT COUNT(*) FROM sys_ai_item i WHERE i.job_id=j.job_id), "
        " (SELECT COUNT(*) FROM sys_ai_item i WHERE i.job_id=j.job_id "
        "    AND i.state='PENDING') "
        "FROM sys_ai_job j ORDER BY j.job_id DESC").fetchall()


def counts(conn, job_id):
    """상태별 건수 — `{상태: 수}`."""
    ensure(conn)
    d = {s: 0 for s in STATES}
    for st, n in conn.execute(
            "SELECT state, COUNT(*) FROM sys_ai_item WHERE job_id=? GROUP BY 1",
            (job_id,)):
        d[st] = n
    return d


def items(conn, job_id, state=None, limit=0):
    ensure(conn)
    q = ("SELECT item_id, slot_id, label, state, out_text, why, gate_json,"
         " n_in, n_out, ran_at FROM sys_ai_item WHERE job_id=?")
    args = [job_id]
    if state:
        q += " AND state=?"
        args.append(state)
    q += " ORDER BY item_id"
    if limit:
        q += " LIMIT %d" % int(limit)
    return conn.execute(q, args).fetchall()


def delete_job(conn, job_id):
    """작업을 지운다 — **적재된 건이 있으면 거부한다**(자국을 남긴 작업이다)."""
    ensure(conn)
    n = conn.execute("SELECT COUNT(*) FROM sys_ai_item WHERE job_id=? "
                     "AND state='LOADED'", (job_id,)).fetchone()[0]
    assert not n, '이미 적재한 건이 %d개 있습니다 — 지우지 않습니다.' % n
    conn.execute("DELETE FROM sys_ai_item WHERE job_id=?", (job_id,))
    conn.execute("DELETE FROM sys_ai_job WHERE job_id=?", (job_id,))
    conn.commit()


# ══════════════════════════════════════════════════════════════════
#  돌리기
# ══════════════════════════════════════════════════════════════════

# ★★★ **2어절이다 — 실측으로 정했다**(사람 글 13,453편 · 이웃 ±3절과
#   첫머리가 같은 비율): 2어절 **3.03%** · 3어절 0.52% · 4어절 0.09%.
#   ⚠ 3어절로 두면 「이 구절은 하나님이 / 이 구절은 하나님을」이 **다르게
#     세어져 상투구를 놓친다**(실측 — 걸린 것이 0건이었다). AI 는 그 2어절이
#     **69%**(13편 중 9편)라 사람의 3.03% 대비 스물세 배다.
#   ⚠ 사람 글도 3%는 걸린다 — 그 정도는 검수자가 보면 되고, 실제로 「같은
#     말로 시작」한 것이라 지적이 틀린 것도 아니다.
# ★★★ **고유명사는 개역한글 표기로 통일한다**(2026-09-23 사용자 지시).
#   ⚠⚠ **「개역한글이 옳아서」가 아니다** — 우리 기본 역본이 그것이므로 글과
#     본문의 표기가 같아야 **나중에 역본을 바꿀 때 한 번에 치환**할 수 있다.
#     섞여 있으면 그날 손으로 하나하나 골라야 한다. 까닭을 안 적으면 다음
#     사람이 「개역개정이 낫다」며 뒤집는다.
#   ⚠ 이 표는 **KRV 본문으로 검증해서 만들었다** — 옛 표기가 KRV 에 있고 새
#     표기가 없을 때만 넣었다(`temp_code_krvname.py`). 지어낸 쌍을 넣으면
#     멀쩡한 글을 흠으로 신고한다. 늘릴 때도 같은 검증을 거친다.
NAME_FIX = [
    ('바빌론', '바벨론'),
    ('이집트', '애굽'),
    ('아시리아', '앗수르'),
    ('다마스쿠스', '다메섹'),
    ('파라오', '바로'),
    ('네부카드네자르', '느부갓네살'),
    ('키루스', '고레스'),
    ('필라도', '빌라도'),
    ('유프라테스', '유브라데'),
    ('티그리스', '힛데겔'),
    ('니네베', '니느웨'),
]


def name_clash(text):
    """개역한글이 아닌 표기를 쓴 자리 — `['바빌론 → 바벨론']`."""
    t = text or ''
    return ['  표기가 개역한글과 다르다: 「%s」 → 「%s」' % (b, o)
            for b, o in NAME_FIX if b in t]


# ★★★ **다듬기는 「잃은 것」으로 망가진다** — 신규와 잣대가 다르다.
#   실측(2026-09-23) — 괄호 안 설명과 **성경 참조가 통째로 사라지고**,
#   원문에 없던 **빈 줄이 늘어** 화면에서 이중 간격이 되었다. 둘 다 「새 흠」이
#   아니라서 여느 게이트로는 안 잡힌다. **앞글과 견주어야만** 보인다.
LOSS_SHRINK = 0.75       # 이보다 짧아지면 너무 깎은 것으로 본다


_NAMES = [None]


def _entity_names(conn):
    """성경 고유명사 — **우리가 이미 가진 엔티티 이름**을 쓴다.

    ⚠ 두 글자 미만은 뺀다(흔한 말과 겹친다). 한 번 읽어 두고 쓴다.
    """
    if _NAMES[0] is None:
        try:
            rows = conn.execute(
                "SELECT contents FROM sys_text_asset WHERE "
                "text_type='ENTITY_NAME' AND UPPER(lang_code)='KO' "
                "AND COALESCE(record_status,'LIVE')='LIVE'").fetchall()
            _NAMES[0] = sorted({(r[0] or '').strip() for r in rows
                                if len((r[0] or '').strip()) >= 2},
                               key=len, reverse=True)
        except Exception:                                 # noqa: BLE001
            _NAMES[0] = []
    return _NAMES[0]


def edit_loss(before, after, conn=None):
    """다듬으며 **잃은 것** — 앞글과 견준다. `[까닭]`."""
    b, a = (before or ''), (after or '')
    if not b.strip():
        return []
    out = []

    def _fix(x):
        # ⚠ **우리가 시킨 표기 수정은 「잃은 것」이 아니다** — 「(이집트)」를
        #   「(애굽)」으로 고친 것을 사라졌다고 하면 멀쩡한 수정을 흠으로
        #   신고한다(실측으로 당했다). 견주기 전에 같은 치환을 먹인다.
        for _b, _o in NAME_FIX:
            x = x.replace(_b, _o)
        return x

    # ⓐ 괄호 안 내용 — 설명·성경 참조가 거기 들어 있다
    pb = set(re.findall(r'\([^)]{1,40}\)', b))
    lost = [x for x in pb if x not in a and _fix(x) not in a]
    if lost:
        out.append('  다듬으며 괄호가 사라졌다: %s' % ' '.join(sorted(lost)[:4]))
    # ⓑ 성경 참조 — 괄호 밖에 있는 것까지
    #   ⚠ **약명으로 좁힌다** — 옛 판은 아무 한글 두세 자 + 숫자를 참조로 보아
    #     「가나**안은 9:25**」를 집었다. 멀쩡한 글을 흠으로 신고하는 자리다.
    rb = set()
    if conn is not None:
        try:
            abv = [x for x in AJ.book_abbr(conn, 'KO').values() if x]
            pat = r'(?:%s)\s?\d{1,3}[:장]\d{0,3}' % '|'.join(
                re.escape(x) for x in sorted(abv, key=len, reverse=True))
            rb = set(re.findall(pat, b))
        except Exception:                                 # noqa: BLE001
            rb = set()
    lost2 = [x for x in rb if x not in a and _fix(x) not in a]
    if lost2:
        out.append('  다듬으며 구절 표기가 사라졌다: %s'
                   % ' '.join(sorted(lost2)[:4]))
    # ⓒ-1 **인용부호** — 성경 인용과 저자의 설명이 섞이면 안 된다.
    #   실측 — 「'그런즉 우리가 무슨 말 하리요.' 바울은…」이 「우리가 무슨 말
    #   하리요 하고 바울은…」으로 바뀌어 **인용 표시가 통째로 사라졌다**.
    #   ⚠ 괄호 검사는 `(…)` 만 본다 — 따옴표는 다른 기호라 안 잡혔다.
    nq_b = len(re.findall(r"'[^']{4,80}'|「[^」]{4,80}」|\"[^\"]{4,80}\"", b))
    nq_a = len(re.findall(r"'[^']{4,80}'|「[^」]{4,80}」|\"[^\"]{4,80}\"", a))
    if nq_a < nq_b:
        out.append('  인용 표시가 %d군데 사라졌다 — 성경 인용과 설명이 '
                   '섞인다' % (nq_b - nq_a))
    # ⓒ 빈 줄 — 원문에 없던 것을 새로 넣지 않는다(§28-11 이중 간격)
    nb, na = b.count('\n\n'), a.count('\n\n')
    if na > nb:
        out.append('  원문에 없던 빈 줄이 %d개 늘었다(화면에서 간격이 벌어진다)'
                   % (na - nb))
    # ⓓ **고유명사가 사라졌다** — 실측으로 찾았다(2026-09-23):
    #   「훗날 이 강가는 **바벨론** 포로의 땅이 됩니다」를 어투만 다듬다가
    #   「포로로 잡혀간 땅」으로 바꿔 **이름을 잃었다.** 괄호도 구절 표기도
    #   아니라 위 검사들이 못 잡는다. 우리가 가진 엔티티 이름으로 잰다.
    if conn is not None:
        gone = [n for n in _entity_names(conn) if n in b and n not in a]
        if gone:
            out.append('  다듬으며 이름이 사라졌다: %s' % ' '.join(gone[:4]))
    # ⓔ **보탠 머리줄** — 원문에 없던 제목·머리말을 앞에 붙였나.
    #   실측 — 도서 다듬기가 재료의 「편 제목」을 본문 맨 앞에 넣었다.
    fa = [x.strip() for x in a.splitlines() if x.strip()]
    fb = [x.strip() for x in b.splitlines() if x.strip()]
    if fa and fb and fa[0] != fb[0] and fa[0] not in b and len(fa[0]) <= 60:
        out.append('  원문에 없던 머리줄을 붙였다: 「%s」' % fa[0][:40])
    # ⓕ 너무 깎였다
    if len(a) < len(b) * LOSS_SHRINK:
        out.append('  글이 %d%% 로 줄었다 — 다듬기가 아니라 깎아 낸 것이다'
                   % round(100.0 * len(a) / max(1, len(b))))
    return out


HEAD_WORDS = 2           # 첫머리로 볼 어절 수
HEAD_NEAR = 3            # 앞뒤로 이만큼 떨어진 절까지 이웃으로 본다


def head_of(text, n=HEAD_WORDS):
    """글의 **첫머리** — 앞 몇 어절. 상투구를 잡는 잣대다."""
    w = re.findall(r'[가-힣A-Za-z0-9]+', text or '')
    return ' '.join(w[:n])


def head_clash(conn, kind, slot_id, lang, text, seen=None):
    """첫머리가 **이 작업 안** 또는 **이웃 절**과 겹치는가 — 겹친 까닭을 낸다.

    ★ 낱말을 금지하지 않는다 — 무엇이 유행하든 「같은 말로 시작한다」를 잡는다.
    """
    h = head_of(text)
    if not h:
        return []
    bad = []
    if seen and h in seen:
        bad.append('  첫머리가 이 작업의 다른 글과 같다: 「%s …」' % h)
    a = AJ.ASSET.get(kind) or {}
    if a.get('slot') == 'VERSE':
        r = conn.execute("SELECT bcode, chapter, verse FROM bible_index "
                         "WHERE verse_id=?", (slot_id,)).fetchone()
        if r:
            rows = conn.execute(
                "SELECT t.contents FROM sys_text_asset t "
                "JOIN bible_index b ON b.verse_id=t.clicked_id "
                "WHERE t.text_type=? AND UPPER(t.lang_code)=? "
                "AND COALESCE(t.record_status,'LIVE')='LIVE' "
                "AND b.bcode=? AND b.chapter=? AND b.verse BETWEEN ? AND ? "
                "AND t.clicked_id<>?",
                (a.get('text_type'), str(lang).upper(), r[0], r[1],
                 r[2] - HEAD_NEAR, r[2] + HEAD_NEAR, slot_id)).fetchall()
            for (t,) in rows:
                if head_of(t) == h:
                    bad.append('  첫머리가 이웃 절 글과 같다: 「%s …」' % h)
                    break
    return bad


def _cite_lines(conn, text, lang='KO'):
    """성경 인용을 우리 역본과 대조한 줄 — 한국어 글에만 건다.

    ★★★ **언어마다 기준 역본이 다르다**(2026-09-25) — 러시아어 번역문은
      시노드역과, 일본어는 JLV 와 견준다. 옛 판은 한국어만 쟀다.
    ⚠ **기준을 모르는 언어는 안 잰다** — 지어낸 기준으로 재면 온 글이 흠이 된다.
    ⚠ 게이트가 터져도 검수를 막지 않는다 — 까닭을 한 줄로 적고 넘어간다.
    """
    try:
        import db_cite_gate as CG
        return CG.check(conn, text, lang=(lang or 'KO'))
    except Exception as e:                                # noqa: BLE001
        return ['(인용 대조를 못 돌렸습니다: %s)' % e]


def taste_lines(src, out, lang='KO'):
    """맛보기 조각 한 편을 **원본과 견준다** — 흠 목록(빈 목록 = 통과).

    ★ 묻는 것은 「잘 옮겼나」가 아니라 **「같은 모양인가」**다(`booktrans.md`
      게이트와 같은 문법). 잘 옮겼나는 사람이 본다.
    ⚠ **표식은 도구가 붙인다** — 옮긴 글이 적으면 흠이다.
    ⚠ 길이비는 **알림**이다 — 언어마다 크게 다르다(실측 KO→EN 1.82배).
    """
    try:
        import db_pack_taste as _T
        mark = _T.TASTE_MARK
    except Exception:                                     # noqa: BLE001
        mark = '\u27e8맛보기 여기까지\u27e9'
    if not (out or '').strip():
        return ['빈 글입니다.']
    bad = []
    if mark in out:
        bad.append('맛보기 표식을 글에 적었습니다 — 표식은 도구가 붙입니다.')
    body = (src or '').split(mark)[0].rstrip()
    sp = [p for p in body.split(chr(10)) if p.strip()]
    op = [p for p in (out or '').split(chr(10)) if p.strip()]
    if sp and len(op) != len(sp):
        bad.append('문단(줄) %d개 — 원본은 %d개입니다(합치거나 나누지 않습니다).'
                   % (len(op), len(sp)))
    a, b = len(body), len((out or '').strip())
    if a and not (0.5 <= b / float(a) <= 3.2):
        bad.append('(길이비 %.2f — 원본 %d자 · 옮긴 글 %d자. 사람이 봅니다)'
                   % (b / float(a), a, b))
    return bad


# ══════════════════════════════════════════════════════════════════
#  게이트 등록표 — **무엇을 재고 무엇을 못 재나**(2026-09-29 294차 · 1.txt 1번 4))
# ══════════════════════════════════════════════════════════════════
#
# ★★★ 사용자 지시 — 「게이트가 어떻게 구성되어 있는지 목록을 표시하라.
#   **필수와 참고**를 구분하라. **어떤 위험이 있는지** 표시하라. 샘플에서
#   발견된 문제를 근거로 **없는 게이트를 전부 만들어라**」.
# ⚠ 이 표는 **설명**이지 실행 규칙이 아니다 — 실행은 `gate_item`·`gate_bundle`
#   의 분기가 한다. `gates_for(kind, task)` 가 그 분기를 **같은 조건으로**
#   되짚어 어느 게이트가 걸리는지 낸다(selftest 가 둘이 어긋나지 않는가를 잰다).
# 갈래 — `MUST`(걸리면 검수를 부른다) · `NOTE`(알림 · 사람이 본다)
GATE_CATALOG = [
    # (열쇠, 이름, 갈래, 무엇을 재나, 놓치면 무슨 위험이 있나)
    # ★★★ 297차 — 구절 연결기(VERS_LINK)
    ('link_review', '연결 점검 줄', 'MUST',
     '줄마다 「약명 · 지금 갈래 · 유지/해제/바꿈:코드 · 까닭」 · 지금 이어진 구절만 · 빠짐 없음',
     '없는 연결을 해제하거나 엉뚱한 갈래로 바꾼다'),
    ('link_form', '연결 줄 꼴', 'MUST',
     '줄마다 「약명 장:절 · 갈래 · 왜」로 읽히나 · 3~8줄인가(구절 연결기)',
     '못 읽는 줄은 적재에서 조용히 빠진다 — 사람이 승인한 것과 담기는 것이 달라진다'),
    ('link_ref', '절 표기가 실재하나', 'MUST', '약명·장·절이 우리 좌표로 풀리나(구절 연결기)',
     '없는 절·엉뚱한 책이 연결로 들어간다'),
    ('link_rel', '갈래 코드', 'MUST', '갈래가 열두 코드 가운데 하나인가(구절 연결기)',
     '모르는 갈래가 들어가 화면 색표·구속사 흐름 판정에서 빠진다'),
    ('link_near', '같은 장 금지', 'MUST', '같은 장 안의 절로 잇지 않았나(구절 연결기)',
     '이웃 절끼리 이어져 연결 화면이 그 장 안을 맴돈다'),
    ('link_dup', '이미 이어진 절', 'NOTE', '사람이나 AI 가 이미 이은 절을 또 냈나(구절 연결기)',
     '같은 짝이 두 번 담긴다(UNIQUE 가 막지만 갈래가 다르면 둘이 된다)'),
    ('structure', '구조 · 짝 · 내용 보존', 'MUST',
     '문단이 있나 · 한국어/영어 짝이 맞나 · 다듬으며 내용을 잃지 않았나(절 자산 · 신규·다듬기)',
     '문단 없는 벽글 · 한 언어만 남은 절 · 다듬으며 뜻이 바뀐 글이 그대로 실린다'),
    ('dash', '대시(—) 금지', 'MUST', '「—」 가 든 문장(절 자산 · 우리 글 전부)',
     '색인체 문장이 섞여 한 화면에서 결이 갈린다(§28-6)'),
    ('yoche', '본문 재진술(요체)', 'MUST', '구절 본문을 그대로 되풀이한 문장(절 자산)',
     '설명이 아니라 본문 베끼기가 실린다'),
    ('selfquote', '자문자답', 'MUST', '물음을 던지고 스스로 답하는 꼴(절 자산)',
     '설교 투가 설명문에 섞인다'),
    ('head', '첫머리 겹침', 'MUST', '한 작업 안에서 첫 두 어절이 같은 글(절 자산 · 신규·다듬기)',
     '「이 구절은…」으로 시작하는 글이 줄줄이 나온다'),
    ('names', '표기 고정', 'MUST', '개역한글 표기와 다른 이름(바빌론·이집트 …)(전 자산)',
     '한 앱 안에서 같은 사람·땅 이름이 두 가지로 적힌다'),
    ('untranslated', '옮기지 않음', 'MUST', '번역인데 원문 글자체계가 20% 넘게 남았나(번역 · 전 자산)',
     '한국어 글이 영어 자산으로 적재된다(2026-09-23 실측)'),
    ('edit_loss', '다듬기 손실', 'MUST', '다듬기 전과 견줘 잃은 문장·너무 줄어든 분량(다듬기 · 전 자산)',
     '「다듬기」가 조용히 「줄이기」가 된다'),
    ('cite', '성경 인용 대조', 'MUST', '인용한 구절이 그 언어 기준 역본과 글자 그대로인가(도서·소개문·맛보기·연구 자료 · 한국어 글)',
     '역본 인용을 AI 가 제 손으로 다시 옮긴다(실측 112곳 중 53곳)'),
    ('comm_ref', '주석 장 번호', 'MUST', '원문의 (ver. N) 이 그 장의 N절로 옮겨졌나 — 같은 책 다른 장(특히 1장)으로 바뀐 참조(주석 번역)',
     '시편 36편 주석에 「(시 1:1)」이 적힌다(2026-10-25 실측 54건)'),
    ('comm_form', '주석 문체·참조 표시', 'MUST', '한국어 합니다체 하나인가 · 글 끝 참조 표시 {a} 수가 원문과 같은가(주석 번역)',
     '묶음마다 문체가 갈리고(빌립보서 시범 합니다체 67 · 한다체 36) 참조 줄이 사라진다'),
    ('cite_soft', '성경 인용 대조(부분)', 'NOTE', '겹침 0.60~0.85 — 부분 인용과 재번역이 섞인 구간',
     '부분 인용을 흠으로 몰면 온 글이 흠투성이가 된다 — 사람이 본다'),
    ('study', '연구 자료 서식', 'MUST', '기호·번호·음독(원어)·인용 줄 꼴·길이 하한(연구 자료)',
     '연구 자료 화면이 자유 서식으로 갈리고 구절 연결을 못 만든다'),
    ('taste', '맛보기 조각 꼴', 'MUST', '문단 수 · 표식 · 길이비(참고)(맛보기 조각)',
     '잘린 자리가 어긋나 사용자가 글이 그렇게 끝난 줄 안다'),
    ('intro', '소개문 꼴', 'MUST', '문단 수 · 출처 블록 · 기관 이름·연도 글자 그대로(도서 소개문)',
     '저작권 고지가 다른 자료를 가리킨다'),
    ('attrib', '출처 줄', 'NOTE', '적재할 때 붙는 출처 줄을 미리 보인다 · 책을 못 찾으면 흠(도서 본문)',
     '승인했는데 적재에서 조용히 건너뛰는 건이 생긴다'),
    ('bundle_pair', '묶음 칸 사이 겹침', 'MUST', '설명·질문·기도·연구 칸이 서로 같은 말을 되풀이하나(절 묶음)',
     '한 절에 같은 문장이 네 번 뜬다'),
    ('trans_paras', '번역 · 문단 수', 'MUST', '옮긴 글의 문단 수가 원본과 같은가(번역 · 도서·주석·자료집·우리 글)',
     '문단을 합치거나 쪼갠 번역이 원문과 다른 짜임으로 실린다'),
    ('trans_blank', '번역 · 군더더기 빈 줄', 'MUST', '빈 줄이 두 겹 넘게 이어지나(번역)',
     '화면 간격이 벌어진다(§28-11)'),
    ('trans_script', '번역 · 원문 글자체계 잔존', 'MUST', '원문 언어 글자가 20% 넘게 남았나(번역 · 기준 언어와 대상 언어의 글자체계가 다를 때)',
     '영어 문단이 그대로 한국어 자산에 실린다'),
    ('trans_orig', '번역 · 원어 낱자', 'MUST', '원본에 없는 히브리·헬라 글자를 새로 적었나(번역)',
     '지어낸 원어가 실린다(§28-11 원어 문자 노출 금지)'),
    ('trans_ar_digits', '번역 · 아랍어 숫자 혼용', 'MUST', '한 글에 아라비아 숫자(٠-٩)와 서양 숫자(0-9)가 섞였나(아랍어)',
     '같은 절 번호가 두 가지 숫자로 적혀 읽는 사람이 헷갈린다(샘플에서 발견)'),
    ('trans_markup', '번역 · 서식 군더더기', 'MUST', '마크다운 머리(#·**)·코드 울타리·「번역:」 머리말이 붙었나(번역)',
     '출력서식을 어긴 글이 화면에 기호째 뜬다'),
    ('ours', '우리 글 꼴', 'MUST',
     '대시(—) · 합니다체 · 동그라미 번호 · 원어 글자 노출 · 교단 귀속어 · 분량 · 한 줄 꼴'
     '(구절연결 설명문 · 단락 설명문·제목 · 장 설명문 · 책 개요 · 용어 설명문·이름)',
     '절 자산 밖의 우리 글이 아무 검사 없이 실렸다(295차 실측 — 구절연결 설명문 반려 3건)'),
    ('peri_style', '단락·장 문체', 'MUST',
     '번역투 · 현학어 · 예고형 · 비유 · 저자 주어 · 책 갈래별 분량(단락 설명문 · 장 설명문)',
     '`db_peri_gate` 가 이미 있는데 AI 작업대 경로만 그것을 안 지났다'),
    ('term_desc', '용어 설명문 꼴', 'MUST',
     '문단 3~7 · 250~1,200자 · 글이 그 이름을 부르나 · 인용한 절이 실재하나(용어 설명문)',
     '기억으로 적은 절 번호·이름을 안 부르는 글이 그대로 실린다(`db_term_desc` 잣대)'),
    ('trans_table', '번역 · 표', 'MUST', '자료집 글의 표 자리표 [[T1]] 이 그대로이고 칸 번호 목록의 칸 수가 맞는가(번역·다듬기)',
     '표가 사라지거나 칸이 어긋난 채 담긴다'),
    ('trans_marks', '번역 · 증거 구절 표시', 'MUST', '(a)(b)… 표시의 차례·개수가 원본과 같은가(번역)',
     '문답 증거 구절 글자가 밀려 엉뚱한 구절을 가리킨다(2026-10-25 실측)'),
    ('trans_ratio', '번역 · 길이비', 'NOTE', '원본 대비 0.4~3.5 밖이면 알린다(번역)',
     '언어마다 다르므로 막지 않는다 — 사람이 본다'),
    # ★ 2026-10-11 — 제미나이 적재분 전수 점검(`temp_code_p373_booktrans_audit`)에서 드러난 것
    ('trans_lang', '번역 · 써 넣을 언어', 'MUST',
     '글이 정말 그 언어 글자로 쓰였나 · 다른 언어 글에 한글이 섞였나(번역 · 맛보기·소개문 포함)',
     '일본어·중국어 자리에 한국어·프랑스어 글이 실린다(실측 14건) · 출처 줄에 한국어가 남는다(32건)'),
    ('link_kind', '갈래 판정 알림', 'NOTE',
     '성취(FUL)가 신·구약을 안 건너나 · 그리스도 성취(INC)에 신약 절이 없나 · 유사(SYN)가 절반을 넘나 · '
     '상대 절에 AI 연결이 몰렸나(구절 연결기)',
     'AI 갈래 판정이 약하다(296·297차 · 2026-10-11 실측 SYN 34% ↔ 사람 1%) — 사람이 갈래를 본다'),
    ('vvd_reader', '연결설명문 · 독자 부름 · 본문 베낌', 'MUST',
     '「당신의 삶 속에서도…」처럼 독자를 부르나 · 두 절 가운데 한 절의 본문을 그대로 옮겼나(구절연결 설명문)',
     '설명문에 적용이 섞인다(실측 178편) · 설명 대신 성경 본문이 실린다(실측 7편)'),
]
GATE_NAME = {k: n for k, n, _lv, _w, _r in GATE_CATALOG}


def gates_for(kind, task='NEW'):
    """그 자산·업무에 **어느 게이트가 걸리나** — 등록표 열쇠 목록.

    ⚠ `gate_item`·`gate_bundle` 의 분기를 **같은 조건으로** 되짚는다. 분기를
      고치면 여기도 고친다(selftest 가 「등록표 열쇠가 어디에도 안 걸리는가」와
      「걸린다고 한 게이트가 실제로 줄을 내는가」를 잰다).
    """
    a = AJ.ASSET.get(kind) or {}
    t = str(task or 'NEW').upper()
    g = []
    if a.get('store') == 'BUNDLE':
        g += ['structure', 'dash', 'yoche', 'selfquote', 'head', 'names',
              'bundle_pair', 'study', 'cite']
        if t == 'EDIT':
            g.append('edit_loss')
        if t == 'TRANS':
            g.append('untranslated')
        return g
    if a.get('store') == 'LINK':
        if AJ.is_link_review(kind, t):
            return ['link_review']
        return ['link_form', 'link_ref', 'link_rel', 'link_near', 'link_dup', 'link_kind']
    if kind in ('REF_STUDY', 'REF_UNIT'):
        g += ['study', 'cite', 'cite_soft']
    if a.get('store') == 'REF' and t in ('TRANS', 'EDIT'):
        g.append('trans_table')                           # ★ 317차-18 ⑦
    elif kind == 'BOOK_TASTE':
        g += ['taste', 'cite', 'cite_soft']
    elif kind == 'BOOK_INTRO':
        g += ['intro', 'cite', 'cite_soft']
    elif kind == 'BOOK_UNIT':
        g += ['attrib', 'cite', 'cite_soft']
    elif kind == 'COMMENTARY':
        if t == 'TRANS':
            g += ['comm_ref', 'comm_form']                # ★ 2026-10-25 · 2026-10-31
    elif kind in OURS_KINDS:
        g += ['ours', 'names']
        if kind == 'VERS_VERS_DESC':
            g.append('vvd_reader')
        if kind in ('PERI_DESC', 'CHAP_DESC'):
            g.append('peri_style')
        if kind == 'ENTITY_DESC':
            g.append('term_desc')
    elif a.get('slot') == 'VERSE':
        if t != 'TRANS':
            g += ['structure', 'head']
        g += ['dash', 'yoche', 'selfquote', 'names']
        if t == 'TRANS':
            g.append('untranslated')
    if t == 'EDIT':
        g += ['edit_loss', 'names'] if 'names' not in g else ['edit_loss']
    if t == 'TRANS':
        g.append('trans_lang')                            # ★ 2026-10-11 — 맛보기·소개문도
    if t == 'TRANS' and kind not in ('BOOK_TASTE', 'BOOK_INTRO'):
        # ⚠ 아랍어 숫자 혼용은 **언어 조건**이라 여기서는 늘 든다(대상 언어가
        #   AR 일 때만 실제로 줄을 낸다) — 등록표에 있는데 아무 자산에도 안
        #   걸리는 것으로 보이지 않게.
        g += ['trans_paras', 'trans_blank', 'trans_script', 'trans_orig',
              'trans_ar_digits', 'trans_markup', 'trans_marks', 'trans_ratio']
    # 중복 제거(차례 유지)
    seen, out = set(), []
    for k in g:
        if k not in seen:
            seen.add(k)
            out.append(k)
    return out


def gate_rows(kind=None, task=None):
    """화면용 — `[(열쇠, 이름, 갈래, 무엇을, 위험, 이 자산·업무에 걸리나)]`."""
    on = set(gates_for(kind, task or 'NEW')) if kind else None
    return [(k, n, lv, w, r, (None if on is None else (k in on)))
            for k, n, lv, w, r in GATE_CATALOG]


# ── 글자체계 — 번역 공통 게이트가 「원문이 남았나」를 재는 잣대 ──────────
SCRIPT_OF = {'KO': 'HANGUL', 'EN': 'LATIN', 'DE': 'LATIN', 'FR': 'LATIN',
             'ES': 'LATIN', 'PT': 'LATIN', 'LA': 'LATIN', 'RU': 'CYRIL',
             'JA': 'JAPAN', 'ZH': 'CJK', 'ZHT': 'CJK', 'AR': 'ARABIC'}
SCRIPT_RE = {'HANGUL': r'[가-힣]', 'LATIN': r'[A-Za-z\u00c0-\u024f]',
             'CYRIL': r'[\u0400-\u04ff]', 'JAPAN': r'[\u3040-\u30ff\u4e00-\u9fff]',
             'CJK': r'[\u4e00-\u9fff]', 'ARABIC': r'[\u0600-\u06ff]'}
_ORIG_RE = re.compile(r'[\u0590-\u05ff\u0370-\u03ff\u1f00-\u1fff]')
_ALL_LETTERS = re.compile(r'[가-힣A-Za-z\u00c0-\u024f\u0400-\u04ff\u3040-\u30ff'
                          r'\u4e00-\u9fff\u0600-\u06ff]')
_MARKUP_HEAD = re.compile(r'^\s*(#{1,6}\s|\*\*|```|번역\s*[:：]|Translation\s*:|譯文|翻訳)',
                          re.I)
SCRIPT_LEFT_AT = 0.20


#: 독자를 부르는 「당신」 — 하나님을 높여 가리키는 「당신」(당신의 뜻·당신 발)은 뺀다
_READER = re.compile(r'당신(이|은|을|에게|도|의 (삶|하루|묵상|일상|마음|믿음))|여러분|평신도 크리스찬인')
_GODSELF = re.compile(r'당신(의)? ?(뜻|사람|일꾼|백성|이름|구속|나라|자녀|영광|발|약속|계획|손|종)')


def lang_lines(out, lang):
    """**써 넣을 언어** 게이트(2026-10-11) — 옮긴 글이 정말 그 언어로 쓰였나.

    ★ `trans_common` 의 「원문 글자 잔존」은 **기준 언어 글자**만 센다 — 그래서 기준이
      영어인 맛보기가 **한국어**로 나와도(JA 자리 · 실측 6편) 소개문이 프랑스어로
      나와도(ZHT 자리) 통과했다. 여기서는 **써 넣을 언어의 글자**가 절반을 넘는지 잰다.
    ★ 한국어가 아닌 글에 한글이 2% 넘게 섞이면 흠 — 출처 블록에 「판본: 1889년」
      같은 한국어 줄이 그대로 남던 자리(실측 32편).
    ⚠ 글자 40자 미만이면 안 잰다 · 그 언어 글자체계를 모르면 안 잰다.
    """
    o = out or ''
    lang = str(lang or '').upper()
    ts = SCRIPT_OF.get(lang)
    n_all = len(_ALL_LETTERS.findall(o))
    if not ts or n_all < 40:
        return []
    ls = []
    own = len(re.findall(SCRIPT_RE[ts], o)) / float(n_all)
    if own < 0.5:
        ls.append('써 넣을 언어(%s) 글자가 %.0f%%뿐입니다 — 다른 언어로 썼습니다.' % (lang, 100 * own))
    if lang != 'KO':
        # ★ 넉 자부터 — 실측 다른 언어 글 1,500여 편에서 한글 4자 이상은 전부 흠이었다
        #   (머리줄·성경 인용·사람 이름이 한국어로 남은 자리)
        ko = len(re.findall(r'[가-힣]', o))
        if ko >= 4:
            ls.append('한글이 %d자 섞였습니다 — 출처 줄·머리까지 %s 로 옮깁니다.' % (ko, lang))
    return ls


def vvd_lines(conn, slot_id, text):
    """구절연결 설명문(한국어) — 독자 부름 · 본문 베낌(2026-10-11)."""
    t = text or ''
    ls = []
    for sent in re.split(r'(?<=[.!?])\s+', t):
        # 따옴표 안은 성경 인물의 말이다(「당신은 나의 누이라」) — 독자 부름이 아니다
        bare = re.sub(r'["“「『\'‘][^"”」』\'’]*["”」』\'’]', '', sent)
        if _READER.search(bare) and not _GODSELF.search(bare):
            ls.append('독자를 부르는 문장이 있습니다 — 설명문에 적용을 넣지 않습니다: %s' % sent[:40])
            break
    try:
        r = conn.execute("SELECT clicked_id, target_id FROM sys_link_asset WHERE sys_link_id=?",
                         (slot_id,)).fetchone()
    except Exception:                                     # noqa: BLE001
        r = None
    if r:
        nt = re.sub(r'[^가-힣]', '', t)
        for v in r:
            row = conn.execute("SELECT verse_text FROM bible_content WHERE verse_id=? AND version_code='KRV'",
                               (v,)).fetchone()
            nv = re.sub(r'[^가-힣]', '', (row and row[0]) or '')
            if len(nt) >= 10 and nv and (nt in nv or (nv in nt and len(nv) > 0.7 * len(nt))):
                ls.append('두 절 가운데 한 절의 본문을 그대로 옮겼습니다 — 왜 잇는지를 설명합니다.')
                break
    return ls


def trans_common(src, out, base, lang):
    """**번역 공통 게이트** — 어느 자산이든 옮긴 글이면 잰다(2026-09-29 294차).

    ★★★ 1.txt 1번 4) — 샘플 반려에서 드러난 것(문단 합침 · 원문 문단 잔존 ·
      아랍어 숫자 혼용 · 마크다운 머리)이 **자산 하나의 게이트**에만 있어
      다른 자산에서는 같은 흠이 그대로 통과했다. 옮기는 일의 흠은 자산과
      무관하므로 한 문으로 모은다.
    ⚠ 「잘 옮겼나」는 안 묻는다 — **같은 모양인가**만 잰다(`taste_lines` 와 같은 문법).
    ⚠ 원본이 없으면(`src` 빈 글) 원본과 견주는 항목은 건너뛰고 그 사실을 적는다.
    """
    ls = []
    o = (out or '').strip()
    if not o:
        return ['빈 글입니다.']
    lang = str(lang or '').upper()
    base = str(base or '').upper()
    s = (src or '').strip()
    if s:
        sp = [p for p in s.split(chr(10)) if p.strip()]
        op = [p for p in o.split(chr(10)) if p.strip()]
        if sp and len(op) != len(sp):
            ls.append('문단(줄) %d개 — 원본은 %d개입니다(합치거나 나누지 않습니다).'
                      % (len(op), len(sp)))
        # ★ 2026-10-25 (docs/1.txt 7 재검토) 증거 구절 표시 (a)(b)… — 문답 번역이 글자를 하나씩 밀어(a~j → a~i)
        #   **어느 글자가 어느 구절을 가리키나**가 어긋났다. 차례·개수가 원본과 같아야 한다.
        import re as _re
        _mk = lambda t: _re.findall(r'\(([a-z])\)', t)
        ms, mo = _mk(s), _mk(o)
        # ★ 2026-10-26 — **차례는 안 따진다, 빠짐·겹침만 잰다.** 한국어·일본어는 어순이 달라 (b) 가 (c)(d) 뒤로 가는 것이
        #   옳은 번역일 때가 있다(실측 하이델베르크 21문 — (b) 가 「확실한 신뢰」 뒤에 제대로 붙었다). 글자 묶음이 같으면 통과.
        if len(ms) >= 2 and sorted(ms) != sorted(mo):
            ls.append('증거 구절 표시가 원문과 다릅니다 — 원문 (%s) · 옮긴 글 (%s)'
                      % (')('.join(ms)[:60], ')('.join(mo)[:60]))
        # ★ 2026-10-26 실측 — 자리를 못 찾은 글자를 끝에 몰아 붙여 개수만 맞췄다(「… 하십니다. (h) (i) (j)」).
        _pile = r'(\([a-z]\)\s*){3,}$'
        if len(ms) >= 2 and _re.search(_pile, o) and not _re.search(_pile, s):
            ls.append('증거 구절 표시를 끝에 몰아 붙였습니다 — 표시마다 원문과 같은 자리(그 말 바로 뒤)에 둡니다.')
        a, b = len(s), len(o)
        if a and not (0.4 <= b / float(a) <= 3.5):
            ls.append('(길이비 %.2f — 원본 %d자 · 옮긴 글 %d자. 사람이 봅니다)'
                      % (b / float(a), a, b))
        if _ORIG_RE.search(o) and not _ORIG_RE.search(s):
            ls.append('원본에 없는 히브리·헬라 글자를 새로 적었습니다 — 원어는 음독(한글)으로만 적습니다.')
    else:
        ls.append('(원본 글을 못 읽어 문단 수·길이비는 안 쟀습니다)')
    if re.search(r'(\r?\n[ \t]*){3,}', o):
        ls.append('빈 줄이 두 겹 넘게 이어집니다 — 문단 사이는 한 번만 띕니다.')
    # ★ 2026-10-26 실측 「살아 S이나 죽으나」 — 한글 낱말에 로마자 한 글자가 박혔다(원문 글자 잔존 20% 문턱 아래로 샌다).
    if lang == 'KO':
        # ★ 2026-10-30 「X자 모양의 십자가」(대문자 + 자 · 형)는 뺀다 — 실측 헛걸림(안드레)
        _st = re.findall(r'(?<![A-Za-z0-9])[A-Za-z](?=[가-힣])(?![자형])', o)
        if _st:
            ls.append('한글 낱말에 로마자 한 글자가 끼었습니다(%s) — 깨진 글자입니다.' % ' '.join(_st[:5]))
    # 원문 글자체계 잔존 — 글자체계가 다를 때만
    bs, ts = SCRIPT_OF.get(base), SCRIPT_OF.get(lang)
    if bs and ts and bs != ts:
        n_b = len(re.findall(SCRIPT_RE[bs], o))
        n_all = len(_ALL_LETTERS.findall(o))
        if n_all >= 40 and n_b / float(n_all) > SCRIPT_LEFT_AT:
            ls.append('옮기지 않았습니다 — %s 글자가 %.0f%% 남아 있습니다.'
                      % (base, 100.0 * n_b / n_all))
    if lang == 'AR':
        if re.search(r'[\u0660-\u0669]', o) and re.search(r'[0-9]', o):
            ls.append('아랍어 글에 아라비아 숫자(٠-٩)와 서양 숫자(0-9)가 섞였습니다 — 한 가지로 씁니다.')
    for line in o.split(chr(10))[:3]:
        if _MARKUP_HEAD.match(line):
            ls.append('머리에 서식 기호·「번역:」 머리말이 붙었습니다 — 본문만 냅니다(출력서식).')
            break
    if '```' in o:
        if not any('서식 기호' in x for x in ls):
            ls.append('코드 울타리(```)가 들어 있습니다 — 본문만 냅니다(출력서식).')
    return ls


def title_lines(conn, kind, slot_id, lang, text):
    """책 제목 용어집 검사(317차-5) — 정한 그 언어 제목이 있는데 소개문에 안 보이면 **알림**.

    ⚠ 편 본문(BOOK_UNIT·맛보기)은 제목을 안 적는 편이 많아 재지 않는다 — 소개문만.
    """
    if kind != 'BOOK_INTRO':
        return []
    try:
        t = AJ.book_title(conn, AJ.book_id_of(conn, kind, slot_id), lang)
    except Exception:                                     # noqa: BLE001
        t = ''
    if t and t not in (text or ''):
        return ['(정한 책 제목 「%s」이 글에 안 보입니다 — 다른 이름으로 옮겼는지 보세요)' % t]
    return []


# ★ 2026-10-27 (docs/1.txt 15) **뜻 검사 둘 — 기계로 잡히는 만큼만**(사라 「아브라함의 아들」 · 여리고 「여호수아 → 여호와」).
#   ① 이름 — 원문에 나온 용어 이름의 그 언어 표기가 옮긴 글에 한 번도 없으면 흠(대명사로만 옮겼어도 한 번은 이름이 나온다)
#   ② 관계 낱말(한국어만) — 옮긴 글의 「아들·딸·아내·남편·아버지·어머니·형제·자매」 에 맞는 영어 낱말이 원문에 없으면 흠
KIN_KO = (
    ('아들', r'\bsons?\b|\bchild|\bdescendant|\boffspring|\bboy'),
    ('딸', r'\bdaughters?\b|\bgirl'),
    ('아내', r'\bwi(fe|ves)\b|\bmarri|\bspouse|\bconsort'),
    ('남편', r'\bhusband|\bmarri|\bspouse'),
    ('아버지', r'\bfathers?\b|\bfather'),
    ('어머니', r'\bmothers?\b|\bmother'),
    ('형제', r'\bbrother|\bbrethren'),
    ('자매', r'\bsisters?\b'),
)


_BOOKS_EN = None


def trans_meaning(conn, src, out, base, lang):
    ls = []
    o = out or ''
    s = src or ''
    if not s or not o:
        return ls
    try:
        g = AJ.name_glossary(conn, s, base, lang, cap=80)
    except Exception:                                     # noqa: BLE001
        g = ''
    # ⚠ 성경 책 이름(Samuel · Isaiah · Romans …)은 참조라 옮긴 글에서 약명(삼상 · 사 · 롬)이 된다 — 빼고 본다
    global _BOOKS_EN
    if _BOOKS_EN is None:
        try:
            _BOOKS_EN = {(r[0] or '').strip() for r in conn.execute(
                "SELECT full_name FROM book_names WHERE lang_code='EN'")}
            _BOOKS_EN |= {x.split(' ', 1)[1] for x in _BOOKS_EN if x[:1].isdigit() and ' ' in x}
        except Exception:                                 # noqa: BLE001
            _BOOKS_EN = set()
    miss = []
    for pair in [x for x in g.split(' · ') if ' = ' in x]:
        a, b = pair.split(' = ', 1)
        if a in _BOOKS_EN or a.rstrip('s') in _BOOKS_EN:
            # 책 이름이면서 사람 이름(Joshua · Samuel)일 수 있다 — 숫자 앞(참조)으로만 나왔을 때만 뺀다
            import re as _re2
            _all = _re2.findall(r'(?<![A-Za-z])%s(?![A-Za-z])(\s*\d)?' % _re2.escape(a), s)
            if _all and all(_all):
                continue
        if b and b not in o:
            miss.append('%s(%s)' % (a, b))
    if miss:
        ls.append('이름이 옮긴 글에 없습니다 — %s' % ' · '.join(miss[:8]))
    if str(lang).upper() == 'KO' and str(base).upper() == 'EN':
        import re as _re
        low = s.lower()
        for ko, en in KIN_KO:
            # ★ 2026-10-31 받아들이다·맞아들이다·몰아내다·찾아내다 안의 글자는 관계 낱말이 아니다(빌립보서 시범 14건이 헛걸렸다)
            if _re.search(r'(?<![받맞끌들달알파몰찾깎쫓밀뽑드꺼])' + ko, o) and not _re.search(en, low):
                ls.append('원문에 없는 관계 낱말 「%s」 — 원문을 확인하세요.' % ko)
    return ls


def gate_item(conn, kind, slot_id, lang, text, variant=None, task='NEW',
              seen_heads=None, before=None, extra=None, structure=True,
              base=None):
    """받은 글을 **적재하기 전에** 잰다 — `{ok, lines}`.

    ★ 자산별 핵심(`_gate_core`) 위에 **번역 공통 게이트**(`trans_common`)를 겹친다.
      맛보기·소개문은 제 꼴 게이트가 문단 수를 이미 재므로 겹치지 않는다.
    """
    # ★ 317차-18 ⑦ — 자료집 글은 칸 번호 목록을 떼어 내고 잰다(본문 게이트가 그 줄을 문단으로 세지 않게)
    _tbl_lines = []
    if (AJ.ASSET.get(kind) or {}).get('store') == 'REF' and str(task).upper() in ('TRANS', 'EDIT'):
        try:
            import ref_doc as _RD
            text, _ans = _RD.split_cells(text)
            _b0 = (base or AJ.base_lang(kind, '', conn)).upper()
            _srcb = AJ._asset_text(conn, kind, slot_id, _b0 if str(task).upper() == 'TRANS' else lang) or ''
            _tbl_lines = _RD.cells_check(_srcb, text, _RD.get_tables(conn, 'SYS', slot_id, _b0), _ans,
                                         need_cells=(str(task).upper() == 'TRANS'))
        except Exception as e:                            # noqa: BLE001
            _tbl_lines = ['(표 검사를 못 돌렸습니다: %s)' % e]
    res = _gate_core(conn, kind, slot_id, lang, text, variant=variant, task=task,
                     seen_heads=seen_heads, before=before, extra=extra,
                     structure=structure, base=base)
    if _tbl_lines:
        res['lines'] = _tbl_lines + list(res.get('lines') or [])
        if [l for l in _tbl_lines if not _is_note(l)]:
            res['ok'] = False
    if str(task).upper() == 'TRANS':
        _ll = lang_lines(text, lang)
        if _ll:
            res['lines'] = _ll + list(res.get('lines') or [])
            res['ok'] = False
    if str(task).upper() == 'TRANS' and kind not in ('BOOK_TASTE', 'BOOK_INTRO'):
        try:
            _b = (base or AJ.base_lang(kind, '', conn)).upper()
            _pref = 'ORIGINAL' if str(lang).upper() == _b else 'MODERN_EN'
            _src = AJ._asset_text(conn, kind, slot_id, _b, variant_pref=_pref)
            ls = trans_common(_src, text, _b, lang) + trans_meaning(conn, _src, text, _b, lang)
        except Exception as e:                            # noqa: BLE001
            ls = ['(번역 공통 검사를 못 돌렸습니다: %s)' % e]
        if ls:
            old = [l for l in (res.get('lines') or [])
                   if '아직 기계 게이트가 없습니다' not in l]
            res['lines'] = ls + old
            real = [l for l in ls if not _is_note(l)]
            if real:
                res['ok'] = False
            elif res.get('ok') is None:
                res['ok'] = True
        if kind == 'COMMENTARY':
            try:
                _cr = comm_ref_lines(conn, slot_id, _src, text)
            except Exception as e:                        # noqa: BLE001
                _cr = ['(주석 장 번호 검사를 못 돌렸습니다: %s)' % e]
            if task == 'TRANS':
                _cr = _cr + comm_form_lines(_src, text, lang)
            if _cr:
                res['lines'] = _cr + [l for l in (res.get('lines') or []) if '걸린 것이 없습니다' not in l]
                if [l for l in _cr if not _is_note(l)]:
                    res['ok'] = False
        if ls or (res.get('ok') is False):
            pass
        elif not any(not _is_note(l) for l in (res.get('lines') or [])
                     if '아직 기계 게이트가 없습니다' not in l):
            # ★ 2026-10-25 (docs/1.txt 7) 번역 공통 검사가 **돌았고 걸린 것이 없다** — 그전에는 자산 핵심 게이트의
            #   「아직 기계 게이트가 없습니다」가 그대로 남아 주석 번역 923건이 게이트 없이 들어간 것처럼 보였다
            old = [l for l in (res.get('lines') or []) if '아직 기계 게이트가 없습니다' not in l]
            res['lines'] = old + ['번역 공통 검사(문단 수·빈 줄·원문 글자·원어 낱자·숫자·서식)에 걸린 것이 없습니다 — 뜻은 사람이 봅니다.']
            if res.get('ok') is None:
                res['ok'] = True
    return res


def comm_form_lines(src, out, lang):
    """★ 2026-10-31 주석 번역의 꼴 — BARNES 빌립보서 시범 실측: 문체가 묶음마다 갈렸고(합니다체 67 · 한다체 36) ·
    글 끝 참조 줄 `{a} "…" Ac 16:12` 이 4건에서 사라졌다. 문장 끝은 따옴표 밖만 센다(인용한 글의 말투는 저자 것)."""
    lines = []
    _mk = r'\{[a-z*]\}'
    a, b = len(re.findall(_mk, src or '')), len(re.findall(_mk, out or ''))
    if a != b:
        lines.append('참조 표시 {a} 가 원문 %d개 · 옮긴 글 %d개입니다 — 글 끝 참조 줄을 빼지 않습니다.' % (a, b))
    if (lang or '').upper() != 'EN':
        # ★ 2026-10-31 BARNES 마태복음 — 136/712 건에 See Barnes·Mr 6:14·{a} "And 가 영어로 남았다(옛 프롬프트 「그대로 남긴다」)
        _eng = re.findall(r'(?<![A-Za-z])See\s+[A-Z]\w*|(?<![A-Za-z])(?:[123] ?)?[A-Z][a-z]{0,3}\.? \d+:\d+|\{[a-z*]\} *"[A-Za-z]+', out or '')
        if _eng:
            lines.append('영어로 남은 참조 %d곳(예: %s) — 참조도 옮깁니다.' % (len(_eng), _eng[0]))
    if (lang or '').upper() != 'EN' and re.match(r'\s*Verses?\s+\d', out or ''):
        lines.append('글 머리의 「Verse N」을 옮기지 않았습니다.')
    if (lang or '').upper() == 'KO':
        bare = re.sub(r'"[^"\n]*"|“[^”\n]*”|「[^」\n]*」', '', out or '')
        polite = len(re.findall(r'(?:니다|니까)[.?!]', bare))
        plain = len(re.findall(r'(?<!니)다[.?!]', bare))
        if plain >= 2 and plain > polite * 0.3:
            lines.append('문체 — 한다체 문장 %d · 합니다체 문장 %d 입니다(합니다체로 씁니다).' % (plain, polite))
    return lines


def comm_ref_lines(conn, entry_id, src, out):
    """★ 2026-10-25 (docs/1.txt 7) 주석 번역 — 원문 「(ver. N)」이 옮긴 글에서 **같은 책 다른 장**의 참조로 바뀌었나.
    잣대: 원문에 장 없는 절 표기(ver./v./verse N)가 있고 · 옮긴 글의 참조가 그 주석의 책이면서 장이 다르고 ·
    그 장:절이 원문에 그대로 적혀 있지 않을 때(원문이 진짜로 다른 장을 인용한 것은 걸지 않는다)."""
    import re as _re
    r = conn.execute('SELECT start_vid, chapter FROM sys_commentary_entry WHERE entry_id=?', (entry_id,)).fetchone()
    if not r or not r[0] or not _re.search(r'(?<![A-Za-z])(?:ver|vers|v|verse)\.?\s*\d+', src or '', _re.I):
        return []
    try:
        head = AJ._ref(conn, r[0]).rsplit(' ', 1)[0]      # 「시」
    except Exception:                                     # noqa: BLE001
        return []
    bad = []
    for m in _re.finditer(r'(?<![가-힣A-Za-z])%s\s*(\d+):(\d+)' % _re.escape(head), out or ''):
        ch, vs = int(m.group(1)), m.group(2)
        # ⚠ **1장으로 바뀐 것만** — 실측 실수는 언제나 「(ver. N)」→「1:N」이었다. 다른 장 인용은 원문이
        #   로마 숫자(「Ps. xvi. 10」)로 적어 글자 대조가 안 되므로 걸면 헛걸림이 난다(매클라렌 실측)
        if ch == 1 and r[1] != 1 and not _re.search(r'(?<!\d)1\s*[:.]\s*%s(?!\d)' % vs, src or ''):
            bad.append(m.group(0))
    if not bad:
        return []
    return ['장 번호가 다릅니다 — 이 글은 %s %d장 주석인데 「%s」(원문은 (ver. N) = 이 장의 N절)'
            % (head, r[1], ' · '.join(dict.fromkeys(bad))[:120])]


#: ★★★ 295차 — 절 자산이 아닌 **우리 글** 일곱. `gates_for` 와 `_gate_core` 가
#:   같은 목록을 본다(두 곳에 적으면 갈린다).
OURS_KINDS = ('VERS_VERS_DESC', 'PERI_DESC', 'PERI_TITLE', 'CHAP_DESC',
              'BOOK_DESC', 'ENTITY_DESC', 'ENTITY_NAME')
#: 한 줄로 끝나는 것(제목·이름) — 합니다체·문단 잣대를 안 댄다
OURS_ONELINE = ('PERI_TITLE', 'ENTITY_NAME')
#: 한국어 분량(글자) — 실측·문서 잣대. 단락·장은 `db_peri_gate` 가 책 갈래로 정한다.
#:   구절연결 설명문 = §28-6 「1~3문장 · 중요한 구절은 더 길게」 · 적재분 중앙 228자.
#:   용어 설명문 = `db_term_desc.MIN_KO/MAX_KO` · 책 개요 = 장 설명문과 같은 폭.
OURS_LEN_KO = {'VERS_VERS_DESC': (60, 400), 'BOOK_DESC': (300, 1200),
               'PERI_TITLE': (2, 18), 'ENTITY_NAME': (2, 26)}
_ORIG_SCRIPT = re.compile(r'[\u0590-\u05FF\u0370-\u03FF\u1F00-\u1FFF]')
_CIRCLED = re.compile(r'[①-⑳]')
_SENT_END = re.compile(r'(다|요|까|네|자|라)[.!?]?\s*$')


def _ours_ref(conn, kind, slot_id):
    """단락·장 게이트가 책 갈래를 알게 — `db_peri_gate` 가 읽는 ref 꼴 'bcode ch:v'."""
    try:
        if kind == 'CHAP_DESC':
            return '%d %d:1' % (int(slot_id) // 1000, int(slot_id) % 1000)
        if kind == 'PERI_DESC' or kind == 'PERI_TITLE':
            r = conn.execute("SELECT b.bcode, b.chapter, b.verse FROM sys_pericope_asset p"
                             " JOIN bible_index b ON b.verse_id=p.start_vid"
                             " WHERE p.pericope_id=?", (slot_id,)).fetchone()
            if r:
                return '%d %d:%d' % (int(r[0]), int(r[1]), int(r[2]))
    except Exception:                                     # noqa: BLE001
        pass
    return ''


def ours_lines(conn, kind, slot_id, lang, text):
    """우리 글(절 자산 아닌 일곱)의 **꼴** — 흠 줄 목록(참고는 `(` 로 시작).

    잣대는 새로 짓지 않았다 — 대시 금지(§28-6) · 합니다체(§28-11 ⑤) · 동그라미 번호
    금지(§28-11 ③) · 원어 글자 노출 금지(§28-11 ⑥) · 교단 귀속어(`db_peri_gate.SECT`)
    · 분량(`OURS_LEN_KO` / 단락·장은 `db_peri_gate` 의 책 갈래별 값 / 용어는
    `db_term_desc`) · 한 줄 꼴(제목·이름).
    ⚠ 「억지 비유」는 기계로 못 잰다 — 프롬프트(`never`)가 막고 사람이 본다.
    """
    t = (text or '').strip()
    lg = (lang or 'KO').upper()
    out = []
    if not t:
        return ['글이 비었습니다.']
    if '—' in t or '–' in t:
        out.append('대시(—)가 %d개 — 문장으로 풀어 적습니다(§28-6).' % (t.count('—') + t.count('–')))
    if _CIRCLED.search(t):
        out.append('동그라미 번호(①②)가 있습니다 — 열거는 문장으로(§28-11 ③).')
    if _ORIG_SCRIPT.search(t) and kind != 'ENTITY_NAME':
        out.append('히브리·헬라 글자가 그대로 적혔습니다 — 원어는 한글 음독으로만(§28-11 ⑥).')
    try:
        import db_peri_gate as PG
        m = PG.SECT.search(t)
        if m:
            out.append('교단 귀속어: 「%s」 — 여러 교단이 함께 쓰는 앱입니다(§28-11).' % m.group(0))
    except Exception:                                     # noqa: BLE001
        PG = None
    lines = [l for l in t.splitlines() if l.strip()]
    if kind in OURS_ONELINE:
        if len(lines) != 1:
            out.append('%d줄입니다 — 한 줄만 냅니다(%s).' % (len(lines), AJ.ASSET[kind]['name']))
        one = lines[0].strip() if lines else ''
        if any(q in one for q in ('"', '「', '」', '“', '”', "'")):
            out.append('따옴표·기호가 붙었습니다 — 글자만 냅니다.')
        if lg == 'KO' and _SENT_END.search(one) and kind == 'PERI_TITLE':
            out.append('문장 꼴로 끝납니다(「…다」) — 제목은 명사형으로(개역한글 소제목 어투).')
        if kind == 'ENTITY_NAME' and lg == 'KO' and re.search(r'(니다|이다|한다)\.?$', one):
            out.append('이름이 문장 꼴입니다 — 「인애 · 헤세드」처럼 이름만.')
        lo, hi = OURS_LEN_KO.get(kind, (1, 40))
        if lg == 'KO' and not (lo <= len(one) <= hi):
            out.append('길이 %d자 — %d~%d자 안이라야 합니다.' % (len(one), lo, hi))
        return out
    # ── 산문 셋·용어 설명문 ────────────────────────────────────────
    if lg == 'KO':
        if not re.search(r'(니다|니까)', t):
            out.append('합니다체가 아닙니다 — 어미는 「…합니다/…합니까」(§28-11 ⑤).')
        if PG is not None:
            hits = PG.PLAIN_ENDING.findall(t)
            if len(hits) >= 2:
                out.append('평서체 종결 %d회(「…다.」) — 경어체로(peri.md §2-11).' % len(hits))
    if kind in ('PERI_DESC', 'CHAP_DESC') and PG is not None:
        # ★ 단락·장은 그 게이트가 이미 잣대를 다 갖고 있다 — 빌려 쓴다(두 벌 금지).
        ref = _ours_ref(conn, kind, slot_id) or '1 1:1'
        try:
            PG.LAST_WARNS.clear()
            bad = PG.check(conn, [(slot_id, ref, '', '', lg if lg in ('KO', 'EN') else 'KO',
                                   None, t)], kind=('CHAP' if kind == 'CHAP_DESC' else 'PERI'))
            for _tag, msg in bad:
                out.append(msg)
        except Exception as e:                            # noqa: BLE001
            out.append('(단락·장 문체 검사가 터졌습니다: %s)' % e)
    elif kind == 'ENTITY_DESC':
        try:
            import db_term_desc as TD
            paras = [p for p in t.split(chr(10)) if p.strip()]
            if lg == 'KO' and not (TD.MIN_PARA <= len(paras) <= TD.MAX_PARA):
                out.append('문단 %d개 — %d~%d개(db_term_desc).' % (len(paras), TD.MIN_PARA, TD.MAX_PARA))
            if lg == 'KO' and not (TD.MIN_KO <= len(t) <= TD.MAX_KO):
                out.append('%d자 — %d~%d자(db_term_desc).' % (len(t), TD.MIN_KO, TD.MAX_KO))
            nm = conn.execute("SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
                              " AND clicked_id=? AND lang_code=? AND record_status='LIVE'"
                              " LIMIT 1", (slot_id, lg)).fetchone()
            head = ((nm and nm[0]) or '').split('·')[0].strip()
            if head and head not in t:
                out.append('글이 이름 「%s」 를 한 번도 안 부릅니다.' % head)
            # 인용한 절이 실재하는가 — 기억으로 적지 않는다
            bm = TD._book_map(conn)
            for bk, ch, vn in TD._REF.findall(t):
                bc = bm.get(bk)
                if bc is None:
                    continue
                okv = conn.execute("SELECT 1 FROM bible_index WHERE bcode=? AND chapter=?"
                                   " AND verse=?", (bc, int(ch), int(vn))).fetchone()
                if not okv:
                    out.append('없는 절을 인용했습니다: %s %s:%s' % (bk, ch, vn))
        except Exception as e:                            # noqa: BLE001
            out.append('(용어 설명문 검사가 터졌습니다: %s)' % e)
    else:
        lo, hi = OURS_LEN_KO.get(kind, (60, 2000))
        if lg == 'KO' and not (lo <= len(t) <= hi):
            out.append('%d자 — %d~%d자 안이라야 합니다.' % (len(t), lo, hi))
        if kind == 'VERS_VERS_DESC':
            if len(lines) > 1:
                out.append('%d줄 — 연결 설명문은 한 문단(개행 없음 · §28-6).' % len(lines))
            if lg == 'KO' and re.search(r'\[(PRG|DEP|INC|REV|TYP|FUL|ALL|PAR|REF|SUP|SYN|COV)\]', t):
                out.append('관점 접두([PRG]…)가 붙었습니다 — 문장으로 녹입니다(§28-6).')
            if lg == 'KO':
                out += vvd_lines(conn, slot_id, t)
    return out


def _review_targets(conn, slot_id):
    """점검할 지금 연결 — `{(상대 절, 갈래): link_id}`."""
    return {(o, rel): lid for lid, o, rel, _s in AJ.review_links(conn, slot_id)}


def link_review_lines(conn, slot_id, text):
    """연결 점검 게이트(317차-5) — 줄 꼴 · 지금 이어진 구절인가 · 판정 · 바꿀 갈래 · 빠짐."""
    ls = []
    items = AJ.link_review_parse(conn, text)
    if not items:
        return ['판정 줄이 하나도 없습니다.']
    have = _review_targets(conn, slot_id)
    bad = [it[5] for it in items if not it[3]]
    if bad:
        ls.append('못 읽은 줄 %d개 — 「약명 · 갈래 · 유지/해제/바꿈:코드 · 까닭」 꼴이 아닙니다: %s'
                  % (len(bad), ' / '.join(x[:30] for x in bad[:3])))
    good = [it for it in items if it[3]]
    stray = [it[0] for it in good if (it[1], it[2]) not in have]
    if stray:
        ls.append('지금 이어진 연결이 아닌 줄 %d개(없는 연결은 판정할 수 없다): %s'
                  % (len(stray), ' / '.join(stray[:4])))
    badrel = [it[0] for it in good if it[3] == '바꿈' and (it[4] not in AJ.REL_CODE_SET or it[4] == it[2])]
    if badrel:
        ls.append('바꿈인데 새 갈래가 열두 갈래 밖이거나 지금과 같다 %d개: %s'
                  % (len(badrel), ' / '.join(badrel[:4])))
    seen = {(it[1], it[2]) for it in good}
    miss = [k for k in have if k not in seen]
    if miss:
        ls.append('(판정이 빠진 연결 %d개 — 그 연결은 그대로 둡니다)' % len(miss))
    n = {v: sum(1 for it in good if it[3] == v) for v in AJ.LINK_VERDICTS}
    ls.append('(유지 %d · 해제 %d · 바꿈 %d)' % (n['유지'], n['해제'], n['바꿈']))
    return ls


LINK_HUB_AT = 6            # 상대 절에 AI 연결이 이만큼 몰려 있으면 알린다


def link_kind_notes(conn, slot_id, good):
    """갈래 판정 **알림**(2026-10-11) — 막지 않고 사람에게 보인다.

    ★ 잣대를 사람 연결로 재고 정했다 — 사람도 구약 안의 성취(FUL 8%)·신약 절 없는
      그리스도 성취(INC 10%)·낱말이 안 겹치는 인용(REF 28%)을 쓴다. 그래서 **흠이 아니라
      알림**이고, 낱말 겹침은 아예 안 잰다(사람과 AI 가 같은 비율이라 가르지 못한다).
    ★ 가르는 것은 갈래 **치우침**이다 — 실측 AI 의 SYN 34% ↔ 사람 1%.
    """
    ls = []
    try:
        my = conn.execute("SELECT bcode FROM bible_index WHERE verse_id=?", (slot_id,)).fetchone()
        my = my[0] if my else None
    except Exception:                                     # noqa: BLE001
        my = None
    ful, inc, hub = [], [], []
    for ref, tv, rel, _why, _raw in good:
        if tv is None or my is None:
            continue
        r2 = conn.execute("SELECT bcode FROM bible_index WHERE verse_id=?", (tv,)).fetchone()
        if not r2:
            continue
        cross = (my < 40) != (r2[0] < 40)
        if rel == 'FUL' and not cross:
            ful.append(ref)
        if rel == 'INC' and max(my, r2[0]) < 40:
            inc.append(ref)
        n = conn.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type='VERS_VERS'"
                         " AND record_status='LIVE' AND source LIKE 'AILINK:%' AND (clicked_id=? OR target_id=?)",
                         (tv, tv)).fetchone()[0]
        if n >= LINK_HUB_AT:
            hub.append('%s(%d)' % (ref, n))
    if ful:
        ls.append('(성취 FUL 인데 신·구약을 안 건넙니다 %d개 — 그 안의 예언 성취인지 보세요: %s)'
                  % (len(ful), ' / '.join(ful[:4])))
    if inc:
        ls.append('(그리스도 성취 INC 인데 신약 절이 없습니다 %d개 — 예표(TYP)·암시(ALL)가 아닌지 보세요: %s)'
                  % (len(inc), ' / '.join(inc[:4])))
    rels = [it[2] for it in good if it[1] is not None]
    if len(rels) >= 3 and rels.count('SYN') * 2 > len(rels):
        ls.append('(유사 SYN 이 %d/%d 줄 — 더 구체적인 갈래(REF·ALL·PAR·TYP)가 아닌지 보세요)'
                  % (rels.count('SYN'), len(rels)))
    if hub:
        ls.append('(AI 연결이 이미 몰린 절: %s — 쏠림)' % ' / '.join(hub[:4]))
    return ls


def link_lines(conn, slot_id, text):
    """구절 연결기 게이트 — 꼴 · 절 표기 · 갈래 · 같은 장 · 이미 이어짐(297차).

    ⚠ 「이미 이어짐」은 **알림**이다 — 사람이 이은 짝을 AI 가 또 내면 그것은
      「사람 목록과 맞았다」는 뜻이기도 하다(296차 시험의 겹침). 담을 때 UNIQUE 가 걸러
      준다. 나머지 넷은 필수다.
    """
    ls = []
    items = AJ.link_lines_parse(conn, text)
    if not items:
        return ['연결 줄이 하나도 없습니다.']
    bad_form = [it[4] for it in items if not it[0]]
    if bad_form:
        ls.append('못 읽은 줄 %d개 — 「약명 장:절 · 갈래 · 왜」 꼴이 아닙니다: %s'
                  % (len(bad_form), ' / '.join(x[:30] for x in bad_form[:3])))
    good = [it for it in items if it[0]]
    if len(good) > AJ.LINK_MAX:
        ls.append('연결이 %d줄 — %d줄까지입니다.' % (len(good), AJ.LINK_MAX))
    if good and len(good) < 3:
        ls.append('(연결이 %d줄 — 3줄은 되는 것이 보통입니다)' % len(good))
    bad_ref = [it[0] for it in good if it[1] is None]
    if bad_ref:
        ls.append('우리 좌표로 못 푼 절 표기 %d개: %s' % (len(bad_ref), ' / '.join(bad_ref[:4])))
    bad_rel = [it[2] for it in good if it[2] not in AJ.REL_CODE_SET]
    if bad_rel:
        ls.append('열두 갈래 밖 코드 %d개: %s' % (len(bad_rel), ' / '.join(sorted(set(bad_rel))[:4])))
    try:
        me = conn.execute("SELECT bcode, chapter FROM bible_index WHERE verse_id=?", (slot_id,)).fetchone()
    except Exception:                                     # noqa: BLE001
        me = None
    near, dup, seen = [], [], set()
    have = set()
    try:
        for a, b in conn.execute(
                "SELECT clicked_id, target_id FROM sys_link_asset WHERE link_type='VERS_VERS'"
                "  AND record_status='LIVE' AND (clicked_id=? OR target_id=?)", (slot_id, slot_id)):
            have.add(b if a == slot_id else a)
    except Exception:                                     # noqa: BLE001
        pass
    for ref, tv, rel, why, _raw in good:
        if tv is None:
            continue
        if tv == slot_id:
            near.append(ref)
            continue
        if me:
            r2 = conn.execute("SELECT bcode, chapter FROM bible_index WHERE verse_id=?", (tv,)).fetchone()
            if r2 and tuple(r2) == tuple(me):
                near.append(ref)
        if tv in seen:
            ls.append('같은 절을 두 번 냈습니다: %s' % ref)
        seen.add(tv)
        if tv in have:
            dup.append(ref)
        if len((why or '').strip()) < 12:
            ls.append('「왜 잇는가」가 너무 짧습니다(%s): %s' % (ref, why))
    if near:
        ls.append('같은 장 안의 절로 이었습니다(금지) %d개: %s' % (len(near), ' / '.join(near[:4])))
    ls += link_kind_notes(conn, slot_id, good)
    if dup:
        ls.append('(이미 이어진 절 %d개 — 담을 때 겹치면 건너뜁니다: %s)' % (len(dup), ' / '.join(dup[:4])))
    return ls


def _gate_core(conn, kind, slot_id, lang, text, variant=None, task='NEW',
               seen_heads=None, before=None, extra=None, structure=True,
               base=None):
    """자산별 핵심 게이트 — `{ok, lines}`.

    ★ 배포 DB 를 안 건드린다 — `db_vers_gate` 의 초안 겹치기로만 잰다(§277차 ①).
    ⚠ 절별자산이 아니면 아직 잴 게이트가 없다 — **「없다」고 말하고 통과시킨다**
      (없는 검사를 통과라 적으면 §18-9 의 실패를 되풀이한다).
    """
    a = AJ.ASSET.get(kind) or {}
    # ★★★ **연구자료는 서식 게이트로 잰다** — 번역·다듬기 경로(`REF_UNIT`)도
    #   묶음 칸과 같은 꼴을 지켜야 한다. 안 그러면 한 자료집 안에서 원본과
    #   번역문의 서식이 갈린다.
    #   ⚠ 갈래를 나눈 뒤로는 **자산 열쇠가 그것을 말한다**
    #     (`REF_STUDY`). 옛 한 자산(`REF_UNIT`)만 유닛까지 뒤진다.
    if kind == 'REF_STUDY' or (kind == 'REF_UNIT'
                               and _is_study_unit(conn, slot_id)):
        try:
            import db_study_gate as SG
            ls = SG.check(text, lang=lang)
        except Exception as e:                            # noqa: BLE001
            ls = ['서식 검사가 터졌습니다: %s' % e]
        if str(task).upper() == 'EDIT' and before:
            ls += edit_loss(before, text, conn) + name_clash(text)
        ls += _cite_lines(conn, text, lang)
        real = [l for l in ls if not _is_note(l)]
        return {'ok': not real,
                'lines': ls or ['서식은 규칙대로입니다 — 글 자체는 사람이 봅니다.']}
    if a.get('store') == 'LINK':
        ls = (link_review_lines(conn, slot_id, text) if AJ.is_link_review(kind, task)
              else link_lines(conn, slot_id, text))
        real = [l for l in ls if not _is_note(l)]
        return {'ok': not real, 'lines': ls}
    if kind == 'BOOK_TASTE':
        # ★★★ **조각은 「같은 모양인가」로 잰다** — 문단 수·길이비·표식.
        #   ⚠ 표식(⟨맛보기 여기까지⟩)은 **도구가 붙인다** — 옮긴 글에 적혀
        #     있으면 두 번 붙거나 자리가 어긋난다.
        ls = []
        try:
            import db_pack_taste as _T
            # ★★★ **그 작업의 기준 언어로 잰다**(2026-09-25 실측) —
            #   EN 으로 못 박으면 원문이 FR·LA 인 책(벨직·도르트)은
            #   **옮긴 적 없는 글과 견주어** 영영 흠이 난다.
            src = _T.taste_text(conn, slot_id,
                                base or AJ.base_lang(kind, '', conn))
            ls += taste_lines(src, text, lang)
            import db_cite_gate as CG
            ls += CG.check_against(conn, src, text, lang,
                                   AJ.base_lang(kind, '', conn))
        except Exception as e:                            # noqa: BLE001
            ls.append('맛보기 조각 검사가 터졌습니다: %s' % e)
        if str(task).upper() == 'EDIT' and before:
            ls += edit_loss(before, text, conn) + name_clash(text)
        real = [l for l in ls if not _is_note(l)]
        return {'ok': not real,
                'lines': ls or ['꼴은 원본과 같습니다 — 글 자체는 사람이 봅니다.']}
    if kind == 'BOOK_INTRO':
        # ★★★ **소개문은 꼴이 있다** — 문단 둘셋 + 「▸ 출처」 블록.
        #   잘 옮겼나는 사람이 보고 **같은 모양인가는 기계가 잰다**.
        #   ⚠⚠ 출처의 기관 이름·판본 연도가 바뀌면 그 순간 저작권
        #     고지가 다른 자료를 가리킨다 — 그것을 여기서 막는다.
        ls = []
        try:
            import db_book_desc as BD
            src = AJ._asset_text(conn, kind, slot_id,
                                 AJ.base_lang(kind, '', conn))
            if str(task).upper() == 'NEW':
                # ★★★ **신규는 견줄 원본이 없다** — `check_text` 로 재면
                #   「문단 3개 · 원본은 0개」라 무조건 흠이 난다. 물음이
                #   다르다: 서식대로 썼고 **출처를 안 건드렸나**.
                blk = (AJ.material(conn, kind, slot_id, 'NEW', lang=lang)
                       .get('그대로 붙일 출처 블록') or '')
                ls += BD.check_new(text, blk, lang)
            else:
                ls += BD.check_text(src, text, lang)
            ls += title_lines(conn, kind, slot_id, lang, text)
            # ★★★ **원본이 인용한 절은 그 언어 역본 글자 그대로**
            #   (2026-09-25 표본에서 실제로 걸렸다 — 예레미야 8:20 을
            #   러시아어로 **다시 번역**해 버렸다). 닻을 옮긴 글이 아니라
            #   **원본**에 두어야 어느 언어로 옮겨도 잰다.
            import db_cite_gate as CG
            ls += CG.check_against(conn, src, text, lang,
                                   AJ.base_lang(kind, '', conn))
        except Exception as e:                            # noqa: BLE001
            ls.append('소개문 검사가 터졌습니다: %s' % e)
        if str(task).upper() == 'EDIT' and before:
            ls += edit_loss(before, text, conn) + name_clash(text)
        real = [l for l in ls if not _is_note(l)]
        return {'ok': not real,
                'lines': ls or [
                    '서식은 규칙대로이고 출처를 안 건드렸습니다 — 글 자체는'
                    ' 사람이 봅니다.' if str(task).upper() == 'NEW' else
                    '꼴은 원본과 같습니다 — 글 자체는 사람이 봅니다.']}
    if kind == 'BOOK_UNIT':
        # ★★★ **출처 줄은 적재할 때 붙는다 — 그 사실을 여기서 말한다**
        #   (2026-09-24 사용자 「맨 아랫줄에 책이름 한줄이 기록되지 않았다.
        #   보다 체계적인 대책을 세워라 · 별도의 자동입력줄을 네가 입력해
        #   두었다가 승인/적재할 때 추가하는 방식도 좋다」).
        #   ★ 사용자가 말한 그 방식이 **이미 지금 방식**이다 — `_load_book` 이
        #     `db_book_attrib` 의 한 꼴로 갈아 끼운다(16-2 ⓐ). 없던 것은
        #     **검수 자리에서 그것을 보여 주는 일**뿐이었다.
        #   ⚠⚠⚠ **출처를 못 대는 유닛은 여기서 흠으로 잡는다** — 그전에는
        #     적재 때 조용히 건너뛰어(`skip`) 검수 화면에서 알 길이 0 이었다.
        #     「승인했는데 안 담긴 건」이 그렇게 생긴다.
        ls = []
        if str(task).upper() == 'EDIT' and before:
            ls += edit_loss(before, text, conn) + name_clash(text)
        try:
            import db_book_attrib as BA
            line = BA.book_attrib_for(
                conn, slot_id, AJ.book_variant_for(lang, base or 'EN'),
                (lang or '').upper())
        except Exception as e:                            # noqa: BLE001
            line = None
            ls.append('출처 줄을 못 만들었습니다: %s' % e)
        if line is None:
            ls.append('이 유닛의 책을 못 찾아 **적재할 때 건너뜁니다** — '
                      '출처를 못 대는 글은 담지 않습니다.')
        else:
            mine = BA.strip_attrib(text or '')
            if mine.rstrip() != (text or '').rstrip():
                ls.append('(AI 가 제 손으로 붙인 출처 줄은 떼고 아래 한 꼴로 '
                          '갈아 끼웁니다)')
            ls.append('(적재할 때 맨 아래에 이 줄이 붙습니다: %s)' % line)
        # ★★★ **성경 인용을 개역한글과 실제로 대조한다**(2026-09-25
        #   사용자 「성경구절도 번역해버린 것 같다 · 대조 게이트 만들어라」).
        #   프로필에 「개역한글을 인용한다」가 적혀 있었는데도 실측 인용
        #   112곳 중 **53곳이 안 맞았다** — 프롬프트만으로는 샌다.
        ls += _cite_lines(conn, text, lang)
        real = [l for l in ls if not _is_note(l)]
        return {'ok': not real,
                'lines': ls or ['이 자산에는 아직 기계 게이트가 없습니다 — '
                                '사람이 봅니다.']}
    if kind in OURS_KINDS:
        # ★★★ 295차 — **우리 글인데 절 자산이 아닌 일곱**(구절연결 설명문 · 단락
        #   설명문·제목 · 장 설명문 · 책 개요 · 용어 설명문·이름). 그전에는 신규
        #   작성에 게이트가 0 이었다(실측 — 구절연결 설명문 반려 3건은 억지 비유와
        #   「오네시보로」 사실 오류였다). 기계가 잴 수 있는 꼴만 잰다.
        ls = ours_lines(conn, kind, slot_id, lang, text)
        if str(task).upper() == 'EDIT' and before:
            ls += edit_loss(before, text, conn)
        ls += name_clash(text)
        real = [l for l in ls if not _is_note(l)]
        return {'ok': not real,
                'lines': ls or ['꼴은 규칙대로입니다 — 글 자체는 사람이 봅니다.']}
    if a.get('slot') != 'VERSE':
        # ★★★ **다듬기 손실 검사는 자산과 무관하다** — 앞글과 뒷글만 있으면
        #   잰다. 옛 판은 절 자산이 아니면 **아무 검사도 안 돌았고**, 그 사이
        #   도서 다듬기가 재료의 「편 제목」을 본문에 붙였다(실측).
        if str(task).upper() == 'EDIT' and before:
            ls = edit_loss(before, text, conn) + name_clash(text)
            return {'ok': not ls,
                    'lines': ls or ['다듬으며 잃거나 보탠 것이 없습니다 — '
                                    '글 자체는 사람이 봅니다.']}
        return {'ok': None, 'lines': ['이 자산에는 아직 기계 게이트가 없습니다 — '
                                      '사람이 봅니다.']}
    tt = a.get('text_type')
    var = variant if variant is not None else a.get('variant')
    r = conn.execute("SELECT bcode, chapter FROM bible_index WHERE verse_id=?",
                     (slot_id,)).fetchone()
    if not r:
        return {'ok': False, 'lines': ['그런 절이 없습니다: %s' % slot_id]}
    bc, ch = int(r[0]), int(r[1])
    out = []
    try:
        import db_vers_gate as G
        # ★ `extra` = **함께 올릴 초안**(묶음의 다른 칸). 안 올리면 같은
        #   절의 나머지 자산이 「없다」로 잡혀 거짓 흠이 난다.
        with G.draft([(slot_id, tt, lang, var, text)] + list(extra or [])):
            ok = True
            # ★★★ **업무마다 잴 것이 다르다** — 실측으로 알았다.
            #   `check_structure` 는 **KO·EN 쌍과 내용 보존**을 본다. 그것을
            #   번역문(KO→JA)에 대면 글자가 안 겹쳐 「내용보존 0.10」이 뜨고,
            #   아직 안 쓴 EN 을 「없다」고 잡는다 — **둘 다 번역의 흠이 아니다**.
            #   ⚠ 느슨하게 한 것이 아니다: 다듬기·신규에는 그대로 건다.
            fns = [G.check_dash, G.check_yoche, G.check_selfquote]
            # ⚠ `structure=False` = **다른 칸이 이미 쟀다**(묶음). 구조 검사는
            #   그 절의 자산을 통째로 보므로 칸마다 돌리면 **같은 흠을 네 번**
            #   적고 진짜 흠이 묻힌다.
            if str(task).upper() != 'TRANS' and structure:
                fns.insert(0, G.check_structure)
            for fn in fns:
                try:
                    v = fn(bc, ch, ch, out)
                except Exception as e:                    # noqa: BLE001
                    out.append('  검사가 터졌다(%s): %s' % (fn.__name__, e))
                    v = False
                if v is False:
                    ok = False
    except Exception as e:                                # noqa: BLE001
        return {'ok': False, 'lines': ['게이트를 못 돌렸습니다: %s' % e]}
    # ⚠⚠⚠ **남의 흠을 내 흠으로 보이지 않는다** — 게이트는 그 장 전체를
    #   재므로 같은 절의 **다른 언어·티어 자산**(이미 DB 에 있던 글)의 흠까지
    #   함께 낸다. 실측 — 일본어 번역을 넣었는데 「EN.EXPERT … — …」(옛 영어
    #   전문 설명의 대시)로 걸렸다. 그것으로 검수자를 부르면 헛일이다.
    #   ⇒ **내 초안의 언어·티어 태그가 붙은 줄**만 남기고, 태그가 아예 없는
    #     줄(구조 검사 등)은 보수적으로 내 것으로 본다. 판정도 그 줄로 한다.
    vs = int(conn.execute("SELECT verse FROM bible_index WHERE verse_id=?",
                          (slot_id,)).fetchone()[0])
    tag = '%s.%s' % (str(lang).upper(), str(var or '').upper())
    here = [l for l in out if (':%d ' % vs) in l or (':%d	' % vs) in l] or out
    mine, others, notes = [], 0, []
    for l in here:
        m = re.search(r'\b([A-Z]{2,4})\.(LAY|EXPERT)\b', l)
        if m and ('%s.%s' % (m.group(1), m.group(2))) != tag:
            others += 1
            continue
        # ⚠⚠ 「VERS_DESC 없음(EN·KO)」·「VERS_QUESTION 한쪽만(KO)」처럼
        #   **짝 언어 이야기**는 이 글의 흠이 아니다 — 한 언어씩 쓰는 동안
        #   늘 뜬다. ⚠ 옛 정규식은 언어를 **하나만** 읽어 「없음(EN·KO)」를
        #   못 걸렀다(묶음 게이트를 제 잣대로 고치자 드러났다).
        #   ★ 내 언어가 그 목록에 **들어 있으면** 진짜 흠이다(내 글이 비었다).
        # ⚠⚠⚠ **한 줄에 흠이 여럿 이어 적힌다** — 「A 한쪽만(KO) · B 없음(EN)
        #   · 문단없음」. 줄째로 거르면 **진짜 흠까지 함께 사라진다**(실측으로
        #   당했다 — 레 14:52 의 「문단없음」이 그렇게 묻힐 뻔했다).
        #   ⇒ `·` 로 쪼개 **조각마다** 판정하고 살아남은 것만 잇는다.
        if '없음(' in l or '한쪽만(' in l:
            keep = []
            for seg in [x.strip() for x in l.split('·')]:
                m2 = re.search(r'(없음|한쪽만)\(([A-Z·,\s]+)\)', seg)
                if not m2:
                    keep.append(seg)
                    continue
                langs = set(re.findall(r'[A-Z]{2,4}', m2.group(2)))
                here = str(lang).upper() in langs
                # 「없음(…)」 = **빠진** 언어 · 「한쪽만(…)」 = **있는** 언어.
                # ⚠ 뜻이 반대다 — 한 잣대로 묶으면 멀쩡한 글을 신고한다.
                if (here if m2.group(1) == '없음' else (not here)):
                    keep.append(seg)          # 내 글이 없다 — 진짜 흠
                else:
                    others += 1
            # 줄 머리(「14:52」)만 남았으면 그것도 알림이다
            keep = [x for x in keep if x and not re.match(r'^\d+:\d+$', x)]
            if not keep:
                continue
            l = ' · '.join(keep)
        # ⚠⚠ **요약 줄은 흠이 아니다** — 「… 위반 0건」. 진짜 흠이 없으면
        #   `here` 가 비어 `or out` 으로 요약 전체가 들어오는데, 태그가 없어
        #   「내 것」으로 분류되어 **흠이 없을수록 걸린다**(실측으로 당했다).
        if _is_sum(l):
            notes.append(l)
            continue
        mine.append(l)
    # ★ 첫머리 겹침 — 번역에는 안 건다(원문의 첫머리를 따르는 것이 옳다)
    if str(task).upper() != 'TRANS':
        mine += head_clash(conn, kind, slot_id, lang, text, seen_heads)
    mine += name_clash(text)      # ★ 번역에도 건다 — 표기는 언제나 같아야 한다
    if str(task).upper() == 'TRANS':
        _r, _bad = not_translated(text, lang)
        if _bad:
            mine.append('  옮기지 않았습니다 — 한글이 %.0f%% 남아 있습니다'
                        % (_r * 100))
    if str(task).upper() == 'EDIT':
        mine += edit_loss(before, text, conn)
    ok = not mine
    if str(task).upper() == 'TRANS':
        mine.append('  (번역이라 구조·내용보존 대조는 안 쟀습니다)')
    if others:
        mine.append('  (이 절의 다른 언어·티어 자산의 흠 %d줄은 뺐습니다 — '
                    '이 글의 흠이 아닙니다)' % others)
    # ★ 요약은 **판정 뒤에** 붙인다 — 무엇을 쟀는지는 보여야 한다
    if notes and not mine:
        mine.append('  (%d가지를 쟀고 걸린 것이 없습니다)' % len(notes))
    return {'ok': ok, 'lines': mine[:20]}


# ══════════════════════════════════════════════════════════════════
#  묶음 게이트 — 칸마다 재고, 칸 사이도 잰다
# ══════════════════════════════════════════════════════════════════

# 짝마다 겹침 상한이 다르다(위 실측). 없는 짝은 `PAIR_DEFAULT`.
PAIR_DEFAULT = 0.40
# ⚠ **연구자료는 그 절 이야기를 길게 쓴다** — 설명문·연구질문과 낱말이
#   겹치는 것이 정상이다. 여느 문턱(0.40)을 대면 늘 걸린다.
PAIR_MAX = {('QUES', 'PRAYER'): 0.70,
            ('DESC', 'NOTE'): 0.65,
            ('STUDY', 'NOTE'): 0.75}

# 칸마다 모양이 다르다(실측 물음표 — 묵상질문 95.0% · 묵상기도 0.1%)
SHAPE = {
    'QUES':   ('?', True,  '묵상질문인데 물음표가 없습니다'),
    'STUDY':  ('?', True,  '연구질문인데 물음표가 없습니다'),
    'PRAYER': ('?', False, '묵상기도에 물음표가 있습니다 — 기도는 묻지 않습니다'),
}


def _tok(s):
    return set(re.findall(r'[가-힣]{2,}', s or ''))


def _jac(a, b):
    A, B = _tok(a), _tok(b)
    return len(A & B) / max(1, len(A | B))


# 한글이 이만큼 넘게 남아 있으면 **안 옮긴 것**이다(칸 표시는 뺀 뒤에 센다).
UNTRANSLATED_AT = 0.20


def not_translated(text, lang):
    """번역인데 **원문 언어 그대로**인가 — `(비율, 참/거짓)`.

    ★ 번역은 글자체계가 바뀌는 일이라 **기계로 잴 수 있다.** 이것을 안 재서
      한국어 연구질문이 EN 자산으로 적재됐다(2026-09-23 실측).
    ⚠ **KO 로 옮길 때는 안 잰다** — 한글이 나오는 것이 정상이다.
    ⚠ 칸 표시([연구질문] 따위)는 **자리 표시라 한국어가 맞다** — 빼고 센다.
    ⚠ 인용·고유명사로 한글이 조금 섞이는 것은 정상이라 **비율**로 본다.
    """
    if str(lang).upper() == 'KO':
        return 0.0, False
    body = re.sub(r'^\[[^\]]{1,12}\]\s*$', '', text or '', flags=re.M)
    han = len(re.findall(r'[가-힣]', body))
    tot = len(re.findall(r'[가-힣A-Za-z\u3040-\u30ff\u4e00-\u9fff'
                         r'\u0400-\u04ff\u0600-\u06ff]', body))
    if tot < 40:
        return 0.0, False
    r = han / tot
    return r, r > UNTRANSLATED_AT


def _is_sum(line):
    """**무엇을 쟀는지 알려 주는 요약 줄**인가 — 흠이 아니다.

    `db_vers_gate` 는 검사마다 「25개 검사 · 위반 0건」·「문장 74개 · 요체
    0개 … 위반 0건」을 적는다. 위반이 0 이면 그것은 **알림**이다.
    ⚠ 위반이 1건 이상인 요약은 **남긴다** — 그 아래 개별 줄이 없을 수도 있다.
    """
    return '위반 0건' in (line or '')


def _is_note(line):
    """흠이 아니라 **알림**인 줄인가 — 괄호로 시작하면 알림이다."""
    t = (line or '').strip()
    if t.startswith('['):                 # 「[칸이름] (…)」 꼴
        t = t.split(']', 1)[-1].strip()
    return t.startswith('(')


def gate_bundle(conn, slot_id, lang, text, task='NEW', seen_heads=None,
                before=None, want=None):
    """구절 묶음 한 건 — 가르고 · 칸마다 재고 · 칸 사이를 잰다.

    `want` = 이번 작업이 **고른 칸**(1.txt 16-2 · 2). 안 주면 표 그대로.
    ⚠ **가르지 못하면 거기서 끝난다** — 반쪽을 담느니 다시 돌리는 것이 낫다.
    """
    parts, why = AJ.bundle_split(text, want)
    if parts is None:
        return {'ok': False, 'lines': ['칸을 가르지 못했습니다 — %s' % why]}
    _kept = set(AJ.bundle_keys(want))    # ⚠ 아래 SHAPE 고리가 `want` 이름을 덮어쓴다 — 여기서 잡아 둔다
    out = []
    # ★★★ 317차-19 — **고른 칸만 잰다**(뺀 칸은 담지도 않으므로 재면 헛 흠이 된다).
    #   뺀 칸을 써 왔으면 그 사실만 알림으로(프롬프트가 새는지 보이게).
    if want:
        _keep = set(AJ.bundle_keys(want))
        _extra = [AJ.BUNDLE_PART[k]['name'] for k in list(parts) if k in AJ.BUNDLE_PART and k not in _keep]
        for _k in [k for k in list(parts) if k in AJ.BUNDLE_PART and k not in _keep]:
            parts.pop(_k, None)
        if _extra:
            out.append('(선택하지 않은 칸을 써 왔습니다 — 담지 않습니다: %s)' % ' · '.join(_extra))
    # ★★★ **재료가 새어 들어왔다** — 가르기가 끊어 냈지만 말은 해야 한다
    alien = parts.pop('_alien', '')
    # ★★★ **네 칸을 함께 초안으로** — 칸마다 따로 올리면 나머지가 「없다」로
    #   잡힌다(「VERS_DESC 없음(EN·KO)」 실측).
    all_draft = []
    for _k, _b in parts.items():
        _p = AJ.BUNDLE_PART.get(_k)
        # ⚠ **연구자료 칸은 초안으로 못 올린다** — `db_vers_gate` 의 겹치기는
        #   `sys_text_asset` 을 흉내 내는데 이 칸은 거기 안 담긴다.
        if _p and _p.get('text_type') and (_b or '').strip():
            all_draft.append((slot_id, _p['text_type'], lang,
                              _p['variant'], _b))
    if alien:
        out.append('재료를 되받아 적었습니다(잘라 냈습니다): %s' % alien)
    # ① 칸마다 — 그 칸의 유형·티어로 기존 게이트를 그대로 돌린다
    for k, body in parts.items():
        p = AJ.BUNDLE_PART[k]
        # ★★★ **연구자료는 서식 게이트로 잰다**(1.txt 16-1 · 4·5) —
        #   절 자산 게이트(문단 수·길이비·요체)는 A4 한 장짜리 글의 잣대가
        #   아니다. 잣대는 `db_study_gate` 한 곳이다.
        if p.get('store') == 'REF':
            try:
                import db_study_gate as SG
                for l in SG.check(body, min_ko=STUDY_MIN.get('VERS_BUNDLE')):
                    out.append('[%s] %s' % (p['name'], l))
                # ★★★ **승인하면 무엇이 함께 걸리는지 먼저 말한다**
                #   (사용자 5번 — 구절 연결은 자동 승인이고 용어도 함께
                #   붙는다). 적재한 뒤에 알리면 뒤늦게 고쳐야 한다.
                _cs = SG.cites(body)
                if _cs:
                    out.append('  (%s · 인용한 구절 %d곳이 함께 연결됩니다: %s)'
                               % (p['name'], len(_cs),
                                  ' · '.join('%s %s' % (x[1], x[2])
                                             for x in _cs[:5])))
                _ts = study_terms(conn, body)
                if _ts:
                    out.append('  (%s · 주요용어 %d개가 함께 연결됩니다: %s)'
                               % (p['name'], len(_ts),
                                  ' · '.join('%s(%s)' % (x[1], x[2])
                                             for x in _ts[:5])))
            except Exception as e:                        # noqa: BLE001
                out.append('[%s] 서식 검사가 터졌습니다: %s' % (p['name'], e))
            continue
        # ★★★ **그 칸의 자산으로 잰다** — 열쇠를 고정하면 묵상질문까지
        #   「설명문」 잣대(문단 수·길이비)로 재어진다(실측으로 당했다).
        g = gate_item(conn, p['asset'], slot_id, lang, body,
                      variant=p['variant'], task=task,
                      seen_heads=seen_heads if k == 'DESC' else None,
                      before=None,
                      extra=[d for d in all_draft if d[1] != p['text_type']
                             or d[3] != p['variant']],
                      # ★ 구조 검사는 **설명 칸에서 한 번만**
                      structure=(k == 'DESC'))
        for l in (g.get('lines') or []):
            # ★ **연구질문은 근거로 본문을 인용하는 것이 정상이다** —
            #   프롬프트가 「근거: 어느 절의 어느 표현인가」를 시킨다.
            #   자기 인용 검사는 설명문의 잣대이지 질문 칸의 잣대가 아니다.
            if k in ('STUDY', 'QUES') and '«' in l:
                continue
            out.append('[%s] %s' % (p['name'], l.strip()))
        out = [l for l in out if not l.endswith('사람이 봅니다.')]
    # ①-2 ★★★ **번역인데 안 옮겨진 칸** — 칸마다 잰다
    if str(task).upper() == 'TRANS':
        for k, body in parts.items():
            r, bad = not_translated(body, lang)
            if bad:
                out.append('[%s] 옮기지 않았습니다 — 한글이 %.0f%% 남아 있습니다'
                           % (AJ.BUNDLE_PART[k]['name'], r * 100))
    # ② 칸마다 모양
    for k, (ch, want, msg) in SHAPE.items():
        b = parts.get(k)
        if b and ((ch in b) != want):
            out.append('[%s] %s' % (AJ.BUNDLE_PART[k]['name'], msg))
    # ③ 칸 사이 되풀이
    keys = [k for k in parts if (parts.get(k) or '').strip()]
    for i, k1 in enumerate(keys):
        for k2 in keys[i + 1:]:
            lim = PAIR_MAX.get((k1, k2), PAIR_MAX.get((k2, k1), PAIR_DEFAULT))
            j = _jac(parts[k1], parts[k2])
            if j > lim:
                out.append('[%s↔%s] 같은 말을 되풀이합니다 — 낱말 겹침 %.2f '
                           '(넘으면 안 되는 값 %.2f)'
                           % (AJ.BUNDLE_PART[k1]['name'],
                              AJ.BUNDLE_PART[k2]['name'], j, lim))
    # ④ 다듬기면 잃은 것
    if str(task).upper() == 'EDIT' and before:
        out += edit_loss(before, text, conn)
    # ⑤ 필수가 아닌 칸이 비었다 — 흠이 아니라 **적어 둔다**
    # ★ 317차-19 — 고르지 않은 칸은 말하지 않는다(_kept 는 맨 앞에서 잡았다)
    for k in AJ.BUNDLE_PART:
        if k in _kept and not AJ.BUNDLE_PART[k]['need'] and not parts.get(k):
            out.append('  (%s 은 없습니다 — 걸리는 것이 없으면 정상입니다)'
                       % AJ.BUNDLE_PART[k]['name'])
    # ⚠ **정보 줄은 흠이 아니다** — 「(…뺐습니다)」·「(…정상입니다)」.
    #   칸 이름이 앞에 붙으면 `startswith('  (')` 를 빠져나간다(실측으로
    #   당했다 — 세 건이 다 거짓 「걸림」이었다).
    real = [l for l in out if not _is_note(l)]
    # ⚠ 같은 알림이 칸마다 되풀이되면 **진짜 흠이 묻힌다** — 한 줄로 모은다
    seen_note, tidy = set(), []
    for l in out:
        if _is_note(l):
            key = l.split(']', 1)[-1].strip()
            if key in seen_note:
                continue
            seen_note.add(key)
            tidy.append('  ' + key)
        else:
            tidy.append(l)
    return {'ok': not real, 'lines': tidy[:24]}


def job_prompt_obj(conn, j):
    """작업의 **프롬프트 객체** — 층을 합치고(`compose_prompt`) 작업에 걸린 것을 얹는다.
    ★ 2026-10-13 — `run_job` · 검수 화면 · 미리보기가 **이 하나**를 쓴다(보이는 것 = 보낸 것)."""
    obj = AJ.compose_prompt(conn, j['asset_kind'], j.get('scope_value', '') if hasattr(j, 'get') else '',
                            j['task'], j['lang'])
    # ★★★ **이번에 쓸 칸을 프롬프트가 말한다**(1.txt 16-2 · 2) — 프로필에
    #   박아 두면 체크를 바꿔도 프롬프트가 안 따라온다.
    _parts = (j.get('parts') or '') if hasattr(j, 'get') else ''
    if AJ.ASSET[j['asset_kind']].get('store') == 'LINK' and 'LINKDESC' in add_modes(j):
        # ★ 317차-5 — 연결하면서 **연결설명문을 함께**(사용자 체크상자). 줄 끝 「왜」 자리가
        #   곧 연결설명문이 되어 따로 작업을 만들지 않는다(같은 맥락 · 호출 한 번).
        _must = obj.get('must')
        obj['must'] = [AJ.LINKDESC_LINE] + (_must if isinstance(_must, list) else ([_must] if _must else []))
    if AJ.ASSET[j['asset_kind']].get('store') == 'BUNDLE':
        # ★★★ 317차-19 — 프롬프트를 **고른 칸만으로**(뺀 칸의 규칙·예시 블록을 걷는다)
        obj = AJ.bundle_filter(obj, _parts or None)
        _ask = AJ.bundle_ask(_parts)
        _must = obj.get('must')
        obj['must'] = [_ask] + (_must if isinstance(_must, list) else ([_must] if _must else []))
    try:
        if src_check_on(conn, j):
            _must = obj.get('must')
            obj['must'] = (_must if isinstance(_must, list) else ([_must] if _must else [])) + [SRC_RULE]
    except Exception:                                     # noqa: BLE001
        pass
    return obj


def job_endings(conn, j, job_id):
    """이 작업에서 이미 쓴 끝맺음 → `(Counter | None, 센 글 수)` — 우리 글 · 한국어만."""
    if j['asset_kind'] not in FORMULA_KINDS or str(j['lang']).upper() != 'KO':
        return None, 0
    c, n = Counter(), 0
    for (_t,) in conn.execute("SELECT out_text FROM sys_ai_item WHERE job_id=? AND state IN ('DONE','OK','LOADED')"
                              " AND COALESCE(out_text,'')<>''", (job_id,)):
        e0, _h0 = formula_counts([_prose_of(_t, j['asset_kind'])])
        c.update(e0)
        n += 1
    return c, n


def item_ctx(conn, j, sid, fixn='', fends=None, fdone=0):
    """한 건의 **재료** — 실제로 보낼 때와 같은 것(고른 칸만 · 다시 쓰기 · 자주 쓴 끝맺음 알림)."""
    ctx = AJ.material(conn, j['asset_kind'], sid, j['task'],
                      base=j['base_lang'], lang=j['lang'],
                      scope=j['scope_value'])
    # ★ 317차-19 — 재료도 고른 칸만(다듬기의 지금 글에 뺀 칸이 실리면 AI 가 그 칸을 다시 쓴다)
    if AJ.ASSET[j['asset_kind']].get('store') == 'BUNDLE':
        ctx = AJ.bundle_filter(ctx, j.get('parts') or None, lines=False)
    if '⚠' in ctx:
        return ctx
    if fixn:
        # ★★★ 317차-5 — **게이트 반영 다시 쓰기** — 앞 글과 걸린 것을 함께 주고 걸린 것만 고치게 한다
        try:
            _fx = json.loads(fixn)
        except Exception:                                 # noqa: BLE001
            _fx = {}
        if _fx.get('prev'):
            ctx['앞에서 쓴 글 — 이 글을 고쳐서 낸다'] = _fx['prev']
        if _fx.get('lines'):
            ctx['게이트가 잡은 것 — 이것만 고치고 나머지는 그대로 둔다'] = chr(10).join(_fx['lines'])
    # ★★ 2026-10-13 — **이 작업에서 이미 자주 쓴 끝맺음**을 다음 건에 알린다(건마다 따로 보내면 AI 는
    #   앞의 글을 모른다 — 검증 작업 900 「이어집니다」 54%). 잣대 = `formula_counts`.
    if fends is not None and fdone >= 3:
        _lim = max(2, int(0.2 * fdone + 0.999))
        _hot = [w for w, n_ in fends.most_common(6) if n_ >= _lim]
        if _hot:
            ctx['이 작업에서 이미 자주 쓴 끝맺음 — 이번 글은 이 말들로 끝내지 않는다'] = ' · '.join(_hot)
    return ctx


def build_item_prompt(conn, job_id, item_id):
    """그 건에 **지금 보낸다면 나갈 글** → `(글, 재료 dict)` — 검수 화면이 「보낸 기록이 없을 때」 보인다.
    ⚠ 보낸 기록이 있으면 그것이 정답이다(`ai_sent_log.for_item`) — 이것은 재구성이다."""
    j = job(conn, job_id)
    r = conn.execute("SELECT slot_id, COALESCE(fix_note,'') FROM sys_ai_item WHERE item_id=?", (item_id,)).fetchone()
    if not j or not r:
        return '', {}
    fe, fd = job_endings(conn, j, job_id)
    ctx = item_ctx(conn, j, r[0], r[1], fe, fd)
    if '⚠' in ctx:
        return '(재료를 못 모아 보내지 않습니다: %s)' % ctx['⚠'], ctx
    return AJ.render_prompt(job_prompt_obj(conn, j), ctx), ctx


# ══════════════════════════════════════════════════════════════════════════
# ★★★ 묶어 보내기 (2026-10-30 · 사용자 「50개를 선택하면 앱이 알아서 적절하게 분할하고 남는 것은 다음에 묶는 방식」)
#   실측(사전 6건 · Pro low): 한 건씩 건당 약 39원 · 3건 묶음 20원 · 6건 묶음 9원 — 품질 같음.
#   돈의 대부분은 호출마다 붙는 「생각」이고 묶으면 그것이 준다(지시문을 거듭 안 보내는 몫은 작다).
#   ⇒ **번역만** 묶는다(잰 것이 번역뿐) · 원문 합계 `cap_chars`(작업 칸 · 기본 6000자)까지 · 많아야 `BATCH_MAX` 건 ·
#     그보다 큰 건 · 다시 쓰기 건은 한 건씩.
#   ⚠ 받은 글을 항목 줄로 못 나누면(빠짐·뒤섞임·빈 항목) **그 묶음은 담지 않고 한 건씩 다시 보낸다** —
#     글이 엉뚱한 자리에 담기는 것이 비용보다 나쁘다.
# ══════════════════════════════════════════════════════════════════════════
BATCH_MAX = 8
BATCH_MARK = '===== 항목 %d ====='
_BATCH_SPLIT = re.compile(r'^=+\s*항목\s*(\d+)\s*=+\s*$', re.M)


def batch_ok(j):
    """묶어 보낼 수 있나 — ★ 2026-10-30 번역 · 새로 쓰기 · 다듬기 모두(사용자 「별도 세팅 없이 모든 동작에서」) ·
    ⚠ 절 묶음(BUNDLE · 한 건이 칸 다섯)과 구절 연결(LINK · 줄마다 짝)은 한 건씩 — 받은 글의 꼴이 따로 있다."""
    a = AJ.ASSET.get(j['asset_kind'], {})
    return str(j['task']).upper() in ('TRANS', 'NEW', 'EDIT') and a.get('store') not in ('BUNDLE', 'LINK')


def plan_batches(conn, j, todo, cap=None):
    """`todo`[(item_id, slot_id, fix_note)] → (묶음들[[(iid, sid, ctx)]], 한 건씩[(iid, sid, fix)]) — 차례는 그대로."""
    cap = int(cap or j.get('cap_chars') or 6000)
    groups, singles, cur, cur_n = [], [], [], 0
    for iid, sid, fixn in todo:
        if fixn:
            singles.append((iid, sid, fixn))
            continue
        try:
            ctx = item_ctx(conn, j, sid)
        except Exception:                                 # noqa: BLE001
            ctx = {'⚠': 'x'}
        if '⚠' in ctx:
            singles.append((iid, sid, fixn))
            continue
        sz = sum(len(str(v)) for v in ctx.values())
        if sz > cap:
            singles.append((iid, sid, fixn))
            continue
        if cur and (cur_n + sz > cap or len(cur) >= BATCH_MAX):
            groups.append(cur)
            cur, cur_n = [], 0
        cur.append((iid, sid, ctx))
        cur_n += sz
    if cur:
        groups.append(cur)
    out = []
    for g in groups:
        if len(g) == 1:
            singles.append((g[0][0], g[0][1], ''))
        else:
            out.append(g)
    return out, singles


# ── 원문 의심 (2026-10-30 사용자 「원문의심을 넣어라. 절대 수정하지 못하도록 지적만 하도록 하라」) ──────
# ★ 번역은 원문 그대로 — AI 가 원문을 고치면 저자 글이 바뀐다(§0-1b). 흠은 **맨 끝 줄에 지적만**.
# ★ **한 원문에 한 번** — 같은 영어 원문을 여러 언어로 옮기므로 첫 번역에서 보면 된다.
#   자리마다 `sys_ai_srccheck` 에 「점검함」을 적고, 그 자산의 자리가 다 점검됐으면 지시를 안 붙인다.
SRC_MARK = '[원문 의심]'
SRC_RULE = ('원문(옮길 글)은 원문 그대로 옮긴다 — 원문이 틀려 보여도 옮긴 글에서 고치거나 빼거나 보태지 않는다. '
            '원문 자체에 의심스러운 곳(오탈자 · 깨진 글자 · 틀린 장절 표기 · 사실과 다른 내용)이 보이면 '
            '옮긴 글을 다 쓴 뒤 맨 끝에 「' + SRC_MARK + ' 원문 글자 그대로 — 무엇이 의심스러운가」 한 줄로만 적는다'
            '(여럿이면 한 줄에 하나 · 이 줄은 한국어로). 의심스러운 곳이 없으면 아무것도 적지 않는다.')
_SRC_LINE = re.compile(r'^[\s>*·\-•]*\[원문\s*의심\]\s*')


def take_src_note(text):
    """받은 글 → (옮긴 글, 원문 의심 줄들) — 의심 줄은 번역 글에서 뗀다"""
    keep, notes = [], []
    for ln in (text or '').split(chr(10)):
        if _SRC_LINE.match(ln):
            t = _SRC_LINE.sub('', ln).strip()
            if t:
                notes.append(t)
        else:
            keep.append(ln)
    return chr(10).join(keep).rstrip(), chr(10).join(notes)


def src_check_on(conn, j):
    """이 번역 작업에 「원문 의심」 지시를 붙이나 — 아직 점검 안 한 자리가 남았을 때만"""
    if str(j['task']).upper() != 'TRANS':
        return False
    try:
        if (conn.execute("SELECT config_val FROM sys_config WHERE config_key='AI_SRC_CHECK'").fetchone() or ['1'])[0] == '0':
            return False
    except Exception:                                     # noqa: BLE001
        pass
    ensure(conn)
    return conn.execute(
        "SELECT 1 FROM sys_ai_item i WHERE i.job_id=? AND i.state IN ('PENDING','FAIL','QUEUED')"
        " AND NOT EXISTS (SELECT 1 FROM sys_ai_srccheck c WHERE c.asset_kind=? AND c.slot_id=CAST(i.slot_id AS TEXT))"
        " LIMIT 1", (j['job_id'], j['asset_kind'])).fetchone() is not None


def keep_src_note(conn, j, iid, sid, note):
    """원문 의심을 그 건에 남기고 · 번역이면 그 자리를 「점검함」으로"""
    conn.execute("UPDATE sys_ai_item SET src_note=? WHERE item_id=?", (note or None, iid))
    if str(j['task']).upper() == 'TRANS':
        conn.execute("INSERT OR IGNORE INTO sys_ai_srccheck(asset_kind, slot_id, lang, checked_at) VALUES (?,?,?,?)",
                     (j['asset_kind'], str(sid), j['lang'], _now()))
    conn.commit()


def batch_prompt(obj, group):
    L = [AJ.render_prompt(obj, {}), '',
         '[여러 항목을 한 번에] 아래 %d개 항목을 각각 따로 처리한다. 항목마다 위 지시를 그대로 지키고, 다른 항목의 글을 섞거나 서로 닮게 쓰지 않는다.' % len(group),
         '답은 항목마다 「%s」 한 줄을 먼저 쓰고 그 아래에 그 항목의 글만 쓴다. 다른 말은 쓰지 않는다.'
         % (BATCH_MARK % 1).replace('1', 'N'), '']
    for n, (_iid, _sid, ctx) in enumerate(group, 1):
        L.append(BATCH_MARK % n)
        L += ['[%s]\n%s' % (k, v) for k, v in ctx.items()]
        L.append('')
    return '\n'.join(L)


def split_batch(text, n):
    """묶음 답 → 항목 글 n개 · 못 나누면 None(빠짐·겹침·빈 항목)"""
    parts = _BATCH_SPLIT.split(text or '')
    got = {}
    for i in range(1, len(parts) - 1, 2):
        k = int(parts[i])
        if k in got:
            return None
        got[k] = parts[i + 1].strip()
    if sorted(got) != list(range(1, n + 1)) or not all(got.values()):
        return None
    return [got[k] for k in range(1, n + 1)]


def run_job(conn, job_id, limit=0, on_progress=None, _call=None,
            should_stop=None, only=None):
    """**아직 안 한 것만** 집어 돌린다 — 중단한 자리에서 이어진다.

    `limit` 은 이번에 처리할 건수(0 이면 전부). `on_progress(i, n, item, res)`.
    ⚠ 한 건이 터져도 다음으로 간다.

    `only` 를 주면 **그 건별 번호만** 보낸다(2026-09-25 사용자 「복수선택
    하고 전송하기」). ⚠ 그때도 **이미 받은 건은 다시 안 보낸다** — 고른 줄에
    끝난 것이 섞여 있어도 한도를 두 번 먹지 않는다.

    `should_stop()` 이 참을 내면 **그 자리에서 멈춘다**(2026-09-24 사용자
    「응답이 없다」 — 여러 건을 돌리는 동안 사람이 그만두고 싶을 수 있다).
    ⚠ **한 건을 자르지 않는다** — 건과 건 사이에서만 멈춘다. 중간에 끊으면
      보낸 요청은 한도를 먹고 받은 글은 버려진다.
    ⚠ 안 한 건은 `PENDING` 그대로라 **다시 누르면 이어진다**.
    """
    ensure(conn)
    j = job(conn, job_id)
    assert j, '그런 작업이 없습니다: %s' % job_id
    # ★★★ **층을 합쳐서 보낸다**(2026-09-25 · 1.txt 16-2 · 3) — 전체 공통 →
    #   자산 유형별 → 대상 언어별 → 개별(범위) 층. 합치는 자리는 `compose_prompt`
    #   **하나**다(화면 미리보기도 그것을 쓴다 — 두 곳이면 갈린다).
    #   ⚠ 옛 프로필은 294차에 층으로 옮겨져 여기서 더 읽지 않는다.
    _ok, _why = AJ.has_prompt(conn, j['asset_kind'], j.get('scope_value', ''),
                              j['task'], j['lang'])
    assert _ok, _why
    obj = job_prompt_obj(conn, j)
    call = _call or AC.call
    q = ("SELECT item_id, slot_id, COALESCE(fix_note,'') FROM sys_ai_item WHERE job_id=? "
         "AND state IN ('PENDING','FAIL')")
    ar = [job_id]
    if only:
        ids = [int(x) for x in only]
        q += " AND item_id IN (%s)" % ','.join('?' * len(ids))
        ar += ids
    q += " ORDER BY item_id%s" % (' LIMIT %d' % int(limit) if limit else '')
    todo = conn.execute(q, ar).fetchall()
    n, done, fail = len(todo), 0, 0
    heads = set()            # ★ 이 작업에서 이미 쓴 글의 첫머리
    stopped = 0
    # ★ 2026-10-13 — 이 작업에서 쓴 끝맺음(우리 글 · 한국어만) — 이미 받은 건부터 센다
    _fends, _fdone = job_endings(conn, j, job_id)
    # ★ 2026-10-30 번역은 묶어 보낸다(위 「묶어 보내기」) — 묶음이 끝난 뒤 남은 것만 아래 한 건씩
    k0 = 0
    if batch_ok(j) and len(todo) > 1:
        groups, todo = plan_batches(conn, j, todo)
        import ai_sent_log as _SLb
        for g in groups:
            if should_stop is not None:
                try:
                    if should_stop():
                        stopped = n - k0
                        n = k0
                        todo = []
                        break
                except Exception:                         # noqa: BLE001
                    pass
            ids_ = [x[0] for x in g]
            try:
                with _SLb.tag('AI 작업실', 'job %d · 묶음 %d건 · item %s' % (job_id, len(g), ','.join(map(str, ids_))),
                              job_id=job_id, item_id=ids_[0]):
                    try:
                        res = call(batch_prompt(obj, g), model=j['model'], conn=conn, thinking=AC.task_think(conn, j['task']))
                    except TypeError:                     # 시험용 가짜 call
                        res = call(batch_prompt(obj, g), model=j['model'], conn=conn)
            except Exception as e:                        # noqa: BLE001
                res = {'ok': False, 'why': str(e)}
            if res.get('daily'):
                # ★ 2026-10-30 하루 한도 — 남은 묶음·건을 보내지 않는다(PENDING 그대로 · 내일 다시 누르면 이어진다)
                stopped = n - k0
                n = k0
                todo = []
                for x in g:
                    _mark(conn, x[0], 'PENDING', why=res.get('why'))
                break
            texts = split_batch(res.get('text') or '', len(g)) if res.get('ok') else None
            if texts is None:
                # 못 나눴으면 이 묶음은 한 건씩 다시(맨 앞으로 — 차례를 지킨다)
                todo = [(x[0], x[1], '') for x in g] + list(todo)
                continue
            tk = res.get('tokens') or {}
            share = {kk: int(tk.get(kk, 0)) // len(g) for kk in ('in', 'out')}
            for (iid, sid, _ctx), txt in zip(g, texts):
                k0 += 1
                txt, _sn = take_src_note(txt)
                keep_src_note(conn, j, iid, sid, _sn)
                g_ = gate_for_job(conn, j, sid, txt, heads)
                heads.add(head_of(txt))
                _mark(conn, iid, 'DONE', text=txt, gate=g_, tok=share)
                done += 1
                if on_progress:
                    try:
                        on_progress(k0, n, sid, res)
                    except Exception:                     # noqa: BLE001
                        pass
    for i, (iid, sid, fixn) in enumerate(todo, k0 + 1):
        if should_stop is not None:
            try:
                if should_stop():
                    stopped = n - i + 1        # 아직 안 한 건
                    n = i - 1                  # 실제로 보낸 것만 센다
                    break
            except Exception:                             # noqa: BLE001
                pass
        try:
            ctx = item_ctx(conn, j, sid, fixn, _fends, _fdone)
            if '⚠' in ctx:
                _mark(conn, iid, 'FAIL', why=ctx['⚠'])
                fail += 1
                continue
            prompt = AJ.render_prompt(obj, ctx)
            # ★ 2026-10-13 — 보낸 글은 `ai_client` 가 글자 그대로 남긴다 · 여기서는 「무엇의 글인가」를 붙인다
            import ai_sent_log as _SL
            with _SL.tag('AI 작업실', 'job %d · item %d · 자리 %s' % (job_id, iid, sid), job_id=job_id, item_id=iid):
                # ★ 2026-10-30 번역은 생각 low — 실측 6건: 기본 $0.275 ↔ low $0.166 · 게이트 6/6 같고 오류 찾기 0·1(사소)
                #   신규·다듬기는 기본 그대로(글을 짓는 일이라 견주지 않았다)
                _th = AC.task_think(conn, j['task'])
                try:
                    res = call(prompt, model=j['model'], conn=conn, thinking=_th)
                except TypeError:                         # 시험용 가짜 call
                    res = call(prompt, model=j['model'], conn=conn)
        except Exception as e:                            # noqa: BLE001
            _mark(conn, iid, 'FAIL', why='터졌다: %s' % e)
            fail += 1
            res = {'ok': False, 'why': str(e)}
        else:
            if res.get('daily'):
                _mark(conn, iid, 'PENDING' if not fixn else 'FAIL', why=res.get('why', ''))
                stopped = n - i + 1
                n = i - 1
                break
            if not res.get('ok'):
                _mark(conn, iid, 'FAIL', why=res.get('why', ''))
                fail += 1
            else:
                txt, _sn = take_src_note((res.get('text') or '').strip())
                keep_src_note(conn, j, iid, sid, _sn)
                # ★ 다듬기면 **앞글**을 함께 넘긴다 — 잃은 것은 견줘야 보인다
                _before = None
                if str(j['task']).upper() == 'EDIT':
                    for _k, _v in ctx.items():
                        if _k.startswith('지금 글'):
                            _before = _v
                            break
                g = gate_for_job(conn, j, sid, txt, heads, before=_before)
                heads.add(head_of(txt))
                if _fends is not None:
                    _e1, _h1 = formula_counts([_prose_of(txt, j['asset_kind'])])
                    _fends.update(_e1)
                    _fdone += 1
                _mark(conn, iid, 'DONE', text=txt,
                      gate=g, tok=res.get('tokens') or {})
                if fixn:
                    conn.execute("UPDATE sys_ai_item SET fix_note=NULL WHERE item_id=?", (iid,))
                    conn.commit()
                done += 1
        if on_progress:
            try:
                on_progress(i, n, sid, res)
            except Exception:                             # noqa: BLE001
                pass
    try:
        formula_pass(conn, job_id)           # ★ 2026-10-13 — 작업 전체를 봐야 보이는 흠
    except Exception:                                     # noqa: BLE001
        pass
    return {'tried': n, 'done': done, 'fail': fail, 'stopped': stopped}



# ─────────────────────────────────────────────────────────────────────────────
# ★★★ 게이트 줄 규칙 · 관리자 설정 · 금지 문구 · 틀 문구 반복 (2026-10-13 · docs/1.txt 71)
# ─────────────────────────────────────────────────────────────────────────────
# 사용자 「예제 / 게이트를 수정할 수 없다 … 문제가 심각하다 · 전수조사하라 · 철저하게 검증하라」.
# ★ 게이트 줄에는 「어느 검사가 낸 줄인가」가 안 적혀 있었다 — 그래서 관리자가 한 검사만 끄거나
#   「참고」로 낮출 길이 없었다(실측: 연결설명문 다듬기에서 「인용 표시 사라짐」 168회가 정상 변화를 흠으로).
#   ⇒ 줄을 **규칙**으로 묶는 표 하나(`GATE_RULES`) · 규칙마다 자산×업무로 기본/참고/끔(`sys_ai_gate_cfg`).
#   판정 방법은 코드에 두고, **세기(흠/참고/끔)만** 관리자가 정한다.
#: (규칙 열쇠, 게이트 열쇠, 이름, 줄을 알아보는 정규식) — 위에서부터 처음 맞는 것.
GATE_RULES = [
    ('pass', '', '통과 문구', r'규칙대로입니다|원본과 같습니다|아직 기계 게이트가 없습니다|잃거나 보탠 것이 없습니다|걸린 것이 없습니다'),
    ('crash', '', '검사가 못 돌았다', r'검사가 터졌다|못 돌렸습니다|터졌습니다|다시 재다 터짐'),
    ('banned', 'banned', '금지 문구', r'^금지 문구'),
    ('formula', 'formula', '틀 문구 반복', r'^틀 문구'),
    ('edit_quote', 'edit_loss', '다듬기 · 인용 표시 사라짐', r'인용 표시가 .*사라졌다'),
    ('edit_ref', 'edit_loss', '다듬기 · 구절 표기 사라짐', r'구절 표기가 사라졌다'),
    ('edit_paren', 'edit_loss', '다듬기 · 괄호 사라짐', r'괄호가 사라졌다'),
    ('edit_name', 'edit_loss', '다듬기 · 이름 사라짐', r'이름이 사라졌다'),
    ('edit_shrink', 'edit_loss', '다듬기 · 분량 깎임', r'로 줄었다'),
    ('edit_blank', 'edit_loss', '다듬기 · 빈 줄 늘림', r'원문에 없던 빈 줄'),
    ('edit_head', 'edit_loss', '다듬기 · 머리줄 붙임', r'원문에 없던 머리줄'),
    ('trans_paras', 'trans_paras', '문단 수', r'^문단(\(줄\))? ?\d+개 — (원본은|\d)'),
    ('trans_blank', 'trans_blank', '번역 · 빈 줄', r'빈 줄이 두 겹|빈 줄이 있습니다'),
    ('untranslated', 'untranslated', '옮기지 않음', r'옮기지 않았습니다'),
    ('trans_lang', 'trans_lang', '써 넣을 언어', r'써 넣을 언어|한글이 \d+자 섞였습니다'),
    ('trans_orig', 'trans_orig', '원어 낱자', r'히브리·헬라 글자'),
    ('trans_ar_digits', 'trans_ar_digits', '아랍어 숫자 혼용', r'아라비아 숫자'),
    ('trans_markup', 'trans_markup', '서식 군더더기', r'굵게 표시|마크다운|코드 울타리|머리말을 붙였'),
    ('echo', 'trans_markup', '재료 되받아 적기', r'재료를 되받아'),
    ('trans_marks', 'trans_marks', '증거 구절 표시', r'증거 구절 표시가 원문과 다릅니다'),
    ('comm_ref', 'comm_ref', '주석 장 번호', r'장 번호가 다릅니다 — 이 글은'),
    ('comm_form', 'comm_form', '주석 문체·참조 표시', r'참조 표시 \{a\} 가 원문|한다체 문장'),
    ('study_short', 'study', '연구자료 · 짧음', r'너무 짧습니다'),
    ('study_orig', 'study', '연구자료 · 음독 없음', r'음독이 없습니다'),
    ('study_quote', 'study', '연구자료 · 인용 줄 꼴', r'인용인데 역본이 없습니다'),
    ('study_num', 'study', '연구자료 · 번호 꼴', r'번호 뒤에 빈칸|기호'),
    # ★ 요약 줄 — 장 전체를 잰 요약이라 실제 위반이 다른 절·다른 언어 것으로 걸러진 뒤에도 남아 헛흠을 냈다
    #   (2026-10-13 실측 — 처음 통과한 묶음 173건이 이 줄로만 걸렸다). 늘 알림으로 다룬다.
    ('summary', 'structure', '요약 줄(알림)', r'\d+개 검사 · 위반 있음|\d+절 · EXPERT \d+절 · 유사도'),
    ('struct_para', 'structure', '문단 없음', r'문단없음'),
    ('struct', 'structure', '구조·짝·내용 보존', r'내용보존|길이비=|유사도|신출어휘|원어과밀|검사 · 위반 있음|없음\(|한쪽만'),
    ('head', 'head', '첫머리 겹침', r'첫머리가 .*같다'),
    ('names', 'names', '표기 고정(개역한글)', r'표기가 개역한글과 다르다|다른 역본 이름'),
    ('vvd_reader', 'vvd_reader', '독자 부름 · 본문 베낌', r'독자를 부르는|본문을 그대로 옮겼습니다'),
    ('style', 'ours', '합니다체·문체', r'합니다체가 아닙니다|평서체 종결|대시|동그라미 번호|교단'),
    ('length', 'ours', '분량', r'자 \(.*\)|글자가 .*(짧|깁)|분량'),
    ('title', 'ours', '제목·이름 꼴', r'제목이 깁니다|제목에 번호'),
    ('ques', 'structure', '물음표', r'물음표가 없습니다'),
    ('bundle_split', 'structure', '칸 나누기', r'칸을 가르지 못했습니다|칸 표시'),
    ('link_near', 'link_near', '같은 장 금지', r'같은 장 안의 절'),
    ('link_ref', 'link_ref', '절 표기 실재', r'좌표로 못 푼'),
    ('link_form', 'link_form', '연결 줄 꼴', r'못 읽은 줄'),
    ('link_rel', 'link_rel', '갈래 코드', r'갈래 코드|모르는 갈래'),
    ('cite', 'cite', '성경 인용 대조', r'^\S+ ?\d+:\d+|인용.*다르|역본과 다릅'),
    ('vers_detail', 'structure', '절 게이트 세부 줄', r'^\[?[^\]]*\]? ?\d+:\d+'),
]
_GATE_RULE_RE = [(k, g, n, re.compile(rx)) for k, g, n, rx in GATE_RULES]
GATE_RULE_NAME = {k: n for k, _g, n, _rx in GATE_RULES}
GATE_MODES = ('MUST', 'NOTE', 'OFF')
GATE_MODE_KO = {'MUST': '흠(막음)', 'NOTE': '참고(알림)', 'OFF': '끔', '': '기본'}

CFG_SCHEMA = """
CREATE TABLE IF NOT EXISTS sys_ai_gate_cfg (
    kind TEXT NOT NULL DEFAULT '',      -- 자산('' = 모든 자산)
    task TEXT NOT NULL DEFAULT '',      -- 업무('' = 모든 업무)
    rule TEXT NOT NULL,                 -- GATE_RULES 열쇠
    mode TEXT NOT NULL CHECK (mode IN ('MUST','NOTE','OFF')),
    note TEXT,
    updated_at TEXT,
    PRIMARY KEY (kind, task, rule)
);
"""
#: 금지 문구 — {자산 또는 '*': [문구]} · 공백을 무시하고 찾는다 · 관리자가 고친다
BANNED_KEY = 'AI_BANNED_PHRASES'
#: 틀 문구 반복 — 한 작업 안에서 같은 끝맺음·첫머리가 이 비율을 넘으면 흠
FORMULA_SHARE = 0.20
FORMULA_MIN = 5
#: 어디에나 흔한 끝맺음 — 반복으로 세지 않는다
_GENERIC_END = set('있습니다 합니다 입니다 됩니다 줍니다 않습니다 없습니다 했습니다 했다 이다 한다 있다 '
                   '보여줍니다 보여 줍니다 알려줍니다 말합니다 뜻합니다 가리킵니다 같습니다 아닙니다'.split())


def gate_rule_of(line):
    """게이트 줄 → 규칙 열쇠(모르면 'other')."""
    t = (line or '').strip()
    t2 = re.sub(r'^\[[^\]]+\]\s*', '', t)
    for k, _g, _n, rx in _GATE_RULE_RE:
        if rx.search(t2) or rx.search(t):
            return k
    return 'other'


def ensure_cfg(conn):
    conn.executescript(CFG_SCHEMA)


def gate_cfg(conn, kind, task):
    """{규칙: 모드} — 좁은 것이 이긴다(자산+업무 > 자산 > 업무 > 전체)."""
    try:
        ensure_cfg(conn)
        rows = conn.execute("SELECT kind, task, rule, mode FROM sys_ai_gate_cfg"
                            " WHERE kind IN ('', ?) AND task IN ('', ?)",
                            (kind or '', str(task or '').upper())).fetchall()
    except Exception:                                     # noqa: BLE001
        return {}
    out, rank = {}, {}
    for k, t, r, m in rows:
        sc = (2 if k else 0) + (1 if t else 0)
        if sc >= rank.get(r, -1):
            out[r], rank[r] = m, sc
    return out


def set_gate_cfg(conn, kind, task, rule, mode, note=''):
    """규칙 하나의 세기를 정한다 — mode '' 면 그 줄을 지워 기본으로."""
    ensure_cfg(conn)
    kind, task = kind or '', str(task or '').upper()
    if rule not in GATE_RULE_NAME or rule in ('pass',):
        raise ValueError('모르는 규칙: %s' % rule)
    if not mode:
        conn.execute("DELETE FROM sys_ai_gate_cfg WHERE kind=? AND task=? AND rule=?", (kind, task, rule))
    else:
        if mode not in GATE_MODES:
            raise ValueError('모르는 세기: %s' % mode)
        if rule == 'crash' and mode != 'MUST':
            raise ValueError('「검사가 못 돌았다」는 끄거나 낮출 수 없습니다 — 검사 없이 통과하게 된다')
        import datetime as _dt
        conn.execute("INSERT OR REPLACE INTO sys_ai_gate_cfg(kind, task, rule, mode, note, updated_at)"
                     " VALUES(?,?,?,?,?,?)", (kind, task, rule, mode, note or '',
                                              _dt.datetime.now().isoformat(timespec='seconds')))
    conn.commit()


def banned_phrases(conn, kind):
    try:
        r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?", (BANNED_KEY,)).fetchone()
        d = json.loads(r[0]) if r and r[0] else {}
    except Exception:                                     # noqa: BLE001
        d = {}
    return [x for x in (d.get('*') or []) + (d.get(kind or '') or []) if (x or '').strip()]


def set_banned_phrases(conn, kind, phrases):
    try:
        r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?", (BANNED_KEY,)).fetchone()
        d = json.loads(r[0]) if r and r[0] else {}
    except Exception:                                     # noqa: BLE001
        d = {}
    d[kind or '*'] = [p.strip() for p in phrases if (p or '').strip()]
    conn.execute("INSERT OR REPLACE INTO sys_config(config_key, config_val) VALUES(?,?)",
                 (BANNED_KEY, json.dumps(d, ensure_ascii=False)))
    conn.commit()


def banned_lines(conn, kind, text):
    t = re.sub(r'\s+', '', text or '')
    out = []
    for ph in banned_phrases(conn, kind):
        if re.sub(r'\s+', '', ph) and re.sub(r'\s+', '', ph) in t:
            out.append('금지 문구가 들어 있습니다: 「%s」 — 관리자가 막은 문구입니다.' % ph)
    return out


def apply_gate_cfg(conn, kind, task, res):
    """게이트 결과에 관리자 설정을 입힌다 — 끈 규칙은 빼고, 참고로 낮춘 규칙은 알림으로.

    ⚠ 「검사가 못 돌았다」(crash)는 낮추지 못한다 — 검사 없이 통과하게 된다(2026-09 99건 적재 사고).
    """
    cfg = gate_cfg(conn, kind, task)
    lines = list(res.get('lines') or [])
    out, off = [], 0
    for line in lines:
        if _is_note(line):
            out.append(line)
            continue
        rule = gate_rule_of(line)
        if rule == 'pass':
            out.append(line)
            continue
        m = 'NOTE' if rule == 'summary' else cfg.get(rule, '')
        if m == 'OFF' and rule != 'crash':
            off += 1
            continue
        if m == 'NOTE' and rule != 'crash':
            mm = re.match(r'^(\s*\[[^\]]+\]\s*)(.*)$', line)
            line = ('%s(참고 · %s)' % (mm.group(1), mm.group(2).strip())) if mm else '  (참고 · %s)' % line.strip()
        out.append(line)
    if off:
        out.append('  (관리자가 꺼 둔 검사 %d줄은 뺐습니다)' % off)
    real = [l for l in out if not _is_note(l) and gate_rule_of(l) != 'pass']
    if res.get('ok') is not None or real:
        res['ok'] = not real
    if not real and not [l for l in out if gate_rule_of(l) == 'pass']:
        out.append('꼴은 규칙대로입니다 — 글 자체는 사람이 봅니다.')
    res['lines'] = out
    return res


def _sentences(t):
    return [x.strip() for x in re.split(r'(?<=[.!?。])\s+', t or '') if x.strip()]


#: ★ 틀 문구 검사는 **우리가 쓰는 글**에만 — 남의 글을 옮기거나 다듬는 것(도서·주석·자료집·소개문·맛보기)은
#:   저자의 문체가 되풀이되는 것이라 틀이 아니다(2026-10-13 실측 — 도서 다듬기의 「…것입니다」를 헛걸었다).
FORMULA_KINDS = set(OURS_KINDS) | {'VERS_BUNDLE', 'VERS_DESC_LAY', 'VERS_LINK', 'REF_STUDY'}
#: 묶음에서 잴 칸 — 묵상질문·묵상기도는 끝맺음이 본래 비슷하다(「…까?」·「…주십시오」)
FORMULA_BUNDLE_PARTS = ('설명문', '연구질문', '연구자료')
_PART_MARK = re.compile(r'^\s*\[(설명문|묵상질문|묵상기도|연구질문|연구자료)\]\s*')


def _prose_of(text, kind):
    """틀 문구를 잴 글 — 묶음이면 산문 칸만 이어 붙이고 칸 표식을 걷는다."""
    if kind != 'VERS_BUNDLE':
        return _PART_MARK.sub('', text or '')
    keep, cur = [], None
    for line in (text or '').split(chr(10)):
        m = _PART_MARK.match(line)
        if m:
            cur = m.group(1)
            line = line[m.end():]
        if cur in FORMULA_BUNDLE_PARTS and line.strip():
            keep.append(line)
    return chr(10).join(keep)


def formula_counts(texts):
    """글 묶음 → (끝맺음 Counter, 첫머리 Counter) — 글마다 한 번씩 센다.
    ⚠ 물음(「…까」로 끝나는 말)은 끝맺음으로 안 센다 — 물음은 본래 그렇게 끝난다."""
    ends, heads = Counter(), Counter()
    for t in texts:
        es = set()
        for snt in _sentences(t):
            ws = re.findall(r'[가-힣]+', snt)
            if ws and ws[-1] not in _GENERIC_END and len(ws[-1]) >= 3 and not ws[-1].endswith('까'):
                es.add(ws[-1])
        ends.update(es)
        ws = re.findall(r'[가-힣]+', (t or '')[:40])
        if len(ws) >= 3:
            heads[' '.join(ws[:3])] += 1
    return ends, heads


def formula_pass(conn, job_id):
    """**한 작업 안의 틀 문구 반복** — 같은 끝맺음·첫머리가 글의 20%를 넘으면 그 글들에 흠을 단다.

    ★ 실측(2026-10-13) — 연결설명문 863건 중 「…자라납니다」 323건(37%). 한 건씩 재는 게이트는 이것을
      못 본다(한 건만 보면 멀쩡한 문장이다). 작업 전체를 봐야 보인다.
    ⚠ 검수 대기(DONE)만 고친다. 한국어 글만 잰다(끝맺음 잣대가 한국어다).
    → 흠을 단 건수.
    """
    j = job(conn, job_id)
    if not j or str(j['lang']).upper() != 'KO' or j['asset_kind'] not in FORMULA_KINDS:
        return 0
    rows = conn.execute("SELECT item_id, out_text, gate_json FROM sys_ai_item WHERE job_id=? AND state='DONE'"
                        " AND COALESCE(out_text,'')<>''", (job_id,)).fetchall()
    rows = [(iid, _prose_of(t, j['asset_kind']), g) for iid, t, g in rows]
    rows = [r for r in rows if r[1].strip()]
    if len(rows) < FORMULA_MIN:
        return 0
    ends, heads = formula_counts([r[1] for r in rows])
    lim = max(FORMULA_MIN, int(FORMULA_SHARE * len(rows) + 0.999))
    bad_e = {w: n for w, n in ends.items() if n >= lim}
    bad_h = {h: n for h, n in heads.items() if n >= lim}
    if not bad_e and not bad_h:
        return 0
    n_hit = 0
    for iid, txt, gj in rows:
        mine = []
        for snt in _sentences(txt):
            ws = re.findall(r'[가-힣]+', snt)
            if ws and ws[-1] in bad_e and not ws[-1].endswith('까'):
                mine.append('틀 문구 반복 — 「…%s」 끝맺음이 이 작업 글의 %d%%(%d/%d)에 있습니다.'
                            % (ws[-1], 100 * bad_e[ws[-1]] // len(rows), bad_e[ws[-1]], len(rows)))
                break
        ws = re.findall(r'[가-힣]+', (txt or '')[:40])
        if len(ws) >= 3 and ' '.join(ws[:3]) in bad_h:
            h = ' '.join(ws[:3])
            mine.append('틀 문구 반복 — 첫머리 「%s…」가 이 작업 글의 %d%%(%d/%d)에 있습니다.'
                        % (h, 100 * bad_h[h] // len(rows), bad_h[h], len(rows)))
        if not mine:
            continue
        try:
            g = json.loads(gj) if gj else {}
        except Exception:                                 # noqa: BLE001
            g = {}
        old = [l for l in (g.get('lines') or []) if gate_rule_of(l) not in ('formula', 'pass')]
        g['lines'] = mine + old
        g['ok'] = False
        g = apply_gate_cfg(conn, j['asset_kind'], j['task'], g)
        conn.execute("UPDATE sys_ai_item SET gate_json=? WHERE item_id=?", (json.dumps(g, ensure_ascii=False), iid))
        n_hit += 1
    conn.commit()
    return n_hit



# ─────────────────────────────────────────────────────────────────────────────
# ★★★ 프롬프트 ↔ 게이트 일관성 (2026-10-13 · 사용자 「느닷없이 게이트를 들이대면 당연히 걸릴 수 밖에
#   없다 · 서로 일관성이 있는지도 잘 판단하라」)
# ─────────────────────────────────────────────────────────────────────────────
#: 규칙 → (프롬프트에 이 요구가 적혀 있다고 볼 낱말 정규식, 적혀 있지 않을 때 프롬프트에 넣을 한 줄)
#:   ⚠ 줄은 **게이트가 실제로 재는 것**을 사람 말로 옮긴 것이다 — 게이트를 바꾸면 여기도 바꾼다.
RULE_PROMPT = {
    'edit_quote': (r'인용 표시|「」|인용.*(유지|그대로|걷)', '성경 인용을 감싼 「」 표시를 걷어 내지 않는다.'),
    'edit_ref': (r'구절 표기|약명.*(유지|그대로)|창 ?1:1', '글에 적힌 구절 표기(창 1:1 따위)를 지우지 않는다.'),
    'edit_paren': (r'괄호', '글에 있던 괄호 설명을 지우지 않는다.'),
    'edit_name': (r'이름.*(지우|빼|그대로|유지)|사람·땅 이름', '글에 나온 사람·땅 이름을 빼지 않는다.'),
    'edit_shrink': (r'분량.*(줄|늘)|줄이기|깎', '분량을 크게 줄이지 않는다.'),
    'edit_blank': (r'빈 줄', '원문에 없던 빈 줄을 늘리지 않는다 — 문단 사이는 개행 하나.'),
    'edit_head': (r'머리줄|날짜 줄', '원문에 없던 머리줄·날짜 줄을 붙이지 않는다.'),
    'trans_paras': (r'문단.*(수|합치|나누)', '문단 수를 원문과 같게 둔다 — 합치거나 나누지 않는다.'),
    'trans_blank': (r'빈 줄', '빈 줄을 두 겹으로 띄우지 않는다.'),
    'untranslated': (r'써 넣을 언어|옮긴다|원문 글자', '모든 문단을 써 넣을 언어로 옮긴다 — 원문 글자를 남기지 않는다.'),
    'trans_lang': (r'써 넣을 언어', '「써 넣을 언어」로만 쓴다 — 출처 줄·머리까지 그 언어로.'),
    'trans_orig': (r'히브리|헬라|원어', '히브리·헬라 글자를 새로 적지 않는다 — 원어는 한글 음독으로만.'),
    'trans_ar_digits': (r'숫자', '숫자는 한 가지 꼴로만 쓴다(아랍어 글이면 아라비아 숫자와 서양 숫자를 섞지 않는다).'),
    'trans_markup': (r'마크다운|\*\*|머리말|서식', '마크다운(#·**)·「번역:」 같은 머리말을 붙이지 않는다.'),
    'echo': (r'되받아|재료.*(적지|옮기지)', '재료로 준 구절 본문·원문을 되받아 적지 않는다.'),
    'study_short': (r'적어도 \d+자|\d+자 이상|\d+자\s*[~∼]', '연구자료는 적어도 {min}자(한국어)로 쓴다.'),
    'study_orig': (r'음독', '원어 낱말은 「음독(원어)」 꼴로 적는다.'),
    'study_quote': (r'인용.*(역본|약명)|역본 약명', '인용 줄은 「역본 약명 장:절 본문」 꼴로 적는다.'),
    'study_num': (r'번호|기호', '제목·번호에 기호를 붙이지 않는다 — 번호는 1. 1) 꼴만.'),
    'struct_para': (r'문단', '다섯 문장이 넘으면 문단을 나눈다(개행 하나).'),
    'head': (r'첫머리|시작하기|「이 구절은', '같은 작업의 다른 글과 첫머리를 같게 시작하지 않는다(「이 구절은…」 따위).'),
    'names': (r'개역한글|바벨론|표기', '사람·땅 이름은 개역한글 표기를 따른다(바빌론이 아니라 바벨론).'),
    'vvd_reader': (r'부르는|여러분|적용', '읽는 사람을 부르지 않는다(당신·여러분의 삶) — 적용을 넣지 않는다.'),
    'style': (r'합니다체|대시|동그라미', '합니다체로 쓴다 · 대시(—)와 동그라미 번호를 쓰지 않는다.'),
    'title': (r'제목', '제목은 짧게 · 번호나 기호 없이.'),
    'ques': (r'물음표|합니까', '묵상질문은 물음표로 끝낸다(「…합니까?」).'),
    'bundle_split': (r'\[설명문\]|칸 표시|표식 줄', '칸마다 [설명문] 같은 표식 줄로 시작한다.'),
    'link_near': (r'같은 장', '같은 장 안의 절로 잇지 않는다.'),
    'link_ref': (r'약명 장:절|절 표기', '구절은 「약명 장:절」로 적는다(우리 약명).'),
    'link_form': (r'줄마다', '줄마다 「약명 장:절 · 갈래 · 왜」 꼴로 적는다.'),
    'link_rel': (r'갈래', '갈래는 열두 코드 가운데 하나만.'),
    'cite': (r'역본|성경 인용|인용', '성경을 인용할 때는 기준 역본의 글자 그대로 적는다.'),
    'length': (r'자\b|분량', ''),        # 분량은 [분량] 칸이 말한다
}
#: 규칙이 아니라 사정을 알리는 것 — 일관성 검사에서 뺀다
_RP_SKIP = ('pass', 'crash', 'summary', 'banned', 'formula', 'other', 'struct', 'vers_detail', 'length')


#: ★ 연구자료 하한 — 자산마다(게이트와 프롬프트가 **같은 값**을 쓴다). 묶음 = 사용자가 적은 「300자~1000자」.
STUDY_MIN = {'VERS_BUNDLE': 300, 'REF_STUDY': 400, 'REF_UNIT': 400}


#: 규칙이 **어느 자산에만** 뜻이 있나 — 게이트 열쇠 하나가 여러 규칙을 낳으므로 따로 좁힌다
_RULE_ONLY = {
    'bundle_split': lambda k: (AJ.ASSET.get(k) or {}).get('store') == 'BUNDLE',
    'title': lambda k: k in OURS_ONELINE,
    'ques': lambda k: k in ('VERS_QUES_LAY', 'VERS_BUNDLE'),
    'study_short': lambda k: k in ('REF_STUDY', 'REF_UNIT', 'VERS_BUNDLE'),
    'study_orig': lambda k: k in ('REF_STUDY', 'REF_UNIT', 'VERS_BUNDLE'),
    'study_quote': lambda k: k in ('REF_STUDY', 'REF_UNIT', 'VERS_BUNDLE'),
    'study_num': lambda k: k in ('REF_STUDY', 'REF_UNIT', 'VERS_BUNDLE'),
}


def rules_for(kind, task):
    """그 자산·업무에 걸리는 **규칙 열쇠** — `gates_for` 의 게이트를 규칙으로 편다."""
    gs = set(gates_for(kind, task))
    return [k for k, g, _n, _rx in GATE_RULES if g and g in gs and k not in _RP_SKIP
            and _RULE_ONLY.get(k, lambda _k: True)(kind)]


def prompt_gate_check(conn, kind, task, lang='KO', text=None):
    """**프롬프트 ↔ 게이트 일관성** — `[(규칙, 프롬프트가 말했나, 세기, 넣을 줄)]`.

    프롬프트가 말하지 않은 것을 게이트가 재면 AI 는 걸릴 수밖에 없다 — 그 자리를 찾는다.
    `text` = 실제로 보내는 글(안 주면 `compose_prompt` → `render_prompt` 로 짓는다).
    """
    if text is None:
        obj = AJ.compose_trace(conn, kind, '', task, lang, gate_lines=False)[0]
        text = AJ.render_prompt(obj, {})
    cfg = gate_cfg(conn, kind, task)
    out = []
    for r in rules_for(kind, task):
        rx, line = RULE_PROMPT.get(r, ('', ''))
        said = bool(rx and re.search(rx, text))
        line = line.replace('{min}', str(STUDY_MIN.get(kind, 400)))
        out.append((r, said, cfg.get(r, ''), line))
    return out


def gate_prompt_lines(conn, kind, task, lang='KO', text=None):
    """프롬프트가 말하지 않았는데 **게이트가 재는 것**을 프롬프트에 넣을 줄로 — 끈 규칙은 뺀다.
    `compose_trace` 가 「게이트 기준」 출처로 붙인다(조회 화면에 그대로 보인다)."""
    out = [line for r, said, mode, line in prompt_gate_check(conn, kind, task, lang, text)
           if not said and line and mode != 'OFF']
    # ★ 작업 전체를 보는 게이트 둘도 프롬프트가 먼저 말한다 — 틀 문구 반복 · 금지 문구(관리자 목록)
    cfg = gate_cfg(conn, kind, task)
    if (kind in FORMULA_KINDS and str(lang or 'KO').upper() == 'KO' and cfg.get('formula') != 'OFF'
            and not re.search(r'끝맺음.*되풀이|되풀이.*끝맺음', text or '')):
        out.append('같은 끝맺음·첫머리를 글마다 되풀이하지 않는다 — 한 작업의 글이 저마다 다른 문장으로 끝나게 쓴다.')
    ban = banned_phrases(conn, kind)
    if ban and cfg.get('banned') != 'OFF':
        out.append('다음 문구는 쓰지 않는다: %s' % ' · '.join('「%s」' % b for b in ban))
    return out

def gate_for_job(conn, j, slot_id, text, seen_heads=None, before=None):
    """작업 `j` 의 한 건을 **그 작업의 조건으로** 잰다 — 묶음/낱개 · 선택한 칸 ·
    기준 언어 · 앞글. `run_job` 과 `regate` 가 **같은 문**을 쓴다(295차) — 두 벌로
    적으면 「돌릴 때는 통과했는데 다시 재니 흠」이 난다.
    """
    if AJ.ASSET.get(j['asset_kind'], {}).get('store') == 'BUNDLE':
        res = gate_bundle(conn, slot_id, j['lang'], text,
                          task=j['task'], seen_heads=seen_heads,
                          before=before, want=(j.get('parts') or None))
    else:
        res = gate_item(conn, j['asset_kind'], slot_id, j['lang'], text,
                        task=j['task'], seen_heads=seen_heads,
                        before=before, base=j['base_lang'])
    # ★ 2026-10-30 한국어 사전은 「~다」체로 통일(적재된 이스턴 KO 278편 · 프롬프트 KO 층) — 「~니다」가 섞이면 걸린다
    if j['asset_kind'] == 'REF_DICT' and str(j['lang']).upper() == 'KO':
        _hn = len(re.findall(r'(?:니다|니까)[.?!]', text or ''))
        if _hn:
            res = dict(res)
            res['lines'] = ['사전 문체는 「~다」입니다 — 「~니다」 문장이 %d개 있습니다(다시 쓰기로 맞춥니다).' % _hn] + list(res.get('lines') or [])
            res['ok'] = False
    # ★ 2026-10-13 — 금지 문구(관리자 목록) · 관리자 설정(흠/참고/끔)을 마지막에 입힌다
    _bl = banned_lines(conn, j['asset_kind'], text)
    if _bl:
        res['lines'] = _bl + list(res.get('lines') or [])
        res['ok'] = False
    return apply_gate_cfg(conn, j['asset_kind'], j['task'], res)


def _before_of(conn, j, slot_id):
    """다듬기(EDIT) 건의 **앞글** — `run_job` 이 재료에서 집는 것과 같은 자리."""
    if str(j['task']).upper() != 'EDIT':
        return None
    try:
        ctx = AJ.material(conn, j['asset_kind'], slot_id, j['task'],
                          base=j['base_lang'], lang=j['lang'],
                          scope=j['scope_value'])
        # ★ 317차-19 — 재료도 고른 칸만(다듬기의 지금 글에 뺀 칸이 실리면 AI 가 그 칸을 다시 쓴다) · _ctx_filter
        if AJ.ASSET[j['asset_kind']].get('store') == 'BUNDLE':
            ctx = AJ.bundle_filter(ctx, j.get('parts') or None, lines=False)
    except Exception:                                     # noqa: BLE001
        return None
    for _k, _v in ctx.items():
        if _k.startswith('지금 글'):
            return _v
    return None


def regate(conn, job_id=None, dry=False):
    """검수 대기(DONE) 건의 `gate_json` 을 **지금 게이트**로 다시 잰다 — 글은 안 건드린다.

    ★★★ 295차 — 게이트를 고치거나 새로 세운 뒤 검수 줄이 **옛 판정**을 이고
      있으면 사람이 옛 흠을 보고 판정한다(실측 「검사가 터졌다(check_structure):
      SQLite objects created in a thread」 20건 — 294차 ④에서 고친 오류의 자국).
      받아 둔 글이 `out_text` 에 있으므로 API 없이 판정만 다시 한다.
    · DONE 만 — OK·LOADED·REJ 는 사람이 판정한 것이고 PENDING·FAIL 은 글이 없다.
    · `gate_for_job` 한 문 — `run_job` 과 같은 분기.
    · 첫머리 겹침은 **그 작업 안 앞선 건**과 견준다(돌릴 때와 같은 차례).
    반환 `{items, changed, ok_before, ok_after, jobs}`.
    """
    ensure(conn)
    q = ("SELECT i.item_id, i.job_id, i.slot_id, i.out_text, i.gate_json"
         "  FROM sys_ai_item i WHERE i.state='DONE'")
    ar = []
    if job_id:
        q += " AND i.job_id=?"
        ar.append(int(job_id))
    q += " ORDER BY i.job_id, i.item_id"
    rows = conn.execute(q, ar).fetchall()
    jobs_c, heads_c = {}, {}
    n_ch = ok0 = ok1 = 0
    for iid, jid, sid, txt, gj in rows:
        j = jobs_c.get(jid)
        if j is None:
            j = jobs_c[jid] = job(conn, jid)
        heads = heads_c.setdefault(jid, set())
        try:
            g_old = json.loads(gj) if gj else {}
        except Exception:                                 # noqa: BLE001
            g_old = {}
        txt = (txt or '').strip()
        g = gate_for_job(conn, j, sid, txt, heads,
                         before=_before_of(conn, j, sid))
        heads.add(head_of(txt))
        ok0 += 1 if g_old.get('ok') else 0
        ok1 += 1 if g.get('ok') else 0
        if json.dumps(g, ensure_ascii=False, sort_keys=True) != \
                json.dumps(g_old, ensure_ascii=False, sort_keys=True):
            n_ch += 1
            if not dry:
                conn.execute("UPDATE sys_ai_item SET gate_json=? WHERE item_id=?",
                             (json.dumps(g, ensure_ascii=False), iid))
    if not dry:
        conn.commit()
        for _jid in jobs_c:
            try:
                formula_pass(conn, _jid)     # ★ 2026-10-13
            except Exception:                             # noqa: BLE001
                pass
    return {'items': len(rows), 'changed': n_ch, 'ok_before': ok0,
            'ok_after': ok1, 'jobs': len(jobs_c)}


def overwrite_map(conn, j, slot_ids):
    """적재하면 **지금 글을 덮어쓰는** 칸 — `{자리: [칸 이름]}` (docs/1.txt 42-2 · 검수 목록 「덮어씀」 칸).

    · 묶음 = 고른 칸 가운데 지금 글이 있는 칸(「덧붙이기」로 고른 칸은 덮지 않으므로 뺀다)
    · 그 밖 = 그 자리 그 언어에 글이 있으면 「글」
    ⚠ 자리마다 조회하지 않는다 — 칸마다 한 번 묻고 자리로 거른다.
    """
    ids = {int(s) for s in slot_ids}
    out = {}
    if not ids or AJ.ASSET.get(j['asset_kind'], {}).get('store') == 'LINK':
        return out                     # 연결 자산은 「덮어쓰는 글」이 없다
    lang = str(j['lang']).upper()
    a = AJ.ASSET.get(j['asset_kind'], {})
    if a.get('store') == 'BUNDLE':
        add = add_modes(j)
        for k in AJ.bundle_keys(j.get('parts') or None):
            if k in add:
                continue
            p = AJ.BUNDLE_PART[k]
            if p.get('store') == 'REF':
                for (code,) in conn.execute(
                        "SELECT u.unit_code FROM sys_ref_unit u JOIN sys_ref_text t ON t.ref_unit_id=u.ref_unit_id"
                        " WHERE u.unit_code LIKE 'AIV%' AND UPPER(t.lang_code)=? AND t.record_status='LIVE'"
                        " AND TRIM(COALESCE(t.body_text,''))<>''", (lang,)):
                    try:
                        sid = int(code[3:9])
                    except ValueError:
                        continue
                    if sid in ids and len(code) == 9:
                        out.setdefault(sid, []).append(p['name'])
                continue
            q = ("SELECT DISTINCT clicked_id FROM sys_text_asset WHERE text_type=? AND UPPER(lang_code)=?"
                 " AND record_status='LIVE' AND TRIM(COALESCE(contents,''))<>''")
            ar = [p['text_type'], lang]
            if p['variant']:
                q += " AND text_variant=?"
                ar.append(p['variant'])
            for (sid,) in conn.execute(q, ar):
                if sid in ids:
                    out.setdefault(sid, []).append(p['name'])
        return out
    for sid in ids:
        try:
            if AJ.current_text(conn, j['asset_kind'], sid, lang):
                out[sid] = ['글']
        except Exception:                                 # noqa: BLE001
            pass
    return out


def _q_norm(s):
    """물음 줄 견주기 — 띄어쓰기·문장부호를 걷는다."""
    import re as _re
    return _re.sub(r'[\s\W_]+', '', s or '')


def study_append(old, new):
    """연구질문 **덧붙이기** — 같은 물음이 이미 있으면 그 블록은 안 붙인다(317차-19 · 42-2).

    블록 = 빈 줄로 나뉜 덩이 · 첫 줄이 물음. 옛 판정은 **글자가 통째로 같을 때만** 걸렀다 —
    같은 작업을 다시 돌리면 낱말 몇 개 다른 물음이 쌓였다. 물음 줄(띄어쓰기·부호 무시)로 견준다.
    반환 = 이어 붙인 글(붙일 것이 없으면 옛 글 그대로).
    """
    old = (old or '').rstrip()
    blocks = [b.strip() for b in (new or '').replace(chr(13), '').split(chr(10) * 2) if b.strip()]
    have = {_q_norm(b.split(chr(10))[0]) for b in old.replace(chr(13), '').split(chr(10) * 2) if b.strip()}
    add = [b for b in blocks if _q_norm(b.split(chr(10))[0]) not in have]
    if not old:
        return (chr(10) * 2).join(add)
    if not add:
        return old
    return old + chr(10) * 2 + (chr(10) * 2).join(add)


def slot_title(conn, kind, slot_id, label=''):
    """검수 「자리」 칸 — **무엇인지 알아볼 이름**(docs/1.txt 4-6)).

    · 구절 자리 = 약명 장:절 · 앞 글 조금 / · 도서·설교 본문 = 책 · 편 번호 · 편 제목
    · 자료집(연구자료 등) = **제목만** / · 그 밖 = 만들 때 적은 이름
    """
    a = AJ.ASSET.get(kind, {})
    sl = a.get('slot')
    try:
        if sl in ('VERSE',):
            ref = AJ._ref(conn, int(slot_id))
            return ('%s · %s' % (ref, (label or '')[:18])) if label and ref not in (label or '') else (ref or label)
        if sl == 'UNIT':
            r = conn.execute("SELECT a.book_code, u.sequence, u.unit_label FROM sys_book_unit u"
                             " JOIN sys_book_asset a ON a.book_id=u.book_id WHERE u.unit_id=?",
                             (int(slot_id),)).fetchone()
            if r:
                return '%s · 편 %s · %s' % (r[0], r[1], (r[2] or '')[:24])
        if sl == 'LINK':
            # ★ 317차-19 (docs/1.txt 42-4) — 구절연결 설명문은 **두 구절 약명 + 본문 앞부분**
            #   (그전에는 연결 번호가 그대로 보였다 — 자동으로 만든 작업은 이름이 번호였다)
            r = conn.execute("SELECT clicked_id, target_id FROM sys_link_asset WHERE sys_link_id=?",
                             (int(slot_id),)).fetchone()
            if r:
                def _one(v):
                    t = conn.execute("SELECT verse_text FROM bible_content WHERE verse_id=? AND version_code='KRV'",
                                     (v,)).fetchone()
                    t = ' '.join(((t[0] if t else '') or '').split())
                    return '%s 「%s」' % (AJ._ref(conn, int(v)), (t[:14] + '…') if len(t) > 14 else t)
                return '%s ↔ %s' % (_one(r[0]), _one(r[1])) if r[1] else _one(r[0])
        if sl == 'RUNIT' or sl in AJ.REF_SLOT_TYPE:
            r = conn.execute("SELECT COALESCE(NULLIF(TRIM(unit_label),''), unit_code) FROM sys_ref_unit"
                             " WHERE ref_unit_id=?", (int(slot_id),)).fetchone()
            if r:
                return r[0]
    except Exception:                                     # noqa: BLE001
        pass
    return label or str(slot_id)


#: 게이트 반영 다시 쓰기를 몇 번까지 AI 에게 맡기나 — 그 뒤는 사람이 본다
FIX_MAX = 2


def gate_failed(conn, job_id):
    """그 작업에서 **게이트에 걸린** 검수 대기 건 — `[item_id]`."""
    out = []
    for iid, gj in conn.execute("SELECT item_id, gate_json FROM sys_ai_item WHERE job_id=?"
                                " AND state='DONE'", (int(job_id),)):
        try:
            if gj and json.loads(gj).get('ok') is False:
                out.append(int(iid))
        except Exception:                                 # noqa: BLE001
            pass
    return out


def mark_fix(conn, item_ids):
    """선택한 건을 **게이트 반영 다시 쓰기**로 돌려놓는다 — 앞 글·걸린 줄을 적고 PENDING 으로.

    ★ 사용자 지시(docs/1.txt 「게이트 걸림」) — 걸린 것을 반려만 할 수 있고 고칠 길이 없었다.
    ⚠ `FIX_MAX` 번 고쳐도 걸리면 더 맡기지 않는다(사람이 본다) — 반환 `(맡김, 건너뜀)`.
    """
    ensure(conn)
    sent, skip = [], []
    for iid in item_ids:
        r = conn.execute("SELECT out_text, gate_json, COALESCE(fix_n,0), state FROM sys_ai_item"
                         " WHERE item_id=?", (int(iid),)).fetchone()
        if not r or not (r[0] or '').strip() or r[3] not in ('DONE', 'FAIL', 'REJ'):
            skip.append(iid)
            continue
        if int(r[2]) >= FIX_MAX:
            skip.append(iid)
            continue
        try:
            lines = [l for l in (json.loads(r[1]).get('lines') or []) if not _is_note(l)] if r[1] else []
        except Exception:                                 # noqa: BLE001
            lines = []
        conn.execute("UPDATE sys_ai_item SET state='PENDING', fix_note=?, fix_n=COALESCE(fix_n,0)+1"
                     " WHERE item_id=?",
                     (json.dumps({'prev': r[0], 'lines': lines}, ensure_ascii=False), int(iid)))
        sent.append(int(iid))
    conn.commit()
    return sent, skip


def _mark(conn, item_id, state, text=None, why=None, gate=None, tok=None):
    conn.execute(
        "UPDATE sys_ai_item SET state=?, out_text=COALESCE(?, out_text),"
        " why=?, gate_json=?, n_in=?, n_out=?, ran_at=? WHERE item_id=?",
        (state, text, why or '',
         json.dumps(gate, ensure_ascii=False) if gate else None,
         int((tok or {}).get('in', 0)), int((tok or {}).get('out', 0)),
         _now(), item_id))
    conn.commit()


def judge(conn, item_ids, state, text=None, why=None, keep=None):
    """사람 판정 — `OK`(승인) / `REJ`(반려). `text` 를 주면 **고쳐서 승인**.

    `why` = **반려 사유**(2026-09-29 294차 · 1.txt 1번 3)·4)). 예제 프롬프트와
    새 게이트의 재료가 여기서 쌓인다 — 실측 반려 16건 전부 사유가 비어 있어
    「무엇이 싫었나」를 되짚을 길이 없었다. `why` 칸(`sys_ai_item.why`)은
    실행기가 실패 까닭을 적는 칸과 같다 — 판정 뒤에는 사람 말이 그 자리를 잇는다.
    """
    assert state in ('OK', 'REJ'), state
    ensure(conn)
    n = 0
    for iid in item_ids:
        if state == 'OK':
            # ★ 2026-10-22 빈 글은 승인하지 않는다 — 실측 작업 613 이 글 없는 3건을 승인해 [적재]가 「0건」으로 끝났다
            cur = text if text is not None else (conn.execute(
                "SELECT out_text FROM sys_ai_item WHERE item_id=?", (iid,)).fetchone() or [''])[0]
            if not (cur or '').strip():
                continue
        n += 1
        if text is not None:
            conn.execute("UPDATE sys_ai_item SET out_text=? WHERE item_id=?",
                         (text, iid))
        if why is not None:
            conn.execute("UPDATE sys_ai_item SET why=? WHERE item_id=?",
                         ((why or '').strip(), iid))
        if keep is not None:
            conn.execute("UPDATE sys_ai_item SET keep_parts=? WHERE item_id=?",
                         (','.join(keep), iid))
        conn.execute("UPDATE sys_ai_item SET state=? WHERE item_id=?",
                     (state, iid))
    conn.commit()
    return n


def reject_reasons(conn, kind=None, limit=200):
    """사람이 적은 **반려 사유** — `[(자산, 업무, 언어, 사유, 받은 글 앞 80자)]`.

    ★ 예제 화면(1번 3))이 「AI 가 자주 틀리는 자리」를 보이는 재료다.
    """
    ensure(conn)
    q = ("SELECT j.asset_kind, j.task, j.lang, i.why, SUBSTR(i.out_text,1,80)"
         "  FROM sys_ai_item i JOIN sys_ai_job j ON j.job_id=i.job_id"
         " WHERE i.state='REJ' AND TRIM(COALESCE(i.why,''))<>''")
    ar = []
    if kind:
        q += " AND j.asset_kind=?"
        ar.append(kind)
    q += " ORDER BY i.item_id DESC LIMIT %d" % int(limit)
    return conn.execute(q, ar).fetchall()


# ══════════════════════════════════════════════════════════════════
#  적재 — **승인한 것만**
# ══════════════════════════════════════════════════════════════════

def load_ok(conn, job_id, dry=True):
    """승인(`OK`)한 건을 배포 DB 에 담는다.

    ⚠⚠ **`sys_text_asset` 자산만** 담는다 — 도서·주석·자료집은 저장 표가
      다르고 그쪽은 아직 이 문을 안 만들었다. **모르는 것을 담지 않는다.**
    ⚠ 멱등 — 같은 (자리, 유형, 언어, 변형) 이 이미 있으면 **덮는다**.
    ⚠ `dry=True` 면 세기만 한다.
    """
    ensure(conn)
    j = job(conn, job_id)
    assert j, '그런 작업이 없습니다: %s' % job_id
    a = AJ.ASSET[j['asset_kind']]
    if a['store'] == 'LINK':
        if AJ.is_link_review(j['asset_kind'], j.get('task')):
            # ★ 317차-20 — 해제분석은 **물리삭제**(사용자 확정) · 옛 연결기 다듬기는 HIDE 그대로
            return _load_link_review(conn, job_id, j, dry, delete=(j['asset_kind'] == 'VERS_UNLINK'))
        return _load_links(conn, job_id, j, dry)
    if a['store'] == 'BUNDLE':
        return _load_bundle(conn, job_id, j, dry)
    if a['store'] == 'BOOK':
        return _load_book(conn, job_id, j, dry)
    if a['store'] == 'BOOKA':
        return _load_book_intro(conn, job_id, j, dry)
    if a['store'] == 'REF':
        return _load_ref(conn, job_id, j, dry)
    if a['store'] == 'BTASTE':
        return _load_taste(conn, job_id, j, dry)
    if a['store'] == 'COMM':
        return _load_comm(conn, job_id, j, dry)
    if a['store'] != 'TEXT':
        return {'ok': False, 'why': '이 자산은 아직 적재 문이 없습니다(%s).'
                                    % a['store'], 'n': 0}
    rows = conn.execute(
        "SELECT item_id, slot_id, out_text FROM sys_ai_item "
        "WHERE job_id=? AND state='OK' AND TRIM(COALESCE(out_text,''))<>''",
        (job_id,)).fetchall()
    if dry:
        return {'ok': True, 'why': '', 'n': len(rows)}
    n = 0
    for iid, sid, txt in rows:
        q = ("DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type=? "
             "AND UPPER(lang_code)=?")
        args = [sid, a['text_type'], j['lang']]
        if a['variant']:
            q += " AND text_variant=?"
            args.append(a['variant'])
        conn.execute(q, args)
        conn.execute(
            "INSERT INTO sys_text_asset(clicked_id, text_type, contents,"
            " lang_code, text_variant, record_status, created_at) "
            "VALUES(?,?,?,?,?,'LIVE',?)",
            (sid, a['text_type'], txt, j['lang'], a['variant'], _now()))
        conn.execute("UPDATE sys_ai_item SET state='LOADED' WHERE item_id=?",
                     (iid,))
        n += 1
    conn.commit()
    return {'ok': True, 'why': '', 'n': n}


def _load_link_review(conn, job_id, j, dry=True, delete=False):
    """연결 점검 승인분 — **해제 = HIDE**(지우지 않는다 · note 에 까닭) · **바꿈 = 갈래만 고친다**.

    ★ 사람이 승인한 줄만 — 검수 칸에서 줄을 지우고 승인하면 그 줄은 손대지 않는다.
    ⚠ 바꿀 갈래의 짝이 이미 있으면(같은 쌍 · 같은 갈래) 옛 줄만 HIDE 한다(UNIQUE).
    ⚠ 판정이 「유지」인 줄과 판정이 없는 연결은 **그대로 둔다**.
    """
    rows = conn.execute(
        "SELECT item_id, slot_id, out_text FROM sys_ai_item "
        "WHERE job_id=? AND state='OK' AND TRIM(COALESCE(out_text,''))<>''",
        (job_id,)).fetchall()
    plan = []
    for iid, sid, txt in rows:
        have = _review_targets(conn, int(sid))
        for ref, tv, rel, verdict, new, why in AJ.link_review_parse(conn, txt):
            lid = have.get((tv, rel))
            if not lid or verdict not in ('해제', '바꿈'):
                continue
            if verdict == '바꿈' and (new not in AJ.REL_CODE_SET or new == rel):
                continue
            plan.append((lid, verdict, new, why))
    # ★ 317차-20 — 구속사연결(chain_code)에 든 연결은 **해제하지 않는다**(고리 한 칸이 끊긴다) — 그렇다고 말한다
    _chain = {lid for lid, v, _n, _w in plan if v == '해제' and (conn.execute(
        "SELECT COALESCE(chain_code,'') FROM sys_link_asset WHERE sys_link_id=?", (lid,)).fetchone() or [''])[0]}
    plan = [p for p in plan if p[0] not in _chain]
    n_off = sum(1 for x in plan if x[1] == '해제')
    n_chg = len(plan) - n_off
    msg = '%s %d · 갈래 바꿈 %d (건 %d)%s' % ('삭제' if delete else '해제', n_off, n_chg, len(rows),
                                         (' · 구속사연결에 든 %d개는 남김' % len(_chain)) if _chain else '')
    if dry:
        return {'ok': True, 'why': msg, 'n': len(plan), 'items': len(rows), 'desc_job': None}
    tag = 'AIREVIEW:%d' % int(job_id)
    for lid, verdict, new, why in plan:
        r = conn.execute("SELECT clicked_id, target_id, COALESCE(note,'') FROM sys_link_asset"
                         " WHERE sys_link_id=?", (lid,)).fetchone()
        if not r:
            continue
        note = (r[2] + (' ' if r[2] else '') + '[%s %s] %s' % (tag, verdict, why)).strip()
        if verdict == '해제':
            if delete:
                # ★ 물리삭제 — 연결설명문도 함께(주인 없는 글이 남지 않게) · 감사 로그가 지운 줄을 남긴다
                conn.execute("DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type='VERS_VERS_DESC'", (lid,))
                conn.execute("DELETE FROM sys_link_asset WHERE sys_link_id=?", (lid,))
            else:
                conn.execute("UPDATE sys_link_asset SET record_status='HIDE', note=? WHERE sys_link_id=?",
                             (note, lid))
            continue
        dupe = conn.execute("SELECT sys_link_id FROM sys_link_asset WHERE link_type='VERS_VERS'"
                            " AND clicked_id=? AND target_id=? AND rel_code=?",
                            (r[0], r[1], new)).fetchone()
        if dupe:
            conn.execute("UPDATE sys_link_asset SET record_status='HIDE', note=? WHERE sys_link_id=?",
                         (note, lid))
        else:
            conn.execute("UPDATE sys_link_asset SET rel_code=?, note=? WHERE sys_link_id=?",
                         (new, note, lid))
    for iid, _s, _t in rows:
        conn.execute("UPDATE sys_ai_item SET state='LOADED' WHERE item_id=?", (iid,))
    conn.commit()
    return {'ok': True, 'why': msg + (' — 지웠습니다(연결설명문 함께 · 감사 로그에 남습니다).' if delete
                                      else ' — 담았습니다(해제는 HIDE · 되돌리려면 LIVE 로).'),
            'n': len(plan), 'items': len(rows), 'desc_job': None}


def _load_links(conn, job_id, j, dry=True):
    """구절 연결기 승인분을 `sys_link_asset`(VERS_VERS) 에 담는다(297차).

    · `clicked_id < target_id` 로 정렬해 담는다(§28-7 트리거) · 갈래는 그대로 ·
      `source='AILINK:<작업>'` · `confidence='AI'` · `note`=왜 잇는가.
    · 같은 (짝, 갈래) 가 이미 있으면 **건너뛴다**(UNIQUE) — 사람이 이은 것을 안 덮는다.
    · ★★★ 담은 뒤 **연결설명문 작업**(VERS_VERS_DESC · 새 링크만)을 저절로 만든다 —
      사용자 「구절연결 설명문도 자동작성」. 보내는 것은 사람이 [돌리기]로(한도).
    반환 `{ok, why, n(담은 링크), items, desc_job}`.
    """
    rows = conn.execute(
        "SELECT item_id, slot_id, out_text FROM sys_ai_item "
        "WHERE job_id=? AND state='OK' AND TRIM(COALESCE(out_text,''))<>''",
        (job_id,)).fetchall()
    plan = []
    for iid, sid, txt in rows:
        for ref, tv, rel, why, _raw in AJ.link_lines_parse(conn, txt):
            if tv is None or tv == sid or rel not in AJ.REL_CODE_SET:
                continue
            plan.append((iid, int(sid), int(tv), rel, (why or '').strip()))
    if dry:
        return {'ok': True, 'why': '링크 %d개(건 %d)' % (len(plan), len(rows)),
                'n': len(plan), 'items': len(rows), 'desc_job': None}
    new_ids, n = [], 0
    src = 'AILINK:%d' % int(job_id)
    for iid, sid, tv, rel, why in plan:
        a_, b_ = sorted((sid, tv))
        cur = conn.execute(
            "INSERT OR IGNORE INTO sys_link_asset(clicked_id, target_id, link_type, rel_code,"
            " record_status, source, confidence, note) VALUES(?,?,'VERS_VERS',?,'LIVE',?,?,?)",
            (a_, b_, rel, src, 'AI', why))
        if cur.rowcount:
            n += 1
            new_ids.append(int(cur.lastrowid))
    for iid, _s, _t in rows:
        conn.execute("UPDATE sys_ai_item SET state='LOADED' WHERE item_id=?", (iid,))
    desc_job = None
    if new_ids and 'LINKDESC' in add_modes(j):
        # ★ 317차-5 — 연결과 함께 받은 설명을 **그대로 연결설명문으로** 담는다(따로 작업 없음)
        _why = {}
        for iid, sid, tv, rel, why in plan:
            _why[tuple(sorted((sid, tv))) + (rel,)] = why
        for lid in new_ids:
            r = conn.execute("SELECT clicked_id, target_id, rel_code FROM sys_link_asset WHERE sys_link_id=?",
                             (lid,)).fetchone()
            w = _why.get((r[0], r[1], r[2])) if r else ''
            if w:
                conn.execute("INSERT INTO sys_text_asset(clicked_id, text_type, contents, lang_code,"
                             " text_variant, record_status, created_at) VALUES(?,'VERS_VERS_DESC',?,'KO',NULL,'LIVE',?)",
                             (lid, w, _now()))
        conn.commit()
        return {'ok': True, 'why': '링크 %d개와 연결설명문을 함께 담았습니다(겹쳐 건너뛴 %d).' % (n, len(plan) - n),
                'n': n, 'items': len(rows), 'desc_job': None}
    # ★ 2026-10-11 — `NODESC` 작업은 연결설명문 작업을 만들지 않는다(사용자 「연결설명문은 제외하라」).
    if new_ids and 'NODESC' not in add_modes(j):
        try:
            desc_job, _k = create_job(conn, 'VERS_VERS_DESC', '', 'NEW', 'KO', new_ids,
                                      base='KO', name='구절연결 설명문 · 연결기 #%d 의 새 링크 %d개'
                                      % (int(job_id), len(new_ids)))
        except Exception as e:                            # noqa: BLE001
            desc_job = None
            why_fail = str(e)
        else:
            why_fail = ''
    else:
        why_fail = ''
    conn.commit()
    why = '링크 %d개를 담았습니다(겹쳐 건너뛴 %d).' % (n, len(plan) - n)
    if desc_job:
        why += ' 연결설명문 작업 #%d 을 만들었습니다 — 「승인 및 검수」에서 [돌리기].' % desc_job
    elif why_fail:
        why += ' (연결설명문 작업은 못 만들었습니다: %s)' % why_fail
    return {'ok': True, 'why': why, 'n': n, 'items': len(rows), 'desc_job': desc_job}


def _load_taste(conn, job_id, j, dry=True):
    """맛보기 조각 번역을 `sys_book_taste` 에 담는다 (2026-09-25).

    ⚠⚠⚠ **`sys_book_unit_text` 에 안 담는다** — 담으면 읽기 화면의 변형
      콤보에 **잘린 글이 정식 번역인 척** 오르고, 본문팩(BOOK)이 그것을 그
      책의 번역본으로 실어 보낸다. 사용자 앱으로는 코어팩이 **음수 열쇠**로
      실어 나른다(`db_pack_taste.taste_tables`).
    ⚠ 상한을 넘으면 **담을 때 자른다**(`put_taste`) — A4 한 장 규칙은 한 곳이다.
    ⚠ 멱등 — 같은 `(유닛, 언어)` 는 덮는다.
    """
    import db_pack_taste as _T
    lang = (j['lang'] or '').upper()
    rows = conn.execute(
        "SELECT item_id, slot_id, out_text FROM sys_ai_item "
        "WHERE job_id=? AND state='OK' AND TRIM(COALESCE(out_text,''))<>''",
        (job_id,)).fetchall()
    if dry:
        return {'ok': True, 'why': '', 'n': len(rows)}
    _T.ensure(conn)
    n = 0
    for iid, sid, txt in rows:
        _T.put_taste(conn, sid, lang, txt)
        conn.execute("UPDATE sys_ai_item SET state='LOADED' WHERE item_id=?",
                     (iid,))
        n += 1
    conn.commit()
    return {'ok': True, 'why': '', 'n': n}


def _load_ref(conn, job_id, j, dry):
    """자료집 글(문답·사전·주제 색인·연구 자료)을 `sys_ref_text` 에 담는다.

    ★★★ **번역·다듬기 경로의 종착지**(2026-09-25) — 그전에는 작업을 만들고
      승인까지 해도 「이 자산은 아직 적재 문이 없습니다」로 끝났다. 자료집을
      갈래로 나눈 값이 여기서 난다 — 갈래마다 기준 언어가 정해지므로
      **무엇을 어느 언어 칸에 담을지가 자산 줄로 결정된다.**
    ⚠ 변형은 **`ORIGINAL`** 로 고정한다 — 실측 `sys_ref_text` 의 전 자료집이
      그 값이고(사전의 `MODERN_EN` 289행만 예외), 읽는 쪽이 그것을 먼저
      본다(`p4_ref_view`). 여기서 새 변형을 만들면 화면에 안 뜬다.
    ⚠ **원문 언어 칸은 안 건드린다** — 하이델베르크의 `unit_answer` 는 저자의
      영어 원문이다. 번역은 언제나 `sys_ref_text` 의 **새 언어 행**이다.
    ⚠ **제목** — 연구 자료는 첫 줄이 제목이라는 규약이 있다
      (`db_study_gate`). 그 밖의 자료집은 유닛 이름을 그대로 쓴다.
    ⚠ 멱등 — 같은 `(유닛, ORIGINAL, 언어)` 가 있으면 덮는다.
    """
    lang = (j['lang'] or '').upper()
    study = (j['asset_kind'] == 'REF_STUDY')
    rows = conn.execute(
        "SELECT item_id, slot_id, out_text FROM sys_ai_item "
        "WHERE job_id=? AND state='OK' AND TRIM(COALESCE(out_text,''))<>''",
        (job_id,)).fetchall()
    # ★ docs/2.txt 8번(2026-10-23) — **원문 언어 칸은 덮지 않는다**. 이 문은 (유닛, ORIGINAL, 언어) 행을
    #   지우고 다시 넣으므로, 작업 언어가 그 자료집의 원문 언어와 같으면 저자의 글이 AI 글로 바뀐다.
    #   만들 때 막지만(`edit_blocked`) 옛 작업·밖에서 만든 작업도 있으니 여기서 한 번 더 막는다(우리 글은 예외).
    _orig = []
    if not study:
        for _iid, _sid, _t in rows:
            _r = conn.execute("SELECT UPPER(COALESCE(s.lang_code,'')) FROM sys_ref_unit u "
                              "JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id WHERE u.ref_unit_id=?",
                              (_sid,)).fetchone()
            if _r and _r[0] == lang:
                _orig.append(_sid)
    if _orig:
        return {'ok': False, 'n': 0,
                'why': '원문 언어(%s) 칸은 적재하지 않습니다 — 저자의 글입니다(자리 %d개: %s)'
                       % (lang, len(_orig), _orig[:5])}
    if dry:
        return {'ok': True, 'why': '', 'n': len(rows)}
    n, skip = 0, []
    for iid, sid, txt in rows:
        # ★ 317차-18 ⑦ — 칸 번호 목록을 떼어 내 그 언어 칸으로 담는다(본문엔 자리표만)
        _ans = {}
        try:
            import ref_doc as _RD
            txt, _ans = _RD.split_cells(txt)
        except Exception:                                 # noqa: BLE001
            pass
        body, title = (txt or '').strip(), None
        if study:
            try:
                import db_study_gate as SG
                title, body = SG.title_of(txt), SG.body_of(txt)
            except Exception:                             # noqa: BLE001
                title, body = None, (txt or '').strip()
            if not (title and body):
                skip.append(sid)
                continue
        if not title:
            r = conn.execute("SELECT unit_label FROM sys_ref_unit "
                             "WHERE ref_unit_id=?", (sid,)).fetchone()
            title = (r[0] if r else '') or None
        conn.execute("DELETE FROM sys_ref_text WHERE ref_unit_id=? "
                     "AND UPPER(lang_code)=? AND text_variant='ORIGINAL'",
                     (sid, lang))
        conn.execute(
            "INSERT INTO sys_ref_text(ref_unit_id, text_variant, lang_code,"
            " body_text, title, record_status) VALUES(?,'ORIGINAL',?,?,?,'LIVE')",
            (sid, lang, body, title))
        if _ans:
            try:
                import ref_doc as _RD
                _st = _RD.get_tables(conn, 'SYS', sid, lang, fallback=())
                for _no, _a in _ans.items():
                    if _no in _st:
                        _RD.put_table(conn, 'SYS', sid, _no, _RD.fill_cells(_st[_no], _a), lang, commit=False)
            except Exception as e:                        # noqa: BLE001
                print('[_load_ref tables] %s' % e)
        conn.execute("UPDATE sys_ai_item SET state='LOADED' WHERE item_id=?",
                     (iid,))
        n += 1
    conn.commit()
    why = ('제목이나 본문이 없어 건너뛴 글 %d개: %s' % (len(skip), skip[:5])
           if skip else '')
    return {'ok': not skip, 'why': why, 'n': n}


def _load_book_intro(conn, job_id, j, dry=True):
    """도서 소개문을 `sys_book_asset_text` 에 담는다 (1.txt 16-3 ⑤).

    ⚠ 그 표는 한 책·한 언어에 **한 행**이고 제목·저자도 함께 산다 —
      행이 이미 있으면 **소개문 칸만 고친다**(제목을 지우지 않는다).
    ⚠ 멱등 — 같은 `(book_id, 언어)` 를 두 번 담아도 한 행이다.
    """
    lang = (j['lang'] or '').upper()
    rows = conn.execute(
        "SELECT item_id, slot_id, out_text FROM sys_ai_item "
        "WHERE job_id=? AND state='OK' AND TRIM(COALESCE(out_text,''))<>''",
        (job_id,)).fetchall()
    if dry:
        return {'ok': True, 'why': '', 'n': len(rows)}
    n = 0
    for iid, sid, txt in rows:
        got = conn.execute(
            "SELECT text_id FROM sys_book_asset_text WHERE book_id=?"
            "  AND UPPER(lang_code)=?", (sid, lang)).fetchone()
        if got:
            conn.execute(
                "UPDATE sys_book_asset_text SET description=?,"
                " record_status='LIVE' WHERE text_id=?",
                (txt, got[0]))
        else:
            conn.execute(
                "INSERT INTO sys_book_asset_text(book_id, lang_code,"
                " description, record_status) VALUES(?,?,?,'LIVE')",
                (sid, lang, txt))
        conn.execute("UPDATE sys_ai_item SET state='LOADED' WHERE item_id=?",
                     (iid,))
        n += 1
    conn.commit()
    # ★ **담았다고 믿지 말고 도로 읽는다**(`_load_book` 과 같은 규칙).
    miss = [sid for _i, sid, _t in rows if not conn.execute(
        "SELECT 1 FROM sys_book_asset_text WHERE book_id=?"
        "  AND UPPER(lang_code)=? AND TRIM(COALESCE(description,''))<>''",
        (sid, lang)).fetchone()]
    return {'ok': not miss, 'n': n,
            'why': ('안 담긴 책 %d권: %s' % (len(miss), miss[:5]))
                   if miss else ''}


def _load_comm(conn, job_id, j, dry=True):
    """주석 본문을 `sys_commentary_text` 에 담는다 (docs/1.txt 13 · 2026-10-20).

    ⚠⚠ **이 문이 없어서 승인한 주석 번역이 「적재 문이 없습니다」로 끝났다** —
      사용자 신고 「주석 등 적재기능이 작동하지 않는 것이 있음」(실측 작업 11개 ·
      승인 383건이 대기).
    ★ 변형 = 도서와 같은 규칙(`book_variant_for`) — 영어로 낸 글은 `MODERN_EN`,
      그 밖은 `TRANSLATED`. **원문(`ORIGINAL`)은 건드리지 않는다**(저자의 글).
    ⚠ 멱등 — 같은 `(entry_id, 변형, 언어)` 가 있으면 덮는다.
    ⚠ 주석 항목이 없는 자리는 건너뛰고 까닭을 적는다.
    """
    lang = (j['lang'] or '').upper()
    var = AJ.book_variant_for(lang, j.get('base_lang') or 'EN')
    rows = conn.execute(
        "SELECT item_id, slot_id, out_text FROM sys_ai_item "
        "WHERE job_id=? AND state='OK' AND TRIM(COALESCE(out_text,''))<>''",
        (job_id,)).fetchall()
    if dry:
        return {'ok': True, 'why': '', 'n': len(rows)}
    n = 0
    skip = []
    for iid, sid, txt in rows:
        if not conn.execute("SELECT 1 FROM sys_commentary_entry WHERE entry_id=?",
                            (sid,)).fetchone():
            skip.append(sid)
            continue
        conn.execute(
            "DELETE FROM sys_commentary_text WHERE entry_id=? AND text_variant=?"
            "  AND UPPER(lang_code)=?", (sid, var, lang))
        conn.execute(
            "INSERT INTO sys_commentary_text(entry_id, text_variant, lang_code,"
            " body_text, record_status) VALUES(?,?,?,?,'LIVE')",
            (sid, var, lang, (txt or '').strip()))
        conn.execute("UPDATE sys_ai_item SET state='LOADED' WHERE item_id=?",
                     (iid,))
        n += 1
    conn.commit()
    why = ('주석 항목을 못 찾아 건너뛴 자리 %d개: %s' % (len(skip), skip[:5])) if skip else ''
    return {'ok': True, 'why': why, 'n': n}


def _load_book(conn, job_id, j, dry=True):
    """도서·설교 본문을 `sys_book_unit_text` 에 담는다 (1.txt 16-2 ⓑ).

    ⚠⚠⚠ **이 문이 없어서 승인한 글이 어디에도 실리지 않았다** — 사용자 신고
      「맥라렌 : 이미 번역하고 승인완료했는데 또 다시 번역대상으로 표시된다」.
      `load_ok` 가 `sys_text_asset` 만 담아, 도서는 승인해도 DB 에 안 들어가고
      다음 번에 또 「번역 안 된 자리」 로 세어졌다(실측 16편이 떠 있었다).
    ★★★ **출처 줄을 도구가 붙인다** — AI 가 낸 줄은 떼고 `db_book_attrib` 의
      한 꼴로 갈아 끼운다. 그래야 한 책 안에서 안 흔들린다(16-2 ⓐ).
    ★ 변형은 **`TRANSLATED`** 로 고정한다 — `MODERN_EN` 은 각 적재 도구의
      `--modern` 이 맡는 별개의 길이고, 여기서 만들면 두 문이 같은 칸을 다툰다.
    ⚠ 멱등 — 같은 `(unit_id, 변형, 언어)` 가 있으면 덮는다.
    ⚠ **책을 못 찾으면 건너뛰고 까닭을 적는다** — 출처를 못 대는 글은 안 담는다.
    """
    import db_book_attrib as BA
    lang = (j['lang'] or '').upper()
    # ★ 1.txt 1번 8) — 영어로 낸 글은 **현대 영어(MODERN_EN)** 칸에 담는다.
    #   원문이 영어인 책의 「영어 번역」은 없다 — 있는 것은 옛말투를 오늘
    #   말로 고친 판이고 그 칸은 `--modern` 도구와 같은 `MODERN_EN` 이다.
    var = AJ.book_variant_for(lang, j.get('base_lang') or 'EN')
    rows = conn.execute(
        "SELECT item_id, slot_id, out_text FROM sys_ai_item "
        "WHERE job_id=? AND state='OK' AND TRIM(COALESCE(out_text,''))<>''",
        (job_id,)).fetchall()
    if dry:
        return {'ok': True, 'why': '', 'n': len(rows)}
    n = 0
    skip = []
    for iid, sid, txt in rows:
        line = BA.book_attrib_for(conn, sid, var, lang)
        if line is None:
            skip.append(sid)
            continue
        text = BA.compose(BA.strip_attrib(txt or ''), line)
        conn.execute(
            "DELETE FROM sys_book_unit_text WHERE unit_id=? AND text_variant=?"
            "  AND UPPER(lang_code)=?", (sid, var, lang))
        conn.execute(
            "INSERT INTO sys_book_unit_text(unit_id, text_variant, lang_code,"
            " body_text, record_status) VALUES(?,?,?,?,'LIVE')",
            (sid, var, lang, text))
        conn.execute("UPDATE sys_ai_item SET state='LOADED' WHERE item_id=?",
                     (iid,))
        n += 1
    conn.commit()
    # ★★★ **붙였다고 믿지 말고 센다**(2026-09-24 사용자 신고 「맨 아랫줄에
    #   책이름 한줄이 기록되지 않았다」). 담는 문과 세는 문이 갈리면 어느
    #   것도 못 믿는다 — 담은 그 행을 도로 읽어 출처 줄로 끝나는지 본다.
    miss = []
    for iid, sid, _t in rows:
        line = BA.book_attrib_for(conn, sid, var, lang)
        if line is None:
            continue
        g = conn.execute(
            "SELECT body_text FROM sys_book_unit_text WHERE unit_id=?"
            "  AND text_variant=? AND UPPER(lang_code)=?",
            (sid, var, lang)).fetchone()
        if not g or not (g[0] or '').rstrip().endswith(line):
            miss.append(sid)
    why = []
    if skip:
        why.append('책을 못 찾아 건너뛴 유닛 %d개: %s' % (len(skip), skip[:5]))
    if miss:
        why.append('출처 줄이 안 붙은 유닛 %d개: %s' % (len(miss), miss[:5]))
    return {'ok': not miss, 'why': ' / '.join(why), 'n': n,
            'attrib': n - len(miss)}


STUDY_SRC = 'STUDY_NOTES'         # `sys_ref_source.src_code`


def _is_study_unit(conn, unit_id):
    """그 자료집 글이 **연구자료**인가.

    ⚠ `sys_ref_unit` 한 표에 문답·주제색인·사전·연구자료가 함께 들어 있다
      (§0-5 — 자산 한 줄로 못 가른다). **서식 잣대도 그렇다** — 수입
      저작물에 우리 서식을 대면 남의 글을 흠으로 신고한다.
    """
    try:
        return bool(conn.execute(
            "SELECT 1 FROM sys_ref_unit u JOIN sys_ref_source s "
            "  ON s.ref_src_id = u.ref_src_id "
            " WHERE u.ref_unit_id=? AND s.src_code=?",
            (unit_id, STUDY_SRC)).fetchone())
    except Exception:                                     # noqa: BLE001
        return False
STUDY_CODE = 'AIV%06d'            # 절 하나에 연구자료 하나 — 멱등 열쇠


def _study_src_id(conn):
    r = conn.execute("SELECT ref_src_id FROM sys_ref_source WHERE src_code=?",
                     (STUDY_SRC,)).fetchone()
    return r and r[0]


def study_terms(conn, text, min_len=3):
    """글이 **실제로 다루는** 주요용어 — `[(entity_id, 이름, 까닭)]`.

    ★★★ 사용자 물음(1.txt 16-1 · 5) — 「AI는 우리가 관리하는 주요용어를
      알지 못한다. **주요용어 연결은 네가 직접 해야 하는가?**」
      ⇒ **기계가 후보를 올리고 사람이 승인한다.** AI 에게 용어 목록을
        주지 않는다 — 수백 개를 프롬프트에 실으면 그 낱말을 쓰려고 글이
        휜다(§195차 「엘」 사건과 같은 방향의 위험이다).

    ⚠⚠⚠ **「본문 어딘가에 나온다」는 잣대가 아니다** — 첫 판이 그렇게 재어
      「하나님」이 걸렸다(실측). 연구자료마다 붙을 이름이고, 그렇게 붙은
      연결은 아무 말도 하지 않는다. CLAUDE.md §256차 ⑳ 의 실측이 같은
      것을 말한다 — **제목 근거는 99% 살아남고 설명문 근거는 0.3%** 다.
    ⇒ 잣대 **둘 중 하나**라야 한다:
      ① 이름이 **제목**에 있다 — 그 글의 주제다
      ② 글이 그 용어의 **원어를 음독(원어) 꼴로 다룬다** — 사용자가 정해 준
        서식(4번)이 여기서 값을 한다. 원어를 짚어 설명했다면 주제어다.
    ⚠ 두 글자 이름은 어느 잣대로도 안 건다(「에서」는 조사 · 「아이」는
      보통명사 · 「엘」은 어디에나 있다 — 실측 4,878건이 그래서 잘못 걸렸다).
    ⚠ **기계 낱말**(스트롱 승격 전)은 뺀다 — 사람이 지은 이름이 아니다.
    """
    import db_study_gate as SG
    t = text or ''
    title = SG.title_of(t)
    # 글이 음독(원어) 꼴로 다룬 음역 — 괄호 앞 한글 덩이
    trs = set()
    for m in SG.OK_ORIG.finditer(t):
        seg = m.group(0)
        head = seg.split('(')[0].strip()
        if len(head) >= 2:
            trs.add(head)

    out, seen = [], set()
    rows = conn.execute(
        "SELECT e.entity_id, a.contents FROM sys_entity_master e "
        "JOIN sys_text_asset a ON a.clicked_id=e.entity_id "
        "  AND a.text_type='ENTITY_NAME' AND UPPER(a.lang_code)='KO' "
        "  AND a.record_status='LIVE' "
        "WHERE e.record_status='LIVE' "
        "  AND COALESCE(e.json_detail,'') NOT LIKE '%subtype%LEX%'"
    ).fetchall()
    for eid, nm in rows:
        if eid in seen:
            continue
        # 이름이 「본딧말 · 음역」 꼴이면 두 조각을 다 본다
        bits = [x.strip() for x in (nm or '').split('\u00b7')]
        head = bits[0] if bits else ''
        why = ''
        if len(head) >= min_len and head in title:
            why = '제목'
        elif any(b in trs for b in bits if len(b) >= 2):
            why = '원어'
        if why:
            seen.add(eid)
            out.append((eid, head, why))
    return out


def put_study_note(conn, vid, lang, body, append=False):
    """연구자료 한 편을 담는다 — 유닛 · 본문 · **구절 연결 자동 승인**.

    ★★★ 사용자 지시(1.txt 16-1 · 5) — 「연구자료 승인하면서 **구절연결까지
      자동으로 승인**되어야 한다」. 그래서 절 연결은 `LIVE` 로 바로 넣는다.
      ⇒ 걸리는 절 = **이 묶음의 절** + **글 안에서 인용한 절 전부**.
        인용 서식을 한 꼴로 못 박은 값이 여기서 난다(`db_study_gate.cites`).
    ★ **용어는 후보(`PEND`)로만** 올린다 — 이름이 같다고 그 용어인 것은
      아니다(§195차). 사람이 관리자 화면에서 승인한다.
    ⚠ **멱등** — 열쇠는 `unit_code = AIV<절번호>` 다. 다시 돌리면 그 유닛의
      그 언어 본문만 갈아 끼운다(사람이 쓴 43편은 열쇠가 달라 안 건드린다).
    ⚠ **첫 줄이 제목**이다(`db_study_gate` 규약). 제목이 없으면 안 담는다 —
      이름 없는 글은 목록에서 못 찾는다.
    """
    import db_study_gate as SG
    src = _study_src_id(conn)
    if not src:
        return None, '연구 자료 자료집(STUDY_NOTES)이 없습니다.'
    title = SG.title_of(body)
    text = SG.body_of(body)
    if not title or not text:
        return None, '제목이나 본문이 없습니다.'
    lang = (lang or 'KO').upper()
    code = STUDY_CODE % int(vid)
    r = conn.execute("SELECT ref_unit_id FROM sys_ref_unit "
                     "WHERE ref_src_id=? AND unit_code=?", (src, code)).fetchone()
    _base_lbl = (conn.execute("SELECT unit_label FROM sys_ref_unit WHERE ref_unit_id=?", (r[0],)).fetchone()
                 or [''])[0] if r else ''
    if append and r and (_base_lbl or '').strip() != title:
        # ★ 317차-5 — **기존 연구자료를 두고 한 편 더**(docs/1.txt 4-2)) — `AIV<절>-2`, `-3` …
        #   같은 제목의 편이 이미 있으면 그 편을 갈아 끼운다(같은 작업을 두 번 적재해도 안 늘어난다).
        n = 2
        while True:
            c2 = '%s-%d' % (code, n)
            r2 = conn.execute("SELECT ref_unit_id, unit_label FROM sys_ref_unit WHERE ref_src_id=?"
                              " AND unit_code=?", (src, c2)).fetchone()
            if not r2 or (r2[1] or '').strip() == title:
                code, r = c2, (r2[:1] if r2 else None)
                break
            n += 1

    try:
        import db_chap_prep as _CP
        sec = _CP._ABBR.get(int(conn.execute(
            "SELECT bcode FROM bible_index WHERE verse_id=?",
            (vid,)).fetchone()[0]))
    except Exception:                                     # noqa: BLE001
        sec = None
    if r:
        uid = r[0]
        conn.execute("UPDATE sys_ref_unit SET unit_label=?, section_code=?, "
                     "record_status='LIVE' WHERE ref_unit_id=?",
                     (title, sec, uid))
    else:
        seq = (conn.execute("SELECT COALESCE(MAX(sequence),0) FROM sys_ref_unit "
                            "WHERE ref_src_id=?", (src,)).fetchone()[0] or 0) + 10
        conn.execute(
            "INSERT INTO sys_ref_unit(ref_src_id, unit_code, sequence, "
            " unit_type, unit_label, section_code, record_status) "
            "VALUES(?,?,?,'ARTICLE',?,?,'LIVE')", (src, code, seq, title, sec))
        uid = conn.execute("SELECT ref_unit_id FROM sys_ref_unit "
                           "WHERE ref_src_id=? AND unit_code=?",
                           (src, code)).fetchone()[0]

    # ★ 317차-18 ⑥ — AI 가 쓴 표(`|`·격자)는 구조로 담고 본문엔 자리표만(ref_doc)
    _tbls = {}
    try:
        import ref_doc as _RD
        text, _tbls = _RD.absorb(text)
    except Exception:                                     # noqa: BLE001
        pass
    conn.execute("DELETE FROM sys_ref_text WHERE ref_unit_id=? "
                 "AND UPPER(lang_code)=? AND text_variant='ORIGINAL'",
                 (uid, lang))
    conn.execute(
        "INSERT INTO sys_ref_text(ref_unit_id, text_variant, lang_code, "
        " body_text, title, record_status) VALUES(?,'ORIGINAL',?,?,?,'LIVE')",
        (uid, lang, text, title))
    try:
        import ref_doc as _RD
        _RD.sync_all(conn, 'SYS', uid, _tbls, lang, commit=False)
    except Exception as e:                                # noqa: BLE001
        print('[put_study_note tables] %s' % e)

    # ── 구절 연결 — **자동 승인**(사용자 지시) ──────────────────────
    #   ⚠⚠⚠ **내가 넣은 것만 다시 깐다**(314차) — 그전에는 `clicked_id` 전체를
    #     지워, 사람이 그 글에 손으로 이은 구절이 다음 적재에서 **사라졌다**.
    #     실측 지금은 전부 `AI_STUDY` 라 드러나지 않았지만 열려 있던 구멍이다.
    conn.execute("DELETE FROM sys_link_asset WHERE link_type='REFU_VERS' "
                 "AND clicked_id=? AND COALESCE(source,'')='AI_STUDY'", (uid,))
    vids, seen = [(int(vid), int(vid))], {int(vid)}
    try:
        # ★★★ 314차 — **다국어 단일 소스로 갈아탔다**(`scripture_ref`).
        #   그전에는 `scripture_ref_kr`(한국어 전용) + `cites()`(서식 줄만)라
        #   ⓐ 다른 언어 글에서 **조용히 0건** ⓑ 문장 안의 약명을 못 읽었다
        #   (실측 서식 줄 184 ↔ 글 전체 1,002).
        #   ⚠ 장만 적힌 참조는 **그 장 1절**로 온다(사용자 확정).
        import scripture_ref as SR
        # ★ 84-2 — 장·편만 적힌 참조는 연결하지 않는다(`SR.linkable`)
        for sv, ev, _m, _k in SR.linkable(SR.find(conn, body, lang, limit=200)):
            if sv not in seen:
                seen.add(sv)
                vids.append((sv, ev or sv))
    except Exception:                                     # noqa: BLE001
        pass
    for i, (sv, ev) in enumerate(vids):
        conn.execute(
            "INSERT OR IGNORE INTO sys_link_asset(link_type, clicked_id, "
            " target_id, end_id, sort_order, record_status, source) "
            "VALUES('REFU_VERS',?,?,?,?,'LIVE','AI_STUDY')",
            (uid, sv, ev if ev != sv else None, i))

    # ── 용어 연결 — **후보로만**(사람이 승인) ───────────────────────
    conn.execute("DELETE FROM sys_link_asset WHERE link_type='REFU_ENTI' "
                 "AND clicked_id=? AND source='AI_STUDY'", (uid,))
    for eid, _nm, why in study_terms(conn, body):
        # ★★★ **승인 자리는 AI 검수 화면이다** — 적재는 사람이
        #   승인한 뒤에만 돌므로 여기서는 `LIVE` 로 넣는다. 후보(`PEND`)로
        #   두면 **어느 화면에도 안 보인다** — `link_picker` 가 LIVE 만
        #   읽는다(§0-1). ★ **왜 올렸는지는 `note` 가 말한다** —
        #   찬양수집기에서 「추천근거=자동추천」이 질책받은 그 자리다.
        conn.execute(
            "INSERT OR IGNORE INTO sys_link_asset(link_type, clicked_id, "
            " target_id, record_status, source, note) "
            "VALUES('REFU_ENTI',?,?,'LIVE','AI_STUDY',?)",
            (uid, eid, '연구자료 %s에서 찾음' % why))
    return uid, ''


def bundle_compare(conn, j, slot_id, out_text):
    """묶음 비교 — `[(칸, 이름, 지금 글, 새 글, 처리)]`(docs/1.txt 4-2)).

    처리 = 덮어씀 · 덧붙임 · 새로 담음 · 안 씀(고르지 않은 칸).
    ★ 설명문·묵상질문·묵상기도는 **한 구절에 하나** — 지금 글이 있으면 덮어쓴다.
      연구질문·연구자료는 「덧붙이기」를 고른 작업이면 덧붙인다.
    """
    parts, _w = AJ.bundle_split(out_text or '', j.get('parts') or None)
    parts = parts or {}
    parts.pop('_alien', None)
    keys = set(AJ.bundle_keys(j.get('parts') or None))
    add = add_modes(j)
    out = []
    for row in AJ.BUNDLE_PARTS:
        k, nm, tt, va = row[0], row[1], row[2], row[3]
        new = parts.get(k, '')
        now = ''
        if tt:
            q = ("SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type=?"
                 " AND UPPER(lang_code)=? AND record_status='LIVE'")
            ar = [int(slot_id), tt, str(j['lang']).upper()]
            if va:
                q += " AND text_variant=?"
                ar.append(va)
            r = conn.execute(q + " ORDER BY ROWID DESC LIMIT 1", ar).fetchone()
            now = (r[0] or '') if r else ''
        elif k == 'NOTE':
            try:
                r = conn.execute("SELECT t.body_text FROM sys_ref_unit u JOIN sys_ref_text t"
                                 " ON t.ref_unit_id=u.ref_unit_id WHERE u.unit_code=?"
                                 " AND UPPER(t.lang_code)=? LIMIT 1",
                                 (STUDY_CODE % int(slot_id), str(j['lang']).upper())).fetchone()
                now = (r[0] or '') if r else ''
            except Exception:                             # noqa: BLE001
                now = ''
        if k not in keys:
            act = '안 씀(선택하지 않은 칸)'
        elif not new:
            act = '새 글 없음'
        elif k in add:
            act = '덧붙임'
        elif now.strip():
            act = '덮어씀'
        else:
            act = '새로 담음'
        if new or now:
            out.append((k, nm, now, new, act))
    return out


def _load_bundle(conn, job_id, j, dry=True):
    """묶음 적재 — **칸을 다 담거나 하나도 안 담는다**.

    ⚠⚠ 세 칸만 들어가면 그 절이 반쪽이 된다. 가르지 못한 건은 **건너뛰고
      까닭을 적는다**(조용히 빠뜨리지 않는다).
    """
    rows = conn.execute(
        "SELECT item_id, slot_id, out_text, COALESCE(keep_parts,'') FROM sys_ai_item "
        "WHERE job_id=? AND state='OK' AND TRIM(COALESCE(out_text,''))<>''",
        (job_id,)).fetchall()
    good, bad = [], []
    _keep = set(AJ.bundle_keys(j.get('parts') or None))
    _add = add_modes(j)
    _hold = {int(r[0]): {x for x in r[3].split(',') if x} for r in rows}
    rows = [r[:3] for r in rows]
    for iid, sid, txt in rows:
        parts, why = AJ.bundle_split(txt, j.get('parts') or None)
        if parts is None:
            bad.append('%s: %s' % (sid, why))
        else:
            parts.pop('_alien', None)     # ⚠ 알림 열쇠는 담지 않는다
            # ★★★ 317차-5 — **고른 칸만 담는다**(고르지 않은 칸을 모델이 써 와도 버린다)
            parts = {k: v for k, v in parts.items() if k in _keep}
            # ★ 사람이 비교 화면에서 「지금 글 유지」로 고른 칸은 **안 담는다**
            parts = {k: v for k, v in parts.items() if k not in _hold.get(int(iid), set())}
            good.append((iid, sid, parts))
    if dry:
        return {'ok': True, 'n': len(good),
                'why': ('칸을 못 가른 %d건은 빼고 셉니다 — %s'
                        % (len(bad), ' / '.join(bad[:3]))) if bad else ''}
    n = 0
    try:
        for iid, sid, parts in good:
            for k, body in parts.items():
                p = AJ.BUNDLE_PART[k]
                # ★★★ **연구자료는 `sys_ref_unit` 으로 간다**(1.txt 16-1)
                if p.get('store') == 'REF':
                    put_study_note(conn, sid, j['lang'], body, append=('NOTE' in _add))
                    continue
                if k == 'STUDY':
                    if 'STUDY' in _add:
                        # ★ 317차-5 — 연구질문 **덧붙이기**: 한 행 안에 물음이 여럿 사는 구조라
                        #   행을 늘리지 않고 그 행 뒤에 잇는다(화면은 한 행만 읽는다)
                        old = conn.execute(
                            "SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type=?"
                            " AND UPPER(lang_code)=? AND text_variant='EXPERT' AND record_status='LIVE'"
                            " ORDER BY ROWID DESC LIMIT 1", (sid, p['text_type'], j['lang'])).fetchone()
                        if old and (old[0] or '').strip():
                            # ★ 317차-19 — 같은 물음이면 안 붙인다(물음 줄로 견준다 · study_append)
                            body = study_append(old[0], body)
                q = ("DELETE FROM sys_text_asset WHERE clicked_id=? "
                     "AND text_type=? AND UPPER(lang_code)=?")
                ar = [sid, p['text_type'], j['lang']]
                if p['variant']:
                    q += " AND text_variant=?"
                    ar.append(p['variant'])
                conn.execute(q, ar)
                conn.execute(
                    "INSERT INTO sys_text_asset(clicked_id, text_type, contents,"
                    " lang_code, text_variant, record_status, created_at) "
                    "VALUES(?,?,?,?,?,'LIVE',?)",
                    (sid, p['text_type'], body, j['lang'], p['variant'], _now()))
            conn.execute("UPDATE sys_ai_item SET state='LOADED' WHERE item_id=?",
                         (iid,))
            n += 1
    except Exception:                                     # noqa: BLE001
        conn.rollback()
        raise
    conn.commit()
    return {'ok': True, 'n': n,
            'why': ('칸을 못 가른 %d건은 안 담았습니다.' % len(bad)) if bad else ''}


# ══════════════════════════════════════════════════════════════════
#  자가 검증 (의무 · 망을 안 탄다)
# ══════════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════════════════
# ★★★ 오류 찾기 · 고른 수정 적용 (2026-10-30 · docs/1.txt 7-2)
#   사용자 지시 — 「재료만 보내 주고 오직 오류·오탈자를 검증하는 역할 · 어떤 내용이 왜
#   어떻게 오류가 있는지, 어떻게 수정해야 하는지 결과만 표시하고 다른 작업은 하지 않는다 ·
#   발견된 오류들을 모아서 수정하는 것은 다른 AI 에게」.
#   찾는 AI(유료 Pro) 와 고치는 쪽(기계 · 안 되면 다른 AI)을 가른다. 찾는 AI 는 글을 안 고친다.
#   ⚠ 「틀린 글자」가 받은 글에 실제로 있는 지적만 남긴다 — 없는 글자를 지적한 줄은 헛것이다.
# ══════════════════════════════════════════════════════════════════════════
CHECK_MODEL_CFG = 'AI_CHECK_MODEL'
CHECK_MODEL = 'gemini-pro-latest'
CHECK_KINDS = ('사실', '번역', '오탈자', '기타')
# ★ 2026-10-30 생각 정도 — 생각 토큰이 출력 단가로 청구된다. 실측(심은 오류 21개 · 6건):
#   Pro 기본 20/21 · **Pro low 20/21 · 건당 약 $0.024(35원)** · Flash low 15/21 ⇒ Pro + low
CHECK_THINK = 'low'
FIX_SIM_MIN = 0.90          # 다른 AI 가 고친 글이 원래 글과 이만큼은 같아야 받는다(지적 밖을 고쳤으면 거절)

CHECK_PROMPT = """너는 교정자다. 아래 [받은 글]에서 독자를 잘못 이끄는 중요한 오류만 찾는다. 글을 고쳐 쓰지 않는다.

중요한 오류
- 사실: 사람·관계·장소·숫자·장절·성경 내용이 원문·재료와 다르다
- 번역: 원문의 뜻을 거꾸로 또는 엉뚱하게 옮겼거나, 뜻이 담긴 문장·구절을 빠뜨렸다
- 오탈자: 낱말을 알아볼 수 없게 깨졌거나 다른 언어 글자가 섞였다
오류가 아닌 것(적지 않는다): 띄어쓰기 · 조사·어미 · 더 나은 낱말이나 어순 · 표기 규칙(약명 꼴·이름 표기) ·
  문체 · 뜻이 통하는 다른 번역 · 성경 구절 인용(그 언어의 기준 역본 글자라 원문 영어와 낱말이 달라도 된다)

답의 모양 — 한 줄에 오류 하나, 이 꼴만:
종류 | 틀린 글자 | 왜 | 고칠 글
- 종류 = 사실 · 번역 · 오탈자 가운데 하나
- 틀린 글자 = [받은 글]에 있는 그대로 복사한 짧은 토막(한 문장 이하)
- 왜 = 한국어 한 문장
- 고칠 글 = 틀린 글자 자리에 들어갈 글
중요한 오류가 없으면 「없음」 한 줄만 쓴다. 다른 말은 쓰지 않는다.

{material}
[받은 글]
{text}
"""


def check_model(conn):
    # ★ 2026-10-30 AI 연결 탭의 일별 설정(ai_client.TASK_SETTINGS 'CHECK')이 정한다
    try:
        return AC.task_model(conn, 'CHECK')
    except Exception:                                     # noqa: BLE001
        return CHECK_MODEL


def _ensure_check(conn):
    try:
        icols = [r[1] for r in conn.execute("PRAGMA table_info(sys_ai_item)")]
        if 'check_json' not in icols:
            conn.execute("ALTER TABLE sys_ai_item ADD COLUMN check_json TEXT")
            conn.commit()
    except Exception:                                     # noqa: BLE001
        pass


def parse_check(answer, text):
    """찾는 AI 의 답 → `[{kind, wrong, why, fix, n}]`(n = 받은 글에 그 글자가 몇 번) · 버린 줄 수.

    ⚠ 받은 글에 없는 「틀린 글자」는 버린다 · 틀린 글자 = 고칠 글이면 버린다(바꿀 것이 없다).
    """
    out, dropped = [], 0
    for ln in (answer or '').splitlines():
        s = ln.strip().lstrip('-*•·').strip()
        s = re.sub(r'^\d+[.)]\s*', '', s)
        if not s or s in ('없음', '없음.') or s.count('|') < 3:
            continue
        p = [x.strip().strip('`"「」“”') for x in s.split('|')]
        kind, wrong, why, fix = p[0], p[1], p[2], '|'.join(p[3:]).strip().strip('`"「」“”')
        if kind not in CHECK_KINDS:
            kind = '기타'
        n = text.count(wrong) if wrong else 0
        if not wrong or n == 0 or wrong == fix:
            dropped += 1
            continue
        if any(x['wrong'] == wrong for x in out):      # 같은 글자를 여러 번 지적 — 한 줄로(고칠 때 함께 고친다)
            continue
        out.append({'kind': kind, 'wrong': wrong, 'why': why, 'fix': fix, 'n': n})
    return out, dropped


def _check_material(conn, j, slot_id):
    try:
        ctx = AJ.material(conn, j['asset_kind'], slot_id, j['task'],
                          base=j['base_lang'], lang=j['lang'], scope=j['scope_value'])
        if AJ.ASSET[j['asset_kind']].get('store') == 'BUNDLE':
            ctx = AJ.bundle_filter(ctx, j.get('parts') or None, lines=False)
    except Exception as e:                                # noqa: BLE001
        return '[재료]\n(못 읽었다: %s)\n' % e
    return ''.join('[%s]\n%s\n\n' % (k, v) for k, v in ctx.items() if str(v or '').strip())


def check_item(conn, item_id, call=None, model=None):
    """그 건의 받은 글에서 **오류만 찾는다**(고치지 않는다) — 결과는 `check_json` 에.

    반환 `{ok, found, dropped, why, model}`.
    """
    ensure(conn)
    _ensure_check(conn)
    r = conn.execute("SELECT job_id, slot_id, out_text FROM sys_ai_item WHERE item_id=?",
                     (int(item_id),)).fetchone()
    if not r or not (r[2] or '').strip():
        return {'ok': False, 'why': '받은 글이 없습니다', 'found': [], 'dropped': 0}
    j = job(conn, r[0])
    text = r[2]
    prompt = CHECK_PROMPT.format(material=_check_material(conn, j, r[1]), text=text)
    m = model or check_model(conn)
    call = call or AC.call
    try:
        import ai_sent_log as _SL
        with _SL.tag('AI 작업실 · 오류 찾기', 'job %d · item %d' % (r[0], int(item_id)),
                     job_id=r[0], item_id=int(item_id)):
            try:
                res = call(prompt, model=m, conn=conn, temperature=0, thinking=AC.task_think(conn, 'CHECK'))
            except TypeError:                             # 시험용 가짜 call
                res = call(prompt, model=m, conn=conn, temperature=0)
    except Exception as e:                                # noqa: BLE001
        res = {'ok': False, 'why': str(e)}
    if not res.get('ok'):
        return {'ok': False, 'why': res.get('why', ''), 'found': [], 'dropped': 0, 'model': m}
    found, dropped = parse_check(res.get('text') or '', text)
    conn.execute("UPDATE sys_ai_item SET check_json=? WHERE item_id=?",
                 (json.dumps({'model': res.get('model') or m, 'at': _now(), 'found': found,
                              'dropped': dropped, 'raw': res.get('text') or ''},
                             ensure_ascii=False), int(item_id)))
    conn.commit()
    return {'ok': True, 'found': found, 'dropped': dropped, 'model': res.get('model') or m}


def check_of(conn, item_id):
    _ensure_check(conn)
    r = conn.execute("SELECT check_json FROM sys_ai_item WHERE item_id=?", (int(item_id),)).fetchone()
    try:
        return json.loads(r[0]) if r and r[0] else None
    except Exception:                                     # noqa: BLE001
        return None


FIX_PROMPT = """아래 [글]에서 [고칠 것]에 적힌 자리만 고친다. 그 밖의 글자는 하나도 바꾸지 않는다.
고친 글 전체만 낸다. 설명·머리말을 붙이지 않는다.

[고칠 것]
{fixes}

[글]
{text}
"""


def apply_fixes(conn, item_id, picks, call=None, model=None):
    """고른 지적(`check_json.found` 의 번호)만 고친다 — 반환 `{ok, machine, ai, skip, why}`.

    ① 받은 글에 **한 번만** 나오는 틀린 글자는 기계가 그 자리만 갈아 끼운다
    ② 여러 번 나오는 것은 **다른 AI**(번역 모델이 아닌 기본 모델)에게 그 자리만 고치게 한다 —
       돌아온 글이 원래 글과 `FIX_SIM_MIN` 보다 다르면 받지 않는다(지적 밖을 고쳤다)
    고친 뒤 게이트를 다시 잰다 · 상태는 그대로(사람이 승인한다).
    """
    import difflib
    ensure(conn)
    chk = check_of(conn, item_id) or {}
    found = chk.get('found') or []
    r = conn.execute("SELECT job_id, slot_id, out_text, state FROM sys_ai_item WHERE item_id=?",
                     (int(item_id),)).fetchone()
    if not r:
        return {'ok': False, 'why': '건이 없습니다'}
    text0 = text = r[2] or ''
    mach, rest, skip = [], [], []
    for i in picks:
        if not (0 <= int(i) < len(found)):
            continue
        f = found[int(i)]
        n = text.count(f['wrong'])
        if n == 1:
            text = text.replace(f['wrong'], f['fix'])
            mach.append(int(i))
        elif n > 1:
            rest.append(int(i))
        else:
            skip.append(int(i))            # 앞 고침이 그 자리를 먹었다
    ai_done, why = [], ''
    if rest:
        fixes = '\n'.join('- 「%s」 → 「%s」 (%s)' % (found[i]['wrong'], found[i]['fix'], found[i]['why'])
                          for i in rest)
        call = call or AC.call
        try:
            res = call(FIX_PROMPT.format(fixes=fixes, text=text),
                       model=model or AC.task_model(conn, 'FIX'), conn=conn, temperature=0)
        except Exception as e:                            # noqa: BLE001
            res = {'ok': False, 'why': str(e)}
        new = (res.get('text') or '').strip() if res.get('ok') else ''
        sim = difflib.SequenceMatcher(None, text, new).ratio() if new else 0
        if new and sim >= FIX_SIM_MIN and all(found[i]['fix'] in new for i in rest):
            text = new
            ai_done = rest
        else:
            skip += rest
            why = res.get('why') or ('고친 글이 지적 밖까지 바뀌었습니다(같은 정도 %.2f) — 받지 않았습니다' % sim
                                     if new else '고친 글을 못 받았습니다')
    if text != text0:
        j = job(conn, r[0])
        g = gate_for_job(conn, j, r[1], text, before=_before_of(conn, j, r[1]))
        # ★ 이미 적재한 건이면 **승인(OK)으로 되돌린다** — 적재 문은 승인한 건만 담으므로 [적재]를 다시 누르면
        #   고친 글이 옛 글을 덮는다(실측 사용자가 오류를 찾은 28건이 전부 적재된 뒤였다)
        conn.execute("UPDATE sys_ai_item SET out_text=?, gate_json=?,"
                     " state=CASE WHEN state='LOADED' THEN 'OK' ELSE state END WHERE item_id=?",
                     (text, json.dumps(g, ensure_ascii=False), int(item_id)))
        for i in mach + ai_done:
            found[i]['done'] = 1
        chk['found'] = found
        chk['prev'] = chk.get('prev') or text0
        conn.execute("UPDATE sys_ai_item SET check_json=? WHERE item_id=?",
                     (json.dumps(chk, ensure_ascii=False), int(item_id)))
        conn.commit()
    return {'ok': bool(mach or ai_done), 'machine': mach, 'ai': ai_done, 'skip': skip, 'why': why,
            'reload': bool(text != text0 and r[3] == 'LOADED')}


# ★ 2026-10-30 오류 찾기도 묶는다(사용자 「50개 이상 선택했는데 하나씩 처리한다」) — 건마다 부르면 호출마다
#   생각 토큰이 붙고 느리다(실측 건당 약 17초). 재료+받은 글 합계 `CHECK_BATCH_CHARS`·`BATCH_MAX`건까지 한 번에.
CHECK_BATCH_CHARS = 6000
# 실측(심은 오류 21 · 6건): 한 건씩 20/21 · **3건 묶음 18~19/21** · 6건 묶음 17/21 ⇒ 3건까지(찾는 힘을 크게 안 잃는 선)
CHECK_BATCH_MAX = 3
_CHECK_HEAD = CHECK_PROMPT.split('{material}')[0]


def _check_unit(conn, item_id):
    r = conn.execute("SELECT job_id, slot_id, out_text FROM sys_ai_item WHERE item_id=?", (int(item_id),)).fetchone()
    if not r or not (r[2] or '').strip():
        return None
    j = job(conn, r[0])
    return {'iid': int(item_id), 'job': r[0], 'text': r[2], 'mat': _check_material(conn, j, r[1])}


def check_groups(conn, item_ids, cap=CHECK_BATCH_CHARS):
    """오류 찾기 묶음 — [[unit…]] · 받은 글이 없는 건은 빠진다(따로 센다)"""
    groups, cur, cur_n, empty = [], [], 0, []
    for iid in item_ids:
        u = _check_unit(conn, iid)
        if u is None:
            empty.append(int(iid))
            continue
        sz = len(u['mat']) + len(u['text'])
        if cur and (cur_n + sz > cap or len(cur) >= CHECK_BATCH_MAX):
            groups.append(cur)
            cur, cur_n = [], 0
        cur.append(u)
        cur_n += sz
    if cur:
        groups.append(cur)
    return groups, empty


def check_batch_prompt(units):
    if len(units) == 1:
        u = units[0]
        return CHECK_PROMPT.format(material=u['mat'], text=u['text'])
    L = [_CHECK_HEAD.rstrip(), '',
         '[여러 항목을 한 번에] 아래 %d개 항목을 따로따로 본다. 줄 맨 앞에 항목 번호를 붙인다:' % len(units),
         '번호 | 종류 | 틀린 글자 | 왜 | 고칠 글',
         '틀린 글자는 그 번호 항목의 [받은 글]에서 복사한다. 오류가 없는 항목은 적지 않는다. 어느 항목에도 없으면 「없음」 한 줄.', '']
    for n, u in enumerate(units, 1):
        L.append(BATCH_MARK % n)
        L.append(u['mat'].rstrip())
        L.append('[받은 글]\n%s' % u['text'])
        L.append('')
    return '\n'.join(L)


def check_many(conn, units, call=None, model=None):
    """한 묶음을 한 번에 — 반환 {iid: {ok, found, dropped, why}} · 결과는 건마다 check_json 에"""
    m = model or check_model(conn)
    call = call or AC.call
    prompt = check_batch_prompt(units)
    try:
        import ai_sent_log as _SL
        with _SL.tag('AI 작업실 · 오류 찾기', 'job %d · %d건 · item %s' % (units[0]['job'], len(units),
                     ','.join(str(u['iid']) for u in units)), job_id=units[0]['job'], item_id=units[0]['iid']):
            try:
                res = call(prompt, model=m, conn=conn, temperature=0, thinking=AC.task_think(conn, 'CHECK'))
            except TypeError:                             # 시험용 가짜 call
                res = call(prompt, model=m, conn=conn, temperature=0)
    except Exception as e:                                # noqa: BLE001
        res = {'ok': False, 'why': str(e)}
    out = {}
    if not res.get('ok'):
        for u in units:
            out[u['iid']] = {'ok': False, 'why': res.get('why', ''), 'found': [], 'dropped': 0, 'daily': bool(res.get('daily'))}
        return out
    return check_store(conn, units, res.get('text') or '', res.get('model') or m)


def check_store(conn, units, raw, model):
    """찾는 AI 의 답 하나를 건마다 나눠 `check_json` 에 — 바로 받기·Batch 받기가 같은 문을 쓴다"""
    out = {}
    lines = {n: [] for n in range(1, len(units) + 1)}
    if len(units) == 1:
        lines[1] = raw.splitlines()
    else:
        for ln in raw.splitlines():
            mm = re.match(r'^\s*[-*•·]?\s*(?:항목\s*)?(\d+)\s*[|.)]\s*(.*)$', ln)
            if mm and int(mm.group(1)) in lines and mm.group(2).count('|') >= 3:
                lines[int(mm.group(1))].append(mm.group(2))
    for n, u in enumerate(units, 1):
        found, dropped = parse_check('\n'.join(lines[n]), u['text'])
        conn.execute("UPDATE sys_ai_item SET check_json=? WHERE item_id=?",
                     (json.dumps({'model': model, 'at': _now(), 'found': found, 'dropped': dropped,
                                  'raw': '\n'.join(lines[n]), 'batch': len(units)}, ensure_ascii=False), u['iid']))
        out[u['iid']] = {'ok': True, 'found': found, 'dropped': dropped}
    conn.commit()
    return out


def set_check_skip(conn, item_id, idxs, skip=True):
    """오류 찾기 결과에서 그 줄을 **고치지 않을 것**으로 표시한다(되살리기 = skip=False)"""
    chk = check_of(conn, item_id)
    if not chk:
        return 0
    f = chk.get('found') or []
    n = 0
    for i in idxs:
        if 0 <= int(i) < len(f):
            f[int(i)]['skip'] = 1 if skip else 0
            n += 1
    conn.execute("UPDATE sys_ai_item SET check_json=? WHERE item_id=?",
                 (json.dumps(chk, ensure_ascii=False), int(item_id)))
    conn.commit()
    return n


def fix_picks(chk):
    """한꺼번에 고칠 줄 — 아직 안 고쳤고 사람이 빼지 않은 것"""
    return [i for i, f in enumerate((chk or {}).get('found') or []) if not f.get('done') and not f.get('skip')]


def selftest():
    bad = []
    # ⚠ **항목 수를 손으로 적지 않는다** — 상수로 두면 항목을 늘려도
    #   그 수로 찍혀 **세는 쪽이 거짓말**을 한다(§238차 그 자리).
    _nck = [0]

    def ck(c, m):
        _nck[0] += 1
        if not c:
            bad.append(m)

    ck(set(STATE_NAME) == set(STATES), '상태 이름표가 빠졌다')

    # ★ 2026-10-20 (docs/1.txt 13) 주석 적재 문 — 메모리 DB 에서(실 DB 자국 0)
    import sqlite3 as _sq
    _m = _sq.connect(':memory:')
    ensure(_m)
    _m.execute("CREATE TABLE sys_commentary_entry (entry_id INTEGER PRIMARY KEY)")
    _m.execute("CREATE TABLE sys_commentary_text (text_id INTEGER PRIMARY KEY AUTOINCREMENT, entry_id, "
               "text_variant, lang_code, body_text, record_status DEFAULT 'LIVE')")
    _m.execute("INSERT INTO sys_commentary_entry VALUES (5)")
    _m.execute("INSERT INTO sys_commentary_text(entry_id,text_variant,lang_code,body_text) VALUES (5,'ORIGINAL','EN','orig')")
    _m.execute("INSERT INTO sys_ai_job(asset_kind,task,base_lang,lang) VALUES ('COMMENTARY','TRANS','EN','KO')")
    _m.execute("INSERT INTO sys_ai_item(job_id,slot_id,state,out_text) VALUES (1,5,'OK','번역 글')")
    _m.execute("INSERT INTO sys_ai_item(job_id,slot_id,state,out_text) VALUES (1,9,'OK','없는 자리')")
    _m.commit()
    ck(load_ok(_m, 1, dry=True)['n'] == 2, '주석 적재 — 세기')
    _r = load_ok(_m, 1, dry=False)
    ck(_r['n'] == 1 and '9' in _r['why'], '주석 적재 — 담기/건너뛰기: %s' % _r)
    ck(_m.execute("SELECT text_variant, body_text FROM sys_commentary_text WHERE lang_code='KO'").fetchall()
       == [('TRANSLATED', '번역 글')], '주석 적재 — 번역 칸')
    ck(_m.execute("SELECT body_text FROM sys_commentary_text WHERE text_variant='ORIGINAL'").fetchone()[0] == 'orig',
       '주석 적재 — 원문 불변')
    load_ok(_m, 1, dry=False)
    ck(_m.execute("SELECT COUNT(*) FROM sys_commentary_text WHERE lang_code='KO'").fetchone()[0] == 1, '주석 적재 — 멱등')
    # ★ docs/2.txt 8번 — 자료집 적재 문은 원문 언어 칸을 덮지 않는다
    _m.execute("CREATE TABLE sys_ref_source (ref_src_id INTEGER PRIMARY KEY, src_code, lang_code)")
    _m.execute("CREATE TABLE sys_ref_unit (ref_unit_id INTEGER PRIMARY KEY, ref_src_id, unit_label)")
    _m.execute("CREATE TABLE sys_ref_text (ref_text_id INTEGER PRIMARY KEY AUTOINCREMENT, ref_unit_id, text_variant, "
               "lang_code, body_text, title, record_status)")
    _m.execute("INSERT INTO sys_ref_source VALUES (1,'EASTON_DICT','EN')")
    _m.execute("INSERT INTO sys_ref_unit VALUES (7,1,'Aaron')")
    _m.execute("INSERT INTO sys_ref_text(ref_unit_id,text_variant,lang_code,body_text,title,record_status) "
               "VALUES (7,'ORIGINAL','EN','author text','Aaron','LIVE')")
    _m.execute("INSERT INTO sys_ai_job(job_id,asset_kind,task,base_lang,lang) VALUES (2,'REF_DICT','TRANS','EN','EN')")
    _m.execute("INSERT INTO sys_ai_item(job_id,slot_id,state,out_text) VALUES (2,7,'OK','AI text')")
    _m.execute("INSERT INTO sys_ai_job(job_id,asset_kind,task,base_lang,lang) VALUES (3,'REF_DICT','TRANS','EN','KO')")
    _m.execute("INSERT INTO sys_ai_item(job_id,slot_id,state,out_text) VALUES (3,7,'OK','아론 번역')")
    _m.commit()
    _r = load_ok(_m, 2, dry=False)
    ck(not _r['ok'] and '원문' in _r['why'], '자료집 적재 — 원문 언어 칸은 거부: %s' % _r)
    ck(_m.execute("SELECT body_text FROM sys_ref_text WHERE lang_code='EN'").fetchone()[0] == 'author text',
       '자료집 적재 — 원문 불변')
    _r = load_ok(_m, 3, dry=False)
    ck(_r['ok'] and _r['n'] == 1 and _m.execute("SELECT body_text FROM sys_ref_text WHERE lang_code='KO'").fetchone()[0] == '아론 번역',
       '자료집 적재 — 번역 언어 칸은 담긴다: %s' % _r)
    _m.close()

    conn = None
    try:
        import appdb
        conn = appdb.connect(os.path.join(APP, 'bible_master.db'))
        ensure(conn)
        n0 = conn.execute("SELECT COUNT(*) FROM sys_ai_job").fetchone()[0]
        i0 = conn.execute("SELECT COUNT(*) FROM sys_ai_item").fetchone()[0]
        t0 = conn.execute("SELECT COUNT(*) FROM sys_text_asset").fetchone()[0]

        # 시편 첫 세 자리(비어 있다) 로 시험 작업
        sl = AJ.todo(conn, 'VERS_DESC_LAY', '19', 'NEW', limit=3)
        ck(len(sl) == 3, '시험할 빈 자리를 못 찾았다: %s' % len(sl))
        jid, n = create_job(conn, 'VERS_DESC_LAY', '19', 'NEW', 'KO', sl,
                            name='__시험__')
        ck(n == 3 and counts(conn, jid)['PENDING'] == 3,
           '건별 행이 안 깔렸다: %s' % counts(conn, jid))

        # ⓐ 가짜 응답기 — **망을 안 탄다**
        seen = []

        def _ok(prompt, model=None, conn=None, **kw):
            seen.append(prompt)
            return {'ok': True, 'text': '시험용 글입니다. 두 문장으로 씁니다.',
                    'why': '', 'tokens': {'in': 10, 'out': 5}}
        r = run_job(conn, jid, limit=2, _call=_ok)
        # ⚠ 반환값을 **통째로** 견주면 칸을 하나 더하는 날 깨진다
        #   (`stopped` 를 더하자 실제로 깨졌다) — 묻는 것만 본다.
        ck(r['tried'] == 2 and r['done'] == 2 and r['fail'] == 0
           and not r.get('stopped'), '두 건이 안 됐다: %s' % r)
        # ★ 2026-10-30 새로 쓰기도 묶어 보낸다 — 이 가짜는 항목 줄을 모르니 묶음 1번 뒤 한 건씩 2번(나누기 실패 → 한 건씩)
        ck(len(seen) == 3 and '===== 항목 1 =====' in seen[0], '부른 횟수가 다르다: %s' % len(seen))
        ck('본문' in seen[-1], '프롬프트에 재료가 안 실렸다')
        c = counts(conn, jid)
        ck(c['DONE'] == 2 and c['PENDING'] == 1,
           '상태가 안 맞는다: %s' % c)

        # ⓑ **이어서 돌리면 남은 것만** 집는다
        seen[:] = []
        r = run_job(conn, jid, _call=_ok)
        ck(r['tried'] == 1, '이미 한 것을 또 집는다: %s' % r)
        ck(counts(conn, jid)['DONE'] == 3, '셋이 다 안 됐다')

        # ⓒ 실패해도 다음으로 가고, 다시 돌리면 **또 집는다**
        def _bad(prompt, model=None, conn=None, **kw):
            return {'ok': False, 'text': '', 'why': '가짜 실패', 'tokens': {}}
        conn.execute("UPDATE sys_ai_item SET state='PENDING' WHERE job_id=?",
                     (jid,))
        conn.commit()
        r = run_job(conn, jid, _call=_bad)
        ck(r['fail'] == 3 and r['done'] == 0, '실패를 안 센다: %s' % r)
        ck(counts(conn, jid)['FAIL'] == 3, '실패 상태가 안 남았다')
        r = run_job(conn, jid, limit=1, _call=_ok)
        ck(r['done'] == 1, '실패한 것을 다시 안 집는다: %s' % r)

        # ⓓ 터져도 다음으로
        def _boom(prompt, model=None, conn=None, **kw):
            raise RuntimeError('펑')
        r = run_job(conn, jid, _call=_boom)
        ck(r['tried'] == 2 and r['fail'] == 2, '터진 뒤 멎는다: %s' % r)

        # ★★★ **고른 건만 보낸다**(2026-09-25 사용자 「복수선택 하고
        #   전송하기」) — 양방향으로 잰다. 옛 방식은 고른 것과 무관하게
        #   앞에서 N개를 보냈다.
        _ids = [r[0] for r in conn.execute(
            "SELECT item_id FROM sys_ai_item WHERE job_id=? ORDER BY item_id",
            (jid,)).fetchall()]
        if len(_ids) >= 2:
            # ⚠ 앞 검사가 이미 돌려 놓았을 수 있다 — **재는 축을 먼저 세운다**
            #   (§0-5 「데이터 상태를 전제하지 말 것」).
            conn.execute("UPDATE sys_ai_item SET state='PENDING',"
                         " out_text=NULL WHERE job_id=?", (jid,))
            conn.commit()
            _seen = []

            def _spy(prompt, model=None, conn=None, **kw):     # noqa: ARG001
                _seen.append(1)
                return {'ok': True, 'text': '보낸 글입니다.', 'usage': {}}

            run_job(conn, jid, only=[_ids[1]], _call=_spy)
            ck(len(_seen) == 1, '선택한 건만 안 보낸다(%d회)' % len(_seen))
            _st = dict(conn.execute(
                "SELECT item_id, state FROM sys_ai_item WHERE job_id=?",
                (jid,)).fetchall())
            ck(_st.get(_ids[1]) == 'DONE', '선택한 건이 안 돌았다')
            ck(_st.get(_ids[0]) == 'PENDING', '안 선택한 건까지 돌았다')
            # ⚠ **이미 받은 건은 다시 안 보낸다** — 한도를 두 번 먹으면 안 된다
            _seen[:] = []
            run_job(conn, jid, only=[_ids[1]], _call=_spy)
            ck(not _seen, '이미 받은 건을 다시 보낸다')
            conn.execute("UPDATE sys_ai_item SET state='PENDING',"
                         " out_text=NULL WHERE job_id=?", (jid,))
            conn.commit()

        # ⓔ 게이트가 **배포 DB 를 안 건드린다**
        g = gate_item(conn, 'VERS_DESC_LAY', sl[0][0], 'KO', '한 문장입니다.')
        ck(isinstance(g, dict) and 'ok' in g, '게이트 결과 모양이 아니다')
        ck(conn.execute("SELECT COUNT(*) FROM sys_text_asset").fetchone()[0] == t0,
           '게이트가 배포 DB 를 건드렸다')
        # ⚠ **BOOK_UNIT 을 쓰지 않는다** — 2026-09-24 에 출처 줄 게이트가
        #   생겼다. 「게이트가 없다」를 재려면 정말 없는 자산이라야 한다.
        g2 = gate_item(conn, 'COMMENTARY', 1, 'KO', 'x')
        ck(g2['ok'] is None, '게이트가 없는 자산을 통과라 한다')
        # ★★★ **도서 출처 줄 — 검수 자리가 그것을 말하는가**(2026-09-24).
        #   사용자 신고 「맨 아랫줄에 책이름 한줄이 기록되지 않았다」의 답이
        #   「적재할 때 붙는다」이므로, **그 말을 검수 화면이 해야** 한다.
        _bu = conn.execute(
            "SELECT u.unit_id FROM sys_book_unit u"
            "  JOIN sys_book_asset a ON a.book_id=u.book_id LIMIT 1").fetchone()
        if _bu:
            import db_book_attrib as _BA2
            _want = _BA2.book_attrib_for(conn, _bu[0], 'TRANSLATED', 'KO')
            g3 = gate_item(conn, 'BOOK_UNIT', _bu[0], 'KO', '본문입니다.')
            ck(g3['ok'] is True, '출처를 댈 수 있는 유닛을 흠으로 잡는다')
            ck(any('적재할 때 맨 아래' in l for l in g3['lines']),
               '적재할 때 붙을 출처 줄을 안 보인다')
            ck(bool(_want) and any((_want in l) for l in g3['lines']),
               '보이는 출처 줄이 실제로 붙을 줄과 다르다')
            # 탐지력 — AI 가 제 손으로 붙인 줄이 있으면 알린다
            _fake = ('본문입니다.' + chr(10) + chr(10)
                     + '— 아무개, 엉뚱한 책 (연도). 공유 저작물.')
            g4 = gate_item(conn, 'BOOK_UNIT', _bu[0], 'KO', _fake)
            ck(any('갈아 끼웁니다' in l for l in g4['lines']),
               'AI 가 붙인 출처 줄을 못 알아본다')
        # ★★★ **성경 인용 대조**(2026-09-25) — 양방향으로 잰다.
        if _bu:
            _krv = conn.execute(
                "SELECT verse_text FROM bible_content WHERE version_code='KRV'"
                "  AND verse_id=(SELECT verse_id FROM bible_index WHERE"
                "   bcode=58 AND chapter=11 AND verse=24)").fetchone()
            if _krv and _krv[0]:
                g6 = gate_item(conn, 'BOOK_UNIT', _bu[0], 'KO',
                               '“%s” (히 11:24)' % _krv[0])
                ck(g6['ok'] is True, '그대로 인용했는데 흠으로 잡는다')
                g7 = gate_item(
                    conn, 'BOOK_UNIT', _bu[0], 'KO',
                    '“믿음으로 모세가 '
                    '태어났을 때, 부모는 '
                    '그가 잘생긴 아이임을 '
                    '보고 석 달 동안 '
                    '숨겼습니다.” '
                    '(히 11:23)')
                ck(any('겹침' in l for l in g7['lines']),
                   '다시 번역한 인용을 검수 화면이 안 알린다')
                # ⚠ **다른 언어에서는 안 잰다** — 개역한글과 견줄 수 없다
                g8 = gate_item(conn, 'BOOK_UNIT', _bu[0], 'JA',
                               '“信仰によって'
                               '、モーセは生ま'
                               'れたとき。” '
                               '(히 11:23)')
                ck(not any('겹침' in l for l in g8['lines']),
                   '한국어가 아닌 글을 개역한글과 견준다')
        # 탐지력 — 책을 못 찾는 유닛은 **흠**이라야 한다(조용히 안 건너뛴다)
        g5 = gate_item(conn, 'BOOK_UNIT', -777, 'KO', '본문입니다.')
        ck(g5['ok'] is False, '책을 못 찾는 유닛을 통과라 한다')

        # ⓕ 적재는 **승인한 것만**
        run_job(conn, jid, _call=_ok)
        ck(load_ok(conn, jid, dry=True)['n'] == 0, '승인 전인데 담을 것이 있다')
        ids = [r2[0] for r2 in items(conn, jid, 'DONE')][:2]
        judge(conn, ids, 'OK')
        ck(load_ok(conn, jid, dry=True)['n'] == 2, '승인분을 안 센다')
        got = load_ok(conn, jid, dry=False)
        ck(got['n'] == 2, '적재가 안 됐다: %s' % got)
        ck(counts(conn, jid)['LOADED'] == 2, '적재 상태가 안 남았다')
        ck(conn.execute("SELECT COUNT(*) FROM sys_text_asset").fetchone()[0]
           == t0 + 2, '적재 행 수가 안 맞는다')
        # 멱등 — 다시 승인해 담아도 행이 안 는다
        conn.execute("UPDATE sys_ai_item SET state='OK' WHERE job_id=? "
                     "AND state='LOADED'", (jid,))
        conn.commit()
        load_ok(conn, jid, dry=False)
        ck(conn.execute("SELECT COUNT(*) FROM sys_text_asset").fetchone()[0]
           == t0 + 2, '다시 담으니 행이 늘었다')

        # ⓖ 적재한 작업은 못 지운다
        try:
            delete_job(conn, jid)
            bad.append('적재한 작업을 지웠다')
        except AssertionError:
            pass

        # 청소 — **자국 0**
        for _iid, sid2, _t in conn.execute(
                "SELECT item_id, slot_id, out_text FROM sys_ai_item "
                "WHERE job_id=?", (jid,)).fetchall():
            conn.execute("DELETE FROM sys_text_asset WHERE clicked_id=? "
                         "AND text_type='VERS_DESC' AND text_variant='LAY' "
                         "AND UPPER(lang_code)='KO'", (sid2,))
        conn.execute("DELETE FROM sys_ai_item WHERE job_id=?", (jid,))
        conn.execute("DELETE FROM sys_ai_job WHERE job_id=?", (jid,))
        conn.commit()
        n1 = conn.execute("SELECT COUNT(*) FROM sys_ai_job").fetchone()[0]
        i1 = conn.execute("SELECT COUNT(*) FROM sys_ai_item").fetchone()[0]
        t1 = conn.execute("SELECT COUNT(*) FROM sys_text_asset").fetchone()[0]
        ck(n0 == n1 and i0 == i1, '작업·건별 자국: %s/%s → %s/%s' % (n0, i0, n1, i1))
        ck(t0 == t1, '배포 DB 자국: %s → %s' % (t0, t1))
    except Exception as e:                                # noqa: BLE001
        import traceback
        traceback.print_exc()
        bad.append('DB 검사에서 터졌다: %s' % e)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:                             # noqa: BLE001
                pass

    # ★★★ 도서 적재 문 (1.txt 16-2 ⓑ) — **승인이 적재로 이어지는가**
    #   ⚠ 실 DB 를 건드리므로 **제 try/finally** 로 반드시 되돌린다.
    conn = None
    try:
        conn = appdb.connect()
        import db_book_attrib as _BA
        # ⚠ `BOOK_UNIT`+`TRANS` 프로필은 **책별(scope)로만** 있다(실측) —
        #   그래서 프로필이 있는 책의 유닛을 골라야 작업이 만들어진다.
        u = conn.execute(
            "SELECT u.unit_id, p.scope_value FROM sys_book_unit u"
            "  JOIN sys_ai_profile p ON p.scope_value = CAST(u.book_id AS TEXT)"
            " WHERE p.asset_kind='BOOK_UNIT' AND p.task='TRANS'"
            "   AND COALESCE(p.record_status,'LIVE')='LIVE' LIMIT 1").fetchone()
        uid = u and u[0]
        bscope = (u and u[1]) or ''
        keep = jid2 = None
        if uid:
            keep = conn.execute(
                "SELECT body_text FROM sys_book_unit_text WHERE unit_id=?"
                "  AND text_variant='TRANSLATED' AND UPPER(lang_code)='KO'",
                (uid,)).fetchone()
            try:
                jid2, _n2 = create_job(conn, 'BOOK_UNIT', bscope, 'TRANS',
                                       'KO', [uid], name='[도서 적재 시험]')
                # ⚠ AI 가 제 손으로 붙인 엉뚱한 출처 줄을 흉내 낸다
                fake = ('본문입니다.' + chr(10) + chr(10)
                        + '— 아무개, 엉뚱한 책 (연도). 공유 저작물.')
                conn.execute("UPDATE sys_ai_item SET state='OK', out_text=?"
                             " WHERE job_id=?", (fake, jid2))
                conn.commit()
                r2 = load_ok(conn, jid2, dry=False)
                got = conn.execute(
                    "SELECT body_text FROM sys_book_unit_text WHERE unit_id=?"
                    "  AND text_variant='TRANSLATED'"
                    "  AND UPPER(lang_code)='KO'", (uid,)).fetchone()
                ck(r2['n'] == 1 and bool(got), '도서 승인분이 안 담긴다')
                want = _BA.book_attrib_for(conn, uid, 'TRANSLATED', 'KO')
                ck(bool(got) and got[0].rstrip().endswith(want),
                   '출처 줄을 한 꼴로 안 갈아 끼운다')
                ck(bool(got) and '엉뚱한 책' not in got[0],
                   'AI 가 지어낸 출처 줄이 남는다')
                ck(counts(conn, jid2)['LOADED'] == 1, '적재 상태가 안 남는다')
            finally:
                conn.execute(
                    "DELETE FROM sys_book_unit_text WHERE unit_id=?"
                    "  AND text_variant='TRANSLATED'"
                    "  AND UPPER(lang_code)='KO'", (uid,))
                if keep:
                    conn.execute(
                        "INSERT INTO sys_book_unit_text(unit_id, text_variant,"
                        " lang_code, body_text, record_status)"
                        " VALUES(?,'TRANSLATED','KO',?,'LIVE')",
                        (uid, keep[0]))
                if jid2:
                    conn.execute("DELETE FROM sys_ai_item WHERE job_id=?",
                                 (jid2,))
                    conn.execute("DELETE FROM sys_ai_job WHERE job_id=?",
                                 (jid2,))
                conn.commit()
            back = conn.execute(
                "SELECT COUNT(*) FROM sys_book_unit_text WHERE unit_id=?"
                "  AND text_variant='TRANSLATED'"
                "  AND UPPER(lang_code)='KO'", (uid,)).fetchone()[0]
            ck(back == (1 if keep else 0), '도서 적재 검사가 자국을 남겼다')
    except Exception as e:                                # noqa: BLE001
        import traceback
        traceback.print_exc()
        bad.append('도서 적재 검사에서 터졌다: %s' % e)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:                             # noqa: BLE001
                pass

    # ★★★ 연구자료 칸 (1.txt 16-1) — 게이트 · 적재 · 연결 자동 승인
    conn = None
    try:
        conn = appdb.connect()
        import db_study_gate as _SG
        _src = _study_src_id(conn)
        # ⚠⚠⚠ 317차-5 — **진짜 연구자료가 없는 절**을 고른다. 옛 판은 창 1:1 을 못 박아,
        #   사용자가 그 절에 AI 연구자료를 담은 뒤 이 검사가 **그것을 덮고 지웠다**(실측 · 되살림).
        _have = {r[0] for r in conn.execute("SELECT unit_code FROM sys_ref_unit WHERE unit_code LIKE 'AIV%'")}
        _vid = next((v for (v,) in conn.execute(
            "SELECT verse_id FROM bible_index WHERE bcode=66 ORDER BY verse_id DESC LIMIT 400")
            if (STUDY_CODE % v) not in _have), None)
        ck(bool(_src), '연구 자료 자료집(STUDY_NOTES)이 없다')
        _n0 = conn.execute("SELECT COUNT(*) FROM sys_ref_unit").fetchone()[0]
        _l0 = conn.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
        _note = (_SG._SAMPLE if hasattr(_SG, '_SAMPLE') else '')
        _uid = None
        if _vid and _src and _note:
            try:
                # ① 게이트 — 깨끗한 글은 통과, 기호를 심으면 잡는다
                _g = gate_bundle(conn, _vid, 'KO', AJ.bundle_join({
                    'DESC': '가나다라마 바사아자차 카타파하 문단입니다.',
                    'QUES': '나는 어떻게 살겠습니까?',
                    'PRAYER': '주님 도와주소서.',
                    'NOTE': _note}))
                ck(not any('[연구자료]' in l and '기호로 시작' in l
                           for l in _g['lines']),
                   '깨끗한 연구자료에서 서식 흠이 났다: %s'
                   % ([l for l in _g['lines'] if '[연구자료]' in l][:2],))
                _g2 = gate_bundle(conn, _vid, 'KO', AJ.bundle_join({
                    'DESC': '가나다라마 바사아자차 카타파하 문단입니다.',
                    'QUES': '나는 어떻게 살겠습니까?',
                    'PRAYER': '주님 도와주소서.',
                    'NOTE': _note.replace('1. 본문이', '\u2022 본문이')}))
                ck(any('[연구자료]' in l and '기호로 시작' in l
                       for l in _g2['lines']),
                   '연구자료의 줄머리 기호를 안 잡는다')
                # ★ 317차-19 — 고르지 않은 칸은 재지 않고 「담지 않는다」 알림만
                _g3 = gate_bundle(conn, _vid, 'KO', AJ.bundle_join({
                    'DESC': '가나다라마 바사아자차 카타파하 문단입니다.',
                    'QUES': '나는 어떻게 살겠습니까?',
                    'PRAYER': '주님 도와주소서.',
                    'NOTE': _note.replace('1. 본문이', '\u2022 본문이')}), want='DESC,QUES,PRAYER')
                ck(not any(l.startswith('[연구자료]') for l in _g3['lines'])
                   and any('선택하지 않은 칸' in l and '연구자료' in l for l in _g3['lines']),
                   '선택하지 않은 칸을 게이트가 잰다: %s' % (_g3['lines'][:3],))
                # ★ 317차-19 (42-2) — 연구질문 덧붙이기: 같은 물음(띄어쓰기·부호만 다름)은 안 붙인다
                _sa = study_append('왜 빛이 먼저인가?' + chr(10) + '참고 : 1절',
                                   '왜  빛이 먼저인가 ?' + chr(10) + '참고 : x' + chr(10) * 2 + '새 물음?')
                ck(_sa.count('빛이 먼저') == 1 and _sa.endswith('새 물음?') and (chr(10) * 2) in _sa,
                   '연구질문 덧붙이기 겹침 판정이 틀리다: %r' % _sa)
                ck(study_append('', 'a?') == 'a?' and study_append('a?', 'a?') == 'a?',
                   '빈 글·같은 글 덧붙이기가 틀리다')
                # ★ 317차-19 (42-4) — 구절연결 설명문 「자리」 = 두 약명 + 본문(번호가 아니다)
                _lk = conn.execute("SELECT sys_link_id FROM sys_link_asset WHERE link_type='VERS_VERS'"
                                   " AND record_status='LIVE' LIMIT 1").fetchone()
                if _lk:
                    _st = slot_title(conn, 'VERS_VERS_DESC', _lk[0], str(_lk[0]))
                    ck('↔' in _st and '「' in _st and _st != str(_lk[0]),
                       '구절연결 설명문 자리 이름이 번호로 나온다: %s' % _st)

                # ② 적재 — 유닛 · 본문 · 구절 연결
                _uid, _why = put_study_note(conn, _vid, 'KO', _note)
                conn.commit()
                ck(bool(_uid), '연구자료가 안 담긴다: %s' % _why)
                if _uid:
                    _t = conn.execute(
                        "SELECT title, body_text FROM sys_ref_text "
                        "WHERE ref_unit_id=? AND UPPER(lang_code)='KO'",
                        (_uid,)).fetchone()
                    ck(bool(_t) and _t[0] == _SG.title_of(_note),
                       '첫 줄이 제목으로 안 들어간다')
                    ck(bool(_t) and _SG.title_of(_note) not in _t[1],
                       '제목이 본문에도 남아 두 번 나온다')
                    # ★ 사용자 지시 — 구절 연결은 **자동 승인**
                    _vs = conn.execute(
                        "SELECT target_id, record_status FROM sys_link_asset "
                        "WHERE link_type='REFU_VERS' AND clicked_id=?",
                        (_uid,)).fetchall()
                    ck(all(r[1] == 'LIVE' for r in _vs),
                       '구절 연결이 자동 승인되지 않았다: %s' % (_vs[:3],))
                    ck(any(r[0] == _vid for r in _vs),
                       '이 절이 연결되지 않았다')
                    # ★ 글 안의 인용 절도 함께 걸린다 (창 1:3 · 계 21:23)
                    ck(len(_vs) >= 2,
                       '인용한 절이 연결되지 않았다 — %d개뿐' % len(_vs))
                    # ★ 용어는 **후보로만**
                    _es = conn.execute(
                        "SELECT record_status FROM sys_link_asset "
                        "WHERE link_type='REFU_ENTI' AND clicked_id=?",
                        (_uid,)).fetchall()
                    ck(all(r[0] == 'LIVE' for r in _es),
                       '용어 연결이 안 보이는 상태로 들어갔다: %s' % (_es[:3],))
                    # ★ 검수 화면이 **승인 전에** 알리는가
                    ck(any('인용한 구절' in l for l in _g['lines']),
                       '함께 걸릴 구절을 먼저 알리지 않는다')
                    # ★★★ 314차 — **사람이 손으로 이은 구절을 안 지운다**
                    #   ⚠ 그전에는 `clicked_id` 전체를 지워 다음 적재가
                    #     사람 연결을 쓸어 갔다(탐지력이 이 구멍을 찾았다).
                    #   ⚠ **그 글에 아직 없는 절**을 골라 쓴다 — 데이터 상태를
                    #     전제하면 UNIQUE 로 터진다(§0-5 · 실측으로 당했다).
                    _busy = {r[0] for r in conn.execute(
                        "SELECT target_id FROM sys_link_asset "
                        "WHERE link_type='REFU_VERS' AND clicked_id=?",
                        (_uid,)).fetchall()}
                    _free = next((v for v in range(1, 200) if v not in _busy), None)
                    if _free:
                        conn.execute(
                            "INSERT INTO sys_link_asset(link_type, clicked_id,"
                            " target_id, record_status, source) "
                            "VALUES('REFU_VERS',?,?,'LIVE','TEST_HUMAN_314')",
                            (_uid, _free))
                        conn.commit()
                    put_study_note(conn, _vid, 'KO', _note)
                    conn.commit()
                    if _free:
                        ck(conn.execute(
                            "SELECT COUNT(*) FROM sys_link_asset "
                            "WHERE link_type='REFU_VERS' AND clicked_id=? "
                            "  AND source='TEST_HUMAN_314'",
                            (_uid,)).fetchone()[0] == 1,
                           '★★★ 사람이 이은 구절 연결을 다시 적재가 지웠다')
                    conn.execute("DELETE FROM sys_link_asset "
                                 "WHERE source='TEST_HUMAN_314'")
                    conn.commit()
                    # ★ 다국어 — 영어 글에서도 인용 절이 걸린다(314차)
                    _en = ('Ephod in the Priestly Garments\n'
                           'The term appears in Exod 28:4 and again in '
                           '1 Sam 2:18, which together frame the question.\n'
                           'BSB Exod 28:4 These are the garments they shall '
                           'make: a breastpiece, an ephod, a robe.')
                    _ue, _ = put_study_note(conn, _vid, 'EN', _en)
                    conn.commit()
                    if _ue:
                        _ven = conn.execute(
                            "SELECT COUNT(*) FROM sys_link_asset "
                            "WHERE link_type='REFU_VERS' AND clicked_id=? "
                            "  AND source='AI_STUDY'", (_ue,)).fetchone()[0]
                        ck(_ven >= 3,
                           '★ 영어 글에서 영어 약명을 못 읽는다 — %d건' % _ven)
                    # ★ 멱등 — 두 번 돌려도 유닛이 안 는다
                    _u2, _ = put_study_note(conn, _vid, 'KO', _note)
                    conn.commit()
                    ck(_u2 == _uid, '두 번 돌리면 유닛이 하나 더 생긴다')
                    ck(conn.execute(
                        "SELECT COUNT(*) FROM sys_ref_text WHERE ref_unit_id=?"
                        "  AND UPPER(lang_code)='KO'",
                        (_uid,)).fetchone()[0] == 1, '본문이 두 벌이 된다')
            finally:
                if _uid:
                    conn.execute("DELETE FROM sys_link_asset WHERE clicked_id=?"
                                 "  AND link_type IN ('REFU_VERS','REFU_ENTI')"
                                 "  AND source='AI_STUDY'", (_uid,))
                    conn.execute("DELETE FROM sys_ref_text WHERE ref_unit_id=?",
                                 (_uid,))
                    conn.execute("DELETE FROM sys_ref_unit WHERE ref_unit_id=?",
                                 (_uid,))
                conn.commit()
            _n1 = conn.execute("SELECT COUNT(*) FROM sys_ref_unit").fetchone()[0]
            _l1 = conn.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
            ck(_n1 == _n0 and _l1 == _l0,
               '연구자료 검사가 자국을 남겼다 — 유닛 %d→%d · 연결 %d→%d'
               % (_n0, _n1, _l0, _l1))
    except Exception as e:                                # noqa: BLE001
        import traceback
        traceback.print_exc()
        bad.append('연구자료 검사에서 터졌다: %s' % e)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:                             # noqa: BLE001
                pass

    # ★★★ 317차-5 — 묶음 비교 · 「지금 글 유지」 칸은 안 담는다(docs/1.txt 4-2))
    #   ⚠ **글이 하나도 없는 절**에서만 잰다 — 남의 글을 덮지 않는다 · 끝에 자국 0
    conn = None
    try:
        conn = appdb.connect()
        _busy = {r[0] for r in conn.execute(
            "SELECT DISTINCT clicked_id FROM sys_text_asset WHERE text_type IN"
            " ('VERS_DESC','VERS_QUESTION','VERS_PRAYER')")}
        _kv = next((v for (v,) in conn.execute(
            "SELECT verse_id FROM bible_index ORDER BY verse_id DESC") if v not in _busy), None)
        ck(bool(_kv), "묶음 비교 시험 — 글 없는 절이 하나는 있다")
        if _kv:
            _kj = None
            try:
                _kj, _n = create_job(conn, 'VERS_BUNDLE', '', 'NEW', 'KO', [_kv], base='KO',
                                     name='__selftest_keep__', parts=['DESC', 'QUES', 'PRAYER'])
                _ki = conn.execute("SELECT item_id FROM sys_ai_item WHERE job_id=?", (_kj,)).fetchone()[0]
                _kt = AJ.bundle_join({'DESC': '새 설명 문단입니다.', 'QUES': '나는 어떻게 살겠습니까?',
                                      'PRAYER': '주님 도와주소서.'})
                conn.execute("UPDATE sys_ai_item SET state='DONE', out_text=? WHERE item_id=?", (_kt, _ki))
                conn.commit()
                _cm = bundle_compare(conn, job(conn, _kj), _kv, _kt)
                ck({x[0]: x[4] for x in _cm}.get('DESC') == '새로 담음',
                   '빈 절이면 「새로 담음」: %s' % [(x[0], x[4]) for x in _cm])
                judge(conn, [_ki], 'OK', keep=['DESC'])
                load_ok(conn, _kj, dry=False)
                _got = {r[0] for r in conn.execute(
                    "SELECT text_type FROM sys_text_asset WHERE clicked_id=? AND lang_code='KO'"
                    " AND text_type IN ('VERS_DESC','VERS_QUESTION','VERS_PRAYER')", (_kv,))}
                ck('VERS_DESC' not in _got and {'VERS_QUESTION', 'VERS_PRAYER'} <= _got,
                   '★★★ 「지금 글 유지」 칸은 안 담고 나머지는 담는다: %s' % _got)
            finally:
                conn.execute("DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type IN"
                             " ('VERS_DESC','VERS_QUESTION','VERS_PRAYER')", (_kv,))
                if _kj:
                    conn.execute("DELETE FROM sys_ai_item WHERE job_id=?", (_kj,))
                    conn.execute("DELETE FROM sys_ai_job WHERE job_id=?", (_kj,))
                conn.commit()
    except Exception as e:                                # noqa: BLE001
        import traceback
        traceback.print_exc()
        bad.append('묶음 비교 검사에서 터졌다: %s' % e)
    finally:
        if conn is not None:
            conn.close()

    # ★ 번역·다듬기 경로(`REF_UNIT`)도 같은 서식 게이트를 탄다 (16-1 · 3)
    #   ⚠ 읽기만 한다 — 자국이 남을 수 없으므로 청소가 필요 없다.
    conn = None
    try:
        conn = appdb.connect()
        import db_study_gate as _SG2
        _ru = conn.execute(
            "SELECT u.ref_unit_id FROM sys_ref_unit u JOIN sys_ref_source s"
            "  ON s.ref_src_id=u.ref_src_id WHERE s.src_code=? LIMIT 1",
            (STUDY_SRC,)).fetchone()
        _rq = conn.execute(
            "SELECT u.ref_unit_id FROM sys_ref_unit u JOIN sys_ref_source s"
            "  ON s.ref_src_id=u.ref_src_id WHERE s.src_code<>? LIMIT 1",
            (STUDY_SRC,)).fetchone()
        if _ru:
            ck(_is_study_unit(conn, _ru[0]), '연구자료 유닛을 못 알아본다')
            # ★ 2026-10-11 — 한국어 견본을 일본어 번역이라 하면 이제 「써 넣을 언어」 게이트가 막는다(옳다)
            ck(any('써 넣을 언어' in l for l in gate_item(conn, 'REF_UNIT', _ru[0], 'JA', _SG2._SAMPLE,
                                                     task='TRANS')['lines']),
               '한국어 글을 일본어 번역으로 받는다')
            ck(gate_item(conn, 'REF_UNIT', _ru[0], 'JA',
                         _SG2._SAMPLE.replace('1. 본문이', '• 본문이'),
                         task='TRANS')['ok'] is False,
               '번역문의 줄머리 기호를 안 잡는다')
        if _rq:
            # ⚠ 수입 자료집에 우리 서식 잣대를 대면 남의 글을 흔으로 신고한다
            ck(not _is_study_unit(conn, _rq[0]),
               '수입 자료집을 연구자료라 한다')
            # ★ 294차 — 번역에는 **번역 공통 게이트**가 걸리므로 `ok` 가
            #   `None` 이 아니다. 묻는 것은 「우리 서식(줄머리 기호·음독)을
            #   남의 글에 대지 않는가」다.
            _rg = gate_item(conn, 'REF_UNIT', _rq[0], 'JA', '아무 글',
                            task='TRANS')
            ck(not any(('줄머리' in l or '음독' in l or '제목' in l)
                       for l in _rg['lines']),
               '수입 자료집에 우리 서식 잣대를 대고 있다')
            ck(_rg['ok'] is not None,
               '수입 자료집 번역에 번역 공통 게이트가 안 걸린다')
    except Exception as e:                                # noqa: BLE001
        bad.append('자료집 게이트 검사에서 터졌다: %s' % e)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:                             # noqa: BLE001
                pass

    # ── 묶음 게이트 (278차) ─────────────────────────────────────
    try:
        conn = appdb.connect()
        _vid = conn.execute(
            "SELECT verse_id FROM bible_index WHERE bcode=19 AND chapter=11 "
            "AND verse=1").fetchone()[0]
        # ⚠ 설명문은 **문단이 있어야** 한다 — 한 덩이로 주면 진짜 「문단없음」이
        #   떠서 이 검사가 헛돈다(실측으로 당했다).
        _ok = AJ.bundle_join({
            'DESC': ('다윗은 피난처를 하나님 안에서 찾습니다. ' * 3 +
                     chr(10) + chr(10) +
                     '그는 흔들리는 자리에서도 주를 바라봅니다. ' * 3),
            'QUES': '나는 위기 앞에서 무엇을 먼저 붙듭니까?',
            'PRAYER': '주님, 흔들릴 때 주를 붙들게 하소서.',
        })
        g = gate_bundle(conn, _vid, 'KO', _ok)
        ck(g['ok'] is True, '멀쩡한 묶음을 걸러 낸다: %s' % (g['lines'][:2],))
        # 마커를 지우면 **거부**
        g2 = gate_bundle(conn, _vid, 'KO', '그냥 글입니다.')
        ck(g2['ok'] is False and '가르지 못' in ' '.join(g2['lines']),
           '마커가 없는데 통과시킨다')
        # 필수 칸이 빠지면 거부
        g3 = gate_bundle(conn, _vid, 'KO', '[설명문]\n가나다라마바사.')
        ck(g3['ok'] is False, '반쪽인데 통과시킨다')
        # ★ 되풀이 탐지 — 두 칸에 **같은 글**을 넣으면 잡아야 한다
        _same = '주님 앞에서 흔들리지 않는 믿음을 구하며 오늘도 나아갑니다.'
        g4 = gate_bundle(conn, _vid, 'KO', AJ.bundle_join(
            {'DESC': _same * 4, 'QUES': _same + ' 나는 그렇습니까?',
             'PRAYER': '주님 도와주소서.'}))
        ck(g4['ok'] is False and any('되풀이' in l for l in g4['lines']),
           '두 칸이 같은 말인데 못 잡는다: %s' % (g4['lines'][:3],))
        # ★ 모양 — 묵상기도에 물음표가 있으면 잡는다
        g5 = gate_bundle(conn, _vid, 'KO', AJ.bundle_join(
            {'DESC': '다윗이 하나님을 피난처로 삼습니다. ' * 8,
             'QUES': '나는 무엇을 붙듭니까?',
             'PRAYER': '주님, 제가 그렇게 살고 있습니까?'}))
        ck(any('물음표' in l for l in g5['lines']),
           '기도에 물음표가 있는데 못 잡는다')
        # ★ 연구질문이 없는 것은 **흠이 아니다**
        ck(g['ok'] is True, '연구질문이 없다고 흠으로 센다')
        # ★ 번역인데 안 옮겼다 — 양방향
        _ko = AJ.bundle_join({
            'DESC': '다윗은 하나님을 피난처로 삼습니다. ' * 6,
            'QUES': '나는 무엇을 붙듭니까?', 'PRAYER': '주님 도와주소서.'})
        g6 = gate_bundle(conn, _vid, 'EN', _ko, task='TRANS')
        ck(g6['ok'] is False and any('옮기지 않았' in l for l in g6['lines']),
           '번역인데 한국어 그대로인 것을 못 잡는다: %s' % (g6['lines'][:2],))
        _en = AJ.bundle_join({
            'DESC': 'David takes refuge in God alone every single day. ' * 4,
            'QUES': 'What do you hold on to today?',
            'PRAYER': 'Lord, please help me to stand firm.'})
        g7 = gate_bundle(conn, _vid, 'EN', _en, task='TRANS')
        ck(not any('옮기지 않았' in l for l in g7['lines']),
           '제대로 옮긴 글을 「안 옮겼다」고 한다: %s' % (g7['lines'][:2],))
        ck(not_translated(_ko, 'KO')[1] is False,
           'KO 로 옮기는데 한글을 흠이라 한다')
        # ★ 재료가 뒤에 붙어도 **칸을 끊어 낸다**
        _leak = AJ.bundle_join({
            'DESC': '다윗은 하나님을 피난처로 삼습니다. ' * 6,
            'QUES': '나는 무엇을 붙듭니까?',
            'PRAYER': '주님 도와주소서.'}) + (
            chr(10) + '[구절]' + chr(10) + '시 1:1' +
            chr(10) + '[본문 (BSB)]' + chr(10) + 'Blessed is the man')
        _p, _w = AJ.bundle_split(_leak)
        ck(_p is not None and 'Blessed' not in (_p.get('PRAYER') or ''),
           '재료가 마지막 칸에 섞여 들어간다: %r' % (_p or {}).get('PRAYER'))
        ck(_p is not None and _p.get('_alien'),
           '재료가 섞였는데 알리지 않는다')
        # ★ 칸마다 **제 잣대**로 잰다 — 한 문단짜리 묵상질문·기도가
        #   「문단없음」으로 걸리면 안 된다(레 19:18 실측으로 당했다)
        ck(not any('문단없음' in l for l in g['lines']),
           '한 문단짜리 질문·기도를 「문단없음」으로 잡는다: %s'
           % [l for l in g['lines'] if '문단없음' in l][:2])
        g8 = gate_bundle(conn, _vid, 'KO', _leak)
        ck(any('재료를 되받아' in l for l in g8['lines']),
           '재료 되받기를 게이트가 말하지 않는다')
        conn.close()
    except Exception as e:                                # noqa: BLE001
        ck(False, '묶음 게이트 검사가 터졌다: %s' % e)
    # ── 294차 — 게이트 등록표 · 번역 공통 게이트 · 반려 사유 ─────────────
    _used = set()
    for _k in AJ.ASSET:
        for _t in ('NEW', 'TRANS', 'EDIT'):
            _used |= set(gates_for(_k, _t))
    ck(all(k in GATE_NAME for k in _used), 'gates_for 가 등록표에 없는 열쇠를 낸다')
    ck(not [k for k in GATE_NAME if k not in _used],
       '등록표의 게이트가 어느 자산·업무에도 안 걸린다: %s'
       % [k for k in GATE_NAME if k not in _used])
    ck({lv for _k, _n, lv, _w, _r in GATE_CATALOG} == {'MUST', 'NOTE'},
       '등록표 갈래가 필수·참고 둘이 아니다')
    ck('structure' in gates_for('VERS_DESC_LAY', 'NEW')
       and 'structure' not in gates_for('VERS_DESC_LAY', 'TRANS'),
       '구조 게이트가 번역에도 걸린다고 한다(실행 분기와 다르다)')
    ck('trans_paras' in gates_for('COMMENTARY', 'TRANS')
       and 'trans_paras' not in gates_for('COMMENTARY', 'EDIT'),
       '번역 공통 게이트가 번역 아닌 업무에 걸린다고 한다')
    ck('taste' in gates_for('BOOK_TASTE', 'TRANS')
       and 'trans_paras' not in gates_for('BOOK_TASTE', 'TRANS'),
       '맛보기에 번역 공통 문단 게이트가 겹친다')
    # ── 295차 — 우리 글 일곱의 게이트(양방향) ─────────────────────────
    ck('ours' in gates_for('VERS_VERS_DESC', 'NEW') and 'ours' in gates_for('PERI_TITLE', 'EDIT'),
       '우리 글 자산에 꼴 게이트가 안 걸린다')
    ck('peri_style' in gates_for('CHAP_DESC', 'NEW') and 'peri_style' not in gates_for('ENTITY_DESC', 'NEW'),
       '단락·장 문체 게이트가 엉뚱한 자산에 걸린다')
    ck('ours' not in gates_for('BOOK_UNIT', 'NEW') and 'ours' not in gates_for('VERS_DESC_LAY', 'NEW'),
       '우리 글 꼴 게이트가 남의 글·절 자산에 걸린다')
    try:
        conn = appdb.connect()
        _clean = ('창조의 첫 말씀이 일곱째 날의 안식으로 이어지는 자리입니다. '
                  '시작하신 분이 마치신다는 약속이 두 본문을 한 줄로 잇습니다.')
        ck(not [l for l in ours_lines(conn, 'VERS_VERS_DESC', 1, 'KO', _clean) if not _is_note(l)],
           '깨끗한 연결 설명문이 꼴 게이트에 걸린다: %s'
           % ours_lines(conn, 'VERS_VERS_DESC', 1, 'KO', _clean))
        ck(any('대시' in l for l in ours_lines(conn, 'VERS_VERS_DESC', 1, 'KO', '빛 — 첫날의 것입니다.')),
           '대시를 안 잡는다')
        ck(any('합니다체' in l for l in ours_lines(conn, 'VERS_VERS_DESC', 1, 'KO', '빛이 첫날의 것이다.')),
           '평서체 연결 설명문을 안 잡는다')
        ck(any('교단' in l for l in ours_lines(conn, 'BOOK_DESC', 1, 'KO', '개혁주의 전통이 ' + '읽어 온 책입니다. ' * 20)),
           '교단 귀속어를 안 잡는다')
        ck(any('원어' in l for l in ours_lines(conn, 'VERS_VERS_DESC', 1, 'KO', '빛(אור)이 첫날의 것입니다.')),
           '원어 글자 노출을 안 잡는다')
        ck(any('문장 꼴' in l for l in ours_lines(conn, 'PERI_TITLE', 1, 'KO', '빛이 창조되었다')),
           '문장 꼴 제목을 안 잡는다')
        ck(not ours_lines(conn, 'PERI_TITLE', 1, 'KO', '빛의 창조'), '멀쩡한 제목이 걸린다')
        ck(any('한 줄' in l for l in ours_lines(conn, 'ENTITY_NAME', 1, 'KO', '인애 · 헤세드' + chr(10) + '둘째 줄')),
           '두 줄 이름을 안 잡는다')
        ck(any('접두' in l for l in ours_lines(conn, 'VERS_VERS_DESC', 1, 'KO', '[PRG] 빛이 자라납니다.')),
           '관점 접두를 안 잡는다')
        _g = gate_item(conn, 'VERS_VERS_DESC', 1, 'KO', '빛이 첫날의 것이다 — 그렇다.')
        ck(_g['ok'] is False and not any('아직 기계 게이트가 없습니다' in l for l in _g['lines']),
           '구절연결 설명문이 여전히 「게이트 없음」으로 통과한다: %s' % _g)
        conn.close()
    except Exception as e:                                # noqa: BLE001
        ck(False, '우리 글 꼴 게이트 검사가 터졌다: %s' % e)
    _rows = gate_rows('BOOK_UNIT', 'TRANS')
    ck(len(_rows) == len(GATE_CATALOG) and any(r[5] for r in _rows)
       and not all(r[5] for r in _rows), '화면용 게이트 줄이 걸림 여부를 안 가른다')
    # 번역 공통 — 양방향
    _S = '첫 문단.' + chr(10) + '둘째 문단.'
    ck(not [l for l in trans_common(_S, '一。' + chr(10) + '二。', 'KO', 'JA')
            if not l.startswith('(')], '깨끗한 번역이 번역 공통 게이트에 걸린다')
    ck(any('문단' in l for l in trans_common(_S, '하나.', 'KO', 'EN')),
       '문단 수 어긋남을 안 잡는다')
    ck(any('빈 줄' in l for l in trans_common(_S, 'a.' + chr(10) * 3 + 'b.', 'KO', 'EN')),
       '군더더기 빈 줄을 안 잡는다')
    ck(any('히브리' in l for l in trans_common(_S, 'a.' + chr(10) + 'b חֶסֶד.', 'KO', 'EN')),
       '원본에 없는 원어 낱자를 안 잡는다')
    ck(not any('히브리' in l for l in trans_common('חֶסֶד.' + chr(10) + 'b.',
                                                    'a חֶסֶד.' + chr(10) + 'b.', 'KO', 'EN')),
       '원본에 있는 원어 낱자를 흠으로 잡는다')
    ck(any('숫자' in l for l in trans_common('a', 'الآية ٣ و 16', 'EN', 'AR')),
       '아랍어 숫자 혼용을 안 잡는다')
    ck(not any('숫자' in l for l in trans_common('a', 'الآية 3 و 16', 'EN', 'AR')),
       '한 가지 숫자만 쓴 아랍어를 흠으로 잡는다')
    ck(any('서식' in l for l in trans_common('a', '**제목**' + chr(10) + '본문', 'EN', 'KO')),
       '마크다운 굵게 머리를 안 잡는다')
    ck(any('서식' in l for l in trans_common('a', '번역: 본문', 'EN', 'KO')),
       '「번역:」 머리말을 안 잡는다')
    # ★ 2026-10-27 뜻 검사 — 사라 「아내 → 아들」 · 이름 빠짐 · 책 이름은 약명이 되므로 안 잡는다(양방향)
    try:
        import appdb as _adb
        _mc = _adb.connect()
        _S1 = 'Sarah was the wife of Abraham (Genesis 11:29).'
        ck(any('「아들」' in l for l in trans_meaning(_mc, _S1, '사라는 아브라함의 아들이었다(창 11:29).', 'EN', 'KO')),
           '원문에 없는 「아들」 을 안 잡는다')
        ck(not trans_meaning(_mc, _S1, '사라는 아브라함의 아내였다(창 11:29).', 'EN', 'KO'),
           '맞는 번역을 흠으로 잡는다(책 이름 Genesis 포함)')
        ck(any('여호수아' in l for l in trans_meaning(_mc, 'Joshua cursed Jericho.', '여호와께서 여리고를 저주하셨다.', 'EN', 'KO')),
           '여호수아 → 여호와 를 안 잡는다')
        ck('Sarah = 사라' in AJ.name_glossary(_mc, _S1, 'EN', 'KO'), '이름 용어집에 사라가 없다')
        ck(AJ.name_glossary(_mc, _S1, 'EN', 'EN') == '', '같은 언어인데 용어집을 싣는다')
        _mc.close()
    except Exception as e:                                # noqa: BLE001
        ck(False, '뜻 검사 시험이 터졌다: %s' % e)
    _en = 'The word of the Lord came to him and he went out to the field to see ' * 3
    ck(any('옮기지 않았습니다' in l for l in trans_common('가', _en, 'EN', 'KO')),
       '영문이 그대로 남은 한국어 번역을 안 잡는다')
    ck(not any('옮기지' in l for l in trans_common('가', _en, 'EN', 'DE')),
       '같은 글자체계(라틴↔라틴)에서 잔존을 잡는다')
    ck(any('길이비' in l for l in trans_common('가' * 100, '나', 'KO', 'JA')),
       '길이비 알림이 없다')
    ck(all(l.startswith('(') for l in trans_common('가' * 100, '나', 'KO', 'JA')
           if '길이비' in l), '길이비가 알림이 아니라 흠으로 나온다')
    ck(trans_common('a', '', 'KO', 'EN') == ['빈 글입니다.'], '빈 글을 못 잡는다')
    # 반려 사유 — 메모리 DB
    try:
        import sqlite3 as _sq
        _m = _sq.connect(':memory:')
        _m.executescript(SCHEMA)
        _m.execute("INSERT INTO sys_ai_job(job_id, name, asset_kind, scope_value, task,"
                   " base_lang, lang, model, cap_chars, created_at)"
                   " VALUES(1,'t','BOOK_UNIT','','TRANS','EN','KO','x',6000,'2026')")
        _m.execute("INSERT INTO sys_ai_item(item_id, job_id, slot_id, label, state, out_text)"
                   " VALUES(1,1,1,'a','DONE','받은 글')")
        _m.commit()
        judge(_m, [1], 'REJ', why='억지 비유')
        _r = _m.execute("SELECT state, why FROM sys_ai_item WHERE item_id=1").fetchone()
        ck(_r == ('REJ', '억지 비유'), '반려 사유가 안 담긴다 %s' % (_r,))
        _rr = reject_reasons(_m)
        ck(len(_rr) == 1 and _rr[0][3] == '억지 비유' and _rr[0][0] == 'BOOK_UNIT',
           '반려 사유 목록이 다르다 %s' % (_rr,))
        judge(_m, [1], 'OK')
        ck(_m.execute("SELECT why FROM sys_ai_item WHERE item_id=1").fetchone()[0] == '억지 비유',
           '사유를 안 줬는데 판정이 옛 사유를 지웠다')
        ck(reject_reasons(_m) == [], '승인한 건이 반려 사유 목록에 남는다')
        _m.close()
    except Exception as e:                                # noqa: BLE001
        ck(False, '반려 사유 검사가 터졐다: %s' % e)

    # ★★★ 295차 — regate: 검수 대기 건의 옛 게이트 줄을 지금 게이트로 갈아 끼운다
    try:
        import appdb as _adb
        _c = _adb.connect()
        _jid = None
        try:
            ensure(_c)
            # ⚠ SAVEPOINT 는 못 쓴다 — `regate`·`create_job` 이 commit 을 부르면
            #   저장점이 함께 끝난다(실측 「no such savepoint」). 시험 작업을 실제로
            #   만들고 끝에 통째로 지운다(하네스와 같은 방식 · 자국 0).
            _jid, _n = create_job(_c, 'VERS_VERS_DESC', '', 'NEW', 'KO',
                                  [9999901, 9999902], name='__selftest_regate__',
                                  base='KO')
            if _jid:
                _its = [r[0] for r in _c.execute(
                    "SELECT item_id FROM sys_ai_item WHERE job_id=? ORDER BY item_id",
                    (_jid,)).fetchall()]
                _stale = json.dumps({'ok': None, 'lines': [
                    '검사가 터졌다(check_structure): SQLite objects created in a thread']},
                    ensure_ascii=False)
                _good = ('앞 구절이 말한 약속이 뒤 구절에서 그대로 이루어집니다. '
                         '두 본문이 같은 낱말로 이어지는 자리입니다.')
                _c.execute("UPDATE sys_ai_item SET state='DONE', out_text=?, gate_json=?"
                           " WHERE item_id=?", (_good, _stale, _its[0]))
                _c.execute("UPDATE sys_ai_item SET state='OK', out_text=?, gate_json=?"
                           " WHERE item_id=?", (_good, _stale, _its[1]))
                _r = regate(_c, _jid)
                _g0 = json.loads(_c.execute("SELECT gate_json FROM sys_ai_item WHERE item_id=?",
                                            (_its[0],)).fetchone()[0])
                _g1 = _c.execute("SELECT gate_json FROM sys_ai_item WHERE item_id=?",
                                 (_its[1],)).fetchone()[0]
                ck(_r['items'] == 1 and _r['changed'] == 1,
                   'regate 가 DONE 한 건만 다시 잰다: %s' % _r)
                ck(not any('터졌다' in l for l in _g0.get('lines') or []),
                   'regate 뒤 옛 스레드 오류 줄이 사라진다: %s' % (_g0.get('lines') or [])[:2])
                ck(_g1 == _stale, 'regate 가 사람이 판정한 건(OK)은 안 건드린다')
                _r2 = regate(_c, _jid, dry=True)
                ck(_r2['changed'] == 0, 'regate 는 멱등(두 번째는 바뀐 것 0): %s' % _r2)
        finally:
            # 이름으로 걷는다 — 만들다 죽은 것(§257차 ㊴ 「죽었을 때가 기본 상정」)까지
            for (_j,) in _c.execute("SELECT job_id FROM sys_ai_job WHERE name=?",
                                    ('__selftest_regate__',)).fetchall():
                _c.execute("DELETE FROM sys_ai_item WHERE job_id=?", (_j,))
                _c.execute("DELETE FROM sys_ai_job WHERE job_id=?", (_j,))
            _c.commit()
            _c.close()
    except Exception as _e:                               # noqa: BLE001
        ck(False, 'regate 자가검증이 터졌다: %r' % (_e,))

    # ★★★ 297차 — 구절 연결기: 게이트 양방향 · 적재 왕복 · 연결설명문 작업 자동 생성
    try:
        import appdb as _adb
        _c = _adb.connect()
        _jid = None
        _jids = []
        try:
            ensure(_c)
            _v = _c.execute("SELECT verse_id FROM bible_index WHERE bcode=1 AND chapter=1 AND verse=1").fetchone()[0]
            _good = ('요 1:3 · PRG · 태초의 창조가 말씀으로 말미암은 창조로 자랍니다.' + chr(10) +
                     '시 33:6 · SYN · 말씀으로 하늘이 지어졌다는 사상을 함께 말합니다.' + chr(10) +
                     '히 11:3 · SUP · 믿음으로 세계가 말씀으로 지어진 줄을 안다고 증언합니다.')
            _ls = link_lines(_c, _v, _good)
            ck(not [l for l in _ls if not _is_note(l)], '깨끗한 연결 줄은 통과: %s' % _ls)
            _ls = link_lines(_c, _v, '창 1:2 · PRG · 같은 장의 이웃 절입니다 그런데 길게')
            ck(any('같은 장' in l for l in _ls), '같은 장 안의 절을 잡는다')
            _ls = link_lines(_c, _v, '요 1:3 · XYZ · 모르는 갈래로 이었습니다 길게 적음')
            ck(any('열두 갈래 밖' in l for l in _ls), '열두 갈래 밖 코드를 잡는다')
            _ls = link_lines(_c, _v, '없는책 3:3 · PRG · 좌표가 안 풀리는 절입니다 길게')
            ck(any('못 푼 절' in l for l in _ls), '못 푸는 절 표기를 잡는다')
            _ls = link_lines(_c, _v, '그냥 문장입니다')
            ck(any('못 읽은 줄' in l for l in _ls), '꼴이 아닌 줄을 잡는다')
            ck(gates_for('VERS_LINK', 'NEW') == ['link_form', 'link_ref', 'link_rel', 'link_near', 'link_dup',
                                                 'link_kind'],
               '연결기 게이트 여섯이 등록표대로 걸린다')
            # ★ 2026-10-11 — 갈래 판정 알림(막지 않는다 · 괄호로 시작)
            _gen = _c.execute("SELECT verse_id FROM bible_index WHERE bcode=1 AND chapter=1 AND verse=1").fetchone()[0]
            _ls = link_kind_notes(_c, _gen, [('사 7:14', _c.execute(
                "SELECT verse_id FROM bible_index WHERE bcode=23 AND chapter=7 AND verse=14").fetchone()[0],
                'FUL', '', ''), ('시 22:1', _c.execute(
                "SELECT verse_id FROM bible_index WHERE bcode=19 AND chapter=22 AND verse=1").fetchone()[0],
                'INC', '', '')])
            ck(any('FUL' in l for l in _ls) and any('INC' in l for l in _ls) and all(_is_note(l) for l in _ls),
               '구약 안 FUL·신약 없는 INC 를 알림으로 낸다')
            _ls = link_kind_notes(_c, _gen, [('요 1:1', _c.execute(
                "SELECT verse_id FROM bible_index WHERE bcode=43 AND chapter=1 AND verse=1").fetchone()[0],
                'FUL', '', '')])
            ck(not any('FUL' in l for l in _ls), '신·구약을 건너는 FUL 은 알리지 않는다')
            # 적재 왕복 — 시험 작업 · 자국은 source 로 걷는다
            _jid, _n = create_job(_c, 'VERS_LINK', '', 'NEW', 'KO', [_v], base='KO',
                                  name='__selftest_link__')
            _iid = _c.execute("SELECT item_id FROM sys_ai_item WHERE job_id=?", (_jid,)).fetchone()[0]
            _uniq = '요 1:3 · PRG · 자가검증 줄입니다 — 태초의 창조가 말씀의 창조로 자랍니다.'
            _c.execute("UPDATE sys_ai_item SET state='OK', out_text=? WHERE item_id=?", (_uniq, _iid))
            _c.commit()
            _n0 = _c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE source=?", ('AILINK:%d' % _jid,)).fetchone()[0]
            _d = load_ok(_c, _jid, dry=True)
            ck(_d['n'] == 1 and _d['desc_job'] is None, '미리보기는 세기만 한다: %s' % _d)
            _r = load_ok(_c, _jid, dry=False)
            _n1 = _c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE source=?", ('AILINK:%d' % _jid,)).fetchone()[0]
            ck(_r['n'] == 1 and _n1 == _n0 + 1, '★★★ 연결이 실제로 담긴다(source=AILINK): %s' % _r)
            _row = _c.execute("SELECT clicked_id, target_id, rel_code, confidence FROM sys_link_asset WHERE source=?",
                              ('AILINK:%d' % _jid,)).fetchone()
            ck(_row and _row[0] < _row[1] and _row[2] == 'PRG' and _row[3] == 'AI',
               '작은 번호가 앞(§28-7) · 갈래 · confidence=AI: %s' % (_row,))
            ck(_r['desc_job'] and _c.execute("SELECT asset_kind FROM sys_ai_job WHERE job_id=?",
                                             (_r['desc_job'],)).fetchone()[0] == 'VERS_VERS_DESC',
               '★★★ 연결설명문 작업이 저절로 생긴다: %s' % _r['desc_job'])
            _r2 = load_ok(_c, _jid, dry=False)
            ck(_c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE source=?", ('AILINK:%d' % _jid,)).fetchone()[0] == _n0 + 1,
               '두 번 담아도 링크는 하나(멱등)')
            ck(_c.execute("SELECT state FROM sys_ai_item WHERE item_id=?", (_iid,)).fetchone()[0] == 'LOADED',
               '담은 건은 LOADED')
            # ★ 317차-5 — 「연결설명문 함께 작성」: 따로 작업 없이 줄의 설명이 그대로 담긴다
            _jid2, _n = create_job(_c, 'VERS_LINK', '', 'NEW', 'KO', [_v], base='KO',
                                   name='__selftest_link__', add_mode='LINKDESC')
            _iid2 = _c.execute("SELECT item_id FROM sys_ai_item WHERE job_id=?", (_jid2,)).fetchone()[0]
            _dsc = '말씀으로 하늘을 지으셨다는 시인의 노래가 태초의 창조를 다시 들려줍니다.'
            _c.execute("UPDATE sys_ai_item SET state='OK', out_text=? WHERE item_id=?",
                       ('시 33:6 · SYN · ' + _dsc, _iid2))
            _c.commit()
            _jids.append(_jid2)
            _r3 = load_ok(_c, _jid2, dry=False)
            _lid = _c.execute("SELECT sys_link_id FROM sys_link_asset WHERE source=?",
                              ('AILINK:%d' % _jid2,)).fetchone()
            _txt = _c.execute("SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type='VERS_VERS_DESC'"
                              " AND lang_code='KO'", (_lid[0],)).fetchone() if _lid else None
            ck(_r3['desc_job'] is None and _txt and _txt[0] == _dsc,
               '★★★ 연결설명문 함께 작성 — 따로 작업 없이 설명이 담긴다: %s' % (_r3,))
            # ★★★ 317차-5 — 연결 점검(다듬기): 해제 = HIDE · 바꿈 = 갈래만 · 끝에 글자 그대로 되돌린다
            _rv = AJ.review_links(_c, _v)
            ck(len(_rv) >= 2, '점검 시험 재료 — 이어진 연결이 둘 이상: %d' % len(_rv))
            if len(_rv) >= 2:
                _keep = [tuple(r) for r in _c.execute(
                    "SELECT sys_link_id, record_status, rel_code, note FROM sys_link_asset WHERE sys_link_id IN (?,?)",
                    (_rv[0][0], _rv[1][0]))]
                _newrel = 'SYN' if _rv[1][2] != 'SYN' else 'ALL'
                _out = ('%s · %s · 해제 · 시험 줄입니다.' % (AJ._ref(_c, _rv[0][1]), _rv[0][2]) + chr(10) +
                        '%s · %s · 바꿈:%s · 시험 줄입니다.' % (AJ._ref(_c, _rv[1][1]), _rv[1][2], _newrel))
                _gl = link_review_lines(_c, _v, _out)
                ck(not [l for l in _gl if not _is_note(l)], '점검 줄 게이트 통과: %s' % _gl)
                ck(any('지금 이어진 연결이 아닌' in l for l in
                       link_review_lines(_c, _v, '몬 1:13 · ILL · 해제 · 없는 연결입니다.')),
                   '없는 연결을 해제하려는 줄을 잡는다')
                ck(gates_for('VERS_LINK', 'EDIT') == ['link_review'], '점검 게이트는 link_review 하나')
                try:
                    _jid3, _n = create_job(_c, 'VERS_LINK', '', 'EDIT', 'KO', [_v], base='KO',
                                           name='__selftest_link__')
                    _jids.append(_jid3)
                    _c.execute("UPDATE sys_ai_item SET state='OK', out_text=? WHERE job_id=?", (_out, _jid3))
                    _c.commit()
                    _d3 = load_ok(_c, _jid3, dry=True)
                    ck(_d3['n'] == 2, '점검 미리보기 = 해제 1 · 바꿈 1: %s' % _d3)
                    load_ok(_c, _jid3, dry=False)
                    _s0 = _c.execute("SELECT record_status FROM sys_link_asset WHERE sys_link_id=?", (_rv[0][0],)).fetchone()[0]
                    _s1 = _c.execute("SELECT record_status, rel_code FROM sys_link_asset WHERE sys_link_id=?", (_rv[1][0],)).fetchone()
                    ck(_s0 == 'HIDE', '★★★ 해제 = HIDE(지우지 않는다): %s' % _s0)
                    ck(_s1[0] == 'HIDE' or _s1[1] == _newrel, '★★★ 바꿈 = 갈래만 고친다: %s' % (_s1,))
                finally:
                    for _lid, _st, _rl, _nt in _keep:
                        _c.execute("UPDATE sys_link_asset SET record_status=?, rel_code=?, note=? WHERE sys_link_id=?",
                                   (_st, _rl, _nt, _lid))
                    _c.commit()
                ck([tuple(r) for r in _c.execute(
                    "SELECT sys_link_id, record_status, rel_code, note FROM sys_link_asset WHERE sys_link_id IN (?,?)",
                    (_rv[0][0], _rv[1][0]))] == _keep, '점검 시험 자국 0(글자 그대로 되돌림)')
            # ★★★ 317차-20 — 해제분석(VERS_UNLINK) = **물리삭제**(연결설명문 함께) · 구속사연결은 남긴다
            _far = _c.execute("SELECT verse_id FROM bible_index WHERE bcode=66 AND chapter=22 AND verse=20").fetchone()[0]
            _far2 = _c.execute("SELECT verse_id FROM bible_index WHERE bcode=66 AND chapter=22 AND verse=19").fetchone()[0]
            _tl = []
            try:
                for _tv, _ch in ((_far, None), (_far2, 'SELFTEST_CHAIN')):
                    _a, _b = sorted((_v, _tv))
                    _c.execute("INSERT INTO sys_link_asset(link_type, clicked_id, target_id, rel_code, chain_code,"
                               " source, record_status) VALUES('VERS_VERS',?,?,'SYN',?,'SELFTEST_UNLINK','LIVE')",
                               (_a, _b, _ch))
                    _lk = _c.execute("SELECT last_insert_rowid()").fetchone()[0]
                    _tl.append(_lk)
                    _c.execute("INSERT INTO sys_text_asset(clicked_id, text_type, contents, lang_code, record_status)"
                               " VALUES(?,'VERS_VERS_DESC','시험',?,'LIVE')", (_lk, 'KO'))
                _c.commit()
                _bl = AJ.link_blacklist(_c)
                ck(any(l == _tl[0] and '설명문 짧음' in f for l, f in _bl.get(_v, [])),
                   '블랙리스트가 짧은 설명문 연결을 못 잡는다')
                ck(_v in dict(AJ.slots(_c, 'VERS_UNLINK', '')) and AJ.have(_c, 'VERS_UNLINK').get(_v) == set(),
                   '해제분석 — 블랙리스트 연결이 있는 절이 할 일이 아니다')
                _o = ('%s · SYN · 해제 · 시험 줄입니다.' % AJ._ref(_c, _far) + chr(10) +
                      '%s · SYN · 해제 · 시험 줄입니다.' % AJ._ref(_c, _far2))
                ck(gates_for('VERS_UNLINK', 'NEW') == ['link_review']
                   and not [l for l in link_review_lines(_c, _v, _o) if not _is_note(l)],
                   '해제분석 게이트 = 점검 줄')
                _jid4, _n = create_job(_c, 'VERS_UNLINK', '', 'NEW', 'KO', [_v], base='KO', name='__selftest_unlink__')
                _jids.append(_jid4)
                _c.execute("UPDATE sys_ai_item SET state='OK', out_text=? WHERE job_id=?", (_o, _jid4))
                _c.commit()
                _d4 = load_ok(_c, _jid4, dry=True)
                ck(_d4['n'] == 1 and '구속사연결에 든 1개는 남김' in _d4['why'], '해제분석 미리보기: %s' % _d4)
                load_ok(_c, _jid4, dry=False)
                ck(not _c.execute("SELECT 1 FROM sys_link_asset WHERE sys_link_id=?", (_tl[0],)).fetchone()
                   and not _c.execute("SELECT 1 FROM sys_text_asset WHERE clicked_id=? AND text_type='VERS_VERS_DESC'",
                                      (_tl[0],)).fetchone(),
                   '★★★ 해제분석 승인 = 연결과 연결설명문을 물리삭제')
                ck(_c.execute("SELECT record_status FROM sys_link_asset WHERE sys_link_id=?", (_tl[1],)).fetchone()
                   == ('LIVE',), '★ 구속사연결에 든 연결은 지우지 않는다')
            finally:
                for _lk in _tl:
                    _c.execute("DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type='VERS_VERS_DESC'", (_lk,))
                _c.execute("DELETE FROM sys_link_asset WHERE source='SELFTEST_UNLINK'")
                _c.commit()
        finally:
            for _jj in _jids:
                for (_lk,) in _c.execute("SELECT sys_link_id FROM sys_link_asset WHERE source=?",
                                         ('AILINK:%d' % _jj,)).fetchall():
                    _c.execute("DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type='VERS_VERS_DESC'", (_lk,))
                _c.execute("DELETE FROM sys_link_asset WHERE source=?", ('AILINK:%d' % _jj,))
                _c.execute("DELETE FROM sys_ai_item WHERE job_id=?", (_jj,))
                _c.execute("DELETE FROM sys_ai_job WHERE job_id=?", (_jj,))
            for (_j,) in _c.execute("SELECT job_id FROM sys_ai_job WHERE name=? OR name LIKE ?",
                                    ('__selftest_link__', '구절연결 설명문 · 연결기 #%')).fetchall():
                if _jid and (_j == _jid or ('연결기 #%d ' % _jid) in (_c.execute(
                        "SELECT name FROM sys_ai_job WHERE job_id=?", (_j,)).fetchone() or [''])[0]):
                    _c.execute("DELETE FROM sys_ai_item WHERE job_id=?", (_j,))
                    _c.execute("DELETE FROM sys_ai_job WHERE job_id=?", (_j,))
            if _jid:
                _c.execute("DELETE FROM sys_link_asset WHERE source=?", ('AILINK:%d' % _jid,))
            _c.commit()
            _c.close()
    except Exception as _e:                               # noqa: BLE001
        ck(False, '연결기 자가검증이 터졌다: %r' % (_e,))

    # ── 2026-10-13 · 게이트 규칙 · 관리자 세기 · 금지 문구 · 틀 문구(docs/1.txt 71) ──
    #   ⚠ 메모리 DB 로만 잰다 — 실제 설정 표·sys_config 를 건드리지 않는다.
    try:
        import sqlite3 as _sq
        _m = _sq.connect(':memory:')
        _m.execute("CREATE TABLE sys_config(config_key TEXT PRIMARY KEY, config_val TEXT)")
        ensure_cfg(_m)
        ck(gate_rule_of('인용 표시가 2군데 사라졌다 — 성경 인용과 설명이 섞인다') == 'edit_quote', '규칙: 인용 표시')
        ck(gate_rule_of('[설명문] 검사가 터졌다(check_dash): x') == 'crash', '규칙: 못 돈 검사')
        ck(gate_rule_of('꼴은 규칙대로입니다 — 글 자체는 사람이 봅니다.') == 'pass', '규칙: 통과 문구')
        _r = {'ok': False, 'lines': ['인용 표시가 2군데 사라졌다 — 성경 인용과 설명이 섞인다']}
        ck(apply_gate_cfg(_m, 'VERS_VERS_DESC', 'EDIT', dict(_r))['ok'] is False, '설정 없으면 그대로 흠')
        set_gate_cfg(_m, 'VERS_VERS_DESC', 'EDIT', 'edit_quote', 'NOTE')
        _g = apply_gate_cfg(_m, 'VERS_VERS_DESC', 'EDIT', dict(_r))
        ck(_g['ok'] is True and _is_note(_g['lines'][0]), '참고로 낮추면 통과 · 알림 줄: %r' % (_g,))
        ck(apply_gate_cfg(_m, 'VERS_VERS_DESC', 'NEW', dict(_r))['ok'] is False, '다른 업무에는 안 번진다')
        set_gate_cfg(_m, 'VERS_VERS_DESC', 'EDIT', 'edit_quote', 'OFF')
        _g = apply_gate_cfg(_m, 'VERS_VERS_DESC', 'EDIT', dict(_r))
        ck(_g['ok'] is True and not [l for l in _g['lines'] if '인용 표시' in l], '끄면 줄이 빠진다')
        set_gate_cfg(_m, 'VERS_VERS_DESC', 'EDIT', 'edit_quote', '')
        ck(apply_gate_cfg(_m, 'VERS_VERS_DESC', 'EDIT', dict(_r))['ok'] is False, '기본으로 되돌리면 다시 흠')
        try:
            set_gate_cfg(_m, '', '', 'crash', 'OFF')
            ck(False, '못 돈 검사를 끌 수 있다(막아야 한다)')
        except ValueError:
            ck(True, '')
        _c2 = {'ok': False, 'lines': ['  [설명문] 검사가 터졌다(check_dash): x']}
        _m.execute("INSERT OR REPLACE INTO sys_ai_gate_cfg(kind,task,rule,mode) VALUES('','','crash','OFF')")
        ck(apply_gate_cfg(_m, 'X', 'NEW', _c2)['ok'] is False, '표에 끔이 박혀 있어도 못 돈 검사는 흠')
        set_banned_phrases(_m, 'VERS_VERS_DESC', ['왜 이 둘인가'])
        ck(banned_lines(_m, 'VERS_VERS_DESC', '왜이 둘인가 하면 두 절이') != [], '금지 문구(공백 무시)')
        ck(banned_lines(_m, 'PERI_DESC', '왜 이 둘인가') == [], '금지 문구는 그 자산만')
        _e, _h = formula_counts(['빛이 자라납니다. 끝.', '물이 자라납니다.', '그는 갑니다.'])
        ck(_e['자라납니다'] == 2 and '있습니다' not in _e, '끝맺음 세기(흔한 끝은 뺀다)')
        _m.close()
    except Exception as _e:                               # noqa: BLE001
        ck(False, '게이트 설정 자가검증이 터졌다: %r' % (_e,))

    # ★ 2026-10-30 오류 찾기 · 고른 수정 적용(가짜 AI)
    try:
        _f, _d = parse_check('사실 | 사래는 아브라함의 아들 | 사래는 아내다 | 사래는 아브라함의 아내\n'
                             '오탈자 | 없는글자 | x | y\n없음', '그날 사래는 아브라함의 아들이었다.')
        ck(len(_f) == 1 and _d == 1 and _f[0]['kind'] == '사실', '오류 찾기 — 받은 글에 있는 지적만 남긴다')
        _f2, _ = parse_check('1. 기타 | 하나 | 왜 | 둘', '하나 하나')
        ck(_f2 and _f2[0]['n'] == 2, '오류 찾기 — 몇 번 나오나 센다')
    except Exception as _e:                               # noqa: BLE001
        ck(False, '오류 찾기 자가검증이 터졌다: %r' % (_e,))

    try:
        _ck = {'found': [{'wrong': 'a', 'fix': 'b'}, {'wrong': 'c', 'fix': 'd', 'skip': 1}, {'wrong': 'e', 'fix': 'f', 'done': 1}]}
        ck(fix_picks(_ck) == [0], '한꺼번에 고칠 줄 = 안 고쳤고 안 뺀 것만')
    except Exception as _e:                               # noqa: BLE001
        ck(False, '고칠 줄 고르기가 터졌다: %r' % (_e,))

    # ★ 2026-10-30 원문 의심 — 지적만 떼어 보관 · 번역 글은 그대로 · 한 원문에 한 번
    try:
        _t, _n = take_src_note('Le texte.' + chr(10) + chr(10) + '- [원문 의심] Gen 3:16 은 3:15 일 듯' + chr(10)
                               + '[원문 의심]  teh → the')
        ck(_t == 'Le texte.' and _n.split(chr(10)) == ['Gen 3:16 은 3:15 일 듯', 'teh → the'],
           '원문 의심 — 떼어 낸다: %r %r' % (_t, _n))
        ck(take_src_note('글만 있다') == ('글만 있다', ''), '원문 의심 — 없으면 글 그대로')
    except Exception as _e:                               # noqa: BLE001
        ck(False, '원문 의심 떼기가 터졌다: %r' % (_e,))
    _sj = []
    _sc_conn = None
    try:
        import appdb as _ad
        _sc_conn = _ad.connect(os.path.join(APP, 'bible_master.db'))
        ensure(_sc_conn)
        _src = _sc_conn.execute("SELECT ref_src_id FROM sys_ref_source WHERE src_code='EASTON_DICT'").fetchone()
        _sl = AJ.slots(_sc_conn, 'REF_DICT', str(_src[0]))[-1][0] if _src else None
        if _sl is not None:
            _had = _sc_conn.execute("SELECT 1 FROM sys_ai_srccheck WHERE asset_kind='REF_DICT' AND slot_id=?",
                                    (str(_sl),)).fetchone()
            _sc_conn.execute("DELETE FROM sys_ai_srccheck WHERE asset_kind='REF_DICT' AND slot_id=?", (str(_sl),))
            _seen = []

            def _sfake(prompt, model=None, conn=None, **kw):
                _seen.append(prompt)
                return {'ok': True, 'tokens': {'in': 1, 'out': 1},
                        'text': '번역한 글입니다.' + chr(10) + '[원문 의심] Mt 5:3 은 5:4 일 듯'}
            _j1, _ = create_job(_sc_conn, 'REF_DICT', str(_src[0]), 'TRANS', 'KO', [_sl], name='__원문의심시험__')
            _sj.append(_j1)
            run_job(_sc_conn, _j1, _call=_sfake)
            _row = _sc_conn.execute("SELECT out_text, src_note FROM sys_ai_item WHERE job_id=?", (_j1,)).fetchone()
            ck(_seen and SRC_RULE in _seen[0], '원문 의심 — 첫 번역에 지시가 붙는다')
            ck(_row and SRC_MARK not in (_row[0] or '') and _row[0].startswith('번역한 글'),
               '원문 의심 — 번역 글에서 뗀다: %r' % (_row,))
            ck(_row and _row[1] == 'Mt 5:3 은 5:4 일 듯', '원문 의심 — 건에 보관: %r' % (_row,))
            _j2, _ = create_job(_sc_conn, 'REF_DICT', str(_src[0]), 'TRANS', 'FR', [_sl], name='__원문의심시험__')
            _sj.append(_j2)
            _seen.clear()
            run_job(_sc_conn, _j2, _call=_sfake)
            ck(_seen and SRC_RULE not in _seen[0], '원문 의심 — 두 번째 언어에는 지시가 안 붙는다')
            if not _had:
                _sc_conn.execute("DELETE FROM sys_ai_srccheck WHERE asset_kind='REF_DICT' AND slot_id=?", (str(_sl),))
    except Exception as _e:                               # noqa: BLE001
        ck(False, '원문 의심 시험이 터졌다: %r' % (_e,))
    finally:
        if _sc_conn is not None:
            for _x in _sj:
                _sc_conn.execute("DELETE FROM sys_ai_item WHERE job_id=?", (_x,))
                _sc_conn.execute("DELETE FROM sys_ai_job WHERE job_id=?", (_x,))
            _sc_conn.commit()
            _sc_conn.close()

    for b in bad:
        print('  FAIL ' + b)
    n_all = _nck[0]   # ★ 맨 끝에서 센다 — 뒤에 항목을 더하면 총수가 따라온다
    print('db_ai_run selftest: %s (%d/%d)'
          % ('OK' if not bad else 'FAIL', n_all - len(bad), n_all))
    return 0 if not bad else 1


def _main(argv):
    if '--selftest' in argv:
        return selftest()
    import appdb
    conn = appdb.connect(os.path.join(APP, 'bible_master.db'))
    if '--jobs' in argv:
        for jid, nm, at, n, pend in jobs(conn):
            print('  #%-4s %-52s %s  %s건(남은 %s)' % (jid, nm, at, n, pend))
        return 0
    if '--show' in argv:
        jid = int(argv[argv.index('--show') + 1])
        print(job(conn, jid))
        for s, n in sorted(counts(conn, jid).items()):
            print('  %-10s %s' % (STATE_NAME.get(s, s), n))
        return 0
    if '--regate' in argv:
        _i = argv.index('--regate')
        jid = int(argv[_i + 1]) if len(argv) > _i + 1 and argv[_i + 1].isdigit() else None
        r = regate(conn, jid, dry='--dry' in argv)
        print('검수 대기 %(items)d건(작업 %(jobs)d) · 게이트 줄이 바뀐 것 %(changed)d ·'
              ' 통과 %(ok_before)d → %(ok_after)d%%s' % r
              % (' (미리보기 — 안 적었다)' if '--dry' in argv else ''))
        return 0
    if '--check' in argv:
        iid = int(argv[argv.index('--check') + 1])
        r = check_item(conn, iid)
        print('찾음 %d · 버림 %d · %s' % (len(r.get('found') or []), r.get('dropped', 0), r.get('why') or r.get('model')))
        for f in r.get('found') or []:
            print('  %(kind)s | %(wrong)s | %(why)s | %(fix)s' % f)
        return 0
    if '--run' in argv:
        jid = int(argv[argv.index('--run') + 1])
        lim = int(argv[argv.index('--limit') + 1]) if '--limit' in argv else 0
        print(run_job(conn, jid, limit=lim,
                      on_progress=lambda i, n, sid, r: print(
                          '  %d/%d  자리 %s  %s' % (i, n, sid,
                                                 '됨' if r.get('ok') else r.get('why', '')))))
        return 0
    print(__doc__)
    return 0


if __name__ == '__main__':
    sys.exit(_main(sys.argv[1:]))
