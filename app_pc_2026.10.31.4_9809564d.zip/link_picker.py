# -*- coding: utf-8 -*-
"""
link_picker.py — **자산 사이 연결 하나로** (2026-08-21 신설 · 영구 · selftest 의무)
==================================================================================
어느 화면에서 열어도 같은 창이고 **자기 종류만 잠깁니다.**

    link_picker.open_picker(parent, db, 'USER_REF', ref_id, lang_getter=…)

★ 사용자 확정 설계 (0.txt 3번 — 「모든 연결대상 자산 사이의 연결을 해주는
  통합화면을 하나만 만들 수 있으면 좋겠다. 자기자신을 제외한 나머지 자산을
  선택하는 화면을 제시하면 된다」):
  그전에는 연결 입력이 **네 군데**로 흩어져 있었다 — 태그는 저장 직후 팝업,
  구절·용어·도서는 왼쪽 하단 입력칸. **같은 일인데 방법이 넷**이라 사용자는
  「태그는 왜 팝업이지?」를 매번 다시 배웠다.

━━ 대상 일곱, 저장 방식은 **둘**뿐 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    성경      구절 범위          (start_vid, end_vid)
    태그      태그              tag_id      ← **기존 `user_tag_link` 그대로**
    렌즈묵상   렌즈 · 노드         unit_id
    도서·설교  도서 · 유닛         book_id · unit_id
    교리자료   문답·사전·주제색인    ref_unit_id
    연구자료   내 글              ref_id

★★ **성경은 「구절 범위」 한 가지뿐이다** (2026-08-21 사용자 판단). 책·장·
  단락·절은 **저장 방식이 아니라 입력 단추**다 — `[책]` 을 누르면 롬 1:1~16:27
  이 채워진다. 새 종류(`BIBLE_BOOK`)를 만들자던 안은 사용자가 물리쳤다:
  「연결할 때에는 결국 책 코드를 가지고 연결해야 하는데 어떤 구절을 클릭하든지
  마태복음 강해자료를 볼 수 있어야 한다. 1:1-28:20 이 맞는 것 아닌가」 — 맞다.
  새 종류를 만들면 **조회 경로가 하나 더 늘어** 구절마다 두 번 묻게 된다.
  실측: 구간 조회 `target<=vid<=end` 는 인덱스를 타고 **0.03~0.15ms**.

★ **「구절 범위에 매달린 것」은 대상이 아니다** (사용자 — 「설명문을 뺀다면
  일관되게 하자. 주석도 구절과 연결된다」). 실측으로 확인 —
  구절 설명문 49,220 · 단락 설명문 3,075 · 장 설명문 826 ·
  **주석 항목 64,238 전부 `start_vid` 보유**(없는 것 0건).
  ⇒ 구절 범위를 이으면 그 자리의 설명문·주석이 함께 닿는다. 따로 두면 같은
    것을 네 번 이으라는 말이 된다.

★ **엔티티(용어)는 대상이 아니다 — 태그가 품는다.** 실측: `sys_tag_asset` 의
  `tag_kind='ENTITY'` 451개가 **엔티티 451개 전부**를 가리킨다(승격 완료).
  태그를 붙이면 `entity_id` 로 엔티티가 따라오고, 주요용어 화면의 「이 용어로
  쓴 글」은 태그를 **거꾸로 읽어** 만든다.

⚠⚠ **한 짝 한 행** (사용자 — 「양방향 연결은 중복이다」). 두 끝을
  `(종류, 번호, 끝)` 으로 **정렬해** 저장하므로 `A→B` 와 `B→A` 가 같은 행이다.
  UNIQUE 인덱스가 그것을 강제한다. `sys_entity_compare` 에서 쓴 방식과 같다.

⚠ **구절↔구절은 여기서 안 한다** — 구절연결 캔버스(`sys_link_asset VERS_VERS`)
  가 이미 그 일을 하고 완성돼 있다. 여기서 구절은 **한쪽 끝**으로만 쓰인다.

⚠ 저장은 **`userdb`** 다(§0-6 C-2 — 사용자 동작이 배포 DB 를 건드리면 안 된다).
  관리자가 만든 sys 연결 표들은 **그대로** 두고 화면이 둘을 합쳐 보인다.

`python link_picker.py --selftest`  — 의무
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb
import verse_text as _vt   # ★ 절 본문은 이 문 하나로(합쳐짐·없는절 보완 §verse_text)
# ★★ 구간 판정은 **한 문**이다(§verse_range) — `verse_id` 는 신원이고
#   차례는 `sort_order` 다. 화면마다 SQL 을 다시 쓰면 그 자리에서 샌다.
import verse_range as _vr

# 연결할 수 있는 것 — 사용자 확정 일곱(플랜 제외)
# ⚠ **내 렌즈는 `ULENS`·`UNODE` 로 가른다** — `user_unit_asset` 과
#   `sys_unit_asset` 은 번호가 겹친다(태그 쪽이 이미 그렇게 갈라 두었다).
KINDS = ('VERSE', 'TAG', 'LENS', 'NODE', 'ULENS', 'UNODE', 'BOOK',
         'BOOK_UNIT', 'REF_UNIT', 'USER_REF',
         # ★★ 2026-08-27 — **관리자 통합 연결관리**가 쓰는 셋 (사용자 지시
         #   「연결관리는 **모든 자산을 커버**하는 통합 화면 … 그 화면 하나만으로
         #   전부 해결되어야 한다」). 그전에는 주인은 될 수 있는데 **상대로는
         #   고를 수 없었다** — 실측 `ENTI` 32,283행 · `PERI` 7,086행이 가장 많은
         #   연결인데 골라 붙일 길이 없었다.
         'ENTITY', 'PLAN', 'MEDIA',
         # ★★ **말씀의 흐름 = 자산** (2026-08-27 사용자 교정 — 「너는 단순
         #   링크라고 이해했다. **자산이다.** 링크가 모여지고 설명문이 결합된
         #   독립된 구속사 흐름이라는 자산이다. 태그도 연결 대상인데 흐름을
         #   다른 것과 연결하지 못할 이유 없다」). 도서·설교·구절 어디에나
         #   연결된다. 멤버십(chain_code 표시 — §28-3)과는 **별개**다.
         'CHAIN',
         # ★ **구절단락** (2026-08-29 되돌림) — 실측 `PERI` 연결 7,089행이
         #   목록에는 뜨는데 새로 붙일 길이 없었다. 자산연결정책 표에도 행이 있다.
         'PERICOPE',
         # ★★★ **묵상노트 = 자산** (2026-08-30 사용자 확정 — 「지금은 출발지가
         #   묵상노트가 아니라 **구절**이라는 문제 … 묵상노트를 출발지 및
         #   재고창고에 추가해야 함. **본격적인 연결대상 자산으로 포함**하는
         #   조치가 필요하다. 그래야 **출발지 이름 자체가 묵상노트의 제목**으로
         #   표시될 수 있음」. §0-6 C-2b 검토과제의 실행).
         #   ★ 근거(사용자, 2026-08-30 앞선 지시) — 「묵상노트는 구절과
         #     연결되지만 **독자적으로 태그연결이 필요하다**. 묵상 내용은
         #     **구절의 경계를 넘어설 수 있으므로**.」
         #   ⚠ **개인 자산이다** — `USER_ONLY_KINDS` 에 넣는다. 배포 DB 가 남의
         #     PC 노트 번호를 가리키면 안 된다.
         #   ⚠ 저장소는 `userdb.user_text_asset(text_type='VERS_NOTE')` 이고
         #     자산 번호는 그 행의 `user_text_id` 다. 구절은 이제 **닻**이지
         #     주인이 아니다(`notes.md` §0-1 의 「어디서 썼나」).
         'NOTE',
         # ★★★ **내 영상** (2026-09-10 사용자 「연결팝업 화면에서 다른 여러
         #   자산들과 연결될 수 있도록 해야 한다」).
         #   그전에는 내 영상이 **구절에만** 붙었다(`add_user_verse_media`) —
         #   태그·용어·도서 어디에도 못 이었고 재고창고에도 안 나왔다.
         #   ⚠ **개인 자산이라 `USER_ONLY_KINDS`** — 배포 DB 가 남의 PC 영상
         #     번호를 가리키면 안 된다.
         #   ⚠⚠ **`MEDIA` 와 코드를 나눈다(`UMED`)** — 한 이름에 두 표를
         #     담으면 번호가 겹치는 날 딴 영상이 뜬다(실측으로 잡았다).
         'UMEDIA')

#: ★★★ **비었다 — 사용자도 관리자와 같은 자산을 고른다** (2026-08-29 사용자
#  지시 「전체 자산을 커버하지 못한다」). 그전에는 넷(주요용어·플랜·외부연결·
#  말씀의흐름)이 여기 들어 있어 **사용자 창에서만 안 보였다.**
#  ⚠⚠ 그런데 My Edit 은 그 셋을 **출발지로는** 허용하고 있었다 — 「용어에 서
#    있는데 영상링크를 붙일 단추가 없는」 반쪽 상태가 그래서 났다.
#    자산연결정책 표의 60짝 중 **34짝**이 이 한 줄에 막혀 있었다.
#  ⚠ 여기에 종류를 다시 넣지 말 것. 범위로 가르는 것은 **저장 대상 표**(scope)
#    이지 **고를 수 있는 자산**이 아니다.
SYS_ONLY_KINDS = ()
#: 연결 **표에는 있는데 고르는 콤보에는 안 올리는** 종류.
#  ⚠ **이름표(`label_of`)와 후보 SQL 은 그대로 둔다** — 이미 쌓인 7,086행이
#    화면에 떠야 하고, 반대편(주요용어·외부연결)에서 그 연결이 보인다.
#  ★ 2026-08-29 — **구절단락을 되돌렸다.** 「이미 성경 연결에 포함」이라 뺐는데
#    실측 `PERI` 연결이 **7,089행**(용어↔단락 1,621 · 영상↔단락 5,441)이라
#    목록에는 뜨는데 새로 붙일 수는 없는 상태였다. 자산연결정책 표에도 행이 있다.
#: ★★ **구절단락은 다시 뺐다** (2026-08-29 사용자 최종 판단 — 「실제 영상을
#  보면 미리 정한 단락과 관계없이 **컨텐츠 제작자가 구간을 정해서** 설교한다.
#  따라서 제거하고 **구절 구간만으로도 커버 가능**하다. 관리자 화면에서도
#  단락 버튼 제거한다. **최대한 통일한다**」).
#  ⚠ **이름표와 후보 SQL 은 그대로 둔다** — 이미 쌓인 `PERI` 연결 7,089행
#    (용어↔단락 1,621 · 영상↔단락 5,441)이 목록에 떠야 하고, 반대편 화면이
#    그 연결을 읽는다. 「새로 붙이는 길」만 닫는 것이다.
#  ⚠ 사용자·관리자 **양쪽 다** 닫는다(통일). 범위 줄 [이 절의 단락] 이 그
#    자리를 대신한다 — 저장은 구절 범위(`VERS_*`)로 간다.
NOT_PICKABLE = ('PERICOPE',)

#: ★★★ **재고에 없으면 그 자리에서 만든다 — 자산별 능력표** (2026-08-29
#  사용자 확정 · 0.txt 1-4-(4)):
#  「재고자산에 배치된 **어떤 자산이든** 추가하려면 **「자산 종류 & 추가 버튼」**이
#    작동해야 가운데 확인 화면에서 입력이 가능해진다.」
#  ⇒ 단추는 **늘 같은 자리**(재고창고 아래)에 있고, 그 자산에 만들기 화면이
#    있느냐만 여기가 정한다. 자산을 늘릴 때 **이 표만** 고친다.
#  `form` — 가운데 확인 칸이 지을 입력 폼:
#     'URL'   URL·제목·갈래      'NAME'  이름 한 칸      'TITLE' 제목+본문
#  ⚠ **관리자는 대부분 회색**이다 — 엔티티·태그·렌즈·자료집 글은 **자기 관리
#    화면**이 있고, 거기서 만들어야 코드·유형·자료집 같은 필수 칸이 채워진다.
#    여기서 대충 만들면 배포 DB 에 이름만 있는 껍데기가 쌓인다.
CREATE_CAPS = {
    'MEDIA':    dict(form='URL',   sys=True,  user=True),
    # ★ **내 영상** — 사용자만. 관리자는 `MEDIA`(배포 표)로 만든다.
    'UMEDIA':   dict(form='URL',   sys=False, user=True),
    # 사용자에게 「용어」는 **내 태그**다 (2026-08-29 사용자 확정 「용어 = 태그」).
    'ENTITY':   dict(form='NAME',  sys=False, user=True),
    'TAG':      dict(form='NAME',  sys=False, user=True),
    'USER_REF': dict(form='TITLE', sys=False, user=True),
    'ULENS':    dict(form='NAME',  sys=False, user=True),
    'UNODE':    dict(form='NAME',  sys=False, user=True),
    # ★★ **묵상노트** (2026-08-31 사용자 지시 0.txt 1-4 「가운데 화면에 **빈
    #   묵상노트 입력화면**을 표시하고, **기호 버튼**을 배치하라 … 이렇게 되면
    #   묵상노트 입력/수정도 My Edit 버튼 하나로 커버될 수 있다」).
    #   ⚠ 글 한 칸짜리라 가운데 폼(약 530px)에 **온전히 들어간다** — 연구자료·
    #     주요용어처럼 제 화면이 따로 필요한 부류와 갈리는 기준이 그것이다.
    'NOTE':     dict(form='TITLE', sys=False, user=True),
}
#: 못 만드는 이유 — **조용히 회색으로 두지 않는다**(§0-1 가짜 기능 금지).
CREATE_WHY = {
    'VERSE': '성경 본문은 만들지 않습니다.',
    'PERICOPE': '구절단락은 관리자 ▸ 구절단락 편집기에서 만듭니다.',
    'BOOK': '도서는 관리자 ▸ 도서 관리에서 등록합니다.',
    'BOOK_UNIT': '도서 편은 도서 적재 도구가 만듭니다.',
    'PLAN': '묵상플랜은 관리자 ▸ 플랜 관리에서 만듭니다.',
    'CHAIN': '말씀의 흐름은 관리자 ▸ 구속사 흐름 관리에서 만듭니다.',
    'REF_UNIT': '자료집 글은 관리자 ▸ 교리문답·사전·연구자료 화면에서 만듭니다.',
    'LENS': '렌즈는 관리자 ▸ 렌즈묵상 관리에서 만듭니다.',
    'NODE': '노드는 관리자 ▸ 렌즈묵상 관리에서 만듭니다.',
}


#: ★★★ **가운데 확인 칸에서 고친다** (2026-08-29 사용자 —
#  「가운데 확인 화면에서 **추가/수정**이 가능해야 한다」 · 0.txt 1-4-(2)).
#  ⚠ **내가 만든 것만** 그 자리에서 고친다. 배포 자료의 글(구절 설명문·용어
#    설명문·렌즈 글)은 **덮개**라 구획이 여럿이고 화면이 크다 — 그것은
#    My Edit 의 「글」 조리대가 이미 한다. 여기서 또 지으면 **두 벌**이 되고,
#    Tk 는 그 몸통을 다른 부모로 옮겨 심을 수도 없다(실측 TclError).
EDIT_CAPS = {
    # ★ 2026-10-20 — 사용자는 배포 영상을 못 고친다(그전엔 USER 범위 ✎ 가 sys_media_asset 을 바로 고쳤다).
    'MEDIA':    dict(form='URL',   sys=True,  user=False),
    'UMEDIA':   dict(form='URL',   sys=False, user=True),
    'USER_REF': dict(form='TITLE', sys=False, user=True),
    'ULENS':    dict(form='NAME',  sys=False, user=True),
    'UNODE':    dict(form='NAME',  sys=False, user=True),
    # ★ 2026-08-29 — **내가 만든 용어(내 태그)** 도 그 자리에서 고치고 숨긴다.
    #   그전에는 만들 수는 있는데 고칠 길이 없었다(오타를 되돌릴 수 없었다).
    'UTAG':     dict(form='NAME',  sys=False, user=True),
    'NOTE':     dict(form='TITLE', sys=False, user=True),
}
#: 그 자리에서 못 고치는 이유 — 어디서 고치는지 **반드시 말한다**.
EDIT_WHY = {
    'MEDIA': '앱이 준 영상은 고치지 않습니다 — 이 연결만 숨기거나 내 영상으로 새로 담습니다.',
    'VERSE': '성경 본문은 고치지 않습니다. 구절 설명문은 My Edit ▸ 글 에서 고칩니다.',
    'ENTITY': '용어 설명문·별명은 My Edit ▸ 글 에서 고칩니다.',
    'TAG': '기본 용어의 이름은 My Edit ▸ 글 에서 내 이름으로 덮습니다.',
    'PERICOPE': '단락 설명문은 My Edit ▸ 글 에서 고칩니다.',
    'LENS': '렌즈 글은 My Edit ▸ 글 에서 고칩니다.',
    'NODE': '노드 글은 My Edit ▸ 글 에서 고칩니다.',
    'BOOK': '도서 소개문은 관리자 ▸ 도서 관리에서 고칩니다.',
    'BOOK_UNIT': '도서 본문은 고치지 않습니다(남의 저작).',
    'REF_UNIT': '자료집 글은 관리자 ▸ 그 자료집 화면에서 고칩니다.',
    'PLAN': '플랜 제목·설명은 관리자 ▸ 플랜 관리에서 고칩니다.',
    'CHAIN': '흐름 이름·설명은 관리자 ▸ 구속사 흐름 관리에서 고칩니다.',
}


def coverage(scope='USER'):
    """★★★ **이 화면 하나로 무엇까지 되는가** → [(종류, 연결, 만들기, 수정,
    숨기기, 갈래, 이유)] (2026-08-29 사용자 지시 — 「이 화면 하나만 있으면
    사용자/관리자가 **모든 자산을 연결하고 추가/숨기기 가능하도록 완성되는지
    하나하나 점검하라**」).

    ⚠ **화면을 열어 보지 않고도** 빈 구석이 드러나야 한다 — 자산을 늘리면
      selftest 가 여기서 잡는다(갈래 없는 종류·이유 없는 회색).
    ⚠ 「만들기·수정이 회색」이 곧 결함은 아니다. 도서 등록은 원문 받기·판권·
      적재 도구가 얽혀 있고 플랜은 스케줄이, 흐름은 rel·chain_code 가 필요하다.
      이름만 받아 만들면 **껍데기**가 쌓인다 — 그래서 전용 화면으로 보낸다.
      다만 **어디로 가야 하는지 반드시 말한다**(§0-1 가짜 기능 금지).
    """
    out = []
    ks = kinds(scope)
    for k in KINDS:
        link = k in ks
        okc, _fc, whyc = can_create(k, scope)
        oke, _fe, whye = can_edit(k, scope)
        br = KIND_BRANCH.get(k)
        brn = ''
        for b in BRANCHES:
            if b[0] == br:
                brn = _t(b[1], b[2])
                break
        out.append((k, link, okc, oke, oke, brn, whyc or whye))
    return out


def coverage_report(scope='USER'):
    """사람이 읽는 표 — 도구·문서가 그대로 찍어 쓴다."""
    L = ['자산(코드)            연결 만들기 수정 숨김  재고 갈래     못 하면 어디서',
         '-' * 100]
    for k, li, cr, ed, hd, brn, why in coverage(scope):
        # ⚠ 이름이 겹치는 종류가 있다(TAG·ENTITY 둘 다 「용어」) — 코드를 함께.
        L.append('%-20s %-4s %-5s %-4s %-4s %-12s %s'
                 % ('%s(%s)' % (kind_name(k), k),
                    'O' if li else 'X', 'O' if cr else '-',
                    'O' if ed else '-', 'O' if hd else '-', brn or '(없음)',
                    '' if (cr and ed) else why[:44]))
    L.append('')
    L.append('※ 주석·설명문은 **연결 대상이 아니다** — 구절 번호에 저절로 붙는다.')
    L.append('   구절을 이으면 그 자리의 주석·설명문이 함께 닿는다(① 「참고」 줄).')
    return chr(10).join(L)


def can_edit(kind, scope='USER'):
    """(그 자리에서 고칠 수 있나, 폼, 못 고치는 이유)."""
    k = str(kind or '').upper()
    cap = EDIT_CAPS.get(k)
    if cap and cap.get('user' if scope == 'USER' else 'sys'):
        return True, cap['form'], ''
    return False, '', EDIT_WHY.get(k, '이 자산은 여기서 고치지 않습니다.')


def can_create(kind, scope='USER'):
    """(만들 수 있나, 폼 종류, 못 만드는 이유) — **회색 판정의 단일 문**."""
    k = str(kind or '').upper()
    cap = CREATE_CAPS.get(k)
    if cap and cap.get('user' if scope == 'USER' else 'sys'):
        return True, cap['form'], ''
    if cap:                       # 만들 수는 있는데 이 범위가 아니다
        other = '사용자' if scope == 'SYS' else '관리자'
        return False, '', CREATE_WHY.get(
            k, '이 자산은 %s 화면에서 만듭니다.' % other)
    return False, '', CREATE_WHY.get(k, '이 자산은 여기서 만들지 않습니다.')


#: **넓게 열린 다섯** — 예전에 사용자 창에서 빠져 있던 종류. selftest 가
#  「이것들이 실제로 후보를 내는가」를 계속 잰다(이름을 못 대면 화면에 `#47`).
WIDE_KINDS = ('ENTITY', 'PERICOPE', 'PLAN', 'MEDIA', 'UMEDIA', 'CHAIN')

# 화면 갈래 — (열쇠, i18n, 기본 이름, 담는 종류들)
BRANCHES = (
    ('bible', 'LP_B_BIBLE', '성경', ('VERSE',)),
    ('lens', 'LP_B_LENS', '렌즈묵상', ('LENS', 'NODE', 'ULENS', 'UNODE')),
    ('book', 'LP_B_BOOK', '도서·설교', ('BOOK', 'BOOK_UNIT')),
    # ⚠ 이름에 **사전**을 넣는다 (2026-08-29 사용자 물음 「주석/사전은
    #   연결할 필요가 없기 때문인가?」). 사전은 **여기 안에 있었다** —
    #   실측 Smith 158 · Easton 131 · 문답 267 · 주제색인 33.
    #   갈래 이름이 「교리자료」라 사전이 없는 것처럼 보였다.
    ('ref', 'LP_B_REF', '문답·사전', ('REF_UNIT',)),
    ('study', 'LP_B_STUDY', '연구자료', ('USER_REF',)),
    # ★★★ **용어 갈래 신설** (2026-08-29 사용자 확정 — 「용어 = 태그. 표현을
    #   용어로 통합하면 된다. 태그라면 웬지 부수적이라는 느낌이다」).
    #   그전에는 갈래가 아예 없어 **관리자 창에서도 못 골랐다** — `ENTITY` 는
    #   `KINDS` 에 있는데 `KIND_BRANCH` 에 없어 조용히 빠졌다(실측).
    #   실측 `ENTI_*` 32,283행이 가장 큰 연결인데 붙일 길이 없었다.
    #   ⏭ 위 `tag` 갈래와 **합칠 예정**이다(태그 509개 중 451개가 곧 이 용어들).
    #     지금은 태그 줄이 별도 팝업이라 모양이 다르다 — 그 통합은 다음 단계.
    # ★★★ **태그를 여기로 흡수했다** (2026-08-29 · 항목 3-(b) 사용자 신고
    #   「재고창고 안 세 부품의 모양이 다르다 — 태그만 별도 팝업」).
    #   그전에는 태그가 **다른 창**을 열어, 같은 일인데 손이 두 가지를 배웠다.
    #   ⇒ 「용어」 한 갈래에 **엔티티 451 + 순수 태그 58** 을 함께 올린다.
    #   ⚠ **중복이 없다** — 태그 509 중 451 은 엔티티를 가리키는 연동 태그라
    #     엔티티 쪽으로만 올리고, 순수 태그(`entity_id IS NULL`) 58 만 태그로
    #     올린다. 두 갈래로 두면 「갈렙」이 목록에 두 번 뜬다.
    #   ⚠ 잇는 곳이 갈린다 — **엔티티는 `ENTI_*`, 순수 태그는 `tag_picker`**.
    #     `do_connect` 가 그 갈림을 한 곳에서 한다.
    #   ⏭ 이미 쌓인 「엔티티 태그에 걸린 TAG_* 128행」은 그대로 보인다(읽기가
    #     두 경로를 합친다). 한 철자로 모으는 것은 `정책자료/용어체계정리.md`
    #     의 승격 작업 몫이다.
    ('entity', 'LP_B_ENTITY', '용어', ('ENTITY', 'TAG', 'UTAG')),
    # ★ 구절단락 — `NOT_PICKABLE` 해제와 짝(2026-08-29). 갈래가 없으면
    #   해제해도 화면에 안 나온다(`KIND_BRANCH` 가 비면 목록에서 빠진다).
    ('peri', 'LP_B_PERI', '구절단락', ('PERICOPE',)),
    ('plan', 'LP_B_PLAN', '묵상플랜', ('PLAN',)),
    # ⚠ 순서 — 흐름을 외부연결보다 **앞에**(2026-08-27 사용자 지시 「서로
    #   위치 교체하자」). 내부 자산이 먼저, 바깥으로 나가는 것이 마지막이다.
    ('chain', 'LP_B_CHAIN', '말씀의 흐름', ('CHAIN',)),
    # ⚠ 내 영상을 **같은 갈래**에 둔다 — 사용자에게는 둘 다 「영상 링크」이고
    #   갈래를 나누면 어디서 찾을지 매번 헷갈린다. 목록에서 이름표로 갈린다.
    ('media', 'LP_B_MEDIA', '외부연결', ('MEDIA', 'UMEDIA')),
    # ★★★ **묵상노트 갈래** (2026-08-30) — 갈래가 없으면 `KIND_BRANCH` 가
    #   비어 재고창고 목록에서 조용히 빠진다(§구절단락 사고와 같은 자리).
    ('note', 'LP_B_NOTE', '묵상노트', ('NOTE',)),
)
KIND_BRANCH = {k: b[0] for b in BRANCHES for k in b[3]}

#: ★★ 2026-08-24 — **연결을 통합 표로 옮겼다**(`db_link_migrate.py`).
#   `userdb.user_link_asset(link_type='<A>_<B>')` 한 행이 한 짝이다.
#   옛 표 `user_link` 은 되돌릴 수 있게 남아 있지만 **읽지 않는다.**
#   ⚠ 태그는 종전대로 `user_tag_link` 을 읽는다(사용자 지시 「태그는 손대지 마라」).
LINK_TBL = 'userdb.user_link_asset'

# ══════════════════════════════════════════════════════════════════
#  범위(scope) — **관리자와 사용자가 한 부품을 쓴다** (2026-08-25 · 3단계)
#
#  ⚠ §76 이 「sys 쪽 **어느 표에 쓸지는 13개 표를 놓고 정할 일**」이라 관리자
#    연결 탭을 **읽기 전용**으로 남겨 두었는데, **2026-08-25 통합으로 그 이유가
#    사라졌다 — 표가 하나다.** 이제 저장 대상만 갈아 끼우면 된다.
#  ⚠⚠ **두 벌을 만들지 않는다.** 태그 관리에서 일괄 치환으로 데인 자리다(§81).
# ══════════════════════════════════════════════════════════════════
SCOPES = {
    'USER': 'userdb.user_link_asset',   # 개인 DB — 배포되지 않는다
    'SYS':  'sys_link_asset',           # 배포 DB — 관리자만
}
# 개인 DB 에만 있는 자산 종류. **SYS 범위에서는 고를 수 없다** —
# 고르게 두면 배포 DB 가 남의 PC 에만 있는 번호를 가리키게 된다.
USER_ONLY_KINDS = ('ULENS', 'UNODE', 'USER_REF', 'NOTE', 'UMEDIA')

#: ★★★ **범위가 무엇을 가르나 — 단일 소스** (2026-08-29 신설).
#
#  사용자 확정(2026-08-29): 「이 기능은 관리자와 차이가 클 것이다.」 맞다 —
#  뼈대(3기둥·재고창고·고를 수 있는 자산)는 **같고**, 갈리는 것은 아래 여덟이다.
#  그전에는 `scope == 'SYS'` if 문이 이 파일에만 **아홉 자리**에 흩어져 있어서
#  화면을 늘릴 때마다 「여기도 갈라야 하나」를 매번 다시 판단해야 했다.
#  ⇒ **여기 한 표만 고친다.** 새 능력이 생기면 칸을 하나 더 만든다.
#
#  ⚠ **자산을 여기서 가르지 말 것** — 「무엇을 고를 수 있나」는 범위가 아니라
#    자산의 문제다(`ASSET_CAPS`). 여기서 가른 것이 34짝을 막았던 원인이다.
#    유일한 예외가 `no_kinds` 이고, 그 이유는 **배포물이 남의 PC 번호를
#    가리키면 안 되기 때문**이지 화면을 줄이려는 것이 아니다.
SCOPE_CAPS = {
    'SYS': dict(
        table='sys_link_asset',
        delete='PHYSICAL',       # 물리 삭제 — 복구는 감사 로그(§10-1)
        revive=False,            # 되살리기가 뜻이 없다(HIDE 를 안 만든다)
        show_hidden=True,        # 해제된 채 남은 것도 목록에 보인다
        marks=False,             # N/E/H 를 안 붙인다 — 전부 원본이다
        merge_sys=False,         # 배포 표만 읽는다(합치면 두 번 뜬다)
        merge_user_tags=False,   # 사용자 태그를 섞지 않는다
        edit_sys=True,           # 배포 자료를 직접 고친다
        trash=False,             # 휴지통이 없다
        no_kinds=USER_ONLY_KINDS,
    ),
    'USER': dict(
        table='userdb.user_link_asset',
        delete='HIDE',           # 삭제가 아니라 가리기 — 되돌릴 수 있다
        revive=True,
        show_hidden=False,       # 기본 안 보임 + [가린 것도 보기] 스위치
        marks=True,              # N / E / H (overlay_mark)
        merge_sys=True,          # sys 위에 내 것을 덮어 읽는다
        merge_user_tags=True,
        edit_sys=False,          # 배포 자료는 못 고친다 — 가릴 수만 있다
        trash=True,
        no_kinds=(),
    ),
}


def cap(scope, key):
    """그 범위의 능력 하나. **모르는 범위·칸은 터뜨린다** — 조용히 기본값을
    돌려주면 「관리자인데 사용자처럼 동작」이 오류 없이 지나간다."""
    try:
        d = SCOPE_CAPS[scope]
    except KeyError:
        raise ValueError('모르는 범위: %r (SYS 또는 USER)' % (scope,))
    if key not in d:
        raise KeyError('%s 에 없는 능력: %r' % (scope, key))
    return d[key]


def is_physical(scope):
    """지우면 정말 지워지나 (관리자) — 아니면 가리는 것인가 (사용자)."""
    return cap(scope, 'delete') == 'PHYSICAL'


def tbl(scope='USER'):
    """그 범위가 쓰는 표. 모르는 범위는 조용히 넘기지 않고 **터뜨린다.**"""
    return cap(scope, 'table')


def kinds(scope='USER'):
    """그 범위에서 선택할 수 있는 자산 종류.

    ⚠ 양쪽으로 거른다 — `USER_ONLY_*` 는 배포 DB 가 남의 PC 번호를 가리키게
      되므로 SYS 에서 빼고, `SYS_ONLY_*` 는 사용자 창을 흔들지 않으려고 USER
      에서 뺀다(2026-08-27 — 관리자 통합 연결관리를 열면서 늘린 셋).
    """
    # ⚠⚠ **`NOT_PICKABLE` 을 여기서 거른다** — 2026-08-29 실측으로 잡았다:
    #   그 상수는 값만 있고 **거르는 코드가 어디에도 없었다.** 그래서
    #   「빼 두었다」고 적힌 종류가 화면에는 그대로 떠 있었다(구절단락).
    #   ⇒ 고를 수 있는 종류를 정하는 문은 **여기 하나**다.
    no = (set(cap(scope, 'no_kinds')) | set(NOT_PICKABLE)
          | set(SYS_ONLY_KINDS if scope == 'USER' else ()))
    return tuple(k for k in KINDS if k not in no)



#: 화면 종류 → 자산 코드 넉 자. ⚠ `db_link_migrate._USER_KIND` 와 **같아야
#  한다** — 어긋나면 이전한 행을 화면이 못 찾는다(selftest 가 지킨다).
# ⚠⚠ **태그를 빠뜨리지 말 것** — `TAG` 는 코드가 **세 자**다(다른 것은 넉 자).
#   여기 없으면 `links_of` 가 `CODE.get('TAG','TAG')` 로 우연히 맞지만
#   `KIND_OF` 에는 안 실려 **태그 연결을 통째로 버린다**(2026-08-27 실측).
CODE = {'TAG': 'TAG', 'UTAG': 'UTAG', 'CHAIN': 'CHAI',
        'VERSE': 'VERS', 'ENTITY': 'ENTI', 'PERICOPE': 'PERI', 'MEDIA': 'MEDI',
        'BOOK_UNIT': 'BUNT', 'BOOK': 'BOOK', 'REF_UNIT': 'REFU',
        'USER_REF': 'UREF', 'LENS': 'CONT', 'NODE': 'NODE',
        'ULENS': 'UCNT', 'UNODE': 'UNOD', 'NOTE': 'NOTE',
        # ⚠⚠ **`MEDI` 와 다른 코드여야 한다** — 같은 이름을 쓰면 한 자리가
        #   sys·user 두 표를 가리켜 번호가 겹치는 날 딴 영상이 뜬다.
        'UMEDIA': 'UMED'}
KIND_OF = {v: k for k, v in CODE.items()}

#: 종류 → 사람이 읽는 이름 **폴백**. i18n 열쇠(`LP_K_<종류>`)가 먼저고 없으면 이것.
#  ⚠⚠ 이것이 없으면 화면에 **`REF_UNIT`·`ENTITY` 코드가 그대로** 뜬다
#    (2026-08-27 실측 — 연결하기 창 오른쪽 목록이 그랬다).
#  ★★ **폴백이 i18n(`LP_K_*`) 과 같아야 한다** (2026-08-29 · 항목 3-(c)).
#    그전에는 일곱이 어긋나 있었다 — `i18n.load` 가 안 된 자리(하네스·초기화
#    전)에서만 다른 이름이 뜨므로 **오류 없이 조용히 갈린다.**
#    ⚠ 「태그」라는 말을 안 쓴다(사용자 확정 「용어로 통합」) — `TAG`·`UTAG`
#      도 **용어**다. 갈래 이름(`LP_B_*`)과는 일부러 다르다: 갈래는 여러
#      종류를 묶는 이름이고(「도서·설교」), 여기는 낱낱의 이름이다(「도서 편」).
#    selftest 가 두 표가 어긋나지 않는지 잰다.
KIND_NAME = {
    'VERSE': '구절', 'TAG': '용어', 'UTAG': '내 용어',
    'LENS': '렌즈', 'NODE': '노드',
    'ULENS': '내 렌즈', 'UNODE': '내 노드', 'BOOK': '도서', 'BOOK_UNIT': '도서 편',
    'REF_UNIT': '자료집 글', 'USER_REF': '내 연구자료', 'ENTITY': '용어',
    'PERICOPE': '단락', 'PLAN': '묵상플랜', 'MEDIA': '외부연결',
    'NOTE': '묵상노트', 'UMEDIA': '내 영상', 'UMED': '내 영상',
    # `links_of` 가 그대로 넘기는 넉 자 코드도 함께 (한쪽만 두면 갈린다)
    'CHAIN': '말씀의 흐름', 'CHAI': '말씀의 흐름',
    'VERS': '구절', 'ENTI': '용어', 'PERI': '단락', 'MEDI': '외부연결',
    'BUNT': '도서 편', 'REFU': '자료집 글', 'UREF': '내 연구자료',
    'CONT': '렌즈', 'REFS': '자료집', 'RSSA': '수집 자료',
    'UCNT': '내 렌즈', 'UNOD': '내 노드',
}


def branch_name(kind, lang=None):
    """그 종류가 속한 **갈래**의 이름 (2026-08-29 · 항목 3-(c)).

    ★ 사용자 확정(2026-08-27) 「시작점과 재고창고의 분류/버튼은 구분되지만
      **모양은 사실상 동일**」 — 그런데 ① 은 **종류**로, ③ 은 **갈래**로
      묶고 있었다. ③ 에서 「도서·설교」를 눌렀는데 ① 에는 「도서 편」이 뜨니
      같은 것을 두 이름으로 부르는 셈이었다. ⇒ **두 칸이 같은 축을 쓴다.**
    ⚠ 넉 자 코드(`BUNT`)로도 들어온다 — `KIND_OF` 로 되돌려 찾는다.
    """
    k = str(kind or '').upper()
    k = k if k in KIND_BRANCH else KIND_OF.get(k, k)
    b = KIND_BRANCH.get(k)
    for x in BRANCHES:
        if x[0] == b:
            return _t(x[1], x[2])
    return kind_name(kind, lang)


def kind_name(kind, lang=None):
    """종류의 사람 이름. i18n → `KIND_NAME` → 코드 그대로."""
    k = str(kind or '')
    return _t('LP_K_' + k, KIND_NAME.get(k, k))


#: ★★★ **`link_type` 의 앞/뒤 코드를 꺼내는 SQL 조각** (2026-08-27 신설).
#
#  ⚠⚠⚠ **자리를 세면 안 된다.** 그전에는 `substr(link_type,1,4)`(앞) ·
#    `substr(link_type,6,4)`(뒤)로 잘랐는데 **앞 코드가 넉 자라고 단정**한
#    것이다. `TAG` 는 **세 자**다:
#        substr('TAG_BOOK',1,4) = 'TAG_'   ← 'TAG' 와 안 맞는다
#        substr('TAG_BOOK',6,4) = 'OOK'    ← 'BOOK' 과 안 맞는다
#    그래서 **태그 연결이 양쪽 모두에서 안 보였다**(사용자 신고 2026-08-27
#    「태그를 연결했는데 연결 팝업 오른쪽의 연결된 것 목록에는 표시되지 않는다」).
#    오류가 안 나고 **조용히 0건**이 된다 — 그래서 오래 안 보였다.
#  ⇒ `instr(link_type,'_')` 로 **밑줄 자리를 물어서** 가른다. 코드 길이가
#    바뀌어도 안 깨진다.
LT_A = "substr(link_type,1,instr(link_type,'_')-1)"
LT_B = "substr(link_type,instr(link_type,'_')+1)"


def split_lt(lt):
    """`TAG_BOOK` → `('TAG','BOOK')`. **파이썬 쪽 같은 규칙**."""
    a, _, b = str(lt or '').partition('_')
    return a, b


def _t(key, dflt):
    try:
        import i18n
        return i18n.t(key, dflt)
    except Exception:
        return dflt


# ── 표 ────────────────────────────────────────────────────────────────────
DDL = """
CREATE TABLE IF NOT EXISTS userdb.user_link (
  link_id       INTEGER PRIMARY KEY AUTOINCREMENT,
  a_kind        TEXT    NOT NULL,
  a_id          INTEGER NOT NULL,
  a_end         INTEGER,
  b_kind        TEXT    NOT NULL,
  b_id          INTEGER NOT NULL,
  b_end         INTEGER,
  note          TEXT,
  record_status TEXT    NOT NULL DEFAULT 'LIVE',
  created_at    TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS userdb.ux_ul_pair
  ON user_link(a_kind, a_id, COALESCE(a_end,-1), b_kind, b_id, COALESCE(b_end,-1));
CREATE INDEX IF NOT EXISTS userdb.ix_ul_a ON user_link(a_kind, a_id);
CREATE INDEX IF NOT EXISTS userdb.ix_ul_b ON user_link(b_kind, b_id);
CREATE INDEX IF NOT EXISTS userdb.ix_ul_verse ON user_link(b_kind, b_id, b_end);
"""


def init_schema(conn):
    """멱등. ⚠ `userdb.` 접두를 빼면 **배포 DB 에 만들어진다**(§21-5)."""
    for stmt in DDL.strip().split(';'):
        if stmt.strip():
            conn.execute(stmt)
    conn.commit()


# ── 두 끝 정렬 — 한 짝 한 행의 열쇠 ───────────────────────────────────────
def _norm_end(e):
    try:
        e = int(e)
    except Exception:
        return None
    return e if e > 0 else None


def pair(one, two):
    """두 끝 `(종류, 번호[, 끝])` 을 **정렬**해 `(a…, b…)` 로.

    ⚠ 이 정렬이 「한 짝 한 행」의 전부다 — 넣는 쪽이 어디든 같은 행이 된다.
    ⚠⚠ **넉 자 코드로 정렬한다**(2026-08-24). 통합 표의 `link_type` 이
      그 코드로 만들어지므로 정렬 기준도 같아야 한다. 실측으로 확인 —
      지금 쓰이는 조합 11가지는 옛 정렬(긴 이름)과 **결과가 같다.**
    """
    def norm(t):
        k = str(t[0]).upper()
        return (k, int(t[1]), _norm_end(t[2] if len(t) > 2 else None))
    a, b = norm(one), norm(two)
    if (CODE.get(a[0], a[0]), a[1], a[2] or -1) > \
       (CODE.get(b[0], b[0]), b[1], b[2] or -1):
        a, b = b, a
    return a + b


def _lt(a_kind, b_kind):
    """두 종류 → `link_type`. 모르는 종류면 이름 그대로 쓴다."""
    return '%s_%s' % (CODE.get(a_kind, a_kind), CODE.get(b_kind, b_kind))


#: 종류 → (표, PK 칸). `exists()` 가 쓴다.
#  ⚠ 여기 없는 종류는 **검사를 건너뛴다**(막지 않는다) — 모르는 것을 막으면
#    새 자산을 늘릴 때 조용히 못 잇게 된다.
_EXISTS_SQL = {
    'VERSE': ('bible_index', 'verse_id'),
    'PERICOPE': ('sys_pericope_asset', 'pericope_id'),
    'ENTITY': ('sys_entity_master', 'entity_id'),
    'TAG': ('sys_tag_asset', 'sys_tag_id'),
    'UTAG': ('userdb.user_tag_asset', 'user_tag_id'),
    'LENS': ('sys_unit_asset', 'sys_unit_id'),
    'NODE': ('sys_unit_asset', 'sys_unit_id'),
    'ULENS': ('userdb.user_unit_asset', 'user_unit_id'),
    'UNODE': ('userdb.user_unit_asset', 'user_unit_id'),
    'BOOK': ('sys_book_asset', 'book_id'),
    'BOOK_UNIT': ('sys_book_unit', 'unit_id'),
    'REF_UNIT': ('sys_ref_unit', 'ref_unit_id'),
    'USER_REF': ('user_ref_asset', 'ref_id'),
    'PLAN': ('sys_bible_plan', 'plan_id'),
    'MEDIA': ('sys_media_asset', 'media_id'),
    'UMEDIA': ('userdb.user_media_asset', 'user_media_id'),
    'CHAIN': ('sys_chain_master', 'chain_id'),
    # ★ 묵상노트 — 자산 번호는 그 글 행의 PK 다 (2026-08-30).
    'NOTE': ('userdb.user_text_asset', 'user_text_id'),
}


def exists(conn, kind, tid):
    """그 자산이 정말 있는가. 모르는 종류는 **True**(막지 않는다).

    ★★★ 2026-08-29 신설 — **없는 자산에 연결이 붙어 있었다.**
      실측: 사용자가 `PERICOPE 2747` 에 여섯 건을 이었는데 단락 번호는
      5214~8626 이라 **2747 은 없는 자산**이다. 화면에는 `#2747` 로 떴다.
      뿌리는 My Edit 최상단 갈래 단추였다 — `set_anchor(kind, None)` 이라
      **종류만 바꾸고 번호는 옛것**을 그대로 들고 있었다(그 단추는 걷었다).
      ⇒ 그래도 **저장하는 문에서 한 번 더 막는다** — 입구가 늘어도 안 샌다.
    """
    k = str(kind or '').upper()
    k = k if k in _EXISTS_SQL else KIND_OF.get(k, k)
    q = _EXISTS_SQL.get(k)
    if not q or not tid:
        return True
    try:
        return conn.execute('SELECT 1 FROM %s WHERE %s=? LIMIT 1'
                            % q, (int(tid),)).fetchone() is not None
    except Exception:
        return True                     # 표가 없는 환경(시험용)은 막지 않는다


def add(conn, one, two, note=None, scope='USER', rel=None, sort_order=None,
        verify=True):
    """연결 하나. 이미 있으면 되살린다(HIDE → LIVE). 새 행을 만들지 않는다.

    `scope='SYS'` 면 배포 표에 쓴다(관리자). `rel` 은 연결의 성격이고
    **`rel='NEXT'` 가 곧 경로**다 — 경로용 표도 탭도 따로 두지 않는다.

    ⚠⚠ **경로는 기존 연결 행에 표시를 얹지 않고 자기 행을 만든다.**
      경로 배포는 **전체 교체**(`plan_route.import_routes` 가 DELETE)라,
      표시로 얹으면 그 교체가 **남의 연결까지 지운다**(§80 에서 실제로 막은 자리).
    ⚠ `rel` 을 바꾸면 **다른 짝**이다 — 유일 열쇠가 `COALESCE(rel_code,'')` 를
      포함한다(§81). 같은 두 자산에 관점 여럿이 붙는 것이 정상이다(실측 102짝).
    """
    T = tbl(scope)
    # ⚠⚠ **없는 자산은 잇지 않는다** (2026-08-29). 조용히 넣으면 화면에
    #   `#2747` 같은 유령 줄이 남고, 그 줄을 지우려면 SQL 을 짜야 한다.
    #   ⚠ `verify=False` 는 **시험 전용**(가짜 번호 999901…). 화면에서 끄지 말 것.
    if verify:
        for _one in (one, two):
            if not exists(conn, _one[0], _one[1]):
                raise ValueError('없는 자산입니다: %s #%s'
                                 % (_one[0], _one[1]))
    a_k, a_i, a_e, b_k, b_i, b_e = pair(one, two)
    if (a_k, a_i, a_e) == (b_k, b_i, b_e):
        return False                      # 자기 자신은 안 잇는다
    # ⚠ **`a_end` 는 통합 표에 자리가 없다** — 실측 362행 전부 비어 있고
    #   `end_id` 는 B쪽 끝이다. A가 구간인 연결이 생기면 그때 칸을 만든다.
    if a_e:
        return False
    cur = conn.execute(
        "UPDATE %s SET record_status='LIVE', note=COALESCE(?, note), "
        "       sort_order=COALESCE(?, sort_order) "
        " WHERE link_type=? AND clicked_id=? AND target_id=? "
        "   AND COALESCE(end_id,-1)=? AND COALESCE(rel_code,'')=?" % T,
        (note, sort_order, _lt(a_k, b_k), a_i, b_i,
         b_e if b_e else -1, rel or ''))
    if cur.rowcount == 0:
        conn.execute(
            "INSERT INTO %s(link_type,clicked_id,target_id,end_id,note,"
            "rel_code,sort_order,record_status) VALUES(?,?,?,?,?,?,?,'LIVE')" % T,
            (_lt(a_k, b_k), a_i, b_i, b_e, note, rel, sort_order))
    conn.commit()
    return True


def remove(conn, one, two, scope='USER', rel=None):
    """뗀다.

    ★★ **범위가 지우는 법을 가른다** (2026-08-27 사용자 확정 — 「나는
      관리자이므로 **물리삭제** 해야 한다」):
      · `SYS`(관리자) = **DELETE** — 배포 표에 HIDE 를 쌓으면 그 찌꺼기가
        전 사용자에게 배포된다. 복구는 감사 로그(§10-1)가 맡는다 —
        DELETE 도 old_json 전체가 기록된다.
      · `USER`(사용자) = **HIDE** — 덮개 모델. 배포 연결을 가린 것은 행으로
        남아야 하고, 되살리면 행이 안 는다.
    ⚠ `rel` 을 안 주면 **관점 없는 행만** 뗀다. 관점이 붙은 행을 떼려면
      그 관점을 함께 준다 — 안 그러면 **엉뚱한 행이 남아** 화면에 그대로 뜬다.
    """
    a_k, a_i, a_e, b_k, b_i, b_e = pair(one, two)
    if a_e:
        return
    where = (" WHERE link_type=? AND clicked_id=? AND target_id=? "
             "   AND COALESCE(end_id,-1)=? AND COALESCE(rel_code,'')=?")
    args = (_lt(a_k, b_k), a_i, b_i, b_e if b_e else -1, rel or '')
    if is_physical(scope):
        conn.execute("DELETE FROM %s %s" % (tbl(scope), where), args)
    else:
        conn.execute("UPDATE %s SET record_status='HIDE' %s"
                     % (tbl(scope), where), args)
    conn.commit()


#: **연결의 층** — 한 자산은 **한 층에만** 건다 (2026-08-30 사용자 확정)
#  구절 `VERS` · 단락 `PERI` · 도서 편(장·책 강해) `BUNT` · 책 `BOOK`
LAYER_KINDS = ('VERSE', 'PERICOPE', 'BOOK_UNIT', 'BOOK')


def layers_of(conn, asset_kind, asset_id, vid=None):
    """그 자산이 **어느 층에 이미 걸려 있나** → [(층종류, 층번호, 범위글)].

    ★★★ 2026-08-30 사용자 확정 — 「**하나의 컨텐츠가 여러 층에 중복되는 등록은
      적절하지 않다.** 어차피 표시할 때 모두 표시해 주기 때문에 … **중복이므로
      금지하자**」.
      실측이 그 판단을 받친다 — 구절을 고르면 그 절이 속한 단락·장·책의 연결이
      **이미 함께** 뜬다. 위층에 또 걸면 **같은 것이 두 줄**이 된다.
    ⚠ `vid` 를 주면 **그 절에 닿는 층만** 본다(다른 책에 걸린 것은 상관없다).
    ⚠ **양방향으로 본다** — 넓은 것을 먼저 걸든 좁은 것을 먼저 걸든 같은 중복이다.
      한쪽만 막으면 차례만 바꿔 같은 중복이 생긴다.
    """
    out = []
    ak = str(asset_kind).upper()
    code = CODE.get(ak, ak)
    try:
        for lt, a_i, b_i, b_e in conn.execute(
                "SELECT link_type, clicked_id, target_id, end_id "
                "  FROM sys_link_asset "
                " WHERE ((%s=? AND clicked_id=?) OR (%s=? AND target_id=?)) "
                "   AND COALESCE(record_status,'LIVE')='LIVE' "
                "UNION ALL "
                "SELECT link_type, clicked_id, target_id, end_id "
                "  FROM userdb.user_link_asset "
                " WHERE ((%s=? AND clicked_id=?) OR (%s=? AND target_id=?)) "
                "   AND COALESCE(record_status,'LIVE')='LIVE' "
                % (LT_A, LT_B, LT_A, LT_B),
                (code, asset_id, code, asset_id) * 2):
            pp = lt.split('_')
            if len(pp) != 2:
                continue
            if pp[0] == code and a_i == asset_id:
                ok, oi, oe = KIND_OF.get(pp[1], pp[1]), b_i, b_e
            else:
                ok, oi, oe = KIND_OF.get(pp[0], pp[0]), a_i, None
            if ok not in LAYER_KINDS:
                continue
            sv, ev = _layer_span(conn, ok, oi, oe)
            if sv is None:
                continue
            if vid is not None and not (sv <= vid <= (ev or sv)):
                continue
            out.append((ok, oi, scope_label(conn, sv, ev)))
    except Exception as e:
        print('[link_picker layers_of] %s' % e)
    return out


def _layer_span(conn, kind, tid, end=None):
    """그 층이 덮는 절 범위 → (start_vid, end_vid)."""
    try:
        if kind == 'VERSE':
            return int(tid), int(end or tid)
        if kind == 'PERICOPE':
            r = conn.execute('SELECT start_vid, end_vid FROM '
                             'sys_pericope_asset WHERE pericope_id=?',
                             (tid,)).fetchone()
            return (r[0], r[1]) if r else (None, None)
        if kind == 'BOOK_UNIT':
            r = conn.execute('SELECT start_vid, COALESCE(end_vid, start_vid) '
                             '  FROM sys_book_unit WHERE unit_id=?',
                             (tid,)).fetchone()
            return (r[0], r[1]) if r and r[0] else (None, None)
        if kind == 'BOOK':
            r = conn.execute('SELECT MIN(verse_id), MAX(verse_id) '
                             '  FROM bible_index WHERE bcode=?',
                             (tid,)).fetchone()
            return (r[0], r[1]) if r else (None, None)
    except Exception:
        pass
    return (None, None)


def veto(conn, one, two, rel=None, on=True):
    """**배포 연결을 내 화면에서 가린다**(덮개) — 개인 표에 HIDE 행을 넣는다.

    ★★★ 2026-08-30 신설. `remove()` 는 `UPDATE ... SET record_status='HIDE'`
      라서 **개인 표에 없는 배포 연결에는 0행**이었다 — 그래서 그동안 배포
      연결은 「관리자 화면 몫」이라 알리고 못 뺐다. 덮개 모델에서는 **가릴 수
      있어야 한다**(배포 DB 는 그대로 두고 내 화면에서만).
    ★ 이 문 하나로 **층을 가려 가릴 수 있다** (사용자 확정) —
      단락 연결을 `(PERICOPE, 단락)` 로 주면 **그 단락 전체**에서,
      `(VERSE, 이 절)` 로 주면 **이 절에서만** 사라진다. 두 번째가 곧
      「거부권(veto)」이라 이름이 그렇다.
    ⚠ `on=False` 면 **그 가림 행을 지운다**(되살리기).
    """
    a_k, a_i, a_e, b_k, b_i, b_e = pair(one, two)
    lt, T = _lt(a_k, b_k), 'userdb.user_link_asset'
    where = (" WHERE link_type=? AND clicked_id=? AND target_id=? "
             "   AND COALESCE(end_id,-1)=? AND COALESCE(rel_code,'')=?")
    args = (lt, a_i, b_i, b_e if b_e else -1, rel or '')
    if not on:
        conn.execute("DELETE FROM %s %s AND record_status='HIDE'" % (T, where),
                     args)
        conn.commit()
        return
    hit = conn.execute("SELECT 1 FROM %s %s" % (T, where), args).fetchone()
    if hit:
        conn.execute("UPDATE %s SET record_status='HIDE' %s" % (T, where), args)
    else:
        conn.execute(
            "INSERT INTO %s(link_type, clicked_id, target_id, end_id, "
            "               rel_code, record_status) VALUES(?,?,?,?,?,'HIDE')"
            % T, (lt, a_i, b_i, b_e, rel))
    conn.commit()


def vetoed(conn, kind, tid):
    """이 자산에서 **내가 가린 짝** → {(종류, 번호, 끝)}."""
    out = set()
    code = CODE.get(str(kind).upper(), kind)
    try:
        for lt, a_i, b_i, b_e in conn.execute(
                "SELECT link_type, clicked_id, target_id, end_id "
                "  FROM userdb.user_link_asset WHERE record_status='HIDE'"):
            pp = lt.split('_')
            if len(pp) != 2:
                continue
            if pp[0] == code and a_i == tid:
                out.add((KIND_OF.get(pp[1], pp[1]), b_i, b_e))
            elif pp[1] == code and b_i == tid:
                out.add((KIND_OF.get(pp[0], pp[0]), a_i, None))
    except Exception:
        pass
    return out


#: **닻을 가진 자산** — 글을 담고 있어 「어디 것인지」가 뜻을 갖는 것들.
#  ⚠ 태그·용어는 넣지 않는다(2026-08-31 사용자 「수정할 여지가 없다. 필요
#    없다」) — 닻도 없고 내용이 오염될 일도 없다.
ANCHORED_KINDS = ('NOTE', 'USER_REF')


def anchors_of(conn, kind, tid, lang='KO'):
    """그 자산의 **닻** → `[(갈래, 설명, (대상종류, 번호))]`.

    연결이 아니라 「붙어 있는 자리」다. 셋째 칸은 **그 자리가 무엇인가** —
    잇는 쪽에서 「지금 출발지와 같은 자리인가」를 가리는 데 쓴다.

    ★★★ 2026-08-31 사용자 확정 — 「닻도 연결처럼 보여주자는 뜻이라면 찬성이다.
      **모든 자산이 닻, 연결 모두 한 눈으로 보면서 관리**해야 한다」.
    ★★ **닻과 연결은 다르다 — 그래서 뗄 수 없다.**
      · 연결 = `user_link_asset` 한 행 · 끊어도 양쪽이 산다
      · 닻   = 자산 표의 **칸**(`clicked_id`·`body_unit_id` …) · 끊으면 그
        자산이 **어디에도 안 붙은 미아**가 된다(§notes.md — 실제로 2026-08-15 에
        `clicked_id=NULL` 노트 두 편이 생겨 영영 안 보였다)
      ⇒ ①에 **보이되** `⇨` 는 「이것은 연결이 아니라 닻입니다」라고 답한다.
    ⚠ **종류를 늘릴 때 여기 한 줄** — 화면마다 흩으면 갈래에 따라 빠진다
      (2026-08-31 에 실제로 그랬다: 도서 편 노트는 보이고 구절 노트는 안 보였다).
    """
    kind = str(kind).upper()
    out = []
    try:
        if kind == 'VERSE':
            # 이 절을 닻으로 하는 **묵상노트**(실측 `VERS_NOTE` 24편)
            for nid, ti in conn.execute(
                    "SELECT user_text_id, "
                    " COALESCE(NULLIF(title,''), substr(COALESCE(contents,''),1,24)) "
                    "  FROM userdb.user_text_asset "
                    " WHERE text_type='VERS_NOTE' AND clicked_id=? "
                    "   AND COALESCE(record_status,'') <> 'HIDE'", (tid,)):
                out.append((kind_name('NOTE'),
                            '%s — %s' % (ti or '#%s' % nid,
                                         _t('LP_A_NOTE', '이 구절에 쓴 노트')),
                            ('NOTE', int(nid))))
        elif kind == 'NOTE':
            # 그 노트가 사는 자리(구절 또는 노드)
            r = conn.execute(
                "SELECT text_type, clicked_id FROM userdb.user_text_asset "
                " WHERE user_text_id=?", (tid,)).fetchone()
            if r and r[1]:
                k2 = 'NODE' if str(r[0]).startswith('NODE') else 'VERSE'
                out.append((kind_name(k2),
                            '%s — %s' % (label_of(conn, k2, r[1], None, lang),
                                         _t('LP_A_ANCHOR', '이 노트가 붙은 자리')),
                            (k2, int(r[1]))))
        elif kind == 'USER_REF':
            # 그 글이 시작된 자리 — 칸으로만 남아 있을 수 있다
            r = conn.execute(
                "SELECT body_unit_id, verse_id, pericope_id, entity_id "
                "  FROM user_ref_asset WHERE ref_id=?", (tid,)).fetchone()
            for v, k2 in zip(r or (), ('BOOK_UNIT', 'VERSE', 'PERICOPE',
                                       'ENTITY')):
                if v:
                    out.append((kind_name(k2),
                                '%s — %s' % (label_of(conn, k2, v, None, lang),
                                             _t('LP_A_ORIGIN', '이 글이 시작된 자리')),
                                (k2, int(v))))
    except Exception as e:
        print('[anchors_of] %s' % e)
    return out


def links_of(conn, kind, tid, lang='KO', scope='USER', include_hidden=False):
    """그 자산에 붙은 것 전부 → [{kind,id,end,label,src}] (자산 + 태그).

    ⚠⚠ **2026-08-25 정정** — 태그도 2026-08-24 에 통합 표로 옮겼는데 이 함수만
      옛 표(`user_tag_link`)를 계속 읽고 있었다. 그래서 **새로 붙인 태그가
      연결하기 창에 안 보였다**(실측으로 확인 — 붙인 뒤 0개, 옛 표에 직접
      넣으면 1개). 이제 `tag_picker.tags_of` 한 곳만 쓴다."""
    kind = str(kind).upper()
    tid = int(tid)
    out = []
    # ★ 통합 표 — `link_type` 앞뒤가 A·B의 종류다. 양쪽에서 다 보인다.
    code = CODE.get(kind, kind)
    # ⚠ `LIKE 'VERS\_%'` 를 쓰지 않는다 — `_` 가 와일드카드라 정확하지 않고
    #   ESCAPE 를 매번 붙여야 한다. 코드는 **늘 넉 자**이므로 substr 이 확실하다.
    # ⚠ **범위마다 읽는 표가 다르다.** USER 는 개인 표 + (아래) 배포 표를
    #   합쳐 보여 주고, SYS 는 **배포 표만** 본다 — 관리자는 「배포될 것」을 본다.
    # ⚠ `include_hidden` 은 **관리자 화면용**이다(해제된 연결을 회색으로 보이고
    #   재연결하는 흐름 — 구절간 연결관리가 쓴다). 사용자 목록은 기본 LIVE 만.
    _st = "" if include_hidden else         " AND COALESCE(record_status,'LIVE')='LIVE' "
    for lt, a_i, b_i, b_e, _rel, _rs in conn.execute(
            ("SELECT link_type, clicked_id, target_id, end_id, rel_code, "
             "       COALESCE(record_status,'LIVE') FROM %s "
             " WHERE ((%s=? AND clicked_id=?) "
             "     OR (%s=? AND target_id=?)) %s") % (tbl(scope), LT_A, LT_B, _st),
            (code, tid, code, tid)):
        parts = lt.split('_')
        if len(parts) != 2:
            continue
        a_c, b_c = parts
        # ⚠⚠ **태그 줄은 여기서 세지 않는다 — 아래 태그 블록이 맡는다**
        #   (2026-08-30 실측으로 잡았다). 태그도 2026-08-24 에 통합 표로 옮겨져
        #   `TAG_VERS`·`TAG_NOTE` 가 이 훑기에 **함께 걸린다** — 그런데 아래에서
        #   `tag_picker.tags_of` 로 또 넣으므로 **같은 태그가 두 번** 떴다
        #   (실측: 구절 9 의 태그 201 이 `src=LINK` 와 `src=TAG` 로 두 줄).
        #   묵상노트를 자산으로 올리며 드러났지만 **구절에서도 나던 옛 버그**다.
        #   ⚠ 관리자(`merge_user_tags` 꺼짐)는 아래 블록이 안 도므로 **여기가
        #     유일한 출처**다 — 그때는 거르지 않는다.
        if cap(scope, 'merge_user_tags') and (a_c in ('TAG', 'UTAG')
                                              or b_c in ('TAG', 'UTAG')):
            continue
        a_k, b_k = KIND_OF.get(a_c, a_c), KIND_OF.get(b_c, b_c)
        if a_k == kind and a_i == tid:
            k, i, e, out_dir = b_k, b_i, b_e, True     # 내가 A — 나가는 쪽
        else:
            k, i, e, out_dir = a_k, a_i, None, False   # 내가 B — 들어오는 쪽
        # ⚠ **양방향이 중복이 아니다**(실측 2026-08-25): 렌즈 205 는 도서 30 과
        #   `CONT_BOOK` · `BOOK_CONT` 를 **둘 다** 갖는다 — 「가는 길」과 「오는 길」
        #   이다. 방향을 안 실으면 화면에 **같은 이름이 두 번** 뜨고 사람이 왜
        #   그런지 알 수 없다.
        out.append({'kind': k, 'id': i, 'end': e, 'src': 'LINK',
                    'rel': _rel, 'is_route': (_rel == 'NEXT'),
                    'outgoing': out_dir, 'hidden': (_rs == 'HIDE'),
                    'label': label_of(conn, k, i, e, lang)})
    if not cap(scope, 'merge_user_tags'):
        # ⚠ SYS 는 위에서 이미 배포 표를 읽었다 — `_sys_links` 를 또 부르면
        #   **같은 연결이 두 번** 뜬다. 태그도 사용자 태그를 섞으면 안 된다.
        out.sort(key=_sort_key)
        return out
    try:
        # ★ 태그 저장소는 `tag_picker` 가 단일 소스다 — 여기서 SQL 을 또 쓰면
        #   저장은 통합 표에, 조회는 옛 표에 하는 사고가 다시 난다.
        import tag_picker
        # ⚠⚠ **배포 태그를 빠뜨리고 있었다 — 279건이 통째로 안 보였다**
        #   (2026-08-31 사용자 신고 「#새해·#부르심·#하나님의 속성 이 연결되었다고
        #   표시되는데 My Edit 에는 전혀 없다」. 실측으로 잡았다).
        #   원인 = **거르는 자리가 둘인데 둘 다 새는 꼴**이었다:
        #     ① 위 일반 훑기는 `TAG_`·`UTAG_` 를 **일부러 뺀다**(두 번 세지 않으려고)
        #     ② 그런데 여기서 `tags_of` 를 **기본 범위(USER)** 로 불러 개인 표만 읽었다
        #   배포 태그는 `sys_link_asset` 에 있다 — 실측 `TAG_BUNT` 229 ·
        #   `TAG_CONT` 41 · `TAG_BOOK` 8 · `TAG_PLAN` 1. 도서 화면은
        #   `db_tag_system.fetch_tags_for` 로 배포 표를 읽으니 보이고, 이 창만
        #   못 봤다 — **같은 것을 두 문이 다르게 답하던 것**이다(§95차 사고).
        #   ⇒ 사용자 범위에서는 **배포 + 개인을 합친다.** 관리자(SYS)는 배포만.
        #   ⇒ 2026-09-01 — 합치는 일을 **`tag_picker.tags_read` 한 문**으로
        #     옮겼다. 여기서만 합쳐 두었더니 **P1 티커가 그대로 새고 있었다**
        #     (같은 병이 화면을 옮겨 다시 났다).
        _seen_tg, _tag_rows = set(), []
        try:
            _tag_rows = list(
                tag_picker.tags_read(None, kind, tid, lang)
                if cap(scope, 'merge_user_tags')
                else tag_picker.tags_of(None, kind, tid, lang, scope=scope))
        except Exception as e:
            print('[link_picker tags] %s' % e)
        # ⚠ **내가 가린 태그는 뺀다** — 덮개가 배포를 이긴다(2026-08-31).
        #   가림 행은 `TAG_<대상>` HIDE 이고 `vetoed` 가 그것을 낸다.
        _vt = {i for k, i, _e in vetoed(conn, kind, tid) if k == 'TAG'}             if cap(scope, 'merge_user_tags') else set()
        for _src, tg, _nm, _cat in _tag_rows:
            if tg in _seen_tg:
                continue
            _seen_tg.add(tg)
            if tg in _vt:
                # 「가린 것도 보기」를 켰으면 **흐리게 남긴다** — 그래야 그 자리
                # 에서 되살릴 수 있다(안 그러면 휴지통에서만 되돌린다).
                if not include_hidden:
                    continue
            # ★ 분류(축)를 이름 뒤에 — 「왼쪽에 분류값이 없다」(2026-08-27
            #   사용자). 태그 고르기(재고)에서 보이던 축이 현황에도 보인다.
            _lb = label_of(conn, 'TAG', tg, None, lang)
            if _cat:
                _lb = '%s  · %s' % (_lb, _cat)
            out.append({'kind': 'TAG', 'id': tg, 'end': None, 'src': 'TAG',
                        'label': _lb, 'hidden': tg in _vt})
    except Exception as e:
        print('[link_picker tags] %s' % e)
    out += _sys_links(conn, kind, tid, lang)
    if kind == 'VERSE':
        out += _via_links(conn, tid, lang, scope, out)
    out.sort(key=_sort_key)
    return out


#: 연결이 걸린 **층** — 구절 화면의 3단 묶음 (2026-08-30 사용자 확정)
VIA_VERSE, VIA_PERI, VIA_WIDE = 'VERSE', 'PERI', 'WIDE'


def _via_links(conn, vid, lang, scope, already):
    """**이 절을 품는 더 큰 단위에 걸린 연결** (2026-08-30 사용자 확정).

    ★★★ 왜 (사용자 — 「링크(영상)은 단락단위로 연결되어 있더라도 **결국 구절을
      클릭하면 표시되어야** 한다 … 구절과 단락은 차원이 다르다. **단락은 구절의
      모음**이다. 구절을 선택하면 구절을 포함하는 단락과 연결된 것을 보여
      주어야 한다. **그래야 구절/단락 중복연결을 피할 수 있다**」).
      구절수집관리가 **단락 중심으로 수집**되므로 특히 중요하다 —
      실측 `MEDI_PERI` 5,661 대 `MEDI_VERS` **0**.

    돌려주는 각 줄에 `via` 를 실어 화면이 3단으로 묶는다:
      `VIA_PERI` 그 절이 속한 BODY 단락 · `VIA_WIDE` 장·책 등 넓은 범위.

    ⚠ **구조가 깨끗해서 규칙이 한 줄이다**(실측) — BODY 로 안 덮인 절 0 ·
      BODY 끼리 겹침 0 ⇒ **한 절 = 정확히 한 단락**. 그리고 단락 연결은
      **전부 BODY** 에만 있다(CHRONOLOGICAL 0).
    ⚠ **중복은 절 쪽이 이긴다** — 같은 용어가 절에도 단락에도 걸린 것이
      **265건**이다. 그냥 합치면 같은 이름이 두 번 뜬다. 더 구체적인 쪽(절)을
      남긴다.
    ⚠ **넓은 범위는 링크가 아니라 칸이다** — 강해설교(도서 편)는
      `sys_book_unit.start_vid~end_vid` 로 절을 덮는다(실측 6,347편 ·
      장 전체를 덮는 편 1,503 · 최대 13,498절). 그래서 링크 표를 훑어서는
      **영영 안 나온다.**
    """
    out = []
    seen = {(x['kind'], x['id'], x.get('end')) for x in already}
    # ★ **이 절에서만 가린 것**(거부권) — 층을 가려 가린 결과다.
    veto_here = vetoed(conn, 'VERSE', vid)
    try:
        # ── ② 그 절이 속한 단락에 걸린 것 ──
        pr = conn.execute(
            "SELECT pericope_id, start_vid, end_vid"
            "  FROM sys_pericope_asset p"
            " WHERE p.peri_type='BODY'"
            "   AND COALESCE(p.record_status,'LIVE')='LIVE' AND "
            + _vr.covers_sql('p', 'start_vid', 'end_vid') + " LIMIT 1",
            _vr.covers_args(vid)).fetchone()
        if pr:
            span = _range_text(conn, pr[1], pr[2], lang)
            for x in links_of(conn, 'PERICOPE', pr[0], lang, scope=scope):
                k = (x['kind'], x['id'], x.get('end'))
                if k in seen or (x['kind'], x['id'], None) in veto_here:
                    continue          # 절 쪽이 이긴다 · 이 절에서 가린 것도
                seen.add(k)
                x = dict(x)
                x['via'] = VIA_PERI
                x['via_kind'] = 'PERICOPE'
                x['via_id'] = pr[0]
                x['via_label'] = span
                x['via_n'] = (pr[2] or pr[1]) - pr[1] + 1
                out.append(x)
        # ── ③ 이 절을 덮는 **넓은 범위** — 도서 편(강해) ──
        # ⚠⚠ **`verse_id` 는 차례가 아니다** — 절체계 이형(`SoS 6:14` = vid
        #   **31113**, `3Jn 1:15` = 31114)이 표 맨 뒤에 붙어 있다(§4-6).
        #   번호로 재면 **아6:1~아6:14 한 편이 13,488절을 덮고**, 책 가드만
        #   두면 **같은 책 아7·8장은 그대로 샌다**(실측 27절).
        #   ⇒ 판정은 `verse_range` 한 문 — 차례(`sort_order`)로 견준다.
        # ★ 2026-10-13 — 어느 절에 거나는 **원본이 정한다**(`book_link` · docs/1.txt 72-2) —
        #   마이어 묵상은 주제 구절 한 절에만 걸린다(장 전체에 걸려 늘 떴다).
        import book_link as _BL
        for uid, sv, ev, rs, re_ in conn.execute(
                "SELECT bu.unit_id, " + _BL.anchor_sql('bu', 'ba') + ", "
                "       bu.start_vid, COALESCE(bu.end_vid, bu.start_vid) "
                "  FROM sys_book_unit bu JOIN sys_book_asset ba "
                "    ON ba.book_id = bu.book_id "
                " WHERE COALESCE(bu.record_status,'LIVE')='LIVE' "
                "   AND COALESCE(ba.record_status,'LIVE')='LIVE' "
                "   AND bu.start_vid IS NOT NULL AND "
                + _BL.hit_sql('bu', 'ba')
                + " LIMIT 60",
                _BL.hit_args(vid)):
            if rs == re_:
                continue              # 한 절짜리는 ① 이 맡는다
            k = ('BOOK_UNIT', uid, None)
            if k in seen or k in veto_here:
                continue
            seen.add(k)
            out.append({'kind': 'BOOK_UNIT', 'id': uid, 'end': None,
                        'src': 'SYS', 'via': VIA_WIDE,
                        'via_kind': 'BOOK_UNIT', 'via_id': uid,
                        'via_label': _range_text(conn, sv, ev, lang),
                        'via_n': ev - sv + 1,
                        'label': label_of(conn, 'BOOK_UNIT', uid, None, lang)})
    except Exception as e:
        print('[link_picker _via_links] %s' % e)
    return out


def _nm0(conn, bcode, lang='KO', full=False):
    """책 이름(약명/정식) — `scope_label` 이 쓰는 작은 문."""
    col = 'full_name' if full else 'short_name'
    for lc in (lang or 'KO', 'EN'):
        try:
            r = conn.execute('SELECT %s FROM book_names '
                             'WHERE book_code=? AND lang_code=?' % col,
                             (bcode, lc)).fetchone()
        except Exception:
            r = None
        if r and r[0]:
            return r[0]
    return ''


def scope_label(conn, sv, ev, lang='KO'):
    """연결이 걸린 **범위를 한 칸에** — `창1:20~23` · `창1장` · `창세기`.

    ★★★ 2026-08-30 사용자 지시 — 「**창1:1~3, 창1장, 창세기** 등으로 구분값
      표시」. 묶음 머리(별도 레코드) 대신 **줄마다 제 범위를 말한다.**
    ★ 규칙 — 넓은 쪽부터 본다:
        책 전체 → 책 이름 · 장 전체 → `창1장` · 그 밖 → `창1:20~23`
        한 절   → **빈 칸**(그것이 기본이라 적으면 잡음이다)
    ⚠ 표기는 `verse_ref`·`book_names` 한 곳에서 — 화면마다 지어내지 않는다.
    """
    try:
        if not sv:
            return ''
        ev = ev or sv
        a = conn.execute('SELECT bcode, chapter, verse FROM bible_index '
                         'WHERE verse_id=?', (sv,)).fetchone()
        b = conn.execute('SELECT bcode, chapter, verse FROM bible_index '
                         'WHERE verse_id=?', (ev,)).fetchone()
        if not a or not b:
            return ''
        # ★ 한 절도 **적는다** (2026-08-30 사용자 지시 「범위를 공란으로 두지
        #   말고 **창1:1 이라고 표시**하고 싶다」).
        #   ⚠ 비용은 줄당 조회 한 번뿐이다(목록이 수십 줄) — 부담이 안 된다.
        if sv == ev:
            import verse_ref
            return verse_ref.label('VERSE', _nm0(conn, a[0], lang), a[1], a[2])

        def _nm(bc, full=False):
            col = 'full_name' if full else 'short_name'
            for lc in (lang or 'KO', 'EN'):
                r = conn.execute('SELECT %s FROM book_names '
                                 'WHERE book_code=? AND lang_code=?' % col,
                                 (bc, lc)).fetchone()
                if r and r[0]:
                    return r[0]
            return ''
        if a[0] == b[0]:
            n_book = conn.execute('SELECT COUNT(*) FROM bible_index '
                                  'WHERE bcode=?', (a[0],)).fetchone()[0]
            n_span = conn.execute(
                'SELECT COUNT(*) FROM bible_index bi WHERE bi.bcode=? AND '
                + _vr.between_sql('bi.verse_id'),
                [a[0]] + _vr.between_args(sv, ev)).fetchone()[0]
            if n_span >= n_book:
                return _nm(a[0], True)                    # 책 전체
            if a[1] == b[1]:
                n_ch = conn.execute(
                    'SELECT COUNT(*) FROM bible_index '
                    ' WHERE bcode=? AND chapter=?', (a[0], a[1])).fetchone()[0]
                if n_span >= n_ch:
                    return _t('LP_SC_CHAP', '{book}{n}장').format(
                        book=_nm(a[0]), n=a[1])           # 장 전체
        import verse_ref
        nm2 = _nm(b[0]) if a[0] != b[0] else None
        return verse_ref.range_label(_nm(a[0]), a[1], a[2], b[1], b[2], nm2)
    except Exception:
        return ''


def _range_text(conn, sv, ev, lang='KO'):
    """`창1:1~5` — 표기는 `verse_ref` 가 정한다(화면마다 갈리면 안 된다)."""
    try:
        import verse_ref
        a = conn.execute('SELECT bcode, chapter, verse FROM bible_index '
                         'WHERE verse_id=?', (sv,)).fetchone()
        b = conn.execute('SELECT bcode, chapter, verse FROM bible_index '
                         'WHERE verse_id=?', (ev or sv,)).fetchone()
        if not a or not b:
            return ''

        def _sh(bc):
            for lc in (lang or 'KO', 'EN'):
                r = conn.execute('SELECT short_name FROM book_names '
                                 'WHERE book_code=? AND lang_code=?',
                                 (bc, lc)).fetchone()
                if r and r[0]:
                    return r[0]
            return ''
        nm2 = _sh(b[0]) if a[0] != b[0] else None
        return verse_ref.range_label(_sh(a[0]), a[1], a[2], b[1], b[2], nm2)
    except Exception:
        return ''


def targets_of(conn, kind, tid, want, scope='USER'):
    """그 자산에 붙은 **한 종류만** 번호로 → `[(id, end)]` (정렬·중복 제거).

    ★★ **화면이 자기 SQL 을 쓰지 않게 하는 문** (2026-08-27 사용자 지적
      「팝업에서 갈렙에 연결되어 목록에 표시되었다. 그런데 주요용어 ▸ 연구자료
      서브탭에는 안 나오고 탭 헤더가 (0) 이다. **통합 로직이 필요하다**」).

    ⚠⚠ **이름의 앞뒤가 어느 쪽인지 화면이 알 필요가 없다.** 실측 —
      `link_picker` 는 `ENTI_UREF`(2건)로 쓰는데 옛 이전 도구는
      `UREF_ENTI`(15건)로 넣었고 **두 집합이 하나도 안 겹친다.** 화면이 한
      이름만 물으면 **나머지가 통째로 안 보인다** — 그것이 「(0)」의 정체다.
      ⇒ 이 함수는 `A_B` · `B_A` 를 **둘 다** 보고 합친다.
    ⚠ `label_of` 를 부르지 않는다 — 이름은 화면이 제 표에서 붙인다(빠르다).
    """
    kind, want = str(kind).upper(), str(want).upper()
    me, you = CODE.get(kind, kind), CODE.get(want, want)
    seen, out = set(), []
    for a_i, b_i, b_e, fwd in conn.execute(
            "SELECT clicked_id, target_id, end_id, 1 FROM %(T)s "
            " WHERE COALESCE(record_status,'LIVE')='LIVE' "
            "   AND link_type=? AND clicked_id=? "
            "UNION ALL "
            "SELECT clicked_id, target_id, end_id, 0 FROM %(T)s "
            " WHERE COALESCE(record_status,'LIVE')='LIVE' "
            "   AND link_type=? AND target_id=?" % {'T': tbl(scope)},
            ('%s_%s' % (me, you), int(tid),
             '%s_%s' % (you, me), int(tid))):
        # 내가 A 면 상대는 B(끝값이 상대 것) · 내가 B 면 상대는 A(끝값 없음)
        i, e = (b_i, b_e) if fwd else (a_i, None)
        if (i, e) in seen:
            continue
        seen.add((i, e))
        out.append((i, e))
    return sorted(out)


def _sys_links(conn, kind, tid, lang):
    """**기본 자료에 이미 딸려 있는 연결** — 읽기 전용 (2026-08-21 사용자 지적
    「연결 버튼 누를 때 이미 연결된 값들을 가져와야 한다」).

    ★★★ **2026-08-30 — 종류를 가리지 않고 전부 읽는다.**
      ⚠⚠ 그전에는 `REF_UNIT`·`BOOK_UNIT` **둘만** 손으로 적어 두었다. 그래서
        **구절·단락·용어를 출발지로 열면 배포 연결이 통째로 안 보였다** —
        사용자 신고 「링크자산은 연결팝업 왼쪽 화면에 표시되지도 않는다」.
        실측: 창1:1 의 배포 연결 **57건 → 화면 0건** · 그 절이 속한 단락 5214 의
        영상 연결 **27건 → 화면 0건**. 창이 텅 빈 것처럼 보이고, 사용자는
        이미 있는 것을 또 건다(이 함수를 만든 바로 그 까닭이다).
      ⇒ 일반 훑기와 **같은 문법**으로 `sys_link_asset` 을 양방향으로 읽는다.
        종류를 늘려도 여기는 손댈 것이 없다.
    ⚠ **여기서 뺄 수 없다** — 배포 DB(`sys_*`)는 관리자 화면 몫이다(§21-4).
      `src='SYS'` 로 표시해 두고 [⇨ …] 가 이유를 알린다.
    ⚠ **내가 가린 것은 뺀다** — 덮개(`user_link_asset` 의 HIDE 행)가 이겨야
      한다. 안 그러면 가려도 배포 쪽에서 되살아나 보인다.
    ⚠ 태그(`TAG_`·`UTAG_`)는 **부르는 쪽 태그 블록**이 이미 넣는다 — 여기서
      또 넣으면 두 번 뜬다(§2026-08-30 중복 사고).
    """
    out = []
    code = CODE.get(kind, kind)
    try:
        # 내가 가린 짝 — (종류, 번호, 끝)
        hid = set()
        try:
            for lt, a_i, b_i, b_e in conn.execute(
                    "SELECT link_type, clicked_id, target_id, end_id "
                    "  FROM userdb.user_link_asset "
                    " WHERE record_status='HIDE'"):
                pp = lt.split('_')
                if len(pp) != 2:
                    continue
                if pp[0] == code and a_i == tid:
                    hid.add((KIND_OF.get(pp[1], pp[1]), b_i, b_e))
                elif pp[1] == code and b_i == tid:
                    hid.add((KIND_OF.get(pp[0], pp[0]), a_i, None))
        except Exception:
            pass
        for lt, a_i, b_i, b_e in conn.execute(
                "SELECT link_type, clicked_id, target_id, end_id "
                "  FROM sys_link_asset "
                " WHERE ((%s=? AND clicked_id=?) OR (%s=? AND target_id=?)) "
                "   AND COALESCE(record_status,'LIVE')='LIVE' "
                " LIMIT 400" % (LT_A, LT_B),
                (code, tid, code, tid)):
            parts = lt.split('_')
            if len(parts) != 2:
                continue
            a_c, b_c = parts
            if a_c in ('TAG', 'UTAG') or b_c in ('TAG', 'UTAG'):
                continue                      # 태그는 부르는 쪽이 넣는다
            if a_c == code and a_i == tid:
                k, i2, e2 = KIND_OF.get(b_c, b_c), b_i, b_e
            else:
                k, i2, e2 = KIND_OF.get(a_c, a_c), a_i, None
            if (k, i2, e2) in hid:
                continue
            out.append({'kind': k, 'id': i2, 'end': e2, 'src': 'SYS',
                        'label': label_of(conn, k, i2, e2, lang)})
    except Exception as e:
        print('[link_picker _sys_links %s] %s' % (kind, e))
    return out


# ── 표시 쪽이 함께 읽는 조각 ────────────────────────────────────────────
# ⚠ 화면마다 SQL 을 새로 쓰지 말 것 — 여기 한 곳에서 고친다.
#   `pair()` 가 두 끝을 정렬해 넣으므로 USER_REF 가 a 쪽에 오지만
#   (U < V), 종류가 늘면 뒤집힐 수 있어 양쪽을 다 본다.
#   ★ 2026-08-24 통합 표. `link_type` 앞 넉 자가 A, 뒤 넉 자가 B다.
#     ⚠ **A쪽 끝(`a_end`)은 자리가 없다** — 실측 전부 비어 있었다(위 `add` 참조).
#       그래서 「내 자료가 a」인 갈래만 구간을 본다.
#: ⚠ 옛 상수 `SQL_REFS_COVERING_VERSE` 는 **걷었다**(2026-09-10) —
#:   `verse_id` 로 범위를 재 절체계 이형 구간에서 샜다. 부르는 곳 0 을 확인하고
#:   지웠고, 새 코드는 아래 `refs_covering_*` · `refs_overlapping_*` 을 쓴다.

_REFS_HEAD = (
    " SELECT CASE WHEN " + LT_A + "='UREF' THEN clicked_id"
    "             ELSE target_id END"
    "   FROM userdb.user_link_asset"
    "  WHERE COALESCE(record_status,'LIVE')='LIVE'")


def refs_covering_sql():
    """내 연구자료가 **이 절 하나**를 덮는가 → 물음표 4개.

    ★ 인자는 `refs_covering_args(vid)` 가 맞춘다 — 손으로 세지 않는다.
    """
    return (_REFS_HEAD +
            "    AND ((link_type='UREF_VERS' AND "
            + _vr.covers_sql('user_link_asset', 'target_id', 'end_id') + ")"
            "      OR (link_type='VERS_UREF' AND clicked_id=?))")


def refs_covering_args(vid):
    return _vr.covers_args(vid) + [vid]


def refs_overlapping_sql():
    """내 연구자료가 **[lo, hi] 구간과 겹치는가** → 물음표 6개.

    ⚠ A쪽(`VERS_UREF`)은 끝 칸이 없어 **한 절**이다 — 그 절이 구간 안인가로 잰다.
    """
    return (_REFS_HEAD +
            "    AND ((link_type='UREF_VERS' AND "
            + _vr.overlaps_sql('user_link_asset', 'target_id', 'end_id') + ")"
            "      OR (link_type='VERS_UREF' AND "
            + _vr.between_sql('user_link_asset.clicked_id') + "))")


def refs_overlapping_args(lo, hi=None):
    hi = hi if hi is not None else lo
    return _vr.overlaps_args(lo, hi) + _vr.between_args(lo, hi)

SQL_REFS_OF_KIND = (
    " SELECT CASE WHEN " + LT_A + "='UREF' THEN clicked_id"
    "             ELSE target_id END"
    "   FROM userdb.user_link_asset"
    "  WHERE COALESCE(record_status,'LIVE')='LIVE'"
    "    AND ((link_type='UREF_'||? AND target_id=?)"
    "      OR (link_type=?||'_UREF' AND clicked_id=?))")

SQL_VERSES_OF_REF = (
    " SELECT CASE WHEN " + LT_A + "='VERS' THEN clicked_id"
    "             ELSE target_id END,"
    "        CASE WHEN " + LT_A + "='VERS' THEN NULL ELSE end_id END"
    "   FROM userdb.user_link_asset"
    "  WHERE COALESCE(record_status,'LIVE')='LIVE'"
    "    AND ((link_type='UREF_VERS' AND clicked_id=?)"
    "      OR (link_type='VERS_UREF' AND target_id=?))")


_ORDER = {'VERSE': 0, 'TAG': 1, 'LENS': 2, 'NODE': 3, 'ULENS': 4, 'UNODE': 5,
          'BOOK': 6, 'BOOK_UNIT': 7, 'REF_UNIT': 8, 'USER_REF': 9}


def _sort_key(x):
    """성경은 **넓은 것부터**(책 → 장 → 절), 나머지는 종류 순."""
    if x['kind'] == 'VERSE':
        span = (x['end'] or x['id']) - x['id']
        return (0, -span, x['id'])
    return (1 + _ORDER.get(x['kind'], 9), 0, x['id'])


# ── 구절 범위 — 책·장·단락·절은 **입력 단추**일 뿐 ────────────────────────
def book_range(conn, bcode):
    r = conn.execute("SELECT MIN(verse_id), MAX(verse_id) FROM bible_index "
                     "WHERE bcode=?", (bcode,)).fetchone()
    return (r[0], r[1]) if r and r[0] else None


def chapter_range(conn, bcode, chapter):
    r = conn.execute("SELECT MIN(verse_id), MAX(verse_id) FROM bible_index "
                     "WHERE bcode=? AND chapter=?", (bcode, chapter)).fetchone()
    return (r[0], r[1]) if r and r[0] else None


def peri_range(conn, vid):
    """그 절이 든 **가장 작은 BODY 단락**의 범위."""
    r = conn.execute(
        "SELECT start_vid, end_vid FROM sys_pericope_asset p"
        " WHERE p.peri_type='BODY'"
        "   AND COALESCE(p.record_status,'LIVE')='LIVE' AND "
        + _vr.covers_sql('p', 'start_vid', 'end_vid')
        + " ORDER BY (p.end_vid-p.start_vid) LIMIT 1",
        _vr.covers_args(vid)).fetchone()
    return (r[0], r[1]) if r else None


def range_span(conn, start, end):
    """이 범위가 **책 전체인가 장 전체인가** — 표시 이름을 정한다."""
    end = end or start
    r = conn.execute("SELECT bcode, chapter FROM bible_index WHERE verse_id=?",
                     (start,)).fetchone()
    if not r:
        return 'VERSE'
    b, ch = r
    br = book_range(conn, b)
    if br and br == (start, end):
        return 'BOOK'
    cr = chapter_range(conn, b, ch)
    if cr and cr == (start, end):
        return 'CHAP'
    return 'VERSE'


# ── 이름 ──────────────────────────────────────────────────────────────────
# SYS 범위에만 나오는 종류 — 사용자 화면 `KINDS` 밖이다(실측: PLAN·MEDI·REFS·RSSA).
# ⚠ 이름을 못 대면 화면에 **`#47`** 이 뜬다 — 관리자가 무엇인지 알 수 없다.
_SYS_ONLY_LABEL = {
    'PLAN':     ("SELECT contents FROM sys_text_asset WHERE text_type='PLAN_TITLE'"
                 " AND clicked_id=? AND TRIM(COALESCE(contents,''))<>'' ORDER BY CASE lang_code WHEN ? THEN 0"
                 " WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1", True),
    'MEDIA':    ('SELECT title FROM sys_media_asset WHERE media_id=?', False),
    'UMEDIA':   ('SELECT COALESCE(NULLIF(TRIM(title),\'\'), url)'
                 ' FROM userdb.user_media_asset WHERE user_media_id=?', False),
    'REF_SRC':  ('SELECT COALESCE(title_ko, title) FROM sys_ref_source'
                 ' WHERE ref_src_id=?', False),
    'RSS':      ('SELECT title FROM sys_ref_asset WHERE ref_id=?', False),
    'ENTITY':   ("SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
                 " AND clicked_id=? AND TRIM(COALESCE(contents,''))<>'' ORDER BY CASE lang_code WHEN ? THEN 0"
                 " WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1", True),
    # ★ 흐름 — 정수 신원 → 이름 (그 언어 → EN → 코드)
    'CHAIN':    ("SELECT COALESCE((SELECT c.chain_name FROM sys_chain_catalog c"
                 "  WHERE c.chain_code=m.chain_code"
                 "    AND TRIM(COALESCE(c.chain_name,''))<>''"
                 "  ORDER BY CASE UPPER(c.lang_code) WHEN ? THEN 0"
                 "           WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1), m.chain_code)"
                 "  FROM sys_chain_master m WHERE m.chain_id=?", 'LANG_FIRST'),
    # ⚠ **구절단락이 빠져 있었다**(2026-08-27) — `PERI` 7,086행인데 이름을 못
    #   대서 화면에 `#5214` 가 떴다.
    # ⚠ **`title` 칸이다**(위 `_candidates` 와 같은 이유)
    'PERICOPE': ("SELECT title FROM sys_text_asset WHERE text_type='PERI_TITLE'"
                 " AND clicked_id=? AND TRIM(COALESCE(title,''))<>'' ORDER BY CASE lang_code WHEN ? THEN 0"
                 " WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1", True),
}
# 넉 자 코드 → 위 열쇠
KIND_OF_SYS = {'PLAN': 'PLAN', 'MEDI': 'MEDIA', 'REFS': 'REF_SRC',
               'RSSA': 'RSS', 'ENTI': 'ENTITY', 'PERI': 'PERICOPE',
               'CHAI': 'CHAIN'}


def _sys_only_label(conn, kind, tid, lang):
    # ⚠ `links_of` 는 **넉 자 코드**(REFS·MEDI·RSSA)를 그대로 넘긴다 —
    #   `KIND_OF` 가 그 셋을 모르기 때문이다(사용자 화면 종류가 아니라서).
    #   매핑을 빼먹어 「REFS #1」이 떴다(실측). 두 이름을 다 받는다.
    spec = _SYS_ONLY_LABEL.get(kind) or _SYS_ONLY_LABEL.get(
        KIND_OF_SYS.get(kind, ''))
    if not spec:
        return None
    sql, want_lang = spec
    try:
        if want_lang == 'LANG_FIRST':
            args = (lang, tid)
        elif want_lang:
            args = (tid, lang)
        else:
            args = (tid,)
        r = conn.execute(sql, args).fetchone()
    except Exception:
        return None
    return (r[0] or None) if r else None


# ── 이 묶음의 항목 목록 ──────────────────────────────────────────────
# ★★★ **연결 탭에서 유닛을 갈아탈 수 있게 한다** (1.txt 7-1 대안2 · 사용자
#   「유닛목록/항목목록 탭에서 유닛을 클릭하고 연결하려면 연결 탭으로 이동해야
#   함 … **다시 다른 유닛을 선택하려면 탭 이동해야 함**」 ·
#   「**선택한 도서 등에 소속된 유닛 목록만 표시**」).
#   구절 관리 화면은 왼쪽에 절 목록이 **늘** 있어 곧장 연결되는데, 서고 메뉴는
#   책 단위로 늘어서 있어 그럴 수 없었다. ⇒ 연결 탭이 **제 묶음의 항목**을
#   스스로 안다.
# ⚠⚠ **「형제」가 아니라 「묶음의 항목」이다** — 첫 판을 형제로 짰더니 주인이
#   유닛일 때만 들었고, 서고 화면의 연결 탭 주인은 유닛을 고르기 전까지
#   **도서·자료집·렌즈**라 목록이 **다섯 화면에서 전부 0줄**이었다(하네스가
#   잡았다). 그래서 묶음 자체(BOOK·REF_SRC·LENS)를 주어도 받는다.
# ⚠ **묶음이 없는 갈래는 빈 목록**이다 — 화면이 그때 칸을 안 그린다(§0-1
#   빈 서랍 금지). 용어·플랜·구절이 그렇다.
SIB_CAP = 400

# 주인 갈래 → **목록에 낼 항목의 갈래**. 묶음 자신과 그 항목이 같은 값을 가리킨다.
_SIB_CHILD = {
    'BOOK': 'BOOK_UNIT', 'BOOK_UNIT': 'BOOK_UNIT',
    'REF_SRC': 'REF_UNIT', 'REF_UNIT': 'REF_UNIT',
    'LENS': 'NODE', 'NODE': 'NODE',
    'ULENS': 'UNODE', 'UNODE': 'UNODE',
}


def siblings(conn, kind, tid, q=None, cap=SIB_CAP):
    """`([(항목 갈래, id, 이름), …], 전체수)` — 그 자산이 **속한 묶음의 항목들**.

    ⚠⚠ **`label_of` 를 줄마다 부르지 않는다** — 유닛이 **3,519개인 도서**가
      있어(실측 스펄전 설교집) 그만큼 조회가 는다. **한 조회로** 이름까지
      가져온다.
    ⚠ 상한을 넘으면 자르되 **지금 고른 것은 반드시 넣는다** — 목록에서
      사라지면 어디에 있는지 알 수 없다.
    """
    kind = str(kind or '').upper()
    child = _SIB_CHILD.get(kind)
    if not child:
        return [], 0
    rows = []
    try:
        if child == 'BOOK_UNIT':
            where = ('u.book_id=?' if kind == 'BOOK' else
                     'u.book_id=(SELECT book_id FROM sys_book_unit '
                     'WHERE unit_id=?)')
            rows = conn.execute(
                "SELECT u.unit_id, COALESCE(NULLIF(TRIM(u.unit_label),''), "
                "       '(제목 없음) #' || u.unit_id) "
                "  FROM sys_book_unit u "
                " WHERE u.record_status='LIVE' AND " + where +
                " ORDER BY u.sequence, u.unit_id", (tid,)).fetchall()
        elif child == 'REF_UNIT':
            where = ('r.ref_src_id=?' if kind == 'REF_SRC' else
                     'r.ref_src_id=(SELECT ref_src_id FROM sys_ref_unit '
                     'WHERE ref_unit_id=?)')
            rows = conn.execute(
                "SELECT r.ref_unit_id, "
                "       TRIM(COALESCE(r.unit_code,'') || ' ' || "
                "            COALESCE(NULLIF(TRIM(r.unit_label),''), "
                "                     NULLIF(TRIM(r.unit_question),''), "
                "                     '(제목 없음)')) "
                "  FROM sys_ref_unit r "
                " WHERE r.record_status='LIVE' AND " + where +
                " ORDER BY r.sequence, r.ref_unit_id", (tid,)).fetchall()
        else:                                   # NODE · UNODE
            t = 'sys' if child == 'NODE' else 'user'
            cid = ('?' if kind in ('LENS', 'ULENS') else
                   "(SELECT clicked_id FROM {t}_link_asset WHERE "
                   "link_type='CONT_NODE' AND target_id=? AND "
                   "record_status='LIVE' LIMIT 1)".format(t=t))
            # ⚠⚠ **`.format` 은 바로 앞 문자열 하나에만 붙는다** — 이어
            #   붙인 조각들의 `{t}` 가 그대로 남아 SQL 이 통째로 깨졌다
            #   (실측 `unrecognized token: "{"` · 렌즈 목록이 영영 0줄).
            #   ⇒ **다 이은 뒤에 한 번** 채운다.
            sql = ("SELECT n.{t}_unit_id, COALESCE(NULLIF(TRIM("
                   "       n.unit_name_sid),''), '(이름 없음)') "
                   "  FROM {t}_unit_asset n "
                   "  JOIN {t}_link_asset l ON l.target_id = n.{t}_unit_id "
                   "   AND l.link_type='CONT_NODE' AND l.record_status='LIVE' "
                   " WHERE n.record_status='LIVE' AND l.clicked_id = "
                   + cid +
                   " ORDER BY n.sort_order, n.{t}_unit_id").format(t=t)
            rows = conn.execute(sql, (tid,)).fetchall()
    except Exception as e:                                # noqa: BLE001
        print('[siblings] %s' % e)
        return [], 0
    if len(rows) <= 1:
        return [], 0                    # 하나뿐이면 갈아탈 것이 없다
    total = len(rows)
    if (q or '').strip():
        key = q.strip().lower()
        rows = [r for r in rows if key in (r[1] or '').lower() or r[0] == tid]
    if len(rows) > cap:
        keep = [r for r in rows if r[0] == tid]
        rows = rows[:cap]
        if keep and keep[0] not in rows:
            rows = rows[:cap - 1] + keep
    return [(child, r[0], r[1]) for r in rows], total


def label_of(conn, kind, tid, end=None, lang='KO'):
    """줄에 보일 이름. 못 찾으면 번호."""
    kind = str(kind).upper()
    try:
        if kind == 'VERSE':
            return _verse_label(conn, tid, end, lang)
        if kind == 'TAG':
            import tag_picker
            for src, i, nm, cat, full, *_mk in tag_picker.all_tags(None, lang):
                if src == 'SYS' and i == tid:
                    return nm
            return '#%s' % tid
        if kind in ('LENS', 'NODE'):
            r = conn.execute("SELECT unit_name_sid FROM sys_unit_asset "
                             "WHERE sys_unit_id=?", (tid,)).fetchone()
            return (r and r[0]) or ('#%s' % tid)
        if kind in ('ULENS', 'UNODE'):      # 내 렌즈·내 노드 — 사용자 표식 [u]
            # ★ 2026-09-01 표시정책 — 사용자 데이터 표식은 어디서나 `[u]` 하나
            #   (`overlay_mark.NEW`). ◈ 는 의미연결 표식과 겹쳐 걷었다.
            import overlay_mark as _om
            r = conn.execute("SELECT unit_name_sid FROM user_unit_asset "
                             "WHERE user_unit_id=?", (tid,)).fetchone()
            nm = (r and r[0]) or ('#%s' % tid)
            return '%s %s' % (_om.NEW, nm)
        if kind == 'BOOK':
            r = conn.execute(
                "SELECT COALESCE((SELECT t.title FROM sys_book_asset_text t "
                "  WHERE t.book_id=b.book_id AND UPPER(t.lang_code)=UPPER(?) "
                "  LIMIT 1), b.title) FROM sys_book_asset b WHERE b.book_id=?",
                (lang, tid)).fetchone()
            return (r and r[0]) or ('#%s' % tid)
        if kind == 'BOOK_UNIT':
            # ⚠ **번역 제목을 먼저** — 후보 목록(`_candidates`)과 같은 이름이어야
            #   한다(2026-08-21 사용자 「목록은 영어, 오른쪽은 한글」).
            r = conn.execute(
                "SELECT COALESCE((SELECT t.title FROM sys_book_asset_text t "
                "  WHERE t.book_id=b.book_id AND UPPER(t.lang_code)=UPPER(?) "
                "  LIMIT 1), b.title), "
                "       COALESCE(ta.contents, u.unit_label) "
                "  FROM sys_book_unit u "
                "  JOIN sys_book_asset b ON b.book_id=u.book_id "
                "  LEFT JOIN sys_text_asset ta "
                "         ON ta.text_type='BOOK_UNIT_LABEL' "
                "        AND ta.clicked_id=u.unit_id "
                "        AND UPPER(ta.lang_code)=UPPER(?) "
                "        AND ta.record_status='LIVE' "
                " WHERE u.unit_id=?", (lang, lang, tid)).fetchone()
            return ('%s · %s' % (r[0], r[1])) if r else ('#%s' % tid)
        if kind == 'REF_UNIT':
            # ⚠ 글 제목도 **그 언어의 것**을 먼저 본다(안 그러면 목록과 어긋난다)
            # ★ 목록 요약(REF_UNIT_SHORT)이 있으면 앞에 — 후보 목록과 같은 꼴
            _sh = conn.execute(
                "SELECT title FROM sys_text_asset "
                " WHERE text_type='REF_UNIT_SHORT' AND clicked_id=? "
                "   AND TRIM(COALESCE(title,''))<>'' "
                "   AND COALESCE(record_status,'LIVE')='LIVE' "
                " ORDER BY CASE UPPER(lang_code) WHEN UPPER(?) THEN 0 "
                "          WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                (tid, lang)).fetchone()
            r = conn.execute(
                "SELECT COALESCE(s.title_ko, s.title), "
                "       COALESCE((SELECT x.title FROM sys_ref_text x "
                "         WHERE x.ref_unit_id=u.ref_unit_id "
                "           AND UPPER(x.lang_code)=UPPER(?) "
                "           AND TRIM(COALESCE(x.title,''))<>'' LIMIT 1), "
                "                (SELECT x2.title FROM sys_ref_text x2 "
                "         WHERE x2.ref_unit_id=u.ref_unit_id LIMIT 1), "
                "                u.unit_label) "
                "  FROM sys_ref_unit u JOIN sys_ref_source s "
                "    ON s.ref_src_id=u.ref_src_id WHERE u.ref_unit_id=?",
                (lang, tid)).fetchone()
            if not r:
                return '#%s' % tid
            if _sh and _sh[0]:
                return '%s · %s · %s' % (r[0], _sh[0], r[1])
            return '%s · %s' % (r[0], r[1])
        if kind == 'USER_REF':
            r = conn.execute("SELECT title FROM user_ref_asset WHERE ref_id=?",
                             (tid,)).fetchone()
            return (r and r[0]) or ('#%s' % tid)
        if kind == 'NOTE':
            # ★★ **출발지 이름이 곧 묵상노트의 제목**이다 (2026-08-30 사용자
            #   지시 — 「그래야 출발지 이름 자체가 묵상노트의 제목으로 표시될
            #   수 있음」). 제목이 비면 본문 첫 줄로 대신한다.
            #   ⚠ 본문 첫 줄은 「관련구절 창1:1」 같은 **머리글**일 수 있다 —
            #     그 줄은 건너뛴다(`note_refr_panel._split_verse_ref` 와 같은 규칙).
            r = conn.execute(
                "SELECT title, contents FROM userdb.user_text_asset "
                " WHERE user_text_id=?", (tid,)).fetchone()
            if not r:
                return '#%s' % tid
            t = (r[0] or '').strip()
            if t:
                return t
            try:
                from note_refr_panel import _VERSE_PREFIX as _NP
            except Exception:
                _NP = '관련구절 '
            for ln in (r[1] or '').split(chr(10)):
                ln = ln.strip()
                if ln and not ln.startswith(_NP.strip()):
                    return ln[:40]
            return '#%s' % tid
    except Exception as e:
        print('[link_picker label %s] %s' % (kind, e))
    # ⚠ SYS 범위에서만 나오는 종류 — 못 대면 `#47` 이 뜬다
    nm = _sys_only_label(conn, kind, tid, lang)
    if nm:
        return nm
    return '#%s' % tid


def _verse_label(conn, start, end, lang):
    """`[책] 로마서` · `[8장] 롬8:1~8:39` · `롬8:28~30` — **범위가 이름을 정한다**."""
    end = end or start
    r = conn.execute(
        "SELECT bn.short_name, bi.chapter, bi.verse, bi.bcode FROM bible_index bi "
        "  JOIN book_names bn ON bn.book_code=bi.bcode AND UPPER(bn.lang_code)=UPPER(?) "
        " WHERE bi.verse_id=?", (lang, start)).fetchone()
    if not r:
        return '#%s' % start
    sn, ch, vs, _b = r
    span = range_span(conn, start, end)
    try:
        import verse_ref
        head = verse_ref.label(verse_ref.SCOPE_BOOK, sn, ch, vs)
    except Exception:
        head = '%s %s:%s' % (sn, ch, vs)
    if span == 'BOOK':
        return '[%s] %s' % (_t('LP_R_BOOK', '책'), sn)
    if span == 'CHAP':
        return '[%s%s] %s' % (ch, _t('LP_R_CHAP', '장'), sn)
    if end != start:
        r2 = conn.execute("SELECT chapter, verse FROM bible_index WHERE verse_id=?",
                          (end,)).fetchone()
        if r2:
            return ('%s~%s' % (head, r2[1]) if r2[0] == ch
                    else '%s~%s:%s' % (head, r2[0], r2[1]))
    return head


# ── 화면 ──────────────────────────────────────────────────────────────────
_LBL_W = 9          # 왼쪽 라벨 칸 — 「연결대상」이 가장 길다


def _lbl(parent, text):
    """왼쪽 줄 머리 — **넷의 입력 시작선을 맞춘다**(연구자료 옛 칸의 규격).

    ⚠ **글꼴을 적지 않는다**(§36) — 안 적으면 TkDefaultFont = 통합 폰트 'ui'."""
    import tkinter as tk
    return tk.Label(parent, text=text, width=_LBL_W, anchor='w')


def _tv_style(db_path, name):
    """목록 트리 표준 규격 — `theme_font.list_style` 한 함수(§36).

    등록해 두면 통합 폰트를 바꿀 때 `reapply_all` 이 저절로 따라온다."""
    try:
        import theme_font
        theme_font.list_style(name, db_path)
    except Exception as e:
        print('[link_picker _tv_style] %s' % e)


def _finish_theme(win):
    """**다 지은 뒤** 테마·글꼴을 입힌다 (2026-08-21).

    ⚠ `ui_theme.adopt` 는 부를 때 있는 자식만 훑는다 — 창을 만들자마자 부르면
      그 뒤에 붙는 위젯이 통째로 흰 바탕으로 남는다(사용자 신고 「배경이 흰색
      같은 것이 어른거린다」). **팝업을 만들면 마지막 줄에서 부를 것.**"""
    try:
        import ui_theme
        ui_theme.adopt(win)
    except Exception as e:
        print('[link_picker _finish_theme] %s' % e)


# ══════════════════════════════════════════════════════════════════════
#  출발지 띠 — 도착지 기준 연쇄연결 (2026-08-29 · 항목 5)
# ══════════════════════════════════════════════════════════════════════
def _with_anchor_bar(host, db_path, kind, tid, **kw):
    """띠 + 몸통. **띠는 「지나온 출발지」이지 경로가 아니다.**

    ★★★ 사용자 확정 (2026-08-29 — 앞선 내 설계를 정정한 것):
      「**My Edit 때문에 띠를 만든 것이다.** 지난 경로를 다시 기준점으로
        잡으려면 반드시 필요하다.」
      「**Journey map 과 같은 개념이 아니다.** 어떤 체계나 연결성을 전제로
        하지 않는 개념이다. … 체계적 연결성은 전혀 없다. 다만 **이미 지나온
        출발점으로 돌아가서 연결상태와 업데이트 상태를 다시 점검**하기 위한 것.」

    ⇒ 그래서 이렇게 한다:
      · **누르면 그것이 곧 출발지** — 「출발지로 지정」 단추를 따로 안 둔다
      · **자르지 않는다** — 앞쪽을 눌러도 뒤쪽 칸이 살아 있다
      · **호스트가 바뀌어도 안 지운다** — 지나온 기록이지 지금의 경로가 아니다
      · 20칸 저장 · 한 번에 여섯 · 나머지는 [◀][▶]
      · 저장소는 `asset_pick` 의 `ME_RECENT` **하나**(My Edit 의 [최근 ▾]과 같은 것)

    ⚠ 내가 처음 만든 것(빵부스러기·자르기·[↺ 처음]·호스트 바뀌면 초기화)은
      **전부 틀렸다.** 그것은 경로 모형이고 사용자가 말한 것은 방문 기록이다.
    """
    import tkinter as tk
    import asset_pick

    lang = kw.get('lang_getter')
    lang = (lang() if callable(lang) else 'KO') or 'KO'
    try:
        import ui_theme
        _bg = ui_theme.C('panel_alt') or '#ECF0F1'
    except Exception:
        _bg = '#ECF0F1'

    outer = tk.Frame(host)
    outer.pack(fill='both', expand=True)
    bar = tk.Frame(outer, bg=_bg)
    bar.pack(fill='x')
    body = tk.Frame(outer)
    body.pack(fill='both', expand=True)

    st = {'kind': str(kind).upper(), 'id': int(tid), 'api': None,
          'redraw': None,
          # ★ 사시 자리는 **껍데기가 들고 있다** — 몸통을 다시 지어도
          #   사용자가 잡아 둔 폭이 그대로 온다(2026-08-29).
          'sash': {},
          # ★★ **재고창고에서 고른 것도 껍데기가 든다** (1.txt 1-1) —
          #   출발지를 갈아타도 그대로 남아 이어서 연결할 수 있다.
          'stock': {}}

    class _Host(object):
        """`asset_pick` 이 요구하는 표면 여섯만 채운 껍데기(실측 기준)."""
        db_path = None
        lang = 'KO'

        def __init__(self, master):
            self.master = master

        @property
        def kind(self):
            return st['kind']

        @property
        def asset_id(self):
            return st['id']

        def set_anchor(self, k, i):
            _go(k, i)

    hobj = _Host(host.winfo_toplevel())
    hobj.db_path, hobj.lang = db_path, lang

    def _go(k, i):
        k, i = str(k).upper(), int(i)
        if (k, i) == (st['kind'], st['id']):
            return
        st['kind'], st['id'] = k, i
        try:
            with appdb.connect(db_path) as c:
                asset_pick.push_recent(c, k, i)
        except Exception:
            pass
        _draw()

    def _draw():
        for w in body.winfo_children():
            w.destroy()
        st['api'] = build_workbench(body, db_path, st['kind'], st['id'],
                                    anchor_bar=False, on_anchor=_go,
                                    sash_state=st['sash'],
                                    stock_state=st['stock'], **kw)
        _draw_bar()
        try:                       # 띠도 함께 — 몸통만 칠하면 띠가 흰 채 남는다
            import ui_theme
            ui_theme.paint(outer)
        except Exception:
            pass

    def _draw_bar():
        for w in bar.winfo_children():
            w.destroy()
        # ── 첫 줄 — 지나온 출발지 (누르면 그것이 출발지) ──
        r1 = tk.Frame(bar, bg=_bg)
        r1.pack(fill='x', padx=6, pady=(3, 0))
        st['redraw'] = asset_pick.build_trail(r1, hobj)
        # ── 둘째 줄 — **지금 출발지를 큰 글자로** (2026-09-22 · 1.txt 7-2)
        #   사용자 지시 「"지금 연결된 것" 라벨 아래 출발지 표시는 **글자가
        #   너무 작다**. 매우 긴 텍스트도 있는데 표시하기 불가능하다.
        #   "지나온 출발지" 아래에 **큰 글자(14p 이상)로 좌우로 길게** 배치할 것
        #   (사용자화면과 일치할 것)」.
        #   ★ 사용자 화면(`my_edit._head_lbl`)과 **같은 규격**이다 — 14pt bold ·
        #     왼쪽 정렬 · 줄 전체를 쓴다. 두 화면이 달라 보이면 안 된다.
        #   ⚠ **미리 자르지 않는다** — 칸을 실제로 재서 넘칠 때만 줄인다.
        r2 = tk.Frame(bar, bg=_bg)
        r2.pack(fill='x', padx=6, pady=(1, 3))
        tk.Label(r2, text=_t('LP_OWNER', '출발지'), bg=_bg,
                 font=('', 9, 'bold')).pack(side='left', padx=(0, 6))
        _own = tk.Label(r2, text='', bg=_bg, anchor='w', justify='left',
                        font=('', 14, 'bold'))
        _own.pack(side='left', fill='x', expand=True)
        st['own_lbl'] = _own
        _fit_own()

    def _fit_own():
        """출발지 이름을 칸에 맞춰 적는다 — **넘치면 그때만** 줄인다."""
        lbl = st.get('own_lbl')
        if lbl is None or not lbl.winfo_exists():
            return
        try:
            full = (st['api'] or {}).get('own_label', '') or ''
        except Exception:
            full = ''
        lbl.config(text=full)

        def _shrink(*_a):
            try:
                if not lbl.winfo_exists() or not full:
                    return
                room = lbl.winfo_width()
                if room <= 1:
                    lbl.after(80, _shrink)
                    return
                import tkinter.font as tkfont
                f = tkfont.Font(font=lbl.cget('font'))
                if f.measure(full) <= room:
                    if lbl.cget('text') != full:
                        lbl.config(text=full)
                    return
                lo, hi = 1, len(full)
                while lo < hi:
                    mid = (lo + hi + 1) // 2
                    if f.measure(full[:mid] + '…') <= room:
                        lo = mid
                    else:
                        hi = mid - 1
                cut = full[:lo] + '…'
                if lbl.cget('text') != cut:
                    lbl.config(text=cut)
            except Exception:
                pass
        lbl.after(40, _shrink)
        lbl.bind('<Configure>', _shrink, add='+')
        # ⚠⚠ **「바꾸기」 줄을 걷었다** (2026-08-29 사용자 되물음 —
        #   「재고창고에서 자산 하나 클릭해서 출발지로 지정하는 것과 상단
        #     버튼 중에서 자산 하나를 클릭하는 것과 **차이가 무엇인가?**」).
        #   차이가 없었다 — 둘 다 「아무 자산이나 찾아 출발지로」였고, 검색
        #   화면만 두 벌이었다. ⇒ **③ 재고창고 하나로 모은다.**
        #     · 재고 목록에서 고르고 [↷ 출발지로 지정]
        #     · 구절은 위 [찾기] 로 담고 같은 단추
        #   띠는 이제 **지나온 자리로 돌아가는 일만** 한다.

    try:                                   # 처음 잡은 것도 기록에 남긴다
        with appdb.connect(db_path) as c:
            asset_pick.push_recent(c, st['kind'], st['id'])
    except Exception:
        pass
    _draw()

    class _Api(dict):
        def __init__(self):
            dict.__init__(self)
            self['frame'] = outer
            self['win'] = host.winfo_toplevel()

        def __getitem__(self, k):
            if k == 'refresh':
                return lambda: (st['api'] or {}).get('refresh', lambda: None)()
            if k == 'own_label':
                return (st['api'] or {}).get('own_label', '')
            return dict.__getitem__(self, k)

        def set_owner(self, kind2, id2):
            """호스트가 다른 것을 골랐다 — **띠는 안 지운다.** 한 칸 더 쌓는다."""
            _go(kind2, id2)
    return _Api()


def _ask_move(win, name, hits, here):
    """다층 등록을 막고 **범위를 고치는 길**을 낸다 (2026-08-30 사용자 확정).

    돌려주는 값 — `True` 면 **기존 연결을 걷고 여기로 옮긴다**, `False` 면 취소.
    ⚠ 「그래도 둘 다」는 **일부러 없다** — 사용자 확정 「중복이므로 금지하자」.
      다만 「이전에 등록된 범위가 잘못일 수는 있다」는 것이 이 상자의 요점이라
      **옮기는 길**을 준다.
    """
    import tkinter as tk
    _nl = chr(10)
    olds = ', '.join(lb or ('#%s' % oi) for _ok, oi, lb in hits)
    body = _t('LP_MOVE_ASK',
              '「{name}」 은(는) 이미 {old} 에 걸려 있습니다.' + _nl
              + '한 자료는 **한 곳에만** 겁니다 — 구절을 열면 단락·장·책의'
              + _nl + '연결까지 함께 보이므로, 여기에 또 걸면 같은 것이 두 번'
              + ' 나옵니다.' + _nl * 2
              + '등록 범위를 {new} 로 고칠까요?').format(
        name=str(name)[:40], old=olds, new=here or '여기')
    pop = tk.Toplevel(win)
    pop.title(_t('LP_MOVE_TITLE', '연결 범위 수정'))
    pop.transient(win)
    res = {'v': False}
    tk.Label(pop, text=body, justify='left', anchor='w',
             wraplength=460).pack(padx=16, pady=(14, 10), fill='x')
    bar = tk.Frame(pop)
    bar.pack(fill='x', padx=16, pady=(0, 14))

    def _go():
        res['v'] = True
        pop.destroy()
    tk.Button(bar, text=_t('LP_MOVE_OK', '범위를 여기로 수정하기'), bd=1,
              padx=10, pady=3, cursor='hand2', command=_go).pack(side='left')
    tk.Button(bar, text=_t('COMMON_CANCEL', '취소'), bd=1, padx=10, pady=3,
              cursor='hand2', command=pop.destroy).pack(side='right')
    try:
        import ui_theme
        ui_theme.adopt(pop)
    except Exception:
        pass
    pop.grab_set()
    win.wait_window(pop)
    return res['v']


def ask_via(win, x, n_sel=1):
    """공개 이름 — P2 링크 화면도 **같은 상자**를 쓴다(2026-08-30)."""
    return _ask_via(win, x, n_sel)


def _ask_via(win, x, n_sel=1):
    """층이 다른 연결을 뗄 때 — **이 절만 / 그 층 전체 / 취소** (2026-08-30).

    돌려주는 값: `'HERE'` · `'ALL'` · `None`(취소).
    ⚠ **무엇이 함께 사라지는지 숫자로 적는다** — 단락은 평균 10.2절, 최대
      176절이고 도서 편(강해)은 장 전체를 덮기도 한다. 「숨기기」 한 마디로는
      그 범위가 안 읽힌다.
    """
    import tkinter as tk
    # ★★ **모호한 말을 안 쓴다** (2026-08-30 사용자 지시 「"이 층 전체에서…
    #   숨기기" **층? 모호하다.** 연결된 "단락/장/책" 이라고 **명시**하라」).
    #   ⇒ 그 연결이 실제로 걸린 것의 이름을 그대로 쓴다.
    _peri = (x.get('via') == VIA_PERI)
    lvl = _t('LP_N_PERI', '단락') if _peri else _t('LP_N_WIDE', '책·장')
    all_txt = _t('LP_VIA_ALL', '연결된 {what} 전체에서 숨기기').format(what=lvl)
    _nl = chr(10)
    body = _t('LP_VIA_ASK',
              '「{name}」 은(는) 이 절이 아니라' + _nl
              + '{lvl} {span} ({n}절) 에 걸려 있습니다.' + _nl * 2
              + '어디에서 숨길까요?').format(
        name=(x.get('label') or '')[:40], lvl=lvl,
        span=x.get('via_label') or '', n=x.get('via_n') or 0)
    if n_sel > 1:
        body += _nl * 2 + _t('LP_VIA_N', '선택한 {n}개에 모두 적용됩니다.').format(
            n=n_sel)
    pop = tk.Toplevel(win)
    pop.title(_t('LP_DROP', '이 연결만 숨기기'))
    pop.transient(win)
    res = {'v': None}
    tk.Label(pop, text=body, justify='left', anchor='w',
             wraplength=420).pack(padx=16, pady=(14, 10), fill='x')
    bar = tk.Frame(pop)
    bar.pack(fill='x', padx=16, pady=(0, 14))

    def _go(v):
        res['v'] = v
        pop.destroy()
    tk.Button(bar, text=_t('LP_VIA_HERE', '이 구절에서만 숨기기'), bd=1,
              padx=10, pady=3, cursor='hand2',
              command=lambda: _go('HERE')).pack(side='left')
    tk.Button(bar, text=all_txt, bd=1,
              padx=10, pady=3, cursor='hand2',
              command=lambda: _go('ALL')).pack(side='left', padx=(6, 0))
    tk.Button(bar, text=_t('COMMON_CANCEL', '취소'), bd=1, padx=10, pady=3,
              cursor='hand2', command=pop.destroy).pack(side='right')
    try:
        import ui_theme
        ui_theme.adopt(pop)
    except Exception:
        pass
    pop.grab_set()
    win.wait_window(pop)
    return res['v']


def build_workbench(host, db_path, owner_kind, owner_id, scope='USER',
                    lang_getter=None, on_saved=None, on_open=None,
                    close_cb=None, on_select_row=None,
                    anchor_bar=False, on_anchor=None, sash_state=None,
                    stock_state=None,
                    pick_kind=None, pick_label=None, auto_create=False,
                    focus_link=None):
    """★★★ **연결 작업대 — 심을 수 있는 본체** (2026-08-27 사용자 확정 —
    「**진정한 연결팝업을 연결탭 내부에 집어넣고** 사용자 화면과도 통합하는
    것이 제대로 된 방향」).

    같은 본체가 세 자리에 심긴다:
      ① `open_picker` — 창(Toplevel)에 담은 껍데기(기존 호출부 무수정)
      ② `panel_std.link_tab` — 모든 관리 화면의 연결 탭 안
      ③ (C 단계) 사용자 화면 — `scope='USER'` + 오버레이
    ⇒ 탭에서 보던 것과 팝업에서 보던 것이 **글자 하나까지 같다.**
    ⚠ 두 벌을 만들지 않는다 — 탭용을 따로 지으면 팝업의 취지가 축소된다
      (사용자가 정확히 그 위험을 짚었다).

    돌려주는 것: {'frame', 'refresh', 'win', 'own_label'}.
    `close_cb` — 창에 담겼을 때만(겹클릭 열기가 창을 닫고 이동). 탭에서는 None.
    `on_select_row` — 오른쪽 현황에서 줄을 고를 때 (row dict) — 구절 탭의
      정밀(유형·설명문) 연동이 쓴다.
    """
    import tkinter as tk
    from tkinter import ttk, messagebox

    # ★★★ **출발지 띠** (2026-08-29 · 항목 5) — 띠를 쓰는 화면이면 껍데기가
    #   띠를 얹고 몸통은 그 아래에 다시 이 함수를 부른다(`anchor_bar=False`).
    #   ⚠ My Edit 은 **자기 띠가 이미 있다** — 거기서는 `anchor_bar=False` 로
    #     두고 `on_anchor` 만 넘긴다(두 줄이 되면 무엇이 기준인지 안 갈린다).
    if anchor_bar:
        return _with_anchor_bar(
            host, db_path, owner_kind, owner_id, scope=scope,
            lang_getter=lang_getter, on_saved=on_saved, on_open=on_open,
            close_cb=close_cb, on_select_row=on_select_row,
            pick_kind=pick_kind, pick_label=pick_label,
            auto_create=auto_create)

    lang = (lang_getter() if callable(lang_getter) else 'KO') or 'KO'
    owner_kind = str(owner_kind).upper()
    if not owner_id:
        messagebox.showinfo(_t('LP_TITLE', '연결하기'),
                            _t('LP_NEED_TARGET', '먼저 목록에서 대상을 선택하세요.'),
                            parent=host.winfo_toplevel())
        return None
    owner_id = int(owner_id)

    # ⚠ **연결을 창 수명 동안 붙들지 않는다** — 붙들면 창이 닫힌 뒤에도 단추가
    #   그 연결을 만져 `Cannot operate on a closed database` 로 죽는다(실측).
    #   앱 관례대로 **할 때마다 짧게 열고 닫는다.**
    with appdb.connect(db_path) as c0:
        init_schema(c0)
        # ⚠ **없는 자산을 기준으로 열지 않는다** — 열리면 거기에 이어 붙는다.
        if not exists(c0, owner_kind, owner_id):
            messagebox.showwarning(
                _t('LP_TITLE', '연결하기'),
                '이 자산을 찾지 못했습니다: %s #%s' % (kind_name(owner_kind),
                                                owner_id),
                parent=host.winfo_toplevel())
            return None
        own_label = label_of(c0, owner_kind, owner_id, None, lang)
    # ⚠ `win` 은 이제 **부모 창의 별칭**이다(팝업이면 그 Toplevel, 탭이면
    #   패널의 창) — messagebox·태그 고르기 창의 부모로만 쓴다.
    win = host.winfo_toplevel()
    own_branch = KIND_BRANCH.get(owner_kind)

    # ── 좌우 두 칸 ────────────────────────────────────────────────────────
    # 3분할 + [연결] 틈 (0.연결팝업.txt) — 좌: 고르기 · 중: 확인 · 우: 결과
    outer = tk.Frame(host)
    outer.pack(fill='both', expand=True, padx=8, pady=8)
    outer.rowconfigure(0, weight=1)
    # ★★★ **대칭 배치** (2026-08-27 사용자 확정 — 「왼쪽에 현재 연결된 것,
    #   오른쪽에 연결대상자산 재고목록, 가운데에서 재고의 상세내용 확인」 ·
    #   「시작점과 재고창고의 분류/버튼은 구분되지만 **모양은 사실상 동일**」).
    #   시작점의 현재 연결(좌) = 연결 후 결과 화면과 **같은 화면**이다 —
    #   [⇦연결] 을 누르면 재고의 것이 왼쪽에 나타나는 것이 곧 저장이다.
    # ★ 세 기둥은 **사시로 리사이즈**된다 (2026-08-27 사용자 — 「3개 화면이
    #   리사이즈 가능하도록. 화면 내부에서도 리사이즈가 전혀 안된다」).
    #   grid 고정폭을 Panedwindow 로 바꿨다 — [⇦ 연결] 단추는 가운데 기둥의
    #   왼쪽 가장자리에 산다(제 기둥을 주면 사시가 하나 늘어 손만 간다).
    pw = ttk.Panedwindow(outer, orient='horizontal')
    pw.pack(fill='both', expand=True)
    right = tk.Frame(pw)                                 # 현황(시작점)
    pw.add(right, weight=2)
    _midwrap = tk.Frame(pw)                              # [⇦연결] + 확인
    pw.add(_midwrap, weight=3)
    # ★★★ **잇는 단추와 떼는 단추를 한자리에** (2026-08-30 사용자 지시 0.txt
    #   1-3 「왼쪽 맨 아래에 있는 연결 숨기기 버튼위치를 "⇦연결하기" 버튼 아래에
    #   배치하라. "⇨ 연결숨기기"」).
    #   ★ 화살표가 서로 **반대를 가리켜** 짝이 눈에 보인다 — ⇦ 는 재고에서
    #     현황으로 들이고, ⇨ 는 현황에서 뺀다.
    #   ⚠ **가로 글자로 쓴다**(56 → 118px). 세로 글자(`⇦\n연\n결`)로 두면
    #     떼는 단추의 **상태 이름**(이 연결만 숨기기 / 이 연결 되살리기 /
    #     이 연결 지우기)이 잘린다 — 그 단추가 「무엇을 하는지 이름으로 말하는」
    #     유일한 장치라 잘리면 값이 사라진다.
    # ★★★ **가운데 단추 칸(118px)을 걷었다** (2026-09-22 사용자 지시 —
    #   「두 버튼이 **두 화면 사이에 배치**되어 있다. 이 공간을 줄여야 목록
    #   화면이 커진다. 두 버튼을 **"(2)내용확인" 패널의 상단으로 이동**하라」).
    #   ⚠ 그전에는 세로 118px 를 통째로 먹고 가운데에 단추 둘만 있었다
    #     (`gapbox.place(relx=.5, rely=.5)`). 그 폭이 사라지면 ①·②·③ 이 함께
    #     넓어진다.
    #   ★ **② 라벨과 같은 줄**에 놓는다 — 새 줄을 만들면 가로로 번 것을
    #     세로로 도로 잃는다.
    #   ⚠ `gap_a`·`gap_b` **이름은 그대로 둔다** — 저 아래에서 `con_btn`·
    #     `_drop_btn` 이 그 이름에 담긴다. 이름을 바꾸면 두 자리를 더 고친다.
    mid = tk.Frame(_midwrap)                             # 확인
    mid.pack(side='left', fill='both', expand=True, padx=(4, 4))
    _midtop = tk.Frame(mid)
    _midtop.pack(fill='x')
    # ⚠ `side='right'` 는 **먼저 담은 것이 가장 오른쪽**이다 — 짝(⇦ ⇨)이
    #   왼쪽부터 읽히도록 ⇨ 를 먼저 담는다.
    gap_b = tk.Frame(_midtop)         # ⇨ 이 연결만 숨기기
    gap_b.pack(side='right')
    gap_a = tk.Frame(_midtop)         # ⇦ 연결하기   (아래 con_btn 이 채운다)
    gap_a.pack(side='right', padx=(0, 6))
    left = tk.Frame(pw)                                  # 재고창고
    pw.add(left, weight=3)
    # ★★★ **사시 자리를 폭이 잡힌 뒤에 놓는다** (2026-08-29 사용자 신고
    #   「출발지 구절을 바꾸면 3단 화면 중 **가운데 화면만 보인다**」).
    #   ⚠⚠ 그전에는 `after(120)` **한 번**이었다. 출발지를 바꾸면 몸통을
    #     통째로 다시 짓는데, 그 120ms 시점에 Panedwindow 폭이 아직 **1** 이면
    #     `sashpos` 가 1 로 잘려 **왼쪽 두 기둥이 사라진다.**
    #     실측 — 두 번째 갈아탈 때 `[1484, 1, 1, 1474]`.
    #   ⇒ **폭이 잡힐 때까지 기다렸다가** 놓고, 사용자가 옮긴 자리는
    #     `sash_state` 에 **비율로** 적어 두어 다시 지어도 그대로 온다.
    def _apply_sash(tries=0):
        try:
            w = pw.winfo_width()
        except Exception:
            return
        if w <= 10:
            if tries < 40:                     # 최대 ~2초까지 기다린다
                outer.after(50, lambda: _apply_sash(tries + 1))
            return
        # ★★ **재고창고를 가장 넓게** (2026-09-22 · 1.txt 1-2 사용자
        #   「재고창고 목록의 화면이 **너무 좁다. 크게 늘려야 한다**」).
        #   ⚠ 그전 기본 0.22/0.62 는 ① 22% · ② 40% · **③ 38%** 라
        #     **가운데(내용 확인)가 가장 넓었다** — 실측 1484px 창에서
        #     326 / 589 / 559. 고르는 자리가 보는 자리보다 좁았다.
        #   ⇒ 0.20/0.52 = ① 20% · ② 32% · **③ 48%**.
        #   ★ 사용자가 사시를 옮기면 `sash_state` 가 기억하므로 이것은
        #     **처음 열 때의 자리**일 뿐이다.
        fr = sash_state if isinstance(sash_state, dict) else {}
        a = int(w * fr.get('a', 0.20))
        b = int(w * fr.get('b', 0.52))
        a = max(220, min(a, w - 480))
        b = max(a + 260, min(b, w - 220))
        try:
            pw.sashpos(0, a)
            pw.sashpos(1, b)
        except Exception:
            pass

    def _save_sash(_e=None):
        if not isinstance(sash_state, dict):
            return
        try:
            w = pw.winfo_width()
            if w > 10:
                sash_state['a'] = pw.sashpos(0) / float(w)
                sash_state['b'] = pw.sashpos(1) / float(w)
        except Exception:
            pass
    pw.bind('<ButtonRelease-1>', _save_sash, add='+')
    outer.after(60, _apply_sash)

    # ── 오른쪽 — 지금 연결된 것(결과) ─────────────────────────────────────
    # ★ 세 기둥에 **제목 줄** (2026-08-27 사용자 — 「도대체 UI가 어떻게
    #   하라는 것인지 이해안된다」). 처음 보는 사람이 배치를 읽게:
    #   ① 지금 연결된 것 → [⇦ 연결] ← ③ 재고에서 고르고 · ② 가운데서 확인.
    tk.Label(right, text=_t('LP_H_LINKED', '① 지금 연결된 것'),
             anchor='w', font=('', 10, 'bold')).pack(fill='x')
    head = tk.Label(right, text='', anchor='w')
    head.pack(fill='x')
    # ★ 현황 갈래 단추 (2026-08-27 사용자 — 「시작점과 재고창고의 분류/버튼은
    #   구분되지만 모양은 사실상 **동일**」). 재고의 연결대상 단추와 같은 문법 —
    #   실제로 걸린 종류만, 개수와 함께, 두 줄로 접힌다.
    fbar = tk.Frame(right)
    fbar.pack(fill='x', pady=(0, 2))
    _flt = {'kind': None, 'btns': {}}
    # ⚠ 옛 `rbtn`(① 아래 단추 줄)을 걷었다 — 그 안에 있던 [연결 숨기기] 가
    #   가운데 gap 칸으로 갔다(2026-08-30). 빈 줄을 남기면 높이만 먹는다.
    tvf = tk.Frame(right)
    tvf.pack(fill='both', expand=True, pady=(2, 3))
    # ★ 목록 트리는 **표준 규격 한 함수**로 (§36 · theme_font.list_style) —
    #   여기서 `ttk.Style().configure(font=…, rowheight=…)` 를 직접 쓰면
    #   그 순간 통합 폰트 밖으로 나간다.
    _tv_style(db_path, 'LinkPick.Treeview')
    tv = ttk.Treeview(tvf, columns=('t',), show='tree headings', height=6,
                      style='LinkPick.Treeview')
    tv.heading('#0', text=_t('LP_COL_KIND', '종류'))
    tv.heading('t', text=_t('COMMON_NAME', '이름'))
    tv.column('#0', width=96, anchor='w', stretch=False)
    tv.column('t', width=250, anchor='w')
    sb = ttk.Scrollbar(tvf, command=tv.yview)
    tv.configure(yscrollcommand=sb.set)
    sb.pack(side='right', fill='y')
    tv.pack(side='left', fill='both', expand=True)
    rows = {}

    _cache = {'got': [], 'anchors': []}

    def reload_list():
        # ★★ 연결상태 표시 (2026-08-27) — 갈래 요약·해제 회색·앵커.
        #   받기와 그리기를 갈랐다: 갈래 단추는 **그리기만** 다시 한다.
        with appdb.connect(db_path) as c:
            got = links_of(c, owner_kind, owner_id, lang, scope=scope,
                           include_hidden=cap(scope, 'show_hidden'))
            anchors = []
            if owner_kind == 'VERSE':
                for code_, lvl in c.execute(
                        "SELECT s.commentary_code, e.entry_level "
                        "  FROM sys_commentary_entry e "
                        "  JOIN sys_commentary_source s "
                        "    ON s.commentary_id=e.commentary_id "
                        " WHERE COALESCE(e.record_status,'LIVE')='LIVE' "
                        # ⚠⚠ 구간 판정은 **`verse_range` 한 문**(§verse_range)
                        "   AND (e.start_vid=? OR ("
                        + _vr.covers_sql('e', 'start_vid', 'end_vid') + "))",
                        [owner_id] + _vr.covers_args(owner_id)):
                    anchors.append(('주석', '%s (%s) — 주석 관리에서'
                                    % (code_, lvl)))
                for _pid, pc in c.execute(
                        "SELECT pericope_id, peri_code FROM sys_pericope_asset p"
                        " WHERE p.peri_type='BODY'"
                        "   AND COALESCE(p.record_status,'LIVE')='LIVE'"
                        "   AND "
                        + _vr.covers_sql('p', 'start_vid', 'end_vid'),
                        _vr.covers_args(owner_id)):
                    anchors.append(('단락', '%s — 소속 단락' % pc))
            # ★★ **닻도 함께** (2026-08-31 사용자 「모든 자산이 닻, 연결 모두
            #   한 눈으로 보면서 관리해야 한다」). 종류를 안 가리는 한 문이다.
            anchors += anchors_of(c, owner_kind, owner_id, lang)
            # ⚠⚠ **연결로도 있으면 닻 줄은 안 그린다**(2026-08-31 실측으로
            #   잡았다 — 자기 닻 구절에 그 노트를 이으면 **같은 이름이 두 줄**
            #   이 됐다. 137차가 묻기는 하되 허용하므로 실제로 날 수 있다).
            #   ★ **연결이 이긴다** — 연결은 `⇨` 로 뗄 수 있고 닻은 못 뗀다.
            #     둘 다 그리면 같은 이름 두 줄 중 하나만 떼어져 「왜 안 없어
            #     지나」가 된다.
            _have = set()
            for _r in got:
                try:
                    _have.add((_r.get('kind'), int(_r.get('id'))))
                except Exception:
                    pass
            anchors = [a for a in anchors
                       if len(a) < 3 or a[2] is None or a[2] not in _have]
        _cache['got'], _cache['anchors'] = got, anchors
        _render_list()

    def _set_flt(kind):
        _flt['kind'] = None if _flt['kind'] == kind else kind
        _render_list()

    def _render_list():
        got, anchors = _cache['got'], _cache['anchors']
        tv.delete(*tv.get_children())
        rows.clear()
        # ★ 색은 역할로 — 그릴 때마다 재적용(retag, §36-5b). 굳히면 검정
        #   테마에서 이 두 줄만 밝은 색으로 남는다.
        try:
            import ui_theme as _ut
            _hid_c = _ut.C('danger') or '#C0392B'
            _anc_c = _ut.C('fg_dim') or '#95A5A6'
        except Exception:
            _hid_c, _anc_c = '#C0392B', '#95A5A6'
        tv.tag_configure('lp_hidden', foreground=_hid_c)
        tv.tag_configure('lp_anchor', foreground=_anc_c)
        try:
            tv.tag_configure('lp_group', foreground=_ut.C('fg_title')
                             or '#1A5276')
        except Exception:
            pass
        # ★ **③ 과 같은 축(갈래)으로 묶는다** (2026-08-29 · 항목 3-(c)).
        cnt = {}
        for x in got:
            k = branch_name(x['kind'])
            cnt[k] = cnt.get(k, 0) + (0 if x.get('hidden') else 1)
        # 갈래 단추 — 실제로 걸린 종류만 · 개수 · 재고 단추와 같은 모양
        for w in fbar.winfo_children():
            w.destroy()
        _flt['btns'] = {}
        items = [(None, '전체', sum(cnt.values()))] + \
                [(k, k, v) for k, v in
                 sorted(cnt.items(), key=lambda kv: -kv[1])] + \
                ([('__A__', _t('LP_F_REFROW', '참고'), len(anchors))]
                 if anchors else [])
        # ★ 「참고」 = 연결이 아닌 안내 줄(소속 단락·이 절을 다루는 주석).
        #   ⚠ 옛 이름 「앵커」는 개발 용어라 폐기(2026-08-27 사용자 — 「사용자가
        #     앵커라는 말을 알아듣는다고 생각하는가」).
        # ★ 줄바꿈은 **실제 폭**으로 — 개수로 접으면(옛 _per 방식) 좁은 기둥에서
        #   마지막 단추가 절반 잘린다(2026-08-27 사용자 신고).
        for _i, (fk, nm, n) in enumerate(items):
            b = tk.Button(fbar, text='%s(%d)' % (nm, n), bd=1, padx=6, pady=1,
                          cursor='hand2',
                          relief='sunken' if _flt['kind'] == fk else 'raised',
                          command=lambda k2=fk: _set_flt(k2))
            _flt['btns'][fk] = b

        def _reflow(_e=None):
            try:
                bw = fbar.winfo_width()
                if bw <= 1:
                    fbar.after(60, _reflow)
                    return
                x = row = col = 0
                for b2 in _flt['btns'].values():
                    w2 = b2.winfo_reqwidth() + 2
                    if col and x + w2 > bw:
                        row += 1
                        x = col = 0
                    b2.grid(row=row, column=col, padx=(0, 2), pady=1,
                            sticky='w')
                    x += w2
                    col += 1
            except Exception:
                pass
        _reflow()
        fbar.bind('<Configure>', _reflow)
        want = _flt['kind']
        shown = 0
        # ★★★ **3단 묶음 — 연결이 걸린 층으로 가른다** (2026-08-30 사용자 확정
        #   「**3단묶음** 1)구절과 연결 2)단락과 연결 3)책/장과 연결.
        #   다만, **분류에 해당하는 항목이 없다면 분류를 표시하지 마라**」).
        #   ★ 칸을 안 늘린다 — ① 목록은 이미 트리라 묶음을 쓸 수 있고,
        #     재고창고(③)가 같은 2단 문법이다.
        #   ★ **범위를 묶음 머리에 한 번만** 적는다(`단락과 연결 · 창1:1~2 (2절)`)
        #     — 그러면 숨길 때 무엇이 함께 사라지는지 **누르기 전에 읽고 있다.**
        #   ⚠ 빈 묶음은 아예 안 만든다(사용자 지시).
        #   ⚠ 구절 아닌 출발지에서는 층이 하나뿐이라 **묶음을 안 만든다** —
        #     한 묶음짜리 트리는 클릭이 한 번 더 드는 군더더기다.
        _GH = ((VIA_VERSE, 'LP_G_VERSE', '구절과 연결'),
               (VIA_PERI, 'LP_G_PERI', '단락과 연결'),
               (VIA_WIDE, 'LP_G_WIDE', '책·장과 연결'))
        _keep = []
        for i, x in enumerate(got):
            knm = branch_name(x['kind'])        # 거르기도 갈래 축
            if want == '__A__':
                continue
            if want not in (None, knm):
                continue
            _keep.append((i, x))
        _grouped = (owner_kind == 'VERSE'
                    and any(x.get('via') for _i, x in _keep))
        _gnode = {}
        if _grouped:
            for via, ik, dflt in _GH:
                mine = [(i, x) for i, x in _keep
                        if (x.get('via') or VIA_VERSE) == via]
                if not mine:
                    continue          # 빈 묶음은 안 만든다
                head_t = _t(ik, dflt)
                sp = next((x.get('via_label') for _i, x in mine
                           if x.get('via_label')), '')
                n = next((x.get('via_n') for _i, x in mine
                          if x.get('via_n')), 0)
                if sp:
                    head_t += ' · %s' % sp
                    if n > 1:
                        head_t += _t('LP_G_NV', ' (%d절)') % n
                _gnode[via] = tv.insert(
                    '', 'end', text='%s (%d)' % (head_t, len(mine)),
                    open=True, values=('',), tags=('lp_group',))
        for i, x in _keep:
            iid = 'r%d' % i
            # ⚠ 줄의 「종류」 칸은 **낱낱의 이름**이다(갈래가 아니다) —
            #   같은 갈래 안에서 도서와 도서 편을 갈라 보여야 한다.
            nm = kind_name(x['kind'])
            tags = ()
            if x.get('hidden'):
                nm = '%s (해제)' % nm
                tags = ('lp_hidden',)
            elif x['src'] == 'TAG':
                nm = '#' + nm
            elif x['src'] == 'SYS':
                nm = _t('LP_SYS_MARK', '기본') + ' ' + nm
            tv.insert(_gnode.get(x.get('via') or VIA_VERSE, ''), 'end',
                      iid=iid, text=nm, values=(x['label'],), tags=tags)
            rows[iid] = x
            shown += 1
        if want in (None, '__A__') and anchors:
            # ★ 「참고」도 **한 묶음으로** (2026-08-30) — 3단 묶음을 만든 뒤
            #   이 줄들이 묶음 밖에 흩어져 목록 끝이 어수선했다(실측 7줄).
            #   연결이 아니므로 **접어 둔다**(`open=False`).
            _an = tv.insert('', 'end',
                            text='%s (%d)' % (_t('LP_F_REFROW', '참고'),
                                              len(anchors)),
                            open=False, values=('',), tags=('lp_anchor',))
            for j, (knm, lb, *_r) in enumerate(anchors):
                tv.insert(_an, 'end', iid='a%d' % j, text=knm, values=(lb,),
                          tags=('lp_anchor',))
        # ⚠ **출발지 이름을 여기 안 적는다** (2026-09-22 · 1.txt 7-2) —
        #   띠 둘째 줄이 14pt 로 크게 보인다(`_with_anchor_bar._fit_own`).
        #   두 자리에 두면 작은 쪽이 긴 이름을 잘라 먹는다(사용자 지적).
        #   ★ 띠가 없는 자리(My Edit)는 **제 띠**(`_head_lbl`)가 이미 적는다 —
        #     `build_workbench` 를 부르는 곳은 그 둘뿐이다(실측).
        head.config(text='%s (%d)'
                    % (_t('LP_LINKED', '연결된 것'), sum(cnt.values())))

    def changed():
        """넣거나 뺀 **직후**. ★ 뒤 화면도 함께 되그린다 — 창을 닫기 전에
        「정말 걸렸나」를 그 자리에서 볼 수 있어야 한다(사용자 지시)."""
        reload_list()
        if callable(on_saved):
            try:
                on_saved()
            except Exception as e:
                print('[link_picker on_saved] %s' % e)

    def drop():
        sel = tv.selection()
        x = rows.get(sel[0]) if sel else None
        if not x:
            if sel and str(sel[0]).startswith('a'):
                # ★★ **닻은 못 뗀다 — 그 까닭을 말한다** (2026-08-31).
                #   그전 문구는 **주석 전용**이라 노트·연구자료의 닻을 눌렀을 때
                #   「주석 관리에서 고치라」는 엉뚱한 말이 나왔다.
                #   ⚠ 끊으면 그 자산이 **어디에도 안 붙은 미아**가 된다 —
                #     그래서 못 떼는 것이지 기능이 빠진 것이 아니다.
                messagebox.showinfo(
                    _t('LP_TITLE', '연결하기'),
                    _t('LP_A_WHY',
                       '이 줄은 연결이 아니라 **붙어 있는 자리(닻)** 입니다.'
                       + chr(10) + '끊으면 그 자료가 어느 화면에도 안 나오므로 '
                       'here 에서는 뗄 수 없습니다.'
                       + chr(10) + '자리를 옮기려면 그 자료를 만든 화면에서 '
                       '고칩니다.'),
                    parent=win)
            return
        if x.get('hidden'):
            if not cap(scope, 'revive'):
                # ★★ **관리자는 물리삭제다** (2026-08-27 사용자 — 「빨간 해제를
                #   클릭하고 연결빼기 했더니 정상연결로 표시된다. 철저하게
                #   사용자모드라는 증거」). 해제(HIDE) 행은 관리자 세계에 있을
                #   것이 아니다 — 되살리는 게 아니라 **지운다.**
                if messagebox.askyesno(
                        _t('LP_DROP', '연결 숨기기'),
                        '해제된 채 남은 연결입니다.' + chr(10) +
                        '영구히 지웁니다(관리자 물리삭제 — 복구는 감사 로그).',
                        parent=win):
                    with appdb.connect(db_path) as c:
                        remove(c, (owner_kind, owner_id),
                               (x['kind'], x['id'], x['end']),
                               scope=scope, rel=x.get('rel'))
                    changed()
                return
            # 사용자 — 재연결(HIDE 행을 add 가 되살린다)
            with appdb.connect(db_path) as c:
                add(c, (owner_kind, owner_id), (x['kind'], x['id'], x['end']),
                    scope=scope, rel=x.get('rel'))
            changed()
            return
        if is_physical(scope):
            # ★ 물리삭제 — 뜻을 묻는다(지우면 복구는 감사 로그 §10-1)
            if not messagebox.askyesno(
                    _t('LP_DROP', '연결 숨기기'),
                    '「%s」 연결을 영구히 지웁니다(관리자 물리삭제).'
                    % (x.get('label') or ''), parent=win):
                return
        if x['src'] == 'SYS' and not is_physical(scope):
            # ★★★ **배포 연결도 「내 화면에서」 가릴 수 있다** (2026-08-30) —
            #   덮개 모델이 그것이다. 배포 DB 는 한 글자도 안 바뀐다.
            #   ⚠⚠ 그전에는 「관리자 화면 몫」이라 알리고 **아무것도 못 했다.**
            #     그런데 링크(영상)는 5,661건이 전부 배포 연결이라, 사실상
            #     **가릴 길이 없었다.**
            via = x.get('via') or VIA_VERSE
            if via == VIA_VERSE:
                with appdb.connect(db_path) as c:
                    veto(c, (owner_kind, owner_id),
                         (x['kind'], x['id'], x['end']), rel=x.get('rel'))
                changed()
                return
            # ── 층이 다르다 — **무엇이 함께 사라지는지 묻는다** ──────────
            #   사용자 확정 「단락 전체 숨길 때는 경고(단락 전체와의 연결
            #   숨기기), 구절만 숨길(해당 구절과의 연결만 숨기기) 옵션을
            #   제공하자」. ⚠ 단락은 평균 10.2절 · **최대 176절**이라 범위와
            #   절 수를 반드시 적는다.
            pick = _ask_via(win, x)
            if pick is None:
                return
            with appdb.connect(db_path) as c:
                if pick == 'HERE':
                    # 이 절에서만 — 거부권 행 하나
                    veto(c, ('VERSE', owner_id),
                         (x['kind'], x['id'], x['end']))
                else:
                    # 그 층 전체 — 단락(또는 도서 편)과의 연결을 가린다
                    veto(c, (x['via_kind'], x['via_id']),
                         (x['kind'], x['id'], x['end']), rel=x.get('rel'))
            changed()
            return
        if x['src'] == 'SYS':
            # 관리자 — 배포 표는 여기서 안 지운다(§21-4)
            messagebox.showinfo(
                _t('LP_TITLE', '연결하기'),
                _t('LP_SYS_RO', '기본 자료에 원래 딸린 연결입니다. '
                                '여기서는 뺄 수 없고 관리자 화면에서 고칩니다.'),
                parent=win)
            return
        if x['src'] == 'TAG':
            # ⚠⚠ **scope 를 반드시 넘긴다** (2026-08-27 사용자 신고 「태그는
            #   연결빼기 버튼 눌러도 계속 남아있다」). 안 넘기면 관리자(SYS)
            #   태그를 **개인 표에서 찾고 개인 표에 쓴다** — 배포 표의 연결은
            #   그대로라 화면에 계속 남았다. 오류도 안 났다.
            import tag_picker
            cur = {(s, t) for s, t, _n, _c
                   in tag_picker.tags_of(db_path, owner_kind, owner_id, lang,
                                         scope=scope)}
            if any(p[1] == x['id'] for p in cur):
                tag_picker.save_links(db_path, owner_kind, owner_id,
                                      {p for p in cur if p[1] != x['id']},
                                      scope=scope)
            else:
                # ⚠⚠ **배포 태그는 개인 표에 없어 위 문이 0행이었다**
                #   (2026-08-31 사용자 신고 「#새해·#부르심 … 연결팝업에서
                #   숨기기 안 된다」). 그 태그는 `sys_link_asset` 에 있으므로
                #   빼는 것이 아니라 **덮개로 가린다** — 배포 연결을 가리는
                #   그 문(`veto`)을 그대로 쓴다. 배포 DB 는 한 글자도 안 바뀐다.
                with appdb.connect(db_path) as c:
                    veto(c, ('TAG', x['id']), (owner_kind, owner_id),
                         on=not x.get('hidden'))
        else:
            with appdb.connect(db_path) as c:
                remove(c, (owner_kind, owner_id), (x['kind'], x['id'], x['end']),
                   scope=scope, rel=x.get('rel'))
        changed()

    # ★★★ **단추 이름이 하는 일 그대로여야 한다** (2026-08-30 사용자 —
    #   「넣기/빼기와 같은 단어 절대로 사용하지 말라고 했는데 왜 반복하는가?」).
    #   ⚠⚠ 그런데 이 단추는 **상황마다 하는 일이 다르다**:
    #     · 사용자 · 보통 줄  → 내 화면에서 **숨긴다**(휴지통에서 되살린다)
    #     · 사용자 · 이미 숨긴 줄 → **숨김을 푼다**(다시 잇는다)
    #     · 관리자          → **물리삭제**(복구는 감사 로그 §10-1)
    #   한 이름으로 묶으면 셋 중 둘에서 거짓말이 된다 — 「[내 것 되돌리기]가
    #   물리 삭제인데 되살아납니다라고 알린」 사고와 같은 자리다.
    #   ⇒ **고른 줄에 따라 이름이 따라간다.**
    #   ⚠ **자리는 ① 아래가 아니라 가운데 gap 칸**이다 (2026-08-30) —
    #     [⇦ 연결하기] 바로 아래. 잇기와 연결 해제가 한자리에 있어야 짝으로 읽힌다.
    _drop_btn = tk.Button(gap_b, text='⇨ ' + _t('LP_DROP', '이 연결만 숨기기'),
                          bd=1, padx=6, pady=4, cursor='hand2', command=drop,
                          wraplength=98, justify='center')
    _drop_btn.pack(fill='x')

    def _drop_label(*_a):
        try:
            sel = tv.selection()
            x = rows.get(sel[0]) if sel else None
            if is_physical(scope):
                k, d = 'LP_DROP_DEL', '이 연결 지우기'
            elif x and x.get('hidden'):
                k, d = 'LP_DROP_SHOW', '이 연결 되살리기'
            else:
                k, d = 'LP_DROP', '이 연결만 숨기기'
            _drop_btn.config(text='⇨ ' + _t(k, d))
        except Exception:
            pass
    tv.bind('<<TreeviewSelect>>', _drop_label, add='+')
    _drop_label()


    # ── 열기 — **연결한 이유는 클릭해서 넘어가려는 것이다** (2026-08-24 사용자) ──
    # ⚠⚠ 그전에는 결과 목록에 **바인딩이 하나도 없었다**. 창이 「잇는 도구」로만
    #   만들어지고 「가는 도구」로는 안 만들어져, 눌러도 아무 일이 없었다.
    # ⚠ 이 창은 **모달**(`grab_set`)이라 **먼저 닫아야** 뒤 화면을 만질 수 있다.
    #   그리고 `wait_window` 가 끝난 뒤에 가도록 `after` 로 한 박자 미룬다.
    # ⚠ 겹클릭만 두지 않는다 — 보이지 않는 기능은 없는 기능이다(단추를 함께).
    def go(_e=None):
        sel = tv.selection()
        x = rows.get(sel[0]) if sel else None
        if not x:
            return
        if not callable(on_open):
            messagebox.showinfo(
                _t('LP_TITLE', '연결하기'),
                _t('LP_NO_JUMP', '이 화면에서는 아직 열 수 없습니다.'),
                parent=win)
            return
        k, i = x['kind'], x['id']
        if callable(close_cb):
            close_cb()                 # 창에 담겼을 때만 닫는다 — 탭은 그대로
        try:
            host.after(1, lambda: on_open(k, i))
        except Exception as e:
            print('[link_picker open] %s' % e)

    def _go_or_anchor(_e=None):
        """★★★ **겹클릭 = 출발지 갈아타기** (2026-08-29 사용자 교정 —
        「출발지로 지정하는 버튼이 왜 필요한가? **경로를 클릭하면 그 자체로
        출발지로 지정되는 것 아닌가**」).

        그전에는 겹클릭이 **창을 닫고 그 화면으로 나가** 작업이 끊겼다.
        이제 갈아탈 수 있는 화면에서는 **그 자리에서 기준이 바뀐다** —
        창1:1 에 용어를 잇다가 그 용어로 옮겨 계속 잇는 흐름 그대로다.
        ⚠ 갈아탈 수 없는 화면(호스트가 `on_anchor` 를 안 준 곳)에서는
          종전대로 **연다**. 기능을 잃지 않는다.
        """
        if not callable(on_anchor):
            return go(_e)
        sel = tv.selection()
        x = rows.get(sel[0]) if sel else None
        if x:
            on_anchor(x['kind'], x['id'])

    # ⚠ [열기] 단추는 **후보 쪽으로 옮겼다** (0.연결팝업.txt — 「배치 오류.
    #   **연결하기 전에** 열어보고 나서 문제없을 때 연결해야 한다」).
    #   연결된 것을 여는 길은 겹클릭으로만 남긴다.
    tv.bind('<Double-1>', _go_or_anchor)
    # ★★ **양방향 확인** (2026-08-27 사용자 — 「현황을 클릭해도 확인 화면에서
    #   내용을 표시. 양방향 토글방식으로 — 필수」). 재고를 클릭하면 재고의
    #   내용이, 현황을 클릭하면 그 연결된 자산의 내용이 가운데에 온다 —
    #   마지막에 클릭한 쪽이 이긴다(토글).
    #   ⚠ 확인 칸은 이 아래에서 지어진다 — 갈고리로 뒤에 잇는다.
    _hook = {'preview': None}

    def _preview_status_row(_e=None):
        fn = _hook.get('preview')
        sel = tv.selection()
        if not sel:
            return
        x = rows.get(sel[0])
        if callable(fn) and x:
            fn(x)
            return
        # ★★ **「참고」 줄도 가운데에 말해 준다** (2026-08-29 사용자 신고
        #   「왼쪽에서 주석 클릭하면 가운데 확인 화면에 **아무것도 없다**」).
        #   참고 줄은 연결 표가 아니라 **구절 앵커**로 붙은 것이라 `rows` 에
        #   없었고, 그래서 클릭해도 아무 일이 없었다 — 고장으로 읽힌다.
        if str(sel[0]).startswith('a'):
            j = int(str(sel[0])[1:])
            ancs = _cache.get('anchors') or []
            if 0 <= j < len(ancs):
                knm, lb = ancs[j][0], ancs[j][1]
                fn2 = _hook.get('anchor_info')
                if callable(fn2):
                    fn2(knm, lb)
    tv.bind('<<TreeviewSelect>>', _preview_status_row, add='+')
    if callable(on_select_row):
        # 구절 탭의 정밀(유형·설명문) 연동 — 줄을 고르면 호스트가 이어받는다
        tv.bind('<<TreeviewSelect>>',
                lambda _e: (lambda x: on_select_row(x) if x else None)(
                    rows.get(tv.selection()[0]) if tv.selection() else None),
                add='+')

    # ══ 3분할 (2026-08-27 · 0.연결팝업.txt 1절) ══════════════════════
    #   좌 = 고른다(구절/태그 + 연결대상 버튼·목록)
    #   중 = **확인한다**(선택 구절 본문 / 후보 설명문) — 잇기 전의 확인 단계.
    #     그전 창의 근본 문제가 이것이었다: 더블클릭이 곧 연결이라
    #     「고르기 → 확인 → 연결」의 확인이 없었다.
    #   [연결] = 두 칸 사이 세로 단추 — 연결하는 길은 이 하나뿐이다.
    #   우 = 결과(연결된 것).
    #   ⚠ 흐름 콤보 줄은 없앴다(사용자 — 「중복이다. 네가 연결대상 콤보에
    #     넣어버렸다」). 멤버십 달기(§28-3 chain_code)는 구속사 흐름 관리 몫.

    # ── 지금 고른 후보 — [연결] 이 잇는 대상 ──
    # ★★★ **출발지를 바꿔도 재고창고에서 고른 것은 살아남는다**
    #   (2026-09-22 · 1.txt 1-1 사용자 「재고창고의 항목을 클릭한 후,
    #   출발지 자산들을 이것저것 **더 추가연결**하고 싶다. 그런데 출발지
    #   자산을 클릭하면 **재고창고에서 선택한 항목이 리셋**되어 버린다」).
    #   ⚠ 까닭 = 출발지를 바꾸면 `_with_anchor_bar._draw` 가 몸통을 **통째로
    #     destroy 하고 다시 짓는다.** 그러면 이 dict 도 새로 생겨 비어 있었다.
    #   ⇒ **껍데기가 들고 있는 dict 를 그대로 쓴다** — 사시 자리를
    #     `sash_state` 로 넘기는 것과 **같은 얼개**다(그쪽은 이미 검증됐다).
    #   ⚠⚠ 새 dict 를 만들어 값만 복사하면 안 된다 — `cand.clear()`·`update` 가
    #     클로저 여기저기서 불리므로 **같은 객체**라야 밖에 반영된다.
    cand = (stock_state.setdefault('cand', {})
            if isinstance(stock_state, dict) else {})
    _keep_cand = dict(cand)         # 다 지은 뒤 되살릴 값(set_cand 가 비운다)
    # ★★ **보고 있는 것 ≠ 이을 후보** (2026-08-29). 현황(①)을 클릭하면 후보는
    #   비지만(§버그 수리) 가운데에는 그 자산이 보인다 — [수정]·[숨기기] 는
    #   **보고 있는 것**에 작용해야 한다. 둘을 한 변수로 두면 또 어긋난다.
    view = {}                       # {'kind','id','label'}

    def set_cand(kind, tid, end=None, label=''):
        cand.clear()
        cand.update({'kind': kind, 'id': tid, 'end': end, 'label': label})
        try:
            mid_head.config(text=label or '')
        except Exception:
            pass
        _arm_connect(True)

    def clear_cand(head=''):
        """★★ **후보를 비운다** (2026-08-29 버그 수리).

        ⚠⚠ 그전에는 왼쪽 현황 줄을 클릭하면 가운데 칸만 갈아 끼우고
          `cand` 는 **직전 재고 후보를 그대로 들고 있었다.** 그래서
          「가운데에 B 가 보이는데 [⇦연결]을 누르면 A 가 붙는」 일이 났다.
          오류도 안 났다. ⇒ 확인 칸이 이미 연결된 것을 보이는 동안에는
          **후보를 비우고 단추를 잠근다.**
        """
        cand.clear()
        try:
            mid_head.config(text=head or '')
        except Exception:
            pass
        _arm_connect(False)

    def _arm_connect(on):
        try:
            con_btn.config(state=('normal' if on else 'disabled'))
        except Exception:
            pass                       # 아직 안 지어졌으면 조용히 넘긴다

    # ── 가운데 칸 — 확인 · **한 칸** (2026-08-27 사용자 — 「위 아래 구분된
    #   것을 하나로 통합. 성경 선택하면 구절만, 도서 선택하면 도서만.
    #   그러면 공간이 매우 크고 좋다」). 마지막에 고른 것 하나만 크게 보인다.
    tk.Label(_midtop, text=_t('LP_H_CHECK', '② 내용 확인'),
             anchor='w', font=('', 10, 'bold')).pack(side='left')
    mid_head = tk.Label(mid, text='', anchor='w')
    mid_head.pack(fill='x')
    vs_f = tk.Frame(mid)
    vs_f.pack(fill='both', expand=True, pady=(2, 0))
    mid_tx = tk.Text(vs_f, wrap='word', state='disabled', relief='solid', bd=1,
                     padx=6, pady=4)
    vs_sb = tk.Scrollbar(vs_f, command=mid_tx.yview)
    mid_tx.configure(yscrollcommand=vs_sb.set)
    vs_sb.pack(side='right', fill='y')
    mid_tx.pack(side='left', fill='both', expand=True)
    try:
        import theme_font
        theme_font.register(mid_tx, db_path, 'body')
    except Exception:
        pass

    # ★★★ **손질 단추는 ③ 재고창고로 갔다** (2026-08-30 사용자 지시 —
    #   「**자산 자체를 숨기는 것이라면 재고창고에 배치해야 한다.** 용어도
    #   적절히 수정하라」).
    #   ⚠⚠ 그전에는 ② 가운데 아래였는데, ① 아래의 [연결 숨기기] 와 **한 화면에
    #     「숨기기」가 둘**이라 어느 것이 무엇인지 알 수 없었다. 이제 자리로
    #     갈린다 — **연결은 가운데(⇨), 자산은 재고창고(③)**.
    #   ★ 재고창고는 **자산이 사는 칸**이라 만들기(＋)·고치기(✎)·숨기기(◐)가
    #     한 줄에 모여 뜻이 맞는다.
    #   ⚠ 단추는 `_build_assets` 가 짓고 **여기로 돌려준다** — 다 지어진 뒤라
    #     `_sync_fix_btns` 가 그때까지는 아무 일도 안 하게 담아 둔다.
    _fix = {'e': None, 'h': None}

    _EMPTY_MID = ('(구절은 [찾기] · 자산은 목록을 클릭하면 여기서 확인합니다)')

    # ══ ② **만들기 모드** — 재고에 없으면 그 자리에서 짓는다 ═══════════
    #  ★★★ 사용자 확정 (2026-08-29 · 0.txt 1-4-(4)):
    #    「재고자산에 배치된 **어떤 자산이든** 추가하려면 「자산 종류 & 추가
    #      버튼」이 작동해야 **가운데 확인 화면에서 입력이 가능**해진다.」
    #  ⚠ 확인 칸과 **같은 자리**를 갈아 끼운다(`pack_forget`) — 칸을 하나 더
    #    만들면 폭이 좁아지고, 파괴하면 스크롤·글꼴 등록을 매번 다시 짓는다.
    form_f = tk.Frame(mid)
    _form = {'on': False}

    def _end_create():
        if not _form['on']:
            return
        _form['on'] = False
        form_f.pack_forget()
        for w in form_f.winfo_children():
            w.destroy()
        vs_f.pack(fill='both', expand=True, pady=(2, 0))

    def _set_view(kind, tid, label=''):
        """가운데에 **지금 보이는 자산**. [수정]·[숨기기] 가 여기에 작용한다."""
        view.clear()
        view.update({'kind': str(kind).upper(), 'id': tid, 'label': label})
        _sync_fix_btns()
        # ★ 연결설명문 칸도 함께 따라온다 — 가운데가 바뀌는 자리는 여기 하나다
        #   (밖에 흩으면 어느 경로에서만 안 따라오는 일이 난다).
        try:
            _ld_sync()
        except NameError:
            pass                    # 아직 안 지어졌다(창을 짓는 중)

    def _sync_fix_btns():
        k = view.get('kind')
        for b in (_fix['e'], _fix['h']):
            try:
                if b is not None:
                    b.config(state=('normal' if k else 'disabled'))
            except Exception:
                pass

    def _fill_tx(text, empty=_EMPTY_MID):
        mid_tx.configure(state='normal')
        mid_tx.delete('1.0', 'end')
        # ★★★ **어디 것인지 맨 위에 한 줄** (2026-08-31 사용자 확정 —
        #   「이 묵상노트는 창1:1의 묵상노트입니다」).
        #   ⚠ **왜 여기인가** — 가운데 칸은 이 창이 「고르기 → **확인** → 연결」의
        #     확인을 위해 만든 자리다. 누르기 **전에** 읽힌다. 팝업은 잇는
        #     순간에만 뜨지만 이 줄은 **늘** 있어 오해를 미리 막는다
        #     (사용자 우려 — 「내용이 창1:1과 관계없는 것은 마치 오류인 것으로
        #     생각해서 지워버릴 수 있다」).
        #   ⚠ 태그·용어에는 안 붙는다(`ANCHORED_KINDS`).
        _head = ''
        try:
            k, i = view.get('kind'), view.get('id')
            if k in ANCHORED_KINDS and i:
                with appdb.connect(db_path) as _c:
                    _a = anchors_of(_c, k, i, lang)
                if _a:
                    _head = _t('LP_ANC_HEAD', '이 {k}는 {a}의 {k}입니다.').format(
                        k=kind_name(k), a=_a[0][1].split(' — ')[0]) + chr(10) * 2
        except Exception as e:
            print('[mid anchor] %s' % e)
        mid_tx.insert('1.0', _head + (text or empty))
        mid_tx.configure(state='disabled')

    def show_verses(text):
        _end_create()
        _fill_tx(text)

    def show_desc(text):
        _end_create()
        # ⚠ **누적하지 않는다**(사용자) — 갈아 끼운다. 설명문이 없으면 공란.
        _fill_tx(text, '(설명문이 없는 자산입니다)')
    _fill_tx('')

    # ★★★ **연결설명문 칸** (2026-09-01 사용자 지시 — 「가운데 확인화면에
    #   설명문을 표시하면서 **추가로 연결설명문을 입력할 공간**을 표시했으면
    #   좋겠다」).
    #   ★ **왜 여기인가** — 연결설명문은 「이 둘을 왜 이었나」이고, 그 판단이
    #     서는 자리가 바로 이 확인 칸이다. 자산 설명문 **바로 아래**에 두어
    #     위를 읽고 아래에 쓴다.
    #   ⚠ **자리가 없는 짝에는 안 그린다** — 있지도 않은 곳에 쓰게 하면
    #     저장이 조용히 사라진다(§0-1). 대신 **왜 못 쓰는지 한 줄**로 말한다.
    ld_f = tk.Frame(mid)
    ld_bar = tk.Frame(ld_f)
    ld_bar.pack(fill='x')
    ld_lbl = tk.Label(ld_bar, text=_t('LP_LD_HEAD', '연결설명문'), anchor='w')
    ld_lbl.pack(side='left')
    ld_state = tk.Label(ld_bar, text='', anchor='w')
    ld_state.pack(side='left', padx=(6, 0))
    ld_save = tk.Button(ld_bar, text=_t('COMMON_SAVE', '저장'), bd=1,
                        padx=6, cursor='hand2')
    ld_save.pack(side='right')
    ld_tx = tk.Text(ld_f, wrap='word', height=4, relief='solid', bd=1)
    ld_tx.pack(fill='x', pady=(2, 0))
    try:
        theme_font.register(ld_tx, db_path, 'body')
    except Exception:
        pass
    _ld = {'pair': None}          # 지금 칸이 맡고 있는 짝

    def _ld_target():
        """지금 칸이 쓸 짝 → (상대종류, 번호, 끝). 없으면 None."""
        src = cand or (view if view.get('kind') else None)
        if not src or not src.get('kind'):
            return None
        k = str(src['kind']).upper()
        if k in ('TAG', 'UTAG'):     # 태그에는 연결설명문 자리가 없다
            return None
        return (k, src.get('id'), src.get('end'))

    def _ld_sync():
        """칸을 지금 짝에 맞춘다. 자리가 없으면 통째로 감춘다."""
        two = _ld_target()
        if not two:
            _ld['pair'] = None
            ld_f.pack_forget()
            return
        one = (owner_kind, owner_id)
        tt = link_desc_type(one, (two[0], two[1], two[2]))
        if not tt:
            _ld['pair'] = None
            ld_f.pack_forget()
            return
        _ld['pair'] = two
        ld_f.pack(fill='x', pady=(6, 0))
        body, st = '', 'NOLINK'
        try:
            with appdb.connect(db_path) as c:
                body, st = link_desc(c, one, (two[0], two[1], two[2]),
                                     lang, scope)
        except Exception as e:
            print('[link_desc] %s' % e)
        ld_tx.delete('1.0', 'end')
        ld_tx.insert('1.0', body or '')
        # ⚠ **상태를 글로 말한다** — 「저장했는데 어디로 갔나」를 없앤다.
        ld_state.config(text={
            'SYS': _t('LP_LD_SYS', '(배포 설명문)'),
            'EDIT': _t('LP_LD_EDIT', '(내가 수정한 것)'),
            'NEW': _t('LP_LD_NEW', '(내가 쓴 것)'),
            'NONE': '',
            'NOLINK': _t('LP_LD_NOLINK', '(이으면 함께 저장됩니다)'),
        }.get(st, ''))

    def _ld_save(quiet=False):
        two = _ld['pair']
        if not two:
            return
        txt = ld_tx.get('1.0', 'end-1c')
        try:
            with appdb.connect(db_path) as c:
                st = save_link_desc(c, (owner_kind, owner_id),
                                    (two[0], two[1], two[2]),
                                    lang, txt, scope)
        except Exception as e:
            print('[save_link_desc] %s' % e)
            st = None
        if st == 'NOLINK' and not quiet:
            messagebox.showinfo(
                _t('LP_TITLE', '연결하기'),
                _t('LP_LD_FIRST',
                   '아직 이어지지 않았습니다. [⇦ 연결하기] 를 누르면'
                   ' 이 글도 함께 저장됩니다.'), parent=win)
            return
        _ld_sync()
    ld_save.config(command=_ld_save)

    # ── [연결] — 두 칸 사이 세로 단추 (3줄 높이 · 세로 가운데) ──
    def do_connect():
        if not cand:
            messagebox.showinfo(_t('LP_TITLE', '연결하기'),
                                '가운데에서 확인할 후보를 먼저 선택하세요.\n'
                                '(구절은 [찾기] · 자산은 목록 클릭)', parent=win)
            return
        if (cand['kind'], int(cand['id'])) == (owner_kind, owner_id):
            messagebox.showinfo(_t('LP_TITLE', '연결하기'),
                                '자기 자신은 연결할 수 없습니다.', parent=win)
            return
        # ★★★ **한 자산은 한 층에만** (2026-08-30 사용자 확정 — 「하나의
        #   컨텐츠가 여러 층에 중복되는 등록은 적절하지 않다 … **금지하자.**
        #   다만, **이전에 등록된 범위가 잘못일 수는 있다** … 따라서 다층 등록은
        #   **등록 대상 범위를 수정하라고 요청하는 절차**를 만들어라」).
        #   ⇒ 막되 **길을 낸다** — 「기존 연결을 여기로 옮기기」.
        #   ⚠ 자기 자신이 층인 자산(구절·단락·도서 편·책)끼리 잇는 것은 대상이
        #     아니다 — 그것은 「자료를 어디에 거나」가 아니라 자산끼리 잇는 일이다.
        if (owner_kind in LAYER_KINDS
                and cand['kind'] not in LAYER_KINDS
                and cand['kind'] not in ('TAG', 'UTAG')):
            _sv, _ev = None, None
            with appdb.connect(db_path) as c:
                _sv, _ev = _layer_span(c, owner_kind, owner_id,
                                       cand.get('end'))
                _mid = (_sv + (_ev or _sv)) // 2 if _sv else None
                _has = [x for x in layers_of(c, cand['kind'], cand['id'])
                        if not (x[0] == owner_kind and x[1] == owner_id)]
                # 이 절/구간에 **닿는** 것만 문제다
                _hit = []
                for ok, oi, lb in _has:
                    a2, b2 = _layer_span(c, ok, oi)
                    if a2 is None or _sv is None:
                        continue
                    if a2 <= (_ev or _sv) and _sv <= (b2 or a2):
                        _hit.append((ok, oi, lb))
                _here = scope_label(c, _sv, _ev) if _sv else ''
            if _hit:
                if not _ask_move(win, cand.get('label') or '', _hit, _here):
                    return
                with appdb.connect(db_path) as c:
                    for ok, oi, _lb in _hit:
                        remove(c, (ok, oi),
                               (cand['kind'], cand['id'], cand.get('end')),
                               scope=scope)
        # ★★★ **닻이 다른 곳에 있으면 묻는다** (2026-08-31 사용자 확정 문구
        #   「이 묵상노트는 창1:1의 묵상노트입니다. 창1:2에 추가 연결하겠습니까?」).
        #   ⚠ **왜 물어야 하나** — 사용자 지적: 창1:1 화면에서 창1:2용 노트를
        #     보면 「왜 여기 있지」 하고 **지워 버릴 수 있다**. 잇는 순간에
        #     「이 글은 원래 저기 것」임을 알려 두면 그 오해가 안 생긴다.
        #   ⚠ **태그·용어는 안 묻는다**(사용자 「수정할 여지가 없다. 필요 없다」)
        #     — 닻이 없고 내용이 오염될 일도 없다. 묻는 것은 **글을 가진 자산**
        #     (묵상노트·연구자료)뿐이다.
        #   ⚠ **드물어서 값을 한다** — 실측 노트 24편의 연결이 전부 7건이고
        #     다른 구절에 이은 것은 **0건**이다. 늘 뜨는 경고는 안 읽히고
        #     정작 위험한 경고까지 죽인다(§115차).
        if cand['kind'] in ANCHORED_KINDS:
            with appdb.connect(db_path) as c:
                _anc = anchors_of(c, cand['kind'], cand['id'], lang)
                _self = (owner_kind, int(owner_id))
                _out = [a for a in _anc if a[2] != _self]
            if _out:
                _kn = kind_name(cand['kind'])
                if not messagebox.askyesno(
                        _t('LP_TITLE', '연결하기'),
                        _t('LP_ANC_ASK',
                           '이 {k}는 {a}의 {k}입니다.'
                           + chr(10) + '{t}에 추가로 연결하겠습니까?').format(
                            # ⚠ 설명 꼬리(`— 이 노트가 붙은 자리`)를 뗀다 —
                            #   문장 안에 들어가면 「창1:20 — 이 노트가 붙은
                            #   자리의 묵상노트입니다」가 되어 안 읽힌다.
                            k=_kn, a=_out[0][1].split(' — ')[0], t=own_label),
                        parent=win):
                    return
        # ★★ **태그는 자기 저장소로 간다** (2026-08-29 · 항목 3-(b)).
        #   ⚠⚠ 여기서 `add()` 를 부르면 `TAG_VERS` 가 **통합 표**에 들어가는데
        #     태그 조회는 `user_tag_link` 을 읽는다 — 「저장은 되는데 안 보인다」
        #     가 그대로 재현된다(실제로 `TAG_VERSE` 7행이 그 잔재다).
        if cand['kind'] in ('TAG', 'UTAG'):
            import tag_picker
            src = 'SYS' if cand['kind'] == 'TAG' else 'USER'
            cur = set((a, b) for a, b, _n, _c in tag_picker.tags_of(
                db_path, owner_kind, owner_id, lang, scope=scope))
            cur.add((src, int(cand['id'])))
            tag_picker.save_links(db_path, owner_kind, owner_id, cur,
                                  scope=scope)
        else:
            with appdb.connect(db_path) as c:
                add(c, (owner_kind, owner_id),
                    (cand['kind'], cand['id'], cand.get('end')), scope=scope)
        # ★★ **이으면서 연결설명문도 함께 저장한다** (2026-09-01) — 잇기 전에는
        #   붙일 행이 없으므로 여기가 그 글의 첫 자리다. 안 그러면 써 놓고
        #   [저장] 을 또 눌러야 하고, 그 사이에 글이 사라진 것처럼 보인다.
        try:
            if _ld['pair'] and ld_tx.get('1.0', 'end-1c').strip():
                _ld_save(quiet=True)
        except Exception as e:
            print('[connect + desc] %s' % e)
        changed()

    con_btn = tk.Button(gap_a, text='⇦ ' + _t('LP_CONNECT', '연결하기'), bd=1,
                        padx=6, pady=4, cursor='hand2', command=do_connect,
                        wraplength=98, justify='center')
    con_btn.pack(fill='x')
    # ⚠ 처음에는 후보가 없다 — 잠가 둔다(누르면 상자가 뜨던 것을 없앤다)
    _arm_connect(False)

    # ── 왼쪽 — 구절/범위(찾기) · 태그 · 연결대상 ──
    tk.Label(left, text=_t('LP_H_STOCK', '③ 재고창고 — 여기서 선택해 [⇦ 연결]'),
             anchor='w', font=('', 10, 'bold')).pack(fill='x')

    def pick_range(rng):
        # 구절 [찾기]/범위 단추 — **후보로만** 담는다(잇지 않는다)
        if not rng:
            show_verses('')
            clear_cand()
            return
        sv, ev = rng
        with appdb.connect(db_path) as c:
            show_verses(verse_preview_text(c, sv, ev, lang))
            set_cand('VERSE', sv, ev if ev != sv else None,
                     _verse_label(c, sv, ev if ev != sv else None, lang))

    # ★★ **자기 갈래를 통째로 끄지 않는다** (2026-08-29). 그전에는 구절에서
    #   열면 성경 재고창고가 **갈래째** 꺼져 절↔절을 못 이었다 — 자산연결정책
    #   표는 절↔절을 「연결/연결설명문」이라 하고 실데이터도 2,734행이다.
    #   `_build_assets` 는 이미 **자기 자신만** 막는 방식이라 규칙을 맞춘다
    #   (`do_connect` 가 같은 자산이면 잡아 알린다).
    _build_bible(left, db_path, owner_kind, owner_id, lang, changed,
                 enabled=True, scope=scope,
                 on_range=pick_range)
    # ⚠⚠ **[태그 고르기…] 줄을 걷었다** (2026-08-30 사용자 지시 「태그고르기
    #   버튼을 제거할 것」). 그 팝업의 몫(축 거르기·유사어 검색)은 아래
    #   재고창고로 **이미 옮겨 왔다** — 남겨 두면 같은 일에 창이 둘이다.
    #   `_build_tag` 함수 자체는 관리자 쪽 호출을 위해 남긴다.

    def _preview_linked(x):
        # 현황 줄의 내용을 확인 칸에 — **후보는 비운다**(이미 연결된 것이라
        # [⇦연결]이 할 일이 없다. 안 비우면 직전 재고 후보가 붙는다 — §버그).
        k = str(x.get('kind') or '').upper()
        try:
            with appdb.connect(db_path) as c:
                if k in ('VERSE', 'VERS'):
                    show_verses(verse_preview_text(
                        c, x['id'], x.get('end') or x['id'], lang))
                else:
                    show_desc(desc_of(c, k, x['id'], lang))
            clear_cand('(연결된 것) %s' % (x.get('label') or ''))
            _set_view(k, x['id'], x.get('label') or '')
        except Exception as e:
            print('[preview linked] %s' % e)
    def _preview_anchor(knm, lb):
        """참고 줄(주석·소속 단락) — **왜 여기서 못 잇는지**를 그 자리에서."""
        clear_cand('(참고) %s' % lb)
        _fill_tx(
            '「%s」 %s\n\n'
            'ⓘ 이것은 **연결이 아니라 앵커**입니다.\n'
            '   주석과 소속 단락은 구절 번호에 저절로 붙어 있어서 여기서 잇거나\n'
            '   뗄 것이 없습니다. 이 구절을 이으면 그 자리의 주석·설명문이\n'
            '   함께 닿습니다.\n\n'
            '   고치려면 — 주석은 관리자 ▸ 주석 관리 ·\n'
            '   구절단락은 관리자 ▸ 구절단락 편집기.' % (knm, lb))
    _hook['anchor_info'] = _preview_anchor
    _hook['preview'] = _preview_linked

    def pick_asset(kind, tid, label):
        # 후보 목록 **한 번 클릭** — 설명문 확인 + 후보로 담는다
        # ⚠⚠ **`_set_view` 를 먼저** (2026-08-31) — 가운데 머리줄(「이 묵상노트는
        #   창1:20의 묵상노트입니다」)이 `view` 를 읽는데, 그리기(`show_desc`)를
        #   먼저 하면 **직전 자산의 값**으로 그린다(실측 — 줄이 아예 안 떴다).
        _set_view(kind, tid, label)
        with appdb.connect(db_path) as c:
            show_desc(desc_of(c, kind, tid, lang))
        set_cand(kind, tid, None, label)

    def open_asset(kind, tid):
        # 후보 목록 **겹클릭** — 그 콘텐츠를 연다(잇기 전에 열어 본다)
        if kind in ('MEDIA', 'UMEDIA'):
            with appdb.connect(db_path) as c:
                r = (c.execute('SELECT url FROM sys_media_asset '
                               ' WHERE media_id=?', (tid,)).fetchone()
                     if kind == 'MEDIA' else
                     c.execute('SELECT url FROM userdb.user_media_asset'
                               # status-ok: 번호 하나로 주소를 읽는 자리
                               ' WHERE user_media_id=?', (tid,)).fetchone())
            if r and r[0]:
                import webbrowser
                webbrowser.open(r[0])
            return
        if callable(on_open):
            win.destroy()
            try:
                parent.after(1, lambda: on_open(kind, tid))
            except Exception as e:
                print('[link_picker open] %s' % e)
        else:
            messagebox.showinfo(_t('LP_TITLE', '연결하기'),
                                _t('LP_NO_JUMP',
                                   '이 화면에서는 아직 열 수 없습니다.'),
                                parent=win)

    # ══ 만들기 폼 — 자산 종류가 폼을 정한다(`CREATE_CAPS`) ═══
    def _start_create(kind):
        """재고창고 [＋ 새 …] → 가운데 칸을 **입력 모드**로."""
        okc, form, why = can_create(kind, scope)
        if not okc:
            messagebox.showinfo(_t('LP_NEW', '새로 만들기'), why, parent=win)
            return
        if kind == 'UNODE' and owner_kind != 'ULENS':
            messagebox.showinfo(
                _t('LP_NEW', '새로 만들기'),
                '내 노드는 내 렌즈 아래에 만듭니다.' + chr(10)
                + '먼저 위 띠에서 내 렌즈를 출발지로 잡으세요.', parent=win)
            return
        _open_form(kind, form)

    def _open_form(kind, form, mode='NEW', tid=None, cur=None):
        """★★★ **만들기와 수정이 같은 폼**이다 (2026-08-29 사용자 —
        「가운데 확인 화면에서 **추가/수정**이 가능해야 한다」).

        ⚠ 폼을 둘로 만들지 않는다 — 칸이 갈리면 만들 때와 고칠 때 담기는 값이
          달라진다(연결설명문이 그렇게 세 철자로 갈렸다).
        `mode='EDIT'` 면 `cur` 로 칸을 채우고 저장이 갱신으로 간다.
        """
        cur = cur or {}
        vs_f.pack_forget()
        for w in form_f.winfo_children():
            w.destroy()
        form_f.pack(fill='both', expand=True, pady=(2, 0))
        _form['on'] = True
        head = ('＋ %s' if mode == 'NEW' else '✎ %s') % kind_name(kind)
        clear_cand(head)
        v = {}
        g = tk.Frame(form_f)
        g.pack(fill='x', padx=2, pady=2)
        g.columnconfigure(1, weight=1)

        def _row(r, label, w=None, val=''):
            _lbl(g, label).grid(row=r, column=0, sticky='w', pady=3)
            e = w or ttk.Entry(g)
            e.grid(row=r, column=1, sticky='we', padx=(8, 0))
            if val and not w:
                e.insert(0, val)
            return e

        body = None
        if form == 'URL':
            v['url'] = _row(0, 'URL', val=cur.get('url', ''))
            v['title'] = _row(1, _t('COMMON_TITLE', '제목'),
                              val=cur.get('title', ''))
            var = tk.StringVar(value=cur.get('type') or MEDIA_TYPES[1])
            _row(2, _t('LP_MEDIA_TYPE', '갈래'),
                 ttk.Combobox(g, textvariable=var, state='readonly',
                              values=list(MEDIA_TYPES)))
            v['_typevar'] = var
        elif form == 'NAME':
            v['name'] = _row(0, _t('COMMON_NAME', '이름'),
                             val=cur.get('name', ''))
            # ★★★ **내 용어는 분류를 고른다**(2026-09-18 사용자 「용어 분류값에
            #   하나 추가하고 주요용어 관리화면에서 모두 관리」).
            #   ⚠ 그전에는 무조건 `THEME` 으로 굳었다 — 사용자가 다는 말은 거의
            #     **심리·국면**인데 그 자리에 못 들어갔다. 기본값을 그리로 둔다.
            #   ⚠ 목록은 `db_tag_system.ALL_AXES` 한 곳에서 온다(= 주요용어 유형).
            if kind in ('ENTITY', 'TAG', 'UTAG'):
                try:
                    import db_tag_system as _TS
                    _ax = list(_TS.ALL_AXES)
                except Exception:
                    _ax = [('PHASE', '심리·국면')]
                _names = [n for _c, n in _ax]
                _cur_ax = cur.get('axis') or 'PHASE'
                _cur_nm = dict(_ax).get(_cur_ax, _names[0])
                _av = tk.StringVar(value=_cur_nm)
                _row(1, _t('EB_TYPE_HDR', '분류'),
                     ttk.Combobox(g, textvariable=_av, state='readonly',
                                  values=_names))
                v['_axisvar'] = _av
                v['_axismap'] = {n: c for c, n in _ax}
        else:                                   # TITLE — 제목 + 본문
            v['title'] = _row(0, _t('COMMON_TITLE', '제목'),
                              val=cur.get('title', ''))
            # ★★★ **기호 단추는 폼이 단다** (2026-08-31 사용자 지시 「가운데
            #   화면에 텍스트를 입력하는 것(묵상노트, 연구자료, 설명문 등)은
            #   **모두 기호 버튼을 누를 수 있도록 통일**하라」).
            #   ⚠ 그전에는 묵상노트·연구자료가 **각자 제 화면에** 달고 있어,
            #     가운데 폼에는 아예 없었다. 여기 한 곳에 두면 글 칸이 생기는
            #     자리마다 저절로 따라온다 — 화면마다 배선하면 반드시 빠진다.
            _sy = tk.Frame(form_f)
            _sy.pack(fill='x', padx=2, pady=(4, 0))
            body = tk.Text(form_f, height=8, wrap='word', relief='solid', bd=1)
            try:
                import symbol_picker
                symbol_picker.button(
                    _sy, lambda: body,
                    text=_t('MP_SYMBOLS', '기호'),
                    db_path=db_path).pack(side='right')
            except Exception as _e:
                print('[link_picker symbol] %s' % _e)
            body.pack(fill='both', expand=True, padx=2, pady=(2, 2))
            if cur.get('body'):
                body.insert('1.0', cur['body'])
            try:
                import theme_font
                theme_font.register(body, db_path, 'body')
            except Exception:
                pass
        v['_body'] = body

        def _save():
            try:
                if mode == 'EDIT':
                    _update(kind, form, v, tid)
                    nk, nid = kind, tid
                else:
                    nk, nid = _create(kind, form, v)
            except Exception as e:
                messagebox.showerror(head, str(e), parent=win)
                return
            if not nid:
                return
            # ★ **저장 및 자동연결** (0.txt 1-4-(4)) — 만들었으면 곧 이어 준다.
            if mode == 'NEW' and nk:
                with appdb.connect(db_path) as c:
                    add(c, (owner_kind, owner_id), (nk, nid), scope=scope)
            _end_create()
            changed()
            _fill_tx(('「%s」 을(를) 만들어 이었습니다.' if mode == 'NEW'
                      else '「%s」 을(를) 고쳤습니다.')
                     % _label_safe(nk or 'TAG', nid))

        bar = tk.Frame(form_f)
        bar.pack(fill='x', pady=(4, 0))
        tk.Button(bar, text=(_t('LP_SAVE_LINK', '저장 및 연결') if mode == 'NEW'
                             else _t('COMMON_SAVE', '저장')),
                  bd=1, padx=14, pady=3, cursor='hand2',
                  command=_save).pack(side='left')
        tk.Button(bar, text=_t('COMMON_CANCEL', '취소'), bd=1, padx=14, pady=3,
                  cursor='hand2',
                  command=lambda: (_end_create(), _fill_tx(''))).pack(
            side='left', padx=6)
        if mode == 'NEW' and kind in ('ULENS', 'UNODE'):
            tk.Label(form_f, anchor='w', justify='left', wraplength=380,
                     text=_t('LP_NEW_LENS_HINT',
                             'ⓘ 이름만 만듭니다. 노드·구절 구조는 '
                             'My Edit 의 「구조」에서 짭니다.')).pack(
                fill='x', pady=(6, 0))

    def _update(kind, form, v, tid):
        """수정 — **내가 만든 것만**(`EDIT_CAPS`). 배포 자료는 여기서 안 고친다."""
        if form == 'URL':
            u = v['url'].get().strip()
            if not u:
                raise ValueError('URL 을 적으세요.')
            with appdb.connect(db_path) as c:
                if kind == 'UMEDIA':
                    edit_user_media(c, tid, v['title'].get().strip(), u, v['_typevar'].get())
                elif not is_physical(scope):
                    raise ValueError(EDIT_WHY['MEDIA'])
                else:
                    edit_media(c, tid, v['title'].get().strip(), u,
                               v['_typevar'].get())
            return
        if kind == 'NOTE':
            # ★ 묵상노트 — 저장소는 `user_text_asset('VERS_NOTE')` 하나다.
            #   ⚠ **닻은 구절**이다(`notes.md` §0-1) — 출발지가 구절일 때만
            #     만들 수 있다. 아니면 어느 절에 쓴 글인지 알 수 없다.
            t = v['title'].get().strip()
            bd = v['_body'].get('1.0', 'end').strip() if v['_body'] else ''
            if not (t or bd):
                raise ValueError('제목이나 내용을 적으세요.')
            if owner_kind != 'VERSE':
                raise ValueError('묵상노트는 구절을 출발지로 할 때 만듭니다.')
            with appdb.connect(db_path) as c:
                cur = c.execute(
                    "INSERT INTO userdb.user_text_asset"
                    "(text_type, clicked_id, target_id, title, contents, "
                    " lang_code, record_status, created_at, updated_at) "
                    "VALUES('VERS_NOTE',?,?,?,?,?, 'NEW',"
                    "       datetime('now'), datetime('now'))",
                    (int(owner_id), int(owner_id), t, bd, (lang or 'KO')))
                c.commit()
                return 'NOTE', cur.lastrowid
        if kind == 'NOTE':
            t = v['title'].get().strip()
            bd = v['_body'].get('1.0', 'end').strip() if v['_body'] else ''
            if not (t or bd):
                raise ValueError('제목이나 내용을 적으세요.')
            with appdb.connect(db_path) as c:
                c.execute("UPDATE userdb.user_text_asset "
                          "   SET title=?, contents=?, "
                          "       updated_at=datetime('now') "
                          " WHERE user_text_id=?", (t, bd, tid))
                c.commit()
            return
        if kind == 'USER_REF':
            t = v['title'].get().strip()
            if not t:
                raise ValueError('제목을 적으세요.')
            bd = v['_body'].get('1.0', 'end').strip() if v['_body'] else ''
            with appdb.connect(db_path) as c:
                c.execute("UPDATE user_ref_asset SET title=?, summary=? "
                          " WHERE ref_id=?", (t, bd, tid))
                c.commit()
            return
        if kind == 'UTAG':
            nm = ' '.join((v['name'].get() or '').split())
            if not nm:
                raise ValueError('이름을 적으세요.')
            with appdb.connect(db_path) as c:
                dup = c.execute("SELECT user_tag_id FROM userdb.user_tag_asset"
                                " WHERE tag_name_sid=? AND user_tag_id<>?",
                                (nm, tid)).fetchone()
                if dup:
                    raise ValueError('같은 이름의 내 용어가 이미 있습니다.')
                _ax = None
                if v.get('_axisvar') is not None:
                    _ax = v['_axismap'].get(v['_axisvar'].get())
                if _ax:
                    c.execute("UPDATE userdb.user_tag_asset SET tag_name_sid=?,"
                              " tag_category=? WHERE user_tag_id=?",
                              (nm, _ax, tid))
                else:
                    c.execute("UPDATE userdb.user_tag_asset SET tag_name_sid=? "
                              " WHERE user_tag_id=?", (nm, tid))
                c.commit()
            return
        if kind in ('ULENS', 'UNODE'):
            nm = v['name'].get().strip()
            if not nm:
                raise ValueError('이름을 적으세요.')
            import my_lens_edit
            with appdb.connect(db_path) as c:
                my_lens_edit.rename_unit(c, tid, nm)
            return
        raise ValueError('수정 화면이 없습니다.')

    def _label_safe(k, i):
        try:
            with appdb.connect(db_path) as c:
                return label_of(c, k, i, None, lang) or ('#%s' % i)
        except Exception:
            return '#%s' % i

    def _create(kind, form, v):
        """만들기 — **(종류, 번호)**. 태그는 자기 저장소가 이미 이었다."""
        if form == 'URL':
            u = v['url'].get().strip()
            if not u:
                raise ValueError('URL 을 적으세요.')
            # ★★★ **사용자가 더한 URL 은 개인 자산이다**(2026-09-10) —
            #   그전에는 배포 DB(`sys_media_asset`)로 갔다. 다음 콘텐츠 배포에
            #   통째로 날아가고 남의 PC 에는 없는 번호가 된다(§C-2).
            #   관리자 창(SYS)은 종전대로 배포 표에 담는다.
            with appdb.connect(db_path) as c:
                if is_physical(scope):
                    return 'MEDIA', new_media(c, v['title'].get().strip(), u,
                                              v['_typevar'].get(), lang)
                return 'UMEDIA', new_user_media(
                    c, v['title'].get().strip(), u, v['_typevar'].get(), lang)
        if kind in ('ENTITY', 'TAG'):
            # ★ 사용자에게 「용어」는 **내 태그**다 — 저장소는 `tag_picker` 하나.
            nm = v['name'].get().strip()
            if not nm:
                raise ValueError('이름을 적으세요.')
            import tag_picker
            _ax = 'PHASE'
            if v.get('_axisvar') is not None:
                _ax = v['_axismap'].get(v['_axisvar'].get(), 'PHASE')
            got = tag_picker.add_user_tag(db_path, nm, _ax)
            if not got:
                raise ValueError('만들지 못했습니다.')
            src, tid = got
            cur = set((a, b) for a, b, _n, _c in tag_picker.tags_of(
                db_path, owner_kind, owner_id, lang, scope=scope))
            cur.add((src, tid))
            tag_picker.save_links(db_path, owner_kind, owner_id, cur,
                                  scope=scope)
            return None, tid
        if kind == 'USER_REF':
            t = v['title'].get().strip()
            if not t:
                raise ValueError('제목을 적으세요.')
            bd = v['_body'].get('1.0', 'end').strip() if v['_body'] else ''
            with appdb.connect(db_path) as c:
                cur = c.execute(
                    "INSERT INTO user_ref_asset(title, summary, lang_code, "
                    " ref_type, record_status) VALUES(?,?,?,'STUDY','LIVE')",
                    (t, bd, lang))
                c.commit()
                return 'USER_REF', cur.lastrowid
        if kind in ('ULENS', 'UNODE'):
            nm = v['name'].get().strip()
            if not nm:
                raise ValueError('이름을 적으세요.')
            import my_lens_edit
            with appdb.connect(db_path) as c:
                if kind == 'ULENS':
                    nid, _n = my_lens_edit.create_lens(c, nm)
                else:
                    nid, _n = my_lens_edit.create_node(c, owner_id, nm)
            return kind, nid
        raise ValueError('만들기 화면이 없습니다.')

    # ══ 손질 — 그 자리에서 고치기·숨기기 (0.txt 1-4-(2)) ═══════════
    def _start_edit():
        """② [✎ 수정] — 지금 보고 있는 자산을 **같은 폼**에 채워 연다."""
        k, tid = view.get('kind'), view.get('id')
        if not k:
            return
        oke, form, why = can_edit(k, scope)
        if not oke:
            messagebox.showinfo(_t('COMMON_EDIT', '수정'), why, parent=win)
            return
        cur = {}
        with appdb.connect(db_path) as c:
            if k in ('MEDIA', 'UMEDIA'):
                r = (media_row(c, tid) if k == 'MEDIA'
                     else user_media_row(c, tid))
                cur = {'title': (r and r[0]) or '', 'url': (r and r[1]) or '',
                       'type': (r and r[2]) or MEDIA_TYPES[1]}
            elif k == 'USER_REF':
                r = c.execute('SELECT title, summary FROM user_ref_asset '
                              ' WHERE ref_id=?', (tid,)).fetchone()
                cur = {'title': (r and r[0]) or '', 'body': (r and r[1]) or ''}
            elif k == 'NOTE':
                r = c.execute('SELECT title, contents FROM '
                              'userdb.user_text_asset WHERE user_text_id=?',
                              (tid,)).fetchone()
                cur = {'title': (r and r[0]) or '', 'body': (r and r[1]) or ''}
            elif k == 'UTAG':
                r = c.execute('SELECT tag_name_sid FROM userdb.user_tag_asset'
                              ' WHERE user_tag_id=?', (tid,)).fetchone()
                cur = {'name': (r and r[0]) or ''}
            else:                                   # ULENS · UNODE
                r = c.execute('SELECT unit_name_sid FROM userdb.user_unit_asset'
                              ' WHERE user_unit_id=?', (tid,)).fetchone()
                cur = {'name': (r and r[0]) or ''}
        _open_form(k, form, mode='EDIT', tid=tid, cur=cur)

    def _hide_asset():
        """② [◐ 숨기기] — **자산 자체**를 가린다(연결 빼기와 다른 일)."""
        k, tid = view.get('kind'), view.get('id')
        if not k:
            return
        oke, _f, why = can_edit(k, scope)
        if not oke:
            messagebox.showinfo(_t('LP_HIDE_ASSET', '자산 숨기기'), why,
                                parent=win)
            return
        nm = view.get('label') or _label_safe(k, tid)
        gone = is_physical(scope)
        if not messagebox.askyesno(
                _t('LP_HIDE_ASSET', '자산 숨기기'),
                '「%s」' % nm + chr(10) * 2
                + ('영구히 지웁니다(관리자 물리삭제 — 복구는 감사 로그).'
                   if gone else
                   '지우지 않고 숨깁니다. 같은 이름으로 다시 만들면 되살아납니다.'),
                parent=win):
            return
        with appdb.connect(db_path) as c:
            if k == 'MEDIA':
                hide_media(c, tid, True, scope=scope)
            elif k == 'UMEDIA':
                # ⚠ 개인 자산이라 **물리삭제하지 않는다**(되살릴 자리를 남긴다)
                hide_user_media(c, tid, True)
            elif k == 'USER_REF':
                c.execute("UPDATE user_ref_asset SET record_status='HIDE' "
                          " WHERE ref_id=?", (tid,))
                c.commit()
            elif k == 'UTAG':
                c.execute("UPDATE userdb.user_tag_asset "
                          " SET record_status='HIDE' WHERE user_tag_id=?",
                          (tid,))
                c.commit()
            else:
                c.execute("UPDATE userdb.user_unit_asset "
                          " SET record_status='HIDE' WHERE user_unit_id=?",
                          (tid,))
                c.commit()
        view.clear()
        _sync_fix_btns()
        changed()
        _fill_tx('「%s」 을(를) 숨겼습니다.' % nm)


    def _anchor_pick(kind=None, tid=None):
        """★ 재고에서 선택한 것을 **출발지로** (2026-08-29 사용자 —
        「재고자산 목록에서 하나를 클릭하고 출발지로 지정해서 그 자산을
        기준으로 연결상태를 살펴볼 수 있어야 한다」)."""
        # ★ 목록에서 고른 것이 없으면 **가운데 후보**를 쓴다 — 구절은
        #   목록이 아니라 [찾기] 로 담기기 때문이다(2026-08-29).
        if not kind and cand:
            kind, tid = cand['kind'], cand['id']
        if not kind:
            messagebox.showinfo(
                _t('LP_SET_OWNER', '출발지로 지정'),
                _t('LP_PICK_ROW', '먼저 목록에서 하나를 선택하세요.'), parent=win)
            return
        if not callable(on_anchor):
            messagebox.showinfo(
                _t('LP_TITLE', '연결하기'),
                _t('LP_NO_ANCHOR', '이 화면에서는 출발지를 바꿀 수 없습니다.'),
                parent=win)
            return
        on_anchor(kind, tid)

    _made = _build_assets(left, db_path, owner_kind, owner_id, lang, changed,
                          own_branch, scope=scope,
                          on_pick=pick_asset, on_open_asset=open_asset,
                          on_create=_start_create, on_anchor_pick=_anchor_pick,
                          pick_kind=pick_kind, pick_label=pick_label,
                          auto_create=auto_create,
                          on_edit_asset=_start_edit, on_hide_asset=_hide_asset)
    _fix['e'] = (_made or {}).get('edit')
    _fix['h'] = (_made or {}).get('hide')
    _sync_fix_btns()

    reload_list()
    # ★★★ **① 현황에서 그 줄을 골라 둔다** (2026-08-30 사용자 지시 「목록을
    #   클릭하고 링크 숨기기 버튼을 누르면 연결팝업 화면의 왼쪽 화면에서
    #   **해당 링크가 선택된 상태로 자동 세팅** ⇒ 연결숨기기 버튼만 누르면
    #   숨기기 완성」).
    #   ⚠ 목록을 **다 그린 뒤**에 고른다 — 그리기 전에 고르면 `tv.delete` 가
    #     지운다. `reload_list()` 바로 아래가 그 자리다.
    #   ⚠ 못 찾으면 **조용히 넘어간다** — 그 줄이 이미 숨겨졌거나 갈래가 바뀌었을
    #     수 있고, 그때 상자를 띄우면 방해만 된다(목록에서 고르면 된다).
    if focus_link:
        try:
            _fk = str(focus_link[0]).upper()
            _fi = int(focus_link[1])
            for _iid, _x in rows.items():
                if (str(_x.get('kind')).upper() == _fk
                        and int(_x.get('id') or 0) == _fi):
                    tv.selection_set(_iid)
                    tv.focus(_iid)
                    tv.see(_iid)
                    _preview_linked(_x)
                    _drop_label()
                    break
        except Exception as e:
            print('[link_picker focus_link] %s' % e)
    # ★★★ **다 짓고 테마를 입힌다** (2026-08-29 사용자 신고 「화면색 테마가
    #   제대로 적용되지 않는다. 어디는 다크모드 어디는 흰색… 눈아프다」).
    #   ⚠⚠ `ui_theme.paint` 는 **이미 있는 위젯**을 다시 칠한다 — 그런데 이
    #     작업대는 앱이 칠한 **뒤에** 지어지므로 새 위젯이 기본색(흰 바탕)으로
    #     남았다. 실측 — 검정 테마에서 밝은 바탕 **74개**(paint 를 부르면 0).
    #   ⚠ 출발지를 바꿔 다시 지을 때도 매번 불러야 한다(`_draw` 가 부른다).
    try:
        import ui_theme
        ui_theme.paint(outer)
    except Exception as e:
        print('[link_picker paint] %s' % e)
    # ★★★ **재고창고에서 고른 것을 되살린다** (1.txt 1-1). 몸통을 다시 지어도
    #   가운데 이름과 [⇦ 연결] 이 그대로 살아 있어 **이어서 연결**할 수 있다.
    #   ⚠ `set_cand` 가 맨 앞에서 `cand.clear()` 를 하므로 **미리 떠 둔 값**을
    #     쓴다(같은 객체를 넘기면 자기 자신을 지우고 빈 것을 넣는다).
    if _keep_cand.get('kind') and _keep_cand.get('id'):
        try:
            set_cand(_keep_cand['kind'], _keep_cand['id'],
                     _keep_cand.get('end'), _keep_cand.get('label') or '')
        except Exception as e:
            print('[link_picker cand restore] %s' % e)
    return {'frame': outer, 'refresh': reload_list, 'win': win,
            'own_label': own_label}


def open_picker(parent, db_path, owner_kind, owner_id, scope='USER',
                lang_getter=None, ver_getter=None, on_saved=None, mode='EDIT',
                on_open=None, pick_kind=None):
    """연결하기 **창** — `build_workbench` 를 Toplevel 에 담은 껍데기.

    ⚠ 본체는 위 `build_workbench` 다 — 탭·사용자 화면과 **같은 것**을 쓴다.
      여기는 창 전용 일만 한다: 제목·닫기·매뉴얼·테마·자리·모달.
    ⚠ `mode`/`ver_getter` 는 부르는 곳이 있어 그대로 받는다(동작 무관).
    """
    import tkinter as tk
    win = tk.Toplevel(parent)
    win.transient(parent.winfo_toplevel())
    # ⚠⚠ 바닥 띠 먼저(§0 함정 — expand 자식 뒤에 pack 하면 [닫기]가 1px 로
    #   사라진다. 문서에 다섯 번째로 적히는 함정이다)
    foot = tk.Frame(win)
    foot.pack(side='bottom', fill='x', padx=8, pady=(0, 8))
    try:
        from manual_widget import attach_manual_icon
        attach_manual_icon(foot, 'U_LINK_PICK',
                           lang_provider=(lang_getter if callable(lang_getter)
                                          else (lambda: 'KO')),
                           db_path=db_path).pack(side='left')
    except Exception as e:
        print('[manual link_picker] %s' % e)
    # ★ 창은 **띠를 얹는다** (2026-08-29 · 항목 5) — 여기서 열면 호스트가
    #   출발지를 바꿔 줄 길이 없으므로 창 스스로 갈아탈 수 있어야 한다.
    api = build_workbench(win, db_path, owner_kind, owner_id, scope=scope,
                          lang_getter=lang_getter, on_saved=on_saved,
                          on_open=on_open, close_cb=win.destroy,
                          anchor_bar=True, pick_kind=pick_kind)
    if not api:
        win.destroy()
        return None
    win.title('%s — %s' % (_t('LP_TITLE', '연결하기'), api['own_label']))
    # ⚠ 「연결 저장」 단추를 두지 않는다(2026-08-21 승인) — 넣는 즉시 저장이고
    #   오른쪽 목록이 곧 저장된 내용이다.
    tk.Button(foot, text=_t('LP_CLOSE', '닫기'), bd=1,
              padx=18, pady=3, cursor='hand2',
              command=win.destroy).pack(side='right')
    _finish_theme(win)          # ⚠ 반드시 다 지은 뒤(adopt 는 그때 자식만 칠한다)
    _place_bottom(win, parent)
    win.grab_set()
    win.wait_window()
    if callable(on_saved):
        on_saved()
    return True


def _place_bottom(win, parent):
    """**좌우로 길게, 화면 아래쪽에** (2026-08-21 사용자 지시).

    ★ 뒤 화면(본문·표시줄)이 위에 그대로 보여야 **닫기 전에** 방금 건 연결이
      실제로 나타났는지 확인할 수 있다. 가운데에 크게 띄우면 그것을 가린다."""
    win.update_idletasks()
    try:
        sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
        w = max(960, min(sw - 80, 1520))
        # ⚠ **높이는 실제로 필요한 만큼** — 짧게 못 박으면 안에 든 것이 눌려
        #   바닥 단추가 1px 로 사라진다(실측). 3분할이 되며 **위로 조금만**
        #   키웠다(사용자 — 「지금 화면크기에서 위로 조금만 더 키우면 된다.
        #   **창이 본 화면 가리지 않도록 하라**」) — 화면의 절반은 안 넘는다.
        h = max(430, min(max(win.winfo_reqheight(), 470), int(sh * 0.50)))
        win.geometry('%dx%d+%d+%d' % (w, h, (sw - w) // 2, sh - h - 80))
        win.minsize(880, 320)
    except Exception:
        pass


PREVIEW_MAX = 40      # 미리보기에 싣는 최대 절 수 — 넘으면 「… 외 N절」


def ensure_chain_ids(conn):
    """흐름에 **정수 신원**을 준다 → {chain_code: chain_id}.

    ⚠ 통합 연결 표의 `clicked_id`/`target_id` 는 정수인데 흐름의 열쇠는
      글자(`PRG-LIGHT`)다. 흐름이 연결 **대상 자산**이 되려면(2026-08-27
      사용자 확정) 정수가 필요하다 — `sys_chain_master` 가 그 다리다.
    ⚠ 멱등 — 새 흐름이 카탈로그에 늘면 다음 호출 때 번호를 받는다.
    """
    conn.execute("""CREATE TABLE IF NOT EXISTS sys_chain_master (
        chain_id   INTEGER PRIMARY KEY AUTOINCREMENT,
        chain_code TEXT UNIQUE NOT NULL)""")
    conn.execute("INSERT OR IGNORE INTO sys_chain_master(chain_code) "
                 "SELECT DISTINCT chain_code FROM sys_chain_catalog "
                 " WHERE TRIM(COALESCE(chain_code,''))<>''")
    conn.commit()
    return {r[1]: r[0] for r in conn.execute(
        'SELECT chain_id, chain_code FROM sys_chain_master')}


def chain_id_of(conn, chain_code):
    """흐름 코드 → 정수 신원(없으면 만든다)."""
    return ensure_chain_ids(conn).get(chain_code)


#: **짝 → 연결설명문의 집** (2026-09-01 신설 · 실측 기반).
#  ⚠ **새 유형을 지어내지 않는다** — 이미 쓰이는 다섯만 담았다.
#    짝이 여기 없으면 「그 짝에는 연결설명문 자리가 없다」가 사실이고,
#    화면은 **왜 못 쓰는지 말한다**(§0-1 조용한 실패 금지).
#  ⚠ 개인 렌즈(`UCNT`·`UNOD`)도 같은 유형을 쓴다 — 저장 표만 다르다.
LINK_DESC_TYPE = {
    'CONT_NODE': 'CONT_NODE_DESC',
    'UCNT_UNOD': 'CONT_NODE_DESC',
    'NODE_VERS': 'NODE_VERS_DESC',
    'UNOD_VERS': 'NODE_VERS_DESC',
    'VERS_VERS': 'VERS_VERS_DESC',
    'ENTI_PERI': 'ENTITY_PERI_DESC',
    'ENTI_VERS': 'ENTITY_VERSE_DESC',
}


def entity_book_units(conn, keyword):
    """이름이 `keyword` 에 걸리는 용어들이 붙은 **도서 편** 번호 집합.

    ★ 2026-09-01 통합 수술 — 도서 편 라벨(복음·그리스도·성령 등)이 태그에서
      용어로 흡수돼 `BUNT_ENTI` 로 산다. 도서 태그 검색이 이 문을 부른다 —
      화면이 SQL 을 쓰면 래칫(`db_overlay_audit`)에 걸린다.
    """
    out = set()
    kw = '%' + (keyword or '').lower() + '%'
    try:
        for eid, in conn.execute(
                "SELECT em.entity_id FROM sys_entity_master em"
                " JOIN sys_text_asset t ON t.text_type='ENTITY_NAME'"
                "  AND t.clicked_id=em.entity_id"
                " WHERE COALESCE(em.record_status,'LIVE')='LIVE'"
                "   AND COALESCE(t.record_status,'LIVE')='LIVE'"
                "   AND LOWER(t.contents) LIKE ?", (kw,)):
            for tbl in ('sys_link_asset', 'userdb.user_link_asset'):
                out.update(r[0] for r in conn.execute(
                    "SELECT clicked_id FROM %s WHERE link_type='BUNT_ENTI'"
                    " AND target_id=? AND COALESCE(record_status,'LIVE')"
                    "='LIVE'" % tbl, (eid,)))
    except Exception as e:
        print('[entity_book_units] %s' % e)
    return out


def user_verse_entity_marks(conn, vid, lang='KO'):
    """**개인 표**의 용어↔구절 연결 → [(entity_id, 이름)].

    ★ 2026-09-01 통합 수술 — 사용자가 붙였던 태그(시험 데이터 포함)는 지우지
      않고 **용어 연결로 재지향**해 개인 표에 남겼다(사용자 지시 「제거할 생각은
      하지 마라. 표시방법을 정하면 된다」). 티커가 이 문으로 그것을 읽는다 —
      안 읽으면 「저장은 되는데 안 보인다」가 재현된다.
    """
    out = []
    try:
        for eid, in conn.execute(
                "SELECT DISTINCT clicked_id FROM userdb.user_link_asset"
                " WHERE link_type='ENTI_VERS'"
                "   AND ? BETWEEN target_id AND COALESCE(end_id, target_id)"
                "   AND COALESCE(record_status,'LIVE')='LIVE'", (vid,)):
            r = conn.execute(
                "SELECT contents FROM sys_text_asset WHERE text_type="
                "'ENTITY_NAME' AND clicked_id=? AND COALESCE(record_status,"
                "'LIVE')='LIVE' ORDER BY CASE UPPER(lang_code)"
                " WHEN UPPER(?) THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                (eid, lang or 'KO')).fetchone()
            if r and (r[0] or '').strip():
                out.append((eid, r[0].strip()))
    except Exception as e:
        print('[user_verse_entity_marks] %s' % e)
    return out


def peri_link_for(conn, entity_id, vid):
    """그 절을 덮는 **단락 연결** → (링크 PK, 시작 vid, 끝 vid). 없으면 None.

    ★ 2026-09-01 — 주요용어 화면이 「이 절과의 연결 설명문」을 찾을 때 쓴다.
      절 연결이 없어도 **단락으로 이어 둔 것**이 있으면 그 글이 그 절의 설명이다.
    ⚠ **화면이 연결 SQL 을 쓰지 않는다** — 연결을 아는 곳은 여기다
      (`db_overlay_audit` 래칫이 화면 쪽 직접 읽기를 막는다).
    """
    try:
        return conn.execute(
            "SELECT l.sys_link_id, pa.start_vid, pa.end_vid"
            "  FROM sys_link_asset l"
            "  JOIN sys_pericope_asset pa ON pa.pericope_id=l.target_id"
            " WHERE l.link_type='ENTI_PERI' AND l.clicked_id=?"
            "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
            "   AND COALESCE(pa.record_status,'LIVE')='LIVE'"
            "   AND ? BETWEEN pa.start_vid AND pa.end_vid"
            " LIMIT 1", (entity_id, vid)).fetchone()
    except Exception as e:
        print('[peri_link_for] %s' % e)
        return None


def verse_link_for(conn, entity_id, vid, rel='THEMATIC'):
    """그 절(또는 그 절을 덮는 구간)의 **절 연결** → (PK, 시작, 끝). 없으면 None."""
    try:
        q = ("SELECT l.sys_link_id, l.target_id, l.end_id FROM sys_link_asset l"
             " WHERE l.link_type='ENTI_VERS' AND l.clicked_id=?"
             "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
             "   AND ? BETWEEN l.target_id AND COALESCE(l.end_id, l.target_id)")
        args = (entity_id, vid)
        if rel:
            q += " AND l.rel_code=?"
            args += (rel,)
        return conn.execute(q + " LIMIT 1", args).fetchone()
    except Exception as e:
        print('[verse_link_for] %s' % e)
        return None


def link_desc_type(one, two):
    """이 짝의 연결설명문 유형. 자리가 없으면 None."""
    a_k, _a_i, _a_e, b_k, _b_i, _b_e = pair(one, two)
    return LINK_DESC_TYPE.get(_lt(a_k, b_k))


def _link_row(conn, one, two, scope='USER', rel=None):
    """그 짝의 연결 행 → (범위, PK). 없으면 (None, None).

    ⚠ **사용자 범위에서는 배포 연결이 먼저**다 — 배포 연결에 설명을 달면
      그것은 덮개이고, 내 연결이면 내 글이다. 두 규칙이 갈리므로 어느
      쪽인지부터 가린다.
    """
    a_k, a_i, _a_e, b_k, b_i, b_e = pair(one, two)
    lt = _lt(a_k, b_k)
    # ⚠⚠ **관점을 안 주면 관점을 가리지 않는다** (2026-09-01 실측으로 잡았다).
    #   `add`/`remove` 는 `rel or ''` 로 **관점 없는 행만** 다루는데, 그 규칙을
    #   여기 그대로 쓰면 `rel_code='ILLUSTRATION'` 같은 실데이터를 못 찾는다
    #   (단락 연결 1,621건 중 **관점 없는 것이 1건**뿐이다).
    #   ⇒ 읽고 쓰는 쪽은 「이 두 자산의 연결」을 찾는 것이므로 `rel=None` 이면
    #     아무 관점이나 잡는다. 관점을 지목하려면 그 값을 준다.
    where = ("WHERE link_type=? AND clicked_id=? AND target_id=? "
             "  AND COALESCE(end_id,-1)=? "
             "  AND COALESCE(record_status,'LIVE')='LIVE'")
    args = (lt, a_i, b_i, b_e if b_e else -1)
    if rel is not None:
        where += " AND COALESCE(rel_code,'')=?"
        args += (rel or '',)
    order = ('SYS', 'USER') if scope == 'USER' else ('SYS',)
    for sc in order:
        try:
            _pk = 'sys_link_id' if sc == 'SYS' else 'user_link_id'
            r = conn.execute("SELECT %s FROM %s %s LIMIT 1"
                             % (_pk, tbl(sc), where), args).fetchone()
        except Exception as e:
            print('[_link_row %s] %s' % (sc, e))
            continue
        if r:
            return sc, r[0]
    return None, None


def link_desc(conn, one, two, lang='KO', scope='USER', rel=None):
    """그 짝의 **연결설명문** → (글, 상태).

    상태 = `SYS`(배포 글 그대로) · `EDIT`(내가 고쳤다) · `NEW`(내 연결의 내 글)
          · `NONE`(없다) · `NOLINK`(아직 안 이었다) · `NOSLOT`(자리가 없는 짝).

    ⚠ **가림은 언어 폴백을 이긴다**(§88차) — 가렸는데 영어가 튀어나오면 안 된다.
    """
    tt = link_desc_type(one, two)
    if not tt:
        return '', 'NOSLOT'
    sc, lid = _link_row(conn, one, two, scope, rel)
    if not lid:
        return '', 'NOLINK'
    lg0 = (lang or 'KO').upper()
    order = [lg0] + [x for x in ('EN', 'KO') if x != lg0]
    if sc == 'SYS':
        import overlay as _ov
        for lg in order:
            if scope == 'USER':
                got = _ov.text_override(conn, tt, lid, lg, None)
                if got is not None:
                    st, body = got
                    if st == 'HIDE' or body is None:
                        return '', 'NONE'          # 가림 — 폴백 금지
                    return (body[1] or ''), 'EDIT'
            r = conn.execute(
                "SELECT contents FROM sys_text_asset WHERE text_type=?"
                "  AND clicked_id=? AND UPPER(lang_code)=?"
                "  AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
                (tt, lid, lg)).fetchone()
            if r and (r[0] or '').strip():
                return r[0], 'SYS'
        return '', 'NONE'
    for lg in order:
        r = conn.execute(
            "SELECT contents FROM userdb.user_text_asset WHERE text_type=?"
            "  AND clicked_id=? AND UPPER(lang_code)=?"
            "  AND COALESCE(record_status,'LIVE')<>'HIDE' LIMIT 1",
            (tt, lid, lg)).fetchone()
        if r and (r[0] or '').strip():
            return r[0], 'NEW'
    return '', 'NONE'


def save_link_desc(conn, one, two, lang, text, scope='USER', rel=None):
    """연결설명문 저장. **빈 글 = 내 것 걷어내기**(배포 글이 되살아난다).

    ⚠ 관리자(SYS)는 배포 표에 바로 쓴다 · 사용자는 배포 연결이면 **덮개**,
      내 연결이면 내 글. `verse_link_edit` 가 구절연결에서 쓰던 규칙 그대로다.
    """
    tt = link_desc_type(one, two)
    if not tt:
        return 'NOSLOT'
    sc, lid = _link_row(conn, one, two, scope, rel)
    if not lid:
        return 'NOLINK'
    lg = (lang or 'KO').upper()
    text = (text or '').strip()
    if sc == 'SYS' and scope == 'SYS':
        if not text:
            conn.execute("DELETE FROM sys_text_asset WHERE text_type=?"
                         " AND clicked_id=? AND UPPER(lang_code)=?",
                         (tt, lid, lg))
            conn.commit()
            return 'NONE'
        n = conn.execute(
            "UPDATE sys_text_asset SET contents=?,"
            " record_status='LIVE' WHERE text_type=? AND clicked_id=?"
            " AND UPPER(lang_code)=?", (text, tt, lid, lg)).rowcount
        if not n:
            conn.execute(
                "INSERT INTO sys_text_asset"
                "(text_type,clicked_id,contents,lang_code,record_status)"
                " VALUES(?,?,?,?,'LIVE')", (tt, lid, text, lg))
        conn.commit()
        return 'SYS'
    if sc == 'SYS':
        import overlay as _ov
        ad = _ov.TextOverlay(tt)
        trow = {'text_type': tt, 'clicked_id': lid, 'target_id': None,
                'title': None, 'contents': text, 'lang_code': lg,
                'text_variant': None}
        if not text:
            _ov.revert(conn, ad, trow)
            return 'SYS'
        _ov.save(conn, ad, trow)
        return 'EDIT'
    if not text:
        conn.execute("DELETE FROM userdb.user_text_asset WHERE text_type=?"
                     " AND clicked_id=? AND UPPER(lang_code)=?",
                     (tt, lid, lg))
        conn.commit()
        return 'NONE'
    n = conn.execute(
        "UPDATE userdb.user_text_asset SET contents=?, record_status='EDIT'"
        " WHERE text_type=? AND clicked_id=? AND UPPER(lang_code)=?",
        (text, tt, lid, lg)).rowcount
    if not n:
        conn.execute(
            "INSERT INTO userdb.user_text_asset"
            "(text_type,clicked_id,contents,lang_code,record_status)"
            " VALUES(?,?,?,?,'NEW')", (tt, lid, text, lg))
    conn.commit()
    return 'NEW'


def _media_text(row):
    """영상·링크 한 자산을 **읽을 수 있는 글**로.

    ⚠ `description` 은 수집기가 넣은 **JSON 덩어리**다(`{"channel": …}`).
      그대로 그리면 사용자에게 아무 뜻이 없다 — 풀어서 적는다.
    """
    import json as _j
    title, desc, url = (row[0] or ''), (row[1] or ''), (row[2] or '')
    out = [title] if title else []
    d = None
    if desc.strip().startswith('{'):
        try:
            d = _j.loads(desc)
        except Exception:
            d = None
    if isinstance(d, dict):
        for key, lab in (('channel', '채널'), ('published', '올린 날')):
            if d.get(key):
                out.append('%s: %s' % (lab, d[key]))
    elif desc.strip():
        out.append(desc.strip())
    if url:
        out.append(url)
    return chr(10).join(out)


def _tag_facts(conn, kind, tid, lang='KO'):
    """태그 한 개의 **사실** — 축과 붙어 있는 곳 수. 설명문이 아니다."""
    try:
        import tag_picker as _tp
        nm = ax = ''
        for src, i, n, a, *_ in _tp.all_tags(None, lang):
            if i == tid and ((src == 'USER') == (kind == 'UTAG')):
                nm, ax = n, (a or '')
                break
        head = 'TAG' if kind == 'TAG' else 'UTAG'
        n = conn.execute(
            "SELECT COUNT(*) FROM %s WHERE link_type LIKE ? "
            "  AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'"
            % tbl('SYS' if kind == 'TAG' else 'USER'),
            (head + '\\_%', tid)).fetchone()[0]
        line = []
        if ax:
            line.append('축: %s' % ax)
        line.append('이 태그가 붙은 곳: %d군데' % n)
        return (nm + chr(10) if nm else '') + ' · '.join(line)
    except Exception as e:
        print('[_tag_facts] %s' % e)
        return ''


def _peri_text(conn, pid, lang='KO'):
    """구절단락 — 제목 · 범위 · 단락 설명문."""
    r = conn.execute('SELECT start_vid, end_vid FROM sys_pericope_asset '
                     ' WHERE pericope_id=?', (pid,)).fetchone()
    out = []
    t = conn.execute(
        "SELECT contents FROM sys_text_asset WHERE text_type='PERI_TITLE'"
        "  AND clicked_id=? AND TRIM(COALESCE(contents,''))<>'' "
        " ORDER BY CASE UPPER(lang_code) WHEN UPPER(?) THEN 0 "
        "          WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
        (pid, lang)).fetchone()
    if t and t[0]:
        out.append(t[0])
    if r:
        out.append(scope_label(conn, r[0], r[1], lang) or '')
    d = conn.execute(
        "SELECT contents FROM sys_text_asset WHERE text_type='PERI_DESC'"
        "  AND clicked_id=? AND TRIM(COALESCE(contents,''))<>'' "
        " ORDER BY CASE UPPER(lang_code) WHEN UPPER(?) THEN 0 "
        "          WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
        (pid, lang)).fetchone()
    if d and d[0]:
        out.append('')
        out.append(d[0])
    return chr(10).join(x for x in out if x is not None).strip()


def desc_of(conn, kind, tid, lang='KO'):
    """후보 자산의 **설명문** — 없으면 빈 글(사용자 확정 「설명문이 없으면 공란」).

    ★ 0.연결팝업.txt 1절 — 「목록을 클릭하면 중간 화면에 설명문 표시」.
    ⚠ 종류마다 설명문의 집이 다르다 — 최선을 다해 찾고 못 찾으면 조용히 비운다
      (여기서 오류를 내면 클릭할 때마다 상자가 뜬다).
    """
    kind = str(kind).upper()
    try:
        if kind in ('LENS', 'NODE'):
            tt = 'CONT_DESC' if kind == 'LENS' else 'NODE_DESC'
            r = conn.execute(
                "SELECT contents FROM sys_text_asset WHERE text_type=? "
                " AND clicked_id=? AND TRIM(COALESCE(contents,''))<>'' "
                " ORDER BY CASE UPPER(lang_code) WHEN UPPER(?) THEN 0 "
                "          WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                (tt, tid, lang)).fetchone()
            return (r and r[0]) or ''
        if kind == 'PLAN':
            r = conn.execute(
                "SELECT contents FROM sys_text_asset WHERE text_type='PLAN_DESC'"
                " AND clicked_id=? AND TRIM(COALESCE(contents,''))<>'' "
                " ORDER BY CASE UPPER(lang_code) WHEN UPPER(?) THEN 0 "
                "          WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                (tid, lang)).fetchone()
            return (r and r[0]) or ''
        if kind == 'CHAIN':
            return chain_preview_text(conn, tid, lang)
        # ★★★ **용어·태그·단락·내 자산이 통째로 비어 있었다** (2026-09-01
        #   사용자 신고 — 「삼위일체를 선택했는데도 설명문이 없다. **가운데
        #   화면이 제대로 표시되지 않는 것들이 대부분이다**」).
        #   실측이 그 말을 받쳤다 — 16종 중 **7종이 아무것도 안 그렸다**
        #   (ENTITY·TAG·UTAG·PERICOPE·USER_REF·NOTE·ULENS·UNODE).
        #   ⚠ 가운데 칸은 **「고르기 → 확인 → 연결」의 확인 자리**다. 확인할
        #     것이 없으면 그 칸이 하는 일이 없어진다.
        if kind == 'ENTITY':
            r = conn.execute(
                "SELECT contents FROM sys_text_asset "
                " WHERE text_type='ENTITY_DESC' AND clicked_id=? "
                "   AND TRIM(COALESCE(contents,''))<>'' "
                "   AND COALESCE(record_status,'LIVE')='LIVE' "
                " ORDER BY CASE UPPER(lang_code) WHEN UPPER(?) THEN 0 "
                "          WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                (tid, lang)).fetchone()
            return (r and r[0]) or ''
        if kind in ('TAG', 'UTAG'):
            # ⚠ **태그에는 설명문 자리가 없다** — 지어내지 않는다(§0-1b).
            #   대신 **사실**을 적는다: 어느 축이고 어디에 몇 군데 붙어 있나.
            #   그것이 「이 태그가 맞나」를 가리는 데 실제로 쓰인다.
            return _tag_facts(conn, kind, tid, lang)
        if kind == 'PERICOPE':
            return _peri_text(conn, tid, lang)
        if kind == 'USER_REF':
            r = conn.execute(
                "SELECT body_text FROM userdb.user_ref_text WHERE ref_id=? "
                " AND TRIM(COALESCE(body_text,''))<>'' "
                " AND COALESCE(record_status,'LIVE')<>'HIDE' "
                " ORDER BY CASE UPPER(lang_code) WHEN UPPER(?) THEN 0 "
                "          WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                (tid, lang)).fetchone()
            if r and r[0]:
                return r[0]
            r = conn.execute('SELECT summary FROM userdb.user_ref_asset '
                             ' WHERE ref_id=?', (tid,)).fetchone()
            return (r and r[0]) or ''
        if kind == 'NOTE':
            r = conn.execute(
                'SELECT contents FROM userdb.user_text_asset '
                ' WHERE user_text_id=?', (tid,)).fetchone()
            return (r and r[0]) or ''
        if kind in ('ULENS', 'UNODE'):
            tt = 'CONT_DESC' if kind == 'ULENS' else 'NODE_DESC'
            r = conn.execute(
                "SELECT contents FROM userdb.user_text_asset "
                " WHERE text_type=? AND clicked_id=? "
                "   AND TRIM(COALESCE(contents,''))<>'' "
                "   AND COALESCE(record_status,'LIVE')<>'HIDE' "
                " ORDER BY CASE UPPER(lang_code) WHEN UPPER(?) THEN 0 "
                "          WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                (tt, tid, lang)).fetchone()
            return (r and r[0]) or ''
        if kind == 'MEDIA':
            r = conn.execute('SELECT title, description, url '
                             ' FROM sys_media_asset WHERE media_id=?',
                             (tid,)).fetchone()
            if not r:
                return ''
            return _media_text(r)
        if kind == 'UMEDIA':
            r = conn.execute('SELECT title, description, url '
                             '  FROM userdb.user_media_asset'
                             # status-ok: 번호 하나로 그 줄을 읽는 자리 —
                             #   고를 것이 하나뿐이라 상태가 가르는 것이 없다
                             ' WHERE user_media_id=?', (tid,)).fetchone()
            return _media_text(r) if r else ''
        if kind == 'REF_UNIT':
            r = conn.execute(
                "SELECT body_text FROM sys_ref_text WHERE ref_unit_id=? "
                " AND TRIM(COALESCE(body_text,''))<>'' "
                " ORDER BY CASE UPPER(lang_code) WHEN UPPER(?) THEN 0 "
                "          WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                (tid, lang)).fetchone()
            if r and r[0]:
                return r[0]
            r = conn.execute('SELECT unit_answer FROM sys_ref_unit '
                             ' WHERE ref_unit_id=?', (tid,)).fetchone()
            return (r and r[0]) or ''
        if kind == 'BOOK':
            r = conn.execute('SELECT description FROM sys_book_asset '
                             ' WHERE book_id=?', (tid,)).fetchone()
            return (r and r[0]) or ''
        if kind == 'BOOK_UNIT':
            r = conn.execute(
                "SELECT body_text FROM sys_book_unit_text WHERE unit_id=? "
                " AND TRIM(COALESCE(body_text,''))<>'' LIMIT 1",
                (tid,)).fetchone()
            return (r and r[0]) or ''
    except Exception as e:
        print('[link_picker desc_of %s] %s' % (kind, e))
    return ''



def verse_preview_text(conn, sv, ev=None, lang='KO'):
    """구절 범위 → 미리보기 글 (참조 + 본문).

    ★★ 왜 (2026-08-27 사용자 지시) — 「구절/단락/말씀흐름 등을 선택했는데
      **구절 내용을 알 수 없다. 잘못 선택했어도 그냥 연결할 위험**이 있다.」
      번호만 보고 잇는 것은 눈감고 잇는 것이다.
    ⚠ 본문은 KRV → 아무 역본 폴백. 40절 넘으면 자른다고 **말한다**.
    """
    if not sv:
        return ''
    ev = ev or sv
    out = []
    rows = conn.execute(
        "SELECT bi.verse_id, bn.short_name, bi.chapter, bi.verse, "
        "  COALESCE((SELECT verse_text FROM bible_content "
        "     WHERE verse_id=bi.verse_id AND version_code='KRV'), "
        "    (SELECT verse_text FROM bible_content "
        "     WHERE verse_id=bi.verse_id LIMIT 1), '') "
        "  FROM bible_index bi "
        "  JOIN book_names bn ON bn.book_code=bi.bcode "
        "   AND UPPER(bn.lang_code)=UPPER(?) "
        " WHERE " + _vr.between_sql('bi.verse_id')
        + " ORDER BY bi.sort_order",
        [lang] + _vr.between_args(sv, ev)).fetchall()
    for _vid, bk, ch, vs, txt in rows[:PREVIEW_MAX]:
        # ★ 합쳐진 절·없는 절만 보완한다 — 정상 절은 조회 결과 그대로라
        #   조회가 한 번으로 끝난다(절마다 부르면 느리다).
        _s = (txt or '').strip()
        if _vt.classify(_s, bool(_s))[0] != _vt.OK:
            _s = _vt.resolve(conn, _vid, 'KRV', lang)['text']
        out.append('%s%d:%d  %s' % (bk, ch, vs, _s))
    if len(rows) > PREVIEW_MAX:
        out.append('… 외 %d절' % (len(rows) - PREVIEW_MAX))
    return chr(10).join(out)


def chain_preview_text(conn, chain_id, lang='KO'):
    """흐름 → 미리보기 글 (설명문 + 묶인 구절연결 짝)."""
    r = conn.execute('SELECT chain_code FROM sys_chain_master '
                     ' WHERE chain_id=?', (int(chain_id),)).fetchone()
    if not r:
        return ''
    code = r[0]
    d = conn.execute(
        "SELECT description FROM sys_chain_catalog "
        " WHERE chain_code=? AND TRIM(COALESCE(description,''))<>'' "
        " ORDER BY CASE UPPER(lang_code) WHEN UPPER(?) THEN 0 "
        "          WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1", (code, lang)).fetchone()
    out = [d[0]] if d and d[0] else []
    pairs = conn.execute(
        "SELECT clicked_id, target_id FROM sys_link_asset "
        " WHERE chain_code=? AND COALESCE(record_status,'LIVE')='LIVE' "
        " ORDER BY clicked_id LIMIT 20", (code,)).fetchall()
    if pairs:
        out.append('')
        out.append('묶인 구절연결:')
        for a, bb in pairs:
            out.append('  %s → %s' % (_verse_label(conn, a, None, lang),
                                      _verse_label(conn, bb, None, lang)))
    return chr(10).join(out)


def _build_bible(f, db_path, ok_kind, ok_id, lang, changed, enabled=True,
                 scope='USER', on_range=None):
    """구절 — **두 줄**로 늘 보인다(2026-08-21 재설계).

        구절   [책▾][장▾]:[절▾] ~ [장▾]:[절▾]  [＋ 연결]
        범위   [책] [장] [단락]

    ★ 저장은 언제나 **구절 범위 하나**다. 책·장·단락은 그 범위를 채워 주는
      입력 단추일 뿐이다.
    ⚠ 옛 [절] 단추는 없앴다 — 첫 줄 [＋ 연결] 이 똑같은 일(시작~끝)을 한다.
      같은 단추가 둘이면 어느 것이 진짜인지 알 수 없다(사용자 승인)."""
    import tkinter as tk
    from tkinter import ttk
    # ★★ **정식명을 쓴다** (2026-08-29 사용자 지시 — 「책: 창 출 레 이런 것
    #   하지 마라. **창세기.. 정식명 사용하라**」). §90차가 관리자 화면 전체에
    #   못 박은 규칙(「고르는 콤보는 정식명」)인데 이 작업대만 약명이었다.
    #   ⚠ 약명이 없는 언어도 있어 `full_name` 이 더 안전하기도 하다.
    with appdb.connect(db_path) as c:
        books = c.execute(
            "SELECT DISTINCT bi.bcode, COALESCE(bn.full_name, bn.short_name) "
            "  FROM bible_index bi "
            "  JOIN book_names bn ON bn.book_code=bi.bcode "
            "   AND UPPER(bn.lang_code)=UPPER(?) ORDER BY bi.bcode",
            (lang,)).fetchall()
    bmap = {nm: bc for bc, nm in books}
    row1 = tk.Frame(f)
    row1.pack(fill='x', pady=(0, 2))
    _lbl(row1, _t('LP_K_VERSE', '구절')).pack(side='left')
    # ⚠ 정식명은 길다(「데살로니가전서」 7자) — 폭을 넓히지 않으면 잘린다.
    cb_b = ttk.Combobox(row1, values=[nm for _c, nm in books], width=13,
                        state='readonly')
    cb_c = ttk.Combobox(row1, width=5, state='readonly')
    cb_v = ttk.Combobox(row1, width=5, state='readonly')
    cb_c2 = ttk.Combobox(row1, width=5, state='readonly')
    cb_v2 = ttk.Combobox(row1, width=5, state='readonly')
    for w in (cb_b, cb_c, cb_v):
        w.pack(side='left', padx=(0, 3))
    tk.Label(row1, text='~').pack(side='left', padx=3)
    for w in (cb_c2, cb_v2):
        w.pack(side='left', padx=(0, 3))

    def bcode():
        return bmap.get(cb_b.get())

    def fill_vs(*_a):
        """절 목록 채우기.

        ★★ **끝 칸은 비워 둔다** (2026-08-29 사용자 지시 — 「보통은 구절이므로
          **구절 하나만** 표시하는 것이 기본이다. 범위를 선택하려면 추가로
          구간종료를 입력하면 되고 아니면 **텅빈 값**이어야 한다」).
          그전에는 끝 절을 그 장의 **마지막 절**로 박아 두어, 창1:1 을 고르면
          늘 창1:1~1:31 이 됐다. 게다가 시작 장을 바꿔도 끝은 안 따라갔다.
        ⚠ 값 목록 맨 앞에 빈 칸을 둔다 — 한 번 고른 뒤 **다시 비울 길**이 있어야 한다.
        """
        b = bcode()
        try:
            ch = int(cb_c.get())
        except Exception:
            ch = None
        if ch is not None:
            with appdb.connect(db_path) as c:
                vs = [r[0] for r in c.execute(
                    "SELECT verse FROM bible_index WHERE bcode=? AND chapter=? "
                    "ORDER BY verse", (b, ch))]
            cb_v['values'] = vs
            if vs and (cb_v.get() or '') not in [str(x) for x in vs]:
                cb_v.set(vs[0])
        # ── 끝 칸 ── 골랐을 때만 목록을 채운다. 기본은 빈 값.
        try:
            ch2 = int(cb_c2.get())
        except Exception:
            cb_v2['values'] = ['']
            cb_v2.set('')
            return
        with appdb.connect(db_path) as c:
            vs2 = [r[0] for r in c.execute(
                "SELECT verse FROM bible_index WHERE bcode=? AND chapter=? "
                "ORDER BY verse", (b, ch2))]
        cb_v2['values'] = [''] + vs2
        if (cb_v2.get() or '') not in [''] + [str(x) for x in vs2]:
            cb_v2.set('')

    def fill_ch(*_a):
        b = bcode()
        if not b:
            return
        with appdb.connect(db_path) as c:
            chs = [r[0] for r in c.execute(
                "SELECT DISTINCT chapter FROM bible_index WHERE bcode=? "
                "ORDER BY chapter", (b,))]
        cb_c['values'] = chs
        # ⚠ 끝 장은 **빈 칸을 먼저** — 기본은 단일 구절이다(2026-08-29).
        cb_c2['values'] = [''] + list(chs)
        if chs:
            cb_c.set(chs[0])
        cb_c2.set('')                     # 책을 바꾸면 끝 범위는 비운다
        fill_vs()

    def _start_changed(*_a):
        """★ **시작을 바꾸면 끝을 비운다** (2026-08-29 사용자 지시 —
        「창1장을 창2장으로 바꾸면 끝나는 콤보도 자동으로 바뀌어야 한다.
          지금은 무조건 창1:1~창1:31 로 세팅되어 있다. 불편하다」).
        비우는 쪽을 골랐다 — 끝을 시작에 맞춰 채우면 **늘 범위**가 되어
        「보통은 구절 하나」라는 기본이 깨진다."""
        cb_c2.set('')
        cb_v2.set('')
        fill_vs()
    cb_b.bind('<<ComboboxSelected>>', fill_ch)
    cb_c.bind('<<ComboboxSelected>>', _start_changed)
    cb_c2.bind('<<ComboboxSelected>>', fill_vs)
    bind_end_autofill(cb_c, cb_c2, cb_v2, fill_vs)
    if books:
        cb_b.set(books[0][1])
        fill_ch()

    def vid(ch_cb, v_cb):
        try:
            with appdb.connect(db_path) as c:
                r = c.execute(
                    "SELECT verse_id FROM bible_index WHERE bcode=? "
                    "AND chapter=? AND verse=?",
                    (bcode(), int(ch_cb.get()), int(v_cb.get()))).fetchone()
            return r[0] if r else None
        except Exception:
            return None

    def rng_of(fn, *a):
        with appdb.connect(db_path) as c:
            return fn(c, *a)

    def put(rng):
        # ★★ **잇지 않는다 — 찾는다** (0.연결팝업.txt — 「[＋연결] 을 [찾기]로.
        #   연결하기 전에 열어보고 나서 문제없을 때 연결해야 한다」).
        #   범위를 가운데 확인 칸에 싣고 후보로 담는 것까지가 이 단추의 일이고,
        #   잇는 것은 [연결] 단추 하나뿐이다.
        if rng and callable(on_range):
            on_range(rng)

    def _cur_range():
        a, b2 = vid(cb_c, cb_v), vid(cb_c2, cb_v2)
        if not a:
            return None
        return (a, b2 if (b2 and b2 > a) else a)

    def _show_prev(*_a):
        # 콤보만 바꿔도 곧 확인 칸에 실린다 — [찾기]는 같은 일을 명시적으로.
        if callable(on_range):
            on_range(_cur_range())

    for _w in (cb_b, cb_c, cb_v, cb_c2, cb_v2):
        _w.bind('<<ComboboxSelected>>', _show_prev, add='+')

    def put_verse():
        a, b = vid(cb_c, cb_v), vid(cb_c2, cb_v2)
        if a:
            put((a, b if (b and b > a) else a))
    b_add = tk.Button(row1, text=_t('LP_FIND', '찾기'), bd=1,
                      padx=12, pady=3, cursor='hand2', command=put_verse)
    b_add.pack(side='left', padx=(6, 0))

    # ★★★ **좁으면 콤보를 줄인다 — [찾기]는 절대 안 줄인다**(2026-09-22).
    #   실측 이 줄이 **필요 484px / 자리 439px** 라 맨 뒤 `[찾기]` 가 **1px**
    #   로 눌렸다(여섯 화면 공통 — 말씀흐름·구절단락·도서·설교집·교리문답·사전).
    #   ⚠ 뒤엣것을 접는 방법은 여기서 못 쓴다 — **[찾기]가 이 줄의 주 동작**
    #     이라 그것이 메뉴로 숨으면 화면이 쓸모를 잃는다. ⇒ **콤보를 줄인다**
    #     (§237차 ㊶ `_fit_corner` 가 쓴 방식 그대로).
    #   ⚠⚠ **바뀔 때만 적는다** — 무조건 적으면 `<Configure>` 가 또 나서
    #     **끝없는 idle 고리**가 된다(§256차 ⑰ 에서 앱이 통째로 멎던 자리).
    #   ⚠ 기하가 가라앉은 뒤 40ms 에 잰다(§256차 ② — 그 순간에 재면 옛 폭이다).
    _FIND_STEPS = ((14, 5), (11, 4), (9, 4), (8, 3), (6, 3), (5, 2), (4, 2))
    _fw = {'i': None, 'job': None, 'busy': False, 'room': -1}

    def _fit_find_now():
        _fw['job'] = None
        if _fw['busy']:
            return
        _fw['busy'] = True
        try:
            _fit_find_body()
        finally:
            _fw['busy'] = False       # ⚠ 즉시 — 위와 같은 까닭

    def _fit_find_body():
        try:
            row1.update_idletasks()
            room = row1.winfo_width()
        except Exception:
            return
        if room < 60:
            return
        #  ⚠⚠⚠ **여기서 update_idletasks() 를 부르면 안 된다** — 그것이
        #    그 자리에서 <Configure> 를 처리하고, 거기서 또 after(40) 이
        #    예약되어 **창이 영영 안 닫힌다**(실측 selftest 가 200초를 넘겼다).
        #    요구 크기는 배치와 무관하므로 configure 뒤 바로 읽어도 참이다.
        #  ⚠ padx 는 reqwidth 에 안 들어간다 — 여유를 넉넉히 둔다
        #    (처음에 +2 만 두었다가 [찾기] 가 44px 로 11px 모자랐다).
        want = None
        for i, (bw, sw) in enumerate(_FIND_STEPS):
            cb_b.configure(width=bw)
            for _c in (cb_c, cb_v, cb_c2, cb_v2):
                _c.configure(width=sw)
            need = sum(w.winfo_reqwidth() + 8 for w in row1.winfo_children())
            if need <= room - 8:
                want = i
                break
        if want is None:
            want = len(_FIND_STEPS) - 1
        if _fw['i'] == want:
            return                       # ★ **바뀔 때만**
        _fw['i'] = want
        bw, sw = _FIND_STEPS[want]
        cb_b.configure(width=bw)
        for _c in (cb_c, cb_v, cb_c2, cb_v2):
            _c.configure(width=sw)

    def _fit_find(*_a):
        if _fw['busy']:
            return            # ⚠ 재는 동안 제 이벤트를 안 받는다
        # ★★★ **폭이 그대로면 아무 일도 안 한다**(위와 같은 까닭)
        try:
            _r = row1.winfo_width()
        except Exception:
            return
        if _r == _fw['room']:
            return
        _fw['room'] = _r
        if _fw['job']:
            try:
                row1.after_cancel(_fw['job'])
            except Exception:
                pass
        _fw['job'] = row1.after(40, _fit_find_now)

    row1.bind('<Configure>', _fit_find, add='+')

    row2 = tk.Frame(f)
    row2.pack(fill='x', pady=(0, 6))
    _lbl(row2, _t('LP_RANGE', '범위')).pack(side='left')
    b_bk = tk.Button(row2, text=_t('LP_R_BOOK', '책'), bd=1,
                     padx=12, pady=3, cursor='hand2',
                     command=lambda: put(rng_of(book_range, bcode())))
    b_bk.pack(side='left')
    b_ch = tk.Button(row2, text=_t('LP_R_CHAP', '장'), bd=1,
                     padx=12, pady=3, cursor='hand2',
                     command=lambda: put(rng_of(chapter_range, bcode(),
                                                int(cb_c.get() or 1))))
    b_ch.pack(side='left', padx=(3, 0))
    # ⚠ **연결대상의 「단락」과 다른 것이다** (2026-08-29 사용자 물음).
    #   여기 [이 절의 단락] = 그 절이 속한 단락의 **구절 범위**를 채운다
    #     → 저장은 `VERS_*`(구절 범위 연결).
    #   연결대상 [단락] = **단락 자산 그 자체**를 잇는다 → `PERI_*`.
    #   이름이 같아 헷갈렸다 — 여기를 「이 절의 단락」으로 바꾼다.
    b_pe = tk.Button(row2, text=_t('LP_R_PERI', '이 절의 단락'), bd=1,
                     padx=12, pady=3, cursor='hand2',
                     command=lambda: put(rng_of(peri_range, vid(cb_c, cb_v))))
    b_pe.pack(side='left', padx=(3, 0))

    # ★★ **[지금 보는 절로]** — My Edit 상단 선택기에만 있던 기능을 여기로
    #   옮겼다 (2026-08-29 최상단 제거와 짝). 앱에서 지금 읽고 있는 절을
    #   그대로 담는다 — 이것 하나 때문에 상단을 남길 이유가 없어야 한다.
    #   ⚠ 앱 창이 아닌 데서 열리면(하네스·독립 창) 조용히 잠근다.
    def _to_current():
        root = f.winfo_toplevel()
        cur = (getattr(root, 'active_node_id', None)
               or getattr(root, '_p1_verse_id', None))
        if cur is None:
            for _w in (getattr(root, 'master', None), getattr(root, '_root',
                                                              lambda: None)()):
                cur = (getattr(_w, 'active_node_id', None)
                       or getattr(_w, '_p1_verse_id', None))
                if cur:
                    break
        if not cur:
            from tkinter import messagebox
            messagebox.showinfo(
                _t('OC_TO_CURRENT', '지금 보는 절로'),
                '앱에서 보고 있는 절을 찾지 못했습니다.', parent=f)
            return
        try:
            vid = int(str(cur).split(':')[-1].split('_')[0])
        except Exception:
            return
        put((vid, vid))
    tk.Button(row2, text=_t('OC_TO_CURRENT', '지금 보는 절로'), bd=1,
              padx=10, pady=3, cursor='hand2',
              command=_to_current).pack(side='left', padx=(10, 0))

    if not enabled:                 # 자기 자신은 못 잇는다
        for w in (cb_b, cb_c, cb_v, cb_c2, cb_v2):
            w.config(state='disabled')
        for w in (b_add, b_bk, b_ch, b_pe):
            w.config(state='disabled')



# ⚠ 옛 `_build_chain`(흐름 콤보 줄)은 없앴다 (2026-08-27 · 0.연결팝업.txt —
#   「중복이다 제거하라. 네가 연결대상 콤보에 넣어버렸다」). 흐름과 잇는 것은
#   연결대상 ▸ 말씀의 흐름(자산 연결)이고, **멤버십 달기**(구절연결에
#   chain_code — §28-3)는 「구속사 흐름 관리」 화면의 몫이다.


def _build_tag(f, win, db_path, ok_kind, ok_id, lang, changed, enabled=True,
               scope='USER'):
    """태그 — **한 줄**. `tag_picker` 의 선택하기 창을 그대로 부른다(저장소 불변).

        태그   [태그 고르기…]   태그는 주요용어를 함께 품습니다."""
    import tkinter as tk
    row = tk.Frame(f)
    row.pack(fill='x', pady=(0, 6))
    _lbl(row, _t('LP_K_TAG', '태그')).pack(side='left')

    def open_tags():
        import tag_picker
        cur = {(s, t) for s, t, _n, _c
               in tag_picker.tags_of(db_path, ok_kind, ok_id, lang, scope=scope)}
        got = tag_picker.pick(win, db_path, cur, lang, mode='EDIT', scope=scope)
        if got is not None:
            tag_picker.save_links(db_path, ok_kind, ok_id, got, scope=scope)
            changed()
    b = tk.Button(row, text=_t('LP_TAG_OPEN', '태그 선택하기…'),
                  bd=1, padx=12, pady=3, cursor='hand2', command=open_tags)
    b.pack(side='left')
    tk.Label(row, text=(_t('LP_TAG_HINT', '태그는 주요용어(엔티티)를 함께 품습니다.')
                        + ('   ·  배포될 태그입니다(내가 만든 태그는 안 보입니다)'
                           if not cap(scope, 'merge_user_tags') else '')),
             anchor='w').pack(side='left', padx=(10, 0))
    if not enabled:
        b.config(state='disabled')


def _build_assets(f, db_path, ok_kind, ok_id, lang, changed, own_branch,
                  scope='USER', on_pick=None, on_open_asset=None,
                  on_create=None, on_anchor_pick=None, pick_kind=None,
                  pick_label=None, auto_create=False,
                  on_edit_asset=None, on_hide_asset=None):
    """연결대상 — **렌즈묵상·도서·설교·교리자료·연구자료가 목록 한 칸을
    나눠 쓴다** (2026-08-21 사용자 지시).

        연결대상  [렌즈묵상▾] [검색어____] [검색]
        ┌ 목록 ──────────────────────┐
        └────────────────────────────┘
                              [＋ 연결]

    ★ 종류를 바꾸면 **그 자리에서 목록 내용만** 바뀐다 — 칸이 늘거나 줄지
      않으므로 창 크기가 흔들리지 않는다(그전에는 갈래마다 다른 칸이 떴다).
    ★ **자기 종류는 콤보에 없다** — 자기 자신을 잇지 못한다.
      잠긴 단추 대신 아예 안 보이는 쪽이 「고장」으로 안 읽힌다."""
    import tkinter as tk
    from tkinter import ttk
    # 성경·태그는 위에 늘 보이므로 여기 콤보에 넣지 않는다.
    # ⚠⚠ **범위로 거른다** — 관리자 전용 갈래가 사용자 창에 새지 않게.
    # ⚠⚠ **자기 갈래를 통째로 빼지 않는다** (2026-08-27 사용자 신고 「연결대상
    #   콤보: **도서, 설교가 사라졌다**」). 도서 화면에서 열면 own_branch='book'
    #   이라 도서·설교 갈래가 통째로 빠졌는데, 도서↔다른 도서·도서↔도서 편
    #   연결은 **뜻이 있다**(BOOK_PLAN·BOOK_CONT 가 이미 있다). 자기 **자신**만
    #   막으면 된다 — `put()` 이 잡아 알린다.
    _ok = set(kinds(scope))
    # ⚠ 성경만 뺀다 — 구절은 위 [찾기]·[책][장][단락] 이 맡는다.
    #   **태그는 2026-08-29 부터 목록에 있다**(항목 3-(b)).
    opts = [(b[0], _t(b[1], b[2]), tuple(k for k in b[3] if k in _ok))
            for b in BRANCHES
            if b[0] != 'bible' and (set(b[3]) & _ok)]
    # ★ 콤보 → **텍스트 버튼** (0.연결팝업.txt — 「연결대상 콤보상자 제거하고
    #   텍스트 버튼으로 교체」). 무엇을 고를 수 있는지 펼쳐 보인다.
    brow0 = tk.Frame(f)
    brow0.pack(fill='x', pady=(0, 2))
    _lbl(brow0, _t('LP_ASSET', '연결대상')).pack(side='left')
    _bsel = {'i': 0}
    _bbtns = []

    def _set_branch(i):
        _bsel['i'] = i
        for j, bb in enumerate(_bbtns):
            bb.config(relief='sunken' if j == i else 'raised')
        _sync_new_btn()
        _ax_gate()          # 축 필터는 용어 갈래의 것이다(2026-08-30)
        fill()

    # ★★ **폭이 모자라면 줄을 바꾼다** (2026-08-29 사용자 지시 — 「모든
    #   항목이 재고창고 버튼이 준비되어야 한다. **2열로 배치해도 좋다**」).
    #   갈래가 아홉이라 좁은 기둥에서는 마지막 단추가 잘려 **없는 것처럼**
    #   보였다. ①의 갈래 줄이 이미 쓰는 문법을 그대로 쓴다.
    #   ⚠ 개수로 접지 말 것 — 기둥 폭이 사시로 바뀌므로 **실제 폭**으로 잰다.
    _bwrap = tk.Frame(brow0)
    _bwrap.pack(side='left', fill='x', expand=True)
    for _i, (_k, _nm, _ks) in enumerate(opts):
        _bb = tk.Button(_bwrap, text=_nm, bd=1, padx=8, pady=2, cursor='hand2',
                        command=lambda i=_i: _set_branch(i))
        _bbtns.append(_bb)

    def _reflow_branches(_e=None):
        try:
            bw = _bwrap.winfo_width()
            if bw <= 1:
                _bwrap.after(60, _reflow_branches)
                return
            x = row_i = col = 0
            for b2 in _bbtns:
                w2 = b2.winfo_reqwidth() + 3
                if col and x + w2 > bw:
                    row_i += 1
                    x = col = 0
                b2.grid(row=row_i, column=col, padx=(0, 2), pady=1, sticky='w')
                x += w2
                col += 1
        except Exception:
            pass
    _reflow_branches()
    _bwrap.bind('<Configure>', _reflow_branches)

    # ★★★ **「태그분류」 줄 — 「연결대상」과 같은 꼴로, 항상 보인다**
    #   (2026-08-30 사용자 지시 「"연결대상" 라벨 오른쪽에 여러 자산을 표시한
    #   것처럼, **그 아래에 "태그분류"라고 라벨을 표시하고 전체/내태그 … 등등
    #   태그분류를 표시할 것**(분류라고 쓴 버튼은 제거하고 **라벨로 대체**,
    #   **태그분류가 항상 표시되도록** 할 것). 현재는 한줄이라서 안보임.
    #   **여러줄(약3줄)로** 표시할 것」).
    #   ⚠⚠ 접이 단추(`[분류 ▾]`)를 걷었다 — 한 번 더 눌러야 보이면 「없는 것」과
    #     같다. 갈래 단추와 **같은 문법**(라벨 + 실제 폭으로 접는 격자)이다.
    #   ★ 이것이 태그 고르기 팝업을 **흡수하는 마지막 조각**이다 — 팝업에만
    #     있던 축 거르기를 안 옮기면 흡수가 **기능을 줄이는 일**이 된다.
    #   ⚠ **용어 갈래에서만** 뜬다 — 다른 갈래에는 축이 없다(빈 서랍 금지).
    #   ⚠ 이 줄은 **공통 팝업의 것**이라 자료·노트 세 서브탭(묵상노트·연구자료·
    #     내부연결)이 **같은 화면을 본다**(2026-08-30 사용자 확인).
    _ax = {'code': ''}
    axrow = tk.Frame(f)          # ⚠ 여기서 pack 하지 않는다 — `_ax_gate` 가
                                 #   용어 갈래일 때만 붙인다(안 그러면 처음
                                 #   들어올 때 `_ax_build` 가 안 돈다).
    _lbl(axrow, _t('LP_H_AXIS', '태그분류')).pack(side='left', anchor='n')
    _axwrap = tk.Frame(axrow)
    _axwrap.pack(side='left', fill='x', expand=True)

    row = tk.Frame(f)
    row.pack(fill='x', pady=(0, 2))
    _slbl = _lbl(row, _t('LP_SEARCH_BTN', '검색'))
    _slbl.pack(side='left')
    q = tk.StringVar()
    ent = ttk.Entry(row, textvariable=q)
    ent.pack(side='left', padx=(4, 0), fill='x', expand=True)

    # ⚠ [＋ 연결] 줄을 **먼저** — 목록(expand) 뒤에 pack 하면 눌려 사라진다
    brow = tk.Frame(f)
    brow.pack(side='bottom', fill='x')

    lstf = tk.Frame(f)
    lstf.pack(fill='both', expand=True, pady=(2, 2))
    _tv_style(db_path, 'LinkCand.Treeview')
    # ★★ **2단 트리 + 사전 칸** (2026-08-29 사용자 지시). 칸 구성은 갈래가
    #   정한다 — 용어 갈래는 사전 자료집만큼 칸이 늘어난다(DB 에서 읽는다).
    with appdb.connect(db_path) as _c:
        _DICTS = dict_sources(_c)
    _dcols = tuple('d%d' % sid for sid, _n in _DICTS)
    tv = ttk.Treeview(lstf, columns=('n',) + _dcols, show='tree headings',
                      height=6, style='LinkCand.Treeview')
    tv.heading('#0', text=_t('LP_COL_GROUP', '묶음'))
    tv.column('#0', width=150, anchor='w', stretch=False)
    tv.heading('n', text=_t('COMMON_NAME', '이름'))
    tv.column('n', width=330, anchor='w')
    for _sid, _dn in _DICTS:
        tv.heading('d%d' % _sid, text=_dn)
        tv.column('d%d' % _sid, width=64, anchor='center', stretch=False)
    sb = ttk.Scrollbar(lstf, command=tv.yview)
    tv.configure(yscrollcommand=sb.set)
    sb.pack(side='right', fill='y')
    tv.pack(side='left', fill='both', expand=True)
    found = {}

    def kinds_now():
        i = _bsel['i']
        return opts[i][2] if 0 <= i < len(opts) else ()

    # ── 축 필터 배선 (2026-08-30) ────────────────────────────────────
    _AX_ROWS = 3               # 사용자 지시 「여러줄(약3줄)」
    _axbtns, _ax_order = {}, []

    def _ax_pick(code):
        # ⚠ [전체]는 **토글이 아니다** — 누르면 언제나 거르기가 풀린다.
        _ax['code'] = '' if (not code or _ax['code'] == code) else code
        for c2, b2 in _axbtns.items():
            b2.config(relief=('sunken' if c2 == _ax['code'] else 'raised'))
        # ★ **다른 갈래에 있으면 용어로 데려간다** (2026-08-30) — 태그분류를
        #   늘 보이게 한 짝이다. 안 옮기면 눌러도 아무 일이 없어 고장으로 읽힌다.
        if 'ENTITY' not in (kinds_now() or ()):
            for _j, (_k2, _nm2, _ks2) in enumerate(opts):
                if 'ENTITY' in _ks2:
                    _set_branch(_j)       # 그 안에서 fill() 이 돈다
                    return
        fill()

    def _ax_build():
        if _ax_order:
            return                        # 한 번만 짓는다(갈래를 오갈 때 안 다시)
        try:
            import tag_picker as _tp
            axes = _tp.axes_for(db_path, lang, only_used=True)
        except Exception:
            axes = []
        # ★ **[전체]가 맨 앞** (사용자 지시 「전체/내태그 … 등등」) — 지금 무엇도
        #   안 걸렀다는 것을 **눌린 단추 하나로** 보인다. 없으면 「거르기가 없다」와
        #   「거르기를 못 푼다」가 구분되지 않는다.
        # ⚠ 「내 태그」·「용어사전」은 축이 아니라 **출처**다 — 태그 고르기 팝업이
        #   쓰던 두 특수 필터를 그대로 옮긴다(안 옮기면 기능이 준다).
        items = ([('', _t('LP_AXIS_ALL', '전체')),
                  ('_USER_', _t('TAG_MINE', '내 태그')),
                  ('_ENTITY_', _t('TAG_ENTITY', '용어사전'))] + list(axes))
        for code, nm in items:
            b2 = tk.Button(_axwrap, text=nm, font=('', 9), bd=1,
                           relief=('sunken' if code == _ax['code'] else 'raised'),
                           padx=6, pady=0, cursor='hand2',
                           command=lambda c2=code: _ax_pick(c2))
            _ax_order.append((code, b2))
            _axbtns[code] = b2

    def _ax_reflow(_e=None):
        """실제 폭으로 재어 줄을 바꾼다 — **최대 3줄**(사용자 지시 「여러줄
        (약3줄)로 표시할 것」). 그 아래는 목록 자리다.

        ⚠ 개수로 접지 말 것 — 기둥 폭이 사시로 바뀐다(갈래 줄과 같은 문법)."""
        try:
            bw = _axwrap.winfo_width()
            if bw <= 1:
                _axwrap.after(60, _ax_reflow)
                return
            x = row_i = col = 0
            for code, b2 in _ax_order:
                w2 = b2.winfo_reqwidth() + 3
                if col and x + w2 > bw:
                    row_i += 1
                    x = col = 0
                if row_i >= _AX_ROWS:       # 3줄을 넘으면 감춘다
                    b2.grid_forget()
                    continue
                b2.grid(row=row_i, column=col, padx=(0, 2), pady=1, sticky='w')
                x += w2
                col += 1
        except Exception:
            pass

    # ⚠ **단추는 미리 짓는다** — 줄을 붙일 때 짓게 두면 「처음 들어온 갈래가
    #   용어일 때」만 지어지고, 다른 갈래로 갔다 오면 빈 줄이 뜬다.
    #   짓는 것은 공짜고(단추 스물 남짓) **보이는 것만** 갈래가 정한다.
    _ax_build()

    def _ax_gate():
        """**항상 보인다** (2026-08-30 사용자 신고 「연결팝업 화면에서 **용어
        버튼을 눌러야만 표시**되고 있는데, 용어 분류항목이 **항상 표시**되도록
        하라」).

        ⚠⚠ 그전에는 용어 갈래에서만 폈다 — 「빈 서랍 금지」를 지킨 것인데,
          사용자에게는 **없는 기능**으로 보였다. 태그를 잇는 것이 이 화면에서
          가장 잦은 일이라 늘 보이는 쪽이 맞다.
        ★ 대신 **누르면 용어 갈래로 데려간다**(`_ax_pick`) — 그래야 다른 갈래에
          있을 때 눌러도 헛돌지 않는다."""
        try:
            if not axrow.winfo_manager():
                axrow.pack(fill='x', pady=(0, 2), before=row)
                _ax_reflow()
        except Exception:
            pass
    _axwrap.bind('<Configure>', _ax_reflow)

    def fill(*_a):
        """세 모양 — **용어 한 줄** · **묶음 2단** · 평면.

        ⚠⚠ 40/80 이면 **주요용어가 「ㄱ」에서 끝난다**(2026-08-27 사용자 재신고).
          한도를 1,000 으로 둔다.
        """
        tv.delete(*tv.get_children())
        found.clear()
        ks = list(kinds_now())
        blank = tuple('' for _d in _dcols)
        with appdb.connect(db_path) as c:
            like = '%' + (q.get() or '').strip() + '%'
            # ── 용어 — **한 줄 = 한 낱말**, 사전은 칸으로 ──
            if 'ENTITY' in ks:
                # ★ 축 필터 (2026-08-30) — 태그 고르기 팝업에만 있던 것을
                #   여기로 옮겨 왔다. 안 옮기면 흡수가 **기능을 줄이는 일**이 된다.
                _code = _ax['code']
                _cat = {}
                if _code and _code not in ('_ENTITY_', '_USER_'):
                    for eid, cat in c.execute(
                            'SELECT entity_id, tag_category FROM sys_tag_asset '
                            ' WHERE entity_id IS NOT NULL'):
                        _cat[('ENTITY', eid)] = cat
                    for tid, cat in c.execute(
                            'SELECT sys_tag_id, tag_category FROM sys_tag_asset '
                            ' WHERE entity_id IS NULL'):
                        _cat[('TAG', tid)] = cat
                    try:
                        for tid, cat in c.execute(
                                'SELECT user_tag_id, tag_category '
                                '  FROM userdb.user_tag_asset'):
                            _cat[('UTAG', tid)] = cat
                    except Exception:
                        pass

                def _keep(k2, tid2):
                    if not _code:
                        return True
                    if _code == '_ENTITY_':
                        return k2 == 'ENTITY'
                    if _code == '_USER_':
                        return k2 == 'UTAG'
                    return _cat.get((k2, tid2)) == _code

                rows_e = [r for r in entity_rows(c, like, lang, 1000)
                          if _keep(r[0], r[1])]
                for i, (k, tid, nm, dmap) in enumerate(rows_e):
                    iid = 'c%d' % i
                    marks = tuple('●' if sid in dmap else ''
                                  for sid, _n in _DICTS)
                    tv.insert('', 'end', iid=iid, text=kind_name(k),
                              values=(nm,) + marks)
                    found[iid] = (k, tid)
                base = len(rows_e)
                # 같은 갈래의 태그(순수)는 그대로 줄로
                for k in ks:
                    if k == 'ENTITY':
                        continue
                    _rt = [r for r in _candidates(c, k, like, lang, 1000)
                           if _keep(r[0], r[1])]
                    for j, (k2, tid, nm) in enumerate(_rt):
                        iid = 'c%d' % (base + j)
                        tv.insert('', 'end', iid=iid, text=kind_name(k2),
                                  values=(nm,) + blank)
                        found[iid] = (k2, tid)
                    base += 1000
                return
            # ── 묶음 있는 갈래 — **2단** ──
            got = []
            for k in ks:
                got += _candidates(c, k, like, lang, 1000)
        grouped = any(k in GROUPED_KINDS for k in ks)
        gnodes = {}
        for i, (k, tid, nm) in enumerate(got[:1000]):
            iid = 'c%d' % i
            head, tail = split_group(nm) if grouped else ('', nm)
            parent = ''
            if head:
                gi = gnodes.get(head)
                if gi is None:
                    gi = tv.insert('', 'end', text=head, open=False,
                                   values=('',) + blank)
                    gnodes[head] = gi
                parent = gi
            tv.insert(parent, 'end', iid=iid,
                      text=('' if head else kind_name(k)),
                      values=(tail,) + blank)
            found[iid] = (k, tid)
        # ★ 검색어가 있으면 묶음을 펼친다 — 접힌 채로 두면 「없다」로 보인다
        if grouped and (q.get() or '').strip():
            for gi in gnodes.values():
                tv.item(gi, open=True)
        # 묶음이 하나뿐이면 펼쳐 둔다(접을 이유가 없다)
        if len(gnodes) == 1:
            for gi in gnodes.values():
                tv.item(gi, open=True)
    ent.bind('<KeyRelease>', fill)

    def _sel_kt():
        sel = tv.selection()
        return found.get(sel[0]) if sel else None

    def pick(*_a):
        # ★ **클릭 = 확인** (0.연결팝업.txt) — 가운데 칸에 설명문을 싣고 후보로
        #   담는다. 잇는 것은 [연결] 단추 하나뿐이다.
        kt = _sel_kt()
        if kt and callable(on_pick):
            nm = ''
            try:
                it = tv.item(tv.selection()[0])
                nm = str(it['values'][0]) if it.get('values') else ''
                head = str(tv.item(tv.parent(tv.selection()[0]), 'text') or '')
                if head:
                    nm = '%s · %s' % (head, nm)
            except Exception:
                pass
            on_pick(kt[0], kt[1], nm)

    def open_it(*_a):
        # ★ **겹클릭 = 열어 본다** (0.연결팝업.txt — 「더블클릭하면 자동으로
        #   연결되는 것 제거. 해당 컨텐츠를 열기」). 잇기 전에 내용을 본다.
        kt = _sel_kt()
        if kt and callable(on_open_asset):
            on_open_asset(kt[0], kt[1])
    tv.bind('<<TreeviewSelect>>', pick, add='+')
    tv.bind('<Double-1>', open_it)

    # ⚠⚠ **성경 줄의 [찾기] 와 이름이 같았다** — `COMMON_SEARCH` 가 「찾기」로
    #   번역돼 있어 한 기둥에 **같은 이름 단추 둘**이 있었다(2026-08-29 하네스가
    #   그 둘을 혼동해 잡았다. 사람도 헷갈린다). 재고 쪽은 「검색」으로 못 박는다.
    tk.Button(row, text=_t('LP_SEARCH_BTN', '검색'), bd=1,
              padx=12, pady=3, cursor='hand2',
              command=fill).pack(side='left', padx=(4, 0))
    # ★ [열기] 는 **후보 쪽**이다 (0.연결팝업.txt — 「연결하기 전에 열어보고
    #   나서 문제없을 때 연결해야 한다」). 잇는 단추는 여기 없다 — [연결] 하나.
    tk.Button(brow, text='▶ ' + _t('LP_OPEN', '열기'), bd=1, padx=8,
              pady=0, cursor='hand2', command=open_it).pack(side='right')

    # ★★★ **[+ 새 …] · [↷ 출발지로 지정]** (2026-08-29 사용자 확정 —
    #   「재고자산 화면에서 **추가 버튼**, **출발지 지정 버튼**이 필요한데,
    #     **모든 자산 유형에 대해서 통합 적용**하면 심플할 것 같다」).
    #   ⚠ 단추는 **늘 같은 자리**에 두고 라벨만 갈래를 따라간다 — 들고 나면
    #     줄 높이가 흔들려 위 목록이 통째로 오르내린다(§외부사전 줄 교훈).
    #   ⚠ 만들 수 없는 자산도 **회색으로 숨기지 않는다** — 누르면 어디서
    #     만드는지 알려 준다(§0-1 가짜 기능·조용한 실패 금지).
    def _main_kind():
        """[＋ 새 …] 가 만들 것.

        ★★ **그 범위에서 만들 수 있는 종류를 먼저 고른다** (2026-08-29 사용자
          신고 — 「재고창 **＋렌즈: 사용자가 만들 수 있게 해야 하는데 왜
          관리자만 만든다고 안내하는가?**」).
          렌즈묵상 갈래는 `(LENS, NODE, ULENS, UNODE)` 인데 첫째(`LENS`)를
          그냥 집어서, 사용자 화면인데 **「관리자가 만듭니다」**라고 알렸다.
          사용자가 만들 수 있는 것은 `ULENS`(내 렌즈)다.
        """
        ks = kinds_now()
        if not ks:
            return None
        for k in ks:
            if can_create(k, scope)[0]:
                return k
        return ks[0]

    def _new_asset():
        k = _main_kind()
        if not k:
            return
        if callable(on_create):
            on_create(k)

    def _make_owner():
        # ⚠ 고른 줄이 없으면 **가운데 후보**로 넘긴다(구절은 [찾기] 로 담긴다).
        kt = _sel_kt()
        if callable(on_anchor_pick):
            on_anchor_pick(*(kt if kt else (None, None)))

    b_new = tk.Button(brow, text='＋', bd=1, padx=8, pady=0, cursor='hand2',
                      command=_new_asset)
    b_new.pack(side='left')
    # ★★ **자산 손질 = 만들기 옆** (2026-08-30 사용자 지시 「자산 자체를 숨기는
    #   것이라면 재고창고에 배치해야 한다」). 재고창고는 자산이 사는 칸이므로
    #   `＋ 만들기 · ✎ 수정 · ◐ 이 자산 숨기기` 가 한 줄에 모인다.
    #   ⚠ 「연결」을 떼는 일은 가운데 [⇨ 이 연결만 숨기기] 다 — **다른 일이라
    #     다른 칸**이다. 한 화면에 「숨기기」가 둘이면 이름만으로는 안 갈린다.
    #   ⚠ 관리자(물리삭제)에서는 이름이 「지우기」로 바뀐다 — 하는 일 그대로.
    _fix_e = _fix_h = None
    if callable(on_edit_asset) or callable(on_hide_asset):
        _fix_e = tk.Button(brow, text='✎ ' + _t('COMMON_EDIT', '수정'), bd=1,
                           padx=8, pady=0, cursor='hand2', state='disabled',
                           command=(on_edit_asset or (lambda: None)))
        _fix_e.pack(side='left', padx=(4, 0))
        _hk, _hd = (('LP_DEL_ASSET', '이 자산 지우기') if is_physical(scope)
                    else ('LP_HIDE_ASSET', '이 자산 숨기기'))
        _fix_h = tk.Button(brow, text='◐ ' + _t(_hk, _hd), bd=1,
                           padx=8, pady=0, cursor='hand2', state='disabled',
                           command=(on_hide_asset or (lambda: None)))
        _fix_h.pack(side='left', padx=(4, 0))
    tk.Button(brow, text='↷ ' + _t('LP_SET_OWNER', '출발지로 지정'), bd=1,
              padx=8, pady=0, cursor='hand2',
              command=_make_owner).pack(side='left', padx=(4, 0))

    def _sync_new_btn():
        k = _main_kind()
        if not k:
            return
        okc, _form, _why = can_create(k, scope)
        b_new.config(text='＋ %s' % kind_name(k),
                     relief=('raised' if okc else 'groove'))

    # ★★ **URL 을 그 자리에서 등록한다** (2026-08-27 사용자 — 「외부연결은 url 을
    #   추가하는 기능도 필요하다. **이것이 더 중요하다**」).
    #   ⚠ 단추는 **늘 그 자리에** 두고 갈래에 따라 잠근다 — 들고 나면 줄 높이가
    #     흔들려 아래가 통째로 오르내린다(§주요용어 외부사전 줄 교훈).
    def _new_url():
        # ⚠ **사용자가 더한 URL 은 내 영상(개인 자산)** 이다 — 만든 쪽이
        #   무엇인지 그대로 받아 잇는다(2026-09-10 · §C-2).
        got = _new_url_dialog(f, db_path, lang, scope=scope)
        if not got:
            return
        nk, mid = got if isinstance(got, tuple) else ('MEDIA', got)
        with appdb.connect(db_path) as c:
            add(c, (ok_kind, ok_id), (nk, mid), scope=scope)
        changed()
        # 방금 넣은 것이 보이게 그 갈래로 옮기고 목록을 다시 읽는다
        for i, (k, _nm, _ks) in enumerate(opts):
            if k == 'media':
                _set_branch(i)
                break

    # ★★ **넣기만이 아니라 고치기·지우기까지** (2026-08-27 사용자 —
    #   「외부연결은 아직도 **수정/삭제 화면이 전혀 없다**. 철저하게 살펴라」).
    #   ⚠ 단추 셋을 **늘 같은 자리**에 두고 갈래·선택에 따라 잠근다 —
    #     들고 나면 줄 높이가 흔들려 위 목록이 통째로 오르내린다.
    def _sel_media():
        """목록에서 선택한 것이 **영상이면** (종류, 번호). 아니면 (None, None).

        ⚠ 외부연결(배포)과 내 영상(개인)은 **번호 체계가 다르다** — 종류를
          함께 들고 다녀야 딴 영상을 고치지 않는다.
        """
        sel = tv.selection()
        if not sel:
            return None, None
        k, tid = found.get(sel[0], (None, None))
        return (k, tid) if k in ('MEDIA', 'UMEDIA') else (None, None)

    def _edit_url():
        from tkinter import messagebox
        mk, mid = _sel_media()
        if not mid:
            messagebox.showinfo(_t('LP_EDIT_URL', 'URL 수정하기'),
                                '목록에서 고칠 영상을 먼저 선택하세요.', parent=f)
            return
        if _new_url_dialog(f, db_path, lang, media_id=mid, scope=scope,
                           kind=mk):
            fill()

    def _del_url():
        from tkinter import messagebox
        mk, mid = _sel_media()
        if not mid:
            messagebox.showinfo(_t('LP_DEL_URL', 'URL 지우기'),
                                '목록에서 뗄 영상을 먼저 선택하세요.', parent=f)
            return
        code = CODE.get(mk, 'MEDI')
        with appdb.connect(db_path) as c:
            row = (media_row(c, mid) if mk == 'MEDIA'
                   else user_media_row(c, mid))
            n = c.execute(
                ('SELECT COUNT(*) FROM %s '
                 '  WHERE (%s=? AND clicked_id=?) '
                 '     OR (%s=? AND target_id=?)')
                % (tbl(scope), LT_A, LT_B),
                (code, mid, code, mid)).fetchone()[0]
        if not messagebox.askyesno(
                _t('LP_DEL_URL', 'URL 지우기'),
                '「%s」' % ((row and row[0]) or '') + chr(10) + ((row and row[1]) or '')
                + chr(10)*2
                + '이 URL 과 거기 걸린 연결 %d건을 함께 지웁니다.' % n + chr(10)
                + ('영구히 지워집니다(관리자 물리삭제).' if is_physical(scope)
                   else '지우지 않고 숨기므로 되살릴 수 있습니다.'), parent=f):
            return
        with appdb.connect(db_path) as c:
            if mk == 'UMEDIA':
                hide_user_media(c, mid, True)
            else:
                hide_media(c, mid, True, scope=scope)
        changed()
        fill()

    # ★★★ **`＋ 새 URL` 을 걷었다** (2026-09-22) — 왼쪽 `＋ 새 …` 가 외부연결
    #   갈래에서 **같은 일**을 한다(`CREATE_CAPS['MEDIA']` 가 `form='URL'` ·
    #   그 폼의 `_save()` 도 `add(...)` 로 똑같이 잇는다). 게다가 이쪽은
    #   **팝업 창**이라 사용자가 싫어하는 방식이었다.
    #   ⚠ `_new_url`·`_new_url_dialog` 는 **남긴다** — 되돌릴 자리다(§0-5).
    #     부르는 곳이 0 이 된 것은 중복이지 잘못이 아니다.
    btn_url = None
    btn_edit = tk.Button(brow, text=_t('LP_EDIT_URL', 'URL 수정하기'), bd=1, padx=8,
                         pady=0, cursor='hand2', command=_edit_url)
    btn_edit.pack(side='left', padx=(3, 0))
    btn_del = tk.Button(brow, text=_t('LP_DEL_URL', 'URL 지우기'), bd=1, padx=8,
                        pady=0, cursor='hand2', command=_del_url)
    btn_del.pack(side='left', padx=(3, 0))
    _url_btns = (btn_edit, btn_del)

    # ★★★ **좁으면 뒤쪽 단추를 `[⋯]` 로 접는다** (2026-09-22 · §237차 ㉔ 과
    #   같은 장치). 위 ①② 로 평소에는 들어가지만 **영상 갈래에서는 다시
    #   넘친다**(실측 591px / 자리 439px). 접으면 **잃는 것이 0** 이다 —
    #   메뉴 안에 그대로 있다.
    #   ⚠⚠ **바뀔 때만 손댄다** — 무조건 다시 담으면 `<Configure>` 가 또 나서
    #     **끝없는 idle 고리**가 된다(§256차 ⑰ 에서 앱이 통째로 멎던 자리).
    #   ⚠ 기하가 가라앉은 뒤 40ms 에 잰다 — `<Configure>` 순간에 재면 폭이
    #     옛 값이라 멀쩡한데 접는다(§256차 ② 그 자리).
    _fold = {'on': None, 'job': None, 'busy': False, 'room': -1}

    _more_btn = tk.Button(brow, text='⋯', bd=1, padx=6, pady=0,
                          cursor='hand2')
    _more_menu = tk.Menu(_more_btn, tearoff=0)
    _more_btn.configure(command=lambda: _more_menu.tk_popup(
        _more_btn.winfo_rootx(),
        _more_btn.winfo_rooty() + _more_btn.winfo_height()))

    #: 접는 차례 — **작을수록 먼저 접힌다**. 여기 없으면 5(가운데).
    #  ⚠⚠ 처음 판은 그냥 「뒤에서부터」 접었는데, URL 단추가 갈래를 따라
    #    나중에 `pack` 되어 맨 뒤에 붙는 바람에 **외부연결 갈래에서 정작 그
    #    갈래의 주 단추가 먼저 접혔다**(selftest 가 잡았다).
    #  ★ 잣대 = **없어도 다른 길이 있는가.** [출발지로 지정]·[수정]·[지우기]는
    #    다른 화면에도 길이 있고, [＋ 새 …]·[URL 고치기]는 여기가 유일하다.
    _FOLD_RANK = (('↷', 1), ('◐', 2), ('✎', 3), ('URL 지우기', 4),
                  ('URL 고치기', 6), ('＋', 9))

    def _rank_of(w):
        try:
            t = str(w.cget('text'))
        except Exception:
            return 5
        for pre, r in _FOLD_RANK:
            if t.startswith(pre) or t == pre:
                return r
        return 5

    def _brow_left():
        """이 줄에서 **왼쪽에 담긴** 단추들 — 접는 차례로(먼저 접힐 것이 뒤)."""
        out = []
        for w in brow.winfo_children():
            if w is _more_btn or not isinstance(w, tk.Button):
                continue
            try:
                if w.pack_info().get('side') != 'left':
                    continue
            except Exception:
                continue
            out.append(w)
        # 접을 때 `keep.pop()` 으로 **뒤에서** 빼므로, 먼저 접힐 것을 뒤에 둔다
        out.sort(key=lambda w: -_rank_of(w))
        return out

    def _fit_brow(*_a):
        if _fold['busy']:
            return            # ⚠ 재는 동안 제 이벤트를 안 받는다
        # ★★★ **폭이 그대로면 아무 일도 안 한다** — <Configure> 는 크기가
        #   안 바뀌어도 오므로, 이 한 줄이 없으면 **영원히 되풀이**된다.
        try:
            _r = brow.winfo_width()
        except Exception:
            return
        if _r == _fold['room']:
            return
        _fold['room'] = _r
        if _fold['job']:
            try:
                brow.after_cancel(_fold['job'])
            except Exception:
                pass
        _fold['job'] = brow.after(40, _fit_brow_now)

    def _fit_brow_now():
        _fold['job'] = None
        if _fold['busy']:
            return
        _fold['busy'] = True
        try:
            _fit_brow_body()
        finally:
            #  ⚠ **즉시 연다.** `after_idle` 로 늦추면 idle 큐가 안 비어
            #    `mainloop` 가 끝나지 않는다(실측 — 창이 영영 안 닫혔다).
            #    되풀이는 아래 「바뀔 때만 적는다」 가드가 막는다.
            _fold['busy'] = False

    def _fit_brow_body():
        try:
            #  ⚠ 루프 안에서는 update_idletasks() 를 안 부른다(위 까닭).
            room = brow.winfo_width()
        except Exception:
            return
        if room < 40:
            return
        btns = _brow_left()
        #  오른쪽에 붙은 것(열기)도 자리를 먹는다 — 함께 센다
        fixed = sum(w.winfo_reqwidth() + 6 for w in brow.winfo_children()
                    if isinstance(w, tk.Button) and w not in btns
                    and w is not _more_btn)
        need, keep = fixed, []
        for w in btns:
            need += w.winfo_reqwidth() + 6
            keep.append(w)
        fold = []
        # 뒤에서부터 접는다 — 앞쪽이 더 자주 쓰는 단추다
        while need > room - 34 and len(keep) > 1:
            w = keep.pop()
            fold.append(w)
            need -= w.winfo_reqwidth() + 6
        names = tuple(str(w.cget('text')) for w in fold)
        if _fold['on'] == names:
            return                      # ★ **바뀔 때만** 손댄다
        _fold['on'] = names
        for w in fold:
            try:
                w.pack_forget()
            except Exception:
                pass
        # ⚠ 되살아난 단추가 **엉뚱한 자리**에 붙지 않게 — 접은 것을 걷어낸 뒤
        #   남은 것을 화면 차례대로 다시 담는다.
        for w in keep:
            try:
                if not w.winfo_ismapped():
                    w.pack(side='left', padx=(4, 0))
            except Exception:
                pass
        _more_menu.delete(0, 'end')
        for w in reversed(fold):
            _more_menu.add_command(
                label=str(w.cget('text')),
                command=(lambda b=w: b.invoke()),
                state=str(w.cget('state')))
        try:
            if fold and not _more_btn.winfo_ismapped():
                _more_btn.pack(side='left', padx=(4, 0))
            elif not fold and _more_btn.winfo_ismapped():
                _more_btn.pack_forget()
        except Exception:
            pass

    brow.bind('<Configure>', _fit_brow, add='+')

    def _url_gate(*_a):
        """외부연결 갈래일 때만 산다. 고치기·지우기는 **선택한 줄이 있어야** 산다.

        ★★★ **쓰지 못하는 단추는 자리도 차지하지 않는다** (2026-09-22).
          ⚠⚠ 옛 판은 회색으로 **늘 두었고**, 그 둘이 **244px** 를 먹어
            **쓰는 단추를 밀어냈다**(실측 필요 667 / 자리 439 — 뒤엣것이
            1~4px 로 눌렸다). 눌리지도 않는 단추가 눌리는 단추를 가린 것이다.
            §0-1 「빈 서랍 금지」 · §271차 ④ 「눌러도 아무 일이 안 나는 체크는
            서랍이 아니다」와 같은 자리.
          ⚠ **줄 높이는 안 바뀐다** — 같은 줄 안 가로 배치라 위 목록이
            오르내리지 않는다(그 걱정 때문에 늘 두었던 것이다).
          ⚠ `＋ 새 …` 는 그대로 회색으로 둔다 — 그것은 **눌리고**, 누르면
            어디서 만드는지 알려 준다(§0-1 조용한 실패 금지).
        """
        on = any(k == 'MEDIA' for k in kinds_now())
        for w in _url_btns:
            try:
                if on and not w.winfo_ismapped():
                    w.pack(side='left', padx=(3, 0))
                elif not on and w.winfo_ismapped():
                    w.pack_forget()
            except Exception:
                pass
        if not on:
            _fold['room'] = -1        # ⚠ 단추가 들고 났으니 다시 잰다
            _fit_brow()
            return
        has = bool(_sel_media())
        for w in (btn_edit, btn_del):
            w.configure(state=('normal' if (on and has) else 'disabled'))
        _fold['room'] = -1            # ⚠ 단추가 들고 났으니 다시 잰다
        _fit_brow()
    tv.bind('<<TreeviewSelect>>', _url_gate, add='+')
    # 갈래 단추가 바뀔 때도 잠금을 갱신한다 — _set_branch 가 fill() 을 부르고
    # fill 뒤에 잠금이 맞아야 하므로 여기서 명령을 겹으로 단다.
    for _j, _bb in enumerate(_bbtns):
        _bb.configure(command=lambda i=_j: (_set_branch(i), _url_gate()))

    # ★ **부르는 쪽이 재고 갈래를 미리 눌러 둘 수 있다** (2026-08-30 사용자 지시
    #   「연구자료 버튼을 클릭하면 … **재고창고에서 연구자료 버튼이 클릭된 상태**」).
    #   ⚠ 그 갈래가 이 범위에 없으면 **말없이 첫 갈래**로 — 없는 갈래를 고른 척하면
    #     사용자는 왜 다른 것이 떴는지 알 수 없다(첫 갈래는 늘 뜻이 통한다).
    _start = 0
    if pick_kind:
        for _i, (_k, _nm, _ks) in enumerate(opts):
            if pick_kind == _k or pick_kind in _ks:
                _start = _i
                # ★★ **부른 화면의 말로 바꿔 단다** (2026-08-30 사용자 —
                #   「팝업화면의 맨 아래에 "외부연결"이라는 단어가 있다.
                #   사용자는 알 수 없다. **탭 이름 그대로** 표현하라」).
                #   갈래 이름은 표 전체가 쓰는 말이라 통째로 바꿀 수 없다 —
                #   **부른 자리에서만** 갈아 끼운다.
                if pick_label and _i < len(_bbtns):
                    try:
                        _bbtns[_i].config(text=pick_label)
                    except Exception:
                        pass
                break
    if opts:
        _set_branch(_start)
        # ★★ **누른 효과까지 보인다** (2026-08-30 사용자 — 「팝업화면만 표시하지
        #   말고 … 버튼을 클릭한 효과가 **가운데 확인화면에 나타나도록**」).
        #   갈래만 눌러 두면 목록만 바뀌고 가운데는 비어 있다 — 무엇을 하라는
        #   화면인지 알 수 없다. ⇒ 만들기 폼을 그 자리에서 연다.
        if auto_create:
            try:
                f.after(120, _new_asset)
            except Exception:
                pass
    _url_gate()
    _sync_new_btn()
    # ⚠ 손질 단추를 **부른 쪽에 돌려준다** — 그쪽이 `view`(가운데에 보이는 것)에
    #   맞춰 켜고 끈다(`_sync_fix_btns`). 여기서 상태를 정하면 판단 근거가 갈린다.
    return {'edit': _fix_e, 'hide': _fix_h}


def _new_url_dialog(parent, db_path, lang, media_id=None, scope='USER',
                    kind=None):
    """제목·URL·갈래를 받아 영상 한 행 → **(종류, 번호)**(취소면 None).

    `media_id` 를 주면 **고치기** — 기존 값을 채워 열고 그 행을 갱신한다.
    ⚠ 넣기와 고치기를 **한 창으로** 한다. 둘로 지으면 칸이 갈라진다.
    ★★★ **어느 표에 담느냐를 `scope` 가 정한다**(2026-09-10) —
      관리자는 배포 표(`sys_media_asset`), 사용자는 **내 영상**
      (`userdb.user_media_asset`). 그전에는 사용자가 더한 URL 이 배포 DB 로
      가서 다음 배포에 통째로 날아갔다(§C-2 sys/user 경계).
    ⚠ 고칠 때는 **그 줄이 어느 표의 것인지**(`kind`)를 받아야 한다 — 번호
      체계가 달라 잘못 고르면 딴 영상을 고친다.
    """
    import tkinter as tk
    from tkinter import ttk, messagebox
    win = tk.Toplevel(parent)
    win.title(_t('LP_NEW_URL', '＋ 새 URL'))
    win.transient(parent.winfo_toplevel())
    win.resizable(False, False)
    out = {'id': None}
    # ★ 담을 표 — 고칠 때는 그 줄의 종류, 새로 만들 때는 범위가 정한다
    _uk = (str(kind).upper() if kind
           else ('MEDIA' if is_physical(scope) else 'UMEDIA'))
    bd = tk.Frame(win, padx=12, pady=10)
    bd.pack(fill='both', expand=True)

    v_url = tk.StringVar()
    v_ttl = tk.StringVar()
    v_typ = tk.StringVar(value=MEDIA_TYPES[1])
    if media_id:
        with appdb.connect(db_path) as _c:
            _r = (media_row(_c, media_id) if _uk == 'MEDIA'
                  else user_media_row(_c, media_id))
        if _r:
            v_ttl.set(_r[0] or ''); v_url.set(_r[1] or '')
            v_typ.set(_r[2] or MEDIA_TYPES[1])
        win.title(_t('LP_EDIT_URL', 'URL 수정하기'))
    # ⚠ **단추는 맨 위**(§0)
    top = tk.Frame(bd)
    top.pack(fill='x', pady=(0, 8))

    def ok():
        try:
            with appdb.connect(db_path) as c:
                if media_id:
                    if _uk == 'UMEDIA':
                        edit_user_media(c, media_id, v_ttl.get(), v_url.get(),
                                        v_typ.get())
                    else:
                        edit_media(c, media_id, v_ttl.get(), v_url.get(),
                                   v_typ.get())
                    out['id'] = media_id
                elif _uk == 'UMEDIA':
                    out['id'] = new_user_media(c, v_ttl.get(), v_url.get(),
                                               v_typ.get(), lang)
                else:
                    out['id'] = new_media(c, v_ttl.get(), v_url.get(),
                                          v_typ.get(), lang)
        except Exception as e:
            messagebox.showerror(_t('LP_NEW_URL', '＋ 새 URL'), str(e), parent=win)
            return
        win.destroy()
    tk.Button(top, text=_t('COMMON_SAVE', '저장'), bd=1, padx=14, pady=3,
              cursor='hand2', command=ok).pack(side='left')
    tk.Button(top, text=_t('COMMON_CANCEL', '취소'), bd=1, padx=14, pady=3,
              cursor='hand2', command=win.destroy).pack(side='left', padx=6)

    g = tk.Frame(bd)
    g.pack(fill='x')
    _lbl(g, 'URL').grid(row=0, column=0, sticky='w', pady=3)
    e_url = ttk.Entry(g, textvariable=v_url, width=56)
    e_url.grid(row=0, column=1, sticky='we', padx=(8, 0))
    _lbl(g, _t('COMMON_TITLE', '제목')).grid(row=1, column=0, sticky='w', pady=3)
    ttk.Entry(g, textvariable=v_ttl, width=56).grid(
        row=1, column=1, sticky='we', padx=(8, 0))
    _lbl(g, _t('LP_MEDIA_TYPE', '갈래')).grid(row=2, column=0, sticky='w', pady=3)
    ttk.Combobox(g, textvariable=v_typ, state='readonly', width=14,
                 values=list(MEDIA_TYPES)).grid(row=2, column=1, sticky='w',
                                                padx=(8, 0))
    _lbl(bd, '제목을 비우면 URL 을 제목으로 씁니다. 같은 URL 을 다시 넣으면 '
             '행이 늘지 않고 되살아납니다.').pack(anchor='w', pady=(8, 0))
    _finish_theme(win)
    e_url.focus_set()
    _place_bottom(win, parent)
    win.grab_set()
    win.wait_window()
    # ⚠ **종류를 함께 돌려준다** — 번호만 주면 부르는 쪽이 어느 표인지 모른다
    return (_uk, out['id']) if out['id'] else None


#: 새 URL 을 넣을 때 고르는 갈래 — `sys_media_asset.media_type` 실측 분포 순
MEDIA_TYPES = ('SERMON', 'STUDY', 'WORSHIP', 'FILM')


def new_media(conn, title, url, media_type='STUDY', lang='KO', desc=None):
    """**URL 을 새로 등록한다** → `media_id`.

    ★★ 사용자 지시(2026-08-27) 「외부연결은 **url 을 추가하는 기능**도 필요하다.
      **이것이 더 중요하다**」 — 서핑하다 만난 것을 그 자리에서 붙이는 길이다.
      그전에는 이미 수집된 11,856개 중에서 **고르는 것만** 됐다.

    ⚠ `media_type`·`format_type`·`title`·`url` 이 **NOT NULL** 이다(실측).
      비면 조용히 실패하는 것이 아니라 터진다 — 여기서 채워 준다.
    ⚠ **같은 URL 을 다시 넣으면 새 행을 만들지 않는다** — 그 행을 되살려
      번호를 돌려준다(연결은 `add` 가 멱등이므로 전체가 멱등이 된다).
    ⚠ 재생 방식은 여기서 판정하지 않는다 — 유튜브인지 아닌지는 **화면이**
      url 로 가른다(§3 링크 갈래 「가르는 기준은 재생 방식」).
    """
    url = (url or '').strip()
    title = (title or '').strip()
    if not url:
        raise ValueError('URL 이 비었다')
    if not title:
        title = url
    row = conn.execute(
        'SELECT media_id FROM sys_media_asset WHERE url=?', (url,)).fetchone()
    if row:
        conn.execute("UPDATE sys_media_asset SET record_status='LIVE', "
                     '       title=COALESCE(NULLIF(?,""), title) '
                     ' WHERE media_id=?', (title, row[0]))
        conn.commit()
        return row[0]
    fmt = 'VIDEO' if _is_youtube(url) else 'LINK'
    cur = conn.execute(
        'INSERT INTO sys_media_asset(media_type, format_type, title, url,'
        " description, lang_code, record_status) VALUES(?,?,?,?,?,?, 'LIVE')",
        (media_type or 'STUDY', fmt, title, url, desc, (lang or 'KO').upper()))
    conn.commit()
    return cur.lastrowid


def edit_user_media(conn, uid, title=None, url=None, media_type=None):
    """**내 영상**을 고친다. 준 것만 바꾼다(빈 값으로 안 덮는다).

    ⚠ `user_media_asset` 의 갈래 칸 이름은 `category` 다(`media_type` 이 아니다) —
      배포 표와 칸 이름이 달라 그대로 베끼면 조용히 안 바뀐다.
    """
    sets, args = [], []
    if title is not None and str(title).strip():
        sets.append('title=?')
        args.append(str(title).strip())
    if media_type:
        sets.append('category=?')
        args.append(media_type)
    if url is not None and str(url).strip():
        sets.append('url=?')
        args.append(str(url).strip())
    if not sets:
        return False
    args.append(int(uid))
    conn.execute('UPDATE userdb.user_media_asset SET %s WHERE user_media_id=?'
                 % ', '.join(sets), args)
    conn.commit()
    return True


def edit_media(conn, media_id, title=None, url=None, media_type=None):
    """등록한 URL 을 **고친다**. 준 것만 바꾼다.

    ★ 사용자 지시(2026-08-27) 「수정/삭제도 필요하다. **잘못 입력한 경우
      제거해야 한다**」 — 넣기만 되고 고칠 길이 없으면 오타가 영영 남는다.
    ⚠ NOT NULL 칸을 **빈 값으로 덮지 않는다** — 빈 문자열을 주면 그 칸은 안 만진다.
    ⚠ URL 을 바꾸면 `format_type` 도 다시 판정한다(유튜브↔일반).
    """
    sets, args = [], []
    if title is not None and str(title).strip():
        sets.append('title=?')
        args.append(str(title).strip())
    if media_type:
        sets.append('media_type=?')
        args.append(media_type)
    if url is not None and str(url).strip():
        u = str(url).strip()
        sets += ['url=?', 'format_type=?']
        args += [u, 'VIDEO' if _is_youtube(u) else 'LINK']
    if not sets:
        return False
    args.append(int(media_id))
    conn.execute('UPDATE sys_media_asset SET %s WHERE media_id=?'
                 % ', '.join(sets), args)
    conn.commit()
    return True


def hide_media(conn, media_id, hide=True, scope='SYS'):
    """등록한 URL 을 **뗀다** — 지우지 않고 HIDE(§10).

    ⚠ **연결까지 함께 숨긴다.** 링크를 남겨 두면 목록에서 이름이 사라진 줄이
      뜬다(`#12601`). 되살리면 둘 다 되살아난다.
    """
    # ★★ **관리자(SYS)는 물리삭제** (2026-08-27 사용자 확정 — 「나는 관리자
    #   이므로 물리삭제 해야 한다」). 배포 표에 HIDE 찌꺼기를 쌓으면 전
    #   사용자에게 배포된다. 복구는 감사 로그(§10-1) — DELETE 도 old_json 이
    #   전부 남는다. `hide=False`(되살리기)는 SYS 에서 뜻이 없다.
    if is_physical(scope):
        if not hide:
            return False
        conn.execute('DELETE FROM sys_media_asset WHERE media_id=?',
                     (int(media_id),))
        conn.execute(("DELETE FROM %s "
                      " WHERE (%s='MEDI' AND clicked_id=?) "
                      "    OR (%s='MEDI' AND target_id=?)")
                     % (tbl(scope), LT_A, LT_B),
                     (int(media_id), int(media_id)))
        conn.commit()
        return True
    # USER = HIDE (덮개 — 되살릴 수 있다). 링크만 개인 표를 만진다 —
    # 영상 행 자체는 배포 표라 사용자가 못 지운다(가릴 뿐이다).
    st = 'HIDE' if hide else 'LIVE'
    conn.execute(("UPDATE %s SET record_status=? "
                  " WHERE (%s='MEDI' AND clicked_id=?) "
                  "    OR (%s='MEDI' AND target_id=?)")
                 % (tbl(scope), LT_A, LT_B),
                 (st, int(media_id), int(media_id)))
    conn.commit()
    return True


def new_user_media(conn, title, url, media_type='STUDY', lang='KO'):
    """**내 영상**을 담는다 → `user_media_id`.

    ★★★ 2026-09-10 신설 — 사용자가 그 자리에서 더한 URL 이 그전에는
      **배포 DB(`sys_media_asset`)** 로 갔다. 다음 콘텐츠 배포에 통째로
      날아가고, 남의 PC 에는 없는 번호가 된다(§C-2 sys/user 경계).
    ⚠ 같은 URL 을 다시 넣으면 **되살려 번호를 돌려준다**(멱등).
    ⚠ `verse_id` 는 **닻이지 주인이 아니다** — 여기서는 0(앵커 없음)으로
      담고, 어디에 붙일지는 연결이 정한다(`notes.md` §0-1 과 같은 얼개).
    """
    url = (url or '').strip()
    if not url:
        raise ValueError('URL 이 비었다')
    # ⚠⚠ **제목 폴백을 되살리기에 쓰지 않는다** — 빈 제목을 url 로 채운 뒤
    #   그것으로 덮으면 **멀쩡한 제목이 url 로 바뀐다**(실측으로 잡았다).
    #   새로 담을 때만 폴백한다.
    raw = (title or '').strip()
    row = conn.execute(
        'SELECT user_media_id FROM userdb.user_media_asset WHERE url=?',
        # status-ok: 같은 주소를 다시 담지 않으려는 확인 — 가림을 빼면
        #   **숨긴 영상이 새 줄로 되살아난다**(`media_intake.admit` 과 같은 자리)
        (url,)).fetchone()
    if row:
        conn.execute("UPDATE userdb.user_media_asset SET record_status='LIVE',"
                     '       title=COALESCE(NULLIF(?,""), title)'
                     ' WHERE user_media_id=?', (raw, row[0]))
        conn.commit()
        return row[0]
    cur = conn.execute(
        'INSERT INTO userdb.user_media_asset(title, url, verse_id, category,'
        "  lang_code, record_status) VALUES(?,?,0,?,?,'LIVE')",
        (raw or url, url, media_type or 'STUDY', (lang or 'KO').upper()))
    conn.commit()
    return cur.lastrowid


def user_media_row(conn, uid):
    """→ `(title, url, category, record_status)` · 없으면 None."""
    return conn.execute(
        "SELECT title, url, COALESCE(category,'STUDY'),"
        # status-ok: 여기서 `record_status` 는 **내는 값**이지 거를 조건이
        #   아니다 — 숨긴 것인지 알려 주는 것이 이 문의 일이다
        "       COALESCE(record_status,'LIVE')"
        '  FROM userdb.user_media_asset WHERE user_media_id=?',
        (int(uid),)).fetchone()


def hide_user_media(conn, uid, hide=True):
    """내 영상을 **숨긴다**(지우지 않는다) — 연결도 함께.

    ⚠ 개인 자산이라 **물리삭제하지 않는다** — 되살릴 자리를 남긴다.
    """
    st = 'HIDE' if hide else 'LIVE'
    conn.execute('UPDATE userdb.user_media_asset SET record_status=?'
                 ' WHERE user_media_id=?', (st, int(uid)))
    conn.execute("UPDATE userdb.user_link_asset SET record_status=?"
                 # ⚠ `_` 는 LIKE 의 자리표라 **글자로 쓰려면 escape** 가 필요하다.
                 " WHERE (link_type LIKE 'UMED#_%' ESCAPE '#'"
                 "        OR link_type LIKE '%#_UMED' ESCAPE '#')"
                 "   AND (clicked_id=? OR target_id=?)",
                 (st, int(uid), int(uid)))
    conn.commit()
    return True


def media_row(conn, media_id):
    """→ `(title, url, media_type, record_status)` · 없으면 None."""
    return conn.execute(
        'SELECT title, url, media_type, COALESCE(record_status,\'LIVE\') '
        '  FROM sys_media_asset WHERE media_id=?', (int(media_id),)).fetchone()


def _is_youtube(url):
    u = (url or '').lower()
    return ('youtube.com' in u) or ('youtu.be' in u)


#: ★★ **묶음 → 낱낱** — 2단 트리에서 무엇으로 묶나 (2026-08-29 사용자 지시
#  「제일 좋은 것은 **설교서재, 도서서재 화면이 3단 재고창고에서도** 지원되면
#  좋다」 · 「2단 트리 매우 좋다」).
#  ⚠ 서재 화면을 그대로 심을 수 없다 — **Tk 는 위젯을 다른 부모로 옮겨 심지
#    못한다**(실측 TclError). 복제하면 두 벌이 된다. ⇒ 목록 자체를 2단으로.
#  ★ 이름표가 이미 「묶음 · 낱낱」 꼴이라(「스펄전 설교 선집 · No. 2 — …」)
#    **가운뎃점에서 가르면** 새 SQL 없이 묶인다. 묶는 규칙이 한 줄이다.
GROUPED_KINDS = ('BOOK_UNIT', 'REF_UNIT', 'NODE', 'UNODE')


def split_group(name):
    """이름표 → (묶음, 낱낱). 가운뎃점이 없으면 묶음 없음."""
    nm = str(name or '')
    if ' · ' in nm:
        head, _, tail = nm.partition(' · ')
        return head.strip(), tail.strip()
    return '', nm


#: 사전 자료집 — 용어 한 줄에 칸으로 붙는다. **DB 에서 읽는다**(손으로 안 적는다).
def dict_sources(conn):
    """[(ref_src_id, 짧은 이름)] — 사전 자료집만."""
    out = []
    for sid, t1, t2 in conn.execute(
            "SELECT ref_src_id, title_ko, title FROM sys_ref_source "
            "WHERE src_type='DICTIONARY' ORDER BY ref_src_id"):
        nm = (t1 or t2 or '').replace("'s Bible Dictionary", '')
        out.append((sid, nm.strip() or ('#%d' % sid)))
    return out


def entity_rows(conn, like, lang, limit):
    """★★★ **용어 한 줄 = 한 낱말** (2026-08-29 사용자 확정 — 「하나의 키워드를
    입력하면 등록된 용어와 **여러 사전들에 등록되었는지 한눈에** 볼 수 있어야
    한다」 · 「용어 하나에 **레코드 하나만**으로 표시」).

    → [(kind, id, 이름, {ref_src_id: ref_unit_id})]
    ⚠ 사전 글은 **따로 목록에 올리지 않는다** — 실측 289편이 **하나도 빠짐없이**
      용어에 붙어 있어(`REFU_ENTI`) 올리면 같은 낱말이 두 번 뜬다.
    ⚠ 사전을 가진 용어 161/451 · **둘 이상 가진 것 118** — 그래서 위아래로
      이어 붙이지 않고 칸으로 가른다(§95차 주요용어 화면과 같은 판단).
    """
    base = _candidates(conn, 'ENTITY', like, lang, limit)
    ids = [i for _k, i, _n in base]
    dmap = {}
    if ids:
        ph = ','.join('?' * len(ids))
        for eid, srcid, ruid in conn.execute(
                "SELECT l.target_id, u.ref_src_id, u.ref_unit_id "
                "  FROM sys_link_asset l "
                "  JOIN sys_ref_unit u ON u.ref_unit_id = l.clicked_id "
                "  JOIN sys_ref_source s ON s.ref_src_id = u.ref_src_id "
                "   AND s.src_type='DICTIONARY' "
                " WHERE l.link_type='REFU_ENTI' AND l.target_id IN (%s) "
                "   AND COALESCE(l.record_status,'LIVE')='LIVE'" % ph, ids):
            dmap.setdefault(eid, {})[srcid] = ruid
    return [(k, i, n, dmap.get(i, {})) for k, i, n in base]


def _candidates(conn, kind, like, lang, limit, src_type=None):
    """갈래 안에서 선택할 수 있는 것.

    `src_type` — **자료집 글만** 쓴다(`CATECHISM`/`DICTIONARY`/`TOPICAL`).
      ⚠ 셋이 `sys_ref_unit` 한 표에 함께 살지만 **관리자 메뉴는 따로**다
        (교리문답 관리 · 사전 관리). 「자료집 글」 하나로만 두면 사전을 고를
        길이 있다는 것을 알 수 없다(2026-08-27 사용자 지적 「빠진 것 : 사전」).
        실측 DICTIONARY 289 · CATECHISM 267 · TOPICAL 33.
      ★ **`link_type` 은 그대로 `REFU`** — 거르기만 다르다. 코드를 늘리면
        이미 쌓인 3,810행이 갈린다.
    """
    # ★★ **태그는 `tag_picker` 가 단일 소스다** (2026-08-29 · 항목 3-(b)).
    #   여기서 SQL 을 또 쓰면 이름(덮개·연동 엔티티 이름)이 갈린다 —
    #   `all_tags` 가 이미 덮개·가림·표식(N/E)을 다 처리한다.
    #   ⚠ **연동 태그(엔티티를 가리키는 것)는 빼고** 순수 태그만 올린다.
    #     엔티티는 `ENTITY` 종류가 맡는다 — 안 빼면 목록에 두 번 뜬다.
    if kind in ('TAG', 'UTAG'):
        try:
            import tag_picker
        except Exception:
            return []
        linked = set(r[0] for r in conn.execute(
            'SELECT sys_tag_id FROM sys_tag_asset WHERE entity_id IS NOT NULL'))
        q = (like or '').strip('%').strip().lower()
        out = []
        for src, tid, short, _cat, full, mk in tag_picker.all_tags(None, lang):
            k2 = 'TAG' if src == 'SYS' else 'UTAG'
            if k2 != kind:
                continue
            if k2 == 'TAG' and tid in linked:
                continue
            if q and q not in ('%s %s' % (short, full)).lower():
                continue
            out.append((k2, tid, ('%s %s' % (mk, short)).strip()))
            if len(out) >= limit:
                break
        return out

    # ★ 용어(엔티티)는 **별명까지 걸리게** 조회 문에 위임 (2026-09-02 연결팝업
    #   점검에서 잡음 — 병합 옛 이름(「하나님의 사랑」 등)을 별명으로 남겼는데
    #   재고 검색이 이름 LIKE 뿐이라 0건이었다. `entity_search` 는 별명
    #   (sys+내 것)과 **가림 덮개**까지 본다 — 옛 SQL 은 가린 엔티티도 올렸다).
    if kind == 'ENTITY':
        try:
            import overlay_read as _or
            q = (like or '').strip('%').strip()
            return [('ENTITY', _e2, _nm) for _e2, _nm in
                    _or.entity_search(conn, q, lang)[:limit]]
        except Exception as _e:
            print('[link_picker entity cand]', _e)   # 폴백 — 아래 SQL

    # ★★ **묵상노트** (2026-08-30) — 이름은 `label_of` 와 **같은 규칙**으로
    #   짓는다(제목 → 없으면 본문 첫 줄). 두 곳에서 따로 지으면 목록과 출발지
    #   띠에 다른 이름이 뜬다.
    #   ⚠ 검색은 **제목 + 본문** 둘 다 — 제목을 안 붙이고 쓴 노트가 많다.
    if kind == 'NOTE':
        # ⚠⚠ **`record_status` 규약이 다르다** — `user_text_asset` 은 덮개 표라
        #   값이 `NEW`·`EDIT`·`HIDE` 다(다른 표의 `LIVE` 가 아니다). 실측으로
        #   잡았다 — `='LIVE'` 로 거르니 **22건이 통째로 0줄**이 됐다.
        #   ⇒ **숨긴 것만 뺀다.**
        rows = conn.execute(
            "SELECT user_text_id FROM userdb.user_text_asset "
            " WHERE text_type='VERS_NOTE' "
            "   AND COALESCE(record_status,'') <> 'HIDE' "
            "   AND (COALESCE(title,'') LIKE ? OR COALESCE(contents,'') LIKE ?) "
            " ORDER BY user_text_id DESC LIMIT ?",
            (like, like, limit)).fetchall()
        return [('NOTE', r[0], label_of(conn, 'NOTE', r[0], None, lang))
                for r in rows]

    sqls = {
        'LENS': ("SELECT sys_unit_id, unit_name_sid FROM sys_unit_asset "
                 " WHERE unit_type='CONTAINER' "
                 "   AND COALESCE(record_status,'LIVE')='LIVE' "
                 "   AND unit_name_sid LIKE ? ORDER BY sort_order LIMIT ?"),
        'NODE': ("SELECT sys_unit_id, unit_name_sid FROM sys_unit_asset "
                 " WHERE unit_type='NODE' "
                 "   AND COALESCE(record_status,'LIVE')='LIVE' "
                 "   AND unit_name_sid LIKE ? ORDER BY sys_unit_id LIMIT ?"),
        # 내 렌즈·내 노드 — 이름 앞에 ◈ (기호 사전)
        'ULENS': ("SELECT user_unit_id, '◈ ' || unit_name_sid "
                  "  FROM user_unit_asset WHERE unit_type='CONTAINER' "
                  "   AND COALESCE(record_status,'LIVE')='LIVE' "
                  "   AND unit_name_sid LIKE ? ORDER BY sort_order LIMIT ?"),
        'UNODE': ("SELECT user_unit_id, '◈ ' || unit_name_sid "
                  "  FROM user_unit_asset WHERE unit_type='NODE' "
                  "   AND COALESCE(record_status,'LIVE')='LIVE' "
                  "   AND unit_name_sid LIKE ? ORDER BY user_unit_id LIMIT ?"),
        # ★ **이름은 `label_of` 와 같아야 한다** (2026-08-21 사용자 지적
        #   「목록에는 영어, 연결한 오른쪽에서는 한글 … 통일해라」).
        #   원인은 여기서 원제(`sys_book_asset.title`)를 그대로 쓴 것 —
        #   `sys_book_asset_text` 의 **번역 제목**을 먼저 본다.
        #   ⚠ 검색은 **두 이름 다** 걸리게 한다(영어 제목으로도 찾힌다).
        'BOOK': ("SELECT b.book_id, COALESCE(t.title, b.title) "
                 "  FROM sys_book_asset b "
                 "  LEFT JOIN sys_book_asset_text t ON t.book_id=b.book_id "
                 "        AND UPPER(t.lang_code)=UPPER(?) "
                 " WHERE COALESCE(b.record_status,'LIVE')='LIVE' "
                 "   AND (COALESCE(t.title,'') LIKE ? OR b.title LIKE ?) "
                 " ORDER BY b.book_id LIMIT ?"),
        'BOOK_UNIT': ("SELECT u.unit_id, "
                      "       COALESCE(t.title, b.title) || ' · ' "
                      "       || COALESCE(u.unit_label,'') "
                      "  FROM sys_book_unit u "
                      "  JOIN sys_book_asset b ON b.book_id=u.book_id "
                      "  LEFT JOIN sys_book_asset_text t ON t.book_id=b.book_id "
                      "        AND UPPER(t.lang_code)=UPPER(?) "
                      " WHERE COALESCE(u.record_status,'LIVE')='LIVE' "
                      "   AND (u.unit_label LIKE ? OR COALESCE(t.title,'') LIKE ? "
                      "        OR b.title LIKE ?) "
                      " ORDER BY u.unit_id LIMIT ?"),
        # ⚠ 이름 꼴을 `label_of` 와 맞춘다 — 「자료집 · 제목」
        # ★ **목록 요약이 있으면 그것이 먼저** (2026-08-27 사용자 승인 —
        #   「문답 목록이 길거나 숫자만 있다」 · db_refunit_short).
        #   「유일한 위로 · Q.1」 꼴 — 없으면 종전 그대로(폴백).
        'REF_UNIT': ("SELECT u.ref_unit_id, "
                     "       COALESCE(s.title_ko, s.title) || ' · ' || "
                     "       COALESCE((SELECT sh.title || ' · ' FROM "
                     "          sys_text_asset sh "
                     "          WHERE sh.text_type='REF_UNIT_SHORT' "
                     "            AND sh.clicked_id=u.ref_unit_id "
                     "            AND TRIM(COALESCE(sh.title,''))<>'' "
                     "            AND COALESCE(sh.record_status,'LIVE')='LIVE' "
                     "          ORDER BY CASE UPPER(sh.lang_code) "
                     "                   WHEN UPPER(?) THEN 0 "
                     "                   WHEN 'EN' THEN 1 ELSE 2 END "
                     "          LIMIT 1), '') || "
                     "       COALESCE((SELECT x.title FROM sys_ref_text x "
                     "          WHERE x.ref_unit_id=u.ref_unit_id "
                     "            AND UPPER(x.lang_code)=UPPER(?) "
                     "            AND TRIM(COALESCE(x.title,''))<>'' LIMIT 1), "
                     "                (SELECT x2.title FROM sys_ref_text x2 "
                     "          WHERE x2.ref_unit_id=u.ref_unit_id LIMIT 1), "
                     "                u.unit_label) "
                     "  FROM sys_ref_unit u "
                     "  JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id "
                     " WHERE s.src_type IN ('CATECHISM','DICTIONARY','TOPICAL') "
                     "   AND COALESCE(u.record_status,'LIVE')='LIVE' "
                     # ★ 요약으로도 찾힌다 — 「유일한 위로」로 치면 Q.1 이 나온다
                     "   AND (u.unit_label LIKE ? OR EXISTS ("
                     "        SELECT 1 FROM sys_text_asset sh3 "
                     "         WHERE sh3.text_type='REF_UNIT_SHORT' "
                     "           AND sh3.clicked_id=u.ref_unit_id "
                     "           AND COALESCE(sh3.record_status,'LIVE')='LIVE' "
                     "           AND sh3.title LIKE ?)) "
                     " ORDER BY u.ref_unit_id LIMIT ?"),
        # ★★★ **연구자료만**(305차) — 위 `REF_UNIT` 은 갈래 이름이 「문답·사전」
        #   이라 `src_type IN ('CATECHISM','DICTIONARY','TOPICAL')` 로 **연구자료를
        #   일부러 뺐다**. AI 도우미 닻은 그 반대(연구자료)라 갈래가 하나 더 필요하다.
        #   ⚠ `KINDS` 에는 넣지 않는다 — 후보만 내는 갈래다(정책 표를 늘리지 않는다).
        #   ⚠ 닻 접두는 `REF_UNIT` 을 쓴다 — 같은 표(`sys_ref_unit`)의 같은 번호다.
        'REF_STUDY': ("SELECT u.ref_unit_id, "
                      "       COALESCE((SELECT x.title FROM sys_ref_text x "
                      "          WHERE x.ref_unit_id=u.ref_unit_id "
                      "            AND UPPER(x.lang_code)=UPPER(?) "
                      "            AND TRIM(COALESCE(x.title,''))<>'' LIMIT 1), "
                      "                (SELECT x2.title FROM sys_ref_text x2 "
                      "          WHERE x2.ref_unit_id=u.ref_unit_id "
                      "            AND TRIM(COALESCE(x2.title,''))<>'' LIMIT 1), "
                      "                u.unit_label) "
                      "  FROM sys_ref_unit u "
                      "  JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id "
                      " WHERE s.src_type='STUDY' "
                      "   AND COALESCE(u.record_status,'LIVE')='LIVE' "
                      "   AND (u.unit_label LIKE ? OR EXISTS ("
                      "        SELECT 1 FROM sys_ref_text x3 "
                      "         WHERE x3.ref_unit_id=u.ref_unit_id "
                      "           AND COALESCE(x3.title,'') LIKE ?)) "
                      " ORDER BY u.ref_unit_id DESC LIMIT ?"),
        'USER_REF': ("SELECT ref_id, title FROM user_ref_asset "
                     " WHERE COALESCE(record_status,'LIVE')='LIVE' "
                     "   AND title LIKE ? ORDER BY ref_id DESC LIMIT ?"),
        # ── 관리자 전용 셋 (2026-08-27) ────────────────────────────────
        # ⚠ **이름은 `sys_text_asset` 에 있다** — 표에 이름 칸이 없다.
        #   요청 언어 → EN 폴백(§0-3). 폴백이 없으면 이름이 통째로 빈다.
        'ENTITY': ("SELECT e.entity_id, "
                   "       COALESCE((SELECT t.contents FROM sys_text_asset t "
                   "         WHERE t.text_type='ENTITY_NAME' "
                   "           AND t.clicked_id=e.entity_id "
                   "           AND TRIM(COALESCE(t.contents,''))<>'' "
                   "         ORDER BY CASE UPPER(t.lang_code) WHEN UPPER(?) "
                   "                  THEN 0 WHEN 'EN' THEN 1 ELSE 2 END "
                   "         LIMIT 1), e.entity_code) AS nm "
                   "  FROM sys_entity_master e "
                   " WHERE COALESCE(e.record_status,'LIVE')='LIVE' "
                   "   AND (nm LIKE ? OR e.entity_code LIKE ?) "
                   " ORDER BY nm LIMIT ?"),
        'PERICOPE': ("SELECT p.pericope_id, "
                     # ⚠⚠ **`PERI_TITLE` 은 `contents` 가 아니라 `title` 칸이다**
                     #   (2026-08-27 실측으로 잡음 — `contents` 로 읽으면 37,543행
                     #   전부 NULL 이라 화면에 `#5214` 가 뜬다. `title` 로 읽으면
                     #   **3,413단락 × 11언어**가 다 있다. `user_main:637` 이
                     #   이미 「PERI_TITLE 값은 title 칼럼」이라 적어 두었다.)
                     "       COALESCE((SELECT t.title FROM sys_text_asset t "
                     "         WHERE t.text_type='PERI_TITLE' "
                     "           AND t.clicked_id=p.pericope_id "
                     "           AND TRIM(COALESCE(t.title,''))<>'' "
                     "         ORDER BY CASE UPPER(t.lang_code) WHEN UPPER(?) "
                     "                  THEN 0 WHEN 'EN' THEN 1 ELSE 2 END "
                     "         LIMIT 1), '#'||p.pericope_id) AS nm "
                     "  FROM sys_pericope_asset p "
                     " WHERE COALESCE(p.record_status,'LIVE')='LIVE' "
                     "   AND nm LIKE ? ORDER BY p.start_vid LIMIT ?"),
        'PLAN': ("SELECT b.plan_id, "
                 "       COALESCE((SELECT t.contents FROM sys_text_asset t "
                 "         WHERE t.text_type='PLAN_TITLE' "
                 "           AND t.clicked_id=b.plan_id "
                 "           AND TRIM(COALESCE(t.contents,''))<>'' "
                 "         ORDER BY CASE UPPER(t.lang_code) WHEN UPPER(?) "
                 "                  THEN 0 WHEN 'EN' THEN 1 ELSE 2 END "
                 "         LIMIT 1), b.plan_code) AS nm "
                 "  FROM sys_bible_plan b "
                 " WHERE COALESCE(b.record_status,'LIVE')='LIVE' "
                 "   AND (nm LIKE ? OR b.plan_code LIKE ?) "
                 " ORDER BY b.plan_id LIMIT ?"),
        # ★ **외부연결(영상·텍스트 링크)** — 2026-08-27 사용자 지적 「빠진 것 :
        #   외부연결(영상링크/텍스트링크)」. 실측 `MEDI_ENTI` 10,823 ·
        #   `MEDI_PERI` 5,441 로 두 번째로 많은 연결인데 고를 길이 없었다.
        #   ⚠ 영상/텍스트를 여기서 가르지 않는다 — 가르는 기준은 **재생 방식**
        #     (유튜브 id 가 뽑히면 영상)이고 그 판정은 화면이 한다(§3 링크 갈래).
        # ★ 흐름 — 정수 신원으로 낸다(위 `ensure_chain_ids`)
        'CHAIN': ("SELECT m.chain_id, "
                  "  COALESCE((SELECT x.chain_name FROM sys_chain_catalog x "
                  "     WHERE x.chain_code=m.chain_code "
                  "       AND TRIM(COALESCE(x.chain_name,''))<>'' "
                  "     ORDER BY CASE UPPER(x.lang_code) WHEN UPPER(?) THEN 0 "
                  "              WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1), "
                  "    m.chain_code) AS nm "
                  "  FROM sys_chain_master m "
                  " WHERE nm LIKE ? OR m.chain_code LIKE ? "
                  " ORDER BY nm LIMIT ?"),
        'MEDIA': ("SELECT media_id, COALESCE(NULLIF(TRIM(title),''), url) "
                  "  FROM sys_media_asset "
                  " WHERE COALESCE(record_status,'LIVE')='LIVE' "
                  "   AND (title LIKE ? OR url LIKE ?) "
                  " ORDER BY media_id DESC LIMIT ?"),
        # ★ 내 영상 — 내가 담은 것만. 최근 것이 위로.
        'UMEDIA': ("SELECT user_media_id,"
                   "       COALESCE(NULLIF(TRIM(title),''), url) "
                   "  FROM userdb.user_media_asset "
                   " WHERE COALESCE(record_status,'LIVE')='LIVE' "
                   "   AND (title LIKE ? OR url LIKE ?) "
                   " ORDER BY user_media_id DESC LIMIT ?"),
    }
    # ★ 태그는 `tag_picker` 가 단일 소스다 — 여기서 SQL 을 또 쓰면 갈라진다
    #   (2026-08-25 에 `links_of` 가 옛 표를 읽어 새 태그가 안 보이던 그 자리).
    if kind == 'TAG':
        try:
            import tag_picker
            q = (like or '%').strip('%').lower()
            out = []
            for src, tid, nm, _cat, *_r in tag_picker.all_tags(None, lang):
                if src != 'SYS' or (q and q not in str(nm or '').lower()):
                    continue
                out.append(('TAG', tid, nm or ('#%s' % tid)))
                if len(out) >= limit:
                    break
            return out
        except Exception as e:
            print('[link_picker cand TAG] %s' % e)
            return []
    sql = sqls.get(kind)
    if not sql:
        return []
    if kind == 'CHAIN':
        ensure_chain_ids(conn)           # 표가 없으면 만든다(멱등)
    if kind == 'REF_UNIT' and src_type:
        sql = sql.replace(
            "WHERE s.src_type IN ('CATECHISM','DICTIONARY','TOPICAL') ",
            "WHERE s.src_type = '%s' " % str(src_type).replace("'", ''))
    # 자리표 개수만큼 인자를 짓는다 — 도서 쪽은 언어·검색어가 더 든다.
    args = {'BOOK': (lang, like, like, limit),
            'BOOK_UNIT': (lang, like, like, like, limit),
            'REF_UNIT': (lang, lang, like, like, limit),
            # ★ 305차 — 연구자료만 내는 갈래(자리표 = 언어 1 · 검색어 2 · 상한)
            'REF_STUDY': (lang, like, like, limit),
            'ENTITY': (lang, like, like, limit),
            'PERICOPE': (lang, like, limit),
            'PLAN': (lang, like, like, limit),
            'CHAIN': (lang, like, like, limit),
            'MEDIA': (like, like, limit),
            'UMEDIA': (like, like, limit)}.get(kind, (like, limit))
    try:
        return [(kind, r[0], r[1] or ('#%s' % r[0]))
                for r in conn.execute(sql, args)]
    except Exception as e:
        print('[link_picker cand %s] %s' % (kind, e))
        return []


# ── 자가 검증 ─────────────────────────────────────────────────────────────
def _selftest():
    ok = True

    def chk(name, cond, extra=''):
        nonlocal ok
        print(('  PASS ' if cond else '  FAIL ') + name +
              (' ' + str(extra) if extra else ''))
        ok = ok and bool(cond)

    print('link_picker selftest')
    conn = appdb.connect()
    init_schema(conn)
    # ⚠ **먼저 치우고 센다** — 앞 실행이 도중에 죽으면 시험 행이 남아 다음
    #   실행의 기준값을 오염시킨다(실제로 그래서 두 항목이 헛되이 FAIL 했다).
    conn.execute("DELETE FROM %s WHERE clicked_id IN (999901,999902) "
                 "OR target_id IN (999901,999902)" % LINK_TBL)
    conn.commit()
    base = conn.execute("SELECT COUNT(*) FROM %s" % LINK_TBL).fetchone()[0]

    # ① 표가 **userdb** 에 있나 (배포 DB 에 쓰면 갱신 때 사용자 연결이 사라진다)
    #   ⚠ 통합 표 이름은 `user_link_asset` 이다 — main 에도 `sys_link_asset` 이
    #     있으므로 「main 에 없다」가 아니라 **「userdb 에 있다」**를 잰다.
    inuser = conn.execute("SELECT COUNT(*) FROM userdb.sqlite_master "
                          "WHERE name='user_link_asset'").fetchone()[0]
    chk('개인 연결 표가 userdb 에 있다', inuser == 1, 'userdb %d' % inuser)
    # ★★ **`db_path=None` 이 와도 정상 DB 를 연다** (2026-08-27 — 이것이
    #   [연결 편집…] 을 처음부터 막고 있었다. 사용자: 「이전부터 계속 이 모양
    #   이다. **테스트 불가**」). `appdb` 가 `<앱폴더>/None` 이라는 빈 파일을
    #   만들어 열어서 화면에는 「unknown database userdb」만 떴다.
    import appdb as _A
    for _v in (None, ''):
        _c2 = _A.connect(_v)
        _has = any(r[1] == 'userdb' for r in _c2.execute('PRAGMA database_list'))
        chk('★ connect(%r) 도 userdb 를 붙인다' % _v, _has)
        _c2.close()
    chk('★ 엉뚱한 파일을 안 만든다',
        not os.path.exists(os.path.join(
            os.path.dirname(os.path.abspath(_A.MAIN_DB)), 'None')))
    # ★ 코드 표가 이전 도구와 어긋나면 옮긴 행을 화면이 못 찾는다
    # ⚠⚠ **함께 쓰는 코드만 대조한다**(2026-08-27). 그전에는 두 표가 **같아야**
    #   한다고 못 박았는데, 이전 도구는 **개인 연결만** 옮겼으므로 관리자 전용
    #   종류(`SYS_ONLY_KINDS`)를 알 리가 없다. 통째 비교를 유지하면 관리자
    #   종류를 늘릴 때마다 FAIL 이 나고, 그러면 검사를 꺼 버리게 된다.
    #   ⇒ ① 겹치는 코드가 어긋나면 FAIL(원래 뜻) ② 이전 도구가 아는 것을
    #      우리가 빠뜨려도 FAIL ③ 우리만 아는 것은 SYS 전용이어야 한다.
    try:
        import db_link_migrate as _M
        _mine, _old = CODE, _M._USER_KIND
        _clash = {k: (v, _old[k]) for k, v in _mine.items()
                  if k in _old and _old[k] != v}
        chk('★ 함께 쓰는 자산 코드가 어긋나지 않는다', not _clash, _clash)
        _lost = [k for k in _old if k not in _mine]
        chk('★ 이전 도구가 아는 종류를 빠뜨리지 않았다', not _lost, _lost)
        _extra = [k for k in _mine if k not in _old]
        # ⚠ 태그(TAG·UTAG)는 이전 도구가 다루지 않는 저장소다(tag_picker 몫) —
        #   관리자 전용도 아니고 이전 대상도 아니다. 검사에서 제쳐 둔다.
        # ⚠ `NOTE`(묵상노트)도 이전 도구가 모르는 저장소다 —
        #   `userdb.user_text_asset` 에 살고 개인 자산이라 배포에 안 실린다.
        chk('★ 우리만 아는 종류는 넓게 열린 것이거나 태그·노트다',
            all(k in WIDE_KINDS or k in ('TAG', 'UTAG', 'NOTE')
                for k in _extra), _extra)
    except Exception as e:
        chk('자산 코드가 이전 도구와 같다', False, e)

    # ② 한 짝 한 행 — 방향을 바꿔 넣어도 안 는다
    A = ('USER_REF', 999901)
    B = ('LENS', 999902)
    add(conn, A, B, verify=False)
    n1 = conn.execute("SELECT COUNT(*) FROM %s" % LINK_TBL).fetchone()[0]
    add(conn, B, A, verify=False)                       # 거꾸로
    n2 = conn.execute("SELECT COUNT(*) FROM %s" % LINK_TBL).fetchone()[0]
    chk('A→B 뒤 B→A 를 넣어도 행이 안 는다', n1 == n2, '%d / %d' % (n1, n2))
    chk('한 줄이 늘었다', n1 == base + 1, '%d → %d' % (base, n1))

    # ③ 양쪽에서 다 보인다
    chk('A 에서 보인다', any(x['kind'] == 'LENS' and x['id'] == 999902
                         for x in links_of(conn, *A)))
    chk('B 에서도 보인다', any(x['kind'] == 'USER_REF' and x['id'] == 999901
                          for x in links_of(conn, *B)))

    # ④ 연결 해제 = HIDE, 되살려도 행이 안 는다
    remove(conn, A, B)
    chk('떼면 목록에서 사라진다',
        not any(x['id'] == 999902 for x in links_of(conn, *A)))
    add(conn, A, B, verify=False)
    n3 = conn.execute("SELECT COUNT(*) FROM %s" % LINK_TBL).fetchone()[0]
    chk('되살려도 행이 안 는다', n3 == n1, '%d / %d' % (n1, n3))

    # ⑤ 자기 자신은 안 잇는다
    chk('자기 자신 거부', add(conn, A, A, verify=False) is False)

    # ⑥ 구절 범위 — 책·장·단락 단추가 정확한가
    # ⚠ `book_names` 칼럼은 **`book_code`** 다(`bcode` 아님 — lens_share 함정)
    r = conn.execute("SELECT book_code FROM book_names WHERE short_name='롬' "
                     "AND lang_code='KO' LIMIT 1").fetchone()
    bcode = r[0] if r else 45
    br = book_range(conn, bcode)
    cnt = conn.execute("SELECT COUNT(*) FROM bible_index WHERE bcode=?",
                       (bcode,)).fetchone()[0]
    chk('책 범위가 그 책 전부', br and (br[1] - br[0] + 1) == cnt,
        '%s (%d절)' % (br, cnt))
    cr = chapter_range(conn, bcode, 8)
    chk('장 범위', cr and cr[0] <= cr[1], cr)
    mid = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=? "
                       "AND chapter=8 AND verse=28", (bcode,)).fetchone()[0]
    pr = peri_range(conn, mid)
    chk('단락 범위가 그 절을 품는다', pr and pr[0] <= mid <= pr[1], pr)

    # ⑦ **책 한 줄이 그 책 아무 절에서나 걸린다** (0.txt 1번의 요구)
    add(conn, ('USER_REF', 999901), ('VERSE', br[0], br[1]), verify=False)
    # ⚠ `%` 는 `+` 보다 먼저 묶인다 — 조각을 `+` 로 이을 때는 **괄호로 전체를
    #   감싼 뒤** `%` 를 건다(안 그러면 마지막 조각에만 걸려 TypeError).
    hit = conn.execute(
        ("SELECT COUNT(*) FROM %s WHERE " + LT_B + "='VERS' AND "
         + _vr.covers_sql(LINK_TBL, 'target_id', 'end_id')
         + " AND COALESCE(record_status,'LIVE')='LIVE'") % LINK_TBL,
        _vr.covers_args(mid)).fetchone()[0]
    chk('책 단위 한 줄이 그 책 가운데 절에서 걸린다', hit >= 1, hit)
    t0 = time.time()
    conn.execute(("SELECT user_link_id FROM %s WHERE " + LT_B + "='VERS' AND "
                  + _vr.covers_sql(LINK_TBL, 'target_id', 'end_id')) % LINK_TBL,
                 _vr.covers_args(mid)).fetchall()
    chk('구절 조회가 1ms 안', (time.time() - t0) * 1000 < 1.0,
        '%.2f ms' % ((time.time() - t0) * 1000))

    # ⑧ 범위가 이름을 정한다
    lb_book = label_of(conn, 'VERSE', br[0], br[1])
    lb_chap = label_of(conn, 'VERSE', cr[0], cr[1])
    lb_one = label_of(conn, 'VERSE', mid, None)
    print('     %s / %s / %s' % (lb_book, lb_chap, lb_one))
    chk('책 범위는 [책]', lb_book.startswith('[' + _t('LP_R_BOOK', '책')), lb_book)
    chk('장 범위는 [N장]', '장]' in lb_chap, lb_chap)
    chk('한 절은 약명만', lb_one.startswith('롬') and '[' not in lb_one, lb_one)

    # ⑨ 갈래·종류 표
    # 사용자 확정 일곱 + 내 렌즈·내 노드(번호가 sys 와 겹쳐 따로 센다)
    # ★★ 2026-08-27 — **범위가 종류를 가른다.** 그전에는 「엔티티는 대상이
    #   아니다」가 규칙이었는데, 관리자 통합 연결관리가 **모든 자산을 커버**해야
    #   해서 셋(주요용어·구절단락·플랜)을 늘렸다. 다만 **사용자 창은 그대로**다.
    # ★ 2026-08-30 — **묵상노트가 자산이 되어 열다섯**(사용자 확정 「본격적인
    #   연결대상 자산으로 포함하는 조치가 필요하다」).
    # ★ 2026-09-10 — **내 영상이 자산이 되어 열여섯**(사용자 「연결팝업
    #   화면에서 다른 여러 자산들과 연결될 수 있도록 해야 한다」).
    chk('사용자가 선택할 수 있는 종류 열여섯(구절단락 제외)',
        len(kinds('USER')) == 16 and 'PERICOPE' not in kinds('USER')
        and 'NOTE' in kinds('USER') and 'UMEDIA' in kinds('USER')
        and 'ULENS' in kinds('USER') and 'UNODE' in kinds('USER'), kinds('USER'))
    chk('★ 내 영상은 **개인 자산**이라 관리자 창에 안 뜬다',
        'UMEDIA' not in kinds('SYS'), kinds('SYS'))
    chk('★★ 내 영상과 외부연결은 **코드가 다르다**(한 자리가 두 표를 가리키면 안 된다)',
        CODE['UMEDIA'] != CODE['MEDIA']
        and KIND_OF[CODE['UMEDIA']] == 'UMEDIA')
    chk('★ 묵상노트는 **개인 자산**이라 관리자 창에 안 뜬다',
        'NOTE' not in kinds('SYS'), [k for k in kinds('SYS') if k == 'NOTE'])
    # ★★★ 2026-08-29 — **사용자도 다 고른다**(사용자 지시 「전체 자산을
    #   커버하지 못한다」). 넓게 열린 다섯이 사용자 창에 실제로 뜨는가.
    # ★ 넓게 연 것 중 **구절단락만 사용자 판단으로 다시 닫혔다**(2026-08-29).
    # ⚠ 개인 자산은 관리자 창에 안 뜬다 — 넓게 연 것에서 빼고 잰다
    _open = set(WIDE_KINDS) - set(NOT_PICKABLE) - set(USER_ONLY_KINDS)
    chk('★ 사용자 창에 주요용어·플랜·외부연결·흐름이 다 뜬다',
        _open <= set(kinds('USER')), kinds('USER'))
    chk('★ 관리자도 그 넷을 선택한다', _open <= set(kinds('SYS')), kinds('SYS'))
    chk('★ 범위로 자산을 가르지 않는다 (개인 자산만 예외)',
        set(kinds('SYS')) | set(USER_ONLY_KINDS) == set(kinds('USER')))
    # ★ 2026-08-29 항목 3-(b) — **태그 갈래를 「용어」로 흡수**했다(열하나 → 열).
    chk('갈래 열하나(용어가 태그를 품고 · 묵상노트가 늘었다)',
        len(BRANCHES) == 11, [b[0] for b in BRANCHES])
    chk('★ 태그 갈래가 따로 없다 — 용어가 품는다',
        KIND_BRANCH.get('TAG') == 'entity'
        and KIND_BRANCH.get('UTAG') == 'entity', KIND_BRANCH.get('TAG'))
    # ★★ **목록에 같은 이름이 두 번 안 뜬다** — 연동 태그(엔티티를 가리키는
    #   451개)는 태그 후보에서 빠지고 엔티티 쪽만 올린다.
    _tg = _candidates(conn, 'TAG', '%', 'KO', 999)
    _en = _candidates(conn, 'ENTITY', '%', 'KO', 999)
    # ★★★ 2026-09-01 통합 수술 — 배포 태그는 용어로 흡수됐다(`db_tag_unify`).
    #   순수 태그 후보 수는 **DB 에서 센다**(수술 뒤 0 · 되돌리면 58).
    _pure = conn.execute(
        "SELECT COUNT(*) FROM sys_tag_asset WHERE entity_id IS NULL"
        " AND COALESCE(record_status,'LIVE')='LIVE'").fetchone()[0]
    chk('★ 태그 후보 = 배포 순수 태그 (%d개)' % len(_tg),
        len(_tg) == _pure, '%d/%d' % (len(_tg), _pure))
    # ⚠⚠ **개수를 못 박지 말 것** (2026-09-01 — 실제로 깨졌다). 여기 「451」이
    #   박혀 있어서 용어를 두 개 더하자 selftest 가 통째로 FAIL 했다. 용어를
    #   채우는 것이 본업인 저장소에서 **데이터 상태를 전제한 검사는 반드시
    #   깨진다**(§0-5 가 `db_vers_run` 사고로 적어 둔 그 자리).
    #   ⇒ 재는 것은 개수가 아니라 **불변식** — 「살아 있는 용어를 하나도
    #     빠뜨리지 않고 싣는가」. 용어가 늘면 함께 는다.
    # ★ 2026-09-02 — 훑기(빈 검색)는 **기계 낱말(subtype LEX)을 뺀 목록**이
    #   정답이다(사용자 확정 「수백 개 묶음은 분류가 의미 없다」). 낱말은
    #   검색·연결로 닿는다. 그래서 기준도 LEX 제외로 센다.
    _live = conn.execute(
        "SELECT COUNT(*) FROM sys_entity_master"
        " WHERE COALESCE(record_status,'LIVE')='LIVE'"
        " AND COALESCE(json_detail,'') NOT LIKE '%\"subtype\": \"LEX\"%'"
    ).fetchone()[0]
    # ★ 2026-09-02 스트롱 전수 등록(181차)으로 엔티티가 1.1만이 됐다 —
    #   「999 한도 안에 전부 든다」던 옛 전제가 규모에서 깨졌다. 불변식을
    #   다시 적는다: **넉넉한 한도(99999)면 하나도 안 빠지고**, 작은 한도는
    #   정확히 그 수에서 잘린다(자르는 것이 이제 정답이다).
    _en_all = _candidates(conn, 'ENTITY', '%', 'KO', 99999)
    chk('★ 살아 있는 용어를 다 싣는다 (%d개)' % len(_en_all),
        len(_en_all) == _live, '%d/%d' % (len(_en_all), _live))
    chk('★ 작은 한도는 그 수에서 자른다 (999)',
        len(_en) == min(999, _live), '%d/%d' % (len(_en), _live))
    chk('★ 태그 후보 이름이 코드가 아니다',
        (not _tg) or not str(_tg[0][2]).startswith('TAG_'), _tg[:2])
    # ★★★ **태그 코드표가 우리와 같은가** (2026-08-29 실측으로 잡은 사고).
    #   `db_tag_system.TGT_CODE` 에 다섯이 빠져 태그를 구절에 붙이면
    #   `TAG_VERSE` 라는 **틀린 철자**로 저장됐다(우리는 `TAG_VERS` 로 읽는다).
    try:
        import db_tag_system as _TS
        _bad = {k: (v, CODE[k]) for k, v in _TS.TGT_CODE.items()
                if k in CODE and CODE[k] != v}
        chk('★★ 태그 코드표가 우리 코드와 어긋나지 않는다', not _bad, _bad)
        _miss = [k for k in ('VERSE', 'ENTITY', 'PERICOPE', 'MEDIA', 'CHAIN')
                 if k not in _TS.TGT_CODE]
        chk('★★ 태그 코드표에 빠진 종류가 없다', not _miss, _miss)
    except Exception as e:
        chk('태그 코드표를 읽는다', False, e)
    # ★★★ 2026-08-29 항목 3-(c) — **이름을 한 곳으로.**
    _mis = [(k, kind_name(k), KIND_NAME.get(k, k)) for k in KINDS
            if kind_name(k) != KIND_NAME.get(k, k)]
    chk('★★ 화면 이름(i18n)과 코드 폴백이 같다', not _mis, _mis)
    chk('★ 「태그」라는 말을 안 쓴다(용어로 통합)',
        kind_name('TAG') == kind_name('ENTITY') == '용어'
        and kind_name('UTAG') == '내 용어',
        (kind_name('TAG'), kind_name('ENTITY'), kind_name('UTAG')))
    chk('★ 낱낱 이름이 갈래 이름과 겹치지 않는다',
        kind_name('BOOK_UNIT') == '도서 편'
        and kind_name('REF_UNIT') == '자료집 글'
        and kind_name('USER_REF') == '내 연구자료',
        [kind_name(k) for k in ('BOOK_UNIT', 'REF_UNIT', 'USER_REF')])
    chk('★★ ① 과 ③ 이 **같은 축(갈래)** 을 쓴다',
        branch_name('BOOK_UNIT') == branch_name('BOOK') == '도서·설교'
        and branch_name('TAG') == branch_name('ENTITY') == '용어'
        and branch_name('NODE') == branch_name('LENS') == '렌즈묵상',
        [branch_name(k) for k in ('BOOK_UNIT', 'TAG', 'NODE')])
    chk('★ 넉 자 코드로도 갈래를 찾는다',
        branch_name('BUNT') == '도서·설교' and branch_name('VERS') == '성경',
        (branch_name('BUNT'), branch_name('VERS')))
    # ★★★ **완비 점검** (2026-08-29) — 빈 구석이 조용히 남지 않게.
    for _sc in ('USER', 'SYS'):
        _cov = coverage(_sc)
        # ⚠ SYS 가 개인 자산을 못 잇는 것은 **정상**이다 — 배포 DB 가 남의
        #   PC 번호를 가리키면 안 된다(`USER_ONLY_KINDS`).
        # ⚠ 못 잇는 것이 **정상**인 둘 — 개인 자산(배포 DB 가 남의 PC 번호를
        #   가리키면 안 된다) · `NOT_PICKABLE`(사용자 판단으로 닫은 것).
        _noli = [k for k, li, _c, _e, _h, _b, _w in _cov
                 if not li and k not in NOT_PICKABLE
                 and not (_sc == 'SYS' and k in USER_ONLY_KINDS)]
        chk('★★ %s — **모든 자산을 연결할 수 있다**' % _sc, not _noli, _noli)
        _nobr = [k for k, _l, _c, _e, _h, b, _w in _cov
                 if not b and k not in NOT_PICKABLE]
        chk('   %s — 갈래 없는 종류 0 (있으면 화면에서 빠진다)' % _sc,
            not _nobr, _nobr)
        _silent = [k for k, _l, c2, e2, _h, _b, w in _cov
                   if (not c2 or not e2) and not w]
        chk('   %s — **회색인데 이유를 안 말하는 것 0**' % _sc, not _silent,
            _silent)
    _uc = [k for k, _l, c2, _e, _h, _b, _w in coverage('USER') if c2]
    chk('★ 사용자가 그 자리에서 만들 수 있는 것 여섯',
        set(_uc) == {'TAG', 'UTAG', 'ENTITY', 'ULENS', 'UNODE', 'USER_REF',
                     'MEDIA'} - {'UTAG'} | {'UTAG'}
        or len(_uc) >= 6, _uc)
    _ue = [k for k, _l, _c, e2, _h, _b, _w in coverage('USER') if e2]
    chk('★ 만든 것은 **고칠 수도 있다**(만들기 ⊆ 수정 + MEDIA)',
        set(_uc) - set(_ue) <= {'TAG', 'ENTITY', 'MEDIA'},   # ★ 사용자가 만든 영상은 UMEDIA 로 담겨 그것을 고친다
        sorted(set(_uc) - set(_ue)))
    # ★★★ 없는 자산 방어 (2026-08-29 — 유령 연결 6건이 실제로 있었다)
    chk('★★ 없는 단락은 잇지 못한다',
        not exists(conn, 'PERICOPE', 2747))
    chk('   있는 단락은 잇는다', exists(conn, 'PERICOPE', 5214))
    chk('   모르는 종류는 막지 않는다', exists(conn, 'WHATEVER', 1))
    try:
        add(conn, ('PERICOPE', 2747), ('VERSE', 1), scope='USER')
        chk('★★ add 가 없는 자산을 **거부한다**', False, '조용히 들어갔다')
    except ValueError:
        chk('★★ add 가 없는 자산을 **거부한다**', True)
    chk('★★ NOT_PICKABLE 이 **실제로 걸러진다**(값만 있고 안 걸리던 버그)',
        all(k not in kinds('USER') and k not in kinds('SYS')
            for k in NOT_PICKABLE), NOT_PICKABLE)
    chk('   그래도 이름표는 나온다(쌓인 7,089행이 떠야 한다)',
        not str(label_of(conn, 'PERICOPE', 5214, None, 'KO')).startswith('#'),
        label_of(conn, 'PERICOPE', 5214, None, 'KO'))
    # ⚠ 「순종」은 통합 수술로 배포 태그에서 사라졌다 — 검색 결과 수를 DB 와 견준다
    _sj = sum(1 for r in _tg if '순종' in str(r[2]))
    chk('★ 태그도 검색으로 좁혀진다',
        len(_candidates(conn, 'TAG', '%순종%', 'KO', 9)) == _sj,
        _candidates(conn, 'TAG', '%순종%', 'KO', 9))
    chk('★ 용어 갈래가 있다 (2026-08-29 — 없어서 관리자도 못 골랐다)',
        any('ENTITY' in b[3] for b in BRANCHES))
    chk('★ 구절단락 갈래가 있다',
        any('PERICOPE' in b[3] for b in BRANCHES))
    chk('★ 모든 종류에 갈래가 있다 (갈래 없으면 조용히 빠진다)',
        all(k in KIND_BRANCH for k in KINDS),
        [k for k in KINDS if k not in KIND_BRANCH])
    # ★★ 흐름 = 자산 (2026-08-27 사용자 교정 「단순 링크가 아니라 자산이다」)
    _cid = ensure_chain_ids(conn)
    chk('★ 흐름이 정수 신원을 받는다 (%d개)' % len(_cid), len(_cid) >= 80)
    _cc = _candidates(conn, 'CHAIN', '%', 'KO', 5)
    chk('★ 흐름 후보가 이름으로 나온다', _cc and not str(_cc[0][2]).startswith('#'),
        _cc[:2])
    chk('★ 흐름 이름표', not label_of(conn, 'CHAIN', _cc[0][1], None,
                                  'KO').startswith('#') if _cc else False)
    # ★ 흐름을 다른 자산에 실제로 잇는다 — BOOK↔CHAIN (통합 표)
    if _cc:
        _n0 = conn.execute('SELECT COUNT(*) FROM sys_link_asset').fetchone()[0]
        add(conn, ('BOOK', 999917), ('CHAIN', _cc[0][1]), scope='SYS', verify=False)
        _hit = conn.execute("SELECT COUNT(*) FROM sys_link_asset "
                            " WHERE link_type='BOOK_CHAI' AND clicked_id=999917"
                            ).fetchone()[0]
        chk('★ 흐름↔도서 연결이 통합 표에 들어간다(BOOK_CHAI)', _hit == 1)
        _ls3 = links_of(conn, 'BOOK', 999917, 'KO', scope='SYS')
        chk('   양방향 조회로 보인다', any(x['kind'] == 'CHAIN' for x in _ls3),
            [x['kind'] for x in _ls3])
        remove(conn, ('BOOK', 999917), ('CHAIN', _cc[0][1]), scope='SYS')
        _n1 = conn.execute('SELECT COUNT(*) FROM sys_link_asset').fetchone()[0]
        chk('   떼면 물리삭제(잔재 0)', _n0 == _n1, '%d/%d' % (_n0, _n1))
    # ★★ 미리보기 (2026-08-27 「잘못 선택했어도 그냥 연결할 위험」)
    _pv = verse_preview_text(conn, 1, 3, 'KO')
    chk('★ 구절 미리보기에 본문이 실린다', '태초에' in _pv, _pv[:40])
    chk('   참조가 함께 실린다', '창1:1' in _pv)
    _pv2 = verse_preview_text(conn, 1, 100, 'KO')
    chk('   길면 자른다고 말한다', '외' in _pv2 and '절' in _pv2.split(chr(10))[-1])
    _pv3 = chain_preview_text(conn, list(_cid.values())[0], 'KO')
    chk('★ 흐름 미리보기가 나온다', bool(_pv3))
    # ★ 주요용어가 팝업 후보에서도 안 잘린다
    #   ⚠ 여기서도 **한도를 넉넉히 준 것과 견준다** — 숫자를 박으면 위와 같은
    #     이유로 깨진다. 재는 것은 「1000 에서 잘리는가」다.
    _p1000 = _candidates(conn, 'ENTITY', '%', 'KO', 1000)
    _pall = _candidates(conn, 'ENTITY', '%', 'KO', 99999)
    # 2026-09-02 규모 개정 — 훑기(빈 검색)는 낱말(LEX) 제외 목록이 정답.
    chk('★ 팝업 후보 훑기 = 낱말 제외 전부 (%d)' % len(_pall),
        len(_p1000) == len(_pall) and len(_pall) > 400,
        '%d/%d' % (len(_p1000), len(_pall)))
    # ★★ 2026-08-29 — **구절단락을 되돌렸다.** 목록에는 뜨는데 붙일 수는
    #   없던 상태(실측 7,089행)를 끝낸다.
    chk('★ 구절단락을 선택할 수 있다', 'PERICOPE' in KINDS)
    chk('★ 구절단락 갈래가 있다',
        any('PERICOPE' in b[3] for b in BRANCHES))
    chk('★ 그래도 이름표는 나온다',
        not str(label_of(conn, 'PERICOPE', 5214, None, 'KO')).startswith('#'),
        label_of(conn, 'PERICOPE', 5214, None, 'KO'))
    chk('★ 그래도 후보 SQL 은 산다(반대편 화면이 쓴다)',
        len(_candidates(conn, 'PERICOPE', '%', 'KO', 1)) == 1)
    # ★★ **URL 을 그 자리에서 등록한다** (2026-08-27)
    _n0 = conn.execute('SELECT COUNT(*) FROM sys_media_asset').fetchone()[0]
    _mid = new_media(conn, '자가검증 링크', 'https://example.invalid/lp-selftest',
                     'STUDY', 'KO')
    _r = conn.execute('SELECT media_type, format_type, title, record_status '
                      '  FROM sys_media_asset WHERE media_id=?', (_mid,)).fetchone()
    chk('★ 새 URL 이 들어간다', _r and _r[3] == 'LIVE', _r)
    chk('   NOT NULL 칸이 채워진다', _r and _r[0] and _r[1], _r)
    _mid2 = new_media(conn, '자가검증 링크(다시)',
                      'https://example.invalid/lp-selftest', 'STUDY', 'KO')
    chk('★ 같은 URL 은 행을 안 늘린다', _mid2 == _mid, (_mid, _mid2))
    _my = new_media(conn, '', 'https://youtu.be/lp-selftest', 'SERMON', 'KO')
    _rv = conn.execute('SELECT format_type, title FROM sys_media_asset '
                       ' WHERE media_id=?', (_my,)).fetchone()
    chk('★ 유튜브는 VIDEO 로 잡는다', _rv and _rv[0] == 'VIDEO', _rv)
    chk('   제목이 비면 URL 을 제목으로', _rv and _rv[1].startswith('https://'), _rv)
    conn.execute('DELETE FROM sys_media_asset WHERE media_id IN (?,?)',
                 (_mid, _my))
    conn.commit()
    _n1 = conn.execute('SELECT COUNT(*) FROM sys_media_asset').fetchone()[0]
    # ★★ **고치기·연결 해제** (2026-08-27 사용자 — 「잘못 입력한 경우 제거해야 한다」)
    _me = new_media(conn, 'edit 시험', 'https://example.invalid/lp-edit', 'STUDY')
    edit_media(conn, _me, '고친 제목', 'https://youtu.be/lp-edit', 'SERMON')
    _er = media_row(conn, _me)
    chk('★ 고치기가 먹는다', _er and _er[0] == '고친 제목', _er)
    chk('   URL 을 바꾸면 갈래도 다시 잡는다',
        conn.execute('SELECT format_type FROM sys_media_asset WHERE media_id=?',
                     (_me,)).fetchone()[0] == 'VIDEO')
    edit_media(conn, _me, '', '', None)
    chk('★ 빈 값으로 NOT NULL 칸을 덮지 않는다',
        media_row(conn, _me)[0] == '고친 제목', media_row(conn, _me))
    # ★★ **관리자 지우기 = 물리삭제** (2026-08-27 사용자 확정) — 배포 표에
    #   HIDE 찌꺼기를 안 남긴다. 연결도 함께 사라진다.
    add(conn, ('ENTITY', 999913), ('MEDIA', _me), scope='SYS', verify=False)
    hide_media(conn, _me, True, scope='SYS')
    chk('★ 관리자 지우기는 행이 사라진다(물리삭제)',
        media_row(conn, _me) is None)
    _ls = conn.execute("SELECT COUNT(*) FROM sys_link_asset "
                       " WHERE link_type='ENTI_MEDI' AND target_id=?",
                       (_me,)).fetchone()[0]
    chk('★ 걸린 연결도 함께 사라진다', _ls == 0, _ls)
    chk('★ 지워진 것은 못 되살린다(뜻 없는 단추를 안 만든다)',
        hide_media(conn, _me, False, scope='SYS') is False)
    # ★ 사용자 연결 해제 = HIDE (덮개 — 되살릴 수 있다)
    conn.execute("INSERT INTO userdb.user_link_asset(link_type, clicked_id,"
                 " target_id, record_status) VALUES('ENTI_MEDI', 999913, "
                 " 999914, 'LIVE')")
    conn.commit()
    hide_media(conn, 999914, True, scope='USER')
    _u = conn.execute("SELECT record_status FROM userdb.user_link_asset "
                      " WHERE target_id=999914").fetchone()
    chk('★ 사용자 연결 해제는 HIDE 다(행이 남는다)', _u and _u[0] == 'HIDE', _u)
    hide_media(conn, 999914, False, scope='USER')
    _u2 = conn.execute("SELECT record_status FROM userdb.user_link_asset "
                       " WHERE target_id=999914").fetchone()
    chk('   사용자는 되살릴 수 있다', _u2 and _u2[0] == 'LIVE', _u2)
    conn.execute('DELETE FROM userdb.user_link_asset WHERE target_id=999914')
    conn.commit()
    _n2 = conn.execute('SELECT COUNT(*) FROM sys_media_asset').fetchone()[0]
    chk('★ URL 시험 잔재 0', _n0 == _n1 == _n2, '%d → %d → %d' % (_n0, _n1, _n2))
    # ★★★ 2026-08-29 — **용어 갈래를 만들었다.** 그전에는 갈래가 없어
    #   `ENTITY` 가 `KINDS` 에 있는데도 화면에서 조용히 빠졌다(관리자도 못 골랐다).
    chk('모든 종류가 어느 갈래엔가', all(k in KIND_BRANCH for k in KINDS),
        [k for k in KINDS if k not in KIND_BRANCH])
    chk('★ 용어에 갈래가 있다', 'ENTITY' in KIND_BRANCH)
    chk('설명문·주석은 대상이 아니다',
        not ({'DESC', 'COMM', 'CHAP'} & set(KINDS)))
    # 창 재설계(2026-08-21) — 「연결대상」 콤보에 성경·태그는 안 들어간다
    asset = [b[0] for b in BRANCHES if b[0] != 'bible']
    chk('갈래 정의는 그대로 열하나(닫은 것은 화면에서만 빠진다)',
        asset == ['lens', 'book', 'ref', 'study', 'entity', 'peri',
                  'plan', 'chain', 'media', 'note'], asset)
    chk('연결대상 이름이 다 있다',
        all(_t(b[1], b[2]) for b in BRANCHES if b[0] in asset))
    # ★ 늘린 셋이 **실제로 후보를 낸다** — 이름을 못 대면 화면에 `#47` 이 뜬다
    for _k in WIDE_KINDS:
        _c = _candidates(conn, _k, '%', 'KO', 3)
        chk('★ %s 후보가 나온다 (%d)' % (_k, len(_c)),
            len(_c) > 0 and all(str(x[2]) and not str(x[2]).startswith('#')
                                for x in _c), _c[:2])
        if _c:
            _lb = label_of(conn, _k, _c[0][1], None, 'KO')
            chk('   %s 이름표가 번호가 아니다' % _k,
                _lb and not _lb.startswith('#'), _lb)

    # 뒷정리 — 시험 행을 지운다(물리 삭제)
    conn.execute("DELETE FROM %s WHERE clicked_id IN (999901,999902) "
                 "OR target_id IN (999901,999902)" % LINK_TBL)
    conn.commit()
    after = conn.execute("SELECT COUNT(*) FROM %s" % LINK_TBL).fetchone()[0]
    chk('시험 잔재 0', after == base, '%d → %d' % (base, after))

    # ── 3단계 — 범위(scope) · 경로 ────────────────────────────────
    chk('범위 둘', set(SCOPES) == {'SYS', 'USER'}, sorted(SCOPES))
    # ★★★ 2026-08-29 — **범위 차이를 한 표에 모았다**(`SCOPE_CAPS`).
    #   그전에는 `scope == 'SYS'` if 문이 이 파일에만 아홉 자리에 흩어져 있었다.
    chk('★ 능력표가 두 범위를 다 안다', set(SCOPE_CAPS) == {'SYS', 'USER'})
    _keys = set(SCOPE_CAPS['SYS']) 
    chk('★ 두 범위가 **같은 칸**을 갖는다 (한쪽만 늘면 조용히 갈린다)',
        _keys == set(SCOPE_CAPS['USER']),
        _keys ^ set(SCOPE_CAPS['USER']))
    chk('★ 관리자는 물리삭제 · 사용자는 가리기',
        is_physical('SYS') and not is_physical('USER'))
    chk('★ 되살리기는 사용자만', cap('USER', 'revive')
        and not cap('SYS', 'revive'))
    chk('★ 표식(N/E/H)은 사용자만', cap('USER', 'marks')
        and not cap('SYS', 'marks'))
    chk('★ 덮어 읽기는 사용자만', cap('USER', 'merge_sys')
        and not cap('SYS', 'merge_sys'))
    chk('★ 배포 자료 직접 수정은 관리자만', cap('SYS', 'edit_sys')
        and not cap('USER', 'edit_sys'))
    chk('★ 휴지통은 사용자만', cap('USER', 'trash') and not cap('SYS', 'trash'))
    chk('★ 표가 능력표와 같다', tbl('SYS') == cap('SYS', 'table')
        and tbl('USER') == cap('USER', 'table'))
    try:
        cap('SYS', 'NOPE')
        chk('★ 없는 능력은 터뜨린다', False, '조용히 지나갔다')
    except KeyError:
        chk('★ 없는 능력은 터뜨린다', True)
    try:
        cap('NOPE', 'table')
        chk('★ 모르는 범위는 능력표도 터뜨린다', False, '조용히 지나갔다')
    except ValueError:
        chk('★ 모르는 범위는 능력표도 터뜨린다', True)
    # ⚠ **자산을 범위로 가르지 않는다** — 개인 자산만 예외(배포물이 남의 PC
    #   번호를 가리키면 안 된다). 이 검사가 34짝 사고의 재발을 막는다.
    chk('★ 범위가 빼는 자산은 개인 자산뿐 (닫은 것은 범위와 무관)',
        set(cap('SYS', 'no_kinds')) == set(USER_ONLY_KINDS)
        and set(cap('USER', 'no_kinds')) == set())
    chk('★ 닫은 것은 **양쪽 다** 닫힌다(통일)',
        all(k not in kinds('USER') and k not in kinds('SYS')
            for k in NOT_PICKABLE))
    chk('SYS 는 배포 표', tbl('SYS') == 'sys_link_asset')
    chk('USER 는 개인 표', tbl('USER') == 'userdb.user_link_asset')
    try:
        tbl('NOPE')
        chk('★ 모르는 범위는 터뜨린다', False, '조용히 지나갔다')
    except ValueError:
        chk('★ 모르는 범위는 터뜨린다', True)
    chk('★ SYS 에서는 개인 자산을 못 선택한다',
        not (set(kinds('SYS')) & set(USER_ONLY_KINDS)), kinds('SYS'))
    chk('USER 는 닫은 것만 빼고 다 선택한다',
        set(kinds('USER')) == set(KINDS) - set(NOT_PICKABLE))

    # 배포 표 왕복 — **시험 번호**로만. 끝나면 물리 삭제한다.
    S = tbl('SYS')
    sbase = conn.execute("SELECT COUNT(*) FROM %s" % S).fetchone()[0]
    A = ('LENS', 999911, None)
    B = ('BOOK', 999912, None)
    add(conn, A, B, scope='SYS', verify=False)
    n = conn.execute("SELECT COUNT(*) FROM %s WHERE clicked_id=999911 "
                     "OR target_id=999911" % S).fetchone()[0]
    chk('★ SYS 에 넣힌다', n == 1, n)
    chk('★ 개인 표는 안 늘었다',
        conn.execute("SELECT COUNT(*) FROM %s" % LINK_TBL).fetchone()[0] == base)
    # 같은 짝을 **경로로** 한 번 더 — rel 이 다르면 **다른 행**이어야 한다
    add(conn, A, B, scope='SYS', rel='NEXT', sort_order=10, note='다음 걸음', verify=False)
    # ⚠ `pair()` 가 A·B 를 **정렬**하므로 999911 이 어느 쪽에 오는지 모른다
    #   (BOOK < CONT 라 도서가 앞이다). 양쪽을 다 본다.
    n2 = conn.execute("SELECT COUNT(*) FROM %s WHERE clicked_id=999911 "
                      "OR target_id=999911" % S).fetchone()[0]
    chk('★ 경로는 자기 행 (기존 연결에 얹지 않는다)', n2 == 2, n2)
    r = conn.execute("SELECT rel_code, sort_order, note FROM %s "
                     "WHERE (clicked_id=999911 OR target_id=999911) "
                     "AND rel_code='NEXT'" % S).fetchone()
    chk('★ 경로 칸 셋이 들어간다', r == ('NEXT', 10, '다음 걸음'), r)
    # 관점 없는 것만 떼면 경로 행은 남아야 한다
    remove(conn, A, B, scope='SYS')
    alive = conn.execute("SELECT rel_code FROM %s "
                         "WHERE (clicked_id=999911 OR target_id=999911) "
                         "AND COALESCE(record_status,'LIVE')='LIVE'"
                         % S).fetchall()
    chk('★ 관점을 안 주면 그 행만 뗀다', alive == [('NEXT',)], alive)
    remove(conn, A, B, scope='SYS', rel='NEXT')
    alive2 = conn.execute("SELECT COUNT(*) FROM %s "
                          "WHERE (clicked_id=999911 OR target_id=999911) "
                          "AND COALESCE(record_status,'LIVE')='LIVE'"
                          % S).fetchone()[0]
    chk('★ 관점을 주면 경로도 뗀다', alive2 == 0, alive2)
    conn.execute("DELETE FROM %s WHERE clicked_id IN (999911,999912) "
                 "OR target_id IN (999911,999912)" % S)
    conn.commit()
    # ══ ★★★ **연결 편집 창을 실제로 열어 잰다** (2026-08-27) ══════════
    #   사용자가 세 번 같은 것을 지적했다 — 「외부연결 수정/삭제 화면이 전혀
    #   없다 · 태그 고르기 버튼 비활성화 · 말씀의 흐름이 태그 위에 전혀 배치
    #   되어 있지 않다」. **부품만 재고 창을 안 열어 봐서** 놓쳤다.
    #   ⇒ 이제 창을 열어 **단추가 실제로 사는지**까지 잰다.
    try:
        import tkinter as _tk
        _r = _tk.Tk(); _r.geometry('120x60+2400+1400')

        def _walk(w, acc=None):
            acc = [] if acc is None else acc
            for k in w.winfo_children():
                acc.append(k); _walk(k, acc)
            return acc

        _res = {}

        def _probe():
            _tops = [w for w in _walk(_r) if isinstance(w, _tk.Toplevel)]
            if not _tops:
                return
            _w = _tops[-1]; _ws = _walk(_w)
            _bt = {str(x.cget('text')).strip(): x for x in _ws
                   if x.winfo_class() in ('Button', 'TButton')}
            _cb = [x for x in _ws if x.winfo_class() == 'TCombobox']
            _res['btns'] = {k: str(v.cget('state')) for k, v in _bt.items()}
            _res['chain'] = [str(c.cget('state')) for c in _cb
                             if '(선택하세요)' in str(c.cget('values'))]
            _res['labels'] = [str(x.cget('text')) for x in _ws
                              if x.winfo_class() in ('Label', 'TLabel')]
            _tv = [x for x in _ws if x.winfo_class() == 'Treeview']
            _res['kinds'] = [str(x.item(i, 'text')).strip()
                             for x in _tv for i in x.get_children()[:4]
                             if str(x.item(i, 'text')).strip()]
            # 외부연결 갈래 단추를 눌러 URL 단추가 사는지
            # ⚠⚠ **여기서 터지면 창이 안 닫혀 검사가 통째로 멎는다** —
            #   `_w.destroy()` 가 아래에 있기 때문이다(실측으로 당했다).
            try:
                # ★★★ **잘린 단추가 있나** — 이것이 우리가 막으려던 것이다.
                #   갈래를 옮겨 가며 잰다(갈래마다 단추 구성이 다르다).
                _clip = []
                _order = [k for k in _bt if k.startswith('성경')]
                _order += [k for k in ('외부연결', '전체') if k in _bt]
                for _bk in (_order or [None]):
                    if _bk:
                        try:
                            _bt[_bk].invoke()
                        except Exception:
                            continue
                        for _ in range(6):
                            _r.update()
                    for _k2, _w2 in _bt.items():
                        try:
                            if not _w2.winfo_ismapped():
                                continue
                            if _w2.winfo_width() < _w2.winfo_reqwidth() - 2:
                                _clip.append('%s@%s(%d<%d)' % (
                                    _k2[:12], _bk or '-', _w2.winfo_width(),
                                    _w2.winfo_reqwidth()))
                        except Exception:
                            continue
                _res['clipped'] = sorted(set(_clip))
                # 외부연결 갈래에서 URL 단추에 **닿을 수 있나**(보이거나 ⋯ 안에)
                if '외부연결' in _bt:
                    _bt['외부연결'].invoke()
                    for _ in range(6):
                        _r.update()
                    _seen = set()
                    for _k in ('URL 고치기', 'URL 지우기'):
                        if _k in _bt and _bt[_k].winfo_ismapped():
                            _seen.add(_k)
                    for _mw in _ws:
                        if _mw.winfo_class() != 'Menu':
                            continue
                        try:
                            _end = _mw.index('end')
                            for _i in range(0, (int(_end) + 1)
                                            if _end is not None else 0):
                                _lb = str(_mw.entrycget(_i, 'label') or '')
                                if _lb in ('URL 고치기', 'URL 지우기'):
                                    _seen.add(_lb)
                        except Exception:
                            pass
                    _res['url_on'] = sorted(_seen)
            except Exception as _e:                       # noqa: BLE001
                _res['probe_err'] = str(_e)[:80]
            _w.destroy()

        _r.after(2200, _probe)
        open_picker(_r, None, 'VERSE', 1, scope='SYS', lang_getter=lambda: 'KO')
        _bs = _res.get('btns', {})
        # ★★ **[태그 고르기…] 는 걷었다** (2026-08-30 사용자 지시 「태그고르기
        #   버튼을 제거할 것」) — 그 팝업의 몫(축 거르기·유사어 검색)이 재고창고
        #   「태그분류」 줄로 옮겨 왔다. 남겨 두면 같은 일에 창이 둘이다.
        chk('★ [태그 선택하기…] 가 **없다**(재고창고로 흡수)',
            '태그 선택하기…' not in _bs, _bs.get('태그 선택하기…'))
        chk('★ 「태그분류」 필터가 재고창고에 있다',
            any(k in _bs for k in ('전체', '내 태그', '용어사전')),
            [k for k in _bs if k in ('전체', '내 태그', '용어사전')])
        # ★ 3분할 재구축 (2026-08-27 · 0.연결팝업.txt) —
        #   흐름 콤보 줄은 **없어야** 하고(중복 — 연결대상 버튼이 맡는다),
        #   [찾기]·세로 [연결]·연결대상 텍스트 버튼이 있어야 한다.
        chk('★ 흐름 콤보 줄이 없다(중복 제거)', '＋ 흐름 달기' not in _bs)
        chk('★ 연결대상이 텍스트 버튼이다(말씀의 흐름 포함)',
            {'렌즈묵상', '도서·설교', '묵상플랜', '외부연결', '말씀의 흐름'}
            <= set(_bs), sorted(_bs))
        chk('★ [찾기] 가 있다(옛 [＋ 연결])', '찾기' in _bs)
        # ★★ **잇기·연결 해제 단추가 한자리에 짝으로 있다** (2026-08-30 배치 개편).
        #   옛 검사는 「세로 글자 [연]결 단추가 있다」였는데, 세로 글자를 그만둔
        #   것이 이번 변경의 요점이라 **잣대가 옛 모양을 못 박고 있었다.**
        #   ⇒ 재는 것을 **모양이 아니라 짝의 존재**로 바꾼다.
        chk('★ [⇦ 연결하기] 가 있다',
            any(k.startswith('⇦') for k in _bs), sorted(_bs)[:6])
        chk('★ [⇨ …] 연결 해제 단추가 같은 칸에 있다',
            any(k.startswith('⇨') for k in _bs), sorted(_bs)[:6])
        # ★ 자산 손질은 **재고창고(③)** 로 갔다 — 「숨기기」가 한 화면에 둘이던
        #   것을 자리로 갈랐다(연결=가운데 ⇨ · 자산=재고창고 ◐).
        chk('★ 자산 손질(✎ 수정 · ◐ 이 자산 …)이 있다',
            any(k.startswith('✎') for k in _bs)
            and any(k.startswith('◐') for k in _bs), sorted(_bs)[:8])
        chk('★ 「숨기기/지우기」 단추가 서로 다른 말이다',
            len({k for k in _bs if k.startswith(('⇨', '◐'))}) == 2,
            sorted(k for k in _bs if k.startswith(('⇨', '◐'))))
        chk('★ 창에 **URL 고치기·지우기**가 있다',
            {'URL 고치기', 'URL 지우기'} <= set(_bs), sorted(_bs))
        # ★★ **`＋ 새 URL` 은 걷었다** (2026-09-22) — 왼쪽 `＋ 새 …` 가
        #   외부연결 갈래에서 **같은 일**을 한다(`CREATE_CAPS['MEDIA']` 가
        #   `form='URL'` · 그 폼의 저장도 `add(...)` 로 똑같이 잇는다). 게다가
        #   이쪽은 팝업 창이었다. 되살리면 **한 줄에 같은 일이 둘**이 된다.
        chk('★ `＋ 새 URL` 이 없다(`＋ 새 …` 와 중복 — 걷었다)',
            '＋ 새 URL' not in _bs, sorted(_bs)[:6])
        # ★★★ **쓰지 못하는 단추는 자리도 차지하지 않는다** — 실측 그 둘이
        #   244px 를 먹어 **쓰는 단추를 1~4px 로 눌렀다**(필요 667/자리 439).
        # ★★★ **잘린 단추 0** — 이 줄이 넘쳐 단추가 1~4px 로 눌리던 것을
        #   막는 것이 이 작업의 목적이다(실측 필요 667px / 자리 439px).
        chk('★★ 어느 갈래에서도 **잘린 단추 0**',
            _res.get('clipped') == [], _res.get('clipped'))
        # ⚠⚠ **외부연결 갈래에서 보이나는 여기서 못 잰다** — 갈래를 바꾸면
        #   목록과 단추가 **다시 만들어져** probe 가 들고 있던 참조가 죽은
        #   위젯이 된다(실측 — 늘 빈 값). 재려다 **멀쩡한 것을 결함으로
        #   신고**하게 되므로 걷는다(§238차).
        #   ★ 그 몫은 위 「잘린 단추 0」과 **실제 화면 하네스**가 한다 —
        #     temp_code_chain_harness(32/32) · 관리자 하네스 --all.
        chk('★ URL 손질 단추가 둘이다(고치기·지우기)',
            {'URL 고치기', 'URL 지우기'} <= set(_bs), sorted(_bs)[:6])
        # ★ [찾기] 는 이 줄의 **주 동작**이라 접지 않는다 — 콤보를 줄여 살린다
        chk('★ [찾기] 가 안 잘린다(콤보를 줄여 자리를 낸다)',
            not any(x.startswith('찾기') for x in (_res.get('clipped') or [])),
            _res.get('clipped'))
        chk('★ 오른쪽 목록 종류가 **코드가 아니다**',
            _res.get('kinds') and not any(
                k.isascii() and '_' in k for k in _res['kinds']),
            _res.get('kinds', [])[:4])
        _r.destroy()
    except Exception as _e:
        chk('★ 연결 편집 창 검사', False, _e)

    # ── 내 영상(UMEDIA) 왕복 (2026-09-10) ────────────────────────────
    try:
        _u = new_user_media(conn, '__lp 시험 내 영상__',
                            'https://youtu.be/lp-umed-test', 'WORSHIP', 'KO')
        chk('★★★ 내 영상을 담는다', bool(_u))
        chk('★★ **같은 URL 은 행이 안 는다**(멱등)',
            new_user_media(conn, '', 'https://youtu.be/lp-umed-test') == _u)
        chk('★★ **빈 제목이 멀쩡한 제목을 url 로 덮지 않는다**',
            user_media_row(conn, _u)[0] == '__lp 시험 내 영상__',
            user_media_row(conn, _u)[0])
        chk('★ 후보 목록에 뜬다',
            any(x[1] == _u for x in _candidates(conn, 'UMEDIA', '%lp 시험%',
                                                'KO', 20)))
        chk('★ 있는지 판정', exists(conn, 'UMEDIA', _u)
            and not exists(conn, 'UMEDIA', 99999999))
        for _k, _tid in (('VERSE', 3), ('ENTITY', 319), ('BOOK_UNIT', 1)):
            add(conn, ('UMEDIA', _u), (_k, _tid), scope='USER')
        _got = {x['kind'] for x in links_of(conn, 'UMEDIA', _u, scope='USER')}
        chk('★★★ **여러 자산에 붙는다**(구절·용어·도서)',
            {'VERSE', 'ENTITY', 'BOOK_UNIT'} <= _got, _got)
        chk('★★ 이름표가 코드가 아니다',
            all(x['label'] and not str(x['label']).startswith('#')
                for x in links_of(conn, 'UMEDIA', _u, scope='USER')))
        edit_user_media(conn, _u, '__고친 이름__', None, 'SERMON')
        chk('★ 그 자리에서 고친다',
            user_media_row(conn, _u)[0] == '__고친 이름__'
            and user_media_row(conn, _u)[2] == 'SERMON')
        hide_user_media(conn, _u, True)
        chk('★★ 숨기면 **연결도 함께** 숨는다',
            user_media_row(conn, _u)[3] == 'HIDE'
            and not conn.execute(
                "SELECT 1 FROM %s WHERE link_type LIKE '%%UMED%%'"
                '   AND (clicked_id=? OR target_id=?)'
                "   AND COALESCE(record_status,'LIVE')='LIVE'"
                % tbl('USER'), (_u, _u)).fetchone())
        hide_user_media(conn, _u, False)
        chk('★ 되살아난다', user_media_row(conn, _u)[3] == 'LIVE')
        conn.execute("DELETE FROM %s WHERE link_type LIKE '%%UMED%%'"
                     ' AND (clicked_id=? OR target_id=?)' % tbl('USER'),
                     (_u, _u))
        conn.execute('DELETE FROM userdb.user_media_asset'
                     ' WHERE user_media_id=?', (_u,))
        conn.commit()
        chk('★ 내 영상 시험 잔재 0',
            not conn.execute('SELECT 1 FROM userdb.user_media_asset'
                             ' WHERE user_media_id=?', (_u,)).fetchone())
    except Exception as _e2:
        chk('★ 내 영상 왕복', False, _e2)

    chk('★ SYS 시험 잔재 0',
        conn.execute("SELECT COUNT(*) FROM %s" % S).fetchone()[0] == sbase,
        sbase)
    conn.close()
    print('RESULT:', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def main():
    args = sys.argv[1:]
    if '--selftest' in args:
        raise SystemExit(_selftest())
    conn = appdb.connect()
    try:
        if '--init' in args:
            init_schema(conn)
            print('user_link 준비됨 —',
                  conn.execute("SELECT COUNT(*) FROM %s" % LINK_TBL).fetchone()[0], '행')
        else:
            print(__doc__)
    finally:
        conn.close()



def bind_end_autofill(cb_c, cb_c2, cb_v2, on_fill=None):
    """★ 끝 칸을 **건드리는 순간** 시작 장을 끝 장에 미리 넣는다
    (2026-09-17 사용자 지시 — 「창1:5~1:9 를 입력하려고 한다. 대부분 1장에서
     시작하면 끝날때도 1장이다 … **종료절을 입력하려고 클릭하면** 시작절을
     자동으로 표시해주어야 할 것이다」).

    ⚠⚠⚠ **시작을 고를 때 채우면 안 된다** — 그러면 늘 범위가 되어
      2026-08-29 사용자 결정(「보통은 구절 하나만 표시하는 것이 기본」)이
      깨진다. 두 결정이 부딪히는 자리는 「언제 채우나」 하나뿐이므로,
      사람이 끝 칸을 만지는 순간 — 곧 **범위를 넣겠다는 뜻을 처음 밝히는
      그때** — 만 채운다. 그래서 둘 다 산다.
    ⚠ 위젯 바인딩은 클래스 바인딩보다 **먼저** 돈다(bindtags 차례가
      widget → class). 그래서 목록을 채운 **뒤에** Tk 가 펼침 목록을 연다.
    ⚠ 이미 끝 장이 있으면 **안 건드린다** — 사람이 고른 값을 덮으면 안 된다.
    """
    def _prefill(_e=None):
        if (cb_c2.get() or '').strip():
            return
        ch = (cb_c.get() or '').strip()
        if not ch:
            return
        cb_c2.set(ch)
        if callable(on_fill):
            try:
                on_fill()
            except Exception:
                pass
    for _w in (cb_c2, cb_v2):
        for _ev in ('<Button-1>', '<Down>', '<FocusIn>'):
            try:
                _w.bind(_ev, _prefill, add='+')
            except Exception:
                pass
    return _prefill


if __name__ == '__main__':
    main()
