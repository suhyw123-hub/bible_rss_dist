# -*- coding: utf-8 -*-
"""자산별 **델타** — 지난 판과 견주어 바뀐 것만 보낸다.

★★★ 왜 (2026-09-04 — ⑨). 지금까지 팩은 **통째 교체**였다. 창세기 설명문 한
  줄을 고쳐도 사용자가 **1.49MB 를 다시** 받는다. 자산을 쪼갠 뜻이 절반만
  실현된 상태다.

**스냅샷은 해시만 남긴다**
  ⚠ 자산 175개의 전체 본문을 스냅샷으로 들고 있으면 배포 폴더가 원본만큼
    커진다. ⇒ `{표: {PK: 행 해시}}` 만 남긴다(개역한글 31,104행 ≈ 0.3MB gzip).
    **무엇이 바뀌었나**는 지금 DB 에서 그 행을 다시 읽으면 된다.

★★★ **묘비가 핵심이다** — 삭제를 전파하지 않으면 **지운 것이 사용자에게
  남는다**. 델타에 `deleted`(PK 목록)를 함께 실어 받는 쪽이 걷는다.
  ⚠ 옛 링크 팩도 같은 이유로 묘비를 쓴다(§193차) — 그때는 미디어가 죽으면
    딸린 연결까지 함께 걷어야 했다.

⚠ **첫 판은 델타가 없다** — 스냅샷이 없으면 전체본을 만들라고 말한다(빈 델타를
  만들어 「받았는데 아무것도 안 생기는」 상태를 만들지 않는다).

`--selftest`(의무) · `--delta KIND KEY [LANG] [VARIANT]` · `--snap` · `--list`.
"""
import argparse
import gzip
import hashlib
import io
import json
import os
import sqlite3
import sys
import time

import appdb
import db_pack_body as PB
import db_pack_core as PK

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')
SNAP_DIR = os.path.join(os.path.dirname(__file__), '_pack_snap')


def snap_path(kind, key='-', lang='-', variant='-'):
    os.makedirs(SNAP_DIR, exist_ok=True)
    return os.path.join(SNAP_DIR, PB.pack_name(kind, key, lang, variant)
                        .replace('.json.gz', '.snap.json.gz'))


def _pk_of(conn, table):
    """행을 가리키는 열쇠 칸. PK 없으면 UNIQUE 인덱스(적재기와 같은 규칙)."""
    pk = [r[1] for r in conn.execute("PRAGMA table_info(%s)" % table) if r[5]]
    if pk:
        return pk
    for idx in conn.execute("PRAGMA index_list(%s)" % table):
        if idx[2]:
            return [x[2] for x in conn.execute("PRAGMA index_info(%s)" % idx[1])
                    if x[2]]
    return []


def _row_hash(row):
    return hashlib.sha1(
        json.dumps(row, ensure_ascii=False, default=str).encode('utf-8')
    ).hexdigest()[:16]


def _parts(kind, key):
    """그 자산이 담는 `[(표, sql, argf)]` — **갈래가 조회를 정한다**.

    ★★★ 왜 (2026-09-04 ⑬) — 본문팩은 `db_pack_body.PARTS` 가, **코어팩은
      `db_pack_catalog` 가 정한 표 85개**가 담긴다. 조회가 아예 다르다.
      ⇒ 여기서 갈라 주면 `scan`·`build_delta` 는 **한 벌 그대로** 돈다.
    ⚠ **담는 문과 견주는 문이 같아야 한다** — 코어팩은 `db_pack_core.
      core_tables()` 가 표와 조건을 내므로 그것을 그대로 쓴다. 여기서 표를
      다시 적으면 **코어에 담기는데 델타에는 안 잡히는** 표가 생긴다.
    """
    if (kind or '').upper() == 'CORE':
        import db_pack_core as PK
        out = []
        for t, cond in PK.core_tables():
            sql = "SELECT * FROM %s%s" % (t, (' WHERE ' + cond) if cond else '')
            out.append((t, sql, (lambda k, l, v: [])))
        return out
    return PB.parts_for(kind, key)


def scan(conn, kind, key='-', lang='-', variant='-'):
    """지금 상태 → `{표: {'pk': [칸…], 'rows': {열쇠: 해시}}}`.

    ⚠ 열쇠는 **글자로** 만든다 — JSON 은 튜플을 못 담는다.
    """
    out = {}
    for table, sql, argf in _parts(kind, key):
        pkc = _pk_of(conn, table)
        if not pkc:
            # ⚠ **코어는 표가 85개라 하나가 막히면 전체가 막힌다** — 열쇠 없는
            #   표는 **건너뛰고 이름을 남긴다**(조용히 빠뜨리지 않는다 §0-1).
            #   그 표는 전체본으로만 간다.
            if (kind or '').upper() == 'CORE':
                out.setdefault('__nokey__', {'pk': [], 'rows': {}})
                out['__nokey__']['rows'][table] = ''
                continue
            raise ValueError('%s: 열쇠가 없어 델타를 만들 수 없다' % table)
        cur = conn.execute(sql, argf(key, lang, variant))
        cols = [d[0] for d in cur.description]
        idx = [cols.index(c) for c in pkc if c in cols]
        if len(idx) != len(pkc):
            raise ValueError('%s: 조회에 열쇠 칸이 빠져 있다 %s' % (table, pkc))
        rows = {}
        for r in cur:
            k = '|'.join(str(r[i]) for i in idx)
            rows[k] = _row_hash(list(r))
        out[table] = {'pk': pkc, 'rows': rows}
    return out


def save_snap(snap, path):
    with gzip.open(path, 'wb', compresslevel=6) as f:
        f.write(json.dumps(snap, ensure_ascii=False).encode('utf-8'))
    return path


def load_snap(path):
    if not os.path.exists(path):
        return None
    try:
        with gzip.open(path, 'rb') as f:
            return json.loads(f.read().decode('utf-8'))
    except Exception:
        return None


def diff(old, new):
    """두 스냅샷 → `{표: {'changed': [열쇠…], 'deleted': [열쇠…]}}`."""
    out = {}
    for t, nd in new.items():
        od = (old or {}).get(t) or {'rows': {}}
        orows, nrows = od.get('rows') or {}, nd.get('rows') or {}
        changed = [k for k, h in nrows.items() if orows.get(k) != h]
        deleted = [k for k in orows if k not in nrows]
        if changed or deleted:
            out[t] = {'changed': changed, 'deleted': deleted, 'pk': nd['pk']}
    # ⚠ 표가 통째로 사라진 경우도 잡는다
    for t, od in (old or {}).items():
        if t not in new and (od.get('rows') or {}):
            out[t] = {'changed': [], 'deleted': list(od['rows']),
                      'pk': od.get('pk') or []}
    return out


def build_delta(conn, kind, key='-', lang='-', variant='-', out_dir=None,
                base_version=0, version=1):
    """델타 하나를 만든다 → `{'file','changed','deleted',…}` 또는 `{'msg':…}`.

    ⚠ **스냅샷이 없으면 델타를 안 만든다** — 첫 판은 전체본이어야 한다.
    ⚠ **바뀐 것이 없으면 안 만든다** — 빈 델타는 받는 쪽 이력만 더럽힌다.
    """
    sp = snap_path(kind, key, lang, variant)
    old = load_snap(sp)
    if old is None:
        return {'file': None, 'msg': '지난 판이 없다 — 먼저 전체본을 만드세요'}
    new = scan(conn, kind, key, lang, variant)
    d = diff(old, new)
    n_ch = sum(len(v['changed']) for v in d.values())
    n_del = sum(len(v['deleted']) for v in d.values())
    if not n_ch and not n_del:
        return {'file': None, 'msg': '바뀐 것이 없다', 'changed': 0,
                'deleted': 0}
    out_dir = out_dir or PB.DIST
    os.makedirs(out_dir, exist_ok=True)
    body = {'format': PK.FORMAT, 'delta': True, 'kind': kind, 'key': key,
            'lang': lang, 'variant': variant,
            'base_version': base_version, 'version': version,
            'made_at': time.strftime('%Y-%m-%d %H:%M'), 'tables': {}}
    for t, v in d.items():
        pkc = v['pk']
        entry = {'cols': [], 'rows': [], 'pk': pkc,
                 'deleted': [k.split('|') for k in v['deleted']]}
        if v['changed']:
            # ★ 바뀐 행만 **지금 DB 에서 다시 읽는다**(스냅샷에 본문이 없다)
            sql, argf = None, None
            for tb, s_, a_ in _parts(kind, key):
                if tb == t:
                    sql, argf = s_, a_
                    break
            if not sql:
                continue
            cur = conn.execute(sql, argf(key, lang, variant))
            cols = [dd[0] for dd in cur.description]
            idx = [cols.index(c) for c in pkc]
            want = set(v['changed'])
            entry['cols'] = cols
            for r in cur:
                k = '|'.join(str(r[i]) for i in idx)
                if k in want:
                    entry['rows'].append([PK._enc(x) for x in r])
        body['tables'][t] = entry
    name = PB.pack_name(kind, key, lang, variant).replace(
        '.json.gz', '_d%03d.json.gz' % int(version))
    path = os.path.join(out_dir, name)
    raw = json.dumps(body, ensure_ascii=False).encode('utf-8')
    with gzip.open(path, 'wb', compresslevel=6) as f:
        f.write(raw)
    save_snap(new, sp)                       # 다음 델타의 기준
    return {'file': path, 'bytes': os.path.getsize(path), 'raw': len(raw),
            'changed': n_ch, 'deleted': n_del, 'tables': len(body['tables']),
            'kind': kind, 'key': key, 'lang': lang, 'variant': variant}


def snap_now(conn, kind, key='-', lang='-', variant='-'):
    """지금 상태를 기준으로 잡는다(전체본을 만든 뒤 부른다)."""
    sp = snap_path(kind, key, lang, variant)
    save_snap(scan(conn, kind, key, lang, variant), sp)
    return sp


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', name, extra))

    import shutil
    import tempfile
    d = tempfile.mkdtemp()
    global SNAP_DIR
    _orig_snap = SNAP_DIR
    SNAP_DIR = os.path.join(d, 'snap')          # ⚠ 실 스냅샷을 안 건드린다
    try:
        c = sqlite3.connect(':memory:')
        c.executescript("""
          CREATE TABLE bible_content(verse_id INTEGER, version_code TEXT,
                                     verse_text TEXT,
                                     PRIMARY KEY(verse_id, version_code));
          INSERT INTO bible_content VALUES(1,'KRV','태초에'),(2,'KRV','땅이'),
                                          (3,'KRV','빛이');
        """)
        c.commit()

        r = build_delta(c, 'BIBLE', 'KRV', out_dir=d)
        t('★★ **첫 판은 델타를 안 만든다**(전체본이 먼저)',
          r['file'] is None and '전체본' in r['msg'], r.get('msg', ''))

        snap_now(c, 'BIBLE', 'KRV')
        r = build_delta(c, 'BIBLE', 'KRV', out_dir=d)
        t('★ 바뀐 것이 없으면 안 만든다', r['file'] is None, r.get('msg', ''))

        # 고치고 · 더하고 · 지운다
        c.execute("UPDATE bible_content SET verse_text='고침' WHERE verse_id=1")
        c.execute("INSERT INTO bible_content VALUES(4,'KRV','새 절')")
        c.execute("DELETE FROM bible_content WHERE verse_id=2")
        c.commit()
        r = build_delta(c, 'BIBLE', 'KRV', out_dir=d, version=2)
        t('★★ **바뀐 것과 지운 것을 함께 낸다**',
          r['changed'] == 2 and r['deleted'] == 1,
          '고침·추가 %d · 지움 %d' % (r['changed'], r['deleted']))
        body = PK.read(r['file'])
        t('  델타라고 적혀 있다', body.get('delta') is True)
        tb = body['tables']['bible_content']
        t('  바뀐 행의 본문이 담긴다', len(tb['rows']) == 2, str(len(tb['rows'])))
        t('★★★ **묘비(지운 열쇠)가 담긴다**',
          tb['deleted'] == [['2', 'KRV']], str(tb['deleted']))
        t('  열쇠 칸 이름이 함께 온다', tb['pk'] == ['verse_id', 'version_code'])

        # 델타를 만들면 기준이 옮겨간다
        r2 = build_delta(c, 'BIBLE', 'KRV', out_dir=d, version=3)
        t('★ 델타를 만들면 기준이 옮겨간다(다음엔 없다)', r2['file'] is None,
          r2.get('msg', ''))

        # 크기 — 스냅샷은 해시만
        sp = snap_path('BIBLE', 'KRV')
        snap = load_snap(sp)
        t('★★ 스냅샷은 **해시만** 담는다(본문이 없다)',
          all(len(h) <= 16 for h in snap['bible_content']['rows'].values())
          and '태초' not in json.dumps(snap, ensure_ascii=False))

        # 표가 통째로 빈 경우
        c.execute("DELETE FROM bible_content")
        c.commit()
        r3 = build_delta(c, 'BIBLE', 'KRV', out_dir=d, version=4)
        t('★ 다 지우면 전부 묘비가 된다', r3 and r3.get('deleted') == 3,
          str(r3.get('deleted')))
        c.close()
    finally:
        SNAP_DIR = _orig_snap
        shutil.rmtree(d, ignore_errors=True)

    # 실 DB — 읽기만
    c2 = appdb.connect(DB)
    try:
        s = scan(c2, 'DICT', 'LUTHER_SC', 'EN')
        t('★ 실 DB 를 훑을 수 있다',
          s and sum(len(v['rows']) for v in s.values()) > 0,
          '%d행' % sum(len(v['rows']) for v in s.values()))
        t('  열쇠 칸이 잡힌다',
          all(v['pk'] for v in s.values()), str([v['pk'] for v in s.values()]))
    finally:
        c2.close()
    print('db_pack_delta selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--delta', nargs='+', metavar='ARG')
    ap.add_argument('--snap', nargs='+', metavar='ARG')
    a = ap.parse_args()
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', write_through=True)
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect(DB)
    try:
        if a.snap:
            g = list(a.snap) + ['-'] * 4
            print('기준 잡음: %s' % snap_now(c, g[0], g[1], g[2], g[3]))
        if a.delta:
            g = list(a.delta) + ['-'] * 4
            r = build_delta(c, g[0], g[1], g[2], g[3])
            if not r.get('file'):
                print(r.get('msg'))
            else:
                print('만듦: %s' % r['file'])
                print('  바뀐 행 %s · 지운 행 %s · %.2f MB'
                      % (f"{r['changed']:,}", f"{r['deleted']:,}",
                         r['bytes'] / 1048576))
    finally:
        c.close()


if __name__ == '__main__':
    main()
