"""UI 문자열이 **어디에 쓰이나** — 코드를 훑어 열쇠마다 파일·화면을 찾는다 (2026-10-10 · 1.txt 60-2).

사용자 「각 문자열들이 어떤 화면에서 사용되는지를 알수가 없다 · 일부 문자열은 전혀 처음보는
것들도 있다」. 사람이 적어 두면 화면을 고칠 때마다 틀어진다 — **코드에서 그때 찾는다.**

· `index()` → {열쇠: [상대 경로, …]} — 파이썬(앱·관리자) + 폰 앱(다트). 따옴표 안의 **낱말 전체**만
  맞춘다(부분 일치 없음 — `AI_ANS` 가 `AI_ANS_X` 에 걸리지 않게).
· 접두로 조립하는 열쇠(`'YTS_K_' + code`)는 그 접두를 쓰는 파일로 본다(`prefixes`).
· `screen_of(경로)` → 사람이 읽는 화면 이름. 관리자는 `admin_main` 의 메뉴 표에서 **저절로** 읽고,
  사용자 앱은 아래 `USER_SCREENS` 표다(모르면 파일 이름).
· `used_keys()` → 코드에서 쓰는 열쇠 집합(조립형 포함).

`--selftest`(의무) · `--unused`(안 쓰는 열쇠 수)
"""
import ast
import io
import os
import re
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
SKIP_DIRS = ('참고코드', 'worktrees', '_backup', '.git', '__pycache__', 'build', '.dart_tool', 'node_modules')

USER_SCREENS = {
    'user_main.py': '사용자 앱 (본 화면 전반)',
    'run.py': '시작 절차',
    'splash_screen.py': '시작화면(스플래시)',
    'onboarding.py': '첫 실행 안내',
    'ai_chat_view.py': 'P4 ▸ AI 도우미',
    'ai_result_win.py': 'P4 ▸ AI 도우미 ▸ AI결과 창',
    'kids_view.py': 'P4 ▸ 온라인 영상',
    'entity_browser.py': 'P4 ▸ 주요용어',
    'p4_ref_view.py': 'P4 ▸ 연구/설교노트',
    'p4_node_panel.py': 'P4 ▸ 구절 연결 ▸ 오른쪽 칸',
    'p4_tree.py': 'P4 ▸ 구절 연결 ▸ 캔버스',
    'version_compare_view.py': 'P4 ▸ 역본 비교',
    'pilgrimage_view.py': 'P4 ▸ 믿음의 발자취',
    'figure_tree.py': 'P4 ▸ 메시아 가계도',
    'shop_view.py': 'P4 ▸ 쇼핑몰',
    'commentary_panel.py': 'P2 ▸ 주석',
    'refr_unified_panel.py': 'P2 ▸ 연구/설교노트',
    'links_panel.py': 'P2 ▸ 영상·텍스트',
    'note_refr_panel.py': 'P2 ▸ 묵상노트',
    'p2_one_list.py': 'P2 ▸ 더보기',
    'p2_tab_settings.py': 'P2 ▸ 탭 설정',
    'plan_main_view.py': 'P1 ▸ 묵상플랜',
    'plan_focus_view.py': 'P1 ▸ 묵상플랜 ▸ 진행 화면',
    'user_lens_manager.py': 'P1 ▸ 렌즈묵상',
    'p1_reading_view.py': 'P1 ▸ 도서/설교집',
    'my_path_view.py': 'P1 ▸ 나의 묵상',
    'feedback_view.py': 'P1 ▸ 설정·공지',
    'settings_view.py': 'P1 ▸ 설정',
    'mobile_view.py': '설정 ▸ 모바일 연결',
    'yt_save_view.py': '설정 ▸ 유튜브 간편 저장',
    'yt_save_win.py': '유튜브 간편 저장 알림 창',
    'my_edit.py': 'My Edit 창',
    'link_picker.py': '연결 선택하기 팝업(My Edit)',
    'lang_combo.py': '표시 언어 콤보(여러 화면)',
    'tray_agent.py': '트레이',
    'search.py': '전체 검색',
}


def _walk():
    for root, ds, fs in os.walk(HERE):
        ds[:] = [d for d in ds if not any(x in d for x in SKIP_DIRS)]
        for f in fs:
            if f.endswith('.py') and f.startswith(('temp_', '_')):
                continue
            if f.endswith(('.py', '.dart')):
                yield os.path.join(root, f)


_TOK = re.compile(r"""['"]([A-Z][A-Z0-9_]{1,})['"]""")
_PRE = re.compile(r"""['"]([A-Z][A-Z0-9_]*_)['"]\s*(?:\+|%)|['"]([A-Z][A-Z0-9_]*_)(?:\$|%s|\{)""")
_CACHE = {'at': 0.0, 'idx': None, 'pre': None}


def scan(force=False):
    """→ (index {열쇠: [경로]}, prefixes {접두: [경로]}). 60초 기억한다."""
    if not force and _CACHE['idx'] is not None and time.time() - _CACHE['at'] < 60:
        return _CACHE['idx'], _CACHE['pre']
    idx, pre = {}, {}
    for p in _walk():
        rel = os.path.relpath(p, HERE).replace('\\', '/')
        try:
            s = io.open(p, encoding='utf-8', errors='replace').read()
        except Exception:
            continue
        for k in set(_TOK.findall(s)):
            idx.setdefault(k, []).append(rel)
        for a, b in _PRE.findall(s):
            pre.setdefault(a or b, []).append(rel)
    _CACHE.update(at=time.time(), idx=idx, pre=pre)
    return idx, pre


def where(key):
    """그 열쇠를 쓰는 파일들(조립형이면 접두를 쓰는 파일) → [경로]."""
    idx, pre = scan()
    if key in idx:
        return sorted(set(idx[key]))
    hits = []
    for p, files in pre.items():
        if key.startswith(p) and len(key) > len(p):
            hits += files
    return sorted(set(hits))


def used_keys(keys=None):
    """코드에서 쓰는 열쇠 집합. `keys` 를 주면 그 가운데서만 선택한다."""
    idx, pre = scan()
    if keys is None:
        return set(idx)
    pl = list(pre)
    return {k for k in keys if k in idx or any(k.startswith(p) and len(k) > len(p) for p in pl)}


def _admin_screens():
    """관리자 메뉴 표(`admin_main.TREE_STRUCTURE` · `PANEL_REGISTRY`)에서 파일 → 화면 이름."""
    out = {'admin_main.py': '관리자 앱 (틀)'}
    try:
        src = io.open(os.path.join(HERE, 'admin_main.py'), encoding='utf-8').read()
        tree = ast.parse(src)
        vals = {}
        for node in tree.body:
            if isinstance(node, ast.Assign) and len(node.targets) == 1 and \
                    isinstance(node.targets[0], ast.Name) and node.targets[0].id in ('TREE_STRUCTURE', 'PANEL_REGISTRY'):
                try:
                    vals[node.targets[0].id] = ast.literal_eval(node.value)
                except Exception:
                    pass
        label_of = {}

        def walk(items, path):
            for it in items:
                if isinstance(it, tuple) and len(it) == 2 and isinstance(it[1], list):
                    walk(it[1], path + [it[0]])
                elif isinstance(it, tuple) and len(it) == 2 and isinstance(it[1], str):
                    label_of[it[1]] = ' ▸ '.join(path + [it[0]])
        walk(vals.get('TREE_STRUCTURE') or [], [])
        for key, spec in (vals.get('PANEL_REGISTRY') or {}).items():
            mod = spec[0].replace('.', '/') + '.py'
            if key in label_of:
                prev = out.get(mod)
                nm = '관리자 ▸ ' + label_of[key]
                out[mod] = nm if not prev else prev + ' / ' + label_of[key]
    except Exception:
        pass
    return out


def screen_of(rel):
    rel = rel.replace('\\', '/')
    if rel.startswith('mobile/'):
        return '폰 앱 ▸ ' + os.path.splitext(os.path.basename(rel))[0]
    adm = _admin_screens()
    if rel in adm:
        return adm[rel]
    base = os.path.basename(rel)
    if base in USER_SCREENS and '/' not in rel:
        return USER_SCREENS[base]
    if rel.startswith('admin/'):
        return '관리자 ▸ ' + base
    return base


def screens(key):
    """그 열쇠가 보이는 화면 이름들(겹친 것 하나로)."""
    seen, out = set(), []
    for f in where(key):
        nm = screen_of(f)
        if nm not in seen:
            seen.add(nm)
            out.append(nm)
    return out


def selftest():
    ok, tot = 0, 0

    def t(name, cond, got=''):
        nonlocal ok, tot
        tot += 1
        ok += bool(cond)
        print(('PASS ' if cond else 'FAIL ') + name + ('' if cond else '  ' + str(got)))

    idx, pre = scan(force=True)
    t('코드를 훑었다(열쇠가 많다)', len(idx) > 1000, len(idx))
    t('사용자 앱 문자열 — 유튜브 간편 저장 알림 창', 'yt_save_win.py' in where('YTS_SAVE'), where('YTS_SAVE'))
    t('조립형 열쇠(YTS_K_ + 갈래)도 찾는다', bool(where('YTS_K_SERMON')), where('YTS_K_SERMON'))
    _fake = ''.join(['YTS', '_SAV', 'E_NO', 'PE'])     # 소스에 통째로 안 남게(제 자신을 찾지 않게)
    t('부분 일치 안 함 — 없는 꼬리가 붙은 열쇠는 안 찾는다', where(_fake) == [], where(_fake))
    t('폰 앱(다트)도 훑는다', any(f.endswith('.dart') for fs in idx.values() for f in fs))
    t('관리자 화면 이름을 메뉴 표에서 읽는다',
      '언어 관리' in screen_of('admin/panel_lang_manager.py'), screen_of('admin/panel_lang_manager.py'))
    t('사용자 화면 이름', screen_of('ai_chat_view.py') == 'P4 ▸ AI 도우미')
    t('모르는 파일은 파일 이름', screen_of('zzz_unknown.py') == 'zzz_unknown.py')
    t('시험 파일(temp_)은 안 훑는다', not any(f.startswith('temp_') for fs in idx.values() for f in fs))
    print('%d/%d' % (ok, tot))
    return ok == tot


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    if '--unused' in sys.argv:
        import appdb
        c = appdb.connect()
        ks = [r[0] for r in c.execute('SELECT DISTINCT string_id FROM ui_strings')]
        u = used_keys(ks)
        print('열쇠 %d · 쓰는 것 %d · 안 쓰는 것 %d' % (len(ks), len(u), len(ks) - len(u)))
