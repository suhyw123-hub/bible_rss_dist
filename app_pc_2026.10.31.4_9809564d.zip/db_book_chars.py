# -*- coding: utf-8 -*-
"""db_book_chars.py — 책마다 **본문 글자 수**를 세어 담는다 (영구 도구).

**왜 필요한가.** 서재의 「분량」 필터가 쓸 자가 필요하다. 그런데 그때그때
세면 **788ms**(실측 — 스펄전 설교집만 130MB)라 서재를 열 때마다 멈춘다.
⇒ `sys_book_asset.body_chars` 에 담는다. **35줄짜리 캐시**다.

★★ **이것은 파트가 아니다** (2026-08-24 사용자 「다시는 파트 따위의 설계를
  하지 마라」). 파트는 **본문을 우리가 잘라 만든 가짜 단위**였고, 이것은
  **저자가 쓴 글이 얼마나 되는지 잰 수**다. 새 단위를 만들지 않는다 —
  편(`sys_book_unit`)은 그대로이고 여기에는 자를 것이 없다.

⚠ 쪽수는 **1,800자 = 1쪽**으로 어림한다. 정확한 값이 아니라 **구간을 가르는
  자**다. 실측으로 35권이 7·7·9·9·3 으로 갈린다.

⚠ 책을 새로 넣거나 본문을 다시 적재하면 **`--apply` 를 다시 돌린다.**
  안 돌리면 그 책이 서재 분량 필터에서 「~50쪽」으로 몰린다.

사용:
    python db_book_chars.py --selftest    (의무)
    python db_book_chars.py --check
    python db_book_chars.py --apply       (멱등)
"""
import sys

import appdb

COL = 'body_chars'
CHARS_PER_PAGE = 1800


def ensure_column(conn):
    """`sys_book_asset.body_chars` — 없으면 만든다. 있으면 아무 일도 안 한다."""
    cols = [r[1] for r in conn.execute('PRAGMA table_info(sys_book_asset)')]
    if COL not in cols:
        conn.execute('ALTER TABLE sys_book_asset ADD COLUMN %s INTEGER' % COL)
        conn.commit()
    return COL in [r[1] for r in conn.execute('PRAGMA table_info(sys_book_asset)')]


def measure(conn):
    """`{book_id: 글자 수}` — 본문(ORIGINAL)을 실제로 센다. 느리다(~0.8초)."""
    return {r[0]: (r[1] or 0) for r in conn.execute(
        "SELECT u.book_id, SUM(LENGTH(t.body_text)) "
        "  FROM sys_book_unit u "
        "  JOIN sys_book_unit_text t ON t.unit_id = u.unit_id "
        " WHERE t.text_variant='ORIGINAL' "
        "   AND COALESCE(t.record_status,'LIVE')='LIVE' "
        "   AND COALESCE(u.record_status,'LIVE')='LIVE' "
        " GROUP BY u.book_id")}


def stored(conn):
    if COL not in [r[1] for r in conn.execute('PRAGMA table_info(sys_book_asset)')]:
        return {}
    return {r[0]: r[1] for r in conn.execute(
        'SELECT book_id, %s FROM sys_book_asset' % COL)}


def pages(chars):
    """어림 쪽수. ⚠ 0 은 0 으로 둔다 — 본문이 없는 책과 아주 짧은 책은 다르다."""
    n = int(chars or 0)
    return 0 if n <= 0 else max(1, round(n / CHARS_PER_PAGE))


def apply(conn, verbose=True):
    ensure_column(conn)
    want, have = measure(conn), stored(conn)
    new = fixed = same = 0
    for bid, n in want.items():
        old = have.get(bid)
        if old is None:
            new += 1
        elif old != n:
            fixed += 1
        else:
            same += 1
            continue
        conn.execute('UPDATE sys_book_asset SET %s=? WHERE book_id=?' % COL,
                     (n, bid))
    conn.commit()
    if verbose:
        print('새로 %d · 고침 %d · 그대로 %d' % (new, fixed, same))
    return new, fixed, same


def check(conn):
    want, have = measure(conn), stored(conn)
    bad = [(b, have.get(b), n) for b, n in want.items() if have.get(b) != n]
    print('책 %d권 · 어긋남 %d권' % (len(want), len(bad)))
    for b, o, n in bad[:10]:
        t = conn.execute('SELECT book_code FROM sys_book_asset WHERE book_id=?',
                         (b,)).fetchone()
        print('  %-18s 담긴 값 %s ↔ 실제 %s' % (t[0] if t else b, o, n))
    return not bad


def selftest():
    ok = fail = 0

    def t(n, c, e=''):
        nonlocal ok, fail
        if c:
            ok += 1
        else:
            fail += 1
            print('  FAIL %s  %s' % (n, e))

    # 쪽 환산 — 순수 함수라 DB 없이 잰다
    t('0 자는 0 쪽', pages(0) == 0)
    t('None 도 0 쪽', pages(None) == 0)
    t('아주 짧아도 1쪽', pages(5) == 1)
    t('1,800자 = 1쪽', pages(1800) == 1)
    t('18,000자 = 10쪽', pages(18000) == 10)
    t('단조증가', pages(10000) < pages(100000) < pages(1000000))

    conn = appdb.connect()
    try:
        t('칸이 있다', ensure_column(conn))
        t('두 번 불러도 된다', ensure_column(conn))   # 멱등

        want = measure(conn)
        t('책을 잰다', len(want) >= 1, len(want))
        t('전부 0 은 아니다', any(v > 0 for v in want.values()))

        # ⚠ **데이터 상태에 검사를 걸지 않는다**(§0-5) — 「지금 어긋남 0」이
        #   아니라 **일부러 틀리게 만들고 고쳐지는가**로 잰다.
        bid = next(iter(want))
        real = want[bid]
        orig = stored(conn).get(bid)
        try:
            conn.execute('UPDATE sys_book_asset SET %s=? WHERE book_id=?' % COL,
                         (-99, bid))
            conn.commit()
            t('틀린 값을 잡는다', not check(conn))
            apply(conn, verbose=False)
            t('고쳐진다', stored(conn).get(bid) == real)
            t('고친 뒤엔 깨끗하다', check(conn))
        finally:
            conn.execute('UPDATE sys_book_asset SET %s=? WHERE book_id=?' % COL,
                         (orig if orig is not None else real, bid))
            conn.commit()

        # 멱등 — 두 번째 apply 는 아무것도 안 바꾼다
        apply(conn, verbose=False)
        n2, f2, _s2 = apply(conn, verbose=False)
        t('멱등', n2 == 0 and f2 == 0, (n2, f2))
    finally:
        conn.close()
    print('selftest %d/%d' % (ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect()
    try:
        if '--apply' in a:
            apply(c)
        else:
            ensure_column(c)
            sys.exit(0 if check(c) else 1)
    finally:
        c.close()
