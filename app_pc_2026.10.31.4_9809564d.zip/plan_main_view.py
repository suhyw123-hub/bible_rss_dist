# plan_main_view.py
"""P1 Tab2 묵상플랜 메인 화면.

Left  : 3-section 플랜 목록 (진행중 / 전체읽기 통독 / 주제읽기)
Right : 두 가지 모드 전환
  - 진행중 클릭  → PlanFocusView (embedded, 콤보/등록 버튼 없음)
  - 전체/주제 클릭 → _PlanDetailFrame (플랜 정보 + 등록관리 + 이력)
"""
import json
import i18n
import sqlite3
import appdb
import tkinter as tk
from datetime import date, datetime, timedelta
from tkinter import messagebox, ttk

from plan_focus_view import PlanFocusView

# plan_category 컬럼 기반으로 분류 (DB에서 직접 읽음 — 하드코딩 제거)

_DUR_DAYS  = {'1Y': 365, '2Y': 730, '3Y': 1095}
_DUR_LABEL = {'1Y': '1년', '2Y': '2년', '3Y': '3년'}

_STAGE_KO_PREVIEW = {
    'EVENT': '사건', 'LAW': '율법', 'EXPANSION': '확장',
    'FULFILLMENT': '성취', 'APPLICATION': '적용', 'READ': '읽기',
    'MIRACLE': '기적', 'OT_TYPE': '예표', 'EXPAND': '확장본문',
    'CONFIRM': '확인', 'PSA': '시편', 'PSA_INTRO': '시편서론',
    'CORE': '핵심 말씀', 'AUXILIARY': '보조',
    'RESONANCE': '공명', 'PIVOT': '보조',
    # 도서기반 플랜 전용
    'BOOK_TEXT':  '도서 본문',
    'QUOTED':     '직접 인용',
    'SUPPORT':    '맥락 지지',
    'COMPLEMENT': '보완 읽기',
    'CONTRAST':   '대비 읽기',
}

_TYPE_KO = {
    'SEQUENTIAL':    '순서대로 통독',
    'CHRONOLOGICAL': '연대기 통독',
    'LITURGICAL':    '구속사 절기묵상',
    'MCHEYNE':       '맥체인 통독',
    'BIOGRAPHICAL':  '성경의 인물',
    'SACRIFICIAL':   '제사/예표 묵상',
    'HARMONY':       '복음서 연대순묵상',
    'TYPOLOGICAL':   '복음서 예표묵상',
    'THEMATIC':      '성경의 기적',
    'WORSHIP':       '참예배와 거짓예배',
    'HYBRID':        '복합 묵상',
    'MIRACLE':       '성경의 기적',
    'DIAGNOSTIC':    '회복묵상',
    'PRAYER':        '성경의 기도',
    'SUFFERING':     '성경의 고난',
    'BOOK_BASED':    '도서기반 묵상',
}


# ⚠ 갈래 이름표·진행중 목록은 **`plan_active_bar` 가 단일 소스**다 (2026-08-14).
#   여기에 사본을 두면 네 서브탭의 표기가 또 갈린다 — 그것이 이번 지적의 원인이었다.


# 찜(묵상후보) 표시 — 트리 줄 앞에 붙는다. 같은 폭의 빈 자리는 `_apply_list_font` 가 잰다.
# ★ **별표가 아니다** (2026-08-17 사용자 지시). 별표는 **즐겨찾기(다시읽기)** 의 기호다
#   (렌즈묵상·나의 길이 그렇게 쓴다). 찜(읽을 후보)이 별표를 같이 쓰니 두 개념이
#   섞여 보였다 — 한국 앱들의 관례대로 **찜 = 하트**로 갈랐다.
#   ⚠ 컬러 이모지 금지(§29) — ♥ 는 단색 기하 기호라 괜찮다.
WISH_MARK = '♥ '


class PlanMainView(ttk.Frame):
    """P1 Tab2 묵상플랜 통합 화면."""

    def __init__(self, parent, db_path,
                 lang_getter, version_getter,
                 on_verse_select=None,
                 on_day_complete=None,
                 on_open_plan_tab=None,
                 scope=None,
                 cat_roots=None, cat_hide=None,
                 bar_host=None,
                 on_scope_jump=None, on_wish_change=None, on_wish_jump=None,
                 on_route_jump=None):
        super().__init__(parent)
        self._bar_host = bar_host
        self.on_scope_jump = on_scope_jump
        self.on_route_jump = on_route_jump   # 묵상경로 「다음 걸음」 (2026-08-17)
        # ★ **탭을 가르는 축 = 카테고리** (2026-08-16 사용자 지시, 서브탭 6개).
        #   `scope`(BIBLE/DIAG/BOOK/LENS)로는 더 못 가른다 — 전체읽기·주제읽기·
        #   골라담기가 **전부 BIBLE** 이다. 트리 이름은 이미 `sys_plan_category`
        #   한 표로 모았으므로(2026-08-16) 축만 맞추면 두 곳이 같은 표를 본다.
        #   ⚠ `scope` 인자는 **지우지 않는다** — `PlanFocusView` 가 녹음 단추를
        #     보일지 그 값으로 가르고(§6), 렌즈묵상은 플랜 표를 쓰지도 않는다.
        #   `cat_roots` 는 이 탭이 **꼭대기로 보일 카테고리** 목록(순서대로).
        #   `cat_hide` 는 그 아래에서 **뺄** 카테고리(주제읽기에서 골라담기를 뺀다).
        self.cat_roots = list(cat_roots) if cat_roots else None
        self.cat_hide  = set(cat_hide or ())
        # ★★ 2026-10-15 — **「내 플랜」 탭**(`cat_roots=['MINE']`) — 사용자가 가진 플랜을 **모두 여기 한 곳에**
        #   (만든 것 · 앱 플랜을 수정한 것 · 받은 것 · 골라 담은 것). 다른 탭에는 앱 플랜만 남는다.
        #   목록은 한 줄씩 · 종류 표시(✎ ⧉ ↓ ◇) · 끌어서 차례를 바꾼다(plan_share.get_order/set_order).
        self.mine = (self.cat_roots == ['MINE'])
        self.on_mine_changed = None     # user_main 이 심는다 — (uid, 옮겨 갈까) · 다른 탭에서 내 플랜이 생기면 그 탭으로
        self.on_wish_change = on_wish_change
        self.on_wish_jump = on_wish_jump
        self._wishes: list = []
        self.db_path          = db_path
        self.lang_getter      = lang_getter
        self.version_getter   = version_getter
        self.on_verse_select  = on_verse_select
        self.on_day_complete  = on_day_complete
        self.on_open_plan_tab = on_open_plan_tab
        # [Phase 2-D] scope 필터: None=전체, 'BIBLE'/'DIAG'/'BOOK'/'LENS' 중 하나
        self.scope            = scope

        self._plans: list[dict]  = []
        self._enrolled: list[dict] = []   # list of enr_dict
        self._cat_groups: dict[int, dict] = {}   # sub-cat cat_id → group dict
        self._cat_book_plans: dict[int, list] = {}  # book sub-cat id → [plan_dict]
        self._book_cat_id: int | None = None
        self._expanded_cats: set = set()

        self._build()
        self._load_data()

    # ── UI 구성 ───────────────────────────────────────────────────────────────

    def _build(self):
        pw = tk.PanedWindow(self, orient='horizontal', sashwidth=4, bg='#D5DBDB')
        pw.pack(fill='both', expand=True)

        left = self._build_left()
        pw.add(left, width=200)

        self._right_f = tk.Frame(pw, bg='white')
        pw.add(self._right_f)

        # Mode A: 진행중 플랜 → PlanFocusView (embedded)
        self._focus_view = PlanFocusView(
            self._right_f, self.db_path,
            lang_getter=self.lang_getter,
            version_getter=self.version_getter,
            on_verse_select=self.on_verse_select,
            on_day_complete=self._on_day_complete_internal,
            embedded=True,
            scope=self.scope,      # 녹음 단추를 보일지 여기서 갈린다 (§6)
        )
        # 묵상경로 — 완주 팝업의 「보기」가 이 콜백으로 점프한다 (2026-08-17)
        self._focus_view.on_route_jump = self.on_route_jump
        # 연구자료 쓰기/열기 (2026-08-19 0.txt ⑩) — user_main 이 나중에
        # `view.on_research_new` 를 꽂으므로 **게으른 전달**로 잇는다.
        self._focus_view.on_research_new = lambda ctx: (
            callable(getattr(self, 'on_research_new', None))
            and self.on_research_new(ctx))
        # 그날 묵상노트 [AI 분석] (2026-10-13 76-15) — 같은 게으른 전달
        self._focus_view.on_context = lambda ctx: (
            callable(getattr(self, 'on_context', None)) and self.on_context(ctx))
        self._focus_view.on_note_ai = lambda v, e=None: (
            callable(getattr(self, 'on_note_ai', None)) and self.on_note_ai(v, e))

        # Mode B: 전체/주제 플랜 → 플랜 상세
        # ★ 자산 판 클릭 = 호스트의 만능 점프(user_main 이 view.on_asset_jump
        #   를 심는다 — 늦은 바인딩이라 심기 전 클릭은 조용히 무시)
        self._detail_f = _PlanDetailFrame(
            self._right_f, self.db_path,
            lang_getter=self.lang_getter,
            on_enrolled=self._after_enrollment,
            on_open_focus=self._show_focus_mode,
            on_wish_change=self._refresh_wishes,
            on_route_jump=self.on_route_jump,
        )
        self._detail_f.on_plans_changed = self._plans_changed
        self._detail_f.on_mine_refresh = lambda: (callable(self.on_mine_changed) and self.on_mine_changed(None, False))
        self._detail_f.attach_actions(self._acts, self._place_acts)

        # 초기: placeholder
        self._show_placeholder()

    def _build_left(self):
        f = tk.Frame(self, bg='#FDFEFE')

        import theme_font as _tf
        _tf.list_style('Plan.Treeview', self.db_path)
        _tf.list_style('Enr.Treeview', self.db_path, heading=False)
        s = ttk.Style()
        s.configure('Plan.Treeview',
                    background='#FDFEFE', fieldbackground='#FDFEFE')
        s.configure('Enr.Treeview',
                    background='#EBF5FB', fieldbackground='#EBF5FB')
        s.map('Enr.Treeview', background=[('selected', '#AED6F1')])

        # ── 진행중 플랜: 콤보 ──────────────────────────────────────────────
        # ★ `bar_host` 를 주면 **그 띠 안에** 만든다 (2026-08-14 사용자 지시
        #   「4개 서브탭 헤더 아래 빈 공간에 진행중 콤보, m 매뉴얼 버튼」).
        #   그 띠가 거의 비어 있었고, 콤보는 여기 안쪽에 또 한 줄을 차지하고 있었다.
        if getattr(self, '_bar_host', None) is not None:
            bar = self._bar_host
        else:
            bar = tk.Frame(f, bg='#D6EAF8')
            bar.pack(fill='x')
        # ★ **띠는 `plan_active_bar` 하나가 그린다** (2026-08-14 사용자 지적
        #   「4개 서브탭 콤보에서 표시되는 원리가 서로 다르다」).
        #   목록을 만드는 코드가 여기 안에 있었기 때문에 렌즈묵상은 콤보를 못 가졌고,
        #   자기 갈래 꼬리표를 떼는 규칙 때문에 탭마다 목록이 달라 보였다.
        from plan_active_bar import ActivePlanBar
        self._enr_bar = ActivePlanBar(bar, self.db_path,
                                      lang_getter=self.lang_getter,
                                      on_pick=self._on_enr_pick,
                                      on_font=self._open_font)
        self._enr_combo = self._enr_bar.combo      # 기존 호출부가 쓰는 이름
        self._enr_var = self._enr_bar.var

        # ★ 2026-10-15 사용자 「복사후수정 / 내보내기 / 가져오기 / 내플랜수정 / 내플랜삭제 등의 버튼을
        #   Font 버튼 오른쪽에 · Font 버튼과 서식 통일 · 다국어 길이를 고려」.
        #   모양 = `ui_theme.flat_btn`(Font 와 같은 단일 소스) · 이름은 짧게(B 열쇠) ·
        #   띠가 모자라면 진행중 콤보를 줄인다(`_fit_bar`). 고른 플랜에 따라 상세 화면이 보인다/감춘다.
        # ★ 2026-10-15 88-4 — 단추 줄 대신 **사용자 모드 콤보**(M 왼쪽 · `plan_active_bar.ModeCombo`).
        #   사용자 「사용자모드 사용할 가능성이 높지 않은데 버튼 방식은 시각적으로 불편하다」.
        #   띠 = [진행중 콤보] …(여백) Font …(여백) [원본 가리기][원본 표시하기] [사용자 모드 ▾] M.
        #   상세 화면은 종전처럼 `acts[k].config(command=…)` · `place(keys)` 로 말한다.
        from plan_active_bar import ModeCombo
        self._act_bar = bar
        self._mode = ModeCombo(bar, always=('new', 'import') if self.mine else ('import',))
        self._mode.NAMES = dict(ModeCombo.NAMES, new=('PMV_NEW_PLAN', '새 플랜 만들기'))
        self._mode.pack()
        self._acts = self._mode.acts
        self._acts['import'].config(command=self._import_file)
        self._acts['new'].config(command=self._open_wizard)
        self._place_acts(())
        bar.bind('<Configure>', lambda _e: self.after_idle(self._fit_bar), add='+')

        tk.Frame(f, bg='#AED6F1', height=1).pack(fill='x')

        # ── 섹션 2: 전체플랜 (트리뷰 — 전체읽기/주제읽기 항상 펼침) ──
        # ⚠ 「전체플랜」 라벨을 없앴다 (2026-08-14 사용자 지시). 목록을 보면 아는 것을
        #   한 줄 더 쓰고 있었다.

        tree_wrap = tk.Frame(f, bg='#FDFEFE')
        tree_wrap.pack(fill='both', expand=True)
        tree_wrap.grid_rowconfigure(0, weight=1)
        tree_wrap.grid_columnconfigure(0, weight=1)

        vsb = ttk.Scrollbar(tree_wrap, orient='vertical')
        vsb.grid(row=0, column=1, sticky='ns')

        self._plan_tv = ttk.Treeview(tree_wrap, show='tree', selectmode='browse',
                                      style='Plan.Treeview',
                                      yscrollcommand=vsb.set)
        vsb.config(command=self._plan_tv.yview)
        self._plan_tv.grid(row=0, column=0, sticky='nsew')
        # ★ **글꼴을 박지 않는다** (2026-08-14 사용자 지적 「왼쪽 패널은 폰트가
        #   적용되지 않았다. 4개 서브탭에서 모두 같은 현상」).
        #   태그에 `font=` 를 박으면 `Plan.Treeview` 스타일을 **이겨 버려** 통합 폰트
        #   「목록」 역할이 닿지 않는다. 굵기만 남기고 크기·글꼴은 역할에 맡긴다.
        self._plan_tv.tag_configure('cat', foreground='#1A5276')
        self._apply_list_font()
        self._plan_tv.bind('<<TreeviewSelect>>', self._on_plan_click)

        return f

    def _place_acts(self, keys):
        """사용자 모드 콤보 항목 + 원본 단추 — `keys` 에 든 것만(가져오기는 늘)."""
        self._mode.place(keys)
        self.after_idle(self._fit_bar)

    def _fit_bar(self):
        """띠가 모자라면 진행중 콤보를 줄인다(넉넉하면 다시 34자로). 값이 같으면 손대지 않는다."""
        try:
            bar = self._act_bar
            W = bar.winfo_width()
            if W <= 1:
                return
            import tkinter.font as tkf
            cb = self._enr_combo
            others = sum(w.winfo_reqwidth() + 12 for w in bar.pack_slaves() if w is not cb)
            ch = max(tkf.nametofont('TkDefaultFont').measure('0'), 6)
            want = int(max(12, min(34, (W - others - 30) / ch)))
            if int(cb.cget('width')) != want:
                cb.config(width=want)
        except Exception:
            pass

    def _import_file(self):
        import my_plan_edit
        new = my_plan_edit.import_dialog(self.winfo_toplevel(), self.db_path)
        if new:
            self._plans_changed(new[-1])

    # ── 데이터 로딩 ───────────────────────────────────────────────────────────

    def _load_data(self):
        self._load_plans()
        self._load_enrolled()

    def _load_plans(self):
        lang = self.lang_getter()
        self._plans       = []
        self._total_plans = []
        self._theme_plans = []
        self._book_plans  = []
        self._cat_groups  = {}
        self._theme_cats  = []      # 주제읽기 하위 묶음 (2026-08-16)
        self._cat_book_plans = {}
        self._book_cat_id = None

        _CAT_ICONS = {1: '', 2: '', 3: '', 4: ''}

        cats: dict[int, dict] = {}
        root_cats: list[dict] = []

        try:
            with appdb.connect(self.db_path) as conn:
                # 1. 카테고리 계층 + 이름
                #    ⚠ `cat_roots` 를 받았으면 **전부 읽는다** — 골라담기(216)는
                #      주제읽기의 자식이라 뿌리만 읽어서는 못 찾는다.
                if self.cat_roots:
                    cat_rows = conn.execute(
                        "SELECT c.cat_id, c.parent_id, c.sort_order, t.contents "
                        "FROM sys_plan_category c "
                        "LEFT JOIN sys_text_asset t "
                        "  ON t.text_type='PLAN_CAT_NAME' AND t.clicked_id=c.cat_id "
                        "  AND UPPER(t.lang_code)=UPPER(?) AND t.record_status='LIVE' "
                        "WHERE c.record_status='LIVE' "
                        "ORDER BY COALESCE(c.parent_id, c.cat_id), c.sort_order",
                        (lang,)
                    ).fetchall()
                elif self.scope:
                    cat_rows = conn.execute(
                        "SELECT c.cat_id, c.parent_id, c.sort_order, t.contents "
                        "FROM sys_plan_category c "
                        "LEFT JOIN sys_text_asset t "
                        "  ON t.text_type='PLAN_CAT_NAME' AND t.clicked_id=c.cat_id "
                        "  AND UPPER(t.lang_code)=UPPER(?) AND t.record_status='LIVE' "
                        "WHERE c.record_status='LIVE' AND c.scope=? "
                        "ORDER BY COALESCE(c.parent_id, c.cat_id), c.sort_order",
                        (lang, self.scope)
                    ).fetchall()
                else:
                    cat_rows = conn.execute(
                        "SELECT c.cat_id, c.parent_id, c.sort_order, t.contents "
                        "FROM sys_plan_category c "
                        "LEFT JOIN sys_text_asset t "
                        "  ON t.text_type='PLAN_CAT_NAME' AND t.clicked_id=c.cat_id "
                        "  AND UPPER(t.lang_code)=UPPER(?) AND t.record_status='LIVE' "
                        "WHERE c.record_status='LIVE' "
                        "ORDER BY COALESCE(c.parent_id, c.cat_id), c.sort_order",
                        (lang,)
                    ).fetchall()
                # 이름 누락 시 EN 우선 폴백 (그다음 KO)
                ko_fallback: dict[int, str] = {}
                if lang.upper() not in ('KO', 'EN'):
                    for r in conn.execute(
                        "SELECT c.cat_id, "
                        "  (SELECT t.contents FROM sys_text_asset t "
                        "    WHERE t.text_type='PLAN_CAT_NAME' AND t.clicked_id=c.cat_id "
                        "      AND t.lang_code IN ('EN','KO') AND t.record_status='LIVE' "
                        "    ORDER BY CASE t.lang_code WHEN 'EN' THEN 0 ELSE 1 END LIMIT 1) "
                        "FROM sys_plan_category c WHERE c.record_status='LIVE'"
                    ).fetchall():
                        ko_fallback[r[0]] = r[1] or ''

                for cat_id, parent_id, sort_order, name in cat_rows:
                    name = name or ko_fallback.get(cat_id, f'카테고리{cat_id}')
                    cats[cat_id] = dict(cat_id=cat_id, parent_id=parent_id,
                                        sort_order=sort_order, name=name,
                                        children=[], plans=[])
                for d in cats.values():
                    if d['parent_id'] is None:
                        root_cats.append(d)
                    else:
                        p = cats.get(d['parent_id'])
                        if p:
                            p['children'].append(d)
                root_cats.sort(key=lambda c: c['sort_order'])
                # ★ 이 탭이 보일 꼭대기 — **적어 준 순서 그대로** (2026-08-16).
                #   `sort_order` 로 다시 정렬하지 않는다. 탭마다 하나씩이라
                #   순서가 곧 사용자가 정한 것이다.
                if self.cat_roots:
                    root_cats = [cats[cid] for cid in self.cat_roots if cid in cats]
                for d in cats.values():
                    d['children'].sort(key=lambda ch: ch['sort_order'])

                # 2. 플랜 목록
                rows = conn.execute(
                    "SELECT plan_id, plan_code, plan_type, duration_days, plan_config, "
                    "       COALESCE(plan_category, 'THEMATIC'), cat_id "
                    "FROM sys_bible_plan WHERE record_status='LIVE' "
                    "ORDER BY COALESCE(sort_order, plan_id*10), plan_id"
                ).fetchall()
                # ★ 2026-10-15 — 내가 수정한(복사한) 플랜이 「원본 가리기」면 원래 플랜은 목록에서 뺀다
                try:
                    import copy_own as _co
                    _hid = _co.hidden_sys_ids(conn, 'PLAN')
                except Exception:
                    _hid = set()
                if _hid:
                    rows = [r for r in rows if r[0] not in _hid]

                # ⚠ `origin_plan_id` 를 함께 읽는다 — 그 기원이 속한 묶음에 붙이려면 필요하다
                user_plan_rows = conn.execute(
                    "SELECT user_plan_id, plan_code, plan_type, duration_days, plan_config, "
                    "       COALESCE(plan_category, 'THEMATIC'), origin_plan_id "
                    "FROM user_bible_plan WHERE record_status='LIVE' ORDER BY user_plan_id"
                ).fetchall()

                if not self.mine:
                    user_plan_rows = []         # ★ 내 플랜은 「내 플랜」 탭에만(2026-10-15)
                # 사용자 플랜의 기원(sys) → 그 플랜이 속한 묶음
                conn_plan_cat = conn.execute(
                    "SELECT plan_id, cat_id FROM sys_bible_plan "
                    "WHERE cat_id IS NOT NULL").fetchall()

                # ★ 2026-10-14 사용자 「아직도 플랜 정보가 없는 것들이 있다」 — 그 언어 글이 없으면 칸이 비었다.
                #   플랜마다 고른 언어 → EN → KO 로 물러선다(언어 하나만 빠져도 빈 칸이 되지 않게).
                _all: dict = {}
                for cid, ttype, lg, val in conn.execute(
                        "SELECT clicked_id, text_type, UPPER(lang_code), contents FROM sys_text_asset "
                        "WHERE text_type IN ('PLAN_TITLE','PLAN_DESC') AND record_status='LIVE' "
                        "AND TRIM(COALESCE(contents,''))<>''").fetchall():
                    _all.setdefault((cid, ttype), {})[lg] = val
                _L = (lang or 'KO').upper()
                txt_map: dict = {}
                for k, by in _all.items():
                    txt_map[k] = by.get(_L) or by.get('EN') or by.get('KO') or next(iter(by.values()))

                # ★ 2026-10-14 87 — 내 플랜의 이름·설명은 user_text_asset(PLAN_TITLE·PLAN_DESC · plan_share 가 적는다)
                _utxt = {}
                for cid, ttype, val in conn.execute(
                        "SELECT clicked_id, text_type, contents FROM user_text_asset WHERE text_type IN "
                        "('PLAN_TITLE','PLAN_DESC') AND COALESCE(record_status,'LIVE')<>'HIDE' "
                        "AND TRIM(COALESCE(contents,''))<>'' ORDER BY user_text_id").fetchall():
                    _utxt[(cid, ttype)] = val
                book_rows = self._load_book_plan_map(conn)
                all_books = self._load_all_books(conn)

                # DIAG/BOOK/TOTAL 루트 cat_id를 DB에서 동적 탐색
                _diag_sample = conn.execute(
                    "SELECT cat_id FROM sys_bible_plan WHERE plan_type='DIAGNOSTIC' "
                    "AND record_status='LIVE' AND cat_id IS NOT NULL LIMIT 1"
                ).fetchone()
                _book_sample = conn.execute(
                    "SELECT cat_id FROM sys_bible_plan WHERE plan_type='BOOK_BASED' "
                    "AND record_status='LIVE' AND cat_id IS NOT NULL LIMIT 1"
                ).fetchone()
                _total_sample = conn.execute(
                    "SELECT cat_id FROM sys_bible_plan WHERE plan_category='TOTAL' "
                    "AND record_status='LIVE' AND cat_id IS NOT NULL LIMIT 1"
                ).fetchone()
        except Exception:
            rows = []
            user_plan_rows = []
            conn_plan_cat = []
            txt_map = {}
            _utxt = {}
            book_rows = []
            all_books = []
            _diag_sample = _book_sample = _total_sample = None

        # root_ancestor_id 계산 헬퍼
        def _root_of(cid: int) -> int | None:
            if cid not in cats:
                return None
            seen: set[int] = set()
            while True:
                seen.add(cid)
                pid = cats[cid]['parent_id']
                if pid is None or pid not in cats or pid in seen:
                    return cid
                cid = pid

        for d in cats.values():
            d['root_ancestor_id'] = _root_of(d['cat_id'])

        DIAG_CAT_ID   = _root_of(_diag_sample[0])  if _diag_sample  and _diag_sample[0]  in cats else None
        BOOK_CAT_ID   = _root_of(_book_sample[0])   if _book_sample  and _book_sample[0]  in cats else None
        total_root_id = _root_of(_total_sample[0])  if _total_sample and _total_sample[0] in cats else None
        theme_root_id = 2   # 주제읽기 뿌리 (2026-08-16)

        self._book_cat_id = BOOK_CAT_ID
        seen_groups: dict[str, dict] = {}

        for plan_id, code, ptype, dur, cfg_json, category, cat_id in rows:
            title = txt_map.get((plan_id, 'PLAN_TITLE')) or code
            desc  = txt_map.get((plan_id, 'PLAN_DESC'))  or ''
            cfg   = json.loads(cfg_json) if cfg_json else {}
            p = dict(plan_id=plan_id, code=code, ptype=ptype,
                     duration_days=dur, title=title, desc=desc, cfg=cfg,
                     category=category, cat_id=cat_id)
            self._plans.append(p)

            plan_root = _root_of(cat_id) if cat_id else None
            # ★★ **자가진단도 도서와 같은 길로 간다** (2026-08-30 사용자 지시
            #   「자가진단 관련된 것 모두 제거해도 좋다 · 사용자가 직접 선택하도록」).
            #   ⚠ 그전에는 `sys_diagnosis_track`·`sys_diagnosis_phase` 두 표로
            #     축(FAITH/PSY)을 따로 세웠는데, 실측하니 **`sys_plan_category` 와
            #     완전히 겹쳤다** — cat 9 신앙진단 5개 · cat 8 심리감정진단 5개가
            #     축 그대로다. 같은 것을 두 곳에 두면 갈라진다.
            if plan_root is not None and plan_root in (BOOK_CAT_ID, DIAG_CAT_ID):
                # 카테고리별로 플랜 분류 (도서기반 · 자가진단)
                if cat_id is not None and cat_id in cats:
                    cats[cat_id]['plans'].append(p)
                if cat_id is not None:
                    if cat_id not in self._cat_book_plans:
                        self._cat_book_plans[cat_id] = []
                    self._cat_book_plans[cat_id].append(p)
            elif (cat_id is not None and cat_id in cats
                  and cats[cat_id]['parent_id'] is not None):
                # ★ **하위 카테고리에 속하면 어느 뿌리든 카테고리로 묶는다** (2026-08-16).
                #   예전에는 `plan_root == total_root_id` 라 **전체읽기만** 이 길로 왔고,
                #   주제읽기는 아래 `plan_type` 묶음으로 떨어져 트리 이름이 두 곳에서
                #   나왔다(`sys_plan_category` ↔ `ui_strings.PLANTYPE_*`).
                cats[cat_id]['plans'].append(p)
            else:
                # 대분류 직속 플랜 — 주제읽기 등, ptype 기준으로 그룹핑
                if ptype not in seen_groups:
                    seen_groups[ptype] = dict(ptype=ptype, label=i18n.t('PLANTYPE_'+str(ptype), _TYPE_KO.get(ptype, ptype)),
                                              plans=[], category=category, cat_id=cat_id)
                seen_groups[ptype]['plans'].append(p)

        # user_bible_plan (파생 플랜) — THEMATIC 그룹에 포함
        # 기원 sys 플랜의 cat_id 를 미리 모아 둔다
        _origin_cat = {r[0]: r[1] for r in conn_plan_cat} if conn_plan_cat else {}
        for uid, code, ptype, dur, cfg_json, category, origin_id in user_plan_rows:
            cfg = json.loads(cfg_json) if cfg_json else {}
            ocat = _origin_cat.get(origin_id)
            # ⚠ `origin_plan_id` 를 **그대로 들고 간다** — 트리가 이 값으로 사용자
            #   플랜을 기원 sys 플랜 아래에 접어 넣는다(`_render_theme_group`).
            #   예전에는 카테고리로 한 번 접고 버려서 「어느 앵커에서 나왔나」를 잃었다.
            p = dict(plan_id=None, user_plan_id=uid, code=code, ptype=ptype,
                     duration_days=dur or 0, title=_utxt.get((uid, 'PLAN_TITLE')) or code,
                     # ★ 내가 만든 플랜은 제 설명이 없으면 — 그 플랜을 만든 바탕 플랜의 설명을 보인다(2026-10-14)
                     desc=_utxt.get((uid, 'PLAN_DESC')) or txt_map.get((origin_id, 'PLAN_DESC')) or '', cfg=cfg,
                     category=category or 'THEMATIC', cat_id=ocat,
                     origin_plan_id=origin_id)
            self._plans.append(p)
            # ★ **기원이 속한 묶음에 붙인다** (2026-08-16). 사용자 플랜은 sys 앵커에서
            #   파생된 조립 결과다 — 최상위에 `plan_type` 이름으로 올리면 sys 묶음과
            #   글자까지 같아져 무엇이 무엇인지 알 수 없다(실제로 그랬다).
            if (ocat is not None and ocat in cats
                    and cats[ocat]['parent_id'] is not None):
                cats[ocat]['plans'].append(p)
                continue
            # ⚠ 기원을 못 찾으면 종전대로 — 조용히 사라지지 않게
            if ptype not in seen_groups:
                seen_groups[ptype] = dict(ptype=ptype, label=i18n.t('PLANTYPE_'+str(ptype), _TYPE_KO.get(ptype, ptype)),
                                          plans=[], category=category or 'THEMATIC',
                                          cat_id=None)
            seen_groups[ptype]['plans'].append(p)

        # _book_plans 빌드 — 플랜 없는 도서도 모두 표시
        book_map: dict = {}
        for book_id, book_code, book_title, author, lang_code, ctype in all_books:
            book_map[book_id] = dict(book_id=book_id, book_code=book_code,
                                      book_title=book_title, author=author,
                                      lang_code=lang_code, copyright_type=ctype,
                                      plans=[])
        for plan_id, book_id, book_code, book_title, author, lang_code in book_rows:
            if book_id in book_map:
                plan = next((pl for pl in self._plans if pl['plan_id'] == plan_id), None)
                if plan:
                    book_map[book_id]['plans'].append(plan)
        self._book_plans = list(book_map.values())

        # sub-category → _total_plans + _cat_groups
        total_root = cats.get(total_root_id) if total_root_id else None
        for child in (total_root['children'] if total_root else []):
            # ★ 2026-10-15 — 내 플랜은 **기간 고르기(1·2·3년)에 섞지 않고** 묶음 아래 제 줄로 보인다.
            #   섞여 있으면 목록에 줄이 안 생겨 「복사했는데 안 보인다」(사용자 신고 · 실측).
            plans_in_child = [p for p in child['plans'] if not p.get('user_plan_id')]
            mine_in_child = [p for p in child['plans'] if p.get('user_plan_id')]
            ptype = plans_in_child[0]['ptype'] if plans_in_child else 'SEQUENTIAL'
            category = plans_in_child[0]['category'] if plans_in_child else 'TOTAL'
            group = dict(ptype=ptype, label=child['name'],
                         plans=plans_in_child, category=category,
                         cat_id=child['cat_id'], mine=mine_in_child)
            self._total_plans.append(group)
            self._cat_groups[child['cat_id']] = group

        # ★ **주제읽기 하위 묶음도 `_cat_groups` 에 올린다** (2026-08-16).
        #   클릭 처리(`_on_plan_click`)가 `CAT_<id>` 를 이 표에서 찾는다.
        #   ★ 2026-08-16 서브탭 6개 — **어느 뿌리의 자식이든** 담는다. 예전에는
        #     `theme_root_id`(=2) 자식만 담아서, 골라담기(216)를 제 탭의 꼭대기로
        #     올리면 그 안이 비었다. `parent_id` 를 함께 넣어 그릴 때 가른다.
        self._theme_cats = []
        _root_ids = {c['cat_id'] for c in root_cats}
        for child in cats.values():
            if child['parent_id'] is None or child['cat_id'] in _root_ids:
                continue                      # 꼭대기는 여기서 다루지 않는다
            if child['cat_id'] in self.cat_hide:
                continue                      # 다른 탭으로 올라간 묶음
            plans_in_child = child['plans']
            if not plans_in_child:
                continue                      # 플랜 없는 묶음은 감춘다
            group = dict(ptype=plans_in_child[0]['ptype'], label=child['name'],
                         plans=plans_in_child,
                         category=plans_in_child[0]['category'],
                         cat_id=child['cat_id'], parent_id=child['parent_id'],
                         sort_order=child['sort_order'])
            self._theme_cats.append(group)
            self._cat_groups[child['cat_id']] = group
        self._theme_cats.sort(key=lambda g: (g['sort_order'], g['cat_id']))

        # ★ 꼭대기 자체가 묶음인 경우 — 골라담기 탭처럼 **자식 카테고리가 없고
        #   플랜이 바로 달린** 마디. 클릭 처리도 `_cat_groups` 를 보므로 함께 올린다.
        for rc in root_cats:
            if rc['cat_id'] in self._cat_groups or not rc['plans']:
                continue
            self._cat_groups[rc['cat_id']] = dict(
                ptype=rc['plans'][0]['ptype'], label=rc['name'],
                plans=rc['plans'], category=rc['plans'][0]['category'],
                cat_id=rc['cat_id'], parent_id=rc['parent_id'],
                sort_order=rc['sort_order'])

        # seen_groups → _theme_plans (대분류 **직속** 플랜 — 아직 묶음이 없는 것)
        for g in seen_groups.values():
            self._theme_plans.append(g)

        # ★★ **이름 짓는 재료를 플랜에 실어 둔다** (2026-08-30). 상세 프레임은
        #   카테고리 표를 갖고 있지 않아 「1년」을 그대로 그렸다 — 정경순서인지
        #   연대기인지 알 수 없었다(사용자 신고). 여기서 한 번 계산해 넘긴다.
        try:
            import plan_label
            _dup = plan_label.mark_ambiguous([x.get('title') for x in self._plans])
            for _p in self._plans:
                _g = self._cat_groups.get(_p.get('cat_id')) or {}
                _p['group_label'] = _g.get('label')
                _p['ambiguous'] = (_p.get('title') or '').strip() in _dup
        except Exception as e:
            print('[plan label] %s' % e)

        # ── 트리뷰 빌드 ──────────────────────────────────────────────────────────
        self._plan_tv.delete(*self._plan_tv.get_children())
        self._expanded_cats = set()      # 자식을 펼친 묶음 — 눌러도 플랜을 안 고른다

        for root_cat in ([] if self.mine else root_cats):
            cat_id = root_cat['cat_id']
            icon   = _CAT_ICONS.get(cat_id, '')

            # ★ 이름의 주인은 `sys_plan_category` 하나다 — 자가진단만 별도
            #   ui_strings 열쇠를 보던 특례를 걷었다(2026-08-30).
            node_text = f'{icon} {root_cat["name"]}'

            # ★ **서브탭 이름과 같은 꼭대기는 그리지 않는다** (2026-08-16 사용자 지시
            #   「서브탭 제목과 동일한 내용을 트리의 1순위 카테고리로 반복할 필요가 없다」).
            #   탭이 「전체읽기」인데 그 안 첫 줄이 또 「전체읽기플랜」이었다.
            #   ⚠ 여섯 탭 방식(`cat_roots`)에서만 뗀다 — 옛 방식은 한 탭에 뿌리가
            #     여럿이라 그 줄이 있어야 무엇의 묶음인지 안다.
            if self.cat_roots:
                cat_node = ''            # 트리 뿌리에 바로 붙인다
            else:
                cat_node = self._plan_tv.insert('', 'end', iid=f'CAT_{cat_id}',
                                                text=node_text, open=True,
                                                tags=('cat',))

            if cat_id == total_root_id:
                # 전체읽기: 소분류를 그룹 노드로 표시
                for group in self._total_plans:
                    sub_id = group['cat_id']
                    mine = group.get('mine') or []
                    self._plan_tv.insert(cat_node, 'end', iid=f'CAT_{sub_id}',
                                          text=group['label'], tags=('item',), open=bool(mine))
                    for up in mine:
                        self._plan_tv.insert(f'CAT_{sub_id}', 'end',
                                             iid='THEME_PLAN_U%s' % up['user_plan_id'],
                                             text=up['title'], tags=('item',))

            elif cat_id in (BOOK_CAT_ID, DIAG_CAT_ID):
                # 카테고리 계층으로 표시 (도서기반 · 자가진단)
                book_root = cats.get(cat_id)
                for child in (book_root['children'] if book_root else []):
                    child_id = child['cat_id']
                    child_plans = self._cat_book_plans.get(child_id, [])
                    if not child_plans:
                        continue  # LIVE 플랜 없는 카테고리 숨김
                    child_iid = f'CAT_{child_id}'
                    self._plan_tv.insert(cat_node, 'end', iid=child_iid,
                                          text=child['name'],
                                          tags=('item',), open=True)
                    # ⚠ **차례가 뜻을 가진다** — 자가진단 다섯은 단계(1~5)다.
                    #   축 표를 걷은 뒤 순서가 흐트러져 45·42·44… 로 나왔다(실측).
                    if len(child_plans) > 1:
                        for bp in sorted(child_plans, key=lambda x: x['plan_id']):
                            self._plan_tv.insert(child_iid, 'end',
                                                  iid=f'BOOK_PLAN_{bp["plan_id"]}',
                                                  text=bp['title'],
                                                  tags=('item',))

            else:
                # ★ **하위 묶음을 먼저** 그린다 (2026-08-16) — 카테고리 표가 이름의 주인.
                # ★ **이 꼭대기의 자식 묶음만** 그린다 (2026-08-16 서브탭 6개).
                #   예전에는 `_theme_cats` 를 통째로 쏟아부어서, 탭이 여럿이 되면
                #   남의 묶음까지 딸려 왔다.
                subs = [g for g in getattr(self, '_theme_cats', [])
                        if g.get('parent_id') == cat_id]
                for group in subs:
                    g_iid = 'CAT_%d' % group['cat_id']
                    self._plan_tv.insert(cat_node, 'end', iid=g_iid,
                                         text=group['label'],
                                         tags=('item',), open=True)
                    self._render_theme_group(g_iid, group)
                # 자식 묶음이 없으면 **이 마디가 곧 묶음**이다 (골라담기 탭).
                if not subs and cat_id in self._cat_groups:
                    self._render_theme_group(cat_node, self._cat_groups[cat_id])
                # 아직 묶음이 없는 직속 플랜은 종전대로 `plan_type` 으로
                for g in self._theme_plans:
                    if g.get('cat_id') is None or _root_of(g['cat_id']) == cat_id:
                        iid_key = f"GROUP_{g['ptype']}_{cat_id}"
                        if not self._plan_tv.exists(iid_key):
                            self._plan_tv.insert(cat_node, 'end',
                                                  iid=iid_key,
                                                  text=g['label'], tags=('item',))

        # ★ 2026-10-15 — 아직 어디에도 안 그려진 내 플랜을 그 묶음(기원 플랜이 든 줄) 아래에 붙인다.
        #   자가진단·도서 묶음은 그리는 방식이 달라 복사한 플랜이 줄을 못 얻었다.
        if self.mine:
            self._render_mine()
        else:
            # ★ 2026-10-15 — 줄을 끌어 차례를 바꾼다(같은 묶음 안에서 · 탭마다 따로 기억 · tree_reorder)
            try:
                import tree_reorder
                _k = 'TREE_ORDER_PLAN_' + '_'.join(str(x) for x in (self.cat_roots or [self.scope or 'ALL']))
                tree_reorder.enable(self._plan_tv, _k, self.db_path)
                tree_reorder.apply(self._plan_tv, _k, self.db_path)
            except Exception as e:
                print('[plan reorder] %s' % e)
        for up in ([] if self.mine else self._plans):
            uid = up.get('user_plan_id')
            if not uid or self._plan_tv.exists('THEME_PLAN_U%s' % uid):
                continue
            host = None
            for cand in ('BOOK_PLAN_%s' % up.get('origin_plan_id'), 'THEME_PLAN_%s' % up.get('origin_plan_id'),
                         'CAT_%s' % up.get('cat_id')):
                if self._plan_tv.exists(cand):
                    host = cand
                    break
            if host:
                self._plan_tv.insert(host, 'end', iid='THEME_PLAN_U%s' % uid,
                                     text=up['title'], tags=('item',))
                self._plan_tv.item(host, open=True)

        # ★ 찜한 플랜에 **★ 표시** (2026-08-16). 목록 자체는 상단 단추 → 팝업이다.
        self._mark_wishes()

    def _mark_wishes(self):
        """플랜 줄 표식 — 매트릭스(◐ 진행중·★ 완료∧찜·● 완료·♥ 찜·○ 미시작).

        ⚠ **트리를 다 그린 뒤 한 번에** 훑는다. 가지마다 글자를 짓는 곳이 달라서
          (전체읽기·자가진단·도서·주제) 각각 고치면 반드시 하나를 빠뜨린다.
        ⚠ 목록 자체를 트리에 넣지 않는다 — 2026-08-16 에 「☆ 묵상후보」 마디를
          맨 아래에 넣어 봤는데 사용자가 **「이상하다」**고 했다. 트리는 **플랜의
          분류**를 보이는 자리인데 거기 성격이 다른 묶음이 끼어든 것이다.
          ⇒ 목록은 **상단 단추 → 팝업**, 트리에는 **표시만**.
        """
        self._wishes = []               # 묵상후보 걷음(76-4) — 옛 이름만 남긴다

        def _keys(plans):
            return [(('U', p['user_plan_id']) if p.get('user_plan_id')
                     else ('S', p.get('plan_id'))) for p in plans or ()]

        def _key_of_iid(iid):
            """그 줄이 가리키는 플랜들(여러 기간이 한 줄이면 여럿). 플랜이 아니면 None.

            ★ 2026-10-13 docs/1.txt 76-1 — 전체읽기의 정경순서·연대기 통독은 **1·2·3년 셋이 한 줄**
              이라 예전 규칙(「플랜이 하나뿐인 묶음만」)에 안 걸려 표식이 없었다(맥체인만 하나라 붙었다).
              ⇒ 묶음 줄은 **그 안 플랜 어느 것이든** 진행중이면 ◐ · 끝냈으면 ● 로 본다."""
            if iid.startswith('THEME_PLAN_U'):
                return [('U', int(iid[len('THEME_PLAN_U'):]))]
            for pre in ('THEME_PLAN_', 'BOOK_PLAN_'):
                if iid.startswith(pre):
                    try:
                        return [('S', int(iid[len(pre):]))]
                    except ValueError:
                        return None
            if iid.startswith('CAT_'):
                if self._plan_tv.get_children(iid):
                    return None                 # 자식이 있는 묶음 머리 — 표식은 자식에
                try:
                    cid = int(iid[4:])
                except ValueError:
                    return None
                g = self._cat_groups.get(cid)
                if g and g.get('plans'):
                    return _keys(g['plans'])
                bp = self._cat_book_plans.get(cid)
                if bp and len(bp) == 1:
                    return _keys(bp)
                return None
            if iid.startswith('GROUP_'):
                ptype = iid[len('GROUP_'):].rsplit('_', 1)[0]
                g = next((g for g in self._theme_plans if g['ptype'] == ptype), None)
                return _keys(g.get('plans')) if g else None
            return None

        # ── 표식 매트릭스 (2026-08-18 `0.txt` 1번 — 두 탭 공통 표준) ──
        #   ◐ 진행중 · ★ 완료∧찜 · ● 완료 · ♥ 찜(미시작) · ○ 미시작.
        #   모든 플랜 줄에 한 글자 슬롯 — 멱등(재호출 시 첫 글자만 교체).
        act, comp = set(), set()
        try:
            with appdb.connect(self.db_path) as conn:
                for pid, upid, st in conn.execute(
                        "SELECT plan_id, user_plan_id, enrollment_status "
                        "FROM user_plan_enrollment WHERE "
                        "COALESCE(record_status,'LIVE')='LIVE' AND "
                        "enrollment_status IN ('ACTIVE','COMPLETED')"):
                    k = ('U', upid) if upid else ('S', pid)
                    (act if st == 'ACTIVE' else comp).add(k)
        except Exception as e:
            print('[plan state] %s' % e)

        def marker(ks):
            # ★ 묵상후보(♥·★)는 걷었다 (2026-10-13 76-4) — 진행 상태만 ◐ 진행중 · ● 끝냄 · ○ 아직
            if any(k in act for k in ks):
                return '◐'
            if any(k in comp for k in ks):
                return '●'
            return '○'

        _ALL = '★●♥○◐'
        def scan(parent=''):
            for iid in self._plan_tv.get_children(parent):
                k = _key_of_iid(iid)
                if k:
                    t = self._plan_tv.item(iid, 'text')
                    m = marker(k)
                    if t[:1] in _ALL and t[1:2] == ' ':
                        self._plan_tv.item(iid, text=m + t[1:])
                    else:
                        self._plan_tv.item(iid, text=m + ' ' + t)
                scan(iid)
        scan()

    # ── 「내 플랜」 탭 (2026-10-15) ─────────────────────────────────────────
    def _render_mine(self):
        """내 플랜을 한 줄씩 — 사람이 정한 차례(새것은 맨 위) · 종류 표시 · 받은 것은 보낸 사람 이름."""
        import plan_share as PS
        mine = [p for p in self._plans if p.get('user_plan_id')]
        by = {p['user_plan_id']: p for p in mine}
        try:
            with appdb.connect(self.db_path) as conn:
                order = PS.ordered(list(by), PS.get_order(conn))
                kinds = {u: PS.kind_of(conn, u, by[u].get('ptype'), by[u].get('cfg') or {}) for u in by}
        except Exception as e:
            print('[mine render] %s' % e)
            order, kinds = sorted(by, reverse=True), {}
        for u in order:
            p = by[u]
            k = kinds.get(u, 'MINE')
            t = '%s  %s' % (PS.KIND_MARK.get(k, '✎'), p.get('title') or '')
            who = (p.get('cfg') or {}).get('made_by')
            if k == 'RECV' and who:
                t += '  · %s' % who
            self._plan_tv.insert('', 'end', iid='THEME_PLAN_U%s' % u, text=t, tags=('item',))
        if not order:
            self._plan_tv.insert('', 'end', iid='EMPTY_MINE', tags=('cat',),
                                 text=i18n.t('PMV_MINE_EMPTY', '아직 내 플랜이 없습니다 — 「사용자 모드」 ▸ 새 플랜 만들기'))
        self._bind_drag()

    def _bind_drag(self):
        """줄을 끌어 놓으면 차례가 바뀐다(한 번만 건다)."""
        if getattr(self, '_drag_bound', False):
            return
        self._drag_bound = True
        tv = self._plan_tv
        self._drag = None

        def press(e):
            iid = tv.identify_row(e.y)
            self._drag = iid if iid.startswith('THEME_PLAN_U') else None

        def motion(e):
            if not self._drag:
                return
            tgt = tv.identify_row(e.y)
            if tgt and tgt != self._drag and tgt.startswith('THEME_PLAN_U'):
                tv.move(self._drag, '', tv.index(tgt))
                tv.configure(cursor='sb_v_double_arrow')

        def release(_e):
            if not self._drag:
                return
            self._drag = None
            tv.configure(cursor='')
            self._save_order()

        tv.bind('<ButtonPress-1>', press, add='+')
        tv.bind('<B1-Motion>', motion, add='+')
        tv.bind('<ButtonRelease-1>', release, add='+')

    def _save_order(self):
        import plan_share as PS
        uids = [int(i[len('THEME_PLAN_U'):]) for i in self._plan_tv.get_children('')
                if i.startswith('THEME_PLAN_U')]
        try:
            with appdb.connect(self.db_path) as conn:
                if uids != PS.get_order(conn):
                    PS.set_order(conn, uids)
                    conn.commit()
        except Exception as e:
            print('[mine order] %s' % e)

    def _open_wizard(self):
        """「새 플랜 만들기」 — 마법사(plan_wizard). 저장하면 그 플랜을 고른다."""
        try:
            import plan_wizard
            plan_wizard.PlanWizard(self.winfo_toplevel(), self.db_path, self.lang_getter(),
                                   on_saved=self._plans_changed)
        except Exception:
            import traceback
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), traceback.format_exc(), parent=self)

    def _theme_groups(self):
        """클릭을 받을 수 있는 묶음 전부 (2026-08-16 서브탭 6개).

        ⚠ `_theme_cats` 만 보면 **골라담기 탭에서 아무것도 안 눌린다** — 그 탭은
          꼭대기(216)가 곧 묶음이라 `_cat_groups` 에만 있다. 줄만 그리고 클릭을
          안 받으면 눌러도 아무 일이 없다(§0-6 C-2 교훈).
        """
        seen, out = set(), []
        for g in list(getattr(self, '_theme_cats', [])) + list(self._cat_groups.values()):
            if id(g) in seen:
                continue
            seen.add(id(g))
            out.append(g)
        return out

    def _render_theme_group(self, g_iid, group):
        """묶음 안 — **사용자 플랜을 기원 sys 플랜 아래로 접는다** (2026-08-16 사용자 지시).

        ```
        골라 담는 묵상            골라 담는 묵상
         ├ 인물 묵상   (sys)       ├ 인물 묵상
         ├ 성경의 기적 (sys)  ⇒    │   ├ 5직분 7시대
         ├ 5직분 7시대 (내것)      │   └ 전체
         └ 기적 3수행자…(내것)     └ 기적 묵상
                                      └ 3수행자 4유형 쌍순
        ```

        ★ **이것이 자동 이름 문제의 해답이다.** 부모 마디가 갈래를 말해 주므로
          이름에서 갈래말을 뗄 수 있다(`기적_` 접두 폐지). 「기적 기적전체」 같은
          겹침이 **구조적으로 생길 수 없게** 된다.

        ⚠ **조건을 한 단계 더 펼치지 않는다**(`기적 ▸ 사도기적 ▸ 치유·부활` ✗).
          조건 수가 플랜마다 달라 깊이가 들쭉날쭉해지고, 조건은 상세 화면에 이미 있다.
        ⚠ 사용자 플랜은 `plan_id` 가 **None** 이다 — `THEME_PLAN_U<uid>` 로 가른다.
          그냥 쓰면 `THEME_PLAN_None` 이 겹쳐 두 번째부터 터진다(실제로 터졌다).
        ⚠ **기원을 못 찾은 사용자 플랜은 묶음 바로 아래**에 둔다. 조용히 사라지면
          사용자가 만든 것을 영영 못 찾는다.
        """
        plans = group['plans']
        sys_plans  = [p for p in plans if p.get('plan_id')]
        user_plans = [p for p in plans if p.get('user_plan_id')]

        known = {p['plan_id'] for p in sys_plans}
        kids, homeless = {}, []
        for up in user_plans:
            oid = up.get('origin_plan_id')
            if oid in known:
                kids.setdefault(oid, []).append(up)
            else:
                homeless.append(up)

        # ★ 예전 규칙 유지 — 플랜이 하나뿐이면 묶음 이름과 겹쳐 두 줄이 같아 보인다.
        #   다만 **접을 자식이 있으면** 보여야 한다(sys 앵커 하나 + 내가 만든 것들).
        if len(plans) <= 1 and not kids:
            return False
        # ⚠ 자식을 그린 마디는 **눌러도 플랜을 고르지 않는다**(아래 `_expanded_cats`).
        #   골라담기(216)처럼 성격이 다른 플랜 둘이 든 묶음에서 하나를 임의로
        #   집으면 사용자가 고르지 않은 것이 열린다.
        self._expanded_cats.add(group['cat_id'])

        for sp in sys_plans:
            s_iid = 'THEME_PLAN_%s' % sp['plan_id']
            mine  = kids.get(sp['plan_id'], [])
            self._plan_tv.insert(g_iid, 'end', iid=s_iid,
                                 text=sp['title'],
                                 tags=('item',), open=bool(mine))
            for up in mine:
                self._plan_tv.insert(s_iid, 'end',
                                     iid='THEME_PLAN_U%s' % up['user_plan_id'],
                                     text=up['title'], tags=('item',))
        for up in homeless:
            self._plan_tv.insert(g_iid, 'end',
                                 iid='THEME_PLAN_U%s' % up['user_plan_id'],
                                 text=up['title'], tags=('item',))
        return True

    def _load_enrolled(self):
        """진행중 목록은 **`plan_active_bar` 가 만든다** (2026-08-14).

        ⚠ 예전에는 이 안에서 직접 SQL 을 돌리며 **자기 갈래의 꼬리표만 떼고** 있었다.
          그래서 네 서브탭의 목록이 서로 달라 보였고(사용자 지적), 렌즈묵상처럼
          `PlanMainView` 가 아닌 화면은 콤보를 아예 못 가졌다.
        """
        self._enrolled = self._enr_bar.refresh()
        self._enr_placeholder = self._enr_bar.placeholder

    def _get_plan_text(self, plan_id: int, text_type: str, lang: str) -> str:
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT contents FROM sys_text_asset "
                    "WHERE clicked_id=? AND text_type=? AND lang_code=? "
                    "AND record_status='LIVE' LIMIT 1",
                    (plan_id, text_type, lang)
                ).fetchone()
                if row:
                    return row[0]
                row = conn.execute(
                    "SELECT contents FROM sys_text_asset "
                    "WHERE clicked_id=? AND text_type=? "
                    "AND record_status='LIVE' LIMIT 1",
                    (plan_id, text_type)
                ).fetchone()
                return row[0] if row else ''
        except Exception:
            return ''

    def _get_ui_string(self, key: str, lang: str = 'ko') -> str:
        """ui_strings 테이블에서 레이블 조회. 없으면 key 자체를 반환."""
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT string_value FROM ui_strings "
                    "WHERE string_id=? AND UPPER(lang_code)=UPPER(?)",
                    (key, lang)
                ).fetchone()
                if row:
                    return row[0]
                row = conn.execute(
                    "SELECT string_value FROM ui_strings WHERE string_id=?", (key,)
                ).fetchone()
                return row[0] if row else key
        except Exception:
            return key

    def _load_book_plan_map(self, conn) -> list:
        """BOOK_TEXT stage 기준으로 plan_id → book 정보 목록 반환."""
        try:
            return conn.execute("""
                SELECT DISTINCT sbp.plan_id, sba.book_id, sba.book_code,
                       sba.title, sba.author, sba.lang_code
                FROM sys_bible_plan sbp
                JOIN sys_plan_schedule sps
                     ON sps.plan_id = sbp.plan_id AND sps.stage_type = 'BOOK_TEXT'
                JOIN sys_book_unit sbu
                     ON sbu.unit_id = CAST(SUBSTR(sps.unit_key, 6) AS INTEGER)
                JOIN sys_book_asset sba ON sba.book_id = sbu.book_id
                WHERE sbp.record_status = 'LIVE'
                ORDER BY sba.book_id, sbp.plan_id
            """).fetchall()
        except Exception:
            return []

    def _load_all_books(self, conn) -> list:
        """sys_book_asset에 등록된 모든 도서를 반환."""
        try:
            return conn.execute(
                "SELECT book_id, book_code, title, author, lang_code, copyright_type "
                "FROM sys_book_asset WHERE record_status='LIVE' ORDER BY book_id"
            ).fetchall()
        except Exception:
            return []

    # ── 이벤트 핸들러 ─────────────────────────────────────────────────────────

    def _clear_enr_sel(self):
        """진행중 콤보 선택 해제(프롬프트로 복귀)."""
        ph = getattr(self, '_enr_placeholder', None)
        if ph is not None:
            self._enr_combo.set(ph)

    def _set_enr_combo(self, enr_id):
        """외부/내부에서 특정 enrollment를 콤보에 선택 표시."""
        enr = next((e for e in self._enrolled if e['enrollment_id'] == enr_id), None)
        if enr:
            self._enr_combo.set(enr['combo_label'])

    def _refresh_wishes(self):
        """찜이 바뀌었다 → **트리를 다시 그린다**(후보 마디·★ 표시가 함께 따라온다).

        ⚠ 찜은 탭을 가리지 않으므로 여섯 탭이 다 같은 목록이어야 한다 —
          바깥(`user_main._refresh_plan_wishes`)이 나머지 탭을 마저 돌린다.
        """
        self._load_plans()
        if callable(self.on_wish_change):
            self.on_wish_change()

    def open_wish_list(self):
        """「☆ 묵상후보」 단추 → 팝업. 선택하면 그 플랜으로 데려간다."""
        import plan_wish
        plan_wish.WishDialog(self.winfo_toplevel(), self.db_path,
                             lang=self.lang_getter(),
                             on_open=self._on_wish_pick,
                             on_change=self._refresh_wishes)

    def _on_wish_pick(self, w):
        """찜한 플랜을 선택했다 → 그 플랜이 사는 탭으로 옮기고 선택해 준다.

        ⚠ 후보는 **아직 안 본 것**이라 Focus 화면이 없다. 진행중 콤보와 달리
          **상세를 연다** — 거기서 `[▶ 시작하기]` 를 누르면 등록된다.
        """
        if self.cat_roots:
            mine = set(self.cat_roots)
            here = (w.get('cat_id') in mine) or (w.get('root_cat') in mine
                                                 and w.get('cat_id') not in self.cat_hide)
            if not here and callable(self.on_wish_jump):
                # ⚠ **`on_scope_jump` 를 쓰면 안 된다** — 그쪽은 등록번호를 받아
                #   Focus 화면을 여는 길이라, 후보는 등록번호가 없어 `None` 이 넘어가
                #   **빈 화면이 떴다**(2026-08-16 사용자 지적 「눌러도 이동하지 않는다」).
                self.on_wish_jump(w)
                return
        if not self.select_plan(w.get('plan_id'), w.get('user_plan_id')):
            print('[wish] 트리에서 못 찾음: %s' % (w.get('title'),))

    def select_plan(self, plan_id=None, user_plan_id=None):
        """트리에서 그 플랜 줄을 선택해 상세를 연다. 찾으면 True.

        ⚠ **iid 모양이 가지마다 다르다** — `THEME_PLAN_<pid>` · `THEME_PLAN_U<uid>` ·
          `BOOK_PLAN_<pid>`(도서·자가진단), 그리고 플랜이 하나뿐인 묶음은
          `CAT_<cid>` 가 곧 그 플랜이다. `THEME_PLAN_*` 만 찾았더니 **자가진단 후보를
          골라도 아무 일이 없었다**(2026-08-16 실측).
        """
        cands = []
        if user_plan_id:
            cands.append('THEME_PLAN_U%s' % user_plan_id)
        if plan_id:
            cands += ['THEME_PLAN_%s' % plan_id,
                      'BOOK_PLAN_%s' % plan_id]
        # 묶음에 플랜이 하나뿐이면 그 줄이 없다 — 카테고리 마디가 곧 플랜이다
        for g in self._theme_groups():
            if any((user_plan_id and p.get('user_plan_id') == user_plan_id)
                   or (plan_id and p.get('plan_id') == plan_id)
                   for p in g.get('plans', [])):
                cands.append('CAT_%d' % g['cat_id'])
        for cid, plans in (self._cat_book_plans or {}).items():
            if plan_id and any(p.get('plan_id') == plan_id for p in plans):
                cands.append('CAT_%d' % cid)
        for iid in cands:
            if not self._plan_tv.exists(iid):
                continue
            par = self._plan_tv.parent(iid)
            while par:                       # 접혀 있으면 펼쳐야 보인다
                self._plan_tv.item(par, open=True)
                par = self._plan_tv.parent(par)
            self._plan_tv.see(iid)
            self._plan_tv.selection_set(iid)
            self._on_plan_click(None)
            return True
        return False

    def _on_enr_pick(self, enr):
        """진행중 콤보 선택 → Focus 모드 표시. (띠는 `plan_active_bar` 가 그린다)"""
        # ★ **다른 갈래면 그 탭으로 옮긴다** (2026-08-14 사용자 결정
        #   「탭 이동기능을 넣어라. 흐려지는 것이 아니라 편리해진다」).
        #   ⚠ 옮기지 않으면 왼쪽(그 탭의 목록)과 오른쪽(고른 플랜)이 **다른 갈래**가
        #     되어 지금 무엇을 보는지 알 수 없다.
        # ★ 가르는 축이 `scope` → **카테고리**로 바뀌었다 (2026-08-16 서브탭 6개).
        #   전체읽기·주제읽기·골라담기가 전부 `scope='BIBLE'` 이라 scope 로 재면
        #   셋 사이를 오갈 때 옮기지 않는다.
        if self.cat_roots:
            mine = set(self.cat_roots)
            here = (enr.get('cat_id') in mine) or (enr.get('root_cat') in mine
                                                   and enr.get('cat_id') not in self.cat_hide)
            if not here and callable(self.on_scope_jump):
                self._enr_bar.clear()
                self.on_scope_jump(enr, enr['enrollment_id'])
                return
        else:
            sc = enr.get('scope')
            if sc and self.scope and sc != self.scope and callable(self.on_scope_jump):
                self._enr_bar.clear()
                self.on_scope_jump(sc, enr['enrollment_id'])
                return
        for s_iid in self._plan_tv.selection():
            self._plan_tv.selection_remove(s_iid)
        self._show_focus_mode(enr['enrollment_id'])

    def _open_font(self):
        """통합 폰트 창을 열고 **「문장」 줄을 짚어 준다**."""
        try:
            import font_settings
            w = font_settings.open_font_settings(
                self.winfo_toplevel(), self.db_path, scope='prose',
                on_change=self._on_font_changed)
            return w
        except Exception as e:
            print(f'[plan font] {e}')

    def _on_font_changed(self):
        try:
            import theme_font
            theme_font.reapply_all(self.db_path, self.winfo_toplevel())
        except Exception:
            pass

    def _apply_list_font(self):
        """트리 글꼴을 통합 폰트 「목록」 역할로. `apply_font` 라 이름해야 저절로 온다."""
        try:
            import theme_font
            from tkinter import ttk as _ttk
            d = theme_font.resolve(self.db_path, 'list')
            st = _ttk.Style(self)
            f = theme_font.list_style('Plan.Treeview', self.db_path)
            theme_font.list_style('Enr.Treeview', self.db_path, heading=False)
            # ★ **들여쓰기가 두 겹이었다** (2026-08-16 사용자 지적 — 도서/설교가
            #   2026-08-15 에 겪은 것과 같다). Treeview 가 단계마다 20px 를 넣는데
            #   글자 앞 공백까지 있어 **3단계가 60px 넘게** 밀렸다. 왼쪽 칸이 좁아
            #   플랜 이름이 잘린다. ⇒ 자체 들여쓰기 8px + **글자 앞 공백은 없앤다.**
            self._plan_tv.tag_configure('cat', font=f + ('bold',))
            self._plan_tv.tag_configure('item', font=f)
            # ★ 찜 표시와 **같은 폭**의 빈 자리를 재 둔다 (2026-08-16 사용자 지적
            #   「별표 때문에 플랜 제목이 들쑥날쑥하다」). 글꼴·크기가 바뀌면 폭도
            #   달라지므로 **여기서** 잰다 — 공백 개수를 코드에 박으면 곧 어긋난다.
            from tkinter import font as _tkf
            _fo = _tkf.Font(family=d['family'], size=int(d['size']))
            _w = _fo.measure(WISH_MARK)
            pad, k = '', 1
            while k <= 12:                       # 가장 가까운 공백 수를 고른다
                if abs(_fo.measure(' ' * k) - _w) <= abs(_fo.measure(pad) - _w):
                    pad = ' ' * k
                k += 1
            self._wish_pad = pad
        except Exception:
            pass

    apply_font = _apply_list_font      # theme_font.reapply_all 이 찾는 이름

    def _on_plan_click(self, event=None):
        """전체플랜 트리뷰 클릭 → 상세 모드 표시."""
        sel = self._plan_tv.selection()
        if not sel:
            return
        iid = sel[0]

        # 카테고리 노드
        if iid.startswith('CAT_'):
            try:
                cat_id = int(iid[4:])
            except ValueError:
                return
            # 도서기반 서브카테고리 — 단일 플랜이면 자동 이동
            if cat_id in self._cat_book_plans:
                bplans = self._cat_book_plans[cat_id]
                if len(bplans) == 1:
                    plan = bplans[0]
                    self._clear_enr_sel()
                    self._focus_view.pack_forget()
                    self._detail_f.pack(fill='both', expand=True)
                    self._detail_f.load_plan(plan, self.lang_getter())
                return
            # ⚠ 자식이 펼쳐진 묶음은 **고르지 않는다** — 사용자가 자식을 누른다.
            if cat_id in getattr(self, '_expanded_cats', ()):
                return
            # 전체읽기 소분류 그룹
            group = self._cat_groups.get(cat_id)
            if group:
                self._clear_enr_sel()
                self._show_detail_mode(group)
            return

        if iid.startswith('THEME_PLAN_'):
            # ⚠ 줄만 그리고 클릭을 안 받으면 눌러도 아무 일이 없다(§0-6 C-2 교훈).
            key = iid[len('THEME_PLAN_'):]
            if key.startswith('U'):
                try:
                    uid = int(key[1:])
                except ValueError:
                    return
                plan = next((p for p in self._plans if p.get('user_plan_id') == uid), None)
            else:
                try:
                    plan_id = int(key)
                except ValueError:
                    return
                plan = next(
                    (p for g in self._theme_groups() for p in g['plans']
                     if p.get('plan_id') == plan_id), None)
            if plan:
                self._clear_enr_sel()
                self._focus_view.pack_forget()
                self._detail_f.pack(fill='both', expand=True)
                self._detail_f.load_plan(plan, self.lang_getter())
            return

        if iid.startswith('BOOK_PLAN_'):
            try:
                plan_id = int(iid[len('BOOK_PLAN_'):])
            except ValueError:
                return
            plan = next(
                (p for ps in self._cat_book_plans.values() for p in ps
                 if p.get('plan_id') == plan_id), None)
            if plan:
                self._clear_enr_sel()
                self._focus_view.pack_forget()
                self._detail_f.pack(fill='both', expand=True)
                self._detail_f.load_plan(plan, self.lang_getter())
            return

        if not iid.startswith('GROUP_'):
            return
        # iid format: GROUP_{ptype}_{cat_id}
        parts = iid[len('GROUP_'):].rsplit('_', 1)
        ptype = parts[0]
        group = next((g for g in self._theme_plans if g['ptype'] == ptype), None)
        if not group:
            return
        self._clear_enr_sel()
        self._show_detail_mode(group)

    # ── 모드 전환 ─────────────────────────────────────────────────────────────

    def _show_placeholder(self):
        self._focus_view.pack_forget()
        self._detail_f.pack_forget()
        self._place_acts(())


    def _show_focus_mode(self, enr_id: int):
        self._detail_f.pack_forget()
        self._place_acts(())
        self._focus_view.pack(fill='both', expand=True)
        self._focus_view.select_by_enr_id(enr_id)

    def _show_detail_mode(self, group: dict):
        self._focus_view.pack_forget()
        self._detail_f.pack(fill='both', expand=True)
        self._detail_f.load_group(group, self.lang_getter())

    # ── 콜백 ──────────────────────────────────────────────────────────────────

    def _on_day_complete_internal(self):
        self._load_enrolled()
        if self.on_day_complete:
            self.on_day_complete()

    def _after_enrollment(self):
        """등록/해제 후 플랜 트리 + 진행중 목록 새로고침."""
        self._load_plans()
        self._load_enrolled()

    def _plans_changed(self, uid=None):
        """내 플랜을 복사·수정·가져오기·삭제 한 뒤 — 트리를 다시 그리고 그 플랜을 보인다(2026-10-14 87).

        ★ 2026-10-15 — 내 플랜은 「내 플랜」 탭에만 있다. 다른 탭에서 생기면(앱 플랜 [수정하기] 저장 ·
          가져오기) 그 탭으로 옮겨 그 줄을 고른다. 원본 가리기가 바뀌었을 수 있어 모든 탭을 다시 읽게 알린다."""
        if callable(self.on_mine_changed):
            try:
                self.on_mine_changed(uid, not self.mine)
            except Exception as e:
                print('[mine changed] %s' % e)
            if not self.mine:
                self._load_plans()
                self._show_placeholder()
                return
        self._load_plans()
        if uid:
            iid = 'THEME_PLAN_U%s' % uid
            try:
                if self._plan_tv.exists(iid):
                    self._plan_tv.see(iid)
                    self._plan_tv.selection_set(iid)
            except Exception:
                pass
            self._focus_view.pack_forget()
            self._detail_f.pack(fill='both', expand=True)
            self._detail_f._select_created_user_plan(uid)
        else:
            self._show_placeholder()

    # ── 외부 API ──────────────────────────────────────────────────────────────

    def refresh(self):
        self._load_data()

    def show_focus_by_plan(self, plan_id: int, current_day: int):
        """_show_focus_overlay 콜백에서 호출: 특정 플랜의 Focus 모드로 전환."""
        enr = next((e for e in self._enrolled if e['plan_id'] == plan_id), None)
        if enr:
            self._clear_enr_sel()
            self._set_enr_combo(enr['enrollment_id'])
            self._show_focus_mode(enr['enrollment_id'])


# ── 플랜 상세 프레임 ──────────────────────────────────────────────────────────

class _PlanDetailFrame(tk.Frame):
    """전체/주제 플랜 그룹 선택 시 오른쪽에 표시되는 상세 패널."""

    def __init__(self, parent, db_path, lang_getter, on_enrolled=None,
                 on_open_focus=None, on_wish_change=None, on_route_jump=None):
        self.on_route_jump = on_route_jump
        super().__init__(parent, bg='#FDFEFE')
        self.db_path      = db_path
        self.lang_getter  = lang_getter
        self.on_enrolled  = on_enrolled
        self.on_open_focus = on_open_focus   # 이미 등록된 플랜 → 진행 화면
        self.on_wish_change = on_wish_change # 찜 바뀜 → 상단 띠 콤보 다시
        self._cur_enr = None

        self._group: dict | None = None
        self._sel_plan: dict | None = None
        self.duration_var = tk.StringVar(value='1Y')

        self._build()

    _BAR_H = 34          # 상단 띠 높이 — 못 박는다(단추가 들고 날 때 흔들리지 않게)

    def _build(self):
        inner = tk.Frame(self, bg='#FDFEFE')
        inner.pack(fill='both', expand=True, padx=8, pady=6)

        # ── ★ 상단 띠 — 왼쪽부터 ① 단추 ② 상태 ③ 제목 ④ 기간 (2026-08-16) ──
        #   예전에는 제목이 맨 위, 등록 단추가 가운데라 **눈이 위아래로 왕복**했다.
        #   ⚠ 높이를 못 박는다 — 단추가 들고 날 때 아래 화면이 흔들린다.
        bar = tk.Frame(inner, bg='#FDFEFE', height=self._BAR_H)
        bar.pack(fill='x', pady=(0, 6))
        bar.pack_propagate(False)
        self._bar = bar

        # ★★ 2026-10-13 docs/1.txt 76-2·3·13 — **제목은 왼쪽 · 시작하기는 오른쪽**.
        #   시작 전 = [제목][기간] …… [시작일 2026-10-13][▶ 시작하기]
        #   시작 뒤 = [제목][기간] …… [● 4/365일 · 06/29 시작][▶ 이어서 읽기]
        #   걷은 것 — ♡ 묵상후보(76-4) · [태그](76-5 · My Edit 몫) · [연결된 자산 보기](76-6 · 늘 펼침) ·
        #   [시작일] 단추와 가운데 날짜 칸(76-13 · 날짜는 시작하기 옆 글자를 눌러 바꾼다).
        self._lbl_title = tk.Label(bar, text='', bg='#FDFEFE',
                                   font=('', 11, 'bold'), fg='#1A5276', anchor='w')
        self._lbl_title.pack(side='left')
        self._lbl_dur = tk.Label(bar, text='', bg='#FDFEFE', fg='#555')
        self._lbl_dur.pack(side='left', padx=(10, 0))
        # ★ 2026-10-14 사용자 「% 표시는 묵상기간 00일 라벨의 오른쪽으로」 — 플랜 정보 칸 안에서 옮겨 왔다
        self._lbl_cover = tk.Label(bar, text='', bg='#FDFEFE', fg='#27AE60')
        self._lbl_cover.pack(side='left', padx=(10, 0))
        # 오른쪽 끝부터 — 나중에 pack 한 것이 더 왼쪽에 온다
        # ⚠ 색은 시작하기·이어서 읽기가 **같다** — 그전에는 시작하기가 형광 초록(#27AE60)이라
        #   「눈이 아프다」 · 플랜을 오갈 때마다 색이 바뀌었다(사용자). 이어서 읽기 색이 알맞다고 했다.
        self._btn_start = tk.Button(bar, text='', bd=0, padx=12, pady=3,
                                    font=('', 10, 'bold'), cursor='hand2',
                                    bg='#1A5276', fg='white',
                                    activebackground='#1A5276', activeforeground='white',
                                    command=self._start_clicked)
        self._btn_start.pack(side='right')
        # 시작일 — 처음부터 오늘이 적혀 있고, 누르면 그 자리에서 고친다(Enter/다른 곳 → 확정)
        self._start_var = tk.StringVar(value=date.today().isoformat())
        self._date_f = tk.Frame(bar, bg='#FDFEFE')
        self._date_f.pack(side='right', padx=(0, 10))
        self._lbl_start = tk.Label(self._date_f, bg='#FDFEFE', fg='#555', cursor='hand2')
        self._lbl_start.pack(side='left')
        self._lbl_start.bind('<Button-1>', lambda _e: self._date_edit())
        self._ent_start = tk.Entry(self._date_f, textvariable=self._start_var, width=11,
                                   justify='center')
        self._ent_start.bind('<Return>', lambda _e: self._date_done())
        self._ent_start.bind('<Escape>', lambda _e: self._date_done(cancel=True))
        self._ent_start.bind('<FocusOut>', lambda _e: self._date_done())
        self._date_show()
        self._lbl_state = tk.Label(bar, text='', bg='#FDFEFE', fg='#555')
        self._lbl_state.pack(side='right', padx=(0, 10))

        self._acts = {}
        self._place_acts = None
        # ── 연결된 자산 판 (접힘 기본 — 단추가 편다) ───────────────
        try:
            from asset_strip import AssetStrip
            self._assets = AssetStrip(
                inner, self.db_path, lang_getter=self.lang_getter,
                on_jump=lambda k, i: (self.on_asset_jump(k, i)
                                      if callable(getattr(self, 'on_asset_jump',
                                                          None)) else None))
        except Exception as _e:
            print('[plan assets] %s' % _e)
            self._assets = None
        self._assets_n = 0
        self.on_asset_jump = None      # 호스트(user_main)가 심는다

        # ── 플랜 정보 ─────────────────────────────────────────────────
        info_f = tk.LabelFrame(inner, text=i18n.t('PMV_PLANINFO',' 플랜 정보 '),
                               bg='#FDFEFE')
        info_f.pack(fill='x', pady=(0, 6))
        self._info_f = info_f

        # ★ 2026-10-14 사용자 「플랜정보 화면 내부에는 설명만 표시하라 · 별명 따위 없애라」 —
        #   갈래 이름 줄(「복음서 조화」 같은 다른 이름)을 걷었다. 위 띠의 제목 하나만 이름이다.
        self._lbl_type = tk.Label(info_f)      # 옛 코드가 config 하는 자리 — 화면에 붙이지 않는다

        desc_wrap = tk.Frame(info_f, bg='#F2F3F4')
        desc_wrap.pack(fill='x', padx=8, pady=(4, 8))
        self._desc_wrap = desc_wrap
        self._desc_vsb = None
        desc_vsb = ttk.Scrollbar(desc_wrap, orient='vertical')
        desc_vsb.pack(side='right', fill='y')
        self._desc_vsb = desc_vsb
        self._txt_desc = tk.Text(desc_wrap, height=2,
                                  wrap='word', relief='flat', bg='#F2F3F4',
                                  fg='#333', state='disabled', cursor='arrow',
                                  yscrollcommand=desc_vsb.set)
        desc_vsb.config(command=self._txt_desc.yview)
        self._txt_desc.pack(fill='x', expand=False)
        # ★ 플랜 설명문도 **「문장」 역할**을 따른다 (2026-08-14 사용자 지적
        #   「플랜정보, 등록, 읽기일정 미리보기, 플랜 설명문 등은 통합폰트 적용안된다」).
        #   ⚠ `font=('Malgun Gothic', 9)` 를 박아 두면 통합 폰트가 못 닿는다.
        try:
            import theme_font
            theme_font.register(self._txt_desc, self.db_path, 'prose')
        except Exception:
            pass

        # ── 기간 선택 (다기간 플랜용) ─────────────────────────────────
        self._dur_row = tk.Frame(inner, bg='#FDFEFE')
        tk.Label(self._dur_row, text=i18n.t('PMV_DURATION','기간:'), bg='#FDFEFE', fg='#555').pack(side='left')
        for lbl, key in [(i18n.t('UI_PLAN_DUR_1Y','1년'), '1Y'), (i18n.t('UI_PLAN_DUR_2Y','2년'), '2Y'), (i18n.t('UI_PLAN_DUR_3Y','3년'), '3Y')]:
            tk.Radiobutton(self._dur_row, text=lbl,
                           variable=self.duration_var, value=key,
                           bg='#FDFEFE',
                           command=self._on_dur_change).pack(side='left', padx=4)
        self._lbl_est = tk.Label(self._dur_row, text='', bg='#FDFEFE', fg='#1A5276')
        self._lbl_est.pack(side='left', padx=(10, 0))

        self._sync_top_bar()

        # ── 읽기 일정 미리보기 (인라인) ──────────────────────────────
        prev_f = tk.LabelFrame(inner, text=i18n.t('PMV_PREVIEW',' 읽기 일정 미리보기 '),
                                bg='#FDFEFE')
        prev_f.pack(fill='both', expand=True, pady=(0, 4))
        self._prev_f = prev_f      # 날짜 칸을 이 앞에 끼운다

        prev_wrap = tk.Frame(prev_f, bg='#FDFEFE')
        prev_wrap.pack(fill='both', expand=True, padx=4, pady=4)
        prev_vsb = ttk.Scrollbar(prev_wrap, orient='vertical')
        prev_vsb.pack(side='right', fill='y')
        prev_hsb = ttk.Scrollbar(prev_wrap, orient='horizontal')
        prev_hsb.pack(side='bottom', fill='x')
        self._prev_tv = ttk.Treeview(prev_wrap, show='headings',
                                      yscrollcommand=prev_vsb.set,
                                      xscrollcommand=prev_hsb.set)
        prev_vsb.config(command=self._prev_tv.yview)
        # 미리보기 표 → 「목록」 역할 (아래 `_apply_detail_font` 가 입힌다)
        self._prev_tv.configure(style='Plan.Treeview')
        prev_hsb.config(command=self._prev_tv.xview)
        self._prev_tv.pack(fill='both', expand=True)

    # ── 내 플랜 (2026-10-14 87) ─────────────────────────────────────────────
    on_plans_changed = None      # PlanMainView 가 심는다 — 트리 다시 그리고 그 플랜을 고른다(uid)

    def attach_actions(self, acts, place):
        """묵상플랜 띠(Font 오른쪽)의 단추를 받는다 — 누르면 이 화면이 고른 플랜에 한다."""
        self._acts, self._place_acts = acts, place
        acts['edit'].config(command=self._edit_any)
        acts['hide'].config(command=lambda: self._set_orig(True))
        acts['show'].config(command=lambda: self._set_orig(False))
        acts['export'].config(command=self._export)
        acts['delete'].config(command=self._del_plan)

    def _sync_mine(self):
        """띠 단추 — 배포 플랜이면 [복사 후 수정][내보내기] · 내 플랜이면 [내 플랜 수정][내보내기] … [내 플랜 삭제]."""
        if not callable(self._place_acts):
            return
        p = self._sel_plan or {}
        if p.get('user_plan_id'):
            o = None
            try:
                import copy_own
                with appdb.connect(self.db_path) as conn:
                    o = copy_own.origin_of(conn, 'PLAN', p['user_plan_id'])
            except Exception:
                o = None
            if o:      # 배포 플랜을 수정한 것 — 원본 가리기/표시하기(지금 상태가 눌린 모양)
                import ui_theme
                for hv, k in ((True, 'hide'), (False, 'show')):
                    on = (hv == o['hide'])
                    self._acts[k].config(relief='sunken' if on else 'flat',
                                         fg=ui_theme.C('accent') if on else ui_theme.C('fg'))
                self._place_acts(('edit', 'hide', 'show', 'export', 'delete'))
            else:      # 내가 처음부터 가진 플랜(가져온 것 등) — 원본 옵션 없음
                self._place_acts(('edit', 'export', 'delete'))
        elif p.get('plan_id'):
            # ⚠ 골라담기 바탕 플랜(인물·기적·기도)은 제 일정이 없다 — 복사·내보내기할 것이 없다
            try:
                with appdb.connect(self.db_path) as conn:
                    has = conn.execute("SELECT 1 FROM sys_plan_schedule WHERE plan_id=? LIMIT 1",
                                       (p['plan_id'],)).fetchone()
            except Exception:
                has = True
            self._place_acts(('edit',) if has else ())      # 88-5 배포 플랜엔 내보내기 없음
        else:
            self._place_acts(())

    def _edit_any(self):
        p = self._sel_plan or {}
        if p.get('user_plan_id'):
            self._edit()
            return
        if not p.get('plan_id'):
            return
        try:
            import copy_own
            with appdb.connect(self.db_path) as conn:
                uid = copy_own.copy_of(conn, 'PLAN', p['plan_id'])
        except Exception:
            uid = None
        if uid:                       # 이미 수정해 둔 사본이 있으면 그것을 연다(두 벌 안 만든다)
            self._changed(uid)
            self._edit(uid)
        else:
            self._clone()

    def _set_orig(self, hide):
        p = self._sel_plan or {}
        uid = p.get('user_plan_id')
        if not uid:
            return
        import copy_own
        with appdb.connect(self.db_path) as conn:
            copy_own.set_hide(conn, 'PLAN', uid, bool(hide))
        self._changed(uid)

    def _changed(self, uid=None):
        if callable(self.on_plans_changed):
            self.on_plans_changed(uid)

    def _clone(self):
        """배포 플랜의 [수정하기] — **초안 창**을 연다. 내 플랜은 [저장]을 누를 때 생긴다(2026-10-15 88-8).
        ⚠ 그전에는 누르는 순간 복사본을 만들어, 마음에 안 들어 닫으면 지워야 할 플랜이 남았다."""
        import my_plan_edit
        p = self._sel_plan or {}
        if not p.get('plan_id'):
            return
        my_plan_edit.MyPlanEditor(self.winfo_toplevel(), self.db_path, None, self.lang_getter(),
                                  on_saved=self._changed, source=('SYS', p['plan_id']))

    def _edit(self, uid=None):
        import my_plan_edit
        uid = uid or (self._sel_plan or {}).get('user_plan_id')
        if uid:
            my_plan_edit.MyPlanEditor(self.winfo_toplevel(), self.db_path, uid, self.lang_getter(),
                                      on_saved=self._changed)

    def _export(self):
        import my_plan_edit
        p = self._sel_plan or {}
        my_plan_edit.export_dialog(self.winfo_toplevel(), self.db_path, plan_id=p.get('plan_id'),
                                   user_plan_id=p.get('user_plan_id'), lang=self.lang_getter())

    def _import(self):
        import my_plan_edit
        new = my_plan_edit.import_dialog(self.winfo_toplevel(), self.db_path)
        if new:
            self._changed(new[-1])

    def _del_plan(self):
        import plan_share as PS
        p = self._sel_plan or {}
        if not p.get('user_plan_id'):
            return
        if not messagebox.askyesno(i18n.t('PMV_DELPLAN', '이 내 플랜 삭제'),
                                   i18n.t('PMV_DELPLAN_Q', '「%s」을(를) 삭제할까요? 쓴 묵상노트는 구절에 그대로 남습니다.')
                                   % p.get('title', ''), parent=self):
            return
        with appdb.connect(self.db_path) as conn:
            PS.delete_plan(conn, p['user_plan_id'])
            conn.commit()
        self._sel_plan = None
        self._changed(None)

    # ── 데이터 로딩 ───────────────────────────────────────────────────────────

    def load_plan(self, plan: dict, lang: str):
        """단일 플랜 직접 로드 — 자가진단 플랜 트리 클릭 시 사용."""
        self._group = None
        self._dur_row.pack_forget()
        self._sel_plan = plan
        self._refresh_display(lang)

    def load_group(self, group: dict, lang: str):
        self._group = group
        plans = group.get('plans', [])
        if not plans:
            return

        # 다기간 그룹 여부
        is_multi = len(plans) > 1
        if is_multi:
            # pack_forget 후 재배치 시 위치가 밀리는 버그 방지 — 항상 enr_f 앞에 삽입
            # ⚠ `before=` 에 **접혀 있는 위젯**을 주면 터진다 — 날짜 칸(`_enr_f`)은
            #   이제 기본이 접힘이다(2026-08-16). 늘 떠 있는 미리보기 앞에 붙인다.
            self._dur_row.pack(fill='x', pady=(0, 6), before=self._prev_f)
            dur_code = self.duration_var.get()
            dur_days = _DUR_DAYS.get(dur_code, 365)
            sel = min(plans, key=lambda p: abs(p['duration_days'] - dur_days))
        else:
            self._dur_row.pack_forget()
            sel = plans[0]
            self.duration_var.set('1Y')

        self._sel_plan = sel
        self._refresh_display(lang)

    def _sync_assets(self, plan_id):
        """플랜이 바뀌면 자산 판을 다시 센다 — **있으면 늘 펼친다**(76-6 · 단추를 걷었다).
        ⚠ 사용자 파생 플랜(plan_id 없음)은 연결 앵커가 아니다 — 0."""
        cnt = 0
        try:
            if plan_id and self._assets is not None:
                cnt = self._assets.load('PLAN', plan_id)
        except Exception as e:
            print('[plan assets sync] %s' % e)
        self._assets_n = cnt
        if self._assets is None:
            return
        if cnt:
            if not self._assets.winfo_manager():
                self._assets.pack(fill='x', before=(self._info_f if self._info_f.winfo_manager() else (self._dur_row if self._dur_row.winfo_manager() else self._prev_f)), pady=(0, 4))
            try:
                import ui_theme
                ui_theme.paint(self._assets)
            except Exception:
                pass
        else:
            self._assets.pack_forget()

    def _fit_desc(self):
        """설명 칸 높이를 글만큼 (76-2 「한 줄 설명으로 끝나는데 칸이 높다」) — 1~6줄 · 넘으면 굴린다."""
        t = self._txt_desc
        try:
            t.update_idletasks()
            n = t.count('1.0', 'end', 'displaylines')
            n = (n[0] if isinstance(n, tuple) else n) or 1
        except Exception:
            n = 2
        # ★ 2026-10-14 사용자 「플랜정보를 완전히 표시하고 나서야 일정 미리보기」 — 6줄에서 자르지 않고 다 보인다
        #   (아주 긴 글만 30줄에서 굴린다).
        t.config(height=max(1, min(30, n)))
        # ⚠ 줄 간격(spacing)이 있어 줄 수만큼으로는 끝 줄이 잘린다 — 다 보일 때까지 늘린다.
        try:
            h = max(1, min(30, n))
            while h < 30:
                t.update_idletasks()
                if t.yview()[1] >= 0.999:
                    break
                h += 1
                t.config(height=h)
            n = h if t.yview()[1] >= 0.999 else 31
        except Exception:
            pass
        try:
            if n > 30:
                t.unbind('<MouseWheel>')        # 넘치는 설명은 제 굴림(76-2)
                if not self._desc_vsb.winfo_manager():
                    self._desc_vsb.pack(side='right', fill='y', before=t)
            else:
                self._desc_vsb.pack_forget()
        except Exception:
            pass

    def _refresh_display(self, lang: str | None = None):
        if not self._sel_plan:
            return
        lang = lang or self.lang_getter()
        p = self._sel_plan
        self._sync_assets(p.get('plan_id'))
        try:
            self._sync_mine()
        except Exception as _e:
            print('[plan mine] %s' % _e)

        # ★★ **이름은 `plan_label` 하나가 짓는다** (2026-08-30 사용자 신고
        #   「어떤 종류를 등록하더라도 1년 등록하면 상단 오른쪽에 플랜 이름이
        #   『1년』이라고 표시된다 · 정경순서 통독 1년 … 이런 식으로 표시해야」).
        #   ⚠ **데이터를 고치면 안 된다** — 제목이 정말 「1년」이고(실측 CANONICAL_1Y·
        #     CHRONOLOGICAL_1Y 둘 다), 트리에서는 부모 마디가 그 맥락을 말한다.
        #     제목에 묶음을 적어 넣으면 트리가 「정경순서 통독 › 정경순서 통독 1년」이
        #     된다. ⇒ **문맥이 없는 이 자리에서만** 묶음을 앞에 붙인다.
        #   ★ 띠 콤보(`plan_active_bar`)가 이미 같은 함수를 쓴다 — 두 자리가 같은 말.
        try:
            import plan_label
            _name = plan_label.full(p['ptype'], p.get('title', p['code']),
                                    ambiguous=bool(p.get('ambiguous')),
                                    group=p.get('group_label'))
        except Exception:
            _name = p.get('title', p['code'])
        self._lbl_title.config(text=_name)
        self._lbl_type.config(text=i18n.t('PLANTYPE_'+str(p['ptype']), _TYPE_KO.get(p['ptype'], p['ptype'])))
        days = p['duration_days']
        self._lbl_dur.config(text=i18n.t('PMV_DAYS_Y_FMT','{days}일 ({y}년)').format(days=days, y=days // 365) if days >= 365
                             else i18n.t('PMV_DAYS_FMT','{days}일').format(days=days))

        # 커버 % — 주제읽기(THEMATIC category)만, 선택된 단일 플랜 기준으로 표시
        cat = p.get('category', self._group.get('category', 'THEMATIC') if self._group else 'THEMATIC')
        if cat != 'TOTAL':
            pct = self._calc_coverage(p['plan_id'])
            self._lbl_cover.config(text=i18n.t('PMV_COVER_FMT','성경 {pct}% 커버').format(pct=f"{pct:.1f}") if pct else '')
        else:
            self._lbl_cover.config(text='')

        # 설명 — 없으면 칸째 감추고, 있으면 글만큼만(76-2)
        desc = (p.get('desc') or '').strip()
        self._txt_desc.config(state='normal')
        self._txt_desc.delete('1.0', 'end')
        self._txt_desc.insert('1.0', desc)
        self._txt_desc.config(state='disabled')
        if desc:
            if not self._info_f.winfo_manager():
                self._info_f.pack(fill='x', pady=(0, 6), before=self._dur_row if self._dur_row.winfo_manager() else self._prev_f)
            if not self._desc_wrap.winfo_manager():
                self._desc_wrap.pack(fill='x', padx=8, pady=(6, 8))
            self.after_idle(self._fit_desc)
        else:
            self._desc_wrap.pack_forget()
            self._info_f.pack_forget()

        # 예상 완료일
        if self._dur_row.winfo_ismapped():
            dur_days = _DUR_DAYS.get(self.duration_var.get(), 365)
            est = (date.today() + timedelta(days=dur_days)).isoformat()
            self._lbl_est.config(text=f'→ 완료 예상: {est}')

        self._show_enroll_row()
        self._load_preview()
        self._wheel_forward()

    def _wheel_forward(self, w=None):
        """오른쪽 칸 **어디서 굴려도** 읽기 일정이 굴러간다 (2026-10-13 docs/1.txt 76-2
        「플랜 정보와 읽기일정 미리보기 화면이 표시된 공간에서 스크롤이 안 된다 · 모든 플랜에 공통」).
        그전에는 미리보기 표 위에서만 굴러가고, 이름·정보·자산 줄 위에서 굴리면 아무 일이 없었다.
        ⚠ 미리보기 표·글이 넘치는 설명 칸은 제 굴림을 쓴다 · 다시 불러도 멱등(같은 이름표로 덮는다)."""
        w = w or self
        if w is self._prev_tv:
            return
        if not (w is self._txt_desc and self._desc_vsb.winfo_manager()):
            try:
                w.bind('<MouseWheel>', self._on_wheel_any)
            except Exception:
                pass
        for c in w.winfo_children():
            self._wheel_forward(c)

    def _on_wheel_any(self, e):
        try:
            self._prev_tv.yview_scroll(-1 * (e.delta // 120 or (1 if e.delta > 0 else -1)), 'units')
        except Exception:
            pass
        return 'break'

    # ── 상단 띠 ───────────────────────────────────────────────────────

    _BUILDER = {'BIOGRAPHICAL': '_open_plan_builder',
                'THEMATIC':     '_open_miracle_builder',
                'JOURNEY':      '_open_journey_builder',   # 발자취(2026-08-18)
                'PRAYER':       '_open_prayer_builder',    # 기도(2026-08-18)
                'SUFFERING':    '_open_suffering_builder'} # 고난(2026-10-20 시험판)

    def _enrollment_of(self, plan):
        """이 플랜의 진행중 등록. 없으면 None."""
        if not plan:
            return None
        pid, uid = plan.get('plan_id'), plan.get('user_plan_id')
        try:
            with appdb.connect(self.db_path) as conn:
                if uid:
                    r = conn.execute(
                        "SELECT enrollment_id, current_day, start_date "
                        "FROM user_plan_enrollment WHERE user_plan_id=? "
                        "AND enrollment_status='ACTIVE' AND record_status='LIVE'",
                        (uid,)).fetchone()
                else:
                    r = conn.execute(
                        "SELECT enrollment_id, current_day, start_date "
                        "FROM user_plan_enrollment WHERE plan_id=? "
                        "AND user_plan_id IS NULL "
                        "AND enrollment_status='ACTIVE' AND record_status='LIVE'",
                        (pid,)).fetchone()
        except Exception:
            return None
        if not r:
            return None
        return dict(enrollment_id=r[0], current_day=r[1] or 1, start_date=r[2])

    def _sync_top_bar(self):
        """상단 띠를 지금 상태에 맞춘다. **단추는 하나다.**

        ⚠ 예전 `_show_enroll_row` 는 단추 둘(옵션설정·등록하기)을 갈아 끼웠다.
          그러면 순서가 안 보여, 만들어만 놓고 시작을 안 하는 일이 생긴다.
        """
        p = self._sel_plan
        if not p:
            self._btn_start.config(state='disabled', text=i18n.t('PMV_START', '▶ 시작하기'))
            self._lbl_state.config(text='')
            return
        enr = self._enrollment_of(p)
        self._cur_enr = enr
        # 등록됐으면 시작일은 필요 없다 — 시작한 날은 상태 글이 말한다
        if enr:
            self._date_f.pack_forget()
        elif not self._date_f.winfo_manager():
            self._date_f.pack(side='right', padx=(0, 10), before=self._lbl_state)
        if enr:
            dur = p.get('duration_days') or 0
            import plan_label
            self._btn_start.config(
                state='normal', text=i18n.t('PMV_CONTINUE', '▶ 이어서 읽기'))
            self._lbl_state.config(
                text='● %s · %s %s' % (
                    plan_label.progress(enr['current_day'], dur),
                    (enr['start_date'] or '')[5:].replace('-', '/'),
                    i18n.t('PMV_STARTED', '시작')),
                fg='#1E8449')
        else:
            self._btn_start.config(state='normal',
                                   text=i18n.t('PMV_START', '▶ 시작하기'))
            # 시작 전 상태 글은 비운다 — 시작일 글자가 그 자리를 말한다(띠를 덜 붐비게)
            self._lbl_state.config(text='', fg='#7F8C8D')
        self._sync_history()
        self._sync_routes()

    def _sync_history(self):
        """완료 이력 — **모든 플랜에** (2026-08-16 사용자 지시 `0.app수정.txt` 4-1
        「렌즈묵상에서는 완료 이력을 표시하고 있다. 다른 묵상플랜도 여러 번 반복할 수
        있다. 모든 묵상플랜에 대해서 '완료: 2025-4-5, 2026-04-04' 이렇게 묶어서」).

        렌즈만 갖고 있던 줄(`user_lens_manager._refresh_enroll_ui`)을 상단 띠 아래로
        가져왔다. **완료한 적이 있을 때만** 나타난다 — 늘 있는 빈 줄은 잡음이다.
        """
        if getattr(self, '_lbl_hist', None) is None:
            self._lbl_hist = tk.Label(self._bar.master, text='', anchor='w',
                                      bg='#FDFEFE', fg='#7F8C8D', font=('', 8))
        p = self._sel_plan
        rows = []
        if p:
            pid, uid = p.get('plan_id'), p.get('user_plan_id')
            try:
                with appdb.connect(self.db_path) as conn:
                    if uid:
                        rows = conn.execute(
                            "SELECT COALESCE(end_date, start_date) FROM user_plan_enrollment "
                            "WHERE user_plan_id=? AND enrollment_status='COMPLETED' "
                            "AND record_status='LIVE' ORDER BY enrollment_id", (uid,)).fetchall()
                    elif pid:
                        rows = conn.execute(
                            "SELECT COALESCE(end_date, start_date) FROM user_plan_enrollment "
                            "WHERE plan_id=? AND user_plan_id IS NULL "
                            "AND enrollment_status='COMPLETED' "
                            "AND record_status='LIVE' ORDER BY enrollment_id", (pid,)).fetchall()
            except Exception as e:
                print('[plan hist] %s' % e)
        if rows:
            dates = ', '.join((r[0] or '?') for r in rows[:5])
            more = '' if len(rows) <= 5 else ' %s' % i18n.t(
                'PMV_HIST_MORE', '외 {n}회').format(n=len(rows) - 5)
            self._lbl_hist.config(text='✓ %s %d%s  ·  %s%s' % (
                i18n.t('PMV_HIST_DONE', '완료'), len(rows),
                i18n.t('PMV_HIST_TIMES', '회'), dates, more))
            if not self._lbl_hist.winfo_manager():
                self._lbl_hist.pack(fill='x', after=self._bar)
            # ⚠ 완료 이력 줄도 **앱이 칠한 뒤에** 지어진다 — 「다음 단계」와 같다.
            try:
                import ui_theme
                ui_theme.paint(self._lbl_hist)
            except Exception:
                pass
        else:
            self._lbl_hist.pack_forget()

    def _sync_routes(self):
        """묵상경로 「다음 걸음」 줄 (2026-08-17) — 완료 이력과 같은 자리 규칙:
        **경로가 있을 때만** 나타난다(sys 플랜만 — 사용자 플랜은 경로 없음).
        존재 게이트(plan_route.routes_from)가 팩 미보유 자산을 걸러 준다."""
        if getattr(self, '_route_f', None) is None:
            self._route_f = tk.Frame(self._bar.master, bg='#FDFEFE')
        for w in self._route_f.winfo_children():
            w.destroy()
        p = self._sel_plan
        routes, prevs = [], []
        # ★ 2026-10-13 76-7 — **전체읽기(통독) 플랜에는 묵상경로·이전/다음 단계를 안 보인다**
        #   (「너무 일반적인 플랜이라 어울리지 않는다」).
        _cat = (p or {}).get('category') or ((self._group or {}).get('category') if self._group else None)
        if _cat == 'TOTAL':
            self._route_f.pack_forget()
            return
        if p and p.get('plan_id') and not p.get('user_plan_id'):
            try:
                import plan_route
                with appdb.connect(self.db_path) as conn:
                    lang = self.lang_getter() or 'KO'
                    routes = plan_route.routes_from(conn, 'PLAN',
                                                    p['plan_id'], lang=lang)
                    prevs = plan_route.routes_to(conn, 'PLAN',
                                                 p['plan_id'], lang=lang)
            except Exception as e:
                print('[plan routes] %s' % e)
        # ★ 다음 단계가 없어도 **이전 단계만으로 줄을 띄운다** (2026-08-18 지시)
        if not routes and not prevs:
            self._route_f.pack_forget()
            return
        # ★ 오른쪽 정렬 (2026-08-18 사용자 지시 「시작하기 버튼 바로 아래는
        #   이상하다 · 아래에 두면 안 보인다 · 오른쪽 정렬하자」) —
        #   안쪽 프레임을 side='right' 로 붙이고 그 안에서 왼→오로 채운다.
        inner = tk.Frame(self._route_f, bg='#FDFEFE')
        inner.pack(side='right', padx=(0, 4))
        import plan_route
        if prevs:
            # ★ 이름 없이 — 자산 이름까지 적으면 너무 길다(하나면 바로 점프,
            #   여럿이면 클릭 시 이름 메뉴)
            back = tk.Label(inner,
                            text=i18n.t('PMV_PREV_STEP', '◀ 이전 단계'),
                            bg='#FDFEFE', fg='#1A5276', cursor='hand2',
                            font=('', 8, 'underline'))
            back.pack(side='left', padx=(0, 12))
            back.bind('<Button-1>',
                      lambda e, pv=prevs:
                      plan_route.prev_click(e, pv, self.on_route_jump))
        if routes:
            tk.Label(inner,
                     text=i18n.t('PMV_NEXT_STEP', '다음 단계:'),
                     bg='#FDFEFE', fg='#7F8C8D', font=('', 8)).pack(
                side='left', padx=(0, 4))
            for r in routes:
                lbl = '%s (%s)' % (
                    r['label'],
                    plan_route.KIND_LABEL.get(r['kind'], r['kind']))
                link = tk.Label(inner, text=lbl, bg='#FDFEFE', fg='#1A5276',
                                cursor='hand2', font=('', 8, 'underline'))
                link.pack(side='left', padx=(0, 8))
                link.bind('<Button-1>',
                          lambda _e, k=r['kind'], i=r['id']:
                          callable(self.on_route_jump)
                          and self.on_route_jump(k, i))
        anchor = (self._lbl_hist if getattr(self, '_lbl_hist', None) is not None
                  and self._lbl_hist.winfo_manager() else self._bar)
        if not self._route_f.winfo_manager():
            self._route_f.pack(fill='x', after=anchor)
        # ⚠⚠ **이 줄은 앱이 칠한 뒤에 지어진다** — 그래서 검정 테마에서도 흰
        #   바탕으로 남아 있었다(2026-08-30 사용자 지시 「다음 단계: 표시라벨의
        #   배경색이 흰색, 표준 배경색 서식으로 통일하라」). 실측 5위젯.
        #   ⇒ 다 짓고 **그 자리만** 칠한다(97차 연결 작업대와 같은 처방).
        try:
            import ui_theme
            ui_theme.paint(self._route_f)
        except Exception:
            pass

    # 옛 이름 — 부르는 곳이 남아 있어 남긴다
    _show_enroll_row = _sync_top_bar

    # ── 시작일 (76-13) — 시작하기 옆 글자를 누르면 그 자리에서 고친다 ──
    def _date_show(self):
        v = self._start_var.get().strip() or date.today().isoformat()
        self._ent_start.pack_forget()
        self._lbl_start.config(text='%s %s ▾' % (i18n.t('PMV_STARTDATE', '시작일'), v))
        if not self._lbl_start.winfo_manager():
            self._lbl_start.pack(side='left')

    def _date_edit(self):
        self._date_old = self._start_var.get()
        self._lbl_start.pack_forget()
        self._ent_start.pack(side='left')
        self._ent_start.focus_set()
        self._ent_start.select_range(0, 'end')

    def _date_done(self, cancel=False):
        if not self._ent_start.winfo_manager():
            return
        v = self._start_var.get().strip()
        ok = False
        try:
            datetime.strptime(v, '%Y-%m-%d')
            ok = True
        except ValueError:
            pass
        if cancel or not ok:
            self._start_var.set(getattr(self, '_date_old', '') or date.today().isoformat())
        self._date_show()

    def _start_clicked(self):
        """단추 하나가 세 갈래로 (2026-08-16 사용자 지시).

            이미 등록됨   → 진행 화면으로
            조립식        → 만들기 창 → **그 자리에서 등록 확정**
            고정식        → 오늘 날짜로 바로 등록
        """
        p = self._sel_plan
        if not p:
            return
        if getattr(self, '_cur_enr', None):
            enr = self._cur_enr
            if callable(getattr(self, 'on_open_focus', None)):
                self.on_open_focus(enr['enrollment_id'])
            return
        maker = self._BUILDER.get(p.get('ptype'))
        # ⚠ THEMATIC 은 기적 플랜만 조립식이다(2026-10-14) — 비유·만남·자리(115·116·119)도 THEMATIC 이라
        #   [시작하기]가 기적 조립 창을 열고 있었다. 그 셋은 이미 일정이 있는 플랜이라 바로 등록한다.
        if p.get('ptype') == 'THEMATIC' and p.get('code') != 'MIRACLE_PLAN':
            maker = None
        if maker and not p.get('user_plan_id'):
            # ⚠ 만든 **뒤에 이어서 등록**한다. 예전에는 창을 닫고 다시
            #   `[등록하기]` 를 눌러야 했고, 그 사이에 떠나면 시작이 안 됐다.
            before = self._sel_plan
            self._enroll_now = None
            getattr(self, maker)()
            # ⚠ **팝업이 물어본 답**을 따른다(`enroll_now`). 안 물었으면(옛 경로)
            #   만들어졌다는 사실만으로 등록한다.
            made = (self._sel_plan is not before
                    and (self._sel_plan or {}).get('user_plan_id'))
            if made and self._enroll_now is not False:
                self._enroll()
            return
        self._enroll()

    def _calc_coverage(self, plan_id: int) -> float:
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT COUNT(DISTINCT v.verse_id) "
                    "FROM sys_plan_schedule s "
                    "JOIN bible_index v ON v.verse_id BETWEEN s.start_vid AND s.end_vid "
                    "WHERE s.plan_id=? AND s.start_vid IS NOT NULL",
                    (plan_id,)
                ).fetchone()
                return (row[0] / 31102 * 100) if row and row[0] else 0.0
        except Exception:
            return 0.0

    def _calc_coverage_group(self) -> float:
        """그룹 내 모든 플랜 중 데이터가 있는 것의 커버리지를 합산."""
        if not self._group:
            return self._calc_coverage(self._sel_plan['plan_id']) if self._sel_plan else 0.0
        try:
            plan_ids = [p['plan_id'] for p in self._group.get('plans', [])]
            if not plan_ids:
                return 0.0
            placeholders = ','.join('?' * len(plan_ids))
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    f"SELECT COUNT(DISTINCT v.verse_id) "
                    f"FROM sys_plan_schedule s "
                    f"JOIN bible_index v ON v.verse_id BETWEEN s.start_vid AND s.end_vid "
                    f"WHERE s.plan_id IN ({placeholders}) AND s.start_vid IS NOT NULL",
                    plan_ids
                ).fetchone()
            return (row[0] / 31102 * 100) if row and row[0] else 0.0
        except Exception:
            return 0.0

    # ── 기간 변경 ─────────────────────────────────────────────────────────────

    def _on_dur_change(self):
        if not self._group:
            return
        dur_code = self.duration_var.get()
        dur_days = _DUR_DAYS.get(dur_code, 365)
        plans = self._group.get('plans', [])
        sel = min(plans, key=lambda p: abs(p['duration_days'] - dur_days))
        self._sel_plan = sel
        self._refresh_display()

    # ── 등록 액션 ─────────────────────────────────────────────────────────────

    def _enroll(self):
        if not self._sel_plan:
            return
        if self._ent_start.winfo_manager():
            self._date_done()            # 고치던 날짜를 먼저 확정
        start = self._start_var.get().strip() or date.today().isoformat()
        try:
            datetime.strptime(start, '%Y-%m-%d')
        except ValueError:
            messagebox.showwarning(i18n.t('MSG_T_INPUTERR', '입력 오류'), i18n.t('MSG_STARTDATE_FORMAT', '시작일 형식: YYYY-MM-DD'))
            return
        pid = self._sel_plan.get('plan_id')
        uid = self._sel_plan.get('user_plan_id')
        try:
            with appdb.connect(self.db_path) as conn:
                # 1. 읽기 데이터 없는 플랜 등록 차단
                if uid:
                    sched_cnt = conn.execute(
                        "SELECT COUNT(*) FROM user_plan_schedule WHERE user_plan_id=?",
                        (uid,)
                    ).fetchone()[0]
                else:
                    sched_cnt = conn.execute(
                        "SELECT COUNT(*) FROM sys_plan_schedule WHERE plan_id=?", (pid,)
                    ).fetchone()[0]
                if sched_cnt == 0:
                    messagebox.showwarning(
                        i18n.t('MSG_T_ENROLLNO', '등록 불가'),
                        '이 플랜에는 읽기 데이터가 없습니다.\n'
                        '"기적묵상 플랜 만들기" 버튼으로 플랜을 먼저 생성하세요.'
                    )
                    return
                # 2. 동일 플랜 중복 등록 차단
                if uid:
                    dup = conn.execute(
                        "SELECT enrollment_id FROM user_plan_enrollment "
                        "WHERE user_plan_id=? AND enrollment_status='ACTIVE' "
                        "AND record_status='LIVE'",
                        (uid,)
                    ).fetchone()
                else:
                    dup = conn.execute(
                        "SELECT enrollment_id FROM user_plan_enrollment "
                        "WHERE plan_id=? AND enrollment_status='ACTIVE' "
                        "AND record_status='LIVE'",
                        (pid,)
                    ).fetchone()
                if dup:
                    messagebox.showwarning(i18n.t('MSG_T_DUPENROLL', '중복 등록'), i18n.t('MSG_ALREADY_ACTIVE', '이미 진행 중인 플랜입니다.'))
                    return
                if uid:
                    conn.execute(
                        "INSERT INTO user_plan_enrollment "
                        "(plan_id, user_plan_id, enrollment_status, start_date, "
                        " current_day, record_status) "
                        "VALUES (30, ?, 'ACTIVE', ?, 1, 'LIVE')",
                        (uid, start)
                    )
                else:
                    conn.execute(
                        "INSERT INTO user_plan_enrollment "
                        "(plan_id, enrollment_status, start_date, current_day, record_status) "
                        "VALUES (?, 'ACTIVE', ?, 1, 'LIVE')",
                        (pid, start)
                    )
                try:
                    import usage_stats; usage_stats.bump('plan_enroll')
                except Exception:
                    pass
        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), str(e))
            return
        self._sync_top_bar()           # ⚠ 안 부르면 단추가 「시작하기」로 남는다
        # ★ 끝났다고 말한다 (2026-08-16 사용자 지시).
        #   「등록할까요? → 예」를 눌렀더니 **아무 말 없이 닫혔다.** 상단 띠는
        #   바뀌지만 그 순간 사용자의 눈은 사라진 팝업 자리에 있다 — 됐는지
        #   안 됐는지 알 수 없다. 무엇을·언제부터인지 함께 알린다.
        messagebox.showinfo(
            i18n.t('PMV_ENROLLED_T', '등록 완료'),
            i18n.t('PMV_ENROLLED_M',
                   '「{title}」을(를) 등록했습니다.\n\n'
                   '{date}부터 시작하세요.').format(
                title=(self._sel_plan.get('title') or self._sel_plan.get('code') or ''),
                date=start))
        if self.on_enrolled:
            self.on_enrolled()

    # ── 옵션 팝업 ─────────────────────────────────────────────────────────────

    def _open_plan_builder(self):
        try:
            from plan_builder import PlanBuilderDialog
            dlg = PlanBuilderDialog(self.winfo_toplevel(), self.db_path)
            self.winfo_toplevel().wait_window(dlg)
            created_id = getattr(dlg, 'created_plan_id', None)
            self._enroll_now = getattr(dlg, 'enroll_now', None)
            if created_id:
                if self.on_enrolled:
                    self.on_enrolled()
                uid = getattr(dlg, 'created_user_plan_id', None)
                if uid:
                    self._select_created_user_plan(uid)
        except Exception:
            import traceback
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), traceback.format_exc())

    def _open_miracle_builder(self):
        try:
            from miracle_builder import MiraclePlanBuilderDialog
            dlg = MiraclePlanBuilderDialog(self.winfo_toplevel(), self.db_path)
            self.winfo_toplevel().wait_window(dlg)
            created_uid = getattr(dlg, 'created_user_plan_id', None)
            self._enroll_now = getattr(dlg, 'enroll_now', None)
            if created_uid:
                if self.on_enrolled:
                    self.on_enrolled()
                self._select_created_user_plan(created_uid)
        except Exception:
            import traceback
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), traceback.format_exc())

    def _open_journey_builder(self):
        try:
            from journey_builder import JourneyBuilderDialog
            dlg = JourneyBuilderDialog(self.winfo_toplevel(), self.db_path)
            self.winfo_toplevel().wait_window(dlg)
            created_uid = getattr(dlg, 'created_user_plan_id', None)
            self._enroll_now = getattr(dlg, 'enroll_now', None)
            if created_uid:
                if self.on_enrolled:
                    self.on_enrolled()
                self._select_created_user_plan(created_uid)
        except Exception:
            import traceback
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'),
                                 traceback.format_exc())

    def _open_prayer_builder(self):
        try:
            from prayer_builder import PrayerBuilderDialog
            dlg = PrayerBuilderDialog(self.winfo_toplevel(), self.db_path)
            self.winfo_toplevel().wait_window(dlg)
            created_uid = getattr(dlg, 'created_user_plan_id', None)
            self._enroll_now = getattr(dlg, 'enroll_now', None)
            if created_uid:
                if self.on_enrolled:
                    self.on_enrolled()
                self._select_created_user_plan(created_uid)
        except Exception:
            import traceback
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'),
                                 traceback.format_exc())

    def _open_suffering_builder(self):
        try:
            from suffering_builder import SufferingBuilderDialog
            dlg = SufferingBuilderDialog(self.winfo_toplevel(), self.db_path)
            self.winfo_toplevel().wait_window(dlg)
            created_uid = getattr(dlg, 'created_user_plan_id', None)
            self._enroll_now = getattr(dlg, 'enroll_now', None)
            if created_uid:
                if self.on_enrolled:
                    self.on_enrolled()
                self._select_created_user_plan(created_uid)
        except Exception:
            import traceback
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'),
                                 traceback.format_exc())

    def _select_created_user_plan(self, user_plan_id: int):
        """miracle_builder가 user_bible_plan에 생성한 플랜을 _sel_plan으로 선택."""
        if callable(getattr(self, 'on_mine_refresh', None)):
            try:
                self.on_mine_refresh()          # 「내 플랜」 탭 목록에도 곧바로(2026-10-15)
            except Exception:
                pass
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT user_plan_id, plan_code, plan_type, duration_days, plan_config, origin_plan_id "
                    "FROM user_bible_plan WHERE user_plan_id=? AND record_status='LIVE'",
                    (user_plan_id,)
                ).fetchone()
                if not row:
                    return
                uid, code, ptype, dur, cfg_json, origin_id = row
                _lg = (self.lang_getter() or 'KO').upper()
                _d = dict(conn.execute(
                    "SELECT UPPER(lang_code), contents FROM sys_text_asset WHERE text_type='PLAN_DESC' "
                    "AND clicked_id=? AND record_status='LIVE' AND TRIM(COALESCE(contents,''))<>''",
                    (origin_id,)).fetchall()) if origin_id else {}
                _desc = _d.get(_lg) or _d.get('EN') or _d.get('KO') or ''
                import plan_share as _PS
                _title = _PS.title_of(conn, 'USER', uid) or code
                _desc = _PS.desc_of(conn, 'USER', uid) or _desc
            import json as _json
            cfg = _json.loads(cfg_json) if cfg_json else {}
            p = dict(plan_id=None, user_plan_id=uid, code=code, ptype=ptype,
                     duration_days=dur, title=_title, desc=_desc, cfg=cfg,
                     category='THEMATIC', origin_plan_id=origin_id)
            self._group = None
            self._dur_row.pack_forget()
            self._sel_plan = p
            self._refresh_display(self.lang_getter())
        except Exception as e:
            print('[select user plan] %s' % e)

    # ── 인라인 미리보기 ───────────────────────────────────────────────────────

    def _pick_fullest_plan_id(self) -> int:
        """그룹 내에서 sys_plan_schedule 행이 가장 많은 plan_id를 반환.
        "전체 옵션" 미리보기에 사용 — 개별 플랜들과 합산 플랜이 공존할 때
        합산 플랜(행이 최다)을 자동 선택한다."""
        plans = (self._group or {}).get('plans', [])
        if not plans:
            return self._sel_plan['plan_id']
        best_id, best_cnt = self._sel_plan['plan_id'], -1
        try:
            with appdb.connect(self.db_path) as conn:
                for p in plans:
                    cnt = conn.execute(
                        'SELECT COUNT(*) FROM sys_plan_schedule WHERE plan_id=?',
                        (p['plan_id'],)
                    ).fetchone()[0]
                    if cnt > best_cnt:
                        best_cnt, best_id = cnt, p['plan_id']
        except Exception:
            pass
        return best_id

    def _load_preview(self):
        self._prev_tv.delete(*self._prev_tv.get_children())
        if not self._sel_plan:
            return
        ptype = self._sel_plan.get('ptype', '')
        uid   = self._sel_plan.get('user_plan_id')
        lang  = self.lang_getter()
        if uid:
            self._load_preview_matrix_user(uid, ptype, lang)
            return
        if ptype in ('SEQUENTIAL', 'CHRONOLOGICAL'):
            self._load_preview_simple(self._sel_plan['plan_id'], lang)
        elif ptype == 'DIAGNOSTIC':
            self._load_preview_matrix([self._sel_plan['plan_id']], ptype, lang)
        elif ptype == 'BOOK_BASED':
            self._load_preview_book(self._sel_plan['plan_id'], lang)
        elif ptype in ('BIOGRAPHICAL', 'THEMATIC'):
            # 전체 옵션 = 그룹 내 스케줄 최다 단일 플랜 (합산 플랜 자동 선택)
            pid = self._pick_fullest_plan_id()
            if pid is not None:
                self._load_preview_matrix([pid], ptype, lang)
        else:
            pid = self._sel_plan.get('plan_id')
            if pid is not None:
                self._load_preview_matrix([pid], ptype, lang)

    def _load_preview_book(self, plan_id: int, lang: str):
        """도서기반 플랜: 일별 도서 단위 제목 + 성경 구절."""
        self._prev_tv['columns'] = ('day', 'book_unit', 'verse')
        self._prev_tv.heading('day',       text=i18n.t('PMV_DAY','일차'))
        self._prev_tv.heading('book_unit', text=i18n.t('PMV_BOOKUNIT','도서 단위'))
        self._prev_tv.heading('verse',     text=i18n.t('PMV_VERSE','성경 구절'))
        self._prev_tv.column('day',       width=35,  anchor='center', stretch=False)
        self._prev_tv.column('book_unit', width=220, anchor='w',      stretch=True)
        self._prev_tv.column('verse',     width=140, anchor='w',      stretch=False)
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute("""
                    SELECT sps.day,
                           COALESCE(ta.contents, sbu.unit_label),
                           sbu.key_verse_ref,
                           bi.bcode, bi.chapter, bi.verse,
                           bn.short_name
                    FROM sys_plan_schedule sps
                    JOIN sys_book_unit sbu
                         ON sbu.unit_id = CAST(SUBSTR(sps.unit_key, 6) AS INTEGER)
                    JOIN bible_index bi ON bi.verse_id = sbu.start_vid
                    -- ⚠ 제목은 **번역 덮개를 먼저** 본다 (2026-08-23) — 이 줄이
                    --   없어서 마이어 제목을 두 언어로 채운 뒤에도 미리보기에
                    --   영어 원제가 남았다(사용자 「제목이 자동으로 바뀌는 것
                    --   같지 않다」).
                    LEFT JOIN sys_text_asset ta
                           ON ta.text_type = 'BOOK_UNIT_LABEL'
                          AND ta.clicked_id = sbu.unit_id
                          AND UPPER(ta.lang_code) = UPPER(?)
                          AND ta.record_status = 'LIVE'
                    -- ⚠⚠ `book_names` 의 칼럼은 **`book_code`** 다. `bn.bcode`
                    --   라고 써 두어 질의가 늘 터졌고, 아래 `except` 가 조용히
                    --   삼켜 **도서묵상 미리보기가 처음부터 0줄**이었다
                    --   (2026-08-22 사용자 「일자별 유닛과 성경구절이 아직
                    --   입력이 하나도 되어 있지 않다」의 정체).
                    LEFT JOIN book_names bn ON bn.book_code = bi.bcode
                                           AND bn.lang_code = ?
                    WHERE sps.plan_id = ? AND sps.stage_type = 'BOOK_TEXT'
                    ORDER BY sps.day
                """, (lang, lang, plan_id)).fetchall()
        except Exception as e:
            # ⚠ 조용히 삼키지 않는다 — 이 한 줄이 없어서 넉 달을 못 봤다
            print('[preview book] %s' % e)
            return
        for day, unit_label, key_ref, bcode, chap, verse, bname in rows:
            bname = bname or bcode
            verse_str = f"{bname} {chap}:{verse}"
            self._prev_tv.insert('', 'end', values=(day, unit_label or key_ref, verse_str))

    def _load_preview_simple(self, plan_id: int, lang: str):
        """순서대로/연대기 통독: 같은 책 내 범위 통합."""
        self._prev_tv['columns'] = ('day', 'range')
        self._prev_tv.heading('day', text=i18n.t('PMV_DAY','일차'))
        self._prev_tv.heading('range', text=i18n.t('PMV_READRANGE','읽기 범위'))
        self._prev_tv.column('day', width=40, anchor='center', stretch=False)
        self._prev_tv.column('range', width=400, anchor='w', stretch=True)
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute("""
                    SELECT s.day,
                           bi_s.bcode, bi_s.chapter, bi_s.verse,
                           bi_e.bcode, bi_e.chapter, bi_e.verse,
                           bn_s.short_name, bn_e.short_name
                    FROM sys_plan_schedule s
                    JOIN bible_index bi_s ON bi_s.verse_id = s.start_vid
                    JOIN bible_index bi_e ON bi_e.verse_id = s.end_vid
                    JOIN book_names  bn_s
                         ON bn_s.book_code = bi_s.bcode AND bn_s.lang_code = ?
                    JOIN book_names  bn_e
                         ON bn_e.book_code = bi_e.bcode AND bn_e.lang_code = ?
                    WHERE s.plan_id = ? AND s.start_vid IS NOT NULL
                    ORDER BY s.day, s.sort_order
                """, (lang, lang, plan_id)).fetchall()
        except Exception:
            return
        from itertools import groupby
        for day, grp in groupby(rows, key=lambda r: r[0]):
            entries = list(grp)
            merged: list[list] = []
            cur: list | None = None
            for (d, bcode, ch, sv, ebcode, ech, ev, sname, ename) in entries:
                if cur is None:
                    cur = [bcode, ch, sv, ebcode, ech, ev, sname, ename]
                elif bcode == cur[3]:
                    cur[3], cur[4], cur[5], cur[7] = ebcode, ech, ev, ename
                else:
                    merged.append(cur)
                    cur = [bcode, ch, sv, ebcode, ech, ev, sname, ename]
            if cur:
                merged.append(cur)
            parts = []
            for (bcode, sch, sv, ebcode, ech, ev, sname, ename) in merged:
                if bcode == ebcode:
                    if sch == ech:
                        parts.append(f"{sname}{sch}:{sv}~{ev}" if sv != ev
                                     else f"{sname}{sch}:{sv}")
                    else:
                        parts.append(f"{sname}{sch}:{sv}~{ech}:{ev}")
                else:
                    parts.append(f"{sname}{sch}:{sv}~{ename}{ech}:{ev}")
            self._prev_tv.insert('', 'end', values=(day, ',  '.join(parts)))

    def _load_preview_matrix(self, plan_ids: list[int], ptype: str, lang: str):
        """비통독 플랜: 일차 × 단계/트랙/복음서 매트릭스."""
        if not plan_ids:
            return
        ph = ','.join('?' * len(plan_ids))
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(f"""
                    SELECT s.day, s.track, s.stage_type, s.sort_order,
                           bi_s.bcode, bi_s.chapter, bi_s.verse,
                           bi_e.bcode, bi_e.chapter, bi_e.verse,
                           bn_s.short_name, bn_e.short_name
                    FROM sys_plan_schedule s
                    JOIN bible_index bi_s ON bi_s.verse_id = s.start_vid
                    JOIN bible_index bi_e ON bi_e.verse_id = s.end_vid
                    JOIN book_names  bn_s
                         ON bn_s.book_code = bi_s.bcode AND bn_s.lang_code = ?
                    JOIN book_names  bn_e
                         ON bn_e.book_code = bi_e.bcode AND bn_e.lang_code = ?
                    WHERE s.plan_id IN ({ph}) AND s.start_vid IS NOT NULL
                    ORDER BY s.day, s.sort_order
                """, [lang, lang] + plan_ids).fetchall()
        except Exception:
            return
        if not rows:
            return

        if ptype == 'MCHEYNE':
            tracks = sorted({r[1] for r in rows if r[1] is not None})
            col_keys = [f'T{t}' for t in tracks]
            col_hdrs = {f'T{t}': f'Track {t}' for t in tracks}
            def get_col(r): return f"T{r[1]}" if r[1] is not None else 'T1'
        elif ptype == 'HARMONY':
            # 복음서 조화: 시작 책 코드로 칼럼 구분 (마태/마가/누가/요한 순)
            _gospel_order = [40, 41, 42, 43]
            bcode_to_name: dict[int, str] = {}
            for r in rows:
                bc = r[4]  # bi_s.bcode
                if bc not in bcode_to_name:
                    bcode_to_name[bc] = r[10]  # bn_s.short_name
            col_keys = [f'G{bc}' for bc in _gospel_order if bc in bcode_to_name]
            col_hdrs = {f'G{bc}': bcode_to_name[bc] for bc in _gospel_order if bc in bcode_to_name}
            def get_col(r): return f"G{r[4]}"
        else:
            seen: list[str] = []
            for r in rows:
                k = r[2] or 'READ'
                if k not in seen:
                    seen.append(k)
            col_keys = seen
            col_hdrs = {k: i18n.t('UI_PLAN_STAGE_'+str(k), _STAGE_KO_PREVIEW.get(k, k)) for k in col_keys}
            def get_col(r): return r[2] or 'READ'

        all_cols = ['day'] + col_keys
        self._prev_tv['columns'] = all_cols
        self._prev_tv.heading('day', text=i18n.t('PMV_DAY','일차'))
        self._prev_tv.column('day', width=40, anchor='center', stretch=False)
        for ck in col_keys:
            self._prev_tv.heading(ck, text=col_hdrs.get(ck, ck))
            self._prev_tv.column(ck, width=150, anchor='w', stretch=True)

        from collections import defaultdict
        day_data: dict = defaultdict(lambda: defaultdict(list))
        for (day, track, stage, sort_ord,
             bcode, ch, sv, ebcode, ech, ev, sname, ename) in rows:
            col = get_col((day, track, stage, sort_ord,
                           bcode, ch, sv, ebcode, ech, ev, sname, ename))
            if bcode == ebcode:
                ref = (f"{sname}{ch}:{sv}~{ev}" if sv != ev else f"{sname}{ch}:{sv}") \
                      if ch == ech else f"{sname}{ch}:{sv}~{ech}:{ev}"
            else:
                ref = f"{sname}{ch}:{sv}~{ename}{ech}:{ev}"
            day_data[day][col].append(ref)

        for day in sorted(day_data.keys()):
            vals = [str(day)]
            for ck in col_keys:
                vals.append(', '.join(day_data[day].get(ck, [''])))
            self._prev_tv.insert('', 'end', values=vals)

    def _load_preview_matrix_user(self, user_plan_id: int, ptype: str, lang: str):
        """user_plan_schedule 기반 일차 × 단계 미리보기.

        ★ 발자취(JOURNEY)·기도(PRAYER)는 날의 정체가 포커스 머리에 있다
          (「아브라함 · 하란: …」·「한나, 눈물의 서원: …」) — 구절만 보이면
          자기 의도대로 조립됐는지 점검할 수 없어(2026-08-18 사용자 지적)
          **「내용」 칼럼**으로 그 머리를 함께 보인다.
        """
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute("""
                    SELECT s.day, s.stage_type, s.sort_order,
                           bi_s.bcode, bi_s.chapter, bi_s.verse,
                           bi_e.bcode, bi_e.chapter, bi_e.verse,
                           bn_s.short_name, bn_e.short_name,
                           s.meditation_focus
                    FROM user_plan_schedule s
                    JOIN bible_index bi_s ON bi_s.verse_id = s.start_vid
                    JOIN bible_index bi_e ON bi_e.verse_id = s.end_vid
                    JOIN book_names  bn_s ON bn_s.book_code = bi_s.bcode AND bn_s.lang_code = ?
                    JOIN book_names  bn_e ON bn_e.book_code = bi_e.bcode AND bn_e.lang_code = ?
                    WHERE s.user_plan_id = ? AND s.start_vid IS NOT NULL
                    ORDER BY s.day, s.sort_order
                """, (lang, lang, user_plan_id)).fetchall()
        except Exception:
            return
        if not rows:
            return
        show_name = ptype in ('JOURNEY', 'PRAYER', 'SUFFERING')
        stages = sorted({r[1] for r in rows if r[1]})
        cols = ('day',) + (('name',) if show_name else ()) + tuple(stages)
        self._prev_tv['columns'] = cols
        self._prev_tv.heading('day', text=i18n.t('PMV_DAY','일차'))
        self._prev_tv.column('day', width=35, anchor='center', stretch=False)
        if show_name:
            self._prev_tv.heading('name', text=i18n.t('PMV_CONTENT','내용'))
            self._prev_tv.column('name', width=190, anchor='w', stretch=True)
        for st in stages:
            lbl = i18n.t('UI_PLAN_STAGE_'+str(st), _STAGE_KO_PREVIEW.get(st, st))
            self._prev_tv.heading(st, text=lbl)
            self._prev_tv.column(st, width=140 if not show_name else 100,
                                 anchor='w', stretch=not show_name)
        from collections import defaultdict
        day_data: dict = defaultdict(lambda: defaultdict(list))
        day_name: dict = {}
        for (day, stage, sort_ord,
             bcode, ch, sv, ebcode, ech, ev, sname, ename, focus) in rows:
            if bcode == ebcode:
                ref = (f"{sname}{ch}:{sv}~{ev}" if sv != ev else f"{sname}{ch}:{sv}") \
                      if ch == ech else f"{sname}{ch}:{sv}~{ech}:{ev}"
            else:
                ref = f"{sname}{ch}:{sv}~{ename}{ech}:{ev}"
            day_data[day][stage].append(ref)
            if show_name and day not in day_name and (focus or '').strip():
                day_name[day] = focus.split(':')[0].strip()[:28]
        for day in sorted(day_data.keys()):
            vals = [str(day)]
            if show_name:
                vals.append(day_name.get(day, ''))
            vals += [', '.join(day_data[day].get(st, [''])) for st in stages]
            self._prev_tv.insert('', 'end', values=vals)
