# -*- coding: utf-8 -*-
"""AI 작성·번역 작업대 — **자산 축 · 범위별 현황 · 프롬프트 프로필** (영구 도구).

2026-09-23 277차 신설. 1.txt 11번(Gemini API 활용)의 토대다.

사용자 지시(2026-09-22):
  「작업순서는 의미 없다. 네가 만든 앱을 이용해서 **상황에 따라 선택**하면 된다.
   오늘은 창세기 구절 설명문 JP 번역작업을 1절에서 20절까지, 내일은 연결설명문을
   레위기 3절에서 24절까지 러시아어 번역, 등등..
   그런데 주로 **자료가 없는 것을 신규 작성하는 것이 우선**이라고 생각한다.
   그래야 번역할 자료가 생기기 때문이다.
   **프롬프트는 json 형식**으로 만들어도 될 것 같다. **자산에 따라 달라져야** 한다.
   더불어, **구절설명문의 경우에도 창세기와 시편이 서로 달라져야** 할 수도 있다.
   도서, 설교 마찬가지다. **스펄전 설교와 마이어 책은 번역스타일을 다르게**
   요구해야 할 수도 있다. 그런데, 이전에 **시편 설명문 번역할 때 사용한 프롬프트를
   계속 참고용으로 보관**해야 한다. **관리자화면의 어디에 배치할 것인지도 정해라.**
   **작업대상/범위를 선택하면 그 내부에 이미 작성된 것, 언어별 상태를 표시**해주어야
   한다. 그래야 처리해야 할 작업할 종류를 선택하는데 도움이 된다.」

★★★ **설계의 중심 = 「자리」**
  자리(slot) = 글이 한 편 들어갈 칸. 창세기 절 설명문이면 창세기 1,533절 각각이
  자리다. **현황도 작업 목록도 전부 「자리 × 언어」 격자 하나**에서 나온다.
  ⇒ 「이미 작성된 것 · 언어별 상태」(사용자 요구)가 곧 그 격자의 두 축이다.

★★★ **업무내용 셋이 격자의 서로 다른 칸을 가리킨다** — 이것이 이 도구의 알맹이다.
  | 업무 | 고르는 자리 | 사용자 말 |
  |---|---|---|
  | **NEW 신규작성** | **기준 언어에도 없는 자리** | 「자료가 없는 것을 신규 작성하는 것이 **우선**」 |
  | TRANS 번역 | 기준엔 있는데 그 언어에 없는 자리 | 「창세기 구절 설명문 JP 번역」 |
  | EDIT 다듬기 | 그 언어에 이미 있는 자리 | |
  ⇒ 기본값이 **NEW** 이고, 화면이 **빈 자리를 먼저** 보인다.

★★★ **프로필 축이 「자산 종류」보다 잘다** (사용자 지시 그대로)
  `(자산, 업무, 범위값)` 셋이 프로필을 고른다. 범위값이 비면 「그 자산 전체」다.
  · 절 설명문 + 창세기 ↔ 절 설명문 + 시편
  · 도서 본문 + 스펄전 ↔ 도서 본문 + 마이어
  고르는 규칙 = **좁은 것이 이긴다**(`pick_profile` · 딱 집은 것 2점, 전체 1점).
  ⚠ 「없으면 못 쓴다」가 아니다 — 전체 프로필이 언제나 되받이가 된다.

★★★ **옛 프롬프트를 버리지 않는다** (사용자 「계속 참고용으로 보관」)
  고칠 때마다 `sys_ai_profile_hist` 에 **옛 판이 통째로** 들어간다. 판 번호는
  1 부터 오른다. `restore()` 는 옛 판을 **새 판으로 되살린다** — 이력을 지우지
  않는다(§0-5 「지우지 않고 옮긴다」와 같은 문법).

⚠⚠⚠ **여기서는 API 를 부르지 않는다.** 이 도구는 「무엇을 할지 고르는 일」과
  「무엇으로 시킬지 적는 일」까지다. 실제 호출·게이트·적재는 다음 단계이고,
  **그 표(작업·건별·사용량)는 아직 만들지 않았다** — 쓰는 코드가 없는 표를
  미리 만들면 §0-1 「빈 서랍」이 된다.

⚠ 유료·저작권 역본 본문은 **어떤 경우에도 밖으로 내보내지 않는다**
  (`db_version_license` 가 잣대다). 이 도구는 역본 본문을 자산으로 다루지
  않는다 — 목록에 아예 없다.

    python db_ai_job.py --selftest        (의무)
    python db_ai_job.py --assets          자산 축 목록
    python db_ai_job.py --status VERS_DESC_LAY --scope 1
    python db_ai_job.py --todo VERS_DESC_LAY --scope 1 --task NEW
    python db_ai_job.py --seed            씨앗 프로필 (멱등)
    python db_ai_job.py --profiles
"""
import json
import re
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)


def _conn():
    import appdb
    return appdb.connect()


def ui_langs():
    """작업 대상 언어 — `sys_language` 가 단일 소스(§0-3)."""
    try:
        import lang_config
        return [c for c in lang_config.ui_langs()] or ['KO', 'EN']
    except Exception:                                     # noqa: BLE001
        return ['KO', 'EN', 'ZH', 'ZHT', 'JA', 'DE', 'FR', 'ES', 'AR', 'RU', 'PT']


# ══════════════════════════════════════════════════════════════════════
#  자산 축 — 한 자리에 한 편의 글이 들어간다
# ══════════════════════════════════════════════════════════════════════
#
#  axis  : 범위를 고르는 축. 화면의 둘째 콤보가 이것으로 채워진다.
#  store : 글이 어느 표에 사는가.
#  slot  : 「자리」가 무엇인가. 열쇠 계산이 갈린다(★ CHAP 은 bcode*1000+장).
#
#  ⚠ **역본 본문은 없다** — 우리가 쓰는 글이 아니고, 유료 역본을 밖으로
#    보내면 안 된다(§18-3 라이선스).
#  ⚠ 자산을 더하려면 **여기 한 줄**만 더한다. 화면은 이 표를 읽는다.

#  base  : **기준 언어** — 「신규 작성」이 무엇을 뜻하는지 정한다.
#          우리가 쓰는 글은 `KO`(먼저 한국어로 쓰고 옮긴다)이고,
#          **밖에서 들여온 저작물은 `EN`**(원문이 영어다).
#  mine  : **우리가 쓰는 글인가.** 거짓이면 신규 작성이라는 일이 없다 —
#          남의 글이라 할 일은 번역·다듬기뿐이다.
#
#  ⚠⚠⚠ 2026-09-23 — 처음에 `BASE_LANG='KO'` **상수 하나**로 두었다가
#    화면이 **「주석 본문 신규 작성 64,234자리」**라고 말했다(실측 주석은
#    KO 4 · EN 64,238). **없는 일감을 6만 개 만들어 보인 것**이다.
#    상수 하나로는 못 가른다 — 자산마다 다르다.

ASSETS = [
    # (열쇠, 이름, axis, store, slot, text_type, variant, base, mine)
    ('VERS_DESC_LAY',   '절 설명문 (일반)',   'BIBLE',  'TEXT', 'VERSE', 'VERS_DESC',      'LAY',    'KO', True),
    # ⚠⚠⚠ **전문설명(VERS_DESC_EXP)은 2026-09-23 에 걷었다**(사용자 지시).
    #   실측이 까닭을 말한다 — 11,061편이 LAY 보다 더 준 것이 한 편에
    #   **원어 괄호 0.77개 · 구절 참조 1.22개 · 출처 0.00개**뿐이고
    #   LAY 내용의 **42%가 그대로** 들어 있었다. `expert.md` 가 알맹이라
    #   한 「관점 정리」는 **1편(0.0%)**, 출처 구체 표기는 **3편**이다.
    #   ⇒ 다른 층이 아니라 **같은 설명의 격식판**이었다.
    #   ★ 사용자 판단 — 「간단한 전문설명은 일반설명에 넣으면 되고,
    #     복잡하고 긴 분량은 **연구자료**에 넣으면 된다」.
    #   ⚠ **데이터는 안 지웠다**(§0-5) — 배포 DB 의 11,061편과 화면의
    #     [Expert] 모드는 그대로다. 걷은 것은 **새로 쓰는 일감**뿐이다.
    #   되살리려면 아래 한 줄을 되돌린다:
    #   ('VERS_DESC_EXP', '절 설명문 (전문)', 'BIBLE', 'TEXT', 'VERSE',
    #    'VERS_DESC', 'EXPERT', 'KO', True),
    ('VERS_QUES_LAY',   '절 묵상질문',        'BIBLE',  'TEXT', 'VERSE', 'VERS_QUESTION',  'LAY',    'KO', True),
    ('VERS_QUES_EXP',   '절 연구질문',        'BIBLE',  'TEXT', 'VERSE', 'VERS_QUESTION',  'EXPERT', 'KO', True),
    ('VERS_PRAYER',     '절 묵상기도',        'BIBLE',  'TEXT', 'VERSE', 'VERS_PRAYER',    None,     'KO', True),
    # ★★★ **구절 묶음** — 한 절의 글을 **한 번에** 쓴다(2026-09-23 사용자 지시).
    #   재료가 다섯 번 다 같고(구절·본문·앞뒤 절) 82%의 절이 이미
    #   여러 종을 함께 갖고 있다. 따로 돌리면 **같은 재료를 네 번 더**
    #   보내고 호출 수도 네 배가 된다(실측 88,250회 ↔ 17,650회).
    #   ⚠ 담기는 칸은 `BUNDLE_PARTS` 가 정한다 — 여기 한 줄이 아니다.
    ('VERS_BUNDLE',     '절 묶음 (설명+질문+기도)', 'BIBLE', 'BUNDLE',
     'VERSE', None,             None,     'KO', True),
    ('VERS_VERS_DESC',  '구절연결 설명문',    'BIBLE',  'TEXT', 'LINK',  'VERS_VERS_DESC', None,     'KO', True),
    # ★★★ **구절 연결기**(2026-09-29 297차 · 사용자 「구절연결기를 만들어라」) — 자리는
    #   절, 담는 곳은 `sys_link_asset`(VERS_VERS). 신규 작성만 있다(번역·다듬기는
    #   뜻이 없다 — `edit_blocked` 가 막는다). 적재하면 **연결설명문 작업**이 저절로
    #   생긴다(`db_ai_run._load_links`).
    ('VERS_LINK',       '구절 연결 (연결기)', 'BIBLE',  'LINK', 'VERSE', None,             None,     'KO', True),
    # ★★★ 317차-20 (docs/1.txt 43-2) — **구절연결 해제분석**. 자리 = 연결이 있는 절 · 기계는 연결 점검
    #   (`LINK_REVIEW`)과 같다 · 신규 작성만 · 승인 = 물리삭제(연결설명문 함께 · 구속사연결은 남긴다).
    ('VERS_UNLINK',     '구절연결 해제분석',  'BIBLE',  'LINK', 'VERSE', None,             None,     'KO', True),
    ('PERI_DESC',       '단락 설명문',        'BIBLE',  'TEXT', 'PERI',  'PERI_DESC',      None,     'KO', True),
    ('PERI_TITLE',      '단락 제목',          'BIBLE',  'TEXT', 'PERI',  'PERI_TITLE',     None,     'KO', True),
    ('CHAP_DESC',       '장 설명문',          'BIBLE',  'TEXT', 'CHAP',  'CHAP_DESC',      None,     'KO', True),
    ('BOOK_DESC',       '책 개요',            'BIBLE',  'TEXT', 'BOOK',  'BOOK_DESC',      None,     'KO', True),
    ('ENTITY_DESC',     '용어 설명문',        'ENTITY', 'TEXT', 'ENTI',  'ENTITY_DESC',    None,     'KO', True),
    ('ENTITY_NAME',     '용어 이름',          'ENTITY', 'TEXT', 'ENTI',  'ENTITY_NAME',    None,     'KO', True),
    # ↓ 밖에서 들여온 저작물 — 원문이 영어이고 **우리가 쓰는 글이 아니다**
    # ★★★ **도서 소개문** — 우리가 쓴 글이라 기준이 `KO` 다
    #   (본문은 남의 저작이라 `EN` 이다 — 한 책에 기준이 둘이다).
    #   ⚠ 저장 자리가 `sys_book_asset_text` 라 `store` 가 따로다.
    ('BOOK_INTRO',      '도서 소개문',        'LIB',    'BOOKA',
     'BOOKA', None,             None,     'KO', True),
    # ★★★ **맛보기 조각 — 열한 언어로**(2026-09-25 사용자 「맛보기로 추가할
    #   첫번째 짧은 유닛도 번역 기능 추가하라」). 실측 40권 중 **31권이 첫 편에
    #   영어뿐**이라 한국어 사용자가 맛보기로 영어 한 쪽을 받고 있었다.
    #   ⚠ 옮기는 것은 **조각(A4 한 장)**이지 첫 편 전체가 아니다 — 첫 편
    #     원문 합계가 591,974자라 열 언어면 590만 자다(조각은 72,000자).
    #   ⚠ 저장 자리가 `sys_book_taste` 라 `store` 가 따로다(§0-5).
    ('BOOK_TASTE',      '도서 맛보기 조각',   'LIB',    'BTASTE',
     'BTASTE', None,             None,     'EN', False),
    ('BOOK_UNIT',       '도서·설교 본문',     'LIB',    'BOOK', 'UNIT',  None,             None,     'EN', False),
    ('COMMENTARY',      '주석 본문',          'COMM',   'COMM', 'ENTRY', None,             None,     'EN', False),
    # ⚠ 「자료집 글」 한 이름에 **성격이 다른 것 여덟**이 들어 있다(실측) —
    #   문답 3(하이델베르크 129·WSC 107·루터 31) · 주제색인 1(Torrey 33) ·
    #   **사전 2**(Easton 308·Smith 336) · **연구 자료 1**(STUDY_NOTES 32).
    #   앞의 여섯은 수입 저작물이고 **연구 자료만 우리가 쓴 글**이다.
    #   ⇒ `base`·`mine` 을 자산 한 줄로 못 준다 — `base_lang`/`is_mine` 이
    #     **범위(자료집)까지 보고** 정한다. 이름도 무엇이 들었는지 적는다.
    # ★★★ **자료집은 갈래마다 성격이 다르다**(2026-09-25 사용자 지시) —
    #   문답·사전·주제 색인은 **수입 저작물**(기준 EN · 옮기고 다듬을 뿐)
    #   이고 연구 자료만 **우리 글**(기준 KO · 새로 쓴다)이다. 한 줄로
    #   묶어 두니 「전체」에서 둘이 섞여 신규 작성 일감이 헛것이 됐다.
    ('REF_CATE',        '자료집 — 문답',      'REF_CATE',  'REF',
     'RUNIT_CATE',  None,             None,     'EN', False),
    ('REF_DICT',        '자료집 — 사전',      'REF_DICT',  'REF',
     'RUNIT_DICT',  None,             None,     'EN', False),
    ('REF_TOPIC',       '자료집 — 주제 색인', 'REF_TOPIC', 'REF',
     'RUNIT_TOPIC', None,             None,     'EN', False),
    ('REF_STUDY',       '연구 자료',          'REF_STUDY', 'REF',
     'RUNIT_STUDY', None,             None,     'KO', True),
]

#: ★★★ 317차-5 — **사용자가 적은 낱말과 차례 그대로**(docs/1.txt 4번 3)(3)).
#:   「왜 Torey 책을 주제색인이라고 부르는가 … 그냥 교리문답으로 동일하게 취급」 ⇒
#:   토레이(TOPICAL)를 교리문답(REF_CATE)이 함께 맡는다. 옛 작업 3개가 `REF_TOPIC` 을
#:   들고 있어 열쇠는 남기되 **화면 목록에서는 뺀다**(`ASSETS_UI`).
USER_NAMES = {
    'VERS_DESC_LAY': '구절 설명문', 'VERS_QUES_LAY': '묵상질문', 'VERS_QUES_EXP': '연구질문',
    'VERS_PRAYER': '묵상기도', 'VERS_BUNDLE': '구절묶음', 'VERS_LINK': '구절연결',
    'VERS_UNLINK': '연결해제분석',
    'VERS_VERS_DESC': '연결설명', 'PERI_DESC': '단락설명', 'PERI_TITLE': '단락제목',
    'CHAP_DESC': '장설명', 'BOOK_DESC': '책설명', 'BOOK_INTRO': '도서소개',
    'BOOK_TASTE': '도서맛보기', 'BOOK_UNIT': '도서설교본문', 'COMMENTARY': '주석본문',
    'REF_CATE': '교리문답', 'REF_DICT': '사전', 'ENTITY_NAME': '용어이름',
    'ENTITY_DESC': '용어설명', 'REF_STUDY': '연구자료', 'REF_TOPIC': '교리문답(토레이 · 옛 작업)',
}
USER_ORDER = ['VERS_DESC_LAY', 'VERS_QUES_LAY', 'VERS_QUES_EXP', 'VERS_PRAYER', 'VERS_BUNDLE',
              'VERS_LINK', 'VERS_UNLINK', 'VERS_VERS_DESC', 'PERI_DESC', 'PERI_TITLE', 'CHAP_DESC', 'BOOK_DESC',
              'BOOK_INTRO', 'BOOK_TASTE', 'BOOK_UNIT', 'COMMENTARY', 'REF_CATE', 'REF_DICT',
              'ENTITY_NAME', 'ENTITY_DESC', 'REF_STUDY']
ASSETS = [(a[0], USER_NAMES.get(a[0], a[1])) + tuple(a[2:]) for a in ASSETS]
ASSETS.sort(key=lambda a: USER_ORDER.index(a[0]) if a[0] in USER_ORDER else 99)
HIDDEN_ASSETS = ('REF_TOPIC',)
ASSETS_UI = [a for a in ASSETS if a[0] not in HIDDEN_ASSETS]

ASSET = {a[0]: dict(zip(
    ('key', 'name', 'axis', 'store', 'slot', 'text_type', 'variant',
     'base', 'mine'), a))
    for a in ASSETS}

# ══════════════════════════════════════════════════════════════════
#  구절 묶음 — 한 호출이 채우는 칸들
# ══════════════════════════════════════════════════════════════════
#
# ★★★ **칸의 정의는 「무엇을 답하는가」다** — 어체가 아니다. 전문설명이
#   폐지된 까닭이 그것이었다(같은 답을 격식 있게 다시 썼을 뿐이다).
#
# ⚠ `need` 가 False 인 칸은 **없어도 된다** — 사용자 지시
#   「연구질문은 한 구절에 없어도 좋고, 여러개 있어도 좋다」.
#   그래서 묶음이 「할 일」로 뜨는 잣대는 **필수 칸**만 본다.
#
# ⚠ 마커는 **줄 맨 앞**에 오고 본문에 나올 일이 없어야 한다. 사람이 검수
#   화면에서 고치다 마커를 지우면 `bundle_split` 이 거부한다(조용히 반쪽을
#   담지 않는다).

# ⚠⚠ **칸마다 담기는 곳이 다르다**(2026-09-24 · 1.txt 16-1) — 넷은
#   `sys_text_asset` 이고 **연구자료는 `sys_ref_unit`+`sys_ref_text`** 다.
#   그래서 여덟째 칸 `store` 를 둔다. 없으면 `_load_bundle` 이 연구자료를
#   설명문 자리에 부어 버린다.

BUNDLE_PARTS = [
    # (칸 열쇠, 마커/이름, text_type, variant, 필수인가, 답할 물음,
    #  자산 열쇠, 담기는 곳)
    # ⚠⚠⚠ **자산 열쇠가 있어야 게이트가 제 잣대로 잰다** — 없을 때는 네 칸을
    #   전부 「절 설명문」으로 재어 묵상질문·기도가 「문단없음」으로 걸렸다
    #   (레 19:18 실측).
    ('DESC',   '설명문',   'VERS_DESC',     'LAY',    True,
     '이 구절이 무슨 일을 말하는가 (장면·사람)', 'VERS_DESC_LAY', 'TEXT'),
    ('QUES',   '묵상질문', 'VERS_QUESTION', 'LAY',    True,
     '나는 어떻게 살 것인가', 'VERS_QUES_LAY', 'TEXT'),
    ('PRAYER', '묵상기도', 'VERS_PRAYER',   None,     True,
     '이 본문으로 무엇을 구할 것인가', 'VERS_PRAYER', 'TEXT'),
    ('STUDY',  '연구질문', 'VERS_QUESTION', 'EXPERT', False,
     '무엇을 더 파고들 것인가 — 걸리는 것이 없으면 안 쓴다',
     'VERS_QUES_EXP', 'TEXT'),
    # ★★★ **연구자료** (2026-09-24 · 1.txt 16-1 사용자 지시 — 「절 묶음
    #   방식으로 진행할 때에도 연구자료 작성기능을 추가하라」).
    #   ⚠ **필수가 아니다** — 연구질문과 같은 규칙이다. 절 31,104개마다
    #     A4 한 장을 쓸 수는 없고, 사용자도 「연구질문을 선택했다는 것은
    #     그 물음에 대해 쓸 방향을 안다는 것」이라 했다. **걸리는 것이
    #     있을 때만** 쓴다. 실측 지금 연구자료는 43편뿐이다.
    #   ⚠ `text_type` 이 없다 — 담기는 곳이 `sys_ref_unit` 이라 그렇다.
    ('NOTE',   '연구자료', None,            None,     False,
     '연구질문에 답하려면 무엇을 알아야 하는가 — 물음이 없으면 안 쓴다',
     None, 'REF'),
]

BUNDLE_PART = {p[0]: dict(zip(
    ('key', 'name', 'text_type', 'variant', 'need', 'asks', 'asset',
     'store'), p))
    for p in BUNDLE_PARTS}

BUNDLE_NEED = [p[0] for p in BUNDLE_PARTS if p[4]]


def bundle_join(parts):
    """`{칸: 글}` → 사람이 읽고 고치는 한 덩이."""
    out = []
    for k, name, *_rest in BUNDLE_PARTS:   # ⚠ 칸이 늘어도 안 깨지게
        t = (parts.get(k) or '').strip()
        if not t:
            continue
        out.append('[%s]' % name)
        out.append(t)
        out.append('')
    return chr(10).join(out).strip()


# 칸이 비었다는 뜻으로 모델이 적는 말들 — 글로 치지 않는다
_EMPTYISH = {'없음', '없습니다', '해당 없음', '해당없음', '없음.',
             'N/A', 'n/a', 'None', 'none', '-', '—', '(없음)', '없다'}


def bundle_keys(parts=None):
    """이번에 쓸 칸 열쇠 — 안 주면 **표 그대로**(지금까지의 동작).

    ⚠ 표에 없는 열쇠는 조용히 버린다 — 옛 작업이 없어진 칸을 들고 있을 수 있다.
    ⚠ 하나도 안 남으면 **표 그대로** 돌아간다(빈 묶음을 보내지 않는다).
    """
    if not parts:
        return [p[0] for p in BUNDLE_PARTS]
    if isinstance(parts, str):
        parts = [x.strip() for x in parts.split(',')]
    ks = [p[0] for p in BUNDLE_PARTS if p[0] in set(parts)]
    return ks or [p[0] for p in BUNDLE_PARTS]


def bundle_ask(parts=None):
    """프롬프트에 붙일 **이번 칸 안내** 한 줄.

    ★ 칸을 고르게 했으므로 **무엇을 쓸지도 그때그때 달라진다** — 프로필에
      박아 두면 체크를 바꿔도 프롬프트가 안 따라온다.
    """
    ks = bundle_keys(parts)
    names = ['[%s]' % BUNDLE_PART[k]['name'] for k in ks]
    return ('이번에 쓸 칸은 %s 다. 그 이름을 대괄호로 그대로 적고 '
            '아래에 글을 쓴다. 선택하지 않은 칸은 쓰지 않는다.'
            % ' '.join(names))


def bundle_need(parts=None, add=()):
    """「이 자리는 이미 썼다」를 가르는 칸 — 선택한 칸 가운데 필수 칸.

    ★ 317차-19 — 연구질문·연구자료만 골랐으면 **그 칸**이 기준이다(그전에는 늘 설명문·묵상질문·
      기도라 연구 갈래만 고르면 설명문이 있는 구절이 전부 「완료」로 숨었다).
    ⚠ 「덧붙이기」로 고른 칸은 기준에서 뺀다 — 이미 있어도 더 쓸 자리다. 다 빠지면 빈 목록(전부 할 일).
    """
    if not parts:
        return list(BUNDLE_NEED)
    ks = bundle_keys(parts)
    req = [k for k in ks if k in BUNDLE_NEED]
    if req:
        return req
    add = {str(x).upper() for x in (add or ())}
    return [k for k in ks if k not in add]


def bundle_filter(obj, parts=None, lines=True):
    """프롬프트(또는 재료)를 **선택한 칸만으로** 거른다 — 317차-19 (docs/1.txt 42-1).

    ⚠⚠ 실측 작업 589 — 설명문·묵상질문·기도만 골랐는데 47건 전부에 [연구질문]·[연구자료]가 왔다.
      「고르지 않은 칸은 쓰지 않는다」 한 줄보다 **다섯 칸이 다 든 예시와 그 칸의 규칙**이 셌다.
    · 칸 표식 블록(`[연구질문]` 줄부터 다음 표식 전까지) — 고르지 않은 칸이면 블록째 뺀다
    · `lines=True` 면 줄 단위로도 — **고르지 않은 칸 이름만** 말하는 줄은 뺀다
      (고른 칸 이름도 함께 말하는 줄은 둔다 — 「묵상질문·연구질문은 물음표로 끝난다」)
    ⚠ 다 고른 것(또는 `parts` 없음)이면 아무것도 안 바꾼다.
    """
    import re as _re
    keep = set(bundle_keys(parts))
    if not parts or keep == {p[0] for p in BUNDLE_PARTS}:
        return obj
    drop_names = [BUNDLE_PART[k]['name'] for k in BUNDLE_PART if k not in keep]
    keep_names = [BUNDLE_PART[k]['name'] for k in keep]
    head = _re.compile(r'^\[([^\]\n]{1,24})\]\s*$')

    def _one(s):
        if not isinstance(s, str) or not any(n in s for n in drop_names):
            return s
        out, skip = [], False
        for ln in s.split(chr(10)):
            m = head.match(ln.strip())
            if m:
                skip = m.group(1) in drop_names
                if skip:
                    continue
            if skip:
                continue
            if lines and any(n in ln for n in drop_names) and not any(n in ln for n in keep_names):
                continue
            out.append(ln)
        return chr(10).join(out).strip()

    def _walk(v):
        if isinstance(v, dict):
            return {k: _walk(x) for k, x in v.items()}
        if isinstance(v, (list, tuple)):
            got = [_walk(x) for x in v]
            return [x for x in got if not (isinstance(x, str) and not x.strip())]
        return _one(v)
    return _walk(obj)


def bundle_split(text, parts=None):
    """한 덩이 → `{칸: 글}`. 마커가 깨졌으면 `(None, 까닭)`.

    ⚠ **반쪽을 담지 않는다** — 필수 칸이 하나라도 없으면 거부한다.
      사람이 검수 화면에서 마커를 지웠을 때 조용히 세 칸만 적재되면
      그 절이 반쪽이 된다.
    ⚠⚠⚠ **낯선 대괄호 머리에서 끊는다** — 재료 머리(`[구절]`·`[본문 (BSB)]`)가
      칸 마커와 **같은 모양**이라, 모델이 재료를 되받아 적으면 마지막 칸이
      문서 끝까지 먹는다. 실측으로 당했다(영어 연구질문에 BSB 본문이
      통째로 붙어 적재됐다).
    """
    import re as _re
    text = (text or '').strip()
    name2key = {p[1]: p[0] for p in BUNDLE_PARTS}
    # 아는 마커와 **낯선 머리**를 함께 찾는다 — 낯선 것은 거기서 끊는 표식
    head = _re.compile(r'^\[([^\]\n]{1,24})\]\s*$', _re.M)
    hits = [m for m in head.finditer(text)]
    known = [m for m in hits if m.group(1) in name2key]
    if not known:
        return None, '칸 표시([설명문] 따위)를 찾지 못했습니다.'
    out, alien = {}, []
    for i, m in enumerate(known):
        # 이 칸의 끝 = 다음 **아는 마커** 또는 다음 **낯선 머리** 중 앞엣것
        end = len(text)
        for h in hits:
            if h.start() > m.start():
                end = h.start()
                break
        k = name2key[m.group(1)]
        body = text[m.end():end].strip()
        # ★★★ **「없음」은 글이 아니라 빈 칸이다**(2026-09-24 실측으로
        #   잡았다) — 필수가 아닌 칸에 쓸 것이 없을 때 모델이 칸을
        #   비우는 대신 「없음」이라 적는다. 그대로 두면 그 낱말이
        #   **연구질문 본문으로 적재되고** 게이트가 「물음표가 없다」로
        #   울어대서 진짜 흔이 묻힌다.
        if body and body.strip(' .·-—') in _EMPTYISH:
            body = ''
        if body:
            out[k] = body
    for h in hits:
        if h.group(1) not in name2key:
            alien.append(h.group(1))
    # ⚠ **고른 칸 안에서만** 필수를 따진다(2026-09-25) — 사용자가 뺀 칸을
    #   「빠졌다」고 하면 고르게 한 뜻이 없어진다.
    _ks = set(bundle_keys(parts))
    miss = [BUNDLE_PART[k]['name'] for k in BUNDLE_NEED
            if k in _ks and not out.get(k)]
    if miss:
        return None, '빠진 칸: %s' % ' · '.join(miss)
    if alien:
        # ★ 끊기는 했으나 **왜 그런 것이 나왔는지** 말해야 한다 —
        #   조용히 지우면 재료가 새고 있다는 것을 아무도 모른다.
        out['_alien'] = ' · '.join(alien[:5])
    return out, ''

AXIS_NAME = {
    'BIBLE':  '성경 책',
    'ENTITY': '용어 유형',
    'LIB':    '도서·설교집',
    'COMM':   '주석',
    'REF':    '자료집',
    # ⚠ 갈래마다 축이 따로다 — 그 갈래의 자료집만 목록에 오른다.
    'REF_CATE':  '교리문답',
    'REF_DICT':  '사전',
    'REF_TOPIC': '주제 색인',
    'REF_STUDY': '연구 자료',
}

TASKS = [
    ('NEW',   '신규 작성',
     '기준 언어에도 아직 없는 자리 — **이것이 우선이다**(사용자 지시).'),
    ('TRANS', '번역',
     '기준 언어에는 있는데 그 언어에 없는 자리.'),
    ('EDIT',  '다듬기',
     '그 언어에 이미 있는 자리.'),
]
TASK_NAME = {t[0]: t[1] for t in TASKS}

BASE_LANG = 'KO'        # 되받이 — 자산이 안 정했을 때만


# ★ 자료집 안에서 **우리 글인 것**(범위값 = `sys_ref_source.ref_src_id`).
#   실측 여덟 중 `STUDY_NOTES`(연구 자료) 하나뿐이다.
# 자료집 축 → `sys_ref_source.src_type` (자산 넷이 이 표 하나를 읽는다)
REF_AXIS_TYPE = {'REF_CATE': ('CATECHISM', 'TOPICAL'), 'REF_DICT': 'DICTIONARY',
                 'REF_TOPIC': 'TOPICAL',  'REF_STUDY': 'STUDY'}
REF_SLOT_TYPE = {'RUNIT_CATE': ('CATECHISM', 'TOPICAL'), 'RUNIT_DICT': 'DICTIONARY',
                 'RUNIT_TOPIC': 'TOPICAL',  'RUNIT_STUDY': 'STUDY'}


MINE_REF_TYPES = ('STUDY',)
_REF_MINE = {}


def _ref_is_mine(conn, scope):
    """그 자료집이 우리가 쓴 글인가 — `sys_ref_source.src_type` 이 정한다."""
    if not scope:
        return False                      # 「전체」는 남의 글이 섞여 있다
    key = str(scope)
    if key in _REF_MINE:
        return _REF_MINE[key]
    try:
        r = conn.execute("SELECT src_type FROM sys_ref_source WHERE ref_src_id=?",
                         (int(scope),)).fetchone()
        v = bool(r and (r[0] or '').upper() in MINE_REF_TYPES)
    except Exception:                                     # noqa: BLE001
        v = False
    _REF_MINE[key] = v
    return v


def base_lang(kind, scope='', conn=None):
    """그 자산의 **기준 언어** — 「신규 작성」이 견주는 말.

    ⚠ 상수 하나로 두면 수입 저작물에서 틀린다(주석·도서·자료집은 EN).
    ⚠⚠ **자료집은 한 자산 안에서도 갈린다** — 사전·문답은 수입 저작물(EN)이고
      연구 자료는 우리가 쓴 글(KO)이다. 그래서 범위까지 본다.
    """
    # ★ 갈래로 나눈 뒤로는 **자산 줄이 기준을 말한다** — 옛 한 자산
    #   (`REF_UNIT`)만 범위까지 뒤진다(되돌릴 자리로 남긴다).
    if kind == 'REF_UNIT' and conn is not None and _ref_is_mine(conn, scope):
        return 'KO'
    # ★★ **맛보기 조각은 그 책의 원문 언어가 기준이다** — 실측 40권 중
    #   벨직신앙고백은 FR, 도르트신조는 LA 다. EN 으로 못 박으면 그 둘은
    #   「옮길 글이 없다」로 영영 막힌다(§0-1). ⚠ 범위(책)를 골랐을 때만
    #   물을 수 있다 — 안 골랐으면 여느 책의 기준(EN)이다.
    if kind == 'BOOK_TASTE' and conn is not None and str(scope or '').strip():
        try:
            import db_pack_taste as _T
            for uid, bid, _c, _l in _T.first_units(conn):
                if int(bid) == int(scope):
                    sl, _t, _x = _T.src_excerpt(conn, uid)
                    if sl:
                        return sl
                    break
        except Exception:                                 # noqa: BLE001
            pass
    return (ASSET.get(kind, {}).get('base') or BASE_LANG).upper()


def edit_blocked(kind, task, lang, scope='', conn=None):
    """**남의 글을 다듬으려는가** — 막아야 하면 까닭을, 아니면 `''`.

    ★★★ 수입 저작물(도서·주석·수입 자료집)의 **원문은 저자의 글**이다.
      §0-1b 규칙 ① 이 「ORIGINAL 은 파일에서 읽는다」고 못 박은 그것이다.
      우리가 손댈 수 있는 것은 **우리가 만든 번역문·현대어**뿐이다.
    ⚠ 실측(2026-09-23) — 막기 전에는 스펄전 원문 **732편**이 다듬기 일감으로
      떴고 재료에 그 원문이 그대로 실렸다.
    """
    if kind == 'VERS_UNLINK' and str(task).upper() != 'NEW':
        return '구절연결 해제분석은 **신규 작성**(이어진 연결 점검)만 있습니다.'
    if ASSET.get(kind, {}).get('store') == 'LINK' and str(task).upper() not in ('NEW', 'EDIT'):
        return '구절 연결기는 **신규 작성**(새로 잇기)과 **다듬기**(이어진 연결 점검)만 있습니다.'
    if ASSET.get(kind, {}).get('store') == 'LINK' and str(task).upper() == 'EDIT':
        # ★ 317차-5 — 다듬기 = **연결 점검**(docs/1.txt 4 구절연결기 2)(2)) · 언어 축이 없다
        return ''
    if str(task).upper() == 'NEW' and not is_mine(kind, scope, conn):
        # ★★★ 317차-5 — 남의 글(도서·설교 본문 · 주석 · 교리문답 · 사전)은 **옮기는 일만** 있다.
        #   신규 작성 재료에는 원문이 없어 제목만 보고 지은 글이 번역인 척 들어갔다(마이어 159편).
        return ('%s 은(는) 저자의 글입니다 — 새로 쓰지 않습니다. 번역만 합니다.'
                % ASSET.get(kind, {}).get('name', kind))
    if str(task).upper() == 'TRANS' and not is_mine(kind, scope, conn) \
            and ASSET.get(kind, {}).get('store') == 'REF' \
            and str(lang).upper() == str(base_lang(kind, scope, conn)).upper():
        # ★ docs/2.txt 8번(2026-10-23) — 자료집 적재 문(`_load_ref`)은 그 언어의 ORIGINAL 행을 덮는다.
        #   같은 언어로 「옮기면」 저자의 원문 칸이 AI 글로 바뀐다 — 만들 수 없게 막는다.
        return ('%s 의 %s 글은 **저자의 원문**입니다 — 같은 언어로 옮길 수 없습니다.'
                % (ASSET.get(kind, {}).get('name', kind), str(lang).upper()))
    if str(task).upper() != 'EDIT':
        return ''
    if is_mine(kind, scope, conn):
        return ''
    base = base_lang(kind, scope, conn)
    if str(lang).upper() == str(base).upper():
        return ('%s 의 %s 글은 **저자의 원문**입니다 — 다듬지 않습니다. '
                '우리가 만든 번역문(다른 언어)만 다듬을 수 있습니다.'
                % (ASSET.get(kind, {}).get('name', kind), base))
    return ''


def is_mine(kind, scope='', conn=None):
    """우리가 쓰는 글인가 — 거짓이면 **신규 작성이라는 일이 없다**."""
    if kind == 'REF_UNIT' and conn is not None:
        return _ref_is_mine(conn, scope)
    return bool(ASSET.get(kind, {}).get('mine', True))


# ── 범위 축 ───────────────────────────────────────────────────────────

def axis_values(conn, axis, lang='KO'):
    """그 축에서 선택할 수 있는 것 — `[(값, 보일 이름)]`. 맨 앞은 「(전체)」."""
    out = [('', '(전체)')]
    if axis == 'BIBLE':
        # ⚠ `book_names` 의 칸은 `bcode` 가 아니라 **`book_code`** 다(실측으로 당했다).
        rows = conn.execute(
            "SELECT book_code, COALESCE("
            "  MAX(CASE WHEN UPPER(lang_code)=? THEN full_name END),"
            "  MAX(CASE WHEN UPPER(lang_code)='EN' THEN full_name END),"
            "  CAST(book_code AS TEXT)) "
            "FROM book_names GROUP BY book_code ORDER BY book_code",
            (lang.upper(),)).fetchall()
        out += [(str(r[0]), '%02d %s' % (r[0], r[1])) for r in rows]
    elif axis == 'ENTITY':
        rows = conn.execute(
            "SELECT entity_type, COUNT(*) FROM sys_entity_master "
            "WHERE record_status='LIVE' GROUP BY 1 ORDER BY 2 DESC").fetchall()
        out += [(r[0], '%s (%s)' % (r[0], format(r[1], ','))) for r in rows]
    elif axis == 'LIB':
        rows = conn.execute(
            "SELECT book_id, book_code, COALESCE(author,'') FROM sys_book_asset "
            "WHERE record_status='LIVE' ORDER BY book_id").fetchall()
        out += [(str(r[0]), '%s — %s' % (r[1], r[2])) for r in rows]
    elif axis == 'COMM':
        rows = conn.execute(
            "SELECT commentary_id, commentary_code FROM sys_commentary_source "
            "ORDER BY commentary_id").fetchall()
        out += [(str(r[0]), r[1]) for r in rows]
    elif axis == 'REF' or axis in REF_AXIS_TYPE:
        # ⚠ **유닛이 0인 자료집은 안 올린다** — 스트롱 원어사전은 가상 사전
        #   이라 고칠 글이 없다. 올리면 눌러도 빈 목록이다(§0-1).
        q = ("SELECT s.ref_src_id, s.src_code, COALESCE(s.title_ko, s.title,'')"
             " FROM sys_ref_source s WHERE s.record_status='LIVE' %s"
             "   AND EXISTS(SELECT 1 FROM sys_ref_unit u"
             "               WHERE u.ref_src_id=s.ref_src_id"
             "                 AND u.record_status='LIVE')"
             " ORDER BY s.ref_src_id")
        ar = []
        if axis in REF_AXIS_TYPE:
            _ty = REF_AXIS_TYPE[axis]
            _ty = _ty if isinstance(_ty, tuple) else (_ty,)
            q = q % ('AND UPPER(s.src_type) IN (%s)' % ','.join('?' * len(_ty)))
            ar = list(_ty)
        else:
            q = q % ''
        rows = conn.execute(q, ar).fetchall()
        out += [(str(r[0]), '%s — %s' % (r[1], r[2])) for r in rows]
    return out


_ABBR = {}


def book_abbr(conn, lang='KO'):
    """`{bcode: 약명}` — 화면 글자는 **사람 말**이라야 한다(std_audit).

    ⚠ 한 번만 읽고 기억한다 — 자리가 3만 개가 넘어 줄마다 물으면 느리다.
    ⚠ `book_names` 의 칸은 `book_code` 다(`bcode` 가 아니다).
    """
    lang = (lang or 'KO').upper()
    if lang in _ABBR:
        return _ABBR[lang]
    m = {}
    for bc, sn, fn in conn.execute(
            "SELECT book_code, short_name, full_name FROM book_names "
            "WHERE UPPER(lang_code) IN (?, 'EN') "
            "ORDER BY CASE WHEN UPPER(lang_code)=? THEN 1 ELSE 0 END",
            (lang, lang)):
        m[bc] = sn or fn or str(bc)
    _ABBR[lang] = m
    return m


# ── 자리 ──────────────────────────────────────────────────────────────

NO_NAME = '(이름 없음)'      # 화면이 「없다」를 말하는 한 가지 글자


def book_full(conn, lang='KO'):
    """`{bcode: 정식 이름}` — 없으면 약명, 그것도 없으면 번호."""
    out = {}
    try:
        for bc, nm in conn.execute(
                "SELECT book_code, COALESCE(NULLIF(TRIM(full_name),''),"
                "       NULLIF(TRIM(short_name),'')) FROM book_names "
                "WHERE UPPER(lang_code)=?", ((lang or 'KO').upper(),)):
            if nm:
                out[bc] = nm
    except Exception:                                     # noqa: BLE001
        pass
    return out


def slots(conn, kind, scope='', limit=0, lang='KO'):
    """그 범위 안의 **자리** — `[(자리번호, 이름)]`.

    ⚠ 자리는 **글이 들어갈 칸**이지 「이미 쓴 글」이 아니다. 그래서 빈 자리도
      반드시 나온다 — 그것이 신규 작성의 대상이다(§0-1 「없으면 안 보인다」의
      반대편: 여기서는 **없는 것이 일감**이다).
    """
    a = ASSET[kind]
    sc = (scope or '').strip()
    sl, args = a['slot'], []
    ab = book_abbr(conn, lang)
    if kind == 'VERS_UNLINK':
        # ★ 317차-20 — 해제분석의 자리는 **이어진 연결이 있는 절**만(사람·AI 모두)
        q = ("SELECT b.verse_id, b.bcode, b.chapter, b.verse FROM bible_index b "
             "WHERE b.verse_id IN (SELECT clicked_id FROM sys_link_asset WHERE link_type='VERS_VERS'"
             " AND record_status='LIVE' UNION SELECT target_id FROM sys_link_asset"
             " WHERE link_type='VERS_VERS' AND record_status='LIVE') %s ORDER BY b.sort_order"
             ) % ('AND b.bcode=?' if sc else '')
        rows = conn.execute(q, [int(sc)] if sc else []).fetchall()
        return [(r[0], '%s %d:%d' % (ab.get(r[1], r[1]), r[2], r[3])) for r in _cap(rows, limit)]
    if sl == 'VERSE':
        q = ("SELECT verse_id, bcode, chapter, verse FROM bible_index "
             "%s ORDER BY sort_order")
        q = q % ('WHERE bcode=?' if sc else '')
        if sc:
            args = [int(sc)]
        rows = conn.execute(q, args).fetchall()
        return [(r[0], '%s %d:%d' % (ab.get(r[1], r[1]), r[2], r[3]))
                for r in _cap(rows, limit)]
    if sl == 'CHAP':
        q = ("SELECT DISTINCT bcode, chapter FROM bible_index "
             "%s ORDER BY bcode, chapter") % ('WHERE bcode=?' if sc else '')
        if sc:
            args = [int(sc)]
        rows = conn.execute(q, args).fetchall()
        return [(r[0] * 1000 + r[1], '%s %d장' % (ab.get(r[0], r[0]), r[1]))
                for r in _cap(rows, limit)]
    if sl == 'BOOK':
        q = "SELECT DISTINCT bcode FROM bible_index %s ORDER BY bcode" % (
            'WHERE bcode=?' if sc else '')
        if sc:
            args = [int(sc)]
        rows = conn.execute(q, args).fetchall()
        # ★ 약명이 아니라 **번호 + 정식 이름** — 66권을 훑을 때 약명만으로는
        #   차례를 못 짚는다(사용자 「사람이 이해하게」).
        full = book_full(conn, lang)
        return [(r[0], '%02d %s' % (r[0], full.get(r[0], ab.get(r[0], r[0]))))
                for r in _cap(rows, limit)]
    if sl == 'PERI':
        # ★ **범위와 제목을 함께** — 「…부터」는 끝을 안 말해 어디까지인지
        #   모르고, 제목이 없으면 좌표만 늘어선다.
        q = ("SELECT p.pericope_id, b.bcode, b.chapter, b.verse,"
             "       e.chapter, e.verse, COALESCE(NULLIF(TRIM(t.contents),''),"
             "                             NULLIF(TRIM(t2.contents),'')) "
             "FROM sys_pericope_asset p "
             "  JOIN bible_index b ON b.verse_id=p.start_vid "
             "  LEFT JOIN bible_index e ON e.verse_id=p.end_vid "
             "  LEFT JOIN sys_text_asset t ON t.text_type='PERI_TITLE'"
             "       AND t.clicked_id=p.pericope_id AND UPPER(t.lang_code)=?"
             "       AND t.record_status='LIVE' "
             # ⚠ 고른 언어에 제목이 없으면 **영어로 떨어진다** — 실측
             #   `PERI_TITLE` 은 EN 3,413편뿐이라 폴백이 없으면 좌표만 뜬다.
             "  LEFT JOIN sys_text_asset t2 ON t2.text_type='PERI_TITLE'"
             "       AND t2.clicked_id=p.pericope_id AND UPPER(t2.lang_code)='EN'"
             "       AND t2.record_status='LIVE' "
             "WHERE p.record_status='LIVE' AND p.peri_type='BODY' %s "
             "ORDER BY p.sort_order") % ('AND b.bcode=?' if sc else '')
        args = [(lang or 'KO').upper()]
        if sc:
            args.append(int(sc))
        rows = conn.execute(q, args).fetchall()
        out = []
        for r in _cap(rows, limit):
            ref = '%s %d:%d' % (ab.get(r[1], r[1]), r[2], r[3])
            if r[4] and (r[4], r[5]) != (r[2], r[3]):
                ref += ('-%d' % r[5]) if r[4] == r[2] else ('-%d:%d' % (r[4], r[5]))
            out.append((r[0], ('%s  %s' % (ref, r[6])).strip() if r[6] else ref))
        return out
    if sl == 'LINK':
        # ⚠⚠ **상대 절이 있어야 줄이 서로 다르다** — 옛 글자는 한 절의 연결이
        #   여럿일 때 「창 1:1 의 연결」이 그 수만큼 똑같이 늘어섰다(실측).
        q = ("SELECT l.sys_link_id, b.bcode, b.chapter, b.verse,"
             "       t.bcode, t.chapter, t.verse "
             "FROM sys_link_asset l "
             "  JOIN bible_index b ON b.verse_id=l.clicked_id "
             "  LEFT JOIN bible_index t ON t.verse_id=l.target_id "
             "WHERE l.link_type='VERS_VERS' AND l.record_status='LIVE' %s "
             "ORDER BY b.sort_order, l.sys_link_id") % ('AND b.bcode=?' if sc else '')
        if sc:
            args = [int(sc)]
        rows = conn.execute(q, args).fetchall()
        out = []
        for r in _cap(rows, limit):
            a1 = '%s %d:%d' % (ab.get(r[1], r[1]), r[2], r[3])
            a2 = ('%s %d:%d' % (ab.get(r[4], r[4]), r[5], r[6])) if r[4] else '?'
            out.append((r[0], '%s \u2192 %s' % (a1, a2)))
        return out
    if sl == 'ENTI':
        # ★★★ **화면 글자에 코드를 안 적는다**(§0 · `std_audit` 과 같은 규칙).
        #   실측 용어 11,016개가 **전부 EN 이름을 갖고 있다**(KO 는 269) —
        #   암호가 보이던 것은 이름이 없어서가 아니라 **코드를 쓰고 있어서**다.
        #   ⇒ 고른 언어 → EN → 그래도 없으면 **「(이름 없음)」** 이라 적는다.
        #     ⚠ 코드를 꼬리로 붙이지 않는다 — 찾기 칸이 코드도 받는다.
        lg = (lang or 'KO').upper()
        q = ("SELECT m.entity_id,"
             " (SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
             "    AND clicked_id=m.entity_id AND UPPER(lang_code)=?"
             "    AND record_status='LIVE' AND TRIM(COALESCE(contents,''))<>''),"
             " (SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
             "    AND clicked_id=m.entity_id AND UPPER(lang_code)='EN'"
             "    AND record_status='LIVE' AND TRIM(COALESCE(contents,''))<>'')"
             " FROM sys_entity_master m WHERE m.record_status='LIVE' %s"
             " ORDER BY m.importance DESC, m.entity_id"
             ) % ('AND m.entity_type=?' if sc else '')
        args = [lg] + ([sc] if sc else [])
        return [(r[0], (r[1] or r[2] or NO_NAME).strip())
                for r in _cap(conn.execute(q, args).fetchall(), limit)]
    if sl == 'UNIT':
        q = ("SELECT unit_id, COALESCE(unit_label, 'unit ' || unit_id) "
             "FROM sys_book_unit WHERE record_status='LIVE' %s "
             "ORDER BY book_id, sequence") % ('AND book_id=?' if sc else '')
        if sc:
            args = [int(sc)]
        return [(r[0], r[1]) for r in _cap(conn.execute(q, args).fetchall(), limit)]
    if sl == 'BTASTE':
        # ★ 자리 = **책마다 첫 편 하나**. 맛보기가 고르는 그 편이다 —
        #   자리를 여기서 다시 고르면 「옮긴 편과 실리는 편이 다르다」가 난다.
        import db_pack_taste as _T
        out = []
        for uid, bid, code, label in _T.first_units(conn):
            if sc and int(sc) != bid:
                continue
            out.append((uid, '%s — %s' % (code, label or ('unit %d' % uid))))
        return _cap(out, limit)
    if sl == 'BOOKA':
        # ★ 자리 = **책 한 권**. 이름은 「코드 — 제목」 —
        #   저자만으로는 한 저자의 여러 권이 구분되지 않는다.
        q = ("SELECT a.book_id, a.book_code,"
             "       COALESCE(NULLIF(TRIM(t.title),''),"
             "                NULLIF(TRIM(a.title),''), a.book_code) "
             "FROM sys_book_asset a "
             "  LEFT JOIN sys_book_asset_text t ON t.book_id=a.book_id"
             "   AND UPPER(t.lang_code)=? "
             "WHERE a.record_status='LIVE' %s ORDER BY a.book_id"
             ) % ('AND a.book_id=?' if sc else '')
        args = [(lang or 'KO').upper()] + ([int(sc)] if sc else [])
        return [(r[0], '%s — %s' % (r[1], r[2]))
                for r in _cap(conn.execute(q, args).fetchall(), limit)]

    if sl == 'ENTRY':
        q = ("SELECT e.entry_id, COALESCE(e.bcode,0), COALESCE(e.chapter,0),"
             "       b.bcode, b.chapter, b.verse, v.chapter, v.verse "
             "FROM sys_commentary_entry e "
             "  LEFT JOIN bible_index b ON b.verse_id=e.start_vid "
             "  LEFT JOIN bible_index v ON v.verse_id=e.end_vid "
             "WHERE e.record_status='LIVE' %s "
             "ORDER BY COALESCE(b.sort_order, 0), e.entry_id"
             ) % ('AND e.commentary_id=?' if sc else '')
        if sc:
            args = [int(sc)]
        rows = conn.execute(q, args).fetchall()
        # ⚠⚠ 옛 글자(`GEN 1장`)는 **한 장의 항목이 여럿일 때 전부 똑같았다**
        #   (실측 네 줄이 같았다). 시작 절 좌표로 줄을 가른다.
        #   ⚠ `sys_commentary_entry.bcode` 는 **글자**다('ACT') — 숫자 서식으로
        #     찍으면 그 자리에서 터진다(실측으로 당했다). 그래서 좌표는
        #     `bible_index` 에서 받아 온다.
        out = []
        for r in _cap(rows, limit):
            if r[3]:
                ref = '%s %d:%d' % (ab.get(r[3], r[3]), r[4], r[5])
                if r[6] and (r[6], r[7]) != (r[4], r[5]):
                    ref += ('-%d' % r[7]) if r[6] == r[4] else \
                        ('-%d:%d' % (r[6], r[7]))
            else:
                ref = '%s %s장' % (r[1], r[2])
            out.append((r[0], ref))
        return out
    if sl == 'RUNIT' or sl in REF_SLOT_TYPE:
        # ⚠ 범위를 안 고르면 **그 갈래 전체**다 — 옛 한 자산은 여기서 문답·
        #   사전·연구를 한 목록에 쏟아 무엇을 고르는지 알 수 없었다.
        # ★ 1.txt 1번 9) — 관리자 「연구자료 ▸ 새 글」이 목록 이름을
        #   `(제목 없음)` 으로 심는다(실측 45편). 그 글자는 자리 이름이 아니라
        #   **빈칸**이다 — 비었으면 그 글의 제목(한국어 먼저)을 대신 쓴다.
        q = ("SELECT u.ref_unit_id, COALESCE("
             "  NULLIF(NULLIF(TRIM(u.unit_label),''),'(제목 없음)'),"
             "  (SELECT t.title FROM sys_ref_text t WHERE t.ref_unit_id=u.ref_unit_id"
             "     AND TRIM(COALESCE(t.title,''))<>''"
             "   ORDER BY CASE WHEN UPPER(t.lang_code)='KO' THEN 0 ELSE 1 END LIMIT 1),"
             "  u.unit_code, '') "
             "FROM sys_ref_unit u JOIN sys_ref_source s"
             "  ON s.ref_src_id=u.ref_src_id "
             "WHERE u.record_status='LIVE' %s %s "
             "ORDER BY u.ref_src_id, u.sequence")
        args = []
        _ty = REF_SLOT_TYPE.get(sl)
        _ty = (_ty if isinstance(_ty, tuple) else (_ty,)) if _ty else ()
        q = q % (('AND UPPER(s.src_type) IN (%s)' % ','.join('?' * len(_ty))) if _ty else '',
                 'AND u.ref_src_id=?' if sc else '')
        args += list(_ty)
        if sc:
            args.append(int(sc))
        return [(r[0], r[1]) for r in _cap(conn.execute(q, args).fetchall(), limit)]
    raise AssertionError('모르는 자리 갈래: %r' % sl)


def gist(conn, kind, scope='', ids=None, lang='KO', n=40):
    """`{자리번호: 곁들임}` — 줄에 함께 보일 **짧은 속내용**.

    ★★★ **좌표만으로는 손이 안 멈춘다** — 「창 1:1」 옆에 본문 앞머리가
      있어야 어느 자리인지 안다(사용자 「사람이 이해하게」).
    ⚠⚠ **여기만 무겁다** — 절이 31,104개라 `slots()` 에 본문을 끼우면
      `have()`·`todo()` 까지 함께 느려진다. 그래서 **화면이 쓰는 이 문**에만
      둔다. 한 조회로 가져온다(자리마다 물으면 화면이 멎는다).
    ⚠ 없는 자산은 **빈 dict** — 「곁들임이 없다」가 흠이 아니다.
    """
    a = ASSET[kind]
    if kind == 'VERS_UNLINK':
        # ★ 317차-20 — 줄 곁들임 = 연결 수 · 블랙리스트 항목(무엇이 낮은가)
        _bl = link_blacklist(conn)
        _n = {}
        for a_, b_ in conn.execute("SELECT clicked_id, target_id FROM sys_link_asset"
                                   " WHERE link_type='VERS_VERS' AND record_status='LIVE'"):
            _n[a_] = _n.get(a_, 0) + 1
            _n[b_] = _n.get(b_, 0) + 1
        out = {}
        for sid in (ids or []):
            fl = _bl.get(sid) or []
            cnt = {}
            for _lid, f in fl:
                for x in f:
                    cnt[x] = cnt.get(x, 0) + 1
            out[sid] = '연결 %d%s' % (_n.get(sid, 0), (' · ⚠ ' + ' · '.join('%s %d' % (k, v) for k, v in cnt.items()))
                                     if cnt else '')
        return out
    sl, sc = a['slot'], (scope or '').strip()
    out = {}
    try:
        if sl in ('VERSE', 'CHAP', 'PERI'):
            # 절 본문 — 우리 기준 역본. 장·단락은 그 첫 절의 본문.
            ver = 'KRV' if (lang or 'KO').upper() == 'KO' else 'BSB'
            if sl == 'VERSE':
                q = ("SELECT b.verse_id, c.verse_text FROM bible_index b"
                     "  JOIN bible_content c ON c.verse_id=b.verse_id"
                     "   AND c.version_code=? %s")
                ar = [ver] + ([int(sc)] if sc else [])
                q = q % ('WHERE b.bcode=?' if sc else '')
            elif sl == 'CHAP':
                q = ("SELECT b.bcode*1000+b.chapter, c.verse_text"
                     " FROM bible_index b"
                     "  JOIN bible_content c ON c.verse_id=b.verse_id"
                     "   AND c.version_code=? WHERE b.verse=1 %s")
                ar = [ver] + ([int(sc)] if sc else [])
                q = q % ('AND b.bcode=?' if sc else '')
            else:
                q = ("SELECT p.pericope_id, c.verse_text"
                     " FROM sys_pericope_asset p"
                     "  JOIN bible_index b ON b.verse_id=p.start_vid"
                     "  JOIN bible_content c ON c.verse_id=p.start_vid"
                     "   AND c.version_code=?"
                     " WHERE p.record_status='LIVE' AND p.peri_type='BODY' %s")
                ar = [ver] + ([int(sc)] if sc else [])
                q = q % ('AND b.bcode=?' if sc else '')
            for sid, tx in conn.execute(q, ar):
                if ids is None or sid in ids:
                    out[sid] = (tx or '').strip()[:n]
        elif sl == 'UNIT':
            q = ("SELECT u.unit_id, SUBSTR(TRIM(t.body_text),1,%d)"
                 " FROM sys_book_unit u"
                 "  JOIN sys_book_unit_text t ON t.unit_id=u.unit_id"
                 "   AND t.record_status='LIVE'"
                 " WHERE u.record_status='LIVE' %s GROUP BY u.unit_id"
                 % (n, 'AND u.book_id=?' if sc else ''))
            for sid, tx in conn.execute(q, [int(sc)] if sc else []):
                if ids is None or sid in ids:
                    out[sid] = (tx or '').strip()
        elif sl == 'BTASTE':
            import db_pack_taste as _T
            for _u, _b, _c, _l in _T.first_units(conn):
                if sc and int(sc) != _b:
                    continue
                if ids is not None and _u not in ids:
                    continue
                out[_u] = (_T.taste_text(conn, _u, lang) or '').strip()[:n]
        elif sl == 'BOOKA':
            q = ("SELECT a.book_id, SUBSTR(TRIM(COALESCE(t.description,"
                 " a.description, '')),1,%d) FROM sys_book_asset a"
                 "  LEFT JOIN sys_book_asset_text t ON t.book_id=a.book_id"
                 "   AND UPPER(t.lang_code)=?"
                 " WHERE a.record_status='LIVE' %s"
                 % (n, 'AND a.book_id=?' if sc else ''))
            ar = [(lang or 'KO').upper()] + ([int(sc)] if sc else [])
            for sid, tx in conn.execute(q, ar):
                if ids is None or sid in ids:
                    out[sid] = (tx or '').strip()
        elif sl == 'RUNIT' or sl in REF_SLOT_TYPE:
            q = ("SELECT u.ref_unit_id, SUBSTR(TRIM(COALESCE(t.body_text,"
                 " u.unit_question, u.unit_answer, '')),1,%d)"
                 " FROM sys_ref_unit u"
                 "  LEFT JOIN sys_ref_text t ON t.ref_unit_id=u.ref_unit_id"
                 " WHERE u.record_status='LIVE' %s GROUP BY u.ref_unit_id"
                 % (n, 'AND u.ref_src_id=?' if sc else ''))
            for sid, tx in conn.execute(q, [int(sc)] if sc else []):
                if ids is None or sid in ids:
                    out[sid] = (tx or '').strip()
    except Exception:                                     # noqa: BLE001
        return {}
    return out


def slot_rows(conn, kind, scope='', lang='KO', task=None, base=None,
              limit=0, with_gist=True, parts=None, add=()):
    """화면이 쓰는 **목록 재료 한 문** — `[(번호, 이름, 곁들임, 언어들, 할일)]`.

    ★★★ **목록과 현황을 한 문에서 낸다.** 그전에는 `slots()`(이름)와
      `status()`(언어별 수)가 따로 돌아, 왼쪽에 언어 표가 **따로** 떠 있었다.
      사용자 지적 「대상을 선택하지도 않았는데 언어별 상태를 보여주면
      무엇하라는 것인가」 — 언어는 **유닛 줄의 한 칸**이라야 쓸모가 있다.
    ⚠ **자리마다 조회하지 않는다** — 절이 31,104개다. `slots`·`have`·`gist`
      **세 조회**로 끝낸다.
    ⚠ `task` 를 주면 마지막 칸이 「이 줄이 지금 할 일인가」를 말한다.
      목록을 **거르지는 않는다** — 거르는 것은 화면의 체크가 정한다.
    """
    lg = (lang or 'KO').upper()
    bs = (base or base_lang(kind, scope, conn)).upper()
    # ★ 296차(1.txt 2번 2)) — 자리 **이름**은 관리자 언어(KO)로 못 박는다.
    #   그전에는 대상 언어를 고르면 책 약명·제목이 그 언어로 바뀌어
    #   「번역이 된 것처럼」 보였다(사용자 「관리자 화면은 모두 한글이 기본」).
    #   대상 언어는 「있는 언어」 칸(`langs`)만 정한다.
    rows = slots(conn, kind, scope, limit=limit, lang='KO')
    hv = have(conn, kind, scope, parts=parts, add=add)
    ids = set(r[0] for r in rows)
    gs = gist(conn, kind, scope, ids, lg) if with_gist else {}
    order = [x for x in ui_langs() if x]           # 화면에 늘 같은 차례로
    # ★★★ **AI 적재분을 언어마다 적는다**(2026-09-25 사용자 지시) —
    #   다시 쓰기는 **대부분 사람이 쓴 글을 덮는 일**이다(실측 AI 적재 365건 ↔
    #   절 설명문 KO 24,521편). 표시가 없는 언어가 곧 사람 글이다.
    ai = ai_loaded(conn, kind)
    out = []
    for sid, name in rows:
        got = hv.get(sid, set())
        _ai = ai.get(int(sid), set())
        langs = [_mark_ai(x, _ai) for x in order if x in got] + \
                [_mark_ai(x, _ai) for x in sorted(x for x in got
                                                  if x not in order)]
        todo_ = None
        if task:
            if task == 'NEW':
                todo_ = bs not in got
            elif task == 'TRANS':
                todo_ = (bs in got) and (lg not in got)
            else:
                todo_ = lg in got
        out.append((sid, name, gs.get(sid, ''), ' '.join(langs), todo_))
    return out


def _cap(rows, limit):
    return rows[:limit] if limit else rows


# ── 이미 쓴 것 ────────────────────────────────────────────────────────

def have(conn, kind, scope='', parts=None, add=()):
    """`{자리번호: {언어, ...}}` — **그 자리에 그 언어 글이 있는가**.

    ⚠ 자리 목록으로 한 번 걸러 낸다 — 표 전체를 세면 다른 책의 글까지 센다.
    """
    a = ASSET[kind]
    ids = set(sid for sid, _ in slots(conn, kind, scope))   # 이름은 안 쓴다
    out = {}
    if a['store'] == 'BUNDLE':
        # ★★★ **필수 칸이 다 있어야 「썼다」** — 하나라도 비면 할 일이다.
        #   ⚠ 「연구질문」은 필수가 아니므로 안 센다(사용자 지시 —
        #     「한 구절에 없어도 좋고, 여러개 있어도 좋다」).
        got = {}
        _need = bundle_need(parts, add)          # ★ 317차-19 — 고른 칸이 기준
        if not _need:                            # 덧붙이기만 — 전부 할 일
            return {sid: set() for sid in ids}
        for k in _need:
            p = BUNDLE_PART[k]
            if p.get('store') == 'REF':
                # 연구자료 = `sys_ref_unit` 의 `AIV<절번호>`(덧붙인 편 `-2` … 포함)
                for code, lg in conn.execute(
                        "SELECT u.unit_code, UPPER(t.lang_code) FROM sys_ref_unit u"
                        " JOIN sys_ref_text t ON t.ref_unit_id=u.ref_unit_id"
                        " WHERE u.unit_code LIKE 'AIV%' AND t.record_status='LIVE'"
                        " AND TRIM(COALESCE(t.body_text,''))<>''"):
                    try:
                        sid = int(code[3:9])
                    except ValueError:
                        continue
                    if sid in ids:
                        got.setdefault((sid, lg), set()).add(k)
                continue
            q = ("SELECT clicked_id, UPPER(lang_code) FROM sys_text_asset "
                 "WHERE text_type=? AND record_status='LIVE' "
                 "AND TRIM(COALESCE(contents,'')) <> ''")
            ar = [p['text_type']]
            if p['variant']:
                q += " AND text_variant=?"
                ar.append(p['variant'])
            for sid, lg in conn.execute(q, ar):
                if sid in ids:
                    got.setdefault((sid, lg), set()).add(k)
        need = set(_need)
        for (sid, lg), ks in got.items():
            if ks >= need:
                out.setdefault(sid, set()).add(lg)
        for sid in ids:
            out.setdefault(sid, set())
        return out
    if kind == 'VERS_UNLINK':
        # ★ 317차-20 — 「할 일」 = **블랙리스트 연결이 있는 절**. 없는 절은 「완료」로 친다.
        _bad = {v for v, _fl in link_blacklist(conn).items()}
        _b = base_lang(kind, scope, conn)
        return {sid: (set() if sid in _bad else {_b}) for sid in ids}
    if a['store'] == 'LINK':
        # 「있다」 = **AI 연결기가 이미 이은 절**(사람 연결은 안 센다 — 사람이 이은 절도
        #   연결기의 일감이다). 언어 축이 없으므로 기준 언어 하나로 적는다.
        rows = [(int(v), base_lang(kind, scope, conn)) for (v,) in conn.execute(
            "SELECT clicked_id FROM sys_link_asset WHERE link_type='VERS_VERS'"
            "  AND record_status='LIVE' AND COALESCE(source,'') LIKE 'AILINK:%'"
            " UNION SELECT target_id FROM sys_link_asset WHERE link_type='VERS_VERS'"
            "  AND record_status='LIVE' AND COALESCE(source,'') LIKE 'AILINK:%'").fetchall()]
    elif a['store'] == 'TEXT':
        q = ("SELECT clicked_id, UPPER(lang_code) FROM sys_text_asset "
             "WHERE text_type=? AND record_status='LIVE' "
             "AND TRIM(COALESCE(contents,'')) <> ''")
        args = [a['text_type']]
        if a['variant']:
            q += " AND text_variant=?"
            args.append(a['variant'])
        rows = conn.execute(q, args).fetchall()
    elif a['store'] == 'BOOK':
        rows = conn.execute(
            "SELECT unit_id, UPPER(lang_code) FROM sys_book_unit_text "
            "WHERE record_status='LIVE' AND TRIM(COALESCE(body_text,'')) <> ''"
        ).fetchall()
    elif a['store'] == 'BTASTE':
        # ★ 원문 조각은 **저장하지 않고 그때 잘라 낸다** — 그래서 「있다」의
        #   잣대가 표 행이 아니라 **본문이 있나**이다.
        import db_pack_taste as _T
        rows = []
        for _u, _b, _c, _l in _T.first_units(conn):
            # ⚠ **이미 옮겨 둔 번역본도 「있다」**(실측 9권) — 원문만 세면
            #   그 아홉 권을 또 옮기게 된다(진짜가 언제나 이긴다).
            rows += [(_u, lg) for lg in _T.unit_langs(conn, _u)]
        rows += [(u, lg) for u, lg, _b in _T.taste_rows(conn)]
    elif a['store'] == 'BOOKA':
        rows = conn.execute(
            "SELECT book_id, UPPER(lang_code) FROM sys_book_asset_text "
            "WHERE COALESCE(record_status,'LIVE')='LIVE' "
            "  AND TRIM(COALESCE(description,'')) <> ''").fetchall()
    elif a['store'] == 'COMM':
        rows = conn.execute(
            "SELECT entry_id, UPPER(lang_code) FROM sys_commentary_text "
            "WHERE record_status='LIVE' AND TRIM(COALESCE(body_text,'')) <> ''"
        ).fetchall()
    else:                                                  # REF
        rows = conn.execute(
            "SELECT ref_unit_id, UPPER(lang_code) FROM sys_ref_text "
            "WHERE record_status='LIVE' AND TRIM(COALESCE(body_text,'')) <> ''"
        ).fetchall()
        # ★★★ **문답은 본문이 칸에 있다** — 하이델베르크 129·WSC 107
        #   이 `sys_ref_text` 0행이다(루터 31만 있다). 그대로 세면
        #   **원문 EN 이 0** 이라 「신규 작성 236자리」라는 헛일감이
        #   뜬다. 잣대는 `sys_ref_source.lang_code` — **그 자료집의
        #   원문 언어에서는 칸이 본문이고 `sys_ref_text` 는 번역 층**
        #   이다(`panel_book_manager._doc_trans_counts` 와 같은 규칙).
        rows += conn.execute(
            "SELECT u.ref_unit_id, UPPER(COALESCE(s.lang_code,'EN')) "
            "  FROM sys_ref_unit u JOIN sys_ref_source s"
            "    ON s.ref_src_id = u.ref_src_id "
            " WHERE u.record_status='LIVE'"
            "   AND TRIM(COALESCE(u.unit_answer,'')) <> ''").fetchall()
    for sid, lg in rows:
        if sid in ids:
            out.setdefault(sid, set()).add(lg)
    for sid in ids:
        out.setdefault(sid, set())
    return out


def sizes(conn, kind, scope='', lang=None):
    """`{자리번호: 글자 수}` — **그 언어 글이 몇 자인가**.

    ★★★ 사용자 지시(2026-09-23) — 「번역작업의 경우 **각각 용량이 얼마나
      되는지 표시**해야 한다」. 자리마다 크기가 천차만별이라(실측 절 설명문
      283자 ↔ 도서 본문 **평균 16,446자 · 최대 88,911자**) 몇 개를 한 번에
      보낼 수 있는지가 자리마다 다르다.
    ⚠ **없는 자리는 열쇠 자체를 안 넣는다** — 0 으로 적으면 「빈 글」과
      「아직 없는 글」이 구분되지 않는다.
    """
    a = ASSET[kind]
    lang = (lang or base_lang(kind, scope, conn)).upper()
    ids = set(sid for sid, _ in slots(conn, kind, scope))
    out = {}
    if a['store'] == 'LINK':
        return out                    # 연결은 글자 수로 잴 것이 없다
    if a['store'] == 'BUNDLE':
        # ★ 묶음의 자수 = **칸을 다 더한 것**(한 번에 보낼 양이 그것이다)
        # ⚠ **연구자료 칸은 여기서 못 센다** — `sys_ref_unit` 에 담기고
        #   그 자리는 절이 아니라 유닛이다. 셈에서 빠지는 것을 적어 둔다.
        for p in BUNDLE_PARTS:
            if not p[2]:
                continue
            q = ("SELECT clicked_id, LENGTH(contents) FROM sys_text_asset "
                 "WHERE text_type=? AND UPPER(lang_code)=? "
                 "AND record_status='LIVE' AND TRIM(COALESCE(contents,''))<>''")
            ar = [p[2], lang]
            if p[3]:
                q += " AND text_variant=?"
                ar.append(p[3])
            for sid, ln in conn.execute(q, ar):
                if sid in ids:
                    out[sid] = out.get(sid, 0) + (ln or 0)
        return out
    if a['store'] == 'TEXT':
        q = ("SELECT clicked_id, LENGTH(contents) FROM sys_text_asset "
             "WHERE text_type=? AND UPPER(lang_code)=? AND record_status='LIVE' "
             "AND TRIM(COALESCE(contents,'')) <> ''")
        args = [a['text_type'], lang]
        if a['variant']:
            q += " AND text_variant=?"
            args.append(a['variant'])
        rows = conn.execute(q, args).fetchall()
    elif a['store'] == 'BOOK':
        rows = conn.execute(
            "SELECT unit_id, LENGTH(body_text) FROM sys_book_unit_text "
            "WHERE UPPER(lang_code)=? AND record_status='LIVE' "
            "AND TRIM(COALESCE(body_text,'')) <> ''", (lang,)).fetchall()
    elif a['store'] == 'BTASTE':
        import db_pack_taste as _T
        rows = []
        for _u, _b, _c, _l in _T.first_units(conn):
            _t = _T.taste_text(conn, _u, lang)
            if _t:
                rows.append((_u, len(_t)))
    elif a['store'] == 'BOOKA':
        rows = conn.execute(
            "SELECT book_id, LENGTH(description) FROM sys_book_asset_text "
            "WHERE UPPER(lang_code)=? AND COALESCE(record_status,'LIVE')='LIVE' "
            "AND TRIM(COALESCE(description,'')) <> ''", (lang,)).fetchall()
    elif a['store'] == 'COMM':
        rows = conn.execute(
            "SELECT entry_id, LENGTH(body_text) FROM sys_commentary_text "
            "WHERE UPPER(lang_code)=? AND record_status='LIVE' "
            "AND TRIM(COALESCE(body_text,'')) <> ''", (lang,)).fetchall()
    else:
        rows = conn.execute(
            "SELECT ref_unit_id, LENGTH(body_text) FROM sys_ref_text "
            "WHERE UPPER(lang_code)=? AND record_status='LIVE' "
            "AND TRIM(COALESCE(body_text,'')) <> ''", (lang,)).fetchall()
        # ★ 문답은 칸이 본문이다(위 `have` 와 같은 규칙)
        rows += conn.execute(
            "SELECT u.ref_unit_id, LENGTH(COALESCE(u.unit_question,''))"
            "       + LENGTH(COALESCE(u.unit_answer,'')) + 2 "
            "  FROM sys_ref_unit u JOIN sys_ref_source s"
            "    ON s.ref_src_id = u.ref_src_id "
            " WHERE u.record_status='LIVE'"
            "   AND UPPER(COALESCE(s.lang_code,'EN'))=?"
            "   AND TRIM(COALESCE(u.unit_answer,'')) <> ''",
            (lang,)).fetchall()
    for sid, n in rows:
        if sid in ids:
            out[sid] = max(out.get(sid, 0), int(n or 0))
    return out


# ══════════════════════════════════════════════════════════════════
#  재료 — 「무엇을 보고 쓰나」 (2026-09-23 277차)
# ══════════════════════════════════════════════════════════════════

NL_ = chr(10)
INTRO_UNITS = 24         # 소개문 재료로 실을 편 제목 수
INTRO_HEAD = 1200        # 첫 편에서 가져올 글자

REF_VERSIONS = (('KRV', 'KO', '개역한글'), ('BSB', 'EN', 'BSB'))
COMM_SRCS = ('BARNES_NT', 'CLARKE', 'GILL', 'JFB')   # 절 단위가 두꺼운 것부터
COMM_MAX = 1800          # 주석 한 소스에서 가져올 최대 글자


def _ref(conn, vid, lang='KO'):
    """`창 1:1` 꼴 약명."""
    r = conn.execute(
        "SELECT b.bcode, b.chapter, b.verse FROM bible_index b WHERE b.verse_id=?",
        (vid,)).fetchone()
    if not r:
        return str(vid)
    return '%s %d:%d' % (book_abbr(conn, lang).get(r[0], r[0]), r[1], r[2])


def _verse_text(conn, vid, version, lang):
    """구절 본문 — **`verse_text` 단일 문**(§267차 ③). 직접 읽지 않는다."""
    try:
        import verse_text as _vt
        return (_vt.resolve(conn, vid, version, lang) or {}).get('text') or ''
    except Exception:                                     # noqa: BLE001
        return ''


def _neighbors(conn, vid, span=2, version='KRV', lang='KO'):
    """앞뒤 절 — 차례는 `sort_order` 가 안다(§236차 · `verse_id` 는 정경 순서가 아니다)."""
    r = conn.execute("SELECT bcode, sort_order FROM bible_index WHERE verse_id=?",
                     (vid,)).fetchone()
    if not r:
        return ''
    rows = conn.execute(
        "SELECT verse_id, chapter, verse FROM bible_index "
        "WHERE bcode=? AND sort_order BETWEEN ? AND ? ORDER BY sort_order",
        (r[0], r[1] - span * 10, r[1] + span * 10)).fetchall()
    out = []
    for v, ch, vs in rows:
        mark = '▶ ' if v == vid else '  '
        out.append('%s%d:%d %s' % (mark, ch, vs, _verse_text(conn, v, version, lang)))
    return chr(10).join(out)


def _peri_title(conn, vid, lang='KO'):
    """그 절이 든 단락의 제목."""
    r = conn.execute(
        "SELECT p.pericope_id FROM sys_pericope_asset p JOIN bible_index a "
        "  ON a.verse_id=p.start_vid JOIN bible_index z ON z.verse_id=p.end_vid "
        "JOIN bible_index t ON t.verse_id=? "
        "WHERE p.peri_type='BODY' AND p.record_status='LIVE' "
        "  AND t.sort_order BETWEEN a.sort_order AND z.sort_order LIMIT 1",
        (vid,)).fetchone()
    if not r:
        return ''
    t = conn.execute(
        "SELECT contents FROM sys_text_asset WHERE text_type='PERI_TITLE' "
        "AND clicked_id=? AND UPPER(lang_code)=? AND record_status='LIVE' LIMIT 1",
        (r[0], lang.upper())).fetchone()
    return (t[0] if t else '') or ''


def book_variant_for(lang, base='EN'):
    """도서 본문을 **그 언어로 새로 낼 때** 담기는 변형(1.txt 1번 8)).

    ★ 영어로 받은 글은 「영어 번역」이 아니라 **현대 영어(MODERN_EN)** 다 —
      원문이 영어인 책을 영어로 옮긴다는 것은 옛말투를 오늘 말로 고치는
      일이고, 그 칸이 `MODERN_EN` 이다(`--modern` 도구와 같은 칸). 그 밖의
      언어는 `TRANSLATED`.
    """
    return 'MODERN_EN' if (lang or '').upper() == (base or 'EN').upper() == 'EN' \
        else 'TRANSLATED'


def _asset_text(conn, kind, slot_id, lang, variant_pref=None):
    """그 자리의 그 언어 글 — 옮길 원본·다듬을 글.

    `variant_pref` = 도서에서 **어느 변형을 먼저 집나**(`MODERN_EN`·`ORIGINAL`).
    ★ 1.txt 1번 8) — 다른 언어로 옮길 원본은 **현대 영어가 있으면 그것**이다.
      17세기 영어를 그대로 주면 옮기는 쪽이 원문 해독부터 해야 한다
      (`db_pack_taste.SRC_VARIANTS` 와 같은 판단). 안 주면 옛 동작(원문 먼저).
    """
    a = ASSET[kind]
    if a['store'] == 'LINK':
        return existing_links_text(conn, slot_id)
    if a['store'] == 'BUNDLE':
        # ★ 묶음을 다듬거나 옮길 때는 **칸을 모아 한 덩이로** 넘긴다 —
        #   그래야 칸 사이의 되풀이가 눈에 보인다.
        got = {}
        for p in BUNDLE_PARTS:
            # ⚠⚠ **연구자료 칸은 안 모은다** — `sys_ref_unit` 에 담기고,
            #   그 글을 옮기고 다듬는 일은 **자료집 글**(`REF_UNIT` · 범위
            #   「연구 자료」) 경로가 따로 맡는다. 두 경로가 같은 글을
            #   옮기면 반드시 갈린다 — 묶음에서는 **새로 쓰기**만 한다.
            if not p[2]:
                continue
            q = ("SELECT contents FROM sys_text_asset WHERE clicked_id=? "
                 "AND text_type=? AND UPPER(lang_code)=? AND record_status='LIVE'")
            ar = [slot_id, p[2], lang.upper()]
            if p[3]:
                q += " AND text_variant=?"
                ar.append(p[3])
            r = conn.execute(q + " LIMIT 1", ar).fetchone()
            if r and (r[0] or '').strip():
                got[p[0]] = r[0]
        return bundle_join(got) if got else ''
    if a['store'] == 'TEXT':
        q = ("SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type=? "
             "AND UPPER(lang_code)=? AND record_status='LIVE'")
        args = [slot_id, a['text_type'], lang.upper()]
        if a['variant']:
            q += " AND text_variant=?"
            args.append(a['variant'])
        r = conn.execute(q + " LIMIT 1", args).fetchone()
    elif a['store'] == 'BOOK':
        pref = (variant_pref or 'ORIGINAL').upper()
        r = conn.execute(
            "SELECT body_text FROM sys_book_unit_text WHERE unit_id=? "
            "AND UPPER(lang_code)=? AND record_status='LIVE' "
            "ORDER BY CASE WHEN UPPER(text_variant)=? THEN 0"
            "              WHEN UPPER(text_variant)='ORIGINAL' THEN 1 ELSE 2 END "
            "LIMIT 1", (slot_id, lang.upper(), pref)).fetchone()
        # ★★★ **출처 줄은 재료에서 뗀다** (1.txt 16-2 ⓐ) — 그것은 저작권
        #   고지이지 저자의 글이 아니다. 넘기면 AI 가 매번 다르게 옮긴다
        #   (실측 맥라렌 14건에서 저자 이름 셋 · 제목 셋 · 빠진 것 4건).
        #   적재할 때 `db_book_attrib` 가 한 꼴로 붙인다.
        if r and r[0]:
            try:
                import db_book_attrib as _BA
                r = (_BA.strip_attrib(r[0]),)
            except Exception:
                pass
    elif a['store'] == 'BTASTE':
        # ★ 원문 언어를 물으면 **본문에서 잘라** 주고, 그 밖이면 담아 둔
        #   조각 번역을 준다(`db_pack_taste` 한 문이 둘 다 안다).
        import db_pack_taste as _T
        return _T.taste_text(conn, slot_id, lang)
    elif a['store'] == 'BOOKA':
        # ⚠ 그 언어 행이 없으면 **빈 글** — 폴백하지 않는다.
        #   폴백하면 KO 를 옮겼다고 적고 실제로는 EN 을 옮긴다.
        r = conn.execute(
            "SELECT description FROM sys_book_asset_text WHERE book_id=? "
            "AND UPPER(lang_code)=? AND COALESCE(record_status,'LIVE')='LIVE' "
            "LIMIT 1", (slot_id, lang.upper())).fetchone()
    elif a['store'] == 'COMM':
        r = conn.execute(
            "SELECT body_text FROM sys_commentary_text WHERE entry_id=? "
            "AND UPPER(lang_code)=? AND record_status='LIVE' LIMIT 1",
            (slot_id, lang.upper())).fetchone()
    else:
        r = conn.execute(
            "SELECT body_text FROM sys_ref_text WHERE ref_unit_id=? "
            "AND UPPER(lang_code)=? AND record_status='LIVE' LIMIT 1",
            (slot_id, lang.upper())).fetchone()
        if not (r and (r[0] or '').strip()):
            # ★ 문답 — 그 자료집의 **원문 언어**를 물었을 때만 칸을
            #   본다. 아무 언어에나 내주면 EN 을 KO 인 척 옮긴다.
            r = conn.execute(
                "SELECT TRIM(COALESCE(u.unit_question,'') || CHAR(10)"
                "       || CHAR(10) || COALESCE(u.unit_answer,'')) "
                "  FROM sys_ref_unit u JOIN sys_ref_source s"
                "    ON s.ref_src_id = u.ref_src_id "
                " WHERE u.ref_unit_id=?"
                "   AND UPPER(COALESCE(s.lang_code,'EN'))=?",
                (slot_id, lang.upper())).fetchone()
    return (r[0] if r else '') or ''


#: ★★★ 연결 갈래 열둘 — CLAUDE.md §28-2 가 단일 소스. **정의 · 가르는 잣대 · 예**
#:   (2026-09-29 297차 · 사용자 「연결유형코드에 대한 설명 프롬프트를 보강하라」).
#:   296차 시험에서 갈래 일치가 27%였다 — 이름과 한 줄 정의만 주면 AI 가 PRG·PAR·SYN 으로
#:   몰린다. **가르는 잣대**(무엇과 무엇을 어떻게 가르나)가 있어야 한다.
REL_CODES = [
    ('PRG', '점진적 발전',
     '같은 주제·모티프가 뒤 본문에서 한 걸음 자란다.',
     '앞 본문 없이는 뒤 본문의 뜻이 얕아지고, 뒤 본문이 앞 본문보다 더 넓거나 깊다.',
     '창 1:3 빛 → 요 8:12 「나는 세상의 빛이니」'),
    ('DEP', '깊어짐',
     '뒤 본문이 앞 본문의 뜻을 풀어 설명하거나 해석한다.',
     '뒤 본문이 앞 본문을 **해설**한다 — 새 주제가 아니라 같은 말의 속뜻.',
     '출 20:13 살인하지 말라 → 마 5:21~22 마음의 노여움까지'),
    ('INC', '그리스도 성취',
     '앞 본문의 인물·사건·약속이 그리스도의 인격·사역에서 몸을 입는다.',
     '뒤 본문이 **그리스도 자신**이다. 모형-실체 짝이 뚜렷하면 TYP, 예언문이면 FUL.',
     '시 22:1 → 마 27:46 십자가의 외침'),
    ('REV', '역전',
     '앞 본문의 죄·저주·죽음이 뒤 본문에서 뒤집힌다.',
     '방향이 **반대**다 — 잃은 것이 회복되거나 저주가 복이 된다.',
     '창 3:19 흙으로 돌아감 → 고전 15:22 그리스도 안에서 삶'),
    ('TYP', '예표',
     '앞 본문의 사물·제도·인물이 뒤 본문의 실체를 미리 그린다.',
     '앞이 **그림**(모형), 뒤가 **실체**(본형). 앞 본문이 말로 한 예언이면 TYP 이 아니라 FUL.',
     '출 12:5 흠 없는 어린 양 → 요 1:29 하나님의 어린 양'),
    ('FUL', '예언 성취',
     '앞 본문이 말로 예언하고 뒤 본문에서 그대로 이루어진다.',
     '앞 본문이 **예언문**(「…하리라」)이다. 사물·제도면 TYP.',
     '사 7:14 처녀가 잉태 → 마 1:23'),
    ('ALL', '암시·반향',
     '뒤 본문이 앞 본문의 낱말·장면을 살짝 되울린다 — 인용은 아니다.',
     '낱말 한둘이 **겹친다**. 문장째 겹치면 REF, 낱말은 안 겹치고 뜻만 겹치면 SYN.',
     '시 19:1 하늘이 영광을 선포 ↔ 창 1:1'),
    ('PAR', '평행',
     '같은 사건·형식·구조가 다른 자리에서 되풀이된다.',
     '**구조가 닮았다** — 후렴·병행 기사·되풀이되는 장면.',
     '창 1:4 「보시기에 좋았더라」 ↔ 창 1:10 (일곱 번 후렴)'),
    ('REF', '명시적 인용·회상',
     '뒤 본문이 앞 본문을 직접 인용하거나 「…하신 것같이」로 되짚는다.',
     '뒤 본문 **안에 앞 본문의 문장**이 있다. 낱말만 겹치면 ALL.',
     '신 26:5~8 출애굽 회상 ← 출 12'),
    ('SUP', '뒷받침',
     '앞 본문의 주장·사실을 다른 자리의 증언이 받쳐 준다.',
     '같은 **사실**을 다른 증인이 말한다(같은 사상이 아니라 같은 사실).',
     '창 1:1 → 히 11:3 믿음으로 세계가 말씀으로 지어진 줄 안다'),
    ('SYN', '같은 사상',
     '다른 말로 같은 사상을 말한다.',
     '**낱말은 안 겹치고 뜻이 겹친다**. 낱말이 겹치면 ALL.',
     '창 1:1 ↔ 사 45:18 땅을 지으신 이가 헛되이 창조하지 않으셨다'),
    ('COV', '언약',
     '언약의 맺음·확인·갱신·성취로 이어진다.',
     '두 본문 가운데 하나 이상이 **언약** 장면이다.',
     '창 17:7 아브라함 언약 ↔ 갈 3:16 그 자손 곧 그리스도'),
]
REL_CODE_SET = tuple(r[0] for r in REL_CODES)
LINK_MAX = 8


#: ★ 317차-20 — 갈래마다 **검수한 고정 예**(둘째 예). 자동으로 뽑던 우리 연결 짝은 창세기 1장에 몰리고
#:   잣대와 어긋나는 짝이 섞여(「예언 성취」 예가 창 1:2 ↔ 행 2:4) 규칙보다 예가 세게 먹었다.
REL_EX2 = {
    'PRG': '겔 47:1 성전에서 흐르는 물 → 계 22:1 생명수의 강',
    'DEP': '레 19:18 이웃 사랑 → 롬 13:10 사랑은 율법의 완성',
    'INC': '시 23:1 여호와는 나의 목자 → 요 10:11 나는 선한 목자라',
    'REV': '창 11:9 바벨의 흩어진 언어 → 행 2:6 각 사람이 자기 방언으로 들음',
    'TYP': '레 16:15 속죄일 염소의 피 → 히 9:12 자기 피로 영원한 속죄',
    'FUL': '미 5:2 베들레헴에서 다스릴 자 → 마 2:6',
    'ALL': '창 2:9 생명나무 → 계 22:2 생명나무 실과',
    'PAR': '왕하 18:13 산헤립의 침공 ↔ 사 36:1 (같은 사건의 병행 기사)',
    'REF': '창 15:6 → 롬 4:3 「아브라함이 하나님을 믿으매 이것이 의로 여기신 바 되었느니라」',
    'SUP': '출 14:22 홍해를 마른 땅으로 → 고전 10:1 우리 조상들이 바다 가운데로 지나고',
    'SYN': '시 51:10 정한 마음을 창조하시고 ↔ 겔 36:26 새 마음을 주고',
    'COV': '창 9:9 노아 언약 → 사 54:9 노아의 홍수가 다시 땅에 범람치 못하게 하리라 맹세한 것같이',
}

#: ★ 317차-20 — **판정 차례**(열두 갈래 모두) — 위에서부터 처음 「예」가 나오는 갈래를 붙인다.
#:   뜻의 갈래(예언·모형·그리스도·언약·역전)를 먼저 묻고 꼴의 갈래(인용·평행·겹침)는 뒤에 묻는다 —
#:   마 1:23 은 사 7:14 를 인용하지만 갈래는 FUL 이다.
REL_ORDER = (
    ('FUL', '앞 본문이 「…하리라」는 예언문이고 뒤 본문에서 이루어지는가'),
    ('TYP', '앞이 사물·제도·인물의 모형이고 뒤가 그 실체인가'),
    ('INC', '뒤 본문이 그리스도 자신(인격·사역)인가'),
    ('COV', '두 본문 가운데 하나 이상이 언약의 맺음·확인·갱신인가'),
    ('REV', '앞의 죄·저주·죽음이 뒤에서 뒤집히는가'),
    ('REF', '뒤 본문 안에 앞 본문의 문장이 있거나 「…하신 것같이」로 되짚는가'),
    ('PAR', '같은 사건·구조·후렴이 되풀이되는가'),
    ('DEP', '뒤가 앞의 뜻을 풀어 해설하는가(새 주제가 아니다)'),
    ('PRG', '같은 주제가 뒤에서 넓어지거나 깊어지는가'),
    ('SUP', '같은 사실을 다른 증인이 말하는가'),
    ('ALL', '낱말 한둘이 겹치는가'),
    ('SYN', '낱말은 안 겹치고 뜻만 겹치는가'),
)


def rel_code_guide(conn=None, n_ex=0):
    """열두 갈래를 **정의 · 잣대 · 예**로 — 프롬프트 재료 한 덩이.

    우리 자료(사람이 이은 연결)의 실제 짝을 갈래마다 `n_ex` 개 덧붙인다 — 정의만
    주면 AI 가 제 뜻으로 읽는다(296차 실측 갈래 일치 27%).
    """
    lines = ['판정 차례 — 위에서부터 물어 처음 「예」가 나오는 갈래 하나를 붙인다:']
    for i, (code, q) in enumerate(REL_ORDER, 1):
        lines.append('  %d. %s → %s' % (i, q, code))
    lines.append('')
    for code, name, what, rule, ex in REL_CODES:
        lines.append('%s = %s — %s' % (code, name, what))
        lines.append('   잣대: %s' % rule)
        exs = [ex] if ex else []
        if REL_EX2.get(code):
            exs.append(REL_EX2[code])
        if conn is not None and n_ex:
            try:
                for a, b in conn.execute(
                        "SELECT clicked_id, target_id FROM sys_link_asset"
                        " WHERE link_type='VERS_VERS' AND record_status='LIVE'"
                        "   AND rel_code=? AND COALESCE(source,'') NOT LIKE 'AILINK:%'"
                        " ORDER BY importance DESC, sys_link_id LIMIT ?", (code, int(n_ex))):
                    exs.append('%s ↔ %s' % (_ref(conn, a), _ref(conn, b)))
            except Exception:                             # noqa: BLE001
                pass
        if exs:
            lines.append('   예: ' + ' / '.join(exs))
    return NL_.join(lines)


def existing_links_text(conn, vid):
    """그 절에 **지금 이어진 구절** — 「약명 · 갈래 · 사람/AI」 줄들(없으면 '')."""
    out = []
    for a, b, rel, src in conn.execute(
            "SELECT clicked_id, target_id, rel_code, COALESCE(source,'') FROM sys_link_asset"
            " WHERE link_type='VERS_VERS' AND record_status='LIVE'"
            "   AND (clicked_id=? OR target_id=?) ORDER BY sys_link_id", (vid, vid)):
        o = b if a == vid else a
        out.append('%s · %s · %s' % (_ref(conn, o), rel or '?',
                                     'AI' if src.startswith('AILINK:') else '사람'))
    return NL_.join(out)


def link_material(conn, vid):
    """연결기 재료 — 이미 이어진 구절 · 갈래 안내."""
    out = {}
    ex = existing_links_text(conn, vid)
    out['이미 이어진 구절 (다시 내지 않는다)'] = ex or '(없음)'
    out['연결 갈래 — 정의 · 잣대 · 예'] = rel_code_guide(conn)
    try:
        out['절 표기 — 개역한글 약명'] = ' '.join(
            r[0] for r in conn.execute("SELECT short_name FROM book_names WHERE lang_code='KO'"
                                       " ORDER BY book_code") if r[0])
    except Exception:                                     # noqa: BLE001
        pass
    return out




#: ★★★ 317차-5 — **연결 점검**(구절연결기 · 다듬기). docs/1.txt 4 구절연결기 2)(2)
#:   「부적절하게 연결되어 있다면 AI 가 그런 연결을 해제하도록 추천하는 방식」.
#:   ⚠ 연결기 신규 층(「3~8개 새로 잇는다」)과 할 일이 정반대라 **그 층을 쓰지 않는다** —
#:   여기 본보기 위에 `VERS_LINK × 다듬기` 층(프롬프트 탭 자산×업무)만 얹는다.
LINK_REVIEW = {
    'role': '이미 이어진 구절 연결이 맞는지 점검하는 사람.',
    'task': '[이어진 구절]의 줄마다 판정을 하나 붙인다 — 유지 · 해제 · 바꿈(갈래). '
            '새 구절을 보태지 않는다.',
    'must': '두 본문에 실제로 있는 낱말·사건·약속이 이어 주면 **유지**.\n'
            '두 본문 어디에도 잇는 근거가 없으면 **해제** — 억지 비유·우연히 같은 낱말 하나뿐인 것.\n'
            '잇는 근거는 있는데 갈래가 [연결 갈래] 표와 안 맞으면 **바꿈:갈래코드**.\n'
            '줄마다 까닭을 합니다체 한 문장으로 — 해제·바꿈은 무엇이 안 맞는지를 든다.\n'
            '[이어진 구절]의 줄을 하나도 빼지 않고 같은 차례로 판정한다.',
    'never': '새 구절 보태기\n판정 둘 붙이기\n애매하다고 해제하기 — 근거가 조금이라도 있으면 유지',
    'output': '줄마다 「약명 장:절 · 지금 갈래 · 판정 · 까닭」 — 판정은 유지 / 해제 / 바꿈:코드.\n'
              '예)\n요 1:3 · PRG · 유지 · 말씀으로 지으신 창조가 두 본문에 함께 있습니다.\n'
              '몬 1:13 · ILL · 해제 · 궁창과 감옥을 잇는 낱말이나 사건이 두 본문에 없습니다.\n'
              '시 33:6 · PRG · 바꿈:SYN · 같은 사상을 다른 말로 말할 뿐 흐름이 자라지는 않습니다.',
}
LINK_VERDICTS = ('유지', '해제', '바꿈')


def is_link_review(kind, task):
    """이어진 연결을 **점검**하는 업무인가 — 해제분석(VERS_UNLINK) · 연결기 다듬기(옛 길)."""
    return kind == 'VERS_UNLINK' or (ASSET.get(kind, {}).get('store') == 'LINK'
                                     and str(task).upper() == 'EDIT')


#: 블랙리스트 항목 — 「값이 매우 낮은 것」(317차-20 사용자 「점수 자체보다 항목별 값」)
#   ⚠ 같은 장이라도 **PAR(평행·후렴)은 정당한 쓰임**이라 안 넣는다(창 1장 후렴 실측 76개).
BLACK_ITEMS = ('같은 장 이웃', '같은 장', '옛 갈래', '설명문 없음', '설명문 짧음')
DESC_SHORT = 10


def link_values(conn, lid):
    """연결 하나의 **항목별 값** — 점수로 합치지 않는다(사용자 확정).

    `{'거리', '갈래', '출처', '설명문', '구속사', '낮음': [블랙리스트 항목]}`.
    """
    r = conn.execute(
        "SELECT a.bcode, a.chapter, a.verse, b.bcode, b.chapter, b.verse, l.rel_code,"
        " COALESCE(l.source,''), COALESCE(l.chain_code,''),"
        " (SELECT MAX(LENGTH(TRIM(t.contents))) FROM sys_text_asset t WHERE t.clicked_id=l.sys_link_id"
        "   AND t.text_type='VERS_VERS_DESC' AND t.record_status='LIVE')"
        " FROM sys_link_asset l JOIN bible_index a ON a.verse_id=l.clicked_id"
        " JOIN bible_index b ON b.verse_id=l.target_id WHERE l.sys_link_id=?", (lid,)).fetchone()
    if not r:
        return None
    ab, ac, av, bb, bc, bv, rel, src, chain, dl = r
    dl = dl or 0
    if ab == bb and ac == bc:
        dist = '같은 장 %d절 차이' % abs(av - bv)
    elif ab == bb:
        dist = '같은 책 다른 장'
    elif (ab <= 39) != (bb <= 39):
        dist = '구약↔신약'
    else:
        dist = '다른 책'
    low = []
    if ab == bb and ac == bc and (rel or '') != 'PAR':
        low.append('같은 장 이웃' if abs(av - bv) <= 2 else '같은 장')
    if (rel or '') not in REL_CODE_SET:
        low.append('옛 갈래')
    if dl == 0:
        low.append('설명문 없음')
    elif dl < DESC_SHORT:
        low.append('설명문 짧음')
    return {'거리': dist, '갈래': rel or '?', '출처': 'AI' if src.startswith('AILINK:') else '사람',
            '설명문': '%d자' % dl, '구속사': chain or '없음', '낮음': low}


def link_blacklist(conn):
    """블랙리스트 — `{절: [(link_id, [항목])]}` (양쪽 절 모두에 적는다 · 한 조회).

    점수를 계산하지 않는다 — 항목별 값이 **매우 낮은** 연결만 모은다(`BLACK_ITEMS`).
    """
    out = {}
    q = ("SELECT l.sys_link_id, l.clicked_id, l.target_id, a.bcode, a.chapter, a.verse,"
         " b.bcode, b.chapter, b.verse, COALESCE(l.rel_code,''),"
         " (SELECT MAX(LENGTH(TRIM(t.contents))) FROM sys_text_asset t WHERE t.clicked_id=l.sys_link_id"
         "   AND t.text_type='VERS_VERS_DESC' AND t.record_status='LIVE')"
         " FROM sys_link_asset l JOIN bible_index a ON a.verse_id=l.clicked_id"
         " JOIN bible_index b ON b.verse_id=l.target_id"
         " WHERE l.link_type='VERS_VERS' AND l.record_status='LIVE'")
    for lid, ca, ta, ab, ac, av, bb, bc, bv, rel, dl in conn.execute(q):
        low = []
        if ab == bb and ac == bc and rel != 'PAR':
            low.append('같은 장 이웃' if abs(av - bv) <= 2 else '같은 장')
        if rel not in REL_CODE_SET:
            low.append('옛 갈래')
        if not dl:
            low.append('설명문 없음')
        elif dl < DESC_SHORT:
            low.append('설명문 짧음')
        if low:
            out.setdefault(ca, []).append((lid, low))
            out.setdefault(ta, []).append((lid, low))
    return out


def review_links(conn, vid):
    """점검할 연결 — `[(link_id, 상대 절, 갈래, 출처)]`(사람·AI 모두 · LIVE)."""
    out = []
    for lid, a, b, rel, src in conn.execute(
            "SELECT sys_link_id, clicked_id, target_id, rel_code, COALESCE(source,'') FROM sys_link_asset"
            " WHERE link_type='VERS_VERS' AND record_status='LIVE'"
            "   AND (clicked_id=? OR target_id=?) ORDER BY sys_link_id", (vid, vid)):
        out.append((int(lid), int(b if a == vid else a), rel or '', src))
    return out


def link_review_material(conn, vid, links=None):
    """연결 점검 재료 — 절 본문 + **이어진 구절마다 그 절 본문** + 갈래 표.

    `links` = `[(상대 절, 갈래)]` 를 주면 그것을 쓴다(시험이 심은 연결을 섞을 때).
    """
    out = {'구절': _ref(conn, vid)}
    for ver, lg, nm in REF_VERSIONS:
        t = _verse_text(conn, vid, ver, lg)
        if t:
            out['본문 (%s)' % nm] = t
    links_from_db = links is None
    if links is None:
        links = [(o, rel) for _l, o, rel, _s in review_links(conn, vid)]
    _vals = {}
    if links_from_db:
        for lid, o, rel, src in review_links(conn, vid):
            _vals[(o, rel)] = link_values(conn, lid)
    rows = []
    for o, rel in links:
        v = _vals.get((o, rel))
        tail = ''
        if v:
            tail = '  ‹%s›' % ' · '.join('%s %s' % (k, v[k]) for k in ('거리', '출처', '설명문', '구속사'))
            if v['낮음']:
                tail += '  ⚠ ' + ' · '.join(v['낮음'])
        rows.append('%s · %s · %s%s' % (_ref(conn, o), rel or '?', _verse_text(conn, o, 'KRV', 'KO'), tail))
    out['이어진 구절 — 약명 · 지금 갈래 · 그 절 본문 ‹항목별 값›'] = NL_.join(rows) or '(없음)'
    out['연결 갈래 — 정의 · 잣대 · 예'] = rel_code_guide(conn)
    return out


def link_review_parse(conn, text, book_map=None):
    """점검 글 → `[(ref, 상대 절|None, 지금 갈래, 판정, 새 갈래, 까닭)]`.

    판정 = 유지 / 해제 / 바꿈. 못 읽은 줄은 판정 ''(게이트가 센다).
    """
    import re as _re
    import scripture_ref_kr as SR
    bm = book_map if book_map is not None else SR.book_map_ko(conn)
    pat = _re.compile(r'^\s*(?:[-*\d]+[.)]?\s*)?'
                      r'([가-힣]{1,3}\s?\d+\s*:\s*\d+)'
                      r'\s*[·|,;]\s*([A-Za-z?]{1,3})\s*[·|,;]\s*'
                      r'(유지|해제|바꿈)\s*(?:[:]\s*([A-Za-z]{3}))?\s*[·|,;]?\s*(.*?)\s*$')
    out = []
    for raw in (text or '').splitlines():
        if not raw.strip():
            continue
        m = pat.match(raw.replace(chr(0xFF1A), ':'))
        if not m:
            out.append(('', None, '', '', '', raw.strip()))
            continue
        ref = m.group(1)
        st, _e = SR.resolve(conn, ref, bm)
        out.append((ref, st, (m.group(2) or '').upper(), m.group(3),
                    (m.group(4) or '').upper(), (m.group(5) or '').strip()))
    return out


def link_lines_parse(conn, text, book_map=None):
    """받은 글 → `[(ref, target_vid|None, rel, why, raw)]`.

    받는 꼴 둘 — 줄 「약명 장:절 · 갈래 · 왜」(구분자 · | , - 아무거나) 와 JSON 배열
    `[{"ref","rel","why"}]`. 줄 앞의 번호·기호는 걷는다. 못 읽은 줄은 `ref=''` 로 남긴다
    (조용히 버리면 게이트가 못 잰다).
    """
    import re as _re
    import json as _json
    import scripture_ref_kr as SR
    bm = book_map if book_map is not None else SR.book_map_ko(conn)
    t = (text or '').strip()
    out = []
    mj = _re.search(r'\[\s*\{.*\}\s*\]', t, _re.S)      # JSON 배열이 어디에 있든
    if mj:
        m = mj
        if m:
            try:
                arr = _json.loads(m.group(0))
                for it in arr if isinstance(arr, list) else []:
                    if isinstance(it, dict):
                        ref = str(it.get('ref', '')).strip().replace('：', ':')
                        rel = str(it.get('rel', '')).strip().upper()
                        why = str(it.get('why', '')).strip()
                        st, _e = SR.resolve(conn, ref, bm)
                        out.append((ref, st, rel, why, _json.dumps(it, ensure_ascii=False)))
                return out
            except Exception:                             # noqa: BLE001
                pass
    pat = _re.compile(r'^\s*(?:[-*•·\d]+[.)]?\s*)?'
                      r'([가-힣]{1,3}\s?\d+\s*:\s*\d+(?:\s*[-~]\s*\d+)?)'
                      r'\s*[·|,;\-–—:]\s*([A-Za-z]{3})\s*[·|,;\-–—:]\s*(.+?)\s*$')
    for raw in t.splitlines():
        if not raw.strip():
            continue
        m = pat.match(raw)
        if not m:
            out.append(('', None, '', '', raw.strip()))
            continue
        ref = _re.sub(r'\s*:\s*', ':', m.group(1)).replace('~', '-')
        ref = _re.sub(r'\s*-\s*', '-', ref)
        st, _e = SR.resolve(conn, ref, bm)
        out.append((ref, st, m.group(2).upper(), m.group(3).strip(), raw.strip()))
    return out


def material(conn, kind, slot_id, task='NEW', base=None, lang=None, scope=''):
    """**그 자리를 쓰려면 무엇을 봐야 하나** — `{사람 말 열쇠: 글}`.

    `render_prompt(프롬프트, 이 값)` 에 그대로 넘긴다.

    ⚠ **번역·다듬기에는 배경을 안 싣는다** — 옮길 글이 거의 전부다. 배경을
      함께 보내면 토큰이 몇 배로 들고 **원문에 없는 것을 보태기 쉽다**
      (`booktrans.md` 「번역은 창작이 아니다」).
    """
    a = ASSET[kind]
    base = (base or base_lang(kind, scope, conn)).upper()
    lang = (lang or base).upper()
    if is_link_review(kind, task):
        return link_review_material(conn, slot_id)
    out = {}

    # ── 옮길 글 / 다듬을 글 ─────────────────────────────────────────
    if task in ('TRANS', 'EDIT'):
        src_lang = base if task == 'TRANS' else lang
        # ★ 도서 — 다른 언어로 옮길 때는 **현대 영어**를 먼저 집고, 영어를
        #   영어로(현대어화) 낼 때만 **원문**을 준다(1.txt 1번 8)).
        _pref = 'ORIGINAL' if (task == 'TRANS' and lang == src_lang) else 'MODERN_EN'
        txt = _asset_text(conn, kind, slot_id, src_lang, variant_pref=_pref)
        if not txt:
            return {'⚠': '%s 글이 없습니다 — 옮길 것이 없습니다.' % src_lang}
        out['옮길 글 (%s)' % src_lang if task == 'TRANS'
            else '지금 글 (%s)' % src_lang] = txt
        # ★ 317차-18 ⑦ — 자료집 글의 표는 **칸 번호 목록**으로 따로 보낸다(ref_doc)
        if task == 'TRANS' and a.get('store') == 'REF':
            try:
                import ref_doc as _RD
                if _RD.tokens(txt):
                    _tb = _RD.get_tables(conn, 'SYS', slot_id, src_lang)
                    if _tb:
                        out['표 칸 — 본문의 [[T1]] 같은 자리표는 글자 그대로 두고, 옮긴 글 맨 끝에 아래 '
                            '[[T1:CELLS]] 줄과 「번호) 옮긴 칸 글」을 같은 번호로 적는다(칸 안 줄바꿈은 <br>)'] = \
                            _RD.cells_block(_tb)
            except Exception:                             # noqa: BLE001
                pass
        if task == 'EDIT':
            other = _asset_text(conn, kind, slot_id, base) if base != lang else ''
            if other:
                out['원본 (%s)' % base] = other
        # ★ 2026-10-25 (docs/1.txt 7) 주석 번역 — **어느 장의 주석인가**를 재료에 적는다.
        #   그전에는 자리가 안 실려, 원문의 「(ver. 1)」을 AI 가 「(시 1:1)」로 옮겼다(시편 36편 주석 · 실측 54건).
        if task == 'TRANS' and a.get('store') == 'COMM':
            try:
                r = conn.execute('SELECT start_vid, chapter FROM sys_commentary_entry WHERE entry_id=?',
                                 (slot_id,)).fetchone()
                if r and r[0]:
                    head = _ref(conn, r[0]).rsplit(':', 1)[0]      # 「시 36」
                    out['자리'] = ('%s장 주석 — 원문의 (ver. N)·(v. N)·Verse N 은 이 장의 N절이다'
                                 '(예: %s:1) · 다른 장 번호를 붙이지 않는다' % (head, head))
                # ★ 2026-10-31 BARNES 빌립보서 시범 — 긴 글에서 문단이 합쳐졌다(25→14 · 15→5). 규칙은 이미 있었다 · 사실 한 줄을 준다
                _n = taste_paras(_first_src(out))
                if _n and _n > 1:
                    out['문단(줄) 수 — 이대로 지킨다'] = _n
            except Exception:                             # noqa: BLE001
                pass

    # ── 자리가 무엇인가 + 신규 작성의 배경 ─────────────────────────
    if a['slot'] == 'VERSE':
        out['구절'] = _ref(conn, slot_id)
        for ver, lg, nm in REF_VERSIONS:
            t = _verse_text(conn, slot_id, ver, lg)
            if t:
                out['본문 (%s)' % nm] = t
        if task == 'NEW':
            # ★★★ **성경 본문만 보낸다**(2026-09-23 사용자 지시) —
            #   「주석 등을 일체 제공하지 마라. **주석에 편향되는 심각한
            #   위험**이 있다」. 남의 해석을 함께 주면 AI 가 본문을 읽는 대신
            #   그 해석을 **요약한다**. 우리 주석은 18~19세기 것이라 그 시대의
            #   강조와 논쟁까지 배어 나온다.
            #   ⚠ **단락 제목도 함께 걷었다** — 우리가 쓴 글이지만 해석이
            #     들어 있고, 제목 한 줄이 글의 방향을 통째로 정해 버린다.
            out['앞뒤 절'] = _neighbors(conn, slot_id)
        if a['store'] == 'LINK':
            out.update(link_material(conn, slot_id))
            # ⚠⚠ 아래는 **되돌릴 자리**다(§0-5). 되살리려면 주석을 걷는다.
            #   import db_vers_prep as _pp
            #   cm = _pp.commentaries(conn, slot_id, COMM_SRCS, COMM_MAX)
            #   ⚠ `commentaries` 는 (소스, 글) 묶음의 목록이다 — `str()` 로
            #     찍으면 파이썬 튜플이 그대로 프롬프트에 실린다.
    elif a['slot'] == 'LINK':
        r = conn.execute(
            "SELECT clicked_id, target_id, rel_code, chain_code FROM sys_link_asset "
            "WHERE sys_link_id=?", (slot_id,)).fetchone()
        if r:
            out['앞 구절'] = '%s  %s' % (_ref(conn, r[0]),
                                      _verse_text(conn, r[0], 'KRV', 'KO'))
            out['뒤 구절'] = '%s  %s' % (_ref(conn, r[1]),
                                      _verse_text(conn, r[1], 'KRV', 'KO'))
            out['연결 갈래'] = r[2] or ''
            if r[3]:
                out['속한 흐름'] = r[3]
    elif a['slot'] == 'PERI':
        r = conn.execute("SELECT start_vid, end_vid FROM sys_pericope_asset "
                         "WHERE pericope_id=?", (slot_id,)).fetchone()
        if r:
            out['단락'] = '%s ~ %s' % (_ref(conn, r[0]), _ref(conn, r[1]))
            if task == 'NEW':
                vs = conn.execute(
                    "SELECT b.verse_id, b.chapter, b.verse FROM bible_index b "
                    "JOIN bible_index a ON a.verse_id=? JOIN bible_index z "
                    "  ON z.verse_id=? WHERE b.bcode=a.bcode "
                    "  AND b.sort_order BETWEEN a.sort_order AND z.sort_order "
                    "ORDER BY b.sort_order", (r[0], r[1])).fetchall()
                out['본문 (개역한글)'] = chr(10).join(
                    '%d:%d %s' % (ch, v, _verse_text(conn, vid, 'KRV', 'KO'))
                    for vid, ch, v in vs)
    elif a['slot'] == 'CHAP':
        bc, ch = divmod(int(slot_id), 1000)
        out['장'] = '%s %d장' % (book_abbr(conn).get(bc, bc), ch)
        if task == 'NEW':
            ts = conn.execute(
                "SELECT t.contents FROM sys_pericope_asset p "
                "JOIN bible_index a ON a.verse_id=p.start_vid "
                "JOIN sys_text_asset t ON t.clicked_id=p.pericope_id "
                "  AND t.text_type='PERI_TITLE' AND UPPER(t.lang_code)='KO' "
                "  AND t.record_status='LIVE' "
                "WHERE a.bcode=? AND a.chapter=? AND p.peri_type='BODY' "
                "  AND p.record_status='LIVE' ORDER BY p.sort_order",
                (bc, ch)).fetchall()
            if ts:
                out['이 장의 단락들'] = chr(10).join('· ' + (t[0] or '') for t in ts)
    elif a['slot'] == 'BTASTE':
        # ⚠ 재료는 **짧게** — 옮기는 일에 배경을 주면 새로 쓰기 시작한다.
        r = conn.execute(
            "SELECT a.title, a.author, COALESCE(u.unit_label,''),"
            "       COALESCE(u.body_ref,'') "
            "FROM sys_book_unit u JOIN sys_book_asset a ON a.book_id=u.book_id "
            "WHERE u.unit_id=?", (slot_id,)).fetchone()
        if r:
            out['책 이름'] = r[0] or ''
            out['지은이'] = r[1] or ''
            if r[2]:
                out['편 제목'] = r[2]
            if r[3]:
                out['제사 구절'] = r[3]
        # ★★★ **문단 수를 말한다**(2026-09-25 실측) — 게이트가 그것으로
        #   재는데 재료가 안 알려 주면 모델이 맞출 길이 없었다.
        #   ⚠ 세는 법은 게이트(`db_ai_run.taste_lines`)와 **똑같이**.
        _n = taste_paras(_first_src(out))
        if _n:
            out['문단(줄) 수 — 이대로 지킨다'] = _n
    elif a['slot'] == 'BOOKA':
        # ★★★ **신규 작성에는 책을 알려 줘야 한다**(2026-09-25 사용자 물음).
        #   그전에는 재료가 「써 넣을 언어」 한 줄이라 AI 가 책을 지어냈다.
        #   ⚠ **번역에는 안 싣는다** — 옮길 글이 이미 그 책을 말한다(위
        #     규칙 「번역에 배경을 주면 새로 쓰기 시작한다」).
        r = conn.execute(
            "SELECT book_code, title, author, pub_year, book_category,"
            "       COALESCE(body_chars,0) "
            "  FROM sys_book_asset WHERE book_id=?", (slot_id,)).fetchone()
        if r:
            out['책 이름'] = r[1] or ''
            out['지은이'] = r[2] or ''
            if r[3]:
                out['펴낸 해'] = str(r[3])
            if task == 'NEW':
                if r[4]:
                    out['갈래'] = r[4]
                us = conn.execute(
                    "SELECT unit_id, COALESCE(unit_label,'') "
                    "  FROM sys_book_unit WHERE book_id=? "
                    "   AND record_status='LIVE' ORDER BY sequence",
                    (slot_id,)).fetchall()
                out['편 수'] = '%d편' % len(us)
                if r[5]:
                    out['본문 분량'] = '%d자' % int(r[5])
                names = [u[1] for u in us if u[1]][:INTRO_UNITS]
                if names:
                    out['편 제목 (앞 %d개)' % len(names)] = NL_.join(
                        '· ' + n for n in names)
                if us:
                    t = conn.execute(
                        "SELECT body_text FROM sys_book_unit_text "
                        " WHERE unit_id=? AND record_status='LIVE' "
                        " ORDER BY CASE WHEN UPPER(text_variant)='ORIGINAL'"
                        "               THEN 0 ELSE 1 END LIMIT 1",
                        (us[0][0],)).fetchone()
                    if t and (t[0] or '').strip():
                        out['첫 편 첫머리'] = (t[0] or '').strip()[:INTRO_HEAD]
                # ★★★ **출처 블록은 도구가 짓는다 — AI 가 안 쓴다**
                try:
                    import db_book_desc as _BD
                    blk = _BD.src_block(conn, r[0], (lang or 'KO'))
                except Exception:                         # noqa: BLE001
                    blk = ''
                if blk:
                    out['그대로 붙일 출처 블록'] = blk
    elif a['slot'] == 'BOOK':
        out['책'] = book_abbr(conn).get(int(slot_id), str(slot_id))
    elif a['slot'] == 'ENTI':
        nm = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE clicked_id=? "
            "AND text_type='ENTITY_NAME' AND UPPER(lang_code)='KO' "
            "AND record_status='LIVE' LIMIT 1", (slot_id,)).fetchone()
        out['용어'] = (nm[0] if nm else '') or ''
        # ★ 317차-5 (docs/1.txt 4-3)(4)) — 용어 이름 작업은 **그 용어의 설명문**을 함께 받아야
        #   뜻을 안다(이름만 주면 동명이의를 못 가른다). 설명문 자체를 쓰는 작업은 제 글을 따로 받는다.
        if a['key'] == 'ENTITY_NAME':
            _ds = conn.execute(
                "SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type='ENTITY_DESC'"
                " AND record_status='LIVE' ORDER BY CASE WHEN UPPER(lang_code)='KO' THEN 0"
                " WHEN UPPER(lang_code)='EN' THEN 1 ELSE 2 END LIMIT 1", (slot_id,)).fetchone()
            if _ds and (_ds[0] or '').strip():
                out['용어 설명문(참고)'] = _ds[0].strip()[:1500]
        lm = conn.execute(
            "SELECT strong, translit, gloss FROM sys_entity_lemma "
            "WHERE entity_id=? LIMIT 5", (slot_id,)).fetchall()
        if lm:
            out['원어 앵커'] = ' · '.join(
                '%s(%s) %s' % (a1 or '', b1 or '', c1 or '') for a1, b1, c1 in lm)
        if task == 'NEW':
            ex = conn.execute(
                "SELECT verse_id FROM sys_entity_verse WHERE entity_id=? "
                "AND is_key=1 LIMIT 5", (slot_id,)).fetchall()
            if ex:
                out['대표 구절'] = chr(10).join(
                    '%s  %s' % (_ref(conn, v[0]),
                                _verse_text(conn, v[0], 'KRV', 'KO')) for v in ex)
    elif a['slot'] == 'UNIT':
        r = conn.execute("SELECT unit_label, body_ref FROM sys_book_unit "
                         "WHERE unit_id=?", (slot_id,)).fetchone()
        if r:
            out['편 제목'] = r[0] or ''
            if r[1]:
                out['제사 구절'] = r[1]
        # ★ 2026-10-11 — 본문 번역에도 **문단 수를 말한다**(맛보기와 같은 문법).
        #   실측 적재분 205편이 원본과 문단 수가 달랐다 — 게이트는 재는데 재료가 안 알려 줬다.
        if task == 'TRANS':
            _src = _first_src(out)
            _n = len([p for p in (_src or '').split(chr(10)) if p.strip()])
            if _n:
                out['문단(줄) 수 — 이대로 지킨다'] = _n
    elif a['slot'] == 'RUNIT' or a['slot'] in REF_SLOT_TYPE:
        r = conn.execute("SELECT unit_label, unit_question FROM sys_ref_unit "
                         "WHERE ref_unit_id=?", (slot_id,)).fetchone()
        if r and task == 'TRANS':
            # ★ 2026-10-25 (docs/1.txt 7 재검토) 번역에는 제목·물음을 따로 안 싣는다 — 물음은 옮길 글 첫 줄에 이미 있고,
            #   제목(「Q.1 — Lord's Day 1」)을 주면 AI 가 그 줄을 본문 맨 위에 옮겨 적었다(문답 적재분 221/236 이 문단 수 +1).
            #   대신 문단 수를 말한다(도서 번역과 같은 문법).
            _src = _first_src(out)
            _n = len([p for p in (_src or '').split(chr(10)) if p.strip()])
            if _n:
                out['문단(줄) 수 — 이대로 지킨다'] = _n
            # ★ 2026-10-26 증거 구절 표시도 사실 한 줄로 — 적재분 23편이 (a)… 를 밀거나 통째로 뺐다(게이트 trans_marks 와 같은 잣대).
            _mk = re.findall(r'\(([a-z])\)', _src or '')
            if len(_mk) >= 2:
                out['증거 구절 표시 — 이 차례 그대로, 같은 자리에'] = ' '.join('(%s)' % x for x in _mk)
        elif r:
            out['글 제목'] = r[0] or ''
            if r[1]:
                out['물음'] = r[1]
    # ★★★ **코드가 아니라 이름으로 말한다**(2026-09-25 실측) — `JA` 만
    #   주면 프롬프트 본문 언어(한국어)를 따라가 **엉뚱한 언어로 낸다**.
    #   오류가 안 나므로 통과처럼 보인다(§0-1).
    out['써 넣을 언어'] = lang_label(lang)
    # ★★★ 316차 사용자 지시 — 번역할 때 **구절약명 표시방법**.
    #   규칙을 늘리는 대신 **그 언어의 실제 약명 보기**를 준다(「써 넣을 언어」·
    #   「문단(줄) 수」와 같은 문법 — 사실이 규칙보다 강하다).
    if task in ('TRANS', 'EDIT'):
        _ab = abbr_sample(conn, lang)
        if _ab:
            out['구절약명 표기 — 이 꼴을 쓴다'] = _ab
    # ★ 317차-18 ⑩ — 관리자가 **인용·원어 꼴을 골랐으면** 그 언어 보기 한 줄(사실 한 줄).
    #   고른 적이 없으면 싣지 않는다 — 프롬프트의 옛 인용 줄 규칙(「역본 약명 장:절 본문」)이 그대로 산다.
    if kind in CITE_FMT_KINDS:
        try:
            import cite_format as _CF
            if _CF.chosen(conn, 'SYS'):
                out['성경 인용·원어 표기 — 이 꼴을 쓴다(프롬프트의 인용 줄 꼴보다 앞선다)'] = \
                    _CF.prompt_line(conn, 'SYS', lang or 'KO')
        except Exception:                                 # noqa: BLE001
            pass
    # ★★★ 317차-5 (docs/1.txt 4-7)(3)) — **책 제목 용어집**. 우리가 정한 그 언어 제목을
    #   재료로 준다 — 「날마다의 강론」 처럼 AI 가 제 말로 옮긴 제목이 끝줄·소개문과 갈렸다.
    #   정한 제목이 없으면 원제를 주고 「처음 한 번 원제를 괄호로」 를 시킨다(지어낸 이름이
    #   정본처럼 굳지 않게). 제목은 도서 관리 화면에서 언어마다 정한다.
    if kind in BOOK_TITLE_KINDS:
        _bid = book_id_of(conn, kind, slot_id)
        if _bid:
            _t = book_title(conn, _bid, lang)
            _o = book_title(conn, _bid, 'EN') or book_title(conn, _bid, 'KO')
            if _t:
                out['이 책의 제목 — 이 언어로는 이렇게 적는다'] = _t
            elif _o:
                out['이 책의 제목 — 원제'] = ('%s (이 언어로 정한 제목이 없다 — 옮기되 처음 한 번은 원제를 괄호로)'
                                              % _o)
    # ★ 2026-10-27 (docs/1.txt 15) **이름 용어집** — 옮길 글에 나오는 사람·땅 이름의 그 언어 표기(사실 한 줄).
    #   사전 101편 재검증에서 이름 흠이 가장 흔했다(여호수아 → 여호와 · 하만 → 하원 · 니느웨 → 니네베 · 들릴라 → 들라훌라).
    if task == 'TRANS':
        _src = _first_src(out)
        _g = name_glossary(conn, _src, base or 'EN', lang)
        if _g:
            out['이 글의 이름 — 이 언어로는 이렇게 적는다'] = _g
    return out


_NAME_MAP = {}


def name_glossary(conn, src, src_lang, lang, cap=40):
    """옮길 글에 나오는 용어 이름 → 그 언어 이름(「Sarah = 사라 · Abraham = 아브라함」). 없으면 ''.

    재료 = 주요용어 이름(ENTITY_NAME) — 두 언어 이름이 다 있는 것만 · 한 낱말 이름은 대문자로 시작하는 낱말로만 맞춘다
    (「Ur」 가 「your」 에 걸리지 않게) · 원문 언어와 대상 언어가 같으면 싣지 않는다.
    """
    src_lang = str(src_lang or 'EN').upper()
    lang = str(lang or '').upper()
    if not src or not lang or src_lang == lang:
        return ''
    key = (src_lang, lang)
    if key not in _NAME_MAP:
        m = {}
        try:
            for a, b in conn.execute(
                    "SELECT s.contents, t.contents FROM sys_text_asset s JOIN sys_text_asset t "
                    "ON t.clicked_id=s.clicked_id AND t.text_type='ENTITY_NAME' AND t.lang_code=? "
                    "WHERE s.text_type='ENTITY_NAME' AND s.lang_code=? "
                    "AND COALESCE(s.record_status,'LIVE')<>'HIDE' AND COALESCE(t.record_status,'LIVE')<>'HIDE'",
                    (lang, src_lang)):
                a, b = (a or '').strip(), (b or '').strip()
                if 2 <= len(a) <= 40 and b and a != b and '(' not in a:
                    m.setdefault(a, b)
        except Exception:                                 # noqa: BLE001
            pass
        _NAME_MAP[key] = m
    m = _NAME_MAP[key]
    hit = []
    for a, b in m.items():
        if a[:1].isupper() and re.search(r'(?<![A-Za-z])%s(?![A-Za-z])' % re.escape(a), src):
            hit.append((src.find(a), a, b))
    hit.sort()
    return ' · '.join('%s = %s' % (a, b) for _, a, b in hit[:cap])


#: 책 제목 용어집을 재료에 싣는 자산
BOOK_TITLE_KINDS = ('BOOK_UNIT', 'BOOK_INTRO', 'BOOK_TASTE')


def book_id_of(conn, kind, slot_id):
    """그 자리의 책 번호 — 편(UNIT·BTASTE)이면 편의 책, 소개문(BOOKA)이면 그 책."""
    sl = ASSET.get(kind, {}).get('slot')
    try:
        if sl == 'BOOKA':
            return int(slot_id)
        r = conn.execute("SELECT book_id FROM sys_book_unit WHERE unit_id=?", (int(slot_id),)).fetchone()
        return int(r[0]) if r else None
    except Exception:                                     # noqa: BLE001
        return None


def book_title(conn, book_id, lang):
    """우리가 정한 **그 언어의 책 제목** — 없으면 ''(지어내지 않는다)."""
    try:
        r = conn.execute("SELECT title FROM sys_book_asset_text WHERE book_id=? AND UPPER(lang_code)=?"
                         " AND COALESCE(record_status,'LIVE')='LIVE' AND TRIM(COALESCE(title,''))<>''",
                         (int(book_id), str(lang).upper())).fetchone()
        return (r[0] or '').strip() if r else ''
    except Exception:                                     # noqa: BLE001
        return ''


CITE_FMT_KINDS = ('REF_STUDY', 'VERS_BUNDLE')           # 우리가 쓰는 연구 글 — 인용 꼴을 선택할 자리


def abbr_sample(conn, lang, n=6):
    """그 언어의 **구절약명 보기** 한 줄 — 「창 1:1 · 신 15:4 · 마 7:7 …」.

    ★★★ 316차 — 번역할 때 구절 참조를 **그 언어 표기로** 옮기게 하는 가장 싼
      길이다. 규칙으로 적는 대신 **그 언어가 실제로 쓰는 글자**를 보여 준다.
    ★ 재료는 `book_names(언어).short_name` — **읽는 쪽과 같은 표**다
      (`scripture_ref.book_map`). 그래서 옮긴 글의 약명이 **그대로 다시 읽힌다**.
    ⚠ 그 언어 약명이 없으면 **빈 글**을 낸다 — 없는 꼴을 지어내지 않는다(§0-1).
    ⚠ 보기로 고른 책은 **자주 인용되는 것**(창·신·시·마·요·롬)이고 꼴만 보이면
      되므로 장·절 숫자는 아무 것이나 쓰지 않고 **실재하는 절**로 적는다.
    """
    #: (bcode, 장, 절) — 실재하는 절이라야 사람이 헷갈리지 않는다
    SHOW = ((1, 1, 1), (5, 15, 4), (19, 23, 1), (40, 7, 7), (43, 3, 16),
            (45, 8, 28))
    lg = (lang or 'KO').upper()
    try:
        nm = {bc: (sn or '').strip() for bc, sn in conn.execute(
            "SELECT book_code, short_name FROM book_names WHERE lang_code=?",
            (lg,)).fetchall()}
    except Exception:                                     # noqa: BLE001
        return ''
    out = []
    for bc, ch, vs in SHOW[:n]:
        a = nm.get(bc)
        if a:
            out.append('%s %d:%d' % (a, ch, vs))
    return ' · '.join(out)


def lang_label(code):
    """`JA` → `JA · 日本語`. 이름을 모르면 코드만(지어내지 않는다)."""
    code = (code or '').upper()
    try:
        import lang_config as _L
        nm = _L.lang_name(code)
    except Exception:                                     # noqa: BLE001
        nm = ''
    return ('%s · %s' % (code, nm)) if nm and nm != code else code


def _first_src(out):
    """재료에서 **옮길/다듬을 글**을 집는다 — 언어 꼬리표가 붙는다."""
    for k, v in out.items():
        if k.startswith('옮길 글') or k.startswith('지금 글'):
            return v
    return ''


def taste_paras(src):
    """맛보기 조각의 **문단(줄) 수** — 표식 앞까지, 빈 줄은 안 센다."""
    try:
        import db_pack_taste as _T
        mark = _T.TASTE_MARK
    except Exception:                                     # noqa: BLE001
        mark = '\u27e8맛보기 여기까지\u27e9'
    body = str(src or '').split(mark)[0]
    return len([p for p in body.split(chr(10)) if p.strip()])


def current_text(conn, kind, slot_id, lang):
    """그 자리에 **지금 들어 있는 글** — 없으면 빈 글.

    ★ 다시 쓰기·다시 번역에서 **옛 글과 견주는** 자리가 쓴다(검수 화면).
    ⚠ 자산마다 저장 표가 다르므로 **읽는 문을 화면이 새로 짜지 않는다** —
      두 벌이 되면 「검수 칸에 보이는 글과 실제로 덮이는 글이 다르다」가 난다.
    """
    try:
        # ★ 영어 자리에서 덮이는 것은 **현대 영어** 칸이다(원문은 안 덮는다)
        return _asset_text(conn, kind, slot_id, (lang or '').upper(),
                           variant_pref='MODERN_EN') or ''
    except Exception:                                     # noqa: BLE001
        return ''


#: 묶음 작업이 채우는 **자산 열쇠** — `(칸 열쇠: 자산)`.
#  ⚠ 담기는 곳이 `TEXT` 인 칸만이다(연구자료는 자리 번호 공간이 다르다).
def _bundle_fills():
    out = {}
    for row in BUNDLE_PARTS:
        key, _nm, _tt, _va, _req, _q = row[:6]
        ak = row[6] if len(row) > 6 else None
        store = row[7] if len(row) > 7 else None
        if ak and store == 'TEXT':
            out[key] = ak
    return out


def _mark_ai(lang, ai_langs):
    """`KO` → `KO(AI)` — 그 언어를 **마지막에 채운 것이 AI** 면 적는다."""
    return ('%s(AI)' % lang) if lang in (ai_langs or ()) else lang


def ai_loaded(conn, kind):
    """그 자산의 자리마다 **AI 가 담은 언어** — `{자리번호: {언어}}`.

    ★★★ 사용자 확정(2026-09-25) — 「**사람이 쓴 이후 AI 가 수정한 것도 AI 가
      적재한 것으로 인정한다**」. 그래서 묻는 것은 **마지막에 그 자리를 채운
      것이 AI 인가**이고, `state='LOADED'` 한 줄이 그 답이다.
    ⚠⚠ **묶음 작업이 설명문 자리를 채운다** — 자산 열쇠만 보면 그 자리를
      「사람 글」로 잘못 적는다. 묶음이 실제로 쓴 칸(`parts`)까지 따라간다.
    ⚠ 자리 번호 공간은 자산마다 다르다 — **그 자산을 채울 수 있는 작업만**
      본다(아무 작업이나 번호로 맞추면 엉뚱한 글을 AI 로 적는다).
    """
    fills = _bundle_fills()
    out = {}
    try:
        rows = conn.execute(
            "SELECT i.slot_id, UPPER(COALESCE(j.lang,'')), j.asset_kind,"
            "       COALESCE(j.parts,'') "
            "  FROM sys_ai_item i JOIN sys_ai_job j ON j.job_id=i.job_id "
            " WHERE i.state='LOADED'").fetchall()
    except Exception:                                     # noqa: BLE001
        return out
    for sid, lg, ak, parts in rows:
        if not lg:
            continue
        if ak != kind:
            if ak != 'VERS_BUNDLE':
                continue
            want = [k for k, v in fills.items() if v == kind]
            if not want:
                continue
            if parts:                    # 칸을 골라 보낸 작업은 그 칸만 채웠다
                got = set(x.strip() for x in parts.split(',') if x.strip())
                if not (got & set(want)):
                    continue
        out.setdefault(int(sid), set()).add(lg)
    return out


def base_options(conn, kind, scope=''):
    """**번역의 기준으로 삼을 수 있는 언어** — 실제로 글이 있는 것만.

    ★★★ 사용자 지시 — 「이미 KO/EN 등이 저장되어 있다면 **번역의 기준 자료를
      선택**해야 할 것 같다」. 실측 절 설명문은 KO 13,453 · EN 13,453 이라
      **둘 다 기준이 될 수 있다.**
    ⚠ 차례는 **원본 언어가 먼저**다 — 원본에서 옮기는 것이 옳고, 번역본을
      다시 옮기면(중역) 뜻이 두 번 흔들린다.
    """
    st = status(conn, kind, scope)
    base = base_lang(kind, scope, conn)
    got = [(lg, d) for lg, (d, _t) in st.items() if d > 0]
    got.sort(key=lambda x: (x[0] != base, -x[1]))
    return got


def status(conn, kind, scope='', langs=None):
    """**언어별 현황** — `{언어: (쓴 자리, 전체 자리)}`.

    ★ 사용자 요구 「작업대상/범위를 선택하면 그 내부에 **이미 작성된 것,
      언어별 상태를 표시**」가 바로 이 값이다. `LangStatusTable` 이 그대로 받는다.
    """
    langs = langs or ui_langs()
    hv = have(conn, kind, scope)
    total = len(hv)
    return {lg: (sum(1 for s in hv.values() if lg in s), total) for lg in langs}


def todo(conn, kind, scope='', task='NEW', lang=None,
         base=None, limit=0, parts=None, add=()):
    """**할 일 목록** — `[(자리번호, 이름)]`.

    ★★★ 업무내용이 격자의 어느 칸을 가리키는지가 이 함수의 전부다:
      · NEW   — 기준 언어(`base`)에도 없는 자리. **자료가 없는 것**
      · TRANS — 기준엔 있는데 `lang` 에 없는 자리
      · EDIT  — `lang` 에 이미 있는 자리
    """
    # ★ **남의 글은 다듬지 않는다**(§0-1b 규칙 ① · `edit_blocked`)
    if edit_blocked(kind, task, lang or '', scope, conn):
        return []
    assert task in TASK_NAME, task
    # ⚠ **자산이 기준 언어를 정한다**(2026-09-23) — 밖에서 안 주면 여기서.
    lang = (lang or base_lang(kind, scope, conn)).upper()
    base = (base or base_lang(kind, scope, conn)).upper()
    hv = have(conn, kind, scope, parts=parts, add=add)
    out = []
    for sid, label in slots(conn, kind, scope, lang='KO'):   # 자리 이름은 한국어로
        got = hv.get(sid, set())
        if task == 'NEW':
            ok = base not in got
        elif task == 'TRANS':
            ok = (base in got) and (lang not in got)
        else:
            ok = lang in got
        if ok:
            out.append((sid, label))
            if limit and len(out) >= limit:
                break
    return out


# ══════════════════════════════════════════════════════════════════════
#  프롬프트 프로필
# ══════════════════════════════════════════════════════════════════════

SCHEMA = """
CREATE TABLE IF NOT EXISTS sys_ai_profile (
    profile_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_code TEXT UNIQUE,
    name         TEXT NOT NULL,
    asset_kind   TEXT NOT NULL,
    task         TEXT NOT NULL,
    scope_value  TEXT DEFAULT '',
    lang_json    TEXT DEFAULT '',
    prompt_json  TEXT NOT NULL,
    gates_json   TEXT DEFAULT '',
    model        TEXT DEFAULT '',
    batch_n      INTEGER DEFAULT 1,
    version      INTEGER DEFAULT 1,
    note         TEXT DEFAULT '',
    sort_order   INTEGER DEFAULT 100,
    record_status TEXT DEFAULT 'LIVE',
    updated_at   TEXT
);
CREATE TABLE IF NOT EXISTS sys_ai_profile_hist (
    hist_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    profile_id   INTEGER NOT NULL,
    version      INTEGER NOT NULL,
    name         TEXT,
    asset_kind   TEXT,
    task         TEXT,
    scope_value  TEXT,
    lang_json    TEXT,
    prompt_json  TEXT,
    gates_json   TEXT,
    model        TEXT,
    batch_n      INTEGER,
    note         TEXT,
    saved_at     TEXT
);
CREATE INDEX IF NOT EXISTS idx_ai_profile_pick
    ON sys_ai_profile(asset_kind, task, scope_value);
CREATE INDEX IF NOT EXISTS idx_ai_profile_hist
    ON sys_ai_profile_hist(profile_id, version);
"""

PROMPT_KEYS = ('role', 'task', 'style', 'must', 'never', 'length',
               'terms', 'example', 'output', 'note')


def init_schema(conn):
    conn.executescript(SCHEMA)
    conn.commit()


def check_prompt(obj):
    """프롬프트 JSON 이 쓸 만한가 — `[흠, ...]`(비면 통과).

    ★ 프롬프트를 **JSON 으로 두는 까닭**(사용자 지시) = 자리마다 무엇이
      들어가야 하는지를 **글이 아니라 칸**으로 못 박기 위해서다. 산문으로
      두면 프로필을 늘릴 때마다 빠지는 칸이 생긴다.
    ⚠ `role`·`task` 만 필수다 — 나머지를 강제하면 짧은 프로필을 못 만든다.
    ⚠ 모르는 열쇠는 **흠이 아니라 알림**이다(오타를 잡되 막지는 않는다).
    """
    bad = []
    if not isinstance(obj, dict):
        return ['맨 바깥이 객체(dict)가 아니다']
    for k in ('role', 'task'):
        if not str(obj.get(k) or '').strip():
            bad.append('`%s` 가 비었다' % k)
    for k in ('style', 'must', 'never', 'terms'):
        v = obj.get(k)
        if v is not None and not isinstance(v, (list, tuple)):
            bad.append('`%s` 는 목록이라야 한다' % k)
    ln = obj.get('length')
    if ln is not None:
        if not isinstance(ln, dict):
            bad.append('`length` 는 {"min":n,"max":n} 라야 한다')
        else:
            lo, hi = ln.get('min'), ln.get('max')
            if lo is not None and hi is not None and lo > hi:
                bad.append('`length` 의 min 이 max 보다 크다')
    return bad


def unknown_keys(obj):
    if not isinstance(obj, dict):
        return []
    return [k for k in obj if k not in PROMPT_KEYS]


COMMON_CFG = 'AI_COMMON_RULES'   # sys_config — 모든 작업에 함께 실린다


def common_rules(conn=None):
    """**모든 작업 공통 준수사항** — 줄 목록.

    ★ 프로필마다 따로 적으면 프로필이 늘 때 **반드시 하나가 빠진다**.
      여기 한 곳에 적고 `render_prompt` 가 모든 프롬프트 맨 앞에 붙인다.
    """
    close = conn is None
    conn = conn or _conn()
    try:
        r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                         (COMMON_CFG,)).fetchone()
    finally:
        if close:
            conn.close()
    raw = (r[0] if r and r[0] else '')
    return [x.strip().lstrip('·-* ').strip()
            for x in str(raw).splitlines() if x.strip()]


def set_common_rules(conn, text):
    """공통 준수사항을 적는다 — 줄 하나가 규칙 하나."""
    conn.execute(
        "INSERT INTO sys_config(config_key, config_val) VALUES(?,?) "
        "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
        (COMMON_CFG, text or ''))
    conn.commit()
    return len(common_rules(conn))


def render_prompt(obj, ctx=None, rules=None):
    """프롬프트 JSON → **실제로 보낼 글**.

    ⚠ JSON 을 그대로 던지지 않는다 — 모델은 산문 지시를 더 잘 따른다. 칸은
      **적는 사람**을 위한 것이고, 여기서 한 번 사람 말로 편다.
    ⚠ 렌더는 **이 함수 하나**다. 화면과 실행기가 각자 펴면 「미리보기와 실제가
      다르다」가 된다.
    """
    ctx = ctx or {}
    L = []
    # ★★★ **공통 준수사항을 맨 앞에** — 뒤에 두면 긴 재료에 묻힌다.
    #   ⚠ 붙이는 자리는 **이 함수 하나**다. 화면 미리보기와 실제로 보낸 글이
    #     갈리면 「미리보기와 다르게 나온다」가 된다.
    try:
        rr = common_rules() if rules is None else list(rules)
    except Exception:                                     # noqa: BLE001
        rr = []
    if rr:
        L.append('[모든 작업에 공통으로 지킬 것]')
        L += ['  · %s' % x for x in rr]
    if obj.get('role'):
        L.append('[역할] %s' % obj['role'])
    if obj.get('task'):
        L.append('[할 일] %s' % obj['task'])
    _rr = set(rr)
    for key, head in (('style', '[문체]'), ('must', '[반드시]'),
                      ('never', '[금지]'), ('terms', '[용어 고정]')):
        v = obj.get(key)
        if key == 'must' and v and _rr:
            # ★ 2026-10-13 — 공통 준수사항은 맨 앞 묶음에 이미 있다(실측: 같은 세 줄이 두 번 나갔다)
            v = [x for x in v if x not in _rr]
        if v:
            L.append(head)
            L += ['  · %s' % x for x in v]
    if obj.get('cite'):
        L.append('[성경 인용] %s' % obj['cite'])
    ln = obj.get('length')
    if isinstance(ln, dict) and (ln.get('min') or ln.get('max')):
        L.append('[분량] %s ~ %s 자'
                 % (ln.get('min', '?'), ln.get('max', '?')))
    elif isinstance(ln, str) and ln.strip():
        L.append('[분량] %s' % ln.strip())
    if obj.get('example'):
        L.append('[예시]\n%s' % obj['example'])
    if obj.get('output'):
        L.append('[출력서식] %s' % obj['output'])
    for k, v in ctx.items():
        L.append('[%s]\n%s' % (k, v))
    return '\n'.join(L)


def _now():
    import datetime
    return datetime.datetime.now().isoformat(timespec='seconds')


# ══════════════════════════════════════════════════════════════════════
#  프롬프트 층 — `sys_ai_prompt` (2026-09-25 · 1.txt 16-2 · 3)
# ══════════════════════════════════════════════════════════════════════
#
# ★★★ **조건 넷이 층을 만든다** — `kind`(자산 유형) · `scope`(개별) ·
#   `task`(업무) · **`lang`(대상 언어)**. 빈칸은 「아무거나」이고,
#   **채워진 조건이 많을수록 좁다.** 넓은 층부터 쌓고 좁은 층이 나중에 온다
#   (§277차 `pick_profile` 의 「좁은 것이 이긴다」와 같은 문법).
#
# ★★★ **언어 축이 없어서 같은 말을 프로필마다 베껴야 했다.** 사용자 예
#   「러시아어 번역은 시노드역으로」는 **자산과도 개별과도 무관한 조건**이라
#   지금 구조(자산 × 업무 × 범위)에는 넣을 자리가 없었다. 베끼면 반드시
#   하나가 빠진다 — 실측 도서 프로필 여섯에 같은 줄이 여섯 번 있었다.
#
#     kind='' scope='' task='TRANS' lang='RU' part='must'
#     body = 성경 인용은 시노드역 본문을 그대로 옮긴다
#     → 어떤 자산이든 러시아어로 번역할 때 **한 줄로** 걸린다
#
# ⚠⚠ **성격(part)마다 합치는 법이 다르다** — 안 가르면 층이 늘수록 더
#   헷갈린다. 규칙 목록은 **쌓고**(넓은 층의 규칙이 살아 있어야 한다),
#   한 문장짜리는 **좁은 것이 이긴다**(둘이면 모순된다).
#
# ⚠ **옛 프로필(`sys_ai_profile`)을 걷지 않았다** — 그것이 **가장 좁은 층**
#   (개별)으로 그대로 산다. 이관을 안 하므로 되돌릴 수 있고, 사용자가
#   「개별자산 프롬프트는 거의 필요하지 않다」 한 대로 **비워 가면 된다**.

PROMPT_SCHEMA = """
CREATE TABLE IF NOT EXISTS sys_ai_prompt (
    prompt_id   INTEGER PRIMARY KEY AUTOINCREMENT,
    kind        TEXT NOT NULL DEFAULT '',
    scope       TEXT NOT NULL DEFAULT '',
    task        TEXT NOT NULL DEFAULT '',
    lang        TEXT NOT NULL DEFAULT '',
    part        TEXT NOT NULL,
    body        TEXT NOT NULL DEFAULT '',
    sort_order  INTEGER DEFAULT 100,
    record_status TEXT DEFAULT 'LIVE',
    updated_at  TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_sys_ai_prompt_unq
    ON sys_ai_prompt(kind, scope, task, lang, part);
"""

# 성격 — 화면 이름은 **사람 말**로(사용자 「암호같은 표현」 지적과 같은 규칙)
# ★★★ 2026-09-29 294차(1.txt 1번 2)) — 「내는 꼴」→ **출력서식**(사용자
#   「이상한 단어 사용금지」) · **성경 인용**(언어별 역본 — 그전에는 「반드시」
#   줄에 섞여 있어 어디에 적는지 사람이 또 판단했다) · **분량**(옛 프로필의
#   `length` 가 층에는 자리가 없었다) · **예시**(본보기 글). 열쇠는 옛 프로필
#   JSON 의 열쇠와 같아 이관할 때 한 번에 옮겨진다.
PROMPT_PARTS = [
    ('role',    '역할',      False),
    ('task',    '할 일',     False),
    ('style',   '문체',      True),
    ('must',    '반드시',    True),
    ('never',   '금지',      True),
    ('terms',   '용어 고정', True),
    ('cite',    '성경 인용', False),
    ('length',  '분량',      False),
    ('example', '예시',      False),
    ('output',  '출력서식',  False),
]
# `True` = **쌓는다**(줄 목록) · `False` = **좁은 것이 이긴다**(한 문장)
PART_STACK = {k: st for k, _n, st in PROMPT_PARTS}
PART_NAME = {k: n for k, n, _s in PROMPT_PARTS}
#: 화면 설명 — 성격마다 **무엇을 적는 칸인가**(사용자 「검토」 요구 · 1번 2))
PART_HINT = {
    'role':    '누구로서 쓰나 — 한 문장. 좁은 층이 이긴다.',
    'task':    '이 자리에서 할 일 한 가지 — 한두 문장. 좁은 층이 이긴다.',
    'style':   '문체 규칙 — 한 줄에 하나. 층이 쌓인다.',
    'must':    '꼭 지킬 것 — 한 줄에 하나. 층이 쌓인다.',
    'never':   '하지 말 것 — 한 줄에 하나. 층이 쌓인다.',
    'terms':   '고정 표기(이름·용어) — 한 줄에 하나. 층이 쌓인다.',
    'cite':    '성경 구절을 인용할 때 쓰는 역본 — 언어별 층에 적는다. 좁은 층이 이긴다.',
    'length':  '분량 — 「300~600자」처럼. 좁은 층이 이긴다.',
    'example': '본보기 글 한 편 — 그대로 실린다. 좁은 층이 이긴다.',
    'output':  '내보내는 모양 — 「본문만 · 제목 없이」처럼. 좁은 층이 이긴다.',
}


def init_prompt_schema(conn):
    conn.executescript(PROMPT_SCHEMA)
    conn.commit()


def _layer_rows(conn, kind, scope, task, lang, with_key=False):
    """맞는 층을 **넓은 것부터** — `[(넓이, part, body)]` (`with_key` 면 `(넓이, part, body, 출처 열쇠)`).

    ⚠ 조건은 **빈칸이거나 값이 같아야** 맞는다. 다른 값이면 그 층은 남의 것이다.
    """
    init_prompt_schema(conn)
    rows = conn.execute(
        "SELECT kind, scope, task, lang, part, body, sort_order "
        "FROM sys_ai_prompt WHERE COALESCE(record_status,'LIVE')='LIVE' "
        "  AND TRIM(COALESCE(body,''))<>''").fetchall()
    want = {'kind': (kind or ''), 'scope': (scope or ''),
            'task': (task or ''), 'lang': (lang or '').upper()}
    out = []
    for k, sc, tk, lg, part, body, so in rows:
        cond = {'kind': k or '', 'scope': sc or '', 'task': tk or '',
                'lang': (lg or '').upper()}
        ok = True
        n = 0
        for key, v in cond.items():
            if not v:
                continue
            n += 1
            if v != want[key]:
                ok = False
                break
        if ok:
            out.append((n, int(so or 100), part, body,
                        (k or '', sc or '', tk or '', (lg or '').upper())))
    out.sort(key=lambda x: (x[0], x[1]))
    if with_key:
        return [(w, p, b, kk) for w, _so, p, b, kk in out]
    return [(w, p, b) for w, _so, p, b, _kk in out]


def compose_prompt(conn, kind, scope='', task='NEW', lang='KO', prof=None):
    """**층을 하나로 합친 프롬프트 객체** — 이것이 실제로 나간다.

    차례 = 공통 준수사항 → 층(넓은 것부터) → 개별 프로필(가장 좁다).
    ⚠ **합치는 자리는 `compose_trace` 하나다**(2026-10-13) — 화면 조회도 그것을 그대로 그린다.
      옛 판은 조회 화면이 합치는 코드를 따로 가져 실측 132조합 중 59조합이 실제와 달랐다.
    """
    return compose_trace(conn, kind, scope, task, lang, prof)[0]


#: 출처 열쇠 — 층이 아닌 것
SRC_LINK_REVIEW = ('@연결 점검 본보기', '', '', '')
SRC_PROFILE = ('@옛 프로필', '', '', '')
SRC_RUNTIME = ('@보낼 때 붙음', '', '', '')
SRC_GATE = ('@게이트 기준', '', '', '')


def compose_trace(conn, kind, scope='', task='NEW', lang='KO', prof=None, gate_lines=True):
    """`(obj, trace, lost)` — **실제로 나가는 프롬프트**와 줄마다의 출처.

    · obj   = 보내는 객체(`render_prompt` 가 편다)
    · trace = {part: [(줄, 출처 열쇠)]} — 쌓는 칸은 줄 차례대로, 이기는 칸은 이긴 하나
    · lost  = {part: [(글, 출처 열쇠)]} — 이기는 칸에서 **더 좁은 층에 가려진** 글(조회 화면이 회색으로 보인다)
    """
    obj, trace, lost = {}, {}, {}

    def _put(part, body, key):
        body = (body or '').strip()
        if not body:
            return
        if PART_STACK.get(part, True):
            cur = obj.get(part)
            lines = [x.strip() for x in body.splitlines() if x.strip()]
            cur = cur if isinstance(cur, list) else []
            add = [x for x in lines if x not in cur]       # ⚠ 같은 줄을 두 번 쌓지 않는다
            obj[part] = cur + add
            trace.setdefault(part, []).extend((x, key) for x in add)
        else:
            if part in trace:
                lost.setdefault(part, []).extend(trace[part])
            obj[part] = body                            # 좁은 것이 이긴다(나중이 덮는다)
            trace[part] = [(body, key)]

    if is_link_review(kind, task):
        # ★ 317차-5 — 연결 점검: 본보기 + **그 자산 × 그 업무 층**만(신규 층과 할 일이 반대다)
        #   317차-20 — 해제분석(VERS_UNLINK)은 신규 작성 층을 쓴다
        for part, body in LINK_REVIEW.items():
            _put(part, body, SRC_LINK_REVIEW)
        try:
            init_prompt_schema(conn)
            for part, body in conn.execute(
                    "SELECT part, body FROM sys_ai_prompt WHERE kind=? AND task=?"
                    " AND COALESCE(scope,'')='' AND COALESCE(lang,'')=''"
                    " AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY sort_order",
                    (kind, str(task).upper())):
                if part in ('role', 'task', 'output'):
                    if part in trace:
                        lost.setdefault(part, []).extend(trace.pop(part))
                    obj.pop(part, None)
                _put(part, body, (kind, '', str(task).upper(), ''))
        except Exception:                                 # noqa: BLE001
            pass
        _gate_put(conn, kind, task, lang, obj, _put, gate_lines)
        return obj, trace, lost
    # ① 전체 공통 준수사항 — 가장 넓다
    try:
        for r in common_rules(conn):
            _put('must', r, ('', '', '', ''))
    except Exception:                                     # noqa: BLE001
        pass
    # ② 층 — 개별(범위) 층까지 여기서 함께 온다
    for _w, part, body, key in _layer_rows(conn, kind, scope, task, lang, with_key=True):
        _put(part, body, key)
    # ③ ⚠ 옛 프로필(`sys_ai_profile`)은 **더 쌓지 않는다**(2026-09-29 294차) — 아직 안 옮긴 DB 에서만.
    if prof is None and not _profiles_migrated(conn):
        prof = pick_profile(conn, kind, task, scope)
    if prof and not _profiles_migrated(conn):
        try:
            old = json.loads(prof['prompt_json'])
        except Exception:                                 # noqa: BLE001
            old = {}
        for part, v in (old or {}).items():
            if isinstance(v, (list, tuple)):
                for x in v:
                    _put(part, str(x), SRC_PROFILE)
            elif isinstance(v, dict):
                obj.setdefault(part, v)          # length 등 — 덮지 않는다
            elif v:
                _put(part, str(v), SRC_PROFILE)
    _gate_put(conn, kind, task, lang, obj, _put, gate_lines)
    return obj, trace, lost


def _gate_put(conn, kind, task, lang, obj, put, on):
    """★★★ **게이트가 재는 것은 프롬프트에도 실린다**(2026-10-13 · 사용자 「느닷없이 게이트를 들이대면
    당연히 걸릴 수 밖에 없다」) — 층이 말하지 않은 게이트 기준을 「게이트 기준」 출처로 「반드시」에 붙인다.
    실측 — 쓰인 자산·업무 21조합에서 게이트 규칙 155개 가운데 27개를 프롬프트가 말하지 않았다
    (묶음의 첫머리 겹침·문단 나누기 · 다듬기의 괄호·구절 표기 …). 관리자가 끈 규칙은 붙이지 않는다."""
    if not on or not kind:
        return
    try:
        import db_ai_run as _AR
        for line in _AR.gate_prompt_lines(conn, kind, task, lang, text=render_prompt(obj, {})):
            put('must', line, SRC_GATE)
    except Exception:                                     # noqa: BLE001
        pass


#: ★ 구절 연결기가 연결설명문을 함께 쓸 때 보낼 때 붙는 줄 — `run_job` 과 조회 화면이 함께 쓴다
LINKDESC_LINE = ('줄 끝 「왜 잇는가」 자리에 **연결설명문**을 쓴다 — 두 구절의 관계를 '
                 '1~3문장, 흐르는 산문 합니다체. 그 글이 그대로 연결설명문으로 담긴다(대시·원어 낱자·관점 머리말 금지).')


def runtime_extras(kind, parts=None, add_mode=None):
    """**보낼 때 저절로 붙는 줄** — `[(part, 줄, 언제)]`(조회 화면이 「보낼 때 붙음」으로 보인다).

    작업마다 달라지는 것(묶음에서 고른 칸 · 연결설명문 함께 쓰기)은 작업을 만들 때 정해진다.
    """
    a = ASSET.get(kind) or {}
    out = []
    if a.get('store') == 'BUNDLE':
        try:
            out.append(('must', bundle_ask(parts or ''), '작업에서 고른 칸에 따라 바뀐다'))
        except Exception:                                 # noqa: BLE001
            pass
    if a.get('store') == 'LINK' and not is_link_review(kind, 'NEW'):
        out.append(('must', LINKDESC_LINE, '「연결설명문 함께 작성」을 켠 작업에만'))
    return out


def layer_sources(conn, kind, scope='', task='NEW', lang='KO'):
    """합쳐진 프롬프트의 **어느 줄이 어느 층에서 왔나** — `[(층 이름 열쇠, part, body)]`.

    ★ 조회 화면(1번 1) 「조회」)이 결합 프롬프트를 보이면서 줄마다 출처를
      적는 데 쓴다. 합치는 규칙은 `compose_prompt` 와 같다(같은 `_layer_rows`).
    """
    out = []
    try:
        for r in common_rules(conn):
            out.append((('', '', '', ''), 'must', r))
    except Exception:                                     # noqa: BLE001
        pass
    init_prompt_schema(conn)
    rows = conn.execute(
        "SELECT kind, scope, task, lang, part, body, sort_order "
        "FROM sys_ai_prompt WHERE COALESCE(record_status,'LIVE')='LIVE' "
        "  AND TRIM(COALESCE(body,''))<>''").fetchall()
    want = {'kind': (kind or ''), 'scope': (scope or ''),
            'task': (task or ''), 'lang': (lang or '').upper()}
    got = []
    for k, sc, tk, lg, part, body, so in rows:
        cond = {'kind': k or '', 'scope': sc or '', 'task': tk or '',
                'lang': (lg or '').upper()}
        n = 0
        ok = True
        for key, v in cond.items():
            if not v:
                continue
            n += 1
            if v != want[key]:
                ok = False
                break
        if ok:
            got.append((n, int(so or 100), (k or '', sc or '', tk or '',
                                            (lg or '').upper()), part, body))
    got.sort(key=lambda x: (x[0], x[1]))
    for _n, _so, key, part, body in got:
        out.append((key, part, body))
    return out


def _profiles_migrated(conn):
    """프로필이 층으로 옮겨졌나 — `sys_config[AI_PROFILES_MIGRATED]`."""
    try:
        r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                         ('AI_PROFILES_MIGRATED',)).fetchone()
    except Exception:                                     # noqa: BLE001
        return False
    return bool(r and str(r[0] or '').strip())


def _prof_to_parts(old):
    """옛 프로필 JSON → `{part: body}`(층 칸 꼴)."""
    out = {}
    for k, v in (old or {}).items():
        if k not in PART_STACK and k != 'note':
            continue
        if k == 'note':
            continue
        if isinstance(v, dict):
            lo, hi = v.get('min'), v.get('max')
            if lo or hi:
                out['length'] = '%s~%s자' % (lo or '', hi or '')
            continue
        if isinstance(v, (list, tuple)):
            body = NL_.join(str(x).strip() for x in v if str(x).strip())
        else:
            body = str(v or '').strip()
        if body:
            out[k] = body
    return out


def migrate_profiles(conn, dry=False):
    """**프로필을 층으로 옮긴다**(2026-09-29 294차 · 1.txt 1번 7)).

    ★★★ 까닭 — 프롬프트 저장소가 둘(프로필 JSON · 층)이라 `create_job` 이
      프로필을 요구했고, 프로필이 없는 자산 11종(주석·연구 자료 …)은
      **화면에 업무가 보이는데 누르면 「프롬프트 프로필이 없습니다」**였다.
      층은 자산 스물 전부에 있으므로 층 하나로 모으면 그 문이 사라진다.
    · 프로필 `(kind, task, scope)` → 층 `(kind, scope, task, lang='')`.
      **있는 칸은 안 덮는다**(사람이 층에 먼저 적어 둔 글이 이긴다) —
      프로필 글은 그 뒤에 이어 붙인다(쌓는 성격) / 비어 있을 때만(이기는 성격).
    · 프로필 행은 지우지 않고 `record_status='ARCHIVED'` — 이력도 그대로.
    · 끝나면 `sys_config[AI_PROFILES_MIGRATED]` 에 날짜를 적어 `compose_prompt`
      가 프로필을 더 안 읽게 한다. 되돌리기 = 그 열쇠 지우고 ARCHIVED→LIVE.
    되돌아온 값 = `(옮긴 프로필 수, 적은 칸 수, 건너뛴 칸 수)`.
    """
    init_schema(conn)
    init_prompt_schema(conn)
    rows = conn.execute(
        "SELECT profile_id, asset_kind, task, COALESCE(scope_value,''),"
        " prompt_json FROM sys_ai_profile WHERE record_status='LIVE'").fetchall()
    n_prof = n_put = n_skip = 0
    for pid, kind, task, scope, pj in rows:
        try:
            old = json.loads(pj or '{}')
        except Exception:                                 # noqa: BLE001
            old = {}
        parts = _prof_to_parts(old)
        if kind not in ASSET:
            # ⚠ 옛 자산 열쇠(REF_UNIT 등) — 층으로 옮길 자리가 없다. 보관만.
            if not dry:
                conn.execute("UPDATE sys_ai_profile SET record_status='ARCHIVED'"
                             " WHERE profile_id=?", (pid,))
            n_prof += 1
            continue
        cur = get_layer(conn, kind, scope, task, '')
        for part, body in parts.items():
            have = (cur.get(part) or '').strip()
            if PART_STACK.get(part, True):
                lines = [x for x in body.splitlines() if x.strip()]
                keep = [x for x in have.splitlines() if x.strip()]
                add = [x for x in lines if x not in keep]
                if not add:
                    n_skip += 1
                    continue
                new = NL_.join(keep + add)
            else:
                if have:
                    n_skip += 1
                    continue
                new = body
            if not dry:
                set_layer(conn, kind, scope, task, '', part, new)
            n_put += 1
        if not dry:
            conn.execute("UPDATE sys_ai_profile SET record_status='ARCHIVED',"
                         " updated_at=? WHERE profile_id=?", (_now(), pid))
        n_prof += 1
    # ★★★ **업무 층의 역할·할 일은 반드시 있어야 한다** — 그것이 없으면
    #   프로필이 없던 자산(주석·자료집 …)은 `has_prompt` 가 여전히 막는다.
    #   자산 층 스무 줄은 사용자가 「내가 적재하겠다」 했으므로 여기서 안 담고,
    #   **업무 셋의 role·task·must·never 만** 씨앗에서 채운다(있는 칸은 안 덮는다).
    for task, parts in _LAYER_TASK.items():
        cur = get_layer(conn, '', '', task, '')
        for part, body in parts.items():
            if (cur.get(part) or '').strip():
                n_skip += 1
                continue
            if not dry:
                set_layer(conn, '', '', task, '', part, body)
            n_put += 1
    if not dry:
        conn.execute(
            "INSERT INTO sys_config(config_key, config_val) VALUES(?,?) "
            "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
            ('AI_PROFILES_MIGRATED', _now()))
        conn.commit()
    return n_prof, n_put, n_skip


def has_prompt(conn, kind, scope='', task='NEW', lang='KO'):
    """이 조합에 **보낼 프롬프트가 있나** — `role`·`task` 둘 다 있어야 한다.

    ★ `create_job` 이 프로필 대신 이것을 묻는다(1번 7) 「프롬프트가 없다」의
      뿌리를 뽑은 자리). 없으면 **무엇이 비었는지** 글로 돌려준다.
    """
    obj = compose_prompt(conn, kind, scope, task, lang)
    miss = [PART_NAME[k] for k in ('role', 'task') if not str(obj.get(k) or '').strip()]
    if miss:
        return False, ('이 자산·업무에 쓸 프롬프트가 아직 없습니다 — 「프롬프트」'
                       ' 탭에서 %s 칸을 적어 두세요(자산 층 또는 업무 층).'
                       % '·'.join(miss))
    return True, ''


def layer_key_error(kind, scope, task, lang, part):
    """층 열쇠가 **꼴에 맞나** — 틀리면 까닭 한 줄, 맞으면 ''.

    ★★★ 295차 실측 — 화면 단추 버그가 `lang='VERS_QUES_EXP'` 층을 만들었다.
      저장 문이 꼴을 안 재면 그런 층이 조용히 쌓이고 `compose_prompt` 는 그것을
      어느 언어에도 안 쓰면서 화면 표식(●)만 켠다. 자산은 `ASSET` 안 · 업무는
      `TASK_NAME` 안 · 언어는 대문자 2~3자 · 성격은 `PART_STACK` 안이라야 한다.
    """
    import re as _re
    if kind and kind not in ASSET:
        return '모르는 자산: %r' % (kind,)
    if task and task not in TASK_NAME:
        return '모르는 업무: %r' % (task,)
    lg = (lang or '').upper()
    if lg and not _re.fullmatch(r'[A-Z]{2,3}', lg):
        return '언어 코드 꼴이 아니다: %r' % (lang,)
    if part not in PART_STACK:
        return '모르는 성격: %r' % (part,)
    return ''


def set_layer(conn, kind, scope, task, lang, part, body):
    """층 한 칸을 적는다. 빈 글이면 **지운다**(빈 줄이 남으면 화면이 거짓말한다).

    ⚠ 열쇠 꼴이 틀리면 `ValueError` — **지우는 것은 허락한다**(잘못 들어간 층을
      걷어 낼 길이 있어야 한다).
    """
    init_prompt_schema(conn)
    key = ((kind or ''), (scope or ''), (task or ''),
           (lang or '').upper(), part)
    _why = layer_key_error(*key)
    if _why and (body or '').strip():
        raise ValueError('층 열쇠가 틀렸다 — ' + _why)
    if not (body or '').strip():
        conn.execute("DELETE FROM sys_ai_prompt WHERE kind=? AND scope=?"
                     "  AND task=? AND lang=? AND part=?", key)
        conn.commit()
        return 0
    conn.execute(
        "INSERT INTO sys_ai_prompt(kind, scope, task, lang, part, body,"
        " updated_at) VALUES(?,?,?,?,?,?,?) "
        "ON CONFLICT(kind, scope, task, lang, part) DO UPDATE SET "
        " body=excluded.body, record_status='LIVE',"
        " updated_at=excluded.updated_at", key + ((body or '').strip(), _now()))
    conn.commit()
    return 1


#: 「하라」 칸과 「하지 말 것」 칸 — 부딪힘 검사(2026-10-13 · docs/1.txt 71)
_PUSH_PARTS = ('role', 'task', 'must', 'style', 'cite', 'length', 'example', 'output')
_QUOTED = re.compile('「([^」]{1,40})」|“([^”]{1,40})”|"([^"]{1,40})"|‘([^’]{1,40})’')


def _core(s):
    return re.sub(r'[^가-힣A-Za-z0-9]', '', s or '')


def layer_conflicts(conn, kind, scope='', task='NEW', lang='KO'):
    """**함께 실리는 층끼리 부딪히는 줄** — `[(하라 출처, 칸, 줄, 하지말것 출처, 줄, 겹친 말)]`.

    ★ 2026-10-13 실측 — 연결설명문 공통 층의 「반드시: 첫 문장에 「왜 이 둘인가」」와 다듬기 층의
      「하지 말 것: "왜 둘인가 하면" … 절대 사용 금지」가 **한 프롬프트에 함께** 실리고 있었다.
      사람은 한 층만 보고 고치므로 다른 층에 남은 줄을 모른다 — 화면이 그 사실을 말해야 한다.
    잣대 = **양쪽 줄이 따옴표로 든 말끼리** 세 글자 넘게 이어서 겹치고 그것이 짧은 쪽의 60% 이상인가
      (숫자·기호·공백 무시). 따옴표 없는 줄까지 견주면 「합니다」 같은 흔한 조각으로 헛걸린다(실측 84건 중 83건).
    """
    src = layer_sources(conn, kind, scope, task, lang)
    pos = [(k, p, l.strip()) for k, p, b in src if p in _PUSH_PARTS for l in (b or '').split(chr(10)) if l.strip()]
    neg = [(k, l.strip()) for k, p, b in src if p == 'never' for l in (b or '').split(chr(10)) if l.strip()]
    out, seen = [], set()
    for nk, nl in neg:
        nsegs = [_core_l(''.join(x)) for x in _QUOTED.findall(nl)]
        for pk, pp, pl in pos:
            if _NEG_WORD.search(pl):
                continue          # 「하라」 칸에서 나쁜 보기를 들며 「…하지 않는다」 — 같은 말의 되풀이다
            psegs = [_core_l(''.join(x)) for x in _QUOTED.findall(pl)]
            hit = None
            for a in psegs:
                for b in nsegs:
                    n = _lcs(a, b)
                    if n >= 3 and n >= 0.6 * min(len(a), len(b)):
                        hit = (a, b)
                        break
                if hit:
                    break
            if hit and (pl, nl) not in seen:
                seen.add((pl, nl))
                out.append((pk, pp, pl, nk, nl, hit[1]))
    # ★ 분량이 두 곳에 다르게 적혔나 — 「200~400자」(반드시) ↔ 「120~250자」(분량)
    rng = re.compile(r'(\d{2,4})\s*[~∼\-–]\s*(\d{2,4})\s*자')
    win_len = [(k, b) for k, p, b in src if p == 'length']
    win_len = win_len[-1] if win_len else None
    if win_len:
        wl = rng.search(win_len[1] or '')
        for pk, pp, pl in pos:
            if pp == 'length':
                continue
            m = rng.search(pl)
            if m and wl and (m.group(1), m.group(2)) != (wl.group(1), wl.group(2)) and (pl, win_len[1]) not in seen:
                seen.add((pl, win_len[1]))
                out.append((pk, pp, pl, win_len[0], '[분량] ' + win_len[1].strip(), '분량이 다르다'))
    # ★ 「…라고 표현하라」가 **금지 칸**에 있고 다른 금지 줄이 그 말을 막나 — 「"당신"이라고 표현하라」 ↔ 「당신·여러분의 삶」
    _posv = re.compile(r'라고 (표현|쓰|적)|을 쓴다|를 쓴다|사용하라')
    for nk, nl in neg:
        if not _posv.search(nl):
            continue
        for x in _QUOTED.findall(nl):
            w = _core_l(''.join(x))
            if len(w) < 2:
                continue
            for nk2, nl2 in neg:
                if nl2 is nl or w not in _core_l(nl2) or (nl, nl2) in seen:
                    continue
                if any(_core_l(''.join(y)) == w for y in _QUOTED.findall(nl2)):
                    continue      # 그 줄도 같은 낱말을 그대로 권한다(「원문의 you 는 「당신」」)
                if w in _core_l(nl.split(''.join(x))[0]):
                    continue
                seen.add((nl, nl2))
                out.append((nk, 'never', nl, nk2, nl2, w))
    return out


_NEG_WORD = re.compile(r'않는다|않습니다|말고|금지|아니라|하지 말|쓰지 않')


def _core_l(s):
    """글자만(한글·영문) — 숫자·기호·공백은 뺀다(구절 번호가 겹쳐 헛걸리지 않게)."""
    return re.sub(r'[^가-힣A-Za-z]', '', s or '')


def _lcs(a, b):
    """가장 긴 이어진 공통 조각의 길이."""
    best = 0
    for i in range(len(a)):
        for k in range(i + best + 1, len(a) + 1):
            if a[i:k] in b:
                best = k - i
            else:
                break
    return best


def companion_lines(conn, kind, scope, task, lang, part, own_key):
    """그 칸에 **함께 실리는 다른 층의 줄** — `[(출처 열쇠, 줄)]` (지금 고치는 층은 뺀다)."""
    return [(k, l.strip()) for k, p, b in layer_sources(conn, kind, scope, task, lang)
            if p == part and tuple(k) != tuple(own_key) for l in (b or '').split(chr(10)) if l.strip()]


def get_layer(conn, kind, scope, task, lang):
    """그 **한 층**의 성격별 글 — `{part: body}`(다른 층은 안 섞는다)."""
    init_prompt_schema(conn)
    rows = conn.execute(
        "SELECT part, body FROM sys_ai_prompt WHERE kind=? AND scope=?"
        "  AND task=? AND lang=? AND COALESCE(record_status,'LIVE')='LIVE'",
        ((kind or ''), (scope or ''), (task or ''),
         (lang or '').upper())).fetchall()
    return {p: b for p, b in rows}


def layer_list(conn):
    """적혀 있는 층 목록 — `[(kind, scope, task, lang, 칸수)]`, 넓은 것부터."""
    init_prompt_schema(conn)
    rows = conn.execute(
        "SELECT kind, scope, task, lang, COUNT(*) FROM sys_ai_prompt "
        "WHERE COALESCE(record_status,'LIVE')='LIVE' "
        "  AND TRIM(COALESCE(body,''))<>'' "
        "GROUP BY kind, scope, task, lang").fetchall()
    return sorted(rows, key=lambda r: (sum(1 for x in r[:4] if x), r[:4]))


def save_profile(conn, prof):
    """프로필을 저장하고 **옛 판을 이력에 남긴다**. 새 `version` 을 돌려준다.

    ★★★ 사용자 지시 — 「이전에 시편 설명문 번역할 때 사용한 프롬프트를
      **계속 참고용으로 보관**해야 한다」. 그래서 덮어쓰기 전에 **있는 판을
      통째로** `sys_ai_profile_hist` 로 옮긴다.
    ⚠ 프로필을 지워도 이력은 남긴다(삭제는 `record_status='HIDE'`).
    """
    init_schema(conn)
    bad = check_prompt(json.loads(prof['prompt_json']))
    assert not bad, '프롬프트 흠: %s' % ' / '.join(bad)
    code = prof.get('profile_code') or profile_code(
        prof['asset_kind'], prof['task'], prof.get('scope_value', ''))
    cur = conn.execute(
        "SELECT profile_id, version, name, asset_kind, task, scope_value, "
        "lang_json, prompt_json, gates_json, model, batch_n, note "
        "FROM sys_ai_profile WHERE profile_code=?", (code,)).fetchone()
    now = _now()
    if cur:
        pid, ver = cur[0], int(cur[1] or 1)
        # ★★★ **바뀐 것이 없으면 판을 안 올린다**(2026-09-24 사용자 신고
        #   「저장버튼을 잘못 눌렀다」). 실측 — 글자가 하나도 안 바뀐 저장이
        #   프로필 65 의 판을 2→3 으로 올리고 이력에 **빈 판**을 남겼다.
        #   ⚠ 판은 「무엇이 달라졌나」를 세는 자리다. 헛판이 끼면 이력을
        #     되짚을 때 어느 판에서 무엇이 바뀌었는지 알 수 없다.
        same = (
            (cur[2] or '') == (prof['name'] or '') and
            (cur[3] or '') == (prof['asset_kind'] or '') and
            (cur[4] or '') == (prof['task'] or '') and
            (cur[5] or '') == (prof.get('scope_value', '') or '') and
            (cur[6] or '') == (prof.get('lang_json', '') or '') and
            (cur[7] or '') == (prof['prompt_json'] or '') and
            (cur[8] or '') == (prof.get('gates_json', '') or '') and
            (cur[9] or '') == (prof.get('model', '') or '') and
            int(cur[10] or 1) == int(prof.get('batch_n', 1) or 1) and
            (cur[11] or '') == (prof.get('note', '') or ''))
        if same:
            return ver
        conn.execute(
            "INSERT INTO sys_ai_profile_hist(profile_id, version, name, asset_kind,"
            " task, scope_value, lang_json, prompt_json, gates_json, model, batch_n,"
            " note, saved_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (pid, ver) + tuple(cur[2:]) + (now,))
        ver += 1
        conn.execute(
            "UPDATE sys_ai_profile SET name=?, asset_kind=?, task=?, scope_value=?,"
            " lang_json=?, prompt_json=?, gates_json=?, model=?, batch_n=?,"
            " version=?, note=?, record_status='LIVE', updated_at=? "
            "WHERE profile_id=?",
            (prof['name'], prof['asset_kind'], prof['task'],
             prof.get('scope_value', ''), prof.get('lang_json', ''),
             prof['prompt_json'], prof.get('gates_json', ''),
             prof.get('model', ''), int(prof.get('batch_n', 1) or 1),
             ver, prof.get('note', ''), now, pid))
    else:
        ver = 1
        conn.execute(
            "INSERT INTO sys_ai_profile(profile_code, name, asset_kind, task,"
            " scope_value, lang_json, prompt_json, gates_json, model, batch_n,"
            " version, note, sort_order, record_status, updated_at)"
            " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,'LIVE',?)",
            (code, prof['name'], prof['asset_kind'], prof['task'],
             prof.get('scope_value', ''), prof.get('lang_json', ''),
             prof['prompt_json'], prof.get('gates_json', ''),
             prof.get('model', ''), int(prof.get('batch_n', 1) or 1),
             ver, prof.get('note', ''), int(prof.get('sort_order', 100)), now))
    conn.commit()
    return ver


def profile_code(kind, task, scope=''):
    return '%s@%s#%s' % (kind, (scope or 'ALL'), task)


def list_profiles(conn, kind=None, live_only=True):
    init_schema(conn)
    q = ("SELECT profile_id, profile_code, name, asset_kind, task, scope_value,"
         " version, model, COALESCE(note,''), record_status "
         "FROM sys_ai_profile WHERE 1=1")
    args = []
    if kind:
        q += " AND asset_kind=?"
        args.append(kind)
    if live_only:
        q += " AND record_status='LIVE'"
    q += " ORDER BY asset_kind, task, (scope_value=''), scope_value"
    return conn.execute(q, args).fetchall()


def get_profile(conn, pid):
    init_schema(conn)
    r = conn.execute(
        "SELECT profile_id, profile_code, name, asset_kind, task, scope_value,"
        " lang_json, prompt_json, gates_json, model, batch_n, version,"
        " COALESCE(note,''), record_status FROM sys_ai_profile WHERE profile_id=?",
        (pid,)).fetchone()
    if not r:
        return None
    return dict(zip(('profile_id', 'profile_code', 'name', 'asset_kind', 'task',
                     'scope_value', 'lang_json', 'prompt_json', 'gates_json',
                     'model', 'batch_n', 'version', 'note', 'record_status'), r))


def pick_profile(conn, kind, task, scope=''):
    """`(자산, 업무, 범위)` 에 **가장 잘 맞는** 프로필.

    ★★★ 사용자 지시 — 「구절설명문의 경우에도 **창세기와 시편이 서로 달라져야**
      할 수도 있다 … **스펄전 설교와 마이어 책은 번역스타일을 다르게**」.
      ⇒ 범위를 딱 집은 프로필이 **전체 프로필을 이긴다**.
    ⚠ 딱 맞는 것이 없다고 빈손으로 돌아가지 않는다 — 전체 프로필이 되받이다.
      그래야 책을 늘릴 때마다 프로필을 먼저 만들지 않아도 일이 돈다.
    """
    init_schema(conn)
    rows = conn.execute(
        "SELECT profile_id, scope_value FROM sys_ai_profile "
        "WHERE asset_kind=? AND task=? AND record_status='LIVE' "
        "AND (scope_value=? OR scope_value='' OR scope_value IS NULL)",
        (kind, task, str(scope or ''))).fetchall()
    best, score = None, -1
    for pid, sv in rows:
        s = 2 if (sv and str(sv) == str(scope or '')) else 1
        if s > score:
            best, score = pid, s
    return get_profile(conn, best) if best else None


def history(conn, pid):
    init_schema(conn)
    return conn.execute(
        "SELECT hist_id, version, name, prompt_json, COALESCE(note,''), saved_at "
        "FROM sys_ai_profile_hist WHERE profile_id=? ORDER BY version DESC",
        (pid,)).fetchall()


def restore(conn, pid, version):
    """옛 판을 **새 판으로 되살린다** — 이력은 그대로 남는다."""
    init_schema(conn)
    r = conn.execute(
        "SELECT name, asset_kind, task, scope_value, lang_json, prompt_json,"
        " gates_json, model, batch_n, note FROM sys_ai_profile_hist "
        "WHERE profile_id=? AND version=?", (pid, version)).fetchone()
    assert r, '그런 판이 없다: %s v%s' % (pid, version)
    cur = get_profile(conn, pid)
    assert cur, '프로필이 없다: %s' % pid
    prof = dict(cur)
    for i, k in enumerate(('name', 'asset_kind', 'task', 'scope_value',
                           'lang_json', 'prompt_json', 'gates_json',
                           'model', 'batch_n', 'note')):
        prof[k] = r[i]
    prof['note'] = ('%s (v%s 에서 되살림)' % (prof.get('note') or '', version)).strip()
    return save_profile(conn, prof)


# ══════════════════════════════════════════════════════════════════════
#  씨앗 프로필 — 화면이 빈 채로 열리지 않게 (§0-1)
# ══════════════════════════════════════════════════════════════════════
#
#  ⚠⚠⚠ **여기 적힌 것은 「우리 문서에 이미 있는 표준」을 옮긴 것이다.**
#    §28-11(서술 표준) · `lay.md` · `booktrans.md` §10 이 원본이고, 지어낸
#    규칙은 하나도 없다. 실제로 쓰던 프롬프트가 따로 있으면 화면에서
#    붙여 넣고 저장하면 **옛 판이 이력에 남는다.**

_KO_STYLE = ['흐르는 산문 · 합니다체', '개조식·요약 열거 금지',
             '동그라미 번호(①②③) 금지', '― 대시 금지',
             '물음은 「합니까?」 (「하나요?」·「할까요?」 금지)']
_NEVER_DENOM = ['특정 교단·전통에 귀속되는 표현(칼뱅주의·개혁주의·루터파 등)',
                '「이렇게 살라」는 적용 — 그 몫은 묵상질문이다']

# ★★ 2026-10-22 사용자 「주석, 도서 등은 교단 중립화 원칙의 예외 · 외부자료 프롬프트에 명확히 표시하라 ·
#   오히려 수정하면 문제가 된다」 — 교단 중립(§28-11)은 **우리가 쓰는 글**의 규칙이다(booktrans.md).
#   남의 저작(도서·설교·주석·신앙고백·사전·주제 색인)에는 `_NEVER_DENOM` 을 걸지 않고 이 줄을 단다.
EXTERNAL_KINDS = ('BOOK_UNIT', 'BOOK_TASTE', 'COMMENTARY', 'REF_CATE', 'REF_DICT', 'REF_TOPIC')
EXTERNAL_DENOM = ('외부 저자의 글이다 — 교단 중립 원칙을 적용하지 않는다. 저자가 쓴 교단·전통·신학자 이름과 '
                  '교리 표현을 그대로 옮기고, 고치거나 지우거나 누그러뜨리지 않는다.')

# ★★★ 연구자료 서식 — 사용자 4·5번 지시(1.txt 16-1).
#   ⚠ **신규 작성과 다듬기가 같은 문장을 쓴다** — 다듬기에서도 연구자료를
#     새로 쓸 수 있으므로, 두 곳에 따로 적으면 새로 쓴 글만 서식이 갈린다.
#   ⚠ **모양은 게이트(`db_study_gate`)가 잡는다** — 여기에는 AI 가 모를 수
#     없는 것만 적는다. 규칙을 길게 적을수록 글이 그 규칙을 설명하려 든다.
_NOTE_TERMS = [
    '연구자료 **첫 줄은 제목**이고 그 아래부터 본문이다. '
    '차례는 **1. 1) A. A)** 만 쓰고(번호 뒤에 한 칸) 다른 기호·서식은 쓰지 않는다.',
    '연구자료의 원어는 **음독(원어)** 꼴 — 오르(אור). '
    '성경 인용은 **"본문" (약명장:절)** 꼴로 적는다 — '
    '"하나님이 가라사대 빛이 있으라 하시매 빛이 있었고" (창1:3). 역본 이름은 적지 않는다.',
    '연구자료 분량은 A4 한 장 안쪽. 중요한 주제면 더 길어도 된다.',
    # ★★★ 314차 사용자 지시 — 「장연결 금지, 구절표현방법 명시」.
    #   ⚠ 까닭이 수로 있다: 장만 적은 참조는 **그 장 1절에만** 연결되고,
    #     절 개수를 「39절」로 적으면 절 번호로 읽힌다(실측 「구약 39절
    #     7권에 나온다(출애굽기 21 · 레위기 1)」이 장 참조로 읽혔다).
    '구절을 가리킬 때는 **책·장·절을 다 적는다** — 「신 15:4」 또는 '
    '「신명기 15장 4절」. **장만 적지 않는다**(「레위기 21장」은 그 장 1절에만 '
    '연결된다). 여러 곳은 각각 다 적는다 — 「신 15:4; 15:11」.',
    '절의 **개수**는 「39절」이 아니라 **「39곳」**으로 적는다 — 절 번호와 '
    '헷갈린다.',
]


# ════════════════════════════════════════════════════════════════════
#  구성요소 층 — 업무 3 · 자산 20 · 언어 11  (1.txt 16-2)
# ════════════════════════════════════════════════════════════════════
# ★★★ 사용자 지시 — 「**책 한권마다 프롬프트 만들 생각이 없다. 콤보상자
#   3개의 구성요소 조합만** 만들면 충분하다」. 20자산 × 3업무 × 11언어 =
#   **660조합**이지만 적는 것은 **34줄**이고 `compose_prompt` 가 고른
#   조합대로 합친다(좁은 것이 이긴다 · 쌓을 것은 쌓는다).
# ⚠ **자동으로 안 담는다** — 「내가 적재하겠다」. `--layers` 는 보여 주기만.

#: 업무 셋 — **무엇을 하는 일인가**(자산·언어와 무관하게 늘 참인 것)
_LAYER_TASK = {
    'NEW': {
        'role': '성경 앱에 실을 글을 **새로 쓰는 사람**.',
        'task': '아래 재료를 읽고 그 자리에 들어갈 글을 한 편 쓴다.',
        'must': '재료에 없는 사실을 지어내지 않는다.\n'
                '한 자리에 한 편만 쓴다 — 여러 안을 늘어놓지 않는다.',
        'never': '재료 밖의 사람 이름·연도·출처를 적기\n'
                 '짐작을 사실처럼 적기',
    },
    'TRANS': {
        'role': '남이 쓴 글을 다른 언어로 옮기는 사람. 저자의 글을 고치지 않는다.',
        'task': '아래 글을 「써 넣을 언어」로 옮긴다. 짜임과 차례는 그대로 둔다.',
        # ★★★ 316차 — **구절약명 표시방법**(사용자 지시). 업무 층에 두면
        #   **21자산이 함께 따라온다** — 자산마다 적으면 하나가 반드시 빠진다
        #   (실측: 315차에 절 묶음에만 넣어 도서·교리·주석이 0줄이었다).
        'must': '구절 **참조 약명**은 그 언어가 쓰는 표기로 옮긴다 — 재료의 '
                '「구절약명 표기」 꼴 그대로. 장·절 숫자는 그대로 둔다.',
        'never': '원문에 없는 설명 보태기\n원문에 있는 문장 빼기\n'
                 '구절 참조를 원문 약명 그대로 남기기',
    },
    'EDIT': {
        'role': '이미 있는 글을 **다듬는 사람**. 새로 쓰지 않는다.',
        'task': '아래 글의 뜻과 짜임을 그대로 두고 읽기 쉽게 다듬는다.',
        'must': '고칠 까닭이 없는 문장은 그대로 둔다.\n'
                '분량이 크게 늘거나 줄지 않게 한다.',
        'never': '내용을 새로 보태기\n문단 수를 바꾸기',
    },
}

#: 자산 스물 — **무엇이 들어갈 자리인가**(업무·언어와 무관한 것)
#: ⚠ `ASSETS` 의 열쇠와 **하나도 빠짐없이** 짝이 맞아야 한다(selftest 가 잰다).
_LAYER_KIND = {
    'VERS_DESC_LAY': {
        'role': '한 구절을 평신도에게 풀어 주는 사람.',
        'task': '이 구절이 무슨 일을 말하는지 장면과 사람으로 푼다. '
                '300~600자, 2~4개의 짧은 문단.',
    },
    'VERS_QUES_LAY': {
        'role': '묵상 물음을 만드는 사람.',
        'task': '이 구절을 읽고 「나는 어떻게 살 것인가」를 묻는다. '
                '한두 물음, 80~150자.',
    },
    'VERS_QUES_EXP': {
        'role': '연구 물음을 만드는 사람.',
        'task': '이 구절에서 「무엇을 더 파고들 것인가」를 묻는다. 두세 물음.',
    },
    'VERS_PRAYER': {
        'role': '본문으로 기도문을 쓰는 사람.',
        'task': '이 본문으로 무엇을 구할 것인지 기도 한 편으로 적는다. '
                '100~200자.',
    },
    'VERS_BUNDLE': {
        'role': '한 절의 글을 **한 번에** 쓰는 사람.',
        'task': '주어진 절 하나에 대해 칸마다 다른 물음에 답한다. '
                '칸 표시는 [설명문] 처럼 대괄호로 줄 맨 앞에 적는다.',
    },
    'VERS_UNLINK': {
        'role': LINK_REVIEW['role'],
        'task': LINK_REVIEW['task'],
    },
    'VERS_LINK': {
        'role': '성경의 구절과 구절을 잇는 사람.',
        'task': '주어진 절과 뜻으로 이어지는 다른 구절을 **3개에서 8개** 선택하고, 줄마다 연결 갈래를 하나씩 붙인다. '
                '연결은 한 편의 글이 아니라 **여러 줄**이다 — 한 줄만 내지 않는다.',
        'must': '두 본문에 실제로 있는 낱말·사건·약속으로 잇는다 — 왜 잇는가에 그 낱말을 든다.\n'
                '갈래는 [연결 갈래] 표의 정의와 잣대를 따른다 — 예언문이면 FUL, 사물·제도의 모형이면 TYP, '
                '문장째 겹치면 REF, 낱말 한둘이 겹치면 ALL, 뜻만 겹치면 SYN.\n'
                '[이미 이어진 구절]에 있는 절은 다시 내지 않는다.\n'
                '왜 잇는가는 합니다체 한 문장.',
        'never': '억지 비유로 잇기(두 본문 어디에도 없는 그림)\n'
                 '같은 장 안의 절\n'
                 '한 절에 갈래 둘 붙이기 — 가장 맞는 하나만\n'
                 '본문에 없는 사실 끌어오기 · 교단 이름',
        'length': '3~8줄 — 줄마다 다른 구절. 구약·신약을 두루 살핀다.',
        # ★ 2026-10-13 — 본보기 문장 셋을 걷었다. 그 끝맺음(「자랍니다」·「되울립니다」)이 결과의 12~13%에
        #   그대로 찍혔다(docs/1.txt 71). 꼴만 말하고 쓸 말을 정해 주지 않는다.
        'output': '줄마다 「약명 장:절 · 갈래코드 · 왜 잇는가 한 문장」 — 머리말·번호·다른 말 없이. '
                  '「왜」 문장은 두 본문에 실제로 같은 낱말·사건·약속을 구체적으로 든다 — 줄마다 같은 끝맺음을 되풀이하지 않는다.',
    },
    'VERS_VERS_DESC': {
        'role': '두 구절의 관계를 설명하는 사람.',
        'task': '두 구절의 관계를 한두 문장으로 적는다. 흐르는 산문으로.',
    },
    'PERI_DESC': {
        'role': '한 단락을 요약해 주는 사람.',
        'task': '이 단락이 하나의 이야기로 무엇을 말하는지 적는다. '
                '구절을 하나하나 다시 적지 않는다.',
    },
    'PERI_TITLE': {
        'role': '단락에 제목을 붙이는 사람.',
        'task': '이 단락을 한눈에 알게 하는 짧은 제목을 짓는다.',
        'output': '제목 한 줄. 설명을 붙이지 않는다.',
    },
    'CHAP_DESC': {
        'role': '한 장이 책 안에서 어디쯤인지 짚어 주는 사람.',
        'task': '이 장이 무엇을 다루고 앞뒤 장과 어떻게 이어지는지 적는다.',
    },
    'BOOK_DESC': {
        'role': '성경 한 권을 소개하는 사람.',
        'task': '이 책이 언제 누구에게 무엇을 말하는 책인지 적는다.',
    },
    'ENTITY_DESC': {
        'role': '주요용어를 설명하는 사람.',
        'task': '이 용어가 성경에서 무엇을 뜻하고 어디서 쓰이는지 적는다.',
    },
    'ENTITY_NAME': {
        'role': '주요용어의 이름을 짓는 사람.',
        'task': '그 언어에서 부를 이름을 짓는다. '
                '원어 음역이 붙어 있으면 그대로 둔다.',
        'output': '이름 한 줄.',
    },
    'BOOK_INTRO': {
        'role': '앱에 실린 책을 소개하는 짧은 글을 다루는 사람.',
        'task': '이 책이 어떤 책이고 누가 왜 읽으면 좋은지 적는다.',
        'must': '맨 끝의 「▸ 출처」 블록은 **글자 하나 안 고치고** 그대로 둔다.',
    },
    'BOOK_TASTE': {
        'role': '책 첫머리 **맛보기 조각**을 다루는 사람.',
        'task': '주어진 조각만 다룬다. 조각이 끊긴 자리는 그대로 끊어 둔다.',
        'never': '맛보기 표식(⟨…⟩)을 적기 — 그것은 도구가 붙인다\n'
                 '끊긴 뒤를 이어 쓰기',
        'must': EXTERNAL_DENOM,
    },
    'BOOK_UNIT': {
        'role': '남의 저작인 책·설교 본문을 다루는 사람.',
        'task': '저자의 글을 그대로 옮긴다.',
        'must': '저자의 논지 차례를 바꾸지 않는다.\n' + EXTERNAL_DENOM,
    },
    'COMMENTARY': {
        'role': '주석 본문을 다루는 사람.',
        'task': '주석가의 글을 그대로 옮긴다.',
        'must': '주석가의 견해를 우리 견해로 바꾸지 않는다.\n' + EXTERNAL_DENOM,
    },
    'REF_CATE': {
        'role': '신앙고백·교리문답을 다루는 사람.',
        'task': '물음과 답의 짝을 그대로 두고 다룬다.',
        'must': '문답 번호를 바꾸지 않는다.\n' + EXTERNAL_DENOM,
    },
    'REF_DICT': {
        'role': '성경사전 표제어를 다루는 사람.',
        'task': '표제어 하나의 뜻풀이를 다룬다.',
        'must': '표제어 이름은 그 언어 성경의 표기를 따른다.\n' + EXTERNAL_DENOM,
    },
    'REF_TOPIC': {
        'role': '주제 색인을 다루는 사람.',
        'task': '주제 이름과 딸린 구절 목록을 그대로 두고 다룬다.',
        'must': EXTERNAL_DENOM,
    },
    'REF_STUDY': {
        'role': '연구 자료를 쓰는 사람.',
        'task': '주어진 주제를 깊이 파고들어 적는다. 첫 줄이 제목이다.',
        'must': '줄머리 기호를 쓰지 않는다 — 번호는 1. 1) A. A) 만 쓰고 '
                '번호 뒤에 한 칸을 띄운다.\n'
                '원어는 음독(원어) 꼴로 적는다.\n'
                '구절 인용은 "본문" (약명장:절) 꼴로 적는다.',
    },
}

#: 언어 열하나 — **그 언어로 쓸 때 성경 인용을 어디서 가져오나**
#: ★ 역본은 `db_cite_gate.VERSION_OF` **한 표**에서 온다(게이트와 같은 표).
#:   두 곳에 적으면 「프롬프트는 시노드역이라 했는데 게이트는 개역한글로
#:   잰다」가 된다.
_LANG_EXTRA = {
    'KO': '사람·땅 이름도 그 역본 표기를 따른다'
          '(바빌론이 아니라 바벨론, 이집트가 아니라 애굽).',
}
_LANG_NOVER = ('성경 구절을 인용할 때에는 그 언어에서 널리 쓰이는 역본의 '
               '표기를 따른다 — 구절을 제 손으로 새로 옮기지 않는다.')


def _ver_name(conn, code):
    """역본의 사람이 읽는 이름 — 없으면 코드 그대로."""
    if conn is None:
        return code
    try:
        r = conn.execute('SELECT version_name FROM bible_version '
                         ' WHERE version_code=?', (code,)).fetchone()
    except Exception:                                     # noqa: BLE001
        return code
    nm = (r[0] if r else '') or ''
    return ('%s(%s)' % (nm, code)) if nm else code


# ══════════════════════════════════════════════════════════════════════
#  예제 프롬프트 — 화면 왼쪽 아래 「예제」 갈래가 보인다 (2026-09-29 294차 · 1.txt 1번 3))
# ══════════════════════════════════════════════════════════════════════
#
# ★★★ 사용자 지시 — 「자산 유형별 · 성격별 프롬프트 예제를 복사할 수 있게 · 이미
#   등록된 프롬프트도 함께 · **자산·업무·언어의 특성과 AI 의 습성을 고려**해서 ·
#   **적재된 것과 반려된 것을 분석**해서 만들어라」.
# ★ **재료는 실측이다** — 2026-09-29 게이트 줄 전수(3,400여 줄)에서 잦은 것:
#   ① 다듬으며 **빈 줄이 는다**(146건) ② 다듬으며 **인용 표시(「」)가 사라진다**(115)
#   ③ 옮기며 **문단 수가 어긋난다**(79) ④ 원문에 없던 **머리줄**(「January 1 — Morning」)
#   ⑤ **굵게 표시(**)** ⑥ 첫머리 겹침 「이 구절은 …」 ⑦ 묶음에서 **칸 표시를 안 붙인다**
#   ⑧ 연구 자료 **제목이 길다** ⑨ 연결설명문 반려 3건 — 두 본문을 **억지 비유로 잇는다**
#   (「궁창이 물을 갈라놓듯 … 빌레몬서의 …」) ⑩ 아랍어 **숫자 두 가지 혼용**.
#   그래서 예제의 「금지」 줄은 대부분 **실제로 난 흠**을 뒤집어 적은 것이다.
# ⚠ 이 표는 **본보기**다 — 저장소가 아니다. 복사해 오른쐹 칸에 붙여 넣으면 그때
#   층이 된다. 규칙을 늘리기보다 **짧게** 두었다(사용자가 직접 규칙을 덜어 내고
#   더 좋아진 선례 — 남은 흠은 게이트가 잡는다).

PROMPT_EXAMPLES = {
    'ALL': {
        'must': '재료에 없는 사실·이름·연도를 지어내지 않는다.\n'
                '문단 사이는 빈 줄 하나 — 두 겹으로 띄우지 않는다.\n'
                '본문만 낸다 — 제목·머리줄·마크다운(#·**)·번호 없이.',
        'never': '「이 구절은 …」·「이 글은 …」으로 시작하기\n'
                 '화살표(→)·대시(—)로 문장 잇기\n'
                 '히브리·헬라 글자를 그대로 적기(음독을 한글로만)',
        'output': '본문만. 앞뒤 인사·설명·표식 없이.',
    },
    'TASK': {
        'NEW': {
            'role': '성경 앱에 실을 글을 새로 쓰는 사람.',
            'task': '재료를 읽고 그 자리에 들어갈 글을 한 편 쓴다.',
            'must': '한 자리에 한 편만 쓴다 — 여러 안을 늘어놓지 않는다.\n'
                    '재료의 성경 본문을 그대로 되풀이하지 않고 풀어 준다.',
            'never': '재료 밖 주석·학자 이름 끌어오기\n'
                     '설교 투로 권면하기(적용은 묵상질문 칸의 몫)',
        },
        'TRANS': {
            'role': '남이 쓴 글을 다른 언어로 옮기는 사람. 저자의 글을 고치지 않는다.',
            'task': '아래 글을 「써 넣을 언어」로 옮긴다. 짜임·차례·문단 수는 그대로 둔다.',
            'must': '문단 수를 원본과 같게 — 합치거나 나누지 않는다.\n'
                    '인용 표시(「」·“”)와 괄호는 그대로 남긴다.\n'
                    '성경 구절은 「성경 인용」 칸의 역본 글자 그대로 — 새로 옮기지 않는다.\n'
                    '사람·땅 이름은 그 역본 표기를 따른다.\n'
                    # ★★★ 316차 — 구절약명 표시방법(사용자 지시)
                    '구절 **참조 약명**은 그 언어가 쓰는 표기로 옮긴다 — 재료의 '
                    '「구절약명 표기」 꼴 그대로. 장·절 숫자는 그대로 둔다.',
            'never': '원문에 없는 설명 보태기 · 있는 문장 빼기\n'
                     '제목이나 머리줄 새로 붙이기\n'
                     '원문 언어 문장을 그대로 남기기',
            'output': '옮긴 본문만.',
        },
        'EDIT': {
            'role': '이미 있는 글을 다듬는 사람. 새로 쓰지 않는다.',
            'task': '뜻과 짜임을 그대로 두고 읽기 쉽게만 다듬는다.',
            'must': '고칠 까닭이 없는 문장은 그대로 둔다.\n'
                    '인용 표시·괄호·구절 표기(창 1:1)를 하나도 잃지 않는다.\n'
                    '문단 수와 빈 줄 수를 원문과 같게 둔다.',
            'never': '내용 보태기 · 문단 합치기\n'
                     '분량을 크게 줄이기(4분의 3 아래로)\n'
                     '원문에 없던 머리줄·날짜 줄 붙이기',
        },
    },
    'KIND': {
        'VERS_DESC_LAY': {
            'role': '한 구절을 평신도에게 풀어 주는 사람.',
            'task': '이 구절이 무슨 일을 말하는지 장면과 사람으로 푼다.',
            'style': '흐르는 산문 · 합니다체\n짧은 문단 2~4개',
            'must': '앞뒤 절이 말하는 흐름 안에서 이 절의 자리를 짚는다.',
            'never': '본문을 그대로 되풀이하기(요체)\n물음을 던지고 스스로 답하기\n적용·권면 덧붙이기',
            'length': '300~600자',
            'output': '설명문 본문만.',
        },
        'VERS_QUES_LAY': {
            'role': '이 구절로 묵상하는 사람에게 물음을 건네는 사람.',
            'task': '삶에 닿는 물음 한두 개를 합니까체로 쓴다.',
            'must': '물음마다 이 구절의 낱말 하나를 붙잡는다.',
            'never': '「…하나요?」·「…할까요?」 어미\n답을 함께 적기',
            'length': '60~160자',
        },
        'VERS_QUES_EXP': {
            'role': '본문을 더 깊이 살피려는 사람에게 연구 각도를 주는 사람.',
            'task': '본문·문맥·낱말에서 파고들 물음 두셋을 쓴다.',
            'must': '원어는 한글 음독 하나만 — 「긍휼(헤세드)」 꼴.',
            'never': '교단 이름·학자 이름 끌어오기\n요약 목록으로 늘어놓기',
            'length': '120~300자',
        },
        'VERS_PRAYER': {
            'role': '이 구절을 읽고 기도하는 사람.',
            'task': '구절의 말씀을 받아 짧은 기도문을 쓴다.',
            # ★ 2026-10-13 — 금지하려고 든 보기(「…하옵소서」)가 오히려 그 꼴을 불렀다(결과의 53%가 「주옵소서」)
            'style': '1인칭 · 하나님께 드리는 말 · 합니다체로 끝맺는다(「…합니다」·「…주십시오」)',
            'never': '설명문처럼 구절을 풀기\n구절 밖 이야기',
            'length': '120~250자',
        },
        'VERS_BUNDLE': {
            'task': '한 절의 설명문·묵상질문·묵상기도(·연구질문·연구자료)를 한 번에 쓴다.',
            'must': '이번에 쓸 칸(선택한 칸)마다 표식 줄로 시작한다 — 선택하지 않은 칸은 표식째 쓰지 않는다.\n'
                    '칸 사이에 같은 문장을 되풀이하지 않는다.\n'
                    '연구질문을 썼으면 연구자료도 쓴다(둘은 짝이다).',
            'never': '표식 없이 붙여 쓰기\n칸 이름을 제 말로 바꾸기',
            'output': '표식 줄 + 그 칸 글, 칸 차례대로.',
        },
        'VERS_UNLINK': {
            'role': '이미 이어진 구절 연결이 맞는지 점검하는 사람.',
            'task': '이어진 구절마다 유지 · 해제 · 바꿈(갈래) 가운데 하나를 붙인다.',
            'must': '두 본문 어디에도 잇는 근거가 없으면 해제 — 사람이 이은 연결도 같다(실수·시험 연결이 섞여 있다).',
            'never': '애매하다고 해제하기 — 근거가 조금이라도 있으면 유지',
            'output': '줄마다 「약명 장:절 · 지금 갈래 · 판정 · 까닭」.',
        },
        'VERS_LINK': {
            'role': '성경의 구절과 구절을 잇는 사람.',
            'task': '주어진 절과 뜻으로 이어지는 다른 구절을 선택하고 갈래를 하나씩 붙인다.',
            'must': '두 본문에 실제로 있는 낱말·사건·약속으로만 — 왜 잇는가에 그 낱말을 든다.\n'
                    '[이미 이어진 구절]은 다시 내지 않는다.',
            'never': '억지 비유(궁창↔빌레몬 감옥)\n같은 장 안의 절\n갈래 둘 붙이기',
            'length': '3~8줄',
            'output': '줄마다 「약명 장:절 · 갈래코드 · 왜 잇는가 한 문장」.',
        },
        'VERS_VERS_DESC': {
            'role': '두 구절의 관계를 한 문단으로 설명하는 사람.',
            'task': '앞 구절과 뒤 구절이 어떤 갈래(연결 갈래)로 잇닿는지 1~3문장으로 쓴다.',
            # ★ 2026-10-13 — 옛 줄 「왜 이 둘인가를 첫 문장에」가 그대로 글에 찍혔다(docs/1.txt 71) —
            #   **할 일만 말하고 쓸 말을 정해 주지 않는다**
            'must': '두 본문에 실제로 있는 공통 낱말·사건·약속을 구체적으로 든다 — 첫 문장을 정해진 말로 시작하지 않는다.\n'
                    '흐름(chain)에 든 연결이면 그 흐름 안에서 이 연결이 어디쯤인지 적는다.',
            'never': '두 본문을 억지 비유로 잇기(「궁창이 물을 갈라놓듯 … 감옥의 …」)\n'
                     '문장 하나를 60자 넘게 늘이기\n'
                     '관점 접두([PRG]·[REV]) 붙이기',
            'length': '80~250자',
        },
        'PERI_DESC': {
            'role': '한 단락(이야기 한 토막)을 소개하는 사람.',
            'task': '이 단락에서 무슨 일이 일어나고 무엇이 달라지는지 서사로 쓴다.',
            'must': '절 설명문이 이미 있는 것을 되풀이하지 않는다 — 단락 전체의 흐름만.',
            'never': '절마다 한 줄씩 요약하기\n앞뒤 단락까지 끌어와 늘이기',
            'length': '400~800자',
        },
        'PERI_TITLE': {
            'task': '이 단락의 제목을 한 줄로 짓는다.',
            'must': '개역한글 소제목 어투(명사형 · 「…하심」·「…의 …」).',
            'never': '문장으로 끝내기(「…했다」)\n따옴표·기호',
            'length': '4~18자',
            'output': '제목 한 줄만.',
        },
        'CHAP_DESC': {
            'role': '한 장이 책 전체에서 어디쯤인지 보여 주는 사람(숲).',
            'task': '이 장의 흐름과 앞뒤 장 사이의 자리를 쓴다.',
            'never': '단락·절이 이미 말한 것을 되풀이하기',
            'length': '500~900자',
        },
        'BOOK_DESC': {
            'task': '성경 한 권의 개요 — 누가·언제·왜 썼고 무엇을 말하나.',
            'must': '견해가 갈리는 자리(저자·연대)는 「…로 여겨 왔다」로 적는다.',
            'never': '한 교단 견해를 정답으로 밀기',
        },
        'ENTITY_DESC': {
            'role': '인물·장소·용어 하나를 소개하는 사람.',
            'task': '성경 안에서 이것이 누구·무엇이고 왜 중요한지 두 문단으로 쓴다.',
            'must': '용례 구절 두셋을 문장 안에 개역한글 표기로.',
            'never': '사전 항목처럼 항목 나열\n원어 글자 노출',
            'length': '300~700자',
        },
        'ENTITY_NAME': {
            'task': '이름 하나 — 「한국어 이름 · 음독」 꼴(「인애 · 헤세드」).',
            'never': '문장 꼴 · 설명 덧붙이기',
            'output': '이름만.',
        },
        'BOOK_INTRO': {
            'role': '서재의 책 한 권을 소개하는 사람.',
            'task': '무슨 책이고 어떻게 읽으면 좋은지 두세 문단 + 「▸ 출처」 블록.',
            'must': '「그대로 붙일 출처 블록」은 글자 하나 안 고치고 맨 끝에 붙인다.',
            'never': '작업 과정(재적재·OCR) 적기\n출처의 기관 이름·연도 바꾸기',
        },
        'BOOK_TASTE': {
            'task': '맛보기 조각(A4 한 장)을 옮긴다 — 문단 수 그대로.',
            'must': '「문단(줄) 수 — 이대로 지킨다」 줄의 수를 지킨다.',
            'never': '표식(⟨맛보기 여기까지⟩) 적기 — 도구가 붙인다',
        },
        'BOOK_UNIT': {
            'role': '옛 저자의 글을 오늘 독자에게 옮기는 사람.',
            'task': '한 편을 옮긴다 — 저자의 목소리(부르는 말·되묻는 말)를 지킨다.',
            'style': '설교체면 설교체로 — 문장을 잘게 끊어 리듬을 지우지 않는다',
            'must': '수사 의문문은 의문문으로 남긴다.\n출처 줄은 적지 않는다 — 적재할 때 도구가 붙인다.',
            'never': '옛말투 흉내(하였도다·이니라)\n날짜·머리줄(「1월 1일 아침」) 새로 붙이기',
        },
        'COMMENTARY': {
            'role': '18~19세기 주석을 오늘 말로 옮기는 사람.',
            'task': '한 항목을 옮긴다 — 인용 구절·상호 참조도 빼지 않고 이 언어로 옮긴다. 「See Barnes "Mt 6:2"」는 「마 6:2 주석 참조」, 「{a} "And Jesus" Mr 13:1」은 「{a} "예수께서" 막 13:1」처럼. 영어 낱말·영어 약명을 남기지 않는다(Mt=마태복음, Mr=마가복음, Lu=누가복음).',
            'must': '주석가의 판단을 고치거나 덧붙이지 않는다.\n원어 낱말은 음독으로.',
            'never': '길다고 요약하기\n주석가가 든 예를 빼기',
        },
        'REF_CATE': {
            'task': '문답 한 항목(물음·답)을 옮긴다 — 물음은 물음으로, 답은 답으로.',
            'must': '증거 구절 표기(롬 3:23)는 그대로.',
            'never': '답을 풀어 설명 보태기',
        },
        'REF_DICT': {
            'task': '사전 한 항목을 옮긴다 — 표제어·뜻·용례 차례 그대로.',
            'never': '표제어를 뜻으로 바꾸기\n용례 구절 빼기',
        },
        'REF_TOPIC': {
            'task': '주제 색인 한 항목 — 소제목과 구절 목록의 짜임 그대로.',
            'never': '구절 목록을 문장으로 풀기',
        },
        'REF_STUDY': {
            'role': '연구 자료를 쓰는 사람.',
            'task': '첫 줄은 제목(30자 안), 그 아래 번호 붙인 절로 논지를 쓴다.',
            # ★ 314차 — 구절 표기. 모양은 `db_study_gate` 가 잡는다.
            'must': '번호는 1. 1) A. A) 만 — 번호 뒤 한 칸.\n'
                    '인용은 "본문" (약명장:절) 꼴.\n'
                    '원어는 음독(원어) 꼴.\n'
                    '구절은 책·장·절을 다 적는다 — 「신 15:4」·「신명기 15장 4절」. '
                    '여러 곳은 각각 다 적는다(「신 15:4; 15:11」).',
            'never': '굵게·머리글(#)·표 · 줄머리 기호(-·•)\n'
                     '제목만 있고 본문 없는 절\n'
                     '장만 가리키는 참조(「레위기 21장」) — 절까지 적는다\n'
                     '절의 개수를 「39절」로 적기 — 「39곳」으로 적는다',
            'length': '400자 이상(많아도 된다)',
        },
    },
    'LANG': {
        'KO': {
            'style': '합니다체 산문 · 물음은 「합니까?」',
            'cite': '개역한글 본문 그대로 — 바벨론·애굽처럼 그 표기를 따른다.',
            'never': '「…하나요?」·「…할까요?」\n번역투(「…에 의해 …되어진다」)',
        },
        'EN': {
            'style': 'Plain modern English · short sentences · no archaic forms (thee, hath)',
            'cite': 'Quote Scripture from the Berean Standard Bible (BSB) verbatim; names as BSB spells them.',
            'never': 'Adding headings or bold\nParaphrasing a quoted verse',
        },
        'JA': {
            'style': 'です・ます体 · 一文を短く',
            'cite': '基準となる訳本がまだ無い — 広く読まれる訳の表記に従い、自分で新たに訳さない。章節は算用数字。',
            'never': '見出し・太字を付ける\n原文の段落をまとめる',
        },
        'ZH': {
            'style': '简体 · 书面语 · 句子简短',
            'cite': '经文引用一律照录和合本（简体），不自行翻译；人名地名从和合本。',
        },
        'ZHT': {
            'style': '繁體 · 書面語',
            'cite': '經文引用一律照錄和合本（繁體），不自行翻譯；人名地名從和合本。',
        },
        'AR': {
            'style': 'فصحى مبسّطة · جمل قصيرة',
            'cite': 'اقتبس الآيات من ترجمة فان دايك كما هي حرفيًا، والأسماء بحسب رسمها فيها.',
            'must': '숫자는 한 가지로만 — 아라비아 숫자(٠-٩)와 서양 숫자(0-9)를 한 글에 섞지 않는다.',
            'never': '절 번호를 두 가지 숫자로 적기\n서양식 문장부호(;)와 아랍식 부호 섞기',
        },
        'RU': {
            'style': 'Простой литературный русский · без архаизмов',
            'cite': 'Цитаты из Писания — дословно по Синодальному переводу; имена и названия по нему же.',
            'never': 'Пересказывать стих своими словами',
        },
        'DE': {'cite': 'Bibelzitate wörtlich nach der Elberfelder Übersetzung; Namen wie dort geschrieben.'},
        'FR': {'cite': 'Citer l’Écriture mot pour mot d’après la version Segond ; noms propres selon cette version.'},
        'ES': {'cite': 'Citar la Escritura literalmente según la Reina-Valera; nombres propios según esa versión.'},
        'PT': {'cite': 'Citar a Escritura literalmente conforme a versão em uso; nomes próprios conforme ela.'},
    },
}


def seed_layers(conn=None):
    """**구성요소 층 34줄** — `[(kind, scope, task, lang, part, body)]`.

    ⚠ 조합(660)을 만들지 않는다 — `compose_prompt` 가 합친다.
    """
    import db_cite_gate as CG
    out = []
    for task in ('NEW', 'TRANS', 'EDIT'):
        for part, body in _LAYER_TASK[task].items():
            out.append(('', '', task, '', part, body))
    for kind, parts in _LAYER_KIND.items():
        for part, body in parts.items():
            out.append((kind, '', '', '', part, body))
    for lg in ui_langs():
        ver = CG.VERSION_OF.get(lg)
        if ver:
            body = ('성경 구절을 인용할 때에는 %s의 본문을 그대로 쓴다 — '
                    '구절을 새로 옮기지 않는다.' % _ver_name(conn, ver))
        else:
            body = _LANG_NOVER
        if _LANG_EXTRA.get(lg):
            body += NL_ + _LANG_EXTRA[lg]
        # ★ 2026-09-29 — **「성경 인용」 성격**으로(옛 `must`). 한 줄짜리라
        #   쌓이지 않고 좁은 층이 이긴다(책 하나가 다른 역본을 쓸 수 있다).
        out.append(('', '', '', lg, 'cite', body))
    return out


def layer_groups(conn=None):
    """씨앗을 **콤보 셋**으로 갈라 본다 — `{'업무':[…], '자산':[…], '언어':[…]}`."""
    g = {'업무': [], '자산': [], '언어': []}
    for row in seed_layers(conn):
        kind, _sc, task, lang, _p, _b = row
        g['자산' if kind else ('언어' if lang else '업무')].append(row)
    return g


def apply_layers(conn, force=False):
    """씨앗을 담는다 — **없는 칸만**. 되돌아온 값 = `(새로, 그대로, 옮김)`.

    ⚠⚠ **이미 적힌 칸은 안 덮는다**(§32차) — 사람이 고친 글이 있을 수 있다.
      덮으려면 `force=True`.
    ★★★ **언어 층을 `task='TRANS'` 에서 `task=''` 로 옮긴다** — 그 규칙은
      새로 쓸 때도 다듬을 때도 똑같이 참이다. **글은 그대로 옮긴다**
      (다시 지으면 사람이 고쳐 둔 것을 잃는다).
    """
    init_prompt_schema(conn)
    moved = 0
    for lg in ui_langs():
        # ⓐ 옛 자리 둘 — `TRANS·must`(16-2 첫 판) · `''·must`(16-2 둘째 판)
        #   → **`''·cite`**(294차). 글은 글자 그대로 옮긴다.
        for tk_ in ('TRANS', ''):
            old = conn.execute(
                "SELECT body FROM sys_ai_prompt WHERE kind='' AND scope=''"
                "  AND task=? AND lang=? AND part='must'", (tk_, lg)).fetchone()
            if not old:
                continue
            cur = conn.execute(
                "SELECT 1 FROM sys_ai_prompt WHERE kind='' AND scope=''"
                "  AND task='' AND lang=? AND part='cite'", (lg,)).fetchone()
            if not cur:
                set_layer(conn, '', '', '', lg, 'cite', old[0])
            conn.execute("DELETE FROM sys_ai_prompt WHERE kind='' AND scope=''"
                         "  AND task=? AND lang=? AND part='must'", (tk_, lg))
            moved += 1
    conn.commit()

    made = kept = 0
    for kind, sc, task, lang, part, body in seed_layers(conn):
        cur = get_layer(conn, kind, sc, task, lang).get(part)
        if cur and not force:
            kept += 1
            continue
        set_layer(conn, kind, sc, task, lang, part, body)
        made += 1
    return made, kept, moved


def seed_profiles():
    """씨앗 — `(열쇠, 이름, 자산, 업무, 범위, 프롬프트dict, 게이트, 메모)`."""
    return [
        # ★★★ **구절 묶음** — 한 절의 글을 한 번에 (2026-09-23 사용자 지시)
        ('절 묶음 — 전체', 'VERS_BUNDLE', 'NEW', '', {
            'role': '성경 앱의 구절 글을 쓰는 사람. 읽는 이는 평신도다.',
            'task': '주어진 절 하나에 대해 **선택한 칸만** 채운다. '
                    '칸마다 답할 물음이 다르다.',
            'style': _KO_STYLE,
            'must': [
                '아래 가운데 **이번에 쓸 칸으로 선택한 것만** 쓴다.',
                '[설명문] 이 구절이 무슨 일을 말하는가 — 장면과 사람으로. '
                '300~600자, 2~4개의 짧은 문단',
                '[묵상질문] 나는 어떻게 살 것인가 — 한두 물음, 80~150자',
                '[묵상기도] 이 본문으로 무엇을 구할 것인가 — 100~200자',
                '[연구질문] 무엇을 더 파고들 것인가 — 아래 「연구질문」 설명을 볼 것',
                '[연구자료] 연구질문에 답하는 글 — 아래 「연구자료」 설명을 볼 것',
                '칸 표시는 [설명문] 처럼 대괄호로 줄 맨 앞에 적는다',
            ],
            'never': _NEVER_DENOM + [
                '앞 칸에서 한 말을 뒤 칸에서 되풀이하기',
                '본문을 그대로 다시 적는 재진술',
            ],
            'terms': [
                '연구질문 = **답을 찾으러 가야 하는 물음**이다. '
                '답이 본문에 그대로 있으면 연구질문이 아니고, '
                '「나는 ~하고 있습니까」로 끝나면 그것은 묵상질문이다.',
                '연구질문 갈래(걸리는 것만 · 없으면 안 쓴다) — '
                '① 원어가 갈린다(소리는 같은데 다른 낱말 · 같은 낱말이 다른 '
                '문맥에서 뒤집힌다) ② 단락의 짜임(되풀이·점층·대조·머리글자) '
                '③ 역사·문화 배경(제도·직분·지명·관습) ④ 다른 본문과 이어진다 '
                '⑤ 겉보기에 어긋나는 두 본문 ⑥ 인물의 속내를 본문 단서로 재구성',
                '연구질문은 **개수를 채우지 않는다** — 0개도 정답이고 '
                '걸리는 것이 여럿이면 여럿 쓴다.',
                '연구질문은 **물음 한 줄로 시작하고**(라벨을 붙이지 않는다) '
                '그 아래 두 줄을 덧붙인다 — 「참고 : 」 어느 절의 어느 낱말·표현인가'
                '(원어가 재료에 있으면 스트롱 번호), 「연구방향 : 」 무엇을 봐야 답할 수 있는가.',
                # ★ 연구자료 — **모양은 게이트(`db_study_gate`)가 잡는다.**
                #   프롬프트에는 AI 가 모를 수 없는 것만 적는다. 사용자가
                #   이 프로필에서 손수 규칙을 덜어 낸 결을 따른다(실측).
                # ★★★ 사용자 2번 — 「AI가 연구질문을 선택했다는 것은
                #   각각의 연구질문에 대해서 어느 정도 연구자료를
                #   작성할 방향을 알고 있을 것」 ⇒ **둘은 짝이다.**
                #   ⚠ 「써도 된다」로 적었더니 모델이 한 번도 안 썼다(실측).
                '연구자료 = **연구질문에 실제로 답하는 글**이다. '
                '**연구질문을 썼으면 연구자료도 쓴다. 안 썼으면 둘 다 안 쓴다.**',
            ] + _NOTE_TERMS,
            'example': '[설명문]\n…\n\n[묵상질문]\n…\n\n[묵상기도]\n…'
                       '\n\n[연구질문]\n…무엇이 …합니까?\n참고 : …\n연구방향 : …'
                       '\n\n[연구자료]\n제목 한 줄\n1. 첫 갈래\n…\n'
                       '"…" (창1:3)\n2. 둘째 갈래\n…',
            'output': '위 칸들만. 다른 머리말·맺음말 없이. ⚠ 재료로 준 [구절]·[본문] 따위를 다시 적지 않는다.',
        }, ['db_vers_gate', 'db_vers_style'],
         '칸의 정의는 「무엇을 답하는가」다 — 어체가 아니다. '
         '되풀이 금지는 한 줄만 적고 나머지는 gate_bundle 이 수로 잡는다.'),

        ('절 묶음 — 번역', 'VERS_BUNDLE', 'TRANS', '', {
            'role': '성경 앱의 구절 글을 다른 언어로 옮기는 사람.',
            'task': '아래 글을 「써 넣을 언어」로 옮긴다. 칸 구성은 그대로 둔다.',
            'style': ['그 언어의 자연스러운 구어체로 쓴다(번역투 금지)',
                      '읽는 이는 그 언어의 평신도다',
                      # ⚠ 실측 — 영어 번역이 em dash(—)를 여섯 자리에 썼다.
                      #   우리 글의 공통 규칙이라 **어느 언어에서나** 지킨다.
                      '대시(—, –) 대신 쉼표·마침표로 끊는다'],
            'must': [
                '칸 표시([설명문]·[묵상질문]·[묵상기도]·[연구질문]·[연구자료])'
                '**만** 한국어 그대로 둔다 — 그것은 글이 아니라 자리 표시다',
                '그 밖의 **모든 글은 빠짐없이 옮긴다** — 연구질문 칸 안의 '
                '「물음·근거·답하려면」도 그 언어의 말로 옮긴다',
                '성경 인용은 그 언어의 널리 쓰이는 역본 표현을 따른다',
                # ★★★ 315차 사용자 지시 — 「다국어 모드의 구절약명 표시방식에
                #   따라서 번역해야 표시할 때도 제대로 표시될 것이다」.
                #   ⚠ 약명을 **원문 그대로 두면** 그 언어 화면에서 못 읽는다
                #     (읽는 문이 `book_names(그 언어)` 를 본다).
                '구절 **참조 약명**은 그 언어가 쓰는 표기로 옮긴다 — 재료의 '
                '「구절약명 표기」 꼴 그대로. 장·절 숫자는 그대로 둔다.',
                '사람·땅 이름은 그 언어의 관용 표기로',
            ],
            'never': [
                '원문에 없는 칸을 새로 짓기 — 연구질문·연구자료가 없으면 '
                '없는 대로 둔다',
                '원문에 없는 설명·적용을 보태기',
                '원문에 있는 성경 인용·괄호 보충을 빼기',
            ],
            'output': '옮긴 글 전체. 칸 표시를 그대로 살려서. ⚠ 재료로 준 [구절]·[본문] 따위를 다시 적지 않는다.',
        }, ['db_vers_gate'],
         '번역은 창작이 아니다 — 칸을 더하거나 빼지 않는다(booktrans.md).'),

        ('절 묶음 — 다듬기', 'VERS_BUNDLE', 'EDIT', '', {
            'role': '이미 쓴 구절 글을 다듬는 사람.',
            'task': '지금 글을 현대 신자가 묵상하며 읽기 편한 자연스러운 '
                    '어투로 다듬는다. 칸 구성은 그대로 둔다.',
            'style': _KO_STYLE,
            'must': [
                '칸 표시([설명문] 따위)를 그대로 둔다',
                '사람·땅 이름은 개역한글 표기로 바꾼다',
                # ★ 사용자 지시(1.txt 16-1 · 3) — 「다듬기 : 기존 설명문을
                #   수정하더라도, 필요한 연구질문을 새로 추가하고,
                #   **연구자료를 새로 작성**하는 기능을 추가하라」
                '[연구질문]은 있으면 그대로 다듬고 없으면 새로 써도 된다'
                '(걸리는 것이 있을 때만).',
                '**[연구질문]이 있으면 [연구자료]를 쓴다** — 그 물음에 '
                '답하는 글이다. 연구질문이 없으면 둘 다 안 쓴다.',
                '⚠ 쓸 것이 없으면 **그 칸 자체를 적지 않는다** — '
                '「없음」이라고 적지 않는다.',
            ],
            # ⚠ 다듬기에서도 **연구자료를 새로 쓸 수 있으므로** 그 칸의
            #   서식 규칙이 여기에도 있어야 한다. 없으면 새로 쓴 글만
            #   서식이 갈린다(신규 작성 프로필과 같은 문장을 쓴다).
            'terms': _NOTE_TERMS,
            'never': _NEVER_DENOM + [
                '있던 칸을 통째로 빼기',
                '성경 인용의 따옴표를 풀어 본문에 녹이기',
                '괄호 안 보충 설명을 통째로 빼고 두루뭉술하게 바꾸기 '
                '⚠ 표기를 개역한글로 고치는 것은 위 [반드시] 대로 한다 — '
                '이름을 지우지 말라는 뜻이지 표기를 그대로 두라는 뜻이 아니다',
            ],
            'output': '다듬은 글 전체. 칸 표시를 그대로 살려서.',
        }, ['db_vers_gate'],
         '다듬기는 「새 흠」이 아니라 「잃은 것」으로 망가진다 — '
         'edit_loss 가 앞글과 견준다.'),

        ('절 설명문 (일반) — 전체', 'VERS_DESC_LAY', 'NEW', '', {
            'role': '성경 구절 설명문을 쓰는 사람. 읽는 이는 평신도다.',
            'task': '주어진 절 하나를 평이한 한국어로 설명한다.',
            'style': _KO_STYLE + ['2~4개의 짧은 문단'],
            'must': ['그 절이 무엇을 말하는지 먼저 말한다',
                     '앞뒤 문맥이 필요하면 한 줄로 짚는다'],
            'never': _NEVER_DENOM + ['본문을 그대로 다시 적는 재진술'],
            'length': {'min': 300, 'max': 600},
            'output': '설명문 본문만. 제목·머리표 없이.',
        }, ['db_vers_gate', 'db_vers_style'],
         '§28-11 서술 표준 · lay.md 에서 옮겼다(지어낸 규칙 없음).'),

        ('절 설명문 (일반) — 다듬기', 'VERS_DESC_LAY', 'EDIT', '', {
            'role': '이미 있는 구절 설명문을 **다듬는** 사람. 새로 쓰지 않는다.',
            'task': '주어진 글에서 규칙에 어긋난 곳만 고친다.',
            'style': _KO_STYLE,
            'must': ['★ 고칠 곳만 고치고 **나머지는 글자 그대로 둔다** — '
                     '뜻·차례·문단을 바꾸지 않는다',
                     '사람·땅 이름은 개역한글 표기로 바꾼다'
                     '(바빌론→바벨론, 이집트→애굽, 유프라테스→유브라데)',
                     '대시(—)를 쓰지 않고 문장으로 푼다',
                     '물음으로 끝나면 설명문으로 바꾼다'],
            'never': _NEVER_DENOM + ['내용을 새로 지어 보태기',
                                     '문단을 합치거나 나누기',
                                     '고칠 것이 없는데 문장을 바꾸기',
                                     '괄호 안 설명과 성경 참조(예 「(행 8장)」)를 지우지 않는다 — 고칠 낱말만 고치고 괄호는 그대로 둔다', '원문에 없던 빈 줄을 새로 넣지 않는다(화면에서 간격이 두 배가 된다)'],
            'length': {'min': 200, 'max': 900},
            'output': '다듬은 글 본문만. 고친 자리를 따로 적지 않는다.',
        }, ['db_vers_gate', 'db_vers_style'],
         '⚠ 다듬기는 **새로 쓰는 것이 아니다** — 전후를 견줄 수 있어야 한다.'),

        ('도서 본문 — 다듬기', 'BOOK_UNIT', 'EDIT', '', {
            'role': '이미 옮겨 둔 한국어 번역을 다듬는 사람.',
            'task': '원본(영어)과 나란히 놓고, 뜻은 그대로 두면서 '
                    '오늘의 신자가 읽기 편한 자연스러운 우리말로 다듬는다.',
            'style': _KO_STYLE,
            'must': ['원본에 있는 것을 빼지 않고 없는 것을 넣지 않는다',
                     '어색한 번역투를 자연스러운 우리말로 고쳐 쓴다',
                     '저자의 논지 차례와 문단 구성을 그대로 둔다',
                     '사람·땅 이름은 개역한글 표기를 따른다'],
            'never': ['원문에 없는 설명·적용을 보태기',      # ★ 2026-10-22 외부 저작 — 교단 중립 줄을 안 단다
                      '문단을 합치거나 나누기',
                      '성경 인용과 그 출처 표기를 지우기'],
            'length': {'min': 200, 'max': 20000},
            'output': '다듬은 한국어 본문만.',
        }, ['db_vers_style'],
         '⚠ 번역은 창작이 아니다(booktrans.md) — 「자연스럽게」가 원문에서 '
         '멀어지는 쪽으로 가면 안 된다. 재료에 원본이 함께 실린다.'),

        ('절 설명문 (일반) — 시편', 'VERS_DESC_LAY', 'NEW', '19', {
            'role': '시편 한 절을 설명하는 사람. 읽는 이는 평신도다.',
            'task': '시가(詩歌)임을 전제로 그 절을 설명한다.',
            'style': _KO_STYLE + ['시의 결을 살린다 — 논증처럼 쓰지 않는다'],
            'must': ['평행법(같은 말을 두 번 다르게)이 있으면 그것을 짚는다',
                     '표제가 있으면 그 자리도 본문임을 안다'],
            'never': _NEVER_DENOM + ['산문 본문처럼 사건 순서로 풀기'],
            'length': {'min': 300, 'max': 600},
            'output': '설명문 본문만.',
        }, ['db_vers_gate', 'db_vers_style'],
         '창세기와 시편이 달라야 한다는 사용자 지시의 첫 자리.'),

        ('절 설명문 (일반) — 창세기', 'VERS_DESC_LAY', 'NEW', '1', {
            'role': '창세기 한 절을 설명하는 사람. 읽는 이는 평신도다.',
            'task': '이야기(서사)임을 전제로 그 절을 설명한다.',
            'style': _KO_STYLE + ['장면이 보이게 쓴다'],
            'must': ['누가 무엇을 했는지 먼저 세운다',
                     '뒤에 올 일을 미리 말해 버리지 않는다'],
            'never': _NEVER_DENOM,
            'length': {'min': 300, 'max': 600},
            'output': '설명문 본문만.',
        }, ['db_vers_gate', 'db_vers_style'], ''),

        ('절 설명문 — 번역 (전체)', 'VERS_DESC_LAY', 'TRANS', '', {
            'role': '이미 쓰인 한국어 설명문을 다른 언어로 옮기는 번역자.',
            'task': '뜻과 문단 구성을 그대로 두고 그 언어로 옮긴다.',
            'style': ['그 언어의 자연스러운 말', '원문의 문단 수를 지킨다'],
            'must': ['성경 인용은 그 언어의 표준 역본 표기를 따른다',
                     '고유명사는 그 언어의 관용 표기로'],
            'never': ['요약하거나 늘리기', '없는 적용을 덧붙이기',
                      '문단을 합치거나 나누기'],
            'output': '번역문 본문만.',
            'note': 'booktrans.md — 번역은 창작이 아니다.',
        }, ['db_rewrite_gate'],
         '길이비 0.85~1.15 · 문단 수 · 물음표 수는 게이트가 잰다.'),

        # ★ **도서 소개문 — 신규 작성**(2026-09-25 사용자 물음 「신규작성할
        #   수 있는가」 — 그전에는 프로필이 없어 `create_job` 이 거부했다).
        #   ⚠ 출처 블록은 **재료로 준 글자를 그대로** 붙인다. 지어내면
        #     저작권 고지가 다른 자료를 가리킨다(게이트가 글자로 잰다).
        ('도서 소개문 — 신규 작성', 'BOOK_INTRO', 'NEW', '', {
            'role': '앱에 실린 책이 어떤 책인지 짧게 소개하는 사람.',
            'task': '준 재료만 보고 소개문을 쓴다. '
                    '개요 · 체계 · 주요내용 세 문단이다.',
            'style': ['흐르는 산문 합니다체',
                      '읽고 어떤 책인지 짐작할 수 있게'],
            'must': ['재료에 있는 것만 쓴다',
                     '「그대로 붙일 출처 블록」을 글자 하나 안 고치고 맨 끝에'],
            'never': ['재료에 없는 줄거리·평가를 지어내기',
                      '작업 진행과정(적재·추출 따위)',
                      '문단 사이 빈 줄'],
            'output': '소개문 전체. 문단들 다음에 출처 블록.',
        }, ['db_book_desc'],
         '문단 수 · 출처 블록 글자 일치는 db_book_desc.check_new 가 잰다.'),

        # ★ **도서 소개문 — 번역**(2026-09-25 · 1.txt 16-3 ⑤).
        #   ⚠ 얇다 — 문단·출처 규칙과 언어별 기준 역본은 **층**이
        #     들고 있다(`sys_ai_prompt`). 두 곳에 적으면 갈린다.
        # ★ **맛보기 조각 — 번역 / 다듬기**(2026-09-25).
        #   ⚠ 조각 끝의 표식(⟨맛보기 여기까지⟩)은 **도구가 붙인다** — AI 가
        #     적으면 두 번 붙거나 자리가 어긋난다(게이트가 잡는다).
        ('맛보기 조각 — 번역', 'BOOK_TASTE', 'TRANS', '', {
            'role': '책의 첫머리 한 쪽을 옮기는 번역자.',
            'task': '아래 글을 「써 넣을 언어」로 옮긴다. '
                    '맛보기라 이 대목만 읽는 사람이 있다는 것을 생각한다.',
            'style': ['저자의 목소리를 살린다', '문단을 그대로 둔다'],
            'never': ['요약', '문단 합치거나 나누기',
                      '맛보기 표식(⟨…⟩)을 적기',
                      '끊긴 자리를 이어 붙이려고 지어내기'],
            'output': '옮긴 글 본문만.',
        }, ['booktrans_gate'],
         '조각은 A4 한 장이다 — 자르는 일도 표식도 db_pack_taste 가 한다.'),

        ('맛보기 조각 — 다듬기', 'BOOK_TASTE', 'EDIT', '', {
            'role': '이미 옮긴 맛보기 조각을 다듬는 사람.',
            'task': '아래 글을 읽기 좋게 다듬는다. 뜻과 문단은 그대로 둔다.',
            'never': ['없던 내용 보태기', '맛보기 표식(⟨…⟩)을 적기'],
            'output': '다듬은 글 본문만.',
        }, ['booktrans_gate'],
         '길이비·인용은 db_ai_run 의 BOOK_TASTE 게이트가 잰다.'),

        # ★ **도서 소개문 — 다듬기** — 업무 셋이 다 열려 있어야 한다.
        #   ⚠ 출처 블록은 여기서도 **손대지 않는다**.
        ('도서 소개문 — 다듬기', 'BOOK_INTRO', 'EDIT', '', {
            'role': '이미 있는 도서 소개문을 다듬는 사람.',
            'task': '아래 소개문을 읽기 좋게 다듬는다. '
                    '짜임과 사실은 그대로 둔다.',
            'never': ['없던 사실을 보태기', '문단 합치거나 나누기',
                      '「▸ 출처」 블록 고치기'],
            'output': '다듬은 소개문 전체. 문단부터 출처 블록까지.',
        }, ['db_book_desc'],
         '문단 수 · 출처는 db_book_desc.check_text 가 잰다.'),

        ('도서 소개문 — 번역', 'BOOK_INTRO', 'TRANS', '', {
            'role': '앱에 실린 책을 소개하는 짧은 글을 옮기는 사람.',
            'task': '아래 소개문을 「써 넣을 언어」로 옮긴다. '
                    '짜임은 그대로 둔다.',
            'output': '옮긴 소개문 전체. 문단부터 출처 블록까지.',
        }, ['db_book_desc'],
         '문단 수 · 「▸ 출처」 블록 · 기관 이름과 판본 연도는 '
         'db_book_desc.check_text 가 잰다.'),

        ('구절연결 설명문 — 전체', 'VERS_VERS_DESC', 'NEW', '', {
            'role': '두 구절의 관계를 설명하는 사람.',
            'task': '연결된 두 절의 관계를 한 문단으로 설명한다.',
            'style': ['흐르는 산문 합니다체 1~3문장',
                      '중요한 연결은 3~4문장까지'],
            # ★ 2026-10-13 — 옛 줄 「무엇이 무엇으로 자라는지를 말한다」 → 실측 37%가 「…자라납니다」로 끝났다
            'must': ['두 구절에 나오는 사람·사건·낱말을 이름으로 들어 무엇이 새로 더해졌는지 적는다 — 「본문」이라는 말로 두 구절을 가리키지 않고, 문장마다 다른 말로 끝맺는다'],
            'never': ['[PRG 흐름] 같은 머리표', '화살표(→ ⇒)·대시',
                      '원어 문자를 글에 적기', '명사화 종결(…됨/…화.)'],
            'output': '설명문 본문만. 개행 없음.',
        }, [], '§28-6 — 2026-08-19 사용자 승인 문체.'),

        ('도서 본문 — 스펄전', 'BOOK_UNIT', 'TRANS', '1', {
            'role': '스펄전의 글을 우리말로 옮기는 번역자.',
            'task': '설교체 원문을 뜻과 기세를 지켜 옮긴다.',
            'style': ['설교하는 목소리를 살린다 — 부르는 말·되묻는 말',
                      '문장을 짧게 끊되 리듬을 지운다'],
            'must': ['수사 의문문은 의문문으로 남긴다',
                     '성경 인용은 개역한글 표기'],
            'never': ['요약', '문단 합치기', '옛말투 흉내'],
            'output': '번역문 본문만.',
        }, ['booktrans_gate'],
         '스펄전과 마이어의 번역 문체를 갈라야 한다는 사용자 지시.'),

        ('도서 본문 — 마이어', 'BOOK_UNIT', 'TRANS', '7', {
            'role': '메이어의 묵상집을 우리말로 옮기는 번역자.',
            'task': '한 편의 짧은 묵상을 뜻 그대로 옮긴다.',
            'style': ['조용히 권하는 목소리', '한 편이 한 호흡으로 읽히게'],
            'must': ['제사 구절의 표기를 본문과 맞춘다',
                     '성경 인용은 개역한글 표기'],
            'never': ['설교조로 키우기', '요약', '문단 합치기'],
            'output': '번역문 본문만.',
        }, ['booktrans_gate'], ''),

        # ★★★ **자료집 글 — 연구자료 번역·다듬기** (2026-09-24 · 1.txt 16-1 · 3)
        #   사용자 「연구자료 전체를 **다국어 모드로 번역**하는 것이 좋을 것
        #   같다. 네 판단을 따르겠다」 ⇒ **전체 번역이 맞다** — 연구자료는
        #   구절에만 걸리는 것이 아니라 **용어에도 걸린다**(사용자가 그 까닭을
        #   먼저 적었다). 구절 설명문 번역을 따라다니게 하면 용어에 걸린 글은
        #   영영 안 옮겨진다.
        #   ⚠⚠⚠ **프로필이 하나도 없어 이 경로가 실제로는 막혀 있었다**
        #     (실측 — `create_job` 이 그 앞에서 거부한다). 화면에 범위는
        #     보이는데 누르면 안 되는 자리였다(§0-1).
        #   ⚠ **범위를 비워 둔다** — 자료집 번호는 DB 마다 다를 수 있어
        #     씨앗에 박으면 안 된다. `pick_profile` 이 좁은 것을 먼저 보고
        #     없으면 전체로 떨어지므로, 나중에 자료집별 프로필을 더할 수 있다.
        # ★ 갈래 넷이 **같은 프롬프트 글**을 나눠 쓴다(아래 `for`)
        ('자료집 글 — 번역', '@REF@', 'TRANS', '', {
            'role': '자료집 글을 다른 언어로 옮기는 사람.',
            'task': '아래 글을 「써 넣을 언어」로 옮긴다. 짜임은 그대로 둔다.',
            'style': ['그 언어의 자연스러운 글말로 쓴다(번역투 금지)',
                      '읽는 이는 그 언어의 평신도다',
                      '대시(—, –) 대신 쉼표·마침표로 끊는다'],
            'must': [
                '**첫 줄은 제목**이다 — 제목도 옮기고 한 줄로 둔다',
                '차례 표시(1. 1) A. A))와 줄 나눔을 **그대로** 옮긴다',
                '원어는 **그 언어의 음독(원어)** 꼴로 — 오르(אור)',
                '성경 인용은 **"본문" (약명장:절)** 꼴을 지킨다 — '
                '본문은 그 언어의 기준 역본 표현, 약명은 그 언어 표기',
            ],
            'never': ['원문에 없는 설명을 보태기', '문단·차례를 합치거나 빼기',
                      '굵게·표·머리글 같은 서식을 새로 넣기'],
            'output': '옮긴 글 전체. 첫 줄 제목부터.',
        }, ['db_study_gate'],
         '연구자료는 구절만이 아니라 용어에도 걸린다 — 그래서 전체를 옮긴다.'),

        ('자료집 글 — 다듬기', '@REF@', 'EDIT', '', {
            'role': '이미 쓴 자료집 글을 다듬는 사람.',
            'task': '지금 글을 읽기 편한 자연스러운 어투로 다듬는다. '
                    '짜임과 차례는 그대로 둔다.',
            'style': _KO_STYLE,
            'must': ['첫 줄 제목을 그대로 둔다(뜻이 흐리면 다듬되 한 줄로)',
                     '차례 표시(1. 1) A. A))를 그대로 둔다',
                     '사람·땅 이름은 개역한글 표기로 바꾼다'],
            'never': _NEVER_DENOM + [
                '있던 갈래를 통째로 빼기',
                '성경 인용 줄에서 역본 표시를 빼기',
                '원어의 음독을 빼고 원어만 남기기',
            ],
            'output': '다듬은 글 전체. 첫 줄 제목부터.',
        }, ['db_study_gate'],
         '⚠ 수입 자료집(문답·사전)의 원문은 `edit_blocked` 가 막는다 — '
         '이 프로필이 실제로 쓰이는 곳은 우리 글(연구 자료)과 번역문이다.'),
    ]


# 자료집 씨앗의 자리표 — 갈래 넷이 같은 글을 나눠 쓴다
REF_SEED_MARK = '@REF@'


def _spread_ref(rows):
    """`@REF@` 한 줄을 **갈래 넷**으로 편다 — 이름 뒤에 갈래를 적는다.

    ⚠ 네 벌을 손으로 적으면 한 벌만 고쳐지는 날이 온다.
    """
    out = []
    for r in rows:
        if r[1] != REF_SEED_MARK:
            out.append(r)
            continue
        for kind in ('REF_CATE', 'REF_DICT', 'REF_TOPIC', 'REF_STUDY'):
            nm = '%s (%s)' % (r[0], ASSET[kind]['name'].split('—')[-1].strip())
            body = r[4]
            if kind in EXTERNAL_KINDS and isinstance(body, dict) and body.get('never'):
                # ★ 2026-10-22 수입 자료집(문답·사전·주제 색인)은 남의 글 — 교단 중립 줄을 빼고 예외 줄을 단다
                body = dict(body, never=[x for x in body['never'] if x not in _NEVER_DENOM],
                            must=list(body.get('must') or []) + [EXTERNAL_DENOM])
            out.append((nm, kind) + (r[2], r[3], body) + tuple(r[5:]))
    return out


def seed(conn, force=False):
    """씨앗을 넣는다(멱등). 이미 있으면 **건드리지 않는다**.

    ⚠ `force` 없이는 덮어쓰지 않는다 — 사람이 고친 프롬프트를 다음 실행이
      되돌리면 안 된다(그 사고가 이 저장소에서 가장 비싸다).
    """
    init_schema(conn)
    n_new = n_skip = 0
    for name, kind, task, scope, prompt, gates, note in _spread_ref(seed_profiles()):
        code = profile_code(kind, task, scope)
        cur = conn.execute("SELECT profile_id FROM sys_ai_profile "
                           "WHERE profile_code=?", (code,)).fetchone()
        if cur and not force:
            n_skip += 1
            continue
        save_profile(conn, {
            'profile_code': code, 'name': name, 'asset_kind': kind,
            'task': task, 'scope_value': scope,
            'prompt_json': json.dumps(prompt, ensure_ascii=False, indent=2),
            'gates_json': json.dumps(gates, ensure_ascii=False),
            'model': 'gemini-flash-lite', 'batch_n': 10, 'note': note})
        n_new += 1
    return n_new, n_skip


# ══════════════════════════════════════════════════════════════════════
#  자가 검증 (의무)
# ══════════════════════════════════════════════════════════════════════

def selftest():
    bad = []
    # ⚠ **항목 수를 손으로 적지 않는다** — 상수로 두면 항목을 늘려도
    #   그 수로 찍혀 **세는 쪽이 거짓말**을 한다(§238차 그 자리).
    _nck = [0]

    def ck(cond, msg):
        _nck[0] += 1
        if not cond:
            bad.append(msg)

    # ① 자산 표가 성하다
    ck(len(ASSETS) == len(ASSET), '자산 열쇠가 겹친다')
    # ★★★ 297차 — 구절 연결기
    ck(ASSET['VERS_LINK']['store'] == 'LINK' and ASSET['VERS_LINK']['slot'] == 'VERSE',
       '연결기 자산 = 절 자리 · LINK 저장')
    ck(len(REL_CODES) == 12 and all(r[3] for r in REL_CODES), '갈래 열둘에 가르는 잣대가 다 있다')
    ck(edit_blocked('VERS_LINK', 'TRANS', 'JA') and not edit_blocked('VERS_LINK', 'EDIT', 'KO')
       and not edit_blocked('VERS_LINK', 'NEW', 'KO'), '연결기는 신규(잇기)·다듬기(점검)만 — 번역 없음')
    # ★ docs/2.txt 8번 — 외부 자료 = 번역만. 신규 작성 없음 · 원문(기준 언어) 다듬기 없음 · 같은 언어 옮기기 없음
    for _k in ('BOOK_UNIT', 'COMMENTARY', 'REF_CATE', 'REF_DICT', 'BOOK_TASTE'):
        ck(edit_blocked(_k, 'NEW', 'KO') and edit_blocked(_k, 'NEW', 'EN'), '%s 신규 작성은 막힌다' % _k)
        ck(edit_blocked(_k, 'EDIT', 'EN') and not edit_blocked(_k, 'EDIT', 'KO'),
           '%s 원문(EN) 다듬기는 막히고 번역본(KO) 다듬기는 된다' % _k)
        ck(not edit_blocked(_k, 'TRANS', 'KO'), '%s 번역은 된다' % _k)
    ck(edit_blocked('REF_CATE', 'TRANS', 'EN') and edit_blocked('REF_DICT', 'TRANS', 'EN'),
       '자료집은 같은 언어(EN→EN)로 옮기면 원문 칸을 덮는다 — 막힌다')
    ck(not edit_blocked('BOOK_UNIT', 'TRANS', 'EN'), '도서 EN→EN 은 현대어(MODERN_EN) 칸이라 된다')
    ck(not edit_blocked('VERS_DESC_LAY', 'NEW', 'KO') and not edit_blocked('VERS_DESC_LAY', 'EDIT', 'KO')
       and not edit_blocked('REF_STUDY', 'NEW', 'KO'), '우리 글은 셋 다 된다')
    try:
        import appdb as _adb
        _c = _adb.connect()
        _g = rel_code_guide(_c)
        ck(all(code in _g for code in REL_CODE_SET) and '잣대' in _g and '↔' in _g,
           '갈래 안내에 정의·잣대·우리 자료의 예가 든다')
        _v = _c.execute("SELECT verse_id FROM bible_index WHERE bcode=1 AND chapter=1 AND verse=1").fetchone()[0]
        _p = link_lines_parse(_c, '1. 요 1:3 · PRG · 태초의 창조가 말씀의 창조로 자랍니다.\n'
                                  '시 33 : 6 | syn | 말씀으로 하늘이 지어졌습니다\n'
                                  '없는책 1:1 · TYP · x\n이상한 줄')
        ck(len(_p) == 4 and _p[0][1] and _p[0][2] == 'PRG' and _p[1][1] and _p[1][2] == 'SYN',
           '줄 꼴을 푼다(번호·구분자·띄어쓰기 견딤): %s' % [(x[0], x[2]) for x in _p])
        ck(_p[2][1] is None and _p[3][0] == '', '모르는 책은 None · 못 읽은 줄은 ref 빈칸')
        _pj = link_lines_parse(_c, '[{"ref":"요 1:3","rel":"PRG","why":"말씀"}]')
        ck(len(_pj) == 1 and _pj[0][1], 'JSON 도 푼다')
        _m = material(_c, 'VERS_LINK', _v, 'NEW', base='KO', lang='KO')
        ck(any(k.startswith('이미 이어진') for k in _m) and any(k.startswith('연결 갈래') for k in _m)
           and '본문 (개역한글)' in _m, '연결기 재료 = 본문 + 이미 이어진 구절 + 갈래 안내')
        ck('창' in existing_links_text(_c, _v) or existing_links_text(_c, _v) == '',
           '지금 이어진 구절 줄')
        _c.close()
    except Exception as _e:                               # noqa: BLE001
        ck(False, '연결기 자가검증이 터졌다: %r' % (_e,))
    for k, a in ASSET.items():
        ck(a['axis'] in AXIS_NAME, '%s: 모르는 축 %s' % (k, a['axis']))
        ck(a['store'] in ('TEXT', 'BOOK', 'COMM', 'REF', 'BUNDLE',
                          'BOOKA', 'BTASTE', 'LINK'),
           '%s: 모르는 저장소' % k)
        if a['store'] == 'TEXT':
            ck(bool(a['text_type']), '%s: TEXT 인데 text_type 이 없다' % k)
        if a['store'] == 'BUNDLE':
            # ⚠ 묶음은 제 text_type 이 **없어야** 한다 — 칸 표가 정한다.
            #   하나라도 적어 두면 「한 자리에 두 규칙」이 된다.
            ck(not a['text_type'], '%s: 묶음인데 text_type 이 있다' % k)

    # ①-2 묶음 칸 표 — 가르기가 왕복하는가
    ck(len(BUNDLE_PARTS) == len(BUNDLE_PART), '묶음 칸 열쇠가 겹친다')
    # ★ 317차-19 — 고른 칸만으로 거른다(작업 589 실측: 뺀 칸을 47건 전부 써 왔다)
    _pf = {'must': ['연구질문과 연구자료를 짝으로 쓴다.', '묵상질문·연구질문은 물음표로 끝난다.', '설명문은 산문.'],
           'example': '[설명문]\n…\n[묵상질문]\n…\n[연구질문]\n…합니까?\n[연구자료]\n제목\n1. 갈래'}
    _f = bundle_filter(_pf, 'DESC,QUES,PRAYER')
    ck('[연구질문]' not in _f['example'] and '[연구자료]' not in _f['example']
       and '[묵상질문]' in _f['example'], '선택하지 않은 칸의 예시 블록이 남는다 (bundle_filter)')
    ck(_f['must'] == ['묵상질문·연구질문은 물음표로 끝난다.', '설명문은 산문.'],
       '뺀 칸만 말하는 줄을 안 걷거나 섞인 줄을 걷었다: %s' % (_f['must'],))
    ck(bundle_filter(_pf, None) is _pf and bundle_filter(_pf, [p[0] for p in BUNDLE_PARTS]) is _pf,
       '다 선택하면 프롬프트를 건드리면 안 된다')
    _g = bundle_filter(_pf, 'STUDY,NOTE')
    ck('[설명문]' not in _g['example'] and '[연구자료]' in _g['example'], '연구 갈래만 골랐는데 설명문 블록이 남는다')
    ck(bundle_need(None) == list(BUNDLE_NEED) and bundle_need('DESC,STUDY') == ['DESC']
       and bundle_need('STUDY,NOTE') == ['STUDY', 'NOTE'] and bundle_need('STUDY,NOTE', ['STUDY']) == ['NOTE']
       and bundle_need('STUDY', ['STUDY']) == [], '「할 일」 기준 칸(bundle_need)이 틀리다')
    ck(BUNDLE_NEED and 'STUDY' not in BUNDLE_NEED,
       '연구질문이 필수로 들어가 있다')
    for _p in BUNDLE_PARTS:
        # ★★★ **담기는 곳이 잣대를 정한다**(2026-09-24) — `sys_text_asset`
        #   칸만 유형·티어·자산 열쇠를 갖는다. 연구자료는 `sys_ref_unit` 이라
        #   그 셋이 **없는 것이 옳다**. 한 잣대로 재면 멀쩡한 칸이 흠이 된다.
        if _p[7] == 'TEXT':
            ck(bool(_p[2]), '묶음 칸 %s: text_type 이 없다' % _p[0])
            # ⚠ 자산 열쇠가 실재해야 게이트가 제 잣대로 잰다
            ck(_p[6] in ASSET, '묶음 칸 %s: 자산 열쇠 %s 가 없다'
               % (_p[0], _p[6]))
            ck(ASSET[_p[6]]['text_type'] == _p[2]
               and (ASSET[_p[6]]['variant'] or None) == _p[3],
               '묶음 칸 %s 의 자산이 유형·티어와 어긋난다' % _p[0])
        else:
            ck(not _p[2] and not _p[6],
               '묶음 칸 %s: 담기는 곳이 %s 인데 절 자산 값을 들고 있다'
               % (_p[0], _p[7]))
            ck(not _p[4], '묶음 칸 %s: 필수인데 담기는 곳이 절 자산이 아니다'
               % _p[0])
    # ★ 연구자료 칸 — 있는가 · 필수가 아닌가 · 셈에서 빠지는가 (16-1)
    ck('NOTE' in BUNDLE_PART and BUNDLE_PART['NOTE']['store'] == 'REF',
       '연구자료 칸이 없다')
    ck('NOTE' not in BUNDLE_NEED, '연구자료가 필수로 들어가 있다')
    _mk = {'DESC': '설명입니다.', 'QUES': '어떻게 살겠습니까?',
           'PRAYER': '주님 도와주소서.', 'STUDY': '왜 그런가?',
           'NOTE': '제목 한 줄' + chr(10) + '1. 첫 갈래' + chr(10) + '본문.'}
    _t = bundle_join(_mk)
    _got, _why = bundle_split(_t)
    ck(_got == _mk, '묶음 가르기 왕복이 깨진다: %s' % _why)
    # 필수 칸을 지우면 **거부**해야 한다(반쪽 적재 금지)
    _bad, _w2 = bundle_split('[설명문]\n가나다\n[묵상질문]\n라마?')
    ck(_bad is None and '묵상기도' in _w2, '반쪽인데 통과시킨다')
    # ★ 「없음」은 글이 아니라 빈 칸이다(2026-09-24 실측으로 잡았다)
    _e1, _ew = bundle_split(bundle_join(dict(_mk, STUDY='없음', NOTE='해당 없음')))
    ck(_e1 is not None and 'STUDY' not in _e1 and 'NOTE' not in _e1,
       '「없음」을 글로 적재한다: %s' % (_e1,))
    # ⚠ 필수 칸이 「없음」이면 **반쪽**이므로 거부해야 한다
    _e2, _ew2 = bundle_split(bundle_join(dict(_mk, PRAYER='없음')))
    ck(_e2 is None and '묵상기도' in (_ew2 or ''),
       '필수 칸이 「없음」인데 통과시킨다')
    # 연구질문이 없는 것은 **정상**이다
    _ok3, _w3 = bundle_split(bundle_join(
        {k: v for k, v in _mk.items() if k not in ('STUDY', 'NOTE')}))
    ck(_ok3 is not None and 'STUDY' not in _ok3 and 'NOTE' not in _ok3,
       '연구질문·연구자료가 없다고 거부한다: %s' % _w3)
    # 마커가 아예 없으면 거부
    _n4, _w4 = bundle_split('그냥 글입니다.')
    ck(_n4 is None, '마커가 없는데 통과시킨다')
    # ⚠ 역본 본문은 **없어야 한다** — 유료 역본을 밖으로 보내면 안 된다
    ck(not any('bible_content' in str(a) for a in ASSET.values()),
       '역본 본문이 자산 목록에 있다')

    # ①-2 **기준 언어가 자산마다 다르다**(2026-09-23 · 상수 하나로 두었다가
    #   「주석 본문 신규 작성 64,234자리」라는 거짓 일감을 냈다)
    ck(base_lang('VERS_DESC_LAY') == 'KO', '우리 글의 기준이 KO 가 아니다')
    for k in ('COMMENTARY', 'BOOK_UNIT', 'REF_DICT', 'REF_CATE'):
        ck(base_lang(k) == 'EN', '%s: 수입 저작물의 기준이 EN 이 아니다' % k)
        ck(not is_mine(k), '%s: 수입 저작물을 우리 글이라 한다' % k)
    ck(is_mine('VERS_DESC_LAY'), '우리 글을 남의 글이라 한다')
    ck(base_lang('__없는자산__') == BASE_LANG, '모르는 자산에서 되받이가 없다')

    # ② 프롬프트 검사기가 **양방향**으로 듣는다
    good = {'role': 'r', 'task': 't', 'style': ['a'], 'length': {'min': 1, 'max': 2}}
    ck(not check_prompt(good), '멀쩡한 프롬프트를 흠이라 한다')
    ck(check_prompt({'task': 't'}), 'role 이 없는데 통과시킨다')
    ck(check_prompt({'role': 'r'}), 'task 가 없는데 통과시킨다')
    ck(check_prompt({'role': 'r', 'task': 't', 'style': 'a'}),
       'style 이 글자인데 통과시킨다')
    ck(check_prompt({'role': 'r', 'task': 't', 'length': {'min': 9, 'max': 1}}),
       '길이가 거꾸로인데 통과시킨다')
    ck(check_prompt('글자'), '객체가 아닌데 통과시킨다')
    ck(unknown_keys({'role': 'r', 'zzz': 1}) == ['zzz'], '모르는 열쇠를 못 짚는다')

    # ③ 렌더 — 칸이 실제로 글에 나온다
    txt = render_prompt(good, {'재료': '창 1:1'})
    for need in ('[역할]', '[할 일]', '[문체]', '[분량]', '[재료]', '창 1:1'):
        ck(need in txt, '렌더에 %s 가 없다' % need)
    ck('role' not in txt, '렌더가 JSON 열쇠를 그대로 낸다')

    # ④ 씨앗 프로필이 전부 검사를 지난다
    for name, kind, task, scope, prompt, _g, _n in _spread_ref(seed_profiles()):
        ck(kind in ASSET, '씨앗 %s: 모르는 자산 %s' % (name, kind))
        ck(task in TASK_NAME, '씨앗 %s: 모르는 업무 %s' % (name, task))
        ck(not check_prompt(prompt), '씨앗 %s 의 프롬프트에 흠' % name)
        ck(not unknown_keys(prompt), '씨앗 %s 에 모르는 열쇠' % name)
    codes = [profile_code(k, t, s) for _n2, k, t, s, _p, _g, _n3 in _spread_ref(seed_profiles())]
    ck(len(codes) == len(set(codes)), '씨앗 프로필 코드가 겹친다')

    # ⑤ DB — 실제로 세어 본다. **되돌린다.**
    conn = None
    try:
        conn = _conn()
    except Exception as e:                                 # noqa: BLE001
        bad.append('DB 를 못 연다: %s' % e)
    if conn is not None:
        try:
            init_schema(conn)
            # 자산 열다섯이 **전부 실제로 돈다**(SQL 오타를 여기서 잡는다)
            for k in ASSET:
                ax = ASSET[k]['axis']
                vals = axis_values(conn, ax)
                ck(len(vals) >= 2, '%s: 축 %s 에 선택할 것이 없다' % (k, ax))
                sc = vals[1][0]
                sl = slots(conn, k, sc, limit=5)
                ck(isinstance(sl, list), '%s: 자리 목록이 아니다' % k)
                st = status(conn, k, sc)
                for lg, (d, t) in st.items():
                    ck(0 <= d <= t, '%s/%s: 쓴 수가 전체를 넘는다' % (k, lg))
            # 격자가 실제 수와 맞는가 — 창세기 절 설명문
            hv = have(conn, 'VERS_DESC_LAY', '1')
            n_ko = sum(1 for s in hv.values() if 'KO' in s)
            real = conn.execute(
                "SELECT COUNT(*) FROM sys_text_asset t JOIN bible_index b "
                "ON b.verse_id=t.clicked_id WHERE t.text_type='VERS_DESC' "
                "AND t.text_variant='LAY' AND UPPER(t.lang_code)='KO' "
                "AND t.record_status='LIVE' AND TRIM(COALESCE(t.contents,''))<>'' "
                "AND b.bcode=1").fetchone()[0]
            ck(n_ko == real, '창세기 KO 현황이 실제와 다르다: %s ≠ %s'
               % (n_ko, real))
            # 업무 셋이 **서로 다른 자리**를 가리킨다
            tot = len(hv)
            n_new = len(todo(conn, 'VERS_DESC_LAY', '1', 'NEW', 'JA'))
            n_tr = len(todo(conn, 'VERS_DESC_LAY', '1', 'TRANS', 'JA'))
            n_ed = len(todo(conn, 'VERS_DESC_LAY', '1', 'EDIT', 'KO'))
            ck(n_new + n_ko == tot, '신규 + KO 보유 ≠ 전체 (%s+%s≠%s)'
               % (n_new, n_ko, tot))
            ck(n_ed == n_ko, 'EDIT(KO) 가 KO 보유와 다르다')
            ck(n_tr <= n_ko, 'JA 번역 대상이 KO 보유보다 많다')
            ck(limit_works(conn), 'limit 가 안 듣는다')
            # ★ 재료 — **업무마다 다르다**(2026-09-23 ②)
            m_new = material(conn, 'VERS_DESC_LAY', 1, 'NEW')
            ck('구절' in m_new and '창 1:1' in m_new['구절'],
               '재료에 약명이 없다: %s' % m_new.get('구절'))
            ck(any('본문' in k for k in m_new), '재료에 구절 본문이 없다')
            ck('앞뒤 절' in m_new, '신규 작성 재료에 앞뒤 절이 없다')
            m_tr = material(conn, 'VERS_DESC_LAY', 1, 'TRANS', base='KO', lang='JA')
            ck(any('글 (KO)' in k for k in m_tr),
               '번역 재료에 웮길 글이 없다: %s' % list(m_tr))
            # ⚠ 번역에는 배경을 안 실는다(토큰 낭비 + 원문에 없는 것을 보태기 쉽다)
            ck('주석' not in m_tr, '번역 재료에 주석이 실렸다')
            # ★ 신규 작성에도 **주석·단락 제목이 안 실린다**(사용자 지시).
            #   재료는 성경 본문뿐이라야 한다 — 늘어나면 여기서 잡힌다.
            ck('주석' not in m_new, '신규 재료에 주석이 실렸다')
            ck('단락' not in ' '.join(m_new.keys()),
               '신규 재료에 단락 제목이 실렸다')
            ck('앞뒤 절' not in m_tr, '번역 재료에 앞뒤 절이 실렸다')
            # ★ 문단 수를 재료가 말한다 — 게이트와 같은 법으로 센다
            ck(taste_paras('가\n\n나\n다') == 3,
               '문단 수를 잘못 센다: %s' % taste_paras('가\n\n나\n다'))
            ck(taste_paras('가\n\u27e8맛보기 여기까지\u27e9\n나') == 1,
               '표식 뒤까지 센다')
            # ★ 지금 있는 글을 읽는 문 — 다시 쓰기 검수가 쓴다
            ck(current_text(conn, 'VERS_DESC_LAY', 1, 'KO')
               == (_asset_text(conn, 'VERS_DESC_LAY', 1, 'KO') or ''),
               '지금 있는 글이 저장된 글과 다르다')
            ck(current_text(conn, 'VERS_DESC_LAY', 1, 'ZZ') == '',
               '없는 언어인데 글을 낸다')
            # ★ AI 적재분 — **묶음이 채운 자리도 AI 로 센다**(양방향)
            _fl = _bundle_fills()
            ck(_fl.get('DESC') == 'VERS_DESC_LAY',
               '묶음이 채우는 설명문 자산을 모른다: %s' % _fl)
            ck('NOTE' not in _fl,
               '연구자료를 묶음이 채우는 자리로 센다(번호 공간이 다르다)')
            _al = ai_loaded(conn, 'BOOK_TASTE')
            ck(isinstance(_al, dict), 'AI 적재분이 표가 아니다')
            ck(all(isinstance(v, set) for v in _al.values()),
               'AI 적재분 값이 집합이 아니다')
            # ★ **담은 건이 빠짐없이 잡히는가** — 데이터 상태를 안 박고
            #   「표와 표가 서로 맞는가」를 묻는다(§0-5).
            _mis = [(r[0], r[1]) for r in conn.execute(
                "SELECT i.slot_id, UPPER(j.lang) FROM sys_ai_item i "
                "JOIN sys_ai_job j ON j.job_id=i.job_id "
                "WHERE i.state='LOADED' AND j.asset_kind='BOOK_TASTE'")
                if r[1] not in _al.get(int(r[0]), set())]
            ck(not _mis, 'AI 가 담은 건이 적재분 표에서 빠졌다: %s'
               % (_mis[:3],))
            ck(_mark_ai('KO', {'KO'}) == 'KO(AI)', 'AI 표시가 안 붙는다')
            ck(_mark_ai('KO', {'EN'}) == 'KO', '사람 글에 AI 표시가 붙는다')
            ck(_mark_ai('KO', set()) == 'KO', '빈 목록인데 AI 표시가 붙는다')
            _wl = str(m_tr.get('써 넣을 언어'))
            ck(_wl.startswith('JA'), '써 넣을 언어가 틀리다: %s' % _wl)
            # ★ 코드만 주면 모델이 프롬프트 언어를 따라간다 — 이름을 댄다
            ck('\u65e5\u672c\u8a9e' in _wl,
               '써 넣을 언어에 그 언어의 이름이 없다: %s' % _wl)
            ck(lang_label('ZZ') == 'ZZ', '모르는 언어 이름을 지어낸다')
            # ⚠ 옮길 글이 없으면 **그렇다고 말한다**(조용히 빈 재료를 내지 않는다)
            # ⚠⚠ **자리를 못 박지 않는다** — 옛 판은 시 1:1(13941)을 「빈
            #   자리」라 박아 두었다가 그 절에 글을 담자 FAIL 했다(§0-5).
            #   **지금 비어 있는 자리를 찾아서** 잰다.
            _hv = have(conn, 'VERS_DESC_LAY', '19')
            _empty = next((sid for sid, lg in _hv.items() if 'KO' not in lg),
                          None)
            if _empty is None:
                ck(True, '(시편이 다 찼다 — 빈 자리 검사는 건너뛴다)')
            else:
                m_none = material(conn, 'VERS_DESC_LAY', _empty, 'TRANS',
                                  base='KO', lang='JA')
                ck('⚠' in m_none,
                   '옮길 글이 없는데 조용히 넘어간다: %s' % list(m_none))
            # 렌더에 재료가 실린다
            _t = render_prompt({'role': 'r', 'task': 't'}, m_new)
            ck('태초에' in _t, '렌더에 구절 본문이 안 실렸다')
            # ★ 자수 — 있는 자리만 열쇠를 갖는다(0 으로 적지 않는다)
            sz = sizes(conn, 'VERS_DESC_LAY', '1', 'KO')
            hv1 = have(conn, 'VERS_DESC_LAY', '1')
            n_ko1 = sum(1 for s in hv1.values() if 'KO' in s)
            ck(len(sz) == n_ko1, '자수 열쇠 수가 보유 수와 다르다: %s ≠ %s'
               % (len(sz), n_ko1))
            ck(all(v > 0 for v in sz.values()), '자수에 0 이 섞였다')
            # ⚠⚠ 옛 판은 「시편은 비었다」를 전제했다 — 오늘 시편 1편에 글을
            #   담자 깨졌다(§0-5). ⇒ **규칙을 잰다** — 자수 열쇠는 언제나
            #   「그 언어 글이 있는 자리」와 같은 집합이어야 한다.
            _sz19 = sizes(conn, 'VERS_DESC_LAY', '19', 'KO')
            _hv19 = have(conn, 'VERS_DESC_LAY', '19')
            _ko19 = set(sid for sid, lg in _hv19.items() if 'KO' in lg)
            ck(set(_sz19) == _ko19,
               '시편 자수 열쇠가 보유와 다르다: %d ≠ %d'
               % (len(_sz19), len(_ko19)))
            ck(all(v > 0 for v in _sz19.values()), '시편 자수에 0 이 섞였다')
            # ★ 기준 후보 — 원본 언어가 맨 앞
            opts = base_options(conn, 'VERS_DESC_LAY', '1')
            ck(opts and opts[0][0] == 'KO', '기준 후보 첫째가 원본이 아니다: %s'
               % (opts[:2],))
            ck(len(opts) >= 2, '창세기 절 설명문 기준 후보가 둘 미만이다')
            # ★ 자료집은 범위가 기준 언어를 바꾼다
            # ★★★ **갈래를 나눈 뒤로는 자산 줄이 기준을 말한다**
            #   (2026-09-25) — 범위를 안 골라도 맞는다. 옛 한 자산은
            #   「전체」에서 남의 글과 우리 글이 섞였다.
            ck(base_lang('REF_STUDY') == 'KO', '연구 자료의 기준이 KO 가 아니다')
            ck(is_mine('REF_STUDY'), '연구 자료를 남의 글이라 한다')
            ck(base_lang('REF_DICT') == 'EN', '사전의 기준이 EN 이 아니다')
            ck(not is_mine('REF_DICT'), '사전을 우리 글이라 한다')
            # ★ 갈래마다 **제 자료집만** 목록에 오른다(섞이면 못 고른다)
            for _ax, _ty in REF_AXIS_TYPE.items():
                _ids = [v for v, _n in axis_values(conn, _ax, 'KO') if v]
                _bad = [v for v in _ids if (conn.execute(
                    "SELECT UPPER(src_type) FROM sys_ref_source"
                    "  WHERE ref_src_id=?", (int(v),)).fetchone() or [''])[0] not in
                    (_ty if isinstance(_ty, tuple) else (_ty,))]
                ck(not _bad, '%s 목록에 다른 갈래가 섞였다: %s' % (_ax, _bad))
            # ★ 유닛 0인 자료집(스트롱 원어사전)은 **안 올린다**(§0-1)
            _dict_ids = [v for v, _n in axis_values(conn, 'REF_DICT', 'KO') if v]
            ck('12' not in _dict_ids, '유닛 0인 가상 사전이 목록에 있다')
            # ★ 자리도 갈래로 좁는다
            _n_st = len(slots(conn, 'REF_STUDY'))
            _n_di = len(slots(conn, 'REF_DICT'))
            ck(0 < _n_st < _n_di, '갈래별 자리 수가 안 갈린다: %s/%s'
               % (_n_st, _n_di))
            # ★ 수입 저작물의 신규 작성은 **0 이라야 한다** — 남의 글이다
            n_cm = len(todo(conn, 'COMMENTARY', '', 'NEW'))
            ck(n_cm == 0, '주석 본문에 신규 작성 일감이 있다: %s' % n_cm)

            # ★★★ **목록 글자는 사람 말이라야 한다**(2026-09-25 사용자
            #   「용어 선택하면 **암호같은 코드**가 표시된다 · 뭔가 **사람이
            #   이해하게** 표시하라」). 양방향으로 잰다 — 코드가 안 보이고,
            #   **줄마다 서로 다르고**, 실제 이름이 나온다.
            import re as _re
            _t = slots(conn, 'ENTITY_DESC', 'TERM', limit=8)
            ck(_t and not any(_re.match(r'^[A-Z]{1,3}_[A-Z]', n)
                              for _i, n in _t),
               '용어 목록에 코드가 보인다 %s' % (_t[:2],))
            ck(_t and any(n != NO_NAME for _i, n in _t),
               '용어 이름이 하나도 없다')
            _p = slots(conn, 'ENTITY_DESC', 'PERSON', limit=5)
            ck(_p and any('다윗' in n or 'David' in n for _i, n in _p),
               '인물 이름이 안 나온다 %s' % (_p[:2],))

            # ⚠⚠ **줄마다 달라야 목록이다** — 옛 글자는 한 장의 주석 항목이
            #   전부 `GEN 1장` 이었고 한 절의 연결이 전부 `창 1:1 의 연결`
            #   이었다(실측). 무엇을 고르는지 알 수 없는 목록은 목록이 아니다.
            for _k, _sc in (('COMMENTARY', '1'), ('VERS_VERS_DESC', '1')):
                _r = slots(conn, _k, _sc, limit=6)
                if len(_r) >= 3:
                    ck(len(set(n for _i, n in _r)) == len(_r),
                       '%s 목록 줄이 서로 같다 %s' % (_k, _r[:3]))

            # 책 개요는 **번호 + 정식 이름**(약명만으로는 차례를 못 짚는다)
            _b = slots(conn, 'BOOK_DESC', '', limit=2)
            ck(_b and _b[0][1].startswith('01 ') and len(_b[0][1]) > 4,
               '책 개요가 정식 이름이 아니다 %s' % (_b[:1],))

            # 단락은 **범위**를 말한다(「…부터」는 끝을 안 말한다)
            _pe = slots(conn, 'PERI_TITLE', '1', limit=3)
            ck(_pe and any('-' in n for _i, n in _pe),
               '단락 이름에 끝이 없다 %s' % (_pe[:1],))
            ck(_pe and not any('부터' in n for _i, n in _pe),
               '단락 이름이 아직 「…부터」다')

            # ★ `slot_rows` — 이름 · 곁들임 · **있는 언어**를 한 문에서
            _rw = slot_rows(conn, 'VERS_DESC_LAY', '1', task='TRANS',
                            lang='JA', limit=3)
            ck(len(_rw) == 3 and len(_rw[0]) == 5, 'slot_rows 모양이 아니다')
            ck(any(r[2] for r in _rw), '곁들임(본문 앞머리)이 비었다')
            ck(any('KO' in (r[3] or '') for r in _rw),
               '있는 언어 칸이 비었다 %s' % (_rw[0][3] if _rw else '',))
            ck(all(isinstance(r[4], bool) for r in _rw),
               '할 일 판정이 안 나온다')
            # ⚠ 업무를 안 주면 **판정하지 않는다** — 「모름」과 「아니다」는 다르다
            ck(all(r[4] is None for r in slot_rows(
                conn, 'VERS_DESC_LAY', '1', limit=2)),
               '업무를 안 줬는데 할 일을 판정한다')
            # ⚠ 목록을 **거르지 않는다** — 거르는 것은 화면의 몫
            ck(len(slot_rows(conn, 'VERS_DESC_LAY', '1', task='NEW',
                             limit=5)) == 5, 'slot_rows 가 목록을 거른다')

            # ★★★ **프롬프트 층**(2026-09-25 · 1.txt 16-2 · 3) — 양방향.
            #   사용자 「프롬프트는 **번역대상 언어마다 설정**할 수 있어야
            #   한다. 예) 러시아어 번역할 때 성경구절 인용은 시노드버전으로」
            init_prompt_schema(conn)
            _n0 = conn.execute(
                "SELECT COUNT(*) FROM sys_ai_prompt").fetchone()[0]
            _MARK = '__시험층__'
            # ★★★ **시험이 건드린 자리를 되돌린다**(2026-09-25).
            #   ⚠⚠⚠ 아래 ⓐ 는 `('','','TRANS','RU','must')` 에
            #     쓰는데 **그 열쇠는 진짜 층이 쓰는 자리**다
            #     (언어마다 기준 역본). 끝에 _MARK 행만 지우면
            #     원래 있던 글이 통째로 사라진다 — 실제로 당했다.
            # ⚠ **차례로 견주지 않는다**(2026-09-25) — 지우고 다시 넣으면
            #   줄 차례가 바뀌어 내용이 같아도 실패한다(흔들리는 검사).
            _snap = sorted(conn.execute(
                "SELECT kind, scope, task, lang, part, body"
                "  FROM sys_ai_prompt").fetchall())
            # ★ 2026-10-13 — 되돌릴 때 **바뀐 줄만 · 고친 시각과 상태까지** 그대로(옛 판은 341줄을 전부 다시 써서
            #   고친 시각이 모두 시험한 때로 바뀌었다 — 누가 언제 고쳤는지가 사라졌다)
            _full = {tuple(r[:5]): r[5:] for r in conn.execute(
                "SELECT kind, scope, task, lang, part, body, updated_at, record_status FROM sys_ai_prompt")}
            try:
                # ⓐ **언어 층** — 그 언어에만 걸린다
                set_layer(conn, '', '', 'TRANS', 'RU', 'must',
                          _MARK + ' 시노드역으로')
                _ru = compose_prompt(conn, 'BOOK_UNIT', '42', 'TRANS', 'RU')
                _ko = compose_prompt(conn, 'BOOK_UNIT', '42', 'TRANS', 'KO')
                ck(any(_MARK in x for x in _ru.get('must', [])),
                   '언어 층이 그 언어에 안 걸린다')
                ck(not any(_MARK in x for x in _ko.get('must', [])),
                   '언어 층이 **다른 언어에도** 걸린다')
                # ⓑ **자산 유형 층** — 다른 자산에는 안 걸린다
                set_layer(conn, 'BOOK_UNIT', '', '', '', 'style',
                          _MARK + ' 설교체를 살린다')
                _bk = compose_prompt(conn, 'BOOK_UNIT', '42', 'TRANS', 'KO')
                _vs = compose_prompt(conn, 'VERS_DESC_LAY', '1', 'NEW', 'KO')
                ck(any(_MARK in x for x in _bk.get('style', [])),
                   '자산 유형 층이 안 걸린다')
                ck(not any(_MARK in x for x in _vs.get('style', [])),
                   '자산 유형 층이 다른 자산에도 걸린다')
                # ⓒ **업무가 다르면 안 걸린다**
                _bn = compose_prompt(conn, 'BOOK_UNIT', '42', 'NEW', 'RU')
                ck(not any(_MARK + ' 시노드' in x for x in _bn.get('must', [])),
                   '업무가 다른데 그 층이 걸린다')
                # ⓓ **쌓는 성격과 이기는 성격**(둘을 안 가르면 층이 늘수록
                #   더 헷갈린다)
                set_layer(conn, '', '', '', '', 'role', _MARK + ' 넓은 역할')
                set_layer(conn, 'BOOK_UNIT', '', '', '', 'role',
                          _MARK + ' 좁은 역할')
                _r = compose_prompt(conn, 'BOOK_UNIT', '', 'NEW', 'KO',
                                    prof=False or None)
                ck(isinstance(_r.get('role'), str), '역할이 목록이 됐다')
                set_layer(conn, '', '', '', '', 'never', _MARK + ' 넓은 금지')
                set_layer(conn, 'BOOK_UNIT', '', '', '', 'never',
                          _MARK + ' 좁은 금지')
                _r2 = compose_prompt(conn, 'BOOK_UNIT', '', 'NEW', 'KO')
                _nv = [x for x in _r2.get('never', []) if _MARK in x]
                ck(len(_nv) == 2,
                   '금지가 안 쌓인다(넓은 층이 사라진다) %s' % (_nv,))
                # ⓔ **같은 줄을 두 번 쌓지 않는다**
                set_layer(conn, '', '', '', 'KO', 'never', _MARK + ' 넓은 금지')
                _r3 = compose_prompt(conn, 'BOOK_UNIT', '', 'NEW', 'KO')
                ck(len([x for x in _r3.get('never', [])
                        if x == _MARK + ' 넓은 금지']) == 1,
                   '같은 줄이 두 번 쌓인다')
                # ⓕ **빈 글이면 지운다**(빈 줄이 남으면 화면이 거짓말한다)
                set_layer(conn, '', '', '', 'KO', 'never', '')
                ck(not get_layer(conn, '', '', '', 'KO').get('never'),
                   '빈 글을 적었는데 층이 남아 있다')
                # ⓖ ★★★ **구성요소 층 씨앗 34줄**(1.txt 16-2 · 2026-09-25)
                #   사용자 「**콤보상자 3개의 구성요소 조합만** 만들면
                #   충분하다」 — 660조합이 아니라 34줄이다.
                _seed = seed_layers(conn)
                _g = layer_groups(conn)
                _keys = {(r[0], r[2], r[3]) for r in _seed}
                # ⚠ 297차 — 수를 못 박지 않는다(자산이 늘면 줄이 는다 · §238차 「세는 쪽」)
                _want = 3 + len(_LAYER_KIND) + len(ui_langs())
                ck(len(_keys) == _want, '씨앗 줄 수가 업무 3 + 자산 %d + 언어 %d 와 다르다: %d'
                   % (len(_LAYER_KIND), len(ui_langs()), len(_keys)))
                ck({r[0] for r in _g['자산']} == set(ASSET),
                   '자산 층이 `ASSETS` 와 안 맞는다 %s'
                   % (set(ASSET) ^ {r[0] for r in _g['자산']},))
                ck({r[2] for r in _g['업무']} == {t[0] for t in TASKS},
                   '업무 층이 `TASKS` 와 안 맞는다')
                ck({r[3] for r in _g['언어']} == set(ui_langs()),
                   '언어 층이 `ui_langs()` 와 안 맞는다')
                # ★ 역본은 **게이트와 같은 표**에서 온다(두 곳에 적으면 갈린다)
                import db_cite_gate as _CG
                _ruL = [r[5] for r in _g['언어'] if r[3] == 'RU']
                ck(_ruL and _CG.VERSION_OF['RU'] in _ruL[0],
                   '언어 층의 역본이 `VERSION_OF` 와 다르다')
                _jaL = [r[5] for r in _g['언어'] if r[3] == 'JA']
                ck(_jaL and '널리 쓰이는' in _jaL[0],
                   '기준 역본이 없는 언어에 없는 역본을 적었다')
                # ★ **빈 메모리 DB 에 담아 본다** — 실 DB 는 사용자가 담는다
                import sqlite3 as _sq
                _m = _sq.connect(':memory:')
                try:
                    _a, _b, _mv = apply_layers(_m)
                    ck(_a == len(_seed) and _b == 0,
                       '첫 적재가 다 안 담긴다 %s/%s' % (_a, _b))
                    # ⚠⚠ **두 번째는 하나도 안 덮는다**(§32차 사람이 고친 판)
                    _m.execute("UPDATE sys_ai_prompt SET body='사람이 고친 글'"
                               " WHERE kind='' AND task='NEW' AND part='role'")
                    _m.commit()
                    _a2, _b2, _ = apply_layers(_m)
                    ck(_a2 == 0 and _b2 == len(_seed),
                       '두 번째 적재가 칸을 덮었다 %s/%s' % (_a2, _b2))
                    ck(get_layer(_m, '', '', 'NEW', '')['role']
                       == '사람이 고친 글', '사람이 고친 글을 덮었다')
                    # ★ `--force` 면 덮는다(탐지력 반대쪽)
                    apply_layers(_m, force=True)
                    ck(get_layer(_m, '', '', 'NEW', '')['role']
                       != '사람이 고친 글', '`--force` 인데 안 덮는다')
                    # ★★★ **언어 층을 `TRANS` 에서 `''` 로 옮긴다**
                    _m.execute("DELETE FROM sys_ai_prompt")
                    _m.commit()
                    set_layer(_m, '', '', 'TRANS', 'RU', 'must', '옛 자리 글')
                    _a3, _b3, _mv3 = apply_layers(_m)
                    ck(_mv3 == 1, '옛 언어 층을 안 옮긴다 %s' % _mv3)
                    # ★ 294차 — 언어 층은 이제 **「성경 인용」(cite) 성격**이다
                    ck(get_layer(_m, '', '', '', 'RU').get('cite')
                       == '옛 자리 글', '옮기면서 글을 다시 지었다')
                    ck(not get_layer(_m, '', '', 'TRANS', 'RU').get('must'),
                       '옛 자리가 그대로 남아 두 벌이 된다')
                finally:
                    _m.close()
            finally:
                conn.execute("DELETE FROM sys_ai_prompt WHERE body LIKE ?",
                             ('%' + _MARK + '%',))
                # ★ 덮어쓴 자리를 **글자 그대로** 되돌린다 — 바뀐 줄만 · 시각·상태까지
                _now_rows = {tuple(r[:5]): r[5:] for r in conn.execute(
                    "SELECT kind, scope, task, lang, part, body, updated_at, record_status FROM sys_ai_prompt")}
                for _key, (_b, _u, _st) in _full.items():
                    if _now_rows.get(_key) == (_b, _u, _st):
                        continue
                    if _key in _now_rows:
                        conn.execute("UPDATE sys_ai_prompt SET body=?, updated_at=?, record_status=?"
                                     " WHERE kind=? AND scope=? AND task=? AND lang=? AND part=?",
                                     (_b, _u, _st) + _key)
                    else:
                        set_layer(conn, *(_key + (_b,)))
                        conn.execute("UPDATE sys_ai_prompt SET updated_at=?, record_status=?"
                                     " WHERE kind=? AND scope=? AND task=? AND lang=? AND part=?",
                                     (_u, _st) + _key)
                conn.commit()
            ck(sorted(conn.execute(
                   "SELECT kind, scope, task, lang, part, body"
                   "  FROM sys_ai_prompt").fetchall()) == _snap,
               '층 시험이 자국을 남겼다')

            # 프로필 왕복 — 저장 · 이력 · 고르기 · 되살리기. **자국 0.**
            n0 = conn.execute("SELECT COUNT(*) FROM sys_ai_profile").fetchone()[0]
            h0 = conn.execute("SELECT COUNT(*) FROM sys_ai_profile_hist").fetchone()[0]
            code = profile_code('VERS_DESC_LAY', 'NEW', '__T__')
            p1 = {'profile_code': code, 'name': '__시험__', 'asset_kind':
                  'VERS_DESC_LAY', 'task': 'NEW', 'scope_value': '__T__',
                  'prompt_json': json.dumps({'role': 'A', 'task': 'B'})}
            ck(save_profile(conn, p1) == 1, '첫 저장이 v1 이 아니다')
            pid = conn.execute("SELECT profile_id FROM sys_ai_profile "
                               "WHERE profile_code=?", (code,)).fetchone()[0]
            p2 = dict(p1, prompt_json=json.dumps({'role': 'C', 'task': 'D'}))
            ck(save_profile(conn, p2) == 2, '두 번째 저장이 v2 가 아니다')
            # ★★★ **빈 저장은 판을 안 올린다**(2026-09-24) — 양방향으로 잰다.
            #   위 두 줄이 「바뀌면 오른다」를 이미 쟀고, 여기서 「안 바뀌면
            #   안 오른다」를 잰다. 실측 사고 — 글자가 그대로인 저장이
            #   프로필 65 의 판을 올리고 이력에 빈 판을 남겼다.
            _hn = conn.execute(
                "SELECT COUNT(*) FROM sys_ai_profile_hist").fetchone()[0]
            ck(save_profile(conn, p2) == 2, '안 바뀐 저장이 판을 올린다')
            ck(conn.execute("SELECT COUNT(*) FROM sys_ai_profile_hist"
                            ).fetchone()[0] == _hn,
               '안 바뀐 저장이 이력에 빈 판을 남긴다')
            hs = history(conn, pid)
            ck(len(hs) == 1 and hs[0][1] == 1, '옛 판이 이력에 안 남았다')
            ck('"A"' in hs[0][3], '이력에 옛 프롬프트가 아니다')
            cur = get_profile(conn, pid)
            ck('"C"' in cur['prompt_json'], '지금 판이 새 프롬프트가 아니다')
            ck(restore(conn, pid, 1) == 3, '되살리기가 v3 을 안 만든다')
            ck('"A"' in get_profile(conn, pid)['prompt_json'],
               '되살린 것이 옛 프롬프트가 아니다')
            ck(len(history(conn, pid)) == 2, '되살릴 때 이력이 안 는다')
            # 고르기 — **좁은 것이 이긴다**
            got = pick_profile(conn, 'VERS_DESC_LAY', 'NEW', '__T__')
            ck(got and got['profile_id'] == pid, '딱 맞는 프로필을 못 선택한다')
            allp = {'profile_code': profile_code('VERS_DESC_LAY', 'NEW', ''),
                    'name': '__시험전체__', 'asset_kind': 'VERS_DESC_LAY',
                    'task': 'NEW', 'scope_value': '',
                    'prompt_json': json.dumps({'role': 'X', 'task': 'Y'})}
            had_all = conn.execute(
                "SELECT profile_id FROM sys_ai_profile WHERE profile_code=?",
                (allp['profile_code'],)).fetchone()
            if not had_all:
                save_profile(conn, allp)
                got2 = pick_profile(conn, 'VERS_DESC_LAY', 'NEW', '__T__')
                ck(got2 and got2['profile_id'] == pid,
                   '전체 프로필이 좁은 것을 이긴다')
                got3 = pick_profile(conn, 'VERS_DESC_LAY', 'NEW', '9999')
                ck(got3 and got3['name'] == '__시험전체__',
                   '모르는 범위에서 전체 프로필로 안 떨어진다')
                conn.execute("DELETE FROM sys_ai_profile WHERE profile_code=?",
                             (allp['profile_code'],))
            ck(pick_profile(conn, 'PERI_TITLE', 'EDIT', '__없다__') is None
               or True, '')
            # 청소
            conn.execute("DELETE FROM sys_ai_profile_hist WHERE profile_id=?", (pid,))
            conn.execute("DELETE FROM sys_ai_profile WHERE profile_id=?", (pid,))
            conn.commit()
            n1 = conn.execute("SELECT COUNT(*) FROM sys_ai_profile").fetchone()[0]
            h1 = conn.execute("SELECT COUNT(*) FROM sys_ai_profile_hist").fetchone()[0]
            ck(n0 == n1 and h0 == h1,
               '시험 자국이 남았다: 프로필 %s→%s · 이력 %s→%s' % (n0, n1, h0, h1))
        except Exception as e:                             # noqa: BLE001
            import traceback
            traceback.print_exc()
            bad.append('DB 검사에서 터졌다: %s' % e)
        finally:
            try:
                conn.close()
            except Exception:                              # noqa: BLE001
                pass

    # ── 294차 — 프로필 → 층 이관 · 보낼 프롬프트가 있나 · 예제 · 도서 변형 ──
    try:
        import sqlite3 as _sq
        _m = _sq.connect(':memory:')
        init_schema(_m)
        init_prompt_schema(_m)
        _m.execute("CREATE TABLE IF NOT EXISTS sys_config(config_key TEXT PRIMARY KEY,"
                   " config_val TEXT)")
        _m.commit()
        # 시험 프로필 둘 — 전체 · 범위(창세기)
        save_profile(_m, {'name': '전체', 'asset_kind': 'VERS_DESC_LAY', 'task': 'NEW',
                          'scope_value': '', 'lang_json': '', 'gates_json': '',
                          'prompt_json': json.dumps({'role': '넓은 역할', 'task': '할 일',
                                                     'must': ['a', 'b'],
                                                     'length': {'min': 300, 'max': 600},
                                                     'output': '본문만'}),
                          'model': '', 'batch_n': 1, 'note': ''})
        save_profile(_m, {'name': '창세기', 'asset_kind': 'VERS_DESC_LAY', 'task': 'NEW',
                          'scope_value': '1', 'lang_json': '', 'gates_json': '',
                          'prompt_json': json.dumps({'role': '창세기 역할', 'task': '할 일'}),
                          'model': '', 'batch_n': 1, 'note': ''})
        # 사람이 층에 먼저 적어 둔 칸은 안 덮는다
        set_layer(_m, 'VERS_DESC_LAY', '', 'NEW', '', 'output', '사람이 적은 출력서식')
        ck(not has_prompt(_m, 'COMMENTARY', '', 'TRANS', 'RU')[0],
           '층이 비었는데 보낼 프롬프트가 있다고 한다')
        _np, _nc, _ns = migrate_profiles(_m, dry=True)
        ck(_np == 2 and _nc >= 5, '이관 미리보기 수가 이상하다 %s/%s' % (_np, _nc))
        ck(not _profiles_migrated(_m), '미리보기가 이관 표식을 남겼다')
        _np, _nc, _ns = migrate_profiles(_m)
        ck(_profiles_migrated(_m), '이관 표식이 안 적혔다')
        _l = get_layer(_m, 'VERS_DESC_LAY', '', 'NEW', '')
        ck(_l.get('role') == '넓은 역할' and _l.get('must') == 'a' + NL_ + 'b',
           '프로필 칸이 층으로 안 옮겨졌다 %s' % _l)
        ck(_l.get('length') == '300~600자', '`length` 가 분량 칸으로 안 옮겨졌다 %s' % _l.get('length'))
        ck(_l.get('output') == '사람이 적은 출력서식', '사람이 먼저 적은 칸을 프로필이 덮었다')
        ck(get_layer(_m, 'VERS_DESC_LAY', '1', 'NEW', '').get('role') == '창세기 역할',
           '범위 프로필이 범위 층으로 안 갔다')
        ck(_m.execute("SELECT COUNT(*) FROM sys_ai_profile WHERE record_status='LIVE'")
           .fetchone()[0] == 0, '이관한 프로필이 LIVE 로 남았다')
        ck(_m.execute("SELECT COUNT(*) FROM sys_ai_profile").fetchone()[0] == 2,
           '이관이 프로필 행을 지웠다')
        # 업무 층(역할·할 일)이 채워져 프로필 없던 자산도 보낼 수 있다
        ck(has_prompt(_m, 'COMMENTARY', '', 'TRANS', 'RU')[0],
           '이관 뒤에도 주석 번역에 프롬프트가 없다(1.txt 1번 7))')
        _c1 = compose_prompt(_m, 'VERS_DESC_LAY', '1', 'NEW', 'KO')
        _c0 = compose_prompt(_m, 'VERS_DESC_LAY', '', 'NEW', 'KO')
        ck(_c1.get('role') == '창세기 역할' and _c0.get('role') == '넓은 역할',
           '범위 층이 자산 층을 이기지 않는다')
        # 이관 뒤에는 옛 프로필을 더 읽지 않는다 — LIVE 로 되살려도 층만 본다
        _m.execute("UPDATE sys_ai_profile SET record_status='LIVE', prompt_json=?"
                   " WHERE scope_value=''", (json.dumps({'role': '되살린 프로필', 'task': 't'}),))
        _m.commit()
        ck(compose_prompt(_m, 'VERS_DESC_LAY', '', 'NEW', 'KO').get('role') == '넓은 역할',
           '이관 뒤에도 프로필 JSON 을 읽는다')
        # layer_sources — compose 와 같은 줄을 내고 출처를 붙인다
        _src = layer_sources(_m, 'VERS_DESC_LAY', '1', 'NEW', 'KO')
        ck(any(k == ('VERS_DESC_LAY', '1', 'NEW', '') and p == 'role' for k, p, _b in _src),
           '결합 출처에 범위 층이 없다')
        ck(any(k == ('', '', 'NEW', '') and p == 'role' for k, p, _b in _src),
           '결합 출처에 업무 층이 없다')
        _m.close()
    except Exception as e:                                 # noqa: BLE001
        import traceback
        traceback.print_exc()
        bad.append('이관 검사에서 터졌다: %s' % e)
    # 성격 표 — 열 칸 · 사람 말 · 설명이 칸마다
    ck([k for k, _n, _s in PROMPT_PARTS] == ['role', 'task', 'style', 'must', 'never',
                                              'terms', 'cite', 'length', 'example', 'output'],
       '성격 열 칸의 차례가 다르다')
    ck(PART_NAME['output'] == '출력서식' and '내는 꼴' not in PART_NAME.values(),
       '「내는 꼴」이 남아 있다(출력서식이라야 한다)')
    ck(set(PART_HINT) == set(PART_STACK), '성격 설명이 빠진 칸이 있다')
    # 예제 표 — 자산 스물·업무 셋·언어 열하나 전부 · 열쇠는 성격 열 칸 안
    ck(set(PROMPT_EXAMPLES['KIND']) == set(ASSET), '예제가 없는 자산이 있다: %s'
       % sorted(set(ASSET) - set(PROMPT_EXAMPLES['KIND'])))
    ck(set(PROMPT_EXAMPLES['TASK']) == {t[0] for t in TASKS}, '예제가 없는 업무가 있다')
    ck(set(PROMPT_EXAMPLES['LANG']) >= set(ui_langs()), '예제가 없는 언어가 있다: %s'
       % sorted(set(ui_langs()) - set(PROMPT_EXAMPLES['LANG'])))
    _badk = [(g, k, p) for g in ('KIND', 'TASK', 'LANG') for k, d in PROMPT_EXAMPLES[g].items()
             for p in d if p not in PART_STACK]
    ck(not _badk and all(p in PART_STACK for p in PROMPT_EXAMPLES['ALL']),
       '예제에 성격 표 밖 열쇠가 있다 %s' % _badk[:3])
    ck(not any('■' in v for d in PROMPT_EXAMPLES['KIND'].values() for v in d.values()),
       '예제에 검은 네모(■)가 있다')
    # 씨앗 언어 층은 「성경 인용」 성격이다
    ck(all(r[4] == 'cite' for r in seed_layers() if r[3]), '언어 씨앗이 cite 성격이 아니다')
    # 도서 변형 — 영어는 현대 영어, 그 밖은 번역
    ck(book_variant_for('EN') == 'MODERN_EN' and book_variant_for('en', 'EN') == 'MODERN_EN',
       '영어 도서 글의 변형이 현대 영어가 아니다')
    ck(book_variant_for('KO') == 'TRANSLATED' and book_variant_for('EN', 'FR') == 'TRANSLATED',
       '영어가 아닌(또는 원문이 영어가 아닌) 글의 변형이 번역이 아니다')
    # 렌더 — 새 성격 넷이 사람 말 머리로 편다
    _r = render_prompt({'role': 'r', 'task': 't', 'cite': '개역한글', 'length': '300~600자',
                        'example': '보기', 'output': '본문만'}, {}, rules=[])
    for need in ('[성경 인용] 개역한글', '[분량] 300~600자', '[예시]', '[출력서식] 본문만'):
        ck(need in _r, '렌더에 %s 가 없다' % need)
    ck('[낼 것]' not in _r and '[길이]' not in _r and '[본보기]' not in _r,
       '렌더에 옛 머리말이 남아 있다')

    # ★ 2026-10-22 외부 저작(도서·설교·주석·신앙고백·사전·주제 색인)은 교단 중립의 예외 — 씨앗이 그렇게 펴지는가
    _sr = _spread_ref([('자료집 글 — 다듬기', REF_SEED_MARK, 'EDIT', '',
                        {'never': _NEVER_DENOM + ['x'], 'must': ['y']}, [], '')])
    for _row in _sr:
        _ext = _row[1] in EXTERNAL_KINDS
        ck(_ext == (EXTERNAL_DENOM in _row[4]['must']), '외부 자료집에만 예외 줄(%s)' % _row[1])
        ck(_ext != (_NEVER_DENOM[0] in _row[4]['never']), '교단 중립 줄은 우리 글(연구 자료)에만(%s)' % _row[1])

    n_all = _nck[0]
    for b in bad:
        print('  FAIL ' + b)
    print('db_ai_job selftest: %s (%d/%d)'
          % ('OK' if not bad else 'FAIL', n_all - len(bad), n_all))
    return 0 if not bad else 1


def limit_works(conn):
    return len(slots(conn, 'VERS_DESC_LAY', '1', limit=7)) == 7


# ══════════════════════════════════════════════════════════════════════

def _main(argv):
    if '--selftest' in argv:
        return selftest()
    conn = _conn()
    if '--assets' in argv:
        for k, name, axis, store, slot, tt, va in ASSETS:
            print('  %-16s %-18s 축=%-7s 자리=%-6s %s%s'
                  % (k, name, AXIS_NAME[axis], slot, tt or store,
                     ('/' + va) if va else ''))
        return 0
    if '--seed' in argv:
        n, s = seed(conn, force='--force' in argv)
        print('씨앗 프로필 — 새로 %d · 그대로 둔 것 %d' % (n, s))
        return 0
    if '--layers' in argv or '--layers-apply' in argv:
        # ★ 사용자가 「내가 적재하겠다」 — `--layers` 는 **보여 주기만** 한다
        if '--layers-apply' in argv:
            n, k, mv = apply_layers(conn, force='--force' in argv)
            print('구성요소 층 — 새로 %d · 그대로 둔 것 %d · 옮긴 언어 층 %d'
                  % (n, k, mv))
            return 0
        g = layer_groups(conn)
        for name in ('업무', '자산', '언어'):
            rows = g[name]
            n = len({(r[0], r[2], r[3]) for r in rows})
            print('── %s %d줄 (칸 %d개) ──' % (name, n, len(rows)))
            for kind, _sc, task, lang, part, body in rows:
                who = kind or task or lang
                print('  %-16s %-7s %s' % (who, PART_NAME.get(part, part),
                                           body.replace(NL_, ' / ')[:64]))
        print()
        print('담으려면 --layers-apply (이미 적힌 칸은 안 덮는다 · '
              '덮으려면 --force)')
        return 0
    if '--migrate-profiles' in argv:
        dry = '--dry' in argv
        r = migrate_profiles(conn, dry=dry)
        print('프로필 → 층: 옮긴 프로필 %d · 적은 칸 %d · 건너뛴 칸 %d%s'
              % (r + (' (미리보기)' if dry else '',)))
        return 0
    if '--profiles' in argv:
        for r in list_profiles(conn):
            print('  #%-4s v%-3s %-14s %-6s %-8s %s'
                  % (r[0], r[6], r[3], r[4], r[5] or '(전체)', r[2]))
        return 0

    def opt(name, dflt=''):
        return argv[argv.index(name) + 1] if name in argv else dflt

    if '--status' in argv:
        kind, sc = opt('--status'), opt('--scope')
        st = status(conn, kind, sc)
        tot = max(t for _d, t in st.values()) if st else 0
        print('%s · 범위 %s — 자리 %s' % (kind, sc or '(전체)', format(tot, ',')))
        for lg in ui_langs():
            d, t = st.get(lg, (0, tot))
            print('  %-4s %6s / %-6s  %5.1f%%'
                  % (lg, format(d, ','), format(t, ','), (100.0 * d / t) if t else 0))
        return 0
    if '--todo' in argv:
        kind, sc = opt('--todo'), opt('--scope')
        task, lang = opt('--task', 'NEW'), opt('--lang', 'KO')
        rows = todo(conn, kind, sc, task, lang, limit=int(opt('--limit', '20')))
        print('%s · %s · %s · %s — %d개(상한 적용)'
              % (kind, sc or '(전체)', TASK_NAME[task], lang, len(rows)))
        for sid, label in rows:
            print('   %-10s %s' % (sid, label))
        return 0
    print(__doc__)
    return 0


if __name__ == '__main__':
    sys.exit(_main(sys.argv[1:]))
