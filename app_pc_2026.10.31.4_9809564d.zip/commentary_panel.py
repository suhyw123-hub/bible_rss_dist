# commentary_panel.py
"""
주석 패널 (P2 탭2 — 주석)
공개 API: load(verse_id)
"""
import sqlite3
import verse_ref
import appdb
# ★ 단위 이름·차례는 **한 곳**이다 — 화면이 따로 적지 않는다.
#   (`db_commentary_level` 은 위젯이 없고 SQL 조회만 있는 데이터 층이다)
import db_commentary_level as _LV
import i18n
import webbrowser
import tkinter as tk
from tkinter import ttk

_SRC_SHORT = {
    'JFB':        'JFB',
    'HENRY_MHC':  'Henry',
    'BARNES_NT':  'Barnes NT',
    'BARNES_OT':  'Barnes OT',
    'CLARKE':     'Clarke',
    'PULPIT_COM': 'Pulpit',
    'GILL':       'Gill',
    # ★★★ **스펄전을 이름에 적는다**(2026-09-12 사용자 「Spurgeon treasury
    #   이라고 명시하라」) — 「Treasury」 만으로는 누구 것인지 모른다.
    'TREASURY':   'Spurgeon Treasury',
    'TREASURY_NOTE': 'Spurgeon Notes',
    'TREASURY_HINT': 'Spurgeon Hints',
    'MACLAREN_PSA': 'Maclaren',
    'CALVIN_PSA': 'Calvin',
    'AUGUSTINE_PSA': 'Augustine',
}
#: ★★★ **이름은 영어 하나다**(2026-09-12 사용자 「주석 이름을 오직 영어로
#:   표시하는 방안 어때 — 어차피 모든 주석이 영어 제목이다. **단어 수준이라
#:   이해하기도 쉽다**」). 옳은 판단이다:
#:   ⓐ **번역이 아니라 음역**이다 — 「Matthew Henry」는 나라마다 매튜/매슈로
#:     갈리고, 밖에서 찾으려면 결국 영어 철자가 필요하다(외부로 나가는 화면이다).
#:   ⓑ 13종 × 11언어 = **143칸**을 안 만든다.
#:   ⓒ 실측이 이미 증명했다 — `title_ko` 가 넉 달 동안 **13개 중 6개만** 찼다.
#:   ⚠ 옛 `_SRC_FULL`(「Commentary on the Psalms — John Calvin (1557)」 272px)은
#:     걷었다. 연도·부제는 **어느 주석인지 가르는 데 쓰이지 않는다.**


def src_name(code):
    """화면에 뜨는 주석 이름 — **짧은 영어 하나**. 모르면 코드를 그대로."""
    return _SRC_SHORT.get(code, code)

def _c(role, dflt):
    """테마 색 — 굳은 색을 새로 짓지 않는다(§0)."""
    try:
        import ui_theme
        return ui_theme.C(role) or dflt
    except Exception:
        return dflt


class CommentaryPanel(ttk.Frame):

    def __init__(self, parent, db_path, external_nav=False, ext_lang=None,
                 **kwargs):
        """external_nav — **옛 인자다**(2026-09-12). [주석본문]/[링크] 전환이
        사라져 하는 일이 없다. 부르는 쪽을 안 깨려고 받기만 한다.
        ext_lang — 밖에서 공유하는 LangCombo(설명·주석 통합 콤보). 자기 콤보를
        만들지 않으며, **밖의 콤보를 pack/forget 으로 건드리지 않는다**."""
        super().__init__(parent, **kwargs)
        self._db = db_path
        self._external_nav = bool(external_nav)
        self._ext_lang = ext_lang
        self._verse_id: int | None = None
        self._all_rows: list[dict] = []
        self._cur_transl_code: str = 'KO'
        # ★★★ **보는 단위**(2026-09-12 사용자 「절 단락 장」) — 소스가 아니라
        #   단위를 고른다. 같은 단위 주석은 **한 화면에 이어 붙인다**.
        self._cur_lv: str = _LV.LV_VERSE
        self._show_lv: str = _LV.LV_VERSE
        self._open: set = set()          # 펼쳐 둔 (단위, 소스)
        self._ext_rows: list = []
        self._mode_var = tk.StringVar(value='ORIGINAL')
        self._sources: list[tuple] = []
        self._load_sources()
        self._build()

    # ── 소스 목록 로드 ──────────────────────────────────────────

    def _load_sources(self):
        try:
            with appdb.connect(self._db) as conn:
                self._sources = conn.execute(
                    "SELECT commentary_id, commentary_code "
                    "FROM sys_commentary_source "
                    "WHERE record_status='LIVE' ORDER BY commentary_id"
                ).fetchall()
        except Exception:
            self._sources = []
        self._src_order = {c: i for i, (_id, c) in enumerate(self._sources)}

    # ── UI 구성 ────────────────────────────────────────────────

    def _build(self):
        """**한 줄이다** (2026-09-12 사용자 확정 배치):

            [절][단락][장]  BibleHub  [외부링크 ▾]  ……  [언어 ▾]

        ⚠⚠ 그전에는 줄이 셋이었다 — [주석본문][링크] · 소스 단추 13개 ·
          [구절 주석][페리코프 주석]. 소스 단추만 **729px**, 외부 링크를
          단추로 놓으면 **946px** 이라 왼쪽 칸(754px)에도 안 들어갔다.
        ⚠⚠⚠ **언어 콤보가 화면에 아예 없었다**(2026-09-12 실측) — 부모가
          `self._view_bar` 인데 `external_nav` 면 그것이 `None` 이라 루트에
          붙고 `pack` 도 안 됐다. 살아 있는 두 자리가 다 그 경우다.
        """
        self._src_bar = ttk.Frame(self)
        self._src_bar.pack(fill='x', padx=4, pady=(4, 0))

        # ── 단위 단추 — 차례는 `db_commentary_level.LV_ORDER`(절·단락·장)
        #   ⚠ **없으면 안 그린다**(§0-1). 실측 91%의 절에는 셋이 다 있다.
        #   ⚠ 「책」 단추는 없다 — `entry_level='BOOK'` 항목이 **0개**다.
        self._lv_btns: dict[str, tk.Button] = {}
        for lv in _LV.LV_ORDER:
            self._lv_btns[lv] = tk.Button(
                self._src_bar, text=_LV.LV_LABEL[lv],
                font=('Malgun Gothic', 9), relief='flat', bd=1,
                padx=6, pady=1, cursor='hand2',
                command=lambda v=lv: self._on_level(v))
            # pack 은 `_update_lv_visibility` 가 맡는다
        # ★ **개수는 단추 안에 적는다**(「절 6」) — 따로 라벨을 두면 좁은
        #   패널(420px)에서 한 칸을 더 먹는다.

        # ── 오른쪽 끝: 표시 언어(사용자 「언어콤보 오른쪽 배치」)
        if self._ext_lang is not None:
            self._lang = self._ext_lang          # 밖의 콤보를 건드리지 않는다
        else:
            import lang_combo
            self._lang = lang_combo.LangCombo(
                self._src_bar, db_path=self._db, on_change=self._on_lang_pick,
                width=10, gap=6, pady=0, side='right',
                default_lang=(i18n.get_lang() or 'KO').upper(),
                key='LANGSEL_COMMENTARY')

        # ── 외부 링크 — **콤보 하나**(사용자 「버튼이 좋지만 좁다면 차선책」)
        #   ⚠ 언어로 거르지 않는다(사용자 「외부연결은 언어콤보와 관계없이
        #     모두 표시」) — 대신 목록에 **(EN)·(DE)** 처럼 적는다.
        self._ext_combo = ttk.Combobox(self._src_bar, state='readonly', width=14)
        self._ext_combo.pack(side='right', padx=(6, 0))
        self._ext_combo.bind('<<ComboboxSelected>>', self._on_ext_pick)

        # ── BibleHub 만 단추로(사용자 「Biblehub 버튼 좋다」)
        self._bh_btn = tk.Button(
            self._src_bar, text='BibleHub', font=('Malgun Gothic', 9),
            relief='flat', bd=1, padx=8, pady=1, cursor='hand2',
            command=self._open_biblehub)
        self._bh_btn.pack(side='right', padx=(6, 0))
        # ⚠⚠ **좁은 패널(P4 슬라이딩 420px)에서는 접는다** — 단추를 그대로
        #   두면 잘린다. **콤보에 BibleHub 가 그대로 있으므로 잃는 것이 없다.**
        self._src_bar.bind('<Configure>', self._fit_bar)

        # ── 본문 ─────────────────────────────────────────────
        self._content_f = ttk.Frame(self)
        self._content_f.pack(fill='both', expand=True, padx=4, pady=(2, 0))

        self._empty_lbl = tk.Label(
            self._content_f,
            text=i18n.t('CP_NOCOMMENT', '이 소스에 해당 구절의 주석이 없습니다.'),
            font=('Malgun Gothic', 10), fg='#AAAAAA', bg='#FAFAFA')

        self._txt_frame = ttk.Frame(self._content_f)
        self._txt_frame.pack(fill='both', expand=True)
        txt_scroll = ttk.Scrollbar(self._txt_frame, orient='vertical')
        self._body_txt = tk.Text(
            self._txt_frame, wrap='word', font=('Malgun Gothic', 10),
            relief='flat', bg='#FAFAFA', yscrollcommand=txt_scroll.set,
            state='disabled', padx=8, pady=6, highlightthickness=0)
        try:
            import theme_font
            theme_font.register(self._body_txt, self._db, 'ref')
        except Exception:
            pass
        txt_scroll.config(command=self._body_txt.yview)
        txt_scroll.pack(side='right', fill='y')
        self._body_txt.pack(fill='both', expand=True)
        self._retag()
        self._fill_lang_combo()
        self._update_lv_btns()

    def _fit_bar(self, _e=None):
        """줄이 좁으면 **BibleHub 단추부터** 접는다(콤보에 그대로 있다)."""
        try:
            have = self._src_bar.winfo_width()
            if have <= 1:
                return
            need = sum(w.winfo_reqwidth() + 6
                       for w in self._src_bar.winfo_children()
                       if w.winfo_ismapped())
            shown = self._bh_btn.winfo_ismapped()
            if shown and need > have:
                self._bh_btn.pack_forget()
            elif not shown and need + self._bh_btn.winfo_reqwidth() + 6 <= have:
                self._bh_btn.pack(side='right', padx=(6, 0))
        except Exception:
            pass

    def _retag(self):
        """제목·☆ 의 모양 — **굳은 색을 새로 짓지 않는다**(§0)."""
        t = self._body_txt
        # ★ 주석 이름 강조(2026-09-16 · 1.txt 25 「주석 이름이 오히려 더 작은 것처럼
        #   느껴진다」) — 굵게 + **밑줄**(제목색은 그대로). 본문과 같은 크기라 작아 보였다.
        t.tag_config('cp_hd', font=('Malgun Gothic', 10, 'bold', 'underline'),
                     foreground=_c('fg_title', '#1A3A5C'), spacing1=8,
                     spacing3=2)
        t.tag_config('cp_fav', foreground=_c('warning', '#E67E22'))
        t.tag_config('cp_dim', foreground=_c('fg_dim', '#888888'))

    # ── 이벤트 핸들러 ──    # ── 이벤트 핸들러 ──────────────────────────────────────────

    def _on_level(self, lv: str):
        """단위 단추 — 절·단락·장. **끈끈하다**(절을 옮겨도 선택한 것이 산다)."""
        self._cur_lv = lv
        self._render_content()

    def _toggle_open(self, key):
        """장·단락의 제목을 눌러 펼치고 접는다."""
        if key in self._open:
            self._open.discard(key)
        else:
            self._open.add(key)
        self._render_content()

    def _on_lang_pick(self, cur):
        """표시 언어 콤보 선택 — 변형과 언어를 **한 값으로** 받는다."""
        self._sync_from_combo()
        self._refresh()

    def _fill_lang_combo(self):
        """표시 언어 목록 — **고정이다. DB 를 묻지 않는다** (2026-08-14 확정).

        ⚠ 예전에는 「이 절·이 소스에 어떤 판이 있나」를 물어 목록을 만들었다.
          이 앱은 완성본이 아니라 **지금 없다고 안 보이면 번역이 채워져도 그
          화면은 여전히 한 줄**이다. ⇒ 늘 같은 목록을 올리고 영어로 폴백한다.
        """
        if self._ext_lang is None:
            import lang_combo
            # ★ 주석 탭만 원문 영어를 `Original` 로(2026-09-16 · 1.txt 23 「Modern EN
            #   이 있으니 English 는 무엇인가? 주석 탭 내부에서는 Original 이라고」).
            self._lang.set_items(
                lang_combo.variant_items(),
                names={('ORIGINAL', lang_combo.ORIGINAL_LANG):
                       i18n.t('CP_LANG_ORIGINAL', 'Original')})
        self._sync_from_combo()

    def _sync_from_combo(self):
        cur = self._lang.current()
        if cur:
            self._mode_var.set(cur[0] or 'ORIGINAL')
            self._cur_transl_code = (cur[1] or 'EN').upper()

    # ── 외부 링크 ──────────────────────────────────────────────

    def _fill_ext(self):
        """외부 사이트 콤보 — **언어로 안 거른다**(사용자 확정). 이름 뒤에
        그 사이트의 언어를 적는다: 「Bibleserver (DE)」.
        ⚠ 비면 **잠근다** — 빈 콤보를 눌러도 아무 일이 없으면 고장처럼 보인다."""
        self._ext_rows = (self._fetch_commentary_sites(self._verse_id)
                          if self._verse_id else [])
        items, self._ext_map = [], {}
        for r in self._ext_rows:
            try:
                nm, lg = r['site_name'], (r['lang_code'] or 'EN')
            except Exception:
                continue
            lbl = '%s (%s)' % (nm, lg.upper())
            if lbl in self._ext_map:
                continue
            self._ext_map[lbl] = r['url']
            items.append(lbl)
        self._ext_combo['values'] = items
        if items:
            self._ext_combo.config(state='readonly')
            self._ext_combo.set(i18n.t('CP_EXT_PICK', '외부 링크 ▾'))
        else:
            self._ext_combo.set(i18n.t('CP_EXT_NONE2', '외부 링크 없음'))
            self._ext_combo.config(state='disabled')
        # BibleHub 단추 — 그 절의 주소가 있을 때만
        self._bh_url = None
        for r in self._ext_rows:
            try:
                if r['site_code'] == 'BIBLEHUB':
                    self._bh_url = r['url']
                    break
            except Exception:
                pass
        try:
            self._bh_btn.config(state=('normal' if self._bh_url else 'disabled'))
        except Exception:
            pass

    def _on_ext_pick(self, _e=None):
        """선택하면 연다. ⚠ **선택한 채로 두지 않는다** — 콤보에 이름이 남으면
        「지금 그것을 보고 있다」로 읽힌다."""
        url = self._ext_map.get(self._ext_combo.get())
        self._ext_combo.set(i18n.t('CP_EXT_PICK', '외부 링크 ▾'))
        if url:
            webbrowser.open(url)

    def _open_biblehub(self):
        if getattr(self, '_bh_url', None):
            webbrowser.open(self._bh_url)

    # ── 단추 모양 ──────────────────────────────────────────────

    def _update_lv_btns(self):
        for lv, btn in self._lv_btns.items():
            try:
                if lv == self._show_lv:
                    btn.config(bg='#1A5276', fg='white', relief='solid')
                else:
                    btn.config(bg='#F0F0F0', fg='#333333', relief='flat')
            except tk.TclError:
                pass

    # ── 외부 API ──    # ── 외부 API ──────────────────────────────────────────────

    def forget_have(self):
        """주석을 새로 받았을 때 — **다시 세게** 한다(기억을 버린다)."""
        self._comm_have_n = None

    def load(self, verse_id):
        # ⚠ _view_type 은 여기서 리셋하지 않는다 (2026-08-17 사용자 지적).
        #   1절에서 페리코프를 골라 두고 2절을 누르면 구절 주석으로 튀어 돌아갔다.
        #   사용자가 고른 보기(페리코프/구절)는 절을 옮겨도 유지한다 — 그 절에 그
        #   종류가 없으면 _render_content 가 그때만 있는 쪽을 보인다(저장값은 안 덮음).
        self._verse_id = int(verse_id) if verse_id else None
        self._refresh()

    # ── DB 조회 ───────────────────────────────────────────────

    def _get_variant_lang(self) -> tuple[str, str]:
        mode = self._mode_var.get()
        if mode == 'ORIGINAL':
            return 'ORIGINAL', 'EN'
        elif mode == 'MODERN_EN':
            return 'MODERN_EN', 'EN'
        else:
            return 'TRANSLATED', self._cur_transl_code

    def _query_entries(self) -> list[dict]:
        if not self._verse_id:
            return []
        vid = self._verse_id
        variant, lang = self._get_variant_lang()
        results = []
        # ⚠⚠ 구간 판정은 **`verse_range` 한 문**이다(§verse_range) — `verse_id`
        #   는 차례가 아니라 신원이라 그것으로 재면 「아6:1~6:14」 주석이
        #   계1:1 과 아7·8장에서 함께 뜬다.
        import verse_range as _vr
        try:
            with appdb.connect(self._db) as conn:
                sql = """
                    SELECT ce.entry_id, cs.commentary_code,
                           ce.start_vid, ce.end_vid, ce.entry_level,
                           COALESCE(NULLIF(TRIM(ct.body_text),''), cf.body_text)
                    FROM sys_commentary_entry ce
                    JOIN sys_commentary_source cs
                         ON ce.commentary_id = cs.commentary_id
                    LEFT JOIN sys_commentary_text ct
                         ON ct.entry_id = ce.entry_id
                         AND ct.text_variant=? AND UPPER(ct.lang_code)=?
                    -- ★ **폴백은 언제나 영어** (2026-08-14 설계 확정).
                    --   고른 언어가 아직 없어도 빈 화면을 보이지 않는다.
                    LEFT JOIN sys_commentary_text cf
                         ON cf.entry_id = ce.entry_id
                         AND cf.text_variant='ORIGINAL' AND UPPER(cf.lang_code)='EN'
                    WHERE cs.record_status='LIVE' AND ce.record_status='LIVE'
                      AND (ce.start_vid=?
                           OR (ce.end_vid IS NOT NULL AND {cov}))
                    ORDER BY cs.commentary_id, ce.entry_id
                """.format(cov=_vr.covers_sql('ce', 'start_vid', 'end_vid'))
                for row in conn.execute(
                        sql,
                        [variant, lang, vid] + _vr.covers_args(vid)).fetchall():
                    results.append({
                        'entry_id':  row[0],
                        'src_code':  row[1],
                        'start_vid': row[2],
                        'end_vid':   row[3],
                        'level':     row[4] or _LV.LV_VERSE,
                        'body':      row[5] or '',
                    })
        except Exception:
            pass
        return results

    def _by_level(self) -> dict:
        """단위마다 그 절의 주석을 모은다 → {단위: [row…]}.

        ★★★ **끼리끼리 결합한다**(2026-09-12 사용자). 같은 단위끼리만 이어
          붙여야 읽힌다 — 실측 장 단위는 한 절에 **중앙 35,210자**이고, 절
          단위(1,718자)에 섞으면 그 글에 묻힌다.
        ⚠ 소스 차례는 `sys_commentary_source` 의 차례를 따른다.
        """
        out = {}
        for r in self._all_rows:
            out.setdefault(r.get('level') or _LV.LV_VERSE, []).append(r)
        for v in out.values():
            v.sort(key=lambda r: (self._src_order.get(r['src_code'], 99),
                                  r['entry_id']))
        return out

    def _update_lv_visibility(self, by):
        """있는 단위만 단추를 그린다(§0-1 빈 서랍 금지) → 보일 단위.

        ⚠ **고른 단위를 덮지 않는다** — 이 절에 없어서 다른 것을 보였다고
          해서 선택이 바뀌면, 다음 절에서 되살아나지 않는다(§2026-08-17 의
          「폴백하지 않는다」와 같은 결 — 다만 여기는 *소스*가 아니라
          *단위*라 있는 쪽을 보이는 것이 자연스럽다).
        """
        for lv in _LV.LV_ORDER:
            self._lv_btns[lv].pack_forget()
        for lv in _LV.LV_ORDER:
            rows = by.get(lv)
            if rows:
                self._lv_btns[lv].config(
                    text='%s %d' % (_LV.LV_LABEL[lv],
                                    len({r['src_code'] for r in rows})))
                self._lv_btns[lv].pack(side='left', padx=2)
        show = self._cur_lv
        if not by.get(show):
            show = next((lv for lv in _LV.LV_ORDER if by.get(lv)), self._cur_lv)
        self._show_lv = show
        self._update_lv_btns()
        return show

    def _refresh(self):
        self._all_rows = self._query_entries()
        self._fill_ext()
        self._render_content()
        self._eng_arm()

    def _eng_arm(self):
        """주석 측정 — 보인 주석(분모) · 10초 머문 구절(유효 열람) · 기기 안에만(docs/통계_설계.md §4)"""
        vid = self._verse_id
        codes = {r.get('src_code') for r in (self._all_rows or []) if r.get('src_code')}
        if not vid or not codes:
            return
        try:
            import usage_stats
            for c in codes:
                usage_stats.engage_hit('commseen:%s' % c)
        except Exception:
            return

        def later():
            try:
                if self._verse_id == vid and self._body_txt.winfo_viewable():
                    for c in codes:
                        usage_stats.engage_hit('comm:%s' % c, vid)
            except Exception:
                pass
        try:
            self.after(10000, later)
        except Exception:
            pass

    # ── 즐겨찾기 ──────────────────────────────────────────────

    def _fav_vid(self, row) -> int:
        """즐겨찾기 열쇠로 쓸 절 — **구간이면 그 첫 절**.

        ⚠⚠ 안 그러면 시편 1편의 매튜 헨리를 **1절에서 담은 것과 3절에서 담은
          것이 서로 다른 줄**이 된다(같은 글인데도). 장·단락 주석은 절이
          아니라 구간에 붙어 있기 때문이다.
        """
        return int(row.get('start_vid') or self._verse_id or 0)

    def _is_fav(self, src, row) -> bool:
        vid = self._fav_vid(row)
        if not vid or not src:
            return False
        try:
            with appdb.connect(self._db) as conn:
                return conn.execute(
                    "SELECT 1 FROM user_favorite"
                    " WHERE fav_type='COMMENTARY' AND source_code=?"
                    "   AND verse_id=? AND record_status='LIVE' LIMIT 1",
                    (src, vid)).fetchone() is not None
        except Exception:
            return False

    def _toggle_fav(self, src, row):
        """결합 본문의 **그 제목 옆 ☆** — 소스가 특정되므로 결합 보기에서도 된다.

        ★ 2026-09-12 사용자 설계. 그전에는 줄 오른쪽 끝에 ☆ 가 하나뿐이라
          「지금 고른 소스」가 있어야 눌릴 수 있었다.
        """
        vid = self._fav_vid(row)
        if not vid or not src:
            return
        try:
            with appdb.connect(self._db) as conn:
                ex = conn.execute(
                    "SELECT fav_id FROM user_favorite"
                    " WHERE fav_type='COMMENTARY' AND source_code=?"
                    "   AND verse_id=? AND record_status='LIVE' LIMIT 1",
                    (src, vid)).fetchone()
                if ex:
                    conn.execute("UPDATE user_favorite SET record_status='HIDE'"
                                 "  WHERE fav_id=?", (ex[0],))
                else:
                    conn.execute(
                        "INSERT INTO user_favorite"
                        " (fav_type, target_id, verse_id, source_code, label,"
                        "  record_status)"
                        " VALUES ('COMMENTARY', ?, ?, ?, ?, 'LIVE')",
                        (row.get('entry_id'), vid, src,
                         self._make_fav_label(src, vid)))
                    try:
                        import usage_stats
                        usage_stats.bump('favorite_add')
                    except Exception:
                        pass
        except Exception:
            pass
        self._render_content()

    def _make_fav_label(self, src=None, vid=None) -> str:
        try:
            with appdb.connect(self._db) as conn:
                # ⚠ 책 약명이 `'KO'` 로 **박혀 있었다**(2026-08-14) — 다른 언어
                #   사용자의 즐겨찾기 이름이 한국어로 남았다. 요청→EN→KO 폴백(§0-3).
                _lg = (i18n.get_lang() or 'KO').upper()
                row = conn.execute("""
                    SELECT bn.short_name, bi.chapter, bi.verse
                    FROM bible_index bi
                    JOIN book_names bn
                      ON bi.bcode = bn.book_code
                     AND UPPER(bn.lang_code) IN (?, 'EN', 'KO')
                    WHERE bi.verse_id = ?
                    ORDER BY CASE UPPER(bn.lang_code)
                             WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END
                    LIMIT 1
                """, (_lg, vid or self._verse_id, _lg)).fetchone()
            if row:
                return "%s | %s" % (src_name(src), verse_ref.label(
                    verse_ref.SCOPE_BOOK, row[0], row[1], row[2]))
        except Exception:
            pass
        return "%s | vid=%s" % (src_name(src), vid or self._verse_id)

    def _render_content(self):
        by = self._by_level()
        show = self._update_lv_visibility(by)
        rows = by.get(show) or []
        if not rows:
            self._show_empty()
            return
        self._render_rows(show, rows)

    def _comm_have(self):
        """주석 본문을 **하나라도 갖고 있나** — 한 번만 세고 기억한다.

        ⚠ 절을 옮길 때마다 세면 화면이 멎는다(76,409행).
        """
        n = getattr(self, '_comm_have_n', None)
        if n is None:
            try:
                with appdb.connect(self._db) as c:
                    n = c.execute(
                        "SELECT COUNT(*) FROM sys_commentary_text"
                        " WHERE COALESCE(record_status,'LIVE')='LIVE'"
                        "   AND TRIM(COALESCE(body_text,''))<>''"
                    ).fetchone()[0]
            except Exception:                             # noqa: BLE001
                n = -1
            self._comm_have_n = n
        return n

    def _in_taste_window(self, verse_id):
        """이 절이 **맛보기 구간** 안인가 — 모르면 `None`(판정 안 한다)."""
        try:
            import db_pack_taste as TA
            with appdb.connect(self._db) as c:
                r = c.execute("SELECT bcode, chapter FROM bible_index"
                              "  WHERE verse_id=?", (verse_id,)).fetchone()
            if not r:
                return None
            bc, ch = int(r[0]), int(r[1])
            return any(bc == b and c1 <= ch <= c2 for b, c1, c2 in TA.WINDOW)
        except Exception:                                 # noqa: BLE001
            return None

    def _show_empty(self):
        """**왜 없는지**를 가려 말하고, 받을 수 있으면 길을 낸다.

        ★★★ 한 말로 뭉치면 사용자는 「이 앱에는 주석이 없다」고 읽는다 —
          실제로는 **아직 안 받은 것**일 수 있다(§0-1).
        """
        self._txt_frame.pack_forget()
        self._empty_lbl.pack_forget()
        for w in getattr(self, '_fb_extra', []):
            try:
                w.destroy()
            except Exception:                             # noqa: BLE001
                pass
        self._fb_extra = []

        have = self._comm_have()
        vid = getattr(self, '_verse_id', None) or getattr(self, 'verse_id', None)
        inw = self._in_taste_window(vid) if vid else None
        if have == 0:
            msg = i18n.t('CP_NOT_YET',
                         '주석 본문을 아직 받지 않았습니다.')
            show_get = True
        elif have > 0 and inw is False:
            # ⚠ 맛보기만 받은 상태 — **어디까지 있는지** 말한다
            try:
                import db_pack_taste as TA
                with appdb.connect(self._db) as c:
                    lab = TA.window_label(c)
            except Exception:                             # noqa: BLE001
                lab = ''
            msg = i18n.t('CP_TASTE_ONLY',
                         '맛보기에는 %s 주석만 있습니다.') % lab
            show_get = True
        else:
            msg = i18n.t('CP_NOCOMMENT', '이 구절에는 주석이 없습니다.')
            show_get = False
        self._empty_lbl.config(text=msg)
        self._empty_lbl.pack(expand=True)
        # ⚠ **누를 수 있을 때만 단추를 낸다**(§0-1) — 길이 없으면 안내만.
        go = getattr(self, 'on_download_jump', None)
        if show_get and go:
            import tkinter as _tk
            b = _tk.Button(self._empty_lbl.master, text=i18n.t(
                'PF_GO_DOWNLOAD', '받으러 가기'),
                command=lambda: go(), cursor='hand2', padx=12)
            b.pack(pady=(6, 0))
            self._fb_extra.append(b)

    #: 장·단락은 한 번에 쏟지 않는다 — 제목만 먼저 보인다.
    #:   ⚠ 실측 장 단위는 한 절에 **중앙 35,210자**(A4 스무 쪽)다.
    AUTO_OPEN = (_LV.LV_VERSE,)

    def _render_rows(self, level, rows):
        """같은 단위 주석을 **소스마다 제목 + ☆ + 본문**으로 이어 붙인다.

        ★★★ **결합**(2026-09-12 사용자) — 그전에는 소스를 하나씩 눌러야 했다.
          실측 한 절에 절 단위 주석이 **중앙 2편 1,718자**라 이어 붙여도 읽힌다.
        ★ **제목 옆 ☆** — 소스가 특정되므로 결합 보기에서도 즐겨찾기가 된다.
        ⚠ 장·단락은 **제목만** 먼저. 누르면 그것만 펼친다.
        """
        self._empty_lbl.pack_forget()
        self._txt_frame.pack(fill='both', expand=True)
        t = self._body_txt
        t.config(state='normal')
        for tag in list(t.tag_names()):
            if tag.startswith('cp_h_') or tag.startswith('cp_s_'):
                t.tag_delete(tag)
        t.delete('1.0', 'end')

        groups, order = {}, []
        for r in rows:
            c = r['src_code']
            if c not in groups:
                groups[c] = []
                order.append(c)
            groups[c].append(r)

        auto = level in self.AUTO_OPEN
        for i, code in enumerate(order):
            rs = groups[code]
            opened = auto or (level, code) in self._open
            htag, stag = 'cp_h_%d' % i, 'cp_s_%d' % i
            if not auto:
                t.insert('end', '▾ ' if opened else '▸ ', ('cp_hd', htag))
            t.insert('end', src_name(code) + '  ', ('cp_hd', htag))
            t.insert('end', ('★' if self._is_fav(code, rs[0]) else '☆'),
                     ('cp_fav', stag))
            t.insert('end', '\n')
            t.tag_bind(stag, '<Button-1>',
                       lambda _e, c=code, r=rs[0]: self._toggle_fav(c, r))
            t.tag_bind(stag, '<Enter>',
                       lambda _e, w=t: w.config(cursor='hand2'))
            t.tag_bind(stag, '<Leave>',
                       lambda _e, w=t: w.config(cursor='arrow'))
            if not auto:
                t.tag_bind(htag, '<Button-1>',
                           lambda _e, k=(level, code): self._toggle_open(k))
                t.tag_bind(htag, '<Enter>',
                           lambda _e, w=t: w.config(cursor='hand2'))
                t.tag_bind(htag, '<Leave>',
                           lambda _e, w=t: w.config(cursor='arrow'))
            if opened:
                for j, r in enumerate(rs):
                    if j:
                        t.insert('end', '\n── ── ──\n')
                    t.insert('end', (r['body'] or
                                     i18n.t('MSG_NO_BODY', '(본문 없음)')) + '\n')
            else:
                body = (rs[0].get('body') or '').strip().replace('\n', ' ')
                # ★ 접힌 줄 끝에 **무엇을 하면 되는지**(2026-09-16 · 1.txt 26 「축약된
                #   문장만 있으니까 무엇을 해야 할지 모른다」).
                more = ' … (%s)' % i18n.t('CP_CLICK_MORE', '주석 이름을 클릭하면 더보기')
                t.insert('end', (body[:70] + more + '\n') if body else '\n',
                         ('cp_dim',))
        t.config(state='disabled')
        t.see('1.0')

    #: 주석 화면에 올릴 외부 사이트 갈래.
    #:   ⚠ **언어로 거르지 않는다**(2026-09-12 사용자 「외부연결은 언어콤보와
    #:     관계없이 모두 표시」) — 대신 목록에 「(DE)」처럼 적는다.
    #:   ★ `SERMON` 을 넣었다 — Enduring Word 는 갈래만 SERMON 이고 성격은 주석이다.
    #:   ⚠⚠ **원문대조(INTERLINEAR)를 뺐다**(2026-09-12) — 역본비교 탭 상단으로
    #:     갔다. 두 자리에 두면 어느 것이 제자리인지 알 수 없다.
    #:   ⚠ **원어사전(LEXICON)도 뺐다** — Mechon Mamre 는 내렸고 Sefaria 는
    #:     `COMMENTARY` 로 옮겼다(URL 이 구절 주소라 성격이 주석이다).
    EXT_TYPES = ('COMMENTARY', 'SERMON')

    #: 자리 넓이(scope)마다 어느 절의 줄을 집을까 — 절·장·책
    _SCOPE_SQL = {
        'VERSE':   'm.verse_id = :vid',
        'CHAPTER': ('m.verse_id = (SELECT MIN(b2.verse_id) FROM bible_index b2'
                    '               WHERE b2.bcode=bi.bcode'
                    '                 AND b2.chapter=bi.chapter)'),
        'BOOK':    ('m.verse_id = (SELECT MIN(b3.verse_id) FROM bible_index b3'
                    '               WHERE b3.bcode=bi.bcode)'),
    }

    def _fetch_commentary_sites(self, verse_id: int) -> list:
        """그 절에서 열 수 있는 외부 사이트 → [Row].

        ⚠ `is_alive` 로 거르지 않는다. 그 값에는 세 뜻이 섞여 있다 — 눌러 보고
          확인한 1 · 안 눌러 보고 넣은 1 · **아직 안 본 NULL**. 거르면
          「점검을 시작했다 만 사이트」만 사라진다(2026-08-03 실측).
        """
        if not verse_id:
            return []
        ph = ','.join("'%s'" % t for t in self.EXT_TYPES)
        parts = []
        for scope, cond in self._SCOPE_SQL.items():
            parts.append("""
                SELECT m.url, s.site_name, s.sort_order AS ord, s.media_type,
                       s.site_code, COALESCE(s.lang_code,'EN') AS lang_code
                  FROM sys_ref_site s
                  JOIN bible_index bi ON bi.verse_id = :vid
                  JOIN sys_ref_verse_map m ON m.site_id = s.site_id AND %s
                 WHERE s.scope = '%s' AND s.media_type IN (%s)
                   AND m.map_status != 'EXCLUDED'
                   AND s.is_active = 1 AND s.record_status = 'LIVE'
            """ % (cond, scope, ph))
        # ⚠ `UNION ALL` 뒤의 `ORDER BY` 는 **결과 칸 이름**으로만 된다 —
        #   `sort_order` 를 별칭으로 내야 한다(실측으로 당했다).
        sql = ' UNION ALL '.join(parts) + ' ORDER BY ord, site_name'
        try:
            with appdb.connect(self._db) as conn:
                conn.row_factory = sqlite3.Row
                return conn.execute(sql, {'vid': verse_id}).fetchall()
        except Exception:
            return []

    # ⚠⚠ **옛 [주석본문]/[링크] 갈래와 아래 외부 사이트 띠를 걷었다**
    #   (2026-09-12). 외부 링크가 **같은 줄의 콤보**로 올라왔으므로 갈래가
    #   필요 없다. 살아 있는 두 자리(P2·P4)가 모두 `external_nav=True` 라
    #   그 단추 줄은 애초에 그려지지도 않았다(실측).
    #   ⚠ `_EXT_GROUPS`·`_on_view`·`_load_commentary_sites`·`_ext_bar` 를
    #     함께 걷었다 — 부르는 곳 0곳을 확인했다.


def count_for(db_path, verse_id):
    """주석 탭 배지용 개수 (2026-08-19 사용자 「모든 탭에 개수 — 빈칸 금지」).

    뜻 = **이 절을 덮는 주석 항목(entry) 수** — 전 소스 합.
    WHERE 는 `_query_entries` 와 같은 조각(start_vid=? OR 구간 포함)이다.
    본문 LEFT JOIN 은 행 수를 바꾸지 않으므로 여기서는 뺐다(언어 무관).
    """
    if not verse_id:
        return 0
    try:
        # ⚠⚠ 구간 판정은 **`verse_range` 한 문**이다(§verse_range) — 여기서 다시
        #   쓰면 「아6:1~6:14」 주석이 계1:1 은 물론 **아7·8장에서도** 세어진다.
        #   `verse_id` 는 차례가 아니라 신원이라 `sort_order` 로 견줘야 한다.
        import verse_range as _vr
        vid = int(verse_id)
        with appdb.connect(db_path) as conn:
            r = conn.execute(
                "SELECT COUNT(*) FROM sys_commentary_entry ce "
                "JOIN sys_commentary_source cs "
                "  ON ce.commentary_id = cs.commentary_id "
                "WHERE cs.record_status='LIVE' AND ce.record_status='LIVE' "
                "  AND (ce.start_vid=? OR (ce.end_vid IS NOT NULL AND "
                + _vr.covers_sql('ce', 'start_vid', 'end_vid') + "))",
                [vid] + _vr.covers_args(vid)).fetchone()
            return int(r[0]) if r else 0
    except Exception:
        return 0
