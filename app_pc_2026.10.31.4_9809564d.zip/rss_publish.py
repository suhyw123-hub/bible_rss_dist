"""
rss_publish.py
--------------
관리자 측 RSS 주소록 배포 — sys_rss_feed → 표준 번들 빌드 → 서버 A/B 동일 업로드.

서버 설정·업로드 이력은 관리자 로컬(app_state_admin.json, 비배포)에 저장
  (비밀값을 배포 DB(bible_master.db)에 넣지 않기 위함).

사용:
  servers = get_servers()
  res = publish_to_servers(conn, servers, published_at)   # 양 서버 동일 번들 업로드
  due = due_servers(servers)                               # 자동업로드 대상(기한 도래)
"""

from admin import admin_state as A
import rss_registry as RR
import rss_transport as RT

PANEL = "rss_transfer"
_MAX_LOG = 500


# 관리자 업로드 대상 기본값 — GitHub repo 한 곳에 push(= jsDelivr·raw 양쪽이 자동 서빙)
_ADMIN_DEFAULT = [
    {"label": "GitHub dist", "role": "PRIMARY", "transport": "GIT",
     "location": RT.GH_SSH, "enabled": True},
]


# ── 서버 설정 (admin-local) ──────────────────────────────────────────

R2_SERVER = {"label": "Cloudflare R2", "role": "PRIMARY", "transport": "R2", "location": "hagah-dist",
             "public": "https://dist.hagahtorah.com", "enabled": True}


def get_servers():
    servers = A.get(PANEL, "servers", None)
    if not isinstance(servers, list) or not servers:
        A.set_(PANEL, "servers", _ADMIN_DEFAULT)
        servers = [dict(s) for s in _ADMIN_DEFAULT]
    # ★ 2026-10-30 R2 는 설정 글이 아니라 **열쇠가 있으면 늘 함께** — 켜 둔 관리자 앱이 옛 설정을 다시 저장해 R2 대상이
    #   지워졌고(실측), 그사이 앱 판·공통팩이 GitHub 에만 올라 R2(폰이 먼저 읽는 곳)가 하루 뒤처졌다.
    #   사람이 R2 줄을 「끔」으로 둔 것은 그대로 존중한다(줄이 아예 없을 때만 더한다).
    if not any((s.get("transport") or "").upper() == "R2" for s in servers):
        try:
            if RT.r2_creds():
                servers = list(servers) + [dict(R2_SERVER)]
        except Exception:
            pass
    return servers


def set_servers(servers):
    A.set_(PANEL, "servers", servers)


# ── 업로드 이력 (admin-local, 상한 롤링) ─────────────────────────────

def get_upload_log():
    log = A.get(PANEL, "upload_log", None)
    return log if isinstance(log, list) else []


def _append_log(entry):
    log = get_upload_log()
    log.insert(0, entry)
    if len(log) > _MAX_LOG:
        log = log[:_MAX_LOG]
    A.set_(PANEL, "upload_log", log)


# ── 자동 업로드 설정 ─────────────────────────────────────────────────

def get_auto():
    return {
        "enabled": bool(A.get(PANEL, "auto_enabled", False)),
        "last_published_at": A.get(PANEL, "last_published_at", ""),
    }


def set_auto_enabled(flag):
    A.set_(PANEL, "auto_enabled", bool(flag))


# ── 번들 빌드 ────────────────────────────────────────────────────────

def load_feed_rows(conn):
    """sys_rss_feed → FEEDS_COLUMNS 형태 dict 리스트 (DELETED 묘비행 포함)."""
    rows = []
    cur = conn.execute(
        "SELECT feed_id, feed_url, site_name, lang_code, feed_kind, "
        "       COALESCE(record_status,'LIVE'), COALESCE(updated_at,'') "
        "FROM sys_rss_feed ORDER BY feed_kind, feed_id"
    )
    for fid, url, name, lang, kind, status, upd in cur.fetchall():
        rows.append({
            "feed_id": fid, "feed_url": url or "", "site_name": name or "",
            "lang": (lang or "").upper(), "feed_kind": (kind or "DEVOTIONAL"),
            "record_status": status or "LIVE", "note": "", "updated_at": upd or "",
        })
    return rows


def build_bundle(conn, published_at):
    """배포 번들 생성. → (files: {name:text}, stats: dict)."""
    rows = load_feed_rows(conn)
    feeds_tsv = RR.build_feeds_tsv(rows)
    feeds_html = RR.build_feeds_html(rows, published_at)
    man_entry = RR.make_manifest_entry(RR.FEEDS_FILE, feeds_tsv, published_at, len(rows))
    # manifest 는 저장된 전체 엔트리(items 포함) + 이번 feeds 엔트리 병합
    entries = dict(get_manifest_entries())
    entries[RR.FEEDS_FILE] = man_entry
    manifest = RR.build_manifest_tsv(list(entries.values()))
    files = {
        RR.FEEDS_FILE: feeds_tsv,
        RR.FEEDS_HTML: feeds_html,
        RR.MANIFEST_FILE: manifest,
    }
    stats = {
        "row_count": len(rows),
        "live": sum(1 for r in rows if r["record_status"] == "LIVE"),
        "hide": sum(1 for r in rows if r["record_status"] == "HIDE"),
        "deleted": sum(1 for r in rows if r["record_status"] == "DELETED"),
        "sha1": man_entry["content_sha1"],
        "published_at": published_at,
    }
    return files, stats


def _apply_latest_rules(conn, rows, limit=None):
    """**최신 목록에서 뺄 것을 거르고 게시일순으로 세운다** (2026-09-06 사용자
    지시 「자동배포 시점 이전에 관리자가 모니터링해서 **제외할 것을 지정**」).

    ★ 거르는 자리는 **발행하는 이 문 하나**다 — 화면이 따로 거르면 「보이는
      것과 나가는 것」이 갈린다. 관리자 화면은 같은 문을 불러 미리 본다.
    ⚠ 규칙 모듈이 없거나 터져도 **발행을 막지 않는다** — 그때는 옛 동작
      (안 거르고 그대로)으로 간다.
    """
    try:
        import latest_rules as LR
        keep, _drop = LR.apply(rows, LR.get_rules(conn),
                               allow_sites=LR.registered_names(conn),
                               block_sites=LR.blocked_names(conn))
        keep = LR.sort_rows(keep)
    except Exception as e:
        print('[rss_publish] 최신 규칙 건너뜀:', str(e)[:80])
        keep = rows
    return keep[:int(limit)] if limit else keep


# ★ 2026-10-22 「번역 페이지 열림」 — 피드 주소 → '1'(구글 자동번역 페이지로 열린다) · '0'(안 열린다) · 없으면 모름.
#   배포 표(sys_rss_feed)에 칸을 더하지 않고 관리자 상태(admin_state rss_transfer.xl_ok)에 둔다 — 발행할 때만 쓰는 값이다.
XL_OK_KEY = "xl_ok"


def xl_ok_map():
    d = A.get(PANEL, XL_OK_KEY, None)
    return {str(k): str(v) for k, v in d.items()} if isinstance(d, dict) else {}


def set_xl_ok(feed_url, val):
    """val = '1' · '0' · ''(모름 = 지운다)"""
    d = xl_ok_map()
    if val in ('1', '0'):
        d[feed_url] = val
    else:
        d.pop(feed_url, None)
    A.set_(PANEL, XL_OK_KEY, d)


def _collect_item_rows(conn, per_feed=20, apply_rules=True):
    """LIVE 피드 실시간 fetch → 항목 rows(원본 lang·제목·URL·날짜). 본문/요약 없음(법적 선).
    → (rows, fetched, failed)."""
    import rss_reader as R
    seen = set()          # URL 기준 중복제거
    seen_titles = set()   # 정규화 제목 기준 중복제거 — 같은 글을 여러 피드/카테고리로 올리는 사이트(예 TGC) 대응
    rows = []
    feeds = []
    for kind in ("DEVOTIONAL", "NEWS"):
        feeds += [(fid, name, url, lang, kind) for (fid, name, url, lang) in R.list_feeds(conn, kind)]
    fetched = failed = 0
    xl_ok = xl_ok_map()   # ★ 2026-10-22 사이트마다 「번역 페이지 열림」(관리자가 사이트 관리에서 적는다 · 모르면 빈칸)
    for fid, name, url, lang, kind in feeds:
        try:
            items = R.parse_feed(url, per_feed)
            fetched += 1
        except Exception:
            failed += 1
            continue
        for it in items:
            iu = (it.get("url") or "").strip()
            if not iu or iu in seen:
                continue
            title = (it.get("title", "") or "")[:300]
            tkey = " ".join(title.lower().split())   # 소문자·공백 정규화
            if tkey and tkey in seen_titles:
                continue   # 같은 제목 다른 URL(중복 카테고리 배포) → 1개만
            seen.add(iu)
            if tkey:
                seen_titles.add(tkey)
            rows.append({
                "feed_url": url, "site_name": name, "lang": (lang or "EN").upper(),
                "feed_kind": kind, "title": title,
                "item_url": iu, "published": it.get("published", "") or "",
                "xl_ok": xl_ok.get(url, ""),
            })
    # ★ 텍스트도 같은 규칙을 탄다 — 갈래마다 다르게 거르면 화면이 갈린다.
    if not apply_rules:
        return rows, fetched, failed
    return _apply_latest_rules(conn, rows), fetched, failed


# ── manifest 엔트리 영속(다중 파일: feeds + items 한 manifest) ──────────

def get_manifest_entries():
    d = A.get(PANEL, "manifest_entries", None)
    return d if isinstance(d, dict) else {}


def _save_manifest_entry(name, content_text, published_at, row_count):
    d = get_manifest_entries()
    d[name] = RR.make_manifest_entry(name, content_text, published_at, row_count)
    A.set_(PANEL, "manifest_entries", d)


# ── 업로드 (양 서버 동일 번들) ───────────────────────────────────────

#: 지문 이름을 몇 판까지 남길까 — 그 위는 저장소에서 걷는다
KEEP_VERSIONS = 5


def _dual_names(files, entries):
    """`{논리이름: 글}` → `{논리이름: 글, 지문이름: 글}`.

    ★★★ **두 이름으로 올린다**(2026-09-18 ① 캐시 어긋남).
      · **지문 이름** — 내용이 바뀌면 처음 보는 주소라 CDN 에 옛것이 있을 수
        없다. 새 앱이 이것을 받는다(manifest 의 `path`).
      · **논리 이름** — 옛 앱이 이 이름으로 찾는다. 그대로 남긴다.
    ⚠ 같은 글을 두 번 올리지만 8 KB 짜리다 — 옛 앱을 조용히 끊는 값보다 싸다.
    """
    import rss_registry as _RR
    out = dict(files)
    for logical, text in list(files.items()):
        e = (entries or {}).get(logical)
        p = _RR.entry_path(e) if e else ''
        if p and p != logical:
            out[p] = text
    return out


def _prune_versions(servers, entries, keep=KEEP_VERSIONS):
    """옛 지문 파일을 저장소에서 걷는다 → 걷은 이름들.

    ⚠ 안 걷으면 **날마다 88 KB 씩 영원히** 쌓인다(11언어 × 8 KB).
    ⚠ **지금 manifest 가 가리키는 판은 절대 안 걷는다** — 걷으면 그 순간
      모든 사용자가 404 를 만난다.
    """
    import rss_transport as _RT
    hist = dict(A.get(PANEL, 'ver_history', {}) or {})
    alive = {(e or {}).get('path', '') for e in (entries or {}).values()}
    drop = []
    for logical, e in (entries or {}).items():
        p = (e or {}).get('path', '')
        if not p or p == logical:
            continue
        seq = [x for x in hist.get(logical, []) if x != p]
        seq.insert(0, p)
        hist[logical] = seq[:keep]
        drop += [x for x in seq[keep:] if x and x not in alive]
    if drop:
        for srv in servers or []:
            if not srv.get('enabled', True):
                continue
            tp = _RT.make_transport(srv)
            rm = getattr(tp, 'remove', None)
            if not callable(rm):
                continue
            for name in drop:
                try:
                    rm(name)
                except Exception:                             # noqa: BLE001
                    pass
            if hasattr(tp, 'flush'):
                try:
                    tp.flush()
                except Exception:                             # noqa: BLE001
                    pass
    A.set_(PANEL, 'ver_history', hist)
    return drop


def _upload(servers, files, published_at, stats):
    """files 를 enabled 서버 전부에 업로드 + 이력 기록. → 서버별 결과 리스트."""
    results = []
    for srv in servers:
        if not srv.get("enabled", True):
            continue
        tp = RT.make_transport(srv)
        ok_all, msgs, total = True, [], 0
        for name, text in files.items():
            if isinstance(text, (bytes, bytearray)):
                # ★ 그림(추천몰 썸네일)은 글이 아니다 — put_bytes 로(없는 transport 는 건너뛴다)
                if not hasattr(tp, "put_bytes"):
                    continue
                ok, msg = tp.put_bytes(name, bytes(text))
                total += len(text)
            else:
                ok, msg = tp.put(name, text)
                total += len(text.encode("utf-8"))
            ok_all = ok_all and ok
            if not ok:
                msgs.append(f"{name}: {msg}")
        # GIT 등 지연-커밋 transport: 모든 파일 put 후 1회 flush(commit+push)
        if hasattr(tp, "flush"):
            fok, fmsg = tp.flush()
            ok_all = ok_all and fok
            if not fok:
                msgs.append(f"flush: {fmsg}")
            elif not msgs:
                msgs.append(fmsg)
        entry = {
            "uploaded_at": published_at, "server": srv.get("label", "?"),
            "role": srv.get("role", ""), "location": srv.get("location", ""),
            "files": list(files.keys()), "rows": stats["row_count"], "bytes": total,
            "sha1": stats["sha1"], "status": "OK" if ok_all else "FAIL",
            "message": "; ".join(msgs) if msgs else "all files uploaded",
        }
        _append_log(entry)
        results.append(entry)
    if any(r["status"] == "OK" for r in results):
        A.set_(PANEL, "last_published_at", published_at)
        # jsDelivr 브랜치 캐시 즉시 무효화(미적용 시 클라가 최대 12h 옛 파일 받음)
        try:
            # ⚠ **지문 이름은 purge 하지 않는다** — 처음 보는 주소라 CDN 에
            #   캐시가 있을 수 없다(지울 것이 없다). 논리 이름과 manifest 만.
            RT.purge_jsdelivr([n for n in files.keys()
                               if not RR.looks_versioned(n)])
        except Exception:
            pass
    return results


def publish_to_servers(conn, servers, published_at):
    """피드 주소록 발행 — feeds.tsv/html + manifest 를 양 서버 동일 업로드."""
    files, stats = build_bundle(conn, published_at)
    _save_manifest_entry(RR.FEEDS_FILE, files[RR.FEEDS_FILE], published_at, stats["row_count"])
    return _upload(servers, files, published_at, stats), stats


def _collect_youtube_rows(conn, limit=200, apply_rules=True):
    """관리자 YouTube 수집분 → **게시일 최신 N개** rows(원본 lang·제목·URL·날짜).

    ★★★ **「최신」은 게시일이지 저장 순서가 아니다**(2026-09-06 실측으로 잡았다).
      그전에는 `ORDER BY media_id DESC`(**늦게 담은 것**)라, 서버에 올라간
      `youtube_KO.tsv` 200행의 맨 위가 **2023-05-03 · 2022-10-15 · 2023-01-11**
      이었다 — 3년 전 영상이 「최신 유튜브」로 나가고 있었다.
    ⚠ **넉넉히 뽑아 거른 뒤 자른다** — 규칙이 걸러 낸 만큼 뒤에서 채워야
      200줄이 온전해진다.

    ★★★ **승인(`is_active=1`)을 기다리지 않는다** (2026-09-06 사용자 확정 —
      「구절/용어 **검토를 거치고 나가면 늦다**. 최신컨텐츠는 구절/용어와
       관련이 없어도 **기독교와 관계만 있어도 충분**하다. **기독교 무관
       사이트만 제거**하면 된다」 · 「구절/용어 무관한 것은 **구절/용어
       검토과정에서 걸러내면 된다**」).
      ⚠⚠ 실측이 그 판단을 받쳤다 — 최근 7일 게시분이 **승인 116 대 미검토
        304** 다. 승인을 기다리면 **최신의 4분의 3이 안 나간다.**
      ★★ **두 축이 갈린다** — 같은 자료를 두 소비자가 다르게 쓴다:
        · **최신 콘텐츠**(빠르다) — 기독교 관련이면 나간다. 연결은 안 본다.
        · **구절·용어 화면**(느리다) — 검토·승인으로 연결이 확정된 것만.
      ⚠ 그래도 아무거나 나가지 않는다. 문이 셋 서 있다:
        ⓐ **채널이 관리자가 고른 기독교 채널**이다(등록 126곳)
        ⓑ **수집 자리의 오프토픽 필터**가 이미 걸렀다(`offtopic_skip`)
        ⓒ **최신 규칙**(오래된 것·중복·채널 제외 — `latest_rules`)
      ⚠ 숨긴 것(`record_status<>'LIVE'`)과 채널 제외는 그대로 막힌다.
    """
    import html as _html
    import json as _json
    rows = []
    # ⚠⚠ **휴면(점검 실패)을 뺀다**(2026-09-08) — 최신 발행은 승인을 안
    #   기다리므로(`is_active` 를 안 본다) 죽은 영상이 그대로 나갈 자리였다.
    try:
        import db_media_linkcheck as _LC
        _LC.ensure(conn)
        _nd = ' AND ' + _LC.not_dormant('sys_media_asset')
    except Exception:
        _nd = ''
    # ★★★ **언어마다 따로 뽑는다**(2026-09-12 실측으로 잡았다).
    #   ⚠⚠ 그전에는 `LIMIT limit*3` **하나**로 전부에서 뽑았다. 게시일
    #     내림차순이라 **한국어·영어가 그 자리를 다 먹고** 나머지 아홉 언어는
    #     `youtube_ZH.tsv` 가 거의 빈 채로 나갔다 — 등록 채널이 없어서가
    #     아니라 **뽑는 자리에서 밀린 것**이다.
    #   ★ 언어를 목록에서 읽는다(`lang_config`) — 언어를 늘리면 따라온다.
    try:
        import lang_config as _LG
        _langs = list(_LG.ui_langs())
    except Exception:
        _langs = ['EN', 'KO']
    _per = int(limit) * 3
    _seen = set()
    _raw = []
    for _lg in _langs:
        cur = conn.execute(
            "SELECT title, url, lang_code, media_type, COALESCE(last_checked,''), description "
            "FROM sys_media_asset "
            "WHERE COALESCE(record_status,'LIVE')='LIVE' AND url LIKE '%youtu%' "
            "  AND UPPER(COALESCE(lang_code,'EN'))=? "
            + _nd +
            "ORDER BY COALESCE(json_extract(description,'$.published'),'') DESC, "
            "         media_id DESC LIMIT ?", (_lg.upper(), _per))
        for _r in cur.fetchall():
            if _r[1] in _seen:
                continue
            _seen.add(_r[1])
            _raw.append(_r)
    for title, url, lang, mtype, lc, desc in _raw:
        if not url:
            continue
        chan, pub, coll = "", "", ""
        try:
            d = (_json.loads(desc) or {}) if desc else {}
            chan = d.get("channel", ""); pub = d.get("published", ""); coll = d.get("collected_at", "")
        except Exception:
            pass
        rows.append({
            "feed_url": "", "site_name": (chan.strip() or mtype or "YouTube"),
            "lang": (lang or "EN").upper(), "feed_kind": "YOUTUBE",
            "title": _html.unescape((title or "")[:300]),
            "item_url": url, "published": (pub or lc or ""),
            "collected": (coll or pub or lc or ""),
        })
    if not apply_rules:
        return rows          # ★ 미리보기용 — 무엇이 걸러지는지 보이려면 날 것이 필요하다
    return _apply_latest_rules(conn, rows, int(limit))


# ── 방식 A 언어별 다중파일 발행 (items_<LANG>.tsv / youtube_<LANG>.tsv) ──────
def _build_multilang_files(conn, kind, published_at, api_key=None, progress=None):
    """rows 수집 → 11개 언어 제목번역 → 언어별 파일 + manifest 엔트리. (files, new_entries, combined_sha, stats)."""
    if kind == "items":
        rows, fetched, failed = _collect_item_rows(conn, 20)
    else:
        rows = _collect_youtube_rows(conn, 200); fetched = failed = 0
    xl_tr = 0; xl_inc = False
    # ★ 2026-10-22 발행은 **캐시만** 쓴다 — 번역(구글·제미나이)은 관리자가 운영 ▸ 번역 키 관리 ▸ [번역하기]를 누를 때만
    #   (사용자 「관리자가 번역 버튼을 누를 때에만 작동 · 검증하고 나서 나중에 자동진행」). 모인 제목은 대기열에 쌓는다.
    import cloud_translate as CT
    # ★ 2026-10-22 유튜브 제목 번역은 관리자가 끌 수 있다(번역 및 키관리) — 끄면 대기열에도 안 넣고 원문 제목 그대로
    if kind == "items" or CT.yt_on():
        try:
            CT.enqueue(rows)
            # ★ 2026-10-24 자동 번역 — 대기열의 **새 제목만** 엔진 차례대로 옮긴다(사용자 「새로 수집한 것을 대상으로 번역」).
            #   옮긴 것은 캐시에 남아 아래 translate_rows 가 그대로 쓴다 · 실패해도 발행은 원문으로 나간다.
            try:
                _xo = CT.translate_pending(progress=progress)
                if progress:
                    progress('자동 번역 %d칸%s' % (_xo.get('cells', 0), (' · 멈춤: ' + _xo['stopped']) if _xo.get('stopped') else ''))
            except Exception as _e:                      # noqa: BLE001
                if progress:
                    progress('자동 번역 실패: %s' % str(_e)[:80])
            xl_tr, _calls = CT.translate_rows(rows, None, progress=progress)
            xl_inc = True
        except Exception as e:
            if progress:
                progress(f"번역 중단(부분 반영): {str(e)[:80]}")
            xl_inc = any(any(k.startswith("t_") for k in r) for r in rows)
    prefix = "items" if kind == "items" else "youtube"
    files, new_entries, shas = {}, {}, []
    for lang in RR.XL_LANGS:
        fname = f"{prefix}_{lang}.tsv"
        text = RR.build_items_lang_tsv(rows, lang)
        e = RR.make_manifest_entry(fname, text, published_at, len(rows))
        files[fname] = text; new_entries[fname] = e; shas.append(e["content_sha1"])
    combined = RR.sha1_text("|".join(shas))
    stats = {"row_count": len(rows), "feeds_fetched": fetched, "feeds_failed": failed,
             "sha1": combined, "published_at": published_at,
             "xl_translated": xl_tr, "xl_included": xl_inc}
    return files, new_entries, combined, stats


def _publish_multilang(conn, servers, kind, published_at, skip_unchanged, api_key, progress):
    """언어별 파일 11개 + manifest 발행. combined sha로 전체 무변경 시 skip. → (results, stats, status)."""
    files, new_entries, combined, stats = _build_multilang_files(conn, kind, published_at, api_key, progress)
    if skip_unchanged and A.get(PANEL, f"combined_sha_{kind}", None) == combined:
        return [], stats, "SKIP"
    entries = dict(get_manifest_entries())
    entries.update(new_entries)
    A.set_(PANEL, "manifest_entries", entries)
    A.set_(PANEL, f"combined_sha_{kind}", combined)
    files[RR.MANIFEST_FILE] = RR.build_manifest_tsv(list(entries.values()))
    # ★ 논리 이름 + 지문 이름 둘 다 올린다(위 `_dual_names`)
    results = _upload(servers, _dual_names(files, entries), published_at, stats)
    _prune_versions(servers, entries)
    status = "OK" if any(r["status"] == "OK" for r in results) else "FAIL"
    return results, stats, status


def publish_items(conn, servers, published_at, per_feed=20, api_key=None, progress=None):
    """항목 색인 발행 — 언어별 items_<LANG>.tsv(번역제목·원본lang·URL·날짜) + manifest 업로드(방식 A)."""
    results, stats, _status = _publish_multilang(
        conn, servers, "items", published_at, False, api_key, progress)
    return results, stats


def publish_youtube(conn, servers, published_at, limit=200):
    """최신 유튜브 발행 — 언어별 youtube_<LANG>.tsv + manifest 업로드. 제목 11언어 번역(키 있으면)."""
    results, stats, _status = _publish_multilang(
        conn, servers, "youtube", published_at, False, _admin_api_key(), None)
    return results, stats


#: 묘비(삭제 표식)를 **며칠 동안 싣나**.
#: ★★★ 2026-09-22 (1.txt 10 사용자 「**3년전에 삭제한 것도 계속 푸시해야
#:   하는가**? … 100개가 누적되어도 누적 푸시해야 하는가?」 — 그전에는
#:   **그랬다**. 실측 공지 14행 중 **12행이 묘비**였다).
#: ⚠ 묘비가 필요한 까닭 — 받는 쪽이 **합쳐 넣기**(upsert)라, 지웠다는 말을
#:   안 보내면 사용자 앱에 남는다. 그래서 바로 뺄 수는 없고 **한동안** 싣는다.
#: ⚠⚠ 그 「한동안」이 지나도 안전한 것은, 이제 받는 쪽이 **파일에 없는 공지를
#:   지우기** 때문이다(`rss_reader.sync_announcements`). 묘비는 **옛 앱**을
#:   위한 다리다.
TOMBSTONE_DAYS = 180


def build_announcements_bundle(conn, published_at):
    """살아 있는 공지 + **최근 묘비** → announcements.json + manifest.

    ⚠ 오래된 묘비는 **안 싣는다**(`TOMBSTONE_DAYS`) — 안 그러면 파일이
      단조 증가한다. 빠뜨리는 것이 아니라 **할 일을 다 한 표식**을 걷는 것이다.
    """
    rows = []
    # ⚠⚠ **자리표는 인자로 넘긴다** — 글자로 이어 붙이면 앞뒤 공백을
    #   빠뜨려 `<= 180ORDER BY` 가 된다(실제로 그렇게 냈다).
    cur = conn.execute(
        "SELECT ann_id, lang_code, title, body, published, COALESCE(pin,0), "
        "       COALESCE(record_status,'LIVE'), COALESCE(audience,'ALL'), "
        "       deleted_at "
        "  FROM sys_announcement "
        " WHERE COALESCE(record_status,'LIVE')<>'DELETED'"
        "    OR deleted_at IS NULL"
        "    OR julianday('now') - julianday(deleted_at) <= ? "
        " ORDER BY ann_id, lang_code", (TOMBSTONE_DAYS,))
    for aid, lang, title, body, pub, pin, status, aud, _da in cur.fetchall():
        rows.append({"ann_id": aid, "lang": (lang or "EN").upper(), "title": title or "",
                     "body": body or "", "published": pub or "", "pin": int(pin or 0),
                     "audience": (aud or "ALL").upper(), "record_status": status or "LIVE"})
    js = RR.build_announcements_json(rows)
    man_entry = RR.make_manifest_entry(RR.ANN_FILE, js, published_at, len(rows))
    entries = dict(get_manifest_entries())
    entries[RR.ANN_FILE] = man_entry
    manifest = RR.build_manifest_tsv(list(entries.values()))
    files = {RR.ANN_FILE: js, RR.MANIFEST_FILE: manifest}
    stats = {"row_count": len(rows), "sha1": man_entry["content_sha1"], "published_at": published_at}
    return files, stats


def _mark_announcements_published(conn):
    """발행 성공 후 모든 공지 행을 PUBLISHED(서버 반영 완료)로. 트리/삭제판정 기준."""
    conn.execute("UPDATE sys_announcement SET dist_state='PUBLISHED'")
    conn.commit()


def publish_announcements(conn, servers, published_at):
    """공지사항 발행 — announcements.json + manifest 업로드(빠름, DB만 읽음).
    수시 발생 → DB 통짜 업데이트 아닌 RSS 방식으로 즉시 전달. 성공 시 dist_state='PUBLISHED'."""
    files, stats = build_announcements_bundle(conn, published_at)
    _save_manifest_entry(RR.ANN_FILE, files[RR.ANN_FILE], published_at, stats["row_count"])
    results = _upload(servers, files, published_at, stats)
    if any(r["status"] == "OK" for r in results):
        _mark_announcements_published(conn)
    return results, stats


def build_aimodels_bundle(conn, published_at):
    """AI 모델 목록 → ai_models.json + manifest.

    ★★★ **왜 날마다 나가나**(2026-09-29 299차-3) — 회사가 모델 판을 물리면 그 이름을
      쓰던 사용자는 **그 자리에서 HTTP 404** 다(실측 `gemini-2.5-flash` 「no longer
      available to new users」). 코어팩은 **연 2회**라 그것만으로는 반년을 기다린다.
    ⚠ 담기는 것은 **모델 이름·차례·기본·별칭뿐**이다 — 회사(어댑터)는 코드에 있고
      **키는 한 글자도 안 나간다**(§C-2 · `db_ai_models` selftest 가 잰다).
    ⚠ 표가 비어 있어도 빈 꾸러미를 낸다 — 받는 쪽 `apply_payload` 가 「담을 회사가
      없다」로 거른다(여기서 막으면 왜 안 나갔는지 알 길이 없다 §0-1).
    """
    import db_ai_models as AM
    payload = AM.export_payload(conn)
    # ★ 317차 — **AI 도우미 필수 지침**도 이 꾸러미에 실린다(같은 날마다 길 · 판은 따로).
    try:
        import db_ai_guard as GUARD
        payload['guard'] = GUARD.export_payload(conn)
    except Exception:                                     # noqa: BLE001
        pass
    js = RR.build_aimodels_json(payload)
    rows = sum(len(d.get('models') or []) for d in (payload.get('providers') or {}).values())
    man_entry = RR.make_manifest_entry(RR.AIMODELS_FILE, js, published_at, rows)
    entries = dict(get_manifest_entries())
    entries[RR.AIMODELS_FILE] = man_entry
    manifest = RR.build_manifest_tsv(list(entries.values()))
    files = {RR.AIMODELS_FILE: js, RR.MANIFEST_FILE: manifest}
    stats = {"row_count": rows, "sha1": man_entry["content_sha1"], "published_at": published_at}
    return files, stats


def build_appch_bundle(conn, published_at):
    """앱이 받는 유튜브 채널 번호 → app_channels.txt + manifest(2026-10-24 · 날마다).
    ★ 사용자 기기가 「내가 모은 채널」 가운데 이것과 겹치는 채널은 제 RSS 받기를 멈춘다 — 앱이 이미 받는다."""
    ids = [r[0] for r in conn.execute(
        "SELECT channel_ext_id FROM sys_media_channel WHERE enabled=1 AND COALESCE(record_status,'LIVE')='LIVE' "
        "AND channel_ext_id LIKE 'UC%'")]
    txt = RR.build_app_channels_txt(ids)
    rows = txt.count('\n')
    man_entry = RR.make_manifest_entry(RR.APP_CHANNELS_FILE, txt, published_at, rows)
    entries = dict(get_manifest_entries())
    entries[RR.APP_CHANNELS_FILE] = man_entry
    manifest = RR.build_manifest_tsv(list(entries.values()))
    files = {RR.APP_CHANNELS_FILE: txt, RR.MANIFEST_FILE: manifest}
    return files, {"row_count": rows, "sha1": man_entry["content_sha1"], "published_at": published_at}


def build_appinfo_bundle(conn, published_at):
    """앱 소개 → app_info.json + manifest(2026-10-21 · app_info.py · 글만 · 수 KB)."""
    import app_info as AI_
    js = AI_.export_json(conn)
    rows = len(AI_.export_payload(conn).get('sections') or [])
    man_entry = RR.make_manifest_entry(RR.APPINFO_FILE, js, published_at, rows)
    entries = dict(get_manifest_entries())
    entries[RR.APPINFO_FILE] = man_entry
    manifest = RR.build_manifest_tsv(list(entries.values()))
    files = {RR.APPINFO_FILE: js, RR.MANIFEST_FILE: manifest}
    stats = {"row_count": rows, "sha1": man_entry["content_sha1"], "published_at": published_at}
    return files, stats


def build_shop_bundle(conn, published_at):
    """추천몰 → shop.json + manifest + 썸네일(shopimg_<지문>.jpg · 바이트).

    ★ 썸네일은 **우리 서버**에 둔다 — 바깥 쇼핑몰 그림을 받으면 그 호스트에 사용자
      IP 가 보인다(추적 0). 이름에 지문이 있어 받는 쪽이 확인하고, 같은 그림은 git 이 한 벌로 둔다.
    """
    import db_shop as SH
    payload, imgs = SH.export_payload(conn, with_images=True)
    js = SH.build_json(payload)
    rows = len(payload.get('items') or [])
    man_entry = RR.make_manifest_entry(RR.SHOP_FILE, js, published_at, rows)
    entries = dict(get_manifest_entries())
    entries[RR.SHOP_FILE] = man_entry
    manifest = RR.build_manifest_tsv(list(entries.values()))
    files = {RR.SHOP_FILE: js, RR.MANIFEST_FILE: manifest}
    files.update(imgs)
    stats = {"row_count": rows, "sha1": man_entry["content_sha1"], "published_at": published_at}
    return files, stats


# 종류 → 빌더·파일명 (스케줄러/선택 발행용)
KIND_FILE = {
    "feeds": RR.FEEDS_FILE, "items": RR.ITEMS_FILE,
    "youtube": RR.YOUTUBE_FILE, "announce": RR.ANN_FILE,
    "aimodels": RR.AIMODELS_FILE,
    "appinfo": RR.APPINFO_FILE,
    "shop": RR.SHOP_FILE,
    "appch": RR.APP_CHANNELS_FILE,
}
KIND_ALL = ["feeds", "items", "youtube", "announce", "aimodels", "appinfo", "shop", "appch"]


def _admin_api_key():
    """관리자 로컬(app_state_admin.json)에 저장된 Cloud Translation 키 — '번역 포함'이 켜져 있을 때만.
    스케줄러(db_rss_upload.py)·패널 양쪽이 같은 저장값을 쓰게 함(매일 자동 발행도 번역 포함)."""
    try:
        if A.get('rss_transfer', 'gtranslate_on', True):
            import cloud_translate as _CT
            return _CT.get_key() or None
    except Exception:
        pass
    return None


def _on_servers(servers, fname, text):
    """그 파일이 켜진 서버마다 **실제로** 같은 글로 있나 — 「발행함」 기록만 믿고 건너뛰지 않게(2026-10-21).
    ⚠ 읽을 수 없는 서버(get 이 없음)는 있다고 본다(옛 동작 그대로)."""
    for srv in (servers or []):
        if not srv.get("enabled", True):
            continue
        try:
            tp = RT.make_transport(srv)
        except Exception:                                     # noqa: BLE001
            return False
        if not hasattr(tp, "get"):
            continue
        try:
            got = tp.get(fname)
        except Exception:                                     # noqa: BLE001
            got = None
        if got is None or got != text:
            return False
    return True


def publish_kind(conn, servers, kind, published_at, skip_unchanged=True):
    """종류 1개 발행 — 변경 감지(skip_unchanged): 새 sha가 직전 발행분과 같으면 건너뜀
    (내용 동일한데 published_at만 바뀌어 전 사용자가 재다운로드하는 낭비 방지). → 결과 dict.
    items/youtube 는 방식 A 언어별 다중파일(번역 포함, 전체 무변경 시 skip)."""
    if kind in ("items", "youtube"):
        results, stats, status = _publish_multilang(
            conn, servers, kind, published_at, skip_unchanged, _admin_api_key(), None)
        if status == "SKIP":
            return {"kind": kind, "status": "SKIP", "rows": stats["row_count"], "message": "변경 없음"}
        return {"kind": kind, "status": status, "rows": stats["row_count"],
                "message": "; ".join(f"{r['server']}:{r['status']}" for r in results)}
    builders = {
        "feeds":    lambda: build_bundle(conn, published_at),
        "announce": lambda: build_announcements_bundle(conn, published_at),
        "aimodels": lambda: build_aimodels_bundle(conn, published_at),
        "appinfo":  lambda: build_appinfo_bundle(conn, published_at),
        "shop":     lambda: build_shop_bundle(conn, published_at),
        "appch":    lambda: build_appch_bundle(conn, published_at),
    }
    if kind not in builders:
        return {"kind": kind, "status": "UNKNOWN", "rows": 0, "message": "알 수 없는 종류"}
    files, stats = builders[kind]()
    fname = KIND_FILE[kind]
    prev = get_manifest_entries().get(fname)
    if skip_unchanged and prev and prev.get("content_sha1") == stats["sha1"] and _on_servers(servers, fname, files[fname]):
        return {"kind": kind, "status": "SKIP", "rows": stats["row_count"], "message": "변경 없음"}
    _save_manifest_entry(fname, files[fname], published_at, stats["row_count"])
    # ★ 논리 이름 + 지문 이름 둘 다 올린다(위 `_dual_names`)
    _ent = get_manifest_entries()
    results = _upload(servers, _dual_names(files, _ent), published_at, stats)
    _prune_versions(servers, _ent)
    ok = any(r["status"] == "OK" for r in results)
    if not ok:
        # ★ 2026-10-21 올리지 못했으면 「발행함」 기록을 되돌린다 — 안 그러면 다시 눌러도 「변경 없음」으로 건너뛰어
        #   영영 안 올라간다(사용자 신고 · WinError 5 뒤 실측).
        d = get_manifest_entries()
        if prev:
            d[fname] = prev
        else:
            d.pop(fname, None)
        A.set_(PANEL, "manifest_entries", d)
    if ok and kind == "announce":
        _mark_announcements_published(conn)
    return {"kind": kind, "status": "OK" if ok else "FAIL", "rows": stats["row_count"],
            "message": "; ".join(f"{r['server']}:{r['status']}" for r in results)}


# ── 자가 검증 ─────────────────────────────────────────────────────────
#: ★★★ 2026-09-22 신설 (1.txt 10) — 이 모듈에 자가 검증이 **하나도 없었다**.
#:   묘비 유효기간·받는 쪽 청소는 **조용히 틀리면 사용자 앱에 옛 공지가
#:   영원히 남거나, 반대로 멀쩡한 공지가 사라지는** 자리라 잣대가 필요하다.
def selftest():
    """`python rss_publish.py --selftest`"""
    import sqlite3 as _sq
    import rss_reader as _RD
    ok = [0, 0]

    def t(nm, cond, extra=''):
        ok[1] += 1
        if cond:
            ok[0] += 1
            print('  PASS  %s' % nm)
        else:
            print('  FAIL  %s  %s' % (nm, extra))

    c = _sq.connect(':memory:')
    c.execute("CREATE TABLE sys_announcement(ann_id INTEGER, lang_code TEXT,"
              " title TEXT, body TEXT, published TEXT, pin INTEGER,"
              " record_status TEXT, audience TEXT, dist_state TEXT,"
              " deleted_at TEXT)")
    rows = [
        (1, 'KO', '살아있는 공지', '본문', '2026-09-01', 0, 'LIVE', 'ALL', None, None),
        (2, 'KO', '어제 지운 것', '', '2026-08-01', 0, 'DELETED', 'ALL', None,
         "2026-09-21"),
        (3, 'KO', '아주 오래 전에 지운 것', '', '2023-01-01', 0, 'DELETED',
         'ALL', None, '2023-01-02'),
        (4, 'KO', '언제 지웠는지 모르는 것', '', '2022-01-01', 0, 'DELETED',
         'ALL', None, None),
    ]
    c.executemany('INSERT INTO sys_announcement VALUES(?,?,?,?,?,?,?,?,?,?)',
                  rows)
    c.commit()
    files, stats = build_announcements_bundle(c, '2026-09-22 00:00:00')
    got = {r['ann_id'] for r in RR.parse_announcements_json(files[RR.ANN_FILE])}
    t('살아 있는 공지는 실린다', 1 in got, got)
    t('최근 묘비는 실린다', 2 in got, got)
    t('★ 오래된 묘비는 안 실린다', 3 not in got, got)
    t('★ 지운 때를 모르면 남긴다(조용히 안 빠뜨린다)', 4 in got, got)
    t('유효기간이 값으로 있다', isinstance(TOMBSTONE_DAYS, int)
      and TOMBSTONE_DAYS > 0, TOMBSTONE_DAYS)

    # ── 받는 쪽 — **파일이 정본** ────────────────────────────────────
    u = _sq.connect(':memory:')
    u.execute('CREATE TABLE user_announcement(ann_id INTEGER, lang TEXT,'
              ' title TEXT, body TEXT, published TEXT, pin INTEGER,'
              ' audience TEXT, PRIMARY KEY(ann_id, lang))')
    u.execute('CREATE TABLE user_rss_sync(file_name TEXT PRIMARY KEY,'
              ' last_published_at TEXT, last_sync_at TEXT)')
    # 옛 공지 셋이 이미 깔려 있다 — 그중 둘은 이제 파일에 없다
    u.executemany('INSERT INTO user_announcement VALUES(?,?,?,?,?,?,?)',
                  [(1, 'KO', '옛 제목', '', '', 0, 'ALL'),
                   (3, 'KO', '오래 전에 지운 공지', '', '', 0, 'ALL'),
                   (9, 'KO', '서버에 없는 공지', '', '', 0, 'ALL')])
    u.commit()
    txt = files[RR.ANN_FILE]
    seen = set()
    for r in RR.parse_announcements_json(txt):
        seen.add((int(r['ann_id']), (r.get('lang') or 'EN').upper()))
    for aid, lang in u.execute('SELECT ann_id, lang FROM user_announcement'
                               ).fetchall():
        if (int(aid), (lang or '').upper()) not in seen:
            u.execute('DELETE FROM user_announcement WHERE ann_id=? AND lang=?',
                      (aid, lang))
    left = {r[0] for r in u.execute('SELECT ann_id FROM user_announcement')}
    t('★★ 파일에 없는 공지는 걷힌다', left == {1, 2} or left == {1},
      left)
    t('★ 살아 있는 공지는 남는다', 1 in left, left)
    src = open(_RD.__file__, encoding='utf-8').read()
    t('받는 쪽에 그 청소가 실제로 있다', '_seen' in src, '')
    t('★ 빈 파일이면 안 걷는다(조용한 전멸 금지)',
      'if _seen else []' in src, '')
    u.close()
    c.close()
    print('\nrss_publish selftest %d/%d' % (ok[0], ok[1]))
    return 0 if ok[0] == ok[1] else 1


if __name__ == '__main__':
    import sys as _s
    if '--selftest' in _s.argv:
        _s.exit(selftest())
