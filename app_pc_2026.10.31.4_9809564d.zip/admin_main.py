"""
admin_main.py
-------------
Hagah Dabar 관리자 앱 진입점.
실행: python admin_main.py
"""

import tkinter as tk
from tkinter import ttk
import importlib
import os
import sys


# ★★★ **관리자 언어 콤보는 영어 이름으로 보인다**(2026-09-18 사용자
#   「모든 언어콤보를 영어로 통일」). 생성 자리마다 고치면 반드시 하나가
#   빠지고, 빠진 자리는 **아무 표시 없이** 코드로 남는다(실측 48패널에
#   31곳). ⇒ **패널을 짓고 탭을 열 때 그 아래를 훑는다.**
#   ⚠ 읽는 코드는 한 줄도 안 바뀐다 — `get()` 은 그대로 **코드**를 낸다.
#   ⚠ 언어 콤보가 아니면 아무 일도 안 한다(역본 코드 콤보 보호).
try:
    import lang_ui as _lang_ui
except Exception:                                             # noqa: BLE001
    _lang_ui = None
try:
    import ui_theme as _ui_theme_guard
    _ui_theme_guard.guard_listboxes()   # ★ 317차-21 — 목록 아래 빈 곳 클릭은 아무 일도 없다(관리자도)
except Exception:                                             # noqa: BLE001
    pass


def _name_langs(widget):
    """그 아래 언어 콤보를 영어 이름으로 → 바꾼 개수."""
    if _lang_ui is None or widget is None:
        return 0
    try:
        return _lang_ui.retrofit_tree(widget)
    except Exception:                                         # noqa: BLE001
        return 0


def _paint_edits(widget):
    """편집 칸 색을 입힌다 — 실패해도 화면을 막지 않는다."""
    if widget is None:
        return
    try:
        import ui_theme
        ui_theme.retrofit_edits(widget)
    except Exception as e:                                    # noqa: BLE001
        print('[admin edit-color] %s' % e)


def bind_lang_tabs(root):
    """탭을 열 때마다 훑는다 — **지연 빌드 대비**(§29).

    ⚠ 관리자 화면은 서브탭을 **처음 열 때** 짓는다. 패널을 지을 때만
      훑으면 그 안의 콤보를 영영 못 잡는다.
    ⚠ `after_idle` 로 미룬다 — 탭 이벤트 시점에는 아직 안 그려져 있다.
    ⚠ `bind_class(..., add='+')` — 남이 건 것을 안 걷는다(§ime_hint).
    """
    if _lang_ui is None:
        return
    def _on_tab(ev):
        try:
            w = ev.widget
            w.after_idle(lambda: _name_langs(w))
            # ★ 편집 칸 색도 같은 자리에서 — 서브탭은 **처음 열 때** 지어지므로
            #   패널을 지을 때만 훑으면 그 안의 칸을 영영 못 잡는다.
            w.after_idle(lambda: _paint_edits(w))
        except Exception:                                     # noqa: BLE001
            pass
    try:
        root.bind_class('TNotebook', '<<NotebookTabChanged>>', _on_tab,
                        add='+')
    except Exception:                                         # noqa: BLE001
        pass


sys.path.insert(0, os.path.dirname(__file__))

TREE_STRUCTURE = [
    # ══════════════════════════════════════════════════════════════════
    #  관리자 메뉴 — **일곱 묶음** (2026-08-25 사용자 확정 · 5단계)
    #
    #  ★★★ **가르는 축은 둘뿐이다**(실측):
    #    · **원천** — 수입 71,690편(못 고침) ↔ 우리 글 172,665 ↔ 수집 388,432.
    #      편집 권한·표준 탭·배포 팩·되돌리는 법이 **한꺼번에** 갈린다.
    #    · **닻** — 성경에 붙느냐(구절 26,039·단락 7,086) 홀로 서느냐.
    #    나머지 다섯 축(글의 모양·안쪽 구조·연결 안팎·경로·다국어)은
    #    **부품과 탭이 흡수**하므로 메뉴를 가르지 않는다.
    #
    #  ⚠ **자리만 옮긴다 — 화면 코드는 안 고친다.** 37개가 전부 자리가 있고
    #    **없어지는 것은 없다**(사용자 지시 「개발된 것을 삭제하지 마라」).
    #  ⚠ 옛 묶음 다섯(묵상플랜 관리·콘텐츠 관리·데이터 수집관리·사용자 소통관리·
    #    데이터 관리)은 **축이 섞여 있었다** — 특히 「데이터 관리」에 성경 화면
    #    다섯이 잡동사니로 들어가 있었다.
    #  상세 = 정책자료/관리자화면_체계_의견서.md
    # ══════════════════════════════════════════════════════════════════

    # ① 성경 — 성경 자체와 **성경을 닻으로 삼는** 것
    #    ⚠ 다섯이 「데이터 관리」에 흩어져 있던 것을 모았다.
    #    ⏭ 신설 예정: 장 설명문(`CHAP_DESC` 826편 — 지금 화면이 없다)
    ('성경', [
        ('구절단락 편집기',            'peri_editor'),
        # 구절설명문 편집기 + 구절간 연결관리 → 성경구절관리 통합
        # (2026-08-26 사용자 승인 0.txt 2-1 — 책 개요(BOOK_DESC)·구절 자산·
        #  번역현황·구절 연결을 한 메뉴에서. 옛 두 패널은 부품으로 재사용)
        ('성경구절관리',              'verse_mgr'),
        ('말씀흐름 관리',             'chain_mgr'),
        ('역본 간 구절 차이 진단',      'verse_divergence'),
    ]),

    # ② 서고 — **밖에서 수입한 저작물**. `ORIGINAL` 은 못 고친다(자물쇠 2-A).
    #    ⚠ 여기와 ③은 예전에 「콘텐츠 관리」 한 묶음이었다. 원천이 다르면
    #      편집 권한·일터 탭·배포 팩·되돌리는 법이 전부 달라진다.
    ('서고', [
        ('도서 관리',                 'book_mgr'),
        ('설교집 관리',               'sermon_mgr'),
        ('교리문답 관리',             'catechism_mgr'),
        ('사전 관리',                 'dict_mgr'),
        ('주석 관리',                 'commentary_mgr'),
    ]),

    # ③ 묵상·연구 — **우리가 쓴 글**이고 홀로 선다(사용자가 따라 하는 것)
    ('묵상·연구', [
        ('렌즈묵상 관리',             'lens_mgr'),
        ('묵상플랜 관리',             'plan_mgr'),
        # ⚠ 「묵상질문 편집기」는 메뉴에서 뺐다 (2026-08-27 사용자 확정 —
        #   「플랜의 경우 플랜 내부가 맞다」). 실측 — 플랜 관리 Tab4 가 같은
        #   PLAN_QUESTION(schedule 단위)을 이미 편집한다 = 진짜 중복.
        #   구절 질문(VERS_QUESTION 46,389행)은 층이 다르고 제 집(성경구절관리
        #   ▸ 구절 자산)이 있다 — 건드리지 않았다.
        #   ⚠ 파일·레지스트리는 유지 — 번역 대시보드 점프('question_editor')가
        #     쓰고, 「개발된 것을 삭제하지 마라」(§0-5 선례: 메뉴만 제거).
        ('연구자료 관리',             'research_mgr'),
        ('말씀카드 추천 구절',        'card_verse'),
    ]),

    # ④ 용어·분류·연결 — **다른 콘텐츠에 붙는 축** + 전수 점검
    #    ⚠ 엔티티는 **읽는 자산이면서 분류 축**이다(설명 7,030편 793,732자 ↔
    #      연결 123,733행으로 **가장 넓다**). 남에게 붙는 축이라 한자리에 둔다.
    # ★★★ **「태그 관리」를 걷었다**(2026-09-18 사용자 지시 「태그 이름을
    #   모두 주요용어로 흡수했고, 연결팝업을 통해서 처리할 수 있으므로 태그
    #   관리 화면을 제거하고, 관련된 불필요한 파일들을 모두 제거하라」).
    #   실측 근거 — `sys_tag_asset` **0행** · `TAG_*` 연결 **0건**
    #   (2026-09-01 152차 `db_tag_unify` 가 병합 8 · 엔티티 거울 451 · 삭제 50).
    #   ⚠⚠ 그 화면의 주력 단추 [◈ 선택 승격]이 만들던 것이 **바로 그
    #     엔티티 거울**이라, 놓아 두면 수술을 한 줄씩 되돌린다.
    #   ⚠ **사용자 화면의 태그는 살아 있다** — 개인 태그(`user_tag_asset` 3행)를
    #     `tag_picker` 가 만들고 고치므로 관리자 화면 없이 돈다. 그래서
    #     `tag_picker`(내 용어)·`db_tag_system`(축)은 그대로다.
    # ★★★ **2026-09-18 — 유형 `PHASE`(심리·국면) 신설로 마무리했다**
    #   (사용자 「용어 분류값에 하나 추가하고 주요용어 관리화면에서 모두
    #   관리」). 관리자 심리·국면 용어 열 개 = `db_phase_terms.py` ·
    #   사용자가 만든 것은 **내 용어**로 같은 목록에 오버레이된다.
    #   `tag_derive`·`tag_search_view` 는 참고코드/ 로 옮겼다.
    #    ⚠ 메뉴 이름에 **「용어」가 들어가야 한다** — 79만 자가 여기 있을
    #      이유가 보여야 한다.
    #    ⏭ 신설 예정: 연결 점검(할일 13-44 §연결 점검 · 13-46 · 덮개 13-43 과 함께)
    ('용어·분류·연결', [
        ('주요용어 관리',             'entity_mgr'),
        ('가계도 카드 편집',           'card_editor'),
        # ★ 2026-10-23 둘러보기(폰) 재료 — 연대표 · 믿음의 발자취 · 유적 사진·링크(admin/panel_explore.py)
        ('둘러보기 — 성경 연대표',      'timeline_mgr'),
        ('둘러보기 — 믿음의 발자취',    'footsteps_mgr'),
        ('둘러보기 — 유적 사진·링크',   'sitephoto_mgr'),
        ('둘러보기 — 순례 장소',        'pilgrim_mgr'),     # ★ 2026-10-28 성지순례 2단계(위키데이터 후보 → 승인)
        # ★★★ **연결관리 — 자산 사이를 다루는 한 화면** (2026-08-27 사용자 지시
        #   「연결관리는 **모든 자산을 커버**하는 통합 화면을 만들어야 한다.
        #    **그 화면 하나만으로 전부 해결되어야 한다**」 · 할일 13-53).
        #   ⚠ 화면마다 있는 「연결」 탭은 **지름길로 남긴다** — 그 자산을 보다가
        #     바로 잇는 길이다. **규칙은 `link_picker` 한 곳**이라 갈라지지 않는다.
        ('연결관리',                  'link_center'),
    ]),

    # ⑤ 수집 — **본문이 남의 서버에 있다.** 우리는 링크만 갖는다.
    #    ⚠ 이름을 「데이터 수집관리」 → 「수집」으로. 「데이터」가 다른 묶음과 겹쳤다.
    #    ★★★ **가르는 축 = 무엇을 수집하나**(2026-09-06 사용자 확정 0.txt 1번).
    #      옛 축은 「YouTube 미디어 / 외부 링크·자료」였는데 **한쪽은 매체,
    #      한쪽은 성격**이라 짝이 안 맞았다. 둘 다 「주소를 모으는 일」이고
    #      **모으는 것이 영상이냐 글이냐**만 다르다.
    #    ★ 차례가 곧 업무흐름이다 — **모으고 → 걸고 → 살피고 → 설정**.
    ('수집', [
        ('유튜브 주소 수집기', [
            # ★★★ **단계 축**(2026-09-08 사용자 지시 「전체적인 업무흐름 체계에
            #   맞도록 재구성」 · 「커버리지를 저밀도 앞단으로」 · 「분류관리를
            #   ② 자리로」). 옛 축 「구절이냐 용어냐」는 일이 흐르는 축이 아니라
            #   복제를 낳았다(검토·연결 2 · 커버리지 2 · 완전차단 3 · 삭제 2).
            #   ⚠ 옛 패널 `media`(구절수집관리)·`entity_yt`(용어수집관리)는
            #     레지스트리에만 남긴다 — 메뉴에 올리면 같은 화면이 둘이다.
            #     그 탭들은 `panel_yt_stage` 가 단계 순으로 나눠 담는다.
            ('① 채널 (자동크롤러)',       'media_channel'),
            ('② 분류관리',              'media_classify'),
            ('③ 수집 (자동/수동)',         'yt_collect'),
            ('④ 연결심사',              'yt_review'),
            ('⑤ 커버리지',              'yt_coverage'),
            # ★ 이름 — 「통합 빈틈 수집」 → **「저밀도 집중수집」**
            #   (2026-09-06 사용자). 전체 수집량이 아니라 **자리별 밀도**를
            #   고르게 만드는 일이라 이름이 그것을 말해야 한다.
            ('⑥ 저밀도 집중수집',         'media_gap'),
            ('⑦ 주소 상태점검',          'link_check'),
            ('⑧ 최신 컨텐츠 (발행)',      'latest_content'),
            ('API 키 관리',              'youtube_keys'),
        ]),
        # ★★★ **찬양은 분야가 다르다**(2026-09-10 사용자 지시 「구절/용어
        #   수집/검토/연결기와 **다른 관리자화면**을 만들어야겠다」).
        #   위 수집기의 ④ 연결심사는 「이 영상이 그 구절/용어를 말하나」를
        #   묻는데 찬양에는 그 물음이 없다 — 찬양 영상은 **곡**에 붙고 층이
        #   `곡 → 판 → 영상` 셋이다(§234차). 한 화면에 두면 두 업무흐름이
        #   서로를 가린다.
        ('찬양 수집기', 'worship'),
        # ★ 2026-10-12 기도는 곡·찬양팀이 없다 — 따로 둔다(심사는 영상 심사 화면 그대로 「기도만」)
        ('기도 수집기', 'prayer'),
        ('텍스트 주소 수집기', [
            ('사전연결 사이트',           'entity_sites'),
            ('구절연결 사이트',           'ref_sites'),
            ('최신 텍스트 수집기',        'ref_collector'),
            ('최신 컨텐츠 (텍스트)',       'latest_text'),
            # ★ 2026-10-22 제목 번역 — 유튜브 키와 따로 · 수집과 발행 사이의 일이라 여기(사용자 지시)
            ('번역 및 키관리',             'translate_key'),
        ]),
    ]),

    # ⑥ 소통 — 사용자와 주고받는 것
    ('소통', [
        # ⚠ 「최신 콘텐츠」는 **수집 ▸ 유튜브 주소 수집기**로 옮겼다(2026-09-06
        #   사용자 0.txt 1번). 하는 일이 「모아 온 주소를 살피는 것」이라
        #   소통(사용자와 주고받는 것)이 아니라 수집 쪽 축이다.
        ('공지사항',                  'announce_admin'),
        ('앱 소개 관리',              'app_info'),
        ('FAQ 관리',                  'faq_mgr'),
        ('Q&A 관리',                  'qa_mgr'),
        ('시작화면·말씀카드 사진',     'splash_mgr'),
        ('광고·후원 관리',            'ad_mgr'),
        ('추천몰 관리',               'shop_mgr'),
        # ★ 공동체 방 취소 목록(2026-09-08) — 자동승인 뒤 사후 차단. 화면만 막힌다.
        ('공동체 방 차단',            'room_block'),
    ]),

    # ⑦ 배포 — **내보내는 일** (2026-09-05 신설 · 총체적 정비 3단계)
    #    ★★★ 왜 — ⚠ **점검은 「운영」에 · 배포는 「소통」에** 있어 업무흐름이
    #      끊겼다. 배포 전에 점검하는 것이 규칙인데(§0-5 배포 체크리스트)
    #      두 화면이 다른 묶음에 있으면 그 차례가 눈에 안 보인다.
    #    ⇒ **점검 → 배포 센터** 한 묶음. 차례가 곧 업무흐름이다.
    #    ⚠ **자리만 옮겼다 — 화면 코드는 한 줄도 안 고쳤다.**
    #    ⚠ **배포 센터 9탭을 메뉴로 펴지 않았다**(계획 3-3 재검토):
    #      ⓐ 탭끼리 **서로 점프**한다(배포 현황 → 다른 탭) — 메뉴로 가르면
    #        그 배선이 깨지고 화면을 고쳐야 한다
    #      ⓑ **탭 차례가 이미 업무흐름**이다(§196차 ⑧ · 현황→관리→릴리스
    #        패킹→링크 팩→안내문→이력)
    #      ⓒ 점검(3탭)까지 넣으면 12탭이라 이름만으로 못 찾는다
    #    ⚠ 이름을 「최신 컨텐츠 전송관리」 → **「배포 센터」**로. 무엇을 하는
    #      곳인지 이름이 말해야 한다(코드·문서가 이미 그렇게 부르고 있었다).
    ('배포', [
        # ★ 점검이 먼저다(2026-09-03 사용자 지시 「배포하기 전에 수시로
        #   점검한 후에 배포해야 한다」). 검사 규칙은 db_integrity·db_rules.
        # ★ 이름 = **「배포준비 점검」** (2026-09-06 사용자 0.txt 6 —
        #   「배포를 점검하는 것이 아니라 **배포준비를 위한 점검**」).
        #   배포한 것이 갔는지 보는 곳이 아니라 **배포 대상을 정하기 전에
        #   데이터 정합성을 올리는 준비 단계**다.
        ('배포준비 점검',              'deploy_check'),
        ('배포 센터',                  'rss_transfer'),
        # ★ 모바일 팩은 PC 팩과 따로(2026-10-08 사용자 「Pc 팩과 독립적으로」 · data.md Z-2y).
        ('모바일 팩 관리',             'mobile_pack'),
    ]),

    # ⑧ 운영 — **앱 자체**를 돌보는 일
    #    ⚠ 연결 점검은 여기가 아니라 ⑦이다 — 운영은 앱 관리, 점검은 배포 준비.
    ('운영', [
        ('언어 관리',                  'lang_mgr'),
        ('번역 대시보드',              'trans_dashboard'),
        # ★★★ **AI 작성·번역 — 번역 대시보드 바로 다음** (2026-09-23 277차).
        #   · 「운영」은 이미 **전 자산을 가로지르는** 두 화면을 담고
        #     있다(언어 관리 · 번역 대시보드). 이 화면도 자산 한 종류에
        #     매이지 않으므로 같은 축이다.
        #   · 대시보드가 **「무엇이 비었나」**를 보이고 이 화면이 **「그 빈자리를
        #     채운다」** — 차례가 곰 업무흐름이다(⑦ 배포를 「점검 → 배포」로
        #     세운 것과 같은 문법).
        #   ⚠ 자산 묶음(성경·서고·묵상·연구) 아래에 두지 않았다 — 한 묶음에
        #     넣으면 **나머지 자산에서는 이 화면이 없는 것처럼 보인다.**
        ('AI 작성·번역',              'ai_workshop'),
        ('AI 작업 현황',              'ai_monitor'),        # 2026-10-08 심사·번역 진행 한눈에
        ('데이터 정합성 점검',        'integrity'),        # 2026-10-09 끊김·중복·고립 — 배포준비 점검과 같은 엔진
        ('테이블 관리',                'tbl_mgr'),
        ('매뉴얼 관리',               'manual_mgr'),
        ('접속·이용 통계',            'usage_stats_admin'),
        ('오류·로그',                 'errlog_view'),      # 2026-08-25 신설
    ]),
]

PANEL_REGISTRY = {
    'plan_mgr':       ('admin.panel_plan_manager',     'PlanManagerPanel'),
    # 한 클래스가 세 메뉴를 맡는다 — 도서·설교집·교리문답은 표가 같고 목록만 다르다.
    'book_mgr':       ('admin.panel_book_manager',     'BookManagerPanel', {'mode': 'BOOK'}),
    'sermon_mgr':     ('admin.panel_book_manager',     'BookManagerPanel', {'mode': 'SERMON'}),
    'catechism_mgr':  ('admin.panel_book_manager',     'BookManagerPanel', {'mode': 'REF'}),
    'link_center':    ('admin.panel_link_center',      'LinkCenterPanel'),
    'entity_mgr':     ('admin.panel_entity_manager',   'EntityManagerPanel'),
    'timeline_mgr':   ('admin.panel_explore',          'TimelineAdminPanel'),   # 2026-10-23 둘러보기
    'footsteps_mgr':  ('admin.panel_explore',          'FootstepsAdminPanel'),
    'sitephoto_mgr':  ('admin.panel_explore',          'SitePhotoAdminPanel'),
    'pilgrim_mgr':    ('admin.panel_pilgrim_site',     'PilgrimSiteAdminPanel'),
    'youtube_keys':   ('admin.panel_youtube_keys',       'YouTubeKeysPanel'),
    'media':          ('admin.panel_media',             'MediaPanel'),
    'entity_yt':      ('admin.panel_entity_youtube',    'EntityYouTubePanel'),
    'media_channel':  ('admin.panel_media_channel',     'MediaChannelPanel'),
    'media_gap':      ('admin.panel_media_gap',         'MediaGapPanel'),
    'media_classify': ('admin.panel_media_classify',    'MediaClassifyPanel'),
    # ★ 단계 축 그릇 셋(2026-09-08) — 옛 세 패널의 탭을 단계 순으로 다시 심는다.
    'yt_collect':     ('admin.panel_yt_stage',          'YtCollectPanel'),
    'yt_review':      ('admin.panel_yt_stage',          'YtReviewPanel'),
    'yt_coverage':    ('admin.panel_yt_stage',          'YtCoveragePanel'),
    # ★ 링크 점검을 **독립 화면으로** 올린다(2026-09-06 사용자 0.txt 1번
    #   「유투브 주소 상태점검」). 부품은 그대로이고 `scope='ALL'` 이라
    #   구절·용어·어디에도 안 걸린 것까지 **한 자리에서** 본다.
    #   ★ 2026-09-08 — 두 수집 화면 안의 「링크 점검」 탭을 **걷었다**(사용자
    #     「링크점검은 반드시 하나만」). 점검 흐름(휴면 → 재점검 → 제거)은
    #     `db_media_linkcheck` 가 맡고 매일 작업이 부른다.
    'link_check':     ('admin.panel_link_check', 'LinkCheckTab', {'scope': 'ALL'}),
    # 'entity_wiki':    ('admin.panel_entity_wiki',       'EntityWikiPanel'),   # [Phase 2-G Phase E] deprecate
    'entity_sites':   ('admin.panel_entity_sites',      'EntitySitesPanel'),
    'worship':         ('admin.panel_worship',           'WorshipPanel'),
    'prayer':          ('admin.panel_prayer',            'PrayerPanel'),
    'ref_sites':       ('admin.panel_ref_sites',          'RefSitesPanel'),
    'ref_collector':   ('admin.panel_ref_collector',     'RefCollectorPanel'),
    # 최신 콘텐츠 — **팩과 성격이 다른 자산**(연결을 안 한다 · 시간이 값이다).
    #   왜 팩이 아닌가 · 왜 캐시인가 · 즐겨찾기는 왜 남는가를 그 화면이 말한다.
    'latest_content':  ('admin.panel_latest_content', 'LatestContentPanel',
                        {'kind': 'yt'}),
    # ★ 같은 클래스가 텍스트 갈래도 맡는다(2026-09-06 사용자 0.txt 1번) —
    #   둘로 지으면 「보이는 규칙」이 갈린다.
    'latest_text':     ('admin.panel_latest_content', 'LatestContentPanel',
                        {'kind': 'items'}),
    'rss_transfer':    ('admin.panel_rss_transfer',      'RssTransferPanel'),
    'app_info':        ('admin.panel_app_info',          'AppInfoPanel'),
    'mobile_pack':     ('admin.panel_mobile_pack',       'MobilePackPanel'),
    'announce_admin':  ('admin.panel_announcement_admin', 'AnnouncementAdminPanel'),
    'faq_mgr':         ('admin.panel_faq_manager',        'FaqManagerPanel'),
    'qa_mgr':          ('admin.panel_qa_manager',         'QaManagerPanel'),
    'splash_mgr':     ('admin.panel_splash_center',   'SplashCenterPanel'),  # 사진 + 장면↔구절(2026-09-05)
    'usage_stats_admin': ('admin.panel_usage_stats',      'UsageStatsPanel'),
    'ad_mgr':          ('admin.panel_ad_manager',         'AdManagerPanel'),
    'shop_mgr':        ('admin.panel_shop',               'ShopPanel'),
    'room_block':      ('admin.panel_room_block',         'RoomBlockPanel'),
    'lang_mgr':        ('admin.panel_lang_manager',       'LangManagerPanel'),
    'translate_key':   ('admin.panel_translate_key',      'TranslateKeyPanel'),
    'trans_dashboard': ('admin.panel_trans_dashboard',    'TransDashboardPanel'),
    'ai_workshop':    ('admin.panel_ai_workshop',       'AiWorkshopPanel'),
    'ai_monitor':     ('admin.panel_ai_monitor',        'AiMonitorPanel'),
    'integrity':      ('admin.panel_integrity',         'IntegrityPanel'),
    'errlog_view':      ('admin.panel_errlog',             'ErrLogPanel'),
    'deploy_check':     ('admin.panel_deploy_check',       'DeployCheckPanel'),
    'tbl_mgr':         ('admin.panel_table_manager',     'TableManagerPanel'),
    'question_editor':  ('admin.panel_question_editor',    'QuestionEditorPanel'),
    'peri_editor':      ('admin.panel_peri_editor',        'PeriEditorPanel'),
    'commentary_mgr':   ('admin.panel_commentary_manager', 'CommentaryManagerPanel'),
    'dict_mgr':         ('admin.panel_dict_manager',       'DictManagerPanel'),
    'research_mgr':     ('admin.panel_research_manager',   'ResearchManagerPanel'),
    'card_verse':       ('admin.panel_card_verse',         'CardVersePanel'),
    'lens_mgr':         ('admin.panel_lens_manager',       'LensManagerPanel'),
    'verse_mgr':        ('admin.panel_verse_mgr',          'VerseMgrPanel'),
    # 아래 둘은 메뉴에서 빠졌다(성경구절관리로 통합) — 열쇠는 호환용으로 유지
    'verse_link':       ('admin.panel_verse_link',         'VerseLinkPanel'),
    'verse_assets':     ('admin.panel_verse_assets',       'VerseAssetsPanel'),
    'verse_divergence': ('admin.panel_verse_divergence',   'VerseDivergencePanel'),
    'chain_mgr':        ('admin.panel_chain_manager',      'ChainManagerPanel'),
    'manual_mgr':       ('admin.panel_manual_manager',     'ManualManagerPanel'),
    'card_editor':      ('admin.panel_card_editor',        'CardEditorPanel'),
}


class AdminApp(tk.Tk):
    def __init__(self):
        super().__init__()
        # ★ 오류 기록 지붕 — 화면 콜백에서 터진 오류를 파일에 남긴다(errlog).
        #   ⚠ **인스턴스마다** 걸어야 한다. 여기서 안 걸면 관리자 화면 오류가
        #     콘솔에만 나가고 사라진다.
        try:
            import errlog
            errlog.install(self)
        except Exception as e:
            print('[errlog] %s' % e)
        self.title('Hagah Dabar Admin')
        # ★ 관리자 아이콘 — X자 칼 앞 와인색 방패에 금색 H(0.txt 3번).
        try:
            self.iconbitmap(default=os.path.join(os.path.dirname(
                os.path.abspath(__file__)), 'icons', 'app_admin.ico'))
        except Exception:
            pass
        self.geometry('1400x860')
        self.minsize(900, 600)
        # ★ 언어 콤보는 **영어 이름**으로 — 탭을 열 때마다 훑는다(지연 빌드)
        bind_lang_tabs(self)
        self._panels = {}
        self._current = None
        self._loading_lbl = None   # 임시 '로딩 중' 라벨 (지연 빌드용)
        self._pending_key = None   # 마지막으로 요청된 메뉴 키 (빌드 경합 가드)
        # 활성 탭 진한 회색 — 사용자 앱과 같은 규칙(2026-08-10). 관리자 패널도 탭이 많다.
        # ★ **`apply_ttk` 를 먼저 부른다** (2026-08-15 사용자 지적 「탭을 클릭하면
        #   색상반전 되면서 글자가 보이지 않는다」).
        #   ⚠ 관리자는 `apply_notebook_tabs` 만 부르고 있었다. 그 함수는 색을 넣지만
        #     **윈도우 `vista` 테마는 탭 배경을 조용히 무시한다** — 그런데 글자색은
        #     먹는다. ⇒ **흰 바탕에 흰 글자**가 되어 고른 탭이 사라졌다.
        #   실측(화면 픽셀) — vista: 진한 파랑 **0개** / clam: **1,595개**.
        #   `style.lookup` 은 넣은 값을 그대로 돌려주므로 **설정만 보면 다 된 것처럼
        #   보인다.** 반드시 픽셀로 확인할 것.
        try:
            import ui_theme
            self._dark_pick()                 # ★ 2026-10-24 관리자 어두운 화면(켜 두었으면 그 테마로 시작)
            ui_theme.apply_ttk(self)          # clam 으로 — 이것이 있어야 색이 먹는다
            ui_theme.apply_notebook_tabs(self)
            import tree_cols                  # ★ 2026-10-21 목록 칸 폭은 사람이 끈 대로(철칙)
            tree_cols.install(self)
            # ★★★ **편집 칸 색을 한 번 걸어 둔다** — 앞으로 지어지는 칸까지
            #   화면에 올라오는 순간 따라온다(지연 서브탭 §29).
            ui_theme.bind_edit_class(self)
        except Exception as e:
            print(f'[tab style] {e}')
        # ★★★ **검색칸에 들어가면 그 언어로 바로 친다**(2026-09-11 사용자
        #   「사용자가 **KO를 설정하였다면** 검색창에 입력할 때 **기본 언어를
        #   KO로** … 프랑스어 사용자라면 FR로」 · 「**러시아어는 RU 기본세팅**」).
        #   ★ **기본값일 뿐이다** — 사람이 한/영을 바꾸면 그 칸에서는 그대로 간다.
        #   ⚠ 문은 하나다(`ime_hint.attach_class`) — 화면마다 붙이면 빠뜨린다.
        try:
            import ime_hint
            import i18n as _i18n_ime
            ime_hint.attach_class(self, lambda: _i18n_ime.get_lang())
        except Exception as _e_ime:
            print('[입력기] %s' % _e_ime)
        self._build()

    # ── 어두운 화면(2026-10-24) ──────────────────────────────────────────
    #   켜면 = 사용자 앱에서 고른 화면색(UI_THEME) · 그것이 밝은 색이면 「검정」. 끄면 = 기본 밝은 색.
    #   ⚠ 사용자 앱의 저장값(UI_THEME)은 건드리지 않는다 — 관리자 켬/끔만 따로(ADMIN_DARK).
    #   새로 지은 패널·서브탭은 그때 칠한다(`_paint_new` — 색을 바꾸지 않은 위젯만).
    def _dark_pick(self):
        import ui_theme
        import appdb
        try:
            c = appdb.connect()
            r = c.execute("SELECT config_val FROM user_config WHERE config_key='ADMIN_DARK'").fetchone()
            c.close()
            self._dark = bool(r and r[0] == '1')
        except Exception:
            self._dark = False
        if self._dark:
            name = ui_theme.load()
            ui_theme._active = name if ui_theme.is_dark(name) else 'BLACK'
        else:
            ui_theme._active = ui_theme.DEFAULT
        try:
            if not getattr(self, '_dark_hooked', False):
                self.bind_class('TNotebook', '<<NotebookTabChanged>>',
                                lambda e: self.after(60, self._paint_new), add='+')
                # ★ 2026-10-27 (docs/1.txt 14-1) **누르거나 고른 뒤 지금 화면을 다시 칠한다** — 사용자 앱의 `_paint_after_click` 과 같은 까닭.
                #   항목을 고르면 화면이 `config(fg='#1A5276')` 처럼 박힌 밝은 테마 색을 다시 넣는데, 관리자는 탭 전환에서만 칠해
                #   어두운 화면에서 그 글자가 바탕에 묻혔다(실측 묵상질문 편집기 문맥 줄 대비 2.0).
                for _ev in ('<ButtonRelease-1>', '<<TreeviewSelect>>', '<<ListboxSelect>>', '<<ComboboxSelected>>'):
                    self.bind_all(_ev, self._paint_soon, add='+')
                self._dark_hooked = True
        except Exception:
            pass

    def _paint_soon(self, ev=None):
        """지금 열린 패널을 잠깐 뒤 다시 칠한다 — 화면이 고른 뒤 색을 바꾸는 것은 이 이벤트 **뒤**다.
        어두운 화면 = 테마로 칠하고 대비 맞추기 · 밝은 화면 = 대비 맞추기만(`ui_theme.fix_contrast`)."""
        if getattr(self, '_paint_pending', False):
            return
        self._paint_pending = True

        def _go():
            self._paint_pending = False
            cur = getattr(self, '_current', None)
            if cur is None:
                return
            try:
                import ui_theme
                if getattr(self, '_dark', False):
                    ui_theme.paint(cur)
                ui_theme.fix_contrast(cur)
            except Exception:
                pass
        self.after(150, _go)

    def _paint_new(self):
        try:
            import ui_theme
            if getattr(self, '_dark', False):
                ui_theme.paint(self, only_new=True)
            cur = getattr(self, '_current', None)
            if cur is not None:
                ui_theme.fix_contrast(cur)    # ★ 2026-10-27 밝은·어두운 화면 둘 다 — 안 읽히는 글자만
        except Exception:
            pass

    def _sync_dark_btn(self):
        b = getattr(self, '_dark_btn', None)
        if b is not None:
            b.config(text='☀ 밝게' if getattr(self, '_dark', False) else '◐ 어둡게')

    def _toggle_dark(self):
        import ui_theme
        import appdb
        try:
            c = appdb.connect()
            c.execute("INSERT OR REPLACE INTO user_config(config_key, config_val) VALUES('ADMIN_DARK', ?)",
                      ('0' if getattr(self, '_dark', False) else '1',))
            c.commit()
            c.close()
        except Exception as e:
            print('[admin dark] %s' % e)
        self._dark_pick()
        ui_theme.apply_ttk(self)
        ui_theme.apply_notebook_tabs(self)
        ui_theme.paint(self)
        self._sync_dark_btn()

    def _build(self):
        pw = ttk.PanedWindow(self, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=4, pady=4)

        # 왼쪽 트리
        lf = ttk.Frame(pw, width=200)
        lf.pack_propagate(False)
        pw.add(lf, weight=0)

        # ★ 2026-10-24 사용자 「관리메뉴 라벨 오른쪽에 화면색 토글 · 눈이 부시다 · 다크모드는 사용자 화면 색상이면 충분」
        _hd = ttk.Frame(lf)
        _hd.pack(fill='x', padx=8, pady=(8, 4))
        ttk.Label(_hd, text='관리 메뉴', font=('', 10, 'bold')).pack(side='left')
        self._dark_btn = ttk.Button(_hd, text='', width=8, command=self._toggle_dark)
        self._dark_btn.pack(side='right')
        self._sync_dark_btn()

        # ★ 들여쓰기를 얕게(2026-09-08 사용자 「단계별로 인덴트가 너무 깊이 들어가서
        #   화면이 좌우로 너무 넓다. 작게 해도 충분히 이해할 수 있다」). clam 기본이
        #   한 층에 20px 인데 세 층이라 항목이 60px 안쪽에서 시작했고, 라벨 앞
        #   공백 두 칸이 더해져 있었다. ⇒ 전용 스타일 indent 8(앱 표준 `list_style`
        #   과 같은 값) + 앞 공백 제거. ⚠ 기본 `Treeview` 스타일을 만지지 않는다 —
        #   ttk.Style 은 전역이라 모든 패널의 트리가 함께 바뀐다(§198차).
        try:
            ttk.Style(self).configure('AdminMenu.Treeview', indent=8)
        except Exception:
            pass
        self._tree = ttk.Treeview(lf, show='tree', selectmode='browse',
                                  style='AdminMenu.Treeview')
        self._tree.pack(fill='both', expand=True, padx=4, pady=4)

        def _add_items(parent, items):
            # 항목 = (label, panel_key) 리프 또는 (label, [하위항목...]) 그룹 — 임의 깊이
            for label, val in items:
                if isinstance(val, list):
                    sub = self._tree.insert(parent, 'end', text=label, open=True)
                    _add_items(sub, val)
                else:
                    self._tree.insert(parent, 'end', iid=val, text=label)

        for cat, items in TREE_STRUCTURE:
            node = self._tree.insert('', 'end', text=cat, open=True)
            _add_items(node, items)

        self._tree.bind('<<TreeviewSelect>>', self._on_select)

        # 오른쪽 콘텐츠
        self._right = ttk.Frame(pw)
        pw.add(self._right, weight=1)

        # 기본 화면
        self._placeholder = ttk.Label(
            self._right, text='왼쪽 메뉴에서 항목을 선택하세요.',
            font=('', 11), foreground='gray')
        self._placeholder.pack(expand=True)

        # 첫 항목 자동 선택
        self._later(200, self._select_first)
        # ★ 다 쓴 유튜브 설명문 자동 정리 — 첫 화면이 뜬 뒤에 조용히 한 번.
        #   ⚠ 시작을 막지 않도록 늦게 부른다(무거운 훑기다).
        self._later(3000, self._auto_purge_desc)

    def _select_first(self):
        # 하위그룹이 있을 수 있으므로 실제 패널 키인 첫 리프를 재귀로 탐색
        def first_key(node):
            for ch in self._tree.get_children(node):
                if ch in PANEL_REGISTRY:
                    return ch
                r = first_key(ch)
                if r:
                    return r
            return None
        for cat in self._tree.get_children():
            iid = first_key(cat)
            if iid:
                self._tree.selection_set(iid)
                self._tree.focus(iid)
                self._show(iid)   # selection_set은 이벤트를 발생시키지 않으므로 직접 호출
                break

    def _on_select(self, _):
        sel = self._tree.selection()
        if not sel:
            return
        key = sel[0]
        if key not in PANEL_REGISTRY:
            return
        self._show(key)

    # ── 화면 사이 점프 (2026-08-17, 번역 대시보드용) ──────────────────────────

    # ── 늦춰 부르기 — **창이 닫히면 안 돈다** ────────────────────────
    #: ★★★ 2026-09-11 — 관리자 앱을 **3초 안에 닫으면** `_auto_purge_desc` 가
    #:   **죽은 인터프리터에 대고 돌아** Tcl 오류를 찍었다(실측
    #:   `invalid command name "…_auto_purge_desc"`). 앱이 죽지는 않지만
    #:   **콘솔에 오류가 남아** 진짜 오류와 섞인다.
    #:   ⚠⚠ `after` 는 창이 사라져도 **저절로 안 걷힌다** — 예약한 것을
    #:     **적어 두고 닫을 때 걷는다**. 그리고 콜백도 **아직 있는가**를 본다
    #:     (둘 다 해야 한다 — 걷기 전에 이미 큐에 들어간 것이 있다).
    def _later(self, ms, fn):
        """`after` 를 적어 두고 부른다 — 닫을 때 걷으려고."""
        if not hasattr(self, '_after_ids'):
            self._after_ids = []

        def _run():
            try:
                self._after_ids.remove(tid)
            except (ValueError, AttributeError):
                pass
            # ⚠ 걷기 전에 이미 큐에 들어간 것이 있다 — 여기서 한 번 더 본다
            try:
                if not self.winfo_exists():
                    return
            except Exception:
                return
            fn()

        tid = self.after(ms, _run)
        self._after_ids.append(tid)
        return tid

    def destroy(self):
        """닫을 때 **예약한 것을 걷는다** — 죽은 창에 대고 돌지 않게."""
        for tid in list(getattr(self, '_after_ids', ())):
            try:
                self.after_cancel(tid)
            except Exception:
                pass
        self._after_ids = []
        super().destroy()

    def open_panel(self, key, jump: dict | None = None):
        """다른 패널에서 부르는 공개 진입점 — 메뉴 트리 선택 + 패널 표시.
        `jump` 를 주면 패널이 만들어진 뒤 `receive_jump(jump)` 를 불러 준다
        (그 메서드가 없는 패널은 화면만 연다). 빌드가 after_idle 이라
        폴링으로 기다린다."""
        if key not in PANEL_REGISTRY:
            return
        try:
            if self._tree.exists(key):
                self._tree.selection_set(key)
                self._tree.focus(key)
                self._tree.see(key)
        except Exception:
            pass
        self._show(key)
        if jump is not None:
            self._deliver_jump(key, jump)

    def _deliver_jump(self, key, jump, tries=0):
        panel = self._panels.get(key)
        if panel is None:
            if tries < 50:
                self._later(100, lambda: self._deliver_jump(key, jump,
                                                            tries + 1))
            return
        fn = getattr(panel, 'receive_jump', None)
        if callable(fn):
            try:
                fn(jump)
            except Exception as e:
                print('[open_panel jump] %s' % e)

    def _clear_right(self):
        """오른쪽 영역 정리 — 현재 위젯은 forget(패널은 캐시 보존), 임시 로딩 라벨은 파기."""
        if self._placeholder.winfo_ismapped():
            self._placeholder.pack_forget()
        if self._current is not None:
            try:
                self._current.pack_forget()
            except Exception:
                pass
        lbl = getattr(self, '_loading_lbl', None)
        if lbl is not None:
            try:
                lbl.destroy()
            except Exception:
                pass
            self._loading_lbl = None
        self._current = None

    def _show(self, key):
        """메뉴 선택 → 패널 표시.

        무거운 패널 생성자를 TreeviewSelect 핸들러 안에서 동기 실행하면 클릭 순간
        UI가 얼어붙어 '느리다'고 느껴진다(user_main 1단계와 동일 안티패턴). 대신
        즉시 '로딩 중' 라벨을 띄우고 import+생성은 after_idle로 양보한다 → 클릭이
        바로 반응한다. 이미 빌드된 패널은 즉시 표시(캐시)."""
        self._clear_right()
        self._pending_key = key

        # 이미 빌드된 패널 → 즉시 표시
        if key in self._panels:
            panel = self._panels[key]
            panel.pack(fill='both', expand=True)
            self._current = panel
            self._paint_soon()        # ★ 2026-10-27 (docs/1.txt 14-1) 안 읽히는 글자 맞추기(밝은·어두운 화면 둘 다)
            return

        # 미빌드 → 로딩 라벨 즉시 표시 후 유휴 시간에 빌드
        self._loading_lbl = ttk.Label(
            self._right, text='⏳  로딩 중...', font=('', 12), foreground='#888')
        self._loading_lbl.pack(expand=True)
        self._current = self._loading_lbl
        # ⚠⚠ **같은 패널을 두 번 짓지 않는다** (2026-09-05 실측으로 잡았다 —
        #   `SplashCenterPanel` 이 둘 생겼다). `open_panel` 이 `selection_set`
        #   을 하면 `<<TreeviewSelect>>` 가 발화해 `_show` 가 **또** 불리는데,
        #   그때는 아직 `_panels` 에 없어 `after_idle` 이 두 번 예약된다.
        #   ⇒ 버려진 첫 인스턴스가 DB 연결·이미지를 쥔 채 남는다.
        if not hasattr(self, '_building'):
            self._building = set()
        if key in self._building:
            return
        self._building.add(key)
        self.after_idle(lambda k=key: self._build_panel(k))

    def _build_panel(self, key):
        """유휴 시간에 패널을 import+생성한다. 빌드 중 사용자가 다른 메뉴로 이동했으면
        (`_pending_key` 불일치) 캐시에만 보관하고 화면 표시는 생략한다."""
        try:
            spec = PANEL_REGISTRY[key]
            # ⚠ `(모듈, 클래스)` 또는 `(모듈, 클래스, {인자})` — 셋째가 있으면 넘긴다.
            #   한 클래스가 여러 메뉴를 맡을 때 쓴다(도서·설교집·교리문답).
            mod_path, cls_name = spec[0], spec[1]
            kw = spec[2] if len(spec) > 2 else {}
            mod = importlib.import_module(mod_path)
            cls = getattr(mod, cls_name)
            self._panels[key] = cls(self._right, **kw)
            getattr(self, '_building', set()).discard(key)
            if getattr(self, '_dark', False):    # 어두운 화면이면 새로 지은 패널도 칠한다
                self.after_idle(lambda: self._paint_new())
        except Exception:
            getattr(self, '_building', set()).discard(key)
            import traceback
            tb = traceback.format_exc()
            print(tb)   # PowerShell 콘솔에 출력
            if self._pending_key == key:
                self._clear_right()
                err = tk.Text(self._right, fg='red', bg='#fff0f0',
                              font=('Consolas', 9), wrap='word')
                err.insert('1.0', tb)
                err.config(state='disabled')
                err.pack(fill='both', expand=True, padx=10, pady=10)
                self._current = err
            return

        # ★ 다른 관리 화면으로 보내는 길 — **늦은 바인딩**(2026-09-03).
        #   레지스트리는 정적 dict 라 콜백을 못 담는다. 만든 뒤에 심는다.
        #   ⚠ 그 속성을 가진 패널에만 — 없는 패널은 건드리지 않는다.
        try:
            _p = self._panels.get(key)
            if _p is not None and hasattr(_p, 'on_open_panel'):
                _p.on_open_panel = self.open_panel
        except Exception:
            pass

        # ★ 언어 콤보를 영어 이름으로 — 패널을 짓고 나서 한 번
        #   (서브탭 안쪽은 `bind_lang_tabs` 가 맡는다)
        _name_langs(self._panels.get(key))

        # ★★★ **편집 칸 색**(2026-09-25 사용자 「수정가능한 텍스트 상자는
        #   바탕색을 밝은 색으로 고정하라」) — 고칠 수 있는 칸은 밝게,
        #   읽기만 하는 칸은 어둡게. 실측 관리자 `tk.Text` 106칸이라
        #   자리마다 고치면 반드시 몇이 빠진다(§272차 ⑥ 과 같은 판단).
        _paint_edits(self._panels.get(key))

        # 빌드 완료 — 사용자가 여전히 이 메뉴를 보고 있을 때만 표시
        if self._pending_key == key:
            self._clear_right()
            panel = self._panels[key]
            panel.pack(fill='both', expand=True)
            self._current = panel
            self._paint_soon()        # ★ 2026-10-27 (docs/1.txt 14-1) 안 읽히는 글자 맞추기(밝은·어두운 화면 둘 다)

    # ── 다 쓴 유튜브 설명문 자동 정리 ────────────────────────────────────────
    def _auto_purge_desc(self):
        """관리자 앱을 켤 때 **하루 한 번** 다 쓴 설명문을 지운다.

        ★★★ 사용자 지시(2026-09-04) — 「검토가 승인되면 설명문이 **다음날
          자동으로** 삭제되는가? **관리자가 아무것도 하지 않아도** 자동처리
          되는가?」 ⇒ 그렇게 만든다.
        ⚠ **PC 를 켜는 순간이 아니라 「관리자 앱을 켤 때」다** — `sys_media_asset`
          은 관리자 DB 라 사용자 PC 에는 없다(팩에도 이제 설명문이 안 실린다).
        ★ 근거는 YouTube API 저장 원칙 — 식별자를 뺀 메타데이터는 30일 안에
          갱신하거나 지운다. 우리는 다시 받을 이유가 없으니 지우는 쪽이다.
        ⚠ **조용히 지우지 않는다** — 몇 건을 지웠는지 콘솔·errlog 에 남긴다.
        ⚠ 하루 한 번 — 앱을 여러 번 켜도 같은 날은 건너뛴다(무거운 훑기다).
        """
        try:
            from datetime import date
            try:
                from admin import admin_state
            except ModuleNotFoundError:
                import admin_state
            import appdb
            import db_media_range as MR
            today = date.today().isoformat()
            if admin_state.get('purge_desc', 'last') == today:
                return
            conn = appdb.connect('bible_master.db')
            try:
                n, ids = MR.purge_desc(conn, days=30, dry_run=False)
            finally:
                conn.close()
            admin_state.set_('purge_desc', 'last', today)
            if n:
                print('[설명문 정리] 승인·30일 지난 %d건에서 유튜브 설명문을'
                      ' 지웠습니다(연결·제목은 그대로).' % n)
        except Exception as e:
            print('[설명문 정리] %s' % e)


if __name__ == '__main__':
    app = AdminApp()
    app.mainloop()
