# -*- coding: utf-8 -*-
"""PC 「나의 묵상 ▸ 때에 맞는 말씀」 서브탭(2026-10-29 · docs/1.txt 3 · 사용자 「나의 묵상 탭 내부에 서브탭」).

★ 폰과 같은 자료·규칙(db_verse_topic) — 큰 갈래 넷 → 주제 → 구절(본문까지).
★ 위 띠 = 갈래 단추 넷 … [+ 구절](약명 칸) [빼기] [복사] · 왼쪽 = 주제 목록 + [새 주제][이름 바꾸기][지우기][뺀 구절 되살리기] ·
  오른쪽 = 구절 목록(여럿 선택) + 아래 고른 구절의 본문(복사될 글 그대로).
★ 앱 자료는 지우지 않는다 — 사용자 것은 개인 DB(덮개) · 폰과 동기화(mobile_sync 사본 · 사건 VERSE_TOPIC).
"""
import tkinter as tk
from tkinter import ttk

import appdb
import db_card_verse as CV
import db_verse_topic as VT
import i18n

try:
    import ui_theme
except Exception:                                               # noqa: BLE001
    ui_theme = None


def _C(role, d):
    """색 = 테마 역할(없는 역할이면 빈 글자가 오므로 폴백) — 하드코딩 금지 규칙."""
    try:
        return ui_theme.C(role) or d
    except Exception:                                           # noqa: BLE001
        return d


def _t(k, d):
    try:
        return i18n.t(k, d)
    except Exception:                                           # noqa: BLE001
        return d


def _font(w, db, delta=0, bold=False):
    try:
        import theme_font
        theme_font.register(w, db, 'base', size_delta=delta)
        if bold:
            import tkinter.font as tkf
            ff = tkf.Font(font=w.cget('font'))
            w.configure(font=(ff.actual('family'), ff.actual('size'), 'bold'))
    except Exception:                                           # noqa: BLE001
        pass


GRP_NAME = {'BLESS': ('M_VT_G_BLESS', '축복'), 'COMFORT': ('M_VT_G_COMFORT', '위로'),
            'CHURCH': ('M_VT_G_CHURCH', '교회'), 'MEMO': ('M_VT_G_MEMO', '암송')}
# 화면에 보이는 갈래 — 암송(MEMO)은 2026-10-30 별도 기능으로 뺐다(docs/1.txt 5 · 자료는 그대로)
SHOWN = [g for g in VT.GROUP_KEYS if g != 'MEMO']


class VerseTopicView(tk.Frame):
    def __init__(self, parent, db_path, lang_getter=None, ver_getter=None, **kw):
        self._bg = _C('bg', '#F4F6F8')
        super().__init__(parent, bg=self._bg, **kw)
        self.db = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.ver_getter = ver_getter or (lambda: 'KRV')
        self._grp = 'BLESS'
        self._key = None
        self._topics = []
        self._rows = []
        with appdb.connect(self.db) as c:
            VT.ensure(c)
            c.commit()
        self._build()
        self.refresh()

    # ── 짓기 ──────────────────────────────────────────────────────
    def _btn(self, host, text, cmd, side='left', strong=False):
        b = tk.Label(host, text=text, cursor='hand2', padx=10, pady=2, relief='solid', bd=1,
                     bg=_C('accent', '#1A5276') if strong else _C('panel', '#FFFFFF'),
                     fg=_C('fg_on_dark', '#FFFFFF') if strong else _C('accent', '#1A5276'))
        b.pack(side=side, padx=(0, 6) if side == 'left' else (6, 0), pady=6)
        _font(b, self.db, bold=strong)
        b.bind('<Button-1>', lambda _e: cmd())
        return b

    def _build(self):
        pnl = _C('panel', '#FFFFFF')
        top = tk.Frame(self, bg=pnl)
        top.pack(fill='x')
        self._gbtn = {}
        for g in SHOWN:
            k, d = GRP_NAME[g]
            b = tk.Label(top, text=_t(k, d), cursor='hand2', padx=12, pady=3, bd=1, relief='solid')
            b.pack(side='left', padx=(10 if g == 'BLESS' else 0, 4), pady=6)
            _font(b, self.db)
            b.bind('<Button-1>', lambda _e, g=g: self._pick_grp(g))
            self._gbtn[g] = b
        self._copy_btn = self._btn(top, _t('M_COPY', '복사'), self._copy, side='right', strong=True)
        tk.Frame(top, bg=pnl, width=12).pack(side='left')
        self._ref_e = tk.Entry(top, width=14, relief='solid', bd=1, bg=pnl, fg=_C('fg', '#2C3E50'))
        self._ref_e.pack(side='left', ipady=3)
        _font(self._ref_e, self.db)
        self._ref_e.bind('<Return>', lambda _e: self._add())
        self._add_btn = self._btn(top, _t('M_VT_ADD_PC', '+ 구절'), self._add)

        pw = ttk.PanedWindow(self, orient='horizontal')
        pw.pack(fill='both', expand=True)
        lf = tk.Frame(pw, bg=self._bg)
        ab = tk.Frame(lf, bg=self._bg)
        ab.pack(fill='x', padx=6)
        self._btn(ab, _t('M_VT_NEW', '새 주제'), self._new)
        self._btn(ab, _t('M_VT_RENAME_S', '이름 바꾸기'), self._rename)
        self._btn(ab, _t('M_VT_HIDE_S', '지우기'), self._hide)
        self._tv_t = ttk.Treeview(lf, show='tree', selectmode='browse')
        self._tv_t.pack(fill='both', expand=True, padx=6, pady=(0, 6))
        self._tv_t.bind('<<TreeviewSelect>>', lambda _e: self._on_topic())
        pw.add(lf, weight=1)
        rf = tk.Frame(pw, bg=self._bg)
        vb = tk.Frame(rf, bg=self._bg)
        vb.pack(fill='x', padx=6)
        self._del_btn = self._btn(vb, _t('M_VT_DEL', '빼기'), self._remove)
        self._rest_btn = self._btn(vb, _t('M_VT_RESTORE', '뺀 구절 되살리기'), self._restore)
        self._say_l = tk.Label(vb, text='', bg=self._bg, fg=_C('fg_dim', '#5D6D7E'), anchor='w')
        self._say_l.pack(side='left', fill='x', expand=True)
        _font(self._say_l, self.db, delta=-1)
        self._tv_v = ttk.Treeview(rf, columns=('ref', 'note'), show='headings', selectmode='extended', height=10)
        self._tv_v.heading('ref', text=_t('MYPATH_VF_REF', '참조'))
        self._tv_v.heading('note', text=_t('M_VT_NOTE', '설명'))
        self._tv_v.column('ref', width=130, stretch=False)
        self._tv_v.column('note', width=320)
        self._tv_v.pack(fill='both', expand=True, padx=6, pady=(0, 4))
        self._tv_v.bind('<<TreeviewSelect>>', lambda _e: self._show_body())
        self._body = tk.Text(rf, height=9, wrap='word', relief='solid', bd=1, bg=pnl, fg=_C('fg', '#2C3E50'),
                             padx=8, pady=6)
        self._body.pack(fill='both', expand=False, padx=6, pady=(0, 6))
        _font(self._body, self.db)
        pw.add(rf, weight=3)
        self._pw = pw
        self.after(60, lambda: self._pw.sashpos(0, 300) if self._pw.winfo_width() > 600 else None)

    # ── 자료 ──────────────────────────────────────────────────────
    def _lang(self):
        try:
            return (self.lang_getter() or 'KO').upper()
        except Exception:                                       # noqa: BLE001
            return 'KO'

    def refresh(self):
        for g, b in self._gbtn.items():
            on = g == self._grp
            b.configure(bg=_C('accent', '#1A5276') if on else _C('panel', '#FFFFFF'),
                        fg=_C('fg_on_dark', '#FFFFFF') if on else _C('fg', '#2C3E50'))
        with appdb.connect(self.db) as c:
            self._topics = VT.topics(c, self._lang(), self._grp)
        if not any(t['key'] == self._key for t in self._topics):
            self._key = self._topics[0]['key'] if self._topics else None
        tv = self._tv_t
        tv.delete(*tv.get_children())
        for t in self._topics:
            tv.insert('', 'end', iid=t['key'], text=t['name'])
        if self._key:
            tv.selection_set(self._key)
            tv.see(self._key)
        self._load_verses()

    def _topic(self):
        return next((t for t in self._topics if t['key'] == self._key), None)

    def _load_verses(self):
        tv = self._tv_v
        tv.delete(*tv.get_children())
        self._rows = []
        if self._key:
            with appdb.connect(self.db) as c:
                for v in VT.verses(c, self._key, self._lang()):
                    lb = CV.label(c, v['ref'], self._lang())
                    self._rows.append(dict(v, label=lb))
                    tv.insert('', 'end', iid=v['ref'], values=(lb, v['note']))
        t = self._topic()
        self._rest_btn.configure(state='normal')
        if t is None or t['mine']:
            self._rest_btn.pack_forget()
        elif not self._rest_btn.winfo_ismapped():
            self._rest_btn.pack(side='left', padx=(0, 6), pady=6, after=self._del_btn)
        if not self._rows:
            self._say(_t('M_VT_NO_VERSE_PC', '구절이 없습니다 — 위 칸에 약명을 적고 [+ 구절]') if t else
                      _t('M_VT_EMPTY_PC', '이 갈래에 주제가 없습니다 — [새 주제]'))
        else:
            self._say(_t('M_VT_HINT_PC', '구절을 선택하면(Ctrl·Shift 로 여럿) 아래에 본문 — [복사]'))
        self._show_body()

    def _picked(self):
        sel = set(self._tv_v.selection())
        return [r for r in self._rows if r['ref'] in sel]

    def _text(self):
        rows = self._picked()
        if not rows:
            return ''
        with appdb.connect(self.db) as c:
            body = VT.share_text(c, [r['ref'] for r in rows], '[%s]' % self._topic()['name'] if self._topic() else '',
                                 self.ver_getter() or 'KRV')
        return body

    def _show_body(self):
        b = self._body
        b.configure(state='normal')
        b.delete('1.0', 'end')
        b.insert('1.0', self._text())
        b.configure(state='disabled')

    def _say(self, s):
        self._say_l.configure(text=s)

    # ── 동작 ──────────────────────────────────────────────────────
    def _pick_grp(self, g):
        self._grp = g
        self._key = None
        self.refresh()

    def _on_topic(self):
        sel = self._tv_t.selection()
        if sel and sel[0] != self._key:
            self._key = sel[0]
            self._load_verses()

    def _copy(self):
        s = self._text()
        if not s:
            self._say(_t('M_VT_PICK_FIRST', '먼저 구절을 선택하세요.'))
            return
        self.clipboard_clear()
        self.clipboard_append(s)
        self._say(_t('M_VT_COPIED', '복사했습니다.'))

    def _ref_of(self, text):
        """약명 글(「요 3:16-18」) → 좌표 「책:장:절[-끝]」 · 장을 넘는 구간은 받지 않는다."""
        with appdb.connect(self.db) as c:
            hits = __import__('scripture_ref').find(c, text, self._lang())
            if not hits:
                return None
            a, b = hits[0][0], hits[0][1] or hits[0][0]
            ra = c.execute('SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?', (a,)).fetchone()
            rb = c.execute('SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?', (b,)).fetchone()
        if not ra or not rb or ra[:2] != rb[:2]:
            return None
        return '%d:%d:%d' % ra + ('-%d' % rb[2] if rb[2] != ra[2] else '')

    def _add(self):
        if not self._key:
            self._say(_t('M_VT_PICK_TOPIC', '먼저 주제를 선택하세요.'))
            return
        txt = self._ref_e.get().strip()
        ref = self._ref_of(txt) if txt else None
        if not ref:
            self._say(_t('M_VT_BAD_REF', '구절을 읽지 못했습니다 — 예) 요 3:16 · 시 23:1-3'))
            return
        with appdb.connect(self.db) as c:
            r = VT.add_verse(c, self._key, ref)
        self._ref_e.delete(0, 'end')
        self._load_verses()
        self._say(_t('M_VT_ADDED', '더했습니다.') if r else _t('M_VT_SAME', '이미 있는 구절입니다.'))

    def _remove(self):
        rows = self._picked()
        if not rows:
            self._say(_t('M_VT_PICK_FIRST', '먼저 구절을 선택하세요.'))
            return
        with appdb.connect(self.db) as c:
            for r in rows:
                VT.remove_verse(c, self._key, r['id'])
        self._load_verses()

    def _ask(self, title, init=''):
        """이름 묻기 — 작은 창 하나(위에 [확인])."""
        w = tk.Toplevel(self)
        w.title(title)
        w.transient(self.winfo_toplevel())
        out = {'v': None}
        top = tk.Frame(w, bg=_C('panel', '#FFFFFF'))
        top.pack(fill='x')
        e = tk.Entry(top, width=28)
        e.pack(side='left', padx=8, pady=8, ipady=3)
        e.insert(0, init)
        _font(e, self.db)

        def ok(_e=None):
            out['v'] = e.get().strip()
            w.destroy()
        ob = tk.Label(top, text=_t('M_OK', '확인'), cursor='hand2', padx=10, pady=2,
                      bg=_C('accent', '#1A5276'), fg=_C('fg_on_dark', '#FFFFFF'))
        ob.pack(side='left', padx=(0, 8))
        ob.bind('<Button-1>', ok)
        e.bind('<Return>', ok)
        e.bind('<Escape>', lambda _e: w.destroy())
        try:
            ui_theme.adopt(w)
        except Exception:                                       # noqa: BLE001
            pass
        e.focus_set()
        w.grab_set()
        self.wait_window(w)
        return out['v']

    def _new(self):
        n = self._ask(_t('M_VT_NEW', '새 주제'))
        if not n:
            return
        with appdb.connect(self.db) as c:
            self._key = VT.add_topic(c, n, self._grp)
        self.refresh()

    def _rename(self):
        t = self._topic()
        if not t:
            return
        n = self._ask(_t('M_VT_RENAME', '주제 이름 바꾸기'), t['name'])
        if n is None:
            return
        with appdb.connect(self.db) as c:
            VT.rename_topic(c, t['key'], n, t['grp'])
        self.refresh()

    def _hide(self):
        t = self._topic()
        if not t:
            return
        if getattr(self, '_hide_arm', None) != t['key']:          # 한 번 더 눌러야 지운다(팝업 없이)
            self._hide_arm = t['key']
            self._say(_t('M_VT_HIDE_AGAIN', '「%s」 — 한 번 더 누르면 지웁니다.') .replace('%s', t['name']))
            return
        self._hide_arm = None
        with appdb.connect(self.db) as c:
            VT.hide_topic(c, t['key'])
        self._key = None
        self.refresh()

    def _restore(self):
        if not self._key:
            return
        with appdb.connect(self.db) as c:
            VT.restore_verses(c, self._key)
        self._load_verses()


def selftest():
    ok, bad = [0], [0]

    def ck(c, m, got=''):
        (ok if c else bad)[0] += 1
        print('  %s %s%s' % ('OK  ' if c else 'FAIL', m, '' if c else '  ← %s' % (got,)))
    root = tk.Tk()
    root.withdraw()
    v = VerseTopicView(root, 'bible_master.db')
    v.pack(fill='both', expand=True)
    root.update()
    ck(len(v._gbtn) == 3 and 'MEMO' not in v._gbtn, '갈래 단추 셋(암송 뺌)')
    v._pick_grp('CHURCH')
    root.update()
    ck(any(t['key'] == 'TS_LORD' for t in v._topics), '교회 예식에 성찬')
    v._tv_t.selection_set('TS_LORD')
    root.update()
    v._on_topic()
    ck(v._rows and v._rows[0]['ref'] == '46:11:23-26', '구절 목록', v._rows[:1])
    v._tv_v.selection_set(v._rows[0]['ref'])
    v._show_body()
    s = v._body.get('1.0', 'end')
    ck('[성찬]' in s and '고전 11:23' in s and '잡히시던 밤' in s, '본문까지 · 주제 이름', s[:60])
    ck(v._ref_of('요 3:16-18') == '43:3:16-18', '약명 읽기(구간)')
    ck(v._ref_of('아무 글') is None, '못 읽으면 None')
    root.destroy()
    print('\nverse_topic_view selftest %d/%d' % (ok[0], ok[0] + bad[0]))
    return bad[0] == 0


if __name__ == '__main__':
    import sys
    sys.exit(0 if selftest() else 1)
