"""db_walk_extract.py — 도보 구역 둘레만 OSM 에서 잘라 도보 엔진 원본을 만든다 (2026-10-30 신설·영구)

사용자 결정(2026-10-30) — 도시 안(예루살렘 옛 도시 등)은 걸어서 다니는 실제 길을 실선으로 그린다.
  · 차 엔진(GH 8989·8991)은 footway·path·steps 를 일부러 버렸다 → 도보는 따로 지어야 한다
  · 나라 통째(1.3 GB)로 도보 그래프를 지을 까닭이 없다 — 도보 구역(sys_pilgrim_walk_zone) 둘레만 자른다
  · 결과 = C:/Hagah/tools/graphhopper/walk.osm.pbf (저장소 밖) → 「도로엔진 켜기 - 걸어서.cmd」(포트 8993)

  --zones   (구역과 자를 상자만 보인다)
  --build   (원본 두 파일에서 잘라 쓴다 · 몇 분)
  --selftest
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)
try:
    sys.stdout.reconfigure(encoding='utf-8')
except Exception:
    pass

GH = 'C:/Hagah/tools/graphhopper'
SOURCES = ('holyland.osm.pbf', 'aegean.osm.pbf')
OUT = GH + '/walk.osm.pbf'
MARGIN_M = 1500   # 구역 반경 밖으로 더 잡는 폭 — 길이 구역 밖을 돌아 들어오는 것까지


def boxes(conn):
    import math
    out = []
    for code, la, lo, r in conn.execute("SELECT code, lat, lng, radius_m FROM sys_pilgrim_walk_zone"
                                        " WHERE COALESCE(record_status,'LIVE')='LIVE' ORDER BY sort_order"):
        d = r + MARGIN_M
        dla = d / 111000.0
        dlo = d / (111000.0 * math.cos(math.radians(la)))
        out.append((code, la - dla, lo - dlo, la + dla, lo + dlo))
    return out


def inside(bx, la, lo):
    for _, a, b, c, d in bx:
        if a <= la <= c and b <= lo <= d:
            return True
    return False


def build(bx, say=print):
    import osmium
    ways, need = set(), set()

    class Pick(osmium.SimpleHandler):
        def way(self, w):
            if 'highway' not in w.tags:
                return
            hit = False
            ids = []
            for n in w.nodes:
                ids.append(n.ref)
                if not hit and n.location.valid() and inside(bx, n.location.lat, n.location.lon):
                    hit = True
            if hit:
                ways.add(w.id)
                need.update(ids)

    if os.path.exists(OUT):
        os.remove(OUT)
    tmp = OUT + '.tmp.pbf'
    if os.path.exists(tmp):
        os.remove(tmp)
    wr = osmium.SimpleWriter(tmp)

    # ⚠ 원본이 둘이라 「점 → 길」 차례를 지킨다 — 원본마다 점·길을 이어 쓰면 GraphHopper 가 거절한다
    #   (「OSM node elements must be located before way elements」 — 2026-10-30 실제로 당했다)
    class Nodes(osmium.SimpleHandler):
        def node(self, n):
            if n.id in need:
                wr.add_node(n)

    class Ways(osmium.SimpleHandler):
        def way(self, w):
            if w.id in ways:
                wr.add_way(w)

    try:
        for src in SOURCES:
            p = GH + '/' + src
            n0 = len(ways)
            Pick().apply_file(p, locations=True, idx='flex_mem')
            say('  %s — 길 %d' % (src, len(ways) - n0))
        for src in SOURCES:
            Nodes().apply_file(GH + '/' + src)
        for src in SOURCES:
            Ways().apply_file(GH + '/' + src)
    finally:
        wr.close()
    os.replace(tmp, OUT)
    say('  쓴 것 — 길 %d · 점 %d · %.1f MB' % (len(ways), len(need), os.path.getsize(OUT) / 1e6))
    return len(ways)


def selftest():
    bx = [('X', 31.0, 35.0, 31.1, 35.1)]
    ok = [inside(bx, 31.05, 35.05), not inside(bx, 31.2, 35.05), not inside(bx, 31.05, 34.9)]
    import appdb
    c = appdb.connect()
    b = boxes(c)
    ok.append(len(b) >= 1)
    jv = [x for x in b if x[0] == 'JER_VIA']
    ok.append(bool(jv) and inside(jv, 31.7800, 35.2330))
    print('db_walk_extract selftest %d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    bx = boxes(appdb.connect())
    if '--resort' in sys.argv:          # 이미 쓴 walk.osm.pbf 의 차례만 바로잡는다(점 → 길)
        import osmium
        ns, ws = [], []

        class R(osmium.SimpleHandler):
            def node(self, n):
                ns.append(osmium.osm.mutable.Node(id=n.id, version=n.version or 1, location=(n.location.lon, n.location.lat),
                                                  tags={t.k: t.v for t in n.tags}))

            def way(self, w):
                ws.append(osmium.osm.mutable.Way(id=w.id, version=w.version or 1, nodes=[r.ref for r in w.nodes],
                                                 tags={t.k: t.v for t in w.tags}))
        R().apply_file(OUT)
        tmp = OUT + '.tmp.pbf'
        if os.path.exists(tmp):
            os.remove(tmp)
        wr = osmium.SimpleWriter(tmp)
        for n in sorted(ns, key=lambda x: x.id):
            wr.add_node(n)
        for w in sorted(ws, key=lambda x: x.id):
            wr.add_way(w)
        wr.close()
        os.replace(tmp, OUT)
        print('점 %d · 길 %d — 차례 바로잡음' % (len(ns), len(ws)))
    elif '--zones' in sys.argv:
        for x in bx:
            print('%-10s %.4f,%.4f ~ %.4f,%.4f' % x)
    elif '--build' in sys.argv:
        build(bx)
    else:
        print(__doc__)
