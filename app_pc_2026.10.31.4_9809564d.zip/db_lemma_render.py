# -*- coding: utf-8 -*-
"""개역한글 옮김새 — 원어 한 낱말이 우리말로 어떻게 갈리나 (영구 도구)

2026-09-07 신설. 사용자 지시:
  「히브리어 하나를 한글에서 서로 다르게 표현하는 경우 용어와 연결된 구절에
   한글이 서로 다르게 된다. 이 경우 **원어가 한글로 다양하게 번역된 사실을
   알 수 있도록** 해야겠다.」

★★★ **왜 이것이 필요한가** — 헤세드 하나를 개역한글이 아홉 가지로 옮긴다.
  그래서 「인애 · 헤세드」의 연결구절 목록을 내려가면 인자·은혜·긍휼·자비가
  차례로 나오는데, **읽는 사람은 그것이 같은 낱말인 줄 모른다.**
  목록이 뒤죽박죽으로 읽히는 것이 아니라 **원문이 그렇게 풍성한 것**이다.

⚠⚠ **기계만으로는 못 낸다 — 실측으로 확인했다**(들어올림 측정 · 헤세드 검증):
  · 조사를 못 뗀다 — 「길로 133 · 길을 118 · 길에 87」이 따로 세어진다
    (한국어 형태소 분석기가 없다)
  · 연어 잡음 — 「인자하심이 **영원함**이로다」의 「영원함」이 상위로 온다
  · 같은 뜻을 여러 앵커가 나눠 가지면 진짜가 걸러진다(목자 H7473/H7462)
  ⇒ **`--cand` 가 후보를 내고 사람이 `RENDER` 에 적는다**(§165차 원칙).

★ **개수는 기계가 센다** — 사람은 낱말만 적는다. 그래야 본문이 바뀌거나
  앵커가 늘 때 숫자가 저절로 따라온다(손으로 적으면 어긋난다).

⚠ **새 표를 만들지 않는다** — 원장은 이 파일이고(§183차 ⑤ 파일 원장),
  개수는 조회할 때 센다.

    python -X utf8 db_lemma_render.py --selftest      (의무)
    python -X utf8 db_lemma_render.py --cand H2617    후보 뽑기
    python -X utf8 db_lemma_render.py --show T_HESED  담긴 것 확인
    python -X utf8 db_lemma_render.py --status
"""
from __future__ import annotations

import re
import sys

try:
    import appdb
except Exception:                                        # pragma: no cover
    appdb = None

#: **사람이 정한 옮김새** — strong → 개역한글이 그 낱말을 옮긴 우리말들.
#:
#: ⚠ **어간만 적는다**(「인자」·「길」) — 조사·활용은 기계가 앞자리 맞춤으로
#:   잡는다. 「인자하심」까지 적으면 「인자한」이 안 걸린다.
#: ⚠ **차례가 뜻을 가진다** — 잦은 것부터 적는다(화면이 그 차례로 보인다).
#: ⚠ **짐작으로 적지 않는다** — `--cand` 로 후보를 보고 본문을 눈으로 확인한다.
RENDER = {
    # 인애 · 헤세드 — 설명문이 「아홉 가지」라 적은 그 목록
    'H2617': ['인자', '은혜', '긍휼', '인애', '자비', '은총', '사랑', '선대', '선'],
    # 길 · 데레크
    'H1870': ['길', '도', '대로', '행위', '행사'],
    'H734':  ['길', '첩경', '행로'],
    # 종 · 에베드 — 「신복」이 실측으로 드러났다(왕의 신하)
    'H5650': ['종', '신복', '사환', '노복'],
    # 사람 · 아담 — 「인자야」는 에스겔의 부름말이다
    'H120':  ['사람', '인자', '인생', '아담'],
    # 씨 · 제라
    'H2233': ['씨', '후손', '자손', '종자'],
    # 물 · 마임
    'H4325': ['물', '샘물', '홍수'],
    # 옷 · 베게드
    'H899':  ['옷', '의복', '겉옷', '복'],
    # 산 · 하르
    'H2022': ['산', '산지'],
    # 포도나무 · 게펜
    'H1612': ['포도나무', '포도'],
    # 신부 · 칼라
    'H3618': ['신부', '며느리'],
}

_HAN = re.compile(r'[가-힣]+')


def renders_of(strong):
    """그 앵커의 옮김새 목록 — 없으면 빈 리스트."""
    return list(RENDER.get(strong) or ())


def find_in(text, words):
    """그 절이 쓴 옮김새 — 목록에서 실제로 나오는 것.

    ⚠ **어간 앞자리 맞춤**이다 — 「인자」가 「인자하심」·「인자한」에 걸린다.
    ⚠ **긴 것부터** 본다 — 「포도나무」가 「포도」보다 먼저 걸려야 한다.
    ⚠ 없으면 **빈손을 낸다**(지어내지 않는다 · §0-1b).
    """
    t = text or ''
    for w in sorted(words or (), key=len, reverse=True):
        if w and w in t:
            return w
    return ''


def counts(conn, strong, version='KRV'):
    """옮김새별 절 수 → `[(낱말, 개수)]` · 잦은 것부터. **기계가 센다.**

    ⚠ 한 절이 두 옮김새를 가지면 **긴 것 하나로만** 센다(`find_in` 규칙).
    ⚠⚠ **그래서 헤세드 설명문의 숫자와 조금 다르다** — 그 글은 「은혜 39번」
      이라 적었는데 여기는 32다. 어긋난 것이 아니라 **세는 단위가 다르다**:
        · 설명문 = **몇 번 옮겼나**(한 절에 두 번 나오면 두 번)
        · 여기   = **몇 절에서 그 말을 썼나**(한 절은 한 번 · 이름표가 하나다)
      ⇒ 화면이 **「(절 수)」라고 적는다**. 그리고 이 수는 목록에 붙는
        `[인자]` 표식의 줄 수와 **정확히 같다** — 화면 안에서 어긋나지 않는다.
      ⚠ 낱말 정렬(원어↔우리말)이 없어 「몇 번」은 기계가 못 센다.
    """
    ws = renders_of(strong)
    if not ws:
        return []
    vs = lemma_verses(conn, strong)
    if not vs:
        return []
    got = {}
    for i in range(0, len(vs), 400):
        part = vs[i:i + 400]
        ph = ','.join('?' * len(part))
        for _v, t in conn.execute(
                "SELECT verse_id, verse_text FROM bible_content "
                "WHERE version_code=? AND verse_id IN (%s)" % ph,
                [version] + list(part)):
            w = find_in(t, ws)
            if w:
                got[w] = got.get(w, 0) + 1
    return sorted(got.items(), key=lambda x: (-x[1], ws.index(x[0])))


def summary(conn, strong, version='KRV'):
    """화면 한 줄 — 「인자 154 · 은혜 39 …」. 없으면 빈 글자."""
    got = counts(conn, strong, version)
    if len(got) < 2:
        return ''                 # 갈리지 않으면 말할 것이 없다(§0-1 빈 서랍)
    return ' · '.join('%s %d' % (w, k) for w, k in got)


def lemma_verses(conn, strong):
    """그 앵커의 낱말연결 절 — **화면이 쓰는 그 데이터**에서."""
    return [r[0] for r in conn.execute(
        "SELECT DISTINCT l.target_id FROM sys_link_asset l "
        "JOIN sys_entity_lemma e ON e.lemma_id=l.lemma_id "
        "WHERE l.link_type='ENTI_VERS' AND l.rel_code='LEXICAL' "
        "AND e.strong=? AND COALESCE(l.record_status,'LIVE')='LIVE'",
        (strong,))]


# ── 후보 뽑기(사람이 볼 것) ────────────────────────────────────────────
def _grams(s, ns=(2, 3, 4)):
    g = set()
    for w in _HAN.findall(s):
        for k in ns:
            for i in range(len(w) - k + 1):
                g.add(w[i:i + k])
    return g


def candidates(conn, strong, top=12, version='KRV'):
    """후보 `[(개수, 전체빈도, 낱말)]` — **판정하지 않는다.**

    ⚠ 실측으로 확인한 한계는 파일 머리에 적었다. 사람이 본문을 보고 정한다.
    """
    vs = set(lemma_verses(conn, strong))
    if not vs:
        return []
    base, tot, mine = {}, 0, []
    for v, t in conn.execute("SELECT verse_id, verse_text FROM bible_content "
                             "WHERE version_code=?", (version,)):
        tot += 1
        gs = _grams(t or '')
        for g in gs:
            base[g] = base.get(g, 0) + 1
        if v in vs:
            mine.append(gs)
    cnt = {}
    for gs in mine:
        for g in gs:
            cnt[g] = cnt.get(g, 0) + 1
    n = len(mine)
    floor = max(5, int(n * 0.02))
    cand = []
    for g, k in cnt.items():
        b = base.get(g, 0) or 1
        if k < floor or k / b < 0.6:
            continue
        cand.append((k, b, g))
    cand.sort(reverse=True)
    keep = []
    for k, b, g in cand:
        if any(g in g2 and k <= k2 * 1.25 for k2, _b2, g2 in keep):
            continue
        keep.append((k, b, g))
    return keep[:top]


# ── selftest ───────────────────────────────────────────────────────────
def _selftest():
    import sqlite3
    ok, bad = [], []

    def chk(name, cond, extra=''):
        (ok if cond else bad).append(name + (('  ' + str(extra)) if extra else ''))

    # ── 원장 모양 ────────────────────────────────────────────────
    chk('원장이 비지 않았다', bool(RENDER))
    chk('열쇠가 strong 꼴이다',
        all(re.match(r'^[HG]\d+$', k) for k in RENDER),
        [k for k in RENDER if not re.match(r'^[HG]\d+$', k)])
    chk('★ 옮김새가 둘 이상이다 — 하나면 적을 까닭이 없다',
        all(len(v) >= 2 for v in RENDER.values()),
        [k for k, v in RENDER.items() if len(v) < 2])
    chk('  한국어만 적는다',
        all(_HAN.fullmatch(w) for v in RENDER.values() for w in v),
        [w for v in RENDER.values() for w in v if not _HAN.fullmatch(w)])
    chk('  같은 낱말을 두 번 안 적는다',
        all(len(v) == len(set(v)) for v in RENDER.values()))

    # ── 찾기 규칙 ────────────────────────────────────────────────
    chk('★ 어간이 활용형에 걸린다',
        find_in('그 인자하심이 영원함이로다', ['인자', '은혜']) == '인자')
    chk('★ 긴 것이 먼저 걸린다 — 포도나무 ↔ 포도',
        find_in('내가 참 포도나무요', ['포도', '포도나무']) == '포도나무')
    chk('  없으면 빈손', find_in('태초에 하나님이', ['인자', '은혜']) == '')
    chk('  목록이 비면 빈손', find_in('아무 글', []) == '')

    # ── 세기·요약 ────────────────────────────────────────────────
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE bible_content(verse_id INTEGER, version_code TEXT,
        verse_text TEXT);
      CREATE TABLE sys_link_asset(clicked_id INTEGER, target_id INTEGER,
        link_type TEXT, rel_code TEXT, lemma_id INTEGER,
        record_status TEXT DEFAULT 'LIVE');
      CREATE TABLE sys_entity_lemma(lemma_id INTEGER PRIMARY KEY, strong TEXT);
    """)
    c.execute("INSERT INTO sys_entity_lemma VALUES (1,'H2617')")
    for v, t in ((10, '주의 인자하심이 크도다'), (11, '주의 은혜가 족하도다'),
                 (12, '그 인자를 영원히'), (13, '긍휼히 여기시는'),
                 (14, '아무 상관 없는 절')):
        c.execute("INSERT INTO bible_content VALUES (?,'KRV',?)", (v, t))
        c.execute("INSERT INTO sys_link_asset(clicked_id,target_id,link_type,"
                  "rel_code,lemma_id) VALUES (1,?,'ENTI_VERS','LEXICAL',1)", (v,))
    c.commit()
    got = counts(c, 'H2617')
    chk('★ 옮김새별로 센다', got == [('인자', 2), ('은혜', 1), ('긍휼', 1)], got)
    chk('  하나도 안 걸린 절은 안 센다', sum(k for _w, k in got) == 4)
    s = summary(c, 'H2617')
    chk('★ 요약 줄을 낸다', '인자 2' in s and '은혜 1' in s, s)
    chk('★ 갈리지 않으면 말하지 않는다(빈 서랍 금지)',
        summary(c, 'H9999') == '')
    chk('  원장에 없는 앵커는 빈손', counts(c, 'H9999') == [])

    # ── 후보 뽑기는 판정하지 않는다 ───────────────────────────────
    cd = candidates(c, 'H2617')
    chk('후보를 낸다(판정 아님)', isinstance(cd, list))
    c.close()

    for n2 in ok:
        print('  OK  ' + n2)
    for n2 in bad:
        print('  FAIL: ' + n2)
    print('db_lemma_render selftest: %d/%d' % (len(ok), len(ok) + len(bad)))
    return 1 if bad else 0


def main(argv):
    if '--selftest' in argv:
        return _selftest()
    c = appdb.connect('bible_master.db') if appdb else None
    if c is None:
        print('appdb 없음')
        return 1
    if '--cand' in argv:
        sn = argv[argv.index('--cand') + 1]
        print('%s 후보 — 사람이 본문을 보고 정한다' % sn)
        for k, b, g in candidates(c, sn):
            print('   %-8s 이 낱말의 절에 %4d · 성경 전체 %5d' % (g, k, b))
        return 0
    if '--show' in argv:
        code = argv[argv.index('--show') + 1]
        for sn, in c.execute(
                "SELECT e.strong FROM sys_entity_lemma e "
                "JOIN sys_entity_master m ON m.entity_id=e.entity_id "
                "WHERE m.entity_code=?", (code,)):
            print('%-8s %s' % (sn, summary(c, sn) or '(갈리지 않음)'))
        return 0
    print('옮김새를 적어 둔 앵커 %d' % len(RENDER))
    for sn in sorted(RENDER):
        s = summary(c, sn)
        print('   %-8s %s' % (sn, s or '(연결 없음 · 갈리지 않음)'))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
