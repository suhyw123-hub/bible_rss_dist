# -*- coding: utf-8 -*-
"""성지순례 **구간**(2026-10-29 신설 · 영구 · 사용자 설계 합의 「12 구간 · 구간 결합(끝 거점 = 다음 시작 · 1시간 안) ·
확장 「애굽 역사 유물 5일」」 · 「계획대로 진행하라」).

★ 구간 = 며칠짜리 한 덩이. 날마다 = **그날 묵는 거점** + 들를 곳 차례. 시작 거점에서 나가 그날 거점에서 잔다.
  다음 날은 그 거점에서 나간다. 구간을 이으면 여러 날 여정이 된다 — 앞 구간의 마지막 거점 = 다음 구간의 시작 거점
  (같지 않아도 차로 1시간 안이면 잇는다 · 그 판정은 폰이 한다).
★ 들를 곳 = 성경 장소(P · 용어 번호) 또는 순례 장소(S · sys_pilgrim_site.site_id) — 적을 때는 **열쇠**(PL_… · 위키데이터 Q…)로
  적고 `seed` 가 번호로 푼다. 성경 장소와 같은 곳인 순례 장소(same_place)는 그 성경 장소로 푼다(폰 팩에는 안 실리므로).
★ 시간·거리는 여기서 재지 않는다 — 폰이 거점 둘레 표(sys_pilgrim_base_road) · 성경 장소 도로 표로 그때 센다(한 문).

표(CORE · 폰 공통팩)
  sys_pilgrim_leg  leg_id PK · code UNIQUE · region(ISRAEL|JORDAN|EGYPT) · ext(확장 0/1) · start_base(거점 code) ·
                   names(JSON 언어마다) · days(JSON [{"base": 거점 code, "stops": ["P160","S91"], "fly": 0|1(비행기)|2(배)}]) ·
                   sort_order · record_status

  python db_pilgrim_leg.py --selftest | --seed | --list
"""
import json
import sys

import appdb


def _n(ko, en, ja, zh, zht, de, fr, es, pt, ru, ar):
    return {'KO': ko, 'EN': en, 'JA': ja, 'ZH': zh, 'ZHT': zht, 'DE': de, 'FR': fr, 'ES': es, 'PT': pt, 'RU': ru, 'AR': ar}


def _d(base, *stops, fly=0):
    return {'base': base, 'stops': list(stops), 'fly': fly}


#: (열쇠, 지역, 확장, 시작 거점, 이름, 날들) — 차례 = 이 표
LEGS = [
    ('GALILEE', 'ISRAEL', 0, 'TIBERIAS',
     _n('갈릴리 호숫가와 북부', 'Sea of Galilee & the North', 'ガリラヤ湖と北部', '加利利海与北部', '加利利海與北部',
        'See Genezareth und der Norden', 'Lac de Tibériade et le Nord', 'Mar de Galilea y el norte', 'Mar da Galileia e o norte',
        'Галилейское море и север', 'بحر الجليل والشمال'),
     [_d('TIBERIAS', 'Q4880851', 'Q990912', 'Q2109794', 'Q543683', 'Q59174'),
      _d('TIBERIAS', 'Q501773', 'Q2469418', 'Q7440096', 'Q819281'),
      _d('TIBERIAS', 'Q2456076', 'Q740138', 'PL_DAN', 'PL_CAESAREA_PHILIPPI')]),
    ('NAZARETH', 'ISRAEL', 0, 'TIBERIAS',
     _n('나사렛과 이스르엘 골짜기', 'Nazareth & the Jezreel Valley', 'ナザレとイズレエル平野', '拿撒勒与耶斯列平原', '拿撒勒與耶斯列平原',
        'Nazareth und die Jesreelebene', 'Nazareth et la vallée de Jezreel', 'Nazaret y el valle de Jezreel', 'Nazaré e o vale de Jezreel',
        'Назарет и Изреельская долина', 'الناصرة ومرج ابن عامر'),
     [_d('NAZARETH', 'PL_TABOR', 'Q1028121', 'Q12408509', 'Q130815', 'Q1124878'),
      _d('NAZARETH', 'Q2602652', 'Q208379', 'PL_JEZREEL', 'Q7055875', 'PL_HAROD')]),
    ('COAST', 'ISRAEL', 0, 'NAZARETH',
     _n('지중해 해안(갈멜·가이사랴·욥바)', 'The Coast: Carmel, Caesarea, Joppa', '地中海沿岸(カルメル・カイサリア・ヤッファ)',
        '地中海沿岸(迦密·该撒利亚·约帕)', '地中海沿岸(迦密·該撒利亞·約帕)', 'Die Küste: Karmel, Caesarea, Jafo',
        'La côte : Carmel, Césarée, Jaffa', 'La costa: Carmelo, Cesarea, Jope', 'O litoral: Carmelo, Cesareia, Jope',
        'Побережье: Кармил, Кесария, Иоппия', 'الساحل: الكرمل وقيسارية ويافا'),
     [_d('JERUSALEM', 'Q1606585', 'PL_MT_CARMEL', 'PL_CAESAREA', 'Q2919884')]),
    ('JORDAN_VALLEY', 'ISRAEL', 0, 'TIBERIAS',
     _n('요단 골짜기(벧산·세례터·여리고)', 'The Jordan Valley: Beth Shean, Baptism Site, Jericho', 'ヨルダン渓谷(ベト・シェアン・洗礼地・エリコ)',
        '约旦河谷(伯珊·受洗处·耶利哥)', '約旦河谷(伯珊·受洗處·耶利哥)', 'Jordantal: Bet Schean, Taufstelle, Jericho',
        'Vallée du Jourdain : Beth-Shéan, site du baptême, Jéricho', 'Valle del Jordán: Bet Seán, lugar del bautismo, Jericó',
        'Vale do Jordão: Bete-Seã, local do batismo, Jericó', 'Долина Иордана: Бет-Шеан, место крещения, Иерихон',
        'وادي الأردن: بيسان وموقع المعمودية وأريحا'),
     [_d('JERUSALEM', 'Q991404', 'Q152368', 'Q1574073', 'Q10742877', 'Q60305', 'Q14795053')]),
    ('SAMARIA', 'ISRAEL', 0, 'JERUSALEM',
     _n('사마리아(벧엘·실로·세겜)', 'Samaria: Bethel, Shiloh, Shechem', 'サマリア(ベテル・シロ・シケム)', '撒玛利亚(伯特利·示罗·示剑)',
        '撒瑪利亞(伯特利·示羅·示劍)', 'Samaria: Bethel, Schilo, Sichem', 'Samarie : Béthel, Silo, Sichem', 'Samaria: Betel, Silo, Siquem',
        'Samaria: Betel, Siló, Siquém', 'Самария: Вефиль, Силом, Сихем', 'السامرة: بيت إيل وشيلوه وشكيم'),
     [_d('NAZARETH', 'PL_BETHEL', 'PL_SHILOH', 'Q1679519', 'Q1288751', 'PL_SHECHEM', 'PL_SAMARIA', 'PL_DOTHAN')]),
    ('JERUSALEM', 'ISRAEL', 0, 'JERUSALEM',
     _n('예루살렘', 'Jerusalem', 'エルサレム', '耶路撒冷', '耶路撒冷', 'Jerusalem', 'Jérusalem', 'Jerusalén', 'Jerusalém',
        'Иерусалим', 'القدس'),
     [_d('JERUSALEM', 'Q773726', 'Q588849', 'Q1238436', 'Q1331689', 'Q968028'),
      _d('JERUSALEM', 'Q831297', 'Q1761639', 'Q1280187', 'Q187702', 'Q134821', 'Q1494672'),
      _d('JERUSALEM', 'Q318972', 'Q1177668', 'Q1861408', 'Q1177750', 'Q1620682')]),
    ('BETHLEHEM', 'ISRAEL', 0, 'JERUSALEM',
     _n('베들레헴과 유대 산지', 'Bethlehem & the Judean Hills', 'ベツレヘムとユダの山地', '伯利恒与犹大山地', '伯利恆與猶大山地',
        'Bethlehem und das judäische Bergland', 'Bethléem et les monts de Judée', 'Belén y las colinas de Judea',
        'Belém e as colinas da Judeia', 'Вифлеем и Иудейские горы', 'بيت لحم وجبال يهوذا'),
     [_d('JERUSALEM', 'Q2424300', 'Q194504', 'Q2892250', 'Q24039683', 'Q913099', 'PL_JUDEAN_HILL')]),
    ('SHEPHELAH', 'ISRAEL', 0, 'JERUSALEM',
     _n('세펠라(다윗과 골리앗의 땅)', 'The Shephelah: Land of David and Goliath', 'シェフェラ(ダビデとゴリアテの地)',
        '谢非拉(大卫与歌利亚之地)', '謝非拉(大衛與歌利亞之地)', 'Schefela: Land von David und Goliat',
        'La Shéphélah : pays de David et Goliath', 'La Sefela: tierra de David y Goliat', 'A Sefelá: terra de Davi e Golias',
        'Шефела: земля Давида и Голиафа', 'الشفيلة: أرض داود وجليات'),
     [_d('JERUSALEM', 'Q847246', 'Q12412084', 'Q723564', 'Q910323', 'Q848509')]),
    ('DEAD_SEA', 'ISRAEL', 0, 'JERUSALEM',
     _n('사해와 네게브', 'The Dead Sea & the Negev', '死海とネゲブ', '死海与南地', '死海與南地', 'Totes Meer und Negev',
        'La mer Morte et le Néguev', 'El mar Muerto y el Néguev', 'O mar Morto e o Neguebe', 'Мёртвое море и Негев',
        'البحر الميت والنقب'),
     [_d('EIN_BOKEK', 'Q223399', 'PL_ENGEDI', 'Q186312'),
      _d('EILAT', 'Q2063578', 'PL_BEERSHEBA', 'Q1973199')]),
    ('JORDAN_NORTH', 'JORDAN', 0, 'AMMAN',
     _n('요르단 북부(제라시·느보산)', 'Northern Jordan: Jerash, Mount Nebo', 'ヨルダン北部(ジェラシュ・ネボ山)', '约旦北部(杰拉什·尼波山)',
        '約旦北部(傑拉什·尼波山)', 'Nordjordanien: Jerasch, Berg Nebo', 'Nord de la Jordanie : Jerash, mont Nébo',
        'Norte de Jordania: Jerash, monte Nebo', 'Norte da Jordânia: Jerash, monte Nebo', 'Северная Иордания: Джераш, гора Нево',
        'شمال الأردن: جرش وجبل نيبو'),
     [_d('AMMAN', 'Q3157009', 'Q31565', 'Q131955'),
      _d('MADABA', 'Q12193567', 'PL_NEBO', 'Q1346870')]),
    ('KINGS_HIGHWAY', 'JORDAN', 0, 'MADABA',
     _n('왕의 대로와 페트라', "The King's Highway & Petra", '王の道とペトラ', '君王大道与佩特拉', '君王大道與佩特拉',
        'Königsstraße und Petra', 'La route des Rois et Pétra', 'El Camino Real y Petra', 'A Estrada do Rei e Petra',
        'Царская дорога и Петра', 'طريق الملوك والبتراء'),
     [_d('PETRA', 'PL_MACHAERUS', 'Q1019166', 'Q844694'),
      _d('PETRA', 'Q5788'),
      _d('AQABA', 'Q40729')]),
    ('SINAI', 'EGYPT', 0, 'EILAT',
     _n('시내산과 출애굽 길', 'Mount Sinai & the Exodus Road', 'シナイ山と出エジプトの道', '西奈山与出埃及之路', '西奈山與出埃及之路',
        'Sinai und der Weg des Exodus', "Le Sinaï et la route de l'Exode", 'El Sinaí y el camino del Éxodo',
        'O Sinai e o caminho do Êxodo', 'Синай и путь Исхода', 'سيناء وطريق الخروج'),
     [_d('ST_CATHERINE', 'Q185362'),
      _d('CAIRO', 'Q377485', 'PL_REPHIDIM', 'PL_ELIM', 'PL_MARAH'),
      _d('CAIRO', 'Q12508', 'Q5715', 'Q192134', 'Q2422298', 'Q2474653')]),
    ('EGYPT_HISTORY', 'EGYPT', 1, 'CAIRO',
     _n('애굽 역사 유물 5일', "Egypt's Ancient Heritage (5 days)", 'エジプトの古代遺跡(5日)', '埃及古迹五日', '埃及古蹟五日',
        'Altägypten in 5 Tagen', "L'Égypte antique en 5 jours", 'El antiguo Egipto en 5 días', 'O Egito antigo em 5 dias',
        'Древний Египет за 5 дней', 'آثار مصر القديمة في 5 أيام'),
     [_d('CAIRO', 'Q603841', 'Q309282', 'Q937930', 'Q1630019'),
      _d('CAIRO', 'Q2671839', 'Q1581553', 'Q2696558'),
      _d('LUXOR', 'Q201219', fly=1),
      _d('LUXOR', 'Q522862', 'Q319841'),
      _d('LUXOR', 'Q133423', 'Q660692', 'Q750209')]),
    # ★ 2026-10-29 튀르키예·그리스 권역 — 이스라엘에서 비행기로 · 도로는 둘째 엔진(GH2) · 밧모는 배(fly=2)
    ('SEVEN_CHURCHES', 'TURKEY', 0, 'IZMIR',
     _n('요한계시록 일곱 교회', 'The Seven Churches of Revelation', 'ヨハネの黙示録の七つの教会', '启示录七教会', '啟示錄七教會',
        'Die sieben Gemeinden der Offenbarung', "Les sept Églises de l'Apocalypse", 'Las siete iglesias del Apocalipsis',
        'As sete igrejas do Apocalipse', 'Семь церквей Откровения', 'كنائس سفر الرؤيا السبع'),
     [_d('IZMIR', 'Q2827071', 'Q18986'),
      _d('PAMUKKALE', 'Q1135603', 'Q232615', 'Q138280'),
      _d('PAMUKKALE', 'Q849709', 'Q7428276', 'Q1001370'),
      _d('SELCUK', 'PL_EPHESUS', 'Q744406', 'Q135779')]),
    ('PAUL_ASIA', 'TURKEY', 0, 'ANTALYA',
     _n('바울의 길 — 버가 · 비시디아 안디옥 · 이고니온 · 루스드라', "Paul's Road: Perga, Pisidian Antioch, Iconium, Lystra",
        'パウロの道 — ペルゲ・ピシディアのアンティオキア・イコニオン・リストラ', '保罗之路 — 别加·彼西底的安提阿·以哥念·路司得',
        '保羅之路 — 別加·彼西底的安提阿·以哥念·路司得', 'Der Weg des Paulus: Perge, Antiochia in Pisidien, Ikonion, Lystra',
        "La route de Paul : Pergé, Antioche de Pisidie, Iconium, Lystre", 'El camino de Pablo: Perge, Antioquía de Pisidia, Iconio, Listra',
        'O caminho de Paulo: Perge, Antioquia da Pisídia, Icônio, Listra', 'Путь Павла: Пергия, Антиохия Писидийская, Иконий, Листра',
        'طريق بولس: برجة وأنطاكية بيسيدية وإيقونية ولسترة'),
     [_d('ANTALYA', 'Q5994531', 'PL_PERGA'),
      _d('KONYA', 'PL_PISIDIAN_ANTIOCH'),
      _d('KONYA', 'PL_ICONIUM', 'PL_LYSTRA', 'PL_DERBE'),
      _d('GOREME', 'Q6710593')]),
    ('ANTIOCH_TARSUS', 'TURKEY', 0, 'ANTAKYA',
     _n('안디옥과 다소', 'Antioch and Tarsus', 'アンティオキアとタルソス', '安提阿与大数', '安提阿與大數', 'Antiochia und Tarsus',
        'Antioche et Tarse', 'Antioquía y Tarso', 'Antioquia e Tarso', 'Антиохия и Тарс', 'أنطاكية وطرسوس'),
     [_d('ANTAKYA', 'PL_ANTIOCH', 'Q516472', 'Q1605894'),
      _d('ANTAKYA', 'PL_TARSUS', 'Q105944717')]),
    ('ISTANBUL_NICAEA', 'TURKEY', 0, 'ISTANBUL',
     _n('이스탄불과 니케아', 'Istanbul and Nicaea', 'イスタンブールとニカイア', '伊斯坦布尔与尼西亚', '伊斯坦堡與尼西亞',
        'Istanbul und Nicäa', 'Istanbul et Nicée', 'Estambul y Nicea', 'Istambul e Niceia', 'Стамбул и Никея', 'إسطنبول ونيقية'),
     [_d('ISTANBUL', 'Q12506', 'Q736676'),
      _d('ISTANBUL', 'Q4430013')]),
    ('MACEDONIA', 'GREECE', 0, 'KAVALA',
     _n('마게도냐 — 빌립보 · 데살로니가 · 베뢰아', 'Macedonia: Philippi, Thessalonica, Berea', 'マケドニア — フィリピ・テサロニケ・ベレア',
        '马其顿 — 腓立比·帖撒罗尼迦·庇哩亚', '馬其頓 — 腓立比·帖撒羅尼迦·庇哩亞', 'Makedonien: Philippi, Thessaloniki, Beröa',
        'Macédoine : Philippes, Thessalonique, Bérée', 'Macedonia: Filipos, Tesalónica, Berea', 'Macedônia: Filipos, Tessalônica, Bereia',
        'Македония: Филиппы, Фессалоника, Верия', 'مقدونية: فيلبي وتسالونيكي وبيرية'),
     [_d('KAVALA', 'PL_PHILIPPI'),
      _d('THESSALONIKI', 'Q217414', 'PL_THESSALONICA', 'Q730019'),
      _d('KALAMBAKA', 'PL_BEREA', 'Q3125051')]),
    ('ATHENS_CORINTH', 'GREECE', 0, 'ATHENS',
     _n('아덴과 고린도', 'Athens and Corinth', 'アテネとコリント', '雅典与哥林多', '雅典與哥林多', 'Athen und Korinth',
        'Athènes et Corinthe', 'Atenas y Corinto', 'Atenas e Corinto', 'Афины и Коринф', 'أثينا وكورنثوس'),
     [_d('ATHENS', 'Q202487', 'Q131013', 'Q395367'),
      _d('ATHENS', 'PL_CORINTH')]),
    ('PATMOS', 'GREECE', 0, 'ATHENS',
     _n('밧모 섬(배로)', 'Patmos (by ship)', 'パトモス島(船で)', '拔摩岛(乘船)', '拔摩島(乘船)', 'Patmos (mit dem Schiff)',
        'Patmos (en bateau)', 'Patmos (en barco)', 'Patmos (de barco)', 'Патмос (на корабле)', 'بطمس (بالسفينة)'),
     [_d('PATMOS', 'Q1982506', 'Q1978886', fly=2)]),
]

DDL = """CREATE TABLE IF NOT EXISTS sys_pilgrim_leg(
    leg_id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT UNIQUE NOT NULL, region TEXT DEFAULT '', ext INTEGER DEFAULT 0,
    start_base TEXT, names TEXT DEFAULT '{}', days TEXT DEFAULT '[]', sort_order INTEGER DEFAULT 0, record_status TEXT DEFAULT 'LIVE')"""


def ensure(conn):
    conn.execute(DDL)


def resolver(conn):
    """열쇠 → 'P번호'|'S번호' — 같은 곳인 순례 장소는 그 성경 장소로"""
    place = {r[0]: r[1] for r in conn.execute("SELECT entity_code, entity_id FROM sys_entity_master WHERE entity_type='PLACE'")}
    site = {}
    try:
        cols = {r[1] for r in conn.execute('PRAGMA table_info(sys_pilgrim_site)')}
        same = 'CAST(COALESCE(same_place,0) AS INTEGER)=1' if 'same_place' in cols else '0'
        for q, sid, pid, sp, st in conn.execute('SELECT qid, site_id, place_id, %s, status FROM sys_pilgrim_site' % same):
            if st != 'HIDE':
                site[q] = ('P%d' % pid) if sp and pid else ('S%d' % sid)
    except Exception:                                   # noqa: BLE001
        pass

    def f(key):
        if key.startswith('PL_'):
            return 'P%d' % place[key] if key in place else None
        return site.get(key)
    return f


def check(conn):
    """→ 못 푼 열쇠 [(구간, 날, 열쇠)] · 모르는 거점 [(구간, 거점)]"""
    f = resolver(conn)
    try:
        bases = {r[0] for r in conn.execute('SELECT code FROM sys_pilgrim_base')}
    except Exception:                                   # noqa: BLE001
        bases = set()
    miss, nob = [], []
    for code, _rg, _x, start, _nm, days in LEGS:
        for b in [start] + [d['base'] for d in days]:
            if bases and b not in bases:
                nob.append((code, b))
        for i, d in enumerate(days, 1):
            for k in d['stops']:
                if not f(k):
                    miss.append((code, i, k))
    return miss, nob


def seed(conn):
    """구간을 심는다 — 열쇠로 찾아 고친다(번호는 그대로) · 못 푼 들를 곳은 뺀다(check 가 말한다)."""
    ensure(conn)
    f = resolver(conn)
    n = 0
    for i, (code, rg, ext, start, names, days) in enumerate(LEGS):
        dd = [{'base': d['base'], 'stops': [x for x in (f(k) for k in d['stops']) if x], 'fly': d['fly']} for d in days]
        row = (rg, ext, start, json.dumps(names, ensure_ascii=False), json.dumps(dd), (i + 1) * 10)
        if conn.execute('SELECT 1 FROM sys_pilgrim_leg WHERE code=?', (code,)).fetchone():
            conn.execute('UPDATE sys_pilgrim_leg SET region=?, ext=?, start_base=?, names=?, days=?, sort_order=? WHERE code=?',
                         row + (code,))
        else:
            conn.execute('INSERT INTO sys_pilgrim_leg(region, ext, start_base, names, days, sort_order, code) VALUES(?,?,?,?,?,?,?)',
                         row + (code,))
            n += 1
    conn.commit()
    return n


def selftest():
    import sqlite3
    ok, bad = [0], [0]

    def ck(c, m, got=''):
        (ok if c else bad)[0] += 1
        print('  %s %s%s' % ('OK  ' if c else 'FAIL', m, '' if c else '  ← %s' % (got,)))
    core = [x for x in LEGS if not x[2] and x[1] in ('ISRAEL', 'JORDAN', 'EGYPT')]
    ck(len(core) == 12, '구간 12 + 확장', len(core))
    ck({x[1] for x in LEGS} == {'ISRAEL', 'JORDAN', 'EGYPT', 'TURKEY', 'GREECE'}, '권역 다섯(튀르키예·그리스 = 비행기로 잇는다)')
    ck(len({x[0] for x in LEGS}) == len(LEGS), '열쇠 겹침 없음')
    ck(all(len(x[4]) == 11 and all(x[4].values()) for x in LEGS), '이름 11개 언어')
    ck(all(x[5] and all(d['stops'] for d in x[5]) for x in LEGS), '날마다 들를 곳이 있다')
    real = appdb.connect()
    miss, nob = check(real)
    ck(not miss, '모든 들를 곳이 풀린다', miss[:5])
    ck(not nob, '모든 거점이 있다', nob[:5])
    c = sqlite3.connect(':memory:')
    for t in ('sys_entity_master', 'sys_pilgrim_site', 'sys_pilgrim_base'):
        sql = real.execute("SELECT sql FROM sqlite_master WHERE name=?", (t,)).fetchone()
        if sql:
            c.execute(sql[0])
    real.close()
    c.execute("INSERT INTO sys_entity_master(entity_id, entity_code, entity_type) VALUES(7, 'PL_DAN', 'PLACE')")
    c.execute("INSERT INTO sys_pilgrim_site(site_id, qid, place_id, lat, lng, status, same_place) VALUES(3, 'Q1', 7, 0, 0, 'LIVE', 1)")
    c.execute("INSERT INTO sys_pilgrim_site(site_id, qid, place_id, lat, lng, status, same_place) VALUES(4, 'Q2', 7, 0, 0, 'LIVE', 0)")
    f = resolver(c)
    got = (f('PL_DAN'), f('Q1'), f('Q2'), f('Q9'))
    ck(got == ('P7', 'P7', 'S4', None), '열쇠 풀기 — 같은 곳은 성경 장소로', got)
    ck(seed(c) == len(LEGS) and seed(c) == 0, '심기 · 두 번 심어도 안 늘어남')
    d = json.loads(c.execute("SELECT days FROM sys_pilgrim_leg WHERE code='GALILEE'").fetchone()[0])
    ck(d[2]['stops'] == ['P7'], '못 푼 것은 빠지고 푼 것만', d[2]['stops'])
    print('\ndb_pilgrim_leg selftest %d/%d' % (ok[0], ok[0] + bad[0]))
    return bad[0] == 0


def main(a):
    if '--selftest' in a:
        return 0 if selftest() else 1
    conn = appdb.connect()
    if '--seed' in a:
        miss, nob = check(conn)
        for m in miss:
            print('  못 푼 들를 곳', m)
        for m in nob:
            print('  모르는 거점', m)
        print('구간 새로 %d' % seed(conn))
    for r in conn.execute("SELECT code, region, ext, start_base, days FROM sys_pilgrim_leg ORDER BY sort_order"):
        dd = json.loads(r[4])
        print('  %-14s %-6s %s %s → %s · %d일 · %d곳' % (r[0], r[1], '확장' if r[2] else '    ', r[3], dd[-1]['base'], len(dd),
                                                     sum(len(x['stops']) for x in dd)))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
