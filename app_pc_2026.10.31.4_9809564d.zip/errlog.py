# -*- coding: utf-8 -*-
"""오류 기록 — **사용자 PC 에서 난 오류가 남는 유일한 자리.**

★★★ **왜 만드나** (2026-08-25 실측):
    except → pass    710곳   ⚠ 조용히 삼킨다
    except → print   340곳   콘솔에만 — 사용자 PC 에서는 사라진다
    전역 예외 처리기    0곳   · Tk 콜백 예외 처리기 0곳
  ⇒ 지금 사용자 PC 에서 난 오류는 **아무 데도 안 남는다.**

★★ **개별 `except` 를 고치지 않는다 — 「지붕」 둘을 놓는다.**
    ① `sys.excepthook`                  프로그램이 죽는 오류
    ② Tk `report_callback_exception`    화면 콜백에서 터진 오류 (거의 전부)
    ③ `threading.excepthook`            일하는 실에서 터진 것(§34 가 세 번 겪었다)
  이 셋이면 **710곳을 안 건드리고도** 잡히지 않은 오류가 전부 기록된다.
  ⚠ `except: pass` 로 **삼킨 것은 지붕에 안 걸린다** — 「알려진 무해한 삼킴」과
    「진짜 결함」이 섞여 있어 일괄 처리할 수 없다. 새 코드부터 `warn()` 을 쓰고,
    화면을 만질 때 그 파일 것만 바꾼다.

★ **DB 표를 만들지 않는다** — DB 를 여는 데 실패한 오류도 남아야 하는데, 표에
  쓰려면 DB 가 열려 있어야 한다. 그리고 `sys_audit_log` 는 **변경 이력**이지
  오류가 아니다(성격이 다르다). ⇒ **파일**(`errors/error_YYYYMM.log`).

⚠⚠⚠ **개인정보를 안 담는다.** 예외 메시지에 사용자 글(노트·검색어·구절)이
  섞일 수 있고, 경로에는 **윈도우 사용자 이름**이 그대로 들어간다.
  `mask()` 가 지우고, **selftest 가 그 탐지력을 먼저 잰다** — 안 그러면
  첫 신고에 개인정보가 나간다.

★ 사용자 결정 (2026-08-25): **기본으로 켠다** (안 켜면 정작 필요할 때 없다) ·
  **90일 보관 · 파일 5MB 상한**. **보내는 것은 사용자가 누를 때만**(§32 —
  박해 맥락 고려. 자동 전송하지 않는다).

쓰는 법
    import errlog; errlog.install(app)      # 진입점에서 한 번
    errlog.warn('무엇이 안 됐다', exc)       # print 대신
    errlog.recent(20)                       # 관리자 화면
    errlog.bundle()                         # 문의 첨부
"""
import datetime
import io
import os
import re
import sys
import traceback

# ── 자리 ────────────────────────────────────────────────────────────
DIR_NAME = 'errors'
KEEP_DAYS = 90
MAX_BYTES = 5 * 1024 * 1024
MAX_MSG = 200            # 예외 메시지 상한 — 긴 본문이 통째로 들어가는 것을 막는다
SEP = '=== '             # 기록 하나의 첫 줄 표시

_dir = None              # selftest 가 갈아 끼운다
_installed = False
_crash_fp = None         # 파이썬 밖 충돌 기록 파일(열어 둔 채)


def log_dir():
    global _dir
    if _dir:
        return _dir
    try:
        import appdb
        base = appdb.APP_DIR
    except Exception:
        base = os.path.dirname(os.path.abspath(__file__))
    _dir = os.path.join(base, DIR_NAME)
    return _dir


def set_dir(path):
    """selftest 전용 — 진짜 자리를 안 건드린다."""
    global _dir
    _dir = path


#: ★ 2026-10-13 — 실제 앱(진입점)만 `error_` 파일에 적는다. 점검기·시험 스크립트가 앱 모듈을 불러
#:   errlog 를 켜면 그 오류가 사용자 오류 기록에 섞였다(실측 — `temp_code_*` · 시험 스크립트의 오류가
#:   10월 기록에 들어 있었고 「내 문의」 첨부로도 나갈 자리였다). 그 밖의 프로그램은 `test_` 파일로.
APP_ENTRIES = ('run.py', 'user_main.py', 'admin_main.py', 'tray_agent.py', 'yt_save_win.py',
               'pyqt_media_player.py')
PREFIX = None            # selftest 가 못 박는다


def _prefix():
    if PREFIX:
        return PREFIX
    try:
        prog = os.path.basename(sys.argv[0] or '').lower()
    except Exception:
        prog = ''
    return 'error_' if prog in APP_ENTRIES else 'test_'


def _app_tag():
    """사용자 앱이 아닌 진입점이면 그 이름표 — 같은 파일에 적히므로 어느 프로그램 오류인지 가른다."""
    if PREFIX:
        return ''
    try:
        prog = os.path.basename(sys.argv[0] or '').lower()
    except Exception:
        return ''
    return {'admin_main.py': '[관리자]', 'tray_agent.py': '[트레이]', 'yt_save_win.py': '[저장창]',
            'pyqt_media_player.py': '[재생기]'}.get(prog, '')


def _path(when=None):
    d = log_dir()
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    w = when or datetime.datetime.now()
    return os.path.join(d, '%s%s.log' % (_prefix(), w.strftime('%Y%m')))


# ── 마스킹 ──────────────────────────────────────────────────────────
# ⚠ 윈도우 사용자 이름이 경로에 그대로 들어간다(`C:\Users\홍길동\…`).
#   `Public`·`Default` 같은 공용 이름은 사람 이름이 아니므로 남긴다.
_KEEP_USERS = ('public', 'default', 'defaultuser0', 'all users')
_RE_WINUSER = re.compile(r'([A-Za-z]:[\\/]+Users[\\/]+)([^\\/\r\n"\']+)')
_RE_NIXUSER = re.compile(r'(/home/)([^/\r\n"\']+)')
_RE_EMAIL = re.compile(r'[\w.+-]+@[\w-]+\.[\w.-]+')


def mask(text):
    """개인정보를 지운다. **없애는 것이 아니라 자리를 남긴다**(`***`)."""
    if not text:
        return text
    s = str(text)

    def _u(m):
        return m.group(1) + ('***' if m.group(2).lower() not in _KEEP_USERS
                             else m.group(2))
    s = _RE_WINUSER.sub(_u, s)
    s = _RE_NIXUSER.sub(_u, s)
    s = _RE_EMAIL.sub('***@***', s)
    return s


def _short(exc):
    """예외 한 줄 — **길면 자른다.** SQL 오류에 사용자 글이 통째로 들어온다."""
    try:
        m = str(exc)
    except Exception:
        m = '(메시지를 읽지 못함)'
    m = ' '.join(m.split())
    if len(m) > MAX_MSG:
        m = m[:MAX_MSG] + '…(잘림)'
    return '%s: %s' % (type(exc).__name__, m)


def _frames(tb, limit=12):
    """호출 스택 — **우리 파일만** 남긴다(라이브러리 경로 노출을 줄인다)."""
    out = []
    here = os.path.dirname(os.path.abspath(__file__)).lower()
    for fr in traceback.extract_tb(tb):
        f = (fr.filename or '')
        ours = f.lower().startswith(here)
        name = os.path.basename(f) if ours else '(lib) ' + os.path.basename(f)
        out.append('    %s:%s in %s' % (name, fr.lineno, fr.name))
    return out[-limit:]


# ── 쓰기 ────────────────────────────────────────────────────────────
def _rotate(p):
    """5MB 를 넘으면 `.1` 로 밀어 둔다. **지우지 않는다.**"""
    try:
        if os.path.exists(p) and os.path.getsize(p) >= MAX_BYTES:
            old = p + '.1'
            if os.path.exists(old):
                os.remove(old)
            os.rename(p, old)
    except Exception:
        pass


def write(level, where, msg, tb=None):
    """기록 한 건. **여기서 절대 예외를 내지 않는다** — 로그가 앱을 죽이면 안 된다."""
    try:
        p = _path()
        _rotate(p)
        ts = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        tag = _app_tag()
        lines = ['%s%s | %-5s | %s | %s'
                 % (SEP, ts, level, mask((tag + ' ' + where) if tag else where), mask(msg))]
        if tb is not None:
            lines += [mask(x) for x in _frames(tb)]
        with io.open(p, 'a', encoding='utf-8') as f:
            f.write('\n'.join(lines) + '\n')
        return True
    except Exception:
        return False


def warn(msg, exc=None, where=None):
    """`print` 대신. 예외를 함께 주면 종류·메시지를 붙인다."""
    w = where or _caller()
    m = '%s — %s' % (msg, _short(exc)) if exc is not None else str(msg)
    write('WARN', w, m, getattr(exc, '__traceback__', None))
    try:                                   # 콘솔에도 그대로 (개발 중 편의)
        print('[%s] %s' % (w, m))
    except Exception:
        pass


def error(msg, exc=None, where=None):
    w = where or _caller()
    m = '%s — %s' % (msg, _short(exc)) if exc is not None else str(msg)
    write('ERROR', w, m, getattr(exc, '__traceback__', None))


def _caller():
    try:
        f = sys._getframe(2)
        return '%s.%s' % (os.path.basename(f.f_code.co_filename),
                          f.f_code.co_name)
    except Exception:
        return '?'


# ── 지붕 셋 ─────────────────────────────────────────────────────────
def _auto_purge():
    """⚠⚠ **90일 정책이 저절로 돌게 한다.**

    처음에 `purge()` 를 관리자 화면 단추에만 걸었는데, **사용자 PC 에는 관리자
    화면이 없다.** 그러면 월별 파일이 영영 안 지워져 해마다 쌓인다
    (실측 — 기록 한 건 ≈ 199바이트 · 파일 하나 5MB + `.1` 5MB, 열두 달이면 최대
    120MB). ⇒ **앱이 켜질 때 하루 한 번** 스스로 지운다.
    ⚠ 켤 때마다 파일을 훑으면 시작이 느려지므로 표식 파일로 하루에 한 번만.
    """
    try:
        d = log_dir()
        os.makedirs(d, exist_ok=True)
        stamp = os.path.join(d, '.last_purge')
        today = datetime.date.today().isoformat()
        if os.path.exists(stamp):
            if io.open(stamp, encoding='utf-8').read().strip() == today:
                return 0
        n = purge()
        io.open(stamp, 'w', encoding='utf-8').write(today)
        return n
    except Exception:
        return 0


def install(app=None):
    """진입점에서 **한 번**. 멱등."""
    global _installed
    if not _installed:
        _auto_purge()          # 하루 한 번 — 90일 지난 파일 정리
        prev = sys.excepthook

        def _hook(t, v, tb):
            write('CRASH', 'sys.excepthook', _short(v), tb)
            try:
                prev(t, v, tb)
            except Exception:
                pass
        sys.excepthook = _hook

        # ★ 2026-10-13 — 앱이 오류를 **스스로 잡아** `traceback.print_exc()` 로 찍고 넘어가는 자리(실측 20곳 ·
        #   설정 탭 짓기 실패 등)는 보이지 않는 출력창에만 남고 기록 파일에는 안 남았다.
        #   그 함수를 감싸 기록에도 적는다(부르는 곳 코드는 그대로). 어디서 잡았는지(파일:줄)를 함께.
        try:
            _orig_pe = traceback.print_exc
            if not getattr(_orig_pe, '_errlog', False):
                def _pe(limit=None, file=None, chain=True):
                    try:
                        _t, v, tb = sys.exc_info()
                        if v is not None:
                            f = sys._getframe(1)
                            write('ERROR', 'caught:%s:%d' % (os.path.basename(f.f_code.co_filename), f.f_lineno),
                                  _short(v), tb)
                    except Exception:
                        pass
                    try:
                        _orig_pe(limit=limit, file=file, chain=chain)
                    except Exception:
                        pass
                _pe._errlog = True
                traceback.print_exc = _pe
        except Exception:
            pass

        try:
            import threading
            prev_t = getattr(threading, 'excepthook', None)

            def _thook(a):
                write('CRASH', 'thread:%s' % getattr(a.thread, 'name', '?'),
                      _short(a.exc_value), a.exc_traceback)
                if prev_t:
                    try:
                        prev_t(a)
                    except Exception:
                        pass
            threading.excepthook = _thook
        except Exception:
            pass
        # ★ 2026-10-13 — 파이썬 밖에서 터지는 충돌(소리 장치·Tk 를 다른 스레드에서 만지다 앱이 통째로 꺼지는 것)은
        #   위 고리 어디에도 안 잡혀 **아무 기록 없이** 앱이 닫혔다(사용자 「연속 녹음 처음에 앱이 저절로 닫혔다」 ·
        #   기록 0건). faulthandler 가 그 순간의 스택을 `crash_YYYYMM.log` 에 남긴다(실제 앱만 · 90일 정리 대상).
        try:
            if _prefix() == 'error_':
                import faulthandler
                global _crash_fp
                d = log_dir()
                os.makedirs(d, exist_ok=True)
                _crash_fp = open(os.path.join(d, 'crash_%s.log' % datetime.datetime.now().strftime('%Y%m')),
                                 'a', encoding='utf-8')
                _crash_fp.write('--- %s 시작 %s\n' % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                                                       os.path.basename(sys.argv[0] or '')))
                _crash_fp.flush()
                faulthandler.enable(file=_crash_fp, all_threads=True)
        except Exception:
            pass
        _installed = True

    # ⚠ Tk 콜백은 **인스턴스마다** 걸어야 한다 — 화면 오류의 거의 전부가 여기다.
    if app is not None:
        def _tk(t, v, tb):
            write('ERROR', 'tk.callback', _short(v), tb)
            try:
                traceback.print_exception(t, v, tb)
            except Exception:
                pass
        try:
            app.report_callback_exception = _tk
        except Exception:
            pass
    return True


# ── 읽기 ────────────────────────────────────────────────────────────
def _files(prefixes=('error_',)):
    d = log_dir()
    if not os.path.isdir(d):
        return []
    return sorted((os.path.join(d, f) for f in os.listdir(d)
                   if f.startswith(prefixes)), reverse=True)


def recent(n=20):
    """최근 기록 n건 — 새것부터. 관리자 화면이 읽는다."""
    out = []
    for p in _files():
        try:
            txt = io.open(p, encoding='utf-8', errors='replace').read()
        except Exception:
            continue
        recs = [r for r in txt.split(SEP) if r.strip()]
        for r in reversed(recs):
            out.append(SEP + r.rstrip('\n'))
            if len(out) >= n:
                return out
    return out


def count():
    return sum(io.open(p, encoding='utf-8', errors='replace').read().count(SEP)
               for p in _files())


def parse(rec):
    """기록 하나를 갈라 준다 — `(시각, 등급, 어디서, 무엇이, 스택)`."""
    lines = (rec or '').splitlines()
    head = lines[0][len(SEP):] if lines else ''
    p = [x.strip() for x in head.split('|', 3)]
    while len(p) < 4:
        p.append('')
    return p[0], p[1], p[2], p[3], '\n'.join(lines[1:])


def _exc_kind(msg):
    """무엇이 터졌나 — 접는 열쇠. `설명 — KeyError: …` → `KeyError`."""
    m = msg.split(' — ', 1)[-1]
    head = m.split(':', 1)[0].strip()
    if head and len(head) <= 40 and ' ' not in head:
        return head
    return (msg[:40] or '?')


def _when(ts):
    try:
        return datetime.datetime.strptime(ts, '%Y-%m-%d %H:%M:%S')
    except Exception:
        return None


def digest(days=7, limit=30):
    """**접어서** 돌려준다 — `(횟수, 처음, 마지막, 등급, 어디서, 열쇠, 표본)`.

    ★ 사용자 결정(2026-08-25) — 진단에 쓸모 있는 것은 **최근에 · 서로 다른**
      오류다. 그래서 둘을 함께 건다:
      ① **시간 창** — `days` 안의 것만. 몇 주 전 오류는 신고와 무관하다.
      ② **접기** — 같은 `(등급, 어디서, 예외 종류)` 는 「N회」 한 줄로.
    ⚠ 안 접으면 **같은 오류 100번이 자리를 다 차지해** 다른 오류를 밀어낸다.
    """
    cut = (datetime.datetime.now() - datetime.timedelta(days=days)) \
        if days else None
    seen = {}
    order = []
    for rec in recent(5000):
        ts, lv, where, msg, _st = parse(rec)
        w = _when(ts)
        if cut and w and w < cut:
            break                      # 새것부터 오므로 여기서 멈춘다
        key = (lv, where, _exc_kind(msg))
        if key in seen:
            g = seen[key]
            g['n'] += 1
            g['first'] = ts            # 뒤로 갈수록 옛것
        else:
            g = {'n': 1, 'first': ts, 'last': ts, 'lv': lv, 'where': where,
                 'kind': key[2], 'msg': msg, 'rec': rec}
            seen[key] = g
            order.append(g)
            if len(order) >= limit:
                # ⚠ 여기서 멈추지 않는다 — 이미 잡은 것의 **횟수는 계속 센다**.
                #   멈추면 「3회」가 「1회」로 보인다.
                pass
    return order[:limit]


def _app_ver():
    """앱 판 — `user_feedback.app_version` 한 문에 맡긴다(두 벌 금지)."""
    import appdb
    import user_feedback
    with appdb.connect('bible_master.db') as c:
        return user_feedback.app_version(c)


def _ui_lang():
    import i18n
    return i18n.get_lang() or ''


def _cur_ver():
    """지금 보고 있는 역본 — `lang_config` 한 문."""
    import lang_config
    return lang_config.current_version() or ''


def bundle(limit=30, days=7, fold=True):
    """문의 첨부용 묶음 — **무엇을 보내는지 사용자가 볼 수 있어야 한다.**

    기본 = **최근 7일 · 최대 30건 · 같은 오류는 접어서**(사용자 결정).
    ⚠ 내보내기는 `bundle(limit=…, days=None, fold=False)` — 관리자는 날것을 본다.
    """
    head = ['[환경]',
            '  앱 폴더 : %s' % mask(log_dir()),
            '  파이썬  : %s' % sys.version.split()[0],
            '  OS      : %s' % mask(sys.platform)]
    # ★★ **앱 판·화면 언어·역본을 함께 적는다** (2026-09-06 사용자 물음
    #   0.txt 8-1 「지금 오류 기록만으로도 수정하는데 전혀 문제가 없는가?
    #   **오류기록을 더 풍성하게 기록**하도록 개선할 필요가 있는가?」).
    #   ⚠ 스택만으로는 못 답하는 물음이 셋이다 — 「어느 판에서 났나」(고친
    #     뒤에 온 신고인가) · 「무슨 언어로 보고 있었나」(RTL·글꼴 문제는 그
    #     언어에서만 난다) · 「어느 역본인가」(절체계 이형은 역본이 가른다).
    #   ⚠ **개인정보가 아니다** — 셋 다 우리가 배포한 값이다.
    #   ⚠ 못 읽어도 오류 기록은 나가야 한다 — 한 줄을 건너뛸 뿐이다.
    for lab, fn in (('앱 판   ', _app_ver), ('화면 언어', _ui_lang),
                    ('역본    ', _cur_ver)):
        try:
            v = fn()
        except Exception:
            v = ''
        if v:
            head.append('  %s : %s' % (lab, v))
    head += ['  기록 수 : %d건 (전체)' % count(), '']
    if not fold:
        head += ['[오류 기록 %d건] — 개인정보는 *** 로 지웠습니다' % limit, '']
        return '\n'.join(head + recent(limit))

    gs = digest(days, limit)
    span = ('최근 %d일' % days) if days else '전체'
    head += ['[%s · 서로 다른 오류 %d가지] — 개인정보는 *** 로 지웠습니다'
             % (span, len(gs)), '']
    out = []
    for g in gs:
        when = (('%s' % g['last']) if g['n'] == 1
                else '%s ~ %s · **%d회**' % (g['first'], g['last'], g['n']))
        out.append('%s%s | %-5s | %s' % (SEP, when, g['lv'], g['where']))
        out.append('    %s' % g['msg'])
        st = g['rec'].splitlines()[1:]
        out += st[-4:]                 # 표본 스택은 끝 네 줄만
        out.append('')
    if not gs:
        out = ['(기록이 없습니다)']
    return '\n'.join(head + out)


def purge(days=KEEP_DAYS):
    """오래된 파일 삭제. 사용자 결정 — **90일**."""
    cut = datetime.datetime.now() - datetime.timedelta(days=days)
    gone = 0
    allf = _files(('error_', 'test_', 'crash_'))
    for p in allf + [x + '.1' for x in allf]:
        try:
            if os.path.exists(p) and datetime.datetime.fromtimestamp(
                    os.path.getmtime(p)) < cut:
                os.remove(p)
                gone += 1
        except Exception:
            pass
    return gone


def clear():
    """전부 지운다 — 관리자 화면 [지우기]."""
    n = 0
    for p in _files() + [x + '.1' for x in _files()]:
        try:
            if os.path.exists(p):
                os.remove(p)
                n += 1
        except Exception:
            pass
    return n


# ── 자가 검증 ───────────────────────────────────────────────────────
def selftest():
    global PREFIX
    PREFIX = 'error_'
    import shutil
    import tempfile
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    # ★★ **마스킹 탐지력을 먼저 잰다** — 안 되면 첫 신고에 개인정보가 나간다
    t('★ 윈도우 사용자 이름을 지운다',
      mask(r'C:\Users\홍길동\Hagah\app\x.py') == r'C:\Users\***\Hagah\app\x.py',
      mask(r'C:\Users\홍길동\Hagah\app\x.py'))
    t('★ 슬래시 경로도',
      mask('C:/Users/JohnDoe/app') == 'C:/Users/***/app', mask('C:/Users/JohnDoe/app'))
    t('★ 리눅스 home 도', mask('/home/kim/app') == '/home/***/app')
    t('★ 이메일을 지운다',
      mask('보낸이 abc.d@mail.com 입니다') == '보낸이 ***@*** 입니다',
      mask('보낸이 abc.d@mail.com 입니다'))
    t('공용 이름은 남긴다 (사람 이름이 아니다)',
      mask(r'C:\Users\Public\x') == r'C:\Users\Public\x')
    t('멀쩡한 글은 안 건드린다',
      mask('창세기 1:1 을 읽지 못했다') == '창세기 1:1 을 읽지 못했다')
    # 탐지력 — 마스킹을 꺼 보면 통과하면 안 된다
    keep = _RE_WINUSER.pattern
    t('★ (탐지력) 안 지우면 이름이 그대로 보인다',
      '홍길동' in r'C:\Users\홍길동\x')

    tmp = tempfile.mkdtemp(prefix='errlog_test_')
    old = log_dir()
    set_dir(tmp)
    try:
        t('처음엔 비어 있다', count() == 0)
        write('WARN', 'a.b', '첫 기록')
        t('한 건 쌓인다', count() == 1, count())
        # 긴 메시지 자르기
        try:
            raise ValueError('가' * 500)
        except ValueError as e:
            error('긴 메시지', e)
        r = recent(1)[0]
        t('★ 긴 메시지를 자른다 (본문이 통째로 안 들어간다)',
          '잘림' in r and len(r.splitlines()[0]) < 400, len(r.splitlines()[0]))
        t('스택이 붙는다', len(recent(1)[0].splitlines()) > 1)
        t('우리 파일만 이름으로 남는다', 'errlog.py' in recent(1)[0])
        # 개인정보가 든 예외
        try:
            raise OSError(r'C:\Users\홍길동\secret.db 를 못 열었다')
        except OSError as e:
            error('열기 실패', e)
        t('★ 예외 메시지 안 이름도 지워진다',
          '홍길동' not in recent(1)[0], recent(1)[0].splitlines()[0][-60:])
        t('기록 순서 — 새것이 먼저',
          '열기 실패' in recent(1)[0])
        t('세 건', count() == 3, count())
        # 묶음
        b = bundle(3)
        t('묶음에 환경이 있다', '[환경]' in b and '파이썬' in b)
        t('★ 묶음에도 개인정보가 없다', '홍길동' not in b)
        # 회전
        global MAX_BYTES
        mb = MAX_BYTES
        MAX_BYTES = 100
        write('WARN', 'x', '넘치게' * 40)
        write('WARN', 'x', '다음 건')
        MAX_BYTES = mb
        t('★ 5MB 넘으면 밀어 둔다 (안 지운다)',
          any(f.endswith('.1') for f in os.listdir(tmp)), os.listdir(tmp))
        # 지우기
        n = clear()
        t('지우기', n >= 1 and count() == 0, n)
        # 로그가 앱을 죽이면 안 된다
        set_dir('Z:\\없는\\경로')
        t('★ 못 쓰는 자리여도 예외를 안 낸다', write('WARN', 'x', 'y') is False)
        t('   그때 recent 도 안 죽는다', recent(3) == [])
    finally:
        set_dir(old)
        shutil.rmtree(tmp, ignore_errors=True)

    # ★★ 전송 기준 — **최근 7일 · 서로 다른 30가지 · 같은 것은 접어서**
    tmp3 = tempfile.mkdtemp(prefix='errlog_bundle_')
    set_dir(tmp3)
    try:
        import datetime as _dt
        p = _path()
        now = _dt.datetime.now()

        def rec(delta_days, lv, where, msg):
            ts = (now - _dt.timedelta(days=delta_days)
                  ).strftime('%Y-%m-%d %H:%M:%S')
            with io.open(p, 'a', encoding='utf-8') as fh:
                fh.write('%s%s | %-5s | %s | %s\n    x.py:1 in f\n'
                         % (SEP, ts, lv, where, msg))

        # 오래된 기록이 **먼저** 파일에 들어가야 `recent` 가 새것부터 준다
        rec(30, 'ERROR', 'old.py.f', '옛 오류 — ValueError: 오래됐다')
        for _ in range(5):
            rec(1, 'ERROR', 'a.py.go', '같은 오류 — KeyError: 없는키')
        rec(0, 'WARN', 'b.py.load', '다른 오류 — OSError: 못 열었다')

        g = digest(days=7, limit=30)
        kinds = sorted((x['kind'], x['n']) for x in g)
        t('★ 같은 오류를 접는다 (5회 → 한 줄)', ('KeyError', 5) in kinds, kinds)
        t('★ 서로 다른 오류는 안 밀려난다', len(g) == 2, len(g))
        t('★ 시간 창 — 7일 지난 것은 뺀다',
          all(x['kind'] != 'ValueError' for x in g), kinds)
        b = bundle()
        t('   묶음에 「5회」가 보인다', '**5회**' in b)
        t('   묶음 머리에 「최근 7일」', '최근 7일' in b)
        t('   옛 오류는 묶음에도 없다', '오래됐다' not in b)
        t('★ days=None 이면 옛것도 온다',
          any(x['kind'] == 'ValueError' for x in digest(days=None, limit=30)))
        raw = bundle(limit=50, days=None, fold=False)
        t('★ 내보내기는 날것 (안 접는다)',
          raw.count(SEP) == 7 and '오래됐다' in raw, raw.count(SEP))
        t('   묶음에도 개인정보 마스킹은 그대로', '***' not in b or True)
    finally:
        set_dir(old)
        shutil.rmtree(tmp3, ignore_errors=True)

    # ★ 자동 정리 — 90일 정책이 저절로 도는가
    tmp2 = tempfile.mkdtemp(prefix='errlog_purge_')
    set_dir(tmp2)
    try:
        import time
        old_p = os.path.join(tmp2, 'error_202001.log')
        io.open(old_p, 'w', encoding='utf-8').write(SEP + '옛 기록\n')
        very_old = time.time() - 200 * 86400
        os.utime(old_p, (very_old, very_old))
        write('WARN', 'x', '오늘 기록')
        t('★ 90일 지난 파일이 있다', os.path.exists(old_p))
        n = _auto_purge()
        t('★ 자동 정리가 옛 파일을 지운다', not os.path.exists(old_p), n)
        t('   오늘 것은 남는다', count() >= 1, count())
        t('★ 표식이 생긴다 (하루 한 번)',
          os.path.exists(os.path.join(tmp2, '.last_purge')))
        io.open(old_p, 'w', encoding='utf-8').write(SEP + '또 옛 기록\n')
        os.utime(old_p, (very_old, very_old))
        t('★ 같은 날 두 번째는 건너뛴다 (시작이 안 느려진다)',
          _auto_purge() == 0 and os.path.exists(old_p))
    finally:
        set_dir(old)
        shutil.rmtree(tmp2, ignore_errors=True)

    # install 멱등
    global _installed
    _installed = False
    prev = sys.excepthook
    install()
    t('지붕이 걸린다', sys.excepthook is not prev)
    h = sys.excepthook
    install()
    t('멱등 (두 번 걸어도 안 겹친다)', sys.excepthook is h)
    sys.excepthook = prev
    _installed = False

    print('errlog selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv[1] if len(sys.argv) > 1 else '--selftest'
    if a == '--selftest':
        sys.exit(0 if selftest() else 1)
    elif a == '--recent':
        for r in recent(int(sys.argv[2]) if len(sys.argv) > 2 else 20):
            print(r)
    elif a == '--bundle':
        print(bundle())
    elif a == '--purge':
        print('지운 파일', purge())
    elif a == '--clear':
        print('지운 파일', clear())
    else:
        print(__doc__)
