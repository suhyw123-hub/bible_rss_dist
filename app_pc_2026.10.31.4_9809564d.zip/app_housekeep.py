# -*- coding: utf-8 -*-
"""app_housekeep.py — **사용자 PC 의 자동 정리 · 저장 공간 · 내 자료 백업** (2026-10-13 신설 · 영구 · `--selftest`).

사용자 지시(docs/1.txt 73) — 「사용자가 스스로 앱을 효과적으로 사용할 수 있도록 돕는 도구 · 불필요한 데이터
삭제(무엇을 · 주기) · 비활성화 링크를 사용자의 동의 하에 물리적으로 삭제 · 로그가 너무 오래 누적되면 부담」.

★ 하루 한 번 뒤에서 돈다(`run_daily` — 앱을 켤 때 · `user_main` 이 스레드로 부른다).
  | 무엇 | 언제 지우나 | 까닭 |
  |---|---|---|
  | 배포 자료 변경 이력(`sys_audit_log`) | **사용자 PC 에서는 기록을 끄고 비운다** | 팩을 받을 때마다 옛 행 수십만 줄이 쌓였다 · 정본은 다음 팩이라 쓸 데가 없다 |
  | 내 자료 변경 이력(`user_audit_log`) | 180일 지난 것 | 내 글을 되살리는 수단이라 남기되 끝없이 쌓이지 않게 |
  | 폰에서 받아 처리 끝난 초안 | 점검 끝·버린 뒤 90일 | PC 에 이미 들어갔다 |
  | **끊긴 영상**(관리자가 내림 · `is_active=0`) | **내 자료가 안 가리키는 것만** | 내 즐겨찾기·재생목록·가림·연결이 가리키면 **사람에게 묻는다**(`dead_media`) |
  · 오류 기록(90일)·최신 콘텐츠 캐시(90일)·폰 변경 기록은 이미 제 모듈이 정리한다 — 여기서 또 안 한다.

⚠⚠ **지운 글(HIDE)은 자동으로 안 지운다** — 내 자료의 HIDE 가운데 일부는 쓰레기가 아니라 **「기본 연결 가리기」
  표식**이다(덮개 · `overlay_read`). 지우면 사용자가 가려 둔 연결이 되살아난다. 휴지통은 사람이 비운다.
⚠⚠ **관리자 PC(`is_publisher`)에서는 배포 자료를 건드리지 않는다** — 그곳의 변경 이력·영상은 원천이다.
"""
import datetime
import json
import os
import shutil
import sqlite3
import threading

import appdb

LAST_KEY = 'HOUSEKEEP_LAST'           # user_config — 마지막으로 돈 날짜와 결과(JSON)
USER_AUDIT_DAYS = 180
INBOX_DAYS = 90
RESTORE_SUFFIX = '.restore'
_LOCK = threading.Lock()

#: 영상을 가리키는 연결 — (link_type 패턴, 영상 쪽 칸)
_MEDIA_LINK_SIDES = (("link_type LIKE 'MEDI%'", 'clicked_id'),
                     ("link_type LIKE '%_MEDI'", 'target_id'))


def is_publisher():
    try:
        import db_linkpack_sync as LS
        return LS.is_publisher()
    except Exception:                                    # noqa: BLE001
        return False


def _cfg_get(conn, key, default=''):
    try:
        r = conn.execute('SELECT config_val FROM userdb.user_config WHERE config_key=?', (key,)).fetchone()
        return r[0] if r and r[0] is not None else default
    except Exception:                                    # noqa: BLE001
        return default


def _cfg_set(conn, key, val):
    if conn.execute('UPDATE userdb.user_config SET config_val=? WHERE config_key=?', (val, key)).rowcount == 0:
        conn.execute('INSERT INTO userdb.user_config(config_key, config_val) VALUES(?,?)', (key, val))


# ── ① 배포 자료 변경 이력 — 사용자 PC 에서는 끈다 ─────────────────────────
def sys_audit_off(conn, batch=20000, publisher=None):
    """→ 지운 줄 수. 관리자 PC 면 아무것도 안 한다(-1)."""
    if is_publisher() if publisher is None else publisher:
        return -1
    try:
        conn.execute('UPDATE sys_audit_switch SET enabled=0')
    except Exception:                                    # noqa: BLE001
        return 0
    n = 0
    while True:                                          # 한꺼번에 지우면 앱이 오래 멎는다 — 나눠서
        try:
            cur = conn.execute('DELETE FROM sys_audit_log WHERE audit_id IN '
                               '(SELECT audit_id FROM sys_audit_log LIMIT ?)', (batch,))
        except Exception:                                # noqa: BLE001
            break
        conn.commit()
        n += cur.rowcount
        if cur.rowcount < batch:
            break
    return n


# ── ② 내 자료 변경 이력 180일 ─────────────────────────────────────────────
def prune_user_audit(conn, days=USER_AUDIT_DAYS):
    try:
        cur = conn.execute("DELETE FROM userdb.user_audit_log WHERE ts < datetime('now', ?)", ('-%d days' % days,))
        conn.commit()
        return cur.rowcount
    except Exception:                                    # noqa: BLE001
        return 0


# ── ③ 폰 초안함 90일 ─────────────────────────────────────────────────────
def prune_inbox(conn, days=INBOX_DAYS):
    try:
        cur = conn.execute(
            "DELETE FROM userdb.user_mobile_inbox WHERE "
            " (state='ADOPTED' AND checked_at IS NOT NULL AND checked_at < datetime('now', ?)) OR "
            " (state='DISCARDED' AND COALESCE(dropped_at, received_at) < datetime('now', ?))",
            ('-%d days' % days, '-%d days' % days))
        conn.commit()
        return cur.rowcount
    except Exception:                                    # noqa: BLE001
        return 0


# ── ④ 끊긴 영상 ──────────────────────────────────────────────────────────
def _refs(conn):
    """내 자료가 가리키는 영상 → {media_id: [어디서…]}."""
    out = {}

    def add(mid, where):
        if mid:
            out.setdefault(int(mid), []).append(where)
    for sql, where in (('SELECT media_id FROM userdb.user_media_fav', 'FAV'),
                       ('SELECT media_id FROM userdb.user_media_list_item', 'LIST'),
                       ('SELECT media_id FROM userdb.user_media_hide', 'HIDE')):
        try:
            for (m,) in conn.execute(sql):
                add(m, where)
        except Exception:                                # noqa: BLE001
            pass
    for cond, side in _MEDIA_LINK_SIDES:
        try:
            for (m,) in conn.execute('SELECT %s FROM userdb.user_link_asset WHERE %s' % (side, cond)):
                add(m, 'LINK')
        except Exception:                                # noqa: BLE001
            pass
    return out


def dead_media(conn, publisher=None):
    """→ (내 자료가 안 가리키는 끊긴 영상 번호들, [{'id','title','refs'}…] 내 자료가 가리키는 것).
    관리자 PC 면 둘 다 빈다."""
    if is_publisher() if publisher is None else publisher:
        return [], []
    refs = _refs(conn)
    free, used = [], []
    for mid, title in conn.execute("SELECT media_id, title FROM sys_media_asset WHERE is_active=0"):
        if mid in refs:
            used.append({'id': mid, 'title': title or '', 'refs': sorted(set(refs[mid]))})
        else:
            free.append(mid)
    return free, used


def purge_media(conn, ids, with_refs=False, publisher=None, commit=True):
    """끊긴 영상을 지운다 → 지운 영상 수. `with_refs` 면 그것을 가리키던 내 자료도 함께(사람이 고른 것)."""
    if (is_publisher() if publisher is None else publisher) or not ids:
        return 0
    ids = [int(i) for i in ids]
    n = 0
    for k in range(0, len(ids), 500):
        part = ids[k:k + 500]
        q = ','.join('?' * len(part))
        # 아직 살아 있는 영상은 절대 안 지운다(사이에 되살아났을 수 있다)
        part = [r[0] for r in conn.execute(
            'SELECT media_id FROM sys_media_asset WHERE is_active=0 AND media_id IN (%s)' % q, part)]
        if not part:
            continue
        q = ','.join('?' * len(part))
        if with_refs:
            for t in ('user_media_fav', 'user_media_list_item', 'user_media_hide'):
                try:
                    conn.execute('DELETE FROM userdb.%s WHERE media_id IN (%s)' % (t, q), part)
                except Exception:                        # noqa: BLE001
                    pass
            for cond, side in _MEDIA_LINK_SIDES:
                conn.execute('DELETE FROM userdb.user_link_asset WHERE %s AND %s IN (%s)' % (cond, side, q), part)
        for cond, side in _MEDIA_LINK_SIDES:
            conn.execute('DELETE FROM sys_link_asset WHERE %s AND %s IN (%s)' % (cond, side, q), part)
        n += conn.execute('DELETE FROM sys_media_asset WHERE media_id IN (%s)' % q, part).rowcount
    if commit:                         # ⚠ 시험은 commit=False — 저장점 안에서 커밋하면 실제 행이 지워진다(실측으로 당했다)
        conn.commit()
    return n


# ── ⑤ 내가 담은 영상(유튜브 간편 저장 · user_media_asset) ─────────────────
#   ★ 2026-10-13 사용자 「관리자 PC 라도 유튜브 주소를 수동 수집했다면 관리 대상이어야 한다」 —
#     내 자료라 관리자 PC 여부와 상관없다. 살았는지는 **누를 때만** 유튜브에 묻는다(망 · 자동으로 안 한다).
def my_videos(conn):
    """→ [{'id','title','url'}] — 지금 살아 있는 내 영상 가운데 유튜브 주소인 것."""
    out = []
    try:
        rows = conn.execute("SELECT user_media_id, title, url FROM userdb.user_media_asset"
                            " WHERE COALESCE(record_status,'LIVE')<>'HIDE' ORDER BY user_media_id").fetchall()
    except Exception:                                    # noqa: BLE001
        return out
    for uid, title, url in rows:
        u = (url or '').lower()
        if 'youtube.com/' in u or 'youtu.be/' in u:
            out.append({'id': uid, 'title': title or url or '', 'url': url})
    return out


def check_video(url, timeout=8, opener=None):
    """→ 'OK' 볼 수 있음 · 'GONE' 지워졌거나 없음(404·400) · 'PRIVATE' 비공개·퍼가기 막힘(401·403) ·
    'NET' 망 때문에 확인 못함. ⚠ 퍼가기 막힘은 죽음이 아니다(§283차) — 지울 것으로 안 친다."""
    import urllib.error
    import urllib.parse
    import urllib.request
    q = 'https://www.youtube.com/oembed?format=json&url=' + urllib.parse.quote(url or '', safe='')
    try:
        req = urllib.request.Request(q, headers={'User-Agent': 'Hagah/1.0'})
        (opener or urllib.request.urlopen)(req, timeout=timeout).read()
        return 'OK'
    except urllib.error.HTTPError as e:
        if e.code in (400, 404):
            return 'GONE'
        if e.code in (401, 403):
            return 'PRIVATE'
        return 'NET'
    except Exception:                                    # noqa: BLE001
        return 'NET'


def purge_my_videos(conn, ids, commit=True):
    """내가 담은 영상을 지운다(사람이 선택한 것) → 지운 수. 그 영상에서 나간 내 연결(UMED_…)도 함께."""
    ids = [int(i) for i in ids or ()]
    if not ids:
        return 0
    q = ','.join('?' * len(ids))
    conn.execute("DELETE FROM userdb.user_link_asset WHERE link_type LIKE 'UMED%%' AND clicked_id IN (%s)" % q, ids)
    n = conn.execute('DELETE FROM userdb.user_media_asset WHERE user_media_id IN (%s)' % q, ids).rowcount
    if commit:
        conn.commit()
    return n


# ── 하루 한 번 ───────────────────────────────────────────────────────────
def run_daily(db_path=None, force=False):
    """→ 결과 dict(돌지 않았으면 None). 앱을 켤 때 스레드로 부른다."""
    if not _LOCK.acquire(blocking=False):
        return None
    try:
        conn = appdb.connect(db_path or appdb.MAIN_DB)
        try:
            today = datetime.date.today().isoformat()
            last = _cfg_get(conn, LAST_KEY)
            if not force and last.startswith(today):
                return None
            pub = is_publisher()
            free, _used = dead_media(conn, publisher=pub)
            rep = {'date': today,
                   'sys_audit': sys_audit_off(conn, publisher=pub),
                   'user_audit': prune_user_audit(conn),
                   'inbox': prune_inbox(conn),
                   'media': purge_media(conn, free, publisher=pub)}
            # ★ 2026-10-14 — 용어로 승격된 낱말의 내 「원어 설명」을 그 용어의 내 설명문으로
            try:
                import user_ai as _UA
                rep['lemma_move'] = _UA.migrate_lemma_notes(conn)
            except Exception:                            # noqa: BLE001
                pass
            # ★ 2026-10-24 — 소통 통로가 막혀 못 보낸 추천(채널·상품)을 다시 보낸다
            try:
                import user_feedback as _UF
                rep['reco_resend'] = _UF.resend_unsent(conn)
            except Exception:                            # noqa: BLE001
                pass
            # ★ 2026-10-20 — AI 대화 휴지통에서 30일 지난 것을 완전히 지운다(알리기만 하고 저절로 휴지통에 넣지는 않는다)
            try:
                import ai_chat_sync as _ACS
                rep['ai_trash'] = _ACS.purge(conn)
            except Exception:                            # noqa: BLE001
                pass
            # ★ 2026-10-16 — 내 연구/설교노트 옛 유형을 셋(연구·설교·참고자료) + 출처로(멱등 · docs/1.txt 2-2)
            try:
                import ref_kinds as _RK
                rep['ref_kinds'] = _RK.migrate(conn)
            except Exception:                            # noqa: BLE001
                pass
            _cfg_set(conn, LAST_KEY, today + ' ' + json.dumps(rep, ensure_ascii=False))
            conn.commit()
            return rep
        finally:
            conn.close()
    except Exception as e:                               # noqa: BLE001
        try:
            import errlog
            errlog.warn('자동 정리 실패', e)
        except Exception:                                # noqa: BLE001
            pass
        return None
    finally:
        _LOCK.release()


def last_report(conn):
    v = _cfg_get(conn, LAST_KEY)
    if not v:
        return '', {}
    d, _, js = v.partition(' ')
    try:
        return d, json.loads(js)
    except Exception:                                    # noqa: BLE001
        return d, {}


# ── 저장 공간 ────────────────────────────────────────────────────────────
def _size(p):
    if os.path.isfile(p):
        return os.path.getsize(p) + sum(os.path.getsize(p + s) for s in ('-wal', '-shm') if os.path.exists(p + s))
    t = 0
    for d, _ds, fs in os.walk(p):
        for f in fs:
            try:
                t += os.path.getsize(os.path.join(d, f))
            except OSError:
                pass
    return t


def storage(conn):
    """→ [(열쇠, 바이트, 덧말)] — 화면이 이름을 붙인다."""
    out = [('MAIN', _size(appdb.MAIN_DB), ''),
           ('USER', _size(appdb.user_db_path(appdb.MAIN_DB)), ''),
           ('LINKPACK', _size(appdb.app_path('link_pack.db')), ''),
           ('MOBILE', _size(appdb.app_path('_mobile_cache')), ''),
           ('SPLASH', _size(appdb.app_path('splash')), '')]
    try:
        import errlog
        out.append(('ERRLOG', _size(errlog.log_dir()), ''))
    except Exception:                                    # noqa: BLE001
        pass
    for key, sql in (('SYS_AUDIT', 'SELECT COUNT(*) FROM sys_audit_log'),
                     ('USER_AUDIT', 'SELECT COUNT(*) FROM userdb.user_audit_log')):
        try:
            out.append((key, None, conn.execute(sql).fetchone()[0]))
        except Exception:                                # noqa: BLE001
            pass
    return out


# ── 내 자료 백업 · 되살리기 ──────────────────────────────────────────────
USER_TABLES_MUST = ('user_text_asset', 'user_config', 'user_link_asset')


def _check_user_db(path):
    """그 파일이 온전한 내 자료 DB 인가 → (ok, 까닭)."""
    try:
        c = sqlite3.connect('file:%s?mode=ro' % path, uri=True)
        try:
            if c.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
                return False, 'BROKEN'
            have = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if not set(USER_TABLES_MUST) <= have:
                return False, 'NOT_USER'
            return True, ''
        finally:
            c.close()
    except Exception:                                    # noqa: BLE001
        return False, 'BROKEN'


def backup(dst):
    """내 자료를 파일 하나로 → (ok, 까닭). `VACUUM INTO` — 쓰는 도중이어도 온전한 한 파일이 된다."""
    src = appdb.user_db_path(appdb.MAIN_DB)
    tmp = dst + '.tmp'
    try:
        if os.path.exists(tmp):
            os.remove(tmp)
        c = sqlite3.connect(src)
        try:
            c.execute('VACUUM INTO ?', (tmp,))
        finally:
            c.close()
        ok, why = _check_user_db(tmp)
        if not ok:
            os.remove(tmp)
            return False, why
        os.replace(tmp, dst)                             # 다 된 뒤에야 제 이름(§db_backup)
        return True, ''
    except Exception as e:                               # noqa: BLE001
        return False, str(e)


def stage_restore(src):
    """백업 파일을 되살릴 차례에 올린다 → (ok, 까닭). 실제로 갈아 끼우는 것은 **다음에 앱을 켤 때**
    (`apply_pending_restore`) — 앱이 쓰는 중인 파일은 바꿀 수 없다."""
    ok, why = _check_user_db(src)
    if not ok:
        return False, why
    dst = appdb.user_db_path(appdb.MAIN_DB) + RESTORE_SUFFIX
    try:
        shutil.copyfile(src, dst + '.tmp')
        os.replace(dst + '.tmp', dst)
        return True, ''
    except Exception as e:                               # noqa: BLE001
        return False, str(e)


def pending_restore():
    return os.path.exists(appdb.user_db_path(appdb.MAIN_DB) + RESTORE_SUFFIX)


def cancel_restore():
    try:
        os.remove(appdb.user_db_path(appdb.MAIN_DB) + RESTORE_SUFFIX)
    except OSError:
        pass


def apply_pending_restore(user_db=None):
    """앱을 켤 때 **DB 를 열기 전에** 부른다 → 바꿨으면 옛 파일을 남긴 이름, 아니면 ''.
    ⚠ 옛 파일은 지우지 않고 `user_data.db.before_restore_날짜` 로 남긴다(되돌릴 자리)."""
    cur = user_db or appdb.user_db_path(appdb.MAIN_DB)
    new = cur + RESTORE_SUFFIX
    if not os.path.exists(new):
        return ''
    ok, _why = _check_user_db(new)
    if not ok:
        os.replace(new, new + '.bad')
        return ''
    keep = cur + '.before_restore_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    if os.path.exists(cur):
        try:                                             # 쓰다 만 WAL 을 본 파일에 합친 뒤 옮긴다
            c = sqlite3.connect(cur)
            c.execute('PRAGMA wal_checkpoint(TRUNCATE)')
            c.close()
        except Exception:                                # noqa: BLE001
            pass
        os.replace(cur, keep)
        for s in ('-wal', '-shm'):
            if os.path.exists(cur + s):
                os.replace(cur + s, keep + s)
    os.replace(new, cur)
    return keep


def compact_main():
    """배포 자료 DB 를 다시 써서 빈 자리를 돌려준다(몇 분) → 줄어든 바이트."""
    p = appdb.MAIN_DB
    before = _size(p)
    c = sqlite3.connect(p)
    try:
        c.execute('VACUUM')
    finally:
        c.close()
    return before - _size(p)


def selftest():
    import tempfile
    ok = []

    def ck(c, m):
        ok.append(bool(c))
        print(('PASS ' if c else 'FAIL ') + m)

    c = appdb.connect()
    c.execute('SAVEPOINT hk')
    try:
        # ① 관리자 PC 면 아무것도 안 한다 · 사용자 PC 면 끄고 비운다
        n0 = c.execute('SELECT COUNT(*) FROM sys_audit_log').fetchone()[0]
        ck(sys_audit_off(c, publisher=True) == -1 and
           c.execute('SELECT COUNT(*) FROM sys_audit_log').fetchone()[0] == n0, '관리자 PC — 배포 자료 이력 그대로')
        # 끊긴 영상 — 내 자료가 가리키는 것은 묻는다
        rows = c.execute('SELECT media_id FROM sys_media_asset WHERE is_active=0 LIMIT 2').fetchall()
        if len(rows) == 2:
            a, b = rows[0][0], rows[1][0]
            c.execute('INSERT INTO userdb.user_media_fav(media_id, created_at) VALUES(?, datetime())', (a,))
            free, used = dead_media(c, publisher=False)
            ck(a in {u['id'] for u in used} and a not in free, '내 즐겨찾기가 가리키는 끊긴 영상 — 묻는다')
            ck(b in free or b in {u['id'] for u in used}, '끊긴 영상이 어느 한쪽에 든다')
            ck(dead_media(c, publisher=True) == ([], []), '관리자 PC — 끊긴 영상 정리 없음')
            live = c.execute('SELECT media_id FROM sys_media_asset WHERE is_active=1 LIMIT 1').fetchone()[0]
            ck(purge_media(c, [live], publisher=False, commit=False) == 0, '살아 있는 영상은 안 지운다')
            ck(purge_media(c, [a], with_refs=True, publisher=False, commit=False) == 1 and not c.execute(
                'SELECT 1 FROM userdb.user_media_fav WHERE media_id=?', (a,)).fetchone(), '고른 것은 내 자료와 함께 지운다')
        # 내가 담은 영상 — 관리자 PC 여부와 상관없이 지운다 · 그 영상의 내 연결도 함께
        uid = c.execute("INSERT INTO userdb.user_media_asset(verse_id, category, title, url, record_status)"
                        " VALUES(0,'STUDY','시험','https://youtu.be/AAAAAAAAAAA','LIVE')").lastrowid
        c.execute("INSERT INTO userdb.user_link_asset(link_type, clicked_id, target_id, record_status)"
                  " VALUES('UMED_VERS', ?, 1, 'LIVE')", (uid,))
        ck(any(v['id'] == uid for v in my_videos(c)), '내가 담은 유튜브 영상이 목록에 든다')
        ck(purge_my_videos(c, [uid], commit=False) == 1 and not c.execute(
            "SELECT 1 FROM userdb.user_link_asset WHERE link_type='UMED_VERS' AND clicked_id=?", (uid,)).fetchone(),
           '내 영상을 지우면 그 연결도 빠진다')
    finally:
        c.execute('ROLLBACK TO hk')
        c.execute('RELEASE hk')
        c.commit()
    # 백업 · 되살리기(임시 폴더)
    d = tempfile.mkdtemp()
    bk = os.path.join(d, 'b.db')
    good, why = backup(bk)
    ck(good and _check_user_db(bk)[0], '백업 파일이 온전하다 %s' % why)
    junk = os.path.join(d, 'j.db')
    sqlite3.connect(junk).execute('CREATE TABLE x(a)').connection.commit()
    ck(stage_restore(junk) == (False, 'NOT_USER'), '내 자료가 아닌 파일은 안 받는다')
    cur = os.path.join(d, 'user_data.db')
    shutil.copyfile(bk, cur)
    shutil.copyfile(bk, cur + RESTORE_SUFFIX)
    keep = apply_pending_restore(cur)
    ck(keep and os.path.exists(keep) and os.path.exists(cur) and not os.path.exists(cur + RESTORE_SUFFIX),
       '되살리기 — 옛 파일을 남기고 갈아 끼운다')
    ck(apply_pending_restore(cur) == '', '차례가 없으면 아무것도 안 한다')
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    if '--run' in sys.argv:
        print(run_daily(force=True))
