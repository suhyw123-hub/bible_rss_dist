# -*- coding: utf-8 -*-
"""db_shop.py — 추천몰(제휴 쇼핑몰·상품) 데이터 단일 소스. 2026-10-23 신설·영구.

사용자 지시(2026-10-23 · 아티팩트 3판 합의):
  「카테고리 = 기프트카드 → 교회용품 → 일반용품(생활필수품) 차례 · 상품이 없는
   카테고리는 표시 안 함 · 링크프라이스 같은 중개업체로 관리 · 나라마다 보일
   쇼핑몰 목록(한 나라에 여럿) · 검색창은 쇼핑몰마다 따로 — 사용자가 즐겨찾기한
   쇼핑몰만 · 즐겨찾기가 없으면 한 줄 안내 · 즐겨찾기는 PC ↔ 폰 동기화」.

★★★ 표는 셋(관리자 PC) — 쇼핑몰 · 카테고리 · 상품. 배너(ad-config)에서 떼어 냈다
  (나라·쇼핑몰·카테고리 단위가 배너 설정에 안 맞는다 — 합의 6).
★★★ 사용자에게는 **날마다 꾸러미 하나**(`shop.json`)로 간다 — `rss_publish` 의
  `shop` 갈래. 받는 쪽은 개인 DB `user_shop_feed` 에 통째로 담는다(코어팩이 갈아
  끼우지 못하게 — AI 모델 목록과 같은 까닭).
★★ 썸네일은 **우리 배포 서버**에 올린다(`shopimg_<지문>.jpg`) — 바깥 쇼핑몰에서
  그림을 받으면 그 호스트에 사용자 IP 가 보인다(추적 0 원칙).
★★ 즐겨찾기 `userdb.user_shop_fav` — 서버로는 안 간다 · PC 와 폰이 함께 쓴다
  (`mobile_sync` 사본 + 폰 사건 `SHOP_FAV`).

⚠ 이름은 짧은 번역 글이라 JSON 안에 언어마다 둔다(§0-3 규칙 2 ③).
⚠ 판(version)은 관리자가 저장할 때마다 오른다 — 받는 쪽은 더 새것만 담는다.

★ 2026-10-23 셋째 판(사용자 「앱에서 상품 통합검색 · 이 앱에 등록된 상품만 · xx쇼핑몰은 검색되지
  않는다는 라벨」) — 쇼핑몰 칸 `text_ok`(상품 글 검색 허용 · 중개업체가 상품 글을 주지 않는 쇼핑몰은 0) ·
  `find(v, q)` = 보이는 상품 가운데 검색 허용 쇼핑몰의 이름·설명에서 낱말을 모두 담은 것 ·
  `view` 의 `nosearch` = 검색에서 빠지는 쇼핑몰 이름. 찾는 일은 이 PC 안에서만(검색어가 밖으로 안 나간다).
"""
import hashlib
import io
import json
import re
import os
import sqlite3
from datetime import date, datetime

APP_DIR = os.path.dirname(os.path.abspath(__file__))
IMG_DIR = os.path.join(APP_DIR, '_shop_img')
SHOP_FILE = 'shop.json'

#: 갈래 차례가 곧 화면 차례(사용자 확정 — 기프트카드 → 교회용품 → 일반용품)
KINDS = ('GIFT', 'CHURCH', 'GENERAL')
KIND_NAME = {'GIFT': '기프트카드', 'CHURCH': '교회용품', 'GENERAL': '일반용품'}
#: 선물이 받는 사람에게 가는 길(상품마다 · 2026-10-23 사용자 합의 — 「e기프트카드를 사전에 식별」)
#:   LINK = 산 사람이 받은 선물 링크를 붙여 보낸다 · CODE = 상품권 번호를 붙여 보낸다 ·
#:   EMAIL = 쇼핑몰이 이메일로 직접 보낸다(아마존 e기프트카드) · KAKAO = 쇼핑몰이 카카오톡으로 직접 보낸다(선물하기)
#:   → 폰 말씀카드가 칸과 함께 보낼 글을 바꾼다(EMAIL·KAKAO 는 붙일 것이 없고 「…보냈어요」 한 줄).
DELIVERS = ('LINK', 'CODE', 'EMAIL', 'KAKAO')
DELIVER_NAME = {'LINK': '링크 붙여 보냄', 'CODE': '상품권 번호 붙여 보냄', 'EMAIL': '쇼핑몰이 이메일로 보냄',
                'KAKAO': '쇼핑몰이 카카오톡으로 보냄'}
#: 중개업체(늘리려면 한 줄 — 칸은 쇼핑몰마다 받는다 · 합의 2)
NETWORKS = ('LINKPRICE', 'COUPANG', 'AMAZON', 'RAKUTEN', 'DIRECT')

#: 처음 심을 카테고리(합의 1 — 기프트 1 · 교회 2 · 일반 8). 관리자 화면에서 고친다.
SEED_CATS = (
    ('GIFT_CARD', 'GIFT', 10, {'KO': '기프트카드', 'EN': 'Gift cards'}),
    ('CHURCH_WORSHIP', 'CHURCH', 10, {'KO': '교회·예배 용품', 'EN': 'Church & worship'}),
    ('CHURCH_EVENT', 'CHURCH', 20, {'KO': '행사·선교 용품', 'EN': 'Events & missions'}),
    ('FOOD', 'GENERAL', 10, {'KO': '식품·생수', 'EN': 'Food & water'}),
    ('LIVING', 'GENERAL', 20, {'KO': '생활용품', 'EN': 'Household'}),
    ('KITCHEN', 'GENERAL', 30, {'KO': '주방', 'EN': 'Kitchen'}),
    ('HEALTH', 'GENERAL', 40, {'KO': '건강·위생', 'EN': 'Health & hygiene'}),
    ('BEAUTY', 'GENERAL', 50, {'KO': '뷰티·바디', 'EN': 'Beauty & body'}),
    ('KIDS', 'GENERAL', 60, {'KO': '유아·어린이', 'EN': 'Baby & kids'}),
    ('BOOKS', 'GENERAL', 70, {'KO': '문구·도서', 'EN': 'Stationery & books'}),
    ('DIGITAL', 'GENERAL', 80, {'KO': '가전·디지털', 'EN': 'Electronics'}),
)

DDL = (
    """CREATE TABLE IF NOT EXISTS sys_shop_mall(
        mall_id INTEGER PRIMARY KEY AUTOINCREMENT,
        mall_code TEXT UNIQUE NOT NULL,
        names TEXT DEFAULT '{}',
        network TEXT DEFAULT 'LINKPRICE',
        adv_id TEXT DEFAULT '',
        countries TEXT DEFAULT '',
        home_url TEXT DEFAULT '',
        search_tpl TEXT DEFAULT '',
        logo BLOB,
        sort_order INTEGER DEFAULT 100,
        record_status TEXT DEFAULT 'LIVE',
        text_ok INTEGER DEFAULT 1)""",
    """CREATE TABLE IF NOT EXISTS sys_shop_category(
        cat_id INTEGER PRIMARY KEY AUTOINCREMENT,
        cat_code TEXT UNIQUE NOT NULL,
        kind TEXT DEFAULT 'GENERAL',
        names TEXT DEFAULT '{}',
        sort_order INTEGER DEFAULT 100,
        record_status TEXT DEFAULT 'LIVE')""",
    """CREATE TABLE IF NOT EXISTS sys_shop_item(
        item_id INTEGER PRIMARY KEY AUTOINCREMENT,
        mall_code TEXT NOT NULL,
        cat_code TEXT NOT NULL,
        names TEXT DEFAULT '{}',
        descs TEXT DEFAULT '{}',
        url TEXT DEFAULT '',
        thumb BLOB,
        price_band TEXT DEFAULT '',
        active_from TEXT DEFAULT '',
        active_to TEXT DEFAULT '',
        sort_order INTEGER DEFAULT 100,
        record_status TEXT DEFAULT 'LIVE',
        deliver TEXT DEFAULT 'LINK')""",
    """CREATE TABLE IF NOT EXISTS sys_shop_meta(
        k TEXT PRIMARY KEY, v TEXT)""",
)
USER_DDL = (
    """CREATE TABLE IF NOT EXISTS userdb.user_shop_feed(
        id INTEGER PRIMARY KEY CHECK(id=1),
        version INTEGER DEFAULT 0,
        payload TEXT DEFAULT '{}',
        received_at TEXT)""",
    """CREATE TABLE IF NOT EXISTS userdb.user_shop_fav(
        mall_code TEXT PRIMARY KEY,
        created_at TEXT)""",
    # ★ 2026-10-23 숨긴 쇼핑몰(사용자 「회원가입하지 않은 쇼핑몰은 숨기기」) — 쇼핑몰도 그 상품도 안 보인다
    """CREATE TABLE IF NOT EXISTS userdb.user_shop_hide(
        mall_code TEXT PRIMARY KEY,
        created_at TEXT)""",
    # ★ 2026-10-24 내 쇼핑몰 모음(사용자 「국가전체 쇼핑몰 목록에서 회원가입한 쇼핑몰을 골라 자주 들르는 모음」) —
    #   비어 있으면 그 나라 쇼핑몰 · 차 있으면 나라와 상관없이 이 쇼핑몰들(해외 직구) · 「숨기기」를 대신한다
    """CREATE TABLE IF NOT EXISTS userdb.user_shop_mine(
        mall_code TEXT PRIMARY KEY,
        created_at TEXT)""",
    # ★ 2026-10-24 자주 사는 상품(반복 구매) — 상품 번호(꾸러미 id)
    """CREATE TABLE IF NOT EXISTS userdb.user_shop_repeat(
        item_key TEXT PRIMARY KEY,
        created_at TEXT)""",
)


def _has_userdb(conn):
    try:
        return any(r[1] == 'userdb' for r in conn.execute('PRAGMA database_list'))
    except Exception:
        return False


def ensure(conn, seed=True):
    """표를 만들고(없으면) 카테고리 씨앗을 한 번 심는다. 멱등."""
    for d in DDL:
        conn.execute(d)
    if 'text_ok' not in {r[1] for r in conn.execute('PRAGMA table_info(sys_shop_mall)')}:
        conn.execute('ALTER TABLE sys_shop_mall ADD COLUMN text_ok INTEGER DEFAULT 1')
    # ★ 2026-10-29 해외배송 — 그 나라에 해외배송으로 보내는 나라들(countries = 국내배송 나라)
    if 'abroad' not in {r[1] for r in conn.execute('PRAGMA table_info(sys_shop_mall)')}:
        conn.execute("ALTER TABLE sys_shop_mall ADD COLUMN abroad TEXT DEFAULT ''")
    # ★ 2026-10-29 쇼핑몰마다 제휴 고지 문구(언어마다 JSON) — 쿠팡·아마존처럼 정해진 문구를 요구하는 곳(사용자 「쇼핑몰에 따라 차별적으로 · 모두 충족」)
    if 'notice' not in {r[1] for r in conn.execute('PRAGMA table_info(sys_shop_mall)')}:
        conn.execute("ALTER TABLE sys_shop_mall ADD COLUMN notice TEXT DEFAULT '{}'")
    if 'deliver' not in {r[1] for r in conn.execute('PRAGMA table_info(sys_shop_item)')}:
        conn.execute("ALTER TABLE sys_shop_item ADD COLUMN deliver TEXT DEFAULT 'LINK'")
    # ★ 2026-10-29 짧은 이름(폰 수직 카테고리 칸 · 언어마다 · 비면 이름의 앞부분)
    if 'shorts' not in {r[1] for r in conn.execute('PRAGMA table_info(sys_shop_category)')}:
        conn.execute("ALTER TABLE sys_shop_category ADD COLUMN shorts TEXT DEFAULT '{}'")
    if _has_userdb(conn):
        for d in USER_DDL:
            conn.execute(d)
    else:
        for d in USER_DDL:
            conn.execute(d.replace('userdb.', ''))
    if seed:
        n = conn.execute('SELECT COUNT(*) FROM sys_shop_category').fetchone()[0]
        done = conn.execute("SELECT v FROM sys_shop_meta WHERE k='SEEDED'").fetchone()
        if not n and not done:
            for code, kind, so, names in SEED_CATS:
                conn.execute('INSERT OR IGNORE INTO sys_shop_category(cat_code,kind,names,sort_order)'
                             ' VALUES(?,?,?,?)', (code, kind, json.dumps(names, ensure_ascii=False), so))
            conn.execute("INSERT OR REPLACE INTO sys_shop_meta(k,v) VALUES('SEEDED','1')")
    conn.commit()


# ── 이름 ─────────────────────────────────────────────────────────────
def jload(s):
    try:
        d = json.loads(s or '{}')
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def name_of(names, lang):
    """그 언어 → EN → KO → 아무것이나. 없으면 ''."""
    if isinstance(names, str):
        names = jload(names)
    names = names or {}
    for k in ((lang or 'KO').upper(), 'EN', 'KO'):
        v = (names.get(k) or '').strip()
        if v:
            return v
    for v in names.values():
        if (v or '').strip():
            return v.strip()
    return ''


def countries_of(s):
    return [c.strip().upper() for c in (s or '').replace(';', ',').split(',') if c.strip()]


# ── 판 ───────────────────────────────────────────────────────────────
def sys_version(conn):
    try:
        r = conn.execute("SELECT v FROM sys_shop_meta WHERE k='VERSION'").fetchone()
        return int(r[0]) if r and r[0] else 0
    except Exception:
        return 0


def bump(conn):
    """관리자가 무엇을 고칠 때마다 — 받는 쪽은 판이 더 높을 때만 담는다."""
    v = sys_version(conn) + 1
    conn.execute("INSERT OR REPLACE INTO sys_shop_meta(k,v) VALUES('VERSION',?)", (str(v),))
    conn.commit()
    return v


# ── 그림 ─────────────────────────────────────────────────────────────
def img_name(blob):
    if not blob:
        return ''
    return 'shopimg_%s.jpg' % hashlib.sha1(bytes(blob)).hexdigest()[:16]


def make_thumb(path_or_bytes, width=360):
    """그림 파일 → 폭 360 JPEG 바이트. PIL 이 없으면 원본 그대로."""
    data = path_or_bytes
    if isinstance(path_or_bytes, str):
        with open(path_or_bytes, 'rb') as f:
            data = f.read()
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(data)).convert('RGB')
        if im.width > width:
            im = im.resize((width, max(1, int(im.height * width / im.width))))
        out = io.BytesIO()
        im.save(out, 'JPEG', quality=82, optimize=True)
        return out.getvalue()
    except Exception:
        return data


def cache_img(name, blob):
    """그림을 이 PC 캐시에 둔다(관리자 PC 는 표에서 · 사용자 PC 는 받아서)."""
    if not name or not blob:
        return ''
    try:
        os.makedirs(IMG_DIR, exist_ok=True)
        p = os.path.join(IMG_DIR, name)
        if not os.path.exists(p):
            with open(p, 'wb') as f:
                f.write(bytes(blob))
        return p
    except Exception:
        return ''


def img_path(name):
    if not name:
        return ''
    p = os.path.join(IMG_DIR, name)
    return p if os.path.exists(p) else ''


# ── 내보내기(관리자) ─────────────────────────────────────────────────
def export_payload(conn, with_images=False):
    """관리자 표 → 꾸러미 dict(+ 올릴 그림 {이름: 바이트}).

    ⚠ 글자가 늘 같아야 한다 — 받는 쪽 판정·지문이 그것을 본다(정렬은 build_json).
    """
    ensure(conn)
    imgs = {}
    malls = []
    for r in conn.execute("SELECT mall_code,names,network,adv_id,countries,home_url,search_tpl,"
                          "logo,sort_order,COALESCE(text_ok,1),COALESCE(abroad,''),COALESCE(notice,'{}') FROM sys_shop_mall WHERE COALESCE(record_status,'LIVE')='LIVE'"
                          " ORDER BY sort_order, mall_id"):
        nm = img_name(r[7])
        if nm:
            imgs[nm] = bytes(r[7])
        malls.append({'code': r[0], 'names': jload(r[1]), 'network': r[2] or '',
                      'adv': r[3] or '', 'countries': countries_of(r[4]),
                      'home': r[5] or '', 'search': r[6] or '', 'logo': nm,
                      'sort': int(r[8] or 0), 'text': 1 if r[9] else 0, 'abroad': countries_of(r[10]),
                      'notice': jload(r[11])})
    cats = []
    for r in conn.execute("SELECT cat_code,kind,names,sort_order,COALESCE(shorts,'{}') FROM sys_shop_category"
                          " WHERE COALESCE(record_status,'LIVE')='LIVE' ORDER BY sort_order, cat_id"):
        cats.append({'code': r[0], 'kind': r[1] if r[1] in KINDS else 'GENERAL',
                     'names': jload(r[2]), 'sort': int(r[3] or 0), 'shorts': jload(r[4])})
    items = []
    for r in conn.execute("SELECT item_id,mall_code,cat_code,names,descs,url,thumb,price_band,"
                          "active_from,active_to,sort_order,COALESCE(deliver,'LINK') FROM sys_shop_item"
                          " WHERE COALESCE(record_status,'LIVE')='LIVE' ORDER BY sort_order, item_id"):
        nm = img_name(r[6])
        if nm:
            imgs[nm] = bytes(r[6])
        items.append({'id': int(r[0]), 'mall': r[1], 'cat': r[2], 'names': jload(r[3]),
                      'descs': jload(r[4]), 'url': r[5] or '', 'img': nm,
                      'band': r[7] or '', 'from': r[8] or '', 'to': r[9] or '',
                      'sort': int(r[10] or 0), 'deliver': r[11] if r[11] in DELIVERS else 'LINK'})
    payload = {'version': sys_version(conn), 'malls': malls, 'cats': cats, 'items': items}
    return (payload, imgs) if with_images else payload


def build_json(payload):
    return json.dumps(payload or {}, ensure_ascii=False, indent=1, sort_keys=True) + '\n'


def parse_json(text):
    try:
        d = json.loads(text or '{}')
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


# ── 받기(사용자) ─────────────────────────────────────────────────────
def user_version(conn):
    try:
        r = conn.execute('SELECT version FROM user_shop_feed WHERE id=1').fetchone()
        return int(r[0]) if r else 0
    except Exception:
        return 0


def apply_payload(conn, payload):
    """받은 꾸러미 → user_shop_feed. 판이 더 높을 때만(멱등). → {'applied', 'version', 'why'}"""
    ensure(conn, seed=False)
    if not isinstance(payload, dict) or 'items' not in payload:
        return {'applied': False, 'version': user_version(conn), 'why': '꾸러미가 아닙니다'}
    v = int(payload.get('version') or 0)
    cur = user_version(conn)
    if v <= cur:
        return {'applied': False, 'version': cur, 'why': '판이 같거나 낮습니다(%d ≤ %d)' % (v, cur)}
    conn.execute('INSERT OR REPLACE INTO user_shop_feed(id,version,payload,received_at) VALUES(1,?,?,?)',
                 (v, json.dumps(payload, ensure_ascii=False),
                  datetime.now().isoformat(timespec='seconds')))
    conn.commit()
    return {'applied': True, 'version': v, 'why': ''}


def need_images(payload):
    """꾸러미가 가리키는데 이 PC 캐시에 없는 그림 이름."""
    out = []
    for m in (payload or {}).get('malls') or []:
        if m.get('logo') and not img_path(m['logo']):
            out.append(m['logo'])
    for it in (payload or {}).get('items') or []:
        if it.get('img') and not img_path(it['img']):
            out.append(it['img'])
    return sorted(set(out))


def fetch_images(payload, servers, limit=200):
    """빠진 그림을 배포 서버에서 받아 캐시에 둔다(이름에 지문이 있어 확인할 수 있다)."""
    from urllib.request import Request, urlopen
    got = 0
    for nm in need_images(payload)[:limit]:
        want = nm.split('_', 1)[-1].split('.', 1)[0]
        for srv in servers or []:
            if not srv.get('enabled', True):
                continue
            base = (srv.get('location') or '').rstrip('/')
            if not base.startswith('http'):
                continue
            try:
                req = Request('%s/%s' % (base, nm), headers={'User-Agent': 'BibleMatrix-RSS/1.0'})
                with urlopen(req, timeout=15) as r:
                    data = r.read()
                if hashlib.sha1(data).hexdigest()[:16] == want:
                    cache_img(nm, data)
                    got += 1
                    break
            except Exception:
                continue
    return got


def catalog(conn):
    """지금 이 PC 가 쓸 꾸러미 — 관리자 표와 받은 것 가운데 판이 높은 것.

    ⚠ 관리자 PC 는 표에서 그림을 바로 캐시에 둔다(받을 서버를 거치지 않는다).
    """
    ensure(conn, seed=False)
    sysv = 0
    try:
        has_sys = conn.execute('SELECT COUNT(*) FROM sys_shop_item').fetchone()[0] > 0 or \
            conn.execute('SELECT COUNT(*) FROM sys_shop_mall').fetchone()[0] > 0
        sysv = sys_version(conn) if has_sys else 0
    except Exception:
        has_sys = False
    uv = user_version(conn)
    if has_sys and sysv >= uv:
        p, imgs = export_payload(conn, with_images=True)
        for nm, b in imgs.items():
            cache_img(nm, b)
        return p
    if uv:
        r = conn.execute('SELECT payload FROM user_shop_feed WHERE id=1').fetchone()
        return parse_json(r[0] if r else '{}')
    return {'version': 0, 'malls': [], 'cats': [], 'items': []}


# ── 즐겨찾기 ─────────────────────────────────────────────────────────
def favs(conn):
    try:
        return [r[0] for r in conn.execute('SELECT mall_code FROM user_shop_fav ORDER BY created_at, mall_code')]
    except Exception:
        return []


def set_fav(conn, code, on):
    ensure(conn, seed=False)
    if on:
        conn.execute('INSERT OR IGNORE INTO user_shop_fav(mall_code,created_at) VALUES(?,?)',
                     (code, datetime.now().isoformat(timespec='seconds')))
    else:
        conn.execute('DELETE FROM user_shop_fav WHERE mall_code=?', (code,))
    conn.commit()


def _codes(conn, table, col='mall_code'):
    try:
        return [r[0] for r in conn.execute('SELECT %s FROM %s ORDER BY created_at, %s' % (col, table, col))]
    except Exception:
        return []


def _set(conn, table, col, key, on):
    ensure(conn, seed=False)
    if on:
        conn.execute('INSERT OR IGNORE INTO %s(%s,created_at) VALUES(?,?)' % (table, col),
                     (key, datetime.now().isoformat(timespec='seconds')))
    else:
        conn.execute('DELETE FROM %s WHERE %s=?' % (table, col), (key,))
    conn.commit()


def mine(conn):
    """내 쇼핑몰 모음 — 비면 그 나라 쇼핑몰이 보인다."""
    return _codes(conn, 'user_shop_mine')


def set_mine(conn, code, on):
    _set(conn, 'user_shop_mine', 'mall_code', code, on)


def repeats(conn):
    """자주 사는 상품 — 상품 번호(글자) 목록."""
    return _codes(conn, 'user_shop_repeat', 'item_key')


def set_repeat(conn, item_id, on):
    _set(conn, 'user_shop_repeat', 'item_key', str(item_id), on)


def recommend_text(name, mall, url, memo=''):
    """상품등록 추천 — 관리자 소통 통로(user_feedback kind SHOP)로 갈 글. 관리자 추천몰 관리가 줄마다 다시 읽는다."""
    lines = ['[상품 추천]', '상품: ' + (name or '').strip(), '쇼핑몰: ' + (mall or '').strip(),
             '주소: ' + (url or '').strip()]
    if (memo or '').strip():
        lines.append('메모: ' + memo.strip())
    return '\n'.join(lines)


def parse_recommend(text):
    """recommend_text 의 거꾸로 — {'상품','쇼핑몰','주소','메모'}."""
    out = {}
    for ln in (text or '').splitlines():
        if ': ' in ln:
            k, v = ln.split(': ', 1)
            if k in ('상품', '쇼핑몰', '주소', '메모'):
                out[k] = v.strip()
    return out


def hides(conn):
    try:
        return [r[0] for r in conn.execute('SELECT mall_code FROM user_shop_hide ORDER BY mall_code')]
    except Exception:
        return []


def set_hide(conn, code, on):
    """쇼핑몰 숨기기 — 켜면 그 쇼핑몰과 상품이 화면에서 빠진다(검색창 표시도 함께 끈다)."""
    ensure(conn, seed=False)
    if on:
        conn.execute('INSERT OR IGNORE INTO user_shop_hide(mall_code,created_at) VALUES(?,?)',
                     (code, datetime.now().isoformat(timespec='seconds')))
    else:
        conn.execute('DELETE FROM user_shop_hide WHERE mall_code=?', (code,))
    conn.commit()


# ── 보일 것 ──────────────────────────────────────────────────────────
def in_window(it, today=None):
    t = (today or date.today()).isoformat()
    f, e = (it.get('from') or '')[:10], (it.get('to') or '')[:10]
    try:
        if f and len(f) == 10 and t < f:
            return False
        if e and len(e) == 10 and t > e:
            return False
    except Exception:
        return True
    return True


def ship_of(m, country):
    """★ 2026-10-29 그 나라에서 이 쇼핑몰은 국내배송(D)인가 해외배송(X)인가 — 나라마다 정한다
    (같은 아마존이 미국 사람에게는 국내, 한국 사람에게는 해외). 「모든 나라」면 가를 기준이 없어 D.
    내 모음에 든 다른 나라 쇼핑몰도 X. 폰 shopShip 과 같다."""
    cc = (country or '').upper()
    if cc in ('', 'ALL'):
        return 'D'
    cs = m.get('countries') or []
    return 'D' if (not cs) or ('ALL' in cs) or (cc in cs) else 'X'


def mall_visible(m, country):
    """그 나라에 보이는 쇼핑몰 = 국내배송 나라 + 해외배송 나라."""
    cc = (country or '').upper()
    return ship_of(m, cc) == 'D' or cc in (m.get('abroad') or [])


def view(payload, country, lang, fav_codes=(), today=None, hidden=(), mine=(), off=(), repeat=(), abroad=True):
    """화면이 그릴 것 하나로 — PC·폰 같은 규칙.

    → {'cats': [{code, kind, name, items:[…]}], 'malls': [{code,name,fav,search,…}],
       'searches': [즐겨찾기한 검색 가능 쇼핑몰], 'count': 보일 상품 수}
    · 그 나라 쇼핑몰만 · 그 쇼핑몰의 상품만 · 때가 된 것만 · 상품 0인 카테고리는 뺀다.
    · 카테고리 차례 = 갈래(기프트카드 → 교회용품 → 일반용품) → 관리자 차례.
    · 숨긴 쇼핑몰(`hidden`)은 쇼핑몰도 상품도 검색창도 없다 — 설정 화면은 `country_malls` 를 본다.
    · 검색창 = 검색창 표시(fav)한 쇼핑몰 · ★ 그 나라에 보이는 쇼핑몰이 하나뿐이면 저절로(auto).
    """
    lang = (lang or 'KO').upper()
    favset = set(fav_codes or ())
    hideset = set(hidden or ())
    mineset = set(mine or ())
    offset = set(off or ())
    every = sorted((payload or {}).get('malls') or [], key=lambda m: (int(m.get('sort') or 0), m.get('code') or ''))
    allm = every if (country or '').upper() == 'ALL' else [m for m in every if mall_visible(m, country)]
    ship = {m['code']: ship_of(m, country) for m in every}
    # 쇼핑몰마다 고지 문구(그 언어 → EN → KO · 없으면 화면이 일반 고지)
    notice = {m['code']: name_of(m.get('notice'), lang) for m in every}
    if not abroad:                       # ★ 2026-10-29 쇼핑 설정 「해외배송 쇼핑몰도 보기」를 끄면 해외배송은 통째로 빠진다
        allm = [m for m in allm if ship[m['code']] == 'D']
    # ★ 2026-10-24 내 모음 — 차 있으면 나라와 상관없이 그 쇼핑몰(해외 직구) · 비면 그 나라 쇼핑몰(옛 숨기기는 이때만)
    if mineset:
        base = [m for m in every if m['code'] in mineset]
    else:
        base = [m for m in allm if m['code'] not in hideset]
    if not abroad:
        base = [m for m in base if ship[m['code']] == 'D']
    basecodes = {m['code'] for m in base}
    country_malls = [dict(m, name=name_of(m.get('names'), lang) or m['code'], fav=m['code'] in favset,
                          hidden=m['code'] in hideset, mine=m['code'] in basecodes, ship=ship[m['code']]) for m in allm]
    malls = base
    mname = {m['code']: name_of(m.get('names'), lang) or m['code'] for m in malls}
    # ★ 2026-10-29 쇼핑몰 차례 = 화면 언어의 이름 순서(폰 shopView 와 같다)
    # ★ 2026-10-29 국내배송 묶음 먼저 · 해외배송 묶음 뒤 · 묶음 안은 이름 순서
    malls.sort(key=lambda m: (ship[m['code']] == 'X', mname[m['code']].casefold()))
    # ★ 2026-10-29 Off 쇼핑몰 상품도 담아 둔다 — 카테고리 자리는 「어느 쇼핑몰에든 상품이 있나」(every) ·
    #   화면 목록(items)은 On 쇼핑몰 것만(Off 해도 칸이 안 사라진다 · 폰과 같다)
    items = [it for it in (payload or {}).get('items') or []
             if it.get('mall') in mname and in_window(it, today) and (it.get('url') or '').strip()]
    by_cat = {}
    for it in sorted(items, key=lambda x: (int(x.get('sort') or 0), int(x.get('id') or 0))):
        by_cat.setdefault(it.get('cat'), []).append(dict(
            it, name=name_of(it.get('names'), lang), desc=name_of(it.get('descs'), lang),
            mall_name=mname.get(it.get('mall'), ''), ship=ship.get(it.get('mall'), 'D'),
            notice=notice.get(it.get('mall'), '')))
    cats = []
    for c in (payload or {}).get('cats') or []:
        lst = by_cat.get(c.get('code'))
        if not lst:
            continue                     # ⚠ 어느 쇼핑몰에도 상품이 없는 카테고리는 안 보인다(사용자)
        nm = name_of(c.get('names'), lang) or c['code']
        cats.append({'code': c['code'], 'kind': c.get('kind') if c.get('kind') in KINDS else 'GENERAL',
                     'name': nm, 'short': short_of(c.get('shorts'), nm, lang), 'sort': int(c.get('sort') or 0),
                     'items': [it for it in lst if it.get('mall') not in offset], 'every': lst})
    cats.sort(key=lambda c: (KINDS.index(c['kind']), c['sort'], c['code']))
    out_malls = [dict(m, name=mname[m['code']], fav=m['code'] in favset, text=text_ok(m), on=m['code'] not in offset,
                      ship=ship[m['code']])
                 for m in malls]
    auto = len(out_malls) == 1
    searches = [dict(m, auto=auto and not m['fav']) for m in out_malls
                if (m['fav'] or auto) and '{q}' in (m.get('search') or '')]
    # ★ 자주 사는 상품 — 내 모음·체크와 상관없이 때가 되고 주소가 있는 것(늘 먼저 주문하는 자리)
    rset = {str(x) for x in (repeat or ())}
    allname = {m['code']: name_of(m.get('names'), lang) or m['code'] for m in every}
    reps = [dict(it, name=name_of(it.get('names'), lang), desc=name_of(it.get('descs'), lang),
                 mall_name=allname.get(it.get('mall'), ''), ship=ship.get(it.get('mall'), 'D'),
                 notice=notice.get(it.get('mall'), ''))
            for it in (payload or {}).get('items') or []
            if str(it.get('id')) in rset and in_window(it, today) and (it.get('url') or '').strip()]
    return {'cats': cats, 'malls': out_malls, 'searches': searches,
            'count': sum(len(c['items']) for c in cats), 'country_malls': country_malls,
            'nosearch': [m['name'] for m in out_malls if not m['text']], 'repeat': reps,
            'all_count': len([it for it in (payload or {}).get('items') or [] if it.get('mall') in basecodes])}


def short_of(shorts, name, lang):
    """짧은 이름 — 관리자가 적은 것 → 없으면 이름의 앞 토막(「교회·예배」 → 「교회」 · 다섯 글자까지). 폰 shopShort 와 같다."""
    s = name_of(shorts, lang) if shorts else ''
    if s:
        return s
    parts = [x for x in re.split(r'[·・,/()\s]', name or '') if x.strip()]
    head = (parts[0] if parts else (name or '')).strip()
    return head[:5]


def text_ok(m):
    """그 쇼핑몰 상품 글을 통합검색에 쓸 수 있나 — 칸이 없는 옛 꾸러미는 쓴다."""
    v = (m or {}).get('text', 1)
    return v not in (0, '0', False)


def _fold(s):
    return ' '.join((s or '').casefold().split())


def find(v, q):
    """앱에서 상품 통합검색 — 보이는 상품 가운데 검색 허용 쇼핑몰의 이름·설명에 낱말이 모두 든 것.

    → [(카테고리 dict, 상품 dict)] · 이름에 걸린 것이 앞. 폰 `shopFind` 와 같은 규칙.
    ⚠ 이 PC 안에서만 찾는다 — 검색어는 어디로도 안 나간다.
    """
    words = _fold(q).split()
    if not words:
        return []
    ok = {m['code'] for m in (v or {}).get('malls') or [] if text_ok(m)}
    hit = []
    for c in (v or {}).get('cats') or []:
        for it in c.get('every', c['items']):     # ★ 2026-10-29 Off 쇼핑몰 상품도 찾는다(화면이 흐리게 · 폰과 같다)
            if it.get('mall') not in ok:
                continue
            nm, ds = _fold(it.get('name')), _fold(it.get('desc'))
            hay = nm + ' ' + ds
            if all(w in hay for w in words):
                hit.append((0 if all(w in nm for w in words) else 1, c, it))
    hit.sort(key=lambda x: x[0])
    return [(c, it) for _r, c, it in hit]


def search_url(mall, q):
    from urllib.parse import quote
    tpl = (mall or {}).get('search') or ''
    q = (q or '').strip()
    if not q or '{q}' not in tpl:
        return ''
    return tpl.replace('{q}', quote(q))


def item_count(db_path, lang='KO', country=None):
    """지금 이 사람에게 보일 상품 수 — 탭을 그릴지 정하는 문(화면과 같은 규칙)."""
    try:
        import appdb
        import ads
        with appdb.connect(db_path) as c:
            p = catalog(c)
            cc = country or ads.get_country(db_path)
            r = c.execute("SELECT config_val FROM user_config WHERE config_key='SHOP_ABROAD'").fetchone()
            v = view(p, cc, lang, favs(c), hidden=hides(c), mine=mine(c), abroad=not (r and r[0] == '0'))
            return v['all_count'] + len(v['repeat'])
    except Exception:
        return 0


# ── 자가 검증 ────────────────────────────────────────────────────────
def selftest():
    ok, bad = [0], [0]

    def t(name, cond, got=''):
        if cond:
            ok[0] += 1
            print('  OK   ' + name)
        else:
            bad[0] += 1
            print('  FAIL ' + name + ('   ' + repr(got) if got != '' else ''))

    c = sqlite3.connect(':memory:')
    ensure(c)
    t('씨앗 카테고리 열하나', c.execute('SELECT COUNT(*) FROM sys_shop_category').fetchone()[0] == 11)
    t('씨앗 = 기프트 1 · 교회 2 · 일반 8',
      [r[0] for r in c.execute('SELECT COUNT(*) FROM sys_shop_category GROUP BY kind ORDER BY kind')] == [2, 8, 1])
    ensure(c)
    t('두 번 불러도 안 는다', c.execute('SELECT COUNT(*) FROM sys_shop_category').fetchone()[0] == 11)
    c.execute("DELETE FROM sys_shop_category WHERE cat_code='KIDS'")
    ensure(c)
    t('관리자가 지운 씨앗을 되살리지 않는다',
      c.execute("SELECT COUNT(*) FROM sys_shop_category WHERE cat_code='KIDS'").fetchone()[0] == 0)
    J = lambda d: json.dumps(d, ensure_ascii=False)
    c.execute("INSERT INTO sys_shop_mall(mall_code,names,countries,search_tpl,sort_order) VALUES(?,?,?,?,?)",
              ('M_A', J({'KO': '가 마트'}), 'KR', 'https://a.example/s?q={q}', 10))
    c.execute("INSERT INTO sys_shop_mall(mall_code,names,countries,search_tpl,sort_order) VALUES(?,?,?,?,?)",
              ('M_B', J({'KO': '나 쇼핑', 'EN': 'Na'}), 'KR,US', '', 20))
    c.execute("INSERT INTO sys_shop_mall(mall_code,names,countries,sort_order) VALUES(?,?,?,?)",
              ('M_US', J({'EN': 'US mall'}), 'US', 30))
    ins = ("INSERT INTO sys_shop_item(mall_code,cat_code,names,url,active_from,active_to,sort_order)"
           " VALUES(?,?,?,?,?,?,?)")
    c.execute(ins, ('M_A', 'FOOD', J({'KO': '생수'}), 'https://a/1', '', '', 1))
    c.execute(ins, ('M_B', 'GIFT_CARD', J({'KO': '커피 쿠폰'}), 'https://b/1', '', '', 1))
    c.execute(ins, ('M_A', 'CHURCH_WORSHIP', J({'KO': '성찬기'}), 'https://a/2', '', '', 1))
    c.execute(ins, ('M_US', 'LIVING', J({'EN': 'Towel'}), 'https://u/1', '', '', 1))
    c.execute(ins, ('M_A', 'KITCHEN', J({'KO': '나중'}), 'https://a/3', '2099-01-01', '', 1))
    c.execute(ins, ('M_A', 'BEAUTY', J({'KO': '주소 없음'}), '', '', '', 1))
    bump(c)
    p = export_payload(c)
    t('판이 실린다', p['version'] == 1, p['version'])
    t('글자가 늘 같다', build_json(p) == build_json(export_payload(c)))
    v = view(p, 'KR', 'KO')
    t('한국 = 그 나라 쇼핑몰 둘', [m['code'] for m in v['malls']] == ['M_A', 'M_B'], [m['code'] for m in v['malls']])
    t('카테고리 차례 = 기프트 → 교회 → 일반',
      [x['code'] for x in v['cats']] == ['GIFT_CARD', 'CHURCH_WORSHIP', 'FOOD'], [x['code'] for x in v['cats']])
    t('때가 안 된 것·주소 없는 것·다른 나라 것은 빠진다', v['count'] == 3, v['count'])
    t('상품 없는 카테고리는 안 보인다', all(x['items'] for x in v['cats']))
    t('즐겨찾기 0 → 검색창 0', v['searches'] == [])
    v2 = view(p, 'KR', 'KO', ['M_A', 'M_B'])
    t('검색창 = 즐겨찾기 가운데 검색 틀이 있는 쇼핑몰만', [m['code'] for m in v2['searches']] == ['M_A'])
    t('즐겨찾기한 쇼핑몰이 앞에', v2['malls'][0]['fav'])
    t('검색 주소에 낱말이 담긴다', search_url(v2['searches'][0], '생수 2L') ==
      'https://a.example/s?q=%EC%83%9D%EC%88%98%202L')
    t('이름 = 그 언어 → EN → KO', name_of({'KO': '가', 'EN': 'A'}, 'JA') == 'A' and
      name_of({'KO': '가'}, 'JA') == '가')
    vu = view(p, 'US', 'EN')
    t('미국 = 미국 쇼핑몰 + 둘 다 걸린 쇼핑몰', [m['code'] for m in vu['malls']] == ['M_B', 'M_US'])
    # 받기
    g = apply_payload(c, p)
    t('받으면 담는다', g['applied'] and user_version(c) == 1)
    t('같은 판은 안 담는다', not apply_payload(c, p)['applied'])
    t('꾸러미가 아니면 안 담는다', not apply_payload(c, {'x': 1})['applied'])
    set_fav(c, 'M_A', True)
    set_fav(c, 'M_A', True)
    t('즐겨찾기 멱등', favs(c) == ['M_A'])
    set_fav(c, 'M_A', False)
    t('즐겨찾기 끄기', favs(c) == [])
    t('그림 이름에 지문', img_name(b'xyz').startswith('shopimg_') and img_name(None) == '')
    vh = view(p, 'KR', 'KO', ['M_A'], hidden=['M_A'])
    t('숨긴 쇼핑몰은 목록에서 빠진다', [m['code'] for m in vh['malls']] == ['M_B'], [m['code'] for m in vh['malls']])
    t('숨긴 쇼핑몰의 상품도 빠진다', vh['count'] == 1, vh['count'])
    t('숨긴 쇼핑몰은 검색창도 없다', all(m['code'] != 'M_A' for m in vh['searches']))
    t('설정 화면은 숨긴 것까지 본다', [(m['code'], m['hidden']) for m in vh['country_malls']] ==
      [('M_A', True), ('M_B', False)])
    c.execute("UPDATE sys_shop_mall SET search_tpl='https://us/s?q={q}' WHERE mall_code='M_US'")
    p3 = export_payload(c)
    vo = view(p3, 'KR', 'KO', [], hidden=['M_B'])
    t('보이는 쇼핑몰이 하나뿐이면 검색창이 저절로', [(m['code'], m['auto']) for m in vo['searches']] == [('M_A', True)],
      vo['searches'])
    t('둘 이상이면 저절로 안 생긴다', view(p3, 'KR', 'KO', [])['searches'] == [])
    t('미국 — 검색 틀 있는 쇼핑몰이 하나뿐이어도 보이는 쇼핑몰이 둘이면 안 생긴다',
      view(p3, 'US', 'EN', [])['searches'] == [])
    c.execute("UPDATE sys_shop_item SET descs=? WHERE mall_code='M_A' AND cat_code='CHURCH_WORSHIP'",
              (J({'KO': '예배 때 쓰는 은빛 성찬기'}),))
    c.execute("UPDATE sys_shop_mall SET text_ok=0 WHERE mall_code='M_B'")
    p4 = export_payload(c)
    v4 = view(p4, 'KR', 'KO')
    t('검색 허용 칸이 꾸러미에 실린다', {m['code']: m['text'] for m in p4['malls']}['M_B'] == 0)
    t('검색에서 빠지는 쇼핑몰 이름', v4['nosearch'] == ['나 쇼핑'], v4['nosearch'])
    t('통합검색 — 설명 글로도 찾는다', [it['name'] for _c, it in find(v4, '은빛')] == ['성찬기'])
    t('통합검색 — 낱말을 모두 담아야', find(v4, '성찬기 생수') == [])
    t('통합검색 — 검색 허용 안 된 쇼핑몰은 빠진다', find(v4, '커피') == [])
    t('통합검색 — 빈 낱말은 없음', find(v4, '  ') == [])
    t('칸 없는 옛 꾸러미는 검색 허용', text_ok({'code': 'X'}) and not text_ok({'text': 0}))
    c.execute("UPDATE sys_shop_item SET deliver='EMAIL' WHERE mall_code='M_B'")
    p5 = export_payload(c)
    t('선물 전달 방식이 꾸러미에 실린다(기본 LINK)',
      {it['mall']: it['deliver'] for it in p5['items']}.get('M_B') == 'EMAIL' and
      {it['mall']: it['deliver'] for it in p5['items']}.get('M_A') == 'LINK')
    vm = view(p5, 'KR', 'KO', mine=['M_US'])
    t('내 모음 — 나라와 상관없이 그 쇼핑몰만(해외 직구)', [m['code'] for m in vm['malls']] == ['M_US'])
    t('설정 목록 「모든 나라」', len(view(p5, 'ALL', 'KO')['country_malls']) == 3)
    vo2 = view(p5, 'KR', 'KO', off=['M_A'])
    t('체크를 끈 쇼핑몰은 상품이 안 보인다(쇼핑몰 칸은 남는다)',
      'M_A' in [m['code'] for m in vo2['malls']] and all(it['mall'] != 'M_A' for c_ in vo2['cats'] for it in c_['items']))
    _food = [c_ for c_ in vo2['cats'] if c_['code'] == 'FOOD']
    t('Off 해도 카테고리 칸은 남는다(every · 폰과 같다)', len(_food) == 1 and not _food[0]['items'] and _food[0]['every'])
    t('통합검색은 Off 쇼핑몰 상품도 찾는다', [it['mall'] for _c, it in find(vo2, '생수')] == ['M_A'])
    _nm = [m['name'] for m in view(p5, 'ALL', 'KO')['malls']]
    t('쇼핑몰 차례 = 이름 순서', _nm == sorted(_nm, key=str.casefold), _nm)
    t('짧은 이름 — 적은 것 먼저 · 없으면 앞 토막 다섯 글자',
      short_of({'KO': '기프트'}, '기프트카드', 'KO') == '기프트' and short_of({}, '교회·예배 용품', 'KO') == '교회' and
      short_of(None, '주방생활용품모음', 'KO') == '주방생활용')
    rid = [it['id'] for it in p5['items'] if it['mall'] == 'M_A' and it.get('url') and not it.get('from')][0]
    vr = view(p5, 'KR', 'KO', off=['M_A'], repeat=[rid])
    t('자주 사는 상품은 체크와 상관없이 보인다', [it['id'] for it in vr['repeat']] == [rid])
    set_mine(c, 'M_US', True)
    set_repeat(c, rid, True)
    t('내 모음·자주 사는 상품 저장', mine(c) == ['M_US'] and repeats(c) == [str(rid)])
    set_mine(c, 'M_US', False)
    set_repeat(c, rid, False)
    rt = recommend_text('비타민 D', '아이허브', 'https://x/1', '자주 삽니다')
    t('추천 글 왕복', parse_recommend(rt) == {'상품': '비타민 D', '쇼핑몰': '아이허브', '주소': 'https://x/1', '메모': '자주 삽니다'})
    set_hide(c, 'M_B', True)
    set_hide(c, 'M_B', True)
    t('숨기기 멱등', hides(c) == ['M_B'])
    set_hide(c, 'M_B', False)
    t('숨기기 끄기', hides(c) == [])
    # ★ 2026-10-29 국내배송 · 해외배송(나라마다)
    pa = {'version': 1, 'cats': [{'code': 'C1', 'kind': 'GENERAL', 'names': {'KO': '생활'}}],
          'malls': [{'code': 'AMZ', 'names': {'KO': '아마존'}, 'countries': ['US'], 'abroad': ['KR']},
                    {'code': 'CPG', 'names': {'KO': '쿠팡'}, 'countries': ['KR']},
                    {'code': 'GB1', 'names': {'KO': '영국몰'}, 'countries': ['GB']}],
          'items': [{'id': 1, 'mall': 'AMZ', 'cat': 'C1', 'names': {'KO': '책'}, 'url': 'https://x/1'},
                    {'id': 2, 'mall': 'CPG', 'cat': 'C1', 'names': {'KO': '컵'}, 'url': 'https://x/2'}]}
    va = view(pa, 'KR', 'KO')
    t('해외배송 — 그 나라에 보낸다고 적힌 쇼핑몰만 보인다', [m['code'] for m in va['malls']] == ['CPG', 'AMZ'],
      [m['code'] for m in va['malls']])
    t('해외배송 — 국내 묶음이 먼저 · ship 칸', [m['ship'] for m in va['malls']] == ['D', 'X'])
    t('해외배송 — 상품에도 ship', {it['id']: it['ship'] for it in va['cats'][0]['items']} == {1: 'X', 2: 'D'})
    t('같은 쇼핑몰이 미국에서는 국내', view(pa, 'US', 'KO')['malls'][0]['ship'] == 'D')
    vo = view(pa, 'KR', 'KO', abroad=False)
    t('해외배송 끄면 쇼핑몰·상품이 빠진다', [m['code'] for m in vo['malls']] == ['CPG'] and vo['count'] == 1)
    t('내 모음의 다른 나라 쇼핑몰도 해외', [m['ship'] for m in view(pa, 'KR', 'KO', mine=['GB1', 'CPG'])['malls']] == ['D', 'X'])
    t('「모든 나라」는 한 묶음', all(m['ship'] == 'D' for m in view(pa, 'ALL', 'KO')['malls']))
    pa['malls'][1]['notice'] = {'KO': '쿠팡 고지', 'EN': 'Coupang notice'}
    nv = {it['id']: it['notice'] for it in view(pa, 'KR', 'EN')['cats'][0]['items']}
    t('쇼핑몰마다 고지 문구(그 언어 · 없으면 빈칸 = 일반 고지)', nv == {1: '', 2: 'Coupang notice'}, nv)
    print('\ndb_shop selftest %d/%d' % (ok[0], ok[0] + bad[0]))
    return 0 if not bad[0] else 1


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(selftest())
    if '--init' in sys.argv:
        import appdb
        with appdb.connect() as _c:
            ensure(_c)
            print('ok — 카테고리', _c.execute('SELECT COUNT(*) FROM sys_shop_category').fetchone()[0])
        sys.exit(0)
    print('db_shop.py — --selftest | --init')
