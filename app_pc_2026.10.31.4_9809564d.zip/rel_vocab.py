# -*- coding: utf-8 -*-
"""연결 어휘 — 「어느 갈래에서 어떤 `rel_code` 를 쓰는가」의 단일 소스.

★ **왜 만드나** (2026-08-25 실측). `sys_rel_catalog` 는 18종을 10개 언어로 갖고
  있는데 **전부 `VERS_VERS` 것**이다. 실제로 쓰이는 `rel_code` 는 **65종**이라
  **47종은 카탈로그 밖**이다. 그래서 ① 오타가 들어와도 아무도 못 잡고
  ② 연결 부품이 「이 갈래에서 고를 수 있는 어휘」를 **물어볼 곳이 없다.**

⚠⚠ **`sys_rel_catalog` 에 `link_type` 칸을 더하지 않았다.** 그 표의 열쇠가
  `UNIQUE(rel_code, lang_code)` 인데, 실측하니 **한 코드가 여러 갈래에 쓰인다**:
      NEXT 9갈래 · MENTIONED 2 · SUBJECT 2
  `NEXT` 는 아홉 갈래에서 뜻이 같으므로 이름을 아홉 벌 두면 고칠 때 아홉 곳을
  고친다. 열쇠를 바꾸려면 표를 재작성해야 하는데 **읽는 코드가 24곳**이다.
  ⇒ **어휘(무엇인가)와 쓰임새(어디서 쓰나)를 가른다.**
     `sys_tag_asset` ↔ `sys_tag_link` 가 이미 쓰는 문법이다.

⚠ **이름은 아직 옮기지 않는다.** 출처가 넷으로 갈라져 있다 —
  `sys_rel_catalog`(VERS_VERS 10언어) · `ui_strings.IDOLREL_*`(우상 6) ·
  `ui_strings.ENTITY_ROLE_*`(단락 역할) · **사람 관계 25종은 아무 데도 없다**
  (`figure_tree` 가 코드를 그대로 쓴다). 지금 옮기면 읽기 코드 24곳을 함께
  고쳐야 하므로, **네 곳을 아는 함수 하나**(`name()`)만 두고 통합은 뒤로 미룬다.

⚠ **`--sync` 는 지금 데이터를 정본으로 삼는다 — 오타도 함께 등록된다.**
  그것이 이 도구의 값이 「지금부터」인 까닭이다. 등록한 뒤로 새로 들어오는
  조합은 `unknown()` 이 잡는다. 그래서 sync 는 **사람이 볼 목록을 함께 낸다.**

쓰는 법
    python rel_vocab.py --selftest
    python rel_vocab.py --check      지금 데이터 ↔ 등록된 어휘 대조
    python rel_vocab.py --apply      멱등 등록
    python rel_vocab.py --list [갈래]
"""
import sys

import appdb

TBL = 'sys_rel_scope'

# 갈래별 「정본 목록」이 이미 있는 곳. 없는 갈래는 데이터가 정본이 된다.
#   VERS_VERS → sys_rel_catalog        (18종 · 10개 언어)
#   ENTI_ENTI → entity_relation 모듈    (PERSON 25 + IDOL 6)
_AUTHORITATIVE = ('VERS_VERS', 'ENTI_ENTI')

DDL = """
CREATE TABLE IF NOT EXISTS %s (
    scope_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    link_type     TEXT NOT NULL,
    rel_code      TEXT NOT NULL,
    sort_order    INTEGER NOT NULL DEFAULT 0,
    record_status TEXT NOT NULL DEFAULT 'LIVE',
    UNIQUE(link_type, rel_code)
)""" % TBL


def ensure_schema(conn):
    conn.execute(DDL)
    conn.execute('CREATE INDEX IF NOT EXISTS idx_rel_scope_lt '
                 'ON %s(link_type)' % TBL)


# ── 지금 쓰이는 조합 ────────────────────────────────────────────────
def used(conn):
    """실제 데이터에 있는 (link_type, rel_code, 행수). rel_code 가 NULL 인 것은 뺀다."""
    out = []
    for tbl in ('sys_link_asset', 'userdb.user_link_asset'):
        try:
            out += list(conn.execute(
                'SELECT link_type, rel_code, COUNT(*) FROM %s '
                'WHERE rel_code IS NOT NULL AND rel_code<>%s '
                'GROUP BY 1,2' % (tbl, "''")))
        except Exception:
            pass
    # 두 표에 같은 조합이 있으면 합친다
    agg = {}
    for lt, rc, n in out:
        agg[(lt, rc)] = agg.get((lt, rc), 0) + n
    return sorted((lt, rc, n) for (lt, rc), n in agg.items())


def authoritative(conn):
    """정본 목록이 **이미 있는** 갈래의 전체 어휘.

    ⚠ 지금 안 쓰이는 어휘도 등록해야 한다 — 콤보가 제안하지 못하면 그 관계를
      **영영 새로 걸 수 없다**(실측: `CHILD`·`OCCULT_DECEPTION`·`ILL`·`PRO`
      넷이 정본에 있는데 데이터가 0행이라 `used()` 로는 안 잡힌다).
    """
    out = set()
    try:
        for r in conn.execute('SELECT DISTINCT rel_code FROM sys_rel_catalog'):
            out.add(('VERS_VERS', r[0]))
    except Exception:
        pass
    try:
        import entity_relation
        # ★ 2026-09-24 — **가까운 낱말 넷**을 함께 등록한다. 콤보가 제안하지
        #   못하면 그 관계를 영영 못 고른다(이 함수 머리글 그대로).
        for rc in (tuple(entity_relation.PERSON) + tuple(entity_relation.IDOL)
                   + tuple(entity_relation.COMPARE)):
            out.add(('ENTI_ENTI', rc))
    except Exception:
        pass
    return out


def registered(conn):
    try:
        return {(r[0], r[1]) for r in conn.execute(
            "SELECT link_type, rel_code FROM %s "
            "WHERE record_status='LIVE'" % TBL)}
    except Exception:
        return set()


def unknown(conn):
    """등록되지 않은 조합 — 연결 점검 A-7 이 읽는다."""
    reg = registered(conn)
    return [(lt, rc, n) for lt, rc, n in used(conn) if (lt, rc) not in reg]


def stale(conn):
    """등록됐는데 쓰이는 행이 없고 **정본에도 없는** 조합 (지우지 않는다 — 알리기만).

    ⚠ 정본에 있는 것은 쓰이지 않아도 정상이다 — 아직 안 건 관계일 뿐이다.
    """
    u = {(lt, rc) for lt, rc, _ in used(conn)} | authoritative(conn)
    return sorted(x for x in registered(conn) if x not in u)


# ── 그 갈래에서 고를 수 있는 어휘 (연결 부품 콤보) ──────────────────
def codes(conn, link_type):
    try:
        return [r[0] for r in conn.execute(
            "SELECT rel_code FROM %s WHERE link_type=? AND record_status='LIVE' "
            "ORDER BY sort_order, rel_code" % TBL, (link_type,))]
    except Exception:
        return []


# ── 이름 — 출처 넷을 한 함수가 안다 ─────────────────────────────────
def name(conn, link_type, rel_code, lang='KO'):
    """이름을 못 찾으면 **코드를 그대로 돌려준다**(조용히 빈칸을 내지 않는다)."""
    if not rel_code:
        return ''
    # ① VERS_VERS 등 — sys_rel_catalog (요청 언어 → EN → KO)
    r = conn.execute(
        "SELECT rel_name FROM sys_rel_catalog WHERE rel_code=? "
        "ORDER BY CASE lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1 "
        "         WHEN 'KO' THEN 2 ELSE 3 END LIMIT 1",
        (rel_code, lang)).fetchone()
    if r and r[0]:
        return r[0]
    # ② ui_strings — 우상 관계 · 단락 역할
    for key in ('IDOLREL_' + rel_code, 'ENTITY_ROLE_' + rel_code,
                'ENTITY_REL_' + rel_code):
        r = conn.execute(
            "SELECT string_value FROM ui_strings WHERE string_id=? "
            "ORDER BY CASE lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1 "
            "         WHEN 'KO' THEN 2 ELSE 3 END LIMIT 1",
            (key, lang)).fetchone()
        if r and r[0]:
            return r[0]
    # ③ 못 찾음 — 코드 그대로
    return rel_code


def unnamed(conn):
    """이름이 없어 코드가 그대로 나오는 조합. **채워야 할 목록이다.**"""
    out = []
    for lt, rc, n in used(conn):
        if name(conn, lt, rc, 'KO') == rc:
            out.append((lt, rc, n))
    return out


# ── 등록 ────────────────────────────────────────────────────────────
def sync(conn, do_apply=False):
    ensure_schema(conn)
    reg = registered(conn)
    seen = {(lt, rc) for lt, rc, _ in used(conn)}
    add = [(lt, rc, n) for lt, rc, n in used(conn) if (lt, rc) not in reg]
    # 정본에 있는데 아직 안 쓰인 어휘도 등록한다 (행수 0 이라 콤보 맨 뒤로)
    add += [(lt, rc, 0) for (lt, rc) in sorted(authoritative(conn))
            if (lt, rc) not in reg and (lt, rc) not in seen]
    if do_apply:
        # 갈래 안에서 많이 쓰이는 것부터 (콤보에서 흔한 것이 위)
        order = {}
        for lt, rc, n in sorted(add, key=lambda x: (x[0], -x[2], x[1])):
            order[lt] = order.get(lt, 0) + 10
            conn.execute(
                'INSERT OR IGNORE INTO %s (link_type, rel_code, sort_order) '
                'VALUES (?,?,?)' % TBL, (lt, rc, order[lt]))
        conn.commit()
    return add


def report(conn):
    u = used(conn)
    reg = registered(conn)
    unk = unknown(conn)
    st = stale(conn)
    un = unnamed(conn)
    print('쓰이는 조합 %d · 등록 %d · **미등록 %d** · 안 쓰이는 등록 %d'
          % (len(u), len(reg), len(unk), len(st)))
    if unk:
        print('\n미등록 조합 — 오타인가 새 어휘인가 (사람이 본다)')
        for lt, rc, n in unk:
            print('   %-12s %-22s %6d행' % (lt, rc, n))
    if st:
        print('\n등록됐는데 안 쓰이는 것 (지우지 않는다)')
        for lt, rc in st:
            print('   %-12s %s' % (lt, rc))
    print('\n갈래별 어휘 수')
    per = {}
    for lt, rc, n in u:
        per.setdefault(lt, []).append(rc)
    for lt in sorted(per, key=lambda k: -len(per[k])):
        mark = ' ★정본있음' if lt in _AUTHORITATIVE else ''
        print('   %-12s %2d종%s' % (lt, len(per[lt]), mark))
    if un:
        print('\n⚠ 이름이 없어 코드가 그대로 나오는 조합 **%d** (채울 목록)' % len(un))
        per2 = {}
        for lt, rc, n in un:
            per2.setdefault(lt, []).append(rc)
        for lt in sorted(per2):
            print('   %-12s %d종  %s' % (lt, len(per2[lt]),
                                         ' '.join(sorted(per2[lt])[:8])))
    return len(unk)


# ── 자가 검증 ───────────────────────────────────────────────────────
def selftest():
    import sqlite3
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        if cond:
            ok[0] += 1
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    c = sqlite3.connect(':memory:')
    c.execute('CREATE TABLE sys_link_asset (link_type TEXT, rel_code TEXT)')
    c.execute("CREATE TABLE sys_rel_catalog (rel_code TEXT, rel_name TEXT, "
              'lang_code TEXT)')
    c.execute('CREATE TABLE ui_strings (string_id TEXT, lang_code TEXT, '
              'string_value TEXT)')
    for lt, rc in (('VERS_VERS', 'PRG'), ('VERS_VERS', 'PRG'),
                   ('VERS_VERS', 'TYP'), ('ENTI_ENTI', 'FATHER'),
                   ('ENTI_ENTI', 'WORSHIPPER'), ('PLAN_CONT', 'NEXT'),
                   ('CONT_CONT', 'NEXT'), ('ENTI_PERI', 'PROTAGONIST'),
                   ('MEDI_ENTI', None)):
        c.execute('INSERT INTO sys_link_asset VALUES (?,?)', (lt, rc))
    c.execute("INSERT INTO sys_rel_catalog VALUES ('PRG','점진','KO')")
    c.execute("INSERT INTO sys_rel_catalog VALUES ('PRG','Progressive','EN')")
    c.execute("INSERT INTO ui_strings VALUES ('IDOLREL_WORSHIPPER','KO','숭배자')")
    c.execute("INSERT INTO ui_strings VALUES "
              "('ENTITY_ROLE_PROTAGONIST','KO','주인공')")
    ensure_schema(c)

    u = used(c)
    t('rel_code NULL 은 안 센다', all(rc for _, rc, _ in u), len(u))
    t('같은 조합을 접어 센다', ('VERS_VERS', 'PRG', 2) in u)
    t('한 코드가 여러 갈래 (NEXT)',
      sum(1 for lt, rc, _ in u if rc == 'NEXT') == 2)

    t('등록 전에는 전부 미등록', len(unknown(c)) == len(u), len(unknown(c)))
    sync(c, do_apply=True)
    t('등록 뒤 미등록 0', len(unknown(c)) == 0, unknown(c))
    n1 = len(sync(c, do_apply=True))
    t('멱등 (두 번째는 0)', n1 == 0, n1)
    # ★ 정본에 있는데 데이터에 없는 어휘도 등록되는가
    # ⚠ 코드를 글자로 박지 않는다 — entity_relation 목록이 바뀌면 검사가 깨진다(§0-5).
    try:
        import entity_relation as _er
        spare = [x for x in tuple(_er.PERSON) + tuple(_er.IDOL)
                 if x not in ('FATHER', 'WORSHIPPER')]
        t('★ 안 쓰인 정본 어휘도 콤보에 오른다',
          bool(spare) and spare[0] in codes(c, 'ENTI_ENTI'), spare[:1])
        t('★ 그것을 「안 쓰이는 등록」으로 잘못 잡지 않는다',
          ('ENTI_ENTI', spare[0]) not in stale(c))
    except ImportError:
        t('★ 정본 어휘 (entity_relation 없음 — 건너뜀)', True)

    t('갈래 콤보 — VERS_VERS', sorted(codes(c, 'VERS_VERS')) == ['PRG', 'TYP'],
      codes(c, 'VERS_VERS'))
    t('갈래 콤보 — 남의 갈래가 안 섞인다',
      codes(c, 'PLAN_CONT') == ['NEXT'], codes(c, 'PLAN_CONT'))
    t('없는 갈래는 빈 목록', codes(c, 'NO_SUCH') == [])

    t('이름 ① 카탈로그', name(c, 'VERS_VERS', 'PRG', 'KO') == '점진')
    t('이름 ① 언어 폴백', name(c, 'VERS_VERS', 'PRG', 'JA') == 'Progressive',
      name(c, 'VERS_VERS', 'PRG', 'JA'))
    t('이름 ② 우상', name(c, 'ENTI_ENTI', 'WORSHIPPER') == '숭배자')
    t('이름 ② 단락 역할', name(c, 'ENTI_PERI', 'PROTAGONIST') == '주인공')
    t('이름 ③ 없으면 코드 그대로 (빈칸 아님)',
      name(c, 'ENTI_ENTI', 'FATHER') == 'FATHER')
    # ⚠ `used()` 가 (갈래, 코드) 순이라 코드만 뽑으면 순서가 갈래를 따른다.
    #    글자 목록을 그대로 맞추면 갈래를 하나 더할 때 깨진다 — 정렬해서 잰다.
    t('이름 없는 것을 셀 수 있다',
      sorted(x[1] for x in unnamed(c)) == ['FATHER', 'NEXT', 'NEXT', 'TYP'],
      sorted(x[1] for x in unnamed(c)))

    # 탐지력 — 새 오타가 들어오면 잡는가
    c.execute("INSERT INTO sys_link_asset VALUES ('VERS_VERS','PRGG')")
    unk = unknown(c)
    t('★ 오타를 잡는다', [x[:2] for x in unk] == [('VERS_VERS', 'PRGG')], unk)
    # 안 쓰이는 등록도 잡는가
    c.execute("INSERT INTO %s (link_type,rel_code) VALUES ('VERS_VERS','GONE')"
              % TBL)
    t('★ 안 쓰이는 등록을 잡는다', ('VERS_VERS', 'GONE') in stale(c), stale(c))
    c.close()
    print('rel_vocab selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv[1] if len(sys.argv) > 1 else '--check'
    if a == '--selftest':
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect()
    try:
        if a == '--check':
            ensure_schema(conn)
            report(conn)
        elif a == '--apply':
            n = len(sync(conn, do_apply=True))
            print('등록 %d건' % n)
            report(conn)
        elif a == '--list':
            lt = sys.argv[2] if len(sys.argv) > 2 else None
            if lt:
                for rc in codes(conn, lt):
                    print('  %-22s %s' % (rc, name(conn, lt, rc)))
            else:
                for r in conn.execute(
                        'SELECT link_type, COUNT(*) FROM %s '
                        'GROUP BY 1 ORDER BY 1' % TBL):
                    print('  %-12s %d종' % r)
        else:
            print(__doc__)
    finally:
        conn.close()
