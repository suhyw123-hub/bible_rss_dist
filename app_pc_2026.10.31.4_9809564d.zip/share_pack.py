# -*- coding: utf-8 -*-
"""share_pack.py — 내 자료 내보내기/가져오기 (영구, 2026-09-08 신설).

★★★ **교회·공동체 묵상 나눔의 1단계**(설계 = `정책자료/0.교회묵상.txt` §8).
  사용자 지시(0.txt 9번): 「**묵상노트를 서로 공유하지 못한다. 렌즈묵상 이외에는
  이용 불가능하다**」 · 「묵상플랜 자체를 교회 목적에 맞게 수정하기, 구절연결,
  말씀흐름, 연구자료 등을 체계적으로 작성하기, **공유하기**」.

★★ **왜 이것이 첫걸음인가** — 방·기수·작성자 칸을 다 만들어도 **나눌 파일
  자체가 없으면** 아무것도 못 한다. 반대로 이것만 있으면 그날부터 전도사가
  카톡으로 교재를 보낼 수 있다. **2~5단계가 전부 이 위에 선다.**

★ **`lens_share` 와 같은 문법이다 — 두 벌을 만들지 않는다.**
  · 파일은 JSON 하나 · 머리에 `app`·`fmt`·`made_by`
  · **구절은 KO 약명 참조**(`창 1:1` · `요 1:1-5`) — `scripture_ref_kr` 이 푼다
  · 렌즈는 **`lens_share` 에 그대로 위임**한다(거기 있는 것을 베끼지 않는다)

⚠⚠ **번호를 싣지 않는다 — 자연 열쇠만.**
  `verse_id`·`entity_id`·`user_text_id` 는 그 PC 안에서만 뜻이 있다. 받는 쪽
  DB 가 다르면 엉뚱한 자리에 붙는다(§149차·§97차 그 자리).
  ⇒ 구절 = 약명 · 용어 = `entity_code` · 도서 편 = (책코드, 차례).
  ⚠ **못 푸는 참조는 건너뛴다** — 지어내지 않는다. 몇 건을 왜 건너뛰었는지
    돌려준다(§0-1 조용한 실패 금지).

⚠ **내 것만 내보낸다** — sys 자산(성경 본문·주석·배포 렌즈)은 안 담는다.
  ⓐ 남의 저작물이고 ⓑ 받는 쪽도 이미 갖고 있다.

⚠ **가져오기는 언제나 user 영역** — sys 는 불가침(`lens_share` 규칙 그대로).

⚠ **멱등** — 같은 파일을 두 번 넣어도 하나다. 열쇠 = **자연 열쇠 + 내용 해시**
  (`origin_key`). 그 칸이 `user_text_asset` 에 이미 있다.

    python share_pack.py --selftest        (의무)
    python share_pack.py --list
    python share_pack.py --export out.json --note 1,2 --ref 3
"""
import hashlib
import json
import sys

import appdb
import scripture_ref_kr

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

APP_MARK = 'hagah-share'
FMT = 1

#: 담을 수 있는 갈래 — **늘리려면 여기 한 줄 + `_EXPORT`/`_IMPORT` 한 짝.**
#: ⚠ 문서에만 적으면 다음에 빠진다(§0-4).
KINDS = ('note', 'ref', 'vlink', 'lens', 'plan')

KIND_NAME = {
    'note':  '묵상노트',
    'ref':   '연구자료',
    'vlink': '구절연결',
    'lens':  '렌즈',
    'plan':  '플랜',     # ★ 2026-10-14 87 — 꼴·받기는 `plan_share` 가 맡는다(여기서 다시 짜지 않는다)
}


# ── 자연 열쇠 ──────────────────────────────────────────────────────────────

def _ref_of(conn, a, b=None):
    """verse_id (구간) → KO 약명 참조 `창 1:1` · `요 1:1-5`.

    ⚠ **`lens_share._ref_of` 와 같은 규칙이다** — 두 곳에서 다르게 지으면
      한쪽 파일을 다른 쪽이 못 읽는다. 그쪽을 그대로 부른다.
    """
    import lens_share
    return lens_share._ref_of(conn, a, b)


def _entity_code(conn, eid):
    """entity_id → `P_DAVID` 꼴 코드. 없으면 None."""
    r = conn.execute("SELECT entity_code FROM sys_entity_master WHERE entity_id=?",
                     (eid,)).fetchone()
    return r[0] if r else None


def _entity_id(conn, code):
    r = conn.execute("SELECT entity_id FROM sys_entity_master WHERE entity_code=? "
                     "AND COALESCE(record_status,'LIVE')='LIVE'", (code,)).fetchone()
    return r[0] if r else None


def _unit_key(conn, unit_id):
    """도서 편 → (책 코드, 차례). ⚠ `unit_id` 는 재적재로 바뀐다."""
    r = conn.execute(
        "SELECT ba.book_code, bu.sequence FROM sys_book_unit bu "
        "JOIN sys_book_asset ba ON ba.book_id=bu.book_id WHERE bu.unit_id=?",
        (unit_id,)).fetchone()
    return {'book': r[0], 'seq': r[1]} if r else None


def _unit_id(conn, d):
    if not d:
        return None
    r = conn.execute(
        "SELECT bu.unit_id FROM sys_book_unit bu JOIN sys_book_asset ba "
        "ON ba.book_id=bu.book_id WHERE ba.book_code=? AND bu.sequence=? "
        "AND COALESCE(bu.record_status,'LIVE')='LIVE'",
        (d.get('book'), d.get('seq'))).fetchone()
    return r[0] if r else None


def origin_key(kind, payload):
    """멱등 열쇠 — **자연 열쇠 + 내용 해시**.

    ★ 왜 내용까지 넣나 — 같은 구절에 두 편을 썼을 수 있다. 자연 열쇠만으로는
      둘이 하나로 합쳐진다.
    ⚠ 짧게 자른다(16자) — 표 칸이 넉넉해도 사람이 눈으로 볼 값이다.
    """
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    h = hashlib.sha1(raw.encode('utf-8')).hexdigest()[:16]
    return 'SHARE:%s:%s' % (kind, h)


# ── 내보내기 ──────────────────────────────────────────────────────────────

def _export_note(conn, ids=None):
    """구절 묵상노트 → [{ref, title, body, lang, written}]."""
    q = ("SELECT user_text_id, clicked_id, title, contents, lang_code, "
         "COALESCE(updated_at, created_at) FROM user_text_asset "
         "WHERE text_type='VERS_NOTE' AND COALESCE(record_status,'HIDE')<>'HIDE'")
    args = []
    if ids:
        q += " AND user_text_id IN (%s)" % ','.join('?' * len(ids))
        args = list(ids)
    out, skip = [], 0
    for _tid, vid, title, body, lang, ts in conn.execute(q, args):
        ref = _ref_of(conn, vid)
        if not ref or not (body or '').strip():
            skip += 1
            continue
        out.append({'ref': ref, 'title': title or '',
                    'body': body.strip(), 'lang': (lang or 'KO').upper(),
                    'written': ts or ''})
    return out, skip


def _export_ref(conn, ids=None):
    """내 연구자료 → [{title, body, lang, ref, entity, unit}]."""
    q = ("SELECT ref_id, verse_id, entity_id, body_unit_id, title, summary, "
         "lang_code FROM user_ref_asset "
         "WHERE COALESCE(record_status,'HIDE')<>'HIDE'")
    args = []
    if ids:
        q += " AND ref_id IN (%s)" % ','.join('?' * len(ids))
        args = list(ids)
    out, skip = [], 0
    for rid, vid, eid, uid, title, summary, lang in conn.execute(q, args):
        body = _ref_body(conn, rid) or (summary or '')
        if not (title or '').strip() and not (body or '').strip():
            skip += 1
            continue
        d = {'title': (title or '').strip(), 'body': (body or '').strip(),
             'lang': (lang or 'KO').upper()}
        if vid:
            d['ref'] = _ref_of(conn, vid)
        if eid:
            d['entity'] = _entity_code(conn, eid)
        if uid:
            d['unit'] = _unit_key(conn, uid)
        out.append(d)
    return out, skip


def _ref_body(conn, ref_id):
    """연구자료 본문 — 표가 없는 옛 DB 도 견딘다."""
    try:
        r = conn.execute("SELECT body_text FROM user_ref_text WHERE ref_id=? "
                         "LIMIT 1", (ref_id,)).fetchone()
        return r[0] if r else ''
    except Exception:
        return ''


def _export_vlink(conn, ids=None):
    """내 구절연결 → [{a, b, rel, desc}]. a·b 는 약명 참조."""
    q = ("SELECT user_link_id, clicked_id, target_id, rel_code, end_id "
         "FROM user_link_asset WHERE link_type='VERS_VERS' "
         "AND COALESCE(record_status,'HIDE')<>'HIDE'")
    args = []
    if ids:
        q += " AND user_link_id IN (%s)" % ','.join('?' * len(ids))
        args = list(ids)
    out, skip = [], 0
    for lid, a, b, rel, end in conn.execute(q, args):
        ra, rb = _ref_of(conn, a, end), _ref_of(conn, b)
        if not ra or not rb:
            skip += 1
            continue
        d = {'a': ra, 'b': rb, 'rel': rel or ''}
        desc = {}
        for lang, body in conn.execute(
                "SELECT lang_code, contents FROM user_text_asset WHERE "
                "text_type='VERS_VERS_DESC' AND clicked_id=? "
                "AND COALESCE(record_status,'HIDE')<>'HIDE'", (lid,)):
            if (body or '').strip():
                desc[(lang or 'KO').upper()] = body.strip()
        if desc:
            d['desc'] = desc
        out.append(d)
    return out, skip


def export_pack(conn, pick=None, made_by='', title=''):
    """내 자료 → 초안 dict.

    `pick` = {'note': [id…], 'ref': [...], 'vlink': [...], 'lens': [...]}
             None 이면 **전부**. 빈 리스트면 그 갈래를 안 담는다.
    ⇒ (draft, {갈래: 건너뛴 수})
    """
    pick = pick if pick is not None else {k: None for k in KINDS}
    d = {'app': APP_MARK, 'fmt': FMT}
    if made_by:
        d['made_by'] = made_by
    if title:
        d['title'] = title
    skipped = {}
    for kind, fn in (('note', _export_note), ('ref', _export_ref),
                     ('vlink', _export_vlink)):
        if kind not in pick:
            continue
        rows, sk = fn(conn, pick.get(kind))
        if rows:
            d[kind] = rows
        if sk:
            skipped[kind] = sk
    # ★ 렌즈는 `lens_share` 에 위임한다 — 여기서 다시 짜지 않는다.
    if 'lens' in pick:
        import lens_share
        ids = pick.get('lens')
        if ids is None:
            ids = [r[0] for r in conn.execute(
                "SELECT user_unit_id FROM user_unit_asset WHERE "
                "unit_type='CONTAINER' AND COALESCE(record_status,'LIVE')='LIVE'")]
        lens = []
        for uid in ids:
            one = lens_share.export_lens(conn, uid, made_by=made_by)
            if one:
                lens.append(one)
            else:
                skipped['lens'] = skipped.get('lens', 0) + 1
        if lens:
            d['lens'] = lens
    return d, skipped


# ── 미리보기 ──────────────────────────────────────────────────────────────

def preview(draft):
    """받기 전에 무엇이 들었는지 — **읽고 나서 누른다**(§0-1)."""
    if not isinstance(draft, dict) or draft.get('app') != APP_MARK:
        return '이 앱의 공유 파일이 아닙니다.'
    lines = []
    if draft.get('title'):
        lines.append(draft['title'])
    if draft.get('made_by'):
        lines.append('만든이: %s' % draft['made_by'])
    for k in KINDS:
        n = len(draft.get(k) or [])
        if n:
            lines.append('%s %d개' % (KIND_NAME[k], n))
    if not lines:
        lines.append('담긴 자료가 없습니다.')
    return '\n'.join(lines)


# ── 가져오기 ──────────────────────────────────────────────────────────────

def _has_key(conn, key):
    r = conn.execute("SELECT 1 FROM user_text_asset WHERE origin_key=? LIMIT 1",
                     (key,)).fetchone()
    if r:
        return True
    try:
        r = conn.execute("SELECT 1 FROM user_link_asset WHERE note=? LIMIT 1",
                         (key,)).fetchone()
        return bool(r)
    except Exception:
        return False


def _put_note(conn, d):
    a, _b = scripture_ref_kr.resolve(conn, (d.get('ref') or '').strip())
    if a is None:                       # ⚠ 실패는 (None, None) — §21-4
        return 'REF'
    key = origin_key('note', {'ref': d.get('ref'), 'body': d.get('body')})
    if _has_key(conn, key):
        return 'DUP'
    conn.execute(
        "INSERT INTO user_text_asset (text_type, clicked_id, title, contents, "
        "lang_code, record_status, origin_key, created_at, updated_at) "
        "VALUES ('VERS_NOTE',?,?,?,?,'NEW',?,DATETIME('now','localtime'),"
        "DATETIME('now','localtime'))",
        (a, d.get('title') or '', d.get('body') or '',
         (d.get('lang') or 'KO').upper(), key))
    return 'OK'


def _put_ref(conn, d):
    key = origin_key('ref', {'t': d.get('title'), 'b': d.get('body')})
    r = conn.execute("SELECT 1 FROM user_ref_asset WHERE file_path=? LIMIT 1",
                     (key,)).fetchone()
    if r:
        return 'DUP'
    vid = None
    if d.get('ref'):
        vid, _ = scripture_ref_kr.resolve(conn, d['ref'].strip())
    eid = _entity_id(conn, d['entity']) if d.get('entity') else None
    uid = _unit_id(conn, d.get('unit'))
    # ⚠ `file_path` 를 멱등 열쇠로 빌려 쓴다 — 그 표에 origin_key 칸이 없다.
    #   ★ 파일 경로가 아닌 값을 넣으므로 **읽는 쪽이 그것을 파일로 열면 안 된다.**
    #     실측 — 지금 `file_path` 를 파일로 여는 코드는 없다(첨부는 별도 표).
    conn.execute(
        "INSERT INTO user_ref_asset (verse_id, entity_id, body_unit_id, title, "
        "summary, lang_code, record_status, file_path) "
        "VALUES (?,?,?,?,?,?,'LIVE',?)",
        (vid, eid, uid, d.get('title') or '', d.get('body') or '',
         (d.get('lang') or 'KO').upper(), key))
    return 'OK'


def _put_vlink(conn, d):
    a, ae = scripture_ref_kr.resolve(conn, (d.get('a') or '').strip())
    b, _ = scripture_ref_kr.resolve(conn, (d.get('b') or '').strip())
    if a is None or b is None:
        return 'REF'
    key = origin_key('vlink', {'a': d.get('a'), 'b': d.get('b'),
                               'rel': d.get('rel')})
    if _has_key(conn, key):
        return 'DUP'
    # ⚠ **VERS_VERS 는 clicked_id < target_id 를 트리거가 강제한다**(§28-7).
    lo, hi = sorted((a, b))
    cur = conn.execute(
        "INSERT INTO user_link_asset (clicked_id, target_id, link_type, "
        "rel_code, end_id, record_status, note) "
        "VALUES (?,?,'VERS_VERS',?,?,'LIVE',?)",
        (lo, hi, d.get('rel') or None, (ae if ae and ae != a else None), key))
    lid = cur.lastrowid
    for lang, body in (d.get('desc') or {}).items():
        body = ' '.join((body or '').split())      # 엔터 금지 정책(§28-6)
        if body:
            conn.execute(
                "INSERT INTO user_text_asset (text_type, clicked_id, lang_code, "
                "contents, record_status, created_at, updated_at) "
                "VALUES ('VERS_VERS_DESC',?,?,?,'NEW',"
                "DATETIME('now','localtime'),DATETIME('now','localtime'))",
                (lid, (lang or 'KO').upper(), body))
    return 'OK'


def import_pack(conn, draft, cat_id=None):
    """가져오기 → (넣은 것 {갈래:수}, 건너뛴 것 {까닭:수}, 문제 목록).

    ⚠ **원자성** — 중간에 터지면 통째로 롤백(`db_pack_apply` 규약).
    ⚠ **멱등** — 같은 파일을 두 번 넣어도 하나.
    ⚠ **user 영역만** — sys 는 불가침.
    """
    if not isinstance(draft, dict) or draft.get('app') != APP_MARK:
        return {}, {}, ['이 앱의 공유 파일이 아닙니다.']
    if int(draft.get('fmt') or 0) > FMT:
        return {}, {}, ['더 새로운 판의 파일입니다 — 앱을 갱신하세요.']
    put, skip, bad = {}, {}, []
    conn.execute('BEGIN')
    try:
        for kind, fn in (('note', _put_note), ('ref', _put_ref),
                         ('vlink', _put_vlink)):
            for d in (draft.get(kind) or []):
                try:
                    r = fn(conn, d)
                except Exception as e:
                    r = 'ERR'
                    bad.append('%s: %s' % (KIND_NAME[kind], e))
                if r == 'OK':
                    put[kind] = put.get(kind, 0) + 1
                else:
                    skip[r] = skip.get(r, 0) + 1
        # 플랜은 plan_share 위임
        for one in (draft.get('plan') or []):
            try:
                import plan_share
                st, _pid, msg = plan_share.put_plan(conn, one)
                if st in ('NEW', 'SYS'):
                    put['plan'] = put.get('plan', 0) + 1
                else:
                    skip['DUP' if st == 'SAME' else 'ERR'] = skip.get('DUP' if st == 'SAME' else 'ERR', 0) + 1
                    if st == 'BAD':
                        bad.append('플랜: %s' % msg)
            except Exception as e:
                bad.append('플랜: %s' % e)
                skip['ERR'] = skip.get('ERR', 0) + 1
        # 렌즈는 lens_share 위임
        for one in (draft.get('lens') or []):
            try:
                import lens_share
                lens_share.import_lens(conn, one, cat_id=cat_id)
                put['lens'] = put.get('lens', 0) + 1
            except Exception as e:
                bad.append('렌즈: %s' % e)
                skip['ERR'] = skip.get('ERR', 0) + 1
        conn.commit()
    except Exception as e:
        conn.rollback()
        return {}, {}, ['가져오기 실패 — 아무것도 넣지 않았습니다: %s' % e]
    return put, skip, bad


# ── 자가 검증 ─────────────────────────────────────────────────────────────

def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    conn = appdb.connect()
    # ⚠ **실데이터를 안 건드린다** — 시험 뒤에 생긴 번호만 지운다(§0-5).
    base = {}
    for tb, pk in (('user_text_asset', 'user_text_id'),
                   ('user_link_asset', 'user_link_id'),
                   ('user_ref_asset', 'ref_id'),
                   ('user_unit_asset', 'user_unit_id')):
        base[tb] = conn.execute('SELECT COALESCE(MAX(%s),0) FROM %s'
                                % (pk, tb)).fetchone()[0]
    try:
        # ── 포맷 ──
        t('★ 갈래 표가 단일 소스', set(KIND_NAME) == set(KINDS), KINDS)
        draft = {
            'app': APP_MARK, 'fmt': FMT, 'made_by': '검사자',
            'title': '검사 묶음',
            'note': [{'ref': '창 1:1', 'title': '검사 노트',
                      'body': '태초에 라는 말이 첫 자리에 섭니다.', 'lang': 'KO'}],
            'ref': [{'title': '검사 연구', 'body': '연구 본문', 'lang': 'KO',
                     'ref': '요 1:1', 'entity': 'P_DAVID'}],
            'vlink': [{'a': '창 1:3', 'b': '요 1:5', 'rel': 'PRG',
                       'desc': {'KO': '빛이 이어집니다.'}}],
        }
        p = preview(draft)
        t('★ 미리보기가 무엇이 들었는지 말한다',
          '묵상노트 1개' in p and '연구자료 1개' in p and '구절연결 1개' in p, p.replace('\n', ' | '))
        t('  남의 파일은 거부한다',
          '이 앱의 공유 파일이 아닙니다.' in preview({'app': 'X'}))

        # ── 가져오기 ──
        put, skip, bad = import_pack(conn, draft)
        t('★★ 세 갈래가 다 들어간다',
          put.get('note') == 1 and put.get('ref') == 1 and put.get('vlink') == 1,
          '%s %s %s' % (put, skip, bad))
        # 구절이 제대로 풀렸나
        r = conn.execute(
            "SELECT clicked_id FROM user_text_asset WHERE text_type='VERS_NOTE' "
            "AND user_text_id>?", (base['user_text_asset'],)).fetchone()
        gen11 = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=1 "
                             "AND chapter=1 AND verse=1").fetchone()[0]
        t('★★★ 약명이 번호로 풀린다(창 1:1)', r and r[0] == gen11,
          '%s vs %s' % (r[0] if r else None, gen11))
        # 용어 코드
        rr = conn.execute("SELECT entity_id FROM user_ref_asset WHERE ref_id>?",
                          (base['user_ref_asset'],)).fetchone()
        eid = _entity_id(conn, 'P_DAVID')
        t('★★ 용어는 코드로 풀린다(P_DAVID)', rr and rr[0] == eid,
          '%s vs %s' % (rr[0] if rr else None, eid))
        # VERS_VERS 트리거 — 작은 번호가 앞
        vl = conn.execute(
            "SELECT clicked_id, target_id FROM user_link_asset WHERE "
            "link_type='VERS_VERS' AND user_link_id>?",
            (base['user_link_asset'],)).fetchone()
        t('★★ 구절연결이 오름차순으로 들어간다(§28-7 트리거)',
          vl and vl[0] < vl[1], vl)
        # 연결설명문이 그 링크에 붙었나
        nd = conn.execute(
            "SELECT contents FROM user_text_asset WHERE text_type='VERS_VERS_DESC' "
            "AND user_text_id>?", (base['user_text_asset'],)).fetchone()
        t('  연결설명문이 함께 온다', nd and '빛이 이어집니다' in nd[0], nd)
        t('  개행이 없다(§28-6)', nd and '\n' not in nd[0])

        # ── 멱등 ──
        put2, skip2, _ = import_pack(conn, draft)
        t('★★★ 두 번 넣어도 안 는다(멱등)',
          not put2 and skip2.get('DUP') == 3, '%s %s' % (put2, skip2))

        # ── 못 푸는 참조 ──
        bad_draft = {'app': APP_MARK, 'fmt': FMT,
                     'note': [{'ref': '없는책 9:9', 'body': 'x', 'lang': 'KO'}]}
        p3, s3, _ = import_pack(conn, bad_draft)
        t('★★ 못 푸는 참조는 건너뛰고 말한다',
          not p3 and s3.get('REF') == 1, '%s %s' % (p3, s3))

        # ── 내보내기 왕복 ──
        nid = conn.execute("SELECT user_text_id FROM user_text_asset WHERE "
                           "text_type='VERS_NOTE' AND user_text_id>? LIMIT 1",
                           (base['user_text_asset'],)).fetchone()[0]
        out, sk = export_pack(conn, {'note': [nid]}, made_by='검사자')
        t('★★★ 내보낸 것이 다시 읽힌다(왕복)',
          out.get('note') and out['note'][0]['ref'] == '창 1:1'
          and out['note'][0]['body'].startswith('태초에'),
          out.get('note'))
        t('  번호가 안 실린다(자연 열쇠만)',
          'clicked_id' not in json.dumps(out, ensure_ascii=False)
          and 'verse_id' not in json.dumps(out, ensure_ascii=False))
        t('  갈래를 안 선택하면 그 갈래가 안 담긴다', 'ref' not in out and 'vlink' not in out)

        # ── 미래 판 거부 ──
        p4, _s4, b4 = import_pack(conn, {'app': APP_MARK, 'fmt': FMT + 1})
        t('★ 더 새로운 판은 거부하고 까닭을 말한다',
          not p4 and b4 and '갱신' in b4[0], b4)

        # ── 원자성 ──
        n0 = conn.execute('SELECT COUNT(*) FROM user_text_asset').fetchone()[0]
        broke = {'app': APP_MARK, 'fmt': FMT,
                 'note': [{'ref': '창 1:2', 'body': 'y', 'lang': 'KO'}],
                 'lens': [{'bad': 1}]}
        import lens_share as _ls
        _real = _ls.import_lens
        _ls.import_lens = lambda *a, **k: (_ for _ in ()).throw(RuntimeError('시험'))
        try:
            import_pack(conn, broke)
        finally:
            _ls.import_lens = _real
        n1 = conn.execute('SELECT COUNT(*) FROM user_text_asset').fetchone()[0]
        # ⚠ 렌즈 실패는 `bad` 에 담고 넘어가므로 노트는 들어간다 — **그것이 설계다**
        #   (한 갈래가 막혀도 나머지는 들어간다). 통째 롤백은 예외가 밖으로
        #   나갈 때만.
        t('★ 한 갈래가 막혀도 나머지는 들어간다', n1 == n0 + 1, '%d → %d' % (n0, n1))

        # ── sys 를 안 건드렸는가 ──
        sysn = conn.execute("SELECT COUNT(*) FROM sys_text_asset").fetchone()[0]
        t('★★★ sys 를 한 줄도 안 건드린다', sysn == _SYS0[0] if _SYS0 else True,
          '%s vs %s' % (sysn, _SYS0[0] if _SYS0 else '-'))
    finally:
        # ⚠ **시험 뒤에 생긴 번호만 지운다** — 값으로 지우지 않는다(§97차 사고).
        for tb, pk in (('user_text_asset', 'user_text_id'),
                       ('user_link_asset', 'user_link_id'),
                       ('user_ref_asset', 'ref_id'),
                       ('user_unit_asset', 'user_unit_id')):
            conn.execute('DELETE FROM %s WHERE %s>?' % (tb, pk), (base[tb],))
        conn.commit()
        left = sum(conn.execute('SELECT COUNT(*) FROM %s WHERE %s>?' % (tb, pk),
                                (base[tb],)).fetchone()[0]
                   for tb, pk in (('user_text_asset', 'user_text_id'),
                                  ('user_link_asset', 'user_link_id'),
                                  ('user_ref_asset', 'ref_id'),
                                  ('user_unit_asset', 'user_unit_id')))
        t('★ 시험 잔재 0', left == 0, left)
        conn.close()
    print('share_pack selftest: %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


_SYS0 = []


def _list(conn):
    out = []
    for kind, fn in (('note', _export_note), ('ref', _export_ref),
                     ('vlink', _export_vlink)):
        rows, sk = fn(conn)
        out.append('%-8s %4d개%s' % (KIND_NAME[kind], len(rows),
                                     ('  (못 담는 것 %d)' % sk) if sk else ''))
    n = conn.execute("SELECT COUNT(*) FROM user_unit_asset WHERE "
                     "unit_type='CONTAINER' AND COALESCE(record_status,'LIVE')"
                     "='LIVE'").fetchone()[0]
    out.append('%-8s %4d개' % ('렌즈', n))
    return '\n'.join('  ' + x for x in out)


if __name__ == '__main__':
    a = sys.argv
    if '--selftest' in a:
        _c = appdb.connect()
        _SYS0.append(_c.execute("SELECT COUNT(*) FROM sys_text_asset").fetchone()[0])
        _c.close()
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect()
    if '--export' in a:
        path = a[a.index('--export') + 1]
        pick = {}
        for opt, kind in (('--note', 'note'), ('--ref', 'ref'),
                          ('--vlink', 'vlink'), ('--lens', 'lens')):
            if opt in a:
                v = a[a.index(opt) + 1]
                pick[kind] = None if v == 'all' else [int(x) for x in v.split(',')]
        if not pick:
            pick = None
        d, sk = export_pack(conn, pick, made_by='')
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
        print('■ %s 로 내보냈다' % path)
        print(preview(d))
        if sk:
            print('  못 담은 것: %s' % sk)
    elif '--import' in a:
        path = a[a.index('--import') + 1]
        with open(path, encoding='utf-8') as f:
            d = json.load(f)
        print(preview(d))
        put, skip, bad = import_pack(conn, d)
        print('  넣은 것 %s · 건너뛴 것 %s' % (put or '없음', skip or '없음'))
        for b in bad:
            print('  ✕ %s' % b)
    else:
        print('■ 지금 내보낼 수 있는 것')
        print(_list(conn))
    conn.close()
