"""highlight_notes.py — 본문에 밑줄을 긋고 그 자리에 메모를 단다 (영구 모듈).

2026-08-15 사용자 지시 — 「책을 읽다가 밑줄 긋고 간단히 메모하는 것처럼」.

    … 본문 … 고른 문장은 파란 글자다 (메모) 여기서 멈췄다 … 본문 이어짐 …
              ^^^^^^^^^^^^^^^^^^^^^^  ^^^^^^^^^^^^^^^^^^^^
              글자색만 바꾼다          작은 글씨로 문장 끝에

★ **본문의 행·열 구조를 왜곡하지 않는다** (2026-08-15 사용자 재설계 지시).
  첫 판은 메모를 **상자 위젯**으로 본문에 끼워 넣었다. 그러자
  「메모를 입력하면 본문의 구조가 망가져서 가시성이 완전히 엉망」이 됐다.
  ⇒ 지금은 **글자만 넣는다.** 상자도, 끼워 넣는 위젯도 없다.
  ⇒ 메모 안의 줄바꿈은 **한 칸으로 눌러서** 넣는다. 안 그러면 한 메모가
    본문을 여러 줄로 밀어낸다 — 그것이 구조 왜곡의 정체였다.

★ **밑줄은 형광이 아니라 글자색이다** (같은 지시).
  「형광색도 너무 진하다. 본문이 안 보이고 형광색만 바라보게 된다.」
  바탕을 칠하면 그 줄이 화면을 지배한다. 글자색만 바꾸면 눈에는 띄되 읽기를 막지 않는다.

★ **닻은 고른 글 자체다.** 문단 번호를 세지 않는다.
  실측(2026-08-15) — 앞 문단이 통째로 사라져도 저장한 글로 다시 찾아냈다.
  ⚠ 이것이 중요한 이유: 머레이 31편 중 **24편을 OCR 손상 때문에 다시 받았고**
    그때 문단이 나뉘고 합쳐졌다. 문단 번호였다면 메모가 전부 밀렸을 것이고,
    **오류도 안 났을 것이다.**

⚠ **메모 글자를 끼우면 그 뒤 자리표가 밀린다.** 그래서 **뒤에서부터** 끼운다.
  앞에서부터 넣으면 두 번째 메모부터 엉뚱한 자리에 붙고 **오류는 안 난다.**

⚠ **갈래를 `text_type` 으로 가른다.** `sys_book_unit.unit_id` 와
  `sys_ref_unit.ref_unit_id` 는 **549개가 겹친다**(실측). 한 갈래로 담으면
  교리자료 메모가 엉뚱한 도서에 뜬다.
      BUNT_MEMO  도서·설교집  clicked_id = sys_book_unit.unit_id
      REFU_MEMO  교리자료     clicked_id = sys_ref_unit.ref_unit_id

⚠ **옛 이름은 `BOOK_NOTE`/`REF_NOTE` 였다**(2026-08-25 개명). 닻이 도서가 아니라
  **편(unit_id)** 인데 이름이 `BOOK_` 로 시작해 §78 이 기록한 혼동을 낳았다.
  넉 자 코드(`BUNT`=편 · `REFU`=자료집 글)로 맞췄다.

⚠ **밑줄은 겹치지 않는다**(사용자 결정). 겹치는 범위를 고르면 새로 만들지 않고
  **기존 메모를 연다** — 겹친다는 건 앞 메모에 썼어야 할 내용이다.

⚠ **본문을 다시 채우면 표시가 함께 사라진다**(`delete('1.0','end')`).
  채운 뒤에 반드시 `reload()` 를 부른다. 이것이 이 모듈에서 가장 틀리기 쉬운 자리다.

사용:
    python highlight_notes.py --selftest     (의무)
"""
import sys
import tkinter as tk
from tkinter import messagebox

import appdb
import i18n

QUOTE_MAX = 200          # 닻으로 저장하는 글 길이 (통합 화면에서도 이만큼 보인다)
INLINE_MAX = 120         # 본문에 보이는 메모 길이 — 넘으면 `…`, 눌러서 다 본다
TAG_MARK = 'hlmark'      # 밑줄 친 곳 — **글자색만** 바꾼다
TAG_MEMO = 'hlmemo'      # 본문에 끼운 메모 글자 — 걷어낼 때 이 태그로 찾는다
KINDS = {'BOOK': 'BUNT_MEMO', 'REF': 'REFU_MEMO'}


def _C(role, fallback):
    """역할 색 — 화면에 값을 박지 않는다(§36). 폴백은 이 꼴 안에서만."""
    try:
        import ui_theme
        return ui_theme.C(role) or fallback
    except Exception:
        return fallback

# 옛 이름 — 밖에서 쓰던 곳이 있어 남긴다
TAG_HL = TAG_MARK


def _c(role, dflt):
    try:
        import ui_theme
        return ui_theme.C(role)
    except Exception:
        return dflt


# ── 저장소 ────────────────────────────────────────────────────────────────

def load_notes(db_path, kind, unit_id):
    """그 유닛의 메모. `(id, 닻, 글, 날짜)` 목록."""
    if not unit_id:
        return []
    try:
        with appdb.connect(db_path) as conn:
            return conn.execute(
                "SELECT user_text_id, title, contents, "
                "       COALESCE(updated_at, created_at) "
                "FROM user_text_asset "
                "WHERE text_type=? AND clicked_id=? "
                "  AND COALESCE(record_status,'LIVE') IN ('LIVE','NEW','EDIT') "
                "ORDER BY user_text_id", (KINDS[kind], unit_id)).fetchall()
    except Exception:
        return []


def load_book_notes(db_path, book_id, lang='KO'):
    """**책 한 권 전체**의 밑줄 메모 — `(편 순번, 편 이름, id, 인용문, 글, 날짜)`.

    ★ 2026-08-24 사용자 지시 「책 한권을 선택하면 여백메모(선택한 본문 포함)를
      모아서 볼 수 있는 화면을 만들어라. 나의묵상 화면에서 표시하는 것과 별도로」.
      「나의 묵상 ▸ 내 메모」는 **전 자료를 한 목록**으로 보여 준다 — 한 권을
      되짚어 읽을 때는 그 책만 순서대로 보이는 자리가 따로 있어야 한다.
    ⚠ 편 이름은 **번역 덮개**를 먼저 본다(`book_label`) — 원제를 직접 읽으면
      마이어·켐피스에서 영어 제목이 샌다(§2026-08-23 여섯 곳 중 다섯이 그랬다).
    ⚠ 도서·설교는 `BUNT_MEMO` 하나로 담긴다(갈래는 `book_category` 가 가른다).
    """
    if not book_id:
        return []
    try:
        import book_label
        with appdb.connect(db_path) as conn:
            return conn.execute(
                "SELECT bu.sequence, " + book_label.SQL_PICK + ", "
                "       t.user_text_id, t.title, t.contents, "
                "       COALESCE(t.updated_at, t.created_at) "
                "  FROM user_text_asset t "
                "  JOIN sys_book_unit bu ON bu.unit_id = t.clicked_id "
                + book_label.SQL_JOIN +
                " WHERE t.text_type = '" + KINDS['BOOK'] + "' "
                "   AND COALESCE(t.record_status,'LIVE') IN ('LIVE','NEW','EDIT') "
                "   AND bu.book_id = ? "
                " ORDER BY bu.sequence, t.user_text_id",
                ((lang or 'KO'), book_id)).fetchall()
    except Exception as e:
        print('[hl book notes] %s' % e)
        return []


def count_unit_notes(db_path, kind, unit_id):
    """그 **편 하나**의 여백메모 수 (2026-08-31 사용자 「유닛을 보고 있는데
    **책 전체의 메모를 표시하면 안된다. 유닛의 메모만** 표시하라」).

    ⚠ `count_book_notes` 는 남긴다 — 책 단위로 훑는 화면(「이 책의 여백메모」
      팝업)이 그것을 쓴다. 세는 단위가 다르면 **함수도 달라야** 한다.
    """
    if not unit_id:
        return 0
    tt = KINDS.get(str(kind).upper()) or KINDS['BOOK']
    try:
        with appdb.connect(db_path) as conn:
            return conn.execute(
                "SELECT COUNT(*) FROM user_text_asset "
                " WHERE text_type=? AND clicked_id=? "
                "   AND COALESCE(record_status,'LIVE') IN ('LIVE','NEW','EDIT')",
                (tt, int(unit_id))).fetchone()[0]
    except Exception:
        return 0


def count_book_notes(db_path, book_id):
    if not book_id:
        return 0
    try:
        with appdb.connect(db_path) as conn:
            return conn.execute(
                "SELECT COUNT(*) FROM user_text_asset t "
                "  JOIN sys_book_unit bu ON bu.unit_id = t.clicked_id "
                " WHERE t.text_type='" + KINDS['BOOK'] + "' "
                "   AND COALESCE(t.record_status,'LIVE') IN ('LIVE','NEW','EDIT') "
                "   AND bu.book_id = ?", (book_id,)).fetchone()[0]
    except Exception:
        return 0


def save_note(db_path, kind, unit_id, anchor, body, note_id=None, lang='KO'):
    """⚠ **유닛을 모르면 저장하지 않는다.**

    실제로 `clicked_id=NULL` 인 메모 두 편이 생겼다(2026-08-15). 어느 자료에도
    안 붙으니 본문에서도 통합 화면에서도 **영영 안 보이는 미아**가 된다.
    쓴 사람은 저장된 줄 안다 — 오류가 안 났으니까. 그래서 여기서 막는다.
    """
    if not unit_id and not note_id:
        raise ValueError('unit_id 가 없다 — 미아 메모를 만들지 않는다')
    # ⚠ **인용문이 비면 닻이 없다.** 위치(`3.0`)만으로는 본문이 조금만 밀려도
    #   못 찾고, 통합 화면에도 보일 글이 없다. 실제로 `'5.0|'` 로 저장됐다(2026-08-16).
    if not split_anchor(anchor)[1].strip():
        raise ValueError('인용문이 비었다 — 다시 찾을 수 없는 메모다')
    with appdb.connect(db_path) as conn:
        if note_id:
            conn.execute(
                "UPDATE user_text_asset SET title=?, contents=?, "
                " record_status='EDIT', updated_at=DATETIME('now','localtime') "
                "WHERE user_text_id=?", (anchor, body, note_id))
        elif not conn.execute(
                # ★ 같은 자리·같은 글이 이미 있으면 다시 넣지 않는다(2026-10-09 ·
                #   1.txt 58 「사용자 db에 중복이 있다면 앱의 결함이다」)
                "SELECT 1 FROM user_text_asset WHERE clicked_id=? AND text_type=?"
                " AND title=? AND contents=?"
                " AND COALESCE(record_status,'LIVE')<>'HIDE'",
                (unit_id, KINDS[kind], anchor, body)).fetchone():
            conn.execute(
                "INSERT INTO user_text_asset (clicked_id, target_id, text_type, "
                " title, contents, lang_code, record_status, created_at, updated_at) "
                "VALUES (?,0,?,?,?,?, 'NEW', DATETIME('now','localtime'), "
                "        DATETIME('now','localtime'))",
                (unit_id, KINDS[kind], anchor, body, lang))
        conn.commit()


def delete_note(db_path, note_id):
    with appdb.connect(db_path) as conn:
        conn.execute("DELETE FROM user_text_asset WHERE user_text_id=?", (note_id,))
        conn.commit()


# ── 닻 ────────────────────────────────────────────────────────────────────

def make_anchor(index, quote):
    """`3.9|선택한 글` — 위치는 빠른 길, 글이 진짜 닻이다."""
    return '%s|%s' % (index, (quote or '')[:QUOTE_MAX])


def split_anchor(anchor):
    a = anchor or ''
    if '|' not in a:
        return None, a
    idx, quote = a.split('|', 1)
    return idx, quote


def find_anchor(text, anchor):
    """본문에서 그 자리를 찾는다. `(시작, 끝)` 또는 None.

    ⚠ 저장한 위치를 먼저 보고, 글이 다르면 **본문 전체에서 그 글을 찾는다.**
      재수집으로 앞이 밀려도 살아남는 이유다.
    """
    idx, quote = split_anchor(anchor)
    if not quote:
        return None
    if idx:
        try:
            end = '%s+%dc' % (idx, len(quote))
            if text.get(idx, end) == quote:
                return text.index(idx), text.index(end)
        except tk.TclError:
            pass
    pos = text.search(quote, '1.0', 'end')
    if not pos:
        return None
    return text.index(pos), text.index('%s+%dc' % (pos, len(quote)))


def _overlaps(text, a, b, c, d):
    return text.compare(a, '<', d) and text.compare(c, '<', b)


def inline_text(body):
    """본문에 보일 한 줄. **줄바꿈을 눌러서** 넣는다.

    ⚠ 여기서 안 누르면 메모 한 편이 본문을 여러 줄로 밀어낸다 —
      「본문의 구조가 망가진다」의 정체가 이것이었다(2026-08-15).

    ★ **양쪽에 표시를 둔다** (2026-08-16 사용자 지시) — `(memo) … (memo)`.
      한쪽만 있으면 어디서 끝나고 본문이 다시 시작하는지 알 수 없다.
    """
    s = ' '.join((body or '').split())
    if not s:
        return ''
    if len(s) > INLINE_MAX:
        s = s[:INLINE_MAX] + '…'
    m = i18n.t('HL_MEMO', 'memo')
    return '  (%s) %s (%s)' % (m, s, m)


# ── 글자색을 **그 화면색에 맞춰 계산한다** (2026-08-16 사용자 물음) ────────────
#
# ★ 「화면색에 따라 메모 글자색을 바꾸는 것이 복잡한가」 — **아니다. 더 간단하다.**
#   손으로 고른 두 값(밝은 계열/어두운 계열)은 16벌 중 **가장 나쁜 바탕**에 맞춰
#   타협한 값이다. 그래서 BLUE_D 에서 겨우 읽히는 색이 WHITE 에서는 필요 이상 연했다.
#   ⇒ **색조는 고정, 밝기만 그 테마의 바탕에서 푼다.** `ui_theme._brew` 가 팔레트를
#     만드는 방식과 같다 — 손으로 적은 값 대신 조리법을 둔다.
#
# ⚠ **바탕보다 어두운 쪽을 먼저 시도한다.** 밝은 바탕에는 진한 글자가 자연스럽다.
#   그쪽이 안 되면(바탕이 이미 어두우면) 밝은 쪽으로 간다. 순서를 바꾸면 흰 바탕에
#   연분홍이 나온다.
# ⚠ **테마 이름으로 기억한다.** 본문을 그릴 때마다 풀면 느리다.

MARK_HUE, MARK_SAT = 216, 0.90        # 고른 범위 — 남색
MEMO_HUE, MEMO_SAT = 348, 0.62        # 메모 — 와인
TARGET = 6.0                          # 목표 대비 (본문 기준 4.5 보다 넉넉히)

_color_cache = {}


def _lum(h):
    h = h.lstrip('#')
    c = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    c = [(x / 12.92 if x <= .03928 else ((x + .055) / 1.055) ** 2.4) for x in c]
    return .2126 * c[0] + .7152 * c[1] + .0722 * c[2]


def contrast(a, b):
    l1, l2 = sorted((_lum(a), _lum(b)), reverse=True)
    return (l1 + .05) / (l2 + .05)


def _hex(hue, sat, light):
    import colorsys
    r, g, b = colorsys.hls_to_rgb(hue / 360.0, light, sat)
    return '#%02X%02X%02X' % (round(r * 255), round(g * 255), round(b * 255))


def _solve(hue, sat, ground):
    """그 바탕에서 목표 대비를 내는 색. 어두운 쪽 → 밝은 쪽 순으로 찾는다."""
    for rng in (range(50, 4, -1), range(50, 96)):
        best, best_r = None, 0.0
        for l in rng:
            c = _hex(hue, sat, l / 100.0)
            r = contrast(c, ground)
            if r >= TARGET:
                return c
            if r > best_r:
                best, best_r = c, r
        if best_r >= 4.5:
            return best            # 목표엔 못 미쳐도 읽히면 받는다
    return best or _hex(hue, sat, 0.30)


def _ground():
    """글자가 얹히는 바탕 — 지금 테마의 본문 바탕."""
    try:
        import ui_theme
        return ui_theme.C('bg') or '#FFFFFF', ui_theme.current()
    except Exception:
        return '#FFFFFF', 'NONE'


def _pick(hue, sat, key):
    ground, theme = _ground()
    ck = (key, theme, ground)
    if ck not in _color_cache:
        _color_cache[ck] = _solve(hue, sat, ground)
    return _color_cache[ck]


def mark_color():
    """**선택한 범위**의 글자색 — 남색. 밝기는 그 화면색에서 계산한다."""
    return _pick(MARK_HUE, MARK_SAT, 'mark')


def memo_color():
    """**메모 글자**의 색 — 와인. 밝기는 그 화면색에서 계산한다.

    ★ 고른 범위와 **다른 색**이어야 한다 — 어디까지가 본문이고 어디부터가 내 메모인지
      색만 보고 갈려야 한다. 색상(348° vs 216°)이 달라 밝기가 비슷해도 갈린다.

    ⚠ **표본을 좁게 잡으면 「됐다」는 답이 나온다.** 처음에 호박을 골랐던 것은 밝은
      바탕을 **4벌만** 재서였다. 실제 밝은 계열은 12벌이고 `BLUE_D` 바탕이 `#ABC0DF`
      라 꽤 어둡다 — 거기서 호박은 **2.48:1** 이었다.
    """
    return _pick(MEMO_HUE, MEMO_SAT, 'memo')


# ── 화면 ──────────────────────────────────────────────────────────────────

class HighlightNotes:
    """읽기 본문 하나에 붙는다.

    `kind_getter()` → 'BOOK' | 'REF' · `unit_getter()` → 유닛 id
    """

    def __init__(self, text, db_path, kind_getter, unit_getter, lang_getter=None):
        self.text = text
        self.db_path = db_path
        self.kind_getter = kind_getter
        self.unit_getter = unit_getter
        self.lang_getter = lang_getter or (lambda: 'KO')
        self._note_tags = []
        self._float = None
        self._apply_styles()
        # ⚠ `<<Selection>>` 이 아니라 버튼을 뗄 때 본다 — 드래그 도중 계속 뜨면 성가시다
        text.bind('<ButtonRelease-1>', self._on_release, add='+')
        text.bind('<Button-1>', lambda _e: self._drop_float(), add='+')

    def _apply_styles(self):
        """밑줄 = **글자색만**. 메모 = 작은 글씨.

        ⚠ 바탕을 칠하지 않는다 — 「형광색만 바라보게 된다」(2026-08-15 사용자).
        """
        t = self.text
        col = mark_color()
        # ⚠ 바탕도 밑줄도 없다 — 둘 다 「시각적으로 안 좋다」(2026-08-16 사용자).
        #   글자색 하나로만 표시한다.
        t.tag_config(TAG_MARK, foreground=col, background='', underline=False)
        # ★ **메모도 본문과 같은 크기** (2026-08-16). 작은 글씨를 걷어냈다 —
        #   글꼴을 여기서 정하지 않으면 위젯의 표준 서식을 그대로 따른다.
        t.tag_config(TAG_MEMO, foreground=memo_color(), background='',
                     underline=False)
        t.tag_raise(TAG_MARK)
        t.tag_raise(TAG_MEMO)

    # ── 다시 그리기 ──────────────────────────────────────────────────
    def reload(self):
        """본문을 다시 채운 **뒤에** 부른다."""
        t = self.text
        was = t.cget('state')
        t.config(state='normal')
        try:
            self._clear()
            kind, uid = self.kind_getter(), self.unit_getter()
            if not kind or not uid:
                return
            found = []
            for nid, anchor, body, when in load_notes(self.db_path, kind, uid):
                fa = find_anchor(t, anchor)
                if not fa:
                    continue            # 자리를 잃었다 — 통합 화면에서 보인다
                found.append((self._offset(fa[0]), nid, fa, anchor, body))
            # ⚠ **뒤에서부터** 끼운다. 앞에서 끼우면 뒤쪽 자리표가 밀려
            #   두 번째 메모부터 엉뚱한 곳에 붙는다 — 그리고 오류는 안 난다.
            found.sort(key=lambda r: r[0], reverse=True)
            for _off, nid, (a, b), anchor, body in found:
                self._draw_one(nid, a, b, anchor, body)
        finally:
            t.config(state=was)
            self._apply_styles()

    def _offset(self, index):
        """`'12.3'` 을 글자 수로. 문자열 비교로 정렬하면 10줄이 9줄보다 앞선다."""
        try:
            return self.text.count('1.0', index, 'chars')[0]
        except Exception:
            return 0

    def _clear(self):
        """앞서 끼운 메모 글자와 표시를 걷어낸다."""
        t = self.text
        rr = list(t.tag_ranges(TAG_MEMO))
        # ⚠ 뒤에서부터 지운다 — 앞을 지우면 뒤 자리표가 당겨진다
        for i in range(len(rr) - 2, -1, -2):
            try:
                t.delete(rr[i], rr[i + 1])
            except tk.TclError:
                pass
        t.tag_remove(TAG_MARK, '1.0', 'end')
        for tg in self._note_tags:
            try:
                t.tag_delete(tg)
            except tk.TclError:
                pass
        self._note_tags = []
        self._drop_float()

    def _draw_one(self, nid, a, b, anchor, body):
        t = self.text
        t.tag_add(TAG_MARK, a, b)
        line = inline_text(body)
        if not line:
            return
        t.insert(b, line, (TAG_MEMO,))
        tg = 'hlnote_%s' % nid
        t.tag_add(tg, b, '%s+%dc' % (b, len(line)))
        t.tag_config(tg, foreground=memo_color())
        t.tag_bind(tg, '<Button-1>', lambda _e: self._editor(nid, anchor, body))
        t.tag_bind(tg, '<Enter>', lambda _e: t.config(cursor='hand2'))
        t.tag_bind(tg, '<Leave>', lambda _e: t.config(cursor=''))
        self._note_tags.append(tg)

    # ── 새 메모 ──────────────────────────────────────────────────────
    def _on_release(self, _evt=None):
        self._drop_float()
        t = self.text
        try:
            a, b = t.index('sel.first'), t.index('sel.last')
        except tk.TclError:
            return
        if t.get(a, b).strip() == '':
            return
        # 메모 글자를 골랐으면 그 메모를 연다 — 본문을 고른 것이 아니다
        for tg in self._note_tags:
            rr = t.tag_ranges(tg)
            if rr and _overlaps(t, a, b, str(rr[0]), str(rr[1])):
                return
        # 겹치면 새로 만들지 않고 알린다 (사용자 결정 2026-08-15)
        rr = t.tag_ranges(TAG_MARK)
        for r in range(0, len(rr), 2):
            if _overlaps(t, a, b, str(rr[r]), str(rr[r + 1])):
                messagebox.showinfo(
                    i18n.t('HL_TITLE', '메모'),
                    i18n.t('HL_OVERLAP',
                           '이미 메모가 있는 자리입니다. 그 메모를 고쳐 주세요.'),
                    parent=t)
                return
        self._show_float(a, b)

    def _show_float(self, a, b):
        """작은 떠 있는 단추.

        ⚠ **본문에 끼우지 않는다** — 끼우면 글자가 밀리고(첫 판이 그랬다),
          `place()` 로 얹으면 본문을 덮는다(둘째 판이 그랬다).
          별도 창이라 본문에 아무 흔적이 없다. 다음 클릭에 사라진다.
        """
        t = self.text
        bbox = t.bbox(b)
        if bbox:
            x, y, _w, h = bbox
            sx, sy = t.winfo_rootx() + x, t.winfo_rooty() + y + h + 2
        else:
            # ⚠ 자리를 못 구해도 **그냥 넘어가지 않는다** — 아무 일도 안 일어나면
            #   사용자는 기능이 없는 줄 안다. 포인터 밑에라도 띄운다.
            sx, sy = t.winfo_pointerx() + 8, t.winfo_pointery() + 12
        win = tk.Toplevel(t)
        win.overrideredirect(True)
        # ⚠ **`transient()` 를 걸지 말 것.** `overrideredirect` 와 함께 쓰면
        #   윈도우가 이 창을 띄우지 않는다 — 객체는 생기고 화면에는 없다.
        #   그래서 「설교집 밑줄이 안 된다」가 됐다(2026-08-15).
        # ★★ **여백메모** (2026-08-24 사용자 지시 — 「잘 안 보인다. 예외적으로
        #   하드코딩하라 … 어떤 테마로 하든지 글자가 잘 보여야 한다」).
        #   ⚠ 그래도 **화면에 색을 박지 않는다** — `ui_theme.FIXED_ROLES` 에
        #     역할로 등록해 두고 여기서는 `C(역할)` 만 읽는다(§36).
        #   ⚠ **글자색만으로는 안 된다** — 진한 빨강이 검정 테마에서 1.5:1 이다.
        #     **흰 바탕까지 고정**해야 16개 테마 전부에서 읽힌다(10.0:1).
        #   ⚠ 이름 = 영어 Marginalia · 한국어 **여백메모**(사용자 확정).
        #   ⚠ 옛 `✎` 는 맑은 고딕·굴림·바탕 **셋 다 없는 글자**라 뺐다(cmap 실측).
        btn = tk.Button(win, text=i18n.t('HL_ADD', '여백메모'),
                  bg=_C('marginalia_bg', '#FFFFFF'),
                  fg=_C('marginalia_fg', '#8B0000'),
                  activebackground=_C('marginalia_bg', '#FFFFFF'),
                  activeforeground=_C('marginalia_fg', '#8B0000'),
                  highlightthickness=1,
                  highlightbackground=_C('marginalia_bd', '#8B0000'),
                  font=('', 9, 'bold'), bd=2, relief='raised',
                  cursor='hand2', padx=8, pady=2,
                  command=lambda: (self._drop_float(), self._new(a, b)))
        # ⚠⚠ **`paint` 가 이 색을 번역해 버린다** — `#FFFFFF` 는 12개 테마에서
        #   `fg_on_dark` 라 역방향 표가 알아보고 검정 테마 색으로 바꿨다
        #   (실측: 바탕이 `#1D1E1F` 가 됐다. 「overrideredirect 는 paint 가 못
        #   닿는다」는 옛 메모는 **틀렸다** — Toplevel 도 부모의 자식이다).
        #   ⇒ **이미 있는 장치를 쓴다** — `SAMPLE` 은 「자기 색이 곧 내용인 위젯」을
        #     통째로 건너뛴다. 여백메모 단추가 바로 그것이다.
        try:
            import ui_theme
            setattr(btn, ui_theme.SAMPLE, True)
            setattr(win, ui_theme.SAMPLE, True)
        except Exception:
            pass
        btn.pack()
        # 고른 줄 **아래**에 둔다 — 위에 두면 방금 고른 글자를 가린다
        win.geometry('+%d+%d' % (sx, sy))
        try:
            win.attributes('-topmost', True)
        except Exception:
            pass
        win.lift()
        win.update_idletasks()
        self._float = win

    def _drop_float(self):
        if self._float is not None:
            try:
                self._float.destroy()
            except Exception:
                pass
            self._float = None

    def _new(self, a, b):
        quote = self.text.get(a, b)
        self._editor(None, make_anchor(self.text.index(a), quote), '')

    # ── 편집 — 작은 창 ───────────────────────────────────────────────
    def _editor(self, nid, anchor, body):
        """본문 밖 작은 창에서 고친다.

        ⚠ **본문 안에 편집칸을 만들지 않는다.** 첫 판이 그렇게 했다가
          쓰는 동안 본문이 통째로 밀렸다(2026-08-15 사용자 지적).
        """
        t = self.text
        win = tk.Toplevel(t)
        win.title(i18n.t('HL_TITLE', '메모'))
        win.transient(t.winfo_toplevel())
        bg = _c('panel', '#F4F6F7')
        win.config(bg=bg)

        bar = tk.Frame(win, bg=bg)                      # 단추는 위 (§0)
        bar.pack(fill='x', padx=8, pady=(8, 4))
        _b = dict(bd=1, relief='raised', cursor='hand2', padx=6, pady=0)

        quote = split_anchor(anchor)[1]
        tk.Label(win, text=('“%s”' % quote[:80]) + ('…' if len(quote) > 80 else ''),
                 bg=bg, fg=_c('accent', '#1F5FA8'), anchor='w', justify='left',
                 wraplength=420).pack(fill='x', padx=10, pady=(0, 4))

        # 6줄 → 18줄 (2026-08-16 사용자 「높이를 3배 정도 늘려라」)
        box = tk.Text(win, height=18, width=56, wrap='word', relief='flat',
                      bg=_c('bg', '#FFFFFF'), fg=_c('fg', '#000000'),
                      insertbackground=_c('fg', '#000000'),
                      highlightthickness=1,
                      highlightbackground=_c('border', '#BDC3C7'))
        box.pack(fill='both', expand=True, padx=10, pady=(0, 10))
        if body:
            box.insert('1.0', body)

        def _save(_e=None):
            txt = box.get('1.0', 'end-1c').strip()
            if not txt:
                return _close()
            try:
                save_note(self.db_path, self.kind_getter(), self.unit_getter(),
                          anchor, txt, nid, self.lang_getter())
            except ValueError:
                # 유닛을 잃었다 — 조용히 삼키면 쓴 글이 사라진다
                messagebox.showwarning(
                    i18n.t('HL_TITLE', '메모'),
                    i18n.t('HL_NOUNIT', '어느 자료를 읽는 중인지 알 수 없어 '
                                        '저장하지 못했습니다. 본문을 다시 연 뒤 '
                                        '적어 주세요.'), parent=win)
                return
            _close()

        def _close(_e=None):
            try:
                win.destroy()
            except Exception:
                pass
            self.reload()

        def _del():
            if nid and messagebox.askyesno(i18n.t('HL_TITLE', '메모'),
                                           i18n.t('HL_DEL', '이 메모를 지울까요?'),
                                           parent=win):
                delete_note(self.db_path, nid)
                _close()

        tk.Button(bar, text=i18n.t('COMMON_SAVE', '저장'),
                  fg=_c('success', '#1E8449'), command=_save, **_b).pack(side='left')
        if nid:
            tk.Button(bar, text=i18n.t('COMMON_DELETE', '삭제'),
                      fg=_c('danger', '#B03A2E'), command=_del,
                      **_b).pack(side='right')
        tk.Button(bar, text=i18n.t('COMMON_CLOSE', '닫기'),
                  fg=_c('fg_dim', '#6F757C'), command=_close,
                  **_b).pack(side='right', padx=6)

        win.bind('<Escape>', _close)
        win.bind('<Control-Return>', _save)
        win.protocol('WM_DELETE_WINDOW', _save)      # 창을 닫아도 잃지 않는다
        win.update_idletasks()
        win.geometry('+%d+%d' % (t.winfo_rootx() + 40, t.winfo_rooty() + 60))
        box.focus_set()


# ── 자가검증 ──────────────────────────────────────────────────────────────

def selftest():
    ok = True
    r = tk.Tk()
    r.withdraw()
    t = tk.Text(r)
    body = "가 문단.\n\n나 문단. 이 문장을 선택한다.\n\n다 문단.\n"
    t.insert('1.0', body)

    quote = t.get('3.7', '3.20')
    anchor = make_anchor('3.7', quote)
    got = find_anchor(t, anchor)
    if not got or t.get(*got) != quote:
        print('FAIL 저장한 자리를 못 찾는다:', got); ok = False

    # ★ 앞 문단이 사라져도 찾아야 한다 — 이 모듈의 존재 이유
    t2 = tk.Text(r)
    t2.insert('1.0', body.replace('가 문단.\n\n', ''))
    got2 = find_anchor(t2, anchor)
    if not got2 or t2.get(*got2) != quote:
        print('FAIL 본문이 밀리면 못 찾는다:', got2); ok = False

    if find_anchor(t, make_anchor('1.0', '있을 리 없는 글자열입니다')) is not None:
        print('FAIL 없는 닻을 찾았다고 한다'); ok = False

    long_q = '가' * 500
    if len(split_anchor(make_anchor('1.0', long_q))[1]) != QUOTE_MAX:
        print('FAIL 닻을 안 자른다'); ok = False

    # 겹침 판정 — 양방향
    if not _overlaps(t, '3.5', '3.15', '3.10', '3.20'):
        print('FAIL 겹치는데 안 겹친다고 한다'); ok = False
    if _overlaps(t, '3.0', '3.5', '3.10', '3.20'):
        print('FAIL 안 겹치는데 겹친다고 한다'); ok = False
    if _overlaps(t, '3.0', '3.5', '3.5', '3.9'):
        print('FAIL 맞닿은 것을 겹침으로 본다'); ok = False

    if KINDS['BOOK'] == KINDS['REF']:
        print('FAIL 갈래가 안 갈린다'); ok = False

    # ★ **본문 줄 수가 늘지 않아야 한다** — 이번 재설계의 핵심
    if '\n' in inline_text('첫 줄\n둘째 줄\n\n셋째 줄'):
        print('FAIL 메모에 줄바꿈이 남는다 — 본문이 밀린다'); ok = False
    if inline_text('  \n ') != '':
        print('FAIL 빈 메모가 글자를 만든다'); ok = False
    if not inline_text('가' * 500).rstrip().endswith(')'):
        print('FAIL 긴 메모에 끝 표시가 없다'); ok = False
    if '…' not in inline_text('가' * 500):
        print('FAIL 긴 메모를 안 자른다'); ok = False
    if inline_text('짧은 글').count('(') != 2:
        print('FAIL 메모 범위 표시가 양쪽에 없다'); ok = False

    t3 = tk.Text(r)
    t3.insert('1.0', body)
    before = int(t3.index('end-1c').split('.')[0])
    t3.insert('3.20', inline_text('여러\n줄\n메모'), (TAG_MEMO,))
    if int(t3.index('end-1c').split('.')[0]) != before:
        print('FAIL 메모를 끼우니 줄 수가 늘었다'); ok = False

    # ★ **뒤에서부터 끼워야 앞 자리가 안 밀린다** — 실제로 이 순서가 답이다
    t4 = tk.Text(r)
    t4.insert('1.0', 'AAA BBB CCC\n')
    a1 = make_anchor('1.0', 'AAA')
    a2 = make_anchor('1.8', 'CCC')
    f1, f2 = find_anchor(t4, a1), find_anchor(t4, a2)
    t4.insert(f2[1], inline_text('뒤'), (TAG_MEMO,))     # 뒤부터
    t4.insert(f1[1], inline_text('앞'), (TAG_MEMO,))
    if t4.get(*find_anchor(t4, a2)) != 'CCC':
        print('FAIL 뒤에서부터 끼웠는데도 자리가 밀렸다'); ok = False

    # 반대 순서는 밀려야 한다 — 안 밀리면 이 검사가 죽은 것이다
    t5 = tk.Text(r)
    t5.insert('1.0', 'AAA BBB CCC\n')
    g1, g2 = find_anchor(t5, a1), find_anchor(t5, a2)
    t5.insert(g1[1], inline_text('앞'), (TAG_MEMO,))     # 앞부터 — 틀린 순서
    if t5.get(g2[0], g2[1]) == 'CCC':
        print('FAIL 앞에서부터 끼웠는데 안 밀린다 — 검사가 죽었다'); ok = False

    # 밑줄은 **바탕을 칠하지 않는다**
    t6 = tk.Text(r)
    HighlightNotes(t6, ':memory:', lambda: None, lambda: None)
    if t6.tag_cget(TAG_MARK, 'background'):
        print('FAIL 밑줄이 바탕을 칠한다 — 형광펜으로 돌아갔다'); ok = False
    if not t6.tag_cget(TAG_MARK, 'foreground'):
        print('FAIL 밑줄에 글자색이 없다'); ok = False
    if t6.tag_cget(TAG_MARK, 'underline') not in ('', '0', 0, False):
        print('FAIL 밑줄이 그어진다 — 시각적으로 안 좋다고 했다'); ok = False
    if t6.tag_cget(TAG_MEMO, 'font'):
        print('FAIL 메모가 제 글꼴을 갖는다 — 본문 표준을 안 따른다'); ok = False
    if t6.tag_cget(TAG_MEMO, 'foreground') == t6.tag_cget(TAG_MARK, 'foreground'):
        print('FAIL 메모와 선택한 범위가 같은 색이다 — 갈리지 않는다'); ok = False

    try:
        save_note(':memory:', 'BOOK', None, 'a|b', '글')
        print('FAIL 유닛 없는 메모를 받아 준다 — 미아가 생긴다'); ok = False
    except ValueError:
        pass
    try:
        save_note(':memory:', 'BOOK', 1, '5.0|   ', '글')
        print('FAIL 인용문 없는 메모를 받아 준다 — 다시 못 찾는다'); ok = False
    except ValueError:
        pass

    # ★ **16벌 전부의 본문 바탕**에 대해 읽히는가 (2026-08-16 신설).
    #   4벌만 재서 「됐다」고 했다가 블루 계열에서 2.48:1 이 나온 적이 있다.
    try:
        import ui_theme

        def _lum(h):
            h = h.lstrip('#')
            c = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
            c = [(x / 12.92 if x <= .03928 else ((x + .055) / 1.055) ** 2.4)
                 for x in c]
            return .2126 * c[0] + .7152 * c[1] + .0722 * c[2]

        def _ratio(a, b):
            l1, l2 = sorted((_lum(a), _lum(b)), reverse=True)
            return (l1 + .05) / (l2 + .05)

        _was = ui_theme._active
        for th, pal in ui_theme.PALETTE.items():
            ui_theme._active = th
            for nm, col in (('메모', memo_color()), ('선택한범위', mark_color())):
                r_ = _ratio(col, pal['bg'])
                if r_ < 5.0:
                    print('FAIL %s 가 %s 에서 안 읽힌다 — %.2f:1 (바탕 %s)'
                          % (nm, th, r_, pal['bg']))
                    ok = False
        ui_theme._active = _was
        if memo_color() == mark_color():
            print('FAIL 메모와 선택한 범위가 같은 색이다'); ok = False
    except Exception as e:
        print('FAIL 대비 검사를 못 돌렸다:', e); ok = False

    r.destroy()
    print('selftest', 'OK' if ok else 'FAIL')
    return ok


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--selftest':
        sys.exit(0 if selftest() else 1)
    print(__doc__.split('\n')[0])
