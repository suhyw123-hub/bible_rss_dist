# -*- coding: utf-8 -*-
"""notify.py — 텔레그램 알림 전송(영구 유틸). 자격증명은 ~/.gemini_notify.json(git 미추적).

사용:
  python notify.py msg "보낼 문구"
  python notify.py doc 파일경로 [캡션]
설정 파일 형식:
  {"telegram_bot_name":"...","telegram_token":"숫자:문자","telegram_chat_id":"숫자"}
의존성 없음(표준 라이브러리 urllib만 사용).
"""
import json
import os
import sys
import urllib.request
import urllib.parse

CFG_PATH = os.path.expanduser('~/.gemini_notify.json')


def _cfg():
    with open(CFG_PATH, encoding='utf-8') as f:
        return json.load(f)


def send_message(text):
    c = _cfg()
    url = f"https://api.telegram.org/bot{c['telegram_token']}/sendMessage"
    data = urllib.parse.urlencode({'chat_id': c['telegram_chat_id'], 'text': text}).encode('utf-8')
    with urllib.request.urlopen(url, data=data, timeout=30) as r:
        return json.load(r)


def send_document(path, caption=''):
    c = _cfg()
    url = f"https://api.telegram.org/bot{c['telegram_token']}/sendDocument"
    boundary = '----gemininotifyboundary'
    fn = os.path.basename(path)
    with open(path, 'rb') as f:
        filedata = f.read()
    parts = []

    def field(name, value):
        parts.append(
            (f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n').encode('utf-8'))

    field('chat_id', str(c['telegram_chat_id']))
    if caption:
        field('caption', caption)
    parts.append((f'--{boundary}\r\nContent-Disposition: form-data; name="document"; '
                  f'filename="{fn}"\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n').encode('utf-8'))
    parts.append(filedata)
    parts.append(f'\r\n--{boundary}--\r\n'.encode('utf-8'))
    body = b''.join(parts)
    req = urllib.request.Request(url, data=body)
    req.add_header('Content-Type', f'multipart/form-data; boundary={boundary}')
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.load(r)


if __name__ == '__main__':
    mode = sys.argv[1] if len(sys.argv) > 1 else 'msg'
    try:
        if mode == 'doc':
            res = send_document(sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else '')
        else:
            res = send_message(sys.argv[2] if len(sys.argv) > 2 else 'test')
        print('OK' if res.get('ok') else f'FAIL: {res}')
    except Exception as e:
        print(f'ERROR: {e}')
        sys.exit(1)
