"""
db_media_crawler.py
-------------------
페리코프별 YouTube 설교/강해 URL 자동 수집.

[ 사전 준비 ]
1. YouTube Data API v3 키 발급:
   Google Cloud Console → 새 프로젝트 → API 라이브러리 → "YouTube Data API v3" 활성화
   → 사용자 인증 정보 → API 키 생성
   → 환경변수: set YOUTUBE_API_KEY=AIzaSy...

2. (선택) Naver 검색 API — 한국어 블로그/카페 수집:
   https://developers.naver.com → 애플리케이션 등록 → 검색 API
   → 환경변수:
        set NAVER_CLIENT_ID=your_id
        set NAVER_CLIENT_SECRET=your_secret

[ 할당량 ]
  YouTube 무료: 10,000 units/일 = 100 검색/일 = 50 페리코프/일 (EN+KO 각 1회)
  전체 3,061개 완료: 무료 ~62일 / 유료 $3~5 하루
  Naver: 25,000회/일 무료 → KO 블로그는 할당량 걱정 없음

[ 실행 예시 ]
  python db_media_crawler.py --dry-run --limit 10     # 결과 미리보기 (삽입 없음)
  python db_media_crawler.py --run --limit 50         # 50개 처리·삽입
  python db_media_crawler.py --run --lang EN          # 영어만 전체 처리
  python db_media_crawler.py --run --offset 500       # 501번 페리코프부터 재개
  python db_media_crawler.py --run --regen peri_id    # 특정 페리코프 재수집

[ 품질 관리 ]
  자동 수집 항목은 is_active=0 으로 저장 → 관리자 검토 후 is_active=1 활성화
  수동 큐레이션 항목은 sort_order < 100, 자동 수집은 sort_order=500
"""

import sqlite3
import os
import json
import time
import argparse
import re
import sys
from datetime import datetime
import media_exclude   # 가톨릭 등 제외후보 키워드 플래그(소프트 — 수집 후 검토)
import media_link      # 영상 연결 단일 소스(통합 표 이름·link_type)
import db_media_range as media_range   # 제목·설명문 → 구절 구간(연결 대상 단일 소스)
import media_taxonomy as tax   # 분류 키워드 언어별/공통 + classify_content/detect_format
import db_media_attempt as _att   # 수집 시도 로그 — **균형의 잣대**(2026-09-04)

if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

# ── 외부 의존성 체크 ─────────────────────────────────────────────────────────
try:
    from googleapiclient.discovery import build as yt_build
    from googleapiclient.errors import HttpError
    YOUTUBE_AVAILABLE = True
except ImportError:
    YOUTUBE_AVAILABLE = False

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

DB = "bible_master.db"

# 키 로테이션: 쉼표로 구분된 복수 키 지원
# 예: $env:YOUTUBE_API_KEY = "key1,key2,key3"
_raw_keys = os.getenv('YOUTUBE_API_KEY', '')
YOUTUBE_API_KEYS = [k.strip() for k in _raw_keys.split(',') if k.strip()]
_key_idx = 0

def get_youtube_key():
    return YOUTUBE_API_KEYS[_key_idx] if YOUTUBE_API_KEYS else ''

def rotate_key():
    global _key_idx
    _key_idx += 1
    if _key_idx < len(YOUTUBE_API_KEYS):
        print(f"    [→] 키 로테이션: 키 #{_key_idx + 1}/{len(YOUTUBE_API_KEYS)} 사용")
        return True
    print(f"    [!] 모든 키({len(YOUTUBE_API_KEYS)}개) 할당량 소진. 내일 재시도.")
    return False

NAVER_CLIENT_ID = os.getenv('NAVER_CLIENT_ID', '')
NAVER_CLIENT_SECRET = os.getenv('NAVER_CLIENT_SECRET', '')

# 검색당 유튜브 API 비용: search.list = 100 units
YOUTUBE_UNITS_PER_SEARCH = 100
YOUTUBE_DAILY_QUOTA = 10000

# 최소 관련성 점수 — 이 값 미만은 저장하지 않음
MIN_SCORE = 5

# 폴백 언어: 자국어 결과가 MIN_RESULTS개 미만이면 EN 결과를 대신 저장
MIN_RESULTS_FOR_LANG = 2
LANG_FALLBACK_TO_EN = {'ZH', 'JA', 'DE', 'ES', 'FR', 'AR', 'PT', 'RU', 'COP', 'HE', 'EL'}


# ── 콘텐츠 분류 키워드 ────────────────────────────────────────────────────────
WORSHIP_KW = [
    '찬양', '찬송', 'ccm', '워십', '경배와찬양', '경배',
    'worship', 'praise', 'hymn', ' song', 'anthem', 'live worship',
    'hillsong', 'bethel', 'elevation worship', 'maverick city', 'passion',
    'chris tomlin', 'kari jobe', 'lauren daigle',
]
SERMON_KW = [
    '설교', '강해', '강의', '묵상', '성경공부', '큐티', '말씀',
    'sermon', 'teaching', 'bible study', 'expository', 'commentary',
    'preaching', 'message', 'devotional', 'exposition', 'exegesis',
]


def _load_classify_keywords():
    """sys_config에서 분류 키워드를 로드. 없으면 하드코딩 기본값 반환."""
    try:
        conn = sqlite3.connect(DB)
        rw = conn.execute(
            "SELECT config_val FROM sys_config WHERE config_key='MEDIA_CLASSIFY_WORSHIP_KW'"
        ).fetchone()
        rs = conn.execute(
            "SELECT config_val FROM sys_config WHERE config_key='MEDIA_CLASSIFY_SERMON_KW'"
        ).fetchone()
        conn.close()
        worship = json.loads(rw[0]) if rw else WORSHIP_KW
        sermon  = json.loads(rs[0]) if rs else SERMON_KW
        return worship, sermon
    except Exception:
        return WORSHIP_KW, SERMON_KW


def classify_media_type(title: str, channel: str,
                        worship_kw=None, sermon_kw=None) -> str:
    """YouTube 제목+채널명 기반으로 SERMON 또는 WORSHIP 분류. SERMON이 기본값."""
    wkw = worship_kw if worship_kw is not None else WORSHIP_KW
    skw = sermon_kw  if sermon_kw  is not None else SERMON_KW
    text = (title + ' ' + channel).lower()
    worship_hits = sum(1 for kw in wkw if kw in text)
    sermon_hits  = sum(1 for kw in skw if kw in text)
    return 'WORSHIP' if worship_hits > sermon_hits else 'SERMON'


# ── 검색 쿼리 생성 ────────────────────────────────────────────────────────────
# 언어별 검색 키워드(설교). 책 이름은 book_names 의 해당 언어 사용(없으면 EN 폴백).
_SERMON_KW = {
    'EN': 'sermon', 'KO': '설교 강해', 'ZH': '讲道', 'JA': '説教', 'DE': 'Predigt',
    'FR': 'prédication', 'ES': 'sermón', 'PT': 'sermão', 'RU': 'проповедь', 'AR': 'عظة',
}


def make_query(bname, bcode, chapter, v_start, v_end, title_en, lang,
               unit='PERI'):
    """bname={lang:{book_code:full_name}}. 현지 책명 있으면 사용, 없으면 EN 폴백.
    언어가 늘어도 book_names 에 해당 언어 책명만 있으면 자동 현지화."""
    book = bname.get(lang, {}).get(bcode) or bname.get('EN', {}).get(bcode, 'Unknown')
    v_str = str(v_start) if v_start == v_end else f"{v_start}-{v_end}"
    # ★ **장 좌표면 절을 안 붙인다** — 「창세기 1장 설교」로 찾는다.
    #   ⚠ 절까지 넣으면 유튜브가 그 절만 다루는 것을 우선해 **장 강해가 뒤로
    #     밀린다**(세상 콘텐츠의 24.9%가 장 전체다).
    if str(unit or 'PERI').upper() == 'CHAP':
        kw_c = _SERMON_KW.get(lang, 'sermon')
        if lang == 'KO':
            return f"{book} {chapter}장 {kw_c}"
        if lang in ('ZH', 'JA'):
            return f"{book} {chapter} {kw_c}"
        return f"{book} {chapter} {kw_c}"
    kw = _SERMON_KW.get(lang, 'sermon')
    if lang == 'KO':
        return f"{book} {chapter}장 {v_start}절 {kw}"
    if lang in ('ZH', 'JA'):
        return f"{book} {chapter} {kw}"
    if lang == 'EN':
        book_tokens = {w.lower() for w in book.split()}   # 책명 중복 제거(예: title 'Genesis 3:1' → 'Genesis' 빼기)
        words = [w for w in (title_en or '').split() if len(w) > 3 and w.lower() not in
                 {'the', 'and', 'for', 'that', 'with', 'his', 'her', 'their', 'from', 'this', 'into'}
                 and w.lower() not in book_tokens]
        return f"{book} {chapter}:{v_str} {kw} {' '.join(words[:3])}".strip()
    return f"{book} {chapter}:{v_str} {kw}"


# ── YouTube 검색 ──────────────────────────────────────────────────────────────
def is_youtube_short(video_id: str) -> bool:
    """YouTube Shorts 판별 — youtube.com/shorts/{id} 가 200이면 Short(제외), 일반 영상이면
    watch 로 리다이렉트(3xx). API 쿼터 불필요. 판별 실패 시 False(제외 안 함).

    ⚠ **2026-09-17 부터 부르는 곳이 0 이다** — 결과 하나에 HTTP 요청 하나(타임아웃 8초)라
      한 검색에 스물다섯 번을 두드리게 됐고, 유튜브를 몰아치면 404·500 이 쏟아진다(§251차 ④).
      **문지기가 `contentDetails` 의 길이(≤120초)와 제목으로 이미 거른다**(§⑤-25).
      되돌릴 자리로 남긴다 — 길이를 못 받는 경로가 생기면 그때 쓴다."""
    import urllib.request
    import urllib.error

    class _NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *a):
            return None
    try:
        op = urllib.request.build_opener(_NoRedirect)
        req = urllib.request.Request(
            f'https://www.youtube.com/shorts/{video_id}',
            method='HEAD', headers={'User-Agent': 'Mozilla/5.0'})
        return op.open(req, timeout=8).status == 200
    except urllib.error.HTTPError as e:
        return e.code == 200
    except Exception:
        return False


def video_ids(urls):
    """`watch?v=` 주소 목록 → 영상 id 목록(순서 유지·중복 제거)."""
    out, seen = [], set()
    for u in urls:
        m = re.search(r'(?:v=|youtu\.be/|embed/|shorts/)([\w-]{11})', u or '')
        if m and m.group(1) not in seen:
            seen.add(m.group(1))
            out.append(m.group(1))
    return out


#: 설명문 상한 — 전문을 담되 통째로 커지는 일은 막는다
MAX_DESC = 5000


def _fill_full_desc(youtube, results, batch=50):
    """`videos.list` 로 **설명문 전문 + 조회수**를 받아 `results` 에 채운다.

    ★ 50개당 1 unit — 검색 100 units 에 견주면 사실상 공짜다.
    ★★ **조회수는 같은 응답에 딸려 온다**(2026-09-09 사용자 「조회수 데이터도
      중요하다」) — `part` 에 `statistics` 를 더할 뿐이라 **추가 비용 0**이다.
      찬양은 프로 사역팀과 아마추어를 가릴 재료가 조회수뿐이다(제목·설명문에
      구절 표기가 76% 없다 — 실측).
    ⚠ **실패는 조용히 넘긴다** — 잘린 snippet 이 이미 들어 있으므로 수집
      자체가 막히면 안 된다.
    ⚠⚠ **여기서는 안 자른다**(2026-09-11) — 검색 snippet 은 유튜브가 이미
      잘라 주지만 이 호출은 **전문**을 준다. 가사는 설명문 뒤쪽에 있다.
    """
    import unicodedata as _ud
    by_id = {}
    for r in results:
        ids = video_ids([r.get('url', '')])
        if ids:
            by_id[ids[0]] = r
    ids = list(by_id)
    for i in range(0, len(ids), batch):
        chunk = ids[i:i + batch]
        try:
            # ★ `contentDetails` 를 더한다 — **50개당 1 unit** 이라
            #   칸을 더해도 **비용이 0**이다(2026-09-11 쇼츠 거르기).
            # ★★★ `status` 도 더한다(2026-09-24 1.txt 14번) — **임베드 가능
            #   여부를 담는 순간 안다.** 같은 호출이라 **비용이 0**이고,
            #   뒤에 링크 점검을 기다릴 까닭이 없어진다(미점검 더미가 안 자란다).
            resp = youtube.videos().list(
                part='snippet,statistics,contentDetails,status',
                id=','.join(chunk)).execute()
        except Exception as e:
            print('    [설명문 전문] 건너뜀: %s' % e)
            return
        for it in resp.get('items', []):
            r = by_id.get(it.get('id'))
            if not r:
                continue
            d = (it.get('snippet', {}) or {}).get('description', '') or ''
            if len(d) > len(r.get('description', '') or ''):
                # ★★★ **전문은 안 자른다**(2026-09-11 사용자 「영상 설명문이
                #   제대로 수집되지 못하고 **잘린다**」).
                #   ⚠⚠ 옛 주석이 「판정에 쓰는 몫은 앞부분이라 600으로 자른다」
                #     고 했는데 **분류에는 맞고 가사 수집에는 틀렸다** —
                #     **가사는 설명문 뒤쪽에 있다.**
                #   ⚠ 저장 부담은 실측 중앙값 86자라 문제가 안 된다.
                #     상한만 둔다(설명문 하나가 통째로 커지는 일을 막는다).
                r['description'] = _ud.normalize('NFC', d)[:MAX_DESC]
            # ⚠ 조회수는 **비공개인 영상이 있다** — 없으면 안 담는다(0 으로 짓지 않는다)
            # ★★★ **길이도 여기서 받는다**(2026-09-11 사용자 「2분 이내는
            #   숏츠로 취급하자」) — 이 호출은 **이미 `contentDetails` 를
            #   part 에 넣고 있다.** 담기만 하면 되고 **추가 비용이 0**이다.
            #   ⇒ 담기 **전에** 걸러져 점검을 기다릴 필요가 없다.
            try:
                import db_media_linkcheck as _LC
                _du = _LC.dur_sec((it.get('contentDetails', {}) or {}
                                   ).get('duration', ''))
                if _du is not None:
                    r['duration'] = _du
            except Exception:
                pass
            # ★ 임베드 가능 여부 — **없으면 안 담는다**(「모름」과 「된다」는
            #   다르다 · 지어내면 막힌 영상을 성한 것으로 적게 된다).
            _emb = (it.get('status', {}) or {}).get('embeddable')
            if _emb is not None:
                r['embed_ok'] = 1 if _emb else 0
            _vc = (it.get('statistics', {}) or {}).get('viewCount')
            if _vc not in (None, ''):
                try:
                    r['views'] = int(_vc)
                except (TypeError, ValueError):
                    pass


#: ★★★ **한 검색에 받는 수** (2026-09-17 유닛 점검 · 사용자 「낭비하는 요소가 있는지」).
#:   `search.list` 는 **결과가 1개든 50개든 100 units** 다. 그런데 5개만 받고 있었다 —
#:   실측 구절·용어 수동수집 **1,675회 = 167,500 units 로 본 것이 8,375개**뿐이고 새것은 4,526개다.
#:   같은 값으로 **다섯 배**를 본다. ⚠ 50 이 아니라 25 로 올린다 — 이 검색은 `order='relevance'`
#:   라 뒤로 갈수록 엉뚱해지고, 문지기를 통과한 것은 사람이 심사할 줄에 선다(미승인 26,000 —
#:   그 줄을 또 불리지 않는다). 한 자리에서만 고친다.
SEARCH_PAGE = 25


def youtube_search(query, lang_code, max_results=SEARCH_PAGE, classify_sets=None):
    if classify_sets is None:
        try:
            _c = sqlite3.connect(DB); classify_sets = tax.load_classify_sets(_c); _c.close()
        except Exception:
            classify_sets = {}
    if not YOUTUBE_AVAILABLE:
        print("    [!] google-api-python-client 미설치. pip install google-api-python-client")
        return []
    if not YOUTUBE_API_KEYS:
        print("    [!] YOUTUBE_API_KEY 환경변수 없음.")
        return []
    import lang_config
    rl = lang_config.relevance_lang(lang_code)   # ZHT='zh-Hant' 등 유효 코드(자체코드 'zht' 400 방지)

    while True:
        key = get_youtube_key()
        try:
            youtube = yt_build('youtube', 'v3', developerKey=key,
                               cache_discovery=False)
            resp = youtube.search().list(
                q=query,
                part='snippet',
                type='video',
                maxResults=max_results,
                relevanceLanguage=rl,
                # ⚠⚠⚠ **`videoDuration='medium'` 을 걷었다**(2026-09-17) — 그것은 **4~20분만**
                #   준다. 실측 우리가 가진 설교 중 **20분 초과가 5,591편(승인 2,257)** 인데
                #   이 검색은 그 덩어리를 **API 자리에서 통째로 버리고 있었다**(RSS 로 들어온 것만
                #   남아 있었다). 100 units 를 내고 가장 흔한 설교 길이를 빼고 받던 셈이다.
                #   ★ 쇼츠는 이제 문지기가 **길이(≤120초)와 제목**으로 거른다(§⑤-25) — 여기서
                #     길이로 막을 까닭이 없다.
                order='relevance',
            ).execute()
            results = []
            for item in resp.get('items', []):
                vid_id = item['id'].get('videoId', '')
                if not vid_id:
                    continue
                # ⚠ **결과마다 HTTP 로 쇼츠를 묻지 않는다**(2026-09-17) — 쿼터는 안 들지만
                #   결과 하나에 요청 하나(타임아웃 8초)라 25개면 25번이고, 유튜브를 몰아치면
                #   404·500 이 쏟아진다(§251차 ④ 그 자리). **문지기가 `contentDetails` 의 길이로
                #   이미 거른다**(바로 아래 `_fill_full_desc` 가 그 값을 담아 준다).
                s = item['snippet']
                import unicodedata as _ud
                # NFC 정규화 — 분해형(NFD) 한글 제목이 자모로 풀려 저장되는 것 방지
                s['title'] = _ud.normalize('NFC', s.get('title', '') or '')
                s['channelTitle'] = _ud.normalize('NFC', s.get('channelTitle', '') or '')
                results.append({
                    'url': f"https://www.youtube.com/watch?v={vid_id}",
                    'title': s['title'],
                    'channel': s['channelTitle'],
                    # ★ 유튜브 채널 id — 이름으로만 담으면 차단이 이름에 걸린다
                    #   (2026-09-09 실측 19,104편 중 5,941편만 id 보유).
                    'channel_id': s.get('channelId') or '',
                    'description': _ud.normalize('NFC', s.get('description', '') or '')[:600],
                    'published': s['publishedAt'][:10],
                    'thumbnail': s['thumbnails']['default']['url'],
                    'lang_code': lang_code,
                    # ⚠ **채널을 함께 넘긴다** — 교회 채널의 「예배」는 찬양이
                    #   아니다(2026-09-07 사용자 확정 · `is_church_channel`).
                    'media_type': tax.classify_content(
                        f"{s['title']} {s['channelTitle']}", lang_code,
                        classify_sets, channel=s['channelTitle']),
                    'format_type': tax.detect_format(
                        f"{s['title']} {s['channelTitle']}", lang_code, classify_sets),
                })
            # ★★★ **설명문 전문을 받는다** (2026-09-04 사용자 지적 「보통
            #   설명문이 길던데 지금 수집된 것은 한줄도 안되는 경우가 많다.
            #   **완전히 수집하지 않은 것 같다**」 — 맞다).
            #   ⚠⚠ `search.list` 의 snippet 은 **~140자에서 잘린다**(실측
            #     2,699건 중 최대 144자 · 중앙 85자). 제목에 좌표가 없는 영상은
            #     설명문이 유일한 단서인데 그 단서가 잘려 있었다.
            #   ★ 비용이 거의 0이다 — `videos.list` 는 **50개당 1 unit**
            #     (검색 한 번이 100 units 인 것과 견주면 무시할 수준).
            #   ⚠ 실패해도 그냥 넘어간다 — 전문은 **더 좋은 재료**이지
            #     없으면 못 도는 것이 아니다(잘린 snippet 이 이미 있다).
            _fill_full_desc(youtube, results)
            return results
        except HttpError as e:
            if e.resp.status in (403, 429):
                if not rotate_key():
                    sys.exit(1)
                continue  # 다음 키로 재시도
            print(f"    [!] YouTube API 오류: {e}")
            return []
        except Exception as e:
            print(f"    [!] YouTube 검색 오류: {e}")
            return []


# ── Naver 검색 (KO 블로그/카페) ───────────────────────────────────────────────
def naver_search(query, display=5):
    if not REQUESTS_AVAILABLE or not NAVER_CLIENT_ID:
        return []
    results = []
    for endpoint, mtype in [('blog', 'BLOG'), ('cafearticle', 'CAFE')]:
        try:
            url = "https://openapi.naver.com/v1/search/{}.json".format(endpoint)
            headers = {
                'X-Naver-Client-Id': NAVER_CLIENT_ID,
                'X-Naver-Client-Secret': NAVER_CLIENT_SECRET,
            }
            params = {'query': query, 'display': display, 'sort': 'sim'}
            resp = requests.get(url, headers=headers, params=params, timeout=8)
            resp.raise_for_status()
            for item in resp.json().get('items', []):
                title = re.sub(r'<[^>]+>', '', item.get('title', ''))
                link = item.get('link', '')
                if not link.startswith('http'):
                    continue
                results.append({
                    'url': link,
                    'title': title,
                    'channel': item.get('bloggername', item.get('cafename', '')),
                    'published': item.get('postdate', '')[:8],
                    'thumbnail': '',
                    'lang_code': 'KO',
                    'media_type': 'SERMON',
                    'format_type': 'TEXT',
                })
        except Exception as e:
            print(f"    [!] Naver {endpoint} 오류: {e}")
    return results


# ── 관련성 점수 계산 ──────────────────────────────────────────────────────────
def score_result(r, book_en, book_ko, chapter, pericope_title):
    title_lo = r['title'].lower()
    score = 0

    # 책 이름 매칭
    if book_en.lower() in title_lo:
        score += 10
    if book_ko and book_ko in r['title']:
        score += 10

    # 장 번호 포함
    ch_str = str(chapter)
    if ch_str in r['title']:
        score += 5

    # 설교/강해 키워드
    sermon_kw = ['sermon', 'commentary', 'preaching', 'teaching', 'bible study',
                 '설교', '강해', '강의', '묵상', '성경공부', '주석']
    for kw in sermon_kw:
        if kw in title_lo or kw in r['title']:
            score += 4
            break

    # 채널명에 교회/사역 키워드
    ch_lo = r.get('channel', '').lower()
    ministry_kw = ['church', 'ministry', 'bible', 'gospel', 'christian',
                   '교회', '성경', '복음', '선교', '목사']
    for kw in ministry_kw:
        if kw in ch_lo:
            score += 2
            break

    # 스팸/광고 감점
    spam_kw = ['#shorts', 'shorts', 'tiktok', 'clip', 'highlight', 'subscribe',
               'official mv', 'music video']
    for kw in spam_kw:
        if kw in title_lo:
            score -= 30

    # 페리코프 제목 단어 매칭 (보너스)
    if pericope_title:
        pt_words = [w.lower() for w in pericope_title.split() if len(w) > 4]
        for w in pt_words[:4]:
            if w in title_lo:
                score += 2

    return score


# ── 수집 제외 채널 목록 로드 ─────────────────────────────────────────────────
def _load_excluded_channels(conn):
    """수집 제외 채널 → set. **판정의 집은 `media_exclude`** (두 벌 금지)."""
    return media_exclude.excluded_channels(conn)


def chan_excluded(name, excluded):
    """호환 이름 — `media_exclude.chan_excluded` 로 위임."""
    return media_exclude.chan_excluded(name, excluded)


def _load_blacklisted_video_ids(conn):
    try:
        rows = conn.execute(
            "SELECT video_id FROM sys_media_blacklist WHERE video_id IS NOT NULL"
        ).fetchall()
        return {r[0] for r in rows}
    except Exception:
        return set()


# ── DB 저장 ───────────────────────────────────────────────────────────────────
#: 언어별 링커 컨텍스트 — 한 번 지으면 재사용(수집 한 바퀴에 수백 번 쓴다).
_ENT_CTX = {}


def offtopic_skip(conn, r, kw_list=None):
    """**저장하기 전에** 성경 본문과 무관한 꼴인지 본다 → 매칭어 또는 None.

    ★★★ **원인을 제거하는 자리다** (2026-09-04 사용자 지시 「왜 수집햇을까
      **원인을 제거해야 한다**」 · 「**필터링 로직 보강해라**」).
      실측 — 보관함 「실마리 없음」 1,727건의 79%가 자동크롤러가 채널을 통째로
      긁은 것이고, 제목 낱말 상위가 주일 202 · 예배 184 · 실황 56 이다.
    ⚠⚠ **앵커(구절 좌표·용어)를 먼저 읽고 그것이 있으면 통과시킨다** —
      실측 오프토픽 낱말이 든 1,247건 중 **58%(722건)가 좌표를 함께 갖는다**
      (「주일예배 | 창세기 1:1-5」). 낱말만 보고 거르면 그 722건을 잃는다.
    ⚠ 판정에 **설명문까지** 넣는다 — 제목이 「주일예배」뿐이어도 설명문에
      본문이 적힌 채널이 있다.
    """
    title = r.get('title', '') or ''
    body = (r.get('description') or '')[:600]
    txt = '%s\n%s' % (title, body)
    got = media_range.read(conn, title) or media_range.read(conn, body)
    anchor = bool(got)
    if not anchor:
        rx, nm = media_range._ent_rx(conn, r.get('lang_code') or 'KO')
        if rx and media_range.find_names(rx, nm, txt):
            anchor = True
    # ★ **그 영상의 언어로 잰다**(2026-09-06 사용자 지시 — 「한국어 이외에는
    #   **그 나라의 실정에 맞게** 적용하라」). 언어를 모르면 옛 동작(전부).
    return media_exclude.match_offtopic(txt, has_anchor=anchor,
                                        kw_list=kw_list,
                                        lang=(r.get('lang_code') or None))


def insert_media(conn, r, pericope_id, dry_run, exclude_kw_list=None,
                 offtopic_kw_list=None, skip_offtopic=True, gate=None):
    """수집물 하나를 담는다 → `action`(글자) 또는 건너뜀 dict.

    ★★★ **공통 품질관리 문에 위임한다**(2026-09-08 사용자 지시 — 「어떤
      방법으로 수집했던지, 어떤 키워드로 수집했던지 **공통적으로 거쳐야 할
      품질관리는 반드시 거치도록** 해야 한다」).
      ⚠ 그전에는 이 함수가 문지기·저장·연결을 **자기 손으로** 했고, 다른
        경로 넷이 각자 조금씩 다르게 했다. 이제 `media_intake.admit` 하나가
        다섯 걸음을 같은 차례로 한다.

    ⚠ **호출부의 반환 규약을 지킨다** — 「신규」/「기존」/「DRY」 글자, 또는
      건너뛰었으면 `{'action': 'SKIP_OFFTOPIC', 'title':…, 'kw':…}`.
    ⚠ `gate` 를 주면 재료를 다시 안 읽는다(한 바퀴에 수백 번 부른다).
    """
    import media_intake as MI
    g = gate if gate is not None else MI.Gate(conn)
    out = MI.admit(g, {
        'title': r.get('title', ''), 'url': r.get('url', ''),
        'lang_code': r.get('lang_code') or r.get('lang'),
        'channel': r.get('channel', ''),
        'channel_id': r.get('channel_id', ''),
        'published': r.get('published', ''),
        'thumbnail': r.get('thumbnail', ''),
        'yt_desc': r.get('description', ''),
    }, hint_id=pericope_id, dry_run=bool(dry_run),
        screen_on=bool(skip_offtopic))
    act = out['action']
    if act == MI.SKIP_OFFTOPIC:
        return {'action': 'SKIP_OFFTOPIC', 'media_id': None,
                'kw': out.get('why') or '', 'title': (r.get('title') or '')[:80]}
    if act == MI.SKIP_CHANNEL:
        return {'action': 'SKIP_CHANNEL', 'media_id': None,
                'kw': r.get('channel', ''), 'title': (r.get('title') or '')[:80]}
    if act == getattr(MI, 'SKIP_CHANNEL_KW', 'SKIP_CHANNEL_KW'):
        return {'action': 'SKIP_CHANNEL_KW', 'media_id': None,
                'kw': out.get('kw') or '', 'title': (r.get('title') or '')[:80]}
    if act == MI.SKIP_NO_URL:
        return {'action': 'SKIP_NO_URL', 'media_id': None, 'kw': '',
                'title': (r.get('title') or '')[:80]}
    return {MI.ACT_NEW: '신규', MI.ACT_EXIST: '기존',
            MI.ACT_DRY: 'DRY'}.get(act, act)


def run(limit, dry_run, lang_filter=None, offset=0, regen_peri_id=None,
        stop_event=None, langs=None, unit='PERI', order=None):
    conn = sqlite3.connect(DB)
    cur = conn.cursor()

    # 검색 대상 언어: langs(리스트) 우선 → lang_filter(단일, CLI 호환) → 기본 EN/KO
    eff_langs = [l for l in (langs or []) if l] or ([lang_filter] if lang_filter else ['EN', 'KO'])

    # 책 이름 캐시
    bname = {}   # {lang: {book_code: full_name}} — 전 언어(현지 책명 검색)
    for _code, _lc, _full in cur.execute(
            "SELECT book_code, lang_code, full_name FROM book_names"):
        bname.setdefault(_lc, {})[_code] = _full

    # 이미 수집된 (pericope, lang) 쌍 — 언어별 판정(언어 무관 "완료" 금지: EN/KO 있다고 ZH/JA 막지 않음)
    # ⚠⚠⚠ **진도는 「그 대목에 자료가 있나」로 잰다**(2026-09-04 사용자 신고
    #   「페리코프 수집기는 **창세기부터** 수집하고 있다」 — 정확한 지적이었다).
    #   그전에는 `MEDI_PERI` 링크로만 셌는데, 수집기를 구간 연결로 고치면서
    #   그 링크가 0 이 됐다. 그래서 **「아무것도 안 했다」로 보고 창세기부터
    #   다시 돌았다.** 화면만이 아니라 **진도 판정도 함께 고쳐야 했다.**
    #   ⇒ 페리코프 연결 ∪ **그 페리코프와 겹치는 구간 연결**.
    done_pairs = {
        (str(r[0]), r[1]) for r in cur.execute(  # status-ok: 「이미 판 자리」 장부 — 상태로 거르면 걷은 연결 자리를 영영 다시 판다
            "SELECT DISTINCT ml.target_id, a.lang_code "
            "FROM %s ml JOIN sys_media_asset a ON a.media_id=ml.clicked_id "
            "WHERE ml.link_type=? AND a.lang_code IS NOT NULL" % media_link.TBL,
            (media_link.lt('PERICOPE'),)).fetchall()
    }
    done_pairs |= {
        (str(r[0]), r[1]) for r in cur.execute(  # status-ok: 같은 장부(구간 연결로 덮인 단락)
            "SELECT DISTINCT p.pericope_id, a.lang_code"
            "  FROM %s ml"
            "  JOIN sys_media_asset a ON a.media_id=ml.clicked_id"
            "  JOIN sys_pericope_asset p"
            "    ON p.record_status='LIVE'"
            "   AND ml.target_id <= COALESCE(p.end_vid, p.start_vid)"
            "   AND COALESCE(ml.end_id, ml.target_id) >= p.start_vid"
            " WHERE ml.link_type=? AND a.lang_code IS NOT NULL" % media_link.TBL,
            (media_link.lt('VERSE'),)).fetchall()
    }

    _SEL = """
        SELECT p.pericope_id, p.peri_code, p.start_vid, p.end_vid, t.title,
               bi.bcode, bi.chapter, bi.verse
        FROM sys_pericope_asset p
        LEFT JOIN sys_text_asset t ON t.clicked_id=p.pericope_id
            AND t.text_type='PERI_TITLE' AND t.lang_code='EN'
        LEFT JOIN bible_index bi ON bi.verse_id=p.start_vid
    """
    # ★★★ **좌표를 장 단위로도 돌 수 있다** (2026-09-04 사용자 지시 —
    #   「수집좌표를 장으로 한다는 것은 지금 구절단위 수집 이외에 **장 단위
    #   수집 기능도 추가**하는 것으로 알겠다」).
    #   ⚠ **대체가 아니라 갈래를 하나 더 둔다** — 절 좌표가 더 나은 자리가
    #     있다(요3:16·시23 처럼 그 절만 다루는 설교가 많은 유명 구절).
    #   ★ 장 좌표의 값 = **검색 횟수가 2.6배 적다**(페리코프 3,061 → 장 1,189)
    #     그리고 **세상 콘텐츠가 장 단위에 가깝다**(실측 구간의 24.9%가 장
    #     전체 · 64.4%가 여러 절 · 한 절은 8.1%).
    #   ⚠ 진도(`done_pairs`)는 **페리코프 축 그대로** 쓴다 — 장을 돌아도 그
    #     장에 걸친 페리코프가 채워지므로 두 갈래가 서로의 진도를 인정한다.
    _CH_SEL = """
        SELECT MIN(p.pericope_id), 'CH_'||bi.bcode||'_'||bi.chapter,
               MIN(p.start_vid), MAX(COALESCE(p.end_vid, p.start_vid)),
               NULL, bi.bcode, bi.chapter, 1
        FROM sys_pericope_asset p
        JOIN bible_index bi ON bi.verse_id=p.start_vid
        WHERE p.peri_type='BODY'
        GROUP BY bi.bcode, bi.chapter
    """
    if regen_peri_id:
        pericopes = cur.execute(_SEL + " WHERE p.pericope_id=?", (regen_peri_id,)).fetchall()
        force_langs = True          # regen 은 선택 언어 전부 강제 재검색
        total_remaining = len(pericopes)
    else:
        if str(unit or 'PERI').upper() == 'CHAP':
            all_body = cur.execute(_CH_SEL).fetchall()
            print('좌표 = **장 단위** — %d장을 돈다(페리코프 축보다 2.6배 적다)'
                  % len(all_body))
        else:
            all_body = cur.execute(
                _SEL + " WHERE p.peri_type='BODY' ORDER BY p.pericope_id").fetchall()
        pending = [row for row in all_body
                   if any((str(row[0]), lc) not in done_pairs for lc in eff_langs)]
        # ★★★ **균형 순서 — 자료가 적은 책부터**(2026-09-04 사용자 지시
        #   「계속 창세기만, 계속 가나/가데스만 수집하면 안된다」).
        #   그전에는 `pericope_id` 순이라 **창세기부터** 돌았고, 실측
        #   창세기 25% · 출애굽기 14% · 모세오경이 **63%** 인데 **18권이
        #   0건**이었다(아가·애가·소선지서 대부분·고린도후서…).
        #   ⇒ 책마다 「자료가 있는 페리코프 비율」을 세어 **낮은 책부터** 돈다.
        #     자연히 안 돈 책이 앞에 오고, 한 책만 파고들지 않는다.
        #   ⚠ 책 안에서는 `pericope_id` 순 — 한 책을 잡으면 앞에서부터
        #     차례로 채우는 것이 사람이 보기에도 자연스럽다.
        #   ⏭ 이상적인 잣대는 **시도 횟수**지만 아직 기록이 없다(0.txt 4-1).
        #     시도 로그가 생기면 이 자리를 그것으로 바꾼다.
        # ⚠ **커버율 계산을 걷었다**(2026-09-11) — 차례가 「책+장 묶음」으로
        #   바뀌면서 아무도 안 읽는데 `all_body` 를 전수로 돌고 있었다.
        # ★★★ **잣대가 커버율에서 「시도 횟수」로 바뀌었다** (2026-09-04
        #   사용자 지시 — 「**결과는 중요하지 않다. 균형있게 수집하는지가
        #   중요하다**」). 시도 로그(`db_media_attempt`)가 생겨 이제 잴 수 있다.
        #   ⚠ 커버율(결과)로만 재면 **오바댜에 아랍어 설교가 있을 리 없는데도
        #     늘 1순위**가 된다 — 돌아도 안 나오는 자리를 영원히 다시 돈다.
        #   ⇒ 책의 순서 = **그 책 대상들의 평균 시도 횟수**가 적은 것부터.
        #     기록이 없으면 0회라 맨 앞에 온다(한 번도 안 돈 책이 먼저).
        #   ⚠ 커버율은 **동점을 가르는 두 번째 잣대**로만 남긴다.
        _att_cnt = {}
        try:
            _att.init(conn)
            _att_cnt = _att.counts(
                conn, 'CHAP' if str(unit or 'PERI').upper() == 'CHAP' else 'PERI',
                langs=list(eff_langs))
        except Exception as _ec:
            print('[시도 로그] %s' % _ec)

        def _tries(_row):
            """그 대상의 시도 횟수 합(선택한 언어 전부) — 적을수록 앞."""
            _k = ((int(_row[5]) * 1000 + int(_row[6]))
                  if str(unit or 'PERI').upper() == 'CHAP' else int(_row[0]))
            return sum(_att_cnt.get((_k, _lc), (0, '', 0))[0] for _lc in eff_langs)

        def _dry(_row):
            """선택한 언어가 **전부** 마른 자리인가(연속 0건) — 그러면 뒤로."""
            _k = ((int(_row[5]) * 1000 + int(_row[6]))
                  if str(unit or 'PERI').upper() == 'CHAP' else int(_row[0]))
            return all(_att_cnt.get((_k, _lc), (0, '', 0))[2] >= _att.DRY_STREAK
                       for _lc in eff_langs)

        # ★★★ **수집 차례를 고를 수 있다**(2026-09-11 사용자 「**책순서를
        #   제거하라** … 3안으로 **책+장을 단위로 해서 랜덤하게 집중되지 않게**
        #   수집하는 것을 추가하라」).
        #   ⚠⚠⚠ **옛 얼개는 묶음이 「책」이었다** — 그래서 1장짜리 오바댜와
        #     150장짜리 시편이 **한 바퀴에 같은 몫**을 받았다. 실측 장당
        #     **빌레몬서 15.0회 대 시편 0.2회(75배)**. 이제 묶음이 **책+장**이라
        #     시편은 한 바퀴에 150칸, 오바댜는 1칸이다.
        #   ⚠⚠ **동점을 책 번호·단락 번호로 가르지 않는다** — 그것이 숨은
        #     정경 순서였다(사용자 「책순서를 제거하라」). `arrange` 가 무작위로 가른다.
        _ord = _att.order_of(order or _att.ORDER_EVEN)
        _chap_mode = str(unit or 'PERI').upper() == 'CHAP'

        def _bucket(_row):
            """번갈아 뽑는 **묶음**.

            ★ `TRY` 는 **책**(옛 얼개) · `EVEN`·`RANDOM` 은 **책+장**.
              묶음이 곧 한 바퀴의 몫이라 **여기서 균등의 결이 정해진다.**
            ⚠ 장을 모르면 책으로 물러선다(조용히 안 뭉갠다).
            """
            if _ord == _att.ORDER_TRY:
                return (int(_row[5]), 0)
            try:
                return (int(_row[5]), int(_row[6]))
            except (TypeError, ValueError, IndexError):
                return (int(_row[5]), 0)

        pending = _att.arrange(pending, _ord, _tries, bucket_of=_bucket,
                               dry_of=_dry)
        total_remaining = len(pending)
        pericopes = pending[offset:offset + limit]
        force_langs = False
        if pericopes:
            _bn = {b: n for b, n in cur.execute(
                "SELECT book_code, full_name FROM book_names"
                " WHERE lang_code='KO'")}
            _uniq = []
            for _r in pericopes:
                if _r[5] not in _uniq:
                    _uniq.append(_r[5])
            # ★ 잣대가 바뀌었으니 **찍는 값도 바꾼다** — 묶음이 **책+장**이므로
            #   책이 아니라 **몇 권 · 몇 장**에 퍼졌는지를 보인다.
            _bk = {_bucket(_r) for _r in pericopes}
            print('수집 차례 [%s] — 묶음은 **책+장** · 이번 배치가 %d권 %d장에'
                  ' 퍼졌습니다: %s'
                  % (_att.ORDER_LABEL.get(_ord, _ord), len(_uniq), len(_bk),
                     ' · '.join('%s%s장' % (_bn.get(b, b), c)
                                for b, c in sorted(_bk)[:8])))

    print(f"검색 언어: {','.join(eff_langs)}")
    print(f"미처리 페리코프(선택언어 기준): {total_remaining:,}개 / 이번 배치: {len(pericopes)}개")
    print(f"모드: {'DRY-RUN (삽입 없음)' if dry_run else '실제 삽입'}")
    if YOUTUBE_AVAILABLE and YOUTUBE_API_KEYS:
        key_count = len(YOUTUBE_API_KEYS)
        _nl = max(1, len(eff_langs))
        est_units = len(pericopes) * _nl * YOUTUBE_UNITS_PER_SEARCH
        daily_cap = YOUTUBE_DAILY_QUOTA * key_count
        print(f"YouTube API 키: {key_count}개 / 일일 처리 가능: {daily_cap // (_nl * YOUTUBE_UNITS_PER_SEARCH):,} 페리코프")
        print(f"예상 API 사용량: {est_units:,} units")
    print()

    saved_count = 0
    api_calls = 0
    excluded_channels   = _load_excluded_channels(conn)
    blacklisted_vid_ids = _load_blacklisted_video_ids(conn)
    classify_sets = tax.load_classify_sets(conn)        # 언어별/공통 분류 키워드(1회 로드)
    exclude_kw_list = media_exclude.get_exclude_map()  # 언어별 표(1회 로드)
    offtopic_kw_list = media_exclude.get_offtopic_map()  # 언어별 표(1회 로드)

    for i, (peri_id, peri_code, start_vid, end_vid, title_en,
            bcode, chapter, verse_start) in enumerate(pericopes):

        b_en = bname.get('EN', {}).get(bcode, 'Unknown')
        b_ko = bname.get('KO', {}).get(bcode, '')
        ve_row = cur.execute("SELECT verse FROM bible_index WHERE verse_id=?", (end_vid,)).fetchone()
        verse_end = ve_row[0] if ve_row else verse_start
        title_en = title_en or f"{b_en} {chapter}:{verse_start}"

        if stop_event and stop_event.is_set():
            print("\n[중지] 사용자 요청으로 수집 중단.")
            break
        print(f"[{i+1}/{len(pericopes)}] pid={peri_id} {peri_code}")
        print(f"  제목: {title_en} | {b_ko} {chapter}:{verse_start}")

        if force_langs:
            langs_to_search = list(eff_langs)
        else:
            langs_to_search = [lc for lc in eff_langs
                               if (str(peri_id), lc) not in done_pairs]
        if not langs_to_search:
            print("  (선택 언어 모두 이미 수집됨 — skip)")
            continue
        peri_results = []

        for lang in langs_to_search:
            query = make_query(bname, bcode, chapter, verse_start, verse_end,
                               title_en, lang, unit=unit)
            print(f"  [{lang}] {query}")

            if lang == 'KO' and NAVER_CLIENT_ID:
                results = naver_search(query, display=5)
                api_calls += 1
            elif YOUTUBE_API_KEYS:
                results = youtube_search(query, lang, max_results=SEARCH_PAGE,
                                         classify_sets=classify_sets)
                api_calls += 1
                time.sleep(0.3)
            else:
                print("    [!] API 키 없음 — 실제 검색 불가. --dry-run 모드 시뮬레이션.")
                results = []

            # 수집 제외: 채널 블랙리스트 + video_id 블랙리스트
            if excluded_channels or blacklisted_vid_ids:
                import re as _re
                def _vid_id(u):
                    m = _re.search(r'v=([\w-]+)', u)
                    return m.group(1) if m else ''
                results = [r for r in results
                           if not chan_excluded(r.get('channel', ''),
                                                excluded_channels)
                           and _vid_id(r.get('url', '')) not in blacklisted_vid_ids]

            # 스코어링 및 필터
            for r in results:
                r['score'] = score_result(r, b_en, b_ko, chapter, title_en)
            results = sorted(results, key=lambda x: x['score'], reverse=True)
            results = [r for r in results if r['score'] >= MIN_SCORE][:3]

            # 다국어 폴백: 결과 없으면 EN 사용 표시
            if lang in LANG_FALLBACK_TO_EN and len(results) < MIN_RESULTS_FOR_LANG:
                print(f"    → {lang} 결과 부족 ({len(results)}개) → EN 폴백 사용 예정")

            for r in results:
                tag = f"[{r['score']:+d}★]" if r['score'] >= 10 else f"[{r['score']:+d}]"
                print(f"    {tag} {r['title'][:65]}")
                print(f"         {r['url']}")
                peri_results.append(r)
            # ★★★ **시도를 남긴다** (2026-09-04 사용자 지시 — 「수집대상별
            #   **수집을 시도한 횟수의 분포**를 볼 수 있어야 한다. 결과는
            #   중요하지 않다. **균형있게 수집하는지가 중요하다**」).
            #   ⚠ **결과가 0이어도 남긴다** — 그것이 이 기록의 존재 이유다.
            #     그래야 0건인 자리가 「아직 안 돌았다」인지 「돌았는데 없다」
            #     인지 갈린다.
            #   ⚠ 좌표에 맞춰 열쇠를 고른다 — 장 축이면 `bcode*1000+chapter`
            #     (§3-1 `verse_tier.chap_key` 와 같은 규칙), 아니면 페리코프 번호.
            if not dry_run:
                try:
                    _att.log(conn,
                             'CHAP' if str(unit or 'PERI').upper() == 'CHAP'
                             else 'PERI',
                             (int(bcode) * 1000 + int(chapter))
                             if str(unit or 'PERI').upper() == 'CHAP'
                             else peri_id,
                             lang, len(results))
                except Exception as _ea:
                    print('    [시도 로그] %s' % _ea)

        # 저장
        if peri_results:
            if not dry_run:
                _n_off, _off_ex = 0, []
                for r in peri_results:
                    action = insert_media(conn, r, peri_id, dry_run=False,
                                          exclude_kw_list=exclude_kw_list,
                                          offtopic_kw_list=offtopic_kw_list)
                    if isinstance(action, dict) \
                            and action.get('action') == 'SKIP_OFFTOPIC':
                        _n_off += 1
                        if len(_off_ex) < 3:
                            _off_ex.append('%s ← 「%s」'
                                           % (action['title'], action['kw']))
                conn.commit()
                _kept = len(peri_results) - _n_off
                saved_count += _kept
                print(f"  → {_kept}개 저장 (is_active=0, 검토 후 활성화)")
                # ⚠ **조용히 버리지 않는다** — 몇 건을 왜 걸렀는지 말한다.
                #   잘못 걸러도 이 줄을 보고 안다.
                if _n_off:
                    print(f"  → 본문과 무관해 안 받음 {_n_off}개")
                    for _e in _off_ex:
                        print(f"       {_e}")
            else:
                print(f"  → [DRY] {len(peri_results)}개 저장 예정")
        else:
            print(f"  → 결과 없음 (최소 점수 {MIN_SCORE} 미달 또는 API 키 없음)")
        print()

        # 할당량 관리: 100 searches마다 잠깐 대기
        if api_calls > 0 and api_calls % 80 == 0 and not dry_run:
            remaining_quota = YOUTUBE_DAILY_QUOTA - api_calls * YOUTUBE_UNITS_PER_SEARCH
            if remaining_quota < 1000:
                print(f"\n⚠ YouTube API 할당량 거의 소진 ({remaining_quota} units 남음). 종료.")
                break
            print(f"  ⏸ 할당량 관리 대기 (사용: {api_calls * 100} units)")
            time.sleep(2)

    print("=" * 60)
    print(f"완료: {i+1}개 처리 / {saved_count}개 저장 / API {api_calls}회 호출")
    if not dry_run:
        print(f"저장된 항목은 is_active=0 (미활성) 상태입니다.")
        print(f"검토 후 활성화: UPDATE sys_media_asset SET is_active=1 WHERE sort_order=500;")
    conn.close()


# ── 검토 도우미: 수집 결과 조회 ───────────────────────────────────────────────
def show_collected(peri_id=None, lang=None):
    conn = sqlite3.connect(DB)
    cur = conn.cursor()
    where = "WHERE ml.link_type=?"
    params = [media_link.lt('PERICOPE')]
    if peri_id:
        where += " AND ml.target_id=?"
        params.append(media_link.key_int(peri_id))
    if lang:
        where += " AND ma.lang_code=?"
        params.append(lang)
    rows = cur.execute(f"""
        SELECT ma.media_id, ml.target_id, ma.lang_code, ma.media_type,
               ma.title, ma.url, ma.is_active
        FROM {media_link.TBL} ml
        JOIN sys_media_asset ma ON ma.media_id=ml.clicked_id
        {where}
        ORDER BY ml.target_id, ma.lang_code, ma.sort_order
        LIMIT 100
    """, params).fetchall()  # status-ok: 관리자 검토 목록 — 미검토·가린 것도 보여야 심사한다(is_active 를 칸으로 낸다)
    print(f"수집 결과 {len(rows)}건:")
    for r in rows:
        active = "✓" if r[6] else "○"
        print(f"  {active} pid={r[1]} [{r[2]}/{r[3]}] {r[4][:60]}")
        print(f"     {r[5]}")
    conn.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='페리코프별 미디어 URL 수집 로봇')
    parser.add_argument('--run', action='store_true',
                        help='실제 DB 삽입 실행 (없으면 dry-run)')
    parser.add_argument('--limit', type=int, default=10,
                        help='처리할 페리코프 수 (기본: 10)')
    parser.add_argument('--lang', type=str, default=None,
                        help='특정 언어만 검색 (EN/KO/ZH/JA 등)')
    parser.add_argument('--offset', type=int, default=0,
                        help='시작 페리코프 위치 (재개용)')
    parser.add_argument('--regen', type=int, default=None,
                        help='특정 pericope_id 재수집')
    parser.add_argument('--show', action='store_true',
                        help='수집된 결과 조회')
    parser.add_argument('--show-peri', type=int, default=None,
                        help='특정 페리코프 결과 조회')
    args = parser.parse_args()

    if args.show or args.show_peri:
        show_collected(peri_id=args.show_peri, lang=args.lang)
    else:
        run(
            limit=args.limit,
            dry_run=not args.run,
            lang_filter=args.lang,
            offset=args.offset,
            regen_peri_id=args.regen,
        )
