# -*- coding: utf-8 -*-
"""db_media_autoapprove.py — **확실한 것만 자동 승인** (2026-09-06 신설·영구).

★★★ 왜 (사용자 지시): 「미검토 건을 네가 처리하라. **확실한 것을 우선
  승인하라**」 · RSS 수집을 **매일**로 바꾸면서(주기 1일) 하루 유입이
  실측 **90~140편**이 되므로, 사람이 다 보면 대기줄이 다시 쌓인다.

★★★ **「확실한 것」을 표본으로 퉁치지 않는다 — 기계가 하나하나 확인한다.**
  잣대 = **제목에서 읽은 구절의 시작이 링크 시작과 같은가**
  (`db_media_range.read` ↔ `MEDI_VERS.target_id`).
  실측 검증 표본 120건 **일치율 95%** — 어긋난 5건 중 4건은 「구간이 좁다」
  (시작은 맞다)이고 **진짜 오연결은 1건**이었다.

    T1  제목 좌표 일치 + 용어 연결도 있음   ← 두 축이 서로를 뒷받침한다
    T2  제목 좌표 일치 (용어 연결 없음)
    ─────────────────────────────────────
    T3  용어 연결만 (제목에 좌표 없음)      ← **안 건드린다**
    NO  근거 약함 · EX 제외 채널           ← 안 건드린다

⚠⚠ **T3 를 자동 승인하지 않는다** — §195차 「엘」 사건이 그 부류다. 엔티티
  이름 문자열 매칭만으로 `chapter` 속 `Er` 같은 오연결이 **2,716줄** 났다.
  사람이 봐야 한다.

⚠ **승인 = 연결**(§194차) — `is_active=1` 과 **보관함 대기표 걷기**를 함께.
  화면(`panel_media._approve_ids`)과 **같은 두 걸음**이다.
⚠ **제외 채널은 절대 승인하지 않는다**(`media_exclude`).
⚠ **되돌릴 수 있다** — 승인한 번호를 `sys_config` 에 남기고 감사 트리거가
  UPDATE 를 전부 기록한다(§10-1).

    python db_media_autoapprove.py --selftest   (의무)
    python db_media_autoapprove.py --check      몇 건이 대상인지만 (안 쓴다)
    python db_media_autoapprove.py --apply      실제 승인
    python db_media_autoapprove.py --undo       마지막 자동 승인 되돌리기
    python db_media_autoapprove.py --verse-check  구절 연결이 있는 미검토 수
    python db_media_autoapprove.py --verse-apply  ★ 구절 연결이 있으면 전부 승인
    python db_media_autoapprove.py --verse-undo   그 승인을 되돌리기

★★★ **구절 연결 승인**(2026-09-09 사용자 「현재 구절 연결된 것들을 조사하라.
  대부분 정상일 것이다. **구절연결만 승인하라**. 그리고 용어 연결을 따로 검토하자」).
  T1·T2 는 제목 좌표가 링크와 **같아야** 했다. 실측 미검토 1,474건 중 제목에
  좌표가 없는 것(설명문에서 읽음)이 523 — 그것도 구절 연결이 있으면 승인한다.
  ⚠ 먼저 `db_media_badlink --ranges --apply` 로 약명 오독 구간(202건)을 걷고 돈다.
  ⚠ 제외 채널·휴면은 그대로 안 건드린다. 승인은 영상 단위라 그 영상의 **살아 있는
    용어 연결(LIVE)도 함께 나간다** — 후보(PEND)는 안 나간다.
"""
import io
import json
import sys
import time

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

LOG_KEY = 'MEDIA_AUTOAPPROVE_LAST'
LOG_KEY_V = 'MEDIA_VERSEAPPROVE_LAST'
LOG_KEY_LS = 'MEDIA_LIVESVC_APPROVE_LAST'
LOG_KEY_T = 'MEDIA_TERMAPPROVE_LAST'
LOG_KEY_CS = 'MEDIA_CHURCHSERMON_APPROVE_LAST'
#: 「설교 중심 채널」 문턱 — 그 채널이 올린 영상 중 설교 유형의 몫.
#:   실측(2026-09-16) 실황 보관함 545편의 채널 118곳 중 이 문턱을 넘는 채널의 영상이 521편.
LIVE_SERMON_SHARE = 0.7
#: 한 번에 승인할 최대 건수. ⚠ 처음 한 번은 밀린 것이 많으므로 넉넉히.
MAX_PER_RUN = 3000


def registered_channels(conn):
    """등록 채널(살아 있는 것) → (id 집합, 소문자 이름 집합)."""
    try:
        ids = {r[0] for r in conn.execute(
            "SELECT channel_ext_id FROM sys_media_channel"
            " WHERE COALESCE(record_status,'LIVE')='LIVE' AND channel_ext_id IS NOT NULL")}
        names = {(r[0] or '').lower() for r in conn.execute(
            "SELECT channel_name FROM sys_media_channel"
            " WHERE COALESCE(record_status,'LIVE')='LIVE'")}
        names.discard('')
        return ids, names
    except Exception:
        return set(), set()


def classify(conn, limit=None):
    """미검토를 근거 세기로 가른다 → {'T1':[…], 'T2':[…], 'T3':n, 'NO':n, 'EX':n}."""
    import db_media_range as MR
    import media_exclude as MX
    import db_media_linkcheck as LC
    # ⚠⚠ **휴면(점검 실패)은 미검토가 아니다**(2026-09-08) — 같은 `is_active=0`
    #   이라 이 조건이 없으면 죽은 영상을 제목이 맞다고 다시 승인한다.
    LC.ensure(conn)
    excl = MX.excluded_channels(conn)
    reg_ids, reg_names = registered_channels(conn)
    rows = conn.execute(
        "SELECT a.media_id, a.title,"
        " MIN(CASE WHEN l.link_type='MEDI_VERS' THEN l.target_id END) sv,"
        " SUM(CASE WHEN l.link_type='MEDI_ENTI' THEN 1 ELSE 0 END) ne,"
        " COALESCE(json_extract(a.description,'$.channel'),'') ch,"
        " COALESCE(json_extract(a.description,'$.channel_id'),'') chid"
        "  FROM sys_media_asset a"
        "  JOIN sys_link_asset l ON l.clicked_id=a.media_id"
        "   AND l.link_type IN ('MEDI_VERS','MEDI_ENTI')"
        "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
        " WHERE a.is_active=0 AND COALESCE(a.record_status,'LIVE')='LIVE'"
        "   AND " + LC.not_dormant('a') +
        " GROUP BY a.media_id").fetchall()
    out = {'T1': [], 'T2': [], 'T2R': [], 'T3': 0, 'NO': 0, 'EX': 0}
    for mid, ti, sv, ne, ch, chid in rows:
        if MX.chan_excluded(ch, excl):
            out['EX'] += 1
            continue
        starts = {g[1] for g in MR.read(conn, ti or '')}
        if sv is not None and sv in starts:
            out['T1' if ne else 'T2'].append(mid)
        elif sv is not None and (chid in reg_ids or (ch or '').lower() in reg_names):
            # ★★★ T2R(2026-09-16 사용자 「교회의 공식 채널일 경우 자동승인 해도 위험하지
            #   않을 것이다」) — **등록 채널**이 올린 영상에 구절 연결(LIVE)이 있으면 좌표가
            #   제목이 아니라 설명문·책 이름(전체 낭독)에서 왔어도 승인한다. 채널은 이미
            #   사람이 심사해 등록한 것이고, 연결이 있으니 「승인=연결」 원칙에도 맞는다.
            #   실측 등록 채널 · 구절 연결 · 미승인 = 제목 좌표 7,009 + 설명문 좌표 3,385.
            out['T2R'].append(mid)
        elif ne:
            out['T3'] += 1
        else:
            out['NO'] += 1
    if limit:
        n = int(limit)
        out['T1'] = out['T1'][:n]
        out['T2'] = out['T2'][:max(0, n - len(out['T1']))]
        out['T2R'] = out['T2R'][:max(0, n - len(out['T1']) - len(out['T2']))]
    return out


def approve(conn, ids, batch=400):
    """`is_active=1` + 보관함 대기표 걷기. → 처리 건수.

    ⚠ **두 걸음이 한 짝이다**(§194차) — 연결이 정해졌으니 보관함에서 뺀다.
    """
    if not ids:
        return 0
    done = 0
    for i in range(0, len(ids), batch):
        ch = ids[i:i + batch]
        ph = ','.join('?' * len(ch))
        conn.execute("UPDATE sys_media_asset SET is_active=1"
                     " WHERE media_id IN (%s)" % ph, ch)
        conn.execute("UPDATE sys_media_pending SET record_status='HIDE'"
                     " WHERE media_id IN (%s)" % ph, ch)
        conn.commit()
        done += len(ch)
    return done


def run(conn, limit=MAX_PER_RUN, dry=False, log=print):
    c = classify(conn, limit)
    ids = c['T1'] + c['T2'] + c['T2R']
    log('  대상 — T1 %d · T2 %d · 등록채널 T2R %d = **%d건**  (안 건드림: T3 %d ·'
        ' 근거약함 %d · 제외채널 %d)' % (len(c['T1']), len(c['T2']), len(c['T2R']),
                                      len(ids), c['T3'], c['NO'], c['EX']))
    if dry or not ids:
        return 0, c
    n = approve(conn, ids)
    # ⚠ **되돌릴 수 있게 남긴다** — 감사 트리거와 이중으로.
    conn.execute("INSERT OR REPLACE INTO sys_config(config_key, config_val)"
                 " VALUES(?,?)",
                 (LOG_KEY, json.dumps(
                     {'when': time.strftime('%Y-%m-%d %H:%M'),
                      't1': c['T1'], 't2': c['T2'], 't2r': c['T2R']}, ensure_ascii=False)))
    conn.commit()
    log('  **%d건 승인**' % n)
    return n, c


def verse_ids(conn):
    """구절 연결(LIVE)이 하나라도 있는 미검토 영상 — 제외 채널·휴면은 뺀다."""
    import media_exclude as MX
    import db_media_linkcheck as LC
    LC.ensure(conn)
    excl = MX.excluded_channels(conn)
    out = []
    for mid, ch in conn.execute(
            "SELECT a.media_id, COALESCE(json_extract(a.description,'$.channel'),'')"
            "  FROM sys_media_asset a"
            " WHERE a.is_active=0 AND COALESCE(a.record_status,'LIVE')='LIVE'"
            "   AND " + LC.not_dormant('a') +
            "   AND EXISTS(SELECT 1 FROM sys_link_asset l WHERE l.clicked_id=a.media_id"
            "              AND l.link_type='MEDI_VERS' AND COALESCE(l.record_status,'LIVE')='LIVE')"
            " ORDER BY a.media_id"):
        if MX.chan_excluded(ch, excl):
            continue
        out.append(mid)
    return out


def run_verse(conn, dry=False, log=print):
    ids = verse_ids(conn)
    log('  구절 연결이 있는 미검토 %d건' % len(ids))
    if dry or not ids:
        return 0
    n = approve(conn, ids)
    conn.execute("INSERT OR REPLACE INTO sys_config(config_key, config_val) VALUES(?,?)",
                 (LOG_KEY_V, json.dumps({'when': time.strftime('%Y-%m-%d %H:%M'), 'ids': ids})))
    conn.commit()
    log('  **%d건 승인**(구절 연결 기준)' % n)
    return n


def church_sermon_ids(conn, share=LIVE_SERMON_SHARE, box_only=False):
    """**교회 공식 채널의 설교** → media_id 목록 (2026-09-17 · 사용자 「교회의 공식 채널이고
    설교 중심이라면 자동승인 해도 위험하지 않을 것이다」).

    잣대 다섯 — ⓐ 등록 채널 ⓑ 채널 이름이 스스로 교회·사역임을 말한다(`db_channel_vet.NAME_WORDS`)
      ⓒ 그 채널 영상의 **설교 몫 ≥ `share`** ⓓ 이 영상의 유형이 SERMON ⓔ 제외 채널·휴면·쇼츠가 아니다.
    ★ `box_only=True` 면 **예배 실황 보관함**(`hint_kind='LIVESVC'`)의 것만 — 옛 좁은 문이다.
    ⚠ **연결이 없어도 승인하는 문**이다(§194차 「승인=연결」의 예외). 근거는 **연결이 아니라 채널**이고,
      그래서 잣대가 채널 쪽에 다섯이나 있다. 구절 화면에는 연결이 없으니 안 뜬다 —
      최신 목록·검색·채널로만 나간다.
    ⚠ 찬양(WORSHIP)은 안 한다 — 찬양의 「연결」은 곡이고 그것은 찬양 수집기 몫이다."""
    import json
    import media_exclude as MX
    import db_channel_vet as CV
    import db_media_linkcheck as LC
    LC.ensure(conn)
    reg_ids, reg_names = registered_channels(conn)
    excl = MX.excluded_channels(conn)
    words = tuple(w.lower() for w in CV.NAME_WORDS)
    cache = {}

    def sermon_share(name):
        if name not in cache:
            r = conn.execute(
                "SELECT SUM(COALESCE(media_type,'')='SERMON'), COUNT(*) FROM sys_media_asset"
                " WHERE COALESCE(record_status,'LIVE')='LIVE'"
                "   AND json_extract(description,'$.channel')=?", (name,)).fetchone()
            cache[name] = (r[0] or 0) / r[1] if r and r[1] else 0.0
        return cache[name]
    sql = ("SELECT a.media_id, a.media_type, a.description, a.title, a.lang_code FROM sys_media_asset a"
           + ("  JOIN sys_media_pending p ON p.media_id=a.media_id"
              "   AND p.hint_kind='LIVESVC' AND COALESCE(p.record_status,'LIVE')='LIVE'" if box_only else "")
           + " WHERE a.is_active=0 AND COALESCE(a.record_status,'LIVE')='LIVE'"
             "   AND a.description LIKE '{%' AND " + LC.not_dormant('a') +
           " ORDER BY a.media_id")
    short = set()
    try:
        short = {r[0] for r in conn.execute(
            "SELECT media_id FROM sys_media_check WHERE duration IS NOT NULL AND duration<=?",
            (LC.SHORT_SEC,))}
    except Exception:
        pass
    out = []
    for mid, mt, desc, title, lang in conn.execute(sql):
        if (mt or '') != 'SERMON' or mid in short:
            continue
        # ⚠ **채널을 믿어도 제목은 본다**(2026-09-17 표본에서 「Quran surah 2:245-251」이 걸렸다 —
        #   기독교 변증 채널의 정당한 영상일 수 있으나 **자동으로 내보낼 것은 아니다**).
        #   콘텐츠 거르는 말(⚠ 층)은 막는 문이 아니라 **사람이 보라는 표식**이라 여기서만 쓴다.
        if MX.match_exclude(title or '', lang=lang):
            continue
        try:
            j = json.loads(desc or '{}')
        except Exception:
            continue
        ch = j.get('channel') or ''
        if not ((j.get('channel_id') or '') in reg_ids or ch.lower() in reg_names):
            continue
        if MX.chan_excluded(ch, excl):
            continue
        low = ch.lower()
        if not any(w in low for w in words):
            continue
        if sermon_share(ch) < share:
            continue
        out.append(mid)
    return out


def run_church_sermon(conn, dry=False, log=print):
    """교회 설교 채널 신뢰 승인 → 승인 수. `--church-undo` 로 되돌린다."""
    ids = church_sermon_ids(conn)
    log('  교회 이름 · 설교 중심 채널 · 설교 유형 = **%d편**' % len(ids))
    if dry or not ids:
        return 0
    n = approve(conn, ids)
    conn.execute("INSERT OR REPLACE INTO sys_config(config_key, config_val) VALUES(?,?)",
                 (LOG_KEY_CS, json.dumps({'when': time.strftime('%Y-%m-%d %H:%M'), 'ids': ids})))
    conn.commit()
    log('  **%d편 승인**(교회 설교 채널)' % n)
    return n


def undo_church_sermon(conn, log=print):
    r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?", (LOG_KEY_CS,)).fetchone()
    if not r or not r[0]:
        log('  되돌릴 기록이 없습니다.')
        return 0
    ids = json.loads(r[0]).get('ids') or []
    n = 0
    for i in range(0, len(ids), 400):
        ch = ids[i:i + 400]
        n += conn.execute("UPDATE sys_media_asset SET is_active=0 WHERE media_id IN (%s)"
                          % ','.join('?' * len(ch)), ch).rowcount
        conn.commit()
    log('  교회 설교 채널 승인분 %d편을 되돌렸습니다.' % n)
    return n


def live_service_ids(conn, share=LIVE_SERMON_SHARE):
    """예배 실황 보관함(`hint_kind='LIVESVC'`)에서 **자동승인해도 되는 것** → media_id 목록.

    ★★★ 잣대(2026-09-16 사용자 「교회 공식 채널이고 설교 중심이라면 자동승인 해도 좋다」) —
      ⓐ 등록 채널(살아 있는 것) ⓑ 채널 이름이 스스로 교회·사역임을 말한다
      (`db_channel_vet.NAME_WORDS`) ⓒ 그 채널 영상의 설교(SERMON) 몫이 `share` 이상
      ⓓ 이 영상의 유형이 SERMON ⓔ 제외 채널이 아니다.
    ⚠ 구절 연결이 없는 채로 승인하는 **유일한 문**이다 — 사용자에게는 최신 목록·검색으로만
      나간다(구절 화면에는 연결이 있어야 뜬다). 찬양(WORSHIP) 유형은 안 한다 — 곡 연결이
      찬양의 「연결」이고 그것은 찬양 수집기 몫이다.
    실측 545편 중 513편 통과 · 탈락 32(찬양 유형 24 · 이름 신호 없음 8).
    ⚠ 2026-09-17 부터 **`church_sermon_ids(box_only=True)` 한 줄**이다 — 잣대가 두 벌이면 갈린다."""
    return church_sermon_ids(conn, share, box_only=True)


def run_live_service(conn, dry=False, log=print):
    """예배 실황 보관함 자동승인(`live_service_ids`) → 승인 수. `--live-undo` 로 되돌린다."""
    ids = live_service_ids(conn)
    log('  예배 실황 보관함 — 교회 이름 · 설교 중심 채널 · 설교 유형 = **%d건**' % len(ids))
    if dry or not ids:
        return 0
    n = approve(conn, ids)
    conn.execute("INSERT OR REPLACE INTO sys_config(config_key, config_val) VALUES(?,?)",
                 (LOG_KEY_LS, json.dumps({'when': time.strftime('%Y-%m-%d %H:%M'), 'ids': ids})))
    conn.commit()
    log('  **%d건 승인**(실황 보관함)' % n)
    return n


def undo_live_service(conn, log=print):
    r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?", (LOG_KEY_LS,)).fetchone()
    if not r or not r[0]:
        log('  되돌릴 기록이 없습니다.')
        return 0
    ids = json.loads(r[0]).get('ids') or []
    n = 0
    for i in range(0, len(ids), 400):
        ch = ids[i:i + 400]
        n += conn.execute("UPDATE sys_media_asset SET is_active=0 WHERE media_id IN (%s)"
                          % ','.join('?' * len(ch)), ch).rowcount
        conn.commit()
    log('  실황 보관함 승인분 %d건을 되돌렸습니다.' % n)
    return n


def term_ids(conn):
    """**용어 연결이 살아 있는 미승인** → media_id 목록 (2026-09-17 사용자 「연결심사를 완료하고」).

    ★★★ 이 문이 안전한 까닭은 **살아 있는 용어 연결의 뜻이 바뀌었기 때문**이다 —
      `db_term_link_audit` 가 후보 줄을 판정해 **제목에 이름이 있고 지금 규칙으로도 걸리는 것만**
      `LIVE` 로 올린다(설명문 근거·붙박이 소개문은 후보로 남거나 내려간다).
      실측 근거 — 용어 연결 전수에서 **제목 근거 7,867건 중 99%가 살아남았고 사람이 뗀 것은 0**,
      설명문 근거 29,742건은 살아남은 것이 **0.3%** 였다.
    ⚠ §195차 「엘」 사건이 이 자리다 — 그때는 **설명문·짧은 이름**이 문제였고, 그 둘을 거른 뒤의
      제목 근거만 쓴다. 제외 채널·휴면은 뺀다."""
    import media_exclude as MX
    import db_media_linkcheck as LC
    LC.ensure(conn)
    excl = MX.excluded_channels(conn)
    out = []
    for mid, ch in conn.execute(
            "SELECT DISTINCT a.media_id, COALESCE(json_extract(a.description,'$.channel'),'')"
            "  FROM sys_media_asset a"
            "  JOIN sys_link_asset l ON l.clicked_id=a.media_id AND l.link_type='MEDI_ENTI'"
            "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
            " WHERE a.is_active=0 AND COALESCE(a.record_status,'LIVE')='LIVE'"
            "   AND " + LC.not_dormant('a') + " ORDER BY a.media_id"):
        if MX.chan_excluded(ch, excl):
            continue
        out.append(mid)
    return out


def run_term(conn, dry=False, log=print):
    """용어 연결 승인 → 승인 수. `--term-undo` 로 되돌린다."""
    ids = term_ids(conn)
    log('  용어 연결(제목 근거)이 살아 있는 미승인 **%d편**' % len(ids))
    if dry or not ids:
        return 0
    n = approve(conn, ids)
    conn.execute("INSERT OR REPLACE INTO sys_config(config_key, config_val) VALUES(?,?)",
                 (LOG_KEY_T, json.dumps({'when': time.strftime('%Y-%m-%d %H:%M'), 'ids': ids})))
    conn.commit()
    log('  **%d편 승인**(용어 연결)' % n)
    return n


def undo_term(conn, log=print):
    r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?", (LOG_KEY_T,)).fetchone()
    if not r or not r[0]:
        log('  되돌릴 기록이 없습니다.')
        return 0
    ids = json.loads(r[0]).get('ids') or []
    n = 0
    for i in range(0, len(ids), 400):
        ch = ids[i:i + 400]
        n += conn.execute("UPDATE sys_media_asset SET is_active=0 WHERE media_id IN (%s)"
                          % ','.join('?' * len(ch)), ch).rowcount
        conn.commit()
    log('  용어 연결 승인분 %d편을 되돌렸습니다.' % n)
    return n


def undo_verse(conn, log=print):
    r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?", (LOG_KEY_V,)).fetchone()
    if not r or not r[0]:
        log('  되돌릴 기록이 없습니다.')
        return 0
    ids = json.loads(r[0]).get('ids') or []
    n = 0
    for i in range(0, len(ids), 400):
        ch = ids[i:i + 400]
        n += conn.execute("UPDATE sys_media_asset SET is_active=0 WHERE media_id IN (%s)"
                          % ','.join('?' * len(ch)), ch).rowcount
        conn.commit()
    log('  구절 연결 승인분 %d건을 되돌렸습니다.' % n)
    return n


def undo(conn, log=print):
    """마지막 자동 승인을 되돌린다(`is_active=0`).

    ⚠ **보관함 대기표는 안 되살린다** — 그 자산이 그 사이에 손으로 다뤄졌을
      수 있고, 대기표를 잘못 되살리면 이미 정리한 것이 다시 줄에 선다.
    """
    r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                     (LOG_KEY,)).fetchone()
    if not r or not r[0]:
        log('  되돌릴 기록이 없습니다.')
        return 0
    d = json.loads(r[0])
    ids = (d.get('t1') or []) + (d.get('t2') or []) + (d.get('t2r') or [])
    n = 0
    for i in range(0, len(ids), 400):
        ch = ids[i:i + 400]
        ph = ','.join('?' * len(ch))
        n += conn.execute("UPDATE sys_media_asset SET is_active=0"
                          " WHERE media_id IN (%s)" % ph, ch).rowcount
        conn.commit()
    log('  %s 승인분 %d건을 되돌렸습니다.' % (d.get('when', '?'), n))
    return n


# ── selftest ─────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(n, c, e=''):
        ok[1] += 1
        ok[0] += 1 if c else 0
        print('  %s %-50s %s' % ('OK  ' if c else 'FAIL', n, e))

    print('=== db_media_autoapprove selftest')
    import sqlite3
    import db_media_range as MR
    import media_exclude as MX
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY, title TEXT,
        description TEXT, is_active INT, record_status TEXT, media_type TEXT, lang_code TEXT);
      CREATE TABLE sys_link_asset(clicked_id INT, target_id INT, end_id INT,
        link_type TEXT, record_status TEXT);
      CREATE TABLE sys_media_pending(media_id INT, record_status TEXT, hint_kind TEXT);
      CREATE TABLE sys_config(config_key TEXT PRIMARY KEY, config_val TEXT);
      CREATE TABLE sys_media_channel(channel_name TEXT, channel_ext_id TEXT, record_status TEXT);
    """)
    c.execute("INSERT INTO sys_media_channel VALUES('등록교회','UCREG','LIVE')")
    A = [(1, '창세기 1장 1절 강해', '{"channel":"좋은채널"}'),
         (2, '요한복음 3:16 설교', '{"channel":"좋은채널"}'),
         (3, '오늘의 은혜', '{"channel":"좋은채널"}'),
         (4, '아무 말', '{"channel":"좋은채널"}'),
         (5, '창세기 1장 1절 강해', '{"channel":"나쁜채널"}'),
         (6, '마태복음 5장 강해', '{"channel":"좋은채널"}'),
         (7, '주일예배 설교', '{"channel":"등록교회","channel_id":"UCREG"}'),   # T2R
         (8, '주일예배 설교', '{"channel":"딴교회"}')]                          # 미등록 → NO
    for mid, ti, d in A:
        c.execute("INSERT INTO sys_media_asset VALUES(?,?,?,0,'LIVE','SERMON','KO')",
                  (mid, ti, d))
    L = [(1, 100, 'MEDI_VERS'), (1, 7, 'MEDI_ENTI'),      # T1
         (2, 200, 'MEDI_VERS'),                            # T2
         (3, 9, 'MEDI_ENTI'),                              # T3
         (5, 100, 'MEDI_VERS'),                            # 제외 채널
         (6, 999, 'MEDI_VERS'),                            # 좌표 어긋남
         (7, 500, 'MEDI_VERS'),                            # 설명문에서 온 좌표 · 등록 채널
         (8, 500, 'MEDI_VERS')]                            # 같은 꼴 · 미등록
    for a, b, ty in L:
        c.execute("INSERT INTO sys_link_asset VALUES(?,?,NULL,?,'LIVE')",
                  (a, b, ty))
    c.execute("INSERT INTO sys_media_pending VALUES(1,'LIVE',NULL)")
    c.execute("INSERT INTO sys_media_pending VALUES(2,'LIVE',NULL)")
    c.commit()

    r_read, r_ex = MR.read, MX.excluded_channels
    MR.read = lambda conn, ti: (
        [(1, 100, 110, 'VERSE')] if '창세기 1장 1절' in ti else
        [(43, 200, 200, 'VERSE')] if '요한복음 3:16' in ti else
        [(40, 300, 320, 'VERSE')] if '마태복음 5장' in ti else [])
    MX.excluded_channels = lambda conn: {'나쁜채널'}
    try:
        got = classify(c)
        t('★★★ **제목 좌표가 링크와 맞고 용어도 있으면 T1**', got['T1'] == [1], got['T1'])
        t('★★ 좌표만 맞으면 T2', got['T2'] == [2], got['T2'])
        t('★★★ **용어만 있으면 안 건드린다**(§195차 「엘」 사건)', got['T3'] == 1)
        t('★★★ **제외 채널은 절대 승인 안 한다**', got['EX'] == 1
          and 5 not in got['T1'] + got['T2'])
        t('★★ **좌표가 어긋나면 안 승인한다**(마태 300~320 ↔ 링크 999)',
          6 not in got['T1'] + got['T2'] and got['NO'] == 2, got['NO'])
        t('★★★ **등록 채널 + 구절 연결이면 T2R**(제목에 좌표가 없어도 · 2026-09-16)',
          got['T2R'] == [7], got['T2R'])
        t('  같은 꼴이라도 미등록 채널이면 안 승인한다', 8 not in got['T2R'] and 8 not in got['T2'])

        n, _ = run(c, dry=True)
        t('★ --check 는 안 쓴다',
          n == 0 and c.execute('SELECT COUNT(*) FROM sys_media_asset'
                               ' WHERE is_active=1').fetchone()[0] == 0)

        n, _ = run(c)
        t('★★ 3건 승인(T1·T2·T2R)', n == 3, n)
        t('★★ **보관함 대기표를 함께 걷는다**(§194차 승인=연결)',
          c.execute("SELECT COUNT(*) FROM sys_media_pending"
                    " WHERE COALESCE(record_status,'LIVE')='LIVE'"
                    ).fetchone()[0] == 0)
        t('  제외 채널은 그대로 미검토',
          c.execute('SELECT is_active FROM sys_media_asset'
                    ' WHERE media_id=5').fetchone()[0] == 0)

        n2, _ = run(c)
        t('★★★ **두 번 돌려도 안 는다**(멱등 — 이미 승인된 것은 대상이 아니다)',
          n2 == 0, n2)

        undo(c, log=lambda *_a: None)
        t('★★ **되돌릴 수 있다**',
          c.execute('SELECT COUNT(*) FROM sys_media_asset'
                    ' WHERE is_active=1').fetchone()[0] == 0)
        t('  ⚠ 보관함 대기표는 안 되살린다(손으로 다뤄졌을 수 있다)',
          c.execute("SELECT COUNT(*) FROM sys_media_pending"
                    " WHERE COALESCE(record_status,'LIVE')='LIVE'"
                    ).fetchone()[0] == 0)
        t('  기록이 없으면 조용히 0', undo(sqlite3.connect(':memory:').__enter__()
                                    if False else _empty(), log=lambda *_a: None) == 0)
        # ── 구절 연결 승인(2026-09-09) — 제목 좌표가 안 맞아도 구절 연결이 있으면
        try:
            c.execute("UPDATE sys_media_asset SET is_active=0")
            vi = verse_ids(c)
            t('★★★ 구절 연결이 있는 미검토 = 1·2·6·7·8(좌표 어긋남도) · 제외 채널 5 는 뺀다 · 용어만 3 은 뺀다',
              vi == [1, 2, 6, 7, 8], vi)
            n = run_verse(c, log=lambda *_a: None)
            t('★★ 5건 승인 · 두 번째는 0(멱등)', n == 5 and run_verse(c, log=lambda *_a: None) == 0)
            undo_verse(c, log=lambda *_a: None)
            t('★ 되돌릴 수 있다', c.execute("SELECT COUNT(*) FROM sys_media_asset WHERE is_active=1").fetchone()[0] == 0)
            # ── 예배 실황 보관함 자동승인(2026-09-16) — 연결 없이 승인하는 유일한 문
            c.execute("UPDATE sys_media_asset SET is_active=0")
            for _m, _ti, _d, _mt in ((11, '2026 주일예배 설교', '{"channel":"등록교회","channel_id":"UCREG"}', 'SERMON'),   # 통과
                                     (12, '2026 주일예배 설교', '{"channel":"딴교회"}', 'SERMON'),                       # 미등록
                                     (13, '2026 주일예배 찬양', '{"channel":"등록교회","channel_id":"UCREG"}', 'WORSHIP'),  # 찬양 유형
                                     (14, 'Sunday Service', '{"channel":"John Doe"}', 'SERMON'),                        # 이름 신호 없음(미등록이기도)
                                     (15, '창세기 2장 강해', '{"channel":"등록교회","channel_id":"UCREG"}', 'SERMON')):   # 설교 몫 3/4
                c.execute("INSERT INTO sys_media_asset VALUES(?,?,?,0,'LIVE',?,'KO')", (_m, _ti, _d, _mt))
                if _m != 15:                       # 15 는 보관함 밖(설교 몫을 채우는 영상)
                    c.execute("INSERT INTO sys_media_pending VALUES(?,'LIVE','LIVESVC')", (_m,))
            c.commit()
            _ls = live_service_ids(c)
            t('★★★ 실황 보관함 — 등록 교회 채널 · 설교 중심 · 설교 유형만 승인 대상(11)', _ls == [11], _ls)
            _r1 = run_live_service(c, log=lambda *_a: None); _r2 = run_live_service(c, log=lambda *_a: None)
            t('  연결이 없어도 그 문으로는 승인된다 · 두 번째는 0',
              _r1 == 1 and _r2 == 0
              and c.execute("SELECT is_active FROM sys_media_asset WHERE media_id=11").fetchone()[0] == 1,
              (_r1, _r2, c.execute("SELECT is_active FROM sys_media_asset WHERE media_id=11").fetchone()))
            t('  되돌릴 수 있다', undo_live_service(c, log=lambda *_a: None) == 1
              and c.execute("SELECT is_active FROM sys_media_asset WHERE media_id=11").fetchone()[0] == 0)
            _sv = c.execute("SELECT is_active FROM sys_media_asset WHERE media_id IN (12,13,14)").fetchall()
            t('  미등록·찬양 유형·이름 신호 없음은 그대로 미검토', all(r[0] == 0 for r in _sv))
            # ── 용어 연결 승인(2026-09-17) — 살아 있는 용어 연결만 · 후보는 안 된다
            c.execute("UPDATE sys_media_asset SET is_active=0")
            c.execute("DELETE FROM sys_link_asset")
            c.execute("INSERT INTO sys_link_asset VALUES(1,10,NULL,'MEDI_ENTI','LIVE')")   # 살아 있는 용어 연결
            c.execute("INSERT INTO sys_link_asset VALUES(2,10,NULL,'MEDI_ENTI','PEND')")   # 후보 — 승인 대상 아님
            c.execute("INSERT INTO sys_link_asset VALUES(5,10,NULL,'MEDI_ENTI','LIVE')")   # 제외 채널
            c.commit()
            # 넓힌 문 — 보관함에 없어도 교회·설교 채널이면 대상(2026-09-17)
            c.execute("DELETE FROM sys_media_pending")
            c.execute("UPDATE sys_media_asset SET is_active=0")
            c.commit()
            _cs = church_sermon_ids(c)
            t('★★★ 보관함에 없어도 교회·설교 채널의 설교면 대상(7·11·15) · 미등록 12 · 찬양 13 · 이름 없음 14 는 아니다',
              _cs == [7, 11, 15], _cs)
            t('  좁은 문(`live_service_ids`)은 보관함 것만 — 지금은 보관함이 비었으니 0',
              live_service_ids(c) == [], live_service_ids(c))
            t('  승인·되돌리기 왕복', run_church_sermon(c, log=lambda *_a: None) == 3
              and undo_church_sermon(c, log=lambda *_a: None) == 3)
            _ti = term_ids(c)
            t('★★★ 용어 연결 승인 = **살아 있는 연결만**(후보 2 · 제외 채널 5 는 뺀다)', _ti == [1], _ti)
            t('  승인되고 두 번째는 0 · 되돌릴 수 있다',
              run_term(c, log=lambda *_a: None) == 1 and run_term(c, log=lambda *_a: None) == 0
              and undo_term(c, log=lambda *_a: None) == 1
              and c.execute("SELECT is_active FROM sys_media_asset WHERE media_id=1").fetchone()[0] == 0)
        finally:
            pass
    finally:
        MR.read, MX.excluded_channels = r_read, r_ex
    c.close()
    print('  %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


def _empty():
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE sys_config(config_key TEXT PRIMARY KEY,"
              " config_val TEXT)")
    return c


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect(timeout=180)
    if '--verse-check' in a:
        run_verse(conn, dry=True); conn.close(); sys.exit(0)
    if '--verse-apply' in a:
        run_verse(conn); conn.close(); sys.exit(0)
    if '--verse-undo' in a:
        undo_verse(conn); conn.close(); sys.exit(0)
    if '--live-check' in a:
        run_live_service(conn, dry=True); conn.close(); sys.exit(0)
    if '--live-apply' in a:
        run_live_service(conn); conn.close(); sys.exit(0)
    if '--live-undo' in a:
        undo_live_service(conn); conn.close(); sys.exit(0)
    if '--term-check' in a:
        run_term(conn, dry=True); conn.close(); sys.exit(0)
    if '--term-apply' in a:
        run_term(conn); conn.close(); sys.exit(0)
    if '--term-undo' in a:
        undo_term(conn); conn.close(); sys.exit(0)
    if '--church-check' in a:
        run_church_sermon(conn, dry=True); conn.close(); sys.exit(0)
    if '--church-apply' in a:
        run_church_sermon(conn); conn.close(); sys.exit(0)
    if '--church-undo' in a:
        undo_church_sermon(conn); conn.close(); sys.exit(0)
    try:
        if '--undo' in a:
            undo(conn)
        elif '--apply' in a:
            run(conn)
        else:
            print('지금 대상 (안 씁니다):')
            run(conn, dry=True)
    finally:
        conn.close()
