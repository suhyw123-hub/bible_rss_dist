# -*- coding: utf-8 -*-
"""tree_cols.py — **목록(Treeview) 칸 폭은 사람이 끈 대로** (2026-10-21 신설 · 영구 · `--selftest`).

사용자(docs/AI도우미.txt 3번) — 「대부분 목록 화면에서 항목 사이의 간격을 조절하면 다시 원상복귀된다.
사용자가 원하는대로 고정되지 않는다 … PC앱의 모든 목록 화면을 전부 정비하라. **철칙으로 지켜라.**
사용자가 간격을 조절하면 그대로 고정하라」.

★ 화면마다 고치지 않는다 — 실측 목록이 사용자 앱 138곳 · 관리자 156곳이고, 새로 만드는 목록은 또 빠진다.
  ⇒ 한 곳에서 건다(`install(root)` 한 번):
    ① 사람이 칸 경계(separator)를 끌어 놓으면 그 목록의 칸 폭을 전부 적는다(`user_config['TREE_COLW']`)
    ② 코드가 나중에 `tv.column(칸, width=…)` 로 폭을 다시 정하면 **사람이 정한 폭이 이긴다**
       — 목록을 다시 채울 때마다 폭이 되돌아가던 까닭이 이것이다.
★ 목록을 가리는 열쇠 = 칸 이름들 + 보이는 방식(`show`) — 위젯 경로는 짓는 차례에 따라 바뀌어 못 쓴다.
  같은 칸 이름을 쓰는 목록은 같은 폭을 나눠 쓴다(같은 모양의 목록이라 그것이 맞다).
⚠ 사람이 끌지 않은 목록은 아무것도 안 바뀐다(코드가 정한 폭 그대로).
★★ 2026-10-21 두 번째 판(사용자 「아직도 간격 조절이 작동하지 않는다」) — 실측 원인 셋:
   ① **늘어나는 칸(stretch)** 이 있으면 Tk 가 끈 뒤에도·창 크기가 바뀔 때도 폭을 다시 나눠 **되돌아간 것처럼** 보였다
      ⇒ 사람이 끈 목록은 칸을 **늘어나지 않게**(stretch=False) 못 박는다 — 남는 자리는 비고, 넘치면 굴린다.
   ② 코드가 폭을 다시 정하지 않는 목록은 적어 둔 폭을 **입힐 때가 없었다** ⇒ 목록이 화면에 놓일 때(`<Map>`) 입힌다.
   ③ 열쇠의 `show` 가 Tcl 객체 글자(`(<index object: 'headings'>,)`)로 적혔다 ⇒ 낱말로 고르고 옛 열쇠도 읽는다.
"""
import json
import re
import tkinter as tk
from tkinter import ttk

KEY = 'TREE_COLW'
_cache = None
_db = None
_installed = False
_orig_column = ttk.Treeview.column


def _conn():
    import appdb
    return appdb.connect(_db) if _db else appdb.connect()


def _load():
    global _cache
    if _cache is None:
        _cache = {}
        try:
            with _conn() as c:
                r = c.execute("SELECT config_val FROM user_config WHERE config_key=?", (KEY,)).fetchone()
            if r and r[0]:
                _cache = {_norm_key(k): v for k, v in (json.loads(r[0]) or {}).items()}
        except Exception:                                 # noqa: BLE001
            _cache = {}
    return _cache


def _save():
    try:
        val = json.dumps(_cache or {}, ensure_ascii=False, sort_keys=True)
        with _conn() as c:
            if c.execute("UPDATE user_config SET config_val=? WHERE config_key=?", (val, KEY)).rowcount == 0:
                c.execute("INSERT INTO user_config(config_key, config_val) VALUES(?,?)", (KEY, val))
            c.commit()
    except Exception as e:                                # noqa: BLE001
        print('[tree_cols save] %s' % e)


def _norm_key(k):
    """옛 열쇠(`a|b@(<index object: 'headings'>,)`) → `a|b@headings`."""
    if '<index object' not in str(k):
        return k
    head, _, tail = str(k).partition('@')
    return head + '@' + ' '.join(re.findall(r"'([^']*)'", tail))


def _show(tv):
    try:
        return ' '.join(str(x) for x in tv.tk.splitlist(tv.cget('show')))
    except Exception:                                     # noqa: BLE001
        return str(tv.cget('show'))


def key_of(tv):
    try:
        cols = tv.cget('columns')
        if isinstance(cols, str):
            cols = tuple(x for x in cols.split() if x)
        show = _show(tv)
    except Exception:                                     # noqa: BLE001
        return None
    if not cols:
        return None
    return '|'.join(str(c) for c in cols) + '@' + show


def saved_width(tv, column):
    k = key_of(tv)
    if not k:
        return None
    return (_load().get(k) or {}).get(str(column))


def _column(self, column, option=None, **kw):
    if option is None and kw and ('width' in kw or 'stretch' in kw or 'minwidth' in kw):
        w = saved_width(self, column)
        if w:
            if 'width' in kw:
                kw['width'] = int(w)                      # ★ 사람이 정한 폭이 이긴다
            kw['stretch'] = False                         # ★ Tk 가 다시 나누지 못하게
            if 'minwidth' in kw:
                kw['minwidth'] = min(int(kw['minwidth']), int(w))
    return _orig_column(self, column, option, **kw)


def apply(tv):
    """적어 둔 폭을 이 목록에 입힌다(늘어나지 않게) — 없으면 아무것도 안 한다."""
    k = key_of(tv)
    ws = _load().get(k) if k else None
    if not ws:
        return False
    for c, w in ws.items():
        try:
            _orig_column(tv, c, width=int(w), stretch=False)
        except Exception:                                 # noqa: BLE001
            pass
    return True


def remember(tv):
    """지금 폭을 그 목록의 폭으로 적는다(사람이 경계를 끌어 놓았을 때)."""
    k = key_of(tv)
    if not k:
        return
    try:
        cols = tv.cget('columns')
        if isinstance(cols, str):
            cols = tuple(x for x in cols.split() if x)
        ws = {str(c): int(_orig_column(tv, c, 'width')) for c in cols}
        if 'tree' in _show(tv).split():
            ws['#0'] = int(_orig_column(tv, '#0', 'width'))
    except Exception:                                     # noqa: BLE001
        return
    _load()[k] = ws
    _save()
    apply(tv)                                             # 끈 그 자리에서 늘어나지 않게 못 박는다


def _press(e):
    tv = e.widget
    try:
        tv._tc_drag = tv.identify_region(e.x, e.y) == 'separator'
    except Exception:                                     # noqa: BLE001
        pass


def _release(e):
    tv = e.widget
    if getattr(tv, '_tc_drag', False):
        tv._tc_drag = False
        try:
            tv.after_idle(lambda: remember(tv))
        except Exception:                                 # noqa: BLE001
            remember(tv)


def _map(e):
    tv = e.widget
    if getattr(tv, '_tc_applied', False):
        return
    tv._tc_applied = True
    apply(tv)


def install(root, db_path=None):
    """앱을 켤 때 한 번 — 모든 목록에 걸린다(앞으로 만드는 것도)."""
    global _installed, _db
    if db_path:
        _db = db_path
    if _installed:
        return
    ttk.Treeview.column = _column
    try:
        root.bind_class('Treeview', '<ButtonPress-1>', _press, add='+')
        root.bind_class('Treeview', '<ButtonRelease-1>', _release, add='+')
        root.bind_class('Treeview', '<Map>', _map, add='+')
    except Exception as e:                                # noqa: BLE001
        print('[tree_cols install] %s' % e)
    _installed = True


def selftest():
    import os
    import tempfile
    import sqlite3
    global _cache, _db
    ok = []

    def ck(c, m):
        ok.append(bool(c))
        print(('PASS ' if c else 'FAIL ') + m)

    d = tempfile.mkdtemp()
    p = os.path.join(d, 't.db')
    con = sqlite3.connect(p)
    con.execute('CREATE TABLE user_config(config_key TEXT PRIMARY KEY, config_val TEXT)')
    con.commit()
    con.close()
    import appdb
    real = appdb.connect

    class _C:
        def __enter__(self_):
            self_.c = sqlite3.connect(p)
            return self_.c

        def __exit__(self_, *a):
            self_.c.close()
    appdb.connect = lambda *a, **k: _C()
    _cache = None
    r = tk.Tk()
    try:
        install(r)
        tv = ttk.Treeview(r, columns=('a', 'b'), show='headings')
        tv.column('a', width=50)
        tv.column('b', width=60)
        ck(int(_orig_column(tv, 'a', 'width')) == 50, '끈 적 없으면 코드가 정한 폭')
        _orig_column(tv, 'a', width=123)
        remember(tv)
        tv.column('a', width=50)                          # 코드가 다시 정해도
        ck(int(_orig_column(tv, 'a', 'width')) == 123, '사람이 끈 폭이 이긴다')
        tv2 = ttk.Treeview(r, columns=('a', 'b'), show='headings')
        tv2.column('a', width=40)
        ck(int(_orig_column(tv2, 'a', 'width')) == 123, '같은 모양의 목록을 다시 지어도 그 폭')
        _cache = None
        ck(saved_width(tv, 'a') == 123, '저장소에서 다시 읽는다')
        tv3 = ttk.Treeview(r, columns=('x',), show='headings')
        tv3.column('x', width=77)
        ck(int(_orig_column(tv3, 'x', 'width')) == 77, '다른 목록은 안 건드린다')
        ck(not bool(int(_orig_column(tv, 'a', 'stretch'))), '끈 목록의 칸은 늘어나지 않는다')
        ck(bool(int(_orig_column(tv3, 'x', 'stretch'))), '안 끈 목록은 그대로 늘어난다')
        ck(key_of(tv) == 'a|b@headings', '열쇠가 낱말(%s)' % key_of(tv))
        ck(_norm_key("a|b@(<index object: 'headings'>,)") == 'a|b@headings', '옛 열쇠를 읽는다')
        tv4 = ttk.Treeview(r, columns=('a', 'b'), show='headings')
        tv4.pack()
        r.update()
        ck(int(_orig_column(tv4, 'a', 'width')) == 123, '폭을 안 정한 목록도 화면에 놓일 때 그 폭')
    finally:
        r.destroy()
        appdb.connect = real
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
