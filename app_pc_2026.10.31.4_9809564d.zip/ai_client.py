# -*- coding: utf-8 -*-
"""ai_client.py — **AI 에 글을 시키는 단 하나의 문** (영구 도구, 2026-09-23 277차).

1.txt 11번 ③단계. `db_ai_job`(무엇을 할지 고른다) → **여기**(시킨다) →
게이트 → 사람 검수 → 적재.

    python ai_client.py --selftest        (의무 · 망을 안 탄다)
    python ai_client.py --status          키·모델·오늘 쓴 양
    python ai_client.py --set-keys A,B    키 저장
    python ai_client.py --ping            **실제로 한 번 불러 본다**
    python ai_client.py --models          모델 목록과 한도

★★★ **왜 문을 하나로 두나** — 키·재시도·한도·사용량을 화면마다 적으면
  ⓐ 한 곳이 반드시 빠지고 ⓑ **얼마나 썼는지 아무도 모른다.** 무료 등급은
  하루 한도가 있어 「모르는 채 쓰는 것」이 곧 작업 중단이다.

⚠⚠⚠ **여기 적힌 한도는 구글 문서의 값이지 우리가 잰 값이 아니다.**
  키를 받으면 `--ping` 으로 실제 응답을 보고 고친다. **재지 않은 수를 잰 것처럼
  쓰지 않는다**(§0-1).

⚠ **유료·저작권 본문을 보내지 않는다** — 무엇을 보낼지는 `db_ai_job.material`
  이 정하고, 그 자산 목록에 역본 본문이 아예 없다(§18-3). 이 문은 받은 글을
  그대로 보낼 뿐이므로 **부르는 쪽이 지킨다.**

⚠ **중단 스위치를 함께 쓴다** — `gcloud_gate` 가 잠겨 있으면 거부한다.
  구글에 닿는 문이 둘로 갈리면 「껐는데 나간다」가 된다(§256차 ⑰).
"""
import datetime
import json
import re
import os
import ssl
import sys
import time
import urllib.error
import urllib.request

APP = os.path.dirname(os.path.abspath(__file__))
if APP not in sys.path:
    sys.path.insert(0, APP)

KEYS = 'GEMINI_API_KEYS'            # 쉼표로 이은 키 (YouTube 와 같은 꼴)
MODEL_CFG = 'GEMINI_MODEL'
ENDPOINT = ('https://generativelanguage.googleapis.com/v1beta/models/'
            '%s:generateContent')

#: 모델 — (이름, 하루 요청, 분당 요청, 출력 상한 토큰, 설명)
#  ⚠⚠ **구글 문서의 무료 등급 값이고 자주 바뀐다.** `--ping` 으로 확인하고
#    다르면 여기를 고친다. 코드가 이 표를 **한도 판정에 쓰지 않는다** —
#    보여 주고 어림잡는 데만 쓴다(틀린 수로 일을 막으면 더 나쁘다).
# ★★★ **이름은 실측이다 — 실제로 한 번씩 불러서 골랐다**(2026-09-23).
#   ⚠⚠ `ListModels` 에 이름이 있다고 쓸 수 있는 것이 아니다. 옛 기본값
#     `gemini-2.5-flash-lite` 는 **목록에 그대로 있는데도** 404 를 낸다
#     (「no longer available to new users」). 목록만 보고 고르면 안 된다.
#   ⚠⚠ **한도는 키가 아니라 프로젝트 단위**이고 **태평양 자정에 리셋**된다
#     (`docs/Rate limits.txt`). 같은 프로젝트의 키를 여러 개 넣어도 한도가
#     늘지 않는다 — 늘리려면 등급을 올리거나 다른 프로젝트의 키라야 한다.
#   ⚠ 한도(rpd·rpm)는 **0 = 아직 안 쟀다**. 위 문서에도 Free 등급의 모델별
#     숫자는 없고 「AI Studio 에서 보라」고만 한다 — 그래서 모름으로 둔다. 옛 표의 1000/15 는 2.5 세대
#     문서값이었고 3.5 세대 값을 우리는 모른다 — **지어내지 않는다**(§0-1).
#     화면이 0 을 「모름」으로 적는다.
# 칸 = (이름, rpd, rpm, 출력상한, **입력 $/1M**, **출력 $/1M**, 무료 가능, 설명)
#   ★ 단가는 `docs/API Pricing.txt` 실측이다(2026-09-23).
MODELS = [
    ('gemini-3.5-flash-lite', 0, 0, 65536, 0.30, 2.50, True,
     '싼 대신 얕다 — 번역·짧은 글'),
    ('gemini-3.5-flash',      0, 0, 65536, 1.50, 9.00, True,
     '두껍다 — 설명문 신규 작성'),
    ('gemini-pro-latest',     0, 0, 65536, 2.00, 12.00, False,
     '가장 두껍다 — ⚠ 무료 등급에서는 못 쓴다(문서 「Not available」· 실측 429)'),
]
MODEL_NAMES = [m[0] for m in MODELS]
DEFAULT_MODEL = MODELS[0][0]

TIMEOUT = 120
RETRY = 3                  # 한 키에서 되풀이할 횟수
BACKOFF = (2, 8, 20)       # 초 — 429·5xx 에서 기다리는 시간

SCHEMA = """
CREATE TABLE IF NOT EXISTS sys_ai_usage (
    day       TEXT NOT NULL,
    model     TEXT NOT NULL,
    n_call    INTEGER DEFAULT 0,
    n_ok      INTEGER DEFAULT 0,
    n_in      INTEGER DEFAULT 0,
    n_out     INTEGER DEFAULT 0,
    PRIMARY KEY (day, model)
);
"""


def _conn():
    import appdb
    return appdb.connect(os.path.join(APP, 'bible_master.db'))


def _test_conn(path):
    """자가 검증 전용 **임시 DB** — 진짜 DB 를 열지 않는다.

    ⚠⚠⚠ 옛 판은 `_conn()`(진짜 `bible_master.db`)에 가짜 키를 썼다가
      끝에 되돌렸다. 그 되돌리기가 `finally` 밖이라 **중간에 죽으면 사용자
      키가 가짜로 남았고**, 실제로 그렇게 잃었다(2026-09-23).
      ⇒ 아예 딴 파일에서 잰다. 죽어도 사용자 자료에 닿을 길이 없다.
    """
    import sqlite3
    c = sqlite3.connect(path)
    c.execute("CREATE TABLE IF NOT EXISTS sys_config("
              "config_key TEXT PRIMARY KEY, config_val TEXT)")
    c.executescript(SCHEMA)
    c.commit()
    return c


def _cfg(conn, key, dflt=''):
    r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                     (key,)).fetchone()
    return (r[0] if r and r[0] is not None else dflt)


def _set_cfg(conn, key, val):
    conn.execute(
        "INSERT INTO sys_config(config_key, config_val) VALUES(?,?) "
        "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
        (key, val))
    conn.commit()


# ── 키 ────────────────────────────────────────────────────────────

def keys(conn=None):
    """저장된 키 목록. **키를 화면·로그에 그대로 찍지 않는다**(`mask` 를 쓴다)."""
    # ★ 2026-10-11 — 열쇠는 배포 DB 밖(secret_store · admin_secrets.db). conn 은 옛 부르는 꼴 그대로 받는다.
    import secret_store as _SS
    return _SS.keys_list(KEYS)


def set_keys(conn, lst):
    import secret_store as _SS
    _SS.put(KEYS, ','.join(k.strip() for k in lst if k.strip()))
    return len(keys(conn))


def mask(k):
    """키를 사람에게 보일 꼴 — 앞뒤만 남긴다."""
    k = str(k or '')
    return (k[:6] + '…' + k[-4:]) if len(k) > 12 else ('…' if k else '(없음)')


def model_of(conn=None):
    close = conn is None
    conn = conn or _conn()
    try:
        m = _cfg(conn, MODEL_CFG, '') or DEFAULT_MODEL
    finally:
        if close:
            conn.close()
    return m if m in MODEL_NAMES else DEFAULT_MODEL


# ★ 2026-10-27 (docs/1.txt 15) **번역은 한 단계 위 모델로** — flash-lite 가 옮긴 사전 101편을 다시 재니
#   절반 넘게 뜻이 틀렸다(사라 「아브라함의 아들」 · 아론 「문병」 · 여리고 「여호수아 → 여호와」).
#   설정(`sys_config[AI_TRANS_MODEL]`)이 있으면 그것 · 없으면 TRANS_MODEL.
TRANS_MODEL = 'gemini-3.5-flash'
TRANS_MODEL_CFG = 'AI_TRANS_MODEL'


def trans_model(conn=None):
    close = conn is None
    conn = conn or _conn()
    try:
        m = _cfg(conn, TRANS_MODEL_CFG, '') or TRANS_MODEL
    finally:
        if close:
            conn.close()
    return m if m in MODEL_NAMES else TRANS_MODEL


# ★★ 2026-10-30 **일마다 모델·생각 정도를 고른다**(사용자 「모든 작업에 대해서 모델을 각각 선택」) —
#   (일, 이름, 모델 설정 열쇠, 기본 모델, 기본 생각). 생각 = '' 기본 · 'low' · 'high'(출력 단가로 청구된다).
#   실측(2026-10-30 · 사전 10건): flash-lite 번역 게이트 0/10 · 오류 8 / Pro low 8/10 · 오류 1 ⇒ 번역 기본 Pro low.
TASK_SETTINGS = (
    # ★ 2026-10-30 AI 작업실 다섯 = 초기값 Pro · low(사용자) · 「그 밖」 = 제목 번역·용어 이름·플랜 점검이 쓰는 앱 기본(싸게 둔다)
    ('NEW', '새로 쓰기', 'AI_MODEL_NEW', 'gemini-pro-latest', 'low'),
    ('TRANS', '번역', TRANS_MODEL_CFG, 'gemini-pro-latest', 'low'),
    ('EDIT', '다듬기', 'AI_MODEL_EDIT', 'gemini-pro-latest', 'low'),
    ('CHECK', '오류 찾기', 'AI_CHECK_MODEL', 'gemini-pro-latest', 'low'),
    ('FIX', '오류 수정(여러 번 나오는 글자)', 'AI_MODEL_FIX', 'gemini-pro-latest', 'low'),
    ('OTHER', '그 밖(제목 번역 · 용어 이름 · 플랜 점검)', MODEL_CFG, None, ''),
)
THINK_LEVELS = ('', 'low', 'high')


def _task_row(task):
    for r in TASK_SETTINGS:
        if r[0] == str(task or '').upper():
            return r
    return TASK_SETTINGS[-1]


def task_model(conn, task):
    """그 일에 쓸 모델 — 설정 → 기본(「그 밖」 = 앱 기본 model_of)"""
    t, _n, key, dflt, _th = _task_row(task)
    if t == 'OTHER':
        return model_of(conn)
    m = _cfg(conn, key, '') or dflt
    return m if m in MODEL_NAMES else dflt


def task_think(conn, task):
    t, _n, _key, _dflt, th = _task_row(task)
    v = _cfg(conn, 'AI_THINK_' + t, None)
    if v is None:
        return th or None
    return v if v in THINK_LEVELS[1:] else None


def set_task(conn, task, model=None, think=None):
    t, _n, key, _dflt, _th = _task_row(task)
    if model is not None:
        _set_cfg(conn, key, model if model in MODEL_NAMES else '')
    if think is not None:
        _set_cfg(conn, 'AI_THINK_' + t, think if think in THINK_LEVELS else '')


def model_info(name):
    for m in MODELS:
        if m[0] == name:
            return dict(zip(('name', 'rpd', 'rpm', 'out_max',
                             'in_usd', 'out_usd', 'free_ok', 'note'), m))
    return None


# ── 사용량 ────────────────────────────────────────────────────────

def _today():
    """오늘 — **태평양 시간 기준**(`docs/Rate limits.txt`).

    ⚠⚠ 구글은 **RPD 를 태평양 자정에 리셋**한다. 우리가 한국 날짜로 세면
      구글의 하루와 최대 17시간 어긋나 「오늘 얼마 썼나」가 거짓이 된다.
    ⚠ `zoneinfo` 가 없는 환경이면 **−8시간 고정**으로 물러선다(서머타임이면
      한 시간 어긋나지만, 로컬 날짜로 세는 것보다 훨씬 가깝다).
    """
    try:
        from zoneinfo import ZoneInfo
        tz = ZoneInfo('America/Los_Angeles')
    except Exception:                                     # noqa: BLE001
        tz = datetime.timezone(datetime.timedelta(hours=-8))
    return datetime.datetime.now(tz).date().isoformat()


def note_usage(conn, model, ok, n_in=0, n_out=0, day=None):
    """한 번 부른 것을 적는다 — **이것이 없으면 얼마나 썼는지 아무도 모른다.**

    ⚠ 실패도 센다(`n_call`) — 무료 등급은 **실패한 요청도 한도를 먹는다.**
      성공만 세면 「아직 여유 있다」고 잘못 읽는다.
    """
    conn.executescript(SCHEMA)
    conn.execute(
        "INSERT INTO sys_ai_usage(day, model, n_call, n_ok, n_in, n_out) "
        "VALUES(?,?,1,?,?,?) ON CONFLICT(day, model) DO UPDATE SET "
        " n_call=n_call+1, n_ok=n_ok+?, n_in=n_in+?, n_out=n_out+?",
        (day or _today(), model, 1 if ok else 0, int(n_in), int(n_out),
         1 if ok else 0, int(n_in), int(n_out)))
    conn.commit()


def usage(conn, day=None):
    """그날 쓴 양 — `[(모델, 부른 수, 된 수, 입력 토큰, 출력 토큰)]`."""
    conn.executescript(SCHEMA)
    return conn.execute(
        "SELECT model, n_call, n_ok, n_in, n_out FROM sys_ai_usage "
        "WHERE day=? ORDER BY model", (day or _today(),)).fetchall()


def cost(model, n_in, n_out):
    """유료 등급으로 올렸을 때 드는 돈(USD) — `docs/API Pricing.txt` 단가.

    ⚠ **무료 등급에서는 0원**이다. 이 수는 「유료로 올리면 얼마인가」다.
    ⚠ 모르는 모델이면 `None` — 0 이라 적으면 공짜로 읽힌다(§0-1).
    """
    inf = model_info(model)
    if not inf:
        return None
    return (int(n_in) * float(inf['in_usd']) +
            int(n_out) * float(inf['out_usd'])) / 1000000.0


def left_today(conn, model=None):
    """오늘 남은 요청 수 — **`(남은 수, 한도)`이고 모르면 `(None, 0)`**.

    ⚠ 이 수로 일을 막지 않는다. 보여 주기만.
    ⚠⚠ **한도를 모르면 숫자를 지어내지 않는다** — 옛 판은 rpd 를 그대로
      빼서 「남은 1000」처럼 적었는데 그 1000 이 잰 값이 아니었다. 모르면
      `None` 을 내고 화면이 「모름」이라 적는다(§0-1).
    """
    model = model or model_of(conn)
    inf = model_info(model) or {}
    cap = int(inf.get('rpd', 0))
    used = dict((m, c) for m, c, _o, _i, _u in usage(conn)).get(model, 0)
    if cap <= 0:
        return None, 0
    return max(0, cap - used), cap


# ── 부르기 ────────────────────────────────────────────────────────

def _post(url, payload, timeout):
    data = json.dumps(payload).encode('utf-8')
    req = urllib.request.Request(
        url, data=data, headers={'Content-Type': 'application/json'})
    ctx = ssl.create_default_context()
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return r.getcode(), r.read().decode('utf-8', 'replace')


def _parse(body):
    """응답에서 글과 토큰 수를 꺼낸다. 못 꺼내면 까닭을 낸다."""
    try:
        d = json.loads(body)
    except Exception as e:                                # noqa: BLE001
        return None, {}, '응답이 JSON 이 아니다: %s' % e
    if 'error' in d:
        e = d['error'] or {}
        return None, {}, '%s %s' % (e.get('status', ''), e.get('message', ''))
    cands = d.get('candidates') or []
    if not cands:
        # ★ 안전 필터에 걸리면 candidates 가 비고 까닭이 따로 온다
        fb = (d.get('promptFeedback') or {}).get('blockReason')
        return None, {}, '받은 글이 없다%s' % (' (%s)' % fb if fb else '')
    c0 = cands[0]
    parts = ((c0.get('content') or {}).get('parts') or [])
    txt = ''.join(p.get('text', '') for p in parts)
    um = d.get('usageMetadata') or {}
    # ★ 2026-10-30 **생각 토큰도 출력으로 센다** — 출력 단가로 청구되는데 빠져 있어 실측 사용액이 10배 넘게 적게 보였다
    #   (Pro 「없음」 한 줄 답에 생각 1,357 토큰 · 사용자 「100건도 안 했는데 6,000원」)
    tok = {'in': um.get('promptTokenCount', 0),
           'out': um.get('candidatesTokenCount', 0) + um.get('thoughtsTokenCount', 0),
           'think': um.get('thoughtsTokenCount', 0)}
    if not txt:
        return None, tok, '글이 비었다 (finishReason=%s)' % c0.get('finishReason')
    return txt, tok, ''


def call(prompt, model=None, conn=None, timeout=TIMEOUT, max_out=None,
         temperature=None, _post_fn=None, thinking=None):
    """**한 번 시킨다** — `{ok, text, why, model, key, tokens}`.

    ★ 2026-10-13 — **보낸 글을 글자 그대로 남긴다**(`ai_sent_log` · 관리자 PC 에만). 사용자 지시
      「AI 에게 보내는 모든 자료가 관리자의 눈에 전부 다 보여지는지 · 하나도 빠지면 안된다」.
      시험용 가짜 망(`_post_fn`)이면 남기지 않는다.
    """
    res = _call_raw(prompt, model, conn, timeout, max_out, temperature, _post_fn, thinking)
    if _post_fn is None:
        try:
            import ai_sent_log
            ai_sent_log.record('ai_client', prompt, model=res.get('model') or model or '',
                               ok=res.get('ok'), response=res.get('text') or '', why=res.get('why') or '')
        except Exception:                                 # noqa: BLE001
            pass
    return res


def _call_raw(prompt, model=None, conn=None, timeout=TIMEOUT, max_out=None,
              temperature=None, _post_fn=None, thinking=None):
    """`call` 의 몸통 — 망에 실제로 보낸다(남기는 일은 `call` 이 한다)."""
    _doc = """**한 번 시킨다** — `{ok, text, why, model, key, tokens}`.

    ⚠ **예외를 밖으로 던지지 않는다** — 배치 도중 한 건이 터져서 전체가 멎으면
      안 된다. 실패는 `ok=False` 와 **까닭**으로 돌려준다.
    ⚠ 키를 여럿 두면 **한도에 걸린 키를 지나 다음 키로** 넘어간다.
      429·5xx 는 기다렸다 되풀이하고, 400·403 은 **되풀이하지 않는다**
      (그 키·그 요청이 잘못된 것이라 다시 해도 같다).
    """
    close = conn is None
    conn = conn or _conn()
    post = _post_fn or _post
    model = model or model_of(conn)
    try:
        try:
            import gcloud_gate
            if gcloud_gate.paused(conn):
                return {'ok': False, 'why': '구글 클라우드가 일시 중단 상태입니다 '
                                            '(관리자 ▸ YouTube API 키 관리에서 재개).',
                        'text': '', 'model': model, 'key': '', 'tokens': {}}
        except Exception:                                 # noqa: BLE001
            pass
        ks = keys(conn)
        if not ks:
            return {'ok': False, 'why': 'Gemini 키가 없습니다 — 「AI 연결」에서 넣으세요.',
                    'text': '', 'model': model, 'key': '', 'tokens': {}}
        gen = {}
        if max_out:
            gen['maxOutputTokens'] = int(max_out)
        if temperature is not None:
            gen['temperature'] = float(temperature)
        if thinking:
            # ★ 2026-10-30 생각 정도(low · high) — 생각 토큰이 출력 단가로 청구된다
            gen['thinkingConfig'] = {'thinkingLevel': thinking}
        payload = {'contents': [{'parts': [{'text': prompt}]}]}
        if gen:
            payload['generationConfig'] = gen

        last = '알 수 없는 까닭'
        for k in ks:
            url = (ENDPOINT % model) + '?key=' + k
            for i in range(RETRY):
                try:
                    code, body = post(url, payload, timeout)
                except urllib.error.HTTPError as e:       # noqa: PERF203
                    code = e.code
                    try:
                        body = e.read().decode('utf-8', 'replace')
                    except Exception:                     # noqa: BLE001
                        body = ''
                except Exception as e:                    # noqa: BLE001
                    code, body = 0, ''
                    last = '망 오류: %s' % e
                if code == 200:
                    txt, tok, why = _parse(body)
                    note_usage(conn, model, bool(txt),
                               tok.get('in', 0), tok.get('out', 0))
                    if txt:
                        return {'ok': True, 'text': txt, 'why': '', 'model': model,
                                'key': mask(k), 'tokens': tok}
                    last = why
                    break                                  # 글이 없으면 되풀이 무의미
                note_usage(conn, model, False)
                if code in (400, 401, 403, 404):
                    _t, _k, why = _parse(body)
                    last = 'HTTP %s %s' % (code, why or '')
                    break                                  # 이 키로는 안 된다
                # ★ 2026-10-30 **하루 한도**(유료 1등급 Pro = 모델당 하루 250회)는 되풀이해도 안 풀린다 —
                #   기다리지 않고 곧바로 「하루 한도」라 알린다(실측: 남은 건을 계속 보내 429 만 쌓였다)
                if code == 429 and 'PerDay' in (body or ''):
                    _sec = re.search(r'"retryDelay"\s*:\s*"(\d+)s"', body or '')
                    _h = (int(_sec.group(1)) / 3600.0) if _sec else None
                    return {'ok': False, 'text': '', 'model': model, 'key': mask(k), 'tokens': {}, 'daily': True,
                            'why': '하루 한도를 다 썼습니다(%s · 모델당 하루 요청 수)%s — 묶어 보내면 요청 수가 준다'
                                   % (model, (' · 약 %.0f시간 뒤 풀립니다' % _h) if _h else '')}
                if code in (429, 500, 502, 503, 504) or code == 0:
                    last = 'HTTP %s' % code if code else last
                    if i < RETRY - 1:
                        time.sleep(BACKOFF[min(i, len(BACKOFF) - 1)])
                    continue
                last = 'HTTP %s' % code
                break
        return {'ok': False, 'text': '', 'why': last, 'model': model,
                'key': '', 'tokens': {}}
    finally:
        if close:
            conn.close()


# ── 자가 검증 (의무 · 망을 안 탄다) ────────────────────────────────

def selftest():
    bad = []
    _nck = [0]
    _tmp = None

    # ⚠ **항목 수를 손으로 적지 않는다** — 옛 판은 `n_all = 25` 라는 상수라
    #   항목을 늘려도 25 로 찍혀 **세는 쪽이 거짓말**을 했다(§238차 그 자리).
    def ck(c, m):
        _nck[0] += 1
        if not c:
            bad.append(m)

    # ① 모델 표
    ck(len(MODELS) == len(set(MODEL_NAMES)), '모델 이름이 겹친다')
    # ★ 한도를 모르면 **숫자를 지어내지 않는다** — 양방향으로 잰다
    _c0 = _conn()
    try:
        _c0.executescript(SCHEMA)
        _l, _cap = left_today(_c0, DEFAULT_MODEL)
        _inf = model_info(DEFAULT_MODEL) or {}
        if int(_inf.get('rpd', 0)) <= 0:
            ck(_l is None and _cap == 0, '한도를 모르면 None 을 낸다')
        else:
            ck(_l is not None, '한도를 알면 수를 낸다')
        ck(left_today(_c0, '(없는모델)') == (None, 0), '모르는 모델도 None')
    finally:
        _c0.close()
    ck(DEFAULT_MODEL in MODEL_NAMES, '기본 모델이 목록에 없다')
    for n in MODEL_NAMES:
        inf = model_info(n)
        ck(inf and inf['out_max'] > 0, '%s: 출력 상한이 비었다' % n)
        ck(inf and inf['in_usd'] > 0 and inf['out_usd'] > 0,
           '%s: 단가가 비었다' % n)
        # 백만 토큰이면 정확히 그 단가여야 한다 — 셈이 도는가
        ck(abs(cost(n, 1000000, 0) - inf['in_usd']) < 1e-9, '%s: 입력 셈' % n)
        ck(abs(cost(n, 0, 1000000) - inf['out_usd']) < 1e-9, '%s: 출력 셈' % n)
    ck(cost('(없는모델)', 1, 1) is None, '모르는 모델이면 None')
    ck(any(not m[6] for m in MODELS), '무료로 못 쓰는 모델을 적어 두었다')
    ck(model_info('__없는모델__') is None, '모르는 모델에 값을 낸다')

    # ② 키 가리기 — **키가 그대로 새면 안 된다**
    ck(mask('AIzaSyABCDEFGHIJKLMNOP') == 'AIzaSy…MNOP', '키 가리기가 틀렸다')
    ck('ABCDEFGHIJ' not in mask('AIzaSyABCDEFGHIJKLMNOP'), '가린 값에 알맹이가 남는다')
    ck(mask('') == '(없음)', '빈 키를 안 말한다')

    # ③ 응답 읽기 — 양방향
    ok_body = json.dumps({'candidates': [{'content': {'parts': [{'text': '가나'}]}}],
                          'usageMetadata': {'promptTokenCount': 7,
                                            'candidatesTokenCount': 3}})
    t, tok, why = _parse(ok_body)
    ck(t == '가나' and tok == {'in': 7, 'out': 3, 'think': 0} and not why, '멀쩡한 응답을 못 읽는다')
    _tb = json.dumps({'candidates': [{'content': {'parts': [{'text': '가'}]}}],
                      'usageMetadata': {'promptTokenCount': 7, 'candidatesTokenCount': 2, 'thoughtsTokenCount': 100}})
    ck(_parse(_tb)[1]['out'] == 102, '생각 토큰을 출력으로 센다(출력 단가로 청구된다)')
    t, _k, why = _parse(json.dumps({'error': {'status': 'RESOURCE_EXHAUSTED',
                                              'message': '한도'}}))
    ck(t is None and 'RESOURCE_EXHAUSTED' in why, '오류 응답을 못 읽는다')
    t, _k, why = _parse(json.dumps({'promptFeedback': {'blockReason': 'SAFETY'}}))
    ck(t is None and 'SAFETY' in why, '안전 필터 거부를 못 읽는다')
    t, _k, why = _parse('<html>')
    ck(t is None and why, 'JSON 이 아닌 것을 통과시킨다')
    t, _k, why = _parse(json.dumps({'candidates': [{'finishReason': 'MAX_TOKENS',
                                                    'content': {'parts': []}}]}))
    ck(t is None and 'MAX_TOKENS' in why, '빈 글을 통과시킨다')

    # ④ 부르기 — **망을 안 탄다**(가짜 응답기를 끼운다)
    conn = None
    try:
        # ★ **진짜 DB 를 열지 않는다** — 위 `_test_conn` 머리글 참조.
        import tempfile
        _fd, _tmp = tempfile.mkstemp(suffix='.aitest.db')
        os.close(_fd)
        conn = _test_conn(_tmp)
        # ★ 열쇠 집도 시험용으로 갈아 끼운다 — 진짜 admin_secrets.db 에 닿지 않는다
        import secret_store as _SS
        _ss_old = _SS.FILE
        _SS.FILE = _tmp + '.secret'
        day = '1900-01-01'                     # 시험용 날짜 — 진짜 집계와 안 섞인다
        conn.execute("DELETE FROM sys_ai_usage WHERE day=?", (day,))
        conn.commit()
        n0 = conn.execute("SELECT COUNT(*) FROM sys_ai_usage").fetchone()[0]
        # ⚠ 가짜 응답기로 부르는 것도 **오늘 날짜로** 사용량을 적는다 —
        #   시험이 진짜 집계를 올리면 「오늘 얼마 썼나」가 거짓이 된다.
        #   ⇒ 오늘 줄을 떠 두고 끝에 **그대로 되돌린다**.
        snap = conn.execute(
            "SELECT model, n_call, n_ok, n_in, n_out FROM sys_ai_usage "
            "WHERE day=?", (_today(),)).fetchall()

        # ⓐ 키가 없으면 그렇게 말한다
        real = keys(conn)
        _SS.put(KEYS, '')
        r = call('x', conn=conn, _post_fn=lambda *a: (200, ok_body))
        ck(not r['ok'] and '키가 없' in r['why'], '키가 없는데 부르려 한다')

        # ⓑ 키 순환 — 첫 키가 429 면 둘째로 넘어간다
        #   ⚠⚠ **한도는 키가 아니라 프로젝트 단위다**(`docs/Rate limits.txt`
        #     「Rate limits are applied per project, not per API key」).
        #     그러니 이 순환은 **다른 프로젝트의 키**를 넣었을 때만 뜻이 있다.
        _SS.put(KEYS, 'KEY_AAAAAAAAAAAA,KEY_BBBBBBBBBBBB')
        seen = []

        def _fake(url, payload, timeout):
            seen.append(url.rsplit('key=', 1)[-1])
            if seen[-1].startswith('KEY_A'):
                return 429, json.dumps({'error': {'status': 'RESOURCE_EXHAUSTED',
                                                  'message': 'quota'}})
            return 200, ok_body
        old_bo = globals()['BACKOFF']
        globals()['BACKOFF'] = (0, 0, 0)       # 시험에서 기다리지 않는다
        try:
            r = call('x', conn=conn, _post_fn=_fake)
        finally:
            globals()['BACKOFF'] = old_bo
        ck(r['ok'] and r['text'] == '가나', '둘째 키로 안 넘어간다: %s' % r.get('why'))
        ck(any(k.startswith('KEY_B') for k in seen), '둘째 키를 안 써 봤다')
        ck('KEY_AAAAAAAAAAAA' not in str(r), '돌려준 값에 키가 그대로 있다')

        # ⓒ 400 은 되풀이하지 않는다 — 다시 해도 같다
        cnt = []

        def _bad(url, payload, timeout):
            cnt.append(1)
            return 400, json.dumps({'error': {'status': 'INVALID_ARGUMENT',
                                              'message': '틀림'}})
        r = call('x', conn=conn, _post_fn=_bad)
        ck(not r['ok'], '400 인데 됐다고 한다')
        ck(len(cnt) == 2, '400 을 되풀이한다(키마다 한 번이라야 한다): %d' % len(cnt))

        # ⓓ 망이 터져도 예외를 안 던진다
        def _boom(url, payload, timeout):
            raise OSError('끊김')
        old_bo = globals()['BACKOFF']
        globals()['BACKOFF'] = (0, 0, 0)
        try:
            r = call('x', conn=conn, _post_fn=_boom)
        finally:
            globals()['BACKOFF'] = old_bo
        ck(not r['ok'] and '망' in r['why'], '망 오류를 안 알린다: %s' % r.get('why'))

        # ⓔ 사용량 — **실패도 센다**
        conn.execute("DELETE FROM sys_ai_usage WHERE day=?", (day,))
        note_usage(conn, 'M', True, 10, 5, day=day)
        note_usage(conn, 'M', False, 0, 0, day=day)
        row = conn.execute("SELECT n_call,n_ok,n_in,n_out FROM sys_ai_usage "
                           "WHERE day=? AND model='M'", (day,)).fetchone()
        ck(row == (2, 1, 10, 5), '사용량 셈이 틀렸다: %s' % (row,))

        # ⓕ 중단 스위치가 이긴다
        try:
            import gcloud_gate
            was = gcloud_gate.paused(conn)
            if not was:
                gcloud_gate.pause(conn, tasks=False)
            r = call('x', conn=conn, _post_fn=lambda *a: (200, ok_body))
            ck(not r['ok'] and '중단' in r['why'], '중단 중인데 부른다')
            if not was:
                gcloud_gate.resume(conn, tasks=False)
            ck(gcloud_gate.paused(conn) == was, '중단 상태를 안 되돌렸다')
        except Exception as e:                            # noqa: BLE001
            bad.append('중단 스위치 검사에서 터졌다: %s' % e)

        # 청소 — **자국 0**
        conn.execute("DELETE FROM sys_ai_usage WHERE day=?", (day,))
        conn.execute("DELETE FROM sys_ai_usage WHERE day=?", (_today(),))
        for _m, _c, _o, _i, _u in snap:
            conn.execute(
                "INSERT INTO sys_ai_usage(day, model, n_call, n_ok, n_in, n_out) "
                "VALUES(?,?,?,?,?,?)", (_today(), _m, _c, _o, _i, _u))
        _SS.put(KEYS, ','.join(real))
        conn.commit()
        ck(conn.execute("SELECT model,n_call,n_ok,n_in,n_out FROM sys_ai_usage "
                        "WHERE day=?", (_today(),)).fetchall() == snap,
           '오늘 사용량을 안 되돌렸다')
        n1 = conn.execute("SELECT COUNT(*) FROM sys_ai_usage").fetchone()[0]
        ck(keys(conn) == real, '키를 안 되돌렸다')
        ck(n0 == n1, '사용량에 자국이 남았다: %s → %s' % (n0, n1))
    except Exception as e:                                # noqa: BLE001
        import traceback
        traceback.print_exc()
        bad.append('DB 검사에서 터졌다: %s' % e)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:                             # noqa: BLE001
                pass
        # 임시 DB 는 지운다 — 못 지워도 진짜 자료와는 무관하다
        try:
            import secret_store as _SS2
            if _SS2.FILE.endswith('.secret'):
                _SS2.FILE = _ss_old
        except Exception:                                 # noqa: BLE001
            pass
        try:
            for _x in (_tmp, _tmp + '.secret'):
                if _x and os.path.exists(_x):
                    os.remove(_x)
        except Exception:                                 # noqa: BLE001
            pass

    # ★★★ **사용자 자료 불변식** — 이 검사가 있었으면 키를 안 잃었다.
    try:
        _rc = _conn()
        try:
            _k = keys(_rc)
            ck(not any(str(x).startswith('KEY_AAAA') or
                       str(x).startswith('KEY_BBBB') for x in _k),
               '진짜 DB 에 시험용 가짜 키가 남았다')
            _u = _rc.execute("SELECT COUNT(*) FROM sys_ai_usage "
                             "WHERE day='1900-01-01'").fetchone()[0]
            ck(_u == 0, '진짜 DB 에 시험용 집계가 남았다')
        finally:
            _rc.close()
    except Exception as e:                                # noqa: BLE001
        bad.append('불변식 검사에서 터졌다: %s' % e)

    n_all = _nck[0]
    for b in bad:
        print('  FAIL ' + b)
    print('ai_client selftest: %s (%d/%d)'
          % ('OK' if not bad else 'FAIL', n_all - len(bad), n_all))
    return 0 if not bad else 1


# ══════════════════════════════════════════════════════════════════

def _main(argv):
    if '--selftest' in argv:
        return selftest()
    if '--models' in argv:
        for n, rpd, rpm, om, iu, ou, fr, note in MODELS:  # rpd 0 = 안 쟀다
            print('  %-24s 하루 %5s · 분당 %2s · 출력 %6s토큰   %s'
                  % (n, rpd, rpm, om,
                     '입력 $%.2f · 출력 $%.2f /1M · 무료 %s · %s'
                     % (iu, ou, '가능' if fr else '불가', note)))
        print('\n⚠ 구글 문서의 무료 등급 값이다 — `--ping` 으로 실제를 확인한다.')
        return 0
    conn = _conn()
    if '--set-keys' in argv:
        v = argv[argv.index('--set-keys') + 1]
        n = set_keys(conn, v.split(','))
        print('키 %d개 저장' % n)
        return 0
    if '--status' in argv:
        ks = keys(conn)
        print('키 %d개 — %s' % (len(ks), ', '.join(mask(k) for k in ks) or '(없음)'))
        print('모델 %s' % model_of(conn))
        try:
            import gcloud_gate
            print('구글 클라우드 %s' % ('중단' if gcloud_gate.paused(conn) else '쓰는 중'))
        except Exception:                                 # noqa: BLE001
            pass
        rows = usage(conn)
        if not rows:
            print('오늘 쓴 것 없음')
        for m, c, o, i, u in rows:
            l, cap = left_today(conn, m)
            print('  %-24s 부름 %4s · 됨 %4s · 입력 %7s · 출력 %7s   (문서상 한도 %s 중 %s 남음)'
                  % (m, c, o, i, u, cap, l))
        return 0
    if '--ping' in argv:
        r = call('한 단어로만 답하세요: 안녕', conn=conn, max_out=32)
        print('됨' if r['ok'] else '안 됨 — ' + r['why'])
        if r['ok']:
            print('  모델 %s · 키 %s · 토큰 %s' % (r['model'], r['key'], r['tokens']))
            print('  받은 글: %r' % r['text'][:80])
        return 0 if r['ok'] else 1
    print(__doc__)
    return 0


if __name__ == '__main__':
    sys.exit(_main(sys.argv[1:]))
