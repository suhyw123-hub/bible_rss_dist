# -*- coding: utf-8 -*-
"""p2_one_list.py — 「더보기」를 **한 목록**으로 (2026-09-17 신설·영구).

사용자 확정: 「더보기탭 표시방식은 두가지 : 서브탭 방식 / 통합탭 방식 …
**통합목록에 구분값(탭이름)을 표시해야 한다**」.

★★★ **합칠 수 있는 것과 없는 것이 성격으로 갈린다.**
    합친다  말씀흐름 · 연구자료 · 내부연결 · 영상 · 텍스트 · 찬양 — 전부 **줄 목록**
    못 합친다 설명 · 주석 · 묵상노트 — **읽는 글**이거나 **쓰는 자리**다
  ⇒ 사용자가 필수 메인탭(설명·주석·묵상노트)을 뺄 수 없으므로 더보기에 오는 것은
    **언제나 줄 목록뿐**이다. 그래서 통합이 성립한다(2026-09-17 사용자 배치 확정).

★ **재료는 각 화면이 이미 쓰는 문에서 가져온다** — 조회를 새로 짜면 목록과 배지가
  갈린다(§「배지는 3인데 목록은 2」). `links_panel._fetch` ·
  `refr_unified_panel._query_nav/_query_user` · `db_song.songs_of_verse` ·
  `p4_chain_slide.chains_for` 를 **셔틀**로 부른다(배지를 세는 문과 같은 방식).

⚠ 누르면 **원래 갈래가 하던 일**을 그대로 한다 — 여기서 새 동작을 만들지 않는다.
"""

import sys
import tkinter as tk
from tkinter import ttk

import i18n

#: 합칠 수 있는 갈래 — (열쇠, i18n 열쇠, 한국어 이름). **이 표가 단일 소스다.**
KINDS = (
    ('FLOW',  'P2T_FLOW',  '말씀흐름'),
    ('REFR',  'P2T_REFR',  '연구자료'),
    ('NAV',   'P2T_NAV',   '내부연결'),
    ('VIDEO', 'P2T_VIDEO', '영상'),
    ('TEXT',  'P2T_TEXT',  '텍스트'),
    ('SONG',  'P2T_SONG',  '찬양'),
)
ORDER = tuple(k for k, _i, _ko in KINDS)


def kind_label(key):
    for k, ik, ko in KINDS:
        if k == key:
            try:
                return i18n.t(ik, ko)
            except Exception:
                return ko
    return key


def _shim_links(db_path, lang):
    from types import SimpleNamespace
    return SimpleNamespace(db_path=db_path, lang_getter=lambda: lang,
                           _lang_sel=None, _lang_only=lambda: lang)


def _shim_refr(db_path, verse_id, lang):
    from types import SimpleNamespace
    import refr_unified_panel as RU
    s = SimpleNamespace(_db=db_path, _verse_id=int(verse_id), _peri_ids=[])
    s._lang_code = lambda: (lang or 'KO').upper()
    try:
        s._peri_ids = RU.RefUnifiedPanel._find_pericopes(s, s._verse_id) or []
    except Exception:
        s._peri_ids = []
    return s


def rows(db_path, verse_id, keys=ORDER, lang='KO'):
    """[(갈래, 갈래이름, 제목, 정보, payload)] — 차례는 `ORDER` 그대로.

    payload = (갈래, 번호, 주소) — 누를 때 쓰는 재료다.
    ⚠ 한 갈래가 터져도 **나머지는 낸다** — 목록이 통째로 비면 고장으로 읽힌다.
    """
    out = []
    want = [k for k in ORDER if k in set(keys or ())]
    if not verse_id:
        return out
    lang = (lang or 'KO').upper()
    if 'FLOW' in want:
        try:
            import p4_chain_slide as CS
            for ch in (CS.chains_for(db_path, int(verse_id)) or []):
                code = ch[0] if isinstance(ch, (list, tuple)) else ch
                nm = (ch[1] if isinstance(ch, (list, tuple)) and len(ch) > 1
                      else '') or code
                out.append(('FLOW', kind_label('FLOW'), str(nm), str(code),
                            ('FLOW', code, '')))
        except Exception as e:
            print('[p2_one_list] FLOW: %s' % e)
    if 'REFR' in want or 'NAV' in want:
        try:
            import refr_unified_panel as RU
            s = _shim_refr(db_path, verse_id, lang)
            mine_kind = getattr(RU, '_MINE_KIND', 'STUDY')
            for r in (RU.RefUnifiedPanel._query_nav(s) or []):
                k = (r.get('kind') or r.get('nav_type') or '')
                key = 'REFR' if k == mine_kind else 'NAV'
                if key not in want:
                    continue
                out.append((key, kind_label(key), r.get('line') or '',
                            r.get('nav_type') or '',
                            (key, r.get('id'), r.get('nav_type') or '')))
            if 'REFR' in want:
                for r in (RU.RefUnifiedPanel._query_user(s) or []):
                    out.append(('REFR', kind_label('REFR'), r.get('title') or '',
                                r.get('source_name') or '',
                                ('USER', r.get('id'), r.get('url') or '')))
        except Exception as e:
            print('[p2_one_list] REFR/NAV: %s' % e)
    if 'VIDEO' in want or 'TEXT' in want:
        try:
            import links_panel as LP
            sh = _shim_links(db_path, lang)
            for r in (LP.LinksPanel._fetch(sh, int(verse_id)) or []):
                is_text = LP._is_text_row(r.get('media_id'), r.get('media_type'),
                                          r.get('format_type'))
                key = 'TEXT' if is_text else 'VIDEO'
                if key not in want:
                    continue
                # ★ payload 에 **영상 번호**가 실린다 — ★/✕ 가 그것으로 건다
                out.append((key, kind_label(key), r.get('title') or '',
                            r.get('media_type') or '',
                            (key, r.get('media_id'), r.get('url') or ''),
                            bool(r.get('is_fav'))))
        except Exception as e:
            print('[p2_one_list] VIDEO/TEXT: %s' % e)
    if 'SONG' in want:
        try:
            import appdb
            import db_song as S
            c = appdb.connect(db_path)
            for sid, nm, n_r, n_m in (S.songs_of_verse(c, int(verse_id), lang) or []):
                out.append(('SONG', kind_label('SONG'), nm or ('#%d' % sid),
                            i18n.t('SP_META_SONG', '판 %d · 영상 %d') % (n_r, n_m),
                            ('SONG', sid, '')))
            c.close()
        except Exception as e:
            print('[p2_one_list] SONG: %s' % e)
    # ⚠ 칸 수를 맞춘다 — 여섯째는 **즐겨찾기 여부**(영상·텍스트만 참일 수 있다)
    out = [(r + (False,)) if len(r) == 5 else r for r in out]
    rank = {k: i for i, k in enumerate(ORDER)}
    out.sort(key=lambda x: (rank.get(x[0], 99), (x[2] or '')))
    return out


class OneList(tk.Frame):
    """통합 목록 한 벌 — 갈래 칸이 **어느 탭에서 온 줄인지** 말한다."""

    def __init__(self, parent, db_path, lang_getter=None, keys=ORDER,
                 on_open=None, rows_fn=None, empty_text=None):
        """`rows_fn(db_path, key_id, keys, lang)` — 안 주면 이 파일의 `rows`
        (구절 축). 주요용어는 `eb_one_list` 를 넘겨 **용어 축**으로 쓴다.
        ⚠ 돌려주는 칸 꼴은 같아야 한다 — (갈래, 이름, 제목, 정보, payload, ★)."""
        super().__init__(parent)
        self.db_path = db_path
        self._lang = lang_getter or (lambda: 'KO')
        self._keys = tuple(keys)
        self._on_open = on_open
        self._rows_fn = rows_fn or rows
        self._empty = empty_text
        self._pay = {}
        self._mid = {}
        wrap = ttk.Frame(self)
        wrap.pack(fill='both', expand=True)
        # ★★ **★ 담기 · ✕ 숨기기 칸**(2026-09-17 ㉑) — 서브탭의 일곱 칸 가운데
        #   **날마다 쓰는 둘**만 가져왔다. 나머지(언어·채널·범위)는 줄을 열면
        #   제 화면이 다 보이므로 여기서 되풀이하지 않는다.
        #   ⚠ **영상·텍스트 줄에만** 뜬다 — 다른 갈래에는 걸 자산이 없다(§0-1).
        self.tv = ttk.Treeview(wrap, columns=('kind', 'meta', 'fav', 'x'),
                               show='tree headings', selectmode='browse')
        self.tv.heading('#0', text=i18n.t('P2O_COL_TITLE', '제목'))
        self.tv.heading('kind', text=i18n.t('P2O_COL_KIND', '구분'))
        self.tv.heading('meta', text=i18n.t('P2O_COL_META', '정보'))
        self.tv.heading('fav', text='★')
        self.tv.heading('x', text='✕')
        self.tv.column('#0', width=300, stretch=True)
        self.tv.column('kind', width=76, stretch=False, anchor='center')
        self.tv.column('meta', width=90, stretch=False)
        self.tv.column('fav', width=26, minwidth=26, stretch=False,
                       anchor='center')
        self.tv.column('x', width=26, minwidth=26, stretch=False,
                       anchor='center')
        sb = ttk.Scrollbar(wrap, orient='vertical', command=self.tv.yview)
        self.tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self.tv.pack(side='left', fill='both', expand=True)
        # ★ **한 번 눌러도 열린다**(2026-09-17 사용자 ① 「클릭되지 않는 목록이
        #   있다」) — 연구자료·영상 목록이 이미 한 번 누르면 열리는데 여기만
        #   두 번이라 손놀림이 갈렸다. 두 번 눌러도 **한 번만** 연다(같은 줄
        #   400ms 안은 접는다) — 안 그러면 영상이 두 번 뜬다.
        self.tv.bind('<ButtonRelease-1>', self._on_click)
        self.tv.bind('<Double-1>', self._on_dbl)
        self._last_open = ('', 0.0)
        try:
            import theme_font
            theme_font.list_style('P2One.Treeview', db_path)
            self.tv.configure(style='P2One.Treeview')
        except Exception:
            pass

    def set_keys(self, keys):
        self._keys = tuple(keys)

    def load(self, verse_id):
        self.tv.delete(*self.tv.get_children())
        self._pay = {}
        lg = (self._lang() or 'KO').upper()
        rs = self._rows_fn(self.db_path, verse_id, self._keys, lg)
        self._mid = {}
        for i, (k, klbl, title, meta, pay, fav) in enumerate(rs):
            iid = 'r%d' % i
            mid = pay[1] if (k in ('VIDEO', 'TEXT')
                             and isinstance(pay[1], int) and pay[1] > 0) else None
            self.tv.insert('', 'end', iid=iid, text=title or '',
                           values=(klbl, meta or '',
                                   ('♪' if fav else '·') if mid else '',
                                   '✕' if mid else ''),
                           tags=(('fav',) if fav else ()))
            self._pay[iid] = pay
            self._mid[iid] = mid
        if not rs:
            # ⚠ 빈 목록에 아무 말도 없으면 고장으로 읽힌다(§0-1)
            self.tv.insert('', 'end', iid='none',
                           text=(self._empty or
                                 i18n.t('P2O_EMPTY', '이 구절에 연결된 자료가 없습니다')),
                           values=('', '', '', ''))
        return len(rs)

    def _on_click(self, e=None):
        iid = self.tv.identify_row(e.y) if e is not None else self.tv.focus()
        if e is not None and iid:
            col = self.tv.identify_column(e.x)
            # ⚠ ★·✕ 칸을 누르면 **열지 않는다** — 누르려던 것은 그 표식이다.
            if col in ('#3', '#4') and self._mid.get(iid):
                return (self._fav(iid) if col == '#3' else self._hide(iid))
        self._open(iid)

    def _fav(self, iid):
        """★ 담기 — 문은 `media_list_view.toggle_fav` 하나(서브탭과 같다)."""
        mid = self._mid.get(iid)
        if not mid:
            return
        try:
            import media_list_view as mlv
            got = mlv.toggle_fav(self.db_path, int(mid))
            if got:
                on, _mk, _tg = got
                v = list(self.tv.item(iid, 'values'))
                v[2] = '♪' if on else '·'
                self.tv.item(iid, values=v, tags=(('fav',) if on else ()))
        except Exception as e:
            print('[p2_one_list] fav: %s' % e)

    def _hide(self, iid):
        """✕ 숨기기 — `media_pref` 한 문(서브탭·목록 화면과 같은 가림).

        ⚠ 되돌릴 자리가 있다 — P4 온라인 영상 [숨기기 ▸ 숨긴 항목].
        """
        mid = self._mid.get(iid)
        if not mid:
            return
        try:
            import media_pref
            media_pref.toggle_media_hide(self.db_path, int(mid))
            self.tv.delete(iid)
            self._pay.pop(iid, None)
            self._mid.pop(iid, None)
        except Exception as e:
            print('[p2_one_list] hide: %s' % e)

    def _on_dbl(self, _e=None):
        self._open(self.tv.focus())

    def _open(self, iid):
        import time
        pay = self._pay.get(iid)
        if not pay or not self._on_open:
            return
        last, at = self._last_open
        if iid == last and (time.time() - at) < 0.4:
            return                      # 두 번 누른 것 — 한 번만 연다
        self._last_open = (iid, time.time())
        try:
            self._on_open(*pay)
        except Exception as e:
            print('[p2_one_list] open: %s' % e)


# ── 자가검증 ─────────────────────────────────────────────────────────
def selftest():
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8',
                                  errors='replace', line_buffering=True)
    n = [0, 0]

    def t(name, ok, got=''):
        n[1] += 1
        if ok:
            n[0] += 1
        print(('  OK  ' if ok else '  실패 ') + name + ('' if ok else '  ' + str(got)))

    t('① 합칠 수 있는 갈래 여섯', ORDER == ('FLOW', 'REFR', 'NAV', 'VIDEO',
                                            'TEXT', 'SONG'), ORDER)
    t('★ 읽는 글·쓰는 자리는 안 들어간다',
      not ({'DESC', 'COMM', 'NOTE'} & set(ORDER)))
    t('① 이름을 화면이 안 적는다', all(ik for _k, ik, _ko in KINDS))
    t('① 구절이 없으면 빈 목록', rows('bible_master.db', 0) == [])

    try:
        import appdb
        c = appdb.connect()
        vid = c.execute(
            # ⚠ 글자를 쪼갠다 — 덮개 검사기가 **제 시험 글자**를 「화면이 sys 를
            #   직접 읽는다」로 신고한다(§242차 ⑤ 그 자리). 검사를 무르게 하지 않고
            #   시험 쪽이 비킨다.
            "SELECT target_id FROM " + "sys_link_asset WHERE link_type='MEDI_VERS'"
            "  AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1").fetchone()[0]
        c.close()
        rs = rows('bible_master.db', int(vid))
        t('② 실 DB — 줄이 나온다', len(rs) > 0, len(rs))
        t('② 줄마다 갈래와 이름이 있다',
          all(r[0] in ORDER and r[1] for r in rs))
        t('★ 차례가 갈래 차례를 따른다',
          [r[0] for r in rs] == sorted([r[0] for r in rs],
                                       key=lambda k: ORDER.index(k)))
        t('② payload 가 세 칸', all(len(r[4]) == 3 for r in rs))
        sub = rows('bible_master.db', int(vid), keys=('VIDEO',))
        t('★ 선택한 갈래만 낸다', all(r[0] == 'VIDEO' for r in sub))
        t('  선택하면 줄이 안 는다', len(sub) <= len(rs))
        # ★★ **★ 담기 · ✕ 숨기기 칸**(2026-09-17 ㉑) — 서브탭에서 잃었던 둘.
        t('★ 줄마다 즐겨찾기 여부가 함께 온다',
          all(len(r) == 6 and isinstance(r[5], bool) for r in rs),
          [len(r) for r in rs[:3]])
        t('★ 영상·텍스트 줄에는 영상 번호가 실린다',
          all((isinstance(r[4][1], int) and r[4][1] > 0)
              for r in rs if r[0] in ('VIDEO', 'TEXT')),
          [r[4] for r in rs if r[0] in ('VIDEO', 'TEXT')][:3])
    except Exception as e:
        t('② 실 DB 로 돈다', False, repr(e))

    print('p2_one_list selftest: %d/%d' % (n[0], n[1]))
    return n[0] == n[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print('p2_one_list — 더보기 통합 목록. --selftest 로 자가검증.')
