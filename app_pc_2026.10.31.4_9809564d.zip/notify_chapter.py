# -*- coding: utf-8 -*-
"""notify_chapter.py — 한 장의 '제1절' 신표준 내용을 txt로 만들어 텔레그램 전송.

사용: python notify_chapter.py <bcode> <chapter>
  예: python notify_chapter.py 1 4   # 창세기 4장 1절 내용 발송
무인 자동 루프가 장 완료 시 호출. 출력 txt는 notify_out/ 에 보관.
"""
import os
import sys
import appdb
import notify

OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'notify_out')

_TYPE_LABEL = {
    ('VERS_DESC', 'EXPERT'): '전문 설명 (EXPERT)',
    ('VERS_DESC', 'LAY'): '일반 설명 (LAY)',
    ('VERS_QUESTION', 'EXPERT'): '연구 질문',
    ('VERS_QUESTION', 'LAY'): '묵상 질문',
    ('VERS_PRAYER', None): '묵상 기도',
}
_ORDER = [('VERS_DESC', 'EXPERT'), ('VERS_DESC', 'LAY'),
          ('VERS_QUESTION', 'EXPERT'), ('VERS_QUESTION', 'LAY'),
          ('VERS_PRAYER', None)]


def _book_name(c, bcode):
    for sql, args in (
        ("SELECT full_name FROM book_names WHERE book_code=? AND lang_code='KO'", (bcode,)),
        ("SELECT full_name FROM book_names WHERE book_code=? AND lang_code='EN'", (bcode,)),
    ):
        try:
            r = c.execute(sql, args).fetchone()
            if r and r[0]:
                return r[0]
        except Exception:
            pass
    return f'book{bcode}'


def _one(c, vid, tt, variant, lang):
    if variant is None:
        row = c.execute("SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type=? "
                        "AND text_variant IS NULL AND lang_code=? AND COALESCE(record_status,'LIVE')='LIVE' "
                        "ORDER BY sys_text_id DESC LIMIT 1", (vid, tt, lang)).fetchone()
    else:
        row = c.execute("SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type=? "
                        "AND text_variant=? AND lang_code=? AND COALESCE(record_status,'LIVE')='LIVE' "
                        "ORDER BY sys_text_id DESC LIMIT 1", (vid, tt, variant, lang)).fetchone()
    return (row[0] if row and row[0] else '').strip()


def build_txt(bcode, chapter):
    c = appdb.connect('bible_master.db')
    try:
        bi = c.execute("SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=1",
                       (bcode, chapter)).fetchone()
        if not bi:
            return None, None
        vid = bi[0]
        bk = _book_name(c, bcode)
        krv = c.execute("SELECT verse_text FROM bible_content WHERE verse_id=? AND version_code='KRV'", (vid,)).fetchone()
        bsb = c.execute("SELECT verse_text FROM bible_content WHERE verse_id=? AND version_code='BSB'", (vid,)).fetchone()
        L = []
        L.append(f"{bk} {chapter}:1  (신표준 절별자산)")
        L.append("=" * 60)
        if krv:
            L.append(f"[KRV] {krv[0]}")
        if bsb:
            L.append(f"[BSB] {bsb[0]}")
        L.append("")
        for tt, var in _ORDER:
            label = _TYPE_LABEL[(tt, var)]
            ko = _one(c, vid, tt, var, 'KO')
            en = _one(c, vid, tt, var, 'EN')
            L.append(f"{label}")
            L.append(f"  [KO] {ko or '(없음)'}")
            L.append(f"  [EN] {en or '(none)'}")
            L.append("")
        txt = "\n".join(L)
        os.makedirs(OUT_DIR, exist_ok=True)
        path = os.path.join(OUT_DIR, f"{bk}_{chapter:03d}_v1.txt")
        with open(path, 'w', encoding='utf-8') as f:
            f.write(txt)
        return path, bk
    finally:
        c.close()


def main():
    if len(sys.argv) < 3:
        print('usage: python notify_chapter.py <bcode> <chapter>')
        return 1
    bcode, chapter = int(sys.argv[1]), int(sys.argv[2])
    path, bk = build_txt(bcode, chapter)
    if not path:
        print(f'[notify_chapter] {bcode}:{chapter} 1절 없음')
        return 1
    res = notify.send_document(path, caption=f"✅ {bk} {chapter}장 완료 — 1절 신표준 내용(KO/EN)")
    print('SENT' if res.get('ok') else f'FAIL: {res}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
