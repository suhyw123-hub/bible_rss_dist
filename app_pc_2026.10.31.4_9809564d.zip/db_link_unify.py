# -*- coding: utf-8 -*-
"""db_link_unify.py — 연결 통합의 **0단계**: 받는 그릇을 넓힌다 (영구 도구).

**무엇을 하나.** `sys_link_asset`/`user_link_asset` 에
  ① **양방향 덮개 인덱스** ② **곁다리 칸 여섯**
을 더한다. **데이터는 한 줄도 안 옮긴다** — 옮기는 것은 다음 단계다.

★ **표 모양은 사용자가 처음부터 설계한 그대로다** (2026-08-24 사용자 정정):
    「`sys_link_asset` 은 A를 B와 연결시킨다는 값만 저장한 것이 아니라,
      **연결타입이 VERS_VERS이므로 A는 구절이고 B도 구절**이므로 각각
      vid를 찾으면 된다. 연결타입이 도서_구절이라면 A는 도서번호,
      B는 구절번호를 찾아가면 된다.」
  ⇒ **`a_scope`/`b_scope` 같은 칸을 만들지 않는다.** 종류는 `link_type` 이
    말한다. 사용자 렌즈처럼 번호가 겹치는 자산은 **`link_type` 쪽 코드를
    가른다**(`TAG_LENS` ↔ `TAG_ULEN`) — 태그가 이미 그렇게 하고 있다.

★★ **왜 인덱스가 먼저인가.** 지금 것은 `(link_type, clicked_id, …)` 로
  시작해서 **`clicked_id` 만으로는 못 쓴다.** 같은 계열의 `sys_text_asset`
  에서 실측한 값 — 번호만 8.103ms → **0.054ms(149배)**. 연결은 지금
  4,018행이라 안 아프지만 **43만 행으로 자랄 표**다.

★ **곁다리 칸 여섯은 실측으로 골랐다** (23개 표의 칸을 전부 세었다).
  나머지는 전부 `rel_code` 하나로 들어간다 — `link_kind`·`link_role`·
  `verse_role`·`role_in_peri`·`scope` 는 **이름만 다른 같은 것**(「이 연결이
  어떤 성격인가」)이다.
  ⚠ **`is_milestone` 은 만들지 않는다** — `milestone_type IS NOT NULL` 과
    **양방향 0건 어긋남**(1,622행 실측). 중복 칸이다.
  ⚠ **`a_end` 도 만들지 않는다** — `user_link` 362행에서 `a_end` 는 **전부
    비어 있고** `b_end` 만 쓴다. 이미 있는 `end_id` 가 그 자리다.

⚠ 이 도구는 **표를 넓히기만** 한다. 좁히지 않는다(`DROP COLUMN` 없음).
⚠ 표가 없는 DB 에서도 안 죽는다(건너뛰고 알린다).

사용:
    python db_link_unify.py --selftest    (의무)
    python db_link_unify.py --check
    python db_link_unify.py --apply       (멱등)
    python db_link_unify.py --report      (실행계획·규모)
"""
import sys
import time

import appdb

PREFIX = 'idx_link_'        # ⚠ 이 접두가 붙은 것만 `--drop` 이 지운다

#: (스키마, 표) — 받는 그릇 둘
TABLES = [
    ('main', 'sys_link_asset'),
    ('userdb', 'user_link_asset'),
]

#: (이름꼬리, 칸, 왜)
INDEXES = [
    ('a', 'clicked_id, link_type, target_id, rel_code',
     '「A를 눌렀을 때 걸린 것 전부」 — 지금 인덱스는 link_type 으로 시작해 못 쓴다'),
    ('b', 'target_id, link_type, clicked_id, rel_code',
     '「B를 눌렀을 때 걸린 것 전부」 — 연결은 방향이 없으므로 반대쪽도 같은 값이다'),
]

# ── 같은 연결을 두 번 담지 않게 ───────────────────────────────────────────────

#: 옛 유일 인덱스 — **지운다**. 아래에 왜.
OLD_UNQ = {'sys_link_asset': 'idx_sys_link_unq',
           'user_link_asset': 'idx_user_link_unq'}

UNQ_TAIL = 'unq'

#: ★★ **새 유일 열쇠.** 옛 것은 `(link_type, clicked_id, target_id, rel_code)` 라
#   두 가지를 잘못했다:
#     ⚠⚠ ① **구간을 안 본다.** 사용자가 창세기에 세 구간을 걸어 두었는데
#       (`창1:1~50:26` · `~1:31` · `~1:2`) 옛 열쇠로는 **셋이 한 짝**이라
#       옮기면서 둘이 사라진다(실측으로 잡았다).
#     ⚠⚠ ② **`rel_code` 가 NULL 이면 안 막는다.** SQLite 는 UNIQUE 에서 NULL 을
#       서로 다르다고 본다 — 그래서 `TAG_*` 처럼 관점이 없는 연결은
#       **중복이 그대로 들어갔다.**
#   ⇒ `COALESCE` 로 둘 다 고친다(`db_user_ref_schema` 가 이미 쓰는 방식).
#
#   ★ **`WHERE … LIVE` — 살아 있는 것만 유일하다.** 숨긴 흔적(HIDE)까지 유일할
#     까닭이 없다. 실측으로 그 자리를 찾았다 — 노드 149↔창1:2 가 HIDE 하나,
#     LIVE 하나로 남아 있었다(지웠다 다시 넣은 정상 이력이다).
UNQ_COLS = ("link_type, clicked_id, target_id, COALESCE(rel_code,''),"
            " COALESCE(end_id, target_id)")
UNQ_WHERE = "COALESCE(record_status,'LIVE')='LIVE'"

#: 칸 이름 → (형, 어느 표에서 왔나, 왜)
#  ⚠ 순서를 바꾸지 말 것 — `--check` 출력이 이 차례로 나온다.
COLUMNS = [
    ('note', 'TEXT',
     'sys_plan_route 49 · user_link 362', '사람이 적어 둔 메모'),
    ('milestone_type', 'TEXT',
     'sys_entity_pericope', '생애의 국면 — CALL·FORMATION·LEGACY …'),
    ('importance', 'INTEGER',
     'sys_entity_pericope 1,622', '3~10 이 실제로 쓰인다(목록 정렬)'),
    ('is_key', 'INTEGER',
     'sys_entity_verse 360', '그 낱말의 대표 절인가'),
    ('source', 'TEXT',
     'sys_book_unit_entity 170', '무엇을 근거로 이었나'),
    ('confidence', 'TEXT',
     'sys_media_link', '얼마나 확실한가 — EXACT·CHAPTER …'),
    # ⚠ 처음에 뺐다가 **실측으로 되돌린 칸**(2026-08-24). 「연결의 성격이 아니라
    #   참조라 필요 없다」고 판단했는데, `sys_entity_verse` **18,868행 중
    #   18,867행**이 이것을 갖고 `db_term_load --show/--list` 가 읽는다.
    #   빼면 「그 원어 낱말이 몇 절에 나오나」를 셀 길이 사라진다.
    ('lemma_id', 'INTEGER',
     'sys_entity_verse 18,867', '어느 원어 낱말에서 왔나(sys_entity_lemma)'),
    # ⚠⚠ **곁다리가 아니라 「두 표의 모양을 맞추는」 칸**(2026-08-24).
    #   `sys_link_asset` 에는 원래 있는데 `user_link_asset` 에만 없어서,
    #   개인 쪽으로 옮기는 첫 배치가 **`no column named chain_code` 로 터졌다.**
    #   앞선 배치는 전부 `main` 이라 안 걸렸다 — **두 표를 같은 모양으로 둔다.**
    ('chain_code', 'TEXT',
     'sys 에는 원래 있다', '구속사 흐름 — 개인 쪽에도 자리를 맞춘다'),
    # ── 인물 관계(2026-08-25 12차) ────────────────────────────────────────
    # ⚠ **`rel_code` 로 못 접는 두 칸이다** — 실측으로 확인했다.
    #   · `is_directed` 는 **6개 유형에서 값이 갈린다**(CO_WORKER·ENEMY·KIN·
    #     RIVAL·CONFLICT_TEMP·SACRED_ENCOUNTER) ⇒ 유형만으로 정해지지 않는다.
    #     읽는 코드는 지금 **한 곳도 없지만** 데이터라 버리지 않는다
    #     (`is_milestone` 은 **파생값**이라 뺐고, 이건 입력값이라 남긴다).
    #   · `relation_cat` 은 22/23 유형이 1:1 인데 **ORACLE 만 갈린다**
    #     (SPIRITUAL 9 · SOCIAL 1). 파생하면 그 한 행을 조용히 고치게 된다.
    #     그리고 **주요용어 화면이 읽는다**(`entity_browser` 그룹 정렬).
    ('is_directed', 'INTEGER',
     'sys_person_relation 136', '한쪽으로만인가(1) 서로인가(0)'),
    ('relation_cat', 'TEXT',
     'sys_person_relation 136', '관계의 묶음 — FAMILY·SOCIAL·SPIRITUAL'),
]


# ── 살펴보기 ────────────────────────────────────────────────────────────────

def _tables(conn, sch):
    return {r[0] for r in conn.execute(
        "SELECT name FROM %s.sqlite_master WHERE type='table'" % sch)}


def _indexes(conn, sch):
    return {r[0] for r in conn.execute(
        "SELECT name FROM %s.sqlite_master WHERE type='index'" % sch)}


def _columns(conn, sch, tbl):
    return {r[1] for r in conn.execute('PRAGMA %s.table_info(%s)' % (sch, tbl))}


def _idx_name(tbl, tail):
    """`idx_link_sys_link_asset_a` 꼴 — 표마다 갈라야 이름이 안 부딪힌다."""
    return '%s%s_%s' % (PREFIX, tbl, tail)


def unq_conflicts(conn, sch, tbl):
    """새 유일 열쇠로 **부딪히는 무리**. 인덱스를 만들기 전에 반드시 센다.

    돌려주는 것 = [(link_type, A, B, rel, end, 몇 건)] — 비어야 만들 수 있다.
    """
    return list(conn.execute("""
        SELECT link_type, clicked_id, target_id, COALESCE(rel_code,''),
               COALESCE(end_id, target_id), COUNT(*)
          FROM %s.%s WHERE %s
         GROUP BY 1,2,3,4,5 HAVING COUNT(*) > 1
         ORDER BY 6 DESC""" % (sch, tbl, UNQ_WHERE)))


def check(conn, verbose=True):
    """아직 없는 것 목록. 비어 있으면 다 맞다.

    돌려주는 것 = (없는 인덱스, 없는 칸)
    """
    miss_i, miss_c = [], []
    for sch, tbl in TABLES:
        if tbl not in _tables(conn, sch):
            if verbose:
                print('  (건너뜀) %s.%s 표가 없다' % (sch, tbl))
            continue
        if verbose:
            print('\n  ── %s.%s ' % (sch, tbl) + '─' * (56 - len(tbl)))
        have_i = _indexes(conn, sch)
        for tail, cols, why in INDEXES:
            name = _idx_name(tbl, tail)
            if name in have_i:
                if verbose:
                    print('    있음   %-34s %s' % (name, cols))
            else:
                miss_i.append((sch, tbl, name, cols, why))
                if verbose:
                    print('    **없음** %-34s %s' % (name, cols))
                    print('             ↳ %s' % why)
        # 유일 열쇠 — 구간과 NULL 을 함께 본다
        uname = _idx_name(tbl, UNQ_TAIL)
        if uname in have_i:
            if verbose:
                print('    있음   %-34s (유일)' % uname)
        else:
            miss_i.append((sch, tbl, uname, UNQ_COLS,
                           '같은 연결을 두 번 담지 않는다 — **구간과 NULL 까지 본다**'))
            if verbose:
                bad = unq_conflicts(conn, sch, tbl)
                print('    **없음** %-34s (유일)' % uname)
                print('             ↳ %s' % UNQ_COLS)
                print('             ↳ 지금 부딪히는 무리 **%d개**%s'
                      % (len(bad), '' if not bad else ' ⚠ 먼저 정리해야 만든다'))
                for r in bad[:5]:
                    print('                %-12s A=%-7s B=%-7s rel=%-8s end=%-7s ×%s' % r)
        have_c = _columns(conn, sch, tbl)
        for col, typ, whence, why in COLUMNS:
            if col in have_c:
                if verbose:
                    print('    있음   %-16s %-8s' % (col, typ))
            else:
                miss_c.append((sch, tbl, col, typ, whence, why))
                if verbose:
                    print('    **없음** %-16s %-8s ← %s' % (col, typ, whence))
                    print('             ↳ %s' % why)
    return miss_i, miss_c


def apply(conn, verbose=True):
    """멱등. 이미 있으면 건너뛴다."""
    miss_i, miss_c = check(conn, verbose=False)
    # ⚠ 칸을 먼저 만든다 — 인덱스가 그 칸을 쓸 수도 있다(지금은 아니지만
    #   차례를 뒤집어 두면 나중에 칸을 인덱스에 넣을 때 조용히 깨진다)
    for sch, tbl, col, typ, _w, _y in miss_c:
        conn.execute('ALTER TABLE %s.%s ADD COLUMN %s %s' % (sch, tbl, col, typ))
        if verbose:
            print('  칸 만듦   %s.%s.%s %s' % (sch, tbl, col, typ))
    for sch, tbl, name, cols, _why in miss_i:
        t0 = time.perf_counter()
        if name.endswith('_' + UNQ_TAIL):
            # ⚠ 부딪히는 것이 있으면 **만들지 않고 알린다**(조용히 넘어가면
            #   중복이 그대로 남고 나중에 데이터가 접힌다)
            bad = unq_conflicts(conn, sch, tbl)
            if bad:
                if verbose:
                    print('  ⚠ %s — 부딪히는 무리 %d개라 못 만든다. 먼저 정리할 것'
                          % (name, len(bad)))
                continue
            conn.execute('CREATE UNIQUE INDEX IF NOT EXISTS %s.%s ON %s(%s) WHERE %s'
                         % (sch, name, tbl, cols, UNQ_WHERE))
            # ★ 옛 유일 인덱스를 **지운다** — 남겨 두면 그것이 구간을 못 보고
            #   먼저 막아 버려서 새 인덱스가 뜻을 잃는다.
            old = OLD_UNQ.get(tbl)
            if old and old in _indexes(conn, sch):
                conn.execute('DROP INDEX %s.%s' % (sch, old))
                if verbose:
                    print('  옛 유일    %-34s 지웠다(구간을 못 본다)' % old)
        else:
            conn.execute('CREATE INDEX IF NOT EXISTS %s.%s ON %s(%s)'
                         % (sch, name, tbl, cols))
        if verbose:
            print('  인덱스    %-34s %.2f초' % (name, time.perf_counter() - t0))
    conn.commit()
    if verbose:
        print('  ANALYZE …')
    conn.execute('ANALYZE')
    conn.commit()
    if verbose:
        print('새 칸 %d · 새 인덱스 %d' % (len(miss_c), len(miss_i)))
    return len(miss_c), len(miss_i)


def drop_indexes(conn, verbose=True):
    """이 도구가 만든 **인덱스만** 지운다.

    ⚠ 칸은 안 지운다 — 값이 들어 있을 수 있고 SQLite 의 `DROP COLUMN` 은
      표를 통째로 다시 쓴다. 되돌릴 일이면 사람이 판단한다.
    """
    n = 0
    for sch, tbl in TABLES:
        have = _indexes(conn, sch)
        for tail, _c, _w in INDEXES:
            name = _idx_name(tbl, tail)
            if name in have:
                conn.execute('DROP INDEX %s.%s' % (sch, name))
                n += 1
    conn.commit()
    if verbose:
        print('지운 인덱스 %d개 (칸은 그대로 둔다)' % n)
    return n


def plan(conn, sql, args=()):
    """실행계획 한 줄 — `SEARCH`(인덱스) 인가 `SCAN`(전수) 인가."""
    return ' | '.join(r[3] for r in conn.execute('EXPLAIN QUERY PLAN ' + sql, args))


def report(conn):
    """지금 무엇이 SCAN 인가 — 사람이 읽는 진단."""
    print('\n── 규모 ─────────────────────────────────────────────────')
    for sch, tbl in TABLES:
        if tbl not in _tables(conn, sch):
            continue
        n = conn.execute('SELECT COUNT(*) FROM %s.%s' % (sch, tbl)).fetchone()[0]
        print('  %-22s %8s행' % (tbl, '{:,}'.format(n)))
        for lt, k in conn.execute(
                'SELECT link_type, COUNT(*) FROM %s.%s GROUP BY link_type '
                'ORDER BY COUNT(*) DESC LIMIT 8' % (sch, tbl)):
            print('      %-14s %s' % (lt, '{:,}'.format(k)))

    print('\n── 실행계획 ─────────────────────────────────────────────')
    for lbl, sql in (
            ('유형+A번호', "SELECT target_id FROM sys_link_asset "
                          "WHERE link_type='VERS_VERS' AND clicked_id=1"),
            ('A번호만  ', "SELECT link_type, target_id FROM sys_link_asset "
                          "WHERE clicked_id=1"),
            ('B번호만  ', "SELECT link_type, clicked_id FROM sys_link_asset "
                          "WHERE target_id=1")):
        p = plan(conn, sql)
        mark = '  SCAN ⚠' if 'SCAN' in p else '  SEARCH'
        print('  %-12s %-8s %s' % (lbl, mark, p[:64]))


# ── 자가 검증 ────────────────────────────────────────────────────────────────

def selftest():
    """⚠ **진짜 DB 를 안 건드린다** — 작은 복제본을 만들어 잰다.

    ⚠⚠ 시간으로 재지 않는다(§61차 — 같은 스캔이 150ms↔2,100ms 로 흔들린다).
      **어느 인덱스를 골랐는가**로 잰다.
    ⚠⚠ 「SCAN 이 나오는가」로도 재지 않는다 — 작은 표에서는 SQLite 가
      **skip-scan**(`ANY(link_type)`)을 골라 SCAN 이 재현 안 된다(실측).
    ⚠ 검사를 **데이터 상태에 걸지 않는다**(§0-5) — 「지금 몇 행인가」가
      아니라 **일부러 없애고 만들어 보고 고쳐지는가**로 잰다.
    """
    import os
    import sqlite3
    ok = fail = 0

    def t(n, c, e=''):
        nonlocal ok, fail
        if c:
            ok += 1
        else:
            fail += 1
            print('  FAIL %s  %s' % (n, e))

    tmp = os.path.join(os.environ.get('TEMP', '.'), 'linkunify_selftest.db')
    for e in ('', '-wal', '-shm'):
        if os.path.exists(tmp + e):
            os.remove(tmp + e)
    d = sqlite3.connect(tmp)
    try:
        d.execute("""CREATE TABLE sys_link_asset (
          sys_link_id INTEGER PRIMARY KEY, clicked_id INTEGER, target_id INTEGER,
          link_type TEXT, rel_code TEXT, sort_order INTEGER,
          record_status TEXT, origin_id INTEGER, chain_code TEXT, end_id INTEGER)""")
        # 지금 앱이 가진 것과 같은 「한 방향」 UNIQUE
        d.execute("CREATE UNIQUE INDEX idx_sys_link_unq ON sys_link_asset"
                  "(link_type, clicked_id, target_id, rel_code)")
        d.executemany("INSERT INTO sys_link_asset "
                      "(clicked_id, target_id, link_type, rel_code) VALUES (?,?,?,?)",
                      [(i % 500, (i * 7) % 500, 'T%d' % (i % 9), 'R%d' % (i % 4))
                       for i in range(4000)])
        d.commit(); d.execute('ANALYZE'); d.commit()

        q_fwd = ("SELECT target_id FROM sys_link_asset "
                 "WHERE link_type='T1' AND clicked_id=3")
        q_a = "SELECT link_type FROM sys_link_asset WHERE clicked_id=3"
        q_b = "SELECT link_type FROM sys_link_asset WHERE target_id=3"

        NA = _idx_name('sys_link_asset', 'a')
        NB = _idx_name('sys_link_asset', 'b')

        # ① 아직 없다
        t('한 방향은 원래 인덱스를 쓴다',
          'idx_sys_link_unq' in plan(d, q_fwd), plan(d, q_fwd))
        t('A번호만 — 아직 새 인덱스가 없다', NA not in plan(d, q_a), plan(d, q_a))
        t('B번호만 — 아직 새 인덱스가 없다', NB not in plan(d, q_b), plan(d, q_b))

        # ② 만들면 고쳐지는가
        d.execute('CREATE INDEX %s ON sys_link_asset(%s)' % (NA, INDEXES[0][1]))
        d.execute('CREATE INDEX %s ON sys_link_asset(%s)' % (NB, INDEXES[1][1]))
        d.commit(); d.execute('ANALYZE'); d.commit()
        t('A번호만 — 새 인덱스를 쓴다', NA in plan(d, q_a), plan(d, q_a))
        t('그때 clicked_id 가 앞선다', 'clicked_id=?' in plan(d, q_a), plan(d, q_a))
        t('B번호만 — 새 인덱스를 쓴다', NB in plan(d, q_b), plan(d, q_b))
        t('그때 target_id 가 앞선다', 'target_id=?' in plan(d, q_b), plan(d, q_b))
        # ⚠ 새 인덱스가 양방향을 다 감당할 수 있다 — 「원래 것을 계속 쓰는가」로
        #   재면 틀린다. 재야 할 것은 **여전히 인덱스를 쓰는가**이다.
        t('한 방향도 여전히 인덱스를 쓴다',
          'SEARCH' in plan(d, q_fwd) and 'link_type=?' in plan(d, q_fwd), plan(d, q_fwd))
        t('유형만으로도 인덱스를 쓴다',
          'SEARCH' in plan(d, "SELECT clicked_id FROM sys_link_asset WHERE link_type='T1'"))

        # ③ 값이 안 바뀐다
        t('행 수 불변', d.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0] == 4000)
        t('A=3 건수 불변',
          d.execute("SELECT COUNT(*) FROM sys_link_asset WHERE clicked_id=3").fetchone()[0]
          == 4000 // 500)

        # ④ 칸 더하기 — 멱등이고 값이 안 사라지는가
        d.execute("UPDATE sys_link_asset SET rel_code='KEEP' WHERE sys_link_id=1")
        # ⚠ 이미 있는 칸은 건너뛴다 — `chain_code` 처럼 **표에 원래 있는 것**을
        #   목록에 넣은 날 `duplicate column name` 으로 터졌다(2026-08-24).
        _have = {r[1] for r in d.execute('PRAGMA table_info(sys_link_asset)')}
        for col, typ, _w, _y in COLUMNS:
            if col not in _have:
                d.execute('ALTER TABLE sys_link_asset ADD COLUMN %s %s' % (col, typ))
        d.commit()
        cols = {r[1] for r in d.execute('PRAGMA table_info(sys_link_asset)')}
        t('목록의 칸이 다 생겼다',
          all(c in cols for c, _t, _w, _y in COLUMNS),
          sorted(c for c, _t, _w, _y in COLUMNS if c not in cols))
        t('칸을 더해도 옛 값이 산다',
          d.execute("SELECT rel_code FROM sys_link_asset WHERE sys_link_id=1")
          .fetchone()[0] == 'KEEP')
        t('새 칸은 비어 있다',
          d.execute("SELECT COUNT(*) FROM sys_link_asset WHERE note IS NOT NULL")
          .fetchone()[0] == 0)
        # 새 칸에 값을 넣고 읽어 본다(형이 맞는가)
        d.execute("UPDATE sys_link_asset SET note='ㄱ', importance=7, is_key=1 "
                  "WHERE sys_link_id=1")
        r = d.execute("SELECT note, importance, is_key FROM sys_link_asset "
                      "WHERE sys_link_id=1").fetchone()
        t('새 칸이 값을 받는다', r == ('ㄱ', 7, 1), r)

        # ⑤ 안 만드는 칸 — 만들지 않았는지 확인(설계가 새지 않게)
        t('a_scope 를 만들지 않았다', 'a_scope' not in cols)
        t('is_milestone 을 만들지 않았다', 'is_milestone' not in cols)
        t('a_end 를 만들지 않았다', 'a_end' not in cols)

        # ⑥ ★★ **유일 열쇠가 구간을 지키는가** — 이것이 이 인덱스의 존재 이유다
        d.execute("DELETE FROM sys_link_asset")
        d.execute("DROP INDEX IF EXISTS idx_sys_link_unq")
        d.execute('CREATE UNIQUE INDEX u_new ON sys_link_asset(%s) WHERE %s'
                  % (UNQ_COLS, UNQ_WHERE))

        def ins(**kw):
            ks = ','.join(kw); ph = ','.join('?' * len(kw))
            return d.execute('INSERT OR IGNORE INTO sys_link_asset(%s) VALUES(%s)'
                             % (ks, ph), list(kw.values())).rowcount

        base = dict(link_type='UREF_VERS', clicked_id=1, target_id=100)
        t('구간이 다르면 **다른 연결**이다',
          ins(**base, end_id=200) == 1 and ins(**base, end_id=300) == 1
          and ins(**base) == 1,
          d.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0])
        t('같은 구간은 두 번 안 들어간다', ins(**base, end_id=200) == 0)
        t('끝 없는 것도 두 번 안 들어간다', ins(**base) == 0)
        # ⚠ 옛 열쇠는 `rel_code` 가 NULL 이면 **안 막았다**(SQLite 는 NULL 을
        #   서로 다르다고 본다). 새 열쇠는 COALESCE 로 막는다.
        t('rel_code 가 NULL 이어도 중복을 막는다',
          d.execute("SELECT COUNT(*) FROM sys_link_asset "
                    "WHERE end_id IS NULL").fetchone()[0] == 1)
        # ★ 숨긴 것까지 유일할 까닭은 없다
        d.execute("UPDATE sys_link_asset SET record_status='HIDE' "
                  "WHERE end_id IS NULL")
        t('숨긴 자리에는 다시 넣을 수 있다', ins(**base) == 1)
        t('그래도 살아 있는 것은 하나',
          d.execute("SELECT COUNT(*) FROM sys_link_asset WHERE end_id IS NULL "
                    "AND COALESCE(record_status,'LIVE')='LIVE'").fetchone()[0] == 1)
        # ⑦ 부딪히는 것을 세는 눈이 실제로 보는가
        #   ⚠ 인덱스를 먼저 지워야 한다 — 안 지우면 **인덱스가 막아서** 위반을
        #     만들 수조차 없다(그것 자체가 인덱스가 산다는 증거이고, 실제로
        #     여기서 IntegrityError 를 만났다).
        d.execute("DROP INDEX u_new")
        d.execute("UPDATE sys_link_asset SET record_status='LIVE'")
        bad = unq_conflicts(d, 'main', 'sys_link_asset')
        t('부딪히는 무리를 찾아낸다', len(bad) == 1, bad)
        # 그 상태에서는 인덱스를 못 만든다 — 그것도 확인한다
        try:
            d.execute('CREATE UNIQUE INDEX u_again ON sys_link_asset(%s) WHERE %s'
                      % (UNQ_COLS, UNQ_WHERE))
            t('부딪히면 인덱스가 안 만들어진다', False, '만들어졌다')
        except Exception:
            t('부딪히면 인덱스가 안 만들어진다', True)
    finally:
        d.close()
        for e in ('', '-wal', '-shm'):
            if os.path.exists(tmp + e):
                os.remove(tmp + e)

    # ⑥ 진짜 DB — `check` 가 아무것도 안 만드는지만 본다
    conn = appdb.connect()
    try:
        before = ({(s, n) for s, t_ in TABLES for n in _indexes(conn, s)},
                  {(s, t_, c) for s, t_ in TABLES
                   if t_ in _tables(conn, s) for c in _columns(conn, s, t_)})
        mi, mc = check(conn, verbose=False)
        t('check 가 목록 둘을 준다', isinstance(mi, list) and isinstance(mc, list))
        after = ({(s, n) for s, t_ in TABLES for n in _indexes(conn, s)},
                 {(s, t_, c) for s, t_ in TABLES
                  if t_ in _tables(conn, s) for c in _columns(conn, s, t_)})
        t('check 는 아무것도 안 만든다', before == after)
    finally:
        conn.close()

    print('selftest %d/%d' % (ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a or not a:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect()
    try:
        if '--apply' in a:
            apply(c); report(c)
        elif '--drop' in a:
            drop_indexes(c); report(c)
        elif '--report' in a:
            report(c)
        else:
            mi, mc = check(c); report(c)
            sys.exit(0 if not (mi or mc) else 1)
    finally:
        c.close()
