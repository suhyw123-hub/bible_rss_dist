# -*- coding: utf-8 -*-
"""media_intake.py — 수집물이 들어오는 **단일 문** (영구, 2026-09-08).

★★★ **사용자 지시**(2026-09-08):
  「**어떤 방법으로 수집했던지, 어떤 키워드로 수집했던지 공통적으로 거쳐야 할
    품질관리는 반드시 거치도록 해야 한다.**」

⚠⚠ **그전에는 `sys_media_asset` 에 INSERT 하는 자리가 다섯이었다** — 그래서
  품질관리가 자리마다 갈렸다(실측):

  | 경로 | 분류 | 제외 | 연결 |
  |---|---|---|---|
  | `db_media_crawler.insert_media` | O | O | O |
  | `db_yt_rss_collect` | O(§206차 수리) | O | O |
  | **`panel_media_channel._CollectTab`** | **✗ 두 갈래만**(SERMON/WORSHIP) | O | O |
  | **`media_gap_collector._save`** | **✗ 없음**(기본값 SERMON) | O | O |
  | `panel_entity_youtube` | O | O | O |

  ★ §199차 「같은 일을 하는 자리가 둘이면 한쪽만 고쳐진다」의 네 번째 자리다.
    §206차가 RSS 에서 고친 병이 **자동크롤러 화면에 그대로 남아 있었다.**

★★★ **이 문이 하는 다섯 걸음** — 어느 경로로 들어와도 같은 순서다:
  ① **문지기** — 채널 차단 · 오프토픽(앵커가 있으면 통과)
  ② **분류**   — 유형(11언어 380낱말 + 교회 채널 판정) · 형태 · 대상
  ③ **저장**   — URL 이 같으면 **기존 것을 재사용**(사람이 손댔을 수 있다)
  ④ **연결**   — 구간(`MEDI_VERS`) + 용어(`MEDI_ENTI`) · 못 정하면 보관함
  ⑤ **보고**   — 무엇을 왜 건너뛰었는지 돌려준다(§0-1 조용한 실패 금지)

⚠ **이미 있는 것은 다시 분류하지 않는다** — 사람이 고쳤을 수 있다.
  규칙을 바꾼 뒤 소급 적용은 **[재분류 실행]**(`media_taxonomy.reclassify`)의
  몫이고, 그 문과 여기가 **같은 `classify_content` 를 쓴다**(갈리지 않는다).

⚠ **여기서 새 규칙을 만들지 않는다** — 분류는 `media_taxonomy`, 제외는
  `media_exclude`, 연결은 `media_text_linker`·`db_media_range` 가 정본이다.
  이 파일은 **차례를 정하고 빠뜨리지 않게 하는 것**만 한다.

사용:  python media_intake.py --selftest | --audit
"""
import io
import json
import os
import sys
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

import media_exclude
import media_link
# ★★★ 용어 연결 후보 상태(2026-09-09 핵심과제 — db_term_link_audit).
#   설명문에서만 걸린 이름은 「지나가는 언급」이 많아(실측 2,901건 중 반쯤) 사람이
#   확인하기 전에는 사용자에게 안 나간다. 제목에 이름이 있으면 처음부터 LIVE.
ST_PEND = 'PEND'
import media_taxonomy as tax
import db_media_range as media_range

#: 건너뛴 사유 — 화면이 사람 말로 옮긴다
SKIP_CHANNEL = 'SKIP_CHANNEL'      #: 차단한 채널
SKIP_OFFTOPIC = 'SKIP_OFFTOPIC'    #: 성경 본문과 무관한 꼴
SKIP_CHANNEL_KW = 'SKIP_CHANNEL_KW'  #: 채널 거르는 말(이단·타종교 단체)에 걸림
SKIP_NO_URL = 'SKIP_NO_URL'
#: ★★★ **쇼츠**(2026-09-11 사용자 「2분 이내는 숏츠로 취급하자」) —
#:   ⚠⚠ 그전에는 **RSS 경로만** 쇼츠를 걸렀고(`exclude_shorts` · 등록 채널
#:     265개 전부 켜져 있다) **검색 경로에는 잣대가 없었다.** 찬양은 대부분
#:     검색으로 들어오므로 필터가 있어도 안 들었다 — 실측 제목에 쇼츠가 든
#:     찬양 **41편**이 그렇게 들어와 있었다.
SKIP_SHORT = 'SKIP_SHORT'

ACT_NEW = 'NEW'
ACT_EXIST = 'EXIST'
ACT_DRY = 'DRY'


#: ★★★ **수집이 아닌 자리** — 이 문을 지날 이유가 없다.
#: ⚠ **늘 걸리는 지표는 죽는다**(§115차) — 배포·복원·시험까지 세면 숫자가
#:   안 줄어 아무도 안 본다. 갈라 두고 **수집 경로만** 센다.
#: ⚠ 새 파일을 여기 넣을 때는 **왜 수집이 아닌지** 한 줄로 적는다.
ALLOWED_INSERT = {
    'db_linkpack_build.py': '배포 팩 — 받는 쪽 스키마를 만든다',
    'db_pack_core.py': '코어팩 적재 — 배포물을 되살린다',
    'db_media_range.py': 'selftest 전용 시험 표',
    'admin/panel_entity_wiki.py': '폐기된 화면(deprecated)',
    'admin/panel_media_pending.py': 'selftest 전용 시험 표',
    'link_picker.py': '사용자가 손으로 만든 링크(수집 아님)',
    'db_media_autoapprove.py': 'selftest 전용 시험 표',
    'db_media_linkcheck.py': 'selftest 전용 시험 표(링크 점검 — 수집이 아니다)',
    'db_worship_artist.py': 'selftest 전용 시험 표(찬양 사역자 — 수집이 아니다)',
    'db_song.py': 'selftest 전용 시험 표(찬양 곡·판 — 수집이 아니다)',
    'db_term_link_audit.py': 'selftest 전용 시험 표(용어 연결 재판정 — 수집이 아니다)',
    'db_heresy_sweep.py': 'selftest 전용 시험 표(이단 정리 — 수집이 아니다)',
    'db_song_match.py': 'selftest 전용 시험 표(곡·사역자 추천 판정 — 수집이 아니다)',
    'video_open.py': 'selftest 전용 시험 표(임베드 차단 판정 — 수집이 아니다)',
    'db_song_lift.py': 'selftest 전용 시험 표(곡 층으로 올리기 — 수집이 아니다)',
    'media_taxonomy.py': 'selftest 전용 시험 표(갈래 판정 — 수집이 아니다)',
}


def _quiet(msg):
    try:
        sys.stderr.write(str(msg) + chr(10))
    except Exception:
        pass


def _safe(fn, dflt, tag):
    """재료 읽기 — **실패해도 담기는 돈다**. 무엇이 없었는지 알린다(§0-1)."""
    try:
        return fn()
    except Exception as e:
        _quiet('[intake] %s: %s' % (tag, e))
        return dflt


class Gate:
    """수집 한 바퀴 동안 **재료를 한 번만 읽는다**.

    ⚠ 채널 목록·분류 낱말·언어별 컨텍스트를 영상마다 다시 읽으면 수백 번
      DB 를 친다. 한 번 만들어 돌려 쓴다.
    """

    def __init__(self, conn, db_path=None):
        self.conn = conn
        self.db_path = db_path or _db_path()
        # ⚠⚠ **재료 하나가 없다고 수집이 멈추면 안 된다** — 표가 빠진 옛 DB
        #   에서도 담기는 돌아야 한다. 못 읽은 것은 **기본값으로 물러선다**.
        self.sets = _safe(lambda: tax.load_classify_sets(conn), {}, 'sets')
        self.excl_ch = _safe(lambda: media_exclude.excluded_channels(conn),
                             set(), 'excl_ch')
        self.excl_ids = _safe(lambda: media_exclude.excluded_ids(conn),
                              set(), 'excl_ids')
        self.chan_kw = _safe(
            lambda: media_exclude.get_channel_map(self.db_path), {}, 'chan_kw')
        self.excl_kw = _safe(
            lambda: media_exclude.get_exclude_map(self.db_path), {}, 'excl_kw')
        self.off_kw = _safe(
            lambda: media_exclude.get_offtopic_map(self.db_path), {}, 'off_kw')
        # ★★★ 분야별 차이(면제·추가) — 영상마다 다시 읽지 않는다
        self.off_domain = _safe(
            lambda: media_exclude.get_offtopic_domain(self.db_path), {},
            'off_domain')
        self._ctx = {}
        _safe(lambda: media_range.init(conn), None, 'range init')

    def ctx(self, lang):
        """언어별 링커 컨텍스트 — 만들어 두고 돌려 쓴다."""
        lg = (lang or 'KO').upper()
        c = self._ctx.get(lg)
        if c is None:
            import media_text_linker as TL
            c = self._ctx[lg] = TL.build_context(self.conn, lg)
        return c


def _db_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        'bible_master.db')


def _kw(kw_map, lang):
    try:
        return media_exclude.kw_for(kw_map, lang)
    except Exception:
        return None


def _song_anchor(gate, title):
    """제목이 우리 곡 이름을 **낱말 그대로** 품는가(EXACT 만) — 관련성 필터를 이기는 둘째 앵커.
    곡 표는 문지기마다 한 번 읽어 둔다(`gate._song_names`)."""
    if not title:
        return False
    try:
        import db_song_match as _SM
        names = getattr(gate, '_song_names', None)
        if names is None:
            names = _SM.song_names(gate.conn)
            try:
                gate._song_names = names
            except Exception:
                pass
        if not names:
            return False
        common = getattr(gate, '_song_common', None)
        if common is None:
            common = _SM._common_words(gate.conn)
            try:
                gate._song_common = common
            except Exception:
                pass
        for _hit in _SM.match_song(title, names, common):
            if len(_hit) >= 3 and _hit[2] == getattr(_SM, 'EXACT', 'EXACT'):
                return True
    except Exception as e:
        _quiet('[intake] song anchor: %s' % e)
    return False


# ── ① 문지기 ─────────────────────────────────────────────────────────
def screen(gate, row, domain=None):
    """담을지 말지 → 사유(건너뛰면) 또는 `None`.

    ★★★ `domain` — **이번 수집의 의도**(2026-09-10). 「원하는가」를 묻는 층
      (오프토픽)에만 걸리고 **「무엇인가」를 묻는 층은 안 바뀐다** — 채널
      차단·콘텐츠 거르는 말은 분야가 못 이긴다(전능신교는 어느 분야에서
      찾아도 전능신교다).
    ⚠ 안 주면 `COMMON` 이라 **옛 판정 그대로**다(회귀 0).
    ⚠ 분야는 콘텐츠 속성이 아니다 — 담긴 뒤의 유형은 `media_taxonomy` 가
      정한다. `audience`(KIDS/SIGN)와 층이 다르다.

    ⚠ **채널을 먼저 본다** — 차단한 채널이면 내용을 볼 것도 없다.
    ⚠ **오프토픽은 앵커를 먼저 읽는다**(§195차) — 실측 오프토픽 낱말이 든
      1,247건 중 58%가 구절 좌표를 함께 갖는다(「주일예배 | 창세기 1:1-5」).
      낱말만 보고 거르면 그 722건을 잃는다.
    """
    ch = (row.get('channel') or '').strip()
    if ch and media_exclude.chan_excluded(ch, gate.excl_ch):
        return SKIP_CHANNEL
    # ★ 유튜브 id 로도 본다 — 이름은 채널이 바꾼다(2026-09-09 「하나님의교회」가
    #   다섯 이름으로 15편 들어와 있었다). id 가 없는 옛 수집분은 이름으로만.
    cid = str(row.get('channel_id') or '').strip()
    if cid and cid in getattr(gate, 'excl_ids', ()):
        return SKIP_CHANNEL
    title = row.get('title') or ''
    body = (row.get('yt_desc') or row.get('description') or '')[:600]
    lang = row.get('lang_code') or row.get('lang') or None
    txt = '%s%s%s' % (title, chr(10), body)
    # ★★★ 채널 거르는 말 — 이단·타종교 **단체** 표기. 채널 이름·제목·설명문을
    #   함께 보고, **앵커가 있어도 못 이긴다**(단체가 이단이면 좌표가 있어도
    #   담을 것이 아니다). 등록 채널도 예외가 아니다 — 등록이 실수일 수 있다
    #   (실측 몰몬 아랍어 공식 채널이 등록돼 있었다).
    hit = None
    try:
        hit = media_exclude.match_channel(
            '%s%s%s' % (ch, chr(10), txt),
            kw_list=_kw(getattr(gate, 'chan_kw', None), lang), lang=lang)
    except Exception as e:
        _quiet('[intake] channel kw: %s' % e)
    if hit:
        return SKIP_CHANNEL_KW
    # ★★★ **앵커 = 구절 좌표 · 곡 이름뿐이다 — 용어 이름은 필터를 못 이긴다**
    #   (2026-09-16 미승인 점검). 그전에는 제목·설명문에 용어 이름(은혜·하나님·마음·
    #   사랑·교회·기도·예수·말씀 …)이 있으면 앵커로 쳐서 「주일예배」가 든 실황이
    #   **거의 다 통과했다** — 실측 관련성 낱말이 든 영상 6,119편 중 **좌표로 통과한
    #   것은 승인률 43%, 용어 이름으로 통과한 것은 8%**(1,960편 중 158). 교회 영상치고
    #   그 낱말이 없는 제목이 없어 필터가 사실상 죽어 있었다.
    #   ★ 곡 이름은 남긴다 — 「곡 이름이 걸렸다는 사실이 낱말보다 강한 신호」(§233차).
    #     마커스워십 「선하신 목자」·사랑의교회 「거룩 영원히」가 「예배 실황」 낱말과
    #     함께 온다(실측 승인분 15편 중 12편이 곡 이름으로 산다).
    # ★★★ **등록 채널(`domain='CHANNEL'`)은 관련성 필터를 아예 안 거친다**(2026-09-16
    #   사용자 「관련성 필터 관리체계를 제로 베이스로」). 관련성 필터가 묻는 것은 「검색한
    #   구절·용어와 상관있는가」인데, 등록 채널 영상은 **검색해서 온 것이 아니라 사람이 고른
    #   채널이 올린 것**이라 그 물음이 성립하지 않는다. 실측 실황 낱말 영상 4,034편의
    #   98.5% 가 등록 채널이었고 66% 는 구절 연결까지 있었다 — 거른 것이 「상관없는 영상」이
    #   아니었다. 등록 채널에 듣는 문은 채널 거르는 말·쇼츠·이미 있음 셋뿐이다.
    if (domain or '').upper() == 'CHANNEL':
        off = None
    else:
        anchor = False
        try:
            got = (media_range.read(gate.conn, title)
                   or media_range.read(gate.conn, body))
            anchor = bool(got)
            if not anchor:
                anchor = _song_anchor(gate, title)
        except Exception as e:
            _quiet('[intake] anchor: %s' % e)
        off = media_exclude.match_offtopic(txt, has_anchor=anchor,
                                           kw_list=_kw(gate.off_kw, lang),
                                           lang=lang, domain=domain,
                                           dmap=getattr(gate, 'off_domain', None))
    if off:
        return SKIP_OFFTOPIC
    # ★★★ **쇼츠는 담지 않는다** — ⓐ 길이가 문턱 이하 ⓑ 제목이 스스로 적었다.
    #   ⚠ 길이는 `videos.list` 가 이미 주는 값이라 **비용이 0**이다
    #     (`db_media_crawler._fill_full_desc` 가 그 호출을 이미 돌린다).
    #   ⚠ 길이를 모르면 **제목만** 본다 — 모른다고 조용히 담지 않는다.
    # ★ 2026-10-12 사용자 「기도 영상은 숏츠를 제거하지 말자 · 짧은 1분 기도는 의미가 있다」 —
    #   기도 분야(검색어 수집)와 기도 채널(row['allow_short'])은 길이로 안 거른다.
    if (domain or '').upper() == 'PRAYER' or row.get('allow_short'):
        return None
    try:
        import db_media_linkcheck as _LC
        _du = row.get('duration')
        if _du is not None and int(_du) <= _LC.SHORT_SEC:
            return SKIP_SHORT
        if _LC.SHORT_MARK.search('%s' % (row.get('title') or '')):
            return SKIP_SHORT
    except Exception:
        pass
    return None


# ── ② 분류 ───────────────────────────────────────────────────────────
def classify(gate, row):
    """유형·형태·대상을 정한다 → dict.

    ★★★ **여기가 사용자 지시의 본체다** — 어느 경로로 들어와도 **같은 문**이
      유형을 정한다. 그전에는 자동크롤러가 두 갈래만 냈고 저밀도는 아예
      안 정했다(기본값 SERMON).
    ⚠ **채널 이름을 함께 넘긴다** — 교회 채널의 「예배」는 찬양이 아니다
      (§207차 ⑨ 사용자 확정 · `is_church_channel`).
    """
    title = row.get('title') or ''
    ch = (row.get('channel') or '').strip()
    lang = row.get('lang_code') or row.get('lang') or 'KO'
    txt = ('%s %s' % (title, ch)).strip()
    mtype = tax.classify_content(txt, lang, gate.sets, channel=ch)
    ftype = tax.detect_format(txt, lang, gate.sets)
    # 대상 — **채널이 정한 것이 먼저**, 없으면 낱말로 짐작(수화 → 어린이 차례).
    #   ⚠⚠ 그전에는 어린이 낱말표를 따로 읽어 **버킷 dict 의 열쇠**를 낱말로
    #     훑었다(KIDS 563건 중 443건이 거짓 — 「1 Korinther」의 `ko`). 이제
    #     `gate.sets`(언어 버킷)에서 `kw_for_lang` 으로 그 언어 낱말만 본다.
    aud = (row.get('audience') or '').strip().upper()
    if aud not in tax.AUDIENCE_TYPES:
        aud = ''
    if not aud:
        if row.get('is_kids'):
            aud = 'KIDS'
        else:
            aud = tax.DEFAULT_AUDIENCE
            for cat in tax.AUDIENCE_KW_CATS:
                if tax.match_kw(txt, tax.kw_for_lang(gate.sets.get(cat) or {}, lang)):
                    aud = cat
                    break
    return {'media_type': mtype, 'format_type': ftype, 'audience': aud}


def ensure_channel_audience(conn):
    """`sys_media_channel.audience` 칸(멱등) — 채널이 정하는 대상(GENERAL·KIDS·SIGN).

    ★ 채널 등록 단계가 대상의 정본이다(2026-09-08 수화). 옛 `is_kids` 는 남긴다.
    """
    try:
        cols = [r[1] for r in conn.execute('PRAGMA table_info(sys_media_channel)')]
        if cols and 'audience' not in cols:
            conn.execute('ALTER TABLE sys_media_channel ADD COLUMN audience TEXT')
            conn.execute("UPDATE sys_media_channel SET audience='KIDS' WHERE COALESCE(is_kids,0)=1")
            conn.commit()
        # ★ 수화 언어 코드(2026-09-08) — 채널이 정본. 코드표도 함께 보장한다.
        if cols and 'sign_code' not in cols:
            conn.execute('ALTER TABLE sys_media_channel ADD COLUMN sign_code TEXT')
            conn.commit()
        tax.ensure_sign_table(conn)
    except Exception:
        pass
    return True


#: 채널 조회에서 대상을 읽는 SQL 조각 — `audience` 칸이 먼저, 없으면 is_kids
CHANNEL_AUD_SQL = ("COALESCE(NULLIF(%s.audience,''), CASE WHEN COALESCE(%s.is_kids,0)=1"
                   " THEN 'KIDS' ELSE 'GENERAL' END)")


def channel_sign_sql(alias='c', conn=None):
    """채널의 수화코드 조각 — 칸이 없는 옛 DB·시험 표면 빈 글자."""
    if conn is not None:
        try:
            cols = [r[1] for r in conn.execute('PRAGMA table_info(sys_media_channel)')]
            if 'sign_code' not in cols:
                return "''"
        except Exception:
            pass
    return "COALESCE(%s.sign_code,'')" % alias


def channel_aud_sql(alias='c', conn=None):
    """`conn` 을 주면 칸이 없는 옛 DB(·시험 표)에서 is_kids 만으로 물러선다."""
    if conn is not None:
        try:
            cols = [r[1] for r in conn.execute('PRAGMA table_info(sys_media_channel)')]
            if 'audience' not in cols:
                return ("CASE WHEN COALESCE(%s.is_kids,0)=1 THEN 'KIDS'"
                        " ELSE 'GENERAL' END" % alias)
        except Exception:
            pass
    return CHANNEL_AUD_SQL % (alias, alias)


# ── 걸러짐 보관함 ────────────────────────────────────────────────────
#: ★★★ **걸러진 것도 자리를 준다**(2026-09-11 사용자 「상관이 있는데 없다고
#:   판단했다. 걸러진 것을 **별도 보관함**에서 표시하라. **다시 복구**할 수
#:   있어야 한다. 걸러내는 키워드에 문제가 있다」).
#:   ⚠⚠ 그전에는 걸러진 줄이 **화면에만 회색으로** 떴고 다시 찾으면 사라졌다 —
#:     거르는 말이 틀렸다는 사실을 **아무도 다시 볼 수 없었다.**
#:   ⚠ **배포하지 않는다**(LOCAL) — 담지 않기로 한 것들의 장부다.
#:   ★ 열쇠는 **주소**다. 같은 영상이 여러 검색어에 걸리므로 멱등이라야 하고,
#:     **몇 번 걸렸나**(`n`)가 곧 「이 거르는 말이 얼마나 자주 때리나」다.
SKIP_TBL = 'sys_media_skip'


def ensure_skip(conn):
    """걸러짐 보관함 표를 만든다(멱등)."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS %s (
            skip_id    INTEGER PRIMARY KEY AUTOINCREMENT,
            url        TEXT UNIQUE,
            title      TEXT,
            channel    TEXT,
            channel_id TEXT,
            lang_code  TEXT,
            yt_desc    TEXT,
            published  TEXT,
            why        TEXT,
            domain     TEXT,
            n          INTEGER DEFAULT 1,
            seen_at    TEXT
        )""" % SKIP_TBL)
    return True


def note_skip(conn, row, why, domain=None):
    """걸러진 줄을 보관함에 적는다(멱등) → 새로 담았으면 True.

    ⚠ **판정하는 문(`screen`)이 적지 않는다** — 그 문은 값을 내기만 하고
      아무것도 안 바꾼다(자동 경로에서도 불린다). 적는 것은 **수집 화면**의
      몫이다. 그래야 「사람이 본 검색 결과」만 보관함에 쌓인다.
    """
    url = (row.get('url') or '').strip()
    if not url or not why:
        return False
    ensure_skip(conn)
    import datetime
    now = datetime.datetime.now().isoformat(' ', 'seconds')
    cur = conn.execute(
        "INSERT INTO %s (url, title, channel, channel_id, lang_code,"
        "  yt_desc, published, why, domain, n, seen_at)"
        " VALUES (?,?,?,?,?,?,?,?,?,1,?)"
        " ON CONFLICT(url) DO UPDATE SET n=n+1, why=excluded.why,"
        "  seen_at=excluded.seen_at" % SKIP_TBL,
        (url, row.get('title') or '', row.get('channel') or '',
         row.get('channel_id') or '', row.get('lang_code') or '',
         (row.get('yt_desc') or '')[:DESC_MAX], row.get('published') or '',
         why, domain or '', now))
    return bool(cur.rowcount)


def skip_rows(conn, domain=None, why=None, limit=300):
    """보관함 목록 → dict 목록(잦은 것 먼저).

    ⚠⚠ **이미 담은 것은 안 낸다**(사용자 「이미 수집승인 된 것이라면 표시하지
      마라」) — 담고 나면 걷지만, 옛 줄이나 딴 경로로 담긴 것이 남을 수 있어
      **낼 때도 한 번 더 본다.**
    """
    ensure_skip(conn)
    wh, ar = [], []
    if domain:
        wh.append("COALESCE(s.domain,'')=?")
        ar.append(domain)
    if why:
        wh.append("COALESCE(s.why,'')=?")
        ar.append(why)
    sql = ("SELECT s.skip_id, s.url, s.title, s.channel, s.channel_id,"
           "       s.lang_code, s.yt_desc, s.published, s.why, s.n, s.seen_at"
           "  FROM %s s"
           " WHERE NOT EXISTS (SELECT 1 FROM sys_media_asset m"
           # status-ok: 담긴 적이 있나만 본다 — 가려 둔 것도 「담은 것」이다
           "                    WHERE m.url = s.url)" % SKIP_TBL)
    if wh:
        sql += ' AND ' + ' AND '.join(wh)
    sql += ' ORDER BY s.n DESC, s.skip_id DESC LIMIT ?'
    ar.append(int(limit))
    ks = ('skip_id', 'url', 'title', 'channel', 'channel_id', 'lang_code',
          'yt_desc', 'published', 'why', 'n', 'seen_at')
    return [dict(zip(ks, r)) for r in conn.execute(sql, ar)]


def drop_skip(conn, url):
    """보관함에서 걷는다 — **담고 나면** 부른다."""
    if not url:
        return 0
    ensure_skip(conn)
    return conn.execute("DELETE FROM %s WHERE url=?" % SKIP_TBL,
                        (url,)).rowcount or 0


def skip_counts(conn, domain=None):
    """사유별 개수 → dict. **거르는 말을 고칠 재료다.**"""
    ensure_skip(conn)
    sql = ("SELECT COALESCE(why,''), COUNT(*) FROM %s s"
           " WHERE NOT EXISTS (SELECT 1 FROM sys_media_asset m"
           # status-ok: 담긴 적이 있나만 본다
           "                    WHERE m.url = s.url)" % SKIP_TBL)
    ar = []
    if domain:
        sql += " AND COALESCE(s.domain,'')=?"
        ar.append(domain)
    sql += ' GROUP BY 1'
    return {r[0]: r[1] for r in conn.execute(sql, ar)}


# ── ③④⑤ 담기 ────────────────────────────────────────────────────────
#: 설명문 상한 — 전문을 담되 통째로 커지는 일은 막는다
DESC_MAX = 5000


def sweep_entities(conn, dry=False, log=print):
    """이미 담긴 **제목·채널 이름의 HTML 기호를 푼다** → (제목 수, 채널 수).

    ★ 담는 문(`admit`)이 이제 풀지만 **쌓인 것은 안 바뀐다**.
    ⚠ **쿼터 0** · 멱등(다시 돌리면 0).
    """
    import html as _html
    import json as _js
    nt = nc = 0
    for mid, title, desc in conn.execute(
            "SELECT media_id, COALESCE(title,''), COALESCE(description,'')"
            # status-ok: 가린 영상의 제목도 고친다 — 되살리는 날 그대로 나간다
            "  FROM sys_media_asset").fetchall():
        new_t = _html.unescape(title)
        try:
            d = _js.loads(desc) if desc.startswith('{') else None
        except Exception:
            d = None
        new_d = None
        if isinstance(d, dict):
            ch = d.get('channel')
            if isinstance(ch, str) and _html.unescape(ch) != ch:
                d['channel'] = _html.unescape(ch)
                new_d = _js.dumps(d, ensure_ascii=False)
                nc += 1
        if new_t != title or new_d is not None:
            if new_t != title:
                nt += 1
            if not dry:
                if new_d is not None:
                    conn.execute("UPDATE sys_media_asset SET title=?,"
                                 " description=? WHERE media_id=?",
                                 (new_t, new_d, mid))
                else:
                    conn.execute("UPDATE sys_media_asset SET title=?"
                                 "  WHERE media_id=?", (new_t, mid))
    # 채널 표도 함께 — 이름이 어긋나면 「등록 채널이 아닙니다」가 된다
    nn = 0
    try:
        chs = conn.execute(
            "SELECT channel_id, COALESCE(channel_name,'')"
            "  FROM sys_media_channel").fetchall()  # status-ok: 이름 글자만 고친다
    except Exception:
        chs = []            # 채널 표가 없는 DB(시험용 메모리) — 조용히 넘긴다
    for chid, nm in chs:
        u = _html.unescape(nm)
        if u != nm:
            nn += 1
            if not dry:
                conn.execute("UPDATE sys_media_channel SET channel_name=?"
                             "  WHERE channel_id=?", (u, chid))
    if not dry:
        conn.commit()
    log('  [HTML 기호] 제목 %d편 · 영상의 채널 이름 %d편 · 채널 표 %d곳%s'
        % (nt, nc, nn, ' (미리보기)' if dry else ''))
    return nt, nc, nn


def admit(gate, row, *, link=True, hint_id=None, also_entity=None,
          dry_run=False, screen_on=True, domain=None):
    """수집물 하나를 담는다 → dict.

    돌려주는 것:
      `action`   `NEW` | `EXIST` | `DRY` | 건너뛴 사유
      `media_id` 담았으면 번호 (건너뛰면 None)
      `why`      건너뛴 까닭 · 보관함에 담긴 까닭
      `links`    (구간, 용어) 새로 만든 수

    ⚠ **이미 있는 URL 은 다시 분류하지 않는다** — 사람이 고쳤을 수 있다.
      다만 **연결은 다시 시도한다**(읽기 규칙이 좋아졌을 수 있다 · 멱등).
    """
    out = {'action': None, 'media_id': None, 'why': '', 'links': (0, 0)}
    # ★★★ **글자를 NFC 로 모아 담는다**(2026-09-10 사용자 「제목이
    #   「ㅂㅗㅎㅕㄹㅇㅡㄹ …」와 같은 형식으로 표시된다」).
    #   ⚠⚠ 한글은 **한 글자로 모인 꼴(NFC)**과 **자모가 흩어진 꼴(NFD)**이
    #     둘 다 있고, 유튜브가 주는 값에 NFD 가 섞여 온다. 그대로 담으면
    #     화면에 자모가 흩어져 보이고 **검색·대조도 조용히 어긋난다**
    #     (`'보혈'` 로 찾아도 NFD 로 담긴 것은 안 걸린다). 실측 115편.
    #   ★ **담는 문 하나에서** 모은다 — 화면마다 고치면 반드시 하나가 빠진다.
    # ★★★ **HTML 기호도 여기서 푼다**(2026-09-12 실측) — 유튜브가 제목을
    #   `Light&amp;Delight`·`악보&amp;찬양` 꼴로 준다. 그대로 담으면
    #   ⓐ 사용자에게 그 글자가 그대로 나가고 ⓑ **검색·대조가 조용히 어긋난다**
    #   (`'Light&Delight'` 로 찾아도 안 걸린다). 실측 제목 **1,858편** ·
    #   채널 이름 47편. §⑤-23 ⓓ 가 곡 캐기에서 겪은 그 자리다.
    #   ⚠ **담는 문 하나에서** 푼다 — 화면마다 고치면 반드시 하나가 빠진다.
    import html as _html
    import unicodedata as _ud
    for _k in ('title', 'channel', 'yt_desc'):
        _v = row.get(_k)
        if isinstance(_v, str) and _v:
            row[_k] = _ud.normalize('NFC', _html.unescape(_v))
    url = (row.get('url') or '').strip()
    if not url:
        out['action'] = SKIP_NO_URL
        return out
    conn = gate.conn
    cur = conn.cursor()
    exist = cur.execute("SELECT media_id, description FROM sys_media_asset "
                        # status-ok: 같은 주소를 다시 담지 않으려는 확인 —
                        #   가림을 빼면 **사용자가 숨긴 영상이 새 줄로
                        #   되살아난다**(이 파일에서 가장 위험한 자리다)
                        "WHERE url=?", (url,)).fetchone()
    desc_json = exist[1] if exist else None

    if exist:
        media_id = exist[0]
        out['action'] = ACT_EXIST
    else:
        # ① 문지기 — **새로 들어오는 것만 거른다**
        if screen_on:
            why = screen(gate, row, domain)
            if why:
                out['action'] = why
                out['why'] = (row.get('title') or '')[:80]
                if why == SKIP_CHANNEL_KW:
                    try:
                        lang = row.get('lang_code') or row.get('lang') or None
                        out['kw'] = media_exclude.match_channel(
                            '%s%s%s%s%s' % (row.get('channel') or '', chr(10),
                                            row.get('title') or '', chr(10),
                                            (row.get('yt_desc') or row.get('description') or '')[:600]),
                            kw_list=_kw(getattr(gate, 'chan_kw', None), lang), lang=lang)
                    except Exception:
                        out['kw'] = ''
                return out
        # ② 분류
        cl = classify(gate, row)
        # 담는 글
        d = {'channel': (row.get('channel') or ''),
             'published': (row.get('published') or ''),
             'thumbnail': (row.get('thumbnail') or ''),
             'auto_collected': True,
             'collected_at': datetime.now().strftime('%Y-%m-%d')}
        if row.get('channel_id'):
            d['channel_id'] = row['channel_id']
        # ★ 수화 언어 코드 — 채널이 준 것만 담는다(말 언어 lang_code 와 다른 층)
        _sc = str(row.get('sign_code') or '').strip().upper()
        if _sc:
            d['sign_code'] = _sc
        elif cl['audience'] == 'SIGN':
            # 채널이 안 정했으면 **제목·설명문 실마리 → 언어코드 기본값**으로 유추
            #   (2026-09-08 사용자). 유추임을 `sign_guess` 로 남긴다.
            _g, _why = tax.infer_sign_code(
                '%s %s' % (row.get('title') or '', row.get('yt_desc') or ''),
                row.get('lang_code') or row.get('lang') or 'KO')
            if _g:
                d['sign_code'] = _g
                d['sign_guess'] = _why
        # ★ **어디서 왔는지 표식** — 경로가 제 이름을 넣는다(`rss_collected`
        #   등). 나중에 「어느 경로가 얼마나 담았나」를 셀 근거다.
        #   ⚠ 표식을 잃으면 갈래를 영영 못 센다.
        for k, v in (row.get('desc_extra') or {}).items():
            d[k] = v
        yt = row.get('yt_desc') or row.get('description') or ''
        if yt:
            # ★★★ **전문을 담는다**(2026-09-11 사용자 「설명문이 잘린다」) —
            #   600자에서 자르면 **가사가 통째로 사라진다**(가사는 뒤쪽에 있다).
            #   ⚠ 상한만 둔다 — 실측 중앙값 86자라 저장 부담은 없다.
            d['yt_desc'] = yt[:DESC_MAX]
        lang = row.get('lang_code') or row.get('lang') or 'KO'
        exk = media_exclude.match_exclude(
            '%s %s' % (row.get('title') or '', row.get('channel') or ''),
            kw_list=_kw(gate.excl_kw, lang), lang=lang)
        if exk:
            d['exclude_kw'] = exk       # ⚠ 폐기 아님 — 검토 화면이 ⚠ 로 보인다
        desc_json = json.dumps(d, ensure_ascii=False)
        if dry_run:
            out['action'] = ACT_DRY
            out.update(cl)
            return out
        # ③ 저장 — **미검토(is_active=0)로 들어온다**
        cur.execute(
            "INSERT INTO sys_media_asset "
            "(media_type, format_type, title, description, url, lang_code, "
            " audience, is_active, sort_order, record_status) "
            "VALUES (?,?,?,?,?,?,?, 0, 500, 'LIVE')",
            (cl['media_type'], cl['format_type'],
             (row.get('title') or '')[:200], desc_json, url, lang,
             cl['audience']))
        media_id = cur.lastrowid
        out['action'] = ACT_NEW
        out.update(cl)

    out['media_id'] = media_id
    # ★ 조회수 — **운영 장부 한 곳**에 적는다(`db_media_linkcheck.set_views`).
    #   `videos.list` 가 설명문과 같은 응답에 주므로 **비용이 0**이고, 링크
    #   점검이 날마다 같은 문으로 갱신한다. ⚠ **`description` 에 담지 않는다**
    #   — 매일 UPDATE 하면 감사 로그·코어 델타가 부푼다(§211차).
    # ★★★ **임베드 가능 여부를 담는 순간 적는다**(2026-09-24 · 비용 0).
    #   ⚠ 사용자 화면이 읽는 자리라 **배포되는 칸**(`sys_media_asset.embed_ok`)
    #     이어야 한다 — 점검 장부(`sys_media_check`)는 LOCAL 이다.
    #   ⚠ `None`(모름)이면 **안 건드린다** — 옛 값을 지우면 안다가 모르게 된다.
    if media_id and not dry_run and row.get('embed_ok') is not None:
        try:
            import db_media_linkcheck as _LC
            _LC.set_embed_ok(gate.conn, media_id, bool(row['embed_ok']))
        except Exception as e:
            _quiet('[intake] embed_ok: %s' % e)
    if media_id and not dry_run and row.get('views') is not None:
        try:
            import db_media_linkcheck as _LC
            _LC.set_views(gate.conn, media_id, row['views'])
        except Exception as e:
            _quiet('[intake] views: %s' % e)
    # ④ 연결
    if link and media_id and not dry_run:
        try:
            out['links'] = connect(gate, media_id, row, desc_json,
                                   hint_id=hint_id, also_entity=also_entity)
        except Exception as e:
            _quiet('[intake] link: %s' % e)
    return out


def connect(gate, media_id, row, desc_json, hint_id=None, also_entity=None):
    """구간 + 용어를 잇는다 → (구간 수, 용어 수).

    ★★★ **연결의 근거는 그 영상이 스스로 말하는 것**이다(§193차) —
      「무슨 검색어로 찾았나」가 아니다. 제목(없으면 설명문)에서 구간을 읽어
      **`MEDI_VERS` 한 줄**로 걸고, 못 정하면 **보관함**에 담는다.
    ⚠ **용어도 함께 뽑는다**(§194차 사용자 지시 — 「어디에서 수집했든지
      구절·용어를 모두 검색해야 효율적이다」).
    ⚠ 멱등 — 이미 있는 연결은 안 만든다.
    """
    conn = gate.conn
    cur = conn.cursor()
    title = row.get('title') or ''
    lang = row.get('lang_code') or row.get('lang') or 'KO'
    n_v = n_e = 0

    # ── 구간 ─────────────────────────────────────────────────────
    got, why = media_range.pick2(conn, title, desc_json)
    if got:
        _bc, s_, e_, _kind = got
        ty = media_link.lt('VERSE')
        if not cur.execute(
                "SELECT 1 FROM %s WHERE link_type=? AND clicked_id=? "
                "AND target_id=?" % media_link.TBL,
                (ty, media_id, s_)).fetchone():  # status-ok: 연결이 이미 있나 보는 자리 — 가림을 빼면 뗀 연결이 도로 생긴다
            cur.execute(
                "INSERT INTO %s (link_type, clicked_id, target_id, end_id,"
                " record_status) VALUES (?,?,?,?,'LIVE')" % media_link.TBL,
                (ty, media_id, s_, e_))
            n_v = 1
        media_range.release(conn, media_id, 'PERI')
    else:
        # ⚠ 실마리를 함께 담는다 — 검토 화면에서 사람이 정한다
        try:
            h = media_range.hints(conn, title, desc_json)
            note = ' | '.join(filter(None, [
                ' '.join('%s(%s)' % (a, b) for a, b in h['ranges']),
                ' '.join(w for w, _ in h['terms']),
                (h['snippet'] or '')[:80]]))
            media_range.hold(conn, media_id, 'PERI', why,
                             hint_id=media_link.key_int(hint_id)
                             if hint_id else None,
                             note=note or None)
        except Exception as e:
            _quiet('[intake] hold: %s' % e)

    # ── 용어 ─────────────────────────────────────────────────────
    try:
        import media_text_linker as TL
        # ⚠ **이음쇠는 줄바꿈 하나** — `TL.why_src` 가 제목 끝을
        #   글자 수로 가른다(빈칸으로 이으면 한 칸이 어긋난다).
        txt = ('%s%s%s' % (title, chr(10),
                           media_range.yt_desc(desc_json))).rstrip()
        cx = gate.ctx(lang)
        an = TL.analyze(conn, txt, cx)
        eids = set(an.get('entity') or [])
        # ★ 제목만 따로 읽는다 — 제목에 있는 이름은 근거가 강해 LIVE,
        #   설명문에서만 나온 이름은 후보(PEND). 검색 근거(also_entity)는 LIVE.
        try:
            strong = set(TL.analyze(conn, title or '', cx).get('entity') or [])
        except Exception:
            strong = set(eids)
        if also_entity:
            eids.add(int(also_entity))
            strong.add(int(also_entity))
        ty_e = media_link.lt('ENTITY')
        # ★★★ **왜 걸렸는지를 적는다**(2026-09-11 사용자 「연결추천한 용어를
        #   내가 해제한 것들이 많다. **기록이 남아 있다면 분석해 보아라**」).
        #   ⚠⚠⚠ 실측 — 사람이 뗀 264건의 `source` 가 **전부 비어 있어** 「왜
        #     걸렸나」를 판정 문에 다시 물어 되살려야 했다. 이제 담을 때 적는다.
        #   ★ 갈래(`TITLE`/`DESC`)와 **걸린 말**을 함께 — ⑤ 주제 탭의 「어떻게」
        #     칸이 그대로 읽는다(`media_link.src_label`).
        _wh = an.get('entity_why') or {}
        _tl = len(title or '')
        for eid in eids:
            if not cur.execute(
                    "SELECT 1 FROM %s WHERE link_type=? AND clicked_id=? "
                    "AND target_id=?" % media_link.TBL,
                    (ty_e, media_id, int(eid))).fetchone():  # status-ok: 연결이 이미 있나 보는 자리 — 가림을 빼면 뗀 연결이 도로 생긴다
                st = 'LIVE' if int(eid) in strong else ST_PEND
                _sv = TL.why_src(_wh.get(int(eid)), _tl)
                if also_entity and int(eid) == int(also_entity):
                    _sv = media_link.src('SEED')      # 검색 근거로 들어온 것
                cur.execute(
                    "INSERT INTO %s (link_type, clicked_id, target_id,"
                    " record_status, confidence, source)"
                    " VALUES (?,?,?,?,'AUTO',?)"
                    % media_link.TBL, (ty_e, media_id, int(eid), st, _sv))
                n_e += 1
    except Exception as e:
        _quiet('[intake] entity: %s' % e)
    return (n_v, n_e)


# ── 감사 — 이 문을 안 지나는 자리가 있나 ─────────────────────────────
def audit():
    """`sys_media_asset` 에 직접 INSERT 하는 자리를 전수로 찾는다.

    ★ **새 수집 경로를 만들면 여기 걸린다** — 문서에만 적어 두면 빠진다.
    """
    import glob
    import re
    root = os.path.dirname(os.path.abspath(__file__))
    me = os.path.basename(__file__)
    bad = []
    pat = re.compile(r'INSERT\s+(?:OR\s+\w+\s+)?INTO\s+sys_media_asset',
                     re.I)
    for f in sorted(glob.glob(os.path.join(root, '*.py'))
                    + glob.glob(os.path.join(root, 'admin', '*.py'))):
        b = os.path.basename(f)
        if b == me or b.startswith('_') or b.startswith('temp_'):
            continue
        try:
            t = io.open(f, encoding='utf-8', errors='replace').read()
        except Exception:
            continue
        for m in pat.finditer(t):
            ln = t[:m.start()].count(chr(10)) + 1
            rel = os.path.relpath(f, root).replace(os.sep, '/')
            if rel in ALLOWED_INSERT:
                continue
            bad.append((rel, ln))
    return bad


# ── 자가 검증 ────────────────────────────────────────────────────────
def fix_nfc(conn, apply_it=False, log=print):
    """이미 담긴 **자모가 흩어진 글자**를 모아 준다 → 고친 수.

    ⚠ 담는 문을 고쳐도 **이미 들어온 것은 안 바뀐다** — 실측 115편.
    ⚠ `record_status` 를 안 본다 — 가린 것도 글자는 옳아야 한다.
    """
    import unicodedata as _ud
    n = 0
    for mid, ti, ch in conn.execute(
            "SELECT media_id, title, COALESCE(description,'')"
            "  FROM sys_media_asset WHERE title IS NOT NULL").fetchall():  # status-ok: 글자를 고치는 자리 — 가린 것도 옳아야 한다
        t2 = _ud.normalize('NFC', ti)
        d2 = _ud.normalize('NFC', ch)
        if t2 == ti and d2 == ch:
            continue
        n += 1
        if apply_it:
            conn.execute('UPDATE sys_media_asset SET title=?, description=?'
                         ' WHERE media_id=?', (t2, d2, mid))
        elif n <= 5:
            log('   %-7d %s' % (mid, t2[:56]))
    if apply_it:
        conn.commit()
    return n


def selftest():
    import sqlite3
    import tempfile
    import shutil
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    d = tempfile.mkdtemp(prefix='intake_')
    dbp = os.path.join(d, 'bible_master.db')
    try:
        c = sqlite3.connect(dbp)
        c.execute("CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY,"
                  " media_type TEXT, format_type TEXT, title TEXT,"
                  " description TEXT, url TEXT, lang_code TEXT, audience TEXT,"
                  " is_active INT, sort_order INT, record_status TEXT,"
                  " fail_count INT, last_checked TEXT)")
        c.execute("CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY,"
                  " link_type TEXT, clicked_id INT, target_id INT, end_id INT,"
                  " record_status TEXT, confidence TEXT)")
        c.execute("CREATE TABLE sys_config(config_key TEXT PRIMARY KEY,"
                  " config_val TEXT)")
        c.execute("CREATE TABLE sys_media_excluded_channel(excl_id INTEGER"
                  " PRIMARY KEY, channel_name TEXT, reason_code TEXT,"
                  " record_status TEXT)")
        c.execute("CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY,"
                  " bcode INT, chapter INT, verse INT)")
        c.execute("CREATE TABLE book_names(book_code INT, lang_code TEXT,"
                  " full_name TEXT, short_name TEXT)")
        c.executemany("INSERT INTO bible_index VALUES(?,?,?,?)",
                      [(i, 1, 1, i) for i in range(1, 32)])
        c.execute("INSERT INTO book_names VALUES(1,'KO','창세기','창')")
        c.execute("INSERT INTO book_names VALUES(1,'EN','Genesis','Gen')")
        c.execute("CREATE TABLE sys_entity_master(entity_id INTEGER "
                  "PRIMARY KEY, entity_code TEXT, entity_type TEXT,"
                  " json_detail TEXT, importance INT, record_status TEXT)")
        c.execute("CREATE TABLE sys_text_asset(clicked_id INT, text_type TEXT,"
                  " lang_code TEXT, contents TEXT, record_status TEXT)")
        c.execute("CREATE TABLE sys_pericope_asset(pericope_id INTEGER"
                  " PRIMARY KEY, peri_code TEXT, peri_type TEXT,"
                  " start_vid INT, end_vid INT, record_status TEXT)")
        c.execute("INSERT INTO sys_pericope_asset VALUES"
                  "(1,'GEN_01_BODY_1','BODY',1,31,'LIVE')")
        c.commit()

        g = Gate(c, dbp)
        t('★ 재료를 한 번만 읽는다(Gate)', g.sets is not None)

        # ② 분류 — **네 갈래가 다 나온다**
        cl = classify(g, {'title': '창세기 1장 설교', 'lang_code': 'KO',
                          'channel': '어느교회'})
        t('★★★ 유형을 정한다', cl['media_type'] in
          ('SERMON', 'STUDY', 'WORSHIP', 'FILM'), cl)
        cl2 = classify(g, {'title': 'BIBLE STUDY ON GENESIS',
                           'lang_code': 'EN', 'channel': 'x'})
        t('★★ **STUDY 가 나온다**(옛 두 갈래 문에서는 불가능)',
          cl2['media_type'] == 'STUDY', cl2['media_type'])
        cl3 = classify(g, {'title': '찬양 워십 콘서트', 'lang_code': 'KO',
                           'channel': 'MARKERS WORSHIP'})
        t('  WORSHIP 도 나온다', cl3['media_type'] == 'WORSHIP',
          cl3['media_type'])
        t('  형태·대상도 함께 정한다',
          cl['format_type'] and cl['audience'] in ('GENERAL', 'KIDS'), cl)
        cl4 = classify(g, {'title': 'x', 'lang_code': 'KO', 'channel': 'y',
                           'is_kids': 1})
        t('★ 채널이 어린이면 KIDS', cl4['audience'] == 'KIDS')
        cl5 = classify(g, {'title': 'x', 'lang_code': 'KO', 'channel': 'y',
                           'audience': 'SIGN'})
        t('★★ 밖에서 준 대상이 이긴다(수화 자리)', cl5['audience'] == 'SIGN')
        # ★★ 낱말로도 수화·어린이를 가른다 — 그 언어 버킷만 본다
        cl6 = classify(g, {'title': 'Read the Bible in sign language Ruth 4',
                           'lang_code': 'EN', 'channel': 'y'})
        t('★ 낱말로 수화(SIGN)를 가른다', cl6['audience'] == 'SIGN', cl6['audience'])
        cl7 = classify(g, {'title': '민수기26장 강해 이수화목사', 'lang_code': 'KO',
                           'channel': '이수화목사'})
        t('  「이수화」는 수화가 아니다(구로만 잡는다)', cl7['audience'] == 'GENERAL',
          cl7['audience'])
        # ⚠⚠ 실제로 당한 결함 — 버킷 dict 의 **열쇠**를 낱말로 읽으면
        #   「1 Korinther」의 `ko` 가 어린이가 된다(KIDS 563 중 443 이 거짓이었다).
        cl8 = classify(g, {'title': '1 Korinther - Schlachter 2000', 'lang_code': 'DE',
                           'channel': 'Glaubensgerechtigkeit'})
        t('★★★ 버킷 열쇠(ko·de…)를 낱말로 읽지 않는다', cl8['audience'] == 'GENERAL',
          cl8['audience'])
        t('  match_kids 에 버킷 dict 를 줘도 안전하다',
          not tax.match_kids('1 Korinther', {'KO': ['어린이'], 'DE': ['Kinder']})
          and tax.match_kids('Kinderbibel', {'KO': ['어린이'], 'DE': ['Kinder']}))
        # ★ 수화 언어 코드 — 채널이 준 것이 먼저 · 없으면 제목 실마리 · 그다음 언어 기본값
        t('★ 수화코드 유추 — 제목 실마리',
          tax.infer_sign_code('Levítico 2 En lengua de Señas Paraguaya', 'ES') == ('PYS', 'TEXT'))
        t('  실마리가 없으면 언어 기본값(표식 LANG)',
          tax.infer_sign_code('Salmo 23', 'ES') == ('SSP', 'LANG'))
        t('  약어는 낱말 경계로만(Aslan 은 ASL 이 아니다)',
          tax.infer_sign_code('Aslan the lion', 'EN')[1] == 'LANG'
          and tax.infer_sign_code('sermon in ASL', 'EN') == ('ASE', 'TEXT'))
        t('  코드표가 멱등으로 선다', tax.ensure_sign_table(c) and tax.ensure_sign_table(c)
          and len(tax.sign_languages(c)) >= 19)

        # ① 문지기
        c.execute("INSERT INTO sys_media_excluded_channel"
                  "(channel_name,reason_code,record_status) "
                  "VALUES('나쁜채널','HERESY','LIVE')")
        c.commit()
        g2 = Gate(c, dbp)
        t('★★ 차단 채널은 담지 않는다',
          screen(g2, {'title': '창세기 1장', 'channel': '나쁜채널'})
          == SKIP_CHANNEL)
        t('  같은 이름이면 대소문자·공백 무시',
          screen(g2, {'title': 'x', 'channel': ' 나쁜채널 '})
          == SKIP_CHANNEL)
        t('  멀쩡한 채널은 통과',
          screen(g2, {'title': '창세기 1장 설교', 'channel': '좋은채널',
                      'lang_code': 'KO'}) is None)
        # ★★★ 채널 거르는 말 (2026-09-09) — 단체 표기는 앵커가 있어도 건너뛴다
        try:
            c.execute("ALTER TABLE sys_media_excluded_channel ADD COLUMN channel_ext_id TEXT")
        except Exception:
            pass
        c.execute("INSERT INTO sys_media_excluded_channel"
                  "(channel_name,reason_code,record_status,channel_ext_id) "
                  "VALUES('이름바꾼채널','HERESY','LIVE','UCBLOCKED1')")
        c.commit()
        g3 = Gate(c, dbp)
        t('★★★ 이단 단체 표기가 채널 이름에 있으면 건너뛴다(앵커 있어도)',
          screen(g3, {'title': '창세기 1:1 성경의 안식일', 'channel': 'Church of God TUBE 세계복음선교협회',
                      'lang_code': 'KO'}) == SKIP_CHANNEL_KW)
        t('  설명문에만 있어도 걸린다(몰몬 일본어 채널의 실태)',
          screen(g3, {'title': '創世記18-23章', 'channel': 'norio koyama', 'lang_code': 'JA',
                      'yt_desc': '末日聖徒イエス・キリスト教会の学び'}) == SKIP_CHANNEL_KW)
        t('  홑낱말은 안 넣었다 — 「전능하신 하나님」·「Church of God」·「Allah」 통과',
          screen(g3, {'title': '창세기 1장 전능하신 하나님', 'channel': 'Lawton Church of God',
                      'lang_code': 'KO'}) is None
          and screen(g3, {'title': 'Renungan Allah Yeremia 14', 'channel': 'GKI', 'lang_code': 'EN'}) is None)
        t('  안식교는 KO 에서만 걸린다(사용자 확정)',
          screen(g3, {'title': '제칠일안식일예수재림교회 안교', 'channel': 'x', 'lang_code': 'KO'})
          == SKIP_CHANNEL_KW
          and screen(g3, {'title': 'Seventh-day Adventist sermon Genesis 1', 'channel': 'x',
                          'lang_code': 'EN'}) is None)
        t('★★ 차단은 유튜브 id 로도 걸린다(이름을 바꿔도)',
          screen(g3, {'title': '창1:1', 'channel': '새이름', 'channel_id': 'UCBLOCKED1',
                      'lang_code': 'KO'}) == SKIP_CHANNEL)
        ob2 = admit(g3, {'title': '몰몬경 지리 이해 창1:1', 'url': 'https://x/lds1',
                         'channel': '후기 성도 독서', 'lang_code': 'KO'})
        t('  admit 이 걸린 낱말을 돌려준다', ob2['action'] == SKIP_CHANNEL_KW
          and ob2.get('kw') in ('후기 성도', '몰몬'), ob2)

        # ③ 담기
        r1 = {'title': '창세기 1장 1절 설교', 'url': 'https://y/1',
              'lang_code': 'KO', 'channel': '좋은채널'}
        o1 = admit(g2, r1)
        t('★ 새것을 담는다', o1['action'] == ACT_NEW, o1['action'])
        mid = o1['media_id']
        row = c.execute("SELECT media_type, format_type, audience, is_active,"
                        " lang_code FROM sys_media_asset WHERE media_id=?",
                        (mid,)).fetchone()
        t('★★★ **분류가 담긴다**', row[0] in
          ('SERMON', 'STUDY', 'WORSHIP', 'FILM'), row)
        t('★★ 대상 칸이 채워진다(수화 대비)', row[2] in ('GENERAL', 'KIDS'),
          row[2])
        t('★ **미검토로 들어온다**(승인은 사람이)', row[3] == 0)
        o2 = admit(g2, r1)
        t('★★ 같은 URL 은 기존 것을 쓴다(멱등)',
          o2['action'] == ACT_EXIST and o2['media_id'] == mid, o2['action'])
        # ★★★ **HTML 기호를 문에서 푼다**(2026-09-12 실측 제목 1,895편)
        oh = admit(g2, {'title': '악보&amp;찬양 창1:1 &#39;말씀&#39;',
                        'url': 'https://y/ent', 'lang_code': 'KO',
                        'channel': 'Light&amp;Delight'})
        rh = c.execute("SELECT title, description FROM sys_media_asset"
                       "  WHERE media_id=?", (oh['media_id'],)).fetchone()
        t('★★★ 제목의 HTML 기호를 푼다',
          '&amp;' not in rh[0] and '악보&찬양' in rh[0], rh[0])
        t('★★ 작은따옴표 기호도 푼다', "'말씀'" in rh[0], rh[0])
        t('★★ 채널 이름의 기호도 푼다',
          'Light&Delight' in (rh[1] or ''), (rh[1] or '')[:60])
        # 쌓인 것을 걷는 문 — 멱등
        c.execute("UPDATE sys_media_asset SET title='다시&amp;넣음'"
                  "  WHERE media_id=?", (oh['media_id'],))
        n1 = sweep_entities(c, log=lambda *a: None)
        n2 = sweep_entities(c, log=lambda *a: None)
        t('★★ 쌓인 기호를 걷는다', n1[0] == 1 and n2[0] == 0, (n1, n2))
        t('  걷은 뒤 제목이 옳다', c.execute(
            "SELECT title FROM sys_media_asset WHERE media_id=?",
            (oh['media_id'],)).fetchone()[0] == '다시&넣음')
        c.execute("DELETE FROM sys_media_asset WHERE media_id=?", (oh['media_id'],))
        n_all = c.execute("SELECT COUNT(*) FROM sys_media_asset").fetchone()[0]
        t('  행이 안 는다', n_all == 1, n_all)

        # ⚠ 이미 있는 것은 다시 분류하지 않는다
        c.execute("UPDATE sys_media_asset SET media_type='FILM' WHERE "
                  "media_id=?", (mid,))
        c.commit()
        admit(g2, r1)
        got = c.execute("SELECT media_type FROM sys_media_asset WHERE "
                        "media_id=?", (mid,)).fetchone()[0]
        t('★★★ **사람이 고친 유형을 안 덮는다**', got == 'FILM', got)

        # ④ 연결
        lk = c.execute("SELECT link_type, target_id, end_id FROM "
                       "sys_link_asset WHERE clicked_id=?", (mid,)).fetchall()
        t('★★ 구간을 건다(MEDI_VERS)',
          any(x[0] == 'MEDI_VERS' for x in lk), lk[:3])
        t('  같은 연결을 두 번 안 만든다',
          len([x for x in lk if x[0] == 'MEDI_VERS']) == 1, lk[:3])

        # 좌표가 없으면 보관함
        o3 = admit(g2, {'title': '오늘의 은혜', 'url': 'https://y/2',
                        'lang_code': 'KO', 'channel': '좋은채널'})
        if o3['action'] == ACT_NEW:
            pend = c.execute("SELECT COUNT(*) FROM sys_media_pending WHERE "
                             "media_id=?", (o3['media_id'],)).fetchone()[0]
            t('★★ 구간을 못 정하면 **보관함**에 담는다', pend == 1, pend)
        else:
            t('  (오프토픽으로 걸러짐 — 그것도 정상)',
              o3['action'] == SKIP_OFFTOPIC, o3['action'])

        # ★★★ **쇼츠는 담지 않는다**(2026-09-11 사용자)
        import db_media_linkcheck as _LC9
        os1 = admit(g2, {'title': '창세기 1장 강해', 'url': 'https://y/short1',
                         'duration': 95, 'lang_code': 'KO'})
        t('★★★ **2분 이하는 안 담는다**', os1['action'] == SKIP_SHORT,
          os1['action'])
        os2 = admit(g2, {'title': '#shorts 하나님(GOD)', 'url': 'https://y/s2', 'lang_code': 'KO'})
        t('★★★ **제목이 쇼츠라고 적으면 안 담는다**(길이를 몰라도)',
          os2['action'] == SKIP_SHORT, os2['action'])
        os3 = admit(g2, {'title': '창세기 1장 강해', 'url': 'https://y/long1',
                         'duration': 900, 'lang_code': 'KO'})
        t('★ 긴 것은 담는다', os3['action'] != SKIP_SHORT, os3['action'])
        os4 = admit(g2, {'title': 'Short film 창세기', 'url': 'https://y/s4', 'lang_code': 'KO'})
        t('★★ **홑낱말 short 는 안 먹는다**', os4['action'] != SKIP_SHORT,
          os4['action'])
        t('★ 문턱이 2분이다', _LC9.SHORT_SEC == 120)

        # dry_run
        n0 = c.execute("SELECT COUNT(*) FROM sys_media_asset").fetchone()[0]
        od = admit(g2, {'title': '창세기 2장', 'url': 'https://y/9',
                        'lang_code': 'KO', 'channel': '좋은채널'},
                   dry_run=True)
        n1 = c.execute("SELECT COUNT(*) FROM sys_media_asset").fetchone()[0]
        t('★ dry_run 은 한 글자도 안 쓴다',
          od['action'] == ACT_DRY and n0 == n1, (od['action'], n0, n1))
        t('  그래도 분류는 알려 준다', od.get('media_type') is not None,
          od.get('media_type'))

        # ★★★ **담는 순간 임베드 가능 여부를 적는다**(2026-09-24 · 비용 0)
        oe = admit(g2, {'title': '창세기 3장 강해', 'url': 'https://y/emb1',
                        'lang_code': 'KO', 'channel': '좋은채널',
                        'embed_ok': 0})
        _ev = c.execute("SELECT embed_ok FROM sys_media_asset WHERE media_id=?",
                        (oe['media_id'],)).fetchone()
        t('★★★ 담는 순간 **임베드 막힘을 적는다**(점검을 안 기다린다)',
          _ev and _ev[0] == 0, str(_ev))
        oe2 = admit(g2, {'title': '창세기 4장 강해', 'url': 'https://y/emb2',
                         'lang_code': 'KO', 'channel': '좋은채널'})
        _ev2 = c.execute("SELECT embed_ok FROM sys_media_asset WHERE media_id=?",
                         (oe2['media_id'],)).fetchone()
        t('★★ **모르면 안 적는다**(「모름」과 「된다」는 다르다)',
          _ev2 and _ev2[0] is None, str(_ev2))

        # URL 없음
        t('  URL 이 없으면 거부',
          admit(g2, {'title': 'x'})['action'] == SKIP_NO_URL)

        # ⑤ 보고 — 왜 건너뛰었는지 말한다(§0-1)
        ob = admit(g2, {'title': 'x', 'url': 'https://y/3',
                        'channel': '나쁜채널'})
        t('★★ **왜 안 담았는지 말한다**', ob['action'] == SKIP_CHANNEL
          and ob['media_id'] is None, ob['action'])

        # ── 감사 — 이 문을 안 지나는 자리 ────────────────────────
        bad = audit()
        print('')
        print('  ── sys_media_asset 에 직접 INSERT 하는 자리 %d곳 ──'
              % len(bad))
        for f, ln in bad:
            print('     %s:%d' % (f, ln))
        # ★★★ **이것이 사용자 지시를 잠그는 항목이다** — 「어떤 방법으로
        #   수집했던지 공통적으로 거쳐야 할 품질관리는 반드시 거치도록」.
        #   ⚠ 새 수집 경로를 만들면 **여기서 그 자리에서 잡힌다.**
        #     수집이 아닌 자리는 `ALLOWED_INSERT` 에 **왜인지 적고** 넣는다.
        t('★★★ **모든 수집 경로가 이 문을 지난다**(직접 INSERT 0곳)',
          not bad, bad[:3])

        # ── 링커가 낱말 경계를 지키는가 (2026-09-08) ────────────────
        # ★★★ **오연결 11,308건의 뿌리**가 여기였다 — `media_text_linker`
        #   3패스가 `low.find` 로 **부분 문자열**만 봐서 「엘」(EN `Er`)이
        #   `chapter` 에, 「벨」(`Bel`)이 `Abel` 에 걸렸다. §195차가 만든
        #   `db_media_range.name_ok` 를 **그 자리가 안 쓰고 있었다.**
        # ⚠ 반대 방향도 함께 잰다 — 2패스가 `Isa`(이사야)를 `Isaac` 속에서
        #   소비해 **이삭을 먹던 미탐**이 있었다. 한쪽만 고치면 남는다.
        try:
            import appdb as _ap
            import media_text_linker as _tl
            _rc = _ap.connect()
            try:
                _cx = _tl.build_context(_rc, 'KO')

                def _ents(txt):
                    return set(_tl.analyze(_rc, txt, _cx)['entity'])

                def _eid(code):
                    r = _rc.execute("SELECT entity_id FROM sys_entity_master"
                                    " WHERE entity_code=?", (code,)).fetchone()
                    return r[0] if r else None

                _abel, _isaac = _eid('P_ABEL'), _eid('P_ISAAC')
                _e1 = _ents('Cain and Abel and God')
                t('★★★ 낱말 속 이름을 안 잡는다(A-bel 에 「벨」)',
                  (_abel is None or _abel in _e1)
                  and not (_ents('Genesis 1:6-8 Explained')
                           | _ents('Truth Set Free')))
                t('★ 책 약명이 이름을 먹지 않는다(Isa-ac)',
                  _isaac is None or _isaac in _ents('Abraham and Isaac'))
                t('  CJK 이름이 살아 있다',
                  bool(_ents('大衛的詩篇')))
                _dav = _eid('P_DAVID')
                if _dav is not None:
                    t('★★★ 「Pastor David Guzik」 은 다윗이 아니다 · 「King David」 는 다윗',
                      _dav not in _ents('Daily devotional by Pastor David Guzik')
                      and _dav in _ents('King David and Bathsheba'))
                    t('  「read by David Suchet」 성이 붙으면 다윗이 아니다',
                      _dav not in _ents('Gospel of John read by David Suchet'))
                _rk = lambda s_: sorted({(_r[0], _r[1]) for _r in
                                         (_tl.analyze(_rc, s_, _cx).get('ranges') or [])})
                _act = _rk('사도행전 2:1 설교')
                _ecc = _rk('전도서 2:1 설교')
                t('★★★ 「사도행전 2:1」 은 행2:1 하나 — 속의 「전」이 전도서로 안 걸린다',
                  len(_act) == 1 and _act != _ecc, (_act, _ecc))
                t('★★★ 「오전 11:00 예배」 는 전도서 11장이 아니다',
                  not _rk('주일 오전 11:00 예배'), _rk('주일 오전 11:00 예배'))
                t('  약명 앞이 부호·공백이면 읽는다((전2:1) · 수 19:32)',
                  _rk('(전2:1) 설교') == _ecc and bool(_rk('납달리 기업 수 19:32')),
                  (_rk('(전2:1) 설교'), _rk('납달리 기업 수 19:32')))
            finally:
                _rc.close()
        except Exception as _e:          # 실 DB 가 없으면 건너뛴다
            t('  (링커 경계 시험 건너뜀)', True, _e)

        # 탐지력 — 표를 비우면 잡히는가
        _save = dict(ALLOWED_INSERT)
        try:
            ALLOWED_INSERT.clear()
            t('  탐지력: 허가를 비우면 잡아낸다', len(audit()) > 0,
              len(audit()))
        finally:
            ALLOWED_INSERT.update(_save)
    finally:
        try:
            c.close()
        except Exception:
            pass
        shutil.rmtree(d, ignore_errors=True)
    # ── ★★★ 분야 축 (2026-09-10 사용자 지시) ──────────────────────
    #   「원하는가」를 묻는 층(오프토픽)에만 걸리고 「무엇인가」를 묻는 층
    #   (채널 차단·콘텐츠 거르는 말)은 분야가 못 바꾼다.
    try:
        import media_exclude as _ME
        _g = type('G', (), {})()
        # ⚠ **DB 가 필요 없다** — 앵커 판정은 `screen` 안에서 try 로 감싸여
        #   있어 conn 이 없으면 앵커 없음(=오프토픽이 걸리는 쪽)으로 떨어진다.
        #   그것이 이 시험이 재려는 자리다.
        _g.conn = None
        _g.db_path = _db_path()
        _g.sets = {}
        _g.excl_ch = set()
        _g.excl_ids = set()
        _g.chan_kw = {}
        _g.excl_kw = {}
        _g.off_kw = _ME.OFFTOPIC_KW_LANG
        _g.off_domain = _ME.DEFAULT_OFFTOPIC_DOMAIN
        _row = {'title': 'Best Worship Songs 2026 Nonstop Playlist',
                'channel': 'Top Praise and Worship Songs',
                'yt_desc': '', 'lang_code': 'EN'}
        t('★★★ **분야 없이 부르면 옛 판정 그대로**(회귀 0)',
          screen(_g, _row) == SKIP_OFFTOPIC)
        t('★★★ **찬양 분야를 주면 통과한다**',
          screen(_g, _row, domain='WORSHIP') is None)
        # ⚠⚠ 분야가 채널 차단을 이기면 안 된다 — 전능신교는 어느 분야에서
        #   찾아도 전능신교다.
        _g2 = type('G', (), {})()
        for k in ('conn', 'db_path', 'sets', 'excl_ids', 'excl_kw',
                  'off_kw', 'off_domain'):
            setattr(_g2, k, getattr(_g, k))
        _g2.excl_ch = {'전능신교회'}
        _g2.chan_kw = {}
        t('★★★ **분야가 채널 차단을 못 이긴다**(전능신교는 공통)',
          screen(_g2, {'title': '基督教會歌曲《詩歌MV》', 'channel': '전능신교회',
                       'yt_desc': '', 'lang_code': 'KO'},
                 domain='WORSHIP') == SKIP_CHANNEL)
        t('★★ **분야가 채널 거르는 말도 못 이긴다**',
          screen(type('G', (), {**_g.__dict__,
                                'chan_kw': {'KO': ['전능하신 하나님 교회']}})(),
                 {'title': '찬양 모음', 'channel': '전능하신 하나님 교회',
                  'yt_desc': '', 'lang_code': 'KO'},
                 domain='WORSHIP') == SKIP_CHANNEL_KW)
        t('★ `admit` 도 분야를 받는다',
          'domain' in admit.__code__.co_varnames)
    except Exception as _e:
        t('★ 분야 축 시험이 돈다', False, repr(_e))

    # ── ⑨ 걸러짐 보관함 ──────────────────────────────────────────────
    try:
        c2 = sqlite3.connect(':memory:')
        c2.execute("CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY,"
                   " url TEXT, record_status TEXT)")
        ensure_skip(c2)
        row = {'url': 'https://y/1', 'title': '보혈 3시간', 'channel': 'CH',
               'channel_id': 'UC1', 'lang_code': 'KO', 'yt_desc': '설명',
               'published': '2026-01-01'}
        t('★ 걸러진 줄을 보관함에 적는다',
          note_skip(c2, row, SKIP_OFFTOPIC, domain='WORSHIP') is True)
        note_skip(c2, row, SKIP_OFFTOPIC, domain='WORSHIP')
        n = c2.execute("SELECT n FROM %s WHERE url=?" % SKIP_TBL,
                       ('https://y/1',)).fetchone()[0]
        t('★★ **멱등** — 두 번 걸려도 줄은 하나이고 횟수만 는다',
          c2.execute("SELECT COUNT(*) FROM %s" % SKIP_TBL).fetchone()[0] == 1
          and n == 2, 'n=%s' % n)
        t('★ 사유 없으면 안 적는다', note_skip(c2, row, '') is False)
        t('★ 주소 없으면 안 적는다',
          note_skip(c2, {'title': 'x'}, SKIP_OFFTOPIC) is False)
        rs = skip_rows(c2, domain='WORSHIP')
        t('★ 보관함 목록에 나온다', len(rs) == 1 and rs[0]['n'] == 2)
        t('★ 분야가 다르면 안 나온다', skip_rows(c2, domain='VERSE') == [])
        t('★ 사유별 개수', skip_counts(c2, domain='WORSHIP')
          .get(SKIP_OFFTOPIC) == 1)
        # ★★★ 이미 담은 것은 안 낸다 — 사용자 지시
        c2.execute("INSERT INTO sys_media_asset(media_id, url, record_status)"
                   " VALUES(1,'https://y/1','LIVE')")
        t('★★★ **이미 담은 것은 보관함에 안 낸다**(사용자)',
          skip_rows(c2, domain='WORSHIP') == [])
        t('★★ 개수도 함께 준다 — 화면과 수가 어긋나지 않는다',
          skip_counts(c2, domain='WORSHIP') == {})
        # ★★ 가려 둔 것도 「담은 것」이다(다시 담으면 안 된다)
        c2.execute("UPDATE sys_media_asset SET record_status='HIDE'")
        t('★★ **가려 둔 것도 담은 것** — 보관함에 안 낸다',
          skip_rows(c2, domain='WORSHIP') == [])
        c2.execute("DELETE FROM sys_media_asset")
        t('★ 되돌아온다', len(skip_rows(c2, domain='WORSHIP')) == 1)
        t('★ 담고 나면 걷는다', drop_skip(c2, 'https://y/1') == 1
          and skip_rows(c2) == [])
        t('★ 없는 주소를 걷어도 안 터진다', drop_skip(c2, 'https://y/none') == 0)
        c2.close()
    except Exception as _e:
        t('★ 걸러짐 보관함 시험이 돈다', False, repr(_e))

    print('media_intake selftest: %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    if '--audit' in sys.argv:
        bad = audit()
        print('sys_media_asset 에 직접 INSERT 하는 자리 %d곳:' % len(bad))
        for f, ln in bad:
            print('  %s:%d' % (f, ln))
        sys.exit(0)
    print(__doc__)
