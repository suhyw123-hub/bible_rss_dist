# -*- coding: utf-8 -*-
"""본문 재진술 전수 감사 — 결과를 파일로 남긴다(영구 도구, 반복 실행용).

배경(2026-07-28): 사용자 지적 "왜 구절 본문을 그대로 인용하는가. 절대 금기사항이다"로
  누가 11~12장을 조사하다 **전 코퍼스 문제**임이 드러났다. 실측 403,321문장 중
  ≥0.55 재진술 23,811건(5.9%), 영향 절 8,356/9,848(85%). 창세기 7.1%·마태 4.2%.
  국소 회귀가 아니라 처음부터의 패턴이다.

사용자 결정(2026-07-28): "23811건 따로 저장하라. 어차피 남은 책에서도 발생할 가능성이
  있다. 누가복음, 요한복음 완성하고 신약성경 전체 재점검하자."
  ⇒ 지금 스냅샷을 남기고, 누가·요한 완간 후 이 도구를 다시 돌려 **전량 정리**한다.

원리: verserep 게이트는 문장 **전체**를 본문 전체와 비교(ratio>=0.70)하므로, 본문 일부를
  옮기고 뒤에 해설을 붙이면 통과한다. 이 도구는 **길이를 맞춘 슬라이딩 창**으로 본문의
  어느 구간과도 비교해 부분 재진술을 잡는다(temp_code_restate_check.py 와 동일 판정).

출력: audit/restate_<stamp>.tsv  (bcode/chapter/verse/variant/lang/ratio/first/sentence)
      audit/restate_<stamp>.summary.txt

용법:
  python -X utf8 db_restate_audit.py --stamp 20260728          # 전 책
  python -X utf8 db_restate_audit.py --stamp 20260728 --books 42,43
  python -X utf8 db_restate_audit.py --stamp 20260728 --th 0.70
"""
import collections, difflib, os, re, sqlite3, sys
from concurrent.futures import ProcessPoolExecutor

ROOT = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(ROOT, 'bible_master.db')
OUTDIR = os.path.join(ROOT, 'audit')
SENT = re.compile(r'(?<=[.?!])\s+|\n+')
DEFAULT_TH = 0.55
BOOKS = [1, 27, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54,
         55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66]


def sents(t):
    return [s.strip() for s in SENT.split(t or '') if len(s.strip()) > 8]


def best_ratio(s, base):
    """문장 s 가 본문 base 의 어느 구간과도 얼마나 겹치는가(길이 맞춘 슬라이딩)."""
    r = difflib.SequenceMatcher(None, s, base).ratio()
    w = len(s)
    for i in range(0, max(1, len(base) - w + 1), 4):
        r = max(r, difflib.SequenceMatcher(None, s, base[i:i + w]).ratio())
    return r


def scan_book(arg):
    bc, th = arg
    c = sqlite3.connect(DB, timeout=300).cursor()
    src = {}
    for vid, vc, t in c.execute("SELECT verse_id,version_code,verse_text FROM bible_content "
                                "WHERE version_code IN ('KRV','BSB')"):
        src[(vid, vc)] = t
    rows = c.execute("""SELECT b.chapter,b.verse,b.verse_id,t.text_variant,t.lang_code,t.contents
        FROM sys_text_asset t JOIN bible_index b ON t.clicked_id=b.verse_id
        WHERE b.bcode=? AND t.text_type='VERS_DESC'
          AND COALESCE(t.record_status,'LIVE')='LIVE'
        ORDER BY b.verse_id""", (bc,)).fetchall()
    hits, total = [], 0
    for ch, vs, vid, var, lg, txt in rows:
        base = src.get((vid, 'KRV' if lg == 'KO' else 'BSB'), '')
        if not base:
            continue
        for i, s in enumerate(sents(txt)):
            total += 1
            r = best_ratio(s, base)
            if r >= th:
                hits.append((bc, ch, vs, var or '', lg, round(r, 3),
                             1 if i == 0 else 0, s.replace('\t', ' ')[:200]))
    return bc, total, hits


def main():
    try: sys.stdout.reconfigure(encoding='utf-8')
    except Exception: pass
    a = sys.argv
    stamp = a[a.index('--stamp') + 1] if '--stamp' in a else 'now'
    th = float(a[a.index('--th') + 1]) if '--th' in a else DEFAULT_TH
    books = ([int(x) for x in a[a.index('--books') + 1].split(',')]
             if '--books' in a else BOOKS)

    os.makedirs(OUTDIR, exist_ok=True)
    tsv = os.path.join(OUTDIR, f'restate_{stamp}.tsv')
    smy = os.path.join(OUTDIR, f'restate_{stamp}.summary.txt')

    total = 0
    per_book = {}
    lane = collections.Counter()
    verses = set()
    with open(tsv, 'w', encoding='utf-8', newline='') as f:
        f.write('bcode\tchapter\tverse\tvariant\tlang\tratio\tfirst_sent\tsentence\n')
        with ProcessPoolExecutor(max_workers=6) as ex:
            for bc, tot, hits in ex.map(scan_book, [(b, th) for b in books]):
                total += tot
                per_book[bc] = (tot, len(hits))
                for h in hits:
                    lane[f'{h[3]}.{h[4]}'] += 1
                    verses.add((h[0], h[1], h[2]))
                    f.write('\t'.join(str(x) for x in h) + '\n')
                print(f'  bc={bc:3d}  문장 {tot:6d}  재진술 {len(hits):5d} '
                      f'({len(hits)/max(tot,1)*100:4.1f}%)', flush=True)

    hit_total = sum(v[1] for v in per_book.values())
    lines = [f'본문 재진술 감사  stamp={stamp}  문턱={th}',
             f'검사 문장 {total}  재진술 {hit_total} ({hit_total/max(total,1)*100:.1f}%)',
             f'영향 절 {len(verses)}', '', '[레인별]']
    lines += [f'  {k:12s} {v:6d}' for k, v in lane.most_common()]
    lines += ['', '[책별]']
    lines += [f'  bc={b:3d}  문장 {t:6d}  재진술 {h:5d} ({h/max(t,1)*100:4.1f}%)'
              for b, (t, h) in sorted(per_book.items())]
    open(smy, 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
    print('\n' + '\n'.join(lines[:4]))
    print(f'\n저장: {tsv}\n      {smy}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
