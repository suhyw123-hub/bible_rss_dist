# -*- coding: utf-8 -*-
"""db_plan_audit.py — 묵상플랜 구절 구성의 적정성 점검 (2026-10-13 docs/1.txt 85 · 영구)

사용자 「모든 묵상플랜을 구성하는 구절 구성의 적정성 재점검 — 플랜의 목적에 맞게 매일매일 구절이 설계되어
있는가? 기적에 대한 플랜인데 기적과 전혀 무관한 구절들이 포함되어 있는가? 설명문이 적절한가? 오탈자?
구절과 연관성? 읽기에 편안한가?」 → 의견 → 「네 계획대로 하라」.

세 층:
  ① **기계 점검**(`--machine` · AI 없음 · 전체 플랜) — 없는 절 · 거꾸로 된 구간 · 빈 날 · 같은 구간 되풀이 ·
     통독 플랜의 빠진 절/겹친 절 · 하루 분량 들쭉날쭉 · 빈 글 껍데기 · 글 속 약명이 그날 범위 밖 · 문체 흠.
  ② **AI 판정**(`--ai 플랜번호 [--limit N]`) — 하루마다 「플랜 목적 + 그날 구절 본문 + 그날 글」을 보내
     적합/의심/부적합 · 까닭 · 무관한 묶음 · 오탈자 · 읽기 편한가 · 고칠 제안을 받는다(`temp_plan_audit` 에 담는다 ·
     배포 안 함). 마지막에 그 플랜의 **설명문 초안**(목적)도 받는다 — 사람이 보고 정한다.
  ③ **사람** — 의심·부적합만 본다(`--report 플랜번호`). ⚠ **이 도구는 아무것도 고치지 않는다.**

    python db_plan_audit.py --selftest      (의무)
    python db_plan_audit.py --machine       → _plan_audit_machine.txt
    python db_plan_audit.py --ai 16         → temp_plan_audit · _plan_audit_ai_16.txt
    python db_plan_audit.py --report 16
"""
import json
import re
import statistics
import sys
import time

import appdb

READING_TYPES = ('SEQUENTIAL', 'CHRONOLOGICAL', 'MCHEYNE')
STAGE_KO = {
    'EVENT': '사건(구약 이야기·모형)', 'LAW': '율법·제사 규정', 'FULFILLMENT': '신약의 성취',
    'EXPANSION': '넓혀 읽기', 'EXPAND': '넓혀 읽기', 'APPLICATION': '적용', 'MIRACLE': '기적',
    'OT_TYPE': '구약 예표', 'CONFIRM': '확인', 'PSA': '시편', 'CORE': '핵심', 'AUXILIARY': '보조', 'SUPPORT': '뒷받침',
}
AUDIT_TBL = 'temp_plan_audit'
_STYLE = [(re.compile(r'[—–]'), '대시(—)'), (re.compile(r'[①-⑳]'), '동그라미 번호'),
          (re.compile(r'(하나요|할까요|일까요)\?'), '「…나요/까요?」 물음꼴')]


def _ref(conn, vid, end=None):
    import scripture_ref as SR
    try:
        return SR.label(conn, vid, end or vid, 'KO')
    except Exception:                                     # noqa: BLE001
        return str(vid)


def plans(conn):
    return conn.execute(
        "SELECT p.plan_id, p.plan_code, p.plan_type, COALESCE(p.duration_days,0),"
        " (SELECT contents FROM sys_text_asset WHERE text_type='PLAN_TITLE' AND clicked_id=p.plan_id"
        "   AND lang_code='KO' LIMIT 1) FROM sys_bible_plan p"
        " WHERE COALESCE(p.record_status,'LIVE')='LIVE' ORDER BY p.plan_id").fetchall()


def _rows(conn, pid):
    return conn.execute(
        'SELECT schedule_id, day, COALESCE(track,0), start_vid, end_vid, COALESCE(stage_type,\'\'),'
        " COALESCE(meditation_focus,'') FROM sys_plan_schedule WHERE plan_id=? ORDER BY day, track, sort_order,"
        ' schedule_id', (pid,)).fetchall()


def _texts(conn, sid):
    out = {}
    for tt, body in conn.execute(
            "SELECT text_type, contents FROM sys_text_asset WHERE clicked_id=? AND lang_code='KO'"
            " AND text_type IN ('PLAN_FOCUS','PLAN_QUESTION') AND COALESCE(record_status,'LIVE')='LIVE'",
            (sid,)):
        out[tt] = body or ''
    return out


# ══════════════════════════════════════════════════════════════════
#  ① 기계 점검
# ══════════════════════════════════════════════════════════════════
def machine(conn, pid=None):
    """→ [(plan_id, day, 심각(흠|참고), 갈래, 말)]"""
    import scripture_ref as SR
    vids = {r[0] for r in conn.execute('SELECT verse_id FROM bible_index')}
    canon = sorted(v for v in vids if v <= 31102)
    out = []
    for p_id, code, typ, dur, _ttl in plans(conn):
        if pid and p_id != pid:
            continue
        rows = _rows(conn, p_id)
        if not rows:
            continue
        days = {}
        seen_rng = {}
        cover = {}
        empty_shell = 0
        for sid, day, trk, a, b, st, mf in rows:
            b = b or a
            days.setdefault(day, []).append((a, b))
            if a not in vids or b not in vids:
                out.append((p_id, day, '흠', '없는 절', '구간 %s~%s 가운데 없는 절 번호' % (a, b)))
                continue
            if b < a:
                out.append((p_id, day, '흠', '거꾸로', '%s 의 끝이 시작보다 앞' % _ref(conn, a, b)))
            if typ not in READING_TYPES:
                k = (a, b)
                if k in seen_rng and seen_rng[k] != day:
                    out.append((p_id, day, '참고', '되풀이', '%s 가 %d일째에도 있다' % (_ref(conn, a, b), seen_rng[k])))
                seen_rng.setdefault(k, day)
            if typ in READING_TYPES:
                for v in range(a, b + 1):
                    cover[v] = cover.get(v, 0) + 1
            tx = _texts(conn, sid)
            for tt in ('PLAN_FOCUS', 'PLAN_QUESTION'):
                if tt in tx and not tx[tt].strip():
                    empty_shell += 1
            body = ' '.join([mf] + [x for x in tx.values() if x])
            if body.strip():
                for ra, rb, m, _k in SR.linkable(SR.find(conn, body, 'KO', limit=50)):
                    if not any(x <= ra and rb <= y for x, y in days[day]) and \
                            not any(x <= ra <= y for x, y in [(a, b)]):
                        out.append((p_id, day, '참고', '범위 밖 약명', '글 속 「%s」 가 이날 읽는 범위 밖' % m))
                for rx, nm in _STYLE:
                    if rx.search(body):
                        out.append((p_id, day, '참고', '문체', nm))
        mx = max(days)
        miss_days = [d for d in range(1, mx + 1) if d not in days]
        if miss_days:
            out.append((p_id, 0, '흠', '빈 날', '%d일 빔: %s' % (len(miss_days), miss_days[:10])))
        if dur and mx != dur:
            out.append((p_id, 0, '참고', '일수', '정한 일수 %d · 실제 마지막 날 %d' % (dur, mx)))
        if empty_shell:
            out.append((p_id, 0, '참고', '빈 글 껍데기', '포커스·질문 줄 %d개가 비어 있다(글 없는 행)' % empty_shell))
        if typ in READING_TYPES:
            gap = [v for v in canon if v not in cover]
            dup = sum(1 for v, n in cover.items() if n > 1)
            if gap:
                out.append((p_id, 0, '흠', '빠진 절', '%d절 · 처음 %s' % (len(gap), _ref(conn, gap[0]))))
            if dup and code != 'MCHEYNE_1Y':
                out.append((p_id, 0, '참고', '겹친 절', '%d절이 두 번 이상' % dup))
            sizes = [sum(b - a + 1 for a, b in rs) for rs in days.values()]
            med = statistics.median(sizes) if sizes else 0
            odd = [d for d, rs in days.items()
                   if med and (sum(b - a + 1 for a, b in rs) > 3 * med or sum(b - a + 1 for a, b in rs) < med / 3)]
            if odd:
                out.append((p_id, 0, '참고', '분량', '하루 분량이 중앙값(%d절)의 3배 넘거나 1/3 못 되는 날 %d개: %s'
                            % (med, len(odd), sorted(odd)[:10])))
    return out


def write_machine(conn, path='_plan_audit_machine.txt'):
    found = machine(conn)
    names = {p[0]: (p[1], p[2], p[4]) for p in plans(conn)}
    by = {}
    for f in found:
        by.setdefault(f[0], []).append(f)
    lines = ['묵상플랜 기계 점검 — 흠 %d · 참고 %d' % (sum(1 for f in found if f[2] == '흠'),
                                               sum(1 for f in found if f[2] == '참고')), '']
    for pid in sorted(by):
        code, typ, ttl = names.get(pid, ('?', '?', ''))
        lines.append('%d %s [%s] %s' % (pid, code, typ, ttl or ''))
        kinds = {}
        for _p, day, sev, kind, msg in by[pid]:
            kinds.setdefault((sev, kind), []).append((day, msg))
        for (sev, kind), items in sorted(kinds.items()):
            lines.append('   %s · %s %d건' % (sev, kind, len(items)))
            for day, msg in items[:6]:
                lines.append('      %s%s' % (('%d일 ' % day) if day else '', msg))
        lines.append('')
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))
    return found


# ══════════════════════════════════════════════════════════════════
#  ② AI 판정
# ══════════════════════════════════════════════════════════════════
def ensure(conn):
    conn.execute('CREATE TABLE IF NOT EXISTS %s (plan_id INTEGER, day INTEGER, verdict TEXT, reason TEXT,'
                 ' off_refs TEXT, typos TEXT, readability TEXT, fix TEXT, raw TEXT, created_at TEXT,'
                 ' PRIMARY KEY(plan_id, day))' % AUDIT_TBL)


def _verse_text(conn, a, b, cap=1600):
    t = ' '.join('%d %s' % (v, x or '') for v, x in conn.execute(
        "SELECT bi.verse, c.verse_text FROM bible_index bi JOIN bible_content c ON c.verse_id=bi.verse_id"
        " AND c.version_code='KRV' WHERE bi.verse_id BETWEEN ? AND ? ORDER BY bi.verse_id", (a, b)))
    return t if len(t) <= cap else t[:cap] + ' …(이하 줄임)'


def plan_head(conn, pid):
    r = conn.execute("SELECT plan_code, plan_type FROM sys_bible_plan WHERE plan_id=?", (pid,)).fetchone()
    t = conn.execute("SELECT contents FROM sys_text_asset WHERE text_type='PLAN_TITLE' AND clicked_id=?"
                     " AND lang_code='KO'", (pid,)).fetchone()
    d = conn.execute("SELECT contents FROM sys_text_asset WHERE text_type='PLAN_DESC' AND clicked_id=?"
                     " AND lang_code IN ('KO','EN') ORDER BY lang_code='KO' DESC LIMIT 1", (pid,)).fetchone()
    return (t[0] if t else r[0]), (d[0] if d else ''), r[1]


def day_prompt(conn, pid, day):
    title, desc, typ = plan_head(conn, pid)
    rows = [r for r in _rows(conn, pid) if r[1] == day]
    stages = sorted({r[5] for r in _rows(conn, pid) if r[5]})
    parts = ['너는 성경 묵상 플랜 검수자다. 아래 플랜의 하루 분량이 플랜의 목적에 맞는지 판정한다.',
             '', '[플랜] %s' % title,
             '[플랜 설명] %s' % (desc or '(설명 없음 — 제목과 묶음 역할로 목적을 짐작한다)')]
    if stages:
        parts.append('[묶음 역할] ' + ' · '.join('%s=%s' % (s, STAGE_KO.get(s, s)) for s in stages))
    parts += ['', '[%d일째]' % day]
    texts = []
    for sid, _d, _t, a, b, st, mf in rows:
        b = b or a
        parts.append('- %s%s: %s' % (('(%s) ' % STAGE_KO.get(st, st)) if st else '', _ref(conn, a, b),
                                     _verse_text(conn, a, b)))
        tx = _texts(conn, sid)
        for x in [mf, tx.get('PLAN_FOCUS', ''), tx.get('PLAN_QUESTION', '')]:
            if x and x.strip() and x.strip() not in texts:
                texts.append(x.strip())
    parts += ['', '[이날의 글]', '\n'.join(texts) if texts else '(없음)', '',
              '판정 기준: 이 구절들이 플랜 목적과 그날의 묶음 역할에 맞는가 · 목적과 무관한 묶음이 있는가 · '
              '글이 있으면 오탈자·구절과의 연관·읽기 편한가.',
              '답은 JSON 한 줄만: {"verdict":"적합|의심|부적합","reason":"한두 문장","off":["무관한 묶음의 약명"],'
              '"typos":["틀린 글→고친 글"],"readability":"좋음|보통|나쁨|글없음","fix":"고칠 제안(없으면 빈칸)"}']
    return '\n'.join(parts)


def _parse(text):
    m = re.search(r'\{.*\}', text or '', re.S)
    if not m:
        return None
    try:
        d = json.loads(m.group(0))
    except Exception:                                     # noqa: BLE001
        return None
    if d.get('verdict') not in ('적합', '의심', '부적합'):
        return None
    return d


def run_ai(conn, pid, limit=None, call=None, redo=False):
    """그 플랜을 하루씩 판정한다(이미 판정한 날은 건너뛴다) → (판정 수, 실패 수)."""
    import ai_client as AC
    call = call or (lambda p: AC.call(p, conn=conn, max_out=700))
    ensure(conn)
    days = sorted({r[1] for r in _rows(conn, pid)})
    done = {r[0] for r in conn.execute('SELECT day FROM %s WHERE plan_id=?' % AUDIT_TBL, (pid,))}
    n = fail = 0
    for day in days:
        if limit and n + fail >= limit:
            break
        if day in done and not redo:
            continue
        res = call(day_prompt(conn, pid, day))
        d = _parse(res.get('text') if res.get('ok') else '')
        if not d:
            fail += 1
            print('  %d일: 실패 %s' % (day, (res.get('why') or '답을 못 읽음')[:80]))
            continue
        conn.execute('INSERT OR REPLACE INTO %s VALUES (?,?,?,?,?,?,?,?,?,DATETIME(\'now\',\'localtime\'))'
                     % AUDIT_TBL,
                     (pid, day, d['verdict'], d.get('reason', ''), json.dumps(d.get('off') or [], ensure_ascii=False),
                      json.dumps(d.get('typos') or [], ensure_ascii=False), d.get('readability', ''),
                      d.get('fix', ''), res.get('text', '')))
        conn.commit()
        n += 1
        print('  %d일: %s' % (day, d['verdict']))
    return n, fail


def desc_draft(conn, pid, call=None):
    """그 플랜의 목적 설명 초안(2~4문장) — 사람이 보고 정한다(저장 안 함)."""
    import ai_client as AC
    call = call or (lambda p: AC.call(p, conn=conn, max_out=500))
    title, desc, _typ = plan_head(conn, pid)
    rows = _rows(conn, pid)
    sample = []
    for day in sorted({r[1] for r in rows})[:12]:
        sample.append('%d일: ' % day + ' · '.join('%s%s' % ((STAGE_KO.get(r[5], r[5]) + ' ') if r[5] else '',
                                                           _ref(conn, r[3], r[4] or r[3])) for r in rows if r[1] == day))
    p = ('아래 묵상플랜의 목적을 평신도가 읽기 편한 한국어 합니다체 2~4문장으로 설명하라. 대시(—)를 쓰지 않는다. '
         '설명만 쓴다.\n[플랜] %s\n[지금 설명] %s\n[앞쪽 일정]\n%s' % (title, desc or '(없음)', '\n'.join(sample)))
    r = call(p)
    return (r.get('text') or '').strip() if r.get('ok') else ''


def report(conn, pid, path=None):
    ensure(conn)
    title, desc, _typ = plan_head(conn, pid)
    rows = conn.execute('SELECT day, verdict, reason, off_refs, typos, readability, fix FROM %s WHERE plan_id=?'
                        ' ORDER BY day' % AUDIT_TBL, (pid,)).fetchall()
    cnt = {}
    for r in rows:
        cnt[r[1]] = cnt.get(r[1], 0) + 1
    out = ['플랜 %d 「%s」 AI 판정 — %d일 · %s' % (pid, title, len(rows),
                                              ' · '.join('%s %d' % kv for kv in sorted(cnt.items()))), '']
    for day, v, why, off, ty, rd, fix in rows:
        if v == '적합' and (not ty or ty == '[]'):
            continue
        out.append('%d일 [%s] %s' % (day, v, why))
        if off and off != '[]':
            out.append('     무관: %s' % ', '.join(json.loads(off)))
        if ty and ty != '[]':
            out.append('     오탈자: %s' % ', '.join(json.loads(ty)))
        if fix:
            out.append('     제안: %s' % fix)
    txt = '\n'.join(out)
    if path:
        with open(path, 'w', encoding='utf-8') as f:
            f.write(txt)
    return txt


# ══════════════════════════════════════════════════════════════════
def selftest():
    fails = []

    def ck(c, m):
        print(('  OK  ' if c else '  FAIL ') + m)
        if not c:
            fails.append(m)

    conn = appdb.connect()
    found = machine(conn, 16)
    ck(isinstance(found, list), '기계 점검이 돈다(플랜 16)')
    p = day_prompt(conn, 16, 1)
    ck('[1일째]' in p and '율법' in p and 'JSON' in p, '하루 프롬프트에 날·묶음 역할·답 꼴')
    ck(_parse('앞말 {"verdict":"의심","reason":"x","off":[],"typos":[],"readability":"좋음","fix":""} 뒷말')['verdict'] == '의심',
       '답 JSON 을 읽는다')
    ck(_parse('{"verdict":"좋음"}') is None, '판정값이 틀리면 버린다')
    # 가짜 AI 로 담기 — 시험 전용 표(진짜 판정 표는 안 건드린다)
    global AUDIT_TBL
    calls = []
    fake = lambda pr: (calls.append(pr), {'ok': True, 'text': '{"verdict":"의심","reason":"맞다","off":["x"],'
                                                           '"typos":[],"readability":"글없음","fix":""}'})[1]
    keep = AUDIT_TBL
    AUDIT_TBL = 'temp_plan_audit_selftest'
    try:
        conn.execute('DROP TABLE IF EXISTS %s' % AUDIT_TBL)
        n, f = run_ai(conn, 16, limit=2, call=fake, redo=True)
        ck(n == 2 and f == 0 and len(calls) == 2, '가짜 AI 로 이틀 판정·담기')
        ck('[의심]' in report(conn, 16), '보고서가 의심을 낸다')
    finally:
        conn.execute('DROP TABLE IF EXISTS %s' % AUDIT_TBL)
        conn.commit()
        AUDIT_TBL = keep
    # 기계 점검 — 통독 플랜은 빠진 절 잣대가 돈다
    f4 = machine(conn, 4)
    ck(all(x[0] == 4 for x in f4), '통독 플랜 점검이 그 플랜만 낸다')
    print('db_plan_audit selftest: %s' % ('FAIL %d' % len(fails) if fails else 'PASS'))
    return not fails


def main(argv):
    conn = appdb.connect()
    if '--selftest' in argv:
        return 0 if selftest() else 1
    if '--machine' in argv:
        found = write_machine(conn)
        print('흠 %d · 참고 %d → _plan_audit_machine.txt' % (sum(1 for f in found if f[2] == '흠'),
                                                          sum(1 for f in found if f[2] == '참고')))
        return 0
    if '--ai' in argv:
        pid = int(argv[argv.index('--ai') + 1])
        lim = int(argv[argv.index('--limit') + 1]) if '--limit' in argv else None
        t0 = time.time()
        n, f = run_ai(conn, pid, lim)
        d = desc_draft(conn, pid)
        txt = report(conn, pid)
        with open('_plan_audit_ai_%d.txt' % pid, 'w', encoding='utf-8') as fp:
            fp.write(txt + '\n\n[설명문 초안 — 저장 안 함]\n' + d + '\n')
        print('판정 %d · 실패 %d · %.0f초 → _plan_audit_ai_%d.txt' % (n, f, time.time() - t0, pid))
        return 0
    if '--report' in argv:
        print(report(conn, int(argv[argv.index('--report') + 1])))
        return 0
    print(__doc__)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
