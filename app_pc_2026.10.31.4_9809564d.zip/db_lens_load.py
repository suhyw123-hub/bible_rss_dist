# -*- coding: utf-8 -*-
"""db_lens_load.py — 렌즈묵상 한 편(JSON) 적재 (영구 도구, 2026-08-16).

★ **왜 도구인가.** 렌즈 목표 규격(§4-5: 컨테이너당 7~12 노드 · 노드당 2~6 구절)을
  채우면 렌즈 한 편에 **글 30~60편 + 링크 30~80개**다. 관리자 화면으로는
  저장 단추를 60번쯤 눌러야 하고 언어마다 다시다. `db_peri_load`(페리코프)·
  `db_chap_load`(장)가 이미 이 방식이다 — 대량 입력·재적재는 **도구**,
  순서 손질·번역 상태 확인·한 편 고치기는 **관리자 화면**.

흐름 (§0-1 샘플 검수 원칙):
    ① 초안 JSON 작성          _lens_prep/<이름>.json   (gitignore)
    ② --check <초안>          틀린 곳을 먼저 잡는다 (적재 안 함)
    ③ 관리자 검수
    ④ --apply <초안>          멱등 적재 — 다시 돌려도 안 겹친다
    ⑤ 관리자 화면에서 확인·손질

초안 형식 (한 파일 = 렌즈 한 편):
    {
      "lens":  "성령의 은사",          ← 이름이 곧 열쇠다 (아래 ★)
      "cat":   102,                    ← sys_plan_category (scope='LENS')
      "desc":  {"KO": "...", "EN": "..."},
      "nodes": [
        {"name": "은사의 근원",
         "desc":     {"KO": "..."},
         "question": {"KO": "..."},
         "prayer":   {"KO": "..."},    ← 노드 묵상기도 (2026-08-17 신설, 선택)
         "verses": [
           {"ref": "고전 12:4-6", "desc": {"KO": "..."}},
           {"ref": "롬 12:6"}
         ]}
      ]
    }

★★ **연결설명문 비대칭 규칙 (2026-08-17 사용자 채택 — 게이트가 지킨다)**
  · **구간**(`고전 12:4-6`) = `desc` **필수** — 구간 전체를 대변하는 노드 관점의 글.
  · **단일** = `desc` **원칙 금지**(구절설명문이 담당) — 있으면 경고(예외 허용).
  근거: 한 규칙으로 묶으면 한쪽이 형식화된다(창 4:4 ↔ 히 10:19-22 실증).
★ **모든 글에 엔터 금지** — 렌즈 텍스트는 전부 한 줄이다(2026-08-17 사용자 정책).
  개행이 들어가면 화면에 줄이 하나씩 더 생긴다. 게이트가 잡는다.

★ **멱등의 열쇠 = 이름이다.** 렌즈는 `(cat_id, unit_name_sid)`, 노드는 그 렌즈 안의
  `unit_name_sid`, 구절은 그 노드 안의 `verse_id`. 번호를 초안에 적게 하면
  DB 마다 번호가 달라 초안을 옮겨 쓸 수 없다.
⚠ **구절 참조는 `scripture_ref_kr.resolve`** 로 푼다. 실패해도 `None` 이 아니라
  `(None, None)` 을 준다 — `rng[0] is None` 으로 봐야 한다(§21-4 에서 실제로 당했다).
★ **구간(`고전 12:4-6`)은 한 링크다** — `target_id`=시작 · `end_id`=끝 (2026-08-16
  사용자 지시). 사용자 화면에 **카드 하나**로 뜬다. 단절은 `end_id` NULL.
  연결 설명(`desc`)도 그 한 링크에 건다.
⚠ **삭제는 하지 않는다.** 초안에서 빠진 노드·구절을 지우려면 관리자 화면의
  cascade HIDE(§22-6)를 쓴다 — 도구가 조용히 지우면 복구 경로가 없다.

    python db_lens_load.py --selftest        (의무)
    python db_lens_load.py --check  _lens_prep/foo.json
    python db_lens_load.py --apply  _lens_prep/foo.json
    python db_lens_load.py --list            지금 렌즈·노드·글 개수
"""
import json
import os
import sys

import appdb

DB = 'bible_master.db'


def ensure_schema(conn):
    """`sys_link_asset.end_id`(NULL 허용) — **구간을 한 링크로** 담는 칸 (2026-08-16
    사용자 지시 「각 노드에 구절이 구간으로 입력될 수 있게」).

    ⚠ 예전에는 `창 22:1-14` 를 절 14개로 풀어 링크 14개를 만들었다 — 사용자 화면에
      **카드가 14장** 떠서 한 사건이 조각났다. §21-2a(`sys_ref_asset_link.end_id`)와
      같은 방식: 컬럼 하나, NULL 이면 예전 그대로 절 하나다. 기존 2,753행 무손상.
    """
    for tbl in ('sys_link_asset', 'user_link_asset'):
        try:
            cols = [r[1] for r in conn.execute('PRAGMA table_info(%s)' % tbl)]
            if 'end_id' not in cols:
                conn.execute('ALTER TABLE %s ADD COLUMN end_id INTEGER' % tbl)
                print('  %s.end_id 추가' % tbl)
        except Exception as e:
            print('  %s: %s' % (tbl, e))
    conn.commit()

# 렌즈가 쓰는 글 종류 — 초안 칸 이름 → text_type
TEXT_OF = {'desc': None}                     # 자리마다 다르다 (아래 참조)
LENS_TT = 'CONT_DESC'
NODE_TT = {'desc': 'NODE_DESC', 'question': 'NODE_QUESTION',
           'prayer': 'NODE_PRAYER'}
VERS_TT = 'NODE_VERS_DESC'

MAX_NAME = 40


# ── 초안 검사 ─────────────────────────────────────────────────────────────

def validate(conn, draft, verbose=True):
    """초안의 틀린 곳 목록. 비면 통과. **적재는 하지 않는다.**

    막는 것(bad) 외에 **경고(warn)** 도 낸다 — 단일 구절의 연결설명문
    (원칙 금지·예외 허용)은 경고로만 알린다.
    """
    bad = []
    warn = []
    import scripture_ref_kr

    def no_enter(d, where):
        # ★ 렌즈 텍스트는 전부 한 줄 — 엔터 금지 (2026-08-17 사용자 정책)
        # ★ 「—」 기호 금지 (2026-08-17 사용자 — 「간격이 넓어지고 문장의
        #   자연스러움이 사라진다. 그냥 문장처럼 읽을 수 있게 하라」)
        for lang, body in (d or {}).items():
            if body and '\n' in body:
                bad.append('%s / %s 글에 엔터가 있다(한 줄로)' % (where, lang))
            if body and '—' in body:
                bad.append('%s / %s 글에 — 기호가 있다(문장으로 풀 것)' % (where, lang))

    name = (draft.get('lens') or '').strip()
    if not name:
        bad.append('lens(렌즈 이름)가 없다')
    elif len(name) > MAX_NAME:
        bad.append('렌즈 이름이 %d자(한도 %d자)' % (len(name), MAX_NAME))
    if '—' in name or '_' in name:
        bad.append('렌즈 이름에 — 나 _ 가 있다(이름 규칙 ② — 플랜 제목이 된다)')

    cat = draft.get('cat')
    if not isinstance(cat, int):
        bad.append('cat(카테고리 번호)이 없다')
    else:
        row = conn.execute(
            "SELECT scope FROM sys_plan_category WHERE cat_id=? "
            "AND COALESCE(record_status,'LIVE')='LIVE'", (cat,)).fetchone()
        if row is None:
            bad.append('cat %d — 없는 카테고리' % cat)
        elif row[0] != 'LENS':
            # ⚠ 묵상플랜 카테고리(cat 2 등)에 렌즈를 넣으면 트리 어디에도 안 보인다
            bad.append('cat %d 는 scope=%s — LENS 카테고리가 아니다' % (cat, row[0]))

    if not isinstance(draft.get('desc'), dict) or not draft['desc'].get('KO'):
        bad.append('desc.KO(렌즈 설명)가 없다')
    no_enter(draft.get('desc'), '렌즈 desc')

    nodes = draft.get('nodes') or []
    if not nodes:
        bad.append('nodes 가 비었다')
    seen_nodes = set()
    for i, nd in enumerate(nodes, 1):
        tag = '노드 %d' % i
        nm = (nd.get('name') or '').strip()
        if not nm:
            bad.append('%s — name 이 없다' % tag); continue
        tag = '노드 %d(%s)' % (i, nm)
        if nm in seen_nodes:
            bad.append('%s — 이름이 겹친다(멱등의 열쇠라 겹치면 안 된다)' % tag)
        seen_nodes.add(nm)
        if not (nd.get('desc') or {}).get('KO'):
            bad.append('%s — desc.KO 가 없다' % tag)
        no_enter(nd.get('desc'), tag + ' desc')
        no_enter(nd.get('question'), tag + ' question')
        no_enter(nd.get('prayer'), tag + ' prayer')

        verses = nd.get('verses') or []
        if not verses:
            bad.append('%s — verses 가 비었다' % tag)
        seen_vids = set()
        for v in verses:
            ref = (v.get('ref') or '').strip()
            if not ref:
                bad.append('%s — ref 없는 구절' % tag); continue
            rng = scripture_ref_kr.resolve(conn, ref)
            # ⚠ 실패는 None 이 아니라 (None, None) 이다 (§21-4)
            if rng[0] is None:
                bad.append('%s — 구절을 못 풀었다: %r' % (tag, ref)); continue
            a, b = rng
            if b - a > 20:
                bad.append('%s — %r 이 %d절짜리 범위다(오타이기 쉽다)' % (tag, ref, b - a + 1))
            for vid in range(a, b + 1):
                if vid in seen_vids:
                    bad.append('%s — %r 안에서 절이 겹친다' % (tag, ref))
                seen_vids.add(vid)
            # ★ 비대칭 규칙 — 구간은 연결설명 필수, 단일은 원칙 금지(경고)
            has_desc = bool((v.get('desc') or {}).get('KO'))
            if b > a and not has_desc:
                bad.append('%s — 구간 %r 에 desc.KO(구간 대변 설명)가 없다' % (tag, ref))
            if b == a and has_desc:
                warn.append('%s — 단일 %r 에 연결설명이 있다(원칙 금지 — '
                            '노드 관점이 정말 필요한 예외인지 확인)' % (tag, ref))
            no_enter(v.get('desc'), '%s %s desc' % (tag, ref))

    if verbose:
        for w in warn:
            print('  ⚠', w)
        if bad:
            print('검사 실패 %d건:' % len(bad))
            for b in bad:
                print('  ✗', b)
        else:
            n_v = sum(len(nd.get('verses') or []) for nd in nodes)
            print('검사 통과 — 렌즈 「%s」 · 노드 %d · 구절 참조 %d · 경고 %d'
                  % (name, len(nodes), n_v, len(warn)))
    return bad


# ── 적재 ──────────────────────────────────────────────────────────────────

def _next_sort(conn, table, where, args):
    r = conn.execute('SELECT MAX(sort_order) FROM %s WHERE %s' % (table, where),
                     args).fetchone()
    return ((r[0] or 0) // 10 + 1) * 10


def _upsert_text(conn, tt, cid, lang, body):
    # ⚠ HIDE 행까지 찾는다 — (text_type, clicked_id, lang_code) UNIQUE 라
    #   LIVE 만 보고 INSERT 하면 숨긴 옛 행(재활용 노드의 junk 글)과 충돌한다
    #   (2026-08-18 실측 — 시험 노드 재활용에서 IntegrityError).
    #   숨긴 행은 내용을 갈아 끼우고 LIVE 로 되살린다.
    row = conn.execute(
        "SELECT sys_text_id, contents, COALESCE(record_status,'LIVE') "
        "FROM sys_text_asset WHERE text_type=? "
        "AND clicked_id=? AND UPPER(lang_code)=UPPER(?) "
        "ORDER BY CASE COALESCE(record_status,'LIVE') WHEN 'LIVE' THEN 0 "
        "ELSE 1 END LIMIT 1", (tt, cid, lang)).fetchone()
    if row is None:
        conn.execute("INSERT INTO sys_text_asset (text_type, clicked_id, lang_code, "
                     "contents, record_status) VALUES (?,?,?,?,'LIVE')",
                     (tt, cid, lang, body))
        return 'new'
    if row[1] != body or row[2] != 'LIVE':
        conn.execute("UPDATE sys_text_asset SET contents=?, record_status='LIVE' "
                     "WHERE sys_text_id=?", (body, row[0]))
        return 'upd'
    return 'same'


def apply(conn, draft):
    """멱등 적재. 결과 요약 dict 를 돌려준다."""
    import scripture_ref_kr
    ensure_schema(conn)
    st = {'lens_new': 0, 'node_new': 0, 'link_new': 0,
          'txt_new': 0, 'txt_upd': 0, 'txt_same': 0}

    def texts(tt, cid, d):
        for lang, body in (d or {}).items():
            body = (body or '').strip()
            if not body:
                continue
            st['txt_' + {'new': 'new', 'upd': 'upd', 'same': 'same'}[
                _upsert_text(conn, tt, cid, lang, body)]] += 1

    name, cat = draft['lens'].strip(), draft['cat']

    # ① 렌즈 — (cat, 이름) 으로 찾는다. HIDE 였으면 되살린다.
    row = conn.execute(
        "SELECT sys_unit_id, record_status FROM sys_unit_asset "
        "WHERE unit_type='CONTAINER' AND cat_id=? AND unit_name_sid=? "
        "ORDER BY sys_unit_id LIMIT 1", (cat, name)).fetchone()
    if row is None:
        so = _next_sort(conn, 'sys_unit_asset',
                        "unit_type='CONTAINER' AND cat_id=?", (cat,))
        cur = conn.execute(
            "INSERT INTO sys_unit_asset (unit_type, unit_name_sid, sort_order, "
            "cat_id, record_status) VALUES ('CONTAINER',?,?,?,'LIVE')",
            (name, so, cat))
        lens_id = cur.lastrowid
        st['lens_new'] += 1
    else:
        lens_id = row[0]
        if row[1] != 'LIVE':
            conn.execute("UPDATE sys_unit_asset SET record_status='LIVE' "
                         "WHERE sys_unit_id=?", (lens_id,))
    texts(LENS_TT, lens_id, draft.get('desc'))

    # ② 노드 — 이 렌즈에 걸린 노드를 이름으로 찾는다
    have = {}
    for lid, nid, nm in conn.execute(
            "SELECT l.sys_link_id, u.sys_unit_id, u.unit_name_sid "
            "FROM sys_link_asset l JOIN sys_unit_asset u ON u.sys_unit_id=l.target_id "
            "WHERE l.link_type='CONT_NODE' AND l.clicked_id=? "
            "AND COALESCE(l.record_status,'LIVE')='LIVE'", (lens_id,)):
        have[nm] = nid

    for order, nd in enumerate(draft['nodes'], 1):
        nm = nd['name'].strip()
        nid = have.get(nm)
        if nid is None:
            cur = conn.execute(
                "INSERT INTO sys_unit_asset (unit_type, unit_name_sid, sort_order, "
                "record_status) VALUES ('NODE',?,?,'LIVE')", (nm, order * 10))
            nid = cur.lastrowid
            conn.execute(
                "INSERT INTO sys_link_asset (clicked_id, target_id, link_type, "
                "sort_order, record_status) VALUES (?,?,'CONT_NODE',?,'LIVE')",
                (lens_id, nid, order * 10))
            st['node_new'] += 1
        else:
            # 순서는 초안이 정한다 — 손으로 옮긴 것을 덮지 않으려면 초안 순서를 맞춘다
            conn.execute(
                "UPDATE sys_link_asset SET sort_order=? WHERE link_type='CONT_NODE' "
                "AND clicked_id=? AND target_id=?", (order * 10, lens_id, nid))
        texts(NODE_TT['desc'], nid, nd.get('desc'))
        texts(NODE_TT['question'], nid, nd.get('question'))
        texts(NODE_TT['prayer'], nid, nd.get('prayer'))

        # ③ 구절 — **구간이 한 링크다** (2026-08-16 사용자 지시).
        #   `target_id`=시작 절, `end_id`=끝 절(단절이면 NULL). 사용자 화면에
        #   카드 하나로 뜬다 — 예전처럼 절마다 링크를 만들면 창 22:1-14 가
        #   카드 14장으로 조각난다. 멱등 열쇠 = (시작, 끝) 짝.
        vhave = {(vid, e): lid for lid, vid, e in conn.execute(
            "SELECT sys_link_id, target_id, end_id FROM sys_link_asset "
            "WHERE link_type='NODE_VERS' AND clicked_id=? "
            "AND COALESCE(record_status,'LIVE')='LIVE'", (nid,))}
        for vorder, v in enumerate(nd.get('verses') or [], 1):
            a, b = scripture_ref_kr.resolve(conn, v['ref'].strip())
            end = b if b != a else None
            lid = vhave.get((a, end))
            if lid is None:
                cur = conn.execute(
                    "INSERT INTO sys_link_asset (clicked_id, target_id, end_id, "
                    "link_type, sort_order, record_status) "
                    "VALUES (?,?,?,'NODE_VERS',?,'LIVE')",
                    (nid, a, end, vorder * 10))
                lid = cur.lastrowid
                st['link_new'] += 1
            else:
                conn.execute("UPDATE sys_link_asset SET sort_order=? "
                             "WHERE sys_link_id=?", (vorder * 10, lid))
            texts(VERS_TT, lid, v.get('desc'))

    conn.commit()
    return st


# ── 조회 ──────────────────────────────────────────────────────────────────

def list_all(conn):
    print('%-5s %-4s %-22s %5s %5s %6s' % ('lens', 'cat', '이름', '노드', '구절', '글'))
    for uid, cat, nm in conn.execute(
            "SELECT sys_unit_id, cat_id, unit_name_sid FROM sys_unit_asset "
            "WHERE unit_type='CONTAINER' AND COALESCE(record_status,'LIVE')='LIVE' "
            "ORDER BY cat_id, sort_order"):
        nodes = [r[0] for r in conn.execute(
            "SELECT target_id FROM sys_link_asset WHERE link_type='CONT_NODE' "
            "AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'", (uid,))]
        nv = 0
        if nodes:
            nv = conn.execute(
                "SELECT COUNT(*) FROM sys_link_asset WHERE link_type='NODE_VERS' "
                "AND clicked_id IN (%s) AND COALESCE(record_status,'LIVE')='LIVE'"
                % ','.join('?' * len(nodes)), nodes).fetchone()[0]
        ids = [uid] + nodes
        nt = conn.execute(
            "SELECT COUNT(*) FROM sys_text_asset WHERE text_type IN "
            "('CONT_DESC','NODE_DESC','NODE_QUESTION','NODE_PRAYER') "
            "AND clicked_id IN (%s) "
            "AND COALESCE(record_status,'LIVE')='LIVE'" % ','.join('?' * len(ids)),
            ids).fetchone()[0]
        print('%-5d %-4s %-22s %5d %5d %6d' % (uid, cat, nm[:22], len(nodes), nv, nt))


# ── 자가검증 ──────────────────────────────────────────────────────────────

def selftest():
    """트랜잭션 안에서 넣었다 되돌린다 — DB 에 흔적을 남기지 않는다."""
    ok = True
    conn = appdb.connect(DB)
    try:
        cat = conn.execute("SELECT cat_id FROM sys_plan_category WHERE scope='LENS' "
                           "AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1").fetchone()
        if not cat:
            print('FAIL LENS 카테고리가 없다'); return False
        cat = cat[0]

        good = {'lens': '검사용 렌즈', 'cat': cat,
                'desc': {'KO': '검사 설명'},
                'nodes': [{'name': '검사 노드', 'desc': {'KO': '노드 설명'},
                           'question': {'KO': '질문'},
                           'prayer': {'KO': '기도'},
                           'verses': [{'ref': '창 1:3', 'desc': {'KO': '연결 설명'}},
                                      {'ref': '요 1:1-5',
                                       'desc': {'KO': '구간 대변 설명'}}]}]}

        # ① 검사기 — 좋은 초안은 통과, 나쁜 초안은 잡는다
        #   (단일 창1:3 의 desc 는 **경고**일 뿐 막지 않는다 — 예외 허용)
        if validate(conn, good, verbose=False):
            print('FAIL 좋은 초안이 검사에 걸린다'); ok = False
        for mut, why in (
                ({**good, 'lens': ''}, '이름 없음'),
                ({**good, 'cat': 999999}, '없는 카테고리'),
                ({**good, 'cat': 2}, 'LENS 아닌 카테고리'),
                ({**good, 'desc': {}}, '렌즈 설명 없음'),
                ({**good, 'desc': {'KO': '첫 줄\n둘째 줄'}}, '설명에 엔터'),
                ({**good, 'nodes': []}, '노드 없음'),
                ({**good, 'nodes': [{**good['nodes'][0],
                                     'verses': [{'ref': '없는책 1:1'}]}]}, '못 푸는 구절'),
                ({**good, 'nodes': [{**good['nodes'][0],
                                     'verses': [{'ref': '요 1:1-5'}]}]},
                 '구간에 desc 없음 — 비대칭 규칙'),
                ({**good, 'nodes': [good['nodes'][0], good['nodes'][0]]}, '노드 이름 겹침')):
            if not validate(conn, mut, verbose=False):
                print('FAIL 나쁜 초안을 놓친다: %s' % why); ok = False

        # ② 적재 — 트랜잭션, 끝나면 롤백
        conn.execute('BEGIN')
        st1 = apply(conn, good)          # ⚠ apply 가 commit 하므로 아래에서 손으로 지운다
        if st1['lens_new'] != 1 or st1['node_new'] != 1:
            print('FAIL 첫 적재 수가 다르다: %s' % st1); ok = False
        if st1['link_new'] != 2:         # 창1:3 + 요1:1-5 — **구간은 한 링크다**
            print('FAIL 링크 수가 다르다(2 여야): %s' % st1); ok = False
        # 구간 링크에 end_id 가 실렸나
        rng = conn.execute(
            "SELECT target_id, end_id FROM sys_link_asset l "
            "JOIN sys_unit_asset u ON u.sys_unit_id=l.clicked_id "
            "WHERE l.link_type='NODE_VERS' AND u.unit_name_sid='검사 노드' "
            "AND l.end_id IS NOT NULL").fetchone()
        if not rng or rng[1] - rng[0] != 4:
            print('FAIL 구간 end_id 가 틀리다: %s' % (rng,)); ok = False

        # ③ **멱등** — 같은 초안을 또 넣으면 아무것도 새로 안 생긴다
        st2 = apply(conn, good)
        if st2['lens_new'] or st2['node_new'] or st2['link_new'] or st2['txt_new']:
            print('FAIL 두 번째 적재가 새로 만든다: %s' % st2); ok = False

        # ④ 고친 초안 — 글만 바뀐다
        good2 = json.loads(json.dumps(good))
        good2['desc']['KO'] = '고친 설명'
        st3 = apply(conn, good2)
        if st3['txt_upd'] != 1 or st3['lens_new'] or st3['link_new']:
            print('FAIL 고침이 upd 1 이 아니다: %s' % st3); ok = False

        # ⑤ 연결 설명이 **첫 절에만** 걸렸나
        lens_id = conn.execute(
            "SELECT sys_unit_id FROM sys_unit_asset WHERE unit_type='CONTAINER' "
            "AND cat_id=? AND unit_name_sid='검사용 렌즈'", (cat,)).fetchone()[0]
        nid = conn.execute(
            "SELECT target_id FROM sys_link_asset WHERE link_type='CONT_NODE' "
            "AND clicked_id=?", (lens_id,)).fetchone()[0]
        n_nv_desc = conn.execute(
            "SELECT COUNT(*) FROM sys_text_asset t JOIN sys_link_asset l "
            "ON l.sys_link_id=t.clicked_id AND l.link_type='NODE_VERS' "
            "WHERE t.text_type='NODE_VERS_DESC' AND l.clicked_id=?", (nid,)).fetchone()[0]
        if n_nv_desc != 2:
            print('FAIL 연결 설명이 %d개 — 링크마다 하나(총 2)여야 한다' % n_nv_desc)
            ok = False
        # ⑥ 노드 기도(NODE_PRAYER)가 실렸나 (2026-08-17 신설)
        n_pr = conn.execute(
            "SELECT COUNT(*) FROM sys_text_asset WHERE text_type='NODE_PRAYER' "
            "AND clicked_id=?", (nid,)).fetchone()[0]
        if n_pr != 1:
            print('FAIL NODE_PRAYER 가 %d개' % n_pr); ok = False
    finally:
        # 되돌리기 — apply 가 commit 하므로 손으로 지운다
        try:
            lens = conn.execute(
                "SELECT sys_unit_id FROM sys_unit_asset WHERE unit_type='CONTAINER' "
                "AND unit_name_sid='검사용 렌즈'").fetchone()
            if lens:
                lid = lens[0]
                nodes = [r[0] for r in conn.execute(
                    "SELECT target_id FROM sys_link_asset WHERE link_type='CONT_NODE' "
                    "AND clicked_id=?", (lid,))]
                if nodes:
                    q = ','.join('?' * len(nodes))
                    links = [r[0] for r in conn.execute(
                        "SELECT sys_link_id FROM sys_link_asset "
                        "WHERE link_type='NODE_VERS' AND clicked_id IN (%s)" % q, nodes)]
                    if links:
                        conn.execute("DELETE FROM sys_text_asset WHERE "
                                     "text_type='NODE_VERS_DESC' AND clicked_id IN (%s)"
                                     % ','.join('?' * len(links)), links)
                    conn.execute("DELETE FROM sys_link_asset WHERE link_type='NODE_VERS' "
                                 "AND clicked_id IN (%s)" % q, nodes)
                    conn.execute("DELETE FROM sys_text_asset WHERE text_type IN "
                                 "('NODE_DESC','NODE_QUESTION','NODE_PRAYER') "
                                 "AND clicked_id IN (%s)" % q, nodes)
                    conn.execute("DELETE FROM sys_unit_asset WHERE sys_unit_id IN (%s)" % q,
                                 nodes)
                conn.execute("DELETE FROM sys_link_asset WHERE link_type='CONT_NODE' "
                             "AND clicked_id=?", (lid,))
                conn.execute("DELETE FROM sys_text_asset WHERE text_type='CONT_DESC' "
                             "AND clicked_id=?", (lid,))
                conn.execute("DELETE FROM sys_unit_asset WHERE sys_unit_id=?", (lid,))
                conn.commit()
            left = conn.execute(
                "SELECT COUNT(*) FROM sys_unit_asset WHERE unit_name_sid LIKE '검사%'"
            ).fetchone()[0]
            if left:
                print('FAIL 검사 자료가 남았다: %d' % left); ok = False
        finally:
            conn.close()
    print('db_lens_load selftest', 'OK' if ok else 'FAIL')
    return ok


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--check', metavar='DRAFT')
    ap.add_argument('--apply', metavar='DRAFT')
    ap.add_argument('--list', action='store_true')
    a = ap.parse_args()

    if a.selftest:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(DB)
    try:
        if a.check or a.apply:
            path = a.check or a.apply
            draft = json.load(open(path, encoding='utf-8'))
            bad = validate(conn, draft)
            if bad:
                sys.exit(1)
            if a.apply:
                st = apply(conn, draft)
                print('적재 — 렌즈 새로 %(lens_new)d · 노드 새로 %(node_new)d · '
                      '링크 새로 %(link_new)d · 글 새로 %(txt_new)d 고침 %(txt_upd)d '
                      '그대로 %(txt_same)d' % st)
        elif a.list:
            list_all(conn)
        else:
            print(__doc__.split('\n')[0])
    finally:
        conn.close()


if __name__ == '__main__':
    main()
