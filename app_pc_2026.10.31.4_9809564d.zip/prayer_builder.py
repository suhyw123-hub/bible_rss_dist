# -*- coding: utf-8 -*-
"""prayer_builder.py — 골라담기 「성경의 기도」 빌더 (2026-08-18 신설).

사용자 검수 표(2026-08-18 「좋다. 그대로 진행하라」) 그대로 — 48편:
구약 27 + 신약 21(바울과 실라 옥중 찬송·계시록 3편·새벽 미명 보강).

  부품  = 아래 _POOL (기도 이름 · 본문 · 결 · 상황(복수) · 시편 보충 · 포커스)
  축    = 기도의 결 6 · 상황 7(복수 태그 — 하나라도 맞으면 담김) · 구약/신약
  하루  = 기도 본문(CORE) + **시편 보충구절(PSA)** — 「시편 자체가 기도문」
          (사용자)이라 전 유닛에 결이 닿는 시편을 짝지었다. 유닛 자체가
          시편인 6편은 보충 생략.

  · 저장 = user_bible_plan(origin=PRAYER_BUILDER 앵커, plan_type PRAYER)
    + user_plan_schedule. sys 에는 쓰지 않는다(§0-6 C-2).
  · 순서 = 정경·시대순 고정(짝 기도 — 한나 서원→노래, 갈멜산→로뎀나무,
    국난→병상 — 이 순서로 유지된다).
"""
import json
import tkinter as tk
from tkinter import ttk, messagebox

import i18n
import appdb
import scripture_ref_kr
from plan_builder import FilterRow, check_plan_name, unique_sibling_name, _readable

ANCHOR_CODE = 'PRAYER_BUILDER'

_TONES = [('SUPPLICATION', '간구'), ('INTERCESSION', '중보'),
          ('REPENTANCE', '회개'), ('THANKS', '감사'),
          ('PRAISE', '찬양'), ('LAMENT', '탄식')]
_SITS = [('CRISIS', '위기와 두려움'), ('SIN', '죄와 용서'),
         ('ILLNESS', '병과 죽음 앞'), ('CALLING', '소명과 갈림길'),
         ('LONGING', '메마름과 갈망'), ('PERSECUTION', '고난과 핍박'),
         ('COMMUNITY', '공동체와 나라')]
_TESTS = [('OT', '구약'), ('NT', '신약')]

# (이름, OT/NT, 본문, 시편보충|None, 결, 상황들, 포커스)
_POOL = [
 ('아브라함, 소돔을 위한 흥정', 'OT', '창 18:23-33', '시 103:8-10',
  'INTERCESSION', ('COMMUNITY', 'CRISIS'),
  '심판 소식 앞에서 열 명까지 값을 낮춰 간 중보입니다.'),
 ('아브라함의 종, 우물가에서', 'OT', '창 24:12-14', '시 25:4-5',
  'SUPPLICATION', ('CALLING',),
  '표적을 정해 놓고 구한 종의 기도에 하나님이 응답하십니다.'),
 ('야곱, 얍복 나루의 밤', 'OT', '창 32:9-12', '시 56:3-4',
  'SUPPLICATION', ('CRISIS',),
  '형 에서를 만나기 전날 밤, 약속을 붙들고 매달립니다.'),
 ('모세, 금송아지 앞의 중보', 'OT', '출 32:11-14', '시 106:23',
  'INTERCESSION', ('COMMUNITY', 'SIN'),
  '주의 이름과 약속을 근거로 백성을 살려낸 중보입니다.'),
 ('모세, 주의 영광을 보이소서', 'OT', '출 33:12-18', '시 27:8',
  'SUPPLICATION', ('CALLING', 'LONGING'),
  '사명보다 먼저 임재를 구합니다. 주의 영광을 보이소서.'),
 ('모세의 시, 우리 날 계수하게', 'OT', '시 90:1-12', None,
  'LAMENT', ('LONGING',),
  '영원하신 하나님 앞에서 우리 날 계수하는 지혜를 구합니다.'),
 ('한나, 눈물의 서원', 'OT', '삼상 1:10-16', '시 113:9',
  'SUPPLICATION', ('CRISIS', 'LONGING'),
  '술 취한 줄로 오해받은 눈물의 기도가 사무엘을 낳았습니다.'),
 ('한나의 노래', 'OT', '삼상 2:1-10', '시 113:7-8',
  'PRAISE', ('LONGING',),
  '응답받은 사람의 노래는 나에게서 하나님께로 옮겨 갑니다.'),
 ('다윗, 밧세바 이후', 'OT', '시 51:1-17', None,
  'REPENTANCE', ('SIN',),
  '상한 심령의 제사, 회개 기도의 영원한 본입니다.'),
 ('다윗, 언약 앞에 앉아서', 'OT', '삼하 7:18-29', '시 138:2',
  'THANKS', ('CALLING',),
  '내가 무엇이기에. 은혜 앞에 앉아서 드리는 감사입니다.'),
 ('다윗, 대적이 많을 때', 'OT', '시 3:1-8', None,
  'LAMENT', ('CRISIS',),
  '대적이 많아도 눕고 자고 깨는 믿음입니다.'),
 ('여호와는 나의 목자', 'OT', '시 23:1-6', None,
  'PRAISE', ('LONGING', 'ILLNESS'),
  '목자의 시는 푸른 풀밭과 사망의 음침한 골짜기를 함께 지납니다.'),
 ('솔로몬, 듣는 마음을 구함', 'OT', '왕상 3:5-14', '시 119:34',
  'SUPPLICATION', ('CALLING',),
  '부와 장수가 아니라 듣는 마음을 구했습니다.'),
 ('솔로몬, 성전 봉헌 기도', 'OT', '왕상 8:22-30', '시 84:1-2',
  'INTERCESSION', ('COMMUNITY',),
  '하늘이 감당하지 못하실 하나님께서 이 집에서 들으시기를 구합니다.'),
 ('엘리야, 갈멜산의 불', 'OT', '왕상 18:36-39', '시 115:1',
  'SUPPLICATION', ('COMMUNITY', 'CRISIS'),
  '불이 내리기 전에 기도가 먼저였습니다.'),
 ('엘리야, 로뎀나무 아래서', 'OT', '왕상 19:4-8', '시 34:18',
  'LAMENT', ('CRISIS', 'LONGING'),
  '지쳐 죽기를 구하는 종을 하나님은 먼저 먹이고 재우십니다.'),
 ('히스기야, 편지를 펴 놓고', 'OT', '왕하 19:14-19', '시 46:1-3',
  'SUPPLICATION', ('COMMUNITY', 'CRISIS'),
  '위협의 편지를 여호와 앞에 펴 놓는 것이 기도입니다.'),
 ('히스기야, 병상에서', 'OT', '왕하 20:1-6', '시 6:2-4',
  'SUPPLICATION', ('ILLNESS',),
  '벽을 향하여 흘린 눈물에 십오 년이 더해집니다.'),
 ('여호사밧, 주만 바라봅니다', 'OT', '대하 20:5-12', '시 25:15',
  'SUPPLICATION', ('COMMUNITY', 'CRISIS'),
  '어떻게 할 줄 모르는 날의 기도, 오직 주만 바라봅니다.'),
 ('에스라의 부끄러운 회개', 'OT', '스 9:5-9', '시 130:3-4',
  'REPENTANCE', ('COMMUNITY', 'SIN'),
  '얼굴을 들지 못하는 부끄러움도 기도가 됩니다.'),
 ('느헤미야, 무너진 성을 듣고', 'OT', '느 1:4-11', '시 137:5-6',
  'INTERCESSION', ('COMMUNITY', 'CALLING'),
  '무너진 소식을 듣고 울며 금식한 자리에서 소명이 옵니다.'),
 ('욥, 티끌과 재 가운데서', 'OT', '욥 42:1-6', '시 131:1-2',
  'REPENTANCE', ('PERSECUTION', 'SIN'),
  '귀로 듣기만 하다가 눈으로 뵈니 말이 줄어드는 회개입니다.'),
 ('어느 때까지니이까', 'OT', '시 13:1-6', None,
  'LAMENT', ('CRISIS', 'LONGING'),
  '어느 때까지가 네 번 반복되고도 찬송으로 끝납니다.'),
 ('사슴이 시냇물을 찾듯', 'OT', '시 42:1-5', None,
  'LAMENT', ('LONGING',),
  '갈급함 자체가 기도입니다. 내 영혼이 하나님을 찾기에.'),
 ('다니엘, 포로의 땅에서', 'OT', '단 9:17-19', '시 79:8-9',
  'INTERCESSION', ('COMMUNITY', 'SIN'),
  '자기 의가 아니라 주의 큰 긍휼을 의지한 중보입니다.'),
 ('요나, 물고기 뱃속에서', 'OT', '욘 2:1-9', '시 18:6',
  'THANKS', ('ILLNESS', 'CRISIS'),
  '스올의 뱃속에서도 감사의 목소리로 서원을 갚겠다 합니다.'),
 ('하박국, 없을지라도', 'OT', '합 3:17-19', '시 73:25-26',
  'PRAISE', ('PERSECUTION', 'LONGING'),
  '무화과나무가 무성치 못해도, 없음 속에서 부르는 찬양입니다.'),
 ('마리아의 찬가', 'NT', '눅 1:46-55', '시 34:2-3',
  'PRAISE', ('CALLING',),
  '비천한 여종을 돌아보신 하나님을 높이는 노래입니다.'),
 ('사가랴의 찬가', 'NT', '눅 1:68-79', '시 111:9',
  'PRAISE', ('COMMUNITY',),
  '침묵 끝에 열린 입이 구속의 하나님을 찬송합니다.'),
 ('시므온, 이제 놓아 주소서', 'NT', '눅 2:29-32', '시 98:2-3',
  'THANKS', ('ILLNESS',),
  '평생 기다린 것을 품에 안은 사람의 마지막 기도입니다.'),
 ('주님이 가르치신 기도', 'NT', '마 6:9-13', '시 103:13',
  'SUPPLICATION', ('LONGING',),
  '주님이 직접 가르치신 기도의 순서와 무게를 배웁니다.'),
 ('예수님, 어린아이들에게 감사', 'NT', '마 11:25-27', '시 8:2',
  'THANKS', ('LONGING',),
  '지혜자가 아니라 어린아이에게 나타내신 것을 감사하십니다.'),
 ('새벽 미명의 기도', 'NT', '막 1:35-39', '시 5:3',
  'SUPPLICATION', ('CALLING', 'LONGING'),
  '새벽 아직 어두울 때, 예수님의 하루는 기도로 시작됩니다.'),
 ('나사로 무덤 앞의 감사', 'NT', '요 11:41-42', '시 118:21',
  'THANKS', ('ILLNESS',),
  '돌을 옮기기 전에 이미 들으신 것을 감사하십니다.'),
 ('겟세마네, 이 잔을', 'NT', '마 26:36-44', '시 42:11',
  'LAMENT', ('PERSECUTION',),
  '내 원대로 마옵시고. 가장 어두운 밤의 가장 깊은 기도입니다.'),
 ('대제사장의 기도', 'NT', '요 17:1-26', '시 133:1',
  'INTERCESSION', ('COMMUNITY',),
  '떠나기 전날 밤, 제자들과 우리를 위해 드린 중보입니다.'),
 ('십자가에서, 저들을 사하여', 'NT', '눅 23:34', '시 86:5',
  'INTERCESSION', ('PERSECUTION', 'SIN'),
  '못 박은 자들을 위한 기도가 십자가에서 먼저 나옵니다.'),
 ('초대교회, 담대히 말하게 하소서', 'NT', '행 4:24-31', '시 2:1-4',
  'SUPPLICATION', ('PERSECUTION', 'COMMUNITY'),
  '위협 앞에서 피할 길이 아니라 담대함을 구했습니다.'),
 ('스데반의 마지막 기도', 'NT', '행 7:59-60', '시 31:5',
  'INTERCESSION', ('PERSECUTION', 'ILLNESS'),
  '돌에 맞으며 드린 기도가 주님의 기도를 닮았습니다.'),
 ('바울과 실라, 감옥의 찬송', 'NT', '행 16:25-34', '시 42:8',
  'PRAISE', ('PERSECUTION',),
  '한밤중 감옥에서 찬송이 울리자 옥터가 흔들립니다.'),
 ('바울, 마음의 눈을 밝히사', 'NT', '엡 1:15-19', '시 119:18',
  'INTERCESSION', ('COMMUNITY', 'LONGING'),
  '지식보다 먼저 마음의 눈이 밝아지기를 구합니다.'),
 ('바울, 속사람을 강건하게', 'NT', '엡 3:14-21', '시 138:3',
  'INTERCESSION', ('COMMUNITY', 'LONGING'),
  '넓이와 길이와 높이와 깊이, 측량 못할 사랑을 알기를 구합니다.'),
 ('바울, 사랑이 지식에 넘치도록', 'NT', '빌 1:9-11', '시 119:66',
  'INTERCESSION', ('COMMUNITY',),
  '사랑이 지식과 총명으로 점점 더 풍성하기를 구합니다.'),
 ('바울의 가시, 족한 은혜', 'NT', '고후 12:7-10', '시 94:18-19',
  'SUPPLICATION', ('ILLNESS', 'PERSECUTION'),
  '세 번 구했으나 가시는 남고 은혜가 족하다 하십니다.'),
 ('순교자들의 탄원, 어느 때까지', 'NT', '계 6:9-11', '시 94:3',
  'LAMENT', ('PERSECUTION', 'COMMUNITY'),
  '제단 아래 영혼들의 어느 때까지가 하늘에서도 울립니다.'),
 ('금향로의 향, 성도의 기도', 'NT', '계 8:3-4', '시 141:2',
  'SUPPLICATION', ('LONGING',),
  '성도의 기도는 사라지지 않고 금향로의 향으로 올라갑니다.'),
 ('어린 양의 새 노래', 'NT', '계 5:8-14', '시 98:1',
  'PRAISE', ('COMMUNITY',),
  '금 대접에 담긴 향이 곧 성도들의 기도입니다.'),
 ('아멘 주 예수여 오시옵소서', 'NT', '계 22:20-21', '시 130:5-6',
  'SUPPLICATION', ('LONGING',),
  '성경의 마지막 기도는 아멘 주 예수여 오시옵소서입니다.'),
 # ★ 2026-10-20 docs/1.txt 5-2(3) — 기도와 함께 부른 노래도 담는다(노래 갈래는 따로 만들지 않는다 · 결 = 찬양·감사).
 #   ⚠ 맨 끝에 덧붙인다 — 번호가 곧 만든 플랜의 unit_key(PRAY_n)라 앞에 끼우면 옛 플랜이 엉뚱한 기도를 가리킨다.
 #     보이는 차례는 `_RANK` 가 정경 차례로 맞춘다.
 ('모세와 미리암, 바다를 건넌 노래', 'OT', '출 15:1-18', '시 106:9-12',
  'PRAISE', ('CRISIS', 'COMMUNITY'),
  '홍해를 건넌 백성의 첫 노래, 구원을 본 사람이 부르는 찬양입니다.'),
 ('드보라의 노래', 'OT', '삿 5:1-12', '시 68:7-9',
  'PRAISE', ('COMMUNITY', 'CRISIS'),
  '백성이 즐거이 헌신한 날, 이긴 일을 여호와께 돌리는 노래입니다.'),
 ('다윗, 마지막 감사', 'OT', '대상 29:10-13', '시 145:1-3',
  'THANKS', ('CALLING', 'COMMUNITY'),
  '성전 예물을 다 모은 뒤, 모든 것이 주께로 말미암았다고 고백합니다.'),
]

# ★ 2026-10-20 — 기도한 사람(주인공)으로 가른다(사용자 「인물묵상의 직분처럼 기도/노래의 주인공을 기준으로」).
#   인물묵상의 직분과 기준이 다르다 — 왕·선지자만으로는 한나·시므온·하늘의 성도들이 갈 자리가 없다.
_WHOS = [('PATRIARCH', '족장'), ('KING', '왕'), ('LEADER', '지도자·제사장'),
         ('PROPHET', '선지자'), ('PEOPLE', '평범한 신앙인'), ('JESUS', '예수님'),
         ('CHURCH', '사도와 교회'), ('HEAVEN', '하늘의 성도')]
_WHO = ['PATRIARCH', 'PEOPLE', 'PATRIARCH', 'LEADER', 'LEADER', 'LEADER',
        'PEOPLE', 'PEOPLE', 'KING', 'KING', 'KING', 'KING', 'KING', 'KING',
        'PROPHET', 'PROPHET', 'KING', 'KING', 'KING', 'LEADER', 'LEADER',
        'PEOPLE', 'KING', 'PEOPLE', 'PROPHET', 'PROPHET', 'PROPHET',
        'PEOPLE', 'LEADER', 'PEOPLE',
        'JESUS', 'JESUS', 'JESUS', 'JESUS', 'JESUS', 'JESUS', 'JESUS',
        'CHURCH', 'CHURCH', 'CHURCH', 'CHURCH', 'CHURCH', 'CHURCH', 'CHURCH',
        'HEAVEN', 'HEAVEN', 'HEAVEN', 'CHURCH',
        'LEADER', 'LEADER', 'KING']
assert len(_WHO) == len(_POOL)
# 보이는 차례(정경·시대순) — 덧붙인 셋을 제자리에 끼운다
_RANK = [0, 1, 2, 48, 3, 4, 5, 49, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 50] + list(range(18, 48))
assert sorted(_RANK) == list(range(len(_POOL)))


def anchor_plan_id(conn):
    row = conn.execute("SELECT plan_id FROM sys_bible_plan WHERE plan_code=?",
                       (ANCHOR_CODE,)).fetchone()
    return row[0] if row else None


class PrayerBuilderDialog(tk.Toplevel):
    """골라담기 성경의 기도 빌더 — journey_builder 와 같은 흐름."""

    def __init__(self, parent, db_path='bible_master.db'):
        super().__init__(parent)
        self.db_path = db_path
        self.created_user_plan_id = None
        self.enroll_now = None
        self.title(i18n.t('PRB_TITLE', '성경의 기도 만들기'))
        self.geometry('1020x640')
        try:
            import ui_theme
            ui_theme.adopt(self)
        except Exception:
            pass
        self._checked = [tk.BooleanVar(value=True) for _ in _POOL]
        self._build()
        self._refresh()

    def _build(self):
        """★ 2026-10-20 docs/1.txt 5-2 — 세 창 공통 틀(`builder_shell`) · 좌우 두 칸을 하나로
        (사용자 「이미 체크상자로 선택한 것들이다. 좌우 대비하지 말고 하나로 통합하자」)."""
        import builder_shell
        self._shell = builder_shell.Shell(self, self._create_plan)
        self._name_var = self._shell.name_var
        ff = self._shell.filters
        self._fr_who = FilterRow(
            ff, 0, i18n.t('PRB_WHO', '기도한 사람'), [k for k, _l in _WHOS],
            display=dict(_WHOS), on_change=self._refresh)
        self._fr_tone = FilterRow(
            ff, 1, i18n.t('PRB_TONE', '기도의 결'), [k for k, _l in _TONES],
            display=dict(_TONES), on_change=self._refresh)
        self._fr_sit = FilterRow(
            ff, 2, i18n.t('PRB_SIT', '상황'), [k for k, _l in _SITS],
            display=dict(_SITS), on_change=self._refresh)
        self._fr_test = FilterRow(
            ff, 3, i18n.t('PRB_TEST', '성경'), [k for k, _l in _TESTS],
            display=dict(_TESTS), on_change=self._refresh)

        lf = ttk.LabelFrame(self._shell.body,
                            text=i18n.t('PRB_LIST', ' 기도 — 눌러서 담기/빼기 · 숫자 = 묵상 일차 '))
        lf.pack(fill='both', expand=True)
        self._ltv = ttk.Treeview(lf, columns=('day', 'who', 'ref', 'tone'),
                                 show='tree headings', selectmode='browse')
        self._ltv.heading('#0', text=i18n.t('COMMON_NAME', '이름'))
        self._ltv.column('#0', width=300)
        self._ltv.heading('day', text=i18n.t('PRB_DAY', '일차'))
        self._ltv.column('day', width=50, anchor='center')
        self._ltv.heading('who', text=i18n.t('PRB_WHO', '기도한 사람'))
        self._ltv.column('who', width=110, anchor='center')
        self._ltv.heading('ref', text=i18n.t('COMMON_VERSE', '본문'))
        self._ltv.column('ref', width=110, anchor='center')
        self._ltv.heading('tone', text=i18n.t('PRB_TONE', '기도의 결'))
        self._ltv.column('tone', width=70, anchor='center')
        vsb = ttk.Scrollbar(lf, orient='vertical', command=self._ltv.yview)
        self._ltv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        self._ltv.pack(fill='both', expand=True, padx=(4, 0), pady=4)
        self._ltv.bind('<Button-1>', self._on_click)

    def _visible(self):
        tones = set(self._fr_tone.get_selected())
        sits = set(self._fr_sit.get_selected())
        sit_all = self._fr_sit.is_all()
        tests = set(self._fr_test.get_selected())
        whos = set(self._fr_who.get_selected())
        out = []
        for i in _RANK:
            nm, test, ref, psa, tone, usits, focus = _POOL[i]
            if tone not in tones or test not in tests or _WHO[i] not in whos:
                continue
            if not sit_all and not (set(usits) & sits):   # 복수 태그 — 교집합
                continue
            out.append(i)
        return out

    def _picked(self):
        return [i for i in self._visible() if self._checked[i].get()]

    def _refresh(self):
        tv = self._ltv
        tv.delete(*tv.get_children())
        tone_ko = dict(_TONES)
        who_ko = dict(_WHOS)
        day = 0
        for i in self._visible():
            nm, test, ref, psa, tone, sits, focus = _POOL[i]
            on = self._checked[i].get()
            if on:
                day += 1
            tv.insert('', 'end', iid=str(i), text='%s %s' % ('☑' if on else '☐', nm),
                      values=(day if on else '', who_ko[_WHO[i]], ref, tone_ko[tone]))
        self._shell.set_count(day, day)

    def _on_click(self, ev):
        iid = self._ltv.identify_row(ev.y)
        try:
            i = int(iid)
        except (TypeError, ValueError):
            return
        self._checked[i].set(not self._checked[i].get())
        self._refresh()
        return 'break'

    def _create_plan(self):
        picked = self._picked()
        if not picked:
            messagebox.showwarning(
                i18n.t('COMMON_WARNING', '경고'),
                i18n.t('PRB_EMPTY', '담긴 기도가 없습니다.'), parent=self)
            return
        plan_code = _readable(self._name_var.get().strip(), '내 기도 묵상')
        plan_code = check_plan_name(plan_code, self)
        if plan_code is None:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                anchor = anchor_plan_id(conn)
                if not anchor:
                    messagebox.showerror(
                        i18n.t('COMMON_ERROR', '오류'),
                        '앵커 플랜(PRAYER_BUILDER)이 없습니다.', parent=self)
                    return
                plan_code = unique_sibling_name(conn, plan_code, anchor)
                self._name_var.set(plan_code)
                bm = scripture_ref_kr.book_map_ko(conn)
                days = len(picked)
                config = {
                    'filter': {'who': self._fr_who.get_selected(),
                               'tone': self._fr_tone.get_selected(),
                               'situation': self._fr_sit.get_selected(),
                               'testament': self._fr_test.get_selected()},
                    'units': picked, 'total_units': days,
                }
                cur = conn.execute(
                    "INSERT INTO user_bible_plan (origin_plan_id, plan_code, "
                    "plan_type, plan_category, duration_days, track_count, "
                    "plan_config) VALUES (?, ?, 'PRAYER', 'THEMATIC', ?, 1, ?)",
                    (anchor, plan_code, days,
                     json.dumps(config, ensure_ascii=False)))
                uid = cur.lastrowid
                for day, i in enumerate(picked, 1):
                    nm, _test, ref, psa, _tone, _sits, focus = _POOL[i]
                    a, b = scripture_ref_kr.resolve(conn, ref, bm)
                    if a is None:
                        raise SystemExit('구절 해석 실패: %s' % ref)
                    conn.execute(
                        "INSERT INTO user_plan_schedule (user_plan_id, week, "
                        "day, track, start_vid, end_vid, stage_type, "
                        "connection_level, sort_order, meditation_focus, "
                        "unit_key) VALUES (?,?,?,1,?,?,'CORE','CORE',1,?,?)",
                        (uid, (day - 1) // 7 + 1, day, a, b,
                         '%s: %s' % (nm, focus), 'PRAY_%d' % i))
                    if psa:
                        pa, pb = scripture_ref_kr.resolve(conn, psa, bm)
                        if pa is None:
                            raise SystemExit('구절 해석 실패: %s' % psa)
                        conn.execute(
                            "INSERT INTO user_plan_schedule (user_plan_id, "
                            "week, day, track, start_vid, end_vid, "
                            "stage_type, connection_level, sort_order) "
                            "VALUES (?,?,?,1,?,?,'PSA','EXPANSION',2)",
                            (uid, (day - 1) // 7 + 1, day, pa, pb))
            self.created_user_plan_id = uid
            self.enroll_now = messagebox.askyesno(
                i18n.t('COMMON_DONE', '완료'),
                i18n.t('MSG_PLAN_CREATED_ASK2',
                       '플랜을 만들었습니다 — {code} ({days}일)\n{status}\n\n'
                       '지금 등록할까요?').format(
                    code=plan_code, days=days,
                    status=i18n.t('PRB_MADE', '기도 {n}편').format(n=days)),
                parent=self)
            self.destroy()
        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), str(e),
                                 parent=self)


if __name__ == '__main__':
    root = tk.Tk()
    root.withdraw()
    dlg = PrayerBuilderDialog(root)
    root.wait_window(dlg)
    root.destroy()
