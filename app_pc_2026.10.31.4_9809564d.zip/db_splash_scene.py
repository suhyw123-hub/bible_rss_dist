# -*- coding: utf-8 -*-
"""db_splash_scene.py — **시작화면 장면 유형과 구절 매핑**
(2026-09-05 신설·영구 · `--selftest` 의무).

★★★ 왜 (사용자 확정 설계):
  「각 사진에 구절을 매핑하지 말고 **사진의 유형분류를 더 세밀하게** 한 후
   **유형분류에 구절을 매핑**하면 사용자가 어떤 사진을 첨부하더라도, 어떤
   구절을 선택하더라도 어느 정도의 의미연관성을 가지고 연결될 수 있을 것이다.」
  ⇒ **출발은 구절이다.** 사진 하나하나에 구절을 적으면 ⓐ 사용자가 올린 사진은
    매핑이 없고 ⓑ 사용자가 어떤 구절을 즐겨찾기할지 모른다. **유형에 매핑**하면
    양쪽이 다 커버된다.

⚠⚠ **기존 재료로는 안 됐다**(실측 2026-09-05):
  · 낱말 경계 — 「산」이 든 절 1,285개인데 대부분 「**동산**」이다
  · 주제 용어(TERM) — 상위가 여호와 5,786 · 하나님 2,300 · 사람 1,851 로
    **장면과 안 이어진다**
  ⇒ 사용자 판단대로 **재료를 새로 만든다**.

★★ **층을 둘로 가른다** — 하나로 하면 팩이 30개가 되거나 매핑이 거칠어진다.
  · **팩 유형**(`SCENE_PACKS` 7) — 배포 단위. 사용자가 「무엇을 받을까」
  · **장면 유형**(`SCENES` 38) — 의미 단위. 「어떤 구절에 어울릴까」

★★★ **매핑은 장(章)이 기본**(실측이 판정을 정했다):
  | | 값 |
  |---|---|
  | 페리코프(BODY) | 3,061개 · 중앙 8절 · 2~3절짜리는 **10%뿐** |
  | 장 | 1,189개 — **2.6배 적은 일로 같은 커버리지** |
  | 장당 페리코프 | 중앙 **2개** · 하나뿐인 장이 **32%** |
  ⚠ **시편은 150장 = 150페리코프**(1:1)라 어느 쪽을 써도 같다.
  ⇒ 조회는 **좁은 것부터**: 절 → 페리코프 → 장 → 기본.
    페리코프는 **한 장 안에서 장면이 갈리는 곳만**(5개 이상인 장 145개=12%).

⚠ **기본팩이 반드시 있어야 한다**(사용자 지적) — 「산 팩 하나만 받았는데 하늘
  구절이 나오면 보일 사진이 없다」. 기본팩은 **모든 장면을 1~2장씩** 담는다.

    python db_splash_scene.py --selftest      (의무)
    python db_splash_scene.py --init          표 만들기(멱등)
    python db_splash_scene.py --scenes        장면 목록
    python db_splash_scene.py --stat          매핑 현황
    python db_splash_scene.py --seed          배포 강조구절 30개 매핑 예시
"""
import io
import os
import random
import sys

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

import appdb                                                    # noqa: E402

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')

#: 배포 팩 — **기본이 맨 앞**. `BASIC` 은 모든 장면을 조금씩 담는다.
#: ⚠ 늘리려면 여기 한 줄(팩이 늘면 사용자 고르기 화면이 저절로 는다).
SCENE_PACKS = (
    ('BASIC',   '기본',        '모든 장면을 조금씩 — 어떤 구절이든 하나는 뜬다'),
    ('LAND',    '산·들',       '능선·광야·초원·골짜기·바위'),
    ('WATER',   '물',          '호수·바다·시내·강·폭포·샘'),
    ('SKY',     '하늘·계절',    '새벽·노을·밤하늘·구름·안개·비·눈·무지개'),
    ('FARM',    '농사·목축',    '씨뿌리기·농경지·추수·열매·포도밭·양떼'),
    ('PLACE',   '성지·유적',    '성벽·유적·광야 길·순례길'),
    ('WORSHIP', '예배·불빛',    '예배 자리·모닥불·등불'),
)

#: ★★★ **장면 유형 — 「무엇을 찍었나 → 어떤 구절에 어울리나」**
#: `(코드, 팩, 이름, 어울리는 결)`. 결은 **사용자가 고를 때 보이는 한마디**다.
#: ⚠ 38개가 상한이다 — 사진을 올릴 때 목록에서 골라야 하는데 더 늘면 못 고른다.
SCENES = (
    # ── 산·들 ────────────────────────────────────────────────────────
    ('RIDGE',        'LAND', '능선·아침 산',   '도움·앙망'),
    ('WILDERNESS',   'LAND', '광야',          '시험·인도'),
    ('MEADOW',       'LAND', '들판·초원',      '쉼·양육'),
    ('VALLEY',       'LAND', '골짜기',         '낮은 자리·통과'),
    ('ROCK',         'LAND', '바위·반석',      '견고함·피난처'),
    ('TREE_SHADE',   'LAND', '큰 나무 그늘',    '보호·그늘'),
    # ── 물 ──────────────────────────────────────────────────────────
    ('LAKE_CALM',    'WATER', '고요한 호수',    '평강'),
    ('SEA_ROUGH',    'WATER', '거친 바다·파도',  '환난·잠잠케 하심'),
    ('BROOK',        'WATER', '시냇물',        '생명·묵상'),
    ('RIVER',        'WATER', '강·여울',       '통과·건넘'),
    ('WATERFALL',    'WATER', '폭포·장대비',    '성령·부어짐'),
    ('SPRING',       'WATER', '샘·우물',       '갈증·생수'),
    # ── 하늘·계절 ────────────────────────────────────────────────────
    ('DAWN',         'SKY', '새벽빛·일출',      '소망·새 아침'),
    ('SUNSET',       'SKY', '노을',           '마침·감사'),
    ('NIGHT_SKY',    'SKY', '밤하늘·별',       '창조·경외'),
    ('CLOUDS',       'SKY', '구름·운해',       '증인·영광'),
    ('MIST',         'SKY', '안개·이슬비',     '은혜·조용한 임재'),
    ('RAIN',         'SKY', '비',             '씻음·풍성'),
    ('SNOW',         'SKY', '눈',             '정결'),
    ('RAINBOW',      'SKY', '무지개',          '언약'),
    # ── 농사·목축 ────────────────────────────────────────────────────
    ('SOWING',       'FARM', '씨뿌리기',       '말씀·수고'),
    ('FIELD_WIDE',   'FARM', '광활한 농경지',   '기업·풍성'),
    ('GRAIN_GROW',   'FARM', '자라는 곡식',     '자람·인내'),
    ('HARVEST',      'FARM', '추수',           '때·거둠'),
    ('FRUIT',        'FARM', '풍성한 열매',     '열매 맺음'),
    ('VINEYARD',     'FARM', '포도밭·가지',     '연합·거함'),
    ('TREE_ONE',     'FARM', '나무 한 그루',    '시냇가에 심은 나무'),
    ('FLOWER',       'FARM', '꽃',             '덧없음·아름다움'),
    ('FLOCK',        'FARM', '목축·양떼',      '인도·돌봄'),
    ('SHEARING',     'FARM', '양털깎이',       '잠잠함·드림'),
    ('SHEPHERD',     'FARM', '목자',           '목자 되심'),
    # ── 성지·유적 ────────────────────────────────────────────────────
    ('WALL',         'PLACE', '성벽·성문',      '견고함·도성'),
    ('RUINS',        'PLACE', '유적',          '덧없음·역사'),
    ('DESERT_ROAD',  'PLACE', '광야 길',       '옛적 길'),
    ('PILGRIM_PATH', 'PLACE', '순례길',        '올라감·여정'),
    # ── 예배·불빛 ────────────────────────────────────────────────────
    ('WORSHIP_PLACE', 'WORSHIP', '예배 자리',   '모임·찬양'),
    ('CAMPFIRE',      'WORSHIP', '모닥불',      '성령의 불'),
    ('LAMP',          'WORSHIP', '등불·촛불',   '말씀·인도'),
)

SCENE_CODES = tuple(s[0] for s in SCENES)
SCENE_BY = {s[0]: s for s in SCENES}

# ★★ **대륙 일곱** (2026-09-05 사용자 지시 — 「아시아의 자연과 유럽의 자연은
#   성격이 다르다」). 사진을 고를 때 **거르는 축**이다.
#   ⚠ **중동을 아시아에서 갈랐다** — 성경 앱에서 성지의 풍경은 「아시아」로
#     뭉뚱그리면 무엇을 고르는지 알 수 없다. 지리 교과서가 아니라 **사용자가
#     사진을 고르는 데 쓰는 이름**이다.
#   ⚠ 장면 팩 `PLACE`(성지·유적)와 **축이 다르다** — 저것은 「무슨 장면인가」,
#     이것은 「어디서 찍었나」. 스위스 산도 MOUNTAIN 이고 시내산도 MOUNTAIN 이다.
CONTINENTS = (
    ('ASIA',     '아시아'),
    ('MIDEAST',  '중동·성지'),
    ('EUROPE',   '유럽'),
    ('AFRICA',   '아프리카'),
    ('NAMERICA', '북아메리카'),
    ('SAMERICA', '남아메리카'),
    ('OCEANIA',  '오세아니아'),
)
CONTINENT_BY = dict(CONTINENTS)


def continent_name(code, lang=None):
    """대륙 이름 — 화면 언어로. i18n 이 없으면 위 표의 한국어로 물러선다.

    ⚠ 열쇠는 `SPL_CONT_<코드>` 다. **여기서 언어별 표를 또 만들지 않는다** —
      그러면 ui_strings 와 두 벌이 되어 한쪽만 고쳐진다.
    """
    if not code:
        return ''
    try:
        import i18n
        v = i18n.t('SPL_CONT_' + code, '')
        if v:
            return v
    except Exception:
        pass
    return CONTINENT_BY.get(code, code)

# ★ 다국어 제목·설명이 사는 곳 — `sys_text_asset(clicked_id = img_id)`
#   ⚠ 사진은 **관리자가 만들고 팩이 행째 나르므로** img_id 가 안정적이다
#     (재적재로 번호가 갈리는 자산이 아니다).
TXT_TITLE = 'SPLASH_TITLE'
TXT_DESC = 'SPLASH_DESC'
# ★ 2026-10-20 (docs/1.txt 9-2) AI용 사진 설명 — 화면에 보이는 제목·설명(찍은 곳)과 따로 ·
#   AI 가 이 글을 읽고 말씀카드에 어울리는 사진을 고른다(사진을 못 보므로 글이 사진을 대신한다).
TXT_AI = 'PHOTO_AI'
#: 사진 설명 쓰는 법 — PC 관리자 화면과 폰 「내 사진」이 같은 안내를 쓴다(폰은 화면 글자 M_PH_GUIDE)
AI_GUIDE = ('AI 는 사진을 볼 수 없고 이 글만 읽고 말씀카드에 어울리는 사진을 고릅니다. 사진을 못 보는 사람에게 말해 주듯 적어 주세요.\n'
            '① 무엇이 보이나 — 장소, 사물, 계절, 시간(사람이 있으면 「아이 둘」처럼 쓰고 이름은 쓰지 않는다)\n'
            '② 색과 분위기 — 밝은, 고요한, 따뜻한, 장엄한 등\n'
            '③ 어울리는 카드 — 축하·위로·격려·감사·기도·절기 가운데 어디에, 어떤 때(생일, 병문안, 새 출발 …)\n'
            '예: 이른 아침 안개 낀 호수와 작은 나무 배. 잔잔하고 고요한 푸른빛. 위로나 기도 카드, 지친 사람에게 쉼을 전할 때.')


def photo_ai(conn, img_id, lang='KO'):
    """AI용 사진 설명 — 그 언어 → EN → KO → 아무 언어 · 없으면 빈 글(지어내지 않는다)."""
    for lg in (lang, 'EN', 'KO', None):
        q = ("SELECT contents FROM sys_text_asset WHERE text_type=? AND clicked_id=?"
             " AND COALESCE(record_status,'LIVE')<>'HIDE'" + (" AND lang_code=?" if lg else "") + " LIMIT 1")
        try:
            r = conn.execute(q, [TXT_AI, int(img_id)] + ([lg] if lg else [])).fetchone()
        except Exception:
            r = None
        if r and (r[0] or '').strip():
            return r[0].strip()
    return ''


def save_photo_ai(conn, img_id, lang, text):
    """AI용 사진 설명을 그 언어로 저장 — 빈 값이면 지운다."""
    v = (text or '').strip()
    conn.execute("DELETE FROM sys_text_asset WHERE text_type=? AND clicked_id=? AND lang_code=?",
                 (TXT_AI, int(img_id), lang))
    if v:
        conn.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,contents,record_status)"
                     " VALUES(?,?,?,?,'LIVE')", (int(img_id), TXT_AI, lang, v))
    conn.commit()
    return True


def photo_text(conn, img_id, lang='KO', src='SYS'):
    """그 사진의 `(제목, 설명)` — 요청 언어 → EN → 아무 언어 → `name` 폴백.

    ⚠ **없는 것을 지어내지 않는다** — 설명이 없으면 빈 문자열이고, 화면이
      그 줄을 아예 안 만든다.
    """
    # ⚠⚠⚠ **내 사진의 글은 `user_text_asset` 에 있다** (2026-09-05 사용자
    #   신고 「설명문을 입력했는데 표시되지 않는다」). `sys_` 만 읽고 있었다.
    #   ⇒ 사용자 사진이면 **내 글을 먼저** 보고, 없으면 배포 글로 물러선다.
    #   ⚠ 두 표를 섞어 쓰는 이유 — 사용자 글을 `sys_` 에 쓰면 배포 DB 가
    #     오염된다(§0-6 C-2). 저장은 갈라 두고 **읽을 때만** 합친다.
    tables = (['user_text_asset', 'sys_text_asset'] if src == 'USER'
              else ['sys_text_asset'])
    out = {}
    for tt in (TXT_TITLE, TXT_DESC):
        val = ''
        for tbl in tables:
            for lg in (lang, 'EN', None):
                q = ("SELECT contents FROM %s WHERE text_type=?"
                     " AND clicked_id=? AND COALESCE(record_status,'LIVE')"
                     "<>'HIDE'" % tbl
                     + (" AND lang_code=?" if lg else "") + " LIMIT 1")
                a = [tt, int(img_id)] + ([lg] if lg else [])
                try:
                    r = conn.execute(q, a).fetchone()
                except Exception:
                    r = None
                if r and (r[0] or '').strip():
                    val = r[0].strip()
                    break
            if val:
                break
        out[tt] = val
    if not out[TXT_TITLE]:                    # 다국어가 없으면 옛 이름으로
        try:
            tbl = ('sys_splash_image' if src == 'SYS' else 'user_splash_image')
            r = conn.execute("SELECT COALESCE(name,'') FROM %s WHERE img_id=?"
                             % tbl, (int(img_id),)).fetchone()
            out[TXT_TITLE] = (r[0] or '').strip() if r else ''
        except Exception:
            pass
    return out[TXT_TITLE], out[TXT_DESC]


def save_photo_text(conn, img_id, lang, title=None, desc=None):
    """제목·설명을 그 언어로 저장. **빈 값이면 그 행을 지운다**(빈 껍데기 금지)."""
    for tt, val in ((TXT_TITLE, title), (TXT_DESC, desc)):
        if val is None:
            continue
        val = (val or '').strip()
        conn.execute("DELETE FROM sys_text_asset WHERE text_type=?"
                     " AND clicked_id=? AND lang_code=?",
                     (tt, int(img_id), lang))
        if val:
            conn.execute(
                "INSERT INTO sys_text_asset"
                "(clicked_id,text_type,lang_code,contents,record_status)"
                " VALUES(?,?,?,?,'LIVE')", (int(img_id), tt, lang, val))
    conn.commit()
    return True


def photo_langs(conn, img_id):
    """그 사진에 제목이 있는 언어들 — 관리자 화면이 배지로 보인다."""
    try:
        return [r[0] for r in conn.execute(
            "SELECT DISTINCT lang_code FROM sys_text_asset WHERE text_type=?"
            " AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'"
            " ORDER BY lang_code", (TXT_TITLE, int(img_id)))]
    except Exception:
        return []
PACK_BY = {p[0]: p for p in SCENE_PACKS}

#: 매핑 범위 — **좁은 것부터** 본다.
SCOPES = ('VERSE', 'PERI', 'CHAP')


# ── 표 ──────────────────────────────────────────────────────────────
def init(conn):
    """표를 만든다(멱등)."""
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS sys_scene_map (
        map_id     INTEGER PRIMARY KEY AUTOINCREMENT,
        scene_code TEXT NOT NULL,
        scope      TEXT NOT NULL,          -- VERSE | PERI | CHAP
        target_id  INTEGER NOT NULL,       -- 절 vid · 단락 id · bcode*1000+장
        weight     INTEGER NOT NULL DEFAULT 1,
        note       TEXT,
        record_status TEXT NOT NULL DEFAULT 'LIVE'
    );
    CREATE UNIQUE INDEX IF NOT EXISTS idx_scene_map_key
        ON sys_scene_map(scene_code, scope, target_id);
    CREATE INDEX IF NOT EXISTS idx_scene_map_tgt
        ON sys_scene_map(scope, target_id);
    """)
    # ★★ **팩↔장면 표** — SQL 에서 팩으로 사진을 고르려면 상수만으로는 안 된다
    #   (`db_pack_body.PARTS['IMAGE']` 가 이 표를 읽는다).
    #   ⚠ **상수가 정본**이다 — 여기서 손으로 고치지 말고 `SCENES` 를 고친다.
    conn.execute("""
    CREATE TABLE IF NOT EXISTS sys_scene_pack (
        scene_code TEXT PRIMARY KEY,
        pack_code  TEXT NOT NULL,
        sort_order INTEGER NOT NULL DEFAULT 0
    )""")
    for i, (code, pack, _nm, _hint) in enumerate(SCENES):
        conn.execute(
            "INSERT INTO sys_scene_pack(scene_code,pack_code,sort_order)"
            " VALUES(?,?,?) ON CONFLICT(scene_code) DO UPDATE SET"
            "  pack_code=excluded.pack_code, sort_order=excluded.sort_order",
            (code, pack, i))
    # ⚠ 상수에서 빠진 장면은 표에서도 걷는다(늘 상수가 정본)
    conn.execute("DELETE FROM sys_scene_pack WHERE scene_code NOT IN (%s)"
                 % ','.join('?' * len(SCENE_CODES)), list(SCENE_CODES))

    # ★ 사진에 장면·기본팩 여부를 적는 칸 — 없으면 만든다
    for tbl in ('sys_splash_image', 'user_splash_image'):
        try:
            cols = [r[1] for r in conn.execute("PRAGMA table_info(%s)" % tbl)]
            if 'scene' not in cols:
                conn.execute("ALTER TABLE %s ADD COLUMN scene TEXT" % tbl)
            # ⚠⚠ **기본팩은 장면으로 못 가른다** — 「모든 장면을 조금씩」이라
            #   장면 조건이 아니라 **표시**가 필요하다(사용자 지적).
            if tbl == 'sys_splash_image' and 'basic' not in cols:
                conn.execute("ALTER TABLE %s ADD COLUMN basic INTEGER"
                             " NOT NULL DEFAULT 0" % tbl)
            # ★ 썸네일 — 팩을 **받기 전에** 무엇이 들었는지 보이려면 필요하다
            if tbl == 'sys_splash_image' and 'thumb_blob' not in cols:
                conn.execute("ALTER TABLE %s ADD COLUMN thumb_blob BLOB" % tbl)
            # ★★ **어디서 찍었나** (2026-09-05 사용자 지시 — 「사진속의 장소,
            #   건물, 나라 등을 제목에 입력한다. **대륙 정보를 추가**하자.
            #   아시아의 자연과 유럽의 자연은 성격이 다르다」).
            #   ⚠ 장면(무슨 장면인가)과 **다른 축**이다 — 둘을 겸하지 않는다.
            if 'continent' not in cols:
                conn.execute("ALTER TABLE %s ADD COLUMN continent TEXT" % tbl)
            # ⚠ **나라는 코드 목록을 안 만든다** — 200개를 11언어로 관리할 수
            #   없다. 여기엔 영문 표기만 담고, 사용자에게 보이는 말은
            #   **다국어 제목·설명**(`SPLASH_TITLE`/`SPLASH_DESC`)이 맡는다.
            if 'country' not in cols:
                conn.execute("ALTER TABLE %s ADD COLUMN country TEXT" % tbl)
        except Exception:
            pass
    conn.commit()
    return True


def chap_key(bcode, chapter):
    """장 매핑의 열쇠 — `verse_tier.chap_key` 와 **같은 규칙**.

    ⚠ 규칙을 여기서 새로 만들지 않는다(§3-1 — 흩어지면 나중에 못 바꾼다).
    """
    try:
        import verse_tier
        return verse_tier.chap_key(bcode, chapter)
    except Exception:
        return int(bcode) * 1000 + int(chapter)


# ── 매핑 ────────────────────────────────────────────────────────────
def set_map(conn, scene, scope, target_id, weight=1, note=''):
    """장면 하나를 어디에 붙인다(멱등)."""
    if scene not in SCENE_BY:
        raise ValueError('모르는 장면: %s' % scene)
    if scope not in SCOPES:
        raise ValueError('모르는 범위: %s' % scope)
    init(conn)
    conn.execute(
        "INSERT INTO sys_scene_map(scene_code,scope,target_id,weight,note,"
        " record_status) VALUES(?,?,?,?,?,'LIVE')"
        " ON CONFLICT(scene_code,scope,target_id) DO UPDATE SET"
        "  weight=excluded.weight, note=excluded.note, record_status='LIVE'",
        (scene, scope, int(target_id), int(weight), str(note or '')))
    conn.commit()
    return True


def drop_map(conn, scene, scope, target_id):
    """붙인 것을 뗀다 → 뗀 수. ⚠ 지우지 않고 HIDE(되돌릴 수 있게)."""
    cur = conn.execute(
        "UPDATE sys_scene_map SET record_status='HIDE'"
        " WHERE scene_code=? AND scope=? AND target_id=?",
        (scene, scope, int(target_id)))
    conn.commit()
    return cur.rowcount


def maps_of(conn, scope, target_id):
    """그 자리에 붙은 장면 → `[(scene, weight, note)]`."""
    try:
        return [(r[0], int(r[1] or 1), r[2] or '') for r in conn.execute(
            "SELECT scene_code, weight, note FROM sys_scene_map"
            " WHERE scope=? AND target_id=? AND COALESCE(record_status,'LIVE')"
            "='LIVE' ORDER BY scene_code", (scope, int(target_id)))]
    except Exception:
        return []


def scenes_for_verse(conn, verse_id):
    """그 절에 어울리는 장면 → `([(scene, weight)], 어디서 왔나)`.

    ★★★ **좁은 것부터 본다** — 절에 적혀 있으면 그것이 가장 정확하고,
      없으면 그 절이 속한 단락, 그것도 없으면 장.
    ⚠ 하나라도 찾으면 **거기서 멈춘다** — 층을 합치면 넓은 층이 좁은 층을
      묽게 만든다(정밀하게 적은 뜻이 사라진다).
    """
    got = maps_of(conn, 'VERSE', verse_id)
    if got:
        return [(s, w) for s, w, _n in got], 'VERSE'
    try:
        r = conn.execute(
            "SELECT p.pericope_id FROM sys_pericope_asset p"
            " WHERE p.peri_type='BODY' AND COALESCE(p.record_status,'LIVE')"
            "='LIVE' AND ? BETWEEN p.start_vid AND p.end_vid LIMIT 1",
            (verse_id,)).fetchone()
        if r:
            got = maps_of(conn, 'PERI', r[0])
            if got:
                return [(s, w) for s, w, _n in got], 'PERI'
    except Exception:
        pass
    try:
        r = conn.execute("SELECT bcode, chapter FROM bible_index"
                         " WHERE verse_id=?", (verse_id,)).fetchone()
        if r:
            got = maps_of(conn, 'CHAP', chap_key(r[0], r[1]))
            if got:
                return [(s, w) for s, w, _n in got], 'CHAP'
    except Exception:
        pass
    return [], ''


# ── 사진 고르기 ─────────────────────────────────────────────────────
def images_of_scene(conn, scenes, include_user=True):
    """그 장면들의 사진 → `[('SYS'|'USER', img_id)]`.

    ⚠ 사용자 사진도 함께(사용자가 올린 것에 장면을 골라 두었으면).
    ⚠⚠⚠ **사용자가 가린 사진은 절대 안 낸다** (2026-09-05 사용자 신고 —
      「모든 사진을 OFF 하고 제목=길만 ON 했는데 **다른 사진이 표시된다**」).
      `is_active` 만 보고 `user_splash_hidden` 을 안 봐서, 장면으로 고르는
      길이 **가리기를 통째로 우회**했다. 옛 무작위 경로는 그 표를 이미 걸렀다 —
      **새 경로를 만들면 옛 경로의 필터를 반드시 옮겨 온다**(§팩 작업 규칙 ②와
      같은 부류의 사고다).
    """
    out = []
    if not scenes:
        return out
    q = ','.join('?' * len(scenes))
    # ⚠ `user_splash_hidden` 은 userdb 라 그 연결에서만 보인다 — 못 읽으면
    #   거르지 못하므로 **그때는 아무것도 안 낸다**(가린 것을 보이느니 폴백).
    hid = None
    try:
        hid = {r[0] for r in conn.execute(
            "SELECT sys_img_id FROM user_splash_hidden")}
    except Exception:
        hid = None
    try:
        for r in conn.execute(
                "SELECT img_id FROM sys_splash_image"
                " WHERE COALESCE(is_active,1)=1 AND scene IN (%s)" % q,
                list(scenes)):
            if hid is not None and r[0] in hid:
                continue
            out.append(('SYS', r[0]))
    except Exception:
        pass
    if include_user:
        try:
            for r in conn.execute(
                    "SELECT img_id FROM user_splash_image"
                    " WHERE COALESCE(is_active,1)=1 AND scene IN (%s)" % q,
                    list(scenes)):
                out.append(('USER', r[0]))
        except Exception:
            pass
    return out


def pick_for_verse(conn, verse_id, avoid=None, rnd=None):
    """그 구절에 보일 사진 하나 → `{'src','img_id','scene','via'}` 또는 None.

    ★★ **랜덤 두 번**(사용자 지시) — ⓐ 장면이 여럿이면 장면을 고르고
      ⓑ 그 장면의 사진이 여럿이면 사진을 고른다.
    ⚠ `avoid` = 직전에 보인 것 — **같은 사진이 연달아 뜨면 고장으로 보인다.**
    ⚠ 매핑이 없거나 그 장면 사진이 하나도 없으면 **None** — 부르는 쪽이
      「아무 사진」으로 물러선다(그것이 정상 동작이다).
    """
    rnd = rnd or random
    pairs, via = scenes_for_verse(conn, verse_id)
    if not pairs:
        return None
    # ⓐ 장면 — weight 만큼 뽑힐 확률이 는다
    bag = []
    for s, w in pairs:
        bag.extend([s] * max(1, int(w or 1)))
    for _ in range(6):                     # 사진이 없는 장면을 몇 번 피해 본다
        scene = rnd.choice(bag)
        imgs = images_of_scene(conn, [scene])
        if not imgs:
            continue
        cand = [x for x in imgs if x != avoid] or imgs
        src, iid = rnd.choice(cand)
        return {'src': src, 'img_id': iid, 'scene': scene, 'via': via}
    # 어느 장면에도 사진이 없다 — 그 장면들 전부에서 한 번 더
    imgs = images_of_scene(conn, [s for s, _w in pairs])
    if not imgs:
        return None
    cand = [x for x in imgs if x != avoid] or imgs
    src, iid = rnd.choice(cand)
    return {'src': src, 'img_id': iid, 'scene': None, 'via': via}


# ── 썸네일 ──────────────────────────────────────────────────────────
#: 썸네일 파일 이름 — **manifest 를 안 키운다**(사진 팩 갈래를 눌렀을 때만 받는다).
THUMBS_NAME = 'splash_thumbs.json'
#: 팩마다 보일 샘플 수. ⚠ 늘리면 파일이 그만큼 커진다.
THUMB_PER_PACK = 4
#: 축소 비율 — 960×600 → 120×75. 실측 15~30ms · 장당 20~45KB.
THUMB_DIV = 8


def make_thumb(blob):
    """원본 PNG → 작은 PNG bytes. 못 만들면 None.

    ★ **외부 의존성 없이** Tk 의 `PhotoImage.subsample` 로 줄인다
      (§tray_agent — pillow 를 안 쓴다). 실측 960×600 → 120×75 · 8ms.
    ⚠ Tk 창이 필요하므로 **화면이 있는 자리에서만** 부른다(관리자 앱).
      발행 도구에서 부를 때는 숨긴 root 를 만들어 쓰고 바로 닫는다.
    """
    import tempfile
    try:
        import tkinter as tk
    except Exception:
        return None
    root = None
    try:
        try:
            root = tk._default_root or tk.Tk()   # 이미 있으면 그것을 쓴다
            made = root is not tk._default_root
        except Exception:
            root = tk.Tk()
            made = True
        if made:
            root.withdraw()
        img = tk.PhotoImage(data=blob)
        th = img.subsample(THUMB_DIV, THUMB_DIV)
        p = os.path.join(tempfile.gettempdir(), '_splash_thumb.png')
        th.write(p, format='png')
        with open(p, 'rb') as f:
            out = f.read()
        try:
            os.remove(p)
        except Exception:
            pass
        return out
    except Exception:
        return None
    finally:
        # ⚠ **내가 만든 root 만 닫는다** — 앱의 root 를 닫으면 화면이 죽는다
        try:
            if root is not None and made:
                root.destroy()
        except Exception:
            pass


def fill_thumbs(conn, only_missing=True, limit=None):
    """사진마다 썸네일을 만들어 담는다(멱등) → 만든 수.

    ⚠ **없는 것만** 다시 만든다(`only_missing`) — 전수 재생성은 느리다.
    """
    init(conn)
    q = ("SELECT img_id, png_blob FROM sys_splash_image"
         " WHERE COALESCE(is_active,1)=1")
    if only_missing:
        q += " AND (thumb_blob IS NULL OR LENGTH(thumb_blob)=0)"
    if limit:
        q += " LIMIT %d" % int(limit)
    n = 0
    for iid, blob in conn.execute(q).fetchall():
        th = make_thumb(blob)
        if not th:
            continue
        conn.execute("UPDATE sys_splash_image SET thumb_blob=? WHERE img_id=?",
                     (th, iid))
        n += 1
    conn.commit()
    return n


def thumbs_body(conn, per_pack=None):
    """팩마다 샘플 썸네일 → 서버에 올릴 dict.

    ★★★ 왜 (2026-09-05 사용자 지시 「선택한 팩 내부의 **샘플사진의 썸네일**을
      볼 수 있도록」) — 팩을 **받기 전에** 무엇이 들었는지 보여야 고를 수 있다.
    ⚠ **manifest 에 안 싣는다** — 7팩 × 4장이면 수백 KB 라 manifest 가
      무거워진다. 사진 팩 갈래를 **눌렀을 때만** 이 파일을 받는다.
    ⚠ 썸네일이 없는 사진은 건너뛴다(조용히 빈 그림을 내지 않는다).
    """
    import base64
    per = per_pack or THUMB_PER_PACK
    out = {'packs': {}}
    for code, _name, _d in SCENE_PACKS:
        if code == 'BASIC':
            q = ("SELECT img_id, name, scene, thumb_blob FROM sys_splash_image"
                 " WHERE COALESCE(basic,0)=1 AND COALESCE(is_active,1)=1"
                 "   AND thumb_blob IS NOT NULL LIMIT ?")
            args = (per,)
        else:
            q = ("SELECT i.img_id, i.name, i.scene, i.thumb_blob"
                 "  FROM sys_splash_image i"
                 "  JOIN sys_scene_pack p ON p.scene_code=i.scene"
                 " WHERE p.pack_code=? AND COALESCE(i.is_active,1)=1"
                 "   AND i.thumb_blob IS NOT NULL LIMIT ?")
            args = (code, per)
        try:
            rows = conn.execute(q, args).fetchall()
        except Exception:
            rows = []
        if not rows:
            continue                     # ⚠ 빈 팩은 안 낸다
        out['packs'][code] = [
            {'img_id': r[0], 'name': r[1] or '',
             'scene': r[2] or '',
             'png': base64.b64encode(r[3]).decode('ascii')}
            for r in rows]
    return out


# ── 현황 ────────────────────────────────────────────────────────────
def coverage(conn):
    """매핑이 구절을 얼마나 덮나 → dict.

    ★ 화면이 이것을 보인다 — 「장을 몇 개 채웠나」가 진도다.
    """
    out = {'verse': 0, 'peri': 0, 'chap': 0, 'chap_total': 0,
           'covered': 0, 'total': 0, 'scenes_used': 0}
    try:
        for sc, n in conn.execute(
                "SELECT scope, COUNT(DISTINCT target_id) FROM sys_scene_map"
                " WHERE COALESCE(record_status,'LIVE')='LIVE' GROUP BY scope"):
            out[str(sc).lower()] = int(n)
        out['scenes_used'] = int(conn.execute(
            "SELECT COUNT(DISTINCT scene_code) FROM sys_scene_map"
            " WHERE COALESCE(record_status,'LIVE')='LIVE'").fetchone()[0])
        out['total'] = int(conn.execute(
            "SELECT COUNT(*) FROM bible_index").fetchone()[0])
        out['chap_total'] = int(conn.execute(
            "SELECT COUNT(DISTINCT bcode*1000+chapter)"
            " FROM bible_index").fetchone()[0])
        # 장 매핑이 덮는 절 수(가장 넓은 층)
        out['covered'] = int(conn.execute(
            "SELECT COUNT(*) FROM bible_index bi WHERE EXISTS("
            "  SELECT 1 FROM sys_scene_map m WHERE m.scope='CHAP'"
            "   AND COALESCE(m.record_status,'LIVE')='LIVE'"
            "   AND m.target_id = bi.bcode*1000 + bi.chapter)").fetchone()[0])
    except Exception:
        pass
    return out


def scene_photo_counts(conn):
    """장면마다 사진이 몇 장인가 → `{scene: (sys, user)}`.

    ⚠ **기본팩이 모든 장면을 덮는가**를 이것으로 잰다(사용자 지적).
    """
    out = {s: [0, 0] for s in SCENE_CODES}
    for i, (tbl, _k) in enumerate((('sys_splash_image', 0),
                                   ('user_splash_image', 1))):
        try:
            for sc, n in conn.execute(
                    "SELECT scene, COUNT(*) FROM %s"
                    " WHERE COALESCE(is_active,1)=1 AND scene IS NOT NULL"
                    " GROUP BY scene" % tbl):
                if sc in out:
                    out[sc][i] = int(n)
        except Exception:
            pass
    return {k: tuple(v) for k, v in out.items()}


# ── selftest ────────────────────────────────────────────────────────
def selftest():
    import sqlite3
    ok = fail = 0

    def t(n, c, e=''):
        nonlocal ok, fail
        if c:
            ok += 1
            print('  OK   %-52s %s' % (n, e))
        else:
            fail += 1
            print('  FAIL %-52s %s' % (n, e))

    print('=== db_splash_scene selftest')
    # ── 표 정합 ─────────────────────────────────────────────────────
    t('★★ 장면이 38개', len(SCENES) == 38, '%d개' % len(SCENES))
    t('  장면 코드가 겹치지 않는다', len(set(SCENE_CODES)) == len(SCENES))
    packs = {s[1] for s in SCENES}
    t('★★★ **모든 장면이 팩에 속한다**', packs <= set(PACK_BY),
      str(sorted(packs - set(PACK_BY)) or '0'))
    t('★★★ **BASIC 은 장면을 직접 안 담는다**(모든 장면에서 선택해 담는 팩이다)',
      'BASIC' not in packs)
    empty = [p for p, _n, _d in SCENE_PACKS
             if p != 'BASIC' and not [1 for s in SCENES if s[1] == p]]
    t('★★ **빈 팩이 없다**', not empty, str(empty or '0'))
    t('  장면마다 이름과 결이 있다',
      all(s[2] and s[3] for s in SCENES))

    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE bible_index(verse_id INTEGER, bcode INTEGER, chapter INTEGER);
      CREATE TABLE sys_pericope_asset(pericope_id INTEGER, peri_type TEXT,
             start_vid INTEGER, end_vid INTEGER, record_status TEXT);
      CREATE TABLE sys_splash_image(img_id INTEGER, is_active INTEGER,
                                    name TEXT);
      CREATE TABLE user_splash_image(img_id INTEGER, is_active INTEGER);
      CREATE TABLE user_splash_hidden(sys_img_id INTEGER PRIMARY KEY,
                                      hidden_at TEXT);
      CREATE TABLE sys_text_asset(clicked_id INTEGER, text_type TEXT,
                                  lang_code TEXT, contents TEXT,
                                  record_status TEXT);
      -- ⚠ scene 칸은 init 이 만든다(아래 항목이 그것을 잰다)
      INSERT INTO bible_index VALUES(10,1,1),(11,1,1),(12,1,2);
      INSERT INTO sys_pericope_asset VALUES(500,'BODY',10,11,'LIVE');
      INSERT INTO sys_splash_image VALUES(1,1,'Old Road'),(2,1,''),(3,1,'');
      INSERT INTO user_splash_image VALUES(9,1);
    """)
    c.commit()
    t('★ 표를 만든다(멱등)', init(c) and init(c))
    t('  사진에 장면 칸이 생긴다',
      'scene' in [r[1] for r in c.execute(
          "PRAGMA table_info(sys_splash_image)")])
    t('★★ **팩↔장면 표가 상수에서 만들어진다**',
      c.execute("SELECT COUNT(*) FROM sys_scene_pack").fetchone()[0]
      == len(SCENES),
      '%d줄' % c.execute("SELECT COUNT(*) FROM sys_scene_pack"
                        ).fetchone()[0])
    c.execute("INSERT INTO sys_scene_pack VALUES('GONE','LAND',99)")
    c.commit()
    init(c)
    t('★★★ **상수가 정본**(표에만 있는 것은 걷는다)',
      c.execute("SELECT COUNT(*) FROM sys_scene_pack WHERE scene_code='GONE'"
                ).fetchone()[0] == 0)
    t('★★ **기본팩 표시 칸이 있다**(장면으로 못 가른다)',
      'basic' in [r[1] for r in c.execute(
          "PRAGMA table_info(sys_splash_image)")])
    t('  사용자 사진에도',
      'scene' in [r[1] for r in c.execute(
          "PRAGMA table_info(user_splash_image)")])

    # ── 매핑 ────────────────────────────────────────────────────────
    set_map(c, 'RIDGE', 'CHAP', chap_key(1, 1), 2, '창1장')
    set_map(c, 'DAWN', 'CHAP', chap_key(1, 1))
    t('★ 붙인다', len(maps_of(c, 'CHAP', chap_key(1, 1))) == 2)
    set_map(c, 'RIDGE', 'CHAP', chap_key(1, 1), 3)
    t('  다시 붙여도 한 줄(멱등)',
      len(maps_of(c, 'CHAP', chap_key(1, 1))) == 2)
    bad = False
    try:
        set_map(c, 'NOPE', 'CHAP', 1)
    except ValueError:
        bad = True
    t('★★ **모르는 장면은 거부한다**', bad)
    bad2 = False
    try:
        set_map(c, 'RIDGE', 'BOOK', 1)
    except ValueError:
        bad2 = True
    t('★★ **모르는 범위도 거부한다**', bad2)

    # ── 조회 — 좁은 것부터 ──────────────────────────────────────────
    got, via = scenes_for_verse(c, 10)
    t('★★★ **장 매핑이 그 장의 모든 절을 덮는다**',
      via == 'CHAP' and len(got) == 2, '%s %s' % (via, got))
    set_map(c, 'BROOK', 'PERI', 500)
    got, via = scenes_for_verse(c, 10)
    t('★★★ **단락이 장을 이긴다**(좁은 것이 먼저)',
      via == 'PERI' and [s for s, _w in got] == ['BROOK'], via)
    # ⚠ vid 12 는 **2장**이라 1장 매핑이 안 걸린다 — 매핑이 없으면 빈손이다
    got, via = scenes_for_verse(c, 12)
    t('  매핑이 없는 장은 빈손(부르는 쪽이 아무 사진으로)', via == '', via or '(빈손)')
    set_map(c, 'SNOW', 'CHAP', chap_key(1, 2))
    got, via = scenes_for_verse(c, 12)
    t('  그 장에 붙이면 물러선다', via == 'CHAP' and got[0][0] == 'SNOW', via)
    set_map(c, 'LAMP', 'VERSE', 10)
    got, via = scenes_for_verse(c, 10)
    t('★★★ **절이 가장 세다**', via == 'VERSE' and got[0][0] == 'LAMP', via)
    t('★★ **층을 합치지 않는다**(정밀하게 적은 뜻이 묽어지지 않는다)',
      len(got) == 1, '%d개' % len(got))
    got2, via2 = scenes_for_verse(c, 11)
    t('  매핑이 없는 절은 빈손', via2 == 'PERI', via2)

    # ── 사진 고르기 ─────────────────────────────────────────────────
    r0 = pick_for_verse(c, 10)
    t('★★ **장면에 사진이 없으면 None**(부르는 쪽이 아무 사진으로 물러선다)',
      r0 is None, str(r0))
    c.execute("UPDATE sys_splash_image SET scene='LAMP' WHERE img_id IN (1,2)")
    c.commit()
    r1 = pick_for_verse(c, 10)
    t('★★★ **구절 → 장면 → 사진이 이어진다**',
      r1 and r1['scene'] == 'LAMP' and r1['img_id'] in (1, 2),
      str(r1))
    picks = {pick_for_verse(c, 10)['img_id'] for _ in range(40)}
    t('★★★ **사진이 여럿이면 랜덤**', picks == {1, 2}, str(sorted(picks)))
    r2 = pick_for_verse(c, 10, avoid=('SYS', 1))
    t('★★ **직전 것을 피한다**(같은 사진이 연달아 뜨면 고장으로 보인다)',
      r2['img_id'] == 2, str(r2['img_id']))
    c.execute("UPDATE user_splash_image SET scene='LAMP' WHERE img_id=9")
    c.commit()
    srcs = {pick_for_verse(c, 10)['src'] for _ in range(40)}
    t('★★ **사용자 사진도 함께 뽑힌다**', srcs == {'SYS', 'USER'}, str(srcs))
    # ★★★ 장면이 여럿인 자리에서 **장면도 랜덤**인가
    #   ⚠ 장면에 사진이 있어야 뽑힌다 — 없으면 None 이 나온다(위에서 확인).
    c.execute("UPDATE sys_splash_image SET scene='RIDGE' WHERE img_id=3")
    c.commit()
    set_map(c, 'DAWN', 'VERSE', 12, 1)
    set_map(c, 'RIDGE', 'VERSE', 12, 1)
    c.execute("INSERT INTO sys_splash_image(img_id,is_active,scene)"
              " VALUES(4,1,'DAWN')")
    c.commit()
    got3 = {pick_for_verse(c, 12)['scene'] for _ in range(60)}
    t('★★★ **장면이 여럿이면 장면도 랜덤**', got3 == {'DAWN', 'RIDGE'}, str(got3))
    set_map(c, 'DAWN', 'VERSE', 12, 20)     # 무게를 크게
    many = [pick_for_verse(c, 12)['scene'] for _ in range(60)]
    t('★★ **무게가 크면 더 자주 뽑힌다**',
      many.count('DAWN') > many.count('RIDGE'),
      'DAWN %d · RIDGE %d' % (many.count('DAWN'), many.count('RIDGE')))

    # ── 뗀다 ────────────────────────────────────────────────────────
    n = drop_map(c, 'LAMP', 'VERSE', 10)
    t('★ 뗀다', n == 1 and scenes_for_verse(c, 10)[1] == 'PERI')
    t('  지우지 않고 HIDE(되돌릴 수 있다)',
      c.execute("SELECT COUNT(*) FROM sys_scene_map WHERE record_status='HIDE'"
                ).fetchone()[0] == 1)

    # ── 현황 ────────────────────────────────────────────────────────
    cov = coverage(c)
    # ⚠ 위에서 2장에도 붙였으므로 장 2개 · 전 절(3)이 덮인다
    t('★★ **덮은 절 수를 센다**(진도를 화면이 본다)',
      cov['chap'] == 2 and cov['covered'] == cov['total'],
      '장 %d개 · 덮은 절 %d/%d' % (cov['chap'], cov['covered'], cov['total']))
    cnt = scene_photo_counts(c)
    t('★★★ **장면마다 사진이 몇 장인지 센다**(기본팩이 다 덮나)',
      cnt['LAMP'] == (2, 1) and cnt['RIDGE'] == (1, 0), str(cnt['LAMP']))
    t('  사진이 없는 장면도 0 으로 나온다', cnt['SNOW'] == (0, 0))
    # ── 대륙·나라 · 다국어 제목/설명 (2026-09-05) ──────────────────
    cols = [r[1] for r in c.execute("PRAGMA table_info(sys_splash_image)")]
    t('★★ **어디서 찍었나 칸이 있다**(장면과 다른 축)',
      'continent' in cols and 'country' in cols)
    t('  대륙은 고정 목록이다', len(CONTINENTS) == 7
      and CONTINENT_BY.get('MIDEAST') == '중동·성지')
    c.execute("UPDATE sys_splash_image SET continent='MIDEAST',"
              " country='Israel' WHERE img_id=1")
    r = c.execute("SELECT continent, country FROM sys_splash_image"
                  " WHERE img_id=1").fetchone()
    t('  적어 두면 그대로 읽힌다', tuple(r) == ('MIDEAST', 'Israel'),
      str(tuple(r)))

    t('★ 다국어가 없으면 **옛 이름으로 물러선다**',
      photo_text(c, 1, 'KO')[0] not in (None,),
      repr(photo_text(c, 1, 'KO')))
    save_photo_text(c, 1, 'KO', title='벧엘의 아침', desc='유대 광야의 옛 길')
    save_photo_text(c, 1, 'EN', title='Morning at Bethel', desc='An old road')
    t('★★★ **그 언어의 제목·설명이 나온다**',
      photo_text(c, 1, 'KO') == ('벧엘의 아침', '유대 광야의 옛 길'),
      str(photo_text(c, 1, 'KO')))
    t('★★ **없는 언어는 EN 으로 물러선다**(빈 화면을 안 만든다)',
      photo_text(c, 1, 'JA')[0] == 'Morning at Bethel',
      str(photo_text(c, 1, 'JA')))
    t('  어느 언어에 썼는지 센다', photo_langs(c, 1) == ['EN', 'KO'],
      str(photo_langs(c, 1)))
    save_photo_text(c, 1, 'KO', title='', desc='')
    t('★★ **비우면 행을 지운다**(빈 껍데기를 남기지 않는다)',
      photo_langs(c, 1) == ['EN'], str(photo_langs(c, 1)))
    n_txt = c.execute("SELECT COUNT(*) FROM sys_text_asset"
                      " WHERE text_type IN (?,?)",
                      (TXT_TITLE, TXT_DESC)).fetchone()[0]
    t('  빈 값으로 저장해도 행이 안 는다', n_txt == 2, '%d행' % n_txt)

    # ★★★ **사용자가 가린 사진은 장면으로도 안 나온다** (2026-09-05 사용자
    #   신고 「모든 사진을 OFF 하고 하나만 ON 했는데 다른 사진이 표시된다」).
    #   ⚠ 새 경로(장면)가 옛 경로의 가리기 필터를 안 물려받아 **가리기를
    #     통째로 우회**했다. 이 항목이 그것을 잠근다.
    c.execute("UPDATE sys_splash_image SET scene='LAMP' WHERE img_id IN (1,2)")
    c.execute("UPDATE user_splash_image SET scene='LAMP' WHERE img_id=9")
    c.commit()
    n0 = len(images_of_scene(c, ['LAMP']))
    c.execute("INSERT INTO user_splash_hidden VALUES(1,'now')")
    c.execute("INSERT INTO user_splash_hidden VALUES(2,'now')")
    c.commit()
    got = images_of_scene(c, ['LAMP'])
    t('★★★ **가린 관리자 사진은 장면으로도 안 나온다**',
      n0 == 3 and got == [('USER', 9)], '%d개 → %s' % (n0, got))
    c.execute("DELETE FROM user_splash_hidden")
    c.commit()
    t('  가림을 풀면 다시 나온다', len(images_of_scene(c, ['LAMP'])) == 3)

    # ★★★ **내 사진의 설명은 `user_text_asset` 에서 읽는다**(2026-09-05
    #   사용자 신고 — 「설명문을 입력했는데 표시되지 않는다」).
    c.execute("CREATE TABLE IF NOT EXISTS user_text_asset(clicked_id INTEGER,"
              " text_type TEXT, lang_code TEXT, contents TEXT,"
              " record_status TEXT)")
    c.execute("INSERT INTO user_text_asset VALUES(9,?,'KO','내가 찍은 길',"
              "'NEW')", (TXT_DESC,))
    c.execute("INSERT INTO user_text_asset VALUES(9,?,'KO','나의 길','NEW')",
              (TXT_TITLE,))
    c.commit()
    t('★★★ **내 사진의 글을 읽는다**(sys 만 보면 영영 안 뜬다)',
      photo_text(c, 9, 'KO', 'USER') == ('나의 길', '내가 찍은 길'),
      str(photo_text(c, 9, 'KO', 'USER')))
    t('  관리자 사진은 배포 글만 본다',
      photo_text(c, 9, 'KO', 'SYS')[1] == '',
      str(photo_text(c, 9, 'KO', 'SYS')))

    t('★ 시험이 실 DB 를 안 건드린다', True, '메모리 DB')
    c.close()
    print('  %d/%d' % (ok, ok + fail))
    return fail == 0


# ── CLI ─────────────────────────────────────────────────────────────
def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect(DB)
    init(c)
    if '--scenes' in a:
        for p, pn, pd in SCENE_PACKS:
            mine = [s for s in SCENES if s[1] == p]
            print('  [%s] %s — %s' % (p, pn, pd))
            for code, _p, nm, hint in mine:
                print('     %-14s %-14s %s' % (code, nm, hint))
    elif '--stat' in a:
        cov = coverage(c)
        print('  매핑 — 절 %d · 단락 %d · 장 %d/%d'
              % (cov['verse'], cov['peri'], cov['chap'], cov['chap_total']))
        print('  장 매핑이 덮는 절 %s / %s (%.1f%%)'
              % (format(cov['covered'], ','), format(cov['total'], ','),
                 100.0 * cov['covered'] / max(1, cov['total'])))
        print('  쓰인 장면 %d / %d' % (cov['scenes_used'], len(SCENES)))
        cnt = scene_photo_counts(c)
        zero = [s for s in SCENE_CODES if cnt[s] == (0, 0)]
        print('  사진이 없는 장면 %d개%s'
              % (len(zero), (': ' + ', '.join(zero[:8])) if zero else ''))
    else:
        print('  장면 %d · 팩 %d' % (len(SCENES), len(SCENE_PACKS)))
        print('  --scenes · --stat · --selftest')
    c.close()


if __name__ == '__main__':
    main()
