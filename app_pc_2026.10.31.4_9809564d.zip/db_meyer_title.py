# -*- coding: utf-8 -*-
"""마이어 『Our Daily Homily』 유닛 제목 다국어 적재 (영구 도구)

  원제(sys_book_unit.unit_label)는 손대지 않는다.
  표시용 덮개만 sys_text_asset(text_type='BOOK_UNIT_LABEL') 에 얹는다.
  화면은 COALESCE(ta.contents, bu.unit_label) 로 읽으므로
  목록·본문 머리가 함께 바뀐다.

  초안 = _meyer_prep/titles.json
      {"titles": {"1": {"ko": "...", "en": "..."}, ...}}

  사용법
      python db_meyer_title.py --selftest      (의무)
      python db_meyer_title.py --check
      python db_meyer_title.py --apply         (멱등)
      python db_meyer_title.py --list KO 20
"""
import io
import json
import os
import re
import sys

try:  # 2026-10-29 제자리에서 — 새 래퍼를 만들면 버려지는 옛 래퍼가 진짜 출력을 닫는다
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:  # noqa: BLE001
    pass

import appdb

BOOK_CODE = 'MEYER_ODH'
TEXT_TYPE = 'BOOK_UNIT_LABEL'
DRAFT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_meyer_prep', 'titles.json')

LANGS = ('KO', 'EN')
MAXLEN = {'KO': 40, 'EN': 70}

# OCR 잔재 — 낱말 안에 숫자·^·/ 가 섞인 것 (db_meyer_import._DMG 와 같은 뜻)
_OCR = re.compile(r'[A-Za-z]+[0-9^/][A-Za-z]*|[A-Za-z]*[0-9^/][A-Za-z]+|[\^]')
_HANGUL = re.compile(r'[가-힣]')
_BAD_CHARS = re.compile(r'[\r\n\t—]')          # 줄바꿈·탭·엠대시


# ───────────────────────────── 조회

def book_id(conn):
    r = conn.execute("SELECT book_id FROM sys_book_asset WHERE book_code=?",
                     (BOOK_CODE,)).fetchone()
    if not r:
        raise SystemExit('도서 %s 가 없습니다.' % BOOK_CODE)
    return r[0]


def units(conn):
    """{sequence: (unit_id, unit_label)} — LIVE 만."""
    bid = book_id(conn)
    return {r[0]: (r[1], r[2]) for r in conn.execute(
        "SELECT sequence, unit_id, unit_label FROM sys_book_unit "
        "WHERE book_id=? AND COALESCE(record_status,'LIVE')='LIVE'", (bid,))}


def load_draft(path=DRAFT):
    if not os.path.exists(path):
        raise SystemExit('초안이 없습니다: %s' % path)
    with open(path, encoding='utf-8') as f:
        d = json.load(f)
    return {int(k): v for k, v in (d.get('titles') or d).items()}


# ───────────────────────────── 게이트

def check_one(seq, lang, text, en_orig=''):
    """한 제목을 잰다 → 문제 목록(빈 목록이면 통과)."""
    bad = []
    t = (text or '').strip()
    if not t:
        bad.append('빈 제목')
        return bad
    if _BAD_CHARS.search(text or ''):
        bad.append('줄바꿈·탭·엠대시')
    if len(t) > MAXLEN[lang]:
        bad.append('%d자 (상한 %d)' % (len(t), MAXLEN[lang]))
    if _OCR.search(t):
        bad.append('OCR 잔재')
    if lang == 'KO' and not _HANGUL.search(t):
        bad.append('한글이 없음')
    if lang == 'EN' and _HANGUL.search(t):
        bad.append('한글이 섞임')
    if lang == 'EN' and t == (en_orig or '').strip():
        bad.append('원제와 글자가 같음')
    return bad


# 차단하지 않고 알리기만 하는 것
#   원제가 이미 깨끗한 현대 영어면 손댈 것이 없다. 억지로 바꾸면 원제보다 나빠진다.
WARN_ONLY = ('원제와 글자가 같음',)


def check(conn, draft, verbose=True):
    u = units(conn)
    problems = []
    warns = []
    missing = [s for s in sorted(u) if s not in draft]
    extra = [s for s in sorted(draft) if s not in u]
    for s in sorted(draft):
        if s not in u:
            continue
        en_orig = u[s][1] or ''
        for lang in LANGS:
            key = lang.lower()
            if key not in draft[s]:
                problems.append((s, lang, '없음'))
                continue
            for b in check_one(s, lang, draft[s][key], en_orig):
                (warns if b in WARN_ONLY else problems).append((s, lang, b))
    if verbose:
        print('유닛 %d · 초안 %d' % (len(u), len(draft)))
        print('  초안에 없는 유닛 %d · 유닛에 없는 초안 %d' % (len(missing), len(extra)))
        if missing[:10]:
            print('   빠진 것 앞 10: %s' % missing[:10])
        if extra[:10]:
            print('   남는 것 앞 10: %s' % extra[:10])
        print('  게이트 위반 %d건' % len(problems))
        for s, lang, b in problems[:30]:
            print('   #%-5d %s  %s' % (s, lang, b))
        if len(problems) > 30:
            print('   … 외 %d건' % (len(problems) - 30))
        print('  경고 %d건 (원제가 이미 현대 영어 — 그대로 둔다)' % len(warns))
        for s, lang, b in warns[:10]:
            print('   #%-5d %s  %s' % (s, lang, b))
    return missing, extra, problems


# ───────────────────────────── 적재

def apply(conn, draft, dry=False):
    u = units(conn)
    ins = upd = same = 0
    for s in sorted(draft):
        if s not in u:
            continue
        uid = u[s][0]
        for lang in LANGS:
            txt = (draft[s].get(lang.lower()) or '').strip()
            if not txt:
                continue
            row = conn.execute(
                "SELECT sys_text_id, contents FROM sys_text_asset "
                "WHERE text_type=? AND clicked_id=? AND lang_code=?",
                (TEXT_TYPE, uid, lang)).fetchone()
            if row is None:
                if not dry:
                    conn.execute(
                        "INSERT INTO sys_text_asset "
                        "(clicked_id, text_type, title, contents, lang_code, record_status) "
                        "VALUES (?,?,?,?,?,'LIVE')",
                        (uid, TEXT_TYPE, 'UL_%d' % uid, txt, lang))
                ins += 1
            elif (row[1] or '') != txt:
                if not dry:
                    conn.execute(
                        "UPDATE sys_text_asset SET contents=?, record_status='LIVE' "
                        "WHERE sys_text_id=?", (txt, row[0]))
                upd += 1
            else:
                if not dry:
                    conn.execute(
                        "UPDATE sys_text_asset SET record_status='LIVE' "
                        "WHERE sys_text_id=?", (row[0],))
                same += 1
    if not dry:
        conn.commit()
    print('%s 새로 %d · 고침 %d · 그대로 %d' % ('[모의]' if dry else '[적재]', ins, upd, same))
    return ins, upd, same


def show(conn, lang='KO', n=20):
    bid = book_id(conn)
    rows = conn.execute(
        "SELECT u.sequence, u.unit_label, ta.contents "
        "FROM sys_book_unit u LEFT JOIN sys_text_asset ta "
        "  ON ta.text_type=? AND ta.clicked_id=u.unit_id AND ta.lang_code=? "
        " AND COALESCE(ta.record_status,'LIVE')='LIVE' "
        "WHERE u.book_id=? AND COALESCE(u.record_status,'LIVE')='LIVE' "
        "ORDER BY u.sequence LIMIT ?", (TEXT_TYPE, lang, bid, n)).fetchall()
    for s, orig, tr in rows:
        print('#%-5d %-58s | %s' % (s, (orig or '')[:58], tr or '(없음)'))
    got = conn.execute(
        "SELECT COUNT(*) FROM sys_book_unit u JOIN sys_text_asset ta "
        "  ON ta.text_type=? AND ta.clicked_id=u.unit_id AND ta.lang_code=? "
        " AND COALESCE(ta.record_status,'LIVE')='LIVE' "
        "WHERE u.book_id=? AND COALESCE(u.record_status,'LIVE')='LIVE'",
        (TEXT_TYPE, lang, bid)).fetchone()[0]
    tot = conn.execute(
        "SELECT COUNT(*) FROM sys_book_unit WHERE book_id=? "
        "AND COALESCE(record_status,'LIVE')='LIVE'", (bid,)).fetchone()[0]
    print('%s 보유 %d / %d' % (lang, got, tot))


# ───────────────────────────── 자가 검증

def selftest():
    ok = fail = 0

    def t(name, cond):
        nonlocal ok, fail
        if cond:
            ok += 1
        else:
            fail += 1
            print('  FAIL %s' % name)

    # 게이트 — 잡아야 할 것
    t('빈 제목', check_one(1, 'KO', ''))
    t('공백만', check_one(1, 'KO', '   '))
    t('줄바꿈', check_one(1, 'KO', '앞\n뒤'))
    t('엠대시', check_one(1, 'KO', '앞 — 뒤'))
    t('길이 초과 KO', check_one(1, 'KO', '가' * 41))
    t('길이 초과 EN', check_one(1, 'EN', 'a' * 71))
    t('한글 없는 KO', check_one(1, 'KO', 'Walk before Me'))
    t('한글 섞인 EN', check_one(1, 'EN', 'Walk 앞에서'))
    t('OCR 잔재 7i', check_one(1, 'KO', '아침에 agai7ist'))
    t('OCR 잔재 ^', check_one(1, 'EN', 'Wi^h an awl'))
    t('원제와 동일', check_one(1, 'EN', 'My Bow in the Cloud.', 'My Bow in the Cloud.'))

    # 게이트 — 통과해야 할 것
    t('정상 KO', not check_one(1, 'KO', '저녁이 되고 아침이 되니 첫째 날'))
    t('정상 EN', not check_one(1, 'EN', 'The evening and the morning: the first day', 'X'))
    t('KO 40자 경계', not check_one(1, 'KO', '가' * 40))
    t('숫자만 든 EN 통과', not check_one(1, 'EN', 'Two whole years in his own hired house', 'X'))
    t('마침표 통과', not check_one(1, 'KO', '내 앞에서 행하여 온전하여라.'))

    # 적재 — 실 DB 에 넣었다 되돌린다
    conn = appdb.connect('bible_master.db')
    try:
        u = units(conn)
        t('유닛 1,189', len(u) == 1189)
        t('1번 있음', 1 in u)
        seq = 1
        uid = u[seq][0]
        before = conn.execute(
            "SELECT sys_text_id, contents FROM sys_text_asset "
            "WHERE text_type=? AND clicked_id=? AND lang_code='KO'",
            (TEXT_TYPE, uid)).fetchone()
        conn.execute('BEGIN')
        d = {seq: {'ko': '자가검증 임시 제목', 'en': 'selftest temporary title'}}
        i1, u1, s1 = apply(conn, d, dry=True)
        t('모의는 안 쓴다', conn.execute(
            "SELECT COUNT(*) FROM sys_text_asset WHERE text_type=? AND clicked_id=? "
            "AND contents='자가검증 임시 제목'", (TEXT_TYPE, uid)).fetchone()[0] == 0)
        apply(conn, d)                       # 내부 commit 은 BEGIN 을 푼다 → 아래서 되돌린다
        got = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE text_type=? AND clicked_id=? "
            "AND lang_code='KO'", (TEXT_TYPE, uid)).fetchone()
        t('적재됨', got and got[0] == '자가검증 임시 제목')
        i2, u2, s2 = apply(conn, d)
        t('멱등 (두 번째는 그대로)', i2 == 0 and u2 == 0 and s2 == 2)
        # 되돌리기
        if before is None:
            conn.execute("DELETE FROM sys_text_asset WHERE text_type=? AND clicked_id=? "
                         "AND lang_code IN ('KO','EN')", (TEXT_TYPE, uid))
        else:
            conn.execute("UPDATE sys_text_asset SET contents=? WHERE sys_text_id=?",
                         (before[1], before[0]))
            conn.execute("DELETE FROM sys_text_asset WHERE text_type=? AND clicked_id=? "
                         "AND lang_code='EN'", (TEXT_TYPE, uid))
        conn.commit()
        after = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE text_type=? AND clicked_id=? "
            "AND lang_code='KO'", (TEXT_TYPE, uid)).fetchone()
        t('되돌림', (after[0] if after else None) == (before[1] if before else None))
        t('시험 잔재 0', conn.execute(
            "SELECT COUNT(*) FROM sys_text_asset WHERE contents LIKE '자가검증 임시%' "
            "OR contents LIKE 'selftest temporary%'").fetchone()[0] == 0)
    finally:
        conn.close()

    print('selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    a = sys.argv[1:]
    if not a or a[0] == '--selftest':
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect('bible_master.db')
    try:
        if a[0] == '--check':
            m, e, p = check(conn, load_draft())
            sys.exit(0 if not (m or e or p) else 1)
        if a[0] == '--apply':
            d = load_draft()
            m, e, p = check(conn, d)
            if m or e or p:
                raise SystemExit('게이트를 통과하지 못했습니다 — 적재하지 않습니다.')
            apply(conn, d)
            return
        if a[0] == '--list':
            show(conn, a[1] if len(a) > 1 else 'KO', int(a[2]) if len(a) > 2 else 20)
            return
        print(__doc__)
    finally:
        conn.close()


if __name__ == '__main__':
    main()
