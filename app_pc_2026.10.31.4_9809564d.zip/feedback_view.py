"""
feedback_view.py
----------------
P1 「공지/소통」·「설정」 두 탭의 본체 (2026-08-19 재편 — 0.txt 2·3번).

 · mode='COMM' → 공지/소통: [공지사항(AnnouncementView 임베드) · FAQ · 내 문의 ·
   개인정보 · 정보(라이선스)]. 배지 = 공지 미열람 + 답변 미열람 합산.
 · mode='SET'  → 설정: [다운로드(겉모습 — 설치된 콘텐츠 실데이터) · 언어 ·
   성경 버전 · 폰트 · 화면 색 · 시작 화면].
 · 문의 전송/동기화 로직은 그대로(user_feedback) — 기능 이동만, 동작 불변.
 · 색은 전부 ui_theme 역할(§0 하드코딩 금지) — 태그는 그릴 때마다 재적용.
"""

import threading
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import appdb
import theme_font
import user_feedback as F
from settings_view import SettingsTabsMixin


def _C(role, fallback):
    try:
        import ui_theme
        return ui_theme.C(role) or fallback
    except Exception:
        return fallback

try:
    import i18n
    def _t(k, d):
        try:
            return i18n.t(k, d)
        except Exception:
            return d
except Exception:
    def _t(k, d):
        return d

#: 문의 갈래. **`BUG` 는 코드로만 산다** — 이력·관리자 화면이 그것으로 두 갈래를
#:   가른다(`kind=='BUG'` ↔ 그 밖).
_KIND_CODES = ['BUG', 'FEATURE', 'QUESTION', 'OTHER']
_KIND_KO = {'BUG': '오류/버그', 'FEATURE': '개선요청', 'QUESTION': '문의', 'OTHER': '기타'}

#: ★★ **일반문의 유형 콤보에서 「오류/버그」를 뺐다** (2026-09-06 사용자 1-2).
#:   이 화면은 §200차에 **[일반문의][오류통보] 두 갈래**로 갈렸다 — 오류는
#:   오른쪽 갈래가 **오류 기록을 붙여** 보내는 자리다. 왼쪽 콤보에 같은 이름을
#:   남겨 두면 **같은 일에 입구가 둘**이고, 그 길로 보내면 기록이 안 붙어
#:   관리자가 「무엇이 터졌나」를 알 수 없다.
#: ⚠ **코드를 지우지 않는다** — 옛 문의가 `BUG` 로 저장돼 있고 이력이 그것으로
#:   갈린다. 고르는 목록에서만 뺀다.
_ASK_KIND_CODES = [c for c in _KIND_CODES if c != 'BUG']


def _kind_label(code):
    """유형 코드 → 사용자 언어 라벨 (런타임 i18n, import시점 평가 회피)."""
    return _t('FB_KIND_' + str(code), _KIND_KO.get(code, code or ''))


def _kind_labels(codes=None):
    return [(c, _kind_label(c)) for c in (codes or _KIND_CODES)]



# ── 5분류 — 「가장 급한 것」 차례 (2026-09-07, 0.txt 1) ──────────────────
# ★ 한 자산에 언어가 여럿이면 분류도 여럿이다. 라디오로 거르려면 행마다
#   하나로 접어야 하고, 그때 **손이 먼저 가야 할 것**이 이긴다.
_CLS_RANK = {'UPGRADE': 0, 'AVAIL': 1, 'REMOVED': 2, 'LATEST': 3, 'UNPUB': 4}


#: 다운로드 탭 줄 높이·글꼴 — **한 곳에서 정한다**(2026-09-07 사용자 지시
#: 「3개 버튼 사이의 규격을 통일하라」). 화면마다 적으면 또 갈린다.
_DL_BAR_H = 32       # 갈래 단추 + 언어 콤보 줄
_DL_CLS_H = 28       # 5분류 라디오 줄
_DL_BTN_DELTA = -1   # 갈래 단추·라디오 글꼴(ui 대비)


def _cls_worst(a, b):
    """둘 중 더 급한 분류. 모르는 값은 지지 않게 맨 뒤로 둔다."""
    if not a:
        return b
    if not b:
        return a
    return a if _CLS_RANK.get(a, 9) <= _CLS_RANK.get(b, 9) else b


class FeedbackView(ttk.Frame, SettingsTabsMixin):
    def __init__(self, master, db_path, lang_getter=None, on_count_change=None,
                 on_saved=None, mode='COMM'):
        super().__init__(master)
        self.db_path = db_path
        self.db = db_path                 # SettingsTabsMixin 공용 속성
        self.on_saved = on_saved          # 설정 저장 시 P1 갱신 콜백
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.on_count_change = on_count_change
        self.mode = (mode or 'COMM').upper()   # 'COMM' 공지/소통 · 'SET' 설정
        self._attach = []          # 첨부 경로 목록
        self._threads = []
        self._busy = False
        self._first = False
        self._cnt_ann = 0          # 공지 미열람 (COMM — 임베드 공지가 알려 줌)
        self._cnt_ask = 0          # 답변 미열람
        #: 서브탭 프레임 — 개수를 붙일 자리(0.txt 둘째 8번). 없으면 안 붙인다.
        self._tab_ann = None
        self._tab_ask = None
        with appdb.connect(self.db_path) as conn:
            F.ensure_tables(conn)
            self._configured = F.is_configured(conn)
            self._email0 = F.get_email(conn)
        self._build()
        if self.mode == 'COMM':
            self.bind('<Map>', self._on_map)

    # ── UI ───────────────────────────────────────────────────────────
    def _build(self):
        nb = ttk.Notebook(self); nb.pack(fill='both', expand=True)
        self._nb = nb
        if self.mode == 'COMM':
            # 공지/소통 = 공지사항 · FAQ · 내 문의 · 개인정보 · 정보 (2026-08-19
            # 사용자 — 「소통·고지 성격은 공지 탭으로」. 서브탭 = 묵상플랜 서식)
            ann_f = ttk.Frame(nb)
            self._tab_ann = ann_f
            self._ann_base = _t('ANN_SUBTAB', '공지사항')
            nb.add(ann_f, text=' ' + self._ann_base + ' ')
            try:
                from announcement_view import AnnouncementView
                self.announce = AnnouncementView(
                    ann_f, self.db_path, lang_getter=self.lang_getter,
                    on_count_change=self._on_ann_count)
                self.announce.pack(fill='both', expand=True)
            except Exception as e:
                self.announce = None
                tk.Label(ann_f, text=f'공지 로드 실패:\n{e}', justify='left',
                         fg=_C('danger', '#C0392B')).pack(padx=10, pady=10)
            faq_f = ttk.Frame(nb); nb.add(faq_f, text=' ' + _t('FB_FAQ', '자주 묻는 질문') + ' ')
            ask_f = ttk.Frame(nb)
            self._tab_ask = ask_f
            self._ask_base = _t('FB_MYASK', '내 문의')
            nb.add(ask_f, text=' ' + self._ask_base + ' ')
            self._build_faq(faq_f)
            self._build_ask(ask_f)
            # ★ 서브탭을 고르면 **그 자리만** 열람 처리한다(0.txt 둘째 8번
            #   「사용자가 해당 목록을 클릭하면 **클릭한 곳은** 갯수 차감할 것」).
            #   그전에는 바깥 탭에 들어가는 것만으로 공지·문의가 함께 0이 됐다.
            nb.bind('<<NotebookTabChanged>>', self._on_sub_tab, add='+')
            try:
                self._build_privacy(nb)     # 개인정보(익명 이용통계 동의)
                self._build_about(nb)       # 라이선스정보(수록 자료 / 이 앱)
                # ★ 라이선스정보 **오른쪽**에 앱소개/후원 (0.txt 8-2)
                self._build_support(nb)
            except Exception:
                import traceback; traceback.print_exc()
        else:
            # 설정 = 다운로드 · 언어 · 성경 버전 · 폰트 · 화면 색 · 시작 화면
            # ★ 2026-10-13 — 무거운 두 탭(다운로드 · 모바일 연결)은 **그 탭을 처음 볼 때** 짓는다
            #   (설정을 누를 때마다 0.9초를 먼저 붙들던 자리 · `_lazy_tab`).
            # ★★ 2026-10-15 docs/1.txt 77 — 차례 = 시작/종료 · 버전/언어/폰트 · 화면 선택 · 다운로드 ·
            #   모바일 연결 · 유튜브 간편 저장 · 앱 관리. **모두 처음 볼 때 짓는다**(`_lazy_tab`) —
            #   그전에는 다운로드(0.4초)가 첫 탭이라 설정을 누르자마자 지어졌고 나머지 여덟도 미리 지었다.
            #   ⚠ 「내 공동체」 탭은 걷었다(그 일은 플랜 파일을 SNS 로 보내기로 옮겨 갔다 · 317차-73) —
            #     `_build_room`·`room_view` 는 남긴다(되살릴 자리).
            for key, ko, fn, uc in (('SET_TAB_STARTEND', '시작/종료 화면', self._build_splash, 'set_start'),
                                    ('SET_TAB_VLF', '버전/언어/폰트', self._build_vlf, 'set_vlf'),
                                    ('SET_TAB_SCREEN', '화면 선택', self._build_screen, 'set_screen'),
                                    ('SET_TAB_DL', '다운로드', self._build_download, 'set_download'),
                                    ('MOB_TAB', '모바일 연결', self._build_mobile, 'set_mobile'),
                                    ('YTS_TAB', '유튜브 간편 저장', self._build_ytsave, 'set_ytsave'),
                                    # ★ 2026-10-28 공동체몰 관리(교회 관리자 · cmall_view)
                                    ('CM_TAB', '공동체몰 관리', self._build_cmall, 'set_cmall'),
                                    ('CARE_TAB', '앱 관리', self._build_care, 'set_care')):
                self._lazy_tab(nb, _t(key, ko), fn, usage=uc)

    @staticmethod
    def _into(nb, target, **pk):
        """빌더가 부르는 `nb.add(f, …)` 를 「target 안에 담기」로 잠시 바꿔 끼운다 → 되돌리는 함수.
        빌더 코드는 그대로 둔다(`_lazy_tab` 과 같은 문법). ⚠ 이미 바꿔 끼운 것(`_lazy_tab`)이
        있으면 그것으로 되돌린다 — 그냥 지우면 바깥 자리를 잃는다."""
        old = nb.__dict__.get('add')
        pk = pk or {'fill': 'both', 'expand': True}
        nb.add = lambda f, **kw: f.pack(in_=target, **pk)

        def back():
            if old is None:
                nb.__dict__.pop('add', None)
            else:
                nb.add = old
        return back

    def _build_vlf(self, nb):
        """버전/언어/폰트 — 탭 하나 안에 갈래 단추 셋(2026-10-15 docs/1.txt 77).
        세 화면의 속은 그대로 두고 겉만 합친다(`_into`)."""
        import branch_tabs
        ph = ttk.Frame(nb)
        nb.add(ph, text=' ' + _t('SET_TAB_VLF', '버전/언어/폰트') + ' ')
        bt = branch_tabs.BranchTabs(ph, db_path=self.db_path, state_key='SET_VLF_BRANCH')
        bt.pack(fill='both', expand=True, padx=6, pady=(6, 0))
        try:
            self._load_vers()
        except Exception:
            import traceback; traceback.print_exc()
        for key, ik, ko, fn in (('VER', 'SET_TAB_VERSION', '성경 버전', self._build_version),
                                ('LANG', 'SET_TAB_LANG', '언어', self._build_lang),
                                ('FONT', 'SET_TAB_FONT', '폰트', self._build_font)):
            bt.add(key, ik, ko)
            back = self._into(nb, bt.frame_for(key))
            try:
                fn(nb)
            except Exception:
                import traceback; traceback.print_exc()
            finally:
                back()
        bt.finish()
        self.vlf_tabs = bt

    def _build_screen(self, nb):
        """화면 선택 = 화면 색 + 화면 배치(2026-10-15 docs/1.txt 77 — 판을 절반으로 줄여 한 화면에)."""
        ph = tk.Frame(nb, bg=_C('bg', '#FAFAFA'))
        nb.add(ph, text=' ' + _t('SET_TAB_SCREEN', '화면 선택') + ' ')
        for fn in (self._build_theme, self._build_layout):
            back = self._into(nb, ph, fill='x', anchor='n')
            try:
                fn(nb)
            except Exception:
                import traceback; traceback.print_exc()
            finally:
                back()

    def _lazy_tab(self, nb, title, builder, usage=None):
        """탭 자리만 먼저 놓고, 처음 고를 때 `builder(nb)` 를 돌린다.
        builder 는 제 손으로 `ttk.Frame(nb)` + `nb.add(f, …)` 를 하므로, 그때만 `nb.add` 를
        「자리 안에 채우기」로 바꿔 끼운다(빌더 코드는 그대로 · 탭 차례도 그대로)."""
        ph = ttk.Frame(nb)
        nb.add(ph, text=' ' + title + ' ')
        wait = ttk.Label(ph, text=_t('COMMON_LOADING', '불러오는 중…'))
        wait.pack(padx=12, pady=12, anchor='w')
        done = {'v': False}

        def build():
            if done['v']:
                return
            done['v'] = True
            back = self._into(nb, ph)
            try:
                builder(nb)
            except Exception:
                import traceback; traceback.print_exc()
            finally:
                back()
                try:
                    wait.destroy()
                except Exception:
                    pass

        def on_tab(_e=None):
            try:
                if nb.select() == str(ph):
                    if usage and _e is not None:   # 이용통계 — 사람이 그 탭을 고를 때마다(2026-10-20)
                        try:
                            import usage_stats
                            usage_stats.screen_hit(usage)
                        except Exception:
                            pass
                    if not done['v']:
                        self.after(20, build)      # 「불러오는 중」을 먼저 그린 뒤
            except Exception:
                pass
        nb.bind('<<NotebookTabChanged>>', on_tab, add='+')
        self.after_idle(on_tab)

    # ── 배지 합산 (COMM — 공지 미열람 + 답변 미열람) ──────────────────
    def _on_ann_count(self, n):
        self._cnt_ann = int(n or 0)
        self._push_count()

    def _push_count(self):
        if self.mode != 'COMM':
            return
        self._sync_sub_labels()
        if callable(self.on_count_change):
            self.on_count_change(self._cnt_ann + self._cnt_ask)

    def _sync_sub_labels(self):
        """서브탭 이름에 개수를 붙인다 — `공지사항 (3)`. 0이면 안 붙인다.

        ⚠ 이름을 여기서만 짓는다 — 두 곳에서 지으면 한쪽이 옛 개수로 굳는다.
        """
        for frame, base, cnt in ((self._tab_ann, getattr(self, '_ann_base', '공지사항'),
                                  self._cnt_ann),
                                 (self._tab_ask, getattr(self, '_ask_base', '내 문의'),
                                  self._cnt_ask)):
            if frame is None:
                continue
            try:
                self._nb.tab(frame, text=(' %s (%d) ' % (base, cnt)) if cnt else ' %s ' % base)
            except Exception:
                pass

    def _on_sub_tab(self, _e=None):
        """지금 보고 있는 서브탭만 열람 처리한다."""
        if self.mode != 'COMM':
            return
        try:
            cur = self._nb.select()
        except Exception:
            return
        if self._tab_ann is not None and cur == str(self._tab_ann):
            ann = getattr(self, 'announce', None)
            if ann is not None:
                ann.mark_seen()            # 안에서 _on_ann_count(0) 로 돌아온다
            else:
                self._cnt_ann = 0
                self._push_count()
        elif self._tab_ask is not None and cur == str(self._tab_ask):
            try:
                with appdb.connect(self.db_path) as conn:
                    F.mark_seen(conn)
            except Exception:
                pass
            self._cnt_ask = 0
            self._push_count()

    # ── 다운로드 (2026-08-19 0.txt 2번 — 겉모습 먼저, 서버는 나중) ────
    #: ★ **최신자료가 맨 위**(2026-09-04 사용자 지시 4 — 「전체 버튼 왼쪽에
    #:   최신자료 버튼을 만들어라. **날자순 최근 자료가 위에 표시**」).
    _DL_KINDS = (('LATEST', 'DL_K_LATEST', '최신자료'),
                 ('ALL', 'COMMON_ALL', '전체'), ('APP', 'DL_K_APP', '앱'),
                 ('BIBLE', 'SET_TAB_VERSION', '성경 버전'),
                 ('COMM', 'DL_K_COMM', '주석'), ('BOOK', 'DL_K_BOOK', '도서'),
                 ('SERMON', 'DL_K_SERMON', '설교집'),
                 ('DICT', 'DL_K_DICT', '사전'),
                 # ★ 원어 사전 — 팩은 있었는데 **갈래가 없어 받을 길이 없었다**
                 #   (2026-09-29 · 1.txt 22-1(1) 점검에서 잡았다). 언어를 안 가린다.
                 ('LEX', 'DL_K_LEX', '원어 사전'),
                 ('DESC', 'DL_K_DESC', '설명문'),
                 # ⚠ 유형을 늘리면 **여기 한 줄** — `_dl_rows_load` 가 내는
                 #   코드와 짝이 맞아야 걸러진다.
                 # ★ 시작화면 사진 — 팩을 고르면 **샘플 썸네일**이 뜬다
                 #   (2026-09-05 사용자 지시).
                 ('IMAGE', 'DL_K_IMAGE', '시작화면 사진'),
                 # ★ 환경설정 양식(A 타입·B 타입 …) — 코어에 실려 온다(`sys_pref_preset`).
                 #   받는 것이 아니라 **적용**하는 줄이다(1.txt 22-1(3) · 293차).
                 ('PRESET', 'DL_K_PRESET', '환경설정 양식'),
                 ('LINK', 'DL_K_LINK', '영상·링크'))
    #: 언어를 안 가리는 갈래 — 언어 콤보로 걸러내지 않는다
    _DL_NOLANG = ('APP', 'LINK', 'LEX', 'PRESET')

    def _build_room(self, nb):
        """설정 ▸ 내 공동체 — `room_view.RoomView` 를 그대로 심는다.

        ⚠ 여기서 화면을 다시 짓지 않는다 — 두 벌이 되면 갈린다.
        """
        f = ttk.Frame(nb)
        nb.add(f, text=' ' + _t('ROOM_TAB', '내 공동체') + ' ')
        try:
            from room_view import RoomView
            self.room = RoomView(f, self.db_path, lang_getter=self.lang_getter)
            self.room.pack(fill='both', expand=True)
        except Exception as e:
            self.room = None
            # ⚠ 조용히 빈 탭을 두지 않는다(§0-1) — 왜 안 뜨는지 말한다.
            tk.Label(f, text=(_t('ROOM_LOAD_FAIL', '내 공동체 화면을 열 수 '
                                 '없습니다:') + chr(10) + str(e)),
                     justify='left', fg=_C('danger', '#C0392B')).pack(
                padx=10, pady=10)

    def _build_layout(self, nb):
        """화면 배치 — P1·P4 탭을 위쪽 / 왼쪽 중에서 **따로** 선택한다(317차-26).

        고르면 곧바로 바뀐다(화면 색과 같은 문법 — 저장 단추가 없다). 저장과 적용은
        `side_rail.set_mode` 한 문이 한다(여기서 user_config 를 따로 쓰지 않는다).
        ★ 2026-10-15 docs/1.txt 77 — 한 줄에 「이름 ○ 위쪽 탭 ○ 왼쪽 탭」 · 안내 줄 걷음.
        """
        import side_rail
        bg = _C('bg', '#FAFAFA')
        f = tk.Frame(nb, bg=bg)
        nb.add(f, text=' ' + _t('SET_TAB_LAYOUT', '화면 배치') + ' ')

        def _reg(w):
            try:
                theme_font.register(w, self.db_path, 'ui')
            except Exception:
                pass
            return w

        box = tk.Frame(f, bg=bg)
        box.pack(anchor='w', padx=14, pady=(12, 0))
        self._layout_vars = {}
        rows = (('P1', 'LAYOUT_P1B', '성경읽기 화면'),
                ('P4', 'LAYOUT_P4B', '역본비교 화면'))
        for r, (area, key, ko) in enumerate(rows):
            _reg(tk.Label(box, text=_t(key, ko), bg=bg, fg=_C('fg_title', '#2C3E50'),
                          anchor='w')).grid(row=r, column=0, sticky='w', padx=(0, 16), pady=2)
            var = tk.StringVar(value=side_rail.get_mode(self.db_path, area))
            self._layout_vars[area] = var
            for c, (mode, mk, mko) in enumerate((('TOP', 'LAYOUT_TOP', '위쪽 탭'),
                                                 ('LEFT', 'LAYOUT_LEFT', '왼쪽 탭'))):
                rb = tk.Radiobutton(
                    box, text=_t(mk, mko), value=mode, variable=var,
                    bg=bg, fg=_C('fg', '#2C3E50'), activebackground=bg,
                    selectcolor=_C('panel', '#FFFFFF'), anchor='w',
                    command=lambda a=area, v=var: side_rail.set_mode(self.db_path, a, v.get()))
                _reg(rb).grid(row=r, column=c + 1, sticky='w', padx=(0, 12))

    def _build_mobile(self, nb):
        """설정 ▸ 모바일 연결 — `mobile_view.MobileSyncView` 를 그대로 심는다."""
        f = ttk.Frame(nb)
        nb.add(f, text=' ' + _t('MOB_TAB', '모바일 연결') + ' ')
        try:
            from mobile_view import MobileSyncView
            self.mobile = MobileSyncView(f, self.db_path, lang_getter=self.lang_getter)
            self.mobile.pack(fill='both', expand=True)
        except Exception as e:
            self.mobile = None
            tk.Label(f, text=(_t('MOB_VIEW_FAIL', '모바일 연결 화면을 열 수 '
                                 '없습니다: ') + str(e)),
                     justify='left', fg=_C('danger', '#C0392B')).pack(
                padx=10, pady=10)

    def _build_care(self, nb):
        """설정 ▸ 앱 관리 — 저장 공간 · 자동 정리 · 끊긴 영상 · 내 자료 백업 (`app_care_view`)."""
        f = ttk.Frame(nb)
        nb.add(f, text=' ' + _t('CARE_TAB', '앱 관리') + ' ')
        try:
            from app_care_view import AppCareView
            self.care = AppCareView(f, self.db_path)
            self.care.pack(fill='both', expand=True)
        except Exception as e:
            self.care = None
            tk.Label(f, text=_t('CARE_FAIL', '하지 못했습니다: %s') % e, justify='left',
                     fg=_C('danger', '#C0392B')).pack(padx=10, pady=10)

    def _build_cmall(self, nb):
        """설정 ▸ 공동체몰 관리 — `cmall_view.CmallAdminView`(교회 관리자 · 구글 시트 + Apps Script)."""
        f = ttk.Frame(nb)
        nb.add(f, text=' ' + _t('CM_TAB', '공동체몰 관리') + ' ')
        try:
            from cmall_view import CmallAdminView
            self.cmall = CmallAdminView(f, self.db_path)
            self.cmall.pack(fill='both', expand=True)
        except Exception as e:
            self.cmall = None
            tk.Label(f, text=_t('CARE_FAIL', '하지 못했습니다: %s') % e, justify='left',
                     fg=_C('danger', '#C0392B')).pack(padx=10, pady=10)

    def _build_ytsave(self, nb):
        """설정 ▸ 유튜브 간편 저장 — `yt_save_view.YtSaveView` 를 심는다."""
        f = ttk.Frame(nb)
        nb.add(f, text=' ' + _t('YTS_TAB', '유튜브 간편 저장') + ' ')
        from yt_save_view import YtSaveView
        self.ytsave = YtSaveView(f, self.db_path, lang_getter=self.lang_getter)
        self.ytsave.pack(fill='both', expand=True)

    def _build_download(self, nb):
        """다운로드 — **좌(갈래) · 중(목록) · 우(자세히·받기/삭제)** 세 칸.

        ★★★ **전면 재설계** (2026-09-04 사용자 지시 — 「다운로드/지우기 흐름을
          **전혀 새롭게 설계**하라 … 목록에서 **더블클릭하면 자세한 설명내용이
          표시**되고 **확실하게 다운로드 받겠다는 생각이 들 때 비로소 다운로드
          버튼**을 누르도록 … 지금은 눈깜짝할사이에 아래에 한줄 표시되고 끝난다.
          **다운로드 받은 것이 무엇인지도 모르니 판단할 수도 없다**」).
          ⚠⚠ 그전에는 [지금 받기] 한 번에 **곧바로 받아졌다** — 무엇을 받는지
            읽을 자리가 없어 「실험삼아 눌렀다가 느닷없이 업데이트」가 났다.
          ⇒ **읽고 → 판단하고 → 누른다.** 받는 단추는 **오른쪽 칸 안**에만 있고
            고르기 전에는 잠겨 있다. 누르면 **한 번 더 확인**을 받는다.
        ★ **상단 두 줄을 걷었다**(사용자 지시 3 — 「새자료확인, 지금 받기 버튼도
          필요 없다. 받은자료 지우기 버튼도 제거하라. **상단 2줄을 모두 제거**」).
        ★ **목록은 늘 나온다** — 받았든 지웠든(지시 6). 상태 셋 =
          **설치됨 / 삭제됨 / 미설치**.
        ★ **세 칸은 `PanedWindow` 라 리사이즈된다**(지시 5).
        """
        f = ttk.Frame(nb)
        nb.add(f, text=' ' + _t('SET_TAB_DL', '다운로드') + ' ')

        # ★★★ **갈래 단추 셋** (2026-09-06 사용자 5-1 「3개의 버튼 배치 :
        #   최신버전 점검, 항목별 다운로드, 자동설정」 · 「**자동은 모두
        #   최신화. 항목별은 하나씩.**」).
        #   · 최신버전 점검 — 갭을 재고 **한 번에** 최신으로
        #   · 항목별 다운로드 — 지금 화면(**하나씩**)
        #   · 자동설정 — 앞으로 저절로 최신화할지
        #   ⚠⚠ **누르면 곧바로 받지 않는다** — §195차에 사용자가 「눈깜짝할
        #     사이에 … **받은 것이 무엇인지도 모르니 판단할 수도 없다**」고
        #     반려한 그 자리다. 점검은 **먼저 무엇을 받을지 보이고**, 받는
        #     단추는 그 아래에 따로 둔다.
        #   ⚠ 한 줄(30px)만 쓴다 — 그때 걷은 것은 **두 줄**이었다.
        # ★★ **높이를 못 박는다**(2026-09-07 사용자 「3개 버튼을 누를 때마다
        #   화면이 흔들린다 … 라디오버튼/언어콤보 유무에 따라서 높이가
        #   달라지는 것 같은데 통일하라」). 언어 콤보가 갈래마다 들고 나므로
        #   자연 높이로 두면 줄 높이가 갈래마다 달라진다(§133차 그 병).
        bar = tk.Frame(f, bg=_C('panel', '#F4F6F7'), height=_DL_BAR_H)
        bar.pack(fill='x', padx=6, pady=(6, 0))
        bar.pack_propagate(False)
        self._dl_mode = 'ITEM'
        self._dl_mbtn = {}
        for code, key, dflt in (('CHECK', 'DL_M_CHECK', '최신버전 점검'),
                                ('ITEM', 'DL_M_ITEM', '항목별 다운로드'),
                                ('AUTO', 'DL_M_AUTO', '자동설정')):
            # ⚠ **크기를 도서/설교 서브탭에 맞춘다**(2026-09-06 사용자
            #   「다운로드 서브탭 3개가 **너무 크다. 탭 메뉴보다 더 크다.**
            #   줄이고 폭도 줄여라. **도서읽기 설교집 버튼 사이즈로**」).
            #   실측 도서 `81x26`(padx 10·pady 3) ↔ 다운로드 `115x28`.
            #   글자가 길어 폭이 컸다 ⇒ 여백과 글꼴을 한 단계 줄인다.
            #   ⚠⚠ **`size_delta=-1` 로는 오히려 커졌다** — `ui` 구역이
            #     10pt 라 Tk 기본(9pt)보다 크다(실측 107→115px). 한 단계 더.
            #   ⚠ `highlightthickness` 가 위아래 2px 를 먹는다.
            #   ⚠ **2026-09-07 한 단계 키웠다**(사용자 「현재 버튼의 글자를
            #     한단계 크게 하라」) — 그리고 **라디오를 같은 값으로 맞춘다**.
            b = tk.Button(bar, text=_t(key, dflt), relief='raised', bd=1,
                          padx=6, pady=1, cursor='hand2', highlightthickness=0,
                          command=lambda c=code: self._dl_set_mode(c))
            try:
                theme_font.register(b, self.db_path, 'ui',
                                    size_delta=_DL_BTN_DELTA)
            except Exception:
                pass
            b.pack(side='left', padx=(4, 0), pady=2)
            self._dl_mbtn[code] = b
        # ★★★ **언어 콤보는 갈래 줄에 둔다 — 셋이 함께 쓴다**
        #   (2026-09-06 사용자 「다운로드 탭 화면에 **3개의 서브탭에 모두
        #   언어콤보가 특정**되어야 최신버전 점검도 가능하고 개별항목
        #   다운로드, 자동 다운로드 가능해진다」).
        #   ⚠ 그전에는 **항목별 화면 안**에만 있어서 점검·자동설정은 언어를
        #     가릴 길이 없었다(그리고 그 콤보마저 숫자를 보이고 있었다).
        #   ⚠ **자동설정에서는 감춘다** — 거기는 **복수**를 고르므로 그 화면
        #     안에 체크 목록이 따로 있다(콤보와 둘이 있으면 어느 것이 도는지 모른다).
        self._dl_lang2 = ttk.Combobox(bar, state='readonly', width=16)
        self._dl_lang2.pack(side='right', padx=(4, 8), pady=3)
        self._dl_lang2.bind('<<ComboboxSelected>>', self._dl_lang_pick)
        # ⚠ **「언어」 라벨을 안 그린다**(2026-09-07 사용자 지시) — 콤보에
        #   `한국어 (KO)` 가 이미 들어 있어 무엇을 고르는지 말한다.
        #   ⚠ 위젯은 남긴다 — `_dl_set_mode` 가 감췄다 되살리는 짝이 있다.
        self._dl_lang2_lbl = tk.Label(bar, text='',
                                      bg=_C('panel', '#F4F6F7'),
                                      fg=_C('fg_dim', '#5D6D7E'))
        self._dl_mhint = tk.Label(bar, text='', anchor='w',
                                  bg=_C('panel', '#F4F6F7'),
                                  fg=_C('fg_dim', '#5D6D7E'))
        self._dl_mhint.pack(side='left', padx=10)
        theme_font.register(self._dl_mhint, self.db_path, 'ui')

        # ★★★ **5분류 라디오 — 화면 전체의 필터**(2026-09-07 사용자 0.txt
        #   1·2-1 「목록 상단내용 수정 … **라디오 버튼 배치**(전체/최신판/
        #   업그레이드 가능/다운로드 가능/미발행)」).
        #   ★ **점검과 항목별이 함께 쓴다** — 같은 분류를 두 화면에서 각각
        #     만들면 이름이 갈린다. 그래서 갈래 줄 **바로 아래**에 둔다.
        #   ★ **「삭제됨」을 하나 더**(사용자 「읽고 난 후에 삭제했다면 의미가
        #     크다」) — 「한 번도 안 받은 것」과 뜻이 다르다.
        #   ⚠ **자동설정에서는 감춘다** — 거기는 목록이 없어 거를 것이 없다.
        import pack_status as _PS0
        #   ⚠ **자동설정에서도 자리는 남긴다**(2026-09-07) — 줄을 통째로
        #     걷으면 갈래를 바꿀 때마다 아래 화면이 26px 씩 오르내린다.
        #     **내용만 감춘다.**
        self._dl_clsf = tk.Frame(f, bg=_C('panel', '#F4F6F7'), height=_DL_CLS_H)
        self._dl_clsf.pack(fill='x', padx=6)
        self._dl_clsf.pack_propagate(False)
        self._dl_cls = tk.StringVar(value='')
        for code, key, dflt in (
                ('', 'DL_CL_ALL', '전체'),
                (_PS0.CL_LATEST, 'DL_CL_LATEST', '최신판'),
                (_PS0.CL_UPGRADE, 'DL_CL_UPGRADE', '최신버전 다운로드 가능'),
                (_PS0.CL_AVAIL, 'DL_CL_AVAIL', '아직 받지 않았음'),
                (_PS0.CL_REMOVED, 'DL_CL_REMOVED', '삭제됨')):
            # ⚠⚠ **「미발행」을 걷었다**(2026-09-07 사용자 「**관리자가
            #   준비중인 데이터를 왜 사용자에게 발행하는가**. 관리자가
            #   발행한다는 것은 완전히 다운로드 가능한 것만 배포해야 한다」).
            #   ⇒ 라디오만이 아니라 **그 자산을 목록에서 통째로 뺀다**
            #     (`_dl_fill`). 「갈래별 합 = 전체」 불변식은 **발행된 것
            #     안에서** 다시 잡는다 — 불변식을 지키려고 못 받을 것을
            #     보이는 것은 앞뒤가 바뀐 것이다.
            rb = ttk.Radiobutton(self._dl_clsf, text=_t(key, dflt), value=code,
                                 variable=self._dl_cls, style='DL.TRadiobutton',
                                 command=self._dl_cls_pick)
            rb.pack(side='left', padx=(0, 10), pady=2)
        # ⚠ 범례를 없애면 `A-2` 가 무슨 뜻인지 읽을 자리가 사라진다 —
        #   같은 줄 **오른쪽 끝**에 한 줄로 남긴다.
        # ★★ **라디오 글꼴 = 갈래 단추 글꼴**(2026-09-07 사용자 「라디오버튼이
        #   3개의 버튼보다 더 글자가 크다. **버튼 글자와 통일**시켜라」).
        #   ⚠ ttk 위젯이라 `theme_font.register` 가 못 닿는다 — **스타일**로
        #     같은 값을 먹인다(`resolve` 가 base+구역을 합친 최종값이다).
        try:
            _rf = theme_font.resolve(self.db_path, 'ui')
            ttk.Style().configure(
                'DL.TRadiobutton',
                font=(_rf['family'], max(6, int(_rf['size']) + _DL_BTN_DELTA)))
        except Exception:
            pass
        # ⚠ **범례를 걷었다**(2026-09-07 사용자 「무슨 말인지 모르겠다.
        #   사용자는 더 이해하지 못한다」) — 축이 둘이라는 것은 **자동설정
        #   안내문 한 자리**에서만 필요하고 목록에서는 `A-2` 로 충분하다.
        self._dl_ver_note = tk.Label(
            self._dl_clsf, anchor='e', bg=_C('panel', '#F4F6F7'),
            fg=_C('fg_dim', '#7F8C8D'), text='')
        try:
            theme_font.register(self._dl_ver_note, self.db_path, 'ui',
                                size_delta=-1)
        except Exception:
            pass

        pw = tk.PanedWindow(f, orient='horizontal', sashwidth=5,
                            bg=_C('border', '#D5D8DC'))
        pw.pack(fill='both', expand=True, padx=6, pady=6)

        # ── 좌: 갈래 (최신자료가 맨 위 — 지시 4) ─────────────────────────
        left = tk.Frame(pw, bg=_C('bg', '#FAFAFA'))
        pw.add(left, minsize=110, width=145)
        self._dl_pw, self._dl_left = pw, left
        self._dl_kinds_tv = ttk.Treeview(left, show='tree', selectmode='browse')
        self._dl_kinds_tv.pack(fill='both', expand=True)
        theme_font.list_style('DlKinds.Treeview', self.db_path)
        self._dl_kinds_tv.configure(style='DlKinds.Treeview')
        for code, key, dflt in self._DL_KINDS:
            self._dl_kinds_tv.insert('', 'end', iid=code, text=_t(key, dflt))
        self._dl_kinds_tv.bind('<<TreeviewSelect>>', self._dl_on_kind)

        # ── 중: 목록 ────────────────────────────────────────────────────
        mid = tk.Frame(pw, bg=_C('bg', '#FAFAFA'))
        pw.add(mid, minsize=180, width=320)
        self._dl_mid_pane = mid
        self._dl_lrow = tk.Frame(mid, bg=_C('panel', '#F4F6F7'))
        self._dl_lrow.pack(fill='x')
        tk.Label(self._dl_lrow, text=_t('COMMON_LANG', '언어'),
                 bg=_C('panel', '#F4F6F7'), fg=_C('fg', '#333')
                 ).pack(side='left', padx=(4, 4))
        # ⚠ **옛 자리(왼쪽 칸)에는 안 만든다** — 갈래 줄로 옮겼다.
        #   위젯은 남기되 그리지 않는다(이 이름을 읽는 자리가 여럿이다).
        self._dl_lang = ttk.Combobox(self._dl_lrow, state='readonly', width=10)
        self._dl_lang.bind('<<ComboboxSelected>>',
                           lambda _e: self._dl_fill(self._dl_kind))
        cols = ('state', 'title', 'sub')
        tv = ttk.Treeview(mid, columns=cols, show='headings',
                          selectmode='browse')
        tv.heading('state', text=_t('DL_COL_STATE', '상태'))
        tv.heading('title', text=_t('COMMON_TITLE', '제목'))
        tv.heading('sub', text=_t('DL_COL_VER', '버전'))
        tv.column('state', width=62, stretch=False, anchor='center')
        tv.column('title', width=165)
        tv.column('sub', width=88, stretch=False, anchor='center')
        vsb = ttk.Scrollbar(mid, orient='vertical', command=tv.yview)
        tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        tv.pack(fill='both', expand=True)
        # ⚠⚠ **목록 서식은 표준 한 문**(`theme_font.list_style`) — 그전에는 행
        #   높이가 화면마다 박혀 있어 「간격 조절이 제대로 안 된다」가 났다
        #   (2026-09-04 사용자 지적 1). 설정에서 글꼴을 키우면 함께 커진다.
        theme_font.list_style('DlList.Treeview', self.db_path)
        tv.configure(style='DlList.Treeview')
        tv.bind('<<TreeviewSelect>>', self._dl_on_pick)
        tv.bind('<Double-1>', self._dl_on_pick)
        self._dl_tv = tv
        self._dl_mid = mid

        # ── 우: 자세히 + 받기/삭제 ───────────────────────────────────────
        right = tk.Frame(pw, bg=_C('bg', '#FAFAFA'))
        pw.add(right, minsize=230)
        self._dl_title = tk.Label(right, text='', anchor='w', justify='left',
                                  bg=_C('bg', '#FAFAFA'), fg=_C('fg', '#000'))
        self._dl_title.pack(fill='x', padx=10, pady=(8, 0))
        # ⚠ `register` 는 `size_delta` 다(`delta`·`weight` 없음) — 굵기는
        #   위젯 옵션으로 준다.
        theme_font.register(self._dl_title, self.db_path, 'ui', size_delta=2)
        self._dl_meta = tk.Label(right, text='', anchor='w', justify='left',
                                 bg=_C('bg', '#FAFAFA'), fg=_C('fg_dim', '#666'))
        self._dl_meta.pack(fill='x', padx=10, pady=(0, 4))
        theme_font.register(self._dl_meta, self.db_path, 'ui')
        bwrap = tk.Frame(right, bg=_C('bg', '#FAFAFA'))
        bwrap.pack(fill='both', expand=True, padx=(10, 0), pady=(0, 4))
        self._dl_body = tk.Text(bwrap, wrap='word', relief='flat', height=8,
                                bg=_C('panel', '#FFF'), fg=_C('fg', '#000'))
        bsb = ttk.Scrollbar(bwrap, command=self._dl_body.yview)
        self._dl_body.configure(yscrollcommand=bsb.set, state='disabled')
        bsb.pack(side='right', fill='y')
        self._dl_body.pack(fill='both', expand=True)
        theme_font.register(self._dl_body, self.db_path, 'prose')
        act = tk.Frame(right, bg=_C('bg', '#FAFAFA'))
        act.pack(fill='x', padx=10, pady=(0, 6))
        self._dl_b_get = tk.Button(act, text=_t('SET_DL_GET', '지금 받기'),
                                   bd=0, padx=12, pady=5, cursor='hand2',
                                   state='disabled', command=self._dl_get)
        self._dl_b_get.pack(side='left')
        self._dl_b_del = tk.Button(act, text=_t('DL_BTN_DEL', '삭제하기'),
                                   bd=0, padx=12, pady=5, cursor='hand2',
                                   state='disabled', command=self._dl_clear)
        self._dl_b_del.pack(side='left', padx=(6, 0))
        # ★★★ **점검은 표로 보인다**(2026-09-06 사용자 「최신버전 점검
        #   화면에서는 **자산목록, 언어1 현재버전/최신버전, 언어2 …** 이렇게
        #   table 방식으로 배치하는 것이 어떨까?」 · 「사용자가 확보한 버전이
        #   **EN FR 두개**라고 한다면 각 언어별 현 버전과 최신버전을 표시」).
        #   ⚠ 글로 늘어놓으면 「어느 언어의 몇 판인가」를 읽는 사람이 머리로
        #     맞춰야 한다. 표는 **한 눈에** 보인다.
        #   ★ 그래서 점검 화면에는 **언어 콤보가 필요 없다** — 표가 언어를
        #     전부 보이므로 고를 것이 없다.
        self._dl_grid = ttk.Treeview(right, show='headings', height=12)
        # ★ **더블클릭 = 항목별 화면의 그 항목으로**(2026-09-06 사용자 지시)
        self._dl_grid.bind('<Double-1>', self._dl_grid_jump)
        # ⚠ 표 위 한 줄 — 겹클릭 안내. 분류 라디오는 **갈래 줄 아래**로 옮겼다
        #   (두 화면이 함께 쓰므로).
        self._dl_meta2 = tk.Label(right, text='', anchor='w', justify='left',
                                  bg=_C('bg', '#FAFAFA'),
                                  fg=_C('fg_dim', '#7F8C8D'))
        self._dl_grid_sb = ttk.Scrollbar(right, orient='vertical',
                                         command=self._dl_grid.yview)
        self._dl_grid.configure(yscrollcommand=self._dl_grid_sb.set)
        self._dl_msg = tk.Label(right, text='', anchor='w', justify='left',
                                bg=_C('bg', '#FAFAFA'), fg=_C('fg', '#333'),
                                wraplength=260)
        self._dl_msg.pack(fill='x', padx=10, pady=(0, 8))
        theme_font.register(self._dl_msg, self.db_path, 'ui')

        self._dl_rows = self._dl_rows_load()
        self._dl_kind = 'LATEST'
        # ⚠⚠⚠ **칸이 하나 어긋나 있었다** (2026-09-06 사용자 「항목별
        #   다운로드 탭의 **언어콤보는 숫자가 표시된다. 오류 같아 보인다**」).
        #   `_dl_rows` 한 줄은 `(k, key, lang, title, ver, lic, st)` 인데
        #   여기서 **`r[1]`(key)** 를 언어로 썼다. 설명문의 key 는 **책 번호**라
        #   콤보에 `1 · 2 · 27 · 3 …` 이 떴다(문자열 정렬이라 차례도 뒤죽박죽).
        #   ⚠ 거르는 자리(`_dl_fill`)는 `lang` 을 제대로 썼다 — **콤보만**
        #     틀렸고, 그래서 「골라도 안 먹는다」가 아니라 「고를 수가 없다」였다.
        self._dl_lang_fill()
        self._dl_kinds_tv.selection_set('LATEST')
        self._dl_set_mode('ITEM')

    def _dl_lang_fill(self):
        """언어 콤보를 채운다 — **코드가 아니라 이름**으로.

        ★ 이름은 `lang_combo.label` 한 문이 짓는다(§lang_combo) — 화면마다
          지으면 「한국어」와 「KO」가 섞인다.
        ★ **기본은 앱 언어**다(사용자 「3개의 서브탭에 모두 언어콤보가
          **특정**되어야」). 전체를 보고 싶으면 「전체」를 고른다.
        ⚠ **있는 언어만** 올린다 — 고정 11언어를 늘어놓으면 골라도 빈 목록이
          나온다(§0-1 빈 서랍).
        """
        import pack_status as PS
        try:
            import lang_combo as LC
        except Exception:
            LC = None
        langs = sorted({(r[2] or '').upper() for r in self._dl_rows
                        if r[0] not in self._DL_NOLANG and r[2]
                        and r[2] not in ('-', '')})
        self._dl_lang_code = {}
        allv = _t('COMMON_ALL', '전체')
        vals = [allv]
        for lg in langs:
            try:
                nm = LC.label(lg, None, self.db_path) if LC else lg
            except Exception:
                nm = lg
            lab = ('%s (%s)' % (nm, lg)) if nm and nm != lg else lg
            self._dl_lang_code[lab] = lg
            vals.append(lab)
        # ★ 저장해 둔 것 → 없으면 앱 언어 → 그것도 없으면 전체
        want = ''
        try:
            want = (PS.dl_lang(self.db_path) or '').upper()
        except Exception:
            want = ''
        pick = allv
        for lab, lg in self._dl_lang_code.items():
            if lg == want:
                pick = lab
                break
        for cb in (self._dl_lang, getattr(self, '_dl_lang2', None)):
            if cb is None:
                continue
            cb['values'] = vals
            cb.set(pick)

    def _dl_lang_pick(self, _e=None):
        """언어를 선택하면 **그 자리에서** 목록·점검이 따라온다.

        ⚠ 고르고 아무 일도 안 일어나면 「안 먹는다」로 읽힌다(§0-1).
        ★ 고른 것은 **저장한다** — 다음에 열면 그대로다.
        """
        import pack_status as PS
        lg = self._dl_lang_get()
        try:
            PS.set_dl_lang(lg, self.db_path)
        except Exception:
            pass
        # 두 콤보를 맞춘다(옛 위젯을 읽는 자리가 있다)
        lab = (getattr(self, '_dl_lang2', None) or self._dl_lang).get()
        for cb in (self._dl_lang, getattr(self, '_dl_lang2', None)):
            if cb is not None and cb.get() != lab:
                cb.set(lab)
        if self._dl_mode == 'CHECK':
            self._dl_show_check()
        elif self._dl_mode == 'ITEM':
            self._dl_fill(self._dl_kind)

    def _dl_lang_get(self):
        """콤보에서 선택한 **언어 코드**. 전체면 빈 글자."""
        cb = getattr(self, '_dl_lang2', None) or self._dl_lang
        lab = cb.get() or ''
        if lab == _t('COMMON_ALL', '전체'):
            return ''
        return (getattr(self, '_dl_lang_code', {}) or {}).get(lab, lab).upper()

    # ── 갈래 셋 (2026-09-06 사용자 5-1) ──────────────────────────────
    def _dl_panes(self, left=True, mid=True):
        """칸을 보이거나 감춘다.

        ★★ **갈래마다 쓰는 칸이 다르다**(2026-09-06 사용자 「자동설정 /
          최신버전 점검 두 개의 탭은 **왼쪽의 트리구조를 없애라. 화면이
          이해하기 어렵다**」).
          · 항목별 — 왼쪽(갈래)·가운데(목록)·오른쪽 셋 다 쓴다
          · 최신버전 점검 — 갈래는 뜻이 없다(밀린 것만 보면 된다) ⇒ 왼쪽 없음
          · 자동설정 — 고를 것이 없다 ⇒ 왼쪽·가운데 없음, 안내 한 장
        ⚠ **차례를 지켜 되돌린다** — `add` 는 맨 뒤에 붙으므로 그냥 다시
          넣으면 왼쪽 칸이 오른쪽으로 간다. `before=` 로 자리를 못 박는다.
        """
        pw = self._dl_pw
        # ⚠⚠ **한 칸씩 붙이면 차례가 뒤집힌다**(실측 `중 좌 우`) — 붙일 때
        #   기준으로 삼을 칸이 아직 없을 수 있기 때문이다.
        #   ⇒ **보일 것을 전부 걷고 차례대로 다시 붙인다.** 오른쪽 칸은
        #     늘 남아 있으므로 그 앞에 좌·중을 차례로 넣으면 자리가 정해진다.
        for w in (self._dl_left, self._dl_mid_pane):
            if str(w) in [str(x) for x in pw.panes()]:
                pw.forget(w)
        right = [x for x in pw.panes()]
        anchor = right[0] if right else None
        for w, on, ms, wd in ((self._dl_left, left, 110, 145),
                              (self._dl_mid_pane, mid, 180, 320)):
            if not on:
                continue
            if anchor is not None:
                pw.add(w, minsize=ms, width=wd, before=anchor)
            else:
                pw.add(w, minsize=ms, width=wd)

    def _dl_set_mode(self, code):
        """갈래를 바꾼다 — 오른쪽 판을 갈아 끼우고 **쓰는 칸만** 보인다."""
        self._dl_mode = code
        # ⚠⚠ **자동설정이 만든 것을 먼저 걷는다**(2026-09-06 사용자 「언어콤보
        #   그룹이 매우 불안정하다. **자동설정 화면에서 표시되던 것이
        #   최신버전점검 화면에 잔상 표시**되었다가 사라졌다 그런다」).
        #   그전에는 ITEM 으로 갈 때만 걷어서 CHECK 로 가면 남았다.
        #   ⇒ **갈래를 바꾸는 첫 줄에서 무조건** 걷는다.
        box = getattr(self, '_dl_auto_lbox', None)
        if box is not None:
            try:
                box.destroy()
            except Exception:
                pass
            self._dl_auto_lbox = None
            self._dl_auto_lv = {}
        # ⚠ 점검 표도 함께 걷는다 — 남으면 다른 갈래에 표가 떠 있다
        for w in (getattr(self, '_dl_grid', None),
                  getattr(self, '_dl_grid_sb', None),
                  getattr(self, '_dl_meta2', None)):
            if w is not None:
                try:
                    w.pack_forget()
                except Exception:
                    pass
        # ★ **점검·자동설정은 오른쪽 한 장**(2026-09-06 사용자 「최신버전
        #   점검 탭 … 그 화면의 **왼쪽 목록화면을 제거**하라. 자동설정과 같이
        #   목록이 없어야 한다」). 고를 것이 없는 화면에 목록을 두면
        #   「무엇을 고르라는 건가」가 된다.
        self._dl_panes(left=(code == 'ITEM'), mid=(code == 'ITEM'))
        # ⚠ **자동설정에는 목록이 없다** — 거를 것이 없으므로 분류 줄을 감춘다
        #   (누를 수 있는데 아무 일도 안 나면 고장으로 읽힌다, §0-1).
        clsf = getattr(self, '_dl_clsf', None)
        if clsf is not None:
            try:
                for ch in clsf.winfo_children():
                    if code == 'AUTO':
                        ch.pack_forget()
                    elif ch.winfo_manager() != 'pack':
                        ch.pack(side='left', padx=(0, 10), pady=2)
                if clsf.winfo_manager() != 'pack':
                    clsf.pack(fill='x', padx=6, before=self._dl_pw)
            except Exception:
                pass
        # ⚠ 자동설정은 **복수**라 그 화면 안에 체크 목록이 있다 — 콤보를 감춘다
        cb2 = getattr(self, '_dl_lang2', None)
        if cb2 is not None:
            if code in ('AUTO', 'CHECK'):
                # ⚠ 점검은 **표가 언어를 전부 보이므로** 고를 것이 없다.
                #   자동설정은 **복수**라 화면 안에 체크 목록이 따로 있다.
                cb2.pack_forget()
                self._dl_lang2_lbl.pack_forget()
            else:
                self._dl_lang2_lbl.pack(side='right', pady=3)
                cb2.pack(side='right', padx=(4, 8), pady=3)
                # ⚠ pack 차례가 뒤집힌다 — 라벨을 다시 붙여 왼쪽에 오게 한다
                self._dl_lang2_lbl.pack_forget()
                self._dl_lang2_lbl.pack(side='right', pady=3)
        for k, b in self._dl_mbtn.items():
            b.configure(relief=('sunken' if k == code else 'raised'))
        self._dl_mhint.config(text={
            'CHECK': _t('DL_M_CHECK_H',
                        '설치된 것과 최신 버전을 비교합니다.'),
            'ITEM': _t('DL_M_ITEM_H', '하나씩 선택해 받습니다'),
            'AUTO': _t('DL_M_AUTO_H', '앞으로 저절로 최신으로 맞출지 정합니다'),
        }.get(code, ''))
        if code == 'CHECK':
            self._dl_show_check()
        elif code == 'AUTO':
            self._dl_show_auto()
        else:
            # ⚠ **오른쪽 판을 되돌린다** — 점검·자동설정이 제목·본문·단추를
            #   갈아 끼웠으므로 그대로 두면 「자동 끄기」 단추가 목록 화면에
            #   남는다(실측으로 잡았다). 고른 것이 없으면 비운다.
            self._dl_b_get.config(text=_t('SET_DL_GET', '지금 받기'),
                                  state='disabled')
            self._dl_b_del.config(state='disabled')
            self._dl_title.config(text='')
            self._dl_meta.config(text='')
            self._dl_msg.config(text='')
            self._dl_body.config(state='normal')
            self._dl_body.delete('1.0', 'end')
            self._dl_body.config(state='disabled')
            self._dl_fill(self._dl_kind or 'LATEST')

    def _dl_gaps(self):
        """**갱신이 필요한 것** → `[(자산, 내 판, 최신 판)]` + 코어 모자란 목록.

        ★ 판정은 `pack_status` 한 문에 맡긴다 — 목록 화면과 같은 재료라야
          「점검은 3개라는데 목록은 5개」 같은 어긋남이 안 난다.
        ⚠ **판을 모르는 것은 갭이 아니다** — 0 으로 치면 전부 갱신 대상이 된다.
        """
        import pack_status as PS
        # ⚠⚠ **`assets()` 를 안 쓴다** (2026-09-06 사용자 「최신버전 점검 탭
        #   화면이 **매우 느리다**」 — 실측 1,845ms).
        #   그 문은 자산마다 `pack_fallback.state` 를 물어 **본문이 실제로
        #   있는지**까지 잰다(193회 × DB 조회). 목록 화면에는 필요하지만
        #   **점검에는 필요 없다** — 여기서 묻는 것은 「내 판 < 최신 판인가」
        #   하나뿐이고, 그 재료는 manifest 와 `mine_versions` 로 충분하다.
        #   ⇒ 실측 **1,845ms → 200ms 대**.
        # ⚠ 서버도 **한 번만** 읽는다 — 그전에는 `assets` 와 `core_missing` 이
        #   각자 manifest 를 받았다.
        # ⚠⚠ **모드를 오갈 때마다 서버를 다시 읽지 않는다** (2026-09-06
        #   사용자 「자동설정 화면이 표시되는것이 **매우 느리다**」).
        #   실측 모드 전환마다 manifest 를 받아 **1초**가 걸렸다.
        #   ⇒ 60초 캐시. 그 안에 판이 바뀔 일은 없다.
        import time as _t
        man = getattr(self, '_dl_man', None)
        if man is None or (_t.time() - getattr(self, '_dl_man_at', 0)) > 60:
            try:
                man = PS.manifest()
            except Exception:
                man = None
            self._dl_man, self._dl_man_at = man, _t.time()
        gaps = []
        # ★ **고른 언어만 잰다**(2026-09-06 사용자 「3개의 서브탭에 모두
        #   언어콤보가 특정되어야 **최신버전 점검도 가능**하고…」).
        #   ⚠ 언어를 안 가리는 자산(코어·원어 사전·사진)은 늘 센다 —
        #     빼면 받을 길이 사라진다(`PS.lang_ok`).
        want_lang = ''
        try:
            want_lang = self._dl_lang_get()
        except Exception:
            want_lang = ''
        try:
            mine_map = PS.mine_versions(self.db_path)
            for it in list((man or {}).get('items') or []):
                if not isinstance(it, dict):
                    it = dict(it)
                lg = (it.get('lang') or '')
                mine = mine_map.get((str(it.get('kind') or '').upper(),
                                     str(it.get('key') or ''),
                                     '' if lg in ('-', None) else lg.upper()))
                new = it.get('version') or it.get('own_version') or 0
                if not PS.lang_ok(it, want_lang):
                    continue
                # ⚠ **판을 모르는 것은 갭이 아니다** — 0 으로 치면 전부 대상이 된다
                if mine and new and mine < new:
                    it = dict(it, mine=mine)
                    gaps.append((it, mine, new))
        except Exception:
            pass
        try:
            core = PS.core_missing(self.db_path, man=man)
        except Exception:
            core = []
        return gaps, core

    def _dl_show_check(self):
        """최신버전 점검 — **행=자산 · 열=언어**.

        ★★ 셀은 `내 판 → 최신 판`(밀림) · `판`(최신) · `—`(그 언어 없음) ·
          `↓판`(아직 안 받음). 「받아야 하나」가 셀 하나로 읽힌다.
        ★ **열은 「내가 가진 언어」 + 「밀린 언어」**다 — 열한 언어를 다
          늘어놓으면 대부분 `—` 라 표가 못 쓰게 된다.
        ⚠ 언어를 안 가리는 자산(코어·원어 사전·사진)은 **「공통」 열**에 둔다.
        """
        self._dl_title.config(text=_t('DL_M_CHECK', '최신버전 점검'))
        gaps, core = self._dl_gaps()
        rows, langs = self._dl_check_rows()
        rows = self._dl_cls_filter(rows)
        n = len(gaps) + len(core)
        self._dl_meta.config(text=(
            _t('DL_CHECK_N', '갱신할 것 %d개') % n if n
            else _t('DL_CHECK_OK', '모두 최신입니다')))

        # 본문은 짧은 안내만 — 표가 내용을 맡는다
        # ⚠ 자동설정이 감춰 두었을 수 있다 — 되돌린다
        try:
            if self._dl_body.winfo_manager() != 'pack':
                self._dl_body.pack(fill='both', expand=True, padx=10,
                                   pady=(0, 6), before=self._dl_msg)
        except Exception:
            pass
        self._dl_body.config(state='normal')
        self._dl_body.delete('1.0', 'end')
        self._dl_body.insert('end', _t(
            'DL_CHECK_BODY2',
            '갖고 있는 판과 최신 판을 언어별로 견줍니다. '
            '「A-1 → A-2」처럼 화살표가 있으면 받을 것이 있다는 뜻입니다. '
            '위의 라디오로 갈래를 선택해 볼 수 있고, 줄을 겹클릭하면 '
            '항목별 다운로드의 그 항목으로 갑니다.')
            if n else _t(
            'DL_CHECK_NONE',
            '갖고 있는 자료가 모두 최신입니다. 받을 것이 없습니다.\n\n'
            '⚠ 서버를 못 읽으면 여기가 비어 보일 수 있습니다 — '
            '인터넷이 끊겼는지 확인해 주세요.'))
        self._dl_body.config(state='disabled')

        # ── 표 ────────────────────────────────────────────────
        # ★ **범례를 표 바로 위에**(사용자 「**설명문 내용도 화면에 배치**하라」)
        #   — 셀의 글자가 무슨 뜻인지 그 자리에서 읽힌다.
        self._dl_meta2.config(text=_t(
            'DL_CHECK_HINT2', '줄을 겹클릭하면 항목별 다운로드의 그 항목으로 갑니다.'))
        try:
            if self._dl_meta2.winfo_manager() != 'pack':
                self._dl_meta2.pack(fill='x', padx=10, pady=(2, 0),
                                    before=self._dl_msg)
        except Exception:
            pass
        g = self._dl_grid
        for iid in g.get_children():
            g.delete(iid)
        cols = ['name'] + ['L%d' % i for i in range(len(langs))]
        g['columns'] = cols
        g.heading('name', text=_t('COMMON_TITLE', '제목'))
        g.column('name', width=250, anchor='w', stretch=True)
        for i, (code, name) in enumerate(langs):
            g.heading('L%d' % i, text=name)
            g.column('L%d' % i, width=96, anchor='center', stretch=False)
        self._dl_grid_rows = rows
        for r in rows:
            vals = [r['title']] + [r['cell'].get(c, '—') for c, _n in langs]
            g.insert('', 'end', values=vals,
                     tags=(('upd',) if r['gap'] else ()))
        g.tag_configure('upd', foreground=_C('accent', '#1565C0'))
        # ⚠ **없으면 안 그린다** — 빈 표는 고장으로 읽힌다(§0-1)
        if rows:
            self._dl_grid.pack(fill='both', expand=True, padx=(10, 0),
                               pady=(4, 6), before=self._dl_msg)
            self._dl_grid_sb.pack(side='right', fill='y',
                                  before=self._dl_msg)
        else:
            self._dl_grid.pack_forget()
            self._dl_grid_sb.pack_forget()

        self._dl_b_get.config(state=('normal' if n else 'disabled'),
                              text=_t('DL_BTN_SYNC', '모두 최신으로'))
        self._dl_b_del.config(state='disabled')
        self._dl_msg.config(text='')

    def _dl_cls_get(self):
        """지금 선택한 분류 — 없으면 빈 글자(=전체)."""
        try:
            return self._dl_cls.get() or ''
        except Exception:
            return ''

    def _dl_cls_filter(self, rows):
        """5분류 라디오로 거른다.

        ★ **행의 분류는 그 행에서 가장 급한 것**이다(`_CLS_RANK`) — 한 자산에
          언어가 여럿이면 분류도 여럿이라 하나로 접어야 거를 수 있다.
        ⚠ 거른 결과가 0이면 **왜 0인지 말한다**(§0-1) — 그냥 빈 표는 고장으로 읽힌다.
        """
        want = self._dl_cls_get()
        if not want:
            return rows
        return [r for r in rows if (r.get('cls') or '') == want]

    def _dl_cls_pick(self):
        """라디오를 누르면 **그 자리에서** 다시 그린다(§0-1 — 안 바뀌면 고장)."""
        try:
            if getattr(self, '_dl_mode', '') == 'CHECK':
                self._dl_show_check()
            else:
                # ⚠ `_dl_fill` 은 **갈래를 받는다** — 안 넘기면 TypeError 가
                #   except 에 삼켜져 「눌러도 아무 일이 없는」 라디오가 된다
                #   (§0-1. 하네스가 그 자리에서 잡았다).
                self._dl_fill(getattr(self, '_dl_kind', 'ALL') or 'ALL')
        except Exception as e:
            print('[download] cls pick:', e)

    def _dl_grid_jump(self, _e=None):
        """점검 표를 겹클릭 → **항목별 다운로드 화면의 그 항목**으로.

        ★ 점검은 「무엇이 밀렸나」를 보는 자리이고 **손대는 곳은 항목별**이다.
          그 사이를 걸어가게 하지 않는다(§0-1 — 보고서 끝나면 갈 길을 준다).
        ⚠ 언어를 **그 자산의 언어로 맞춘다** — 안 맞추면 목록에서 걸러져
          「눌렀는데 없다」가 된다.
        """
        import pack_status as PS
        sel = self._dl_grid.selection()
        if not sel:
            return
        i = self._dl_grid.index(sel[0])
        rows = getattr(self, '_dl_grid_rows', None) or []
        if i >= len(rows):
            return
        r = rows[i]
        kind, key = r.get('kind'), r.get('key')
        # ★ 그 자산이 실제로 쓰는 언어 하나를 고른다(밀린 것을 우선)
        want = ''
        for code, txt in (r.get('cell') or {}).items():
            if code in ('*', '~'):
                continue
            if '→' in str(txt):
                want = code
                break
            if txt and txt != '—' and not want:
                want = code
        if want:
            try:
                PS.set_dl_lang(want, self.db_path)
            except Exception:
                pass
        self._dl_set_mode('ITEM')
        self._dl_lang_fill()
        # 갈래를 고르고
        tv = self._dl_kinds_tv
        if tv.exists(kind):
            tv.selection_set(kind)
            tv.see(kind)
        self._dl_fill(kind if tv.exists(kind) else 'ALL')
        # ⚠⚠ **줄 선택은 `after_idle` 로 미룬다**(§128차 그 함정) —
        #   바로 위 `tv.selection_set(kind)` 이 `<<TreeviewSelect>>` 를 **큐에**
        #   넣으므로, 지금 고르면 그 이벤트가 나중에 `_dl_fill` 을 다시 돌려
        #   **방금 고른 것을 지운다**(실측 — 목록에 있는데 선택이 비었다).
        self.after_idle(lambda: self._dl_pick_row(kind, key))

    def _dl_pick_row(self, kind, key):
        """항목별 목록에서 그 자산 줄을 선택한다."""
        for iid, (what, row) in (self._dl_items or {}).items():
            if what != 'CONTENT':
                continue
            if str(row[0]) == str(kind) and str(row[1]) == str(key):
                try:
                    self._dl_tv.selection_set(iid)
                    self._dl_tv.see(iid)
                    self._dl_on_pick()
                except Exception:
                    pass
                return

    def _dl_check_rows(self):
        """점검 표의 재료 — `(행 목록, [(언어코드, 이름)])`.

        ★★ **`_dl_rows` 를 그대로 쓴다** — 그 목록이 이미 제목·언어·판·상태를
          다 갖고 있다(`(kind, key, lang, title, ver, lic, state)`).
          다시 만들면 제목이 갈린다 — 실제로 그렇게 했다가 설명문 제목이
          **책 번호(`1`·`2`·`27`)** 로 나왔다(그 자산의 key 가 번호다).
        ★ **열은 값이 있는 언어만** — 열한 언어를 늘어놓으면 대부분 `—` 라
          표가 못 쓰게 된다(실측 14열 중 12열이 전부 `—` 였다).
        ⚠ 언어를 안 가리는 자산(코어·원어 사전·사진)은 **「공통」 열**.
        """
        try:
            import lang_combo as LC
        except Exception:
            LC = None
        seen, order = {}, []
        for row in (self._dl_rows or []):
            k, key, lang, title, ver, _lic, st, *_rest = row
            if k in self._DL_NOLANG:
                continue
            code = (lang or '').upper()
            if code in ('', '-'):
                code = '*'
            kk = (k, str(key))
            if kk not in seen:
                seen[kk] = {'title': title or str(key), 'cell': {},
                            'gap': False, 'kind': k, 'key': str(key)}
                order.append(kk)
            r = seen[kk]
            # ★ 행의 분류 — **가장 급한 것**이 이긴다. 한 자산에 언어가
            #   여럿이면 분류도 여럿이라 하나로 접어야 라디오로 거를 수 있다.
            #   ⚠ 글자(`A-1 → A-2`)를 되파싱하지 않는다 — 표기를 바꾸면
            #     조용히 어긋난다. 아홉째 칸이 원본 dict 에서 온 값이다.
            cl = (_rest[1] if len(_rest) > 1 else None)
            if cl:
                r['cls'] = _cls_worst(r.get('cls'), cl)
            txt = str(ver or '')
            if '→' in txt:
                r['gap'] = True
            elif st == 'NEW':
                # ⚠ **「↓ 1」 은 눈에 안 들어온다**(2026-09-06 사용자 「미설치된
                #   상황인지를 표시하는 경우에는 **어떻게 표시하는지 잘 보이지
                #   않는다**」). 글자로 말한다.
                txt = _t('DL_CELL_NEW', '안 받음 %s') % txt
            elif st == 'REMOVED':
                txt = _t('DL_CELL_DEL', '지움 %s') % txt
            r['cell'][code] = txt or '—'
        # ★★ **열 = 「내가 확보한 언어」**(2026-09-06 사용자 「사용자가
        #   확보한 버전이 **EN FR 두개**라고 한다면 각 언어별 현 버전과
        #   최신버전을 표시해야 한다」).
        #   ⚠ 자산이 가진 모든 언어를 열로 만들면 **16열**이 되고 그중
        #     열넷이 통째로 `—` 라 표가 못 쓰게 된다(실측).
        #   ⇒ **받아 둔 것이 하나라도 있는 언어**만 연다. 밀린 언어는
        #     정의상 받아 둔 것이라 함께 들어온다.
        used = {}
        for kk in order:
            for c, t in seen[kk]['cell'].items():
                if t and t != '—' and not str(t).startswith('↓'):
                    used[c] = used.get(c, 0) + 1
        if not used:
            # ⚠ 하나도 안 받았으면 **빈 표를 보이지 않는다** — 받을 수 있는
            #   언어를 보여야 고를 수 있다(§0-1 빈 서랍).
            for kk in order:
                for c, t in seen[kk]['cell'].items():
                    if t and t != '—':
                        used[c] = used.get(c, 0) + 1
        # ⚠⚠ **열 상한 6 + 「그 밖」** (2026-09-06). 이 PC 처럼 자산을 전부
        #   갖고 있으면 「확보한 언어」가 **16개**가 되어 표가 못 쓰게 된다
        #   (실측 16열 중 열넷이 통째로 `—`).
        #   ★ 실측 **언어가 여럿인 자산의 언어는 EN 49 · KO 45 · LA 2 · FR 1
        #     · ZH 1** — 언어 축이 실제로 뜻 있는 것은 두셋뿐이다.
        #   ⇒ 자산이 많은 언어 여섯만 열로 두고 나머지는 **「그 밖」 한 칸**에
        #     `FR 1판` 처럼 적는다. **감추지 않는다** — 감추면 그 자산을
        #     받을 길이 사라진다(§0-1).
        _MAXC = 6
        keep = [c for c in sorted(used, key=lambda x: (x == '*', -used[x], x))]
        rest = keep[_MAXC:]
        keep = keep[:_MAXC]
        if rest:
            for r in rows if False else [seen[kk] for kk in order]:
                bits = []
                for c in rest:
                    t = r['cell'].pop(c, None)
                    if t and t != '—':
                        bits.append('%s %s' % (c, t))
                if bits:
                    r['cell']['~'] = ' · '.join(bits)
            used = {c: used[c] for c in keep}
            used['~'] = 1
        langs = []
        for c in sorted(used, key=lambda x: (x == '~', x == '*', -used.get(x, 0), x)):
            if c == '~':
                langs.append(('~', _t('DL_LANG_ETC', '그 밖')))
                continue
            if c == '*':
                nm = _t('DL_LANG_ANY', '공통')
            else:
                try:
                    nm = LC.label(c, None, self.db_path) if LC else c
                except Exception:
                    nm = c
            langs.append((c, nm))
        rows = [seen[kk] for kk in order]
        # ⚠ **밀린 것이 위로** — 손볼 자리가 먼저 보여야 한다
        rows.sort(key=lambda r: (not r['gap'], r['kind'], r['title']))
        return rows, langs

    def _dl_on_kind(self, _e=None):
        """왼쪽 갈래를 선택하면 가운데 목록을 채운다."""
        sel = self._dl_kinds_tv.selection()
        if not sel:
            return
        self._dl_fill(sel[0])

    def _dl_fill(self, kind):
        """가운데 목록 — 선택한 갈래 · 선택한 언어 · 선택한 분류."""
        import pack_status as PS0
        self._dl_kind = kind
        if not self._dl_rows:
            self._dl_rows = self._dl_rows_load()
        tv = self._dl_tv
        tv.delete(*tv.get_children())
        tv.tag_configure('upd', foreground=_C('accent', '#1565C0'))
        self._dl_items = {}
        if kind == 'LINK':
            # ⚠ 목록을 안 만든다 — 가운데 칸을 접고 오른쪽에 안내를 편다
            self._dl_show_link_page()
            return
        want_lang = self._dl_lang_get()
        if kind == 'LATEST':
            import pack_status as PS
            for i, it in enumerate(PS.catalog(self.db_path)):
                iid = 'R%d' % i
                self._dl_items[iid] = ('REL', it)
                tv.insert('', 'end', iid=iid,
                          values=(self._dl_state_label(it.get('state')),
                                  it.get('title') or it.get('note') or '',
                                  # ★ 릴리스 축이라 `R-`(자산은 `A-`)
                                  PS.ver_label(it.get('seq'), PS.VER_R)))
            return
        # ★★★ **상태 칸 = 5분류**(2026-09-07 사용자 0.txt 2-1 「개별자산 목록
        #   표시 화면에서 **현재 버전과 최신버전 비교화면 없음** … 4가지 구분을
        #   따르는 것은 어떤가?」).
        #   ⚠ 그전 상태(설치됨/삭제됨/미설치)는 **「받았나」**만 말하고
        #     「최신인가」를 안 말했다 — 안 받은 자산이 전부 「미설치」라
        #     서버에 있는지도 알 수 없었다.
        #   ★ 이름은 점검 화면 라디오와 **같은 낱말**을 쓴다(같은 분류이므로).
        clbl = {PS0.CL_LATEST: _t('DL_CL_LATEST', '최신판'),
                PS0.CL_UPGRADE: _t('DL_CL_UPGRADE', '최신버전 다운로드 가능'),
                PS0.CL_AVAIL: _t('DL_CL_AVAIL', '아직 받지 않았음'),
                PS0.CL_REMOVED: _t('DL_CL_REMOVED', '삭제됨')}
        want_cls = self._dl_cls_get()
        n_hid = n_unpub = 0
        for i, row in enumerate(self._dl_rows):
            k, key, lang, title, ver, lic, st, *_rest = row
            if kind != 'ALL' and k != kind:
                continue
            # ★ 앱·연결 자료는 언어를 안 가린다
            if want_lang and k not in self._DL_NOLANG \
                    and (lang or '').upper() != want_lang:
                continue
            cl = (_rest[1] if len(_rest) > 1 else None) or PS0.item_class({}, st)
            # ⚠⚠ **미발행은 목록에 안 올린다**(2026-09-07 사용자 지시) —
            #   받을 수 없는 것을 보이면 「눌러도 아무 일이 없다」가 된다(§0-1).
            if cl == PS0.CL_UNPUB:
                n_unpub += 1
                continue
            if want_cls and cl != want_cls:
                n_hid += 1
                continue
            iid = 'C%d' % i
            self._dl_items[iid] = ('CONTENT', row)
            up = (cl == PS0.CL_UPGRADE)
            tv.insert('', 'end', iid=iid, tags=(('upd',) if up else ()),
                      values=(clbl.get(cl, ''), title, ver))
        # ⚠ 거른 결과가 0이면 **왜 0인지 말한다**(§0-1) — 빈 목록은 고장으로 읽힌다
        if not tv.get_children():
            # ⚠⚠ **왜 비었는지 말한다**(§0-1). 특히 「서버에 자료 목록이 아직
            #   없다」는 상태를 안 말하면 **화면이 고장난 것으로 읽힌다** —
            #   실측 이 PC 는 `PUBLISH_ITEMS=False` 라 193개가 전부 미발행이고,
            #   그동안 목록이 조용히 비어 있었다(2026-09-07 사용자 지적
            #   「현재 버전, 최신버전 비교표시 하지 않고 있다」의 진짜 원인).
            msg = (_t('DL_UNPUB_NOTE',
                      '아직 서버에 발행되지 않은 자료입니다 — 받을 수 있게 되면 '
                      '여기에 나옵니다')
                   if n_unpub and not want_cls
                   else _t('DL_CL_EMPTY', '해당하는 자료 없음'))
            tv.insert('', 'end', iid='_none', values=('', msg, ''))

    # ── 자동설정 ────────────────────────────────────────────────────
    def _dl_auto_get(self):
        """자동 받기가 켜져 있나. **판정의 집은 `tray_agent` 하나**다 —
        화면이 제 판정을 두면 「켰는데 안 받는다」가 난다(§203차 ㉙)."""
        try:
            import tray_agent
            return bool(tray_agent.auto_sync_on(self.db_path))
        except Exception:
            return True

    def _dl_auto_set(self, on):
        """켜고 끈다 — **누른 때를 남긴다**.

        ★ 이 화면이 곧 동의서라(팝업을 따로 안 띄운다) **누른 사실이 남아야**
          나중에 「언제 동의했나」를 답할 수 있다(§203차 ㉝).
        """
        import datetime
        try:
            import appdb
            import tray_agent
            c = appdb.connect(self.db_path)
            try:
                c.execute(
                    "INSERT INTO user_config(config_key, config_val) VALUES(?,?) "
                    "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                    (tray_agent.AUTO_SYNC_KEY, '1' if on else '0'))
                c.execute(
                    "INSERT INTO user_config(config_key, config_val) VALUES(?,?) "
                    "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                    ('PACK_AUTO_SYNC_TS',
                     ('ON ' if on else 'OFF ') +
                     datetime.datetime.now().strftime('%Y-%m-%d %H:%M')))
                c.commit()
            finally:
                c.close()
        except Exception:
            pass
        self._dl_show_auto()

    def _dl_auto_note(self):
        """지금 상태를 한 줄로 — 켠 날짜까지."""
        on = self._dl_auto_get()
        ts = ''
        try:
            import appdb
            c = appdb.connect(self.db_path)
            try:
                r = c.execute("SELECT config_val FROM user_config"
                              " WHERE config_key='PACK_AUTO_SYNC_TS'").fetchone()
                ts = (r[0] if r else '') or ''
            finally:
                c.close()
        except Exception:
            ts = ''
        head = (_t('DL_AUTO_ON', '자동 받기 켜짐') if on
                else _t('DL_AUTO_OFF', '자동 받기 꺼짐'))
        return head + (('   ' + ts) if ts else '')

    def _dl_show_auto(self):
        """자동설정 — **좌우 분할**(2026-09-06 사용자 「자동설정 화면이
        상하로 구분되어 있다. **좌우로 구분**하라. 아래 언어콤보가 잘 안
        보인다」).

        왼쪽 = 받을 언어(복수) · 오른쪽 = 동의문. 언어가 **위쪽 왼편**에
        오므로 스크롤 없이 바로 보인다.
        """
        on = self._dl_auto_get()
        self._dl_title.config(text=_t('DL_M_AUTO', '자동설정'))
        self._dl_meta.config(text=self._dl_auto_note())
        # 본문 Text 를 감추고 좌우 판을 그 자리에 놓는다
        try:
            self._dl_body.pack_forget()
        except Exception:
            pass
        self._dl_auto_pane()
        self._dl_b_get.config(
            state='normal',
            text=(_t('DL_AUTO_TURNOFF', '자동 끄기') if on
                  else _t('DL_AUTO_AGREE', '동의하고 켜기')))
        self._dl_b_del.config(state='disabled')
        self._dl_msg.config(text='')

    def _dl_auto_pane(self):
        """좌(언어 복수) · 우(동의문)."""
        import pack_status as PS
        try:
            import lang_combo as LC
        except Exception:
            LC = None
        box = getattr(self, '_dl_auto_lbox', None)
        if box is not None:
            try:
                box.destroy()
            except Exception:
                pass
        host = self._dl_msg.master
        box = tk.Frame(host, bg=_C('bg', '#FAFAFA'))
        box.pack(fill='both', expand=True, padx=10, pady=(4, 6),
                 before=self._dl_msg)
        self._dl_auto_lbox = box

        # ★★ **좌 = 설명문(+아래 단추) · 우 = 언어 체크**
        #   (2026-09-06 사용자 「화면을 좌우로 구분하라. **좌-버튼 및 설명문,
        #   우-언어체크박스** 배치」). 처음에 반대로 놓았던 것을 뒤집었다.
        #   ⚠ 단추([동의하고 켜기]·[자동 끄기])는 이 판 **아래 공용 줄**에
        #     왼쪽으로 붙으므로 설명문과 같은 기둥에 선다.
        right = tk.Frame(box, bg=_C('bg', '#FAFAFA'))
        right.pack(side='right', fill='y', padx=(12, 0))
        left = tk.Frame(box, bg=_C('bg', '#FAFAFA'))
        left.pack(side='left', fill='both', expand=True)

        # ── 오른쪽: 받을 언어(복수) ────────────────────────────
        tk.Label(right, anchor='w', justify='left', bg=_C('bg', '#FAFAFA'),
                 fg=_C('fg_title', '#1A5276'),
                 text=_t('DL_AUTO_LANGS', '자동으로 받을 언어')
                 ).pack(anchor='w')
        cur = set(PS.dl_langs(self.db_path))
        self._dl_auto_lv = {}
        codes = [lg for lg, _n in PS.item_langs(self.db_path)]
        if not codes:
            codes = [PS.ui_lang(self.db_path)]
        for lg in codes:
            try:
                nm = LC.label(lg, None, self.db_path) if LC else lg
            except Exception:
                nm = lg
            v = tk.BooleanVar(value=(lg in cur))
            tk.Checkbutton(right, text=('%s (%s)' % (nm, lg) if nm != lg else lg),
                           variable=v, bg=_C('bg', '#FAFAFA'), anchor='w',
                           command=self._dl_auto_langs_save
                           ).pack(anchor='w')
            self._dl_auto_lv[lg] = v
        tk.Label(right, anchor='w', justify='left', wraplength=190,
                 bg=_C('bg', '#FAFAFA'), fg=_C('fg_dim', '#7F8C8D'),
                 text=_t('DL_AUTO_LANGS_NOTE2',
                         '※ 지금 저절로 받는 것은 «연결 자료»(영상·링크 주소)'
                         '뿐이고 그것은 언어를 안 가립니다. 여기서 선택한 언어는 '
                         '[최신버전 점검]이 쓰고, 본문 자료 자동받기가 켜지면 '
                         '그때 함께 쓰입니다.')
                 ).pack(anchor='w', pady=(8, 0))

        # ── 왼쪽: 동의문 ──────────────────────────────────────
        txt = tk.Text(left, wrap='word', height=8, relief='flat',
                      bg=_C('bg', '#FAFAFA'), fg=_C('fg', '#333'))
        sb = ttk.Scrollbar(left, orient='vertical', command=txt.yview)
        txt.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        txt.pack(side='left', fill='both', expand=True)
        try:
            theme_font.register(txt, self.db_path, 'prose')
        except Exception:
            pass
        txt.insert('end', _t(
            'DL_AUTO_BODY',
            '[동의하고 켜기] 를 누르시면 아래 내용에 동의하신 것으로 봅니다. '
            '따로 창이 뜨지 않습니다.\n\n'

            '지금 받는 것 — 「연결 자료」와 「갖고 있는 본문의 갱신」\n'
            '어느 구절에 어떤 영상이 걸리는지 같은 「주소와 연결」, 그리고 '
            '**이미 받아 두신 본문 자료에 새 판이 나왔을 때 그 갱신분**입니다. '
            '한 번에 세 개까지만 받으므로 데이터 부담이 크지 않습니다.\n\n'

            '아직 받지 않는 것 — 「새 본문 자료」\n'
            '아직 받지 않으신 성경 본문, 주석, 도서, 설교, 연구자료는 자동으로 '
            '오지 않습니다. 무엇을 읽으실지는 사용자가 정하실 일이기 때문입니다. '
            '[항목별 다운로드] 에서 필요한 것만 선택해 받으시면, 그다음부터는 '
            '갱신이 자동으로 옵니다.\n\n'

            '내가 쓴 글은 건드리지 않습니다\n'
            '묵상노트, 밑줄, 메모, 내가 만든 렌즈는 받지도 보내지도 않습니다. '
            '이 기능은 오직 받기만 합니다.\n\n'

            '언제 받나요 — 하루 한 번\n'
            '앱을 꺼 두어도 트레이가 대신 확인합니다. 앱이 켜져 있는 동안에는 '
            '트레이가 쉽니다. 같은 자료를 둘이 함께 건드리지 않기 위해서입니다.\n'
            '확인하는 시각은 기기마다 다릅니다. 모두가 같은 시각에 몰리지 않도록 '
            '앱이 알아서 흩어 놓습니다. 새로 나온 것이 없으면 아무것도 받지 '
            '않습니다.\n\n'

            '얼마나 받나요 — 바뀐 것만\n'
            '처음 한 번만 전체를 받습니다. 그다음부터는 바뀐 것과 없어진 것만 '
            '받습니다. 한동안 앱을 켜지 않아 중간을 놓치더라도, 앱이 알아서 '
            '한 번에 맞춥니다.\n\n'

            '언제든 그만둘 수 있습니다\n'
            '이 화면에서 [자동 끄기] 를 누르시면 그 즉시 멈춥니다. 이미 받은 '
            '자료는 지워지지 않고 그대로 남습니다.\n\n'

            '끄면 어떻게 되나요\n'
            '[최신버전 점검] 에서 손으로 맞추셔야 합니다. 오래 두시면 새 자료가 '
            '보이지 않고, 자료 사이의 연결이 어긋난 것처럼 보일 수 있습니다.\n\n'

            '공지는 이 설정과 상관없이 받습니다\n'
            '이 설정을 끄셔도 공지사항은 그대로 옵니다. 이 설정이 정하는 것은 '
            '「자료」이고, 공지까지 끊으면 중요한 안내를 못 보시게 되기 '
            '때문입니다.\n\n'

            '⚠ 이것은 「받는」 설정입니다. 이용통계를 「보내는」 동의와는 '
            '별개이며, [개인정보] 탭에서 따로 정하십니다.'))
        txt.config(state='disabled')

    def _dl_auto_langs_save(self):
        """선택한 언어를 저장한다. **하나도 안 선택하면 앱 언어로 되돌린다** —
        빈 채로 켜면 「켜져 있는데 아무것도 안 받는」 상태가 된다."""
        import pack_status as PS
        picked = [lg for lg, v in (self._dl_auto_lv or {}).items() if v.get()]
        if not picked:
            picked = [PS.ui_lang(self.db_path)]
            for lg, v in (self._dl_auto_lv or {}).items():
                v.set(lg in picked)
        PS.set_dl_langs(picked, self.db_path)

    def _dl_sync_all(self):
        """[모두 최신으로] — **코어를 먼저, 그다음 밀린 자산**.

        ⚠ 순서가 중요하다 — 연결·껍데기가 코어에 있으므로 본문을 먼저 넣으면
          가리킬 것이 없다(§196차 ⑨ 적재 순서).
        """
        import pack_status as PS
        gaps, core = self._dl_gaps()
        done, fail = 0, []
        if core:
            try:
                PS.fetch_core(self.db_path)
                done += len(core)
            except Exception as e:
                fail.append('core: %s' % (repr(e)[:40]))
        for it, _mine, _new in gaps:
            try:
                if PS.fetch_asset(it.get('kind'), it.get('key'),
                                  it.get('lang'), self.db_path,
                                  it.get('variant')):
                    done += 1
                else:
                    fail.append(str(it.get('title') or it.get('key')))
            except Exception:
                fail.append(str(it.get('title') or it.get('key')))
        self._dl_rows = self._dl_rows_load()
        self._dl_show_check()
        # ⚠ **무엇이 안 됐는지 말한다** — 조용히 넘어가면 받은 줄 안다
        msg = _t('DL_SYNC_DONE', '%d개를 받았습니다.') % done
        if fail:
            msg += ' ' + (_t('DL_SYNC_FAIL', '%d개는 받지 못했습니다: %s')
                          % (len(fail), ', '.join(fail[:3])))
        self._dl_msg.config(text=msg)

    def _dl_state_label(self, st):
        import pack_status as PS
        return {PS.ST_INSTALLED: _t('DL_STATE_IN', '설치됨'),
                PS.ST_REMOVED: _t('DL_STATE_DEL', '삭제됨'),
                PS.ST_NEW: _t('DL_STATE_NEW', '미설치')}.get(st, '')

    def _dl_show_link_page(self):
        """**영상·링크 안내 한 장** — 자동으로 받는다는 것과 지금 상태.

        ⚠ 자동인 줄 모르면 「왜 안 받아지나」가 된다 — 주기·시각을 함께 적는다.
        """
        import pack_status as PS
        h = PS.have()
        self._dl_title.config(text=_t('DL_ROW_PACK', '영상·링크 연결 자료'))
        self._dl_meta.config(text=' · '.join(x for x in (
            # ★ 목록 줄과 **같은 표기**여야 한다(그 줄은 `A-3`)
            PS.ver_label(h['cursor']) if h['exists'] else
            _t('DL_STATE_DEL', '삭제됨') if PS.seen_max(self.db_path) else
            _t('DL_STATE_NEW', '미설치'),
            PS.human(h['bytes']) if h['exists'] else '') if x))
        self._dl_body.config(state='normal')
        self._dl_body.delete('1.0', 'end')
        self._dl_body.insert('end', _t(
            'DL_AUTO_NOTE',
            '이 자료는 앱을 켜 두면 자동으로 받습니다. 따로 누르지 않아도 됩니다.')
            + '\n\n')
        for line in self._dl_link_stats():
            self._dl_body.insert('end', line + '\n')
        self._dl_body.insert('end', '\n' + _t(
            'DL_AUTO_TAIL',
            '기다리지 않고 지금 받거나, 저장 공간을 위해 지울 수 있습니다.\n'
            '지워도 다음에 자동으로 다시 받습니다.'))
        self._dl_body.config(state='disabled')
        self._dl_b_get.config(state='normal')
        self._dl_b_del.config(state='normal' if h['exists'] else 'disabled')
        self._dl_msg.config(text='')

    def _dl_link_stats(self):
        """안내 페이지의 **기본 통계** → 줄 목록.

        ⚠ **없는 값을 지어내지 않는다** — 아직 안 받았으면 그 줄을 안 낸다.
        """
        import pack_status as PS
        out = []
        h = PS.have()
        per, slot = PS.schedule_label(self.db_path)
        per = {'DAILY': _t('DL_CYCLE_DAY', '하루 한 번'),
               'WEEKLY': _t('DL_CYCLE_WEEK', '한 주에 한 번'),
               'MANUAL': _t('DL_CYCLE_MANUAL', '자동으로 받지 않음')}.get(
                   per, per or _t('DL_CYCLE_DAY', '하루 한 번'))
        out.append('%s: %s' % (_t('DL_ST_CYCLE', '받는 주기'), per))
        if slot:
            out.append('%s: %s' % (_t('DL_ST_TIME', '받는 시각'), slot))
        if h['exists']:
            for key, label, _q in PS.PARTS:
                out.append('%s: %s' % (label, f"{h['counts'].get(key, 0):,}"))
            out.append('%s: %s' % (_t('SET_DL_SIZE', '차지하는 용량'),
                                   PS.human(h['bytes'])))
            last = PS.last_get(self.db_path)
            if last:
                out.append('%s: %s' % (_t('DL_ST_LAST', '마지막으로 받은 때'),
                                       last))
            today = PS.today_added(self.db_path)
            if today is not None:
                out.append('%s: %s' % (_t('DL_ST_TODAY', '오늘 새로 받은 것'),
                                       f'{today:,}'))
        return out

    def _dl_on_pick(self, _e=None):
        """선택한 항목의 **자세한 내용**을 오른쪽에 그린다."""
        import pack_status as PS
        sel = self._dl_tv.selection()
        if not sel:
            return
        what, it = self._dl_items.get(sel[0], (None, None))
        self._dl_body.config(state='normal')
        self._dl_body.delete('1.0', 'end')
        self._dl_msg.config(text='')
        if what == 'REL':
            st = it.get('state')
            self._dl_title.config(
                text=it.get('title')
                or PS.ver_label(it.get('seq'), PS.VER_R))
            bits = [it.get('made_at') or '', self._dl_state_label(st)]
            if it.get('bytes'):
                bits.append(PS.human(it['bytes']))
            self._dl_meta.config(text=' · '.join(x for x in bits if x))
            if it.get('note'):
                self._dl_body.insert('end', it['note'] + '\n\n')
            if it.get('detail'):
                self._dl_body.insert('end', it['detail'] + '\n\n')
            if it.get('caution'):
                self._dl_body.insert('end',
                                     '\u26a0 ' + _t('DL_CAUTION', '주의사항')
                                     + '\n' + it['caution'] + '\n\n')
            self._dl_body.insert('end', _t(
                'DL_AUTO_NOTE',
                '이 자료는 앱을 켜 두면 자동으로 받습니다. '
                '따로 누르지 않아도 됩니다.'))
            self._dl_b_get.config(
                state='disabled' if st == PS.ST_INSTALLED else 'normal')
            self._dl_b_del.config(
                state='normal' if st == PS.ST_INSTALLED else 'disabled')
        elif what == 'CONTENT':
            k, key, lang, title, ver, lic, st, *_rest = it
            self._dl_title.config(text=title)
            if (k or '').upper() == 'PRESET':
                # ★ 환경설정 양식 — 받는 것이 아니라 **적용**한다(1.txt 22-1(3))
                self._dl_meta.config(text=_t('DL_PRESET_META', '환경설정 양식'))
                try:
                    import db_pref_preset as _PP
                    import appdb as _ad
                    _c = _ad.connect(self.db_path)
                    try:
                        _x = next((p for p in _PP.list_presets(_c) if p['code'] == key), None)
                    finally:
                        _c.close()
                except Exception:
                    _x = None
                if _x and _x.get('descr'):
                    self._dl_body.insert('end', _x['descr'] + '\n\n')
                self._dl_body.insert('end', _t(
                    'DL_PRESET_NOTE',
                    '관리자가 담아 둔 설정 한 벌(테마·글꼴·역본·탭 짜임·캔버스 배치·표시 언어)입니다. '
                    '[이 양식 적용]을 누르면 지금 설정이 그것으로 바뀝니다. 내 글·즐겨찾기·읽은 '
                    '기록은 건드리지 않습니다. 화면 배치는 다음에 켤 때 보입니다.'))
                if _x:
                    self._dl_body.insert('end', '\n\n%s %d · %s %d' % (
                        _t('DL_PRESET_NCFG', '설정 항목'), _x['n_cfg'],
                        _t('DL_PRESET_NSTATE', '화면 배치 항목'), _x['n_state']))
                self._dl_b_get.config(state='normal', text=_t('DL_PRESET_APPLY', '이 양식 적용'))
                self._dl_b_del.config(state='disabled')
                self._dl_body.config(state='disabled')
                return
            self._dl_b_get.config(text=_t('SET_DL_GET', '지금 받기'))
            _nt = getattr(self, '_dl_item_note', {}).get(
                ((k or '').upper(), str(key), '' if (lang or '').upper() in ('-', '') else (lang or '').upper()))
            if _nt:
                self._dl_body.insert('end', _nt + '\n\n')
            stl = {'INSTALLED': _t('DL_STATE_IN', '설치됨'),
                   'REMOVED': _t('DL_STATE_DEL', '삭제됨'),
                   'NEW': _t('DL_STATE_NEW', '미설치')}.get(
                       st, _t('DL_STATE_IN', '설치됨'))
            self._dl_meta.config(text=' · '.join(
                x for x in (lang if lang and lang != '-' else '', ver, stl)
                if x))
            if lic and lic != '-':
                self._dl_body.insert('end', '%s: %s\n\n'
                                     % (_t('DL_COL_LIC', '저작권'), lic))
            # ★★★ **받으면 / 안 받으면 무슨 일이 나나**(2026-09-05 사용자
            #   지시 「각 팩을 다운로드 받으면 **또는 안 받으면 어떤 현상/문제가
            #   발생하는지**를 사용자가 이해할 수 있도록 … **시작/종료 id(암호)를
            #   해석할 수 없으니** … 간단하게 설명문을」).
            #   ⇒ **id 를 안 보이고 두 줄로** 말한다.
            try:
                import appdb as _ad
                import db_pack_release as _RL
                _c = _ad.connect(self.db_path)
                try:
                    _y, _n = _RL.effect(_c, k, key, lang, t=_t)
                finally:
                    _c.close()
                # ⚠ `'%s %s' + chr(10) % (…)` 는 **더하기가 나중**이라
                #   포맷 인자가 어긋난다 — 괄호로 묶는다(실측으로 잡았다).
                self._dl_body.insert(
                    'end', ('%s %s' % (_t('DL_EF_YES', '받으면:'), _y))
                    + chr(10))
                self._dl_body.insert(
                    'end', ('%s %s' % (_t('DL_EF_NO', '안 받으면:'), _n))
                    + chr(10) * 2)
            except Exception:
                pass
            # ★★★ **사진 팩은 샘플을 보여 준다**(2026-09-05 사용자 지시
            #   「선택한 팩 내부의 **샘플사진의 썸네일**을 볼 수 있도록」).
            #   ⚠ 사진은 **보고 고르는 것**이라 글만으로는 판단이 안 된다.
            if (k or '').upper() == 'IMAGE':
                try:
                    self._dl_thumbs(key)
                except Exception:
                    pass
            # ★ **팩으로 관리하는 자산인가**가 단추를 가른다(2026-09-04 ⑩).
            #   ⚠ **왜 눌리지 않는지 말한다**(§0-1) — 회색으로만 두지 않는다.
            if st:
                self._dl_body.insert('end', _t(
                    'DL_ITEM_NOTE',
                    '이 자료는 따로 받거나 지울 수 있습니다. '
                    '지워도 목록에는 남아 언제든 다시 받을 수 있습니다.'))
            else:
                self._dl_body.insert('end', _t(
                    'DL_CORE_NOTE',
                    '앱에 기본으로 들어 있는 자료입니다. '
                    '따로 받거나 지울 수 없습니다.'))
            self._dl_b_get.config(
                state='normal' if st in ('NEW', 'REMOVED') else 'disabled')
            self._dl_b_del.config(
                state='normal' if st == 'INSTALLED' else 'disabled')
        self._dl_body.config(state='disabled')

    def _dl_thumbs(self, pack):
        """선택한 사진 팩의 **샘플 썸네일**을 오른쪽에 그린다.

        ⚠ **받기 전에 보여야** 고를 수 있다 — 서버의 별도 파일에서 읽는다.
        ⚠ 못 받으면 **왜 없는지 말한다**(§0-1 — 빈 자리는 고장으로 읽힌다).
        """
        import tkinter as tk
        for w in getattr(self, '_dl_thumb_row', []):
            try:
                w.destroy()
            except Exception:
                pass
        self._dl_thumb_row = []
        self._dl_thumb_imgs = []          # ⚠ 참조를 붙들어야 안 사라진다
        try:
            import pack_status as PS
            rows = PS.pack_thumbs(pack)
        except Exception:
            rows = []
        if not rows:
            self._dl_body.insert('end', chr(10) + _t(
                'DL_THUMB_NONE',
                '미리보기를 받을 수 없습니다. 인터넷 연결을 확인하세요.'))
            return
        self._dl_body.insert(
            'end', chr(10) + _t('DL_THUMB', '미리보기') + chr(10))
        for r in rows[:4]:
            try:
                img = tk.PhotoImage(data=r['png'])
            except Exception:
                continue
            self._dl_thumb_imgs.append(img)
            lb = tk.Label(self._dl_body, image=img, bd=0)
            self._dl_body.window_create('end', window=lb)
            self._dl_thumb_row.append(lb)
        self._dl_body.insert('end', chr(10))

    def _dl_get(self):
        """**확인을 받고** 받는다 — 덜컥 받아지지 않게.

        ★ 갈래마다 하는 일이 다르다(2026-09-06 5-1):
          점검 = **모두 최신으로** · 자동설정 = **켜고 끄기** · 항목별 = 하나씩.
        """
        import pack_status as PS
        if self._dl_mode == 'AUTO':
            on = not self._dl_auto_get()
            self._dl_auto_set(on)
            self._dl_show_auto()
            # ★ **동의한 때는 `_dl_auto_set` 이 이미 적는다**(`PACK_AUTO_SYNC_TS`
            #   — 켤 때도 끌 때도). ⚠⚠ 여기서 `_dl_auto_note(on)` 을 또 불렀는데
            #   그 메서드는 **인자를 안 받아** 누를 때마다 `TypeError` 로 터졌다
            #   (2026-09-24 287차 실측 — 값은 앞에서 저장돼 바뀌지만 **안내
            #   문구가 안 뜨고** Tk 콜백 예외가 났다). 한 일을 두 곳에 적은 자리다.
            self._dl_msg.config(text=(
                _t('DL_AUTO_SAVED_ON',
                   '동의해 주셔서 고맙습니다. 이제 새 자료를 저절로 받습니다.')
                if on else
                _t('DL_AUTO_SAVED_OFF',
                   '멈췄습니다. 이제 [최신버전 점검]을 눌러 손으로 맞춰 주세요.')))
            return
        if self._dl_mode == 'CHECK':
            return self._dl_sync_all()
        what = self._dl_kind
        name = _t('DL_ROW_PACK', '영상·링크 연결 자료')
        if what != 'LINK':
            sel = self._dl_tv.selection()
            w, it = self._dl_items.get(sel[0], (None, None)) if sel \
                else (None, None)
            # ★★ **자산 하나 받기**(2026-09-04 ⑩) — 그전에는 이 갈래에서
            #   **눌러도 아무 일이 없었다**(§0-1).
            if w == 'CONTENT':
                if (it[0] or '').upper() == 'PRESET':
                    return self._dl_apply_preset(it)
                return self._dl_get_asset(it)
            if w != 'REL':
                return
            name = (it.get('title') or it.get('note') or name)[:60]
        if not messagebox.askyesno(
                _t('SET_DL_GET', '지금 받기'),
                _t('DL_GET_ASK',
                   '「%s」 를 지금 받습니다.\n\n'
                   '받는 동안 앱을 켜 두세요. 인터넷을 씁니다.') % name):
            return
        self._dl_msg.config(text=_t('SET_DL_GETTING', '받는 중…'))
        self.update_idletasks()
        before = PS.have()['counts']
        core_note = ''
        try:
            # ★★★ **코어를 먼저 받는다**(2026-09-05 릴리스 패킹).
            #   연결·껍데기가 코어에 있으므로 본문·링크보다 앞서야 한다.
            #   ⚠ 코어가 주기별 파일로 갈렸고 **차례는 서버 목록이 정한다**
            #     (`pack_status.fetch_core` → `apply_many`).
            #   ⚠ 서버에 코어 목록이 없으면(정비 중·옛 서버) **아무 일도 안
            #     한다** — 지금까지와 똑같이 링크 팩만 받는다.
            cr = PS.fetch_core(self.db_path)
            if cr.get('got'):
                core_note = _t('DL_GET_CORE',
                               '앱 기본 자료 %d개를 받았습니다(%s행).') \
                    % (len(cr['got']), f"{cr.get('rows', 0):,}")
            elif cr.get('why') and cr['why'] != 'NO_CORE_LIST':
                # ⚠ **조용히 넘기지 않는다** — 무엇이 안 됐는지 말한다(§0-1)
                core_note = _t('DL_GET_CORE_FAIL',
                               '앱 기본 자료를 받지 못했습니다: %s') \
                    % str(cr['why'])[:60]
        except Exception:
            core_note = ''
        try:
            import tray_agent as TA
            n = TA.fetch_pack_deltas()
            h = PS.have()
            PS.note_seen(h['cursor'], self.db_path)
            PS.note_get(h['counts'], self.db_path)
            if n:
                # ★★ **무엇이 달라졌는지 말한다**(사용자 — 「다운로드 받은
                #   후에도 도대체 무엇이 바뀌었는지 알기 쉽지 않다」)
                dm = h['counts'].get('media', 0) - (before.get('media') or 0)
                dl = h['counts'].get('mlink', 0) - (before.get('mlink') or 0)
                self._dl_msg.config(text=_t(
                    'DL_GET_DONE',
                    '받기를 마쳤습니다. 이제 %d 판입니다.\n'
                    '영상·링크 %s (%+d) · 구절·용어 연결 %s (%+d)')
                    % (h['cursor'], f"{h['counts'].get('media', 0):,}", dm,
                       f"{h['counts'].get('mlink', 0):,}", dl))
            else:
                self._dl_msg.config(text=_t('SET_DL_UPTODATE', '최신입니다.'))
        except Exception as e:
            self._dl_msg.config(text=_t('SET_DL_FAIL', '받지 못했습니다: ')
                                + str(e)[:70])
        # ★ 코어를 받았으면(또는 못 받았으면) **함께 말한다** — 링크 팩만
        #   보고하면 사용자는 기본 자료가 왔는지 모른다.
        if core_note:
            self._dl_msg.config(
                text=core_note + '\n' + self._dl_msg.cget('text'))
        msg = self._dl_msg.cget('text')
        self._dl_fill(self._dl_kind)
        if self._dl_kind != 'LINK':
            self._dl_on_pick()
        self._dl_msg.config(text=msg)

    def _dl_get_asset(self, row):
        """자산 하나를 서버에서 받아 붙인다.

        ⚠ **왜 안 되는지 말한다**(§0-1) — 아직 서버에 안 올라온 자산이 있다.
          조용히 실패하면 「눌렀는데 아무 일이 없다」가 된다.
        """
        import os
        import tempfile
        k, key, lang, title, ver, lic, st, *_rest = row
        if st not in ('NEW', 'REMOVED'):
            return
        if not messagebox.askyesno(
                _t('SET_DL_GET', '지금 받기'),
                _t('DL_GET_ASK',
                   '「%s」 를 지금 받습니다.\n\n'
                   '받는 동안 앱을 켜 두세요. 인터넷을 씁니다.') % title[:60]):
            return
        self._dl_msg.config(text=_t('SET_DL_GETTING', '받는 중…'))
        self.update_idletasks()
        # ★ **받는 문은 `pack_status.fetch_asset` 하나**(⑪) — 폴백 화면도
        #   같은 문을 쓴다. 여기서 다시 짜면 규칙이 갈린다.
        import pack_status as PS
        r = PS.fetch_asset(k, key, lang, self.db_path,
                                  self._dl_variant_of(k, key, lang))
        if not r['ok']:
            self._dl_msg.config(text=_t(
                'DL_NOT_ON_SERVER',
                '아직 서버에 올라오지 않은 자료입니다. 나중에 다시 눌러 주세요.')
                if r['why'] == 'NOT_ON_SERVER' else
                _t('DL_GET_FAIL', '받지 못했습니다: %s') % r['why'])
            return
        self._dl_msg.config(text=_t(
            'DL_GET_DONE_N', '「%s」 를 받았습니다. (%s개)')
            % (title[:40], format(r['rows'], ',')))
        self._dl_rows = self._dl_rows_load()
        self._dl_fill(self._dl_kind)
        self._dl_on_pick()

    def _dl_apply_preset(self, row):
        """환경설정 양식을 **적용**한다 — 확인을 받고(1.txt 22-1(3) · 293차)."""
        _k, code, _lang, title, *_r = row
        if not messagebox.askyesno(
                _t('DL_PRESET_APPLY', '이 양식 적용'),
                _t('DL_PRESET_ASK',
                   '「%s」 양식을 적용합니다.\n\n지금 설정(테마·글꼴·역본·탭 짜임·캔버스 배치·'
                   '표시 언어)이 그것으로 바뀝니다. 내 글과 즐겨찾기는 그대로입니다.') % title[:60]):
            return
        try:
            import db_pref_preset as _PP
            import appdb as _ad
            c = _ad.connect(self.db_path)
            try:
                r = _PP.apply(c, code)
            finally:
                c.close()
        except Exception as e:                               # noqa: BLE001
            self._dl_msg.config(text=_t('DL_PRESET_FAIL', '적용하지 못했습니다: %s') % str(e)[:60])
            return
        self._dl_msg.config(text=_t(
            'DL_PRESET_DONE',
            '「%s」 양식을 적용했습니다(설정 %d · 화면 배치 %d). 화면 배치는 다음에 켤 때 보입니다. '
            '색·글꼴은 앱을 껐다 켜면 전부 반영됩니다.') % (r['name'][:40], r['cfg'], r['state']))

    def _dl_variant_of(self, kind, key, lang):
        """그 자산의 **변형**(`ORIGINAL`·`TRANSLATED` …). 모르면 `-`.

        ★ 목록 행의 여덟째 칸에 실려 있다(`_dl_merge_assets`). 없으면
          `sys_pack_item` 에 물어본다 — 서버 목록이 없을 때다.
        ⚠ **`-` 로 때우지 않는다** — 그러면 지우기·받기가 0행을 걸어
          「눌러도 아무 일이 없다」가 된다(§0-1). 그것이 0.txt 2-2 버그였다.
        """
        lg = '' if (lang or '-') in ('-', '') else str(lang).upper()
        for row in (self._dl_rows or []):
            if len(row) < 8:
                continue
            rlg = '' if (row[2] or '-') in ('-', '') else str(row[2]).upper()
            if str(row[0]) == str(kind) and str(row[1]) == str(key)                     and rlg == lg:
                return row[7] or '-'
        try:
            c = appdb.connect(self.db_path)
            try:
                r = c.execute(
                    "SELECT variant FROM sys_pack_item WHERE kind=? AND key=? "
                    "AND COALESCE(lang,'') IN (?, '-') "
                    "AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
                    (kind, key, lg)).fetchone()
                return (r[0] if r and r[0] else '-')
            finally:
                c.close()
        except Exception:
            return '-'

    def _dl_del_asset(self, row):
        """자산 하나를 지운다 — **몇 개가 사라지는지 먼저 말한다**."""
        k, key, lang, title, ver, lic, st, *_rest = row
        if st != 'INSTALLED':
            return
        lg = '-' if (lang or '-') == '-' else lang
        # ⚠ **variant 를 그 자산의 것으로** — `'-'` 로 물으면 0행이 걸린다.
        var = self._dl_variant_of(k, key, lg)
        try:
            import db_pack_body as PB
            c = appdb.connect(self.db_path)
            try:
                n = PB.remove(c, k, key, lg, var, dry=True)
            finally:
                c.close()
        except Exception as e:                                # noqa: BLE001
            self._dl_msg.config(text=_t(
                'DL_DEL_FAIL', '지우지 못했습니다: %s') % str(e)[:70])
            return
        if not messagebox.askyesno(
                _t('DL_BTN_DEL', '삭제하기'),
                _t('DL_DEL_ASK_N',
                   '「%s」 의 본문 %s개를 지웁니다.\n\n'
                   '제목과 연결은 남아 있어 계속 보이고, '
                   '언제든 다시 받을 수 있습니다.\n'
                   '내가 쓴 글은 지워지지 않습니다.')
                % (title[:50], format(n, ','))):
            return
        try:
            c = appdb.connect(self.db_path)
            try:
                got = PB.remove(c, k, key, lg, var)
                c.commit()
            finally:
                c.close()
            import pack_status as PS
            PS.mark_removed(k, key, lang, on=True, db_path=self.db_path)
            self._dl_msg.config(text=_t(
                'DL_DEL_DONE_N',
                '「%s」 를 지웠습니다. (%s개) 목록에는 「삭제됨」으로 남습니다.')
                % (title[:40], format(got, ',')))
        except Exception as e:                                # noqa: BLE001
            self._dl_msg.config(text=_t(
                'DL_DEL_FAIL', '지우지 못했습니다: %s') % str(e)[:70])
            return
        self._dl_rows = self._dl_rows_load()
        self._dl_fill(self._dl_kind)
        self._dl_on_pick()

    def _dl_clear(self):
        """용량 확보용 지우기 — **다시 받을 수 있다는 것을 먼저 말한다**."""
        import pack_status as PS
        sel = self._dl_tv.selection()
        if self._dl_kind != 'LINK' and sel:
            w, it = self._dl_items.get(sel[0], (None, None))
            if w == 'CONTENT':
                return self._dl_del_asset(it)
        h = PS.have()
        if not messagebox.askyesno(
                _t('DL_BTN_DEL', '삭제하기'),
                _t('SET_DL_CLEAR_ASK',
                   '받은 자료 %s 를 지웁니다.\n\n'
                   '내가 쓴 글과 성경 본문은 지워지지 않습니다.\n'
                   '언제든 [지금 받기] 로 다시 받을 수 있습니다.')
                % PS.human(h['bytes'])):
            return
        try:
            import link_pack
            c = appdb.connect(self.db_path)
            try:
                link_pack.detach(c)
            finally:
                c.close()
        except Exception:
            pass
        n = PS.clear()
        msg = (_t('DL_DEL_DONE',
                  '%s 를 비웠습니다. 목록에는 「삭제됨」으로 남고, '
                  '언제든 다시 받을 수 있습니다.') % PS.human(n)) if n \
            else _t('SET_DL_LOCKED',
                    '지금은 지울 수 없습니다. 앱을 껐다 켠 뒤 다시 해 주세요.')
        self._dl_fill(self._dl_kind)
        if self._dl_kind != 'LINK':
            self._dl_on_pick()
        self._dl_msg.config(text=msg)

    def _dl_rows_load(self):
        """받을 수 있는 자산 + 내 실물 → `(유형, 열쇠, 언어, 제목, 판, 저작권, 상태)`.

        ★★★ **두 목록을 겹친다**(2026-09-04 ⑩) — 그전에는 **내가 이미 가진
          것만** 보였다. 무엇을 더 받을 수 있는지 알 길이 없었다.
          · **실측**(아래 SQL) = 「지금 내 DB 에 있는 것」
          · **서버 목록**(`pack_status.assets` — manifest 의 `items`)
            = 「받을 수 있는 것 + 판 번호」
          ⇒ 열쇠 `(유형, 열쇠, 언어)` 로 맞춰 **판과 상태를 덮고**, 서버에만
            있는 것은 **미설치 줄로 더한다**.
        ⚠ 서버를 못 읽으면 실측만 남는다 — 지금까지처럼 보인다(안 깨진다).
        """
        rows = []
        try:
            with appdb.connect(self.db_path) as c:
                rows.append(('APP', '-', '-', 'Hagah Dabar', '-', '-', ''))
                # ★ **받은 연결 자료를 목록에 낸다**(2026-09-04) — 그전에는
                #   이 표에 팩이 없어 「무엇을 받았나」가 어디에도 안 보였다.
                #   ⚠ 없으면 줄을 안 만든다(빈 서랍 금지 §0-1) — 위 상태줄이
                #     「아직 받은 자료가 없습니다」라고 이미 말한다.
                try:
                    import pack_status as PS
                    h = PS.have()
                    if h['exists']:
                        rows.append((
                            'LINK', '-', '-',
                            _t('DL_ROW_PACK', '영상·링크 연결 자료'),
                            # ★ 판 표기 통일 — 여기도 `A-3` 꼴(2026-09-07)
                            '%s · %s' % (PS.ver_label(h['cursor']),
                                         PS.human(h['bytes'])),
                            _t('DL_LIC_LINKONLY', '주소만 저장(원저작물 미포함)'),
                            ''))
                except Exception:
                    pass
                for code, name, lang in c.execute(
                        "SELECT version_code, COALESCE(display_name, version_name,"
                        " version_code), COALESCE(lang_code,'') FROM bible_version "
                        "ORDER BY version_code"):
                    lic = ''
                    try:
                        lic = c.execute("SELECT COALESCE(copyright_type,'') FROM"
                                        " bible_version WHERE version_code=?",
                                        (code,)).fetchone()[0]
                    except Exception:
                        pass
                    rows.append(('BIBLE', code, lang, name, code, lic, ''))
                for code, title, year in c.execute(
                        "SELECT commentary_code, COALESCE(title, commentary_code),"
                        " COALESCE(pub_year,'') FROM sys_commentary_source "
                        "ORDER BY commentary_code"):
                    rows.append(('COMM', code, 'EN', title, str(year),
                                 'PUBLIC_DOMAIN', ''))
                for cat_is_sermon, want in ((0, 'BOOK'), (1, 'SERMON')):
                    for bcode, title, lang, cr, year in c.execute(
                            "SELECT book_code, COALESCE(title,''),"
                            " COALESCE(lang_code,''),"
                            " COALESCE(copyright_type,''), COALESCE(pub_year,'')"
                            " FROM sys_book_asset WHERE record_status='LIVE' AND "
                            + ("book_category='SERMON'" if cat_is_sermon
                               else "book_category!='SERMON'") + " ORDER BY title"):
                        rows.append((want, bcode, lang, title, str(year),
                                     cr, ''))
                for code, in c.execute(
                        "SELECT src_code FROM sys_ref_source "
                        "WHERE src_type='DICTIONARY' AND record_status='LIVE'"):
                    rows.append(('DICT', code, 'EN', code, '-',
                                 'PUBLIC_DOMAIN', ''))
                # ★ 원어 사전 — **담는 쪽과 같은 문**(`db_pack_item._lex`). 언어 `-`.
                try:
                    import db_pack_item as _PI2
                    for _k, key, _lg, _v, title in _PI2._lex(c):
                        rows.append(('LEX', key, '-', title, '-', 'PUBLIC_DOMAIN', ''))
                except Exception as _e:                      # noqa: BLE001
                    print('[download] lex:', _e)
                # ★ 환경설정 양식 — 코어에 실려 이미 여기 있다. 받는 줄이 아니라
                #   **적용하는 줄**이라 상태를 「설치됨」으로 두고 단추 글을 바꾼다.
                try:
                    import db_pref_preset as _PP
                    for x in _PP.list_presets(c):
                        rows.append(('PRESET', x['code'], '-', x['name'], '-', '-',
                                     'INSTALLED'))
                except Exception as _e:                      # noqa: BLE001
                    print('[download] preset:', _e)
                # ★★★ **설명문은 (성경책 묶음 × 언어)가 팩 하나다**
                #   (2026-09-24 286차 · 사용자 지시 「배포관리 수정에 따라
                #    영향을 받는 모든 부분들을 일관되게 수정하라」).
                #   ⚠⚠ 그전에는 열쇠에 **`text_type`**(`VERS_DESC`)을 적고
                #     있었다 — 어떤 팩 열쇠와도 안 맞아 **받을 수도 지울 수도
                #     없는 유령 줄**이었다(지금은 묶음 코드가 열쇠다).
                #   ★ 목록을 여기서 다시 짜지 않는다 — **담는 쪽과 같은 문**
                #     (`db_pack_item._desc`)을 부른다. 두 벌이면 갈린다.
                try:
                    import db_pack_item as _PI
                    for _k, key, lang, _v, title in _PI._desc(c):
                        rows.append(('DESC', key, lang, title, '-', '-', ''))
                except Exception as _e:                      # noqa: BLE001
                    print('[download] desc:', _e)
        except Exception as e:
            print('[download] rows:', e)
        return self._dl_merge_assets(rows)

    def _dl_ver_label(self, it, st):
        """버전 칸 — **내 판과 최신 판을 함께** 보인다.

        ★★★ 왜 (2026-09-06 사용자 지시 「**항목별 버전상태 표시하지 않으면
          다운로드 필요성을 모른다.** 표시하라」): 그전에는 **서버 최신 판만**
          적어서, 갖고 있는 것과 같은지 알 수 없었다 — 「받을 필요가 있나」를
          화면이 답하지 않았다.
        · 안 받았음      `A-3`         (상태 칸이 「다운로드 가능」이라 말한다)
        · 최신을 갖고 있음 `A-3`
        · 갱신이 있음     `A-2 → A-3`  ← **이 한 줄이 필요성을 말한다**
        ⚠ **판을 모르면 지어내지 않는다** — 옛 DB 에는 판 칸이 없다.
          그때는 최신 판만 적고 화살표를 안 쓴다(§0-1b).
        ★★ **표기는 `pack_status.ver_arrow` 한 문이 짓는다**(2026-09-07 사용자
          지시 「앱의 모든 화면/목록 등에서 **한 가지 방식으로 통일**한다.
          예) 1판, Ver 1 ... **금지한다**」). 화면마다 지으면 갈린다.
        """
        import pack_status as PS
        new = it.get('version') or it.get('own_version') or 0
        if st != 'INSTALLED':
            return PS.ver_label(new)
        return PS.ver_arrow(it.get('mine'), new)

    def _dl_merge_assets(self, rows):
        """실측 줄 위에 **서버 자산 목록**을 겹친다 — 판·상태·미설치 줄.

        ⚠ 열쇠는 `(유형, 열쇠, 언어)` 다 — 같은 책이라도 **언어마다 따로
          받는다**(사용자 확정 「책 한권 선호하는 언어로 선택하여 다운로드
          할 것이다. 그래야 최소용량을 사용한다」). 언어가 없는 자산(성경·
          주석)은 언어 칸을 비워 맞춘다.
        ⚠ **코어는 목록에 안 낸다** — 앱 기본이라 받고 지우는 대상이 아니고,
          위의 「영상·링크」 줄이 이미 그 자리를 맡는다.
        """
        try:
            import pack_status as PS
            items = PS.assets(self.db_path)
        except Exception as e:
            print('[download] assets:', e)
            return rows
        if not items:
            return rows
        # ⚠ **`UNKNOWN` 도 미설치다** — 그 값은 「껍데기를 못 찾았다」는 뜻인데,
        #   **목록에 있다는 것 자체가 「받을 수 있다」**는 뜻이므로 여기서는
        #   미설치로 읽는다. 빈 값으로 두면 **팩 밖 자산(앱 기본)과 구별이
        #   안 되어** 받을 수 있는 것이 회색으로 잠긴다(실측으로 잡았다).
        try:
            import pack_fallback as FB
            st_map = {FB.OK: 'INSTALLED', FB.MISSING: 'NEW',
                      FB.LANG: 'NEW', FB.UNKNOWN: 'NEW'}
        except Exception:
            st_map = {}
        by_key, seen, out = {}, set(), []
        # ★ 자산 안내문(manifest `note`) — 고른 줄 아래에 보인다(1.txt 22-4)
        self._dl_item_note = {}
        for it in items:
            lg = (it.get('lang') or '').upper()
            by_key[((it.get('kind') or '').upper(),
                    str(it.get('key') or ''), '' if lg == '-' else lg)] = it
            if it.get('note'):
                self._dl_item_note[((it.get('kind') or '').upper(),
                                    str(it.get('key') or ''), '' if lg == '-' else lg)] = it['note']
        for r in rows:
            lg = (r[2] or '').upper()
            k = (r[0], str(r[1]), '' if lg == '-' else lg)
            it = by_key.get(k) or by_key.get((r[0], str(r[1]), ''))
            if it:
                seen.add(id(it))
                st = st_map.get(it.get('state'), '')
                if st == 'NEW' and it.get('removed'):
                    st = 'REMOVED'
                # ★★ **여덟째 칸 = variant**(2026-09-06 사용자 0.txt 2-2
                #   「책 한권 선택해서 삭제하기 → **도서 0개를 지운다**고
                #   팝업 → 확인해도 지워지지 않는다」).
                #   ⚠⚠ 정체는 화면이 `variant='-'` 를 넘긴 것이다 — 실제
                #     자산은 `BOOK|CLEMENT_1ST|KO|**TRANSLATED**` 라
                #     0행이 걸렸다. `_dl_rows` 가 variant 를 **아예 안 실어**
                #     화면이 넘길 값을 갖고 있지 않았다.
                #   ⚠ **맨 뒤에** 더한다 — 앞 일곱 칸을 읽는 코드가 안 깨진다
                #     (언패킹은 `*_rest` 로 열어 두었다).
                #   ★ **아홉째 칸 = 5분류**(2026-09-07 사용자 0.txt 1·2-1
                #     「라디오 버튼 배치 (전체/최신판/업그레이드 가능/
                #      다운로드 가능/미발행)」). **원본 dict 가 있는 여기서**
                #     정한다 — 화면이 글자를 되파싱하면 표기를 바꿀 때 깨진다.
                out.append((r[0], r[1], r[2], r[3],
                            self._dl_ver_label(it, st), r[5], st,
                            it.get('variant') or '-',
                            PS.item_class(it, st)))
            else:
                # ⚠ 서버 목록에 없는 자산 — 내 DB 실측만 있다. 판을 모르므로
                #   갖고 있으면 최신, 아니면 미발행으로 본다(지어내지 않는다).
                st0 = r[6] if len(r) > 6 else 'NEW'
                out.append(tuple(r) + ('-', PS.item_class({}, st0)))
        # ★ **서버에만 있는 것 = 아직 안 받은 자산** — 이것이 이 겹치기의
        #   존재 이유다(그전에는 화면에 나올 자리가 아예 없었다).
        for it in items:
            if id(it) in seen or (it.get('kind') or '').upper() == 'CORE':
                continue
            st2 = ('REMOVED' if it.get('removed')
                   else st_map.get(it.get('state'), 'NEW'))
            out.append(((it.get('kind') or '').upper(),
                        str(it.get('key') or ''), it.get('lang') or '-',
                        it.get('title') or str(it.get('key') or ''),
                        self._dl_ver_label(it, st2),
                        '-', st2, it.get('variant') or '-',
                        PS.item_class(it, st2)))
        return out

    def _build_faq(self, p):
        """FAQ — bible_master sys_faq 로컬 읽기(사용자 언어, EN 폴백). 동기화 없음.

        ⚠ **제목 라벨을 걷었다** (2026-09-06 사용자 0.txt 8-5 「「자주 묻는
          질문」 라벨 제거」) — **탭 이름이 이미 그 말이다.** 같은 말을 두 번
          적으면 그만큼 목록이 줄어든다.
        """
        pw = ttk.Panedwindow(p, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=8, pady=(6, 8))
        left = ttk.Frame(pw); pw.add(left, weight=1)
        tv = ttk.Treeview(left, columns=('cat', 'q'), show='headings', selectmode='browse', height=12)
        tv.heading('cat', text=_t('FB_FAQ_CAT', '분류')); tv.column('cat', width=100, anchor='w', stretch=False)
        tv.heading('q', text=_t('FB_FAQ_Q', '질문')); tv.column('q', width=240, anchor='w')
        vsb = ttk.Scrollbar(left, orient='vertical', command=tv.yview); tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y'); tv.pack(side='left', fill='both', expand=True)
        tv.bind('<<TreeviewSelect>>', self._on_faq_select)
        self._faq_tv = tv
        right = ttk.Frame(pw); pw.add(right, weight=2)
        self._faq_ans = tk.Text(right, wrap='word', state='disabled',
                                bg=_C('panel', '#FBFCFC'), fg=_C('fg', '#222'),
                                padx=8, pady=6)
        try:
            import theme_font
            theme_font.register(self._faq_ans, self.db_path, 'prose')
        except Exception:
            pass
        self._faq_ans.pack(fill='both', expand=True)
        self._faq_rows = []
        self._load_faq()

    def _load_faq(self):
        lang = (self.lang_getter() or 'KO').upper()
        rows = []
        try:
            with appdb.connect(self.db_path) as conn:
                if conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='sys_faq'").fetchone():
                    rows = conn.execute("""
                        SELECT COALESCE(f.category,''),
                               COALESCE(tl.question, te.question, ''),
                               COALESCE(tl.answer, te.answer, '')
                        FROM sys_faq f
                        LEFT JOIN sys_faq_text tl ON tl.faq_id=f.faq_id AND UPPER(tl.lang_code)=? AND tl.record_status='LIVE'
                        LEFT JOIN sys_faq_text te ON te.faq_id=f.faq_id AND te.lang_code='EN' AND te.record_status='LIVE'
                        WHERE f.record_status='LIVE'
                        ORDER BY f.sort_order, f.faq_id""", (lang,)).fetchall()
        except Exception as e:
            print('[Feedback] faq:', e)
        # 질문 비어있는(번역 없는) 행 제외
        self._faq_rows = [(c, q, a) for c, q, a in rows if (q or '').strip()]
        self._faq_tv.delete(*self._faq_tv.get_children())
        for i, (cat, q, a) in enumerate(self._faq_rows):
            cat_lbl = _t('FB_FAQCAT_' + cat, cat) if cat else ''   # 분류 코드 → 사용자 언어
            self._faq_tv.insert('', 'end', iid=str(i), values=(cat_lbl, q))

    def _on_faq_select(self, _e):
        sel = self._faq_tv.selection()
        if not sel:
            return
        try:
            cat, q, a = self._faq_rows[int(sel[0])]
        except (ValueError, IndexError):
            return
        self._faq_ans.config(state='normal')
        self._faq_ans.delete('1.0', 'end')
        self._faq_ans.insert('1.0', f'Q. {q}\n\n{a}')
        self._faq_ans.config(state='disabled')

    def _build_ask(self, p):
        """내 문의 — **갈래 둘**(2026-09-06 사용자 0.txt 8-1).

        ★ 사용자 지시 — 「버튼 2개 배치 : **일반문의 / 오류통보**」.
          두 일은 재료가 다르다: 일반문의는 **사람이 쓴 글**이고 오류통보는
          **기계가 남긴 기록**이다. 한 화면에 섞여 있어 [오류 기록 함께]가
          체크박스 하나로 숨어 있었다.
        ⚠ 갈래 전환은 `pack_forget` — 파괴하면 목록·본문을 매번 다시 짓는다(§3-1).
        ⚠ **이메일 칸을 걷었다**(사용자 「이메일 주소는 전혀 안보이게, 안내
          라벨도 제거」) — 값은 남긴다(`self._email0`). 답은 앱 안에서 온다.
        """
        top = tk.Frame(p, bg=_C('accent_bg', '#EAF2FB'))
        top.pack(fill='x', side='top')
        self._ask_btn = {}
        for key, lab, dflt in (('ASK', 'FB_G_ASK', '일반문의'),
                               ('BUG', 'FB_G_BUG', '오류통보')):
            b = tk.Button(top, text=_t(lab, dflt), bd=0, padx=14, pady=4,
                          cursor='hand2', command=lambda k=key: self._ask_show(k))
            b.pack(side='left', padx=(6 if key == 'ASK' else 4, 0), pady=4)
            self._ask_btn[key] = b
        self._status = tk.Label(top, text='', bg=_C('accent_bg', '#EAF2FB'),
                                fg=_C('fg_dim', '#555'))
        self._status.pack(side='right', padx=8)

        host = tk.Frame(p)
        host.pack(fill='both', expand=True)
        self._ask_pane = {'ASK': tk.Frame(host), 'BUG': tk.Frame(host)}
        self._build_ask_normal(self._ask_pane['ASK'])
        self._build_ask_bug(self._ask_pane['BUG'])
        self._ask_show('ASK')

    def _ask_show(self, key):
        for k, fr in self._ask_pane.items():
            if k == key:
                fr.pack(fill='both', expand=True)
            else:
                fr.pack_forget()
        for k, b in self._ask_btn.items():
            on = (k == key)
            b.configure(bg=_C('accent' if on else 'panel_alt', '#2471A3'),
                        fg=_C('fg_on_dark' if on else 'fg', '#FFFFFF'))
        self._ask_mode = key

    # ── 갈래 ① 일반문의 ───────────────────────────────────────────
    def _build_ask_normal(self, p):
        # 상단 액션 바 (§0 — 버튼 상단). ★ **보내기·첨부는 오른쪽**(사용자 지시)
        bar = tk.Frame(p, bg=_C('accent_bg', '#EAF2FB')); bar.pack(fill='x', side='top')
        tk.Label(bar, text=_t('FB_KIND', '유형'),
                 bg=_C('accent_bg', '#EAF2FB'),
                 fg=_C('fg', '#333')).pack(side='left', padx=(6, 2), pady=5)
        self._kind = ttk.Combobox(
            bar, values=[lb for _, lb in _kind_labels(_ASK_KIND_CODES)],
            width=12, state='readonly')
        self._kind.current(0); self._kind.pack(side='left', padx=2)
        tk.Button(bar, text=_t('COMMON_REFRESH', '새로고침'), bd=0,
                  bg=_C('panel_alt', '#E5E8E8'), fg=_C('fg', '#333'),
                  padx=8, cursor='hand2',
                  command=self.refresh).pack(side='left', padx=8)
        # ⚠ **먼저 pack 한 것이 더 오른쪽**이다 — 보내기를 맨 나중에 붙이면
        #   첨부보다 왼쪽으로 간다. 차례를 뒤집어 붙인다.
        tk.Button(bar, text=_t('FB_SEND', '보내기'), bd=0,
                  bg=_C('accent', '#2471A3'), fg=_C('fg_on_dark', 'white'),
                  padx=14, cursor='hand2',
                  command=self._send).pack(side='right', padx=(4, 8), pady=5)
        self._attach_btn = tk.Button(bar, text=_t('FB_ATTACH', '첨부'), bd=0,
                                     bg=_C('accent_bg', '#D6EAF8'),
                                     fg=_C('accent', '#1A5276'),
                                     padx=10, cursor='hand2',
                                     command=self._pick_files)
        self._attach_btn.pack(side='right', padx=4)

        # 첨부 이름 + 용량 제한 — **정책은 코드에서 읽는다**(손으로 적으면 갈린다)
        arow = tk.Frame(p); arow.pack(fill='x', padx=8, pady=(4, 0))
        self._attach_lbl = tk.Label(arow, text='', anchor='w',
                                    fg=_C('success', '#1E8449'))
        self._attach_lbl.pack(side='left')
        tk.Label(arow, anchor='e', fg=_C('fg_dim', '#888'),
                 text=_t('FB_ATTACH_LIMIT',
                         '첨부는 한 개 %dMB · 모두 합쳐 %dMB 까지입니다.')
                      % (F.MAX_FILE_BYTES // (1024 * 1024),
                         F.MAX_TOTAL_BYTES // (1024 * 1024))
                 ).pack(side='right')

        # 작성 영역
        cf = tk.LabelFrame(p, text=' ' + _t('FB_COMPOSE', '문의·개선요청') + ' ')
        cf.pack(fill='x', padx=8, pady=4)
        self._text = tk.Text(cf, height=5, wrap='word')
        try:
            import theme_font
            theme_font.register(self._text, self.db_path, 'prose')
        except Exception:
            pass
        self._text.pack(fill='x', padx=6, pady=6)

        if not self._configured:
            tk.Label(p, text='ⓘ ' + _t('FB_NOT_CONFIGURED',
                     '지원 채널이 아직 설정되지 않았습니다. 관리자 설정 후 이용할 수 있습니다.'),
                     anchor='w', fg=_C('danger', '#C0392B')).pack(fill='x', padx=10, pady=2)

        self._tv, self._detail = self._ask_history(p, _t('FB_MY_THREADS', '내 문의 내역'))

    # ── 갈래 ② 오류통보 ───────────────────────────────────────────
    def _build_ask_bug(self, p):
        """오류통보 — 상단 단추 차례를 사용자 지시 그대로 못 박는다.

        `새로고침 | (여백) | 오류기록 보기 · 오류기록 첨부 · 첨부 이름 |
         (여백) | 보내기`
        ⚠ **첨부 이름이 들고 나도 단추 자리가 안 바뀐다**(사용자 지시
          「첨부파일 이름 표시와 관계없이 **배치장소 고정**」) — 이름 라벨을
          폭이 정해진 칸에 넣는다.
        """
        bar = tk.Frame(p, bg=_C('accent_bg', '#EAF2FB')); bar.pack(fill='x', side='top')
        tk.Button(bar, text=_t('COMMON_REFRESH', '새로고침'), bd=0,
                  bg=_C('panel_alt', '#E5E8E8'), fg=_C('fg', '#333'),
                  padx=8, cursor='hand2',
                  command=self.refresh).pack(side='left', padx=(6, 0), pady=5)
        tk.Frame(bar, width=28, bg=_C('accent_bg', '#EAF2FB')).pack(side='left')
        tk.Button(bar, text=_t('FB_ERRLOG_VIEW2', '오류기록 보기'), bd=0,
                  bg=_C('panel_alt', '#E5E8E8'), fg=_C('fg', '#333'),
                  padx=8, cursor='hand2',
                  command=self._show_errlog).pack(side='left', padx=(0, 4))
        # ★ 체크박스를 **단추**로 — 「함께 보낼까」가 아니라 「붙인다」가 이 화면의 일
        self._send_errlog = tk.BooleanVar(value=True)
        self._errlog_btn = tk.Button(bar, text=_t('FB_ERRLOG_ATTACH', '오류기록 첨부'),
                                     bd=0, padx=10, cursor='hand2',
                                     command=self._toggle_errlog)
        self._errlog_btn.pack(side='left')
        namef = tk.Frame(bar, width=240, height=24, bg=_C('accent_bg', '#EAF2FB'))
        namef.pack(side='left', padx=8)
        namef.pack_propagate(False)          # ⚠ 이름 길이가 자리를 못 밀게
        self._errlog_name = tk.Label(namef, text='', anchor='w',
                                     bg=_C('accent_bg', '#EAF2FB'),
                                     fg=_C('success', '#1E8449'))
        self._errlog_name.pack(fill='both', expand=True)
        tk.Button(bar, text=_t('FB_SEND', '보내기'), bd=0,
                  bg=_C('accent', '#2471A3'), fg=_C('fg_on_dark', 'white'),
                  padx=14, cursor='hand2',
                  command=self._send_bug).pack(side='right', padx=(4, 8), pady=5)

        # ★ **메시지 칸을 둔다**(사용자 물음 「별도 메시지 입력항목이 없어도
        #   되는가? 추가 설명이 도움이 되는가?」 — 도움이 된다).
        #   오류 기록은 「무엇이 터졌나」만 말하고 「무엇을 하다가」는 못 말한다.
        cf = tk.LabelFrame(p, text=' ' + _t('FB_BUG_WHAT', '무엇을 하다가 그랬나요? (선택)') + ' ')
        cf.pack(fill='x', padx=8, pady=4)
        self._bug_text = tk.Text(cf, height=4, wrap='word')
        try:
            import theme_font
            theme_font.register(self._bug_text, self.db_path, 'prose')
        except Exception:
            pass
        self._bug_text.pack(fill='x', padx=6, pady=6)

        self._bug_tv, self._bug_detail = self._ask_history(
            p, _t('FB_BUG_THREADS', '지난 오류통보'))
        self._toggle_errlog(init=True)

    def _toggle_errlog(self, init=False):
        if not init:
            self._send_errlog.set(not self._send_errlog.get())
        on = self._send_errlog.get()
        self._errlog_btn.configure(
            bg=_C('accent' if on else 'panel_alt', '#2471A3'),
            fg=_C('fg_on_dark' if on else 'fg', '#FFFFFF'))
        if on:
            try:
                import errlog
                n = len(errlog.bundle())
            except Exception:
                n = 0
            # ⚠⚠ **파일 이름을 지어내지 않는다**(2026-09-06 사용자 1-2).
            #   그전에는 `errlog.txt (7,017자)` 라고 적었는데 **그런 파일은
            #   없다** — 오류 기록은 첨부가 아니라 **본문에 붙는다**
            #   (`_send_bug` 가 글 뒤에 이어 붙인다). 없는 파일 이름을 보이면
            #   사용자는 그것을 찾아 열려고 한다(§0-1b 지어내지 않는다).
            self._errlog_name.config(
                text=_t('FB_ERRLOG_ON', '오류 기록 %s자 — 본문에 붙습니다')
                     % format(n, ',d'),
                fg=_C('success', '#1E8449'))
        else:
            # ⚠ 빈 칸은 「고장」으로 읽힌다 — 안 붙인다는 것도 말한다.
            self._errlog_name.config(
                text=_t('FB_ERRLOG_OFF', '오류 기록을 안 붙입니다'),
                fg=_C('fg_dim', '#7F8C8D'))

    def _ask_history(self, p, title):
        """지난 문의 목록 — 좌(목록)/우(내용). 두 갈래가 같은 얼개를 쓴다."""
        tk.Label(p, text=title, anchor='w',
                 font=('', 9, 'bold')).pack(fill='x', padx=8, pady=(4, 0))
        pw = ttk.Panedwindow(p, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=8, pady=(2, 8))
        left = ttk.Frame(pw); pw.add(left, weight=1)
        cols = ('when', 'kind', 'summary', 'reply')
        tv = ttk.Treeview(left, columns=cols, show='headings', selectmode='browse', height=10)
        tv.heading('when', text=_t('FB_COL_WHEN', '보낸날')); tv.column('when', width=110, anchor='center', stretch=False)
        tv.heading('kind', text=_t('FB_KIND', '유형')); tv.column('kind', width=80, anchor='center', stretch=False)
        tv.heading('summary', text=_t('FB_COL_SUMMARY', '내용')); tv.column('summary', width=200, anchor='w')
        tv.heading('reply', text=_t('FB_COL_REPLY', '답변')); tv.column('reply', width=44, anchor='center', stretch=False)
        vsb = ttk.Scrollbar(left, orient='vertical', command=tv.yview)
        tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y'); tv.pack(side='left', fill='both', expand=True)
        tv.bind('<<TreeviewSelect>>', self._on_select)

        right = ttk.Frame(pw); pw.add(right, weight=2)
        det = tk.Text(right, wrap='word', state='disabled',
                      bg=_C('panel', '#FBFCFC'), fg=_C('fg', '#222'),
                      padx=8, pady=6)
        try:
            import theme_font
            theme_font.register(det, self.db_path, 'prose')
        except Exception:
            pass
        det.pack(fill='both', expand=True, padx=4, pady=4)
        return tv, det

    # ── 동작 ─────────────────────────────────────────────────────────
    def _on_map(self, _e):
        if not self._first:
            self._first = True
            self.after(100, self._load)
            self.after(300, lambda: self._sync(force=False))

    def _pick_files(self):
        paths = filedialog.askopenfilenames(
            title=_t('FB_ATTACH', '첨부'),
            filetypes=[('로그/텍스트', '*.log *.txt *.json'), ('이미지', '*.png *.jpg *.jpeg'),
                       ('모든 파일', '*.*')])
        if paths:
            self._attach = list(paths)
            self._attach_lbl.config(text='' + ', '.join(p.split('/')[-1].split('\\')[-1]
                                                            for p in self._attach))

    def _show_errlog(self):
        """**보내기 전에 무엇을 보내는지 보여 준다** — §32 가 요구한 안내."""
        try:
            import errlog
            body = errlog.bundle()      # 기본 = 최근 7일 · 30가지 · 접어서
        except Exception as e:
            body = '오류 기록을 읽지 못했습니다: %s' % e
        w = tk.Toplevel(self.winfo_toplevel())
        w.title(_t('FB_ERRLOG_VIEW_TITLE', '함께 보낼 오류 기록'))
        w.geometry('820x520')
        tk.Label(w, text=_t('FB_ERRLOG_NOTE',
                            '아래 내용이 문의와 함께 갑니다. '
                            '이름·이메일 같은 개인정보는 *** 로 지웠습니다.'),
                 anchor='w', justify='left',
                 fg=_C('fg_dim', '#7F8C8D')).pack(fill='x', padx=8, pady=(8, 2))
        f = tk.Frame(w)
        f.pack(fill='both', expand=True, padx=8, pady=(0, 8))
        sb = tk.Scrollbar(f)
        sb.pack(side='right', fill='y')
        t = tk.Text(f, wrap='none', yscrollcommand=sb.set)
        sb.config(command=t.yview)
        t.pack(fill='both', expand=True)
        t.insert('1.0', body)
        t.config(state='disabled')
        tk.Button(w, text=_t('COMMON_CLOSE', '닫기'),
                  command=w.destroy).pack(pady=(0, 8))
        try:
            import ui_theme
            ui_theme.adopt(w)
        except Exception:
            pass

    def _send(self):
        """일반문의 보내기. ⚠ **오류 기록을 안 붙인다** — 그 일은 오류통보 갈래."""
        if self._busy:
            return
        if not self._configured:
            messagebox.showinfo(_t('FB_COMPOSE', '문의'),
                                _t('FB_NOT_CONFIGURED', '지원 채널이 아직 설정되지 않았습니다.'),
                                parent=self.winfo_toplevel())
            return
        text = self._text.get('1.0', 'end').strip()
        if not text and not self._attach:
            messagebox.showinfo(_t('FB_COMPOSE', '문의'),
                                _t('FB_EMPTY', '내용이나 첨부를 입력하세요.'),
                                parent=self.winfo_toplevel())
            return
        kind = _ASK_KIND_CODES[self._kind.current()]
        # ⚠ 이메일 칸은 화면에서 걷었다(0.txt 8-1) — 예전에 넣어 둔 값이 있으면 그대로 쓴다
        email = self._email0 or ''
        self._busy = True
        self._status.config(text=_t('FB_SENDING', '보내는 중…'))
        threading.Thread(target=self._send_worker, args=(kind, text, list(self._attach), email),
                         daemon=True).start()

    def _send_bug(self):
        """오류통보 — 사람이 쓴 한 줄 + **오류 기록 전문**을 본문에 붙인다.

        ★ 새 통로를 만들지 않는다(§32) — 같은 문의 통로에 `kind='BUG'` 로 간다.
        ⚠ 개인정보(홈 폴더 경로·메일)는 `errlog.mask` 가 이미 지웠다.
        """
        if self._busy:
            return
        if not self._configured:
            messagebox.showinfo(_t('FB_G_BUG', '오류통보'),
                                _t('FB_NOT_CONFIGURED', '지원 채널이 아직 설정되지 않았습니다.'),
                                parent=self.winfo_toplevel())
            return
        text = self._bug_text.get('1.0', 'end').strip()
        body = ''
        if self._send_errlog.get():
            try:
                import errlog
                body = errlog.bundle()      # [오류기록 보기] 와 **같은 것**을 보낸다
            except Exception as e:
                print('[errlog bundle] %s' % e)
        if not text and not body:
            messagebox.showinfo(_t('FB_G_BUG', '오류통보'),
                                _t('FB_BUG_EMPTY',
                                   '보낼 것이 없습니다 — [오류기록 첨부]를 켜거나 '
                                   '무슨 일이 있었는지 적어 주세요.'),
                                parent=self.winfo_toplevel())
            return
        if body:
            text = (text + '\n\n----- 오류 기록 -----\n' + body).strip()
        self._busy = True
        self._status.config(text=_t('FB_SENDING', '보내는 중…'))
        threading.Thread(target=self._send_worker,
                         args=('BUG', text, [], self._email0 or ''),
                         daemon=True).start()

    def _send_worker(self, kind, text, attach, email):
        try:
            with appdb.connect(self.db_path) as conn:
                ok, err = F.submit(conn, kind, text, attach, email, self.lang_getter())
        except Exception as e:
            ok, err = False, str(e)[:80]
        self.after(0, lambda: self._send_done(ok, err))

    def _send_done(self, ok, err):
        self._busy = False
        if ok:
            if getattr(self, '_ask_mode', 'ASK') == 'BUG':
                self._bug_text.delete('1.0', 'end')
            else:
                self._text.delete('1.0', 'end')
                self._attach = []
                self._attach_lbl.config(text='')
            self._status.config(text=_t('FB_SENT', '보냈습니다. 답변은 여기에 표시됩니다.'))
            self._load()
        else:
            msg = _t('FB_NOT_CONFIGURED', '지원 채널 미설정') if err == 'NOT_CONFIGURED' else err
            self._status.config(text='' + (msg or '전송 실패'))

    def refresh(self):
        self._load()
        self._sync(force=True)

    def _sync(self, force=False):
        if self._busy or not self._configured:
            return
        if not force:
            try:
                with appdb.connect(self.db_path) as conn:
                    if not F.is_configured(conn):
                        return
            except Exception:
                return
        threading.Thread(target=self._sync_worker, daemon=True).start()

    def _sync_worker(self):
        try:
            with appdb.connect(self.db_path) as conn:
                F.sync_replies(conn)
        except Exception:
            pass
        # ⚠ 이 실은 앱이 닫힌 **뒤에** 깨어날 수 있다 — 그때 `after` 를 부르면
        #   Tk 가 「main thread is not in main loop」 로 트레이스백을 뱉는다
        #   (종료할 때 실제로 났다). 창이 아직 있을 때만 돌려보낸다.
        try:
            if self.winfo_exists():
                self.after(0, self._load)
        except Exception:
            pass

    def _load(self):
        try:
            with appdb.connect(self.db_path) as conn:
                self._threads = F.threads(conn)
                unread = F.unread_count(conn)   # 열람 처리는 mark_seen()에서만(탭 볼 때)
        except Exception as e:
            self._threads = []; unread = 0
            print('[Feedback] load:', e)
        # ★ **갈래마다 제 목록**(0.txt 8-1) — 오류통보 이력이 문의에 섞이면
        #   무엇이 오류 신고인지 못 가린다. iid 는 `_threads` 색인 그대로라
        #   두 트리가 같은 `_on_select` 를 쓴다.
        trees = [(self._tv, lambda k: k != 'BUG')]
        if getattr(self, '_bug_tv', None) is not None:
            trees.append((self._bug_tv, lambda k: k == 'BUG'))
        for tv, keep in trees:
            # 태그 색은 그릴 때마다 역할로(§36-5b) — answered 는 상태색(의도)
            tv.tag_configure('answered', foreground=_C('success', '#1E8449'))
            tv.tag_configure('pending', foreground=_C('fg_dim', '#999'))
            tv.delete(*tv.get_children())
            for i, th in enumerate(self._threads):
                if not keep(th['kind'] or ''):
                    continue
                answered = bool(th['replies'])
                kind_lbl = _kind_label(th['kind']) if th['kind'] else ''
                summ = (th['text'] or th.get('attach') or '').replace('\n', ' ')[:60]
                tv.insert('', 'end', iid=str(i),
                          values=((th['created_at'] or '')[:16], kind_lbl, summ,
                                  '✔' if answered else ('•' if th['sent_ok'] else '')),
                          tags=('answered' if answered else 'pending',))
        self._cnt_ask = unread
        self._push_count()

    def _on_select(self, _e):
        tv = getattr(_e, 'widget', None) or self._tv
        det = (self._bug_detail if tv is getattr(self, '_bug_tv', None)
               else self._detail)
        sel = tv.selection()
        if not sel:
            return
        try:
            th = self._threads[int(sel[0])]
        except (ValueError, IndexError):
            return
        lines = [f"[{_kind_label(th['kind'])}]  {th['created_at']}",
                 '', th['text'] or '']
        if th.get('attach'):
            lines += ['', '' + th['attach']]
        if th.get('email'):
            lines += ['', '' + th['email']]
        if th['replies']:
            lines += ['', '─' * 30, '【관리자 답변】']
            for r in th['replies']:
                lines += [f"  ({r['replied_at']})", '  ' + (r['body'] or '')]
        else:
            lines += ['', _t('FB_WAIT_REPLY', '(아직 답변 없음 — 답변이 오면 여기에 표시됩니다)')]
        det.config(state='normal')
        det.delete('1.0', 'end')
        det.insert('1.0', '\n'.join(lines))
        det.config(state='disabled')

    def mark_seen(self):
        """공지/소통 탭을 볼 때 호출(user_main) — **지금 보이는 서브탭만** 열람 처리.

        ★ 2026-09-09 개정(0.txt 둘째 8번) — 그전에는 바깥 탭에 들어가는 것만으로
          공지·문의가 **함께** 0이 됐다. 문의를 보러 들어갔는데 안 읽은 공지까지
          읽은 것이 되어 그 개수가 영영 사라졌다.
        ⚠ SET(설정) 모드에서는 아무것도 하지 않는다 — 설정을 보는 것이
          문의 열람은 아니다.
        """
        if self.mode != 'COMM':
            return
        self._on_sub_tab()

    def notify_count(self):
        """배지 갱신용(외부 호출): 미열람 답변 수."""
        try:
            with appdb.connect(self.db_path) as conn:
                return F.unread_count(conn)
        except Exception:
            return 0
