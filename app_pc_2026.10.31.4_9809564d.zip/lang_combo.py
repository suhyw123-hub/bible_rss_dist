# lang_combo.py
"""표시 언어 콤보 — **단일 소스** (2026-08-14 사용자 지시 7·8·9번, 설계 재확정).

★ 설계 원칙 (2026-08-14 사용자 확정 — **이것을 어기면 안 된다**)

  ① **처음 한 번은 전체 환경설정 언어**(`user_lang`)로 시작하고, 그 뒤로는
     **화면마다 완전히 따로 기억한다.** 도서/설교를 영어로 두면 앱을 껐다 켜도 영어고,
     그동안 사전은 일본어로 남는다. 화면끼리 서로 영향이 없다.
     ⇒ 화면마다 `key='LANGSEL_<화면>'` 을 준다. **열쇠를 안 주면 기억하지 않는다.**
     ⚠ 전에는 「일시값」이었다(전역 하나만 저장). 사용자 확정으로 바뀌었다 —
       「한 마디로 화면마다 완전히 따로따로 저장한다」.
  ② **목록은 고정이다. 데이터가 있는지 묻지 않는다.**
     ⚠ **이 앱은 완성본이 아니다.** 지금 한국어뿐이라고 콤보를 한 줄로 만들면,
       나중에 번역이 채워져도 그 화면은 여전히 한 줄이다. 그리고 화면을 열 때마다
       「이 언어에 글이 있나」를 묻는 것이 **가장 큰 느림의 원인**이었다
       (실측 — 도서 판 조회 74.75ms · 페리코프 언어 28.2ms, `font.md` §28).
     ⇒ **앱이 다국어라면 모든 데이터가 다국어로 채워진다는 전제**로 만든다.
  ③ **폴백은 언제나 영어다.** 요청한 언어가 없으면 EN. 폴백은 「고를 수 있게 하는
     수단」이 아니라 **만일의 공백·오류에 대비하는 것**이다.

★ 「원문」이라는 낱말을 쓰지 않는다.
  이 앱에는 히브리·헬라 성경 원문(`WLC`·`GNT`)이 따로 있어 **같은 낱말이 두 가지를
  가리킨다.** 주석·도서의 `ORIGINAL` 은 원문이 아니라 저자가 쓴 **영어**다.
  ⇒ `English` 로 적고, 같은 영어인 `MODERN_EN` 만 `Modern English` 로 가른다.

★ 언어 이름은 **그 언어의 자기 이름**으로 (`lang_config.lang_name`).
  「영어·중국어」처럼 읽는 사람 언어로 번역하면 그 언어를 쓰는 사람이 자기 줄을 못 찾는다.

┌ 목록 두 가지 — 자산의 성격이 정한다 ─────────────────────────────────────┐
│ **번역이 얹히는 저작물** (주석·도서·설교·사전) → `variant_items()`          │
│    `English` · `Modern English` · `한국어` · `中文(简体)` … (12줄)          │
│    고르면 `(ORIGINAL,EN)` · `(MODERN_EN,EN)` · `(TRANSLATED,KO)` …          │
│ **언어별 행만 있는 자산** (엔티티·설명문·연구 글) → `lang_items()`          │
│    `English` · `한국어` · `中文(简体)` … (11줄), 변형 없음                  │
└──────────────────────────────────────────────────────────────────────────┘
"""
import tkinter as tk
from tkinter import ttk

import appdb
import lang_config

# 갈래 단추와 콤보 사이 간격 — **화면마다 같아야 한다**(잘못 누르지 않게).
GAP = 28

# 폴백은 언제나 영어 (사용자 확정).
FALLBACK = 'EN'

# 「원문」이 실제로 무슨 언어인가 — 등록된 주석·도서·사전의 저자 언어.
ORIGINAL_LANG = 'EN'

_word_cache = {}

# ── 화면마다 따로 기억한다 (2026-08-14 사용자 확정) ─────────────────────────
# 「스펄전 설교집을 한글로 읽다가 영어를 선택하면 그 상태가 유지된다. 앱을 꺼도,
#  화면을 바꾸어도 그 상태가 유지된다. … 한 마디로 화면마다 완전히 따로따로 저장한다.」
#
#   열쇠 이름은 `LANGSEL_<화면>` 하나로 통일한다 — 이름이 갈리면 「이건 다른 장치인가」를
#   묻게 된다(실제로 `DESC_LANG` 하나가 그래서 여러 차례 혼란을 만들었다).
#   값은 `"<변형>|<언어>"` 한 줄. 변형이 없는 자산은 `"|KO"`.
#
# ⚠ **읽기는 한 번만.** 46줄짜리 표라 통째로 읽어도 0.028ms 지만, 화면마다 DB 연결을
#   새로 여는 것이 오히려 비싸다(2.6ms). 처음 한 번 읽어 기억하고 쓸 때 갱신한다.
KEY_PREFIX = 'LANGSEL_'
_sel_cache = None


def _load_sel(db_path=None):
    global _sel_cache
    if _sel_cache is not None:
        return _sel_cache
    out = {}
    conn = None
    try:
        conn = appdb.connect(db_path) if db_path else appdb.connect()
        for k, v in conn.execute(
                "SELECT config_key, config_val FROM user_config "
                "WHERE config_key LIKE ?", (KEY_PREFIX + '%',)).fetchall():
            if v:
                out[k] = v
        # ★ 옛 열쇠 `LINKS_<갈래>` (2026-10-09 1.txt 59-1) — 접두가 없어
        #   위 조회가 못 읽었다(앱을 다시 켜면 P2 영상 탭의 선택이 잊혔다).
        #   새 이름에 아직 값이 없으면 옛 값을 읽는다(새로 고르면 새 이름에 적힌다).
        for k, v in conn.execute(
                "SELECT config_key, config_val FROM user_config "
                "WHERE config_key LIKE 'LINKS_%'").fetchall():
            if v and (KEY_PREFIX + k) not in out:
                out[KEY_PREFIX + k] = v
    except Exception:
        out = {}
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
    _sel_cache = out
    return out


def get_sel(key, db_path=None):
    """그 화면이 마지막에 선택한 `(variant, lang)`. 선택한 적 없으면 None."""
    if not key:
        return None
    raw = _load_sel(db_path).get(key)
    if not raw:
        return None
    v, _, lc = str(raw).partition('|')
    return ((v or None), (lc or '').upper() or None)


def chosen_lang(key, default='KO', db_path=None):
    """그 화면이 지금 선택한 **언어 코드** — 「전체」면 None, 선택한 적 없으면 `default`.

    ★ 배지가 쓴다(2026-10-09 1.txt 59-1 사용자 「하나의 언어콤보를 선택하면 그 언어에
      해당하는 레코드 숫자만」) — 목록과 배지가 **같은 선택**을 읽어야 숫자가 맞는다.
      콤보가 처음 뜰 때도 「고른 것 → 환경설정 언어」 차례라 여기와 같다.
    """
    saved = get_sel(key, db_path)
    if saved and saved[1]:
        return None if saved[1] == ALL else saved[1].upper()
    return (default or FALLBACK).upper()


_LISTEN = []


def listen(fn):
    """언어 콤보가 바뀔 때 부를 것을 건다 — `fn(key)`. (배지를 다시 세는 자리)"""
    if fn not in _LISTEN:
        _LISTEN.append(fn)


def notify(key):
    for fn in list(_LISTEN):
        try:
            fn(key)
        except Exception as e:
            print('[lang_combo.notify] %s' % e)


def set_sel(key, variant, lang, db_path=None):
    """그 화면의 선택을 기억한다. **콤보를 선택할 때만** 불린다(쓰기 1.8ms)."""
    if not key:
        return
    raw = '%s|%s' % (variant or '', (lang or '').upper())
    conn = None
    try:
        conn = appdb.connect(db_path) if db_path else appdb.connect()
        cur = conn.execute("UPDATE user_config SET config_val=? WHERE config_key=?",
                           (raw, key))
        if cur.rowcount == 0:
            conn.execute("INSERT INTO user_config(config_key,config_val) "
                         "VALUES(?,?)", (key, raw))
        conn.commit()
        if _sel_cache is not None:
            _sel_cache[key] = raw
    except Exception as e:
        print('[lang_combo.set_sel] %s' % e)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass


# ── 글자를 보고 언어를 짐작한다 (2026-08-14 사용자 제안 「일차 점검기능」) ────
# ⚠ **막을 수는 없다** — 사람이 무엇을 치든 막을 방법은 없다. 다만 저장 직전에
#   한 번 묻는 것은 값싸고 거의 다 잡는다. 문자 종류는 기계가 **정확히** 안다.
# ⚠ **라틴 문자끼리는 가르지 않는다.** 영어·독일어·프랑스어·스페인어·포르투갈어는
#   같은 글자를 쓰므로 「영어라 해 놓고 독일어를 썼다」는 판정할 수 없다.
#   억지로 가르면 헛경고가 쏟아진다.
_LATIN = {'EN', 'DE', 'FR', 'ES', 'PT'}
_SCRIPT_RANGES = (
    ('KO', ((0xAC00, 0xD7A3), (0x1100, 0x11FF))),          # 한글 음절·자모
    ('JA', ((0x3040, 0x309F), (0x30A0, 0x30FF))),          # 히라가나·가타카나
    ('RU', ((0x0400, 0x04FF),)),                           # 키릴
    ('AR', ((0x0600, 0x06FF), (0x0750, 0x077F))),          # 아랍
    ('ZH', ((0x4E00, 0x9FFF),)),                           # 한자 (가나가 없을 때만)
)


def guess_script(text):
    """글자를 세어 가장 많은 문자체계의 대표 코드. 못 가르면 None.

    ⚠ 한자는 일본어에도 쓰이므로 **가나가 있으면 일본어**로 본다 — 순서가 뜻이 있다.
    """
    s = str(text or '')
    if not s.strip():
        return None
    cnt = {}
    latin = 0
    for ch in s:
        o = ord(ch)
        if (0x41 <= o <= 0x5A) or (0x61 <= o <= 0x7A) or (0xC0 <= o <= 0x24F):
            latin += 1
            continue
        for code, ranges in _SCRIPT_RANGES:
            if any(a <= o <= b for a, b in ranges):
                cnt[code] = cnt.get(code, 0) + 1
                break
    if cnt.get('JA') and cnt.get('ZH'):
        cnt['JA'] += cnt.pop('ZH')          # 가나가 있으면 한자도 일본어 몫
    if not cnt:
        return 'LATIN' if latin else None
    top = max(cnt, key=cnt.get)
    # 라틴이 압도적이면 라틴으로 본다 (원어 낱말 몇 개가 섞였을 뿐인 경우)
    if latin > cnt[top] * 3:
        return 'LATIN'
    return top


def mismatch(text, lang):
    """선택한 언어와 글자가 **분명히** 어긋나면 짐작한 코드를, 아니면 None.

    ⚠ 애매하면 **아무 말도 하지 않는다.** 헛경고는 경고를 무시하게 만든다.
    """
    got = guess_script(text)
    if not got:
        return None
    lg = str(lang or '').upper()
    if got == 'LATIN':
        return None if lg in _LATIN else 'EN'
    if got == 'ZH':
        return None if lg in ('ZH', 'ZHT') else 'ZH'
    return None if lg == got else got


def ui_langs():
    """`sys_language.sort_order` 순서의 UI 언어 코드."""
    try:
        return [str(c).upper() for c in lang_config.ui_langs()]
    except Exception:
        return ['EN', 'KO']


def content_langs():
    """**자료를 쓸 수 있는 언어** — UI 축보다 넓다(히브리어 등).

    ★ 2026-09-22 (1.txt 8-3) — 「히브리어는 연구자료와 같은 것들을 표시할
      방법이 없다. 추가 활성화해야 한다」. `ui_langs()` 를 넓히면 **앱 표시
      언어 콤보**까지 넓어져 `ui_strings` 가 없는 언어로 화면이 열린다.
    """
    try:
        return [str(c).upper() for c in lang_config.content_langs()]
    except Exception:
        return ui_langs()


def content_items(with_all=False):
    """`lang_items` 의 콘텐츠 축 판 — `(None, lang_code)`."""
    out = [(None, ALL)] if with_all else []
    return out + [(None, c) for c in content_langs()]


def order(langs):
    """언어 코드 뭉치를 `sys_language.sort_order` 순서로. (남는 것은 뒤에)"""
    want = {str(c).upper() for c in (langs or ()) if c}
    ref = ui_langs()
    out = [c for c in ref if c in want]
    out += sorted(want - set(out))
    return out


def variant_items():
    """**번역이 얹히는 저작물**의 고정 목록 — `(text_variant, lang_code)`.

    `0.app수정.txt` 가 적어 둔 그대로다: 원문 / 현대영어 / 한국어 / 중국어 …
    ⚠ **DB 를 묻지 않는다.** 있고 없고는 고른 뒤에 폴백이 처리한다.
    """
    out = [('ORIGINAL', ORIGINAL_LANG), ('MODERN_EN', ORIGINAL_LANG)]
    out += [('TRANSLATED', c) for c in ui_langs() if c != ORIGINAL_LANG]
    return out


#: 「전체언어」 자리표 — 언어를 안 가린다는 뜻
ALL = '*'


def lang_items(with_all=False):
    """**언어별 행만 있는 자산**의 고정 목록 — `(None, lang_code)`.

    `with_all` 이면 **맨 앞에 「전체언어」**(`ALL`)를 둔다 — 언어를 안 가리는
    화면(P2 링크 등)이 쓴다. ⚠ 정렬이 안정적이라 맨 앞자리가 지켜진다.
    """
    out = [(None, ALL)] if with_all else []
    return out + [(None, c) for c in ui_langs()]


def word(string_id, lang_code, db_path=None, dflt=''):
    """`ui_strings` 를 **지정한 언어로** 읽는다 (한 번 읽고 기억한다).

    ⚠ `i18n.t` 는 **지금 UI 언어**로만 준다. 여기서는 「그 언어로 적힌 낱말」이
      필요하다 — 중국어 항목에는 중국어로 `摘要` 라고 적혀야 한다.
    """
    code = (lang_code or FALLBACK).upper()
    key = (string_id, code)
    if key in _word_cache:
        return _word_cache[key] or dflt
    val = ''
    conn = None
    try:
        conn = appdb.connect(db_path) if db_path else appdb.connect()
        r = conn.execute(
            "SELECT string_value FROM ui_strings "
            "WHERE string_id=? AND UPPER(lang_code)=?", (string_id, code)).fetchone()
        if not r:
            r = conn.execute(
                "SELECT string_value FROM ui_strings "
                "WHERE string_id=? AND UPPER(lang_code)=?",
                (string_id, FALLBACK)).fetchone()
        val = (r[0] if r else '') or ''
    except Exception:
        val = ''
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
    _word_cache[key] = val
    return val or dflt


def label(lang_code, variant=None, db_path=None):
    """콤보에 보일 한 줄. **언어 이름은 그 언어의 자기 이름으로.**

    `English` · `Modern English` · `한국어` · `한국어 (요약)` · `中文(简体)`
    """
    if lang_code == ALL:
        try:
            import i18n as _i
            return _i.t('LP_ALLLANG', '전체언어')
        except Exception:
            return '전체언어'
    v = (variant or '').upper()
    if v == 'MODERN_EN':
        # 영어를 고친 영어다 — 이름도 영어로 적는다.
        return word('BOOK_VARIANT_MODERN_EN', ORIGINAL_LANG, db_path,
                    'Modern English')
    code = (lang_code or ORIGINAL_LANG).upper()
    name = lang_config.lang_name(code) or code
    if v == 'SUMMARY':
        return '%s (%s)' % (name, word('BOOK_VARIANT_SUMMARY', code, db_path,
                                       'Summary'))
    return name


# 변형을 늘어놓는 순서 — 원문 → 현대영어 → 번역 → 요약
_V_ORDER = {'ORIGINAL': 0, 'MODERN_EN': 1, 'TRANSLATED': 2, 'SUMMARY': 3, '': 2}


def sort_key(item):
    """`(variant, lang_code)` 를 늘어놓는 순서 — **변형만 본다.**

    ⚠ 언어끼리는 **부르는 쪽이 준 순서를 지킨다**(파이썬 정렬은 안정적이다).
      코드 알파벳순으로 세웠더니 `العربية · Deutsch · English …` 로 아랍어가 맨 위에
      왔다(2026-08-14 실측). `ui_langs()` 는 `sys_language.sort_order` 를 따르므로
      **그 순서가 이미 뜻을 갖는다** — 여기서 다시 세우면 그것을 버린다.
    """
    v, _lc = item
    return _V_ORDER.get((v or '').upper(), 9)


class LangCombo:
    """표시 언어 콤보 하나. 화면은 **`set_items` 와 `current` 만** 쓰면 된다.

    ★ `key` 를 주면 **그 화면의 선택을 기억한다** — 앱을 꺼도, 다른 화면에 갔다 와도
      그대로다. 화면끼리는 서로 영향이 없다(열쇠가 다르다).
      처음 한 번은 `default_lang`(= 환경설정 언어)으로 시작한다.
    """

    def __init__(self, parent, db_path=None, on_change=None,
                 width=15, font=None, gap=GAP, pady=3,
                 side='left', default_lang='KO', key=None):
        # ★ 글꼴을 **박지 않는다** (2026-08-19 0.txt ④ — 사용자 「English 가
        #   표준서식보다 작은 글자, 하드코딩인 듯」 → 정확했다. 옛 기본값
        #   `('Malgun Gothic', 9)` 는 §36 위반 이중이었다: 이름 하드코딩 + 9pt
        #   고정이라 펼침 목록(TkDefaultFont = 통합폰트 「ui」 구역)과 어긋나고
        #   콤보 상하 폭도 9pt 에 눌려 좁았다). 비우면 TkDefaultFont 를 따라
        #   표시부·펼침 목록·높이가 함께 표준을 탄다.
        self.db_path = db_path
        self.on_change = on_change
        self.key = key
        self.default_lang = (default_lang or FALLBACK).upper()
        self.items = []
        self.var = tk.StringVar()
        kw = dict(textvariable=self.var, state='disabled', width=width)
        if font:
            kw['font'] = font
        self.combo = ttk.Combobox(parent, **kw)
        self.combo.pack(side=side, padx=(gap, 6), pady=pady)
        self.combo.bind('<<ComboboxSelected>>', self._fire)

    # ── 목록 ────────────────────────────────────────────────────────────────
    def set_items(self, items, select=None, names=None):
        """항목을 갈아 끼운다. `select` 는 `(variant, lang_code)`.

        `select` 를 안 주면 **그 화면이 마지막에 고른 것** → 없으면 환경설정 언어.
        ⚠ **같은 이름이 두 번 오르면 고를 수 없다.** 이름이 겹치면 뒤엣것을 버린다.
        `names` — `{(variant, lang_code): 이름}` 으로 **그 화면만의 이름**을 덮는다
          (2026-09-16 · 1.txt 23 — 주석 탭은 원문 영어를 `Original` 이라 적는다.
          다른 화면은 「원문이 무엇인지 표시할 필요 없다」).
        """
        seen, rows = set(), []
        for v, lc in items:
            nm = (names or {}).get((v, lc)) or label(lc, v, self.db_path)
            if nm in seen:
                continue
            seen.add(nm)
            rows.append((v, lc, nm))
        rows.sort(key=lambda r: sort_key((r[0], r[1])))
        self.items = rows
        self.combo['values'] = [r[2] for r in rows]
        if not rows:
            self.combo.set('')
            self.combo.config(state='disabled')
            return
        self.combo.config(state='readonly' if len(rows) > 1 else 'disabled')
        if select is not None and self.select(*select):
            return
        # ① 이 화면이 마지막에 고른 것
        saved = get_sel(self.key, self.db_path)
        if saved:
            if self.select(saved[0], saved[1]):
                return
            # 판이 안 맞아도 **언어는 지킨다** (목록이 바뀌었을 때)
            if saved[1] and self._select_lang(saved[1]):
                return
        # ② 환경설정 언어  ③ 영어
        if self._select_lang(self.default_lang):
            return
        if self._select_lang(FALLBACK):
            return
        self.combo.set(rows[0][2])

    def _select_lang(self, lang):
        """그 언어의 첫 줄을 선택한다. (변형이 여럿이면 앞선 것 = 원문)"""
        lg = (lang or '').upper()
        for v, lc, nm in self.items:
            if (lc or '').upper() == lg:
                self.combo.set(nm)
                return True
        return False

    def select(self, variant, lang_code):
        v = (variant or '').upper()
        lc = (lang_code or '').upper()
        for vv, ll, nm in self.items:
            if (vv or '').upper() == v and (ll or '').upper() == lc:
                self.combo.set(nm)
                return True
        return False

    def current(self):
        """선택한 것 `(variant, lang_code)`. 없으면 None."""
        nm = self.combo.get()
        for v, lc, n in self.items:
            if n == nm:
                return (v, lc)
        return self.items[0][:2] if self.items else None

    def lang(self):
        """선택한 언어 코드. 없으면 환경설정 언어."""
        cur = self.current()
        return ((cur[1] if cur and cur[1] else self.default_lang) or FALLBACK).upper()

    def variant(self):
        """선택한 판. 변형 개념이 없는 자산이면 None."""
        cur = self.current()
        return cur[0] if cur else None

    def _fire(self, event=None):
        cur = self.current()
        if self.key and cur:
            set_sel(self.key, cur[0], cur[1], self.db_path)
        if callable(self.on_change):
            self.on_change(cur)
        notify(self.key)


def _selftest():
    bad = []
    import os
    db = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                      'bible_master.db')
    if not os.path.exists(db):
        db = None

    # ① 언어 이름은 그 언어의 자기 이름 — 번역하지 않는다
    if label('EN', 'ORIGINAL', db) != 'English':
        bad.append('원문(영어)을 English 로 안 적는다: %r' % label('EN', 'ORIGINAL', db))
    if label('KO', 'TRANSLATED', db) != '한국어':
        bad.append('한국어를 자기 이름으로 안 적는다: %r' % label('KO', 'TRANSLATED', db))

    # ② 「원문」이라는 낱말을 쓰지 않는다 — 히브리·헬라 성경 원문과 겹친다
    for lc, v in (('EN', 'ORIGINAL'), ('KO', 'TRANSLATED'), ('KO', 'SUMMARY')):
        s = label(lc, v, db)
        for w in ('원문', 'Original', '原文'):
            if w in s:
                bad.append('「%s」이 라벨에 남았다: %r' % (w, s))

    # ③ 두 영어가 갈린다
    a, b = label('EN', 'ORIGINAL', db), label('EN', 'MODERN_EN', db)
    if a == b:
        bad.append('원문과 현대영어가 같은 이름이다: %r' % a)

    # ④ 요약은 **그 언어의 낱말**로
    if db and label('ZH', 'SUMMARY', db) != '中文(简体) (摘要)':
        bad.append('ZH 요약이 그 언어 낱말이 아니다: %r' % label('ZH', 'SUMMARY', db))

    # ⑤ 늘어놓는 순서 · 언어 순서는 부르는 쪽을 지킨다
    got = sorted([('SUMMARY', 'KO'), ('TRANSLATED', 'KO'),
                  ('MODERN_EN', 'EN'), ('ORIGINAL', 'EN')], key=sort_key)
    if [g[0] for g in got] != ['ORIGINAL', 'MODERN_EN', 'TRANSLATED', 'SUMMARY']:
        bad.append('순서가 어긋났다: %s' % got)
    given = [(None, 'EN'), (None, 'KO'), (None, 'ZH'), (None, 'AR'), (None, 'DE')]
    if sorted(given, key=sort_key) != given:
        bad.append('언어 순서를 제멋대로 바꾼다')

    # ⑥ ★ **고정 목록** — 데이터가 있든 없든 전 언어가 오른다 (설계 ②)
    vi, li = variant_items(), lang_items()
    langs = ui_langs()
    if len(li) != len(langs):
        bad.append('언어 목록이 ui_langs 와 다르다: %d vs %d' % (len(li), len(langs)))
    if len(vi) != len(langs) + 1:
        bad.append('변형 목록이 「원문+현대영어+나머지 언어」가 아니다: %d' % len(vi))
    if vi[0] != ('ORIGINAL', 'EN') or vi[1] != ('MODERN_EN', 'EN'):
        bad.append('변형 목록 앞머리가 다르다: %s' % vi[:2])
    for c in langs:
        if c == 'EN':
            continue
        if ('TRANSLATED', c) not in vi:
            bad.append('%s 가 변형 목록에 없다' % c)
        if (None, c) not in li:
            bad.append('%s 가 언어 목록에 없다' % c)

    # ⑦ **DB 를 묻지 않는다** — 목록 만들기에 조회가 끼면 화면이 느려진다
    import time
    s = time.perf_counter()
    for _ in range(200):
        variant_items()
        lang_items()
    ms = (time.perf_counter() - s) / 200 * 1000
    if ms > 0.5:
        bad.append('목록 만들기가 느리다(%.2fms) — DB 를 묻고 있지 않은가' % ms)

    # ⑧ 폴백은 언제나 영어
    if FALLBACK != 'EN':
        bad.append('폴백이 영어가 아니다: %s' % FALLBACK)

    # ⑨ 기본 선택 = 환경설정 언어, 없으면 영어 (Tk 없이 흉내)
    class _C:
        def __init__(self): self._v, self._s = '', 'readonly'
        def set(self, v): self._v = v
        def get(self): return self._v
        def config(self, **kw): self._s = kw.get('state', self._s)
        def cget(self, k): return self._s
        def bind(self, *a): pass
        def pack(self, **kw): pass
        def __setitem__(self, k, v): pass

    lc = LangCombo.__new__(LangCombo)
    lc.db_path, lc.on_change, lc.default_lang, lc.key = db, None, 'KO', None
    lc.items, lc.combo = [], _C()
    lc.set_items(variant_items())
    if lc.combo.get() != '한국어':
        bad.append('환경설정 언어를 기본으로 안 선택한다: %r' % lc.combo.get())
    if lc.lang() != 'KO' or lc.variant() != 'TRANSLATED':
        bad.append('선택한 값 해석이 이상하다: %s' % (lc.current(),))
    lc.default_lang = 'JA'
    lc.set_items(variant_items())
    if lc.combo.get() != '日本語':
        bad.append('일본어 환경에서 일본어를 안 선택한다: %r' % lc.combo.get())
    # 그 언어가 목록에 아예 없으면 영어로
    lc.default_lang = 'XX'
    lc.set_items(variant_items())
    if lc.combo.get() != 'English':
        bad.append('없는 언어일 때 영어로 안 떨어진다: %r' % lc.combo.get())

    # ⑩ ★ **화면마다 따로 기억한다** — 이 설계의 요점이라 반드시 검사한다.
    import sqlite3, tempfile
    global _sel_cache
    tdb = os.path.join(tempfile.gettempdir(), '_lc_sel.db')
    if os.path.exists(tdb):
        os.remove(tdb)
    _c = sqlite3.connect(tdb)
    _c.execute("CREATE TABLE user_config (config_key TEXT PRIMARY KEY, config_val TEXT)")
    _c.commit(); _c.close()
    _sel_cache = None

    def _mk(key, default='KO'):
        o = LangCombo.__new__(LangCombo)
        o.db_path, o.on_change, o.key = tdb, None, key
        o.default_lang, o.items, o.combo = default, [], _C()
        return o

    book = _mk('LANGSEL_BOOK')
    dic = _mk('LANGSEL_DICT')
    book.set_items(variant_items())
    dic.set_items(variant_items())
    if book.combo.get() != '한국어' or dic.combo.get() != '한국어':
        bad.append('처음에 환경설정 언어로 시작하지 않는다')
    # 도서 화면만 영어로 바꾼다
    book.combo.set('English')
    book._fire()
    # 사전 화면은 일본어로
    dic.combo.set('日本語')
    dic._fire()
    # 앱을 껐다 켠 것처럼 캐시를 버리고 새로 만든다
    _sel_cache = None
    book2, dic2, lens2 = _mk('LANGSEL_BOOK'), _mk('LANGSEL_DICT'), _mk('LANGSEL_LENS')
    book2.set_items(variant_items())
    dic2.set_items(variant_items())
    lens2.set_items(lang_items())
    if book2.combo.get() != 'English':
        bad.append('도서 화면이 선택한 값을 못 지킨다: %r' % book2.combo.get())
    if dic2.combo.get() != '日本語':
        bad.append('사전 화면이 선택한 값을 못 지킨다: %r' % dic2.combo.get())
    if lens2.combo.get() != '한국어':
        bad.append('안 선택한 화면까지 끌려갔다: %r' % lens2.combo.get())
    # 목록에서 사라진 판이어도 **언어는 지킨다**
    set_sel('LANGSEL_BOOK', 'SUMMARY', 'JA', tdb)
    _sel_cache = None
    book3 = _mk('LANGSEL_BOOK')
    book3.set_items(variant_items())          # SUMMARY 는 고정 목록에 없다
    if book3.combo.get() != '日本語':
        bad.append('판이 안 맞을 때 언어를 못 지킨다: %r' % book3.combo.get())
    # 열쇠가 없으면 저장하지 않는다
    nokey = _mk(None)
    nokey.set_items(variant_items())
    nokey.combo.set('English')
    nokey._fire()
    _sel_cache = None
    if _load_sel(tdb).get(None) is not None:
        bad.append('열쇠 없이도 저장한다')
    try:
        os.remove(tdb)
    except Exception:
        pass
    _sel_cache = None

    # ⑪ **글자로 언어 짐작** — 잡아야 할 것과 **잡으면 안 되는 것**을 함께 검사한다
    for txt, lang, want in (
            ('에봇은 제사장의 옷이다', 'EN', 'KO'),        # 한글인데 영어라 함 → 잡는다
            ('에봇은 제사장의 옷이다', 'KO', None),
            ('The ephod was a priestly garment', 'EN', None),
            ('The ephod was a priestly garment', 'KO', 'EN'),
            ('Das Efod war ein Gewand', 'DE', None),       # 라틴끼리는 안 가른다
            ('Das Efod war ein Gewand', 'FR', None),
            ('エポデは祭司の衣', 'JA', None),
            ('エポデは祭司の衣', 'ZH', 'JA'),               # 가나가 있으면 일본어
            ('以弗得是祭司的衣服', 'ZH', None),
            ('以弗得是祭司的衣服', 'ZHT', None),            # 번체도 중국어로 본다
            ('以弗得是祭司的衣服', 'KO', 'ZH'),
            ('Ефод — одежда священника', 'RU', None),
            ('Ефод — одежда священника', 'EN', 'RU'),
            ('', 'EN', None),                              # 빈 글은 아무 말도 안 한다
            ('123 ...', 'EN', None),
            ('The ephod (에봇) was worn', 'EN', None),      # 낱말 몇 개 섞인 것은 봐준다
    ):
        got = mismatch(txt, lang)
        if got != want:
            bad.append('어긋남 판정 틀림: %r/%s → %s (기대 %s)' % (txt[:16], lang, got, want))

    print('lang_combo selftest:', 'OK' if not bad else 'FAIL')
    for b in bad:
        print('  X', b)
    if db:
        print('   변형 목록 :', ' · '.join(label(c, v, db) for v, c in variant_items()))
        print('   목록 만들기 : %.3f ms (DB 조회 없음)' % ms)
    return not bad


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if _selftest() else 1)
    print(__doc__)
