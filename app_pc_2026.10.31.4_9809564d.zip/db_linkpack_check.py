# -*- coding: utf-8 -*-
"""db_linkpack_check.py — 팩 × 오버레이 상호작용 점검 (영구 · 2026-09-03).

★ **팩 설계를 고치면 이것부터 돌린다.** 실제 앱 조회 문(overlay_read.media ·
  LinksPanel._fetch)을 그대로 불러 시나리오를 밟는다 — 「합친 결과가
  맞는가」는 코드를 읽어서는 못 재고 실제로 넣어 봐야 안다.

물음 둘:
  ① 링크 자체(추가·삭제·숨기기·수정)와 **연결관계**가 함께 전송되어
     제대로 표시되는가
  ② 사용자가 숨기기/추가/수정한 **뒤에** 관리자 팩이 오면 어떻게 되는가

⚠ 실데이터를 건드리지 않는다 — 시험 행은 시작 전 MAX(pk) 를 적어 두고
  그보다 큰 것만 지운다(§실전 다섯 번째 사고). 팩은 시험 후 삭제.
"""
import io
import json
import os
import sqlite3
import sys

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Hagah\app')
os.chdir(r'C:\Hagah\app')

import appdb                                    # noqa: E402
import db_linkpack_sync as SYNC                 # noqa: E402
import link_pack                                # noqa: E402
import overlay_read as OR                       # noqa: E402

OK = [0, 0]


def t(name, cond, extra=''):
    OK[0] += 1
    OK[1] += 1 if cond else 0
    print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))


PACK_MID = 9900777          # 시험용 팩 미디어 번호

# ⚠⚠⚠ **시험용 팩 파일로 갈아 끼운다** (2026-09-03 — 실제로 당했다).
#   그전에는 `link_pack.pack_path()`(실 팩)를 그대로 쓰고 끝에 지웠다.
#   그래서 **1차 배포로 받은 실 팩 위에 시험 델타를 얹고**, 삭제가 파일 잠금에
#   걸려 실패하자 **시험 잔재만 남은 팩**(미디어 4 · 커서 20)이 됐다.
#   ⇒ 이름을 갈아 끼워 실 팩을 아예 안 만진다. §0-5 「selftest 는 실데이터를
#     건드리지 않는다」가 팩에도 적용된다.
_KEEP_PACK_NAME = link_pack.PACK_NAME
link_pack.PACK_NAME = 'link_pack_selftest.db'

conn = appdb.connect('bible_master.db')
EID = conn.execute("SELECT entity_id FROM sys_entity_master"
                   " WHERE entity_code='P_DAVID'").fetchone()[0]

# ── 시험 전 스냅샷 ────────────────────────────────────────────────
hide_before = {r[0] for r in conn.execute(
    'SELECT media_id FROM userdb.user_media_hide')}
umax = conn.execute('SELECT COALESCE(MAX(user_media_id),0)'
                    ' FROM userdb.user_media_asset').fetchone()[0]
lmax = conn.execute('SELECT COALESCE(MAX(user_link_id),0)'
                    ' FROM userdb.user_link_asset').fetchone()[0]
tmax = conn.execute('SELECT COALESCE(MAX(sys_text_id),0)'
                    ' FROM sys_text_asset').fetchone()[0]
base = len(OR.media(conn, EID, 'ALL', 'KO'))
print('기준 — 다윗 미디어 %d · 가림 %d' % (base, len(hide_before)))


def n_all():
    conn.commit()
    return len(OR.media(conn, EID, 'ALL', 'KO'))


def row_of(mid):
    for d in OR.media(conn, EID, 'ALL', 'KO'):
        if d['mid'] == mid and not d['is_user']:
            return d
    return None


def deliver(seq, media=None, links=None, full=False):
    """관리자 팩 전송 시늉 — 델타 하나 적용."""
    p = link_pack.ensure()
    pk = sqlite3.connect(p)
    try:
        d = {'seq': seq, 'media': media or [], 'links': links or []}
        return (SYNC.apply_full(pk, d, conn) if full
                else SYNC.apply_delta(pk, d, conn))
    finally:
        pk.close()


print('\n── ① 링크 자체 + 연결관계가 함께 오는가 ──')
r = deliver(1,
            media=[{'media_id': PACK_MID, 'media_type': 'SERMON',
                    'format_type': 'VIDEO', 'title': '팩 강해 1',
                    'url': 'https://youtu.be/PACKAAAAAAA', 'lang_code': 'KO'}],
            links=[{'link_type': 'MEDI_ENTI', 'clicked': PACK_MID,
                    'target_code': 'P_DAVID'}])
t('전송 성공', r['status'] == 'OK' and r['media'] == 1 and r['links'] == 1)
t('화면에 도착(연결이 해석됐다)', n_all() == base + 1)
row = row_of(PACK_MID)
t('제목·URL 그대로', bool(row) and row['title'] == '팩 강해 1')
t('갈래 판정(yt)', bool(row) and row['yt'] == 'PACKAAAAAAA')

print('\n── 링크 수정(제목·URL 교체) ──')
deliver(2, media=[{'media_id': PACK_MID, 'media_type': 'SERMON',
                   'format_type': 'VIDEO', 'title': '팩 강해 1 (수정)',
                   'url': 'https://youtu.be/PACKBBBBBBB', 'lang_code': 'KO'}])
row = row_of(PACK_MID)
t('수정이 화면에 반영', bool(row) and row['title'] == '팩 강해 1 (수정)')
t('행이 안 는다(Upsert)', n_all() == base + 1)

print('\n── 연결관계만 삭제(미디어는 남긴다) ──')
deliver(3, links=[{'link_type': 'MEDI_ENTI', 'clicked': PACK_MID,
                   'target_code': 'P_DAVID', 'record_status': 'DELETED'}])
t('연결이 끊겨 화면에서 사라짐', n_all() == base)
pk = sqlite3.connect(link_pack.pack_path())
alive = pk.execute('SELECT COUNT(*) FROM pack_media WHERE media_id=?',
                   (PACK_MID,)).fetchone()[0]
pk.close()
t('미디어 자체는 팩에 남아 있다(연결만 삭제)', alive == 1)

print('\n── 연결 재개 + 미디어 묘비(딸린 연결까지) ──')
deliver(4, links=[{'link_type': 'MEDI_ENTI', 'clicked': PACK_MID,
                   'target_code': 'P_DAVID'}])
t('다시 이어짐', n_all() == base + 1)
deliver(5, media=[{'media_id': PACK_MID, 'record_status': 'DELETED'}])
t('미디어 묘비 → 화면에서 사라짐', n_all() == base)
pk = sqlite3.connect(link_pack.pack_path())
lk = pk.execute('SELECT COUNT(*) FROM pack_link WHERE clicked_id=?',
                (PACK_MID,)).fetchone()[0]
pk.close()
t('딸린 연결도 함께 걷힘', lk == 0)

print('\n── ② 사용자 조작 뒤 팩이 오면 ── (핵심)')
deliver(6, media=[{'media_id': PACK_MID, 'media_type': 'SERMON',
                   'format_type': 'VIDEO', 'title': '팩 강해 1',
                   'url': 'https://youtu.be/PACKAAAAAAA', 'lang_code': 'KO'}],
        links=[{'link_type': 'MEDI_ENTI', 'clicked': PACK_MID,
                'target_code': 'P_DAVID'}])
t('되살림(다시 배포)', n_all() == base + 1)

# (가) 사용자가 숨긴다
conn.execute('INSERT OR IGNORE INTO userdb.user_media_hide(media_id)'
             ' VALUES(?)', (PACK_MID,))
conn.commit()
row = row_of(PACK_MID)
t('(가) 사용자 숨김이 팩 행에 걸린다', bool(row) and row['src'] == 'HIDE')
t('읽는 화면 개수에서 빠진다',
  OR.count_reading(OR.media(conn, EID, 'ALL', 'KO')) == base)

# (나) 그 뒤 관리자가 수정본을 보낸다  ← 사용자가 물은 자리
deliver(7, media=[{'media_id': PACK_MID, 'media_type': 'SERMON',
                   'format_type': 'VIDEO', 'title': '관리자 수정본',
                   'url': 'https://youtu.be/PACKCCCCCCC', 'lang_code': 'KO'}])
row = row_of(PACK_MID)
t('(나) 팩 수정이 반영된다', bool(row) and row['title'] == '관리자 수정본')
t('(나) **사용자 숨김이 살아남는다**', bool(row) and row['src'] == 'HIDE')

# (다) 풀싱크(전체 교체)를 해도 사용자 조작이 남는가
deliver(9, media=[{'media_id': PACK_MID, 'media_type': 'SERMON',
                   'format_type': 'VIDEO', 'title': '전체본 판',
                   'url': 'https://youtu.be/PACKDDDDDDD', 'lang_code': 'KO'}],
        links=[{'link_type': 'MEDI_ENTI', 'clicked': PACK_MID,
                'target_code': 'P_DAVID'}], full=True)
row = row_of(PACK_MID)
t('(다) 풀싱크 뒤에도 숨김 유지', bool(row) and row['src'] == 'HIDE')

# (라) 사용자가 직접 만든 링크가 팩 갱신에 안 쓸린다
cur = conn.execute(
    "INSERT INTO userdb.user_media_asset(verse_id, category, title, url,"
    " record_status) VALUES(0,'ENTITY','내 링크 시험',"
    "'https://youtu.be/MYOWNAAAAAA','NEW')")
uid = cur.lastrowid
conn.execute("INSERT INTO userdb.user_link_asset(clicked_id, target_id,"
             " link_type, record_status) VALUES(?,?,'MEDI_ENTI','LIVE')",
             (uid, EID))
conn.commit()
mine = [d for d in OR.media(conn, EID, 'ALL', 'KO')
        if d['is_user'] and d['mid'] == uid]
t('(라) 내 링크가 보인다', len(mine) == 1 and mine[0]['src'] == 'NEW')
deliver(10, media=[{'media_id': PACK_MID, 'media_type': 'SERMON',
                    'format_type': 'VIDEO', 'title': '전체본 2',
                    'url': 'https://youtu.be/PACKEEEEEEE', 'lang_code': 'KO'}],
        links=[{'link_type': 'MEDI_ENTI', 'clicked': PACK_MID,
                'target_code': 'P_DAVID'}], full=True)
mine = [d for d in OR.media(conn, EID, 'ALL', 'KO')
        if d['is_user'] and d['mid'] == uid]
t('(라) **풀싱크 뒤에도 내 링크가 그대로**', len(mine) == 1)

# (마) 사용자가 제목을 고친 덮개(MEDIA_TITLE)가 팩 행에 걸리는가
conn.execute("INSERT INTO sys_text_asset(clicked_id, text_type, lang_code,"
             " contents, record_status) VALUES(?,'MEDIA_TITLE','KO',"
             "'내가 고친 제목','LIVE')", (PACK_MID,))
conn.commit()
row = row_of(PACK_MID)
t('(마) 제목 덮개가 팩 행에 걸리나', bool(row) and row['title'] == '내가 고친 제목',
  (row or {}).get('title'))

# (바) 번호 충돌 — 팩이 sys 와 같은 media_id 를 쓰면
# ⚠⚠ **화면 조회와 같은 조건으로 골라야 한다** (2026-09-10 실측으로 잡음).
#   §225차가 `overlay_read.media` 에 **링크 상태**(`ml.record_status`)를
#   더했는데 이 시험은 그것을 안 봐서 **후보(PEND) 연결의 미디어**를 골랐다.
#   그러면 그 행은 애초에 목록에 없으므로 팩이 겹칠 것이 없어 한 줄 는다 —
#   **코드가 아니라 시험이 낡은 것**이었다(4 → 5).
sysrow = conn.execute(
    "SELECT ma.media_id, ma.title FROM sys_link_asset ml"
    " JOIN sys_media_asset ma ON ma.media_id=ml.clicked_id"
    " WHERE ml.link_type='MEDI_ENTI' AND ml.target_id=?"
    "   AND COALESCE(ml.record_status,'LIVE')='LIVE'"
    "   AND ma.is_active=1 AND ma.record_status='LIVE'"
    "   AND ma.media_type NOT LIKE 'WIKI%' LIMIT 1", (EID,)).fetchone()
if sysrow:
    smid, stitle = sysrow
    n_before = n_all()
    deliver(11, media=[{'media_id': smid, 'media_type': 'SERMON',
                        'format_type': 'VIDEO', 'title': '팩이 덮은 제목',
                        'url': 'https://youtu.be/PACKFFFFFFF',
                        'lang_code': 'KO'}],
            links=[{'link_type': 'MEDI_ENTI', 'clicked': smid,
                    'target_code': 'P_DAVID'}])
    row2 = row_of(smid)
    t('(바) 같은 번호면 팩이 이긴다', bool(row2) and row2['title'] == '팩이 덮은 제목',
      (row2 or {}).get('title'))
    t('(바) 두 줄로 늘지 않는다', n_all() == n_before,
      '%d → %d' % (n_before, n_all()))

# ── ③ 구절·단락 축(P2 링크 탭) — 조회 문이 다르다 ─────────────────
print('')
print('── ③ 구절·단락 축(P2 링크 탭)은 다른 조회 문을 쓴다 ──')
import links_panel                                    # noqa: E402
VID = conn.execute("SELECT verse_id FROM bible_index"
                   " WHERE bcode=1 AND chapter=1 AND verse=1").fetchone()[0]
_p = conn.execute("SELECT pericope_id FROM sys_pericope_asset"
                  " WHERE start_vid<=? AND end_vid>=?"
                  " AND record_status='LIVE'", (VID, VID)).fetchone()
PERI = _p[0] if _p else None


class _FakePanel(links_panel.LinksPanel):
    """화면 없이 조회 문만 — 위젯을 짓지 않는다(Tk 불필요)."""

    def __init__(self, db):
        self.db_path = db
        self.lang_getter = lambda: 'KO'
        self._multi_lang = type('V', (), {'get': staticmethod(lambda: 1)})()
        self._mode = 'ALL'


_fp = _FakePanel('bible_master.db')
vbase = len(_fp._fetch(VID))
deliver(20, media=[
    {'media_id': 9911001, 'media_type': 'SERMON', 'format_type': 'VIDEO',
     'title': '팩-구절축', 'url': 'https://youtu.be/PACKVERSE1',
     'lang_code': 'KO'},
    {'media_id': 9911002, 'media_type': 'SERMON', 'format_type': 'VIDEO',
     'title': '팩-단락축', 'url': 'https://youtu.be/PACKPERI01',
     'lang_code': 'KO'}],
    links=[{'link_type': 'MEDI_VERS', 'clicked': 9911001, 'target': VID},
           {'link_type': 'MEDI_PERI', 'clicked': 9911002, 'target': PERI}])
vrows = _fp._fetch(VID)
t('구절 축 팩 링크가 P2 목록에 온다', len(vrows) == vbase + 2,
  '%d → %d' % (vbase, len(vrows)))
_via = {r['title']: r['_via'] for r in vrows
        if isinstance(r.get('media_id'), int) and r['media_id'] > 9911000}
t('층(_via)이 정확 — 구절/단락',
  _via.get('팩-구절축') == 'VERSE' and _via.get('팩-단락축') == 'PERI', _via)

# ── 뒷정리 — 시험 뒤에 생긴 것만 ─────────────────────────────────
conn.execute('DELETE FROM userdb.user_media_hide WHERE media_id=? AND ?=0',
             (PACK_MID, 1 if PACK_MID in hide_before else 0))
conn.execute('DELETE FROM userdb.user_link_asset WHERE user_link_id>?', (lmax,))
conn.execute('DELETE FROM userdb.user_media_asset WHERE user_media_id>?',
             (umax,))
conn.execute('DELETE FROM sys_text_asset WHERE sys_text_id>?', (tmax,))
conn.commit()
after_hide = {r[0] for r in conn.execute(
    'SELECT media_id FROM userdb.user_media_hide')}
t('뒷정리 — 가림 원복', after_hide == hide_before)
t('뒷정리 — 사용자 미디어 원복',
  conn.execute('SELECT COALESCE(MAX(user_media_id),0)'
               ' FROM userdb.user_media_asset').fetchone()[0] == umax)
t('뒷정리 — sys_text 원복',
  conn.execute('SELECT COALESCE(MAX(sys_text_id),0)'
               ' FROM sys_text_asset').fetchone()[0] == tmax)
# ⚠⚠ **붙어 있는 동안 파일이 잠긴다** (2026-09-03 검거) — 게다가
#   `with appdb.connect(...)` 는 **연결을 닫지 않는다**(트랜잭션만 관리 ·
#   §1 에 기록된 함정). `_fetch` 가 매번 새 연결에 attach 하므로 그 연결이
#   GC 될 때까지 잠금이 남는다.
#   ⇒ **팩 파일 교체는 앱이 꺼져 있을 때** 한다(트레이 설계가 이미 그렇다).
#     앱 안에서 갈아 끼우려면 `link_pack.detach` 를 먼저 부른다.
import gc                                             # noqa: E402
t('팩 연결 해제', link_pack.detach(conn) is True)
p = link_pack.pack_path()
for _ in range(5):
    gc.collect()
    try:
        if os.path.exists(p):
            os.remove(p)
        break
    except Exception:
        pass
t('시험 팩 삭제(뗀 뒤 · GC 유도)', not os.path.exists(p))
t('팩 없는 상태 = 기준으로 복귀', n_all() == base, '%d/%d' % (n_all(), base))
# ★ 이름을 되돌린다 — 안 되돌리면 이 프로세스 안에서 뒤에 오는 코드가
#   시험 팩을 실 팩으로 안다.
link_pack.PACK_NAME = _KEEP_PACK_NAME
t('★ 실 팩 이름 원복', link_pack.PACK_NAME == 'link_pack.db')
t('★ 실 팩을 안 건드렸다',
  not os.path.exists(os.path.join(os.path.dirname(p),
                                  'link_pack_selftest.db')))
conn.close()
print('\n점검 %d/%d' % (OK[1], OK[0]))
