# -*- coding: utf-8 -*-
"""영상 연결의 단일 소스 (2026-08-25 연결 통합).

옛 `sys_media_link(media_id, scope, scope_key, link_confidence)` 가
통합 표 `sys_link_asset` 으로 들어가면서 **칸 이름과 값의 꼴이 함께 바뀌었다.**

    옛                          새
    ----------------------      ------------------------------
    scope='ENTITY'              link_type='MEDI_ENTI'
    scope='PERICOPE'            link_type='MEDI_PERI'
    scope='VERSE'               link_type='MEDI_VERS'
    media_id                    clicked_id
    scope_key   (TEXT)          target_id   (INTEGER)   ← 꼴이 바뀐다
    link_confidence             confidence

⚠ **`scope_key` 가 글자였고 `target_id` 는 숫자다.** 옛 코드가 `str(key)` 로
  넘기던 자리를 그대로 두면 `'123'` ≠ `123` 이라 **조용히 0건**이 된다.
  그래서 `key_int()` 를 지나게 한다.

⚠ **`substr(link_type,-4)` 로 가르지 말 것** — 끝 넉 자가 같은 다른 연결
  (`BUNT_ENTI` 등)이 함께 걸린다. 늘 온전한 이름(`lt()`)으로 고른다.

배선을 파일마다 베끼면 갈라진다 — **16개 화면이 이 한 곳을 쓴다.**
"""
import sys

#: 통합 표(배포 DB). 개인 쪽 영상 연결은 아직 없다.
TBL = 'sys_link_asset'

#: 옛 scope → 넉 자 코드. **여기만 늘리면 화면이 따라온다.**
#  ⚠ `ENTITY_WIKI` 는 넣지 않는다 — 실측 0건이고 그 갈래는 `sys_ref_entity_url`
#    (사이트×엔티티 주소)로 이사했다(2026-08-25 확인).
#: ⚠ **앞의 셋은 「본문 축」**(구절·단락·용어)이고 뒤의 둘은 **찬양 축**이다
#:   (2026-09-09) — `target_id` 가 사역자·판 번호라 구절 화면이 물으면 안 된다.
#:   그래도 **여기 적는다** — `types()` 가 「이 영상의 연결 전부」를 뜻하는
#:   자리(영상을 지울 때)가 있어, 빠지면 **주인 없는 연결이 남는다.**
#:   화면은 `lt('VERSE')` 처럼 **갈래를 이름으로 집어** 쓴다.
CODE = {'ENTITY': 'ENTI', 'PERICOPE': 'PERI', 'VERSE': 'VERS',
        'ARTIST': 'ARTI', 'RENDITION': 'REND'}

#: 넉 자 코드 → 옛 scope (되읽기용)
SCOPE_OF = {v: k for k, v in CODE.items()}

#: 영상 연결 전체를 고르는 조건. `substr` 은 앞 넉 자만 본다(끝이 아니다).
MINE_WHERE = "substr(%s.link_type,1,4)='MEDI'"


def lt(scope):
    """`'ENTITY'` → `'MEDI_ENTI'`. 모르는 갈래면 None (조용히 옛 이름을 쓰지 않는다)."""
    c = CODE.get(scope)
    return ('MEDI_' + c) if c else None


# ── 구절 앵커의 내 미디어 (2026-08-27 신설 — 덮개 C 단계) ─────────────
#  `user_media_asset.verse_id` 는 처음부터 구절 앵커용 칸인데(§95차 MY 창은
#  verse_id=0 = 앵커 없음으로 용어 링크만 썼다) **쓰는 UI 가 없었다.**
#  링크 탭(links_panel)의 [+ 내 링크]가 이것을 쓴다. 연결은 통합 표
#  (`user_link_asset('MEDI_VERS')`)에도 같이 남긴다 — 링크자산·텍스트자산은
#  통합 테이블에(§95차 사용자 지시).

def user_verse_media(conn, verse_id):
    """이 구절에 내가 붙인 링크 → [{'uid','title','url','status'}] (HIDE 포함
    — 읽는 화면이 status 로 거른다)."""
    out = []
    try:
        for uid, title, url, st in conn.execute(
                'SELECT um.user_media_id, um.title, um.url, '
                "COALESCE(um.record_status,'LIVE') "
                'FROM userdb.user_media_asset um '
                'JOIN userdb.user_link_asset ul '
                '  ON ul.clicked_id=um.user_media_id '
                # ⚠⚠ **`UMED_VERS` 가 내 영상의 이름이다**(2026-09-10) —
                #   그전에는 `MEDI_VERS` 한 이름이 배포 영상과 내 영상을
                #   함께 가리켜, 번호가 겹치면 딴 영상이 뜰 자리였다.
                #   옛 이름도 함께 읽는다 — 조인이 내 영상만 맞춘다.
                "WHERE ul.link_type IN ('UMED_VERS','MEDI_VERS') "
                "  AND ul.target_id=? "
                "  AND COALESCE(ul.record_status,'LIVE')='LIVE' "
                'ORDER BY um.user_media_id', (int(verse_id),)):
            out.append({'uid': uid, 'title': title or '', 'url': url or '',
                        'status': st})
    except Exception as e:
        print('[media_link user_verse_media] %s' % e)
    return out


def add_user_verse_media(conn, verse_id, title, url):
    """구절에 내 링크를 붙인다 — (uid, 'NEW'|'REVIVED'|'DUP'|'') 반환. 멱등:
    같은 (구절, url) 이 살아 있으면 DUP, 숨겨져 있으면 되살린다."""
    url = (url or '').strip()
    if not url or not verse_id:
        return None, ''
    for u in user_verse_media(conn, verse_id):
        if u['url'] == url:
            if u['status'] == 'HIDE':
                conn.execute('UPDATE userdb.user_media_asset SET '
                             "record_status='LIVE', title=? "
                             'WHERE user_media_id=?',
                             ((title or '').strip() or u['title'], u['uid']))
                conn.commit()
                return u['uid'], 'REVIVED'
            return u['uid'], 'DUP'
    # ★ 같은 주소의 내 영상이 이미 있으면 **그 줄에 연결만** 더한다(2026-10-09 ·
    #   1.txt 58 「사용자 db에 중복이 있다면 앱의 결함」) — 그전에는 구절마다 영상
    #   줄이 하나씩 생겨 같은 주소가 여러 줄이 됐다.
    ex = conn.execute('SELECT user_media_id FROM userdb.user_media_asset WHERE url=?'
                      ' ORDER BY user_media_id', (url,)).fetchone()
    if ex:
        uid = ex[0]
        conn.execute("UPDATE userdb.user_media_asset SET record_status='LIVE'"
                     ' WHERE user_media_id=?', (uid,))
    else:
        cur = conn.execute(
            'INSERT INTO userdb.user_media_asset'
            "(title, url, verse_id, category, record_status) "
            "VALUES(?,?,?,'VERSE','LIVE')",
            ((title or '').strip() or url, url, int(verse_id)))
        uid = cur.lastrowid
    conn.execute("INSERT INTO userdb.user_link_asset(link_type, clicked_id,"
                 " target_id, record_status) VALUES('UMED_VERS', ?, ?, "
                 "'LIVE')", (uid, int(verse_id)))
    conn.commit()
    return uid, 'NEW'


def set_user_verse_media_hidden(conn, uid, hide=True):
    """내 링크 숨김/되살림 — 물리삭제가 아니다(삭제 동사 확정 전까지 MY 창
    문법과 동일). 행이 남아 [+]로 같은 URL 을 넣으면 되살아난다."""
    conn.execute('UPDATE userdb.user_media_asset SET record_status=? '
                 'WHERE user_media_id=?',
                 ('HIDE' if hide else 'LIVE', int(uid)))
    conn.commit()


def asset_url(conn, media_id):
    """영상·링크 한 줄 → `(url, 제목)`. 없으면 `(None, '')`.

    ★ 번호 하나로 주소를 찾는 **단일 문**이다 — 화면이 `sys_media_asset` 을
      직접 물으면 표가 바뀔 때마다 화면마다 고쳐야 한다(§덮개 검사기가 그
      직접 읽기를 센다).
    ⚠ 내 링크는 다른 표에 있다(`user_media_asset`) — 여기서 함께 본다.
    """
    try:
        mid = int(media_id)
    except (TypeError, ValueError):
        return None, ''
    for sql in ("SELECT url, COALESCE(title,'') FROM sys_media_asset"
                " WHERE media_id=?",
                "SELECT url, COALESCE(title,'') FROM userdb.user_media_asset"
                " WHERE user_media_id=?"):
        try:
            r = conn.execute(sql, (mid,)).fetchone()
        except Exception:
            r = None
        if r and r[0]:
            return r[0], r[1]
    return None, ''


def fav_media(conn, kind=None, pref=None, limit=300, lang=None):
    """내가 담아 둔 영상 → [(media_id, 제목, url, 설명문)] — **읽는 문 하나**.

    ★ 화면이 `sys_media_asset` 을 직접 안 읽게 하는 자리다(§121차) — 담는 표는
      `user_media_fav`, 본체는 sys 라 조인이 필요하고 그 조인은 여기 한 곳에 둔다.
    ⚠ `pref` = `media_pref.load(...)` — 주면 **내가 숨긴 영상·채널을 뺀다**
      (§226차 덮개 규칙). 안 주면 그대로 낸다.
    ⚠ **승인된 것만** 낸다(§194차 승인=연결).
    """
    # ★ 2026-10-11 — 담는 표가 ♥ 즐겨듣기(user_favorite LISTEN · 영상 번호)로 바뀌었다
    q = ("SELECT a.media_id, a.title, a.url, COALESCE(a.description,'')"
         "  FROM userdb.user_favorite f"
         "  JOIN sys_media_asset a ON substr(a.url,33,11)=f.label"
         " WHERE f.fav_type='LISTEN' AND f.record_status='LIVE'"
         "   AND a.record_status='LIVE' AND a.is_active=1")
    args = []
    if kind:
        q += " AND COALESCE(a.media_type,'')=?"
        args.append(str(kind))
    if lang:
        q += " AND UPPER(COALESCE(a.lang_code,''))=?"
        args.append(str(lang).upper())
    q += " ORDER BY f.created_at DESC, f.fav_id DESC LIMIT ?"
    args.append(int(limit))
    out = []
    for mid, ti, url, d in conn.execute(q, args).fetchall():
        if pref is not None:
            try:
                if pref.hidden(mid, d):
                    continue
            except Exception:
                pass
        out.append((mid, ti or '', url or '', d or ''))
    return out


def yt_id(url):
    """YouTube URL → video_id (아니면 None). **갈래 판정의 단일 소스** —
    유튜브 id 가 뽑히면 영상, 아니면 텍스트(재생 방식이 곧 갈래다, §95차).
    ⚠ 화면마다 정규식을 베끼지 말 것 — `entity_browser._yt_id` 도 이것이다."""
    import re
    if not url or ('youtube.com' not in url and 'youtu.be' not in url):
        return None
    m = re.search(r'(?:v=|youtu\.be/|embed/|/v/|shorts/)([\w-]{11})', url)
    return m.group(1) if m else None


#: 유튜브 썸네일 주소 크기 — `default` 120x90 · `mqdefault` 320x180
THUMB_SIZES = ('default', 'mqdefault', 'hqdefault')


def thumb_url(url, size='default'):
    """영상 주소 → 썸네일 주소. 못 읽으면 빈 글자.

    ★★★ **받아 두지 않아도 된다 — 규칙으로 나온다**(2026-09-10 실측).
      담아 둔 썸네일 125개를 전수로 대조하니 **125개 전부** 이 규칙과 글자
      그대로 같았다. 그래서 ⓐ 쿼터가 0이고 ⓑ 옛 행도 함께 산다.
    ⚠ 그전에는 담는 경로마다 따로 넣었고 **곡 수집기가 빠뜨려** 찬양 856편 중
      24편(3%)만 썸네일이 있었다 — 화면이 검은 칸으로 덮였다.
    """
    vid = yt_id(url)
    if not vid:
        return ''
    return 'https://i.ytimg.com/vi/%s/%s.jpg' % (
        vid, size if size in THUMB_SIZES else 'default')


# ── 근거 — 「이 연결은 무엇을 보고 이었나」 ───────────────────────────
#: ★★★ 사용자 지시(2026-09-10) 「나중에 연결된 것들이 과연 **가사에서 추출한
#:   것인지 임의로 만든 것인지 알 수 없을 것이다**」.
#: ⚠⚠ 실측 — 살아 있는 영상 연결 **10,000여 건 중 `source` 가 적힌 것은 343건**
#:   (오늘 넣은 주제 씨앗뿐)이었다. 나머지는 무엇을 보고 이었는지 알 길이 없다.
#: ⚠ `note` 는 **되돌리기 표식**의 자리다(`HOLD_ALL_…`·`BADLINK_…` 27,675건) —
#:   근거를 거기 적으면 두 뜻이 섞이고 `--undo` 가 근거를 지운다.
#: ⇒ **`source` 한 칸에 「무엇을 · 어디서 · 어떤 말」을 담는다.**
#:   꼴 = `<갈래>[:<줄번호>]:<걸린 말>`   보기 `TITLE:은혜` · `LYRIC:12:보혈`
SRC_KINDS = ('TITLE', 'DESC', 'LYRIC', 'SONG', 'CHANNEL', 'MANUAL',
             'SEED', 'RULE', 'INDIRECT')
_SRC_NAME = {'TITLE': '제목', 'DESC': '설명문', 'LYRIC': '가사',
             'SONG': '곡 이름', 'CHANNEL': '채널', 'MANUAL': '사람이 이음',
             'SEED': '씨앗', 'RULE': '규칙',
             # 2026-09-16 · 1.txt 18번 — 찬양→용어→구절 (db_song_indirect · 힌트 = 용어 번호)
             'INDIRECT': '용어 경유'}


def src(kind, hint='', line=None):
    """근거 글자를 만든다 → `'LYRIC:12:보혈'`.

    ⚠ **모르는 갈래는 만들지 않는다** — 오타가 새 갈래가 되면 셀 수 없다.
    ⚠ 걸린 말에 `:` 가 있으면 첫 두 자리만 갈래·줄이다(뒤는 그대로 둔다).
    """
    k = str(kind or '').upper()
    if k not in SRC_KINDS:
        raise ValueError('모르는 근거 갈래: %r' % (kind,))
    out = k
    if line is not None:
        out += ':%d' % int(line)
    h = str(hint or '').strip()
    if h:
        out += ':' + h
    return out


def parse_src(text):
    """`'LYRIC:12:보혈'` → `('LYRIC', 12, '보혈')`. 못 읽으면 `(None, None, '')`."""
    t = str(text or '').strip()
    if not t:
        return (None, None, '')
    part = t.split(':', 2)
    k = part[0].upper()
    if k not in SRC_KINDS:
        return (None, None, t)
    line, hint = None, ''
    if len(part) >= 2:
        if part[1].isdigit():
            line = int(part[1])
            hint = part[2] if len(part) > 2 else ''
        else:
            hint = ':'.join(part[1:])
    return (k, line, hint)


def src_label(text, lang='KO'):
    """근거를 사람이 읽는 말로 → `'가사 12줄 「보혈」'`. 없으면 빈 글자."""
    k, line, hint = parse_src(text)
    if not k:
        return str(text or '')
    out = _SRC_NAME.get(k, k)
    if k == 'INDIRECT':
        # 숫자는 줄이 아니라 **용어 번호**다(db_song_indirect) — 이름으로 보인다
        nm = ''
        if line is not None:
            try:
                import appdb
                with appdb.connect() as c:
                    r = c.execute(
                        "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
                        "   AND clicked_id=? AND record_status='LIVE'"
                        " ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                        (line, (lang or 'KO').upper())).fetchone()
                nm = (r[0] if r else '') or ''
            except Exception:
                nm = ''
        return out + (' 「%s」' % nm if nm else (' #%d' % line if line is not None else ''))
    if line is not None:
        out += ' %d줄' % line
    if hint:
        out += ' 「%s」' % hint
    return out


def stamp(conn, link_id, kind, hint='', line=None, table=None):
    """그 연결에 근거를 적는다 → True.

    ⚠ `note` 를 안 건드린다 — 거기는 되돌리기 표식의 자리다.
    """
    conn.execute('UPDATE %s SET source=? WHERE %s=?'
                 % (table or TBL,
                    'sys_link_id' if (table or TBL) == TBL else 'user_link_id'),
                 (src(kind, hint, line), int(link_id)))
    return True


def no_source(conn, table=None):
    """근거가 안 적힌 **살아 있는 영상 연결** 수 — 줄어드는 것을 지킨다."""
    return conn.execute(
        "SELECT COUNT(*) FROM %s WHERE substr(link_type,1,4)='MEDI'"
        "   AND COALESCE(record_status,'LIVE')='LIVE'"
        "   AND TRIM(COALESCE(source,''))=''" % (table or TBL)).fetchone()[0]


def search_media(conn, q, kind=None, lang=None, pref=None, limit=300):
    """제목으로 찾는다 → [(media_id, 제목, url, 설명문)] — **읽는 문 하나**.

    ★★★ 2026-09-10 신설 — 사용자 확정 「검색은 **지금 화면이 다루는 범위 안에서**
      제목으로 찾는다」. 성경듣기·찬양 화면에서 1단 검색창이 이 문을 부른다.
      그래서 **아무것도 안 고르고 「찬송가」만 쳐도** 그 62편이 나온다 —
      옛 찬송처럼 목록에 자리를 안 준 것에 닿는 유일한 길이다.
    ⚠ **어느 축에도 안 걸린 찬양이 26%(221편)** 다 — 검색이 그 몫을 맡는다.
    ⚠ `pref` = `media_pref.load(...)` — 내가 숨긴 것을 뺀다(§226차).
    ⚠ **승인된 것만**(§194차) · 화면이 `sys_media_asset` 을 직접 안 읽는다(§121차).
    """
    like = '%%%s%%' % (q or '').strip()
    sql = ("SELECT media_id, title, url, COALESCE(description,'')"
           "  FROM sys_media_asset"
           " WHERE record_status='LIVE' AND is_active=1"
           "   AND title LIKE ?")
    args = [like]
    if kind:
        sql += " AND COALESCE(media_type,'')=?"
        args.append(str(kind))
    if lang:
        sql += " AND UPPER(COALESCE(lang_code,''))=?"
        args.append(str(lang).upper())
    sql += ' ORDER BY title LIMIT ?'          # ★ 제목순(사용자 「알파벳순」)
    args.append(int(limit) * 3)
    out = []
    for mid, ti, url, d in conn.execute(sql, args):
        if pref is not None:
            try:
                if pref.hidden(mid, d):
                    continue
            except Exception:
                pass
        out.append((mid, ti or '', url or '', d or ''))
        if len(out) >= int(limit):
            break
    return out


def types(scopes=None):
    """`link_type IN (?,?)` 에 넣을 목록. 인자가 없으면 아는 갈래 전부."""
    if scopes is None:
        scopes = list(CODE)
    out = []
    for s in scopes:
        t = lt(s)
        if t and t not in out:
            out.append(t)
    return out


def key_int(key):
    """옛 `scope_key`(글자)를 `target_id`(숫자)로. 숫자가 아니면 None."""
    try:
        return int(str(key).strip())
    except (TypeError, ValueError):
        return None


def mine(alias='l'):
    """그 별칭의 영상 연결만 선택하는 조건절."""
    return MINE_WHERE % alias


def _raises(fn):
    """그 문이 실제로 거부하는가 — 거부해야 하는 자리를 검사로 못 박는다."""
    try:
        fn()
        return False
    except Exception:
        return True


def selftest():
    ok = fail = 0

    def t(name, cond, extra=''):
        nonlocal ok, fail
        if cond:
            ok += 1
            print('  OK   %s' % name)
        else:
            fail += 1
            print('  FAIL %s  %s' % (name, extra))

    t('ENTITY → MEDI_ENTI', lt('ENTITY') == 'MEDI_ENTI', lt('ENTITY'))
    t('PERICOPE → MEDI_PERI', lt('PERICOPE') == 'MEDI_PERI', lt('PERICOPE'))
    t('VERSE → MEDI_VERS', lt('VERSE') == 'MEDI_VERS', lt('VERSE'))
    t('모르는 갈래는 None', lt('ENTITY_WIKI') is None, lt('ENTITY_WIKI'))
    t('되읽기가 짝이 맞는다',
      all(SCOPE_OF[CODE[s]] == s for s in CODE), SCOPE_OF)
    # ★ 본문 축 셋 + 찬양 축 둘 (2026-09-09) — 개수를 못 박지 않고
    #   **CODE 표와 짝이 맞는가**를 잰다(표를 늘리면 저절로 따라온다).
    t('types() = CODE 표 전부',
      sorted(types()) == sorted('MEDI_' + c for c in CODE.values()), types())
    t('★ 본문 축 셋이 그대로 있다',
      set(types(['ENTITY', 'PERICOPE', 'VERSE']))
      == {'MEDI_ENTI', 'MEDI_PERI', 'MEDI_VERS'})
    t('types(하나)', types(['ENTITY']) == ['MEDI_ENTI'], types(['ENTITY']))
    t('types() 는 모르는 갈래를 버린다',
      types(['ENTITY', 'ENTITY_WIKI']) == ['MEDI_ENTI'],
      types(['ENTITY', 'ENTITY_WIKI']))
    t("key_int('123')", key_int('123') == 123, key_int('123'))
    t('key_int(123)', key_int(123) == 123, key_int(123))
    t("key_int(' 7 ')", key_int(' 7 ') == 7, key_int(' 7 '))
    t('key_int(글자) = None', key_int('abc') is None, key_int('abc'))
    t('key_int(None) = None', key_int(None) is None, key_int(None))
    # ⚠ 앞 넉 자로 가른다 — 끝 넉 자로 가르면 BUNT_ENTI 가 함께 걸린다
    t('mine() 은 앞 넉 자', mine('x') == "substr(x.link_type,1,4)='MEDI'", mine('x'))
    t('mine() 기본 별칭', mine() == "substr(l.link_type,1,4)='MEDI'", mine())

    # 실제 DB 로 확인 — 있으면 잰다(없어도 통과. §0-5 데이터 상태에 걸지 않는다)
    try:
        import appdb
        c = appdb.connect()
        n_all = c.execute("SELECT COUNT(*) FROM %s WHERE %s"
                          % (TBL, mine('sys_link_asset'))).fetchone()[0]
        n_sum = 0
        for ty in types():
            n_sum += c.execute(
                "SELECT COUNT(*) FROM %s WHERE link_type=?" % TBL,
                (ty,)).fetchone()[0]
        t('아는 갈래 합계 = 영상 연결 전체 (%d)' % n_all, n_all == n_sum,
          (n_all, n_sum))
        # ⚠ 끝 넉 자로 가르면 남의 연결이 섞인다 — 그것을 실제로 보인다
        bad = c.execute(
            "SELECT COUNT(*) FROM %s WHERE substr(link_type,-4)='ENTI' "
            "AND substr(link_type,1,4)<>'MEDI'" % TBL).fetchone()[0]
        t('끝 넉 자로 가르면 섞이는 것이 실제로 있다 (%d건)' % bad, bad > 0, bad)
        c.close()
    except Exception as e:
        print('  --   DB 검사 건너뜀: %s' % e)

    # ── 구절 앵커 내 미디어 — 인메모리 왕복 (실DB 불변) ──
    try:
        import sqlite3 as _s
        m = _s.connect(':memory:')
        m.execute("ATTACH ':memory:' AS userdb")
        m.execute('CREATE TABLE userdb.user_media_asset(user_media_id INTEGER '
                  'PRIMARY KEY, origin_id, verse_id, category, title, url, '
                  'description, sort_order, lang_code, record_status)')
        m.execute('CREATE TABLE userdb.user_link_asset(user_link_id INTEGER '
                  'PRIMARY KEY, link_type, clicked_id, target_id, end_id, '
                  'rel_code, sort_order, origin_id, record_status)')
        uid, how = add_user_verse_media(m, 5, '내 글', 'https://x.com/a')
        t('구절 링크 추가 = NEW', how == 'NEW' and uid, (uid, how))
        rows = user_verse_media(m, 5)
        t('읽기 — 한 줄, LIVE', len(rows) == 1
          and rows[0]['status'] == 'LIVE')
        t('★ 통합 표에도 남는다 — **내 영상은 `UMED_VERS`**', m.execute(
            "SELECT COUNT(*) FROM userdb.user_link_asset WHERE "
            "link_type='UMED_VERS' AND clicked_id=? AND target_id=5",
            (uid,)).fetchone()[0] == 1)
        _u2, how2 = add_user_verse_media(m, 5, '', 'https://x.com/a')
        t('같은 URL = DUP (멱등)', how2 == 'DUP' and _u2 == uid)
        set_user_verse_media_hidden(m, uid, True)
        t('숨기면 HIDE', user_verse_media(m, 5)[0]['status'] == 'HIDE')
        _u3, how3 = add_user_verse_media(m, 5, '다시', 'https://x.com/a')
        t('숨긴 URL 재추가 = 되살림', how3 == 'REVIVED' and _u3 == uid
          and user_verse_media(m, 5)[0]['status'] == 'LIVE')
        t('빈 URL 거부', add_user_verse_media(m, 5, 't', ' ')[0] is None)
        m.close()
    except Exception as e:
        fail += 1
        print('  FAIL 구절 링크 왕복: %s' % e)

    # 근거(source) — 무엇을 보고 이었나 (2026-09-10)
    t('★★★ 근거 글자를 만든다', src('LYRIC', '보혈', 12) == 'LYRIC:12:보혈')
    t('★ 줄 번호가 없으면 뺀다', src('TITLE', '은혜') == 'TITLE:은혜')
    t('★ 걸린 말이 없어도 된다', src('MANUAL') == 'MANUAL')
    t('★★ **모르는 갈래는 안 만든다**(오타가 새 갈래가 되면 못 센다)',
      _raises(lambda: src('WAT', 'x')))
    t('★★ 되읽는다', parse_src('LYRIC:12:보혈') == ('LYRIC', 12, '보혈'))
    t('★ 줄 없는 것도 되읽는다', parse_src('TITLE:은혜') == ('TITLE', None, '은혜'))
    t('★★ 걸린 말에 `:` 가 있어도 뒤를 안 자른다',
      parse_src('TITLE:요 3:16') == ('TITLE', None, '요 3:16'))
    t('★ 빈 것·모르는 것은 조용히 통과',
      parse_src('') == (None, None, '') and parse_src('WAT')[0] is None)
    t('★★ 사람이 읽는 말로', src_label('LYRIC:12:보혈') == '가사 12줄 「보혈」'
      and src_label('MANUAL') == '사람이 이음')

    # 썸네일 주소(2026-09-10)
    t('★★★ 영상 주소에서 썸네일 주소가 나온다',
      thumb_url('https://www.youtube.com/watch?v=xF90RWqlOu8')
      == 'https://i.ytimg.com/vi/xF90RWqlOu8/default.jpg')
    t('★ 짧은 주소와 embed 가 같은 답을 낸다',
      thumb_url('https://youtu.be/BXMI7FCEaqs')
      == thumb_url('https://www.youtube.com/embed/BXMI7FCEaqs') != '')
    t('★★ 유튜브가 아니면 **빈 글자**(엉뚱한 주소를 지어내지 않는다)',
      thumb_url('https://vimeo.com/12345') == ''
      and thumb_url('') == '' and thumb_url(None) == '')
    t('★ 모르는 크기는 기본으로 떨어진다',
      thumb_url('https://youtu.be/BXMI7FCEaqs', 'wat').endswith('/default.jpg'))
    t('★ 큰 그림도 낼 수 있다',
      thumb_url('https://youtu.be/BXMI7FCEaqs', 'mqdefault')
      .endswith('/mqdefault.jpg'))

    print('\nmedia_link selftest %d/%d' % (ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
    sys.exit(0 if selftest() else 1)
