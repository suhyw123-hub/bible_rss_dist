# -*- coding: utf-8 -*-
"""db_book_source_seed.py — 확인한 출처를 **DB 에** 남긴다 (영구 · `--selftest`)

`python db_book_source_seed.py --selftest`  — 의무
`python db_book_source_seed.py --apply`     — 적재 (멱등)
`python db_book_source_seed.py --list [코드]` — 지금 담긴 것

★ 사용자 지시(2026-08-22): 「db의 어디에든지 관리자가 볼 수 있도록 url을
  추가하자. 네가 나중에 확인할 수 있도록 하자. **파일로 저장하는 것은
  불완전하다**」.
  ⇒ `_verify_raw/` 의 내려받은 파일이나 세션 기록에 기대지 않는다. 어디서
    받았고 무엇과 대조했고 **무엇을 왜 버렸는지**를 표 한 곳에 남긴다.
    관리자 화면 = 데이터 관리 ▸ 테이블 관리 ▸ `sys_book_source`.

역할 셋
  · `PRIMARY`  본문을 실제로 받은 곳
  · `CROSS`    대조에 쓴 곳(두 곳 대조 규칙 §0-1b ②)
  · `REJECTED` 버린 후보 — **왜 버렸는지 note 에 적는다**(같은 삽질 방지)

⚠ `match_pct` 는 **DB 본문 ↔ 그 원문**의 문장 일치다(`db_book_verify`).
  CROSS 줄에는 원문끼리의 낮은 쪽 값을 적는다.
"""
import sys

sys.path.insert(0, __file__.rsplit('\\', 1)[0] if '\\' in __file__ else '.')
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import appdb
import db_book_source_match as SM

DB = 'bible_master.db'
DAY = '2026-08-22'

# (책, 역할, 이름, 주소, 메모, 일치율)
SOURCES = [
    # ── 바운즈 — 위작을 걷어내고 다시 받은 것 ──────────────────────────────
    ('BOUNDS_PTP', 'PRIMARY', 'Project Gutenberg #65115',
     'https://www.gutenberg.org/ebooks/65115',
     'Marshall Brothers 제12판. 위작 41행을 걷고 여기서 20장을 받았다.', 98),
    ('BOUNDS_PTP', 'CROSS', 'CCEL bounds/power',
     'https://ccel.org/ccel/bounds/power/cache/power.txt', '', 100),
    ('BOUNDS_PTP', 'REJECTED', 'Project Gutenberg #16905',
     'https://www.gutenberg.org/ebooks/16905',
     '옛 기록의 번호 — 실제로는 『The Great Red Frog』라는 딴 책이다.', None),

    # ── 로렌스 — 발췌본을 전문으로 갈아 끼운 것 ────────────────────────────
    ('LAWRENCE_PPG', 'PRIMARY', 'Internet Archive — Revell 1895 스캔',
     'https://archive.org/details/practiceofpresen00lawriala',
     '판권장 Copyright, 1895, by FLEMING H. REVELL COMPANY · '
     'Translated from the French · 서문 한나 위톨 스미스. 대화 4 + 편지 15.', 92),
    ('LAWRENCE_PPG', 'CROSS', 'Internet Archive — dli 1895 스캔',
     'https://archive.org/details/in.ernet.dli.2015.209844',
     '같은 Revell 1895 판을 따로 스캔한 것. 두 스캔 84% 일치.', 91),
    ('LAWRENCE_PPG', 'REJECTED', 'Project Gutenberg #5657',
     'https://www.gutenberg.org/ebooks/5657',
     '★ 파일 머리에 `** This is a COPYRIGHTED Project Gutenberg eBook **` · '
     '`Copyright (C) 2002 by Lightheart.` — 저작권이 살아 있는 2002년 편집본.'
     ' 퍼블릭 도메인이 아니다.', None),
    ('LAWRENCE_PPG', 'REJECTED', 'Project Gutenberg #13790',
     'https://www.gutenberg.org/ebooks/13790',
     '옛 기록의 번호 — 내려받아지지 않는다. 근거 없는 기록이었다.', None),

    # ── 머레이 ────────────────────────────────────────────────────────────
    ('MURRAY_AIC', 'PRIMARY', 'Internet Archive — Fleming H. Revell 스캔',
     'https://archive.org/details/abideinchristtho00murr_0',
     '받아 온 파일이 무엇이었는지는 기록이 없다. 이 스캔과 문장 89% 일치해 '
     '진본으로 확인했다.', 89),
    ('MURRAY_AIC', 'CROSS', 'Internet Archive — Altemus 1895 스캔',
     'https://archive.org/details/abideinchrist01murr', '두 스캔 80% 일치.', 87),
    ('MURRAY_AIC', 'REJECTED', 'CCEL murray/abide',
     'https://ccel.org/ccel/murray/abide',
     '★ 옛 기록의 주소 — **404**. CCEL 저자 목록에 이 책이 없다.', None),

    # ── 밀러 ──────────────────────────────────────────────────────────────
    ('MILLER_CYA', 'PRIMARY', 'Internet Archive — Solid Ground 재인쇄본 스캔',
     'https://archive.org/details/isbn_9781599252070',
     '문장 100% 일치 — 여기서 왔다. 첫 편 제목이 ISBN 인 까닭이 이것이다. '
     '원저는 1888년판이라 퍼블릭 도메인.', 100),
    ('MILLER_CYA', 'CROSS', 'Internet Archive — Thomas Nelson 판 스캔',
     'https://archive.org/details/bwb_S0-ADX-303', '두 스캔 93% 일치.', 92),
    ('MILLER_CYA', 'REJECTED', 'CCEL miller/comeyeapart',
     'https://ccel.org/ccel/miller/comeyeapart',
     '★ 옛 기록의 주소 — **404**. CCEL 에는 miller/history 뿐이다.', None),

    # ── 마이어 ────────────────────────────────────────────────────────────
    # ★ 2026-08-22 — 다섯 권 전권 적재(사용자 「네 권 다 담아라」). 71편 → 301편.
    # ★ 2026-08-22 재적재 — 성경 한 장에 한 편, 한 쪽에 한 편(1,189편).
    #   전수 대조 1,188/1,189. 판권장 v1~v3 = 1898 · v5 = 1899, Revell.
    ('MEYER_ODH', 'PRIMARY', 'Internet Archive — 1898 제1권 (창세기~룻기)',
     'https://archive.org/details/ourdailyhomily01meye', '236편 (성경 236장).', 100),
    ('MEYER_ODH', 'PRIMARY', 'Internet Archive — 1898 제2권 (사무엘상~욥기)',
     'https://archive.org/details/ourdailyhomily02meye', '242편 (성경 242장).', 100),
    ('MEYER_ODH', 'PRIMARY', 'Internet Archive — 1898 제3권 (시편~아가)',
     'https://archive.org/details/ourdailyhomily03meye', '201편 (성경 201장).', 100),
    ('MEYER_ODH', 'PRIMARY', 'Internet Archive — 1898 제4권 (이사야~말라기)',
     'https://archive.org/details/ourdailyhomily04meye', '250편 (성경 250장).', 100),
    ('MEYER_ODH', 'PRIMARY', 'Internet Archive — 1899 제5권 (마태~계시록)',
     'https://archive.org/details/ourdailyhomily05meye',
     '260편 (성경 260장). 처음부터 담겨 있던 권이며 옛 71편의 `unit_id` 를 지켰다.', 100),
    ('MEYER_ODH', 'REJECTED', 'CCEL meyer/homily2',
     'https://ccel.org/ccel/meyer/homily2',
     'CCEL 에는 제2권(사무엘상~욥기)만 글이 있다 — 우리가 쓰는 제5권이 아니다. '
     '`meyer/homily` 는 글이 아니라 **전집 안내 페이지**다(txt 404).', None),
    ('MEYER_ODH', 'REJECTED', 'Internet Archive — 1955 마태~계시록',
     'https://archive.org/details/ourdailyhomilyma0000fbme',
     '대출 제한(access-restricted-item)이라 본문을 못 받는다. 1951·1957·1966년 '
     '재인쇄본도 모두 대출 제한. ⇒ **제5권은 원문이 한 곳뿐**이고, 그 한 곳과 '
     '94% 일치한다(남은 6%는 줄끝 하이픈 차이 — 우리 글이 그 스캔을 다듬은 '
     '것이라는 증거다). 2026-08-22 전수 탐색으로 확인.', None),

    # ── 번연 ──────────────────────────────────────────────────────────────
    ('BUNYAN_GRACE', 'PRIMARY', 'Project Gutenberg #654',
     'https://www.gutenberg.org/ebooks/654',
     '문장 100% 일치 — 여기서 왔다. 전사: 1905 The Religious Tract Society '
     '판, David Price. 미러 aleph.gutenberg.org/6/5/654/654-0.txt', 100),
    ('BUNYAN_GRACE', 'CROSS', 'CCEL bunyan/grace',
     'https://ccel.org/ccel/bunyan/grace/cache/grace.txt',
     '판이 달라 66% — 같은 책 확인용.', 66),
    ('BUNYAN_GRACE', 'REJECTED', 'Project Gutenberg #4186',
     'https://www.gutenberg.org/ebooks/4186',
     '★ 옛 기록의 번호 — 실제로는 『Diary of Samuel Pepys — Volume 62』'
     '(새뮤얼 피프스)다. 바운즈 #16905 와 같은 꼴.', None),

    ('BUNYAN_PP', 'PRIMARY', 'Project Gutenberg #131 (제1부)',
     'https://www.gutenberg.org/ebooks/131',
     '제1부 문장 99% 일치. 미러 aleph.gutenberg.org/1/3/131/131-0.txt', 99),
    ('BUNYAN_PP', 'PRIMARY', 'Project Gutenberg #6048 (제2부)',
     'https://www.gutenberg.org/ebooks/6048',
     '★ Works of John Bunyan 제3권. **제2부는 여기서 왔다**(문장 100% 일치) '
     '— `source_url` 한 칸에는 담기지 않던 사실이다.', 100),
    ('BUNYAN_PP', 'CROSS', 'CCEL bunyan/pilgrim',
     'https://ccel.org/ccel/bunyan/pilgrim/cache/pilgrim.txt',
     '판이 달라 1부 92% · 2부 54%.', 69),

    # ── 셸던 ──────────────────────────────────────────────────────────────
    ('SHELDON_IHS', 'PRIMARY', 'Project Gutenberg #4540',
     'https://www.gutenberg.org/ebooks/4540',
     '문장 100% 일치. 미러 aleph.gutenberg.org/4/5/4/4540/4540-0.txt. '
     '본문 머리에 남아 있던 장 번호 조각 14개(`teen`·`-one` …)를 걷었다.', 100),
    ('SHELDON_IHS', 'CROSS', 'CCEL sheldon/ihsteps',
     'https://ccel.org/ccel/sheldon/ihsteps/cache/ihsteps.txt',
     '두 곳 대조 100%/98%.', 100),
    ('SHELDON_IHS', 'REJECTED', 'Project Gutenberg #289',
     'https://www.gutenberg.org/ebooks/289',
     '★ 옛 기록의 번호 — 실제로는 『The Wind in the Willows』(케네스 그레이엄)'
     '다. DB 본문과 0% 일치. 바운즈 #16905 · 번연 #4186 과 같은 꼴.', None),

    # ── 로 · 뮐러 · 반다이크 (2026-08-22 전수 점검에서 번호 오류 발견) ──────
    ('LAW_SCDHL', 'PRIMARY', 'CCEL law/serious_call',
     'https://ccel.org/ccel/law/serious_call',
     '문장 99% 일치. 이 책은 구텐베르크에 없다.', 99),
    ('LAW_SCDHL', 'REJECTED', 'Project Gutenberg #1606',
     'https://www.gutenberg.org/ebooks/1606',
     '★ 옛 기록의 번호 — 실제로는 월터 스콧의 『Kenilworth』다.', None),
    ('MULLER_ATP', 'PRIMARY', 'Project Gutenberg #25891',
     'https://www.gutenberg.org/ebooks/25891',
     '문장 100% 일치. 미러 파일 이름은 `25891-8.txt` 다(-0 은 없다).', 100),
    ('MULLER_ATP', 'REJECTED', 'Project Gutenberg #10388',
     'https://www.gutenberg.org/ebooks/10388',
     '★ 옛 기록의 번호 — 실제로는 『A Collection of Old English Plays 제1권』.',
     None),
    ('VANDYKE_OWM', 'PRIMARY', 'Project Gutenberg #10679',
     'https://www.gutenberg.org/ebooks/10679', '문장 100% 일치.', 100),
    ('VANDYKE_OWM', 'REJECTED', 'Project Gutenberg #5050',
     'https://www.gutenberg.org/ebooks/5050',
     '★ 옛 기록의 번호 — 실제로는 『State of the Union Addresses (1790-2008)』.',
     None),

    # ── 2026-08-22 전권 점검 — 나머지 24권 (전부 진본) ─────────────────────
    ('AUGUSTINE_CONF', 'PRIMARY', 'Project Gutenberg #3296',
     'https://www.gutenberg.org/ebooks/3296', '문장 100%. Pusey 영역.', 100),
    ('KEMPIS_IOC', 'PRIMARY', 'Project Gutenberg #1653',
     'https://www.gutenberg.org/ebooks/1653',
     '문장 100%. Benham 1874년 영역.', 100),
    ('LUTHER_FOC', 'PRIMARY', 'Project Gutenberg #1911',
     'https://www.gutenberg.org/ebooks/1911',
     '문장 100%. 미러 파일 이름은 `1911.txt`.', 100),
    ('MACLAREN_DAVID', 'PRIMARY', 'Project Gutenberg #21872',
     'https://www.gutenberg.org/ebooks/21872',
     '문장 100%. 미러 파일 이름은 `21872-8.txt`.', 100),
    ('PASCAL_PENSEES', 'PRIMARY', 'Project Gutenberg #18269',
     'https://www.gutenberg.org/ebooks/18269', '문장 100%. Trotter 영역.', 100),
    ('CLEMENT_1ST', 'PRIMARY', 'CCEL lightfoot/fathers',
     'https://ccel.org/ccel/lightfoot/fathers/cache/fathers.txt',
     '사도교부 다섯 권이 **한 파일**에 들어 있다. 문장 100%.', 100),
    ('DIDACHE', 'PRIMARY', 'CCEL lightfoot/fathers',
     'https://ccel.org/ccel/lightfoot/fathers/cache/fathers.txt', '문장 100%.',
     100),
    ('DIOGNETUS', 'PRIMARY', 'CCEL lightfoot/fathers',
     'https://ccel.org/ccel/lightfoot/fathers/cache/fathers.txt', '문장 100%.',
     100),
    ('HERMAS_SHEPHERD', 'PRIMARY', 'CCEL lightfoot/fathers',
     'https://ccel.org/ccel/lightfoot/fathers/cache/fathers.txt', '문장 100%.',
     100),
    ('IGNATIUS_LETTERS', 'PRIMARY', 'CCEL lightfoot/fathers',
     'https://ccel.org/ccel/lightfoot/fathers/cache/fathers.txt', '문장 100%.',
     100),
    ('POLYCARP_PHIL', 'PRIMARY', 'CCEL lightfoot/fathers',
     'https://ccel.org/ccel/lightfoot/fathers/cache/fathers.txt', '문장 99%.',
     99),
    ('EDERSHEIM_JSL', 'PRIMARY', 'CCEL edersheim/sketches',
     'https://ccel.org/ccel/edersheim/sketches/cache/sketches.txt',
     '문장 100%.', 100),
    ('EDERSHEIM_LT', 'PRIMARY', 'CCEL edersheim/lifetimes',
     'https://ccel.org/ccel/edersheim/lifetimes/cache/lifetimes.txt',
     '문장 99% (16,555/16,683).', 99),
    ('EDERSHEIM_TMP', 'PRIMARY', 'CCEL edersheim/temple',
     'https://ccel.org/ccel/edersheim/temple/cache/temple.txt', '문장 100%.',
     100),
    ('SMITH_CSHL', 'PRIMARY', 'CCEL smith_hw/secret',
     'https://ccel.org/ccel/smith_hw/secret/cache/secret.txt', '문장 100%.',
     100),
    ('SPURGEON_AOG', 'PRIMARY', 'CCEL spurgeon/grace',
     'https://ccel.org/ccel/spurgeon/grace/cache/grace.txt', '문장 100%.', 100),
    ('WESLEY_SERMONS', 'PRIMARY', 'CCEL wesley/sermons',
     'https://ccel.org/ccel/wesley/sermons/cache/sermons.txt', '문장 95%.', 95),
    ('WHITEFIELD_SERMONS', 'PRIMARY', 'CCEL whitefield/sermons',
     'https://ccel.org/ccel/whitefield/sermons/cache/sermons.txt',
     '문장 96%.', 96),
    ('EDWARDS_SERMONS', 'PRIMARY', 'CCEL edwards — Select Sermons + 전집 1·2권',
     'https://ccel.org/ccel/edwards/sermons/cache/sermons.txt',
     '★ 일곱 편이 **세 파일에 나뉘어** 있다 — Select Sermons(1·2·4·5) · '
     'works1(3 Ruth’s Resolution · 7 Farewell) · works2(6). 한 파일만 보면 '
     '53% 로 나와 위작처럼 보인다. 셋을 합치면 93~98%.', 98),
    ('EDWARDS_SERMONS', 'CROSS', 'CCEL edwards/works1',
     'https://ccel.org/ccel/edwards/works1/cache/works1.txt', '', 97),
    ('EDWARDS_SERMONS', 'CROSS', 'CCEL edwards/works2',
     'https://ccel.org/ccel/edwards/works2/cache/works2.txt', '', 95),
    # 편마다 페이지가 따로인 곳 — 표본으로 확인했다(§21-2b 표본 원칙)
    ('FINNEY_SERMONS', 'PRIMARY', 'Gospel Truth Ministries — 1836SOIS',
     'https://www.gospeltruth.net/1836SOIS/indexsois.htm',
     '표본 4편 99~100%. 설교마다 페이지가 따로다(`01sois_…htm` 꼴).', 100),
    ('SPURGEON_SW', 'PRIMARY', 'The Spurgeon Archive — sw01~sw15',
     'https://archive.spurgeon.org/misc/soulwinr.php',
     '표본 3편: 4편 100% · 15편 100% · 13편 79%(그 서버가 문장 중간에서 잘라 '
     '주어 미러에서 받았던 편 — 문서화된 사례).', 100),
    ('SPURGEON_TOD', 'PRIMARY', 'The Spurgeon Archive — treasury/psNNN',
     'https://archive.spurgeon.org/treasury/treasury.php',
     '도서 본문 = TREASURY 주석 **150/150편 일치**(복사본). 그 주석을 원본과 '
     '대조한 표본 3편(시 1·23·100) 전부 100%.', 100),
    ('SPURGEON_SERMONS', 'PRIMARY', 'The Spurgeon Center',
     'https://www.spurgeon.org/resource-library/sermons/',
     '표본 3편 87~91%(No.1 · 500 · 1804). 설교마다 페이지가 따로다.', 91),

    # ── 스펄전 아침과 저녁 ────────────────────────────────────────────────
    ('SPURGEON_ME', 'PRIMARY', 'CCEL spurgeon/morneve',
     'https://ccel.org/ccel/spurgeon/morneve',
     '732편. 적재 도구가 여기서 받는다. 문장 100%.', 100),
    ('SPURGEON_ME', 'REJECTED', 'Project Gutenberg #24804',
     'https://www.gutenberg.org/ebooks/24804',
     '옛 기록의 주소 — 실제로 받은 곳은 CCEL 이다.', None),
]


def apply(conn):
    SM.init_source_table(conn)
    for code, role, name, url, note, pct in SOURCES:
        SM.record_source(conn, code, role, name, url, note, pct, DAY)
    return len(SOURCES)


def _selftest():
    fails = []

    def ck(n, ok, got=''):
        print(('  OK  ' if ok else '  FAIL') + ' ' + n +
              ('  | ' + str(got) if got != '' else ''))
        if not ok:
            fails.append(n)

    ck('역할이 셋 중 하나', all(r in SM.ROLES for _, r, _, _, _, _ in SOURCES))
    ck('주소가 다 있다', all(u.startswith('http')
                        for _, _, _, u, _, _ in SOURCES))
    ck('버린 후보에는 이유가 있다',
       all(bool(n.strip()) for _, r, _, _, n, _ in SOURCES if r == 'REJECTED'))
    codes = {c for c, _, _, _, _, _ in SOURCES}
    ck('책마다 PRIMARY 가 있다',
       all(any(c == x and r == 'PRIMARY' for x, r, _, _, _, _ in SOURCES)
           for c in codes), sorted(codes))
    ck('같은 책에 같은 주소가 두 번 없다',
       len({(c, u) for c, _, _, u, _, _ in SOURCES}) == len(SOURCES))

    conn = appdb.connect(DB)
    # 책 코드가 실재하는가
    have = {r[0] for r in conn.execute("SELECT book_code FROM sys_book_asset")}
    miss = sorted(codes - have)
    ck('없는 책 코드 0', not miss, miss)
    # 실 DB 왕복 — 되돌린다
    SM.init_source_table(conn)
    conn.commit()
    before = conn.execute("SELECT COUNT(*) FROM %s" % SM.SRC_TABLE).fetchone()[0]
    conn.execute('BEGIN')
    apply(conn)
    mid = conn.execute("SELECT COUNT(*) FROM %s" % SM.SRC_TABLE).fetchone()[0]
    conn.rollback()
    after = conn.execute("SELECT COUNT(*) FROM %s" % SM.SRC_TABLE).fetchone()[0]
    ck('넣으면 늘고', mid >= len(SOURCES), mid)
    ck('되돌리면 그대로', before == after, '%d → %d' % (before, after))
    conn.close()
    print('\n=== %s (%d fail) ===' %
          ('PASS' if not fails else 'FAIL: ' + ', '.join(fails), len(fails)))
    return 0 if not fails else 1


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        raise SystemExit(_selftest())
    conn = appdb.connect(DB)
    if '--list' in a:
        code = None
        i = a.index('--list')
        if i + 1 < len(a) and not a[i + 1].startswith('-'):
            code = a[i + 1]
        for row in SM.list_sources(conn, code):
            print('  %-14s %-9s %-3s%% %s' %
                  (row[0], row[1],
                   row[5] if row[5] is not None else '  -', row[3]))
            print('        %s' % (row[2] or ''))
            if row[4]:
                print('        %s' % row[4])
        conn.close()
        return
    if '--apply' in a:
        conn.execute('BEGIN')
        n = apply(conn)
        conn.commit()
        print('출처 %d줄 적재 (%s)' % (n, SM.SRC_TABLE))
        conn.close()
        return
    conn.close()
    print(__doc__)


if __name__ == '__main__':
    main()
