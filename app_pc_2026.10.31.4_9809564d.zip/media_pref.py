# -*- coding: utf-8 -*-
"""
media_pref.py — 영상·링크에 대한 **사용자 취향**(즐겨찾기·숨기기·신고)
--------------------------------------------------------------------
0.txt 1번(링크 피드백)의 저장소. 사용자가 목록에서 영상을 만났을 때
다섯 가지를 할 수 있게 한다:

  1) 이 영상 즐겨찾기        → `user_media_fav` (**이미 있던 것** — 여기서 안 다룬다)
  2) 이 채널 즐겨찾기        → `user_channel_fav`
  3) 이 영상 숨기기          → `user_media_hide`
  4) 이 채널 숨기기          → `user_channel_hide`
  5) 신고                    → `user_media_report` + 문의·지원 통로로 전송

★ **숨기기는 그 노트북에서만이다** (2026-08-21 사용자 확정). 전부 `userdb`
  에 남고 서버로 나가지 않는다. 밖으로 나가는 것은 5) 신고뿐이다.

★ **채널은 이름으로 다룬다.** `sys_media_asset` 에 채널 칼럼이 없지만
  `description` 이 JSON 이고 그 안에 채널 이름이 있다(실측 11,292/11,321 ·
  채널 3,163개). 나중에 채널 ID 를 채우면 그때 열쇠만 옮기면 된다.
  ⚠ 그때까지는 **동명 채널이 같이 묶인다** — 이름이 열쇠이기 때문이다.

⚠ **거르기는 SQL 이 아니라 파이썬에서** 한다. 채널이 JSON 안에 있어
  `LIKE '%"channel": "…"%'` 로 거르면 이름에 따옴표·이스케이프가 든 채널에서
  조용히 어긋난다. 목록을 만들 때 `Pref.hidden(mid, desc)` 로 거른다.

`python media_pref.py --selftest` — 의무.
"""
import json
import appdb

_DDL = (
    "CREATE TABLE IF NOT EXISTS userdb.user_channel_fav ("
    " channel_name TEXT PRIMARY KEY, created_at TEXT DEFAULT (datetime('now')))",
    "CREATE TABLE IF NOT EXISTS userdb.user_media_hide ("
    " media_id INTEGER PRIMARY KEY, created_at TEXT DEFAULT (datetime('now')))",
    "CREATE TABLE IF NOT EXISTS userdb.user_channel_hide ("
    " channel_name TEXT PRIMARY KEY, created_at TEXT DEFAULT (datetime('now')))",
    "CREATE TABLE IF NOT EXISTS userdb.user_media_report ("
    " report_id INTEGER PRIMARY KEY AUTOINCREMENT,"
    " media_id INTEGER, channel_name TEXT, title TEXT, url TEXT, reason TEXT,"
    " sent INTEGER DEFAULT 0, created_at TEXT DEFAULT (datetime('now')))",
)


def _conn(db_path=None):
    """⚠ `appdb.connect(None)` 은 userdb 를 붙이지 않는다 — 기본 DB 로 바꿔 준다
    (실측: `unknown database userdb`)."""
    return appdb.connect(db_path or appdb.MAIN_DB)


def init(conn):
    """표가 없으면 만든다(멱등). 화면이 처음 쓸 때 스스로 부른다."""
    for sql in _DDL:
        conn.execute(sql)
    conn.commit()


def channel_of(description):
    """description JSON 에서 채널 이름. 없으면 ''.

    ⚠ `media_list_view.channel_of` 와 같은 일을 한다 — 그쪽은 화면 표시용이고
      여기는 저장 열쇠용이라, 표시 규칙이 바뀌어도 저장 열쇠가 흔들리지 않게
      **일부러 따로 둔다**(예: 표시 쪽이 길이를 자르더라도 열쇠는 원본)."""
    if not description:
        return ''
    try:
        j = json.loads(description)
    except Exception:
        return ''
    if not isinstance(j, dict):
        return ''
    return str(j.get('channel') or '').strip()


class Pref:
    """한 번 읽어 두고 목록을 만드는 동안 되풀이해 묻는 꾸러미."""

    def __init__(self, hide_m=None, hide_c=None, fav_c=None):
        self.hide_m = set(hide_m or ())
        self.hide_c = set(hide_c or ())
        self.fav_c = set(fav_c or ())

    def hidden(self, media_id, description=None, channel=None):
        if media_id is not None and int(media_id) in self.hide_m:
            return True
        ch = channel if channel is not None else channel_of(description)
        return bool(ch) and ch in self.hide_c

    def fav_channel(self, description=None, channel=None):
        ch = channel if channel is not None else channel_of(description)
        return bool(ch) and ch in self.fav_c

    def count(self):
        return len(self.hide_m) + len(self.hide_c)


def load(db_path=None):
    """지금 숨김·채널찜 상태를 한 번에 읽는다. 표가 없으면 빈 꾸러미."""
    try:
        with _conn(db_path) as conn:
            init(conn)
            hm = {r[0] for r in conn.execute("SELECT media_id FROM user_media_hide")}
            hc = {r[0] for r in conn.execute("SELECT channel_name FROM user_channel_hide")}
            fc = {r[0] for r in conn.execute("SELECT channel_name FROM user_channel_fav")}
        return Pref(hm, hc, fc)
    except Exception:
        return Pref()


def _toggle(db_path, table, col, val):
    """있으면 지우고 없으면 넣는다 → 새 상태(bool)."""
    if val in (None, ''):
        return False
    with _conn(db_path) as conn:
        init(conn)
        row = conn.execute("SELECT 1 FROM %s WHERE %s=?" % (table, col), (val,)).fetchone()
        if row:
            conn.execute("DELETE FROM %s WHERE %s=?" % (table, col), (val,))
            conn.commit()
            return False
        conn.execute("INSERT INTO %s(%s) VALUES(?)" % (table, col), (val,))
        conn.commit()
        return True


def toggle_media_hide(db_path, media_id):
    return _toggle(db_path, 'user_media_hide', 'media_id', media_id)


def toggle_channel_hide(db_path, channel_name):
    return _toggle(db_path, 'user_channel_hide', 'channel_name', channel_name)


def toggle_channel_fav(db_path, channel_name):
    return _toggle(db_path, 'user_channel_fav', 'channel_name', channel_name)


def unhide_all(db_path):
    with _conn(db_path) as conn:
        init(conn)
        conn.execute("DELETE FROM user_media_hide")
        conn.execute("DELETE FROM user_channel_hide")
        conn.commit()


def hidden_list(db_path):
    """숨김 관리 팝업용 — [('MEDIA', id, 제목, 채널), ('CHANNEL', 이름, '', 이름)]"""
    out = []
    with _conn(db_path) as conn:
        init(conn)
        for mid, in conn.execute("SELECT media_id FROM user_media_hide ORDER BY created_at DESC"):
            r = conn.execute("SELECT title, description FROM sys_media_asset "
                             "WHERE media_id=?", (mid,)).fetchone()
            out.append(('MEDIA', mid, (r[0] if r else '') or '',
                        channel_of(r[1]) if r else ''))
        for ch, in conn.execute("SELECT channel_name FROM user_channel_hide ORDER BY created_at DESC"):
            out.append(('CHANNEL', ch, '', ch))
    return out


def report(db_path, media_id, title, url, description='', reason=''):
    """신선택할 **로컬에 남기고** 문의·지원 통로로 보낸다.

    ★ 새 서버를 만들지 않는다 — 이미 있는 `user_feedback`(Apps Script)이
      같은 일을 한다. 전송이 실패해도 로컬 행은 남으므로 다음에 다시 보낸다.
    반환 (저장됨, 전송됨)."""
    ch = channel_of(description)
    with _conn(db_path) as conn:
        init(conn)
        conn.execute("INSERT INTO user_media_report(media_id, channel_name, title, url, reason)"
                     " VALUES(?,?,?,?,?)", (media_id, ch, title or '', url or '', reason or ''))
        conn.commit()
        rid = conn.execute("SELECT last_insert_rowid()").fetchone()[0]
    sent = False
    try:
        import user_feedback
        body = ("[영상 신고]\n제목: %s\n채널: %s\nURL: %s\nmedia_id: %s\n사유: %s"
                % (title or '', ch, url or '', media_id, reason or ''))
        # ⚠ `submit` 은 **연결 객체**를 받고 `(ok, err)` 튜플을 돌려준다
        #   (dict 가 아니다 — 실측으로 확인).
        with _conn(db_path) as conn2:
            ok2, _err = user_feedback.submit(conn2, 'OTHER', body)
        sent = bool(ok2)
    except Exception:
        sent = False
    if sent:
        with _conn(db_path) as conn:
            conn.execute("UPDATE user_media_report SET sent=1 WHERE report_id=?", (rid,))
            conn.commit()
    return True, sent


# ── 자가 검증 ────────────────────────────────────────────────────────────
def _selftest():
    ok = True

    def chk(name, cond):
        nonlocal ok
        print(('  PASS ' if cond else '  FAIL ') + name)
        ok = ok and bool(cond)

    print('media_pref selftest')
    chk('channel_of 정상', channel_of('{"channel": "홍익학당", "published": "2020"}') == '홍익학당')
    chk('channel_of 빈값', channel_of('') == '' and channel_of('not json') == '')
    chk('channel_of dict 아님', channel_of('[1,2]') == '')

    p = Pref({1, 2}, {'나쁜채널'}, {'좋은채널'})
    chk('영상 숨김', p.hidden(1) is True)
    chk('안 숨긴 영상', p.hidden(3, '{"channel":"보통"}') is False)
    chk('채널 숨김', p.hidden(9, '{"channel":"나쁜채널"}') is True)
    chk('채널 찜', p.fav_channel('{"channel":"좋은채널"}') is True)
    chk('개수', p.count() == 3)

    # 실제 DB 왕복 — 시험 값은 반드시 되돌린다
    import appdb as _a
    with _a.connect() as conn:
        init(conn)
        before = conn.execute("SELECT COUNT(*) FROM user_channel_hide").fetchone()[0]
    name = '__selftest_channel__'
    chk('토글 켜기', toggle_channel_hide(None, name) is True)
    chk('로드에 반영', name in load(None).hide_c)
    chk('토글 끄기', toggle_channel_hide(None, name) is False)
    chk('로드에서 사라짐', name not in load(None).hide_c)
    with _a.connect() as conn:
        after = conn.execute("SELECT COUNT(*) FROM user_channel_hide").fetchone()[0]
    chk('잔재 없음', before == after)
    print('RESULT:', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        raise SystemExit(_selftest())
    print(__doc__)
