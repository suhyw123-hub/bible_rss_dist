"""
voice_test_popup.py  —  녹음 환경 점검

VoiceTestFrame : 재사용 가능한 환경점검 위젯 (tk.Frame, 어디에나 embed 가능)
VoiceTestPopup : 독립 팝업 래퍼 (tk.Toplevel)
"""
import importlib
import i18n
import subprocess
import sys
import tempfile
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import ttk

# ── 상수 ──────────────────────────────────────────────────────────────────────
_PIP_PKGS = [
    ("sounddevice", "sounddevice"),
    ("soundfile",   "soundfile"),
    ("numpy",       "numpy"),
]
_FFMPEG_WINGET = "winget install --id Gyan.FFmpeg -e"

BG     = "#1C2833"
BG2    = "#212F3D"
BG_HDR = "#17202A"
FG     = "#ECF0F1"
FG_DIM = "#AEB6BF"
GREEN  = "#27AE60"
RED    = "#E74C3C"
BLUE   = "#1A5276"
ORANGE = "#F0B27A"

SAMPLERATE = 44100
TEST_SEC   = 3


# ── 공개 API ──────────────────────────────────────────────────────────────────

def open_voice_test_popup(parent):
    """독립 팝업으로 환경점검을 연다 (하위 호환용)."""
    VoiceTestPopup(parent)


# ── 환경점검 위젯 (재사용 가능 Frame) ─────────────────────────────────────────

class VoiceTestFrame(tk.Frame):
    """녹음 환경점검 내용 위젯 — Frame으로 어느 컨테이너에나 embed 가능."""

    def __init__(self, parent):
        super().__init__(parent, bg=BG)
        self._mic_stream  = None
        self._mic_level   = 0.0
        self._mic_active  = False
        self._lib_rows: dict[str, dict] = {}
        self._build()
        self.after(100, self._run_lib_checks)

    def _build(self):
        self._build_lib_section()
        tk.Frame(self, bg="#2E4053", height=1).pack(fill="x", padx=10, pady=4)
        self._build_mic_section()
        tk.Frame(self, bg="#2E4053", height=1).pack(fill="x", padx=10, pady=4)
        self._build_test_section()

    def cleanup(self):
        """Frame 숨기기/해제 전 호출 — 마이크 스트림 정리."""
        self._stop_mic()

    # ── ① 라이브러리 점검 ────────────────────────────────────────────────────

    def _build_lib_section(self):
        sec = tk.LabelFrame(self, text=i18n.t('VTP_S1',' ① 라이브러리 점검 '),
                            bg=BG, fg=FG_DIM,
                            font=("Malgun Gothic", 9), padx=10, pady=6)
        sec.pack(fill="x", padx=10, pady=(8, 0))

        for display, pkg in _PIP_PKGS:
            row = tk.Frame(sec, bg=BG)
            row.pack(fill="x", pady=2)
            tk.Label(row, text=display, bg=BG, fg=FG,
                     font=("Malgun Gothic", 9), width=12, anchor="w"
                     ).pack(side="left")
            lbl = tk.Label(row, text=i18n.t('VTP_CHECKING','점검 중...'), bg=BG, fg=ORANGE,
                           font=("Malgun Gothic", 9), width=10, anchor="w")
            lbl.pack(side="left", padx=6)
            btn = tk.Button(row, text=i18n.t('VTP_PIPINSTALL','pip 설치'), bg=BLUE, fg="white",
                            font=("Malgun Gothic", 8), bd=0, padx=8, pady=1)
            btn.config(command=lambda p=pkg, l=lbl, b=btn: self._pip_install(p, l, b))
            self._lib_rows[pkg] = {"lbl": lbl, "btn": btn, "ok": False}

        # ffmpeg 행
        row = tk.Frame(sec, bg=BG)
        row.pack(fill="x", pady=2)
        tk.Label(row, text=i18n.t('VTP_MP3', 'MP3 저장'), bg=BG, fg=FG,
                 font=("Malgun Gothic", 9), width=12, anchor="w").pack(side="left")
        self._ffmpeg_lbl = tk.Label(row, text=i18n.t('VTP_CHECKING','점검 중...'), bg=BG, fg=ORANGE,
                                    font=("Malgun Gothic", 9), width=26, anchor="w")
        self._ffmpeg_lbl.pack(side="left", padx=6)
        self._ffmpeg_copy_btn = tk.Button(
            row, text=i18n.t('VTP_COPYCMD','설치 명령 복사'), bg=BLUE, fg="white",
            font=("Malgun Gothic", 8), bd=0, padx=8, pady=1,
            command=self._copy_winget_cmd)

        self._lib_note = tk.Label(sec, text="", bg=BG, fg=ORANGE,
                                  font=("Malgun Gothic", 8), justify="left",
                                  wraplength=400)
        self._lib_note.pack(anchor="w", pady=(4, 0))

    def _run_lib_checks(self):
        # 스레드는 큐에만 적재(스레드-세이프). UI 갱신은 메인스레드 폴러(_poll_chk)가 담당.
        # (스레드가 직접 self.after 를 호출하면 'main thread is not in main loop' — 특히 스플래시로
        #  app.mainloop 진입이 지연될 때 — 발생. 큐+폴러로 회피.)
        import queue as _q
        self._chk_q = _q.Queue()

        def _worker():
            any_fail = False
            for _display, pkg in _PIP_PKGS:
                try:
                    importlib.import_module(pkg)
                    ok = True
                except ImportError:
                    ok = False
                if not ok:
                    any_fail = True
                self._chk_q.put(('lib', pkg, ok))
            try:
                from voice_bible import ffmpeg_available
                ff_ok = ffmpeg_available()
            except Exception:
                ff_ok = False
            self._chk_q.put(('ffmpeg', ff_ok, None))
            if any_fail:
                self._chk_q.put(('note', None, None))

        threading.Thread(target=_worker, daemon=True).start()
        self._poll_chk()

    def _poll_chk(self):
        q = getattr(self, '_chk_q', None)
        if q is not None:
            try:
                while True:
                    kind, a, b = q.get_nowait()
                    if kind == 'lib':
                        self._set_lib_result(a, b)
                    elif kind == 'ffmpeg':
                        self._set_ffmpeg_result(a)
                    elif kind == 'note':
                        self._lib_note.config(
                            text=i18n.t('VTP_RESTART1', 'pip 설치 후 앱을 재시작해야 적용됩니다.'),
                            fg=ORANGE)
            except Exception:
                pass
        # ⚠⚠ **`winfo_exists()` 만으로는 못 막는다** (2026-09-03 실측) — 이미
        #   예약된 `after` 가 파괴 **뒤에** 발화하면 Tk 가
        #   `invalid command name "..._poll_chk"` 를 낸다. 예약 손잡이를
        #   들고 있다가 파괴할 때 취소한다.
        try:
            if self.winfo_exists():
                self._chk_after = self.after(300, self._poll_chk)
        except Exception:
            pass

    def destroy(self):
        try:
            if getattr(self, '_chk_after', None):
                self.after_cancel(self._chk_after)
                self._chk_after = None
        except Exception:
            pass
        try:
            super().destroy()
        except Exception:
            pass

    def _set_lib_result(self, pkg: str, ok: bool):
        info = self._lib_rows[pkg]
        info["ok"] = ok
        if ok:
            info["lbl"].config(text=i18n.t('VTP_INSTALLED','✓ 설치됨'), fg=GREEN)
            info["btn"].pack_forget()
        else:
            info["lbl"].config(text=i18n.t('VTP_MISSING','✗ 없음'), fg=RED)
            info["btn"].pack(side="left")
        self._refresh_lower_sections()

    def _set_ffmpeg_result(self, ok: bool):
        if ok:
            self._ffmpeg_lbl.config(text=i18n.t('VTP_MP3_OK', '✓ 가능'), fg=GREEN)
        else:
            # ★ 2026-10-13 — 바깥 프로그램(ffmpeg)을 설치하라고 하지 않는다. 못 만들면 WAV 로 저장된다.
            self._ffmpeg_lbl.config(text=i18n.t('VTP_MP3_WAV', '✗ 안 됨 — WAV 로 저장합니다'), fg=ORANGE)
        self._ffmpeg_copy_btn.pack_forget()

    def _pip_install(self, pkg: str, lbl: tk.Label, btn: tk.Button):
        lbl.config(text=i18n.t('VTP_INSTALLING','설치 중...'), fg=ORANGE)
        btn.config(state="disabled")

        def _run():
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", pkg],
                capture_output=True, text=True
            )
            ok = result.returncode == 0
            self.after(0, lambda: self._on_pip_done(pkg, lbl, btn, ok))

        threading.Thread(target=_run, daemon=True).start()

    def _on_pip_done(self, pkg: str, lbl: tk.Label, btn: tk.Button, ok: bool):
        self._lib_rows[pkg]["ok"] = ok
        if ok:
            lbl.config(text=i18n.t('VTP_INSTALLED','✓ 설치됨'), fg=GREEN)
            btn.pack_forget()
            self._lib_note.config(
                text=i18n.t('VTP_INSTALLED_RESTART','✓ 설치 완료. 앱을 재시작하면 적용됩니다.'), fg=GREEN)
        else:
            lbl.config(text=i18n.t('VTP_FAIL','✗ 실패'), fg=RED)
            btn.config(state="normal")
            self._lib_note.config(
                text=i18n.t('VTP_INSTALLFAIL','설치 실패. 터미널에서 직접 설치해 주세요.'), fg=RED)
        self._refresh_lower_sections()

    def _copy_winget_cmd(self):
        self.clipboard_clear()
        self.clipboard_append(_FFMPEG_WINGET)
        self._ffmpeg_copy_btn.config(text=i18n.t('VTP_COPIED','복사됨 ✓'))
        self.after(2000, lambda: self._ffmpeg_copy_btn.config(text=i18n.t('VTP_COPYCMD','설치 명령 복사')))

    def _all_pip_ok(self) -> bool:
        return all(info["ok"] for info in self._lib_rows.values())

    def _refresh_lower_sections(self):
        ok = self._all_pip_ok()
        self._mic_toggle_btn.config(state="normal" if ok else "disabled")
        self._test_btn.config(state="normal" if ok else "disabled")
        if ok:
            self._mic_note.config(text="")
            self._load_devices()
        else:
            self._mic_note.config(
                text=i18n.t('VTP_NEEDLIBS','sounddevice / soundfile / numpy 설치 필요'), fg=FG_DIM)

    # ── ② 마이크 레벨 섹션 ───────────────────────────────────────────────────

    def _build_mic_section(self):
        sec = tk.LabelFrame(self, text=i18n.t('VTP_S2',' ② 마이크 레벨 확인 '),
                            bg=BG, fg=FG_DIM,
                            font=("Malgun Gothic", 9), padx=10, pady=6)
        sec.pack(fill="x", padx=10)

        dev_row = tk.Frame(sec, bg=BG)
        dev_row.pack(fill="x", pady=(0, 4))
        tk.Label(dev_row, text=i18n.t('VTP_INPUTDEV','입력 장치:'), bg=BG, fg=FG,
                 font=("Malgun Gothic", 9)).pack(side="left")
        self._dev_var = tk.StringVar()
        self._dev_cb = ttk.Combobox(dev_row, textvariable=self._dev_var,
                                    width=34, state="readonly",
                                    font=("Malgun Gothic", 9))
        self._dev_cb.pack(side="left", padx=6)

        meter_row = tk.Frame(sec, bg=BG)
        meter_row.pack(fill="x", pady=2)
        tk.Label(meter_row, text=i18n.t('VOICE_LEVEL','레벨:'), bg=BG, fg=FG,
                 font=("Malgun Gothic", 9)).pack(side="left")
        self._mic_canvas = tk.Canvas(meter_row, bg="#0B1120",
                                     height=18, width=320,
                                     highlightthickness=1,
                                     highlightbackground="#2E4053")
        self._mic_canvas.pack(side="left", padx=6)
        self._mic_bar = self._mic_canvas.create_rectangle(
            0, 0, 0, 18, fill=GREEN, outline="")

        self._mic_toggle_btn = tk.Button(
            sec, text=i18n.t('VTP_TESTSTART','▶ 테스트 시작'),
            command=self._toggle_mic,
            bg="#1E8449", fg="white",
            font=("Malgun Gothic", 9, "bold"),
            bd=0, padx=12, pady=3, state="disabled")
        self._mic_toggle_btn.pack(anchor="w", pady=(6, 0))

        self._mic_note = tk.Label(sec, text=i18n.t('VTP_AFTERCHECK','라이브러리 점검 후 활성화됩니다.'),
                                  bg=BG, fg=FG_DIM, font=("Malgun Gothic", 8))
        self._mic_note.pack(anchor="w", pady=(2, 0))

    def _load_devices(self):
        try:
            import sounddevice as sd
            devs = sd.query_devices()
            inputs = [(i, d["name"]) for i, d in enumerate(devs)
                      if d["max_input_channels"] > 0]
            labels = [f"{i}: {n}" for i, n in inputs]
            self._dev_cb["values"] = labels
            default_idx = sd.default.device[0]
            match = next((lbl for lbl in labels
                          if lbl.startswith(f"{default_idx}:")), None)
            self._dev_var.set(match or (labels[0] if labels else ""))
        except Exception as e:
            self._mic_note.config(text=f"장치 조회 실패: {e}", fg=RED)

    def _selected_device_idx(self):
        val = self._dev_var.get()
        try:
            return int(val.split(":")[0])
        except (ValueError, IndexError):
            return None

    def _toggle_mic(self):
        if self._mic_active:
            self._stop_mic()
        else:
            self._start_mic()

    def _start_mic(self):
        try:
            import sounddevice as sd
            import numpy as np
            self._mic_active = True
            self._mic_level  = 0.0
            dev = self._selected_device_idx()

            def _cb(indata, frames, t, status):
                self._mic_level = float(np.abs(indata).mean()) * 8

            kw = dict(samplerate=SAMPLERATE, channels=1,
                      dtype="float32", callback=_cb)
            if dev is not None:
                kw["device"] = dev
            self._mic_stream = sd.InputStream(**kw)
            self._mic_stream.start()
            self._mic_toggle_btn.config(text=i18n.t('VTP_TESTSTOP','■ 테스트 중지'), bg="#922B21")
            self._mic_note.config(text=i18n.t('VTP_SPEAK','마이크에 말해보세요.'), fg=GREEN)
            self._poll_meter()
        except Exception as e:
            self._mic_active = False
            self._mic_note.config(text=f"마이크 오류: {e}", fg=RED)

    def _stop_mic(self):
        self._mic_active = False
        if self._mic_stream:
            try:
                self._mic_stream.stop()
                self._mic_stream.close()
            except Exception:
                pass
            self._mic_stream = None
        if hasattr(self, "_mic_toggle_btn"):
            self._mic_toggle_btn.config(text=i18n.t('VTP_TESTSTART','▶ 테스트 시작'), bg="#1E8449")
            self._mic_canvas.coords(self._mic_bar, 0, 0, 0, 18)
            self._mic_note.config(text="", fg=FG_DIM)

    def _poll_meter(self):
        if not self._mic_active:
            return
        level = min(self._mic_level, 1.0)
        w     = int(320 * level)
        color = GREEN if level < 0.7 else RED
        self._mic_canvas.itemconfig(self._mic_bar, fill=color)
        self._mic_canvas.coords(self._mic_bar, 0, 0, w, 18)
        self.after(40, self._poll_meter)

    # ── ③ 녹음·재생 테스트 ───────────────────────────────────────────────────

    def _build_test_section(self):
        sec = tk.LabelFrame(self, text=i18n.t('VTP_S3',' ③ 녹음·재생 테스트 (3초) '),
                            bg=BG, fg=FG_DIM,
                            font=("Malgun Gothic", 9), padx=10, pady=6)
        sec.pack(fill="x", padx=10)

        row = tk.Frame(sec, bg=BG)
        row.pack(fill="x")
        self._test_btn = tk.Button(
            row, text=i18n.t('VTP_REC3','⏺  3초 녹음 후 재생'),
            command=self._run_test,
            bg=BLUE, fg="white",
            font=("Malgun Gothic", 9, "bold"),
            bd=0, padx=14, pady=4, state="disabled")
        self._test_btn.pack(side="left")
        self._test_lbl = tk.Label(row, text="", bg=BG, fg=FG_DIM,
                                  font=("Malgun Gothic", 9))
        self._test_lbl.pack(side="left", padx=10)

    def _run_test(self):
        if not self._all_pip_ok():
            self._test_lbl.config(text=i18n.t('VTP_INSTALLFIRST','라이브러리를 먼저 설치하세요.'), fg=RED)
            return
        mic_was_active = self._mic_active
        if mic_was_active:
            self._stop_mic()
        self._test_btn.config(state="disabled")
        self._test_lbl.config(text=f"● 녹음 중... ({TEST_SEC}초)", fg=RED)
        dev = self._selected_device_idx()

        def _worker():
            try:
                import sounddevice as sd
                import soundfile as sf
                import numpy as np
                kw = dict(samplerate=SAMPLERATE, channels=1, dtype="float32")
                if dev is not None:
                    kw["device"] = dev
                frames = sd.rec(int(SAMPLERATE * TEST_SEC), **kw)
                for remaining in range(TEST_SEC, 0, -1):
                    self.after(0, lambda r=remaining: self._test_lbl.config(
                        text=f"● 녹음 중... ({r}초)", fg=RED))
                    time.sleep(1)
                sd.wait()
                self.after(0, lambda: self._test_lbl.config(
                    text=i18n.t('VOICE_PLAYING','▶ 재생 중...'), fg="#AED6F1"))
                with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                    tmp = Path(f.name)
                sf.write(str(tmp), frames, SAMPLERATE)
                data, fs = sf.read(str(tmp), dtype="float32")
                sd.play(data, fs)
                sd.wait()
                tmp.unlink(missing_ok=True)
                self.after(0, lambda: self._test_lbl.config(text='✓ '+i18n.t('COMMON_DONE','완료'), fg=GREEN))
            except Exception as e:
                self.after(0, lambda: self._test_lbl.config(
                    text=f"오류: {e}", fg=RED))
            finally:
                self.after(0, lambda: self._test_btn.config(state="normal"))
                if mic_was_active:
                    self.after(200, self._start_mic)

        threading.Thread(target=_worker, daemon=True).start()


# ── 독립 팝업 래퍼 ────────────────────────────────────────────────────────────

class VoiceTestPopup(tk.Toplevel):
    """VoiceTestFrame을 독립 팝업으로 표시한다."""

    def __init__(self, parent):
        super().__init__(parent)
        self.title(i18n.t('WIN_VOICE_CHECK', "녹음 환경 점검"))
        self.resizable(False, False)
        self.configure(bg=BG)
        self.grab_set()

        tk.Label(self, text=i18n.t('VTP_TITLE','  녹음 환경 점검'), bg=BG_HDR, fg=FG,
                 font=("Malgun Gothic", 11, "bold"), pady=8, anchor="w"
                 ).pack(fill="x")

        self._content = VoiceTestFrame(self)
        self._content.pack(fill="both", expand=True)

        tk.Button(self, text=i18n.t('COMMON_CLOSE','닫기'), command=self._on_close,
                  bg="#4A235A", fg="white",
                  font=("Malgun Gothic", 9, "bold"), bd=0, padx=20, pady=4
                  ).pack(pady=(8, 10))

        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.update_idletasks()
        pw = self.winfo_reqwidth()
        ph = self.winfo_reqheight()
        sx = parent.winfo_rootx() + (parent.winfo_width()  - pw) // 2
        sy = parent.winfo_rooty() + (parent.winfo_height() - ph) // 2
        self.geometry(f"+{sx}+{sy}")

    def _on_close(self):
        self._content.cleanup()
        self.grab_release()
        self.destroy()
