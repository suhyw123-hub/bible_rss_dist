# -*- coding: utf-8 -*-
"""찬양 **앨범** 층 — 사역자가 언제 무엇을 함께 냈나.

★★★ 왜 곡 표에 바로 안 넣나 (2026-09-11 사용자 「다윗과 요나단 … 앨범 수록곡
  명단이다. 이것을 **DB에 어떻게 입력하는 것이 좋겠는가?** 자작곡도 있고
  번안곡도 있을 것 같다. **이미 저장된 곡도 일부** 있을 것 같다」 →
  「**앨범 등록 필요하다**」).
  ✅ 실측이 답을 정했다 — 다윗과 요나단 9집 **76곡** 가운데 우리 곡 표에 이미
    있는 것은 **4곡**(전부 찬송가)이고, 우리 영상에 실제로 있는 것은 **거의
    없다**. 74곡을 곡으로 바로 올리면 **영상 0편짜리 서랍 70개**가 생긴다(§0-1).
  ⇒ **앨범은 그 자체로 참인 사실**이라 먼저 담고, 곡은 **영상이 생길 때** 꺼낸다.

★★★ 그리고 앨범은 **원곡의 증거**다 — §⑤-11 이 「근거를 안 적으면 원곡으로 못
  정한다」고 막아 두었는데 「1집 《친구의 고백》 1987년 수록」은 근거로 충분하다.

층 —
    sys_song_album   앨범 (사역자 · 몇 집 · 연도)
      └ sys_album_track  수록곡 (차례 · 이름 · **곡 번호는 비어 있어도 된다**)

⚠ **이름은 `sys_text_asset` 에 둔다**(§0-3 규칙 1) — 앨범 제목도 수록곡 이름도
  다국어가 될 수 있다(중국어·영어 앨범).
⚠ **`song_id` 가 비어 있는 것이 정상이다** — 「아직 곡으로 안 올렸다」는 뜻이고,
  수집이 그 이름을 물어 오면 그때 잇는다(`link_track`).
⚠ **배포하지 않는다(LOCAL)** — 지금은 관리자가 원곡을 가리는 재료다
  (§233차 ④ `sys_worship_artist` 와 같은 취급). 화면에 나가는 날 CORE 로 올린다.

사용:  python db_song_album.py --selftest | --list | --show <번호> | --thin
"""
import os
import sys

import appdb

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bible_master.db')

T_ALB = 'sys_song_album'
T_TRK = 'sys_album_track'

#: 이름이 사는 곳 — §0-3 규칙 1
NAME_ALBUM = 'SONG_ALBUM_TITLE'
NAME_TRACK = 'ALBUM_TRACK_NAME'


def _db(path=None):
    return appdb.connect(path or DB)


def ensure(conn):
    """표 둘을 만든다(멱등)."""
    conn.execute("""CREATE TABLE IF NOT EXISTS %s(
        album_id      INTEGER PRIMARY KEY AUTOINCREMENT,
        artist_id     INTEGER,
        seq           INTEGER,
        year          INTEGER,
        note          TEXT,
        record_status TEXT DEFAULT 'LIVE')""" % T_ALB)
    conn.execute("""CREATE TABLE IF NOT EXISTS %s(
        track_id      INTEGER PRIMARY KEY AUTOINCREMENT,
        album_id      INTEGER NOT NULL,
        track_no      INTEGER,
        song_id       INTEGER,
        note          TEXT,
        record_status TEXT DEFAULT 'LIVE')""" % T_TRK)
    # ★★★ **장르는 앨범의 칸이다**(2026-09-12 사용자 「**메시아닉도 별도
    #   장르로 구분**하라」) — 그전에는 `note` 글자를 파싱해 읽었다.
    #   ⚠ **글자를 파싱해 읽으면 반드시 어긋난다** — note 는 사람이 고치는
    #     자리다. 목록의 집은 `media_taxonomy.SONG_GENRES` 하나다.
    _ac = [r[1] for r in conn.execute('PRAGMA table_info(%s)' % T_ALB)]
    if 'genre' not in _ac:
        conn.execute("ALTER TABLE %s ADD COLUMN genre TEXT" % T_ALB)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_album_artist"
                 " ON %s(artist_id, seq)" % T_ALB)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_track_album"
                 " ON %s(album_id, track_no)" % T_TRK)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_track_song"
                 " ON %s(song_id)" % T_TRK)
    return True


def _put_name(conn, ttype, oid, names):
    """이름을 언어별로 적는다(멱등)."""
    for lang, nm in (names or {}).items():
        if not nm:
            continue
        r = conn.execute(
            "SELECT sys_text_id FROM sys_text_asset WHERE text_type=?"
            "   AND clicked_id=? AND lang_code=?",  # status-ok: 있는 줄을 다시 만들지 않으려는 확인 — 가림도 있는 줄이다
            (ttype, oid, lang)).fetchone()
        if r:
            conn.execute("UPDATE sys_text_asset SET contents=?,"
                         " record_status='LIVE' WHERE sys_text_id=?", (nm, r[0]))
        else:
            conn.execute(
                "INSERT INTO sys_text_asset(text_type, clicked_id, lang_code,"
                " contents, record_status) VALUES(?,?,?,?,'LIVE')",
                (ttype, oid, lang, nm))


def name_of(conn, ttype, oid, lang='KO'):
    """그 언어 이름 → 없으면 KO → 아무거나."""
    for lg in (lang, 'KO', None):
        q = ("SELECT contents FROM sys_text_asset WHERE text_type=?"
             "   AND clicked_id=? AND record_status='LIVE'")
        a = [ttype, oid]
        if lg:
            q += " AND lang_code=?"
            a.append(lg)
        r = conn.execute(q + " LIMIT 1", a).fetchone()
        if r and r[0]:
            return r[0]
    return ''


def add_album(conn, artist_id, seq, title, year=None, note=None, lang='KO',
              genre=None):
    """앨범 하나 → album_id (멱등 — **(사역자, 몇 집)** 이 열쇠).

    ⚠⚠⚠ **사역자 없이는 안 만든다**(2026-09-12 실측으로 잡았다) — 열쇠가
      (사역자, 몇 집)인데 사역자가 비면 **`(NULL, 1)` 인 앨범들이 서로 같은
      줄로 보여 통째로 뭉친다**. 실제로 한 장이 그렇게 들어갔다
      (「제이 브라이언 / 트라이브스 (J.J. Hairston …)」 — 파서가 `/` 로 잘라
      영문 이름을 잃어 코드가 빈 채로 `WA.add` 가 `None` 을 냈다).
    """
    ensure(conn)
    if not artist_id:
        raise ValueError('앨범에는 사역자가 있어야 합니다 — 열쇠가 (사역자, 몇 집)입니다')
    r = conn.execute(
        "SELECT album_id FROM %s WHERE artist_id=? AND seq=?" % T_ALB,  # status-ok: 있는 줄을 다시 만들지 않으려는 확인 — 가림도 있는 줄이다
        (artist_id, seq)).fetchone()
    if r:
        aid = r[0]
        if year:
            conn.execute("UPDATE %s SET year=COALESCE(year,?) WHERE album_id=?"
                         % T_ALB, (year, aid))
        if note:
            conn.execute("UPDATE %s SET note=COALESCE(note,?) WHERE album_id=?"
                         % T_ALB, (note, aid))
    else:
        aid = conn.execute(
            "INSERT INTO %s(artist_id, seq, year, note, record_status)"
            " VALUES(?,?,?,?,'LIVE')" % T_ALB,
            (artist_id, seq, year, note)).lastrowid
    if genre:
        set_album_genre(conn, aid, genre)
    _put_name(conn, NAME_ALBUM, aid, {lang: title} if title else None)
    return aid


def set_album_genre(conn, album_id, genre):
    """앨범의 **장르**를 적는다 → bool.

    ⚠ 목록에 없는 값은 **거부한다**(`media_taxonomy.SONG_GENRES` 가 집).
    """
    ensure(conn)
    import media_taxonomy as _TX
    g = (genre or '').strip().upper() or None
    if g and g not in _TX.SONG_GENRES:
        return False
    conn.execute("UPDATE %s SET genre=? WHERE album_id=?" % T_ALB, (g, album_id))
    return True


def album_genre(conn, album_id):
    """앨범의 장르 코드 → 없으면 `''`."""
    ensure(conn)
    r = conn.execute("SELECT COALESCE(genre,'') FROM %s WHERE album_id=?"  # status-ok: 번호 하나로 제 장부를 읽는 자리
                     % T_ALB, (album_id,)).fetchone()
    return r[0] if r else ''


def genre_of_track(conn, track_id):
    """그 수록곡이 실린 **앨범의 장르** → 없으면 `''`.

    ★ 곡으로 올릴 때 이것을 그대로 단다 — **출처가 곧 장르**다.
    """
    ensure(conn)
    r = conn.execute(
        "SELECT COALESCE(a.genre,'') FROM %s t JOIN %s a ON a.album_id=t.album_id"
        " WHERE t.track_id=?" % (T_TRK, T_ALB), (track_id,)).fetchone()  # status-ok: 번호 하나로 어느 앨범인지만 읽는다
    return r[0] if r else ''


def promote_track(conn, track_id, media_id=None, lang='EN'):
    """수록곡을 **곡으로 올린다** → song_id.

    ★★★ **장르는 앨범에서 온다**(2026-09-12 사용자 「메시아닉도 별도 장르로
      구분하라」) — 손으로 박지 않는다. 실측 그 자리에서 내가 블랙 가스펠을
      박아 두었다가 메시아닉을 놓칠 뻔했다.
    ⚠ **이미 곡이 있으면 그것을 쓴다**(멱등).
    """
    import db_song as _SG
    ensure(conn)
    r = conn.execute("SELECT song_id, album_id FROM %s WHERE track_id=?" % T_TRK,  # status-ok: 번호 하나로 제 장부를 읽는 자리
                     (track_id,)).fetchone()
    if not r:
        return None
    sid, alb = r
    if not sid:
        nm = name_of(conn, NAME_TRACK, track_id, lang)
        art = conn.execute("SELECT artist_id FROM %s WHERE album_id=?" % T_ALB,  # status-ok: 번호 하나로 제 장부를 읽는 자리
                           (alb,)).fetchone()
        sid = _SG.add_song(conn, 'ALBTRK_%d' % track_id, names={lang: nm},
                           orig_lang=lang,
                           orig_artist_id=(art[0] if art else None),
                           note='앨범 수록곡에서 올림')
        link_track(conn, track_id, sid)
    # ⚠⚠⚠ **앨범 장르가 곡 장르를 덮지 않는다**(2026-09-12 실측으로 잡았다) —
    #   다윗과 요나단이 부른 **찬송가 셋**(304·413·540장)이 그 앨범의 장르로
    #   덮였다. **곡의 장르는 그 곡의 것이지 앨범의 것이 아니다** — 번안한
    #   사람이 CCM 가수라도 찬송가는 찬송가다. **비어 있을 때만** 적는다.
    g = album_genre(conn, alb)
    if g and not _SG.genre_of(conn, sid):
        _SG.set_genre(conn, sid, g)
    if media_id:
        rid, _why = _SG.pick_rend(conn, sid, media_id)
        if rid:
            _SG.link_media(conn, media_id, rid)
    return sid


def add_track(conn, album_id, track_no, name, song_id=None, note=None,
              lang='KO'):
    """수록곡 하나 → track_id (멱등 — **(앨범, 차례)** 가 열쇠).

    ⚠ `song_id` 는 **비어 있어도 된다** — 아직 곡으로 안 올렸다는 뜻이다.
    """
    ensure(conn)
    r = conn.execute(
        "SELECT track_id FROM %s WHERE album_id=? AND track_no=?" % T_TRK,  # status-ok: 있는 줄을 다시 만들지 않으려는 확인 — 가림도 있는 줄이다
        (album_id, track_no)).fetchone()
    if r:
        tid = r[0]
        if song_id:
            conn.execute("UPDATE %s SET song_id=COALESCE(song_id,?)"
                         " WHERE track_id=?" % T_TRK, (song_id, tid))
        if note:
            conn.execute("UPDATE %s SET note=COALESCE(note,?) WHERE track_id=?"
                         % T_TRK, (note, tid))
    else:
        tid = conn.execute(
            "INSERT INTO %s(album_id, track_no, song_id, note, record_status)"
            " VALUES(?,?,?,?,'LIVE')" % T_TRK,
            (album_id, track_no, song_id, note)).lastrowid
    _put_name(conn, NAME_TRACK, tid, {lang: name} if name else None)
    return tid


def link_track(conn, track_id, song_id):
    """수록곡 ↔ 곡 — 곡이 생긴 뒤에 잇는다."""
    ensure(conn)
    n = conn.execute("UPDATE %s SET song_id=? WHERE track_id=?" % T_TRK,
                     (song_id, track_id)).rowcount
    return bool(n)


def albums(conn, artist_id=None, lang='KO'):
    """[(album_id, 사역자, 몇 집, 제목, 연도, 수록곡 수, 곡에 이은 수)]."""
    ensure(conn)
    q = ("SELECT album_id, artist_id, seq, year FROM %s"
         " WHERE COALESCE(record_status,'LIVE')='LIVE'" % T_ALB)
    a = []
    if artist_id:
        q += " AND artist_id=?"
        a.append(artist_id)
    out = []
    for aid, art, seq, yr in conn.execute(q + " ORDER BY artist_id, seq", a):
        n = conn.execute(
            "SELECT COUNT(*), COUNT(song_id) FROM %s WHERE album_id=?"
            "   AND COALESCE(record_status,'LIVE')='LIVE'" % T_TRK,
            (aid,)).fetchone()
        out.append((aid, art, seq, name_of(conn, NAME_ALBUM, aid, lang),
                    yr, n[0], n[1]))
    return out


def tracks(conn, album_id, lang='KO'):
    """[(track_id, 차례, 이름, song_id, 그 곡의 영상 수)]."""
    ensure(conn)
    out = []
    for tid, no, sid in conn.execute(
            "SELECT track_id, track_no, song_id FROM %s WHERE album_id=?"
            "   AND COALESCE(record_status,'LIVE')='LIVE'"
            " ORDER BY track_no" % T_TRK, (album_id,)):
        n = 0
        if sid:
            n = conn.execute(
                "SELECT COUNT(DISTINCT l.clicked_id) FROM sys_link_asset l"
                "  JOIN sys_song_rendition rd ON rd.rend_id=l.target_id"
                " WHERE rd.song_id=? AND l.link_type='MEDI_REND'"
                "   AND l.record_status IN ('LIVE','PEND')",
                (sid,)).fetchone()[0]
        out.append((tid, no, name_of(conn, NAME_TRACK, tid, lang), sid, n))
    return out


def albums_of_song(conn, song_id, lang='KO'):
    """그 곡이 실린 앨범 → [(앨범 제목, 몇 집, 연도, 사역자)].

    ★ **원곡 증거로 쓰는 문**이다 — 가장 이른 해가 원곡 후보다.
    """
    ensure(conn)
    out = []
    for aid, seq, yr, art in conn.execute(
            "SELECT a.album_id, a.seq, a.year, a.artist_id FROM %s t"
            "  JOIN %s a ON a.album_id=t.album_id"
            " WHERE t.song_id=? AND COALESCE(t.record_status,'LIVE')='LIVE'"
            "   AND COALESCE(a.record_status,'LIVE')='LIVE'"
            " ORDER BY a.year" % (T_TRK, T_ALB), (song_id,)):
        out.append((name_of(conn, NAME_ALBUM, aid, lang), seq, yr, art))
    return out


def thin_songs(conn, max_media=3, lang='KO', limit=300):
    """**영상이 얇은 수록곡 이름** → [(이름, song_id, 영상 수, track_id)].

    ★★★ 2026-09-11 사용자 — 「**연결된 영상 숫자가 3개 미만인 곡 이름을 집중
      수집**하는 로직도 좋을 것 같다 … 매번 같은 사역자의 앨범에 수록된 곡을
      검색하면 **주요사역자들의 영상만 넘쳐나기 때문이다**」.
    ⇒ 곡 이름 검색은 **얇은 곡을 채우는 도구**이지 많이 모으는 도구가 아니다.
    ⚠ **흔한 말 이름은 뺀다** — `db_song.name_risk` 가 막는다(실측 앨범 76곡
      중 「고백」·「용서」 둘이 걸렸다). 그 이름으로 찾으면 딴 곡이 쏟아진다.
    """
    ensure(conn)
    import db_song as SG
    out = []
    seen = set()
    for row in albums(conn, lang=lang):
        for tid, _no, nm, sid, n in tracks(conn, row[0], lang):
            if not nm or nm in seen:
                continue
            seen.add(nm)
            if n >= int(max_media):
                continue
            if SG.name_risk(conn, nm):
                continue            # 흔한 말·팀 이름은 안 쓴다
            out.append((nm, sid, n, tid))
            if len(out) >= int(limit):
                return out
    return out


def collect_thin(conn, keys=None, max_media=3, limit=12, dry=False,
                 log=print):
    """**영상이 얇은 수록곡 이름으로 집중 수집** → 요약 dict.

    ★★★ 2026-09-11 사용자 — 「등록된 곡이름으로 검색하는 **특수한 방식**도
      필요할 것 같다 … **연결된 영상 숫자가 3개 미만인 곡 이름을 집중 수집** …
      **자주 사용할 것은 아니다**. 매번 같은 사역자의 앨범에 수록된 곡을
      검색하면 **주요사역자들의 영상만 넘쳐나기 때문이다」.
    ⚠⚠ **매일 자동수집에 넣지 않는다** — 사용자가 그 까닭을 적었다. 사람이
      누를 때만 돈다.
    ⚠ **담는 문은 `db_song_collect.collect` 하나다** — 여기서 따로 찾거나
      INSERT 하지 않는다(§237차 ③ · 문이 둘이면 문지기가 갈린다).
    ⚠ 한 번에 `limit` 개만 — 곡 하나에 검색 한 번(100 units)이라 값이 비싸다.
    """
    import db_song_collect as SC
    got = thin_songs(conn, max_media=max_media, limit=int(limit))
    out = {'names': len(got), 'units': len(got) * 100}
    if dry or not got:
        out['list'] = [g[0] for g in got]
        return out
    # `collect` 이 받는 꼴 = (코드, [이름], 영문, 영문으로도 찾나, **찾을 때
    #   앞에 붙일 말**). ★★★ 2026-09-12 표본 조사 — 「Made a Way」만으로는 못
    #   찾고 **「Travis Greene Made a Way」**로 찾았다. 사역자 이름을 함께 넣는다.
    #   ⚠ **문지기는 이름만 본다** — 제목에 사역자가 없어도 그 곡일 수 있다.
    songs = [('ALBUM_%d' % tid, [nm], '', False, _artist_of_track(conn, tid))
             for nm, _sid, _n, tid in got]
    r = SC.collect(conn, songs=songs, keys=keys, log=log)
    out.update({k: v for k, v in (r or {}).items() if isinstance(v, int)})
    out['list'] = [g[0] for g in got]
    return out


def _daily_src():
    """매일 작업(`collect_channels`) 소스 — **이 문을 안 부르는가**를 잰다."""
    import io as _io
    try:
        return _io.open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                     'collect_channels.py'),
                        encoding='utf-8').read()
    except Exception:
        return ''


def _artist_of_track(conn, track_id, lang='EN'):
    """그 수록곡의 **사역자 이름** — 찾을 때 앞에 붙인다. 없으면 `''`."""
    r = conn.execute(
        "SELECT a.artist_id FROM %s t JOIN %s a ON a.album_id=t.album_id"
        " WHERE t.track_id=?" % (T_TRK, T_ALB), (track_id,)).fetchone()  # status-ok: 번호 하나로 어느 사역자인지만 읽는다
    if not r or not r[0]:
        return ''
    try:
        import db_worship_artist as _WA
        return _WA.label(conn, r[0], lang) or _WA.label(conn, r[0], 'KO') or ''
    except Exception:
        return ''


def _in_catalog():
    try:
        import db_pack_catalog as PC
        return T_ALB in PC.TABLES and T_TRK in PC.TABLES
    except Exception:
        return False


def selftest():
    ok = [0, 0]

    def t(msg, cond, extra=''):
        ok[1] += 1
        if cond:
            ok[0] += 1
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', msg,
                              '' if cond else extra))

    import sqlite3
    c = sqlite3.connect(':memory:')
    c.execute("""CREATE TABLE sys_text_asset(sys_text_id INTEGER PRIMARY KEY,
        text_type TEXT, clicked_id INTEGER, lang_code TEXT, contents TEXT,
        record_status TEXT)""")
    c.execute("""CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY,
        link_type TEXT, clicked_id INTEGER, target_id INTEGER,
        record_status TEXT)""")
    c.execute("""CREATE TABLE sys_song_rendition(rend_id INTEGER PRIMARY KEY,
        song_id INTEGER, record_status TEXT)""")
    t('표를 만든다(멱등)', ensure(c) and ensure(c))

    a1 = add_album(c, 41, 1, '친구의 고백', 1987)
    t('★ 앨범이 생긴다', bool(a1))
    t('★★ **멱등 — (사역자, 몇 집)이 열쇠**',
      add_album(c, 41, 1, '친구의 고백') == a1)
    _no_art = False
    try:
        add_album(c, None, 1, '사역자 없는 앨범')
    except ValueError:
        _no_art = True
    t('★★★ **사역자 없이는 안 만든다**(안 막으면 앨범이 통째로 뭉친다)', _no_art)
    t('  제목을 읽는다', name_of(c, NAME_ALBUM, a1) == '친구의 고백')

    t1 = add_track(c, a1, 1, '친구의 고백')
    t2 = add_track(c, a1, 2, '주님이여 이 손을')
    t('★ 수록곡이 생긴다', bool(t1) and t1 != t2)
    t('★★ 멱등 — (앨범, 차례)가 열쇠', add_track(c, a1, 1, '친구의 고백') == t1)
    t('★★★ **곡 번호가 비어 있어도 된다**(아직 곡이 아니다)',
      tracks(c, a1)[0][3] is None)

    t('★ 앨범 한 줄이 수록곡 수를 말한다', albums(c, 41)[0][5] == 2)
    t('  곡에 이은 수도 함께', albums(c, 41)[0][6] == 0)
    t('★★ 곡에 이으면 그것이 보인다', link_track(c, t1, 99)
      and tracks(c, a1)[0][3] == 99 and albums(c, 41)[0][6] == 1)

    a2 = add_album(c, 41, 9, '찬양합니다', 2004)
    add_track(c, a2, 1, '친구의 고백', song_id=99)
    ev = albums_of_song(c, 99)
    t('★★★ **가장 이른 해가 먼저 온다**(원곡 증거)',
      len(ev) == 2 and ev[0][2] == 1987, ev)

    c.execute("INSERT INTO sys_song_rendition VALUES(7, 99, 'LIVE')")
    for i in (1, 2):
        c.execute("INSERT INTO sys_link_asset(link_type, clicked_id, target_id,"
                  " record_status) VALUES('MEDI_REND',?,7,'LIVE')", (i,))
    t('★ 그 곡의 영상 수를 센다', tracks(c, a1)[0][4] == 2)

    import inspect
    src = inspect.getsource(thin_songs)
    t('★★★ **흔한 말 이름은 안 쓴다**(`name_risk`)', 'name_risk' in src)
    t('★★★ **얇은 곡만 낸다**(사용자 「3개 미만」)', 'max_media' in src)
    t('★★ 이름은 `sys_text_asset` 에 둔다(§0-3 규칙 1)',
      'sys_text_asset' in inspect.getsource(_put_name))
    t('★★ **배포하지 않는다(LOCAL)** — 팩 분류표에 있다', _in_catalog())
    src2 = inspect.getsource(collect_thin)
    t('★★★ **담는 문은 `db_song_collect.collect` 하나다**',
      'SC.collect(' in src2 and 'INSERT INTO ' + 'sys_media_asset' not in src2)
    t('★★★ **매일 자동수집에 안 넣는다**(사용자 「자주 사용할 것은 아니다」)',
      '_song_album' not in _daily_src(), '매일 작업이 부른다')
    t('★ 쿼터를 **미리 말한다**(곡 하나에 100 units)', "'units'" in src2)
    t('★★★ **사역자 이름을 함께 넣어 찾는다**(표본 조사로 정했다)',
      '_artist_of_track' in src2)
    # ★★★ 장르는 **앨범의 칸**이고 곡으로 올릴 때 그대로 간다(2026-09-12)
    import media_taxonomy as _TX8
    t('★★★ **목록에 없는 장르는 거부한다**',
      set_album_genre(c, a1, 'ZZ_NOPE') is False)
    t('★★ 앨범에 장르를 적는다',
      set_album_genre(c, a1, 'MESSIANIC') and album_genre(c, a1) == 'MESSIANIC')
    t('★★★ **수록곡이 앨범의 장르를 따라온다**',
      genre_of_track(c, t1) == 'MESSIANIC')
    t('★★ 장르 목록을 **베끼지 않는다**(`media_taxonomy` 가 집)',
      'media_taxonomy' in inspect.getsource(set_album_genre))
    t('★★★ **곡으로 올릴 때 장르를 손으로 안 박는다**',
      'album_genre(' in inspect.getsource(promote_track)
      and 'BLACK_GOSPEL' not in inspect.getsource(promote_track))
    t('★★★ **앨범 장르가 곡 장르를 안 덮는다**(찬송가는 찬송가다)',
      'not _SG.genre_of(' in inspect.getsource(promote_track))
    c.close()
    print('db_song_album selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


def main(argv):
    if '--selftest' in argv:
        return 0 if selftest() else 1
    conn = _db()
    try:
        if '--list' in argv:
            for aid, art, seq, ti, yr, n, k in albums(conn):
                print('  앨범%-4d 사역자%-4s %d집 「%s」 (%s) — %d곡 ·'
                      ' 곡에 이은 것 %d' % (aid, art, seq, ti, yr or '?', n, k))
            return 0
        if '--show' in argv:
            aid = int(argv[argv.index('--show') + 1])
            for tid, no, nm, sid, n in tracks(conn, aid):
                print('  %2s. %-26s 곡 %-6s 영상 %d' % (no, nm, sid or '-', n))
            return 0
        if '--thin' in argv:
            got = thin_songs(conn)
            print('영상이 얇은 수록곡 %d개 (3편 미만 · 흔한 말 제외)' % len(got))
            for nm, sid, n, tid in got:
                print('  %-26s 곡 %-6s 영상 %d' % (nm, sid or '-', n))
            return 0
        print(__doc__)
        return 0
    finally:
        conn.close()


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
