"""
book_footnote.py — 도서·설교·교리 본문의 **각주 성구 참조**를 살린다 (영구 · `--selftest` 의무)
================================================================================

옛 저작은 성구를 본문에 풀어 쓰지 않고 **편 끝 각주 한 줄**로 모아 둔다.

    (1) 시편 94:12; 민수기 12:8   (2) 요한복음 8:25 (불가타)

그 줄은 **본문 안의 평문**이라 눌러도 아무 일이 없었고, 무슨 말씀인지 보려면
성경 화면으로 나갔다 돌아와야 했다(2026-08-23 사용자 지적 — 켐피스 4편
「진리께서 친히 가르치시는 사람은 복이 있습니다.(1)」).

이 모듈이 하는 일은 둘뿐이다.
  ① 각주 줄에서 성구 참조를 찾아 **어디부터 어디까지인지**(글자 자리) 돌려준다
     → 화면이 그 자리에 태그를 걸어 **누르면 그 구절로** 가게 한다.
  ② 그 참조 바로 아래에 붙일 **구절 본문 줄**을 만들어 준다.

★ **데이터를 건드리지 않는다.** 본문(`sys_book_unit_text`)은 그대로 두고 화면에
  그릴 때만 살을 붙인다 — 그래서 켐피스뿐 아니라 **각주가 있는 모든 책**에
  그대로 걸리고, 되돌리려면 호출만 빼면 된다(2026-08-23 사용자 채택 안 B).

세 표기를 모두 읽는다 — **판본 콤보를 어디에 두어도 같은 자리에 걸린다.**
    한국어  (1) 시편 94:12; 민수기 12:8
    현대영어 (1) Psalm 94:12; Numbers 12:8
    원문    (1) Psalm xciv. 12; Numbers xii. 8.      ← 로마 숫자

⚠ **약명만 알던 `scripture_ref_kr` 을 정식명까지 읽도록 넓혔다.** 우리 번역
  각주는 「시편 94:12」처럼 **정식명**을 쓰는데 그 도구는 「시 94:12」만 알아
  전부 `(None, None)` 이었다. 실측으로 **정식명·약명 사이에 겹치는 이름이
  하나도 없음**을 확인하고 넓혔다(겹쳤다면 조용히 딴 책으로 갔을 것이다).
★ 영어는 **한국어 약명으로 바꿔** 그 해석기에 넘긴다 — 범위(`-`)·장 단위를
  두 곳에서 처리하면 반드시 갈라진다.

실측(켐피스 118편) — 각주 줄 74편, **세 판본 모두 180개 해석 · 서로 같음**.
  못 읽는 것은 외경(지혜서·집회서·마카베오상)과 성구가 아닌 각주(「아가타」·
  역자 주)뿐이다 — **해석 못 하는 것이 맞다.** 조용히 넘긴다.

사용법
    python book_footnote.py --selftest        (의무)
    python book_footnote.py --scan KEMPIS_IOC 그 책의 각주 해석률
"""
import io
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# ⚠⚠ **`sys.stdout` 을 갈아 끼우지 않는다.** 이 파일은 화면(`p1_reading_view`)이
#   import 하는 **라이브러리**다. 옛 방식(`sys.stdout = io.TextIOWrapper(...)`)은
#   앱의 stdout 을 통째로 바꾸고, 그 위에 또 감싼 도구가 `I/O operation on closed
#   file` 로 죽는다(2026-08-23 `db_kempis_plan` 에서 실제로 터졌다 —
#   `kd.py` 때와 같은 함정, 두 번째). `reconfigure` 는 있는 것을 손볼 뿐이다.
try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

import appdb
import scripture_ref_kr
# ★★ 구간 판정은 **한 문**이다(§verse_range) — `verse_id` 는 신원이고
#   차례는 `sort_order` 다. 번호로 나열하면 절체계 이형 구간에서 샌다.
import verse_range as _vr
import verse_ref

# 각주 줄 = 「(1) …」 로 시작하는 줄
_FOOT = re.compile(r'^\(\d+\)')
# 줄 안의 번호 표식
_MARK = re.compile(r'\(\d+\)')
# 꼬리 괄호 — 「(불가타)」 「(Vulg.)」 처럼 참조 뒤에 붙는 설명
_TAIL_PAREN = re.compile(r'\s*\([^)]*\)\s*$')
# 책 이름 + 나머지 (한국어)
_BOOK_HEAD = re.compile(r'^([가-힣]+)\s*(\d.*)$')
# 책 이름 + 나머지 (영어 — 「1 Corinthians 4:20」·「Song of Songs 2:17」)
_BOOK_HEAD_EN = re.compile(r'^((?:[123]\s+)?[A-Za-z][A-Za-z ]*?)\s+(\d.*)$')
# 책 이름 없이 장:절만 (「…; 19:14」·「…; xix. 14」 처럼 앞 책을 물려받는 꼴)
_BARE = re.compile(r'^(?:\d+\s*[:：]\s*\d|[ivxlcdm]+\.\s*\d)', re.I)

# 영어 각주가 쓰는 다른 표기 → `book_names(EN)` 의 이름.
# ⚠ **지어내지 않는다** — 실측으로 못 맞춘 것만 넣고 selftest 가 실재를 확인한다.
#   켐피스 EN 각주 178개 중 「Psalm」 47개가 유일하게 안 맞았다(표는 「Psalms」).
# ⚠ **별칭은 지어내지 않는다** — 실측으로 못 맞춘 것만 넣는다.
#   `song of solomon` 은 2026-08-24 추가: 표에는 `Song of Songs` 뿐인데
#   **스펄전 『아침과 저녁』이 34편에서 그 이름을 쓴다**(실측). 19세기 영어권
#   표준 표기라 다른 옛 저작에도 그대로 나온다.
_EN_ALIAS = {'psalm': 'psalms',           # 표는 「Psalms」
             'revelations': 'revelation',  # 옛 판의 복수 표기
             'cant': 'song of songs',      # Canticles 약자
             'canticles': 'song of songs',
             'song of solomon': 'song of songs'}

# 옛 판은 장을 **로마 숫자**로 찍는다 — 「Psalm xciv. 12」 「2 Corinthians xii. 2」.
# ⚠ 우리 번역(MODERN_EN·TRANSLATED)만 아라비아로 바꿨으므로 **원문(ORIGINAL)을
#   읽는 사람에게는 이 처리가 없으면 각주가 통째로 죽는다**(실측 0개).
#   19세기 공개 저작은 대개 이 표기라 다른 책에도 그대로 쓰인다.
# ⚠ 앞머리를 **비탐욕**으로 두어야 「Song of Songs ii. 17」이 바르게 갈린다.
#   그리고 「1 Mac. ix. 10」처럼 책 이름에 점이 있어도 뒤로 밀려 제자리를 찾는다.
_ROMAN_CH = re.compile(r'^(.*?)\s+([ivxlcdm]+)\.\s*(\d.*)$', re.I)
# 절 없이 장만 — 「Psalm cxx.」 「2 Kings iv.」
_ROMAN_CH_ONLY = re.compile(r'^(.*?)\s+([ivxlcdm]+)\.?\s*$', re.I)
_ROMAN_OK = re.compile(r'^m{0,3}(cm|cd|d?c{0,3})(xc|xl|l?x{0,3})(ix|iv|v?i{0,3})$',
                       re.I)
_ROMAN_VAL = (('m', 1000), ('cm', 900), ('d', 500), ('cd', 400), ('c', 100),
              ('xc', 90), ('l', 50), ('xl', 40), ('x', 10), ('ix', 9),
              ('v', 5), ('iv', 4), ('i', 1))


def _roman(s):
    """로마 숫자 → 정수. 올바른 꼴이 아니면 None (지어내지 않는다)."""
    s = (s or '').lower()
    if not s or not _ROMAN_OK.match(s):
        return None
    out = i = 0
    order = sorted(_ROMAN_VAL, key=lambda kv: -len(kv[0]))
    while i < len(s):
        for sym, val in order:
            if s.startswith(sym, i):
                out += val
                i += len(sym)
                break
        else:
            return None
    return out or None


def arabize(ref):
    """「Psalm xciv. 12」 → 「Psalm 94:12」 · 「2 Kings iv.」 → 「2 Kings 4」.

    로마 숫자가 없으면 그대로 돌려준다.
    ⚠ **절 없이 장만** 찍은 것도 살린다 — 「Psalm cxx.」·「2 Kings iv.」가 그 꼴이라
      빠뜨리면 원문 각주가 조용히 죽는다(실측 7건 중 3건).
    """
    src = ref or ''
    m = _ROMAN_CH.match(src)
    if m:
        n = _roman(m.group(2))
        if n:
            return '%s %d:%s' % (m.group(1).rstrip('. '), n, m.group(3))
        return ref
    m = _ROMAN_CH_ONLY.match(src)
    if m:
        n = _roman(m.group(2))
        if n:
            return '%s %d' % (m.group(1).rstrip('. '), n)
    return ref

# 한 참조가 데려오는 구절이 이보다 많으면 앞의 몇 절만 보이고 「…」 로 알린다.
# ⚠ 「열왕기하 4장」 같은 장 단위 참조가 37절을 통째로 쏟는 것을 막는다.
MAX_VERSES = 3


def book_map(conn):
    """KO 약명·정식명 → book_code. `scripture_ref_kr` 이 이제 둘 다 싣는다."""
    return scripture_ref_kr.book_map_ko(conn)


def en_to_ko(conn):
    """영어 책 이름(소문자) → **한국어 약명**.

    ★ 영어 참조를 한국어 약명으로 바꿔 `scripture_ref_kr.resolve` 에 넘긴다 —
      범위(`-`)·장 단위 처리를 **한 곳에서만** 하려는 것이다. 해석기를 두 벌
      만들면 곧 갈라진다.
    """
    ko = {bc: sn for bc, sn in conn.execute(
        "SELECT book_code, short_name FROM book_names WHERE lang_code='KO'")}
    out = {}
    for bc, sn, fn in conn.execute(
            "SELECT book_code, short_name, full_name FROM book_names "
            "WHERE lang_code='EN'"):
        k = ko.get(bc)
        if not k:
            continue
        for nm in (fn, sn):
            if nm:
                out[nm.strip().lower()] = k
    # ★ **로마 숫자 서수 접두** — 19세기 판은 「I John ii. 15」 「II Corinthians」
    #   처럼 적는다. 표에는 `1 John` 뿐이라 그대로는 **「요한복음」으로 읽힌다**
    #   (2026-08-24 실측 — 피니 설교 12편이 그렇게 어긋났다).
    #   ⚠ 이름에서 뽑아 만든다 — 책 목록을 손으로 베끼면 갈라진다.
    _ORD = {'1': 'i', '2': 'ii', '3': 'iii'}
    for nm in list(out):
        head = nm.split(' ', 1)
        if len(head) == 2 and head[0] in _ORD:
            out.setdefault('%s %s' % (_ORD[head[0]], head[1]), out[nm])
    for alias, real in _EN_ALIAS.items():
        if real in out:
            out.setdefault(alias, out[real])
    return out


def _norm(ref):
    """참조 하나를 해석기가 읽을 수 있는 꼴로 다듬는다.

    ⚠ 「4장」·「120편」의 꼬리 글자를 뗀다 — 그것은 **문자 체계 관례**이지
      참조의 일부가 아니다(§`_CHAP_SUFFIX` 와 같은 계열).
    """
    s = _TAIL_PAREN.sub('', ref).strip()
    s = arabize(s)                       # 로마 숫자 장을 먼저 아라비아로
    s = s.strip().rstrip('.').strip()
    s = re.sub(r'\s*(장|편)\s*$', '', s)
    return s


def find(conn, line, bm=None, em=None):
    """각주 줄 하나에서 성구 참조를 찾는다 (한국어·영어 둘 다).

    → [{'text', 'start', 'end', 'vid_s', 'vid_e'}]  (start/end 는 줄 안 글자 자리)
    해석 못 한 조각은 **넣지 않는다** — 외경·역자 주는 성구가 아니다.
    """
    if not line or not _FOOT.match(line):
        return []
    bm = bm if bm is not None else book_map(conn)
    em = em if em is not None else en_to_ko(conn)
    out = []
    last_book = None                     # 「…; 19:14」 가 물려받을 앞 책

    # 번호 표식으로 잘라 각 덩이의 **줄 안 시작 자리**를 함께 들고 간다
    marks = [(m.end(), m.start()) for m in _MARK.finditer(line)]
    if not marks:
        return []
    chunks = []
    for i, (beg, _) in enumerate(marks):
        end = marks[i + 1][1] if i + 1 < len(marks) else len(line)
        chunks.append((beg, line[beg:end]))

    for base, chunk in chunks:
        off = 0
        for part in chunk.split(';'):
            piece = part
            # 앞뒤 공백을 뺀 **실제 글자 자리**를 잡는다
            lead = len(piece) - len(piece.lstrip())
            body = piece.strip()
            s0 = base + off + lead
            off += len(part) + 1          # +1 = 잘라낸 ';'
            if not body:
                continue
            norm = _norm(body)
            if not norm:
                continue
            mb = _BOOK_HEAD.match(norm)
            me = None if mb else _BOOK_HEAD_EN.match(norm)
            if mb:
                cand = '%s %s' % (mb.group(1), mb.group(2))
                book_now = mb.group(1)
            elif me:
                ko = em.get(me.group(1).strip().lower())
                if not ko:
                    continue
                cand = '%s %s' % (ko, me.group(2))
                book_now = ko
            elif _BARE.match(norm) and last_book:
                # 앞 책을 물려받은 뒤에 로마 숫자를 푼다 — 「시 xix. 14」 → 「시 19:14」
                cand = arabize('%s %s' % (last_book, norm))
                book_now = last_book
            else:
                continue
            vs, ve = scripture_ref_kr.resolve(conn, cand, bm)
            if not vs:
                continue
            last_book = book_now
            # 태그 자리는 **꼬리 괄호를 뺀 참조 글자**까지만
            span = len(_TAIL_PAREN.sub('', body).rstrip().rstrip('.').rstrip())
            out.append({'text': body[:span], 'start': s0, 'end': s0 + span,
                        'vid_s': vs, 'vid_e': ve})
    return out


def verse_rows(conn, vid_s, vid_e, version, bn_lang='KO', limit=MAX_VERSES):
    """구절 범위 → [(약명라벨, 본문)] · 넘치면 마지막에 (None, None) 을 넣어 알린다."""
    rows = conn.execute("""
        SELECT bi.verse_id, bn.short_name, bi.chapter, bi.verse,
               COALESCE(bc.verse_text, '')
          FROM bible_index bi
          JOIN book_names bn ON bn.book_code = bi.bcode AND bn.lang_code = ?
          LEFT JOIN bible_content bc ON bc.verse_id = bi.verse_id
                                    AND bc.version_code = ?
         WHERE """ + _vr.between_sql('bi.verse_id') + """
         ORDER BY bi.sort_order
    """, [bn_lang, version] + _vr.between_args(vid_s, vid_e)).fetchall()
    out = []
    for _vid, nm, ch, vs, txt in rows[:limit]:
        out.append((verse_ref.label(verse_ref.SCOPE_BOOK, nm, ch, vs), txt))
    if len(rows) > limit:
        out.append((None, None))
    return out


def annotate(conn, body, version, bn_lang='KO', limit=MAX_VERSES):
    """본문에 각주 구절 본문을 끼워 넣는다.

    → (새 본문, [(줄번호1부터, 시작칸, 끝칸, vid_s, vid_e)], [끼워 넣은 줄번호])
    자리 목록은 **끼워 넣은 뒤의 줄 번호**라 화면이 그대로 `'%d.%d'` 로 쓴다.
    ⚠ 끼워 넣은 줄 번호를 함께 돌려준다 — 화면이 그 줄만 흐리게 칠할 때
      **글자 모양(`    · `)으로 찾지 않게** 하려는 것이다(본문에 같은 꼴이
      있으면 엉뚱한 줄이 흐려진다).
    """
    if not body:
        return body, [], []
    bm = book_map(conn)
    em = en_to_ko(conn)
    out_lines = []
    spots = []
    vlines = []
    for raw in body.split('\n'):
        out_lines.append(raw)
        hits = find(conn, raw, bm, em)
        if not hits:
            continue
        ln = len(out_lines)                      # 1-based
        for h in hits:
            spots.append((ln, h['start'], h['end'], h['vid_s'], h['vid_e']))
        for h in hits:
            for lab, txt in verse_rows(conn, h['vid_s'], h['vid_e'],
                                       version, bn_lang, limit):
                out_lines.append('      …' if lab is None
                                 else '    · %s  %s' % (lab, txt or ''))
                vlines.append(len(out_lines))
    return '\n'.join(out_lines), spots, vlines


# ── 자가 검증 ──────────────────────────────────────────────────────────────────

def _selftest():
    ok = fail = 0

    def t(name, cond):
        nonlocal ok, fail
        if cond:
            ok += 1
        else:
            fail += 1
            print('  FAIL %s' % name)

    t('_norm 꼬리 괄호', _norm('요한복음 8:25 (불가타)') == '요한복음 8:25')
    t('_norm 장 꼬리', _norm('열왕기하 4장') == '열왕기하 4')
    t('_norm 편 꼬리', _norm('시편 120편') == '시편 120')
    t('_norm 마침표', _norm('민수기 12:8.') == '민수기 12:8')

    conn = appdb.connect('bible_master.db')
    try:
        bm = book_map(conn)
        # ★ 정식명·약명을 둘 다 읽는가 (넓히기 전에는 정식명이 전부 실패했다)
        t('정식명 해석', scripture_ref_kr.resolve(conn, '시편 94:12', bm)[0] == 15444)
        t('약명 해석', scripture_ref_kr.resolve(conn, '시 94:12', bm)[0] == 15444)
        t('정식명·약명 같은 절', scripture_ref_kr.resolve(conn, '민수기 12:8', bm)
          == scripture_ref_kr.resolve(conn, '민 12:8', bm))
        # ⚠ 넓혔어도 **겹치는 이름이 없어야** 조용히 딴 책으로 안 간다
        rows = conn.execute("SELECT full_name, short_name FROM book_names "
                            "WHERE lang_code='KO'").fetchall()
        fulls = {r[0] for r in rows}
        shorts = {r[1] for r in rows}
        t('정식명·약명 겹침 없음', not (fulls & shorts))

        L = '(1) 시편 94:12; 민수기 12:8 (2) 요한복음 8:25 (불가타)'
        h = find(conn, L, bm)
        t('각주 3개 해석', len(h) == 3)
        t('첫 참조 자리', L[h[0]['start']:h[0]['end']] == '시편 94:12')
        t('둘째 참조 자리', L[h[1]['start']:h[1]['end']] == '민수기 12:8')
        t('꼬리 괄호 뺀 자리', L[h[2]['start']:h[2]['end']] == '요한복음 8:25')
        t('첫 참조 vid', h[0]['vid_s'] == 15444)

        # 앞 책 물려받기 — 「(1) 시편 27:1-3; 19:14」
        h2 = find(conn, '(1) 시편 27:1-3; 19:14', bm)
        t('앞 책 물려받음', len(h2) == 2 and h2[1]['vid_s'] ==
          scripture_ref_kr.resolve(conn, '시 19:14', bm)[0])

        # ── 영어 각주 (MODERN_EN 을 볼 때도 같은 자리에 걸려야 한다) ──────────
        em = en_to_ko(conn)
        # ⚠ 별칭은 **실재하는 이름**에만 건다 — 지어낸 이름은 조용히 딴 데로 간다
        for alias, real in _EN_ALIAS.items():
            t('EN 별칭 %s 의 본이름이 표에 있다' % alias, real in em)
            t('EN 별칭 %s 가 같은 책' % alias, em.get(alias) == em.get(real))
        LE = '(1) Psalm 94:12; Numbers 12:8 (2) John 8:25 (Vulgate)'
        he = find(conn, LE, bm, em)
        t('EN 각주 3개 해석', len(he) == 3)
        t('EN 첫 참조 자리', LE[he[0]['start']:he[0]['end']] == 'Psalm 94:12')
        t('EN 꼬리 괄호 뺀 자리', LE[he[2]['start']:he[2]['end']] == 'John 8:25')
        t('EN·KO 같은 절', [x['vid_s'] for x in he] == [x['vid_s'] for x in h])
        t('EN 숫자 머리 책', find(conn, '(1) 1 Corinthians 4:20', bm, em)[0]['vid_s']
          == scripture_ref_kr.resolve(conn, '고전 4:20', bm)[0])
        t('EN 여러 낱말 책',
          find(conn, '(1) Song of Songs 2:17', bm, em)[0]['vid_s']
          == scripture_ref_kr.resolve(conn, '아 2:17', bm)[0])
        t('EN 외경은 넘긴다', find(conn, '(1) Wisdom 6:8', bm, em) == [])

        # ── 로마 숫자 장 (ORIGINAL 판) ────────────────────────────────────────
        t('로마 xciv', _roman('xciv') == 94)
        t('로마 xii', _roman('xii') == 12)
        t('로마 대문자', _roman('IX') == 9)
        t('로마 아닌 것은 None', _roman('abc') is None and _roman('') is None)
        t('로마 잘못된 꼴은 None', _roman('iiii') is None)
        t('arabize 기본', arabize('Psalm xciv. 12') == 'Psalm 94:12')
        t('arabize 여러 낱말', arabize('Song of Songs ii. 17') == 'Song of Songs 2:17')
        t('arabize 숫자 머리', arabize('2 Corinthians xii. 2') == '2 Corinthians 12:2')
        # ⚠ 책 이름이 로마 글자처럼 보여도(Mic.) 진짜 장을 찾아야 한다
        t('arabize 책이름 오인 안 함', arabize('Mic. iii. 8') == 'Mic 3:8')
        t('arabize 로마 없으면 그대로', arabize('Psalm 94:12') == 'Psalm 94:12')
        LR = '(1) Psalm xciv. 12; Numbers xii. 8. (2) John viii. 25 (Vulg.)'
        hr = find(conn, LR, bm, em)
        t('원문 로마 각주 3개', len(hr) == 3)
        t('원문·현대 같은 절',
          [x['vid_s'] for x in hr] == [x['vid_s'] for x in he])
        t('원문 첫 참조 자리',
          LR[hr[0]['start']:hr[0]['end']] == 'Psalm xciv. 12')

        # 성구가 아닌 각주는 조용히 넘긴다
        t('사람 이름은 넘긴다', find(conn, '(2) 아가타', bm) == [])
        t('역자 주는 넘긴다',
          find(conn, '(2) 괄호 안의 말은 성직자에게만 해당한다', bm) == [])
        t('외경은 넘긴다', find(conn, '(1) 집회서 18:30', bm) == [])
        # 각주 줄이 아니면 손대지 않는다 (본문 속 「(1)」 오탐 차단)
        t('본문 줄은 안 건드린다',
          find(conn, '그가 말하기를 (1) 시편 94:12 라 하였다', bm) == [])

        ver = conn.execute("SELECT version_code FROM bible_content "
                           "WHERE verse_id=15444 LIMIT 1").fetchone()[0]
        vr = verse_rows(conn, 15444, 15444, ver)
        t('구절 본문 한 줄', len(vr) == 1 and vr[0][1])
        t('약명 라벨', vr[0][0].startswith('시'))
        # 장 단위는 잘라서 알린다
        vr2 = verse_rows(conn, *scripture_ref_kr.resolve(conn, '열왕기하 4', bm),
                         version=ver)
        t('넘치면 … 로 알린다', vr2[-1] == (None, None) and len(vr2) == MAX_VERSES + 1)

        BODY = ('진리께서 친히 가르치시는 사람은 복이 있습니다.(1)\n'
                '(1) 시편 94:12; 민수기 12:8 (2) 요한복음 8:25 (불가타)')
        nb, sp, vl = annotate(conn, BODY, ver)
        nl = nb.split('\n')
        t('본문 첫 줄 불변', nl[0] == BODY.split('\n')[0])
        t('각주 줄 불변', nl[1] == BODY.split('\n')[1])
        t('구절 줄이 붙었다', len(nl) == 2 + 3 and nl[2].startswith('    · '))
        t('자리 3개', len(sp) == 3)
        t('자리가 각주 줄(2행)', all(s[0] == 2 for s in sp))
        # ★ 돌려준 자리로 실제 글자를 떠 보면 참조가 나와야 한다
        t('자리로 뜬 글자가 참조', nl[sp[0][0] - 1][sp[0][1]:sp[0][2]] == '시편 94:12')
        t('끼운 줄 번호 3개', vl == [3, 4, 5])
        t('끼운 줄만 가리킨다',
          all(nl[i - 1].startswith(('    · ', '      …')) for i in vl))
        t('빈 본문', annotate(conn, '', ver) == ('', [], []))
        t('각주 없는 본문 불변',
          annotate(conn, '그냥 글입니다.', ver) == ('그냥 글입니다.', [], []))

        # 켐피스 전권 — 해석률이 떨어지면 알아차린다
        rows = conn.execute("""
            SELECT t.body_text FROM sys_book_unit u
              JOIN sys_book_asset a ON a.book_id = u.book_id
              JOIN sys_book_unit_text t ON t.unit_id = u.unit_id
             WHERE a.book_code='KEMPIS_IOC' AND t.text_variant='TRANSLATED'
        """).fetchall()
        n = sum(len(find(conn, l, bm))
                for (b,) in rows for l in b.split('\n'))
        t('켐피스 각주 해석 170개 이상 (실측 178)', n >= 170)
        print('  켐피스 해석 %d개' % n)
    finally:
        conn.close()

    print('selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def _scan(code):
    conn = appdb.connect('bible_master.db')
    try:
        bm = book_map(conn)
        em = en_to_ko(conn)
        for var in ('ORIGINAL', 'MODERN_EN', 'TRANSLATED'):
            rows = conn.execute("""
                SELECT u.sequence, t.body_text FROM sys_book_unit u
                  JOIN sys_book_asset a ON a.book_id = u.book_id
                  JOIN sys_book_unit_text t ON t.unit_id = u.unit_id
                 WHERE a.book_code=? AND t.text_variant=?
                 ORDER BY u.sequence
            """, (code, var)).fetchall()
            if not rows:
                continue
            tot = units = 0
            for _seq, b in rows:
                hits = [h for l in b.split('\n') for h in find(conn, l, bm, em)]
                if hits:
                    units += 1
                    tot += len(hits)
            print('%s %-11s — 살린 편 %3d · 참조 %3d개' % (code, var, units, tot))
    finally:
        conn.close()


def main():
    a = sys.argv[1:]
    if not a or a[0] == '--selftest':
        sys.exit(0 if _selftest() else 1)
    if a[0] == '--scan':
        _scan(a[1])
        return
    print(__doc__)


if __name__ == '__main__':
    main()
