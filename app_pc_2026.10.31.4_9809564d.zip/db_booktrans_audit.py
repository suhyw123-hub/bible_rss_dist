"""db_booktrans_audit.py — 이미 들어간 번역물이 `booktrans.md` 를 지키는가 (영구 도구).

⚠ **`temp_` 를 붙이지 않는다** — 번역물을 넣을 때마다 다시 돌린다.
   반복 실행할 도구가 그 이름 때문에 넉 달간 사라진 전례가 있다(§0-4·§0-5).

대상 = `sys_book_unit_text` 의 `MODERN_EN`·`TRANSLATED`·`SUMMARY` 전량.
견줌 대상 = 같은 유닛의 `ORIGINAL`.

보는 것 넷:
  ① 길이비 0.85~1.15 밖        — 요약해 버렸거나 부풀렸다 (SUMMARY 는 제외)
  ② 옛말 잔존                  — 손이 덜 갔다
  ③ 출처 한 줄 없음            — 붙이는 것을 잊었다
  ④ ORIGINAL 자체가 발췌인가   — 한 책 안에서 편 길이가 크게 갈리면 의심.
                                 §0-1 「발췌본은 반드시 명시」 위반 후보

⚠ ④ 는 **판정이 아니라 후보 제시**다. 원본을 안 보고 「짧으니 발췌」라고 단정하지 않는다.
   한 책 안에서 첫 편만 길고 나머지가 고르게 짧으면 그것이 신호다.
"""
import re
import statistics
import appdb

ARCHAIC = [r"\bthee\b", r"\bthou\b", r"\bthy\b", r"\bthine\b", r"\bye\b",
           r"\bhath\b", r"\bdoth\b", r"\bshalt\b", r"\bhast\b", r"\bdidst\b",
           r"\bunto\b", r"\byea\b", r"\bfain\b", r"\bnay\b", r"\bwhereunto\b",
           r"'tis\b", r"\bbrethren\b", r"\bsaith\b", r"\bcometh\b", r"\bbeareth\b",
           r"\bthou\s+art\b", r"\bthou\s+wilt\b"]


def archaic(s):
    return sorted({m.group(0).lower() for p in ARCHAIC
                   for m in re.finditer(p, s, re.I)})


def main():
    conn = appdb.connect()
    rows = conn.execute("""
        SELECT ba.book_code, ba.title, bu.sequence, bu.unit_id,
               t.text_variant, UPPER(t.lang_code), t.body_text
        FROM sys_book_unit_text t
        JOIN sys_book_unit  bu ON bu.unit_id = t.unit_id
        JOIN sys_book_asset ba ON ba.book_id = bu.book_id
        WHERE COALESCE(t.record_status,'LIVE')='LIVE'
        ORDER BY ba.book_code, bu.sequence, t.text_variant""").fetchall()
    conn.close()

    orig, other, by_book_orig = {}, [], {}
    for bc, title, seq, uid, var, lang, body in rows:
        if var == 'ORIGINAL':
            orig[uid] = body or ''
            by_book_orig.setdefault((bc, title), []).append((seq, len(body or '')))
        else:
            other.append((bc, title, seq, uid, var, lang, body or ''))

    print('=' * 74)
    print('① ~ ③  번역물 게이트 (%d행)' % len(other))
    print('=' * 74)
    bad = {}
    for bc, title, seq, uid, var, lang, body in other:
        o = orig.get(uid)
        p = []
        if o is None:
            p.append('원문 없음')
        elif var != 'SUMMARY':
            r = len(body) / len(o) if o else 0
            if not 0.85 <= r <= 1.15:
                p.append('길이비 %.2f' % r)
        a = archaic(body)
        if a:
            p.append('옛말 %d종(%s)' % (len(a), ','.join(a[:4])))
        tail = body.rstrip()[-160:]
        if not re.search(r'^\s*[—-]{1,2}\s*\S', tail.split('\n')[-1] if tail else ''):
            p.append('출처 줄 없음')
        if p:
            bad.setdefault((bc, var, lang), []).append((seq, p))

    if not bad:
        print('  흠 없음')
    for (bc, var, lang), items in sorted(bad.items()):
        print('\n[%s] %s/%s — %d편' % (bc, var, lang, len(items)))
        for seq, p in items[:6]:
            print('   %3s  %s' % (seq, ' / '.join(p)))
        if len(items) > 6:
            print('   … 그 밖 %d편' % (len(items) - 6))

    print()
    print('=' * 74)
    print('④  ORIGINAL 이 발췌인지 — 한 책 안에서 편 길이가 갈리는가')
    print('=' * 74)
    print('%-18s %5s %7s %7s %7s  %s' % ('book_code', '편수', '최소', '중앙', '최대', '판단'))
    for (bc, title), items in sorted(by_book_orig.items()):
        lens = [n for _, n in items if n]
        if len(lens) < 3:
            continue
        lo, mid, hi = min(lens), int(statistics.median(lens)), max(lens)
        note = ''
        if hi > mid * 2.5:
            note = '⚠ 한두 편만 길다 — 나머지가 발췌일 수 있다'
        elif mid < 1500:
            note = '⚠ 전편이 짧다 — 발췌 여부 확인 필요'
        print('%-18s %5d %7d %7d %7d  %s' % (bc, len(lens), lo, mid, hi, note))


if __name__ == '__main__':
    main()
