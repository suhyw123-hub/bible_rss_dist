# -*- coding: utf-8 -*-
"""copy_own.py — 배포 자료를 **내 것으로 가져와 고친다** (2026-10-13 docs/1.txt 83 · 영구).

사용자 확정 — 「단락제목 고치기는 제외한다. **가져와서 수정하는 방식**으로 하라.
옵션을 주어라. "원본 가리기" "원본 표시하기"」.

대상 둘:
  · **렌즈**(sys CONTAINER) → 내 렌즈(user CONTAINER) — 구조·이름·설명문·구절·연결 설명
  · **연구노트**(sys_ref_unit · STUDY) → 내 연구노트(user_ref_asset) — 언어별 제목·본문·표·구절/용어 연결

★★★ **원본은 안 건드린다** — 배포 자료는 다음 팩에서 다시 온다. 고치는 것은 언제나 사본이다.
★★★ **가져온 사실을 표 하나에 적는다**(`userdb.user_copy_origin`) — 원본 열쇠는 번호가 아니라
  **이름**(렌즈 `unit_name_sid` · 연구노트 `unit_code`)이다. 배포 DB 를 갈아 끼우면 번호가 바뀔 수 있다.
★★ **원본 가리기 / 원본 표시하기** = 그 줄의 `hide_origin`(기본 1 — 가린다). 목록이 원본을 그릴지
  `hidden_origins(conn, kind)` 하나로 묻는다(화면마다 SQL 을 또 짜지 않는다).
  ⚠ **사본을 지우면(HIDE) 원본이 저절로 돌아온다** — 가림은 「살아 있는 사본이 있을 때만」 건다.
⚠ 지금 화면에 보이는 그대로 가져온다 — 렌즈 글·이름은 내 덮개(overlay)가 이기고, 구절 목록은
  `overlay_read.links`(가린 연결 빠짐 · 더한 연결 들어감)를 쓴다.

    python copy_own.py --selftest        (의무 · 임시 사본 DB 에서 돈다)
"""
import sys

import appdb

KINDS = ('LENS', 'REF', 'PLAN')   # PLAN = 2026-10-15 배포 플랜 → 내 플랜(수정하기)

NODE_TT = (('NODE_DESC', 'desc'), ('NODE_QUESTION', 'question'), ('NODE_PRAYER', 'prayer'))


def ensure(conn):
    conn.execute(
        'CREATE TABLE IF NOT EXISTS userdb.user_copy_origin ('
        ' copy_id INTEGER PRIMARY KEY AUTOINCREMENT,'
        ' kind TEXT NOT NULL,'            # LENS | REF
        ' sys_key TEXT NOT NULL,'         # 렌즈 unit_name_sid · 연구노트 unit_code
        ' user_id INTEGER NOT NULL,'      # user_unit_asset.user_unit_id · user_ref_asset.ref_id
        ' hide_origin INTEGER NOT NULL DEFAULT 1,'
        ' created_at TEXT,'
        " record_status TEXT DEFAULT 'LIVE')")
    conn.execute('CREATE INDEX IF NOT EXISTS userdb.ix_copy_origin ON user_copy_origin(kind, sys_key)')


# ── 원본 열쇠 ────────────────────────────────────────────────────────────
def sys_key(conn, kind, sys_id):
    if kind == 'LENS':
        r = conn.execute('SELECT unit_name_sid FROM sys_unit_asset WHERE sys_unit_id=?', (sys_id,)).fetchone()
    elif kind == 'PLAN':
        r = conn.execute('SELECT plan_code FROM sys_bible_plan WHERE plan_id=?', (sys_id,)).fetchone()
    else:
        r = conn.execute('SELECT unit_code FROM sys_ref_unit WHERE ref_unit_id=?', (sys_id,)).fetchone()
    return (r[0] or '').strip() if r and r[0] else None


def _alive_sql(kind):
    if kind == 'LENS':
        return ("EXISTS (SELECT 1 FROM user_unit_asset u WHERE u.user_unit_id=o.user_id"
                " AND COALESCE(u.record_status,'LIVE')='LIVE')")
    if kind == 'PLAN':
        return ("EXISTS (SELECT 1 FROM user_bible_plan u WHERE u.user_plan_id=o.user_id"
                " AND COALESCE(u.record_status,'LIVE')='LIVE')")
    return ("EXISTS (SELECT 1 FROM user_ref_asset a WHERE a.ref_id=o.user_id"
            " AND COALESCE(a.record_status,'LIVE')='LIVE')")


def origin_of(conn, kind, user_id):
    """사본 → {'sys_key', 'hide'} · 가져온 것이 아니면 None."""
    try:
        ensure(conn)
        r = conn.execute("SELECT sys_key, hide_origin FROM user_copy_origin WHERE kind=? AND user_id=?"
                         " AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY copy_id DESC LIMIT 1",
                         (kind, user_id)).fetchone()
    except Exception:                                     # noqa: BLE001
        return None
    return {'sys_key': r[0], 'hide': bool(r[1])} if r else None


def copy_of(conn, kind, sys_id):
    """이 원본의 살아 있는 사본 번호(가장 최근) · 없으면 None."""
    k = sys_key(conn, kind, sys_id)
    if not k:
        return None
    try:
        ensure(conn)
        r = conn.execute("SELECT o.user_id FROM user_copy_origin o WHERE o.kind=? AND o.sys_key=?"
                         " AND COALESCE(o.record_status,'LIVE')='LIVE' AND " + _alive_sql(kind) +
                         " ORDER BY o.copy_id DESC LIMIT 1", (kind, k)).fetchone()
    except Exception:                                     # noqa: BLE001
        return None
    return r[0] if r else None


def hidden_origins(conn, kind):
    """가린 원본의 열쇠 모음 — 살아 있는 사본이 「원본 가리기」일 때만."""
    try:
        ensure(conn)
        return {r[0] for r in conn.execute(
            "SELECT o.sys_key FROM user_copy_origin o WHERE o.kind=? AND o.hide_origin=1"
            " AND COALESCE(o.record_status,'LIVE')='LIVE' AND " + _alive_sql(kind), (kind,))}
    except Exception:                                     # noqa: BLE001
        return set()


def hidden_sys_ids(conn, kind):
    """가린 원본의 지금 번호 모음(목록 거르개용)."""
    keys = hidden_origins(conn, kind)
    if not keys:
        return set()
    ph = ','.join('?' * len(keys))
    if kind == 'LENS':
        sql = 'SELECT sys_unit_id FROM sys_unit_asset WHERE unit_name_sid IN (%s)' % ph
    elif kind == 'PLAN':
        sql = 'SELECT plan_id FROM sys_bible_plan WHERE plan_code IN (%s)' % ph
    else:
        sql = 'SELECT ref_unit_id FROM sys_ref_unit WHERE unit_code IN (%s)' % ph
    return {r[0] for r in conn.execute(sql, tuple(keys))}


def set_hide(conn, kind, user_id, hide):
    """원본 가리기(True) / 원본 표시하기(False)."""
    ensure(conn)
    conn.execute("UPDATE user_copy_origin SET hide_origin=? WHERE kind=? AND user_id=?"
                 " AND COALESCE(record_status,'LIVE')='LIVE'", (1 if hide else 0, kind, user_id))
    conn.commit()


def _record(conn, kind, key, user_id, hide):
    ensure(conn)
    conn.execute("INSERT INTO user_copy_origin (kind, sys_key, user_id, hide_origin, created_at)"
                 " VALUES (?,?,?,?,DATETIME('now','localtime'))", (kind, key, user_id, 1 if hide else 0))


# ── 렌즈 ─────────────────────────────────────────────────────────────────
def _langs(conn, tt, cid):
    return [r[0] for r in conn.execute(
        "SELECT DISTINCT UPPER(lang_code) FROM sys_text_asset WHERE text_type=? AND clicked_id=?"
        " AND COALESCE(record_status,'LIVE')='LIVE'", (tt, cid))]


def _lens_text(conn, tt, cid):
    """{언어: 글} — 원본 글에 내 덮개를 얹은 것(가린 것은 빠진다)."""
    import overlay
    out = {}
    langs = set(_langs(conn, tt, cid))
    for lg in ('KO', 'EN'):
        langs.add(lg)
    for lg in sorted(langs):
        body = None
        r = conn.execute("SELECT contents FROM sys_text_asset WHERE text_type=? AND clicked_id=?"
                         " AND UPPER(lang_code)=? AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
                         (tt, cid, lg)).fetchone()
        if r and (r[0] or '').strip():
            body = r[0].strip()
        try:
            ov = overlay.text_override(conn, tt, cid, lg, '')
        except Exception:                                 # noqa: BLE001
            ov = None
        if ov is not None:
            if ov[0] == 'HIDE':
                body = None
            elif (ov[1][1] or '').strip():
                body = ov[1][1].strip()
        if body:
            out[lg] = body
    return out


def _name(conn, tt, cid, lang, base):
    t = _lens_text(conn, tt, cid)
    return t.get((lang or 'KO').upper()) or t.get('KO') or t.get('EN') or base


def lens_draft(conn, sys_unit_id, lang='KO'):
    """sys 렌즈 → lens_share 초안(보이는 그대로)."""
    import lens_share
    import overlay_read
    r = conn.execute("SELECT unit_name_sid FROM sys_unit_asset WHERE sys_unit_id=? AND unit_type='CONTAINER'",
                     (sys_unit_id,)).fetchone()
    if not r:
        return None
    d = {'app': lens_share.APP_MARK, 'fmt': lens_share.FMT,
         'lens': _name(conn, 'CONT_NAME', sys_unit_id, lang, r[0]),
         'desc': _lens_text(conn, 'CONT_DESC', sys_unit_id), 'nodes': []}
    nodes = [x for x in overlay_read.links(conn, 'CONTAINER', sys_unit_id, lang)
             if x.get('kind') == 'NODE' and not x.get('hidden')]
    if not nodes:                                         # 덮개 문이 노드를 모르면 원본 차례로
        nodes = [{'id': n, '_src': 'SYS'} for (n,) in conn.execute(
            "SELECT target_id FROM sys_link_asset WHERE link_type='CONT_NODE' AND clicked_id=?"
            " AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY sort_order, sys_link_id", (sys_unit_id,))]
    for nx in nodes:
        nid = nx['id']
        nr = conn.execute('SELECT unit_name_sid FROM sys_unit_asset WHERE sys_unit_id=?', (nid,)).fetchone()
        if not nr:
            continue
        nd = {'name': _name(conn, 'NODE_NAME', nid, lang, nr[0]), 'verses': []}
        for tt, key in NODE_TT:
            t = _lens_text(conn, tt, nid)
            if t:
                nd[key] = t
        for v in overlay_read.links(conn, 'NODE', nid, lang):
            if v.get('kind') != 'VERSE' or v.get('hidden'):
                continue
            a, e = v['id'], v.get('end')
            ref = lens_share._ref_of(conn, a, e)
            if not ref:
                continue
            item = {'ref': ref}
            lr = conn.execute("SELECT sys_link_id FROM sys_link_asset WHERE link_type='NODE_VERS'"
                              " AND clicked_id=? AND target_id=? AND COALESCE(end_id,0)=COALESCE(?,0)"
                              " AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1", (nid, a, e)).fetchone()
            if lr:
                desc = {}
                for lg, body in conn.execute(
                        "SELECT UPPER(lang_code), contents FROM sys_text_asset WHERE text_type='NODE_VERS_DESC'"
                        " AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'", (lr[0],)):
                    if (body or '').strip():
                        desc[lg] = body.strip()
                if desc:
                    item['desc'] = desc
            nd['verses'].append(item)
        d['nodes'].append(nd)
    return d


def copy_lens(conn, sys_unit_id, lang='KO', hide=True):
    """sys 렌즈를 내 렌즈로 → (user_unit_id, 이름). 같은 카테고리에 들어간다."""
    import lens_share
    key = sys_key(conn, 'LENS', sys_unit_id)
    draft = lens_draft(conn, sys_unit_id, lang)
    if not key or not draft:
        raise ValueError('렌즈를 찾지 못했습니다')
    cat = conn.execute('SELECT cat_id FROM sys_unit_asset WHERE sys_unit_id=?', (sys_unit_id,)).fetchone()
    uid, name = lens_share.import_lens(conn, draft, cat_id=(cat[0] if cat else None))
    _record(conn, 'LENS', key, uid, hide)
    conn.commit()
    return uid, name


# ── 연구노트 ─────────────────────────────────────────────────────────────
def copy_ref(conn, ref_unit_id, lang='KO', hide=True):
    """sys 연구노트를 내 연구노트로 → 새 ref_id."""
    import db_user_ref_schema as U
    key = sys_key(conn, 'REF', ref_unit_id)
    u = conn.execute('SELECT unit_label, unit_question FROM sys_ref_unit WHERE ref_unit_id=?',
                     (ref_unit_id,)).fetchone()
    if not key or not u:
        raise ValueError('연구노트를 찾지 못했습니다')
    texts = {}
    for lg, title, body in conn.execute(
            "SELECT UPPER(lang_code), title, body_text FROM sys_ref_text WHERE ref_unit_id=?"
            " AND record_status='LIVE' AND COALESCE(text_variant,'ORIGINAL')='ORIGINAL'"
            " AND TRIM(COALESCE(body_text,''))<>''", (ref_unit_id,)):
        texts.setdefault(lg, ((title or '').strip(), body or ''))
    if not texts:
        raise ValueError('옮길 본문이 없습니다')
    lg0 = (lang or 'KO').upper()
    main = texts.get(lg0) or texts.get('KO') or texts.get('EN') or next(iter(texts.values()))
    title0 = main[0] or (u[0] or '')
    first_v = conn.execute("SELECT target_id FROM sys_link_asset WHERE link_type='REFU_VERS' AND clicked_id=?"
                           " AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY sys_link_id LIMIT 1",
                           (ref_unit_id,)).fetchone()
    cur = conn.execute(
        "INSERT INTO user_ref_asset (verse_id, ref_type, title, summary, lang_code, record_status)"
        " VALUES (?, 'STUDY', ?, ?, ?, 'LIVE')",
        (first_v[0] if first_v else None, title0, main[1], lg0 if lg0 in texts else None))
    rid = cur.lastrowid
    for lg, (t, b) in texts.items():
        conn.execute("INSERT INTO user_ref_text (ref_id, lang_code, title, body_text, record_status)"
                     " VALUES (?,?,?,?,'LIVE')", (rid, lg, t or title0, b))
    # 표(자리표 [[T1]] 그대로 맞물린다)
    for tid, no, nr, nc, hr in conn.execute(
            "SELECT table_id, table_no, n_rows, n_cols, head_rows FROM sys_ref_table WHERE ref_unit_id=?"
            " AND COALESCE(record_status,'LIVE')='LIVE'", (ref_unit_id,)).fetchall():
        c2 = conn.execute("INSERT INTO user_ref_table (ref_id, table_no, n_rows, n_cols, head_rows, record_status)"
                          " VALUES (?,?,?,?,?,'LIVE')", (rid, no, nr, nc, hr))
        for lg, cells in conn.execute('SELECT lang_code, cells_json FROM sys_ref_table_text WHERE table_id=?',
                                      (tid,)).fetchall():
            conn.execute('INSERT INTO user_ref_table_text (table_id, lang_code, cells_json) VALUES (?,?,?)',
                         (c2.lastrowid, lg, cells))
    links = [('VERSE', t, e) for t, e in conn.execute(
        "SELECT target_id, end_id FROM sys_link_asset WHERE link_type='REFU_VERS' AND clicked_id=?"
        " AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY sys_link_id", (ref_unit_id,))]
    links += [('ENTITY', t, None) for (t,) in conn.execute(
        "SELECT target_id FROM sys_link_asset WHERE link_type='REFU_ENTI' AND clicked_id=?"
        " AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY sys_link_id", (ref_unit_id,))]
    _record(conn, 'REF', key, rid, hide)
    conn.commit()
    if links:
        U.add_links(conn, rid, links)          # 사람이 이은 것으로(글과 동기화하지 않는다)
        conn.commit()
    return rid


# ── 자가검증 ─────────────────────────────────────────────────────────────
def selftest():
    import os
    import shutil
    import sqlite3
    import tempfile
    fails = []

    def ck(c, m):
        print(('  OK  ' if c else '  FAIL ') + m)
        if not c:
            fails.append(m)

    d = tempfile.mkdtemp(prefix='copyown_')
    try:
        main = os.path.join(d, 'm.db')
        user = os.path.join(d, 'u.db')
        src = sqlite3.connect(appdb.resolve_db('bible_master.db'))
        dst = sqlite3.connect(main)
        src.backup(dst)
        src.close()
        dst.close()
        src = sqlite3.connect(appdb.resolve_db('user_data.db'))
        dst = sqlite3.connect(user)
        src.backup(dst)
        src.close()
        dst.close()
        conn = sqlite3.connect(main)
        conn.execute("ATTACH DATABASE ? AS userdb", (user,))
        ensure(conn)
        conn.execute('DELETE FROM user_copy_origin')
        # 렌즈
        lid = conn.execute(
            "SELECT u.sys_unit_id FROM sys_unit_asset u WHERE u.unit_type='CONTAINER'"
            " AND EXISTS (SELECT 1 FROM sys_link_asset l WHERE l.link_type='CONT_NODE' AND l.clicked_id=u.sys_unit_id"
            " AND COALESCE(l.record_status,'LIVE')='LIVE') ORDER BY u.sys_unit_id LIMIT 1").fetchone()[0]
        n_sys = conn.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type='CONT_NODE' AND clicked_id=?"
                             " AND COALESCE(record_status,'LIVE')='LIVE'", (lid,)).fetchone()[0]
        sys_before = conn.execute('SELECT COUNT(*) FROM sys_unit_asset').fetchone()[0]
        uid, name = copy_lens(conn, lid, 'KO', hide=True)
        n_u = conn.execute("SELECT COUNT(*) FROM user_link_asset WHERE link_type='CONT_NODE' AND clicked_id=?",
                           (uid,)).fetchone()[0]
        ck(n_u == n_sys, '렌즈 마디 수가 같다 (%d/%d)' % (n_u, n_sys))
        nv = conn.execute("SELECT COUNT(*) FROM user_link_asset l JOIN user_link_asset c ON c.target_id=l.clicked_id"
                          " WHERE c.link_type='CONT_NODE' AND c.clicked_id=? AND l.link_type='NODE_VERS'",
                          (uid,)).fetchone()[0]
        ck(nv > 0, '구절이 함께 왔다 (%d)' % nv)
        ck(conn.execute('SELECT COUNT(*) FROM sys_unit_asset').fetchone()[0] == sys_before, '원본 불변')
        ck(lid in hidden_sys_ids(conn, 'LENS'), '원본 가리기 → 가린 목록에 든다')
        ck(copy_of(conn, 'LENS', lid) == uid, '원본 → 사본 번호')
        ck(origin_of(conn, 'LENS', uid)['hide'] is True, '사본 → 원본·가림')
        set_hide(conn, 'LENS', uid, False)
        ck(lid not in hidden_sys_ids(conn, 'LENS'), '원본 표시하기 → 목록에 돌아온다')
        set_hide(conn, 'LENS', uid, True)
        conn.execute("UPDATE user_unit_asset SET record_status='HIDE' WHERE user_unit_id=?", (uid,))
        ck(lid not in hidden_sys_ids(conn, 'LENS'), '사본을 지우면 원본이 저절로 돌아온다')
        # 연구노트
        rid0 = conn.execute(
            "SELECT u.ref_unit_id FROM sys_ref_unit u JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id"
            " WHERE s.src_type='STUDY' AND u.record_status='LIVE' AND EXISTS (SELECT 1 FROM sys_link_asset l"
            " WHERE l.link_type='REFU_VERS' AND l.clicked_id=u.ref_unit_id) ORDER BY u.ref_unit_id LIMIT 1"
        ).fetchone()[0]
        rid = copy_ref(conn, rid0, 'KO', hide=True)
        nt = conn.execute('SELECT COUNT(*) FROM user_ref_text WHERE ref_id=?', (rid,)).fetchone()[0]
        ns = conn.execute("SELECT COUNT(DISTINCT lang_code) FROM sys_ref_text WHERE ref_unit_id=? AND record_status='LIVE'"
                          " AND TRIM(COALESCE(body_text,''))<>''", (rid0,)).fetchone()[0]
        ck(nt == ns and nt > 0, '언어별 본문이 다 왔다 (%d/%d)' % (nt, ns))
        lk = conn.execute("SELECT COUNT(*) FROM user_link_asset WHERE link_type='UREF_VERS' AND clicked_id=?",
                          (rid,)).fetchone()[0]
        ck(lk > 0, '구절 연결이 왔다 (%d)' % lk)
        ck(rid0 in hidden_sys_ids(conn, 'REF'), '연구노트 원본 가리기')
        ck(conn.execute("SELECT ref_type FROM user_ref_asset WHERE ref_id=?", (rid,)).fetchone()[0] == 'STUDY',
           '내 연구노트 갈래 = STUDY')
        conn.close()
    finally:
        shutil.rmtree(d, ignore_errors=True)
    print('copy_own selftest: %s' % ('FAIL %d' % len(fails) if fails else 'PASS'))
    return not fails


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print(__doc__)
