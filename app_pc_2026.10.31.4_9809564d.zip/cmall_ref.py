# -*- coding: utf-8 -*-
"""공동체몰 참고 구현 · 시험 서버 (docs/공동체몰_약속.md · api 1) — 2026-10-27 신설·영구.

교회 서버 담당자가 보고 따라 만드는 **참고 구현**이고, 이 PC 에서 폰·PC 화면을 시험하는 **가짜 교회 서버**다.
Apps Script 견본(`cmall_apps_script.gs`)과 같은 규칙을 지킨다 — 규칙을 바꾸면 셋(문서 · 이 파일 · .gs)을 함께 고친다.

  python cmall_ref.py --selftest
  python cmall_ref.py --serve 8790 --file _cmall_test.json --pw 1234 [--seed]
"""
import hashlib
import json
import os
import re
import secrets
import sys
import threading
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

API = 1
PKG = 'com.hagah.hagah_mobile'  # 링크 쪽의 「하가에서 열기」가 여는 앱
FIELDS = ('name', 'cat', 'intro', 'phone', 'addr', 'hours', 'owner', 'link', 'dc_on', 'dc_text', 'dc_until', 'photo',
          'mode', 'desc', 'photo2', 'photo3', 'photo4', 'photo5',  # ★ 2026-10-28 보이는 방식 · 긴 설명 · 사진 다섯
          'extra')  # ★ 2026-10-28 교회별 추가 칸 {칸 열쇠: 글}
SUB_PHOTOS = ('photo2', 'photo3', 'photo4', 'photo5')
DESC_MAX = 3000
PHOTO_MAX = 40000
CATS = ['음식점', '카페', '베이커리', '미용/뷰티', '의료/건강', '교육', '생활서비스', '패션/잡화', '안경', '자동차', '부동산',
        '온라인 쇼핑몰', '기타']
# ★ 2026-10-28 앱이 정한 분류 코드(앱 표준 서식 · 폰 cmall_cats.dart · PC cmall_admin.CATS 와 같은 차례)
CAT_CODES = ('FOOD', 'CAFE', 'BAKERY', 'GROCERY', 'BEAUTY', 'MEDICAL', 'DENTAL', 'PHARMACY', 'FITNESS', 'EDU', 'KIDS',
             'LIVING', 'REPAIR', 'FASHION', 'OPTICAL', 'AUTO', 'REALTY', 'PRO', 'FINANCE', 'TRAVEL', 'FLOWER', 'PRINT',
             'IT', 'MUSIC', 'PET', 'ONLINE', 'ETC')
LINE_MAX = 200     # 추가 칸 「한 줄」
GUIDE_MAX = 2000   # 작성 안내 글
SHAPES = ('LINE', 'BOX')
FILE_APP = 'hagah-mallfile'     # 몰 파일(관리자 → 성도)
STORE_APP = 'hagah-mallstore'   # 가게 파일(사장님 → 관리자)


def clean_form(f):
    """교회별 서식 — 작성 안내 글 · 추가 칸(개수 제한 없음 · 이름 · 한 줄/큰 상자) · 쓰는 분류(비면 전부).
    칸 열쇠(k)는 관리자 도구가 한 번 붙이고 바꾸지 않는다 — 이름을 고쳐도 사장님이 적은 글이 그 칸에 남는다."""
    f = f if isinstance(f, dict) else {}
    out = {'guide': ('%s' % (f.get('guide') or '')).strip()[:GUIDE_MAX], 'fields': [], 'cats': []}
    seen = set()
    for x in f.get('fields') or []:
        if not isinstance(x, dict):
            continue
        k = ('%s' % (x.get('k') or '')).strip()
        lab = ('%s' % (x.get('label') or '')).strip()[:60]
        if not re.fullmatch(r'f\d{1,6}', k) or k in seen or not lab:
            continue
        seen.add(k)
        out['fields'].append({'k': k, 'label': lab, 'shape': 'BOX' if x.get('shape') == 'BOX' else 'LINE'})
    out['cats'] = [c for c in CAT_CODES if c in set('%s' % c for c in (f.get('cats') or []))]
    return out


def next_field_key(form):
    """새 칸 열쇠 — 지금까지 쓴 가장 큰 번호 + 1(지운 칸의 번호를 다시 쓰지 않으려면 관리자 도구가 최댓값을 기억한다)."""
    n = [int(x['k'][1:]) for x in clean_form(form)['fields']]
    return 'f%d' % ((max(n) if n else 0) + 1)


def _now():
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _hash(k):
    return hashlib.sha256(('%s' % k).encode('utf-8')).hexdigest()


def _clean(st, form=None):
    """가게 칸만 · 글자는 다듬고 · 사진은 상한 · 할인을 체크하지 않으면 내용·기간을 싣지 않는다 ·
    추가 칸은 그 교회 서식에 있는 칸만(form 이 없으면 꼴만 본다)."""
    st = st if isinstance(st, dict) else {}
    out = {}
    for f in FIELDS:
        v = st.get(f, '')
        if f == 'dc_on':
            out[f] = bool(v) and v not in ('0', 'false', 'False')
        elif f == 'extra':
            out[f] = _clean_extra(v, form)
        else:
            out[f] = ('%s' % (v or '')).strip()
    if not out['dc_on']:
        out['dc_text'] = out['dc_until'] = ''
    for f in ('photo',) + SUB_PHOTOS:
        if len(out[f]) > PHOTO_MAX:
            out[f] = ''
    out['name'] = out['name'][:80]
    out['mode'] = 'SNS' if out['mode'] == 'SNS' else 'SELF'
    out['desc'] = out['desc'][:DESC_MAX]
    return out


def _clean_extra(v, form=None):
    if isinstance(v, str):
        try:
            v = json.loads(v or '{}')
        except Exception:
            v = {}
    v = v if isinstance(v, dict) else {}
    shape = None if form is None else {x['k']: x['shape'] for x in clean_form(form)['fields']}
    out = {}
    for k, t in v.items():
        k = '%s' % k
        t = ('%s' % (t or '')).strip()
        if not t or not re.fullmatch(r'f\d{1,6}', k) or (shape is not None and k not in shape):
            continue
        out[k] = t[:DESC_MAX if (shape or {}).get(k, 'BOX') == 'BOX' else LINE_MAX]
    return out


def show_extra(store, form):
    """화면에 보일 추가 칸 — 서식 차례대로 (이름, 글, 모양) · 빈 칸과 지운 칸은 안 보인다."""
    ex = _clean_extra((store or {}).get('extra'), None)
    return [(x['label'], ex[x['k']], x['shape']) for x in clean_form(form)['fields'] if ex.get(x['k'])]


class Mall:
    """몰 하나 — 줄(rows)과 설정. 파일 하나에 JSON 으로 둔다."""

    def __init__(self, path=None, pw='', name='시험몰', church='시험교회', file_id=''):
        self.path = path
        self.lock = threading.Lock()
        self.d = {'settings': {'name': name, 'church': church, 'pw': pw, 'cats': CATS[:], 'ver': 0, 'changed': '',
                               'form': clean_form({}), 'file_id': file_id},
                  'rows': [], 'seq': 0}
        if path and os.path.exists(path):
            with open(path, encoding='utf-8') as f:
                self.d = json.load(f)
        self.d['settings'].setdefault('form', clean_form({}))

    @property
    def form(self):
        return clean_form(self.d['settings'].get('form'))

    def _save(self):
        if self.path:
            tmp = self.path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(self.d, f, ensure_ascii=False)
            os.replace(tmp, self.path)

    def _bump(self):
        s = self.d['settings']
        s['ver'] = int(s.get('ver') or 0) + 1
        s['changed'] = _now()

    def _row(self, rid):
        return next((r for r in self.d['rows'] if r['id'] == '%s' % rid), None)

    def _head(self):
        s = self.d['settings']
        pub = [r for r in self.d['rows'] if r['state'] == 'PUBLISHED']
        return {'ok': True, 'api': API, 'mall': {'name': s['name'], 'church': s['church']},
                'ver': int(s.get('ver') or 0), 'count': len(pub), 'changed': s.get('changed') or '',
                'setup': not s.get('pw')}

    def _public(self, r, full=False):
        """목록 = 대표 사진만(photos = 사진 수) · 가게 하나(a=store) = 다섯 다."""
        o = {'id': r['id']}
        o.update({f: r.get(f, '') for f in FIELDS})
        o['mode'] = 'SNS' if o.get('mode') == 'SNS' else 'SELF'
        if not o.get('dc_on'):
            o['dc_text'] = o['dc_until'] = ''
        o['extra'] = _clean_extra(r.get('extra'), self.form)
        o['posted'] = r.get('posted') or ''
        o['changed'] = r.get('changed') or ''
        o['photos'] = sum(1 for f in ('photo',) + SUB_PHOTOS if r.get(f))
        if not full:
            for f in SUB_PHOTOS:
                o.pop(f, None)
        return o

    def store(self, sid):
        r = next((x for x in self.d['rows'] if x['id'] == '%s' % sid and x['state'] == 'PUBLISHED'), None)
        return {'ok': True, 'api': API, 'store': self._public(r, True)} if r else {'ok': False, 'err': 'ID'}

    # ── 읽기 ──
    def ping(self):
        return self._head()

    def list(self):
        h = self._head()
        h['cats'] = list(self.d['settings'].get('cats') or CATS)
        h['form'] = self.form
        h['stores'] = [self._public(r) for r in self.d['rows'] if r['state'] == 'PUBLISHED']
        return h

    # ── 주인 ──
    def submit(self, b):
        op = b.get('op')
        with self.lock:
            self.d['seq'] += 1
            nid = '%d' % self.d['seq']
            if op == 'new':
                st = _clean(b.get('store'), self.form)
                if not st['name']:
                    return {'ok': False, 'err': 'NAME'}
                key = secrets.token_hex(12)
                row = dict(st, id=nid, state='PENDING', kind='NEW', ref='', key_hash=_hash(key), made=_now(),
                           posted='', changed='')
                self.d['rows'].append(row)
                self._save()
                return {'ok': True, 'id': nid, 'key': key}
            if op in ('edit', 'drop'):
                base = self._row(b.get('id'))
                if base is None or base['kind'] != 'NEW':
                    return {'ok': False, 'err': 'ID'}
                if base.get('key_hash') != _hash(b.get('key') or ''):
                    return {'ok': False, 'err': 'KEY'}
                st = _clean(b.get('store'), self.form) if op == 'edit' else {f: base.get(f, '') for f in FIELDS}
                # 같은 가게의 옛 대기 고침은 걷는다(마지막 것만 남는다)
                self.d['rows'] = [r for r in self.d['rows']
                                  if not (r['state'] == 'PENDING' and r['kind'] != 'NEW' and r['ref'] == base['id'])]
                row = dict(st, id=nid, state='PENDING', kind='EDIT' if op == 'edit' else 'DROP', ref=base['id'],
                           key_hash='', made=_now(), posted='', changed='')
                self.d['rows'].append(row)
                self._save()
                return {'ok': True, 'id': base['id']}
        return {'ok': False, 'err': 'OP'}

    # ── 관리자 ──
    def admin(self, b):
        s = self.d['settings']
        if b.get('op') == 'init':
            # 처음 한 번 — 비밀번호가 비어 있을 때만 PC 가 이름·교회·비밀번호를 적는다
            with self.lock:
                if s.get('pw'):
                    return {'ok': False, 'err': 'SET'}
                if len('%s' % (b.get('pw') or '')) < 4:
                    return {'ok': False, 'err': 'PW'}
                s['pw'] = '%s' % b['pw']
                for k in ('name', 'church'):
                    if b.get(k):
                        s[k] = ('%s' % b[k]).strip()
                self._save()
                return dict(self._head(), cats=list(s.get('cats') or CATS))
        if not s.get('pw') or b.get('pw') != s['pw']:
            return {'ok': False, 'err': 'PW'}
        op = b.get('op')
        with self.lock:
            if op == 'all':
                rows = [{k: v for k, v in r.items() if k != 'key_hash'} for r in self.d['rows']]
                return dict(self._head(), rows=rows, cats=list(s.get('cats') or CATS), form=self.form)
            if op == 'settings':
                for k in ('name', 'church'):
                    if b.get(k):
                        s[k] = ('%s' % b[k]).strip()
                if isinstance(b.get('cats'), list) and b['cats']:
                    s['cats'] = [('%s' % c).strip() for c in b['cats'] if ('%s' % c).strip()]
                if isinstance(b.get('form'), dict):
                    s['form'] = clean_form(b['form'])
                self._save()
                return dict(self._head(), cats=s['cats'], form=self.form)
            r = self._row(b.get('id'))
            if r is None:
                return {'ok': False, 'err': 'ID'}
            if op == 'publish':
                if r['kind'] == 'NEW':
                    r['state'] = 'PUBLISHED'
                    r['posted'] = r['posted'] or _now()
                    r['changed'] = _now()
                else:
                    base = self._row(r['ref'])
                    if base is None:
                        return {'ok': False, 'err': 'ID'}
                    if r['kind'] == 'EDIT':
                        base.update({f: r.get(f, '') for f in FIELDS})
                        base['state'] = 'PUBLISHED'
                        base['posted'] = base['posted'] or _now()
                        base['changed'] = _now()
                    else:
                        base['state'] = 'REMOVED'
                    self.d['rows'].remove(r)
                self._bump()
                self._save()
                return {'ok': True}
            if op == 'hold':
                was = r['state']
                r['state'] = 'HELD'
                if was == 'PUBLISHED':
                    self._bump()
                self._save()
                return {'ok': True}
            if op == 'save':
                r.update(_clean(b.get('store'), self.form))
                if r['state'] == 'PUBLISHED':
                    r['changed'] = _now()
                    self._bump()
                self._save()
                return {'ok': True}
            if op == 'delete':
                was = r['state']
                self.d['rows'].remove(r)
                if was == 'PUBLISHED':
                    self._bump()
                self._save()
                return {'ok': True}
            if op == 'rekey':
                if r['kind'] != 'NEW':
                    return {'ok': False, 'err': 'ID'}
                key = secrets.token_hex(12)
                r['key_hash'] = _hash(key)
                self._save()
                return {'ok': True, 'key': key}
        return {'ok': False, 'err': 'OP'}

    # ── 파일 방식(서버 없이 · 카톡으로 주고받는다) ──
    def take(self, d):
        """사장님이 보낸 가게 파일 하나를 대기로 받는다(관리자 쪽). 답은 submit 과 같은 꼴.
        새 가게 = 사장님 폰이 지은 번호(sid)와 열쇠 — 처음 받을 때 그 열쇠의 지문을 적어 두고, 고침·내리기는 그 열쇠로만.
        같은 새 가게를 다시 보내면(게시 전) 대기 글을 갈아 끼운다."""
        if not isinstance(d, dict) or d.get('app') != STORE_APP:
            return {'ok': False, 'err': 'APP'}
        fid = self.d['settings'].get('file_id') or ''
        if not fid or d.get('mall') != fid:
            return {'ok': False, 'err': 'MALL'}
        sid = '%s' % (d.get('sid') or '')
        key = '%s' % (d.get('key') or '')
        if not re.fullmatch(r's[0-9a-f]{12,32}', sid) or len(key) < 16:
            return {'ok': False, 'err': 'ID'}
        op = d.get('op')
        with self.lock:
            base = self._row(sid)
        if op == 'new' and base is None:
            st = _clean(d.get('store'), self.form)
            if not st['name']:
                return {'ok': False, 'err': 'NAME'}
            with self.lock:
                self.d['rows'].append(dict(st, id=sid, state='PENDING', kind='NEW', ref='', key_hash=_hash(key),
                                           made=_now(), posted='', changed=''))
                self._save()
            return {'ok': True, 'id': sid, 'op': 'new'}
        if base is None or base['kind'] != 'NEW':
            return {'ok': False, 'err': 'ID'}
        if base.get('key_hash') != _hash(key):
            return {'ok': False, 'err': 'KEY'}
        if base['state'] == 'PENDING' and op in ('new', 'edit'):
            with self.lock:   # 아직 게시 전인 새 가게 — 그 대기 글을 갈아 끼운다
                base.update(_clean(d.get('store'), self.form))
                base['made'] = _now()
                self._save()
            return {'ok': True, 'id': sid, 'op': 'new'}
        if op == 'new':
            op = 'edit'
        r = self.submit({'op': op, 'id': sid, 'key': key, 'store': d.get('store')})
        return dict(r, op=op) if r.get('ok') else r

    def mall_file(self):
        """성도에게 나눌 몰 파일 — 게시된 가게 전부(사진 다섯까지) · 서식 · 판 번호."""
        s = self.d['settings']
        return {'app': FILE_APP, 'v': API, 'mall': {'id': s.get('file_id') or '', 'name': s.get('name') or '',
                                                     'church': s.get('church') or ''},
                'ver': int(s.get('ver') or 0), 'made': _now(), 'form': self.form,
                'stores': [self._public(r, True) for r in self.d['rows'] if r['state'] == 'PUBLISHED']}

    # ── 문 하나 ──
    def open_page(self, d):
        """초대·열쇠 링크(…?hagah=…) — 「하가에서 열기」 쪽(글자열 · Apps Script openPage_ 와 같은 일)."""
        d = re.sub(r'[^A-Za-z0-9_=-]', '', d or '')
        nm = re.sub(r'[<>&"]', '', self.d['settings'].get('name', '') or '')
        href = 'intent://open?d=%s#Intent;scheme=hagah;package=%s;end' % (d, PKG)
        return ('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
                '<div style="font-family:sans-serif;max-width:520px;margin:32px auto;text-align:center"><h2>%s</h2>'
                '<a href="%s" style="display:block;padding:16px;border-radius:12px;background:#2471A3;color:#fff;font-size:20px;'
                'text-decoration:none">하가에서 열기 · Open in Hagah</a></div>' % (nm or 'Hagah', href))

    def handle(self, method, query, body):
        if method == 'GET':
            if query.get('hagah'):
                return self.open_page(query['hagah'][0])
            a = (query.get('a') or ['list'])[0]
            if a == 'store':
                return self.store((query.get('id') or [''])[0])
            return self.ping() if a == 'ping' else self.list()
        try:
            b = json.loads(body or '{}')
        except Exception:
            return {'ok': False, 'err': 'JSON'}
        if b.get('a') == 'submit':
            return self.submit(b)
        if b.get('a') == 'admin':
            return self.admin(b)
        return {'ok': False, 'err': 'OP'}


def seed(m):
    """시험용 가게 셋(관리자가 게시까지 한 것)."""
    samples = [
        {'name': '아이뜰 안경원', 'cat': '안경', 'intro': '성도님께 맞는 안경을 정성껏 맞춰 드립니다.',
         'phone': '031-000-1001', 'addr': '경기도 수원시 팔달구 인계로 45', 'hours': '월~토 10:00~20:00',
         'owner': '김성철', 'link': 'https://naver.me/example1', 'dc_on': True, 'dc_text': '렌즈 구매 시 안경테 20%',
         'dc_until': '2026-12-31'},
        {'name': '하늘 카페', 'cat': '카페', 'intro': '따뜻한 커피 한 잔으로 하루를 시작하세요.',
         'phone': '031-000-1002', 'addr': '경기도 수원시 영통구 영통로 123', 'dc_on': True, 'dc_text': '음료 10%'},
        {'name': '행복 치과', 'cat': '의료/건강', 'intro': '성도님들의 건강한 미소를 위한 치과입니다.',
         'phone': '031-000-1003', 'addr': '경기도 수원시 영통구 봉영로 77'},
    ]
    for st in samples:
        r = m.submit({'op': 'new', 'store': st})
        m.admin({'pw': m.d['settings']['pw'], 'op': 'publish', 'id': r['id']})


def new_file_id():
    return 'file:' + secrets.token_hex(8)


def new_sid():
    return 's' + secrets.token_hex(8)


def store_file(mall_id, op, sid, key, store, mall_name=''):
    """사장님 폰이 짓는 가게 파일(약속 문서의 꼴 그대로 · 폰 Dart 와 같아야 한다)."""
    return {'app': STORE_APP, 'v': API, 'mall': mall_id, 'name': mall_name, 'op': op, 'sid': sid, 'key': key,
            'store': store if op != 'drop' else {}, 'made': _now()}


def read_mall_file(text):
    """몰 파일 글 → 사전 · 꼴이 틀리면 None(받는 쪽은 그대로 둔다)."""
    try:
        d = json.loads(text) if isinstance(text, str) else text
    except Exception:
        return None
    if not isinstance(d, dict) or d.get('app') != FILE_APP or not isinstance(d.get('stores'), list):
        return None
    m = d.get('mall') or {}
    if not ('%s' % m.get('id', '')).startswith('file:'):
        return None
    d['form'] = clean_form(d.get('form'))
    return d


def newer(have_ver, d):
    """받은 몰 파일이 지금 가진 판보다 새것인가(같거나 옛것이면 바꾸지 않는다)."""
    return int((d or {}).get('ver') or 0) > int(have_ver or 0)


def serve(port, path, pw, do_seed=False):
    m = Mall(path, pw=pw)
    if do_seed and not m.d['rows']:
        seed(m)

    class H(BaseHTTPRequestHandler):
        def _send(self, d):
            html = isinstance(d, str)
            raw = (d if html else json.dumps(d, ensure_ascii=False)).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8' if html else 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def do_GET(self):
            self._send(m.handle('GET', parse_qs(urlparse(self.path).query), ''))

        def do_POST(self):
            n = int(self.headers.get('Content-Length') or 0)
            self._send(m.handle('POST', {}, self.rfile.read(n).decode('utf-8')))

        def log_message(self, *a):
            pass

    srv = ThreadingHTTPServer(('0.0.0.0', port), H)
    print('공동체몰 시험 서버 http://0.0.0.0:%d  (%s)' % (port, path))
    srv.serve_forever()


def selftest():
    ok = 0
    bad = []

    def ck(c, msg):
        nonlocal ok
        if c:
            ok += 1
        else:
            bad.append(msg)

    m = Mall(None, pw='pw1', name='하나몰', church='수원하나교회')
    h = m.ping()
    ck(h['ok'] and h['api'] == API and h['count'] == 0 and h['ver'] == 0, '빈 몰 ping')
    r = m.submit({'op': 'new', 'store': {'name': '가게', 'cat': '카페', 'dc_on': 'true', 'photo': 'x' * (PHOTO_MAX + 1)}})
    ck(r['ok'] and r['key'] and r['id'], '새 가게 → 열쇠')
    key, sid = r['key'], r['id']
    ck(m.list()['stores'] == [], '대기는 목록에 없다')
    ck(m.admin({'pw': 'no', 'op': 'all'}).get('err') == 'PW', '비밀번호 틀림')
    ck(not any('key_hash' in x for x in m.admin({'pw': 'pw1', 'op': 'all'})['rows']), '관리자에게도 지문은 안 보인다')
    ck(m.admin({'pw': 'pw1', 'op': 'publish', 'id': sid})['ok'], '게시')
    L = m.list()
    ck(L['count'] == 1 and L['ver'] == 1 and L['stores'][0]['name'] == '가게', '게시 → 목록 · 판 1')
    ck(L['stores'][0]['photo'] == '' and L['stores'][0]['dc_on'] is True, '사진 상한 · 할인 참')
    # 사진 다섯 · 보이는 방식 — 목록은 대표만(사진 수 photos) · a=store 는 다섯
    m5 = Mall(pw='pw5')
    r5 = m5.submit({'op': 'new', 'store': {'name': '사진가게', 'mode': 'SNS', 'link': 'https://naver.me/x', 'photo': 'p1',
                                          'photo2': 'p2', 'photo5': 'p5', 'desc': 'd' * 4000}})
    m5.admin({'pw': 'pw5', 'op': 'publish', 'id': r5['id']})
    s5 = next(x for x in m5.list()['stores'] if x['id'] == r5['id'])
    ck(s5['photos'] == 3 and 'photo2' not in s5 and s5['mode'] == 'SNS', '목록 = 대표 사진만 · 사진 수 · SNS')
    f5 = m5.handle('GET', {'a': ['store'], 'id': [r5['id']]}, '')['store']
    ck(f5['photo2'] == 'p2' and f5['photo5'] == 'p5' and len(f5['desc']) == DESC_MAX, '가게 하나 = 다섯 · 설명 상한')
    ck(m5.handle('GET', {'a': ['store'], 'id': ['999']}, '').get('err') == 'ID', '없는 가게')
    ck(m5.submit({'op': 'new', 'store': {'name': 'x', 'mode': '??'}}) and m5.d['rows'][-1]['mode'] == 'SELF', '모르는 방식 = SELF')
    ck('key_hash' not in L['stores'][0], '목록에 지문 없음')
    ck(m.submit({'op': 'edit', 'id': sid, 'key': 'wrong', 'store': {'name': 'x'}}).get('err') == 'KEY', '열쇠 틀리면 거부')
    r2 = m.submit({'op': 'edit', 'id': sid, 'key': key, 'store': {'name': '새 이름', 'cat': '카페'}})
    ck(r2['ok'] and m.list()['stores'][0]['name'] == '가게', '고침은 대기 — 게시 전에는 옛 글')
    r3 = m.submit({'op': 'edit', 'id': sid, 'key': key, 'store': {'name': '새 이름 2', 'cat': '카페'}})
    pend = [x for x in m.d['rows'] if x['state'] == 'PENDING']
    ck(len(pend) == 1 and pend[0]['name'] == '새 이름 2', '같은 가게의 옛 대기 고침은 걷힌다')
    m.admin({'pw': 'pw1', 'op': 'publish', 'id': pend[0]['id']})
    L = m.list()
    ck(L['stores'][0]['name'] == '새 이름 2' and L['stores'][0]['id'] == sid and L['ver'] == 2, '고침 게시 = 원래 번호에 덮음')
    m.submit({'op': 'drop', 'id': sid, 'key': key})
    pend = [x for x in m.d['rows'] if x['state'] == 'PENDING']
    m.admin({'pw': 'pw1', 'op': 'publish', 'id': pend[0]['id']})
    ck(m.list()['count'] == 0, '내리기 게시 → 목록에서 빠짐')
    nk = m.admin({'pw': 'pw1', 'op': 'rekey', 'id': sid})
    ck(nk['ok'] and nk['key'] != key and m.submit({'op': 'edit', 'id': sid, 'key': key, 'store': {'name': 'a'}}).get('err') == 'KEY',
       '열쇠 새로 → 옛 열쇠 거부')
    st = m.admin({'pw': 'pw1', 'op': 'settings', 'name': '하나몰2', 'cats': ['카페', '기타']})
    ck(st['mall']['name'] == '하나몰2' and m.list()['cats'] == ['카페', '기타'], '설정 고침')
    ck(m.handle('POST', {}, '{깨짐').get('err') == 'JSON', '깨진 본문')
    ck(m.handle('GET', {'a': ['ping']}, '')['ok'], 'GET ping 문')
    # 처음 설치 — 비밀번호가 빈 몰을 PC 가 한 번 채운다
    m3 = Mall(None, pw='', name='', church='')
    ck(m3.ping()['setup'] is True and m.ping()['setup'] is False, 'ping 이 처음 설치인지 말한다')
    ck(m3.admin({'op': 'init', 'pw': '12'}).get('err') == 'PW', '짧은 비밀번호 거부')
    i3 = m3.admin({'op': 'init', 'pw': 'abcd', 'name': '새몰', 'church': '새교회'})
    ck(i3['ok'] and i3['mall']['name'] == '새몰' and i3['setup'] is False, 'init — 이름·교회·비밀번호')
    ck(m3.admin({'op': 'init', 'pw': 'zzzz'}).get('err') == 'SET', '두 번째 init 거부(빼앗기 막기)')
    ck(m3.admin({'op': 'all', 'pw': 'abcd'})['ok'], 'init 뒤 그 비밀번호로 관리')
    # 파일 왕복
    import tempfile
    p = os.path.join(tempfile.mkdtemp(), 'm.json')
    m2 = Mall(p, pw='p')
    seed(m2)
    ck(Mall(p).list()['count'] == 3, '파일 왕복 · 견본 셋')
    pg = m.handle('GET', {'hagah': ['abc-_x']}, '')
    ck(isinstance(pg, str) and 'intent://open?d=abc-_x#Intent;scheme=hagah;package=' + PKG in pg, '링크 = 하가에서 열기 쪽')
    ck('<script' not in m.handle('GET', {'hagah': ['<script>']}, ''), '링크 글자를 거른다')
    # ★ 2026-10-28 할인 · 교회별 서식 · 파일 방식
    md = Mall(pw='q')
    rd = md.submit({'op': 'new', 'store': {'name': '할인없음', 'dc_on': False, 'dc_text': '숨은 글', 'dc_until': '2026-12-31'}})
    md.admin({'pw': 'q', 'op': 'publish', 'id': rd['id']})
    sd = md.list()['stores'][0]
    ck(sd['dc_on'] is False and sd['dc_text'] == '' and sd['dc_until'] == '', '할인 체크 안 하면 내용·기간을 싣지 않는다')
    fm = clean_form({'guide': '교인 할인을 꼭 적어 주세요', 'cats': ['CAFE', 'NOPE', 'FOOD'],
                     'fields': [{'k': 'f1', 'label': '교인 할인 내용', 'shape': 'BOX'}, {'k': 'f2', 'label': '소속 교구'},
                                {'k': 'f1', 'label': '겹침'}, {'k': 'x9', 'label': '틀린 열쇠'}, {'k': 'f3', 'label': ''}]})
    ck([x['k'] for x in fm['fields']] == ['f1', 'f2'] and fm['fields'][1]['shape'] == 'LINE', '서식 칸 — 겹침·틀린 열쇠·빈 이름은 뺀다 · 기본 한 줄')
    ck(fm['cats'] == ['FOOD', 'CAFE'], '쓰는 분류 = 앱 코드만 · 앱 차례')
    many = clean_form({'fields': [{'k': 'f%d' % i, 'label': 'L%d' % i} for i in range(1, 41)]})
    ck(len(many['fields']) == 40 and next_field_key(many) == 'f41', '추가 칸 개수 제한 없음 · 다음 열쇠')
    ck(md.admin({'pw': 'q', 'op': 'settings', 'form': fm})['form'] == fm and md.list()['form'] == fm, '서식 저장 · 목록에 실림')
    rx = md.submit({'op': 'new', 'store': {'name': '교구가게', 'extra': {'f1': 'x' * 5000, 'f2': 'y' * 500, 'f9': '모름', 'f2 ': ''}}})
    md.admin({'pw': 'q', 'op': 'publish', 'id': rx['id']})
    ex = next(x for x in md.list()['stores'] if x['id'] == rx['id'])['extra']
    ck(set(ex) == {'f1', 'f2'} and len(ex['f1']) == DESC_MAX and len(ex['f2']) == LINE_MAX, '추가 칸 — 서식에 있는 칸만 · 모양별 상한')
    ck(show_extra({'extra': {'f2': '3교구', 'f1': ''}}, fm) == [('소속 교구', '3교구', 'LINE')], '보일 추가 칸 — 빈 칸은 안 보인다')
    md.admin({'pw': 'q', 'op': 'settings', 'form': {'fields': [{'k': 'f2', 'label': '교구'}]}})
    ck(set(next(x for x in md.list()['stores'] if x['id'] == rx['id'])['extra']) == {'f2'}, '지운 칸의 글은 안 나간다')
    # 파일 방식 한 바퀴 — 사장님 가게 파일 → 관리자 대기 → 게시 → 몰 파일 → 성도
    fid = new_file_id()
    mf = Mall(pw='z', name='파일몰', church='새교회', file_id=fid)
    mf.admin({'pw': 'z', 'op': 'settings', 'form': fm})
    sid, k = new_sid(), secrets.token_hex(12)
    st1 = {'name': '파일가게', 'cat': 'CAFE', 'photo': 'p1', 'photo3': 'p3', 'extra': {'f1': '10%'}}
    ck(mf.take(store_file('file:other', 'new', sid, k, st1)).get('err') == 'MALL', '다른 몰의 가게 파일은 거부')
    t1 = mf.take(json.loads(json.dumps(store_file(fid, 'new', sid, k, st1, '파일몰'))))
    ck(t1['ok'] and t1['id'] == sid and mf.list()['stores'] == [], '가게 파일 → 대기(게시 전에는 안 보인다)')
    mf.take(store_file(fid, 'new', sid, k, dict(st1, name='파일가게 고침')))
    pend = [x for x in mf.d['rows'] if x['state'] == 'PENDING']
    ck(len(pend) == 1 and pend[0]['name'] == '파일가게 고침', '게시 전 다시 보내면 대기 글을 갈아 끼운다')
    ck(mf.take(store_file(fid, 'new', sid, 'x' * 24, st1)).get('err') == 'KEY', '같은 번호·다른 열쇠 = 거부(흉내 막기)')
    mf.admin({'pw': 'z', 'op': 'publish', 'id': sid})
    mfile = json.loads(json.dumps(mf.mall_file(), ensure_ascii=False))
    got = read_mall_file(json.dumps(mfile, ensure_ascii=False))
    s0 = got['stores'][0]
    ck(got and got['mall']['id'] == fid and got['ver'] == 1 and s0['photo3'] == 'p3' and s0['extra'] == {'f1': '10%'},
       '몰 파일 — 판 · 사진 다섯까지 · 추가 칸')
    ck(got['form'] == fm and newer(0, got) and not newer(1, got), '몰 파일에 서식 · 판 견주기')
    t2 = mf.take(store_file(fid, 'edit', sid, k, dict(st1, name='게시 뒤 고침')))
    ck(t2['ok'] and t2['op'] == 'edit' and mf.list()['stores'][0]['name'] == '파일가게 고침', '게시 뒤 고침은 대기로')
    ck(mf.take(store_file(fid, 'drop', sid, k, {}))['op'] == 'drop', '내리기 파일')
    ck(read_mall_file('{"app":"x"}') is None and read_mall_file('깨짐') is None, '꼴이 틀린 몰 파일은 안 받는다')
    big = Mall(pw='b', file_id=new_file_id())
    for i in range(30):
        rb = big.submit({'op': 'new', 'store': {'name': 'g%d' % i, **{f: 'x' * 40000 for f in ('photo',) + SUB_PHOTOS}}})
        big.admin({'pw': 'b', 'op': 'publish', 'id': rb['id']})
    mb = len(json.dumps(big.mall_file(), ensure_ascii=False)) / 1e6
    ck(mb < 7, '가게 30곳 · 사진 다섯 = %.1f MB' % mb)
    print('cmall_ref selftest %d/%d' % (ok, ok + len(bad)))
    for b in bad:
        print('  FAIL', b)
    return not bad


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    if '--serve' in sys.argv:
        a = sys.argv
        port = int(a[a.index('--serve') + 1])
        path = a[a.index('--file') + 1] if '--file' in a else '_cmall_test.json'
        pw = a[a.index('--pw') + 1] if '--pw' in a else '1234'
        serve(port, path, pw, '--seed' in a)
    else:
        print(__doc__)
