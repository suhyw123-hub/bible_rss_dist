"""
db_book_attribution.py — 도서기반 묵상플랜 텍스트 출처 표기 일괄 정비
대상: sys_book_unit_text (book_id 1, 5, 8)

- ORIGINAL       → "— Author, Book (Year)"
- MODERN_EN      → "— Modern English adaptation · Author, Book (Year)"
- TRANSLATED(KO) → "— 저자, 도서명 (연도) 한국어 의역"
- TRANSLATED(ZH) → "— 저자, 도서명（연도）中文意译"

멱등(idempotent): 기존 "— ..." 끝줄을 제거 후 재삽입하므로 재실행 안전.
"""

import re
import sqlite3
import sys

if sys.stdout.encoding and sys.stdout.encoding.lower() != 'utf-8':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

DB = 'bible_master.db'

# book_id → variant/lang → attribution 문자열
ATTR: dict[int, dict[str, str]] = {
    1: {  # Spurgeon Morning and Evening
        'ORIGINAL':   '— C.H. Spurgeon, Morning and Evening (1865)',
        'MODERN_EN':  '— Modern English adaptation · C.H. Spurgeon, Morning and Evening (1865)',
        'KO':         '— C.H. 스펄전, 아침과 저녁 (1865) 한국어 의역',
        'ZH':         '— C.H. 司布真，《晨与夕》（1865）中文意译',
    },
    5: {  # Brother Lawrence
        'ORIGINAL':   '— Brother Lawrence, The Practice of the Presence of God (c. 1692)',
        'MODERN_EN':  '— Modern English adaptation · Brother Lawrence, The Practice of the Presence of God (c. 1692)',
        'KO':         '— 로렌스 형제, 하나님의 임재 연습 (약 1692) 한국어 의역',
        'ZH':         '— 劳伦斯弟兄，《操练神的同在》（约1692）中文意译',
    },
    8: {  # E.M. Bounds
        'ORIGINAL':   '— E.M. Bounds, Power Through Prayer (1907)',
        'MODERN_EN':  '— Modern English adaptation · E.M. Bounds, Power Through Prayer (1907)',
        'KO':         '— E.M. 바운즈, 기도를 통한 능력 (1907) 한국어 의역',
        'ZH':         '— E.M. 包忠杰，《祷告的能力》（1907）中文意译',
    },
}

_TRAILING_ATTR = re.compile(r'\n\n— [^\n]+$')


def _resolve_key(variant: str, lang_code: str) -> str:
    if variant == 'MODERN_EN':
        return 'MODERN_EN'
    if variant == 'ORIGINAL':
        return 'ORIGINAL'
    # TRANSLATED / SUMMARY → lang_code 기준
    return lang_code.upper()


def _apply(body: str, attr_line: str) -> str:
    # 기존 "— ..." 끝줄 제거 후 재삽입 (멱등 보장)
    cleaned = _TRAILING_ATTR.sub('', body.rstrip())
    return cleaned + '\n\n' + attr_line


def main():
    conn = sqlite3.connect(DB, timeout=60)
    conn.execute('PRAGMA journal_mode=WAL')

    rows = conn.execute('''
        SELECT b.book_id, t.text_id, t.unit_id, t.text_variant, t.lang_code, t.body_text
        FROM sys_book_asset b
        JOIN sys_book_unit u ON u.book_id = b.book_id
        JOIN sys_book_unit_text t ON t.unit_id = u.unit_id
        WHERE b.book_id IN (1, 5, 8)
          AND t.record_status = 'LIVE'
          AND t.body_text IS NOT NULL
        ORDER BY b.book_id, u.sequence, t.text_variant
    ''').fetchall()

    updated = 0
    skipped = 0

    for book_id, text_id, unit_id, variant, lang_code, body in rows:
        key = _resolve_key(variant, lang_code)
        book_attr = ATTR.get(book_id, {})
        attr_line = book_attr.get(key)

        if attr_line is None:
            skipped += 1
            continue

        new_body = _apply(body, attr_line)
        if new_body == body:
            skipped += 1
            continue

        conn.execute(
            'UPDATE sys_book_unit_text SET body_text=? WHERE text_id=?',
            (new_body, text_id)
        )
        updated += 1
        print(f'  unit={unit_id} {variant}({lang_code}): attribution set')

    conn.commit()
    conn.close()
    print(f'\n완료: {updated}개 갱신, {skipped}개 스킵')

    # 샘플 확인
    conn2 = sqlite3.connect(DB)
    print('\n─── 샘플 끝 3줄 ───')
    checks = [
        (1, 1, 'ORIGINAL',  'unit=1 Spurgeon ORIGINAL'),
        (1, 1, 'MODERN_EN', 'unit=1 Spurgeon MODERN_EN'),
        (1, 1, 'TRANSLATED','unit=1 Spurgeon KO'),
        (5, 8, 'MODERN_EN', 'unit=8 Lawrence MODERN_EN'),
        (8,15, 'MODERN_EN', 'unit=15 Bounds MODERN_EN'),
        (8,15, 'ORIGINAL',  'unit=15 Bounds ORIGINAL'),
    ]
    for uid, unit_id, variant, label in checks:
        row = conn2.execute(
            'SELECT body_text FROM sys_book_unit_text WHERE unit_id=? AND text_variant=? AND record_status="LIVE"',
            (unit_id, variant)
        ).fetchone()
        if row and row[0]:
            last_lines = row[0].splitlines()[-2:]
            print(f'\n  {label}:')
            for ln in last_lines:
                print(f'    {repr(ln)}')
    conn2.close()


if __name__ == '__main__':
    main()
