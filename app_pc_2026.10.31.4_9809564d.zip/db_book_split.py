# -*- coding: utf-8 -*-
"""db_book_split.py — 도서 **미완 적재 정리**(유닛 쪼개기) (2026-08-28 신설·영구).

★★★ 왜 (2026-08-28 실측): 본문은 다 들어왔는데 **유닛이 안 쪼개진** 책들이
  있다 — 한 유닛이 20~30만 자면 읽기 화면에서 넘길 수 없는 벽이다.
  | 책 | 유닛 | 본문 |
  |---|---|---|
  | Grace Abounding | 4 | 306,660자(한 유닛 219,496) |
  | Edwards 설교집 | 7 | 296,634자(설교 한 편 4만) |
  | Answers to Prayer | 3 | 171,309자 |

**유닛 = 묵상 한 자리** (2026-08-28 사용자 지시로 기준 개정).
  나누는 **자리**는 원문 표지·문단 경계에서만 고르고, **크기**는 독자가
  정한다. **지침 전문 = `booktrans.md` §1-6.**
  ⚠ 옛 규칙(「원문 표지만 쓴다」)은 절반만 맞았다 — 저자가 CHAPTER 하나를
    40분치로 쓴 책(스펄전 설교 37,000자)에서 그 표지만 따르면 독자가 벽
    앞에 선다. 실측: 구절 앵커가 붙은 책은 전부 1,200~2,900자이고
    14,000자 넘는 책은 앵커가 **전부 0%** 다.
  ⚠ 원문에 문단(빈 줄)조차 없으면 **그대로 두고 원문을 다시 받는다** —
    없는 정보를 지어내어 자르면 문장 중간이 끊긴다.

**원문 대조를 먼저 통과해야 쪼갠다**(§0-1b). 위작·주해 혼입 상태로 쪼개면
  가짜를 20조각으로 늘리는 꼴이다(천로역정이 실제로 그랬다 — `db_bunyan_pp`).

    python db_book_split.py --selftest        (의무)
    python db_book_split.py --scan            # 쪼갤 후보 훑기
    python db_book_split.py --audit           # ★ 적재된 전권을 읽기 대역으로 잰다
    python db_book_split.py --check <CODE> <원문>   # 미리보기(등급·읽기분)
    python db_book_split.py --apply <CODE> <원문>   # 적용(백업 보존)
      옵션: --raw(안쪽 나누기 끔) · --force(벽 게이트 통과 — 장르 판단)
"""
import io
import os
import re
import sys

import appdb

BACKUP = 'temp_book_split_backup'

#: 표지 규칙 — 위에서부터 맞는 것 하나를 쓴다(원문이 무엇으로 나뉘는가)
RULES = (
    ('CHAPTER', r'^\s{0,6}CHAPTER\s+[IVXLC\d]+[\.\s]*.*$'),
    ('SERMON',  r'^\s{0,6}SERMON\s+[IVXLC\d]+[\.\s]*.*$'),
    ('STAGE',   r'^\s{0,6}THE\s+[A-Z]+\s+STAGE\s*$'),
    ('LETTER',  r'^\s{0,6}(FIRST|SECOND|THIRD|FOURTH|FIFTH|SIXTH|SEVENTH|'
                r'EIGHTH|NINTH|TENTH|ELEVENTH|TWELFTH)\s+LETTER\s*$'),
    ('CAPS',    r'^\s{0,6}[A-Z][A-Z \'\.,\-]{12,60}$'),
    # ★ 절 번호 — 번연 『Grace Abounding』처럼 장이 없고 **번호로만** 나뉘는
    #   책(실측 347개). 그대로 쪼개면 유닛이 잘아 `GROUP_N` 개씩 묶는다.
    ('NUMSEC',  r'^\s{0,6}\d{1,3}\.\s+\S'),
)

#: 절 번호 책을 몇 절씩 한 유닛으로 묶나 (읽기 한 호흡)
GROUP_N = 20

#: 한 유닛이 이보다 크면 「벽」으로 본다(사용자 화면 기준 — 실측 30만 자 사례)
WALL = 60000
#: 이보다 작은 토막은 표제만 있는 줄로 보고 앞 유닛에 붙인다
MIN_CHUNK = 400

# ══════════════════════════════════════════════════════════════════
#  읽기 대역 — 「묵상 한 자리」의 크기 (2026-08-28 사용자 지시로 신설)
#
#  ★★★ 사용자: 「유닛 분할의 기준을 오로지 원본에 의존할 것이 아니라
#    독자들이 읽기 편한 단위로 나누어야 한다. **유닛 단위로 묵상구절이
#    연결되면 좋기 때문이다.**」
#
#  ⇒ **구절을 댈 수 있느냐가 크기를 판정한다.** 실측이 그렇게 말한다 —
#    구절 앵커가 붙은 책은 전부 작고, 안 붙은 책은 전부 크다:
#      SPURGEON_ME 1,973자 앵커 100% · MEYER_ODH 1,818 98% ·
#      MILLER 1,607 63% · TOD 1,750 100% · CLEMENT 1,193 100%
#      ↕ 경계
#      MULLER 4,220 **0%** · SHELDON 14,479 **0%** ·
#      EDERSHEIM 30,257 **0%** · LAW 30,750 **0%**
#    그리고 묵상플랜이 하루로 쓰는 것도 **작은 쪽뿐**이다(MEYER 1,189일 ·
#    TOD 150일 · KEMPIS 59일 / 큰 쪽은 플랜이 하나도 없다).
#    40분짜리 덩어리에 구절 하나를 붙여도 그 구절이 글을 대표하지 못한다.
# ══════════════════════════════════════════════════════════════════

#: 영문 원문 → 한국어 번역 자수 환산(실측 대역 0.5~0.6의 가운데)
KO_RATIO = 0.55
#: 한국어 분당 읽기 자수
CPM = 500

#: 목표 대역 — 영문 원문 자수 기준 (한국어 약 500~2,000자 · 1~4분)
AIM_LO, AIM_HI = 900, 3600
#: 장르상 허용 상한 (한국어 약 4,400자 · 9분). 넘으면 안을 더 나눈다
OK_HI = 8000

GRADES = ('SMALL', 'AIM', 'OK', 'BIG', 'WALL')


def read_min(n):
    """영문 자수 → 한국어로 읽는 데 걸리는 분."""
    return n * KO_RATIO / CPM


def grade(n):
    """조각 하나의 등급 — (등급, 한 줄 사유)."""
    if n < MIN_CHUNK:
        return 'SMALL', '표제만 있는 줄 — 앞에 붙인다'
    if n < AIM_LO:
        return 'SMALL', '너무 짧다 — 묶는다'
    if n <= AIM_HI:
        return 'AIM', '묵상 한 자리'
    if n <= OK_HI:
        return 'OK', '길지만 한 호흡에 읽힌다'
    if n <= WALL:
        return 'BIG', '구절 하나로 대표되지 않는다 — 안을 더 나눈다'
    return 'WALL', '벽 — 반드시 나눈다'


def measure(units):
    """유닛 목록을 재서 요약 — 지침을 지켰는지 한눈에.

    반환 = {n, aim, ok, big, wall, small, median, worst, pass}
    ⚠ `pass` 는 **BIG·WALL 이 하나도 없을 때만** 참이다. 평균이 좋아도
      벽이 하나 있으면 그 자리에서 독자가 막힌다 — 평균으로 덮지 않는다.
    """
    ns = sorted(len(b) for _t, b in units)
    cnt = dict((g, 0) for g in GRADES)
    for n in ns:
        cnt[grade(n)[0]] += 1
    return {
        'n': len(ns),
        'median': ns[len(ns) // 2] if ns else 0,
        'worst': ns[-1] if ns else 0,
        'aim': cnt['AIM'], 'ok': cnt['OK'], 'big': cnt['BIG'],
        'wall': cnt['WALL'], 'small': cnt['SMALL'],
        'pass': not ns or (cnt['BIG'] == 0 and cnt['WALL'] == 0),
    }


# ══════════════════════════════════════════════════════════════════
#  두 층 구조 — 「구역(Section) + 번호 단상(fragment)」
#
#  ★ 고전에 흔한 모양이다. 파스칼 『팡세』가 그 전형 — SECTION 14개 안에
#    번호만 제 줄에 선 단상 923편(Trotter 판 1~923)이 들어 있다.
#    단상 하나는 중앙 269자라 **그것만으로는 너무 잘고**(SMALL), 구역
#    하나는 4만 자라 **너무 크다**(BIG). 답은 **구역 안에서 단상을 대역까지
#    모으는 것**이다 → 「Section II — … · §60–68」.
#  ⚠ **구역을 넘어 모으지 않는다** — 넘으면 제목이 무엇을 가리키는지 없어진다.
# ══════════════════════════════════════════════════════════════════

#: 번호만 제 줄에 선 단상 표지
FRAG_PAT = r'(?m)^[ \t]{0,6}(\d{1,3})[ \t]*$'

#: 바깥 구역 표지
OUTER_PATS = (
    ('SECTION', r'(?m)^[ \t]{0,6}(SECTION\s+[IVXLC\d]+)[ \t]*$'),
    ('PART',    r'(?m)^[ \t]{0,6}(PART\s+(?:THE\s+)?[IVXLC\d]+|'
                r'PART\s+(?:FIRST|SECOND|THIRD|FOURTH))[ \t]*$'),
    ('BOOK',    r'(?m)^[ \t]{0,6}(BOOK\s+[IVXLC\d]+)[ \t]*$'),
)

#: 단상이 이보다 적으면 두 층으로 보지 않는다(우연한 숫자 줄 배제)
FRAG_MIN = 30


_SMALL_W = {'of', 'the', 'and', 'on', 'in', 'to', 'for', 'a', 'an', 'by',
            'with', 'or', 'at', 'from', 'as', 'is'}
_ROMAN = re.compile(r'^[IVXLC]+$')


def _nice(s):
    """다 대문자인 표제를 읽기 좋게 — **로마 숫자는 대문자로 지킨다**.

    ⚠ `str.title()` 만 쓰면 `SECTION XIV` 가 **`Section Xiv`** 가 된다
      (실측으로 잡았다). 로마 숫자는 낱말이 아니다.
    """
    if not s.isupper():
        return s
    out = []
    for i, w in enumerate(s.split()):
        core = w.strip('.,:;—-')
        if _ROMAN.match(core) and core:
            out.append(w)
        elif i and core.lower() in _SMALL_W:
            out.append(w.lower())
        else:
            out.append(w.capitalize())
    return ' '.join(out)


def _title_after(src, pos):
    """구역 표지 **다음** 비어 있지 않은 줄 = 그 구역의 이름.

    ⚠ `SECTION II` 만으로는 무엇인지 알 수 없다 — 바로 아래 줄에
      `THE MISERY OF MAN WITHOUT GOD` 이 있다. 그것까지가 제목이다.
    """
    for ln in src[pos:pos + 400].split('\n')[1:]:
        s = ln.strip()
        if s:
            return _nice(s)
    return ''


def detect_frag(src):
    """두 층인가 → (구역목록, 단상목록). 아니면 ([], [])."""
    frags = [(m.start(), m.group(1)) for m in re.finditer(FRAG_PAT, src)]
    if len(frags) < FRAG_MIN:
        return [], []
    outer = []
    for _nm, pat in OUTER_PATS:
        ms = [(m.start(), m.group(1).strip(), _title_after(src, m.start()))
              for m in re.finditer(pat, src)]
        if len(ms) > len(outer):
            outer = ms
    return outer, frags


def split_fragments(src, lo=AIM_LO, hi=AIM_HI):
    """구역 안에서 단상을 대역까지 모아 유닛으로 만든다."""
    outer, frags = detect_frag(src)
    if not frags:
        return []
    # 구역 경계(없으면 전체가 한 구역)
    bounds = [(o[0], '%s%s' % (_nice(o[1]),
                               (' — ' + o[2]) if o[2] else ''))
              for o in outer] or [(0, '')]
    out = []
    for bi, (bpos, btitle) in enumerate(bounds):
        bend = bounds[bi + 1][0] if bi + 1 < len(bounds) else len(src)
        mine = [f for f in frags if bpos <= f[0] < bend]
        if not mine:
            continue
        # 단상 = (번호, 글). 구역 안에서만 모은다
        pieces = []
        for k, (pos, num) in enumerate(mine):
            end = mine[k + 1][0] if k + 1 < len(mine) else bend
            pieces.append((num, src[pos:end].strip()))

        def _title(a, b):
            tag = '§%s–%s' % (a, b) if a != b else '§%s' % a
            return ('%s · %s' % (btitle, tag)) if btitle else tag

        cur, cn, first = [], 0, pieces[0][0]
        for num, piece in pieces:
            # 담으면 상한을 넘고 이미 하한을 채웠으면 여기서 끊는다
            if cur and cn + len(piece) > hi and cn >= lo:
                out.append((_title(first, cur[-1][0]),
                            '\n\n'.join(p for _n, p in cur)))
                cur, cn, first = [], 0, num
            cur.append((num, piece))
            cn += len(piece) + 2
        if cur:
            body = '\n\n'.join(p for _n, p in cur)
            if out and len(body) < MIN_CHUNK:     # 꼬리가 짧으면 앞에 붙인다
                out[-1] = (out[-1][0], out[-1][1] + '\n\n' + body)
            else:
                out.append((_title(first, cur[-1][0]), body))
    return out


#: 큰 조각 **안쪽**의 표지 — 위에서부터 맞는 것 하나
INNER = (
    ('POINT', r'(?m)^\s{0,6}(?:I|II|III|IV|V|VI|VII|VIII|IX|X)\.\s+\S'),
    ('NUM',   r'(?m)^\s{0,6}\d{1,2}\.\s+\S'),
)


#: 홑 줄바꿈 토막이 이보다 길면 **문단**으로 본다(그 아래는 줄접기)
WRAP_MAX = 200

#: 문단 안 줄 중앙값이 이보다 길면 **강제 줄바꿈**으로 본다(그 아래는 시·목록)
WRAP_LINE = 45


def unwrap(text):
    """구텐베르크식 **강제 줄바꿈을 편다** — 한 문단을 한 줄로.

    ★★ 왜 (2026-08-28 실측): 구텐베르크 `.txt` 는 1970년대 터미널에 맞춰
      72자마다 줄을 끊는다. 그것은 저자의 구조가 아니라 **표시 형식**인데,
      우리 읽기 화면(Tk Text)은 그 `\\n` 을 강제 줄바꿈으로 그려 아무 데서나
      끊긴 줄을 보인다. 실측 줄당 자수 —
        PASCAL 58 · BUNYAN_PP 64   ← 강제 줄바꿈
        CLEMENT 174 · MEYER 296 · SPURGEON_ME 507 · TOD 651  ← 문단이 한 줄
      우리 다른 책은 전부 문단이 한 줄이므로, 이 둘만 형식이 다르다.

    ⚠ **시(詩)는 건드리지 않는다.** 짧은 줄로 된 문단(중앙 `WRAP_LINE` 미만)은
      저자가 일부러 끊은 것이다 — 펴면 시가 산문이 된다.
    ⚠ 빈 줄(문단 경계)은 그대로 둔다.
    """
    # ⚠ `re.split` 은 캡처 묶음 하나면 [글, 구분자, 글, …] 로 돌려준다.
    #   구분자를 「`\n` 으로 시작하는가」로 가리면 **빈 줄이 셋인 자리**에서
    #   남은 `\n` 을 달고 오는 본문 토막까지 구분자로 잘못 본다(실측으로 잡았다 —
    #   파스칼 첫 문단이 그래서 안 펴졌다). **자리 홀짝으로 가른다.**
    out = []
    for i, para in enumerate(re.split(r'(\n[ \t]*\n)', text or '')):
        if i % 2 or not para.strip():
            out.append(para)
            continue
        ls = [l for l in para.split('\n') if l.strip()]
        if len(ls) > 1 and sorted(len(l) for l in ls)[len(ls) // 2] >= WRAP_LINE:
            out.append(' '.join(l.strip() for l in ls))
        else:
            out.append(para)
    return ''.join(out)


def wrap_stat(conn, code):
    """그 책이 강제 줄바꿈인가 → (유닛수, 줄당 자수)."""
    rows = [r[0] for r in conn.execute(
        "SELECT x.body_text FROM sys_book_asset b "
        "JOIN sys_book_unit u ON u.book_id=b.book_id "
        "JOIN sys_book_unit_text x ON x.unit_id=u.unit_id "
        "  AND x.text_variant='ORIGINAL' WHERE b.book_code=?", (code,))]
    tot = sum(len(t or '') for t in rows)
    ln = sum(len([l for l in (t or '').split('\n') if l.strip()]) for t in rows)
    return len(rows), tot // max(ln, 1)


def unwrap_book(conn, code, dry=True):
    """그 책의 `ORIGINAL` 을 편다. 백업 보존 · 유닛은 손대지 않는다.

    ⚠ **번역이 있으면 거부한다** — 원문 줄 수가 바뀌면 번역 게이트의
      구조 대조(줄 수)가 어긋난다. 번역 전에 편다.
    """
    r = conn.execute('SELECT book_id FROM sys_book_asset WHERE book_code=?',
                     (code,)).fetchone()
    if not r:
        raise SystemExit('%s 가 없다' % code)
    bid = r[0]
    tv = conn.execute(
        "SELECT COUNT(*) FROM sys_book_unit u "
        "JOIN sys_book_unit_text x ON x.unit_id=u.unit_id "
        "WHERE u.book_id=? AND x.text_variant<>'ORIGINAL'", (bid,)).fetchone()[0]
    if tv:
        raise SystemExit('거부: 이 책에는 원문 아닌 변형이 %d편 있다. '
                         '줄 수가 바뀌면 번역 구조 대조가 어긋난다 — '
                         '**번역 전에** 편다.' % tv)
    rows = conn.execute(
        "SELECT x.text_id, x.body_text FROM sys_book_unit u "
        "JOIN sys_book_unit_text x ON x.unit_id=u.unit_id "
        "  AND x.text_variant='ORIGINAL' WHERE u.book_id=?", (bid,)).fetchall()
    changed = [(tid, unwrap(bt)) for tid, bt in rows]
    changed = [(tid, nt) for (tid, nt), (_t, ot) in zip(changed, rows)
               if nt != ot]
    if dry:
        return len(rows), len(changed)
    conn.execute('CREATE TABLE IF NOT EXISTS %s (book_code TEXT, unit_id INT,'
                 ' sequence INT, unit_label TEXT, text_variant TEXT,'
                 ' lang_code TEXT, body_text TEXT, saved_at TEXT)' % BACKUP)
    conn.execute(
        'INSERT INTO %s SELECT ?, u.unit_id, u.sequence, u.unit_label, '
        "  x.text_variant, x.lang_code, x.body_text, "
        "  DATETIME('now','localtime') "
        'FROM sys_book_unit u JOIN sys_book_unit_text x '
        "  ON x.unit_id=u.unit_id AND x.text_variant='ORIGINAL' "
        'WHERE u.book_id=?' % BACKUP, (code + '/unwrap', bid))
    for tid, nt in changed:
        conn.execute('UPDATE sys_book_unit_text SET body_text=? WHERE text_id=?',
                     (nt, tid))
    conn.commit()
    return len(rows), len(changed)


def paragraphs(text):
    """문단으로 가른다 — 빈 줄이 문단 경계다.

    ★★ **빈 줄이 없다고 문단이 없는 것은 아니다** (2026-08-28 실측으로
      잡았다). 적재 도구에 따라 문단이 `\\n\\n` 이 아니라 **홑 `\\n`** 으로
      들어와 있다:
        AUGUSTINE_CONF 빈줄 2.0개 · 그러나 줄바꿈 38개 → 줄당 1,220자
        EDERSHEIM_LT   빈줄 2.0개 · 그러나 줄바꿈 20개 → 줄당 1,502자
      1,200자짜리 「줄」은 줄이 아니라 **문단**이다. 처음에 빈 줄만 보고
      「문단 정보가 소실됐다 → 원문 재수집」이라 판정했는데 **틀렸다** —
      다섯 권이 그대로 나뉜다.

    ⚠ 반대로 줄당 자수가 짧으면(PASCAL 135자) 그것은 **줄접기**(hard wrap)
      라 문단 경계가 아니다. 그때만 진짜로 문단 정보가 없는 것이고,
      **쪼개지 말고 원문을 다시 받는다.**
    """
    ps = [p.strip() for p in re.split(r'\n\s*\n', text) if p.strip()]
    lines = [p.strip() for p in text.split('\n') if p.strip()]
    # ⚠ 「빈 줄이 하나라도 있으면 그것으로 끝」이 아니다 — 빈 줄 2개짜리
    #   책(LAW·AUGUSTINE)은 그 둘만 쓰면 여전히 3만 자 덩어리다.
    #   **더 잘게 나오는 쪽**을 쓰되, 줄접기(짧은 줄)는 배제한다.
    if len(lines) > len(ps) and lines and len(text) / len(lines) >= WRAP_MAX:
        return lines                      # 홑 줄바꿈이 문단이었다
    return ps or ([text.strip()] if text.strip() else [])


def pack(paras, lo=AIM_LO, hi=AIM_HI):
    """문단을 목표 대역으로 **모은다** — 문단 경계에서만 자른다.

    ★ 분량으로 임의 재단하지 않는다는 원칙과 어긋나지 않는다 — 자르는 자리는
      언제나 저자가 문단을 끊은 자리이고, 분량은 **어느 문단 경계를 고를지**만
      정한다. 그래서 문장 중간이 절대 안 끊긴다.
    """
    out, cur, cn = [], [], 0
    for p in paras:
        if cur and cn + len(p) > hi and cn >= lo:
            out.append('\n\n'.join(cur))
            cur, cn = [], 0
        cur.append(p)
        cn += len(p) + 2
    if cur:
        tail = '\n\n'.join(cur)
        if out and len(tail) < MIN_CHUNK:       # 꼬리가 짧으면 앞에 붙인다
            out[-1] += '\n\n' + tail
        else:
            out.append(tail)
    return out


# ── 마지막 층: 문장 경계 ────────────────────────────────────────
#
# ★★ 사용자 지시(2026-08-28): 「문단이 긴 책은 **읽은 곳 기억하도록 인위적으로
#   분할**」. 실측 — 문단으로 안 나뉘는 조각은 전체 45,553 중 **47개(0.10%)**
#   지만, 그 하나가 2~3만 자면 독자는 거기서 진도를 기록할 길이 없다.
#
# ⚠⚠ **옛 「파트」 설계와 다르다는 것을 분명히 한다.** `db_read_state.py` 가
#   「다시는 파트 따위의 설계를 하지 마라」로 폐기한 것은 ① 경계가 화면에
#   안 보이고 ② 페이지마다 쓸 수 있는 것으로 착각하게 하고 ④ **DB 행도 없이**
#   그릴 때마다 계산해 붙는 것이 없었기 때문이다. 여기서는 **진짜 유닛 행**을
#   만들므로 ①②④가 없다 — 목록에 제목으로 보이고, 밑줄·메모·읽음·구절이
#   붙는다.
#   ③(저자가 안 나눈 자리에 의미를 붙인다)만 남는다. 그래서 **제목이 스스로
#   인위적임을 말한다** — `(이어서 2/3)`. 없는 의미를 붙이지 않는다.
#
# ⚠ **문장 중간은 어떤 경우에도 자르지 않는다.** 한 문장이 상한을 넘으면
#   그 문장은 통째로 둔다(그런 문장은 실측 0건).

#: 마침표가 문장 끝이 아닌 낱말 — 이 뒤에서는 안 자른다
_ABBR = set("""Mr Mrs Ms Dr St Sr Jr Rev Prof Gen Col Capt Sgt Lieut Hon
Esq vs etc viz cf ca vol vols ch chap p pp no No fig Fig ver Ver
i.e e.g A.D B.C a.m p.m
Matt Mk Lk Jn Rom Cor Gal Eph Phil Thess Tim Tit Philem Heb Jas Pet Jude
Gen Ex Lev Num Deut Josh Judg Sam Kgs Chron Ezr Neh Esth Ps Prov Eccl Isa
Jer Lam Ezek Dan Hos Obad Jon Mic Nah Hab Zeph Hag Zech Mal""".split())

_SENT_END = re.compile(r'(?<=[.!?])["\'’”)\]]*\s+(?=[A-Z"\'‘'
                       r'“(\[])')


def sentences(text):
    """문장으로 가른다 — 약어 뒤는 문장 끝이 아니다.

    ⚠ `St. Paul` · `i.e.` · `Rom. 8:1` 에서 자르면 문장이 두 동강 난다.
      실제로 성경 약어가 이 글들에 빽빽하다.
    """
    parts, prev = [], 0
    for m in _SENT_END.finditer(text):
        head = text[max(0, m.start() - 14):m.start()]
        w = re.split(r'[\s(\[]', head)[-1].rstrip('.').lstrip('"\'')
        if w in _ABBR or (len(w) == 1 and w.isupper()):
            continue                      # 약어 · 이름 머리글자(J. Smith)
        parts.append(text[prev:m.start()].strip())
        prev = m.end()
    tail = text[prev:].strip()
    if tail:
        parts.append(tail)
    return [p for p in parts if p]


def subsplit(title, body):
    """큰 조각의 **안**을 더 나눈다 → [(제목, 토막)].

    차례 = ① 저자가 안에 둔 대문단 표지(I. II. III.) ② 문단 모으기
           ③ **문장 모으기**(마지막 층 · 인위적임을 제목이 말한다).
    ⚠ 셋 다 안 되면 **그대로 돌려준다** — 못 나누는 것을 나눈 척하지 않는다.
    """
    if len(body) <= OK_HI:
        return [(title, body)]
    parts = [body]
    for _nm, pat in INNER:
        ms = [m.start() for m in re.finditer(pat, body)]
        if len(ms) >= 2 and ms[0] > MIN_CHUNK:
            parts, prev = [], 0
            for pos in ms + [len(body)]:
                seg = body[prev:pos].strip()
                if seg:
                    parts.append(seg)
                prev = pos
            break
    pieces = []
    for seg in parts:
        pieces += _reduce(seg)
    if len(pieces) <= 1:
        return [(title, body)]
    return _numbered(title, pieces)


def _reduce(seg):
    """한 토막을 대역까지 줄인다 → [(조각, **인위적인가**)].

    차례 = 문단 → (아직 벽이면) 문장. 어느 층에서 나왔는지를 함께 돌려주어
    제목이 **인위적인 자리인지 말할 수 있게** 한다.
    ⚠ 대문단 표지로 가른 갈래에도 이 함수를 태운다 — 예전에는 그 갈래에만
      문장 층이 안 걸려 스펄전 설교 31조각이 벽으로 남았다(실측으로 잡았다).
    """
    if len(seg) <= OK_HI:
        return [(seg, False)]
    fine = pack(paragraphs(seg))
    if len(fine) > 1:
        out = []
        for s in fine:
            if len(s) > OK_HI:
                ss = _split_sent(s)
                out += [(x, len(ss) > 1) for x in ss]
            else:
                out.append((s, False))
        return out
    ss = _split_sent(seg)
    return [(x, len(ss) > 1) for x in ss]


def _split_sent(text):
    """한 문단을 문장 경계로 모은다. 못 나누면 그대로 [text]."""
    ss = sentences(text)
    return pack(ss) if len(ss) > 1 else [text]


def _numbered(title, pieces):
    """`(2/5)` = 저자가 나눈 자리 · `(이어서 2/5)` = **우리가 나눈 자리**."""
    n = len(pieces)
    if n <= 1:
        return [(title, pieces[0][0])] if pieces else []
    out = []
    for i, (p, art) in enumerate(pieces, 1):
        fmt = '%s (이어서 %d/%d)' if art else '%s (%d/%d)'
        out.append((fmt % (title, i, n), p))
    return out


#: 본문이 아닌 꼬리·머리 — 기관이 붙인 안내(§0-1b 「도서관 대출 카드」 계열)
_STRIP = (
    '*** END OF THE PROJECT GUTENBERG',
    'PLEASE READ THIS BEFORE YOU DISTRIBUTE',
    'START: FULL LICENSE',
    '\nReferences\n',
    'This document is from the Christian Classics',
)


def strip_frame(src):
    """기관 안내를 걷는다 — 저자의 글만 남긴다.

    ⚠ 실측: Müller 마지막 유닛이 구텐베르크 라이선스 전문(17,366자)이었다.
      쪼개기 전에 안 걷으면 **라이선스가 한 장(章)이 된다.**
    ⚠ 머리의 `*** START OF …` 앞부분(PG 서지)도 본문이 아니다.
    """
    i = src.find('*** START OF')
    if i >= 0:
        j = src.find('\n', i)
        if j > 0:
            src = src[j + 1:]
    for mk in _STRIP:
        k = src.find(mk)
        if k > 1000:                      # 머리 근처의 우연한 일치는 무시
            src = src[:k]
    return src


def detect_rule(src):
    """원문이 무엇으로 나뉘는가 → (규칙 이름, 표지 목록). 없으면 (None, [])."""
    best = (None, [])
    for name, pat in RULES:
        ms = [(m.start(), re.sub(r'\s+', ' ', m.group(0)).strip())
              for m in re.finditer(pat, src, re.M)]
        # 표지가 2개 미만이면 나눌 것이 없다. CAPS 는 너무 흔하면 표제가 아니다
        if len(ms) < 2:
            continue
        if name == 'CAPS' and len(ms) > 400:
            continue
        if len(ms) > len(best[1]):
            best = (name, ms)
    return best


def split_text(src, rule=None, deep=True):
    """본문 → [(제목, 토막)]. 원문 표지가 없으면 [] (쪼개지 않는다).

    `deep` — 조각이 `OK_HI` 를 넘으면 **안을 더 나눈다**(`subsplit`).
      ★ 원문 표지는 **재료이지 자[尺]가 아니다.** 저자가 CHAPTER 하나를
        40분치로 썼으면(스펄전 설교 37,000자) 그 표지만 따르는 것은
        「원문에 충실」이 아니라 **독자를 벽 앞에 세우는 것**이다.
      ⚠ `deep=False` 는 원문 구조를 그대로 보고 싶을 때만(`--check --raw`).
    """
    src = strip_frame(src)
    # ★ 두 층(구역 + 번호 단상)이면 그쪽이 먼저다 — 표지 규칙보다 정확하다
    if rule in (None, 'FRAG'):
        fr = split_fragments(src)
        if fr:
            return _deepen(fr) if deep else fr
    name, ms = detect_rule(src) if rule is None else (rule, [])
    if not ms:
        return []
    out = []
    head = src[:ms[0][0]].strip()
    if len(head) >= MIN_CHUNK:
        out.append(('머리말', head))
    if name == 'NUMSEC':
        for a in range(0, len(ms), GROUP_N):
            grp = ms[a:a + GROUP_N]
            beg = grp[0][0]
            end = ms[a + GROUP_N][0] if a + GROUP_N < len(ms) else len(src)
            body = src[beg:end].strip()
            if len(body) < MIN_CHUNK:
                continue
            n1 = grp[0][1].split('.')[0].strip()
            n2 = grp[-1][1].split('.')[0].strip()
            out.append(('§%s–%s' % (n1, n2), body))
        return _deepen(out) if deep else out
    for i, (pos, title) in enumerate(ms):
        end = ms[i + 1][0] if i + 1 < len(ms) else len(src)
        chunk = src[pos:end].strip()
        if len(chunk) < MIN_CHUNK:
            if out:                       # 표제만 있는 줄 — 앞에 붙인다
                out[-1] = (out[-1][0], out[-1][1] + '\n\n' + chunk)
            continue
        out.append((title[:60], chunk))
    return _deepen(out) if deep else out


def _deepen(units):
    """큰 조각을 안쪽까지 나눈다 — 목록 전체에 `subsplit` 을 태운다."""
    out = []
    for title, body in units:
        out += subsplit(title, body)
    return out


# ══════════════════════════════════════════════════════════════════
#  DB
# ══════════════════════════════════════════════════════════════════
def scan(conn):
    """쪼갤 후보 — 유닛이 적고 한 유닛이 벽인 책."""
    rows = conn.execute(
        "SELECT b.book_id, b.book_code, b.title, COUNT(u.unit_id), "
        "  MAX(LENGTH(COALESCE(x.body_text,''))) "
        "FROM sys_book_asset b "
        "JOIN sys_book_unit u ON u.book_id=b.book_id "
        "LEFT JOIN sys_book_unit_text x ON x.unit_id=u.unit_id "
        "  AND x.text_variant='ORIGINAL' "
        "WHERE b.record_status='LIVE' "
        "GROUP BY b.book_id HAVING MAX(LENGTH(COALESCE(x.body_text,'')))>? "
        "ORDER BY 5 DESC", (WALL,)).fetchall()
    return rows


def audit(conn):
    """★ 적재된 **전권**을 읽기 대역으로 잰다 — 지침을 데이터에 비춰 본다.

    반환 = [(코드, 제목, 유닛수, 중앙자수, 최대자수, 앵커%, 등급요약)]
    ⚠ 앵커%(구절이 걸린 유닛 비율)를 함께 낸다 — **크기와 앵커는 같은
      사실의 두 얼굴**이고, 둘을 나란히 보아야 「왜 나눠야 하나」가 보인다.
    """
    out = []
    for bid, code, title in conn.execute(
            "SELECT book_id, book_code, title FROM sys_book_asset "
            "WHERE record_status='LIVE' ORDER BY book_code"):
        rows = conn.execute(
            "SELECT LENGTH(COALESCE(x.body_text,'')), "
            "  CASE WHEN u.start_vid>0 THEN 1 ELSE 0 END "
            "FROM sys_book_unit u LEFT JOIN sys_book_unit_text x "
            "  ON x.unit_id=u.unit_id AND x.text_variant='ORIGINAL' "
            "WHERE u.book_id=? AND COALESCE(u.record_status,'LIVE')='LIVE'",
            (bid,)).fetchall()
        rows = [r for r in rows if r[0]]
        if not rows:
            continue
        m = measure([('', 'x' * r[0]) for r in rows])
        anc = 100.0 * sum(r[1] for r in rows) / len(rows)
        out.append((code, title or '', m['n'], m['median'], m['worst'],
                    anc, m))
    return out


def apply(conn, code, units, dry=True, force=False):
    """유닛을 갈아 끼운다.

    ⚠⚠ **읽기 대역 게이트** — 벽(BIG·WALL) 조각이 남아 있으면 **거부**한다.
      §0-1b 의 교훈 그대로다: 지침이 문서에만 있던 동안 두 번 빠졌다.
      그래서 여기서 **코드가 막는다**. `force=True` 는 장르상 정말 그
      크기가 맞을 때만(사람이 판단해 `--force` 로 명시).
    """
    if not force:
        m = measure(units)
        if not m['pass']:
            raise SystemExit(
                '거부: 큰 조각 %d개(BIG %d · WALL %d)가 남았다 — 최대 %d자'
                '(한국어 약 %d분). 안을 더 나누거나, 장르상 맞다면 --force.'
                % (m['big'] + m['wall'], m['big'], m['wall'], m['worst'],
                   read_min(m['worst'])))
    r = conn.execute('SELECT book_id FROM sys_book_asset WHERE book_code=?',
                     (code,)).fetchone()
    if not r:
        raise SystemExit('%s 가 없다' % code)
    bid = r[0]
    # ⚠⚠ **번역이 있는 책은 통째로 갈아 끼우면 그 번역이 사라진다.**
    #   이 함수는 유닛을 지우고 다시 만들므로 `ORIGINAL` 이 아닌 변형
    #   (MODERN_EN·TRANSLATED·SUMMARY)이 딸려 죽는다. 실측 지뢰 —
    #   `KEMPIS_IOC` 는 MODERN_EN 118 + TRANSLATED KO 118 을 갖고 있는데
    #   경계가 미정이라, 아무 생각 없이 쪼개면 **236편이 그 자리에서 없어진다.**
    #   ⇒ 그런 책은 **문제 유닛만 나누는 수술적 분할**이 필요하다(미구현).
    tv = conn.execute(
        "SELECT x.text_variant, COUNT(*) FROM sys_book_unit u "
        "JOIN sys_book_unit_text x ON x.unit_id=u.unit_id "
        "WHERE u.book_id=? AND x.text_variant<>'ORIGINAL' "
        "GROUP BY 1", (bid,)).fetchall()
    if tv and not force:
        raise SystemExit(
            '거부: 이 책에는 번역/현대영어가 있다(%s). 통째로 갈아 끼우면 '
            '**그것이 사라진다.** 문제 유닛만 나누는 수술적 분할이 필요하다.'
            % ' · '.join('%s %d편' % t for t in tv))
    old = conn.execute('SELECT COUNT(*) FROM sys_book_unit WHERE book_id=?',
                       (bid,)).fetchone()[0]
    if dry:
        return old, len(units), 0
    conn.execute('CREATE TABLE IF NOT EXISTS %s (book_code TEXT, unit_id INT,'
                 ' sequence INT, unit_label TEXT, text_variant TEXT,'
                 ' lang_code TEXT, body_text TEXT, saved_at TEXT)' % BACKUP)
    conn.execute(
        'INSERT INTO %s SELECT ?, u.unit_id, u.sequence, u.unit_label, '
        "  x.text_variant, x.lang_code, x.body_text, "
        "  DATETIME('now','localtime') "
        'FROM sys_book_unit u LEFT JOIN sys_book_unit_text x '
        '  ON x.unit_id=u.unit_id WHERE u.book_id=?' % BACKUP, (code, bid))
    ids = [x[0] for x in conn.execute(
        'SELECT unit_id FROM sys_book_unit WHERE book_id=?', (bid,))]
    if ids:
        ph = ','.join('?' * len(ids))
        conn.execute('DELETE FROM sys_book_unit_text WHERE unit_id IN (%s)'
                     % ph, ids)
        conn.execute('DELETE FROM sys_book_unit WHERE book_id=?', (bid,))
    first_new = None
    for i, (title, body) in enumerate(units, 1):
        cur = conn.execute(
            'INSERT INTO sys_book_unit (book_id, sequence, unit_label, '
            "record_status) VALUES (?,?,?,'LIVE')", (bid, i, title))
        if first_new is None or i == 2:
            first_new = cur.lastrowid       # 머리말 다음이 본문 시작
        conn.execute(
            'INSERT INTO sys_book_unit_text (unit_id, text_variant, '
            "lang_code, body_text) VALUES (?,'ORIGINAL','EN',?)",
            (cur.lastrowid, body))
    n_orphan = remap_user_data(conn, ids, first_new)
    conn.commit()
    return old, len(units), n_orphan


def remap_user_data(conn, old_ids, new_first):
    """옛 유닛을 가리키던 **사용자 데이터**를 새 유닛으로 옮긴다.

    ⚠⚠ **유닛 분할은 물리적이다** — 옛 `unit_id` 가 사라지면 그것을 앵커로
      삼던 읽기 위치·읽음 표시·즐겨찾기가 **미아**가 된다(2026-08-28 실측:
      Grace Abounding 본편을 읽던 위치 1건이 실제로 미아가 됐다).
      쪼개기와 같은 트랜잭션에서 옮긴다 — 나중에 찾아 고치려면 무엇이
      어디였는지 이미 알 수 없다.
    ⚠ 옮기는 자리 = **그 책의 본문 첫 유닛**. 옛 유닛 안 어디를 읽고 있었는지는
      알 수 없으므로 그 책의 처음으로 되돌린다(잘못된 자리에 두는 것보다 낫다).
    """
    if not old_ids or not new_first:
        return 0
    ph = ','.join('?' * len(old_ids))
    n = 0
    for tbl, col in (('userdb.user_book_pos', 'unit_id'),
                     ('userdb.user_book_read', 'unit_id'),
                     ('userdb.user_favorite', 'target_id')):
        try:
            if tbl.endswith('user_favorite'):
                cur = conn.execute(
                    "UPDATE %s SET %s=? WHERE fav_type IN ('BOOK_UNIT',"
                    "'SERMON_UNIT') AND %s IN (%s)" % (tbl, col, col, ph),
                    [new_first] + list(old_ids))
            else:
                cur = conn.execute('UPDATE %s SET %s=? WHERE %s IN (%s)'
                                   % (tbl, col, col, ph),
                                   [new_first] + list(old_ids))
            n += cur.rowcount
        except Exception as e:
            print('[remap %s] %s' % (tbl, e))
    return n


# ══════════════════════════════════════════════════════════════════
def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    ch = ('머리 ' + 'h' * 500 + '\n\nCHAPTER I. 처음\n\n' + 'a' * 900 +
          '\n\nCHAPTER II. 다음\n\n' + 'b' * 900)
    u = split_text(ch)
    t('CHAPTER 로 나뉜다 (%d)' % len(u), len(u) == 3, [x[0] for x in u])
    t('   머리말이 산다', u[0][0] == '머리말')
    se = ('SERMON I. 하나\n\n' + 'a' * 900 + '\n\nSERMON II. 둘\n\n' + 'b' * 900)
    t('SERMON 도 규칙이다', len(split_text(se)) == 2)
    caps = ('A GREAT ENCOURAGEMENT.\n\n' + 'a' * 900 +
            '\n\nONE THOUSAND POUNDS.\n\n' + 'b' * 900)
    t('대문자 소제목도 (%d)' % len(split_text(caps)),
      len(split_text(caps)) == 2, [x[0] for x in split_text(caps)])
    t('★ 표지가 없으면 **안 쪼갠다**', split_text('그냥 긴 글 ' + 'x' * 5000)
      == [])
    t('★ 표제만 있는 줄은 앞에 붙는다',
      len(split_text('CHAPTER I. 하나\n\n' + 'a' * 900 +
                     '\n\nCHAPTER II. 둘\n\n짧다')) == 1)
    # 글자 손실 0 — 쪼갠 것을 합치면 원문(표지 포함)이 나온다
    src = ch
    joined = ' '.join(x[1] for x in split_text(src))
    t('★ 글자 손실 없음', all(w in joined for w in ('a' * 50, 'b' * 50,
                                                'h' * 50)))
    t('★ 기관 안내를 걷는다',
      'FULL LICENSE' not in ' '.join(
          x[1] for x in split_text(ch + chr(10) * 2 + 'START: FULL LICENSE'
                                   + chr(10) * 2 + 'z' * 900)))
    # ★ 미아 방지 — 옛 앵커를 가리키던 사용자 데이터가 남지 않는가
    import sqlite3 as _s
    m = _s.connect(':memory:')
    m.execute("ATTACH ':memory:' AS userdb")
    m.execute('CREATE TABLE userdb.user_book_pos(kind TEXT, book_id INT,'
              ' unit_id INT, part_no INT, updated_at TEXT)')
    m.execute('CREATE TABLE userdb.user_book_read(kind TEXT, unit_id INT,'
              ' read_at TEXT, book_id INT)')
    m.execute('CREATE TABLE userdb.user_favorite(fav_type TEXT, target_id INT)')
    m.execute("INSERT INTO userdb.user_book_pos VALUES('BOOK',9,111,0,'')")
    m.execute("INSERT INTO userdb.user_book_read VALUES('BOOK',111,'',9)")
    m.execute("INSERT INTO userdb.user_favorite VALUES('BOOK_UNIT',111)")
    got = remap_user_data(m, [111, 112], 900)
    t('★ 미아 방지 — 옛 앵커 3건이 새 유닛으로', got == 3, got)
    t('   실제로 옮겨졌다',
      m.execute('SELECT unit_id FROM userdb.user_book_pos').fetchone()[0] == 900
      and m.execute('SELECT target_id FROM userdb.user_favorite'
                    ).fetchone()[0] == 900)
    m.close()

    # ══ 읽기 대역 (2026-08-28 신설) ══
    t('등급 — 목표 대역', grade(2000)[0] == 'AIM', grade(2000))
    t('등급 — 벽', grade(40000)[0] == 'BIG', grade(40000))
    t('등급 — 짧음', grade(300)[0] == 'SMALL')
    t('읽기 분 환산 (2000자 → 2.2분)',
      abs(read_min(2000) - 2.2) < 0.05, '%.2f' % read_min(2000))

    # ★ 큰 조각을 안쪽 표지로 나눈다 (스펄전 설교 모양)
    big = ('SERMON I. 큰 설교\n\n' + 'a' * 3000 +
           '\n\nI. 첫째 요점\n\n' + 'b' * 5000 +
           '\n\nII. 둘째 요점\n\n' + 'c' * 5000 +
           '\n\nIII. 셋째 요점\n\n' + 'd' * 5000 +
           '\n\nSERMON II. 다음\n\n' + 'e' * 2000)
    raw = split_text(big, deep=False)
    deep = split_text(big, deep=True)
    t('★ 안쪽 나누기 전 = 벽이 있다 (%d유닛)' % len(raw),
      not measure(raw)['pass'], measure(raw)['worst'])
    t('★ 안쪽 나누기 뒤 = 벽이 없다 (%d유닛)' % len(deep),
      measure(deep)['pass'], measure(deep)['worst'])
    t('   조각 이름에 (n/N) 이 붙는다',
      any('/' in x[0] for x in deep), [x[0] for x in deep[:3]])
    t('   글자 손실 없음',
      all(w * 50 in ' '.join(x[1] for x in deep) for w in 'abcde'))

    # ★ 문단으로만 나뉘는 경우 (안쪽 표지가 없다)
    paras = '\n\n'.join('p' * 800 for _ in range(20))
    fine = subsplit('제목', paras)
    t('★ 표지가 없으면 문단으로 모은다 (%d조각)' % len(fine),
      len(fine) > 1 and measure(fine)['pass'],
      [len(x[1]) for x in fine])
    t('   자르는 자리가 **문단 경계**다 — 문장 중간 안 끊김',
      all(not x[1].startswith('p' * 5) or x[1].count('p') % 800 == 0
          for x in fine))

    # ⚠ 문단조차 없으면 못 나눈다 — 나눈 척하지 않는다
    wall1 = 'z' * 40000
    t('★ 문단이 없으면 **그대로 돌려준다**(원문 재수집 신호)',
      subsplit('벽', wall1) == [('벽', wall1)])
    t('   문단 세기 = 1', len(paragraphs(wall1)) == 1)

    # ★ 홑 줄바꿈이 문단인 경우 (AUGUSTINE·EDERSHEIM 실측 모양)
    single = '\n'.join('q' * 1200 for _ in range(20))
    t('★ 긴 홑 줄바꿈은 **문단으로 읽는다** (%d개)' % len(paragraphs(single)),
      len(paragraphs(single)) == 20)
    t('   그래서 나뉜다',
      measure(subsplit('제목', single))['pass'],
      len(subsplit('제목', single)))
    # ⚠ 짧은 홑 줄바꿈은 줄접기다 — 문단이 아니다
    wrapped = '\n'.join('w' * 70 for _ in range(500))
    t('★ 짧은 홑 줄바꿈은 **줄접기** — 문단 아님',
      len(paragraphs(wrapped)) == 1, len(paragraphs(wrapped)))
    t('   그래서 (문장도 없으면) 안 나눈다',
      len(subsplit('제목', wrapped)) == 1)

    # ══ 문장 층 (2026-08-28 사용자 지시 — 인위적 분할) ══
    t('약어 뒤는 문장 끝이 아니다 (St. Paul)',
      len(sentences('He met St. Paul there. Then he left.')) == 2,
      sentences('He met St. Paul there. Then he left.'))
    t('   성경 약어도 (Rom. 8:1)',
      len(sentences('See Rom. 8:1 today. Next line here.')) == 2)
    t('   이름 머리글자도 (J. Smith)',
      len(sentences('Ask J. Smith now. He knows.')) == 2)
    t('   보통 마침표는 자른다',
      len(sentences('First one. Second one. Third one.')) == 3)

    # ★ 한 문단짜리 벽 — 문장으로 나뉘고 **인위적임을 제목이 말한다**
    one_para = ' '.join('This is sentence number %d and it runs on for a '
                        'little while to make bulk.' % i for i in range(300))
    got = subsplit('긴 문단', one_para)
    t('★ 한 문단 벽이 문장으로 나뉜다 (%d조각)' % len(got),
      len(got) > 1 and measure(got)['pass'],
      [len(x[1]) for x in got[:3]])
    t('   제목이 **인위적임을 말한다**',
      all('이어서' in x[0] for x in got), got[0][0])
    t('   문장 중간이 안 끊긴다',
      all(x[1].rstrip().endswith('.') for x in got))
    t('   글자 손실 없음',
      ' '.join(x[1] for x in got).count('sentence number') == 300)

    # ══ 강제 줄바꿈 펴기 (2026-08-28) ══
    wrapped = ('This is a paragraph that was hard wrapped by the old\n'
               'Gutenberg format at about seventy two characters per\n'
               'line which is a display artefact and not the author.\n'
               '\n'
               'Roses are red,\n'
               'violets are blue.\n')
    got = unwrap(wrapped)
    t('★ 강제 줄바꿈을 편다 (문단이 한 줄)',
      got.split('\n\n')[0].count('\n') == 0, repr(got.split('\n\n')[0][:40]))
    t('★ 시(詩)는 건드리지 않는다',
      'Roses are red,\nviolets are blue.' in got)
    t('   빈 줄(문단 경계)은 남는다', '\n\n' in got)
    t('   글자 손실 없음',
      all(w in got for w in ('Gutenberg', 'artefact', 'violets')))
    t('   이미 펴진 글은 그대로',
      unwrap('One long line already unwrapped.') ==
      'One long line already unwrapped.')

    # ★ 게이트 — 벽이 남으면 apply 가 거부한다
    import sqlite3 as _s2
    g = _s2.connect(':memory:')
    g.execute('CREATE TABLE sys_book_asset(book_id INT, book_code TEXT,'
              ' record_status TEXT)')
    g.execute("INSERT INTO sys_book_asset VALUES(1,'X','LIVE')")
    g.execute('CREATE TABLE sys_book_unit(unit_id INTEGER PRIMARY KEY,'
              ' book_id INT, sequence INT, unit_label TEXT,'
              ' record_status TEXT, start_vid INT)')
    g.execute('CREATE TABLE sys_book_unit_text(unit_id INT, text_variant TEXT,'
              ' lang_code TEXT, body_text TEXT)')
    try:
        apply(g, 'X', [('벽', 'z' * 40000)], dry=True)
        t('★ 게이트 — 벽이면 거부', False, '통과해 버렸다')
    except SystemExit as e:
        t('★ 게이트 — 벽이면 거부', '거부' in str(e), str(e)[:40])
    try:
        apply(g, 'X', [('벽', 'z' * 40000)], dry=True, force=True)
        t('   --force 는 통과한다', True)
    except SystemExit as e:
        t('   --force 는 통과한다', False, e)
    # ★ 번역이 있는 책은 거부한다 (KEMPIS 지뢰)
    g.execute("INSERT INTO sys_book_unit VALUES(7,1,1,'u','LIVE',0)")
    g.execute("INSERT INTO sys_book_unit_text VALUES(7,'TRANSLATED','KO','글')")
    try:
        apply(g, 'X', [('알맞음', 'z' * 2000)], dry=True)
        t('★ 번역이 있으면 거부한다', False, '통과해 버렸다')
    except SystemExit as e:
        t('★ 번역이 있으면 거부한다', '사라진다' in str(e), str(e)[:46])
    g.close()

    # 실DB 훑기
    try:
        conn = appdb.connect()
        rows = scan(conn)
        conn.close()
        t('실DB 후보 훑기 (%d권)' % len(rows), True,
          [r[1] for r in rows[:4]])
    except Exception as e:
        t('실DB 훑기', False, e)
    print('db_book_split selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        raise SystemExit(0 if selftest() else 1)
    if '--wrapscan' in a:
        conn = appdb.connect()
        print('강제 줄바꿈 훑기 (줄당 %d자 미만이면 구텐베르크 형식)' % 120)
        for (code,) in conn.execute(
                "SELECT book_code FROM sys_book_asset WHERE record_status='LIVE'"
                " ORDER BY book_code"):
            n, per = wrap_stat(conn, code)
            if n and per < 120:
                print('  %-20s %4d유닛 · 줄당 %3d자  ← 편다' % (code, n, per))
        conn.close()
        return
    if '--unwrap' in a:
        i = a.index('--unwrap')
        code = a[i + 1]
        conn = appdb.connect()
        n0, per0 = wrap_stat(conn, code)
        tot, ch = unwrap_book(conn, code, dry=('--apply' not in a))
        n1, per1 = wrap_stat(conn, code)
        conn.close()
        print('%s %s — %d편 중 %d편 변경 · 줄당 %d자 → %d자'
              % (code, '적용' if '--apply' in a else '미리보기',
                 tot, ch, per0, per1))
        return
    if '--audit' in a:
        conn = appdb.connect()
        rows = audit(conn)
        conn.close()
        print('읽기 대역 감사 — 목표 %d~%d자(한국어 %.0f~%.0f자 · %.1f~%.1f분)'
              % (AIM_LO, AIM_HI, AIM_LO * KO_RATIO, AIM_HI * KO_RATIO,
                 read_min(AIM_LO), read_min(AIM_HI)))
        print('  %-19s %5s %8s %9s %6s  %s'
              % ('책', '유닛', '중앙', '최대', '앵커', '판정'))
        bad = 0
        for code, _t, n, med, worst, anc, m in sorted(
                rows, key=lambda r: -r[4]):
            mark = 'OK' if m['pass'] else '나눠야 함'
            if not m['pass']:
                bad += 1
            print('  %-19s %5d %6d자 %7d자 %5.0f%%  %-9s %s'
                  % (code, n, med, worst, anc, mark,
                     ('큼%d 벽%d' % (m['big'], m['wall'])) if not m['pass']
                     else ''))
        print('  ─ %d권 중 **%d권**이 읽기 대역을 벗어났다' % (len(rows), bad))
        return
    if '--scan' in a:
        conn = appdb.connect()
        rows = scan(conn)
        conn.close()
        print('한 유닛이 %d자를 넘는 책 (%d권):' % (WALL, len(rows)))
        for bid, code, title, n, mx in rows:
            print('  #%-3s %-16s %-34s 유닛 %4d · 최대 %7d자'
                  % (bid, code, (title or '')[:34], n, mx))
        return
    for mode in ('--check', '--apply'):
        if mode in a:
            i = a.index(mode)
            code, path = a[i + 1], a[i + 2]
            deep = '--raw' not in a
            src = io.open(path, encoding='utf-8', errors='replace').read()
            name, ms = detect_rule(src)
            units = split_text(src, deep=deep)
            print('원문 표지: %s %d개 → %d유닛%s'
                  % (name or '(없음)', len(ms), len(units),
                     '' if deep else '  (--raw · 안쪽 나누기 끔)'))
            for j, (ttl, body) in enumerate(units, 1):
                g, why = grade(len(body))
                print('  %3d %-46s %7d자 %4.1f분 %-5s %s'
                      % (j, ttl[:46], len(body), read_min(len(body)), g,
                         why if g in ('BIG', 'WALL', 'SMALL') else ''))
            if not units:
                print('⚠ 원문에 나눌 표지가 없다 — 그대로 둔다')
                return
            m = measure(units)
            print('  ─ 요약: 알맞음 %d · 허용 %d · **큼 %d · 벽 %d** · 짧음 %d'
                  '  (중앙 %d자 %.1f분 · 최대 %d자 %.1f분)'
                  % (m['aim'], m['ok'], m['big'], m['wall'], m['small'],
                     m['median'], read_min(m['median']),
                     m['worst'], read_min(m['worst'])))
            if not m['pass'] and len(paragraphs(units[-1][1])) <= 1:
                print('  ⚠ 문단(빈 줄)이 없다 — 적재 때 뭉개진 것이다. '
                      '나누지 말고 **원문을 다시 받는다**.')
            conn = appdb.connect()
            old, new, nmap = apply(conn, code, units,
                                   dry=(mode == '--check'),
                                   force=('--force' in a))
            conn.close()
            print('%s 옛 %d유닛 → 새 %d유닛%s'
                  % ('적용:' if mode == '--apply' else '미리보기:', old, new,
                     (' · 사용자 데이터 %d건 이어붙임' % nmap) if nmap else ''))
            return
    print(__doc__)


if __name__ == '__main__':
    main()
