"""
media_list_view.py
------------------
미디어 목록 표준 표시 (사용자 화면 공용).

표준 컬럼: 언어 / 형태 / 제목 / 채널 / ★(즐겨찾기)
links_panel(구절·노드 Links) 과 entity_browser(엔티티 정보 Links) 가
동일한 모양으로 사용한다.

유형(kind) = media_taxonomy.badge = 내용 유형 이름(`content_label`)[·어린이/수화].
  ★ 2026-09-16 19-3 — P2 유형 콤보·어린이 화면 라디오와 **같은 이름**(KV_KIND_*).
채널(channel) = description JSON 의 channel.
즐겨찾기 = user_media_fav(media_id) 토글 (음수 id = sys_ref_asset 등은 미지원).
"""
import json
import sqlite3
import appdb
import tkinter as tk
from tkinter import ttk

import media_taxonomy as tax
import i18n

# ★★★ **✕ 칸 신설** (2026-08-30 사용자 지시 「**묵상노트에 X표가 붙어 있는
#   것처럼** 링크자산 P2 화면에서 x 와 같은 기능을 수행하도록 만들어야 한다」).
#   ★ 묵상노트 카드의 ✕ 와 **같은 문법**이다 — 그 줄에서 한 번 눌러 내린다.
#     ★(즐겨찾기) 칸이 이미 그 방식(칸을 눌러 토글)이라 새 규칙이 아니다.
#   ⚠ 지우는 것이 아니라 **내 화면에서 가리는 것**이다. 배포 자료는 안 건드린다.
# ★★★ **고르기 칸(`pick`)은 맨 왼쪽 · 평소에는 접혀 있다** (2026-08-30 사용자
#   지시 「정말 황당하게 만들었다. 실수하기 좋다. **오른쪽에 배치하니까 보이지도
#   않는다.** "링크 숨기기" 버튼을 만들고 클릭하면 목록의 **가장 왼쪽에 x 체크
#   할 수 있는 칸**이 표시되도록 하라. **기본 세팅은 아무것도 없는 것**이다.
#   원하는 것만 골라서 v 체크하고 **"숨기기 확인" 버튼을 누르면 그때 비로소**
#   실제 조치되도록 하라」).
#   ⚠⚠ 그전 판(오른쪽 끝 ✕ 한 번 클릭)은 **누르는 순간 곧 실행**이라
#     되돌리기가 있어도 실수하기 쉬웠고, 오른쪽 끝이라 눈에도 안 들어왔다.
#   ★ 평소 폭 **0** — 「기본 세팅은 아무것도 없는 것」. [링크 숨기기]를 눌러야
#     폭이 생긴다(`set_pick_col`).
# ★★★ **범위 칸** (2026-08-30 사용자 확정 — 「**창1:1~3, 창1장, 창세기** 등으로
#   구분값 표시」). 묶음 머리(별도 레코드)가 아니라 **줄마다 제 범위**를 말한다.
#   ⚠ 한 절짜리는 **빈 칸** — 그것이 기본이라 적으면 잡음이다.
COLS   = ('pick', 'scope', 'lang', 'kind', 'title', 'channel', 'fav')
_HEAD  = {'pick': '', 'scope': '범위', 'lang': '언어', 'kind': '유형',
          'title': '제목', 'channel': '채널', 'fav': '♪'}
_HEAD_KEY = {'scope': 'LP_C_SCOPE', 'lang': 'MLV_LANG', 'kind': 'MLV_KIND',
             'title': 'MLV_TITLE', 'channel': 'MLV_CHANNEL'}
_WIDTH = {'pick': 0, 'scope': 92, 'lang': 40, 'kind': 96, 'title': 240,
          'channel': 96, 'fav': 26}
PICK_COL = '#1'   # 선택하기 칸 식별자 (identify_column)
FAV_COL  = '#7'   # fav 컬럼 식별자
PICK_ON, PICK_OFF = 'v', ''


def set_pick_col(tv, on):
    """선택하기 칸을 펴고 접는다 — 접으면 폭 0 이라 **없는 것과 같다**."""
    try:
        tv.column('pick', width=(26 if on else 0),
                  minwidth=(26 if on else 0), stretch=False)
        tv.heading('pick', text=('✓' if on else ''))
    except Exception:
        pass


def build_tree(parent, height=10, style_name='MediaList.Treeview'):
    """표준 5컬럼 Treeview 생성 (스크롤바 미포함 — 호출측에서 배치).
    서식은 `theme_font.list_style` 표준 하나를 따른다 (2026-08-18 — 여기의
    9pt/22px 하드코딩이 Links·EBLinks 트리를 표준 밖에 남겨 두고 있었다)."""
    import theme_font as _tf
    _tf.list_style(style_name, None)
    # ⚠ **묶음(별도 레코드) 방식을 걷었다** (2026-08-30 사용자 비교 요청 뒤
    #   확정) — 묶음 머리는 **#0 에 190px** 를 늘 먹고 줄도 하나씩 더 쓴다.
    #   범위 칸은 **92px** 이고 **줄마다 제 범위**를 말한다. 좁은 P2 에서
    #   그 차이가 크다.
    tv = ttk.Treeview(parent, columns=COLS, show='headings',
                      selectmode='browse', height=height, style=style_name)
    for c in COLS:
        tv.heading(c, text=(i18n.t(_HEAD_KEY[c], _HEAD[c]) if c in _HEAD_KEY else _HEAD[c]))
        tv.column(c, width=_WIDTH[c],
                  anchor=('center' if c in ('pick', 'lang', 'fav') else 'w'),
                  stretch=(c == 'title'),
                  minwidth=(120 if c == 'title' else (0 if c == 'pick' else 24)))
    tv.tag_configure('row', background='white')
    tv.tag_configure('fav', background='#FEF9E7', foreground='#C0392B')
    # 가린 줄 — 흐리게(「가린 것도 보기」가 켜졌을 때만 뜬다)
    try:
        import ui_theme
        tv.tag_configure('hidden', foreground=ui_theme.C('fg_dim') or '#95A5A6')
    except Exception:
        tv.tag_configure('hidden', foreground='#95A5A6')
    return tv


def channel_of(description):
    """description JSON 에서 채널명 추출 (없으면 '')."""
    if not description:
        return ''
    try:
        return json.loads(description).get('channel', '') or ''
    except Exception:
        return ''


def kind_label(media_type, format_type, audience='GENERAL'):
    content = tax.normalize_content(media_type)
    fmt = tax.normalize_format(media_type, format_type)
    return tax.badge(content, fmt, audience)


def fav_mark(is_fav):
    # ★ 2026-10-11 — 영상의 즐겨듣기 하나로 · 폰과 같은 표(listen)
    # ★ 2026-10-24 docs/4.txt — 기호 하나에 뜻 하나: 즐겨듣기 = ♪(♥ 는 찜 · ★ 는 즐겨찾기 · 채널은 글자)
    return '♪' if is_fav else '·'


def row_values(lang, media_type, format_type, title, channel,
               is_fav, audience='GENERAL', hidden=False):
    """표준 컬럼 값 튜플 (lang, kind, title, channel, fav, ✕) + 태그.

    `hidden` — 「가린 것도 보기」가 켜져 있을 때만 참이 온다. 그때는 ✕ 대신
      **되살리기(↺)** 를 보이고 줄을 흐리게 그린다.
    ⚠ 칸을 늘렸다 — **다섯 칸으로 언패킹하던 곳이 있으면 터진다**(§all_tags
      5→6 사고). 실측 호출부는 `links_panel`·`entity_browser` 둘이다."""
    vals = (PICK_OFF, '', lang or '',
            kind_label(media_type, format_type, audience),
            title or '', channel or '', fav_mark(is_fav))
    tags = ('hidden',) if hidden else (('fav',) if is_fav else ('row',))
    return vals, tags


def toggle_fav(db_path, media_id):
    """user_media_fav 토글. 반환 (새 상태 bool, mark, tag). 음수/None 은 무시."""
    if media_id is None or media_id < 0:
        return None
    try:
        import listen
        with appdb.connect(db_path) as conn:
            on = listen.toggle_media(conn, media_id)
            if on is None:
                return None
            return (True, '♪', 'fav') if on else (False, '·', 'row')
    except Exception as e:
        print(f'[media_list_view] toggle_fav: {e}')
        return None
