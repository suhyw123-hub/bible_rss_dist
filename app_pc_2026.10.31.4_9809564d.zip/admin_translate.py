# -*- coding: utf-8 -*-
"""admin_translate.py — 관리자 검토용 자동번역 (영구, 2026-09-08).

사용자 지시(2026-09-08): 「구글 번역기를 사용하자. 막히면 그때 가서 방법을
찾아보자. 수집한 유투브 제목/설명문이 한국어 이외에는 모두 한국어로 번역,
저장해서 표시하라. **철저히 관리자 1인용이다.**」

★★★ **「관리자 1인용」이 저장 자리를 정했다** — 번역본을 `bible_master.db`
  (`sys_media_asset.description`)에 넣지 않는다. **`admin_xl_cache.db` 에만**
  둔다. 그러면
    ⓐ 배포물에 한 글자도 안 닿는다(§194차 — 유튜브 설명문은 팩에서 뺐다)
    ⓑ `db_media_range.purge_desc` 가 원문을 지울 때 **번역본을 따로
       챙길 필요가 없다** — 애초에 다른 파일이다
    ⓒ 캐시가 곧 저장이라 **같은 글을 두 번 안 부른다**
  ⚠ 그 파일은 관리자 PC 에만 있다(`cloud_translate` 가 쓰던 그것).

★★ **통로를 넷 두고 자동 절체한다** — 공지 동기화가 jsDelivr(주)/raw(백업)로
  하는 그 패턴 그대로. 실측(2026-09-08):
    translate.googleapis.com / gtx            0.97초
    clients5.google.com / dict-chrome-ex      0.41초
    clients5.google.com / gtx                 0.41초
    translate.google.com / gtx                0.57초
  ⚠⚠ **빈 UA 는 언제나 429 다**(실측) — UA 를 반드시 넣는다.
  ⚠ 429 는 「죽음」이 아니라 **일시적 rate limit** 이다. 몰아치면 걸리고
    잠시 뒤 풀린다(실측 — 연속 45회는 통과, 앞서 6회 몰아쳤을 때는 걸렸다).
  ⚠ **한 통로가 막히는 것은 사고가 아니라 정상**이라 넷을 둔다.
  ⚠ 비공식 통로다 — `cloud_translate` 가 「공식 v2 사용(비공식 gtx 아님)」이라
    못 박은 것은 **배포물(사용자 화면 제목)** 이야기다. 여기는 관리자가
    자기 화면에서 판단하려고 보는 보조 표시라 자리가 다르다.

⚠ **한국어는 번역하지 않는다** — 실측 미검토 8,781건 중 KO 가 2,991건(34%)이다.

사용:  python admin_translate.py --selftest | --try "글" | --stat
"""
import hashlib
import io
import json
import os
import sys
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

#: ⚠⚠ **빈 UA 는 언제나 429** — 실측(2026-09-08). 반드시 넣는다.
_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) BibleMatrixAdmin/1.0'
_TIMEOUT = 15

#: ★★ **통로 — 차례대로 쓰고 막히면 다음으로.** (이름, 호스트, client)
#: ⚠ 늘리거나 순서를 바꿀 때 **여기 한 줄**이다. 화면에 적으면 갈린다.
ROUTES = (
    ('gapis/gtx',      'translate.googleapis.com', 'gtx'),
    ('clients5/chrome', 'clients5.google.com',      'dict-chrome-ex'),
    ('clients5/gtx',   'clients5.google.com',      'gtx'),
    ('gtranslate/gtx', 'translate.google.com',     'gtx'),
)

#: 우리 언어 코드 → 구글 ISO
_ISO = {'ZH': 'zh-CN', 'ZHT': 'zh-TW', 'KO': 'ko', 'EN': 'en', 'JA': 'ja',
        'DE': 'de', 'FR': 'fr', 'ES': 'es', 'AR': 'ar', 'RU': 'ru', 'PT': 'pt'}

#: 한 번에 보낼 최대 자수 — 실측 5,691자까지 100% 소비됐지만 여유를 둔다.
#: ⚠ 넘으면 **자르지 않고 문단 경계에서 나눠 여러 번** 부른다(아래 `_chunks`).
MAX_CHARS = 3000

_CACHE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           'admin_xl_cache.db')

#: 마지막 실패 사유 — 화면이 「왜 안 됐나」를 말할 수 있게(§0-1).
last_error = ''


def iso(code):
    c = (code or '').upper()
    return _ISO.get(c, (c or 'en').lower())


def _h(text):
    """캐시 열쇠 — `cloud_translate._h` 와 **같은 규칙**(두 벌 금지)."""
    return hashlib.sha1((text or '').encode('utf-8')).hexdigest()


def _cache_conn():
    import sqlite3
    c = sqlite3.connect(_CACHE_PATH)
    c.execute("CREATE TABLE IF NOT EXISTS xl (h TEXT NOT NULL, lang TEXT NOT NULL,"
              " dst TEXT, PRIMARY KEY(h, lang))")
    return c


def cache_get(text, lang, conn=None):
    own = conn is None
    c = conn or _cache_conn()
    try:
        r = c.execute("SELECT dst FROM xl WHERE h=? AND lang=?",
                      (_h(text), (lang or '').upper())).fetchone()
        return r[0] if r else None
    finally:
        if own:
            c.close()


def cache_put(text, lang, dst, conn=None):
    own = conn is None
    c = conn or _cache_conn()
    try:
        c.execute("INSERT OR REPLACE INTO xl(h,lang,dst) VALUES(?,?,?)",
                  (_h(text), (lang or '').upper(), dst))
        c.commit()
    finally:
        if own:
            c.close()


# ── 통로 ─────────────────────────────────────────────────────────────
def _call(route, text, tl, sl='auto'):
    """한 통로로 한 번 부른다 → 번역문. 실패하면 예외."""
    _nm, host, client = route
    q = urlencode({'client': client, 'sl': sl, 'tl': tl, 'dt': 't', 'q': text})
    req = Request('https://%s/translate_a/single?%s' % (host, q),
                  headers={'User-Agent': _UA})
    with urlopen(req, timeout=_TIMEOUT) as r:
        d = json.loads(r.read().decode('utf-8'))
    if not d or not d[0]:
        raise ValueError('EMPTY')
    return ''.join(s[0] for s in d[0] if s and s[0])


def _chunks(text, limit=MAX_CHARS):
    """긴 글을 **문장·문단 경계에서** 나눈다.

    ⚠ **글자 수로 자르지 않는다** — 문장 한가운데가 갈리면 번역이 망가진다.
    """
    text = text or ''
    if not text.strip():
        return []
    if len(text) <= limit:
        return [text]
    out, buf = [], ''
    for part in text.split('\n'):
        part = part + '\n'
        while len(part) > limit:
            # 한 줄이 너무 길면 마침표 뒤에서 끊는다
            cut = max(part.rfind('. ', 0, limit), part.rfind('。', 0, limit),
                      part.rfind('! ', 0, limit), part.rfind('? ', 0, limit))
            if cut <= 0:
                cut = limit
            else:
                cut += 1
            if buf:
                out.append(buf)
                buf = ''
            out.append(part[:cut])
            part = part[cut:]
        if len(buf) + len(part) > limit:
            out.append(buf)
            buf = part
        else:
            buf += part
    if buf.strip():
        out.append(buf)
    return [x for x in out if x.strip()]


def translate(text, target='KO', src=None, use_cache=True, routes=None,
              conn=None, pause=0.25):
    """번역 → 글. **못 하면 `None` 을 돌려주고 까닭을 `last_error` 에 적는다.**

    ⚠ **조용히 실패하지 않는다**(§0-1) — 부른 쪽이 「지금 번역할 수 없습니다」를
      말할 수 있어야 한다. 빈 글자를 돌려주면 「번역했는데 비었다」로 읽힌다.
    ⚠ **원문을 안 건드린다** — 이것은 곁들임이다.
    """
    global last_error
    last_error = ''
    text = (text or '').strip()
    if not text:
        return ''
    tl = (target or 'KO').upper()
    if use_cache:
        hit = cache_get(text, tl, conn)
        if hit is not None:
            return hit
    tl_iso = iso(tl)
    sl_iso = iso(src) if src else 'auto'
    parts = _chunks(text)
    got, errs = [], []
    for i, part in enumerate(parts):
        one = None
        # ⚠⚠ **`routes or ROUTES` 로 쓰면 안 된다** — 빈 튜플이 falsy 라
        #   「통로를 하나도 쓰지 마라」가 **기본 통로 전부**로 뒤집힌다
        #   (selftest 가 그 자리에서 잡았다).
        for route in (ROUTES if routes is None else routes):
            try:
                one = _call(route, part, tl_iso, sl_iso)
                break
            except HTTPError as e:
                errs.append('%s %d' % (route[0], e.code))
            except (URLError, OSError) as e:
                errs.append('%s %s' % (route[0], type(e).__name__))
            except Exception as e:
                errs.append('%s %s' % (route[0], type(e).__name__))
        if one is None:
            # ⚠ 한 조각이라도 실패하면 **반쪽 번역을 돌려주지 않는다**.
            last_error = ' · '.join(errs[:4]) or 'UNKNOWN'
            return None
        got.append(one)
        if pause and i + 1 < len(parts):
            time.sleep(pause)     # ⚠ 몰아치면 429 — 조각 사이에 쉰다
    out = '\n'.join(got).strip()
    if use_cache and out:
        try:
            cache_put(text, tl, out, conn)
        except Exception:
            pass
    return out


def need_translate(lang_code, target='KO'):
    """번역이 필요한가 — **같은 언어면 안 한다**.

    ⚠ 실측 미검토 8,781건 중 KO 가 2,991건(34%)이라 이 한 줄이 3분의 1을 던다.
    """
    return (lang_code or '').upper() != (target or 'KO').upper()


def translate_media(title, desc, lang_code, target='KO', conn=None):
    """제목·설명문을 한 번에 → `(제목역, 설명역, 사유)`.

    · 필요 없으면 `(None, None, 'SAME_LANG')`
    · 못 하면 `(None, None, 사유)` — 화면이 그 까닭을 그대로 보인다
    ★ **캐시 연결을 물려받는다** — 두 번 열지 않는다.
    """
    if not need_translate(lang_code, target):
        return None, None, 'SAME_LANG'
    own = conn is None
    c = conn or _cache_conn()
    try:
        # ⚠⚠ **출발 언어를 강제하지 않는다(`src=None` = auto)** — 수집기가
        #   다는 `lang_code` 는 **짐작**이다(§203차 — 번체 제목이 ZH 로 들어온다).
        #   실측(2026-09-08): `lang_code='AR'` 인데 본문이 스페인어인 줄에서
        #     sl=AR   → 'Predica "Jesucristo la esperanza viva"…'  ← 번역 안 됨
        #     sl=auto → '"산 소망이신 예수 그리스도"를 전파하십시오…'  ← 됨
        #   ⇒ **「무슨 언어인가」는 번역기가 더 잘 안다.**
        #   ★ 다만 `need_translate` 판정에는 `lang_code` 를 그대로 쓴다 —
        #     그것이 틀려도 손해가 「한국어를 한 번 더 번역」뿐이라 싸다.
        t = translate(title, target, None, conn=c) if (title or '').strip() else ''
        if t is None:
            return None, None, last_error
        d = translate(desc, target, None, conn=c) if (desc or '').strip() else ''
        if d is None:
            return t, None, last_error
        return t, d, ''
    finally:
        if own:
            c.close()


def stat():
    """캐시 현황 — 「이미 몇 개를 번역해 두었나」."""
    c = _cache_conn()
    try:
        n = c.execute("SELECT COUNT(*) FROM xl").fetchone()[0]
        by = c.execute("SELECT lang, COUNT(*) FROM xl GROUP BY 1 "
                       "ORDER BY 2 DESC").fetchall()
        return n, by, (os.path.getsize(_CACHE_PATH) if os.path.exists(_CACHE_PATH) else 0)
    finally:
        c.close()


# ── 자가 검증 ────────────────────────────────────────────────────────
def selftest(net=True):
    """⚠ **실 캐시를 안 건드린다** — 임시 파일로 잰다(§0-5)."""
    global _CACHE_PATH
    import tempfile
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    real = _CACHE_PATH
    d = tempfile.mkdtemp(prefix='xl_st_')
    _CACHE_PATH = os.path.join(d, 'xl.db')
    try:
        # ── 순수 함수 ────────────────────────────────────────────
        t('★ 같은 언어면 번역 안 한다', not need_translate('KO'))
        t('  다른 언어면 한다', need_translate('AR') and need_translate('en'))
        t('  대소문자 무관', not need_translate('ko'))
        t('  ISO 매핑', iso('ZH') == 'zh-CN' and iso('ZHT') == 'zh-TW'
          and iso('KO') == 'ko', (iso('ZH'), iso('ZHT')))

        # ── 조각내기 — **글자를 잃지 않는다** ────────────────────
        long = ('첫째 문장입니다. 둘째 문장입니다.\n' * 400)
        cs = _chunks(long)
        t('★ 긴 글을 나눈다', len(cs) > 1, len(cs))
        t('★★ 나눠도 글자를 안 잃는다',
          ''.join(cs).replace('\n', '') == long.replace('\n', ''),
          (len(''.join(cs)), len(long)))
        t('  조각이 상한을 안 넘는다', all(len(x) <= MAX_CHARS for x in cs),
          max(len(x) for x in cs))
        t('  짧은 글은 안 나눈다', _chunks('짧다') == ['짧다'])
        t('  빈 글은 조각 0', _chunks('') == [] and _chunks('   ') == [])
        # ⚠ 마침표가 없는 아주 긴 한 줄도 잘려야 한다(무한 반복 금지)
        one = 'あ' * (MAX_CHARS * 3)
        c2 = _chunks(one)
        t('★ 마침표 없는 긴 줄도 나뉜다',
          len(c2) >= 3 and all(len(x) <= MAX_CHARS for x in c2), len(c2))
        t('  그때도 글자를 안 잃는다',
          ''.join(c2).replace('\n', '') == one)

        # ── 캐시 ─────────────────────────────────────────────────
        cache_put('hello', 'KO', '안녕')
        t('★ 캐시에 담고 꺼낸다', cache_get('hello', 'KO') == '안녕')
        t('  없는 것은 None', cache_get('nope', 'KO') is None)
        t('  언어가 다르면 다른 칸', cache_get('hello', 'EN') is None)
        t('★ 캐시를 타면 통로를 안 부른다',
          translate('hello', 'KO', routes=()) == '안녕')

        # ── 통로가 다 막혔을 때 ──────────────────────────────────
        r = translate('never-cached-text-xyz', 'KO', routes=())
        t('★★ 다 막히면 None 을 돌려준다(빈 글자 아님)', r is None, repr(r))
        t('  까닭을 남긴다', bool(last_error), last_error[:40])

        # ── 절체 — 앞이 죽고 뒤가 살면 뒤로 간다 ─────────────────
        bad = ('죽은통로', 'no-such-host.invalid', 'gtx')
        if net:
            v = translate('God is love', 'KO', src='EN',
                          routes=(bad,) + ROUTES, use_cache=False)
            t('★★ 앞 통로가 죽으면 다음으로 넘어간다',
              bool(v) and '사랑' in v, repr(v))
        else:
            t('  (절체는 네트워크 시험이라 건너뜀)', True)

        # ── 실제 번역 ────────────────────────────────────────────
        if net:
            v = translate('Grace and peace to you', 'KO', src='EN', use_cache=False)
            t('★ 영어를 한국어로', bool(v) and v != 'Grace and peace to you', repr(v))
            a = translate('ترنيمة عن محبة الله', 'KO', src='AR', use_cache=False)
            t('  아랍어도', bool(a), repr(a))
            tt, dd, why = translate_media('Bible study', 'A short description',
                                          'EN')
            t('★ 제목·설명을 한 번에', bool(tt) and bool(dd) and not why,
              (repr(tt)[:20], why))
            tt2, dd2, why2 = translate_media('제목', '설명', 'KO')
            t('★★ 한국어는 건드리지 않는다',
              tt2 is None and dd2 is None and why2 == 'SAME_LANG')
        else:
            t('  (실제 번역은 네트워크 시험이라 건너뜀)', True)

        # ── 안 건드리는 것 ───────────────────────────────────────
        src = io.open(os.path.abspath(__file__), encoding='utf-8').read()
        # ⚠⚠ **찾는 글자를 검사 코드에 그대로 적으면 자기가 걸린다**(§199차).
        _ins = 'UP' + 'DATE '
        _upd = 'UP' + 'DATE '
        _del = 'DEL' + 'ETE '
        # ⚠ **표 이름으로 재면 안 된다** — 이 파일의 문서가 「거기에 넣지
        #   않는다」고 그 이름을 적고 있어 검사가 제 글에 걸린다(§199차).
        #   ⇒ **쓰는 문이 있는가**로만 잰다.
        t('★★ 배포 DB 에 한 글자도 안 쓴다',
          all(x not in src.upper() for x in (_ins, _upd, _del))
          or src.upper().count(_ins) == src.count('INSERT OR REPLACE INTO xl'),
          (src.upper().count(_ins), src.upper().count(_upd)))
        t('  통로 목록이 단일 소스', len(ROUTES) == 4
          and len({r[0] for r in ROUTES}) == 4)
        t('★ UA 를 반드시 넣는다(빈 UA 는 429)', bool(_UA) and 'User-Agent' in src)
    finally:
        _CACHE_PATH = real
        for f in os.listdir(d):
            try:
                os.remove(os.path.join(d, f))
            except OSError:
                pass
        try:
            os.rmdir(d)
        except OSError:
            pass
    t('  시험 파일 잔재 0', not os.path.exists(d))
    print('admin_translate selftest: %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv
    if '--selftest' in a:
        sys.exit(0 if selftest(net='--nonet' not in a) else 1)
    if '--stat' in a:
        n, by, sz = stat()
        print('■ 번역 캐시 %s건 · %.1fMB' % (format(n, ','), sz / 1e6))
        for lg, k in by[:12]:
            print('   %-5s %s' % (lg, format(k, ',')))
        sys.exit(0)
    if '--try' in a:
        txt = a[a.index('--try') + 1]
        v = translate(txt, 'KO')
        print(v if v is not None else '✕ %s' % last_error)
        sys.exit(0 if v is not None else 1)
    print(__doc__.strip().split('\n')[0])
    print('사용:  --selftest | --stat | --try "글"')
