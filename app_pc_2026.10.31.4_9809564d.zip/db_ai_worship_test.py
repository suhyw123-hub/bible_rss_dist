# -*- coding: utf-8 -*-
"""찬양 AI 판정 시험 — **규칙 추천과 나란히 두고 견준다** (2026-09-30 신설).

사용자 확정 「**두가지를 유지해서 그 결과를 비교하고 난 이후에 정리하자.
아직 판단하기 애매하다**」 — 그래서 이 도구는 **아무것도 걷지 않는다.**
규칙이 낸 연결(`media_text_linker`·`db_song_match`)은 그대로 두고, AI 답을
**로컬 표에만** 담아 나중에 대조한다.

★★★ **배포 표를 한 줄도 안 건드린다** — `sys_media_asset`·`sys_link_asset` 은
  읽기만 한다(selftest 가 그 불변식을 잰다). 담는 곳은 `temp_ai_worship_*` 셋.

★★★ **설명문은 전문을 쓴다.** 실측 찬양 설명문 10,451편 중 **51.2%가 잘려
  있다**(`search.list` 의 snippet 은 유튜브가 잘라서 준다 · 중앙 125자).
  `videos.list(part=snippet)` 이 전문을 주고 **50개당 1 unit** 이라 값이 0에
  가깝다. ⚠ 그래도 **`sys_media_asset.description` 에 쓰지 않는다** — 비교가
  끝나기 전에는 원본을 그대로 둔다(사용자 「두 가지를 유지」).

★★★ **용어 목록을 프롬프트에 싣지 않는다** — 실측(302차):
  | | 자유응답 | 용어 목록 191종 제시 |
  |---|---|---|
  | 24073 | 곡·팀·**시 121:1** | 구절 0 · 용어 **「예루살렘」**(사람이 반려한 그 오답) |
  | 토큰 | 674~1,148 | 1,178~1,652 |
  목록을 주면 목록 낱말을 맞추려고 글이 휜다(§195차 「엘」 사건 그 자리).
  ⇒ **분야 힌트만** 주고 낱말은 자유롭게 받은 뒤 **우리 코드가 맞춘다**.

⚠ 외부 사이트에 목록을 두는 길은 재서 버렸다 — `URL context` 는 「Charged as
  input tokens per model pricing」이고 읽어 온 토큰이 **포함**된다(HTML 이라
  오히려 는다). Search Grounding 은 $14/1,000 요청.

표본 갈래 — **규칙이 무엇을 잘하고 무엇을 못하나**를 갈라 보려고 나눈다.
  A  용어 `DESC:` 근거가 걸린 편   (규칙 생존 **0.2%** — AI 는 무엇을 내나)
  B  용어 `TITLE:` 근거가 걸린 편  (규칙 생존 **99.4%** — AI 가 재현하나)
  C  구절 연결이 걸린 편           (겹치나)
  D  **아무 연결도 없는 편**       (AI 가 새로 찾나 ← 값이 가장 크다)
  E  사람이 HIDE 한 연결이 있는 편 (AI 가 같은 오답을 피하나)
  F  **설명문이 거의 없는 편**       (제목 전용 프롬프트를 재는 자리 — 2026-09-30)

명령
  --selftest              자가검증(의무)
  --plan                  표본 계획만 — 한 바이트도 안 보낸다
  --fulldesc [N]          설명문 전문 받기(videos.list · 50개당 1 unit)
  --run N [--model M]     AI 에 N편 보낸다(멱등 — 받은 것은 건너뛴다)
  --report                규칙 ↔ AI 대조
  --undo                  시험 표 비우기
"""
import io
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request

import appdb

#: 시험 표 넷 — 전부 로컬(배포 분류표에 안 넣는다).
T_RUN = 'temp_ai_worship_test'
T_ITEM = 'temp_ai_worship_item'
T_DESC = 'temp_ai_worship_desc'
T_CHAN = 'temp_ai_worship_chan'

MODEL_DEFAULT = 'gemini-3.1-flash-lite'

#: 출력 예산 — **생각 토큰이 여기 함께 든다.** 상위 flash 는 생각에 2,000 토큰을
#: 쓰고도 답을 써야 하므로 라이트와 같은 값을 주면 **JSON 이 중간에서 끊긴다**
#: (실측 3.5-flash 가 `"title": "Psalm 46",` 에서 잘렸다).
MAXOUT_OF = {'gemini-3.5-flash': 9000, 'gemini-3.6-flash': 9000,
             'gemini-3.7-flash': 9000, 'gemini-3.8-flash': 9000,
             'gemini-pro-latest': 12000, 'gemini-flash-latest': 9000}
#: ⚠⚠ **2판은 수록곡을 `tracks` 에 다 담으므로 출력이 훨씬 커진다** — 실측
#:   105곡 모음집에서 2,267 토큰(1판은 615)이라 옛 예산 2,400 에 닿았다.
#:   모자라면 **JSON 이 중간에서 끊겨** 그 편이 통째로 헛것이 된다.
MAXOUT_DEFAULT = 5000


def maxout_of(model):
    """그 모델에 줄 출력 예산 — 생각하는 모델은 넉넉히."""
    return MAXOUT_OF.get((model or '').strip(), MAXOUT_DEFAULT)
ENDPOINT = ('https://generativelanguage.googleapis.com/v1beta/models/'
            '%s:generateContent')

#: 갈래마다 몇 편 — 합계가 한 번에 돌릴 만한 크기여야 한다.
GROUPS = (('A', 25), ('B', 25), ('C', 25), ('D', 25), ('E', 20), ('F', 20))

#: 용어 분야 힌트 — **목록이 아니라 갈래다**(낱말은 자유롭게 받는다).
FIELDS = (
    '하나님의 성품(인자·헤세드·거룩·영광·전능·신실) / '
    '구원(은혜·믿음·칭의·속죄·보혈·십자가·부활) / '
    '예배(찬양·경배·감사·제사) / '
    '기도(간구·중보·부르짖음·응답) / '
    '사람의 형편(갈급함·연약함·고난·눈물·회개·죄·방황) / '
    '성령(임재·기름부음·인도·충만) / '
    '마지막 때(재림·천국·영생·새예루살렘) / '
    '언약과 이스라엘(약속·선택·출애굽·성전) / '
    '사랑과 삶(이웃·섬김·순종·헌신·소망·평안)'
)

PROMPT = '''너는 기독교 찬양 영상을 성경 자료와 잇는 조수다.
아래 [제목]과 [설명문]만 보고 판단한다. 영상은 보지 않았다.

[규칙]
- 확실하지 않으면 그 칸을 비운다. 지어내지 않는다.
- 설명문에 가사가 있으면 가사를 근거로 삼는다. 없으면 제목·곡명·채널로만
  판단하고 confidence 를 낮춘다.
- 항목마다 why 를 한 문장으로 적는다 — 무엇을 보고 그렇게 판단했는지.
- 성경 구절은 개역한글 약명 + 장:절(보기: 시 121:1). 가사가 실제로 그 구절을
  노래할 때만 적는다.
- 용어는 아래 분야에서 찾되 낱말은 자유롭게 적는다(목록에 묶이지 않는다).
  분야: {fields}
- JSON 만 낸다. 다른 말을 붙이지 않는다.

{{"kind":"SINGLE|MEDLEY|PLAYLIST|INSTRUMENTAL|SERMON|OTHER",
 "lyrics_in_desc":true,
 "songs":[{{"title":"곡 제목(원어 그대로)","lang":"KO|EN|ZH|JA","confidence":"HIGH|MED|LOW","why":""}}],
 "artists":[{{"name":"부르는 팀/사역자","role":"TEAM|SOLO|CHOIR|CHANNEL","confidence":"","why":""}}],
 "verses":[{{"ref":"시 121:1","confidence":"","why":""}}],
 "terms":[{{"word":"은혜","field":"구원","confidence":"","why":""}}]}}

[제목] {title}
[채널] {chan}
[설명문]
{desc}'''

# ══ 프롬프트 2판 — 실측한 오답 유형을 한 줄씩 막는다 ═══════════════════════
#
# 사용자 지시(2026-09-30) 「AI 가 제대로 판단하지 못한 영역·유형을 분류하라.
#   필요하면 **제목 프롬프트를 따로 만들어 특화**하라. 제목에는 주로 곡이름/
#   찬양팀 정보가 있고 용어/구절 연결 힌트는 없을 것이다」.
#
# ★★★ **1판을 120편 돌려 가른 오답 다섯**:
#   | 유형 | 무엇 | 실측 |
#   |---|---|---|
#   | **E1 갈래 밖 산출** | SERMON 이라 보고도 구절 90·용어 57 · INSTRUMENTAL 이 용어 53 | 갈래를 정해 놓고 그 갈래에 없을 것을 낸다 |
#   | **E2 남의 것** | 설교 설명문의 예배 찬양 목록(「보혈을 지나」) · 배경음악 크레딧(「Fanfare for Space」) | 「이 영상이 부르는 것」과 「설명문에 적힌 것」을 안 가른다 |
#   | **E3 분위기 추측** | INSTRUMENTAL 용어 중 우리 명단 밖 **68%** | 가사가 없는데 낱말을 만든다 |
#   | **E4 채널 복사** | 찬양팀 128건 중 채널명 그대로 **79건(62%)** | 채널이 찬양팀인지 안 묻는다 |
#   | E5 우리 명단 밖 | 낱말 52%(평안·찬양·임재) | **우리 쪽 공백** — AI 흠이 아니다 |
#   ✅ 잘하는 것 — 구절 약명 형식 **못 푼 것 0건** · 가사 판정 54/54 · 제목에서 곡 뽑기
#
# ★★★ **그래서 둘로 가른다** — 재료의 성질이 다르다.
#   · 설명문이 짧으면 = 제목뿐 ⇒ **구절·용어 칸을 아예 안 준다**(없으면 못 만든다)
#   · 설명문이 길면 = 가사·구절 인용이 있을 수 있다 ⇒ 갈래마다 낼 것을 못 박는다

PROMPT_TITLE = '''너는 기독교 찬양 영상을 정리하는 조수다.

이 영상은 **설명문이 거의 없다.** [제목]과 [채널]만 보고 판단한다.

[규칙]
- **제목에서 알 수 있는 것만 적는다.** 곡 이름과 부르는 팀이다.
- **구절과 주제는 묻지 않는다** — 제목만으로는 알 수 없고, 짐작해서 적으면
  틀린 연결이 된다. 아래 JSON 에 그 칸이 아예 없다.
- 곡 이름은 **꾸밈말을 뗀 이름만**. 보기:
    `Rest For My Soul - Calming Christian Instrumental` → `Rest For My Soul`
    `주 은혜임을 ㅣ1시간 연속듣기ㅣ가사포함` → `주 은혜임을`
    `【中英字幕】神掌權 | 女聲降B調 | 小羊詩歌` → `神掌權`
  ⚠ 채널 이름·조성·자막 안내·재생시간은 곡 이름이 아니다.
- 제목에 곡 이름이 없으면 songs 를 **빈 배열**로 둔다(지어내지 않는다).
- artists — **채널 이름을 그대로 베끼지 않는다.** 그 채널이 찬양팀·찬양사역자
  인지 판단해서 role 을 고르고, 모아 올리는 채널·연주 채널이면 `CHANNEL`.
- JSON 만 낸다.

{{"kind":"SINGLE|MEDLEY|PLAYLIST|INSTRUMENTAL|SERMON|OTHER",
 "songs":[{{"title":"","lang":"KO|EN|ZH|JA","confidence":"HIGH|MED|LOW","why":""}}],
 "artists":[{{"name":"","role":"TEAM|SOLO|CHOIR|CHANNEL","confidence":"","why":""}}]}}

[제목] {title}
[채널] {chan}
[설명문] {desc}'''

PROMPT_V2 = '''너는 기독교 찬양 영상을 성경 자료와 잇는 조수다.
아래 [제목]과 [설명문]만 보고 판단한다. 영상은 보지 않았다.

[규칙 — 갈래를 먼저 정하고, 그 갈래에 있는 것만 적는다]
- kind 를 먼저 정한다.
  · `SINGLE` 한 곡  · `MEDLEY` 이어 부르기  · `PLAYLIST` 여러 곡 모음
  · `INSTRUMENTAL` 연주·반주(노래 없음)  · `SERMON` 설교·강해·성경 낭독
  · `OTHER` 그 밖
- **SERMON 이면** songs·terms 를 **빈 배열**로 둔다. 설교가 다룬 본문은
  verses 가 아니라 `sermon_refs` 에 적는다(찬양 연결이 아니다).
- **INSTRUMENTAL 이면** terms 를 **빈 배열**로 둔다 — 노래하는 말이 없으므로
  주제를 알 수 없다. 분위기(잔잔함·평안함)를 주제로 적지 않는다.
- **PLAYLIST 이면** 수록곡을 songs 가 아니라 `tracks` 에 적는다. songs 는
  빈 배열로 둔다(모음집은 한 곡의 판이 아니다).

[규칙 — 이 영상이 부르는 것만 songs 에 적는다]
- 설명문에는 **이 영상과 무관한 곡 이름**이 흔히 섞여 있다: 예배 순서에 부른
  다른 찬양 · 배경음악 크레딧 · 다른 영상 추천 · 앨범의 다른 수록곡.
  그런 것은 `other_songs` 에 적는다. **버리지 말고 가른다.**

[규칙 — 주제(terms)는 노래하는 말에 근거를 둔다]
- 가사가 설명문에 있으면 **그 가사 한 구절을 why 에 적는다.**
- 가사가 없으면 terms 를 **비운다.** 제목·채널·분위기로 주제를 짐작하지 않는다.
- 용어는 아래 분야에서 찾되 낱말은 자유롭게 적는다(목록에 묶이지 않는다).
  분야: {fields}

[규칙 — 구절(verses)]
- 개역한글 약명 + 장:절(보기: 시 121:1). **가사나 설명문이 그 구절을 실제로
  노래하거나 인용할 때만** 적는다. 제목에 좌표가 있으면 그것도 적는다.

[규칙 — 찬양팀(artists)]
- **채널 이름을 그대로 베끼지 않는다.** 그 채널이 찬양팀·개인 찬양사역자·
  합창단인지 판단한다. 모아 올리는 채널·연주 채널·음반사면 role 을 각각
  `CHANNEL`·`LABEL` 로 하고 name 은 이름만 깨끗하게 적는다.

[공통]
- 확실하지 않으면 그 칸을 비운다. 지어내지 않는다.
- 항목마다 why 를 한 문장으로 — **무엇을 보고 그렇게 판단했는지.**
- confidence 는 HIGH·MED·LOW 셋 가운데 하나만 쓴다.
- JSON 만 낸다. 다른 말을 붙이지 않는다.

{{"kind":"SINGLE|MEDLEY|PLAYLIST|INSTRUMENTAL|SERMON|OTHER",
 "lyrics_in_desc":true,
 "songs":[{{"title":"","lang":"KO|EN|ZH|JA","confidence":"HIGH|MED|LOW","why":""}}],
 "tracks":[{{"title":"","lang":""}}],
 "other_songs":[{{"title":"","why":""}}],
 "artists":[{{"name":"","role":"TEAM|SOLO|CHOIR|CHANNEL|LABEL","confidence":"","why":""}}],
 "verses":[{{"ref":"시 121:1","confidence":"","why":""}}],
 "sermon_refs":[{{"ref":""}}],
 "terms":[{{"word":"","field":"","confidence":"","why":""}}]}}

[제목] {title}
[채널] {chan}
[설명문]
{desc}'''

# ══ 프롬프트 3판 — 2판을 140편 돌려 남은 흠 넷을 막는다 ═══════════════════
#
# 사용자 지시 「**AI 가 잘 판단하는 영역 또한 오류발생한 것을 조사해서 프롬프트를
#   업그레이드**하여 돌려보아라」.
#
# ★★★ 2판 실측 — E1·E3 은 **0으로 떨어졌다**(설교 용어 59→0 · 연주 용어 55→0 ·
#   모음집 곡 판 369→2 · 제목만 용어 23→0 · 구절 5→0). 남은 흠은 넷이다:
#   | 흠 | 무엇 | 실측 |
#   |---|---|---|
#   | **F1 약명 언어** | 讚美之泉 편에서 **`加 2:20`·`詩 118:24`·`哀 3:22-23`** 로 냈다 | 못 푼 구절 4건 — **판정은 옳고 형식만 틀렸다** |
#   | **F2 제목 좌표 놓침** | `I Will Find Refuge in You (Psalm 91)` 인데 안 냈다 | 2판이 「가사 근거」를 너무 세게 지켰다 |
#   | **F3 없는 곡 지어내기** | `카메라 보면서 찬송가 치기` → **「만복의 근원 하나님」** | 제목에 없는 이름이다 |
#   | **F4 합창단을 안 쓴다** | CHOIR 1판 5 → 2판 **0** | 보기를 안 주었다 |
#   ⚠⚠ **E4(찬양팀=채널명)는 오답이 아니었다 — 정정한다.** 채널명을 그대로 낸
#     98건 가운데 **84건이 이미 `role=CHANNEL`** 이라 밝혔다(2판은 95 중 90).
#     「이름은 채널명이지만 찬양팀이 아니다」는 **옳은 답**이다.

_V3_REF = '''[규칙 — 구절(verses)]
- **약명은 반드시 한국어로 적는다.** 자료가 중국어·영어·히브리어여도 한국어
  약명으로 옮긴다. 보기: `加 2:20` → **갈 2:20** · `詩 118:24` → **시 118:24**
  · `哀 3:22-23` → **애 3:22** · `Psalm 91` → **시 91:1** · `Romans 8:28` → **롬 8:28**
- **제목·부제에 구절 좌표가 있으면 반드시 적는다** — 가사를 몰라도 적는다.
  보기: `I Will Find Refuge in You (Psalm 91)` → 시 91:1 ·
  `Peace Be Still (Psalm 46:10)` → 시 46:10
- 그 밖에는 가사나 설명문이 그 구절을 실제로 노래하거나 인용할 때만 적는다.
- 장만 알면 1절로 적는다(`시 91` → 시 91:1). 구간은 시작 절만 적는다.'''

_V3_ARTI = '''[규칙 — 찬양팀(artists)]
- **채널 이름을 그대로 베끼지 않는다.** 그 채널이 찬양팀·개인 찬양사역자·
  합창단인지 판단한다. 모아 올리는 채널·연주 채널·음반사면 role 을 각각
  `CHANNEL`·`LABEL` 로 하고 name 은 이름만 깨끗하게 적는다.
- **합창단이면 `CHOIR`** — 성가대·Choral Society·Hymns Choir 처럼 여러 사람이
  합창하는 것이면 TEAM 이 아니라 CHOIR 다.'''

PROMPT_V3 = (PROMPT_V2
             .replace('''[규칙 — 구절(verses)]
- 개역한글 약명 + 장:절(보기: 시 121:1). **가사나 설명문이 그 구절을 실제로
  노래하거나 인용할 때만** 적는다. 제목에 좌표가 있으면 그것도 적는다.''',
                      _V3_REF)
             .replace('''[규칙 — 찬양팀(artists)]
- **채널 이름을 그대로 베끼지 않는다.** 그 채널이 찬양팀·개인 찬양사역자·
  합창단인지 판단한다. 모아 올리는 채널·연주 채널·음반사면 role 을 각각
  `CHANNEL`·`LABEL` 로 하고 name 은 이름만 깨끗하게 적는다.''', _V3_ARTI))

PROMPT_TITLE3 = (PROMPT_TITLE
                 .replace('''- 제목에 곡 이름이 없으면 songs 를 **빈 배열**로 둔다(지어내지 않는다).''',
                          '''- **제목에 실제로 적힌 낱말만 곡 이름으로 쓴다.** 제목에 곡 이름이 없으면
  songs 를 **빈 배열**로 둔다. 보기: `카메라 보면서 찬송가 치기` 는 곡 이름이
  없으므로 빈 배열이다 — 흔한 찬송가 이름을 골라 적으면 **틀린 연결**이 된다.
- 제목이 성경 구절 이름이나 설교 제목이면 그것도 곡 이름이 아니다.''')
                 .replace('''  인지 판단해서 role 을 선택하고, 모아 올리는 채널·연주 채널이면 `CHANNEL`.''',
                          '''  인지 판단해서 role 을 선택하고, 모아 올리는 채널·연주 채널이면 `CHANNEL`,
  음반사면 `LABEL`, 성가대·합창단이면 `CHOIR`.'''))

#: 설명문이 이보다 짧으면 **제목 전용 프롬프트**를 쓴다.
#: ⚠ 실측 표본은 `--fulldesc` 로 전문을 받아 전부 200자를 넘는다 — 그래서
#:   제목 전용을 재려면 **짧은 설명문 표본(F 갈래)** 이 따로 있어야 한다.
TITLE_ONLY_MAX = 200

#: 찬양으로 볼 조건 — 다른 화면과 같은 잣대.
_W = ("m.media_type='WORSHIP' AND COALESCE(m.record_status,'LIVE')='LIVE'")


# ── 표 ─────────────────────────────────────────────────────────────────────
def _cols(conn, tbl):
    try:
        return [r[1] for r in conn.execute('PRAGMA table_info(%s)' % tbl)]
    except Exception:
        return []


def _migrate_model_axis(conn):
    """옛 표(한 영상에 한 모델)를 **(영상, 모델)** 축으로 옮긴다 — 멱등.

    ★★★ **모델을 견주려면 축이 둘이어야 한다**(2026-09-30 사용자 「3」 =
      상위 모델로 같은 표본을 돌려 품질을 견준다). 옛 표는 `media_id` 가 PK 라
      두 번째 모델이 첫 모델을 **덮어 버렸다**.
    ⚠ SQLite 는 PK 를 못 고친다 — 새 표를 만들어 **옛 줄을 글자 그대로** 옮기고
      이름을 바꾼다. 옛 줄의 모델 이름은 그 줄에 이미 적혀 있다.
    """
    have = _cols(conn, T_RUN)
    if have and 'media_id' in have:
        # PK 가 (media_id, model) 인가 — 아니면 옮긴다.
        pk = [r[1] for r in conn.execute('PRAGMA table_info(%s)' % T_RUN) if r[5]]
        if pk != ['media_id', 'model']:
            conn.execute('DROP TABLE IF EXISTS %s_new' % T_RUN)
            conn.execute(
                "CREATE TABLE %s_new("
                " media_id INTEGER, grp TEXT, at TEXT, model TEXT,"
                " ok INTEGER, tok_in INTEGER, tok_out INTEGER, sec REAL,"
                " desc_len INTEGER, desc_full INTEGER, raw TEXT, kind TEXT,"
                " lyrics INTEGER, why TEXT, PRIMARY KEY(media_id, model))"
                % T_RUN)
            conn.execute(
                'INSERT OR REPLACE INTO %s_new(media_id,grp,at,model,ok,tok_in,'
                ' tok_out,sec,desc_len,desc_full,raw,kind,lyrics,why)'
                ' SELECT media_id,grp,at,COALESCE(model,""),ok,tok_in,tok_out,'
                ' sec,desc_len,desc_full,raw,kind,lyrics,why FROM %s'
                % (T_RUN, T_RUN))
            conn.execute('DROP TABLE %s' % T_RUN)
            conn.execute('ALTER TABLE %s_new RENAME TO %s' % (T_RUN, T_RUN))
    for cl in ('main', 'pver'):
        if _cols(conn, T_CHAN) and cl not in _cols(conn, T_CHAN):
            conn.execute('ALTER TABLE %s ADD COLUMN %s TEXT' % (T_CHAN, cl))
    if 'pver' not in _cols(conn, T_RUN) and _cols(conn, T_RUN):
        # ★ 어느 프롬프트 판을 **실제로** 썼나 — v2 는 편마다 전문/제목이 갈린다.
        conn.execute('ALTER TABLE %s ADD COLUMN pver TEXT' % T_RUN)
    if 'model' not in _cols(conn, T_ITEM) and _cols(conn, T_ITEM):
        conn.execute('ALTER TABLE %s ADD COLUMN model TEXT' % T_ITEM)
        # ⚠ 옛 낱낱에는 모델이 안 적혀 있다 — 그 영상의 돌린 줄에서 가져온다.
        conn.execute('UPDATE %s SET model=(SELECT model FROM %s r'
                     ' WHERE r.media_id=%s.media_id LIMIT 1)'
                     ' WHERE COALESCE(model,"")=""' % (T_ITEM, T_RUN, T_ITEM))
    conn.commit()


def ensure(conn):
    """시험 표 넷을 만든다(멱등). 옛 표는 모델 축으로 옮긴다."""
    conn.execute(
        "CREATE TABLE IF NOT EXISTS %s("
        " media_id INTEGER, grp TEXT, at TEXT, model TEXT,"
        " ok INTEGER, tok_in INTEGER, tok_out INTEGER, sec REAL,"
        " desc_len INTEGER, desc_full INTEGER, raw TEXT, kind TEXT,"
        " lyrics INTEGER, why TEXT, PRIMARY KEY(media_id, model))" % T_RUN)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS %s("
        " media_id INTEGER, slot TEXT, value TEXT, lang TEXT, conf TEXT,"
        " why TEXT, vid INTEGER, entity_id INTEGER, hit TEXT,"
        " model TEXT)" % T_ITEM)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_%s_m ON %s(media_id)"
                 % (T_ITEM, T_ITEM))
    _migrate_model_axis(conn)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS %s("
        " media_id INTEGER PRIMARY KEY, yt_desc TEXT, at TEXT)" % T_DESC)
    conn.execute(
        "CREATE TABLE IF NOT EXISTS %s("
        " chan TEXT PRIMARY KEY, n_vid INTEGER, at TEXT, model TEXT,"
        " name TEXT, kind TEXT, country TEXT, conf TEXT, why TEXT,"
        " hit INTEGER)" % T_CHAN)
    conn.commit()


def wipe(conn):
    for t in (T_ITEM, T_RUN, T_DESC, T_CHAN):
        try:
            conn.execute('DELETE FROM %s' % t)
        except Exception:
            pass
    conn.commit()


# ── 설명문 ─────────────────────────────────────────────────────────────────
def stored_desc(conn, mid):
    """저장본 (yt_desc, channel) — `sys_media_asset.description` 안의 JSON."""
    r = conn.execute("SELECT COALESCE(description,'') FROM sys_media_asset"
                     " WHERE media_id=?", (mid,)).fetchone()
    if not r:
        return '', ''
    try:
        j = json.loads(r[0] or '{}')
    except Exception:
        return '', ''
    return (j.get('yt_desc') or '').strip(), (j.get('channel') or '').strip()


def is_cut(s):
    """유튜브가 잘라 준 글인가 — `search.list` snippet 의 표식."""
    return bool(s) and s.rstrip().endswith(('...', '…'))


def best_desc(conn, mid):
    """전문이 있으면 전문, 없으면 저장본 → (글, 전문인가)."""
    r = conn.execute('SELECT yt_desc FROM %s WHERE media_id=?' % T_DESC,
                     (mid,)).fetchone()
    if r and (r[0] or '').strip():
        return r[0].strip(), 1
    return stored_desc(conn, mid)[0], 0


def yt_id(url):
    m = re.search(r'(?:v=|youtu\.be/|/embed/|/shorts/)([A-Za-z0-9_-]{11})',
                  url or '')
    return m.group(1) if m else None


def fetch_full(conn, mids, on_log=None):
    """`videos.list(part=snippet)` 로 설명문 전문을 받아 담는다 → 받은 수.

    ⚠ **50개당 1 unit** 이고 `db_media_linkcheck` 가 이미 같은 문을 부르므로
      본 작업에서는 그 자리에 얹으면 값이 **0**이다. 여기서는 시험 표만 채운다.
    """
    import db_media_linkcheck as LC
    keys = LC.api_keys(conn) or []
    if not keys:
        if on_log:
            on_log('YouTube API 키가 없다 — 전문을 못 받는다')
        return 0
    try:
        import googleapiclient.discovery as gd
    except Exception as e:
        if on_log:
            on_log('googleapiclient 없음: %s' % e)
        return 0
    rows = []
    for mid in mids:
        r = conn.execute('SELECT url FROM sys_media_asset WHERE media_id=?',
                         (mid,)).fetchone()
        v = yt_id(r[0] if r else '')
        if v:
            rows.append((mid, v))
    got = 0
    ki = 0
    i = 0
    while i < len(rows):
        batch = rows[i:i + 50]
        try:
            yt = gd.build('youtube', 'v3', developerKey=keys[ki],
                          cache_discovery=False)
            resp = yt.videos().list(part='snippet',
                                    id=','.join(v for _m, v in batch)).execute()
        except Exception as e:
            ki += 1
            if ki >= len(keys):
                if on_log:
                    on_log('API 오류로 멈춘다: %s' % str(e)[:120])
                break
            continue
        found = {it['id']: (it.get('snippet', {}) or {}).get('description', '')
                 for it in resp.get('items', [])}
        for mid, v in batch:
            d = (found.get(v) or '').strip()
            if not d:
                continue
            conn.execute('INSERT OR REPLACE INTO %s(media_id, yt_desc, at)'
                         ' VALUES(?,?,datetime("now"))' % T_DESC, (mid, d))
            got += 1
        conn.commit()
        if on_log:
            on_log('  전문 %d / %d' % (min(i + 50, len(rows)), len(rows)))
        i += 50
    return got


# ── 표본 ───────────────────────────────────────────────────────────────────
def _sql_of(grp):
    """갈래마다 표본 SQL — 규칙이 무엇을 했나로 가른다."""
    base = ("SELECT m.media_id FROM sys_media_asset m WHERE " + _W + " AND ")
    if grp == 'A':      # 용어 DESC 근거
        return base + (
            "EXISTS(SELECT 1 FROM sys_link_asset l WHERE l.clicked_id=m.media_id"
            " AND l.link_type='MEDI_ENTI' AND l.source LIKE 'DESC:%')")
    if grp == 'B':      # 용어 TITLE 근거
        return base + (
            "EXISTS(SELECT 1 FROM sys_link_asset l WHERE l.clicked_id=m.media_id"
            " AND l.link_type='MEDI_ENTI' AND l.source LIKE 'TITLE:%'"
            " AND COALESCE(l.record_status,'LIVE')='LIVE')")
    if grp == 'C':      # 구절 연결
        return base + (
            "EXISTS(SELECT 1 FROM sys_link_asset l WHERE l.clicked_id=m.media_id"
            " AND l.link_type='MEDI_VERS'"
            " AND COALESCE(l.record_status,'LIVE')='LIVE')")
    if grp == 'D':      # 아무 연결도 없음
        return base + (
            "NOT EXISTS(SELECT 1 FROM sys_link_asset l WHERE l.clicked_id=m.media_id"
            " AND l.link_type IN ('MEDI_REND','MEDI_ARTI','MEDI_VERS','MEDI_ENTI')"
            " AND COALESCE(l.record_status,'LIVE')='LIVE')")
    if grp == 'F':      # 설명문이 거의 없다 — 제목만으로 판단해야 하는 자리
        # ⚠ JSON 안의 길이를 SQL 로 못 재니 **담긴 글 전체 길이**로 가른다
        #   (껍데기가 100자쯤 되므로 400자 미만이면 설명문은 200자 미만이다).
        return base + (
            "LENGTH(COALESCE(m.description,'')) < 400"
            " AND COALESCE(m.description,'') LIKE '%yt_desc%'")
    if grp == 'P':      # 미검토(심사 대기) — 실제 심사(`db_ai_worship`)가 쓴다
        return base + "COALESCE(m.is_active,0)=0"
    if grp == 'E':      # 사람이 뗀 연결
        return base + (
            "EXISTS(SELECT 1 FROM sys_link_asset l WHERE l.clicked_id=m.media_id"
            " AND l.link_type IN ('MEDI_REND','MEDI_ARTI','MEDI_VERS','MEDI_ENTI')"
            " AND l.record_status='HIDE')")
    raise ValueError('모르는 갈래 %r' % grp)


def plan(conn, groups=GROUPS):
    """표본 → [(갈래, media_id)] — 한 편이 두 갈래에 겹치지 않게."""
    seen = set()
    out = []
    for grp, n in groups:
        # ★ **설명문이 있는 편을 먼저** — 없으면 판정 재료가 제목뿐이다.
        # ★ A~E 는 **재료가 많은 편**을 먼저(판정할 것이 있어야 한다).
        #   F 는 뜻이 반대라 **짧은 것부터** 뽑는다.
        order = ('ASC' if grp == 'F' else 'DESC')
        rows = conn.execute(
            _sql_of(grp) + " ORDER BY LENGTH(COALESCE(m.description,'')) "
            + order + ", m.media_id").fetchall()
        k = 0
        for (mid,) in rows:
            if mid in seen:
                continue
            seen.add(mid)
            out.append((grp, mid))
            k += 1
            if k >= n:
                break
    return out


def todo(conn, groups=GROUPS, model=None):
    """그 모델로 아직 안 보낸 표본 — 멱등의 근거.

    ⚠ **모델마다 따로 센다** — 모델을 견주려면 같은 표본을 두 번 돌려야 한다.
    """
    if model:
        done = set(r[0] for r in conn.execute(
            'SELECT media_id FROM %s WHERE ok=1 AND model=?' % T_RUN, (model,)))
    else:
        done = set(r[0] for r in conn.execute(
            'SELECT media_id FROM %s WHERE ok=1' % T_RUN))
    return [(g, m) for g, m in plan(conn, groups) if m not in done]


# ── AI ─────────────────────────────────────────────────────────────────────
def user_key(conn, prefer_admin=True):
    """시험에 쓸 Gemini 키 → (키, 모델). ⚠ 키를 찍지 않는다(§C-2).

    ★★★ **관리자 키를 먼저 쓴다**(2026-09-30). 그전에는 사용자 키만 써서
      **이 시험이 사용자의 AI 도우미 한도를 먹었다** — 실측 하루에 390회를
      쓰고 나니 사용자가 질문 하나에 429 를 받았다.
      ⚠ 한도는 **키마다가 아니라 구글 프로젝트마다**다(`docs/Rate limits.txt`
      「Rate limits are applied per project, not per API key」). 그러니 사용자
      키를 아끼는 것이 유일한 길이다.
    """
    if prefer_admin:
        try:
            import ai_client
            ks = ai_client.keys(conn) or []
            if ks:
                return ks[0], MODEL_DEFAULT
        except Exception:                                 # noqa: BLE001
            pass
    import user_ai as UA
    rows = UA.enabled_accounts(conn) or UA.accounts(conn) or []
    for a in rows:
        if (a.get('provider') or 'GEMINI').upper().startswith('GEM') and a.get('key'):
            return a.get('key'), (a.get('model') or MODEL_DEFAULT)
    return None, MODEL_DEFAULT


def pick_ver(desc, ver='v1'):
    """그 편에 쓸 프롬프트 판 — `v2` 를 선택하면 재료를 보고 갈라 준다.

    ★ `v2` = 설명문이 길면 **전문판**, 짧으면 **제목 전용판**.
      제목만 있는 편에 구절·용어를 물으면 **짐작을 받게 된다**(사용자 지적).
    """
    if ver not in ('v2', 'v3'):
        return ver
    short = len((desc or '').strip()) < TITLE_ONLY_MAX
    return (ver + 't') if short else ver


def build_prompt(title, chan, desc, fields=FIELDS, ver='v1'):
    """그 판의 프롬프트를 짓는다. `ver` = v1 · v2(전문) · v2t(제목 전용)."""
    d = (desc or '')[:4000] or '(설명문 없음)'
    if ver == 'v3t':
        return PROMPT_TITLE3.format(title=title or '', chan=chan or '', desc=d)
    if ver == 'v3':
        return PROMPT_V3.format(fields=fields, title=title or '',
                                chan=chan or '', desc=d)
    if ver == 'v2t':
        return PROMPT_TITLE.format(title=title or '', chan=chan or '', desc=d)
    if ver == 'v2':
        return PROMPT_V2.format(fields=fields, title=title or '',
                                chan=chan or '', desc=d)
    return PROMPT.format(fields=fields, title=title or '', chan=chan or '',
                         desc=d)


def has_term_list(prompt):
    """프롬프트에 **용어 목록**이 실렸나 — 실리면 안 된다(위 머리글)."""
    return '[용어 목록' in prompt


def ask(key, model, prompt, timeout=180, retry=3, maxout=2400):
    """한 번 묻는다 → dict. **예외를 밖으로 안 던진다**(값으로 돌려준다).

    ★ 2026-10-13 — 보낸 글을 글자 그대로 남긴다(`ai_sent_log` · 관리자 화면 「AI 에게 보낸 글」).
    """
    res = _ask_raw(key, model, prompt, timeout, retry, maxout)
    try:
        import ai_sent_log
        ai_sent_log.record('gemini_direct', prompt, model=model, ok=res.get('ok'),
                           response=res.get('text') or '', why=res.get('why') or '')
    except Exception:                                     # noqa: BLE001
        pass
    return res


def _ask_raw(key, model, prompt, timeout=180, retry=3, maxout=2400):
    """`ask` 의 몸통 — 망에 실제로 보낸다."""
    body = {'contents': [{'parts': [{'text': prompt}]}],
            'generationConfig': {'temperature': 0, 'maxOutputTokens': maxout}}
    last = {'ok': False, 'text': '', 'tok': 0, 'out': 0, 'sec': 0.0,
            'code': 0, 'fin': '', 'why': 'retry 소진'}
    for i in range(retry):
        t0 = time.time()
        try:
            req = urllib.request.Request(
                (ENDPOINT % model) + '?key=' + key,
                data=json.dumps(body).encode('utf-8'),
                headers={'Content-Type': 'application/json'})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                d = json.loads(r.read().decode('utf-8'))
            cand = (d.get('candidates') or [{}])[0]
            txt = ''.join(p.get('text', '') for p in
                          cand.get('content', {}).get('parts', []))
            u = d.get('usageMetadata', {}) or {}
            # ⚠⚠⚠ **생각 토큰도 출력으로 과금된다** — `candidatesTokenCount` 만
            #   세면 상위 모델의 값이 몇 배 적게 나온다(실측 3.5-flash 는 답이
            #   93토큰인데 생각에 2,300 을 썼다). 값을 잴 것이면 함께 센다.
            out = (u.get('candidatesTokenCount', 0) or 0) + \
                  (u.get('thoughtsTokenCount', 0) or 0)
            fin = cand.get('finishReason') or ''
            return {'ok': True, 'text': txt.strip(),
                    'tok': u.get('promptTokenCount', 0), 'out': out,
                    'sec': time.time() - t0, 'code': 200, 'fin': fin,
                    'why': ('잘렸다(MAX_TOKENS)' if fin == 'MAX_TOKENS' else '')}
        except urllib.error.HTTPError as e:
            try:
                msg = e.read().decode('utf-8', 'replace')[:200]
            except Exception:
                msg = ''
            last = {'ok': False, 'text': '', 'tok': 0, 'out': 0,
                    'sec': time.time() - t0, 'code': e.code,
                    'why': 'HTTP %s %s' % (e.code, msg.replace('\n', ' '))}
            # ⚠ 400·401·403·404 는 되묻지 않는다 — 한도만 더 먹는다.
            if e.code in (408, 429, 500, 502, 503, 504) and i < retry - 1:
                time.sleep(15 * (i + 1))
                continue
            return last
        except Exception as e:
            return {'ok': False, 'text': '', 'tok': 0, 'out': 0,
                    'sec': time.time() - t0, 'code': 0, 'fin': '',
                    'why': str(e)[:160]}
    return last


def parse(txt):
    """AI 답 → dict. 코드펜스를 견딘다. 못 읽으면 `None`."""
    s = (txt or '').strip()
    s = re.sub(r'^```(?:json)?\s*', '', s)
    s = re.sub(r'\s*```$', '', s).strip()
    if not s:
        return None
    try:
        d = json.loads(s)
    except Exception:
        m = re.search(r'\{.*\}', s, re.S)
        if not m:
            return None
        try:
            d = json.loads(m.group(0))
        except Exception:
            return None
    return d if isinstance(d, dict) else None


# ── 맞춤(우리 자료에 있나) ──────────────────────────────────────────────────
def _norm(s):
    return re.sub(r'[\s·\-_.!?\'"()\[\]]+', '', (s or '')).lower()


def term_index(conn):
    """용어 이름(KO) → entity_id. 「간구 · 데에시스」의 **앞 조각**도 담는다."""
    exact, head = {}, {}
    for eid, nm in conn.execute(
            "SELECT clicked_id, contents FROM sys_text_asset"
            " WHERE text_type='ENTITY_NAME' AND lang_code='KO'"):
        nm = (nm or '').strip()
        if not nm:
            continue
        exact.setdefault(nm, eid)
        first = nm.split('·')[0].strip()
        if first and first != nm:
            head.setdefault(first, eid)
    return exact, head


def term_match(word, exact, head):
    """낱말 → (entity_id, 어떻게 맞았나 'EXACT'|'HEAD'|'')."""
    w = (word or '').strip()
    if not w:
        return None, ''
    if w in exact:
        return exact[w], 'EXACT'
    if w in head:
        return head[w], 'HEAD'
    return None, ''


def artist_index(conn):
    """찬양팀 이름·채널 표기 → artist_id."""
    out = {}
    for aid, nm in conn.execute(
            "SELECT a.artist_id, t.contents FROM sys_worship_artist a"
            " JOIN sys_text_asset t ON t.clicked_id=a.artist_id"
            "  AND t.text_type='ARTIST_NAME'"
            " WHERE COALESCE(a.record_status,'LIVE')='LIVE'"):
        out.setdefault(_norm(nm), aid)
    for aid, nm in conn.execute(
            "SELECT artist_id, channel_name FROM sys_worship_artist"
            " WHERE COALESCE(channel_name,'')<>''"):
        out.setdefault(_norm(nm), aid)
    return out


def song_index(conn):
    """곡 이름·판 열쇠 → song_id."""
    out = {}
    for sid, nm in conn.execute(
            "SELECT clicked_id, contents FROM sys_text_asset"
            " WHERE text_type IN ('SONG_TITLE','SONG_REND_TITLE','SONG_ALIAS')"):
        out.setdefault(_norm(nm), sid)
    for sid, tk in conn.execute(
            "SELECT song_id, title_key FROM sys_song_rendition"
            " WHERE COALESCE(title_key,'')<>''"):
        out.setdefault(_norm(tk), sid)
    return out


# ── 저장 ───────────────────────────────────────────────────────────────────
def save(conn, mid, grp, model, res, d, desc_len, desc_full, idx=None,
         pver=''):
    """한 편의 결과를 담는다(멱등 — 다시 넣으면 갈아 끼운다)."""
    import scripture_ref_kr as SR
    ex, hd = idx[0] if idx else term_index(conn)[0], idx[1] if idx else {}
    if idx is None:
        ex, hd = term_index(conn)
    ai = idx[2] if idx else artist_index(conn)
    sg = idx[3] if idx else song_index(conn)
    bm = idx[4] if idx else SR.book_map_ko(conn)

    conn.execute('DELETE FROM %s WHERE media_id=? AND COALESCE(model,"")=?'
                 % T_ITEM, (mid, model or ''))
    conn.execute(
        'INSERT OR REPLACE INTO %s(media_id,grp,at,model,ok,tok_in,tok_out,'
        ' sec,desc_len,desc_full,raw,kind,lyrics,why,pver) VALUES'
        ' (?,?,datetime("now"),?,?,?,?,?,?,?,?,?,?,?,?)' % T_RUN,
        (mid, grp, model, 1 if res['ok'] else 0, res['tok'], res['out'],
         round(res['sec'], 2), desc_len, desc_full, res['text'] or '',
         (d or {}).get('kind', ''),
         1 if (d or {}).get('lyrics_in_desc') else 0, res['why'], pver))
    if not d:
        conn.commit()
        return
    for x in (d.get('songs') or []):
        nm = (x or {}).get('title', '')
        conn.execute('INSERT INTO %s(media_id,slot,value,lang,conf,why,vid,'
                     'entity_id,hit,model) VALUES(?,?,?,?,?,?,NULL,?,?,?)' % T_ITEM,
                     (mid, 'SONG', nm, (x or {}).get('lang', ''),
                      (x or {}).get('confidence', ''), (x or {}).get('why', ''),
                      sg.get(_norm(nm)), 'OURS' if _norm(nm) in sg else '',
                      model))
    for x in (d.get('artists') or []):
        nm = (x or {}).get('name', '')
        conn.execute('INSERT INTO %s(media_id,slot,value,lang,conf,why,vid,'
                     'entity_id,hit,model) VALUES(?,?,?,?,?,?,NULL,?,?,?)' % T_ITEM,
                     (mid, 'ARTI', nm, (x or {}).get('role', ''),
                      (x or {}).get('confidence', ''), (x or {}).get('why', ''),
                      ai.get(_norm(nm)), 'OURS' if _norm(nm) in ai else '',
                      model))
    for x in (d.get('verses') or []):
        ref = (x or {}).get('ref', '')
        s, _e = SR.resolve(conn, ref, bm)
        conn.execute('INSERT INTO %s(media_id,slot,value,lang,conf,why,vid,'
                     'entity_id,hit,model) VALUES(?,?,?,?,?,?,?,NULL,?,?)' % T_ITEM,
                     (mid, 'VERS', ref, '', (x or {}).get('confidence', ''),
                      (x or {}).get('why', ''), s, 'RESOLVED' if s else '',
                      model))
    # ★★★ **가른 것을 버리지 않는다** — 수록곡·남의 곡·설교 본문을 따로 담아야
    #   「무엇을 곡 판으로 올릴까」를 사람이 그 자리에서 가릴 수 있다.
    for x in (d.get('tracks') or []):
        nm = (x or {}).get('title', '')
        conn.execute('INSERT INTO %s(media_id,slot,value,lang,conf,why,vid,'
                     'entity_id,hit,model) VALUES(?,?,?,?,"","",NULL,?,?,?)' % T_ITEM,
                     (mid, 'TRACK', nm, (x or {}).get('lang', ''),
                      sg.get(_norm(nm)), 'OURS' if _norm(nm) in sg else '', model))
    for x in (d.get('other_songs') or []):
        nm = (x or {}).get('title', '')
        conn.execute('INSERT INTO %s(media_id,slot,value,lang,conf,why,vid,'
                     'entity_id,hit,model) VALUES(?,?,?,"","",?,NULL,?,?,?)' % T_ITEM,
                     (mid, 'OTHER', nm, (x or {}).get('why', ''),
                      sg.get(_norm(nm)), 'OURS' if _norm(nm) in sg else '', model))
    for x in (d.get('sermon_refs') or []):
        ref = (x or {}).get('ref', '') if isinstance(x, dict) else str(x)
        s2, _e2 = SR.resolve(conn, ref, bm)
        conn.execute('INSERT INTO %s(media_id,slot,value,lang,conf,why,vid,'
                     'entity_id,hit,model) VALUES(?,?,?,"","","",?,NULL,?,?)' % T_ITEM,
                     (mid, 'SREF', ref, s2, 'RESOLVED' if s2 else '', model))
    for x in (d.get('terms') or []):
        w = (x or {}).get('word', '')
        eid, how = term_match(w, ex, hd)
        conn.execute('INSERT INTO %s(media_id,slot,value,lang,conf,why,vid,'
                     'entity_id,hit,model) VALUES(?,?,?,?,?,?,NULL,?,?,?)' % T_ITEM,
                     (mid, 'TERM', w, (x or {}).get('field', ''),
                      (x or {}).get('confidence', ''), (x or {}).get('why', ''),
                      eid, how, model))
    conn.commit()


# ── 돌리기 ─────────────────────────────────────────────────────────────────
def run(conn, n=20, model=None, pace=5.0, on_log=None, groups=GROUPS,
        ver='v1'):
    """표본 N편을 AI 에 보낸다 → dict(보냄·받음·멈춤 사유).

    ⚠ **한도에 걸리면 거기까지 담고 멈춘다** — 몇 편을 했는지 말한다.
      다시 부르면 안 한 것부터 이어 간다(멱등).
    """
    import scripture_ref_kr as SR
    ensure(conn)
    key, m0 = user_key(conn)
    if not key:
        return {'sent': 0, 'ok': 0, 'why': '사용자 Gemini 키가 없다'}
    model = model or m0 or MODEL_DEFAULT
    #: 담는 이름 = 모델 + 판 — 같은 모델의 두 판을 견줄 수 있어야 한다.
    tag = model if ver == 'v1' else '%s/%s' % (model, ver)
    ex, hd = term_index(conn)
    idx = (ex, hd, artist_index(conn), song_index(conn), SR.book_map_ko(conn))
    rows = todo(conn, groups, tag)[:max(0, int(n))]
    sent = ok = 0
    why = ''
    for grp, mid in rows:
        r = conn.execute('SELECT title FROM sys_media_asset WHERE media_id=?',
                         (mid,)).fetchone()
        title = r[0] if r else ''
        chan = stored_desc(conn, mid)[1]
        desc, full = best_desc(conn, mid)
        pv = pick_ver(desc, ver)
        p = build_prompt(title, chan, desc, ver=pv)
        res = ask(key, model, p, maxout=maxout_of(model))
        sent += 1
        d = parse(res['text']) if res['ok'] else None
        # ⚠⚠⚠ **못 읽은 답을 성공으로 적지 않는다**(§0-1 조용한 실패) — 그러면
        #   「곡0 팀0 절0 용어0」이 되어 **모델이 아무것도 못 찾은 것처럼** 보인다.
        if res['ok'] and d is None:
            res = dict(res, ok=False,
                       why=('JSON 못 읽음' +
                            (' · ' + res['why'] if res['why'] else '')))
        save(conn, mid, grp, tag, res, d, len(desc or ''), full, idx, pv)
        if res['ok']:
            ok += 1
            if on_log:
                on_log('  [%s%s] %-6d %-38s 곡%d 팀%d 절%d 용어%d  %d/%d토큰 %.1f초'
                       % (grp, ('·' + pv if pv != 'v1' else ''), mid,
                          (title or '')[:38],
                          len((d or {}).get('songs') or []),
                          len((d or {}).get('artists') or []),
                          len((d or {}).get('verses') or []),
                          len((d or {}).get('terms') or []),
                          res['tok'], res['out'], res['sec']))
        else:
            if on_log:
                on_log('  [%s] %-6d 실패 %s' % (grp, mid, res['why'][:90]))
            # ⚠ 한도·과부하면 **그 자리에서 멈춘다** — 계속 두드리면 더 막힌다.
            if res['code'] in (429, 503):
                why = res['why']
                break
        time.sleep(max(0.0, float(pace)))
    return {'sent': sent, 'ok': ok, 'why': why, 'model': tag,
            'left': len(todo(conn, groups, tag))}


# ── 1회차 : 채널을 찬양팀으로 가른다 ────────────────────────────────────────
#
# ★★★ **「명단을 대라」는 못 쓴다** — 실측(302차) AI 에게 영역을 지시하고
#   이름을 받으니 중화권 20개 중 **19개가 우리 자료에 없었다**(95% · 「글로리
#   워십(榮耀敬拜)」처럼 일반명사를 조합한 가짜). confidence 도 전부 HIGH 라
#   변별력이 0이었다.
# ★★★ **반대로 하면 된다** — 우리가 이미 수집한 채널 이름은 **실재가 보장**
#   된다. 찬양 영상이 있는 채널 4,176곳 가운데 찬양팀으로 등록된 것이 92곳뿐
#   이고, 미등록 + 3편 이상이 **794곳**이다. 그것을 가르면 발굴이 된다.
#   실측 30곳 → 찬양팀 7(23%) · 모아 올리는 채널 20 · 음반사 3 · **지어낸 이름 0**.
#   게다가 이름을 다듬어 준다(`YERAM WORSHIP [편곡자 NAM D]` → 예람워십).

CHAN_PROMPT = '''너는 기독교 영상 자료를 정리하는 조수다.

아래는 **우리가 실제로 수집한 유튜브 채널 목록**이다. 채널마다 그 채널이
올린 영상 제목을 셋까지 함께 적어 두었다.

채널마다 판정하라.

[규칙 — kind : 그 채널의 임자가 무엇인가]
- `TEAM` 찬양팀 · `SOLO` 개인 찬양사역자 · `CHOIR` 합창단·성가대 ·
  `LABEL` 음반사·배급
- `CHURCH` **교회**(교회가 제 예배·설교를 올리는 채널) ·
  `QT` **개인 묵상·큐티 채널**(한 사람이 날마다 말씀 묵상을 올린다) ·
  `MINISTRY` 선교회·기관·신학교 · `BROADCAST` 방송사·기독 미디어
- `CHANNEL` 위 어디도 아니고 **남의 것을 모아 올리는 채널**(연주·수면음악·
  플레이리스트·모음집)
- 모르면 `UNKNOWN`.

[규칙 — main : 그 채널이 주로 올리는 것]
- `WORD` 설교·강해·큐티  ·  `WOR` 찬양·CCM  ·  `READ` 성경 낭독 ·
  `FILM` 영화·애니  ·  `MIXED` 둘이 비슷하게 섞였다
- ⚠ **제목에 「예배」가 있어도 그것만으로 WORD 라 하지 않는다.** 찬양팀의
  「목요예배」·「하루예배」는 찬양이다. **그 채널이 무엇을 하는 곳인가**로 정한다.

[공통]
- **채널 이름과 제목만 보고 판단한다.** 지어내지 않는다.
- name — 임자의 **이름만** 깨끗하게(꾸밈말·안내문·이모지·「Official」
  「[편곡자 …]」 같은 것은 뗀다). CHANNEL 이면 채널 이름 그대로.
- country — 알 수 있으면 두 글자 코드(KR·TW·US·HK·JP …), 모르면 빈 칸.
- why 한 문장.
- JSON 배열만. 줄 수는 입력과 같아야 한다.

[{{"no":1,"name":"","kind":"","main":"","country":"","confidence":"HIGH|MED|LOW","why":""}}]

[채널 목록]
{rows}'''

#: 채널 판정 프롬프트 판 — 표에 적어 둔다(1판은 kind 에 교회·QT 가 없었다).
CHAN_PVER = 'c2'

#: 한 번에 몇 곳 — 30곳이 2,229 토큰이었다(실측).
CHAN_BATCH = 30

#: 찬양팀으로 볼 갈래 — 나머지는 찬양팀이 아니다.
CHAN_ARTIST = ('TEAM', 'SOLO', 'CHOIR')
#: 우리가 아는 주 갈래 값(사용자 화면 묶음과 같다).
CHAN_MAIN = ('WORD', 'WOR', 'READ', 'FILM', 'MIXED')


#: 우리 분류기의 유형 → 사용자 화면 묶음. 대조할 때 쓴다.
MAIN_OF = {'SERMON': 'WORD', 'STUDY': 'WORD', 'READING': 'READ',
           'WORSHIP': 'WOR', 'FILM': 'FILM'}


def chan_pool(conn, min_vid=3, worship_only=False):
    """영상 N편 이상 채널 → [(채널, 편수, [제목…], 우리분류주갈래)].

    ★★★ **모든 유형을 센다**(2026-09-30 사용자 「채널 분류가 가장 중요하다」) —
      그전에는 찬양 영상만 세어 말씀·낭독 채널이 후보에 아예 없었다.
    ★ 우리 분류기가 본 주 갈래를 함께 돌려준다 — **프롬프트에는 안 싣고**
      대조할 때만 쓴다(주면 AI 가 그 답을 베낀다).
    """
    ch = {}
    where = _W if worship_only else (
        "COALESCE(m.record_status,'LIVE')='LIVE'")
    for mtype, title, dj in conn.execute(
            "SELECT media_type, title, COALESCE(description,'')"
            " FROM sys_media_asset m WHERE " + where):
        try:
            nm = (json.loads(dj or '{}').get('channel') or '').strip()
        except Exception:
            nm = ''
        if not nm:
            continue
        d = ch.setdefault(nm, [0, [], {}])
        d[0] += 1
        if len(d[1]) < 3:
            d[1].append(title or '')
        g = MAIN_OF.get(mtype, '?')
        d[2][g] = d[2].get(g, 0) + 1
    out = []
    for k, v in ch.items():
        if v[0] < int(min_vid):
            continue
        top = max(v[2].items(), key=lambda x: x[1])[0] if v[2] else '?'
        out.append((k, v[0], v[1], top))
    out.sort(key=lambda x: -x[1])
    return out


def chan_todo(conn, min_vid=3, pver=None):
    """아직 **이 판으로** 판정하지 않은 채널 — 판을 올리면 다시 돈다."""
    pv = pver or CHAN_PVER
    done = set(r[0] for r in conn.execute(
        'SELECT chan FROM %s WHERE COALESCE(pver,"")=?' % T_CHAN, (pv,)))
    return [x for x in chan_pool(conn, min_vid) if x[0] not in done]


def chan_parse(txt):
    """채널 판정 답 → [dict]. 코드펜스를 견딘다."""
    s = re.sub(r'^```(?:json)?\s*', '', (txt or '').strip())
    s = re.sub(r'\s*```$', '', s).strip()
    try:
        d = json.loads(s)
    except Exception:
        m = re.search(r'\[.*\]', s, re.S)
        if not m:
            return []
        try:
            d = json.loads(m.group(0))
        except Exception:
            return []
    return d if isinstance(d, list) else []


def run_chan(conn, n=60, model=None, min_vid=3, pace=5.0, on_log=None,
             batch_n=None):
    """채널 N곳을 판정한다 → dict. 한도에 걸리면 담고 멈춘다(멱등)."""
    ensure(conn)
    key, m0 = user_key(conn)
    if not key:
        return {'sent': 0, 'ok': 0, 'why': '사용자 Gemini 키가 없다'}
    model = model or m0 or MODEL_DEFAULT
    ai = artist_index(conn)
    pool = chan_todo(conn, min_vid)[:max(0, int(n))]
    sent = ok = 0
    why = ''
    bn = int(batch_n or CHAN_BATCH)
    for i in range(0, len(pool), bn):
        batch = pool[i:i + bn]
        # ⚠ `chan_pool` 은 넷을 낸다 — 넷째(우리 분류기 답)는 **프롬프트에 안 싣는다**
        #   (주면 AI 가 그 답을 베껴 대조가 뜻을 잃는다).
        rows = '\n'.join(
            '%d. %s  (영상 %d편) | %s' % (j + 1, nm, k, ' | '.join(t)[:150])
            for j, (nm, k, t, _g) in enumerate(batch))
        # ⚠⚠ **생각 모델은 예산이 더 든다** — 실측 3.6-flash 가 5,000 에서
        #   잘려 「0곳 판정」이 나왔다. 모델 표를 쓰고, 30곳이면 답만 1,300
        #   토큰이라 넉넉히 잡는다.
        res = ask(key, model, CHAN_PROMPT.format(rows=rows),
                  maxout=max(6000, maxout_of(model)))
        sent += len(batch)
        if not res['ok']:
            if on_log:
                on_log('  실패 %s' % res['why'][:100])
            if res['code'] in (429, 503):
                why = res['why']
                break
            continue
        got = chan_parse(res['text'])
        # ⚠ **못 읽은 답을 조용히 넘기지 않는다**(§0-1) — 잘렸는지 말한다.
        if not got and on_log:
            on_log('  ⚠ 답을 못 읽었다 (출력 %d토큰 · %s)'
                   % (res['out'], res['why'] or 'JSON 아님'))
        for x in got:
            try:
                j = int(x.get('no', 0)) - 1
            except Exception:
                continue
            if not (0 <= j < len(batch)):
                continue
            nm, k, _t, _g = batch[j]
            name = (x.get('name') or '').strip()
            conn.execute(
                'INSERT OR REPLACE INTO %s(chan,n_vid,at,model,name,kind,'
                ' country,conf,why,hit,main,pver) VALUES'
                ' (?,?,datetime("now"),?,?,?,?,?,?,?,?,?)' % T_CHAN,
                (nm, k, model, name, (x.get('kind') or '').strip(),
                 (x.get('country') or '').strip(),
                 (x.get('confidence') or '').strip(),
                 (x.get('why') or '').strip(),
                 1 if _norm(name) in ai else 0,
                 (x.get('main') or '').strip(), CHAN_PVER))
            ok += 1
        conn.commit()
        if on_log:
            on_log('  %d곳 판정 (%d/%d 토큰 %.1f초)'
                   % (len(got), res['tok'], res['out'], res['sec']))
        time.sleep(max(0.0, float(pace)))
    return {'sent': sent, 'ok': ok, 'why': why, 'model': model,
            'left': len(chan_todo(conn, min_vid))}


def chan_report(conn, out_path=None, pver=None):
    """채널 판정 요약 + **우리 분류기와 대조** → 글.

    ⚠ **판마다 따로 센다** — 1판(`c1`)은 `main` 칸이 없었다. 섞으면 그 90곳이
      「주 갈래 모름」으로 잡혀 대조가 거짓이 된다(실측으로 당했다).
    """
    from collections import Counter
    pv = pver or CHAN_PVER
    rows = conn.execute('SELECT chan,n_vid,name,kind,country,conf,hit,why,main'
                        ' FROM %s WHERE COALESCE(pver,"")=?'
                        ' ORDER BY n_vid DESC' % T_CHAN, (pv,)).fetchall()
    if not rows:
        return '채널 판정을 아직 안 돌렸다 — `--chan N` 을 먼저.'
    old = conn.execute('SELECT COUNT(*) FROM %s WHERE COALESCE(pver,"")<>?'
                       % T_CHAN, (pv,)).fetchone()[0]
    L = ['=' * 76, '채널 판정 — 판 %s · %d곳%s'
         % (pv, len(rows), (' (옛 판 %d곳은 안 셌다)' % old) if old else '')]
    #: 우리 분류기가 본 주 갈래
    ours = {k: g for k, _n, _t, g in chan_pool(conn, 1)}

    kc = Counter(r[3] or '?' for r in rows)
    art = sum(v for k, v in kc.items() if k in CHAN_ARTIST)
    L.append('')
    L.append('① 임자 갈래(kind)')
    for k, n in kc.most_common():
        L.append('   %-10s %5d곳 (%.1f%%)' % (k, n, 100.0 * n / len(rows)))
    L.append('   >> **찬양팀(팀·개인·합창) %d곳** · 교회 %d · QT %d · 사역단체 %d'
             ' · 방송 %d · 음반사 %d · 모아올림 %d · 모름 %d'
             % (art, kc.get('CHURCH', 0), kc.get('QT', 0),
                kc.get('MINISTRY', 0), kc.get('BROADCAST', 0),
                kc.get('LABEL', 0), kc.get('CHANNEL', 0), kc.get('UNKNOWN', 0)))

    L.append('')
    L.append('② 주 갈래(main)')
    mc = Counter(r[8] or '?' for r in rows)
    for k, n in mc.most_common():
        L.append('   %-8s %5d곳 (%.1f%%)' % (k, n, 100.0 * n / len(rows)))

    L.append('')
    L.append('③ **우리 분류기 ↔ AI 대조** — 채널 주 갈래가 같은가')
    L.append('   %-8s | %s' % ('우리', ' '.join('%6s' % x for x in
                                               list(CHAN_MAIN) + ['?'])))
    same = tot = 0
    grid = {}
    for r in rows:
        o = ours.get(r[0], '?')
        a = r[8] or '?'
        grid[(o, a)] = grid.get((o, a), 0) + 1
        tot += 1
        if o == a or (a == 'MIXED' and o != '?'):
            same += 1
    for o in ('WORD', 'WOR', 'READ', 'FILM', '?'):
        if not any(k[0] == o for k in grid):
            continue
        L.append('   %-8s | %s' % (o, ' '.join(
            '%6d' % grid.get((o, a), 0) for a in list(CHAN_MAIN) + ['?'])))
    L.append('   >> 같음 %d / %d (**%.1f%%**) — MIXED 는 맞은 것으로 센다'
             % (same, tot, 100.0 * same / max(tot, 1)))
    L.append('   ⚠ 어긋난 자리가 곧 **사람이 볼 줄**이다(어느 쪽이 틀렸는지는'
             ' 제목을 읽어야 안다).')

    L.append('')
    L.append('④ 우리 분류기와 어긋난 채널 — 표본')
    n = 0
    for r in rows:
        o = ours.get(r[0], '?')
        a = r[8] or '?'
        if o == a or a == 'MIXED' or n >= 20:
            continue
        L.append('   우리 %-5s ↔ AI %-5s %-8s %-26s %4d편  %s'
                 % (o, a, r[3] or '', (r[2] or '')[:26], r[1], (r[7] or '')[:34]))
        n += 1

    L.append('')
    L.append('⑤ 찬양팀 후보 (등록 안 된 것)')
    n = 0
    for r in rows:
        if r[3] in CHAN_ARTIST and not r[6]:
            n += 1
            if n <= 25:
                L.append('   %-7s %-3s %-26s %4d편  ← %s'
                         % (r[3], r[4] or '', (r[2] or '')[:26], r[1], r[0][:30]))
    L.append('   … 찬양팀 후보 합계 %d곳' % n)

    L.append('')
    L.append('⑥ 교회·QT 후보 — `sys_media_channel.org_kind` 를 채울 재료')
    for k in ('CHURCH', 'QT', 'MINISTRY', 'BROADCAST'):
        sub = [r for r in rows if r[3] == k]
        L.append('   [%s] %d곳' % (k, len(sub)))
        for r in sub[:6]:
            L.append('      %-3s %-28s %4d편  ← %s'
                     % (r[4] or '', (r[2] or '')[:28], r[1], r[0][:28]))

    L.append('')
    L.append('⑦ confidence — 변별력이 있나')
    L.append('   %s' % dict(Counter(r[5] or '?' for r in rows)))
    txt = '\n'.join(L)
    if out_path:
        io.open(out_path, 'w', encoding='utf-8').write(txt)
    return txt


# ── 대조 ───────────────────────────────────────────────────────────────────
def rule_links(conn, mid):
    """규칙이 낸 연결 → {slot: {(값, 상태, 근거)}}."""
    out = {'VERS': set(), 'TERM': set(), 'SONG': set(), 'ARTI': set()}
    for lt, slot in (('MEDI_VERS', 'VERS'), ('MEDI_ENTI', 'TERM'),
                     ('MEDI_REND', 'SONG'), ('MEDI_ARTI', 'ARTI')):
        for tid, st, src in conn.execute(
                "SELECT target_id, COALESCE(record_status,'LIVE'),"
                " COALESCE(source,'') FROM sys_link_asset"
                " WHERE link_type=? AND clicked_id=?", (lt, mid)):
            out[slot].add((tid, st, src))
    return out


def report(conn, out_path=None, model=None):
    """규칙 ↔ AI 대조 → 글."""
    ensure(conn)
    # ★ **모델 축** — 안 주면 가장 많이 돌린 모델 하나를 고른다(섞어 세면 안 된다).
    if not model:
        r = conn.execute('SELECT model, COUNT(*) FROM %s GROUP BY 1'
                         ' ORDER BY 2 DESC LIMIT 1' % T_RUN).fetchone()
        model = (r[0] if r else '') or ''
    #: 그 모델의 낱낱만 보는 조각 — 모든 조회가 이것을 표처럼 쓴다.
    IT = ('(SELECT * FROM ' + T_ITEM + ' WHERE COALESCE(model,\'\')=\''
          + str(model).replace("'", "''") + '\')')
    L = []

    def w(s=''):
        L.append(s)

    runs = conn.execute(
        'SELECT media_id, grp, ok, tok_in, tok_out, sec, desc_len, desc_full,'
        ' kind, lyrics, why FROM %s WHERE COALESCE(model,"")=?'
        % T_RUN, (model,)).fetchall()
    if not runs:
        return '아직 돌린 것이 없다 — `--run N` 을 먼저.'
    okr = [r for r in runs if r[2]]
    w('=' * 74)
    w('찬양 AI 판정 시험 — 규칙과 나란히 · 모델 %s (%d편 보냄 · %d편 받음)'
      % (model or '(없음)', len(runs), len(okr)))
    ti = sum(r[3] or 0 for r in okr)
    to = sum(r[4] or 0 for r in okr)
    w('  토큰 입력 %d · 출력 %d · 편당 %.0f/%.0f · 값 ≈ $%.4f'
      % (ti, to, ti / max(len(okr), 1), to / max(len(okr), 1),
         ti / 1e6 * 0.25 + to / 1e6 * 1.50))
    w('  설명문 전문을 쓴 편 %d / %d · 가사가 들었다고 본 편 %d'
      % (sum(1 for r in okr if r[7]), len(okr),
         sum(1 for r in okr if r[9])))
    w()
    w('① 영상 갈래 — 규칙이 아예 못 하던 판정')
    from collections import Counter
    kc = Counter((r[8] or '?') for r in okr)
    for k, n in kc.most_common():
        w('   %-14s %4d편' % (k, n))
    w()
    w('② 갈래별로 AI 가 낸 값의 수 (편당 평균)')
    w('   갈래  편수 |  곡   찬양팀  구절  용어 | 구절 풀림  용어 맞음')
    for grp, _n in GROUPS:
        ms = [r[0] for r in okr if r[1] == grp]
        if not ms:
            continue
        q = ('SELECT slot, COUNT(*), SUM(hit<>"") FROM %s WHERE media_id IN (%s)'
             ' GROUP BY slot' % (IT, ','.join('?' * len(ms))))
        got = {s: (c, h or 0) for s, c, h in conn.execute(q, ms)}
        w('   %s    %4d | %4.1f %5.1f %5.1f %5.1f |   %3d %8d'
          % (grp, len(ms),
             got.get('SONG', (0, 0))[0] / len(ms),
             got.get('ARTI', (0, 0))[0] / len(ms),
             got.get('VERS', (0, 0))[0] / len(ms),
             got.get('TERM', (0, 0))[0] / len(ms),
             got.get('VERS', (0, 0))[1], got.get('TERM', (0, 0))[1]))
    w()
    w('③ 구절 — 규칙 ∩ AI')
    both = ronly = aonly = 0
    for r in okr:
        mid = r[0]
        rv = set(t for t, st, _s in rule_links(conn, mid)['VERS']
                 if st == 'LIVE')
        av = set(v for (v,) in conn.execute(
            'SELECT vid FROM %s WHERE media_id=? AND slot="VERS"'
            ' AND vid IS NOT NULL' % IT, (mid,)))
        both += len(rv & av)
        ronly += len(rv - av)
        aonly += len(av - rv)
    w('   둘 다 %d · 규칙만 %d · **AI 만 %d**' % (both, ronly, aonly))
    w()
    w('④ 용어 — 규칙 ∩ AI (우리 용어 번호로 맞춘 것만)')
    tb = tr = ta = 0
    for r in okr:
        mid = r[0]
        rv = set(t for t, st, _s in rule_links(conn, mid)['TERM']
                 if st == 'LIVE')
        av = set(v for (v,) in conn.execute(
            'SELECT entity_id FROM %s WHERE media_id=? AND slot="TERM"'
            ' AND entity_id IS NOT NULL' % IT, (mid,)))
        tb += len(rv & av)
        tr += len(rv - av)
        ta += len(av - rv)
    w('   둘 다 %d · 규칙만 %d · AI 만 %d' % (tb, tr, ta))
    w()
    w('⑤ 사람이 뗀 것을 AI 가 다시 내나 (E 갈래의 잣대)')
    again = 0
    for r in okr:
        mid = r[0]
        hid = set(t for t, st, _s in rule_links(conn, mid)['TERM'] if st == 'HIDE')
        hid |= set(t for t, st, _s in rule_links(conn, mid)['VERS'] if st == 'HIDE')
        av = set(v for (v,) in conn.execute(
            'SELECT entity_id FROM %s WHERE media_id=? AND entity_id IS NOT NULL'
            % IT, (mid,)))
        av |= set(v for (v,) in conn.execute(
            'SELECT vid FROM %s WHERE media_id=? AND vid IS NOT NULL'
            % IT, (mid,)))
        again += len(hid & av)
    w('   사람이 뗀 짝을 AI 가 다시 낸 건수 **%d**' % again)
    w()
    w('⑥ 용어 낱말이 우리 명단에 있나')
    tot = conn.execute('SELECT COUNT(*) FROM %s WHERE slot="TERM"' % IT
                       ).fetchone()[0]
    for how, nm in (('EXACT', '이름이 꼭 맞음'), ('HEAD', '앞 조각이 맞음'),
                    ('', '**우리 명단에 없음**')):
        n = conn.execute('SELECT COUNT(*) FROM %s WHERE slot="TERM" AND hit=?'
                         % IT, (how,)).fetchone()[0]
        w('   %-16s %5d (%.0f%%)' % (nm, n, 100.0 * n / max(tot, 1)))
    w('   맞추지 못한 낱말 상위')
    for v, n in conn.execute(
            'SELECT value, COUNT(*) FROM %s WHERE slot="TERM" AND hit=""'
            ' GROUP BY 1 ORDER BY 2 DESC LIMIT 15' % IT):
        w('      %-14s %3d회' % (v, n))
    w()
    w('⑦ 곡·찬양팀 이름이 우리 명단에 있나')
    for slot, nm in (('SONG', '곡'), ('ARTI', '찬양팀')):
        t = conn.execute('SELECT COUNT(*) FROM %s WHERE slot=?' % IT,
                         (slot,)).fetchone()[0]
        h = conn.execute('SELECT COUNT(*) FROM %s WHERE slot=? AND hit<>""'
                         % IT, (slot,)).fetchone()[0]
        w('   %-6s 낸 것 %4d · 우리 명단에 있음 %4d (%.0f%%) · **새 이름 %d**'
          % (nm, t, h, 100.0 * h / max(t, 1), t - h))
    w()
    w('⑧ 실패')
    fc = Counter()
    for r in runs:
        if not r[2]:
            fc[(r[10] or '')[:40]] += 1
    if not fc:
        w('   없음')
    for k, n in fc.most_common(6):
        w('   %3d회  %s' % (n, k))
    txt = '\n'.join(L)
    if out_path:
        io.open(out_path, 'w', encoding='utf-8').write(txt)
    return txt


# ── 모델끼리 견주기 ─────────────────────────────────────────────────────────
def models_done(conn):
    """돌린 모델 → 편 수."""
    return conn.execute('SELECT COALESCE(model,""), COUNT(*), SUM(ok)'
                        ' FROM %s GROUP BY 1 ORDER BY 2 DESC' % T_RUN).fetchall()


def _items(conn, mid, model, slot):
    """그 모델이 그 편에서 낸 낱낱 → [(값, 맞춤, 번호)]."""
    q = ('SELECT value, hit, COALESCE(entity_id, vid) FROM %s'
         ' WHERE media_id=? AND COALESCE(model,"")=? AND slot=?' % T_ITEM)
    return conn.execute(q, (mid, model or '', slot)).fetchall()


def compare(conn, ma, mb, out_path=None, show=8):
    """두 모델을 같은 표본에서 견준다 → 글.

    ⚠ **같은 편만 센다** — 한쪽만 받은 편을 섞으면 수가 거짓이 된다.
    """
    ensure(conn)
    L = []

    def w(s=''):
        L.append(s)

    A = {r[0]: r for r in conn.execute(
        'SELECT media_id, grp, tok_in, tok_out, sec, kind, lyrics FROM %s'
        ' WHERE ok=1 AND COALESCE(model,"")=?' % T_RUN, (ma,))}
    B = {r[0]: r for r in conn.execute(
        'SELECT media_id, grp, tok_in, tok_out, sec, kind, lyrics FROM %s'
        ' WHERE ok=1 AND COALESCE(model,"")=?' % T_RUN, (mb,))}
    both = sorted(set(A) & set(B))
    w('=' * 74)
    w('모델 견주기 — A=%s  ↔  B=%s' % (ma, mb))
    w('  받은 편 A %d · B %d · **둘 다 %d편**(이 수로만 센다)'
      % (len(A), len(B), len(both)))
    if not both:
        return '\n'.join(L) + '\n둘 다 받은 편이 없다.'

    def cost(D):
        ti = sum(D[m][2] or 0 for m in both)
        to = sum(D[m][3] or 0 for m in both)
        sc = sum(D[m][4] or 0 for m in both)
        return ti, to, sc

    ai_, ao, asec = cost(A)
    bi, bo, bsec = cost(B)
    w()
    w('① 값·속도 (둘 다 받은 %d편)' % len(both))
    w('   %-26s 입력 %7d · 출력 %7d · %6.0f초 · 편당 %5.1f초'
      % (ma, ai_, ao, asec, asec / len(both)))
    w('   %-26s 입력 %7d · 출력 %7d · %6.0f초 · 편당 %5.1f초'
      % (mb, bi, bo, bsec, bsec / len(both)))
    w('   ⚠ 값은 모델마다 단가가 다르다 — 토큰 수만 여기 적는다.')
    w()
    w('② 영상 갈래 — 두 모델이 같게 보나')
    same = sum(1 for m in both if (A[m][5] or '') == (B[m][5] or ''))
    w('   같음 %d / %d (%.0f%%)' % (same, len(both), 100.0 * same / len(both)))
    diff = [m for m in both if (A[m][5] or '') != (B[m][5] or '')]
    for m in diff[:show]:
        t = conn.execute('SELECT title FROM sys_media_asset WHERE media_id=?',
                         (m,)).fetchone()
        w('   %-6d %-40s A:%-13s B:%s'
          % (m, ((t[0] if t else '') or '')[:40], A[m][5] or '?', B[m][5] or '?'))
    if len(diff) > show:
        w('   … 그 밖 %d편' % (len(diff) - show))
    w()
    w('③ 가사가 들었다고 본 편')
    w('   A %d · B %d' % (sum(1 for m in both if A[m][6]),
                          sum(1 for m in both if B[m][6])))
    w()
    for slot, nm in (('VERS', '구절'), ('TERM', '용어'), ('SONG', '곡'),
                     ('ARTI', '찬양팀')):
        na = nb2 = inter = onlya = onlyb = 0
        hita = hitb = 0
        for m in both:
            ia = _items(conn, m, ma, slot)
            ib = _items(conn, m, mb, slot)
            na += len(ia)
            nb2 += len(ib)
            hita += sum(1 for _v, h, _e in ia if h)
            hitb += sum(1 for _v, h, _e in ib if h)
            ka = set(_norm(v) for v, _h, _e in ia if v)
            kb = set(_norm(v) for v, _h, _e in ib if v)
            inter += len(ka & kb)
            onlya += len(ka - kb)
            onlyb += len(kb - ka)
        w('④-%s %s — A %d개 · B %d개' % (slot, nm, na, nb2))
        w('     낱말이 같은 것 %d · A 만 %d · B 만 %d · 겹침률 %.0f%%'
          % (inter, onlya, onlyb,
             100.0 * inter / max(inter + onlya + onlyb, 1)))
        w('     우리 자료에 맞은 것  A %d (%.0f%%) · B %d (%.0f%%)'
          % (hita, 100.0 * hita / max(na, 1), hitb, 100.0 * hitb / max(nb2, 1)))
    w()
    w('⑤ 규칙과의 겹침 — 어느 모델이 규칙에 더 가깝나')
    for slot, lt in (('VERS', 'VERS'), ('TERM', 'TERM')):
        line = []
        for mo in (ma, mb):
            b = r_only = a_only = 0
            for m in both:
                rv = set(t for t, st, _s in rule_links(conn, m)[lt]
                         if st == 'LIVE')
                av = set(e for _v, _h, e in _items(conn, m, mo, slot) if e)
                b += len(rv & av)
                r_only += len(rv - av)
                a_only += len(av - rv)
            line.append('%s: 둘 다 %d · 규칙만 %d · AI만 %d' % (mo[-14:], b, r_only, a_only))
        w('   [%s] %s' % (slot, '   |   '.join(line)))
    w()
    w('⑥ 사람이 뗀 짝을 다시 내나')
    for mo in (ma, mb):
        again = 0
        for m in both:
            hid = set(t for t, st, _s in rule_links(conn, m)['TERM'] if st == 'HIDE')
            hid |= set(t for t, st, _s in rule_links(conn, m)['VERS'] if st == 'HIDE')
            got = set()
            for slot in ('TERM', 'VERS'):
                got |= set(e for _v, _h, e in _items(conn, m, mo, slot) if e)
            again += len(hid & got)
        w('   %-26s %d건' % (mo, again))
    w()
    w('⑦ confidence 분포 — 변별력이 있나')
    for mo in (ma, mb):
        r = {}
        for cf, n in conn.execute(
                'SELECT COALESCE(conf,""), COUNT(*) FROM %s'
                ' WHERE COALESCE(model,"")=? GROUP BY 1' % T_ITEM, (mo,)):
            r[cf or '?'] = n
        w('   %-26s %s' % (mo, r))
    w()
    w('⑧ **오답 유형이 줄었나** — 1판에서 가른 다섯을 그대로 잰다')
    w('   유형                       %-22s %-22s' % (ma[-22:], mb[-22:]))

    def cnt(mo, slot, kinds=None, grp=None):
        n = 0
        for m in both:
            if kinds and (A if mo == ma else B)[m][5] not in kinds:
                continue
            if grp and (A if mo == ma else B)[m][1] != grp:
                continue
            n += len(_items(conn, m, mo, slot))
        return n

    rows = [
        ('E1 설교인데 용어를 낸다', 'TERM', ('SERMON',), None),
        ('E1 설교인데 곡을 낸다', 'SONG', ('SERMON',), None),
        ('E1 연주인데 용어를 낸다', 'TERM', ('INSTRUMENTAL',), None),
        ('E1 모음집인데 곡 판을 낸다', 'SONG', ('PLAYLIST',), None),
        ('E3 제목만인데 용어를 낸다', 'TERM', None, 'F'),
        ('E3 제목만인데 구절을 낸다', 'VERS', None, 'F'),
    ]
    for nm, slot, kinds, grp in rows:
        w('   %-26s %-22d %-22d' % (nm, cnt(ma, slot, kinds, grp),
                                    cnt(mb, slot, kinds, grp)))
    w('   %-26s %-22d %-22d' % ('E2 수록곡으로 가른 것', cnt(ma, 'TRACK'),
                                cnt(mb, 'TRACK')))
    w('   %-26s %-22d %-22d' % ('E2 남의 곡으로 가른 것', cnt(ma, 'OTHER'),
                                cnt(mb, 'OTHER')))
    w('   %-26s %-22d %-22d' % ('E2 설교 본문으로 가른 것', cnt(ma, 'SREF'),
                                cnt(mb, 'SREF')))

    def chan_copy(mo):
        same = tot = 0
        for m in both:
            ch = stored_desc(conn, m)[1]
            for v, _h, _e in _items(conn, m, mo, 'ARTI'):
                tot += 1
                if _norm(v) == _norm(ch):
                    same += 1
        return same, tot
    sa, ta = chan_copy(ma)
    sb, tb = chan_copy(mb)
    w('   %-26s %d/%d (%.0f%%)%-8s %d/%d (%.0f%%)'
      % ('E4 찬양팀 = 채널명 그대로', sa, ta, 100.0 * sa / max(ta, 1), '',
         sb, tb, 100.0 * sb / max(tb, 1)))
    # 갈래 밖 산출은 **비운 편 수**로도 본다(0이 되어야 옳다)
    for k in ('SERMON', 'INSTRUMENTAL'):
        la = sum(1 for m in both if A[m][5] == k and not _items(conn, m, ma, 'TERM'))
        na = sum(1 for m in both if A[m][5] == k)
        lb = sum(1 for m in both if B[m][5] == k and not _items(conn, m, mb, 'TERM'))
        nbk = sum(1 for m in both if B[m][5] == k)
        w('   %-26s %d/%d 편이 비웠다%-6s %d/%d 편이 비웠다'
          % ('   ' + k + ' 용어 비움', la, na, '', lb, nbk))
    w()
    w('⑨ 같은 편에서 판단이 갈린 표본 — 사람이 읽는다')
    shown = 0
    for m in both:
        if shown >= show:
            break
        ta = set(_norm(v) for v, _h, _e in _items(conn, m, ma, 'TERM'))
        tb = set(_norm(v) for v, _h, _e in _items(conn, m, mb, 'TERM'))
        if ta == tb:
            continue
        t = conn.execute('SELECT title FROM sys_media_asset WHERE media_id=?',
                         (m,)).fetchone()
        w('   [%d] %s' % (m, ((t[0] if t else '') or '')[:56]))
        w('      A: %s' % ' · '.join(v for v, _h, _e in _items(conn, m, ma, 'TERM')))
        w('      B: %s' % ' · '.join(v for v, _h, _e in _items(conn, m, mb, 'TERM')))
        shown += 1
    txt = '\n'.join(L)
    if out_path:
        io.open(out_path, 'w', encoding='utf-8').write(txt)
    return txt


# ── 자가검증 ───────────────────────────────────────────────────────────────
def selftest():
    import sqlite3
    n = ok = 0

    def ck(msg, cond, got=''):
        nonlocal n, ok
        n += 1
        if cond:
            ok += 1
            print('  OK   %s' % msg)
        else:
            print('  FAIL %s %s' % (msg, got))

    # ① 프롬프트
    p = build_prompt('제목', '채널', '설명문')
    ck('프롬프트에 분야 힌트가 든다', '하나님의 성품' in p)
    ck('프롬프트에 **용어 목록이 없다**', not has_term_list(p))
    ck('탐지력 — 목록을 넣으면 잡는다',
       has_term_list(p + '\n[용어 목록 191개]\n가 · 나'))
    ck('설명문이 비면 그렇다고 적는다', '(설명문 없음)' in build_prompt('t', 'c', ''))
    ck('설명문을 4000자로 끊는다', len(build_prompt('t', 'c', 'x' * 9000)) < 6000)

    # ② 파싱
    ck('순수 JSON 을 읽는다', (parse('{"kind":"SINGLE"}') or {}).get('kind') == 'SINGLE')
    ck('코드펜스를 견딘다',
       (parse('```json\n{"kind":"MEDLEY"}\n```') or {}).get('kind') == 'MEDLEY')
    ck('앞뒤 군더더기를 견딘다',
       (parse('답: {"kind":"X"} 끝') or {}).get('kind') == 'X')
    ck('못 읽으면 None', parse('그냥 글') is None)
    ck('빈 글이면 None', parse('') is None)

    # ③ 잘림 판정
    ck('「...」로 끝나면 잘린 것', is_cut('가나다...'))
    ck('「…」도 잡는다', is_cut('가나다…'))
    ck('온전한 글은 안 잡는다', not is_cut('가나다.'))
    ck('빈 글은 안 잡는다', not is_cut(''))

    # ④ 표본 SQL — 갈래마다 다른 조건이어야 한다
    sqls = {g: _sql_of(g) for g, _n in GROUPS}
    ck('갈래마다 다른 SQL', len(set(sqls.values())) == len(GROUPS))
    ck('F 는 짧은 설명문을 선택한다', 'LENGTH' in sqls['F'])
    ck('D 는 NOT EXISTS 로 선택한다', 'NOT EXISTS' in sqls['D'])
    ck('E 는 HIDE 를 본다', "'HIDE'" in sqls['E'])
    try:
        _sql_of('Z')
        ck('모르는 갈래를 거부한다', False)
    except ValueError:
        ck('모르는 갈래를 거부한다', True)

    # ⑤ 메모리 DB 로 표·저장·멱등
    c = sqlite3.connect(':memory:')
    c.execute('CREATE TABLE sys_media_asset(media_id INTEGER, media_type TEXT,'
              ' record_status TEXT, title TEXT, description TEXT, url TEXT,'
              ' is_active INT)')
    c.execute('CREATE TABLE sys_link_asset(link_type TEXT, clicked_id INT,'
              ' target_id INT, record_status TEXT, source TEXT)')
    c.execute('CREATE TABLE sys_text_asset(text_type TEXT, clicked_id INT,'
              ' lang_code TEXT, contents TEXT)')
    c.execute('CREATE TABLE sys_worship_artist(artist_id INT, record_status TEXT,'
              ' channel_name TEXT)')
    c.execute('CREATE TABLE sys_song_rendition(rend_id INT, song_id INT,'
              ' title_key TEXT)')
    c.execute('CREATE TABLE bible_index(verse_id INT, bcode INT, chapter INT,'
              ' verse INT)')
    c.execute('CREATE TABLE book_names(book_code INT, lang_code TEXT,'
              ' book_name TEXT, book_abbr TEXT)')
    ensure(c)
    ensure(c)
    ck('표 만들기가 멱등', True)
    c.execute("INSERT INTO sys_media_asset VALUES(1,'WORSHIP','LIVE','제목',"
              "'{\"yt_desc\":\"가사\",\"channel\":\"채널\"}','u',1)")
    # ⚠⚠ **A 갈래 조건을 실제로 만족시킨다** — 안 넣으면 `plan` 이 빈 목록을
    #   내고 「todo 에서 빠진다」가 **거짓으로 통과**한다(탐지력 0).
    c.execute("INSERT INTO sys_link_asset VALUES('MEDI_ENTI',1,7,'PEND',"
              "'DESC:Grace')")
    c.execute("INSERT INTO sys_text_asset VALUES('ENTITY_NAME',7,'KO','은혜')")
    c.execute("INSERT INTO sys_text_asset VALUES('ENTITY_NAME',8,'KO','간구 · 데에시스')")
    c.commit()
    ex, hd = term_index(c)
    ck('이름이 꼭 맞으면 EXACT', term_match('은혜', ex, hd) == (7, 'EXACT'))
    ck('앞 조각이 맞으면 HEAD', term_match('간구', ex, hd) == (8, 'HEAD'))
    ck('없으면 빈 표식', term_match('평안', ex, hd) == (None, ''))
    res = {'ok': True, 'text': '{}', 'tok': 10, 'out': 5, 'sec': 1.0,
           'code': 200, 'why': ''}
    d = {'kind': 'SINGLE', 'lyrics_in_desc': True,
         'songs': [{'title': '은혜', 'lang': 'KO'}],
         'artists': [{'name': '어떤팀', 'role': 'TEAM'}],
         'verses': [], 'terms': [{'word': '은혜', 'field': '구원'}]}
    idx = (ex, hd, {}, {}, {})
    save(c, 1, 'A', 'm', res, d, 2, 0, idx)
    n1 = c.execute('SELECT COUNT(*) FROM %s' % T_ITEM).fetchone()[0]
    save(c, 1, 'A', 'm', res, d, 2, 0, idx)
    n2 = c.execute('SELECT COUNT(*) FROM %s' % T_ITEM).fetchone()[0]
    ck('저장이 멱등(두 번 넣어도 안 는다)', n1 == n2 == 3, '%s/%s' % (n1, n2))
    ck('돌린 표에 한 줄', c.execute('SELECT COUNT(*) FROM %s' % T_RUN
                                 ).fetchone()[0] == 1)
    ck('용어를 우리 번호로 맞췄다',
       c.execute('SELECT entity_id FROM %s WHERE slot="TERM"' % T_ITEM
                 ).fetchone()[0] == 7)
    ck('받은 것은 todo 에서 빠진다',
       1 not in [m for _g, m in todo(c, (('A', 5),))])
    # ⑤-1b 모델 축 · 조용한 실패
    save(c, 1, 'A', 'other-model', res, d, 2, 0, idx)
    ck('모델이 다르면 줄이 하나 더 생긴다(덮지 않는다)',
       c.execute('SELECT COUNT(*) FROM %s WHERE media_id=1' % T_RUN
                 ).fetchone()[0] == 2)
    ck('낱낱도 모델마다 따로',
       c.execute('SELECT COUNT(DISTINCT model) FROM %s' % T_ITEM
                 ).fetchone()[0] == 2)
    ck('그 모델로 안 한 편은 todo 에 남는다',
       1 in [m for _g, m in todo(c, (('A', 5),), 'third-model')])
    ck('생각하는 모델은 출력 예산이 더 크다',
       maxout_of('gemini-3.5-flash') > maxout_of('gemini-3.1-flash-lite'))
    ck('모르는 모델은 기본 예산', maxout_of('아무거나') == MAXOUT_DEFAULT)
    # ★ **사용자 키를 먹지 않는다** — 관리자 키가 있으면 그것을 쓴다.
    src2 = io.open(__file__, encoding='utf-8').read().split('def selftest(')[0]
    ck('시험이 관리자 키를 먼저 본다', 'ai_client' in src2 and 'prefer_admin' in src2)

    # ⑤-1c 프롬프트 2판 — 갈래마다 낼 것을 못 박았나
    ck('v2 는 긴 설명문에 전문판', pick_ver('가' * 900, 'v2') == 'v2')
    ck('v2 는 짧은 설명문에 제목판', pick_ver('가' * 20, 'v2') == 'v2t')
    ck('v1 은 갈라지지 않는다', pick_ver('가' * 20, 'v1') == 'v1')
    pt = build_prompt('t', 'c', 'x' * 10, ver='v2t')
    ck('제목판에 구절·용어 칸이 **없다**',
       ('verses' not in pt) and ('terms' not in pt))
    ck('제목판이 꾸밈말 떼는 보기를 든다', 'Rest For My Soul' in pt)
    ck('제목판이 채널 베끼기를 막는다', '베끼지 않는다' in pt)
    p2 = build_prompt('t', 'c', 'x' * 900, ver='v2')
    ck('전문판이 SERMON 이면 곡·용어를 비우라 한다',
       'SERMON 이면' in p2 and 'sermon_refs' in p2)
    ck('전문판이 INSTRUMENTAL 이면 용어를 비우라 한다', 'INSTRUMENTAL 이면' in p2)
    ck('전문판이 수록곡을 tracks 로 가른다', 'tracks' in p2)
    ck('전문판이 남의 곡을 other_songs 로 가른다', 'other_songs' in p2)
    ck('전문판이 가사 근거를 why 에 적으라 한다', '가사 한 구절을 why' in p2)
    ck('전문판도 용어 목록은 안 싣는다', not has_term_list(p2))
    p3 = build_prompt('t', 'c', 'x' * 900, ver='v3')
    ck('3판은 약명을 한국어로 못 박는다', '약명은 반드시 한국어로' in p3)
    ck('3판은 중국어 약명 보기를 든다', '加 2:20' in p3)
    ck('3판은 제목 좌표를 반드시 적으라 한다', '제목·부제에 구절 좌표' in p3)
    ck('3판은 합창단 보기를 든다', 'CHOIR 다' in p3)
    ck('3판도 2판의 갈래 규칙을 그대로 지킨다',
       'SERMON 이면' in p3 and 'INSTRUMENTAL 이면' in p3 and 'tracks' in p3)
    ck('3판도 용어 목록은 안 싣는다', not has_term_list(p3))
    p3t = build_prompt('t', 'c', 'x' * 10, ver='v3t')
    ck('3판 제목판은 없는 곡을 막는다', '카메라 보면서 찬송가 치기' in p3t)
    ck('3판 제목판에도 구절·용어 칸이 없다',
       ('verses' not in p3t) and ('terms' not in p3t))
    ck('v3 도 재료를 보고 갈라 준다',
       pick_ver('가' * 20, 'v3') == 'v3t' and pick_ver('가' * 900, 'v3') == 'v3')
    ck('1판은 그대로 남아 있다(견주려면 둘이 필요하다)',
       '갈래를 먼저 정하고' not in build_prompt('t', 'c', 'x' * 900, ver='v1'))
    d2 = {'kind': 'PLAYLIST', 'songs': [], 'artists': [],
          'verses': [], 'terms': [],
          'tracks': [{'title': '어떤곡', 'lang': 'KO'}],
          'other_songs': [{'title': '남의곡', 'why': '크레딧'}],
          'sermon_refs': [{'ref': '시 1:1'}]}
    save(c, 1, 'A', 'm/v2', res, d2, 2, 0, idx, 'v2')
    got = dict(c.execute('SELECT slot, COUNT(*) FROM %s WHERE model="m/v2"'
                         ' GROUP BY 1' % T_ITEM).fetchall())
    ck('수록곡·남의곡·설교본문을 따로 담는다',
       got.get('TRACK') == 1 and got.get('OTHER') == 1 and got.get('SREF') == 1,
       str(got))
    ck('쓴 판을 적어 둔다',
       c.execute('SELECT pver FROM %s WHERE model="m/v2"' % T_RUN
                 ).fetchone()[0] == 'v2')

    # ⑤-2 채널 판정
    ck('채널 프롬프트에 갈래 다섯이 든다',
       all(k in CHAN_PROMPT for k in ('TEAM', 'SOLO', 'CHOIR', 'LABEL',
                                      'CHANNEL')))
    ck('채널 프롬프트가 「모르면 UNKNOWN」이라 한다', 'UNKNOWN' in CHAN_PROMPT)
    ck('채널 답 배열을 읽는다',
       len(chan_parse('[{"no":1,"name":"가"}]')) == 1)
    ck('채널 답 코드펜스를 견딘다',
       len(chan_parse('```json\n[{"no":1},{"no":2}]\n```')) == 2)
    ck('못 읽으면 빈 목록', chan_parse('그냥 글') == [])
    pool = chan_pool(c, 1)
    ck('실 표에서 채널 후보를 뽑는다(가짜 DB)',
       [x[0] for x in pool] == ['채널'], str(pool))
    ck('우리 분류기의 주 갈래를 함께 낸다', pool[0][3] == 'WOR', str(pool[0]))
    ck('프롬프트에 우리 분류 답을 안 싣는다',
       'WOR' not in CHAN_PROMPT.split('[채널 목록]')[1])
    ck('채널 프롬프트가 교회·QT 를 가른다',
       'CHURCH' in CHAN_PROMPT and 'QT' in CHAN_PROMPT)
    ck('채널 프롬프트가 「예배」 낱말 함정을 말한다',
       '목요예배' in CHAN_PROMPT)
    ck('채널 프롬프트가 주 갈래를 묻는다',
       all(k in CHAN_PROMPT for k in CHAN_MAIN))
    c.execute('INSERT INTO %s(chan,n_vid,name,kind,main,pver)'
              ' VALUES("채널",1,"가","TEAM","WOR",?)' % T_CHAN, (CHAN_PVER,))
    c.commit()
    ck('담은 채널은 chan_todo 에서 빠진다', chan_todo(c, 1) == [])
    ck('판이 오르면 다시 돈다', len(chan_todo(c, 1, 'c9')) == 1)
    ck('채널 요약이 글을 낸다', '찬양팀' in chan_report(c))
    c.close()

    # ⑥ 배포 표를 안 건드린다 — 실 DB 로 잰다
    try:
        rc = appdb.connect()
        before = [rc.execute('SELECT COUNT(*) FROM ' + t).fetchone()[0]
                  for t in ('sys_media_asset', 'sys_link_asset', 'sys_text_asset')]
        ensure(rc)
        pl = plan(rc, (('A', 3), ('D', 3)))
        ck('실 DB 에서 표본이 뽑힌다', len(pl) >= 1, str(len(pl)))
        ck('한 편이 두 갈래에 겹치지 않는다',
           len(set(m for _g, m in pl)) == len(pl))
        after = [rc.execute('SELECT COUNT(*) FROM ' + t).fetchone()[0]
                 for t in ('sys_media_asset', 'sys_link_asset', 'sys_text_asset')]
        ck('**배포 표 행수 불변**', before == after, '%s → %s' % (before, after))
        # ⚠⚠ **제 규칙을 글자로 재면 규칙을 적은 줄이 늘 걸린다**(§292차 ⑨) —
        #   낱말을 **조립**해서 이 파일에 그 글자가 통째로 안 남게 한다.
        # ⚠ **재는 것은 「돌리는 길」이다** — 이 selftest 는 **메모리 DB** 에
        #   가짜 `sys_*` 를 만들어 넣으므로 그 줄까지 세면 늘 걸린다.
        #   ⇒ `def selftest(` **앞까지**만 본다(살아 있는 코드가 잣대다).
        src = io.open(__file__, encoding='utf-8').read()
        live = src.split('def selftest(')[0]
        pat = ('(' + 'INS' + 'ERT|UPD' + 'ATE|DEL' + 'ETE)'
               + r'[^\n]{0,40}\bsys_')
        hit = re.search(pat, live)
        ck('돌리는 길에 배포 표 쓰기가 없다', not hit,
           (hit.group(0) if hit else '')[:60])
        ck('탐지력 — 있으면 잡는다',
           bool(re.search(pat, 'x\nDEL' + 'ETE FROM sys_link_asset WHERE 1\n')))
        rc.close()
    except Exception as e:
        ck('실 DB 검사', False, str(e)[:100])

    print('\n  %d/%d' % (ok, n))
    return ok == n


# ── CLI ────────────────────────────────────────────────────────────────────
def _log(s):
    print(s)
    sys.stdout.flush()


def main(argv):
    if '--selftest' in argv:
        return 0 if selftest() else 1
    conn = appdb.connect()
    ensure(conn)
    try:
        if '--undo' in argv:
            wipe(conn)
            print('시험 표를 비웠다 — 배포 표는 안 건드렸다.')
            return 0
        if '--plan' in argv:
            pl = plan(conn)
            print('표본 %d편 (한 바이트도 안 보냈다)' % len(pl))
            from collections import Counter
            for g, k in Counter(g for g, _m in pl).most_common():
                print('  %s  %3d편' % (g, k))
            d = todo(conn)
            print('아직 안 보낸 것 %d편' % len(d))
            cut = full = 0
            for _g, m in pl:
                s, f = best_desc(conn, m)
                full += f
                cut += 1 if is_cut(s) else 0
            print('  그중 전문을 이미 받은 것 %d · 잘린 채인 것 %d' % (full, cut))
            return 0
        if '--fulldesc' in argv:
            i = argv.index('--fulldesc')
            n = int(argv[i + 1]) if len(argv) > i + 1 and argv[i + 1].isdigit() else 200
            mids = [m for _g, m in plan(conn)][:n]
            got = fetch_full(conn, mids, on_log=_log)
            print('설명문 전문 %d편 담았다 (배포 표는 안 건드렸다).' % got)
            return 0
        if '--run' in argv:
            i = argv.index('--run')
            n = int(argv[i + 1]) if len(argv) > i + 1 and argv[i + 1].isdigit() else 20
            model = None
            if '--model' in argv:
                model = argv[argv.index('--model') + 1]
            ver = 'v1'
            if '--ver' in argv:
                ver = argv[argv.index('--ver') + 1]
            r = run(conn, n, model=model, on_log=_log, ver=ver)
            print('보냄 %d · 받음 %d · 남은 표본 %d · 모델 %s'
                  % (r['sent'], r['ok'], r.get('left', -1), r.get('model', '')))
            if r['why']:
                print('멈춘 사유: %s' % r['why'][:200])
            return 0
        if '--chan' in argv:
            i = argv.index('--chan')
            n = int(argv[i + 1]) if len(argv) > i + 1 and argv[i + 1].isdigit() else 60
            model = None
            if '--model' in argv:
                model = argv[argv.index('--model') + 1]
            bn = None
            if '--batch' in argv:
                bn = int(argv[argv.index('--batch') + 1])
            r = run_chan(conn, n, model=model, on_log=_log, batch_n=bn)
            print('채널 보냄 %d · 담음 %d · 남은 곳 %d · 모델 %s'
                  % (r['sent'], r['ok'], r.get('left', -1), r.get('model', '')))
            if r['why']:
                print('멈춘 사유: %s' % r['why'][:200])
            return 0
        if '--models' in argv:
            for m, n, k in models_done(conn):
                print('  %-28s %4d편 (받음 %s)' % (m or '(없음)', n, k or 0))
            return 0
        if '--compare' in argv:
            i = argv.index('--compare')
            ms = [x for x in argv[i + 1:i + 3] if not x.startswith('--')]
            if len(ms) < 2:
                done = [m for m, _n, _k in models_done(conn) if m]
                if len(done) < 2:
                    print('견줄 모델이 둘 있어야 한다 — `--models` 로 본다.')
                    return 1
                ms = done[:2]
            p = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             '_ai_worship_cmp.txt')
            print(compare(conn, ms[0], ms[1], p))
            print('\n(같은 글을 %s 에 적었다)' % p)
            return 0
        if '--chan-report' in argv:
            q = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             '_ai_chan.txt')
            print(chan_report(conn, q))
            print('\n(같은 글을 %s 에 적었다)' % q)
            return 0
        if '--chan-plan' in argv:
            pool = chan_pool(conn)
            print('영상 3편 이상 채널 %d곳 (한 바이트도 안 보냈다)'
                  % len(pool))
            for nm, k, _t in pool[:15]:
                print('   %-44s %4d편' % (nm[:44], k))
            print('아직 안 보낸 곳 %d' % len(chan_todo(conn)))
            return 0
        if '--report' in argv:
            p = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             '_ai_worship_test.txt')
            print(report(conn, p))
            print('\n(같은 글을 %s 에 적었다)' % p)
            return 0
        print(__doc__)
        return 0
    finally:
        conn.close()


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
