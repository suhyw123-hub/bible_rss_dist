# -*- coding: utf-8 -*-
"""성지순례 도로 — 장소 사이 도로 거리 · 시간 · 선 모양을 미리 계산해 둔다(2026-10-28 docs/1.txt 9).

★ 사용자 결정 — 「외부 서비스로 계산하고 지도에 반영하고 차이가 있는지 눈으로 확인하고 PC 로 다시 계산해보자」.
  두 방법으로 서로 검증한다 — 출처 칸 `src` 가 가른다:
    OSRM_DEMO  공개 OSRM 서버(router.project-osrm.org) · 키 없음 · 이용 규칙대로 1초에 한 건
    GH_PC      이 PC 의 GraphHopper(localhost:8989 · 같은 쌍을 다시 재서 견준다 · Docker 가 없어 OSRM 대신 — 엔진이 달라 교차 검증이 더 세다)
★ 폰은 망을 쓰지 않는다 — 결과만 공통 팩(sys_place_road)에 실린다. 사용자 정보는 어디로도 안 나간다.
★ 대상 = 순례 지역(유다 · 사마리아 · 갈릴리 · 요단 동편 · 시내 · 이집트)의 좌표 있는 장소.
    거리·시간 = 전부(표 계산 한 번) · 선 모양 = 직선 [GEO_KM]km 안의 쌍만(멀리 떨어진 쌍은 순례에서 잇지 않는다).
⚠ 표기 — 「© OpenStreetMap 기여자」(도로 원자료) · 공개 서버 결과는 시험·검증용이다(대량 사용 금지 — 1초 한 건 · 한 번만).

  python db_place_road.py --selftest | --plan | --table | --geo [--limit N] | --pc | --status | --diff
"""
import json
import math
import sys
import time
import urllib.error
import urllib.request

import appdb

SRC_DEMO = 'OSRM_DEMO'
SRC_PC = 'GH_PC'
GH = 'http://127.0.0.1:8989'
GH2 = 'http://127.0.0.1:8991'   # ★ 2026-10-29 튀르키예·그리스 엔진(도로엔진 켜기 - 튀르키예 그리스.cmd)   # ⚠ localhost 는 IPv6 를 먼저 잡아 연결마다 멎었다(2026-10-28)
REGIONS = ('JUDEA', 'SAMARIA', 'GALILEE', 'TRANSJORDAN', 'SINAI', 'EGYPT')
#: ★ 2026-10-29 튀르키예·그리스 권역 — 비행기로 잇는 따로 된 권역 · 도로는 둘째 엔진(GH2 · 튀르키예+그리스 지도)
#:   시리아 갈래 가운데 안디옥(안타키아)은 지금 튀르키예 땅이라 이 권역(북위 35.8 넘는 곳)
AEGEAN = ('ASIA_MINOR', 'GREECE')
GEO_KM = 100.0
DEMO = 'https://router.project-osrm.org'
UA = 'HagahDabar/1.0 (pilgrimage route precompute; contact via app)'

DDL = """CREATE TABLE IF NOT EXISTS sys_place_road (
    a_id INTEGER NOT NULL, b_id INTEGER NOT NULL, src TEXT NOT NULL,
    km REAL, minutes REAL, poly TEXT, made_at TEXT,
    PRIMARY KEY (a_id, b_id, src))"""


def ensure(conn):
    conn.execute(DDL)


def in_aegean(region, lat):
    return region in AEGEAN or (region == 'SYRIA' and lat > 35.8)


def engine_of(lat, lng):
    """그 좌표를 재는 엔진 — 북위 34.5 넘고 동경 45 안(튀르키예·그리스) = GH2 · 그 밖 = GH(이스라엘·요르단·이집트)"""
    return GH2 if lat >= 34.5 and lng < 45 else GH


def places(conn, regions='HOLY'):
    """순례 지역의 좌표 있는 장소 → [(번호, 위도, 경도, 지역)] (번호 차례)
    regions = 'HOLY'(이스라엘·요르단·이집트 · 옛 규칙) · 'AEGEAN'(튀르키예·그리스) · 'ALL'(둘 다)"""
    out = []
    for i, lat, lng, j in conn.execute(
            "SELECT entity_id, geo_lat, geo_lng, json_detail FROM sys_entity_master WHERE entity_type='PLACE'"
            " AND geo_lat IS NOT NULL AND geo_lng IS NOT NULL AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY entity_id"):
        try:
            r = (json.loads(j or '{}') or {}).get('region_code') or ''
        except ValueError:
            r = ''
        holy, aeg = r in REGIONS, in_aegean(r, float(lat))
        if (regions in ('HOLY', 'ALL') and holy) or (regions in ('AEGEAN', 'ALL') and aeg):
            out.append((i, float(lat), float(lng), r))
    # 같은 번호가 두 줄이면 하나만
    seen, uniq = set(), []
    for p in out:
        if p[0] not in seen:
            seen.add(p[0])
            uniq.append(p)
    return uniq


def km(a, b):
    r = 6371.0
    d1, d2 = math.radians(b[1] - a[1]), math.radians(b[2] - a[2])
    x = math.sin(d1 / 2) ** 2 + math.cos(math.radians(a[1])) * math.cos(math.radians(b[1])) * math.sin(d2 / 2) ** 2
    return 2 * r * math.asin(min(1.0, math.sqrt(x)))


def geo_pairs(ps, lim=GEO_KM):
    return [(ps[i], ps[k]) for i in range(len(ps)) for k in range(i + 1, len(ps)) if km(ps[i], ps[k]) <= lim]


def _get(url, timeout=60):
    req = urllib.request.Request(url, headers={'User-Agent': UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode('utf-8'))


def _now():
    return time.strftime('%Y-%m-%d %H:%M:%S')


def _put(conn, a, b, src, km_, mins, poly=None):
    a, b = (a, b) if a < b else (b, a)
    row = conn.execute('SELECT poly FROM sys_place_road WHERE a_id=? AND b_id=? AND src=?', (a, b, src)).fetchone()
    if row:
        conn.execute('UPDATE sys_place_road SET km=?, minutes=?, poly=COALESCE(?, poly), made_at=? WHERE a_id=? AND b_id=? AND src=?',
                     (km_, mins, poly, _now(), a, b, src))
    else:
        conn.execute('INSERT INTO sys_place_road(a_id, b_id, src, km, minutes, poly, made_at) VALUES(?,?,?,?,?,?,?)',
                     (a, b, src, km_, mins, poly, _now()))


def parse_table(d, ids):
    """OSRM table 답 → [(a, b, km, 분)] (a<b · 길이 없는 쌍은 뺀다)"""
    if d.get('code') != 'Ok':
        raise ValueError(d.get('code') or 'no code')
    dist, dur = d.get('distances') or [], d.get('durations') or []
    out = []
    for i in range(len(ids)):
        for k in range(i + 1, len(ids)):
            m = dist[i][k] if i < len(dist) and k < len(dist[i]) else None
            s = dur[i][k] if i < len(dur) and k < len(dur[i]) else None
            if m is None or s is None:
                continue
            out.append((ids[i], ids[k], round(m / 1000.0, 2), round(s / 60.0, 1)))
    return out


def table(conn, base=DEMO, src=SRC_DEMO):
    """거리·시간 표 — 한 번에(공개 서버 표 한도 100곳)"""
    ensure(conn)
    ps = places(conn)
    coords = ';'.join('%.6f,%.6f' % (p[2], p[1]) for p in ps)
    d = _get('%s/table/v1/driving/%s?annotations=distance,duration' % (base, coords), timeout=120)
    rows = parse_table(d, [p[0] for p in ps])
    for a, b, k_, m_ in rows:
        _put(conn, a, b, src, k_, m_)
    conn.commit()
    return len(ps), len(rows)


def geo(conn, base=DEMO, src=SRC_DEMO, limit=None, pause=1.05, say=print):
    """선 모양 — 아직 없는 쌍만(멈췄다 다시 돌리면 이어서) · 1초 한 건"""
    ensure(conn)
    ps = places(conn)
    todo = []
    for a, b in geo_pairs(ps):
        x, y = (a, b) if a[0] < b[0] else (b, a)
        r = conn.execute('SELECT poly FROM sys_place_road WHERE a_id=? AND b_id=? AND src=?', (x[0], y[0], src)).fetchone()
        if not r or not r[0]:
            todo.append((x, y))
    if limit:
        todo = todo[:limit]
    ok = fail = 0
    for n, (a, b) in enumerate(todo, 1):
        url = '%s/route/v1/driving/%.6f,%.6f;%.6f,%.6f?overview=simplified&geometries=polyline' % (base, a[2], a[1], b[2], b[1])
        try:
            d = _get(url)
            if d.get('code') == 'Ok' and d.get('routes'):
                r = d['routes'][0]
                _put(conn, a[0], b[0], src, round(r['distance'] / 1000.0, 2), round(r['duration'] / 60.0, 1), r.get('geometry') or '')
                ok += 1
            else:
                fail += 1
        except Exception as e:                            # noqa: BLE001
            fail += 1
            say('  실패 %d-%d %s' % (a[0], b[0], str(e)[:80]))
            time.sleep(5)
        conn.commit()       # ⚠ 쉬는 동안 쓰기 잠금을 쥐지 않는다(다른 계산이 막혀 조용히 실패했다 · 2026-10-28)
        if n % 50 == 0:
            say('  %d/%d (받음 %d · 실패 %d)' % (n, len(todo), ok, fail))
        time.sleep(pause)
    conn.commit()
    return len(todo), ok, fail


_SNAP = {}


def snap(p, base=DEMO):
    """길에서 먼 좌표(바다 · 산꼭대기 · 광야) → 가장 가까운 길 위 좌표(공개 OSRM nearest · 장소마다 한 번 · 기억).
    GraphHopper 가 그런 점을 「Cannot find point」(400)로 거절한다 — 엔진 설정을 안 바꾸고 여기서 푼다."""
    if p[0] in _SNAP:
        return _SNAP[p[0]]
    out = p
    try:
        d = _get('%s/nearest/v1/driving/%.6f,%.6f?number=1' % (base, p[2], p[1]), timeout=30)
        w = (d.get('waypoints') or [None])[0]
        if w and w.get('location'):
            out = (p[0], float(w['location'][1]), float(w['location'][0])) + tuple(p[3:])
        time.sleep(1.05)
    except Exception:                                     # noqa: BLE001
        pass
    _SNAP[p[0]] = out
    return out


def _gh_path(base, pa, pb, line):
    url = ('%s/route?point=%.6f,%.6f&point=%.6f,%.6f&profile=car&points_encoded=true&calc_points=%s'
           % (base, pa[1], pa[2], pb[1], pb[2], 'true' if line else 'false'))
    return (_get(url, timeout=30).get('paths') or [None])[0]


def pc_all(conn, base=GH, say=print, redo=False):
    """이 PC 의 GraphHopper 로 외부 계산과 **같은 쌍 전부**(거리·시간 4천여 쌍 · 선은 직선 GEO_KM 안의 쌍) — 쉼 없이(이 PC 안)."""
    ensure(conn)
    ps = {p[0]: p for p in places(conn)}
    rows = [(a, b, km(ps[a], ps[b]) <= GEO_KM) for a, b in conn.execute(
        'SELECT a_id, b_id FROM sys_place_road WHERE src=?', (SRC_DEMO,)).fetchall() if a in ps and b in ps]
    if not redo:                                  # 이미 잰 쌍은 건너뛴다(멈췄다 다시 돌리면 이어서)
        have = set(conn.execute('SELECT a_id, b_id FROM sys_place_road WHERE src=?', (SRC_PC,)).fetchall())
        rows = [r for r in rows if (r[0], r[1]) not in have]
    ok = fail = 0
    for n, (a, b, want_line) in enumerate(rows, 1):
        pa, pb = ps.get(a), ps.get(b)
        if not pa or not pb:
            continue
        try:
            try:
                path = _gh_path(base, pa, pb, want_line)
            except urllib.error.HTTPError as e:
                if e.code != 400:
                    raise
                path = _gh_path(base, snap(pa), snap(pb), want_line)   # 길에서 먼 점 → 가까운 길로
            if path:
                _put(conn, a, b, SRC_PC, round(path['distance'] / 1000.0, 2), round(path['time'] / 60000.0, 1),
                     path.get('points') if want_line else None)
                ok += 1
            else:
                fail += 1
        except Exception:                                 # noqa: BLE001
            fail += 1
        if n % 50 == 0:
            conn.commit()
        if n % 500 == 0:
            say('  %d/%d (받음 %d · 실패 %d)' % (n, len(rows), ok, fail))
    conn.commit()
    return len(rows), ok, fail


def decode(poly):
    """구글 polyline(정밀도 5) → [(위도, 경도)] — 시험·견주기용(폰은 Dart 로 같은 것을 한다)"""
    out, i, lat, lng = [], 0, 0, 0
    while i < len(poly):
        vals = []
        for _ in range(2):
            shift = res = 0
            while True:
                b = ord(poly[i]) - 63
                i += 1
                res |= (b & 0x1f) << shift
                shift += 5
                if b < 0x20:
                    break
            vals.append(~(res >> 1) if res & 1 else res >> 1)
        lat += vals[0]
        lng += vals[1]
        out.append((lat / 1e5, lng / 1e5))
    return out


def encode(pts):
    """[(위도, 경도)] → 구글 polyline(정밀도 5) — decode 의 거꾸로."""
    out, plat, plng = [], 0, 0
    for la, ln in pts:
        ila, iln = int(round(la * 1e5)), int(round(ln * 1e5))
        for v in (ila - plat, iln - plng):
            v = ~(v << 1) if v < 0 else (v << 1)
            while v >= 0x20:
                out.append(chr((0x20 | (v & 0x1f)) + 63))
                v >>= 5
            out.append(chr(v + 63))
        plat, plng = ila, iln
    return ''.join(out)


def simplify(pts, tol_deg=0.0003):
    """Douglas-Peucker — 화면에서 안 보일 만큼(기본 0.0003도 ≈ 30m) 꺾임만 덜어 낸다 · 양 끝은 늘 남는다."""
    if len(pts) < 3:
        return list(pts)
    keep = [False] * len(pts)
    keep[0] = keep[-1] = True
    stack = [(0, len(pts) - 1)]
    while stack:
        a, b = stack.pop()
        (ya, xa), (yb, xb) = pts[a], pts[b]
        dx, dy = xb - xa, yb - ya
        nn = (dx * dx + dy * dy) ** 0.5 or 1e-12
        best, bi = -1.0, -1
        for i in range(a + 1, b):
            y, x = pts[i]
            d = abs(dy * (x - xa) - dx * (y - ya)) / nn
            if d > best:
                best, bi = d, i
        if best > tol_deg:
            keep[bi] = True
            stack += [(a, bi), (bi, b)]
    return [p for p, k in zip(pts, keep) if k]


def slim(conn, src=SRC_PC, tol_deg=0.0003):
    """★ 2026-10-29 길 모양을 덜어 낸다(제자리) — 옛 모양은 temp_road_poly_backup 에(처음 한 번) · → (줄 수, 전 바이트, 후 바이트)."""
    ensure(conn)
    conn.execute('CREATE TABLE IF NOT EXISTS temp_road_poly_backup(a_id INTEGER, b_id INTEGER, src TEXT, poly TEXT,'
                 ' PRIMARY KEY(a_id, b_id, src))')
    n = before = after = 0
    for a, b, p in conn.execute("SELECT a_id, b_id, poly FROM sys_place_road WHERE src=? AND COALESCE(poly,'')<>''",
                                (src,)).fetchall():
        conn.execute('INSERT OR IGNORE INTO temp_road_poly_backup VALUES(?,?,?,?)', (a, b, src, p))
        q = encode(simplify(decode(p), tol_deg))
        before += len(p)
        after += len(q)
        if q != p:
            conn.execute('UPDATE sys_place_road SET poly=? WHERE a_id=? AND b_id=? AND src=?', (q, a, b, src))
            n += 1
    conn.commit()
    return n, before, after


def status(conn):
    ensure(conn)
    for src, n, ng in conn.execute("SELECT src, COUNT(*), SUM(CASE WHEN COALESCE(poly,'')<>'' THEN 1 ELSE 0 END)"
                                   " FROM sys_place_road GROUP BY src"):
        print('%s  쌍 %d · 선 %d' % (src, n, ng or 0))


def diff(conn, top=20):
    """두 출처가 다른 쌍 — 거리 차이가 큰 차례"""
    rows = conn.execute(
        "SELECT a.a_id, a.b_id, a.km, b.km, a.minutes, b.minutes FROM sys_place_road a JOIN sys_place_road b"
        " ON a.a_id=b.a_id AND a.b_id=b.b_id AND a.src=? AND b.src=?", (SRC_DEMO, SRC_PC)).fetchall()
    rows.sort(key=lambda r: -abs((r[2] or 0) - (r[3] or 0)))
    for r in rows[:top]:
        print('%d-%d  외부 %.1fkm %.0f분 · PC %.1fkm %.0f분' % (r[0], r[1], r[2] or 0, r[4] or 0, r[3] or 0, r[5] or 0))
    return rows


def selftest():
    ok, fails = 0, []

    def ck(c, m):
        nonlocal ok
        if c:
            ok += 1
        else:
            fails.append(m)

    ck(encode(decode('_p~iF~ps|U_ulLnnqC_mqNvxq`@')) == '_p~iF~ps|U_ulLnnqC_mqNvxq`@', 'polyline 짓기 = 풀기의 거꾸로')
    _ln = [(31.0, 35.0), (31.00001, 35.5), (31.0, 36.0), (31.5, 36.0)]
    ck(simplify(_ln) == [(31.0, 35.0), (31.0, 36.0), (31.5, 36.0)], '덜기 — 곧은 줄 가운데 점은 빠지고 꺾인 점은 남는다')
    ck(decode('_p~iF~ps|U_ulLnnqC_mqNvxq`@') == [(38.5, -120.2), (40.7, -120.95), (43.252, -126.453)], 'polyline 풀기(구글 예제)')
    d = {'code': 'Ok', 'distances': [[0, 1000, 2500], [1000, 0, None], [2500, 1500, 0]],
         'durations': [[0, 60, 150], [60, 0, None], [150, 90, 0]]}
    rows = parse_table(d, [5, 7, 9])
    ck(rows == [(5, 7, 1.0, 1.0), (5, 9, 2.5, 2.5)], '표 읽기(길 없는 쌍 뺌) %s' % rows)
    import sqlite3
    c = sqlite3.connect(':memory:')
    ensure(c)
    _put(c, 9, 5, SRC_DEMO, 2.5, 3.0)
    _put(c, 5, 9, SRC_DEMO, 2.6, 3.1, 'abc')
    r = c.execute('SELECT a_id, b_id, km, poly FROM sys_place_road').fetchall()
    ck(r == [(5, 9, 2.6, 'abc')], '쌍은 작은 번호 앞 · 다시 넣으면 갈아 끼움 %s' % r)
    _put(c, 5, 9, SRC_DEMO, 2.7, 3.2)
    ck(c.execute('SELECT poly FROM sys_place_road').fetchone()[0] == 'abc', '선 없이 다시 넣어도 선은 남는다')
    conn = appdb.connect('bible_master.db')
    ps = places(conn)
    ck(len(ps) > 60 and all(p[3] in REGIONS for p in ps), '순례 지역 장소 %d' % len(ps))
    ck(len({p[0] for p in ps}) == len(ps), '장소 번호 겹침 없음')
    for m in fails:
        print('  FAIL', m)
    print('db_place_road selftest %d/%d' % (ok, ok + len(fails)))
    return not fails


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect('bible_master.db')
    ensure(conn)
    if '--plan' in a:
        ps = places(conn)
        print('장소 %d · 선 받을 쌍 %d(직선 %dkm 안)' % (len(ps), len(geo_pairs(ps)), GEO_KM))
    elif '--table' in a:
        print('표: 장소 %d · 쌍 %d' % table(conn))
    elif '--geo' in a:
        lim = int(a[a.index('--limit') + 1]) if '--limit' in a else None
        print('선: 할 것 %d · 받음 %d · 실패 %d' % geo(conn, limit=lim))
    elif '--pc' in a:
        print('PC: 쌍 %d · 받음 %d · 실패 %d' % pc_all(conn))
    elif '--diff' in a:
        diff(conn)
    elif '--slim' in a:                               # ★ 2026-10-29 길 모양 덜기(≈30m) — 폰 공통팩 3.3 → 0.5 MB
        print('덜어 냄: 줄 %d · %d → %d 글자' % slim(conn))
    status(conn)


if __name__ == '__main__':
    main()
