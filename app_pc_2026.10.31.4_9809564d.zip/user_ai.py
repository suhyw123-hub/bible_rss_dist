# -*- coding: utf-8 -*-
"""user_ai — 사용자의 AI 대화 (2026-09-29 298차 · `docs/1.txt` 3번).

사용자 확정(2026-09-29): 「**완전히 사용자만의 기능이다. sys 데이터에 저장하는 것은 아무것도
없어야 한다.** 대화식으로 구성하는 것도 중요하고 이런 대화를 **하나의 텍스트로 통합**할 수
있도록 하는 기능도 필요하다. 교단중립 등은 **사용자가 프롬프트를 통해서 결정**할 사항이다.
**프롬프트 예제(다국어)가 매우 중요**하다. 구절 하나를 클릭하고 AI 버튼을 누르면 **구절
구간으로 확장**할 수도 있어야 한다. 구절 하나 선택하고 진행하면 이어지는 모든 대화는 그
구절을 중심으로 **하나의 자산**으로 취급해야 한다. 성경교사 기능에서 AI 가 먼저 주어진
재료와 프롬프트에 따라서 적절하게 질문하는 것이 가능한 것으로 이해하겠다.」

★★★ 규칙
· **쓰는 표는 전부 `userdb`**(`user_ai_chat` · `user_ai_msg` · `user_ai_prompt`) — 배포 DB
  (`sys_*`)에는 한 줄도 안 쓴다. selftest 가 sys 표 행수 불변을 잰다(§C-2).
· **키는 사용자 것** — `user_config['AI_KEY']`. 배포 꾸러미·코어팩·양식에 실리지 않는다
  (`db_dist_build.SEED_CFG` 허용 목록에 없다 — 허용 목록이라 새 열쇠는 저절로 빠진다).
· **대화 = 자산 하나** — 닻(구절 또는 구간)에 매인 `user_ai_chat` 한 줄에 메시지가 쌓인다.
  합치면(`merge_text`) 한 편의 글이 되고 「내 자료」(`user_ref_asset`)로 담을 수 있다.
· **프롬프트는 사용자 것** — 씨앗(`SEED_PROMPTS` 11언어)은 없는 것만 채우고 사람이 고친
  줄은 안 덮는다. 교단 중립 같은 규칙을 코드가 강제하지 않는다(사용자 지시).
· 어댑터 셋 — Gemini · OpenAI 호환(GPT·Grok(xAI)) · Anthropic. 예외를 밖으로 안 던진다
  (`{ok, text, why, tokens}`). 망이 없으면 「지금은 앱 안의 자료로」 물러선다.
· 재료(`materials`)는 **sys 를 읽기만** 한다 — 본문·단락·앞뒤 절·주요용어.
"""
import io
import re
import json
import ssl
import time
import urllib.request

import appdb

NL = chr(10)

PROVIDERS = [
    # (열쇠, 이름, 기본 모델, 키 받는 곳, 후보 모델)
    # ★ 후보는 **본보기**다(2026-09-29 299차-3 · 사용자 「flash-lite 를 쓰는데 2.5 flash 가 박혀
    #   404 · 사용자 환경에 따라 다양한 상황에 대비」). 어느 키가 어느 모델을 쓸 수 있는지는 회사·
    #   등급·지역·날짜마다 다르므로 여기 적은 이름이 그 사람 키에서 404 일 수 있다. **정답은
    #   `list_models`** — 그 키로 서버에 물어 실제로 쓸 수 있는 이름을 받아 온다.
    # ★ Gemini 기본은 **별칭**(2026-09-29 실측) — 새 키로 `gemini-2.5-flash`·`-lite` 를 부르면
    #   HTTP 404 「no longer available to new users … use gemini-3.8-flash / gemini-3.5-flash-lite」.
    #   판 번호를 박으면 구글이 물릴 때마다 그 사용자가 404 를 본다. `gemini-flash-lite-latest` 는
    #   그날도 정상이었다(사용자가 쓰는 갈래가 flash-lite 다).
    ('GEMINI', 'Google Gemini', 'gemini-flash-lite-latest', 'https://aistudio.google.com/apikey',
     ['gemini-flash-lite-latest', 'gemini-flash-latest', 'gemini-pro-latest',
      'gemini-3.5-flash-lite', 'gemini-3.8-flash', 'gemini-3.1-pro-preview']),
    ('OPENAI', 'OpenAI (GPT)', 'gpt-4o-mini', 'https://platform.openai.com/api-keys',
     ['gpt-4o-mini', 'gpt-4o', 'gpt-4.1-mini', 'gpt-4.1', 'gpt-5-mini', 'gpt-5']),
    ('XAI', 'xAI (Grok)', 'grok-3-mini', 'https://console.x.ai',
     ['grok-3-mini', 'grok-3', 'grok-4']),
    ('ANTHROPIC', 'Anthropic (Claude)', 'claude-sonnet-5', 'https://console.anthropic.com',
     ['claude-sonnet-5', 'claude-opus-5', 'claude-haiku-4-5-20251001']),
]
PROVIDER = {p[0]: {'name': p[1], 'model': p[2], 'url': p[3], 'models': list(p[4])} for p in PROVIDERS}

#: 물린 모델 이름 → 살아 있는 별칭(읽을 때 옮긴다 · 저장값은 다음 저장 때 따라간다).
#  298차 기본값 `gemini-2.5-flash` 를 그대로 들고 있는 사람이 새 키를 넣으면 404 만 본다.
MODEL_ALIAS = {
    'gemini-2.5-flash': 'gemini-flash-latest',
    'gemini-2.5-flash-lite': 'gemini-flash-lite-latest',
    'gemini-2.5-pro': 'gemini-pro-latest',
    'gemini-2.0-flash': 'gemini-flash-latest',
    'gemini-2.0-flash-lite': 'gemini-flash-lite-latest',
}


def providers(conn=None):
    """**지금 쓸 수 있는 회사·모델** — 코드 씨앗 위에 **배포로 받은 목록을 덮는다**.

    ★★★ 화면은 `PROVIDER`(코드 상수)가 아니라 **이 문**을 쓴다(2026-09-29 299차-3).
      모델 이름은 회사가 물리면 그 자리에서 404 라 **배포로 고칠 수 있어야** 한다
      (`db_ai_models` · 관리자가 고치면 사용자가 날마다 자동으로 받는다).
    ⚠ **회사 이름·키 받는 곳은 코드 그대로** — 새 회사는 어댑터가 필요하므로 목록만
      늘려서는 못 쓴다(고를 수 있는데 못 보내면 화면이 거짓말한다 §0-1).
    ⚠ 표가 없거나 비면 **코드 씨앗 그대로** 돈다(조용히 안 터진다).
    """
    out = {k: dict(v) for k, v in PROVIDER.items()}
    for d in out.values():
        d['models'] = list(d['models'])
        d['alias'] = dict(MODEL_ALIAS) if d is out.get('GEMINI') else {}
    out['GEMINI']['alias'] = dict(MODEL_ALIAS)
    if conn is None:
        return out
    try:
        import db_ai_models as AM                         # ⚠ 늦게 부른다(서로 부른다)
        cat = AM.catalog(conn)
    except Exception:                                     # noqa: BLE001
        return out
    for p, d in (cat or {}).items():
        if p not in out:
            continue                                      # 어댑터가 없는 회사는 안 쓴다
        if d.get('models'):
            out[p]['models'] = list(d['models'])
            out[p]['model'] = d.get('model') or d['models'][0]
        al = dict(out[p].get('alias') or {})
        al.update(d.get('alias') or {})
        out[p]['alias'] = al
    return out


def model_alias(provider, model, conn=None):
    """물린 이름이면 살아 있는 별칭으로, 아니면 그대로.

    ★ 배포로 받은 별칭이 코드 씨앗을 **덮는다**(`conn` 을 주면). 저장값은 안 고치고
      **읽는 순간만** 옮긴다(§258차 ⑰ 과 같은 원칙).
    """
    p = (provider or '').upper()
    m = (model or '').strip()
    if conn is not None:
        try:
            import db_ai_models as AM
            al = (AM.catalog(conn).get(p) or {}).get('alias') or {}
            if m in al:
                return al[m]
            if p in PROVIDER and (AM.catalog(conn).get(p) or {}).get('models'):
                return MODEL_ALIAS.get(m, m) if p == 'GEMINI' else m
        except Exception:                                 # noqa: BLE001
            pass
    if p == 'GEMINI':
        return MODEL_ALIAS.get(m, model)
    return model

#: 모델 목록을 묻는 자리 — 회사마다 (주소, 머리글 꼴). 답은 `_models_parse` 가 읽는다.
MODELS_URL = {
    'GEMINI': ('https://generativelanguage.googleapis.com/v1beta/models?pageSize=200',
               {'x-goog-api-key': '{KEY}'}),
    'OPENAI': ('https://api.openai.com/v1/models', {'Authorization': 'Bearer {KEY}'}),
    'XAI': ('https://api.x.ai/v1/models', {'Authorization': 'Bearer {KEY}'}),
    'ANTHROPIC': ('https://api.anthropic.com/v1/models?limit=100',
                  {'x-api-key': '{KEY}', 'anthropic-version': '2023-06-01'}),
}
#: OpenAI 목록에는 글 모델이 아닌 것이 섞여 온다(음성·그림·임베딩…) — 이 낱말이 들면 뺀다.
_NOT_CHAT = ('audio', 'realtime', 'tts', 'transcribe', 'whisper', 'image', 'dall-e',
             'embedding', 'moderation', 'search', 'codex', 'instruct', 'computer-use')
TIMEOUT = 90          # 한 번 묻는 데 기다리는 끝(헤지 요청이 15초부터 다른 모델에도 함께 묻는다 — `_hedged`)
BUSY_TIMEOUT = 25     # 붐벼서 다른 모델로 한 번 더 물을 때
BUSY_TRY = 4          # 붐빌 때 한꺼번에 물어볼 다른 모델 수

#: 프롬프트 갈래 — (열쇠, 차례) · `TEACH` 는 AI 가 먼저 묻는다 · `MERGE` 는 합칠 때 쓴다
KINDS = ['ASK', 'ORIG', 'COMPARE', 'SIMILAR',
         # 310차 — 사용자 「Pick 체크상자가 더 다양해야 한다」
         'APPLY', 'CONTEXT', 'WHOWHERE',
         'CHECK', 'STUDY', 'TEACH', 'NOTE', 'MERGE']


# ══════════════════════════════════════════════════════════════════════
#  표 · 설정
# ══════════════════════════════════════════════════════════════════════
def init(conn):
    """개인 DB 표 셋 — 멱등. **`userdb.` 를 반드시 붙인다**(안 붙이면 배포 DB 에 생긴다)."""
    conn.execute(
        "CREATE TABLE IF NOT EXISTS userdb.user_ai_chat ("
        " chat_id INTEGER PRIMARY KEY AUTOINCREMENT, start_vid INTEGER, end_vid INTEGER,"
        " title TEXT, lang_code TEXT, provider TEXT, model TEXT, prompt_kind TEXT,"
        " created_at TEXT, updated_at TEXT, record_status TEXT DEFAULT 'LIVE')")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS userdb.user_ai_msg ("
        " msg_id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER NOT NULL,"
        " role TEXT NOT NULL, body TEXT, ts TEXT, n_in INTEGER DEFAULT 0, n_out INTEGER DEFAULT 0)")
    conn.execute("CREATE INDEX IF NOT EXISTS userdb.idx_user_ai_msg_chat ON user_ai_msg(chat_id)")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS userdb.user_ai_prompt ("
        " prompt_id INTEGER PRIMARY KEY AUTOINCREMENT, lang_code TEXT NOT NULL,"
        " kind TEXT NOT NULL, title TEXT, body TEXT, sort_order INTEGER DEFAULT 0,"
        " record_status TEXT DEFAULT 'LIVE')")
    # 299차 — 용어 닻 · 갈래(구절/용어) · 답마다 어느 AI 인가
    for tbl, col, ddl in (('user_ai_chat', 'entity_id', 'INTEGER'),
                          ('user_ai_chat', 'scope', "TEXT DEFAULT 'VERSE'"),
                          # 302차 — 이 대화가 만든 「내 자료」 번호(두 번 눌러도 덮어쓴다)
                          ('user_ai_chat', 'ref_id', 'INTEGER'),
                          ('user_ai_msg', 'provider', 'TEXT'),
                          ('user_ai_msg', 'model', 'TEXT'),
                          ('user_ai_prompt', 'scope', "TEXT DEFAULT 'VERSE'"),
                          # 303차 — **연구자료 닻**(`USER_REF:175` · `REF_UNIT:9` 꼴)
                          # ★ 칸 하나로 담는 까닭 — 연구자료가 **개인 글과 자료집 글 둘**이라
                          #   번호만으로는 어느 표인지 알 수 없다(번호 공간이 다르다 §240차).
                          ('user_ai_chat', 'ref_anchor', 'TEXT'),
                          # 303차 — 프롬프트의 **성격**(일반대화형·질문형·분석형·통합형·교사형)
                          # ⚠⚠ **기본값을 주지 않는다** — 주면 옛 줄이 전부 그 값이 되어
                          #   `ensure_seeds` 의 보정(「비었으면 갈래 표로」)이 한 번도 안 돈다
                          #   (실측으로 당했다 — 씨앗 일곱이 다 일반대화형으로 보였다).
                          ('user_ai_prompt', 'genre', 'TEXT'),
                          # ★★★ 317차-5 — Pick 은 **업무마다 따로**다(사용자 「설명문 작성에서 pick을
                          #   삭제하면 다른 곳(연구하자)에서도 삭제된다. 독립적이어야 한다」 ·
                          #   「업무에 따라서 Pick은 완전히 독립적으로 구성하고 추가 삭제 수정」).
                          #   빈 글 = 옛 공용 줄(씨앗 · 업무 사본의 원본).
                          ('user_ai_prompt', 'task', "TEXT DEFAULT ''"),
                          # ★★★ 317차-8 — AI 마다 대화가 갈라진다(사용자 「첫 질문만 동일 · 후속 질문은 AI 마다」).
                          #   `target` = 사용자 말이 **누구에게** 갔나('' = 모두 · 'GEMINI|모델' = 그 AI 만)
                          #   `mkind`  = 답의 **갈래**('' = 대화 · 'INTEG' = 모든 AI 통합본 · 'SELF' = 그 AI 대화 통합본)
                          ('user_ai_msg', 'target', "TEXT DEFAULT ''"),
                          ('user_ai_msg', 'mkind', "TEXT DEFAULT ''"),
                          # ★ 2026-10-15 답 검증 — `verify` = '' 안 함 · 'OK' 검증함 · 'FAIL' 검증 못 함
                          #   `raw` = 검증 전 원래 답(고쳤거나 못 했을 때만 · [다시 검증]이 이것을 다시 잰다)
                          ('user_ai_msg', 'verify', "TEXT DEFAULT ''"),
                          ('user_ai_msg', 'raw', 'TEXT'),
                          # ★ 2026-10-20 폰 AI 대화 번호(동기화로 온 대화 · 같은 대화는 갈아 끼운다)
                          ('user_ai_chat', 'phone_uid', 'TEXT'),
                          # ★ 2026-10-20 함께 쓰기(바통) · 정리 — ai_chat_sync.py
                          ('user_ai_chat', 'edits', 'INTEGER DEFAULT 0'),
                          ('user_ai_chat', 'synced_edits', 'INTEGER DEFAULT 0'),
                          ('user_ai_chat', 'last_by', 'TEXT'),
                          ('user_ai_chat', 'history', 'TEXT'),
                          ('user_ai_chat', 'share', 'INTEGER DEFAULT 0'),
                          ('user_ai_chat', 'share_sent', 'INTEGER DEFAULT 0'),
                          ('user_ai_chat', 'saved', 'INTEGER DEFAULT 0'),
                          ('user_ai_chat', 'trashed_at', 'TEXT')):
        cols = [r[1] for r in conn.execute("PRAGMA userdb.table_info(%s)" % tbl)]
        if col not in cols:
            conn.execute("ALTER TABLE userdb.%s ADD COLUMN %s %s" % (tbl, col, ddl))
    # ★ 317차-5 — 그 업무의 Pick 을 한 번 베꼈다는 표식. 사람이 다 지워도 다시 안 베낀다.
    conn.execute("CREATE TABLE IF NOT EXISTS userdb.user_ai_pick_seeded ("
                 " lang_code TEXT NOT NULL, scope TEXT NOT NULL, task TEXT NOT NULL,"
                 " PRIMARY KEY(lang_code, scope, task))")
    conn.commit()


def get_setting(conn, key, default=''):
    r = conn.execute("SELECT config_val FROM user_config WHERE config_key=?", (key,)).fetchone()
    return (r[0] if r and r[0] is not None else default)


def set_setting(conn, key, val):
    if conn.execute("SELECT 1 FROM user_config WHERE config_key=?", (key,)).fetchone():
        conn.execute("UPDATE user_config SET config_val=? WHERE config_key=?", (val, key))
    else:
        conn.execute("INSERT INTO user_config(config_key, config_val) VALUES(?,?)", (key, val))
    conn.commit()


def accounts(conn):
    """AI 계정 목록 — `[{provider, model, key, on}]`(`user_config['AI_ACCOUNTS']` JSON).
    ★ 299차 사용자 「AI 모델을 여러개 입력해두었는데 어떤 것을 사용할지 **복수 체크**하는
      화면이 필요하다」 — 켠 계정 전부에 보내고 답을 전부 담는다(`send`).
    옛 한 벌 설정(AI_PROVIDER·AI_MODEL·AI_KEY)이 있고 목록이 없으면 그것을 첫 줄로 읽는다."""
    raw = get_setting(conn, 'AI_ACCOUNTS', '')
    if raw:
        try:
            lst = json.loads(raw)
            out = []
            for a in lst if isinstance(lst, list) else []:
                if not isinstance(a, dict):
                    continue
                p = str(a.get('provider', 'GEMINI')).upper()
                if p not in PROVIDER:
                    continue
                out.append({'provider': p, 'model': model_alias(p, str(a.get('model') or PROVIDER[p]['model']), conn),
                            'key': str(a.get('key') or ''), 'on': 1 if a.get('on', 1) else 0,
                            # ★ 304차 — 화면에 그릴 **짧은 이름**(설정 팝업에서 사람이 적는다)
                            'label': str(a.get('label') or '').strip()})
            return out
        except Exception:                                 # noqa: BLE001
            pass
    st = _legacy_settings(conn)
    return [dict(st, on=1)] if st['key'] else []


def set_accounts(conn, accts):
    clean = []
    for a in accts or []:
        p = str(a.get('provider', 'GEMINI')).upper()
        if p not in PROVIDER:
            continue
        clean.append({'provider': p, 'model': model_alias(p, str(a.get('model') or PROVIDER[p]['model']).strip(), conn),
                      'key': str(a.get('key') or '').strip(), 'on': 1 if a.get('on', 1) else 0,
                      'label': str(a.get('label') or '').strip()[:LABEL_MAX]})
    set_setting(conn, 'AI_ACCOUNTS', json.dumps(clean, ensure_ascii=False))
    return clean


#: 짧은 이름 상한 — 체크 줄에 여럿이 들어야 한다(실측 12자면 한 줄에 다섯)
LABEL_MAX = 12


def short_name(a):
    """화면에 그릴 계정 이름 — **사람이 적은 짧은 이름이 먼저**.

    ★★★ 이름을 정하는 문은 **여기 하나**다(2026-09-30 사용자 「AI 이름을 짧게
      표시하는 기능이 설정 팝업에 필요하다」). 목록·고지·진행 라벨이 저마다
      지으면 어느 것이 그 계정인지 알 수 없다.
    ⚠ 짧은 이름이 없으면 **모델 이름에서 회사 접두와 판 꼬리를 깎는다** —
      지어내지 않고 있는 글자를 줄인다(`gemini-flash-lite-latest` → `flash-lite`).
    ⚠ 깎아서 빈 글자가 되면 회사 이름으로 물러선다(빈 체크상자를 내지 않는다).
    """
    a = a or {}
    lab = str(a.get('label') or '').strip()
    if lab:
        return lab[:LABEL_MAX]
    m = str(a.get('model') or '').strip()
    p = str(a.get('provider') or '').upper()
    for pre in ('gemini-', 'gpt-', 'claude-', 'grok-', 'models/'):
        if m.lower().startswith(pre):
            m = m[len(pre):]
            break
    for tail in ('-latest', '-preview', '-exp'):
        if m.lower().endswith(tail):
            m = m[:-len(tail)]
    m = m.strip('-')
    if not m:
        # ⚠ 마지막으로 물러서는 자리는 **자르지 않는다** — 「Anthropic (C」 처럼
        #   토막난 이름이 나오면 사람이 그것을 계정으로 못 읽는다. 첫 낱말만.
        # ⚠ 317차-7 — 회사도 모델도 비었으면(옛 답 · 시험 답) **빈 글자**를 낸다 — 옛 판은 `[0]` 에서 터졌다
        _w = str(PROVIDER.get(p, {}).get('name') or p).split()
        return _w[0] if _w else p
    return m[:LABEL_MAX]


def enabled_accounts(conn):
    return [a for a in accounts(conn) if a.get('on') and a.get('key')]


def _legacy_settings(conn):
    p = (get_setting(conn, 'AI_PROVIDER', 'GEMINI') or 'GEMINI').upper()
    if p not in PROVIDER:
        p = 'GEMINI'
    m = get_setting(conn, 'AI_MODEL', '') or PROVIDER[p]['model']
    k = get_setting(conn, 'AI_KEY', '')
    return {'provider': p, 'model': m, 'key': k}


def settings(conn):
    """`{provider, model, key}` — **켠 첫 계정**(없으면 옛 한 벌 설정)."""
    en = enabled_accounts(conn)
    if en:
        return {'provider': en[0]['provider'], 'model': en[0]['model'], 'key': en[0]['key']}
    return _legacy_settings(conn)


def _settings_legacy_unused(conn):
    p = (get_setting(conn, 'AI_PROVIDER', 'GEMINI') or 'GEMINI').upper()
    if p not in PROVIDER:
        p = 'GEMINI'
    m = get_setting(conn, 'AI_MODEL', '') or PROVIDER[p]['model']
    k = get_setting(conn, 'AI_KEY', '')
    return {'provider': p, 'model': m, 'key': k}


# ══════════════════════════════════════════════════════════════════════
#  어댑터 셋 — 한 문 `call`
# ══════════════════════════════════════════════════════════════════════
def _post(url, payload, headers, timeout):
    data = json.dumps(payload).encode('utf-8')
    hd = {'Content-Type': 'application/json'}
    hd.update(headers or {})
    req = urllib.request.Request(url, data=data, headers=hd)
    ctx = ssl.create_default_context()
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return r.getcode(), r.read().decode('utf-8', 'replace')


def _get(url, headers, timeout):
    hd = {'Content-Type': 'application/json'}
    hd.update(headers or {})
    req = urllib.request.Request(url, headers=hd)
    ctx = ssl.create_default_context()
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return r.getcode(), r.read().decode('utf-8', 'replace')


def _models_parse(provider, body):
    """서버가 준 목록 → 모델 이름 목록(글을 만들 수 있는 것만 · 이름순)."""
    d = json.loads(body)
    if isinstance(d, dict) and 'error' in d:
        e = d['error'] if isinstance(d['error'], dict) else {'message': str(d['error'])}
        raise ValueError('%s %s' % (e.get('type', e.get('status', '')), e.get('message', '')))
    out = []
    if provider == 'GEMINI':
        for m in d.get('models') or []:
            nm = str(m.get('name') or '')
            nm = nm[7:] if nm.startswith('models/') else nm
            meth = m.get('supportedGenerationMethods') or []
            low = nm.lower()
            if nm and (not meth or 'generateContent' in meth) \
                    and not any(w in low for w in _NOT_CHAT + ('robotics', 'live')):
                out.append(nm)
    else:
        for m in d.get('data') or []:
            nm = str(m.get('id') or '')
            low = nm.lower()
            if not nm:
                continue
            if provider == 'OPENAI' and (any(w in low for w in _NOT_CHAT)
                                         or not (low.startswith('gpt') or low[:1] == 'o' and low[1:2].isdigit())):
                continue
            if provider == 'XAI' and not low.startswith('grok'):
                continue
            out.append(nm)
    return sorted(set(out))


def best_model(provider, models):
    """그 키가 쓸 수 있는 목록에서 알맞은 하나 — 우리 기본값 → 후보 목록 차례 → 가벼운 것 → 첫째(2026-10-30)."""
    p = PROVIDER.get((provider or '').upper()) or {}
    ms = list(models or [])
    if not ms:
        return p.get('model', '')
    for m in [p.get('model', '')] + list(p.get('models') or []):
        if m and m in ms:
            return m
    for w in ('flash-lite', 'flash', 'mini', 'haiku', 'sonnet'):
        for m in ms:
            if w in m.lower() and 'preview' not in m.lower():
                return m
    return ms[0]


def list_models(provider, key, timeout=30, _get_fn=None):
    """**그 키로 쓸 수 있는 모델**을 회사 서버에 묻는다 — `{ok, models, why}`. 예외를 밖으로 안 던진다.

    ★ 후보 목록(`PROVIDER[p]['models']`)은 본보기일 뿐이라 그 사람 키에서 404 일 수 있다.
      이 문이 낸 이름은 **실제로 그 키가 쓸 수 있는 것**이다(299차-3).
    """
    provider = (provider or 'GEMINI').upper()
    if provider not in MODELS_URL:
        return {'ok': False, 'models': [], 'why': '모르는 AI: %s' % provider}
    if not (key or '').strip():
        return {'ok': False, 'models': [], 'why': 'API 키가 없습니다 — 키를 먼저 넣으세요.'}
    url, hd = MODELS_URL[provider]
    hd = {k: v.replace('{KEY}', key.strip()) for k, v in hd.items()}
    get = _get_fn or _get
    try:
        code, raw = get(url, hd, timeout)
    except urllib.error.HTTPError as e:                   # noqa: F821
        try:
            raw = e.read().decode('utf-8', 'replace')
        except Exception:                                 # noqa: BLE001
            raw = ''
        why = ''
        try:
            _models_parse(provider, raw)
        except ValueError as ve:
            why = str(ve)
        except Exception:                                 # noqa: BLE001
            pass
        return {'ok': False, 'models': [], 'why': 'HTTP %s %s' % (e.code, why)}
    except Exception as e:                                # noqa: BLE001
        return {'ok': False, 'models': [], 'why': '연결하지 못했습니다(망 없음?): %s' % e}
    try:
        models = _models_parse(provider, raw)
    except Exception as e:                                # noqa: BLE001
        return {'ok': False, 'models': [], 'why': '목록을 못 읽었다: %s' % e}
    if code != 200:
        return {'ok': False, 'models': [], 'why': 'HTTP %s' % code}
    if not models:
        return {'ok': False, 'models': [], 'why': '이 키로 쓸 수 있는 글 모델이 목록에 없다'}
    return {'ok': True, 'models': models, 'why': ''}


#: HTTP 404 = 「그 이름의 모델을 이 키로 못 찾았다」 — 모델 이름이 그 사람 환경에 없는 것이다.
NOT_FOUND_HINT = ('모델 이름을 이 키로 찾지 못했습니다 — [설정] ▸ [모델 불러오기]로 '
                  '이 키가 실제로 쓸 수 있는 모델을 선택해 주세요.')


def _payload(provider, model, system, messages, max_out):
    """회사마다 다른 꼴 — `messages=[(role, text)]` · role ∈ {'user','ai'}."""
    if provider == 'GEMINI':
        url = ('https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent'
               % model)
        body = {'contents': [{'role': ('model' if r == 'ai' else 'user'),
                              'parts': [{'text': t}]} for r, t in messages],
                'generationConfig': {'maxOutputTokens': int(max_out)}}
        if system:
            body['systemInstruction'] = {'parts': [{'text': system}]}
        return url, body, {'x-goog-api-key': '{KEY}'}
    if provider == 'ANTHROPIC':
        url = 'https://api.anthropic.com/v1/messages'
        body = {'model': model, 'max_tokens': int(max_out),
                'messages': [{'role': ('assistant' if r == 'ai' else 'user'), 'content': t}
                             for r, t in messages]}
        if system:
            body['system'] = system
        return url, body, {'x-api-key': '{KEY}', 'anthropic-version': '2023-06-01'}
    # OpenAI 호환 — GPT · Grok(xAI)
    url = ('https://api.x.ai/v1/chat/completions' if provider == 'XAI'
           else 'https://api.openai.com/v1/chat/completions')
    msgs = ([{'role': 'system', 'content': system}] if system else []) + [
        {'role': ('assistant' if r == 'ai' else 'user'), 'content': t} for r, t in messages]
    body = {'model': model, 'messages': msgs, 'max_tokens': int(max_out)}
    return url, body, {'Authorization': 'Bearer {KEY}'}


def _parse(provider, body):
    try:
        d = json.loads(body)
    except Exception as e:                                # noqa: BLE001
        return '', {}, '응답이 JSON 이 아니다: %s' % e
    if isinstance(d, dict) and 'error' in d:
        e = d['error'] if isinstance(d['error'], dict) else {'message': str(d['error'])}
        return '', {}, '%s %s' % (e.get('type', e.get('status', '')), e.get('message', ''))
    txt, tok = '', {}
    try:
        if provider == 'GEMINI':
            c0 = (d.get('candidates') or [{}])[0]
            txt = ''.join(p.get('text', '') for p in ((c0.get('content') or {}).get('parts') or []))
            um = d.get('usageMetadata') or {}
            tok = {'in': um.get('promptTokenCount', 0), 'out': um.get('candidatesTokenCount', 0),
                   'cut': c0.get('finishReason') == 'MAX_TOKENS'}
        elif provider == 'ANTHROPIC':
            txt = ''.join(b.get('text', '') for b in (d.get('content') or []) if b.get('type') == 'text')
            um = d.get('usage') or {}
            tok = {'in': um.get('input_tokens', 0), 'out': um.get('output_tokens', 0),
                   'cut': d.get('stop_reason') == 'max_tokens'}
        else:
            ch = (d.get('choices') or [{}])[0]
            txt = ((ch.get('message') or {}).get('content') or '')
            um = d.get('usage') or {}
            tok = {'in': um.get('prompt_tokens', 0), 'out': um.get('completion_tokens', 0),
                   'cut': ch.get('finish_reason') == 'length'}
    except Exception as e:                                # noqa: BLE001
        return '', {}, '응답 꼴을 못 읽었다: %s' % e
    if not (txt or '').strip():
        return '', tok, '받은 글이 비었다'
    return txt.strip(), tok, ''


#: 되물어도 되는 것 — 일시 과부하·한도. ⚠ 400·401·403·404 는 **안 되묻는다**(키·이름 문제라
#  세 번 더 불러도 같고 한도만 더 먹는다 · `ai_client` 와 같은 규칙).
RETRY_CODES = (408, 429, 500, 502, 503, 504)
RETRY_WAIT = (2, 6)                                       # 두 번까지 · 초


def call(provider, key, model, messages, system='', timeout=TIMEOUT, max_out=2048,
         _post_fn=None, _sleep=None):
    """**한 번 묻는다**(일시 과부하면 잠깐 쉬고 다시) — `{ok, text, why, tokens}`.

    예외를 밖으로 던지지 않는다. 되묻는 것은 `RETRY_CODES` 뿐이다.
    """
    provider = (provider or 'GEMINI').upper()
    if provider not in PROVIDER:
        return {'ok': False, 'text': '', 'why': '모르는 AI: %s' % provider, 'tokens': {}, 'code': 0}
    if not (key or '').strip():
        return {'ok': False, 'text': '', 'why': 'API 키가 없습니다 — [설정]에서 넣으세요.', 'tokens': {}, 'code': 0}
    if not messages:
        return {'ok': False, 'text': '', 'why': '보낼 말이 없습니다.', 'tokens': {}, 'code': 0}
    url, body, hd = _payload(provider, model or PROVIDER[provider]['model'], system, messages, max_out)
    hd = {k: v.replace('{KEY}', key.strip()) for k, v in hd.items()}
    post = _post_fn or _post
    nap = _sleep if _sleep is not None else time.sleep
    code, raw, last = 0, '', None
    for _try in range(len(RETRY_WAIT) + 1):
        if _try:
            nap(RETRY_WAIT[_try - 1])
        try:
            code, raw = post(url, body, hd, timeout)
        except urllib.error.HTTPError as e:               # noqa: F821 — urllib.error 는 request 가 끌어온다
            try:
                raw = e.read().decode('utf-8', 'replace')
            except Exception:                             # noqa: BLE001
                raw = ''
            _t, _k, why = _parse(provider, raw)
            if e.code == 404:                             # 모델 이름이 이 키에 없다(299차-3)
                why = (why or '').strip() + ' ' + NOT_FOUND_HINT
            last = {'ok': False, 'text': '', 'why': 'HTTP %s %s' % (e.code, why or ''),
                    'tokens': {}, 'code': e.code}
            if e.code in RETRY_CODES and _try < len(RETRY_WAIT):
                continue
            return last
        except Exception as e:                            # noqa: BLE001
            last = {'ok': False, 'text': '', 'why': '연결하지 못했습니다(망 없음?): %s' % e,
                    'tokens': {}, 'code': 0}
            return last
        if code != 200:
            _t, _k, why = _parse(provider, raw)
            if code == 404:
                why = (why or '').strip() + ' ' + NOT_FOUND_HINT
            last = {'ok': False, 'text': '', 'why': 'HTTP %s %s' % (code, why),
                    'tokens': {}, 'code': code}
            if code in RETRY_CODES and _try < len(RETRY_WAIT):
                continue
            return last
        break
    if code != 200:
        return last or {'ok': False, 'text': '', 'why': 'HTTP %s' % code, 'tokens': {}, 'code': code}
    txt, tok, why = _parse(provider, raw)
    if why:
        return {'ok': False, 'text': '', 'why': why, 'tokens': tok, 'code': code}
    return {'ok': True, 'text': txt, 'why': '', 'tokens': tok, 'code': code}


# ══════════════════════════════════════════════════════════════════════
#  재료 — sys 를 읽기만 한다
# ══════════════════════════════════════════════════════════════════════
#: 404 뒤 자동 전환 — 한 계정에 **한 번만** 시도한다(바꾼 것이 또 404 면 그대로 실패).
NOT_FOUND = 404


def pick_model(conn, provider, key, cur='', _list=None):
    """404 가 난 **그 키에게 직접 물어** 쓸 수 있는 이름을 하나 선택한다 — `{ok, model, why}`.

    ★ 사용자 확정(300차) 「사용자 화면이 **자동으로 인지하여 적용**」 — [모델 불러오기]를
      사람이 누르던 일을 앱이 그 자리에서 한다.
    고르는 차례 — ① 우리 기본 모델 ② 우리 후보 목록 차례대로 ③ 키 목록의 첫 번째.
      **우리가 권하는 것 가운데 그 키가 실제로 쓸 수 있는 것**이 가장 안전하다.
    ⚠ **지금 쓰던 이름은 안 고른다** — 같은 404 를 또 먹는다.
    ⚠ 물어보다 실패하면(망 없음·키 틀림) 조용히 넘어가지 않고 까닭을 돌려준다(§0-1).
    """
    provider = (provider or 'GEMINI').upper()
    got = (_list or list_models)(provider, key)
    if not got.get('ok'):
        return {'ok': False, 'model': '', 'why': got.get('why', '')}
    have = [m for m in (got.get('models') or []) if m and m != (cur or '')]
    if not have:
        return {'ok': False, 'model': '', 'why': '이 키가 쓸 수 있는 다른 모델이 없습니다.'}
    pv = providers(conn).get(provider) or PROVIDER.get(provider) or {}
    for want in ([pv.get('model', '')] + list(pv.get('models') or [])):
        if want and want != (cur or '') and want in have:
            return {'ok': True, 'model': want, 'why': ''}
    return {'ok': True, 'model': have[0], 'why': ''}


_MODEL_LIST_CACHE = {}


def busy_alternates(conn, provider, key, cur, _list=None):
    """그 모델이 **붐빌 때**(503·429·시간 초과) 넘어가 볼 다른 모델 — 우리 후보 가운데 그 키가 쓸 수 있는 것.

    ★ 2026-10-13 사용자 「답변하는데 86초 걸렸다」 — 실측: 같은 시각 `gemini-flash-lite-latest` 는 503·40초 시간 초과,
      `gemini-3.8-flash` 는 5.8초. 우리 탓이 아니라 그 모델이 붐볐다. ⇒ 한 모델에 매달리지 않고 다른 모델로 한 번 더 묻는다.
    ⚠ 저장은 안 바꾼다(404 와 달리 잠깐 붐빈 것이다) · 키 목록은 한 시간 기억한다."""
    provider = (provider or 'GEMINI').upper()
    ck = (provider, (key or '')[-8:])
    hit = _MODEL_LIST_CACHE.get(ck)
    if hit and time.time() - hit[0] < 3600:
        have = hit[1]
    else:
        got = (_list or list_models)(provider, key)
        have = list(got.get('models') or []) if got.get('ok') else []
        _MODEL_LIST_CACHE[ck] = (time.time(), have)
    pv = providers(conn).get(provider) or PROVIDER.get(provider) or {}
    out = []
    for m in [pv.get('model', '')] + list(pv.get('models') or []):
        if m and m != (cur or '') and m not in out and (not have or m in have):
            out.append(m)
    return out


HEDGE = 15            # 이 초 안에 답이 없으면 다른 모델에도 함께 묻는다


def _hedged(fn, acc, msgs, system, alts_fn):
    """그 모델에 묻되 HEDGE 초가 지나도록 답이 없거나 붐빈다고 하면 **다른 모델들에도 함께** 묻는다 —
    `(결과, 답한 모델)`. 붐빈 것이 아닌 실패(404·키 틀림)는 그대로 돌려준다(404 전환이 따로 맡는다)."""
    import queue
    import threading
    q = queue.Queue()
    t0 = time.time()

    def one(m, tmo):
        try:
            try:
                r = fn(acc['provider'], acc['key'], m, msgs, system=system, timeout=tmo)
            except TypeError:
                r = fn(acc['provider'], acc['key'], m, msgs, system=system)
        except Exception as e:                            # noqa: BLE001
            r = {'ok': False, 'why': str(e), 'code': 0}
        q.put((m, r))
    threading.Thread(target=one, args=(acc['model'], TIMEOUT), daemon=True).start()
    pending, started, first_res = 1, False, None
    while pending:
        left = TIMEOUT + 5 - (time.time() - t0)
        if left <= 0:
            break
        try:
            m, r = q.get(timeout=min(left, HEDGE) if not started else left)
        except Exception:                                 # noqa: BLE001
            m, r = None, None
        if m is None:                                     # HEDGE 초가 지났다 — 다른 모델에도
            if not started:
                started = True
                try:
                    alts = list(alts_fn() or [])
                except Exception:                         # noqa: BLE001
                    alts = []
                for a in alts:
                    threading.Thread(target=one, args=(a, max(10, int(TIMEOUT - (time.time() - t0)))),
                                     daemon=True).start()
                pending += len(alts)
            continue
        pending -= 1
        if first_res is None and m == acc['model']:
            first_res = r
        if r.get('ok'):
            return r, m
        if m == acc['model'] and not _busy(r):
            return r, m                                   # 붐빈 것이 아니다 — 그대로(404 등)
        if m == acc['model'] and not started:
            started = True
            try:
                alts = list(alts_fn() or [])
            except Exception:                             # noqa: BLE001
                alts = []
            for a in alts:
                threading.Thread(target=one, args=(a, max(10, int(TIMEOUT - (time.time() - t0)))),
                                 daemon=True).start()
            pending += len(alts)
    return (first_res or {'ok': False, 'text': '', 'why': '응답이 없습니다(시간 초과)', 'tokens': {}, 'code': 0}), None


def _race(fn, acc, models, msgs, system):
    """여러 모델에 한꺼번에 묻고 **먼저 성공한 답** `(모델, 결과)` — 모두 실패면 None.
    ⚠ 늦은 답은 버린다(받아도 화면에 안 쓴다) · 붐빌 때만 쓰이므로 요청이 몇 번 더 가는 값은 작다."""
    import queue
    import threading
    if not models:
        return None
    q = queue.Queue()

    def one(m):
        try:
            try:
                r = fn(acc['provider'], acc['key'], m, msgs, system=system, timeout=BUSY_TIMEOUT)
            except TypeError:
                r = fn(acc['provider'], acc['key'], m, msgs, system=system)
        except Exception as e:                            # noqa: BLE001
            r = {'ok': False, 'why': str(e)}
        q.put((m, r))
    for m in models:
        threading.Thread(target=one, args=(m,), daemon=True).start()
    for _ in models:
        try:
            m, r = q.get(timeout=BUSY_TIMEOUT + 10)
        except Exception:                                 # noqa: BLE001
            return None
        if r.get('ok'):
            return m, r
    return None


def _busy(res):
    """붐벼서 못 받은 것인가(503·429·5xx·시간 초과)."""
    if res.get('ok'):
        return False
    if res.get('code') in RETRY_CODES:
        return True
    return res.get('code') == 0 and 'timed out' in (res.get('why') or '')


def switch_model(conn, provider, old, new):
    """계정 목록에서 `(회사, 옛 모델)` 인 줄의 모델을 **저장까지** 바꾼다 — 바꾼 줄 수.

    ⚠ 꺼 둔 계정도 함께 읽어 다시 쓴다(`accounts` 전체) — 켠 것만 저장하면 나머지를 잃는다.
    ⚠ 같은 회사·같은 모델이 여러 줄이면 다 바꾼다 — 같은 키 사정이라 함께 막힌다.
    """
    provider = (provider or '').upper()
    accts, n = accounts(conn), 0
    for a in accts:
        if a.get('provider') == provider and a.get('model') == old:
            a['model'] = new
            n += 1
    if n:
        set_accounts(conn, accts)
    return n


def _label(conn, vid, lang='KO'):
    r = conn.execute(
        "SELECT bn.short_name, bi.chapter, bi.verse FROM bible_index bi "
        "JOIN book_names bn ON bn.book_code=bi.bcode AND bn.lang_code IN (?,'EN','KO') "
        "WHERE bi.verse_id=? ORDER BY CASE bn.lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END"
        " LIMIT 1", (lang, vid, lang)).fetchone()
    return ('%s %d:%d' % (r[0], r[1], r[2])) if r else str(vid)


def range_label(conn, start_vid, end_vid=None, lang='KO'):
    a = _label(conn, start_vid, lang)
    if not end_vid or end_vid == start_vid:
        return a
    b = conn.execute("SELECT chapter, verse FROM bible_index WHERE verse_id=?", (end_vid,)).fetchone()
    a0 = conn.execute("SELECT chapter FROM bible_index WHERE verse_id=?", (start_vid,)).fetchone()
    if not b:
        return a
    return ('%s~%d' % (a, b[1])) if (a0 and a0[0] == b[0]) else ('%s~%d:%d' % (a, b[0], b[1]))


def _verses(conn, start_vid, end_vid):
    r0 = conn.execute("SELECT bcode, sort_order FROM bible_index WHERE verse_id=?", (start_vid,)).fetchone()
    r1 = conn.execute("SELECT bcode, sort_order FROM bible_index WHERE verse_id=?", (end_vid or start_vid,)).fetchone()
    if not r0 or not r1:
        return []
    lo, hi = sorted((r0[1], r1[1]))
    return [x[0] for x in conn.execute(
        "SELECT verse_id FROM bible_index WHERE sort_order BETWEEN ? AND ? ORDER BY sort_order",
        (lo, hi)).fetchall()]


def _text(conn, vid, ver, lang):
    try:
        import verse_text as VT
        return (VT.resolve(conn, vid, ver, lang) or {}).get('text', '') or ''
    except Exception:                                     # noqa: BLE001
        return ''


def pericope_of(conn, vid):
    """그 절이 든 본문 단락 — `(start_vid, end_vid)` 또는 `None`."""
    r = conn.execute(
        "SELECT p.start_vid, p.end_vid FROM sys_pericope_asset p"
        " JOIN bible_index a ON a.verse_id=p.start_vid JOIN bible_index z ON z.verse_id=p.end_vid"
        " JOIN bible_index v ON v.verse_id=?"
        " WHERE p.peri_type='BODY' AND p.record_status='LIVE'"
        "   AND v.sort_order BETWEEN a.sort_order AND z.sort_order"
        " ORDER BY (z.sort_order - a.sort_order) LIMIT 1", (vid,)).fetchone()
    return (int(r[0]), int(r[1])) if r else None


def shift(conn, vid, n):
    """`vid` 에서 `n` 절 뒤(음수면 앞)의 절 — 정경 차례로(책을 넘지 않는다)."""
    r = conn.execute("SELECT bcode, sort_order FROM bible_index WHERE verse_id=?", (vid,)).fetchone()
    if not r:
        return vid
    rows = conn.execute(
        "SELECT verse_id FROM bible_index WHERE bcode=? AND sort_order %s ? ORDER BY sort_order %s LIMIT ?"
        % (('>' if n > 0 else '<'), ('ASC' if n > 0 else 'DESC')), (r[0], r[1], abs(int(n)))).fetchall()
    return int(rows[-1][0]) if rows else vid


def materials(conn, start_vid, end_vid=None, lang='KO', versions=(('KRV', 'KO'), ('BSB', 'EN'))):
    """AI 에게 줄 재료 — `{열쇠: 글}`. sys 를 **읽기만** 한다."""
    end_vid = end_vid or start_vid
    out = {}
    lbl = range_label(conn, start_vid, end_vid, lang)
    out['구절'] = lbl
    vids = _verses(conn, start_vid, end_vid)
    for ver, vl in versions:
        lines = []
        for v in vids[:60]:
            t = _text(conn, v, ver, vl)
            if t:
                lines.append('%s %s' % (_label(conn, v, lang), t))
        if lines:
            out['본문 (%s)' % ver] = NL.join(lines)
    pr = pericope_of(conn, start_vid)
    if pr:
        out['이 절이 든 단락'] = range_label(conn, pr[0], pr[1], lang)
        t = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE text_type='PERI_TITLE' AND record_status='LIVE'"
            " AND clicked_id=(SELECT pericope_id FROM sys_pericope_asset WHERE start_vid=? AND end_vid=?"
            " AND peri_type='BODY' LIMIT 1) AND UPPER(lang_code) IN (?, 'EN')"
            " ORDER BY CASE WHEN UPPER(lang_code)=? THEN 0 ELSE 1 END LIMIT 1",
            (pr[0], pr[1], lang.upper(), lang.upper())).fetchone()
        if t and t[0]:
            out['단락 제목'] = t[0]
    if len(vids) == 1:
        a, b = shift(conn, start_vid, -2), shift(conn, start_vid, 2)
        nb = [v for v in _verses(conn, a, b) if v != start_vid]
        ln = ['%s %s' % (_label(conn, v, lang), _text(conn, v, 'KRV', 'KO')) for v in nb]
        ln = [x for x in ln if x.strip()]
        if ln:
            out['앞뒤 절 (개역한글)'] = NL.join(ln)
    try:
        names = conn.execute(
            "SELECT DISTINCT t.contents FROM sys_entity_verse ev"
            " JOIN sys_text_asset t ON t.text_type='ENTITY_NAME' AND t.clicked_id=ev.entity_id"
            "   AND UPPER(t.lang_code)=? AND t.record_status='LIVE'"
            " WHERE ev.verse_id IN (%s) AND ev.record_status='LIVE' AND ev.link_kind<>'LEXICAL'"
            " LIMIT 12" % ','.join('?' * len(vids[:60])), [lang.upper()] + vids[:60]).fetchall()
        if names:
            out['이 자리의 주요용어'] = ' · '.join(n[0] for n in names if n[0])
    except Exception:                                     # noqa: BLE001
        pass
    return out


#: 내 묵상노트를 **어디까지 모아** AI 에게 보낼까 — 화면 콤보와 같은 차례.
#: ★★★ **「전부」를 걷었다**(2026-09-30 사용자 확정 · docs/1.txt 1번) —
#:   성경 전체의 내 노트를 **통째로 외부 AI 에** 보내는 값이었다. 개인 글이
#:   나가는 문은 좁을수록 낫다. ⚠ 옛 저장값 `ALL` 은 `BOOK` 으로 읽는다.
NOTE_SCOPES = ['RANGE', 'PERI', 'CHAPTER']     # 절(이 구절·구간) · 단락 · 장
#: ★ 317차-15 — 「책」을 뺐다(사용자 「책은 노트가 너무 많아서 분석결과가 의미없을 것」) · 단락을 넣었다.
#:   옛 값 BOOK·ALL 은 `_note_scope` 가 그대로 읽는다(화면에서만 빠진다).

# ★★★ **살아 있는 묵상노트의 상태는 셋이다 — 이 앱의 관례다**(312차 실측).
#   `medi_note.add_note` 가 새 노트를 **`NEW`** 로 넣고, `update_note` 가 고치면
#   **`EDIT`** 로 바꾸며, `hide_note` 가 지우면 **`HIDE`** 다. 읽는 자리
#   (`medi_note.notes_for_context`·`note_refr_panel`)는 전부
#   `record_status IN ('LIVE','NEW','EDIT')` 로 본다.
# ⚠⚠⚠ 그래서 `='LIVE'` 로 좁히면 **사용자가 쓴 노트를 하나도 못 찾는다** —
#   실측 `VERS_NOTE` 53건이 **EDIT 32 · NEW 21 · HIDE 2 · LIVE 0** 이었다.
#   사용자가 「시18:4 묵상노트 + 이 책을 골랐는데 묵상노트가 전혀 첨부되지
#   않은 것 같다」고 한 자리가 **정확히 이것**이고, 배선은 멀쩡했다.
# ⚠ **`HIDE` 는 반드시 뺀다** — 사용자가 지운 글이 외부 AI 로 나가면 안 된다(§C-2).
#   그래서 「`LIVE` 조건만 걷기」가 아니라 **목록으로 못 박는다**.
NOTE_ALIVE = ('LIVE', 'NEW', 'EDIT')
_NOTE_ALIVE_SQL = ("COALESCE(t.record_status,'LIVE') IN ('%s')"
                   % "','".join(NOTE_ALIVE))



_NOTE_SRC = ("(SELECT user_text_id, clicked_id, contents, record_status, updated_at, created_at"
             " FROM user_text_asset WHERE text_type='VERS_NOTE'"
             " UNION ALL SELECT n.user_text_id, u.start_vid, n.contents, n.record_status, n.updated_at, n.created_at"
             " FROM user_text_asset n JOIN sys_book_unit u ON u.unit_id=n.clicked_id"
             " WHERE n.text_type='BUNT_MEDI' AND u.start_vid IS NOT NULL"
             " AND n.contents LIKE '관련구절 %')")   # ★ 2026-10-21 구절에도 연결한 도서노트만(medi_note.UNIT_LINKED_SQL)
# ★ 2026-10-13 docs/1.txt 79-3 — 도서 편에 단 노트(BUNT_MEDI)도 **그 편의 기준 구절** 노트로 함께 센다·싣는다.
#   세 문(my_notes·notes_where·note_groups)이 같은 원천을 쓴다 — 갈리면 팝업과 실리는 것이 다르다.


def _note_scope(conn, start_vid, end_vid=None, scope='RANGE'):
    """범위를 **조건절 하나**로 — `(조건절, 인자)` · 재료가 없으면 `None`.

    ★★★ **`my_notes` 와 `notes_where` 가 이 한 문을 쓴다**(312차) — 두 곳에서
      좁히면 「팝업에는 있다는데 실제로는 안 실린다」가 난다(§219차 ⑤ 그 자리).
    ⚠ 옛 값 `ALL`(성경 전체)은 303차에 걷었다 — 들어오면 **그 책까지**로 좁힌다
      (성경 전체의 내 노트를 통째로 외부 AI 에 보내지 않는다).
    """
    scope = (scope or 'RANGE').upper()
    if scope == 'ALL':
        scope = 'BOOK'
    end_vid = end_vid or start_vid
    if scope == 'PERI':
        # ★ 317차-15 — 그 절이 든 **본문 단락**(없으면 그 구절·구간으로)
        per = pericope_of(conn, start_vid) if start_vid else None
        if per:
            start_vid, end_vid = per
    if scope in ('CHAPTER', 'BOOK'):
        r = conn.execute("SELECT bcode, chapter FROM bible_index WHERE verse_id=?",
                         (start_vid,)).fetchone()
        if not r:
            return None
        if scope == 'CHAPTER':
            return (" AND b.bcode=? AND b.chapter=?", [r[0], r[1]])
        return (" AND b.bcode=?", [r[0]])
    r0 = conn.execute("SELECT sort_order FROM bible_index WHERE verse_id=?", (start_vid,)).fetchone()
    r1 = conn.execute("SELECT sort_order FROM bible_index WHERE verse_id=?", (end_vid,)).fetchone()
    if not r0 or not r1:
        return None
    lo, hi = sorted((r0[0], r1[0]))
    return (" AND b.sort_order BETWEEN ? AND ?", [lo, hi])


def _note_body(txt):
    """노트 머리말(출처·질문 규약 줄)을 걷고 **본문만** — 비면 빈 글.

    ⚠ `my_notes` 와 `notes_where` 가 **같은 잣대**로 걸러야 한다 — 세는 것과
      싣는 것이 갈리면 팝업이 거짓말을 한다.
    """
    body = txt or ''
    try:
        import medi_note
        p = medi_note.parse(txt)
        body = (p.get('body') or '').strip() or body
    except Exception:                                     # noqa: BLE001
        pass
    return body.strip()


def my_notes(conn, start_vid, end_vid=None, limit=40, scope='RANGE'):
    """내 묵상노트(`user_text_asset` VERS_NOTE · 개인 DB) 본문들 — 최근 것부터.
    `scope` = RANGE(닻 구간) · CHAPTER(닻이 든 장) · BOOK(그 책) — 299차 사용자
    「선택된 구절 하나가 아니라 더 많은 범위를 선택할 수 있어야 한다」.
    ⚠ 개인 글이 밖으로 나가는 자리다 — 화면 체크가 켜져 있을 때만 재료에 싣는다.
    ⚠⚠⚠ 상태 조건은 **`NOTE_ALIVE`**(LIVE·NEW·EDIT)다 — `='LIVE'` 로 좁히면
      사용자가 쓴 노트를 전부 걸러 낸다(312차 실측 · 위 상수 머리글)."""
    sc = _note_scope(conn, start_vid, end_vid, scope)
    if sc is None:
        return []
    add, ar = sc
    rows = conn.execute(
        "SELECT t.contents FROM " + _NOTE_SRC + " t JOIN bible_index b ON b.verse_id=t.clicked_id"
        " WHERE " + _NOTE_ALIVE_SQL +
        "   AND TRIM(COALESCE(t.contents,''))<>''" + add +
        " ORDER BY COALESCE(t.updated_at, t.created_at) DESC LIMIT ?",
        list(ar) + [int(limit)]).fetchall()
    out = []
    for (txt,) in rows:
        body = _note_body(txt)
        if body:
            out.append(body)
    return out


def notes_where(conn, start_vid, end_vid=None, scope='RANGE', lang='KO', limit=200):
    """그 범위에서 **어느 절에 내 묵상노트가 있나** — `[(verse_id, 약명, 편수)]`.

    ★★★ 312차 사용자 「묵상노트 프롬프트 클릭하고 콤보상자를 선택하면 팝업으로
      **어떤 구절에 묵상노트가 있는지** 표시해주어야 할 것 같다. 아무런 묵상노트가
      없을 수도 있다. **없으면 없다고 말해야 한다**」.
    ★ 묵상노트는 `system_text`(시스템 글)에만 실려 **사용자가 확인할 화면이
      없었다** — 그래서 「첨부되지 않은 것 같다」로 읽혔다. 이 문이 그 자리를 메운다.
    ⚠ 범위·상태·빈 노트 잣대가 `my_notes` 와 **같다**(`_note_scope`·`_note_body`).
    ⚠ 차례는 **성경 차례**(`sort_order`)다 — 「어디에 있나」를 보는 자리라
      최근순이 아니라 읽는 순이 맞다.
    """
    sc = _note_scope(conn, start_vid, end_vid, scope)
    if sc is None:
        return []
    add, ar = sc
    rows = conn.execute(
        "SELECT b.verse_id, t.contents FROM " + _NOTE_SRC + " t"
        " JOIN bible_index b ON b.verse_id=t.clicked_id"
        " WHERE " + _NOTE_ALIVE_SQL +
        "   AND TRIM(COALESCE(t.contents,''))<>''" + add +
        " ORDER BY b.sort_order, t.user_text_id LIMIT ?",
        list(ar) + [int(limit)]).fetchall()
    cnt = {}
    for vid, txt in rows:
        if _note_body(txt):
            cnt[vid] = cnt.get(vid, 0) + 1
    return [(v, range_label(conn, v, None, lang), c) for v, c in cnt.items()]


def note_groups(conn, start_vid, end_vid=None, scope='RANGE', lang='KO', limit=200):
    """★ 317차-15 — 그 범위의 묵상노트를 **구절마다** — `[(verse_id, 약명, [본문…])]`(성경 차례).

    ★ 사용자 「분석은 한꺼번에 하지만, 분석 내용과 연결작업은 **각 구절단위 독립적**이어야 한다」 —
      보낼 때 노트마다 그 구절 이름표를 붙이고(`note_material`), 받은 답을 구절마다 나눠 그 구절에 담는다.
    ⚠ 범위·상태·빈 노트 잣대는 `my_notes`·`notes_where` 와 같은 문(`_note_scope`·`_note_body`).
    """
    sc = _note_scope(conn, start_vid, end_vid, scope)
    if sc is None:
        return []
    add, ar = sc
    rows = conn.execute(
        "SELECT b.verse_id, t.contents FROM " + _NOTE_SRC + " t"
        " JOIN bible_index b ON b.verse_id=t.clicked_id"
        " WHERE " + _NOTE_ALIVE_SQL +
        "   AND TRIM(COALESCE(t.contents,''))<>''" + add +
        " ORDER BY b.sort_order, t.user_text_id LIMIT ?",
        list(ar) + [int(limit)]).fetchall()
    out, at = [], {}
    for vid, txt in rows:
        if is_ai_note(txt):
            continue                                      # ★ AI 가 쓴 분석은 분석할 노트가 아니다
        body = _note_body(txt)
        if not body:
            continue
        if vid not in at:
            at[vid] = len(out)
            out.append((vid, range_label(conn, vid, None, lang), []))
        out[at[vid]][2].append(body)
    return out


def note_material(groups):
    """재료 「내 묵상노트」 — 노트마다 **그 구절 이름표**를 붙인다(AI 가 어느 노트가 어느 구절의 것인지 안다)."""
    parts = []
    for _v, lbl, bodies in groups:
        for b in bodies:
            parts.append('[%s]%s%s' % (lbl, NL, b))
    return (NL + '---' + NL).join(parts)


NOTE_RULE = {
    'KO': '묵상노트가 있는 구절마다 따로 분석하세요. 구절마다 그 구절 표시를 대괄호에 넣어 한 줄에 먼저 적고(예: {ex}) 그 아래에 그 구절의 분석만 쓰세요. 여러 구절을 한데 섞어 분석하지 마세요.',
    'EN': 'Analyse each verse that has a note separately. For each verse, first write its reference in square brackets on its own line (e.g. {ex}), then write the analysis of that verse only below it. Do not mix several verses into one analysis.',
    'JA': '黙想ノートのある節ごとに分けて分析してください。節ごとにまずその節の表示を角かっこに入れて一行に書き(例: {ex})、その下にその節の分析だけを書いてください。複数の節をまとめて分析しないでください。',
    'ZH': '请按有默想笔记的经节逐一分别分析。每节先在一行中用方括号写出该节标示(例: {ex})，再在下面只写该节的分析。不要把几节混在一起分析。',
    'ZHT': '請按有默想筆記的經節逐一分別分析。每節先在一行中用方括號寫出該節標示(例: {ex})，再在下面只寫該節的分析。不要把幾節混在一起分析。',
    'DE': 'Analysiere jeden Vers mit einer Notiz einzeln. Schreibe zu jedem Vers zuerst seine Stelle in eckigen Klammern in eine eigene Zeile (z. B. {ex}) und darunter nur die Analyse dieses Verses. Vermische nicht mehrere Verse in einer Analyse.',
    'FR': 'Analyse séparément chaque verset qui a une note. Pour chaque verset, écris d’abord sa référence entre crochets sur une ligne (ex. {ex}), puis seulement l’analyse de ce verset en dessous. Ne mélange pas plusieurs versets dans une même analyse.',
    'ES': 'Analiza por separado cada versículo que tenga una nota. Para cada versículo, escribe primero su referencia entre corchetes en una línea (p. ej. {ex}) y debajo solo el análisis de ese versículo. No mezcles varios versículos en un mismo análisis.',
    'PT': 'Analise separadamente cada versículo que tenha uma nota. Para cada versículo, escreva primeiro a referência entre colchetes numa linha (ex.: {ex}) e abaixo apenas a análise desse versículo. Não misture vários versículos numa só análise.',
    'RU': 'Разбери отдельно каждый стих, к которому есть заметка. Для каждого стиха сначала напиши его ссылку в квадратных скобках отдельной строкой (напр. {ex}), а ниже — только разбор этого стиха. Не смешивай несколько стихов в одном разборе.',
    'AR': 'حلّل كل آية لها ملاحظة على حدة. لكل آية اكتب أولًا مرجعها بين قوسين مربعين في سطر مستقل (مثل {ex})، ثم اكتب تحته تحليل تلك الآية فقط. لا تخلط عدة آيات في تحليل واحد.',
}


def note_task_text(conn, task_text, groups, lang='KO'):
    """묵상노트 분석의 할 일 — 자리표 [구절] = **노트가 있는 구절들**(닻 하나가 아니다) + 구절마다 나눠 쓰는 규칙.

    ⚠ 그전에는 「시 22:26 에 대해 쓴 묵상노트」라 하고 시편 전체의 노트를 보냈다(사용자 지적) —
      말한 범위와 보낸 노트가 어긋났다.
    """
    if not groups:
        return task_text
    lbl = ', '.join(g[1] for g in groups) + ' (%d)' % sum(len(g[2]) for g in groups)
    body = task_text or ''
    for tok in _PH_VERSE:
        body = body.replace(tok, lbl)
    rule = (NOTE_RULE.get((lang or 'KO').upper()) or NOTE_RULE['EN']).replace('{ex}', '[%s]' % groups[0][1])
    return (body.rstrip() + NL + rule) if body.strip() else rule


def split_note_analysis(conn, text, lang='KO', allowed=None):
    """받은 분석을 **구절마다** 나눈다 — `[(verse_id, 그 구절 분석)]`(나온 차례).

    머리 줄 = 짧은 한 줄이 **구절 하나**로 풀리는 것(대괄호·#·굵게 표시는 걷는다 · 그 언어 약명 · 영어·한국어도).
    ⚠ `allowed` 를 주면 그 구절만 머리로 본다(묻지 않은 구절이 끼어들지 않게) — 그 밖은 본문으로 둔다.
    ⚠ 첫 머리 앞의 글(인사말)은 어느 구절에도 붙이지 않는다.
    """
    import re as _re
    try:
        import scripture_ref as SR
    except Exception:                                     # noqa: BLE001
        return []
    langs = [(lang or 'KO').upper()] + [x for x in ('KO', 'EN') if x != (lang or 'KO').upper()]
    out, cur, buf = [], None, []

    def _head(line):
        t = line.strip()
        if not t or len(t) > 60:
            return None
        t2 = _re.sub(r'^[\s#>*_\-]*', '', t).strip()        # ⚠ 숫자는 안 걷는다(「1 Cor」·「요일」의 책 번호)
        t2 = t2.strip('*_ ').strip()
        m = _re.match(r'^[\[\(\u3010\u300c]\s*([^\]\)\u3011\u300d]{2,40})\s*[\]\)\u3011\u300d]', t2)
        core = m.group(1) if m else t2
        rest = t2[m.end():].strip(' :.-—') if m else ''
        if rest and len(rest) > 20:
            return None
        for lg in langs:
            got = SR.find(conn, core, lg, limit=2)
            if len(got) == 1 and got[0][0] == got[0][1]:
                matched = got[0][2]
                if core.strip().startswith(matched.strip()[:2]) and len(core) - len(matched) <= 12:
                    v = got[0][0]
                    if allowed is None or v in allowed:
                        return v
        return None

    for line in (text or '').split(NL):
        v = _head(line)
        if v is not None:
            if cur is not None and NL.join(buf).strip():
                out.append((cur, NL.join(buf).strip()))
            cur, buf = v, []
            continue
        if cur is not None:
            buf.append(line)
    if cur is not None and NL.join(buf).strip():
        out.append((cur, NL.join(buf).strip()))
    merged, at = [], {}
    for v, b in out:                                      # 같은 구절 머리가 두 번 나오면 잇는다
        if v in at:
            merged[at[v]] = (v, merged[at[v]][1] + NL + NL + b)
        else:
            at[v] = len(merged)
            merged.append((v, b))
    return merged


AI_NOTE_SRC = 'AI'      # 묵상분석을 담을 때 적는 출처 이름(`medi_note` 규약 줄의 src_label)


def is_ai_note(contents):
    """그 노트가 **AI 묵상분석**인가(사람이 쓴 노트가 아니다) — 출처 줄이 `AI` 다."""
    try:
        import medi_note
        p = medi_note.parse(contents)
        return (p.get('src_label') or '').strip() == AI_NOTE_SRC and not (p.get('src_key') or '').strip()
    except Exception:                                     # noqa: BLE001
        return False


def noted_verses(conn, vids):
    """그 구절들 가운데 **사람이 쓴 살아 있는 묵상노트가 있는** 것 — 분석을 붙일 수 있는 자리."""
    vids = [int(v) for v in vids if v]
    if not vids:
        return set()
    q = ("SELECT t.clicked_id, t.contents FROM user_text_asset t WHERE t.text_type='VERS_NOTE' AND "
         + _NOTE_ALIVE_SQL + " AND t.clicked_id IN (%s)" % ','.join('?' * len(vids)))
    return {r[0] for r in conn.execute(q, vids) if not is_ai_note(r[1]) and _note_body(r[1])}


def term_name(conn, entity_id, lang='KO'):
    r = conn.execute(
        "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME' AND clicked_id=?"
        " AND record_status='LIVE' AND UPPER(lang_code) IN (?, 'EN', 'KO')"
        " ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
        (entity_id, (lang or 'KO').upper(), (lang or 'KO').upper())).fetchone()
    return (r[0] if r and r[0] else '#%s' % entity_id)


#: 연구자료 닻의 갈래 — (열쇠, 담긴 표, 이름 칸, 본문 표, 본문의 닻 칸).
#: ★ `USER_REF` = 내 연구자료(개인 DB) · `REF_UNIT` = 자료집 글(sys).
REF_KINDS = ('USER_REF', 'REF_UNIT', 'BOOK_UNIT')
#: ★ 2026-10-13 docs/1.txt 81 — `BOOK_UNIT:<unit_id>` = 도서·설교 **편** 닻(도서 묵상 AI 도우미).
#:   연구/설교노트 갈래(REF)의 닻 하나로 산다 — 새 갈래를 세우지 않고 재료·업무만 더한다.
#: 도서 편 재료는 **A4 한 장** 이하(사용자 「A4 1장을 넘어가면 안된다」) — 한중일 글 1,800자 · 그 밖 3,600자.
BOOK_A4 = {'KO': 1800, 'JA': 1800, 'ZH': 1800, 'ZHT': 1800}
BOOK_A4_DEFAULT = 3600


def book_unit_text(conn, unit_id, lang='KO'):
    """그 편의 읽을 글 `(글, 언어)` — 그 언어 번역 → (영어면) 현대 영어 → 원문."""
    lg = (lang or 'KO').upper()
    order = [('TRANSLATED', lg)] + ([('MODERN_EN', 'EN')] if lg == 'EN' else []) + [('ORIGINAL', None)]
    for var, l2 in order:
        q = ("SELECT body_text, UPPER(lang_code) FROM sys_book_unit_text WHERE unit_id=? AND text_variant=?"
             " AND COALESCE(record_status,'LIVE')='LIVE'" + (" AND UPPER(lang_code)=?" if l2 else "") +
             " AND TRIM(COALESCE(body_text,''))<>'' LIMIT 1")
        r = conn.execute(q, (unit_id, var, l2) if l2 else (unit_id, var)).fetchone()
        if r:
            return (r[0] or '').strip(), r[1]
    return '', ''


def book_unit_fits(conn, unit_id, lang='KO'):
    """그 편이 A4 한 장 안인가 — 도서 묵상 AI 도우미를 열 수 있는 편인가(81)."""
    body, bl = book_unit_text(conn, unit_id, lang)
    return bool(body) and len(body) <= BOOK_A4.get(bl, BOOK_A4_DEFAULT)


def ref_split(anchor):
    """`'USER_REF:175'` → `('USER_REF', 175)`. 모르는 꼴이면 `(None, None)`."""
    try:
        k, v = str(anchor or '').split(':', 1)
        k = k.strip().upper()
        if k in REF_KINDS:
            return k, int(v)
    except Exception:                                     # noqa: BLE001
        pass
    return None, None


def ref_name(conn, anchor, lang='KO'):
    """연구자료 닻의 **제목** — 그 언어 글이 있으면 그것, 없으면 목록 이름.

    ⚠ 자료집 글은 후보 목록이 **자료집 이름을 앞에 붙여** 보이고 여기서는 글 제목만
      낸다(닻 라벨은 좁은 자리다) — 같은 글을 가리키는 것은 번호가 보장한다.
    """
    k, rid = ref_split(anchor)
    if not k:
        return ''
    lg = (lang or 'KO').upper()
    try:
        if k == 'BOOK_UNIT':
            import book_label
            r = conn.execute("SELECT book_id, sequence FROM sys_book_unit WHERE unit_id=?", (rid,)).fetchone()
            if not r:
                return ''
            bt = book_label.book_title(conn, r[0], lg) or ''
            ut = book_label.unit_title(conn, rid, lg, str(r[1] or '')) or ''
            return ' · '.join(x for x in (bt, ut) if x)
        if k == 'USER_REF':
            r = conn.execute("SELECT title FROM user_ref_text WHERE ref_id=? AND lang_code=?",
                             (rid, lg)).fetchone()
            if r and (r[0] or '').strip():
                return r[0].strip()
            r = conn.execute("SELECT title FROM user_ref_asset WHERE ref_id=?", (rid,)).fetchone()
            return (r[0] or '').strip() if r else ''
        r = conn.execute("SELECT title FROM sys_ref_text WHERE ref_unit_id=? AND lang_code=?"
                         " AND COALESCE(title,'')<>'' LIMIT 1", (rid, lg)).fetchone()
        if r and (r[0] or '').strip():
            return r[0].strip()
        r = conn.execute("SELECT unit_label FROM sys_ref_unit WHERE ref_unit_id=?", (rid,)).fetchone()
        return (r[0] or '').strip() if r else ''
    except Exception:                                     # noqa: BLE001
        return ''


#: 연구자료 재료에 실을 본문 상한 — 긴 글을 통째로 보내면 한도를 먹는다.
REF_BODY_MAX = 6000


def materials_ref(conn, anchor, lang='KO'):
    """연구자료 재료 — 제목 · 갈래 · 본문(상한) · 그 글에 걸린 구절.

    ⚠ **잘랐으면 그렇게 적는다**(§0-1) — 조용히 자르면 AI 가 뒷부분을 없는 것으로 읽는다.
    """
    k, rid = ref_split(anchor)
    lg = (lang or 'KO').upper()
    out = {}
    if not k:
        return out
    if k == 'BOOK_UNIT':
        return _materials_book(conn, rid, lg)
    out['연구자료'] = ref_name(conn, anchor, lg)
    out['갈래'] = '내 연구자료' if k == 'USER_REF' else '자료집 글'
    body = ''
    try:
        if k == 'USER_REF':
            r = conn.execute("SELECT body_text FROM user_ref_text WHERE ref_id=? AND lang_code=?",
                             (rid, lg)).fetchone()
            if not (r and (r[0] or '').strip()):
                r = conn.execute("SELECT body_text FROM user_ref_text WHERE ref_id=?"
                                 " ORDER BY lang_code LIMIT 1", (rid,)).fetchone()
            body = (r[0] or '') if r else ''
        else:
            r = conn.execute("SELECT body_text FROM sys_ref_text WHERE ref_unit_id=? AND lang_code=?",
                             (rid, lg)).fetchone()
            if not (r and (r[0] or '').strip()):
                r = conn.execute("SELECT body_text FROM sys_ref_text WHERE ref_unit_id=?"
                                 " ORDER BY lang_code LIMIT 1", (rid,)).fetchone()
            body = (r[0] or '') if r else ''
            if not body.strip():
                # ⚠⚠ **문답 자료집은 본문이 `sys_ref_text` 에 없다** — 하이델베르크·WSC 는
                #   `unit_question`·`unit_answer` **칸**이 본문이다(§0-5 그 자리 · 실측
                #   `sys_ref_text` 0행). 여기서 안 읽으면 재료가 제목뿐이다.
                q2 = conn.execute("SELECT unit_question, unit_answer FROM sys_ref_unit"
                                  " WHERE ref_unit_id=?", (rid,)).fetchone()
                if q2:
                    body = NL.join([x.strip() for x in (q2[0] or '', q2[1] or '') if (x or '').strip()])
    except Exception:                                     # noqa: BLE001
        body = ''
    body = (body or '').strip()
    if len(body) > REF_BODY_MAX:
        body = body[:REF_BODY_MAX] + NL + '(여기까지 — 글이 길어 잘랐습니다)'
    if body:
        out['본문'] = body
    refs = ref_verses(conn, anchor, lg)
    if refs:
        out['이 글에 걸린 구절'] = ', '.join(refs)
    return out


def _materials_book(conn, unit_id, lang='KO'):
    """도서 편 재료 — 책·지은이·편 · 본문(A4 한 장 이하) · 핵심 구절과 그 본문(81).
    ⚠ A4 를 넘는 편은 자르고 **잘랐다고 적는다**(화면은 애초에 그런 편에서 이 도우미를 안 연다)."""
    out = {}
    try:
        import book_label
        r = conn.execute("SELECT u.book_id, u.sequence, u.start_vid, a.author, a.pub_year FROM sys_book_unit u"
                         " JOIN sys_book_asset a ON a.book_id=u.book_id WHERE u.unit_id=?", (unit_id,)).fetchone()
        if not r:
            return out
        bid, seq, svid, author, year = r
        rt = conn.execute("SELECT author FROM sys_book_asset_text WHERE book_id=? AND UPPER(lang_code)=?",
                          (bid, lang)).fetchone()
        out['도서'] = book_label.book_title(conn, bid, lang) or ''
        out['지은이'] = ', '.join(str(x) for x in ((rt[0] if rt and rt[0] else author), year) if x)
        out['편'] = book_label.unit_title(conn, unit_id, lang, str(seq or '')) or ''
        body, bl = book_unit_text(conn, unit_id, lang)
        cap = BOOK_A4.get(bl, BOOK_A4_DEFAULT)
        if len(body) > cap:
            body = body[:cap] + NL + '(여기까지 — A4 한 장을 넘어 잘랐습니다)'
        if body:
            out['본문'] = body
        if svid:
            lab = range_label(conn, svid, None, lang)
            try:
                import db_cite_gate
                ver = db_cite_gate.version_for(lang) or 'BSB'
                if isinstance(ver, (tuple, list)):
                    ver = ver[0]
            except Exception:                             # noqa: BLE001
                ver = 'BSB'
            tv = conn.execute("SELECT verse_text FROM bible_content WHERE verse_id=? AND version_code=?",
                              (svid, ver)).fetchone()
            out['핵심 구절'] = ('%s %s' % (lab, (tv[0] if tv and tv[0] else ''))).strip()
    except Exception as e:                                # noqa: BLE001
        print('[ai book material] %s' % e)
    return out


def ref_verses(conn, anchor, lang='KO', limit=20):
    """그 연구자료에 걸린 구절 약명 — 없으면 빈 목록(지어내지 않는다)."""
    k, rid = ref_split(anchor)
    if not k:
        return []
    out = []
    try:
        if k == 'USER_REF':
            # ⚠ 칸 이름은 `target_id` 다(`verse_id` 가 아니다 — 실측으로 확인).
            rows = conn.execute(
                "SELECT target_id FROM user_ref_asset_link WHERE ref_id=? AND link_kind='VERSE'"
                " AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY sort_order LIMIT ?",
                (rid, int(limit))).fetchall()
            if not rows:
                rows = conn.execute("SELECT verse_id FROM user_ref_asset WHERE ref_id=?"
                                    " AND verse_id IS NOT NULL", (rid,)).fetchall()
        else:
            rows = conn.execute(
                "SELECT start_vid FROM sys_ref_verse_link WHERE ref_unit_id=?"
                " AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY sort_order LIMIT ?",
                (rid, int(limit))).fetchall()
    except Exception:                                     # noqa: BLE001
        rows = []
    for r in rows:
        try:
            lbl = _label(conn, int(r[0]), lang)
            if lbl:
                out.append(lbl)
        except Exception:                                 # noqa: BLE001
            pass
    return out


def _rel_codes():
    """연결 갈래 → [이름, 뜻] — `db_ai_job.REL_CODES` 한 표에서(두 벌을 두지 않는다)."""
    try:
        import db_ai_job as _J
        return {c[0]: [c[1], c[2]] for c in _J.REL_CODES}
    except Exception:                                     # noqa: BLE001
        return {}


def lemma_label(conn, strong):
    """원어 낱말 이름 — 「חֶסֶד chesed (H2617)」."""
    r = conn.execute("SELECT form, translit FROM sys_lemma_master WHERE strong=?", (strong,)).fetchone()
    return ('%s %s (%s)' % (r[0] or '', r[1] or '', strong)).strip() if r else strong


def materials_lemma(conn, strong, lang='KO', n_verses=8):
    """원어 낱말 재료 — 원문 · 음역 · 뜻 · 뜻풀이 · 출현 수 · 대표 구절(개역한글) · 내 원어 설명. sys 읽기만."""
    lg = (lang or 'KO').upper()
    r = conn.execute("SELECT form, translit, pos, gloss, def_en, occurrences, verse_ids FROM sys_lemma_master"
                     " WHERE strong=?", (strong,)).fetchone()
    if not r:
        return {'원어 낱말': strong}
    out = {'원어 낱말': '%s · %s · %s' % (r[0] or '', r[1] or '', strong)}
    if r[2]:
        out['품사'] = r[2]
    if r[3]:
        out['뜻'] = r[3]
    if r[4] and r[4] != r[3]:
        out['뜻풀이'] = r[4][:1500]
    if r[5]:
        out['성경에 나오는 횟수'] = str(r[5])
    try:
        import db_lex_link as LL
        vids = LL.verses_of(conn, strong) or []
    except Exception:                                     # noqa: BLE001
        vids = []
    lines = []
    for v in list(vids)[:n_verses]:
        t = _text(conn, v, 'KRV', 'KO')
        if t:
            lines.append('%s %s' % (_label(conn, v, lg), t))
    if lines:
        out['대표 구절 (개역한글)'] = NL.join(lines)
    mine = lemma_note(conn, strong, lg)
    if mine.strip():
        out['내 원어 설명'] = mine[:2500]
    return out


def lemma_save(conn, strong, lang, text):
    """원어 설명(내 글)을 담는다 → True. 덮개(`overlay_edit`) · 비면 안 담는다."""
    k = lemma_key(strong)
    t = (text or '').strip()
    if k is None or not t:
        return False
    import overlay_edit as OE
    OE.save_mine(conn, LEMMA_TEXT, k, lang, None, t)
    return True


def link_title(conn, link_id, lang='KO'):
    """연결 하나의 이름 — 「창 1:3 ↔ 창 1:14」."""
    r = conn.execute("SELECT clicked_id, target_id FROM sys_link_asset WHERE sys_link_id=?", (int(link_id),)).fetchone()
    if not r:
        return ''
    return '%s ↔ %s' % (_label(conn, r[0], lang), _label(conn, r[1], lang))


def materials_link(conn, link_id, lang='KO'):
    """연결 하나의 재료 — 두 구절(개역한글 · BSB) · 연결 갈래(이름 · 뜻) · 지금 연결설명문. sys 읽기만(설명문은 덮개 적용)."""
    lg = (lang or 'KO').upper()
    r = conn.execute("SELECT clicked_id, target_id, COALESCE(rel_code,'') FROM sys_link_asset WHERE sys_link_id=?",
                     (int(link_id),)).fetchone()
    if not r:
        return {}
    out = {}
    for name, v in (('구절', r[0]), ('연결 구절', r[1])):
        lines = [_label(conn, v, lg)]
        for ver, vl in (('KRV', 'KO'), ('BSB', 'EN')):
            t = _text(conn, v, ver, vl)
            if t:
                lines.append('%s: %s' % (ver, t))
        out[name] = NL.join(lines)
    try:
        import db_ai_job as _J
        rc = {c[0]: c for c in _J.REL_CODES}.get(r[2])
        if rc:
            out['연결 갈래'] = '%s (%s) — %s' % (rc[1], rc[0], rc[2])
    except Exception:                                     # noqa: BLE001
        pass
    try:
        import overlay_edit as OE
        _v, st, txt = OE.target_state(conn, 'VERS_VERS_DESC', int(link_id), lg, '')
        if txt and st in ('SYS', 'EDIT', 'NEW'):
            out['지금 연결설명문'] = txt[:2000]
    except Exception:                                     # noqa: BLE001
        pass
    return out


def materials_term(conn, entity_id, lang='KO', n_verses=8):
    """용어(주요용어) 재료 — 이름 · 유형 · 설명문 · 원어 · 대표 구절 · 용례 수. sys 읽기만."""
    lg = (lang or 'KO').upper()
    out = {'용어': term_name(conn, entity_id, lg)}
    r = conn.execute("SELECT entity_type FROM sys_entity_master WHERE entity_id=?", (entity_id,)).fetchone()
    if r:
        out['유형'] = r[0] or ''
    d = conn.execute(
        "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_DESC' AND clicked_id=?"
        " AND record_status='LIVE' AND UPPER(lang_code) IN (?, 'EN', 'KO')"
        " ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
        (entity_id, lg, lg)).fetchone()
    if d and d[0]:
        out['설명문 (앱)'] = d[0][:2500]
    # ★ 2026-10-14 — 내가 고쳐 둔 설명문(덮개)도 함께 — 그래야 「내 설명문을 다듬어 줘」가 된다(폰·PC 같게)
    try:
        mine = term_desc_current(conn, entity_id, lg)
        if mine and mine.strip() and mine.strip() != (d[0] if d and d[0] else '').strip():
            out['내 설명문'] = mine[:2500]
    except Exception:                                     # noqa: BLE001
        pass
    try:
        lem = conn.execute(
            "SELECT lang_code, strong, COALESCE(translit,''), COALESCE(gloss,'') FROM sys_entity_lemma"
            " WHERE entity_id=? ORDER BY lemma_id", (entity_id,)).fetchall()
        if lem:
            out['원어'] = NL.join('%s %s %s %s' % (a, b, c, d_) for a, b, c, d_ in lem)
    except Exception:                                     # noqa: BLE001
        pass
    try:
        keys = conn.execute(
            "SELECT ev.verse_id FROM sys_entity_verse ev JOIN bible_index b ON b.verse_id=ev.verse_id"
            " WHERE ev.entity_id=? AND ev.record_status='LIVE'"
            " ORDER BY ev.is_key DESC, ev.sort_order, b.sort_order LIMIT ?", (entity_id, int(n_verses))).fetchall()
        lines = []
        for (v,) in keys:
            t = _text(conn, v, 'KRV', 'KO')
            if t:
                lines.append('%s %s' % (_label(conn, v, lg), t))
        if lines:
            out['대표 구절 (개역한글)'] = NL.join(lines)
        else:
            # 인물·장소는 절이 아니라 **단락**에 걸려 있다(sys_entity_pericope) — 단락 범위와 첫 절
            per = conn.execute(
                "SELECT p.start_vid, p.end_vid FROM sys_entity_pericope ep"
                " JOIN sys_pericope_asset p ON p.pericope_id=ep.pericope_id"
                " WHERE ep.entity_id=? AND ep.record_status='LIVE' AND p.record_status='LIVE'"
                " ORDER BY ep.is_milestone DESC, ep.importance DESC, p.sort_order LIMIT ?",
                (entity_id, int(n_verses))).fetchall()
            pl = []
            for a, b in per:
                t = _text(conn, a, 'KRV', 'KO')
                pl.append('%s — %s' % (range_label(conn, a, b, lg), t))
            if pl:
                out['관련 단락 (첫 절 · 개역한글)'] = NL.join(pl)
        n = conn.execute("SELECT COUNT(*) FROM sys_entity_verse WHERE entity_id=? AND record_status='LIVE'",
                         (entity_id,)).fetchone()[0]
        if n:
            out['용례 수'] = str(n)
    except Exception:                                     # noqa: BLE001
        pass
    return out


def render(mat):
    return NL.join('[%s]%s%s' % (k, NL, v) for k, v in mat.items())


# ══════════════════════════════════════════════════════════════════════
#  프롬프트 예제 — 11언어 씨앗(사람이 고친 것은 안 덮는다)
# ══════════════════════════════════════════════════════════════════════
#: ★ 2026-10-21 창 1:31 성경공부 실측 — 다섯 물음의 답을 833자로 줄이고 마지막 물음만 남겼다 ⇒ 다룬 것을 **빠짐없이**
MERGE_KO = ('아래 대화 전체를 [구절] 에 대한 한 편의 글로 엮어 주세요. 대화에서 다룬 물음과 답을 하나도 빠뜨리지 말고 '
            '다룬 차례대로 모두 담으세요. 답의 설명은 요약하거나 줄이지 말고 거의 그대로 옮기되, 여러 답에서 겹치는 '
            '문장만 하나로 합치고 대화체는 걷어 주세요. 글 제목은 맨 위에 하나만 두고, 물음 하나하나를 그 아래 차례 번호가 '
            '이어지는 큰 단락으로 엮으세요. 문장 끝은 한 가지 말투로 맞추세요. 새 내용을 보태지 마세요.')
MERGE_EN = ('Weave the whole conversation below into one text on [passage]. Include every question and answer that was '
            'discussed, in the order they came, leaving nothing out. Do not summarise or shorten the explanations — carry '
            'them over almost as they are, merging only sentences repeated across answers and removing the dialogue form. '
            'Put a single title at the top and make each question one numbered main section under it, numbering '
            'continuously. Keep one consistent register throughout. Add nothing new.')
MERGE_OLD_KO = ('아래 대화를 [구절] 에 대한 한 편의 글로 정리해 주세요. 질문과 답의 흐름을 살리되 대화체를 걷고, '
                '제가 이해한 것과 남은 물음을 끝에 따로 적어 주세요. 새 내용을')


SEED_PROMPTS = {
 'ASK': {
  'KO': ('이 구절의 배경', '[구절] 의 시대·저자·앞뒤 흐름을 평신도가 읽기 쉬운 말로 설명해 주세요. 본문에 있는 것과 학자들의 추정을 구분해 주세요. 마지막에 이 구절이 오늘 우리에게 묻는 것 하나를 적어 주세요.'),
  'EN': ('Background of this passage', 'Explain the setting, author, and surrounding flow of [passage] in plain language for a lay reader. Separate what the text itself says from what scholars infer. End with one question this passage asks us today.'),
  'JA': ('この箇所の背景', '[聖句] の時代・著者・前後の流れを、信徒が読みやすい言葉で説明してください。本文にあることと学者の推定を区別してください。最後に、この箇所が今日の私たちに問いかけることを一つ書いてください。'),
  'ZH': ('这段经文的背景', '请用平信徒易读的语言说明 [经文] 的时代、作者和前后脉络。请区分经文本身所说的和学者的推断。最后写出这段经文今天向我们提出的一个问题。'),
  'ZHT': ('這段經文的背景', '請用平信徒易讀的語言說明 [經文] 的時代、作者和前後脈絡。請區分經文本身所說的和學者的推斷。最後寫出這段經文今天向我們提出的一個問題。'),
  'DE': ('Hintergrund dieser Stelle', 'Erkläre Zeit, Verfasser und den Zusammenhang von [Stelle] in einfacher Sprache für Laien. Trenne, was der Text sagt, von dem, was Gelehrte vermuten. Schließe mit einer Frage, die diese Stelle uns heute stellt.'),
  'FR': ('Contexte de ce passage', 'Explique l’époque, l’auteur et le fil du contexte de [passage] dans un langage simple pour un lecteur laïc. Distingue ce que dit le texte de ce que les savants supposent. Termine par une question que ce passage nous pose aujourd’hui.'),
  'ES': ('Trasfondo de este pasaje', 'Explica la época, el autor y el hilo del contexto de [pasaje] en un lenguaje sencillo para un lector laico. Distingue lo que dice el texto de lo que suponen los estudiosos. Termina con una pregunta que este pasaje nos hace hoy.'),
  'PT': ('Contexto desta passagem', 'Explique a época, o autor e o fio do contexto de [passagem] em linguagem simples para um leitor leigo. Distinga o que o texto diz do que os estudiosos supõem. Termine com uma pergunta que esta passagem nos faz hoje.'),
  'RU': ('Контекст этого отрывка', 'Объясни эпоху, автора и ход контекста [отрывок] простым языком для мирянина. Отдели то, что говорит сам текст, от предположений учёных. Закончи одним вопросом, который этот отрывок задаёт нам сегодня.'),
  'AR': ('خلفية هذا المقطع', 'اشرح زمن [المقطع] وكاتبه وسياقه بلغة بسيطة للقارئ العادي. ميّز بين ما يقوله النص وما يفترضه العلماء. اختم بسؤال واحد يطرحه هذا المقطع علينا اليوم.'),
 },
 'ORIG': {
  'KO': ('이 구절의 원어 낱말 설명', '[구절] 에 쓰인 히브리어·헬라어 낱말 가운데 뜻을 아는 것이 도움이 되는 것 두세 개를 선택해 설명해 주세요. 낱말마다 한글 음역과 원어를 함께 적고, 그 낱말이 성경 다른 곳에서 어떻게 쓰이는지 한 예를 들어 주세요. 번역으로는 드러나지 않는 것이 있으면 짚어 주세요.'),
  'EN': ('Explain the original words', 'From [passage], pick two or three Hebrew or Greek words that are worth knowing and explain them. For each word give the transliteration with the original spelling, and one example of how it is used elsewhere in Scripture. Point out anything the translation does not show.'),
  'JA': ('この箇所の原語の説明', '[聖句] に使われているヘブライ語・ギリシア語の語のうち、意味を知ると助けになる二、三語を選んで説明してください。語ごとに音訳と原語を併記し、その語が聖書の他の箇所でどう使われているか一例を挙げてください。翻訳では見えないことがあれば指摘してください。'),
  'ZH': ('这段经文的原文词语说明', '请从 [经文] 中挑出两三个值得了解的希伯来文或希腊文词语并加以说明。每个词请同时写出音译与原文拼写，并举一个该词在圣经别处的用例。若有翻译无法呈现之处，请指出。'),
  'ZHT': ('這段經文的原文詞語說明', '請從 [經文] 中挑出兩三個值得了解的希伯來文或希臘文詞語並加以說明。每個詞請同時寫出音譯與原文拼寫，並舉一個該詞在聖經別處的用例。若有翻譯無法呈現之處，請指出。'),
  'DE': ('Die Wörter des Urtexts erklären', 'Wähle aus [Stelle] zwei oder drei hebräische oder griechische Wörter, deren Bedeutung hilfreich ist, und erkläre sie. Nenne bei jedem Wort die Umschrift samt Originalschreibung und ein Beispiel, wie es an anderer Stelle der Schrift gebraucht wird. Weise darauf hin, was die Übersetzung nicht zeigt.'),
  'FR': ('Expliquer les mots originaux', 'Dans [passage], choisis deux ou trois mots hébreux ou grecs qu’il vaut la peine de connaître et explique-les. Pour chacun, donne la translittération avec l’orthographe originale et un exemple de son emploi ailleurs dans l’Écriture. Signale ce que la traduction ne montre pas.'),
  'ES': ('Explicar las palabras originales', 'De [pasaje], elige dos o tres palabras hebreas o griegas que valga la pena conocer y explícalas. De cada una da la transliteración junto con la grafía original y un ejemplo de su uso en otro lugar de la Escritura. Señala lo que la traducción no muestra.'),
  'PT': ('Explicar as palavras originais', 'De [passagem], escolha duas ou três palavras hebraicas ou gregas que valha a pena conhecer e explique-as. De cada uma dê a transliteração junto com a grafia original e um exemplo de seu uso em outro lugar da Escritura. Aponte o que a tradução não mostra.'),
  'RU': ('Объяснить слова оригинала', 'Выбери из [отрывок] два-три еврейских или греческих слова, которые стоит знать, и объясни их. Для каждого слова приведи транслитерацию вместе с написанием на языке оригинала и один пример его употребления в другом месте Писания. Укажи то, чего не видно в переводе.'),
  'AR': ('اشرح كلمات الأصل في هذا المقطع', 'اختر من [المقطع] كلمتين أو ثلاثًا عبرية أو يونانية يفيد معرفة معناها واشرحها. لكل كلمة اذكر النقل الصوتي مع الكتابة الأصلية، ومثالًا واحدًا على استعمالها في موضع آخر من الكتاب. وبيّن ما لا تظهره الترجمة.'),
 },
 'SIMILAR': {
  'KO': ('뜻이 이어지는 구절 찾기', '[구절] 과 뜻이 이어지는 다른 성경 구절을 찾아 주세요. 구절마다 어디가 어떻게 이어지는지(같은 낱말인가, 같은 사건인가, 예언과 성취인가, 대조인가) 한 문장으로 적어 주세요. 억지로 잇지 말고 본문에 근거가 있는 것만 들어 주세요.'),
  'EN': ('Find passages that connect', 'Find other passages of Scripture whose meaning connects with [passage]. For each one write in a single sentence how it connects — the same word, the same event, prophecy and fulfilment, or a contrast. Do not force a link; give only what the text itself supports.'),
  'JA': ('意味がつながる聖句を探す', '[聖句] と意味がつながる他の聖句を探してください。それぞれについて、どこがどうつながるのか（同じ語か、同じ出来事か、預言と成就か、対比か）を一文で書いてください。無理につなげず、本文に根拠のあるものだけを挙げてください。'),
  'ZH': ('查找意思相通的经文', '请找出与 [经文] 意思相通的其他圣经经文。每一处请用一句话写明如何相通（同一个词、同一件事、预言与应验，还是对比）。不要勉强牵连，只举本文有依据的。'),
  'ZHT': ('查找意思相通的經文', '請找出與 [經文] 意思相通的其他聖經經文。每一處請用一句話寫明如何相通（同一個詞、同一件事、預言與應驗，還是對比）。不要勉強牽連，只舉本文有依據的。'),
  'DE': ('Stellen finden, die zusammenhängen', 'Finde andere Schriftstellen, deren Sinn mit [Stelle] zusammenhängt. Schreibe zu jeder in einem Satz, wie sie zusammenhängt — dasselbe Wort, dasselbe Ereignis, Verheißung und Erfüllung oder ein Gegensatz. Erzwinge keine Verbindung; nenne nur, was der Text selbst trägt.'),
  'FR': ('Trouver les passages liés', 'Trouve d’autres passages de l’Écriture dont le sens rejoint [passage]. Pour chacun, écris en une phrase comment il rejoint — le même mot, le même événement, prophétie et accomplissement, ou un contraste. Ne force pas le lien ; ne donne que ce que le texte soutient.'),
  'ES': ('Buscar pasajes relacionados', 'Busca otros pasajes de la Escritura cuyo sentido se una con [pasaje]. De cada uno escribe en una frase cómo se une: la misma palabra, el mismo suceso, profecía y cumplimiento, o un contraste. No fuerces el vínculo; da solo lo que el texto sostiene.'),
  'PT': ('Buscar passagens relacionadas', 'Busque outras passagens da Escritura cujo sentido se una a [passagem]. De cada uma escreva em uma frase como se une: a mesma palavra, o mesmo acontecimento, profecia e cumprimento, ou um contraste. Não force o vínculo; dê apenas o que o texto sustenta.'),
  'RU': ('Найти связанные отрывки', 'Найди другие места Писания, смысл которых связан с [отрывок]. О каждом напиши одним предложением, как именно связан — то же слово, то же событие, пророчество и исполнение или противопоставление. Не связывай насильно; приводи только то, что подтверждает сам текст.'),
  'AR': ('ابحث عن مقاطع متصلة المعنى', 'ابحث عن مقاطع أخرى من الكتاب يتصل معناها بـ [المقطع]. اكتب عن كل واحد في جملة واحدة كيف يتصل: الكلمة نفسها، أو الحدث نفسه، أو النبوءة وتحققها، أو التقابل. لا تربط قسرًا؛ واذكر ما يدعمه النص فقط.'),
 },
 'APPLY': {
  'KO': ('묵상 적용', '[구절] 을 오늘 제 삶에 놓고 묵상하도록 도와 주세요. 이 구절이 하나님에 대해 무엇을 보여 주는지 먼저 한 문단으로 적고, 그다음에 이 구절이 사람의 마음·말·관계·일 가운데 어느 자리를 건드리는지 짚어 주세요. 마지막에 제가 스스로 답할 물음 세 개를 주세요. ⚠ 제가 무엇을 해야 하는지 대신 정해 주지는 마세요 — 그것은 제가 기도하며 정할 몫입니다.'),
  'EN': ('Applying this in meditation', 'Help me meditate on [passage] in my life today. First write one paragraph on what this passage shows about God, then point out which part of a person it touches — the heart, the words, relationships, or work. End with three questions for me to answer myself. Do not decide for me what I should do; that is mine to settle in prayer.'),
  'JA': ('黙想への適用', '[聖句] を今日の私の生活に置いて黙想できるよう助けてください。まずこの箇所が神について何を示すかを一段落で書き、次にこの箇所が人の心・言葉・関係・仕事のどこに触れるかを示してください。最後に私が自分で答える問いを三つください。私が何をすべきかを代わりに決めないでください。それは私が祈って定めることです。'),
  'ZH': ('默想应用', '请帮助我把 [经文] 放在今天的生活中默想。请先用一段写出这段经文显明了神的什么，然后指出它触及人的哪一处：内心、言语、关系还是工作。最后给我三个由我自己回答的问题。请不要替我决定该做什么，那是我要祷告定下的。'),
  'ZHT': ('默想應用', '請幫助我把 [經文] 放在今天的生活中默想。請先用一段寫出這段經文顯明了神的什麼，然後指出它觸及人的哪一處：內心、言語、關係還是工作。最後給我三個由我自己回答的問題。請不要替我決定該做什麼，那是我要禱告定下的。'),
  'DE': ('Anwendung in der Betrachtung', 'Hilf mir, [Stelle] in meinem heutigen Leben zu betrachten. Schreibe zuerst einen Abschnitt darüber, was diese Stelle über Gott zeigt, und weise dann darauf hin, welchen Bereich eines Menschen sie berührt — Herz, Worte, Beziehungen oder Arbeit. Schließe mit drei Fragen, die ich mir selbst beantworte. Entscheide nicht für mich, was ich tun soll; das klärt sich im Gebet.'),
  'FR': ('Appliquer dans la méditation', 'Aide-moi à méditer [passage] dans ma vie aujourd’hui. Écris d’abord un paragraphe sur ce que ce passage montre de Dieu, puis indique quel domaine de la personne il touche — le cœur, les paroles, les relations ou le travail. Termine par trois questions auxquelles je répondrai moi-même. Ne décide pas à ma place ce que je dois faire ; cela se règle dans la prière.'),
  'ES': ('Aplicación en la meditación', 'Ayúdame a meditar [pasaje] en mi vida de hoy. Escribe primero un párrafo sobre lo que este pasaje muestra de Dios, y luego señala qué área de la persona toca: el corazón, las palabras, las relaciones o el trabajo. Termina con tres preguntas que yo mismo responderé. No decidas por mí qué debo hacer; eso se resuelve en oración.'),
  'PT': ('Aplicação na meditação', 'Ajude-me a meditar [passagem] na minha vida hoje. Escreva primeiro um parágrafo sobre o que esta passagem mostra de Deus e depois aponte que área da pessoa ela toca: o coração, as palavras, os relacionamentos ou o trabalho. Termine com três perguntas que eu mesmo responderei. Não decida por mim o que devo fazer; isso se resolve em oração.'),
  'RU': ('Применение в размышлении', 'Помоги мне размышлять над [отрывок] в моей сегодняшней жизни. Сначала напиши один абзац о том, что этот отрывок показывает о Боге, затем укажи, какую область человека он затрагивает — сердце, слова, отношения или труд. Закончи тремя вопросами, на которые я отвечу сам. Не решай за меня, что мне делать; это я определю в молитве.'),
  'AR': ('تطبيق في التأمل', 'ساعدني أن أتأمل [المقطع] في حياتي اليوم. اكتب أولًا فقرة واحدة عما يُظهره هذا المقطع عن الله، ثم بيّن أي جانب من الإنسان يلمسه: القلب أم الكلام أم العلاقات أم العمل. واختم بثلاثة أسئلة أجيب عنها بنفسي. ولا تقرر عني ما ينبغي أن أفعله؛ فذلك ما أحدده في الصلاة.'),
 },
 'CONTEXT': {
  'KO': ('문맥설명', '[구절] 이 그 단락 안에서 어디에 놓였는지 설명해 주세요. 이 단락이 어디서 시작해서 어디서 끝나는지, 논지가 어떤 걸음으로 이어지는지, 이 구절이 그 걸음 가운데 어느 자리인지(전제인가, 근거인가, 결론인가, 예인가, 반전인가) 적어 주세요. 앞 구절과 뒤 구절이 없으면 이 구절을 어떻게 잘못 읽게 되는지도 한 줄로 짚어 주세요.'),
  'EN': ('Explain the context', 'Explain where [passage] sits within its paragraph. Say where the paragraph begins and ends, what steps the argument moves through, and which step this verse is — a premise, a ground, a conclusion, an example, or a turn. Add one line on how this verse gets misread when the verses before and after it are missing.'),
  'JA': ('文脈の説明', '[聖句] がその段落の中でどこに置かれているか説明してください。その段落がどこから始まりどこで終わるか、論旨がどんな歩みでつながるか、この聖句がその歩みのどの位置か（前提か、根拠か、結論か、例か、転換か）を書いてください。前後の節がないとこの聖句をどう読み誤るかも一行で示してください。'),
  'ZH': ('上下文说明', '请说明 [经文] 在所属段落中的位置。请写出这个段落从哪里开始、到哪里结束，论述经过哪些步骤，而这节经文处在其中哪一步（是前提、依据、结论、例证，还是转折）。并用一行指出：若缺了前后经节，这节经文会被如何误读。'),
  'ZHT': ('上下文說明', '請說明 [經文] 在所屬段落中的位置。請寫出這個段落從哪裡開始、到哪裡結束，論述經過哪些步驟，而這節經文處在其中哪一步（是前提、依據、結論、例證，還是轉折）。並用一行指出：若缺了前後經節，這節經文會被如何誤讀。'),
  'DE': ('Den Zusammenhang erklären', 'Erkläre, wo [Stelle] innerhalb ihres Abschnitts steht. Sage, wo der Abschnitt beginnt und endet, welche Schritte der Gedankengang geht und welcher Schritt dieser Vers ist — Voraussetzung, Begründung, Schluss, Beispiel oder Wendung. Füge eine Zeile hinzu, wie dieser Vers missverstanden wird, wenn die Verse davor und danach fehlen.'),
  'FR': ('Expliquer le contexte', 'Explique où se situe [passage] dans son paragraphe. Dis où le paragraphe commence et finit, par quelles étapes l’argument avance, et quelle étape est ce verset — une prémisse, un appui, une conclusion, un exemple ou un retournement. Ajoute une ligne sur la façon dont ce verset est mal lu quand les versets qui l’entourent manquent.'),
  'ES': ('Explicar el contexto', 'Explica dónde se sitúa [pasaje] dentro de su párrafo. Di dónde empieza y acaba el párrafo, por qué pasos avanza el razonamiento y qué paso es este versículo: una premisa, un apoyo, una conclusión, un ejemplo o un giro. Añade una línea sobre cómo se lee mal este versículo cuando faltan los versículos de alrededor.'),
  'PT': ('Explicar o contexto', 'Explique onde [passagem] se situa dentro do seu parágrafo. Diga onde o parágrafo começa e termina, por que passos o raciocínio avança e que passo é este versículo: uma premissa, um apoio, uma conclusão, um exemplo ou uma virada. Acrescente uma linha sobre como este versículo é mal lido quando faltam os versículos ao redor.'),
  'RU': ('Объяснить контекст', 'Объясни, где [отрывок] стоит внутри своего абзаца. Скажи, где абзац начинается и заканчивается, какими шагами движется мысль и какой шаг — этот стих: предпосылка, основание, вывод, пример или поворот. Добавь одну строку о том, как этот стих прочитывают неверно, когда рядом нет стихов до и после.'),
  'AR': ('شرح السياق', 'اشرح موضع [المقطع] داخل الفقرة التي ينتمي إليها. بيّن أين تبدأ الفقرة وأين تنتهي، وبأي خطوات يتقدم المعنى، وأي خطوة هو هذا العدد: مقدمة أم دليل أم خاتمة أم مثال أم تحوّل. وأضف سطرًا واحدًا عن كيف يُقرأ هذا العدد قراءة خاطئة حين تغيب الأعداد السابقة واللاحقة.'),
 },
 'WHOWHERE': {
  'KO': ('인물/장소 설명', '[구절] 에 나오는 사람과 곳을 설명해 주세요. 사람마다 누구인지, 이 자리에서 무엇을 하는지, 성경 다른 곳에서는 어떻게 나오는지 적어 주세요. 곳마다 어디인지, 그 자리가 어떤 곳이었는지(지형·거리·그때 어떤 뜻을 지녔는지) 적어 주세요. 본문에 적힌 것과 다른 자료에서 온 것을 구분해 주세요. 이름이 같은 다른 사람·다른 곳과 헷갈릴 자리가 있으면 그것도 짚어 주세요.'),
  'EN': ('Who and where', 'Explain the people and places in [passage]. For each person, say who they are, what they do here, and how they appear elsewhere in Scripture. For each place, say where it is and what kind of place it was — terrain, distance, and what it meant at the time. Separate what the text states from what comes from other sources. Point out any person or place that is easily confused with another of the same name.'),
  'JA': ('人物・地名の説明', '[聖句] に出てくる人と場所を説明してください。人ごとに、だれなのか、この場面で何をしているのか、聖書の他の箇所ではどう現れるかを書いてください。場所ごとに、どこなのか、どんな所だったか（地形・距離・当時どんな意味を持ったか）を書いてください。本文に記されていることと他の資料から来たことを区別してください。同名の別人・別の地と混同しやすい箇所があれば、それも示してください。'),
  'ZH': ('人物／地名说明', '请说明 [经文] 中出现的人物和地点。每个人物请写出他是谁、在此处做什么、在圣经别处如何出现。每个地点请写出在哪里、是什么样的地方（地形、距离、当时具有什么意义）。请区分经文所记的和出自其他资料的。若有容易与同名的另一人、另一地混淆之处，也请指出。'),
  'ZHT': ('人物／地名說明', '請說明 [經文] 中出現的人物和地點。每個人物請寫出他是誰、在此處做什麼、在聖經別處如何出現。每個地點請寫出在哪裡、是什麼樣的地方（地形、距離、當時具有什麼意義）。請區分經文所記的和出自其他資料的。若有容易與同名的另一人、另一地混淆之處，也請指出。'),
  'DE': ('Personen und Orte', 'Erkläre die Personen und Orte in [Stelle]. Sage zu jeder Person, wer sie ist, was sie hier tut und wie sie an anderen Stellen der Schrift vorkommt. Sage zu jedem Ort, wo er liegt und was für ein Ort er war — Gelände, Entfernung und welche Bedeutung er damals hatte. Trenne, was der Text sagt, von dem, was aus anderen Quellen kommt. Weise auf Personen oder Orte hin, die mit gleichnamigen anderen leicht verwechselt werden.'),
  'FR': ('Personnages et lieux', 'Explique les personnes et les lieux de [passage]. Pour chaque personne, dis qui elle est, ce qu’elle fait ici et comment elle apparaît ailleurs dans l’Écriture. Pour chaque lieu, dis où il se trouve et quel genre de lieu c’était — relief, distance et ce qu’il signifiait alors. Distingue ce que dit le texte de ce qui vient d’autres sources. Signale toute personne ou tout lieu facile à confondre avec un homonyme.'),
  'ES': ('Personas y lugares', 'Explica las personas y los lugares de [pasaje]. De cada persona di quién es, qué hace aquí y cómo aparece en otros lugares de la Escritura. De cada lugar di dónde está y qué clase de lugar era: relieve, distancia y qué significaba entonces. Distingue lo que dice el texto de lo que viene de otras fuentes. Señala cualquier persona o lugar que se confunda fácilmente con otro del mismo nombre.'),
  'PT': ('Pessoas e lugares', 'Explique as pessoas e os lugares de [passagem]. De cada pessoa diga quem é, o que faz aqui e como aparece em outros lugares da Escritura. De cada lugar diga onde está e que tipo de lugar era: relevo, distância e o que significava então. Distinga o que o texto diz do que vem de outras fontes. Aponte qualquer pessoa ou lugar que se confunda facilmente com outro de mesmo nome.'),
  'RU': ('Люди и места', 'Объясни людей и места в [отрывок]. О каждом человеке скажи, кто он, что он делает здесь и как появляется в других местах Писания. О каждом месте скажи, где оно и каким местом было — рельеф, расстояние и что оно значило тогда. Отдели то, что говорит сам текст, от того, что приходит из других источников. Укажи человека или место, которые легко спутать с одноимёнными другими.'),
  'AR': ('الأشخاص والأماكن', 'اشرح الأشخاص والأماكن الواردة في [المقطع]. عن كل شخص قل من هو، وماذا يفعل هنا، وكيف يظهر في مواضع أخرى من الكتاب. وعن كل مكان قل أين يقع وأي نوع من الأماكن كان: التضاريس والمسافة وما كان يعنيه في ذلك الزمان. وميّز بين ما يقوله النص وما يأتي من مصادر أخرى. وأشِر إلى أي شخص أو مكان يسهل الخلط بينه وبين آخر يحمل الاسم نفسه.'),
 },
 'CHECK': {
  'KO': ('내가 이해한 것이 맞는가', '[구절] 을 저는 이렇게 이해했습니다: (여기에 적으세요). 이렇게 이해할 수 있는 근거, 주의할 점, 다른 해석, 함께 읽을 본문을 말해 주세요. 본문상 분명한 것 / 가능한 해석 / 논쟁이 있는 해석을 구분해 주세요.'),
  'EN': ('Is my understanding right?', 'I understand [passage] this way: (write here). Tell me the grounds for this reading, cautions, other interpretations, and passages to read alongside. Distinguish what is clear in the text / possible readings / disputed readings.'),
  'JA': ('私の理解は正しいか', '[聖句] を私はこう理解しました：（ここに書く）。この理解の根拠、注意点、別の解釈、あわせて読む本文を教えてください。本文上明らかなこと／可能な解釈／論争のある解釈を区別してください。'),
  'ZH': ('我的理解对吗', '我这样理解 [经文]：（在此写下）。请告诉我这样理解的依据、需要注意的地方、其他解释，以及可以一起读的经文。请区分经文明确的 / 可能的解释 / 有争议的解释。'),
  'ZHT': ('我的理解對嗎', '我這樣理解 [經文]：（在此寫下）。請告訴我這樣理解的依據、需要注意的地方、其他解釋，以及可以一起讀的經文。請區分經文明確的 / 可能的解釋 / 有爭議的解釋。'),
  'DE': ('Verstehe ich das richtig?', 'Ich verstehe [Stelle] so: (hier schreiben). Nenne Gründe für diese Lesart, Vorsichtspunkte, andere Deutungen und Texte, die man dazu lesen sollte. Trenne: im Text klar / mögliche Deutung / umstrittene Deutung.'),
  'FR': ('Ai-je bien compris ?', 'Je comprends [passage] ainsi : (écrire ici). Donne les fondements de cette lecture, les points de vigilance, d’autres interprétations et des textes à lire avec. Distingue : clair dans le texte / interprétation possible / interprétation débattue.'),
  'ES': ('¿Es correcta mi comprensión?', 'Entiendo [pasaje] así: (escribir aquí). Dame los fundamentos de esta lectura, precauciones, otras interpretaciones y textos para leer junto. Distingue: claro en el texto / interpretación posible / interpretación debatida.'),
  'PT': ('Entendi corretamente?', 'Entendo [passagem] assim: (escrever aqui). Dê os fundamentos desta leitura, cuidados, outras interpretações e textos para ler junto. Distinga: claro no texto / interpretação possível / interpretação debatida.'),
  'RU': ('Правильно ли я понял?', 'Я понимаю [отрывок] так: (напишите здесь). Назови основания такого прочтения, предостережения, другие толкования и тексты для совместного чтения. Раздели: ясно в тексте / возможное толкование / спорное толкование.'),
  'AR': ('هل فهمي صحيح؟', 'أفهم [المقطع] هكذا: (اكتب هنا). اذكر أسس هذا الفهم، والتنبيهات، والتفسيرات الأخرى، والنصوص التي تُقرأ معه. ميّز بين: الواضح في النص / التفسير الممكن / التفسير المختلَف فيه.'),
 },
 'COMPARE': {
  'KO': ('해석 비교', '[구절] 에 대한 서로 다른 해석을 비교해 주세요. 해석마다 주장, 주요 근거 구절, 장점, 단점, 그 해석을 따르는 대표적인 전통을 적어 주세요. 어느 하나를 정답으로 밀지 말고 나란히 놓아 주세요.'),
  'EN': ('Compare interpretations', 'Compare the different interpretations of [passage]. For each: the claim, key supporting passages, strengths, weaknesses, and the traditions that hold it. Put them side by side without pushing one as the answer.'),
  'JA': ('解釈の比較', '[聖句] についての異なる解釈を比較してください。解釈ごとに主張、主な根拠聖句、長所、短所、その解釈をとる代表的な伝統を書いてください。どれか一つを正解として押さず、並べてください。'),
  'ZH': ('比较不同解释', '请比较对 [经文] 的不同解释。每种解释写出主张、主要根据经文、优点、缺点，以及持此解释的代表传统。不要把某一种当作正确答案，请并列呈现。'),
  'ZHT': ('比較不同解釋', '請比較對 [經文] 的不同解釋。每種解釋寫出主張、主要根據經文、優點、缺點，以及持此解釋的代表傳統。不要把某一種當作正確答案，請並列呈現。'),
  'DE': ('Deutungen vergleichen', 'Vergleiche die verschiedenen Deutungen von [Stelle]. Zu jeder: These, wichtigste Belegstellen, Stärken, Schwächen und die Traditionen, die sie vertreten. Stelle sie nebeneinander, ohne eine als die Antwort durchzusetzen.'),
  'FR': ('Comparer les interprétations', 'Compare les différentes interprétations de [passage]. Pour chacune : la thèse, les passages d’appui, les forces, les faiblesses et les traditions qui la soutiennent. Mets-les côte à côte sans en imposer une comme la réponse.'),
  'ES': ('Comparar interpretaciones', 'Compara las distintas interpretaciones de [pasaje]. Para cada una: la tesis, pasajes de apoyo, fortalezas, debilidades y las tradiciones que la sostienen. Ponlas lado a lado sin imponer una como la respuesta.'),
  'PT': ('Comparar interpretações', 'Compare as diferentes interpretações de [passagem]. Para cada uma: a tese, passagens de apoio, pontos fortes, pontos fracos e as tradições que a sustentam. Coloque-as lado a lado sem impor uma como a resposta.'),
  'RU': ('Сравнить толкования', 'Сравни разные толкования [отрывок]. Для каждого: тезис, ключевые подтверждающие места, сильные и слабые стороны, традиции, которые его придерживаются. Поставь их рядом, не навязывая одно как ответ.'),
  'AR': ('مقارنة التفسيرات', 'قارن بين التفسيرات المختلفة لـ [المقطع]. لكل تفسير: الدعوى، النصوص الداعمة، نقاط القوة، نقاط الضعف، والتقاليد التي تتبناه. اعرضها جنبًا إلى جنب دون فرض أحدها كإجابة.'),
 },
 'STUDY': {
  'KO': ('성경공부 자료 만들기', '[구절] 로 30분 소그룹 성경공부 교재를 만들어 주세요(대상: 성인 초신자). 차례: 본문 · 배경 · 관찰 질문 3개 · 이해 질문 3개 · 관련 구절 · 묵상 질문 2개 · 적용 질문 2개 · 기도 제목. 질문은 예/아니오로 끝나지 않게 해 주세요.'),
  'EN': ('Make a Bible study', 'Make a 30-minute small-group Bible study on [passage] (audience: adult new believers). Order: text · background · 3 observation questions · 3 understanding questions · related passages · 2 meditation questions · 2 application questions · prayer points. Avoid yes/no questions.'),
  'JA': ('聖書勉強の教材を作る', '[聖句] で30分の小グループ聖書勉強の教材を作ってください（対象：成人の初信者）。順序：本文・背景・観察の質問3つ・理解の質問3つ・関連聖句・黙想の質問2つ・適用の質問2つ・祈りの課題。はい/いいえで終わる質問は避けてください。'),
  'ZH': ('制作查经材料', '请用 [经文] 制作一份30分钟的小组查经材料（对象：成人初信者）。顺序：经文 · 背景 · 3个观察问题 · 3个理解问题 · 相关经文 · 2个默想问题 · 2个应用问题 · 祷告事项。问题不要用是/否作答。'),
  'ZHT': ('製作查經材料', '請用 [經文] 製作一份30分鐘的小組查經材料（對象：成人初信者）。順序：經文 · 背景 · 3個觀察問題 · 3個理解問題 · 相關經文 · 2個默想問題 · 2個應用問題 · 禱告事項。問題不要用是/否作答。'),
  'DE': ('Bibelarbeit erstellen', 'Erstelle eine 30-minütige Kleingruppen-Bibelarbeit zu [Stelle] (Zielgruppe: erwachsene Neubekehrte). Reihenfolge: Text · Hintergrund · 3 Beobachtungsfragen · 3 Verständnisfragen · verwandte Stellen · 2 Fragen zur Besinnung · 2 Anwendungsfragen · Gebetsanliegen. Keine Ja/Nein-Fragen.'),
  'FR': ('Préparer une étude biblique', 'Prépare une étude biblique de 30 minutes en petit groupe sur [passage] (public : adultes nouveaux croyants). Ordre : texte · contexte · 3 questions d’observation · 3 questions de compréhension · passages liés · 2 questions de méditation · 2 questions d’application · sujets de prière. Évite les questions oui/non.'),
  'ES': ('Preparar un estudio bíblico', 'Prepara un estudio bíblico de 30 minutos para grupo pequeño sobre [pasaje] (público: adultos nuevos creyentes). Orden: texto · trasfondo · 3 preguntas de observación · 3 de comprensión · pasajes relacionados · 2 de meditación · 2 de aplicación · motivos de oración. Evita preguntas de sí/no.'),
  'PT': ('Preparar um estudo bíblico', 'Prepare um estudo bíblico de 30 minutos para pequeno grupo sobre [passagem] (público: adultos novos convertidos). Ordem: texto · contexto · 3 perguntas de observação · 3 de compreensão · passagens relacionadas · 2 de meditação · 2 de aplicação · motivos de oração. Evite perguntas de sim/não.'),
  'RU': ('Подготовить библейское занятие', 'Подготовь 30-минутное занятие для малой группы по [отрывок] (аудитория: взрослые новообращённые). Порядок: текст · контекст · 3 вопроса на наблюдение · 3 на понимание · связанные места · 2 на размышление · 2 на применение · молитвенные нужды. Без вопросов «да/нет».'),
  'AR': ('إعداد درس كتابي', 'أعدّ درسًا كتابيًا لمجموعة صغيرة مدته 30 دقيقة عن [المقطع] (الجمهور: مؤمنون جدد بالغون). الترتيب: النص · الخلفية · 3 أسئلة ملاحظة · 3 أسئلة فهم · نصوص ذات صلة · سؤالا تأمل · سؤالا تطبيق · طلبات صلاة. تجنّب أسئلة نعم/لا.'),
 },
 'TEACH': {
  'KO': ('성경교사 (AI 가 먼저 묻는다)', '당신은 소그룹 성경공부 인도자입니다. 강의하지 말고 질문으로 이끄세요. [구절] 을 함께 읽습니다. 먼저 본문을 어디까지 읽을지 말하고, 관찰 질문 하나를 던지세요. 제 답을 받으면 짧게 교정·격려하고 다음 질문 하나를 던지세요. 한 번에 질문 하나만. 다섯 번째 질문 뒤에는 오늘 배운 것을 한 문단으로 정리해 주세요.'),
  'EN': ('Bible teacher (AI asks first)', 'You are a small-group Bible study leader. Do not lecture; lead by questions. We read [passage] together. First say how far to read, then ask one observation question. After my answer, briefly correct or encourage, then ask the next single question. One question at a time. After the fifth question, summarize what we learned in one paragraph.'),
  'JA': ('聖書教師（AIが先に問う）', 'あなたは小グループ聖書勉強のリーダーです。講義せず、質問で導いてください。[聖句] を一緒に読みます。まずどこまで読むかを言い、観察の質問を一つ投げてください。私の答えを受けたら短く訂正・励まし、次の質問を一つ投げてください。一度に質問は一つ。五つ目の質問の後に、今日学んだことを一段落でまとめてください。'),
  'ZH': ('圣经教师（AI 先提问）', '你是小组查经的带领者。不要讲课，用提问来引导。我们一起读 [经文]。先说明读到哪里，然后提出一个观察问题。收到我的回答后，简短地纠正或鼓励，再提出下一个问题。一次只问一个问题。第五个问题之后，用一段话总结今天学到的内容。'),
  'ZHT': ('聖經教師（AI 先提問）', '你是小組查經的帶領者。不要講課，用提問來引導。我們一起讀 [經文]。先說明讀到哪裡，然後提出一個觀察問題。收到我的回答後，簡短地糾正或鼓勵，再提出下一個問題。一次只問一個問題。第五個問題之後，用一段話總結今天學到的內容。'),
  'DE': ('Bibellehrer (KI fragt zuerst)', 'Du leitest eine Kleingruppen-Bibelarbeit. Halte keinen Vortrag; führe durch Fragen. Wir lesen [Stelle] gemeinsam. Sage zuerst, bis wohin gelesen wird, und stelle eine Beobachtungsfrage. Nach meiner Antwort korrigiere oder ermutige kurz und stelle die nächste einzelne Frage. Immer nur eine Frage. Nach der fünften Frage fasse das Gelernte in einem Absatz zusammen.'),
  'FR': ('Enseignant biblique (l’IA questionne d’abord)', 'Tu animes une étude biblique en petit groupe. Ne fais pas de cours ; conduis par des questions. Nous lisons [passage] ensemble. Dis d’abord jusqu’où lire, puis pose une question d’observation. Après ma réponse, corrige ou encourage brièvement, puis pose la question suivante, une seule. Une question à la fois. Après la cinquième, résume en un paragraphe ce que nous avons appris.'),
  'ES': ('Maestro bíblico (la IA pregunta primero)', 'Eres líder de un estudio bíblico en grupo pequeño. No des cátedra; guía con preguntas. Leemos [pasaje] juntos. Primero di hasta dónde leer y haz una pregunta de observación. Tras mi respuesta, corrige o anima brevemente y haz la siguiente pregunta, solo una. Una pregunta a la vez. Después de la quinta, resume en un párrafo lo aprendido.'),
  'PT': ('Professor bíblico (a IA pergunta primeiro)', 'Você lidera um estudo bíblico em pequeno grupo. Não dê aula; conduza com perguntas. Lemos [passagem] juntos. Primeiro diga até onde ler e faça uma pergunta de observação. Após minha resposta, corrija ou encoraje brevemente e faça a próxima pergunta, apenas uma. Uma pergunta por vez. Após a quinta, resuma em um parágrafo o que aprendemos.'),
  'RU': ('Учитель Библии (ИИ спрашивает первым)', 'Ты ведёшь библейское занятие в малой группе. Не читай лекцию; веди вопросами. Мы вместе читаем [отрывок]. Сначала скажи, докуда читать, и задай один вопрос на наблюдение. После моего ответа кратко поправь или ободри и задай следующий вопрос, только один. По одному вопросу за раз. После пятого вопроса подведи итог одним абзацем.'),
  'AR': ('معلّم الكتاب المقدس (الذكاء الاصطناعي يسأل أولًا)', 'أنت قائد مجموعة صغيرة لدراسة الكتاب المقدس. لا تُلقِ محاضرة؛ قُد بالأسئلة. نقرأ [المقطع] معًا. قل أولًا إلى أين نقرأ، ثم اطرح سؤال ملاحظة واحدًا. بعد إجابتي صحّح أو شجّع باختصار ثم اطرح السؤال التالي وحده. سؤال واحد في كل مرة. بعد السؤال الخامس لخّص ما تعلمناه في فقرة واحدة.'),
 },
 'NOTE': {
  'KO': ('내 묵상을 발전시켜 줘', '아래는 [구절] 에 대해 제가 쓴 묵상노트입니다. 이 글의 특징과 장점, 놓친 것, 더 생각해 볼 부분, 이번 주 실천할 작은 행동 하나를 말해 주세요. 제 글을 고쳐 쓰지 말고 제 말로 더 나아가게 도와주세요.'),
  'EN': ('Grow my meditation', 'Below is my meditation note on [passage]. Tell me its traits and strengths, what I missed, what to think further about, and one small action for this week. Do not rewrite my note; help me go further in my own words.'),
  'JA': ('私の黙想を深めて', '以下は [聖句] について私が書いた黙想ノートです。この文の特徴と長所、見落としたこと、さらに考える点、今週実践する小さな行動を一つ教えてください。私の文を書き直さず、私の言葉で先へ進めるよう助けてください。'),
  'ZH': ('帮我深化我的默想', '下面是我对 [经文] 写的默想笔记。请告诉我这篇的特点和优点、遗漏的地方、可以进一步思考的部分，以及本周可以实践的一个小行动。不要改写我的笔记，请帮我用自己的话走得更远。'),
  'ZHT': ('幫我深化我的默想', '下面是我對 [經文] 寫的默想筆記。請告訴我這篇的特點和優點、遺漏的地方、可以進一步思考的部分，以及本週可以實踐的一個小行動。不要改寫我的筆記，請幫我用自己的話走得更遠。'),
  'DE': ('Meine Besinnung weiterführen', 'Unten steht meine Besinnungsnotiz zu [Stelle]. Nenne ihre Merkmale und Stärken, was ich übersehen habe, worüber ich weiter nachdenken sollte, und eine kleine Handlung für diese Woche. Schreibe meine Notiz nicht um; hilf mir, mit meinen Worten weiterzugehen.'),
  'FR': ('Faire grandir ma méditation', 'Ci-dessous ma note de méditation sur [passage]. Dis-en les traits et les forces, ce que j’ai manqué, ce qu’il faut creuser, et une petite action pour cette semaine. Ne réécris pas ma note ; aide-moi à aller plus loin avec mes mots.'),
  'ES': ('Hacer crecer mi meditación', 'Abajo está mi nota de meditación sobre [pasaje]. Dime sus rasgos y fortalezas, lo que pasé por alto, qué pensar más y una pequeña acción para esta semana. No reescribas mi nota; ayúdame a ir más lejos con mis palabras.'),
  'PT': ('Aprofundar minha meditação', 'Abaixo está minha nota de meditação sobre [passagem]. Diga seus traços e pontos fortes, o que deixei passar, o que pensar mais e uma pequena ação para esta semana. Não reescreva minha nota; ajude-me a ir além com minhas palavras.'),
  'RU': ('Углубить моё размышление', 'Ниже моя заметка-размышление об [отрывок]. Назови её особенности и сильные стороны, что я упустил, о чём подумать дальше и одно маленькое действие на эту неделю. Не переписывай мою заметку; помоги мне продвинуться своими словами.'),
  'AR': ('طوّر تأملي', 'فيما يلي مذكرة تأملي في [المقطع]. اذكر سماتها ونقاط قوتها، وما فاتني، وما يستحق مزيد التفكير، وعملًا صغيرًا واحدًا لهذا الأسبوع. لا تُعِد كتابة مذكرتي؛ ساعدني على المضي أبعد بكلماتي.'),
 },
 'MERGE': {
  'KO': ('대화를 한 편의 글로', MERGE_KO),
  'EN': ('Merge the conversation into one text', MERGE_EN),
  'JA': ('対話を一編の文に', '以下の対話を [聖句] についての一編の文にまとめてください。問答の流れは活かしつつ対話体を取り去り、最後に私が理解したことと残った問いを別に書いてください。新しい内容は加えないでください。'),
  'ZH': ('把对话整理成一篇文章', '请把下面的对话整理成关于 [经文] 的一篇文章。保留问答的脉络但去掉对话体，最后分别写出我已理解的和仍存的疑问。不要添加新内容。'),
  'ZHT': ('把對話整理成一篇文章', '請把下面的對話整理成關於 [經文] 的一篇文章。保留問答的脈絡但去掉對話體，最後分別寫出我已理解的和仍存的疑問。不要添加新內容。'),
  'DE': ('Gespräch zu einem Text zusammenfassen', 'Fasse das Gespräch unten zu einem einzigen Text über [Stelle] zusammen. Behalte den Gang von Frage und Antwort, aber ohne Dialogform; am Ende getrennt: was ich verstanden habe und was offen bleibt. Nichts Neues hinzufügen.'),
  'FR': ('Fondre la conversation en un texte', 'Transforme la conversation ci-dessous en un seul texte sur [passage]. Garde le fil question-réponse sans la forme dialoguée ; à la fin, note à part ce que j’ai compris et ce qui reste ouvert. N’ajoute rien de nouveau.'),
  'ES': ('Fundir la conversación en un texto', 'Convierte la conversación de abajo en un solo texto sobre [pasaje]. Mantén el hilo de pregunta y respuesta sin la forma de diálogo; al final anota aparte lo que entendí y lo que queda abierto. No añadas nada nuevo.'),
  'PT': ('Fundir a conversa em um texto', 'Transforme a conversa abaixo em um único texto sobre [passagem]. Mantenha o fio de pergunta e resposta sem a forma de diálogo; no fim anote à parte o que entendi e o que fica em aberto. Não acrescente nada novo.'),
  'RU': ('Свести беседу в один текст', 'Преврати беседу ниже в единый текст об [отрывок]. Сохрани ход вопросов и ответов, но без формы диалога; в конце отдельно запиши, что я понял и что остаётся открытым. Ничего нового не добавляй.'),
  'AR': ('دمج الحوار في نص واحد', 'حوّل الحوار أدناه إلى نص واحد عن [المقطع]. احتفظ بمسار السؤال والجواب من دون صيغة الحوار، وفي النهاية اكتب على حدة ما فهمته وما بقي مفتوحًا. لا تُضف شيئًا جديدًا.'),
 },
}


#: 용어 닻 프롬프트 씨앗 — [용어] 자리
TERM_KINDS = ['TERM_ASK', 'TERM_COMPARE', 'TERM_STUDY']
SEED_TERM = {
 'TERM_ASK': {
  'KO': ('이 용어의 뜻과 용례', '[용어] 가 성경에서 무엇을 뜻하는지 평신도가 읽기 쉬운 말로 설명해 주세요. 원어가 있으면 그 낱말의 결을 짚고, 대표 구절 두셋을 문장 안에서 풀어 주세요. 오늘 우리에게 남기는 물음 하나로 끝내 주세요.'),
  'EN': ('Meaning and usage of this term', 'Explain what [term] means in the Bible in plain language. If an original-language word is given, note its nuance, and unpack two or three key passages in sentences. End with one question it leaves us today.'),
  'JA': ('この用語の意味と用例', '[用語] が聖書で何を意味するかを、信徒に読みやすい言葉で説明してください。原語があればその語感を押さえ、代表聖句を二、三、文の中で解いてください。最後に今日の私たちへの問いを一つ。'),
  'ZH': ('这个词的意思与用例', '请用平信徒易读的语言说明 [词语] 在圣经中的意思。若有原文词，请点出其语感，并在句子中解开两三处代表经文。最后以留给我们今天的一个问题作结。'),
  'ZHT': ('這個詞的意思與用例', '請用平信徒易讀的語言說明 [詞語] 在聖經中的意思。若有原文詞，請點出其語感，並在句子中解開兩三處代表經文。最後以留給我們今天的一個問題作結。'),
  'DE': ('Bedeutung und Gebrauch dieses Begriffs', 'Erkläre in einfacher Sprache, was [Begriff] in der Bibel bedeutet. Wenn ein Wort der Ursprache angegeben ist, benenne seine Nuance und entfalte zwei oder drei Kernstellen in Sätzen. Schließe mit einer Frage an uns heute.'),
  'FR': ('Sens et usage de ce terme', 'Explique en langage simple ce que [terme] signifie dans la Bible. Si un mot original est donné, note sa nuance et déploie deux ou trois passages clés en phrases. Termine par une question pour nous aujourd’hui.'),
  'ES': ('Sentido y uso de este término', 'Explica en lenguaje sencillo qué significa [término] en la Biblia. Si se da una palabra original, señala su matiz y desarrolla dos o tres pasajes clave en frases. Termina con una pregunta para nosotros hoy.'),
  'PT': ('Sentido e uso deste termo', 'Explique em linguagem simples o que [termo] significa na Bíblia. Se houver palavra original, aponte sua nuance e desenvolva duas ou três passagens-chave em frases. Termine com uma pergunta para nós hoje.'),
  'RU': ('Значение и употребление термина', 'Объясни простым языком, что означает [термин] в Библии. Если дано слово оригинала, отметь его оттенок и раскрой два-три ключевых места в предложениях. Закончи одним вопросом для нас сегодня.'),
  'AR': ('معنى هذا المصطلح واستعماله', 'اشرح بلغة بسيطة ماذا يعني [المصطلح] في الكتاب المقدس. إن وُجدت الكلمة الأصلية فبيّن ظلالها، وافتح نصين أو ثلاثة رئيسية داخل جمل. اختم بسؤال واحد لنا اليوم.'),
 },
 'TERM_COMPARE': {
  'KO': ('비슷한 낱말과 견주기', '[용어] 와 뜻이 비슷하거나 헷갈리는 성경의 낱말들을 선택해 어떻게 다른지 견주어 주세요. 낱말마다 한 구절씩 들어 주세요. 표가 아니라 문장으로.'),
  'EN': ('Compare with similar words', 'Pick biblical words similar to or easily confused with [term] and compare how they differ. Give one passage per word. Prose, not a table.'),
  'JA': ('似た言葉との比較', '[用語] と意味が近い、または紛らわしい聖書の言葉を選び、どう違うかを比べてください。言葉ごとに聖句を一つ。表ではなく文で。'),
  'ZH': ('与相近词语比较', '请挑出与 [词语] 意思相近或容易混淆的圣经词语，比较它们的不同。每个词举一处经文。用句子而非表格。'),
  'ZHT': ('與相近詞語比較', '請挑出與 [詞語] 意思相近或容易混淆的聖經詞語，比較它們的不同。每個詞舉一處經文。用句子而非表格。'),
  'DE': ('Mit ähnlichen Wörtern vergleichen', 'Wähle biblische Wörter, die [Begriff] ähneln oder leicht damit verwechselt werden, und vergleiche die Unterschiede. Je Wort eine Stelle. Fließtext, keine Tabelle.'),
  'FR': ('Comparer avec des mots proches', 'Choisis des mots bibliques proches de [terme] ou faciles à confondre et compare leurs différences. Un passage par mot. En prose, pas de tableau.'),
  'ES': ('Comparar con palabras afines', 'Elige palabras bíblicas afines a [término] o fáciles de confundir y compara sus diferencias. Un pasaje por palabra. Prosa, no tabla.'),
  'PT': ('Comparar com palavras afins', 'Escolha palavras bíblicas afins a [termo] ou fáceis de confundir e compare suas diferenças. Uma passagem por palavra. Prosa, não tabela.'),
  'RU': ('Сравнить с похожими словами', 'Выбери библейские слова, близкие к [термин] или легко с ним путаемые, и сравни различия. По одному месту на слово. Прозой, без таблицы.'),
  'AR': ('مقارنة مع كلمات مشابهة', 'اختر كلمات كتابية قريبة من [المصطلح] أو يسهل الخلط بينها وقارن الفروق. نص واحد لكل كلمة. نثرًا لا جدولًا.'),
 },
 'TERM_STUDY': {
  'KO': ('용어 성경공부 자료', '[용어] 를 주제로 30분 소그룹 성경공부 자료를 만들어 주세요(성인 초신자). 차례: 용어의 뜻 · 대표 구절 셋 · 관찰 질문 3 · 이해 질문 3 · 삶에 닿는 물음 2 · 기도 제목. 예/아니오 물음은 피해 주세요.'),
  'EN': ('Word study for a small group', 'Make a 30-minute small-group study on [term] (adult new believers). Order: meaning · three key passages · 3 observation questions · 3 understanding questions · 2 life questions · prayer points. Avoid yes/no questions.'),
  'JA': ('用語の聖書勉強教材', '[用語] をテーマに30分の小グループ聖書勉強教材を作ってください（成人初信者）。順序：意味・代表聖句三つ・観察の質問3・理解の質問3・生活に触れる問い2・祈りの課題。はい/いいえの質問は避けて。'),
  'ZH': ('词语查经材料', '请以 [词语] 为题制作30分钟小组查经材料（成人初信者）。顺序：词义 · 三处代表经文 · 3个观察问题 · 3个理解问题 · 2个贴近生活的问题 · 祷告事项。避免是/否问题。'),
  'ZHT': ('詞語查經材料', '請以 [詞語] 為題製作30分鐘小組查經材料（成人初信者）。順序：詞義 · 三處代表經文 · 3個觀察問題 · 3個理解問題 · 2個貼近生活的問題 · 禱告事項。避免是/否問題。'),
  'DE': ('Wortstudium für die Kleingruppe', 'Erstelle eine 30-minütige Kleingruppenarbeit zu [Begriff] (erwachsene Neubekehrte). Reihenfolge: Bedeutung · drei Kernstellen · 3 Beobachtungsfragen · 3 Verständnisfragen · 2 Lebensfragen · Gebetsanliegen. Keine Ja/Nein-Fragen.'),
  'FR': ('Étude de mot en petit groupe', 'Prépare une étude de 30 minutes en petit groupe sur [terme] (adultes nouveaux croyants). Ordre : sens · trois passages clés · 3 questions d’observation · 3 de compréhension · 2 questions de vie · sujets de prière. Évite les questions oui/non.'),
  'ES': ('Estudio de palabra en grupo pequeño', 'Prepara un estudio de 30 minutos en grupo pequeño sobre [término] (adultos nuevos creyentes). Orden: sentido · tres pasajes clave · 3 preguntas de observación · 3 de comprensión · 2 de vida · motivos de oración. Evita preguntas de sí/no.'),
  'PT': ('Estudo de palavra em pequeno grupo', 'Prepare um estudo de 30 minutos em pequeno grupo sobre [termo] (adultos novos convertidos). Ordem: sentido · três passagens-chave · 3 perguntas de observação · 3 de compreensão · 2 de vida · motivos de oração. Evite perguntas de sim/não.'),
  'RU': ('Изучение слова в малой группе', 'Подготовь 30-минутное занятие для малой группы по [термин] (взрослые новообращённые). Порядок: значение · три ключевых места · 3 вопроса на наблюдение · 3 на понимание · 2 жизненных вопроса · молитвенные нужды. Без вопросов «да/нет».'),
  'AR': ('دراسة مصطلح لمجموعة صغيرة', 'أعدّ درسًا لمجموعة صغيرة مدته 30 دقيقة عن [المصطلح] (مؤمنون جدد بالغون). الترتيب: المعنى · ثلاثة نصوص رئيسية · 3 أسئلة ملاحظة · 3 أسئلة فهم · سؤالا حياة · طلبات صلاة. تجنّب أسئلة نعم/لا.'),
 },
}
#: 303차 — **연구자료 갈래**(scope REF) 씨앗 둘.
#:   `REF_HELP` = 분석형 「내 연구자료를 도와줘」(docs/1.txt 1번 3열 그대로)
#:   `REF_ASK`  = 일반대화형 「이 자료에 대해 물어보기」
#: ⚠ **글을 다시 써 주지 말라고 적었다** — 그것은 사용자의 글이다. AI 는 짚어 주고
#:   사용자가 고친다(§0-1b 남의 글을 고쳐 돌려주면 누가 쓴 글인지 알 수 없다).
REF_KINDS_SEED = ['REF_HELP', 'REF_ASK']
SEED_REF = {
 'REF_HELP': {
  'KO': ('내 연구자료를 도와줘', '[연구자료] 는 제가 쓴 글입니다. 논지가 성경 본문에서 실제로 나오는지 짚어 주세요. 근거가 약한 곳, 빠진 반론, 함께 읽어야 할 구절을 말해 주세요. 글을 다시 써 주지는 말고 고칠 자리만 짚어 주세요.'),
  'EN': ('Help me with my note', '[note] is a piece I wrote. Check whether its claims actually arise from the biblical text. Point out weak grounds, missing counter-arguments, and passages to read alongside. Do not rewrite it — just show me where to fix.'),
  'JA': ('私の研究資料を助けて', '[研究資料] は私が書いた文です。主張が聖書本文から実際に出てくるか確かめてください。根拠の弱いところ、抜けている反論、あわせて読むべき聖句を挙げてください。書き直さず、直す箇所だけ示してください。'),
  'ZH': ('帮我看我的研究资料', '[研究资料] 是我写的文章。请检查其论点是否真的出自圣经本文。指出依据薄弱之处、遗漏的反驳，以及应一并阅读的经文。请不要替我重写，只指出需要修改的地方。'),
  'ZHT': ('幫我看我的研究資料', '[研究資料] 是我寫的文章。請檢查其論點是否真的出自聖經本文。指出依據薄弱之處、遺漏的反駁，以及應一併閱讀的經文。請不要替我重寫，只指出需要修改的地方。'),
  'DE': ('Hilf mir bei meiner Notiz', '[Notiz] ist ein Text, den ich geschrieben habe. Prüfe, ob die Aussagen wirklich aus dem biblischen Text hervorgehen. Benenne schwache Begründungen, fehlende Gegenargumente und Stellen, die man dazu lesen sollte. Schreibe den Text nicht neu — zeige nur, was zu verbessern ist.'),
  'FR': ('Aide-moi avec ma note', '[note de recherche] est un texte que j’ai écrit. Vérifie si ses affirmations découlent vraiment du texte biblique. Signale les fondements faibles, les objections manquantes et les passages à lire avec. Ne le réécris pas — montre seulement où corriger.'),
  'ES': ('Ayúdame con mi nota', '[nota] es un texto que escribí. Comprueba si sus afirmaciones surgen realmente del texto bíblico. Señala los fundamentos débiles, las objeciones que faltan y los pasajes que conviene leer junto. No lo reescribas — solo muestra dónde corregir.'),
  'PT': ('Ajude-me com a minha nota', '[nota] é um texto que eu escrevi. Verifique se as afirmações realmente surgem do texto bíblico. Aponte fundamentos fracos, objecções que faltam e passagens para ler em conjunto. Não o reescreva — apenas mostre onde corrigir.'),
  'RU': ('Помоги с моей заметкой', '[заметка] — это текст, который я написал. Проверь, действительно ли его утверждения следуют из библейского текста. Укажи слабые основания, пропущенные возражения и места, которые стоит прочитать рядом. Не переписывай — только покажи, где поправить.'),
  'AR': ('ساعدني في ملاحقتي', '[الملاحقة] نص كتبتُه أنا. تحقق مما إن كانت دعاواه تنشأ فعلًا من النص الكتابي. بيّن الأسس الضعيفة والاعتراضات الناقصة والنصوص التي يُقرأ معها. لا تُعد كتابته — أشر فقط إلى مواضع التصحيح.'),
 },
 'REF_ASK': {
  'KO': ('이 자료에 대해 물어보기', '[연구자료] 를 읽고 무엇을 다루는 글인지 짧게 요약해 주세요. 그리고 이 주제를 더 알려면 성경의 어느 본문을 함께 봐야 하는지 알려 주세요.'),
  'EN': ('Ask about this note', 'Read [note] and summarize briefly what it is about. Then tell me which biblical passages I should read alongside to go deeper on this topic.'),
  'JA': ('この資料について尋ねる', '[研究資料] を読んで、何を扱った文かを短くまとめてください。そして、この主題をさらに知るには聖書のどの本文をあわせて読むべきかを教えてください。'),
  'ZH': ('询问这份资料', '请阅读 [研究资料]，简短概述它在讲什么。然后告诉我，若要更深入了解这个主题，应当一并阅读圣经的哪些本文。'),
  'ZHT': ('詢問這份資料', '請閱讀 [研究資料]，簡短概述它在講什麼。然後告訴我，若要更深入了解這個主題，應當一併閱讀聖經的哪些本文。'),
  'DE': ('Zu dieser Notiz fragen', 'Lies [Notiz] und fasse kurz zusammen, worum es geht. Sage mir dann, welche biblischen Stellen ich dazu lesen sollte, um tiefer zu gehen.'),
  'FR': ('Interroger cette note', 'Lis [note de recherche] et résume brièvement de quoi il s’agit. Dis-moi ensuite quels passages bibliques lire en complément pour approfondir ce sujet.'),
  'ES': ('Preguntar sobre esta nota', 'Lee [nota] y resume brevemente de qué trata. Luego dime qué pasajes bíblicos debería leer junto para profundizar en este tema.'),
  'PT': ('Perguntar sobre esta nota', 'Leia [nota] e resuma brevemente do que se trata. Depois diga-me quais passagens bíblicas devo ler em conjunto para aprofundar este tema.'),
  'RU': ('Спросить об этой заметке', 'Прочитай [заметка] и кратко изложи, о чём она. Затем скажи, какие библейские места стоит прочитать рядом, чтобы углубиться в тему.'),
  'AR': ('اسأل عن هذه الملاحقة', 'اقرأ [الملاحقة] ولخّص باختصار موضوعها. ثم قل لي أي نصوص كتابية ينبغي أن أقرأها معها لأتعمق في الموضوع.'),
 },
}


#: ★★★ **축 둘 — 읽는 깊이(Depth)와 관점(View)**(2026-09-30 309차 사용자 확정).
#:   사용자 「Question set, Contents set, **Depth Set**(초신자, 평신도, 신학생,
#:   설교자)로 표준화해서 임의로 선택」 · 「depth 이외에 **view** 를 추가하는 것은
#:   어떤가? 관점중립, A 관점 중심, D 관점 중심.. **기본적인 것만 하면 된다.
#:   사용자가 관점 프롬프트를 수정하면 되기 때문이다**」 → 「**오순절 추가,
#:   중립+5, 지시문 네가 작성하고 사용자가 수정한다**」.
#:
#: ★★★ **왜 축인가** — 그전에는 프롬프트 하나가 「무엇을 묻나」와 「누구에게
#:   어떻게 답하나」를 함께 지고 있었다. 그래서 같은 물음을 초신자용·설교자용으로
#:   따로 만들어야 했고, 관점을 주려면 프롬프트를 또 늘려야 했다(곱셈이다).
#:   축으로 갈라 두면 **물음 N개 × 깊이 4 × 관점 6** 이 프롬프트 N개로 끝난다.
#: ★★★ **Depth 와 View 는 완전히 직교한다** — 「초신자 + 개혁 전통」도
#:   「설교자 + 관점 중립」도 다 뜻이 있다. Q×C 처럼 어색한 조합이 없다.
#:
#: ⚠⚠⚠ **§28-11 교단 중립을 어기지 않는다** — `booktrans.md` 가 그 범위를
#:   「**우리가 쓰는 글**의 규칙이지 저자의 글에 적용하지 않는다」로 못 박았고,
#:   사용자의 AI 대화는 **개인 DB 에만 남는다**(§C-2). 오히려 관점을 안 주면
#:   AI 가 제 훈련 데이터의 다수 관점을 정답처럼 낸다 — 그것이 진짜 중립 위반이고
#:   사용자가 그것을 눈치챌 방법이 없다.
#: ⚠⚠⚠ **그래서 관점마다 같은 단서를 붙였다** — 「다른 전통은 이 본문을 어떻게
#:   달리 보는지 한 줄로 덧붙여 주세요」. **관점을 고르되 창을 닫지 않는다.**
#:   이 한 줄이 ⓐ 여러 교단이 함께 쓰는 앱이라는 사실을 지키고 ⓑ AI 가 그 관점을
#:   캐리커처로 내는 것(「개혁주의니까 예정만 말한다」)을 막는다.
#: ⚠ **기본은 늘 「관점 중립」**(`AXIS_DEFAULT`) — 고르지 않으면 나란히 놓는다.
#:
#: ⚠⚠ **어휘를 새로 짓지 않았다** — `sys_view_tradition`(§12-0 `db_verse_view`)에
#:   전통 열하나가 이미 등록돼 있고 그 코드를 그대로 쓴다(`REFORMED`·`LUTHERAN`·
#:   `WESLEYAN`·`PENTECOSTAL`·`DISPENSATIONAL`). 화면에 안 내는 여섯
#:   (`PATRISTIC`·`RABBINIC`·`CATHOLIC`·`ORTHODOX`·`ARMINIAN`·`ANABAPTIST`·
#:   `CRITICAL`)은 **지우지 않았다** — 사용자가 프롬프트를 더해 쓸 자리다.
#: ⚠⚠ **오순절이 표에 빠져 있었다** — 한국 개신교에서 큰 비중인데 없었다.
#:   빠진 교단의 사용자는 「내 관점이 목록에 없다」를 겪는다(309차에 더했다).

#: 축 = (열쇠, 저장 열쇠, 이름 열쇠, 한국어 이름, 프롬프트 갈래 접두)
AXES = [
    ('DEPTH', 'AI_DEPTH', 'AI_AX_DEPTH', '읽는 깊이', 'D_'),
    ('VIEW',  'AI_VIEW',  'AI_AX_VIEW',  '관점',      'V_'),
]
AXIS_KEYS = [a[0] for a in AXES]
#: 화면에 내는 값 — **차례가 곧 화면 차례**다(`sort_order` 가 따라온다).
AXIS_KINDS = {
    'DEPTH': ['D_NEW', 'D_LAY', 'D_STUDENT', 'D_PREACH'],
    'VIEW':  ['V_NEUTRAL', 'V_REFORMED', 'V_LUTHERAN', 'V_WESLEYAN',
              'V_PENTECOSTAL', 'V_DISPENSATIONAL'],
}
#: 기본값 — **깊이는 평신도, 관점은 중립**(고르지 않은 상태의 뜻).
AXIS_DEFAULT = {'DEPTH': 'D_LAY', 'VIEW': 'V_NEUTRAL'}
#: 축 라벨(영어 한 낱말) — 성격 라벨과 같은 문법이라 11언어에서 배치가 안 흔들린다.
AXIS_TAG = {'DEPTH': 'Depth', 'VIEW': 'View'}
#: 관점 열쇠 ↔ `sys_view_tradition.trad_code`(어휘를 두 곳에 적지 않는다).
VIEW_TRAD = {
    'V_REFORMED': 'REFORMED', 'V_LUTHERAN': 'LUTHERAN',
    'V_WESLEYAN': 'WESLEYAN', 'V_PENTECOSTAL': 'PENTECOSTAL',
    'V_DISPENSATIONAL': 'DISPENSATIONAL',
}
AXIS_ALL = AXIS_KINDS['DEPTH'] + AXIS_KINDS['VIEW']

#: 축 지시문 씨앗 — **제목 = 화면 라디오 이름 · 본문 = AI 에게 붙이는 지시**.
#: ⚠ 사용자가 고치면 그대로 쓰인다(씨앗은 없는 것만 채운다 · `ensure_seeds`).
SEED_AXIS = {
 'D_NEW': {
  'KO': ('초신자', '성경을 처음 읽는 사람에게 말하듯 설명해 주세요. 교회에서만 쓰는 낱말은 되도록 쓰지 말고, 써야 하면 그 자리에서 쉬운 말로 풀어 주세요. 한 번에 한 가지만 말하고 문장을 짧게 해 주세요.'),
  'EN': ('New believer', 'Explain as if speaking to someone reading the Bible for the first time. Avoid words used only inside church; if you must use one, explain it in plain words right there. Say one thing at a time and keep sentences short.'),
  'JA': ('初心者', '聖書を初めて読む人に話すように説明してください。教会の中でしか使わない言葉はできるだけ避け、使う場合はその場でやさしい言葉に言い換えてください。一度に一つのことだけを述べ、文は短くしてください。'),
  'ZH': ('初信者', '请像对第一次读圣经的人说话那样解释。尽量不用只在教会里使用的词语；若必须使用，请当场用浅白的话解释。一次只说一件事，句子要短。'),
  'ZHT': ('初信者', '請像對第一次讀聖經的人說話那樣解釋。盡量不用只在教會裡使用的詞語；若必須使用，請當場用淺白的話解釋。一次只說一件事，句子要短。'),
  'DE': ('Neu im Glauben', 'Erkläre so, als sprächest du mit jemandem, der die Bibel zum ersten Mal liest. Vermeide Wörter, die nur in der Kirche gebraucht werden; wenn du eines brauchst, erkläre es gleich an der Stelle in einfachen Worten. Sage eines nach dem anderen und halte die Sätze kurz.'),
  'FR': ('Nouveau croyant', 'Explique comme si tu parlais à quelqu’un qui lit la Bible pour la première fois. Évite les mots qui ne servent qu’à l’église ; si tu dois en employer un, explique-le sur place en mots simples. Dis une chose à la fois et fais des phrases courtes.'),
  'ES': ('Nuevo creyente', 'Explica como si hablaras con alguien que lee la Biblia por primera vez. Evita las palabras que solo se usan en la iglesia; si debes usar alguna, explícala allí mismo con palabras sencillas. Di una cosa a la vez y usa frases cortas.'),
  'PT': ('Novo crente', 'Explique como se falasse com alguém que lê a Bíblia pela primeira vez. Evite palavras usadas apenas na igreja; se precisar de alguma, explique-a ali mesmo em palavras simples. Diga uma coisa de cada vez e use frases curtas.'),
  'RU': ('Новичок в вере', 'Объясняй так, будто говоришь с тем, кто читает Библию впервые. Избегай слов, которые употребляют только в церкви; если слово необходимо, объясни его тут же простыми словами. Говори об одном за раз и делай предложения короткими.'),
  'AR': ('مبتدئ في الإيمان', 'اشرح كما لو كنت تتحدث إلى شخص يقرأ الكتاب المقدس أول مرة. تجنّب الكلمات التي لا تُستعمل إلا داخل الكنيسة، وإن احتجت إلى واحدة فاشرحها في موضعها بكلمات بسيطة. قل أمرًا واحدًا في كل مرة واجعل الجمل قصيرة.'),
 },
 'D_LAY': {
  'KO': ('평신도', '주일마다 예배에 나가는 평신도에게 설명해 주세요. 교회에서 흔히 쓰는 낱말은 그대로 쓰되, 신학 용어는 처음 나올 때 한 번 풀어 주세요. 끝에 이 본문이 오늘 삶에서 무엇을 달라지게 하는지 한 대목을 넣어 주세요.'),
  'EN': ('Lay reader', 'Explain to a layperson who attends worship every Sunday. Use the words common in church as they are, but explain a theological term once when it first appears. End with one part on what this passage changes in daily life today.'),
  'JA': ('信徒', '毎週礼拝に出ている信徒に向けて説明してください。教会でよく使う言葉はそのまま用いてよいですが、神学用語は最初に出てきたとき一度だけ説明してください。最後に、この本文が今日の生活の何を変えるのかを一段落入れてください。'),
  'ZH': ('平信徒', '请向每周参加礼拜的平信徒解释。教会常用的词语可以照用，但神学术语第一次出现时请解释一次。最后请加一段，说明这段经文使今天的生活有什么不同。'),
  'ZHT': ('平信徒', '請向每週參加禮拜的平信徒解釋。教會常用的詞語可以照用，但神學術語第一次出現時請解釋一次。最後請加一段，說明這段經文使今天的生活有什麼不同。'),
  'DE': ('Gemeindeglied', 'Erkläre es einem Gemeindeglied, das jeden Sonntag zum Gottesdienst geht. Gebrauche die in der Gemeinde üblichen Wörter, erkläre aber einen theologischen Fachbegriff einmal, wenn er zuerst vorkommt. Schließe mit einem Abschnitt darüber, was diese Stelle im Alltag heute ändert.'),
  'FR': ('Fidèle', 'Explique à un fidèle qui va au culte chaque dimanche. Emploie les mots courants dans l’Église tels quels, mais explique un terme théologique une fois, à sa première apparition. Termine par un passage sur ce que ce texte change dans la vie de tous les jours.'),
  'ES': ('Laico', 'Explica a un laico que asiste al culto cada domingo. Usa tal cual las palabras corrientes en la iglesia, pero explica un término teológico una vez, cuando aparezca por primera vez. Termina con un apartado sobre lo que este texto cambia en la vida diaria de hoy.'),
  'PT': ('Leigo', 'Explique a um leigo que vai ao culto todos os domingos. Use tal como são as palavras correntes na igreja, mas explique um termo teológico uma vez, quando aparecer pela primeira vez. Termine com um trecho sobre o que este texto muda na vida diária de hoje.'),
  'RU': ('Прихожанин', 'Объясняй прихожанину, который каждое воскресенье бывает на богослужении. Обычные церковные слова употребляй как есть, но богословский термин объясни один раз, когда он появится впервые. Закончи частью о том, что этот текст меняет в сегодняшней повседневной жизни.'),
  'AR': ('مؤمن عادي', 'اشرح لمؤمن عادي يحضر العبادة كل أحد. استعمل الكلمات الشائعة في الكنيسة كما هي، لكن اشرح المصطلح اللاهوتي مرة واحدة عند وروده أول مرة. واختم بمقطع عمّا يغيّره هذا النص في الحياة اليومية اليوم.'),
 },
 'D_STUDENT': {
  'KO': ('신학생', '신학을 공부하는 사람에게 설명해 주세요. 원어 낱말, 본문의 문학 구조, 해석이 갈리는 자리를 필요한 만큼 다뤄 주세요. 견해가 갈리면 어느 견해가 무엇을 근거로 하는지 나란히 적고, 한 견해를 정답처럼 말하지 말아 주세요.'),
  'EN': ('Theology student', 'Explain to someone studying theology. Handle the original-language words, the literary structure of the text, and the places where interpretation divides, as far as needed. Where views differ, set them side by side with the grounds each rests on, and do not present one view as the answer.'),
  'JA': ('神学生', '神学を学んでいる人に向けて説明してください。原語の語、本文の文学構造、解釈が分かれる箇所を必要な範囲で扱ってください。見解が分かれる場合は、どの見解が何を根拠にしているのかを並べて書き、一つの見解を正解のように述べないでください。'),
  'ZH': ('神学生', '请向正在学习神学的人解释。请按需要处理原文词语、本文的文学结构，以及解释有分歧之处。见解不同时，请把各见解及其依据并列写出，不要把某一见解说成正确答案。'),
  'ZHT': ('神學生', '請向正在學習神學的人解釋。請按需要處理原文詞語、本文的文學結構，以及解釋有分歧之處。見解不同時，請把各見解及其依據並列寫出，不要把某一見解說成正確答案。'),
  'DE': ('Theologiestudent', 'Erkläre es jemandem, der Theologie studiert. Behandle die Wörter der Ursprache, den literarischen Aufbau des Textes und die Stellen, an denen sich die Auslegung scheidet, soweit es nötig ist. Wo die Ansichten auseinandergehen, stelle sie mit ihren Gründen nebeneinander und gib keine als die Antwort aus.'),
  'FR': ('Étudiant en théologie', 'Explique à quelqu’un qui étudie la théologie. Traite, autant qu’il le faut, les mots de la langue originale, la structure littéraire du texte et les endroits où l’interprétation se divise. Là où les avis diffèrent, place-les côte à côte avec leurs fondements, et ne présente pas l’un d’eux comme la réponse.'),
  'ES': ('Estudiante de teología', 'Explica a alguien que estudia teología. Trata, en la medida necesaria, las palabras de la lengua original, la estructura literaria del texto y los lugares donde la interpretación se divide. Donde los pareceres difieran, ponlos uno al lado del otro con sus fundamentos, y no presentes uno como la respuesta.'),
  'PT': ('Estudante de teologia', 'Explique a quem estuda teologia. Trate, na medida do necessário, as palavras da língua original, a estrutura literária do texto e os lugares onde a interpretação se divide. Onde os pareceres diferirem, coloque-os lado a lado com seus fundamentos, e não apresente um deles como a resposta.'),
  'RU': ('Студент богословия', 'Объясняй тому, кто изучает богословие. Разбери, насколько нужно, слова языка оригинала, литературное строение текста и места, где расходится толкование. Где мнения расходятся, поставь их рядом вместе с основаниями и не выдавай одно из них за верный ответ.'),
  'AR': ('طالب لاهوت', 'اشرح لمن يدرس اللاهوت. تناول بالقدر اللازم كلمات اللغة الأصلية، والبنية الأدبية للنص، والمواضع التي يتفرق فيها التفسير. وحيث تختلف الآراء، اعرضها جنبًا إلى جنب مع ما تستند إليه، ولا تقدّم أحدها كأنه الجواب.'),
 },
 'D_PREACH': {
  'KO': ('설교자', '설교를 준비하는 사람에게 설명해 주세요. 본문의 뼈대와 중심 주장을 먼저 세우고, 오늘 청중에게 전할 때 짚어야 할 자리와 빠지기 쉬운 함정을 적어 주세요. 설교 원선택할 대신 쓰지는 말아 주세요.'),
  'EN': ('Preacher', 'Explain to someone preparing a sermon. First set out the skeleton of the text and its central claim, then note the places to press when bringing it to hearers today and the traps easy to fall into. Do not write the sermon manuscript for me.'),
  'JA': ('説教者', '説教を準備している人に向けて説明してください。まず本文の骨組みと中心主張を立て、今日の聴衆に語るときに押さえるべき箇所と陥りやすい落とし穴を書いてください。説教原稿を代わりに書くことはしないでください。'),
  'ZH': ('讲道者', '请向正在准备讲道的人解释。请先立出本文的骨架与中心主张，再写出向今天的听众传讲时应当着力之处，以及容易落入的陷阱。请不要代写讲道稿。'),
  'ZHT': ('講道者', '請向正在準備講道的人解釋。請先立出本文的骨架與中心主張，再寫出向今天的聽眾傳講時應當著力之處，以及容易落入的陷阱。請不要代寫講道稿。'),
  'DE': ('Prediger', 'Erkläre es jemandem, der eine Predigt vorbereitet. Stelle zuerst das Gerüst des Textes und seine Hauptaussage heraus, dann die Stellen, auf die es beim Weitersagen an die heutigen Hörer ankommt, und die Fallen, in die man leicht tritt. Schreibe das Predigtmanuskript nicht an meiner Stelle.'),
  'FR': ('Prédicateur', 'Explique à quelqu’un qui prépare une prédication. Dégage d’abord l’ossature du texte et son affirmation centrale, puis note les points sur lesquels appuyer en le portant aux auditeurs d’aujourd’hui, et les pièges où l’on tombe facilement. N’écris pas le manuscrit de la prédication à ma place.'),
  'ES': ('Predicador', 'Explica a alguien que prepara un sermón. Establece primero el armazón del texto y su afirmación central, y luego señala los puntos en que hay que insistir al llevarlo a los oyentes de hoy, y las trampas en que se cae con facilidad. No escribas el manuscrito del sermón en mi lugar.'),
  'PT': ('Pregador', 'Explique a quem prepara um sermão. Estabeleça primeiro a ossatura do texto e a sua afirmação central, e depois indique os pontos em que insistir ao levá-lo aos ouvintes de hoje, e as armadilhas em que se cai facilmente. Não escreva o manuscrito do sermão em meu lugar.'),
  'RU': ('Проповедник', 'Объясняй тому, кто готовит проповедь. Сначала выстрой каркас текста и его главное утверждение, затем отметь места, на которые стоит нажать, обращаясь к нынешним слушателям, и ловушки, в которые легко попасть. Не пиши текст проповеди вместо меня.'),
  'AR': ('واعظ', 'اشرح لمن يُعِدّ عظة. ابنِ أولًا هيكل النص وادّعاءه المركزي، ثم اذكر المواضع التي ينبغي التركيز عليها عند تقديمه لسامعي اليوم، والمزالق التي يسهل الوقوع فيها. ولا تكتب نص العظة بدلًا مني.'),
 },
 'V_NEUTRAL': {
  'KO': ('관점 중립', '견해가 갈리는 자리에서는 한쪽을 정답으로 밀지 말고, 어느 전통이 어떻게 보는지 나란히 놓아 주세요. 본문이 분명히 말하는 것과 해석이 갈리는 것을 구분해 주세요.'),
  'EN': ('No single tradition', 'Where views differ, do not push one as the answer; set side by side how each tradition sees it. Distinguish what the text plainly says from what interpretation divides over.'),
  'JA': ('特定の立場に立たない', '見解が分かれる箇所では一方を正解として押し出さず、どの伝統がどう見るのかを並べて置いてください。本文がはっきり述べていることと、解釈が分かれることを区別してください。'),
  'ZH': ('不偏于某一传统', '在见解分歧之处，不要把某一方推为正确答案，请把各传统如何看待并列摆出。请区分本文明确所说的和解释有分歧的。'),
  'ZHT': ('不偏於某一傳統', '在見解分歧之處，不要把某一方推為正確答案，請把各傳統如何看待並列擺出。請區分本文明確所說的和解釋有分歧的。'),
  'DE': ('Ohne feste Tradition', 'Wo die Ansichten auseinandergehen, dränge keine als die Antwort auf; stelle nebeneinander, wie die einzelnen Traditionen es sehen. Unterscheide, was der Text klar sagt, von dem, worüber sich die Auslegung scheidet.'),
  'FR': ('Sans tradition fixée', 'Là où les avis diffèrent, n’impose pas l’un comme la réponse ; place côte à côte la manière dont chaque tradition le voit. Distingue ce que le texte dit clairement de ce sur quoi l’interprétation se divise.'),
  'ES': ('Sin tradición fija', 'Donde los pareceres difieran, no impongas uno como la respuesta; pon uno al lado del otro cómo lo ve cada tradición. Distingue lo que el texto dice con claridad de aquello en que la interpretación se divide.'),
  'PT': ('Sem tradição fixa', 'Onde os pareceres diferirem, não imponha um como a resposta; coloque lado a lado como cada tradição o vê. Distinga o que o texto diz com clareza daquilo em que a interpretação se divide.'),
  'RU': ('Без одной традиции', 'Там, где мнения расходятся, не выдавай одно за верный ответ; поставь рядом, как это видит каждая традиция. Отличай то, что текст говорит ясно, от того, в чём расходится толкование.'),
  'AR': ('دون الانحياز إلى تقليد', 'حيث تختلف الآراء، لا تفرض واحدًا كأنه الجواب؛ بل اعرض جنبًا إلى جنب كيف يراه كل تقليد. وميّز ما يقوله النص بوضوح عمّا يتفرق فيه التفسير.'),
 },
 'V_REFORMED': {
  'KO': ('개혁 전통', '하나님의 주권과 언약의 전개를 중심으로 읽어 주세요. 다른 전통은 이 본문을 어떻게 달리 보는지 마지막에 한 줄로 덧붙여 주세요.'),
  'EN': ('Reformed', 'Read it centred on the sovereignty of God and the unfolding of the covenant. At the end, add one line on how other traditions see this passage differently.'),
  'JA': ('改革派の伝統', '神の主権と契約の展開を中心に読んでください。最後に、他の伝統がこの本文をどう違って見るのかを一行で添えてください。'),
  'ZH': ('改革传统', '请以上帝的主权与约的展开为中心来读。最后请用一行补充其他传统如何不同地看这段经文。'),
  'ZHT': ('改革傳統', '請以上帝的主權與約的展開為中心來讀。最後請用一行補充其他傳統如何不同地看這段經文。'),
  'DE': ('Reformierte Tradition', 'Lies es von der Souveränität Gottes und der Entfaltung des Bundes her. Füge am Ende eine Zeile hinzu, wie andere Traditionen diese Stelle anders sehen.'),
  'FR': ('Tradition réformée', 'Lis-le en te centrant sur la souveraineté de Dieu et le déploiement de l’alliance. À la fin, ajoute une ligne sur la manière dont d’autres traditions voient ce passage autrement.'),
  'ES': ('Tradición reformada', 'Léelo centrándote en la soberanía de Dios y en el despliegue del pacto. Al final, añade una línea sobre cómo otras tradiciones ven este pasaje de otro modo.'),
  'PT': ('Tradição reformada', 'Leia-o centrando-se na soberania de Deus e no desdobramento da aliança. No final, acrescente uma linha sobre como outras tradições veem esta passagem de outro modo.'),
  'RU': ('Реформатская традиция', 'Читай, сосредоточившись на владычестве Божием и развитии завета. В конце добавь одну строку о том, как иначе видят это место другие традиции.'),
  'AR': ('التقليد المُصلَح', 'اقرأه مركّزًا على سيادة الله وتدرّج العهد. وفي الختام أضف سطرًا واحدًا عن كيف ترى التقاليد الأخرى هذا المقطع على نحو مختلف.'),
 },
 'V_LUTHERAN': {
  'KO': ('루터 전통', '율법과 복음의 구별, 십자가 신학을 중심으로 읽어 주세요. 다른 전통은 이 본문을 어떻게 달리 보는지 마지막에 한 줄로 덧붙여 주세요.'),
  'EN': ('Lutheran', 'Read it centred on the distinction between law and gospel, and on the theology of the cross. At the end, add one line on how other traditions see this passage differently.'),
  'JA': ('ルター派の伝統', '律法と福音の区別、十字架の神学を中心に読んでください。最後に、他の伝統がこの本文をどう違って見るのかを一行で添えてください。'),
  'ZH': ('路德传统', '请以律法与福音的区分、十字架神学为中心来读。最后请用一行补充其他传统如何不同地看这段经文。'),
  'ZHT': ('路德傳統', '請以律法與福音的區分、十字架神學為中心來讀。最後請用一行補充其他傳統如何不同地看這段經文。'),
  'DE': ('Lutherische Tradition', 'Lies es von der Unterscheidung von Gesetz und Evangelium und von der Theologie des Kreuzes her. Füge am Ende eine Zeile hinzu, wie andere Traditionen diese Stelle anders sehen.'),
  'FR': ('Tradition luthérienne', 'Lis-le en te centrant sur la distinction entre la loi et l’Évangile, et sur la théologie de la croix. À la fin, ajoute une ligne sur la manière dont d’autres traditions voient ce passage autrement.'),
  'ES': ('Tradición luterana', 'Léelo centrándote en la distinción entre la ley y el evangelio, y en la teología de la cruz. Al final, añade una línea sobre cómo otras tradiciones ven este pasaje de otro modo.'),
  'PT': ('Tradição luterana', 'Leia-o centrando-se na distinção entre a lei e o evangelho, e na teologia da cruz. No final, acrescente uma linha sobre como outras tradições veem esta passagem de outro modo.'),
  'RU': ('Лютеранская традиция', 'Читай, сосредоточившись на различении закона и Евангелия и на богословии креста. В конце добавь одну строку о том, как иначе видят это место другие традиции.'),
  'AR': ('التقليد اللوثري', 'اقرأه مركّزًا على التمييز بين الناموس والإنجيل، وعلى لاهوت الصليب. وفي الختام أضف سطرًا واحدًا عن كيف ترى التقاليد الأخرى هذا المقطع على نحو مختلف.'),
 },
 'V_WESLEYAN': {
  'KO': ('웨슬리·알미니안', '하나님의 은혜에 응답하는 사람의 책임과 성화의 여정을 중심으로 읽어 주세요. 다른 전통은 이 본문을 어떻게 달리 보는지 마지막에 한 줄로 덧붙여 주세요.'),
  'EN': ('Wesleyan / Arminian', 'Read it centred on the responsibility of the one who responds to God’s grace, and on the journey of sanctification. At the end, add one line on how other traditions see this passage differently.'),
  'JA': ('ウェスレー・アルミニウス', '神の恵みに応える人の責任と、聖化の歩みを中心に読んでください。最後に、他の伝統がこの本文をどう違って見るのかを一行で添えてください。'),
  'ZH': ('卫斯理·亚米念', '请以回应上帝恩典之人的责任与成圣的历程为中心来读。最后请用一行补充其他传统如何不同地看这段经文。'),
  'ZHT': ('衛斯理·亞米念', '請以回應上帝恩典之人的責任與成聖的歷程為中心來讀。最後請用一行補充其他傳統如何不同地看這段經文。'),
  'DE': ('Wesleyanisch / Arminianisch', 'Lies es von der Verantwortung des Menschen her, der auf Gottes Gnade antwortet, und vom Weg der Heiligung. Füge am Ende eine Zeile hinzu, wie andere Traditionen diese Stelle anders sehen.'),
  'FR': ('Wesleyen / arminien', 'Lis-le en te centrant sur la responsabilité de celui qui répond à la grâce de Dieu et sur le chemin de la sanctification. À la fin, ajoute une ligne sur la manière dont d’autres traditions voient ce passage autrement.'),
  'ES': ('Wesleyano / arminiano', 'Léelo centrándote en la responsabilidad de quien responde a la gracia de Dios y en el camino de la santificación. Al final, añade una línea sobre cómo otras tradiciones ven este pasaje de otro modo.'),
  'PT': ('Wesleyano / arminiano', 'Leia-o centrando-se na responsabilidade de quem responde à graça de Deus e no caminho da santificação. No final, acrescente uma linha sobre como outras tradições veem esta passagem de outro modo.'),
  'RU': ('Уэслианская / арминианская', 'Читай, сосредоточившись на ответственности человека, отвечающего на благодать Божию, и на пути освящения. В конце добавь одну строку о том, как иначе видят это место другие традиции.'),
  'AR': ('وِسليّ / أرمينيّ', 'اقرأه مركّزًا على مسؤولية من يستجيب لنعمة الله، وعلى مسيرة التقديس. وفي الختام أضف سطرًا واحدًا عن كيف ترى التقاليد الأخرى هذا المقطع على نحو مختلف.'),
 },
 'V_PENTECOSTAL': {
  'KO': ('오순절·은사주의', '성령의 현재적 역사와 그 체험을 중심으로 읽어 주세요. 다른 전통은 이 본문을 어떻게 달리 보는지 마지막에 한 줄로 덧붙여 주세요.'),
  'EN': ('Pentecostal / charismatic', 'Read it centred on the present working of the Holy Spirit and the experience of it. At the end, add one line on how other traditions see this passage differently.'),
  'JA': ('ペンテコステ・カリスマ', '聖霊の今の働きと、その体験を中心に読んでください。最後に、他の伝統がこの本文をどう違って見るのかを一行で添えてください。'),
  'ZH': ('五旬节·灵恩', '请以圣灵当下的作为及其经历为中心来读。最后请用一行补充其他传统如何不同地看这段经文。'),
  'ZHT': ('五旬節·靈恩', '請以聖靈當下的作為及其經歷為中心來讀。最後請用一行補充其他傳統如何不同地看這段經文。'),
  'DE': ('Pfingstlich / charismatisch', 'Lies es vom gegenwärtigen Wirken des Heiligen Geistes und dessen Erfahrung her. Füge am Ende eine Zeile hinzu, wie andere Traditionen diese Stelle anders sehen.'),
  'FR': ('Pentecôtiste / charismatique', 'Lis-le en te centrant sur l’œuvre présente du Saint-Esprit et son expérience. À la fin, ajoute une ligne sur la manière dont d’autres traditions voient ce passage autrement.'),
  'ES': ('Pentecostal / carismático', 'Léelo centrándote en la obra presente del Espíritu Santo y en su experiencia. Al final, añade una línea sobre cómo otras tradiciones ven este pasaje de otro modo.'),
  'PT': ('Pentecostal / carismático', 'Leia-o centrando-se na obra presente do Espírito Santo e na sua experiência. No final, acrescente uma linha sobre como outras tradições veem esta passagem de outro modo.'),
  'RU': ('Пятидесятническая / харизматическая', 'Читай, сосредоточившись на нынешнем действии Святого Духа и на опыте этого действия. В конце добавь одну строку о том, как иначе видят это место другие традиции.'),
  'AR': ('خمسينيّ / كاريزميّ', 'اقرأه مركّزًا على عمل الروح القدس الحاضر وعلى خبرته. وفي الختام أضف سطرًا واحدًا عن كيف ترى التقاليد الأخرى هذا المقطع على نحو مختلف.'),
 },
 'V_DISPENSATIONAL': {
  'KO': ('세대주의', '이스라엘과 교회의 구분, 성경 역사의 시대 구분을 중심으로 읽어 주세요. 다른 전통은 이 본문을 어떻게 달리 보는지 마지막에 한 줄로 덧붙여 주세요.'),
  'EN': ('Dispensational', 'Read it centred on the distinction between Israel and the church, and on the division of biblical history into ages. At the end, add one line on how other traditions see this passage differently.'),
  'JA': ('ディスペンセーション', 'イスラエルと教会の区別、聖書の歴史の時代区分を中心に読んでください。最後に、他の伝統がこの本文をどう違って見るのかを一行で添えてください。'),
  'ZH': ('时代论', '请以以色列与教会的区分、圣经历史的时代划分为中心来读。最后请用一行补充其他传统如何不同地看这段经文。'),
  'ZHT': ('時代論', '請以以色列與教會的區分、聖經歷史的時代劃分為中心來讀。最後請用一行補充其他傳統如何不同地看這段經文。'),
  'DE': ('Dispensationalistisch', 'Lies es von der Unterscheidung zwischen Israel und der Kirche und von der Einteilung der biblischen Geschichte in Zeitalter her. Füge am Ende eine Zeile hinzu, wie andere Traditionen diese Stelle anders sehen.'),
  'FR': ('Dispensationaliste', 'Lis-le en te centrant sur la distinction entre Israël et l’Église et sur le découpage de l’histoire biblique en âges. À la fin, ajoute une ligne sur la manière dont d’autres traditions voient ce passage autrement.'),
  'ES': ('Dispensacionalista', 'Léelo centrándote en la distinción entre Israel y la iglesia y en la división de la historia bíblica en edades. Al final, añade una línea sobre cómo otras tradiciones ven este pasaje de otro modo.'),
  'PT': ('Dispensacionalista', 'Leia-o centrando-se na distinção entre Israel e a igreja e na divisão da história bíblica em eras. No final, acrescente uma linha sobre como outras tradições veem esta passagem de outro modo.'),
  'RU': ('Диспенсационалистская', 'Читай, сосредоточившись на различении Израиля и церкви и на разделении библейской истории на периоды. В конце добавь одну строку о том, как иначе видят это место другие традиции.'),
  'AR': ('التدبيريّ', 'اقرأه مركّزًا على التمييز بين إسرائيل والكنيسة، وعلى تقسيم التاريخ الكتابي إلى عهود. وفي الختام أضف سطرًا واحدًا عن كيف ترى التقاليد الأخرى هذا المقطع على نحو مختلف.'),
 },
}

# ══════════════════════════════════════════════════════════════════════
#  317차 — 공통 프롬프트: 상태 · 신앙 배경 · 관점 + 내용과 형식 일곱 칸
# ══════════════════════════════════════════════════════════════════════
#: ★★★ 「깊이」 넷을 「상태」 아홉으로 넓혔다(docs/1.txt 2-6)(5) 「상태 : 선택안함, 초신자,
#:   평신도, 교회지도자, 신학생, 목사, 선교사, 사모, 신학교수」).
#: ★ 2026-10-27 신학교수 걷음(사용자 「필요하면 자기가 만들면 된다」 — [수정]에서 상태를 더할 수 있다).
#: ⚠ 옛 깊이 넷의 글은 **그대로 옮겨 산다**(초신자·평신도·신학생 · 설교자 → 목사) —
#:   사용자가 고쳐 둔 글도 함께 옮긴다(`_migrate_axes`).
#: ★★★ **신앙 배경**(사용자 확정 — 「이 앱은 개신교 중심이다」 · 가톨릭은 개신교가 아니다).
#:   가톨릭·정교회를 고르면 필수 지침 4번(다른 신앙 배경)이 그 채팅에 작동한다.
#: ⚠ 「선택 안 함」은 **아무것도 보내지 않는다**(빈 지시문).
SEED_AXIS_317 = {
 'S_NONE': {lg: (t, '') for lg, t in {
     'KO': '선택 안 함', 'EN': 'Not chosen', 'JA': '選択しない', 'ZH': '不选择', 'ZHT': '不選擇',
     'DE': 'Keine Angabe', 'FR': 'Non précisé', 'ES': 'Sin elegir', 'PT': 'Não escolhido',
     'RU': 'Не выбрано', 'AR': 'بلا اختيار'}.items()},
 'S_LEADER': {
  'KO': ('교회지도자', '구역장·교사·장로·권사처럼 교회에서 다른 사람을 가르치고 돌보는 사람에게 설명해 주세요. 소그룹이나 교회학교에서 그대로 나눌 수 있게 요점과 나눔 질문을 함께 주세요.'),
  'EN': ('Church leader', 'Explain to someone who teaches and cares for others in church — a small-group leader, teacher or elder. Give the main points together with discussion questions that can be used as they are in a small group or Sunday school.'),
  'JA': ('教会リーダー', '小グループのリーダー、教師、長老のように、教会で人を教え世話する人に説明してください。小グループや教会学校でそのまま分かち合えるよう、要点と分かち合いの問いを添えてください。'),
  'ZH': ('教会领袖', '请向在教会中教导和关怀他人的人（如小组长、主日学老师、长老）解释。请给出要点和分享问题，使之能直接用于小组或主日学。'),
  'ZHT': ('教會領袖', '請向在教會中教導和關懷他人的人（如小組長、主日學老師、長老）解釋。請給出要點和分享問題，使之能直接用於小組或主日學。'),
  'DE': ('Gemeindeleitung', 'Erkläre für jemanden, der in der Gemeinde andere lehrt und begleitet – Hauskreisleiter, Lehrer, Älteste. Gib die Kernpunkte zusammen mit Gesprächsfragen, die sich so im Hauskreis oder Kindergottesdienst verwenden lassen.'),
  'FR': ('Responsable d’Église', 'Explique pour quelqu’un qui enseigne et accompagne d’autres personnes dans l’Église – responsable de groupe, moniteur, ancien. Donne les points clés avec des questions de partage utilisables telles quelles en petit groupe ou à l’école du dimanche.'),
  'ES': ('Líder de iglesia', 'Explica para alguien que enseña y cuida a otros en la iglesia: líder de grupo, maestro, anciano. Da los puntos clave junto con preguntas para compartir que se puedan usar tal cual en un grupo pequeño o en la escuela dominical.'),
  'PT': ('Líder da igreja', 'Explique para alguém que ensina e cuida de outros na igreja – líder de grupo, professor, presbítero. Dê os pontos principais com perguntas de partilha que possam ser usadas tal como estão num pequeno grupo ou na escola dominical.'),
  'RU': ('Служитель церкви', 'Объясни для того, кто учит и опекает других в церкви, — лидера малой группы, учителя, старейшины. Дай главные мысли вместе с вопросами для обсуждения, которые можно сразу использовать в малой группе или воскресной школе.'),
  'AR': ('قائد كنسي', 'اشرح لشخص يعلّم الآخرين ويرعاهم في الكنيسة مثل قائد مجموعة صغيرة أو معلم أو شيخ. قدّم النقاط الرئيسية مع أسئلة للمشاركة يمكن استخدامها كما هي في مجموعة صغيرة أو مدرسة الأحد.'),
 },
 'S_MISSION': {
  'KO': ('선교사', '다른 문화권에서 복음을 전하는 선교사에게 설명해 주세요. 그 문화의 사람에게 이 본문을 전할 때 걸림돌이 될 낱말이나 개념과, 쉽게 옮길 수 있는 표현을 함께 짚어 주세요.'),
  'EN': ('Missionary', 'Explain to a missionary who shares the gospel in another culture. Point out words or ideas in this passage that may be stumbling blocks for people of that culture, and expressions that carry over easily.'),
  'JA': ('宣教師', '異文化で福音を伝える宣教師に説明してください。その文化の人にこの本文を伝えるとき、つまずきとなる言葉や概念と、伝えやすい表現をあわせて示してください。'),
  'ZH': ('宣教士', '请向在其他文化中传福音的宣教士解释。请指出向该文化的人讲解这段经文时可能成为绊脚石的词语或观念，以及容易转达的表达方式。'),
  'ZHT': ('宣教士', '請向在其他文化中傳福音的宣教士解釋。請指出向該文化的人講解這段經文時可能成為絆腳石的詞語或觀念，以及容易轉達的表達方式。'),
  'DE': ('Missionar', 'Erkläre für jemanden, der in einer anderen Kultur das Evangelium weitergibt. Zeige Wörter oder Vorstellungen in diesem Text, die für Menschen dieser Kultur Stolpersteine sein können, und Ausdrücke, die sich leicht übertragen lassen.'),
  'FR': ('Missionnaire', 'Explique pour un missionnaire qui annonce l’Évangile dans une autre culture. Signale les mots ou idées de ce texte qui peuvent faire obstacle aux gens de cette culture, et les expressions qui passent facilement.'),
  'ES': ('Misionero', 'Explica para un misionero que comparte el evangelio en otra cultura. Señala las palabras o ideas de este pasaje que pueden ser piedras de tropiezo para la gente de esa cultura y las expresiones que se transmiten con facilidad.'),
  'PT': ('Missionário', 'Explique para um missionário que anuncia o evangelho noutra cultura. Indique as palavras ou ideias deste texto que podem ser pedras de tropeço para as pessoas dessa cultura e as expressões que se transmitem com facilidade.'),
  'RU': ('Миссионер', 'Объясни для миссионера, который несёт Евангелие в другой культуре. Укажи слова или понятия этого отрывка, которые могут стать преткновением для людей той культуры, и выражения, которые легко передать.'),
  'AR': ('مُرسَل', 'اشرح لمُرسَل ينشر الإنجيل في ثقافة أخرى. بيّن الكلمات أو الأفكار في هذا النص التي قد تكون عثرة لأهل تلك الثقافة، والتعابير التي يسهل نقلها.'),
 },
 'S_PWIFE': {
  'KO': ('사모', '목회자의 배우자로서 교회 안팎에서 사람들을 돌보는 사람에게 설명해 주세요. 상담과 심방, 여성 모임에서 쓸 수 있게 따뜻하고 구체적으로 풀어 주세요.'),
  'EN': ('Pastor’s wife', 'Explain to a pastor’s wife who cares for people in and around the church. Make it warm and concrete so it can be used in counselling, home visits and women’s gatherings.'),
  'JA': ('牧師夫人', '牧師の配偶者として教会内外で人々を世話する人に説明してください。相談や訪問、女性の集まりで使えるよう、温かく具体的に説き明かしてください。'),
  'ZH': ('师母', '请向作为牧者配偶、在教会内外关怀他人的人解释。请讲得温暖而具体，使之能用于辅导、探访和姊妹聚会。'),
  'ZHT': ('師母', '請向作為牧者配偶、在教會內外關懷他人的人解釋。請講得溫暖而具體，使之能用於輔導、探訪和姊妹聚會。'),
  'DE': ('Pastorenfrau', 'Erkläre für die Frau eines Pastors, die Menschen in und um die Gemeinde begleitet. Mache es warm und konkret, damit es in Seelsorge, Hausbesuchen und Frauentreffen verwendet werden kann.'),
  'FR': ('Épouse de pasteur', 'Explique pour l’épouse d’un pasteur qui prend soin des personnes dans et autour de l’Église. Rends-le chaleureux et concret pour l’accompagnement, les visites et les rencontres de femmes.'),
  'ES': ('Esposa de pastor', 'Explica para la esposa de un pastor que cuida a las personas dentro y fuera de la iglesia. Hazlo cálido y concreto para usarlo en consejería, visitas y reuniones de mujeres.'),
  'PT': ('Esposa de pastor', 'Explique para a esposa de um pastor que cuida das pessoas dentro e fora da igreja. Torne-o caloroso e concreto para aconselhamento, visitas e encontros de mulheres.'),
  'RU': ('Жена пастора', 'Объясни для жены пастора, которая заботится о людях в церкви и вокруг неё. Сделай это тёплым и конкретным, чтобы использовать в душепопечении, посещениях и женских встречах.'),
  'AR': ('زوجة القسّ', 'اشرح لزوجة قسّ ترعى الناس داخل الكنيسة وخارجها. اجعله دافئًا وملموسًا ليُستخدم في الإرشاد والزيارات واجتماعات النساء.'),
 },
}

#: 신앙 배경 — (제목, 한 줄 사실). 「선택 안 함」은 빈 글.
_FAITH_ROWS = {
 'F_NONE': {'KO': ('선택 안 함', ''), 'EN': ('Not chosen', ''), 'JA': ('選択しない', ''),
            'ZH': ('不选择', ''), 'ZHT': ('不選擇', ''), 'DE': ('Keine Angabe', ''),
            'FR': ('Non précisé', ''), 'ES': ('Sin elegir', ''), 'PT': ('Não escolhido', ''),
            'RU': ('Не выбрано', ''), 'AR': ('بلا اختيار', '')},
 'F_PROT': {'KO': ('개신교', '묻는 사람은 개신교 신자입니다.'),
            'EN': ('Protestant', 'The person asking is a Protestant Christian.'),
            'JA': ('プロテスタント', '質問者はプロテスタントの信徒です。'),
            'ZH': ('基督新教', '提问者是基督新教的信徒。'), 'ZHT': ('基督新教', '提問者是基督新教的信徒。'),
            'DE': ('Evangelisch', 'Die fragende Person ist evangelische Christin bzw. evangelischer Christ.'),
            'FR': ('Protestant', 'La personne qui pose la question est chrétienne protestante.'),
            'ES': ('Protestante', 'La persona que pregunta es cristiana protestante.'),
            'PT': ('Protestante', 'A pessoa que pergunta é cristã protestante.'),
            'RU': ('Протестант', 'Спрашивающий — христианин-протестант.'),
            'AR': ('بروتستانتي', 'السائل مسيحي بروتستانتي.')},
 'F_CATH': {'KO': ('가톨릭', '묻는 사람의 신앙 배경은 가톨릭입니다.'),
            'EN': ('Catholic', 'The person asking comes from a Catholic background.'),
            'JA': ('カトリック', '質問者の信仰背景はカトリックです。'),
            'ZH': ('天主教', '提问者的信仰背景是天主教。'), 'ZHT': ('天主教', '提問者的信仰背景是天主教。'),
            'DE': ('Katholisch', 'Die fragende Person hat einen katholischen Hintergrund.'),
            'FR': ('Catholique', 'La personne qui pose la question vient d’un milieu catholique.'),
            'ES': ('Católico', 'La persona que pregunta viene de un trasfondo católico.'),
            'PT': ('Católico', 'A pessoa que pergunta vem de um contexto católico.'),
            'RU': ('Католик', 'Спрашивающий — из католической среды.'),
            'AR': ('كاثوليكي', 'خلفية السائل الإيمانية كاثوليكية.')},
 'F_ORTH': {'KO': ('정교회', '묻는 사람의 신앙 배경은 정교회입니다.'),
            'EN': ('Orthodox', 'The person asking comes from an Orthodox background.'),
            'JA': ('正教会', '質問者の信仰背景は正教会です。'),
            'ZH': ('东正教', '提问者的信仰背景是东正教。'), 'ZHT': ('東正教', '提問者的信仰背景是東正教。'),
            'DE': ('Orthodox', 'Die fragende Person hat einen orthodoxen Hintergrund.'),
            'FR': ('Orthodoxe', 'La personne qui pose la question vient d’un milieu orthodoxe.'),
            'ES': ('Ortodoxo', 'La persona que pregunta viene de un trasfondo ortodoxo.'),
            'PT': ('Ortodoxo', 'A pessoa que pergunta vem de um contexto ortodoxo.'),
            'RU': ('Православный', 'Спрашивающий — из православной среды.'),
            'AR': ('أرثوذكسي', 'خلفية السائل الإيمانية أرثوذكسية.')},
 'F_ISLAM': {'KO': ('이슬람', '묻는 사람은 이슬람을 믿습니다.'),
             'EN': ('Islam', 'The person asking is a Muslim.'),
             'JA': ('イスラム教', '質問者はイスラム教徒です。'),
             'ZH': ('伊斯兰教', '提问者是穆斯林。'), 'ZHT': ('伊斯蘭教', '提問者是穆斯林。'),
             'DE': ('Islam', 'Die fragende Person ist Muslim bzw. Muslima.'),
             'FR': ('Islam', 'La personne qui pose la question est musulmane.'),
             'ES': ('Islam', 'La persona que pregunta es musulmana.'),
             'PT': ('Islão', 'A pessoa que pergunta é muçulmana.'),
             'RU': ('Ислам', 'Спрашивающий — мусульманин.'),
             'AR': ('الإسلام', 'السائل مسلم.')},
 'F_BUDDH': {'KO': ('불교', '묻는 사람은 불교를 믿습니다.'),
             'EN': ('Buddhism', 'The person asking is a Buddhist.'),
             'JA': ('仏教', '質問者は仏教徒です。'),
             'ZH': ('佛教', '提问者是佛教徒。'), 'ZHT': ('佛教', '提問者是佛教徒。'),
             'DE': ('Buddhismus', 'Die fragende Person ist buddhistisch.'),
             'FR': ('Bouddhisme', 'La personne qui pose la question est bouddhiste.'),
             'ES': ('Budismo', 'La persona que pregunta es budista.'),
             'PT': ('Budismo', 'A pessoa que pergunta é budista.'),
             'RU': ('Буддизм', 'Спрашивающий — буддист.'),
             'AR': ('البوذية', 'السائل بوذي.')},
 'F_ATHE': {'KO': ('무신론', '묻는 사람은 신을 믿지 않습니다.'),
            'EN': ('Atheism', 'The person asking does not believe in God.'),
            'JA': ('無神論', '質問者は神を信じていません。'),
            'ZH': ('无神论', '提问者不信神。'), 'ZHT': ('無神論', '提問者不信神。'),
            'DE': ('Atheismus', 'Die fragende Person glaubt nicht an Gott.'),
            'FR': ('Athéisme', 'La personne qui pose la question ne croit pas en Dieu.'),
            'ES': ('Ateísmo', 'La persona que pregunta no cree en Dios.'),
            'PT': ('Ateísmo', 'A pessoa que pergunta não acredita em Deus.'),
            'RU': ('Атеизм', 'Спрашивающий не верит в Бога.'),
            'AR': ('الإلحاد', 'السائل لا يؤمن بالله.')},
 'F_OTHER': {'KO': ('그 밖의 종교', '묻는 사람은 다른 종교를 믿습니다.'),
             'EN': ('Other religion', 'The person asking follows another religion.'),
             'JA': ('その他の宗教', '質問者は他の宗教を信じています。'),
             'ZH': ('其他宗教', '提问者信奉其他宗教。'), 'ZHT': ('其他宗教', '提問者信奉其他宗教。'),
             'DE': ('Andere Religion', 'Die fragende Person gehört einer anderen Religion an.'),
             'FR': ('Autre religion', 'La personne qui pose la question suit une autre religion.'),
             'ES': ('Otra religión', 'La persona que pregunta sigue otra religión.'),
             'PT': ('Outra religião', 'A pessoa que pergunta segue outra religião.'),
             'RU': ('Другая религия', 'Спрашивающий исповедует другую религию.'),
             'AR': ('دين آخر', 'السائل يتبع دينًا آخر.')},
}
SEED_AXIS_317.update(_FAITH_ROWS)

#: 옛 깊이 → 새 상태(글을 옮긴다 · 사용자가 고친 글도). 설교자는 목사 자리로.
DEPTH_TO_STATE = {'D_NEW': 'S_NEW', 'D_LAY': 'S_LAY', 'D_STUDENT': 'S_STUDENT',
                  'D_PREACH': 'S_PASTOR'}
#: 옮겨 사는 넷의 새 제목(설교자 → 목사만 이름이 바뀐다).
STATE_TITLE_PASTOR = {
    'KO': '목사', 'EN': 'Pastor', 'JA': '牧師', 'ZH': '牧师', 'ZHT': '牧師', 'DE': 'Pastor',
    'FR': 'Pasteur', 'ES': 'Pastor', 'PT': 'Pastor', 'RU': 'Пастор', 'AR': 'قسّ'}


def _state_seeds():
    """상태 아홉의 씨앗 — 옛 깊이 씨앗 넷은 그 글을 그대로(설교자 → 목사)."""
    out = {}
    for old, new in DEPTH_TO_STATE.items():
        rows = {}
        for lg, (t, b) in SEED_AXIS[old].items():
            rows[lg] = ((STATE_TITLE_PASTOR.get(lg, t) if new == 'S_PASTOR' else t), b)
        out[new] = rows
    out.update({k: v for k, v in SEED_AXIS_317.items() if k.startswith('S_')})
    return out


SEED_AXIS.update(_state_seeds())
SEED_AXIS.update({k: v for k, v in SEED_AXIS_317.items() if k.startswith('F_')})

AXES = [
    ('STATE', 'AI_STATE', 'AI_AX_STATE', '상태',      'S_'),
    ('FAITH', 'AI_FAITH', 'AI_AX_FAITH', '신앙 배경', 'F_'),
    ('VIEW',  'AI_VIEW',  'AI_AX_VIEW',  '관점',      'V_'),
]
AXIS_KEYS = [a[0] for a in AXES]
AXIS_KINDS = {
    'STATE': ['S_NONE', 'S_NEW', 'S_LAY', 'S_LEADER', 'S_STUDENT', 'S_PASTOR',
              'S_MISSION', 'S_PWIFE'],
    'FAITH': ['F_NONE', 'F_PROT', 'F_CATH', 'F_ORTH', 'F_ISLAM', 'F_BUDDH',
              'F_ATHE', 'F_OTHER'],
    'VIEW':  ['V_NEUTRAL', 'V_REFORMED', 'V_LUTHERAN', 'V_WESLEYAN',
              'V_PENTECOSTAL', 'V_DISPENSATIONAL'],
}
#: 옛 이름으로 부르는 곳(「DEPTH」)은 「상태」로 잇는다.
AXIS_ALIAS = {'DEPTH': 'STATE'}
AXIS_DEFAULT = {'STATE': 'S_NONE', 'FAITH': 'F_NONE', 'VIEW': 'V_NEUTRAL'}
AXIS_TAG = {'STATE': 'State', 'FAITH': 'Faith', 'VIEW': 'View', 'DEPTH': 'State'}
AXIS_ALL = AXIS_KINDS['STATE'] + AXIS_KINDS['FAITH'] + AXIS_KINDS['VIEW']

#: ★★★ **내용과 형식 일곱 칸**(관리자 프롬프트 탭과 같은 칸) — `user_config` 열쇠 하나씩.
#:   (열쇠, 설정 이름). 금지·출력서식은 312·311차의 칸을 그대로 쓴다.
PARTS = [('STYLE', 'AI_STYLE'), ('MUST', 'AI_MUST'), ('CITE', 'AI_CITE'),
         ('LENGTH', 'AI_LEN'), ('EXAMPLE', 'AI_EXAMPLE'), ('BAN', 'AI_BAN'),
         ('FORMAT', 'AI_FORMAT')]
PART_KEY = dict(PARTS)

#: ★★★ 보내는 글의 **칸 머리말** — 칸 이름을 대괄호로 붙인다(대화 언어로).
#:   차례가 곧 화면 칸 차례이고 보낼 차례다(`SLOTS`).
SLOTS = ['ROLE', 'TASK', 'QUESTION', 'FREE', 'PICK', 'ASKER', 'STYLE', 'MUST',
         'CITE', 'LENGTH', 'EXAMPLE', 'BAN', 'FORMAT']
SLOT_HEAD = {
 'KO': ['역할', '할일', '물음', '자유 프롬프트', 'Pick', '사용자', '문체', '반드시',
        '성경인용', '분량', '예시', '금지사항', '출력서식'],
 'EN': ['Role', 'Task', 'Question', 'Additional request', 'Also cover', 'About the user',
        'Style', 'Must', 'Bible quotations', 'Length', 'Example', 'Do not', 'Answer format'],
 'JA': ['役割', 'すること', '問い', '自由な要望', 'あわせて扱うこと', 'ユーザーについて', '文体',
        '必ず', '聖書の引用', '分量', '例', 'してはいけないこと', '答えの形'],
 'ZH': ['角色', '任务', '问题', '补充要求', '一并讨论', '关于用户', '文体', '必须',
        '圣经引用', '篇幅', '示例', '不要', '回答格式'],
 'ZHT': ['角色', '任務', '問題', '補充要求', '一併討論', '關於使用者', '文體', '必須',
         '聖經引用', '篇幅', '示例', '不要', '回答格式'],
 'DE': ['Rolle', 'Aufgabe', 'Frage', 'Weiterer Wunsch', 'Ebenfalls behandeln', 'Zum Nutzer',
        'Stil', 'Unbedingt', 'Bibelzitate', 'Umfang', 'Beispiel', 'Nicht', 'Form der Antwort'],
 'FR': ['Rôle', 'Tâche', 'Question', 'Demande supplémentaire', 'À traiter aussi', 'À propos de l’utilisateur',
        'Style', 'Obligatoire', 'Citations bibliques', 'Longueur', 'Exemple', 'À éviter', 'Forme de la réponse'],
 'ES': ['Rol', 'Tarea', 'Pregunta', 'Petición adicional', 'Tratar también', 'Sobre el usuario',
        'Estilo', 'Imprescindible', 'Citas bíblicas', 'Extensión', 'Ejemplo', 'No hacer', 'Forma de la respuesta'],
 'PT': ['Papel', 'Tarefa', 'Pergunta', 'Pedido adicional', 'Tratar também', 'Sobre o usuário',
        'Estilo', 'Obrigatório', 'Citações bíblicas', 'Extensão', 'Exemplo', 'Não fazer', 'Forma da resposta'],
 'RU': ['Роль', 'Задача', 'Вопрос', 'Дополнительная просьба', 'Также разобрать', 'О пользователе',
        'Стиль', 'Обязательно', 'Цитаты из Библии', 'Объём', 'Пример', 'Не делать', 'Форма ответа'],
 'AR': ['الدور', 'المهمة', 'السؤال', 'طلب إضافي', 'تناول أيضًا', 'عن المستخدم', 'الأسلوب', 'لا بد',
        'الاقتباس من الكتاب المقدس', 'الطول', 'مثال', 'لا تفعل', 'شكل الإجابة'],
}


def slot_head(lang='KO'):
    """칸 → 머리말(그 언어 · 없으면 영어)."""
    h = SLOT_HEAD.get((lang or 'KO').upper()) or SLOT_HEAD['EN']
    return dict(zip(SLOTS, h))


# ══════════════════════════════════════════════════════════════════════
#  317차 2단계 — 업무 유형 · 공통 역할 · 할 일 · Free
# ══════════════════════════════════════════════════════════════════════
#: ★★★ **업무 유형**(docs/1.txt 2 · 사용자 확정) — 갈래마다 고를 수 있는 일.
#:   성격 다섯(Ask·Pick·Study·Merge·Tutor)을 **업무**로 바꿔 세운다 —
#:   QUEST → 연구하자·질문 · STUDY → 연구하자·성경공부 · TEACH → 성경교사 ·
#:   MERGE → [이 채팅을 한 글로] 단추 · CHAT → Pick(곁들임 · 그대로).
#: ⚠ Free 는 업무가 없다(사용자 「업무 유형 버튼은 없다」) — Pick 과 공통 칸만.
TASKS_OF = {
    # ★ 2026-10-14 — 설명문 작성을 **일반설명문(DESC) / 전문설명문(XDESC)** 둘로(사용자 「전문설명문을 별도로 구분 ·
    #   업무유형 프롬프트를 일반설명문, 전문설명문으로」). 용어는 일반·전문 구분이 없어 하나 그대로.
    # ★ 2026-10-15 설교 작성(SERMON) — 사용자 「설교작성을 도와줘 추가」
    # ★ 2026-10-16 docs/1.txt 1-1) — 「연구하자」(RESEARCH · 질문/성경공부 갈래)를 **업무 둘로** 나눴다:
    #   ASK 구절질문(대화하듯 · 정형 질문 = Pick · 내 물음은 요구사항 칸) · STUDY 성경공부 자료 만들기.
    #   ⚠ 옛 열쇠 RESEARCH 는 이제 업무 목록에 없다 — 옛 값·Pick·직전값은 `_migrate_ask_split` 이 옮긴다.
    # ★ 용어 설명문 분석(TERMAN) — 이미 있는 용어 설명문을 살펴 짚는다(사용자 「분석해줘 선택할 수 있어야」).
    'VERSE': ['DESC', 'XDESC', 'ASK', 'STUDY', 'SERMON', 'NOTE', 'TEACH', 'LINKAN'],
    # ★ 2026-10-23 docs/2.txt 7 — 인물 살펴보기(FIGURE · 가계도·발자취·연대표의 인물 카드 AI). 사용자 「12개를 모두 Pick 으로 할 것은 없다 ·
    #   유형별로 잘 분석해서」 ⇒ Pick 여섯 = 생애와 사건 · 위기와 선택 · 잘한 것과 잘못한 것 · 관계와 비교 · 하나님과의 관계 · 오늘의 의미.
    # ★ 2026-10-23 docs/2.txt 2 — 장소 조사(PLACEAN · 발자취 장소 카드 · PLACE 용어에만 — 화면이 가른다)
    'TERM':  ['DESC', 'TERMAN', 'ASK', 'STUDY', 'TEACH', 'FIGURE', 'PLACEAN'],
    # ★ 2026-10-27 (docs/1.txt 6-1(4) 사용자 「설교노트로 다시쓰기 추가」) — SERMWR = 고른 노트(대개 연구노트)를 설교노트로 다시 쓴다
    'REF':   ['REFAN', 'SERMAN', 'SERMWR', 'BOOKMEDI'],
    # ★ 2026-10-23 docs/2.txt 1 — 연대 조사(ERAAN · 폰 연대표 카드에서만 · 닻 = 재료에 실린 그 줄)
    'ERA':   ['ERAAN'],
    'FREE':  [],
}
TASK_KEYS = ['DESC', 'XDESC', 'ASK', 'STUDY', 'TERMAN', 'SERMON', 'NOTE', 'TEACH', 'REFAN', 'SERMAN', 'SERMWR', 'BOOKMEDI',
             'LINKAN', 'FIGURE', 'PLACEAN', 'ERAAN']
#: ★ 2026-10-14 연결 살펴보기 — **연결 하나를 닻으로 연 대화에서만** 보인다(`ref_anchor='LINK:<번호>'` · 화면이 가른다).
LINK_TASKS = ('LINKAN',)
LINK_PFX = 'LINK:'
#: ★ 2026-10-14 승격 안 된 원어 낱말을 닻으로 — 용어 갈래 그대로(`ref_anchor='LEMMA:H2617'` · entity_id 없음)
LEMMA_PFX = 'LEMMA:'
#: ★ 81 — 도서 묵상은 **도서 편 닻에서만** 보이고, 연구/설교노트 닻에서는 안 보인다(화면이 가른다).
BOOK_TASKS = ('BOOKMEDI',)
#: ★ 317차-16 — 연구/설교노트 분석을 둘로(docs/1.txt 40) — 연구노트 = 근거·논리 검토 ·
#:   설교노트 = 본문 중심·구조·복음·적용·예화·청중. 닻의 갈래(`ref_type='SERMON'`)가 처음 업무를 정한다.
#: 연구하자의 세 갈래 — 하나를 고른다.
# ★ 2026-10-15 「이해 확인」(CHECK) 걷음 — 사용자 「일단 제거하자. 다른 Pick 항목과 성격이 다르다」.
#   T_CHECK 줄·씨앗은 남긴다(되돌릴 자리) · 옛 직전값 CHECK 는 `get_rmode` 가 질문으로 읽는다.
RESEARCH_MODES = ['ASK', 'STUDY']
#: ★ 홀로 서는 업무 — Pick 을 곁들이지 않는다(교사는 「한 번에 질문 하나」라 섞으면 무너진다).
SOLO_TASKS = ()          # ★ 317차-5 — 교사도 Pick 을 곁들인다(사용자 예시)
#: 업무 → 프롬프트 줄(kind). 설명문은 구절·용어가 쓰는 꼴이 달라 둘로 갈린다.
TASK_KIND = {
    ('DESC', 'VERSE'): 'T_DESC_V', ('DESC', 'TERM'): 'T_DESC_T',
    'XDESC': 'T_XDESC_V', 'LINKAN': 'T_LINKAN',
    ('RESEARCH', 'ASK'): 'T_ASK', ('RESEARCH', 'CHECK'): 'T_CHECK',
    ('RESEARCH', 'STUDY'): 'T_STUDY',
    'NOTE': 'T_NOTE', 'TEACH': 'T_TEACH', 'REFAN': 'T_REFAN', 'SERMAN': 'T_SERMAN', 'SERMWR': 'T_SERMWR',
    'BOOKMEDI': 'T_BOOKMEDI', 'SERMON': 'T_SERMON_V',
    'ASK': 'T_ASK', 'STUDY': 'T_STUDY', 'TERMAN': 'T_TERMAN', 'FIGURE': 'T_FIGURE',
    'PLACEAN': 'T_PLACEAN', 'ERAAN': 'T_ERAAN',
}
ROLE_KIND = 'T_ROLE'
TASK_ALL = [ROLE_KIND, 'T_DESC_V', 'T_XDESC_V', 'T_LINKAN', 'T_DESC_T', 'T_ASK', 'T_CHECK', 'T_STUDY',
            'T_NOTE', 'T_TEACH', 'T_REFAN', 'T_SERMAN', 'T_SERMWR', 'T_BOOKMEDI', 'T_SERMON_V', 'T_TERMAN', 'T_FIGURE',
            'T_PLACEAN', 'T_ERAAN']
#: 옛 씨앗 → 새 업무 줄. **사람이 고친 글이면** 그 글을 새 줄로 옮긴다(`_migrate_tasks`).
OLD_TO_TASK = {'CHECK': 'T_CHECK', 'STUDY': 'T_STUDY', 'TEACH': 'T_TEACH',
               'NOTE': 'T_NOTE', 'REF_HELP': 'T_REFAN', 'TERM_STUDY': 'T_STUDY'}
#: 옛 씨앗 가운데 **업무가 맡게 된 것** — 창고(Pick 목록)에 다시 안 뜬다.
#:   ⚠ MERGE 는 단추가 쓴다(`merge_prompt_body`) — 창고에서만 빠진다.
TASK_SUPERSEDED = ('CHECK', 'STUDY', 'TEACH', 'NOTE', 'MERGE', 'REF_HELP', 'TERM_STUDY')

#: ★ 설명문 칸 이름 — **채팅 언어로** 적게 하고 저장할 때 한국어 칸으로 되읽는다
#:   (`db_ai_job.bundle_split` 이 한국어 이름을 안다). 차례 = 설명문 · 묵상질문 · 묵상기도 · 연구질문.
DESC_MARKS = {
    'KO':  ('설명문', '묵상질문', '묵상기도', '연구질문', '전문 설명'),
    'EN':  ('Explanation', 'Reflection question', 'Prayer', 'Study question', 'In-depth explanation'),
    'JA':  ('説明', '黙想の問い', '黙想の祈り', '研究の問い', '専門的な説明'),
    'ZH':  ('说明', '默想问题', '默想祷告', '研究问题', '深入说明'),
    'ZHT': ('說明', '默想問題', '默想禱告', '研究問題', '深入說明'),
    'DE':  ('Erklärung', 'Frage zur Besinnung', 'Gebet', 'Studienfrage', 'Vertiefte Erklärung'),
    'FR':  ('Explication', 'Question de méditation', 'Prière', "Question d'étude", 'Explication approfondie'),
    'ES':  ('Explicación', 'Pregunta de meditación', 'Oración', 'Pregunta de estudio', 'Explicación detallada'),
    'PT':  ('Explicação', 'Pergunta de meditação', 'Oração', 'Pergunta de estudo', 'Explicação aprofundada'),
    'RU':  ('Объяснение', 'Вопрос для размышления', 'Молитва', 'Вопрос для изучения', 'Углублённое объяснение'),
    'AR':  ('الشرح', 'سؤال للتأمل', 'صلاة', 'سؤال للدراسة', 'شرح معمّق'),
}
_DESC_KO = DESC_MARKS['KO']
#: ★ 2026-10-14 연결설명문 칸 이름(연결 살펴보기 업무 · 폰이 이 칸만 떼어 「연결설명문으로」 담는다)
LINK_MARKS = {'KO': '연결설명', 'EN': 'Connection note', 'JA': '関連の説明', 'ZH': '关联说明', 'ZHT': '關聯說明',
              'DE': 'Verbindungserklärung', 'FR': 'Note de lien', 'ES': 'Nota de conexión', 'PT': 'Nota de ligação',
              'RU': 'Пояснение связи', 'AR': 'شرح الصلة'}


def _desc_tpl(lg):
    m = DESC_MARKS.get(lg) or DESC_MARKS['EN']
    return ' '.join('[%s]' % x for x in m[:3]), '[%s]' % m[3]


SEED_TASK = {
    'T_ROLE': {
        'KO': ('역할', '당신은 성경을 깊이 아는 성경 교사입니다. 본문에 근거해 정직하고 따뜻하게 돕습니다.'),
        'EN': ('Role', 'You are a Bible teacher who knows the Scriptures deeply. You help honestly and warmly, grounded in the text.'),
        'JA': ('役割', 'あなたは聖書を深く知る聖書教師です。本文に基づいて、誠実に温かく助けてください。'),
        'ZH': ('角色', '你是一位深知圣经的圣经老师。请根据经文，诚实而温暖地帮助人。'),
        'ZHT': ('角色', '你是一位深知聖經的聖經老師。請根據經文，誠實而溫暖地幫助人。'),
        'DE': ('Rolle', 'Du bist ein Bibellehrer, der die Schrift gut kennt. Du hilfst ehrlich und freundlich und bleibst beim Text.'),
        'FR': ('Rôle', 'Tu es un enseignant biblique qui connaît bien les Écritures. Tu aides avec honnêteté et bienveillance, en restant fidèle au texte.'),
        'ES': ('Rol', 'Eres un maestro bíblico que conoce bien las Escrituras. Ayudas con honestidad y calidez, basándote en el texto.'),
        'PT': ('Papel', 'Você é um professor bíblico que conhece bem as Escrituras. Ajuda com honestidade e carinho, com base no texto.'),
        'RU': ('Роль', 'Ты учитель Библии, хорошо знающий Писание. Ты помогаешь честно и тепло, опираясь на текст.'),
        'AR': ('الدور', 'أنت معلّم للكتاب المقدس يعرفه معرفة عميقة. تساعد بصدق ودفء مستندًا إلى النص.'),
    },
    'T_DESC_T': {
        'KO': ('용어 설명문 작성', '[용어]의 설명문을 써 주세요. 이 낱말이 성경에서 무엇을 뜻하고 어디서 어떻게 쓰이는지 두세 문단으로 쉽게 풀어 주세요.'),
        'EN': ('Write a term description', 'Write a description of [term]. In two or three paragraphs, explain plainly what this word means in the Bible and where and how it is used.'),
        'JA': ('用語説明を書く', '[用語]の説明文を書いてください。この言葉が聖書で何を意味し、どこでどのように使われるかを、二、三段落でやさしく説明してください。'),
        'ZH': ('撰写词语说明', '请为[词语]写一段说明。用两三段浅白的话解释这个词在圣经中的意思，以及在哪里、如何使用。'),
        'ZHT': ('撰寫詞語說明', '請為[詞語]寫一段說明。用兩三段淺白的話解釋這個詞在聖經中的意思，以及在哪裡、如何使用。'),
        'DE': ('Begriffserklärung schreiben', 'Schreibe eine Erklärung zu [Begriff]. Erkläre in zwei oder drei Absätzen einfach, was dieses Wort in der Bibel bedeutet und wo und wie es gebraucht wird.'),
        'FR': ('Rédiger une définition', 'Rédige une explication de [terme]. En deux ou trois paragraphes, explique simplement ce que ce mot veut dire dans la Bible, où et comment il est employé.'),
        'ES': ('Escribir una definición', 'Escribe una explicación de [término]. En dos o tres párrafos, explica con sencillez qué significa esta palabra en la Biblia y dónde y cómo se usa.'),
        'PT': ('Escrever uma definição', 'Escreva uma explicação de [termo]. Em dois ou três parágrafos, explique com simplicidade o que esta palavra significa na Bíblia e onde e como é usada.'),
        'RU': ('Написать пояснение к слову', 'Напиши пояснение к слову [термин]. В двух-трёх абзацах просто объясни, что это слово значит в Библии и где и как оно употребляется.'),
        'AR': ('كتابة شرح للمصطلح', 'اكتب شرحًا لـ [المصطلح]. اشرح ببساطة في فقرتين أو ثلاث ما تعنيه هذه الكلمة في الكتاب المقدس وأين وكيف تُستعمل.'),
    },
    # ★ 2026-10-16 docs/1.txt 1-1) — 「질문을 던지면 설교하듯 답한다」 · 대화하듯 · 요지 먼저 · 짧게(옛 글 = OLD_T_ASK)
    'T_ASK': {
        'KO': ('질문', '[구절]에 대해 묻습니다. 대화하듯 답해 주세요. 물음의 요지에 먼저 짧게 답하고, 필요한 설명은 짧은 문단 두세 개 안에서 이어 가세요. 근거 구절은 한두 개만 들고, 설교나 강의처럼 길게 쓰지 마세요. 물음이 모호하면 짧게 되물어도 됩니다.'),
        'EN': ('Question', 'I have a question about [verse]. Answer as in a conversation: answer the point first, briefly, then continue within two or three short paragraphs if needed. Cite only one or two supporting verses, and do not write at length like a sermon or lecture. If the question is unclear, you may briefly ask back.'),
        'JA': ('質問', '[聖句]について質問します。会話するように答えてください。まず問いの要点に短く答え、必要な説明は短い段落二、三つの中で続けてください。根拠となる箇所は一つか二つにとどめ、説教や講義のように長く書かないでください。問いがあいまいなら短く聞き返してもかまいません。'),
        'ZH': ('提问', '我想就[经文]提问。请像对话一样回答：先简短回答问题的要点，需要说明时用两三个短段落继续。依据经文只举一两处，不要像讲道或讲课那样写得很长。如果问题不清楚，可以简短地反问。'),
        'ZHT': ('提問', '我想就[經文]提問。請像對話一樣回答：先簡短回答問題的要點，需要說明時用兩三個短段落繼續。依據經文只舉一兩處，不要像講道或講課那樣寫得很長。如果問題不清楚，可以簡短地反問。'),
        'DE': ('Frage', 'Ich habe eine Frage zu [Vers]. Antworte wie im Gespräch: zuerst kurz auf den Kern der Frage, dann bei Bedarf in zwei oder drei kurzen Absätzen weiter. Nenne nur ein oder zwei Belegstellen und schreibe nicht lang wie eine Predigt oder Vorlesung. Wenn die Frage unklar ist, darfst du kurz nachfragen.'),
        'FR': ('Question', 'J’ai une question sur [verset]. Réponds comme dans une conversation : d’abord brièvement sur l’essentiel, puis, si besoin, en deux ou trois courts paragraphes. Ne cite qu’un ou deux versets à l’appui et n’écris pas longuement comme un sermon ou un cours. Si la question n’est pas claire, tu peux brièvement la reformuler.'),
        'ES': ('Pregunta', 'Tengo una pregunta sobre [versículo]. Responde como en una conversación: primero, brevemente, al punto de la pregunta; después, si hace falta, en dos o tres párrafos cortos. Cita solo uno o dos versículos de apoyo y no escribas largo como un sermón o una clase. Si la pregunta no está clara, puedes preguntar brevemente.'),
        'PT': ('Pergunta', 'Tenho uma pergunta sobre [versículo]. Responda como numa conversa: primeiro, de forma breve, ao ponto da pergunta; depois, se preciso, em dois ou três parágrafos curtos. Cite apenas um ou dois versículos de apoio e não escreva longamente como um sermão ou uma aula. Se a pergunta não estiver clara, pode perguntar de volta brevemente.'),
        'RU': ('Вопрос', 'У меня вопрос о [стих]. Отвечай как в разговоре: сначала коротко по сути вопроса, затем при необходимости в двух-трёх коротких абзацах. Приводи лишь один-два подтверждающих стиха и не пиши длинно, как проповедь или лекцию. Если вопрос неясен, можешь коротко переспросить.'),
        'AR': ('سؤال', 'لدي سؤال عن [الآية]. أجب كما في حديث: أجب أولاً باختصار عن جوهر السؤال، ثم أكمل عند الحاجة في فقرتين أو ثلاث فقرات قصيرة. اذكر آية أو آيتين فقط للاستشهاد، ولا تكتب طويلاً كعظة أو محاضرة. إن كان السؤال غير واضح فيمكنك أن تستوضح باختصار.'),
    },
    # ★ 2026-10-16 용어 설명문 분석(docs/1.txt 1-2)(4))
    'T_TERMAN': {
        'KO': ('용어 설명문 분석', '[용어]의 지금 설명문을 성경에 비추어 살펴 주세요. 잘 짚은 점, 빠졌거나 치우친 점, 근거가 약한 주장, 함께 보면 좋을 구절을 짧게 짚어 주세요. 설명문을 대신 다시 쓰지는 마세요.'),
        'EN': ('Analyze the term description', 'Look at the current description of [term] in the light of Scripture. Briefly point out what it gets right, what is missing or one-sided, claims with weak support, and passages worth adding. Do not rewrite the description.'),
        'JA': ('用語説明の分析', '[用語]の今の説明文を聖書に照らして見てください。よく捉えている点、欠けている点や偏っている点、根拠の弱い主張、合わせて読むとよい箇所を短く示してください。説明文を代わりに書き直さないでください。'),
        'ZH': ('分析词语说明', '请对照圣经查看[词语]现有的说明。简短指出说得好的地方、遗漏或偏颇之处、依据薄弱的说法，以及值得一并参考的经文。不要替我改写说明。'),
        'ZHT': ('分析詞語說明', '請對照聖經查看[詞語]現有的說明。簡短指出說得好的地方、遺漏或偏頗之處、依據薄弱的說法，以及值得一併參考的經文。不要替我改寫說明。'),
        'DE': ('Begriffserklärung prüfen', 'Prüfe die jetzige Erklärung zu [Begriff] im Licht der Schrift. Zeige kurz, was gut getroffen ist, was fehlt oder einseitig ist, welche Aussagen schwach belegt sind und welche Stellen man ergänzen sollte. Schreibe die Erklärung nicht neu.'),
        'FR': ('Analyser la définition', 'Examine l’explication actuelle de [terme] à la lumière de l’Écriture. Indique brièvement ce qui est juste, ce qui manque ou est partial, les affirmations mal fondées et les passages à ajouter. Ne réécris pas l’explication.'),
        'ES': ('Analizar la definición', 'Revisa la explicación actual de [término] a la luz de la Escritura. Señala brevemente lo que acierta, lo que falta o es parcial, las afirmaciones con poco fundamento y los pasajes que conviene añadir. No reescribas la explicación.'),
        'PT': ('Analisar a definição', 'Examine a explicação atual de [termo] à luz da Escritura. Aponte brevemente o que está certo, o que falta ou é parcial, as afirmações com pouco fundamento e as passagens que valeria acrescentar. Não reescreva a explicação.'),
        'RU': ('Разбор пояснения к слову', 'Рассмотри нынешнее пояснение к слову [термин] в свете Писания. Коротко укажи, что в нём верно, чего не хватает или что однобоко, какие утверждения слабо обоснованы и какие места стоит добавить. Не переписывай пояснение.'),
        'AR': ('تحليل شرح المصطلح', 'افحص الشرح الحالي لـ [المصطلح] في ضوء الكتاب المقدس. بيّن باختصار ما أصاب فيه، وما نقص أو انحاز، والأقوال الضعيفة السند، والمقاطع التي يحسن إضافتها. لا تُعِد كتابة الشرح.'),
    },
    'T_CHECK': {
        'KO': ('이해 확인', '[구절]에 대해 내가 이해한 것을 아래에 적었습니다. 맞는 부분과 바로잡을 부분을 본문에 근거해 짚어 주세요.'),
        'EN': ('Check my understanding', 'Below is how I understand [verse]. Point out, from the text, what is right and what needs correcting.'),
        'JA': ('理解の確認', '[聖句]について私が理解したことを下に書きました。本文に基づいて、正しい点と直すべき点を示してください。'),
        'ZH': ('理解确认', '我把对[经文]的理解写在下面。请根据经文指出哪些对、哪些需要纠正。'),
        'ZHT': ('理解確認', '我把對[經文]的理解寫在下面。請根據經文指出哪些對、哪些需要糾正。'),
        'DE': ('Verständnis prüfen', 'Unten steht, wie ich [Vers] verstehe. Zeige anhand des Textes, was stimmt und was zu korrigieren ist.'),
        'FR': ('Vérifier ma compréhension', 'Voici ci-dessous ce que je comprends de [verset]. Montre, à partir du texte, ce qui est juste et ce qu’il faut corriger.'),
        'ES': ('Comprobar mi comprensión', 'Abajo escribí cómo entiendo [versículo]. Señala, desde el texto, lo que es correcto y lo que hay que corregir.'),
        'PT': ('Verificar meu entendimento', 'Abaixo escrevi como entendo [versículo]. Mostre, a partir do texto, o que está certo e o que precisa ser corrigido.'),
        'RU': ('Проверка понимания', 'Ниже я написал, как понимаю [стих]. Покажи по тексту, что верно, а что нужно исправить.'),
        'AR': ('التحقق من فهمي', 'كتبت أدناه كيف أفهم [الآية]. بيّن من النص ما هو صحيح وما يحتاج إلى تصحيح.'),
    },
    'T_STUDY': {
        'KO': ('성경공부', '[구절]로 성경공부 자료를 만들어 주세요. 배경, 본문의 흐름, 핵심 낱말, 함께 읽을 구절, 나눔 질문 차례로 써 주세요.'),
        'EN': ('Bible study', 'Make Bible study material on [verse]: background, flow of the text, key words, related passages, and discussion questions, in that order.'),
        'JA': ('聖書研究', '[聖句]で聖書研究の資料を作ってください。背景、本文の流れ、鍵となる言葉、あわせて読む箇所、分かち合いの問いの順に書いてください。'),
        'ZH': ('查经', '请用[经文]做一份查经材料，依次写出背景、经文脉络、关键词、参考经文和分享问题。'),
        'ZHT': ('查經', '請用[經文]做一份查經材料，依次寫出背景、經文脈絡、關鍵詞、參考經文和分享問題。'),
        'DE': ('Bibelarbeit', 'Erstelle eine Bibelarbeit zu [Vers]: Hintergrund, Gedankengang des Textes, Schlüsselwörter, Parallelstellen und Gesprächsfragen, in dieser Reihenfolge.'),
        'FR': ('Étude biblique', 'Prépare une étude biblique sur [verset] : contexte, déroulement du texte, mots clés, passages à lire ensemble et questions de partage, dans cet ordre.'),
        'ES': ('Estudio bíblico', 'Prepara un estudio bíblico sobre [versículo]: contexto, desarrollo del texto, palabras clave, pasajes relacionados y preguntas para compartir, en ese orden.'),
        'PT': ('Estudo bíblico', 'Prepare um estudo bíblico sobre [versículo]: contexto, desenvolvimento do texto, palavras-chave, passagens relacionadas e perguntas para partilha, nessa ordem.'),
        'RU': ('Изучение Библии', 'Подготовь материал для изучения [стих]: контекст, ход мысли текста, ключевые слова, связанные места и вопросы для обсуждения, в этом порядке.'),
        'AR': ('دراسة الكتاب', 'أعدّ مادة لدراسة [الآية]: الخلفية، وتسلسل النص، والكلمات المفتاحية، والمقاطع ذات الصلة، وأسئلة للمشاركة، بهذا الترتيب.'),
    },
    'T_NOTE': {
        'KO': ('묵상노트 분석', '[구절]에 대해 내가 쓴 묵상노트를 분석해 주세요. 본문에 비추어 잘 붙든 점과 놓친 점을 짚고, 더 깊이 묵상할 방향을 하나 제안해 주세요. 노트를 대신 고쳐 쓰지는 마세요.'),
        'EN': ('Analyze my notes', 'Analyze my meditation notes on [verse]. In light of the text, point out what I grasped well and what I missed, and suggest one direction for deeper meditation. Do not rewrite my notes.'),
        'JA': ('黙想ノート分析', '[聖句]について私が書いた黙想ノートを分析してください。本文に照らして、よく捉えた点と見落とした点を示し、さらに深く黙想する方向を一つ提案してください。ノートを代わりに書き直さないでください。'),
        'ZH': ('默想笔记分析', '请分析我就[经文]写的默想笔记。对照经文，指出我把握得好的地方和遗漏的地方，并建议一个更深默想的方向。不要替我改写笔记。'),
        'ZHT': ('默想筆記分析', '請分析我就[經文]寫的默想筆記。對照經文，指出我把握得好的地方和遺漏的地方，並建議一個更深默想的方向。不要替我改寫筆記。'),
        'DE': ('Notizen auswerten', 'Werte meine Andachtsnotizen zu [Vers] aus. Zeige im Licht des Textes, was ich gut erfasst und was ich übersehen habe, und schlage eine Richtung zum tieferen Nachdenken vor. Schreibe meine Notizen nicht um.'),
        'FR': ('Analyser mes notes', 'Analyse mes notes de méditation sur [verset]. À la lumière du texte, montre ce que j’ai bien saisi et ce qui m’a échappé, et propose une piste pour méditer plus loin. Ne réécris pas mes notes.'),
        'ES': ('Analizar mis notas', 'Analiza mis notas de meditación sobre [versículo]. A la luz del texto, señala lo que capté bien y lo que pasé por alto, y sugiere una dirección para meditar más a fondo. No reescribas mis notas.'),
        'PT': ('Analisar minhas notas', 'Analise minhas notas de meditação sobre [versículo]. À luz do texto, mostre o que captei bem e o que deixei passar, e sugira uma direção para meditar mais a fundo. Não reescreva minhas notas.'),
        'RU': ('Разбор моих заметок', 'Разбери мои заметки для размышления о [стих]. В свете текста покажи, что я уловил верно и что упустил, и предложи одно направление для более глубокого размышления. Не переписывай мои заметки.'),
        'AR': ('تحليل ملاحظاتي', 'حلّل ملاحظات التأمل التي كتبتها عن [الآية]. في ضوء النص، بيّن ما أدركته جيدًا وما فاتني، واقترح اتجاهًا واحدًا لتأمل أعمق. لا تعد كتابة ملاحظاتي.'),
    },
    'T_SERMON_V': {
        'KO': ('설교 작성', '[구절]로 설교를 준비하도록 도와 주세요. 본문이 실제로 말하는 것에서 출발하고, 아래 Pick 에서 선택한 것을 그 차례대로 다뤄 주세요. 선택한 것이 없으면 본문 관찰 · 중심 메시지 · 설교 개요 · 적용을 다뤄 주세요. 본문에 없는 뜻을 끌어오지 말고, 해석이 갈리는 곳은 한 견해를 정답처럼 말하지 마세요. 재료에 「연결구절」이 있으면 설교에 실제로 힘이 되는 것만 쓰세요.'),
        'EN': ('Sermon writing', 'Help me prepare a sermon on [passage]. Start from what the text actually says and cover the items chosen under Pick in that order. If none are chosen, cover observation of the text, the central message, a sermon outline and application. Do not read into the text what is not there, and where interpretations differ, do not present one view as the only answer. If the material includes "Linked verses", use only those that really strengthen the sermon.'),
        'JA': ('説教作成', '[聖句]で説教を準備するのを手伝ってください。本文が実際に語っていることから出発し、下の Pick で選んだものをその順に扱ってください。何も選んでいなければ、本文の観察・中心メッセージ・説教のアウトライン・適用を扱ってください。本文にない意味を持ち込まず、解釈が分かれるところでは一つの見解を正解のように語らないでください。資料に「関連聖句」があれば、説教に本当に役立つものだけを使ってください。'),
        'ZH': ('撰写讲道', '请帮助我用[经文]预备讲道。从经文实际所说的出发，按下面 Pick 中所选的顺序处理。若没有选择，请处理经文观察、中心信息、讲道大纲和应用。不要把经文中没有的意思带进来；解释有分歧之处，不要把一种观点说成唯一答案。材料中若有“相关经文”，只使用真正有助于讲道的。'),
        'ZHT': ('撰寫講道', '請幫助我用[經文]預備講道。從經文實際所說的出發，按下面 Pick 中所選的順序處理。若沒有選擇，請處理經文觀察、中心信息、講道大綱和應用。不要把經文中沒有的意思帶進來；解釋有分歧之處，不要把一種觀點說成唯一答案。材料中若有「相關經文」，只使用真正有助於講道的。'),
        'DE': ('Predigt schreiben', 'Hilf mir, eine Predigt über [Stelle] vorzubereiten. Geh von dem aus, was der Text tatsächlich sagt, und behandle die unter Pick gewählten Punkte in dieser Reihenfolge. Ist nichts gewählt, behandle Beobachtung des Textes, Kernbotschaft, Predigtgliederung und Anwendung. Trage nichts in den Text hinein, und wo Auslegungen auseinandergehen, stelle keine Sicht als die einzige Antwort dar. Enthält das Material „Verknüpfte Verse“, nutze nur die, die die Predigt wirklich stärken.'),
        'FR': ('Rédiger une prédication', 'Aide-moi à préparer une prédication sur [passage]. Pars de ce que dit réellement le texte et traite, dans cet ordre, les points choisis sous Pick. Si rien n’est choisi, traite l’observation du texte, le message central, un plan de prédication et l’application. N’introduis pas dans le texte ce qui n’y est pas, et là où les interprétations divergent, ne présente pas un avis comme la seule réponse. Si le matériau contient des « versets liés », n’utilise que ceux qui renforcent vraiment la prédication.'),
        'ES': ('Escribir un sermón', 'Ayúdame a preparar un sermón sobre [pasaje]. Parte de lo que el texto dice realmente y trata, en ese orden, los puntos elegidos en Pick. Si no hay nada elegido, trata la observación del texto, el mensaje central, un bosquejo del sermón y la aplicación. No introduzcas en el texto lo que no está, y donde las interpretaciones difieren, no presentes una opinión como la única respuesta. Si el material incluye «versículos relacionados», usa solo los que de verdad fortalezcan el sermón.'),
        'PT': ('Escrever um sermão', 'Ajude-me a preparar um sermão sobre [passagem]. Parta do que o texto realmente diz e trate, nessa ordem, os pontos escolhidos em Pick. Se nada for escolhido, trate a observação do texto, a mensagem central, um esboço do sermão e a aplicação. Não introduza no texto o que não está nele e, onde as interpretações divergem, não apresente uma visão como a única resposta. Se o material incluir «versículos relacionados», use só os que realmente fortalecem o sermão.'),
        'RU': ('Подготовка проповеди', 'Помоги мне подготовить проповедь по [отрывок]. Исходи из того, что действительно говорит текст, и разбери по порядку пункты, выбранные в Pick. Если ничего не выбрано, разбери наблюдение над текстом, главную мысль, план проповеди и применение. Не вкладывай в текст того, чего в нём нет, а где толкования расходятся, не выдавай одно мнение за единственный ответ. Если в материале есть «связанные стихи», используй только те, что действительно укрепляют проповедь.'),
        'AR': ('كتابة عظة', 'ساعدني في إعداد عظة عن [المقطع]. ابدأ مما يقوله النص فعلًا، وتناول بالترتيب البنود المختارة في Pick. إن لم يُختر شيء فتناول ملاحظة النص والرسالة المحورية ومخطط العظة والتطبيق. لا تُدخل في النص ما ليس فيه، وحيث تختلف التفاسير لا تقدّم رأيًا واحدًا كأنه الجواب الوحيد. إن احتوت المادة على «آيات مرتبطة» فاستعمل فقط ما يقوّي العظة فعلًا.'),
    },
    'T_TEACH': {
        'KO': ('성경교사', '[구절]을 함께 공부하는 성경 교사가 되어 주세요. 한 번에 질문 하나만 하고 내 답을 기다리세요. 질문을 여러 개 한꺼번에 내지 마세요. 내 답을 들은 뒤 짧게 짚어 주고 다음 질문을 하세요. 질문을 마칠 때가 되면 함께 배운 것을 정리해 주세요.'),
        'EN': ('Bible tutor', 'Be a Bible teacher studying [verse] with me. Ask only one question at a time and wait for my answer. Never ask several questions at once. After my answer, comment briefly and then ask the next question. When the questions are over, sum up what we learned.'),
        'JA': ('聖書教師', '[聖句]を一緒に学ぶ聖書教師になってください。一度に一つだけ質問し、私の答えを待ってください。いくつもの質問を一度に出さないでください。私の答えを聞いたら短く応じ、次の質問をしてください。五つほど質問したら、学んだことをまとめてください。'),
        'ZH': ('圣经老师', '请做一位和我一起学习[经文]的圣经老师。每次只问一个问题，等我回答。不要一次问几个问题。听了我的回答后简短回应，再问下一个问题。大约五个问题后，总结我们学到的。'),
        'ZHT': ('聖經老師', '請做一位和我一起學習[經文]的聖經老師。每次只問一個問題，等我回答。不要一次問幾個問題。聽了我的回答後簡短回應，再問下一個問題。大約五個問題後，總結我們學到的。'),
        'DE': ('Bibellehrer', 'Sei ein Bibellehrer, der mit mir [Vers] studiert. Stelle immer nur eine Frage und warte auf meine Antwort. Stelle nie mehrere Fragen auf einmal. Gehe kurz auf meine Antwort ein und stelle dann die nächste Frage. Fasse nach etwa fünf Fragen zusammen, was wir gelernt haben.'),
        'FR': ('Enseignant biblique', 'Sois un enseignant biblique qui étudie [verset] avec moi. Pose une seule question à la fois et attends ma réponse. Ne pose jamais plusieurs questions d’un coup. Après ma réponse, commente brièvement puis pose la question suivante. Après environ cinq questions, résume ce que nous avons appris.'),
        'ES': ('Maestro bíblico', 'Sé un maestro bíblico que estudia [versículo] conmigo. Haz una sola pregunta a la vez y espera mi respuesta. Nunca hagas varias preguntas juntas. Después de mi respuesta, comenta brevemente y haz la siguiente pregunta. Tras unas cinco preguntas, resume lo que aprendimos.'),
        'PT': ('Professor bíblico', 'Seja um professor bíblico que estuda [versículo] comigo. Faça uma só pergunta de cada vez e espere a minha resposta. Nunca faça várias perguntas juntas. Depois da minha resposta, comente brevemente e faça a pergunta seguinte. Após umas cinco perguntas, resuma o que aprendemos.'),
        'RU': ('Учитель Библии', 'Будь учителем Библии, который изучает со мной [стих]. Задавай только один вопрос за раз и жди моего ответа. Никогда не задавай несколько вопросов сразу. После моего ответа кратко прокомментируй и задай следующий вопрос. Примерно после пяти вопросов подведи итог того, что мы узнали.'),
        'AR': ('معلّم الكتاب', 'كن معلّمًا للكتاب يدرس معي [الآية]. اطرح سؤالًا واحدًا فقط في كل مرة وانتظر جوابي. لا تطرح عدة أسئلة دفعة واحدة. بعد جوابي علّق باختصار ثم اطرح السؤال التالي. بعد نحو خمسة أسئلة لخّص ما تعلمناه.'),
    },
    'T_SERMAN': {
        'KO': ('내 설교노트 분석', '내 설교노트 [구절]을 분석해 주세요. 본문이 말하는 것을 설교가 따라가는지, 중심 메시지가 하나로 서 있는지, 대지와 흐름이 본문에서 나오는지, 그리스도와 복음에 닿는지, 적용이 구체적인지, 예화가 본문을 돕는지 짚어 주세요. 설교를 대신 다시 쓰지는 마세요.'),
        'EN': ('Analyze my sermon', 'Analyze my sermon note "[verse]". Show whether the sermon follows what the text says, whether one central message stands, whether the points and flow come out of the text, whether it reaches Christ and the gospel, whether the application is concrete, and whether the illustrations serve the text. Do not rewrite the sermon for me.'),
        'JA': ('説教ノートの分析', '私の説教ノート「[聖句]」を分析してください。説教が本文の語ることに従っているか、中心メッセージが一つに立っているか、要点と流れが本文から出ているか、キリストと福音に届いているか、適用が具体的か、例話が本文を助けているかを示してください。代わりに説教を書き直さないでください。'),
        'ZH': ('讲道笔记分析', '请分析我的讲道笔记“[经文]”。指出讲道是否跟随经文本身所说的、中心信息是否单一清楚、要点与脉络是否出自经文、是否指向基督与福音、应用是否具体、例证是否帮助理解经文。不要替我重写讲章。'),
        'ZHT': ('講道筆記分析', '請分析我的講道筆記「[經文]」。指出講道是否跟隨經文本身所說的、中心信息是否單一清楚、要點與脈絡是否出自經文、是否指向基督與福音、應用是否具體、例證是否幫助理解經文。不要替我重寫講章。'),
        'DE': ('Predigt auswerten', 'Werte meine Predigtnotiz „[Vers]“ aus. Zeige, ob die Predigt dem folgt, was der Text sagt, ob eine zentrale Botschaft steht, ob Gliederung und Verlauf aus dem Text kommen, ob sie zu Christus und dem Evangelium führt, ob die Anwendung konkret ist und ob die Beispiele dem Text dienen. Schreibe die Predigt nicht für mich um.'),
        'FR': ('Analyser mon sermon', 'Analyse ma note de sermon « [verset] ». Montre si le sermon suit ce que dit le texte, si un message central se tient, si les points et le déroulement viennent du texte, s’il conduit au Christ et à l’Évangile, si l’application est concrète et si les illustrations servent le texte. Ne réécris pas le sermon à ma place.'),
        'ES': ('Analizar mi sermón', 'Analiza mi nota de sermón «[versículo]». Señala si el sermón sigue lo que dice el texto, si se sostiene un mensaje central, si los puntos y el desarrollo salen del texto, si llega a Cristo y al evangelio, si la aplicación es concreta y si las ilustraciones sirven al texto. No reescribas el sermón por mí.'),
        'PT': ('Analisar meu sermão', 'Analise minha nota de sermão “[versículo]”. Mostre se o sermão segue o que o texto diz, se uma mensagem central se sustenta, se os pontos e o desenvolvimento saem do texto, se chega a Cristo e ao evangelho, se a aplicação é concreta e se as ilustrações servem ao texto. Não reescreva o sermão por mim.'),
        'RU': ('Разбор моей проповеди', 'Разбери мою заметку к проповеди «[стих]». Покажи, следует ли проповедь тому, что говорит текст, есть ли одна главная мысль, вытекают ли пункты и ход из текста, приводит ли она ко Христу и Евангелию, конкретно ли применение и служат ли примеры тексту. Не переписывай проповедь за меня.'),
        'AR': ('تحليل عظتي', 'حلّل ملاحظة عظتي «[الآية]». بيّن هل تتبع العظة ما يقوله النص، وهل تقوم رسالة مركزية واحدة، وهل تنبع النقاط والتسلسل من النص، وهل تصل إلى المسيح والإنجيل، وهل التطبيق محدد، وهل تخدم الأمثلة النص. لا تعد كتابة العظة بدلًا مني.'),
    },
    # ★ 2026-10-27 설교노트로 다시 쓰기 — 노트의 내용·근거를 지키고 설교의 꼴로(새 주장 · 새 예화를 지어내지 않는다)
    'T_SERMWR': {
        'KO': ('설교노트로 다시 쓰기', '내 노트 [구절]을 설교노트로 다시 써 주세요. 노트에 있는 본문 해석과 근거를 그대로 지키면서 설교의 꼴로 옮겨 주세요 — 본문, 중심 메시지 한 문장, 대지(본문의 흐름에서 나온 것), 그리스도와 복음, 적용의 방향. 노트에 없는 주장이나 예화를 지어내지 말고, 보탤 것이 있으면 따로 「보탤 만한 것」으로 적어 주세요.'),
        'EN': ('Rewrite as a sermon note', 'Rewrite my note "[verse]" as a sermon note. Keep the interpretation and evidence in the note as they are and put them into the shape of a sermon: the text, the central message in one sentence, the points (coming from the flow of the text), Christ and the gospel, and the direction of application. Do not invent claims or illustrations that are not in the note; if something could be added, list it separately under "Could be added".'),
        'JA': ('説教ノートに書き直す', '私のノート「[聖句]」を説教ノートに書き直してください。ノートにある本文の解釈と根拠はそのまま保ち、説教の形に移してください — 本文、中心メッセージを一文で、要点（本文の流れから出たもの）、キリストと福音、適用の方向。ノートにない主張や例話を作らず、加えられるものがあれば「加えられるもの」として別に書いてください。'),
        'ZH': ('改写为讲道笔记', '请把我的笔记“[经文]”改写为讲道笔记。保持笔记中的经文解释和依据不变，把它们放进讲道的结构：经文、一句话的中心信息、要点（出自经文脉络）、基督与福音、应用方向。不要编造笔记中没有的主张或例证；如有可补充的，请另列为“可补充的”。'),
        'ZHT': ('改寫為講道筆記', '請把我的筆記「[經文]」改寫為講道筆記。保持筆記中的經文解釋和依據不變，把它們放進講道的結構：經文、一句話的中心信息、要點（出自經文脈絡）、基督與福音、應用方向。不要編造筆記中沒有的主張或例證；如有可補充的，請另列為「可補充的」。'),
        'DE': ('Als Predigtnotiz neu schreiben', 'Schreibe meine Notiz „[Vers]“ als Predigtnotiz neu. Behalte Auslegung und Belege der Notiz bei und bringe sie in die Form einer Predigt: Text, zentrale Botschaft in einem Satz, Gliederung (aus dem Verlauf des Textes), Christus und das Evangelium, Richtung der Anwendung. Erfinde keine Behauptungen oder Beispiele, die nicht in der Notiz stehen; Ergänzbares führe getrennt unter „Könnte ergänzt werden“ auf.'),
        'FR': ('Réécrire en note de sermon', 'Réécris ma note « [verset] » en note de sermon. Garde telles quelles l’interprétation et les preuves de la note et mets-les en forme de sermon : le texte, le message central en une phrase, les points (issus du déroulement du texte), le Christ et l’Évangile, la direction de l’application. N’invente ni affirmations ni illustrations absentes de la note ; ce qui pourrait être ajouté, liste-le à part sous « À ajouter éventuellement ».'),
        'ES': ('Reescribir como nota de sermón', 'Reescribe mi nota «[versículo]» como nota de sermón. Mantén la interpretación y las pruebas de la nota tal como están y ponlas en forma de sermón: el texto, el mensaje central en una frase, los puntos (que salen del desarrollo del texto), Cristo y el evangelio, la dirección de la aplicación. No inventes afirmaciones ni ilustraciones que no estén en la nota; si algo podría añadirse, ponlo aparte bajo «Podría añadirse».'),
        'PT': ('Reescrever como nota de sermão', 'Reescreva minha nota “[versículo]” como nota de sermão. Mantenha a interpretação e as evidências da nota como estão e coloque-as na forma de um sermão: o texto, a mensagem central em uma frase, os pontos (vindos do desenvolvimento do texto), Cristo e o evangelho, a direção da aplicação. Não invente afirmações ou ilustrações que não estejam na nota; o que puder ser acrescentado, liste à parte em “Poderia ser acrescentado”.'),
        'RU': ('Переписать как заметку к проповеди', 'Перепиши мою заметку «[стих]» как заметку к проповеди. Сохрани толкование и доводы заметки как есть и придай им форму проповеди: текст, главная мысль одним предложением, пункты (из хода текста), Христос и Евангелие, направление применения. Не придумывай утверждений и примеров, которых нет в заметке; что можно добавить, перечисли отдельно в разделе «Можно добавить».'),
        'AR': ('إعادة الكتابة كملاحظة عظة', 'أعد كتابة ملاحظتي «[الآية]» كملاحظة عظة. احتفظ بتفسير الملاحظة وأدلتها كما هي وضعها في شكل عظة: النص، والرسالة المركزية في جملة واحدة، والنقاط (النابعة من تسلسل النص)، والمسيح والإنجيل، واتجاه التطبيق. لا تختلق ادعاءات أو أمثلة ليست في الملاحظة؛ وما يمكن إضافته اذكره منفصلًا تحت «يمكن إضافته».'),
    },
    'T_BOOKMEDI': {
        'KO': ('도서 묵상', '방금 다 읽은 「[도서]」으로 내가 묵상하도록 도와 주세요. 내 묵상을 대신하지 말고 내가 스스로 생각하고 답하도록 이끌어 주세요. '
               '먼저 ① 이 글의 핵심 메시지를 한 문장으로 ② 핵심 구절의 앞뒤 문맥과 뜻을 짧게 ③ 나 자신을 돌아볼 질문 두 개를 주고, 내 답을 기다려 주세요. '
               '내가 답하면 그 답을 바탕으로 질문을 하나씩 더 해 주세요. 저자의 설명과 성경 본문 자체의 뜻을 구분하고, 본문에 없는 뜻을 끌어내지 말고, '
               '견해가 갈리는 곳은 한 견해를 정답처럼 말하지 마세요. 한 번에 너무 많이 말하지 마세요. '
               '답할 때마다 맨 끝에, 내가 이어서 물을 만한 질문 두세 개를 한 줄에 하나씩 「▷ 」로 시작해 적어 주세요.'),
        'EN': ('Book meditation', 'Help me meditate on "[book]", which I have just finished reading. Do not meditate for me; lead me to think and answer for myself. '
               'First give (1) the core message in one sentence, (2) the context and meaning of the key verse in brief, (3) two questions to look at myself, then wait for my answer. '
               'When I answer, ask one more question at a time based on it. Keep the author\'s explanation apart from what the Bible text itself says, do not draw out meanings that are not in the text, '
               'and where views differ do not present one view as the only answer. Do not say too much at once. '
               'At the end of every reply, write two or three questions I could ask next, one per line, each starting with "▷ ".'),
        'JA': ('書籍の黙想', '読み終えたばかりの「[書籍]」で私が黙想できるよう助けてください。私の代わりに黙想せず、私が自分で考えて答えるよう導いてください。'
               'まず①この文章の中心メッセージを一文で ②中心聖句の前後の文脈と意味を短く ③自分を振り返る問いを二つ示し、私の答えを待ってください。'
               '私が答えたら、それをもとに問いを一つずつ加えてください。著者の説明と聖書本文そのものの意味を区別し、本文にない意味を引き出さず、見解が分かれるところでは一つの見解を唯一の正解のように言わないでください。一度に多くを語らないでください。'
               '答えるたびに最後に、次に尋ねられる問いを二つか三つ、一行に一つずつ「▷ 」で始めて書いてください。'),
        'ZH': ('书籍默想', '请帮助我用刚读完的“[书籍]”来默想。不要替我默想，而要引导我自己思考、自己回答。'
               '先给出 ① 这篇文字的核心信息（一句话）② 核心经文的上下文与含义（简短）③ 两个让我省察自己的问题，然后等我回答。'
               '我回答后，请据此一次再问一个问题。请区分作者的解释与经文本身的意思，不要引申经文中没有的意思，在看法分歧之处不要把一种看法说成唯一答案。不要一次说太多。'
               '每次回答的最后，请写两三个我接下来可以问的问题，每行一个，以“▷ ”开头。'),
        'ZHT': ('書籍默想', '請幫助我用剛讀完的「[書籍]」來默想。不要替我默想，而要引導我自己思考、自己回答。'
                '先給出 ① 這篇文字的核心信息（一句話）② 核心經文的上下文與含義（簡短）③ 兩個讓我省察自己的問題，然後等我回答。'
                '我回答後，請據此一次再問一個問題。請區分作者的解釋與經文本身的意思，不要引申經文中沒有的意思，在看法分歧之處不要把一種看法說成唯一答案。不要一次說太多。'
                '每次回答的最後，請寫兩三個我接下來可以問的問題，每行一個，以「▷ 」開頭。'),
        'DE': ('Buchmeditation', 'Hilf mir, über „[Buch]“, das ich gerade zu Ende gelesen habe, zu meditieren. Meditiere nicht für mich, sondern führe mich, selbst zu denken und zu antworten. '
               'Gib zuerst (1) die Kernbotschaft in einem Satz, (2) kurz Zusammenhang und Bedeutung des Schlüsselverses, (3) zwei Fragen zur Selbstprüfung, und warte dann auf meine Antwort. '
               'Wenn ich antworte, stelle darauf aufbauend jeweils eine weitere Frage. Unterscheide die Erklärung des Autors von dem, was der Bibeltext selbst sagt, lies nichts in den Text hinein, '
               'und stelle bei unterschiedlichen Auffassungen keine als die einzige Antwort dar. Sag nicht zu viel auf einmal. '
               'Schreibe am Ende jeder Antwort zwei oder drei Fragen, die ich als Nächstes stellen könnte, je eine pro Zeile, beginnend mit „▷ “.'),
        'FR': ('Méditation du livre', 'Aide-moi à méditer « [livre] », que je viens de finir de lire. Ne médite pas à ma place ; amène-moi à réfléchir et à répondre moi-même. '
               'Donne d’abord (1) le message central en une phrase, (2) brièvement le contexte et le sens du verset clé, (3) deux questions pour m’examiner, puis attends ma réponse. '
               'Quand je réponds, pose une question de plus à la fois à partir de ma réponse. Distingue l’explication de l’auteur de ce que dit le texte biblique lui-même, ne tire pas du texte ce qui n’y est pas, '
               'et là où les avis divergent, ne présente pas un avis comme la seule réponse. N’en dis pas trop à la fois. '
               'À la fin de chaque réponse, écris deux ou trois questions que je pourrais poser ensuite, une par ligne, commençant par « ▷ ».'),
        'ES': ('Meditación del libro', 'Ayúdame a meditar en «[libro]», que acabo de terminar de leer. No medites por mí; guíame a pensar y responder por mí mismo. '
               'Primero da (1) el mensaje central en una frase, (2) brevemente el contexto y el sentido del versículo clave, (3) dos preguntas para examinarme, y espera mi respuesta. '
               'Cuando responda, haz una pregunta más cada vez a partir de mi respuesta. Distingue la explicación del autor de lo que dice el texto bíblico mismo, no saques del texto lo que no está, '
               'y donde las opiniones difieren no presentes una como la única respuesta. No digas demasiado de una vez. '
               'Al final de cada respuesta, escribe dos o tres preguntas que podría hacer después, una por línea, empezando con «▷ ».'),
        'PT': ('Meditação do livro', 'Ajude-me a meditar em “[livro]”, que acabei de ler. Não medite por mim; leve-me a pensar e responder por mim mesmo. '
               'Primeiro dê (1) a mensagem central numa frase, (2) brevemente o contexto e o sentido do versículo-chave, (3) duas perguntas para eu me examinar, e espere minha resposta. '
               'Quando eu responder, faça mais uma pergunta de cada vez a partir dela. Distinga a explicação do autor do que o próprio texto bíblico diz, não tire do texto o que nele não está, '
               'e onde as opiniões divergem não apresente uma como a única resposta. Não diga demais de uma vez. '
               'No fim de cada resposta, escreva duas ou três perguntas que eu poderia fazer em seguida, uma por linha, começando com “▷ ”.'),
        'RU': ('Размышление над книгой', 'Помоги мне размышлять над «[книга]», которую я только что дочитал. Не размышляй за меня; веди меня к тому, чтобы я сам думал и отвечал. '
               'Сначала дай (1) главную мысль одним предложением, (2) кратко контекст и смысл ключевого стиха, (3) два вопроса для самоисследования — и жди моего ответа. '
               'Когда я отвечу, задавай на его основе по одному вопросу. Отличай объяснение автора от того, что говорит сам библейский текст, не вычитывай из текста того, чего в нём нет, '
               'и там, где мнения расходятся, не выдавай одно мнение за единственный ответ. Не говори слишком много сразу. '
               'В конце каждого ответа напиши два-три вопроса, которые я мог бы задать дальше, по одному в строке, начиная с «▷ ».'),
        'AR': ('تأمل الكتاب', 'ساعدني على التأمل في «[الكتاب]» الذي أنهيت قراءته للتو. لا تتأمل بدلًا مني، بل قُدني لأفكر وأجيب بنفسي. '
               'أعطِ أولًا (1) الرسالة الأساسية في جملة واحدة، (2) باختصار سياق الآية الرئيسة ومعناها، (3) سؤالين لأفحص نفسي، ثم انتظر جوابي. '
               'عندما أجيب، اطرح سؤالًا آخر واحدًا في كل مرة بناءً على جوابي. ميّز بين شرح الكاتب وما يقوله النص الكتابي نفسه، ولا تستخرج من النص ما ليس فيه، '
               'وحيث تختلف الآراء لا تقدّم رأيًا واحدًا على أنه الجواب الوحيد. لا تقل الكثير دفعة واحدة. '
               'في نهاية كل جواب اكتب سؤالين أو ثلاثة يمكنني أن أسألها بعد ذلك، كل سؤال في سطر، يبدأ بـ «▷ ».'),
    },
    'T_REFAN': {
        'KO': ('내 연구노트 분석', '내 연구노트 [구절]을 분석해 주세요. 본문 근거가 약한 곳, 논리가 건너뛴 곳, 더 보탤 만한 구절을 짚어 주세요. 글을 대신 다시 쓰지는 마세요.'),
        'EN': ('Analyze my study', 'Analyze my study "[verse]". Point out where the biblical support is weak, where the reasoning jumps, and which passages could be added. Do not rewrite it for me.'),
        'JA': ('研究資料の分析', '私の研究資料「[聖句]」を分析してください。本文の根拠が弱いところ、論理が飛んでいるところ、加えるとよい箇所を示してください。代わりに書き直さないでください。'),
        'ZH': ('研究资料分析', '请分析我的研究资料“[经文]”。指出经文依据薄弱之处、推理跳跃之处，以及可以补充的经文。不要替我重写。'),
        'ZHT': ('研究資料分析', '請分析我的研究資料「[經文]」。指出經文依據薄弱之處、推理跳躍之處，以及可以補充的經文。不要替我重寫。'),
        'DE': ('Studie auswerten', 'Werte meine Studie „[Vers]“ aus. Zeige, wo die biblische Begründung schwach ist, wo die Argumentation springt und welche Stellen ergänzt werden könnten. Schreibe sie nicht für mich um.'),
        'FR': ('Analyser mon étude', 'Analyse mon étude « [verset] ». Montre où l’appui biblique est faible, où le raisonnement saute une étape et quels passages pourraient être ajoutés. Ne la réécris pas à ma place.'),
        'ES': ('Analizar mi estudio', 'Analiza mi estudio «[versículo]». Señala dónde el apoyo bíblico es débil, dónde el razonamiento salta y qué pasajes podrían añadirse. No lo reescribas por mí.'),
        'PT': ('Analisar meu estudo', 'Analise meu estudo “[versículo]”. Mostre onde o apoio bíblico é fraco, onde o raciocínio salta e que passagens poderiam ser acrescentadas. Não o reescreva por mim.'),
        'RU': ('Разбор моего исследования', 'Разбери моё исследование «[стих]». Покажи, где библейское основание слабое, где рассуждение перескакивает и какие места можно добавить. Не переписывай его за меня.'),
        'AR': ('تحليل دراستي', 'حلّل دراستي «[الآية]». بيّن أين يضعف السند الكتابي، وأين يقفز الاستدلال، وأي المقاطع يمكن إضافتها. لا تعد كتابتها بدلًا مني.'),
    },
}
_DESC_V_LEAD = {
    'KO': ('설명문 작성', '[구절]의 설명문을 써 주세요. 본문이 무슨 일을 말하는지 장면과 사람을 중심으로 쉬운 말로 풀어 주세요. 아래 칸 이름을 대괄호째 그대로 한 줄에 적고 그 아래에 글을 쓰세요: %s. 더 파고들 물음이 있을 때만 %s 도 쓰세요.'),
    'EN': ('Write a verse description', 'Write a description of [verse]. Explain in plain words what the text is saying, centred on the scene and the people. Write each heading below on its own line, brackets included, and the text under it: %s. Add %s only if there is a question worth digging into.'),
    'JA': ('説明文を書く', '[聖句]の説明文を書いてください。本文が何を語っているかを、場面と人物を中心にやさしい言葉で説明してください。次の見出しを括弧ごと一行に書き、その下に本文を書いてください：%s。掘り下げる問いがあるときだけ %s も書いてください。'),
    'ZH': ('撰写经文说明', '请为[经文]写说明。以场景和人物为中心，用浅白的话讲清经文在说什么。请把下面的标题连同方括号单独写一行，在下面写内容：%s。只有在有值得深究的问题时才写 %s。'),
    'ZHT': ('撰寫經文說明', '請為[經文]寫說明。以場景和人物為中心，用淺白的話講清經文在說什麼。請把下面的標題連同方括號單獨寫一行，在下面寫內容：%s。只有在有值得深究的問題時才寫 %s。'),
    'DE': ('Verserklärung schreiben', 'Schreibe eine Erklärung zu [Vers]. Erkläre in einfachen Worten, was der Text sagt, ausgehend von Szene und Personen. Schreibe jede Überschrift unten samt Klammern in eine eigene Zeile und den Text darunter: %s. Füge %s nur hinzu, wenn es eine Frage gibt, die sich zu vertiefen lohnt.'),
    'FR': ('Rédiger une explication', 'Rédige une explication de [verset]. Dis simplement ce que dit le texte, en partant de la scène et des personnes. Écris chaque titre ci-dessous sur sa propre ligne, crochets compris, et le texte en dessous : %s. Ajoute %s seulement s’il y a une question qui mérite d’être creusée.'),
    'ES': ('Escribir una explicación', 'Escribe una explicación de [versículo]. Explica con palabras sencillas lo que dice el texto, centrándote en la escena y las personas. Escribe cada título de abajo en su propia línea, con los corchetes, y el texto debajo: %s. Añade %s solo si hay una pregunta que merezca profundizarse.'),
    'PT': ('Escrever uma explicação', 'Escreva uma explicação de [versículo]. Explique com palavras simples o que o texto diz, centrando-se na cena e nas pessoas. Escreva cada título abaixo em sua própria linha, com os colchetes, e o texto embaixo: %s. Acrescente %s só se houver uma pergunta que valha a pena aprofundar.'),
    'RU': ('Написать пояснение к стиху', 'Напиши пояснение к [стих]. Простыми словами объясни, о чём говорит текст, опираясь на сцену и людей. Запиши каждый заголовок ниже на отдельной строке вместе со скобками, а под ним текст: %s. Добавь %s, только если есть вопрос, который стоит исследовать глубже.'),
    'AR': ('كتابة شرح للآية', 'اكتب شرحًا لـ [الآية]. اشرح بكلمات بسيطة ما يقوله النص مركّزًا على المشهد والأشخاص. اكتب كل عنوان أدناه في سطر مستقل مع الأقواس، والنص تحته: %s. أضف %s فقط إذا كان هناك سؤال يستحق التعمق.'),
}
#: 옛 씨앗(연구질문까지 쓰게 하던 것) — 사람이 안 고친 줄을 새 씨앗으로 옮길 때 견준다(`_migrate_desc_split`).
OLD_DESC_V = {lg: (t, b % _desc_tpl(lg)) for lg, (t, b) in _DESC_V_LEAD.items()}


def _lay_body(b):
    """옛 일반 씨앗 본문에서 「연구질문도 쓰세요」 문장을 걷는다 — 첫 %s 다음 문장 끝까지만 남긴다."""
    a, rest = b.split('%s', 1)
    cut = min([i for i in (rest.find('.'), rest.find('。')) if i >= 0] or [len(rest) - 1])
    return a + '%s' + rest[:cut + 1]


_DESC_V_TITLE = {'KO': '일반설명문 작성', 'EN': 'Write a basic verse explanation', 'JA': '一般説明文を書く',
                 'ZH': '撰写一般说明', 'ZHT': '撰寫一般說明', 'DE': 'Einfache Verserklärung schreiben',
                 'FR': 'Rédiger une explication simple', 'ES': 'Escribir una explicación sencilla',
                 'PT': 'Escrever uma explicação simples', 'RU': 'Написать простое пояснение',
                 'AR': 'كتابة شرح مبسّط للآية'}
SEED_TASK['T_DESC_V'] = {
    lg: (_DESC_V_TITLE.get(lg, t),
         _lay_body(b) % (' '.join('[%s]' % x for x in (DESC_MARKS.get(lg) or DESC_MARKS['EN'])[:3]),))
    for lg, (t, b) in _DESC_V_LEAD.items()}

#: ★ 2026-10-14 전문설명문 — 칸 = [전문 설명] + (있을 때만) [연구질문] · 저장 = VERS_DESC·VERS_QUESTION **EXPERT**.
_XDESC_V_LEAD = {
    'KO': ('전문설명문 작성', '[구절]의 전문 설명문을 써 주세요. 원어의 핵심 낱말, 문맥과 역사적 배경, 다른 구절과의 연결, 해석이 갈리는 자리를 근거와 함께 차분히 풀어 주세요. 원어는 한글 뜻 뒤 괄호에 핵심 낱말 하나만 적으세요. 아래 칸 이름을 대괄호째 그대로 한 줄에 적고 그 아래에 글을 쓰세요: %s. 더 파고들 물음이 있으면 %s 도 쓰세요.'),
    'EN': ('Write an in-depth verse explanation', 'Write an in-depth explanation of [verse]. Set out the key words of the original language, the context and historical background, links to other passages, and the points where interpretations differ, with evidence. Give an original-language word only in brackets after its English meaning, one key word at a time. Write each heading below on its own line, brackets included, and the text under it: %s. Add %s if there is a question worth digging into.'),
    'JA': ('専門説明文を書く', '[聖句]の専門的な説明文を書いてください。原語の鍵となる語、文脈と歴史的背景、他の箇所とのつながり、解釈が分かれる点を、根拠とともに丁寧に説明してください。原語は意味の後の括弧に鍵語を一つだけ書いてください。次の見出しを括弧ごと一行に書き、その下に本文を書いてください：%s。掘り下げる問いがあれば %s も書いてください。'),
    'ZH': ('撰写深入说明', '请为[经文]写深入说明。请结合依据，从容讲清原文关键词、上下文与历史背景、与其他经文的关联，以及解释分歧之处。原文只在中文意思后的括号里写一个关键词。请把下面的标题连同方括号单独写一行，在下面写内容：%s。若有值得深究的问题，也写 %s。'),
    'ZHT': ('撰寫深入說明', '請為[經文]寫深入說明。請結合依據，從容講清原文關鍵詞、上下文與歷史背景、與其他經文的關聯，以及解釋分歧之處。原文只在中文意思後的括號裡寫一個關鍵詞。請把下面的標題連同方括號單獨寫一行，在下面寫內容：%s。若有值得深究的問題，也寫 %s。'),
    'DE': ('Vertiefte Verserklärung schreiben', 'Schreibe eine vertiefte Erklärung zu [Vers]. Lege die Schlüsselwörter der Ursprache, Kontext und historischen Hintergrund, Verbindungen zu anderen Stellen und die Punkte, an denen Auslegungen auseinandergehen, mit Belegen dar. Nenne ein Wort der Ursprache nur in Klammern nach seiner deutschen Bedeutung, jeweils nur ein Schlüsselwort. Schreibe jede Überschrift unten samt Klammern in eine eigene Zeile und den Text darunter: %s. Füge %s hinzu, wenn es eine Frage gibt, die sich zu vertiefen lohnt.'),
    'FR': ('Rédiger une explication approfondie', 'Rédige une explication approfondie de [verset]. Expose, preuves à l’appui, les mots clés de la langue originale, le contexte et l’arrière-plan historique, les liens avec d’autres passages et les points où les interprétations divergent. Donne un mot de la langue originale seulement entre parenthèses après son sens en français, un mot clé à la fois. Écris chaque titre ci-dessous sur sa propre ligne, crochets compris, et le texte en dessous : %s. Ajoute %s s’il y a une question qui mérite d’être creusée.'),
    'ES': ('Escribir una explicación detallada', 'Escribe una explicación detallada de [versículo]. Expón con fundamento las palabras clave del idioma original, el contexto y el trasfondo histórico, los vínculos con otros pasajes y los puntos donde las interpretaciones difieren. Pon una palabra del idioma original solo entre paréntesis después de su significado en español, una palabra clave cada vez. Escribe cada título de abajo en su propia línea, con los corchetes, y el texto debajo: %s. Añade %s si hay una pregunta que merezca profundizarse.'),
    'PT': ('Escrever uma explicação aprofundada', 'Escreva uma explicação aprofundada de [versículo]. Exponha com fundamento as palavras-chave da língua original, o contexto e o pano de fundo histórico, as ligações com outras passagens e os pontos em que as interpretações divergem. Ponha uma palavra da língua original só entre parênteses depois do seu sentido em português, uma palavra-chave de cada vez. Escreva cada título abaixo em sua própria linha, com os colchetes, e o texto embaixo: %s. Acrescente %s se houver uma pergunta que valha a pena aprofundar.'),
    'RU': ('Написать углублённое пояснение', 'Напиши углублённое пояснение к [стих]. С опорой на доводы изложи ключевые слова языка оригинала, контекст и исторический фон, связи с другими местами Писания и места, где толкования расходятся. Слово языка оригинала давай только в скобках после его русского значения, по одному ключевому слову. Запиши каждый заголовок ниже на отдельной строке вместе со скобками, а под ним текст: %s. Добавь %s, если есть вопрос, который стоит исследовать глубже.'),
    'AR': ('كتابة شرح معمّق للآية', 'اكتب شرحًا معمّقًا لـ [الآية]. اعرض مع الأدلة الكلمات المفتاحية في اللغة الأصلية، والسياق والخلفية التاريخية، والصلات بنصوص أخرى، والمواضع التي تختلف فيها التفاسير. اذكر كلمة اللغة الأصلية بين قوسين بعد معناها العربي فقط، كلمة مفتاحية واحدة في كل مرة. اكتب كل عنوان أدناه في سطر مستقل مع الأقواس، والنص تحته: %s. أضف %s إذا كان هناك سؤال يستحق التعمق.'),
}
SEED_TASK['T_XDESC_V'] = {
    lg: (t, b % tuple('[%s]' % (DESC_MARKS.get(lg) or DESC_MARKS['EN'])[i] for i in (4, 3)))
    for lg, (t, b) in _XDESC_V_LEAD.items()}

_LINKAN_LEAD = {
    'KO': ('연결 살펴보기', '[구절]과 연결된 구절이 왜 이어지는지 살펴 주세요. 두 본문의 낱말과 사건과 주제가 어떻게 맞닿는지, 재료에 적힌 연결 갈래가 무엇을 뜻하는지 근거와 함께 풀어 주세요. 근거가 약하면 그렇다고 말해 주세요. 마지막에 %s 를 대괄호째 한 줄에 적고 그 아래에 두 본문을 잇는 연결설명문을 두세 문장으로 쓰세요.'),
    'EN': ('Examine this connection', 'Examine why [passage] is connected to the linked verse. Explain, with evidence, how the words, events and themes of the two texts meet and what the connection type in the materials means. If the evidence is weak, say so. At the end, write %s on its own line, brackets included, and under it a two- or three-sentence note connecting the two texts.'),
    'JA': ('つながりを調べる', '[聖句]と関連づけられた聖句がなぜつながるのかを調べてください。二つの本文の言葉・出来事・主題がどう触れ合うか、資料にある関連の種類が何を意味するかを根拠とともに説明してください。根拠が弱ければそう言ってください。最後に %s を括弧ごと一行に書き、その下に二つの本文をつなぐ説明を二、三文で書いてください。'),
    'ZH': ('查看关联', '请查看[经文]与关联经文为何相连。请结合依据说明两段经文的词语、事件与主题如何相合，以及资料中的关联类型是什么意思。若依据薄弱，请直说。最后把 %s 连同方括号单独写一行，在下面用两三句话写出连接两段经文的说明。'),
    'ZHT': ('查看關聯', '請查看[經文]與關聯經文為何相連。請結合依據說明兩段經文的詞語、事件與主題如何相合，以及資料中的關聯類型是什麼意思。若依據薄弱，請直說。最後把 %s 連同方括號單獨寫一行，在下面用兩三句話寫出連接兩段經文的說明。'),
    'DE': ('Verbindung untersuchen', 'Untersuche, warum [Vers] mit dem verknüpften Vers verbunden ist. Erkläre mit Belegen, wie Wörter, Ereignisse und Themen der beiden Texte zusammenkommen und was die Verbindungsart in den Unterlagen bedeutet. Wenn die Belege schwach sind, sag es. Schreibe am Ende %s samt Klammern in eine eigene Zeile und darunter eine Erklärung von zwei oder drei Sätzen, die die beiden Texte verbindet.'),
    'FR': ('Examiner ce lien', 'Examine pourquoi [verset] est relié au verset lié. Explique, preuves à l’appui, comment les mots, les événements et les thèmes des deux textes se rejoignent et ce que signifie le type de lien indiqué dans les éléments. Si les preuves sont faibles, dis-le. À la fin, écris %s sur sa propre ligne, crochets compris, et en dessous une note de deux ou trois phrases reliant les deux textes.'),
    'ES': ('Examinar la conexión', 'Examina por qué [versículo] está conectado con el versículo vinculado. Explica con fundamento cómo se encuentran las palabras, los hechos y los temas de los dos textos y qué significa el tipo de conexión de los materiales. Si el fundamento es débil, dilo. Al final, escribe %s en su propia línea, con los corchetes, y debajo una nota de dos o tres frases que una los dos textos.'),
    'PT': ('Examinar a ligação', 'Examine por que [versículo] está ligado ao versículo relacionado. Explique com fundamento como as palavras, os fatos e os temas dos dois textos se encontram e o que significa o tipo de ligação dos materiais. Se o fundamento for fraco, diga isso. No fim, escreva %s em sua própria linha, com os colchetes, e embaixo uma nota de duas ou três frases que ligue os dois textos.'),
    'RU': ('Рассмотреть связь', 'Рассмотри, почему [стих] связан со связанным стихом. С опорой на доводы объясни, как сходятся слова, события и темы двух текстов и что означает тип связи в материалах. Если доводы слабые, так и скажи. В конце запиши %s на отдельной строке вместе со скобками, а под ним пояснение из двух-трёх предложений, связывающее два текста.'),
    'AR': ('فحص الصلة', 'افحص لماذا ترتبط [الآية] بالآية المرتبطة بها. اشرح مع الأدلة كيف تلتقي كلمات النصين وأحداثهما وموضوعاتهما، وما معنى نوع الصلة المذكور في المواد. إن كانت الأدلة ضعيفة فقل ذلك. في النهاية اكتب %s في سطر مستقل مع الأقواس، وتحته شرحًا من جملتين أو ثلاث يربط النصين.'),
}
SEED_TASK['T_LINKAN'] = {lg: (t, b % ('[%s]' % LINK_MARKS[lg])) for lg, (t, b) in _LINKAN_LEAD.items()}
# ★ 2026-10-23 인물 살펴보기 — 자리표는 용어 업무(T_TERMAN)와 같은 낱말을 쓴다(언어마다 [용어]·[term]…)
_TERM_PH = {lg: (re.search(r'\[[^\]]+\]', b) or re.search(r'\[[^\]]+\]', '[term]')).group(0) for lg, (t, b) in SEED_TASK['T_TERMAN'].items()}
_FIG = {
    'KO': ('인물 살펴보기', '%s 이 사람의 삶을 성경 본문을 따라 함께 살펴 주세요. 성경이 적은 사실과 추론을 구분하고, 영웅이나 악인으로 단정하지 말고, 구절을 들어 짧은 문단으로 답해 주세요.'),
    'EN': ('Explore this person', 'Walk through the life of %s following the biblical text. Separate what Scripture records from inference, do not reduce the person to a hero or a villain, cite passages, and answer in short paragraphs.'),
    'JA': ('人物を見る', '%s の生涯を聖書本文に沿って一緒に見てください。聖書が記した事実と推論を区別し、英雄か悪人かと断定せず、聖句を挙げて短い段落で答えてください。'),
    'ZH': ('认识这个人物', '请沿着圣经经文一起看%s的一生。区分圣经记载的事实与推论，不要把人简单定为英雄或恶人，引用经文，用短段落回答。'),
    'ZHT': ('認識這個人物', '請沿著聖經經文一起看%s的一生。區分聖經記載的事實與推論，不要把人簡單定為英雄或惡人，引用經文，用短段落回答。'),
    'DE': ('Diese Person betrachten', 'Gehe das Leben von %s entlang des Bibeltextes durch. Trenne, was die Schrift berichtet, von Schlussfolgerungen, mache die Person nicht zum Helden oder Schurken, nenne Stellen und antworte in kurzen Absätzen.'),
    'FR': ('Découvrir ce personnage', 'Parcours la vie de %s en suivant le texte biblique. Distingue ce que l’Écriture rapporte des déductions, ne réduis pas la personne à un héros ou à un méchant, cite des passages et réponds en courts paragraphes.'),
    'ES': ('Conocer a este personaje', 'Recorre la vida de %s siguiendo el texto bíblico. Distingue lo que la Escritura registra de las deducciones, no reduzcas a la persona a héroe o villano, cita pasajes y responde en párrafos breves.'),
    'PT': ('Conhecer esta pessoa', 'Percorra a vida de %s seguindo o texto bíblico. Separe o que a Escritura registra das deduções, não reduza a pessoa a herói ou vilão, cite passagens e responda em parágrafos curtos.'),
    'RU': ('Узнать этого человека', 'Пройдите по жизни %s, следуя библейскому тексту. Отделяйте то, что записано в Писании, от выводов, не делайте из человека героя или злодея, приводите отрывки и отвечайте короткими абзацами.'),
    'AR': ('التعرّف على هذه الشخصية', 'تتبّع حياة %s وفق نص الكتاب المقدس. ميّز بين ما يسجّله الكتاب وبين الاستنتاج، ولا تختزل الشخص في بطل أو شرير، واستشهد بالمقاطع وأجب بفقرات قصيرة.'),
}
SEED_TASK['T_FIGURE'] = {lg: (t, b % _TERM_PH.get(lg, '[term]')) for lg, (t, b) in _FIG.items()}
# ★ 2026-10-23 docs/2.txt 2 — 장소 조사(발자취 장소 카드 [AI] · 자리표는 용어 업무와 같다)
_PLACEAN = {
    'KO': ('장소 조사', '%s 이 장소와 그 근처에서 어떤 일들이 있었는지 조사해 주세요. 성경이 적은 사건을 먼저 차례대로 들고, 그다음 성경 밖의 역사와 발굴을 덧붙여 주세요. 확인된 것과 추정을 구분하고, 짧은 문단으로 답해 주세요.'),
    'EN': ('Research this place', 'Research what happened at and around %s. First list the events Scripture records, in order, then add history and excavations outside the Bible. Separate what is established from what is conjectured, and answer in short paragraphs.'),
    'JA': ('場所を調べる', '%s とその周辺でどのような出来事があったかを調べてください。まず聖書が記す出来事を順に挙げ、その後に聖書以外の歴史や発掘を加えてください。確かなことと推定を区別し、短い段落で答えてください。'),
    'ZH': ('调查这个地方', '请调查%s及其附近发生过哪些事。先按次序列出圣经记载的事件，再补充圣经以外的历史与考古发掘。区分已确认的与推测的，用短段落回答。'),
    'ZHT': ('調查這個地方', '請調查%s及其附近發生過哪些事。先按次序列出聖經記載的事件，再補充聖經以外的歷史與考古發掘。區分已確認的與推測的，用短段落回答。'),
    'DE': ('Diesen Ort erforschen', 'Erforsche, was an und um %s geschehen ist. Nenne zuerst der Reihe nach die Ereignisse, die die Schrift berichtet, und ergänze dann Geschichte und Ausgrabungen außerhalb der Bibel. Trenne Gesichertes von Vermutetem und antworte in kurzen Absätzen.'),
    'FR': ('Explorer ce lieu', 'Recherche ce qui s’est passé à %s et dans ses environs. Cite d’abord, dans l’ordre, les événements rapportés par l’Écriture, puis ajoute l’histoire et les fouilles hors de la Bible. Distingue ce qui est établi de ce qui est supposé et réponds en courts paragraphes.'),
    'ES': ('Investigar este lugar', 'Investiga qué ocurrió en %s y sus alrededores. Primero enumera en orden los hechos que registra la Escritura y luego añade la historia y las excavaciones fuera de la Biblia. Distingue lo comprobado de lo supuesto y responde en párrafos breves.'),
    'PT': ('Pesquisar este lugar', 'Pesquise o que aconteceu em %s e arredores. Primeiro liste, em ordem, os fatos que a Escritura registra e depois acrescente a história e as escavações fora da Bíblia. Separe o que é comprovado do que é suposição e responda em parágrafos curtos.'),
    'RU': ('Исследовать это место', 'Исследуйте, что происходило в %s и вокруг. Сначала по порядку перечислите события, записанные в Писании, затем добавьте историю и раскопки вне Библии. Отделяйте установленное от предположений и отвечайте короткими абзацами.'),
    'AR': ('البحث في هذا المكان', 'ابحث عمّا جرى في %s وما حوله. اذكر أولًا بالترتيب الأحداث التي يسجّلها الكتاب المقدس، ثم أضف التاريخ والتنقيبات خارج الكتاب. ميّز بين الثابت والمظنون، وأجب بفقرات قصيرة.'),
}
SEED_TASK['T_PLACEAN'] = {lg: (t, b % _TERM_PH.get(lg, '[term]')) for lg, (t, b) in _PLACEAN.items()}
# ★ 2026-10-23 docs/2.txt 1 — 연대 조사(연대표 카드 · 재료 = 그 줄의 시대·연도·사건). 자리표 없음 — 재료가 닻이다.
_ERAAN = {
    'KO': ('연대 조사', '재료에 적힌 연대에 그 자리(성경 무대)에서 무엇이 있었는지, 그리고 같은 때 세계 여기저기에서 무엇이 있었는지 조사해 주세요. 연대 학설이 갈리면 그렇다고 적고, 확인된 것과 추정을 구분해 짧은 문단으로 답해 주세요.'),
    'EN': ('Research this period', 'Research what was happening at the time given in the materials, first in the biblical setting and then elsewhere in the world at the same time. If the dating is disputed, say so, separate what is established from what is conjectured, and answer in short paragraphs.'),
    'JA': ('年代を調べる', '資料にある年代に、その場所(聖書の舞台)で何があったか、また同じ頃に世界の各地で何があったかを調べてください。年代の説が分かれるならそう記し、確かなことと推定を区別して短い段落で答えてください。'),
    'ZH': ('调查这个年代', '请调查资料所载年代里，在那个地方(圣经场景)发生了什么，以及同一时期世界各地发生了什么。若年代说法不一，请注明，区分已确认的与推测的，用短段落回答。'),
    'ZHT': ('調查這個年代', '請調查資料所載年代裡，在那個地方(聖經場景)發生了什麼，以及同一時期世界各地發生了什麼。若年代說法不一，請註明，區分已確認的與推測的，用短段落回答。'),
    'DE': ('Diese Zeit erforschen', 'Erforsche, was zu der in den Unterlagen genannten Zeit am Schauplatz der Bibel geschah und was gleichzeitig anderswo in der Welt geschah. Wenn die Datierung umstritten ist, sag es, trenne Gesichertes von Vermutetem und antworte in kurzen Absätzen.'),
    'FR': ('Explorer cette époque', 'Recherche ce qui se passait à l’époque indiquée dans les éléments, d’abord dans le cadre biblique, puis ailleurs dans le monde au même moment. Si la datation est discutée, dis-le, distingue l’établi du supposé et réponds en courts paragraphes.'),
    'ES': ('Investigar esta época', 'Investiga qué ocurría en la época indicada en los materiales, primero en el escenario bíblico y luego en otras partes del mundo al mismo tiempo. Si la datación está en disputa, dilo, distingue lo comprobado de lo supuesto y responde en párrafos breves.'),
    'PT': ('Pesquisar esta época', 'Pesquise o que acontecia na época indicada nos materiais, primeiro no cenário bíblico e depois em outras partes do mundo ao mesmo tempo. Se a datação for discutida, diga isso, separe o comprovado da suposição e responda em parágrafos curtos.'),
    'RU': ('Исследовать эту эпоху', 'Исследуйте, что происходило во время, указанное в материалах, сначала в библейской обстановке, затем в других частях мира в то же время. Если датировка спорна, так и скажите, отделяйте установленное от предположений и отвечайте короткими абзацами.'),
    'AR': ('البحث في هذه الحقبة', 'ابحث عمّا كان يجري في الزمن المذكور في المواد، أولًا في مسرح الكتاب المقدس ثم في أنحاء العالم الأخرى في الوقت نفسه. إن كان التأريخ موضع خلاف فقل ذلك، وميّز بين الثابت والمظنون، وأجب بفقرات قصيرة.'),
}
_VERSE_PH = {lg: (re.search(r'\[[^\]]+\]', b) or re.search(r'\[[^\]]+\]', '[verse]')).group(0) for lg, (t, b) in SEED_TASK['T_ASK'].items()}
# 자리표 = 그 카드의 사건 이름(폰이 닻 이름으로 채운다)
SEED_TASK['T_ERAAN'] = {lg: (t, '%s — ' % _VERSE_PH.get(lg, '[verse]') + b) for lg, (t, b) in _ERAAN.items()}

# ══════════════════════════════════════════════════════════════════════
#  ★ 2026-10-15 docs/1.txt 77 — 기도 노트(폰)의 AI 도우미
#  사용자 「AI 에게 상대방 정보는 보내지 않는다 · 보내기 전에 보낼 모든 내용을 표시하고 수정할 수 있게 ·
#   프롬프트는 PC 에서도 수정할 수 있어야 하고 모바일과 교환 · 성경구절을 추천해달라는 것은 매우 좋다」.
#  ★ 재료는 **사람이 따로 적는 짧은 상황 요약 · 붙든 말씀 · 기도 상태**뿐 — 카드의 이름·기도 내용은 안 간다(폰이 지킨다).
#  ★ 프롬프트 집 = user_ai_prompt(scope TASK · kind T_PR_*) — PC 「AI 도우미 ▸ 설정 ▸ 기도 프롬프트」와
#    폰 「보낼 글」 화면에서 고친다(폰 → PC 사건 AI_PROMPT · PC → 폰 꾸러미 `prayer`).
# ══════════════════════════════════════════════════════════════════════
PRAYER_TASKS = ['PR_VERSE', 'PR_TODO', 'PR_SELF', 'PR_HEART', 'PR_WAIT', 'PR_THANK']
TASKS_OF['PRAYER'] = list(PRAYER_TASKS)
for _t in PRAYER_TASKS:
    TASK_KIND[_t] = 'T_' + _t
TASK_ALL += ['T_' + _t for _t in PRAYER_TASKS]
#: 재료 칸 이름(폰이 보낼 글 끝에 붙인다) — 그 언어
PRAYER_LABELS = {
    # ★ 2026-10-15 사용자 「기도내용 자체가 보내야 할 핵심 내용이다 · 현재 상황을 따로 적는 것은 중복」 — 첫 칸 = 기도 내용
    'KO': ('기도 내용', '붙든 말씀', '지금 기도 상태'),
    'EN': ('Prayer request', 'Verse I hold on to', 'Where this prayer is now'),
    'JA': ('祈りの内容', '握りしめている御言葉', 'いまの祈りの状態'),
    'ZH': ('祷告内容', '我所持守的经文', '这个祷告现在的状态'),
    'ZHT': ('禱告內容', '我所持守的經文', '這個禱告現在的狀態'),
    'DE': ('Gebetsanliegen', 'Bibelwort, an dem ich mich festhalte', 'Wo dieses Gebet jetzt steht'),
    'FR': ('Sujet de prière', 'Verset auquel je m’accroche', 'Où en est cette prière'),
    'ES': ('Motivo de oración', 'Versículo al que me aferro', 'Dónde está esta oración ahora'),
    'PT': ('Pedido de oração', 'Versículo a que me apego', 'Onde esta oração está agora'),
    'RU': ('Молитвенная просьба', 'Стих, за который я держусь', 'Где сейчас эта молитва'),
    'AR': ('موضوع الصلاة', 'الآية التي أتمسك بها', 'أين وصلت هذه الصلاة'),
}
#: 기도 상태 이름(사용자 2026-10-15 「쉬지말고 기도하라 · 더 좋은 것 주심을 감사 · 응답하신 것을 감사 — 짧게」)
PRAYER_STATES = {
    'KO': ('쉬지 말고 기도', '더 좋은 것 주심 감사', '응답 감사'),
    'EN': ('Keep praying', 'Thanks for something better', 'Thanks for the answer'),
    'JA': ('絶えず祈る', 'より良いものへの感謝', '応答への感謝'),
    'ZH': ('不住地祷告', '感谢赐下更好的', '感谢应允'),
    'ZHT': ('不住地禱告', '感謝賜下更好的', '感謝應允'),
    'DE': ('Weiter beten', 'Dank für Besseres', 'Dank für die Antwort'),
    'FR': ('Prier sans cesse', 'Merci pour mieux', 'Merci pour la réponse'),
    'ES': ('Orar sin cesar', 'Gracias por algo mejor', 'Gracias por la respuesta'),
    'PT': ('Orar sem cessar', 'Grato por algo melhor', 'Grato pela resposta'),
    'RU': ('Молиться непрестанно', 'Спасибо за лучшее', 'Спасибо за ответ'),
    'AR': ('صلِّ بلا انقطاع', 'شكرًا على الأفضل', 'شكرًا على الاستجابة'),
}
SEED_TASK['T_PR_VERSE'] = {
    'KO': ('붙들 말씀 추천', '위 기도 내용에 적힌 구체적인 사정(누가, 무엇 때문에, 무엇을 두려워하거나 바라는지)에 맞는 성경 구절 다섯 개를 추천해 주세요. 「기도하라」는 일반적인 구절보다 이 사정에 직접 닿는 구절을 고르고, 구절마다 기도 내용의 어느 부분에 왜 맞는지 짧게 밝혀 주세요.'),
    'EN': ('Verses to hold on to', 'Suggest five Bible verses that fit the concrete situation written in the prayer request above (who, what is happening, what is feared or hoped for). Choose verses that speak directly to this situation rather than general verses about prayer, and for each say briefly which part of the request it fits and why.'),
    'JA': ('握りしめる御言葉の推薦', 'この祈りをささげるときに握りしめることのできる聖書箇所を五つ推薦してください。箇所ごとに書名の略称と章:節、そしてなぜこの祈りに合うのかを一文で添えてください。無理に結びつけた箇所は入れないでください。'),
    'ZH': ('推荐可持守的经文', '请推荐五处我在这个祷告中可以持守的经文。每处请注明书卷简称和章:节，并用一句话说明它为什么适合这个祷告。不要勉强牵连的经文。'),
    'ZHT': ('推薦可持守的經文', '請推薦五處我在這個禱告中可以持守的經文。每處請註明書卷簡稱和章:節，並用一句話說明它為什麼適合這個禱告。不要勉強牽連的經文。'),
    'DE': ('Bibelworte zum Festhalten', 'Schlage fünf Bibelverse vor, an denen ich mich bei diesem Gebet festhalten kann. Gib zu jedem die Buchabkürzung mit Kapitel:Vers und einen Satz, warum er zu diesem Gebet passt. Keine erzwungenen Verse.'),
    'FR': ('Versets auxquels s’accrocher', 'Propose cinq versets bibliques auxquels je peux m’accrocher en priant cette prière. Pour chacun, donne l’abréviation du livre avec chapitre:verset et une phrase sur la raison pour laquelle il convient à cette prière. Pas de versets forcés.'),
    'ES': ('Versículos a los que aferrarse', 'Sugiere cinco versículos a los que pueda aferrarme mientras hago esta oración. Para cada uno, da la abreviatura del libro con capítulo:versículo y una frase de por qué encaja con esta oración. No fuerces versículos.'),
    'PT': ('Versículos a que me apegar', 'Sugira cinco versículos a que eu possa me apegar enquanto faço esta oração. Para cada um, dê a abreviação do livro com capítulo:versículo e uma frase sobre por que combina com esta oração. Não force versículos.'),
    'RU': ('Стихи, за которые держаться', 'Предложи пять библейских стихов, за которые я могу держаться, молясь об этом. К каждому дай сокращение книги с главой:стихом и одно предложение о том, почему он подходит к этой молитве. Не притягивай стихи.'),
    'AR': ('آيات أتمسك بها', 'اقترح خمس آيات من الكتاب المقدس أستطيع أن أتمسك بها وأنا أصلي هذه الصلاة. اذكر لكل آية اختصار السفر مع الأصحاح:العدد وجملة واحدة عن سبب ملاءمتها لهذه الصلاة. لا تقحم آيات لا تناسب.'),
}
SEED_TASK['T_PR_TODO'] = {
    'KO': ('기도와 함께 내가 할 일', '이 기도와 함께 제가 실제로 할 수 있는 작은 일 두세 가지를 성경에 근거해 제안해 주세요. 상대를 바꾸려 하거나 상대 대신 결정하는 일은 빼 주세요. 끝에 그 일을 붙들 성경 구절 두세 개를 약명 장:절과 함께 추천해 주세요.'),
    'EN': ('What I can do alongside this prayer', 'Suggest two or three small things I can actually do alongside this prayer, grounded in Scripture. Leave out anything that tries to change the other person or decide for them. At the end, recommend two or three verses (book abbreviation and chapter:verse) to hold on to.'),
    'JA': ('祈りとともに私にできること', 'この祈りとともに私が実際にできる小さなことを二つか三つ、聖書に基づいて提案してください。相手を変えようとしたり、相手の代わりに決めたりすることは除いてください。最後に、それを支える聖書箇所を二つか三つ、略称と章:節で推薦してください。'),
    'ZH': ('与祷告同行我能做的事', '请根据圣经，建议两三件我在这个祷告之外实际可以做的小事。请不要包括试图改变对方或替对方做决定的事。最后请推荐两三处可以持守的经文（书卷简称和章:节）。'),
    'ZHT': ('與禱告同行我能做的事', '請根據聖經，建議兩三件我在這個禱告之外實際可以做的小事。請不要包括試圖改變對方或替對方做決定的事。最後請推薦兩三處可以持守的經文（書卷簡稱和章:節）。'),
    'DE': ('Was ich neben dem Gebet tun kann', 'Schlage zwei oder drei kleine Dinge vor, die ich neben diesem Gebet tatsächlich tun kann, biblisch begründet. Lass alles weg, was den anderen ändern oder für ihn entscheiden will. Empfiehl am Ende zwei oder drei Verse (Buchabkürzung und Kapitel:Vers).'),
    'FR': ('Ce que je peux faire en plus de prier', 'Propose deux ou trois petites choses que je peux réellement faire en plus de cette prière, fondées sur l’Écriture. Laisse de côté ce qui cherche à changer l’autre ou à décider à sa place. À la fin, recommande deux ou trois versets (abréviation du livre et chapitre:verset).'),
    'ES': ('Lo que puedo hacer junto con esta oración', 'Sugiere dos o tres cosas pequeñas que pueda hacer de verdad junto con esta oración, basadas en la Escritura. Deja fuera lo que intente cambiar a la otra persona o decidir por ella. Al final, recomienda dos o tres versículos (abreviatura del libro y capítulo:versículo).'),
    'PT': ('O que posso fazer junto com esta oração', 'Sugira duas ou três pequenas coisas que eu possa realmente fazer junto com esta oração, com base na Escritura. Deixe de fora o que tente mudar a outra pessoa ou decidir por ela. No fim, recomende dois ou três versículos (abreviação do livro e capítulo:versículo).'),
    'RU': ('Что я могу делать вместе с молитвой', 'Предложи два-три небольших дела, которые я действительно могу сделать вместе с этой молитвой, опираясь на Писание. Не включай то, что пытается изменить другого человека или решить за него. В конце порекомендуй два-три стиха (сокращение книги и глава:стих).'),
    'AR': ('ما أستطيع فعله مع هذه الصلاة', 'اقترح أمرين أو ثلاثة أمور صغيرة أستطيع فعلها فعلًا مع هذه الصلاة، مستندة إلى الكتاب المقدس. استبعد ما يحاول تغيير الشخص الآخر أو اتخاذ القرار عنه. وفي النهاية أوصِ بآيتين أو ثلاث (اختصار السفر والأصحاح:العدد).'),
}
SEED_TASK['T_PR_SELF'] = {
    'KO': ('기도 속에서 나를 돌아보기', '다른 사람을 위해 기도하면서 제 마음을 돌아보려 합니다. 이 기도에 제 바람이나 판단, 두려움이 섞여 있지 않은지 살펴볼 질문 세 가지를 주세요. 답은 정해 주지 말고 질문만 주세요. 끝에 마음을 비추어 볼 성경 구절 두세 개를 추천해 주세요.'),
    'EN': ('Looking at myself in this prayer', 'While praying for someone else, I want to look at my own heart. Give me three questions to check whether my own wishes, judgments or fears are mixed into this prayer. Do not answer them for me; only ask. At the end, recommend two or three verses to reflect on.'),
    'JA': ('祈りの中で自分を振り返る', '人のために祈りながら、自分の心を振り返りたいと思います。この祈りに私自身の願いや判断、恐れが混じっていないかを確かめる問いを三つください。答えは決めず、問いだけをください。最後に心を照らす聖書箇所を二つか三つ推薦してください。'),
    'ZH': ('在祷告中省察自己', '我在为别人祷告时，想省察自己的心。请给我三个问题，帮助我察看这个祷告里是否掺杂了我自己的愿望、判断或惧怕。请不要替我回答，只提问题。最后请推荐两三处可以对照省察的经文。'),
    'ZHT': ('在禱告中省察自己', '我在為別人禱告時，想省察自己的心。請給我三個問題，幫助我察看這個禱告裡是否摻雜了我自己的願望、判斷或懼怕。請不要替我回答，只提問題。最後請推薦兩三處可以對照省察的經文。'),
    'DE': ('Mich selbst im Gebet ansehen', 'Während ich für jemand anderen bete, möchte ich mein eigenes Herz prüfen. Gib mir drei Fragen, ob sich meine eigenen Wünsche, Urteile oder Ängste in dieses Gebet mischen. Beantworte sie nicht für mich, frage nur. Empfiehl am Ende zwei oder drei Verse zum Nachdenken.'),
    'FR': ('Me regarder dans cette prière', 'En priant pour quelqu’un d’autre, je veux regarder mon propre cœur. Donne-moi trois questions pour voir si mes désirs, mes jugements ou mes peurs se mêlent à cette prière. N’y réponds pas à ma place ; pose seulement les questions. À la fin, recommande deux ou trois versets pour réfléchir.'),
    'ES': ('Mirarme a mí mismo en esta oración', 'Mientras oro por otra persona, quiero mirar mi propio corazón. Dame tres preguntas para ver si mis deseos, juicios o temores se mezclan en esta oración. No las respondas por mí; solo pregunta. Al final, recomienda dos o tres versículos para reflexionar.'),
    'PT': ('Olhar para mim nesta oração', 'Enquanto oro por outra pessoa, quero olhar para o meu próprio coração. Dê-me três perguntas para ver se meus desejos, julgamentos ou medos se misturam nesta oração. Não responda por mim; apenas pergunte. No fim, recomende dois ou três versículos para refletir.'),
    'RU': ('Взглянуть на себя в этой молитве', 'Молясь о другом человеке, я хочу взглянуть на своё сердце. Дай три вопроса, чтобы проверить, не примешиваются ли к этой молитве мои желания, суждения или страхи. Не отвечай за меня, только спрашивай. В конце порекомендуй два-три стиха для размышления.'),
    'AR': ('أنظر إلى نفسي في هذه الصلاة', 'وأنا أصلي من أجل شخص آخر أريد أن أنظر إلى قلبي. أعطني ثلاثة أسئلة لأرى هل تختلط رغباتي أو أحكامي أو مخاوفي بهذه الصلاة. لا تُجب عني، اسأل فقط. وفي النهاية أوصِ بآيتين أو ثلاث للتأمل.'),
}
SEED_TASK['T_PR_HEART'] = {
    'KO': ('하나님의 마음', '이런 기도를 드리는 사람을 향한 하나님의 마음을 성경이 말하는 범위 안에서만 설명해 주세요. 성경에 없는 약속을 하거나 결과를 단정하지 마세요. 근거가 되는 성경 구절 두세 개를 약명 장:절과 함께 알려 주세요.'),
    'EN': ("God's heart", 'Explain, only within what Scripture says, the heart of God toward someone who prays a prayer like this. Do not make promises the Bible does not make, and do not declare the outcome. Give two or three supporting verses with book abbreviation and chapter:verse.'),
    'JA': ('神の御心', 'このような祈りをささげる人に対する神の御心を、聖書が語る範囲の中でだけ説明してください。聖書にない約束をしたり、結果を断定したりしないでください。根拠となる聖書箇所を二つか三つ、略称と章:節で示してください。'),
    'ZH': ('神的心意', '请只在圣经所说的范围内，说明神对献上这样祷告之人的心意。不要作出圣经中没有的应许，也不要断言结果。请给出两三处依据经文（书卷简称和章:节）。'),
    'ZHT': ('神的心意', '請只在聖經所說的範圍內，說明神對獻上這樣禱告之人的心意。不要作出聖經中沒有的應許，也不要斷言結果。請給出兩三處依據經文（書卷簡稱和章:節）。'),
    'DE': ('Gottes Herz', 'Erkläre nur im Rahmen dessen, was die Schrift sagt, das Herz Gottes gegenüber jemandem, der so ein Gebet betet. Mache keine Versprechen, die die Bibel nicht macht, und lege das Ergebnis nicht fest. Nenne zwei oder drei belegende Verse mit Buchabkürzung und Kapitel:Vers.'),
    'FR': ('Le cœur de Dieu', 'Explique, seulement dans les limites de ce que dit l’Écriture, le cœur de Dieu envers quelqu’un qui prie une telle prière. Ne fais pas de promesses que la Bible ne fait pas et n’affirme pas l’issue. Donne deux ou trois versets d’appui avec l’abréviation du livre et chapitre:verset.'),
    'ES': ('El corazón de Dios', 'Explica, solo dentro de lo que dice la Escritura, el corazón de Dios hacia quien hace una oración así. No hagas promesas que la Biblia no hace ni declares el resultado. Da dos o tres versículos de apoyo con la abreviatura del libro y capítulo:versículo.'),
    'PT': ('O coração de Deus', 'Explique, apenas dentro do que a Escritura diz, o coração de Deus para com quem faz uma oração assim. Não faça promessas que a Bíblia não faz nem declare o resultado. Dê dois ou três versículos de apoio com a abreviação do livro e capítulo:versículo.'),
    'RU': ('Сердце Бога', 'Объясни, только в пределах того, что говорит Писание, сердце Бога к человеку, который молится такой молитвой. Не давай обещаний, которых нет в Библии, и не утверждай исход. Приведи два-три подтверждающих стиха с сокращением книги и главой:стихом.'),
    'AR': ('قلب الله', 'اشرح، في حدود ما يقوله الكتاب المقدس فقط، قلب الله تجاه من يصلي صلاة كهذه. لا تَعِد بما لم يعد به الكتاب المقدس ولا تجزم بالنتيجة. اذكر آيتين أو ثلاثًا داعمة مع اختصار السفر والأصحاح:العدد.'),
}
SEED_TASK['T_PR_WAIT'] = {
    'KO': ('쉬지 말고 기도', '응답이 아직 보이지 않는 기도를 계속 드리고 있습니다. 기다리며 기도한 성경 인물 두세 명과 그들이 붙든 말씀(약명 장:절)을 소개하고, 오늘 드릴 짧은 기도문 하나를 써 주세요.'),
    'EN': ('Keep praying', 'I keep praying a prayer whose answer I cannot see yet. Introduce two or three people in the Bible who prayed while waiting, with the word they held on to (book abbreviation and chapter:verse), and write one short prayer I can pray today.'),
    'JA': ('絶えず祈る', 'まだ応答が見えない祈りをささげ続けています。待ちながら祈った聖書の人物を二人か三人、彼らが握りしめた御言葉（略称と章:節）とともに紹介し、今日ささげる短い祈りを一つ書いてください。'),
    'ZH': ('不住地祷告', '我一直在为一件还没看到应允的事祷告。请介绍两三位在等待中祷告的圣经人物和他们所持守的经文（书卷简称和章:节），并写一段我今天可以献上的简短祷告。'),
    'ZHT': ('不住地禱告', '我一直在為一件還沒看到應允的事禱告。請介紹兩三位在等待中禱告的聖經人物和他們所持守的經文（書卷簡稱和章:節），並寫一段我今天可以獻上的簡短禱告。'),
    'DE': ('Weiter beten', 'Ich bete weiter um etwas, dessen Antwort ich noch nicht sehe. Stelle zwei oder drei biblische Personen vor, die wartend gebetet haben, mit dem Wort, an dem sie sich festhielten (Buchabkürzung und Kapitel:Vers), und schreibe ein kurzes Gebet für heute.'),
    'FR': ('Prier sans cesse', 'Je continue de prier pour une chose dont je ne vois pas encore la réponse. Présente deux ou trois personnages bibliques qui ont prié en attendant, avec la parole à laquelle ils se sont accrochés (abréviation du livre et chapitre:verset), et écris une courte prière pour aujourd’hui.'),
    'ES': ('Orar sin cesar', 'Sigo orando por algo cuya respuesta aún no veo. Presenta a dos o tres personajes bíblicos que oraron mientras esperaban, con la palabra a la que se aferraron (abreviatura del libro y capítulo:versículo), y escribe una oración breve para hoy.'),
    'PT': ('Orar sem cessar', 'Continuo orando por algo cuja resposta ainda não vejo. Apresente duas ou três pessoas da Bíblia que oraram enquanto esperavam, com a palavra a que se apegaram (abreviação do livro e capítulo:versículo), e escreva uma oração curta para hoje.'),
    'RU': ('Молиться непрестанно', 'Я продолжаю молиться о том, ответа на что пока не вижу. Представь двух-трёх библейских людей, которые молились в ожидании, со словом, за которое они держались (сокращение книги и глава:стих), и напиши короткую молитву на сегодня.'),
    'AR': ('صلِّ بلا انقطاع', 'ما زلت أصلي من أجل أمر لم أرَ استجابته بعد. عرّفني باثنين أو ثلاثة من شخصيات الكتاب المقدس صلّوا وهم ينتظرون، مع الكلمة التي تمسكوا بها (اختصار السفر والأصحاح:العدد)، واكتب صلاة قصيرة أصليها اليوم.'),
}
SEED_TASK['T_PR_THANK'] = {
    'KO': ('감사와 이어지는 기도', '이 기도에 하나님께서 응답하셨거나 더 좋은 것을 주셨습니다. 짧은 감사 기도문과, 이어서 드릴 기도문 하나를 써 주세요. 끝에 감사를 붙들 성경 구절 두 개를 약명 장:절과 함께 추천해 주세요.'),
    'EN': ('Thanksgiving and the next prayer', 'God has answered this prayer or given something better. Write a short prayer of thanks and one prayer to pray next. At the end, recommend two verses (book abbreviation and chapter:verse) to hold on to in thanksgiving.'),
    'JA': ('感謝と続く祈り', 'この祈りに神が応えてくださった、あるいはより良いものを与えてくださいました。短い感謝の祈りと、続けてささげる祈りを一つずつ書いてください。最後に感謝を支える聖書箇所を二つ、略称と章:節で推薦してください。'),
    'ZH': ('感恩与接续的祷告', '神已应允了这个祷告，或赐下了更好的。请写一段简短的感恩祷告，以及接下来可以献上的一段祷告。最后请推荐两处帮助我持守感恩的经文（书卷简称和章:节）。'),
    'ZHT': ('感恩與接續的禱告', '神已應允了這個禱告，或賜下了更好的。請寫一段簡短的感恩禱告，以及接下來可以獻上的一段禱告。最後請推薦兩處幫助我持守感恩的經文（書卷簡稱和章:節）。'),
    'DE': ('Dank und das nächste Gebet', 'Gott hat dieses Gebet erhört oder etwas Besseres gegeben. Schreibe ein kurzes Dankgebet und ein Gebet für das, was folgt. Empfiehl am Ende zwei Verse (Buchabkürzung und Kapitel:Vers), um im Dank zu bleiben.'),
    'FR': ('Action de grâce et prière suivante', 'Dieu a exaucé cette prière ou donné quelque chose de meilleur. Écris une courte prière de remerciement et une prière pour la suite. À la fin, recommande deux versets (abréviation du livre et chapitre:verset) pour rester dans la reconnaissance.'),
    'ES': ('Gratitud y la siguiente oración', 'Dios ha respondido esta oración o ha dado algo mejor. Escribe una breve oración de gratitud y una oración para lo que sigue. Al final, recomienda dos versículos (abreviatura del libro y capítulo:versículo) para permanecer en gratitud.'),
    'PT': ('Gratidão e a próxima oração', 'Deus respondeu a esta oração ou deu algo melhor. Escreva uma breve oração de gratidão e uma oração para o que vem a seguir. No fim, recomende dois versículos (abreviação do livro e capítulo:versículo) para permanecer em gratidão.'),
    'RU': ('Благодарение и следующая молитва', 'Бог ответил на эту молитву или дал лучшее. Напиши короткую благодарственную молитву и одну молитву на дальнейшее. В конце порекомендуй два стиха (сокращение книги и глава:стих), чтобы оставаться в благодарности.'),
    'AR': ('الشكر والصلاة التالية', 'لقد استجاب الله هذه الصلاة أو أعطى ما هو أفضل. اكتب صلاة شكر قصيرة وصلاة لما يلي. وفي النهاية أوصِ بآيتين (اختصار السفر والأصحاح:العدد) للثبات في الشكر.'),
}

# ★ 2026-10-20 (docs/1.txt 9-3(6)(9)) 기도 AI 다시 짜기 — **메인 프롬프트 + 그 아래 Pick**.
#   개인 기도(메인 하나 · 옛 Pick 다섯) / 공동체 기도(교회 · 성도·셀 · 선교지 · 사회·국가 — 메인마다 제 Pick) /
#   감사 도우미(감사와 이어지는 기도 + 감사 Pick 넷 — 기도 내용 도우미와 따로).
#   메인은 「꼬리물기」로 연다 — 형편을 더 알아야 하면 질문 둘 이하를 먼저 하고 기다린다(사용자 「단순한 몇 줄로는 파악이 어렵다」).
#   ⚠ 한국어·영어만 먼저(사용자 「번역은 한국어를 확정한 뒤」) — 다른 언어는 영어로 물러선다(`KO_FIRST`).
_ASK2 = ('이 기도의 형편을 더 알아야 제대로 도울 수 있다면, 꼭 필요한 질문을 두 가지 이하로 짧게 먼저 묻고 제 대답을 기다려 주세요. '
         '충분히 알 수 있으면 묻지 말고 바로 답해 주세요. ')
_ASK2_EN = ('If you need to know more about the situation to help well, first ask at most two short, necessary questions and wait for my answer. '
            'If you already know enough, do not ask; answer right away. ')
PRAYER_V2 = {
    'PR_ME': {'KO': ('개인 기도', '위 [기도 내용]은 나 자신이나 가족·가까운 사람을 위한 개인 기도입니다. ' + _ASK2 +
                     '판단하거나 응답을 약속하지 말고, 이 사정에 맞는 위로와 기도의 방향을 짧게 먼저 말한 뒤 아래 요청에 답해 주세요.'),
              'EN': ('Personal prayer', 'The [Prayer request] above is a personal prayer for myself, my family or someone close. ' + _ASK2_EN +
                     'Do not judge or promise an answer; first give brief comfort and a direction for prayer that fits this situation, then answer the requests below.')},
    'PR_CHURCH': {'KO': ('교회 공동체', '위 [기도 내용]은 우리 교회 공동체(하나됨, 부흥, 다음 세대, 예배와 섬김)를 위한 기도입니다. ' + _ASK2 +
                         '어느 사람이나 편을 탓하지 말고, 교회가 함께 드릴 기도의 방향을 제안해 주세요.'),
                  'EN': ('Church community', 'The [Prayer request] above is for our church community (unity, revival, the next generation, worship and service). ' + _ASK2_EN +
                         'Do not blame any person or side; suggest a direction for the church to pray together.')},
    'PR_CH_UNITY': {'KO': ('하나됨과 화목', '교회 안의 하나됨과 화목을 위해 함께 드릴 기도 제목 세 가지를 제안하고, 제목마다 붙들 구절 하나를 약명 장:절로 추천해 주세요.'),
                    'EN': ('Unity and peace', 'Suggest three prayer points for unity and peace within the church, with one verse to hold on to for each (book abbreviation chapter:verse).')},
    'PR_CH_REVIVAL': {'KO': ('말씀과 기도의 부흥', '교회가 말씀과 기도로 새로워지도록 드릴 기도의 방향을 설명하고, 붙들 구절 둘을 약명 장:절로 추천해 주세요.'),
                      'EN': ('Revival in Word and prayer', 'Explain a direction of prayer for the church to be renewed by the Word and prayer, and recommend two verses (book abbreviation chapter:verse).')},
    'PR_CH_NEXT': {'KO': ('다음 세대와 주일학교', '다음 세대(주일학교·청소년·청년)를 위해 교회가 드릴 구체적인 기도 제목 세 가지와, 함께 붙들 구절 하나를 약명 장:절로 추천해 주세요.'),
                   'EN': ('The next generation', 'Suggest three concrete prayer points for the next generation (children, youth, young adults) and one verse to hold on to (book abbreviation chapter:verse).')},
    'PR_CELL': {'KO': ('성도 간(셀·소그룹)', '위 [기도 내용]은 함께하는 성도들(셀·소그룹·구역)을 위한 기도입니다. ' + _ASK2 +
                       '서로의 짐을 함께 지는 기도가 되도록 방향을 제안해 주세요.'),
                'EN': ('Fellow believers (cell group)', 'The [Prayer request] above is for the believers I walk with (cell group, small group). ' + _ASK2_EN +
                       'Suggest a direction so that we carry one another’s burdens in prayer.')},
    'PR_CE_CARE': {'KO': ('아픔을 함께 지는 기도', '어려움을 겪는 지체를 위해 함께 드릴 기도와, 소그룹이 구체적으로 돌볼 수 있는 방법 두세 가지를 제안해 주세요.'),
                   'EN': ('Sharing the burden', 'Suggest a prayer to pray together for a member who is struggling, and two or three concrete ways the group can care for them.')},
    'PR_CE_TOGETHER': {'KO': ('함께 드릴 기도 순서', '소그룹이 함께 드릴 짧은 기도 순서(찬양과 감사, 서로를 위한 간구, 마무리)를 이 기도 내용에 맞게 제안해 주세요.'),
                       'EN': ('A prayer order for the group', 'Suggest a short order of prayer for the group (praise and thanks, prayer for one another, closing) that fits this request.')},
    'PR_MISSION': {'KO': ('선교지', '우리 교회(선교단체)가 선교하는 곳을 위한 기도 제목, 내용, 방향을 추천해 주세요. ' + _ASK2 +
                          '확인되지 않은 현지 사정을 지어내지 말고, 알 수 없는 것은 모른다고 말해 주세요.'),
                   'EN': ('Mission field', 'Recommend prayer points, content and direction for the place where our church (mission) serves. ' + _ASK2_EN +
                          'Do not invent local facts you cannot confirm; say so when you do not know.')},
    'PR_MI_FIELD': {'KO': ('현지 사역의 기도 영역', '현지에서 활동하는 선교사들의 경험에 비추어 기도가 필요한 영역과 방향을 설명해 주세요.'),
                    'EN': ('Areas that need prayer', 'In light of the experience of missionaries on the field, explain the areas and directions that need prayer.')},
    'PR_MI_SPIRIT': {'KO': ('영적 방해를 위한 기도', '현지 선교를 가로막는 중요한 영적 방해에 대한 기도 방향을 설명해 주세요.'),
                     'EN': ('Spiritual opposition', 'Explain a direction of prayer concerning the main spiritual opposition to mission there.')},
    'PR_MI_FAMILY': {'KO': ('사역자와 가족', '현지 사역자, 사모, 자녀들이 겪는 가장 어려운 부분을 위해 기도할 수 있도록 안내해 주세요.'),
                     'EN': ('Workers and their families', 'Guide me to pray for the hardest things that missionaries, their spouses and children face.')},
    'PR_MI_VERSE': {'KO': ('붙들 구절 셋', '이 선교지의 지금 형편에 맞는 효과적인 기도를 위해 붙들 성경 구절 세 개를 약명 장:절로 추천해 주세요.'),
                    'EN': ('Three verses', 'Recommend three verses to hold on to for effective prayer for this field now (book abbreviation chapter:verse).')},
    'PR_NATION': {'KO': ('사회와 나라', '위 [기도 내용]은 사회와 나라를 위한 기도입니다(성경적 세계관과의 갈등, 박해, 정의와 평화). ' + _ASK2 +
                         '한쪽 정치 입장을 정답처럼 말하지 말고, 성경이 가르치는 방향으로 기도하도록 도와주세요.'),
                  'EN': ('Society and nation', 'The [Prayer request] above is for our society and nation (conflict with a biblical worldview, persecution, justice and peace). ' + _ASK2_EN +
                         'Do not present one political position as the answer; help me pray in the direction Scripture teaches.')},
    'PR_NA_VIEW': {'KO': ('세계관 갈등 속 바른 증언', '성경적 세계관과 부딪히는 문제 앞에서 성도가 사랑과 진리로 증언하도록 드릴 기도의 방향을 설명해 주세요.'),
                   'EN': ('Faithful witness amid conflict', 'Explain how to pray that believers bear witness with love and truth where a biblical worldview is challenged.')},
    'PR_NA_PERSEC': {'KO': ('박해받는 성도', '믿음 때문에 고난받는 성도들을 위한 기도 제목과 붙들 구절 하나를 약명 장:절로 추천해 주세요.'),
                     'EN': ('Persecuted believers', 'Suggest prayer points for believers who suffer for their faith and one verse to hold on to (book abbreviation chapter:verse).')},
    'PR_NA_LEADERS': {'KO': ('나라와 지도자', '나라와 지도자들을 위해 드릴 기도(정의, 평화, 지혜)의 방향을 성경에 근거해 제안해 주세요.'),
                      'EN': ('The nation and its leaders', 'Suggest, from Scripture, a direction of prayer for the nation and its leaders (justice, peace, wisdom).')},
    'PR_TH_VERSE': {'KO': ('감사의 구절', '이 응답에 맞는 감사의 성경 구절 세 개를 약명 장:절로 추천해 주세요.'),
                    'EN': ('Verses of thanks', 'Recommend three verses of thanksgiving that fit this answer (book abbreviation chapter:verse).')},
    'PR_TH_DO': {'KO': ('감사를 행동으로', '이 감사를 삶으로 표현할 수 있는 작은 일 두세 가지를 제안해 주세요.'),
                 'EN': ('Thanks in action', 'Suggest two or three small things I can do to express this thanks in my life.')},
    'PR_TH_ACCEPT': {'KO': ('바라던 대로가 아니어도', '바라던 대로 응답되지 않았더라도 하나님의 선하심을 신뢰하며 감사할 수 있도록 권면하고, 붙들 구절 하나를 약명 장:절로 추천해 주세요.'),
                     'EN': ('Even when it was not as I hoped', 'Encourage me to trust God’s goodness and give thanks even if the answer was not what I hoped, and recommend one verse (book abbreviation chapter:verse).')},
    'PR_TH_WITNESS': {'KO': ('감사 간증 정리', '이 응답을 다른 사람에게 나눌 수 있는 짧은 감사 간증(세 문장)으로 정리해 주세요. 사람 이름은 쓰지 마세요.'),
                      'EN': ('A short testimony', 'Shape this answer into a short testimony of thanks (three sentences) I can share. Do not use people’s names.')},
}
for _k, _v in PRAYER_V2.items():
    SEED_TASK['T_' + _k] = _v
    PRAYER_TASKS.append(_k)
    TASKS_OF['PRAYER'].append(_k)
    TASK_KIND[_k] = 'T_' + _k
    TASK_ALL.append('T_' + _k)
#: 번역은 한국어 확정 뒤 — 이 줄들은 11개 언어 검사에서 뺀다(없는 언어는 영어로 물러선다)
KO_FIRST = {'T_' + _k for _k in PRAYER_V2}

# ★★ 2026-10-21 분야별 도움말 업무(docs/1.txt 15번 · 사용자 「분야별 AI묻기 : PC에 적절한 프롬프트가 설계되지 않았다.
#   PC에 프롬프트를 만들어라. 신학생은 분류에서 제거하라. 3개만 유지하자」).
#   그전에는 요구사항 칸에 한 줄을 채울 뿐이고 업무는 그때 골라 둔 것(설명문 작성 등)이 그대로 갔다 —
#   그 업무의 「설명문을 써라」 지시와 한 줄 요구가 부딪혔다. 이제 분야마다 **제 업무(역할 + 할 일)** 를 둔다.
#   · 분야 「▾ ▸ AI 에게 묻기」로 연 채팅에서만 보인다(`ROLE_TASKS` · 화면이 가른다) · 답은 [저장 ▾] 「분야 도움말로」
#   · 프롬프트 수정 화면에서 고칠 수 있다(앱 업무 줄 · [기본으로])
#   ⚠ 「쓸 말」을 주지 않는다(프롬프트 문장이 그대로 찍힌다) — 다룰 것과 꼴만 말한다.
ROLE_TASK_OF = {'S_PASTOR': 'RT_PASTOR', 'S_MISSION': 'RT_MISSION', 'S_PWIFE': 'RT_PWIFE'}
# ★ 2026-10-26 [일반] 설명의 분야 = **평신도의 삶의 자리**(docs/1.txt 6-2 · 사용자 「전문사역자가 아닌 일반 평신도들이므로 당연히 구분값이 달라야 한다」).
#   코드 = role_tips.LAY_ROLES 와 같다(두 곳에서 따로 정하면 갈린다 — 이름은 여기 한 표).
LAY_WHO = {'L_BIZ': ('사업가', 'business owner'), 'L_WORK': ('직장인', 'office worker'),
           'L_YOUTH': ('학생·청년', 'student or young adult'), 'L_PUBLIC': ('공무원·정치인', 'public servant or politician'),
           'L_MED': ('의료인', 'healthcare worker'), 'L_LAW': ('법조인', 'legal professional'),
           'L_RETIRE': ('은퇴자', 'retiree')}
for _lc in LAY_WHO:
    ROLE_TASK_OF[_lc] = 'RT_' + _lc[2:]
ROLE_TASKS = tuple(ROLE_TASK_OF.values())
#: ★ 2026-10-21 분야 업무는 제 꼴(한 문단)과 제 독자(그 분야)가 있다 — 사용자 칸·출력서식·자유·Pick·문체·분량·예시를 싣지 않는다
#:   (첫 답이 개요식 출력서식과 「견해를 나란히」 사용자 칸을 따라 한 문단 대신 세 마디를 썼다).
ROLE_DROP_SLOTS = ('FREE', 'PICK', 'ASKER', 'STYLE', 'LENGTH', 'EXAMPLE', 'FORMAT')
# ★ 2026-10-21 사용자 「선택한 구절과 관련된 분야별 질문에 집중해서 답해야 한다」 — 첫 답이 창조 순서 논쟁·교단 견해로 한 문단을 썼다
_RT_FOCUS_KO = ' 그 분야 사람이 이 구절을 두고 실제로 묻는 것에만 답하고, 해석사·학설·교단 견해 비교로 넓히지 않습니다.'
_RT_FOCUS_EN = (' Answer only what someone in that work would actually ask about this passage; do not widen into the history of '
                'interpretation, scholarly theories or comparisons of church traditions.')
_RT_FORM_KO = ' 한 문단 네다섯 문장으로, 소제목·번호·기호 없이 씁니다. 본문에 근거하고, 다른 구절은 꼭 필요할 때 한두 곳만 약명 장:절로 댑니다.'
_RT_FORM_EN = (' Write one paragraph of four or five sentences, with no headings, numbers or symbols. Stay grounded in the text, '
               'and cite other passages only when really needed, at most one or two, as book abbreviation chapter:verse.')
SEED_TASK['T_RT_PASTOR'] = {
    'KO': ('목회 도움말', '[구절]을 설교하고 성도를 돌보려는 목회자에게 도움말을 써 주세요. 이 본문이 오늘 회중에게 건네는 중심, '
           '설교에서 흔히 빠지는 오해 하나, 목양(심방·상담·교회 생활)에서 이 본문을 쓸 자리를 다룹니다.' + _RT_FOCUS_KO + _RT_FORM_KO),
    'EN': ('Pastoral notes', 'Write notes for a pastor who will preach [passage] and care for the congregation. Cover what this text says '
           'to today\'s congregation, one misunderstanding preachers often fall into, and where the text serves in pastoral care '
           '(visits, counselling, church life).' + _RT_FOCUS_EN + _RT_FORM_EN),
}
SEED_TASK['T_RT_MISSION'] = {
    'KO': ('선교 도움말', '[구절]을 다른 문화와 언어의 사람들에게 전하려는 선교사에게 도움말을 써 주세요. 그 문화에서 오해되기 쉬운 낱말이나 개념, '
           '그것을 풀어 전하는 길, 현지 교회와 제자 훈련에 이 본문이 주는 뜻을 다룹니다. 어느 문화도 낮추어 말하지 않습니다.' + _RT_FOCUS_KO + _RT_FORM_KO),
    'EN': ('Mission notes', 'Write notes for a missionary bringing [passage] to people of another culture and language. Cover words or '
           'ideas easily misunderstood in another culture, how to explain them, and what the text means for the local church and '
           'discipleship. Do not speak of any culture as lesser.' + _RT_FOCUS_EN + _RT_FORM_EN),
}
SEED_TASK['T_RT_PWIFE'] = {
    'KO': ('사모 도움말', '[구절]을 목회자의 아내(사모)로서 붙들려는 분에게 도움말을 써 주세요. 성도를 돌보고 이야기를 들어 줄 때 이 본문을 쓸 자리, '
           '사모 자신의 신앙과 가정에 주는 위로를 다룹니다. 훈계하지 않고 따뜻하게, 짐을 더 지우지 않게 씁니다.' + _RT_FOCUS_KO + _RT_FORM_KO),
    'EN': ('Notes for a pastor\'s wife', 'Write notes for a pastor\'s wife who wants to hold on to [passage]. Cover where the text helps '
           'when caring for and listening to church members, and the comfort it gives to her own faith and family. Write warmly, '
           'without lecturing or adding burdens.' + _RT_FOCUS_EN + _RT_FORM_EN),
}
for _lc, (_ko, _en) in LAY_WHO.items():
    SEED_TASK['T_RT_' + _lc[2:]] = {
        'KO': ('%s 도움말' % _ko,
               '[구절]을 %s의 자리에서 읽으려는 평신도에게 도움말을 써 주세요. 그 자리의 일상(일·관계·결정)에서 이 본문이 비추는 것, '
               '붙들 약속이나 조심할 것 하나, 오늘 해 볼 작은 걸음 하나를 다룹니다. 훈계하지 않고 짐을 더 지우지 않습니다.'
               % _ko + _RT_FOCUS_KO + _RT_FORM_KO),
        'EN': ('Notes for a %s' % _en,
               'Write notes for a lay believer who reads [passage] as a %s. Cover what the text shows about everyday life in that '
               'place (work, relationships, decisions), one promise to hold or one thing to watch, and one small step for today. '
               'Do not lecture or add burdens.' % _en + _RT_FOCUS_EN + _RT_FORM_EN),
    }
for _rk in ROLE_TASKS:
    TASKS_OF['VERSE'].append(_rk)
    TASK_KEYS.append(_rk)
    TASK_KIND[_rk] = 'T_' + _rk
    TASK_ALL.append('T_' + _rk)
    KO_FIRST.add('T_' + _rk)
#: 화면 차례 — (메인, [Pick]) · 기도 내용 도우미(개인·공동체)와 감사 도우미가 갈린다
PRAYER_GROUPS = {
    'ME': [('PR_ME', ['PR_VERSE', 'PR_TODO', 'PR_SELF', 'PR_HEART', 'PR_WAIT'])],
    'US': [('PR_CHURCH', ['PR_CH_UNITY', 'PR_CH_REVIVAL', 'PR_CH_NEXT', 'PR_VERSE', 'PR_TODO']),
           ('PR_CELL', ['PR_CE_CARE', 'PR_CE_TOGETHER', 'PR_VERSE', 'PR_TODO']),
           ('PR_MISSION', ['PR_MI_FIELD', 'PR_MI_SPIRIT', 'PR_MI_FAMILY', 'PR_MI_VERSE']),
           ('PR_NATION', ['PR_NA_VIEW', 'PR_NA_PERSEC', 'PR_NA_LEADERS', 'PR_VERSE'])],
    'THANKS': [('PR_THANK', ['PR_TH_VERSE', 'PR_TH_DO', 'PR_TH_ACCEPT', 'PR_TH_WITNESS'])],
}

#: ★ Free 갈래의 자리표 — 닻이 없으니 「본문」으로 채운다(지어내지 않는다).
FREE_WORD = {'KO': '이 본문', 'EN': 'this passage', 'JA': 'この本文', 'ZH': '这段经文',
             'ZHT': '這段經文', 'DE': 'diesen Text', 'FR': 'ce passage', 'ES': 'este pasaje',
             'PT': 'esta passagem', 'RU': 'этот текст', 'AR': 'هذا المقطع'}

# 자리표를 채움 규칙(`_PH_VERSE`)이 아는 글자로 맞춘다 — 언어마다 한 낱말.
_PH_FIX = {'EN': ('[verse]', '[passage]'), 'DE': ('[Vers]', '[Stelle]'),
           'FR': ('[verset]', '[passage]'), 'ES': ('[versículo]', '[pasaje]'),
           'PT': ('[versículo]', '[passagem]'), 'RU': ('[стих]', '[отрывок]'),
           'AR': ('[الآية]', '[المقطع]')}
for _k, _d in SEED_TASK.items():
    for _lg, (_a, _b) in list(_PH_FIX.items()):
        if _lg in _d:
            _d[_lg] = (_d[_lg][0], _d[_lg][1].replace(_a, _b))


SEED_SCOPE = dict({k: 'VERSE' for k in KINDS},
                  **{k: 'TERM' for k in TERM_KINDS},
                  **{k: 'REF' for k in REF_KINDS_SEED},
                  # ★ 축 지시문은 **`AXIS`** — 성격 줄(VERSE/TERM/REF)에 안 뜬다.
                  **{k: 'AXIS' for k in AXIS_ALL},
                  # ★ 317차 2단계 — 역할·할 일은 **`TASK`** — 창고(Pick)에 안 뜬다.
                  **{k: 'TASK' for k in TASK_ALL})


#: 옛 「질문」 씨앗 — **그대로인 줄만** 새 대화식 씨앗으로 옮긴다(`_migrate_ask_split`).
OLD_T_ASK = {
        'KO': ('질문', '[구절]에 대해 아래 내 질문에 답해 주세요.'),
        'EN': ('Question', 'Please answer my question below about [verse].'),
        'JA': ('質問', '[聖句]について、下の私の質問に答えてください。'),
        'ZH': ('提问', '请就[经文]回答我下面的问题。'),
        'ZHT': ('提問', '請就[經文]回答我下面的問題。'),
        'DE': ('Frage', 'Bitte beantworte meine Frage unten zu [Vers].'),
        'FR': ('Question', 'Réponds à ma question ci-dessous sur [verset].'),
        'ES': ('Pregunta', 'Responde a mi pregunta de abajo sobre [versículo].'),
        'PT': ('Pergunta', 'Responda à minha pergunta abaixo sobre [versículo].'),
        'RU': ('Вопрос', 'Ответь на мой вопрос ниже о [стих].'),
        'AR': ('سؤال', 'أجب عن سؤالي أدناه حول [الآية].'),
    }


def _migrate_ask_split(conn):
    """★ 2026-10-16 — 「연구하자」(RESEARCH) → 구절질문(ASK) · 성경공부(STUDY) 두 업무. 한 번만(`AI_ASK_SPLIT`).

    · Pick(업무 RESEARCH 에 살던 정형 질문들)은 **구절질문의 Pick** 이 된다(성경공부는 제 씨앗을 새로 받는다).
    · 직전값 `AI_LAST_<갈래>_RESEARCH_ASK` → `AI_LAST_<갈래>_ASK`(성경공부 직전값은 옛 Pick 번호라 버린다).
    · 고른 업무 `AI_TASK_<갈래>=RESEARCH` → 그때 갈래(AI_RMODE)대로 ASK/STUDY.
    · 옛 질문 씨앗 **그대로인 줄만** 새 대화식 글로(사람이 고친 글은 안 덮는다).
    """
    if (get_setting(conn, 'AI_ASK_SPLIT', '') or '').strip():
        return 0
    n = 0
    conn.execute("UPDATE user_ai_prompt SET task='ASK' WHERE task='RESEARCH'")
    try:
        conn.execute("UPDATE user_ai_pick_seeded SET task='ASK' WHERE task='RESEARCH'")
    except Exception:                                     # noqa: BLE001
        pass
    for sc in ('VERSE', 'TERM'):
        old = get_setting(conn, 'AI_LAST_%s_RESEARCH_ASK' % sc, '')
        if old and not get_setting(conn, 'AI_LAST_%s_ASK' % sc, ''):
            set_setting(conn, 'AI_LAST_%s_ASK' % sc, old)
        if (get_setting(conn, 'AI_TASK_' + sc, '') or '').upper() == 'RESEARCH':
            rm = (get_setting(conn, 'AI_RMODE', '') or '').upper()
            set_setting(conn, 'AI_TASK_' + sc, 'STUDY' if rm == 'STUDY' else 'ASK')
    for pid, lg, title, body in conn.execute(
            "SELECT prompt_id, lang_code, title, body FROM user_ai_prompt WHERE kind='T_ASK'").fetchall():
        o, nw = OLD_T_ASK.get(lg), SEED_TASK['T_ASK'].get(lg)
        if o and nw and (body or '') == o[1]:
            conn.execute('UPDATE user_ai_prompt SET body=? WHERE prompt_id=?', (nw[1], pid))
            n += 1
    # 출력서식 — 지금 쓰던 벌을 「업무 기본」으로 적어 둔다(질문만 대화식으로 바뀌고 나머지는 그대로)
    try:
        d = part_sets(conn, 'FORMAT')
        nm = (d['items'][d['on']].get('name') or '').strip()
        m = _jget(conn, FMT_BY_TASK_KEY, {}) or {}
        if nm and '*' not in m:
            m['*'] = nm
            _jset(conn, FMT_BY_TASK_KEY, m)
    except Exception as e:                                # noqa: BLE001
        print('[ask split fmt] %s' % e)
    set_setting(conn, 'AI_ASK_SPLIT', '1')
    return n


def _migrate_desc_split(conn):
    """옛 「설명문 작성」 씨앗(연구질문까지 쓰게 하던 것) **그대로인 줄만** 일반설명문 씨앗으로 바꾼다.

    ⚠ 사람이 이름이나 내용을 고친 줄은 안 덮는다 — 그 글은 일반설명문 업무가 그대로 쓴다.
    """
    n = 0
    for pid, lg, title, body in conn.execute(
            "SELECT prompt_id, lang_code, title, body FROM user_ai_prompt WHERE kind='T_DESC_V'").fetchall():
        old = OLD_DESC_V.get(lg)
        new = SEED_TASK['T_DESC_V'].get(lg)
        if not old or not new:
            continue
        sets = {}
        if (body or '') == old[1]:
            sets['body'] = new[1]
        if (title or '') == old[0]:
            sets['title'] = new[0]
        if sets:
            conn.execute('UPDATE user_ai_prompt SET %s WHERE prompt_id=?' % ', '.join('%s=?' % k for k in sets),
                         list(sets.values()) + [pid])
            n += 1
    return n


def ensure_seeds(conn):
    """없는 (언어, 갈래)만 채운다 — 사람이 고친 줄은 안 덮는다. 채운 수를 낸다."""
    init(conn)
    n = _migrate_axes(conn)                     # ★ 317차 — 옛 깊이 글을 새 상태로
    n += _migrate_tasks(conn)                   # ★ 317차 2단계 — 고친 옛 성격 글을 새 업무로
    n += _migrate_desc_split(conn)              # ★ 2026-10-14 — 설명문 작성 → 일반설명문(옛 씨앗 그대로인 줄만)
    n += _migrate_ask_split(conn)               # ★ 2026-10-16 — 연구하자 → 구절질문 · 성경공부
    n += _migrate_book_ph(conn)                 # ★ 2026-10-27 — 도서 묵상 자리표 [연구자료] → [도서]
    n += renew_teach(conn)                      # ★ 2026-10-20 — 교사 질문 횟수 자리표(옛 씨앗 그대로인 줄만)
    have = {(r[0], r[1]) for r in conn.execute("SELECT lang_code, kind FROM user_ai_prompt")}
    for i, kind in enumerate(KINDS + TERM_KINDS + REF_KINDS_SEED + AXIS_ALL + TASK_ALL):
        seeds = (SEED_PROMPTS.get(kind) or SEED_TERM.get(kind)
                 or SEED_REF.get(kind) or SEED_AXIS.get(kind) or SEED_TASK.get(kind) or {})
        for lg, (title, body) in seeds.items():
            if (lg, kind) in have:
                continue
            conn.execute("INSERT INTO user_ai_prompt(lang_code, kind, title, body, sort_order, scope, genre)"
                         " VALUES(?,?,?,?,?,?,?)", (lg, kind, title, body, i * 10,
                                                    SEED_SCOPE.get(kind, 'VERSE'),
                                                    GENRE_OF.get(kind, GENRE_DEFAULT)))
            n += 1
    conn.execute("UPDATE user_ai_prompt SET scope='VERSE' WHERE scope IS NULL OR scope=''")
    # ⚠ **옛 줄(303차 앞)에 성격을 채운다** — 사람이 고른 성격은 안 덮는다.
    for k, g in GENRE_OF.items():
        conn.execute("UPDATE user_ai_prompt SET genre=? WHERE kind=?"
                     " AND (genre IS NULL OR genre='')", (g, k))
    conn.execute("UPDATE user_ai_prompt SET genre=? WHERE genre IS NULL OR genre=''",
                 (GENRE_DEFAULT,))
    conn.commit()
    return n


#: 프롬프트의 **성격** — (열쇠, 이름 열쇠, 한국어 이름, 복수선택인가).
#: ★★★ 화면이 이 표대로 묶는다(2026-09-30 docs/1.txt 1번 3열 「프롬프트 목록을
#:   성격에 따라 배치하기」). 갈래가 늘면 여기 한 줄이고 화면은 안 고친다.
#: ★★★ **복수선택은 일반대화형 안에서만**(사용자 지시) — 「여기에 많이 추가될
#:   가능성이 있음. 버튼방식이 아니라 체크박스 복수선택 방식으로 전환하자」.
#:   ⚠ 질문형·분석형·통합형·교사형은 **한 번에 하나**다: 질문형은 내 질문을 그
#:     프롬프트에 끼우고, 통합형·교사형은 시스템 지시라 섞으면 서로를 무너뜨린다.
#: ★★★ **AI강사형이 다섯째다**(2026-09-30 사용자 「내가 제공한 프롬프트 목록에
#:   **AI강사형이 빠져있다. 추가하라**」) — docs/1.txt 의 네 묶음에 없던 자리다.
#: ⚠ **AI강사형을 따로 둔 까닭** — 사용자가 적은 넷에 성경교사가 없는데 씨앗에는
#:   있다(298차 사용자 지시로 만든 기능이라 걷을 수 없다). 일반대화형에 넣으면
#:   복수선택에 섞이는데 그것은 「AI 가 먼저 묻는다」와 같이 갈 수 없다.
GENRES = [
    # ★★★ **주관식이 맨 위**(308차 사용자 「이해확인형 질문을 가장 위에 배치하라」).
    #   자유 입력 칸이 붙는 자리라 **어떤 질문이든** 할 수 있다.
    ('QUEST', 'AI_G_QUEST', '주관식 질문형', False),
    # ★ **객관식** — 미리 만들어 둔 것을 **체크상자로** 고른다(복수선택은 여기만).
    ('CHAT',  'AI_G_CHAT',  '객관식 질문형', True),
    ('ANAL',  'AI_G_ANAL',  '분석형',     False),
    ('MERGE', 'AI_G_MERGE', '통합형',     False),
    ('TEACH', 'AI_G_TEACH', 'AI강사형',  False),
]
GENRE_KEYS = [g[0] for g in GENRES]
MULTI_GENRES = {g[0] for g in GENRES if g[3]}
GENRE_DEFAULT = 'CHAT'

#: ★★★ **Pick(객관식) 은 성격이 아니라 조미료 축이다**(310차 · docs/1.txt 5판).
#:   사용자가 Pick 을 Depth·View 와 나란히 두라 했고, 실제로 성격이 다르다 —
#:   Ask·Study·Merge·Tutor 는 **무엇을 물을까**(하나만 고른다)이고 Pick 은
#:   **무엇을 곁들일까**(여럿 체크한다)다.
#:   ⚠⚠ 그래서 조립 규칙이 바뀐다 — 성격은 **주 물음**이 정하고 Pick 은 뒤에
#:     덧붙는다. 화면이 'CHAT' 을 글자로 적지 않게 여기 한 줄로 둔다.
PICK_GENRE = 'CHAT'
#: 주 물음이 되는 성격들 — 이 가운데 **하나**가 `genre` 를 정한다.
MAIN_GENRES = tuple(g for g in GENRE_KEYS if g != PICK_GENRE)
#: ★★★ **홀로 서는 성격 — Pick 을 곁들이지 않는다**(310차).
#:   `GENRES` 머리글이 이미 적어 둔 규칙이다 — 「통합형·교사형은 **시스템
#:   지시**라 섞으면 서로를 무너뜨린다」. 교사는 「AI 가 먼저 묻는다」이고
#:   통합은 「이 대화를 한 편의 글로」라 곁들임이 뜻을 갖지 않는다.
SOLO_GENRES = ('TEACH', 'MERGE')

#: 씨앗 갈래(kind) → 성격. 사람이 더한 것(`USER…`)은 기본 `CHAT`(고칠 수 있다).
GENRE_OF = {
    'ASK': 'CHAT', 'COMPARE': 'CHAT', 'TERM_ASK': 'CHAT', 'TERM_COMPARE': 'CHAT',
    # 304차 — 사용자 지시(일반대화형에 원어 설명 · 비슷한 구절)
    'ORIG': 'CHAT', 'SIMILAR': 'CHAT',
    # 310차 — Pick 셋 신설(묵상 적용 · 문맥설명 · 인물/장소 설명)
    'APPLY': 'CHAT', 'CONTEXT': 'CHAT', 'WHOWHERE': 'CHAT',
    'CHECK': 'QUEST',
    'NOTE': 'ANAL', 'STUDY': 'ANAL', 'TERM_STUDY': 'ANAL',
    'MERGE': 'MERGE', 'TEACH': 'TEACH',
    # 303차 — 연구자료 갈래
    'REF_HELP': 'ANAL', 'REF_ASK': 'CHAT',
}


def genre_of(kind, genre=None):
    """그 프롬프트의 성격 — 적힌 값이 먼저, 없으면 갈래 표, 그래도 없으면 기본."""
    g = (genre or '').strip().upper()
    if g in GENRE_KEYS:
        return g
    return GENRE_OF.get(str(kind or '').upper(), GENRE_DEFAULT)


def quest_slot(lang='KO'):
    """질문형 프롬프트의 「여기에 적으세요」 자리 — **씨앗 본문에서 뽑는다**.

    ★ 자리표 글자를 두 곳에 적지 않는다 — 씨앗을 고치면 이 문이 따라온다.
    ⚠ 사람이 본문을 고쳐 그 자리가 사라졌으면 빈 글을 낸다(부르는 쪽이 끝에 붙인다).
    """
    import re
    b = (SEED_PROMPTS.get('CHECK', {}).get((lang or 'KO').upper())
         or SEED_PROMPTS['CHECK']['EN'])[1]
    m = re.search(r'\(([^()]{1,40})\)', b)
    return m.group(0) if m else ''


def fill_question(body, question, lang='KO'):
    """질문형 — **내 질문을 그 프롬프트에 끼운다**(자리표가 없으면 끝에 붙인다).

    ★ docs/1.txt 1번 3열 「질문이 자동으로 질문 프롬프트 창에 결합되어 표시」.
    """
    q = (question or '').strip()
    if not q:
        return body or ''
    slot = quest_slot(lang)
    if slot and slot in (body or ''):
        return body.replace(slot, q, 1)
    return ((body or '').rstrip() + NL + q).strip()


def join_bodies(bodies):
    """복수선택 — 선택한 프롬프트들을 **한 물음으로** 잇는다(빈 줄로 나눈다)."""
    out = [(b or '').strip() for b in bodies if (b or '').strip()]
    return (NL + NL).join(out)


def axis_rows(conn, axis, lang='KO'):
    """그 축의 값 목록 — `[(kind, 이름, 지시문)]`(차례는 `AXIS_KINDS`).

    ★★★ **제목이 곧 화면의 라디오 이름**이다 — 사용자가 프롬프트 제목을 고치면
      화면 이름이 따라 바뀐다(「지시문은 네가 쓰고 **사용자가 수정한다**」).
    ⚠ 그 언어에 없으면 영어로 떨어진다(`prompts` 와 같은 규칙).
    ⚠ **없는 줄은 씨앗 표에서 메운다** — 사용자가 지워도 화면에서 자리가 사라지지
      않는다(축은 늘 고를 수 있어야 한다 · 지우는 것은 지시문이지 자리가 아니다).
    """
    ax = _axis_key(axis)
    if not (AXIS_KINDS.get(ax) or []):
        return []
    ensure_seeds(conn)
    kinds = axis_kinds(conn, ax)              # ★ 317차-14 — 숨긴 씨앗 빼고 · 내가 더한 것 잇고
    lg = (lang or 'KO').upper()
    got = {}
    for pid, kind, title, body, _g in prompts(conn, lg, 'AXIS'):
        got[kind] = (title, body, pid)
    out = []
    for k in kinds:
        if k in got:
            t, b, _ = got[k]
        elif k in SEED_AXIS:
            seed = SEED_AXIS.get(k) or {}
            t, b = seed.get(lg) or seed.get('EN') or (k, '')
        else:                                             # 내가 더한 항목 — 쓴 언어의 줄
            r = conn.execute("SELECT title, body FROM user_ai_prompt WHERE scope='AXIS' AND kind=?"
                             " AND record_status='LIVE' ORDER BY prompt_id LIMIT 1", (k,)).fetchone()
            t, b = (r[0], r[1]) if r else (k, '')
        out.append((k, t, b))
    return out


def axis_prompt_id(conn, kind, lang='KO'):
    """그 축 값의 프롬프트 번호 — 고치는 화면이 쓴다(없으면 `None`)."""
    for pid, k, _t, _b, _g in prompts(conn, lang, 'AXIS'):
        if k == kind:
            return pid
    r = conn.execute("SELECT prompt_id FROM user_ai_prompt WHERE scope='AXIS' AND kind=? AND record_status='LIVE'"
                     " ORDER BY (lang_code=?) DESC, prompt_id LIMIT 1", (kind, (lang or 'KO').upper())).fetchone()
    return r[0] if r else None


def get_free(conn):
    """자유 프롬프트 — 어떤 항목을 선택해도 함께 나가는 사용자의 추가 지시."""
    return (get_setting(conn, 'AI_FREE', '') or '').strip()


def set_free(conn, text):
    """자유 프롬프트를 적는다(빈 글이면 지운다 — 빈 값을 남기지 않는다)."""
    set_setting(conn, 'AI_FREE', (text or '').strip())
    return True


def get_ban(conn):
    """금지사항 — 사용자가 적어 둔 **하지 말 것**(구절·용어·연구자료 공통).

    ★★★ 312차 사용자 「출력서식 위에 금지사항 항목을 만들자. **구절/용어/연구자료
      공통적용.** 예) 다른 자료의 내용을 무단 복사하지 말것…」.
    ★ 「공통적용」은 저절로 성립한다 — 자유 프롬프트·출력서식과 같이 **`user_config`
      열쇠 하나**에 담으므로 갈래(구절·용어·연구자료)를 가리지 않는다.
    ⚠ 출력서식과 몫이 다르다 — 이것은 「무엇을 **하지 말라**」이고 그것은
      「어떤 **모양으로** 내놓나」다. 그래서 칸을 합치지 않았다.
    ⚠ **기본값 씨앗을 넣지 않는다** — 자유 프롬프트·출력서식과 같은 규칙이다
      (사용자가 적은 것만 나간다 §0-1).
    """
    return (get_setting(conn, 'AI_BAN', '') or '').strip()


def set_ban(conn, text):
    """금지사항을 적는다(빈 글이면 지운다 — 빈 값을 남기지 않는다)."""
    set_setting(conn, 'AI_BAN', (text or '').strip())
    return True


def get_fmt(conn):
    """출력서식 — 사용자가 적어 둔 **답의 모양 본보기**(어떤 항목을 선택해도 함께 나간다).

    ⚠ 자유 프롬프트와 몫이 다르다 — 자유는 「무엇을 더 묻나」이고 이것은
      「어떤 모양으로 내놓나」다. 그래서 보낼 글에서도 **맨 뒤**에 선다.
    """
    return (get_setting(conn, 'AI_FORMAT', '') or '').strip()


def set_fmt(conn, text):
    """출력서식을 적는다(빈 글이면 지운다 — 빈 값을 남기지 않는다)."""
    set_setting(conn, 'AI_FORMAT', (text or '').strip())
    return True


def axis_bodies(conn, lang='KO', depth=None, view=None, faith=None):
    """선택한 축의 지시문 — `[상태, 신앙 배경, 관점]`(빈 것은 안 담는다).

    ⚠ 인자를 주면 그것을, 안 주면 저장값을 쓴다(화면이 미리보기에 쓴다).
    ⚠ `depth` 는 옛 이름이다 — 「상태」를 뜻한다(317차).
    """
    out = []
    for ax, want in (('STATE', depth), ('FAITH', faith), ('VIEW', view)):
        k = (want or '').strip().upper() or get_axis(conn, ax)
        if not k:
            continue
        for kind, _t, body in axis_rows(conn, ax, lang):
            if kind == k and (body or '').strip():
                out.append(body.strip())
                break
    return out


def _axis_key(axis):
    ax = (axis or '').upper()
    return AXIS_ALIAS.get(ax, ax)


def get_axis(conn, axis):
    """선택한 값 — 없거나 모르는 값이면 **기본**(상태·신앙 배경 = 선택 안 함 · 관점 = 중립).

    ★ 317차 — 옛 「깊이」 설정(`AI_DEPTH`)은 **읽을 때** 새 상태로 옮긴다
      (설교자 → 목사). 저장값은 안 고친다(§258차 ⑰ 그 원칙).
    """
    ax = _axis_key(axis)
    keys = {a[0]: a[1] for a in AXES}
    if ax not in keys:
        return ''
    v = (get_setting(conn, keys[ax], '') or '').strip().upper()
    if not v and ax == 'STATE':
        old = (get_setting(conn, 'AI_DEPTH', '') or '').strip().upper()
        v = DEPTH_TO_STATE.get(old, '')
    return v if v in axis_kinds(conn, ax) else AXIS_DEFAULT.get(ax, '')


def set_axis(conn, axis, kind):
    """선택한 값을 적는다 — **모르는 값은 안 적는다**(화면이 거짓말하지 않게)."""
    ax = _axis_key(axis)
    keys = {a[0]: a[1] for a in AXES}
    if ax not in keys or kind not in axis_kinds(conn, ax):
        return False
    set_setting(conn, keys[ax], kind)
    return True


def _migrate_axes(conn):
    """옛 깊이 줄(D_*)의 글을 새 상태 줄(S_*)로 옮긴다 — **사람이 고친 글도 산다**.

    ⚠ 이미 S_ 줄이 있으면 안 건드린다(멱등) · D_ 줄은 지우지 않는다(되돌릴 자리).
    """
    have = {(r[0], r[1]) for r in conn.execute(
        "SELECT lang_code, kind FROM user_ai_prompt WHERE scope='AXIS'")}
    n = 0
    for old, new in DEPTH_TO_STATE.items():
        for lg, body in conn.execute(
                "SELECT lang_code, body FROM user_ai_prompt WHERE kind=? AND scope='AXIS'",
                (old,)).fetchall():
            if (lg, new) in have:
                continue
            seed = (SEED_AXIS.get(new) or {}).get(lg) or (SEED_AXIS.get(new) or {}).get('EN')
            title = seed[0] if seed else new
            conn.execute("INSERT INTO user_ai_prompt(lang_code, kind, title, body, sort_order,"
                         " scope, genre) VALUES(?,?,?,?,?,'AXIS',?)",
                         (lg, new, title, body or (seed[1] if seed else ''),
                          AXIS_ALL.index(new) * 10, GENRE_DEFAULT))
            n += 1
    return n


def get_part(conn, part):
    """내용과 형식 한 칸(문체·반드시·성경인용·분량·예시·금지·출력서식) — 적은 글.

    ★ 성경인용은 비어 있으면 **고른 역본으로 저절로** 채운 글을 낸다(`cite_default`) —
      AI 가 구절을 제 손으로 옮기는 일을 줄인다(관리자 쪽 실측 문제). 사용자가 적으면 그 글.
    """
    p = (part or '').upper()
    if p not in PART_KEY:
        return ''
    v = (get_setting(conn, PART_KEY[p], '') or '').strip()
    if not v and p == 'CITE':
        v = cite_default(conn)
    return v


def set_part(conn, part, text):
    p = (part or '').upper()
    if p not in PART_KEY:
        return False
    set_setting(conn, PART_KEY[p], (text or '').strip())
    return True


CITE_TPL = {
    'KO': '성경 구절은 {v}에서 글자 그대로 인용하고 장과 절을 밝혀 주세요. 직접 번역해 인용하지 마세요.',
    'EN': 'Quote Bible verses word for word from {v}, giving chapter and verse. Do not make your own translation.',
    'JA': '聖書の箇所は{v}から一字一句そのまま引用し、章と節を示してください。自分で訳して引用しないでください。',
    'ZH': '请从{v}逐字引用经文，并注明章节。不要自行翻译引用。',
    'ZHT': '請從{v}逐字引用經文，並註明章節。不要自行翻譯引用。',
    'DE': 'Zitiere Bibelverse wörtlich aus {v} mit Kapitel und Vers. Übersetze nicht selbst.',
    'FR': 'Cite les versets mot pour mot dans {v}, avec chapitre et verset. Ne fais pas ta propre traduction.',
    'ES': 'Cita los versículos palabra por palabra de {v}, con capítulo y versículo. No hagas tu propia traducción.',
    'PT': 'Cite os versículos palavra por palavra de {v}, com capítulo e versículo. Não faça a sua própria tradução.',
    'RU': 'Приводи стихи дословно по {v}, указывая главу и стих. Не переводи сам.',
    'AR': 'اقتبس الآيات حرفيًا من {v} مع ذكر الإصحاح والآية. لا تترجم بنفسك.',
}


#: ★ 2026-10-20 (docs/1.txt 8-3) 사용자 성경버전 자리표 — 보낼 때 그 기기에 설정한 역본 이름으로 바뀐다
#:   (「개역한글」을 프롬프트에 적으면 하드코딩이 된다 · 폰은 폰의 역본으로 채운다)
VERSION_TOKENS = ('[성경버전]', '[Bible version]')


def version_label(conn):
    """설정한 역본 이름 — 「개역한글 (KRV)」 꼴 · 못 읽으면 빈 글."""
    try:
        code = (get_setting(conn, 'BIBLE_VERSION', '') or '').strip()
        if not code:
            return ''
        r = conn.execute("SELECT COALESCE(NULLIF(display_name,''), version_name) FROM bible_version"
                         " WHERE version_code=?", (code,)).fetchone()
        return ('%s (%s)' % (r[0], code)) if r and r[0] else code
    except Exception:                                     # noqa: BLE001
        return ''


#: ★ 2026-10-21 사용자 「사회현상 프롬프트에 국가/사회 값을 사용자마다 자동으로 · 언어코드 = 국가코드라고 전제」 —
#:   [국가] 자리표는 보낼 때 그 사용자 언어의 나라 이름(그 나라 말)으로 바뀐다 · `AI_COUNTRY` 에 적으면 그것이 이긴다.
#:   ⚠ 언어 하나가 여러 나라인 곳은 전제대로 하나를 골랐다(EN 미국 · PT 포르투갈 · ES 스페인) · AR 은 나라 코드가
#:     아르헨티나라 맞지 않아 「아랍 세계」로 둔다.
COUNTRY_TOKENS = ('[국가]', '[Country]')
COUNTRY_OF = {'KO': '대한민국', 'EN': 'the United States', 'JA': '日本', 'ZH': '中国', 'ZHT': '台灣',
              'DE': 'Deutschland', 'FR': 'France', 'ES': 'España', 'PT': 'Portugal', 'RU': 'Россия',
              'AR': 'العالم العربي'}


#: ★ 2026-10-21 [오늘] 자리표 — AI 는 오늘이 며칠인지 모른다(「최근 이슈」·절기가 옛 날짜로 간다) ⇒ 보낼 때 그 언어 날짜로
DATE_TOKENS = ('[오늘]', '[Today]')
_WD = {'KO': '월화수목금토일', 'JA': '月火水木金土日', 'ZH': '一二三四五六日', 'ZHT': '一二三四五六日'}
_WD_EN = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
_MON_EN = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October',
           'November', 'December']


def date_label(lang='KO', when=None):
    """오늘 날짜를 그 언어 꼴로 — KO 「2026년 10월 21일 (화)」 · JA·ZH 「2026年10月21日（火）」 · 그 밖 ISO + 요일(영어)."""
    import datetime as _dt
    d = when or _dt.date.today()
    lg = (lang or 'KO').upper()
    w = d.weekday()
    if lg == 'KO':
        return '%d년 %d월 %d일 (%s)' % (d.year, d.month, d.day, _WD['KO'][w])
    if lg in ('JA', 'ZH', 'ZHT'):
        return '%d年%d月%d日（%s）' % (d.year, d.month, d.day, ('星期' if lg != 'JA' else '') + _WD[lg][w])
    if lg == 'EN':
        return '%s, %s %d, %d' % (_WD_EN[w], _MON_EN[d.month - 1], d.day, d.year)
    return '%s (%s)' % (d.isoformat(), _WD_EN[w])


def country_label(conn, lang=None):
    own = (get_setting(conn, 'AI_COUNTRY', '') or '').strip()
    if own:
        return own
    lg = (lang or get_setting(conn, 'LANG', '') or 'KO').upper()
    return COUNTRY_OF.get(lg) or COUNTRY_OF['EN']


def context_line(conn, lang=None):
    """★ 2026-10-22 「오늘 · 나라」 한 줄 — 시스템 글에 한 번 보낼 때 한 번 붙는다(사용자 「모든 프롬프트에 넣어야 하는 것이라면
    자동으로 넣어라」). [오늘]·[국가] 자리표는 옛 프롬프트를 위해 그대로 작동한다. 폰 `AiRepo.contextLine` 과 같은 꼴."""
    lg = (lang or 'KO').upper()
    return '[오늘 · 나라] %s · %s' % (date_label(lg), country_label(conn, lg))


def fill_version(conn, text, lang=None):
    """사용자마다 다른 자리표를 채운다 — [성경버전] = 설정한 역본 · [국가] = 그 사용자의 나라 · [오늘] = 오늘 날짜."""
    if any(t in (text or '') for t in DATE_TOKENS):
        d_ = date_label(lang or get_setting(conn, 'LANG', '') or 'KO')
        for t in DATE_TOKENS:
            text = text.replace(t, d_)
    if any(t in (text or '') for t in COUNTRY_TOKENS):
        c_ = country_label(conn, lang)
        for t in COUNTRY_TOKENS:
            text = text.replace(t, c_)
    if not any(t in (text or '') for t in VERSION_TOKENS):
        return text
    lbl = version_label(conn)
    if not lbl:
        return text
    for t in VERSION_TOKENS:
        text = text.replace(t, lbl)
    return text


def cite_default(conn, lang=None, token=False):
    """선택한 역본(`BIBLE_VERSION`)으로 지은 「성경 인용」 기본 문장 — 못 읽으면 빈 글.
    ★ 2026-10-20 `token` — 역본 이름 대신 [성경버전] 자리표(폰 꾸러미 · 폰이 제 역본으로 채운다)."""
    try:
        code = (get_setting(conn, 'BIBLE_VERSION', '') or '').strip()
        if not code and not token:
            return ''
        r = conn.execute("SELECT COALESCE(NULLIF(display_name,''), version_name), lang_code"
                         " FROM bible_version WHERE version_code=?", (code,)).fetchone()
        name = ('%s (%s)' % (r[0], code)) if r and r[0] else code
        if token:
            name = VERSION_TOKENS[0]
        lg = (lang or get_setting(conn, 'AI_LANG', '') or (r[1] if r else '') or 'KO').upper()
        return (CITE_TPL.get(lg) or CITE_TPL['EN']).format(v=name)
    except Exception:                                     # noqa: BLE001
        return ''


def tasks_for(scope, conn=None):
    """그 갈래가 선택할 수 있는 업무 — Free 는 빈 목록이다.

    ★ 317차-14 — `conn` 을 주면 **사용자가 더한 업무**(`UT_n`)를 뒤에 잇는다(`user_tasks`).
    """
    sc = (scope or 'VERSE').upper()
    out = list(TASKS_OF.get(sc, []))
    if conn is not None and sc != 'FREE':
        out += [u['key'] for u in user_tasks(conn) if sc in u.get('scopes', [])]
        # ★ 2026-10-21 (AI도우미.txt 3) 라이브러리에서 숨긴 앱 질문프롬프트는 빠진다(되살릴 수 있다)
        hid = set(hidden_tasks(conn))
        out = [t for t in out if '%s:%s' % (sc, t) not in hid]
    return out


TASK_HIDDEN_KEY = 'AI_TASK_HIDDEN'      # ["VERSE:LINKAN", ...] — 숨긴 앱 질문프롬프트


def hidden_tasks(conn):
    try:
        v = json.loads(get_setting(conn, TASK_HIDDEN_KEY, '') or '[]')
        return [str(x) for x in v] if isinstance(v, list) else []
    except Exception:                                     # noqa: BLE001
        return []


def set_task_hidden(conn, scope, task, hide=True):
    """앱 질문프롬프트를 숨기거나 되살린다(글은 그대로 · 내 질문프롬프트 `UT_` 는 `hide_user_task`)."""
    k = '%s:%s' % ((scope or '').upper(), (task or '').upper())
    h = [x for x in hidden_tasks(conn) if x != k]
    if hide:
        h.append(k)
    set_setting(conn, TASK_HIDDEN_KEY, json.dumps(h, ensure_ascii=False))
    if hide and (get_setting(conn, 'AI_TASK_' + scope.upper(), '') or '').upper() == task.upper():
        set_setting(conn, 'AI_TASK_' + scope.upper(), '')
    return True


# ══════════════════════════════════════════════════════════════════════
#  317차-14 — 업무 · 사용자 목록 · 내용과 형식을 **사용자가 늘리고 줄인다**
#  (docs/1.txt 2-5)(2) 「업무 프롬프트의 제목과 내용 자체를 추가/수정/삭제 · 콤보상자 목록 자체도 ·
#   내용과 형식 프롬프트 자체도 · 이런 관리기능이 가운데 화면에서」)
# ══════════════════════════════════════════════════════════════════════
USER_TASK_KEY = 'AI_USER_TASKS'          # [{"key": "UT_3", "scopes": ["VERSE"]}]
AXIS_HIDDEN_KEY = 'AI_AXIS_HIDDEN'       # 숨긴 씨앗 항목 ["S_PWIFE", ...]
AXIS_USER_PFX = {'STATE': 'US_', 'FAITH': 'UF_', 'VIEW': 'UV_'}
PART_ALL = ['FREE'] + [pp for pp, _k in PARTS]


def _jget(conn, key, default):
    try:
        v = json.loads(get_setting(conn, key, '') or 'null')
        return v if v is not None else default
    except Exception:                                     # noqa: BLE001
        return default


def _jset(conn, key, val):
    set_setting(conn, key, json.dumps(val, ensure_ascii=False, sort_keys=True))


def user_tasks(conn):
    """사용자가 더한 업무 — `[{'key','scopes'}]`(지운 것은 목록에서 빠진다)."""
    out = []
    for u in _jget(conn, USER_TASK_KEY, []) or []:
        if isinstance(u, dict) and str(u.get('key', '')).startswith('UT_'):
            out.append({'key': u['key'], 'scopes': [str(x).upper() for x in (u.get('scopes') or [])]})
    return out


def _next_no(conn, pfx):
    n = 0
    for (k,) in conn.execute("SELECT DISTINCT kind FROM user_ai_prompt WHERE kind LIKE ?", (pfx + '%',)):
        try:
            n = max(n, int(str(k)[len(pfx):]))
        except Exception:                                 # noqa: BLE001
            pass
    return n + 1


def put_task_text(conn, kind, lang, body=None, title=None):
    """업무·역할 줄을 그 언어에 적는다 — 줄이 없으면 만든다(영어 줄을 안 덮는다) · 준 것만 바꾼다."""
    lg = (lang or 'KO').upper()
    r = conn.execute("SELECT prompt_id, title, body FROM user_ai_prompt WHERE kind=? AND lang_code=?"
                     " AND scope='TASK' AND record_status='LIVE' ORDER BY prompt_id LIMIT 1",
                     (kind, lg)).fetchone()
    if r:
        conn.execute("UPDATE user_ai_prompt SET title=?, body=? WHERE prompt_id=?",
                     (r[1] if title is None else title, r[2] if body is None else body, r[0]))
    else:
        _pid, t0, b0 = task_row(conn, kind, lg)
        conn.execute("INSERT INTO user_ai_prompt(lang_code, kind, title, body, sort_order, scope, genre)"
                     " VALUES(?,?,?,?,?,'TASK','ANAL')",
                     (lg, kind, t0 if title is None else title, b0 if body is None else body,
                      (TASK_ALL.index(kind) if kind in TASK_ALL else 90) * 10))
    conn.commit()


def add_user_task(conn, scope, lang, title, body='', role=None):
    """내 업무를 더한다 — `UT_n`(할 일) · `UR_n`(역할 · 비우면 공통 역할 글) · 그 갈래에 잇는다.

    ⚠ 내 업무는 **일반 업무**다 — 설명문 칸 나누기·묵상분석 저장 같은 특수 저장은 앱에 있는 업무만 한다
      (저장할 곳은 갈래가 정한다 · `saves_for`).
    """
    sc = (scope or 'VERSE').upper()
    if sc == 'FREE':
        return ''
    n = _next_no(conn, 'UT_')
    key = 'UT_%d' % n
    put_task_text(conn, key, lang, body=body or '', title=title or key)
    put_task_text(conn, 'UR_%d' % n, lang, body=(role if role is not None else task_row(conn, ROLE_KIND, lang)[2]),
                  title=title or key)
    us = user_tasks(conn)
    us.append({'key': key, 'scopes': [sc]})
    _jset(conn, USER_TASK_KEY, us)
    return key


def hide_user_task(conn, key):
    """내 업무를 지운다(HIDE · 되돌릴 자리) — 앱에 있는 업무는 지우지 않는다."""
    if not str(key).startswith('UT_'):
        return False
    conn.execute("UPDATE user_ai_prompt SET record_status='HIDE' WHERE kind IN (?,?)",
                 (key, 'UR_' + key[3:]))
    conn.commit()
    _jset(conn, USER_TASK_KEY, [u for u in user_tasks(conn) if u['key'] != key])
    for sc in TASKS_OF:
        if (get_setting(conn, 'AI_TASK_' + sc, '') or '').upper() == key:
            set_setting(conn, 'AI_TASK_' + sc, '')
    return True


def task_label(conn, scope, task, lang, default=''):
    """업무 단추 이름 — 내 업무는 그 이름 · 앱 업무는 **사람이 이름을 고쳤을 때만** 그 이름(아니면 `default`)."""
    t = (task or '').upper()
    if t.startswith('UT_'):
        return task_row(conn, t, lang)[1] or default or t
    if t == 'RESEARCH':
        return default
    k = task_kind(scope, t)
    return kind_label(conn, k, lang, default)


def task_ui_ko(scope, task):
    """질문프롬프트 단추의 처음 이름(한국어) — 화면 글자(`AI_T2_*`)가 없을 때."""
    vt = 'T' if (scope or '').upper() == 'TERM' else 'V'
    w = '용어' if vt == 'T' else '구절'
    return {'DESC': ('이 %s의 설명문을 작성해줘' % w) if vt == 'T' else '이 구절의 일반설명문을 작성해줘',
            'XDESC': '이 구절의 전문설명문을 작성해줘', 'LINKAN': '이 연결을 살펴보자',
            'RESEARCH': '이 %s%s 연구하자' % (w, '를' if vt == 'T' else '을'),
            'NOTE': '나의 묵상노트를 분석해줘', 'REFAN': '내 연구노트를 분석해줘',
            'SERMAN': '내 설교노트를 분석해줘', 'SERMWR': '설교노트로 다시 쓰기', 'TEACH': 'AI 성경교사', 'BOOKMEDI': '도서 묵상',
            'SERMON': '설교작성을 도와줘', 'ASK': '이 %s에 대해 질문하기' % w,
            'STUDY': '이 %s로 성경공부 자료 만들기' % w, 'TERMAN': '이 용어의 설명문 분석',
            'RT_PASTOR': '목회 도움말', 'RT_MISSION': '선교 도움말', 'RT_PWIFE': '사모 도움말',
            **{'RT_' + _c[2:]: '%s 도움말' % _v[0] for _c, _v in LAY_WHO.items()}}.get(
        (task or '').upper(), task or '')


#: ★ 2026-10-27 (사용자 「PC Free → 홈 AI대화 · 그 내부에 Free」) — 홈 AI 대화 갈래(옛 Free)의 업무 = 라이브러리 자리.
#:   폰 홈 AI 대화(AiRepo.homePlaces + Free)와 같은 다섯 · 업무 글은 그 자리의 TASK 항목 · Pick 은 그 자리의 PICK.
HOME_TASKS = ('HOME_MEDI', 'HOME_STUDY', 'HOME_SOCIAL', 'NEWS', 'FREE')
HOME_PLACE = {'HOME_MEDI': 'HOME:MEDI', 'HOME_STUDY': 'HOME:STUDY', 'HOME_SOCIAL': 'HOME:SOCIAL',
              'NEWS': 'NEWS', 'FREE': 'VERSE:FREE', 'HOME_FIND': 'HOME:FIND'}
#: ★ 2026-10-31 AI 대화 그룹 넷(Free · 세상 · 자료 · 말씀) — 세상 = 사회현상·뉴스 · 말씀 = 프롬프트 여섯(폰 AiRepo.wordOrder 와 같은 차례)
WORLD_TASKS = ('HOME_SOCIAL', 'NEWS')
WORD_TASKS = ('ASK', 'HOME_MEDI', 'STUDY', 'TEACH', 'SERMON', 'HOME_FIND')
#: 말씀 그룹 프롬프트 이름 — 대화하듯(재료가 구절이 아닐 수도 있어 「이 말씀」)
WORD_LABELS = {'ASK': ('M_AIW_ASK', '이 말씀에 대해 질문할게요'), 'HOME_MEDI': ('M_AIW_MEDI', '이 말씀을 함께 묵상해줘'),
               'STUDY': ('M_AIW_STUDY', '성경공부 자료를 만들어줘'), 'TEACH': ('M_AIW_TEACH', 'AI가 먼저 질문해줘'),
               'SERMON': ('M_AIW_SERMON', '설교 준비를 도와줘'), 'HOME_FIND': ('M_AIW_FIND', '이럴 때 맞는 구절을 찾아줘')}
WORD_MAT_NAME = '내가 넣은 내용'


def word_title(conn, task, lang='KO'):
    """말씀 그룹 프롬프트 이름(폰과 같은 글) — 화면 글자 > 처음 이름."""
    nk, ko = WORD_LABELS[task]
    return _ui_label(conn, nk, lang) or ko


def home_title(conn, task, lang='KO'):
    """홈 AI 대화 업무 이름 — 라이브러리 자리 이름(Free 는 화면 글자)."""
    t = (task or '').upper()
    if t == 'FREE':
        return _ui_label(conn, 'M_AI_FREE', lang) or 'Free 대화'
    if t.startswith('UT_'):                                # ★ 2026-10-28 내가 더한 홈 질문프롬프트
        return task_row(conn, t, lang)[1] or t
    try:
        import ai_lib
        for k, _grp, name in ai_lib.PLACES:
            if k == HOME_PLACE.get(t):
                return name
    except Exception:                                     # noqa: BLE001
        pass
    return t


def home_task_body(conn, task, lang='KO'):
    """홈 AI 대화 업무 글 — 그 자리의 TASK 항목(없으면 '')."""
    t = (task or '').upper()
    lib = _lib(conn)
    if lib is None or t == 'FREE' or t not in HOME_PLACE:
        return ''
    try:
        rows = lib.place_rows(conn, HOME_PLACE[t], (lang or 'KO').upper(), 'TASK')
        return (rows[0][3] or '').strip() if rows else ''
    except Exception:                                     # noqa: BLE001
        return ''


def task_title(conn, scope, task, lang):
    """★ 2026-10-21 (AI도우미.txt 5) 질문프롬프트 이름 **하나** — AI 도우미 왼쪽 칸 · 라이브러리 · 폰이 모두 이것을 쓴다.
    사람이 고친 이름 > 화면 글자(그 언어 · `AI_T2_*`) > 처음 이름(한국어). 내 질문프롬프트는 그 이름."""
    t = (task or '').upper()
    if t.startswith('UT_'):
        return task_row(conn, t, lang)[1] or t
    d = _ui_task_name(conn, scope, t, lang) or task_ui_ko(scope, t)
    return task_label(conn, scope, t, lang, d) or d


def is_title_default(conn, scope, task, lang, title):
    """그 이름이 화면이 저절로 보이는 이름(고치지 않은 것)인가 — 라이브러리 저장이 「고친 이름」으로 굳히지 않게."""
    t = (task or '').upper()
    if t.startswith('UT_') or t == 'RESEARCH':
        return False
    return (title or '').strip() == (_ui_task_name(conn, scope, t, lang) or task_ui_ko(scope, t)).strip()


def kind_label(conn, kind, lang, default=''):
    if not kind:
        return default
    _pid, title, _b = task_row(conn, kind, lang)
    sd = SEED_TASK.get(kind) or SEED_ROLE.get(kind) or {}
    seed = (sd.get((lang or 'KO').upper()) or sd.get('EN') or ('', ''))[0]
    return title if (title and title != seed) else default


def reset_task(conn, kind, lang):
    """앱 업무 줄을 씨앗 글(이름·내용)로 되돌린다 — 그 언어만."""
    sd = SEED_TASK.get(kind) or SEED_ROLE.get(kind) or {}
    seed = sd.get((lang or 'KO').upper()) or sd.get('EN')
    if not seed:
        return False
    put_task_text(conn, kind, lang, body=seed[1], title=seed[0])
    return True


# ── 사용자(상태 · 신앙 배경 · 관점) 목록 ─────────────────────────────
def axis_kinds(conn, axis):
    """그 축의 항목 — 숨기지 않은 씨앗 + 사용자가 더한 것(`US_`·`UF_`·`UV_`). 기본 항목은 숨길 수 없다."""
    ax = _axis_key(axis)
    base = AXIS_KINDS.get(ax) or []
    hidden = set(_jget(conn, AXIS_HIDDEN_KEY, []) or [])
    keep = [k for k in base if k not in hidden or k == AXIS_DEFAULT.get(ax)]
    pfx = AXIS_USER_PFX.get(ax)
    users = []
    if pfx:
        users = [r[0] for r in conn.execute(
            "SELECT kind FROM user_ai_prompt WHERE scope='AXIS' AND kind LIKE ? AND record_status='LIVE'"
            " GROUP BY kind ORDER BY MIN(prompt_id)", (pfx + '%',))]
    return keep + users


def axis_of_kind(kind):
    k = str(kind or '')
    for ax, kinds in AXIS_KINDS.items():
        if k in kinds or k.startswith(AXIS_USER_PFX.get(ax, '#')):
            return ax
    return ''


def add_axis_item(conn, axis, lang, title, body=''):
    ax = _axis_key(axis)
    pfx = AXIS_USER_PFX.get(ax)
    if not pfx:
        return ''
    kind = '%s%d' % (pfx, _next_no(conn, pfx))
    conn.execute("INSERT INTO user_ai_prompt(lang_code, kind, title, body, sort_order, scope, genre)"
                 " VALUES(?,?,?,?,?,'AXIS','ANAL')", ((lang or 'KO').upper(), kind, title or kind, body or '', 900))
    conn.commit()
    return kind


def hide_axis_item(conn, kind):
    """항목을 목록에서 뺀다 — 내가 더한 것은 HIDE · 씨앗은 숨김 목록 · **기본 항목은 못 뺀다**."""
    ax = axis_of_kind(kind)
    if not ax or kind == AXIS_DEFAULT.get(ax):
        return False
    if str(kind).startswith(AXIS_USER_PFX.get(ax, '#')):
        conn.execute("UPDATE user_ai_prompt SET record_status='HIDE' WHERE scope='AXIS' AND kind=?", (kind,))
        conn.commit()
    else:
        h = list(_jget(conn, AXIS_HIDDEN_KEY, []) or [])
        if kind not in h:
            h.append(kind)
        _jset(conn, AXIS_HIDDEN_KEY, h)
    keys = {a[0]: a[1] for a in AXES}
    if (get_setting(conn, keys[ax], '') or '').upper() == kind:
        set_setting(conn, keys[ax], AXIS_DEFAULT.get(ax, ''))
    return True


def restore_axis(conn, axis, kind=None, lang='KO'):
    """[기본으로] — 그 축의 숨긴 씨앗을 되살리고, 선택한 씨앗 항목의 이름·글을 씨앗으로 되돌린다(그 언어)."""
    ax = _axis_key(axis)
    base = set(AXIS_KINDS.get(ax) or [])
    _jset(conn, AXIS_HIDDEN_KEY, [k for k in (_jget(conn, AXIS_HIDDEN_KEY, []) or []) if k not in base])
    if kind and kind in base:
        seed = (SEED_AXIS.get(kind) or {}).get((lang or 'KO').upper()) or (SEED_AXIS.get(kind) or {}).get('EN')
        pid = axis_prompt_id(conn, kind, lang)
        if seed and pid:
            save_prompt(conn, pid, seed[0], seed[1])
    return True


# ── 내용과 형식 — 칸마다 **이름 붙인 여러 벌** · 하나를 쓴다 ───────────────
def part_raw(conn, part):
    p = (part or '').upper()
    if p == 'FREE':
        return get_free(conn)
    if p not in PART_KEY:
        return ''
    return (get_setting(conn, PART_KEY[p], '') or '').strip()


def part_put(conn, part, text):
    """쓰는 글을 그 칸의 열쇠에 적는다 — **보내는 쪽(`compose`)은 이 열쇠만 읽는다**(바뀌지 않는다)."""
    p = (part or '').upper()
    if p == 'FREE':
        return set_free(conn, text)
    if p == 'BAN':
        return set_ban(conn, text)
    if p == 'FORMAT':
        return set_fmt(conn, text)
    return set_part(conn, p, text)


def part_sets(conn, part):
    """`{'items': [{'name','body'}], 'on': i}` — 쓰는 벌의 글은 **열쇠의 글과 늘 같다**(열쇠가 정본)."""
    p = (part or '').upper()
    d = _jget(conn, 'AI_PSET_' + p, None)
    if not isinstance(d, dict) or not d.get('items'):
        d = {'items': [{'name': '', 'body': part_raw(conn, p)}], 'on': 0}
    on = int(d.get('on') or 0)
    if not 0 <= on < len(d['items']):
        on = 0
    d['on'] = on
    d['items'][on]['body'] = part_raw(conn, p)
    return d


def _pset_save(conn, part, d):
    _jset(conn, 'AI_PSET_' + (part or '').upper(), d)


def part_select(conn, part, i):
    d = part_sets(conn, part)
    if not 0 <= i < len(d['items']):
        return False
    if d['items'][i].get('multi'):                        # ★ 복수 서식은 하나 선택이 아니다 — 켜고 끈다
        part_check(conn, part, i)
        return True
    d['on'] = i
    _pset_save(conn, part, d)
    part_put(conn, part, d['items'][i].get('body', ''))
    return True


def part_add(conn, part, name, multi=False):
    d = part_sets(conn, part)
    if multi:                                             # ★ 복수 서식 — 하나 선택은 그대로
        d['items'].append({'name': name or '', 'body': '', 'multi': True})
        _pset_save(conn, part, d)
        return len(d['items']) - 1
    d['items'].append({'name': name or '', 'body': ''})
    d['on'] = len(d['items']) - 1
    _pset_save(conn, part, d)
    part_put(conn, part, '')
    return d['on']


def part_del(conn, part, i):
    """벌 하나를 지운다 — **마지막 하나는 못 지운다**(칸이 사라지면 안 된다)."""
    d = part_sets(conn, part)
    if len(d['items']) <= 1 or not 0 <= i < len(d['items']):
        return False
    d['items'].pop(i)
    d['checked'] = [x - (1 if x > i else 0) for x in (d.get('checked') or []) if x != i]
    if d['on'] >= len(d['items']) or d['on'] == i:
        d['on'] = 0
    elif d['on'] > i:
        d['on'] -= 1
    _pset_save(conn, part, d)
    part_put(conn, part, d['items'][d['on']].get('body', ''))
    return True


def part_write(conn, part, i, name=None, body=None):
    d = part_sets(conn, part)
    if not 0 <= i < len(d['items']):
        return False
    if name is not None:
        d['items'][i]['name'] = name
    if body is not None:
        d['items'][i]['body'] = body
    _pset_save(conn, part, d)
    if i == d['on'] and body is not None and not d['items'][i].get('multi'):
        part_put(conn, part, body)
    return True


def task_kind(scope, task, mode=None):
    """업무(+연구하자 갈래) → 프롬프트 줄 kind. 모르는 업무면 빈 글."""
    sc = (scope or 'VERSE').upper()
    t = (task or '').upper()
    if t.startswith('UT_'):
        return t                                          # ★ 317차-14 — 내 업무는 제 줄
    if t == 'RESEARCH' and sc in ('VERSE', 'TERM'):       # ★ 2026-10-16 옛 열쇠(옛 채팅) → 구절질문/성경공부
        t = 'STUDY' if (mode or '').upper() == 'STUDY' else 'ASK'
    if t not in tasks_for(sc):
        return ''
    if t == 'DESC':
        return TASK_KIND.get(('DESC', 'TERM' if sc == 'TERM' else 'VERSE'), '')
    if t == 'RESEARCH':
        m = (mode or '').upper()
        return TASK_KIND.get(('RESEARCH', m if m in RESEARCH_MODES else RESEARCH_MODES[0]), '')
    return TASK_KIND.get(t, '')


def get_task(conn, scope):
    """그 갈래에서 선택한 업무 — 없거나 그 갈래에 없는 값이면 **첫 업무**(Free 는 빈 글)."""
    sc = (scope or 'VERSE').upper()
    ts = tasks_for(sc, conn)
    v = (get_setting(conn, 'AI_TASK_' + sc, '') or '').strip().upper()
    return v if v in ts else (ts[0] if ts else '')


def set_task(conn, scope, task):
    sc = (scope or 'VERSE').upper()
    if (task or '').upper() not in tasks_for(sc, conn):
        return False
    set_setting(conn, 'AI_TASK_' + sc, task.upper())
    return True


def get_rmode(conn):
    v = (get_setting(conn, 'AI_RMODE', '') or '').strip().upper()
    return v if v in RESEARCH_MODES else RESEARCH_MODES[0]


def set_rmode(conn, mode):
    if (mode or '').upper() not in RESEARCH_MODES:
        return False
    set_setting(conn, 'AI_RMODE', mode.upper())
    return True


def task_row(conn, kind, lang='KO'):
    """업무 줄 하나 — `(prompt_id, 이름, 글)`. 그 언어 → 영어 → 씨앗 차례로 떨어진다."""
    if not kind:
        return (None, '', '')
    ensure_seeds(conn)
    for lg in ((lang or 'KO').upper(), 'EN'):
        r = conn.execute("SELECT prompt_id, title, body FROM user_ai_prompt WHERE kind=?"
                         " AND lang_code=? AND scope='TASK' AND record_status='LIVE'"
                         " ORDER BY prompt_id LIMIT 1", (kind, lg)).fetchone()
        if r:
            return (r[0], r[1] or '', r[2] or '')
    sd = SEED_TASK.get(kind) or SEED_ROLE.get(kind) or {}
    s = sd.get((lang or 'KO').upper()) or sd.get('EN') or ('', '')
    return (None, s[0], s[1])


#: ★★★ 317차-5 — **역할은 업무마다**(docs/1.txt 2-6)(4)가) 「업무 유형별 AI의 역할과 할일 …
#:   각 업무별로 차별화하여 작성」). 줄 kind = `R_<업무>` · 없으면 공통 역할(`T_ROLE`)로 떨어진다.
ROLE_OF_TASK = {t: 'R_' + t for t in ('DESC', 'XDESC', 'RESEARCH', 'SERMON', 'NOTE', 'TEACH', 'REFAN', 'SERMAN', 'SERMWR', 'BOOKMEDI', 'LINKAN', 'FIGURE',
                                       'ASK', 'STUDY', 'TERMAN', 'PLACEAN', 'ERAAN')}
_R = {
 'DESC': ('역할', '당신은 성경 본문을 정확하게 풀어 쓰는 설명문 작가입니다. 본문에 근거해 평신도가 읽기 쉬운 글을 씁니다.',
          'You are a writer of Bible explanations who expounds the text accurately. Grounded in the text, you write so that lay readers can follow easily.'),
 'XDESC': ('역할', '당신은 성경 본문을 깊이 연구해 풀어 쓰는 전문 설명문 작가입니다. 원어와 문맥, 배경과 다른 구절과의 연결을 근거와 함께 밝히되, 개신교 안의 여러 교단이 함께 읽을 수 있게 씁니다.',
           'You are a writer of in-depth Bible explanations. You set out the original language, context, background and links to other passages with evidence, writing so that readers from the various Protestant traditions can all use it.'),
 'LINKAN': ('역할', '당신은 성경의 두 본문이 어떻게 이어지는지 살피는 성경 교사입니다. 두 본문에 실제로 있는 낱말과 사건, 주제에 근거해서만 잇고 억지로 잇지 않습니다.',
            'You are a Bible teacher who examines how two passages of Scripture are connected. You link them only on the basis of words, events and themes actually in both texts, never forcing a connection.'),
 'RESEARCH': ('역할', '당신은 사용자와 함께 본문을 연구하는 성경 교사입니다. 물음에 정직하게 답하고 근거가 되는 구절을 함께 보입니다.',
              'You are a Bible teacher who studies the text together with the user. You answer honestly and show the verses that support your answer.'),
 'ASK': ('역할', '당신은 성경 질문에 대화하듯 답하는 성경 교사입니다. 묻는 것에 바로 답하고, 근거 구절을 함께 보이되 짧고 분명하게 말합니다.',
         'You are a Bible teacher who answers questions about Scripture conversationally. You answer what is asked directly and show the supporting verses, briefly and clearly.'),
 'STUDY': ('역할', '당신은 개인과 소그룹이 함께 쓸 성경공부 자료를 만드는 성경 교사입니다. 본문에 근거해 차례가 분명한 자료를 만듭니다.',
           'You are a Bible teacher who prepares Bible study material for individuals and small groups. Grounded in the text, you make material with a clear order.'),
 'PLACEAN': ('역할', '당신은 성경의 장소와 그 역사를 함께 살피는 성경 교사입니다. 성경이 적은 것과 성경 밖의 역사·고고학을 구분하고, 확인된 것과 추정을 나누어 말하며, 근거로 삼은 자료의 이름을 밝힙니다.',
             'You are a Bible teacher who explores the places of Scripture and their history. You separate what the Bible records from history and archaeology outside it, distinguish the established from the conjectured, and name the sources you rely on.'),
 'ERAAN': ('역할', '당신은 성경의 사건을 그 시대의 세계사 속에서 함께 읽는 성경 교사입니다. 성경이 적은 것과 성경 밖의 역사를 구분하고, 연대 학설이 갈리면 그렇다고 말하며, 근거로 삼은 자료의 이름을 밝힙니다.',
           'You are a Bible teacher who reads biblical events within the world history of their time. You separate what the Bible records from history outside it, say so when the dating is disputed, and name the sources you rely on.'),
 'FIGURE': ('역할', '당신은 성경 인물의 삶을 함께 읽는 성경 교사입니다. 성경 본문에 적힌 것과 추론을 구분하고, 한 인물을 영웅이나 악인으로 단정하지 않으며, 오늘의 신자에게 닿는 자리까지 함께 생각합니다.',
            'You are a Bible teacher who reads the lives of biblical people together with the user. You separate what the text records from inference, do not reduce a person to a hero or a villain, and think through to where the story touches believers today.'),
 'TERMAN': ('역할', '당신은 성경 낱말의 설명문을 검토하는 성경 교사입니다. 글을 대신 쓰지 않고 근거를 들어 짚어 줍니다.',
            'You are a Bible teacher who reviews descriptions of biblical terms. You do not rewrite the text; you point things out with reasons.'),
 'NOTE': ('역할', '당신은 사용자의 묵상노트를 읽고 함께 생각하는 신앙의 동역자입니다. 노트에 적힌 것을 존중하고 본문에 비추어 짚어 줍니다.',
          'You are a companion in faith who reads the user\'s meditation notes and thinks with them. You respect what is written and reflect on it in the light of the text.'),
 'TEACH': ('역할', '당신은 질문으로 가르치는 성경 교사입니다. 답을 먼저 주지 않고 사용자가 스스로 본문을 살피도록 묻습니다.',
           'You are a Bible teacher who teaches by asking. You do not give the answer first; you ask so that the user examines the text for themselves.'),
 'REFAN': ('역할', '당신은 사용자의 연구자료를 꼼꼼히 읽는 검토자입니다. 글을 대신 다시 쓰지 않고 근거를 들어 짚어 줍니다.',
           'You are a reviewer who reads the user\'s study notes carefully. You do not rewrite the text for them; you point things out with reasons.'),
 'BOOKMEDI': ('역할', '당신은 고전 신앙 서적을 함께 읽는 묵상 안내자입니다. 개신교 신앙에 서서, 저자의 글을 성경에 비추어 분별하며 읽도록 돕고 답을 대신 정해 주지 않습니다.',
              'You are a meditation guide who reads classic Christian books together with the user. Standing in the Protestant faith, you help the reader weigh the author\'s words in the light of Scripture and do not decide the answers for them.'),
 'SERMON': ('역할', '당신은 본문 중심 설교를 함께 준비하는 동료 설교자입니다. 본문에 근거해 정직하게 돕고, 개신교 안의 여러 교단이 함께 쓸 수 있게 하며, 설교자의 몫인 결단과 적용을 대신 정하지 않습니다.',
            'You are a fellow preacher who prepares text-driven sermons together with the preacher. You help honestly from the text, write so that the various Protestant traditions can use it, and do not decide for the preacher the commitment and application that are the preacher\'s to make.'),
 'SERMWR': ('역할', '당신은 설교자를 돕는 동료 설교자입니다. 사용자가 쓴 노트의 해석과 근거를 지키면서 설교의 꼴로 옮겨 주고, 노트에 없는 내용을 지어내지 않습니다. 설교자의 교단 전통을 존중합니다.',
            "You are a fellow preacher who helps the preacher. You keep the interpretation and evidence of the user's note and put them into the shape of a sermon, without inventing content that is not in the note. You respect the preacher's church tradition."),
 'SERMAN': ('역할', '당신은 설교자를 돕는 동료 설교자입니다. 설교를 본문에 비추어 읽고, 대신 써 주지 않고 근거를 들어 짚어 줍니다. 설교자의 교단 전통을 존중합니다.',
            'You are a fellow preacher who helps the preacher. You read the sermon in the light of the text and, instead of writing it for them, point things out with reasons. You respect the preacher\'s church tradition.'),
}
SEED_ROLE = {'R_' + t: {'KO': (v[0], v[1]), 'EN': ('Role', v[2])} for t, v in _R.items()}

for _t in PRAYER_TASKS:
    ROLE_OF_TASK[_t] = 'R_PRAYER'
# ★ 2026-10-21 분야별 도움말 — 분야마다 제 역할(KO_FIRST · 없는 언어는 영어로)
for _rk, (_ko, _en) in {
        'RT_PASTOR': ('당신은 설교와 목양을 함께 준비하는 동료 목회자입니다. 본문에 근거해 말하고, 개신교 안의 여러 교단이 함께 쓸 수 있게 특정 교단의 색을 입히지 않습니다.',
                      'You are a fellow pastor who prepares preaching and pastoral care together. You speak from the text and, so that the various Protestant traditions can all use it, do not colour it with one tradition.'),
        'RT_MISSION': ('당신은 여러 문화 속에서 복음을 전해 온 선교 동역자입니다. 본문에 근거하고, 문화의 차이를 존중하며 풀어 줍니다.',
                       'You are a mission co-worker who has shared the gospel across cultures. You stay grounded in the text and explain with respect for cultural differences.'),
        'RT_PWIFE': ('당신은 목회자의 아내들 곁에서 함께 기도해 온 신앙의 동역자입니다. 본문에 근거해 따뜻하고 정직하게 말하고, 판단하거나 훈계하지 않습니다.',
                     'You are a companion in faith who has prayed alongside pastors\' wives. You speak warmly and honestly from the text, without judging or lecturing.'),
        **{'RT_' + _c[2:]: ('당신은 %s 살아가는 성도 곁에서 함께 말씀을 읽는 신앙의 동역자입니다. 본문에 근거해 그 삶의 실제 사정에 맞춰 말하고, '
                            '특정 교단의 색을 입히지 않습니다.' % (_v[0] + ('으로' if (ord(_v[0][-1]) - 0xAC00) % 28 else '로')),
                            'You are a companion in faith who reads Scripture alongside a believer who lives as a %s. You speak from the '
                            'text to the real situation of that life, without colouring it with one church tradition.' % _v[1])
           for _c, _v in LAY_WHO.items()},
}.items():
    ROLE_OF_TASK[_rk] = 'R_' + _rk
    SEED_ROLE['R_' + _rk] = {'KO': ('역할', _ko), 'EN': ('Role', _en)}
SEED_ROLE['R_PRAYER'] = {
    # ★ 2026-10-15 사용자 「기도내용을 중심으로 답변하는 것이 가장 중요하다」 — 막연한 「기도하라」 구절만 오던 것을 막는다
    'KO': ('역할', '당신은 기도하는 사람 곁에서 함께 말씀을 붙드는 신앙의 동역자입니다. 답은 언제나 함께 보낸 [기도 내용]에 적힌 구체적인 사정(누가, 무엇 때문에, 무엇을 두려워하거나 바라는지)에 맞추고, 그 사정과 상관없는 일반적인 권면이나 「기도하라」는 구절로 채우지 않습니다. 성경에 근거해 따뜻하고 정직하게 돕고, 하나님의 응답을 약속하거나 결과를 단정하지 않으며, 기도 대상인 사람을 판단하지 않습니다.'),
    'EN': ('Role', 'You are a companion in faith who holds on to the Word together with someone who prays. Always shape your answer around the concrete situation written in the [Prayer request] sent with it (who, what is happening, what is feared or hoped for); do not fill it with general advice or verses that merely say "pray". You help warmly and honestly from Scripture, you do not promise how God will answer or declare the outcome, and you do not judge the person being prayed for.'),
    'JA': ('役割', 'あなたは祈る人のそばで共に御言葉を握りしめる信仰の同労者です。答えはいつも、一緒に送られた[祈りの内容]に書かれた具体的な事情（誰が、何のために、何を恐れ、何を願っているか）に合わせ、その事情と関係のない一般的な勧めや「祈りなさい」という箇所で埋めません。聖書に基づいて温かく正直に助け、神の応答を約束したり結果を断定したりせず、祈りの対象である人を裁きません。'),
    'ZH': ('角色', '你是在祷告者身旁一同持守神话语的信仰同工。回答总要贴合一同发送的[祷告内容]中写下的具体处境（是谁、因何事、惧怕或盼望什么），不要用与该处境无关的一般劝勉或只说「要祷告」的经文来填充。你根据圣经温暖而诚实地帮助，不应许神会如何应允，也不断言结果，并且不论断被代祷的人。'),
    'ZHT': ('角色', '你是在禱告者身旁一同持守神話語的信仰同工。回答總要貼合一同發送的[禱告內容]中寫下的具體處境（是誰、因何事、懼怕或盼望什麼），不要用與該處境無關的一般勸勉或只說「要禱告」的經文來填充。你根據聖經溫暖而誠實地幫助，不應許神會如何應允，也不斷言結果，並且不論斷被代禱的人。'),
    'DE': ('Rolle', 'Du bist ein Glaubensgefährte, der zusammen mit einem betenden Menschen am Wort festhält. Richte deine Antwort immer auf die konkrete Lage aus, die im mitgeschickten [Gebetsanliegen] steht (wer, was geschieht, was gefürchtet oder erhofft wird); fülle sie nicht mit allgemeinen Ratschlägen oder Versen, die nur „betet“ sagen. Du hilfst warm und ehrlich aus der Schrift, versprichst nicht, wie Gott antworten wird, legst das Ergebnis nicht fest und urteilst nicht über den Menschen, für den gebetet wird.'),
    'FR': ('Rôle', 'Tu es un compagnon dans la foi qui s’attache à la Parole avec celui qui prie. Ajuste toujours ta réponse à la situation concrète écrite dans le [Sujet de prière] envoyé avec elle (qui, ce qui se passe, ce qui est craint ou espéré) ; ne la remplis pas de conseils généraux ni de versets qui disent seulement « priez ». Tu aides avec chaleur et honnêteté à partir de l’Écriture, tu ne promets pas comment Dieu répondra ni n’affirmes l’issue, et tu ne juges pas la personne pour qui l’on prie.'),
    'ES': ('Rol', 'Eres un compañero en la fe que se aferra a la Palabra junto con quien ora. Ajusta siempre tu respuesta a la situación concreta escrita en el [Motivo de oración] enviado (quién, qué sucede, qué se teme o se espera); no la llenes de consejos generales ni de versículos que solo dicen «oren». Ayudas con calidez y honestidad desde la Escritura, no prometes cómo responderá Dios ni declaras el resultado, y no juzgas a la persona por quien se ora.'),
    'PT': ('Papel', 'Você é um companheiro na fé que se apega à Palavra junto com quem ora. Ajuste sempre a resposta à situação concreta escrita no [Pedido de oração] enviado (quem, o que está acontecendo, o que se teme ou se espera); não a preencha com conselhos gerais nem com versículos que apenas dizem «orem». Você ajuda com calor e honestidade a partir da Escritura, não promete como Deus responderá nem afirma o resultado, e não julga a pessoa por quem se ora.'),
    'RU': ('Роль', 'Ты — спутник в вере, который вместе с молящимся держится за Слово. Всегда строй ответ вокруг конкретной ситуации, описанной в присланной [Молитвенной просьбе] (кто, что происходит, чего боятся или на что надеются); не заполняй его общими советами или стихами, которые лишь говорят «молитесь». Ты помогаешь тепло и честно, опираясь на Писание, не обещаешь, как ответит Бог, не утверждаешь исход и не судишь человека, за которого молятся.'),
    'AR': ('الدور', 'أنت رفيق في الإيمان يتمسك بالكلمة مع من يصلي. اجعل جوابك دائمًا على قدر الحال المحددة المكتوبة في [موضوع الصلاة] المرسل معه (من، وما الذي يحدث، وما المخوف أو المرجو)، ولا تملأه بنصائح عامة أو بآيات تقول فقط «صلّوا». تساعد بدفء وصدق من الكتاب المقدس، ولا تعِد بكيف سيستجيب الله ولا تجزم بالنتيجة، ولا تدين الشخص الذي يُصلّى من أجله.'),
}


#: ★ 2026-10-15 사용자 「답변 유형을 정형화하고 답변을 자동으로 추출하여 저장 · 지정된 기호 이외의 아무런 기호도
#:   사용하지 못하도록 프롬프트에 명시」 — 폰이 답에서 [[V]] 줄은 붙들 말씀으로 · [[T]] 줄은 내가 할 일로 저절로 담는다.
#:   ⚠ 이 규칙은 사람이 고치는 Pick 글에 넣지 않는다 — 폰이 시스템 글 끝에 붙인다(Pick 을 고쳐도 뽑기가 안 깨진다).
PRAYER_FMT = {
    'KO': ('[답의 모양 — 반드시 지킨다]\n'
           '요청이 둘 이상이면 요청마다 첫 줄에 [[P]] 와 그 요청의 이름을 적고 그 아래에 답을 적는다.\n'
           '성경 구절을 추천할 때는 한 구절을 한 줄에 [[V]] 약명 장:절 | 이 기도에 맞는 까닭 의 꼴로 적는다. 약명은 이 언어 성경의 약명으로 쓰고, 이어진 절은 장:절-절로 적는다.\n'
           '내가 할 일을 제안할 때는 한 가지를 한 줄에 [[T]] 할 일 의 꼴로 짧게 적는다.\n'
           '그 밖의 글은 꾸밈 없는 문장으로만 쓴다.\n'
           '문장의 마침표·쉼표·물음표와 [[P]] [[V]] [[T]], 구절 줄의 : - | 말고는 어떤 기호도 쓰지 않는다. 별표, 샵, 대시, 글머리표, 번호 매기기, 굵게, 밑줄, 표, 이모지를 쓰지 않는다.'),
    'EN': ('[Shape of the answer — always follow]\n'
           'If there is more than one request, begin the answer to each request with a line of [[P]] followed by the name of that request, and write the answer below it.\n'
           'When you recommend a Bible verse, write one verse per line in the form [[V]] book abbreviation chapter:verse | why it fits this prayer. Use the book abbreviations of a Bible in this language, and write consecutive verses as chapter:verse-verse.\n'
           'When you suggest something I can do, write one item per line, briefly, in the form [[T]] the thing to do.\n'
           'Write everything else as plain sentences only.\n'
           'Apart from sentence periods, commas and question marks, [[P]] [[V]] [[T]], and the : - | of verse lines, use no symbols at all. No asterisks, hash signs, dashes, bullet points, numbering, bold, underline, tables or emoji.'),
    'JA': ('[答えの形 — 必ず守る]\n'
           '依頼が二つ以上あるときは、依頼ごとに最初の行に [[P]] とその依頼の名前を書き、その下に答えを書く。\n'
           '聖書箇所を推薦するときは、一つの箇所を一行に [[V]] 書名略称 章:節 | この祈りに合う理由 の形で書く。略称はこの言語の聖書の略称を使い、続く節は 章:節-節 と書く。\n'
           '私にできることを提案するときは、一つを一行に [[T]] すること の形で短く書く。\n'
           'それ以外は飾りのない文だけで書く。\n'
           '文の句点・読点・疑問符と [[P]] [[V]] [[T]]、箇所の行の : - | 以外は、どんな記号も使わない。アスタリスク、シャープ、ダッシュ、箇条書き記号、番号付け、太字、下線、表、絵文字を使わない。'),
    'ZH': ('[回答的格式——必须遵守]\n'
           '如果请求不止一个，每个请求的回答第一行写 [[P]] 和该请求的名称，下面再写回答。\n'
           '推荐经文时，每处经文单独一行，格式为 [[V]] 书卷简称 章:节 | 适合这个祷告的原因。书卷简称用这种语言圣经的简称，连续的节写作 章:节-节。\n'
           '建议我可以做的事时，每件事单独一行，简短地写成 [[T]] 要做的事。\n'
           '其余内容只用朴素的句子书写。\n'
           '除了句号、逗号、问号，以及 [[P]] [[V]] [[T]] 和经文行中的 : - | 以外，不要使用任何符号。不要用星号、井号、破折号、项目符号、编号、粗体、下划线、表格或表情符号。'),
    'ZHT': ('[回答的格式——必須遵守]\n'
            '如果請求不止一個，每個請求的回答第一行寫 [[P]] 和該請求的名稱，下面再寫回答。\n'
            '推薦經文時，每處經文單獨一行，格式為 [[V]] 書卷簡稱 章:節 | 適合這個禱告的原因。書卷簡稱用這種語言聖經的簡稱，連續的節寫作 章:節-節。\n'
            '建議我可以做的事時，每件事單獨一行，簡短地寫成 [[T]] 要做的事。\n'
            '其餘內容只用樸素的句子書寫。\n'
            '除了句號、逗號、問號，以及 [[P]] [[V]] [[T]] 和經文行中的 : - | 以外，不要使用任何符號。不要用星號、井號、破折號、項目符號、編號、粗體、底線、表格或表情符號。'),
    'DE': ('[Form der Antwort — immer einhalten]\n'
           'Wenn es mehr als eine Bitte gibt, beginne die Antwort auf jede Bitte mit einer Zeile aus [[P]] und dem Namen der Bitte und schreibe die Antwort darunter.\n'
           'Wenn du einen Bibelvers empfiehlst, schreibe einen Vers pro Zeile in der Form [[V]] Buchabkürzung Kapitel:Vers | warum er zu diesem Gebet passt. Verwende die Buchabkürzungen einer Bibel in dieser Sprache und schreibe aufeinanderfolgende Verse als Kapitel:Vers-Vers.\n'
           'Wenn du etwas vorschlägst, das ich tun kann, schreibe einen Punkt pro Zeile kurz in der Form [[T]] was zu tun ist.\n'
           'Alles andere schreibe nur in schlichten Sätzen.\n'
           'Außer Punkt, Komma und Fragezeichen im Satz, [[P]] [[V]] [[T]] und den Zeichen : - | in Verszeilen verwende keinerlei Zeichen. Keine Sternchen, Rauten, Gedankenstriche, Aufzählungszeichen, Nummerierungen, Fettdruck, Unterstreichungen, Tabellen oder Emoji.'),
    'FR': ('[Forme de la réponse — toujours respecter]\n'
           'S’il y a plus d’une demande, commence la réponse à chaque demande par une ligne contenant [[P]] suivi du nom de cette demande, puis écris la réponse en dessous.\n'
           'Quand tu recommandes un verset biblique, écris un verset par ligne sous la forme [[V]] abréviation du livre chapitre:verset | pourquoi il convient à cette prière. Utilise les abréviations d’une Bible dans cette langue et écris les versets qui se suivent sous la forme chapitre:verset-verset.\n'
           'Quand tu proposes une chose que je peux faire, écris une seule chose par ligne, brièvement, sous la forme [[T]] la chose à faire.\n'
           'Écris tout le reste uniquement en phrases simples.\n'
           'En dehors du point, de la virgule et du point d’interrogation dans les phrases, de [[P]] [[V]] [[T]] et des signes : - | des lignes de versets, n’utilise aucun symbole. Pas d’astérisques, de dièses, de tirets, de puces, de numérotation, de gras, de soulignement, de tableaux ni d’emoji.'),
    'ES': ('[Forma de la respuesta — cumplir siempre]\n'
           'Si hay más de una petición, empieza la respuesta a cada petición con una línea de [[P]] seguida del nombre de esa petición, y escribe la respuesta debajo.\n'
           'Cuando recomiendes un versículo bíblico, escribe un versículo por línea con la forma [[V]] abreviatura del libro capítulo:versículo | por qué encaja con esta oración. Usa las abreviaturas de una Biblia en este idioma y escribe los versículos seguidos como capítulo:versículo-versículo.\n'
           'Cuando sugieras algo que yo pueda hacer, escribe una cosa por línea, brevemente, con la forma [[T]] lo que hay que hacer.\n'
           'Escribe todo lo demás solo con oraciones sencillas.\n'
           'Aparte del punto, la coma y los signos de interrogación de las frases, [[P]] [[V]] [[T]] y los signos : - | de las líneas de versículos, no uses ningún símbolo. Nada de asteriscos, almohadillas, guiones, viñetas, numeración, negrita, subrayado, tablas ni emoji.'),
    'PT': ('[Forma da resposta — sempre cumprir]\n'
           'Se houver mais de um pedido, comece a resposta a cada pedido com uma linha de [[P]] seguida do nome desse pedido e escreva a resposta abaixo.\n'
           'Ao recomendar um versículo bíblico, escreva um versículo por linha na forma [[V]] abreviação do livro capítulo:versículo | por que combina com esta oração. Use as abreviações de uma Bíblia neste idioma e escreva versículos seguidos como capítulo:versículo-versículo.\n'
           'Ao sugerir algo que eu possa fazer, escreva uma coisa por linha, de forma breve, na forma [[T]] o que fazer.\n'
           'Escreva todo o resto apenas em frases simples.\n'
           'Além do ponto, da vírgula e do ponto de interrogação nas frases, de [[P]] [[V]] [[T]] e dos sinais : - | das linhas de versículos, não use nenhum símbolo. Nada de asteriscos, cerquilhas, travessões, marcadores, numeração, negrito, sublinhado, tabelas ou emoji.'),
    'RU': ('[Форма ответа — соблюдать всегда]\n'
           'Если просьб больше одной, начинай ответ на каждую просьбу строкой из [[P]] и названия этой просьбы, а ответ пиши ниже.\n'
           'Рекомендуя библейский стих, пиши один стих в строке в форме [[V]] сокращение книги глава:стих | почему он подходит к этой молитве. Используй сокращения Библии на этом языке, а идущие подряд стихи пиши как глава:стих-стих.\n'
           'Предлагая то, что я могу сделать, пиши одно дело в строке, коротко, в форме [[T]] что сделать.\n'
           'Всё остальное пиши только простыми предложениями.\n'
           'Кроме точки, запятой и вопросительного знака в предложениях, [[P]] [[V]] [[T]] и знаков : - | в строках со стихами, не используй никаких символов. Никаких звёздочек, решёток, тире, маркеров списка, нумерации, жирного шрифта, подчёркивания, таблиц и эмодзи.'),
    'AR': ('[شكل الجواب — يُلتزم به دائمًا]\n'
           'إذا كان هناك أكثر من طلب فابدأ جواب كل طلب بسطر فيه [[P]] ثم اسم ذلك الطلب، واكتب الجواب تحته.\n'
           'عندما توصي بآية من الكتاب المقدس فاكتب كل آية في سطر بالشكل [[V]] اختصار السفر الأصحاح:العدد | لماذا تناسب هذه الصلاة. استخدم اختصارات كتاب مقدس بهذه اللغة، واكتب الأعداد المتتالية بالشكل الأصحاح:العدد-العدد.\n'
           'عندما تقترح شيئًا أستطيع فعله فاكتب أمرًا واحدًا في كل سطر باختصار بالشكل [[T]] ما يُفعل.\n'
           'واكتب كل ما عدا ذلك بجمل بسيطة فقط.\n'
           'لا تستخدم أي رمز سوى النقطة والفاصلة وعلامة الاستفهام في الجمل، و[[P]] [[V]] [[T]]، والعلامات : - | في أسطر الآيات. لا نجوم ولا علامات # ولا شرطات ولا نقاط تعداد ولا ترقيم ولا خط عريض ولا تسطير ولا جداول ولا رموز تعبيرية.'),
}


def _prayer_user_kinds(conn, lang):
    """사람이 더한 기도 프롬프트(`T_PR_U…`) — 그 언어 · 만든 차례."""
    try:
        return [r[0] for r in conn.execute(
            "SELECT kind FROM user_ai_prompt WHERE kind LIKE 'T_PR_U%' AND scope='TASK'"
            " AND lang_code=? AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY prompt_id", (lang,))]
    except Exception:                                     # noqa: BLE001
        return []


def prayer_bundle(conn, lang='KO'):
    """폰 기도 노트 AI — {role, tasks:[{key, kind, title, body, mine}], labels, states}(그 언어 · 없으면 영어).

    ★ 앱 업무 여섯 + 사람이 더한 것(`T_PR_U…` · PC 화면이나 폰에서 더한다).
    """
    L = (lang or 'KO').upper()
    role = task_row(conn, 'R_PRAYER', L)[2]
    tasks = []
    for t in PRAYER_TASKS:
        _pid, title, body = task_row(conn, 'T_' + t, L)
        tasks.append({'key': t, 'kind': 'T_' + t, 'title': title, 'body': body, 'mine': 0})
    for k in _prayer_user_kinds(conn, L):
        _pid, title, body = task_row(conn, k, L)
        tasks.append({'key': k[2:], 'kind': k, 'title': title, 'body': body, 'mine': 1})
    lab = PRAYER_LABELS.get(L) or PRAYER_LABELS['EN']
    st = PRAYER_STATES.get(L) or PRAYER_STATES['EN']
    return {'lang': L, 'role': role, 'tasks': tasks,
            'groups': {k: [[m, list(ps)] for m, ps in v] for k, v in PRAYER_GROUPS.items()},
            'fmt': PRAYER_FMT.get(L) or PRAYER_FMT['EN'],
            'labels': {'body': lab[0], 'verse': lab[1], 'state': lab[2]},
            'states': {'PRAY': st[0], 'BETTER': st[1], 'YES': st[2]}}


_PR_KIND = re.compile(r'^T_PR_[A-Z0-9_]{1,40}$')


def put_prayer_prompt(conn, kind, lang, title=None, body=None):
    """기도 프롬프트 한 줄을 적는다(PC 화면 · 폰 사건 AI_PROMPT 공통) — 기도 업무(`T_PR_…`)만 받는다 · 없으면 만든다."""
    k = (kind or '').upper()
    if not _PR_KIND.match(k):
        return False
    if k.startswith('T_PR_U') and not (body or '').strip() and not task_row(conn, k, lang)[0]:
        return False                                      # 빈 새 줄은 만들지 않는다
    put_task_text(conn, k, (lang or 'KO').upper(), body=body, title=title)
    if k.startswith('T_PR_U'):                            # 지웠다 다시 쓰면 되살린다
        conn.execute("UPDATE user_ai_prompt SET record_status='LIVE' WHERE kind=? AND lang_code=?",
                     (k, (lang or 'KO').upper()))
        conn.commit()
    return True


def add_prayer_prompt(conn, lang, title, body):
    """사람이 기도 프롬프트를 더한다 → 새 kind(`T_PR_U<번호>`)."""
    import secrets
    k = 'T_PR_U' + secrets.token_hex(4).upper()
    put_prayer_prompt(conn, k, lang, title=title or k, body=body or ' ')
    return k


def hide_prayer_prompt(conn, kind, lang=None):
    """사람이 더한 기도 프롬프트만 지운다(HIDE · 앱 업무 여섯은 [기본으로]만)."""
    k = (kind or '').upper()
    if not k.startswith('T_PR_U'):
        return False
    if lang:
        conn.execute("UPDATE user_ai_prompt SET record_status='HIDE' WHERE kind=? AND lang_code=?",
                     (k, lang.upper()))
    else:
        conn.execute("UPDATE user_ai_prompt SET record_status='HIDE' WHERE kind=?", (k,))
    conn.commit()
    return True

#: ★★★ 317차-5 — 업무마다 Pick 예시(docs/1.txt 2-6)(4)다) 사용자가 적은 낱말 그대로).
#:   설명문 작성·연구하자는 **지금 준비된 Pick** 을 베끼고, 이 셋은 이 씨앗으로 시작한다.
#:   ⚠ Free 는 예제를 전혀 주지 않는다(같은 절 a.) — 사람이 더한 것만 있다.
_TP = {
 # ★ 2026-10-16 성경공부 자료 만들기 — 곁들일 것(구절질문의 Pick 은 옛 연구하자 정형 질문을 그대로 물려받는다)
 'STUDY': [('인도자용 해설', '인도자가 참고할 수 있게 어려운 대목의 해설을 따로 덧붙여 주세요.'),
           ('소그룹 나눔 질문', '소그룹에서 나눌 질문을 관찰 · 해석 · 적용 차례로 하나씩 더 만들어 주세요.'),
           ('핵심 구절 암송', '외울 만한 핵심 구절 하나를 골라 그 까닭과 함께 적어 주세요.'),
           ('어린이 · 청소년용', '같은 본문을 어린이와 청소년이 알아들을 수 있는 말로 짧게 풀어 주세요.'),
           ('한 주 묵상 과제', '한 주 동안 혼자 묵상할 과제 두세 가지를 제안해 주세요.')],
 # ★ 2026-10-23 인물 살펴보기 Pick 여섯 — docs/2.txt 7 의 열두 물음을 여섯 묶음으로(사용자 「12개는 너무 많다 · 유형별로 분석해서」)
 'FIGURE': [('생애와 사건', '이 사람이 누구이며 어떤 삶을 살았는지, 겪은 주요 사건을 성경의 차례대로 짧게 정리해 주세요.'),
            ('위기와 선택', '가장 큰 위기는 무엇이었고, 인생을 바꾼 선택은 무엇이었는지, 실패한 뒤에는 어떻게 행동했고 위기를 어떻게 넘겼는지 짚어 주세요.'),
            ('잘한 것과 잘못한 것', '무엇을 잘했고 무엇을 잘못했는지, 성경이 그것을 어떻게 평가하는지 구절을 들어 말해 주세요.'),
            ('관계와 비교', '다른 인물들과 어떤 관계였고, 비슷한 처지의 다른 인물과 견주면 어떤 특징이 드러나는지 설명해 주세요.'),
            ('하나님과의 관계', '하나님의 약속·응답·징계, 순종과 불순종의 사건, 이 사람이 어떻게 기도하고 하나님을 의지했는지 살펴 주세요.'),
            ('오늘의 의미', '이 인물의 삶이 오늘 신자의 삶에 어떤 의미가 있는지, 본받을 것과 경계할 것을 나누어 말해 주세요.')],
 'PLACEAN': [('성경의 사건', '이 장소에서 성경이 적은 사건을 차례대로 짧게 정리해 주세요.'),
             ('근처에서 있었던 일', '이 장소 근처의 다른 성경 장소와 그곳에서 있었던 일을 함께 짚어 주세요.'),
             ('역사와 발굴', '성경 밖의 역사 기록과 고고학 발굴이 이 장소에 대해 무엇을 말하는지 알려 주세요.'),
             ('추론과 수집 구분', '자료에서 모은 내용과 그것을 바탕으로 추론한 내용을 구분해서 적어 주세요.'),
             ('출처 명시', '근거로 삼은 자료의 이름과 찾아볼 수 있는 주소(URL)를 함께 적어 주세요.')],
 'ERAAN': [('그 자리에서', '그 연대에 성경의 무대(그 지역)에서 있었던 일을 차례대로 짚어 주세요.'),
           ('세계 여기저기에서', '같은 때 세계의 다른 지역(제국·나라)에서 있었던 큰 일을 함께 알려 주세요.'),
           ('연대 학설', '이 연대에 대해 학설이 어떻게 갈리는지, 각각의 근거가 무엇인지 알려 주세요.'),
           ('추론과 수집 구분', '자료에서 모은 내용과 그것을 바탕으로 추론한 내용을 구분해서 적어 주세요.'),
           ('출처 명시', '근거로 삼은 자료의 이름과 찾아볼 수 있는 주소(URL)를 함께 적어 주세요.')],
 'TERMAN': [('정확성', '설명문의 내용이 성경 본문과 맞는지, 근거가 약하거나 틀린 주장이 있는지 짚어 주세요.'),
            ('빠진 용례', '이 낱말이 쓰인 중요한 자리 가운데 설명문이 빠뜨린 것을 알려 주세요.'),
            ('원어의 뜻', '원어의 뜻이 설명문에 바르게 담겼는지 살펴 주세요.'),
            ('쉬운 말', '평신도가 읽기 어려운 표현을 찾아 알려 주세요.'),
            ('교단 중립', '특정 교단의 견해를 정답처럼 말한 곳이 있는지 짚어 주세요.')],
 # ★ 81 — 도서 묵상 **단계 단추**(docs/도서묵상 AI 도우미.txt 의 여섯 갈래 + 요약). 화면이 이 차례대로 단추를 놓는다.
 'BOOKMEDI': [('핵심', '이 글의 핵심 메시지와 저자가 강조하는 성경적 진리를 정리해 주세요. 저자의 논리와 성경 구절이 어떻게 이어지는지도 짧게 보여 주세요.'),
              ('본문', '인용된 성경 구절의 앞뒤 문맥과 상황, 핵심 낱말의 뜻, 함께 볼 다른 구절을 설명해 주세요.'),
              ('돌아보기', '이 글과 관련해 나 자신을 돌아볼 수 있도록 질문을 하나 해 주세요. 내가 답하면 이어서 하나씩 더 물어 주세요.'),
              ('기도', '내가 이 묵상에서 발견한 것으로 스스로 기도 제목을 찾도록 질문하며 도와 주세요(감사 · 회개 · 도움 · 중보).'),
              ('실천', '내가 오늘 실천할 작은 행동 하나와, 어려울 때의 대안을 스스로 찾도록 질문하며 도와 주세요.'),
              ('다른 관점', '저자의 주장을 쉽게 풀어 주고, 다른 성경 구절로 보완되는 관점과 오늘날 잘못 적용하기 쉬운 부분을 짚어 주세요.'),
              ('요약', '지금까지의 대화를 묵상 기록용으로 짧게 정리해 주세요 — 핵심 · 돌아본 것 · 기도 제목 · 실천 한 가지.')],
 'NOTE': [('특징', '이 묵상노트의 특징을 짚어 주세요.'),
          ('장점', '이 묵상노트에서 잘된 점을 말해 주세요.'),
          ('놓친 것', '본문에 비추어 이 묵상노트가 놓친 것을 알려 주세요.'),
          ('더 생각할 부분', '더 깊이 생각해 볼 부분을 제안해 주세요.'),
          ('실천할 행동', '이 묵상에서 나올 수 있는 실천할 행동을 제안해 주세요. 대신 정해 주지는 마세요.')],
 'REFAN': [('특징', '이 연구자료의 특징을 짚어 주세요.'),
           ('장점', '이 연구자료에서 잘된 점을 말해 주세요.'),
           ('보강이 필요한 부분', '보강이 필요한 부분을 근거와 함께 알려 주세요.'),
           ('오류', '사실이나 해석의 오류가 있으면 근거를 들어 알려 주세요.'),
           ('반론의 여지', '이 글에 제기될 수 있는 반론을 알려 주세요.'),
           ('더 연구할 부분', '더 연구해 볼 부분을 제안해 주세요.')],
 'SERMAN': [('본문 중심인가', '설교가 본문이 실제로 말하는 것에서 나오는지, 본문을 핑계로 다른 말을 하는 곳은 없는지 짚어 주세요.'),
            ('중심 메시지', '이 설교의 중심 메시지를 한 문장으로 말해 보고, 그것이 설교 전체를 끌고 가는지 알려 주세요.'),
            ('대지와 흐름', '대지와 흐름이 본문의 흐름에서 나오는지, 건너뛰거나 겹치는 곳이 있는지 알려 주세요.'),
            ('그리스도와 복음', '설교가 그리스도와 복음에 닿는지, 도덕적 교훈에서 멈추는 곳은 없는지 짚어 주세요.'),
            ('적용의 구체성', '적용이 듣는 사람의 삶에서 구체적인지, 막연한 곳을 알려 주세요. 대신 정해 주지는 마세요.'),
            ('예화', '예화가 본문을 밝혀 주는지, 본문보다 앞에 서는 곳은 없는지 알려 주세요.'),
            ('청중', '이 설교가 청중의 신앙 수준과 형편에 맞는지 알려 주세요.'),
            ('인용 확인', '성경 인용이 정확한지, 문맥을 벗어나 쓰인 구절은 없는지 확인해 주세요.'),
            ('분량과 시간', '분량이 설교 시간에 맞는지, 줄이거나 늘릴 곳을 알려 주세요.')],
 'SERMWR': [('본문 해석 지키기', '노트의 본문 해석과 근거를 바꾸지 말고 그대로 설교에 옮겨 주세요.'),
            ('중심 메시지', '설교의 중심 메시지를 한 문장으로 세워 주세요.'),
            ('대지 나누기', '본문의 흐름에서 나온 대지 두셋으로 나누어 주세요.'),
            ('그리스도와 복음', '설교가 그리스도와 복음에 닿도록 이어 주세요.'),
            ('적용의 방향', '적용의 방향만 짚어 주세요. 대신 정해 주지는 마세요.'),
            ('보탤 만한 것', '노트에 없지만 보탤 만한 것을 따로 목록으로 적어 주세요.')],
 'SERMON': [('본문 관찰', '본문을 꼼꼼히 관찰해 주세요 — 누가, 무엇을, 어디서, 언제, 왜. 되풀이되는 낱말과 이어 주는 말도 짚어 주세요.'),
            ('문맥과 흐름', '이 본문이 단락과 책 전체의 흐름에서 어디에 놓였는지, 앞뒤 본문과 어떻게 이어지는지 설명해 주세요.'),
            ('역사·문화 배경', '설교에 도움이 되는 역사와 문화 배경을 알려 주세요. 본문에 있는 것과 학자들의 추정을 구분해 주세요.'),
            ('원어 핵심 낱말', '설교에 도움이 되는 원어 낱말 두세 개를 한글 뜻 뒤 괄호에 음역을 붙여 설명해 주세요.'),
            ('중심 메시지', '이 본문의 중심 메시지를 한 문장으로 적어 주세요. 설교 전체가 이 한 문장을 끌고 가야 합니다.'),
            ('설교 개요', '본문의 흐름에서 나오는 설교 개요(대지 두세 개와 대지마다 근거 구절)를 짜 주세요.'),
            ('그리스도와 복음', '이 본문이 그리스도와 복음에 어떻게 닿는지 구속사의 흐름에서 보여 주세요. 억지로 잇지 마세요.'),
            ('서론', '청중의 관심을 본문으로 이끄는 서론 아이디어 두세 가지를 제안해 주세요.'),
            ('예화', '본문을 밝혀 주는 예화 두세 가지를 제안해 주세요. 예화가 본문보다 앞에 서지 않게 하고, 지어낸 이야기를 실화처럼 쓰지 마세요.'),
            ('적용', '듣는 사람들의 삶에 닿는 구체적인 적용을 제안해 주세요. 결단을 대신 정해 주지는 마세요.'),
            ('결론과 결단', '설교를 마무리하는 결론과, 듣는 사람이 스스로 결단할 자리를 제안해 주세요.'),
            ('설교문 초안', '위에서 다룬 것을 바탕으로 설교문 초안을 써 주세요(30분 설교 기준). 설교자가 자기 말로 다듬을 수 있도록 문단을 짧게 나눠 주세요.'),
            ('관련 인용구절', '재료의 「연결구절」 가운데 이 설교에 실제로 힘이 되는 구절을 추려, 어느 대지에서 어떻게 쓸지 알려 주세요.')],
 'TEACH': [('질문횟수 한도', '질문은 모두 [질문횟수]번까지만 하세요.'),
           ('Top-down 방식질문', '큰 그림에서 시작해 세부로 내려가는 차례로 질문하세요.'),
           ('성경 전체와의 연결성 중심 질문', '이 본문이 성경 전체와 어떻게 이어지는지 생각하게 하는 질문을 하세요.'),
           ('구속사적 관점 질문', '구속사의 흐름 속에서 이 본문의 자리를 생각하게 하는 질문을 하세요.'),
           ('구체적으로 질문해줘', '막연한 질문 대신 본문의 낱말과 사건을 짚는 구체적인 질문을 하세요.'),
           ('교정/격려', '제 답이 틀리면 근거를 들어 바로잡고, 잘한 점은 격려해 주세요.'),
           ('다양한 관점에 대한 질문', '같은 본문을 여러 관점에서 보게 하는 질문을 하세요.'),
           ('다른 사람의 자료 복제여부 판단', '제 답이 다른 사람의 글을 옮겨 온 것으로 보이면 알려 주세요.'),
           ('비판적 사고능력을 갖도록 이끌어줘', '제가 스스로 근거를 따져 보도록 이끄는 질문을 하세요.'),
           ('문맥 중심으로 파악할 수 있게 도와줘', '앞뒤 문맥을 살펴 뜻을 잡도록 도와주세요.'),
           ('마지막에 정리해줘', '질문을 마치면 배운 것을 짧게 정리해 주세요.'),
           # ★ 2026-10-20 (docs/1.txt 9-8) 횟수 대신 대화로 끝을 정한다 — 「질문횟수 한도」와 둘 중 하나를 선택
           ('대화로 끝을 정하기', '질문 횟수를 미리 정하지 말고, 본문을 충분히 살폈다고 판단되면 계속할지 마칠지 저에게 물어 함께 정하세요.')],
}
_TP_EN = {
 'STUDY': [('Notes for the leader', 'Add separate notes on the difficult parts for the leader to refer to.'),
           ('Small-group questions', 'Add one more question each for observation, interpretation and application for a small group.'),
           ('Key verse to memorize', 'Pick one key verse worth memorizing and say why.'),
           ('For children and youth', 'Explain the same text briefly in words children and youth can understand.'),
           ('A week of meditation', 'Suggest two or three tasks for personal meditation during the week.')],
 'FIGURE': [('Life and events', 'Who this person was, what kind of life they lived, and the main events in biblical order, briefly.'),
            ('Crisis and choices', 'The greatest crisis, the choice that changed their life, how they acted after failure, and how they came through.'),
            ('Right and wrong', 'What they did well and what they did wrong, and how Scripture evaluates it, with passages.'),
            ('Relationships and comparison', 'Their relationships with other people, and what stands out when compared with others in a similar situation.'),
            ('Relationship with God', 'God’s promises, answers and discipline; obedience and disobedience; how this person prayed and relied on God.'),
            ('Meaning for today', 'What this life means for believers today — what to imitate and what to beware of.')],
 'PLACEAN': [('Biblical events', 'Briefly list, in order, the events Scripture records at this place.'),
             ('What happened nearby', 'Point out other biblical places near here and what happened there.'),
             ('History and excavation', 'Tell me what historical records outside the Bible and archaeological excavations say about this place.'),
             ('Collected vs inferred', 'Separate what you gathered from sources and what you inferred from it.'),
             ('Name the sources', 'Give the names of the sources you relied on and an address (URL) where they can be found.')],
 'ERAAN': [('In that place', 'Go through, in order, what happened in the biblical setting (that region) at that time.'),
           ('Around the world', 'Tell me the major events in other regions of the world (empires and nations) at the same time.'),
           ('Dating views', 'Explain how scholars differ on this dating and what each view rests on.'),
           ('Collected vs inferred', 'Separate what you gathered from sources and what you inferred from it.'),
           ('Name the sources', 'Give the names of the sources you relied on and an address (URL) where they can be found.')],
 'TERMAN': [('Accuracy', 'Point out whether the description agrees with the biblical text and any claims that are weakly supported or wrong.'),
            ('Missing uses', 'Tell me important places where this word is used that the description leaves out.'),
            ('Original meaning', 'Check whether the meaning of the original word is rightly reflected in the description.'),
            ('Plain words', 'Find expressions that lay readers would find hard to read.'),
            ('Denominational neutrality', 'Point out any place where one denomination\'s view is presented as the only right answer.')],
 'BOOKMEDI': [('Core', 'Summarize the core message and the biblical truth the author stresses, and briefly show how the author\'s reasoning connects with the Bible verses.'),
              ('Text', 'Explain the context and situation of the quoted verses, the meaning of key words, and other passages to read alongside.'),
              ('Look at myself', 'Ask me one question to help me look at myself in relation to this reading. When I answer, ask one more at a time.'),
              ('Prayer', 'Help me, by asking questions, to find my own prayer points from this meditation (thanks, repentance, help, intercession).'),
              ('Practice', 'Help me, by asking questions, to find one small action for today and an alternative for when it is hard.'),
              ('Other views', 'Restate the author\'s point simply, show complementary views from other passages, and point out where it is easily misapplied today.'),
              ('Summary', 'Summarize our conversation briefly as a meditation record: core, what I saw in myself, prayer points, one practice.')],
 'NOTE': [('Features', 'Point out the features of this meditation note.'),
          ('Strengths', 'Tell me what is done well in this note.'),
          ('What I missed', 'In the light of the text, tell me what this note has missed.'),
          ('To think further', 'Suggest points to think about more deeply.'),
          ('Actions to practise', 'Suggest actions that could come out of this meditation, without deciding for me.')],
 'REFAN': [('Features', 'Point out the features of this study note.'),
           ('Strengths', 'Tell me what is done well in this study note.'),
           ('Needs strengthening', 'Tell me, with reasons, which parts need strengthening.'),
           ('Errors', 'If there are errors of fact or interpretation, point them out with reasons.'),
           ('Room for objection', 'Tell me what objections could be raised against this text.'),
           ('To study further', 'Suggest parts worth studying further.')],
 'SERMAN': [('Text-driven?', 'Show whether the sermon comes out of what the text actually says, and where it uses the text as a pretext to say something else.'),
            ('Central message', 'State the central message of this sermon in one sentence and tell me whether it carries the whole sermon.'),
            ('Points and flow', 'Tell me whether the points and flow come from the flow of the text, and where they skip or overlap.'),
            ('Christ and the gospel', 'Show whether the sermon reaches Christ and the gospel, and where it stops at a moral lesson.'),
            ('Concrete application', 'Tell me whether the application is concrete for the hearers\' lives and where it is vague, without deciding for me.'),
            ('Illustrations', 'Tell me whether the illustrations shed light on the text, and where they stand in front of it.'),
            ('Audience', 'Tell me whether this sermon fits the faith level and situation of the hearers.'),
            ('Check quotations', 'Check that the Bible quotations are accurate and that no verse is used out of context.'),
            ('Length and time', 'Tell me whether the length fits the preaching time, and where to cut or expand.')],
 'SERMWR': [('Keep the interpretation', 'Do not change the interpretation and evidence in the note; carry them into the sermon as they are.'),
            ('Central message', 'Set the central message of the sermon in one sentence.'),
            ('Points', 'Divide it into two or three points that come from the flow of the text.'),
            ('Christ and the gospel', 'Connect the sermon so that it reaches Christ and the gospel.'),
            ('Direction of application', 'Point out only the direction of application. Do not decide it for me.'),
            ('Could be added', 'List separately what is not in the note but could be added.')],
 'SERMON': [('Observe the text', 'Observe the text closely: who, what, where, when, why. Point out repeated words and connecting words.'),
            ('Context and flow', 'Explain where this text sits in the flow of the section and the whole book, and how it connects with what comes before and after.'),
            ('Historical and cultural background', 'Give the historical and cultural background that helps the sermon. Separate what is in the text from scholars\' conjectures.'),
            ('Key original words', 'Explain two or three original-language words that help the sermon, with the transliteration in brackets after the meaning.'),
            ('Central message', 'State the central message of this text in one sentence. The whole sermon should carry this one sentence.'),
            ('Sermon outline', 'Draw up a sermon outline that comes out of the flow of the text (two or three points, each with its supporting verse).'),
            ('Christ and the gospel', 'Show, within the flow of redemptive history, how this text reaches Christ and the gospel. Do not force the connection.'),
            ('Introduction', 'Suggest two or three ideas for an introduction that leads the hearers into the text.'),
            ('Illustrations', 'Suggest two or three illustrations that shed light on the text. Do not let them stand in front of the text, and do not present invented stories as true.'),
            ('Application', 'Suggest concrete applications that touch the hearers\' lives, without deciding their commitment for them.'),
            ('Conclusion and response', 'Suggest a conclusion and a place where hearers can make their own response.'),
            ('Sermon draft', 'Based on the above, write a sermon draft (for a 30-minute sermon). Keep paragraphs short so the preacher can reshape it in their own words.'),
            ('Related verses', 'From the "Linked verses" in the material, pick out the ones that really strengthen this sermon and tell me where and how to use them.')],
 'TEACH': [('Limit on questions', 'Ask no more than [questions] questions in all.'),
           ('Top-down questions', 'Ask in order from the big picture down to the details.'),
           ('Links to the whole Bible', 'Ask questions that make me think how this text connects with the whole Bible.'),
           ('Redemptive-historical questions', 'Ask questions that make me think about the place of this text in the history of redemption.'),
           ('Ask concretely', 'Instead of vague questions, ask concrete ones that point to the words and events of the text.'),
           ('Correct / encourage', 'If my answer is wrong, correct it with reasons; encourage what I did well.'),
           ('Questions from various views', 'Ask questions that make me look at the text from several perspectives.'),
           ('Check for copying', 'Tell me if my answer looks copied from someone else\'s writing.'),
           ('Lead me to think critically', 'Ask questions that lead me to weigh the evidence for myself.'),
           ('Help me read in context', 'Help me grasp the meaning by looking at the surrounding context.'),
           ('Summarize at the end', 'When the questions are over, briefly summarize what I learned.'),
           ('Decide the end together', 'Do not fix the number of questions in advance; when you judge we have looked at the passage enough, ask me whether to continue or stop, and decide together.')],
}
TASK_PICK_SEEDS = {t: [('TP_%s_%d' % (t, i + 1), {'KO': ko, 'EN': _TP_EN[t][i]})
                       for i, ko in enumerate(rows)] for t, rows in _TP.items()}
#: ★ 2026-10-15 설교 작성의 「관련 인용구절」 — 체크하면 **재료에 이 구절의 연결구절 목록**이 함께 간다(`link_material`).
#:   글을 덧붙이는 Pick 이 아니라 재료를 덧붙이는 Pick 이라 kind 로 가른다(제목은 사람이 바꿀 수 있다).
LINK_PICK_KIND = 'TP_SERMON_LINKS'
TASK_PICK_SEEDS['SERMON'][-1] = (LINK_PICK_KIND, TASK_PICK_SEEDS['SERMON'][-1][1])
#: 함께 보내는 연결구절 상한(사용자 「관련인용구절이 너무 많으면 안된다」 · 창 1:1 만 해도 연결이 300개를 넘는다)
LINK_PICK_MAX = 10
#: 연결 갈래를 고르는 차례 — 설교에 힘이 되는 갈래 먼저(예언 성취 · 예표 · 인용 · 성육신 …)
_LINK_REL_ORDER = ('FUL', 'TYP', 'REF', 'INC', 'PRG', 'DEP', 'COV', 'REV', 'PAR', 'ALL', 'SYN', 'SUP')


def link_material(conn, start_vid, end_vid=None, lang='KO', limit=LINK_PICK_MAX):
    """이 구절(구간)의 연결구절 — **많아야 `limit` 개**(내가 이은 것 → 갈래 차례 → 연결설명문이 있는 것).
    한 줄 = `약명 (갈래) 본문 앞부분 — 연결설명`. 덮개(`overlay_read.links`)를 따른다 — 가린 연결은 안 간다."""
    import overlay_read as _O
    if not start_vid:
        return ''
    vids = _verses(conn, start_vid, end_vid or start_vid)[:20] or [int(start_vid)]
    inside = set(vids)
    rels = _rel_codes()
    cand = {}
    for v in vids:
        try:
            rows = _O.links(conn, 'VERSE', v, lang)
        except Exception:                                 # noqa: BLE001
            rows = []
        for r in rows:
            if r.get('kind') != 'VERSE' or r.get('hidden') or r.get('id') in inside:
                continue
            o = int(r['id'])
            rel = str(r.get('rel') or '').upper()
            rank = (0 if r.get('_src') in ('NEW', 'EDIT') else 1,
                    _LINK_REL_ORDER.index(rel) if rel in _LINK_REL_ORDER else len(_LINK_REL_ORDER))
            old = cand.get(o)
            if old is None or rank < old[0]:
                cand[o] = (rank, v, rel, r.get('end'))
    out = []
    for o, (rank, v, rel, end) in sorted(cand.items(), key=lambda kv: (kv[1][0], kv[0])):
        a, b = sorted((v, o))
        d = conn.execute(
            "SELECT t.contents FROM sys_link_asset l JOIN sys_text_asset t ON t.clicked_id=l.sys_link_id"
            " AND t.text_type='VERS_VERS_DESC' AND t.record_status='LIVE' AND UPPER(t.lang_code) IN (?,'KO','EN')"
            " WHERE l.link_type='VERS_VERS' AND l.clicked_id=? AND l.target_id=?"
            " AND COALESCE(l.record_status,'LIVE')='LIVE'"
            " ORDER BY CASE WHEN UPPER(t.lang_code)=? THEN 0 WHEN UPPER(t.lang_code)='KO' THEN 1 ELSE 2 END LIMIT 1",
            (lang.upper(), a, b, lang.upper())).fetchone()
        nm = (rels.get(rel) or [rel])[0] if rel else ''
        body = (_text(conn, o, 'KRV' if lang.upper() == 'KO' else 'BSB', lang) or '').strip()
        line = '%s%s %s' % (range_label(conn, o, end, lang), (' (%s)' % nm) if nm else '', body[:90])
        if d and (d[0] or '').strip():
            line += ' — ' + ' '.join(d[0].split())[:160]
        out.append(line)
        if len(out) >= limit:
            break
    return NL.join(out)


def link_count_for(conn, start_vid, end_vid=None, lang='KO', limit=LINK_PICK_MAX):
    """화면 「함께 보내는 자료」 줄의 수 — 실제로 실리는 줄 수(`link_material` 과 같은 문)."""
    t = link_material(conn, start_vid, end_vid, lang, limit)
    return len([x for x in t.split(NL) if x.strip()]) if t else 0


# ══════════════════════════════════════════════════════════════════════
#  2026-10-15 — **출력서식 견본**(사용자 「출력서식 샘플을 몇가지 PC 에 만들어 놓고 그 명칭을 선택하면
#  간편 · 특히 모바일에서는 이런 방식」). 내용과 형식 ▸ 출력서식의 「벌」(`AI_PSET_FORMAT`)로 심는다 —
#  처음 한 번만(`AI_FMT_SEEDED`) · 사람이 고친 벌은 안 덮는다 · 지금 쓰던 서식이 첫 벌로 남는다.
# ══════════════════════════════════════════════════════════════════════
FORMAT_PRESETS = {
 'KO': [('대화식', '대화하듯 답해 주세요. 묻는 요지에 먼저 한두 문장으로 답하고, 필요한 설명은 짧은 문단 두세 개로 이어 가세요. 제목 · 번호 · 소제목은 쓰지 마세요.'),
        ('설명식', '문단으로 이어지는 설명글로 써 주세요. 소제목은 꼭 필요할 때만 쓰고, 목록보다 문장으로 풀어 주세요.'),
        ('요약식', '핵심만 짧게 정리해 주세요. 맨 위에 한 문장 요약, 그 아래 중요한 점 세 개에서 다섯 개를 한 줄씩 적어 주세요.'),
        ('개요식', '번호 개요로 정리해 주세요(1. → 1) → (1) 차례). 항목마다 한두 문장 설명을 붙여 주세요.'),
        ('도표사용 가능', '답은 문장으로 쓰고, 비교하거나 나열할 내용이 있을 때만 그 부분을 표로 정리해 주세요. 답 전체를 표로 쓰지는 마세요.'),
        ('묻고 답하기', '물음과 답의 꼴로 써 주세요. 물음은 짧게, 답은 두세 문장으로.'),
        ('설교 원고식', '설교 원고처럼 소리 내어 읽기 좋게 써 주세요. 서론 · 본론(대지) · 결론을 나누고 문장을 짧게 써 주세요.')],
 'EN': [('Conversational', 'Answer as in a conversation. Answer the point of the question first in one or two sentences, then continue with two or three short paragraphs if needed. Do not use headings, numbering or subheadings.'),
        ('Explanatory', 'Write flowing explanatory paragraphs. Use subheadings only when really needed, and explain in sentences rather than lists.'),
        ('Summary', 'Keep it short: a one-sentence summary at the top, then three to five key points, one line each.'),
        ('Outline', 'Arrange it as a numbered outline (1. → 1) → (1)). Add one or two sentences of explanation to each item.'),
        ('Tables allowed', 'Write the answer in sentences; only where there is something to compare or list, put that part in a table. Do not write the whole answer as a table.'),
        ('Questions and answers', 'Write it as questions and answers: short questions, answers of two or three sentences.'),
        ('Sermon manuscript', 'Write it like a sermon manuscript, easy to read aloud: introduction, body (points), conclusion, with short sentences.')],
}


#: ★ 2026-10-20 (사용자) 출력서식은 두 갈래 — **하나 선택**(답의 꼴: 대화식 · 설명식 · 요약식 …) /
#:   **복수 선택**(어떤 꼴과도 함께: 기호사용규칙 · 도표사용 가능 · 사람이 더한 것). 벌마다 `multi` 표시 · 켠 것은 `checked`.
#:   보낼 글의 출력서식 칸 = 하나 선택한 꼴 + 켠 복수 서식들(`format_text`).
FMT_MULTI_SEEDS = {
    'KO': [('기호사용규칙', '별표(*)나 샵(#) 같은 마크다운 기호와 이모지는 쓰지 마세요. 목록이 필요하면 1. 2. 처럼 숫자를 쓰세요.', True),
           ('도표사용 가능', None, False)],
    'EN': [('Symbol rules', 'Do not use Markdown symbols such as * or # or emoji. If a list is needed, number it 1. 2.', True),
           ('Tables allowed', None, False)],
}
FMT_MULTI_OLD = {'내 서식': '기호사용규칙', 'My format': 'Symbol rules', '표 정리': '도표사용 가능', 'Table': 'Tables allowed'}


def _fmt_multi_migrate(conn, lang='KO'):
    """한 번 — 옛 「내 서식」 → 기호사용규칙(복수 · 켬) · 「표 정리」 → 도표사용 가능(복수) · 없으면 견본을 더한다."""
    if (get_setting(conn, 'AI_FMT_MULTI1', '') or '').strip():
        return 0
    lg = (lang or 'KO').upper()
    d = part_sets(conn, 'FORMAT')
    items = d['items']
    checked = set(d.get('checked') or [])
    n = 0
    for i, it in enumerate(items):
        nm = (it.get('name') or '').strip()
        if nm in FMT_MULTI_OLD:
            it['name'] = FMT_MULTI_OLD[nm]
            it['multi'] = True
            if FMT_MULTI_OLD[nm] in ('기호사용규칙', 'Symbol rules'):
                checked.add(i)
            n += 1
    names = {(it.get('name') or '').strip() for it in items}
    for nm, body, on in (FMT_MULTI_SEEDS.get(lg) or FMT_MULTI_SEEDS['EN']):
        if nm in names:
            continue
        if body is None:
            body = next((b for n2, b in (FORMAT_PRESETS.get(lg) or FORMAT_PRESETS['EN']) if n2 == nm), '')
        items.append({'name': nm, 'body': body, 'multi': True})
        if on:
            checked.add(len(items) - 1)
        n += 1
    d['checked'] = sorted(checked)
    if items[d['on']].get('multi'):                       # 하나 선택이 복수 서식을 가리키면 첫 꼴로
        d['on'] = next((i for i, it in enumerate(items) if not it.get('multi')), 0)
        set_fmt(conn, items[d['on']].get('body', '') if not items[d['on']].get('multi') else '')
    _pset_save(conn, 'FORMAT', d)
    set_setting(conn, 'AI_FMT_MULTI1', '1')
    return n


def fmt_extras(conn):
    """켠 복수 서식들의 글(차례대로) — 하나 선택한 꼴 뒤에 붙는다."""
    d = _jget(conn, 'AI_PSET_FORMAT', None)
    if not isinstance(d, dict):
        return []
    on = set(d.get('checked') or [])
    return [(it.get('body') or '').strip() for i, it in enumerate(d.get('items') or [])
            if it.get('multi') and i in on and (it.get('body') or '').strip()]


def format_text(conn, fmt=None):
    """보낼 출력서식 = 하나 선택한 꼴(또는 `fmt`) + 켠 복수 서식들."""
    if fmt is not None and not (fmt or '').strip():
        return ''                                         # 일부러 비운 출력서식 = 아무것도 안 붙인다
    base = get_fmt(conn) if fmt is None else fmt.strip()
    return NL.join([x for x in [base] + fmt_extras(conn) if x])


def part_check(conn, part, i, on=None):
    """복수 서식 하나를 켜고 끈다 → 켰나."""
    d = part_sets(conn, part)
    if not 0 <= i < len(d['items']) or not d['items'][i].get('multi'):
        return False
    ck = set(d.get('checked') or [])
    want = (i not in ck) if on is None else bool(on)
    ck.add(i) if want else ck.discard(i)
    d['checked'] = sorted(ck)
    _pset_save(conn, part, d)
    return want


def part_set_multi(conn, part, i, multi):
    """벌 하나를 「복수 선택」 갈래로 옮기거나 되돌린다(하나 선택 중인 것은 못 옮긴다)."""
    d = part_sets(conn, part)
    if not 0 <= i < len(d['items']) or (multi and i == d['on']):
        return False
    d['items'][i]['multi'] = bool(multi)
    if not multi:
        d['checked'] = [x for x in (d.get('checked') or []) if x != i]
    _pset_save(conn, part, d)
    return True


#: ★ 2026-10-16 업무별 출력서식 — `{업무: 벌 이름, '*': 업무 기본}`(이름으로 기억 — 번호는 벌을 지우면 밀린다).
#:   사용자 「질문을 던지면 설교하듯 답한다」의 뿌리 = 개요식 출력서식 하나가 **모든 업무**에 붙었다.
FMT_BY_TASK_KEY = 'AI_FMT_BY_TASK'
#: 사람이 고르기 전의 업무 기본 서식(벌 이름 · 그 언어 → 영어)
#: ★ 설명문을 쓰는 업무는 「설명식」 — 개요식(제목 · 1. · 1)) 서식이 붙으면 설명문이 설교 원고처럼 나왔다
#:   (사용자 「원어 설명문 작성하라고 했는데 설교체로 작성하고 있음」).
TASK_FMT_DEFAULT = {'ASK': {'KO': '대화식', 'EN': 'Conversational'},
                    'DESC': {'KO': '설명식', 'EN': 'Explanatory'},
                    'XDESC': {'KO': '설명식', 'EN': 'Explanatory'},
                    'LINKAN': {'KO': '설명식', 'EN': 'Explanatory'},
                    'TERMAN': {'KO': '설명식', 'EN': 'Explanatory'},
                    # ★ 2026-10-21 창 1:31 성경공부 실측 — 정한 서식이 없는 질문은 **앞에서 고른 질문의 서식을 이어받아**
                    #   성경공부에 「대화식(제목·번호 쓰지 마세요)」이 실렸다 ⇒ 질문마다 기본 서식을 둔다
                    'STUDY': {'KO': '개요식', 'EN': 'Outline'},
                    'SERMON': {'KO': '설교 원고식', 'EN': 'Sermon manuscript'},
                    'NOTE': {'KO': '설명식', 'EN': 'Explanatory'},
                    'REFAN': {'KO': '설명식', 'EN': 'Explanatory'},
                    'SERMAN': {'KO': '설명식', 'EN': 'Explanatory'},
                    'SERMWR': {'KO': '설교 원고식', 'EN': 'Sermon manuscript'},
                    'TEACH': {'KO': '대화식', 'EN': 'Conversational'},
                    'BOOKMEDI': {'KO': '대화식', 'EN': 'Conversational'}}


def _fmt_name_for(conn, task, lang='KO'):
    m = _jget(conn, FMT_BY_TASK_KEY, {}) or {}
    t = (task or '').upper()
    if m.get(t):
        return m[t]
    dflt = TASK_FMT_DEFAULT.get(t)
    if dflt:
        return dflt.get((lang or 'KO').upper()) or dflt['EN']
    return m.get('*') or ''


def task_fmt_index(conn, task, lang='KO'):
    """그 업무가 쓸 출력서식 벌 번호 — 정한 것이 없으면 None(지금 벌 그대로)."""
    nm = _fmt_name_for(conn, task, lang)
    if not nm:
        return None
    d = part_sets(conn, 'FORMAT')
    for i, it in enumerate(d['items']):
        if (it.get('name') or '').strip() == nm:
            return i
    # 다른 언어 이름으로 심긴 견본도 알아본다(같은 자리의 견본 = 같은 서식)
    for rows in FORMAT_PRESETS.values():
        for k, (pn, _b) in enumerate(rows):
            if pn == nm:
                same = {r[k][0] for r in FORMAT_PRESETS.values() if len(r) > k}
                for i, it in enumerate(d['items']):
                    if (it.get('name') or '').strip() in same:
                        return i
    return None


def apply_task_fmt(conn, task, lang='KO'):
    """업무를 고르면 그 업무의 출력서식 벌로 — 바꾸었으면 True."""
    ensure_format_presets(conn, lang)
    i = task_fmt_index(conn, task, lang)
    if i is None or i == part_sets(conn, 'FORMAT')['on']:
        return False
    return part_select(conn, 'FORMAT', i)


def remember_task_fmt(conn, task, i):
    """사람이 그 업무에서 벌을 고르면 기억한다(다음에 그 업무를 고르면 그 벌)."""
    d = part_sets(conn, 'FORMAT')
    if not task or not 0 <= i < len(d['items']):
        return False
    m = _jget(conn, FMT_BY_TASK_KEY, {}) or {}
    m[task.upper()] = (d['items'][i].get('name') or '').strip() or ('#%d' % (i + 1))
    _jset(conn, FMT_BY_TASK_KEY, m)
    return True


def ensure_format_presets(conn, lang='KO'):
    """출력서식 벌에 견본을 심는다 — 한 번만. 돌려주는 값 = 심은 수.

    ★ 2026-10-16 「대화식」 견본은 따로 한 번 더 심는다(`AI_FMT_SEEDED2` · 이미 심은 PC 에도).
    """
    if (get_setting(conn, 'AI_FMT_SEEDED', '') or '').strip():
        if (get_setting(conn, 'AI_FMT_SEEDED2', '') or '').strip():
            return _fmt_multi_migrate(conn, lang)
        lg = (lang or 'KO').upper()
        nm, body = (FORMAT_PRESETS.get(lg) or FORMAT_PRESETS['EN'])[0]
        d = part_sets(conn, 'FORMAT')
        n = 0
        if not any((it.get('name') or '').strip() in (nm, '대화식', 'Conversational') for it in d['items']):
            d['items'].append({'name': nm, 'body': body})
            _pset_save(conn, 'FORMAT', d)
            n = 1
        set_setting(conn, 'AI_FMT_SEEDED2', '1')
        return n + _fmt_multi_migrate(conn, lg)
    lg = (lang or 'KO').upper()
    pre = FORMAT_PRESETS.get(lg) or FORMAT_PRESETS['EN']
    d = part_sets(conn, 'FORMAT')
    have = {(it.get('name') or '').strip() for it in d['items']}
    items = d['items']
    if len(items) == 1 and not (items[0].get('name') or '').strip():
        items[0]['name'] = '내 서식' if lg == 'KO' else 'My format'
        if not (items[0].get('body') or '').strip():
            items[0]['name'] = '지정 안 함' if lg == 'KO' else 'None'
    n = 0
    for nm, body in pre:
        if nm not in have:
            items.append({'name': nm, 'body': body})
            n += 1
    _pset_save(conn, 'FORMAT', d)
    set_setting(conn, 'AI_FMT_SEEDED', '1')
    set_setting(conn, 'AI_FMT_SEEDED2', '1')
    return n + _fmt_multi_migrate(conn, lg)


def ref_task_of(conn, anchor):
    """★ 317차-16 — 연구/설교노트 닻의 갈래가 정하는 처음 업무 — 내 글이 설교(`ref_type='SERMON'`)면 SERMAN.

    ⚠ 공용 연구자료(`REF_UNIT:`)는 늘 REFAN · 못 읽으면 REFAN.
    """
    a = str(anchor or '')
    if a.startswith('BOOK_UNIT:'):
        return 'BOOKMEDI'                    # ★ 81 — 도서 편 = 도서 묵상
    if a.startswith('USER_REF:'):
        try:
            r = conn.execute("SELECT ref_type FROM user_ref_asset WHERE ref_id=?",
                             (int(a.split(':', 1)[1]),)).fetchone()
            if r and str(r[0] or '').upper() == 'SERMON':
                return 'SERMAN'
        except Exception:                                 # noqa: BLE001
            pass
    return 'REFAN'


def role_kind(task):
    t = (task or '').upper()
    if t.startswith('UT_'):
        return 'UR_' + t[3:]                              # ★ 317차-14 — 내 업무의 역할
    return ROLE_OF_TASK.get(t, '')


def task_texts(conn, scope, task=None, mode=None, lang='KO'):
    """(역할, 할 일) 글 — **자리표는 채우지 않는다**(채움은 `fill_prompt` 한 문).

    ⚠ Free 는 할 일이 없다 — 역할만 낸다(사용자 「업무 유형 버튼은 없다」).
    """
    t = task if task is not None else get_task(conn, scope)
    # ★ 2026-10-27 홈 AI 대화 갈래 — 업무 글은 라이브러리 자리에서(역할은 공통 역할)
    if (scope or '').upper() == 'FREE' and (t or '').upper() in HOME_PLACE:
        return task_row(conn, ROLE_KIND, lang)[2], home_task_body(conn, t, lang)
    if (t or '').upper() in ('HOME_MEDI', 'HOME_FIND'):   # ★ 2026-10-31 말씀 그룹의 라이브러리 자리 업무
        return task_row(conn, ROLE_KIND, lang)[2], home_task_body(conn, t, lang)
    role = task_row(conn, role_kind(t), lang)[2] if role_kind(t) else ''
    if not role:
        role = task_row(conn, ROLE_KIND, lang)[2]
    m = mode if mode is not None else get_rmode(conn)
    body = task_row(conn, task_kind(scope, t, m), lang)[2]
    # ★ 2026-10-21 사용자 「맨 아래에 [삶의 변화]라는 새로운 값을 표시하고 있다」 — 설명문 업무는 칸이 정해져 있다.
    #   묻는 사람 칸(「끝에 … 한 대목」 등)이 새 칸을 낳았다 ⇒ 칸 이름을 대고 그 밖의 칸을 만들지 않게(PC·폰 함께 — 폰은 이 글을 받는다)
    tt = (t or '').upper()
    if body and tt in ('DESC', 'XDESC') and (scope or 'VERSE').upper() == 'VERSE':
        ms = DESC_MARKS.get((lang or 'KO').upper()) or DESC_MARKS['EN']
        cells = ' '.join('[%s]' % x for x in ((ms[0], ms[1], ms[2]) if tt == 'DESC' else (ms[4], ms[3])))
        body = body.rstrip() + NL + (DESC_CELLS_ONLY.get((lang or 'KO').upper()) or DESC_CELLS_ONLY['EN']) % cells
    return role, body


#: 설명문 업무 — 쓰는 칸만(그 언어 칸 이름 · 없는 언어는 영어)
DESC_CELLS_ONLY = {'KO': '칸은 %s만 씁니다. 다른 칸을 새로 만들지 않습니다.',
                   'EN': 'Write only the sections %s. Do not add any other section.'}


def _is_pick(kind, genre):
    return str(kind).upper().startswith('USER') or (kind not in TASK_SUPERSEDED and genre == PICK_GENRE)


def pick_key(scope, task):
    """Pick 이 사는 자리 `(갈래, 업무)` — Free 는 구절 갈래의 **제 자리 `FREE`** 다."""
    sc = (scope or 'VERSE').upper()
    if sc == 'FREE':
        return 'VERSE', 'FREE'
    return sc, (task or '').upper()


def _ensure_task_picks(conn, lang, scope, task):
    """그 업무의 Pick 이 아직 없으면 **공용 줄을 베껴** 업무 사본을 만든다(한 번만).

    ★ 사본이라 한 업무에서 지우고 고치고 더한 것이 다른 업무에 안 번진다.
    ⚠ 317차 화면이 공용 줄을 바로 지웠던 씨앗(사람이 한 업무에서 지운 것)은
      **설명문 작성(DESC) 밖의 업무**에 되살린다 — 사용자는 거기서만 지웠다.
    """
    lg = (lang or 'KO').upper()
    sc, tk = scope, task
    if not tk:
        return 0
    if conn.execute("SELECT 1 FROM user_ai_pick_seeded WHERE lang_code=? AND scope=? AND task=?",
                    (lg, sc, tk)).fetchone():
        return 0
    n = 0
    if tk in TASK_PICK_SEEDS or tk == 'FREE':
        # ★ 317차-5 — 묵상노트·연구자료 분석·교사는 사용자가 적은 예시로 · Free 는 예제 없음
        for i, (kind, tx) in enumerate(TASK_PICK_SEEDS.get(tk, [])):
            title, body = tx.get(lg) or tx['EN']
            conn.execute("INSERT INTO user_ai_prompt(lang_code, kind, title, body, sort_order, scope, genre, task)"
                         " VALUES(?,?,?,?,?,?,?,?)", (lg, kind, title, body, (i + 1) * 10, sc, PICK_GENRE, tk))
            n += 1
        conn.execute("INSERT OR IGNORE INTO user_ai_pick_seeded(lang_code, scope, task) VALUES(?,?,?)",
                     (lg, sc, tk))
        conn.commit()
        return n
    rows = conn.execute("SELECT kind, title, body, sort_order, genre, record_status FROM user_ai_prompt"
                        " WHERE lang_code=? AND scope=? AND COALESCE(task,'')=''"
                        " ORDER BY sort_order, prompt_id", (lg, sc)).fetchall()
    for kind, title, body, so, genre, st in rows:
        g = genre_of(kind, genre)
        if not _is_pick(kind, g):
            continue
        live = (st or 'LIVE') == 'LIVE'
        if not live and (str(kind).upper().startswith('USER') or tk == 'DESC'):
            continue
        conn.execute("INSERT INTO user_ai_prompt(lang_code, kind, title, body, sort_order, scope, genre, task)"
                     " VALUES(?,?,?,?,?,?,?,?)", (lg, kind, title, body, so, sc, g, tk))
        n += 1
    conn.execute("INSERT OR IGNORE INTO user_ai_pick_seeded(lang_code, scope, task) VALUES(?,?,?)",
                 (lg, sc, tk))
    conn.commit()
    return n


def pick_prompts(conn, lang='KO', scope='VERSE', task=None, place=None):
    """창고(Pick) 목록 — **그 업무의 것만**(317차-5). 업무를 안 주면 그 갈래에서 선택한 업무.

    ★ 사람이 만든 것(`USER…`)은 성격과 상관없이 남긴다 — 사람이 쓴 글을 잃지 않는다.
    ⚠ Free 는 제 자리(`VERSE`·`FREE`)를 갖는다 — 닻이 없으니 자리표는 「이 본문」으로 채운다.
    """
    ensure_seeds(conn)
    if task is None:
        task = get_task(conn, scope)
    sc, tk = pick_key(scope, task)
    lg = (lang or 'KO').upper()
    lib = _lib(conn)
    if lib is not None:
        # ★★ 2026-10-20 프롬프트 라이브러리(ai_lib) — Pick 은 한 벌을 자리들이 같이 쓴다.
        #   번호 = **음수 lib_id**(옛 프롬프트 번호와 안 부딪힌다 · 폰은 정수로 받는다)
        #   ★ 2026-10-21 1:1 — 자리마다 제 사본(`열쇠~자리`) · `place` 를 주면 그 자리(도서노트 분석 등)
        return [(-r[0], re.split(r'[@~]', r[1])[0], r[2], r[3], PICK_GENRE)
                for r in lib.place_rows(conn, place or '%s:%s' % (sc, TASK_ALIAS_LIB.get(tk, tk)), lg, 'PICK')]
    _ensure_task_picks(conn, lg, sc, tk)
    rows = prompts(conn, lg, sc, tk)
    if not rows and lg != 'EN':
        _ensure_task_picks(conn, 'EN', sc, tk)
        rows = prompts(conn, 'EN', sc, tk)
    return [r for r in rows if _is_pick(r[1], r[4])]


#: 옛 업무 열쇠 → 라이브러리 자리(ai_lib.TASK_ALIAS 와 같다)
TASK_ALIAS_LIB = {'RESEARCH': 'ASK'}


def pick_place(scope, task):
    """그 업무의 라이브러리 자리 열쇠 `갈래:업무`(Free = `VERSE:FREE`)."""
    sc, tk = pick_key(scope, task)
    return '%s:%s' % (sc, TASK_ALIAS_LIB.get(tk, tk))


def _lib(conn):
    """라이브러리를 쓰고 있으면 그 모듈 · 아니면 None(옮기기 전 · 되돌린 뒤엔 옛 업무별 사본)."""
    try:
        import ai_lib
        return ai_lib if ai_lib.lib_on(conn) else None
    except Exception:                                     # noqa: BLE001
        return None


def _lib_id(prompt_id):
    try:
        return -int(prompt_id) if int(prompt_id) < 0 else None
    except (TypeError, ValueError):
        return None


#: ★ 2026-10-20 (docs/1.txt 9-8) 성경교사 질문 횟수 — Pick 글의 자리표를 화면에서 적은 수로 채운다(기본 5)
TEACH_N_KEY = 'AI_TEACH_N'
TEACH_N_TOKENS = ('[질문횟수]', '[questions]')
#: 옛 씨앗 글 → 새 글(사람이 안 고친 줄만 옮긴다 · `renew_teach`)
TEACH_RENEW = {('TP_TEACH_1', 'KO'): ('질문은 모두 다섯 번까지만 하세요.', '질문은 모두 [질문횟수]번까지만 하세요.'), ('TP_TEACH_1', 'EN'): ('Ask no more than five questions in all.', 'Ask no more than [questions] questions in all.'),
               ('T_TEACH', 'KO'): ('다섯 질문쯤 뒤에 함께 배운 것을 정리해 주세요.', '질문을 마칠 때가 되면 함께 배운 것을 정리해 주세요.'), ('T_TEACH', 'EN'): ('After about five questions, sum up what we learned.', 'When the questions are over, sum up what we learned.')}


def teach_n(conn):
    try:
        n = int(get_setting(conn, TEACH_N_KEY, '5') or 5)
    except ValueError:
        n = 5
    return max(1, min(20, n))


def fill_teach_n(text, n):
    for tok in TEACH_N_TOKENS:
        text = (text or '').replace(tok, str(n))
    return text


def renew_teach(conn):
    """옛 씨앗 그대로인 줄만 새 글로(교사 질문 횟수 자리표 · 「다섯 질문쯤」 걷음) — 멱등."""
    n = 0
    for (kind, lg), (old, new) in TEACH_RENEW.items():
        for row in conn.execute("SELECT prompt_id, body FROM user_ai_prompt WHERE kind=? AND lang_code=?", (kind, lg)).fetchall():
            b = row[1] or ''
            if old in b:
                conn.execute("UPDATE user_ai_prompt SET body=? WHERE prompt_id=?", (b.replace(old, new), row[0]))
                n += 1
    return n


def merge_prompt_body(conn, lang='KO'):
    """[이 채팅을 한 글로] 단추가 보내는 글 — 옛 통합형(MERGE) 씨앗을 그대로 쓴다."""
    ensure_seeds(conn)
    _renew_merge(conn)
    for lg in ((lang or 'KO').upper(), 'EN'):
        r = conn.execute("SELECT body FROM user_ai_prompt WHERE kind='MERGE' AND lang_code=?"
                         " AND record_status='LIVE' ORDER BY prompt_id LIMIT 1", (lg,)).fetchone()
        if r and (r[0] or '').strip():
            return r[0]
    return (SEED_PROMPTS.get('MERGE', {}).get('EN') or ('', ''))[1]


def _renew_merge(conn):
    """★ 2026-10-21 옛 「한 글로」 지시(이해한 것 · 남은 물음 · 끝 낱말만 다른 것도)를 새 글로 — 한 번만(`AI_MERGE_RENEW`).
    옛 글은 `AI_MERGE_OLD` 에 남긴다(되돌릴 자리)."""
    if get_setting(conn, 'AI_MERGE_RENEW', ''):
        if not get_setting(conn, 'AI_MERGE_RENEW3', ''):
            for pid, lg, body in conn.execute("SELECT prompt_id, lang_code, body FROM user_ai_prompt WHERE kind='MERGE'"
                                              " AND lang_code IN ('KO','EN')").fetchall():
                if '물음마다 소제목을 붙이세요' in (body or '') or 'Give each question a subheading. Add nothing new.' in (body or ''):
                    conn.execute("UPDATE user_ai_prompt SET body=? WHERE prompt_id=?", (MERGE_KO if lg == 'KO' else MERGE_EN, pid))
            set_setting(conn, 'AI_MERGE_RENEW3', time.strftime('%Y-%m-%d %H:%M:%S'))
            conn.commit()
        if not get_setting(conn, 'AI_MERGE_RENEW2', ''):
            for pid, lg, body in conn.execute("SELECT prompt_id, lang_code, body FROM user_ai_prompt WHERE kind='MERGE'"
                                              " AND lang_code IN ('KO','EN')").fetchall():
                if (body or '').startswith('아래 대화 전체를 [구절] 에 대한 한 편의 글로 엮어 주세요. 대화에서 다룬 물음과 답을 하나도'
                                           ' 빠뜨리지 말고 다룬 차례대로 모두 담되') or                         (body or '').startswith('Weave the whole conversation below into one text on [passage]. Include every'
                                                ' question and answer that was discussed, in the order they came, leaving nothing out;'):
                    conn.execute("UPDATE user_ai_prompt SET body=? WHERE prompt_id=?", (MERGE_KO if lg == 'KO' else MERGE_EN, pid))
            set_setting(conn, 'AI_MERGE_RENEW2', time.strftime('%Y-%m-%d %H:%M:%S'))
            conn.commit()
        return
    for pid, lg, body in conn.execute("SELECT prompt_id, lang_code, body FROM user_ai_prompt WHERE kind='MERGE'"
                                      " AND lang_code IN ('KO','EN')").fetchall():
        old = (body or '')
        if (lg == 'KO' and old.startswith(MERGE_OLD_KO)) or (lg == 'EN' and 'what I understood' in old):
            set_setting(conn, 'AI_MERGE_OLD_' + lg, old)
            conn.execute("UPDATE user_ai_prompt SET body=? WHERE prompt_id=?", (MERGE_KO if lg == 'KO' else MERGE_EN, pid))
    set_setting(conn, 'AI_MERGE_RENEW', time.strftime('%Y-%m-%d %H:%M:%S'))
    conn.commit()


def merge_prompt_row(conn, lang='KO'):
    """라이브러리가 고치는 줄 — `(prompt_id, 제목, 글)`(그 언어 · 없으면 영어)."""
    merge_prompt_body(conn, lang)
    for lg in ((lang or 'KO').upper(), 'EN'):
        r = conn.execute("SELECT prompt_id, title, body FROM user_ai_prompt WHERE kind='MERGE' AND lang_code=?"
                         " AND record_status='LIVE' ORDER BY prompt_id LIMIT 1", (lg,)).fetchone()
        if r:
            return r
    return (None, '', '')


def _migrate_tasks(conn):
    """옛 성격 씨앗(이해 확인·성경공부·교사·노트·연구자료 분석)을 **사람이 고쳤으면**
    그 글을 새 업무 줄로 옮긴다. 안 고쳤으면 새 씨앗이 들어간다.

    ⚠ 이미 새 줄이 있으면 안 건드린다(멱등) · 옛 줄은 지우지 않는다(되돌릴 자리).
    """
    have = {(r[0], r[1]) for r in conn.execute(
        "SELECT lang_code, kind FROM user_ai_prompt WHERE scope='TASK'")}
    n = 0
    for old, new in OLD_TO_TASK.items():
        seeds = (SEED_PROMPTS.get(old) or SEED_TERM.get(old) or SEED_REF.get(old) or {})
        for lg, body in conn.execute(
                "SELECT lang_code, body FROM user_ai_prompt WHERE kind=?"
                " AND record_status='LIVE'", (old,)).fetchall():
            if (lg, new) in have:
                continue
            seed_b = (seeds.get(lg) or ('', ''))[1]
            if not (body or '').strip() or (body or '').strip() == (seed_b or '').strip():
                continue                                  # 안 고쳤다 — 새 씨앗이 들어간다
            seed = (SEED_TASK.get(new) or {}).get(lg) or (SEED_TASK.get(new) or {}).get('EN')
            conn.execute("INSERT INTO user_ai_prompt(lang_code, kind, title, body, sort_order,"
                         " scope, genre) VALUES(?,?,?,?,?,'TASK',?)",
                         (lg, new, seed[0] if seed else new, body,
                          TASK_ALL.index(new) * 10, 'ANAL'))
            have.add((lg, new))
            n += 1
    return n


def split_desc(text, lang='KO'):
    """설명문 작성의 답 → `{칸: 글}`. 그 언어 칸 이름을 한국어 칸으로 되읽고 나눈다.

    ★ 나누는 문은 `db_ai_job.bundle_split` **하나**다 — 관리자 묶음과 같은 규칙.
    반환은 `bundle_split` 그대로 — `({…}, 까닭)` 또는 `(None, 까닭)`.
    """
    import re as _re
    import db_ai_job as _J
    marks = DESC_MARKS.get((lang or 'KO').upper()) or DESC_MARKS['EN']
    t = text or ''
    for loc, ko in zip(marks, _DESC_KO):
        t = _re.sub(r'(?m)^\[\s*' + _re.escape(loc) + r'\s*\]\s*$', '[%s]' % ko, t)
    # ★ 317차 — **적힌 칸만** 묻는다. 관리자 묶음은 필수 칸이 빠지면 「반쪽」으로 거부하는데
    #   사용자 저장은 사람이 칸을 지우고 고칠 수 있다 — 설명문·기도만 남겨도 그 둘을 담는다.
    #   ⚠ 그 거부에 걸리면 답 전체가 설명문 칸 하나로 들어갔다(하네스가 잡았다).
    present = [k for k, ko in zip(('DESC', 'QUES', 'PRAYER', 'STUDY', 'XDESC'), _DESC_KO)
               if _re.search(r'(?m)^\[' + _re.escape(ko) + r'\]\s*$', t)]
    if not present:
        return None, '칸 표시를 찾지 못했습니다.'
    if 'XDESC' not in present:
        return _J.bundle_split(t, present)
    # ★ 2026-10-14 전문설명문 — 관리자 묶음 칸 표는 「전문 설명」을 모른다(관리자 일괄 작업을 안 건드린다).
    #   같은 규칙(아는 칸에서 시작 · 다음 대괄호 머리에서 끝)으로 여기서 나눈다.
    name2key = dict(zip(_DESC_KO, ('DESC', 'QUES', 'PRAYER', 'STUDY', 'XDESC')))
    heads = list(_re.finditer(r'(?m)^\[([^\]\n]{1,24})\]\s*$', t))
    out = {}
    for i, h in enumerate(heads):
        k = name2key.get(h.group(1))
        if not k:
            continue
        end = heads[i + 1].start() if i + 1 < len(heads) else len(t)
        body = t[h.end():end].strip()
        if body and body not in ('없음', '(없음)', 'None', '-'):
            out[k] = body
    return (out, '') if out else (None, '칸 표시를 찾지 못했습니다.')


def compose_parts(conn, bodies=None, question='', lang='KO', depth=None, view=None,
                  free=None, with_axes=True, fmt=None, ban=None, role=None, task=None,
                  picks=None, state=None, faith=None, parts=None, keep_version=False):
    """★★★ **보낼 프롬프트의 칸들**(차례 고정) → `[(칸, 머리말, 글)]` — 빈 칸도 자리를 지킨다.

    ★ 317차 — 관리자 프롬프트 탭처럼 **칸이 고정된 자리**에 쌓인다(docs/1.txt 2 ·
      사용자 「각 영역을 나누어서 고정된 자리에 배치하고 pick 을 여러개 선택하거나 금지,
      출력서식 등을 통합하여 누적되어 표시」). 화면은 이것을 그리고, `compose` 는 이것을
      글로 잇는다 — **보이는 것 = 보내는 것**(조립하는 문이 하나다).
    · 차례 = `SLOTS`(역할 → 할 일 → 물음 → 자유 → 함께 다룰 것 → 묻는 사람 → 문체 → 반드시 →
      성경 인용 → 분량 → 예시 → 하지 말 것 → 답의 모양).
    · `bodies` 는 옛 호출부의 「고른 프롬프트 본문」이다 — `task` 가 없으면 「할 일」 칸이 된다.
    · `picks` = Pick 본문들 — **목록 차례로** 번호를 붙여 쌓는다.
    · 상태·신앙 배경·관점은 「묻는 사람」 한 칸에 모은다(`with_axes=False` 면 비운다).
    """
    lg = (lang or 'KO').upper()
    head = slot_head(lg)
    if isinstance(bodies, str):
        bodies = [bodies]
    t = (task if task is not None else join_bodies(bodies or [])).strip()
    q = (question or '').strip()
    if q and t and quest_slot(lg) and quest_slot(lg) in t:
        t, q = fill_question(t, q, lg).strip(), ''        # 옛 자리표가 있으면 그 자리에
    pk = [x for x in (_pick_pair(p) for p in (picks or [])) if x[1]]
    if any(t in b for _n, b in pk for t in TEACH_N_TOKENS):  # ★ 2026-10-20 교사 질문 횟수 — 적어 둔 수로
        _tn = teach_n(conn) if conn is not None else 5
        pk = [(n, fill_teach_n(b, _tn)) for n, b in pk]
    pick_txt = each_block(pk, lg)                           # ★ 2026-10-24 둘 이상이면 항목별로 답하라
    asker = ''
    if with_axes:
        st = state if state is not None else depth
        asker = NL.join(axis_bodies(conn, lg, depth=st, view=view, faith=faith))
    fr = get_free(conn) if free is None else (free or '').strip()
    pv = dict(parts or {})
    vals = {'ROLE': (role or '').strip(), 'TASK': t, 'QUESTION': q, 'FREE': fr,
            'PICK': pick_txt, 'ASKER': asker}
    for p, _k in PARTS:
        if p == 'BAN':
            v = get_ban(conn) if ban is None else (ban or '').strip()
        elif p == 'FORMAT':
            v = format_text(conn, fmt)                    # ★ 2026-10-20 하나 선택한 꼴 + 켠 복수 서식
        elif p in pv:
            v = pv.get(p) or ''
        elif p == 'CITE':
            v = (get_setting(conn, PART_KEY['CITE'], '') or '').strip() or cite_default(conn, lg, token=keep_version)
        else:
            v = get_part(conn, p)
        vals[p] = (v or '').strip()
    return [(s, head[s], vals.get(s, '')) for s in SLOTS]


def compose(conn, bodies, question='', lang='KO', depth=None, view=None,
            free=None, with_axes=True, fmt=None, ban=None, **kw):
    """★★★ **보낼 프롬프트를 만드는 단일 문** — `compose_parts` 를 칸 머리말과 함께 잇는다.

    ⚠⚠⚠ **화면과 `send` 가 이 한 문을 쓴다**(§219차 ⑤).
    ★ 317차 — 칸마다 **[머리말]** 을 붙인다. 문단만 이어 붙이면 AI 가 출력서식 본보기를
      답의 내용으로, 금지사항을 물음의 일부로 읽는 일이 생긴다.
    ⚠ **빈 칸은 보내지 않는다**(화면에서는 자리를 지키지만 글에는 머리말째 뺀다).
    """
    keep_version = kw.get('keep_version', False)    # ★ 폰 꾸러미 — 폰이 제 역본으로 채운다
    rows = compose_parts(conn, bodies, question, lang, depth, view, free, with_axes,
                         fmt, ban, **kw)
    out = (NL + NL).join('[%s]%s%s' % (h, NL, v) for _s, h, v in rows if v)
    return out if keep_version else fill_version(conn, out, lang)


def set_genre(conn, prompt_id, genre):
    """그 프롬프트의 성격을 바꾼다 — 모르는 값은 안 적는다(화면이 거짓말하지 않게)."""
    init(conn)
    g = (genre or '').strip().upper()
    if g not in GENRE_KEYS:
        return False
    conn.execute("UPDATE user_ai_prompt SET genre=? WHERE prompt_id=?", (g, int(prompt_id)))
    conn.commit()
    return True


def prompts(conn, lang='KO', scope='VERSE', task=''):
    """그 언어·갈래의 프롬프트 — 없으면 영어.
    `[(prompt_id, kind, title, body, **genre**)]`(303차에 성격 칸이 늘었다).
    갈래 = VERSE(구절) / TERM(용어). 사람이 더한 것(kind='USER…')도 함께."""
    ensure_seeds(conn)
    lg = (lang or 'KO').upper()
    sc = (scope or 'VERSE').upper()
    tk = (task or '').upper()
    q = ("SELECT prompt_id, kind, title, body, genre FROM user_ai_prompt"
         " WHERE lang_code=? AND scope=? AND COALESCE(task,'')=?"
         " AND record_status='LIVE' ORDER BY sort_order, prompt_id")
    rows = conn.execute(q, (lg, sc, tk)).fetchall()
    if not rows and lg != 'EN':
        rows = conn.execute(q, ('EN', sc, tk)).fetchall()
    # ⚠ **성격이 비어 있어도 낸다** — 옛 줄은 갈래 표로 읽는다(조용히 빠지지 않게).
    return [(r[0], r[1], r[2], r[3], genre_of(r[1], r[4])) for r in rows]


def save_prompt(conn, prompt_id, title, body, genre=None):
    """이름·본문(그리고 성격)을 적는다 — 성격은 **줄 때만** 바꾼다(안 주면 그대로)."""
    lid = _lib_id(prompt_id)
    if lid is not None:                                   # 라이브러리 항목 — 그 줄(언어)에 적는다
        import ai_lib
        r = ai_lib.row_of(conn, lid)
        if r:
            ai_lib.save_item(conn, r[0], r[1], title, body)
        return
    conn.execute("UPDATE user_ai_prompt SET title=?, body=? WHERE prompt_id=?", (title, body, prompt_id))
    if (genre or '').strip().upper() in GENRE_KEYS:
        conn.execute("UPDATE user_ai_prompt SET genre=? WHERE prompt_id=?",
                     ((genre or '').strip().upper(), prompt_id))
    conn.commit()


def add_prompt(conn, lang, scope, title, body, genre=GENRE_DEFAULT, task=''):
    """사용자가 **새 프롬프트**를 더한다 — 갈래 열쇠는 `USER<번호>`(씨앗과 안 부딪힌다).
    299차 사용자 「프롬프트 콤보항목을 더 추가하거나 항목이름을 수정하고 프롬프트를 창의적으로
    입력할 수 있도록」."""
    init(conn)
    lg = (lang or 'KO').upper()
    sc = (scope or 'VERSE').upper()
    lib = _lib(conn) if (task or '').strip() else None
    if lib is not None:                                   # ★ 라이브러리에 더하고 이 자리에서 쓴다
        tk = (task or '').upper()
        key = lib.add_item(conn, lg, (title or '').strip() or '새 프롬프트', (body or '').strip(),
                           places=('%s:%s' % (sc, TASK_ALIAS_LIB.get(tk, tk)),))
        r = conn.execute("SELECT lib_id FROM user_ai_lib WHERE item_key=? AND lang_code=?", (key, lg)).fetchone()
        return -int(r[0])
    mx = conn.execute("SELECT COALESCE(MAX(sort_order),0) FROM user_ai_prompt WHERE lang_code=? AND scope=?",
                      (lg, sc)).fetchone()[0]
    g = (genre or '').strip().upper()
    if g not in GENRE_KEYS:
        g = GENRE_DEFAULT
    cur = conn.execute("INSERT INTO user_ai_prompt(lang_code, kind, title, body, sort_order, scope, genre, task)"
                       " VALUES(?,?,?,?,?,?,?,?)", (lg, 'USER', (title or '').strip() or '새 프롬프트',
                                                    (body or '').strip(), int(mx) + 10, sc, g,
                                                    (task or '').upper()))
    conn.commit()
    pid = int(cur.lastrowid)
    conn.execute("UPDATE user_ai_prompt SET kind=? WHERE prompt_id=?", ('USER%d' % pid, pid))
    conn.commit()
    return pid


def hide_prompt(conn, prompt_id, place=None):
    """지운다 — 라이브러리 항목이면 **그 자리에서만 뗀다**(다른 자리는 그대로 쓴다) · 자리를 안 주면 라이브러리에서 지운다."""
    lid = _lib_id(prompt_id)
    if lid is not None:
        import ai_lib
        r = ai_lib.row_of(conn, lid)
        if r:
            if place:
                ai_lib.set_used(conn, place, r[0], False)
                if not ai_lib.places_of(conn, r[0]):      # 어느 자리에서도 안 쓰면 라이브러리에서도 지운다
                    ai_lib.hide_item(conn, r[0])
            else:
                ai_lib.hide_item(conn, r[0])
        return
    conn.execute("UPDATE user_ai_prompt SET record_status='HIDE' WHERE prompt_id=?", (prompt_id,))
    conn.commit()


# ══════════════════════════════════════════════════════════════════════
#  대화 = 자산 하나
# ══════════════════════════════════════════════════════════════════════
def _now():
    return time.strftime('%Y-%m-%d %H:%M:%S')


def new_chat(conn, start_vid=None, end_vid=None, lang='KO', title='', kind='ASK', entity_id=None,
             ref_anchor=None, free=False):
    """대화 하나 — 닻은 구절(구간) · **용어**(scope TERM) · **연구자료**(scope REF · 303차)."""
    init(conn)
    st = settings(conn)
    lg = (lang or 'KO').upper()
    if free:
        # ★ 317차 — **Free** = 닻 없는 채팅(사용자가 P1·캔버스를 아직 안 눌렀을 때)
        start_vid = end_vid = entity_id = ref_anchor = None
        title = title or 'Free'
        scope = 'FREE'
    elif ref_anchor and str(ref_anchor).startswith(LEMMA_PFX):
        title = title or lemma_label(conn, str(ref_anchor)[len(LEMMA_PFX):])
        scope = 'TERM'
    elif ref_anchor and str(ref_anchor).startswith(LINK_PFX):
        # ★ 2026-10-14 연결 하나를 닻으로 — 구절 갈래 그대로(재료는 `materials_link`)
        title = title or link_title(conn, str(ref_anchor)[len(LINK_PFX):], lg)
        scope = 'VERSE'
    elif ref_anchor:
        title = title or ref_name(conn, ref_anchor, lg)
        scope = 'REF'
    elif entity_id:
        title = title or term_name(conn, entity_id, lg)
        scope = 'TERM'
    else:
        title = title or range_label(conn, start_vid, end_vid, lg)
        scope = 'VERSE'
    cur = conn.execute(
        "INSERT INTO user_ai_chat(start_vid, end_vid, title, lang_code, provider, model,"
        " prompt_kind, created_at, updated_at, entity_id, scope, ref_anchor)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        (int(start_vid) if start_vid else None, int(end_vid or start_vid) if start_vid else None, title, lg,
         st['provider'], st['model'], kind, _now(), _now(), int(entity_id) if entity_id else None, scope,
         (ref_anchor or None)))
    # ★ 2026-10-20 대화 번호(폰과 함께 쓰기) · 함께 쓰기 처음 값(설정)
    try:
        import secrets as _sec
        _sh = True                                         # ★ 2026-10-21 모든 대화를 함께 쓴다(옛 설정 안 읽음)
        conn.execute("UPDATE user_ai_chat SET phone_uid=?, share=?, share_sent=? WHERE chat_id=?",
                     (_sec.token_hex(8), 1 if _sh else 0, 1 if _sh else 0, int(cur.lastrowid)))
    except Exception:                                     # noqa: BLE001
        pass
    conn.commit()
    return int(cur.lastrowid)


def chats_for(conn, start_vid=None, end_vid=None, limit=50, entity_id=None, scope=None,
              ref_anchor=None):
    """닻이 같은 대화 — 구절(정확히 같은 구간) 또는 용어. 둘 다 안 주면 최근 전부(갈래로 거를 수 있다)."""
    init(conn)
    q = ("SELECT c.chat_id, c.title, c.start_vid, c.end_vid, c.updated_at,"
         " (SELECT COUNT(*) FROM user_ai_msg m WHERE m.chat_id=c.chat_id), c.prompt_kind,"
         " c.entity_id, COALESCE(c.scope,'VERSE')"
         " FROM user_ai_chat c WHERE c.record_status='LIVE'")
    ar = []
    if ref_anchor:
        q += " AND c.ref_anchor=?"
        ar.append(str(ref_anchor))
    elif entity_id:
        q += " AND c.entity_id=?"
        ar.append(int(entity_id))
    elif start_vid:
        q += " AND c.start_vid=? AND c.end_vid=? AND c.entity_id IS NULL"
        ar += [int(start_vid), int(end_vid or start_vid)]
    elif str(scope or '').upper() == 'BOOK':          # ★ 2026-10-21 도서 — 도서 묵상(편 닻) · 도서노트 분석
        q += " AND (COALESCE(c.ref_anchor,'') LIKE 'BOOK_UNIT:%' OR COALESCE(c.prompt_kind,'') LIKE 'T:%:BOOK')"
    elif str(scope or '').upper() == 'REF':
        q += " AND COALESCE(c.scope,'VERSE')='REF' AND COALESCE(c.ref_anchor,'') NOT LIKE 'BOOK_UNIT:%'"
    elif scope:
        q += " AND COALESCE(c.scope,'VERSE')=?"
        ar.append(str(scope).upper())
        if str(scope).upper() == 'VERSE':
            q += " AND COALESCE(c.prompt_kind,'') NOT LIKE 'T:%:BOOK'"
    q += " ORDER BY c.updated_at DESC LIMIT ?"
    ar.append(int(limit))
    return [tuple(r) for r in conn.execute(q, ar).fetchall()]


def kind_labels(conn, lang='KO'):
    """갈래 코드 → 그 언어의 예제 제목(`prompts`) — 목록의 갈래 칸이 쓴다."""
    out = {}
    for _row in prompts(conn, lang):
        kind, title = _row[1], _row[2]
        out.setdefault(kind, title)
    return out


def chat(conn, chat_id):
    r = conn.execute("SELECT chat_id, start_vid, end_vid, title, lang_code, provider, model, prompt_kind,"
                     " entity_id, COALESCE(scope,'VERSE'), ref_anchor"
                     " FROM user_ai_chat WHERE chat_id=?", (chat_id,)).fetchone()
    if not r:
        return None
    return dict(zip(('chat_id', 'start_vid', 'end_vid', 'title', 'lang', 'provider', 'model', 'kind',
                     'entity_id', 'scope', 'ref_anchor'), r))


def msgs(conn, chat_id):
    return [tuple(r) for r in conn.execute(
        "SELECT msg_id, role, body, ts FROM user_ai_msg WHERE chat_id=? ORDER BY msg_id", (chat_id,))]


def msgs_full(conn, chat_id):
    """`[(msg_id, role, body, ts, provider, model)]` — 답마다 어느 AI 인지."""
    return [tuple(r) for r in conn.execute(
        "SELECT msg_id, role, body, ts, COALESCE(provider,''), COALESCE(model,'')"
        " FROM user_ai_msg WHERE chat_id=? ORDER BY msg_id", (chat_id,))]


def acct_key(a_or_provider, model=None):
    """계정(AI) 열쇠 — `'GEMINI|gemini-flash-lite-latest'`. 답·질문을 AI 와 잇는 단일 문."""
    if isinstance(a_or_provider, dict):
        return '%s|%s' % (str(a_or_provider.get('provider') or '').upper(), a_or_provider.get('model') or '')
    return '%s|%s' % (str(a_or_provider or '').upper(), model or '')


def msg_rows(conn, chat_id):
    """그 채팅의 말 전부 — `[{msg_id, role, body, provider, model, target, mkind, verify}]`."""
    out = []
    for r in conn.execute(
            "SELECT msg_id, role, body, COALESCE(provider,''), COALESCE(model,''),"
            " COALESCE(target,''), COALESCE(mkind,''), COALESCE(verify,'')"
            " FROM user_ai_msg WHERE chat_id=? ORDER BY msg_id",
            (int(chat_id),)):
        out.append(dict(zip(('msg_id', 'role', 'body', 'provider', 'model', 'target', 'mkind', 'verify'), r)))
    return out


def other_ais_for_ref(conn, ref_id):
    """★ 2026-10-15 사용자 「AI 가 2개 이상이면 설교작성 후 분석은 우선적으로 다른 AI 에게」 —
    그 노트를 쓴 AI 채팅(`user_ai_chat.ref_id`)이 있으면 **그 AI 가 아닌 켠 계정의 열쇠들**(다른 회사 먼저).
    쓴 AI 를 모르거나 다른 AI 가 없으면 빈 목록(= 켠 것 전부에 보낸다)."""
    try:
        r = conn.execute("SELECT chat_id FROM user_ai_chat WHERE ref_id=? ORDER BY chat_id DESC LIMIT 1",
                         (int(ref_id),)).fetchone()
    except Exception:                                     # noqa: BLE001
        r = None
    if not r:
        return []
    writers = chat_ais(conn, r[0])
    en = enabled_accounts(conn)
    if not writers or len(en) < 2:
        return []
    wk = {acct_key(p, m) for p, m in writers}
    wp = {str(p).upper() for p, _m in writers}
    other_co = [acct_key(a) for a in en if str(a.get('provider') or '').upper() not in wp]
    if other_co:
        return other_co
    return [acct_key(a) for a in en if acct_key(a) not in wk]


def chat_ais(conn, chat_id):
    """그 채팅에 답한 AI — `[(provider, model)]`(처음 답한 차례 · 통합본은 안 센다)."""
    seen, out = set(), []
    for m in msg_rows(conn, chat_id):
        if m['role'] == 'ai' and not m['mkind']:
            k = acct_key(m['provider'], m['model'])
            if k not in seen:
                seen.add(k)
                out.append((m['provider'], m['model']))
    return out


def _is_mine(m, key):
    """그 AI 의 줄기에 드는 말인가 — 모두에게 간 말 · 그 AI 에게만 간 말 · 그 AI 의 대화 답."""
    if m['role'] == 'user':
        return m['target'] in ('', key)
    if m['role'] == 'ai':
        return (not m['mkind']) and acct_key(m['provider'], m['model']) == key
    return False


def thread_of(conn, chat_id, key):
    """그 AI 의 대화 줄기 — `[(role, body)]`(함께 보낸 자료 표시는 뺀다)."""
    return [(m['role'], m['body']) for m in msg_rows(conn, chat_id)
            if _is_mine(m, key) and (m['body'] or '').strip()]


def latest_of(conn, chat_id, key):
    """그 AI 칸에 보일 글 — 대화 답과 그 AI 의 자체 통합본 가운데 **더 늦은 것**.

    → `(body, mkind)` · 없으면 `('', '')`.
    """
    best = ('', '')
    for m in msg_rows(conn, chat_id):
        if m['role'] == 'ai' and acct_key(m['provider'], m['model']) == key and m['mkind'] in ('', 'SELF'):
            best = (strip_next(m['body'] or ''), m['mkind'])
    return best


def latest_integ(conn, chat_id):
    """마지막 **모든 AI 통합본** — `{body, provider, model, map}` 또는 None."""
    hit = None
    for m in msg_rows(conn, chat_id):
        if m['role'] == 'ai' and m['mkind'] == 'INTEG':
            hit = m
    if not hit:
        return None
    return {'body': hit['body'] or '', 'provider': hit['provider'], 'model': hit['model'],
            'map': hit['target'] or ''}


def first_question(conn, chat_id):
    """첫 프롬프트(모두에게 간 첫 사용자 말) — 없으면 ''."""
    for m in msg_rows(conn, chat_id):
        if m['role'] == 'user' and not m['target']:
            return m['body'] or ''
    return ''


def last_answers(conn, chat_id):
    """**마지막 물음에 온 답들** — `[(msg_id, provider, model, body)]`(AI 여럿이면 여럿).

    ★ 317차-6 — AI 둘에 함께 보냈을 때 두 답을 나란히 견주는 화면이 이것을 읽는다.
    ⚠ 함께 보낸 자료 표시(시스템 글)는 답이 아니다 — 건너뛴다.
    """
    rows = msg_rows(conn, chat_id)
    last_user = max([i for i, m in enumerate(rows) if m['role'] == 'user'] or [-1])
    return [(m['msg_id'], m['provider'], m['model'], strip_next(m['body'])) for m in rows[last_user + 1:]
            if m['role'] == 'ai' and not m['mkind'] and (m['body'] or '').strip()]


def answers_block(answers, label_of=None):
    """여러 답을 한 덩이로 — 「[답 1 · 모델]」 머리말 + 본문(합치기 요청에 싣는다)."""
    out = []
    for i, (_m, p_, md, b) in enumerate(answers, 1):
        nm = (label_of(p_, md) if callable(label_of) else '') or md or p_ or ''
        out.append('[%d · %s]' % (i, nm) + NL + (b or '').strip())
    return (NL + NL).join(out)


def add_msg(conn, chat_id, role, body, tok=None, provider='', model='', target='', mkind='',
            verify='', raw=None):
    assert role in ('user', 'ai', 'system'), role
    conn.execute("INSERT INTO user_ai_msg(chat_id, role, body, ts, n_in, n_out, provider, model, target, mkind,"
                 " verify, raw) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                 (chat_id, role, body, _now(), int((tok or {}).get('in', 0)), int((tok or {}).get('out', 0)),
                  provider or '', model or '', target or '', mkind or '', verify or '', raw))
    conn.execute("UPDATE user_ai_chat SET updated_at=?, edits=COALESCE(edits,0)+1, last_by='PC' WHERE chat_id=?",
                 (_now(), chat_id))                       # ★ 2026-10-20 고친 횟수(함께 쓰기)
    conn.commit()


def hide_chat(conn, chat_id):
    """[이 채팅 삭제] — ★ 2026-10-20 휴지통으로(30일 뒤 완전히 지운다 · 되살릴 수 있다)."""
    try:
        import ai_chat_sync as ACS
        ACS.trash(conn, [chat_id])
    except Exception:                                     # noqa: BLE001
        conn.execute("UPDATE user_ai_chat SET record_status='HIDE' WHERE chat_id=?", (chat_id,))
        conn.commit()


# ── 이어서 묻기(2026-10-16) ─────────────────────────────────────────────
# ★ 사용자 「방향전환질문(반대, 차이점, 비교 등) + 심화질문 + 안고른 Pick 추가질문 + AI의 제안질문 좋다.
#   추가질문 유형을 잘 정리해야 한다. AI가 질문할 때 사용자는 1,2,3 형식으로 쉽게 선택하도록」.
#   갈래 넷 = AI 제안(답 끝 「▷ 」 줄 → 화면이 1·2·3 번호로) · 방향 바꾸기 · 더 깊이 · 아직 안 고른 Pick.
#   ⚠ 방향·깊이 글은 **요구사항에 붙는 물음**이다(쓸 말을 주지 않는다 — 문장 한 줄씩 · 규칙은 적을수록 낫다).
FOLLOW_GROUPS = ('TURN', 'DEEP')
FOLLOW = {
    'TURN': [
        ('OPPOSE', {'KO': ('다르게 보는 견해와 그 근거를 알려 주세요', '이 해석과 다르게 보는 견해는 무엇이며, 그 근거는 무엇입니까?'),
                    'EN': ('Opposing view', 'What views read this differently, and on what grounds?'),
                    'JA': ('反対の見解', 'この解釈と異なる見方は何で、その根拠は何ですか。'),
                    'ZH': ('相反的看法', '与这个解释不同的看法是什么？其依据是什么？'),
                    'ZHT': ('相反的看法', '與這個解釋不同的看法是什麼？其依據是什麼？'),
                    'DE': ('Gegenansicht', 'Welche Auffassungen lesen dies anders, und mit welcher Begründung?'),
                    'FR': ('Avis contraire', 'Quels avis lisent ce texte autrement, et sur quelle base ?'),
                    'ES': ('Opinión contraria', '¿Qué opiniones lo leen de otra manera y con qué fundamento?'),
                    'PT': ('Visão contrária', 'Que visões o leem de outro modo, e com que base?'),
                    'RU': ('Иной взгляд', 'Какие взгляды понимают это иначе и на каком основании?'),
                    'AR': ('رأي مخالف', 'ما الآراء التي تفهم هذا بطريقة مختلفة، وما سندها؟')}),
        ('DIFF', {'KO': ('헷갈리기 쉬운 것들의 차이를 짚어 주세요', '앞의 답에서 헷갈리기 쉬운 것들이 서로 어떻게 다른지 짚어 주세요.'),
                  'EN': ('Differences', 'In the previous answer, show how the things that are easy to confuse differ from each other.'),
                  'JA': ('違い', '前の答えの中で混同しやすいものが互いにどう違うかを示してください。'),
                  'ZH': ('区别', '请指出上一个回答中容易混淆的内容彼此有何不同。'),
                  'ZHT': ('區別', '請指出上一個回答中容易混淆的內容彼此有何不同。'),
                  'DE': ('Unterschiede', 'Zeige, wie sich die leicht verwechselbaren Dinge aus der vorigen Antwort unterscheiden.'),
                  'FR': ('Différences', 'Montre en quoi diffèrent les éléments faciles à confondre dans la réponse précédente.'),
                  'ES': ('Diferencias', 'Muestra en qué se diferencian las cosas fáciles de confundir de la respuesta anterior.'),
                  'PT': ('Diferenças', 'Mostre em que diferem as coisas fáceis de confundir da resposta anterior.'),
                  'RU': ('Различия', 'Покажи, чем различаются вещи из предыдущего ответа, которые легко спутать.'),
                  'AR': ('الفروق', 'بيّن كيف تختلف الأمور التي يسهل الخلط بينها في الجواب السابق.')}),
        ('COMPARE', {'KO': ('다른 성경 본문과 견주어 주세요', '이 내용을 다른 성경 본문과 견주면 같은 점과 다른 점은 무엇입니까?'),
                     'EN': ('Compare passages', 'Compared with other Bible passages, what is the same and what is different?'),
                     'JA': ('他の箇所と比較', 'この内容を他の聖書箇所と比べると、同じ点と違う点は何ですか。'),
                     'ZH': ('与其他经文比较', '把这个内容与其他经文相比，相同点和不同点是什么？'),
                     'ZHT': ('與其他經文比較', '把這個內容與其他經文相比，相同點和不同點是什麼？'),
                     'DE': ('Mit anderen Stellen vergleichen', 'Was ist im Vergleich mit anderen Bibelstellen gleich und was anders?'),
                     'FR': ('Comparer', 'Comparé à d’autres passages bibliques, qu’est-ce qui est semblable et qu’est-ce qui diffère ?'),
                     'ES': ('Comparar pasajes', 'Comparado con otros pasajes bíblicos, ¿qué es igual y qué es diferente?'),
                     'PT': ('Comparar passagens', 'Comparado com outras passagens bíblicas, o que é igual e o que é diferente?'),
                     'RU': ('Сравнить с другими местами', 'Что общего и что различается в сравнении с другими местами Библии?'),
                     'AR': ('مقارنة بنصوص أخرى', 'عند مقارنته بنصوص كتابية أخرى، ما المتشابه وما المختلف؟')}),
        ('EVIDENCE', {'KO': ('말한 것의 성경 근거를 구절로 대 주세요', '앞의 답에서 말한 것의 성경 근거를 구절로 대 주시고, 근거를 댈 수 없는 것은 그렇다고 말해 주세요.'),
                      'EN': ('Check the basis', 'Give the Bible verses behind what the previous answer said, and say so where no basis can be given.'),
                      'JA': ('根拠の確認', '前の答えで述べたことの聖書の根拠を箇所で示し、根拠を示せないものはそう言ってください。'),
                      'ZH': ('核对依据', '请用经文列出上一个回答所说内容的圣经依据，无法提供依据的请直说。'),
                      'ZHT': ('核對依據', '請用經文列出上一個回答所說內容的聖經依據，無法提供依據的請直說。'),
                      'DE': ('Begründung prüfen', 'Nenne die Bibelstellen hinter der vorigen Antwort und sage es, wo sich keine Begründung angeben lässt.'),
                      'FR': ('Vérifier les appuis', 'Donne les versets qui appuient la réponse précédente, et dis-le là où aucun appui ne peut être donné.'),
                      'ES': ('Verificar la base', 'Da los versículos que respaldan la respuesta anterior y dilo donde no se pueda dar respaldo.'),
                      'PT': ('Verificar a base', 'Dê os versículos que sustentam a resposta anterior e diga quando não houver base.'),
                      'RU': ('Проверить основание', 'Укажи стихи, на которых основан предыдущий ответ, и скажи прямо, где основания нет.'),
                      'AR': ('التحقق من السند', 'اذكر الآيات التي يستند إليها الجواب السابق، وقل ذلك صراحة حيث لا يوجد سند.')}),
        ('CASES', {'KO': ('비슷한 다른 사례를 성경에서 찾아 주세요', '앞의 답과 비슷한 다른 사례(성경 속 인물이나 사건)를 두세 가지 들고, 같은 점과 다른 점을 짧게 짚어 주세요.'),
                   'EN': ('Find similar cases in the Bible', 'Give two or three similar cases (people or events in the Bible) and briefly note what is alike and what differs.')}),
        ('RECENT', {'KO': ('최근의 새로운 연구나 관점을 알려 주세요', '이 주제에 대해 비교적 최근에 나온 연구나 새로운 관점이 있으면 소개해 주세요. 확실하지 않은 것은 확실하지 않다고 말하고, 지어내지 마세요.'),
                    'EN': ('Tell me about recent research or views', 'If there is relatively recent research or a new perspective on this topic, introduce it. Say so where you are not sure, and do not make anything up.')}),
    ],
    'DEEP': [
        ('DEEPER', {'KO': ('가장 중요한 한 가지를 더 깊이 설명해 주세요', '앞의 답에서 가장 중요한 한 가지를 더 깊이 설명해 주세요.'),
                    'EN': ('Go deeper', 'Explain the most important point of the previous answer in more depth.'),
                    'JA': ('さらに深く', '前の答えで最も大切な一点をさらに深く説明してください。'),
                    'ZH': ('更深入', '请把上一个回答中最重要的一点解释得更深入。'),
                    'ZHT': ('更深入', '請把上一個回答中最重要的一點解釋得更深入。'),
                    'DE': ('Vertiefen', 'Erkläre den wichtigsten Punkt der vorigen Antwort ausführlicher.'),
                    'FR': ('Approfondir', 'Explique plus en profondeur le point le plus important de la réponse précédente.'),
                    'ES': ('Profundizar', 'Explica con más profundidad el punto más importante de la respuesta anterior.'),
                    'PT': ('Aprofundar', 'Explique com mais profundidade o ponto mais importante da resposta anterior.'),
                    'RU': ('Глубже', 'Объясни глубже самый важный пункт предыдущего ответа.'),
                    'AR': ('تعمّق', 'اشرح أهم نقطة في الجواب السابق بعمق أكبر.')}),
        ('CLARIFY', {'KO': ('애매한 부분을 더 구체적으로 풀어 주세요', '앞의 답에서 애매하거나 단정하기 어려운 부분을 더 구체적으로 설명해 주세요.'),
                     'EN': ('Unclear parts', 'Explain more concretely the parts of the previous answer that are vague or hard to state firmly.'),
                     'JA': ('曖昧な部分', '前の答えで曖昧な部分や断定しにくい部分を、より具体的に説明してください。'),
                     'ZH': ('模糊之处', '请更具体地解释上一个回答中模糊或难以断定的部分。'),
                     'ZHT': ('模糊之處', '請更具體地解釋上一個回答中模糊或難以斷定的部分。'),
                     'DE': ('Unklares', 'Erkläre konkreter, was in der vorigen Antwort vage oder schwer eindeutig zu sagen ist.'),
                     'FR': ('Points flous', 'Explique plus concrètement ce qui est flou ou difficile à affirmer dans la réponse précédente.'),
                     'ES': ('Partes ambiguas', 'Explica con más concreción lo que es ambiguo o difícil de afirmar en la respuesta anterior.'),
                     'PT': ('Partes ambíguas', 'Explique de forma mais concreta o que é vago ou difícil de afirmar na resposta anterior.'),
                     'RU': ('Неясное', 'Объясни конкретнее то, что в предыдущем ответе неясно или трудно утверждать.'),
                     'AR': ('مواضع غامضة', 'اشرح بشكل أوضح ما كان غامضًا أو يصعب الجزم به في الجواب السابق.')}),
        ('EXAMPLE', {'KO': ('성경 속 예나 삶의 예를 들어 주세요', '성경 속 예나 오늘의 삶의 예를 들어 설명해 주세요.'),
                     'EN': ('An example', 'Explain it with an example from the Bible or from life today.'),
                     'JA': ('例を挙げて', '聖書の中の例や今日の生活の例を挙げて説明してください。'),
                     'ZH': ('举例', '请用圣经中的例子或今天生活中的例子来解释。'),
                     'ZHT': ('舉例', '請用聖經中的例子或今天生活中的例子來解釋。'),
                     'DE': ('Ein Beispiel', 'Erkläre es mit einem Beispiel aus der Bibel oder aus dem heutigen Leben.'),
                     'FR': ('Un exemple', 'Explique-le avec un exemple tiré de la Bible ou de la vie d’aujourd’hui.'),
                     'ES': ('Un ejemplo', 'Explícalo con un ejemplo de la Biblia o de la vida de hoy.'),
                     'PT': ('Um exemplo', 'Explique com um exemplo da Bíblia ou da vida de hoje.'),
                     'RU': ('Пример', 'Объясни на примере из Библии или из сегодняшней жизни.'),
                     'AR': ('مثال', 'اشرحه بمثال من الكتاب المقدس أو من الحياة اليوم.')}),
        ('SIMPLE', {'KO': ('처음 믿는 사람도 알아듣게 쉽게 풀어 주세요', '처음 믿는 사람도 알아듣게 더 쉽게 설명해 주세요.'),
                    'EN': ('Simpler', 'Explain it more simply, so that a new believer can follow.'),
                    'JA': ('やさしく', '信じ始めたばかりの人にも分かるよう、もっとやさしく説明してください。'),
                    'ZH': ('更浅显', '请解释得更浅显，让初信的人也能明白。'),
                    'ZHT': ('更淺顯', '請解釋得更淺顯，讓初信的人也能明白。'),
                    'DE': ('Einfacher', 'Erkläre es einfacher, sodass auch ein neuer Gläubiger folgen kann.'),
                    'FR': ('Plus simple', 'Explique-le plus simplement, pour qu’un nouveau croyant puisse suivre.'),
                    'ES': ('Más sencillo', 'Explícalo de forma más sencilla, para que un nuevo creyente pueda entenderlo.'),
                    'PT': ('Mais simples', 'Explique de forma mais simples, para que um novo crente entenda.'),
                    'RU': ('Проще', 'Объясни проще, чтобы понял даже новообращённый.'),
                    'AR': ('ببساطة', 'اشرحه ببساطة أكثر حتى يفهمه المؤمن الجديد.')}),
        ('APPLY', {'KO': ('내 삶에 이어 생각해 볼 거리를 주세요', '앞의 답을 내 삶에 이어 생각해 볼 질문을 두세 가지 주세요. 무엇을 해야 하는지 대신 정해 주지는 마세요.'),
                   'EN': ('Give me things to reflect on for my life', 'Give two or three questions that connect the previous answer to my life. Do not decide for me what I should do.')}),
    ],
}

# ★ AI 제안 질문 — 답 끝에 「▷ 」 줄 셋(화면이 1·2·3 번호를 붙인다 — AI 가 번호를 달면 겹친다)
NEXT_RULE = {
    'KO': ('답의 맨 끝에, 이 답에 이어 내가 더 듣고 싶어 할 만한 내용 세 가지를 한 줄에 하나씩 「▷ 」로 시작해 적어 주세요. '
           '각 줄은 당신이 이어서 설명해 줄 수 있는 것을 권하는 꼴로 쓰고, 나에게 내 생각이나 경험을 묻는 질문으로 쓰지 마세요. '
           '번호는 붙이지 마세요.'),
    'EN': ('At the very end of your answer, write three things I would likely want to hear more about next, one per line, '
           'each starting with "▷ ". Phrase each line as an offer of what you can explain further, not as a question asking me '
           'about my own thoughts or experience. Do not number them.'),
    'JA': '答えの最後に、次に尋ねられる問いを三つ、一行に一つずつ「▷ 」で始めて書いてください。番号は付けないでください。',
    'ZH': '请在回答的最后写三个我接下来可以问的问题，每行一个，以“▷ ”开头。不要编号。',
    'ZHT': '請在回答的最後寫三個我接下來可以問的問題，每行一個，以「▷ 」開頭。不要編號。',
    'DE': 'Schreibe ganz am Ende deiner Antwort drei Fragen, die ich als Nächstes stellen könnte, je eine pro Zeile, beginnend mit „▷ “. Nummeriere sie nicht.',
    'FR': 'Tout à la fin de ta réponse, écris trois questions que je pourrais poser ensuite, une par ligne, commençant par « ▷ ». Ne les numérote pas.',
    'ES': 'Al final de tu respuesta, escribe tres preguntas que podría hacer después, una por línea, empezando con «▷ ». No las numeres.',
    'PT': 'No fim da resposta, escreva três perguntas que eu poderia fazer em seguida, uma por linha, começando com “▷ ”. Não as numere.',
    'RU': 'В самом конце ответа напиши три вопроса, которые я мог бы задать дальше, по одному в строке, начиная с «▷ ». Не нумеруй их.',
    'AR': 'في نهاية جوابك اكتب ثلاثة أسئلة يمكنني أن أسألها بعد ذلك، كل سؤال في سطر، يبدأ بـ «▷ ». لا ترقّمها.',
}
NEXT_MARK = '▷'
NO_NEXT_KINDS = ('T:TEACH', 'T:BOOKMEDI')       # 교사는 AI 가 묻는 쪽 · 도서 묵상은 제 씨앗이 이미 ▷ 를 시킨다
_NUM_HEAD = re.compile(r'^\s*(?:[\(\[]?\d{1,2}[\.\)\]:]|[-*·•])\s*')


def next_rule(lang='KO'):
    return NEXT_RULE.get((lang or 'KO').upper(), NEXT_RULE['EN'])


#: ★ 2026-10-24 항목별로 나누어 답하기 — Pick·이어서 묻기에서 **둘 이상** 골랐을 때만 붙는다
#   (사용자 「Pick 에 대하여 통합하여 답변하면 질문의 요지에 대한 1:1 이해가 어렵다 · 질문유형별 매칭답변 · 이어서 묻기에서도」).
#   ⚠ 필수 지침에 늘 두지 않는다 — 하나만 고른 때 쓸데없는 머리가 생기고, 프롬프트 문장이 틀 문구가 된다.
PICK_EACH = {
    'KO': '위 항목마다 번호와 이름을 머리로 달고, 항목별로 나누어 답한다.',
    'EN': 'Answer each item above separately, heading each answer with its number and name.',
    'ZH': '请针对以上每一项分别作答，每个回答以其编号和名称作为标题。',
    'ZHT': '請針對以上每一項分別作答，每個回答以其編號和名稱作為標題。',
    'JA': '上の項目ごとに、番号と名前を見出しにして、項目別に分けて答えてください。',
    'DE': 'Beantworte jeden Punkt oben einzeln und setze Nummer und Namen des Punktes als Überschrift.',
    'FR': 'Réponds à chaque point ci-dessus séparément, en mettant son numéro et son nom en titre.',
    'ES': 'Responde a cada punto anterior por separado, encabezando cada respuesta con su número y nombre.',
    'PT': 'Responda a cada item acima separadamente, com o número e o nome do item como título.',
    'RU': 'Ответь на каждый пункт выше отдельно, начиная каждый ответ с его номера и названия.',
    'AR': 'أجب عن كل بند أعلاه على حدة، واجعل رقمه واسمه عنوانًا لكل جواب.',
}


def pick_each(lang='KO'):
    return PICK_EACH.get((lang or 'KO').upper(), PICK_EACH['EN'])


def _pick_pair(p):
    """Pick 하나 → (이름, 글) — 옛 호출부는 글만 준다(이름 '')."""
    if isinstance(p, (tuple, list)):
        return (str(p[0] or '').strip(), str(p[1] or '').strip())
    return ('', str(p or '').strip())


def each_block(items, lang='KO'):
    """고른 항목들 → 보낼 글. 하나면 그 글 그대로 · 둘 이상이면 「1. [이름] 글」 줄 + 항목별로 답하라는 한 줄.
    ★ Pick 칸과 이어서 묻기가 **같은 문**을 쓴다 — 폰 `eachBlock`(ai_follow.dart)과 글자 그대로 같아야 한다."""
    pk = [x for x in (_pick_pair(p) for p in (items or [])) if x[1]]
    if not pk:
        return ''
    if len(pk) == 1:
        return pk[0][1]
    lines = ['%d. %s%s' % (i + 1, ('[%s] ' % n) if n else '', b) for i, (n, b) in enumerate(pk)]
    return NL.join(lines) + NL + pick_each(lang)


def follow_items(lang='KO'):
    """이어서 묻기 갈래 → `{'TURN': [(열쇠, 이름, 글)], 'DEEP': [...]}`(그 언어 · 없으면 영어)."""
    L = (lang or 'KO').upper()
    return {g: [(k, *(d.get(L) or d['EN'])) for k, d in FOLLOW[g]] for g in FOLLOW_GROUPS}


_MD_RULE = re.compile(r'^\s*([-*_]\s*){3,}$')
_MD_HEAD = re.compile(r'^\s{0,3}#{1,6}\s+')
_MD_QUOTE = re.compile(r'^\s*>\s?')
_MD_BULLET = re.compile(r'^(\s*)[-*+]\s+')
_MD_LINK = re.compile(r'\[([^\[\]\n]+)\]\((https?://[^)\s]+)\)')
_MD_EM = re.compile(r'(?<![\w*])\*(?!\s)([^*\n]+?)(?<!\s)\*(?![\w*])', re.ASCII)   # 폰 Dart 의 \w(ASCII)와 같게


def strip_md(text):
    """★ 2026-10-24 AI 답의 마크다운 기호를 모두 걷는다(사용자 「모든 마크다운 기호는 제거해야 한다」) —
    머리 #, 굵게·기울임 ** __ *, 코드 `, 지운 줄 ~~, 인용 >, 가로줄 ---, 글머리 - * + (→ 「· 」), 링크 [글](주소) → 글 (주소).
    ⚠ 표의 | 와 기도 표시 [[V]] · 제안 질문 ▷ · Pick 머리 [이름] 은 건드리지 않는다. 폰 `stripMd` 와 글자 그대로 같다."""
    out = []
    for ln in (text or '').split(NL):
        if _MD_RULE.match(ln):
            continue
        ln = _MD_HEAD.sub('', ln)
        ln = _MD_QUOTE.sub('', ln)
        ln = _MD_BULLET.sub(lambda m: m.group(1) + '· ', ln)
        ln = _MD_LINK.sub(lambda m: '%s (%s)' % (m.group(1), m.group(2)), ln)
        ln = ln.replace('**', '').replace('__', '').replace('~~', '').replace('`', '')
        ln = _MD_EM.sub(lambda m: m.group(1), ln)
        out.append(ln)
    return NL.join(out)


def split_next(text):
    """AI 답 → `(본문, [제안 질문])` — 「▷ 」 줄을 본문에서 떼고 앞 번호를 걷는다(최대 3 · 마지막 것)."""
    body, qs = [], []
    for ln in (text or '').splitlines():
        t = ln.strip()
        if t.startswith(NEXT_MARK):
            q = _NUM_HEAD.sub('', t.lstrip(NEXT_MARK).strip(' :-·')).strip()
            if q:
                qs.append(q)
        else:
            body.append(ln)
    return NL.join(body).rstrip(), qs[-3:]


def strip_next(text):
    """제안 질문 줄을 뗀 본문(저장·통합·비교에 쓴다)."""
    return split_next(text)[0]


def number_pick(q, suggestions):
    """요구사항에 숫자 하나(「1」「2.」「３」)만 적었으면 그 제안 질문 — 아니면 None."""
    t = (q or '').strip().translate(str.maketrans('１２３', '123')).rstrip('.)번 ')
    if t in ('1', '2', '3') and len(suggestions) >= int(t):
        return suggestions[int(t) - 1]
    return None


def chats_covering(conn, vid, limit=50):
    """그 절을 **덮는** 구절 채팅 전부(그 절 하나 · 그 절이 든 구간) — P4 AI 배지와 채팅목록이 쓴다.

    ★ 사용자 「창1:1과 관련한 모든 대화목록이 AI(5)와 같이 표시될 것이다 … 구절+질문유형을 결합해서
      배지를 표시하는 것은 무리가 있을 것 같다」 — 배지는 업무와 상관없이 **그 절의 채팅 수**다.
    ⚠ 말이 하나도 없는 빈 채팅은 안 센다(새 채팅을 열고 안 보낸 것).
    """
    init(conn)
    if not vid:
        return []
    return [tuple(r) for r in conn.execute(
        "SELECT c.chat_id, c.title, c.start_vid, c.end_vid, c.updated_at,"
        " (SELECT COUNT(*) FROM user_ai_msg m WHERE m.chat_id=c.chat_id), c.prompt_kind"
        " FROM user_ai_chat c WHERE c.record_status='LIVE' AND COALESCE(c.scope,'VERSE')='VERSE'"
        " AND c.entity_id IS NULL AND c.start_vid<=? AND COALESCE(c.end_vid, c.start_vid)>=?"
        " AND EXISTS(SELECT 1 FROM user_ai_msg m WHERE m.chat_id=c.chat_id AND m.role='ai')"
        " ORDER BY c.updated_at DESC LIMIT ?", (int(vid), int(vid), int(limit))).fetchall()]


def verse_chat_count(conn, vid):
    return len(chats_covering(conn, vid, limit=999))


_PH_VERSE = ('[구절]', '[passage]', '[聖句]', '[经文]', '[經文]', '[Stelle]',
             '[pasaje]', '[passagem]', '[отрывок]', '[المقطع]')
_PH_TERM = ('[용어]', '[term]', '[用語]', '[词语]', '[詞語]', '[Begriff]', '[terme]',
            '[término]', '[termo]', '[термин]', '[المصطلح]')
#: 303차 — 연구자료 닻의 자리표(그 언어 씨앗이 쓰는 글자).
_PH_REF = ('[연구자료]', '[note]', '[研究資料]', '[研究资料]', '[Notiz]', '[note de recherche]',
           '[nota]', '[заметка]', '[الملاحظة]')
#: ★ 2026-10-27 (docs/1.txt 6-5) 도서 묵상의 자리표 — 닻은 연구자료 갈래(BOOK_UNIT:)이지만 사용자에게는 「도서」다.
#   채우는 문은 연구자료 자리표와 같다(그 편 제목).
_PH_BOOK = ('[도서]', '[book]', '[書籍]', '[书籍]', '[Buch]', '[livre]', '[libro]', '[livro]', '[книга]', '[الكتاب]')
_PH_REF = _PH_REF + _PH_BOOK
_BOOK_PH_OLD = {'KO': ('[연구자료]', '[도서]'), 'EN': ('[note]', '[book]'), 'JA': ('[研究資料]', '[書籍]'), 'ZH': ('[研究资料]', '[书籍]'), 'ZHT': ('[研究資料]', '[書籍]'), 'DE': ('[Notiz]', '[Buch]'), 'FR': ('[note de recherche]', '[livre]'), 'ES': ('[nota]', '[libro]'), 'PT': ('[nota]', '[livro]'), 'RU': ('[заметка]', '[книга]'), 'AR': ('[الملاحظة]', '[الكتاب]')}


def _migrate_book_ph(conn):
    """도서 묵상 프롬프트에 남은 옛 자리표 [연구자료] → [도서](그 언어 글자) — 사람이 고친 글도 자리표만 바꾼다."""
    n = 0
    for pid, lg, body in conn.execute("SELECT prompt_id, lang_code, body FROM user_ai_prompt WHERE kind='T_BOOKMEDI'").fetchall():
        o, nw = _BOOK_PH_OLD.get((lg or '').upper(), ('', ''))
        if o and o in (body or ''):
            conn.execute("UPDATE user_ai_prompt SET body=? WHERE prompt_id=?", ((body or '').replace(o, nw), pid))
            n += 1
    return n


def fill_prompt(conn, body, scope='VERSE', start_vid=None, end_vid=None, entity_id=None, lang='KO',
                ref_anchor=None):
    """프롬프트의 [구절]/[용어] 자리를 닻 이름으로 채운다 — 화면의 초안과 시스템 글이 **같은 문**을 쓴다
    (299차-2 · 사용자 「선택한 구절/용어가 자동으로 질문 프롬프트에 표시되면 좋겠다」)."""
    body = fill_version(conn, body or '', lang)     # ★ 2026-10-20 [성경버전] · 2026-10-21 [국가] 자리표
    if str(scope or '').upper() == 'FREE':
        # ★ 닻이 없다 — 자리표를 「이 본문」으로(지어내지 않는다)
        lbl = FREE_WORD.get((lang or 'KO').upper(), FREE_WORD['EN'])
        for tok in _PH_REF + _PH_TERM + _PH_VERSE:
            body = body.replace(tok, lbl)
        return body
    if str(scope or '').upper() == 'REF' and ref_anchor:
        lbl = ref_name(conn, ref_anchor, lang)
        toks = _PH_REF + _PH_TERM + _PH_VERSE
        for tok in toks:
            body = body.replace(tok, lbl)
        return body
    if str(scope or '').upper() == 'TERM' and str(ref_anchor or '').startswith(LEMMA_PFX):
        lbl = lemma_label(conn, str(ref_anchor)[len(LEMMA_PFX):])
        toks = _PH_TERM + _PH_VERSE
    elif str(scope or '').upper() == 'TERM' and entity_id:
        lbl = term_name(conn, entity_id, lang)
        toks = _PH_TERM + _PH_VERSE
    elif start_vid:
        lbl = range_label(conn, start_vid, end_vid, lang)
        toks = _PH_VERSE
    else:
        return body
    for tok in toks:
        body = body.replace(tok, lbl)
    return body


#: ★ 2026-10-13 docs/1.txt 84-1 — **표는 탭으로 칸을 나눈다**(사용자 지시 「AI 공통 프롬프트에 표를 만들 때에는
#:   콤마가 아니라 탭을 넣으라고 명시하라」). 탭 표는 저장할 때 표 구조로 바뀐다(`ref_doc.absorb`).
#:   쉼표 표는 문장과 구별이 안 돼 저절로 안 바뀐다. 모든 업무·모든 갈래에 붙는 공통 줄이다.
TABLE_RULE = {
    'KO': '표를 만들 때는 한 줄에 한 행을 쓰고 칸 사이를 탭(Tab) 문자로 나눕니다. 쉼표(,)나 세로 막대(|)로 칸을 나누지 않습니다. 첫 줄은 머리 줄입니다.',
    'EN': 'When you make a table, write one row per line and separate the cells with a Tab character. Do not separate cells with commas (,) or vertical bars (|). The first line is the header row.',
    'ZH': '制作表格时，每行写一行，单元格之间用制表符（Tab）分隔。不要用逗号（,）或竖线（|）分隔单元格。第一行是表头。',
    'ZHT': '製作表格時，每行寫一行，儲存格之間用定位字元（Tab）分隔。不要用逗號（,）或豎線（|）分隔儲存格。第一行是表頭。',
    'JA': '表を作るときは1行に1つの行を書き、セルの間をタブ（Tab）文字で区切ります。カンマ（,）や縦棒（|）で区切らないでください。最初の行は見出し行です。',
    'DE': 'Wenn du eine Tabelle erstellst, schreibe eine Zeile pro Tabellenzeile und trenne die Zellen mit einem Tabulatorzeichen. Trenne Zellen nicht mit Kommas (,) oder senkrechten Strichen (|). Die erste Zeile ist die Kopfzeile.',
    'FR': 'Pour un tableau, écris une ligne par rangée et sépare les cellules par une tabulation. Ne sépare pas les cellules par des virgules (,) ni par des barres verticales (|). La première ligne est l’en-tête.',
    'ES': 'Al hacer una tabla, escribe una fila por línea y separa las celdas con un tabulador. No separes las celdas con comas (,) ni con barras verticales (|). La primera línea es el encabezado.',
    'PT': 'Ao fazer uma tabela, escreva uma linha por fila e separe as células com uma tabulação. Não separe as células com vírgulas (,) nem com barras verticais (|). A primeira linha é o cabeçalho.',
    'RU': 'Составляя таблицу, пиши одну строку таблицы на строке и разделяй ячейки символом табуляции. Не разделяй ячейки запятыми (,) или вертикальными чертами (|). Первая строка — заголовок.',
    'AR': 'عند إنشاء جدول اكتب صفًا واحدًا في كل سطر وافصل بين الخلايا بحرف الجدولة (Tab). لا تفصل بين الخلايا بالفواصل (,) أو بالخطوط العمودية (|). السطر الأول هو صف العناوين.',
}


def table_rule(lang):
    return TABLE_RULE.get((lang or 'KO').upper()) or TABLE_RULE['EN']


def system_text(conn, ch, prompt_body, with_notes=False, notes_scope='RANGE', with_links=False):
    """시스템 글 = 프롬프트(사용자 것 · [구절]/[용어] 자리를 채운다) + 재료(+ 켜면 내 묵상노트).
    ⚠ 299차-2 부터 보통 [보내기]는 프롬프트를 **사용자 말**로 보내므로 여기 `prompt_body` 는 빈 글이고,
      시스템 글은 재료뿐이다. 교사(TEACH)만 지시문을 여기 싣는다."""
    body = fill_prompt(conn, prompt_body, ch.get('scope'), ch.get('start_vid'), ch.get('end_vid'),
                       ch.get('entity_id'), ch.get('lang'), ch.get('ref_anchor'))
    if ch.get('scope') == 'FREE':
        mat = {}                                          # ★ Free — 재료가 없다
    elif ch.get('scope') == 'VERSE' and not ch.get('start_vid') and not ch.get('ref_anchor'):
        mat = {}                                          # ★ 2026-10-31 말씀 그룹 — 내용만 넣었다(내용은 첫 말에 실린다)
    elif ch.get('scope') == 'REF' and ch.get('ref_anchor'):
        mat = materials_ref(conn, ch['ref_anchor'], ch['lang'])
    elif ch.get('scope') == 'TERM' and ch.get('entity_id'):
        mat = materials_term(conn, ch['entity_id'], ch['lang'])
    elif str(ch.get('ref_anchor') or '').startswith(LEMMA_PFX):
        mat = materials_lemma(conn, str(ch['ref_anchor'])[len(LEMMA_PFX):], ch['lang'])
    elif str(ch.get('ref_anchor') or '').startswith(LINK_PFX):
        mat = materials_link(conn, str(ch['ref_anchor'])[len(LINK_PFX):], ch['lang'])
    else:
        mat = materials(conn, ch['start_vid'], ch['end_vid'], ch['lang'])
    if with_notes and ch.get('scope') != 'FREE':
        if ch.get('scope') == 'TERM' or not ch.get('start_vid'):
            notes = my_notes(conn, None, None, scope='ALL') if str(notes_scope).upper() == 'ALL' else []
        else:
            # ★ 317차-15 — 노트마다 그 구절 이름표(구절마다 따로 분석하게)
            notes = note_groups(conn, ch['start_vid'], ch['end_vid'], notes_scope, ch.get('lang') or 'KO')
            if notes:
                mat['내 묵상노트'] = note_material(notes)
                notes = []
        if notes:
            mat['내 묵상노트'] = (NL + '---' + NL).join(notes)
    if with_links and ch.get('start_vid'):
        # ★ 2026-10-15 설교 작성 「관련 인용구절」 Pick — 연결구절(많아야 LINK_PICK_MAX)
        lk = link_material(conn, ch['start_vid'], ch.get('end_vid'), ch.get('lang') or 'KO')
        if lk:
            mat['연결구절'] = lk
    # ★★★ 317차 — **필수 지침이 맨 앞**(사용자가 보지도 고치지도 못한다 · `db_ai_guard`).
    #   그 아래 지시·재료가 오고, 사용자 프롬프트는 사용자 말로 간다 — 위아래가 분명하다.
    #   ⚠ 못 읽어도 보내기는 막지 않는다 — 코드 씨앗으로 떨어진다(`text` 가 그렇게 한다).
    try:
        import db_ai_guard as GUARD
        guard = GUARD.text(conn, ch.get('lang') or 'KO')
    except Exception:                                     # noqa: BLE001
        guard = ''
    rule = table_rule(ch.get('lang') or 'KO')            # ★ 84-1 — 표는 탭으로(공통)
    ctx = context_line(conn, ch.get('lang') or 'KO')     # ★ 2026-10-22 오늘·나라 — 어느 프롬프트든 AI 가 안다(자리표 없이)
    return ((guard + NL + NL) if guard else '') + rule + NL + NL + ctx + NL + NL + \
        (body + NL + NL if body.strip() else '') + render(mat)


def copy_prompt(conn, ch, user_text, prompt_body='', with_notes=False, notes_scope='RANGE', with_links=False,
                teach=False):
    """★ 2026-10-20 (docs/1.txt 8-1) 프롬프트를 **글 한 덩어리로** — API 가 없는 AI(브라우저)에 붙여 넣는다.
    보낼 때와 같은 문(`system_text` + 제안 규칙)을 쓴다 — 두 벌이면 「복사한 것과 보낸 것이 다르다」가 난다."""
    sysx = system_text(conn, ch, prompt_body, with_notes=with_notes, notes_scope=notes_scope, with_links=with_links)
    if not teach:
        sysx = (sysx.rstrip() + NL + NL + next_rule(ch.get('lang') or 'KO')).strip()
    u = (user_text or '').strip()
    return sysx.strip() + ((NL + NL + u) if u else '')


# ── 답 검증(2026-10-15) ─────────────────────────────────────────────────
# ★★★ 사용자 확정 — 「검증결과 문제없음 또는 문제 수정후 완성본만 답변으로 표시」 ·
#   「같은 AI 를 이용하는 것이 가장 저렴」 · 「5번(검증 실패)은 검증하지 못한 답변 원본이라고
#   말하고 보여주고 다시 검증을 시도할 기회를 주어라」.
# ★★★ 측정이 정한 꼴(temp_code_p107_verify_measure.py · 심은 흠 40건):
#   ⓐ 「무엇이 틀렸나」 목록을 받는 꼴은 0/40 — 같은 모델은 제 답을 판정하지 못한다
#   ⓑ **답 전체를 다시 쓰게 하고 바뀐 곳만 규칙으로 받아들인다** → 38/40
#   ⓒ 없는 장·절은 AI 에게 묻지 않고 **기계가 DB 로** 잰다(`scripture_ref.bad_refs`)
# ⚠ 받아들이는 규칙(`verify_guard`)이 이 꼴의 알맹이다 — AI 가 다시 쓴 글을 그대로 쓰지 않는다
#   (측정에서 다시 쓴 글이 뜻풀이를 지우고 어미를 바꾸었다).
VERIFY_PROMPT = {
    'KO': ('너는 교정자다. [답]을 처음부터 끝까지 그대로 옮겨 쓰되 아래 셋만 고친다. '
           '나머지 글자·문단·기호·줄바꿈은 하나도 바꾸지 않는다.' + NL +
           '1. 실제로 쓰이는 공식 이름이라고 확신할 수 없는 사람·교단·단체·책 이름이 든 문장은 빼고 옮긴다' + NL +
           '2. 오탈자·사전에 없는 낱말·잘못 겹친 낱말은 바르게 고친다' + NL +
           '3. 그 책에 없는 장·절이 든 문장은 빼고 옮긴다' + NL +
           '고친 [답]만 쓴다. 설명·머리말·인사는 쓰지 않는다.'),
    'EN': ('You are a proofreader. Copy [Answer] from start to finish exactly as it is, fixing only the three '
           'things below. Do not change any other character, paragraph, symbol or line break. Keep the language '
           'of [Answer].' + NL +
           '1. Leave out any sentence containing a name of a person, denomination, organization or book that you '
           'are not sure is a real, officially used name' + NL +
           '2. Correct typos, words not in the dictionary and wrongly doubled words' + NL +
           '3. Leave out any sentence citing a chapter or verse that does not exist in that book' + NL +
           'Write only the corrected [Answer]. No explanation, heading or greeting.'),
}
VERIFY_HEAD = {'KO': ('[재료]', '[질문]', '[답]'), 'EN': ('[Material]', '[Question]', '[Answer]')}
VERIFY_MIN = 40          # 이보다 짧은 답은 검증하지 않는다(고칠 자리가 없다)
VERIFY_MAT_MAX = 8000    # 재료는 이만큼만 싣는다(검증은 답을 고치는 일이다)
VERIFY_SIM = 0.85        # 다시 쓴 글의 이만큼은 원래 답에서 와야 한다(아니면 다른 글을 쓴 것)
_STOP = '.?!' + NL


def _ends_sentence(a, i1, i2):
    """같은 결과를 내는 범위로 앞뒤로 밀어 보아 마침표로 끝나는 자리가 있나
    (글자 비교가 같은 어미가 되풀이되는 자리에서 한두 글자 밀린다 — 측정에서 잡았다)."""
    base = a[:i1] + a[i2:]
    for k in range(-12, 13):
        s1, s2 = i1 + k, i2 + k
        if s1 < 0 or s2 > len(a):
            continue
        if a[:s1] + a[s2:] == base and a[s1:s2].rstrip().endswith(('.', '?', '!')):
            return True
    return False


def _whole_sentence(a, b, i1, i2):
    st = max(a.rfind(c, 0, i1 + 1) for c in _STOP) + 1
    ens = [j for j in (a.find(c, max(i1, i2 - 1)) for c in _STOP) if j >= 0]
    en = (min(ens) + 1) if ens else len(a)
    sent = a[st:en].strip()
    return bool(sent) and len(a[i1:i2].strip()) >= 0.8 * len(sent) and sent not in b


def _ending_change(a, i2, x, y):
    """어미를 바꾸는 고침인가(실측 — 「입니다→이다」 · 「갑니다→간다」 · 「하십→하셨습」을 막는다)."""
    if any(t in x + y for t in ('니', '습', '셨', '십')):
        return True
    return a[i2:i2 + 1] in ('다', '요') or (y.endswith('다') and '니다' in x + a[i2:i2 + 2])


def verify_guard(a, b, veto=None):
    """다시 쓴 글(b)에서 **받아들일 고침만** 원래 답(a)에 옮긴다 → `(final, took, dropped)`.

    받는 것 셋 — ① 문장째 빼기(10자 이상 · 문장 끝까지) ② 잘못 겹친 글자 빼기
    ③ 짧은 낱말 고침(양쪽 6자 이하 · 어미 바꾸기는 안 받는다). 그 밖은 원래 답 그대로.
    `veto(지울 글)` 가 참이면 그 문장 빼기는 안 받는다(맞는 구절이 든 문장 — 장·절은 기계가 잰다).
    """
    import difflib
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    out, took, dropped = [], [], []
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        x, y = a[i1:i2], b[j1:j2]
        if op == 'equal':
            out.append(x)
            continue
        keep = False
        if op == 'delete' and len(x.strip()) >= 10 and (_ends_sentence(a, i1, i2) or _whole_sentence(a, b, i1, i2)):
            keep = not (veto and veto(x))
        elif op == 'delete' and x.strip() and (a[i2:i2 + len(x)] == x or a[i2:i2 + len(x.strip())] == x.strip()):
            keep = True
        elif op == 'replace' and 0 < len(x) <= 6 and 0 < len(y) <= 6:
            keep = not _ending_change(a, i2, x, y)
        if keep:
            out.append(y)
            took.append((x, y))
        else:
            out.append(x)
            dropped.append((x, y))
    return ''.join(out), took, dropped


def _drop_at(text, positions):
    """그 자리가 든 문장을 뺀다(뒤에서부터 — 앞자리 번호가 안 밀리게)."""
    for p in sorted(set(positions), reverse=True):
        st = max(text.rfind(c, 0, p) for c in _STOP) + 1
        while st < p and text[st] in ' 	':
            st += 1                                       # 앞 문장 뒤 빈칸은 남긴다
        ens = [j for j in (text.find(c, p) for c in _STOP) if j >= 0]
        en = (min(ens) + 1) if ens else len(text)
        while en < len(text) and text[en] in ' 	':
            en += 1                                       # 뺀 문장 뒤 빈칸은 함께 뺀다
        text = text[:st] + text[en:]
    return text


def _verify_lang(lang):
    return 'KO' if (lang or 'KO').upper() == 'KO' else 'EN'


def verify_answer(conn, acc, answer, question='', material='', lang='KO', fn=None):
    """답을 검증한다 → `{state, text, raw, took, refs, why}`.

    state — 'OK'(검증함 · text 가 완성본) · 'SKIP'(짧아 검증 안 함) · 'FAIL'(검증 못 함 · text = 원래 답).
    ⚠ FAIL 은 답을 버리지 않는다 — 화면이 「검증하지 못한 답변 원본」이라 말하고 [다시 검증]을 준다.
    """
    answer = answer or ''
    if len(answer.strip()) < VERIFY_MIN:
        return {'state': 'SKIP', 'text': answer, 'raw': None, 'took': [], 'refs': [], 'why': ''}
    refs = []
    a = answer
    try:
        import scripture_ref as SR
        bad = SR.bad_refs(conn, a, lang or 'KO')
        if bad:
            refs = [m for m, _p in bad]
            a = _drop_at(a, [p for _m, p in bad])
    except Exception as e:                                # noqa: BLE001
        print('[verify refs] %s' % e)
    vl = _verify_lang(lang)
    hm, hq, ha = VERIFY_HEAD[vl]
    parts = []
    if (material or '').strip():
        parts += [hm, material.strip()[:VERIFY_MAT_MAX], '']
    if (question or '').strip():
        parts += [hq, question.strip()[:VERIFY_MAT_MAX], '']
    parts += [ha, a]
    fn = fn or call
    try:
        res = fn(acc['provider'], acc['key'], acc['model'], [('user', NL.join(parts))],
                 system=VERIFY_PROMPT[vl], max_out=MERGE_OUT)
    except TypeError:                                     # 시험용 가짜 call 은 max_out 을 모를 수 있다
        res = fn(acc['provider'], acc['key'], acc['model'], [('user', NL.join(parts))],
                 system=VERIFY_PROMPT[vl])
    if not res.get('ok'):
        return {'state': 'FAIL', 'text': answer, 'raw': answer, 'took': [], 'refs': refs,
                'why': res.get('why', '') or 'verify call failed'}
    b = (res.get('text') or '').strip()
    for h in (ha, ha.strip('[]')):
        if b.startswith(h):
            b = b[len(h):].lstrip(':').lstrip()
    import difflib
    #  ★ 잣대 = 「다시 쓴 글 가운데 원래 답에서 온 몫」 — 문장을 빼는 것은 정상이라 전체 닮음(ratio)으로
    #    재면 짧은 답에서 멀쩡한 교정이 떨어진다(시험이 잡았다)
    sim = (sum(x.size for x in difflib.SequenceMatcher(None, a, b, autojunk=False).get_matching_blocks())
           / float(len(b))) if b else 0.0
    if not b or len(b) < 0.6 * len(a.strip()) or sim < VERIFY_SIM:
        return {'state': 'FAIL', 'text': answer, 'raw': answer, 'took': [], 'refs': refs,
                'why': 'verify answer too different (%.2f)' % sim}
    def _veto(seg):
        try:
            import scripture_ref as SR
            return bool(SR.find(conn, seg, lang or 'KO')) and not SR.bad_refs(conn, seg, lang or 'KO')
        except Exception:                                 # noqa: BLE001
            return False
    final, took, _dropped = verify_guard(a, b, veto=_veto)
    return {'state': 'OK', 'text': final, 'raw': answer if final != answer else None,
            'took': took, 'refs': refs, 'why': ''}


def _verify_ctx(conn, ch, question=''):
    """검증에 함께 줄 재료 — 그 채팅의 재료(시스템 글)."""
    try:
        return system_text(conn, ch, '')
    except Exception:                                     # noqa: BLE001
        return ''


def reverify(conn, msg_id, _call=None):
    """[다시 검증] — 검증 못 한 답(또는 아무 답)을 다시 검증한다 → `verify_answer` 결과.
    된 것은 그 말에 그대로 적는다(완성본 · verify='OK')."""
    r = conn.execute("SELECT chat_id, body, COALESCE(provider,''), COALESCE(model,''), raw"
                     " FROM user_ai_msg WHERE msg_id=? AND role='ai'", (int(msg_id),)).fetchone()
    if not r:
        return {'state': 'FAIL', 'why': 'no message', 'text': ''}
    cid, body, prov, model, raw = r
    ch = chat(conn, cid)
    acc = _acct_of(conn, acct_key(prov, model)) or next(iter(enabled_accounts(conn)), None)
    if not ch or not acc:
        return {'state': 'FAIL', 'why': 'API 키가 없습니다.', 'text': body}
    q = conn.execute("SELECT body FROM user_ai_msg WHERE chat_id=? AND role='user' AND msg_id<?"
                     " ORDER BY msg_id DESC LIMIT 1", (cid, int(msg_id))).fetchone()
    orig = raw or body
    core, qs = split_next(orig)          # ★ 2026-10-16 제안 질문 줄은 검증 밖 · 뒤에 다시 붙인다
    v = verify_answer(conn, acc, core, q[0] if q else '', _verify_ctx(conn, ch), ch.get('lang') or 'KO',
                      fn=_call)
    st = 'OK' if v['state'] in ('OK', 'SKIP') else 'FAIL'
    out = orig if st == 'FAIL' else _rejoin(orig, core, v['text'])
    v = dict(v, text=out)
    conn.execute("UPDATE user_ai_msg SET body=?, verify=?, raw=? WHERE msg_id=?",
                 (out, st, orig if (st == 'FAIL' or out != orig) else None, int(msg_id)))
    conn.commit()
    return v


# ── 검증 모드(2026-10-16) ───────────────────────────────────────────
# ★ 사용자 「옵션 : 검증없이, 항상검증, 저장/공유할 때 자동검증」 — 문제가 날 확률이 낮은데 늘 검증하면
#   비용(호출 두 배·5초)이 크다. 기본은 「저장/공유할 때」 — 남기거나 밖으로 내보내는 답만 검증한다.
#   ★ 없는 장·절을 걷는 기계 검사(`machine_drop`)는 **모드와 상관없이 늘** 한다(비용 0).
VERIFY_MODES = ('OFF', 'ALWAYS', 'SAVE')
VERIFY_MODE_KEY = 'AI_VERIFY_MODE'
VERIFY_MODE_DEFAULT = 'SAVE'


def verify_mode(conn):
    m = (get_setting(conn, VERIFY_MODE_KEY, '') or '').strip().upper()
    return m if m in VERIFY_MODES else VERIFY_MODE_DEFAULT


def set_verify_mode(conn, mode):
    m = (mode or '').strip().upper()
    if m not in VERIFY_MODES:
        raise ValueError(mode)
    set_setting(conn, VERIFY_MODE_KEY, m)


def _v_on(conn, _call, verify):
    """이번 답을 받는 자리에서 검증하나 — 명시 > 시험용 가짜 call(끔) > 모드(항상검증일 때만)."""
    if verify is not None:
        return bool(verify)
    if _call is not None:
        return False
    return verify_mode(conn) == 'ALWAYS'


def machine_drop(conn, text, lang='KO'):
    """없는 장·절이 든 문장을 기계로 걷는다(AI 를 안 부른다) → `(글, [걷은 표기])`. ▷ 줄은 그대로."""
    core, qs = split_next(text or '')
    try:
        import scripture_ref as SR
        bad = SR.bad_refs(conn, core, lang or 'KO')
    except Exception as e:                                # noqa: BLE001
        print('[machine refs] %s' % e)
        bad = []
    if not bad:
        return text, []
    out = _drop_at(core, [p_ for _m, p_ in bad])
    if qs:
        out += NL + NL + NL.join(NEXT_MARK + ' ' + q for q in qs)
    return out, [m for m, _p in bad]


def unverified_ids(conn, chat_id):
    """그 채팅에서 아직 검증되지 않은(또는 검증 못 한) AI 답 번호."""
    return [r[0] for r in conn.execute(
        "SELECT msg_id FROM user_ai_msg WHERE chat_id=? AND role='ai' AND COALESCE(verify,'')<>'OK'"
        " AND TRIM(COALESCE(body,''))<>'' ORDER BY msg_id", (int(chat_id),))]


def same_answer(a, b):
    """★ 2026-10-21 「고쳤나」 판정 — 제안 질문(▷) 줄과 빈칸·줄바꿈 차이는 고친 것이 아니다.
    (실측 검증된 분야 답 7개 중 6개가 ▷ 앞 빈 줄 하나로 「고쳤습니다」가 떴다 — 우리 코드가 다시 붙이며 낸 차이)"""
    import re as _re
    n = lambda t: _re.sub(r'\s+', ' ', strip_next(t or '')).strip()
    return n(a) == n(b)


def _rejoin(orig, core, new_core):
    """검증한 본문을 원래 답 자리에 다시 넣는다 — 바뀐 것이 없으면 원래 글 그대로 · 있으면 ▷ 줄은 원래 모양 그대로 뒤에."""
    if same_answer(core, new_core):
        return orig
    tail = orig[len(core):] if orig.startswith(core) else ''
    if not tail:
        _c, qs = split_next(orig)
        tail = (NL + NL + NL.join(NEXT_MARK + ' ' + x for x in qs)) if qs else ''
    return new_core.rstrip() + tail


def ensure_verified(conn, chat_id, _call=None):
    """저장·공유 전에 — 그 채팅의 검증 안 된 답을 모두 검증한다 → `{checked, changed:[id], failed:[id], diffs:[(id, 원래, 고친)]}`.
    이미 검증한 답은 건너뛴다(같은 답을 두 번 부르지 않는다). `changed` 는 **내용이 실제로 바뀐 것만**(`same_answer`)."""
    out = {'checked': 0, 'changed': [], 'failed': [], 'diffs': []}
    for mid in unverified_ids(conn, chat_id):
        old = conn.execute("SELECT body FROM user_ai_msg WHERE msg_id=?", (mid,)).fetchone()[0] or ''
        v = reverify(conn, mid, _call=_call)
        out['checked'] += 1
        if v.get('state') == 'FAIL':
            out['failed'].append(mid)
        elif not same_answer(v.get('text') or '', old):
            out['changed'].append(mid)
            out['diffs'].append((mid, strip_next(old), strip_next(v.get('text') or '')))
    return out


def keep_original(conn, msg_ids):
    """★ 2026-10-21 비교 화면 [원래 글로 저장] — 검증이 고친 답을 원래 글로 되돌린다(검증은 한 것으로 둔다)."""
    for mid in msg_ids or []:
        r = conn.execute("SELECT raw FROM user_ai_msg WHERE msg_id=?", (int(mid),)).fetchone()
        if r and r[0]:
            conn.execute("UPDATE user_ai_msg SET body=?, raw=NULL WHERE msg_id=?", (r[0], int(mid)))
    conn.commit()


def _verified(conn, ch, acc, text, question, fn, on):
    """보낸 자리에서 부른다 → `(본문, verify, raw)`. 끄면 기계 검사(없는 장·절)만."""
    text = strip_md(text)                               # ★ 2026-10-24 마크다운 기호를 먼저 걷는다(답·통합·한 글로 모두 이 문)
    if not on:
        t2, _bad = machine_drop(conn, text, ch.get('lang') or 'KO')
        return t2, '', (text if t2 != text else None)
    # ★ 2026-10-16 — 제안 질문(▷ 줄)은 검증에서 뺀다(물음표 줄을 문장째 지울 수 있다) · 검증 뒤 다시 붙인다
    core, qs = split_next(text)
    tail = (NL + NL + NL.join(NEXT_MARK + ' ' + q for q in qs)) if qs else ''
    v = verify_answer(conn, acc, core, question, _verify_ctx(conn, ch), ch.get('lang') or 'KO', fn=fn)
    if v['state'] == 'FAIL':
        return text, 'FAIL', text
    out = _rejoin(text, core, v['text'])            # ★ 2026-10-21 바뀐 것이 없으면 원래 글 그대로(빈 줄 하나도 안 바꾼다)
    return out, 'OK', (text if out != text else None)


def send(conn, chat_id, user_text, prompt_body='', _call=None, teach_start=False, with_notes=False,
         notes_scope='RANGE', _models=None, only=None, with_links=False, verify=None):
    """한 번 주고받는다 — 사용자 말과 AI 답을 **둘 다** 대화에 담는다.

    ★ 299차 — **켠 계정 전부**에 보내고 답을 전부 담는다(답마다 provider·model). 각 AI 에게는
      사용자 말 + **그 AI 자신의 앞 답**만 싣는다(남의 답을 제 답으로 알지 않게).
    `teach_start=True` 면 사용자 말 없이 AI 가 먼저 묻게 한다(성경교사).
    망·키 문제는 `{ok:False, why}` 로 돌아온다 — 담긴 것은 사용자 말뿐이다.
    반환 `{ok, text(첫 답), why, results:[…], switched:[(회사, 옛 모델, 새 모델)]}`.

    ★ 300차 — 모델 이름이 그 키에 없으면(404) **스스로 키에게 묻고 바꿔 다시 보낸다.**
      바꾼 것은 저장하고 `switched` 로 알린다(화면이 한 줄로 말한다 — 조용히 안 고친다).
    """
    ch = chat(conn, chat_id)
    if _call is None and ch:              # AI 측정 — 자리·프롬프트 이름만 기기 안에 · 글은 없다(docs/통계_설계.md §6)
        try:
            import usage_stats as _US
            _k = str(ch.get('kind') or '')
            _US.engage_hit('ai:place:%s' % (ch.get('scope') or 'VERSE'))
            _US.engage_hit('ai:prompt:%s' % ('USER' if _k.startswith(('USER', 'UT_')) else (_k or 'NONE')))
            _US.engage_hit('ai:step:%s' % ('ask' if enabled_accounts(conn) else 'nokey'))
            _US.engage_hit('ai:use')
        except Exception:
            pass
    if not ch:
        return {'ok': False, 'why': '그런 대화가 없습니다.', 'text': '', 'results': []}
    accts = enabled_accounts(conn)
    # ★ 317차-8 — `only=[열쇠]` 면 **그 AI 에게만**(AI결과 창의 후속 질문)
    if only:
        _ok = set(only)
        accts = [a for a in accts if acct_key(a) in _ok]
    if not accts:
        return {'ok': False, 'why': 'API 키가 없습니다 — [설정]에서 회사와 키를 넣고 체크하세요.', 'text': '', 'results': []}
    rows0 = msg_rows(conn, chat_id)
    target = acct_key(accts[0]) if (only and len(accts) == 1) else ''
    sysx = system_text(conn, ch, prompt_body, with_notes=with_notes, notes_scope=notes_scope,
                       with_links=with_links)
    if not teach_start and str(ch.get('kind') or '') not in NO_NEXT_KINDS:
        # ★ 2026-10-16 이어서 묻기 — AI 가 답 끝에 제안 질문 셋(▷)을 적게 한다(화면이 1·2·3 으로)
        sysx = (sysx.rstrip() + NL + NL + next_rule(ch.get('lang') or 'KO')).strip()
    if teach_start:
        opener = {'KO': '시작해 주세요.', 'JA': '始めてください。', 'ZH': '请开始。', 'ZHT': '請開始。',
                  'DE': 'Bitte beginnen.', 'FR': 'Commençons.', 'ES': 'Empecemos.', 'PT': 'Vamos começar.',
                  'RU': 'Начнём.', 'AR': 'لنبدأ.'}.get(ch['lang'], 'Please begin.')
        last = ('user', opener)
    else:
        user_text = (user_text or '').strip()
        if not user_text:
            return {'ok': False, 'why': '보낼 말이 없습니다.', 'text': '', 'results': []}
        add_msg(conn, chat_id, 'user', user_text, target=target)
        last = ('user', user_text)
    fn = _call or call
    # ★ 2026-10-15 — 답을 받으면 **같은 AI 로 검증한 뒤에야** 담는다(검증 전 답은 화면에 안 나온다).
    #   시험용 가짜 call 을 넣으면 따로 켜지 않는 한 검증을 건너뛴다(옛 시험의 가짜 답이 검증에 휩쓸리지 않게).
    v_on = _v_on(conn, _call, verify)
    results, first, fails, switched, busy = [], '', [], [], []
    for acc in accts:
        # ★ 317차-8 — **그 AI 의 줄기만** — 모두에게 간 말 + 그 AI 에게만 간 말 + 그 AI 의 대화 답
        #   (옛 답에 provider 가 비었으면 모델 이름으로 잇는다 · 통합본은 안 싣는다)
        _k = acct_key(acc)
        hist = [(m['role'], m['body']) for m in rows0
                if (m['role'] == 'user' and m['target'] in ('', _k))
                or (m['role'] == 'ai' and not m['mkind']
                    and (not m['model'] or m['model'] == acc['model']))]
        # ★ 2026-10-13 「86초」 — **헤지 요청**: 그 모델에 묻고, HEDGE 초 안에 답이 없거나 붐빈다고 하면
        #   다른 모델들에도 함께 묻고 **먼저 온 답**을 쓴다(저장은 안 바꾼다 · 화면이 그렇다고 말한다).
        res, won = _hedged(fn, acc, hist + [last], sysx,
                           lambda: busy_alternates(conn, acc['provider'], acc['key'], acc['model'],
                                                   _list=_models)[:BUSY_TRY])
        if won and won != acc['model']:
            # ★ 2026-10-21 창 1:31 성경공부 실측 — 붐벼서 다른 모델이 답하면 그 이름으로 담아 **AI 가 하나 더 생겼다**
            #   (통합화면 칸이 둘로 갈리고 「대화 통합」이 그 답을 빼먹었다). 담는 이름은 **그 계정의 모델** 그대로 —
            #   어느 모델이 대신 답했는지는 진행 줄이 말한다(busy).
            busy.append((acc['provider'], acc['model'], won))
        if not res.get('ok') and res.get('code') == NOT_FOUND:
            # 그 이름을 이 키가 모른다 — **묻고 바꿔 한 번만 다시 보낸다**(300차)
            got = pick_model(conn, acc['provider'], acc['key'], acc['model'], _list=_models)
            if got.get('ok'):
                old_m, new_m = acc['model'], got['model']
                res2 = fn(acc['provider'], acc['key'], new_m, hist + [last], system=sysx)
                if res2.get('ok'):
                    switch_model(conn, acc['provider'], old_m, new_m)
                    acc['model'] = new_m
                    switched.append((acc['provider'], old_m, new_m))
                    res = res2
        ok = bool(res.get('ok'))
        vst = ''
        if ok:
            body, vst, raw = _verified(conn, ch, acc, res['text'], last[1], fn, v_on)
            body = _cut_note(body, res, ch.get('lang'))
            add_msg(conn, chat_id, 'ai', body, res.get('tokens'), acc['provider'], acc['model'],
                    verify=vst, raw=raw)
            res = dict(res, text=body)
            first = first or body
        else:
            fails.append('%s: %s' % (acc['model'], res.get('why', '')))
        results.append({'provider': acc['provider'], 'model': acc['model'], 'ok': ok,
                        'text': res.get('text', ''), 'why': res.get('why', ''), 'verify': vst})
    return {'ok': bool(first), 'text': first, 'why': ' / '.join(fails), 'results': results,
            'switched': switched, 'busy': busy}


def merge_text(conn, chat_id, lang=None, with_q=False):
    """대화를 **한 편의 글**로 — AI 없이 기계로 잇는다(질문/답 머리말만 붙인다).

    ★★★ **기본은 답만 잇는다**(312차 사용자 「연구자료 저장 버튼을 누를 때
      **프롬프트 내용을 전부 포함해서 저장**하고 있다. 프롬프트 내용까지 저장할
      필요는 없는 것 같다. **자동 제거하거나 옵션을 제시**하는 것이 좋을 것 같다」).
    ⚠⚠ 까닭 = **사용자 말이 곧 조립된 프롬프트 전문**이다 — `send` 가 화면 입력
      칸의 글(= `compose` 결과: 물음 + 자유 + 깊이 + 관점 + 금지사항 + 출력서식)을
      그대로 담는다. 연구자료로 남길 것은 **AI 의 답**이다.
    ⚠ `with_q=True` 면 종전처럼 물음도 싣는다 — **화면 체크가 그것을 정한다**
      (자동으로 걷되 되살릴 자리를 남긴다).
    """
    ch = chat(conn, chat_id)
    if not ch:
        return ''
    lg = (lang or ch['lang'] or 'KO').upper()
    q_lbl = {'KO': '물음', 'JA': '問い', 'ZH': '提问', 'ZHT': '提問', 'DE': 'Frage', 'FR': 'Question',
             'ES': 'Pregunta', 'PT': 'Pergunta', 'RU': 'Вопрос', 'AR': 'سؤال'}.get(lg, 'Question')
    a_lbl = {'KO': '답', 'JA': '答え', 'ZH': '回答', 'ZHT': '回答', 'DE': 'Antwort', 'FR': 'Réponse',
             'ES': 'Respuesta', 'PT': 'Resposta', 'RU': 'Ответ', 'AR': 'جواب'}.get(lg, 'Answer')
    out = [ch['title'] or (range_label(conn, ch['start_vid'], ch['end_vid'], lg) if ch['start_vid'] else ''), '']
    rows = msgs_full(conn, chat_id)
    many = len({m for _i, r, _b, _t, _p, m in rows if r == 'ai' and m}) > 1
    for _i, role, body, _t, _p, model in rows:
        if role == 'user':
            if not with_q:
                continue          # ★ 프롬프트 전문은 담지 않는다(312차 · 위 머리글)
            out.append('%s: %s' % (q_lbl, body))
        elif role == 'ai':
            out.append('%s%s: %s' % (a_lbl, (' (%s)' % model) if (many and model) else '', strip_next(body)))
        out.append('')
    return NL.join(out).strip()


def default_ref_title(conn, chat_id, lang=None):
    """신규 저장 때 **제목 칸에 미리 채워 둘 글자** — 닻 이름(구절 약명·용어).

    ★ 화면이 제 손으로 짓지 않는다 — **담는 쪽과 같은 글자**라야 사용자가
      고치지 않고 그냥 저장했을 때 예전과 똑같은 제목이 된다(두 곳에서 지으면
      「칸에 보이던 것과 저장된 것이 다르다」가 난다).
    """
    ch = chat(conn, chat_id)
    if not ch:
        return ''
    lg = (lang or ch['lang'] or 'KO').upper()
    return ch['title'] or range_label(conn, ch['start_vid'], ch['end_vid'], lg)


def ref_title(conn, ref_id):
    """그 「내 자료」의 지금 제목 — 없으면 빈 글(화면이 무엇을 덮는지 말하려고)."""
    try:
        r = conn.execute("SELECT title FROM user_ref_asset WHERE ref_id=?",
                         (int(ref_id),)).fetchone()
        return (r[0] or '').strip() if r else ''
    except Exception:                                     # noqa: BLE001
        return ''


def save_as_ref(conn, chat_id, text=None, lang=None, title=None, with_q=False, link=True):
    """합친 글을 「내 자료」(`user_ref_asset`)로 담는다 — 개인 DB → `ref_id`.

    ★★★ **한 대화에 자료 한 편이다 — 두 번 누르면 덮어쓴다**(2026-09-30 사용자
      「이 버튼을 누른 만큼 계속 반복저장된다. 동일한 데이터라면 굳이 반복저장할
      필요가 없다. **오히려 수정된 내용을 덮어써야 한다**」).
      ⚠ 그전에는 무조건 `INSERT` 라 실측 한 대화가 **3벌**로 쌓였다(시 17:15).
    ★ 기억하는 자리 = `user_ai_chat.ref_id`(멱등 ALTER). 대화가 자라면 같은
      자료가 **최신 글로 갈린다** — 새 편이 생기지 않는다.
    ⚠ **사용자가 그 자료를 지웠으면 새로 만든다** — 지운 것을 되살리지 않고,
      빈 번호를 붙들고 있지도 않는다.
    """
    ch = chat(conn, chat_id)
    if not ch:
        return None
    lg = (lang or ch['lang'] or 'KO').upper()
    body = text if text is not None else merge_text(conn, chat_id, lg, with_q=with_q)
    # ★★★ **제목은 사람이 정한다**(2026-09-30 docs/1.txt 1번 4열 — 「저장할 때
    #   구절이름만 표시하고 있음 … 신규저장인 경우 제목을 입력할 기회를 주어야
    #   함」). 그전에는 언제나 닻 이름이라 자료 목록이 「창 1:1」로만 늘어섰다.
    given = (title or '').strip()
    auto = ch['title'] or range_label(conn, ch['start_vid'], ch['end_vid'], lg)
    import db_user_ref_schema as U
    U.init(conn)
    init(conn)           # ⚠ `ref_id` 칸은 **init 의 이주 루프**가 만든다(자리 하나)
    old = None
    try:
        r = conn.execute("SELECT ref_id FROM user_ai_chat WHERE chat_id=?",
                         (int(chat_id),)).fetchone()
        old = int(r[0]) if r and r[0] else None
    except Exception:                                     # noqa: BLE001
        old = None
    if old:
        alive = conn.execute(
            "SELECT 1 FROM user_ref_asset WHERE ref_id=?"
            " AND COALESCE(record_status,'LIVE')='LIVE'", (old,)).fetchone()
        if not alive:
            old = None
    if old:
        # ⚠⚠ **고칠 때는 제목을 안 덮는다** — 처음 저장할 때 사람이 붙인 제목을
        #   두 번째 [저장]이 닻 이름으로 되돌리면 그 손길을 잃는다. 사람이 새
        #   제목을 대 주었을 때만 바꾼다.
        t = given or ref_title(conn, old) or auto
        conn.execute(
            "UPDATE user_ref_asset SET verse_id=?, title=?, author=?, lang_code=?"
            " WHERE ref_id=?",
            (ch['start_vid'] or None, t, 'AI · ' + (ch['provider'] or ''),
             lg, old))
        body, _tb = _absorb_tables(body)           # ★ 317차-18 — AI 가 쓴 표를 구조로
        U.set_text(conn, old, lg, t, body)
        _sync_tables(conn, old, _tb, lg)
        conn.commit()
        link_verses(conn, old, body, lg, add=link)    # ★ 314차 — 구절 자동 연결(link=False 면 사라진 것만 걷는다)
        return old
    t = given or auto
    cur = conn.execute(
        "INSERT INTO user_ref_asset(verse_id, ref_type, title, author, source_name, url, summary,"
        " file_path, lang_code, record_status) VALUES(?,?,?,?,?,?,?,?,?,'LIVE')",
        (ch['start_vid'] or None, 'SERMON' if str(ch.get('kind') or '') in ('T:SERMON', 'T:SERMWR') else 'STUDY', t,
         'AI · ' + (ch['provider'] or ''), 'AI 대화', '', '', '', lg))
    rid = int(cur.lastrowid)
    try:                                           # ★ 2026-10-16 출처 = AI 작성(docs/1.txt 2-2 · ref_kinds)
        import ref_kinds
        ref_kinds.ensure(conn)
        conn.execute("UPDATE user_ref_asset SET ref_origin='AI', ai_edited=0 WHERE ref_id=?", (rid,))
    except Exception as e:                                # noqa: BLE001
        print('[save_as_ref origin] %s' % e)
    body, _tb = _absorb_tables(body)               # ★ 317차-18 — AI 가 쓴 표를 구조로
    U.set_text(conn, rid, lg, t, body)
    _sync_tables(conn, rid, _tb, lg)
    try:
        conn.execute("UPDATE user_ai_chat SET ref_id=? WHERE chat_id=?",
                     (rid, int(chat_id)))
    except Exception:                                     # noqa: BLE001
        pass
    conn.commit()
    link_verses(conn, rid, body, lg, add=link)    # ★ 314차 — 구절 자동 연결(link=False 면 사람이 연구/설교노트 추천 줄에서 확정)
    return rid


def _absorb_tables(body):
    """글 속 `|` 표·격자 표 → 자리표 + 구조(ref_doc). 실패하면 글 그대로."""
    try:
        import ref_doc as _RD
        return _RD.absorb(body or '')
    except Exception:                                     # noqa: BLE001
        return body, {}


def _sync_tables(conn, rid, tables, lang):
    try:
        import ref_doc as _RD
        _RD.sync_all(conn, 'USER', rid, tables, lang, commit=False)
    except Exception as e:                                # noqa: BLE001
        print('[user_ai tables] %s' % e)


def link_verses(conn, ref_id, body, lang, add=True):
    """글 안의 구절약명을 읽어 **그 글에 자동으로 연결한다** → 보탠 수.

    ★★★ 사용자 지시(314차) — 「사용자가 AI를 이용해서 연구자료 작성한 경우
      **저장하면 구절 연결이 자동으로 이루어져야 한다**」.
    ★ 읽는 문은 `scripture_ref` **하나**다 — 관리자·AI 작업대와 같은 문이라
      「한쪽에서는 걸리는데 다른 쪽에서는 안 걸린다」가 안 난다(§219차 ⑤).
    ★★ **언어는 그 글의 언어**다(사용자 지시 「다국어 모드는 성경 버전이 아니라
      사용자가 설정한 언어 기준」) — 역본 언어가 아니다.
    ★★★ **동기화한다**(315차 사용자 지시 「구절약명이 수정되면 구절연결도
      수정되어야 한다. **구절이 추가로 연결되면 안된다**」) — 글에서 약명을
      지우면 그 연결도 사라진다. 돌려주는 값은 `(넣은 수, 지운 수)`.
      ⚠ 314차의 `add_links`(보태기만)로는 그 지시를 못 지킨다 — 같은 글을
        고쳐 가며 저장하면 **옛 좌표가 쌓인다.**
    ⚠⚠ **사람이 이은 것과 사용자가 지운 것은 건드리지 않는다**(`source` 가 가른다).
    ⚠ 터져도 저장을 되돌리지 않는다 — 글은 이미 담겼고 연결은 덧붙는 것이다.
    """
    try:
        import db_user_ref_schema as U
        import scripture_ref as SR
        # ★ 317차-18 ⑧ — 표 칸 안의 약명도 읽는다(본문엔 자리표뿐이라 안 읽으면 빠진다)
        try:
            import ref_doc as _RD
            body = (body or '') + '\n' + _RD.all_cells_text(conn, 'USER', int(ref_id), (lang or 'KO').upper())
        except Exception:                                 # noqa: BLE001
            pass
        # ★ 84-2 — 장·편만 적힌 참조는 연결하지 않는다(`SR.linkable`)
        got = SR.linkable(SR.find(conn, body or '', (lang or 'KO').upper(), limit=200))
        res = U.sync_links(conn, int(ref_id),
                           [('VERSE', a, b) for a, b, _m, _k in got], add=add)
        # ★ 2026-10-25 원어 — AI 답의 「뜻(음독…)」도 그 용어·원어에 잇는다(**확실한 것만** · 짐작은 추천 줄이 사람에게 묻는다)
        try:
            import orig_ref as _OR
            _o = [(k, t, None) for k, t, _m, _s in _OR.find(conn, body or '', (lang or 'KO').upper(), sure_only=True)]
            U.sync_links(conn, int(ref_id), _o, add=add, kinds=('ENTITY', 'LEMMA'))
        except Exception:                                 # noqa: BLE001
            pass
        return res
    except Exception:                                     # noqa: BLE001
        return (0, 0)


def ref_of(conn, chat_id):
    """그 대화가 만든 「내 자료」 번호 — 없거나 지웠으면 `None`."""
    init(conn)
    try:
        r = conn.execute("SELECT ref_id FROM user_ai_chat WHERE chat_id=?",
                         (int(chat_id),)).fetchone()
    except Exception:                                     # noqa: BLE001
        return None
    if not (r and r[0]):
        return None
    ok = conn.execute("SELECT 1 FROM user_ref_asset WHERE ref_id=?"
                      " AND COALESCE(record_status,'LIVE')='LIVE'",
                      (int(r[0]),)).fetchone()
    return int(r[0]) if ok else None


# ══════════════════════════════════════════════════════════════════════
#  자가 검증 — API 안 씀 · sys 불변 · 자국 0
# ══════════════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════════════
#  317차 4단계 — 저장 넷(연구자료 · 구절 설명문 · 용어 설명문 · 묵상분석)
# ══════════════════════════════════════════════════════════════════════
#: 갈래마다 [저장 ▾] 에 보일 것 — **그 갈래에 맞는 것만**(사용자 확정)
SAVES_OF = {
    # ★ 2026-10-14 LDESC = 연결설명문(연결 닻으로 연 대화에서만 · 화면이 가른다)
    'VERSE': ['REF', 'VDESC', 'NOTE', 'ROLE', 'LDESC'],      # ROLE = 분야 도움말(내 것 · role_tips · 2026-10-13)
    'TERM':  ['REF', 'TDESC'],
    'REF':   ['REF'],
    'FREE':  ['REF', 'VDESC', 'TDESC'],
}
#: 설명문 칸 → (text_type, 변형). ★ 관리자 묶음 칸 표(`db_ai_job.BUNDLE_PART`)와 같은 자리.
DESC_SAVE = [('DESC', 'VERS_DESC', 'LAY'), ('QUES', 'VERS_QUESTION', 'LAY'),
             ('PRAYER', 'VERS_PRAYER', ''), ('STUDY', 'VERS_QUESTION', 'EXPERT'),
             ('XDESC', 'VERS_DESC', 'EXPERT')]      # ★ 2026-10-14 전문 설명문
#: 업무마다 쓰는 칸 — 비교 화면이 지금 글도 이 칸만 보인다
DESC_KEYS_OF = {'DESC': ('DESC', 'QUES', 'PRAYER'), 'XDESC': ('XDESC', 'STUDY')}


def saves_for(scope):
    return list(SAVES_OF.get((scope or 'VERSE').upper(), []))


#: ★★★ 317차-8 — **모든 AI 통합** 기본 지시(사용자가 고칠 수 있다 · `user_config['AI_INTEG_PROMPT']`).
#:   사용자 「다른 AI 가 만든 의견을 단지 문서 통합하는 것이 아니라 사실관계, 논리 등을 함께 검증」.
#:   ⚠ 검증은 **따로 적게** 한다 — 통합본에 녹이면 AI 가 다툼을 조용히 한쪽으로 정리한다.
#:   ⚠ 「확인 불가」 칸이 있어야 한다 — 없으면 AI 가 확인한 척한다.
INTEG_SEED = {
    'KO': ('아래는 같은 물음에 여러 AI 가 낸 답이다(누가 썼는지는 가렸다). 다음 차례로 써라.\n'
           '1. 공통으로 맞는 내용\n'
           '2. 서로 다른 주장 — 답마다 무엇을 말했고 어느 쪽이 성경 본문과 재료에 맞는지 근거와 함께\n'
           '3. 사실 오류로 보이는 것 — 성경 인용 · 인물 · 연대 · 원어\n'
           '4. 근거 없이 주장한 것\n'
           '5. 확인 불가 — 본문과 재료로 확인할 수 없는 것은 확인했다고 하지 말고 여기에 적는다\n'
           '6. 통합본 — 위 검증을 반영해 한 편으로. 다툼이 남은 곳은 한쪽으로 정리하지 말고 두 견해를 함께 적는다.'),
    'EN': ('Below are answers from several AIs to the same question (authors hidden). Write, in this order:\n'
           '1. What they agree on and is correct\n'
           '2. Where they differ — what each says and which fits the Bible text and materials, with reasons\n'
           '3. Apparent factual errors — Bible quotations, people, dates, original language\n'
           '4. Claims made without support\n'
           '5. Cannot verify — anything the text and materials cannot confirm goes here; do not claim to have checked it\n'
           '6. Merged text — one piece reflecting the checks above. Where disagreement remains, present both views.'),
    'JA': ('以下は同じ問いへの複数のAIの回答です(作者は伏せています)。次の順で書いてください。\n'
           '1. 共通して正しい内容\n2. 食い違う主張 — 各回答の主張と、どちらが聖書本文と資料に合うか根拠とともに\n'
           '3. 事実の誤りと思われるもの — 聖書引用・人物・年代・原語\n4. 根拠なしの主張\n'
           '5. 確認不可 — 本文と資料で確かめられないことは確かめたと言わずここに書く\n'
           '6. 統合版 — 上の検証を反映して一つに。対立が残る所は一方にまとめず両方の見解を書く。'),
    'ZH': ('以下是多个AI对同一问题的回答(已隐去作者)。请按以下顺序写:\n'
           '1. 共同且正确的内容\n2. 不同的主张 — 各回答说了什么,哪一方符合圣经经文和资料,并说明依据\n'
           '3. 似乎有误的事实 — 经文引用、人物、年代、原文\n4. 没有依据的主张\n'
           '5. 无法核实 — 经文和资料无法证实的不要说已核实,写在这里\n'
           '6. 综合版 — 反映以上核查写成一篇。仍有分歧之处不要归于一方,两种观点都写。'),
    'ZHT': ('以下是多個AI對同一問題的回答(已隱去作者)。請按以下順序寫:\n'
            '1. 共同且正確的內容\n2. 不同的主張 — 各回答說了什麼,哪一方符合聖經經文和資料,並說明依據\n'
            '3. 似乎有誤的事實 — 經文引用、人物、年代、原文\n4. 沒有依據的主張\n'
            '5. 無法核實 — 經文和資料無法證實的不要說已核實,寫在這裡\n'
            '6. 綜合版 — 反映以上核查寫成一篇。仍有分歧之處不要歸於一方,兩種觀點都寫。'),
    'DE': ('Unten stehen Antworten mehrerer KIs auf dieselbe Frage (Verfasser verborgen). Schreibe in dieser Reihenfolge:\n'
           '1. Was übereinstimmt und richtig ist\n2. Wo sie sich unterscheiden — was jede sagt und was zum Bibeltext und Material passt, mit Begründung\n'
           '3. Mutmaßliche Sachfehler — Bibelzitate, Personen, Daten, Ursprache\n4. Unbegründete Behauptungen\n'
           '5. Nicht überprüfbar — was Text und Material nicht bestätigen, hier nennen, nicht als geprüft ausgeben\n'
           '6. Zusammenführung — ein Text, der die Prüfung berücksichtigt. Bleibt Streit, beide Sichten nennen.'),
    'FR': ('Voici les réponses de plusieurs IA à la même question (auteurs masqués). Écris dans cet ordre :\n'
           '1. Ce sur quoi elles s’accordent et qui est juste\n2. Leurs divergences — ce que dit chacune et laquelle s’accorde au texte biblique et aux documents, avec raisons\n'
           '3. Erreurs factuelles apparentes — citations bibliques, personnes, dates, langue originale\n4. Affirmations sans appui\n'
           '5. Invérifiable — ce que le texte et les documents ne confirment pas, à noter ici sans prétendre l’avoir vérifié\n'
           '6. Texte fusionné — un seul texte tenant compte de ces vérifications. Là où le désaccord demeure, donne les deux vues.'),
    'ES': ('Abajo están las respuestas de varias IA a la misma pregunta (autores ocultos). Escribe en este orden:\n'
           '1. Lo que coinciden y es correcto\n2. Dónde difieren — qué dice cada una y cuál concuerda con el texto bíblico y los materiales, con razones\n'
           '3. Errores de hecho aparentes — citas bíblicas, personas, fechas, idioma original\n4. Afirmaciones sin respaldo\n'
           '5. No verificable — lo que el texto y los materiales no confirman, anótalo aquí sin decir que lo verificaste\n'
           '6. Texto unificado — uno solo que refleje lo anterior. Donde quede desacuerdo, presenta ambas posturas.'),
    'PT': ('Abaixo estão as respostas de várias IAs à mesma pergunta (autores ocultos). Escreva nesta ordem:\n'
           '1. O que concordam e está correto\n2. Onde divergem — o que cada uma diz e qual concorda com o texto bíblico e os materiais, com razões\n'
           '3. Erros factuais aparentes — citações bíblicas, pessoas, datas, língua original\n4. Afirmações sem apoio\n'
           '5. Não verificável — o que o texto e os materiais não confirmam, anote aqui sem dizer que verificou\n'
           '6. Texto unificado — um só refletindo o acima. Onde restar divergência, apresente as duas visões.'),
    'RU': ('Ниже ответы нескольких ИИ на один вопрос (авторы скрыты). Напиши по порядку:\n'
           '1. В чём они согласны и что верно\n2. В чём расходятся — что говорит каждый и что соответствует библейскому тексту и материалам, с обоснованием\n'
           '3. Вероятные фактические ошибки — цитаты из Библии, люди, даты, язык оригинала\n4. Утверждения без основания\n'
           '5. Не проверить — то, что текст и материалы не подтверждают, укажи здесь, не утверждая, что проверил\n'
           '6. Объединённый текст — один, с учётом проверки. Где спор остаётся, приведи обе точки зрения.'),
    'AR': ('فيما يلي إجابات عدة نماذج ذكاء اصطناعي عن السؤال نفسه (أُخفي الكاتب). اكتب بهذا الترتيب:\n'
           '1. ما تتفق عليه وهو صحيح\n2. مواضع الاختلاف — ما تقوله كل إجابة وأيها يوافق النص الكتابي والمواد مع الأسباب\n'
           '3. أخطاء واقعية محتملة — الاقتباسات الكتابية والأشخاص والتواريخ واللغة الأصلية\n4. ادعاءات بلا سند\n'
           '5. لا يمكن التحقق — ما لا يؤكده النص والمواد اكتبه هنا ولا تدّعِ أنك تحققت منه\n'
           '6. النص الموحّد — نص واحد يعكس ما سبق. حيث يبقى الخلاف اعرض الرأيين.'),
}


def integ_prompt(conn, lang='KO'):
    """통합프롬프트 — 사용자가 고친 글이 먼저 · 없으면 그 언어 기본."""
    own = (get_setting(conn, 'AI_INTEG_PROMPT', '') or '').strip()
    if own:
        return own
    return INTEG_SEED.get((lang or 'KO').upper()) or INTEG_SEED['EN']


def integ_account(conn):
    """통합 담당 AI 열쇠 — [설정] 팝업이 정한 것(`AI_INTEG_ACCT`) · 그것이 꺼졌거나 없으면 **켠 계정 첫째**."""
    en = enabled_accounts(conn)
    keys = [acct_key(a) for a in en]
    k = (get_setting(conn, 'AI_INTEG_ACCT', '') or '').strip()
    if k in keys:
        return k
    return keys[0] if keys else ''


def set_integ_account(conn, key):
    set_setting(conn, 'AI_INTEG_ACCT', key or '')


def _acct_of(conn, key):
    for a in accounts(conn):
        if acct_key(a) == key and a.get('key'):
            return a
    return None


def integrate(conn, chat_id, integ_key, prompt=None, _call=None, verify=None):
    """**모든 AI 통합**(317차-8) — 통합 담당 AI **하나**에게 첫 물음 + 줄기마다 후속 물음 + 마지막 답을
    **이름을 가려**(답 A · 답 B …) 보낸다. 결과는 `mkind='INTEG'` 로 담고 `target` 에 가린 이름 짝을 적는다.

    ⚠ 차례를 섞는다 — 통합 담당이 제 답을 맨 앞에서 알아보지 않게.
    ⚠ 시스템 글 = 필수 지침 + 재료(구절 본문 등) — 기억이 아니라 본문을 보고 검증하게.
    """
    import random as _r
    ch = chat(conn, chat_id)
    if not ch:
        return {'ok': False, 'why': '그런 대화가 없습니다.'}
    acc = _acct_of(conn, integ_key)
    if not acc:
        return {'ok': False, 'why': '통합 담당 AI 의 키가 없습니다.'}
    ais = chat_ais(conn, chat_id)
    if not ais:
        return {'ok': False, 'why': '통합할 답이 없습니다.'}
    rows = msg_rows(conn, chat_id)
    blocks = []
    for p_, md in ais:
        k = acct_key(p_, md)
        body, _mk = latest_of(conn, chat_id, k)
        if not body.strip():
            continue
        follow = [m['body'] for m in rows if m['role'] == 'user' and m['target'] == k]
        blocks.append((k, md, follow, body))
    if not blocks:
        return {'ok': False, 'why': '통합할 답이 없습니다.'}
    _r.Random(int(chat_id)).shuffle(blocks)
    letters = 'ABCDEFGH'
    parts = [(prompt or integ_prompt(conn, ch['lang'])).strip() + _fmt_tail(conn, ch['lang'], chat_id), '',
             '[첫 물음]', first_question(conn, chat_id).strip()]
    mp = []
    for i, (k, md, follow, body) in enumerate(blocks):
        parts += ['', '[답 %s]' % letters[i]]
        if follow:
            parts.append('(이 답에 이어진 물음: %s)' % ' / '.join(f.strip()[:200] for f in follow))
        parts.append(body.strip())
        mp.append('%s=%s' % (letters[i], md))
    sysx = system_text(conn, ch, '')
    fn = _call or call
    res = _call_long(fn, acc, [('user', NL.join(parts))], sysx)
    if not res.get('ok'):
        return {'ok': False, 'why': res.get('why', '')}
    body, vst, raw = _verified(conn, ch, acc, res['text'], first_question(conn, chat_id), fn,
                               _v_on(conn, _call, verify))
    body = _cut_note(body, res, ch.get('lang'))
    add_msg(conn, chat_id, 'ai', body, res.get('tokens'), acc['provider'], acc['model'],
            target=' · '.join(mp), mkind='INTEG', verify=vst, raw=raw)
    return {'ok': True, 'text': body, 'map': ' · '.join(mp), 'verify': vst}


#: ★ 2026-10-21 창 1:31 성경공부 실측 — 대화 통합본이 출력 한도 2048 토큰(n_out 2044)에서 문장 중간에 잘려
#:   뒤 주제 셋이 빠졌다 ⇒ 한 글로 엮는 일(대화 통합 · 모든 AI 통합 · 그 검증)은 한도를 넉넉히 · 잘리면 글 끝에 알린다
MERGE_OUT = 8192
CUT_NOTE = {'KO': '⚠ 글이 길어 AI 가 끝까지 쓰지 못하고 잘렸습니다 — 대화를 나누어 통합하거나 다시 시도하세요.',
            'EN': '⚠ The text was too long and the AI stopped before finishing — try merging in parts or again.'}


def chat_format(conn, chat_id, lang='KO'):
    """그 채팅이 **실제로 보낸** 출력서식 — 첫 물음의 「[출력서식]」 칸(다음 칸 머리까지). 없으면 ''."""
    head = '[%s]' % slot_head(lang).get('FORMAT', 'FORMAT')
    for r in msg_rows(conn, chat_id):
        if r['role'] != 'user':
            continue
        b = r['body'] or ''
        i = b.find(head)
        if i < 0:
            return ''
        rest = b[i + len(head):]
        out = []
        for ln in rest.split(chr(10)):
            if ln.startswith('[') and ln.rstrip().endswith(']') and out:
                break
            out.append(ln)
        return chr(10).join(out).strip()
    return ''


def _fmt_tail(conn, lang, chat_id=None):
    """★ 2026-10-21 창 1:31 — 통합본의 모양이 그때그때 달랐다(처음엔 번호 개요 · 다시 하니 문단만).
    한 글로 엮을 때도 **그 채팅이 쓴 출력서식**(첫 물음에 실린 것)을 함께 보낸다 — 대화의 답과 같은 모양으로.
    ⚠ 「지금 출력서식」을 쓰면 안 된다 — 화면에서 마지막으로 고른 질문(예: 질문하기 = 대화식)을 따라 바뀐다."""
    f = chat_format(conn, chat_id, lang) if chat_id else ''
    if not f:
        f = (part_raw(conn, 'FORMAT') or '').strip()
    if not f:
        return ''
    return chr(10) + chr(10) + '[%s]' % slot_head(lang).get('FORMAT', 'FORMAT') + chr(10) + f


def _call_long(fn, acc, msgs, system):
    try:
        return fn(acc['provider'], acc['key'], acc['model'], msgs, system=system, max_out=MERGE_OUT)
    except TypeError:                                     # 시험용 가짜 call 은 max_out 을 모를 수 있다
        return fn(acc['provider'], acc['key'], acc['model'], msgs, system=system)


def _cut_note(body, res, lang):
    if (res.get('tokens') or {}).get('cut'):
        return (body or '').rstrip() + chr(10) + chr(10) + (CUT_NOTE.get((lang or 'KO').upper()) or CUT_NOTE['EN'])
    return body


def self_merge(conn, chat_id, key, _call=None, verify=None):
    """**그 AI 의 대화 통합**(317차-8) — 그 AI 의 줄기 + 「한 글로」 지시를 **그 AI 에게** 보낸다.
    결과는 `mkind='SELF'` — 그 AI 칸에 보이고 다음 대화에는 안 실린다."""
    ch = chat(conn, chat_id)
    acc = _acct_of(conn, key)
    if not ch or not acc:
        return {'ok': False, 'why': '그 AI 의 키가 없습니다.'}
    th = thread_of(conn, chat_id, key)
    if not th:
        return {'ok': False, 'why': '통합할 대화가 없습니다.'}
    body = merge_prompt_body(conn, ch['lang']) + _fmt_tail(conn, ch['lang'], chat_id)
    fn = _call or call
    res = _call_long(fn, acc, th + [('user', body)], system_text(conn, ch, ''))
    if not res.get('ok'):
        return {'ok': False, 'why': res.get('why', '')}
    body, vst, raw = _verified(conn, ch, acc, res['text'], first_question(conn, chat_id), fn,
                               _v_on(conn, _call, verify))
    body = _cut_note(body, res, ch.get('lang'))
    add_msg(conn, chat_id, 'ai', body, res.get('tokens'), acc['provider'], acc['model'], mkind='SELF',
            verify=vst, raw=raw)
    return {'ok': True, 'text': body, 'verify': vst}


def chat_state(conn, chat_id):
    """가운데 상태 한 줄의 재료 — `{ais:[(이름, 답 수)], integ:bool, selfs:n}`."""
    out = {'ais': [], 'integ': False, 'selfs': 0}
    if not chat_id:
        return out
    cnt = {}
    for m in msg_rows(conn, chat_id):
        if m['role'] != 'ai':
            continue
        if m['mkind'] == 'INTEG':
            out['integ'] = True
        elif m['mkind'] == 'SELF':
            out['selfs'] += 1
        else:
            k = (m['provider'], m['model'])
            cnt[k] = cnt.get(k, 0) + 1
    out['ais'] = [(short_name({'provider': p_, 'model': md}) or md or p_ or 'AI', n) for (p_, md), n in cnt.items()]
    return out


def last_answer(conn, chat_id):
    """그 채팅의 **마지막 AI 답**(없으면 빈 글)."""
    r = conn.execute("SELECT body FROM user_ai_msg WHERE chat_id=? AND role='ai'"
                     " AND COALESCE(mkind,'')='' ORDER BY msg_id DESC LIMIT 1", (int(chat_id),)).fetchone()
    return (r[0] or '') if r else ''


def answer_text(conn, chat_id, mode='ALL', lang=None, with_q=False):
    """저장할 글 — `LAST` 마지막 답만 · `ALL` 채팅 전체(요구사항은 `with_q` 일 때만).

    ⚠ 「요구사항도 함께」는 **채팅 전체일 때만** 뜻이 있다 — 마지막 답만이면 무시한다.
    """
    if (mode or '').upper() == 'LAST':
        return last_answer(conn, chat_id)
    return merge_text(conn, chat_id, lang, with_q=with_q)


def ref_title_clash(conn, title, chat_id):
    """그 제목을 **다른 채팅이 만든** 내 자료가 이미 쓰는가 → 그 `ref_id` 또는 None.

    ★ 같은 채팅이면 덮어쓰기라 겹침이 아니다(사용자 확정 — 「같은 채팅은 덮어쓴다 ·
      다른 채팅인데 제목이 같으면 막는다」).
    """
    t = (title or '').strip()
    if not t:
        return None
    try:
        r = conn.execute("SELECT ref_id FROM user_ai_chat WHERE chat_id=?", (int(chat_id),)).fetchone()
        mine = int(r[0]) if r and r[0] else None
    except Exception:                                     # noqa: BLE001
        mine = None
    for (rid,) in conn.execute("SELECT ref_id FROM user_ref_asset WHERE TRIM(title)=?"
                               " AND COALESCE(record_status,'LIVE')='LIVE'", (t,)):
        if rid != mine:
            return int(rid)
    return None


def desc_current(conn, vid, lang='KO'):
    """그 구절의 지금 설명문 네 칸 — `{칸: 글}`(덮개 적용 · 가린 것은 빈 글)."""
    import overlay_edit as OE
    out = {}
    for k, tt, var in DESC_SAVE:
        _v, st, txt = OE.target_state(conn, tt, int(vid), lang, var)
        out[k] = (txt or '') if st in ('SYS', 'EDIT', 'NEW') else ''
    return out


def desc_join(parts, lang='KO'):
    """칸 → 한 덩이(그 언어 칸 이름) — 비교 화면이 그린다 · `split_desc` 가 되읽는다."""
    marks = DESC_MARKS.get((lang or 'KO').upper()) or DESC_MARKS['EN']
    out = []
    for (k, _tt, _var), m in zip(DESC_SAVE, marks):
        t = (parts.get(k) or '').strip()
        if t:
            out += ['[%s]' % m, t, '']
    return NL.join(out).strip()


def desc_save(conn, vid, lang, parts):
    """구절 설명문을 **내 버전(덮개)** 으로 담는다 → 담은 칸 수.

    ★ sys 글을 고치지 않는다 — 덮개(`overlay_edit.save_mine`)라 되돌릴 수 있다(§C-2).
    ⚠ 비어 있는 칸은 안 건드린다(AI 가 그 칸을 안 썼다고 지금 글을 지우지 않는다).
    """
    import overlay_edit as OE
    n = 0
    for k, tt, var in DESC_SAVE:
        t = (parts.get(k) or '').strip()
        if not t:
            continue
        _v, _st, _txt = OE.target_state(conn, tt, int(vid), lang, var)
        OE.save_mine(conn, tt, int(vid), lang, _v if _v is not None else var, t)
        n += 1
    conn.commit()
    return n


#: ★ 2026-10-14 원어 설명(내 글) — 용어로 승격 안 된 낱말에 사용자가 붙이는 설명(docs 「원어 · 용어와 같은 수준」).
#:   열쇠 = 스트롱 번호를 수로(H2617 → 1002617 · G1656 → 2001656) · 칸 `LEMMA_DESC` · 덮개(`overlay_edit`)로 담는다.
#:   ⚠ 관리자가 그 낱말을 용어로 승격하면 이 글을 그 용어의 「내 설명문」으로 옮긴다(data.md Z-3j).
LEMMA_TEXT = 'LEMMA_DESC'


def lemma_key(strong):
    s = (strong or '').strip().upper()
    if len(s) < 2 or s[0] not in 'HG' or not s[1:].isdigit():
        return None
    return (1000000 if s[0] == 'H' else 2000000) + int(s[1:])


def lemma_note(conn, strong, lang='KO'):
    """그 낱말의 내 원어 설명 — 없으면 ''."""
    k = lemma_key(strong)
    if k is None:
        return ''
    import overlay_edit as OE
    _v, st, txt = OE.target_state(conn, LEMMA_TEXT, k, lang, '')
    return (txt or '') if st in ('EDIT', 'NEW') else ''


def migrate_lemma_notes(conn):
    """★ 2026-10-14 승격 뒤 옮기기 — 관리자가 그 낱말을 용어로 올리면(팩으로 `sys_entity_lemma` 가 온다)
    내 「원어 설명」을 그 용어의 **내 설명문**으로 옮기고 원어 설명 줄은 가린다(HIDE · 되돌릴 수 있다).
    ⚠ 그 용어에 내 설명문이 이미 있으면 덮지 않는다(그대로 둔다 · 다음에도 안 옮긴다 — 사람이 둘을 견준다).
    → 옮긴 수."""
    import overlay_edit as OE
    n = 0
    try:
        rows = conn.execute(
            "SELECT user_text_id, clicked_id, lang_code, contents FROM user_text_asset"
            " WHERE text_type=? AND COALESCE(record_status,'LIVE')<>'HIDE' AND TRIM(COALESCE(contents,''))<>''",
            (LEMMA_TEXT,)).fetchall()
    except Exception:                                     # noqa: BLE001
        return 0
    for uid, key, lg, text in rows:
        key = int(key or 0)
        if key >= 2000000:
            strong = 'G%d' % (key - 2000000)
        elif key >= 1000000:
            strong = 'H%d' % (key - 1000000)
        else:
            continue
        r = conn.execute("SELECT entity_id FROM sys_entity_lemma WHERE UPPER(strong)=?"
                         " AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY sort_order, lemma_id LIMIT 1",
                         (strong,)).fetchone()
        if not r:
            continue
        _v, st, _t = OE.target_state(conn, 'ENTITY_DESC', int(r[0]), lg, '')
        if st in ('EDIT', 'NEW'):
            continue
        OE.save_mine(conn, 'ENTITY_DESC', int(r[0]), lg, None, text)
        conn.execute("UPDATE user_text_asset SET record_status='HIDE' WHERE user_text_id=?", (uid,))
        conn.commit()
        n += 1
    return n


def term_desc_current(conn, entity_id, lang='KO'):
    import overlay_edit as OE
    _v, st, txt = OE.target_state(conn, 'ENTITY_DESC', int(entity_id), lang, '')
    return (txt or '') if st in ('SYS', 'EDIT', 'NEW') else ''


def term_desc_save(conn, entity_id, lang, text):
    """용어 설명문을 내 버전(덮개)으로 담는다 → True."""
    import overlay_edit as OE
    t = (text or '').strip()
    if not t:
        return False
    _v, _st, _txt = OE.target_state(conn, 'ENTITY_DESC', int(entity_id), lang, '')
    OE.save_mine(conn, 'ENTITY_DESC', int(entity_id), lang, _v or '', t)
    conn.commit()
    return True


def ref_link_count(conn, ref_id):
    """그 내 자료에 걸린 구절 수 — 저장 뒤 진행 줄이 말한다."""
    try:
        import db_user_ref_schema as U
        return len([l for l in U.fetch_links(conn, int(ref_id)) if l[0] == 'VERSE'])
    except Exception:                                     # noqa: BLE001
        return 0


# ══════════════════════════════════════════════════════════════════════
#  폰 AI 꾸러미 — PC 가 업무마다 보낼 글을 **지어서** 폰에 싣는다(317차-30 ④)
# ══════════════════════════════════════════════════════════════════════
#: 물음이 들어갈 자리 — 폰이 사용자의 물음으로 바꾼다(글자가 겹칠 일이 없는 표식)
PHONE_Q = chr(0x2063) + 'Q' + chr(0x2063)
#: 폰에 없는 업무 — 묵상노트 분석은 노트 묶기가 PC 몫이다(폰은 노트를 초안으로만 갖는다)
# ★ 2026-10-14 설명문 업무(일반·전문)는 폰 구절 [AI] 에서 빼고 설명 판 [AI 분석] 으로만(사용자 「서브메뉴 AI 에는 설명문 관련 업무가 없어야」)
PHONE_SKIP = ('NOTE', 'LINKAN', 'DESC', 'XDESC') + ROLE_TASKS   # 구절 업무 목록에서 뺀다 — 폰은 설명 판 [AI 분석](analyze['DESC'·'ROLE'] · 2026-10-26)에서 쓴다
PHONE_ASK_MODES = ('ASK',)      # 물음 칸이 있는 연구하자 갈래(PC 화면과 같다)


def _picks_of(conn, unit):
    """그 단위에 PC 가 마지막으로 체크해 둔 Pick 본문 — 선택한 차례(`AI_LAST_<단위>`)."""
    try:
        d = json.loads(get_setting(conn, 'AI_LAST_' + unit, '') or '{}')
    except ValueError:
        d = {}
    out = []
    for pid in d.get('checked') or []:
        lid = _lib_id(pid)
        if lid is not None:
            r = conn.execute("SELECT body FROM user_ai_lib WHERE lib_id=? AND record_status='LIVE'", (lid,)).fetchone()
        else:
            r = conn.execute("SELECT body FROM user_ai_prompt WHERE prompt_id=? AND"
                             " COALESCE(record_status,'LIVE')='LIVE'", (pid,)).fetchone()
        if r and (r[0] or '').strip():
            out.append(r[0])
    return out


def _phone_lib(conn, L):
    """폰에 싣는 라이브러리 — 자리 · 항목(번호 = 음수 lib_id · Pick 꾸러미와 같은 번호) · 자리마다 쓰는 항목."""
    lib = _lib(conn)
    if lib is None:
        return None
    items = {}
    for k, title, body, it, _lg in lib.items(conn, L):
        r = lib._pick_lang(conn, k, L)
        items[k] = {'id': -int(r[0]), 'itype': it, 'title': title or '', 'body': body or ''}
    use, own = {}, {}
    for pl, k, on in conn.execute("SELECT place, item_key, on_flag FROM user_ai_lib_place ORDER BY place, sort_order, rowid"):
        if k in items:
            own.setdefault(pl, []).append(k)             # ★ 2026-10-28 1:1 — 그 자리의 항목 전부(표시를 끈 것까지)
            if on:
                use.setdefault(pl, []).append(k)
    # ★ 2026-10-28 자리 이름 — PC 라이브러리·AI 도우미와 같은 이름(`task_title` · 그 언어) · 그 밖은 라이브러리 이름
    places = []
    for k, g, nm in lib.all_places(conn, L):   # ★ 2026-10-28 사람이 더한 카드 갈래까지
        sc, _, t = k.partition(':')
        if sc in ('VERSE', 'TERM', 'REF', 'ERA') and t and t != 'FREE':
            try:
                nm = task_title(conn, sc, t, L) or nm
            except Exception:                             # noqa: BLE001
                pass
        elif k == 'VERSE:FREE':
            nm = _ui_label(conn, 'M_AI_FREE', L) or nm
        places.append([k, g, nm])
    try:
        seeds = lib.seed_rows(conn, L)                    # ★ 2026-10-31 초기값 전체(폰 초기값 복구)
    except Exception:                                     # noqa: BLE001
        seeds = []
    return {'places': places, 'items': items, 'use': use, 'own': own, 'seeds': seeds,
            'free_name': _ui_label(conn, 'M_AI_FREE', L) or ''}


def _phone_slots(conn, L, role, task, q, fmt=None):
    """칸 목록 `[[칸, 머리말, 글]]` — Pick·묻는 사람 칸은 비운다(폰이 선택한 것으로 채운다)."""
    return [[a, b, c] for a, b, c in
            compose_parts(conn, None, q, L, role=role, task=task, picks=[], with_axes=False, fmt=fmt, keep_version=True)]


def phone_compose(slots, picks=(), asker=(), lang='KO'):
    """폰이 하는 조립 그대로(시험 벡터용) — `compose` 와 같은 규칙: Pick 은 둘 이상이면 번호 ·
    묻는 사람은 줄바꿈으로 잇는다 · 빈 칸은 머리말째 뺀다."""
    pick_txt = each_block(list(picks), lang)
    ask = NL.join(x.strip() for x in asker if (x or '').strip())
    out = []
    for slot, head, val in slots:
        v = pick_txt if slot == 'PICK' else (ask if slot == 'ASKER' else val)
        if v:
            out.append('[%s]%s%s' % (head, NL, v))
    return (NL + NL).join(out)


def _ui_task_name(conn, scope, task, lang):
    """업무 단추 이름(화면 글자 `AI_T2_*`) — 꾸러미에 실어 보낸다(폰 팩이 아직 그 글자를 몰라도 이름이 보이게 · 2026-10-14).
    연구하자는 갈래마다 이름이 달라 폰이 정한다(빈 글)."""
    t = (task or '').upper()
    if t == 'RESEARCH' or t.startswith('UT_'):
        return ''
    keys = (['AI_T2_%s_%s' % (t, 'T' if scope == 'TERM' else 'V')] if t in ('DESC', 'ASK', 'STUDY') else []) + ['AI_T2_' + t]
    for k in keys:
        for lg in ((lang or 'KO').upper(), 'EN', 'KO'):
            try:
                r = conn.execute("SELECT string_value FROM ui_strings WHERE string_id=? AND lang_code=?", (k, lg)).fetchone()
            except Exception:                             # noqa: BLE001
                r = None
            if r and (r[0] or '').strip():
                return r[0].strip()
    return ''


def _ui_label(conn, key, lang):
    """화면 글자 하나(그 언어 → EN → KO) — 없으면 ''."""
    for lg in ((lang or 'KO').upper(), 'EN', 'KO'):
        try:
            r = conn.execute("SELECT string_value FROM ui_strings WHERE string_id=? AND lang_code=?", (key, lg)).fetchone()
        except Exception:                                 # noqa: BLE001
            r = None
        if r and (r[0] or '').strip():
            return r[0].strip()
    return ''


def phone_bundle(conn, lang='KO'):
    """폰이 보낼 글 — `{lang, ph, tasks:[…], free, guard, integ, opener}`.

    ★★★ 조립은 PC 가 한다 — `compose` 그대로(보이는 것 = 보내는 것 · 두 벌을 두지 않는다).
      폰은 ① 물음 표식(`PHONE_Q`)을 사용자의 물음으로 ② 자리표(`ph`)를 구절 이름으로 바꿀 뿐이다.
    · 업무마다 `prompt`(물음 없음) · `prompt_q`(물음 칸 있음 · 표식 포함) — 물음 칸이 비면 머리말째 빠지는
      `compose` 규칙을 폰이 흉내 내지 않게 둘 다 싣는다.
    · Pick = PC 에서 그 업무에 마지막으로 체크해 둔 것(`AI_LAST_*`)이 처음 값 — 폰 화면에서 바꿔 고른다.
    · 성경교사(`teach`)는 PC 처럼 지시문을 **시스템 글**로 보내고 AI 가 먼저 묻는다(`opener`).
    ⚠ 키는 여기 없다 — 「AI 키도 폰에 보낸다」를 켰을 때만 config 의 `AI_ACCOUNTS` 로 간다.
    """
    L = (lang or 'KO').upper()

    def both(role, task, picks, scope, fmt=None):
        a = compose(conn, None, '', L, role=role, task=task, picks=picks, fmt=fmt, keep_version=True)
        b = compose(conn, None, PHONE_Q, L, role=role, task=task, picks=picks, fmt=fmt, keep_version=True)
        if scope == 'FREE':
            a, b = fill_prompt(conn, a, 'FREE', lang=L), fill_prompt(conn, b, 'FREE', lang=L)
        return a, b

    try:
        ensure_format_presets(conn, L)          # 「대화식」 견본이 아직 없는 PC 에서도 질문 업무가 그것을 싣게
    except Exception:                           # noqa: BLE001
        pass
    fsets = part_sets(conn, 'FORMAT')

    def one(scope, t, m, plist):
        role, task = task_texts(conn, scope, t, m, L)
        if not (task or '').strip():
            return None
        unit = '%s_%s' % (scope, t) + ('_' + m if m else '')
        fi = task_fmt_index(conn, t, L)          # ★ 2026-10-16 업무별 출력서식(질문 = 대화식)
        fmt = (fsets['items'][fi].get('body') or '').strip() if fi is not None else None
        pr, prq = both(role, task, _picks_of(conn, unit), scope, fmt)
        try:
            picked = [x for x in json.loads(get_setting(conn, 'AI_LAST_' + unit, '') or '{}')
                      .get('checked') or [] if any(pp['id'] == x for pp in plist)]
        except ValueError:
            picked = []
        return {'id': unit, 'task': t, 'mode': m or '', 'scope': scope,
                # 사람이 고친 이름·내 업무 이름만 — 비면 폰이 화면 글자(AI_T2_* · AI_RM2_*)로
                'label': task_title(conn, scope, t, L),
                'ask': bool(m in PHONE_ASK_MODES), 'teach': t == 'TEACH',
                'prompt': pr, 'prompt_q': prq,
                # ★ 칸별(폰이 Pick·묻는 사람을 골라 잇는다 · 54번 「User, Pick 항목 선택하는 버튼」)
                'slots': _phone_slots(conn, L, role, task, '', fmt),
                'slots_q': _phone_slots(conn, L, role, task, PHONE_Q, fmt),
                # 그 업무의 출력서식 벌 번호(폰 서식 칩의 처음 값 · 없으면 폰의 직전값)
                'fmt': fi if fi is not None else -1,
                'picks': plist, 'picked': picked,
                # ★ 그 갈래의 자리표 — 용어·연구자료 업무는 [구절] 이 아니라 [용어]·[연구자료] 를 쓴다
                'ph': list(_PH_TERM if scope == 'TERM' else _PH_REF if scope == 'REF' else _PH_VERSE)}

    def scope_tasks(scope, only=None, skip=()):
        out = []
        for t in tasks_for(scope, conn):
            if t in skip or (only and t not in only):
                continue
            modes = RESEARCH_MODES if t == 'RESEARCH' else [None]
            try:
                plist = [{'id': r[0], 'title': r[2] or '', 'body': r[3] or ''}
                         for r in pick_prompts(conn, L, scope, t) if (r[3] or '').strip()]
                _lb = _lib(conn)
                if _lb is not None:                       # ★ 폰이 라이브러리 고친 것을 겹쳐 볼 수 있게 열쇠를 함께
                    for x in plist:
                        rr = _lb.row_of(conn, -x['id']) if x['id'] < 0 else None
                        if rr:
                            x['key'] = rr[0]
            except Exception:                                 # noqa: BLE001
                plist = []
            for m in modes:
                d = one(scope, t, m, plist)
                if d:
                    out.append(d)
        return out

    tasks = scope_tasks('VERSE', skip=PHONE_SKIP)
    # ★ 2026-10-11 (docs/1.txt 6-4) — 폰의 [AI 분석]: 묵상노트 한 편 · 연구/설교노트 한 편 · 용어 하나.
    #   구절 업무 목록(tasks)과 **따로** 싣는다 — 구절 화면 업무 칩에 섞이면 안 된다.
    #   ⚠ 폰의 묵상노트 분석은 **고른 노트 한 편**이다(PC 처럼 여러 구절 노트를 묶지 않는다).
    analyze = {'NOTE': scope_tasks('VERSE', only=('NOTE',)),
               # ★ 2026-10-16 도서 묵상은 내서재 도서 편에서만(사용자 「구절-연구자료-AI 에 도서묵상 프롬프트가 나온다」)
               'REF': scope_tasks('REF', skip=BOOK_TASKS),
               'TERM': scope_tasks('TERM'),
               # ★ 2026-10-14 연결구절 한 줄의 [AI 분석] — 연결 살펴보기
               'LINK': scope_tasks('VERSE', only=LINK_TASKS),
               # ★ 2026-10-14 설명 판 [AI 분석] — 일반설명문 · 전문설명문
               'DESC': scope_tasks('VERSE', only=('DESC', 'XDESC')),
               # ★ 2026-10-23 docs/2.txt 1 — 연대표 카드 [연대 조사]
               'ERA': scope_tasks('ERA'),
               # ★ 2026-10-26 분야별 도움말 [AI 분석] — [일반] 평신도 분야 · [전문] 사역자 분야(PC 와 같은 업무 · 화면이 분야 하나만 고른다)
               'ROLE': scope_tasks('VERSE', only=ROLE_TASKS)}
    # ★ 2026-10-28 docs/1.txt 6-1 — 라이브러리에서 더한 내 홈 질문프롬프트(UT_ · 갈래 HOME) → 폰 홈 AI 대화(Free 갈래)
    _home = []
    for _u in user_tasks(conn):
        if 'HOME' in _u.get('scopes', []):
            try:
                _pl = [{'id': r[0], 'title': r[2] or '', 'body': r[3] or ''}
                       for r in pick_prompts(conn, L, 'FREE', _u['key']) if (r[3] or '').strip()]
            except Exception:                                 # noqa: BLE001
                _pl = []
            _d = one('FREE', _u['key'], None, _pl)
            if _d:
                _d['scope'] = 'HOME'
                _home.append(_d)
    analyze['HOME'] = _home
    try:
        import role_tips as _RT
        _rlb = {}
        for _tier in ('LAY', 'EXPERT'):
            for _r in _RT.roles(_tier):
                _rlb[_r[0]] = [_r[0], _tier, _ui_label(conn, _r[1], L) or (_r[2] if L == 'KO' else _r[3]),
                               ROLE_TASK_OF.get(_r[0], '')]
        roles = list(_rlb.values())
    except Exception:                                     # noqa: BLE001
        roles = []
    frole, _ft = task_texts(conn, 'FREE', None, None, L)
    fa, fb = both(frole, '', _picks_of(conn, 'FREE'), 'FREE')
    axes = {}
    for ax in ('STATE', 'FAITH', 'VIEW'):
        axes[ax] = {'cur': get_axis(conn, ax),
                    'items': [[k, t, b] for k, t, b in axis_rows(conn, ax, L)]}
    axes['STATE']['field'] = (get_setting(conn, 'AI_LAY_FIELD', '') or '').upper()   # ★ 2026-10-28 평신도 분야(4-2)
    try:
        import db_ai_guard as GUARD
        guard = GUARD.text(conn, L)
    except Exception:                                     # noqa: BLE001
        guard = ''
    opener = {'KO': '시작해 주세요.', 'JA': '始めてください。', 'ZH': '请开始。', 'ZHT': '請開始。',
              'DE': 'Bitte beginnen.', 'FR': 'Commençons.', 'ES': 'Empecemos.', 'PT': 'Vamos começar.',
              'RU': 'Начнём.', 'AR': 'لنبدأ.'}.get(L, 'Please begin.')
    return {'lang': L, 'q': PHONE_Q, 'ph': list(_PH_VERSE), 'tasks': tasks, 'analyze': analyze, 'roles': roles,
            'free': {'prompt': fa, 'prompt_q': fb,
                     'slots': [[a, b, fill_prompt(conn, c, 'FREE', lang=L)] for a, b, c in _phone_slots(conn, L, frole, '', '')],
                     'slots_q': [[a, b, fill_prompt(conn, c, 'FREE', lang=L)] for a, b, c in _phone_slots(conn, L, frole, '', PHONE_Q)],
                     'picks': [], 'picked': []},
            'axes': axes, 'axis_order': ['STATE', 'FAITH', 'VIEW'], 'guard': guard,
            # ★ 2026-10-15 표는 탭으로(PC system_text 와 같은 공통 줄 · 필수 지침 바로 다음) — 폰에 빠져 있었다
            'table_rule': table_rule(L),
            'integ': integ_prompt(conn, L), 'opener': opener,
            # ★ 폰 [이 대화를 한 글로] — PC [이 채팅을 한 글로]와 같은 글(두 벌을 두지 않는다 · 2026-10-10)
            'merge': merge_prompt_body(conn, L),
            # ★ 2026-10-20 프롬프트 라이브러리(docs/1.txt B3) — 폰 「설정 ▸ 프롬프트 라이브러리」가 이것을 보이고 고친다
            'lib': _phone_lib(conn, L),
            # ★ 2026-10-14 설명문 칸 이름 — 폰이 답을 칸으로 나눠 「구절 설명문으로」 담는다(그 언어 · 한국어 · 영어 모두 읽는다)
            'marks': {k: sorted({(DESC_MARKS.get(L) or DESC_MARKS['EN'])[i], DESC_MARKS['KO'][i], DESC_MARKS['EN'][i]})
                      for i, k in enumerate(('DESC', 'QUES', 'PRAYER', 'STUDY', 'XDESC'))}
            | {'LDESC': sorted({LINK_MARKS.get(L, LINK_MARKS['EN']), LINK_MARKS['KO'], LINK_MARKS['EN']})},
            # ★ 2026-10-14 연결 갈래 뜻 — 폰 연결구절 [AI 분석] 재료(폰 사본에는 갈래 이름 표가 없다)
            'rel_codes': _rel_codes(),
            # ★ 2026-10-15 출력서식 견본 — 폰은 이름으로 선택한다(사용자 「특히 모바일에서는 이런 방식」)
            'formats': _phone_formats(conn),
            # ★ 2026-10-15 77 — 기도 노트 AI 프롬프트(PC 에서 고친 것이 폰으로 · 폰에서 고친 것은 사건 AI_PROMPT 로 PC 에)
            'prayer': prayer_bundle(conn, L),
            'integ_acct': (get_setting(conn, 'AI_INTEG_ACCT', '') or '').strip(),
            # ★ 2026-10-16 이어서 묻기 — 방향 바꾸기·더 깊이(그 언어) · 제안 질문 규칙(폰도 같은 글)
            'follow': {g: [[k, t, b] for k, t, b in v] for g, v in follow_items(L).items()},
            'next_rule': next_rule(L),
            'pick_each': pick_each(L)}


def _phone_formats(conn):
    """출력서식 벌 — `{'cur': 지금 쓰는 번호, 'items': [[이름, 글], …]}`(이름 없는 벌은 「서식 N」)."""
    try:
        d = part_sets(conn, 'FORMAT')
    except Exception:                                     # noqa: BLE001
        return {'cur': 0, 'items': []}
    items = [[(it.get('name') or '').strip() or ('#%d' % (i + 1)), it.get('body') or '']
             for i, it in enumerate(d['items'])]
    # ★ 2026-10-20 두 갈래 — 복수 선택 서식 번호 · 켠 것(폰이 하나 선택한 꼴 뒤에 붙인다)
    return {'cur': d['on'], 'items': items,
            'multi': [i for i, it in enumerate(d['items']) if it.get('multi')],
            'checked': [i for i in (d.get('checked') or []) if 0 <= i < len(d['items']) and d['items'][i].get('multi')]}


def phone_fill(bundle, item, question='', ref_label=''):
    """폰이 하는 일 그대로(시험 벡터용) — 물음을 넣고 자리표를 구절 이름으로."""
    q = (question or '').strip()
    txt = (item['prompt_q'].replace(bundle['q'], q)) if q else item['prompt']
    if ref_label:
        for tok in bundle['ph']:
            txt = txt.replace(tok, ref_label)
    return txt


def selftest():
    bad, n = [], [0]

    def ck(c, m, got=''):
        n[0] += 1
        if not c:
            bad.append('%s%s' % (m, ('  | ' + str(got)[:140]) if got != '' else ''))
    conn = appdb.connect()
    sys_before = [conn.execute("SELECT COUNT(*) FROM %s" % t).fetchone()[0]
                  for t in ('sys_text_asset', 'sys_link_asset', 'sys_entity_verse', 'user_config')]
    init(conn)
    ck(all(conn.execute("SELECT 1 FROM userdb.sqlite_master WHERE name=?", (t,)).fetchone()
           for t in ('user_ai_chat', 'user_ai_msg', 'user_ai_prompt')), '표 셋이 개인 DB(userdb)에 생긴다')
    ck(not any(conn.execute("SELECT 1 FROM main.sqlite_master WHERE name=?", (t,)).fetchone()
               for t in ('user_ai_chat', 'user_ai_msg', 'user_ai_prompt')), '배포 DB 에는 그 표가 없다')
    # 어댑터 꼴
    for p in ('GEMINI', 'OPENAI', 'XAI', 'ANTHROPIC'):
        url, body, hd = _payload(p, PROVIDER[p]['model'], 'S', [('user', 'a'), ('ai', 'b'), ('user', 'c')], 100)
        ck(url.startswith('https://') and any('{KEY}' in v for v in hd.values()), '%s 요청 꼴' % p)
    ck(_payload('GEMINI', 'm', 'S', [('user', 'a')], 10)[1]['contents'][0]['role'] == 'user'
       and _payload('GEMINI', 'm', 'S', [('ai', 'a')], 10)[1]['contents'][0]['role'] == 'model', 'Gemini 역할 이름')
    ck(_payload('OPENAI', 'm', 'S', [('ai', 'a')], 10)[1]['messages'][1]['role'] == 'assistant', 'OpenAI 역할 이름')
    # ── 299차-3 모델 다양화 ─────────────────────────────────────────
    ck(all(PROVIDER[p]['models'] and PROVIDER[p]['models'][0] == PROVIDER[p]['model'] for p in PROVIDER),
       '회사마다 후보 모델 목록이 있고 첫째가 기본 모델')
    ck(set(MODELS_URL) == set(PROVIDER), '모델 목록 주소가 회사 넷 전부에 있다')
    ck(PROVIDER['GEMINI']['model'].endswith('-latest'), 'Gemini 기본은 판 번호가 아니라 별칭(물려도 404 가 안 난다)')
    ck(model_alias('GEMINI', 'gemini-2.5-flash') == 'gemini-flash-latest'
       and model_alias('GEMINI', 'gemini-2.5-flash-lite') == 'gemini-flash-lite-latest'
       and model_alias('GEMINI', 'gemini-3.8-flash') == 'gemini-3.8-flash'
       and model_alias('OPENAI', 'gemini-2.5-flash') == 'gemini-2.5-flash', '물린 Gemini 이름은 읽을 때 별칭으로 · 남은 것은 그대로')
    ck(not any(m in MODEL_ALIAS for m in PROVIDER['GEMINI']['models']), '후보 목록에 물린 이름이 없다')
    ck(set(providers()) == set(PROVIDER) and providers()['GEMINI']['models'] == PROVIDER['GEMINI']['models'],
       'providers() — conn 없으면 코드 씨앗 그대로')
    ck(providers()['GEMINI']['alias'].get('gemini-2.5-flash') == 'gemini-flash-latest',
       'providers() 가 별칭도 함께 낸다')
    # ── 314차 — 연구자료 저장 때 **구절 자동 연결** ──────────────────
    #   ★ 사용자 지시 「저장하면 구절 연결이 자동으로 이루어져야 한다」.
    #   ⚠ 실 DB 에 시험 번호(-9997)로 넣고 끝에 **그 자리에서 치운다**.
    try:
        import db_user_ref_schema as _U
        import scripture_ref as _SR
        _RID = -9997
        import db_user_ref_schema as _U4x
        _U.init(conn)
        conn.execute("DELETE FROM userdb.user_link_asset WHERE clicked_id=?",
                     (_RID,))
        conn.commit()
        _n = link_verses(conn, _RID, '신 15:4 와 마 7:7 을 함께 봅니다.', 'KO')
        ck(_n == (2, 0), '저장 때 구절 둘이 자동 연결된다', _n)
        ck(link_verses(conn, _RID, '신 15:4 와 마 7:7 을 함께 봅니다.', 'KO')
           == (0, 0), '두 번 저장해도 연결이 늘지 않는다(멱등)')
        #   ★★★ **약명을 지우면 그 연결도 사라진다**(315차 사용자 지시)
        ck(link_verses(conn, _RID, '신 15:4 만 봅니다.', 'KO') == (0, 1),
           '★★★ 글에서 약명을 지웠는데 연결이 남는다')
        _lk = [l for l in _U4x.fetch_links(conn, _RID) if l[0] == 'VERSE'] \
            if True else []
        ck(len(_lk) == 1, '남은 연결이 하나여야 한다', len(_lk))
        #   ★ 되살리면 다시 걸린다(지운 것을 영구히 막지 않는다)
        ck(link_verses(conn, _RID, '신 15:4 와 마 7:7.', 'KO')[0] == 1,
           '약명을 다시 적으면 연결이 돌아온다')
        #   ⚠⚠ **사람이 손으로 이은 것은 안 건드린다**
        conn.execute(
            "INSERT INTO userdb.user_link_asset(link_type, clicked_id,"
            " target_id, record_status) VALUES('UREF_VERS',?,1,'LIVE')",
            (_RID,))
        conn.commit()
        link_verses(conn, _RID, '신 15:4 만 봅니다.', 'KO')
        ck(conn.execute(
            "SELECT COALESCE(record_status,'LIVE') FROM userdb.user_link_asset"
            " WHERE link_type='UREF_VERS' AND clicked_id=? AND target_id=1",
            (_RID,)).fetchone()[0] == 'LIVE',
           '★★ 사람이 손으로 이은 연결을 동기화가 지웠다')
        #   ★ 다국어 — 영어 글은 영어 약명으로 읽는다
        conn.execute("DELETE FROM userdb.user_link_asset WHERE clicked_id=?",
                     (_RID,))
        conn.commit()
        _n2 = link_verses(conn, _RID, 'See Deut 15:4 and Matt 7:7.', 'EN')
        ck(_n2 == (2, 0), '영어 글에서 영어 약명으로 읽는다', _n2)
        #   ⚠ 언어를 틀리게 주면 **조용히 0건**이 아니라 그 언어로 못 읽는다
        conn.execute("DELETE FROM userdb.user_link_asset WHERE clicked_id=?",
                     (_RID,))
        conn.commit()
        ck(link_verses(conn, _RID, '본문이 비었습니다', 'KO') == (0, 0),
           '약명이 없으면 0건')
        ck(_SR.find(conn, '신 15:4', 'KO'), '읽는 문이 단일 소스로 돈다')
    finally:
        try:
            conn.execute("DELETE FROM userdb.user_link_asset WHERE clicked_id=?",
                         (-9997,))
            conn.commit()
        except Exception:                                 # noqa: BLE001
            pass
    ck(providers(conn)['GEMINI']['name'] == PROVIDER['GEMINI']['name'], '실 DB 로 불러도 회사 이름은 코드')
    _gm2 = json.dumps({'models': [{'name': 'models/gemini-3.8-flash-tts', 'supportedGenerationMethods': ['generateContent']},
                                  {'name': 'models/gemini-3-pro-image', 'supportedGenerationMethods': ['generateContent']},
                                  {'name': 'models/gemini-flash-lite-latest', 'supportedGenerationMethods': ['generateContent']}]})
    ck(list_models('GEMINI', 'k', _get_fn=lambda u, h, t: (200, _gm2))['models'] == ['gemini-flash-lite-latest'],
       'Gemini 목록 — 음성·그림 모델을 뺀다')
    _gm = json.dumps({'models': [{'name': 'models/gemini-2.5-flash-lite', 'supportedGenerationMethods': ['generateContent']},
                                 {'name': 'models/embedding-001', 'supportedGenerationMethods': ['embedContent']},
                                 {'name': 'models/gemini-2.5-flash', 'supportedGenerationMethods': ['generateContent']}]})
    r = list_models('GEMINI', 'k', _get_fn=lambda u, h, t: (200, _gm))
    ck(r['ok'] and r['models'] == ['gemini-2.5-flash', 'gemini-2.5-flash-lite'],
       'Gemini 목록 — models/ 접두를 걷고 글 모델만 · 이름순: %s' % r['models'])
    _om = json.dumps({'data': [{'id': 'gpt-4o-mini'}, {'id': 'whisper-1'}, {'id': 'gpt-4o-audio-preview'},
                               {'id': 'text-embedding-3-small'}, {'id': 'o3-mini'}, {'id': 'gpt-4.1'}]})
    r = list_models('OPENAI', 'k', _get_fn=lambda u, h, t: (200, _om))
    ck(r['ok'] and r['models'] == ['gpt-4.1', 'gpt-4o-mini', 'o3-mini'], 'OpenAI 목록 — 음성·임베딩을 뺀다: %s' % r['models'])
    r = list_models('XAI', 'k', _get_fn=lambda u, h, t: (200, json.dumps({'data': [{'id': 'grok-3'}, {'id': 'grok-2-image'}]})))
    ck(r['ok'] and r['models'] == ['grok-2-image', 'grok-3'], 'xAI 목록 — grok 으로 시작하는 것')
    r = list_models('ANTHROPIC', 'k', _get_fn=lambda u, h, t: (200, json.dumps({'data': [{'id': 'claude-sonnet-5'}]})))
    ck(r['ok'] and r['models'] == ['claude-sonnet-5'], 'Anthropic 목록')
    ck(not list_models('GEMINI', '', _get_fn=lambda u, h, t: (200, _gm))['ok'], '키가 없으면 안 묻는다')
    _hs = [None]
    def _capture(u, h, t):
        _hs[0] = (u, h); return 200, _gm
    list_models('GEMINI', 'SECRET', _get_fn=_capture)
    ck(_hs[0] and _hs[0][1].get('x-goog-api-key') == 'SECRET' and 'models' in _hs[0][0], '키가 머리글에 실려 나간다')
    r = list_models('GEMINI', 'k', _get_fn=lambda u, h, t: (200, json.dumps({'error': {'status': 'PERMISSION_DENIED', 'message': 'bad key'}})))
    ck(not r['ok'] and 'bad key' in r['why'], '서버 오류 글을 그대로 낸다')
    def _404(u, b, h, t):
        raise urllib.error.HTTPError(u, 404, 'nf', {}, io.BytesIO(
            json.dumps({'error': {'status': 'NOT_FOUND', 'message': 'models/x is not found'}}).encode('utf-8')))
    r = call('GEMINI', 'k', 'x', [('user', 'a')], _post_fn=_404)
    ck(True, '(아래 되묻기 검사는 실제로 안 쉰다 — `_sleep` 을 갈아 끼운다)')
    ck(not r['ok'] and 'HTTP 404' in r['why'] and '[모델 불러오기]' in r['why'] and 'is not found' in r['why'],
       '★ 404 면 [모델 불러오기]로 가라고 알린다: %s' % r['why'][:80])
    _n = [0]
    def _503(u, b, h, t):
        _n[0] += 1
        raise urllib.error.HTTPError(u, 503, 'busy', {}, io.BytesIO(
            json.dumps({'error': {'status': 'UNAVAILABLE', 'message': 'high demand'}}).encode('utf-8')))
    _naps = []
    r = call('GEMINI', 'k', 'm', [('user', 'a')], _post_fn=_503, _sleep=_naps.append)
    ck(not r['ok'] and _n[0] == 3 and _naps == list(RETRY_WAIT),
       '★ 503(일시 과부하)은 두 번 더 묻고 그 사이 쉰다', (_n[0], _naps))
    _n2 = [0]
    def _503_then_ok(u, b, h, t):
        _n2[0] += 1
        if _n2[0] == 1:
            raise urllib.error.HTTPError(u, 503, 'busy', {}, io.BytesIO(b'{}'))
        return 200, json.dumps({'candidates': [{'content': {'parts': [{'text': 'hi'}]}}], 'usageMetadata': {}})
    r = call('GEMINI', 'k', 'm', [('user', 'a')], _post_fn=_503_then_ok, _sleep=lambda _s: None)
    ck(r['ok'] and r['text'] == 'hi' and _n2[0] == 2, '★ 되물어 성공하면 그 답을 낸다', (r, _n2[0]))
    _n3 = [0]
    def _401(u, b, h, t):
        _n3[0] += 1
        raise urllib.error.HTTPError(u, 401, 'bad', {}, io.BytesIO(b'{}'))
    r = call('GEMINI', 'k', 'm', [('user', 'a')], _post_fn=_401, _sleep=lambda _s: None)
    ck(not r['ok'] and _n3[0] == 1, '★ 401(키 문제)은 안 되묻는다 — 한도만 더 먹는다', _n3[0])
    _n4 = [0]
    def _503_code(u, b, h, t):
        _n4[0] += 1
        return 503, json.dumps({'error': {'message': 'busy'}})
    r = call('GEMINI', 'k', 'm', [('user', 'a')], _post_fn=_503_code, _sleep=lambda _s: None)
    ck(not r['ok'] and _n4[0] == 3 and 'HTTP 503' in r['why'], '예외가 아니라 코드로 와도 되묻는다', (_n4[0], r['why'][:40]))
    ck(_parse('GEMINI', json.dumps({'candidates': [{'content': {'parts': [{'text': 'hi'}]}}],
                                    'usageMetadata': {'promptTokenCount': 3, 'candidatesTokenCount': 1}}))[0] == 'hi',
       'Gemini 응답을 읽는다')
    ck(_parse('OPENAI', json.dumps({'choices': [{'message': {'content': 'yo'}}], 'usage': {}}))[0] == 'yo',
       'OpenAI 응답을 읽는다')
    ck(_parse('ANTHROPIC', json.dumps({'content': [{'type': 'text', 'text': 'z'}], 'usage': {}}))[0] == 'z',
       'Anthropic 응답을 읽는다')
    ck(_parse('OPENAI', json.dumps({'error': {'message': 'bad key', 'type': 'auth'}}))[2].startswith('auth'),
       '오류 응답은 까닭으로')
    ck(not call('GEMINI', '', 'm', [('user', 'a')])['ok'], '키가 없으면 안 보낸다')
    ck(not call('NOPE', 'k', 'm', [('user', 'a')])['ok'], '모르는 회사는 거부')
    fake = lambda url, body, hd, to: (200, json.dumps({'candidates': [{'content': {'parts': [{'text': '가짜 답'}]}}]}))
    r = call('GEMINI', 'k', 'm', [('user', 'q')], system='s', _post_fn=fake)
    ck(r['ok'] and r['text'] == '가짜 답', '가짜 전송으로 왕복')
    boom = lambda url, body, hd, to: (_ for _ in ()).throw(OSError('no net'))
    r = call('GEMINI', 'k', 'm', [('user', 'q')], _post_fn=boom)
    ck(not r['ok'] and '연결하지 못했습니다' in r['why'], '망이 없으면 까닭으로 돌아온다(터지지 않는다)')
    # 재료 — sys 읽기만
    vid = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=1 AND chapter=1 AND verse=1").fetchone()[0]
    m = materials(conn, vid, None, 'KO')
    ck(m.get('구절') == '창 1:1' and '본문 (KRV)' in m and '앞뒤 절 (개역한글)' in m, '재료: 구절·본문·앞뒤 절: %s' % list(m))
    pr = pericope_of(conn, vid)
    ck(pr and pr[0] <= vid <= pr[1], '이 절이 든 단락: %s' % (pr,))
    v5 = shift(conn, vid, 4)
    ck(range_label(conn, vid, v5, 'KO') == '창 1:1~5', '구간 표기 창 1:1~5: %s' % range_label(conn, vid, v5, 'KO'))
    m2 = materials(conn, vid, v5, 'KO')
    ck('앞뒤 절 (개역한글)' not in m2 and m2['본문 (KRV)'].count(NL) == 4, '구간이면 앞뒤 절 대신 본문 다섯 줄')
    ck(materials(conn, vid, None, 'EN')['구절'] == 'Gen 1:1', '언어를 따라 약명이 바뀐다')
    # 프롬프트 씨앗 — 11언어 × 7갈래 · 사람이 고친 것은 안 덮는다
    ensure_seeds(conn)
    ck(all(len(SEED_PROMPTS[k]) == 11 for k in KINDS), '씨앗이 갈래마다 11언어')
    ps = prompts(conn, 'JA')
    ck(len(ps) == len(KINDS) and any('[聖句]' in p[3] for p in ps), '일본어 프롬프트 예제 일곱')
    pid = ps[0][0]
    old = conn.execute("SELECT title, body FROM user_ai_prompt WHERE prompt_id=?", (pid,)).fetchone()
    save_prompt(conn, pid, old[0], old[1] + ' (내가 고침)')
    ensure_seeds(conn)
    ck(conn.execute("SELECT body FROM user_ai_prompt WHERE prompt_id=?", (pid,)).fetchone()[0].endswith('(내가 고침)'),
       '씨앗을 다시 채워도 사람이 고친 줄은 안 덮는다')
    save_prompt(conn, pid, old[0], old[1])
    # 대화 = 자산 하나 · 합치기 · 내 자료로
    cid = new_chat(conn, vid, v5, 'KO', kind='TEACH')
    try:
        ch = chat(conn, cid)
        ck(ch and ch['title'] == '창 1:1~5' and ch['end_vid'] == v5, '대화 닻 = 구간')
        ck(cid in [c[0] for c in chats_for(conn, vid, v5)] and cid not in [c[0] for c in chats_for(conn, vid, vid)],
           '닻이 같은 대화만 목록에')
        _raw_b = get_setting(conn, 'AI_ACCOUNTS', None)
        _had_b = conn.execute("SELECT 1 FROM user_config WHERE config_key='AI_ACCOUNTS'").fetchone() is not None
        set_accounts(conn, [{'provider': 'GEMINI', 'model': 'g', 'key': 'k', 'on': 1}])
        fake2 = lambda p, k, m_, msgs_, system='': {'ok': True, 'text': '첫 물음: 1절에서 누가 무엇을 합니까?', 'tokens': {}}
        r = send(conn, cid, '', prompt_body=SEED_PROMPTS['TEACH']['KO'][1], _call=fake2, teach_start=True)
        ck(r['ok'] and msgs(conn, cid)[0][1] == 'ai', '★ 성경교사 — AI 가 먼저 묻는다(사용자 말 없이)')
        seen = {}
        def fake3(p, k, m_, msgs_, system=''):
            seen['msgs'] = msgs_; seen['system'] = system
            return {'ok': True, 'text': '좋습니다. 다음 물음.', 'tokens': {'in': 5, 'out': 2}}
        r = send(conn, cid, '하나님이 창조하십니다', prompt_body=SEED_PROMPTS['TEACH']['KO'][1], _call=fake3)
        ck(r['ok'] and len(seen['msgs']) == 2 and seen['msgs'][0][0] == 'ai' and seen['msgs'][1] == ('user', '하나님이 창조하십니다'),
           '이어지는 대화가 앞 말을 다 실어 보낸다: %s' % seen['msgs'])
        # ★ 317차 — 시스템 글 맨 앞은 **필수 지침**이다(사용자가 못 고친다)
        import db_ai_guard as _GD
        _g = _GD.text(conn, 'KO')
        ck(seen['system'].startswith(_g), '★★★ 시스템 글 맨 앞 = 필수 지침')
        _head = seen['system'][len(_g):].lstrip()
        ck(_head.startswith(table_rule('KO')), '★ 84-1 필수 지침 다음 = 표는 탭으로(공통 줄)')
        _head = _head[len(table_rule('KO')):].lstrip()
        _head = _head[len(context_line(conn, 'KO')):].lstrip().split(NL + NL)[0]   # ★ 2026-10-22 오늘·나라 줄 다음부터
        ck('창 1:1~5' in _head and '[구절]' not in _head and '[본문 (KRV)]' in seen['system'],
           '시스템 글 = 필수 지침 + 프롬프트([구절] 채움) + 재료')
        ck([r_[1] for r_ in msgs(conn, cid)] == ['ai', 'user', 'ai'], '대화에 세 마디')
        bad_call = lambda p, k, m_, msgs_, system='': {'ok': False, 'text': '', 'why': 'HTTP 429', 'tokens': {}}
        r = send(conn, cid, '또 묻습니다', _call=bad_call)
        ck(not r['ok'] and [r_[1] for r_ in msgs(conn, cid)][-1] == 'user', '실패해도 사용자 말은 남고 답은 안 담긴다')
        # 내 묵상노트 재료 — 체크가 켜져 있을 때만
        conn.execute("INSERT INTO user_text_asset(clicked_id, text_type, contents, lang_code, record_status, created_at)"
                     " VALUES(?,?,?,?,'LIVE',?)", (vid, 'VERS_NOTE', '관련구절 창 1:1' + NL + '자가검증 묵상노트 본문입니다', 'KO', _now()))
        _nid = conn.execute("SELECT MAX(user_text_id) FROM user_text_asset").fetchone()[0]
        try:
            ck(any('자가검증 묵상노트 본문' in x for x in my_notes(conn, vid, v5)), '내 묵상노트를 찾는다(머리말은 걷는다)')
            _s1 = system_text(conn, chat(conn, cid), 'p', with_notes=False)
            _s2 = system_text(conn, chat(conn, cid), 'p', with_notes=True)
            ck('내 묵상노트' not in _s1 and '[내 묵상노트]' in _s2 and '자가검증 묵상노트 본문' in _s2,
               '★ 묵상노트는 체크가 켜져 있을 때만 재료에 실린다(양방향)')
        finally:
            conn.execute("DELETE FROM user_text_asset WHERE user_text_id=?", (_nid,))
        hide_chat(conn, cid)
        ck(cid not in [c_[0] for c_ in chats_for(conn, vid, v5)], '지운 대화(HIDE)는 목록에서 빠진다')
        conn.execute("UPDATE user_ai_chat SET record_status='LIVE' WHERE chat_id=?", (cid,))
        mt = merge_text(conn, cid, with_q=True)
        ck(mt.startswith('창 1:1~5') and '물음: 하나님이 창조하십니다' in mt and '답: 좋습니다' in mt, '한 편의 글로 합친다')
        # ★★★ ⑤ 기본은 **답만** — 사용자 말이 곧 조립된 프롬프트 전문이다(312차)
        _mt0 = merge_text(conn, cid)
        ck('하나님이 창조하십니다' not in _mt0 and '답: 좋습니다' in _mt0,
           '★★★ 연구자료로 담는 기본 글에는 **프롬프트가 없다**(답만 남는다)', _mt0[:80])
        ck(_mt0.startswith('창 1:1~5'),
           '★ 제목(닻 이름)은 남는다 — 무엇에 대한 글인지 잃지 않는다')
        n_ref0 = conn.execute("SELECT COUNT(*) FROM user_ref_asset").fetchone()[0]
        rid = save_as_ref(conn, cid)
        got = conn.execute("SELECT title, body_text FROM user_ref_text WHERE ref_id=?", (rid,)).fetchone()
        ck(rid and got and '답:' in got[1], '합친 글이 「내 자료」로 담긴다(개인 DB)')
        # ⚠ 「'물음:' 이 없다」로 재면 안 된다 — **AI 답 본문**에 「첫 물음: …」
        #   같은 글자가 있을 수 있다(실측으로 당했다 §238차). 머리말은 **줄 맨
        #   앞**에 붙으므로 그것으로 잰다.
        _qh = [x for x in (got[1] if got else '').splitlines() if x.startswith('물음:')]
        ck(rid and got and not _qh,
           '★★★ 담긴 글에 프롬프트가 없다 — `save_as_ref` 도 기본이 답만이다', _qh[:1])
        ck(conn.execute("SELECT ref_type, ref_origin FROM user_ref_asset WHERE ref_id=?", (rid,)).fetchone()
           == ('STUDY', 'AI'),
           '★ 담긴 글 = 유형 연구 · 출처 AI 작성 — 사람 글과 갈린다(2026-10-16 docs/1.txt 2-2)')
        ck(chats_for(conn, vid, v5)[0][6] == 'TEACH' and kind_labels(conn, 'KO').get('TEACH', '').startswith('성경교사'),
           '대화 목록에 갈래(성경교사)가 함께 나온다')
        conn.execute("DELETE FROM user_ref_text WHERE ref_id=?", (rid,))
        conn.execute("DELETE FROM user_ref_asset WHERE ref_id=?", (rid,))
        ck(conn.execute("SELECT COUNT(*) FROM user_ref_asset").fetchone()[0] == n_ref0, '내 자료 자국 0')
    finally:
        conn.execute("DELETE FROM user_ai_msg WHERE chat_id=?", (cid,))
        conn.execute("DELETE FROM user_ai_chat WHERE chat_id=?", (cid,))
        if _had_b:
            set_setting(conn, 'AI_ACCOUNTS', _raw_b or '')
        else:
            conn.execute("DELETE FROM user_config WHERE config_key='AI_ACCOUNTS'")
        conn.commit()
    # ★★★ 299차 — 계정 여럿(복수 체크) · 용어 닻 · 프롬프트 추가/이름/삭제 · 노트 범위
    raw0 = get_setting(conn, 'AI_ACCOUNTS', None)
    had_raw = conn.execute("SELECT 1 FROM user_config WHERE config_key='AI_ACCOUNTS'").fetchone() is not None
    cid2 = None
    _pid_new = None
    try:
        set_accounts(conn, [{'provider': 'GEMINI', 'model': 'g-a', 'key': 'k1', 'on': 1},
                            {'provider': 'OPENAI', 'model': 'o-b', 'key': 'k2', 'on': 1},
                            {'provider': 'XAI', 'model': 'x-c', 'key': 'k3', 'on': 0}])
        ck([a['model'] for a in enabled_accounts(conn)] == ['g-a', 'o-b'], '켠 계정만 보낸다(복수 체크)')
        ck(settings(conn)['model'] == 'g-a', '옛 한 벌 설정 문은 첫 켠 계정을 낸다')
        eid = conn.execute("SELECT entity_id FROM sys_entity_master WHERE entity_type='PERSON'"
                           " AND record_status='LIVE' ORDER BY importance DESC LIMIT 1").fetchone()[0]
        mt_ = materials_term(conn, eid, 'KO')
        ck('용어' in mt_ and '관련 단락 (첫 절 · 개역한글)' in mt_, '인물 재료: 이름·관련 단락(절 연결이 없으면 단락): %s' % list(mt_))
        _eid_t = conn.execute("SELECT entity_id FROM sys_entity_verse WHERE record_status='LIVE' AND is_key=1"
                              " GROUP BY 1 ORDER BY COUNT(*) DESC LIMIT 1").fetchone()[0]
        ck('대표 구절 (개역한글)' in materials_term(conn, _eid_t, 'KO'), '용어 재료: 대표 구절(절 연결이 있는 용어)')
        cid2 = new_chat(conn, entity_id=eid, lang='KO', kind='TERM_ASK')
        ch2 = chat(conn, cid2)
        ck(ch2['scope'] == 'TERM' and ch2['entity_id'] == eid and ch2['title'] == term_name(conn, eid, 'KO'),
           '용어 닻 대화(scope TERM)')
        ck(cid2 in [c_[0] for c_ in chats_for(conn, entity_id=eid)]
           and cid2 not in [c_[0] for c_ in chats_for(conn, vid, vid)], '용어 대화는 용어 목록에만')
        calls = []
        def fake_multi(p, k, m_, msgs_, system=''):
            calls.append((p, m_, [x for x in msgs_]))
            return {'ok': True, 'text': '%s 의 답' % m_, 'tokens': {}}
        r = send(conn, cid2, '뜻이 무엇입니까', prompt_body=SEED_TERM['TERM_ASK']['KO'][1], _call=fake_multi)
        ck(r['ok'] and len(r['results']) == 2 and {x[1] for x in calls} == {'g-a', 'o-b'},
           '★ 켠 계정 둘에 다 보내고 답을 둘 다 담는다: %s' % [x['model'] for x in r['results']])
        _sx = system_text(conn, ch2, '[용어] 뜻')
        import db_ai_guard as _GD
        _sx = _sx[len(_GD.text(conn, 'KO')):].lstrip()      # ★ 317차 — 필수 지침 다음부터
        _sx = _sx[len(table_rule('KO')):].lstrip()            # ★ 84-1 — 표 규칙 줄 다음부터
        _sx = _sx[len(context_line(conn, 'KO')):].lstrip()    # ★ 2026-10-22 오늘·나라 줄 다음부터
        ck('[용어]' not in _sx.split(NL + NL)[0] and _sx.startswith(term_name(conn, eid, 'KO'))
           and '[관련 단락 (첫 절 · 개역한글)]' in _sx, '용어 프롬프트의 [용어] 자리와 재료')
        rows_ = msgs_full(conn, cid2)
        ck([x[5] for x in rows_ if x[1] == 'ai'] == ['g-a', 'o-b'], '답마다 모델 이름이 남는다')
        calls.clear()
        send(conn, cid2, '더 묻습니다', _call=fake_multi)
        hist_a = [b for r_, b in calls[0][2] if r_ == 'ai']
        ck(hist_a == ['g-a 의 답'], '★ 각 AI 에게는 제 답만 앞 대화로 싣는다(남의 답은 안 싣는다): %s' % hist_a)
        ck('(g-a)' in merge_text(conn, cid2) and '(o-b)' in merge_text(conn, cid2), '합친 글이 어느 AI 의 답인지 적는다')
        # ── 300차 404 자동 전환 — 묻고 · 바꾸고 · 저장하고 · 말한다 ──
        _fl = lambda p, k, timeout=30, _get_fn=None: {          # noqa: E731
            'ok': True, 'models': ['zzz-unknown', PROVIDER[p]['model'], 'aaa'], 'why': ''}
        ck(pick_model(conn, 'GEMINI', 'k', 'g-a', _list=_fl)['model'] == PROVIDER['GEMINI']['model'],
           '★ 키가 쓸 수 있는 것 가운데 우리 기본 모델을 먼저 선택한다')
        ck(pick_model(conn, 'GEMINI', 'k', PROVIDER['GEMINI']['model'],
                      _list=lambda *_a, **_k: {'ok': True, 'models': [PROVIDER['GEMINI']['model']],
                                               'why': ''})['ok'] is False,
           '★ 지금 쓰던 이름만 있으면 안 선택한다(같은 404 를 또 먹지 않는다)')
        ck(pick_model(conn, 'GEMINI', 'k', 'g-a',
                      _list=lambda *_a, **_k: {'ok': False, 'models': [], 'why': '망 없음'})['why'] == '망 없음',
           '못 물어보면 까닭을 그대로 낸다(조용히 넘기지 않는다)')
        ck(pick_model(conn, 'GEMINI', 'k', 'g-a',
                      _list=lambda *_a, **_k: {'ok': True, 'models': ['solo-x'], 'why': ''})['model'] == 'solo-x',
           '우리 후보가 하나도 없으면 키 목록 첫 번째')
        _seen = []

        def _c404(p, k, m_, msgs_, system=''):
            _seen.append(m_)
            if m_ in ('g-a', 'o-b'):
                return {'ok': False, 'text': '', 'why': 'HTTP 404 ' + NOT_FOUND_HINT,
                        'tokens': {}, 'code': 404}
            return {'ok': True, 'text': '%s 의 답' % m_, 'tokens': {}, 'code': 200}
        r4 = send(conn, cid2, '404 가 나면?', _call=_c404, _models=_fl)
        _sw = r4.get('switched') or []
        ck(r4['ok'] and len(_sw) == 2
           and _sw[0] == ('GEMINI', 'g-a', PROVIDER['GEMINI']['model'])
           and _sw[1] == ('OPENAI', 'o-b', PROVIDER['OPENAI']['model']),
           '★★★ 404 면 키에게 묻고 모델을 바꿔 다시 보낸다: %s' % (_sw,))
        ck(len(_seen) == 4 and _seen[1] == PROVIDER['GEMINI']['model'],
           '계정마다 한 번만 바꿔 본다(첫 시도 + 바꿔 시도): %s' % _seen)
        _saved = accounts(conn)
        ck([a['model'] for a in _saved] == [PROVIDER['GEMINI']['model'], PROVIDER['OPENAI']['model'], 'x-c']
           and [a['key'] for a in _saved] == ['k1', 'k2', 'k3'] and [a['on'] for a in _saved] == [1, 1, 0],
           '★★★ 바꾼 모델이 저장된다 — 꺼 둔 계정·키·체크는 그대로: %s' % (_saved,))
        ck([x[5] for x in msgs_full(conn, cid2) if x[1] == 'ai'][-2:]
           == [PROVIDER['GEMINI']['model'], PROVIDER['OPENAI']['model']],
           '답에 적히는 모델도 바뀐 이름이다')
        _n429 = []

        def _c429(p, k, m_, msgs_, system=''):
            _n429.append(m_)
            return {'ok': False, 'text': '', 'why': 'HTTP 429 한도', 'tokens': {}, 'code': 429}
        r5 = send(conn, cid2, '한도가 차면?', _call=_c429, _models=_fl)
        ck(not r5['ok'] and not r5.get('switched') and len(_n429) == 2,
           '★ 404 가 아니면 모델을 안 바꾼다(한도 초과는 그대로 실패): %s' % _n429)
        _all4 = []

        def _c404b(p, k, m_, msgs_, system=''):
            _all4.append(m_)
            return {'ok': False, 'text': '', 'why': 'HTTP 404', 'tokens': {}, 'code': 404}
        r6 = send(conn, cid2, '계속 404 면?', _call=_c404b, _models=_fl)
        ck(not r6['ok'] and not r6.get('switched') and len(_all4) == 4,
           '★ 바꿔 보고 또 404 면 포기한다(무한 고리 없음): %s' % _all4)
        ck([a['model'] for a in accounts(conn)]
           == [PROVIDER['GEMINI']['model'], PROVIDER['OPENAI']['model'], 'x-c'],
           '실패한 전환은 저장하지 않는다')
        _seen.clear()
        r7 = send(conn, cid2, '못 물어보면?', _call=_c404b,
                  _models=lambda *_a, **_k: {'ok': False, 'models': [], 'why': '망 없음'})
        ck(not r7['ok'] and not r7.get('switched') and '404' in r7['why'],
           '★ 키에게 못 물어보면 원래 404 메시지 그대로(힌트가 남는다)')
        # ── 2026-10-13 붐빌 때(503·시간 초과) 다른 모델로 한 번 더 — 저장은 안 바꾼다 ──
        _MODEL_LIST_CACHE.clear()
        _gm = PROVIDER['GEMINI']['model']
        _alt = next((m for m in (providers(conn).get('GEMINI') or {}).get('models', []) if m != _gm), 'alt-x')
        _flb = lambda p, k, timeout=30, _get_fn=None: {'ok': True, 'models': [_gm, _alt, PROVIDER['OPENAI']['model']], 'why': ''}  # noqa: E731
        _bz = []

        def _cbusy(p, k, m_, msgs_, system='', timeout=None):
            _bz.append((m_, timeout))
            if m_ == _gm:
                return {'ok': False, 'text': '', 'why': '연결하지 못했습니다(망 없음?): The read operation timed out',
                        'tokens': {}, 'code': 0}
            return {'ok': True, 'text': '%s 의 답' % m_, 'tokens': {}, 'code': 200}
        r8 = send(conn, cid2, '붐비면?', _call=_cbusy, _models=_flb)
        ck(r8['ok'] and ('GEMINI', _gm, _alt) in (r8.get('busy') or [])
           and any(m_ == _alt for m_, t_ in _bz),
           '★★ 붐비면(시간 초과) 다른 모델로 한 번 더 받는다: %s' % (r8.get('busy'),))
        ck([a['model'] for a in accounts(conn)][0] == _gm, '붐벼서 넘어간 것은 저장하지 않는다(잠깐 붐빈 것이다)')
        _MODEL_LIST_CACHE.clear()
        # 프롬프트 — 갈래 · 추가 · 이름 · 삭제
        # ⚠ 개수를 못 박지 않는다(§0-5) — 사용자가 씨앗 하나를 [지우기](HIDE)해 두면 셋이 아니다.
        #   묻는 것은 「씨앗이 갈래마다 심어져 있고 · 목록은 살아 있는 것만 · 갈래가 맞나」다.
        _term_live = prompts(conn, 'KO', 'TERM')
        _term_all = {r[0] for r in conn.execute(
            "SELECT kind FROM user_ai_prompt WHERE scope='TERM' AND lang_code='KO'")}
        _term_live_db = conn.execute(
            "SELECT COUNT(*) FROM user_ai_prompt WHERE scope='TERM' AND lang_code='KO' AND record_status='LIVE'"
            " AND COALESCE(task,'')=''").fetchone()[0]
        ck(set(TERM_KINDS) <= _term_all and len(_term_live) == _term_live_db
           and all(p[1] in TERM_KINDS or p[1].startswith('USER') for p in _term_live),
           '용어 갈래 프롬프트 — 씨앗 셋이 심어져 있고 목록은 살아 있는 것만(%d/%d)' % (len(_term_live), len(_term_all)))
        # ⚠ 317차-5 — 사람이 숨긴 씨앗이 있어도 깨지지 않게 **심겼는가**를 센다(§0-5)
        _vk = {r[0] for r in conn.execute("SELECT kind FROM user_ai_prompt WHERE scope='VERSE' AND lang_code='KO'")}
        ck(set(KINDS) <= _vk, '구절 갈래 씨앗이 다 심겼다', sorted(set(KINDS) - _vk))
        _pid_new = add_prompt(conn, 'KO', 'VERSE', '내 독창 프롬프트', '[구절] 을 시로 풀어 주세요.')
        ck(any(p[0] == _pid_new and p[2] == '내 독창 프롬프트' for p in prompts(conn, 'KO', 'VERSE')),
           '★ 사용자가 프롬프트를 더한다')
        save_prompt(conn, _pid_new, '이름 바꿈', '[구절] 을 노래로.')
        ck(any(p[0] == _pid_new and p[2] == '이름 바꿈' for p in prompts(conn, 'KO', 'VERSE')), '항목 이름을 고친다')
        hide_prompt(conn, _pid_new)
        ck(not any(p[0] == _pid_new for p in prompts(conn, 'KO', 'VERSE')), '지운 프롬프트는 목록에서 빠진다(HIDE)')
        # 노트 범위
        conn.execute("INSERT INTO user_text_asset(clicked_id, text_type, contents, lang_code, record_status, created_at)"
                     " VALUES(?,?,?,?,'LIVE',?)", (shift(conn, vid, 30), 'VERS_NOTE', '관련구절 창 2:1' + NL + '자가검증 2장 노트', 'KO', _now()))
        _nid2 = conn.execute("SELECT MAX(user_text_id) FROM user_text_asset").fetchone()[0]
        try:
            ck(not any('2장 노트' in x for x in my_notes(conn, vid, v5, scope='RANGE'))
               and any('2장 노트' in x for x in my_notes(conn, vid, v5, scope='BOOK'))
               and any('2장 노트' in x for x in my_notes(conn, vid, v5, scope='ALL')),
               '★ 묵상노트 범위 — 구간엔 없고 책·전부에는 있다')
        finally:
            conn.execute("DELETE FROM user_text_asset WHERE user_text_id=?", (_nid2,))
    finally:
        if cid2:
            conn.execute("DELETE FROM user_ai_msg WHERE chat_id=?", (cid2,))
            conn.execute("DELETE FROM user_ai_chat WHERE chat_id=?", (cid2,))
        if _pid_new:
            conn.execute("DELETE FROM user_ai_prompt WHERE prompt_id=?", (_pid_new,))
        if had_raw:
            set_setting(conn, 'AI_ACCOUNTS', raw0 or '')
        else:
            conn.execute("DELETE FROM user_config WHERE config_key='AI_ACCOUNTS'")
        conn.commit()
    # ══ 303차 — 성격 묶기 · 질문 결합 · 연구자료 닻 · 제목 규칙 ══════
    ck(GENRE_KEYS == [g[0] for g in GENRES] and MULTI_GENRES == {'CHAT'},
       '성격 표 — 복수선택은 일반대화형 안에서만', (GENRE_KEYS, MULTI_GENRES))
    ck(all(v in GENRE_KEYS for v in GENRE_OF.values()),
       '갈래→성격 표의 값이 모두 있는 성격이다')
    ck(genre_of('CHECK') == 'QUEST' and genre_of('TEACH') == 'TEACH'
       and genre_of('USER7') == GENRE_DEFAULT and genre_of('USER7', 'ANAL') == 'ANAL',
       '★ 성격 판정 — 적힌 값이 먼저 · 없으면 갈래 표 · 그래도 없으면 기본')
    ck(genre_of('CHECK', 'NOPE') == 'QUEST', '모르는 성격값은 무시한다(갈래 표로)')
    ck(all(len(r) == 5 for r in prompts(conn, 'KO', 'VERSE')),
       '프롬프트가 성격까지 다섯 칸을 낸다')
    ck({r[4] for r in prompts(conn, 'KO', 'VERSE')} <= set(GENRE_KEYS),
       '모든 프롬프트에 성격이 붙었다(옛 줄도)')
    _slot = quest_slot('KO')
    ck(_slot and _slot in SEED_PROMPTS['CHECK']['KO'][1],
       '★ 질문 자리표를 씨앗 본문에서 뽑는다(두 곳에 안 적는다)', _slot)
    ck(fill_question(SEED_PROMPTS['CHECK']['KO'][1], '왜 그렇습니까?', 'KO').count('왜 그렇습니까?') == 1
       and _slot not in fill_question(SEED_PROMPTS['CHECK']['KO'][1], '왜 그렇습니까?', 'KO'),
       '★★★ 내 질문이 자리표를 대신한다(두 번 묻지 않는다)')
    ck(fill_question('자리표 없는 글', '내 물음', 'KO').endswith('내 물음'),
       '★ 자리표가 없으면 끝에 붙인다(조용히 잃지 않는다)')
    ck(fill_question('그대로', '', 'KO') == '그대로', '질문이 비면 글을 안 건드린다')
    ck(join_bodies(['가', '', '나']) == '가' + NL + NL + '나',
       '★ 복수선택 — 빈 글은 빼고 빈 줄로 잇는다')
    # ── 조립 단일 문 `compose` — 차례가 알맹이다 ────────────────────
    #   ★★★ 차례 = **물음 → 자유 → 깊이·관점 → 출력서식**(311차).
    #   ⚠ 축은 가짜로 갈아 끼워 잰다 — 저장값에 기대면 검사가 헛돈다(§0-5).
    _ab0 = globals()['axis_bodies']
    try:
        globals()['axis_bodies'] = lambda *_a, **_k: ['<<축>>']
        _cp = compose(conn, ['<<물음>>'], '', 'KO', free='<<자유>>', fmt='<<서식>>',
                      ban='<<금지>>')
        _pos = [_cp.find(x) for x in ('<<물음>>', '<<자유>>', '<<축>>', '<<금지>>', '<<서식>>')]
        ck(all(p >= 0 for p in _pos) and _pos == sorted(_pos),
           '★★★ 조립 차례 = 물음 → 자유 → 깊이·관점 → **금지사항 → 출력서식**', _pos)
        ck('<<금지>>' in compose(conn, ['<<물음>>'], '', 'KO', ban='<<금지>>',
                                 with_axes=False),
           '★★★ 축을 꺼도 금지사항은 나간다(자유·출력서식과 같은 규칙)')
        # ⚠ `free=''` 를 **반드시 준다** — 안 주면 저장된 자유 프롬프트가 함께
        #   들어와 검사가 헛돈다(§0-5 「데이터 상태를 전제하지 말 것」).
        # ★ 317차 — 칸 머리말이 붙고 **빈 칸은 머리말째 빠진다**. 저장값이 섞이지 않게
        #   내용과 형식 다섯 칸도 빈 글로 준다(§0-5 「데이터 상태를 전제하지 말 것」).
        _np = {pp: '' for pp, _kk in PARTS if pp not in ('BAN', 'FORMAT')}
        _one = '[%s]%s<<물음>>' % (slot_head('KO')['TASK'], NL)
        ck(compose(conn, ['<<물음>>'], '', 'KO', free='', ban='  ', fmt='',
                   with_axes=False, parts=_np).strip() == _one,
           '★ 빈 금지사항은 안 담는다(빈 줄을 남기지 않는다)')
        ck('<<축>>' not in compose(conn, ['<<물음>>'], '', 'KO', fmt='<<서식>>',
                                   with_axes=False)
           and '<<서식>>' in compose(conn, ['<<물음>>'], '', 'KO', fmt='<<서식>>',
                                     with_axes=False),
           '★★★ 축을 꺼도 출력서식은 나간다(사용자가 적은 것을 끄는 스위치는 없다)')
        ck('<<서식>>' in compose(conn, [], '', 'KO', fmt='<<서식>>', with_axes=False),
           '★ 선택한 프롬프트가 없어도 출력서식은 나간다(§0-1 — 적은 글을 안 버린다)')
        # ⚠⚠ `free=''` **와 `ban=''` 를 둘 다** 준다 — 하나라도 빠지면 저장된
        #   글이 섞여 검사가 헛돈다(실측 — 사용자가 금지사항을 적은 날 FAIL 했다).
        _empty = compose(conn, ['<<물음>>'], '', 'KO', free='', ban='', fmt='   ',
                         with_axes=False, parts=_np)
        ck(_empty.strip() == _one,
           '★ 빈 출력서식·자유는 안 담는다(빈 줄을 남기지 않는다)', _empty)
        # ── 317차 — 고정 서식 ───────────────────────────────────────────
        _rows = compose_parts(conn, task='<<할일>>', role='<<역할>>', question='<<물>>',
                              picks=['<<p1>>', '<<p2>>'], free='<<자>>', ban='<<금>>',
                              fmt='<<서>>', lang='KO', state='S_PASTOR', faith='F_CATH',
                              view='V_REFORMED', parts=dict(_np, STYLE='<<문>>'))
        ck([r[0] for r in _rows] == SLOTS, '★★★ 칸이 고정된 차례로 열셋(빈 칸도 자리)')
        _txt = compose(conn, None, task='<<할일>>', role='<<역할>>', question='<<물>>',
                       picks=['<<p1>>', '<<p2>>'], free='<<자>>', ban='<<금>>', fmt='<<서>>',
                       lang='KO', state='S_PASTOR', faith='F_CATH', view='V_REFORMED',
                       parts=dict(_np, STYLE='<<문>>'))
        _o = [_txt.find(x) for x in ('<<역할>>', '<<할일>>', '<<물>>', '<<자>>', '<<p1>>',
                                     '<<문>>', '<<금>>', '<<서>>')]
        ck(all(x >= 0 for x in _o) and _o == sorted(_o), '★★★ 보내는 글 차례 = 칸 차례', _o)
        ck('1. <<p1>>' in _txt and '2. <<p2>>' in _txt, 'Pick 은 번호를 붙여 쌓는다')
        ck('[%s]%s<<축>>' % (slot_head('KO')['ASKER'], NL) in _txt,
           '★ 상태·신앙 배경·관점은 「묻는 사람」 칸 하나에')
        _ask = NL.join(_ab0(conn, 'KO', depth='S_PASTOR', faith='F_CATH', view='V_REFORMED'))
        ck('가톨릭' in _ask and '설교' in _ask and '언약' in _ask,
           '★ 묻는 사람 = 상태(목사) · 신앙 배경(가톨릭) · 관점(개혁)', _ask)
        ck('[Role]' in compose(conn, None, role='r', lang='EN', with_axes=False,
                               parts=_np, free='', ban='', fmt=''),
           '★ 머리말은 채팅 언어로(영어 채팅은 [Role])')
        ck(len(AXIS_KINDS['STATE']) == 8 and 'S_PROF' not in AXIS_KINDS['STATE'] and len(AXIS_KINDS['FAITH']) == 8,
           '★ 상태 여덟(신학교수 걷음 2026-10-27) · 신앙 배경 여덟')
        ck('F_CATH' in AXIS_KINDS['FAITH'] and not any('CATH' in k for k in AXIS_KINDS['VIEW']),
           '★★★ 가톨릭은 신앙 배경이다 — 관점(개신교 전통)에는 없다')
        ck(all(SEED_AXIS[k].get(lg) for k in AXIS_ALL for lg in
               ('KO', 'EN', 'JA', 'ZH', 'ZHT', 'DE', 'FR', 'ES', 'PT', 'RU', 'AR')),
           '★ 새 축 씨앗이 11개 언어 전부')
        ck(not any(b for _k, _t, b in axis_rows(conn, 'STATE', 'KO') if _k == 'S_NONE'),
           '「선택 안 함」은 아무것도 보내지 않는다')
        ck(axis_rows(conn, 'DEPTH', 'KO') == axis_rows(conn, 'STATE', 'KO'),
           '옛 이름 DEPTH 는 상태로 잇는다')
        _cd = cite_default(conn, 'KO')
        ck(get_setting(conn, 'BIBLE_VERSION', '') == '' or
           (get_setting(conn, 'BIBLE_VERSION', '') in _cd and '그대로 인용' in _cd),
           '★ 성경 인용 기본 = 선택한 역본으로', _cd)
        ck(all(len(v) == len(SLOTS) for v in SLOT_HEAD.values()) and len(SLOT_HEAD) == 11,
           '머리말 11개 언어 × 열셋')
        # ── 317차 4단계 — 저장 넷 ──────────────────────────────────────
        ck(saves_for('VERSE') == ['REF', 'VDESC', 'NOTE', 'ROLE', 'LDESC'] and saves_for('TERM') == ['REF', 'TDESC']
           and saves_for('REF') == ['REF'] and saves_for('FREE') == ['REF', 'VDESC', 'TDESC'],
           '★★ [저장 ▾] 은 그 갈래에 맞는 것만')
        _pp = {'DESC': '가', 'QUES': '나?', 'PRAYER': '다', 'STUDY': ''}
        for _lg in ('KO', 'EN', 'RU'):
            _sp, _w = split_desc(desc_join(_pp, _lg), _lg)
            ck(_sp == {'DESC': '가', 'QUES': '나?', 'PRAYER': '다'}, '★ 설명문 칸 → 한 덩이 → 칸 왕복(%s)' % _lg, _sp)
        _sp2, _w2 = split_desc(desc_join({'DESC': '가', 'PRAYER': '다'}, 'KO'), 'KO')
        ck(_sp2 == {'DESC': '가', 'PRAYER': '다'}, '★ 칸 일부만 적혀도 그 칸들을 담는다(반쪽 거부를 안 탄다)', (_sp2, _w2))
        ck(split_desc('그냥 글', 'KO')[0] is None, '칸 표시가 없으면 나누지 않는다')
        ck(ref_title_clash(conn, '#없는 제목#317', -1) is None, '없는 제목은 겹치지 않는다')
        import overlay_edit as _OE
        _tv = None
        for (_vv,) in conn.execute("SELECT verse_id FROM bible_index WHERE bcode=65 ORDER BY sort_order LIMIT 25"):
            if all(_OE.target_state(conn, tt, _vv, 'KO', var)[1] in ('SYS', 'NONE')
                   for _k, tt, var in DESC_SAVE):
                _tv = _vv
                break
        if _tv:
            _cur = desc_current(conn, _tv, 'KO')
            try:
                _n = desc_save(conn, _tv, 'KO', {'DESC': '<<시험설명>>', 'QUES': '', 'PRAYER': '<<시험기도>>'})
                _dnow = desc_current(conn, _tv, 'KO')
                ck(_n == 2 and _dnow['DESC'] == '<<시험설명>>' and _dnow['PRAYER'] == '<<시험기도>>'
                   and _dnow['QUES'] == _cur['QUES'],
                   '★★★ 구절 설명문 저장 = 덮개 · 빈 칸은 지금 글을 안 지운다', _dnow)
            finally:
                for _k, tt, var in DESC_SAVE:
                    _v2, _st2, _t2 = _OE.target_state(conn, tt, _tv, 'KO', var)
                    if _st2 in ('EDIT', 'NEW'):
                        _OE.revert_mine(conn, tt, _tv, 'KO', _v2)
                conn.commit()
            ck(desc_current(conn, _tv, 'KO') == _cur, '시험 덮개 자국 0(되돌렸다)')
        # ── 317차 2단계 — 업무 유형 · 공통 역할 · Free ─────────────────
        # ★ 317차-14 — 내 업무 · 사용자 목록 항목의 이름 규칙(쓰기 없이 잰다 — 쓰는 시험은 AI 하네스)
        ck(task_kind('VERSE', 'UT_7') == 'UT_7' and role_kind('UT_7') == 'UR_7'
           and axis_of_kind('US_3') == 'STATE' and axis_of_kind('F_CATH') == 'FAITH' and axis_of_kind('V_REFORMED') == 'VIEW',
           '★ 내 업무(UT_) · 역할(UR_) · 사용자 목록 항목(US_/UF_/UV_) 이름 규칙')
        ck(set(axis_kinds(conn, 'STATE')) >= {AXIS_DEFAULT['STATE']} and set(PART_ALL) >= {'FREE', 'FORMAT', 'BAN'},
           '사용자 목록에 기본 항목이 늘 있다 · 내용과 형식 칸 여덟')
        ck(tasks_for('VERSE') == ['DESC', 'XDESC', 'ASK', 'STUDY', 'SERMON', 'NOTE', 'TEACH', 'LINKAN'] + list(ROLE_TASKS)
           and tasks_for('TERM') == ['DESC', 'TERMAN', 'ASK', 'STUDY', 'TEACH', 'FIGURE', 'PLACEAN']
           and tasks_for('ERA') == ['ERAAN']
           and tasks_for('REF') == ['REFAN', 'SERMAN', 'SERMWR', 'BOOKMEDI'] and tasks_for('FREE') == [],
           '★★★ 갈래마다 업무 — 구절 넷 · 용어 셋 · 연구/설교노트 둘 + 도서 묵상(도서 편 닻 · 81) · **Free 는 없다**')
        ck(len(SEED_TASK.get('T_SERMAN', {})) == 11 and 'R_SERMAN' in SEED_ROLE
           and len(TASK_PICK_SEEDS.get('SERMAN', [])) >= 6 and task_kind('REF', 'SERMAN') == 'T_SERMAN',
           '★★★ 317차-16 — 설교노트 분석: 할 일 11언어 · 제 역할 · 제 Pick')
        ck(ref_task_of(conn, 'REF_UNIT:1') == 'REFAN' and ref_task_of(conn, '') == 'REFAN'
           and ref_task_of(conn, 'USER_REF:999999999') == 'REFAN',
           '공용 자료·없는 닻은 연구노트 분석으로')
        ck(task_kind('VERSE', 'DESC') == 'T_DESC_V' and task_kind('TERM', 'DESC') == 'T_DESC_T',
           '설명문 작성은 구절·용어가 다른 꼴을 쓴다')
        ck(task_kind('VERSE', 'ASK') == 'T_ASK' and task_kind('VERSE', 'STUDY') == 'T_STUDY'
           and task_kind('TERM', 'TERMAN') == 'T_TERMAN' and task_kind('VERSE', 'TERMAN') == ''
           and task_kind('VERSE', 'RESEARCH', 'STUDY') == 'T_STUDY'
           and len(TASK_PICK_SEEDS.get('STUDY', [])) >= 5 and len(TASK_PICK_SEEDS.get('TERMAN', [])) >= 5
           and FORMAT_PRESETS['KO'][0][0] == '대화식' and _fmt_name_for(conn, 'ASK', 'KO') == '대화식',
           '★★ 2026-10-16 구절질문 · 성경공부 · 용어 설명문 분석 — 업무 셋 · Pick · 질문은 대화식 서식')
        ck('제목' not in SEED_TASK['T_ASK']['KO'][1] and '설교' in SEED_TASK['T_ASK']['KO'][1]
           and all(len(OLD_T_ASK.get(lg, ('', ''))[1]) > 0 for lg in SEED_TASK['T_ASK']),
           '구절질문 씨앗 = 대화하듯 · 짧게(옛 씨앗은 이관용으로 남김)')
        ck(task_kind('VERSE', 'RESEARCH', 'CHECK') == 'T_ASK' and 'CHECK' not in RESEARCH_MODES
           and task_kind('VERSE', 'SERMON') == 'T_SERMON_V'
           and [k for k, _ in TASK_PICK_SEEDS['SERMON']][-1] == LINK_PICK_KIND
           and len(TASK_PICK_SEEDS['SERMON']) == 13
           and task_kind('VERSE', 'RESEARCH', '???') == 'T_ASK'
           and task_kind('REF', 'DESC') == '' and task_kind('FREE', 'TEACH') == '',
           '연구하자 갈래 · 모르는 갈래는 질문 · 그 갈래에 없는 업무는 빈 글')
        ck(all(len(SEED_TASK[k]) == 11 for k in TASK_ALL if k not in KO_FIRST)
           and all({'KO', 'EN'} <= set(SEED_TASK[k]) for k in KO_FIRST),
           '★ 역할·할 일 씨앗이 11개 언어 전부(새 기도 프롬프트는 한국어·영어 먼저)',
           [k for k in TASK_ALL if k not in KO_FIRST and len(SEED_TASK[k]) != 11])
        _pb = prayer_bundle(conn, 'JA')
        ck(len(_pb['tasks']) == len(PRAYER_TASKS) and all(t['body'] for t in _pb['tasks']) and _pb['role']
           and all(m in PRAYER_TASKS and all(x in PRAYER_TASKS for x in ps) for g in PRAYER_GROUPS.values() for m, ps in g)
           and 'groups' in _pb
           and set(_pb['states']) == {'PRAY', 'BETTER', 'YES'} and all(len(PRAYER_STATES[k]) == 3 for k in PRAYER_STATES)
           and set(PRAYER_STATES) == set(PRAYER_LABELS) and len(PRAYER_STATES) == 11
           and 'prayer' in phone_bundle(conn, 'KO'),
           '★ 77 — 기도 AI 업무 여섯(11언어) · 역할 · 상태 이름 셋 · 꾸러미에 실린다')
        _vb = [(k, lg) for k in PRAYER_TASKS for lg, (_t, b) in SEED_TASK['T_' + k].items()
               if k not in ('PR_SELF', 'PR_HEART', 'PR_VERSE') and 'T_' + k not in KO_FIRST and not any(x in b for x in ('장:절', 'chapter:verse', '章:節', '章:节', 'Kapitel:Vers', 'chapitre:verset', 'capítulo:versículo', 'глава:стих', 'главой:стихом', 'الأصحاح:العدد'))]
        ck(not _vb, '★ 기도 업무는 성경 구절을 약명 장:절로 추천받는다', _vb[:4])
        ck(not put_prayer_prompt(conn, 'T_ASK', 'KO', body='x'), '기도 프롬프트 문은 기도 업무만 받는다')
        ck(len(PRAYER_FMT) == 11 and set(PRAYER_FMT) == set(PRAYER_LABELS)
           and all(all(m in v for m in ('[[P]]', '[[V]]', '[[T]]')) for v in PRAYER_FMT.values())
           and 'fmt' in prayer_bundle(conn, 'KO') and '[[V]]' in prayer_bundle(conn, 'JA')['fmt'],
           '★ 기도 답 형식 규칙 11언어([[P]] [[V]] [[T]]) · 꾸러미에 실린다')
        _phs = _PH_VERSE + _PH_TERM + _PH_REF
        # ★ 기도 업무는 닻이 없다 — 폰이 사람이 적은 상황 요약을 끝에 붙인다(자리표를 안 쓴다)
        _noph = [(k, lg) for k in TASK_ALL if k != ROLE_KIND and not k.startswith('T_PR_')
                 for lg, (_t, b) in SEED_TASK[k].items() if not any(x in b for x in _phs)]
        ck(not _noph, '★★★ 할 일 글마다 **채움 규칙이 아는 자리표**가 있다(안 채워지면 「[verse]」가 그대로 간다)',
           _noph[:4])
        ck(all(('[%s]' % m) in SEED_TASK['T_DESC_V'][lg][1] for lg, ms in DESC_MARKS.items() for m in ms[:3])
           and all(('[%s]' % ms[3]) not in SEED_TASK['T_DESC_V'][lg][1] for lg, ms in DESC_MARKS.items())
           and all(('[%s]' % m) in SEED_TASK['T_XDESC_V'][lg][1] for lg, ms in DESC_MARKS.items() for m in ms[3:5]),
           '★ 일반설명문 = 설명문·묵상질문·묵상기도 · 전문설명문 = 전문 설명·연구질문(칸 이름은 그 언어 · 11개 언어)')
        _xs, _xw = split_desc(NL.join(['[%s]' % _DESC_KO[4], '가', '', '[%s]' % _DESC_KO[3], '나?']), 'KO')
        ck(_xs == {'XDESC': '가', 'STUDY': '나?'}, '★ 전문설명문 답 → 전문 설명·연구질문 칸', _xs)
        ck(dict((k, (tt, v)) for k, tt, v in DESC_SAVE)['XDESC'] == ('VERS_DESC', 'EXPERT')
           and dict((k, (tt, v)) for k, tt, v in DESC_SAVE)['STUDY'] == ('VERS_QUESTION', 'EXPERT'),
           '★ 전문 칸은 EXPERT 로 담긴다')
        _bad_sp = []
        for lg, ms in DESC_MARKS.items():
            _sp, _why = split_desc('[%s]%s가%s%s[%s]%s나?%s%s[%s]%s다' % (
                ms[0], NL, NL, NL, ms[1], NL, NL, NL, ms[2], NL), lg)
            if not _sp or set(_sp) != {'DESC', 'QUES', 'PRAYER'}:
                _bad_sp.append(lg)
        ck(not _bad_sp, '★★★ 그 언어 칸 이름으로 쓴 답을 관리자 묶음 칸으로 되읽는다(11개 언어)', _bad_sp)
        ck('하나만' in SEED_TASK['T_TEACH']['KO'][1] and 'one question at a time' in SEED_TASK['T_TEACH']['EN'][1],
           '★★★ 성경교사 = 한 번에 질문 하나(docs/1.txt 3-1)')
        ck('TEACH' not in SOLO_TASKS and TASK_PICK_SEEDS.get('TEACH'), '★ 교사도 Pick 을 곁들인다(사용자 예시 열하나)')
        _pk = [r[1] for r in pick_prompts(conn, 'KO', 'VERSE', 'DESC')]
        ck(_pk and not (set(_pk) & set(TASK_SUPERSEDED)),
           '★ 창고(Pick) 에 업무가 맡은 옛 씨앗이 안 뜬다', _pk)
        _fr = pick_prompts(conn, 'KO', 'FREE')
        ck(not ({r[0] for r in _fr} & {r[0] for r in pick_prompts(conn, 'KO', 'VERSE', 'DESC')})
           and not any(not str(r[1]).startswith(('USER', 'L_', 'M_')) for r in _fr),     # 라이브러리에서 사람이 더한 것은 L_·M_
           '★★★ Free 는 예제를 주지 않는다 · 제 자리다(사람이 더한 것만)', [r[2] for r in _fr])
        ck([r[2] for r in pick_prompts(conn, 'KO', 'VERSE', 'NOTE')][:2] == ['특징', '장점'],
           '★ 묵상노트 분석의 Pick = 사용자 예시', [r[2] for r in pick_prompts(conn, 'KO', 'VERSE', 'NOTE')])
        # ★★★ 317차-5 — 업무마다 독립: 한 업무에서 지워도 다른 업무엔 남는다 · 더한 것도 그 업무에만
        _d = pick_prompts(conn, 'KO', 'VERSE', 'DESC')
        _r = pick_prompts(conn, 'KO', 'VERSE', 'ASK')
        _libm = _lib(conn)
        if _libm is not None:
            # ★★★ 2026-10-21 1:1 — 자리마다 제 항목(같이 쓰지 않는다) · 떼기·더하기는 그 자리에만
            #   ⚠ 실제 개인 DB 다 — 사람이 둔 항목은 건드리지 않고 시험 항목을 더해 잰다
            ck(_d and _r and not ({x[0] for x in _d} & {x[0] for x in _r}),
               '★★★ 라이브러리 1:1: 두 자리가 같은 항목을 같이 쓰지 않는다')
            _np = None
            try:
                _np = add_prompt(conn, 'KO', 'VERSE', 't', 'b', task='ASK')
                ck(_np in [x[0] for x in pick_prompts(conn, 'KO', 'VERSE', 'ASK')]
                   and _np not in [x[0] for x in pick_prompts(conn, 'KO', 'VERSE', 'DESC')],
                   '★★ 한 자리에서 더한 Pick 은 그 자리에만 단다')
                hide_prompt(conn, _np, place='VERSE:ASK')
                ck(_np not in [x[0] for x in pick_prompts(conn, 'KO', 'VERSE', 'ASK')],
                   '★★ 그 자리에서 지운 Pick 은 사라진다')
            finally:
                if _np:
                    _k = _libm.row_of(conn, -_np)[0]
                    conn.execute("DELETE FROM user_ai_lib WHERE item_key=?", (_k,))
                    conn.execute("DELETE FROM user_ai_lib_place WHERE item_key=?", (_k,))
                conn.commit()
        if _libm is None:
          ck(_d and _r and not ({x[0] for x in _d} & {x[0] for x in _r}),
             '★★★ 설명문 작성과 연구하자의 Pick 은 서로 다른 줄이다', ([x[0] for x in _d], [x[0] for x in _r]))
          _sv = conn.execute("SELECT prompt_id, record_status FROM user_ai_prompt WHERE prompt_id=?",
                             (_d[0][0],)).fetchone()
          _np = None
          try:
              conn.execute("UPDATE user_ai_prompt SET record_status='HIDE' WHERE prompt_id=?",
                                            (_d[0][0],))
              _kd = _d[0][1]
              ck(_kd not in [x[1] for x in pick_prompts(conn, 'KO', 'VERSE', 'DESC')]
                 and _kd in [x[1] for x in pick_prompts(conn, 'KO', 'VERSE', 'ASK')],
                 '★★★ 설명문 작성에서 지운 Pick 이 연구하자에는 남는다', _kd)
              _np = conn.execute("INSERT INTO user_ai_prompt(lang_code, kind, title, body, sort_order, scope, genre, task)"
                                 " VALUES('KO','USERT','t','b',999,'VERSE','CHAT','ASK')").lastrowid
              ck(_np in [x[0] for x in pick_prompts(conn, 'KO', 'VERSE', 'ASK')]
                 and _np not in [x[0] for x in pick_prompts(conn, 'KO', 'VERSE', 'DESC')],
                 '★★★ 연구하자에서 더한 Pick 은 연구하자에만 있다')
          finally:
              conn.execute("UPDATE user_ai_prompt SET record_status=? WHERE prompt_id=?", (_sv[1], _sv[0]))
              if _np:
                  conn.execute("DELETE FROM user_ai_prompt WHERE prompt_id=?", (_np,))
              conn.commit()
        ck(not any(r[1] in TASK_ALL for r in prompts(conn, 'KO', 'VERSE')),
           '★ 역할·할 일 줄은 갈래 목록에 안 섞인다(scope TASK)')
        _fr = fill_prompt(conn, '[구절] · [용어] · [연구자료]', 'FREE', lang='KO')
        ck('[' not in _fr and FREE_WORD['KO'] in _fr, '★ Free 의 자리표 = 「이 본문」(지어내지 않는다)', _fr)
        ck(merge_prompt_body(conn, 'KO').strip() != '', '[한 글로] 단추가 쓸 글이 있다')
        _rl, _tk = task_texts(conn, 'VERSE', 'NOTE', lang='KO')
        ck(_rl == task_row(conn, role_kind('NOTE'), 'KO')[2] and '묵상노트' in _tk, '(역할, 할 일) 을 함께 낸다')
        ck(task_texts(conn, 'VERSE', 'DESC', lang='KO')[0] != task_texts(conn, 'VERSE', 'TEACH', lang='KO')[0],
           '★★★ 역할이 업무마다 다르다(docs/1.txt 2-6)(4)가)')
        ck(task_texts(conn, 'FREE', lang='KO')[1] == '', 'Free 는 할 일이 없다')
        _cf = None
        try:
            _cf = new_chat(conn, lang='KO', free=True)
            _chf = chat(conn, _cf)
            ck(_chf['scope'] == 'FREE' and not _chf['start_vid'] and not _chf['entity_id'],
               '★★★ Free 채팅 — 닻이 없다')
            import db_ai_guard as _GD2
            _sf = system_text(conn, _chf, '')
            ck(_sf.strip() == (_GD2.text(conn, 'KO').strip() + NL + NL + table_rule('KO') + NL + NL + context_line(conn, 'KO')).strip(),
               '★ Free 의 시스템 글 = 필수 지침 + 표 규칙 + 오늘·나라 줄뿐(재료가 없다)', _sf[-80:])
            ck(any(r[0] == _cf for r in chats_for(conn, scope='FREE')), 'Free 갈래로 거른다')
        finally:
            if _cf:
                conn.execute("DELETE FROM user_ai_msg WHERE chat_id=?", (_cf,))
                conn.execute("DELETE FROM user_ai_chat WHERE chat_id=?", (_cf,))
                conn.commit()
    finally:
        globals()['axis_bodies'] = _ab0
    ck(get_fmt(conn) == (get_setting(conn, 'AI_FORMAT', '') or '').strip(),
       '★ 출력서식 열쇠는 `AI_FORMAT` 하나다(두 곳에 안 적는다)')
    ck(get_ban(conn) == (get_setting(conn, 'AI_BAN', '') or '').strip(),
       '★ 금지사항 열쇠는 `AI_BAN` 하나다 — 갈래를 가리지 않아 「공통적용」이 성립한다')
    # ── ④ 묵상노트 상태 — 「살아 있다」의 정의가 `LIVE` 하나가 아니다 ──
    ck(set(NOTE_ALIVE) == {'LIVE', 'NEW', 'EDIT'} and 'HIDE' not in NOTE_ALIVE,
       '★★★ 살아 있는 노트 = LIVE·NEW·EDIT — **HIDE(지운 글)는 밖으로 안 나간다**',
       NOTE_ALIVE)
    try:
        import medi_note as _MN
        _msrc = open(_MN.__file__, encoding='utf-8').read()
        ck(("record_status IN ('%s')" % "','".join(NOTE_ALIVE)) in _msrc,
           '★★★ 잣대가 `medi_note` 의 읽는 문과 **같다**(두 곳이 갈리면 조용히 0건)')
    except Exception:                                     # noqa: BLE001
        ck(False, '★ `medi_note` 를 읽어 잣대를 견준다')
    _snote = _note_scope(conn, vid, v5, 'RANGE')
    ck(_snote is not None and 'sort_order BETWEEN' in _snote[0],
       '★ 구간 범위는 `sort_order` 로 좁힌다(§236차 — verse_id 는 정경 차례가 아니다)')
    ck(_note_scope(conn, vid, None, 'CHAPTER')[0].count('?') == 2
       and _note_scope(conn, vid, None, 'BOOK')[0].count('?') == 1,
       '★ 장·책 범위 — 좁히는 조건 수가 다르다')
    ck(_note_scope(conn, vid, None, 'ALL') == _note_scope(conn, vid, None, 'BOOK'),
       '★ 옛 값 ALL 은 그 책까지로 읽는다(성경 전체를 밖으로 보내지 않는다 · 303차)')
    ck(_note_body('') == '', '★ 빈 노트는 빈 글이다(세는 것과 싣는 것이 같다)')
    # ── 연구자료 닻 ─────────────────────────────────────────────────
    ck(ref_split('USER_REF:175') == ('USER_REF', 175)
       and ref_split('REF_UNIT:9') == ('REF_UNIT', 9)
       and ref_split('NOPE:1') == (None, None) and ref_split('') == (None, None),
       '★ 연구자료 닻 풀기 — 모르는 꼴은 거부한다')
    _rid = conn.execute("SELECT ref_id FROM user_ref_asset WHERE COALESCE(record_status,'LIVE')='LIVE'"
                        " ORDER BY ref_id LIMIT 1").fetchone()
    _uid = conn.execute("SELECT ref_unit_id FROM sys_ref_unit WHERE COALESCE(record_status,'LIVE')='LIVE'"
                        " ORDER BY ref_unit_id LIMIT 1").fetchone()
    if _rid and _uid:
        _a1 = 'USER_REF:%d' % _rid[0]
        _a2 = 'REF_UNIT:%d' % _uid[0]
        ck(ref_name(conn, _a1, 'KO').strip() != '', '★ 내 연구자료 닻의 제목을 낸다',
           ref_name(conn, _a1, 'KO'))
        ck(ref_name(conn, _a2, 'KO').strip() != '', '자료집 글 닻의 제목을 낸다',
           ref_name(conn, _a2, 'KO'))
        ck(ref_name(conn, 'USER_REF:99999999', 'KO') == '',
           '없는 번호면 빈 글(지어내지 않는다)')
        _m1 = materials_ref(conn, _a1, 'KO')
        ck(_m1.get('연구자료') and _m1.get('갈래') == '내 연구자료',
           '★ 재료 — 제목·갈래', list(_m1))
        _m2 = materials_ref(conn, _a2, 'KO')
        ck((_m2.get('본문') or '').strip() != '',
           '★★★ 문답 자료집도 본문이 든다(sys_ref_text 가 0행이어도)',
           len(_m2.get('본문', '')))
        ck(materials_ref(conn, 'NOPE:1', 'KO') == {},
           '모르는 닻이면 빈 재료(조용히 지어내지 않는다)')
        _long = 'ㄱ' * (REF_BODY_MAX + 500)
        ck(len(_long) > REF_BODY_MAX, '재료 상한이 있다')
        ck(_PH_REF and fill_prompt(conn, '[연구자료] 를 봐 주세요', 'REF',
                                   ref_anchor=_a1, lang='KO').startswith(ref_name(conn, _a1, 'KO')),
           '★ 프롬프트의 [연구자료] 자리가 제목으로 채워진다')
        _cid3 = None
        try:
            _cid3 = new_chat(conn, lang='KO', kind='REF_ASK', ref_anchor=_a1)
            _ch3 = chat(conn, _cid3)
            ck(_ch3['scope'] == 'REF' and _ch3['ref_anchor'] == _a1
               and _ch3['title'] == ref_name(conn, _a1, 'KO'),
               '★★★ 연구자료 닻 대화(scope REF · 제목이 그 자료 이름)')
            ck(_cid3 in [x[0] for x in chats_for(conn, ref_anchor=_a1)]
               and _cid3 not in [x[0] for x in chats_for(conn, ref_anchor=_a2)],
               '★ 그 자료의 목록에만 뜬다')
            _sys3 = system_text(conn, _ch3, '')
            ck(ref_name(conn, _a1, 'KO') in _sys3, '시스템 글에 연구자료 재료가 든다')
            # ── 「내 자료」 제목 규칙 ─────────────────────────────
            ck(default_ref_title(conn, _cid3, 'KO') == ref_name(conn, _a1, 'KO'),
               '★ 신규 저장 기본 제목 = 닻 이름')
            add_msg(conn, _cid3, 'user', '물음')
            add_msg(conn, _cid3, 'ai', '답')
            _r1 = save_as_ref(conn, _cid3, lang='KO', title='내가 붙인 제목')
            ck(_r1 and ref_title(conn, _r1) == '내가 붙인 제목',
               '★★★ 사람이 준 제목으로 담는다', ref_title(conn, _r1) if _r1 else None)
            _r2 = save_as_ref(conn, _cid3, lang='KO')
            ck(_r2 == _r1 and ref_title(conn, _r2) == '내가 붙인 제목',
               '★★★ 두 번째 저장이 그 제목을 안 덮는다(한 편 그대로)',
               (_r1, _r2, ref_title(conn, _r2) if _r2 else None))
            _r3 = save_as_ref(conn, _cid3, lang='KO', title='고친 제목')
            ck(_r3 == _r1 and ref_title(conn, _r3) == '고친 제목',
               '★ 새 제목을 주면 바꾼다')
            if _r1:
                conn.execute("DELETE FROM user_ref_text WHERE ref_id=?", (_r1,))
                conn.execute("DELETE FROM user_ref_asset WHERE ref_id=?", (_r1,))
        finally:
            if _cid3:
                conn.execute("DELETE FROM user_ai_msg WHERE chat_id=?", (_cid3,))
                conn.execute("DELETE FROM user_ai_chat WHERE chat_id=?", (_cid3,))
            conn.commit()
    # ★★★ 314차 — **저장 경로가 실제로 연결을 거는가**
    #   ⚠⚠ `link_verses` 를 직접 불러 재면 **`save_as_ref` 가 그 문을 쓰는지**
    #     모른다(§239차 그 자리 — 탐지력이 이 구멍을 찾았다). 그래서 **저장
    #     문을 불러** 연결이 생기는지 본다.
    _cid4 = _r4 = None
    try:
        import db_user_ref_schema as _U4
        _cid4 = new_chat(conn, lang='KO', kind='ASK')
        add_msg(conn, _cid4, 'user', '물음')
        add_msg(conn, _cid4, 'ai', '신 15:4 와 마 7:7 을 함께 봅니다.')
        _r4 = save_as_ref(conn, _cid4, lang='KO', title='연결 시험')
        _lk4 = [l for l in _U4.fetch_links(conn, _r4) if l[0] == 'VERSE'] \
            if _r4 else []
        ck(len(_lk4) == 2,
           '★★★ [연구자료 저장]이 구절을 자동으로 연결하지 않는다 — %d건'
           % len(_lk4))
        #   ★ 두 번 저장해도 안 는다(같은 글)
        save_as_ref(conn, _cid4, lang='KO')
        _lk5 = [l for l in _U4.fetch_links(conn, _r4) if l[0] == 'VERSE'] \
            if _r4 else []
        ck(len(_lk5) == 2, '두 번 저장하면 연결이 는다 — %d건' % len(_lk5))
        #   ★★★ **덮어쓰기 경로** — 대화를 더 하고 다시 저장하면 새 구절이
        #     붙어야 한다(한 대화에 한 자료라 둘째부터 UPDATE 로 간다).
        #     ⚠ 이 항목이 없으면 그 경로의 자동 연결을 걷어도 통과한다
        #       (탐지력이 그 구멍을 찾았다).
        add_msg(conn, _cid4, 'user', '더 묻기')
        add_msg(conn, _cid4, 'ai', '창 1:1 도 함께 보십시오.')
        save_as_ref(conn, _cid4, lang='KO')
        _lk6 = [l for l in _U4.fetch_links(conn, _r4) if l[0] == 'VERSE'] \
            if _r4 else []
        ck(len(_lk6) == 3,
           '★★★ 대화를 더 하고 다시 저장했는데 새 구절이 안 붙는다 — %d건'
           % len(_lk6))
    finally:
        if _r4:
            conn.execute("DELETE FROM userdb.user_link_asset WHERE clicked_id=?",
                         (_r4,))
            conn.execute("DELETE FROM user_ref_text WHERE ref_id=?", (_r4,))
            conn.execute("DELETE FROM user_ref_asset WHERE ref_id=?", (_r4,))
        if _cid4:
            conn.execute("DELETE FROM user_ai_msg WHERE chat_id=?", (_cid4,))
            conn.execute("DELETE FROM user_ai_chat WHERE chat_id=?", (_cid4,))
        conn.commit()

    # 성격 옮기기 — 제 것을 만들어 재고 걷는다(§0-5 재료가 없으면 만들어서)
    _gp = add_prompt(conn, 'KO', 'VERSE', '성격 시험', '몸', genre='CHAT')
    try:
        ck([p[4] for p in prompts(conn, 'KO', 'VERSE') if p[0] == _gp] == ['CHAT'],
           '새 프롬프트는 준 성격으로 생긴다')
        ck(set_genre(conn, _gp, 'ANAL')
           and [p[4] for p in prompts(conn, 'KO', 'VERSE') if p[0] == _gp] == ['ANAL'],
           '★ 성격을 옮긴다')
        ck(not set_genre(conn, _gp, 'NOPE')
           and [p[4] for p in prompts(conn, 'KO', 'VERSE') if p[0] == _gp] == ['ANAL'],
           '★ 모르는 성격값은 안 적는다(화면이 거짓말하지 않게)')
        save_prompt(conn, _gp, '이름', '몸2')
        ck([p[4] for p in prompts(conn, 'KO', 'VERSE') if p[0] == _gp] == ['ANAL'],
           '이름·본문만 저장하면 성격은 그대로')
    finally:
        conn.execute("DELETE FROM user_ai_prompt WHERE prompt_id=?", (_gp,))
        conn.commit()
    ck(SEED_SCOPE.get('REF_HELP') == 'REF' and GENRE_OF.get('REF_HELP') == 'ANAL',
       '연구자료 씨앗 — 갈래 REF · 성격 분석형')
    ck(len(SEED_REF['REF_HELP']) == 11 and len(SEED_REF['REF_ASK']) == 11,
       '★ 연구자료 씨앗 둘이 11언어', (len(SEED_REF['REF_HELP']), len(SEED_REF['REF_ASK'])))
    ck(all('[' in b for _t, b in SEED_REF['REF_HELP'].values()),
       '연구자료 씨앗마다 닻 자리표가 있다')
    # ★★★ 317차-8 — AI 마다 갈라지는 줄기 · 모든 AI 통합 · AI 자체 통합
    #   ⚠ 계정은 **가짜로 갈아 끼운다**(user_config 를 안 건드린다 — 끝의 행수 불변 검사)
    _acc0 = globals()['accounts']
    _cid = None
    try:
        globals()['accounts'] = lambda c: [{'provider': 'GEMINI', 'model': 'g1', 'key': 'K', 'on': 1},
                                           {'provider': 'OPENAI', 'model': 'o1', 'key': 'K', 'on': 1}]
        _seen = []

        def _fk(provider, key, model, messages, system='', **kw):
            _seen.append((model, [b for _r, b in messages]))
            return {'ok': True, 'text': '%s:%d' % (model, len(messages)), 'tokens': {}}
        _cid = new_chat(conn, lang='KO', kind='', free=True)
        send(conn, _cid, '첫 물음', _call=_fk)
        ck(len(last_answers(conn, _cid)) == 2, '첫 물음은 두 AI 모두에게 · 답 둘')
        kg, ko = acct_key('GEMINI', 'g1'), acct_key('OPENAI', 'o1')
        _seen.clear()
        send(conn, _cid, 'g1 에게만 후속', _call=_fk, only=[kg])
        ck([m for m, _b in _seen] == ['g1'], '★★★ 후속 물음은 그 AI 에게만', _seen)
        ck(_seen and _seen[0][1] == ['첫 물음', 'g1:1', 'g1 에게만 후속'],
           '★★★ 그 AI 줄기 = 첫 물음 + 제 답 + 제 후속(남의 답 없음)', _seen)
        _seen.clear()
        send(conn, _cid, 'o1 에게만', _call=_fk, only=[ko])
        ck(_seen and _seen[0][1] == ['첫 물음', 'o1:1', 'o1 에게만'],
           '★★★ 다른 AI 에게는 g1 의 후속이 안 간다', _seen)
        ck([r for r, _b in thread_of(conn, _cid, kg)] == ['user', 'ai', 'user', 'ai'], 'g1 줄기 넷')
        ck(first_question(conn, _cid) == '첫 물음', '첫 프롬프트를 읽는다')
        _seen.clear()
        r = integrate(conn, _cid, kg, _call=_fk)
        _ib = _seen[0][1][0] if _seen else ''
        ck(r.get('ok') and '[답 A]' in _ib and '[답 B]' in _ib and 'g1' not in _ib.split('[답 A]')[0][-20:]
           and '확인 불가' in _ib and '이 답에 이어진 물음' in _ib,
           '★★★ 통합 — 답 이름을 가리고 · 후속 물음 요지 · 확인 불가 칸 지시', _ib[-200:])
        li = latest_integ(conn, _cid)
        ck(li and li['model'] == 'g1' and 'A=' in li['map'] and 'B=' in li['map'], '통합본은 INTEG 로 · 가린 이름 짝', li)
        ck(len(last_answers(conn, _cid)) == 1 and last_answer(conn, _cid) == 'o1:3',
           '★ 통합본은 「답」으로 안 센다(마지막 답 · 마지막 답들)')
        _seen.clear()
        r = self_merge(conn, _cid, ko, _call=_fk)
        ck(r.get('ok') and _seen and _seen[0][0] == 'o1' and len(_seen[0][1]) == 5,
           '★★ 자체 통합 — 그 AI 줄기 + 「한 글로」 지시를 그 AI 에게', _seen)
        ck(latest_of(conn, _cid, ko)[1] == 'SELF', '그 AI 칸에는 더 늦은 자체 통합본이 보인다')
        _seen.clear()
        send(conn, _cid, 'o1 다시', _call=_fk, only=[ko])
        ck(_seen and not any(':5' in b for b in _seen[0][1]), '★ 통합본은 다음 대화에 안 실린다', _seen)
        st = chat_state(conn, _cid)
        ck(st['integ'] and st['selfs'] == 1 and len(st['ais']) == 2, '상태 한 줄 재료', st)
    finally:
        globals()['accounts'] = _acc0
        if _cid:
            conn.execute("DELETE FROM user_ai_msg WHERE chat_id=?", (_cid,))
            conn.execute("DELETE FROM user_ai_chat WHERE chat_id=?", (_cid,))
            conn.commit()
    # ── 2026-10-15 답 검증 ──────────────────────────────────────────────
    _acc = {'provider': 'GEMINI', 'model': 'g', 'key': 'k'}
    _A = ('하나님께서 아브람을 부르셨습니다. 이 해석은 수종장로교 전통에서 강조되어 왔습니다. '
          '그는 하나닙을 믿었습니다. 바울은 롬 16:85에서 이것을 다시 말합니다. 그래서 우리는 감사합니다.')
    _B = ('하나님께서 아브람을 부르셨습니다. 그는 하나님을 믿었습니다. 바울은 롬 16:85에서 이것을 다시 말합니다. '
          '그래서 우리는 감사한다.')
    _seen = {}

    def _vfake(p, k, m_, msgs_, system='', max_out=0):
        _seen['sys'] = system
        _seen['user'] = msgs_[0][1]
        return {'ok': True, 'text': _B.replace(' 바울은 롬 16:85에서 이것을 다시 말합니다.', ''), 'tokens': {}}
    _v = verify_answer(conn, _acc, _A, '설명해 주세요', '[본문] 창 12:1', 'KO', fn=_vfake)
    ck(_v['state'] == 'OK' and '수종장로교' not in _v['text'] and '하나님을 믿었' in _v['text'],
       '★ 검증 — 지어낸 이름 문장을 빼고 오탈자를 고친다', _v)
    ck('16:85' in ''.join(_v['refs']) and '16:85' not in _seen['user'] and '16:85' not in _v['text'],
       '★ 검증 — 없는 장·절은 기계가 먼저 빼고 AI 에게 보내지 않는다', _v['refs'])
    ck(_v['text'].rstrip().endswith('감사합니다.'), '★ 검증 — 어미 바꾸기(합니다→한다)는 안 받는다', _v['text'][-20:])
    ck(_seen['sys'] == VERIFY_PROMPT['KO'] and '[재료]' in _seen['user'] and '[질문]' in _seen['user'],
       '검증 요청 꼴 — 교정 지시 + 재료·질문·답')
    _vb = verify_answer(conn, _acc, _A, '', '', 'KO',
                        fn=lambda *a, **k: {'ok': False, 'text': '', 'why': 'HTTP 429', 'tokens': {}})
    ck(_vb['state'] == 'FAIL' and _vb['text'] == _A, '★ 검증 못 하면 FAIL · 원래 답을 그대로 낸다')
    _vd = verify_answer(conn, _acc, _A, '', '', 'KO',
                        fn=lambda *a, **k: {'ok': True, 'text': '전혀 다른 글입니다.', 'tokens': {}})
    ck(_vd['state'] == 'FAIL', '★ 다시 쓴 글이 원래 답과 너무 다르면 받지 않는다(FAIL)')
    ck(verify_answer(conn, _acc, '짧은 답', fn=_vfake)['state'] == 'SKIP', '짧은 답은 검증하지 않는다')
    _g, _tk, _dr = verify_guard('훗날 여호수아가 언약을 새롭게 했습니다(수 24장). 끝입니다.', '끝입니다.',
                                veto=lambda s_: '수 24장' in s_)
    ck('수 24장' in _g, '★ 맞는 구절이 든 문장은 지우지 않는다(veto)')
    _raw_v = get_setting(conn, 'AI_ACCOUNTS', None)
    _had_v = conn.execute("SELECT 1 FROM user_config WHERE config_key='AI_ACCOUNTS'").fetchone() is not None
    _cv = new_chat(conn, lang='KO', free=True)
    try:
        set_accounts(conn, [{'provider': 'GEMINI', 'model': 'g', 'key': 'k', 'on': 1}])
        _ans = lambda *a, **k: {'ok': True, 'text': _A, 'tokens': {}}
        _calls = []

        def _two(p, k, m_, msgs_, system='', max_out=0):
            _calls.append(system)
            if system == VERIFY_PROMPT['KO']:
                return {'ok': False, 'text': '', 'why': 'HTTP 429', 'tokens': {}}
            return {'ok': True, 'text': _A, 'tokens': {}}
        r = send(conn, _cv, '설명해 주세요', _call=_two, verify=True)
        _m = [m for m in msg_rows(conn, _cv) if m['role'] == 'ai'][-1]
        ck(r['ok'] and _m['verify'] == 'FAIL' and _m['body'] == _A and len(_calls) == 2,
           '★ send — 답을 받고 같은 AI 로 검증한다 · 못 하면 원본을 FAIL 로 담는다', (_m['verify'], len(_calls)))
        r = send(conn, _cv, '또', _call=_ans)
        ck([m for m in msg_rows(conn, _cv) if m['role'] == 'ai'][-1]['verify'] == '',
           '시험용 가짜 call 은 따로 켜지 않으면 검증을 건너뛴다')
        _rv = reverify(conn, _m['msg_id'], _call=_vfake)
        _m2 = [m for m in msg_rows(conn, _cv) if m['msg_id'] == _m['msg_id']][0]
        ck(_rv['state'] == 'OK' and _m2['verify'] == 'OK' and '수종장로교' not in _m2['body']
           and conn.execute("SELECT raw FROM user_ai_msg WHERE msg_id=?", (_m['msg_id'],)).fetchone()[0] == _A,
           '★ [다시 검증] — 원본을 다시 검증해 완성본으로 바꾸고 원본은 raw 에 남긴다')
    finally:
        conn.execute("DELETE FROM user_ai_msg WHERE chat_id=?", (_cv,))
        conn.execute("DELETE FROM user_ai_chat WHERE chat_id=?", (_cv,))
        if _had_v:
            set_setting(conn, 'AI_ACCOUNTS', _raw_v or '')
        else:
            conn.execute("DELETE FROM user_config WHERE config_key='AI_ACCOUNTS'")
        conn.commit()
    # ── 이어서 묻기(2026-10-16) ──
    _b, _qs = split_next('본문입니다.\n둘째 줄.\n\n▷ 1. 첫 물음?\n▷ 둘째 물음?\n▷ - 셋째 물음?\n▷ 넷째 물음?')
    ck(_b == '본문입니다.\n둘째 줄.' and _qs == ['둘째 물음?', '셋째 물음?', '넷째 물음?'],
       '★ 이어서 — ▷ 줄을 떼고 앞 번호를 걷는다(마지막 셋)', (_b, _qs))
    ck(split_next('없는 답')[1] == [] and strip_next('그냥 답') == '그냥 답', '▷ 없으면 제안 없음 · 본문 그대로')
    ck(number_pick('2', ['가', '나', '다']) == '나' and number_pick(' 3. ', ['가', '나', '다']) == '다'
       and number_pick('2', ['가']) is None and number_pick('12', ['가', '나']) is None
       and number_pick('2번 말고', ['가', '나']) is None, '★ 이어서 — 숫자 하나만 적으면 그 제안 질문')
    _fi = follow_items('KO')
    ck(set(_fi) == set(FOLLOW_GROUPS) and len(_fi['TURN']) == 6 and len(_fi['DEEP']) == 5,
       '이어서 묻기 갈래 둘 × 넷')
    # ★ 2026-10-20 새 준비된 질문은 한국어·영어 먼저(사용자 「한국어 프롬프트를 시험해 확정한 뒤 다국어」) — 없으면 영어로 물러선다
    ck(all('KO' in d and 'EN' in d for g in FOLLOW.values() for _k, d in g) and len(NEXT_RULE) == 11
       and all(len(follow_items(L)['TURN']) == len(FOLLOW['TURN']) for L in NEXT_RULE),
       '★ 이어서 묻기 글(한국어·영어 · 그 밖은 영어로) · 제안 규칙 — 11언어')
    ck(follow_items('XX')['TURN'][0][1] == FOLLOW['TURN'][0][1]['EN'][0], '모르는 언어는 영어로')
    _raw_f = get_setting(conn, 'AI_ACCOUNTS', None)
    _had_f = conn.execute("SELECT 1 FROM user_config WHERE config_key='AI_ACCOUNTS'").fetchone() is not None
    _v5 = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=1 AND chapter=1 AND verse=5").fetchone()[0]
    _n0 = verse_chat_count(conn, _v5)
    _cf = new_chat(conn, _v5, _v5, 'KO')
    _cg = new_chat(conn, _v5 - 2, _v5 + 1, 'KO')
    _ce = new_chat(conn, _v5, _v5, 'KO')                      # 빈 채팅(안 보냄) — 안 센다
    _ct = new_chat(conn, _v5, _v5, 'KO', kind='T:TEACH')
    try:
        set_accounts(conn, [{'provider': 'GEMINI', 'model': 'g', 'key': 'k', 'on': 1}])
        _sys = []

        def _fake_next(p, k, m_, msgs_, system='', max_out=0):
            _sys.append(system)
            return {'ok': True, 'tokens': {}, 'text': '설명입니다.\n▷ 다음 물음?'}
        send(conn, _cf, '설명해 주세요', _call=_fake_next)
        send(conn, _cg, '설명해 주세요', _call=_fake_next)
        ck(next_rule('KO') in _sys[0], '★ 이어서 — 보통 업무는 시스템 글 끝에 제안 질문 규칙', _sys[0][-80:])
        send(conn, _ct, '네', _call=_fake_next)
        ck(next_rule('KO') not in _sys[-1], '성경교사는 제안 질문 규칙을 안 붙인다(AI 가 묻는 쪽)')
        _ids = [r[0] for r in chats_covering(conn, _v5)]
        ck(_cf in _ids and _cg in _ids and _ce not in _ids and verse_chat_count(conn, _v5) == _n0 + 3,
           '★ AI 배지 — 그 절을 덮는 채팅(구간 포함 · 빈 채팅 빼고) 수', (_n0, verse_chat_count(conn, _v5)))
        _mt = merge_text(conn, _cf)
        ck('▷' not in _mt and '설명입니다.' in _mt, '연구자료로 담을 글에는 제안 질문 줄이 없다')
        _calls_v = []

        def _vf(p, k, m_, msgs_, system='', max_out=0):
            if system == VERIFY_PROMPT['KO']:
                _calls_v.append(msgs_[-1][1])
                return {'ok': True, 'tokens': {}, 'text': '하나님께서 첫째 날에 빛을 만드셨습니다. 그 빛이 보시기에 좋았습니다. 그래서 우리는 그 빛을 보며 감사합니다.'}
            return {'ok': True, 'tokens': {},
                    'text': '하나님께서 첫째 날에 빛을 만드셨습니다. 그 빛이 보시기에 좋았습니다. 그래서 우리는 그 빛을 보며 감사합니다.\n\n▷ 빛은 무엇입니까?\n▷ 왜 좋았습니까?'}
        send(conn, _cf, '또', _call=_vf, verify=True)
        _lm = [m for m in msg_rows(conn, _cf) if m['role'] == 'ai'][-1]
        ck(_calls_v and '▷' not in _calls_v[0] and split_next(_lm['body'])[1] == ['빛은 무엇입니까?', '왜 좋았습니까?']
           and _lm['verify'] == 'OK', '★ 검증 — 제안 질문 줄은 검증에 안 보내고 그대로 다시 붙인다', _lm['body'][-40:])
    finally:
        for _c in (_cf, _cg, _ce, _ct):
            conn.execute("DELETE FROM user_ai_msg WHERE chat_id=?", (_c,))
            conn.execute("DELETE FROM user_ai_chat WHERE chat_id=?", (_c,))
        if _had_f:
            set_setting(conn, 'AI_ACCOUNTS', _raw_f or '')
        else:
            conn.execute("DELETE FROM user_config WHERE config_key='AI_ACCOUNTS'")
        conn.commit()
    _pbf = phone_bundle(conn, 'KO')
    ck(_pbf.get('next_rule') == next_rule('KO') and len(_pbf.get('follow', {}).get('TURN', [])) == len(FOLLOW['TURN']),
       '폰 꾸러미 — 이어서 묻기 갈래 · 제안 질문 규칙')
    # ── 마크다운 걷기(2026-10-24) ──
    _md = strip_md('### 1. [배경]'+NL+'**요한**이 쓴 *복음*'+NL+'---'+NL+'- 첫째'+NL+'> 인용'+NL+'`코드` [링크](https://a.com/x)'+NL+'[[V]] 요 3:16 | 까닭'+NL+'▷ 다음')
    ck(_md == '1. [배경]'+NL+'요한이 쓴 복음'+NL+'· 첫째'+NL+'인용'+NL+'코드 링크 (https://a.com/x)'+NL+'[[V]] 요 3:16 | 까닭'+NL+'▷ 다음', '마크다운 기호를 걷는다(표·기도 표시·▷ 는 그대로)', repr(_md))
    # ── 항목별로 나누어 답하기(2026-10-24) ──
    ck(each_block(['가'], 'KO') == '가', '항목 하나면 규칙을 안 붙인다')
    _eb = each_block([('배경', '가'), ('원어', '나')], 'KO')
    ck(_eb == '1. [배경] 가' + NL + '2. [원어] 나' + NL + pick_each('KO'), '둘 이상이면 번호·이름 + 항목별 규칙', _eb)
    ck(each_block(['가', '나'], 'EN').endswith(PICK_EACH['EN']) and '1. 가' in each_block(['가', '나'], 'EN'),
       '이름 없는 옛 호출부도 번호 + 규칙')
    ck(len(PICK_EACH) == 11 and _pbf.get('pick_each') == pick_each('KO'), '11언어 · 폰 꾸러미에 실린다')
    _cp = compose(conn, None, '', 'KO', role='R', task='T', picks=[('배경', '가'), ('원어', '나')], fmt='')
    ck(pick_each('KO') in _cp and '[배경] 가' in _cp, '보낼 글의 Pick 칸에 이름과 규칙이 든다')
    # ── 검증 모드(2026-10-16) ──
    _raw_m = get_setting(conn, VERIFY_MODE_KEY, None)
    _had_m = conn.execute("SELECT 1 FROM user_config WHERE config_key=?", (VERIFY_MODE_KEY,)).fetchone() is not None
    _raw_a2 = get_setting(conn, 'AI_ACCOUNTS', None)
    _had_a2 = conn.execute("SELECT 1 FROM user_config WHERE config_key='AI_ACCOUNTS'").fetchone() is not None
    _cm = new_chat(conn, lang='KO', free=True)
    try:
        conn.execute("DELETE FROM user_config WHERE config_key=?", (VERIFY_MODE_KEY,))
        ck(verify_mode(conn) == 'SAVE', '★ 검증 모드 — 기본은 「저장/공유할 때」')
        ck(_v_on(conn, None, None) is False and _v_on(conn, _vfake, None) is False
           and _v_on(conn, _vfake, True) is True, '저장/공유 모드 — 받을 때는 검증 안 함 · 명시하면 함')
        set_verify_mode(conn, 'ALWAYS')
        ck(_v_on(conn, None, None) is True and _v_on(conn, _vfake, None) is False,
           '항상검증 — 받을 때 검증(시험용 가짜 call 은 여전히 끔)')
        set_verify_mode(conn, 'OFF')
        ck(verify_mode(conn) == 'OFF' and _v_on(conn, None, None) is False, '검증 없이')
        try:
            set_verify_mode(conn, 'XX')
            ck(False, '모르는 모드는 거부')
        except ValueError:
            ck(True, '모르는 모드는 거부')
        _mt = '하나님께서 빛을 만드셨습니다. 이것은 롬 16:85에 적혀 있습니다. 그래서 감사합니다.\n\n▷ 빛은?'
        _md, _mb = machine_drop(conn, _mt, 'KO')
        ck('16:85' in ''.join(_mb) and '16:85' not in _md and _md.endswith('▷ 빛은?') and '감사합니다.' in _md,
           '★ 기계 검사 — 없는 장·절 문장만 걷고 ▷ 줄은 남긴다(AI 안 부름)', _md)
        set_accounts(conn, [{'provider': 'GEMINI', 'model': 'g', 'key': 'k', 'on': 1}])
        add_msg(conn, _cm, 'user', '설명해 주세요')
        add_msg(conn, _cm, 'ai', _A, provider='GEMINI', model='g')
        add_msg(conn, _cm, 'ai', '짧은 답', provider='GEMINI', model='g', verify='OK')
        _ids0 = unverified_ids(conn, _cm)
        ck(len(_ids0) == 1, '검증 안 된 답만 고른다(이미 OK 는 건너뜀)', _ids0)
        _ev = ensure_verified(conn, _cm, _call=_vfake)
        _b2 = conn.execute("SELECT body, verify FROM user_ai_msg WHERE msg_id=?", (_ids0[0],)).fetchone()
        ck(_ev['checked'] == 1 and _ev['changed'] == _ids0 and not _ev['failed']
           and _b2[1] == 'OK' and '수종장로교' not in _b2[0],
           '★ 저장 전 검증 — 고친 답을 완성본으로 바꾸고 바뀐 것을 알린다', _ev)
        ck(ensure_verified(conn, _cm, _call=_vfake)['checked'] == 0, '★ 두 번째는 부르지 않는다(이미 검증함)')
        add_msg(conn, _cm, 'ai', _A, provider='GEMINI', model='g')
        _ef = ensure_verified(conn, _cm, _call=lambda *a, **k: {'ok': False, 'text': '', 'why': 'HTTP 429', 'tokens': {}})
        ck(len(_ef['failed']) == 1, '검증 못 하면 failed 로 알린다(화면이 묻는다)')
    finally:
        conn.execute("DELETE FROM user_ai_msg WHERE chat_id=?", (_cm,))
        conn.execute("DELETE FROM user_ai_chat WHERE chat_id=?", (_cm,))
        if _had_m:
            set_setting(conn, VERIFY_MODE_KEY, _raw_m or '')
        else:
            conn.execute("DELETE FROM user_config WHERE config_key=?", (VERIFY_MODE_KEY,))
        if _had_a2:
            set_setting(conn, 'AI_ACCOUNTS', _raw_a2 or '')
        else:
            conn.execute("DELETE FROM user_config WHERE config_key='AI_ACCOUNTS'")
        conn.commit()
    # ── 폰 AI 꾸러미(317차-30 ④) — 폰이 채운 글 = PC 가 보낼 글 ──
    pb = phone_bundle(conn, 'KO')
    ck(pb['tasks'] and pb['guard'] and pb['integ'] and pb['free']['prompt'], '폰 꾸러미 — 업무·지침·통합·Free', pb.keys())
    ck(pb.get('merge') == merge_prompt_body(conn, 'KO'), '폰 꾸러미 — 「한 글로」 지시 = PC 단추가 쓰는 글')
    ck(not any(t['task'] in PHONE_SKIP for t in pb['tasks']), '폰 꾸러미 — 묵상노트 분석은 없다')
    ck(not any(a.get('key') and a['key'] in json.dumps(pb, ensure_ascii=False) for a in accounts(conn)),
       '★ 폰 꾸러미에 AI 키가 없다')
    _v3 = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=1 AND chapter=1 AND verse=3").fetchone()[0]
    # ★ 2026-10-14 설명문 업무는 설명 판 [AI 분석](analyze DESC)으로 옮겼다 — 같은 잣대로 잰다(검사 수가 줄지 않게)
    ck([t['task'] for t in pb['analyze'].get('DESC', [])] == ['DESC', 'XDESC']
       and not any(t['task'] in ('DESC', 'XDESC') for t in pb['tasks']),
       '★ 폰 — 설명문 업무는 구절 [AI] 에 없고 설명 판 [AI 분석] 에만', [t['task'] for t in pb['tasks']])
    for _t in pb['tasks'] + pb['analyze'].get('DESC', []):
        _m = _t['mode'] or None
        _role, _task = task_texts(conn, 'VERSE', _t['task'], _m, 'KO')
        _pk = _picks_of(conn, _t['id'])
        _fi = task_fmt_index(conn, _t['task'], 'KO')        # ★ 2026-10-16 업무별 출력서식
        _fm = (part_sets(conn, 'FORMAT')['items'][_fi].get('body') or '').strip() if _fi is not None else None
        ck(_t.get('fmt', -1) == (_fi if _fi is not None else -1), '폰 꾸러미 — 업무의 서식 번호 (%s)' % _t['id'])
        for _q in ('', '왜 빛이 먼저인가?'):
            want = fill_prompt(conn, compose(conn, None, _q, 'KO', role=_role, task=_task, picks=_pk, fmt=_fm),
                               'VERSE', _v3, _v3, lang='KO')
            got = fill_version(conn, phone_fill(pb, _t, _q, range_label(conn, _v3, _v3, 'KO')))  # 폰도 보낼 때 [성경버전]을 채운다
            ck(want == got, '★ 폰이 채운 글 = PC compose (%s · 물음 %s)' % (_t['id'], bool(_q)))
    ck(pb['q'] not in phone_fill(pb, pb['tasks'][0], '', '창 1:3'), '물음 없으면 표식이 안 남는다')
    ck(all(len(pb['axes'][a]['items']) >= 2 for a in ('STATE', 'FAITH', 'VIEW')), '폰 꾸러미 — 축 셋의 항목')
    for _t in pb['tasks'] + pb['analyze'].get('DESC', []):
        _m = _t['mode'] or None
        _role, _task = task_texts(conn, 'VERSE', _t['task'], _m, 'KO')
        _pk = [x['body'] for x in _t['picks'][:2]]
        _fi = task_fmt_index(conn, _t['task'], 'KO')
        _fm = (part_sets(conn, 'FORMAT')['items'][_fi].get('body') or '').strip() if _fi is not None else None
        _ax = {a: pb['axes'][a]['items'][1][0] for a in ('STATE', 'FAITH', 'VIEW')}
        _ab = [next(b for k, _tt, b in pb['axes'][a]['items'] if k == _ax[a]) for a in ('STATE', 'FAITH', 'VIEW')]
        for _q in ('', '왜?'):
            want = fill_prompt(conn, compose(conn, None, _q, 'KO', role=_role, task=_task, picks=_pk,
                                             state=_ax['STATE'], faith=_ax['FAITH'], view=_ax['VIEW'], fmt=_fm),
                               'VERSE', _v3, _v3, lang='KO')
            sl = _t['slots_q'] if _q else _t['slots']
            got = fill_version(conn, phone_compose(sl, [fill_teach_n(x, teach_n(conn)) for x in _pk], _ab).replace(pb['q'], _q))  # 폰도 보내기 전에 질문 횟수를 채운다
            for tok in pb['ph']:
                got = got.replace(tok, range_label(conn, _v3, _v3, 'KO'))
            ck(want == got, '★ 폰이 선택한 Pick·축으로 이은 글 = PC compose (%s · 물음 %s)' % (_t['id'], bool(_q)))
    # ★ 2026-10-20 [성경버전] 자리표 — 설정한 역본 이름으로 · 폰 꾸러미 글은 자리표를 남긴다(폰이 채운다)
    _vl0 = globals()['version_label']
    globals()['version_label'] = lambda c: '개역한글 (KRV)'
    try:
        ck(fill_version(conn, '[성경버전]으로 인용하세요') == '개역한글 (KRV)으로 인용하세요'
           and compose(conn, None, '[성경버전]?', 'KO', with_axes=False).count('개역한글 (KRV)') >= 1
           and '[성경버전]' in compose(conn, None, '[성경버전]?', 'KO', with_axes=False, keep_version=True),
           '★ [성경버전] 자리표 — 보낼 글은 설정 역본으로 · 폰 꾸러미는 자리표 그대로')
        import datetime as _dt
        ck(date_label('KO', _dt.date(2026, 10, 21)) == '2026년 10월 21일 (수)'
           and date_label('EN', _dt.date(2026, 10, 21)) == 'Wednesday, October 21, 2026'
           and date_label('JA', _dt.date(2026, 10, 21)) == '2026年10月21日（水）'
           and fill_version(conn, '오늘은 [오늘]', 'KO') == '오늘은 ' + date_label('KO'),
           '★ [오늘] 자리표 — 그 언어 날짜 · 요일')
        ck(fill_version(conn, '[국가] 사회', 'KO') == ((get_setting(conn, 'AI_COUNTRY', '') or '').strip() or '대한민국') + ' 사회'
           and fill_version(conn, '[Country]', 'JA') in ('日本', (get_setting(conn, 'AI_COUNTRY', '') or '').strip())
           and set(COUNTRY_OF) >= {'KO', 'EN', 'JA', 'ZH', 'ZHT', 'DE', 'FR', 'ES', 'PT', 'RU', 'AR'},
           '★ [국가] 자리표 — 그 사용자 언어의 나라(11언어) · AI_COUNTRY 가 이긴다')
    finally:
        globals()['version_label'] = _vl0
    # ★ 2026-10-21 잘린 답 — 세 회사 「다 못 썼다」 표시를 읽고 글 끝에 알린다 · 통합은 한도를 넉넉히
    _cuts = [_parse('GEMINI', json.dumps({'candidates': [{'content': {'parts': [{'text': 'a'}]}, 'finishReason': 'MAX_TOKENS'}]}))[1].get('cut'),
             _parse('ANTHROPIC', json.dumps({'content': [{'type': 'text', 'text': 'a'}], 'stop_reason': 'max_tokens'}))[1].get('cut'),
             _parse('OPENAI', json.dumps({'choices': [{'message': {'content': 'a'}, 'finish_reason': 'length'}]}))[1].get('cut'),
             _parse('GEMINI', json.dumps({'candidates': [{'content': {'parts': [{'text': 'a'}]}, 'finishReason': 'STOP'}]}))[1].get('cut')]
    ck(_cuts == [True, True, True, False] and CUT_NOTE['KO'] in _cut_note('a', {'tokens': {'cut': True}}, 'KO')
       and _cut_note('a', {'tokens': {}}, 'KO') == 'a' and MERGE_OUT >= 8192,
       '★★ 잘린 답을 알아보고 글 끝에 알린다 · 통합 한도 8192', _cuts)
    sys_after = [conn.execute("SELECT COUNT(*) FROM %s" % t).fetchone()[0]
                 for t in ('sys_text_asset', 'sys_link_asset', 'sys_entity_verse', 'user_config')]
    ck(sys_before == sys_after, '★★★ sys 표·user_config 행수 불변(아무것도 안 썼다): %s → %s' % (sys_before, sys_after))
    conn.close()
    for b in bad:
        print('  FAIL', b)
    print('user_ai selftest: %s (%d/%d)' % ('OK' if not bad else 'FAIL', n[0] - len(bad), n[0]))
    return 0 if not bad else 1


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(selftest())
    print(__doc__)
