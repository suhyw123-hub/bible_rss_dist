# -*- coding: utf-8 -*-
"""db_vers_prep.py — 구약 절별자산 집필 재료 (영구 도구, §0-5 KEEP).

⚠ 원래 `temp_code_ot_prep.py` 였다. **책마다 다시 쓰는 도구에 temp_ 를 붙이면 안 된다** —
   2026-07-30 정리에서 게이트 다섯이 그 이름 때문에 통째로 `참고코드/` 로 휩쓸려
   넉 달간 실행조차 안 됐다(§0-5). 2026-08-09 승격.

한 장의 절마다 **KRV·BSB 본문 + 그 절에 걸린 주석 본문**을 한자리에 모은다.
주석 6종이 흩어져 있어 절마다 따로 캐면 배치마다 같은 질의를 되풀이하게 된다.

★ **재료만 낸다. 규격은 내지 않는다 (2026-08-12).**
   여기에 있던 `_golden()`(골든 레퍼런스 히 10:1)과 `_spec()`(절별 자수·문단 수·
   길이비 0.75·신출어휘 0.15)은 **2026-08-09 개편에서 폐기된 규격**인데 출력에만 남아
   있었다. `vers.md` 가 「폐기된 규격이 그대로 남아 있어 읽으면 헷갈린다」고 적어 둔 바로
   그것이고, 실제로 레위기 착수 때 이 출력을 읽고 LAY 를 264~297자로 묶을 뻔했다.
   ⇒ **집필 지침은 `lay.md` 하나이고 `db_vers_run.py --next` 가 그것을 출력한다.**
   재료 도구가 지침을 함께 내면 두 곳이 갈라지고, 갈라지면 오래된 쪽이 남는다.

⚠ `end_vid` 가 NULL 인 행이 많다(CLAUDE.md §8) — `start_vid=?` 를 먼저 본다.

사용:  python -X utf8 db_vers_prep.py 3 1 --vs 1-7
       python -X utf8 db_vers_prep.py 3 1 --vs 1-7 --src GILL,CLARKE --max 1800
"""
import argparse
import re
import sys

import appdb

TAG = re.compile(r'<[^>]+>')


def clean(t):
    t = TAG.sub(' ', t or '')
    return re.sub(r'[ \t]+', ' ', t).strip()


def commentaries(c, vid, srcs, maxlen):
    """이 절에 걸린 주석을 출처별로 하나씩. [(code, text), ...] 를 srcs 순서로 돌려준다.

    ⚠ 절 단위 항목을 범위 항목보다 **먼저** 집는다. GILL 은 장마다 장서론(범위)을
      갖고 있어서, 순서를 안 주면 그 한 덩어리가 그 장 모든 절에 붙는다(실제로 당했다).

    ★ 2026-08-10 main() 에서 꺼냈다 — `db_vers_run.py --next` 가 같은 재료를 쓴다.
      이 질의를 복사해 두면 한쪽만 고쳐져 어긋난다(CLAUDE.md §8-3 의 그 실패).
    """
    cq = """SELECT s.commentary_code, x.body_text,
                   CASE WHEN en.start_vid = ? THEN 0 ELSE 1 END AS pref,
                   COALESCE(en.end_vid, en.start_vid) - en.start_vid AS span
            FROM sys_commentary_entry en
            JOIN sys_commentary_source s ON s.commentary_id = en.commentary_id
            JOIN sys_commentary_text x ON x.entry_id = en.entry_id
            WHERE (en.start_vid = ? OR (en.start_vid <= ? AND en.end_vid >= ?))
              AND x.text_variant = 'ORIGINAL'
              AND COALESCE(en.record_status,'LIVE') = 'LIVE'
            ORDER BY pref, span"""
    got = {}
    for code, body, _p, _s in c.execute(cq, (vid, vid, vid, vid)):
        if code in srcs and code not in got:
            got[code] = clean(body)
    return [(code, got[code][:maxlen]) for code in srcs if code in got]


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('bcode', type=int)
    ap.add_argument('ch', type=int)
    ap.add_argument('--vs', help='1-7 또는 3')
    ap.add_argument('--src', default='GILL,CLARKE,JFB,PULPIT_COM,BARNES_OT')
    ap.add_argument('--max', type=int, default=1600, help='주석 하나당 잘라 낼 길이')
    a = ap.parse_args()
    lo, hi = 1, 999
    if a.vs:
        p = a.vs.split('-')
        lo = int(p[0]); hi = int(p[-1])
    srcs = [s.strip() for s in a.src.split(',') if s.strip()]
    c = appdb.connect()

    bn = c.execute("SELECT full_name FROM book_names WHERE book_code=? AND lang_code='KO'",
                   (a.bcode,)).fetchone()
    print('# %s %d장 %d~%d절 — 집필 재료' % (bn[0] if bn else a.bcode, a.ch, lo, hi))
    print('  집필 지침은 lay.md · python -X utf8 db_vers_run.py --next %d' % a.bcode)
    print()

    q = ("SELECT verse_id, verse FROM bible_index WHERE bcode=? AND chapter=?"
         " AND verse BETWEEN ? AND ? ORDER BY verse")
    for vid, vs in c.execute(q, (a.bcode, a.ch, lo, hi)):
        print('=' * 70)
        print('## %d:%d   vid %d' % (a.ch, vs, vid))
        for ver in ('KRV', 'BSB'):
            r = c.execute("SELECT verse_text FROM bible_content"
                          " WHERE verse_id=? AND version_code=?", (vid, ver)).fetchone()
            print('**%s** %s' % (ver, r[0] if r else ''))
        print()
        for code, t in commentaries(c, vid, srcs, a.max):
            print('--- %s (%d자) ---' % (code, len(t)))
            print(t)
            print()
        print()


if __name__ == '__main__':
    main()
