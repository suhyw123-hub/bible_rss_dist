# -*- coding: utf-8 -*-
"""ref_doc — 연구/설교노트의 **표**를 다루는 단일 문 (2026-10-07 317차-18 · docs/1.txt 41 · data.md Z-2v).

★★★ 원칙 — **저장 꼴은 우리 것(글 + 표 구조)이 정본**이다.
  · 본문에는 자리표 `[[T1]]` 만 둔다(그 글 안 표 번호 · 1부터).
  · 표는 따로 담는다 — **구조**(행·열·머리 줄 수)는 언어와 상관없이 하나, **칸 글**은 언어마다 JSON 한 줄.
  · 모양(공백 맞춤)을 저장하지 않는다 — 화면·내보내기가 **그때** 칸 폭을 계산한다.
    그래서 글꼴·크기·번역이 바뀌어도 표가 일그러지지 않는다.
  · 워드·한글·HTML·`|` 표·격자 표는 **주고받는 꼴**일 뿐이고 모두 이 모듈을 지난다
    (두 곳에서 바꾸면 갈린다).

표 넷(같은 모양 — 열쇠만 다르다):
  sys_ref_table(table_id · ref_unit_id · table_no · n_rows · n_cols · head_rows · record_status)
  sys_ref_table_text(table_id · lang_code · cells_json)
  userdb.user_ref_table(table_id · ref_id · …) · userdb.user_ref_table_text(…)

⚠ 언어 JSON 의 모양(행×열)이 구조와 다르면 **저장을 거부**한다 — 일그러진 표가 들어갈 길을 막는다.
  구조를 바꾸는 것은 `put_table(..., restructure=True)` 하나뿐이고, 그때 다른 언어의 칸은
  **자리(행·열)를 지켜** 잘라 내거나 빈칸을 채운다(빈칸은 읽을 때 기준 언어로 폴백).
⚠ 칸 합치기는 처음부터 안 한다(나중에 구조에 `span` 을 더할 수 있게만 둔다).
"""
import html
import json
import re
import sys
import unicodedata

TOKEN_RE = re.compile(r'\[\[T(\d{1,3})\]\]')
SIDES = {
    'SYS':  ('sys_ref_table', 'sys_ref_table_text', 'ref_unit_id', ''),
    'USER': ('user_ref_table', 'user_ref_table_text', 'ref_id', 'userdb.'),
}


def token(no):
    return '[[T%d]]' % int(no)


def tokens(text):
    """글 속 자리표 번호들(나온 차례)."""
    return [int(m.group(1)) for m in TOKEN_RE.finditer(text or '')]


# ══════════════════════════════════════════════════════════════════
#  표 한 개 = dict(rows, cols, head, cells)   cells = [[str]] · 칸 안 줄바꿈은 '\n'
# ══════════════════════════════════════════════════════════════════
def make(cells, head=0):
    rows = [list(map(lambda x: '' if x is None else str(x), r)) for r in (cells or [])]
    cols = max((len(r) for r in rows), default=0)
    rows = [r + [''] * (cols - len(r)) for r in rows]
    return {'rows': len(rows), 'cols': cols, 'head': max(0, min(int(head or 0), len(rows))), 'cells': rows}


def shape_ok(t, cells):
    return (isinstance(cells, list) and len(cells) == t['rows']
            and all(isinstance(r, list) and len(r) == t['cols'] for r in cells))


def reshape(cells, rows, cols):
    """칸을 새 모양으로 — 자리(행·열)를 지키고 남는 것은 자르고 모자란 것은 빈칸."""
    out = []
    for i in range(rows):
        r = cells[i] if i < len(cells or []) else []
        out.append([(r[j] if j < len(r) else '') for j in range(cols)])
    return out


# ── 글자 폭(고정폭 기준 · 한글·한자·가나 = 2칸) ─────────────────────────
def disp_width(s):
    return sum(2 if unicodedata.east_asian_width(ch) in ('W', 'F') else
               (0 if unicodedata.combining(ch) else 1) for ch in (s or ''))


def _pad(s, w):
    return s + ' ' * max(0, w - disp_width(s))


# ══════════════════════════════════════════════════════════════════
#  읽기 — `|` 표(마크다운) · 격자 표
# ══════════════════════════════════════════════════════════════════
_PIPE_LINE = re.compile(r'^\s*\|.*\|\s*$')
_PIPE_SEP = re.compile(r'^\s*\|?(\s*:?-{2,}:?\s*\|)+\s*:?-{0,}:?\s*\|?\s*$')
_GRID_BORDER = re.compile(r'^\s*\+([-=]+\+)+\s*$')


def _split_pipe(line):
    s = line.strip()
    if s.startswith('|'):
        s = s[1:]
    if s.endswith('|'):
        s = s[:-1]
    parts = re.split(r'(?<!\\)\|', s)
    return [re.sub(r'<br\s*/?>', '\n', p.strip().replace('\\|', '|'), flags=re.I) for p in parts]


def _parse_pipe(lines):
    rows, head = [], 0
    for ln in lines:
        if _PIPE_SEP.match(ln):
            if rows and not head:
                head = len(rows)
            continue
        rows.append(_split_pipe(ln))
    return make(rows, head) if rows and max(len(r) for r in rows) >= 2 else None


def _parse_grid(lines):
    rows, head, cur = [], 0, None
    for ln in lines:
        if _GRID_BORDER.match(ln):
            if cur is not None:
                rows.append(['\n'.join(x for x in col).strip('\n') for col in cur])
                cur = None
            if '=' in ln and rows and not head:
                head = len(rows)
            continue
        if not (ln.strip().startswith('|') and ln.strip().endswith('|')):
            return None                                   # 칸 줄은 막대로 시작하고 끝나야 한다
        parts = _split_pipe(ln)
        if cur is None:
            cur = [[] for _ in parts]
        if len(parts) != len(cur):
            return None                                   # 줄 하나가 어긋났다 — 표로 안 본다
        for i, p in enumerate(parts):
            cur[i].append(p)
    if cur is not None:
        return None                                       # 닫는 테두리가 없다
    for r in rows:                                        # 칸 안 빈 줄 정리(높이 맞춤으로 생긴 것)
        for j, v in enumerate(r):
            r[j] = '\n'.join(x for x in v.split('\n') if x.strip() != '' or False).strip()
    return make(rows, head) if rows and max(len(r) for r in rows) >= 2 else None


# ══════════════════════════════════════════════════════════════════
#  탭·쉼표로 나뉜 표 (2026-10-13 docs/1.txt 84-1)
# ══════════════════════════════════════════════════════════════════
#  ★ 엑셀·구글 시트·웹 화면의 표를 Ctrl+C 하면 글자는 **칸 사이가 탭**인 줄로 온다(칸 안 줄바꿈은 따옴표로 묶인다).
#  ★ 쉼표 표(CSV)는 **사람이 고를 때만** 바꾼다 — 문장에도 쉼표가 많아 저절로 바꾸면 엉뚱한 표가 된다.
def parse_delimited(text, delim=None, head=1):
    """탭·쉼표·`|` 로 나뉜 글 → 표 · 표가 아니면 None.

    delim=None 이면 스스로 정한다 — 탭이 있으면 탭 · 줄이 `|` 로 시작하면 `|` 표 · 그 밖은 쉼표.
    ⚠ 두 줄 이상 · 두 칸 이상이어야 표다. 따옴표로 묶인 칸(안의 쉼표·줄바꿈)은 그대로 한 칸.
    """
    import csv
    import io
    s = (text or '').replace('\r\n', '\n').strip('\n')
    if not s.strip():
        return None
    if delim is None:
        if '\t' in s:
            delim = '\t'
        elif all(_PIPE_LINE.match(ln) or _PIPE_SEP.match(ln) or _GRID_BORDER.match(ln)
                 for ln in s.split('\n') if ln.strip()):
            _t, tb = absorb(s)
            if len(tb) == 1 and not _t.replace(token(min(tb)), '').strip():
                return tb[min(tb)]
            return None
        else:
            delim = ','
    try:
        rows = [[c.strip() for c in r] for r in csv.reader(io.StringIO(s), delimiter=delim)]
    except Exception:                                     # noqa: BLE001
        return None
    rows = [r for r in rows if any(c for c in r)]
    if len(rows) < 2 or max(len(r) for r in rows) < 2:
        return None
    return make(rows, head)


def _tsv_block(lines):
    """탭 줄 덩어리가 표로 맞는가 — 줄마다 칸 수가 같고 두 칸 이상."""
    n = {ln.count('\t') for ln in lines}
    return len(lines) >= 2 and len(n) == 1 and min(n) >= 1


def absorb(text, start_no=1, tsv=True):
    """글 속 `|` 표·격자 표를 구조로 바꾸고 그 자리에 자리표를 둔다 → (새 글, {번호: 표}).

    ⚠ 표로 못 읽은 덩어리(줄 하나가 어긋난 격자 등)는 **글 그대로 둔다** — 엉뚱한 표를 만들지 않는다.
    ⚠ 이미 있는 자리표 번호와 안 부딪히게 `start_no` 부터 매긴다.
    ★ 2026-10-16 — `tsv=False` 면 탭 줄 덩어리는 **글 그대로** 둔다. 사람이 붙여 넣은 일반 문서(목록 번호 뒤 탭 ·
      들여쓰기)가 저장할 때 표가 되던 자리다(사용자 「일반 문서인데도 무조건 표로」). 표는 [표 넣기]·[표로 바꾸기]로.
    """
    lines = (text or '').split('\n')
    out, tables, i, no = [], {}, 0, max([start_no - 1] + tokens(text)) + 1
    while i < len(lines):
        ln = lines[i]
        blk, kind = [], None
        if _GRID_BORDER.match(ln):
            kind = 'GRID'
            # ⚠ 격자 덩어리는 「테두리이거나 막대가 든 줄」로 이어 모은다 — 줄 하나가 어긋나도
            #   덩어리가 끊기지 않아야 통째로 글로 둘 수 있다(뒷부분만 표가 되면 엉뚱한 표다)
            while i < len(lines) and (_GRID_BORDER.match(lines[i]) or '|' in lines[i]):
                blk.append(lines[i])
                i += 1
        elif _PIPE_LINE.match(ln):
            kind = 'PIPE'
            while i < len(lines) and (_PIPE_LINE.match(lines[i]) or _PIPE_SEP.match(lines[i])):
                blk.append(lines[i])
                i += 1
        elif tsv and '\t' in ln and ln.strip():
            # ★ 84-1 — 탭으로 칸을 나눈 줄 덩어리(AI 가 탭 표를 내거나 엑셀에서 붙여 넣은 것)
            kind = 'TSV'
            while i < len(lines) and '\t' in lines[i] and lines[i].strip():
                blk.append(lines[i])
                i += 1
        if kind:
            if kind == 'TSV':
                t = parse_delimited('\n'.join(blk), '\t') if _tsv_block(blk) else None
            else:
                t = (_parse_grid if kind == 'GRID' else _parse_pipe)(blk) if len(blk) >= 2 else None
            if t:
                tables[no] = t
                out.append(token(no))
                no += 1
            else:
                out.extend(blk)
            continue
        out.append(ln)
        i += 1
    return '\n'.join(out), tables


# ══════════════════════════════════════════════════════════════════
#  쓰기 — 격자 글 · `|` 글 · HTML
# ══════════════════════════════════════════════════════════════════
def grid_text(t):
    """격자 표 — 칸 안 여러 줄을 여러 줄로 · 고정폭 글꼴에서 줄이 맞는다(한글 = 2칸)."""
    cells = t['cells']
    if not cells:
        return ''
    cols = t['cols']
    split = [[(c or '').split('\n') for c in r] for r in cells]
    w = [max([disp_width(x) for r in split for x in r[j]] + [1]) for j in range(cols)]
    border = '+' + '+'.join('-' * (x + 2) for x in w) + '+'
    hborder = border.replace('-', '=')
    out = [border]
    for ri, r in enumerate(split):
        h = max(len(c) for c in r)
        for k in range(h):
            out.append('|' + '|'.join(' ' + _pad(r[j][k] if k < len(r[j]) else '', w[j]) + ' '
                                      for j in range(cols)) + '|')
        out.append(hborder if (t.get('head') and ri == t['head'] - 1) else border)
    return '\n'.join(out)


def pipe_text(t):
    """`|` 표 — AI·마크다운이 읽는 꼴. 칸 안 줄바꿈은 `<br>`(이 꼴은 한 칸 = 한 줄이 규칙이다)."""
    def c(s):
        return (s or '').replace('|', '\\|').replace('\n', '<br>')
    rows = [('| ' + ' | '.join(c(x) for x in r) + ' |') for r in t['cells']]
    if not rows:
        return ''
    h = t.get('head') or 0
    sep = '| ' + ' | '.join('---' for _ in range(t['cols'])) + ' |'
    rows.insert(h if h else 1, sep) if True else None
    if not h:
        rows.insert(0, '| ' + ' | '.join('' for _ in range(t['cols'])) + ' |')
    return '\n'.join(rows)


def table_html(t):
    """HTML 표 — 워드·한글이 진짜 표로 받는다. 폭 100% → 페이지 안으로 맞춘다."""
    out = ['<table border="1" cellspacing="0" cellpadding="4" '
           'style="border-collapse:collapse;width:100%">']
    for ri, r in enumerate(t['cells']):
        tag = 'th' if ri < (t.get('head') or 0) else 'td'
        out.append('<tr>' + ''.join('<%s style="vertical-align:top">%s</%s>'
                                    % (tag, html.escape(c or '').replace('\n', '<br>'), tag) for c in r) + '</tr>')
    out.append('</table>')
    return ''.join(out)


def expand(text, tables, mode='grid'):
    """자리표를 표 글로 편다 — 'grid' 격자 · 'pipe' `|` 표 · 모르는 번호는 그대로 둔다."""
    fn = grid_text if mode == 'grid' else pipe_text

    def rep(m):
        t = (tables or {}).get(int(m.group(1)))
        return fn(t) if t else m.group(0)
    return TOKEN_RE.sub(rep, text or '')


def to_html(text, tables):
    """글 + 표 → HTML 조각(문단은 <p>, 자리표는 <table>)."""
    parts = []
    for blk in re.split(r'\n\s*\n', text or ''):
        segs = TOKEN_RE.split(blk)
        for k, seg in enumerate(segs):
            if k % 2 == 1:
                t = (tables or {}).get(int(seg))
                parts.append(table_html(t) if t else html.escape(token(seg)))
            elif seg.strip():
                parts.append('<p>' + html.escape(seg.strip('\n')).replace('\n', '<br>') + '</p>')
    return ''.join(parts)


# ══════════════════════════════════════════════════════════════════
#  저장
# ══════════════════════════════════════════════════════════════════
def ensure(conn, sides=('SYS', 'USER')):
    for sd in sides:
        tt, tx, own, pre = SIDES[sd]
        if pre and not any(r[1] == 'userdb' for r in conn.execute('PRAGMA database_list')):
            continue
        conn.execute(
            'CREATE TABLE IF NOT EXISTS %s%s (table_id INTEGER PRIMARY KEY AUTOINCREMENT,'
            ' %s INTEGER NOT NULL, table_no INTEGER NOT NULL, n_rows INTEGER NOT NULL,'
            " n_cols INTEGER NOT NULL, head_rows INTEGER DEFAULT 0, record_status TEXT DEFAULT 'LIVE')"
            % (pre, tt, own))
        conn.execute('CREATE UNIQUE INDEX IF NOT EXISTS %six_%s_no ON %s(%s, table_no)' % (pre, tt, tt, own))
        conn.execute(
            'CREATE TABLE IF NOT EXISTS %s%s (table_id INTEGER NOT NULL, lang_code TEXT NOT NULL,'
            ' cells_json TEXT NOT NULL, PRIMARY KEY(table_id, lang_code))' % (pre, tx))
    conn.commit()


def _q(side):
    tt, tx, own, pre = SIDES[side]
    return pre + tt, pre + tx, own


def put_table(conn, side, owner, no, t, lang, restructure=False, commit=True):
    """표 하나를 그 언어로 담는다 → table_id.

    ⚠ 구조가 이미 있고 모양이 다르면 `restructure` 없이는 **거부**(ValueError) —
      번역이 표를 일그러뜨리는 길을 여기서 막는다.
    """
    tt, tx, own = _q(side)
    lg = str(lang or 'KO').upper()
    if not shape_ok(t, t.get('cells')):
        raise ValueError('표 모양이 행·열 수와 다르다')
    r = conn.execute('SELECT table_id, n_rows, n_cols FROM %s WHERE %s=? AND table_no=?' % (tt, own),
                     (owner, int(no))).fetchone()
    if r:
        tid, nr, nc = r
        if (nr, nc) != (t['rows'], t['cols']):
            if not restructure:
                raise ValueError('표 %d 의 모양(%d×%d)이 저장된 구조(%d×%d)와 다르다'
                                 % (no, t['rows'], t['cols'], nr, nc))
            for olg, cj in conn.execute('SELECT lang_code, cells_json FROM %s WHERE table_id=?' % tx,
                                        (tid,)).fetchall():
                if olg != lg:
                    conn.execute('UPDATE %s SET cells_json=? WHERE table_id=? AND lang_code=?' % tx,
                                 (json.dumps(reshape(json.loads(cj), t['rows'], t['cols']), ensure_ascii=False),
                                  tid, olg))
        conn.execute("UPDATE %s SET n_rows=?, n_cols=?, head_rows=?, record_status='LIVE' WHERE table_id=?" % tt,
                     (t['rows'], t['cols'], t.get('head') or 0, tid))
    else:
        tid = conn.execute('INSERT INTO %s(%s, table_no, n_rows, n_cols, head_rows) VALUES(?,?,?,?,?)'
                           % (tt, own), (owner, int(no), t['rows'], t['cols'], t.get('head') or 0)).lastrowid
    conn.execute('INSERT OR REPLACE INTO %s(table_id, lang_code, cells_json) VALUES(?,?,?)' % tx,
                 (tid, lg, json.dumps(t['cells'], ensure_ascii=False)))
    if commit:
        conn.commit()
    return tid


def sync_all(conn, side, owner, tables, lang, commit=True):
    """본문을 저장한 **뒤에** 부른다 — 그 글의 모든 언어 본문을 읽어 `sync` 한다.

    ⚠ 본문 표: USER = `user_ref_text(ref_id)` · SYS = `sys_ref_text(ref_unit_id)`.
    """
    ensure(conn, (side,))
    q = ("SELECT body_text FROM userdb.user_ref_text WHERE ref_id=? AND COALESCE(record_status,'LIVE')='LIVE'"
         if side == 'USER' else
         "SELECT body_text FROM sys_ref_text WHERE ref_unit_id=? AND COALESCE(record_status,'LIVE')='LIVE'")
    texts = [r[0] or '' for r in conn.execute(q, (owner,))]
    sync(conn, side, owner, texts, tables, lang, commit=commit)


# ══════════════════════════════════════════════════════════════════
#  번역 — 본문은 자리표째 · 표는 **칸 번호 목록**으로 보내고 같은 번호로 되돌린다
#  ⚠ 머리 줄은 언어 중립 꼴 `[[T1:CELLS]]` — 「표 1」이라 쓰면 AI 가 그것까지 옮긴다.
# ══════════════════════════════════════════════════════════════════
CELLS_HEAD = re.compile(r'^\s*\[\[T(\d{1,3}):CELLS\]\]\s*$')
CELL_LINE = re.compile(r'^\s*(\d{1,4})\)\s?(.*)$')


def cells_block(tables):
    """표들을 번호 목록 글로(행 먼저 · 1부터 · 칸 안 줄바꿈은 `<br>`)."""
    out = []
    for no in sorted(tables or {}):
        t = tables[no]
        out.append('[[T%d:CELLS]]' % no)
        k = 0
        for r in t['cells']:
            for v in r:
                k += 1
                out.append('%d) %s' % (k, (v or '').replace('\n', '<br>')))
    return '\n'.join(out)


def split_cells(text):
    """받은 글 → (본문, {표 번호: {칸 번호: 글}}). 칸 목록이 없으면 (글, {})."""
    lines = (text or '').split('\n')
    body, ans, cur = [], {}, None
    for ln in lines:
        m = CELLS_HEAD.match(ln)
        if m:
            cur = int(m.group(1))
            ans.setdefault(cur, {})
            continue
        if cur is not None:
            c = CELL_LINE.match(ln)
            if c:
                ans[cur][int(c.group(1))] = re.sub(r'<br\s*/?>', '\n', c.group(2).strip(), flags=re.I)
            continue
        body.append(ln)
    while body and not body[-1].strip():
        body.pop()
    return '\n'.join(body), ans


def fill_cells(t, answers):
    """구조(t)의 모양 그대로 번호 답을 칸에 — 빈 번호는 빈칸(읽을 때 폴백)."""
    cells, k = [], 0
    for _i in range(t['rows']):
        row = []
        for _j in range(t['cols']):
            k += 1
            row.append((answers or {}).get(k, ''))
        cells.append(row)
    return {'rows': t['rows'], 'cols': t['cols'], 'head': t.get('head') or 0, 'cells': cells}


def cells_check(src_body, out_body, tables, answers=None, need_cells=True):
    """번역 게이트 — 자리표가 그대로인가 · 칸 수가 맞는가 → 흠 목록."""
    bad = []
    a, b = sorted(tokens(src_body)), sorted(tokens(out_body))
    if a != b:
        bad.append('표 자리표가 원본과 다릅니다 — 원본 %s · 옮긴 글 %s(자리표 [[T1]] 은 글자 그대로 둡니다)'
                   % (a or '없음', b or '없음'))
    if need_cells:
        for no in sorted(set(a)):
            t = (tables or {}).get(no)
            if not t:
                continue
            n = t['rows'] * t['cols']
            got = (answers or {}).get(no) or {}
            miss = [k for k in range(1, n + 1) if k not in got]
            extra = [k for k in got if k > n]
            if miss or extra:
                bad.append('표 %d 의 칸 수가 맞지 않습니다 — %d칸 중 빠짐 %d · 넘침 %d' % (no, n, len(miss), len(extra)))
    return bad


def all_cells_text(conn, side, owner, lang='KO'):
    """그 글 표들의 칸 글을 한 덩어리로 — 구절약명 자동 연결·검색이 표 안 글도 읽게."""
    out = []
    for _no, t in sorted(get_tables(conn, side, owner, lang).items()):
        for r in t['cells']:
            out.extend(x for x in r if x)
    return '\n'.join(out)


def get_tables(conn, side, owner, lang='KO', fallback=('EN', 'KO')):
    """그 글의 표들 {번호: 표} — 그 언어 칸이 비면 **칸마다** 폴백 언어로 채운다."""
    tt, tx, own = _q(side)
    try:
        rows = conn.execute("SELECT table_id, table_no, n_rows, n_cols, head_rows FROM %s"
                            " WHERE %s=? AND COALESCE(record_status,'LIVE')='LIVE'" % (tt, own),
                            (owner,)).fetchall()
    except Exception:                                     # noqa: BLE001 — 표가 아직 없는 DB
        return {}
    order = [str(lang or 'KO').upper()] + [x for x in fallback if x != str(lang or 'KO').upper()]
    out = {}
    for tid, no, nr, nc, hd in rows:
        have = {lg: json.loads(cj) for lg, cj in conn.execute(
            'SELECT lang_code, cells_json FROM %s WHERE table_id=?' % tx, (tid,)).fetchall()}
        others = [lg for lg in have if lg not in order]
        cells = [[''] * nc for _ in range(nr)]
        for i in range(nr):
            for j in range(nc):
                for lg in order + others:
                    c = have.get(lg)
                    if c and i < len(c) and j < len(c[i]) and (c[i][j] or '').strip():
                        cells[i][j] = c[i][j]
                        break
        out[int(no)] = {'rows': nr, 'cols': nc, 'head': hd or 0, 'cells': cells}
    return out


def sync(conn, side, owner, texts, tables, lang, commit=True):
    """글을 저장할 때 표를 맞춘다 — 이 언어의 표들을 담고, **어느 언어 글에도 자리표가 없는** 표는 HIDE.

    `texts` = 그 글의 모든 언어 본문(방금 저장한 것 포함) · `tables` = {번호: 표}(이 언어).
    ⚠ 지우지 않고 HIDE — 되돌릴 수 있다. 자리표를 다시 넣으면 살아난다.
    """
    tt, tx, own = _q(side)
    for no, t in (tables or {}).items():
        put_table(conn, side, owner, no, t, lang, restructure=True, commit=False)
    used = set()
    for tx_ in texts or []:
        used.update(tokens(tx_))
    for tid, no in conn.execute('SELECT table_id, table_no FROM %s WHERE %s=?' % (tt, own), (owner,)).fetchall():
        st = 'LIVE' if int(no) in used else 'HIDE'
        conn.execute('UPDATE %s SET record_status=? WHERE table_id=?' % tt, (st, tid))
    if commit:
        conn.commit()


# ══════════════════════════════════════════════════════════════════
#  화면 — 자리표 자리에 격자 표를 끼워 넣는다(Tk)
# ══════════════════════════════════════════════════════════════════
def table_widget(parent, t, C=None, font=None, wrap=160, lang=None):
    """격자 표 위젯 — 칸 폭은 **그때** 글 길이와 `wrap`(픽셀)으로 정한다(공백 맞춤 없음).

    `C(역할, 폴백)` = 테마 색(ui_theme.C) · 머리 칸은 `panel_alt` 바탕에 굵게.
    """
    import tkinter as tk
    C = C or (lambda r, f: f)
    line = C('border', '#BDC3C7')
    outer = tk.Frame(parent, bg=line, bd=0, highlightthickness=0)
    rtl = False
    try:
        import bidi as _bd
        rtl = bool(_bd.rtl_align(' '.join(sum(t['cells'], [])), lang))
    except Exception:                                     # noqa: BLE001
        pass
    for i, r in enumerate(t['cells']):
        for j, v in enumerate(r):
            head = i < (t.get('head') or 0)
            kw = {}
            if font:
                try:
                    import tkinter.font as tkf
                    a_ = tkf.Font(font=font).actual()
                    kw['font'] = (a_['family'], a_['size'], 'bold' if head else 'normal')
                except Exception:                         # noqa: BLE001
                    pass
            col = (t['cols'] - 1 - j) if rtl else j
            lb = tk.Label(outer, text=v or '', anchor='ne' if rtl else 'nw',
                          justify='right' if rtl else 'left', wraplength=wrap, padx=6, pady=3,
                          bg=C('panel_alt', '#EEF2F5') if head else C('view_bg', '#FFFFFF'),
                          fg=C('fg', '#222222'), **kw)
            lb.grid(row=i, column=col, sticky='nsew', padx=(0 if col else 1, 1), pady=(0 if i else 1, 1))
    for j in range(t['cols']):
        outer.columnconfigure(j, weight=1)
    return outer


def render(txt, body, tables, lang=None, C=None, font=None):
    """`tk.Text` 끝에 본문을 넣되 자리표 자리에 표를 심는다 → 심은 위젯들.

    ⚠ 부르는 쪽이 다시 그릴 때 **이 위젯들을 destroy** 해야 한다(글자를 지워도 위젯은 남는다).
    ⚠ 표가 없으면 글만 넣는다(지금까지와 똑같다).
    """
    try:
        import bidi as _bd
        put = lambda s_: _bd.insert(txt, s_, lang=lang)     # noqa: E731
    except Exception:                                     # noqa: BLE001
        put = lambda s_: txt.insert('end', s_)           # noqa: E731
    segs = TOKEN_RE.split(body or '')
    made = []
    try:
        width = max(240, int(txt.winfo_width()) - 40)
    except Exception:                                     # noqa: BLE001
        width = 600
    for k, seg in enumerate(segs):
        if k % 2 == 0:
            if seg:
                put(seg)
            continue
        t = (tables or {}).get(int(seg))
        if not t:
            put(token(seg))
            continue
        w = table_widget(txt, t, C=C, font=font, wrap=max(80, width // max(1, t['cols']) - 14), lang=lang)
        w._rd_table = t                                   # 복사할 때 이 위젯이 어느 표인지
        txt.window_create('end', window=w, padx=2, pady=4)
        made.append(w)
    if not getattr(txt, '_rd_copy_bound', False):
        txt.bind('<<Copy>>', lambda e: (copy_selection(txt), 'break')[1])
        txt._rd_copy_bound = True
    return made


# ══════════════════════════════════════════════════════════════════
#  복사 — 클립보드에 **HTML 표**(워드·한글은 진짜 표) + **격자 글**(메모장) 함께
# ══════════════════════════════════════════════════════════════════
def selection_doc(txt, first='sel.first', last='sel.last'):
    """글상자의 선택한 부분 → (자리표 글, {번호: 표}). 심은 표는 선택한 범위 안에 있으면 통째로."""
    parts, tables = [], {}
    try:
        items = txt.dump(first, last, text=True, window=True)
    except Exception:                                     # noqa: BLE001 — 고른 것이 없다
        return '', {}
    for kind, val, _idx in items:
        if kind == 'text':
            parts.append(val)
        elif kind == 'window':
            try:
                t = txt.nametowidget(val)._rd_table
            except Exception:                             # noqa: BLE001
                continue
            no = len(tables) + 1
            tables[no] = t
            parts.append(token(no))
    return ''.join(parts), tables


def cf_html(fragment):
    """윈도우 클립보드 HTML 꼴(CF_HTML) — 머리에 바이트 위치를 적는다(UTF-8)."""
    CRLF = chr(13) + chr(10)
    head = ('Version:0.9' + CRLF + 'StartHTML:{0:010d}' + CRLF + 'EndHTML:{1:010d}' + CRLF +
            'StartFragment:{2:010d}' + CRLF + 'EndFragment:{3:010d}' + CRLF)
    pre = '<html><head><meta charset="utf-8"></head><body><!--StartFragment-->'
    post = '<!--EndFragment--></body></html>'
    sh = len(head.format(0, 0, 0, 0).encode('utf-8'))
    sf = sh + len(pre.encode('utf-8'))
    ef = sf + len(fragment.encode('utf-8'))
    eh = ef + len(post.encode('utf-8'))
    return (head.format(sh, eh, sf, ef) + pre + fragment + post).encode('utf-8')


def set_clipboard(text, html_fragment=None, widget=None):
    """글 + (있으면) HTML 을 함께 올린다. 윈도우가 아니거나 실패하면 Tk 로 글만."""
    CR, LF = chr(13), chr(10)
    try:
        import ctypes
        import time
        from ctypes import wintypes
        u32, k32 = ctypes.windll.user32, ctypes.windll.kernel32
        k32.GlobalAlloc.restype = wintypes.HGLOBAL
        k32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
        k32.GlobalLock.restype = ctypes.c_void_p
        k32.GlobalLock.argtypes = [wintypes.HGLOBAL]
        k32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
        u32.SetClipboardData.restype = wintypes.HANDLE
        u32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
        u32.OpenClipboard.argtypes = [wintypes.HWND]
        u32.RegisterClipboardFormatW.argtypes = [wintypes.LPCWSTR]

        def put(fmt, data):
            h = k32.GlobalAlloc(0x0002, len(data))        # GMEM_MOVEABLE
            q = k32.GlobalLock(h)
            ctypes.memmove(q, data, len(data))
            k32.GlobalUnlock(h)
            u32.SetClipboardData(fmt, h)
        for _ in range(10):
            if u32.OpenClipboard(None):
                break
            time.sleep(0.05)
        else:
            raise OSError('클립보드를 열지 못했다')
        try:
            u32.EmptyClipboard()
            t = (text or '').replace(CR + LF, LF).replace(LF, CR + LF)
            put(13, t.encode('utf-16-le') + bytes(2))                 # CF_UNICODETEXT
            if html_fragment:
                put(u32.RegisterClipboardFormatW('HTML Format'), cf_html(html_fragment) + bytes(1))
        finally:
            u32.CloseClipboard()
        return True
    except Exception:                                     # noqa: BLE001
        if widget is not None:
            widget.clipboard_clear()
            widget.clipboard_append(text or '')
        return False


def copy_selection(txt):
    """Ctrl-C — 선택한 부분을 격자 글 + HTML 로. 표가 없으면 글만(지금까지와 같다)."""
    body, tables = selection_doc(txt)
    if not body:
        return False
    plain = expand(body, tables, 'grid')
    set_clipboard(plain, to_html(body, tables) if tables else None, widget=txt)
    return True


# ══════════════════════════════════════════════════════════════════
def selftest():
    import sqlite3
    ok = fail = 0

    def ck(c, m, got=''):
        nonlocal ok, fail
        if c:
            ok += 1
            print('  OK  ', m)
        else:
            fail += 1
            print('  FAIL', m, '|', str(got)[:200])

    # 읽기 — `|` 표
    src = '앞 글\n\n| 이름 | 뜻 |\n|---|---|\n| 은혜 | 값없이 주심<br>둘째 줄 |\n| 믿음 | 신뢰 |\n\n뒷 글'
    txt, tb = absorb(src)
    ck('[[T1]]' in txt and '앞 글' in txt and '뒷 글' in txt and '|' not in txt, '`|` 표 → 자리표 하나', txt)
    t = tb.get(1) or {}
    ck(t.get('rows') == 3 and t.get('cols') == 2 and t.get('head') == 1, '구조 3×2 · 머리 줄 1', t)
    ck(t.get('cells', [[], ['', '']])[1][1] == '값없이 주심\n둘째 줄', '`<br>` → 칸 안 줄바꿈', t.get('cells'))
    # 쓰기 — 격자 · 여러 줄 · 한글 폭
    g = grid_text(t)
    lines = g.split('\n')
    ck(len({disp_width(x) for x in lines}) == 1, '★ 격자 글 — 모든 줄의 표시 폭이 같다(한글 2칸 계산)', g)
    ck(any('둘째 줄' in x for x in lines) and sum(1 for x in lines if '값없이' in x or '둘째' in x) == 2,
       '★ 칸 안 여러 줄이 여러 줄로', g)
    ck('=' in lines[2] and lines[0].startswith('+-'), '머리 줄 아래는 = 테두리', g)
    # 되읽기 — 격자 → 같은 구조
    txt2, tb2 = absorb('머리\n' + g + '\n꼬리')
    ck(tb2.get(1) == t, '★★ 격자 글을 되읽으면 같은 구조(왕복)', (tb2.get(1), t))
    # 줄 하나가 어긋난 격자는 표로 안 본다
    bad = g.split('\n')
    bad[1] = bad[1].replace('|', '', 1)
    txt3, tb3 = absorb('\n'.join(bad))
    ck(not tb3 and '은혜' in txt3, '★ 어긋난 격자는 표로 안 만들고 글 그대로 둔다', (tb3, txt3[:40]))
    # pipe 왕복 · HTML
    _t, tb4 = absorb(pipe_text(t))
    ck(tb4.get(1) == t, '`|` 글 왕복', tb4.get(1))
    h = to_html('문단 하나\n\n' + token(1) + '\n\n문단 <둘>', {1: t})
    ck('<table' in h and '<th' in h and '값없이 주심<br>둘째 줄' in h and '&lt;둘&gt;' in h and h.count('<p>') == 2,
       'HTML — 표·머리 칸·칸 줄바꿈·글 이스케이프', h[:200])
    ck(expand('가 ' + token(1) + ' 나 ' + token(9), {1: t}).count('+') > 4 and '[[T9]]' in
       expand(token(9), {1: t}), '자리표 펴기 — 모르는 번호는 그대로', '')
    ck(tokens('a [[T2]] b [[T10]]') == [2, 10], '자리표 번호 읽기', tokens('a [[T2]] b [[T10]]'))
    _t, tb5 = absorb('[[T1]]\n| a | b |\n|---|---|\n| c | d |')
    ck(list(tb5) == [2], '이미 있는 자리표와 안 부딪히게 번호를 잇는다', list(tb5))
    ck(absorb('그냥 | 들어간 | 글')[1] == {}, '글 속 막대 하나는 표가 아니다')

    # 저장
    c = sqlite3.connect(':memory:')
    c.execute("ATTACH ':memory:' AS userdb")
    ensure(c)
    tid = put_table(c, 'USER', 7, 1, t, 'KO')
    en = make([['Name', 'Meaning'], ['grace', 'given freely'], ['faith', '']], 1)
    put_table(c, 'USER', 7, 1, en, 'EN')
    got = get_tables(c, 'USER', 7, 'EN')[1]
    ck(got['cells'][1][1] == 'given freely' and got['cells'][2][1] == '신뢰',
       '★ 칸마다 폴백 — 빈 영어 칸은 기준 언어 칸으로', got['cells'])
    try:
        put_table(c, 'USER', 7, 1, make([['a', 'b', 'c']]), 'FR')
        ck(False, '★★ 모양이 다른 번역은 거부')
    except ValueError:
        ck(True, '★★ 모양이 다른 번역은 거부(일그러진 표가 못 들어간다)')
    t4 = make(t['cells'] + [['소망', '기다림']], 1)
    put_table(c, 'USER', 7, 1, t4, 'KO', restructure=True)
    enc = json.loads(c.execute("SELECT cells_json FROM userdb.user_ref_table_text WHERE table_id=? AND lang_code='EN'",
                               (tid,)).fetchone()[0])
    ck(len(enc) == 4 and enc[1][1] == 'given freely' and enc[3] == ['', ''],
       '★ 구조를 바꾸면 다른 언어 칸은 자리를 지키고 빈칸이 생긴다', enc)
    sync(c, 'USER', 7, ['글만 남음'], {}, 'KO')
    ck(get_tables(c, 'USER', 7, 'KO') == {}, '자리표가 어느 글에도 없으면 HIDE')
    sync(c, 'USER', 7, ['다시 ' + token(1)], {}, 'KO')
    ck(1 in get_tables(c, 'USER', 7, 'KO'), '자리표를 다시 넣으면 되살아난다')
    put_table(c, 'SYS', 3, 1, t, 'KO')
    ck(get_tables(c, 'SYS', 3, 'KO')[1]['cells'] == t['cells'] and get_tables(c, 'SYS', 7, 'KO') == {},
       '공용(sys)·내 글(user) 표가 섞이지 않는다')
    blk = cells_block({1: t})
    src_b = '앞' + chr(10) + token(1) + chr(10) + '뒤'
    out_b, ans = split_cells('before' + chr(10) + token(1) + chr(10) + 'after' + chr(10) + chr(10)
                             + blk.replace('은혜', 'grace').replace('<br>', '<br/>'))
    ck(out_b.endswith('after') and ans.get(1, {}).get(3) == 'grace' and ans[1][4] == '값없이 주심' + chr(10) + '둘째 줄',
       '★ 칸 번호 목록 왕복(본문과 칸을 가른다 · <br> 은 줄바꿈)', (out_b, ans))
    ck(cells_check(src_b, out_b, {1: t}, ans) == [], '자리표·칸 수가 맞으면 흠 0')
    ck(cells_check(src_b, 'before after', {1: t}, ans) and
       cells_check(src_b, out_b, {1: t}, {1: {1: 'x'}}), '★ 자리표를 빼먹거나 칸이 모자라면 흠', '')
    ck(fill_cells(t, {1: 'A', 4: 'B'})['cells'] == [['A', ''], ['', 'B'], ['', '']], '번호 답 → 같은 모양 칸')
    raw = cf_html('<p>가</p>')
    hd = raw.decode('utf-8')
    import re as _re
    nums = {k: int(v) for k, v in _re.findall(r'(StartHTML|EndHTML|StartFragment|EndFragment):(\d+)', hd)}
    ck(raw[nums['StartFragment']:nums['EndFragment']].decode('utf-8') == '<p>가</p>'
       and raw[nums['StartHTML']:].startswith(b'<html>') and nums['EndHTML'] == len(raw),
       '★ 클립보드 HTML 꼴 — 바이트 위치가 맞다(한글 포함)', nums)
    # ── 84-1 탭·쉼표 표 ──────────────────────────────────────────
    tsv = '구분\t구글\t애플\n핵심 기술\tPAD\tODR\n최대 용량\t4GB\t20GB'
    tt = parse_delimited(tsv)
    ck(tt and tt['rows'] == 3 and tt['cols'] == 3 and tt['head'] == 1, '탭 표 → 3×3 · 머리 줄', tt)
    ck(parse_delimited('"a\nb"\tc\nd\te')['cells'][0][0] == 'a\nb', '따옴표 칸 안 줄바꿈')
    csvs = '구분,구글 플레이스토어,애플 앱스토어\n핵심 기술,PAD,"ODR, Background"'
    tc = parse_delimited(csvs)
    ck(tc and tc['cols'] == 3 and tc['cells'][1][2] == 'ODR, Background', '쉼표 표 · 따옴표 안 쉼표', tc)
    ck(parse_delimited('한 줄뿐인 글, 쉼표 있음') is None, '한 줄은 표가 아니다')
    txt9, tb9 = absorb('앞\n' + tsv + '\n뒤')
    ck('[[T1]]' in txt9 and len(tb9) == 1 and '\t' not in txt9, '글 속 탭 표 → 자리표(absorb)', txt9)
    txt10, tb10 = absorb('앞\n가\t나\n다\t라\t마\n뒤')
    ck(not tb10 and '\t' in txt10, '칸 수가 어긋난 탭 줄은 글 그대로', txt10)
    txt11, tb11 = absorb('사과, 배, 감\n하나, 둘, 셋')
    ck(not tb11, '쉼표 줄은 저절로 표로 안 바꾼다')
    ck((parse_delimited('| a | b |\n|---|---|\n| 1 | 2 |') or {}).get('rows') == 2, '`|` 표도 받는다')
    print('ref_doc selftest: %s (%d/%d)' % ('OK' if not fail else 'FAIL', ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print(__doc__)
