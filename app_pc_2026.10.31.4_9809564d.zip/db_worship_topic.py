# -*- coding: utf-8 -*-
"""찬양 **주제** — 우리 앱에서는 「용어」다 (2026-09-10 신설).

사용자 확정 「분위기 필요하고, **주제는 데이터 연결이 없을 뿐**이다. 관리화면
에서 주제와 연결해야 한다. **주제는 용어 중에서 선택하는 것이 최선**이다.
감사, 은혜, 십자가, 보혈… 표현은 주제, 우리 앱에서는 용어」.

★★★ **새 축을 만들지 않는다.** 영상↔용어 연결(`MEDI_ENTI`)이 이미 있고
  자동 추천기도 그 표에 쓴다. 주제는 그 위에 얹는 **고른 목록**일 뿐이다 —
  「사람이 주제로 쓰겠다고 정한 용어 번호들」. 표를 새로 만들면 같은 것을
  두 곳에서 정하게 된다.

⚠⚠ **이름이 든다고 그 주제인 것이 아니다**(§228차 홑낱말 함정). 실측 —
  「교회」가 23편에 걸리는데 대개 **채널 이름**이고, 「영화」·「자존」은 딴
  낱말의 조각이다. ⇒ `suggest` 는 **추천만** 하고 사람이 고른다.
⚠ 설명문은 안 본다 — 채널 안내에 이런 낱말이 흔해 오탐이 는다.

명령
  --selftest   자가검증(의무)
  --list       지금 고른 주제와 편 수
  --scan       제목에 걸리는 용어 상위 (주제 씨앗을 고를 재료)
"""
import io
import json
import sys

#: 고른 주제 = **용어 번호 목록**. 배포 DB 의 설정 한 줄(CORE).
CFG_KEY = 'MEDIA_WORSHIP_TOPIC'

#: 찬양으로 볼 조건 — 세 화면이 같은 잣대를 쓴다.
_W = ("a.record_status='LIVE' AND a.media_type='WORSHIP' AND a.is_active=1")


def _lt():
    import media_link
    return media_link.lt('ENTITY')


# ── 고른 목록 ───────────────────────────────────────────────────────────
def topic_ids(conn):
    """선택한 주제 용어 번호 [int] — 정한 차례 그대로."""
    try:
        r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                         (CFG_KEY,)).fetchone()
        if r and r[0]:
            v = json.loads(r[0])
            return [int(x) for x in v if str(x).strip()]
    except Exception:
        pass
    return []


def save(conn, ids):
    """주제 목록을 갈아 끼운다 → 담은 수.

    ⚠ **차례를 지킨다** — 사람이 늘어놓은 차례가 곧 화면 차례다.
    ⚠ 겹치는 번호는 한 번만.
    """
    out = []
    for x in (ids or []):
        try:
            n = int(x)
        except Exception:
            continue
        if n not in out:
            out.append(n)
    conn.execute("INSERT INTO sys_config(config_key, config_val) VALUES(?,?)"
                 " ON CONFLICT(config_key) DO UPDATE"
                 " SET config_val=excluded.config_val",
                 (CFG_KEY, json.dumps(out)))
    return len(out)


def name_of(conn, eid, lang='KO'):
    """용어 번호 → 이름. **못 찾으면 번호를 그대로**(조용히 안 비운다)."""
    r = conn.execute(
        "SELECT contents FROM sys_text_asset"
        " WHERE text_type='ENTITY_NAME' AND clicked_id=?"
        "   AND COALESCE(record_status,'LIVE')='LIVE'"
        " ORDER BY CASE UPPER(COALESCE(lang_code,'')) WHEN ? THEN 0"
        "          WHEN 'EN' THEN 1 ELSE 2 END, LENGTH(contents) LIMIT 1",
        (int(eid), str(lang).upper())).fetchone()
    got = split_names((r[0] if r else '') or '')
    # ⚠ 화면에는 **첫 표기 하나만** — 「감사 · 토다」는 주제 이름이 아니다
    return got[0] if got else ('#%d' % int(eid))


#: 이름 한 줄에 여러 표기가 묶여 있다 — 가운뎃점과 괄호로 쪼갠다.
_SEP = ('·', '・', '‧', '/')
#: 쪼갤 자리 표식 — 본문에 나올 리 없는 글자 하나.
_MARK = chr(1)


def split_names(text):
    """`'감사 · 토다'` → `['감사', '토다']`.

    ⚠⚠ **이름이 한 줄에 묶여 있다**(2026-09-10 실측). `sys_text_asset` 의
      `ENTITY_NAME` 이 「한국어 이름 · 원어 음역」을 **한 행**에 담은 것이
      많아, 통째로 제목과 대조하면 **영영 안 걸린다** — 실측 「감사」가
      제목 31편에 있는데 추천 **0편**이었다.
    ⚠ 괄호 표기(`Resurrection (anastasis)`)도 함께 연다(§232차).
    ⚠ **한 글자는 버린다** — 어디에나 걸린다(§228차 홑낱말 함정).
    """
    out = []
    for chunk in [text or '']:
        for sep in _SEP:
            chunk = chunk.replace(sep, _MARK)
        for part in chunk.split(_MARK):
            part = part.strip()
            if not part:
                continue
            if '(' in part and part.endswith(')'):
                head, _, tail = part.partition('(')
                for x in (head, tail[:-1]):
                    x = x.strip()
                    if len(x) >= 2 and x not in out:
                        out.append(x)
                continue
            if len(part) >= 2 and part not in out:
                out.append(part)
    return out


def names_of(conn, eid, lang='KO'):
    """그 용어의 이름 전부(원어 음역 포함) — 제목 대조에 쓴다."""
    out = []
    for (c,) in conn.execute(
            "SELECT contents FROM sys_text_asset"
            " WHERE text_type='ENTITY_NAME' AND clicked_id=?"
            "   AND UPPER(COALESCE(lang_code,''))=?"
            "   AND COALESCE(record_status,'LIVE')='LIVE'",
            (int(eid), str(lang).upper())):
        for x in split_names(c):
            if x not in out:
                out.append(x)
    return out


def topics(conn, lang='KO', pref=None, only_used=False):
    """주제 [(entity_id, 이름, 편 수)] — 선택한 차례 그대로.

    ⚠ `only_used` 면 **편 수가 0인 주제는 안 낸다**(§0-1 빈 서랍 금지) —
      사용자 화면이 쓴다. 관리 화면은 0도 봐야 하므로 기본은 전부 낸다.
    """
    out = []
    for eid in topic_ids(conn):
        n = len(media_of_topic(conn, eid, pref=pref, limit=10 ** 9))
        if only_used and not n:
            continue
        out.append((eid, name_of(conn, eid, lang), n))
    return out


# ── 영상 ────────────────────────────────────────────────────────────────
def media_of_topic(conn, entity_id, lang=None, pref=None, limit=200):
    """그 주제의 찬양 [(media_id, 제목, url, 설명문)] — **읽는 문 하나**.

    ★ 화면이 `sys_media_asset` 을 직접 안 읽는 자리다(§121차).
    ⚠ `pref` = `media_pref.load(...)` — 내가 숨긴 것을 뺀다(§226차).
    ⚠ **승인된 것만**(§194차) · **살아 있는 연결만**(후보 PEND 는 안 낸다).
    """
    q = ("SELECT DISTINCT a.media_id, a.title, a.url,"
         "       COALESCE(a.description,'')"
         "  FROM sys_link_asset l"
         "  JOIN sys_media_asset a ON a.media_id=l.clicked_id"
         " WHERE l.link_type=? AND l.target_id=? AND " + _W +
         "   AND COALESCE(l.record_status,'LIVE')='LIVE'")
    args = [_lt(), int(entity_id)]
    if lang:
        q += " AND UPPER(COALESCE(a.lang_code,''))=?"
        args.append(str(lang).upper())
    out = []
    for mid, ti, url, d in conn.execute(q, args):
        if pref is not None:
            try:
                if pref.hidden(mid, d):
                    continue
            except Exception:
                pass
        out.append((mid, ti or '', url or '', d or ''))
        if len(out) >= int(limit):
            break
    return out


def review_rows(conn, entity_id=None, lang='KO', q='', limit=1000):
    """**검증 화면이 쓰는 줄** → [dict].

    ★★★ 2026-09-10 사용자 — 「이 탭에서 **다시 한번 검증**하는 절차라면 그것은
      충분히 의미가 있다. 그런데 **판단할 정보가 전혀 없다**는 것이 문제다」.
      ⇒ 무엇을 보고 이었는지(`source`)와 조회수·곡·사역자를 **함께** 낸다.
    ★ `entity_id` 가 없으면 **주제 전부**를 한 목록으로 낸다 — 주제 22개를
      하나씩 눌러야 했던 자리다(사용자 「주제 하나하나 눌러야 하는가?」).
    ⚠ 연결의 **번호(`link_id`)를 함께** 낸다 — 「이 주제 아님」이 그것으로 뗀다.
    ⚠ 관리 화면이라 **승인 여부를 안 가린다** — 검증이 이 화면의 일이다.
    """
    import media_link as _ML
    tids = ([int(entity_id)] if entity_id is not None else topic_ids(conn))
    if not tids:
        return []
    ph = ','.join('?' * len(tids))
    args = [_lt()] + tids
    sql = ("SELECT l.sys_link_id, l.target_id, a.media_id, a.title, a.url,"
           "       COALESCE(a.description,''), COALESCE(a.lang_code,''),"
           "       COALESCE(l.source,''), COALESCE(a.is_active,0),"
           # ★ **분류를 함께 낸다**(2026-09-11) — 「긍휼」에 걸린 바이블프로젝트
           #   처럼 **찬양이 아닌 것**을 화면이 그 칸으로 알아본다.
           "       COALESCE(a.media_type,'')"
           "  FROM sys_link_asset l"
           "  JOIN sys_media_asset a ON a.media_id=l.clicked_id"
           " WHERE l.link_type=? AND l.target_id IN (%s)"
           "   AND COALESCE(a.record_status,'LIVE')='LIVE'"
           "   AND a.media_type='WORSHIP'"
           "   AND COALESCE(l.record_status,'LIVE')='LIVE'" % ph)
    if lang and lang != '(전체)':
        sql += " AND UPPER(COALESCE(a.lang_code,''))=?"
        args.append(str(lang).upper())
    if q:
        sql += " AND a.title LIKE ?"
        args.append('%%%s%%' % q)
    sql += " ORDER BY l.target_id, a.media_id DESC"
    # ⚠ 이름·조회수·곡·사역자는 **한 번만** 읽는다 — 줄마다 물으면 그 수만큼 돈다.
    tname = {t: name_of(conn, t, lang if lang != '(전체)' else 'KO')
             for t in tids}
    try:
        import db_media_linkcheck as _LC
        views = _LC.views_of(conn)
    except Exception:
        views = {}
    song_of, art_of = {}, {}
    try:
        import db_song as _SG
        snm = {x[0]: x[1] for x in _SG.songs(conn)}
        for mid, sid in conn.execute(
                "SELECT l.clicked_id, r.song_id FROM sys_link_asset l"
                "  JOIN sys_song_rendition r ON r.rend_id=l.target_id"
                " WHERE l.link_type=?"
                "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
                # ⚠ **걷은 판의 곡 이름을 보이지 않는다**(§226차 상태 검사기가
                #   그 자리에서 잡았다).
                "   AND COALESCE(r.record_status,'LIVE')='LIVE',".replace(',', ''),
                (_SG.LINK_MEDI,)):
            song_of[mid] = snm.get(sid, '')
    except Exception:
        pass
    try:
        import db_worship_artist as _WA
        anm = {a[0]: a[1] for a in _WA.artists(conn)}
        for mid, aid in conn.execute(
                "SELECT clicked_id, target_id FROM sys_link_asset"
                " WHERE link_type=?"
                "   AND COALESCE(record_status,'LIVE')='LIVE'", (_WA.LINK,)):
            art_of[mid] = anm.get(aid, '')
    except Exception:
        pass
    out = []
    for lid, tid, mid, ti, url, d, lg, src, act, mt in conn.execute(sql, args):
        out.append(dict(link_id=lid, topic_id=tid, topic=tname.get(tid, ''),
                        media_id=mid, title=ti or '', url=url or '', desc=d,
                        lang=lg, mtype=mt,
                        why=_ML.src_label(src) if src else '',
                        views=(views.get(mid) or (None,))[0],
                        song=song_of.get(mid, ''), artist=art_of.get(mid, ''),
                        ok=bool(act)))
        if len(out) >= int(limit):
            break
    return out


def unlink_links(conn, link_ids):
    """**찬양–주제 연결해제** — 그 연결만 뗀다 → 뗀 수.

    ⚠⚠ **지우지 않는다** — 영상도 용어도 그대로 두고 잇던 줄만 내린다.
    ⚠ **사람이 정했다고 적는다** — 자동 추천이 도로 잇지 않게.
    """
    ids = [int(x) for x in (link_ids if isinstance(link_ids, (list, tuple, set))
                            else [link_ids]) if x]
    if not ids:
        return 0
    conn.execute("UPDATE sys_link_asset SET record_status='HIDE',"
                 " confidence='MANUAL' WHERE sys_link_id IN (%s)"
                 % ','.join('?' * len(ids)), ids)
    return len(ids)


#: ★ 「찬양은 아니지만 값이 있는 것」을 옮길 자리(2026-09-11 사용자).
NOT_WORSHIP_TYPES = (('STUDY', '성경공부'), ('SERMON', '설교'),
                     ('FILM', '영상물'), ('READING', '성경듣기'))


def not_worship(conn, media_ids, new_type='STUDY'):
    """**찬양이 아니다** — 찬양 더미에서 빼되 **자료는 남긴다** → 옮긴 수.

    ★★★ 2026-09-11 사용자 —
      「2단 목록에 **찬양과 관계없는 영상**이 표시되는 경우 … **찬양은 아니지만
       다른 컨텐츠로서는 가치가 있기 때문에 데이터에서 제거하지는 않는다**」.
      실측 그 자리 = 「긍휼」에 걸린 **바이블프로젝트 「긍휼 Compassion」**
      (성경공부 애니메이션인데 분류가 찬양이었다).
    ⓐ 분류를 옮기고 ⓑ **사람이 고쳤다고 적어**(`corrected_by='ADMIN'`)
      재분류가 도로 못 바꾸게 하고 ⓒ **찬양 쪽 연결(용어·곡·사역자)을 걷는다.**
    ⚠ **영상은 그대로 산다** — 다른 화면에서는 계속 보인다.
    ⚠ `sys_media_correction` 은 §203차 ⑤ 「되돌릴 근거이자 키워드 오답 노트」다.
    """
    import json as _js
    ids = [int(x) for x in (media_ids if isinstance(media_ids, (list, tuple,
                                                                set))
                            else [media_ids]) if x]
    if not ids:
        return 0
    n = 0
    for mid in ids:
        row = conn.execute(
            "SELECT COALESCE(media_type,''), COALESCE(title,''),"
            # status-ok: 번호 하나로 읽는 줄 — 가린 영상도 분류를 고쳐야 한다
            #   (상태로 거르면 삭제 보관함에 있는 것을 영영 못 고친다)
            "       COALESCE(description,''), COALESCE(lang_code,'')"
            "  FROM sys_media_asset WHERE media_id=?", (mid,)).fetchone()
        if not row:
            continue
        old, ti, d, lg = row
        ch = ''
        if d.startswith('{'):
            try:
                ch = _js.loads(d).get('channel') or ''
            except Exception:
                ch = ''
        conn.execute("UPDATE sys_media_asset SET media_type=?, is_active=0"
                     " WHERE media_id=?", (new_type, mid))
        try:
            conn.execute(
                "INSERT INTO sys_media_correction(media_id, original_type,"
                " corrected_type, corrected_by, title_snapshot,"
                " channel_snapshot, lang_code, corrected_at)"
                " VALUES(?,?,?,'ADMIN',?,?,?,date('now','localtime'))",
                (mid, old, new_type, ti[:300], ch[:120], lg))
        except Exception:
            pass
        # ★ 찬양 축의 연결을 걷는다 — 분류만 바꾸면 곡·사역자에 그대로 남는다
        for lt in _worship_link_types():
            conn.execute(
                "UPDATE sys_link_asset SET record_status='HIDE',"
                " confidence='MANUAL' WHERE link_type=? AND clicked_id=?"
                "   AND COALESCE(record_status,'LIVE')='LIVE'", (lt, mid))
        n += 1
    return n


def _worship_link_types():
    """찬양 축의 연결 갈래 — 용어(주제) · 곡 · 사역자."""
    out = [_lt()]
    try:
        import db_song as _SG
        out.append(_SG.LINK_MEDI)
    except Exception:
        pass
    try:
        import db_worship_artist as _WA
        out.append(_WA.LINK)
    except Exception:
        pass
    return out


def delete_media(conn, media_ids):
    """**영상 삭제** — 삭제 보관함으로 내린다 → 내린 수.

    ★ 2026-09-11 사용자 「근본적으로 **영상 자체를 제거**해야 할 상황(여행영상
      등)이 발생할 경우를 위해서」.
    ⚠⚠ **물리 삭제가 아니다** — `record_status='HIDE'`(삭제 보관함, §222차).
      그 자리가 이미 있고, 지우면 다음 수집에서 **같은 영상이 또 들어온다.**
    """
    ids = [int(x) for x in (media_ids if isinstance(media_ids, (list, tuple,
                                                                set))
                            else [media_ids]) if x]
    if not ids:
        return 0
    conn.execute("UPDATE sys_media_asset SET record_status='HIDE', is_active=0"
                 " WHERE media_id IN (%s)" % ','.join('?' * len(ids)), ids)
    return len(ids)


def title_hits(conn, lang='KO', q='', limit=300):
    """주제로 선택할 만한 용어 + **제목에 든 편 수** → [(eid, 이름, 유형, 편수)].

    ★ [제목에 걸리는 용어 보기] 팝업을 걷고 **후보 목록이 스스로 말하게** 한다
      (2026-09-10 사용자 「어디에 사용하라는 것인가? 그냥 참고? 제거하라」).
    """
    hit = {eid: n for n, eid, _nm in scan(conn, lang)}
    out = [(eid, nm, ty, hit.get(eid, 0))
           for eid, nm, ty in candidates(conn, lang, q, limit=limit)]
    # ★ 제목에 많이 든 것이 위로 — 그것이 씨앗으로 쓸 만한 말이다.
    out.sort(key=lambda r: (-r[3], r[1]))
    return out


def unclassified(conn, lang=None, pref=None, limit=300):
    """주제가 **하나도 안 붙은** 찬양.

    ★★ 이 줄이 없으면 856편 중 상당수가 어느 목록에도 안 걸려 **화면에서
      영영 안 보인다**. 목록 맨 아래 「분류 안 됨 (N편)」이 이것을 연다.
    """
    tids = topic_ids(conn)
    if not tids:
        ph, args = '', [_lt()]
        sub = ("SELECT 1 FROM sys_link_asset x WHERE x.clicked_id=a.media_id"
               "   AND x.link_type=? AND COALESCE(x.record_status,'LIVE')='LIVE'")
    else:
        ph = ','.join('?' * len(tids))
        args = [_lt()] + tids
        sub = ("SELECT 1 FROM sys_link_asset x WHERE x.clicked_id=a.media_id"
               "   AND x.link_type=? AND x.target_id IN (%s)"
               "   AND COALESCE(x.record_status,'LIVE')='LIVE'" % ph)
    q = ("SELECT a.media_id, a.title, a.url, COALESCE(a.description,'')"
         "  FROM sys_media_asset a WHERE " + _W +
         "   AND NOT EXISTS (" + sub + ")")
    if lang:
        q += " AND UPPER(COALESCE(a.lang_code,''))=?"
        args.append(str(lang).upper())
    out = []
    for mid, ti, url, d in conn.execute(q, args):
        if pref is not None:
            try:
                if pref.hidden(mid, d):
                    continue
            except Exception:
                pass
        out.append((mid, ti or '', url or '', d or ''))
        if len(out) >= int(limit):
            break
    return out


# ── 관리자 — 추천과 연결 ────────────────────────────────────────────────
def suggest(conn, entity_id, lang='KO', limit=200):
    """**제목에 그 용어 이름이 든** 승인 찬양 중 아직 안 이은 것.

    ⚠⚠ **추천이지 판정이 아니다.** 실측 「교회」 23편은 대개 채널 이름이고
      「영화」·「자존」은 딴 낱말의 조각이다(§228차 홑낱말 함정). 사람이 고른다.
    ⚠ **제목만 본다** — 설명문까지 보면 채널 안내에 걸려 오탐이 크게 는다.
    """
    names = [n for n in names_of(conn, entity_id, lang) if len(n) >= 2]
    if not names:
        return []
    have = {m for m, _t, _u, _d in media_of_topic(conn, entity_id,
                                                  limit=10 ** 9)}
    out = []
    for mid, ti, url, d in conn.execute(
            "SELECT a.media_id, a.title, a.url, COALESCE(a.description,'')"
            "  FROM sys_media_asset a WHERE " + _W):
        if mid in have:
            continue
        hit = next((n for n in names if n in (ti or '')), '')
        if not hit:
            continue
        out.append((mid, ti or '', url or '', d or '', hit))
        if len(out) >= int(limit):
            break
    return out


def link(conn, entity_id, media_ids, why='MANUAL', hint=''):
    """영상 ↔ 주제(용어) — **사람이 이은 것**이라 바로 LIVE → 새로 이은 수.

    ⚠ 이미 있으면 되살린다(행이 한 벌씩 늘면 안 된다).
    """
    import media_link as _ML
    # ★★★ **근거를 함께 적는다**(2026-09-10 사용자 「가사에서 추출한 것인지
    #   임의로 만든 것인지 알 수 없을 것이다」) — 무엇을 보고 이었는지.
    _src = _ML.src(why, hint)
    ty = _lt()
    n = 0
    for m in (media_ids if isinstance(media_ids, (list, tuple, set))
              else [media_ids]):
        if m is None:
            continue
        r = conn.execute(
            "SELECT sys_link_id FROM sys_link_asset"
            " WHERE link_type=? AND clicked_id=? AND target_id=?",
            (ty, int(m), int(entity_id))).fetchone()  # status-ok: 있는 줄 확인 — 가림도 있는 줄이다
        if r:
            conn.execute("UPDATE sys_link_asset SET record_status='LIVE',"
                         " confidence='MANUAL', source=?"
                         " WHERE sys_link_id=?", (_src, r[0]))
        else:
            conn.execute(
                "INSERT INTO sys_link_asset(clicked_id, target_id, link_type,"
                "  record_status, confidence, source)"
                " VALUES(?,?,?,'LIVE','MANUAL',?)",
                (int(m), int(entity_id), ty, _src))
            n += 1
    return n


def unlink(conn, entity_id, media_ids):
    """연결을 걷는다(지우지 않는다) → 걷은 수."""
    ty = _lt()
    ms = [int(m) for m in (media_ids if isinstance(media_ids, (list, tuple, set))
                           else [media_ids]) if m is not None]
    if not ms:
        return 0
    conn.execute(
        "UPDATE sys_link_asset SET record_status='HIDE'"
        " WHERE link_type=? AND target_id=? AND clicked_id IN (%s)"
        % ','.join('?' * len(ms)), [ty, int(entity_id)] + ms)
    return len(ms)


def candidates(conn, lang='KO', q='', limit=500):
    """주제로 선택할 만한 용어 [(entity_id, 이름, 유형)].

    ⚠⚠ **기계 낱말(`W_`)은 뺀다** — 실측 TERM 11,013 중 10,892 가 사전에서
      기계로 뽑은 것이라 그대로 두면 목록이 못 읽을 만큼 길어진다.
      사람이 만든 용어는 121 개이고 교리·사물·절기를 합쳐 199 개다.
    """
    sql = ("SELECT t.clicked_id, t.contents, e.entity_type"
           "  FROM sys_text_asset t"
           "  JOIN sys_entity_master e ON e.entity_id=t.clicked_id"
           " WHERE t.text_type='ENTITY_NAME' AND UPPER(t.lang_code)=?"
           "   AND substr(e.entity_code,1,2)<>'W_'"
           "   AND COALESCE(e.record_status,'LIVE')='LIVE'"
           "   AND COALESCE(t.record_status,'LIVE')='LIVE'")
    args = [str(lang).upper()]
    if (q or '').strip():
        sql += " AND t.contents LIKE ?"
        args.append('%%%s%%' % q.strip())
    sql += " ORDER BY t.contents LIMIT ?"
    args.append(int(limit))
    return [(r[0], r[1], r[2]) for r in conn.execute(sql, args)]


def scan(conn, lang='KO', top=30):
    """제목에 걸리는 용어 상위 — **주제 씨앗을 선택할 재료**(판정이 아니다)."""
    titles = [(r[0], r[1] or '') for r in conn.execute(
        "SELECT a.media_id, a.title FROM sys_media_asset a WHERE " + _W)]
    byid = {}
    for eid, nm, _ty in candidates(conn, lang):
        if len(nm) >= 2:
            byid.setdefault(eid, []).append(nm)
    out = []
    for eid, names in byid.items():
        ms = {mid for mid, ti in titles if any(n in ti for n in names)}
        if ms:
            out.append((len(ms), eid, names[0]))
    out.sort(reverse=True)
    return out[:int(top)]


# ── 씨앗 ────────────────────────────────────────────────────────────────
#: 없는 용어를 만든다 — (코드, 유형, 한국어, 영어)
#: ⚠ 사용자 지시(2026-09-10) 「감사, 은혜, 십자가, **보혈**…」 중 보혈이 용어로
#:   없었다. 함께 없던 것 = 소망 · 예배 · 치유 · 경배.
#: ⚠⚠ **한국어 자동 연결기는 이 유형을 안 연다**(`media_text_linker.
#:   TYPES_BY_LANG` — EN 만 열려 있다. 한국어는 이름이 일상어라 오탐 70%).
#:   그래서 「예배」 같은 흔한 말을 더해도 **자동 연결이 폭주하지 않는다.**
NEW_TERMS = (
    ('D_PRECIOUS_BLOOD', 'DOCTRINE', '보혈', 'Precious Blood'),
    ('D_HOPE', 'DOCTRINE', '소망', 'Hope'),
    ('D_WORSHIP', 'DOCTRINE', '예배', 'Worship'),
    ('T_HEALING', 'TERM', '치유', 'Healing'),
    ('D_COMFORT', 'DOCTRINE', '위로', 'Comfort'),
)

#: 주제 씨앗 — **한국어 이름으로 찾는다**(번호는 DB 마다 다르다).
#:   차례가 곧 사용자 화면 차례다. 자주 찾는 것을 앞에.
TOPIC_SEED = ('은혜', '감사', '사랑', '보혈', '십자가', '영광', '소망', '예배',
              '평강', '기쁨', '위로', '능력', '기도', '구원', '믿음',
              '거룩', '긍휼', '부활', '회개', '언약', '치유', '목자')


def ensure_terms(conn, log=print):
    """없는 주제 용어를 만든다(멱등) → 새로 만든 수.

    ⚠ 이름은 `sys_text_asset('ENTITY_NAME')` 에 **언어마다 한 행**(§0-3).
    ⚠ 이미 같은 코드가 있으면 **아무것도 안 한다** — 사람이 고친 값을 안 덮는다.
    """
    n = 0
    for code, ty, ko, en in NEW_TERMS:
        r = conn.execute("SELECT entity_id FROM sys_entity_master"
                         " WHERE entity_code=?", (code,)).fetchone()  # status-ok: 있는 줄 확인 — 가림도 있는 줄이다
        if r:
            continue
        # ★★★ **`subtype='TOPIC'` 을 박는다** — 이 낱말들은 **찬양 주제로만**
        #   쓴다. 실측 「예배」가 영상 제목 **1,839편**에 들어 있어, 그대로
        #   두면 자동 분류·추천이 통째로 이 낱말에 끌려간다(§228차 홑낱말
        #   함정). 기계 낱말(`LEX`)을 빼는 그 장치를 그대로 쓴다.
        cur = conn.execute(
            "INSERT INTO sys_entity_master(entity_code, entity_type,"
            "  importance, json_detail, record_status)"
            " VALUES(?,?,?,'{\"subtype\": \"TOPIC\"}','LIVE')",
            (code, ty, 7))
        eid = cur.lastrowid
        for lg, nm in (('KO', ko), ('EN', en)):
            conn.execute(
                "INSERT INTO sys_text_asset(clicked_id, text_type, contents,"
                "  lang_code, record_status) VALUES(?,'ENTITY_NAME',?,?,'LIVE')",
                (eid, nm, lg))
        n += 1
        log('  새 용어 %s (%s) #%d' % (ko, code, eid))
    return n


def find_by_name(conn, name, lang='KO'):
    """한국어 이름으로 용어 번호를 찾는다 → entity_id | None.

    ⚠ **묶인 이름 안에서도 찾는다**(`'감사 · 토다'`) — 그러지 않으면 씨앗의
      절반이 안 걸린다(2026-09-10 실측).
    ⚠ 기계 낱말(`W_`)은 뺀다.
    ⚠⚠ **후보 목록을 훑어 찾지 않는다** — 그 문은 화면용이라 상한이 있어
      뒤쪽 이름(평강·회개)이 잘려 나갔다(2026-09-10 실측: 씨앗 셋이 조용히
      빠졌다). 이름으로 **곧장 좁혀** 묻는다.
    """
    for eid, nm, _ty in candidates(conn, lang, name, limit=200):
        if name in split_names(nm):
            return eid
    return None


def seed(conn, log=print):
    """주제 씨앗 → (만든 용어 수, 선택한 주제 수, 못 찾은 이름).

    ⚠ **이미 고른 것이 있으면 안 덮는다** — 사람이 정한 차례가 우선이다.
    """
    made = ensure_terms(conn, log)
    cur = topic_ids(conn)
    if cur:
        log('  이미 선택한 주제 %d개가 있어 그대로 둡니다.' % len(cur))
        return made, len(cur), []
    ids, miss = [], []
    for nm in TOPIC_SEED:
        eid = find_by_name(conn, nm)
        if eid:
            ids.append(eid)
        else:
            miss.append(nm)
    save(conn, ids)
    return made, len(ids), miss


def seed_links(conn, note='TOPIC_SEED', log=print):
    import media_link as _ML
    """선택한 주제마다 **제목에 이름이 든 것**을 잇는다 → 이은 수.

    ⚠⚠ **추천을 그대로 받는 것이라 사람 확인이 아니다.** 되돌릴 수 있게
      `note` 를 적는다(`--unlink-seed`). 관리 화면에서 하나씩 보는 것이 정본.
    """
    ty = _lt()
    n = 0
    for eid, nm, _c in topics(conn, 'KO'):
        got = suggest(conn, eid, 'KO', limit=10 ** 9)
        for mid, _ti, _u, _d, _hit in got:
            _s = _ML.src('TITLE', _hit)
            # ⚠ 이미 있는 줄(가림 포함)이면 **되살린다** — 새 행을 만들면
            #   같은 연결이 두 벌이 된다.
            r = conn.execute(
                "SELECT sys_link_id FROM sys_link_asset"
                " WHERE link_type=? AND clicked_id=? AND target_id=?",
                (ty, mid, eid)).fetchone()  # status-ok: 있는 줄 확인 — 가림도 있는 줄이다
            if r:
                conn.execute(
                    "UPDATE sys_link_asset SET record_status='LIVE',"
                    " source=?, note=? WHERE sys_link_id=?", (_s, note, r[0]))
            else:
                conn.execute(
                    "INSERT INTO sys_link_asset(clicked_id, target_id,"
                    "  link_type, record_status, confidence, source, note)"
                    " VALUES(?,?,?,'LIVE','AUTO',?,?)",
                    (mid, eid, ty, _s, note))
            n += 1
        if got:
            log('  %-6s %d편' % (nm, len(got)))
    return n


def restamp(conn, log=print):
    """이미 이어 둔 주제 연결에 **근거를 되짚어 적는다** → 적은 수.

    ★ 사용자 지시(2026-09-10) — 나중에 「무엇을 보고 이었나」를 알 수 있어야
      한다. 이미 있는 연결은 그때 걸린 말을 다시 찾아 적는다.
    ⚠ **제목에서 다시 못 찾으면 안 적는다** — 지어내면 근거가 거짓이 된다.
      그런 줄은 `SEED`(씨앗으로 걸었으나 지금 제목에는 없음)로만 남긴다.
    """
    import media_link as _ML
    ty = _lt()
    n = fuzzy = 0
    for eid, nm, _k in topics(conn, 'KO'):
        names = [x for x in names_of(conn, eid, 'KO') if len(x) >= 2]
        for lid, mid, ti in conn.execute(
                "SELECT l.sys_link_id, l.clicked_id, COALESCE(a.title,'')"
                "  FROM sys_link_asset l"
                "  JOIN sys_media_asset a ON a.media_id=l.clicked_id"
                " WHERE l.link_type=? AND l.target_id=?"
                "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
                # status-ok: **근거를 되짚어 적는 자리** — 가린 영상의 연결도
                #   근거는 옳아야 한다(글자를 고치는 일이지 목록이 아니다)
                , (ty, eid)):
            hit = next((x for x in names if x in ti), '')
            conn.execute('UPDATE sys_link_asset SET source=? WHERE sys_link_id=?',
                         (_ML.src('TITLE', hit) if hit else _ML.src('SEED'), lid))
            if hit:
                n += 1
            else:
                fuzzy += 1
    log('  근거를 적었다 — 제목에서 찾음 %d · 못 찾음 %d(SEED 로만)' % (n, fuzzy))
    return n + fuzzy


def unlink_seed(conn, note='TOPIC_SEED'):
    """씨앗으로 이은 것만 걷는다 → 걷은 수."""
    cur = conn.execute(
        "UPDATE sys_link_asset SET record_status='HIDE'"
        " WHERE link_type=? AND COALESCE(note,'')=?", (_lt(), note))
    return cur.rowcount


# ── 자가검증 ────────────────────────────────────────────────────────────
def selftest():
    import appdb
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0 if cond else 1] += 1
        print(('  OK   ' if cond else '  실패 ') + name
              + ('' if cond else '  ' + str(extra)))

    conn = appdb.connect(appdb.MAIN_DB)
    try:
        conn.execute('BEGIN')
        base = topic_ids(conn)
        t('★ 선택한 목록을 읽는다', isinstance(base, list))
        t('★★ 차례를 지키고 겹침을 지운다',
          save(conn, [319, 183, 319, 318]) == 3
          and topic_ids(conn) == [319, 183, 318])
        t('★ 글자로 와도 숫자로 담는다',
          save(conn, ['319', ' ', 183]) == 2 and topic_ids(conn) == [319, 183])
        t('★★ 이름을 찾는다 · 못 찾으면 **번호를 그대로**',
          name_of(conn, 319) == '은혜' and name_of(conn, -7) == '#-7')
        t('★ 그 용어의 이름 전부를 낸다(원어 음역 포함)',
          len(names_of(conn, 319)) >= 1)
        # ★★★ 묶인 이름 쪼개기 (2026-09-10 실측으로 잡은 자리)
        t('★★★ **가운뎃점으로 묶인 이름을 쪼갠다**',
          split_names('감사 · 토다') == ['감사', '토다'])
        t('★★ 셋 이상도 쪼갠다',
          split_names('사랑 · 아하브 · 아가페') == ['사랑', '아하브', '아가페'])
        t('★★ 괄호 표기도 연다(§232차)',
          split_names('Resurrection (anastasis)')
          == ['Resurrection', 'anastasis'])
        t('★★ **한 글자는 버린다**(§228차 홑낱말 함정)',
          split_names('피 · 담 · 하이마') == ['하이마'])
        t('★ 묶이지 않은 이름은 그대로', split_names('십자가') == ['십자가'])
        t('★★ 화면 이름표는 **첫 표기 하나**',
          name_of(conn, 471) in ('감사', '#471'))
        # ⚠ **데이터 상태에 걸지 않는다**(§0-5) — 다 이어 놓으면 추천이 0이
        #   되어 검사가 깨진다. 「쪼개진 이름이 실제로 쓰이는가」를 잰다.
        t('★★★ **쪼갠 이름이 대조에 쓰인다**',
          '감사' in names_of(conn, 471)
          and '토다' in names_of(conn, 471))

        got = topics(conn, 'KO')
        t('★ 주제 목록이 선택한 차례 그대로다',
          [g[0] for g in got] == [319, 183])
        t('★ 편 수가 함께 온다', all(isinstance(g[2], int) for g in got))

        sg = suggest(conn, 319, limit=50)
        t('★★★ **제목에 이름이 든 것만 추천한다**',
          all('은혜' in ti for _m, ti, _u, _d, _h in sg), sg[:2])
        t('★★ **이미 이은 것은 추천에 안 낸다**',
          not ({m for m, _t2, _u, _d, _h in sg}
               & {m for m, _t3, _u2, _d2 in media_of_topic(conn, 319,
                                                           limit=10 ** 9)}))
        t('★ 설명문은 안 본다(제목만)',
          all('은혜' in ti for _m, ti, _u, _d, _h in sg))

        # ⚠⚠⚠ **`rollback` 을 믿으면 안 된다**(2026-09-11에 실제로 샜다) —
        #   이 아래가 부르는 문들이 안에서 `ensure()`·`init()` 을 부르고 그것이
        #   **`commit` 을 하면 트랜잭션이 거기서 끊긴다.** 그러면 시험이 가린
        #   연결이 **배포 DB 에 그대로 남는다.** 실측 — 씨앗 연결 셋이
        #   `HIDE·MANUAL` 로 남아 있었다(감사 로그 20:17:57.406/.409/.410 —
        #   **4밀리초 안에 셋**이라 사람이 아니라 시험이다).
        #   ⇒ **손댄 줄을 스스로 적어 두고 끝에 되돌린다**(§0-5).
        _undo = []

        def _snap(link_id):
            r = conn.execute("SELECT record_status, confidence"
                             "  FROM sys_link_asset WHERE sys_link_id=?",
                             (link_id,)).fetchone()
            if r:
                _undo.append((link_id, r[0], r[1]))

        if sg:
            mid = sg[0][0]
            n0 = len(media_of_topic(conn, 319, limit=10 ** 9))
            t('★★ 이으면 목록에 든다',
              link(conn, 319, [mid]) == 1
              and mid in {m for m, _t4, _u3, _d3
                          in media_of_topic(conn, 319, limit=10 ** 9)})
            t('★★ **다시 이어도 행이 안 는다**(멱등)',
              link(conn, 319, [mid]) == 0
              and len(media_of_topic(conn, 319, limit=10 ** 9)) == n0 + 1)
            t('★★ 걷으면 목록에서 빠진다',
              unlink(conn, 319, [mid]) == 1
              and mid not in {m for m, _t5, _u4, _d4
                              in media_of_topic(conn, 319, limit=10 ** 9)})
            t('★ 걷은 것은 **지우지 않는다**(되살릴 자리가 남는다)',
              conn.execute("SELECT record_status FROM sys_link_asset"
                           " WHERE link_type=? AND clicked_id=? AND target_id=?",
                           (_lt(), mid, 319)).fetchone()[0] == 'HIDE')
            # ★ 시험이 만든 줄은 **지운다**(없던 것이다)
            conn.execute("DELETE FROM sys_link_asset WHERE link_type=?"
                         "   AND clicked_id=? AND target_id=319", (_lt(), mid))
            conn.commit()
            t('★★★ **시험 자국이 안 남는다**(`rollback` 을 안 믿는다)',
              not conn.execute(
                  "SELECT 1 FROM sys_link_asset WHERE link_type=?"
                  "   AND clicked_id=? AND target_id=319",
                  (_lt(), mid)).fetchone())
        else:
            t('★ 추천 표본이 없어 건너뜀', True)

        un = unclassified(conn, limit=10 ** 9)
        allw = conn.execute("SELECT COUNT(*) FROM sys_media_asset a WHERE "
                            + _W).fetchone()[0]
        t('★★★ **분류 안 된 찬양을 셀 수 있다**(%d / %d)' % (len(un), allw),
          0 <= len(un) <= allw)
        t('★★ 주제가 붙은 것은 분류 안 됨에 **안 든다**',
          not ({m for m, _t6, _u5, _d5 in un}
               & {m for e, _n2, _c in topics(conn, 'KO')
                  for m, _t7, _u6, _d6 in media_of_topic(conn, e,
                                                         limit=10 ** 9)}))

        cd = candidates(conn, 'KO')
        t('★★ **기계 낱말(W_)을 뺀다**(11,013 → 몇백)', 0 < len(cd) < 1000,
          len(cd))
        t('★ 이름으로 좁힌다',
          all('은혜' in nm for _e, nm, _ty in candidates(conn, 'KO', '은혜')))

        import media_pref
        if got and got[0][2]:
            one = media_of_topic(conn, got[0][0], limit=1)[0][0]
            pr = media_pref.Pref(hide_m={one})
            t('★★ **내가 숨긴 영상은 안 나온다**(§226차 덮개)',
              one not in {m for m, _t8, _u7, _d7
                          in media_of_topic(conn, got[0][0], pref=pr,
                                            limit=10 ** 9)})
        else:
            t('★ 덮개 표본 없음 — 건너뜀', True)

        import ast as _ast
        _tree = _ast.parse(io.open(__file__, encoding='utf-8').read())
        _imp = set()
        for _nd in _ast.walk(_tree):
            if isinstance(_nd, _ast.Import):
                _imp |= {al.name.split('.')[0] for al in _nd.names}
            elif isinstance(_nd, _ast.ImportFrom) and _nd.module:
                _imp.add(_nd.module.split('.')[0])
        t('★ 위젯 꾸러미를 안 부른다 — **데이터 층**이다(§121차)',
          not (_imp & {'tk' + 'inter', 'ttk'}), sorted(_imp))

        # ★★★ 검증 화면이 쓰는 문 — **판단할 정보가 실제로 실리는가**
        #   (2026-09-10 사용자 「판단할 정보가 전혀 없다는 것이 문제다」)
        rr = review_rows(conn, lang='KO', limit=50)
        t('★★★ 주제를 안 주면 **전부** 한 목록으로 낸다 (%d줄)' % len(rr),
          isinstance(rr, list))
        t('★★★ 줄마다 **근거·주제·연결번호·분류**가 실린다',
          all({'why', 'topic', 'link_id', 'mtype'} <= set(r) for r in rr))
        if rr:
            t('★★ 근거가 **사람이 읽는 말**이다 (%s)'
              % (rr[0]['why'] or '(빈칸)'), '_' not in (rr[0]['why'] or ''),
              rr[0]['why'])
            t('★★ 조회수·곡·사역자 칸이 있다',
              all({'views', 'song', 'artist'} <= set(r) for r in rr))
            one = review_rows(conn, rr[0]['topic_id'], lang='KO', limit=50)
            t('★ 주제를 주면 **그 주제만** 낸다',
              all(r['topic_id'] == rr[0]['topic_id'] for r in one), len(one))
        else:
            t('★ 검증 줄 표본 없음 — 건너뜀', True)
        # ★★★ 세 갈래 조치(2026-09-11 사용자) — **되돌릴 수 있는가**를 잰다
        rr2 = review_rows(conn, None, lang='(전체)', limit=3)
        if rr2:
            _r = rr2[0]
            # ⚠⚠ **되돌릴 것을 먼저 적어 둔다** — 위 설명 참조.
            _b0 = conn.execute(
                "SELECT record_status, confidence FROM sys_link_asset"
                " WHERE sys_link_id=?", (_r['link_id'],)).fetchone()
            _m0 = conn.execute(
                "SELECT media_type, COALESCE(is_active,0), record_status"
                "  FROM sys_media_asset WHERE media_id=?",
                (_r['media_id'],)).fetchone()
            _l0 = [tuple(x) for x in conn.execute(
                "SELECT sys_link_id, record_status, COALESCE(confidence,'')"
                "  FROM sys_link_asset WHERE clicked_id=? AND link_type IN (%s)"
                % ','.join('?' * len(_worship_link_types())),
                [_r['media_id']] + _worship_link_types())]
            _c0 = conn.execute("SELECT MAX(corr_id) FROM sys_media_correction"
                               ).fetchone()[0] or 0
            unlink_links(conn, [_r['link_id']])
            _st = conn.execute("SELECT record_status FROM sys_link_asset"
                               " WHERE sys_link_id=?",
                               (_r['link_id'],)).fetchone()[0]
            t('★★★ 「찬양–주제 연결해제」가 실제로 뗀다', _st == 'HIDE', _st)
            _mid = _r['media_id']
            _old = conn.execute("SELECT media_type FROM sys_media_asset"
                                " WHERE media_id=?", (_mid,)).fetchone()[0]
            not_worship(conn, [_mid], 'STUDY')
            _new, _act = conn.execute(
                "SELECT media_type, COALESCE(is_active,0)"
                "  FROM sys_media_asset WHERE media_id=?", (_mid,)).fetchone()
            t('★★★ 「찬양아님」이 **분류를 옮기고 승인을 내린다** (%s→%s)'
              % (_old, _new), _new == 'STUDY' and not _act)
            t('★★★ **영상은 산다**(삭제가 아니다)',
              conn.execute("SELECT record_status FROM sys_media_asset"
                           " WHERE media_id=?", (_mid,)).fetchone()[0] != 'HIDE')
            t('★★ 사람이 고쳤다고 적는다(재분류가 못 되돌린다)',
              conn.execute("SELECT COUNT(*) FROM sys_media_correction"
                           " WHERE media_id=? AND corrected_by='ADMIN'",
                           (_mid,)).fetchone()[0] >= 1)
            t('★★ 찬양 축 연결이 함께 걷힌다',
              not conn.execute(
                  "SELECT 1 FROM sys_link_asset WHERE clicked_id=?"
                  "   AND link_type IN (%s)"
                  "   AND COALESCE(record_status,'LIVE')='LIVE'"
                  % ','.join('?' * len(_worship_link_types())),
                  [_mid] + _worship_link_types()).fetchone())
            delete_media(conn, [_mid])
            t('★★★ 「영상 삭제」는 **삭제 보관함**이다(물리 삭제가 아니다)',
              conn.execute("SELECT record_status FROM sys_media_asset"
                           " WHERE media_id=?", (_mid,)).fetchone()[0] == 'HIDE')
            t('★★ 갈 수 있는 분류가 넷이다 %s'
              % [k for k, _v in NOT_WORSHIP_TYPES],
              len(NOT_WORSHIP_TYPES) == 4)
            # ★★★ **손으로 되돌린다** — `rollback` 을 안 믿는다
            conn.execute("UPDATE sys_media_asset SET media_type=?,"
                         " is_active=?, record_status=? WHERE media_id=?",
                         (_m0[0], _m0[1], _m0[2], _r['media_id']))
            for _lid, _st, _cf in _l0:
                conn.execute("UPDATE sys_link_asset SET record_status=?,"
                             " confidence=? WHERE sys_link_id=?",
                             (_st, _cf or None, _lid))
            if _b0:
                conn.execute("UPDATE sys_link_asset SET record_status=?,"
                             " confidence=? WHERE sys_link_id=?",
                             (_b0[0], _b0[1], _r['link_id']))
            conn.execute("DELETE FROM sys_media_correction WHERE corr_id>?",
                         (_c0,))
            conn.commit()
            _m1 = conn.execute(
                "SELECT media_type, COALESCE(is_active,0), record_status"
                "  FROM sys_media_asset WHERE media_id=?",
                (_r['media_id'],)).fetchone()
            t('★★★ **시험 자국이 안 남는다** — 영상 %s → %s'
              % (_m0, _m1), _m0 == _m1)
            t('★★★ 연결도 제자리 · 교정 기록도 안 남는다',
              all(conn.execute("SELECT record_status FROM sys_link_asset"
                               " WHERE sys_link_id=?", (_l,)).fetchone()[0] == _s
                  for _l, _s, _c in _l0)
              and (conn.execute("SELECT MAX(corr_id) FROM sys_media_correction"
                                ).fetchone()[0] or 0) == _c0)
        else:
            t('★ 세 갈래 조치 표본 없음 — 건너뜀', True)
        th = title_hits(conn, 'KO', '', limit=40)
        t('★★ 후보가 **제목에 든 편 수** 차례로 온다 (%d개)' % len(th),
          all(th[i][3] >= th[i + 1][3] for i in range(len(th) - 1)),
          [x[3] for x in th[:6]])
    finally:
        conn.rollback()
        conn.close()
    print('db_worship_topic selftest %d/%d' % (ok[0], ok[0] + ok[1]))
    return ok[1] == 0


def main():
    import appdb
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(appdb.MAIN_DB)
    try:
        if '--seed' in sys.argv:
            made, n, miss = seed(conn)
            conn.commit()
            print('용어 새로 %d개 · 주제 %d개' % (made, n))
            if miss:
                print('⚠ 못 찾은 이름:', ' · '.join(miss))
            return
        if '--restamp' in sys.argv:
            n = restamp(conn)
            conn.commit()
            print('근거 %d건' % n)
            return
        if '--seed-links' in sys.argv:
            n = seed_links(conn)
            conn.commit()
            print('씨앗 연결 %d건 — 되돌리기: --unlink-seed' % n)
            return
        if '--unlink-seed' in sys.argv:
            n = unlink_seed(conn)
            conn.commit()
            print('씨앗 연결 %d건 걷음' % n)
            return
        if '--scan' in sys.argv:
            print('제목에 걸리는 용어 상위 — 주제 씨앗 재료(판정 아님)')
            for n, eid, nm in scan(conn):
                print('   %-14s #%-6d %3d편' % (nm, eid, n))
            return
        got = topics(conn, 'KO')
        if not got:
            print('선택한 주제가 없습니다 — 관리자 「찬양 수집기 ▸ 주제」에서 선택합니다.')
        for eid, nm, n in got:
            print('   %-14s #%-6d %3d편' % (nm, eid, n))
        print('   분류 안 됨 %d편' % len(unclassified(conn, limit=10 ** 9)))
    finally:
        conn.close()


if __name__ == '__main__':
    main()
