# -*- coding: utf-8 -*-
"""plan_build.py — 「새 플랜 만들기」 마법사와 수정 창이 함께 쓰는 **일정 계산**(2026-10-15 · docs/1.txt 87·88).

화면이 없다. 마법사(`plan_wizard`)와 「내 플랜 수정하기」 창(`my_plan_edit`)이 같은 문을 쓴다 — 두 곳이 따로
계산하면 「마법사에서 본 분량과 수정 창의 분량이 다르다」가 난다.

· `units(conn, books, unit, version, lang)` — 고른 책을 **장** 또는 **단락**(BODY 페리코프 · 성경 전체를 빈틈없이 덮는다)으로.
  하나마다 (첫 절, 끝 절, 글자 수, 제목).
· 글자 수 = 그 역본 본문의 **공백을 뺀 글자 수**(사용자 확정 2026-10-14 · 모든 언어 같은 잣대).
· `distribute(units, ndays, cap)` — 장·단락을 **자르지 않고** 날마다 고르게. 상한을 넘으면 다음 날로.
· `merge(days, i)` · `split(conn, version, days, i)` — 다음 날과 합치기 / 둘로 나누기(가장 고르게 나뉘는 자리를
  저절로 — 단락 경계 먼저, 단락이 하나면 절).
· 일정 꼴은 `plan_share.save_plan` 이 받는 그대로 — [{d, sec, q, r:[{v:[a,b], ref, f}]}].

`--selftest` 의무.
"""
import datetime
import sys

import appdb

# 정경 분류 — 1단계 「분류」 칩(책 번호 범위)
GENRES = (
    ('LAW', '율법서', 1, 5), ('HIST', '역사서', 6, 17), ('POET', '시가서', 18, 22),
    ('MPROPH', '대선지서', 23, 27), ('XPROPH', '소선지서', 28, 39),
    ('GOSPEL', '복음서', 40, 43), ('ACTS', '사도행전', 44, 44), ('PAUL', '바울서신', 45, 57),
    ('GENEP', '일반서신', 58, 65), ('REV', '요한계시록', 66, 66),
)
OT = tuple(range(1, 40))
NT = tuple(range(40, 67))


def version_of(lang):
    try:
        import db_cite_gate
        return db_cite_gate.VERSION_OF.get((lang or 'KO').upper()) or 'BSB'
    except Exception:
        return 'KRV' if (lang or 'KO').upper() == 'KO' else 'BSB'


def verse_lens(conn, version, books):
    """[(vid, bcode, chapter, verse, 글자)] — 그 책들 · 성경 차례."""
    if not books:
        return []
    ph = ','.join('?' * len(books))
    return conn.execute(
        "SELECT b.verse_id, b.bcode, b.chapter, b.verse, "
        "COALESCE(LENGTH(REPLACE(REPLACE(c.verse_text,' ',''),char(10),'')),0) "
        "FROM bible_index b LEFT JOIN bible_content c ON c.verse_id=b.verse_id AND c.version_code=? "
        "WHERE b.bcode IN (%s) ORDER BY b.bcode, b.chapter, b.verse" % ph,
        [version] + list(books)).fetchall()


def _peri_title(conn, pid, lang):
    rows = conn.execute("SELECT UPPER(lang_code), title FROM sys_text_asset WHERE text_type='PERI_TITLE' "
                        "AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'", (pid,)).fetchall()
    by = {lg: (t or '').strip() for lg, t in rows if (t or '').strip()}
    return by.get((lang or 'KO').upper()) or by.get('EN') or by.get('KO') or ''


def _book_name(conn, bcode, lang):
    for lg in ((lang or 'KO').upper(), 'EN', 'KO'):
        r = conn.execute("SELECT full_name FROM book_names WHERE book_code=? AND UPPER(lang_code)=?",
                         (bcode, lg)).fetchone()
        if r and r[0]:
            return r[0]
    return str(bcode)


def units(conn, books, unit='PERI', version='KRV', lang='KO'):
    """고른 책 → 단위 목록 [{a, b, n, title}] (성경 차례). unit = 'CHAP' | 'PERI'."""
    vs = verse_lens(conn, version, sorted(set(int(x) for x in books)))
    if not vs:
        return []
    out = []
    if unit == 'CHAP':
        cur = None
        for vid, bc, ch, _v, n in vs:
            if cur and cur['key'] == (bc, ch):
                cur['b'], cur['n'] = vid, cur['n'] + n
            else:
                cur = {'key': (bc, ch), 'a': vid, 'b': vid, 'n': n,
                       'title': '%s %d' % (_book_name(conn, bc, lang), ch)}
                out.append(cur)
        for u in out:
            u.pop('key', None)
        return out
    # 단락 — BODY 페리코프 시작 절로 자른다(시작이 고른 범위 안에 있는 것만)
    vids = [r[0] for r in vs]
    pos = {v: i for i, v in enumerate(vids)}
    starts = {}
    for pid, a in conn.execute("SELECT pericope_id, start_vid FROM sys_pericope_asset WHERE peri_type='BODY' "
                               "AND COALESCE(record_status,'LIVE')='LIVE'"):
        if a in pos:
            starts[pos[a]] = pid
    cuts = sorted(set(starts) | {0} | {i for i in range(1, len(vs)) if vs[i][1] != vs[i - 1][1]})
    for k, i in enumerate(cuts):
        j = (cuts[k + 1] if k + 1 < len(cuts) else len(vs)) - 1
        pid = starts.get(i)
        out.append({'a': vids[i], 'b': vids[j], 'n': sum(r[4] for r in vs[i:j + 1]),
                    'title': _peri_title(conn, pid, lang) if pid else ''})
    return out


def reading_days(mode, value, weekdays=(0, 1, 2, 3, 4, 5, 6), today=None):
    """읽는 날 수. mode='DAYS'(value=일수) → 그 기간 안 고른 요일 수(비율) · 'UNTIL'(value='YYYY-MM-DD') → 오늘부터 그날까지 고른 요일."""
    wd = set(weekdays) or set(range(7))
    if mode == 'UNTIL':
        today = today or datetime.date.today()
        end = datetime.date.fromisoformat(value)
        if end < today:
            return 0
        n, d = 0, today
        while d <= end:
            n += d.weekday() in wd
            d += datetime.timedelta(days=1)
        return n
    days = int(value)
    return max(1, round(days * len(wd) / 7))


def distribute(us, ndays, cap=None):
    """단위를 자르지 않고 ndays 날에 고르게 → [[단위, …], …]. 단위보다 날이 많으면 단위 수로 줄인다."""
    us = list(us)
    if not us:
        return []
    ndays = max(1, min(int(ndays), len(us)))
    out, i = [], 0
    for d in range(ndays):
        left = ndays - d
        rem = sum(u['n'] for u in us[i:])
        tgt = rem / left
        grp, s = [us[i]], us[i]['n']
        i += 1
        while i < len(us) and len(us) - i > left - 1:
            nxt = s + us[i]['n']
            if cap and nxt > cap:
                break
            if abs(nxt - tgt) < abs(s - tgt):
                grp.append(us[i])
                s = nxt
                i += 1
            else:
                break
        out.append(grp)
    if i < len(us):              # 상한 때문에 남은 것 — 날을 늘려 담는다
        while i < len(us):
            grp, s = [us[i]], us[i]['n']
            i += 1
            while i < len(us) and (not cap or s + us[i]['n'] <= cap):
                grp.append(us[i])
                s += us[i]['n']
                i += 1
            out.append(grp)
    return out


def _next_vid(conn, v):
    r = conn.execute("SELECT MIN(verse_id) FROM bible_index WHERE verse_id>?", (v,)).fetchone()
    return r[0] if r else None


def _join_rows(conn, rows):
    """이어지는 범위는 한 줄로 합친다."""
    out = []
    for r in rows:
        a, b = r['v'][0], r['v'][-1]
        if out and not out[-1].get('f') and not r.get('f') and _next_vid(conn, out[-1]['v'][-1]) == a:
            out[-1]['v'] = [out[-1]['v'][0], b]
        else:
            out.append({'v': [a, b], 'f': r.get('f') or ''})
    return out


def to_days(conn, groups):
    """distribute 결과 → 일정 꼴(save_plan 이 받는 것) · 읽을 곳 글자는 그 언어 약명."""
    import plan_share as PS
    days = []
    for k, grp in enumerate(groups, 1):
        rows = _join_rows(conn, [{'v': [u['a'], u['b']]} for u in grp])
        for r in rows:
            r['ref'] = PS._ref(conn, r['v'][0], r['v'][1])
        days.append({'d': k, 'sec': '', 'q': '', 'r': rows})
    return days


def day_n(conn, version, dd):
    n = 0
    for r in dd.get('r') or []:
        v = r.get('v') or []
        if v:
            n += conn.execute("SELECT COALESCE(SUM(LENGTH(REPLACE(REPLACE(verse_text,' ',''),char(10),''))),0) "
                              "FROM bible_content WHERE version_code=? AND verse_id BETWEEN ? AND ?",
                              (version, int(v[0]), int(v[-1]))).fetchone()[0] or 0
    return n


def titles(conn, dd, lang='KO'):
    """그날 걸린 단락 제목들(시작이 그날 안에 있는 BODY 페리코프) — 「 · 」로 잇는다."""
    out = []
    for r in dd.get('r') or []:
        v = r.get('v') or []
        if not v:
            continue
        # 단락 중간에서 시작하면 그 단락 제목 + 「(이어서)」 — 둘로 나눈 뒤쪽 날이 제목 없이 비지 않게
        st = conn.execute("SELECT pericope_id, start_vid FROM sys_pericope_asset WHERE peri_type='BODY' "
                          "AND COALESCE(record_status,'LIVE')='LIVE' AND start_vid<=? AND end_vid>=? "
                          "ORDER BY start_vid DESC LIMIT 1", (int(v[0]), int(v[0]))).fetchone()
        if st and st[1] < int(v[0]):
            t = _peri_title(conn, st[0], lang)
            if t:
                try:
                    import i18n
                    t = t + ' ' + i18n.t('PW_CONT', '(이어서)')
                except Exception:
                    t = t + ' (이어서)'
                if t not in out:
                    out.append(t)
        for pid, in conn.execute("SELECT pericope_id FROM sys_pericope_asset WHERE peri_type='BODY' "
                                 "AND COALESCE(record_status,'LIVE')='LIVE' AND start_vid BETWEEN ? AND ? "
                                 "ORDER BY start_vid", (int(v[0]), int(v[-1]))):
            t = _peri_title(conn, pid, lang)
            if t and t not in out:
                out.append(t)
    return ' · '.join(out)


def merge(conn, days, i):
    """i 날과 다음 날을 합친다 → 새 일정(뒤 날은 하루씩 당겨짐). 마지막 날이면 None."""
    if i < 0 or i + 1 >= len(days):
        return None
    a, b = days[i], days[i + 1]
    import plan_share as PS
    rows = _join_rows(conn, [dict(r) for r in (a.get('r') or [])] + [dict(r) for r in (b.get('r') or [])])
    for r in rows:
        r['ref'] = PS._ref(conn, r['v'][0], r['v'][1])
    m = {'d': 0, 'sec': a.get('sec') or b.get('sec') or '', 'q': a.get('q') or b.get('q') or '', 'r': rows}
    out = days[:i] + [m] + days[i + 2:]
    for k, dd in enumerate(out, 1):
        dd['d'] = k
    return out


def _day_verses(conn, version, dd):
    vs = []
    for r in dd.get('r') or []:
        v = r.get('v') or []
        if not v:
            continue
        vs += conn.execute(
            "SELECT b.verse_id, COALESCE(LENGTH(REPLACE(REPLACE(c.verse_text,' ',''),char(10),'')),0) "
            "FROM bible_index b LEFT JOIN bible_content c ON c.verse_id=b.verse_id AND c.version_code=? "
            "WHERE b.verse_id BETWEEN ? AND ? ORDER BY b.verse_id", (version, int(v[0]), int(v[-1]))).fetchall()
    return vs


def split(conn, version, days, i):
    """i 날을 둘로 → (새 일정, (자른 뒤 절, 앞 글자, 뒤 글자)). 자를 수 없으면 (None, None).

    자리 = 두 쪽 글자 수가 가장 비슷해지는 곳. **단락 경계·읽을 곳 경계 먼저** — 그 자리로 나눈 차이가
    가장 고른 절 자리보다 전체의 15% 이상 나쁘지 않으면 그것을 쓴다(이야기를 덜 자른다)."""
    if i < 0 or i >= len(days):
        return None, None
    vs = _day_verses(conn, version, days[i])
    if len(vs) < 2:
        return None, None
    tot = sum(n for _v, n in vs)
    vids = [v for v, _n in vs]
    soft = set()
    for r in days[i].get('r') or []:
        if r.get('v'):
            soft.add(int(r['v'][0]))
    lo, hi = vids[0], vids[-1]
    for (a,) in conn.execute("SELECT start_vid FROM sys_pericope_asset WHERE peri_type='BODY' "
                             "AND COALESCE(record_status,'LIVE')='LIVE' AND start_vid>? AND start_vid<=?", (lo, hi)):
        soft.add(a)
    acc, best, best_soft = 0, None, None
    for k in range(1, len(vs)):
        acc += vs[k - 1][1]
        diff = abs(tot - 2 * acc)
        if best is None or diff < best[0]:
            best = (diff, k, acc)
        if vids[k] in soft and (best_soft is None or diff < best_soft[0]):
            best_soft = (diff, k, acc)
    pick = best_soft if best_soft and best_soft[0] <= best[0] + 0.15 * tot else best
    _d, k, acc = pick
    return _cut(conn, days, i, vs, k)


def split_at(conn, version, days, i, cut_vid):
    """i 날을 `cut_vid` 뒤에서 자른다(되돌리기용) → (새 일정, 정보) · 그 절이 그날 마지막이면 (None, None)."""
    if i is None or i < 0 or i >= len(days):
        return None, None
    vs = _day_verses(conn, version, days[i])
    vids = [v for v, _n in vs]
    if cut_vid not in vids or vids.index(cut_vid) == len(vids) - 1:
        return None, None
    return _cut(conn, days, i, vs, vids.index(cut_vid) + 1)


def _cut(conn, days, i, vs, k):
    vids = [v for v, _n in vs]
    acc = sum(n for _v, n in vs[:k])
    tot = sum(n for _v, n in vs)
    cut_after = vids[k - 1]
    import plan_share as PS

    def part(lo_v, hi_v):
        rows = []
        for r in days[i].get('r') or []:
            v = r.get('v') or []
            if not v:
                continue
            a, b = max(int(v[0]), lo_v), min(int(v[-1]), hi_v)
            if a <= b:
                rows.append({'v': [a, b], 'f': r.get('f') or '', 'ref': PS._ref(conn, a, b)})
        return rows
    first = dict(days[i], r=part(vids[0], cut_after))
    second = {'d': 0, 'sec': '', 'q': '', 'r': part(vids[k], vids[-1])}
    out = days[:i] + [first, second] + days[i + 1:]
    for n, dd in enumerate(out, 1):
        dd['d'] = n
    return out, (cut_after, acc, tot - acc)


def span(dd):
    """그날의 (첫 절, 끝 절) · 읽을 곳이 없으면 (None, None)."""
    vs = [r['v'] for r in dd.get('r') or [] if r.get('v')]
    if not vs:
        return None, None
    return min(int(v[0]) for v in vs), max(int(v[-1]) for v in vs)


def day_of(days, vid):
    """그 절을 읽는 날(번호 0부터) · 없으면 None."""
    for i, dd in enumerate(days):
        for r in dd.get('r') or []:
            v = r.get('v') or []
            if v and int(v[0]) <= vid <= int(v[-1]):
                return i
    return None


# ── 바꾼 것(합치기·나누기) — 날 번호가 아니라 **절**로 기억한다 ─────────────────
#   뒤에 다른 날을 합치거나 나눠 날 번호가 밀려도, 그 자리를 다시 찾아 그것 하나만 되돌린다.
#   op = {'kind': 'SPLIT'|'MERGE', 'at': 경계 앞 절}  — 경계 = at 과 그다음 절 사이.

def do_split(conn, version, days, i):
    nd, info = split(conn, version, days, i)
    if nd is None:
        return None, None, None
    return nd, {'kind': 'SPLIT', 'at': info[0]}, info


def do_merge(conn, days, i):
    if i is None or i < 0 or i + 1 >= len(days):
        return None, None
    at = span(days[i])[1]
    nd = merge(conn, days, i)
    return (nd, {'kind': 'MERGE', 'at': at}) if nd else (None, None)


def op_days(conn, days, op):
    """그 바꾼 것이 걸린 날들(번호 0부터) · 이미 사라졌으면 []."""
    at = op['at']
    nxt = _next_vid(conn, at)
    if op['kind'] == 'SPLIT':
        i = next((k for k, dd in enumerate(days) if span(dd)[1] == at), None)
        if i is not None and i + 1 < len(days) and span(days[i + 1])[0] == nxt:
            return [i, i + 1]
        return []
    i = day_of(days, at)
    if i is not None and day_of(days, nxt) == i:
        return [i]
    return []


def undo_op(conn, version, days, op):
    """그 바꾼 것 **하나만** 되돌린다 → 새 일정 · 그 자리가 뒤의 일로 없어졌으면 None."""
    ds = op_days(conn, days, op)
    if not ds:
        return None
    if op['kind'] == 'SPLIT':
        return merge(conn, days, ds[0])
    nd, _info = split_at(conn, version, days, ds[0], op['at'])
    return nd


def ref_of(conn, vid):
    import plan_share as PS
    return PS._ref(conn, vid, vid)


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, got=''):
        ok[1] += 1
        ok[0] += bool(cond)
        print(('  OK   ' if cond else '  FAIL ') + name, got if not cond else '')
    conn = appdb.connect()
    ver = version_of('KO')
    us = units(conn, [45], 'PERI', ver, 'KO')
    t('로마서 단락 47개', len(us) == 47, len(us))
    t('단락 글자 합 = 로마서 전체', sum(u['n'] for u in us) == sum(r[4] for r in verse_lens(conn, ver, [45])))
    t('단락 제목이 붙는다', us[18]['title'] != '', us[18])
    uc = units(conn, [45], 'CHAP', ver, 'KO')
    t('로마서 16장', len(uc) == 16 and uc[0]['title'].endswith(' 1'), [u['title'] for u in uc[:2]])
    g = distribute(us, 30)
    t('30일로 나뉜다', len(g) == 30)
    t('단락을 빠짐없이 차례대로', [u for grp in g for u in grp] == us)
    t('단락이 하나뿐인 날도 자르지 않는다', all(len(grp) >= 1 for grp in g))
    g2 = distribute(us, 100)
    t('날이 단락보다 많으면 단락 수로', len(g2) == 47, len(g2))
    g3 = distribute(us, 10, cap=1500)
    t('상한 1,500자 — 넘는 날 없음(단락 하나짜리 빼고)', all(sum(u['n'] for u in grp) <= 1500 or len(grp) == 1 for grp in g3),
      [sum(u['n'] for u in grp) for grp in g3])
    t('상한 때문에 날이 는다', len(g3) > 10, len(g3))
    days = to_days(conn, g)
    t('일정 꼴 · 약명', days[0]['r'][0]['ref'].startswith('롬') and days[0]['d'] == 1, days[0])
    t('이어지는 단락은 한 줄', all(len(dd['r']) == 1 for dd in days))
    i17 = next(k for k, dd in enumerate(days) if dd['r'][0]['ref'].startswith('롬 9:6'))
    nd, info = split(conn, ver, days, i17)
    t('둘로 나누기 → 31일', nd and len(nd) == 31)
    t('나눈 두 쪽이 비슷하다(차이 10% 안)', info and abs(info[1] - info[2]) <= 0.1 * (info[1] + info[2]), info)
    t('나눈 뒤 글자 합 불변', day_n(conn, ver, nd[i17]) + day_n(conn, ver, nd[i17 + 1]) == day_n(conn, ver, days[i17]))
    t('뒤 날이 하루씩 밀린다', nd[i17 + 2]['r'][0]['ref'] == days[i17 + 1]['r'][0]['ref'] and nd[-1]['d'] == 31)
    md = merge(conn, nd, i17 + 2)
    t('합치기 → 30일 · 한 줄로 이어짐', md and len(md) == 30 and len(md[i17 + 2]['r']) == 1, md and md[i17 + 2]['r'])
    t('마지막 날은 합칠 수 없다', merge(conn, days, len(days) - 1) is None)
    # 바꾼 것을 골라 하나만 되돌린다(순서와 무관)
    a1, op1, _ = do_split(conn, ver, days, 2)
    a2, op2 = do_merge(conn, a1, 20)
    t('바꾼 것 둘 → 날 수', len(a2) == 30, len(a2))
    t('나눔 표시 = 두 날', op_days(conn, a2, op1) == [2, 3], op_days(conn, a2, op1))
    t('합침 표시 = 한 날', len(op_days(conn, a2, op2)) == 1)
    b1 = undo_op(conn, ver, a2, op1)
    t('먼저 한 나눔만 되돌림 — 합침은 그대로', b1 and len(b1) == 29 and op_days(conn, b1, op2)
      and [span(d) for d in b1[:3]] == [span(d) for d in days[:3]])
    b2 = undo_op(conn, ver, b1, op2)
    t('합침도 되돌리면 처음과 같다', b2 and [span(d) for d in b2] == [span(d) for d in days])
    t('이미 되돌린 것은 None', undo_op(conn, ver, b2, op1) is None)
    t('읽는 날 — 30일 · 주 5일', reading_days('DAYS', 30, (0, 1, 2, 3, 4)) == 21)
    t('읽는 날 — 언제까지', reading_days('UNTIL', '2026-10-21', today=datetime.date(2026, 10, 15)) == 7)
    t('제목 잇기', '하나님의 주권적인 선택' in titles(conn, days[i17]), titles(conn, days[i17]))
    conn.close()
    print('plan_build selftest: %d/%d' % tuple(ok))
    return ok[0] == ok[1]


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print(__doc__)
