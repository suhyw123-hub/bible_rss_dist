# -*- coding: utf-8 -*-
"""splash_prep.py — 스플래시 배경 사진 전처리(오프라인/관리자 측).
폰으로 찍은 큰 원본을 스플래시 규격 PNG로 cover-crop 다운스케일한다.
→ 런타임(splash_screen.py)은 작은 PNG만 즉시 로드(PIL 불필요).
※ 이 모듈은 PIL을 쓰므로 사용자 앱 시작 경로에서 import하지 않는다(관리자/전처리 전용).
"""
import os
from PIL import Image


def _cover_crop(src, width, height):
    """src 를 width×height 로 cover-crop 한 RGB 이미지 + 원본크기 반환."""
    img = Image.open(src)
    ow, oh = img.size
    img = img.convert('RGB')
    scale = max(width / ow, height / oh)          # cover: 빈틈 없이 채움
    nw, nh = max(width, int(ow * scale + 0.5)), max(height, int(oh * scale + 0.5))
    img = img.resize((nw, nh), Image.LANCZOS)
    left, top = (nw - width) // 2, (nh - height) // 2   # 중앙 크롭
    img = img.crop((left, top, left + width, top + height))
    return img, ow, oh


def prepare_background(src, dst='splash/bg.png', width=960, height=600):
    """src(jpg/png/…)를 width×height cover-crop 후 최적화 PNG 파일로 저장.
    반환: (dst_path, bytes, (orig_w, orig_h))"""
    img, ow, oh = _cover_crop(src, width, height)
    os.makedirs(os.path.dirname(dst) or '.', exist_ok=True)
    img.save(dst, 'PNG', optimize=True)
    return dst, os.path.getsize(dst), (ow, oh)


def to_png_bytes(src, width=960, height=600):
    """src 를 width×height cover-crop 후 PNG 바이트로 반환(DB BLOB 저장용).
    반환: (png_bytes, orig_w, orig_h)"""
    import io
    img, ow, oh = _cover_crop(src, width, height)
    buf = io.BytesIO()
    img.save(buf, 'PNG', optimize=True)
    return buf.getvalue(), ow, oh


if __name__ == '__main__':
    import sys
    src = sys.argv[1] if len(sys.argv) > 1 else 'sea.jpeg'
    dst = sys.argv[2] if len(sys.argv) > 2 else 'splash/bg.png'
    p, sz, orig = prepare_background(src, dst)
    print(f"{src} {orig[0]}x{orig[1]} -> {p}  {sz//1024} KB")
