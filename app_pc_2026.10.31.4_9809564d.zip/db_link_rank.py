# -*- coding: utf-8 -*-
"""구절연결(VERS_VERS) 중요도 점수 — 일괄 계산 (영구 도구 · 8단계 ②).

★ 설계 단일 소스 = 할일목록 13-46 「확정 설계」 표. 요점:
    · 입력은 무제한, **캔버스 표시만 제한**(상한 1~10 · 기본 10)
    · 점수 = 지표 4 (합 100 표시 · **비율 정규화** 계산)
        성경 안 거리 40 · 관계 유형 30 · 구속사 흐름 20 · 설명문 충실도 10
    · 관리자 기본 = `sys_config` JSON + **sys_link_asset.rank_score** (배포)
    · 사용자 가중치·점수 = user db (**자연 열쇠** — ③ 캔버스 단계에서 잇는다)

⚠⚠ **일괄 SQL 한 방으로만 계산한다.** 행별 파이썬 계산은 100배 느리다
  (실측 2026-08-26 — 일괄: 2,722행 3ms · 30만 행 249ms · 100만 행 4.1s).
  「로직을 수시로 바꾸면 느릴까」의 답은 그래서 **아니오**다.

⚠ **설명문 축은 연속값**(자수/300, 상한 1) — 계단(10/6/3/0)으로 하면 동점이
  쏟아진다(실측: 서로 다른 값 9개/42행). 동점은 **정경순**으로 안정 정렬(표시층).

⚠ **점수는 참고값이지 정답이 아니다.** 「연결 수 ≤ 표시 상한이면 계산 없이 전부
  표시」(13-46)라 절의 96%는 이 점수를 쓰지도 않는다.

쓰는 법
    python db_link_rank.py --selftest
    python db_link_rank.py --check          가중치·분포 미리 보기 (안 쓴다)
    python db_link_rank.py --apply          일괄 계산 → sys rank_score 저장
    python db_link_rank.py --show 1 [10]    그 절의 상위 N
"""
import json
import sys
import time

import appdb

CONFIG_KEY = 'LINK_RANK_WEIGHTS'
# 기본 가중치 — 화면에는 「합 100」으로 보이지만 계산은 비율 정규화라
# 합이 100이 아니어도 뜻이 같다.
DEFAULT_WEIGHTS = {'distance': 40, 'tier': 30, 'chain': 20, 'desc': 10,
                   # 선택 지표 둘 — 기본 꺼짐(0) (13-46 확정: 지표 4 + 선택 2)
                   'multi': 0,   # 관점 여럿 — 같은 짝에 rel 이 2개 이상
                   'hub': 0}     # 허브 — 연결이 아주 많은 절로 가는 연결
# 선택 지표의 **방향**(2026-08-26 0.txt 사용자 지시 「일방적 감점으로 하지
# 말고 가점도 가능해야 한다. 감점/가점 선택하도록」): +1 = 가점(해당하면
# 점수↑) · -1 = 감점(해당하면 점수↓). 기본은 종전 동작 그대로.
DEFAULT_DIRS = {'multi_dir': 1, 'hub_dir': -1}

# ── 절대점수 방식 (2026-09-01 0.txt 4번 사용자 확정) ─────────────────────
# 「지표마다 초기점수를 배치한다. 가점 체크하고 10을 입력하면 +10, 감점
#  체크하고 10을 입력하면 -10. 합산한다. 합산 점수가 마이너스가 되어도 순위에
#  영향 없다. 점수 순서대로 배치한다.」
# ⇒ 유효 배점 = 초기점수 + 방향 × 가감 수치. **정규화하지 않고** 유효 배점 ×
#   축값(0~1)을 그대로 합산한다. 여섯 지표 전부 같은 꼴(통일 적용).
#   허브의 「감점」은 축을 뒤집는 대신 **음수 배점**이 맡는다 — 공식이 하나가 된다.
#   가감점을 전부 0으로 두면 초기점수만 남는 균등배점이고, 동점은 표시층이
#   정경순으로 가른다(user_main._child_rank_key).
ABS_DIRS = {k + '_dir': (-1 if k == 'hub' else 1) for k in DEFAULT_WEIGHTS}

# ── 연결유형별 점수 (2026-09-02 사용자 확정 0.txt 5번) ─────────────────────
# 「연결유형 하나하나에 대한 배점을 결정할 수 있다면 인위적으로 3가지로
#  분류하거나 가감점 정책이 필요 없어진다」 ⇒ tier 축(A 1.0·B 0.6·C 0.27 ×
#  배점 30)을 **유형별 절대점수**로 편다. 초기값 = 옛 공식과 같은 순위가
#  나오는 값(A 30 · B 18 · C 8). 명부에 없는(새·희귀) 유형은 tier 기본값.
REL_TIER_DEFAULT = {'A': 30, 'B': 18, 'C': 8}

# ── 등급표 (2026-09-02 0.txt 5-5 사용자 확정 「각 항목별로 점수를 받을 수
#   있는 방식이 표준화되어야 한다」) — 연속 축을 **명시된 등급**으로 바꾼다.
#   배점 10을 주면 실제로 최대 10점이 움직인다는 것이 보장된다.
#   구절 간격: 교차 100% · 다른 책 60% · 다른 장 25% · 같은 장 0
#   설명문: 충실(150자↑) 100% · 있음 50% · 없음 0
#   허브: 연결 10개↑ 100% · 5~9개 50% · 미만 0
DESC_RICH = 150
HUB_MANY, HUB_SOME = 10, 5


def rel_defaults(conn):
    """실제 구절연결이 쓰는 유형 → 초기점수 {code: int}. tier 에서 유도."""
    out = {}
    try:
        for code, tier in conn.execute(
                "SELECT DISTINCT l.rel_code, COALESCE(rc.rel_tier,'B')"
                ' FROM sys_link_asset l'
                ' LEFT JOIN (SELECT DISTINCT rel_code, rel_tier'
                '  FROM sys_rel_catalog) rc ON rc.rel_code=l.rel_code'
                " WHERE l.link_type='VERS_VERS' AND l.rel_code IS NOT NULL"):
            out[code] = REL_TIER_DEFAULT.get(tier, REL_TIER_DEFAULT['B'])
    except Exception:
        pass
    return out
DESC_FULL = 300          # 설명문 만점 자수 (실측 최대 212·평균 66)
HUB_FULL = 30            # 허브 만점(감점 0이 되는) 연결 수 (실측 최대 42·10개 넘는 절 4%)


def ensure_schema(conn):
    """멱등. sys 에 점수 칸, user 에 개인 점수 표(③에서 쓴다)."""
    cols = [r[1] for r in conn.execute('PRAGMA table_info(sys_link_asset)')]
    if 'rank_score' not in cols:
        conn.execute('ALTER TABLE sys_link_asset ADD COLUMN rank_score INTEGER')
    # ⚠ 개인 점수는 **자연 열쇠**로 — sys PK 는 배포마다 0% 보존(실측).
    conn.execute(
        'CREATE TABLE IF NOT EXISTS userdb.user_link_rank ('
        ' link_type TEXT NOT NULL, clicked_id INTEGER NOT NULL,'
        ' target_id INTEGER NOT NULL, rel_key TEXT NOT NULL,'
        ' end_key INTEGER NOT NULL, score INTEGER,'
        ' UNIQUE(link_type, clicked_id, target_id, rel_key, end_key))')
    conn.commit()


def weights(conn, scope='SYS'):
    """가중치. USER 는 user_config 우선, 없으면 sys_config, 없으면 기본.

    돌려주는 것은 **정규화된 비율**(합 1.0) — 「합계 100 강제」 대신
    「저장은 원값·계산은 비율」(2026-08-26 사용자 승인 방향).
    """
    raw = None
    try:
        if scope == 'USER':
            # ⚠ 칼럼은 config_val 이다 — config_value 로 적어 두고 selftest 의
            #   가짜 표까지 같은 이름으로 만들어 못 잡았다(§0-5 재발, 2026-08-26
            #   수리). USER 가중치가 영영 안 읽히고 있었다.
            r = conn.execute('SELECT config_val FROM userdb.user_config '
                             'WHERE config_key=?', (CONFIG_KEY,)).fetchone()
            raw = r and r[0]
        if raw is None:
            r = conn.execute('SELECT config_val FROM sys_config '
                             'WHERE config_key=?', (CONFIG_KEY,)).fetchone()
            raw = r and r[0]
    except Exception:
        raw = None
    try:
        w = dict(DEFAULT_WEIGHTS, **json.loads(raw)) if raw else dict(DEFAULT_WEIGHTS)
    except Exception:
        w = dict(DEFAULT_WEIGHTS)
    tot = sum(max(0, float(w.get(k, 0))) for k in DEFAULT_WEIGHTS) or 1.0
    out = {k: max(0, float(w.get(k, 0))) / tot for k in DEFAULT_WEIGHTS}
    # 방향은 가중치가 아니라 부호 — 정규화 합에 넣지 않는다
    for dk, dft in DEFAULT_DIRS.items():
        out[dk] = _dir(w.get(dk, dft), dft)
    return out


def _dir(v, dft):
    try:
        return 1 if float(v) >= 0 else -1
    except Exception:
        return dft


def _score_select(w, table='sys_link_asset'):
    """일괄 채점 SELECT — **여기 말고 다른 데서 점수 공식을 쓰지 말 것.**

    각 축은 0~1 로 재고 가중치(비율)를 곱해 0~100 정수로.
      거리   구약↔신약 1.0 · 다른 책 0.625 · 다른 장 0.25 · 같은 장 0
      유형   A 1.0 · B 0.6 · C 0.27  (`sys_rel_catalog.rel_tier`)
      흐름   chain_code 있으면 1.0
      설명문 KO 자수/300 (상한 1) — **연속값**
    """
    wm = float(w.get('multi', 0) or 0)
    wh = float(w.get('hub', 0) or 0)
    dm = _dir(w.get('multi_dir', 1), 1)
    dh = _dir(w.get('hub_dir', -1), -1)
    extra_terms = ''
    extra_joins = ''
    if wm > 0:
        # 관점 여럿 — 같은 구절 짝에 rel_code 행이 2개 이상 (§28-1).
        # 가점(+1) = 여럿이면 1.0 / 감점(-1) = 여럿이면 0, 단일이면 1.0
        yes, no = ('1.0', '0') if dm > 0 else ('0', '1.0')
        extra_terms += (' + %.6f * (CASE WHEN COALESCE(mm.cnt,1) >= 2'
                        ' THEN %s ELSE %s END)' % (wm, yes, no))
        extra_joins += (' LEFT JOIN (SELECT clicked_id AS c, target_id AS g,'
                        ' COUNT(*) AS cnt FROM %(tbl)s'
                        " WHERE link_type='VERS_VERS' GROUP BY 1, 2) mm"
                        ' ON mm.c=l.clicked_id AND mm.g=l.target_id')
    if wh > 0:
        # 허브 — 양 끝 중 연결이 더 많은 절 기준. 붐빔도(dens) = 0(연결 1)
        # ~ 1(HUB_FULL 이상). 감점(-1) = 덜 붐빌수록 점수↑(1-dens) /
        # 가점(+1) = 붐빌수록 점수↑(dens)
        dens = ('MIN(1.0,'
                ' (MAX(COALESCE(da.cnt,1), COALESCE(db.cnt,1)) - 1.0)'
                ' / %d.0)' % HUB_FULL)
        expr = ('(1.0 - %s)' % dens) if dh < 0 else dens
        extra_terms += (' + %.6f * %s' % (wh, expr))
        deg = ('(SELECT vid, COUNT(*) AS cnt FROM'
               ' (SELECT clicked_id AS vid FROM %(tbl)s'
               "  WHERE link_type='VERS_VERS'"
               '  UNION ALL SELECT target_id FROM %(tbl)s'
               "  WHERE link_type='VERS_VERS') GROUP BY vid)")
        extra_joins += (' LEFT JOIN ' + deg + ' da ON da.vid=l.clicked_id'
                        ' LEFT JOIN ' + deg + ' db ON db.vid=l.target_id')
    return ('SELECT l.rowid AS rid, CAST(ROUND(100.0 * ('
            ' %(d).6f * (CASE WHEN (a.bcode<=39)<>(b.bcode<=39) THEN 1.0'
            '   WHEN a.bcode<>b.bcode THEN 0.625'
            '   WHEN a.chapter<>b.chapter THEN 0.25 ELSE 0 END)'
            " + %(t).6f * (CASE COALESCE(rc.rel_tier,'B')"
            "   WHEN 'A' THEN 1.0 WHEN 'B' THEN 0.6 ELSE 0.27 END)"
            ' + %(c).6f * (CASE WHEN l.chain_code IS NOT NULL THEN 1.0 ELSE 0 END)'
            ' + %(e).6f * MIN(1.0, COALESCE(LENGTH(t.contents),0)/%(full)d.0)'
            ' %(x)s'
            ')) AS INTEGER) AS s'
            ' FROM %(tbl)s l'
            ' JOIN bible_index a ON a.verse_id=l.clicked_id'
            ' JOIN bible_index b ON b.verse_id=l.target_id'
            ' LEFT JOIN (SELECT DISTINCT rel_code, rel_tier FROM sys_rel_catalog) rc'
            '   ON rc.rel_code=l.rel_code'
            " LEFT JOIN sys_text_asset t ON t.text_type='VERS_VERS_DESC'"
            "   AND t.clicked_id=l.rowid AND t.lang_code='KO'"
            ' %(xj)s'
            " WHERE l.link_type='VERS_VERS'"
            % {'d': w['distance'], 't': w['tier'], 'c': w['chain'],
               'e': w['desc'], 'full': DESC_FULL, 'tbl': table,
               'x': extra_terms % {'tbl': table} if '%(tbl)s' in extra_terms
                    else extra_terms,
               'xj': extra_joins % {'tbl': table} if extra_joins else ''})


def eff_from_raw(raw):
    """절대점수 원값 → 지표별 **유효 배점**(초기점수 + 방향×가감 수치)."""
    out = {}
    for k in DEFAULT_WEIGHTS:
        base = float(raw.get(k, DEFAULT_WEIGHTS[k]) or 0)
        adj = abs(float(raw.get(k + '_adj', 0) or 0))
        d = _dir(raw.get(k + '_dir', ABS_DIRS[k + '_dir']), ABS_DIRS[k + '_dir'])
        out[k] = base + d * adj
    return out


def _score_select_abs(eff, table='sys_link_asset', rel_scores=None):
    """절대점수 일괄 채점 SELECT — 축(0~1)은 비율 방식과 같고 배점만 절대값.

    ⚠ 여기서도 공식은 이 함수 하나다. 허브·관점여럿은 배점이 0 이 아니면
      조인을 건다(음수 배점 = 감점이므로 부호로 조인을 거르면 안 된다).
    rel_scores — 유형별 점수 {code:int} (2026-09-02). 주어지면 tier 축
      (eff['tier'] × 0~1) 대신 **rel_code CASE** 로 유형마다 제 점수를 더한다.
      명부에 없는 유형은 tier 기본값(REL_TIER_DEFAULT)으로 떨어진다."""
    em = float(eff.get('multi', 0) or 0)
    eh = float(eff.get('hub', 0) or 0)
    extra_terms = ''
    extra_joins = ''
    if em != 0:
        extra_terms += (' + %.6f * (CASE WHEN COALESCE(mm.cnt,1) >= 2'
                        ' THEN 1.0 ELSE 0 END)' % em)
        extra_joins += (' LEFT JOIN (SELECT clicked_id AS c, target_id AS g,'
                        ' COUNT(*) AS cnt FROM %(tbl)s'
                        " WHERE link_type='VERS_VERS' GROUP BY 1, 2) mm"
                        ' ON mm.c=l.clicked_id AND mm.g=l.target_id')
    if eh != 0:
        # ★ 등급 (2026-09-02) — 연속 밀도 대신 10개↑ 100% · 5~9 50% · 미만 0
        dens = ('(CASE WHEN MAX(COALESCE(da.cnt,1), COALESCE(db.cnt,1)) >= %d'
                ' THEN 1.0 WHEN MAX(COALESCE(da.cnt,1), COALESCE(db.cnt,1))'
                ' >= %d THEN 0.5 ELSE 0 END)' % (HUB_MANY, HUB_SOME))
        extra_terms += (' + %.6f * %s' % (eh, dens))
        deg = ('(SELECT vid, COUNT(*) AS cnt FROM'
               ' (SELECT clicked_id AS vid FROM %(tbl)s'
               "  WHERE link_type='VERS_VERS'"
               '  UNION ALL SELECT target_id FROM %(tbl)s'
               "  WHERE link_type='VERS_VERS') GROUP BY vid)")
        extra_joins += (' LEFT JOIN ' + deg + ' da ON da.vid=l.clicked_id'
                        ' LEFT JOIN ' + deg + ' db ON db.vid=l.target_id')
    if rel_scores:
        # 유형별 CASE — 값은 전부 숫자 리터럴이라 바인딩이 필요 없다.
        #   코드 이름은 영문·숫자·_ 만 통과시킨다(SQL 주입 방지 — 사용자
        #   입력이 아니라 카탈로그 코드지만, 문에 끼워 넣는 것은 거른다).
        # ★★ **같은 짝의 관점이 여럿이면 최고점 하나만** (2026-09-02 0.txt
        #   5-6 사용자 확정 — 합산하면 「한 구절이 이렇게 많은 점수를 받는
        #   것처럼」 오해된다. 캔버스는 어차피 구절당 한 박스라 최고점 행이
        #   대표한다 — 이제 **짝의 모든 행이 같은(최고) 유형 점수**를 받아
        #   미리보기·점수표가 캔버스와 같은 말을 한다).
        _parts = []
        for code, v in sorted(rel_scores.items()):
            if code and all(ch.isalnum() or ch == '_' for ch in str(code)):
                _parts.append("WHEN '%s' THEN %.6f" % (code, float(v)))
        _one = ('(CASE x.rel_code ' + ' '.join(_parts) +
                " ELSE (CASE COALESCE(xc.rel_tier,'B')"
                " WHEN 'A' THEN %.6f WHEN 'C' THEN %.6f"
                ' ELSE %.6f END) END)'
                % (float(REL_TIER_DEFAULT['A']),
                   float(REL_TIER_DEFAULT['C']),
                   float(REL_TIER_DEFAULT['B'])))
        tier_term = ' + COALESCE(rmx.mx, 0)'
        extra_joins += (' LEFT JOIN (SELECT x.clicked_id AS c, x.target_id AS g,'
                        ' MAX(' + _one + ') AS mx'
                        ' FROM %(tbl)s x'
                        ' LEFT JOIN (SELECT DISTINCT rel_code, rel_tier'
                        '  FROM sys_rel_catalog) xc ON xc.rel_code=x.rel_code'
                        " WHERE x.link_type='VERS_VERS' GROUP BY 1, 2) rmx"
                        ' ON rmx.c=l.clicked_id AND rmx.g=l.target_id')
    else:
        tier_term = (" + %.6f * (CASE COALESCE(rc.rel_tier,'B')"
                     " WHEN 'A' THEN 1.0 WHEN 'B' THEN 0.6 ELSE 0.27 END)"
                     % eff['tier'])
    return ('SELECT l.rowid AS rid, CAST(ROUND('
            ' %(d).6f * (CASE WHEN (a.bcode<=39)<>(b.bcode<=39) THEN 1.0'
            '   WHEN a.bcode<>b.bcode THEN 0.6'
            '   WHEN a.chapter<>b.chapter THEN 0.25 ELSE 0 END)'
            ' %(tier)s'
            ' + %(c).6f * (CASE WHEN l.chain_code IS NOT NULL THEN 1.0 ELSE 0 END)'
            ' + %(e).6f * (CASE WHEN COALESCE(LENGTH(t.contents),0) >= %(rich)d'
            '   THEN 1.0 WHEN COALESCE(LENGTH(t.contents),0) > 0'
            '   THEN 0.5 ELSE 0 END)'
            ' %(x)s'
            ') AS INTEGER) AS s'
            ' FROM %(tbl)s l'
            ' JOIN bible_index a ON a.verse_id=l.clicked_id'
            ' JOIN bible_index b ON b.verse_id=l.target_id'
            ' LEFT JOIN (SELECT DISTINCT rel_code, rel_tier FROM sys_rel_catalog) rc'
            '   ON rc.rel_code=l.rel_code'
            " LEFT JOIN sys_text_asset t ON t.text_type='VERS_VERS_DESC'"
            "   AND t.clicked_id=l.rowid AND t.lang_code='KO'"
            ' %(xj)s'
            " WHERE l.link_type='VERS_VERS'"
            % {'d': eff['distance'], 'tier': tier_term, 'c': eff['chain'],
               'e': eff['desc'], 'rich': DESC_RICH, 'tbl': table,
               'x': extra_terms % {'tbl': table} if '%(tbl)s' in extra_terms
                    else extra_terms,
               'xj': extra_joins % {'tbl': table} if extra_joins else ''})


def preview_top(conn, vid, raw_abs=None, limit=10):
    """그 절의 순위 미리보기 — **저장하지 않는다** (2026-09-01 0.txt 4번).

    raw_abs 를 주면 그 점수표(절대점수)로 새로 채점한 순위,
    안 주면 지금 저장된 점수(개인 점수 우선, 없으면 sys) 순위.
    → [(상대 vid, rel_code, 점수)] — 동점은 정경순."""
    if raw_abs is not None:
        sel = _score_select_abs(eff_from_raw(raw_abs),
                                rel_scores=(raw_abs.get('rel_scores') or None))
        rows = conn.execute(
            'SELECT q.s, l.clicked_id, l.target_id, l.rel_code'
            ' FROM (%s) q JOIN sys_link_asset l ON l.rowid = q.rid'
            " WHERE COALESCE(l.record_status,'LIVE')='LIVE'"
            '   AND (l.clicked_id=? OR l.target_id=?)' % sel,
            (vid, vid)).fetchall()
    else:
        rows = conn.execute(
            'SELECT COALESCE(u.score, l.rank_score, 0), l.clicked_id,'
            ' l.target_id, l.rel_code'
            ' FROM sys_link_asset l'
            ' LEFT JOIN userdb.user_link_rank u'
            "   ON u.link_type='VERS_VERS' AND u.clicked_id=l.clicked_id"
            '   AND u.target_id=l.target_id'
            "   AND u.rel_key=COALESCE(l.rel_code,'')"
            " WHERE l.link_type='VERS_VERS'"
            "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
            '   AND (l.clicked_id=? OR l.target_id=?)',
            (vid, vid)).fetchall()
    # ★ 구절 단위로 하나만 (2026-09-02 0.txt 5-3 「같은 구절이 여러 개
    #   표시된다」 — 다중관점 짝이 관점 수만큼 반복됐다). 최고점 행이 대표한다
    #   — 캔버스가 이미 그렇게 그린다(같은 구절은 한 박스).
    best = {}
    for s, a, b, rel in rows:
        other = b if a == vid else a
        cur = best.get(other)
        sv = s if s is not None else -10**9
        if cur is None or sv > cur[1]:
            best[other] = (rel, sv, s)
    out = [(k, v[0], v[2]) for k, v in best.items()]
    out.sort(key=lambda x: (-(x[2] if x[2] is not None else -1.0), x[0]))
    return out[:limit]


def breakdown(conn, vid, raw_abs, limit=10):
    """미리보기용 **득점 내역** — [(상대 vid, rel, 총점, {지표: 점수})].

    ★ 「아무리 수정해도 안 바뀐다」 혼란의 해독제 (2026-09-02 0.txt 5-5) —
      줄마다 어느 지표에서 몇 점을 받았는지 보인다.
    ⚠ 공식은 _score_select_abs 와 같은 등급표를 파이썬으로 다시 적는다 —
      갈라지면 안 되므로 **selftest 가 「내역 합 = preview_top 점수」를 잰다.**
    """
    eff = eff_from_raw(raw_abs)
    rs = raw_abs.get('rel_scores') or {}
    rows = conn.execute(
        'SELECT l.clicked_id, l.target_id, l.rel_code, l.chain_code,'
        ' a.bcode, a.chapter, b.bcode, b.chapter,'
        " COALESCE(rc.rel_tier,'B'),"
        " COALESCE((SELECT LENGTH(t.contents) FROM sys_text_asset t"
        "  WHERE t.text_type='VERS_VERS_DESC' AND t.clicked_id=l.rowid"
        "  AND t.lang_code='KO' LIMIT 1), 0)"
        ' FROM sys_link_asset l'
        ' JOIN bible_index a ON a.verse_id=l.clicked_id'
        ' JOIN bible_index b ON b.verse_id=l.target_id'
        ' LEFT JOIN (SELECT DISTINCT rel_code, rel_tier FROM sys_rel_catalog) rc'
        '  ON rc.rel_code=l.rel_code'
        " WHERE l.link_type='VERS_VERS'"
        "  AND COALESCE(l.record_status,'LIVE')='LIVE'"
        '  AND (l.clicked_id=? OR l.target_id=?)', (vid, vid)).fetchall()
    # 짝별 관점 수·유형 최고점
    from collections import defaultdict
    pair_rels = defaultdict(list)
    for a, b, rel, *_r in rows:
        pair_rels[(a, b)].append((rel, _r[-2]))     # (rel, tier)

    def _relpts(pairs):
        best = None
        for rel, tier in pairs:
            v = rs.get(rel)
            if v is None:
                v = REL_TIER_DEFAULT.get(tier, REL_TIER_DEFAULT['B'])
            best = v if best is None else max(best, v)
        return float(best or 0)

    def _deg(v):
        r = conn.execute(
            'SELECT COUNT(*) FROM sys_link_asset'
            " WHERE link_type='VERS_VERS' AND (clicked_id=? OR target_id=?)",
            (v, v)).fetchone()
        return r[0] if r else 0

    deg_cache = {}
    best_by_other = {}
    for a, b, rel, chain, ab, ach, bb, bch, tier, dlen in rows:
        other = b if a == vid else a
        comp = {}
        cross = (ab <= 39) != (bb <= 39)
        grade = 1.0 if cross else (0.6 if ab != bb
                                   else (0.25 if ach != bch else 0.0))
        comp['distance'] = eff['distance'] * grade
        comp['rel'] = _relpts(pair_rels[(a, b)])
        comp['chain'] = eff['chain'] * (1.0 if chain else 0.0)
        comp['desc'] = eff['desc'] * (1.0 if dlen >= DESC_RICH
                                      else (0.5 if dlen > 0 else 0.0))
        comp['multi'] = eff['multi'] * (1.0 if len(pair_rels[(a, b)]) >= 2
                                        else 0.0)
        if eff['hub']:
            for v in (a, b):
                if v not in deg_cache:
                    deg_cache[v] = _deg(v)
            d = max(deg_cache[a], deg_cache[b])
            hg = 1.0 if d >= HUB_MANY else (0.5 if d >= HUB_SOME else 0.0)
            comp['hub'] = eff['hub'] * hg
        else:
            comp['hub'] = 0.0
        total = int(round(sum(comp.values())))
        cur = best_by_other.get(other)
        if cur is None or total > cur[1]:
            best_by_other[other] = (rel, total, comp)
    out = [(k, v[0], v[1], v[2]) for k, v in best_by_other.items()]
    out.sort(key=lambda x: (-x[2], x[0]))
    return out[:limit]


def busiest_vid(conn):
    """연결이 가장 많은 절 — 미리보기 표본 (2026-09-01 0.txt 4번)."""
    r = conn.execute(
        'SELECT vid FROM ('
        ' SELECT clicked_id AS vid FROM sys_link_asset'
        "  WHERE link_type='VERS_VERS'"
        ' UNION ALL SELECT target_id FROM sys_link_asset'
        "  WHERE link_type='VERS_VERS')"
        ' GROUP BY vid ORDER BY COUNT(*) DESC LIMIT 1').fetchone()
    return r[0] if r else None


def apply_sys(conn, w=None):
    """관리자 기본 점수를 sys 에 일괄 저장. 멱등."""
    ensure_schema(conn)
    w = w or weights(conn, 'SYS')
    t0 = time.perf_counter()
    # ⚠ sys_link_asset 의 PK 는 sys_link_id 지만 rowid 별칭으로 같은 행이다.
    #   설명문 닻(clicked_id)이 그 PK 를 가리키므로 t.clicked_id=l.rowid 가 맞다.
    conn.execute('UPDATE sys_link_asset SET rank_score = ('
                 ' SELECT s FROM (%s) q WHERE q.rid = sys_link_asset.rowid)'
                 " WHERE link_type='VERS_VERS'" % _score_select(w))
    conn.commit()
    ms = (time.perf_counter() - t0) * 1000
    n = conn.execute("SELECT COUNT(*) FROM sys_link_asset "
                     "WHERE link_type='VERS_VERS' AND rank_score IS NOT NULL"
                     ).fetchone()[0]
    return n, ms


def raw_weights(conn, scope='USER'):
    """저장된 **원값**(정규화 전) — 설정 화면이 칸을 채울 때 쓴다."""
    raw = None
    try:
        if scope == 'USER':
            r = conn.execute('SELECT config_val FROM userdb.user_config '
                             'WHERE config_key=?', (CONFIG_KEY,)).fetchone()
            raw = r and r[0]
        if raw is None:
            r = conn.execute('SELECT config_val FROM sys_config '
                             'WHERE config_key=?', (CONFIG_KEY,)).fetchone()
            raw = r and r[0]
    except Exception:
        raw = None
    try:
        w = dict(DEFAULT_WEIGHTS, **json.loads(raw)) if raw else dict(DEFAULT_WEIGHTS)
    except Exception:
        w = dict(DEFAULT_WEIGHTS)
    _abs = (w.get('mode') == 'ABS')
    # ★ 절대점수 모드는 **부호를 보존한다** (2026-09-02 — 가감점 방식 폐지,
    #   「각 항목별 점수 부여 · 마이너스 입력 가능」). 비율 모드만 0 하한.
    out = {k: (int(float(w.get(k, 0) or 0)) if _abs
               else max(0, int(float(w.get(k, 0) or 0))))
           for k in DEFAULT_WEIGHTS}
    for dk, dft in DEFAULT_DIRS.items():
        out[dk] = _dir(w.get(dk, dft), dft)
    # 절대점수 칸 (2026-09-01) — 옛 저장본에는 없으므로 0 · 기본 방향
    out['mode'] = w.get('mode', '')
    for k in DEFAULT_WEIGHTS:
        out[k + '_adj'] = abs(int(float(w.get(k + '_adj', 0) or 0)))
        out[k + '_dir'] = _dir(w.get(k + '_dir', ABS_DIRS[k + '_dir']),
                               ABS_DIRS[k + '_dir'])
    # 유형별 점수 (2026-09-02) — 있으면 그대로(부호 보존)
    try:
        out['rel_scores'] = {str(c): int(float(v))
                             for c, v in (w.get('rel_scores') or {}).items()}
    except Exception:
        out['rel_scores'] = {}
    return out


def save_user_weights(conn, raw):
    """개인 가중치 저장 — **원값 그대로**(계산은 weights 가 비율로).
    raw = {'distance':40, ..., 'multi_dir':±1, 'hub_dir':±1}.
    ★ 절대점수 방식(2026-09-01)이면 raw['mode']='ABS' + `<k>_adj`/`<k>_dir`
      까지 함께 담는다 — apply_user 가 mode 로 공식을 가른다."""
    _abs = (raw.get('mode') == 'ABS')
    body_d = {k: (int(float(raw.get(k, 0) or 0)) if _abs
                  else max(0, int(raw.get(k, 0) or 0)))
              for k in DEFAULT_WEIGHTS}
    for dk, dft in DEFAULT_DIRS.items():
        body_d[dk] = _dir(raw.get(dk, dft), dft)
    if _abs:
        body_d['mode'] = 'ABS'
        for k in DEFAULT_WEIGHTS:
            body_d[k + '_adj'] = abs(int(float(raw.get(k + '_adj', 0) or 0)))
            body_d[k + '_dir'] = _dir(raw.get(k + '_dir', ABS_DIRS[k + '_dir']),
                                      ABS_DIRS[k + '_dir'])
        if raw.get('rel_scores'):
            body_d['rel_scores'] = {str(c): int(float(v))
                                    for c, v in raw['rel_scores'].items()}
    body = json.dumps(body_d, ensure_ascii=False)
    cur = conn.execute('UPDATE userdb.user_config SET config_val=? '
                       'WHERE config_key=?', (body, CONFIG_KEY))
    if cur.rowcount == 0:
        conn.execute('INSERT INTO userdb.user_config(config_key, config_val) '
                     'VALUES (?, ?)', (CONFIG_KEY, body))
    conn.commit()


def clear_user(conn):
    """개인 설정 제거 = 기본(관리자 점수)으로 복귀 — 가중치·점수 둘 다 지운다.

    ⚠ 점수만 남기면 옛 가중치의 점수가 계속 이겨서 「기본값」이 거짓이 된다."""
    conn.execute('DELETE FROM userdb.user_config WHERE config_key=?',
                 (CONFIG_KEY,))
    try:
        conn.execute('DELETE FROM userdb.user_link_rank')
    except Exception:
        pass
    conn.commit()


def apply_user(conn, w=None):
    """개인 점수 재계산 — `userdb.user_link_rank` 전체 교체 (멱등).

    자연 열쇠로 담으므로 배포로 sys PK 가 갈려도 산다. sys 연결 전체 +
    사용자 VERS_VERS(있다면 — 지금 0건)를 함께 채점한다.
    ⚠ 행별 파이썬 계산 금지 — 일괄 SQL 한 방(13-46 실측: 100배 차이).
    ★ 저장된 mode 가 'ABS'(절대점수, 2026-09-01)면 그 공식으로 채점한다."""
    ensure_schema(conn)
    if w is None:
        raw = raw_weights(conn, 'USER')
        if raw.get('mode') == 'ABS':
            _rs = raw.get('rel_scores') or None
            sel_a = _score_select_abs(eff_from_raw(raw), rel_scores=_rs)
            sel_b = _score_select_abs(eff_from_raw(raw), 'userdb.user_link_asset',
                                      rel_scores=_rs)
        else:
            w2 = weights(conn, 'USER')
            sel_a = _score_select(w2)
            sel_b = _score_select(w2, 'userdb.user_link_asset')
    else:
        sel_a = _score_select(w)
        sel_b = _score_select(w, 'userdb.user_link_asset')
    t0 = time.perf_counter()
    conn.execute('DELETE FROM userdb.user_link_rank')
    conn.execute(
        'INSERT OR REPLACE INTO userdb.user_link_rank'
        ' (link_type, clicked_id, target_id, rel_key, end_key, score)'
        " SELECT 'VERS_VERS', l2.clicked_id, l2.target_id,"
        " COALESCE(l2.rel_code,''), COALESCE(l2.end_id, l2.target_id), q.s"
        ' FROM (%s) q JOIN sys_link_asset l2 ON l2.rowid = q.rid'
        % sel_a)
    try:
        conn.execute(
            'INSERT OR REPLACE INTO userdb.user_link_rank'
            ' (link_type, clicked_id, target_id, rel_key, end_key, score)'
            " SELECT 'VERS_VERS', l2.clicked_id, l2.target_id,"
            " COALESCE(l2.rel_code,''), COALESCE(l2.end_id, l2.target_id), q.s"
            ' FROM (%s) q JOIN userdb.user_link_asset l2 ON l2.rowid = q.rid'
            % sel_b)
    except Exception:
        pass                                 # 사용자 연결 표가 없는 DB
    conn.commit()
    ms = (time.perf_counter() - t0) * 1000
    n = conn.execute('SELECT COUNT(*) FROM userdb.user_link_rank').fetchone()[0]
    return n, ms


def top(conn, vid, limit=10):
    """그 절의 상위 N — **표시층이 읽는 형태.** 동점은 정경순(target 작은 것 먼저)."""
    return conn.execute(
        'SELECT l.sys_link_id, l.clicked_id, l.target_id, l.rel_code,'
        ' l.chain_code, l.rank_score'
        ' FROM sys_link_asset l'
        " WHERE l.link_type='VERS_VERS'"
        "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
        '   AND (l.clicked_id=? OR l.target_id=?)'
        ' ORDER BY l.rank_score DESC,'
        '   (CASE WHEN l.clicked_id=? THEN l.target_id ELSE l.clicked_id END)'
        ' LIMIT ?', (vid, vid, vid, limit)).fetchall()


def check(conn):
    w = weights(conn, 'SYS')
    print('가중치(비율):', {k: round(v, 3) for k, v in w.items()})
    rows = conn.execute('SELECT s, COUNT(*) FROM (%s) GROUP BY s ORDER BY s'
                        % _score_select(w)).fetchall()
    tot = sum(n for _, n in rows)
    print('채점 대상 %d행 · 서로 다른 점수 %d개 · 폭 %d~%d'
          % (tot, len(rows), rows[0][0], rows[-1][0]))
    import collections
    band = collections.Counter((s // 10) * 10 for s, n in rows for _ in range(n))
    for b in sorted(band):
        print('   %3d점대 %5d행' % (b, band[b]))
    return tot


def selftest():
    import sqlite3
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    # 가중치 정규화
    class FakeConn(object):
        def execute(self, *a):
            raise RuntimeError

    w = weights(FakeConn())
    t('기본 가중치 합 1.0', abs(sum(w.values()) - 1.0) < 1e-9, sum(w.values()))
    t('비율 그대로', abs(w['distance'] - 0.4) < 1e-9, w['distance'])

    db = sqlite3.connect(':memory:')
    db.execute('ATTACH DATABASE ":memory:" AS userdb')
    db.execute('CREATE TABLE sys_config (config_key TEXT, config_val TEXT)')
    # ⚠ 칼럼 이름을 실제(config_val)와 같게 — config_value 로 손으로 적어
    #   두는 바람에 본체의 같은 오타를 **못 잡았다**(§0-5 재발 · 2026-08-26).
    db.execute('CREATE TABLE userdb.user_config '
               '(config_key TEXT, config_val TEXT)')
    db.execute("INSERT INTO sys_config VALUES (?, ?)",
               (CONFIG_KEY, '{"distance": 95, "tier": 0, "chain": 0, "desc": 0}'))
    w2 = weights(db, 'SYS')
    t('★ 합 95 여도 비율로 산다 (100 강제 안 함)',
      abs(w2['distance'] - 1.0) < 1e-9, w2)
    db.execute("INSERT INTO userdb.user_config VALUES (?, ?)",
               (CONFIG_KEY, '{"distance": 10, "tier": 10, "chain": 0, "desc": 0}'))
    w3 = weights(db, 'USER')
    t('★ USER 는 user_config 이 이긴다',
      abs(w3['distance'] - 0.5) < 1e-9 and w3['chain'] == 0, w3)

    # 채점 정확성 — 손으로 계산한 행 넷
    db.execute('CREATE TABLE bible_index (verse_id INTEGER PRIMARY KEY, '
               'bcode INT, chapter INT)')
    for vid, bc, ch in ((1, 1, 1), (2, 1, 1), (50, 1, 2), (900, 19, 5),
                        (25000, 45, 3)):
        db.execute('INSERT INTO bible_index VALUES (?,?,?)', (vid, bc, ch))
    db.execute('CREATE TABLE sys_link_asset (sys_link_id INTEGER PRIMARY KEY,'
               ' link_type TEXT, clicked_id INT, target_id INT, rel_code TEXT,'
               ' chain_code TEXT, end_id INT, record_status TEXT,'
               ' rank_score INTEGER)')
    db.execute('CREATE TABLE sys_rel_catalog (rel_code TEXT, rel_tier TEXT)')
    db.execute("INSERT INTO sys_rel_catalog VALUES ('TYP','A'),('SUP','B'),('REF','C')")
    db.execute('CREATE TABLE sys_text_asset (clicked_id INT, text_type TEXT,'
               ' lang_code TEXT, contents TEXT)')
    L = [(1, 1, 25000, 'TYP', 'CH'),      # 교차+A+체인 → 40+30+20 = 90 (+desc)
         (2, 1, 900, 'SUP', None),        # 다른책+B → 25+18 = 43
         (3, 1, 50, 'REF', None),         # 같은책 다른장+C → 10+8 = 18
         (4, 1, 2, 'REF', None)]          # 같은장+C → 8
    for pk, a, b, rel, chn in L:
        db.execute("INSERT INTO sys_link_asset VALUES (?,?,?,?,?,?,NULL,'LIVE',NULL)",
                   (pk, 'VERS_VERS', a, b, rel, chn))
    db.execute("INSERT INTO sys_text_asset VALUES (1,'VERS_VERS_DESC','KO',?)",
               ('가' * 150,))              # 150/300 = 0.5 → +5
    db.commit()
    n, ms = apply_sys(db, dict(distance=0.4, tier=0.3, chain=0.2, desc=0.1))
    t('네 행 채점', n == 4, n)
    got = {r[0]: r[1] for r in db.execute(
        'SELECT sys_link_id, rank_score FROM sys_link_asset')}
    t('★ 손 계산과 일치 — 교차+A+체인+글 95', got[1] == 95, got[1])
    t('   다른책+B 43', got[2] == 43, got[2])
    t('   다른장+C 18', got[3] == 18, got[3])
    t('   같은장+C 8', got[4] == 8, got[4])
    # 멱등
    apply_sys(db, dict(distance=0.4, tier=0.3, chain=0.2, desc=0.1))
    got2 = {r[0]: r[1] for r in db.execute(
        'SELECT sys_link_id, rank_score FROM sys_link_asset')}
    t('멱등', got == got2)
    # top — 정렬·동점 정경순
    r = top(db, 1, 3)
    t('top 정렬', [x[0] for x in r] == [1, 2, 3], [x[0] for x in r])
    # ★ 탐지력 — 가중치를 바꾸면 점수가 실제로 바뀌는가
    apply_sys(db, dict(distance=0.0, tier=0.0, chain=1.0, desc=0.0))
    got3 = {r[0]: r[1] for r in db.execute(
        'SELECT sys_link_id, rank_score FROM sys_link_asset')}
    t('★ 가중치 변경이 점수를 바꾼다 (체인만 100)',
      got3[1] == 100 and got3[2] == 0, (got3[1], got3[2]))
    # ★ 선택 지표 — 손 계산 (2026-08-26 신설 · 기본 꺼짐이라 위 넷은 불변)
    db.execute("INSERT INTO sys_link_asset VALUES "
               "(5,'VERS_VERS',1,900,'TYP',NULL,NULL,'LIVE',NULL)")   # (1,900) 두 관점
    db.commit()
    apply_sys(db, dict(distance=0, tier=0, chain=0, desc=0, multi=1.0, hub=0))
    g4 = {r[0]: r[1] for r in db.execute(
        'SELECT sys_link_id, rank_score FROM sys_link_asset')}
    t('★ multi — 관점 여럿 짝만 100', g4[2] == 100 and g4[5] == 100
      and g4[1] == 0, (g4[1], g4[2]))
    apply_sys(db, dict(distance=0, tier=0, chain=0, desc=0, multi=0, hub=1.0))
    g5 = {r[0]: r[1] for r in db.execute(
        'SELECT sys_link_id, rank_score FROM sys_link_asset')}
    # deg(1)=5 라 전부 1-(5-1)/30 = 0.8667 → 87 (손 계산)
    t('★ hub — 붐비는 절 감점', g5[1] == 87, g5[1])

    # ★ 방향 선택 (2026-08-26 0.txt — 「감점/가점 선택하도록」)
    apply_sys(db, dict(distance=0, tier=0, chain=0, desc=0, multi=1.0, hub=0,
                       multi_dir=-1))
    g6 = {r[0]: r[1] for r in db.execute(
        'SELECT sys_link_id, rank_score FROM sys_link_asset')}
    t('★ multi 감점 — 단일 관점이 100·여럿이 0',
      g6[1] == 100 and g6[2] == 0, (g6[1], g6[2]))
    apply_sys(db, dict(distance=0, tier=0, chain=0, desc=0, multi=0, hub=1.0,
                       hub_dir=1))
    g7 = {r[0]: r[1] for r in db.execute(
        'SELECT sys_link_id, rank_score FROM sys_link_asset')}
    # 가점이면 dens = (5-1)/30 = 0.1333 → 13
    t('★ hub 가점 — 붐빌수록 점수↑', g7[1] == 13, g7[1])
    # 방향 저장·복원 — save_user_weights 가 dir 를 함께 담는가
    save_user_weights(db, {'distance': 10, 'multi': 5, 'multi_dir': -1,
                           'hub': 5, 'hub_dir': 1})
    rw = raw_weights(db, 'USER')
    t('★ 방향 저장·복원', rw['multi_dir'] == -1 and rw['hub_dir'] == 1,
      (rw['multi_dir'], rw['hub_dir']))
    clear_user(db)

    # ★ 개인 점수 (apply_user — 자연 열쇠 일괄)
    db.execute('CREATE TABLE userdb.user_link_asset '
               '(user_link_id INTEGER PRIMARY KEY, link_type TEXT,'
               ' clicked_id INT, target_id INT, rel_code TEXT,'
               ' chain_code TEXT, end_id INT, record_status TEXT)')
    n2, _ms = apply_user(db, dict(distance=0.4, tier=0.3, chain=0.2, desc=0.1))
    t('★ 개인 점수 일괄(user_link_rank)', n2 == 5, n2)
    r = db.execute('SELECT score FROM userdb.user_link_rank '
                   'WHERE clicked_id=1 AND target_id=25000').fetchone()
    t('   자연 열쇠로 담기고 값 일치(95)', r and r[0] == 95, r and r[0])

    # ★ 개인 가중치 저장·복귀 (config_val — 실제 칼럼으로)
    save_user_weights(db, {'distance': 10, 'tier': 10})
    w4 = weights(db, 'USER')
    t('★ 저장한 개인 가중치가 읽힌다', abs(w4['distance'] - 0.5) < 1e-9, w4['distance'])
    clear_user(db)
    w5 = weights(db, 'USER')
    n3 = db.execute('SELECT COUNT(*) FROM userdb.user_link_rank').fetchone()[0]
    t('★ 기본 복귀 — 가중치·개인 점수 함께 지움',
      abs(w5['distance'] - 1.0) < 1e-9 and n3 == 0, (w5['distance'], n3))

    # ★★ 절대점수 방식 (2026-09-01 0.txt 4번)
    eff = eff_from_raw({'distance': 40, 'distance_adj': 10, 'distance_dir': 1,
                        'tier': 30, 'tier_adj': 10, 'tier_dir': -1})
    t('★ 유효 배점 = 초기 + 방향×수치', eff['distance'] == 50
      and eff['tier'] == 20, (eff['distance'], eff['tier']))
    t('   허브 기본 방향은 감점', eff_from_raw({'hub': 0, 'hub_adj': 10})['hub'] == -10)
    # 절대 채점 — 손 계산: 링크1 = 교차(1.0)×50 + A(1.0)×20 + 체인×0 + 글×0 = 70
    save_user_weights(db, {'mode': 'ABS', 'distance': 50, 'tier': 20,
                           'chain': 0, 'desc': 0, 'multi': 0, 'hub': 0})
    n4, _ = apply_user(db)
    r = db.execute('SELECT score FROM userdb.user_link_rank '
                   'WHERE clicked_id=1 AND target_id=25000').fetchone()
    t('★ ABS 모드 저장 → apply_user 가 절대 공식으로', r and r[0] == 70,
      r and r[0])
    # 감점이 순위를 실제로 뒤집는가 — tier 에 큰 감점을 주면 A 가 C 밑으로
    save_user_weights(db, {'mode': 'ABS', 'distance': 0, 'tier': 10,
                           'tier_adj': 30, 'tier_dir': -1,
                           'chain': 0, 'desc': 0, 'multi': 0, 'hub': 0})
    apply_user(db)
    g8 = {(a, b): s for a, b, s in db.execute(
        'SELECT clicked_id, target_id, score FROM userdb.user_link_rank')}
    # 유효 tier = -20 → A(1.0) = -20 · C(0.27) = -5 (마이너스 허용)
    t('★ 감점으로 마이너스 점수 — A 가 C 아래로',
      g8[(1, 25000)] == -20 and g8[(1, 2)] == -5,
      (g8[(1, 25000)], g8[(1, 2)]))
    # preview_top — 저장하지 않고 순위 (점수 내림·동점 정경순)
    pv = preview_top(db, 1, {'mode': 'ABS', 'distance': 50, 'tier': 20,
                             'chain': 0, 'desc': 0, 'multi': 0, 'hub': 0})
    t('★ preview_top 순위', pv and pv[0][0] == 25000, pv and pv[0][0])
    before = db.execute('SELECT COUNT(*), SUM(score) FROM userdb.user_link_rank'
                        ).fetchone()
    preview_top(db, 1, {'mode': 'ABS', 'distance': 1, 'tier': 0, 'chain': 0,
                        'desc': 0, 'multi': 0, 'hub': 0})
    after = db.execute('SELECT COUNT(*), SUM(score) FROM userdb.user_link_rank'
                       ).fetchone()
    t('★ preview 는 저장하지 않는다', before == after, (before, after))
    t('   busiest_vid', busiest_vid(db) == 1, busiest_vid(db))
    clear_user(db)

    # ★★ 유형별 점수 (2026-09-02 0.txt 5번)
    #   손 계산 — 링크1(TYP)=50 · 링크3(REF)=-5 · 링크2(SUP)는 명부에 없어
    #   tier 기본(B=18). 다른 지표는 전부 0.
    save_user_weights(db, {'mode': 'ABS', 'distance': 0, 'tier': 0,
                           'chain': 0, 'desc': 0, 'multi': 0, 'hub': 0,
                           'rel_scores': {'TYP': 50, 'REF': -5}})
    # 미등재 유형만 있는 짝 — tier 기본값 검증용 (짝 최고점과 안 섞이게)
    db.execute("INSERT INTO sys_link_asset VALUES "
               "(6,'VERS_VERS',2,900,'SUP',NULL,NULL,'LIVE',NULL)")
    db.commit()
    apply_user(db)
    # ⚠ (1,900) 짝은 SUP·TYP 두 관점이 있다(§28-1) — rel 까지 열쇠에 넣는다
    g9 = {(a, b, r): s for a, b, r, s in db.execute(
        'SELECT clicked_id, target_id, rel_key, score FROM userdb.user_link_rank')}
    t('★ 유형별 점수 — TYP 50 · REF -5 · 미등재 SUP 는 tier 기본 18',
      g9[(1, 25000, 'TYP')] == 50 and g9[(1, 50, 'REF')] == -5
      and g9[(2, 900, 'SUP')] == 18,
      (g9[(1, 25000, 'TYP')], g9[(1, 50, 'REF')], g9[(2, 900, 'SUP')]))
    t('★ 짝 최고점 — (1,900) 의 SUP 행도 TYP 점수(50)를 받는다 (0.txt 5-6)',
      g9[(1, 900, 'SUP')] == 50 and g9[(1, 900, 'TYP')] == 50,
      (g9[(1, 900, 'SUP')], g9[(1, 900, 'TYP')]))
    # 미리보기 중복 제거 — (1,900) 두 관점이 한 줄로 (0.txt 5-3)
    pv2 = preview_top(db, 1, {'mode': 'ABS', 'distance': 0, 'tier': 0,
                              'chain': 0, 'desc': 0, 'multi': 0, 'hub': 0,
                              'rel_scores': {'TYP': 50, 'REF': -5}})
    t('★ 미리보기 — 구절당 한 줄(중복 0)',
      len([x for x in pv2 if x[0] == 900]) == 1
      and len(pv2) == len({x[0] for x in pv2}), pv2)
    # ★ 득점 내역 = preview 점수와 일치 (공식 두 벌 갈라짐 방지)
    bd = breakdown(db, 1, {'mode': 'ABS', 'distance': 40, 'tier': 0,
                           'chain': 20, 'desc': 10, 'multi': 7, 'hub': 0,
                           'rel_scores': {'TYP': 50, 'REF': -5}})
    pv3 = preview_top(db, 1, {'mode': 'ABS', 'distance': 40, 'tier': 0,
                              'chain': 20, 'desc': 10, 'multi': 7, 'hub': 0,
                              'rel_scores': {'TYP': 50, 'REF': -5}}, 99)
    _pvmap = {x[0]: x[2] for x in pv3}
    t('★ 내역 합 = preview 점수 (전 행)',
      all(_pvmap.get(o) == tot for o, _r, tot, _c in bd),
      [(o, tot, _pvmap.get(o)) for o, _r, tot, _c in bd])
    # 부호 보존 — ABS 기본값도 마이너스를 살린다
    save_user_weights(db, {'mode': 'ABS', 'distance': -7, 'tier': 0,
                           'chain': 0, 'desc': 0, 'multi': 0, 'hub': 0})
    rw2 = raw_weights(db, 'USER')
    t('★ ABS 는 마이너스 초기점수 보존', rw2['distance'] == -7, rw2['distance'])
    t('   rel_scores 왕복', raw_weights(db, 'USER').get('rel_scores') == {},
      raw_weights(db, 'USER').get('rel_scores'))
    save_user_weights(db, {'mode': 'ABS', 'rel_scores': {'PAR': 40},
                           'distance': 0, 'tier': 0, 'chain': 0, 'desc': 0,
                           'multi': 0, 'hub': 0})
    t('   rel_scores 저장·복원', raw_weights(db, 'USER')['rel_scores'] == {'PAR': 40})
    clear_user(db)

    # 스키마 멱등
    ensure_schema(db)
    ensure_schema(db)
    t('스키마 멱등', True)
    db.close()
    print('db_link_rank selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv[1] if len(sys.argv) > 1 else '--check'
    if a == '--selftest':
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect()
    try:
        if a == '--check':
            ensure_schema(conn)
            check(conn)
        elif a == '--apply':
            n, ms = apply_sys(conn)
            print('채점 %d행 · %.0f ms' % (n, ms))
            check(conn)
        elif a == '--show':
            vid = int(sys.argv[2])
            lim = int(sys.argv[3]) if len(sys.argv) > 3 else 10
            for r in top(conn, vid, lim):
                print('  %5d점 %6d → %-6d %-4s %s'
                      % (r[5] or 0, r[1], r[2], r[3] or '-', r[4] or ''))
        else:
            print(__doc__)
    finally:
        conn.close()
