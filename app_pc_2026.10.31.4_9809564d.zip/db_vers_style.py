# -*- coding: utf-8 -*-
"""db_vers_style.py — 절별자산 **한국어 문체** 측정기 (영구 도구).

왜 필요한가 — 2026-08-07 사용자 반려.
  "네 글을 읽기 위해서 골치아프게 머리를 써야 한다. 더 이상 읽고 싶은 마음이 사라진다.
   영어로 작성한 것을 기계적으로, 직역하듯이 번역하는 패턴이 여전하다."

  `db_vers_gate` 는 길이비·신출어휘·문단밀도·요체·학술장치·본문재진술을 센다. 전부 통과해도
  번역투는 그대로 남는다 — **게이트는 바닥이지 천장이 아니다.** 통과를 목표로 쓰면 통과에
  맞는 문장이 나오고, 그것이 곧 번역투다.

  이 도구는 다섯 가지를 잰다. 전부 **한국어 문장의 모양**이지 내용이 아니다.

    ① 문장 길이 표준편차   고르면 기계가 쓴 것처럼 읽힌다. **하한**을 본다
    ② 사물 주어            「이 절이 ~한다」 「본문이 ~한다」 — 영어 구조
    ③ 명사화               「~에 쓰인 낱말」 「~라는 점」 「~인 셈이다」
    ④ 자문자답             스스로 묻고 곧바로 답하는 꼴. 장치이지 말이 아니다
    ⑤ 한자어 밀도          촘촘하면 읽는 데 품이 든다

★ **판정하지 않는다 (2026-08-07 현재).** 바닥값이 없으면 문턱을 정할 수 없다. 먼저 이미 써 놓은
  글에 돌려 숫자를 모으고, 그 분포를 보고 문턱을 정한 뒤에 `--judge` 를 켠다.
  ⚠ 코퍼스를 기준으로 문턱을 느슨히 하지 말 것 — lay.md §6 이 요체에서 겪은 실패다.
  바닥값은 **지금이 어떤 상태인지 알려는 것**이지 목표가 아니다.

★ 한국어만 잰다. 영어는 이 다섯 지표가 뜻을 갖지 않는다.

사용:
  python db_vers_style.py --selftest              # 의무
  python db_vers_style.py --book 2 --ch 12        # 한 장
  python db_vers_style.py --book 2 --ch 1 --to 12 # 여러 장 (바닥값 내기)
  python db_vers_style.py --draft _vers_prep/draft_exo_13.json   # 적재 전 초안
  python db_vers_style.py --book 2 --ch 12 --verses   # 절별로 펼쳐 보기
"""
import argparse
import json
import os
import re
import sys

import db_vers_gate as G

sentences = G.sentences          # 문장 자르기는 게이트와 **같은 함수**를 쓴다


# ── ① 사물 주어 ──────────────────────────────────────────────────────────────
# 「이 절이 ~한다」처럼 사물이 행위자 노릇을 하는 꼴. 영어는 늘 이렇게 쓰고 한국어는 안 쓴다.
# ⚠ 존재·소재 서술(「이 낱말이 창 22:8에 나온다」)은 자연스러우므로 제외한다 —
#   걸러 내지 않으면 원어 설명이 통째로 걸린다(실측에서 그렇게 됐다).
THING_SUBJ = re.compile(
    r'(?:이|그|본|해당)\s*(?:절|본문|표현|낱말|말|구절|대목|장|단락|문장|규례|조항|기록)\s*(?:이|은|는|가)\s'
    r'|본문\s*(?:이|은|는|가)\s'          # 꾸밈말 없이 홀로 서는 것들
    r'|성경\s*(?:이|은|는|가)\s')
_EXIST = re.compile(r'(?:나온다|나오고|나오며|나온|있다|있고|있으며|있는|쓰인다|쓰이고|쓰인|'
                    r'쓴다|보인다|없다|없고|아니다|이다|였다|많다|적다)')


def thing_subject(text):
    """사물 주어 문장 수. 존재·소재 서술은 세지 않는다."""
    n = 0
    for s in sentences(text):
        m = THING_SUBJ.search(s)
        if not m:
            continue
        tail = s[m.end():]
        if _EXIST.search(tail):     # 「~이 나온다/있다」 — 정상
            continue
        n += 1
    return n


# ── ② 명사화 ─────────────────────────────────────────────────────────────────
# 동사로 쓸 것을 명사로 바꿔 쓴 자리. 읽는 사람이 되돌려 풀어야 해서 품이 든다.
NOMINAL = (
    '라는 점', '는 점도', '는 점이', '는 점을',
    '에 쓰인', '에 쓴',
    '하는 자리', '되는 자리', '이는 자리',
    '인 셈이다', '는 셈이다', '한 셈이다',
    '하는 방식', '되는 방식',
    '하는 대목', '되는 대목',
    '이라는 말이다', '라는 뜻이다',
    '할 만하다', '볼 만하다',
)


def nominalization(text):
    return sum(text.count(p) for p in NOMINAL)


# ── ③ 자문자답 ───────────────────────────────────────────────────────────────
# 「무엇에 찍어 바르는가. 우슬초 한 줌이다.」 — 스스로 묻고 곧바로 답한다.
# EXPERT 물음 어미(~인가/~하는가)와 LAY 물음(~합니까) 뒤에 짧은 평서가 붙는 꼴을 본다.
# ⚠ VERS_QUESTION 은 대상이 아니다 — 그쪽은 묻는 것이 일이다.
_ASK = re.compile(r'(?:는가|은가|인가|던가|까)[.?]$|합니까[?]$')


def self_qa(text):
    n = 0
    ss = sentences(text)
    for i, s in enumerate(ss[:-1]):
        if _ASK.search(s.strip()) and len(ss[i + 1]) <= 40:
            n += 1
    return n


# ── ④ 한자어 밀도 ────────────────────────────────────────────────────────────
# 정확히 재려면 사전이 있어야 한다. 없으므로 **어림한다** — 2음절 이상 한자어에 흔한 꼬리를
# 가진 어절의 비율. 절대값이 아니라 **글끼리 견주는 데** 쓴다.
_SINO_TAIL = ('적', '성', '화', '식', '법', '론', '체', '설', '제', '계', '력', '률', '도',
              '관', '상', '점', '항', '기', '개', '과', '학', '용', '측', '차', '규', '형')
_SINO_WORD = re.compile(r'[가-힣]{2,}')
_KO_NATIVE = ('하다', '있다', '없다', '되다', '이다', '보다', '주다', '가다', '오다', '말다')


def sino_ratio(text):
    words = [w for w in re.split(r'\s+', re.sub(r'[^\w\s가-힣]', ' ', text)) if w]
    if not words:
        return 0.0
    n = 0
    for w in words:
        core = re.sub(r'(?:이다|입니다|한다|합니다|였다|이며|이고|의|을|를|은|는|이|가|도|로|에)$', '', w)
        if len(core) >= 2 and core[-1] in _SINO_TAIL and not any(core.endswith(k) for k in _KO_NATIVE):
            n += 1
    return n / len(words)


# ── ⑤ 문장 길이 ──────────────────────────────────────────────────────────────
def sent_stats(text):
    """(문장 수, 평균 길이, 표준편차). 표준편차가 작으면 고르다 = 기계 같다."""
    ss = sentences(text)
    if not ss:
        return 0, 0.0, 0.0
    ls = [len(s) for s in ss]
    mean = sum(ls) / len(ls)
    var = sum((x - mean) ** 2 for x in ls) / len(ls)
    return len(ls), mean, var ** 0.5


# ── 한 덩이 재기 ─────────────────────────────────────────────────────────────
def measure(text):
    n, mean, sd = sent_stats(text)
    return dict(chars=len(text), sents=n, mean=mean, sd=sd,
                thing=thing_subject(text), nominal=nominalization(text),
                selfqa=self_qa(text), sino=sino_ratio(text))


def _blend(rows):
    """여러 덩이를 합쳐 하나로. 문장 통계는 전체 문장을 모아 다시 낸다."""
    if not rows:
        return None
    txt = '\n\n'.join(rows)
    m = measure(txt)
    m['units'] = len(rows)
    return m


# ⚠ 절당으로 환산해 보인다. 장마다 절 수가 달라 **날수는 견줄 수 없다** —
#   출 11장(10절)과 출 12장(51절)을 원수로 비교하면 거꾸로 읽힌다.
HEAD = ('구분       절   자수   문장  평균  편차 | 사물주어 명사화 자문자답  한자어')
FMT = '%-9s %4d %6d %5d %5.1f %5.1f | %7.2f %6.2f %7.2f %7.3f'


def _print(label, m):
    if not m:
        print('%-9s (없음)' % label)
        return
    u = max(m.get('units', 1), 1)
    print(FMT % (label, m.get('units', 1), m['chars'], m['sents'], m['mean'], m['sd'],
                 m['thing'] / u, m['nominal'] / u, m['selfqa'] / u, m['sino']))


# ── DB 에서 읽기 ─────────────────────────────────────────────────────────────
def from_db(bcode, lo, hi, per_verse=False):
    buckets = {'EXPERT': [], 'LAY': []}
    per = []
    for vid, ch, vs in G._verses(bcode, lo, hi):
        got = {}
        for tt, lang, var, txt in G._assets(vid):
            if tt != 'VERS_DESC' or lang != 'KO' or var not in buckets:
                continue
            buckets[var].append(txt)
            got[var] = txt
        if per_verse and got:
            per.append((ch, vs, {k: measure(v) for k, v in got.items()}))
    return buckets, per


def from_draft(path):
    rows = json.load(open(path, encoding='utf-8'))
    buckets = {'EXPERT': [], 'LAY': []}
    for r in rows:
        if (r.get('text_type') == 'VERS_DESC' and r.get('lang_code') == 'KO'
                and r.get('text_variant') in buckets):
            buckets[r['text_variant']].append(r['contents'])
    return buckets, []


def report(buckets, per, title):
    print(title)
    print()
    print(HEAD)
    print('-' * len(HEAD))
    for var in ('EXPERT', 'LAY'):
        _print(var, _blend(buckets[var]))
    print()
    if per:
        print('절별')
        print(HEAD)
        print('-' * len(HEAD))
        for ch, vs, d in per:
            for var in ('EXPERT', 'LAY'):
                if var in d:
                    _print('%d:%d %s' % (ch, vs, var[0]), d[var])
    print()
    print('※ 판정하지 않는다. 문턱은 바닥값을 모은 뒤에 정한다.')
    print('※ 편차가 작을수록 문장 길이가 고르다 — 기계가 쓴 것처럼 읽힌다.')
    return 0


# ── 자가 검증 (의무) ─────────────────────────────────────────────────────────
def selftest():
    """★ 양방향. 나쁜 글은 높게, 좋은 글은 낮게 나와야 한다.
    탐지력이 없는 검사기는 PASS 를 찍으며 아무것도 안 한다 —
    `temp_code_greek_check` 가 어휘집이 빈 채 수십 번 통과한 전례가 있다."""
    print('db_vers_style 자가 검증')
    bad = []

    # ① 사물 주어 — 잡아야 하는 것
    if thing_subject('이 절이 협상의 마지막 자리다.') != 1:
        bad.append('사물 주어를 못 잡는다')
    if thing_subject('본문이 그 겹침을 설명하지 않는다.') != 1:
        bad.append('사물 주어를 못 잡는다 (본문이)')
    # ① 사물 주어 — 잡으면 안 되는 것 (존재 서술)
    if thing_subject('이 낱말이 창 22:8에 나온다.') != 0:
        bad.append('존재 서술을 사물 주어로 오탐한다')
    if thing_subject('그 표현이 여기 한 번뿐이다.') != 0:
        bad.append('존재 서술을 사물 주어로 오탐한다 (뿐이다)')

    # ② 명사화
    if nominalization('쫓아내리니에 쓰인 낱말이 6:1에 이미 나왔다.') != 1:
        bad.append('명사화를 못 잡는다 (에 쓰인)')
    if nominalization('눈여겨볼 만하다. 그것도 짚어 볼 만하다.') != 2:
        bad.append('명사화를 못 잡는다 (볼 만하다)')
    if nominalization('우슬초 한 줌에 피를 찍어 바른다.') != 0:
        bad.append('멀쩡한 문장을 명사화로 오탐한다')

    # ③ 자문자답
    if self_qa('피를 무엇에 찍어 바르는가. 우슬초 한 줌이다.') != 1:
        bad.append('자문자답을 못 잡는다')
    if self_qa('얼마나 작은 풀입니까? 들에 흔한 것입니다.') != 1:
        bad.append('자문자답을 못 잡는다 (합니까)')
    if self_qa('우슬초 한 줌에 피를 찍어 바른다. 붓이 아니라 풀이다.') != 0:
        bad.append('평서문을 자문자답으로 오탐한다')

    # ④ 문장 길이 편차 — 고른 글이 흩어진 글보다 낮아야 한다
    flat = '가나다라마바사아자차카타파하가나다. 하파타카차자아사바마라다나가하파타. 가나다라마바사아자차카타파하가나다.'
    vary = '짧다. 그런데 이 문장은 훨씬 길어서 앞의 것과 견주면 길이가 사뭇 다르고 읽는 결도 달라진다. 그렇다.'
    if sent_stats(flat)[2] >= sent_stats(vary)[2]:
        bad.append('문장 길이 편차가 선택한 글과 흩어진 글을 못 가른다')

    # ⑤ 한자어 밀도 — 한자어 글이 고유어 글보다 높아야 한다
    sino = '협상의 성격상 타협적 조치가 구조적 한계를 규정적으로 노출한다.'
    native = '들에 흔한 풀 한 줌에 피를 찍어 문틀에 바른다.'
    if sino_ratio(sino) <= sino_ratio(native):
        bad.append('한자어 밀도가 두 글을 못 가른다')

    # ⑥ 문장 자르기가 게이트와 같은 함수인가
    if sentences is not G.sentences:
        bad.append('문장 자르기가 게이트와 다른 함수다')

    if bad:
        print('SELFTEST FAIL — %d건' % len(bad))
        for m in bad:
            print('  X ' + m)
        return 1
    print('SELFTEST PASS — 13개 항목')
    return 0


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('--book', type=int)
    ap.add_argument('--ch', type=int)
    ap.add_argument('--to', type=int)
    ap.add_argument('--draft')
    ap.add_argument('--verses', action='store_true', help='절별로 펼쳐 본다')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()

    if a.selftest:
        return selftest()
    if a.draft:
        if not os.path.exists(a.draft):
            print('그런 파일이 없다: %s' % a.draft)
            return 2
        b, p = from_draft(a.draft)
        return report(b, p, '초안 %s' % a.draft)
    if a.book and a.ch:
        hi = a.to or a.ch
        b, p = from_db(a.book, a.ch, hi, a.verses)
        return report(b, p, 'bcode %d · %d~%d장' % (a.book, a.ch, hi))
    ap.print_help()
    return 0


if __name__ == '__main__':
    sys.exit(main())
