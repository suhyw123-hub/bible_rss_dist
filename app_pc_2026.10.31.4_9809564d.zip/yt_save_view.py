"""설정 ▸ 유튜브·웹 글 간편 저장 (2026-10-09 · 2026-10-12 다시 짰다).

★ 2026-10-12 사용자 — 「화면을 다시 체계적으로 개편하라 · 설명문을 읽으면서 즉시 하나하나 조치할 수 있도록」 ·
  「설정화면과 실제 사용자가 심사하는 화면을 갈래로 구분하라」 · 북마크 단추는 폐기(우리 아이콘을 못 단다).

갈래 둘
  [저장 방법 설정] — 「어디서 보나요?」 PC(① 확장 프로그램 · ② 주소 복사) / 폰·TV(③ +Hagah 재생목록 · ④ 폰 공유).
      고른 방법의 차례를 번호로 늘어놓고 **할 일이 있는 줄 바로 옆에 단추·입력 칸**을 둔다(읽으며 따라 한다).
  [받은 영상·글 심사] — 왼쪽 목록(전체 / 연결 전) · 오른쪽 [재생][연결] — 팝업 없이 그 자리에서 듣고 잇는다.

· 주소 복사는 **늘 묻는다** · 확장 단추는 **늘 받는다**(옛 체크상자 둘 걷음).
· 확장 단추를 누르면 ⦿ 바로 저장·연결 창 / ○ 조용히 저장(심사 갈래에서 나중에 연결) — `yt_intake.CFG_QUIET`.
· 단추는 위(§0) · 색은 역할 · 글꼴은 표준 · 경계는 끌어서 크기를 바꾼다.
"""
import os
import queue
import threading
import tkinter as tk
import webbrowser
from tkinter import ttk

import appdb
import yt_intake as YT

try:
    import i18n
    _t = i18n.t
except Exception:          # pragma: no cover
    def _t(k, d=''):
        return d

try:
    import ui_theme
except Exception:          # pragma: no cover
    ui_theme = None


def _C(role, fb):
    try:
        v = ui_theme.C(role) if ui_theme else ''
        return v or fb
    except Exception:
        return fb


KIND_NAME = {'SERMON': ('YTS_K_SERMON', '설교'), 'WORSHIP': ('YTS_K_WORSHIP', '찬양'),
             'STUDY': ('YTS_K_STUDY', '성경공부'), 'WEB': ('YTS2_K_WEB', '웹 글')}

# 방법 넷 — (열쇠, 무리, 이름 열쇠, 이름, 한 줄 열쇠, 한 줄)
METHODS = (
    ('EXT', 'PC', 'YTS2_M_EXT', '① 확장 프로그램 (추천)', 'YTS2_M_EXT_D', '단추 한 번 · 아무 사이트'),
    ('COPY', 'PC', 'YTS2_M_COPY', '② 주소 복사', 'YTS2_M_COPY_D', '설치 없음 · 유튜브만'),
    ('LIST', 'MOB', 'YTS2_M_LIST', '③ +Hagah 재생목록', 'YTS2_M_LIST_D', 'PC가 꺼져 있어도 모임 · 몇 시간 뒤'),
    ('SHARE', 'MOB', 'YTS2_M_SHARE', '④ 폰 공유', 'YTS2_M_SHARE_D', '폰에서 바로 · PC와 동기화 뒤'),
)
EXT_URL = {'CHROME': 'chrome://extensions', 'EDGE': 'edge://extensions'}


def _paint(w):
    """나중에 지은 칸에 테마 색을 입힌다(처음 칠한 뒤 지은 위젯은 기본색으로 남는다 §36)."""
    try:
        if ui_theme:
            ui_theme.paint(w)
    except Exception:
        pass


def probe(port=YT.PORT, timeout=1.5):
    """확장 단추를 받는 자리 상태 → 'OK' · 'OLD'(옛 판이 쥐고 있음) · 'NONE'(아무도 안 받음)."""
    try:
        import urllib.request
        with urllib.request.urlopen('http://127.0.0.1:%d/save?u=' % port, timeout=timeout) as r:
            ct = (r.headers.get('Content-Type') or '').lower()
        return 'OK' if 'json' in ct else 'OLD'
    except Exception:
        return 'NONE'


class YtSaveView(ttk.Frame):
    def __init__(self, parent, db_path, lang_getter=None, on_cfg=None, on_edit=None):
        super().__init__(parent)
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.on_cfg = on_cfg or YT.HOOKS.get('cfg')
        self._rows = {}
        self._player = None
        self._cur_key = None
        self._build()
        self.after(50, self.refresh)
        self.bind('<Destroy>', self._drop, add='+')

    def _lang(self):
        return (self.lang_getter() or 'KO').upper()

    def _drop(self, e=None):
        # ⚠ Tk 변수는 주 스레드에서 놓는다 · 재생기 프로세스는 화면이 사라질 때만 멈춘다
        if e is None or e.widget is self:
            try:
                if self._player is not None:
                    self._player.stop()
            except Exception:
                pass
            self._branch = self._method = self._quiet = self._filter = self._pl_var = None
            self._ed = None

    def _bold(self):
        try:
            import tkinter.font as tkfont
            f = tkfont.nametofont('TkDefaultFont').actual()
            return (f['family'], f['size'], 'bold')
        except Exception:
            return None

    def _btn(self, parent, text, cmd):
        return tk.Button(parent, text=text, command=cmd, bd=1, relief='raised', padx=8)

    # ── 짓기 ────────────────────────────────────────────────────────
    def _build(self):
        bar = tk.Frame(self)
        bar.pack(fill='x', padx=8, pady=(8, 4))
        self._branch = tk.StringVar(value='SETUP')
        self._br_setup = tk.Radiobutton(bar, text=_t('YTS2_BR_SETUP', '저장 방법 설정'), value='SETUP',
                                        variable=self._branch, indicatoron=0, padx=12, pady=3,
                                        command=self._show_branch)
        self._br_setup.pack(side='left')
        self._br_review = tk.Radiobutton(bar, text=_t('YTS2_BR_REVIEW', '받은 영상·글 심사'), value='REVIEW',
                                         variable=self._branch, indicatoron=0, padx=12, pady=3,
                                         command=self._show_branch)
        self._br_review.pack(side='left', padx=(4, 0))
        self._setup = tk.Frame(self)
        self._review = tk.Frame(self)
        self._build_setup(self._setup)
        self._build_review(self._review)
        self._show_branch()

    def _show_branch(self):
        b = self._branch.get() if self._branch is not None else 'SETUP'
        self._setup.pack_forget()
        self._review.pack_forget()
        (self._review if b == 'REVIEW' else self._setup).pack(fill='both', expand=True)
        if b == 'REVIEW':
            self.refresh()

    def go_review(self):
        self._branch.set('REVIEW')
        self._show_branch()

    # ── 갈래 1: 저장 방법 설정 ──────────────────────────────────────
    def _build_setup(self, f):
        tk.Label(f, text=_t('YTS2_INTRO', '보던 유튜브 영상이나 웹 글을 하가에 담아 구절·용어와 잇습니다.'),
                 anchor='w').pack(fill='x', padx=10)
        tk.Label(f, text=_t('YTS2_WHERE', '어디서 보나요? — 하나를 선택하면 아래에 그 차례가 나옵니다.'),
                 anchor='w', font=self._bold()).pack(fill='x', padx=10, pady=(6, 2))
        grid = tk.Frame(f)
        grid.pack(fill='x', padx=10)
        self._method = tk.StringVar(value='EXT')
        groups = (('PC', _t('YTS2_G_PC', 'PC')), ('MOB', _t('YTS2_G_MOB', '폰·TV')))
        for r, (g, gname) in enumerate(groups):
            tk.Label(grid, text=gname, anchor='w', width=6, font=self._bold()).grid(row=r * 2, column=0, sticky='w')
            col = 1
            for key, grp, ik, ko, dk, dko in METHODS:
                if grp != g:
                    continue
                tk.Radiobutton(grid, text=_t(ik, ko), value=key, variable=self._method, indicatoron=0,
                               padx=10, pady=3, command=self._show_method
                               ).grid(row=r * 2, column=col, sticky='we', padx=(0, 8), pady=(4, 0))
                tk.Label(grid, text=_t(dk, dko), anchor='w', fg=_C('fg_dim', '#7F8C8D')
                         ).grid(row=r * 2 + 1, column=col, sticky='w', padx=(0, 8))
                col += 1
        sep = ttk.Separator(f)
        sep.pack(fill='x', padx=10, pady=(8, 4))
        self._steps = tk.Frame(f)
        self._steps.pack(fill='both', expand=True, padx=10, pady=(0, 8))
        self._show_method()

    def _step(self, n, text, wrap=560):
        """번호 줄 하나 → 그 줄의 오른쪽 칸(단추·입력을 놓을 자리)."""
        row = tk.Frame(self._steps)
        row.pack(fill='x', pady=(4, 0))
        tk.Label(row, text='%s.' % n if n else '', width=3, anchor='ne', font=self._bold()).pack(side='left', anchor='n')
        tk.Label(row, text=text, anchor='w', justify='left', wraplength=wrap).pack(side='left', anchor='n')
        side = tk.Frame(row)
        side.pack(side='left', anchor='n', padx=(10, 0))
        return side

    def _note(self, text):
        tk.Label(self._steps, text=text, anchor='w', justify='left', wraplength=700,
                 fg=_C('fg_dim', '#7F8C8D')).pack(fill='x', padx=(28, 0), pady=(6, 0))

    def _msg(self, parent):
        lb = tk.Label(parent, text='', anchor='w', fg=_C('success', '#1E8449'))
        lb.pack(side='left', padx=(8, 0))
        return lb

    def _show_method(self):
        for w in self._steps.winfo_children():
            w.destroy()
        m = self._method.get() if self._method is not None else 'EXT'
        getattr(self, '_m_' + m.lower())()
        _paint(self._steps)

    def _m_ext(self):
        s = self._step(1, _t('YTS2_EXT_1', '확장 파일이 든 폴더를 엽니다.'))
        self._btn(s, _t('YTS_EXT_OPEN2', '폴더 열기'), self._open_ext).pack(side='left')
        self._ext_msg = self._msg(s)
        s = self._step(2, _t('YTS2_EXT_2', '이 주소를 복사해 브라우저 주소창에 붙여 넣습니다.'))
        self._btn(s, _t('YTS2_COPY_CHROME', '크롬 주소 복사'), lambda: self._copy(EXT_URL['CHROME'], self._ext2)).pack(side='left')
        self._btn(s, _t('YTS2_COPY_EDGE', '엣지 주소 복사'), lambda: self._copy(EXT_URL['EDGE'], self._ext2)).pack(side='left', padx=(6, 0))
        self._ext2 = self._msg(s)
        self._step(3, _t('YTS2_EXT_3', '열린 쪽 오른쪽 위 「개발자 모드」를 켜고 「압축해제된 확장 프로그램 로드」를 눌러 1번 폴더를 선택합니다.'))
        self._step(4, _t('YTS2_EXT_4', '주소창 오른쪽 퍼즐 조각을 누르고 +Hagah 옆 핀을 눌러 고정합니다. 이제 주소창 오른쪽에 +Hagah 단추가 늘 보입니다.'))
        s = self._step(5, _t('YTS2_EXT_5', '잘 되는지 봅니다.'))
        self._btn(s, _t('YTS2_TEST', '연결 시험'), self._test).pack(side='left')
        self._test_lbl = self._msg(s)
        self._fix_btn = self._btn(s, _t('YTS2_RESTART', '하가 트레이 다시 켜기'), self._restart_tray)
        s = self._step(6, _t('YTS2_EXT_6', '+Hagah 단추를 누르면'))
        self._quiet = tk.StringVar(value='1' if YT.quiet_on(self.db_path) else '0')
        tk.Radiobutton(s, text=_t('YTS2_Q_NOW', '바로 저장·연결 창을 띄웁니다 (그때그때 심사)'), value='0',
                       variable=self._quiet, command=self._set_quiet).pack(anchor='w')
        tk.Radiobutton(s, text=_t('YTS2_Q_LATER', '조용히 저장만 합니다 (「받은 영상·글 심사」에서 나중에 연결)'),
                       value='1', variable=self._quiet, command=self._set_quiet).pack(anchor='w')
        self._note(_t('YTS2_EXT_NOTE', '하가 앱이나 트레이가 켜져 있어야 단추가 받습니다. 유튜브 영상은 「내 영상」, 그 밖의 쪽은 「내 자료(웹 글)」에 담깁니다. 링크를 우클릭해 +Hagah 를 선택할 수도 있습니다.'))

    def _m_copy(self):
        self._step(1, _t('YTS2_COPY_1', '유튜브 영상 주소를 복사합니다 — 주소창에서 복사하거나 영상 아래 [공유] ▸ [복사].'))
        self._step(2, _t('YTS2_COPY_2', '하가 화면이나 작업표시줄의 하가 트레이 아이콘을 누릅니다. 오른쪽 아래에 저장 창이 뜹니다.'))
        s = self._step(3, _t('YTS2_COPY_3', '창을 놓쳤거나 닫았으면 여기서 다시 엽니다.'))
        self._btn(s, _t('YTS_ASK_NOW', '복사한 주소 저장'), self._ask_now).pack(side='left')
        self._copy_msg = self._msg(s)
        self._note(_t('YTS2_COPY_NOTE', '유튜브 영상 주소 한 줄을 복사했을 때만 묻습니다. 다른 글을 복사한 것에는 묻지 않고, 같은 주소는 한 번만 묻습니다.'))

    def _m_list(self):
        s = self._step(1, _t('YTS2_LIST_1', '유튜브에서 재생목록 하나를 만듭니다. 이름은 「+Hagah」, 공개 범위는 「일부 공개」로 둡니다(비공개면 하가가 읽지 못합니다).'))
        self._btn(s, _t('YTS2_YT_OPEN', '유튜브 열기'), lambda: webbrowser.open('https://www.youtube.com/feed/playlists')).pack(side='left')
        s = self._step(2, _t('YTS2_LIST_2', '그 재생목록 쪽의 주소를 복사해 아래 칸에 붙여 넣고 누릅니다.'))
        self._pl_var = tk.StringVar(value=YT._cfg_get(YT.CFG_PLAYLIST, self.db_path) or '')
        row = tk.Frame(self._steps)
        row.pack(fill='x', padx=(28, 0), pady=(2, 0))
        tk.Entry(row, textvariable=self._pl_var, width=52).pack(side='left', fill='x', expand=True)
        self._btn(row, _t('YTS_PL_SAVE', '저장하고 지금 가져오기'), self._pl_save).pack(side='left', padx=(6, 0))
        self._pl_msg = tk.Label(self._steps, text='', anchor='w', fg=_C('fg_dim', '#7F8C8D'))
        self._pl_msg.pack(fill='x', padx=(28, 0))
        self._pl_show_last()
        self._step(3, _t('YTS2_LIST_3', '앞으로는 폰·TV·PC 어디서든 유튜브 영상 아래 [저장] ▸ 「+Hagah」를 누르면 됩니다.'))
        s = self._step(4, _t('YTS2_LIST_4', '하가가 몇 시간마다 가져와 「받은 영상·글 심사」에 넣습니다. 거기서 구절·용어와 잇습니다.'))
        self._btn(s, _t('YTS2_GO_REVIEW', '심사 화면으로'), self.go_review).pack(side='left')

    def _m_share(self):
        self._step(1, _t('YTS2_SHARE_1', '폰에 하가 앱을 깔고 PC와 연결합니다 — PC 하가의 설정 ▸ 모바일 연결.'))
        self._step(2, _t('YTS2_SHARE_2', '유튜브 앱이나 인터넷 브라우저에서 [공유] ▸ 「+Hagah」를 누릅니다. 처음 한 번은 공유 줄 끝의 [더보기]에서 찾습니다.'))
        s = self._step(3, _t('YTS2_SHARE_3', '폰과 PC를 동기화하면 「받은 영상·글 심사」에 들어옵니다. 거기서 구절·용어와 잇습니다.'))
        self._btn(s, _t('YTS2_GO_REVIEW', '심사 화면으로'), self.go_review).pack(side='left')

    # ── 설정 갈래의 움직임 ──────────────────────────────────────────
    def _copy(self, text, lbl):
        try:
            self.clipboard_clear()
            self.clipboard_append(text)
            lbl.config(text=_t('YTS2_COPIED', '복사했습니다'), fg=_C('success', '#1E8449'))
        except Exception as e:
            lbl.config(text=str(e), fg=_C('danger', '#C0392B'))

    def _open_ext(self):
        """확장 프로그램 폴더(browser_ext) — 「압축해제된 확장 프로그램 로드」에 선택할 곳."""
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'browser_ext')
        try:
            os.startfile(p)
            self._ext_msg.config(text=_t('YTS2_OPENED', '열었습니다'), fg=_C('success', '#1E8449'))
        except Exception as e:
            self._ext_msg.config(text=str(e), fg=_C('danger', '#C0392B'))

    def _test(self):
        self._test_lbl.config(text=_t('YTS2_TESTING', '보는 중…'), fg=_C('fg_dim', '#7F8C8D'))
        self._fix_btn.pack_forget()
        q = queue.Queue()
        threading.Thread(target=lambda: q.put(probe()), daemon=True).start()

        def _poll():
            try:
                st = q.get_nowait()
            except queue.Empty:
                if self.winfo_exists():
                    self.after(200, _poll)
                return
            if st == 'OK':
                self._test_lbl.config(text=_t('YTS2_T_OK', '● 받을 준비가 되었습니다'), fg=_C('success', '#1E8449'))
            elif st == 'OLD':
                self._test_lbl.config(text=_t('YTS2_T_OLD', '옛 판 하가 트레이가 자리를 잡고 있습니다'),
                                      fg=_C('warning', '#B9770E'))
                self._fix_btn.pack(side='left', padx=(8, 0))
            else:
                self._test_lbl.config(text=_t('YTS2_T_NONE', '아무도 받지 않습니다 — 하가를 다시 켜 주세요'),
                                      fg=_C('danger', '#C0392B'))
                self._fix_btn.pack(side='left', padx=(8, 0))
        self.after(200, _poll)

    def _restart_tray(self):
        try:
            import tray_agent
            tray_agent.launch(replace=True)
            self._test_lbl.config(text=_t('YTS2_T_RESTART', '다시 켜는 중… 몇 초 뒤 [연결 시험]을 다시 누르세요'),
                                  fg=_C('fg_dim', '#7F8C8D'))
        except Exception as e:
            self._test_lbl.config(text=str(e), fg=_C('danger', '#C0392B'))

    def _set_quiet(self):
        YT._cfg_put(YT.CFG_QUIET, self._quiet.get(), self.db_path)

    def _ask_now(self):
        """지금 클립보드의 유튜브 주소를 묻는다 — 이미 물었거나 넘긴 주소여도."""
        try:
            s = self.clipboard_get()
        except Exception:
            s = ''
        url = YT.should_ask(s, self.db_path, force=True)
        if not url:
            self._copy_msg.config(text=_t('YTS_NO_CLIP', '클립보드에 유튜브 영상 주소가 없습니다'),
                                  fg=_C('warning', '#B9770E'))
            return
        self._copy_msg.config(text='')
        YT.mark_asked(url, self.db_path)
        import yt_save_win
        yt_save_win.offer(self.winfo_toplevel(), self.db_path, url, '', self._lang(),
                          on_saved=lambda _u: self.refresh())

    def _pl_show_last(self):
        last = YT._cfg_get(YT.CFG_PLAYLIST_LAST, self.db_path) or ''
        if '|' in last:
            when, msg = last.split('|', 1)
            self._pl_msg.config(text=_t('YTS_PL_LAST', '마지막으로 읽은 때 %s — %s') % (when, msg),
                                fg=_C('fg_dim', '#7F8C8D'))
        elif not (self._pl_var.get() or '').strip():
            self._pl_msg.config(text=_t('YTS2_PL_NONE', '아직 재생목록 주소가 없습니다'), fg=_C('fg_dim', '#7F8C8D'))

    def _pl_save(self):
        """주소를 저장하고 그 자리에서 한 번 읽는다 — 일꾼 스레드(망) · 결과는 after 로."""
        txt = (self._pl_var.get() or '').strip()
        if txt and not YT.playlist_id(txt):
            self._pl_msg.config(text=_t('YTS_PL_BAD', '재생목록 주소가 아닙니다 — 주소에 「list=」 가 있어야 합니다'),
                                fg=_C('warning', '#B9770E'))
            return
        YT._cfg_put(YT.CFG_PLAYLIST, txt, self.db_path)
        if not txt:
            self._pl_msg.config(text=_t('YTS_PL_OFF', '재생목록을 쓰지 않습니다'), fg=_C('fg_dim', '#7F8C8D'))
            return
        self._pl_msg.config(text=_t('YTS_PL_WORK', '읽는 중…'), fg=_C('fg_dim', '#7F8C8D'))
        q = queue.Queue()
        threading.Thread(target=lambda: q.put(YT.playlist_tick(self.db_path, force=True)), daemon=True).start()

        def _poll():
            try:
                q.get_nowait()
            except queue.Empty:
                if self.winfo_exists():
                    self.after(300, _poll)
                return
            self._pl_show_last()
            self.refresh()
        self.after(300, _poll)

    # ── 갈래 2: 받은 영상·글 심사 ───────────────────────────────────
    def _build_review(self, f):
        bar = tk.Frame(f)
        bar.pack(fill='x', padx=8, pady=(0, 4))
        self._filter = tk.StringVar(value='TODO')
        tk.Radiobutton(bar, text=_t('YTS2_F_TODO', '연결 전'), value='TODO', variable=self._filter,
                       indicatoron=0, padx=10, pady=2, command=self.refresh).pack(side='left')
        tk.Radiobutton(bar, text=_t('YTS2_F_ALL', '전체'), value='ALL', variable=self._filter,
                       indicatoron=0, padx=10, pady=2, command=self.refresh).pack(side='left', padx=(2, 0))
        self._cnt = tk.Label(bar, text='', fg=_C('fg_dim', '#7F8C8D'))
        self._cnt.pack(side='left', padx=8)
        self._btn(bar, _t('YTS_HIDE', '숨기기'), self._hide).pack(side='right')
        self._btn(bar, _t('YTS2_BROWSER', '브라우저에서 열기'), self._open).pack(side='right', padx=(0, 6))
        self._btn(bar, _t('YTS_REFRESH', '새로 고침'), self.refresh).pack(side='right', padx=(0, 6))

        pw = tk.PanedWindow(f, orient='horizontal', sashwidth=6, sashrelief='raised', bd=0)
        pw.pack(fill='both', expand=True, padx=8, pady=(0, 8))
        left = tk.Frame(pw)
        cols = ('kind', 'verses', 'terms')
        tv = ttk.Treeview(left, columns=cols, show='tree headings', selectmode='browse')
        tv.heading('#0', text=_t('YTS_COL_TITLE', '제목'))
        tv.heading('kind', text=_t('YTS_COL_KIND', '갈래'))
        tv.heading('verses', text=_t('YTS_VERSES', '구절'))
        tv.heading('terms', text=_t('YTS_TERMS', '주요용어'))
        tv.column('#0', width=300)
        for c, w in (('kind', 70), ('verses', 50), ('terms', 74)):
            tv.column(c, width=w, anchor='center', stretch=False)
        sb = ttk.Scrollbar(left, command=tv.yview)
        tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        tv.pack(fill='both', expand=True)
        tv.bind('<<TreeviewSelect>>', lambda e: self._on_pick())
        self._tv = tv
        pw.add(left, minsize=260, width=520)

        right = tk.Frame(pw)
        rb = tk.Frame(right)
        rb.pack(fill='x')
        self._rtab = tk.StringVar(value='LINK')
        tk.Radiobutton(rb, text=_t('YTS2_R_PLAY', '재생'), value='PLAY', variable=self._rtab, indicatoron=0,
                       padx=12, pady=2, command=self._show_right).pack(side='left')
        tk.Radiobutton(rb, text=_t('YTS2_R_LINK', '연결'), value='LINK', variable=self._rtab, indicatoron=0,
                       padx=12, pady=2, command=self._show_right).pack(side='left', padx=(2, 0))
        self._play = tk.Frame(right, bg=_C('panel_alt', '#F4F6F7'))
        self._play_host = tk.Frame(self._play, bg='black')
        self._play_note = tk.Label(self._play, text=_t('YTS2_PLAY_PICK', '왼쪽에서 하나를 선택하세요'),
                                   anchor='center', bg=_C('panel_alt', '#F4F6F7'))
        self._play_note.pack(fill='both', expand=True)
        self._link = tk.Frame(right)
        self._ed = LinkEditor(self._link, self.db_path, self._lang, on_saved=self._after_save)
        self._ed.pack(fill='both', expand=True)
        pw.add(right, minsize=300)
        self._show_right()

    def _show_right(self):
        t = self._rtab.get() if self._rtab is not None else 'LINK'
        self._play.pack_forget()
        self._link.pack_forget()
        (self._play if t == 'PLAY' else self._link).pack(fill='both', expand=True, pady=(4, 0))
        if t == 'PLAY':
            self._load_play()
        elif self._player is not None:
            try:
                self._player.clear()
            except Exception:
                pass

    # ── 심사 갈래의 움직임 ──────────────────────────────────────────
    def refresh(self):
        tv = getattr(self, '_tv', None)
        if tv is None:
            return
        keep = self._cur_key
        tv.delete(*tv.get_children())
        self._rows = {}
        try:
            conn = appdb.connect(self.db_path)
            try:
                rows = YT.received_all(conn)
            finally:
                conn.close()
        except Exception as e:
            rows = []
            print('[yt_save_view] %s' % e)
        todo = [r for r in rows if not (r['verses'] or r['terms'])]
        only = self._filter.get() if self._filter is not None else 'TODO'
        shown = todo if only == 'TODO' else rows
        for r in shown:
            ik, ko = KIND_NAME.get(r['kind'], ('', r['kind']))
            tv.insert('', 'end', iid=r['key'], text=r['title'],
                      values=(_t(ik, ko) if ik else ko, r['verses'] or '–', r['terms'] or '–'))
            self._rows[r['key']] = r
        if not shown:
            tv.insert('', 'end', iid='_empty',
                      text=(_t('YTS2_EMPTY_TODO', '연결할 것이 없습니다 — 「전체」에서 지난 것을 봅니다')
                            if only == 'TODO' else
                            _t('YTS2_EMPTY', '아직 받은 영상·글이 없습니다 — 「저장 방법 설정」을 보세요')))
        self._cnt.config(text=_t('YTS2_COUNT', '연결 전 %d · 전체 %d') % (len(todo), len(rows)))
        try:
            self._br_review.config(text=_t('YTS2_BR_REVIEW', '받은 영상·글 심사') +
                                   ((' (%d)' % len(todo)) if todo else ''))
        except Exception:
            pass
        if keep and keep in self._rows:
            tv.selection_set(keep)
            tv.see(keep)

    def _cur(self):
        sel = self._tv.selection()
        return self._rows.get(sel[0]) if sel else None

    def _on_pick(self):
        r = self._cur()
        if not r or r['key'] == self._cur_key:
            return
        self._cur_key = r['key']
        if self._ed is not None:
            self._ed.load(r)
        if self._rtab.get() == 'PLAY':
            self._load_play()

    def _load_play(self):
        r = self._cur()
        if not r:
            return
        p = YT.parse(r['url'])
        if not p:          # 웹 글 — 하가 안에서 그리지 않는다(남의 글 · 저작권)
            if self._player is not None:
                try:
                    self._player.clear()
                except Exception:
                    pass
            self._play_host.pack_forget()
            self._play_note.config(text=_t('YTS2_WEB_PLAY', '웹 글은 브라우저에서 엽니다 — 위 [브라우저에서 열기]'))
            self._play_note.pack(fill='both', expand=True)
            return
        self._play_note.pack_forget()
        self._play_host.pack(fill='both', expand=True)
        try:
            if self._player is None:
                import media_player
                self._player = media_player.EmbeddedPlayer(self._play_host)
            self._player.play(p[0])
        except Exception as e:
            self._play_host.pack_forget()
            self._play_note.config(text=str(e))
            self._play_note.pack(fill='both', expand=True)

    def _after_save(self):
        self.refresh()

    def _open(self):
        r = self._cur()
        if r:
            webbrowser.open(r['url'])

    def _hide(self):
        r = self._cur()
        if not r:
            return
        try:
            conn = appdb.connect(self.db_path)
            try:
                if r['web']:
                    conn.execute("UPDATE userdb.user_ref_asset SET record_status='HIDE' WHERE ref_id=?", (r['uid'],))
                else:
                    import link_picker as LP
                    LP.hide_user_media(conn, r['uid'], True)
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            print('[yt_save_view hide] %s' % e)
        self._cur_key = None
        if self._ed is not None:
            self._ed.load(None)
        self.refresh()


class LinkEditor(tk.Frame):
    """오른쪽 「연결」 칸 — 선택한 영상·글의 구절·용어를 그 자리에서 고친다(팝업 없이).

    ★ 저장 문은 알림 창과 같다(`yt_intake.save` · `save_web`) — 두 벌을 두지 않는다.
    · 걸린 것은 체크된 채 · 연결이 하나도 없으면 제목에서 **추천**을 구해 「추천」 표시로 붙인다(체크 안 한 채).
    · 체크를 푼 연결은 숨긴다(지우지 않는다).
    """

    def __init__(self, parent, db_path, lang_getter, on_saved=None):
        super().__init__(parent)
        self.db_path = db_path
        self.lang_getter = lang_getter
        self.on_saved = on_saved
        self.r = None
        self._vchk, self._tchk = [], []
        self._q = queue.Queue()
        top = tk.Frame(self)
        top.pack(fill='x', padx=6, pady=(6, 2))
        self._save_btn = tk.Button(top, text=_t('YTS2_SAVE_LINK', '연결 저장'), command=self._save,
                                   bd=1, relief='raised', padx=10, state='disabled')
        self._save_btn.pack(side='left')
        self._status = tk.Label(top, text='', anchor='w', fg=_C('success', '#1E8449'))
        self._status.pack(side='left', padx=8)
        try:
            import tkinter.font as tkfont
            f = tkfont.nametofont('TkDefaultFont').actual()
            self._b = (f['family'], f['size'], 'bold')
        except Exception:
            self._b = None
        self._title = tk.Label(self, text=_t('YTS2_PLAY_PICK', '왼쪽에서 하나를 선택하세요'), anchor='w',
                               justify='left', wraplength=420, font=self._b)
        self._title.pack(fill='x', padx=8, pady=(2, 4))
        self._title.bind('<Configure>', lambda e: self._title.config(wraplength=max(200, e.width - 10)))
        self._kr = tk.Frame(self)
        tk.Label(self._kr, text=_t('YTS_KIND', '갈래')).pack(side='left')
        self._kind = tk.StringVar(value='STUDY')
        for code, ko in (('SERMON', '설교'), ('WORSHIP', '찬양'), ('STUDY', '성경공부')):
            tk.Radiobutton(self._kr, text=_t('YTS_K_' + code, ko), value=code,
                           variable=self._kind).pack(side='left', padx=(6, 0))
        # 구절 · 용어 — 굴리는 칸 하나
        wrap = tk.Frame(self)
        wrap.pack(fill='both', expand=True, padx=6)
        self._wrap = wrap
        cv = tk.Canvas(wrap, highlightthickness=0, bd=0)
        sb = ttk.Scrollbar(wrap, command=cv.yview)
        cv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        cv.pack(side='left', fill='both', expand=True)
        body = tk.Frame(cv)
        win = cv.create_window(0, 0, anchor='nw', window=body)
        body.bind('<Configure>', lambda e: cv.configure(scrollregion=cv.bbox('all')))
        cv.bind('<Configure>', lambda e: cv.itemconfigure(win, width=e.width))
        tk.Label(body, text=_t('YTS_VERSES', '구절'), anchor='w', font=self._b).pack(fill='x', pady=(2, 0))
        vr = tk.Frame(body)
        vr.pack(fill='x', padx=10, pady=(2, 2))
        self._vent = tk.Entry(vr, width=18)
        self._vent.pack(side='left')
        self._vent.bind('<Return>', lambda e: self._add_verse())
        tk.Button(vr, text=_t('YTS_ADD_V', '구절 더하기'), command=self._add_verse,
                  bd=1, relief='raised', padx=4).pack(side='left', padx=(4, 0))
        tk.Label(vr, text=_t('YTS2_V_EX', '예: 롬 8:28'), fg=_C('fg_dim', '#7F8C8D')).pack(side='left', padx=6)
        self._vbox = tk.Frame(body)
        self._vbox.pack(fill='x', padx=10)
        tk.Label(body, text=_t('YTS_TERMS', '주요용어'), anchor='w', font=self._b).pack(fill='x', pady=(8, 0))
        tr = tk.Frame(body)
        tr.pack(fill='x', padx=10, pady=(2, 2))
        self._tent = tk.Entry(tr, width=18)
        self._tent.pack(side='left')
        self._tent.bind('<Return>', lambda e: self._add_term())
        tk.Button(tr, text=_t('YTS_FIND_T', '용어 찾기'), command=self._add_term,
                  bd=1, relief='raised', padx=4).pack(side='left', padx=(4, 0))
        self._tbox = tk.Frame(body)
        self._tbox.pack(fill='x', padx=10)
        self._pump()

    def _lang(self):
        try:
            return (self.lang_getter() or 'KO').upper()
        except Exception:
            return 'KO'

    def _clear(self):
        for w in list(self._vbox.winfo_children()) + list(self._tbox.winfo_children()):
            w.destroy()
        self._vchk, self._tchk = [], []

    def load(self, r):
        self.r = r
        self._clear()
        self._status.config(text='')
        self._kr.pack_forget()
        if not r:
            self._title.config(text=_t('YTS2_PLAY_PICK', '왼쪽에서 하나를 선택하세요'))
            self._save_btn.config(state='disabled')
            return
        self._title.config(text=r['title'] or r['url'])
        self._save_btn.config(state='normal')
        lang = self._lang()
        conn = appdb.connect(self.db_path)
        try:
            lk = YT.web_links_of(conn, r['uid']) if r['web'] else YT.links_of(conn, r['uid'])
            for s, e in lk['verses']:
                self._add_v(s, e, YT.verse_name(conn, s, e, lang), True)
            for eid in lk['terms']:
                self._add_t(eid, YT.entity_name(conn, eid, lang), True)
        finally:
            conn.close()
        if not r['web']:
            self._kind.set(r['kind'] if r['kind'] in YT.MEDIA_TYPES else 'STUDY')
            self._kr.pack(fill='x', padx=8, pady=(0, 4), before=self._wrap)
        if not (lk['verses'] or lk['terms']) and not r['web']:
            key, title = r['key'], r['title'] or ''

            def _work():
                try:
                    c = appdb.connect(self.db_path)
                    try:
                        self._q.put((key, YT.suggest(c, title, lang)))
                    finally:
                        c.close()
                except Exception as ex:
                    print('[yt_save_view suggest] %s' % ex)
            threading.Thread(target=_work, daemon=True).start()

    def _pump(self):
        try:
            while True:
                key, d = self._q.get_nowait()
                if not self.r or self.r['key'] != key:
                    continue
                tag = _t('YTS2_SUG', '추천')
                for s, e, nm in d.get('verses') or ():
                    self._add_v(s, e, '%s · %s' % (tag, nm), False)
                for eid, nm in d.get('terms') or ():
                    self._add_t(eid, '%s · %s' % (tag, nm), False)
        except queue.Empty:
            pass
        except Exception as e:
            print('[yt_save_view pump] %s' % e)
        if self.winfo_exists():
            self.after(200, self._pump)

    def _add_v(self, s, e, name, on):
        for v, ss, ee in [(x[0], x[1], x[2]) for x in self._vchk]:
            if (ss, ee) == (s, e):
                v.set(v.get() or on)
                return
        v = tk.BooleanVar(value=on)
        cb = tk.Checkbutton(self._vbox, text=name, variable=v, anchor='w')
        cb.pack(fill='x')
        _paint(cb)
        self._vchk.append((v, s, e))

    def _add_t(self, eid, name, on):
        for v, ee in self._tchk:
            if ee == eid:
                v.set(v.get() or on)
                return
        v = tk.BooleanVar(value=on)
        cb = tk.Checkbutton(self._tbox, text=name, variable=v, anchor='w')
        cb.pack(fill='x')
        _paint(cb)
        self._tchk.append((v, eid))

    def _add_verse(self):
        txt = self._vent.get().strip()
        if not txt or not self.r:
            return
        lang = self._lang()
        hits = []
        try:
            import scripture_ref
            conn = appdb.connect(self.db_path)
            try:
                hits = scripture_ref.find(conn, txt, lang)
                for s, e, _m, _k in hits:
                    self._add_v(s, e, YT.verse_name(conn, s, e, lang), True)
            finally:
                conn.close()
        except Exception as ex:
            print('[yt_save_view verse] %s' % ex)
        if hits:
            self._vent.delete(0, 'end')
            self._status.config(text='')
        else:
            self._status.config(text=_t('YTS_NO_VERSE', '구절을 읽지 못했습니다 — 예: 롬 8:28'),
                                fg=_C('warning', '#B9770E'))

    def _add_term(self):
        q = self._tent.get().strip()
        if not q or not self.r:
            return
        conn = appdb.connect(self.db_path)
        try:
            rows = conn.execute(
                "SELECT t.clicked_id, t.contents FROM sys_text_asset t JOIN sys_entity_master m"
                " ON m.entity_id=t.clicked_id AND COALESCE(m.record_status,'LIVE')='LIVE'"
                " WHERE t.text_type='ENTITY_NAME' AND UPPER(t.lang_code)=? AND t.contents LIKE ?"
                " ORDER BY LENGTH(t.contents) LIMIT 5", (self._lang(), '%' + q + '%')).fetchall()
        finally:
            conn.close()
        for eid, nm in rows:
            self._add_t(eid, nm, len(rows) == 1)
        if rows:
            self._tent.delete(0, 'end')
            self._status.config(text='')
        else:
            self._status.config(text=_t('YTS_NO_TERM', '그런 용어가 없습니다'), fg=_C('warning', '#B9770E'))

    def _save(self):
        r = self.r
        if not r:
            return
        vs = [(s, e) for v, s, e in self._vchk if v.get()]
        ts = [eid for v, eid in self._tchk if v.get()]
        conn = appdb.connect(self.db_path)
        try:
            vt, tt = ('UREF_VERS', 'UREF_ENTI') if r['web'] else ('UMED_VERS', 'MEDI_ENTI')
            vtypes = (vt,) if r['web'] else ('UMED_VERS', 'MEDI_VERS')
            for v, s, e in self._vchk:            # 체크를 푼 연결은 숨긴다(지우지 않는다)
                if not v.get():
                    conn.execute(
                        "UPDATE userdb.user_link_asset SET record_status='HIDE' WHERE clicked_id=?"
                        ' AND link_type IN (%s) AND target_id=? AND COALESCE(end_id,target_id)=?'
                        % ','.join('?' * len(vtypes)), (r['uid'],) + vtypes + (s, e))
            for v, eid in self._tchk:
                if not v.get():
                    conn.execute("UPDATE userdb.user_link_asset SET record_status='HIDE'"
                                 ' WHERE clicked_id=? AND link_type=? AND target_id=?', (r['uid'], tt, eid))
            if r['web']:
                YT.save_web(conn, r['url'], r['title'], vs, ts, self._lang())
            else:
                conn.execute('UPDATE userdb.user_media_asset SET category=? WHERE user_media_id=?',
                             (self._kind.get(), r['uid']))
                YT.save(conn, r['url'], r['title'], self._kind.get(), vs, ts, self._lang())
            conn.commit()
        except Exception as e:
            self._status.config(text=str(e), fg=_C('danger', '#C0392B'))
            return
        finally:
            conn.close()
        self._status.config(text=_t('YTS_SAVED_N2', '저장했습니다 · 구절 %d · 용어 %d') % (len(vs), len(ts)),
                            fg=_C('success', '#1E8449'))
        if callable(self.on_saved):
            self.on_saved()


def selftest():
    ok = [0, 0]

    def t(name, cond):
        ok[0] += 1
        ok[1] += bool(cond)
        print(('PASS ' if cond else 'FAIL ') + name)
    t('방법 넷 — PC 둘 · 폰·TV 둘', [m[1] for m in METHODS] == ['PC', 'PC', 'MOB', 'MOB'])
    t('방법마다 차례 함수가 있다', all(hasattr(YtSaveView, '_m_' + m[0].lower()) for m in METHODS))
    t('북마크 단추는 없다(폐기 2026-10-12)', [m[0] for m in METHODS] == ['EXT', 'COPY', 'LIST', 'SHARE'])
    t('probe — 아무도 안 받으면 NONE', probe(port=1, timeout=0.3) == 'NONE')
    print('yt_save_view selftest %d/%d' % (ok[1], ok[0]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
