# -*- coding: utf-8 -*-
"""db_book_artifact.py — 본문에 섞인 **전사 흔적**을 찾아 걷는다
================================================================================
`python db_book_artifact.py --selftest`        — 의무
`python db_book_artifact.py --scan`            — 전 도서 훑기 (DB 안 건드림)
`python db_book_artifact.py --show CODE`       — 그 책의 흔적을 줄째로 보기
`python db_book_artifact.py --apply CODE …`    — 걷어낸다 (멱등 · 백업)

━━ 무엇이 흔적인가 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
저자가 쓴 글이 아니라 **옮긴 사람·전자책 만든 곳이 붙인 것**이다.
  · 구텐베르크 머리말·꼬리말 (`*** START OF …`, `pglaf.org`, `Produced by …`)
  · 전사자 주석 (`Transcribed from the 1905 … edition by David Price`,
    `… not been included in this Project Gutenberg eText.—DP.`)
  · 그림 자리 표시 (`[Picture: Book cover]`) — 우리는 그림을 담지 않는다
  · 도서관 장서표·대출 카드 (스캔본)

★ 실측 계기 — 번연 『넘치는 은혜』 1편이 `EBOOK … ***` 로 시작하고 있었다
  (2026-08-22). 본문 자체는 구텐베르크 #654 와 **문장 100% 일치**하는 진본이라
  다시 받을 필요가 없었다. **걷어내면 되는 일**이었다.

⚠ **저자의 글을 지우지 않는다** — 걷는 것은 위 목록뿐이고, 걷은 뒤 원문과
  다시 대조해 일치율이 떨어지지 않았는지 확인한다(`db_book_verify`).
⚠ 각주는 **남긴다** — `{184} …` 처럼 1905년판이 달아 둔 것은 책의 일부다.
  전사자가 붙인 `{7} … eText.—DP.` 만 걷는다.
"""
import io
import re
import sys

sys.path.insert(0, __file__.rsplit('\\', 1)[0] if '\\' in __file__ else '.')
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import appdb

DB = 'bible_master.db'
BACKUP = 'temp_book_artifact_backup'

# (이름, 정규식, 방식)  방식 'line' = 그 줄을 통째로 / 'inline' = 그 자리만
PATTERNS = [
    ('구텐베르크 표식',
     r'^.*\*\*\*\s*(START|END) OF (THE|THIS) PROJECT GUTENBERG.*$', 'line'),
    ('구텐베르크 표식',
     r'^\s*(EBOOK|E-?BOOK)\b.*\*\*\*\s*$', 'line'),
    ('구텐베르크 주소',
     r'^.*(pglaf\.org|gutenberg\.org|gutenberg\.net).*$', 'line'),
    ('전사자 주석',
     r'^.*Transcribed from .{0,80}edition by .*$', 'line'),
    # ⚠⚠ **줄 첫머리로 못 박는다.** `^.*Produced by` 로 두었더니 본문 산문의
    #   「…is produced by…」에 걸려 **저자의 문단을 통째로 지울 뻔했다**
    #   (스펄전 설교 25곳 · 바운즈 1곳 · 밀러 1곳 — 실측으로 잡았다).
    ('전사자 주석', r'^\s*Produced by [A-Z].{0,90}$', 'line'),
    ('전사자 주석', r'^.*Project Gutenberg eText.*$', 'line'),
    ('전사자 주석',
     r'^.*This eBook is for the use of anyone anywhere.*$', 'line'),
    # ⚠ 새 판 구텐베르크는 라이선스 문단을 본문 꼬리에 흘려 넣는다 —
    #   켐피스 118편 끝에 두 줄이 붙어 있었다(2026-08-23 실측). 주소(pglaf 등)가
    #   없어 위 패턴에 안 걸린다. **줄 첫머리로 못 박아** 저자의 산문을 지우지
    #   않게 한다(그 두 문장은 PG 라이선스 고유 문구다).
    ('구텐베르크 라이선스',
     r'^Updated editions will replace the previous one.*$', 'line'),
    ('구텐베르크 라이선스',
     r'^Creating the works from print editions not protected by U\.S\. '
     r'copyright law.*$', 'line'),
    ('그림 자리', r'\[Picture:[^\]]*\]', 'inline'),
    ('그림 자리', r'\[Illustration:[^\]]*\]', 'inline'),
    ('도서관 표식',
     r'^\s*(Return this material|Please Note: This item|Date Due|'
     r'SOUTHERN REGIONAL LIBRARY).*$', 'line'),
    # ★ 장서표·바코드 뒤는 **뒤표지**다 — 저자의 글이 한 줄도 없다.
    #   실측(2026-08-29 마이어) — `Prmceton Theoloqical Seminary Libraries !`
    #   아래로 바코드 한 줄과 **바코드 그림을 OCR 한 잡음 여덟 줄**
    #   (`:illi|ii` · `liiliiiiiiii:"` …)이 이어졌다. 그 여덟 줄은 생김새로는
    #   못 잡는다 — 무모음 규칙을 재 보니 **스펄전 찬송 89줄**을 삼켰다.
    #   ⇒ 낱낱을 맞추지 말고 **자리로** 자른다.
    ('도서관 표식',
     r'^.{0,60}(Seminary|University|College|Public|Municipal)\s+'
     r'Librar(?:y|ies).{0,10}$', 'tail'),
    ('도서관 표식', r'^\s*\d[\d ]{9,}\s*[\'"]?\s*$', 'tail'),
]
_COMPILED = [(n, re.compile(p, re.M | re.I), how) for n, p, how in PATTERNS]

# 적재기가 맨 끝에 붙인 출처 한 줄 — 꼬리를 걷을 때 **이것만은 지킨다**
# (§0-1b 저작권 표시. 걷어 버리면 화면에서 출처가 사라진다)
_KEEP_ATTRIB = re.compile(
    r'^\s*(?:—|--)\s*.{0,140}(?:Public domain\.|\(\d{4}\)\.?)\s*$')

# ── 장 번호가 잘려 본문 머리에 남은 조각 ──────────────────────────────────
# 실측(셸던 2026-08-22) — 나누는 규칙이 `Chapter Four` 를 먼저 맞춰 버려서
# `Chapter Fourteen` 이 잘리고 본문이 **`teen BUT more than…`** 으로 시작했다.
# 열넷 章이 그랬다. 제목은 `unit_label` 에 온전하니 **조각만 떼면 된다.**
# ⚠ 반드시 **본문 맨 앞**에서만 뗀다 — `re.M` 로 두면 본문 중간의 「-one」
#   같은 줄을 잘라 저자의 글을 지운다.
_HEADFRAG = re.compile(
    r'^\s*(teen|-one|-two|-three|-four|-five|-six|-seven|-eight|-nine|'
    r'-ten|ty|teenth)\b[ \t]*')


def head_fragment(body):
    m = _HEADFRAG.match(body or '')
    return m.group(0).strip() if m else None


# ── 본문 **맨 끝**에 흘린 쪽 번호 조각 ────────────────────────────────────
# 스캔본은 쪽 번호를 본문 끝에 떨어뜨린다 — `lU`(114) · `X56`(156) · `2U0`(200) ·
# `1»1` · `d08` · `j I`. 저자의 글이 아니라 §1-2 ④ 전사자 개입이다.
# ⚠⚠ **맨 끝일 때만** 뗀다. 자리 조건 없이 「짧은 줄」로만 재었더니 스펄전의
#   `So it` 과 파스칼의 `J. C.`(예수 그리스도)까지 삼켰다(실측). 자리가 잣대다.
# ⚠ **숫자와 로마 숫자는 남긴다** — 파스칼 924줄 · 이그나티우스 91줄 ·
#   폴리카르포스 36줄이 **저자의 번호**다. 그것을 걷으면 책의 뼈대가 사라진다.
# ⚠ 네 글자 이상 이어지면 낱말로 보고 남긴다(`Amen.` · `NOTE` · `Luke`).
# 실측 = 전 코퍼스 **20편 3권**(마이어 18 · 밀러 1 · 번연 1) · 오탐 0.
_TAILSTUB = re.compile(
    r'^(?!\W*\d+\W*$)(?![IVXLCDM]+[.):]?$)(?!.*[A-Za-z]{4}).{1,5}$')


def tail_stub(body):
    """본문 맨 끝의 쪽 번호 조각 → 그 글자 (없으면 None)

    ⚠ 출처 한 줄은 본문이 아니므로 건너뛰고 그 앞을 본다.
    """
    live = [ln for ln in (body or '').split('\n')
            if ln.strip() and not _KEEP_ATTRIB.match(ln)]
    if not live:
        return None
    s = live[-1].strip()
    return s if _TAILSTUB.match(s) else None


def find(body):
    """흔적을 찾는다 → [(이름, 걸린 글자)]"""
    out = []
    hf = head_fragment(body)
    if hf:
        out.append(('장번호 조각', hf))
    ts = tail_stub(body)
    if ts:
        out.append(('쪽번호 조각', ts))
    for name, rx, how in _COMPILED:
        if how == 'tail':
            continue
        for m in rx.finditer(body or ''):
            s = ' '.join(m.group(0).split())
            if s:
                out.append((name, s))
    for name, s in _tail_cut(body or '')[1]:
        out.append((name, s))
    return out


def _tail_cut(body):
    """꼬리를 걷을 자리를 찾는다 → (자른 줄 목록, [(이름, 걸린 글자)])

    ⚠ **첫 자리에서 자른다** — 장서표가 먼저 오고 바코드가 뒤따르므로
      나중 것으로 자르면 앞의 장서표가 본문에 남는다.
    """
    lines = (body or '').split('\n')
    for i, ln in enumerate(lines):
        for name, rx, how in _COMPILED:
            if how != 'tail' or not rx.match(ln):
                continue
            found = [(name, ' '.join(x.split()))
                     for x in lines[i:] if x.strip()
                     and not _KEEP_ATTRIB.match(x)]
            keep = lines[:i] + [x for x in lines[i:] if _KEEP_ATTRIB.match(x)]
            return keep, found
    return lines, []


def strip(body):
    """걷어낸다. 저자의 글은 건드리지 않는다."""
    t = _HEADFRAG.sub('', body or '', count=1)   # 맨 앞 한 번만
    t = '\n'.join(_tail_cut(t)[0])
    ts = tail_stub(t)
    if ts:                                       # 맨 끝 쪽 번호 조각 한 줄만
        ln = t.split('\n')
        for i in range(len(ln) - 1, -1, -1):
            if ln[i].strip() == ts:
                del ln[i]
                break
        t = '\n'.join(ln)
    for name, rx, how in _COMPILED:
        if how == 'tail':
            continue
        t = rx.sub('' if how == 'inline' else '\x00', t)
    # 통째로 지운 줄이 남긴 빈 자리를 정리한다
    t = '\n'.join(l for l in t.split('\n') if '\x00' not in l)
    t = re.sub(r'[ \t]+\n', '\n', t)
    t = re.sub(r'\n{3,}', '\n\n', t)
    return t.strip('\n')


def _rows(conn, code=None):
    sql = """SELECT a.book_code, u.sequence, u.unit_label, x.text_id,
                    x.body_text
               FROM sys_book_unit u
               JOIN sys_book_asset a ON a.book_id=u.book_id
               JOIN sys_book_unit_text x ON x.unit_id=u.unit_id
              WHERE x.text_variant='ORIGINAL'
                AND COALESCE(a.record_status,'LIVE')='LIVE'
                AND COALESCE(u.record_status,'LIVE')='LIVE'
                AND COALESCE(x.record_status,'LIVE')='LIVE'"""
# ⚠ **유닛·본문의 record_status 도 본다** (2026-08-29). 그전에는 책만 보아
#   **밀려난 옛 적재분(HIDE)까지 고쳤다** — 화면에 없는 행이라 고쳐도 소용이
#   없고, `--scan` 수치에 죽은 행이 섞여 **보고가 사람을 속인다**(실제로
#   마이어 장서표가 두 편에 있는 것처럼 보였는데 산 것은 #679 하나였다).
    args = ()
    if code:
        sql += " AND a.book_code=?"
        args = (code,)
    return conn.execute(sql + " ORDER BY a.book_code, u.sequence",
                        args).fetchall()


def scan(conn):
    tally = {}
    for code, seq, lab, tid, body in _rows(conn):
        for name, s in find(body):
            d = tally.setdefault(code, {})
            d[name] = d.get(name, 0) + 1
    return tally


def apply(conn, codes, dry=False):
    conn.execute("CREATE TABLE IF NOT EXISTS %s ("
                 " text_id INTEGER, book_code TEXT, sequence INTEGER,"
                 " body_text TEXT)" % BACKUP)
    n_unit = n_hit = 0
    for code in codes:
        for c2, seq, lab, tid, body in _rows(conn, code):
            hits = find(body)
            if not hits:
                continue
            new = strip(body)
            n_unit += 1
            n_hit += len(hits)
            if dry:
                continue
            have = conn.execute("SELECT 1 FROM %s WHERE text_id=?" % BACKUP,
                                (tid,)).fetchone()
            if not have:
                conn.execute("INSERT INTO %s VALUES (?,?,?,?)" % BACKUP,
                             (tid, code, seq, body))
            conn.execute("UPDATE sys_book_unit_text SET body_text=? "
                         " WHERE text_id=?", (new, tid))
    return n_unit, n_hit


def _selftest():
    fails = []

    def ck(n, ok, got=''):
        print(('  OK  ' if ok else '  FAIL') + ' ' + n +
              ('  | ' + str(got) if got != '' else ''))
        if not ok:
            fails.append(n)

    sample = (
        'EBOOK GRACE ABOUNDING TO THE CHIEF OF SINNERS***\n'
        'Transcribed from the 1905 The Religious Tract Society edition by '
        'David Price, email ccx074@pglaf.org\n'
        '[Picture: Book cover]\n'
        'GRACE ABOUNDING TO THE CHIEF OF SINNERS\n'
        'In this his pilgrimage, God blessed him with four children.\n'
        '{184} The text from which he intended to preach was Jn. ix. 35.\n'
        '{7} The marginal summaries have not been included in this Project '
        'Gutenberg eText.—DP.\n')
    got = find(sample)
    ck('흔적을 찾는다', len(got) >= 4, [n for n, _ in got])
    out = strip(sample)
    ck('구텐베르크 표식을 걷었다', 'EBOOK' not in out and '***' not in out)
    ck('전사자 주석을 걷었다', 'Transcribed from' not in out
       and 'pglaf' not in out and 'eText' not in out)
    ck('그림 자리를 걷었다', '[Picture' not in out)
    # ★ 저자의 글은 남아야 한다
    ck('본문은 그대로', 'God blessed him with four children' in out)
    ck('제목은 그대로', 'GRACE ABOUNDING TO THE CHIEF OF SINNERS' in out)
    ck('원서 각주는 남긴다', '{184}' in out, out[-90:])
    ck('빈 줄이 겹치지 않는다', '\n\n\n' not in out)
    ck('두 번 걷어도 같다', strip(out) == out)
    ck('흔적 없는 글은 안 건드린다',
       strip('Plain text.\nSecond line.') == 'Plain text.\nSecond line.')
    # ── 장서표 꼬리 (2026-08-29 마이어 #679) ────────────────────────────────
    plate = ('Still throughout the endless ages Serving Him with perfect '
             'love."\n\n'
             'Prmceton Theoloqical Seminary Libraries !\n\n'
             '1 1012 01276 7762 \'\n\n'
             ':illi|ii\n\n'
             'liiliiiiiiii:"\n\n'
             'iliii>iii<atiuii>itiiitli!iliil\n\n'
             '— F.B. Meyer, "Our Daily Homily" (1898). Public domain.')
    po = strip(plate)
    ck('장서표를 걷었다', 'Seminary Libraries' not in po)
    ck('바코드를 걷었다', '01276' not in po)
    ck('★ 장서표 뒤 잡음까지 걷는다',
       'illi' not in po and 'atiuii' not in po, po[-60:])
    ck('★ 출처 한 줄은 지킨다', 'Public domain.' in po)
    ck('★ 저자의 글은 그대로', 'Serving Him with perfect love' in po)
    ck('두 번 걷어도 같다 (꼬리)', strip(po) == po)
    # ⚠ 무모음 규칙을 쓰면 이것들이 지워진다 — 실측 89줄. **쓰지 않는다.**
    for s in ('Pity thy simplicity,', 'C. H. S.', '1 Kings 18:40',
              'Is His, is His by right,', '‘It is finish’d!’'):
        ck('오탐 아님 · %s' % s, find(s) == [], find(s))
    # CCEL 「Library at Calvin College」 는 낱말 차례가 달라 안 걸린다
    #   (그 책의 아파라투스는 별개 사안 — LAW_SCDHL #24)
    ck('CCEL 줄은 이 규칙에 안 걸린다',
       find('Library at Calvin College, http://www.ccel.org,') == [])
    # ── 맨 끝 쪽 번호 조각 (2026-08-29 마이어 #111) ─────────────────────────
    stub = ('This is a high ideal, practicable only to those who realize it.\n\n'
            'lU\n\n'
            '— F.B. Meyer, "Our Daily Homily" (1898). Public domain.')
    so = strip(stub)
    ck('★ 맨 끝 쪽 번호 조각을 뗀다', 'lU' not in so, so[-70:])
    ck('그 편의 본문은 그대로', 'This is a high ideal' in so)
    ck('출처 줄은 그대로 (조각)', 'Public domain.' in so)
    ck('두 번 걷어도 같다 (조각)', strip(so) == so)
    for s in ('X56', 'd08', '1»1', 'j I', '2U0', 'ir'):
        ck('조각으로 본다 · %s' % s, tail_stub('body line here.\n\n' + s) == s)
    # ⚠ **저자의 번호는 남긴다** — 파스칼 924줄 · 이그나티우스 91줄이 이 꼴이다
    for s in ('1', '12', '924', '1.', 'IV', 'III.'):
        ck('저자의 번호는 안 뗀다 · %s' % s,
           tail_stub('body line here.\n\n' + s) is None)
    for s in ('Amen.', 'NOTE', 'Luke', 'Vows', 'Grace'):
        ck('낱말은 안 뗀다 · %s' % s,
           tail_stub('body line here.\n\n' + s) is None)
    # ⚠⚠ **자리가 잣대다** — 가운데 있는 짧은 줄은 저자의 글이다(실측 오탐)
    ck('★ 가운데 조각은 안 건드린다 · So it',
       tail_stub('So it\n\nis a plain closing sentence here.') is None)
    ck('★ 가운데 조각은 안 건드린다 · J. C.',
       tail_stub('J. C.\n\nis how Pascal writes the Name in full.') is None)
    # ── 오탐 검사 — **저자의 글을 지우면 안 된다** ──────────────────────────
    pp = 'Now, at the end of this valley was another, called the Valley.'
    ck('「end of this valley」는 오탐이 아니다', find(pp) == [], find(pp))
    prose = ('We would not have any think that the value of their prayers is '
             'to be measured by the clock, but our purpose is to say that the '
             'best fruit is produced by long and patient waiting on God.')
    ck('산문 속 「produced by」는 오탐이 아니다', find(prose) == [], find(prose))
    ck('그 문장이 살아 남는다', strip(prose) == prose)
    prose2 = 'The shell is good for something, and the egg was produced by it.'
    ck('또 다른 「produced by」도 안전', find(prose2) == [], find(prose2))
    ck('진짜 제작자 줄은 잡는다',
       find('Produced by David Widger and the Online Distributed '
            'Proofreading Team') != [])

    # ── 장 번호 조각 ────────────────────────────────────────────────────
    frag = 'teen No one in all Raymond felt Loreen’s death more keenly.'
    ck('머리 조각을 잡는다', head_fragment(frag) == 'teen', head_fragment(frag))
    ck('머리 조각을 뗀다',
       strip(frag) == 'No one in all Raymond felt Loreen’s death more keenly.',
       strip(frag)[:40])
    ck('-one 도 뗀다', strip('-one HE had planned to return.') ==
       'HE had planned to return.')
    # ⚠ 본문 **중간**의 같은 글자는 건드리지 않는다
    mid = ('He counted them.\n-one, two, three- said the boy.\n'
           'teen was not a word he knew.')
    ck('본문 중간은 안 건드린다', strip(mid) == mid, strip(mid)[:50])
    ck('멀쩡한 첫머리는 그대로',
       strip('THE next day she went down.') == 'THE next day she went down.')
    ck('조각 뗀 것도 멱등', strip(strip(frag)) == strip(frag))

    conn = appdb.connect(DB)
    before = conn.execute("SELECT SUM(LENGTH(body_text)) "
                          "  FROM sys_book_unit_text").fetchone()[0]
    conn.execute('BEGIN')
    apply(conn, ['BUNYAN_GRACE'])
    conn.rollback()
    after = conn.execute("SELECT SUM(LENGTH(body_text)) "
                         "  FROM sys_book_unit_text").fetchone()[0]
    ck('되돌리면 그대로', before == after, '%s → %s' % (before, after))
    conn.close()
    print('\n=== %s (%d fail) ===' %
          ('PASS' if not fails else 'FAIL: ' + ', '.join(fails), len(fails)))
    return 0 if not fails else 1


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        raise SystemExit(_selftest())
    conn = appdb.connect(DB)
    if '--scan' in a:
        t = scan(conn)
        if not t:
            print('전사 흔적 0 — 깨끗하다.')
        for code in sorted(t):
            print('  %-18s %s' % (code, ' · '.join(
                '%s %d' % (k, v) for k, v in sorted(t[code].items()))))
        conn.close()
        return
    if '--show' in a:
        code = a[a.index('--show') + 1]
        for c2, seq, lab, tid, body in _rows(conn, code):
            for name, s in find(body):
                print('  [%d] %-12s %s' % (seq, name, s[:110]))
        conn.close()
        return
    if '--restore' in a:
        # ⚠⚠ **백업을 두고 되돌릴 길이 없었다** (2026-08-30에 실제로 필요해졌다).
        #   번연 『넘치는 은혜』에서 흔적을 걷었더니 **빈 줄 묶음이 눌려**
        #   문단 경계 374개가 사라졌고(묶음 3: 611 → 237), 되돌릴 방법이 없어
        #   손으로 SQL 을 쓸 뻔했다. 백업을 두는 도구는 **쓰는 길까지** 있어야 한다.
        codes = [x for x in a[a.index('--restore') + 1:] if not x.startswith('-')]
        try:
            rows = conn.execute(
                "SELECT text_id, body_text, book_code FROM %s" % BACKUP
                + ((" WHERE book_code IN (%s)" % ','.join('?' * len(codes)))
                   if codes else ''), codes).fetchall()
        except Exception as e:
            raise SystemExit('백업이 없다: %s' % e)
        for tid, body, _c in rows:
            conn.execute("UPDATE sys_book_unit_text SET body_text=? WHERE text_id=?",
                         (body, tid))
        conn.execute("DELETE FROM %s" % BACKUP
                     + ((" WHERE book_code IN (%s)" % ','.join('?' * len(codes)))
                        if codes else ''), codes)
        conn.commit()
        print('되돌림 %d편 (%s)' % (len(rows), ', '.join(codes) or '전부'))
        conn.close()
        return
    if '--apply' in a:
        codes = [x for x in a[a.index('--apply') + 1:] if not x.startswith('-')]
        if not codes:
            raise SystemExit('어느 책인지 코드를 적으십시오.')
        conn.execute('BEGIN')
        n_unit, n_hit = apply(conn, codes)
        conn.commit()
        print('%d편에서 흔적 %d개를 걷었다 (백업 %s)' % (n_unit, n_hit, BACKUP))
        conn.close()
        return
    conn.close()
    print(__doc__)


if __name__ == '__main__':
    main()
