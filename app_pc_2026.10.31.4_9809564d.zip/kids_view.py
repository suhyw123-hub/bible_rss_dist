"""
kids_view.py — P4 탭8 '어린이' 화면 (KidsView)
----------------------------------------------
어린이용(audience='KIDS') 성경영상을 인물 중심으로 탐색하는 독립 브라우즈 화면.
콤보박스 없이 좌측 큰 인물 목록 + 우측 인라인 재생 + 영상 목록.

- 좌측: 어린이 영상이 연결된 인물 목록(이름 + 영상 수, 큰 글씨). 클릭하면 우측 갱신.
- 우측 상단: 인라인 플레이어(YouTube 임베드, media_player.EmbeddedPlayer 재사용).
- 우측 하단: 그 인물의 어린이 영상 목록(media_list_view 표준 5컬럼). 클릭 → 위에서 재생.

어린이는 배타적 게이트가 아니라 분류 태그 — 같은 영상은 일반 Links 에도 그대로 노출된다.
한 영상에 여러 인물이 연결되면 각 인물 아래에 모두 나타난다(이미 본 영상 반복 시청 자연 지원).
"""
import re
import i18n
import sqlite3
# ★★ 구간 판정은 **한 문**이다(§verse_range) — `verse_id` 는 신원이고
#   차례는 `sort_order` 다. 번호로 재면 절체계 이형 구간에서 샌다.
import verse_range as _vr
import appdb
import webbrowser
import tkinter as tk
from tkinter import ttk

import media_list_view as mlv
import media_link               # 영상 연결 단일 소스(통합 표 이름·link_type)
import media_pref
import media_taxonomy as _tax
import ui_theme

try:
    import media_player
    _MP_EMBED_OK = media_player.embed_available()
except Exception:
    media_player = None
    _MP_EMBED_OK = False


def _c(role, dflt):
    """테마 색. 어린이 화면도 **앱 표준을 그대로 따른다** (2026-08-15 사용자 지시).

    ⚠ 예전에는 크림색(`#FFF6E5`)·주황(`#E8C97A`)을 박아 두어 테마를 바꿔도
      이 탭만 그대로였다. 「어린이용이니 달라야 한다」는 생각이었는데,
      사용자 판단은 반대다 — **아이가 작은 글씨를 어른보다 더 잘 본다.**
    """
    try:
        import ui_theme
        return ui_theme.C(role)
    except Exception:
        return dflt


def _ui_lang_codes():
    """UI 언어 코드 목록.

    ⚠ `lang_config.ui_langs()` 는 **문자열 목록**이다 — `for c, *_ in` 로 풀면
      `'EN'` 이 `'E'` 가 된다(CLAUDE.md §3 · 2026-09-10 실제로 당했다).
    """
    try:
        import lang_config
        return [str(x) for x in lang_config.ui_langs()]
    except Exception:
        return ['KO', 'EN']


def _reg(w, db, scope='ui', size_delta=0):
    """글꼴을 통합 폰트에 맡긴다 — 글꼴 이름을 화면이 적지 않는다(§36).

    ⚠ 2026-08-20 사용자 지적 「어린이영상 서브탭의 왼쪽 트리목록이 표준서식을
      따르지 않는다」 — 색은 `_c()` 로 진작 옮겼는데 **글꼴 이름 13곳이
      그대로 박혀 있어** 통합 폰트를 바꿔도 이 탭만 안 따라왔다."""
    try:
        import theme_font
        theme_font.register(w, db, scope, size_delta=size_delta)
    except Exception:
        pass
    return w


def scope_keys(conn, vid):
    """그 절에 영상이 걸릴 수 있는 `(link_type, target_id)` 짝들 — 절 + 그 절이 든 단락.

    ★ 2026-10-07 (51-4) — 온라인영상 목록의 구절 거르개와 P4 탭 머리 배지가 **같은 문**을 쓴다
      (두 벌이면 배지 수와 목록 수가 갈린다)."""
    try:
        bi = conn.execute('SELECT 1 FROM bible_index WHERE verse_id=?', (vid,)).fetchone()
        if not bi:
            return []
        pairs = [('VERSE', vid)]
        for (pid,) in conn.execute(
                'SELECT pericope_id FROM sys_pericope_asset p WHERE '
                + _vr.covers_sql('p', 'start_vid', 'end_vid')
                + " AND COALESCE(p.record_status,'LIVE')='LIVE'",
                _vr.covers_args(vid)):
            pairs.append(('PERICOPE', pid))
        out = []
        for sc, k in pairs:
            ty, tgt = media_link.lt(sc), media_link.key_int(k)
            if ty and tgt is not None:
                out.append((ty, tgt))
        return out
    except Exception:
        return []


def verse_media_ids(conn, vid, lang=None):
    """그 절(·단락)에 연결된 **살아 있는** 영상 번호 집합. `lang` 이면 그 언어만."""
    keys = scope_keys(conn, vid)
    if not keys:
        return set()
    sql = ("SELECT DISTINCT l.clicked_id FROM " + media_link.TBL + " l"
           " JOIN sys_media_asset a ON a.media_id=l.clicked_id"
           "  AND a.is_active=1 AND a.record_status='LIVE'"
           " WHERE COALESCE(l.record_status,'LIVE')='LIVE' AND (" +
           ' OR '.join('(l.link_type=? AND l.target_id=?)' for _ in keys) + ")")
    args = []
    for ty, tgt in keys:
        args += [ty, tgt]
    if lang:
        sql += " AND UPPER(COALESCE(a.lang_code,''))=?"
        args.append(str(lang).upper())
    return set(r[0] for r in conn.execute(sql, args))


#: 온라인 영상 언어 콤보의 기억 열쇠(2026-10-09 1.txt 59-1 — 배지가 같은 값을 읽는다)
LANG_KEY = 'LANGSEL_KIDS'


def chosen_lang(default='KO', db_path=None):
    """온라인 영상 목록이 지금 선택한 언어 — 「모든 언어」면 None."""
    import lang_combo as _LC
    return _LC.chosen_lang(LANG_KEY, default, db_path)


def verse_media_count(db_path, vid, lang=None):
    """그 구절의 영상 수 — **목록과 같은 잣대**(언어 · 내가 숨긴 것 빼기 · 갈래 무관). 2026-10-13 80-2."""
    conn = appdb.connect(db_path)
    try:
        ids = verse_media_ids(conn, vid, lang)
        if not ids:
            return 0
        try:
            pref = media_pref.load(db_path)
            rows = conn.execute("SELECT media_id, description FROM sys_media_asset WHERE media_id IN (%s)"
                                % ','.join('?' * len(ids)), sorted(ids)).fetchall()
            return sum(1 for m, d in rows if not pref.hidden(m, d))
        except Exception:
            return len(ids)
    finally:
        conn.close()


def _yt_id(url):
    if not url or ('youtube.com' not in url and 'youtu.be' not in url):
        return None
    m = re.search(r'(?:v=|youtu\.be/|embed/|/v/|shorts/)([\w-]{11})', url)
    return m.group(1) if m else None


class KidsView(ttk.Frame):
    def __init__(self, parent, db_path, lang_getter=None,
                 state_get=None, state_set=None):
        super().__init__(parent)
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self._state_get = state_get   # _load_state(key, default)
        self._state_set = state_set   # _save_state(key, val)
        self._embed_player = None
        self._embed_host = None
        self._items = {}          # video tree iid -> (media_id, url, yt)
        self._cur_eid = None
        self._build()
        self.bind('<Destroy>', self._on_destroy, add='+')
        self.after_idle(self.refresh_persons)
        self.after(500, self._restore_sash)

    # ── UI ──────────────────────────────────────────────────────────────────
    #: ★★★ **상단 라디오 = 화면 갈래**(2026-09-17 · 1.txt 5-4(3) 사용자 배치
    #:   「설교강해, 성경공부, 성경듣기, (공백) 찬양듣기, (공백) 영화애니,
    #:   어린이, 수화, (공백), 즐겨찾기」). `None` 은 구분선이다.
    #:   ⚠ 단순 거르개가 아니다 — 갈래마다 **왼쪽 트리가 달라진다**.
    # ★★★ **갈래 목록은 `media_taxonomy.USER_KINDS` 한 표에서 온다**
    #   (2026-09-17 사용자 「모든 것을 P4 상단 라디오 버튼으로 통일하라」).
    #   여기와 P2 영상 갈래가 **같은 이름·같은 조건**을 쓴다.
    #   ★ 설교·강해·성경공부는 **「말씀」 하나**로 합쳤다 — 까닭은 그 표에 적었다.
    #   ⚠ 즐겨찾기만 여기 것이다 — 유형이 아니라 **내가 담은 것**이라 P2 에는 없다.
    VIEWS = tuple(
        x for c, ik, ko, _t, _a in _tax.USER_KINDS
        for x in ((c, ik, ko),) + ((None,) if c in _tax.KIND_SEP_AFTER else ())
    ) + (('FAV', 'KV_V_FAV', '즐겨듣기'),)
    #: 갈래 → 조회 조건. (media_type 튜플, audience)
    VIEW_COND = dict(
        [(c, _tax.kind_cond(c)) for c, _i, _k, _t, _a in _tax.USER_KINDS]
        + [('FAV', ((), None))])
    #: 책 트리를 쓰는 갈래 — 나머지는 축·용어·재생목록 트리
    BOOK_VIEWS = ('WORD', 'READ')

    def _build(self):
        """좌우 두 칸 — **왼쪽 = 검색창·목록 · 오른쪽 = 단추 줄·재생 화면**
        (2026-09-17 · 1.txt 5-1 사용자 「좌우로 분할, 좌측에 검색창/목록 배치,
        우측에 상단 버튼들과 플래이화면 배치」).

        ★★★ **상단 단추는 거르개가 아니라 화면을 고른다**(5-4(3) 사용자 —
          「성경듣기/찬양듣기 버튼과 같이 **별도의 트리뷰 목록을 왼쪽 화면에
          표시**하고 클릭하면 영상 플래이」). 누르면 왼쪽 트리가 바뀌고,
          거기서 고르면 아래 목록이 차고, 목록을 누르면 오른쪽에서 재생한다.
        ⚠ 「목록」 단추는 걷었다(5-3) — 갈래가 언제나 하나 켜져 있으므로
          돌아올 자리가 따로 없다.
        ⚠ Focus 라벨도 걷었다(5-2) — 구절 약명은 **P2 에서 들어왔을 때만**
          오른쪽 단추 줄 맨 왼쪽에 나온다(5-4(1)·(2)).
        ⚠ 플레이어는 **한 벌만** 산다(§30) — 갈래를 바꿔도 안 죽인다.
        """
        import ui_theme
        self._mode = 'VERSE'          # 옛 이름(밖에서 부르는 자리가 있다)
        self._mode_btns = {}
        self._aud = 'ALL'
        self._kind = 'ALL'
        self._aud_btns = {}
        self._kind_btns = {}
        self._items = {}
        self._picked = set()
        self._tree_pay = {}           # 트리 iid → 눌렀을 때 쓸 재료
        self._list_id = None          # 고른 재생목록
        # ★★★ **보던 구절 자리는 갈래를 바꿔도 남는다**(2026-09-17 사용자
        #   「성경공부 선택하고 호세아 1장 클릭하였다면, **찬양을 선택하더라도
        #   호세아 1장이 유지**되고 적절하게 필터링 하도록 하라. **다시 책을
        #   처음부터 선택하도록 하지 마라**」).
        #   ⚠ 거르는 자리는 **`_fill_videos` 한 곳**이다 — 갈래마다 조회가 달라
        #     (책·사역자·즐겨찾기·재생목록) 조회문마다 넣으면 반드시 하나가 샌다.
        self._book_pick = None        # (bcode, 장|None)
        self._pick_ids = None         # 그 자리에 걸린 영상 번호(한 번만 센다)
        # ★★★ **검색 중에는 왼쪽 트리가 「검색 결과의 묶음」이다**(2026-09-17
        #   사용자 「검색어 입력하고 엔터하면 목록이 표시되어야 하는데 **좌측
        #   상단에 항상 카테고리가 표시**되고 있다」).
        #   ⚠ 검색은 **갈래 전체**를 뒤지므로(트리 선택을 일부러 무시한다) 그
        #     자리에 카테고리가 남아 있으면 화면이 거짓말을 한다 — 지금 보고 있는
        #     것은 「모세오경」이 아니라 「다윗을 찾은 결과」다.
        self._searching = False
        self._search_rows = None      # 지금 검색 결과(줄 그대로)
        self._search_books = {}       # 책 번호 → 그 책에 걸린 영상 번호
        self._from_p2 = False         # P2 에서 들어왔나(왼쪽을 접는다)
        self._ref_text = ''
        self._view = 'WORD'
        if self._state_get:
            try:
                v = self._state_get('kids_view_kind', 'WORD')
                # ⚠ 옛 저장값 `SERMON`·`STUDY` 는 이제 **「말씀」 하나**다
                #   (2026-09-17 통합) — 읽을 때 옮긴다. 안 옮기면 그 사람만
                #   갈래가 없어 첫 화면이 빈다.
                v = {'SERMON': 'WORD', 'STUDY': 'WORD'}.get(v, v)
                if v in self.VIEW_COND:
                    self._view = v
            except Exception:
                pass

        pw = tk.PanedWindow(self, orient='horizontal', sashwidth=6,
                            bg=_c('border', '#94AEBC'), sashrelief='raised',
                            opaqueresize=False)
        pw.pack(fill='both', expand=True)
        self._pw = pw

        # ── 왼쪽 = 검색창 + 트리 + 목록 ─────────────────────────────────
        left = tk.Frame(pw, bg=_c('panel', 'white'))
        self._left_pane = left
        pw.add(left, minsize=300, width=520, stretch='never')

        srow = tk.Frame(left, bg=_c('panel_alt', '#DCE3E7'))
        self._srow = srow
        srow.pack(fill='x')
        self._q_var = tk.StringVar()
        # ★ 2026-10-07 (docs/1.txt 51-4(6)) — [입력창][검색][X] 는 주요용어·연구노트와
        #   **같은 부품**이다(`search_row`). X = 검색어 + 구절 거르개를 함께 푼다.
        import search_row
        search_row.build(srow, self._q_var, self._refresh_current, self._reset_search,
                         db_path=self.db_path, width=12, expand=False)
        self._cnt_lbl = tk.Label(srow, text='', bg=_c('panel_alt', '#DCE3E7'),
                                 fg=_c('fg_dim', '#667A85'))
        _reg(self._cnt_lbl, self.db_path)
        self._cnt_lbl.pack(side='left', padx=(6, 0))
        # ★ 걸려 있다는 것을 글로 말한다 — 안 그러면 0개가 고장으로 읽힌다(§0-1).
        self._pick_btn = tk.Button(srow, text='', bd=1, relief='raised',
                                   cursor='hand2', padx=3,
                                   command=self._clear_pick)
        _reg(self._pick_btn, self.db_path, size_delta=-1)
        # ★ 구절 거르개 칩(2026-10-07 · 51-3·4(6)) — P1·P4 에서 구절을 누르면 그 구절에
        #   연결된 영상만 보인다. 칩이 그 사실을 말하고 누르면 풀린다(전체).
        self._vpick = None            # 걸린 구절 번호(사람이 누른 것)
        self._vpick_off = False       # 칩/X 로 풀었나(다음 구절 클릭까지)
        self._vpick_ids = None
        self._vpick_btn = tk.Button(srow, text='', bd=1, relief='raised',
                                    cursor='hand2', padx=3,
                                    command=self.clear_verse_filter)
        _reg(self._vpick_btn, self.db_path, size_delta=-1)
        # ★ 수화 갈래 — 어느 수화인가. 승인된 영상에 있는 코드만(§0-1).
        self._sign_var = tk.StringVar(value='')
        self._sign_cb = ttk.Combobox(srow, textvariable=self._sign_var,
                                     state='readonly', width=14)
        self._sign_cb.bind('<<ComboboxSelected>>',
                           lambda e: self._refresh_current())
        self._sign_codes = {}
        _reg(tk.Button(srow, text=i18n.t('COMMON_REFRESH', '새로고침'),
                       bd=1, relief='raised', cursor='hand2',
                       command=self._refresh_current),
             self.db_path).pack(side='right', padx=4, pady=2)
        # ★ **재생목록 관리 줄** — 즐겨찾기 갈래에서만 편다(1.txt 5-4(3)
        #   「이어듣기 버튼은 … 재생목록 화면 내부에 배치하라」와 같은 자리).
        frow = tk.Frame(left, bg=_c('panel_alt', '#DCE3E7'))
        self._fav_row = frow
        # ★★ **이어듣기는 재생목록 화면 **안**에 있다**(2026-09-17 사용자 5-4(3)
        #   「이어듣기 버튼은 사용자가 만든 재생목록 화면을 열었을 때 재생목록
        #   화면 내부에 배치하라」) — 위 단추 줄에서 걷었다.
        #   ⚠ 검색 줄에 두었더니 개수 라벨에 밀려 **1px 로 눌렸다**(실측) —
        #     좁은 줄에 단추를 더하지 않는다.
        self._play_btn = tk.Button(frow, text=i18n.t('KV_PLAYALL', '▶ 이어서 듣기'),
                                   bd=1, relief='raised', cursor='hand2',
                                   command=self._play_selected)
        _reg(self._play_btn, self.db_path, size_delta=-1)
        for _t, _k, _cmd in (
                ('＋ 새 목록', 'KV_L_NEW', self._new_list),
                ('이름 바꾸기', 'KV_L_RENAME', self._rename_list),
                ('▲', 'KV_L_UP', lambda: self._move_item(-1)),
                ('▼', 'KV_L_DOWN', lambda: self._move_item(1)),
                # ⚠⚠ 「빼기」는 **내가 지어낸 말**이다(2026-09-17 사용자 「수십번
                #   말했다」 · §237차 ⑱ 그 자리). 사람이 쓰는 말은 「제거」다.
                ('제거', 'KV_L_DROP', self._drop_item)):
            _reg(tk.Button(frow, text=i18n.t(_k, _t), bd=1, relief='raised',
                           cursor='hand2', padx=3, command=_cmd),
                 self.db_path, size_delta=-1).pack(side='left', padx=2, pady=2)

        # ★★★ **찬양은 축 단추 셋**(2026-09-17 사용자 「찬양듣기를 누르면 반응이
        #   매우 느리다. **트리구조가 싫다. 버튼 3개 배치하라. 이전의 방식이 더
        #   좋다**」) — 사역자 / 분위기 / 주제. 찬양 갈래에서만 편다.
        #   ⚠ 느리던 까닭도 트리였다 — 셋을 한꺼번에 채우느라 **셋을 다 셌다**.
        #     이제 **고른 축 하나만** 센다.
        self._axis = 'ARTIST'
        self._axis_btns = {}
        arow = tk.Frame(left, bg=_c('panel_alt', '#DCE3E7'))
        self._axis_row = arow
        for _code, _ik, _ko in (('ARTIST', 'PV_PICKART', '사역자'),
                                ('MOOD', 'PV_PICKMOOD', '분위기'),
                                ('TOPIC', 'PV_PICKTOPIC', '주제')):
            _b = tk.Button(arow, text=i18n.t(_ik, _ko), bd=1, relief='raised',
                           cursor='hand2', padx=6,
                           command=lambda c=_code: self.set_axis(c))
            _reg(_b, self.db_path, size_delta=-1)
            _b.pack(side='left', padx=2, pady=2)
            self._axis_btns[_code] = _b

        # ★★ **왼쪽을 좌우 둘로**(2026-09-17 사용자 「왼쪽 화면을 상하로 구분했다.
        #   너무 좁다. 이전에 했던 것을 왜 바꾸었는가? **왼쪽 패널을 좌우 2개로
        #   배치하라**」) — 위아래로 나누니 트리도 목록도 **절반 높이**가 되어
        #   둘 다 짧았다. 좌우로 두면 **높이를 통째로** 쓴다.
        lpw = tk.PanedWindow(left, orient='horizontal', sashwidth=5,
                             bg=_c('border', '#94AEBC'), sashrelief='raised',
                             opaqueresize=False)
        lpw.pack(fill='both', expand=True)
        self._lpw = lpw

        tf = tk.Frame(lpw, bg=_c('panel', 'white'))
        self._tree_pane = tf
        lpw.add(tf, minsize=120, width=210, stretch='never')
        try:
            import theme_font
            theme_font.list_style('Kids.Treeview', self.db_path)
        except Exception:
            pass
        self._lv = ttk.Treeview(tf, columns=('n',), show='tree headings',
                                selectmode='browse', style='Kids.Treeview')
        self._lv.heading('#0', text=i18n.t('KV_TREE_COL', '목록'))
        self._lv.heading('n', text=i18n.t('KV_COUNT', '수'))
        self._lv.column('#0', width=210, stretch=True)
        self._lv.column('n', width=54, anchor='e', stretch=False)
        lsb = ttk.Scrollbar(tf, command=self._lv.yview)
        self._lv.configure(yscrollcommand=lsb.set)
        lsb.pack(side='right', fill='y')
        self._lv.pack(side='left', fill='both', expand=True)
        self._lv.bind('<<TreeviewSelect>>', self._on_tree_pick)
        self._lv.bind('<<TreeviewOpen>>', self._on_tree_open)
        self._person_tv = self._lv     # 옛 이름(인물 트리를 부르던 자리)

        vf = tk.Frame(lpw, bg=_c('panel', 'white'))
        self._list_pane = vf
        self._mid_pane = vf            # 옛 이름
        lpw.add(vf, minsize=160, stretch='always')
        self._vf = vf
        self._video_tv = mlv.build_tree(vf, style_name='KidsVid.Treeview',
                                        height=10)
        self._video_tv.column('scope', width=0, minwidth=0, stretch=False)
        try:
            mlv.set_pick_col(self._video_tv, True)
        except Exception:
            self._video_tv.column('pick', width=26, minwidth=26, stretch=False)
        vsb = ttk.Scrollbar(vf, command=self._video_tv.yview)
        self._video_tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        self._video_tv.pack(side='left', fill='both', expand=True)
        self._video_tv.bind('<ButtonRelease-1>', self._on_video_click)
        self._video_tv.bind('<<TreeviewSelect>>',
                            lambda _e: self._sel_video_target(), add='+')

        # ── 오른쪽 = 단추 줄 + 재생 화면 ───────────────────────────────
        right = tk.Frame(pw, bg='black')
        pw.add(right, minsize=320, stretch='always')
        self._right_pane = right
        bar = tk.Frame(right, bg=_c('panel', '#ECEFF1'))
        ui_theme.bar_height(bar)
        bar.pack(side='top', fill='x')
        self._bar = bar
        self._fb_bar = bar

        # ★ 맨 왼쪽 — **구절 약명**(P2 에서 들어왔을 때만) · **검색창 토글**
        self._ref_lbl = _reg(tk.Label(
            bar, text='', bg=_c('panel', '#ECEFF1'),
            fg=_c('fg_label', '#44565F')), self.db_path, size_delta=-1)
        self._search_btn = tk.Button(
            bar, text=i18n.t('KV_SEARCH_HIDE', '목록 닫기'), bd=1,
            relief='raised', cursor='hand2', padx=3, command=self._toggle_left)
        _reg(self._search_btn, self.db_path, size_delta=-1)
        self._search_btn.pack(side='left', padx=(4, 2), pady=2)

        # ★★★ **화면 갈래 = 라디오**(2026-09-17 · 1.txt 5-5 사용자 「음각/양각
        #   버튼이 너무 많아서 혼란스럽다 … 라디오버튼으로 … 글자 크기를
        #   한단계 작게」). 크기는 `size_delta=-1` — **절대 크기를 안 적는다**.
        self._view_var = tk.StringVar(value=self._view)
        self._view_btns = {}
        for it in self.VIEWS:
            if it is None:
                ttk.Separator(bar, orient='vertical').pack(
                    side='left', fill='y', padx=(6, 3), pady=4)
                continue
            code, ik, ko = it
            rb = tk.Radiobutton(
                bar, text=i18n.t(ik, ko), value=code, variable=self._view_var,
                bg=_c('panel', '#ECEFF1'), fg=_c('fg_label', '#44565F'),
                activebackground=_c('panel', '#ECEFF1'),
                selectcolor=_c('panel', '#ECEFF1'),
                cursor='hand2', padx=1, bd=0, highlightthickness=0,
                command=lambda c=code: self.set_view(c))
            _reg(rb, self.db_path, size_delta=-1)
            rb.pack(side='left', padx=0, pady=2)
            self._view_btns[code] = rb

        # ── 오른쪽 끝 — My Edit · 언어콤보 · 숨기기 · ☆ 담기 ──────────
        #   ⚠ `side='right'` 는 **먼저 담은 것이 가장 오른쪽**이다.
        # ★★ **넷을 한 칸에 담는다**(2026-09-17) — 왼쪽을 좌우 둘로 넓히자 이 줄이
        #   넘쳤다(실측 RU 필요 1,166 / 자리 932). 좁으면 **칸째 [···] 로 접는다**
        #   (§237차 ⑰ⓑ 가 P4 온라인 영상에서 쓴 방식 — 잃는 것이 없다).
        self._dots_btn = tk.Button(bar, text='···', bd=1, relief='raised',
                                   cursor='hand2', padx=4,
                                   command=self._open_tools_menu)
        _reg(self._dots_btn, self.db_path, size_delta=-1)
        tools = tk.Frame(bar, bg=_c('panel', '#ECEFF1'))
        self._tools_f = tools
        tools.pack(side='right')
        _me = tk.Button(tools, text=i18n.t('OE_BTN', 'My Edit'), bd=1,
                        relief='raised', cursor='hand2', padx=3,
                        command=self._add_my_link)
        _reg(_me, self.db_path, size_delta=-1)
        _me.pack(side='right', padx=(2, 4), pady=2)
        # ★ 처음 한 번은 환경설정 언어, 그 뒤로는 고른 것을 기억한다(2026-10-09
        #   1.txt 59-1 — 배지가 이 값을 읽는다. 그전에는 늘 「모든 언어」로 떠서
        #   배지와 목록이 11개 언어 합계였다).
        _cl = chosen_lang((self.lang_getter() or 'KO'), self.db_path)
        self._lang_var = tk.StringVar(value=(_cl if _cl else i18n.t('PV_L_ALL', '모든 언어')))
        # ★ 2026-10-13 80-1 — 언어 콤보는 **왼쪽 목록 위**(검색 줄 오른쪽)에 둔다(무엇을 거르는지 목록 곁에서 보인다)
        self._lang_cb = ttk.Combobox(
            self._srow, width=8, state='readonly', textvariable=self._lang_var,
            values=[i18n.t('PV_L_ALL', '모든 언어')] + _ui_lang_codes())
        self._lang_cb.pack(side='right', padx=(2, 0), pady=2)
        self._lang_cb.bind('<<ComboboxSelected>>', lambda e: self._on_lang())
        self._more_btn = tk.Button(tools, text=i18n.t('KV_HIDEMENU', '숨기기'),
                                   bd=1, relief='raised', cursor='hand2',
                                   padx=3, command=self._open_more)
        _reg(self._more_btn, self.db_path, size_delta=-1)
        self._more_btn.pack(side='right', padx=2, pady=2)
        self._hidden_btn = self._more_btn
        self._fb_btns = {}
        # ★ [담기] = **살리는 쪽 메뉴**(즐겨찾기 · 채널 · 재생목록에 담기).
        #   [숨기기] 와 짝이다 — 한 메뉴에 섞으면 실수하기 쉽다.
        b = tk.Button(tools, text=i18n.t('KV_FB_MFAV', '즐겨듣기'), bd=1,
                      relief='raised', cursor='hand2',
                      padx=3, command=self._open_add_menu)
        _reg(b, self.db_path, size_delta=-1)
        b.pack(side='right', padx=2, pady=2)
        self._fb_btns['MFAV'] = b
        self._fit_job = None
        bar.bind('<Configure>', lambda _e: self._fit_bar_later())
        self._pref = media_pref.load(self.db_path)
        self._cur_media = None
        self._sync_hidden_btn()

        # ⚠ 안내 라벨 줄은 걷었다 — 위젯만 만들어 둔다(옛 코드가 글을 쓴다).
        self._hdr_lbl = tk.Label(self)
        self._mid_lbl = tk.Label(self)
        self._fb_lbl = tk.Label(self)

        host = tk.Frame(right, bg='black')
        host.pack(fill='both', expand=True)
        if _MP_EMBED_OK:
            self._embed_host = host
            self._embed_hint = tk.Label(
                host, text=i18n.t('KV_PLAYHINT2',
                                  '◀ 왼쪽 제목을 누르면 여기서 재생돼요'),
                bg='black', fg='#AAA')
            _reg(self._embed_hint, self.db_path)
            self._embed_hint.pack(expand=True)
        else:
            self._embed_host = None
            _reg(tk.Label(host, text=i18n.t(
                'KV_NOINLINE', '인라인 재생을 사용할 수 없는 환경입니다.'),
                bg='black', fg='#AAA'), self.db_path).pack(expand=True)

        pw.bind('<ButtonRelease-1>', lambda e: self._save_sash(), add='+')
        self.set_view(self._view)

    # ── 갈래 ──────────────────────────────────────

    # ★ 옛 이름들 — 밖에서 부르는 자리가 남아 있어 그대로 둔다.
    def _set_opt(self, store, code):
        self.set_view(code if code in self.VIEW_COND else self._view)

    def _toggle_aud(self, code):
        self.set_view(code if code in self.VIEW_COND else self._view)

    def set_mode(self, mode):
        """옛 이름 (KIDS | VERSE | SIGN) — 갈래로 옮긴다."""
        self.set_view({'KIDS': 'KIDS', 'SIGN': 'SIGN'}.get(mode, self._view))

    def attach_pick(self, widget):
        """옛 배선 — 성경듣기·찬양·즐겨찾기를 **이 화면이 직접** 하므로
        더는 쓰지 않는다. 부르는 자리가 남아 있어 받아만 둔다."""
        self._pick = widget

    def alt_frame(self):
        if getattr(self, '_alt', None) is None:
            self._alt = tk.Frame(self)
        return self._alt

    def _on_lang(self):
        try:
            import lang_combo as _LC
            _LC.set_sel(LANG_KEY, '', self.sel_lang() or _LC.ALL, self.db_path)
        except Exception:
            pass
        self._reload_tree()
        self._refresh_current()
        try:
            import lang_combo as _LC
            _LC.notify(LANG_KEY)
        except Exception:
            pass

    def sel_lang(self):
        """선택한 언어 코드 — 「모든 언어」면 None."""
        v = self._lang_var.get()
        return None if v == i18n.t('PV_L_ALL', '모든 언어') else v

    def set_focus_label(self, text):
        """호스트가 지금 구절을 알려 준다 — **P2 에서 들어왔을 때만 보인다**."""
        self._ref_text = text or ''
        self._sync_ref_lbl()

    def _sync_ref_lbl(self):
        """구절 약명은 **왼쪽 칸이 접혀 있을 때만** 보인다(5-4(1)·(2)).

        ⚠ 사용자 지시 — 「검색창 이용하는 경우 구절약명 라벨을 표시하면 안됨」.
        """
        show = self._from_p2 and not self._left_shown()
        try:
            if show and getattr(self, '_ref_text', ''):
                self._ref_lbl.config(text=self._ref_text)
                if not self._ref_lbl.winfo_manager():
                    self._ref_lbl.pack(side='left', padx=(6, 2),
                                       before=self._search_btn)
            else:
                self._ref_lbl.pack_forget()
        except Exception:
            pass

    def _fit_bar_later(self):
        """기하가 가라앉은 뒤에 잰다 — Configure 순간에 재면 옛 폭이 나온다."""
        job = getattr(self, '_fit_job', None)
        if job:
            try:
                self.after_cancel(job)
            except Exception:
                pass
        try:
            self._fit_job = self.after(40, self._fit_bar)
        except Exception:
            self._fit_job = None

    def _fit_bar(self):
        """오른쪽 도구 넷이 자리를 넘으면 **[···] 하나**로 접는다.

        ⚠⚠ **바뀔 때만 손댄다** — 무조건 다시 담으면 `<Configure>` 가 또 나서
          끝없는 idle 고리가 된다(§256차 ⑰ 에서 앱이 통째로 멎던 그 자리).
        """
        self._fit_job = None
        try:
            bar = self._bar
            avail = bar.winfo_width()
            if avail <= 1:
                return
            need = 8
            for w in bar.winfo_children():
                if w is self._tools_f or w is self._dots_btn:
                    continue
                if w.winfo_manager():
                    need += w.winfo_reqwidth() + 4
            fits = (need + self._tools_f.winfo_reqwidth() + 4) <= avail
            shown = bool(self._tools_f.winfo_manager())
            if fits and not shown:
                self._dots_btn.pack_forget()
                self._tools_f.pack(side='right')
            elif not fits and shown:
                self._tools_f.pack_forget()
                self._dots_btn.pack(side='right', padx=(2, 4), pady=2)
        except Exception:
            pass

    def _open_tools_menu(self):
        """접힌 도구 넷 — 메뉴 안에 **그대로** 있다(잃는 것이 없다)."""
        m = tk.Menu(self, tearoff=0)
        m.add_command(label=i18n.t('KV_FB_MFAV', '즐겨듣기'),
                      command=self._open_add_menu)
        m.add_command(label=i18n.t('KV_HIDEMENU', '숨기기'),
                      command=self._open_more)
        sub = tk.Menu(m, tearoff=0)
        for v in [i18n.t('PV_L_ALL', '모든 언어')] + _ui_lang_codes():
            sub.add_command(label=v,
                            command=lambda x=v: (self._lang_var.set(x),
                                                 self._on_lang()))
        # ⚠ 이름표를 새로 짓지 않는다 — **지금 고른 값**이 그 자리를 말한다.
        m.add_cascade(label=self._lang_var.get(), menu=sub)
        m.add_command(label=i18n.t('OE_BTN', 'My Edit'),
                      command=self._add_my_link)
        try:
            m.tk_popup(self._dots_btn.winfo_rootx(),
                       self._dots_btn.winfo_rooty()
                       + self._dots_btn.winfo_height())
        finally:
            m.grab_release()

    def _left_shown(self):
        try:
            return str(self._left_pane) in [str(p) for p in self._pw.panes()]
        except Exception:
            return True

    def _show_left(self, on):
        try:
            if on and not self._left_shown():
                self._pw.add(self._left_pane, minsize=300, width=520,
                             stretch='never', before=self._right_pane)
            elif not on and self._left_shown():
                self._pw.forget(self._left_pane)
        except Exception:
            pass
        try:
            self._search_btn.config(
                text=i18n.t('KV_SEARCH_HIDE', '목록 닫기') if on
                else i18n.t('KV_SEARCH_SHOW', '목록 보기'))
        except Exception:
            pass
        self._sync_ref_lbl()

    def _toggle_left(self):
        on = not self._left_shown()
        self._show_left(on)
        if on:
            self._from_p2 = False     # 검색창을 폈으면 약명은 안 쓴다
            self._sync_ref_lbl()

    def set_view(self, code):
        """화면 갈래 — 왼쪽 트리가 바뀐다.

        ⚠ 옛 값 `'LIST'` 는 「목록으로 돌아오라」는 뜻이었다 — 곡 화면을 걷고
          지금 갈래를 그대로 둔다(부르는 자리가 여럿이다).
        """
        if code == 'LIST':
            self.hide_song()
            self._show_left(True)
            return
        if code not in self.VIEW_COND:
            return
        # ★ 80-2 — 갈래를 누르면 구절 거르개를 푼다(그 구절의 영상 목록 → 그 갈래 목록)
        if self._verse_on():
            self._vpick_off = True
            self._sync_vpick_btn()
            if callable(self.on_count):
                self.after_idle(self.on_count)
        self.hide_song()
        self._view = code
        try:
            self._view_var.set(code)
        except Exception:
            pass
        self._show_left(True)
        if self._state_set:
            try:
                self._state_set('kids_view_kind', code)
            except Exception:
                pass
        # 갈래마다 다른 거르개 — 수화 코드 콤보 · 재생목록 이어듣기
        try:
            if code == 'SIGN':
                self._fill_sign_combo()
                self._sign_cb.pack(side='left', padx=(8, 0), pady=2)
            else:
                self._sign_cb.pack_forget()
        except Exception:
            pass
        try:
            if code == 'FAV':
                self._fav_row.pack(fill='x', after=self._srow)
                self._play_btn.pack(side='right', padx=2, pady=2)
            else:
                self._fav_row.pack_forget()
        except Exception:
            pass
        try:
            if code == 'WOR':
                self._axis_row.pack(fill='x', after=self._srow)
                self._sync_axis_btns()
            else:
                self._axis_row.pack_forget()
        except Exception:
            pass
        self._list_id = None
        self._searching = False
        self._search_rows = None
        self._search_books = {}
        self._blank_embed()
        self._video_tv.delete(*self._video_tv.get_children())
        self._items = {}
        self._picked = set()
        self._set_count(0)
        self._sync_tree_pane()
        self._reload_tree()
        self._restore_pick()
        # ★ 검색어가 남아 있으면 **그 갈래 안에서** 다시 찾는다(검색은 갈래를
        #   따른다 · 2026-08-15 규칙) — 글자만 남고 목록이 딴 것이면 거짓말이다.
        _q = self._q_var.get().strip()
        if _q:
            self._load_search(_q)
        elif self._verse_on():
            self._after_filter_change()
        elif not self._uses_tree():
            self._load_by_view()          # 용어 목록을 걷은 갈래 — 영상 목록을 바로

    # ── 찬양 축 (2026-09-17 · 단추 셋) ──────────────────────────────
    def set_axis(self, code):
        """찬양 축을 선택한다 — **선택한 것 하나만** 센다(느리던 자리)."""
        if code not in ('ARTIST', 'MOOD', 'TOPIC'):
            return
        self._axis = code
        self._sync_axis_btns()
        self._blank_list()
        self._set_count(0)
        self._reload_tree()

    def _sync_axis_btns(self):
        """선택한 축이 눌린 채로 보인다 — 라디오를 또 만들지 않는다."""
        for c, b in getattr(self, '_axis_btns', {}).items():
            try:
                b.config(relief='sunken' if c == self._axis else 'raised')
            except Exception:
                pass

    # ── 보던 자리 잇기 (2026-09-17 · 사용자 ④) ──────────────────────
    def _set_pick(self, bcode, chapter=None):
        self._book_pick = (int(bcode), int(chapter) if chapter else None)
        self._pick_ids = None
        self._sync_pick_btn()

    def _clear_pick(self):
        """걸린 구절 자리를 푼다 — ✕.

        ⚠ 책 갈래에서는 **트리 선택이 곧 그 자리**다(고른 줄이 남아 있으면
          `_on_tree_pick` 이 곧바로 다시 건다 — 실측으로 잡았다). 선택도 함께 푼다.
        """
        self._book_pick = None
        self._pick_ids = None
        self._sync_pick_btn()
        if getattr(self, '_searching', False):
            return self._refresh_current()
        try:
            sel = self._lv.selection()
            if sel:
                self._lv.selection_remove(*sel)
        except Exception:
            pass
        self._blank_list()
        self._set_count(0)
        try:
            if self._view == 'FAV':
                self._load_favs()
            elif self._view not in self.BOOK_VIEWS:
                self._load_by_view()
        except Exception as e:
            print('[kids_view] clear pick: %s' % e)

    def _sync_pick_btn(self):
        b = getattr(self, '_pick_btn', None)
        if b is None:
            return
        try:
            if self._book_pick:
                bc, ch = self._book_pick
                nm = self._book_names().get(bc, str(bc))
                if ch:
                    nm += ' ' + (i18n.t('KV_CHAP_N', '%d장') % ch)
                b.config(text=nm + ' ✕')
                if not b.winfo_manager():
                    b.pack(side='left', padx=(6, 0), pady=2)
            else:
                b.pack_forget()
        except Exception:
            pass

    def _pick_filter(self):
        """걸린 자리의 영상 번호 집합 — 안 걸렸으면 None(거르지 않는다).

        ★ 2026-10-07 — 구절 거르개가 걸려 있으면 그 구절의 영상과 **겹치는 것만**."""
        vk = self._verse_ids()
        if vk is not None:
            return vk                     # 구절 거르개는 책 자리와 겹치지 않는다(80-2 — 배지와 같은 잣대)
        return self._book_ids()

    def _book_ids(self):
        if not self._book_pick or getattr(self, '_searching', False):
            # ⚠ 찾기는 **넓게** 한다 — 트리 선택을 무시하는 것과 같은 까닭이다.
            #   구절 자리까지 함께 걸면 검색이 거의 0건이 된다.
            return None
        if self._pick_ids is not None:
            return self._pick_ids
        bc, ch = self._book_pick
        sql = ("SELECT DISTINCT l.clicked_id FROM " + media_link.TBL + " l"
               "  JOIN bible_index bi ON bi.verse_id=l.target_id"
               " WHERE l.link_type=? AND COALESCE(l.record_status,'LIVE')='LIVE'"
               "   AND bi.bcode=?")
        args = [media_link.lt('VERSE'), int(bc)]
        if ch:
            sql += " AND bi.chapter=?"
            args.append(int(ch))
        conn = self._db()
        try:
            self._pick_ids = set(r[0] for r in conn.execute(sql, args))
        except Exception as e:
            print('[kids_view] pick: %s' % e)
            self._pick_ids = set()
        finally:
            conn.close()
        return self._pick_ids

    def _restore_pick(self):
        """갈래를 바꿔도 **보던 자리**를 잇는다(사용자 「다시 책을 처음부터
        선택하도록 하지 마라」).

        책 갈래면 그 책·장 줄을 다시 고르고, 책 축이 없는 갈래(찬양·어린이·
        즐겨찾기)면 **거르개로 남겨** 그 자리의 것만 보인다.
        ⚠ 그 갈래에 그 책 영상이 아예 없으면 **억지로 만들지 않는다**(§0-1).
        """
        self._sync_pick_btn()
        if not self._book_pick:
            return
        bc, ch = self._book_pick
        try:
            if self._view in self.BOOK_VIEWS:
                iid = 'B%d' % bc
                if not self._lv.exists(iid):
                    return
                self._lv.item(self._lv.parent(iid), open=True)
                self._expand_book(iid, bc)
                cid = '%s_c%d' % (iid, ch) if ch else None
                tgt = cid if (cid and self._lv.exists(cid)) else iid
                if cid:
                    self._lv.item(iid, open=True)
                self._lv.selection_set(tgt)
                self._lv.see(tgt)
            elif self._view == 'FAV':
                self._load_favs()
            else:
                self._load_by_view()
        except Exception as e:
            print('[kids_view] restore: %s' % e)

    def _sync_opt_btns(self):
        """옛 이름 — 라디오가 스스로 제 상태를 그린다."""
        try:
            self._view_var.set(self._view)
        except Exception:
            pass

    def _apply_opts(self):
        """옛 이름 — 갈래를 다시 읽는다."""
        self._reload_tree()

    # ── 이어듣기 ────────────────────────────────────────────────────
    def _toggle_pick(self, iid):
        """체크 켜고 끄기 — 체크한 것이 이어듣기 목록이 된다."""
        if iid in self._picked:
            self._picked.discard(iid)
            mark = ''
        else:
            self._picked.add(iid)
            mark = '✓'
        try:
            self._video_tv.set(iid, 'pick', mark)
        except Exception:
            pass
        self._sync_play_btn()

    def _sync_play_btn(self):
        n = len(self._picked)
        try:
            self._play_btn.config(
                text=(i18n.t('KV_PLAYALL', '▶ 이어서 듣기')
                      if not n else '▶ %d' % n))
        except Exception:
            pass

    def _blocked_ids(self, mids):
        """임베드가 막힌 영상 — **이어듣기 목록에서 뺀다**.

        ⚠⚠ 하나라도 섞이면 **거기서 멈춘다**(「이 영상은 인라인 재생이
          제한됩니다」). 실측 89편이 그렇다.
        """
        if not mids:
            return set()
        try:
            conn = self._db()
            q = ("SELECT media_id FROM sys_media_check WHERE status IN"
                 " ('EMBED_BLOCKED','DEAD') AND media_id IN (%s)"
                 % ','.join('?' * len(mids)))
            out = {r[0] for r in conn.execute(q, list(mids))}
            conn.close()
            return out
        except Exception:
            return set()

    def play_ids(self):
        """이어듣기 목록 — **체크한 차례대로**(체크가 없으면 목록 전부).

        ★ 튼는 일과 **가르는 일을 나눴다**(2026-09-17) — 화면을 안 띄우고도
          「무엇을 어떤 차례로 트는가」를 잴 수 있어야 한다(하네스).
        ⚠ **막힌 영상은 뺀다** — 하나라도 섞이면 거기서 멈춘다(실측 89편).
        """
        order = [i for i in self._video_tv.get_children('')
                 if (not self._picked) or i in self._picked]
        rows = [(self._items.get(i) or (None, None, None)) for i in order]
        pairs = [(r[0], r[2]) for r in rows if r and r[0] and r[2]]
        bad = self._blocked_ids([m for m, _v in pairs])
        return [v for m, v in pairs if m not in bad], len(pairs)

    def _play_selected(self):
        """체크한 영상을 **순서대로** 튼다. 체크가 없으면 목록 전부.

        ★ 사용자 요구(2026-09-10) — 「선택항목을 체크한 후 자동재생 버튼을
          누르면 플레이 화면에서 순서대로 자동재생」. 찬양뿐 아니라
          **성경듣기**도 같은 자리에서 이어 듣는다.
        """
        ids, n_all = self.play_ids()
        if not ids:
            try:
                from tkinter import messagebox
                messagebox.showinfo(
                    i18n.t('KV_PLAYALL', '▶ 이어서 듣기'),
                    i18n.t('KV_PLAY_NONE',
                           '틀 수 있는 영상이 없습니다. (재생이 막힌 영상은 뺍니다)'),
                    parent=self)
            except Exception:
                pass
            return
        n_drop = n_all - len(ids)
        try:
            self._ensure_embed()
            if self._embed_player is not None:
                self._embed_player.play_list(ids)
            else:
                import webbrowser
                webbrowser.open('https://www.youtube.com/watch?v=%s' % ids[0])
        except Exception as e:
            print('[kids_view] play_list: %s' % e)
            return
        try:
            self._cnt_lbl.config(text=i18n.t('KV_PLAYING', '%d편 이어서 듣기')
                                 % len(ids) + ('' if not n_drop
                                               else ' (재생 막힘 %d 제외)' % n_drop))
        except Exception:
            pass

    def _open_more(self):
        """[숨기기] — **내리는 쪽**만 모은다(2026-09-17 · 1.txt 5-4(3) 배치).

        ⚠ 「담기」와 가른다 — 한 메뉴에 살리는 것과 내리는 것을 섞으면
          실수하기 쉽다(§241차 ㉜ 2열 배치와 같은 결).
        """
        import tkinter as _tk
        m = _tk.Menu(self, tearoff=0)
        for key, ko in (('MHIDE', '이 영상 숨기기'), ('CHIDE', '이 채널 숨기기'),
                        ('REPORT', '신고')):
            m.add_command(label=i18n.t('KV_FB_' + key, ko),
                          command=lambda k=key: self._on_feedback(k),
                          state=('normal' if self._cur_media else 'disabled'))
        m.add_separator()
        m.add_command(label=i18n.t('KV_HIDDEN_MGR', '숨긴 항목'),
                      command=self._open_hidden_mgr)
        try:
            x = self._more_btn.winfo_rootx()
            y = self._more_btn.winfo_rooty() + self._more_btn.winfo_height()
            m.tk_popup(x, y)
        finally:
            m.grab_release()

    def _open_add_menu(self):
        """[☆ 담기] — **살리는 쪽**. 즐겨찾기와 재생목록이 여기 함께 있다.

        ⚠ 예전에는 재생목록 담기가 **찬양 화면 안에만** 있어 설교를 보다가는
          담을 길이 없었다(2026-09-17 재편에서 모든 갈래로 넓혔다).
        """
        import tkinter as _tk
        m = _tk.Menu(self, tearoff=0)
        for key, ko in (('MFAV', '즐겨듣기'), ('CFAV', '즐겨찾는 채널에 넣기')):
            m.add_command(label=i18n.t('KV_FB_' + key, ko),
                          command=lambda k=key: self._on_feedback(k),
                          state=('normal' if self._cur_media else 'disabled'))
        m.add_separator()
        m.add_command(label=i18n.t('PV_ADDTO', '재생목록에 담기'),
                      command=self._add_to_list)
        try:
            b = self._fb_btns.get('MFAV')
            m.tk_popup(b.winfo_rootx(), b.winfo_rooty() + b.winfo_height())
        finally:
            m.grab_release()

    # ── 재생목록 관리 — 즐겨찾기 갈래 안에 있다 (1.txt 5-4(3)) ────────────
    def _pick_mids(self):
        """체크한 영상(없으면 선택한 한 줄)의 media_id 목록."""
        iids = [i for i in self._video_tv.get_children('') if i in self._picked]
        if not iids:
            iids = list(self._video_tv.selection())
        return [self._items[i][0] for i in iids if i in self._items]

    def _ask_name(self, title, initial=''):
        from tkinter import simpledialog
        return simpledialog.askstring(i18n.t('PV_PICKLIST', '재생목록'), title,
                                      initialvalue=initial or '', parent=self)

    def _new_list(self):
        import db_media_list as ML
        nm = self._ask_name(i18n.t('PV_ASKNAME', '재생목록 이름'))
        if not nm:
            return
        conn = self._db()
        try:
            lid = ML.add_list(conn, nm)
            conn.commit()
        finally:
            conn.close()
        self._reload_tree()
        if lid:
            try:
                self._lv.selection_set('L%d' % lid)
            except Exception:
                pass

    def _rename_list(self):
        import db_media_list as ML
        if self._list_id is None:
            return
        lid = self._list_id
        conn = self._db()
        try:
            cur = next((x[1] for x in ML.lists(conn) if x[0] == lid), '')
        finally:
            conn.close()
        nm = self._ask_name(i18n.t('PV_ASKNAME', '재생목록 이름'), cur)
        if not nm:
            return
        conn = self._db()
        try:
            ML.rename(conn, lid, nm)
            conn.commit()
        finally:
            conn.close()
        self._reload_tree()
        try:
            self._lv.selection_set('L%d' % lid)
        except Exception:
            pass
        self._list_id = lid
        self._say_saved()

    def _add_to_list(self):
        """선택한 영상을 재생목록에 담는다 — **갈래를 섞어** 담는다."""
        from tkinter import messagebox
        import db_media_list as ML
        mids = self._pick_mids()
        if not mids:
            messagebox.showinfo(i18n.t('PV_PICKLIST', '재생목록'),
                                i18n.t('KV_PICKFIRST',
                                       '목록에서 선택한 뒤에 담습니다.'),
                                parent=self)
            return
        conn = self._db()
        try:
            got = ML.lists(conn)
        finally:
            conn.close()
        win = tk.Toplevel(self)
        win.title(i18n.t('PV_ADDTO', '재생목록에 담기'))
        win.transient(self)
        win.grab_set()
        ttk.Label(win, text=i18n.t('KV_ADDN', '%d편을 담을 재생목록') % len(mids)
                  ).pack(padx=12, pady=(12, 4), anchor='w')
        cb = ttk.Combobox(win, state='readonly', width=28,
                          values=[x[1] for x in got]
                          + [i18n.t('PV_NEWLIST', '＋ 새 재생목록')])
        cb.pack(padx=12)
        cb.current(0 if got else len(got))

        def go():
            k = cb.current()
            lid = got[k][0] if k < len(got) else None
            win.destroy()
            nm = None
            if lid is None:
                nm = self._ask_name(i18n.t('PV_ASKNAME', '재생목록 이름'))
                if not nm:
                    return
            c2 = self._db()
            try:
                if lid is None:
                    lid = ML.add_list(c2, nm)
                n = ML.add(c2, lid, mids)
                c2.commit()
            finally:
                c2.close()
            self._say_saved()
            messagebox.showinfo(i18n.t('PV_ADDTO', '재생목록에 담기'),
                                i18n.t('KV_ADDED', '%d편을 담았습니다.') % n,
                                parent=self)
        ttk.Button(win, text=i18n.t('COMMON_OK', '담기'), command=go
                   ).pack(padx=12, pady=10, anchor='e')

    def _move_item(self, d):
        """▲▼ — **누르는 즉시 저장**한다."""
        import db_media_list as ML
        if self._list_id is None:
            return
        mids = self._pick_mids()
        if not mids:
            return
        conn = self._db()
        try:
            ML.move(conn, self._list_id, mids[0], d)
            conn.commit()
        finally:
            conn.close()
        self._load_list(self._list_id)
        self._say_saved()

    def _drop_item(self):
        import db_media_list as ML
        if self._list_id is None:
            return
        mids = self._pick_mids()
        if not mids:
            return
        conn = self._db()
        try:
            ML.remove(conn, self._list_id, mids)
            conn.commit()
        finally:
            conn.close()
        self._load_list(self._list_id)
        self._reload_tree()
        self._say_saved()

    def _say_saved(self):
        """★ **바꾸는 즉시 저장한다** — 그래서 저장 단추 대신 **말한다**."""
        try:
            self._cnt_lbl.config(text=i18n.t('PV_SAVED', '저장했습니다'))
            self.after(1800, lambda: self._set_count(
                len(self._video_tv.get_children(''))))
        except Exception:
            pass

    def _add_my_link(self):
        """[링크추가] — 서핑하다 만난 영상을 **지금 P1 구절**에 잇는다
        (2026-09-03 0.txt 2번). 저장소는 이미 있다(user_media_asset ·
        MEDI_VERS — 96차 덮개) — 이 단추는 입구일 뿐이다."""
        vid = getattr(self, '_verse_id', None)
        if not vid:
            try:
                from tkinter import messagebox
                messagebox.showinfo(
                    i18n.t('LP_ADD_LINK', '링크추가'),
                    i18n.t('KV_NEED_VERSE',
                           'P1 에서 구절을 먼저 선택하면 그 구절에 연결됩니다.'),
                    parent=self)
            except Exception:
                pass
            return
        try:
            import my_edit
            my_edit.open(self, 'VERSE', vid,
                         on_changed=lambda *_a: self._refresh_current(),
                         pick_kind='MEDIA',
                         pick_label='＋ ' + i18n.t('LP_BR_VIDEO', '영상링크'),
                         auto_create=True)
        except Exception as e:
            print('[kids add link] %s' % e)

    # ── 링크 피드백 (0.txt 1번) ─────────────────────────────────────────
    def _fb_target(self):
        """지금 선택한 영상 (media_id, 제목, url, description) 또는 None."""
        return getattr(self, '_cur_media', None)

    def _set_fb_target(self, mid, title, url, desc):
        self._cur_media = (mid, title or '', url or '', desc or '')
        ch = media_pref.channel_of(desc)
        for k, b in getattr(self, '_fb_btns', {}).items():
            live = True
            if k in ('CFAV', 'CHIDE') and not ch:
                live = False            # 채널을 모르면 채널 단추는 못 쓴다
            b.config(state='normal' if live else 'disabled')
        self._sync_fb_marks(ch)

    def _sync_fb_marks(self, ch=None):
        """단추 글자에 지금 상태를 담는다 — 눌렀는지 안 눌렀는지 보이게."""
        if not getattr(self, '_fb_btns', None):
            return
        t = self._fb_target()
        if not t:
            self._fb_lbl.config(text='')
            return
        mid, _title, _url, desc = t
        ch = ch if ch is not None else media_pref.channel_of(desc)
        p = self._pref
        # ⚠⚠⚠ **없는 단추를 이름으로 찾으면 그 자리에서 죽는다**(2026-09-10
        #   실측). 오른쪽 여섯 단추를 `[⋯]` 팝업으로 접으면서(§237차) 이 셋이
        #   `_fb_btns` 에서 빠졌는데 여기가 그대로 이름을 불러 **영상을 누를
        #   때마다 `KeyError: 'MHIDE'`** 가 났다 — 그래서 [☆ 담기]가 영영
        #   안 열리고 고른 영상이 기억되지 않았다.
        #   ⇒ **있는 단추만 손본다.** 접힌 것은 팝업이 제 글자를 그때 짓는다.
        _txt = {
            'MHIDE': (i18n.t('KV_FB_MHIDE_ON', '다시 보이기') if mid in p.hide_m
                      else i18n.t('KV_FB_MHIDE', '이 영상 숨기기')),
            'CHIDE': (i18n.t('KV_FB_CHIDE_ON', '채널 다시 보이기')
                      if ch in p.hide_c
                      else i18n.t('KV_FB_CHIDE', '이 채널 숨기기')),
            # ★ 2026-10-24 docs/4.txt — PC 는 글자로(켜짐 = ✓) · ★·♥ 는 다른 뜻에 쓴다
            'CFAV': (('✓ ' if ch in p.fav_c else '')
                     + i18n.t('M_MP_FAVS', '즐겨찾는 채널')),
            'MFAV': (('✓ ' if self._is_fav(mid) else '')
                     + i18n.t('KV_FB_MFAV_S', '즐겨듣기')),
        }
        for _k, _v in _txt.items():
            _b = self._fb_btns.get(_k)
            if _b is not None:
                try:
                    _b.config(text=_v)
                except Exception:
                    pass
        self._fb_lbl.config(text=('· ' + ch) if ch else '')

    def _is_fav(self, mid):
        """이 영상이 즐겨찾기에 담겨 있나 — ☆/★ 를 가른다."""
        try:
            import listen
            with appdb.connect(self.db_path) as c:
                r = c.execute('SELECT url FROM sys_media_asset WHERE media_id=?', (int(mid),)).fetchone()
                return bool(r) and listen.is_on(c, listen.vid_of(r[0] or '') or '')
        except Exception:
            return False

    def _on_feedback(self, key):
        t = self._fb_target()
        if not t:
            return
        mid, title, url, desc = t
        ch = media_pref.channel_of(desc)
        if key == 'MFAV':
            res = mlv.toggle_fav(self.db_path, mid)      # 영상 즐겨찾기는 옛 표 그대로
            if res:
                self._refresh_current()
            return
        if key == 'CFAV':
            media_pref.toggle_channel_fav(self.db_path, ch)
        elif key == 'MHIDE':
            media_pref.toggle_media_hide(self.db_path, mid)
        elif key == 'CHIDE':
            # 채널을 통째로 숨기는 것은 되돌리기 어려운 선택 — 한 번 묻는다
            from tkinter import messagebox
            if ch not in self._pref.hide_c and not messagebox.askyesno(
                    i18n.t('KV_FB_CHIDE', '이 채널 숨기기'),
                    i18n.t('KV_FB_CHIDE_Q', '「%s」 채널의 영상을 모두 숨길까요?\n'
                                            '[숨긴 항목]에서 되돌릴 수 있습니다.') % ch,
                    parent=self.winfo_toplevel()):
                return
            media_pref.toggle_channel_hide(self.db_path, ch)
        elif key == 'REPORT':
            self._open_report(mid, title, url, desc)
            return
        self._pref = media_pref.load(self.db_path)
        self._sync_hidden_btn()
        self._sync_fb_marks()
        self._refresh_current()

    def _open_report(self, mid, title, url, desc):
        """신고 — **관리자에게 전달된다는 사실을 먼저 알린다**(0.txt 지시)."""
        from tkinter import messagebox
        pop = tk.Toplevel(self)
        pop.title(i18n.t('KV_FB_REPORT', '신고'))
        pop.transient(self.winfo_toplevel())
        ui_theme.adopt(pop)            # 팝업은 한 줄로 테마를 따른다(§36-4)
        _reg(tk.Label(pop, text=i18n.t(
            'KV_REPORT_HINT',
            '관련이 없거나 해로운 자료를 알려 주세요.\n'
            '이 내용은 관리자에게 전달됩니다(제목·주소·채널이 함께 갑니다).'),
            justify='left'), self.db_path).pack(padx=14, pady=(12, 6), anchor='w')
        _reg(tk.Label(pop, text=(title or '')[:60], fg=_c('fg_dim', '#667A85')),
             self.db_path).pack(padx=14, anchor='w')
        txt = tk.Text(pop, width=46, height=4)
        _reg(txt, self.db_path)
        txt.pack(padx=14, pady=8)

        def send():
            reason = txt.get('1.0', 'end').strip()
            _saved, sent = media_pref.report(self.db_path, mid, title, url, desc, reason)
            pop.destroy()
            messagebox.showinfo(
                i18n.t('KV_FB_REPORT', '신고'),
                i18n.t('KV_REPORT_OK', '신선택할 접수했습니다. 관리자에게 전달됩니다.')
                if sent else
                i18n.t('KV_REPORT_QUEUED', '신선택할 저장했습니다. 연결되면 전달됩니다.'),
                parent=self.winfo_toplevel())
        bar = tk.Frame(pop)
        bar.pack(fill='x', padx=14, pady=(0, 12))
        _reg(tk.Button(bar, text=i18n.t('KV_REPORT_SEND', '보내기'), command=send,
                       bd=1, relief='raised'), self.db_path).pack(side='right', padx=4)
        _reg(tk.Button(bar, text=i18n.t('COMMON_CANCEL', '취소'), command=pop.destroy,
                       bd=1, relief='raised'), self.db_path).pack(side='right')

    def _sync_hidden_btn(self):
        """`[⋯]` 에 숨긴 개수만 얹는다.

        ⚠⚠ 그전에는 이 단추의 **이름을 「숨긴 항목」으로 덮었다** — §237차에
          오른쪽 여섯을 `[⋯]` 팝업으로 접으면서 그 단추를 그대로 물려받았기
          때문이다. 그래서 ⓐ `⋯` 이 사라져 **더 보기인 줄 알 수 없고**
          ⓑ 77px 을 먹어 **1단이 자리를 넘겼다**(실측 1,613 / 1,524px).
        ⚠ **잠그지 않는다** — 숨긴 것이 없어도 그 안에 다른 조치가 들어 있다.
        """
        n = self._pref.count()
        if getattr(self, '_hidden_btn', None) is not None:
            self._hidden_btn.config(
                text=' ⋯ ' + ('(%d)' % n if n else ''), state='normal')

    def _open_hidden_mgr(self):
        """숨긴 영상·채널을 되돌리는 자리 — 없으면 실수 한 번이 영구가 된다."""
        pop = tk.Toplevel(self)
        pop.title(i18n.t('KV_HIDDEN_MGR', '숨긴 항목'))
        pop.transient(self.winfo_toplevel())
        ui_theme.adopt(pop)
        tv = ttk.Treeview(pop, columns=('kind', 'name'), show='headings', height=12)
        tv.heading('kind', text=i18n.t('COMMON_TYPE', '유형'))
        tv.heading('name', text=i18n.t('COMMON_NAME', '이름'))
        tv.column('kind', width=80, anchor='center')
        tv.column('name', width=420, anchor='w')
        tv.pack(fill='both', expand=True, padx=12, pady=(12, 6))
        rows = {}

        def fill():
            tv.delete(*tv.get_children())
            rows.clear()
            for kind, key, title, ch in media_pref.hidden_list(self.db_path):
                lab = (i18n.t('KV_HIDDEN_VIDEO', '영상') if kind == 'MEDIA'
                       else i18n.t('KV_HIDDEN_CHANNEL', '채널'))
                nm = title if kind == 'MEDIA' else key
                iid = tv.insert('', 'end', values=(lab, nm))
                rows[iid] = (kind, key)
        fill()

        def restore():
            sel = tv.selection()
            for iid in sel:
                kind, key = rows.get(iid, (None, None))
                if kind == 'MEDIA':
                    media_pref.toggle_media_hide(self.db_path, key)
                elif kind == 'CHANNEL':
                    media_pref.toggle_channel_hide(self.db_path, key)
            self._pref = media_pref.load(self.db_path)
            fill()
            self._sync_hidden_btn()
            self._sync_fb_marks()
            self._refresh_current()
        bar = tk.Frame(pop)
        bar.pack(fill='x', padx=12, pady=(0, 12))
        _reg(tk.Button(bar, text=i18n.t('KV_HIDDEN_RESTORE', '다시 보이기'),
                       command=restore, bd=1, relief='raised'),
             self.db_path).pack(side='left')
        _reg(tk.Button(bar, text=i18n.t('COMMON_CLOSE', '닫기'), command=pop.destroy,
                       bd=1, relief='raised'), self.db_path).pack(side='right')

    def _refresh_current(self):
        """검색은 **선택한 갈래 안에서** 한다 (2026-08-15 사용자 지시).

        ⚠ 갈래가 트리를 정하므로 검색도 같은 조건을 쓴다 — 설교·강해를 보다
          「다윗」으로 찾으면 설교·강해 안에서 찾는다.
        """
        q = self._q_var.get().strip()
        if not q:
            # 검색어를 지우면 **카테고리 트리가 돌아온다**(검색 묶음을 걷는다).
            was = self._searching
            self._searching = False
            self._search_rows = None
            self._search_books = {}
            if was:
                self._blank_list()
                self._set_count(0)
                self._reload_tree()
                self._restore_pick()
                return
            # ★ 2026-10-13 80-2 — 구절 거르개가 걸려 있으면 그 구절 목록을 다시(언어를 바꿔도 그 구절이다)
            if self._verse_on():
                self._after_filter_change()
                return
            # 검색 중이 아니었다 — 고른 트리 줄로 되돌아간다.
            sel = self._lv.selection()
            if sel and self._tree_pay.get(sel[0]):
                self._on_tree_pick()
            else:
                self._blank_list()
                self._set_count(0)
            return
        self._load_search(q)

    def _reset_search(self):
        """X — 검색어를 비우고 **구절 거르개도 푼다**(51-4(6) 사용자 「전체 검색하기 위해서는
        구절 필터링 조건을 해제/제거하는 버튼(x버튼)」)."""
        self._q_var.set('')
        if self._vpick and not self._vpick_off:
            self._vpick_off = True
            self._sync_vpick_btn()
        was = self._searching
        self._refresh_current()
        if not was:
            self._after_filter_change()

    def _load_search(self, q):
        """제목으로 찾는다 — **갈래 조건은 그대로 걸고 트리 선택은 무시한다**.

        ⚠ 트리에서 고른 것까지 함께 걸면 「그 책 안에서만」이 되어 거의 0건이
          된다. 찾기는 넓게, 목록은 좁게(P4 연구자료와 같은 규칙).
        """
        _mc, _ma = self._mt_cond()
        aud = self._aud_of()
        sql = self._SEL + "WHERE a.is_active=1 AND a.record_status='LIVE' "
        args = []
        sql += _mc
        args += _ma
        if aud:
            sql += "AND a.audience=? "
            args.append(aud)
        if aud == 'SIGN':
            sc = self._sign_codes.get(self._sign_var.get(), '')
            if sc:
                sql += ("AND UPPER(COALESCE(json_extract("
                        "a.description,'$.sign_code'),''))=? ")
                args.append(sc)
        lc, la = self._lang_cond()
        sql += lc
        args += la
        sql += "AND a.title LIKE ? ORDER BY a.media_id LIMIT 300"
        args.append('%' + q + '%')
        try:
            conn = self._db()
            rows = conn.execute(sql, args).fetchall()
            conn.close()
        except Exception as e:
            print('[kids_view] search: %s' % e)
            rows = []
        self._searching = True
        self._search_rows = rows
        self._fill_search_tree(rows)
        self._blank_list()
        self._fill_videos(rows)

    def _fill_search_tree(self, rows):
        """검색 결과를 **책 묶음**으로 왼쪽에 편다(사용자 확정안).

        ★ 맨 위 「전체」가 결과 전부다 — 묶음만 두면 구절 연결이 없는 영상에
          닿을 길이 없다(§0-1 그 규칙).
        ⚠ 책은 **한 조회로** 센다 — 영상마다 물으면 300번이다.
        """
        self._lv.delete(*self._lv.get_children())
        self._tree_pay = {}
        self._search_books = {}
        ids = [r[0] for r in rows]
        if ids:
            q = ','.join('?' * len(ids))
            sql = ("SELECT DISTINCT l.clicked_id, bi.bcode FROM "
                   + media_link.TBL + " l"
                   "  JOIN bible_index bi ON bi.verse_id=l.target_id"
                   " WHERE l.link_type=? AND COALESCE(l.record_status,'LIVE')='LIVE'"
                   "   AND l.clicked_id IN (%s)" % q)
            conn = self._db()
            try:
                for mid, bc in conn.execute(sql, [media_link.lt('VERSE')] + ids):
                    self._search_books.setdefault(int(bc), set()).add(mid)
            except Exception as e:
                print('[kids_view] search tree: %s' % e)
            finally:
                conn.close()
        linked = set()
        for v in self._search_books.values():
            linked |= v
        self._lv.insert('', 'end', iid='S_ALL',
                        text=i18n.t('COMMON_ALL', '전체'), values=(len(rows),))
        self._tree_pay['S_ALL'] = ('SRCH', None, None)
        nm = self._book_names()
        for bc in sorted(self._search_books):
            iid = 'S%d' % bc
            self._lv.insert('', 'end', iid=iid, text=nm.get(bc, str(bc)),
                            values=(len(self._search_books[bc]),))
            self._tree_pay[iid] = ('SRCH', bc, None)
        rest = len(rows) - len(linked)
        if rest > 0:
            self._lv.insert('', 'end', iid='S_NONE',
                            text=i18n.t('KV_SRCH_NOLINK', '구절 연결 없음'),
                            values=(rest,))
            self._tree_pay['S_NONE'] = ('SRCH', -1, None)
        self._lv.selection_set('S_ALL')

    def _show_search(self, bcode):
        """검색 결과 안에서 한 묶음만 — 다시 찾지 않는다(이미 가진 줄을 거른다)."""
        rows = self._search_rows or []
        if bcode is not None:
            if int(bcode) < 0:
                linked = set()
                for v in self._search_books.values():
                    linked |= v
                rows = [r for r in rows if r[0] not in linked]
            else:
                keep = self._search_books.get(int(bcode)) or set()
                rows = [r for r in rows if r[0] in keep]
        self._blank_list()
        self._fill_videos(rows)

    # 옛 이름 — 부르는 자리가 남아 있다
    def _load_kids_search(self):
        self._refresh_current()

    def _set_count(self, n):
        # ⚠ 「표시할 영상이 없습니다」를 걷었다(2026-09-17 사용자 「라벨 제거하라.
        #   없으면 **0개**라고 표시하면 된다」) — 긴 글이 좁은 줄에서 단추를 밀었다.
        if getattr(self, '_cnt_lbl', None) is not None:
            self._cnt_lbl.config(text=i18n.t('KV_COUNT_N', '%d개') % int(n or 0))

    def _fill_videos(self, rows):
        """조회 결과를 가운데 목록에 채운다 — 세 경로가 함께 쓴다.

        ⚠ **숨긴 것은 여기서 거른다**(0.txt 1번). SQL 로 거르지 않는 이유는
          채널이 description JSON 안에 있기 때문이다(media_pref 주석 참조)."""
        self._pref = media_pref.load(self.db_path)
        keep = self._pick_filter()       # 걸린 구절 자리 — 없으면 None
        shown = 0
        for (mid, lang, title, url, mtype, ftype, aud, desc, is_fav) in rows:
            if self._pref.hidden(mid, desc):
                continue
            if keep is not None and mid not in keep:
                continue
            ch = media_pref.channel_of(desc)
            iid = self._video_tv.insert(
                '', 'end',
                # ⚠ 칸 수 = 표준 7칸(mlv.COLS) — 2026-08-30 범위 칸 추가 때
                #   여기만 5값이라 값이 밀렸다(2026-09-03 주요용어와 같은 병).
                values=(mlv.PICK_OFF, '', lang or '',
                        mlv.kind_label(mtype, ftype, aud), title or '',
                        ('★ ' if ch and ch in self._pref.fav_c else '') + mlv.channel_of(desc),
                        mlv.fav_mark(is_fav)),
                tags=(('fav',) if is_fav else ('row',)))
            self._items[iid] = (mid, url, _yt_id(url), title or '', desc or '')
            shown += 1
        self._set_count(shown)
        self._sync_hidden_btn()
        try:
            self._view_var.set('' if self._verse_on() else self._view)   # 구절 목록일 때는 갈래 표시를 끈다
        except Exception:
            pass
        if callable(self.on_count):
            try:
                self.on_count()
            except Exception:
                pass

    def set_verse(self, verse_id):
        """밖에서 구절이 바뀌었을 때 — **번호만 받아 둔다**.

        ★ 2026-09-17 재편 뒤로 이 화면에 「구절에 걸린 영상」 갈래가 없다
          (1.txt 5-4 — P2 에서 들어오면 오른쪽에서 **그 영상만** 튼다).
          그래서 여기서 목록을 흔들지 않는다 — 보던 갈래가 그대로 있어야 한다.
        ⚠ 번호는 [My Edit] 이 「어느 구절에 잇나」로 쓴다.
        """
        self._verse_id = verse_id

    # ── 구절 거르개 (2026-10-07 · docs/1.txt 51-3·4(6)) ─────────────
    #   P1·P4 에서 **사람이 구절을 누르면** 그 구절(·그 구절이 든 단락)에 연결된 영상만.
    #   안 눌렀으면 지금 그대로 · 검색어를 넣으면 거르개를 무시하고 갈래 전체에서 찾는다 ·
    #   칩/X 로 풀면 다음 구절 클릭까지 전체다. 걸리는 짝은 `_scope_keys`(절 + 단락).
    def set_verse_filter(self, vid):
        try:
            vid = int(vid) if vid else None
        except (TypeError, ValueError):
            vid = None
        if vid:
            self._verse_id = vid
        self._vpick = vid
        self._vpick_off = False
        self._vpick_ids = None
        self._sync_vpick_btn()
        self._after_filter_change()

    def clear_verse_filter(self):
        if self._vpick and not self._vpick_off:
            self._vpick_off = True
            self._sync_vpick_btn()
            self._after_filter_change()
            if callable(self.on_count):
                self.after_idle(self.on_count)

    on_count = None      # 목록 수가 바뀌면 — P4 탭 배지가 다시 센다(80-2)

    def badge_count(self):
        """탭 배지 = 지금 목록 수. 구절 거르개가 안 걸렸으면 None(배지 없음 — 목록이 그 구절이 아니다)."""
        return len(self._items) if self._verse_on() else None

    def _verse_on(self):
        return (bool(getattr(self, '_vpick', None)) and not self._vpick_off
                and not getattr(self, '_searching', False))

    def _verse_ids(self):
        if not self._verse_on():
            return None
        if self._vpick_ids is None:
            conn = self._db()
            try:
                self._vpick_ids = verse_media_ids(conn, self._vpick)
            except Exception as e:
                print('[kids_view] verse ids: %s' % e)
                self._vpick_ids = set()
            finally:
                conn.close()
        return self._vpick_ids

    def _verse_label(self, vid):
        conn = self._db()
        try:
            r = conn.execute(
                "SELECT COALESCE(bn.short_name, bn2.short_name, bi.bcode), bi.chapter, bi.verse"
                " FROM bible_index bi"
                " LEFT JOIN book_names bn ON bn.book_code=bi.bcode AND UPPER(bn.lang_code)=?"
                " LEFT JOIN book_names bn2 ON bn2.book_code=bi.bcode AND bn2.lang_code='EN'"
                " WHERE bi.verse_id=?",
                ((self.lang_getter() or 'KO').upper(), int(vid))).fetchone()
            return '%s %s:%s' % r if r else str(vid)
        except Exception:
            return str(vid)
        finally:
            conn.close()

    def _sync_vpick_btn(self):
        b = getattr(self, '_vpick_btn', None)
        if b is None:
            return
        try:
            if self._vpick and not self._vpick_off:
                b.config(text='%s ✕' % self._verse_label(self._vpick))
                if not b.winfo_manager():
                    b.pack(side='left', padx=(6, 0), pady=2, after=self._cnt_lbl)
            else:
                b.pack_forget()
        except Exception:
            pass

    def _after_filter_change(self):
        """거르개가 걸리거나 풀렸다 — 지금 갈래의 목록을 다시 채운다."""
        if getattr(self, '_searching', False):
            return self._refresh_current()
        self._blank_list()
        self._set_count(0)
        try:
            if self._verse_on():
                self._load_verse_view()
                return
            sel = self._lv.selection() if self._tree_shown() else ()
            if sel and self._tree_pay.get(sel[0]):
                self._on_tree_pick()
            elif self._view == 'FAV':
                self._load_favs()
            elif not self._tree_shown():
                self._load_by_view()
        except Exception as e:
            print('[kids_view] filter: %s' % e)

    def _load_verse_view(self):
        """지금 갈래 안에서 그 구절에 연결된 영상 전부 — LIMIT 앞에서 거른다."""
        # ★★ 2026-10-13 80-2·3 — 구절을 누르면 이 탭은 **그 구절의 영상 전부**(선택한 언어 · 갈래 무관)를 보인다.
        #   탭 배지(`verse_media_count`)와 **같은 잣대**라 개수가 늘 같다. 갈래를 누르면 거르개가 풀린다.
        ids = self._verse_ids() or set()
        if not ids:
            self._fill_videos([])
            return
        lc, la = self._lang_cond()
        sql = self._SEL + "WHERE a.is_active=1 AND a.record_status='LIVE' "
        args = []
        sql += lc
        args += la
        sql += ("AND a.media_id IN (%s) ORDER BY a.media_id"
                % ','.join('?' * len(ids)))
        args += sorted(ids)
        self._run_fill(sql, args)

    # ── 용어 목록 걷기 (2026-10-07 · 51-4(6) 사용자 「왼쪽 목록화면(엔티티 목록)을 제거」) ──
    #   영화애니·어린이·수화의 용어(인물·장소) 목록만 걷는다(사용자 확정 — 책 트리·찬양 축·
    #   재생목록은 남긴다). 그 갈래는 영상 목록이 왼쪽 칸을 통째로 쓴다.
    def _uses_tree(self, view=None):
        v = view or self._view
        return v in self.BOOK_VIEWS or v in ('WOR', 'FAV')

    def _tree_shown(self):
        try:
            return str(self._tree_pane) in [str(p) for p in self._lpw.panes()]
        except Exception:
            return True

    def _sync_tree_pane(self):
        try:
            if self._uses_tree():
                if not self._tree_shown():
                    self._lpw.add(self._tree_pane, minsize=120, width=210,
                                  stretch='never', before=self._list_pane)
            elif self._tree_shown():
                self._lpw.forget(self._tree_pane)
        except Exception:
            pass

    def _scope_keys(self, vid):
        """그 절에 영상이 걸릴 수 있는 짝들 — 모듈 `scope_keys` 한 문(배지와 같다)."""
        conn = self._db()
        try:
            return scope_keys(conn, vid)
        finally:
            conn.close()

    def _load_verse_videos(self):
        """옛 「구절에 걸린 영상」 목록 — 부르는 곳 0(되돌릴 자리로 남긴다)."""
        vid = getattr(self, '_verse_id', None)
        keys = self._scope_keys(vid) if vid else []
        if not keys:
            self._blank_list()
            self._set_count(0)
            return
        sql = (self._SEL + "WHERE a.is_active=1 AND a.record_status='LIVE'"
               "  AND a.media_id IN (SELECT clicked_id FROM " + media_link.TBL +
               "   WHERE COALESCE(record_status,'LIVE')='LIVE' AND (" +
               ' OR '.join('(link_type=? AND target_id=?)' for _ in keys) +
               ")) ")
        args = []
        for ty, tgt in keys:
            args += [ty, tgt]
        lc, la = self._lang_cond()
        sql += lc
        args += la
        sql += "ORDER BY a.media_id LIMIT 300"
        self._run_fill(sql, args)

    def _fill_sign_combo(self):
        """승인된 수화 영상에 있는 코드만 콤보에(이름은 코드표 · 화면 언어)."""
        import media_taxonomy as tax
        lang = (self.lang_getter() or 'KO').upper() if self.lang_getter else 'KO'
        allv = i18n.t('KV_SIGN_ALL', '모든 수화')
        self._sign_codes = {allv: ''}
        try:
            conn = self._db()
            # ★ 조회 문은 `media_taxonomy` 한 곳 — 화면이 sys 를 직접 읽지 않는다
            codes = tax.sign_codes_in_use(conn)
            for c0 in sorted(codes):
                self._sign_codes['%s (%s)' % (tax.sign_name(conn, c0, lang), c0)] = c0
            conn.close()
        except Exception:
            pass
        self._sign_cb.config(values=list(self._sign_codes))
        if self._sign_var.get() not in self._sign_codes:
            self._sign_var.set(allv)

    # ── 데이터 ──────────────────────────────────────────────────────────────
    def _db(self):
        return appdb.connect(self.db_path)

    # ── 왼쪽 트리 — 갈래마다 다르다 (2026-09-17 · 1.txt 5-4(3)) ──────────
    #   설교강해·성경공부·성경듣기 → **묶음 ▸ 책 ▸ 장**(성경듣기 방식)
    #   찬양듣기               → **사역자 / 분위기 / 주제**(지금 방식 유지)
    #   영화애니·어린이·수화     → **제목 목록 + 주제(용어) 구분**
    #   즐겨찾기               → ★ 내 즐겨찾기 + 재생목록들
    #  ⚠ 재료는 이미 있는 문에서 가져온다 — `db_reading_book.GROUPS` ·
    #    `db_worship_artist` · `db_worship_topic` · `db_media_list`.

    def _reload_tree(self):
        """지금 갈래의 트리를 다시 그린다."""
        self._lv.delete(*self._lv.get_children())
        self._tree_pay = {}
        v = self._view
        try:
            if v in self.BOOK_VIEWS:
                self._fill_book_tree()
            elif v == 'WOR':
                self._fill_worship_tree()
            elif v == 'FAV':
                self._fill_list_tree()
            else:
                self._fill_term_tree()
        except Exception as e:
            print('[kids_view] tree(%s): %s' % (v, e))
        if not self._lv.get_children():
            self._lv.insert('', 'end', iid='X',
                            text=i18n.t('KV_TREE_EMPTY',
                                        '아직 이 갈래의 영상이 없습니다'),
                            values=('',))

    def _mt(self):
        """지금 갈래의 media_type **튜플**(빈 튜플 = 안 거른다)."""
        return self.VIEW_COND.get(self._view, ((), None))[0]

    def _aud_of(self):
        """지금 갈래의 audience (없으면 None)."""
        return self.VIEW_COND.get(self._view, ((), None))[1]

    def _book_counts(self, mtype):
        """{bcode: 편 수} — **데이터 층이 센다**(§121차 화면은 sys 를 직접 안 읽는다)."""
        import db_reading_book as RB
        conn = self._db()
        try:
            return RB.books_with_media(conn, mtype)
        finally:
            conn.close()

    def _book_names(self):
        lang = (self.lang_getter() or 'KO').upper()
        conn = self._db()
        try:
            nm = dict(conn.execute(
                "SELECT book_code, full_name FROM book_names"
                " WHERE UPPER(lang_code)=?", (lang,)).fetchall())
            if not nm:
                nm = dict(conn.execute(
                    "SELECT book_code, full_name FROM book_names"
                    " WHERE UPPER(lang_code)='EN'").fetchall())
        finally:
            conn.close()
        return nm

    def _fill_book_tree(self):
        """묶음 ▸ 책 ▸ 장 — **보유한 것만**(§0-1). 장은 펼 때 채운다."""
        import db_reading_book as RB
        mtype = self._mt()
        have = self._book_counts(mtype)
        nm = self._book_names()
        for code, ko, rr in RB.GROUPS:
            books = [b for b in rr if have.get(b)]
            if not books:
                continue
            g = self._lv.insert('', 'end', iid='G' + code,
                                text=i18n.t('PV_G_' + code, ko),
                                values=(sum(have[b] for b in books),))
            for b in books:
                iid = 'B%d' % b
                self._lv.insert(g, 'end', iid=iid, text=nm.get(b, str(b)),
                                values=(have[b],))
                self._tree_pay[iid] = ('BOOK', b, None)
                # ⚠ 장을 미리 세지 않는다 — 66권을 다 세면 느리다.
                #   자리표를 하나 두고 **펼 때** 채운다.
                self._lv.insert(iid, 'end', iid=iid + '_x', text='…',
                                values=('',))

    def _on_tree_open(self, _e=None):
        """책을 펴면 그 책의 **장**을 그때 센다(자리표를 갈아 끼운다)."""
        iid = self._lv.focus()
        pay = self._tree_pay.get(iid)
        if not pay or pay[0] != 'BOOK':
            return
        kids = self._lv.get_children(iid)
        if not (len(kids) == 1 and kids[0].endswith('_x')):
            return
        self._expand_book(iid, pay[1])

    def _expand_book(self, iid, bcode):
        """그 책의 장을 채운다 — 이미 찼으면 아무 일도 안 한다(멱등).

        ⚠ 자리 잇기(`_restore_pick`)도 이 문을 부른다 — `<<TreeviewOpen>>` 은
          **사람이 펼 때만** 나므로 프로그램이 펴려면 직접 불러야 한다.
        """
        kids = self._lv.get_children(iid)
        if not (len(kids) == 1 and kids[0].endswith('_x')):
            return
        self._lv.delete(kids[0])
        import db_reading_book as RB
        conn = self._db()
        try:
            rows = RB.chapters_with_media(conn, self._mt(), bcode)
        finally:
            conn.close()
        for ch, n in rows:
            cid = '%s_c%d' % (iid, ch)
            self._lv.insert(iid, 'end', iid=cid,
                            text=i18n.t('KV_CHAP_N', '%d장') % ch, values=(n,))
            self._tree_pay[cid] = ('BOOK', bcode, int(ch))

    def _fill_worship_tree(self):
        """찬양 — **선택한 축 하나만** 채운다(2026-09-17 사용자 「버튼 3개」).

        ⚠⚠ 그전에는 사역자·분위기·주제를 **한 트리에 겹쳐** 두어 ⓐ 두 겹이라
          손이 한 번 더 가고 ⓑ **셋을 다 세느라 느렸다**(사용자 신고). 특히
          사역자 수는 한 사람씩 세면서 그때마다 조회수 표를 다시 읽었다.
        ★ 이제 축 단추가 고른 하나만 세고, 편 수가 0인 값은 안 낸다(§0-1).
        """
        import db_worship_artist as WA
        lang = (self.lang_getter() or 'KO').upper()
        ax = getattr(self, '_axis', 'ARTIST')
        conn = self._db()
        try:
            if ax == 'MOOD':
                import media_taxonomy as TX
                cnt = WA.axis_counts(conn)
                for grp in ('mood', 'instrument'):
                    items = (TX.mood_list(self.db_path) if grp == 'mood'
                             else TX.inst_list(self.db_path))
                    for it in items:
                        k = (cnt.get(grp) or {}).get(it['code'], 0)
                        if not k:
                            continue
                        iid = 'M|%s|%s' % (grp, it['code'])
                        self._lv.insert('', 'end', iid=iid,
                                        text=it.get('name') or it['code'],
                                        values=(k,))
                        self._tree_pay[iid] = ('AXIS', grp, it['code'])
            elif ax == 'TOPIC':
                import db_worship_topic as TP
                for eid, nmv, k in TP.topics(conn, lang, pref=self._pref,
                                             only_used=True):
                    iid = 'T%d' % eid
                    self._lv.insert('', 'end', iid=iid, text=nmv, values=(k,))
                    self._tree_pay[iid] = ('TOPIC', eid, None)
            else:
                # ★ **한 조회로 센다** — 사역자마다 물으면 그 수만큼 느리다
                cnt = WA.counts_by_artist(conn, lang=self.sel_lang(),
                                          pref=self._pref)
                feat = set(WA.featured(conn))
                rows = [(aid, nmv, cnt.get(aid, 0), aid in feat)
                        for aid, nmv, _co, _kd, _ext, _n
                        in WA.artists(conn, lang=lang) if cnt.get(aid)]
                rows.sort(key=lambda x: (not x[3], -x[2]))
                for aid, nmv, k, _f in rows:
                    iid = 'A%d' % aid
                    self._lv.insert('', 'end', iid=iid, text=nmv, values=(k,))
                    self._tree_pay[iid] = ('ARTIST', aid, None)
        finally:
            conn.close()

    def _fill_term_tree(self):
        """영화애니·어린이·수화 — **제목 목록 + 주제(용어) 구분**.

        2026-09-17 사용자 「영화애니, 어린이, 수화 => 네가 잘 추천해보아라」.
        ★ 추천한 까닭 — 이 셋은 책·장으로 갈리지 않는다(실측 어린이 101편 ·
          수화 32편 · 영화애니 236편 중 구절 연결 102편). 대신 **제목에서
          읽힌 용어**(인물·장소·교리)가 이미 붙어 있어 그것이 자연스러운 서랍이다.
          어린이 화면이 예전부터 쓰던 **인물 목록**이 바로 이 축이다.
        ⚠ 용어가 안 붙은 영상도 있으므로 맨 위에 **「전체」**를 둔다 — 서랍만
          두면 그 영상들에 닿을 길이 없다(§0-1).
        """
        ts = list(self._mt() or ())
        aud = self._aud_of()
        lang = (self.lang_getter() or 'KO').upper()
        where, args = [], []
        if ts:
            where.append("a.media_type IN (%s)" % ','.join('?' * len(ts)))
            args += ts
        if aud:
            where.append("a.audience=?")
            args.append(aud)
        cond = (' AND ' + ' AND '.join(where)) if where else ''
        conn = self._db()
        try:
            tot = conn.execute(
                "SELECT COUNT(*) FROM sys_media_asset a WHERE a.is_active=1"
                "  AND a.record_status='LIVE'" + cond, args).fetchone()[0]
            rows = conn.execute(
                "SELECT em.entity_id,"
                "  COALESCE(me.contents, en.contents, ko.contents, em.entity_code),"
                "  COUNT(DISTINCT a.media_id) AS cnt "
                "FROM " + media_link.TBL + " l "
                "JOIN sys_media_asset a ON a.media_id=l.clicked_id"
                "  AND a.is_active=1 AND a.record_status='LIVE'" + cond + " "
                "JOIN sys_entity_master em ON em.entity_id=l.target_id"
                "  AND em.record_status='LIVE' "
                "LEFT JOIN sys_text_asset me ON me.clicked_id=em.entity_id"
                "  AND me.text_type='ENTITY_NAME' AND UPPER(me.lang_code)=?"
                "  AND COALESCE(me.record_status,'LIVE')='LIVE' "
                "LEFT JOIN sys_text_asset en ON en.clicked_id=em.entity_id"
                "  AND en.text_type='ENTITY_NAME' AND en.lang_code='EN'"
                "  AND COALESCE(en.record_status,'LIVE')='LIVE' "
                "LEFT JOIN sys_text_asset ko ON ko.clicked_id=em.entity_id"
                "  AND ko.text_type='ENTITY_NAME' AND ko.lang_code='KO'"
                "  AND COALESCE(ko.record_status,'LIVE')='LIVE' "
                "WHERE l.link_type=? AND COALESCE(l.record_status,'LIVE')='LIVE' "
                "GROUP BY em.entity_id ORDER BY cnt DESC, 2",
                args + [lang, media_link.lt('ENTITY')]).fetchall()
        finally:
            conn.close()
        if tot:
            self._lv.insert('', 'end', iid='ALL',
                            text=i18n.t('KV_KIND_ALL', '전체'), values=(tot,))
            self._tree_pay['ALL'] = ('ALL', None, None)
        for eid, nmv, cnt in rows:
            iid = 'E%d' % eid
            self._lv.insert('', 'end', iid=iid, text=nmv, values=(cnt,))
            self._tree_pay[iid] = ('ENTITY', int(eid), None)

    def _fill_list_tree(self):
        """★ 내 즐겨찾기 + 재생목록들 — 이어듣기는 이 화면 안에 있다."""
        import db_media_list as ML
        conn = self._db()
        try:
            got = ML.lists(conn)
        finally:
            conn.close()
        self._lv.insert('', 'end', iid='FAV',
                        text=i18n.t('PV_FAV_ALL', '♪ 즐겨듣기'), values=('',))
        self._tree_pay['FAV'] = ('FAV', None, None)
        for lid, nmv, k in got:
            iid = 'L%d' % lid
            self._lv.insert('', 'end', iid=iid, text=nmv, values=(k,))
            self._tree_pay[iid] = ('LIST', int(lid), None)

    def _on_tree_pick(self, _e=None):
        """왼쪽에서 선택하면 아래 목록이 찬다."""
        sel = self._lv.selection()
        if not sel:
            return
        pay = self._tree_pay.get(sel[0])
        if not pay:
            return
        kind, a, b = pay
        self._cur_eid = a if kind == 'ENTITY' else None
        try:
            if kind == 'BOOK':
                self._set_pick(a, b)          # 갈래를 바꿔도 남는다(사용자 ④)
                self._load_by_book(a, b)
            elif kind == 'ENTITY':
                self._load_videos(a)
            elif kind == 'ALL':
                self._load_by_view()
            elif kind in ('ARTIST', 'AXIS', 'TOPIC'):
                self._load_worship(kind, a, b)
            elif kind == 'SRCH':
                self._show_search(a)
            elif kind == 'FAV':
                self._list_id = None
                self._load_favs()
            elif kind == 'LIST':
                self._list_id = a
                self._load_list(a)
        except Exception as e:
            print('[kids_view] pick(%s): %s' % (kind, e))

    # ── 목록 채우기 ────────────────────────────────────────────────────
    _SEL = ("SELECT a.media_id, a.lang_code, a.title, a.url, a.media_type,"
            "  COALESCE(a.format_type,''), COALESCE(a.audience,''),"
            "  COALESCE(a.description,''),"
            "  CASE WHEN f.fav_id IS NOT NULL THEN 1 ELSE 0 END "
            "FROM sys_media_asset a "
            "%s " % __import__('listen').join_sql('a'))      # ♥ 즐겨듣기(2026-10-11)

    def _mt_cond(self, alias='a'):
        """지금 갈래의 유형 조건 — **여럿일 수 있다**(「말씀」 = 설교+성경공부)."""
        ts = list(self._mt() or ())
        if not ts:
            return '', []
        return (" AND %s.media_type IN (%s) " % (alias, ','.join('?' * len(ts))), ts)

    def _lang_cond(self):
        lg = self.sel_lang()
        return (" AND UPPER(COALESCE(a.lang_code,''))=? ", [str(lg).upper()]) \
            if lg else ('', [])

    def _load_by_book(self, bcode, chapter=None):
        """그 책(또는 장)에 걸린 이 갈래의 영상."""
        lc, la = self._lang_cond()
        sql = (self._SEL +
               "JOIN " + media_link.TBL + " l ON l.clicked_id=a.media_id"
               "  AND l.link_type=? AND COALESCE(l.record_status,'LIVE')='LIVE' "
               "JOIN bible_index bi ON bi.verse_id=l.target_id "
               "WHERE a.is_active=1 AND a.record_status='LIVE'"
               "  AND bi.bcode=? ")
        _mc, _ma = self._mt_cond()
        sql += _mc
        args = [media_link.lt('VERSE'), int(bcode)] + _ma
        if chapter:
            sql += "AND bi.chapter=? "
            args.append(int(chapter))
        sql += lc
        args += la
        sql += "GROUP BY a.media_id ORDER BY a.media_id LIMIT 300"
        self._run_fill(sql, args)

    def _load_by_view(self):
        """갈래 전체 — 「전체」 줄을 눌렀을 때."""
        _mc, _ma = self._mt_cond()
        aud = self._aud_of()
        lc, la = self._lang_cond()
        sql = self._SEL + "WHERE a.is_active=1 AND a.record_status='LIVE' "
        args = list(_ma)
        sql += _mc
        if aud:
            sql += "AND a.audience=? "
            args.append(aud)
        if aud == 'SIGN':
            sc = self._sign_codes.get(self._sign_var.get(), '')
            if sc:
                sql += ("AND UPPER(COALESCE(json_extract("
                        "a.description,'$.sign_code'),''))=? ")
                args.append(sc)
        sql += lc
        args += la
        sql += "ORDER BY a.media_id LIMIT 300"
        self._run_fill(sql, args)

    def _load_worship(self, kind, a, b):
        """사역자 · 분위기/반주 · 주제 — 조회 문은 각 모듈이 갖고 있다."""
        import db_worship_artist as WA
        conn = self._db()
        try:
            if kind == 'ARTIST':
                raw = WA.media_of(conn, int(a), lang=self.sel_lang(),
                                  pref=self._pref)
            elif kind == 'AXIS':
                raw = WA.media_by_axis(conn, a, b, lang=self.sel_lang(),
                                       pref=self._pref)
            else:
                import db_worship_topic as TP
                raw = TP.media_of_topic(conn, int(a), lang=self.sel_lang(),
                                        pref=self._pref)
            ids = [r[0] for r in raw]
        finally:
            conn.close()
        self._load_by_ids(ids)

    def _load_favs(self):
        import media_link as ML2
        conn = self._db()
        try:
            ids = [r[0] for r in ML2.fav_media(conn)]
        finally:
            conn.close()
        self._load_by_ids(ids)

    def _load_list(self, list_id):
        import db_media_list as ML
        conn = self._db()
        try:
            ids = [r[0] for r in ML.items(conn, int(list_id))]
        finally:
            conn.close()
        self._load_by_ids(ids, keep_order=True)

    def _load_by_ids(self, ids, keep_order=False):
        """번호 목록으로 채운다 — 차례를 지켜야 하는 곳(재생목록)이 있다."""
        if not ids:
            self._blank_list()
            return
        ids = list(ids)[:300]
        q = ','.join('?' * len(ids))
        sql = self._SEL + ("WHERE a.media_id IN (%s) AND a.is_active=1"
                           "  AND a.record_status='LIVE'" % q)
        conn = self._db()
        try:
            rows = conn.execute(sql, ids).fetchall()
        finally:
            conn.close()
        if keep_order:
            by = {r[0]: r for r in rows}
            rows = [by[m] for m in ids if m in by]
        self._blank_list()
        self._fill_videos(rows)

    def _run_fill(self, sql, args):
        try:
            conn = self._db()
            rows = conn.execute(sql, args).fetchall()
            conn.close()
        except Exception as e:
            print('[kids_view] list: %s' % e)
            rows = []
        self._blank_list()
        self._fill_videos(rows)

    def _blank_list(self):
        self._blank_embed()
        self._video_tv.delete(*self._video_tv.get_children())
        self._items = {}
        self._picked = set()

    def refresh_persons(self):
        """옛 이름 — 왼쪽 트리를 다시 그린다(밖에서 부르는 자리가 있다)."""
        self._reload_tree()

    def _on_person_select(self, _evt=None):
        self._on_tree_pick()

    def _load_videos(self, eid):
        """그 용어(인물·장소…)에 걸린 이 갈래의 영상."""
        ts = list(self._mt() or ())
        aud = self._aud_of()
        lc, la = self._lang_cond()
        sql = (self._SEL +
               "JOIN " + media_link.TBL + " l ON l.clicked_id=a.media_id"
               "  AND l.link_type=? AND l.target_id=?"
               "  AND COALESCE(l.record_status,'LIVE')='LIVE' "
               "WHERE a.is_active=1 AND a.record_status='LIVE' ")
        args = [media_link.lt('ENTITY'), int(eid)]
        if ts:
            sql += "AND a.media_type IN (%s) " % ','.join('?' * len(ts))
            args += ts
        if aud:
            sql += "AND a.audience=? "
            args.append(aud)
        sql += lc
        args += la
        sql += "ORDER BY a.media_id LIMIT 300"
        self._run_fill(sql, args)

    def _sel_video_target(self):
        """선택한 줄을 조치 단추의 대상으로 — **누르든 화살표든 같다**."""
        sel = self._video_tv.selection()
        if not sel:
            return
        got = self._items.get(sel[0])
        if not got:
            return
        mid, url, _yt, title, desc = got
        self._set_fb_target(mid, title, url, desc)

    def _on_video_click(self, event):
        if self._video_tv.identify_region(event.x, event.y) != 'cell':
            return
        iid = self._video_tv.identify_row(event.y)
        if not iid or iid not in self._items:
            return
        mid, url, yt, title, desc = self._items[iid]
        # ★ **고르기 칸을 누르면 체크만** — 재생하지 않는다(이어듣기 목록 담기).
        if self._video_tv.identify_column(event.x) == '#1':
            self._toggle_pick(iid)
            return
        # 고른 영상을 피드백 줄의 대상으로 (0.txt 1번 — 그 영상에 대해 누른다)
        self._set_fb_target(mid, title, url, desc)
        if self._video_tv.identify_column(event.x) == mlv.FAV_COL:
            res = mlv.toggle_fav(self.db_path, mid)
            if res:
                _s, mark, tag = res
                vals = list(self._video_tv.item(iid, 'values'))
                vals[6] = mark              # fav = 표준 7칸의 마지막(#7)
                self._video_tv.item(iid, values=vals, tags=(tag,))
            return
        if yt and self._embed_host is not None:
            self._embed_play(yt)
        elif url:
            webbrowser.open(url)

    # ── 플레이어 ────────────────────────────────────────────────────────────
    # ── 곡 화면 (P2 찬양에서 온다) ─────────────────────────────────────────
    def show_song(self, song_id):
        """왼쪽에 **그 곡의 곡·판·영상**, 오른쪽에 **대표를 자동 재생**.

        2026-09-17 사용자 「클릭하면 어차피 P4 온라인 영상 탭에서 표시해야 한다.
        이때, 왼쪽 패널에 클릭한 곡의 곡/판/영상 목록을 모두 표시하면서, 가장
        대표적인 영상을 자동 플레이 한다. 사용자가 싫어하면 다른 영상을 클릭하면 된다」.

        ⚠⚠ **브라우저 갈래에서는 저절로 안 튼다** — 목록만 보인다(`video_open.open_rep`).
        ⚠ 대표는 **미리 박아 둔 값이 아니라 그때 센다**(`db_song.rep_order`).
        ⚠ 왼쪽 칸(검색·트리·목록)을 통째로 갈아 끼운다 — 두 칸 배치(1.txt 5-1).
        """
        import video_open as VO
        try:
            import song_panel
            import db_song as S
        except Exception as e:
            print('[kids_view] show_song: %s' % e)
            return 0
        if getattr(self, '_song_panel', None) is None:
            host = tk.Frame(self._pw, bg=_c('panel', 'white'))
            self._song_host = host
            self._song_panel = song_panel.SongPanel(
                host, self.db_path,
                lang_getter=lambda: (self.lang_getter() or 'KO'),
                on_play=lambda u, t='': self._embed_play(_yt_id(u) or u))
            self._song_panel.pack(fill='both', expand=True)
        if self._left_shown():
            try:
                self._pw.forget(self._left_pane)
            except Exception:
                pass
        try:
            self._pw.add(self._song_host, minsize=300, width=420,
                         stretch='never', before=self._right_pane)
        except Exception:
            try:
                self._pw.add(self._song_host, minsize=300, width=420,
                             stretch='never')
            except Exception:
                pass
        self._song_on = True
        self._from_p2 = True
        self._sync_ref_lbl()
        n = self._song_panel.load_song(song_id)
        lg = (self.lang_getter() or 'KO').upper()
        try:
            conn = appdb.connect(self.db_path)
            cands = S.rep_order(conn, song_id, lg)
            conn.close()
        except Exception as e:
            print('[kids_view] rep_order: %s' % e)
            cands = []
        if cands:
            mode = VO.get_mode(self.db_path)
            if mode != 'BROWSER':
                self._ensure_embed()
            VO.open_rep(self._embed_player, cands, mode=mode,
                        db_path=self.db_path)
        return n

    def hide_song(self):
        """곡 화면을 걷고 목록 칸으로 되돌린다."""
        if not getattr(self, '_song_on', False):
            return
        self._song_on = False
        try:
            self._pw.forget(self._song_host)
        except Exception:
            pass
        self._show_left(True)

    def play_video(self, url_or_id, title=''):
        """밖(P2 영상·텍스트 링크)에서 영상 하나를 이 화면에서 재생.

        ★★ 2026-09-17 · 1.txt 5-4(1) — 「P2 영상 탭에서 목록 클릭해서 들어오는
          경우 : 온라인영상 탭 **오른쪽에 영상 표시하기, 왼쪽 검색창 표시제거**.
          오른쪽 영상표시 화면의 상단 가장 왼쪽에 **구절약명 표시**,
          **검색창 표시/닫기 토글버튼**」.
        ⚠ **목록 갈래는 안 바꾼다** — [검색창 표시] 를 누르면 보던 갈래가 그대로 있다.
        """
        self.hide_song()
        self._from_p2 = True
        self._show_left(False)          # 약명은 여기서 함께 켜진다
        yt = _yt_id(url_or_id or '') or (url_or_id or '')
        if yt:
            self._embed_play(yt)

    def _ensure_embed(self):
        """임베드 플레이어가 없으면 만든다 → 있으면 그것.

        ⚠ **한 벌만 산다**(§30) — 갈래를 바꿔도 죽이지 않는다.
        """
        if self._embed_player is not None:
            return self._embed_player
        if not self._embed_host or media_player is None:
            return None
        try:
            self._embed_play('')      # 호스트 준비 + 플레이어 생성 경로를 탄다
        except Exception:
            pass
        return self._embed_player

    def _embed_play(self, video_id):
        """저장된 갈래대로 연다 — 영상만 · 영상+설명(유튜브 쪽) · 브라우저.

        ★ 갈래를 여기서 정하지 않는다(`video_open` 단일 소스 · 2026-09-17 사용자
          「사용자가 설정값을 한번 저장하면 매번 그대로 적용」).
        ⚠ **브라우저 갈래면 재생기를 아예 안 만든다** — 안 쓸 프로세스를 띄우면
          첫 재생이 느려지고 소리가 겹칠 자리가 는다.
        """
        import video_open as VO
        mode = VO.get_mode(self.db_path)
        if mode == 'BROWSER' or not self._embed_host or media_player is None:
            VO.open_video(None, video_id, db_path=self.db_path)
            return
        if self._embed_player is None:
            for w in self._embed_host.winfo_children():
                w.destroy()
            self._embed_player = media_player.EmbeddedPlayer(self._embed_host)
        VO.open_video(self._embed_player, video_id, mode=mode,
                      db_path=self.db_path)

    def _blank_embed(self):
        if self._embed_player is not None:
            try:
                self._embed_player.clear()
            except Exception:
                pass

    # ── 리사이즈 직전값 (sash) ───────────────────────────────────────────────
    def _save_sash(self):
        if not self._state_set:
            return
        try:
            n = len(self._pw.panes()) - 1
            pos = [self._pw.sash_coord(i)[0] for i in range(n)]
            self._state_set('kids_sash', pos)
        except Exception:
            pass

    def _restore_sash(self):
        if not self._state_get:
            return
        pos = self._state_get('kids_sash', None)
        if not isinstance(pos, list):
            return
        # ★ 화면에 견주어 조인다(2026-09-17) — 큰 화면에서 저장한 자리가
        #   작은 노트북에서는 칸 밖이다. 저장값은 안 고친다.
        try:
            lim = int(self.winfo_screenwidth() * 0.70)
        except Exception:
            lim = None
        for i, x in enumerate(pos):
            try:
                v = int(x)
                if lim:
                    v = max(60, min(v, lim))
                self._pw.sash_place(i, v, 1)
            except Exception:
                pass

    def _on_destroy(self, event):
        if event.widget is self and self._embed_player is not None:
            try:
                self._embed_player.stop()
            except Exception:
                pass
            self._embed_player = None
