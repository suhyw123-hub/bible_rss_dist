# -*- coding: utf-8 -*-
"""표시 우선순위 계산기준 — 구절연결 점수의 **개인 점수표** (프레임 부품).

★ 2026-09-02 사용자 확정(0.txt 5번)으로 다시 지었다:
    · **가감점 방식 폐지** — 지표마다 점수 하나(마이너스 입력 가능)
    · **관계유형 지표 폐지** — 연결유형 **하나하나에** 점수를 매긴다
      (「유사군 그룹이 일관성이 부족하므로 그룹별 점수로는 선호를 반영하지
       못한다. 각 항목별로 점수를 매기는 방식이 좋다」).
      유사군은 **나열 차례일 뿐** — 비슷한 유형이 나란히 있어야 견주며
      판단하기 쉽다(대조/반전이 딴 곳에 흩어져 있던 것을 바로잡음).
    · 연결유형은 개념이 복잡하므로 **지표 중 맨 아래** + 유형마다 개념 한 줄.
    · 초기값은 우리가 세팅한다 — 옛 tier 공식과 같은 순위가 나오는 값
      (핵심 30 · 일반 18 · 보조 8. `db_link_rank.rel_defaults`).
    · **캔버스 설정 팝업에 끼워 넣는다**(`build_rank_frame`) — 별도 팝업 폐지.
      `open_setup` 은 호환 껍데기(프레임을 Toplevel 에 담아 연다).
★ 공식·계산은 db_link_rank 단일 소스(`_score_select_abs`·rel_scores CASE).
`--selftest` 의무(지표 표 ↔ 엔진 열쇠 정합).
"""
import sys
import tkinter as tk
from tkinter import messagebox

import appdb
import verse_text as _vt   # ★ 절 본문은 이 문 하나로(합쳐짐·없는절 보완 §verse_text)
import i18n
import db_link_rank as R


# (열쇠, i18n 이름, 기본 라벨, i18n 설명, 중립 설명 한 줄) — tier 는 여기 없다:
# 관계유형은 아래 REL_GROUPS 가 유형별로 편다.
INDICATORS = (
    ('distance', 'RANKW_DIST', '구절 간격',
     'RANKW_DIST_EX', '구약↔신약 100% · 다른 책 60% · 다른 장 25% · 같은 장 0'),
    ('chain', 'RANKW_CHAIN', '구속사 흐름',
     'RANKW_CHAIN_EX', '구속사 흐름(체인)에 속하면 100%'),
    ('desc', 'RANKW_DESC', '설명문 충실도',
     'RANKW_DESC_EX', '연결설명문 150자 이상 100% · 있으면 50% · 없으면 0'),
    ('multi', 'RANKW_MULTI', '다중관점',
     'RANKW_MULTI_EX', '같은 두 구절을 2개 이상의 관점으로 이었으면 100% (개수를 곱하지 않음)'),
    ('hub', 'RANKW_HUB', '허브 구절',
     'RANKW_HUB_EX', '상대 구절의 연결이 10개 이상 100% · 5~9개 50% · 미만 0'),
)

# 유사군 = **나열 차례** (점수 단위가 아니다 — 점수는 유형마다 따로).
# (i18n 열쇠, 기본 이름, [rel_code…])
REL_GROUPS = (
    ('RANKW_G_FULFILL', '성취·예표', ('TYP', 'FUL', 'CIT', 'ALL')),
    ('RANKW_G_FLOW',    '흐름·발전', ('PRG', 'DEP', 'COV')),
    ('RANKW_G_STRUCT',  '대응·구조', ('INC', 'PAR', 'SYN')),
    ('RANKW_G_CONTRAST', '대조',     ('REV', 'CON')),
    ('RANKW_G_SUPPORT', '논증·적용', ('SUP', 'CAU', 'APP', 'ILL', 'REF')),
)

# 유형 개념 한 줄 (KO 기본 — i18n RANKW_RC_<code>)
REL_CONCEPT = {
    'TYP': '구약의 인물·사건이 그리스도를 미리 그린 것',
    'FUL': '예언이 뒤에서 이루어진 것',
    'CIT': '신약이 구약 구절을 그대로 끌어온 것',
    'ALL': '낱말·심상이 은근히 되울리는 것',
    'PRG': '한 주제가 단계적으로 자라나는 것',
    'DEP': '앞 본문을 더 깊이 풀어낸 것',
    'COV': '언약의 맺음·성취로 이어진 것',
    'INC': '처음과 끝이 짜임새로 마주 보는 것',
    'PAR': '같은 내용이 다른 자리에 나란히 있는 것',
    'SYN': '비슷한 사상·표현',
    'REV': '앞의 것이 뒤에서 뒤집히는 것',
    'CON': '서로 반대되는 내용을 맞세운 것',
    'SUP': '주장을 받쳐 주는 본문',
    'CAU': '한 본문이 다른 본문의 까닭이 되는 것',
    'APP': '삶으로 옮기는 자리',
    'ILL': '빗대어 보여 주는 것',
    'REF': '관련 자리를 가리키는 것',
}


def open_setup(parent, db_path, on_applied=None):
    """호환 껍데기 — 프레임을 Toplevel 에 담아 연다 (본자리는 캔버스 설정 팝업)."""
    pop = tk.Toplevel(parent)
    pop.title(i18n.t('RANKW_TITLE', '표시 우선순위 계산기준 설정'))
    pop.transient(parent)
    pop.resizable(True, True)
    f = build_rank_frame(pop, db_path, on_applied)
    f.pack(fill='both', expand=True, padx=8, pady=8)
    try:
        import ui_theme
        ui_theme.adopt(pop)
    except Exception:
        pass
    return pop


def build_rank_frame(parent, db_path, on_applied=None):
    """계산기준 프레임 — 캔버스 설정 팝업이 끼워 넣는다 (2026-09-02 통합)."""
    return _RankFrame(parent, db_path, on_applied)


class _RankFrame(tk.Frame):
    def __init__(self, parent, db_path, on_applied):
        super().__init__(parent)
        _t = i18n.t
        self.db_path = db_path
        self.on_applied = on_applied

        # ★ 글자 통일 = 8pt (2026-09-02 0.txt 5-4 사용자 — 「이 팝업 화면은
        #   매우 밀집되어 있다. 예외적으로 글자를 모두 작게. 연결옵션과 같은
        #   크기로 통일」 — §36 표준서식의 명시적 예외).
        _f8 = ('', 8)
        self._f8 = _f8
        # ── 단추 줄 (상단 — §0) ─────────────────────────────────
        bar = tk.Frame(self)
        bar.pack(fill='x', pady=(0, 4))
        tk.Label(bar, text=_t('RANKW_TITLE', '표시 우선순위 계산기준 설정'),
                 anchor='w', font=('', 8, 'bold')).pack(side='left', padx=(0, 10))
        tk.Button(bar, text=_t('RANKW_SAVE_PREVIEW', '점수표 저장하고 미리보기'),
                  font=_f8, command=self._save_preview).pack(side='left', padx=(0, 6))
        tk.Button(bar, text=_t('RANKW_RECALC', '점수표대로 모든 연결구절 다시 계산'),
                  font=_f8, command=self._apply_all).pack(side='left', padx=(0, 6))
        tk.Button(bar, text=_t('RANKW_RESET', '기본값으로'),
                  font=_f8, command=self._reset).pack(side='left')

        tk.Label(self, anchor='w', justify='left', wraplength=560, font=_f8,
                 text='ⓘ ' + _t('RANKW_HINT3',
                                '지표·유형마다 점수 하나를 매깁니다 — 마이너스를 '
                                '입력할 수 있습니다. 등급(지표설명)에 따라 점수를 '
                                '받아 합산하고, 점수 순서대로 배치합니다(동점은 '
                                '정경 순서).')).pack(fill='x', pady=(0, 4))

        # 저장된 값으로 칸을 채운다 — 유효 배점(초기+가감 흡수)을 하나로 보인다
        try:
            with appdb.connect(db_path) as conn:
                cur = R.raw_weights(conn, 'USER')
                eff = R.eff_from_raw(cur)
                rel_dft = R.rel_defaults(conn)
                self._rel_names = self._load_rel_names(conn)
        except Exception:
            cur, eff, rel_dft = {}, dict(R.DEFAULT_WEIGHTS), {}
            self._rel_names = {}
        rel_cur = dict(rel_dft)
        rel_cur.update(cur.get('rel_scores') or {})
        self._rel_dft = rel_dft

        body = tk.Frame(self)
        body.pack(fill='x')
        self._vars = {}
        row = 0
        for key, nk, nd, ek, ed in INDICATORS:
            # ⚠ 고정 글자폭(width=13)을 걷었다 (2026-09-02 사용자 신고 「다국어
            #   모드에서 글자가 보이지 않는다」 — EN 'Multiple viewpoints' 같은
            #   긴 이름이 13자에서 잘려 나갔다. 자연 폭 + 넓어진 팝업이 답이다).
            tk.Label(body, text=_t(nk, nd), anchor='w',
                     font=_f8).grid(row=row, column=0, sticky='w', padx=(0, 8))
            v = tk.StringVar(value=str(int(eff.get(key, 0))))
            self._vars[key] = v
            tk.Entry(body, textvariable=v, width=5, justify='right',
                     font=_f8).grid(row=row, column=1, sticky='w', padx=(0, 8))
            tk.Label(body, text=_t(ek, ed), anchor='w', justify='left',
                     wraplength=760, font=_f8).grid(row=row, column=2, sticky='w')
            row += 1

        # ── 연결유형 — **맨 아래** · 유형마다 점수 + 개념 한 줄 ──────────
        tk.Label(self, text=_t('RANKW_RELTYPES', '연결유형 (유형마다 점수 · '
                               '마이너스 가능)'), anchor='w',
                 font=('', 8, 'bold')).pack(fill='x', pady=(8, 0))
        # ★ 취급 안내 (0.txt 5-6 — 「한 구절이 이렇게 많은 점수를 받는 것처럼
        #   오해하지 않도록」) — 유형은 다른 지표와 층이 다르다.
        tk.Label(self, anchor='w', justify='left', wraplength=560, font=_f8,
                 text=_t('RANKW_REL_NOTE',
                         '구절마다 해당하는 연결유형의 점수를 배정합니다 — '
                         '유형이 여럿이면 가장 높은 것 하나만 반영합니다'
                         '(대부분 1~2개입니다).')).pack(fill='x', pady=(0, 2))
        # ★ 세 기둥 (2026-09-02 — 팝업이 좌우 최대가 되면서 폭이 넉넉하다.
        #   기둥을 늘리면 높이가 줄어 캔버스가 더 보인다) + 개념 한 줄
        #   (「연결유형 설명이 한줄 만으로 설명할 수 있으면 더 좋다」).
        rf = tk.Frame(self)
        rf.pack(fill='x')
        cols = [tk.Frame(rf), tk.Frame(rf), tk.Frame(rf)]
        cols[0].pack(side='left', anchor='n', padx=(0, 14))
        cols[1].pack(side='left', anchor='n', padx=(0, 14))
        cols[2].pack(side='left', anchor='n')
        self._rel_vars = {}
        groups = list(REL_GROUPS) + [('RANKW_G_ETC', '기타', tuple(
            c for c in sorted(rel_cur) if not any(
                c in g[2] for g in REL_GROUPS)))]
        rrows = [0, 0, 0]
        for gi, (gk, gname, codes) in enumerate(groups):
            codes = [c for c in codes if c in rel_cur]
            if not codes:
                continue
            ci = 0 if gi < 2 else (1 if gi < 4 else 2)
            col = cols[ci]
            tk.Label(col, text='── %s ──' % _t(gk, gname), anchor='w',
                     font=_f8).grid(row=rrows[ci], column=0, columnspan=3,
                                    sticky='w', pady=(2, 0))
            rrows[ci] += 1
            for c in codes:
                nm = self._rel_names.get(c, c)
                # ⚠ 고정 글자폭 제거 — 다국어 이름이 잘리지 않게 (2026-09-02)
                tk.Label(col, text=nm, anchor='w', font=_f8).grid(
                    row=rrows[ci], column=0, sticky='w', padx=(8, 6))
                v = tk.StringVar(value=str(int(rel_cur.get(c, 0))))
                self._rel_vars[c] = v
                tk.Entry(col, textvariable=v, width=5, justify='right',
                         font=_f8).grid(row=rrows[ci], column=1,
                                        sticky='w', padx=(0, 6))
                tk.Label(col, text=_t('RANKW_RC_%s' % c,
                                      REL_CONCEPT.get(c, '')),
                         anchor='w', justify='left', wraplength=340,
                         font=('', 8)).grid(row=rrows[ci], column=2, sticky='w')
                rrows[ci] += 1

        # ── 미리보기 — 최다 연결 절의 현재/수정 후 좌우 대비 ─────────
        pv = tk.LabelFrame(self, text=_t('RANKW_PREVIEW', '미리보기 — 연결이 '
                                         '가장 많은 구절'))
        pv.pack(fill='both', expand=True, pady=(8, 0))
        cols = tk.Frame(pv)
        cols.pack(fill='both', expand=True)
        self._pv_txt = {}
        for side, kk, dft in (('left', 'RANKW_CUR', '현재'),
                              ('right', 'RANKW_NEW', '수정 후')):
            f = tk.Frame(cols)
            f.pack(side=side, fill='both', expand=True, padx=4, pady=3)
            tk.Label(f, text=_t(kk, dft), anchor='w', font=_f8).pack(fill='x')
            txt = tk.Text(f, height=8, width=34, wrap='none', state='disabled',
                          font=_f8)
            txt.pack(fill='both', expand=True)
            self._pv_txt[side] = txt

    # ── 재료 ────────────────────────────────────────────────────
    def _load_rel_names(self, conn):
        lang = 'KO'
        try:
            app = self._find_app()
            lang = getattr(app, 'lang', 'KO') if app else 'KO'
        except Exception:
            pass
        out = {}
        try:
            for code, nm in conn.execute(
                    'SELECT rel_code, rel_name FROM sys_rel_catalog'
                    ' WHERE lang_code=?', (lang,)):
                out.setdefault(code, nm)
            for code, nm in conn.execute(
                    'SELECT rel_code, rel_name FROM sys_rel_catalog'
                    " WHERE lang_code='KO'"):
                out.setdefault(code, nm)
        except Exception:
            pass
        return out

    def _num(self, var, lo=-999, hi=999):
        try:
            return max(lo, min(hi, int(float(var.get() or 0))))
        except Exception:
            return 0

    def _collect(self):
        """화면 → 절대점수 원값 dict (mode='ABS' · 부호 있는 점수 하나씩)."""
        out = {'mode': 'ABS', 'tier': 0}
        for key, *_r in INDICATORS:
            out[key] = self._num(self._vars[key])
            out[key + '_adj'] = 0
        out['rel_scores'] = {c: self._num(v) for c, v in self._rel_vars.items()}
        return out

    # ── 동작 ────────────────────────────────────────────────────
    def _save_preview(self):
        _t = i18n.t
        raw = self._collect()
        try:
            with appdb.connect(self.db_path) as conn:
                R.save_user_weights(conn, raw)
                vid = R.busiest_vid(conn)
                if vid is None:
                    return
                cur_rows = R.preview_top(conn, vid, None, 10)
                new_rows = R.breakdown(conn, vid, raw, 10)
                self._fill_preview(conn, cur_rows, new_rows)
        except Exception as e:
            print('[rank setup]', e)
            messagebox.showerror(_t('RANKW_TITLE', '표시 우선순위 계산기준 설정'),
                                 str(e), parent=self)

    def _fill_preview(self, conn, cur_rows, new_rows):
        app = self._find_app()
        lang = getattr(app, 'lang', 'KO') if app else 'KO'
        ver = getattr(app, 'ver', 'KRV') if app else 'KRV'
        _cn = {'distance': i18n.t('RANKW_DIST', '구절 간격'),
               'rel': i18n.t('RANKW_TIER', '유형'),
               'chain': i18n.t('RANKW_CHAIN', '구속사 흐름'),
               'desc': i18n.t('RANKW_DESC', '설명문'),
               'multi': i18n.t('RANKW_MULTI', '다중관점'),
               'hub': i18n.t('RANKW_HUB', '허브')}
        for side, rows in (('left', cur_rows), ('right', new_rows)):
            txt = self._pv_txt[side]
            txt.config(state='normal')
            txt.delete('1.0', 'end')
            for r in rows:
                tid, rel, s = r[0], r[1], r[2]
                ref = self._ref_label(conn, tid, lang)
                body = self._verse_snip(conn, tid, ver)
                line = '%s  %s  (%s' % (ref, body, s)
                # ★ 득점 내역 (0.txt 5-5 — 「왜 이 순서인가」가 그 자리에서
                #   읽히게). 0이 아닌 지표만 짧게.
                if len(r) > 3 and isinstance(r[3], dict):
                    parts = ['%s%d' % (_cn.get(k, k), round(v))
                             for k, v in r[3].items() if round(v) != 0]
                    if parts:
                        line += ' = ' + '+'.join(parts)
                txt.insert('end', line + ')\n')
            txt.config(state='disabled')

    def _find_app(self):
        w = self.master
        while w is not None:
            if hasattr(w, 'ver') and hasattr(w, 'lang'):
                return w
            w = getattr(w, 'master', None)
        return None

    def _ref_label(self, conn, vid, lang):
        try:
            r = conn.execute(
                'SELECT bn.short_name, bi.chapter, bi.verse FROM bible_index bi'
                ' JOIN book_names bn ON bi.bcode = bn.book_code'
                ' WHERE bi.verse_id=? AND bn.lang_code=?', (vid, lang)).fetchone()
            if r:
                return '%s%d:%d' % (r[0], r[1], r[2])
        except Exception:
            pass
        return '#%s' % vid

    def _verse_snip(self, conn, vid, ver, n=12):
        try:
            # ★ 합쳐진 절·없는 절도 뜻이 통하게(§verse_text)
            _s = _vt.resolve(conn, vid, ver)['text']
            if _s:
                s = ' '.join(_s.split())
                return s[:n] + ('…' if len(s) > n else '')
        except Exception:
            pass
        return ''

    def _apply_all(self):
        _t = i18n.t
        raw = self._collect()
        try:
            with appdb.connect(self.db_path) as conn:
                R.save_user_weights(conn, raw)
                n, ms = R.apply_user(conn)
        except Exception as e:
            print('[rank setup]', e)
            messagebox.showerror(_t('RANKW_TITLE', '표시 우선순위 계산기준 설정'),
                                 str(e), parent=self)
            return
        messagebox.showinfo(
            _t('RANKW_TITLE', '표시 우선순위 계산기준 설정'),
            _t('RANKW_DONE', '내 점수를 다시 계산했습니다 — {n}개 연결 · '
               '{ms}ms.').format(n=n, ms=int(ms)), parent=self)
        if callable(self.on_applied):
            try:
                self.on_applied()
            except Exception:
                pass

    def _reset(self):
        _t = i18n.t
        if not messagebox.askyesno(
                _t('RANKW_RESET', '기본값으로'),
                _t('RANKW_RESET_Q', '내 점수표·내 점수를 지우고 기본(관리자 '
                   '기준)으로 돌아갑니다. 계속할까요?'), parent=self):
            return
        try:
            with appdb.connect(self.db_path) as conn:
                R.clear_user(conn)
        except Exception as e:
            print('[rank setup]', e)
            return
        for key, *_r in INDICATORS:
            self._vars[key].set(str(int(R.DEFAULT_WEIGHTS.get(key, 0))))
        for c, v in self._rel_vars.items():
            v.set(str(int(self._rel_dft.get(c, 0))))
        if callable(self.on_applied):
            try:
                self.on_applied()
            except Exception:
                pass


# ══════════════════════════════════════════════════════════════════
def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    keys = [x[0] for x in INDICATORS]
    t('★ 지표 표 ⊂ 엔진 열쇠 (tier 는 유형별 점수가 대체)',
      set(keys) == set(R.DEFAULT_WEIGHTS) - {'tier'}
      and len(keys) == len(set(keys)), keys)
    t('★ 유형별 점수 부품이 엔진에 있다',
      all(hasattr(R, n) for n in
          ('rel_defaults', 'REL_TIER_DEFAULT', 'eff_from_raw',
           '_score_select_abs', 'preview_top', 'busiest_vid')))
    # 유사군에 중복 코드가 없다 — 한 유형이 두 그룹에 들면 점수 칸이 두 개가 된다
    seen = []
    for _gk, _gn, codes in REL_GROUPS:
        seen += list(codes)
    t('★ 유사군 중복 0', len(seen) == len(set(seen)), seen)
    t('★ 개념 한 줄 — 그룹의 모든 유형에 있다',
      all(c in REL_CONCEPT for c in seen),
      [c for c in seen if c not in REL_CONCEPT])
    # ★ 실데이터 — 실사용 유형이 전부 유사군(또는 기타)으로 배치 가능한가
    try:
        conn = appdb.connect(appdb.MAIN_DB)
        used = set(R.rel_defaults(conn))
        conn.close()
        t('★ 실사용 유형 전부 개념 보유(기타 제외)',
          not (used - set(REL_CONCEPT)), used - set(REL_CONCEPT))
    except Exception as e:
        t('실데이터 접근', False, e)
    print('rank_setup selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)
