# -*- coding: utf-8 -*-
"""용어 갈래(원천·십자가·확산) + 겹침 짝 병합 — 2026-09-02 사용자 확정 설계.

★★★ 설계 (166차 뒤 토론에서 확정 — 「하나의 용어 안에 서로 연결된 두 갈래」):
  · **갈래형** — 하나님께 속한 것이 「…하심 같이 너희도」 꼴로 사람에게
    옮겨지는 개념(사랑·거룩·부활·영광·평강·용서·긍휼·위로). 엔티티는
    하나로 병합하고, 구절 연결에 갈래 값(SRC 원천 · CROSS 십자가 · OUT 확산)
    을 단다. **단어 하나가 구속사의 이미-아직을 보여 준다**(사용자).
  · **동어형** — 진노. 사람의 분노는 갈래가 아니라 경고(약1:20)라 갈래 없음.
    낱말 색인에는 남고(색인은 실측), 대표·의미연결·설명문 중심에서 벗어난다.
  · **층위형** — 믿음↔바타흐 등. 분리 유지 + 비교 칸(db_entity_compare)으로
    잇는다. 이 도구의 몫이 아니다(compare 초안은 별도).

★ **갈래 값은 별도 표 `sys_entity_branch`** (entity_id, verse_id, branch_code).
  링크 행에 달지 않는 이유 — `db_term_load --load/--relink` 가 LEXICAL 행을
  **지우고 다시 넣는다**(§148차 T_TOV 사고). 행에 달면 재적재 때 사라진다.
  (entity, verse) 열쇠는 재적재를 그대로 살아 넘는다.

★ **의미연결 행은 DELETE+INSERT 가 아니라 UPDATE 로 옮긴다** — 연결설명문
  (ENTITY_VERSE_DESC)이 링크 PK 에 닻을 내리고 있어, 행을 옮기면 글이
  따라온다. 다시 넣으면 닻이 끊긴다.

★ 단일절인데 목적지에 같은 절 낱말연결이 있으면 **설명문을 낱말 행으로
  옮기고 의미연결 행은 접는다**(§156차 사52:7 판정 — 같은 절이 목록에 두 번
  뜨면 안 된다). 구간 행(end_id)은 구간 정보가 값이라 그대로 옮긴다.

사용:
    python db_term_branch.py --selftest   (의무)
    python db_term_branch.py --status
    python db_term_branch.py --check
    python db_term_branch.py --apply
    python db_term_branch.py --undo
"""
import argparse
import io
import sys

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

import appdb  # noqa: E402
import entity_aliases  # noqa: E402

DB = 'bible_master.db'

# 백업표 접미사 — selftest 는 '_st' 로 갈아타 제 표를 쓴다.
# (2026-09-02 실전에서 잡음 — selftest 의 undo() 가 실 적용의 백업표를 읽어
#  **진짜 이관을 되돌렸다.** §139차 「남의 백업 행을 안 건드린다」 네 번째 사례.)
_SFX = ''


def _bt(name):
    return 'temp_termbranch_%s%s' % (name, _SFX)

# ── 병합 표 (src → dst) ──────────────────────────────────────────────
#   사용자 확정: 「그리스도의 부활이 있기 때문에 성도의 부활도 가능한 것이다.
#   이것은 내가 거룩하니 너희도 거룩하라는 명령과 일관성 있는 구조다.」
MERGES = (
    ('D_GOD_LOVE', 'T_AHAV'),
    ('D_HOLINESS_GOD', 'T_KADOSH'),
    ('D_RESURRECTION_CHRIST', 'T_ANASTASIS'),
    ('D_FINAL_RESURRECTION', 'T_ANASTASIS'),
    ('D_WRATH_GOD', 'T_HEMAH'),
)

# 병합되는 옛 이름 → 검색이 계속 찾도록 별명으로 남긴다.
ALIASES = {
    'T_AHAV': {'KO': ['하나님의 사랑'], 'EN': ['Love of God']},
    'T_KADOSH': {'KO': ['하나님의 거룩'], 'EN': ['Holiness of God']},
    'T_ANASTASIS': {'KO': ['그리스도의 부활', '마지막 부활'],
                    'EN': ['Resurrection of Christ', 'Final Resurrection']},
    'T_HEMAH': {'KO': ['하나님의 진노'], 'EN': ['Wrath of God']},
}

# ── 갈래 값 ──────────────────────────────────────────────────────────
#   SRC 원천(하나님께 속함) · CROSS 십자가·그리스도(전환점) · OUT 확산(성도).
#   ⚠ 애매하면 안 단다 — 갈래 칸은 값이 있는 줄만 채워진다(빈 서랍 원칙).
BRANCH_CODES = ('SRC', 'CROSS', 'OUT')

# 이관되는 의미연결 행의 갈래 — **링크 번호**로 지목(2026-09-02 전 행을 읽고
# 판정). 진노(D_WRATH_GOD)는 동어형이라 갈래 없음.
BRANCH_LINK = {
    # D_GOD_LOVE → T_AHAV
    65214: 'SRC', 66008: 'SRC', 66037: 'SRC', 66138: 'SRC', 66140: 'SRC',
    66167: 'CROSS', 66192: 'CROSS', 66278: 'CROSS', 66305: 'SRC',
    66396: 'SRC', 66519: 'SRC', 66523: 'OUT',
    # 65276 아8:6~7 — 사람 사이 사랑의 노래로도 읽혀 갈래를 안 단다.
    # D_HOLINESS_GOD → T_KADOSH
    65185: 'SRC', 65192: 'SRC', 65204: 'OUT', 65206: 'SRC', 65257: 'SRC',
    65975: 'SRC', 65996: 'SRC', 66049: 'SRC', 66484: 'OUT', 66497: 'OUT',
    66501: 'OUT', 66533: 'SRC',
    # D_RESURRECTION_CHRIST → T_ANASTASIS (그리스도 사건 = CROSS)
    65242: 'CROSS', 66045: 'CROSS', 66106: 'CROSS', 66129: 'CROSS',
    66147: 'CROSS', 66148: 'CROSS', 66190: 'CROSS', 66213: 'CROSS',
    66215: 'CROSS', 66224: 'CROSS', 66247: 'CROSS', 66259: 'CROSS',
    66274: 'CROSS', 66282: 'OUT', 66345: 'CROSS', 66346: 'CROSS',
    66347: 'CROSS', 66419: 'OUT', 66421: 'OUT', 66532: 'CROSS',
    # D_FINAL_RESURRECTION → T_ANASTASIS (성도에게 확산 = OUT)
    65231: 'OUT', 65981: 'OUT', 66031: 'OUT', 66038: 'OUT', 66092: 'OUT',
    66172: 'OUT', 66177: 'OUT', 66191: 'OUT', 66249: 'OUT', 66257: 'OUT',
    66349: 'OUT', 66351: 'OUT', 66353: 'OUT', 66445: 'OUT', 66543: 'OUT',
    66547: 'OUT',
}

# 용어 자체의 대표 구절(is_key) 갈래 — (엔티티 코드, verse_id).
#   판정이 분명한 것만(2026-09-02 본문을 읽고).
BRANCH_VID = {
    # 사랑 — 레19:18 이웃 사랑 · 신6:5 응답 · 고전13 실천 · 요일4:8 본성
    ('T_AHAV', 3300): 'OUT', ('T_AHAV', 5092): 'OUT',
    ('T_AHAV', 28670): 'OUT', ('T_AHAV', 30612): 'SRC',
    # 거룩 — 벧전1:16 「너희도 거룩할지어다」
    ('T_KADOSH', 30391): 'OUT',
    # 부활 — 요11:25 그분 자신 · 고전15:13 · 벧전1:3 산 소망
    ('T_ANASTASIS', 26549): 'CROSS', ('T_ANASTASIS', 28732): 'CROSS',
    ('T_ANASTASIS', 30378): 'OUT',
    # 영광
    ('T_KAVOD', 1958): 'SRC', ('T_KAVOD', 2194): 'SRC',
    ('T_KAVOD', 2492): 'SRC', ('T_KAVOD', 2742): 'SRC',
    ('T_KAVOD', 14170): 'SRC', ('T_KAVOD', 17773): 'SRC',
    ('T_KAVOD', 18513): 'OUT', ('T_KAVOD', 20493): 'SRC',
    # 평강 — 사9:6 평강의 왕 · 사53:5 그가 징계를 받음으로 · 요14:27 나의 평안
    ('T_SHALOM', 3850): 'SRC', ('T_SHALOM', 4484): 'SRC',
    ('T_SHALOM', 14320): 'SRC', ('T_SHALOM', 16096): 'OUT',
    ('T_SHALOM', 17836): 'CROSS', ('T_SHALOM', 18717): 'CROSS',
    ('T_SHALOM', 19647): 'SRC', ('T_SHALOM', 26696): 'CROSS',
    ('T_SHALOM', 29450): 'OUT',
    # 용서 — 렘31:34 새 언약 예고 · 마26:28 언약의 피
    ('T_SALACH', 15553): 'SRC', ('T_SALACH', 18748): 'SRC',
    ('T_SALACH', 19726): 'CROSS', ('T_SALACH', 24083): 'CROSS',
    # 긍휼 — 예수님의 긍휼 = CROSS · 눅10:33 사마리아인 = OUT ·
    #   눅15:20 아버지 비유 = SRC
    ('T_SPLANCHNA', 23416): 'CROSS', ('T_SPLANCHNA', 23612): 'CROSS',
    ('T_SPLANCHNA', 23666): 'CROSS', ('T_SPLANCHNA', 23827): 'CROSS',
    ('T_SPLANCHNA', 24257): 'CROSS', ('T_SPLANCHNA', 24442): 'CROSS',
    ('T_SPLANCHNA', 25209): 'CROSS', ('T_SPLANCHNA', 25397): 'OUT',
    ('T_SPLANCHNA', 25609): 'SRC',
    # 위로 — 사40:1 만 분명(나함은 뉘우침 갈래가 따로 있다)
    ('T_NACHAM', 18422): 'SRC',
}

# ⚠ 충돌 특례 — 행17:31 이 두 출처(66247 단일 · 66249 구간)에 다 있다.
#   구간(66249)이 이기고 66247 은 접는다(설명문은 그 행에 남겨 보존 —
#   내용이 66249 와 겹쳐 병합하면 되풀이가 된다).
COLLIDE_HIDE = {66247}

# ── 병합 엔티티 설명문 재작성 (원천 → 십자가 → 확산 3단) ──────────────
#   흡수한 교리 설명문(D_GOD_LOVE 2,510자 등 — 색인체)의 내용을 산문으로
#   녹였다. 인용은 개역한글 표기.
DESC = {
    'T_AHAV': {
        'KO': """성경의 사랑은 감정을 가리키는 말이 아니라 선택하고 붙드는 일을 가리키는 말입니다. 그래서 명령할 수 있습니다. 감정이라면 명령이 안 됩니다.
개역한글은 이 히브리 낱말을 사랑 140번, 좋아함 20번, 친구 15번으로 옮겼습니다. 「친구」로 옮긴 자리가 있다는 것이 이 낱말의 성격을 보여 줍니다. 마음이 향한 상대를 가리키는 말입니다.
이 사랑의 원천은 하나님입니다. 하나님이 이스라엘을 택하신 까닭은 그들이 많아서가 아니라 사랑하셨기 때문이고(신7:8), 그 사랑은 스스로를 「무궁한 사랑」(렘31:3)이라 부릅니다. 요한일서는 아예 「하나님은 사랑이심이라」(요일4:8)고 씁니다. 사랑이 하나님께 있는 여러 가지 중 하나가 아니라 그분의 본성이라는 것입니다.
그 사랑이 가장 분명하게 나타난 자리가 십자가입니다. 「하나님이 세상을 이처럼 사랑하사 독생자를 주셨으니」(요3:16), 「우리가 아직 죄인 되었을 때에 그리스도께서 우리를 위하여 죽으심으로 하나님께서 우리에게 대한 자기의 사랑을 확증하셨느니라」(롬5:8). 사랑의 증거가 말이 아니라 사건으로 주어졌습니다.
그리고 그 사랑은 받은 사람에게로 번집니다. 「우리가 사랑함은 그가 먼저 우리를 사랑하셨음이라」(요일4:19). 하나님 사랑과 이웃 사랑이 가장 큰 계명이 되는 것은(마22:37~39) 이 차례 위에서입니다. 성도의 사랑은 원천이 아니라 반사입니다.
신약이 쓰는 아가페는 헬라어에서 원래 드물고 밋밋한 낱말이었는데, 신약이 그것을 집어 들어 하나님이 하시는 일의 이름으로 삼았습니다.""",
        'EN': """In Scripture, love is not first a word for a feeling but for choosing and holding fast. That is why it can be commanded; a feeling cannot be.
The Korean Revised Version renders this Hebrew word as love about 140 times, liking 20 times, and friend 15 times. That it can mean "friend" shows its character: it names the one toward whom the heart is turned.
The source of this love is God himself. He chose Israel not because they were many but because he loved them (Deut 7:8), and he calls it "an everlasting love" (Jer 31:3). John writes simply, "God is love" (1 John 4:8) — love is not one of God's possessions but his nature.
That love was shown most plainly at the cross. "God so loved the world, that he gave his only begotten Son" (John 3:16); "God commendeth his love toward us, in that, while we were yet sinners, Christ died for us" (Rom 5:8). The proof of love was given not in words but in an event.
And the love received spreads to those who receive it. "We love him, because he first loved us" (1 John 4:19). Loving God and loving neighbor become the greatest commandments (Matt 22:37-39) on the strength of that order: the believer's love is not a source but a reflection.
The New Testament's word agape was originally a rare, colorless Greek word; the apostles took it up and made it the name of what God does.""",
    },
    'T_KADOSH': {
        'KO': """거룩하다는 말은 착하다는 뜻이 아닙니다. 뿌리 뜻은 「잘라 내어 따로 둔다」에 가깝습니다. 그래서 사람만이 아니라 그릇과 옷과 기름과 날에도 붙습니다.
개역한글이 이 낱말을 옮긴 자리를 보면 그 폭이 드러납니다. 거룩 159번, 성소 113번, 성물 53번, 구별 23번, 지성소 16번입니다. 「성소」와 「성물」이 절반 가까이인 것은 이 낱말이 처음부터 장소와 물건에 붙는 말이었기 때문입니다.
거룩의 원천은 하나님 자신입니다. 스랍들이 「거룩하다 거룩하다 거룩하다」(사6:3)라고 외치는 세 번 반복은 히브리 말이 아는 가장 강한 강조입니다. 다른 어떤 속성도 이렇게 반복되지 않습니다. 그 앞에서 이사야가 「화로다 나여 망하게 되었도다」(사6:5)라고 무너진 것처럼, 거룩은 죄를 견디지 못합니다(합1:13).
거룩함이 없이는 아무도 주를 보지 못하는데(히12:14), 그 거룩하신 분이 죄인을 받으시는 길을 그리스도께서 여셨습니다. 그리스도 안에서 죄인이 「왕 같은 제사장들이요 거룩한 나라」(벧전2:9)로 불리게 됩니다.
그래서 거룩은 명령이 됩니다. 「내가 거룩하니 너희도 거룩할지어다」(레11:45·벧전1:16). 하나님이 쓰시려고 따로 두신 것이 거룩이므로, 제단의 그릇이 거룩한 것은 훌륭해서가 아니라 그 자리에만 쓰기로 했기 때문입니다. 사람도 마찬가지입니다.
신약은 이 낱말을 하기오스로 받았고, 그것을 신자를 부르는 이름으로 씁니다. 개역한글이 「성도」로 옮긴 그 낱말입니다. 착한 사람들이라는 뜻이 아니라 따로 떼어 놓인 사람들이라는 뜻입니다.""",
        'EN': """Holy does not mean good. The root idea is closer to "cut off and set apart" — which is why it attaches not only to people but to vessels, garments, oil, and days.
The breadth shows in how the Korean Revised Version renders it: holy 159 times, sanctuary 113, holy things 53, set apart 23, most holy place 16. Nearly half the occurrences name places and objects, because that is where the word began.
The source of holiness is God himself. The seraphim's threefold cry, "Holy, holy, holy" (Isa 6:3), is the strongest emphasis Hebrew knows; no other attribute is repeated like this. Before it Isaiah collapsed — "Woe is me! for I am undone" (Isa 6:5) — for holiness cannot bear sin (Hab 1:13).
Without holiness no one will see the Lord (Heb 12:14); yet Christ opened the way for the Holy One to receive sinners, so that in him they are called "a royal priesthood, an holy nation" (1 Pet 2:9).
So holiness becomes a command: "Be ye holy; for I am holy" (Lev 11:45; 1 Pet 1:16). A vessel of the altar is holy not because it is finer than other vessels but because it is reserved for that place alone. So it is with people.
The New Testament receives the word as hagios and makes it the name for believers — the word rendered "saints": not the good, but the set-apart.""",
    },
    'T_ANASTASIS': {
        'KO': """아나스타시스는 「일어남」, 곧 부활입니다. 신약 40절에 나오고 개역한글의 98%가 부활 또는 다시 살아남으로 옮깁니다. 헬라 세계에 몸의 부활만큼 낯선 것이 없었기에(행17:32), 이 낱말은 처음부터 복음의 가장 논쟁적인 깃발이었습니다.
부활의 첫 자리는 그리스도이십니다. 예수님은 이 낱말을 자기 이름으로 삼으셨고(「나는 부활이요 생명이니」 요11:25), 죽으신 지 사흘 만에 몸으로 다시 살아나셔서 「잠자는 자들의 첫 열매」(고전15:20)가 되셨습니다. 빈 무덤과 만져 본 손(요20:27), 오백여 형제가 일시에 본 증언(고전15:6)이 그 사건의 무게를 떠받칩니다. 「그리스도께서 만일 다시 살지 못하셨으면 우리의 전파하는 것도 헛것이요 또 너희 믿음도 헛것이며」(고전15:14).
첫 열매가 있으면 추수가 옵니다. 그리스도의 부활이 있기에 성도의 부활이 있습니다. 마지막 날에 무덤 속에 있는 자가 다 그의 음성을 들을 것이고(요5:28~29), 「아담 안에서 모든 사람이 죽은 것같이 그리스도 안에서 모든 사람이 삶을 얻으리라」(고전15:22). 썩을 몸이 썩지 아니할 영광의 몸으로 변화됩니다(고전15:42~44·빌3:21).
그래서 신자의 소망에는 족보가 있습니다. 「예수 그리스도의 죽은 자 가운데서 부활하심으로 말미암아 우리를 거듭나게 하사 산 소망이 있게 하시며」(벧전1:3). 죽음은 끝이 아니라 부활을 기다리는 잠으로 불리게 됩니다(살전4:14).""",
        'EN': """Anastasis means "rising up" — resurrection. It appears in forty New Testament verses, and nothing was stranger to the Greek world than the resurrection of the body (Acts 17:32); from the first, this word was the gospel's most contested banner.
Resurrection begins with Christ. Jesus took the word as his own name — "I am the resurrection, and the life" (John 11:25) — and on the third day rose bodily, becoming "the firstfruits of them that slept" (1 Cor 15:20). The empty tomb, the hands that were touched (John 20:27), and five hundred witnesses at once (1 Cor 15:6) bear the weight of the event. "If Christ be not risen, then is our preaching vain, and your faith is also vain" (1 Cor 15:14).
Where there are firstfruits, harvest follows. Because Christ is risen, his people will rise. At the last day all who are in the graves will hear his voice (John 5:28-29); "as in Adam all die, even so in Christ shall all be made alive" (1 Cor 15:22). The perishable body will be raised imperishable and glorious (1 Cor 15:42-44; Phil 3:21).
So the believer's hope has a lineage: God "hath begotten us again unto a lively hope by the resurrection of Jesus Christ from the dead" (1 Pet 1:3). Death comes to be called not an end but a sleep that waits for resurrection (1 Thess 4:14).""",
    },
    'T_HEMAH': {
        'KO': """성경이 말하는 진노는 성질을 부리는 것이 아닙니다. 잘못된 것을 잘못됐다고 하는 일이고, 그것을 그냥 두지 않겠다는 일입니다.
개역한글이 이 낱말을 옮긴 자리에는 노 105번, 분 74번, 분노 36번, 진노 25번이 섞여 있습니다. 사람의 화와 하나님의 진노에 같은 낱말을 쓰기 때문입니다.
그런데 성경의 진노 본문은 거의 전부 하나님의 진노입니다. 심판할 권세가 사람에게 없기 때문입니다. 사람의 분노에 같은 낱말이 쓰일 때 성경은 그것을 덕이 아니라 경계로 다룹니다. 「사람의 성내는 것이 하나님의 의를 이루지 못함이니라」(약1:20), 「분을 내어도 죄를 짓지 말며」(엡4:26).
하나님의 진노는 변덕이 아니라 거룩의 표현입니다. 「하나님의 진노가 불의로 진리를 막는 사람들의 모든 경건치 않음과 불의에 대하여 하늘로 좇아 나타나나니」(롬1:18). 그리고 그 진노가 모인 자리가 십자가입니다. 하나님이 그리스도를 「화목제물로 세우셨으니」(롬3:25), 믿는 자는 「그로 말미암아 진노하심에서 구원을」(롬5:9) 받습니다.
이 낱말은 언제나 사랑과 붙어 다닙니다. 아무래도 좋은 것에는 화가 나지 않습니다. 하나님이 진노하신다는 것은 아직 상관하신다는 뜻입니다.""",
        'EN': """The wrath Scripture speaks of is not a fit of temper. It is the act of calling wrong what is wrong, and of refusing to leave it be.
The Korean Revised Version renders this vocabulary as anger 105 times, fury 74, indignation 36, wrath 25 — the same words serve for human anger and for the wrath of God.
Yet the Bible's wrath texts are almost entirely about God's wrath, for the authority to judge does not belong to man. When the same words are used of human anger, Scripture treats it not as a virtue but as a warning: "the wrath of man worketh not the righteousness of God" (Jas 1:20); "Be ye angry, and sin not" (Eph 4:26).
God's wrath is not caprice but the expression of his holiness: "the wrath of God is revealed from heaven against all ungodliness and unrighteousness of men, who hold the truth in unrighteousness" (Rom 1:18). And the place where that wrath was gathered is the cross: God set forth Christ "to be a propitiation" (Rom 3:25), and those who believe "shall be saved from wrath through him" (Rom 5:9).
This word always travels with love. No one is angered by what he does not care about. That God is wroth means he has not stopped caring.""",
    },
}

# ── 공용 ─────────────────────────────────────────────────────────────


def branch_map(conn, entity_id):
    """화면용 조회 문 — {verse_id: 'SRC'|'CROSS'|'OUT'}. 표가 없으면 빈 dict.

    ⚠ 화면이 `sys_entity_branch` 를 직접 SELECT 하지 않는다(db_overlay_audit
      래칫). 갈래 조회는 이 한 문이다."""
    try:
        return {v: c for v, c in conn.execute(
            "SELECT verse_id, branch_code FROM sys_entity_branch"
            " WHERE entity_id=?", (entity_id,))}
    except Exception:
        return {}


def _eid(conn, code):
    r = conn.execute(
        "SELECT entity_id FROM sys_entity_master WHERE entity_code=?",
        (code,)).fetchone()
    return r[0] if r else None


def ensure_table(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS sys_entity_branch (
        entity_id   INTEGER NOT NULL,
        verse_id    INTEGER NOT NULL,
        branch_code TEXT NOT NULL,
        PRIMARY KEY (entity_id, verse_id))""")


def _backup_tables(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS %s (
        sys_link_id INTEGER PRIMARY KEY, clicked_id INTEGER,
        target_id INTEGER, record_status TEXT, is_key INTEGER)""" % _bt('link'))
    conn.execute("""CREATE TABLE IF NOT EXISTS %s (
        sys_text_id INTEGER PRIMARY KEY, clicked_id INTEGER, contents TEXT)"""
                 % _bt('text'))
    conn.execute("""CREATE TABLE IF NOT EXISTS %s (
        entity_id INTEGER PRIMARY KEY, record_status TEXT, json_detail TEXT)"""
                 % _bt('entity'))
    conn.execute("""CREATE TABLE IF NOT EXISTS %s (
        entity_id INTEGER, verse_id INTEGER,
        PRIMARY KEY (entity_id, verse_id))""" % _bt('branchrow'))


def _bk_link(conn, lid):
    conn.execute(
        "INSERT OR IGNORE INTO %s "
        "SELECT sys_link_id, clicked_id, target_id, record_status, is_key "
        "FROM sys_link_asset WHERE sys_link_id=?" % _bt('link'), (lid,))


def _bk_text(conn, tid):
    conn.execute(
        "INSERT OR IGNORE INTO %s "
        "SELECT sys_text_id, clicked_id, contents FROM sys_text_asset "
        "WHERE sys_text_id=?" % _bt('text'), (tid,))


def _bk_entity(conn, eid):
    conn.execute(
        "INSERT OR IGNORE INTO %s "
        "SELECT entity_id, record_status, json_detail FROM sys_entity_master "
        "WHERE entity_id=?" % _bt('entity'), (eid,))


# ── 병합 엔진 (selftest 가 합성 자료로도 부른다) ──────────────────────


def merge_pair(conn, src_id, dst_id, collide_hide=frozenset(),
               branch_link=None, log=None):
    """src 엔티티의 연결을 dst 로 이관. → (이관, 접힘, 충돌접힘) 수."""
    log = log if log is not None else (lambda *a: None)
    branch_link = branch_link or {}
    moved = folded = collided = 0

    # 1) 의미연결(THEMATIC) — 설명문이 딸린 큐레이션 층
    rows = conn.execute(
        "SELECT sys_link_id, target_id, end_id FROM sys_link_asset "
        "WHERE link_type='ENTI_VERS' AND clicked_id=? AND rel_code='THEMATIC' "
        "AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY sys_link_id",
        (src_id,)).fetchall()
    for lid, vid, end in rows:
        _bk_link(conn, lid)
        if lid in collide_hide:
            conn.execute("UPDATE sys_link_asset SET record_status='HIDE' "
                         "WHERE sys_link_id=?", (lid,))
            collided += 1
            log('  충돌 접힘 %d (vid %d — 구간 행이 이긴다)' % (lid, vid))
            continue
        lex = conn.execute(
            "SELECT sys_link_id FROM sys_link_asset WHERE link_type='ENTI_VERS'"
            " AND clicked_id=? AND target_id=? AND rel_code='LEXICAL'"
            " AND COALESCE(record_status,'LIVE')='LIVE'",
            (dst_id, vid)).fetchone()
        lex_has_desc = False
        if lex:
            lex_has_desc = bool(conn.execute(
                "SELECT 1 FROM sys_text_asset WHERE clicked_id=? "
                "AND text_type='ENTITY_VERSE_DESC' LIMIT 1",
                (lex[0],)).fetchone())
        if end is None and lex and not lex_has_desc:
            # 단일절 + 낱말행 있음 → 설명문을 낱말행으로, 의미행은 접는다
            for (tid,) in conn.execute(
                    "SELECT sys_text_id FROM sys_text_asset WHERE clicked_id=?"
                    " AND text_type='ENTITY_VERSE_DESC'", (lid,)).fetchall():
                _bk_text(conn, tid)
                conn.execute("UPDATE sys_text_asset SET clicked_id=? "
                             "WHERE sys_text_id=?", (lex[0], tid))
            _bk_link(conn, lex[0])
            conn.execute("UPDATE sys_link_asset SET is_key=1 "
                         "WHERE sys_link_id=?", (lex[0],))
            conn.execute("UPDATE sys_link_asset SET record_status='HIDE' "
                         "WHERE sys_link_id=?", (lid,))
            folded += 1
        else:
            dup = conn.execute(
                "SELECT 1 FROM sys_link_asset WHERE link_type='ENTI_VERS'"
                " AND clicked_id=? AND target_id=? AND rel_code='THEMATIC'"
                " AND COALESCE(record_status,'LIVE')='LIVE'",
                (dst_id, vid)).fetchone()
            if dup:
                conn.execute("UPDATE sys_link_asset SET record_status='HIDE' "
                             "WHERE sys_link_id=?", (lid,))
                collided += 1
            else:
                conn.execute("UPDATE sys_link_asset SET clicked_id=? "
                             "WHERE sys_link_id=?", (dst_id, lid))
                moved += 1
        b = branch_link.get(lid)
        if b:
            conn.execute("INSERT OR IGNORE INTO %s VALUES (?,?)"
                         % _bt('branchrow'), (dst_id, vid))
            conn.execute("INSERT OR REPLACE INTO sys_entity_branch "
                         "VALUES (?,?,?)", (dst_id, vid, b))

    # 2) 그 밖의 연결 전부 — 사전(REFU_ENTI)·영상(MEDI_ENTI)·태그 등
    for col, pat in (('clicked_id', "link_type LIKE 'ENTI\\_%' ESCAPE '\\'"),
                     ('target_id', "link_type LIKE '%\\_ENTI' ESCAPE '\\'")):
        others = conn.execute(
            "SELECT sys_link_id, link_type, clicked_id, target_id, "
            " COALESCE(rel_code,'') FROM sys_link_asset "
            "WHERE %s=? AND %s AND COALESCE(record_status,'LIVE')='LIVE'"
            % (col, pat), (src_id,)).fetchall()
        for lid, lt, cid, tid_, rel in others:
            if lt == 'ENTI_VERS':
                continue                    # 위에서 처리(LEXICAL 은 원천에 없음)
            _bk_link(conn, lid)
            oc, ot = (dst_id, tid_) if col == 'clicked_id' else (cid, dst_id)
            dup = conn.execute(
                "SELECT 1 FROM sys_link_asset WHERE link_type=? AND clicked_id=?"
                " AND target_id=? AND COALESCE(rel_code,'')=?"
                " AND COALESCE(record_status,'LIVE')='LIVE'",
                (lt, oc, ot, rel)).fetchone()
            if dup:
                conn.execute("UPDATE sys_link_asset SET record_status='HIDE' "
                             "WHERE sys_link_id=?", (lid,))
            else:
                conn.execute("UPDATE sys_link_asset SET %s=? "
                             "WHERE sys_link_id=?" % col, (dst_id, lid))
                moved += 1

    # 3) 원천 엔티티를 가린다
    _bk_entity(conn, src_id)
    conn.execute("UPDATE sys_entity_master SET record_status='HIDE' "
                 "WHERE entity_id=?", (src_id,))
    return moved, folded, collided


def apply(conn, verbose=True):
    log = print if verbose else (lambda *a: None)
    ensure_table(conn)
    _backup_tables(conn)
    tot = [0, 0, 0]
    for src_code, dst_code in MERGES:
        s, d = _eid(conn, src_code), _eid(conn, dst_code)
        if s is None or d is None:
            log('⚠ 엔티티 없음:', src_code, dst_code)
            continue
        st = conn.execute("SELECT COALESCE(record_status,'LIVE') FROM "
                          "sys_entity_master WHERE entity_id=?", (s,)).fetchone()
        if st and st[0] == 'HIDE':
            log('· %s — 이미 병합됨(HIDE)' % src_code)
            continue
        m, f, c = merge_pair(conn, s, d, COLLIDE_HIDE, BRANCH_LINK, log)
        log('· %s → %s : 이관 %d · 접힘 %d · 충돌 %d' %
            (src_code, dst_code, m, f, c))
        tot[0] += m; tot[1] += f; tot[2] += c
        # 별명 — 옛 이름을 검색이 계속 찾도록
        al = ALIASES.get(dst_code, {})
        for lang, names in al.items():
            jd = conn.execute("SELECT json_detail FROM sys_entity_master "
                              "WHERE entity_id=?", (d,)).fetchone()[0]
            cur = entity_aliases.aliases_for_lang(jd, lang)
            add = [n for n in names if n not in cur]
            if add:
                _bk_entity(conn, d)
                entity_aliases.update_aliases(conn, d, lang, cur + add)

    # 대표 구절 갈래 (용어 자체의 is_key — 판정 분명한 것만)
    nb = 0
    for (code, vid), b in BRANCH_VID.items():
        d = _eid(conn, code)
        if d is None:
            continue
        conn.execute("INSERT OR IGNORE INTO %s VALUES (?,?)"
                     % _bt('branchrow'), (d, vid))
        cur = conn.execute("SELECT branch_code FROM sys_entity_branch "
                           "WHERE entity_id=? AND verse_id=?", (d, vid)).fetchone()
        if not cur or cur[0] != b:
            conn.execute("INSERT OR REPLACE INTO sys_entity_branch "
                         "VALUES (?,?,?)", (d, vid, b))
            nb += 1
    log('· 대표 구절 갈래 %d건' % nb)

    # 설명문 재작성 (병합분 흡수 · 원천→십자가→확산)
    nd = 0
    for code, texts in DESC.items():
        d = _eid(conn, code)
        if d is None:
            continue
        for lang, body in texts.items():
            row = conn.execute(
                "SELECT sys_text_id, contents FROM sys_text_asset "
                "WHERE text_type='ENTITY_DESC' AND clicked_id=? AND lang_code=?"
                " AND COALESCE(record_status,'LIVE')='LIVE'",
                (d, lang)).fetchone()
            if row and row[1] != body:
                _bk_text(conn, row[0])
                conn.execute("UPDATE sys_text_asset SET contents=? "
                             "WHERE sys_text_id=?", (body, row[0]))
                nd += 1
            elif not row:
                conn.execute(
                    "INSERT INTO sys_text_asset (clicked_id, text_type, "
                    " lang_code, contents, record_status) VALUES (?,?,?,?, 'LIVE')",
                    (d, 'ENTITY_DESC', lang, body))
                nd += 1
    log('· 설명문 갱신 %d건' % nd)
    conn.commit()
    log('이관 합계 %d · 접힘 %d · 충돌 %d' % tuple(tot))


def undo(conn):
    """백업표에서 원복 — 같은 PK 로 되돌린다."""
    n = 0
    for lid, cid, tid_, st, ik in conn.execute(
            "SELECT * FROM " + _bt('link')).fetchall():
        conn.execute("UPDATE sys_link_asset SET clicked_id=?, target_id=?, "
                     "record_status=?, is_key=? WHERE sys_link_id=?",
                     (cid, tid_, st, ik, lid))
        n += 1
    for tid, cid, body in conn.execute(
            "SELECT * FROM " + _bt('text')).fetchall():
        conn.execute("UPDATE sys_text_asset SET clicked_id=?, contents=? "
                     "WHERE sys_text_id=?", (cid, body, tid))
        n += 1
    for eid, st, jd in conn.execute(
            "SELECT * FROM " + _bt('entity')).fetchall():
        conn.execute("UPDATE sys_entity_master SET record_status=?, "
                     "json_detail=? WHERE entity_id=?", (st, jd, eid))
        n += 1
    for eid, vid in conn.execute(
            "SELECT * FROM " + _bt('branchrow')).fetchall():
        conn.execute("DELETE FROM sys_entity_branch WHERE entity_id=? "
                     "AND verse_id=?", (eid, vid))
        n += 1
    for t in ('link', 'text', 'entity', 'branchrow'):
        conn.execute("DELETE FROM " + _bt(t))
    conn.commit()
    print('원복 %d건' % n)


def status(conn):
    ensure_table(conn)
    for src_code, dst_code in MERGES:
        s = _eid(conn, src_code)
        st = conn.execute("SELECT COALESCE(record_status,'LIVE') FROM "
                          "sys_entity_master WHERE entity_id=?", (s,)).fetchone()
        print('%-24s %s' % (src_code, st[0] if st else '없음'))
    n = conn.execute("SELECT COUNT(*) FROM sys_entity_branch").fetchone()[0]
    by = conn.execute("SELECT branch_code, COUNT(*) FROM sys_entity_branch "
                      "GROUP BY 1").fetchall()
    print('갈래 값 %d건 %s' % (n, dict(by)))


def check(conn):
    """dry-run 보고 — 무엇이 어떻게 움직일지."""
    ensure_table(conn)
    for src_code, dst_code in MERGES:
        s, d = _eid(conn, src_code), _eid(conn, dst_code)
        if s is None or d is None:
            print('⚠ 엔티티 없음:', src_code, dst_code)
            continue
        st = conn.execute("SELECT COALESCE(record_status,'LIVE') FROM "
                          "sys_entity_master WHERE entity_id=?", (s,)).fetchone()[0]
        if st == 'HIDE':
            print('· %s — 이미 병합됨' % src_code)
            continue
        rows = conn.execute(
            "SELECT sys_link_id, target_id, end_id FROM sys_link_asset "
            "WHERE link_type='ENTI_VERS' AND clicked_id=? AND rel_code='THEMATIC'"
            " AND COALESCE(record_status,'LIVE')='LIVE'", (s,)).fetchall()
        fold = mv = 0
        nob = []
        for lid, vid, end in rows:
            lex = conn.execute(
                "SELECT 1 FROM sys_link_asset WHERE link_type='ENTI_VERS' AND "
                "clicked_id=? AND target_id=? AND rel_code='LEXICAL' AND "
                "COALESCE(record_status,'LIVE')='LIVE'", (d, vid)).fetchone()
            if end is None and lex and lid not in COLLIDE_HIDE:
                fold += 1
            else:
                mv += 1
            if lid not in BRANCH_LINK and src_code != 'D_WRATH_GOD' \
                    and lid not in COLLIDE_HIDE:
                nob.append(lid)
        other = conn.execute(
            "SELECT COUNT(*) FROM sys_link_asset WHERE (clicked_id=? AND "
            "link_type LIKE 'ENTI\\_%' ESCAPE '\\' AND link_type!='ENTI_VERS')"
            " OR (target_id=? AND link_type LIKE '%\\_ENTI' ESCAPE '\\')",
            (s, s)).fetchone()[0]
        print('· %s → %s : 의미 %d(접힘 %d·이동 %d) · 기타 %d · 갈래 미지정 %s'
              % (src_code, dst_code, len(rows), fold, mv, other, nob or '없음'))


# ── selftest ─────────────────────────────────────────────────────────


def selftest():
    """합성 자료로 엔진을 왕복 — 실데이터 불변(§149차 규칙: 시험 전 MAX 기록,
    시험 뒤에 생긴 행만 걷는다)."""
    conn = appdb.connect(DB)
    ok = fail = 0

    def t(name, cond):
        nonlocal ok, fail
        print('  %s %s' % ('OK  ' if cond else 'FAIL', name))
        ok += cond
        fail += (not cond)

    global _SFX
    ensure_table(conn)
    # 실 백업표 행수를 먼저 재 둔다 — 시험이 그것을 건드리면 안 된다
    _backup_tables(conn)
    real_bk = tuple(conn.execute("SELECT COUNT(*) FROM " + _bt(t2)).fetchone()[0]
                    for t2 in ('link', 'text', 'entity', 'branchrow'))
    _SFX = '_st'
    _backup_tables(conn)
    max_e = conn.execute("SELECT MAX(entity_id) FROM sys_entity_master").fetchone()[0]
    max_l = conn.execute("SELECT MAX(sys_link_id) FROM sys_link_asset").fetchone()[0]
    max_t = conn.execute("SELECT MAX(sys_text_id) FROM sys_text_asset").fetchone()[0]
    pre_link = conn.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
    pre_br = conn.execute("SELECT COUNT(*) FROM sys_entity_branch").fetchone()[0]
    try:
        conn.execute("INSERT INTO sys_entity_master (entity_code, entity_type,"
                     " record_status) VALUES ('ZZTB_SRC','DOCTRINE','LIVE')")
        conn.execute("INSERT INTO sys_entity_master (entity_code, entity_type,"
                     " record_status) VALUES ('ZZTB_DST','TERM','LIVE')")
        s, d = _eid(conn, 'ZZTB_SRC'), _eid(conn, 'ZZTB_DST')
        # dst 낱말행(절 9901) · src 의미행 둘(9901 단일 = 접힘 대상 ·
        # 9902 구간 = 이동 대상) + 설명문
        conn.execute("INSERT INTO sys_link_asset (link_type, clicked_id, "
                     "target_id, rel_code, record_status) VALUES "
                     "('ENTI_VERS',?,9901,'LEXICAL','LIVE')", (d,))
        lex = conn.execute("SELECT MAX(sys_link_id) FROM sys_link_asset").fetchone()[0]
        conn.execute("INSERT INTO sys_link_asset (link_type, clicked_id, "
                     "target_id, rel_code, record_status) VALUES "
                     "('ENTI_VERS',?,9901,'THEMATIC','LIVE')", (s,))
        th1 = conn.execute("SELECT MAX(sys_link_id) FROM sys_link_asset").fetchone()[0]
        conn.execute("INSERT INTO sys_link_asset (link_type, clicked_id, "
                     "target_id, rel_code, end_id, record_status) VALUES "
                     "('ENTI_VERS',?,9902,'THEMATIC',9903,'LIVE')", (s,))
        th2 = conn.execute("SELECT MAX(sys_link_id) FROM sys_link_asset").fetchone()[0]
        conn.execute("INSERT INTO sys_text_asset (clicked_id, text_type, "
                     "lang_code, contents, record_status) VALUES "
                     "(?, 'ENTITY_VERSE_DESC', 'KO', '시험 설명문', 'LIVE')", (th1,))
        conn.commit()

        merge_pair(conn, s, d, frozenset(), {th1: 'SRC', th2: 'OUT'})
        conn.commit()
        # 단일절 → 설명문이 낱말행으로, 의미행 접힘, 낱말행 is_key
        r = conn.execute("SELECT clicked_id FROM sys_text_asset WHERE "
                         "contents='시험 설명문'").fetchone()
        t('★ 설명문이 낱말행으로 따라온다', r and r[0] == lex)
        r = conn.execute("SELECT record_status, is_key FROM sys_link_asset "
                         "WHERE sys_link_id=?", (th1,)).fetchone()
        t('단일절 의미행 접힘', r[0] == 'HIDE')
        r = conn.execute("SELECT is_key FROM sys_link_asset WHERE sys_link_id=?",
                         (lex,)).fetchone()
        t('낱말행 대표 승격', r[0] == 1)
        r = conn.execute("SELECT clicked_id, end_id FROM sys_link_asset "
                         "WHERE sys_link_id=?", (th2,)).fetchone()
        t('구간 의미행은 구간째 이동', r[0] == d and r[1] == 9903)
        r = conn.execute("SELECT branch_code FROM sys_entity_branch WHERE "
                         "entity_id=? AND verse_id=9901", (d,)).fetchone()
        t('갈래 값 — 접힌 행도 (엔티티,절)로 남는다', r and r[0] == 'SRC')
        r = conn.execute("SELECT COALESCE(record_status,'LIVE') FROM "
                         "sys_entity_master WHERE entity_id=?", (s,)).fetchone()
        t('원천 엔티티 가림', r[0] == 'HIDE')
        # 멱등 — 다시 돌려도 안 는다
        n1 = conn.execute("SELECT COUNT(*) FROM sys_entity_branch").fetchone()[0]
        merge_pair(conn, s, d, frozenset(), {th1: 'SRC', th2: 'OUT'})
        conn.commit()
        n2 = conn.execute("SELECT COUNT(*) FROM sys_entity_branch").fetchone()[0]
        t('멱등 — 갈래 행 불변', n1 == n2)

        undo(conn)
        r = conn.execute("SELECT clicked_id FROM sys_text_asset WHERE "
                         "contents='시험 설명문'").fetchone()
        t('★ 원복 — 설명문 닻 복귀', r and r[0] == th1)
        r = conn.execute("SELECT clicked_id, record_status FROM sys_link_asset "
                         "WHERE sys_link_id=?", (th2,)).fetchone()
        t('원복 — 구간 행 복귀', r[0] == s and r[1] == 'LIVE')
        t('원복 — 갈래 행 걷힘',
          conn.execute("SELECT COUNT(*) FROM sys_entity_branch").fetchone()[0]
          == pre_br)
    finally:
        # 시험 뒤에 생긴 행만 걷는다(값으로 지우지 않는다 — §97차 사고)
        conn.execute("DELETE FROM sys_text_asset WHERE sys_text_id>?", (max_t,))
        conn.execute("DELETE FROM sys_link_asset WHERE sys_link_id>?", (max_l,))
        conn.execute("DELETE FROM sys_entity_master WHERE entity_id>?", (max_e,))
        conn.execute("DELETE FROM sys_entity_branch WHERE entity_id>?", (max_e,))
        for tname in ('link', 'text', 'entity', 'branchrow'):
            conn.execute("DROP TABLE IF EXISTS " + _bt(tname))
        _SFX = ''
        conn.commit()
    post_link = conn.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
    t('★ 시험 전 상태로 원복(행수)', post_link == pre_link)
    now_bk = tuple(conn.execute("SELECT COUNT(*) FROM " + _bt(t2)).fetchone()[0]
                   for t2 in ('link', 'text', 'entity', 'branchrow'))
    t('★ 남의 백업 행을 안 건드린다(§139차)', now_bk == real_bk)
    conn.close()
    print('db_term_branch selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--status', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--undo', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(DB)
    if a.undo:
        undo(conn)
    elif a.apply:
        apply(conn)
        status(conn)
    elif a.check:
        check(conn)
    else:
        status(conn)
    conn.close()


if __name__ == '__main__':
    main()
