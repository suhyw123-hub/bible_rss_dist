# -*- coding: utf-8 -*-
"""db_book_attrib.py — 본문 끝 **출처 줄**을 짓고 붙인다 (영구 · `--selftest`)

`python db_book_attrib.py --selftest`   — 의무
`python db_book_attrib.py --check`      — 실태만 (DB 안 건드림)
`python db_book_attrib.py --apply [CODE…]` — 붙인다 (멱등 · 백업)

━━ 왜 새로 만들었나 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
옛 `db_book_attribution.py` 는 **세 권(book_id 1·5·8)만** 다루고 나머지는
손대지 않았다. 실측(2026-08-22) — **11권 4,166편에 출처 줄이 아예 없다**
(스펄전 설교 3,519 · 밀러 423 · 켐피스 114 · 머레이 29 …).

★ **모양** — `— 저자, "제목" (판본). Public domain.`
  연도가 아니라 **판본**을 적는다(2026-08-22 정책). 판본을 모르면 저작 연대,
  번역서면 번역자. 표는 `db_book_desc_data.EDITIONS` 한 곳 — 소개문의
  `▸ 출처` 블록과 같은 자리에서 나온다. 두 곳에 적으면 갈라진다.

⚠ **출처 줄에 약자(`H.`)를 넣지 말 것** — 문장 나누기가 거기서 끊겨
  검증기(`db_book_verify`)가 이 줄을 「원문에 없는 문장」으로 잡는다(실측).
  게이트가 막는다.
⚠ **`ORIGINAL` 만 다룬다.** `MODERN_EN`·`TRANSLATED` 는 우리가 만든 파생물이라
  다른 문구가 필요하다(§17-8) — 그것은 옛 도구가 하던 일이고 여기 담지 않았다.
⚠ 붙이기 전 원문 대조를 깨지 않는지 확인할 것 — 출처 줄은 저자의 글이 아니므로
  검증 하네스에서 **빼고 센다**.
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import appdb
from db_book_desc_data import EDITIONS

DB = 'bible_master.db'
BACKUP = 'temp_book_attrib_backup'
TAIL = 'Public domain.'
# 약자 = 마침표 붙은 한 글자 (문장 나누기를 깬다)
_ABBR = re.compile(r'\b[A-Z]\.')


def line_for(author, title, ed):
    a = ' '.join((author or '').split())
    t = ' '.join((title or '').split())
    e = ' '.join((ed or '').split())
    return '— %s, "%s" (%s). %s' % (a, t, e, TAIL)


# ── 파생물(번역·현대영어) 출처 줄 ────────────────────────────────────
#   ★ 저자·제목은 **원문 그대로** 쓴다 — 한국어 이름표가 따로 없어서
#     옮기려 들면 그 자리에서 또 흔들린다(그것이 이번 사고의 원인이다).
DERIV_TAIL = 'Public domain.'
#: ★ 2026-10-11 — 「번역」이라는 낱말도 **그 언어로**. 그전에는 모든 언어에 한국어
#:   「번역」이 박혀 다른 아홉 언어의 출처 줄 360편이 한국어로 끝났다(실측).
TRANS_WORD = {'KO': '번역', 'EN': 'translation', 'DE': 'Übersetzung', 'FR': 'traduction',
              'ES': 'traducción', 'PT': 'tradução', 'RU': 'перевод', 'JA': '訳',
              'ZH': '翻译', 'ZHT': '翻譯', 'AR': 'ترجمة'}


def trans_word(lang):
    return TRANS_WORD.get((lang or '').upper(), 'translation')


def line_for_derived(variant, lang, author, title, ed, lang_name=None,
                      local_title=None, local_author=None):
    """파생물 본문 끝에 붙일 출처 줄. **한 꼴로 못 박는다.**

    · `MODERN_EN` — 기존 300편이 쓰는 꼴 그대로(바꾸면 그 책이 갈린다)
    · 그 밖    — `— 저자, "제목" (판본) <언어> <그 언어의 「번역」>. Public domain.`
    ⚠ `ORIGINAL` 에는 안 쓴다 — 그것은 `line_for` 의 몫이다.
    """
    a = ' '.join((author or '').split())
    t = ' '.join((title or '').split())
    e = ' '.join((ed or '').split())
    v = (variant or '').upper()
    if v == 'ORIGINAL':
        raise ValueError('원문은 line_for 를 쓴다')
    if v == 'MODERN_EN':
        return '— Modern English adaptation · %s, %s (%s)' % (a, t, e)
    if not lang_name:
        try:
            import lang_config
            lang_name = lang_config.lang_name(lang) or lang
        except Exception:
            lang_name = lang
    # ★ 317차-5 — 그 언어의 제목이 도서 표에 있으면 **그 제목**을 쓴다(제목 단일 소스 ·
    #   사용자 「어느 쪽이든 통일」). 꼴은 손 번역이 써 온 「저자, 「제목」(판본) …」 그대로.
    lt = ' '.join((local_title or '').split())
    if lt:
        la = ' '.join((local_author or '').split()) or a
        head = '— %s, 「%s」' % (la, lt)
        if e:
            head += '(%s)' % e
        return '%s %s %s. %s' % (head, lang_name, trans_word(lang), DERIV_TAIL)
    head = '— %s, "%s"' % (a, t)
    if e:
        head += ' (%s)' % e
    return '%s %s %s. %s' % (head, lang_name, trans_word(lang), DERIV_TAIL)


def check_derived(code, variant, lang, author, title, ed):
    """파생물 출처 줄 게이트 — 흔들릴 자리를 미리 막는다."""
    bad = []
    if (variant or '').upper() == 'ORIGINAL':
        return ['%s: 원문에는 파생물 줄을 쓰지 않는다' % code]
    s = line_for_derived(variant, lang, author, title, ed)
    if '\n' in s:
        bad.append('%s 파생물 출처 줄에 개행' % code)
    if len(s) > 220:
        bad.append('%s 파생물 출처 줄이 %d자 (너무 길다)' % (code, len(s)))
    if not s.startswith('—'):
        bad.append('%s 파생물 출처 줄이 「—」 로 시작하지 않는다' % code)
    return bad


def book_attrib_for(conn, unit_id, variant, lang):
    """그 유닛이 속한 책의 파생물 출처 줄. 못 찾으면 `None`.

    ⚠ 책을 못 찾으면 **지어내지 않는다** — 없는 출처를 적는 것이 빈 줄보다 나쁘다.
    """
    r = conn.execute(
        "SELECT a.book_code, a.title, a.author, a.book_id FROM sys_book_unit u"
        "  JOIN sys_book_asset a ON a.book_id = u.book_id"
        " WHERE u.unit_id=?", (unit_id,)).fetchone()
    if not r:
        return None
    code, title, author, book_id = r
    # ★★ 317차-5 — **한 책·한 언어 안에서는 이미 쓰고 있는 끝줄을 따른다.**
    #   손 번역(스펄전 731편)과 AI 적재분이 다른 꼴을 쓰면 한 책이 두 꼴로 갈린다(실측 마이어·스펄전).
    dom = dominant_line(conn, book_id, variant, lang, exclude_unit=unit_id)
    if dom:
        # ★ 2026-10-11 — 따라 쓰는 끝줄에 옛 한국어 「번역」이 박혀 있으면 그 언어 낱말로
        #   (안 고치면 옛 흠이 「가장 많이 쓰는 줄」이 되어 스스로 되살아난다)
        if (lang or '').upper() != 'KO' and ' 번역. ' in dom:
            dom = dom.replace(' 번역. ', ' %s. ' % trans_word(lang))
        return dom
    lt = conn.execute("SELECT title, author FROM sys_book_asset_text WHERE book_id=? AND UPPER(lang_code)=?",
                      (book_id, (lang or '').upper())).fetchone()
    if (variant or '').upper() == 'MODERN_EN' or not lt:
        lt = (None, None)
    return line_for_derived(variant, lang, author, title, EDITIONS.get(code, ''),
                            local_title=lt[0], local_author=lt[1])


def dominant_line(conn, book_id, variant, lang, exclude_unit=None):
    """그 책·변형·언어 본문들이 가장 많이 쓰는 끝줄(「—」 로 시작) — 없으면 빈 글."""
    import collections
    cnt = collections.Counter()
    for uid, body in conn.execute(
            "SELECT t.unit_id, t.body_text FROM sys_book_unit_text t JOIN sys_book_unit u ON u.unit_id=t.unit_id"
            " WHERE u.book_id=? AND t.text_variant=? AND UPPER(t.lang_code)=?",
            (book_id, (variant or '').upper(), (lang or '').upper())):
        if uid == exclude_unit:
            continue
        last = (body or '').rstrip().split('\n')[-1].strip()
        if last.startswith('—'):
            cnt[last] += 1
    return cnt.most_common(1)[0][0] if cnt else ''


def strip_attrib(body):
    """이미 붙은 출처 줄을 뗀다 — 멱등의 열쇠."""
    lines = (body or '').rstrip().split('\n')
    while lines and (not lines[-1].strip()
                     or lines[-1].strip().startswith('—')):
        if lines[-1].strip().startswith('—'):
            lines.pop()
            break
        lines.pop()
    return '\n'.join(lines).rstrip()


def compose(body, attrib):
    return strip_attrib(body) + '\n\n' + attrib


def check_line(code, author, title, ed):
    bad = []
    if not ed:
        bad.append('%s 판본이 없다 (EDITIONS 에 넣을 것)' % code)
        return bad
    s = line_for(author, title, ed)
    # ★ 철자 규칙이 아니라 **행동**으로 잰다 — 검증기가 이 줄을 저자의 문장으로
    #   세면 안 된다. (옛 규칙은 `E. B. Pusey` 같은 정상 번역자 이름을 막았다.
    #   고칠 자리는 이름이 아니라 `db_book_verify.sentences` 였다.)
    import db_book_verify as _V
    if any('Public domain' in x for x in _V.sentences('Body sentence here.\n\n'
                                                      + s)):
        bad.append('%s 출처 줄을 검증기가 문장으로 센다: %r' % (code, s[:60]))
    if len(s) > 190:
        bad.append('%s 출처 줄이 %d자 (너무 길다)' % (code, len(s)))
    if '\n' in s:
        bad.append('%s 출처 줄에 개행' % code)
    return bad


def survey(conn):
    """→ [(code, 전체, 출처줄 있는 편, 지금 줄)]"""
    out = []
    for code, in conn.execute("""SELECT book_code FROM sys_book_asset
             WHERE COALESCE(record_status,'LIVE')='LIVE' ORDER BY book_code"""):
        rows = conn.execute("""
            SELECT x.body_text FROM sys_book_unit u
              JOIN sys_book_asset b ON b.book_id=u.book_id
              JOIN sys_book_unit_text x ON x.unit_id=u.unit_id
             WHERE b.book_code=? AND x.text_variant='ORIGINAL'""",
                            (code,)).fetchall()
        if not rows:
            continue
        have, samp = 0, ''
        for (b,) in rows:
            ls = [l.strip() for l in (b or '').strip().splitlines() if l.strip()]
            if ls and ls[-1].startswith('—'):
                have += 1
                samp = samp or ls[-1]
        out.append((code, len(rows), have, samp))
    return out


def apply(conn, codes=None, dry=False):
    conn.execute("CREATE TABLE IF NOT EXISTS %s ("
                 " text_id INTEGER PRIMARY KEY, book_code TEXT,"
                 " body_text TEXT)" % BACKUP)
    n_book = n_unit = 0
    rows = conn.execute("""
        SELECT b.book_code,
               COALESCE(t.title,  b.title),
               COALESCE(t.author, b.author),
               x.text_id, x.body_text
          FROM sys_book_unit u
          JOIN sys_book_asset b ON b.book_id=u.book_id
          JOIN sys_book_unit_text x ON x.unit_id=u.unit_id
          LEFT JOIN sys_book_asset_text t
                 ON t.book_id=b.book_id AND UPPER(t.lang_code)='EN'
                AND COALESCE(t.record_status,'LIVE')='LIVE'
         WHERE x.text_variant='ORIGINAL'
           AND COALESCE(b.record_status,'LIVE')='LIVE'
         ORDER BY b.book_code, u.sequence""").fetchall()
    seen = set()
    for code, title, author, tid, body in rows:
        if codes and code not in codes:
            continue
        ed = EDITIONS.get(code)
        if not ed:
            continue
        want = line_for(author, title, ed)
        new = compose(body, want)
        if new == (body or '').rstrip():
            continue
        n_unit += 1
        if code not in seen:
            seen.add(code)
            n_book += 1
        if dry:
            continue
        if not conn.execute("SELECT 1 FROM %s WHERE text_id=?" % BACKUP,
                            (tid,)).fetchone():
            conn.execute("INSERT INTO %s VALUES (?,?,?)" % BACKUP,
                         (tid, code, body))
        conn.execute("UPDATE sys_book_unit_text SET body_text=? "
                     " WHERE text_id=?", (new, tid))
    return n_book, n_unit


def _selftest():
    fails = []

    def ck(n, ok, got=''):
        print(('  OK  ' if ok else '  FAIL') + ' ' + n +
              ('  | ' + str(got) if got != '' else ''))
        if not ok:
            fails.append(n)

    s = line_for('John Bunyan', 'Grace Abounding',
                 'Religious Tract Society, 1905')
    ck('모양', s == '— John Bunyan, "Grace Abounding" '
       '(Religious Tract Society, 1905). Public domain.', s)

    body = 'First line.\nSecond line.'
    once = compose(body, s)
    ck('붙인다', once.endswith(s) and once.startswith('First line.'))
    ck('본문과 한 줄 띄운다', '\n\n' + s in once)
    ck('두 번 붙여도 하나', compose(once, s) == once)
    ck('옛 줄을 갈아 끼운다',
       compose(compose(body, '— old attribution'), s) == once)
    ck('본문은 안 지운다', strip_attrib(once) == body)
    # ⚠ 본문 마지막 줄이 대시로 시작하면 안 된다 — 그런 책이 있나 확인용
    ck('본문 속 대시 줄은 한 개만 뗀다',
       strip_attrib('a\n— quoted line\n\n' + s) == 'a\n— quoted line')

    # 게이트
    ck('판본이 없으면 걸린다',
       any('판본이 없다' in m for m in check_line('X', 'A', 'B', '')))
    ck('약자가 든 번역자 이름도 통과',
       check_line('X', 'Augustine', 'Confessions', 'tr. E. B. Pusey') == [],
       check_line('X', 'Augustine', 'Confessions', 'tr. E. B. Pusey'))
    ck('판본 표기도 통과', check_line('X', 'A', 'B', 'Revell, 1895') == [])
    # ★ 검증기가 출처 줄을 저자의 문장으로 세지 않는가 (이것이 진짜 기준)
    import db_book_verify as V
    sample = ('This is a real sentence from the author that is long enough '
              'to count as one.\n\n'
              + line_for('Augustine', 'Confessions', 'tr. E. B. Pusey'))
    ss = V.sentences(sample)
    ck('검증기가 출처 줄을 뺀다',
       not any('Public domain' in x for x in ss), ss[-1][:60] if ss else '(0)')
    ck('본문 문장은 남긴다', any('real sentence' in x for x in ss))

    conn = appdb.connect(DB)
    codes = {r[0] for r in conn.execute(
        "SELECT book_code FROM sys_book_asset "
        " WHERE COALESCE(record_status,'LIVE')='LIVE'")}
    miss = sorted(codes - set(EDITIONS))
    ck('35권 판본이 다 있다', not miss, miss)
    extra = sorted(set(EDITIONS) - codes)
    ck('없는 책이 표에 없다', not extra, extra)
    # ★ 영어 본문에는 **영어 제목·저자**를 쓴다 — 사도교부 다섯 권은 기본 칸이
    #   한국어라 그대로 쓰면 영문 본문 끝에 한국어가 붙는다(실측).
    kr = [c for c, t, a in conn.execute(
        """SELECT b.book_code, COALESCE(t.title, b.title),
                  COALESCE(t.author, b.author)
             FROM sys_book_asset b
             LEFT JOIN sys_book_asset_text t
                    ON t.book_id=b.book_id AND UPPER(t.lang_code)='EN'
                   AND COALESCE(t.record_status,'LIVE')='LIVE'
            WHERE COALESCE(b.record_status,'LIVE')='LIVE'""")
        if any('가' <= ch <= '힣' for ch in (t or '') + (a or ''))]
    ck('출처 줄에 한국어가 안 섞인다', not kr, kr)

    bad = []
    for code, title, author in conn.execute(
            """SELECT b.book_code, COALESCE(t.title, b.title),
                      COALESCE(t.author, b.author)
                 FROM sys_book_asset b
                 LEFT JOIN sys_book_asset_text t
                        ON t.book_id=b.book_id AND UPPER(t.lang_code)='EN'
                       AND COALESCE(t.record_status,'LIVE')='LIVE'
                WHERE COALESCE(b.record_status,'LIVE')='LIVE'"""):
        bad += check_line(code, author, title, EDITIONS.get(code))
    ck('출처 줄 게이트 전권 통과', not bad, bad[:4])

    # ★★★ 파생물 출처 줄 — **한 꼴로 못 박히는가** (1.txt 16-2 ⓐ)
    d1 = line_for_derived('TRANSLATED', 'KO', 'Andrew Murray',
                          'Abide in Christ', 'Revell, 1895')
    d2 = line_for_derived('TRANSLATED', 'KO', ' Andrew  Murray ',
                          'Abide in Christ', 'Revell, 1895')
    ck('★★★ 같은 책이면 늘 같은 줄', d1 == d2, (d1, d2))
    ck('★ 번역임을 밝힌다', '번역' in d1 and d1.startswith('—'), d1)
    _d3 = line_for_derived('TRANSLATED', 'JA', 'Andrew Murray', 'Abide in Christ', 'Revell, 1895')
    ck('★ 번역이라는 낱말도 그 언어로(한글 없음)', '訳' in _d3 and '번역' not in _d3, _d3)
    ck('★ 현대영어는 기존 꼴 그대로',
       line_for_derived('MODERN_EN', 'EN', 'A', 'B', 'C')
       == '— Modern English adaptation · A, B (C)')
    try:
        line_for_derived('ORIGINAL', 'EN', 'A', 'B', 'C')
        ck('★★ 원문에는 안 쓴다', False)
    except ValueError:
        ck('★★ 원문에는 안 쓴다', True)
    ck('★ 게이트가 돈다', check_derived('X', 'TRANSLATED', 'KO', 'A', 'B', 'C')
       == [], check_derived('X', 'TRANSLATED', 'KO', 'A', 'B', 'C'))
    ck('★★ 원문 변형을 게이트가 잡는다',
       bool(check_derived('X', 'ORIGINAL', 'KO', 'A', 'B', 'C')))
    # ★ 붙였다 떼면 원래대로 (멱등)
    body = '본문입니다.\n둘째 줄입니다.'
    once = compose(body, d1)
    ck('★★ 붙였다 떼면 원래대로', strip_attrib(once) == body,
       repr(strip_attrib(once))[:60])
    ck('★★ 두 번 붙여도 한 줄', compose(once, d1) == once)

    before = conn.execute("SELECT SUM(LENGTH(body_text)) "
                          "  FROM sys_book_unit_text").fetchone()[0]
    conn.execute('BEGIN')
    apply(conn, {'MULLER_ATP'})
    conn.rollback()
    after = conn.execute("SELECT SUM(LENGTH(body_text)) "
                         "  FROM sys_book_unit_text").fetchone()[0]
    ck('되돌리면 그대로', before == after, '%s → %s' % (before, after))
    conn.close()
    print('\n=== %s (%d fail) ===' %
          ('PASS' if not fails else 'FAIL: ' + ', '.join(fails), len(fails)))
    return 0 if not fails else 1


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        raise SystemExit(_selftest())
    conn = appdb.connect(DB)
    if '--check' in a:
        n_book, n_unit = apply(conn, dry=True)
        print('%-18s %5s %6s  %s' % ('code', '편', '출처줄', '지금 줄'))
        for code, tot, have, samp in survey(conn):
            mark = '  ' if have == tot else '✗ '
            print('%s%-18s %5d %5d개  %s' % (mark, code, tot, have,
                                             (samp or '(없음)')[:72]))
        print()
        print('고칠 편 %d (책 %d권)' % (n_unit, n_book))
        conn.close()
        return
    if '--apply' in a:
        codes = [x for x in a[a.index('--apply') + 1:] if not x.startswith('-')]
        bad = []
        for code, title, author in conn.execute(
                "SELECT book_code, title, author FROM sys_book_asset "
                " WHERE COALESCE(record_status,'LIVE')='LIVE'"):
            if codes and code not in codes:
                continue
            bad += check_line(code, author, title, EDITIONS.get(code))
        if bad:
            for m in bad:
                print('  ✗ ' + m)
            raise SystemExit('게이트에 걸렸다 — 붙이지 않는다.')
        conn.execute('BEGIN')
        n_book, n_unit = apply(conn, set(codes) if codes else None)
        conn.commit()
        print('%d권 %d편에 출처 줄을 맞췄다 (백업 %s)' % (n_book, n_unit, BACKUP))
        conn.close()
        return
    conn.close()
    print(__doc__)


if __name__ == '__main__':
    main()
