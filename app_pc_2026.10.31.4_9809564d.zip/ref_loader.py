"""Generic catechism/reference loader — reads JSON data file, inserts into sys_ref_* tables.

JSON format:
{
  "src_code": "LUTHER_SC",
  "units": [
    {
      "code": "LSC_CMD1",
      "seq": 1,
      "type": "QA",
      "label": "First Commandment",
      "header": "You shall have no other gods.",   // optional — prepended to body_text
      "question": "What does this mean?",          // optional
      "answer": "We should fear, love...",
      "links": [
        {"sb": 5, "sc": 6, "sv": 5},              // single verse (eb/ec/ev omitted)
        {"sb": 40, "sc": 5, "sv": 21, "eb": 40, "ec": 5, "ev": 22}  // range
      ]
    }
  ]
}

Usage: python ref_loader.py <data_file.json>
"""
import sqlite3, json, sys
import appdb

DB = "bible_master.db"

def get_vid(cur, bcode, ch, vs):
    if bcode is None:
        return None
    cur.execute(
        "SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?",
        (bcode, ch, vs)
    )
    r = cur.fetchone()
    return r[0] if r else None

def build_body_text(u):
    parts = []
    if u.get("header"):
        parts.append(u["header"])
    if u.get("question"):
        parts.append(u["question"])
    if u.get("answer"):
        parts.append(u["answer"])
    return "\n\n".join(parts)

def main(data_file):
    with open(data_file, encoding="utf-8") as f:
        data = json.load(f)

    src_code = data["src_code"]
    units = data["units"]
    if not units:
        print("No units in data file"); return

    conn = appdb.connect(DB)
    cur = conn.cursor()

    cur.execute("SELECT ref_src_id FROM sys_ref_source WHERE src_code=?", (src_code,))
    row = cur.fetchone()
    if not row:
        print(f"Source '{src_code}' not found in sys_ref_source"); conn.close(); sys.exit(1)
    src_id = row[0]

    # idempotency — check first unit code
    first_code = units[0]["code"]
    cur.execute(
        "SELECT ref_unit_id FROM sys_ref_unit WHERE unit_code=? AND ref_src_id=?",
        (first_code, src_id)
    )
    if cur.fetchone():
        print(f"Already inserted (first unit '{first_code}' exists)"); conn.close(); sys.exit(0)

    units_n = texts_n = links_n = missed = 0

    for u in units:
        cur.execute("""
            INSERT INTO sys_ref_unit
              (ref_src_id, unit_code, unit_type, unit_label,
               unit_question, unit_answer, sequence, record_status)
            VALUES (?,?,?,?,?,?,?,'LIVE')
        """, (
            src_id, u["code"], u["type"], u["label"],
            u.get("question"), u.get("answer"), u["seq"]
        ))
        uid = cur.lastrowid
        units_n += 1

        cur.execute("""
            INSERT INTO sys_ref_text (ref_unit_id, text_variant, lang_code, body_text, record_status)
            VALUES (?,'ORIGINAL','EN',?,'LIVE')
        """, (uid, build_body_text(u)))
        texts_n += 1

        for so, lnk in enumerate(u.get("links", []), 1):
            svid = get_vid(cur, lnk.get("sb"), lnk.get("sc"), lnk.get("sv"))
            if svid is None:
                missed += 1; continue
            evid = get_vid(cur, lnk.get("eb"), lnk.get("ec"), lnk.get("ev")) \
                   if lnk.get("eb") else None
            cur.execute("""
                INSERT OR IGNORE INTO sys_link_asset
                  (link_type, clicked_id, target_id, end_id, rel_code,
                   sort_order, record_status)
                VALUES ('REFU_VERS',?,?,?,'PROOF_TEXT',?,'LIVE')
            """, (uid, svid, evid, so))
            links_n += 1

    conn.commit()
    conn.close()
    print(f"Done - units={units_n}  texts={texts_n}  links={links_n}  missed={missed}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python ref_loader.py <data_file.json>")
        sys.exit(1)
    main(sys.argv[1])
