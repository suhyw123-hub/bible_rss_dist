# -*- coding: utf-8 -*-
"""맛보기를 **규칙으로** 만든다 — 관리자가 선택하지 않는다 (1.txt 16-3).

★★★ **왜 바꿨나** (2026-09-25 사용자 확정):
  「**현재 방식으로는 맛보기 자산을 관리자가 설정하는 방식을 포기**해야 한다.
   네가 분석해서 **맛보기를 정형화**하는 방식으로 진행하자.」
  옛 방식은 **자산 하나를 통째로** 골랐다(GILL 주석 전체 29.7 MB · 천로역정).
  그러면 ⓐ 코어팩이 부풀고 ⓑ 같은 자료가 개별 팩과 **두 벌**이 되고
  ⓒ 고른 것이 **한 언어**라 나머지 열 언어는 못 읽는 글을 받는다.

★★★ **새 규칙 — 「모든 자산을 조금씩, 모든 사용자에게」**(사용자 지시 그대로):
  「모든 자산을 **모든 언어로 조금씩 일괄 배포**해서 맛보게 하고 추가 팩
   다운로드는 자기 언어로 받도록 한다.」

  | 갈래 | 끊는 자리 | 상한 |
  |---|---|---|
  | 성경 좌표를 가진 것 | **맛보기 구간**(`WINDOW`) | 구간이 곧 상한 |
  | 도서·설교 | **첫 편의 앞부분** | **A4 한 장**(`UNIT_CHARS`) |
  | 사전·자료집 | 표제어 앞에서부터 | 종당 `DICT_BYTES` |
  | 사진 | 유형별 대표 한 장 | 나머지는 썸네일 |

★★★ **구간에 걸린 것은 남김없이**(2026-09-25 사용자 「이 개념을 확장하자 —
  맛보기 성경좌표에 연결된 **모든 자산**을 맛보기로 제공한다. 주석, 용어,
  원어, 연구자료, 영상주소 등」). 한 구절을 열었을 때 **그 절이 가진 것이 다
  보여야** 앱이 무엇을 하는 물건인지 안다. 자산마다 다른 데를 보이면 맛보기가
  아니라 조각 모음이다.

⚠⚠⚠ **새로 들어오는 도서·설교도 저절로 따라온다** — 그것이 정형화의 값이다
  (사용자 「앞으로 추가하는 도서/설교 등의 자산도 모두 이 규칙을 따라야 한다」).
  적재 도구는 맛보기를 **만들 필요가 없다**. 여기서 규칙으로 뽑는다.

⚠ **글 중간에서 안 자른다** — 문단 경계에서만(`_cut`). 자른 자리에는
  **표식 한 줄**(`TASTE_MARK`)을 남겨 화면이 「여기까지입니다」를 말하게 한다.
  표식이 없으면 사용자는 **글이 그렇게 끝난 줄** 안다(§0-1).

    python db_pack_taste.py --selftest    (의무)
    python db_pack_taste.py --plan        무엇이 얼마나 실리나
"""
import io
import re as _re
import sys

# ── 맛보기 구간 — (bcode, 시작 장, 끝 장) ─────────────────────────────
#   ★ 창 1~3 = 창조·타락. **모든 주석이 가장 두껍게** 다루는 자리.
#     마 5~7 = 산상수훈. 신약의 대표이고 누구나 안다.
#   ⚠ **책 통째는 못 담는다** — 창세기+마태만으로 27.5 MB(실측).
#     **한 장씩은 맛이 안 난다** — 0.86 MB.
WINDOW = ((1, 1, 3), (40, 5, 7))

UNIT_CHARS = 1800     # 도서·설교 한 편의 맛보기 — **A4 한 장**(사용자 지시)
DICT_BYTES = 65536    # 사전·자료집 한 종
MIN_UNITS = 1         # 아무것도 없으면 맛보기가 아니다 — 최소 하나

# 잘린 자리 표식 — 화면이 이것을 보고 「받으러 가기」를 낸다
TASTE_MARK = '⟨맛보기 여기까지⟩'


def window_where(alias='b'):
    """`bible_index` 에 거는 조건문 — 구간을 **한 곳에서** 만든다."""
    return ' OR '.join(
        '(%s.bcode=%d AND %s.chapter BETWEEN %d AND %d)' % (alias, bc, alias,
                                                            c1, c2)
        for bc, c1, c2 in WINDOW)


def window_vids(conn):
    """구간의 `verse_id` 목록 — 차례대로."""
    return [r[0] for r in conn.execute(
        'SELECT verse_id FROM bible_index b WHERE %s ORDER BY sort_order'
        % window_where())]


def window_label(conn):
    """사람이 읽는 구간 이름 — 「창세기 1~3장 · 마태복음 5~7장」."""
    try:
        nm = {bc: fn for bc, fn in conn.execute(
            "SELECT book_code, COALESCE(NULLIF(TRIM(full_name),''),"
            " short_name) FROM book_names WHERE UPPER(lang_code)='KO'")}
    except Exception:                                     # noqa: BLE001
        nm = {}
    out = []
    for bc, c1, c2 in WINDOW:
        b = nm.get(bc, str(bc))
        out.append('%s %d장' % (b, c1) if c1 == c2
                   else '%s %d~%d장' % (b, c1, c2))
    return ' · '.join(out)


def _cut(text, cap=UNIT_CHARS):
    """앞에서 `cap` 자까지 — **문단 경계에서만** 끊는다.

    ⚠ 글 중간에서 자르면 문장이 토막 난다. 문단이 없으면 문장 끝(`.`·`다.`)을
      찾고, 그것도 없으면 통째로 둔다(**억지로 안 자른다**).
    ⚠ 자른 때만 표식을 붙인다 — 안 자른 글에 붙이면 거짓말이다.
    """
    t = (text or '').rstrip()
    if len(t) <= cap:
        return t, False
    head = t[:cap]
    for sep in ('\n\n', '\n'):
        i = head.rfind(sep)
        if i > cap * 0.4:                 # 너무 앞에서 끊기지 않게
            return t[:i].rstrip() + '\n\n' + TASTE_MARK, True
    i = max(head.rfind('. '), head.rfind('다.'), head.rfind('! '),
            head.rfind('? '))
    if i > cap * 0.4:
        return t[:i + 1].rstrip() + '\n\n' + TASTE_MARK, True
    return head.rstrip() + '\n\n' + TASTE_MARK, True


def book_taste(conn, book_id, lang=None, variant=None):
    """그 책의 맛보기 — `[(unit_id, lang, variant, 글, 잘렸나)]`.

    ★ **첫 편의 앞 A4 한 장**(사용자 지시). 편이 짧으면 통째로 간다.
    ⚠ 있는 언어·변형을 **다 담는다** — 「모든 언어로 조금씩」이 이 설계의 뜻이다.
    """
    # ★★★ **자리는 `_first_of` 한 문**이 고른다(앞장 건너뛰기 포함) —
    #   여기서 제 SQL 로 또 고르면 **AI 작업대는 2번 편을 옮기는데 팩은
    #   1번 편(판권장)을 싣는다**(이 파일 머리글이 경고한 그 자리).
    _got = _first_of(conn, book_id)
    r = [(_got[0],)] if _got else []
    out = []
    for (uid,) in r:
        q = ("SELECT unit_id, lang_code, text_variant, body_text "
             "FROM sys_book_unit_text WHERE unit_id=?"
             "  AND COALESCE(record_status,'LIVE')='LIVE'"
             "  AND TRIM(COALESCE(body_text,''))<>''")
        ar = [uid]
        if lang:
            q += " AND UPPER(lang_code)=?"
            ar.append(lang.upper())
        if variant:
            q += " AND text_variant=?"
            ar.append(variant)
        for u, lg, va, body in conn.execute(q, ar):
            t, cut = _cut(body)
            out.append((u, lg, va, t, cut))
        # ★★★ **원문에 없는 언어는 조각 번역이 채운다**(2026-09-25) — 실측
        #   40권 중 31권이 첫 편에 영어뿐이라 한국어 사용자가 영어를 받았다.
        #   ⚠ 그 언어에 **진짜 본문이 이미 있으면 건드리지 않는다** — 진짜가
        #     언제나 이긴다(잘린 글이 온전한 글을 덮으면 안 된다).
        got = set((u, (l or '').upper()) for u, l, _v, _t, _c in out)
        for _u, lg2, body2 in taste_rows(conn, uid):
            if (uid, lg2) in got:
                continue
            if lang and lg2 != lang.upper():
                continue
            if variant and variant != TASTE_VARIANT:
                continue
            out.append((uid, lg2, TASTE_VARIANT, body2,
                        TASTE_MARK in (body2 or '')))
    return out


# ══════════════════════════════════════════════════════════════════
#  맛보기 조각의 번역 — `sys_book_taste`
# ══════════════════════════════════════════════════════════════════

TASTE_TABLE = 'sys_book_taste'
TASTE_VARIANT = 'TRANSLATED'   # 사용자 앱에 실릴 때의 변형
# ⚠ 원문 조각을 어느 변형에서 뽑나 — **현대영어를 먼저** 본다. 17세기 영어를
#   그대로 옮기게 하면 옮기는 사람이 원문 해독부터 해야 한다(`booktrans.md`).
SRC_VARIANTS = ('MODERN_EN', 'ORIGINAL')
_SYNTH_BASE = -100000          # 음수 열쇠 자리 — 진짜 `text_id` 와 안 겹친다


def ensure(conn):
    """`sys_book_taste` 를 세운다 — 멱등.

    ⚠ **`sys_book_unit_text` 에 안 넣는 까닭**은 이 파일 머리글에 있다.
    """
    conn.execute(
        "CREATE TABLE IF NOT EXISTS sys_book_taste ("
        " unit_id INTEGER NOT NULL,"
        " lang_code TEXT NOT NULL,"
        " body_text TEXT,"
        " record_status TEXT NOT NULL DEFAULT 'LIVE',"
        " updated_at TEXT,"
        " PRIMARY KEY(unit_id, lang_code))")
    return True


#: **앞장 표식** — 본문 첫머리에 이것이 있으면 저자의 글이 아니다.
#: ⚠ 좁게 잡는다 — 헛걸리면 **진짜 첫 편을 건너뛴다**.
FRONT_BODY = (
    'project gutenberg ebook',        # 구텐베르크 파일 머리말
    'this ebook is for the use of',
    'release date:',
    'all rights reserved',            # 판권장
    'printed in the united states',
)
#: 제목이 **판권 번호**이거나 **쪽 번호로 시작**하면 앞장이다
FRONT_LABEL = _re.compile(r'\bISBN\b|^\s*\d{2,4}\s+[A-Z]{3,}')
#: ⚠ 이만큼만 건너뛴다 — 더 이어지면 그 책은 사람이 봐야 한다
FRONT_MAX = 4


#: 속표지 판정 상한 — 이보다 길면 짧아도 본문으로 본다
FRONT_BARE = 240
#: 문장이 끝나는 자리(속표지에는 없다)
_SENT_RE = _re.compile(r'[.!?\u3002\uff1f\uff01]')


def _words(s):
    return [w for w in _re.split(r'[^0-9A-Za-z\uac00-\ud7a3]+',
                                 (s or '').lower()) if w]


def _is_bare_head(label, body):
    """**속표지 한 편**인가 — 제 이름만 한 번 더 적어 놓았는가.

    잣대 셋을 **함께** 건다:
      ⓐ 짧다(출처 줄을 뺀 본문이 `FRONT_BARE` 아래)
      ⓑ 문장이 하나도 없다(속표지에는 마침표가 없다)
      ⓒ **그 글이 제 제목 안에 거의 다 들어 있다**
    ⚠ ⓐⓑ 만으로는 진짜 본문의 첫 줄까지 앞장으로 본다(하네스가 잡았다).
    """
    t = (body or '')
    try:
        import db_book_attrib as _BA          # 출처 줄은 우리가 붙인 것이다
        t = _BA.strip_attrib(t)
    except Exception:                                     # noqa: BLE001
        pass
    t = (t or '').strip()
    if not t or len(t) > FRONT_BARE or _SENT_RE.search(t):
        return False
    bw = _words(t)
    if not bw:
        return False
    lw = set(_words(label))
    if not lw:
        return False
    return sum(1 for w in bw if w in lw) >= len(bw) * 0.75


def is_front_matter(label, body):
    """그 편이 **앞장**(판권장·파일 머리말·속표지)인가 — 본문이 아닌가."""
    lab = (label or '').strip()
    if FRONT_LABEL.search(lab):
        return True
    head = (body or '')[:400].lower()
    if any(m in head for m in FRONT_BODY):
        return True
    # ★★★ 「제1권」처럼 **이름만 있는 편**(2026-09-25 실측 — 켐피스)
    return _is_bare_head(lab, body)


def _book_units(conn, bid, limit=None):
    return conn.execute(
        "SELECT unit_id, COALESCE(unit_label,'') FROM sys_book_unit "
        "WHERE book_id=? AND COALESCE(record_status,'LIVE')='LIVE' "
        "ORDER BY sequence, unit_id" + (" LIMIT %d" % limit if limit else ""),
        (bid,)).fetchall()


def _raw_body(conn, unit_id):
    """그 편의 원문 — 조각을 안 자른 통글(앞장 판정에 쓴다)."""
    for va in SRC_VARIANTS:
        r = conn.execute(
            "SELECT body_text FROM sys_book_unit_text "
            "WHERE unit_id=? AND text_variant=?"
            "  AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
            (unit_id, va)).fetchone()
        if r and (r[0] or '').strip():
            return r[0]
    return ''


def _first_of(conn, bid):
    """그 책의 **맛보기 자리** — `(unit_id, 이름, 건너뛴 수)`.

    ⚠ **다 앞장이면 첫 편으로 되돌아간다** — 자리를 잃으면 그 책이
      맛보기에서 통째로 사라진다(§0-1).
    """
    rows = _book_units(conn, bid, FRONT_MAX + 1)
    if not rows:
        return None
    for i, (uid, lab) in enumerate(rows[:FRONT_MAX]):
        if not is_front_matter(lab, _raw_body(conn, uid)):
            return uid, lab, i
    return rows[0][0], rows[0][1], 0


def first_units(conn):
    """**맛보기 조각의 자리** — `[(unit_id, book_id, 코드, 편 이름)]`.

    ★ 자리를 정하는 문이 하나다 — 맛보기(`book_taste`)도 AI 작업대도 이것을
      쓴다. 두 곳에서 고르면 「옮긴 편과 실리는 편이 다르다」가 난다.
    ★★★ **앞장은 건너뛴다**(2026-09-25) — 첫 편이 판권장이면 사용자가
      맛보기로 **표지 뒷면**을 받는다. 무엇을 건너뛰었는지는
      `front_skips()` 가 말한다(조용히 건너뛰지 않는다).
    """
    out = []
    for bid, code in conn.execute(
            "SELECT book_id, book_code FROM sys_book_asset "
            "WHERE COALESCE(record_status,'LIVE')='LIVE' ORDER BY book_id"):
        got = _first_of(conn, bid)
        if got:
            out.append((got[0], bid, code, got[1]))
    return out


def front_skips(conn):
    """**앞장을 건너뛴 책** — `[(코드, 건너뛴 수, 건너뛴 편 이름, 선택한 편)]`.

    ★ 조용히 건너뛰면 다음 사람이 「왜 2번 편이 맛보기지」를 처음부터 다시
      조사한다. 화면·CLI 가 이것을 적는다.
    """
    out = []
    for bid, code in conn.execute(
            "SELECT book_id, book_code FROM sys_book_asset "
            "WHERE COALESCE(record_status,'LIVE')='LIVE' ORDER BY book_id"):
        got = _first_of(conn, bid)
        if not got or not got[2]:
            continue
        rows = _book_units(conn, bid, got[2])
        out.append((code, got[2], ' / '.join((r[1] or '')[:28] for r in rows),
                    got[1]))
    return out


def src_excerpt(conn, unit_id):
    """옮길 **원문 조각** — `(언어, 글, 잘렸나)`. 없으면 `('', '', False)`.

    ⚠ 조각은 **저장하지 않는다** — 본문에서 그때 잘라 낸다. 본문을 다시
      적재하면 조각도 저절로 따라온다(두 벌이 되지 않는다).
    """
    for va in SRC_VARIANTS:
        r = conn.execute(
            "SELECT lang_code, body_text FROM sys_book_unit_text "
            "WHERE unit_id=? AND text_variant=?"
            "  AND COALESCE(record_status,'LIVE')='LIVE'"
            "  AND TRIM(COALESCE(body_text,''))<>'' LIMIT 1",
            (unit_id, va)).fetchone()
        if r:
            t, cut = _cut(r[1])
            return (r[0] or '').upper(), t, cut
    return '', '', False


def unit_langs(conn, unit_id):
    """그 편에 **진짜 본문이 있는 언어** — `{언어}`.

    ★ 원문만이 아니다 — 이미 옮겨 둔 번역본(9권)도 여기 든다. 그 언어는
      **조각을 따로 옮길 까닭이 없다**(진짜가 언제나 이긴다).
    """
    try:
        return set((r[0] or '').upper() for r in conn.execute(
            "SELECT DISTINCT lang_code FROM sys_book_unit_text WHERE unit_id=?"
            "  AND COALESCE(record_status,'LIVE')='LIVE'"
            "  AND TRIM(COALESCE(body_text,''))<>''", (unit_id,)))
    except Exception:                                     # noqa: BLE001
        return set()


def taste_text(conn, unit_id, lang):
    """그 언어의 맛보기 조각 — **진짜 본문이 있으면 그것을 잘라서**, 없으면
    담아 둔 조각 번역.

    ⚠⚠ 진짜 본문을 먼저 보는 것이 `book_taste` 의 「진짜가 이긴다」와 같은
      규칙이다 — 두 곳이 다르게 판정하면 **이미 옮긴 책을 또 옮기게 된다**
      (실측 9권이 그랬다).
    """
    lang = (lang or '').upper()
    r = conn.execute(
        "SELECT body_text FROM sys_book_unit_text WHERE unit_id=?"
        "  AND UPPER(lang_code)=? AND COALESCE(record_status,'LIVE')='LIVE'"
        "  AND TRIM(COALESCE(body_text,''))<>'' "
        "ORDER BY CASE text_variant WHEN 'MODERN_EN' THEN 0"
        "              WHEN 'TRANSLATED' THEN 1 WHEN 'ORIGINAL' THEN 2"
        "              ELSE 3 END LIMIT 1", (unit_id, lang)).fetchone()
    if r:
        return _cut(r[0])[0]
    try:
        r = conn.execute(
            "SELECT body_text FROM sys_book_taste WHERE unit_id=?"
            "  AND UPPER(lang_code)=? AND COALESCE(record_status,'LIVE')='LIVE'",
            (unit_id, lang)).fetchone()
    except Exception:                                     # noqa: BLE001
        return ''
    return (r[0] if r else '') or ''


def put_taste(conn, unit_id, lang, body):
    """조각 번역을 담는다 — 멱등. **상한을 넘으면 그 자리에서 자른다.**"""
    ensure(conn)
    t, _cut_ = _cut((body or '').replace(TASTE_MARK, '').rstrip())
    conn.execute(
        "INSERT OR REPLACE INTO sys_book_taste"
        "(unit_id, lang_code, body_text, record_status, updated_at) "
        "VALUES(?,?,?, 'LIVE', datetime('now','localtime'))",
        (unit_id, (lang or '').upper(), t))
    return t


def taste_rows(conn, unit_id=None):
    """담아 둔 조각 번역 — `[(unit_id, lang, 글)]`."""
    try:
        q = ("SELECT unit_id, UPPER(lang_code), body_text FROM sys_book_taste "
             "WHERE COALESCE(record_status,'LIVE')='LIVE'"
             "  AND TRIM(COALESCE(body_text,''))<>''")
        ar = []
        if unit_id is not None:
            q += " AND unit_id=?"
            ar.append(unit_id)
        return [(r[0], r[1], r[2]) for r in conn.execute(q, ar)]
    except Exception:                                     # noqa: BLE001
        return []


def _lang_ord(lang):
    """언어마다 **정해진 번호** — 음수 열쇠가 실행마다 안 흔들리게."""
    try:
        import lang_config
        ls = [c for c in lang_config.all_langs()]
    except Exception:                                     # noqa: BLE001
        ls = []
    lang = (lang or '').upper()
    if lang in ls:
        return ls.index(lang) + 1
    # ⚠ 모르는 언어도 **같은 번호**라야 한다 — 글자로 짓는다(지어내지 않는다)
    return 90 + (sum(ord(c) for c in lang) % 9)


def _synth_id(unit_id, lang):
    """조각 번역 행의 **음수 `text_id`** — 정해진 값(멱등)."""
    return _SYNTH_BASE - (int(unit_id) * 100 + _lang_ord(lang))


def dict_taste(conn, src_id, cap=DICT_BYTES):
    """그 자료집의 맛보기 — **표제어 앞에서부터** 상한까지.

    ★ 사용자가 말한 「알파벳 A」가 여기다. ⚠ 다만 **알파벳이 양을 정하지
      않는다** — A 로 시작하는 것이 35개든 3,500개든 **상한만큼만** 싣는다.
    """
    rows = conn.execute(
        "SELECT u.ref_unit_id, t.lang_code, t.body_text "
        "FROM sys_ref_unit u JOIN sys_ref_text t"
        "  ON t.ref_unit_id=u.ref_unit_id "
        "WHERE u.ref_src_id=? AND COALESCE(u.record_status,'LIVE')='LIVE' "
        "ORDER BY u.sequence, u.ref_unit_id", (src_id,)).fetchall()
    out, tot = [], 0
    seen = set()
    for uid, lg, body in rows:
        n = len(body or '')
        if tot + n > cap and len(seen) >= MIN_UNITS:
            break
        out.append((uid, lg, body))
        seen.add(uid)
        tot += n
    return out


# ★★★ **코어에 통째로 싣는 역본**(2026-09-25 사용자 확정) —
#   「BSB 성경버전을 **코어팩에 필수로 추가**하자. 추가로 다운로드 받는 것이
#    아니라 **코어에 포함**하라」.
#   ⚠⚠⚠ **왜 필요했나** — 본문이 맛보기 구간뿐이면 **구간에 걸린 절↔절 연결
#     943건 가운데 818건(87%)이 상대 절 본문이 없다**(실측). 창 1:1 → 요 1:1
#     을 눌러도 요한복음이 없어 빈다. **구절 연결은 이 앱의 핵심 기능인데
#     맛보기에서 그것이 87% 안 보였다.**
#   ✅ BSB 하나면 31,104절이 다 열린다 — 압축 전 3.2 MB · 팩 **1.29 MB**.
#   ⚠ 이것은 **맛보기가 아니라 필수**다. 그래서 구간을 안 자른다.
CORE_VERSIONS = ('BSB',)


def _dump(conn, table, sql, args=()):
    """`{cols, rows}` — 본문팩과 **같은 꼴**(받는 쪽 적재기를 안 고친다)."""
    cur = conn.execute(sql, args)
    cols = [d[0] for d in cur.description]
    return {'cols': cols, 'rows': [list(r) for r in cur.fetchall()]}


def taste_tables(conn):
    """맛보기 + 코어 역본을 **실제 행으로** → `{표: {cols, rows}}`.

    ★ `db_pack_core_pick.extra_tables` 와 **같은 꼴**이라 코어 빌드가 그대로
      받는다. ⚠ 같은 표가 여러 곳에서 나오면 행을 잇는다.
    ⚠⚠ **세는 쪽(`plan`)과 담는 쪽(여기)이 같은 규칙을 써야 한다** — 갈리면
      화면이 적은 크기와 실제로 나가는 것이 달라진다(§286차 ⑮-3 그 자리).
    """
    out = {}

    def put(tb, d):
        if not d or not d.get('rows'):
            return
        if tb in out and out[tb]['cols'] == d['cols']:
            out[tb]['rows'].extend(d['rows'])
        else:
            out[tb] = {'cols': d['cols'], 'rows': list(d['rows'])}

    vids = window_vids(conn)
    ph = ','.join('?' * len(vids)) or 'NULL'
    w = window_where()

    # ① **코어 역본 — 통째로**(맛보기가 아니다)
    for v in CORE_VERSIONS:
        put('bible_content', _dump(
            conn, 'bible_content',
            'SELECT * FROM bible_content WHERE version_code=?', (v,)))
    # ② 나머지 역본 — 구간만
    put('bible_content', _dump(
        conn, 'bible_content',
        'SELECT * FROM bible_content WHERE verse_id IN (%s)'
        '  AND version_code NOT IN (%s)'
        % (ph, ','.join('?' * len(CORE_VERSIONS))),
        vids + list(CORE_VERSIONS)))
    # ③ 구절 설명문 — 구간
    put('sys_text_asset', _dump(
        conn, 'sys_text_asset',
        "SELECT * FROM sys_text_asset WHERE clicked_id IN (%s)"
        "  AND text_type LIKE 'VERS%%'" % ph, vids))
    # ④ 주석 본문 — 구간(항목 좌표는 코어에 통째로 있다)
    put('sys_commentary_text', _dump(
        conn, 'sys_commentary_text',
        'SELECT x.* FROM sys_commentary_text x '
        'JOIN sys_commentary_entry e ON e.entry_id=x.entry_id '
        'JOIN bible_index b ON b.verse_id=e.start_vid WHERE %s' % w))
    # ⑤ 절↔원어 낱말 — 구간
    put('sys_verse_lemma', _dump(
        conn, 'sys_verse_lemma',
        'SELECT * FROM sys_verse_lemma WHERE verse_id IN (%s)' % ph, vids))
    # ⑥ 연구자료 본문 — 구간에 걸린 것만(본문은 팩이라 따로 실어야 한다)
    put('sys_ref_text', _dump(
        conn, 'sys_ref_text',
        "SELECT t.* FROM sys_ref_text t WHERE t.ref_unit_id IN ("
        " SELECT clicked_id FROM sys_link_asset"
        "  WHERE link_type='REFU_VERS' AND target_id IN (%s))" % ph, vids))

    # ⑦ 도서·설교 — 권마다 **첫 편의 앞 A4 한 장**
    rows = []
    cols = None
    for (bid,) in conn.execute(
            "SELECT book_id FROM sys_book_asset "
            "WHERE COALESCE(record_status,'LIVE')='LIVE'"):
        for uid, lg, va, body, _cut in book_taste(conn, bid):
            d = _dump(conn, 'sys_book_unit_text',
                      'SELECT * FROM sys_book_unit_text WHERE unit_id=?'
                      '  AND lang_code=? AND text_variant=? LIMIT 1',
                      (uid, lg, va))
            if not d['rows']:
                # ★ 조각 번역은 **원본 행이 없다** — 같은 칸으로 지어 담되
                #   열쇠는 **음수**라 진짜 행과 안 부딪히고 값이 정해져 있어
                #   코어팩을 다시 받아도 덮어쓸 뿐 늘지 않는다.
                if not any(x[0] == uid and x[1] == lg for x in taste_rows(conn, uid)):
                    continue
                cols = cols or [c[1] for c in conn.execute(
                    'PRAGMA table_info(sys_book_unit_text)')]
                one = dict(text_id=_synth_id(uid, lg), unit_id=uid,
                           text_variant=va, lang_code=lg, body_text=body,
                           record_status='LIVE')
                rows.append([one.get(c) for c in cols])
                continue
            cols = cols or d['cols']
            r = list(d['rows'][0])
            # ⚠ **자른 글로 바꿔 담는다** — 원본 행을 그대로 담으면 A4 한 장
            #   규칙이 무너진다(스펄전 한 편이 26,275자다).
            try:
                r[cols.index('body_text')] = body
            except ValueError:                            # noqa: PERF203
                pass
            rows.append(r)
    if rows:
        put('sys_book_unit_text', {'cols': cols, 'rows': rows})

    # ⑧ 사전·자료집 — 앞에서부터 상한까지
    drows, dcols = [], None
    for (sid,) in conn.execute(
            "SELECT ref_src_id FROM sys_ref_source "
            "WHERE COALESCE(record_status,'LIVE')='LIVE'"):
        ids = sorted(set(u for u, _l, _b in dict_taste(conn, sid)))
        if not ids:
            continue
        d = _dump(conn, 'sys_ref_text',
                  'SELECT * FROM sys_ref_text WHERE ref_unit_id IN (%s)'
                  % ','.join('?' * len(ids)), ids)
        if d['rows']:
            dcols = dcols or d['cols']
            if d['cols'] == dcols:
                drows.extend(d['rows'])
    if drows:
        put('sys_ref_text', {'cols': dcols, 'rows': drows})
    return out


def plan(conn):
    """무엇이 얼마나 실리나 — `[(갈래, 설명, 조각 수, 바이트)]`.

    ⚠ **세는 쪽과 담는 쪽을 가르지 않는다** — 담을 때도 이 문이 고른 것을
      쓴다. 두 곳에서 세면 어느 것도 못 믿는다(§286차 ⑮-3 그 자리).
    """
    w = window_where()
    vids = window_vids(conn)
    ph = ','.join('?' * len(vids)) or 'NULL'
    out = []

    def add(kind, desc, sql, args=()):
        try:
            n, b = conn.execute(sql, args).fetchone()
        except Exception as e:                            # noqa: BLE001
            out.append((kind, desc + ' (못 셌다: %s)' % e, 0, 0))
            return
        out.append((kind, desc, int(n or 0), int(b or 0)))

    # ★ **코어 역본은 통째로** — 맛보기가 아니라 필수다(사용자 확정)
    add('BIBLE*', '성경 본문 %s — **전권**(코어 필수)'
        % ' · '.join(CORE_VERSIONS),
        'SELECT COUNT(*), SUM(LENGTH(verse_text)) FROM bible_content '
        'WHERE version_code IN (%s)' % ','.join('?' * len(CORE_VERSIONS)),
        list(CORE_VERSIONS))
    add('BIBLE', '그 밖 역본 — 구간',
        'SELECT COUNT(*), SUM(LENGTH(verse_text)) FROM bible_content '
        'WHERE verse_id IN (%s) AND version_code NOT IN (%s)'
        % (ph, ','.join('?' * len(CORE_VERSIONS))),
        vids + list(CORE_VERSIONS))
    add('DESC', '구절 설명문 — 구간',
        "SELECT COUNT(*), SUM(LENGTH(contents)) FROM sys_text_asset "
        "WHERE clicked_id IN (%s) AND text_type LIKE 'VERS%%'" % ph, vids)
    add('COMM', '주석 본문 — 구간',
        'SELECT COUNT(*), SUM(LENGTH(x.body_text)) FROM sys_commentary_text x '
        'JOIN sys_commentary_entry e ON e.entry_id=x.entry_id '
        'JOIN bible_index b ON b.verse_id=e.start_vid WHERE %s' % w)
    add('LEX', '절↔원어 낱말 — 구간',
        'SELECT COUNT(*), 0 FROM sys_verse_lemma WHERE verse_id IN (%s)' % ph,
        vids)
    # ★★★ **구간에 걸린 연결은 남김없이**(사용자 「연결된 모든 자산」) —
    #   본체(영상·용어)는 이미 코어에 통째로 있으므로 **연결만** 실으면 된다.
    # ⚠ **연결은 이미 코어에 통째로 있다**(`sys_link_asset` 5.1MB) — 여기서
    #   세는 것은 「구간에 몇 건이 걸려 있나」를 **보이기 위한 것**이고 따로
    #   담지 않는다. 담으면 같은 행이 두 벌이 된다.
    add('LINK', '구절 연결(절↔절 · 영상 · 용어 · 연구자료) — **코어에 이미 있음**',
        "SELECT COUNT(*), 0 FROM sys_link_asset "
        "WHERE COALESCE(record_status,'LIVE')='LIVE' AND ("
        " (link_type='VERS_VERS' AND clicked_id IN (%s))"
        " OR (link_type IN ('MEDI_VERS','REFU_VERS','ENTI_VERS')"
        "     AND target_id IN (%s)))" % (ph, ph), vids + vids)

    # 도서·설교 — 권마다 **첫 편의 앞 A4 한 장**
    nb = nu = tb = 0
    for (bid,) in conn.execute(
            "SELECT book_id FROM sys_book_asset "
            "WHERE COALESCE(record_status,'LIVE')='LIVE'"):
        got = book_taste(conn, bid)
        if got:
            nb += 1
            nu += len(got)
            tb += sum(len(t) for _u, _l, _v, t, _c in got)
    out.append(('BOOK', '도서·설교 %d권 — 첫 편의 앞 A4 한 장' % nb, nu, tb))

    # 사전·자료집 — 표제어 앞에서부터
    nd = nr = td = 0
    for (sid,) in conn.execute(
            "SELECT ref_src_id FROM sys_ref_source "
            "WHERE COALESCE(record_status,'LIVE')='LIVE'"):
        got = dict_taste(conn, sid)
        if got:
            nd += 1
            nr += len(got)
            td += sum(len(b or '') for _u, _l, b in got)
    out.append(('DICT', '사전·자료집 %d종 — 앞에서부터' % nd, nr, td))
    return out


# ───────────────────────── 자가 검증 ─────────────────────────
def _selftest():
    import appdb
    bad = []
    n = [0]

    def ck(name, cond, got=''):
        n[0] += 1
        if not cond:
            bad.append('%s %s' % (name, got))

    conn = appdb.connect()
    try:
        # ⓐ 구간 — 한 곳에서 만들고 실제로 절이 나온다
        vids = window_vids(conn)
        ck('구간이 비었다', len(vids) > 100, len(vids))
        ck('구간에 창세기가 없다',
           any(r[0] == 1 for r in conn.execute(
               'SELECT bcode FROM bible_index WHERE verse_id IN (%s)'
               % ','.join('?' * len(vids)), vids)))
        lb = window_label(conn)
        ck('구간 이름이 사람 말이 아니다', '장' in lb and len(lb) > 6, lb)

        # ⓑ ★★★ **자르기 — 문단 경계에서만, 그리고 잘랐다고 말한다**
        long = ('가' * 900 + '\n\n' + '나' * 900 + '\n\n' + '다' * 900)
        t, cut = _cut(long, 1800)
        ck('긴 글을 안 잘랐다', cut)
        ck('자른 표식이 없다', TASTE_MARK in t)
        ck('문단 한가운데서 잘랐다', t.split(TASTE_MARK)[0].rstrip()[-1] in '가나')
        ck('자른 글이 더 길다', len(t) < len(long))
        short = '짧은 글입니다.'
        t2, cut2 = _cut(short, 1800)
        ck('짧은 글을 잘랐다', not cut2)
        ck('안 자른 글에 표식을 붙였다', TASTE_MARK not in t2, t2)
        # ⚠ 문단이 없으면 **문장 끝**에서
        # ⚠ **cap 보다 길어야** 자른다 — 300개면 딱 1,800자라 안 잘린다
        one = ('가나다라. ' * 500)
        t3, c3 = _cut(one, 1800)
        ck('문단 없는 글을 못 자른다', c3)
        ck('문장 한가운데서 잘랐다',
           t3.split(TASTE_MARK)[0].rstrip().endswith('.'))

        # ⓒ 도서 맛보기 — 권마다 나오고 **A4 한 장 안쪽**
        r = conn.execute(
            "SELECT book_id FROM sys_book_asset "
            "WHERE COALESCE(record_status,'LIVE')='LIVE' LIMIT 1").fetchone()
        if r:
            got = book_taste(conn, r[0])
            ck('도서 맛보기가 비었다', got)
            ck('맛보기가 A4 한 장을 넘는다',
               all(len(t) <= UNIT_CHARS + len(TASTE_MARK) + 4
                   for _u, _l, _v, t, _c in got),
               max((len(t) for _u, _l, _v, t, _c in got), default=0))
            # ⚠ **한 편만** 담는다(권 전체가 아니다)
            ck('한 편보다 많이 담는다',
               len(set(u for u, _l, _v, _t, _c in got)) <= MIN_UNITS)
        # ★ **큰 책도 작은 책도 같은 규칙** — 스펄전 설교집이 통째로 오면 안 된다
        big = conn.execute(
            "SELECT book_id FROM sys_book_asset b WHERE EXISTS("
            " SELECT 1 FROM sys_book_unit u WHERE u.book_id=b.book_id) "
            "ORDER BY (SELECT COUNT(*) FROM sys_book_unit u"
            "          WHERE u.book_id=b.book_id) DESC LIMIT 1").fetchone()
        if big:
            g2 = book_taste(conn, big[0])
            ck('가장 큰 책이 A4 한 장을 넘는다',
               all(len(t) <= UNIT_CHARS + len(TASTE_MARK) + 4
                   for _u, _l, _v, t, _c in g2),
               max((len(t) for _u, _l, _v, t, _c in g2), default=0))

        # ⓘ ★★★ **맛보기 조각 번역**(2026-09-25) — 원문에 없는 언어를 채운다
        ensure(conn)
        fu = first_units(conn)
        ck('첫 편 자리가 비었다', len(fu) > 10, len(fu))
        ck('자리가 겹친다', len(set(u for u, _b, _c, _l in fu)) == len(fu))
        # ★ 자리는 **맛보기가 고르는 그 편**이라야 한다(두 문이면 갈린다)
        _bad = []
        for _u, _b, _c, _l in fu[:5]:
            got = book_taste(conn, _b)
            if got and got[0][0] != _u:
                _bad.append(_c)
        ck('맛보기가 선택하는 편과 자리가 다르다', not _bad, _bad)

        tu = None
        for _u, _b, _c, _l in fu:
            sl, tx, _x = src_excerpt(conn, _u)
            if sl and tx:
                tu, tb, tsl = _u, _b, sl
                break
        ck('옮길 원문 조각이 하나도 없다', tu is not None)
        if tu is not None:
            n0 = len(taste_rows(conn))
            m0 = len(book_taste(conn, tb))
            # ⚠⚠ **시험 언어는 시험 전용 코드**(§0-5) — 「그 책에 없는
            #   언어」로 고르던 것이 조각 번역을 적재하자 넷이 다 차서
            #   폴백이 **이미 있는 언어**를 집었고, 「진짜가 이긴다」 규칙에
            #   걸려 아무것도 안 늘어 **검사가 FAIL** 했다(재는 쪽 흠).
            got0 = set((l or '').upper() for _u2, l, _v, _t, _c in
                       book_taste(conn, tb))
            ck('시험 언어가 진짜 자료와 부딪힌다', 'XX' not in got0)
            # ★★★ **그 편의 조각을 통째로 떠 둔다**(2026-09-25 실측) —
            #   끝의 `DELETE … WHERE unit_id=?` 가 **남의 번역까지** 지웠다.
            _snap = conn.execute(
                'SELECT lang_code, body_text, record_status, updated_at'
                '  FROM sys_book_taste '
                'WHERE unit_id=?', (tu,)).fetchall()
            tlang = 'XX'
            try:
                put_taste(conn, tu, tlang, '시험용 맛보기 조각입니다.')
                g = book_taste(conn, tb)
                ck('조각 번역이 맛보기에 안 실린다', len(g) == m0 + 1,
                   '%d → %d' % (m0, len(g)))
                ck('조각 번역의 변형이 다르다',
                   any(l == tlang and v == TASTE_VARIANT
                       for _u2, l, v, _t, _c in g))
                ck('조각 번역 글이 안 나온다',
                   taste_text(conn, tu, tlang).startswith('시험용'))
                # ★ **원문 언어는 담아 둔 것이 아니라 잘라 낸 것**이다
                ck('원문 언어를 담아 둔 것으로 읽는다',
                   taste_text(conn, tu, tsl) == src_excerpt(conn, tu)[1])
                # ★★ **진짜 본문이 있는 언어는 조각이 못 이긴다**
                put_taste(conn, tu, tsl, '이 글이 원문을 덮으면 안 된다')
                g2 = [t for _u2, l, v, t, _c in book_taste(conn, tb)
                      if l == tsl]
                ck('잘린 조각이 원문을 덮었다',
                   all('이 글이 원문을' not in t for t in g2))
                # ★★ **음수 열쇠는 정해진 값**(코어팩을 다시 받아도 안 는다)
                ck('합성 열쇠가 양수다', _synth_id(tu, tlang) < 0)
                ck('합성 열쇠가 실행마다 다르다',
                   _synth_id(tu, tlang) == _synth_id(tu, tlang))
                ck('언어가 달라도 열쇠가 같다',
                   _synth_id(tu, tlang) != _synth_id(tu, 'JA'))
                # ★ **상한을 넘으면 담을 때 자른다**
                put_taste(conn, tu, tlang, '가' * (UNIT_CHARS + 500))
                ck('상한을 넘겨 담았다',
                   len(taste_text(conn, tu, tlang))
                   <= UNIT_CHARS + len(TASTE_MARK) + 4,
                   len(taste_text(conn, tu, tlang)))
            finally:
                conn.execute('DELETE FROM sys_book_taste WHERE unit_id=?',
                             (tu,))
                # ★ 떠 둔 것을 **글자 그대로** 되돌린다(상한을 다시 걸지
                #   않는다 — `put_taste` 를 쓰면 표식이 한 번 더 붙는다).
                for _row in _snap:
                    conn.execute(
                        'INSERT INTO sys_book_taste(unit_id, lang_code,'
                        ' body_text, record_status, updated_at) '
                        'VALUES(?,?,?,?,?)', (tu,) + tuple(_row))
                conn.commit()
            ck('시험 자국이 남았다', len(taste_rows(conn)) == n0,
               '%d → %d' % (n0, len(taste_rows(conn))))
            ck('되돌린 뒤 맛보기가 다르다', len(book_taste(conn, tb)) == m0)

        # ⓘ ★★★ **앞장(판권장·파일 머리말)을 건너뛴다**(2026-09-25)
        #   사용자 물음에서 나왔다 — 맛보기가 「첫 편의 앞부분」이라
        #   첫 편이 판권장이면 **표지 뒷면**이 나간다.
        ck('구텐베르크 머리말을 앞장으로 안 본다',
           is_front_matter('머리말', 'The Project Gutenberg eBook, Grace '
                                     'Abounding to the Chief of Sinners'))
        ck('판권 번호 제목을 앞장으로 안 본다',
           is_front_matter('ISBN: 978-159925-207-0', '아무 글'))
        ck('쪽 번호로 시작하는 제목을 앞장으로 안 본다',
           is_front_matter('550 CANONES SYNODI DORDRECHTANAE.', '아무 글'))
        # ★★ **헛걸림 양방향** — 보통 본문을 앞장으로 보면 진짜 첫 편을 잃는다
        ck('보통 본문을 앞장으로 본다',
           not is_front_matter('January 1 — Morning',
                               '"They did eat of the fruit of the land"'))
        ck('숫자가 든 제목을 다 앞장으로 본다',
           not is_front_matter('Psalm 119', '아무 글'))
        ck('제목에 년도가 있다고 앞장으로 본다',
           not is_front_matter('1855 Sermon', '아무 글'))

        _sk = {r[0]: r for r in front_skips(conn)}
        _fu = {cd: u for u, _b, cd, _l in first_units(conn)}
        ck('앞장을 건너뛴 책이 하나도 없다', bool(_sk), list(_sk))
        # ★★★ **담는 쪽과 작업대가 같은 편**이라야 한다 — 이 파일 머리글이
        #   경고한 자리(두 곳에서 고르면 옮긴 편과 실리는 편이 갈린다)
        _bad = []
        for _u, _bid, _cd, _l in first_units(conn):
            _rows = book_taste(conn, _bid)
            if _rows and {r[0] for r in _rows} != {_u}:
                _bad.append(_cd)
        ck('담는 편과 작업대 편이 다르다', not _bad, _bad[:3])
        # ★ **자리를 잃지 않는다** — 건너뛴 책도 자리가 있다
        ck('건너뛴 책이 맛보기에서 사라졌다',
           all(cd in _fu for cd in _sk), [c for c in _sk if c not in _fu])
        # ★ **다 앞장이면 첫 편으로 되돌아온다**(자리를 안 잃는다)
        _all_front = _first_of.__doc__ and '되돌아간다' in _first_of.__doc__
        ck('되돌아가는 규칙이 적혀 있지 않다', bool(_all_front))
        # ★ **넷까지만 건너뛴다**
        ck('건너뛴 편이 상한을 넘었다',
           all(r[1] <= FRONT_MAX for r in front_skips(conn)))

        # ⓒ-2 ★ **속표지 한 줄은 맛보기가 아니다**(양방향)
        _kl = 'Book I — Admonitions Profitable for the Spiritual Life'
        ck('속표지를 본문으로 본다',
           _is_bare_head(_kl, 'THE FIRST BOOK\nAdmonitions Profitable '
                              'for the Spiritual Life'))
        ck('출처 줄만 보고 본문이라 한다',
           _is_bare_head(_kl, 'THE FIRST BOOK\nAdmonitions Profitable for '
                              'the Spiritual Life\n\n— Modern English '
                              'adaptation · Thomas à Kempis, "The '
                              'Imitation of Christ" (tr. William Benham, '
                              '1874). Public domain.'))
        ck('짧은 본문을 속표지로 본다',
           not _is_bare_head('Prologue', 'The Church of God that sojourns '
                                         'in Rome. Grace be with you.'))
        ck('긴 글을 속표지로 본다',
           not _is_bare_head('가', '가' * (FRONT_BARE + 1)))
        # ★ 제목과 겹치지 않으면 짧아도 본문이다(진짜 첫 줄을 잃지 않는다)
        ck('제목과 다른 짧은 글을 속표지로 본다',
           not _is_bare_head('January 1 — Morning',
                             '"They did eat of the fruit of the land"'))

        # ⓓ 사전 — 상한을 지키고 **최소 하나는 준다**
        s = conn.execute(
            "SELECT ref_src_id FROM sys_ref_source "
            "WHERE src_type='DICTIONARY' LIMIT 1").fetchone()
        if s:
            d = dict_taste(conn, s[0])
            ck('사전 맛보기가 비었다', d)
            ck('사전 상한을 넘는다',
               sum(len(b or '') for _u, _l, b in d) <= DICT_BYTES * 1.2,
               sum(len(b or '') for _u, _l, b in d))
            # ⚠ 상한이 아주 작아도 **하나는 준다**(빈 맛보기를 안 만든다)
            ck('상한이 작으면 통째로 비운다', len(dict_taste(conn, s[0], 1)) >= 1)

        # ⓔ-0 ★★★ **담는 쪽** — BSB 전권 + 맛보기가 실제 행으로 나온다
        tb = taste_tables(conn)
        ck('담을 표가 없다', tb)
        bc = tb.get('bible_content') or {}
        ck('성경 본문을 안 담는다', bc.get('rows'))
        _vi = bc['cols'].index('version_code')
        _bsb = sum(1 for r in bc['rows'] if r[_vi] == 'BSB')
        ck('BSB 를 전권으로 안 담는다', _bsb > 30000, _bsb)
        # ⚠ **그 밖 역본은 구간만** — 전부 담으면 27 MB 가 된다
        _oth = sum(1 for r in bc['rows'] if r[_vi] != 'BSB')
        ck('그 밖 역본을 전권으로 담는다', _oth < 20 * len(vids), _oth)
        # ⚠ **같은 행을 두 번 담지 않는다**
        _key = set()
        _dup = 0
        _ki = bc['cols'].index('verse_id')
        for r in bc['rows']:
            k = (r[_ki], r[_vi])
            if k in _key:
                _dup += 1
            _key.add(k)
        ck('성경 본문에 겹치는 행이 있다', _dup == 0, _dup)
        # ★ 도서 본문은 **자른 글**이 담긴다(원본 그대로면 규칙이 무너진다)
        bu = tb.get('sys_book_unit_text') or {}
        if bu.get('rows'):
            _bi = bu['cols'].index('body_text')
            ck('도서 본문이 A4 한 장을 넘는다',
               all(len(r[_bi] or '') <= UNIT_CHARS + len(TASTE_MARK) + 4
                   for r in bu['rows']),
               max(len(r[_bi] or '') for r in bu['rows']))
        # ⚠ **연결은 안 담는다** — 코어에 이미 있다(담으면 두 벌)
        ck('연결을 또 담는다', 'sys_link_asset' not in tb)

        # ⓔ 전체 셈 — 갈래가 다 나오고 크기가 예산 안
        pl = plan(conn)
        ks = set(k for k, *_r in pl)
        for want in ('BIBLE', 'DESC', 'COMM', 'LEX', 'LINK', 'BOOK', 'DICT'):
            ck('%s 갈래가 셈에 없다' % want, want in ks)
        tot = sum(b for _k, _d, _n, b in pl)
        ck('맛보기가 비었다', tot > 100000, tot)
        # ⚠ **예산** — 압축 전 12 MB 를 넘으면 코어팩이 한도에 닿는다
        ck('맛보기가 예산(12MB)을 넘는다', tot < 12 * 1048576,
           '%.1f MB' % (tot / 1048576))
        # ★ 구간에 걸린 **연결**이 실제로 잡히는가(빠뜨리면 조용히 얕아진다)
        lk = [x for x in pl if x[0] == 'LINK'][0]
        ck('구간에 걸린 연결이 0건이다', lk[2] > 0, lk[2])
    finally:
        try:
            conn.close()
        except Exception:                                 # noqa: BLE001
            pass

    print('[db_pack_taste] %d개 검사 · 흠 %d건'
          % (n[0], len(bad)))
    for b in bad:
        print('  FAIL', b)
    return 1 if bad else 0


def _plan_cli():
    import appdb
    conn = appdb.connect()
    print('맛보기 구간 —', window_label(conn))
    print()
    tot = 0
    for k, d, n, b in plan(conn):
        tot += b
        print('  %-6s %-44s %7s조각 %8.2f MB'
              % (k, d, format(n, ','), b / 1048576))
    print('  %-6s %-44s %7s  %8.2f MB' % ('', '합계', '', tot / 1048576))
    return 0


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        return _selftest()
    if '--plan' in a:
        return _plan_cli()
    print(__doc__)
    return 0


if __name__ == '__main__':
    sys.exit(main())
