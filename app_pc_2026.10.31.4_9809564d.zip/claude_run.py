# -*- coding: utf-8 -*-
"""Claude Code 를 화면 없이 부르는 **단일 문** (2026-10-08 · docs/1.txt 57 후속).

Q&A 비슷한 질문 찾기(`qa_agent`)와 용어 연결 판정(`db_ai_term_link --claude`)이 같은 문을 쓴다.
부를 때마다 시간·비용·성공을 `admin_comm.db` 의 `claude_log` 에 남긴다 — AI 작업 현황 화면이 읽는다.

★ 빈 작업 폴더에서 돈다 — 앱 폴더에서 부르면 CLAUDE.md(수백 KB)를 통째로 읽어 느리고 비싸다.
★ 도구는 부르는 쪽이 정한다(없으면 `--tools ""` · 있으면 허용 목록만 · `dontAsk` 로 나머지는 막는다).
★ 결과는 JSON 스키마로 못 박는다 · 꼴이 틀리면 실패로 돌려준다.
⚠ 관리자 PC 전용 — Claude Code 가 깔리고 로그인돼 있어야 한다.
"""
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
from datetime import datetime

APP = os.path.dirname(os.path.abspath(__file__))
MODEL = 'claude-sonnet-5-5'
WORK = os.path.join(tempfile.gettempdir(), 'hagah_claude_work')
LOG_DB = os.path.join(APP, 'admin_comm.db')


def claude_bin():
    return shutil.which('claude') or shutil.which('claude.cmd') or shutil.which('claude.exe')


def workdir(sub=''):
    d = os.path.join(WORK, sub) if sub else WORK
    os.makedirs(d, exist_ok=True)
    return d


def _log(task, ok, sec, cost, turns, why, db=None):
    try:
        c = sqlite3.connect(db or LOG_DB)
        c.execute('CREATE TABLE IF NOT EXISTS claude_log(at TEXT, task TEXT, ok INTEGER, sec REAL,'
                  ' cost REAL, turns INTEGER, why TEXT)')
        c.execute('INSERT INTO claude_log VALUES(?,?,?,?,?,?,?)',
                  (datetime.now().isoformat(timespec='seconds'), task, 1 if ok else 0,
                   round(sec or 0, 1), cost or 0, turns or 0, (why or '')[:300]))
        c.commit()
        c.close()
    except Exception:                                    # noqa: BLE001
        pass


def build_cmd(prompt, schema, tools=None, allowed=None, model=None, budget='1.00'):
    cmd = [claude_bin() or 'claude', '-p', prompt, '--model', model or MODEL,
           '--output-format', 'json', '--json-schema', json.dumps(schema),
           '--no-session-persistence', '--max-budget-usd', str(budget),
           '--permission-mode', 'dontAsk']
    cmd += ['--tools', tools if tools else '']
    if allowed:
        cmd += ['--allowedTools'] + list(allowed)
    return cmd


def parse(out):
    """CLI JSON 출력 → {'ok', 'data', 'cost', 'turns', 'why'}."""
    try:
        d = json.loads(out)
    except Exception:
        return {'ok': False, 'why': '출력을 읽지 못했습니다: %s' % (out or '')[:200]}
    if d.get('is_error'):
        return {'ok': False, 'why': str(d.get('result') or d.get('subtype'))[:300],
                'cost': d.get('total_cost_usd'), 'turns': d.get('num_turns')}
    so = d.get('structured_output')
    if so is None:
        try:
            so = json.loads(d.get('result') or '')
        except Exception:
            so = None
    if not isinstance(so, dict):
        return {'ok': False, 'why': '정해진 꼴이 아닙니다', 'cost': d.get('total_cost_usd')}
    return {'ok': True, 'data': so, 'cost': d.get('total_cost_usd'), 'turns': d.get('num_turns')}


def run(task, prompt, schema, tools=None, allowed=None, env=None, cwd=None, model=None,
        budget='1.00', timeout=300, runner=None, log_db=None):
    """한 번 부른다 → parse() 결과 + sec. 실패를 밖으로 던지지 않는다."""
    cmd = build_cmd(prompt, schema, tools, allowed, model, budget)
    e = dict(os.environ, PYTHONIOENCODING='utf-8')
    e.update(env or {})
    t0 = time.time()
    if runner:
        res = parse(runner(cmd, e))
    elif not claude_bin():
        res = {'ok': False, 'why': 'Claude Code 를 찾지 못했습니다(관리자 PC 에 설치·로그인 필요)'}
    else:
        try:
            p = subprocess.run(cmd, cwd=cwd or workdir(), env=e, capture_output=True,
                               timeout=timeout, encoding='utf-8', errors='replace')
            res = parse(p.stdout) if p.stdout.strip() else {'ok': False, 'why': (p.stderr or 'claude 실패')[:300]}
        except subprocess.TimeoutExpired:
            res = {'ok': False, 'why': '시간 초과(%d초)' % timeout}
    res['sec'] = round(time.time() - t0, 1)
    if not runner:
        _log(task, res.get('ok'), res['sec'], res.get('cost'), res.get('turns'), res.get('why'), log_db)
        # ★ 2026-10-13 — 보낸 글을 글자 그대로 남긴다(`ai_sent_log`) — 도구 권한·스키마도 함께 적는다
        try:
            import ai_sent_log
            import json as _json
            extra = '\n\n[도구] %s · [허락] %s\n[답의 모양(스키마)]\n%s' % (
                tools or '없음', ', '.join(allowed or []) or '없음',
                _json.dumps(schema, ensure_ascii=False) if schema else '없음')
            ai_sent_log.record('claude', prompt + extra, model=model or MODEL, ok=res.get('ok'),
                               response=_json.dumps(res.get('data') if res.get('data') is not None
                                                    else res.get('text') or '', ensure_ascii=False)[:20000],
                               why=res.get('why') or '', source=ai_sent_log._TAG.get('source') or task)
        except Exception:                                 # noqa: BLE001
            pass
    return res


def log_summary(db=None, days=30):
    """task 마다 [(task, 부른 수, 성공, 비용, 평균 초, 마지막)]."""
    try:
        c = sqlite3.connect(db or LOG_DB)
        c.execute('CREATE TABLE IF NOT EXISTS claude_log(at TEXT, task TEXT, ok INTEGER, sec REAL,'
                  ' cost REAL, turns INTEGER, why TEXT)')
        rows = c.execute("SELECT task, COUNT(*), SUM(ok), SUM(cost), AVG(sec), MAX(at) FROM claude_log"
                         " WHERE at >= date('now', ?) GROUP BY task ORDER BY task", ('-%d day' % days,)).fetchall()
        c.close()
        return rows
    except Exception:
        return []


def selftest():
    n = [0, 0]

    def ck(c, m):
        n[0] += 1
        n[1] += bool(c)
        if not c:
            print('  FAIL', m)
    good = json.dumps({'is_error': False, 'total_cost_usd': 0.03, 'num_turns': 2,
                       'structured_output': {'items': []}})
    ck(parse(good)['ok'], '꼴 읽기')
    ck(not parse('x')['ok'], '못 읽으면 실패')
    ck(not parse(json.dumps({'is_error': True, 'result': 'budget'}))['ok'], '에이전트 실패')
    cmd = build_cmd('p', {'type': 'object'})
    ck(cmd[cmd.index('--tools') + 1] == '' and '--allowedTools' not in cmd, '도구 없음이 기본')
    cmd = build_cmd('p', {}, tools='Bash', allowed=['Bash(python t.py:*)'])
    ck(cmd[cmd.index('--allowedTools') + 1] == 'Bash(python t.py:*)', '허용 목록')
    ck(cmd[cmd.index('--permission-mode') + 1] == 'dontAsk', '나머지는 막는다')
    r = run('test', 'p', {}, runner=lambda c, e: good)
    ck(r['ok'] and 'sec' in r, '가짜 실행기')
    d = tempfile.mkdtemp()
    _log('t', True, 1.0, 0.02, 3, '', os.path.join(d, 'l.db'))
    ck(log_summary(os.path.join(d, 'l.db'))[0][1] == 1, '기록 요약')
    ck(not os.path.exists(os.path.join(workdir(), 'CLAUDE.md')), '작업 폴더에 CLAUDE.md 없음')
    print('claude_run selftest %d/%d' % (n[1], n[0]))
    return n[0] == n[1]


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)
