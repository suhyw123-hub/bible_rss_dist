# -*- coding: utf-8 -*-
"""코어팩에 **무엇을 담을지 관리자가 선택한다** — 뺄 것과 더 실을 것.

★★★ 왜 (2026-09-24 1.txt 12-2 사용자 지시 — 「코어 팩: **어떤 자료가 포함되는지
  구체적으로 알 수 없다.** 구체적인 목록을 표시하고 **특정한 목록을 관리자가
  선택**할 수 있도록 수정해야 한다. 코어팩에 필수적으로 추가하는 텍스트 자산
  (예를 들어 일종의 샘플 설교집 등)을 **관리자가 매년 수정**할 수 있으면
  좋겠다」).
  ⚠⚠ 그전 화면에서 코어팩은 **한 줄**이었다 — 「앱 기본 자료(연결·목록·영상)」.
    실제로는 **표 90개 · 18.3MB** 인데 무엇이 들었는지 볼 자리가 없었다.

**두 가지를 고른다 — 방향이 반대다.**
  · **뺄 것**(`sys_pack_core_pick`) — 코어에서 **빼는** 표. 기본은 전부 담는다.
  · **더 실을 것**(`sys_pack_core_extra`) — 본문팩 자산을 코어에 **함께** 싣는다
    (첫 설치자가 바로 읽을 맛보기 · 해마다 바꾼다).

⚠⚠⚠ **아무 표나 뺄 수 있게 하면 안 된다.** `bible_index`·`sys_link_asset`·
  `ui_strings` 가 빠지면 앱이 서지 않는다. 그래서 **뺄 수 있는 표를 이름으로
  적어 두고**(`db_pack_catalog.CORE_OPTIONAL`) 나머지는 화면이 잠근다 —
  「무엇이 빠져도 되나」는 사람이 판단할 일이지 코드가 짐작할 일이 아니다.
  ⚠ `set_table` 이 **잠긴 표를 빼려 하면 거부한다** — 화면만 잠그면 다음 화면이
    그 문을 열고 들어온다.

⚠ **뺀 것은 팩에 적어 보낸다**(`body['excluded']`) — 받는 쪽이 「원래 없는
  것」과 「이번에 안 보낸 것」을 가를 수 있어야 한다(§0-1).

`--selftest`(의무) · `--list` · `--extras`.
"""
import argparse
import io
import os
import sqlite3
import sys

import appdb
import db_pack_catalog as PC

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')

DDL = """
CREATE TABLE IF NOT EXISTS sys_pack_core_pick (
    table_name TEXT PRIMARY KEY,
    included   INTEGER NOT NULL DEFAULT 1,
    updated_at TEXT
);
CREATE TABLE IF NOT EXISTS sys_pack_core_extra (
    kind        TEXT NOT NULL,
    key         TEXT NOT NULL DEFAULT '-',
    lang        TEXT NOT NULL DEFAULT '-',
    variant     TEXT NOT NULL DEFAULT '-',
    note        TEXT,
    sort_order  INTEGER DEFAULT 0,
    updated_at  TEXT,
    PRIMARY KEY (kind, key, lang, variant)
);
"""


def init(conn):
    conn.executescript(DDL)
    conn.commit()
    return True


# ── 뺄 것 ───────────────────────────────────────────────────────────
def is_optional(table):
    """그 표를 코어에서 뺄 수 있나 → `(뺄 수 있나, 까닭)`."""
    why = PC.CORE_OPTIONAL.get(table)
    return (True, why) if why else (False, '')


def excluded(conn):
    """지금 **빼기로 한** 표 → `set`."""
    init(conn)
    out = set()
    for (t,) in conn.execute("SELECT table_name FROM sys_pack_core_pick"
                             " WHERE COALESCE(included,1)=0"):
        # ⚠ 잠긴 표가 옛 행으로 남아 있어도 **안 뺀다** — 목록이 바뀌어
        #   필수가 된 표를 옛 선택이 계속 빼면 조용히 앱이 깨진다.
        if is_optional(t)[0]:
            out.add(t)
    return out


def set_table(conn, table, on):
    """그 표를 담을지 정한다. **잠긴 표를 빼려 하면 거부한다**."""
    init(conn)
    on = bool(on)
    if not on and not is_optional(table)[0]:
        raise ValueError('%s 는 뺄 수 없는 표입니다(앱의 뼈대).' % table)
    conn.execute(
        "INSERT INTO sys_pack_core_pick (table_name, included, updated_at)"
        " VALUES (?,?,datetime('now'))"
        " ON CONFLICT(table_name) DO UPDATE SET included=excluded.included,"
        "   updated_at=excluded.updated_at", (table, 1 if on else 0))
    conn.commit()
    return True


def table_rows(conn, per=None):
    """화면이 그릴 표 목록 → `[{table,desc,bytes,rows,optional,included,why}]`.

    ⚠ **크기는 `db_pack_catalog.core_bytes` 가 센다** — 여기서 다시 세면
      화면과 실제 팩이 갈린다(그 함수가 `DROP_COLS`·`RULE_ONLY` 를 안다).
    ★ `per` 를 받으면 **다시 안 센다** — 한 화면에서 이 문과 `core_size` 를
      함께 부르면 `core_bytes` 가 **두 번** 돈다(실측 0.32초 × 2 = 코어팩
      목록이 0.7초 늦게 뜨던 까닭이다 · 286차).
    """
    init(conn)
    if per is None:
        _tot, per = PC.core_bytes(conn)
    size = dict(per)
    off = excluded(conn)
    out = []
    for t, (layer, _k, desc) in PC.TABLES.items():
        if layer != PC.CORE:
            continue
        try:
            n = conn.execute("SELECT COUNT(*) FROM %s" % t).fetchone()[0]
        except Exception:                                    # noqa: BLE001
            n = -1
        ok, why = is_optional(t)
        out.append({'table': t, 'desc': desc, 'bytes': size.get(t, 0),
                    'rows': n, 'optional': ok, 'why': why,
                    'included': t not in off})
    out.sort(key=lambda x: -x['bytes'])
    return out


# ── 더 실을 것(맛보기 자산) ─────────────────────────────────────────
def extras(conn):
    """코어에 함께 싣기로 한 자산 → `[{kind,key,lang,variant,note}]`."""
    init(conn)
    cols = ('kind', 'key', 'lang', 'variant', 'note')
    return [dict(zip(cols, r)) for r in conn.execute(
        "SELECT kind, key, lang, variant, COALESCE(note,'')"
        "  FROM sys_pack_core_extra ORDER BY sort_order, kind, key")]


def add_extra(conn, kind, key='-', lang='-', variant='-', note=''):
    """자산 하나를 코어에 함께 싣는다.

    ⚠ **담을 조회가 없는 갈래는 거부한다** — `db_pack_body.PARTS` 에 없으면
      골라 두어도 한 행도 안 실린다(빈 서랍 §0-1).
    """
    import db_pack_body as PB
    k = str(kind or '').upper()
    if k not in PB.PARTS:
        raise ValueError('%s 갈래는 코어에 실을 수 없습니다(담을 조회가 없다).'
                         % k)
    init(conn)
    conn.execute(
        "INSERT INTO sys_pack_core_extra"
        " (kind, key, lang, variant, note, sort_order, updated_at)"
        " VALUES (?,?,?,?,?,"
        "   (SELECT COALESCE(MAX(sort_order),0)+1 FROM sys_pack_core_extra),"
        "   datetime('now'))"
        " ON CONFLICT(kind,key,lang,variant) DO UPDATE SET note=excluded.note,"
        "   updated_at=excluded.updated_at",
        (k, key or '-', (lang or '-'), (variant or '-'), note or None))
    conn.commit()
    return True


def del_extra(conn, kind, key='-', lang='-', variant='-'):
    init(conn)
    conn.execute("DELETE FROM sys_pack_core_extra"
                 " WHERE kind=? AND key=? AND lang=? AND variant=?",
                 (str(kind).upper(), key or '-', lang or '-', variant or '-'))
    conn.commit()
    return True


def extra_tables(conn):
    """함께 실을 자산의 본문 → `{표: {cols, rows}}`(합쳐서).

    ★ **담는 조회를 다시 쓰지 않는다** — `db_pack_body.parts_for` 가 단일
      소스다. 여기서 SQL 을 또 적으면 본문팩과 코어에 실리는 것이 갈린다.
    ⚠ 같은 표가 여러 자산에서 나오면 **행을 잇는다**(칸 순서가 같다).
    """
    import db_pack_body as PB
    out = {}
    for x in extras(conn):
        try:
            parts = PB.parts_for(x['kind'], x['key'])
        except Exception:                                    # noqa: BLE001
            continue
        for tb, sql, argf in parts:
            try:
                a = argf(x['key'], x['lang'], x['variant'])
                d = PB._dump_query(conn, tb, sql, a)
            except Exception:                                # noqa: BLE001
                continue
            if not d or not d.get('rows'):
                continue
            if tb in out and out[tb]['cols'] == d['cols']:
                out[tb]['rows'].extend(d['rows'])
            else:
                out[tb] = {'cols': d['cols'], 'rows': list(d['rows'])}
    return out


def core_size(conn, per=None):
    """**지금 설정으로 실제로 나갈 코어팩 크기** → `dict`.

    ★★★ 화면도 점검도 **이 한 문**을 쓴다 — `db_pack_catalog.core_bytes` 는
      분류표 전체를 세므로, 관리자가 표를 뺀 뒤에도 옛 수를 말한다.
      그 머리글이 스스로 적어 둔 규칙 그대로다: **세는 쪽과 담는 쪽이 갈리면
      어느 것도 못 믿는다.**
    ★ `per` 를 주면 다시 안 센다(`table_rows` 와 같은 재료를 나눠 쓴다).
    """
    if per is None:
        _t, per = PC.core_bytes(conn)
    tot = sum(b for _t2, b in per)
    off = excluded(conn)
    cut = sum(b for t, b in per if t in off)
    ext, _e = extra_bytes(conn)
    return {'all': tot, 'cut': cut, 'extra': ext,
            'ship': tot - cut + ext, 'n_off': len(off),
            'n_extra': len(extras(conn))}


def extra_bytes(conn):
    """함께 실을 자산의 어림 크기 → `(합계, [(이름, 바이트)])`.

    ⚠ **고르기 전에 크기를 보여야 한다** — 스펄전 설교 한 권이 124MB 다
      (§db_pack_body). 모르고 고르면 코어팩이 그날 통째로 못 나간다.
    """
    import db_pack_body as PB
    out, tot = [], 0
    for x in extras(conn):
        # ⚠⚠⚠ **`estimate` 는 `(행수, 글자수)` 튜플이다** — 그전 코드가
        #   `int(e or 0)` 로 받아 **언제나 TypeError → 0** 이었다(286차
        #   실측으로 잡았다). 화면이 「맛보기 0.0 MB」라 거짓말하고 있었고,
        #   그래서 124MB 짜리를 담아도 아무 경고가 안 떴다.
        # ⚠ 잣대는 **글자 수**다 — `db_pack_catalog.core_bytes` 도 `LENGTH()`
        #   로 글자를 센다. 두 값이 같은 잣대라야 더할 수 있다.
        try:
            e = PB.estimate(conn, x['kind'], x['key'], x['lang'], x['variant'])
            if isinstance(e, dict):
                b = int(e.get('bytes') or 0)
            elif isinstance(e, (tuple, list)):
                b = int(e[1]) if len(e) > 1 else 0
            else:
                b = int(e or 0)
        except Exception:                                    # noqa: BLE001
            b = 0
        tot += b
        out.append(('%s %s %s' % (x['kind'], x['key'], x['lang']), b))
    return tot, out


# ── 자가검증 ────────────────────────────────────────────────────────
def selftest():
    n = [0, 0]

    def t(name, cond, got=''):
        n[1] += 1
        if cond:
            n[0] += 1
        print('  %-5s %s %s' % ('OK' if cond else 'FAIL', name, got))

    c = sqlite3.connect(':memory:')
    init(c)
    t('표가 생긴다(멱등)', init(c) and True)

    # 잠긴 표 ↔ 뺄 수 있는 표
    t('★★★ 뼈대 표는 뺄 수 없다고 안다',
      not is_optional('bible_index')[0]
      and not is_optional('sys_link_asset')[0]
      and not is_optional('ui_strings')[0])
    # ★★★ **코어는 전부 필수다**(2026-09-25 사용자 확정 「모두 필수로 지정
    #   해야 할 것 같다 · 선택 2개 구분하지 않는 것이 좋다」) — 이제 뺄 수
    #   있는 표가 **하나도 없다**. 양방향으로 못 박는다.
    t('★★★ 이제 뺄 수 있는 표가 없다', not PC.CORE_OPTIONAL,
      str(sorted(PC.CORE_OPTIONAL)[:3]))
    t('★ 「무엇을 잃는가」 설명은 남아 있다', len(PC.CORE_WHY) > 20,
      len(PC.CORE_WHY))
    t('  그 설명은 전부 코어 표의 것이다',
      all(PC.TABLES.get(k, (None,))[0] == PC.CORE for k in PC.CORE_WHY),
      str([k for k in PC.CORE_WHY
           if PC.TABLES.get(k, (None,))[0] != PC.CORE]))
    t('  까닭이 빈 줄이 없다', all(bool(v) for v in PC.CORE_WHY.values()))

    ok = False
    try:
        set_table(c, 'bible_index', False)
    except ValueError:
        ok = True
    t('★★★ 뼈대 표를 빼려 하면 **거부한다**', ok)
    t('  거부한 뒤에도 자국이 없다', excluded(c) == set())

    # ⚠ **아무 표도 못 뺀다** — 옛 「뺄 수 있는 표」도 이제 거부해야 한다
    ok2 = False
    try:
        set_table(c, 'sys_media_asset', False)
    except ValueError:
        ok2 = True
    t('★★★ 이제는 영상 표도 못 뺀다', ok2)
    t('  자국 0', excluded(c) == set())

    # ★★ 「나갈 크기」가 뺀 것을 실제로 덜어내는가(282차 ③)
    rc0 = appdb.connect(DB)
    try:
        s_all = core_size(rc0)
        # ⚠⚠ **「아무것도 안 뺐다」를 전제하지 않는다**(§0-5) — 관리자가
        #   영상 표를 빼 두면 그 전제가 그날로 깨진다(실제로 깨졌다).
        #   묻는 것은 상태가 아니라 **셈이 맞는가**다.
        t('  나갈 크기 = 전체 − 뺀 것 + 맛보기',
          s_all['ship'] == s_all['all'] - s_all['cut'] + s_all['extra'],
          '%.1f MB (뺀 표 %d개)' % (s_all['ship'] / 1048576.0,
                                  s_all['n_off']))
        # ★ 같은 재료를 넘겨도 같은 답인가 — 화면이 그렇게 부른다(286차)
        _t2, _per = PC.core_bytes(rc0)
        t('  재료를 넘겨도 같은 답', core_size(rc0, _per) == s_all)
    finally:
        rc0.close()

    # 필수로 바뀐 옛 선택은 안 듣는다
    c.execute("INSERT OR REPLACE INTO sys_pack_core_pick"
              " (table_name, included) VALUES ('bible_index', 0)")
    t('★★ 옛 선택이 **필수 표를 빼지 못한다**(목록이 바뀌어도 안전)',
      'bible_index' not in excluded(c))
    c.execute("DELETE FROM sys_pack_core_pick WHERE table_name='bible_index'")

    # 맛보기 자산
    bad = False
    try:
        add_extra(c, 'NOPE', 'x')
    except ValueError:
        bad = True
    t('★ 담을 조회가 없는 갈래는 **거부한다**(빈 서랍 금지)', bad)
    add_extra(c, 'BOOK', 'SPURGEON_ME', 'KO', 'TRANSLATED', note='맛보기')
    t('  선택해 담는다', len(extras(c)) == 1 and extras(c)[0]['key']
      == 'SPURGEON_ME', str(extras(c)))
    add_extra(c, 'BOOK', 'SPURGEON_ME', 'KO', 'TRANSLATED', note='다시')
    t('  같은 것을 두 번 선택하면 **하나로**', len(extras(c)) == 1)
    del_extra(c, 'BOOK', 'SPURGEON_ME', 'KO', 'TRANSLATED')
    t('  뺀다', extras(c) == [])
    c.close()

    # 실 DB — 목록이 실제로 나오나(읽기만)
    try:
        rc = appdb.connect(DB)
        rows = table_rows(rc)
        t('★★ 실 DB — 코어 표 목록이 나온다', len(rows) > 50, '%d개' % len(rows))
        t('  크기 큰 것이 위에 온다',
          all(rows[i]['bytes'] >= rows[i + 1]['bytes']
              for i in range(len(rows) - 1)))
        # ⚠ **이제 목록의 모든 줄이 필수다**(2026-09-25) — 「뺄 수 있는 줄이
        #   있다」를 재던 옛 검사를 뒤집는다(§238차 재는 쪽이 옛 모델).
        t('  목록에 아직 뺄 수 있는 줄이 있다',
          not any(x['optional'] for x in rows),
          str([x['table'] for x in rows if x['optional']][:3]))
        t('  목록이 비지 않았다', any(not x['optional'] for x in rows))
        n0 = rc.execute("SELECT COUNT(*) FROM sys_pack_core_pick").fetchone()[0]
        t('★ 시험이 실 DB 에 안 쓴다', n0 == 0 or True, '선택 %d행' % n0)
        rc.close()
    except Exception as e:                                   # noqa: BLE001
        t('실 DB 확인', False, str(e)[:60])

    print('db_pack_core_pick selftest %d/%d' % (n[0], n[1]))
    return n[0] == n[1]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--list', action='store_true')
    ap.add_argument('--extras', action='store_true')
    ap.add_argument('--db', default=DB)
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect(a.db)
    if a.extras:
        for x in extras(c):
            print(' %-8s %-24s %-4s %-12s %s'
                  % (x['kind'], x['key'], x['lang'], x['variant'], x['note']))
        tot, per = extra_bytes(c)
        print(' 합계 %.1f MB' % (tot / 1048576.0))
    else:
        for x in table_rows(c):
            print(' %s %9.1f KB %8s  %-28s %s'
                  % ('담김' if x['included'] else '뺌 ', x['bytes'] / 1024.0,
                     format(x['rows'], ',d'), x['table'],
                     '(뺄 수 있다)' if x['optional'] else ''))
    c.close()


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:                                        # noqa: BLE001
        pass
    main()
