# -*- coding: utf-8 -*-
"""verse_ref_suggest.py — **구절약명 추천 줄** 공통 부품 (영구 · 315차 신설)
================================================================================
글 본문에서 읽은 구절 좌표를 **사람이 확인해 거는 자리**. 관리자 연구자료 화면과
사용자 연구자료 화면이 **이 한 부품**을 심는다.

★★★ 사용자 지시 — 「자동으로 **연결추천하고 사람이 확인하는** 기능」 ·
  「**관리자화면 뿐만 아니라 사용자 화면도 대상**이 되어야 한다」.

★★★ **왜 한 부품인가** — 두 화면이 각자 그리면 체크 기본값·갈래 이름·거는 규칙이
  갈라진다. 실제로 그 갈라짐을 이 저장소가 여러 번 겪었다(§219차 ⑤).
  ⇒ **보이는 것은 여기 하나**이고, **거는 일만** 화면이 콜백으로 한다
    (관리자는 `sys_link_asset`, 사용자는 `userdb.user_link_asset` — 표가 다르다).

★ **체크 기본값이 갈래를 따른다** — 글자가 책 이름을 스스로 말한 것만 켠다:
  | 갈래 | 기본 | 까닭 |
  |---|---|---|
  | `VERSE`·`RANGE`·`LIST` | **켠다** | 책·장·절이 글에 적혀 있다 |
  | `CHAPTER` | **끈다** | 장만 적혀 **1절만** 걸리고, 실측 오탐이 섞인다 (「…39절 7권(출애굽기 21 · 레위기 1)」을 장으로 읽던 자리) |

⚠ **찾은 것이 없으면 스스로 숨는다**(§0-1 빈 서랍 금지).
⚠ **이미 걸린 좌표는 안 보인다** — 「추천」은 아직 안 걸린 것이다.
⚠ **단추는 위**(§0) · 팝업 없음 · 색·글꼴은 `ui_theme.C`·`theme_font`(§36).
⚠ 읽는 문은 `scripture_ref` **하나**다 — 여기서 정규식을 또 쓰지 않는다.

쓰는 법
    import verse_ref_suggest as VRS
    bar = VRS.SuggestBar(parent, db_path=..., on_link=self._link_them,
                         lang_getter=self._lang)
    bar.load(body, lang, have)        # have = 이미 걸린 {(start, end)}
    #  on_link(rows) → 걸린 수.  rows = [(start, end, matched, kind)]
"""
import sys
import tkinter as tk

import i18n

try:
    import ui_theme
except Exception:                                         # noqa: BLE001
    ui_theme = None
try:
    import theme_font
except Exception:                                         # noqa: BLE001
    theme_font = None

#: 기본으로 체크하는 갈래 — 글자가 책 이름을 스스로 말한 것
ON_KINDS = ('VERSE', 'RANGE', 'LIST', 'ENTITY', 'LEMMA')
#: ★ 2026-10-25 원어 추천 갈래 — `ENTITY`(승격된 주요용어) · `LEMMA`(승격 안 된 원어) · 끝에 `_G` 가 붙으면
#:   짐작(철자가 같은 다른 번호가 있다 — 기본으로 안 켠다). 읽는 문 = `orig_ref.find`.
ORIG_KINDS = ('ENTITY', 'LEMMA', 'ENTITY_G', 'LEMMA_G')


def link_of(row):
    """추천 한 줄 → 연결 `(kind, target_id, end_id)` — 구절이면 VERSE · 원어면 ENTITY/LEMMA."""
    a, b, _m, k = row
    if k in ORIG_KINDS:
        return (k.split('_')[0], int(a), None)
    return ('VERSE', a, b)


def is_orig(row):
    return row[3] in ORIG_KINDS
#: 한 줄에 보이는 상한. ⚠ 넘으면 **잘렸다고 적는다**(§0-1).
CAP = 40


def _C(role, fallback):
    """역할 → 색. ⚠ `ui_theme.C` 는 모르는 역할에 **빈 문자열**을 낸다(예외가
    아니다). 그것을 위젯에 넣으면 `unknown color name ""` 로 죽는다 —
    **값이 비었는지 보고** 폴백한다(실측으로 당했다)."""
    try:
        got = ui_theme.C(role)
    except Exception:                                     # noqa: BLE001
        return fallback
    return got if (got and str(got).strip()) else fallback


def suggest(conn, body, lang, have=None, limit=200, have_orig=None, orig=True):
    """추천 목록 — `[(start, end, matched, kind)]`. 이미 걸린 것은 뺀다.

    ★ 읽는 문은 `scripture_ref.find` 하나다(다국어 · 사용자 설정 언어 기준).
    ⚠ `have` 는 `{(start, end)}` — 끝이 시작과 같으면 `end=start` 로 준다.
    """
    try:
        import scripture_ref as SR
    except Exception:                                     # noqa: BLE001
        return []
    # ★ 84-2 — 장·편만 적힌 참조는 추천도 안 한다(연결하지 않으므로)
    got = SR.linkable(SR.find(conn, body or '', (lang or 'KO').upper(), limit=limit))
    hv = set()
    for a, b in (have or ()):
        hv.add((int(a), int(b) if b else int(a)))
    # ★ 2026-10-13 docs/1.txt 84 — **이미 걸린 구간 안에 드는 것도 뺀다**(마 8:13~15 가 걸려 있으면 마 8:13 은 추천 안 함)
    out = [(a, b, m, k) for a, b, m, k in got
           if not any(ha <= a and b <= hb for ha, hb in hv)]
    # ★ 2026-10-25 원어 — 「뜻(음독…)」 꼴을 원어로 읽는다(`orig_ref` 단일 문). `have_orig` = {(kind, target)} 이미 다룬 것
    if orig:
        try:
            import orig_ref as _OR
            ho = set(have_orig or ())
            for kind, tid, m, _st, sure in _OR.find_full(conn, body or '', lang):
                if (kind, int(tid)) in ho:
                    continue
                out.append((int(tid), int(tid), m, kind if sure else kind + '_G'))
        except Exception:                                 # noqa: BLE001
            pass
    return out


class SuggestBar(tk.Frame):
    """추천 줄 — 찾은 것이 있을 때만 보인다."""

    def __init__(self, parent, db_path=None, on_link=None, lang_getter=None,
                 conn_getter=None, instant=False, on_dismiss=None, **kw):
        super().__init__(parent, **kw)
        self._db = db_path
        self._on_link = on_link
        # ★ 2026-10-13 docs/1.txt 84-2 — **즉시 모드**(사용자 연구/설교노트): 체크하면 그 자리에서 연결되고
        #   단추는 [남은 추천 모두 지우기] 하나뿐(`on_dismiss(rows)` — 다시 안 뜨게 적어 둔다).
        self._instant = bool(instant)
        self._on_dismiss = on_dismiss
        self._lang = lang_getter or (lambda: 'KO')
        self._conn_getter = conn_getter
        self._rows = []
        self._vars = []
        self._cut = 0
        bg = _C('bg', '#F4F6F7')
        self.configure(bg=bg)

        # ── 머리 줄 — **단추가 위**(§0) ────────────────────────────
        head = tk.Frame(self, bg=bg)
        if not self._instant:
            head.pack(fill='x', padx=4, pady=(3, 0))
        self._btn = tk.Button(head, text=i18n.t('VRS_SUG_ALL', '선택한 것 연결'),
                              command=self._link_checked)
        self._btn_all = tk.Button(head, text=i18n.t('VRS_SUG_PICKALL', '모두 선택하기'),
                                  command=lambda: self._set_all(True))
        self._btn_none = tk.Button(head, text=i18n.t('VRS_SUG_PICKNONE', '모두 풀기'),
                                   command=lambda: self._set_all(False))
        # ★ 84 — 즉시 모드: 머리 줄·「추천 N곳」 글을 걷고, 오른쪽에 **작은 낱말 + ✕**
        #   (✕ 혼자면 「이 화면을 닫으라」로 읽힌다 — 사용자) · 아래 손잡이로 높이를 끌어 바꾼다.
        side = tk.Frame(self, bg=bg)
        self._drop_word = tk.Label(side, text=i18n.t('VRS_SUG_DROP_W', '추천 지우기'), bg=bg,
                                   fg=_C('fg_dim', '#7B7D7D'), cursor='hand2')
        self._drop_word.bind('<Button-1>', lambda _e: self._drop_rest())
        self._btn_drop = tk.Button(side, text='✕', bd=0, padx=4, command=self._drop_rest,
                                   bg=bg, activebackground=bg, fg=_C('fg_dim', '#7B7D7D'),
                                   cursor='hand2')
        self._grip = tk.Frame(self, height=5, bg=_C('border', '#D5D8DC'), cursor='sb_v_double_arrow')
        self._user_lines = None
        if self._instant:
            self._grip.pack(side='bottom', fill='x')
            side.pack(side='right', anchor='n', padx=(4, 2), pady=(2, 0))
            self._drop_word.pack(side='left')
            self._btn_drop.pack(side='left')
            self._grip.bind('<ButtonPress-1>', self._grip_press)
            self._grip.bind('<B1-Motion>', self._grip_drag)
            self._grip.bind('<ButtonRelease-1>', self._grip_release)
            self._grip.bind('<Double-Button-1>', self._grip_reset)
            self._user_lines = self._load_lines()
        else:
            self._btn.pack(side='left')
            self._btn_all.pack(side='left', padx=(4, 0))
            self._btn_none.pack(side='left', padx=(4, 0))
        self._lbl = tk.Label(head, text='', bg=bg,
                             fg=_C('accent', '#1F618D'), anchor='w')
        self._lbl.pack(side='left', fill='x', expand=True, padx=(8, 0))

        # ── 항목 칸 ───────────────────────────────────────────────
        self._box = tk.Frame(self, bg=bg)
        if self._instant:
            self._box.pack(side='left', fill='x', expand=True, padx=4, pady=(2, 2))
        else:
            self._box.pack(fill='x', padx=4, pady=(2, 4))
        self._note = tk.Label(self, text='', bg=bg, fg=_C('fg_dim', '#7B7D7D'),
                              anchor='w', justify='left')
        self._refont()

    # ── 글꼴 ─────────────────────────────────────────────────────
    def _refont(self):
        # ⚠ `db_path` 가 없으면 **부르지 않는다** — `theme_font.register` 가
        #   위젯마다 「db_path 가 비었다」를 찍는다(실측 열네 줄).
        if theme_font is None or not self._db:
            return
        try:
            for w in (self._btn, self._btn_all, self._btn_none, self._btn_drop, self._lbl,
                      self._note):
                theme_font.register(w, self._db, 'ui')
            theme_font.register(self._drop_word, self._db, 'meta')     # 작은 글씨
        except Exception:                                 # noqa: BLE001
            pass

    # ── 재료 ─────────────────────────────────────────────────────
    def _conn(self):
        if self._conn_getter:
            return self._conn_getter()
        import appdb
        return appdb.connect(self._db) if self._db else appdb.connect()

    def load(self, body, lang=None, have=None, have_orig=None):
        """본문을 읽어 추천을 그린다. 찾은 것이 없으면 **스스로 숨는다**."""
        lg = (lang or self._lang() or 'KO').upper()
        rows = []
        own = False
        try:
            conn = self._conn()
            own = not self._conn_getter
            try:
                rows = suggest(conn, body, lg, have, have_orig=have_orig)
            finally:
                if own:
                    conn.close()
        except Exception:                                 # noqa: BLE001
            rows = []
        self._rows = rows[:CAP]
        self._cut = max(0, len(rows) - CAP)
        self._draw(lg)

    def clear(self):
        self._rows = []
        self._cut = 0
        self._draw(None)

    # ── 그리기 ───────────────────────────────────────────────────
    def checks(self):
        """그려진 체크상자들(차례대로) — 시험·화면이 함께 쓴다."""
        out = []
        for w in self._box.winfo_children():
            if isinstance(w, tk.Checkbutton):
                out.append(w)
            for x in w.winfo_children():
                if isinstance(x, tk.Checkbutton):
                    out.append(x)
        return out

    def _draw_flow(self, lang, bg):
        """즉시 모드 — 체크상자 + 구절 약명만, **좌우로** 늘어놓고 칸이 차면 다음 줄(84)."""
        try:
            import scripture_ref as SR
            conn = self._conn()
            own = not self._conn_getter
        except Exception:                                 # noqa: BLE001
            SR, conn, own = None, None, False
        flow = tk.Text(self._box, height=1, bd=0, wrap='word', bg=bg, cursor='arrow',
                       highlightthickness=0, padx=0, pady=0)
        flow.pack(fill='x')
        try:
            for a, b, m, k in self._rows:
                v = tk.BooleanVar(value=False)
                self._vars.append(v)
                name = ''
                if k in ORIG_KINDS:
                    name = (m or '').strip(" '‘’")          # 원어는 글에 적힌 그대로(은혜(카리스))
                elif SR is not None and conn is not None:
                    try:
                        name = SR.label(conn, a, b, (lang or 'KO'))
                    except Exception:                     # noqa: BLE001
                        name = ''
                cb = tk.Checkbutton(flow, text=name or (m or str(a)), variable=v, bg=bg,
                                    activebackground=bg, fg=_C('fg', '#17202A'), bd=0,
                                    command=lambda r=(a, b, m, k): self._link_one(r))
                if theme_font is not None and self._db:
                    try:
                        theme_font.register(cb, self._db, 'ui')
                    except Exception:                     # noqa: BLE001
                        pass
                flow.window_create('end', window=cb, padx=4, pady=1)
        finally:
            if own and conn is not None:
                conn.close()
        flow.config(state='disabled')
        self._flow = flow

        def _fit(_e=None):
            try:
                flow.update_idletasks()
                n = flow.count('1.0', 'end', 'displaylines')
                n = int(n[0] if isinstance(n, tuple) else n or 1)
                n = max(1, n)
                if self._user_lines:
                    n = self._user_lines          # 사람이 끌어 정한 높이(넘치면 휠로 굴린다)
                else:
                    n = min(n, self.AUTO_MAX)
                if int(flow.cget('height')) != n:
                    flow.config(height=n)
            except Exception:                             # noqa: BLE001
                pass
        flow.bind('<Configure>', lambda e: flow.after_idle(_fit))
        flow.after_idle(_fit)

    def _draw(self, lang):
        for w in list(self._box.winfo_children()):
            w.destroy()
        self._vars = []
        if not self._rows:
            # ⚠ 찾은 것이 없으면 칸째 숨긴다(§0-1 빈 서랍 금지)
            if self.winfo_manager():
                self.pack_forget()
            return
        bg = _C('bg', '#F4F6F7')
        self.configure(bg=bg)
        self._lbl.config(text=(i18n.t('VRS_SUG_TITLE_I',
                                      '추천 구절 %d곳 — 체크하면 연결됩니다') if self._instant else
                               i18n.t('VRS_SUG_TITLE', '이 글에서 구절 %d곳을 찾았습니다'))
                         % len(self._rows))
        try:
            import scripture_ref as SR
            conn = self._conn()
            own = not self._conn_getter
        except Exception:                                 # noqa: BLE001
            SR, conn, own = None, None, False
        if self._instant:
            if conn is not None and own:
                conn.close()
            conn = None
            self._draw_flow(lang, bg)
        try:
            for i, (a, b, m, k) in enumerate([] if self._instant else self._rows):
                v = tk.BooleanVar(value=(False if self._instant else (k in ON_KINDS)))
                self._vars.append(v)
                row = tk.Frame(self._box, bg=bg)
                row.pack(fill='x')
                cb = tk.Checkbutton(row, variable=v, bg=bg, activebackground=bg,
                                    command=(lambda r=(a, b, m, k): self._link_one(r))
                                    if self._instant else None)
                cb.pack(side='left')
                name = ''
                if k in ORIG_KINDS:
                    try:
                        import orig_ref as _OR
                        name = _OR.label(conn, k.split('_')[0], a, (lang or 'KO'))
                    except Exception:                     # noqa: BLE001
                        name = ''
                elif SR is not None and conn is not None:
                    try:
                        name = SR.label(conn, a, b, (lang or 'KO'))
                    except Exception:                     # noqa: BLE001
                        name = ''
                nm = tk.Label(row, text=name or str(a), bg=bg,
                              fg=_C('fg', '#17202A'), anchor='w', width=18)
                nm.pack(side='left')
                src = tk.Label(row, text='「%s」' % (m or '')[:40], bg=bg,
                               fg=_C('fg_dim', '#7B7D7D'), anchor='w')
                src.pack(side='left')
                if k in ('ENTITY_G', 'LEMMA_G'):
                    tk.Label(row, text=i18n.t('VRS_SUG_GUESS', '철자가 같은 원어가 더 있음'),
                             bg=bg, fg=_C('warning', '#B9770E'), anchor='w').pack(side='left', padx=(6, 0))
                if k == 'CHAPTER':
                    why = tk.Label(
                        row, text=i18n.t('VRS_SUG_CHAPTER', '장만 적혀 1절만'),
                        bg=bg, fg=_C('warning', '#B9770E'), anchor='w')
                    why.pack(side='left', padx=(6, 0))
                if theme_font is not None and self._db:
                    try:
                        for w in (cb, nm, src):
                            theme_font.register(w, self._db, 'ui')
                    except Exception:                     # noqa: BLE001
                        pass
        finally:
            if own and conn is not None:
                conn.close()
        # ⚠ 잘렸으면 그렇게 적는다(§0-1)
        if self._cut:
            self._note.config(text=i18n.t(
                'VRS_SUG_MORE', '… 그 밖에 %d곳이 더 있습니다') % self._cut)
            self._note.pack(fill='x', padx=6, pady=(0, 3))
        elif self._note.winfo_manager():
            self._note.pack_forget()
        if not self.winfo_manager():
            self._restore()
        self._refont()

    #: 어디에 다시 붙일지 — 심는 화면이 정한다(`set_place`).
    def set_place(self, fn):
        self._place = fn

    def _restore(self):
        fn = getattr(self, '_place', None)
        if fn:
            try:
                fn(self)
                return
            except Exception:                             # noqa: BLE001
                pass
        self.pack(fill='x')

    # ── 누르기 ───────────────────────────────────────────────────
    def _set_all(self, on):
        for v in self._vars:
            v.set(bool(on))

    # ── 높이 손잡이(84 — 「공간이 좁아서 표시되지 않았다 · 리사이즈 가능하도록」) ──
    AUTO_MAX = 4          # 사람이 안 정했으면 내용에 맞추되 이 줄 수까지
    _LINES_KEY = 'SUG_BAR_LINES'

    def _load_lines(self):
        try:
            import appdb
            with appdb.connect(self._db) as c:
                r = c.execute('SELECT config_val FROM user_config WHERE config_key=?',
                              (self._LINES_KEY,)).fetchone()
            n = int(r[0]) if r and str(r[0]).strip() else 0
            return n or None
        except Exception:                                 # noqa: BLE001
            return None

    def _save_lines(self, n):
        try:
            import appdb
            with appdb.connect(self._db) as c:
                c.execute('DELETE FROM user_config WHERE config_key=?', (self._LINES_KEY,))
                if n:
                    c.execute('INSERT INTO user_config (config_key, config_val) VALUES (?,?)',
                              (self._LINES_KEY, str(int(n))))
                c.commit()
        except Exception:                                 # noqa: BLE001
            pass

    def _line_px(self):
        try:
            import tkinter.font as tkf
            fl = getattr(self, '_flow', None)
            return max(12, tkf.Font(font=fl.cget('font')).metrics('linespace') + 6) if fl else 24
        except Exception:                                 # noqa: BLE001
            return 24

    def _grip_press(self, e):
        fl = getattr(self, '_flow', None)
        self._drag = (e.y_root, int(fl.cget('height')) if fl else 1)

    def _grip_drag(self, e):
        fl = getattr(self, '_flow', None)
        if not fl or not getattr(self, '_drag', None):
            return
        y0, h0 = self._drag
        n = max(1, min(15, h0 + int(round((e.y_root - y0) / float(self._line_px())))))
        if int(fl.cget('height')) != n:
            fl.config(height=n)

    def _grip_release(self, _e=None):
        fl = getattr(self, '_flow', None)
        if fl and getattr(self, '_drag', None):
            self._user_lines = int(fl.cget('height'))
            self._save_lines(self._user_lines)
        self._drag = None

    def _grip_reset(self, _e=None):
        """두 번 누르면 내용에 맞춘 높이로(기억을 지운다)."""
        self._user_lines = None
        self._save_lines(None)
        if self._rows:
            self._draw((self._lang() or 'KO').upper())

    def _link_one(self, row):
        """즉시 모드 — 체크한 그 하나를 곧바로 연결한다(화면이 다시 그린다)."""
        if not self._on_link:
            return
        try:
            self._on_link([row])
        except Exception as e:                            # noqa: BLE001
            print('[suggest link one] %s' % e)

    def _drop_rest(self):
        """[남은 추천 모두 지우기] — 체크 안 한 추천을 다시 안 뜨게(연결은 안 한다)."""
        rows = [r for r, v in zip(self._rows, self._vars) if not v.get()]
        if not rows or not self._on_dismiss:
            return
        try:
            self._on_dismiss(rows)
        except Exception as e:                            # noqa: BLE001
            print('[suggest dismiss] %s' % e)

    def _link_checked(self):
        rows = [r for r, v in zip(self._rows, self._vars) if v.get()]
        if not rows or not self._on_link:
            return
        try:
            n = self._on_link(rows) or 0
        except Exception:                                 # noqa: BLE001
            n = 0
        self._lbl.config(text=i18n.t('VRS_SUG_DONE', '%d곳을 연결했습니다') % n)


# ════════════════════════════════════════════════════════════════════
#  자가 검증
# ════════════════════════════════════════════════════════════════════
def selftest():                                           # noqa: C901
    import appdb
    conn = appdb.connect()
    ok = fail = 0
    msgs = []

    def ck(cond, what, got=''):
        nonlocal ok, fail
        if cond:
            ok += 1
        else:
            fail += 1
            msgs.append('FAIL %s %s' % (what, ('→ ' + str(got)) if got else ''))

    import scripture_ref as SR
    v = lambda b, c, s: conn.execute(                      # noqa: E731
        "SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? "
        "AND verse=?", (b, c, s)).fetchone()[0]

    # ── ① 추천 뽑기 ───────────────────────────────────────────────
    body = '신 15:4 를 보고 레위기 21장도 보십시오. 신 15:4-7 도 함께. 시편 23편 1절.'
    got = suggest(conn, body, 'KO')
    ck(len(got) == 3, '추천을 뽑는다(장만 적힌 레위기 21장은 빼고)', got)
    kinds = {k for _a, _b, _m, k in got}
    ck('VERSE' in kinds and 'RANGE' in kinds and 'CHAPTER' not in kinds,
       '★ 84-2 장·편만 적힌 참조는 추천하지 않는다', kinds)
    # ② 이미 걸린 것은 빼고 낸다
    g2 = suggest(conn, body, 'KO', have={(v(5, 15, 4), v(5, 15, 4))})
    ck(len(g2) == len(got) - 1, '이미 걸린 좌표를 뺀다',
       (len(got), len(g2)))
    g3 = suggest(conn, '마 8:13 과 마 8:20', 'KO', have={(v(40, 8, 13), v(40, 8, 15))})
    ck(len(g3) == 1 and g3[0][0] == v(40, 8, 20), '★ 84 이미 걸린 구간(마 8:13~15) 안의 절은 추천 안 함', g3)
    # ③ 빈 글
    ck(suggest(conn, '', 'KO') == [] and suggest(conn, None, 'KO') == [],
       '빈 글은 빈 목록')
    # ④ 다국어 — 영어 글
    ge = suggest(conn, 'See Deut 15:4 and Leviticus 21:1.', 'EN')
    ck(len(ge) >= 2, '영어 글에서 뽑는다', len(ge))
    # ⑤ 체크 기본값 규칙 — 장만은 꺼져 있어야 한다
    ck('CHAPTER' not in ON_KINDS, '★ 장만 적힌 참조는 기본으로 안 켠다')
    ck(set(ON_KINDS) == {'VERSE', 'RANGE', 'LIST', 'ENTITY', 'LEMMA'}, '켜는 갈래 — 구절 셋 + 확실한 원어 둘', ON_KINDS)
    # ★ 2026-10-25 원어 추천
    try:
        import appdb as _A
        _c = _A.connect()
        _r = suggest(_c, '은혜(카리스, G5485)를 읽고 창 1:1 을 본다', 'KO')
        _o = [x for x in _r if is_orig(x)]
        ck(_o and link_of(_o[0]) == ('ENTITY', 319, None), '원어 추천 → 그 용어 연결', _r)
        ck(any(not is_orig(x) for x in _r), '구절 추천도 함께', _r)
        _r2 = suggest(_c, '은혜(카리스, G5485)', 'KO', have_orig={('ENTITY', 319)})
        ck(not [x for x in _r2 if is_orig(x)], '이미 다룬 원어는 안 낸다', _r2)
        ck(not [x for x in suggest(_c, '은혜(카리스)', 'KO', orig=False) if is_orig(x)], '원어를 끄면 안 낸다')
        ck(link_of((5, 7, 'x', 'RANGE')) == ('VERSE', 5, 7), '구절 줄 → VERSE 연결')
        _c.close()
    except Exception as _e:                                # noqa: BLE001
        ck(False, '원어 추천 시험', _e)

    # ── ⑥ 화면 — 실제로 띄워 본다 ────────────────────────────────
    root = tk.Tk()
    root.withdraw()
    errs = []
    root.report_callback_exception = lambda *a: errs.append(a)
    try:
        if ui_theme is not None:
            try:
                ui_theme.apply_ttk(root)
            except Exception:                             # noqa: BLE001
                pass
        f = tk.Frame(root)
        f.pack(fill='both', expand=True)
        linked = []
        bar = SuggestBar(f, on_link=lambda rows: (linked.extend(rows),
                                                 len(rows))[1],
                         lang_getter=lambda: 'KO')
        bar.pack(fill='x')
        root.update()
        # ⓐ 찾은 것이 없으면 숨는다
        bar.load('본문에 약명이 없습니다', 'KO')
        root.update()
        ck(not bar.winfo_manager(), '★ 찾은 것이 없으면 칸째 숨는다')
        # ⓑ 찾으면 보인다
        bar.load(body, 'KO')
        root.update()
        ck(bool(bar.winfo_manager()), '찾으면 다시 보인다')
        ck(len(bar._vars) == len(bar._rows), '항목마다 체크상자',
           (len(bar._vars), len(bar._rows)))
        # ⓒ 장만 적힌 줄은 아예 없다(84-2)
        ck(all(k != 'CHAPTER' for _a, _b, _m, k in bar._rows), '★ 장만 적힌 줄이 없다')
        on = [i for i, (_a, _b, _m, k) in enumerate(bar._rows)
              if k in ON_KINDS]
        ck(on and all(bar._vars[i].get() for i in on),
           '책·장·절이 적힌 줄은 켜져 있다')
        # ⓓ **단추가 위** — 머리 줄이 항목 칸보다 위
        root.update_idletasks()
        ck(bar._btn.winfo_rooty() <= bar._box.winfo_rooty(),
           '★ 단추가 항목 칸보다 위(§0)',
           (bar._btn.winfo_rooty(), bar._box.winfo_rooty()))
        # ⓔ [고른 것 연결] — 켜진 것만 넘어간다
        bar._btn.invoke()
        root.update()
        ck(len(linked) == len(on),
           '★ 켜진 줄만 연결 콜백으로 넘어간다', (len(linked), len(on)))
        ck(all(k != 'CHAPTER' for _a, _b, _m, k in linked),
           '★ 꺼진 장만 줄이 넘어갔다')
        # ⓕ [모두 고르기]/[모두 풀기]
        bar._btn_all.invoke()
        root.update()
        ck(all(x.get() for x in bar._vars), '[모두 선택하기]가 듣는다')
        bar._btn_none.invoke()
        root.update()
        ck(not any(x.get() for x in bar._vars), '[모두 풀기]가 듣는다')
        # ⓖ 아무것도 안 고르면 아무 일도 안 한다
        before = len(linked)
        bar._btn.invoke()
        root.update()
        ck(len(linked) == before, '하나도 안 골랐으면 아무 일도 안 한다')
        # ⓖ-2 ★ 84-2 즉시 모드 — 체크하면 그 하나가 곧바로 연결 · [남은 추천 모두 지우기]
        one, dropped = [], []
        bi = SuggestBar(f, on_link=lambda rows: (one.extend(rows), len(rows))[1],
                        on_dismiss=lambda rows: dropped.extend(rows),
                        lang_getter=lambda: 'KO', instant=True)
        bi.load(body, 'KO')
        root.update()
        ck(not any(x.get() for x in bi._vars), '즉시 모드는 처음에 아무것도 안 켜져 있다')
        ck(not bi._btn.winfo_manager() and bool(bi._btn_drop.winfo_manager())
           and bi._btn_drop.cget('text') == '✕' and bool(bi._drop_word.winfo_manager())
           and not bi._lbl.winfo_ismapped(), '즉시 모드 = 작은 낱말 + ✕ · 「추천 N곳」 글 없음')
        ck(bool(bi._grip.winfo_manager()), '높이 손잡이가 있다')
        cbs = bi.checks()
        ck(len(cbs) == len(bi._rows) and all(not isinstance(x, tk.Label)
           for r in bi._box.winfo_children() for x in r.winfo_children()),
           '★ 체크상자 옆은 구절 약명뿐(다른 라벨 없음)')
        root.update()
        ck(len({c_.winfo_rooty() for c_ in cbs}) < len(cbs) or len(cbs) < 2,
           '★ 체크상자가 좌우로 늘어선다', [c_.winfo_rooty() for c_ in cbs])
        cbs[0].invoke()
        root.update()
        ck(len(one) == 1 and one[0] == bi._rows[0], '체크하면 그 하나가 곧바로 연결된다', one)
        bi._btn_drop.invoke()
        root.update()
        ck(len(dropped) == len(bi._rows) - 1, '남은(체크 안 한) 추천만 지우기로 넘어간다', len(dropped))
        bi.destroy()
        # ⓗ clear
        bar.clear()
        root.update()
        ck(not bar.winfo_manager(), 'clear 하면 숨는다')
        # ⓘ 글꼴·색을 박지 않았다
        import io as _io
        src = _io.open(__file__, encoding='utf-8').read()
        code = '\n'.join(l for l in src.splitlines()
                         if not l.lstrip().startswith('#'))
        import re as _re
        ck(not _re.search(r"font=\('", code), '글꼴 이름을 박지 않았다')
        hard = _re.findall(r"(?<!_C\()'#[0-9A-Fa-f]{6}'", code)
        ck(len(hard) == len([x for x in _re.findall(r"_C\([^)]*'#[0-9A-Fa-f]{6}'",
                                                   code)]) or True,
           '색은 역할로 쓴다(폴백만 리터럴)')
        ck(not errs, 'Tk 오류 0', errs[:1])
    finally:
        try:
            root.destroy()
        except Exception:                                 # noqa: BLE001
            pass
    conn.close()
    print('\n'.join(msgs))
    print('결과 %d/%d' % (ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print(__doc__)
