# -*- coding: utf-8 -*-
"""db_commentary_endvid.py — 범위형 주석 항목의 end_vid 복원 (영구 도구, 멱등)

  python -X utf8 db_commentary_endvid.py            # 미리보기(기본, DB 무변경)
  python -X utf8 db_commentary_endvid.py --apply    # 적용
  python -X utf8 db_commentary_endvid.py --restore  # 백업에서 원복

**무엇을 고치나.** BARNES 는 병행 단락을 한 항목으로 묶으면서 본문 첫머리에
`Verses 32-44.` 라고 적는다. 그런데 임포트가 `end_vid` 를 채우지 않아
(33,178행 중 29,716행이 NULL) **33~44절이 '주석 없음'으로 집계된다.**

그래서 커버리지가 실제보다 크게 낮아 보였다 —
마가 39% · 마태 78% · 누가 52%. 원문에 없는 것이 아니라 **우리 컬럼이 비어 있던 것**이다.

**왜 지금 고치나.** 2026-08-02 부터 페리코프·장 설명문의 배경을 이 DB 에서 가져온다
(peri.md §3-3b). `db_peri_prep --comm` 의 조회가 `start_vid=? OR (start_vid<=? AND
end_vid>=?)` 라서, end_vid 가 없으면 **범위 항목이 그 범위의 첫 절에서만 잡힌다.**
마가·마태·누가가 다음 작업 대상이라 지금이 고칠 때다.

**안전 장치.** 본문이 스스로 말하는 범위만 쓴다(추정 없음). 시작 절 번호가 실제
매핑과 일치할 때만 고친다. 이미 end_vid 가 있으면 건드리지 않는다. 원본은
`temp_comm_endvid_backup` 에 남기고 `--restore` 로 되돌린다.
"""
import argparse
import re
import sys

import appdb

DB = 'bible_master.db'
BACKUP = 'temp_comm_endvid_backup'
# 본문 첫머리의 범위 표기. `Verses 32-44.` · `Verses 2,3` · `Ver. 5-8`
RANGE = re.compile(r'^\s*Ver(?:s|se|ses)?\.?\s+(\d+)\s*[-–,]\s*(\d+)', re.I)


def plan(conn):
    """고칠 수 있는 (entry_id, start_vid, new_end_vid, 라벨) 목록."""
    rows = conn.execute(
        """SELECT e.entry_id, e.start_vid, s.commentary_code, x.body_text
             FROM sys_commentary_entry e
             JOIN sys_commentary_source s ON s.commentary_id = e.commentary_id
             JOIN sys_commentary_text  x ON x.entry_id = e.entry_id
            WHERE e.end_vid IS NULL AND x.text_variant = 'ORIGINAL'
              AND COALESCE(e.record_status,'LIVE') = 'LIVE'""").fetchall()
    out, skipped = [], 0
    for eid, sv, code, body in rows:
        m = RANGE.match(body or '')
        if not m:
            continue
        a, b = int(m.group(1)), int(m.group(2))
        if b <= a:
            continue
        r = conn.execute('SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?',
                         (sv,)).fetchone()
        if not r:
            continue
        # ⚠ 본문이 말하는 시작 절과 매핑이 어긋나면 손대지 않는다. 그건 매핑 문제이지
        #   범위 문제가 아니고(db_commentary_audit.py 의 몫), 여기서 고치면 오류를 굳힌다.
        if r[2] != a:
            skipped += 1
            continue
        tgt = conn.execute('SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? '
                           'AND verse=?', (r[0], r[1], b)).fetchone()
        if not tgt or tgt[0] <= sv:
            continue
        out.append((eid, sv, tgt[0], code, f'{r[0]} {r[1]}:{a}-{b}', tgt[0] - sv))
    return out, skipped


def coverage(conn, bcode, code):
    nv = conn.execute('SELECT COUNT(*) FROM bible_index WHERE bcode=?', (bcode,)).fetchone()[0]
    n = conn.execute(
        """SELECT COUNT(DISTINCT bi.verse_id) FROM bible_index bi
             JOIN sys_commentary_entry e ON (e.start_vid = bi.verse_id
                   OR (e.start_vid <= bi.verse_id AND e.end_vid >= bi.verse_id))
             JOIN sys_commentary_source s ON s.commentary_id = e.commentary_id
            WHERE bi.bcode=? AND s.commentary_code=?""", (bcode, code)).fetchone()[0]
    return 100 * n / nv if nv else 0


BOOKS = (40, 41, 42, 43, 44, 45, 58, 66)


def report(conn, tag):
    names = dict(conn.execute("SELECT book_code, full_name FROM book_names "
                              "WHERE lang_code='KO'"))
    print(f'  {tag}  ' + ' · '.join(
        f'{names.get(b, b)} {coverage(conn, b, "BARNES_NT"):.0f}%' for b in BOOKS))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--restore', action='store_true')
    a = ap.parse_args()
    conn = appdb.connect(DB)

    if a.restore:
        n = conn.execute(f"SELECT COUNT(*) FROM sqlite_master WHERE type='table' "
                         f"AND name='{BACKUP}'").fetchone()[0]
        if not n:
            print(f'{BACKUP} 없음 — 원복할 것이 없다'); sys.exit(1)
        cur = conn.execute(
            f"UPDATE sys_commentary_entry SET end_vid = "
            f"(SELECT old_end_vid FROM {BACKUP} b WHERE b.entry_id = sys_commentary_entry.entry_id) "
            f"WHERE entry_id IN (SELECT entry_id FROM {BACKUP})")
        conn.commit()
        print(f'원복 {cur.rowcount}행')
        report(conn, '원복 후')
        return

    items, skipped = plan(conn)
    by_src = {}
    for _e, _s, _t, code, _lbl, span in items:
        d = by_src.setdefault(code, [0, 0])
        d[0] += 1
        d[1] += span
    print('=== 본문이 스스로 말하는 범위로 end_vid 를 채운다 ===')
    for code, (n, span) in sorted(by_src.items()):
        print(f'  {code:<12} 항목 {n:>4}개 · 새로 덮이는 절 {span:>5}개')
    if skipped:
        print(f'  (시작 절이 매핑과 어긋나 건너뜀 {skipped}건 — '
              f'db_commentary_audit.py 로 따로 볼 것)')
    if not items:
        print('  고칠 것 없음'); return
    print()
    report(conn, '지금 ')

    if not a.apply:
        print('\n(적용하려면 --apply)')
        return

    conn.execute(f'CREATE TABLE IF NOT EXISTS {BACKUP} '
                 f'(entry_id INTEGER PRIMARY KEY, old_end_vid INTEGER)')
    for eid, _sv, tgt, _c, _l, _sp in items:
        conn.execute(f'INSERT OR IGNORE INTO {BACKUP}(entry_id, old_end_vid) '
                     f'SELECT entry_id, end_vid FROM sys_commentary_entry WHERE entry_id=?',
                     (eid,))
        conn.execute('UPDATE sys_commentary_entry SET end_vid=? WHERE entry_id=?', (tgt, eid))
    conn.commit()
    print(f'\n적용 {len(items)}행 (백업 {BACKUP})')
    report(conn, '보정 후')
    print('\n  남은 공백은 저자가 상호 참조로 넘긴 자리다 '
          '(막 6:1 "See Barnes Mt 13:54") — 원문에 없는 것이므로 보완 대상이 아니다.')


if __name__ == '__main__':
    main()
