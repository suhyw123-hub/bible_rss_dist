# -*- coding: utf-8 -*-
"""reading_font.py — '지원/설정 ▸ 폰트' 설정을 읽어 위젯에 적용하는 공용 헬퍼.

저장소: user_config['READING_FONT'] = {"family":..., "size":..., "spacing":...}
(설정 화면 `settings_view._save_font` 와 `p1_reading_view` 가 쓰던 바로 그 키다.)

**적용 범위 원칙 (2026-07-30 사용자 결정)**
- 적용   : 길게 읽는 텍스트 — 도서/설교 본문 · P1 성경 본문 · 구절 설명문
           (P2 탭1 / P4 탭1 캔버스 슬라이딩 패널 탭1 / P4 탭2 트리뷰 우측 탭1)
- 비적용 : 트리뷰·콤보·버튼·탭 라벨 등 UI 크롬(레이아웃이 깨진다), 관리자 앱

새로 '읽는 본문' 위젯을 만들면 여기 `apply_text()`/`apply_widget()` 을 호출한다.
폰트 크기를 각 화면에서 하드코딩하지 말 것.
"""

import json

import appdb

DEFAULTS = {'family': 'Georgia', 'size': '10', 'spacing': '기본'}

# 줄간격 라벨 → 추가 픽셀. p1_reading_view._SPACING_PX 와 같은 값을 쓴다.
SPACING_PX = {'기본': 0, '넓게': 3, '아주 넓게': 6}

# ── 읽기 설정 항목 (2026-08-12 신설) ─────────────────────────────────────────
# 「독서 느낌」을 위해 픽셀 단위 항목을 더했다. 옛 `spacing` 라벨('기본'·'넓게')은
# 그대로 두고, 새 키가 있으면 그것이 이긴다 — 이미 설정해 둔 사용자의 값을 지우지 않는다.
#   line_gap : 한 절이 여러 줄로 흐를 때 **그 줄 사이**(Text spacing2).
#              ⚠ P1 이 Listbox 이던 시절에는 wrap 이 없어 이 값을 일부러 꺼 두었다.
#                 이제는 이것이 독서감을 가장 크게 좌우한다.
#   para_gap : 절과 절 사이 (spacing1/spacing3)
#   margin   : 좌우 여백 (padx)
LIMITS = {'line_gap': (0, 14), 'para_gap': (0, 20), 'margin': (0, 60)}
NEW_DEFAULTS = {'line_gap': 2, 'para_gap': 4, 'margin': 10}


def _clamp(key, val, dflt):
    lo, hi = LIMITS[key]
    try:
        return max(lo, min(hi, int(val)))
    except Exception:
        return dflt


def load(db_path):
    """설정값 → {'family', 'size', 'spacing_px', 'line_gap', 'para_gap', 'margin'}.
    실패해도 기본값을 돌려준다."""
    cfg = {}
    try:
        with appdb.connect(db_path) as conn:
            row = conn.execute(
                "SELECT config_val FROM user_config WHERE config_key='READING_FONT'").fetchone()
        if row and row[0]:
            cfg = json.loads(row[0])
    except Exception:
        cfg = {}
    d = {**DEFAULTS, **(cfg if isinstance(cfg, dict) else {})}
    try:
        size = int(str(d.get('size') or DEFAULTS['size']).strip())
    except Exception:
        size = int(DEFAULTS['size'])
    size = max(7, min(40, size))          # 극단값이 레이아웃을 깨뜨리지 않게 clamp

    legacy_px = SPACING_PX.get(d.get('spacing'), 0)
    # para_gap 이 없으면 옛 라벨 값을 그대로 쓴다(하위 호환)
    para = _clamp('para_gap', d.get('para_gap', legacy_px), legacy_px)
    return {'family': d.get('family') or DEFAULTS['family'],
            'size': size,
            'spacing_px': legacy_px,
            'line_gap': _clamp('line_gap', d.get('line_gap', NEW_DEFAULTS['line_gap']),
                               NEW_DEFAULTS['line_gap']),
            'para_gap': para,
            'margin': _clamp('margin', d.get('margin', NEW_DEFAULTS['margin']),
                             NEW_DEFAULTS['margin'])}


def save(db_path, **kw):
    """읽기 설정을 **병합**해 저장한다.

    ⚠ 통째로 덮어쓰지 말 것. `settings_view._save_font` 가 예전에 `{family,size,spacing}`
      3키짜리 dict 를 새로 만들어 저장해서, 다른 화면이 넣어 둔 항목을 날리고 있었다.
    """
    cur = {}
    try:
        with appdb.connect(db_path) as conn:
            row = conn.execute(
                "SELECT config_val FROM user_config WHERE config_key='READING_FONT'").fetchone()
            if row and row[0]:
                cur = json.loads(row[0]) or {}
            cur.update({k: v for k, v in kw.items() if v is not None})
            conn.execute("INSERT INTO user_config (config_key, config_val) VALUES ('READING_FONT', ?) "
                         "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                         (json.dumps(cur, ensure_ascii=False),))
            conn.commit()
    except Exception:
        pass
    return cur


def apply_widget(widget, db_path, size_delta=0):
    """폰트만 적용 (Listbox·Label 등 줄간격 옵션이 없는 위젯)."""
    if widget is None:
        return
    try:
        d = load(db_path)
        widget.config(font=(d['family'], max(7, d['size'] + size_delta)))
    except Exception:
        pass


def apply_text(widget, db_path, size_delta=0, with_line_gap=False):
    """폰트 + 간격 적용 (Text·ScrolledText).

    spacing1=문단 위, spacing3=문단 아래, spacing2=**한 문단이 여러 줄로 흐를 때 그 사이**.

    ⚠ `with_line_gap` 은 기본이 False 다. 설명문·도서 본문은 한 문단이 길게 흐르므로
      줄 사이까지 벌리면 지나치게 성겨진다(2026-07-30 판단). **P1 성경 본문만** 다르다 —
      절마다 문단이 끊기고 wrap 된 줄이 곧 그 절의 이어짐이라 이 값이 독서감을 좌우한다.
    """
    if widget is None:
        return
    try:
        d = load(db_path)
        opts = dict(font=(d['family'], max(7, d['size'] + size_delta)),
                    spacing1=d['para_gap'], spacing3=d['para_gap'])
        if with_line_gap:
            opts['spacing2'] = d['line_gap']
        widget.config(**opts)
    except Exception:
        pass
