# -*- coding: utf-8 -*-
"""역본별 **스트롱 태그 본문** 적재 — 역본차이 판정의 재료 (2026-09-22 신설).

★★★ **왜 필요한가.**
  역본차이 판정의 물음은 「이 역본의 N절이 기준(BSB) 몇 절의 내용인가」다.
  그전에는 그것을 ⓐ 고유명사 닻(273개) ⓑ 스트롱→번역어 자동 학습 사전으로
  짐작했는데, 실측 **사전이 6,071 스트롱 중 959(16%)** 뿐이고 **근거가 4낱말
  이상인 절이 51%** 라 문턱을 조금만 움직여도 후보가 **40배 흔들렸다**
  (14건 ↔ 541건). 짐작이 아니라 **사실**이 필요하다.

★★★ **답 = 번역문에 스트롱이 이미 붙은 판본이 있다.**
  낱말마다 원문 낱말 번호가 달려 있으므로 **집합을 그대로 견주면 된다**:

      BSB  창1:1 {H7225 H1254 H430 H853 H8064 H853 H776}
      CUVS 창1:1 {H9002 H7225 H430 H1254 H8804 H853 H8064 H853 H776}
                  └ 겹침이 크다 = 같은 내용 · 작다 = 어긋남 후보

  사전도 닻도 필요 없다. **기준 역본 BSB 에 스트롱이 붙는 것**이 결정적이다.

★ 받는 것 — 전부 **판권이 깨끗한 것만**(§0-1b 규칙 ④):

  | 우리 역본 | 모듈 | 판권 |
  |---|---|---|
  | BSB (기준) | BSB v2.0 | Creative Commons CC0 |
  | CUVS | ChiUns 和合本 简体 1919 v3.1 | Public Domain |
  | CUV | ChiUn 和合本 繁體 1919 v3.1 | Public Domain |
  | SpaRV | SpaRV Reina-Valera 1909 v2.0 | Public Domain |
  | FreJND | FreJND Darby 2024 v3.3 | Public Domain |
  | ASV | ASV 1901 v2.0 | Public Domain |

  ⚠ **안 받은 것과 까닭** — 한국어 `KorRV` 는 PD 이지만 **스트롱 태그가
    없다**(모듈 428개 전수 확인). 러시아어 둘(`RusVZh`·`RusSynodalLIO`)과
    독일어 `GerSch` 는 **저작권이 살아 있다**. 영어 `KJV` 태그본은 **모듈이
    GPL** 이라 안 받는다(ASV 가 PD 로 같은 자리를 채운다).

⚠⚠⚠ **§0-1b 규칙 ⓪ — 받기 전에 링크를 보이고 확인받는다.**
  `require_ack()` 가 `--links-confirmed` 없이는 **한 바이트도 받지 않는다**.
  2026-09-22 사용자 확인 완료(「필요한 것을 받아서 진행하라」).

⚠⚠ **규칙 ② 의 자리가 다르다** — 도서는 「권위 있는 두 곳 80% 대조」인데
  여기는 **우리 DB 가 이미 같은 판을 갖고 있다.** 받은 본문이 우리 본문과
  글자 그대로 같은가를 재는 것이 두 곳 대조보다 강하다(`--check`).

⚠ **LOCAL 이다 — 배포하지 않는다.** 판정 재료이고, 사용자 화면에 스트롱을
  보이는 것은 별개 결정이다.

쓰는 법
    python db_strong_align.py --selftest
    python db_strong_align.py --links
    python db_strong_align.py --fetch --links-confirmed
    python db_strong_align.py --check [--version BSB]
    python db_strong_align.py --apply [--version BSB]
    python db_strong_align.py --undo
"""
import io
import os
import re
import struct
import sys
import zipfile
import zlib

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)
import appdb                                              # noqa: E402

RAW_DIR = os.path.join(_HERE, '_sword_raw')
BASE_URL = ('https://www.crosswire.org/ftpmirror/pub/sword/'
            'packages/rawzip/%s.zip')

# ── 받을 것 — (우리 역본, 모듈, 소문자 폴더, 판권, 판, 원출처, 제목) ──────
SOURCES = [
    ('BSB', 'BSB', 'bsb', 'Creative Commons CC0', 'v2.0',
     'https://berean.bible/downloads.htm', 'Berean Standard Bible'),
    ('CUVS', 'ChiUns', 'chiuns', 'Public Domain', 'v3.1',
     'http://bible.fhl.net', '和合本 (简体字) 1919'),
    ('CUV', 'ChiUn', 'chiun', 'Public Domain', 'v3.1',
     'http://bible.fhl.net', '和合本 (繁體字) 1919'),
    ('SpaRV', 'SpaRV', 'sparv', 'Public Domain', 'v2.0',
     'https://es.wikisource.org/wiki/Biblia_Reina-Valera_1909',
     'Reina-Valera 1909'),
    ('FreJND', 'FreJND', 'frejnd', 'Public Domain', 'v3.3',
     'https://concordance.bible/media/download/Darby-osis.zip',
     'Bible J.N. Darby 2024'),
    ('ASV', 'ASV', 'asv', 'Public Domain', 'v2.0',
     'http://www.ebible.org/bible/asv/',
     'American Standard Version 1901'),
]

# OSIS 책 약자 → bcode. ⚠ 순서를 세는 것이 아니라 **이름으로** 푼다 —
#   모듈마다 빠진 책이 있을 수 있고, 그때 순서로 세면 통째로 밀린다.
OSIS_BOOKS = [
    'Gen', 'Exod', 'Lev', 'Num', 'Deut', 'Josh', 'Judg', 'Ruth',
    '1Sam', '2Sam', '1Kgs', '2Kgs', '1Chr', '2Chr', 'Ezra', 'Neh',
    'Esth', 'Job', 'Ps', 'Prov', 'Eccl', 'Song', 'Isa', 'Jer', 'Lam',
    'Ezek', 'Dan', 'Hos', 'Joel', 'Amos', 'Obad', 'Jonah', 'Mic',
    'Nah', 'Hab', 'Zeph', 'Hag', 'Zech', 'Mal',
    'Matt', 'Mark', 'Luke', 'John', 'Acts', 'Rom', '1Cor', '2Cor',
    'Gal', 'Eph', 'Phil', 'Col', '1Thess', '2Thess', '1Tim', '2Tim',
    'Titus', 'Phlm', 'Heb', 'Jas', '1Pet', '2Pet', '1John', '2John',
    '3John', 'Jude', 'Rev',
]
BCODE_OF = dict((b, i + 1) for i, b in enumerate(OSIS_BOOKS))

_RX_CH = re.compile(r'<chapter\b[^>]*osisID="([^".]+)\.(\d+)"[^>]*sID=')
_RX_TAG = re.compile(r'<[^>]*>')
_RX_STRONG = re.compile(r'strong:([HG])0*(\d+)')
_RX_DROP = re.compile(r'<(title|note)\b[^>]*>.*?</\1>', re.S)


# ══════════════════════════════════════════════════════════════════════
#  §0-1b 규칙 ⓪ — 받기 전에 링크를 보이고 확인받는다
# ══════════════════════════════════════════════════════════════════════
def links_text():
    """받을 것의 주소·판권·판본을 사람이 읽는 글로."""
    out = ['받을 것 — CrossWire SWORD 모듈 %d개' % len(SOURCES), '']
    for vc, mod, _d, lic, ver, src, title in SOURCES:
        out.append('  [%s] %s  %s' % (vc, title, ver))
        out.append('      판권 : %s' % lic)
        out.append('      원출처: %s' % src)
        out.append('      받을 곳: %s' % (BASE_URL % mod))
    out.append('')
    out.append('⚠ 전부 Public Domain 또는 CC0 이고, 우리가 이미 가진 판과')
    out.append('  같은 판이다(--check 가 본문을 글자로 대조한다).')
    return '\n'.join(out)


def require_ack(argv):
    """`--links-confirmed` 없이는 **한 바이트도 받지 않는다**(§0-1b ⓪)."""
    if '--links-confirmed' in argv:
        return True
    print(links_text())
    print()
    print('⚠ 위 링크를 사용자에게 보이고 확인받은 뒤에만 받는다.')
    print('  확인했으면: --fetch --links-confirmed')
    raise SystemExit(2)


def fetch(argv, out_dir=RAW_DIR):
    """모듈 zip 을 받는다. 이미 있으면 건너뛴다(멱등)."""
    require_ack(argv)
    import urllib.request
    if not os.path.isdir(out_dir):
        os.makedirs(out_dir)
    got = []
    for vc, mod, _d, _l, _v, _s, _t in SOURCES:
        dst = os.path.join(out_dir, mod + '.zip')
        if os.path.exists(dst) and os.path.getsize(dst) > 100000:
            print('  [%s] 이미 있다 (%d바이트)' % (vc, os.path.getsize(dst)))
            got.append(dst)
            continue
        url = BASE_URL % mod
        print('  [%s] 받는다 %s' % (vc, url))
        with urllib.request.urlopen(url, timeout=180) as r:
            data = r.read()
        tmp = dst + '.tmp'
        io.open(tmp, 'wb').write(data)
        os.replace(tmp, dst)      # ⚠ 다 받기 전에는 제 이름을 주지 않는다
        print('      %d바이트' % len(data))
        got.append(dst)
    return got


# ══════════════════════════════════════════════════════════════════════
#  SWORD ztext 읽기 — 표준 라이브러리만 (§1 외부 의존성 없음)
# ══════════════════════════════════════════════════════════════════════
class ZText(object):
    """`ztext` 모듈 하나. zlib 블록 + 12/10바이트 인덱스.

    ⚠ **canon 표를 쓰지 않는다** — 장 헤더의 `osisID` 를 읽고 그 뒤 연속
      인덱스를 1절·2절…로 센다. 모듈마다 절체계가 달라(KJV/NRSV/German)
      개수를 우리가 세면 통째로 밀린다.
    """

    def __init__(self, zip_path, mod):
        self._z = zipfile.ZipFile(zip_path)
        self._p = 'modules/texts/ztext/%s/' % mod

    def _iter(self, tt):
        try:
            bzs = self._z.read(self._p + tt + '.bzs')
            bzz = self._z.read(self._p + tt + '.bzz')
            bzv = self._z.read(self._p + tt + '.bzv')
        except KeyError:
            return
        cache = {}

        def blk(n):
            if n not in cache:
                o, c, _u = struct.unpack('<III', bzs[n * 12:(n + 1) * 12])
                cache[n] = zlib.decompress(bzz[o:o + c])
            return cache[n]

        for i in range(len(bzv) // 10):
            b, s, ln = struct.unpack('<IIH', bzv[i * 10:(i + 1) * 10])
            if ln == 0:
                yield ''
                continue
            try:
                yield blk(b)[s:s + ln].decode('utf-8', 'replace')
            except Exception:
                yield ''

    def verses(self):
        """(osis책, 장, 절, 원본 XML) 을 차례로 낸다."""
        for tt in ('ot', 'nt'):
            bk = None
            ch = 0
            v = 0
            for raw in self._iter(tt):
                m = _RX_CH.search(raw)
                if m:
                    bk, ch, v = m.group(1), int(m.group(2)), 0
                    continue
                if bk is None:
                    continue           # 머리말(milestone)
                v += 1
                yield bk, ch, v, raw


def plain(xml):
    """태그를 걷은 본문. ⚠ 제목·각주는 **본문이 아니다** — 먼저 뺀다."""
    return ' '.join(_RX_TAG.sub('', _RX_DROP.sub('', xml)).split())


def strongs(xml):
    """그 절의 스트롱 번호 목록(나온 차례대로 · 중복 그대로).

    ⚠ **앞의 0 을 뗀다** — 같은 낱말을 `H09002` 와 `H9002` 로 적는 모듈이
      섞여 있어(실측 ChiUns 대 BSB) 안 떼면 집합이 영영 안 겹친다.
    ⚠ 형태소 코드(H8804 같은 문법 태그)는 **그대로 둔다** — 거르면 모듈마다
      다른 잣대가 되고, 견주는 것은 집합이라 양쪽에 다 있으면 문제없다.
    """
    return ['%s%d' % (m.group(1), int(m.group(2)))
            for m in _RX_STRONG.finditer(xml)]


# ══════════════════════════════════════════════════════════════════════
#  적재
# ══════════════════════════════════════════════════════════════════════
def ensure(conn):
    """표를 만든다(멱등). ⚠ LOCAL — 배포하지 않는다."""
    conn.execute("""CREATE TABLE IF NOT EXISTS sys_verse_strong (
        version_code TEXT NOT NULL,
        verse_id     INTEGER NOT NULL,
        strongs      TEXT NOT NULL,
        n_word       INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (version_code, verse_id))""")
    conn.execute('CREATE INDEX IF NOT EXISTS idx_vstrong_v '
                 'ON sys_verse_strong(verse_id)')


def _vid_map(conn):
    """(bcode, chapter, verse) → verse_id."""
    return dict(((b, c, v), i) for i, b, c, v in conn.execute(
        'SELECT verse_id, bcode, chapter, verse FROM bible_index'))


def _norm(s):
    """대조용 — 공백을 걷는다. ⚠ 글자는 안 건드린다(이체자는 차이로 센다)."""
    return ''.join((s or '').split())


_RX_PUNCT = re.compile(r'[^\w]', re.U)


def _key(s):
    """**자리를 맞추는 열쇠** — 대조보다 느슨하다.

    ⚠⚠ `_norm` 으로만 맞추려다 **ASV 가 1,664절 밀린 채 담겼다**
      (2026-09-22 실측 — 창32장부터 한 칸씩. ASV 도 히브리 절체계라 우리
      영어축과 다른데, 본문에 쉼표·따옴표 차이가 있어 사전에서 못 찾았다).
    ⇒ 열쇠에서는 **문장부호와 대소문자를 걷는다.** 담는 본문은 그대로다 —
      바꾸는 것은 「같은 절인가」를 묻는 잣대뿐이다.
    ⚠ 그래도 **글자 자체는 안 건드린다** — 중국어 이체자(形象/形像)는 여전히
      다른 열쇠이고, 그 절들은 좌표가 맞으므로 옮길 필요가 없다.
    """
    return _RX_PUNCT.sub('', (s or '')).lower()


def read_module(zip_path, mod, conn, version_code=None):
    """모듈 하나를 읽어 {verse_id: (본문, [스트롱])} · 못 맞춘 좌표 목록.

    ★★★ **좌표를 번호로만 맞추면 안 된다** (2026-09-22 실측으로 잡았다).
      모듈은 **그 역본의 원본 절체계**(KJV/NRSV/German)를 쓰는데 우리 DB 는
      §18-7·§18-8 에서 **영어축으로 이미 정렬해 두었다.** 번호로만 맞추면
      FreJND 가 통째로 한 칸씩 밀려 **1,843절에 남의 스트롱이 붙는다**
      (실측 — 창31/32 · 민12/13 장경계가 히브리 절체계라 다르다).

    ⇒ **본문으로 맞춘다.** 같은 판이므로 본문이 글자 그대로 같다:
        ① 좌표로 찾아 본문이 같으면 → 확정
        ② 다르면 **우리 본문 사전**에서 그 글을 찾는다 → 하나뿐이면 그리로
        ③ 둘 다 실패하면 좌표 그대로 — 표기 차이(이체자)인 경우다
      ⚠ ② 에서 찾은 자리가 ① 과 다르면 **그것이 곧 밀림**이고 본문 쪽이 옳다.
      ⚠ 짧은 절은 본문이 겹치므로 **후보가 둘 이상이면 안 옮긴다**(지어내지
        않는다 — 그런 절은 ③ 으로 떨어진다).
    """
    vmap = _vid_map(conn)
    out = {}
    miss = []
    moved = 0
    # 우리 본문 사전 — 겹치는 글은 버린다(가릴 수 없으면 안 옮긴다)
    tmap = {}
    if version_code:
        for vid, txt in conn.execute(
                'SELECT verse_id, verse_text FROM bible_content '
                'WHERE version_code=?', (version_code,)):
            k = _key(txt)
            if len(k) < 12:               # 너무 짧은 절은 열쇠로 못 쓴다
                continue
            tmap[k] = None if k in tmap else vid
    for bk, ch, v, raw in ZText(zip_path, mod).verses():
        bc = BCODE_OF.get(bk)
        if bc is None:
            miss.append(('%s.%d.%d' % (bk, ch, v), '모르는 책'))
            continue
        vid = vmap.get((bc, ch, v))
        body = plain(raw)
        if tmap:
            by_text = tmap.get(_key(body))
            if by_text is not None and by_text != vid:
                vid = by_text
                moved += 1
        if vid is None:
            miss.append(('%s.%d.%d' % (bk, ch, v), '우리 좌표에 없다'))
            continue
        out[vid] = (body, strongs(raw))
    if moved:
        print('      ★ 본문으로 자리를 옮긴 절 %d개' % moved)
    return out, miss


def check(conn, only=None, zip_dir=RAW_DIR, limit_show=4):
    """받은 본문이 **우리 본문과 같은 판인가**(§0-1b 규칙 ②)."""
    rows = []
    for vc, mod, folder, _l, _v, _s, _t in SOURCES:
        if only and vc != only:
            continue
        zp = os.path.join(zip_dir, mod + '.zip')
        if not os.path.exists(zp):
            rows.append((vc, None, '받지 않았다', []))
            continue
        got, miss = read_module(zp, folder, conn, vc)
        mine = dict(conn.execute(
            'SELECT verse_id, verse_text FROM bible_content '
            'WHERE version_code=?', (vc,)))
        same = diff = only_got = n_str = 0
        samples = []
        for vid, (txt, st) in got.items():
            if st:
                n_str += 1
            m = mine.get(vid)
            if m is None:
                only_got += 1
                continue
            if _norm(m) == _norm(txt):
                same += 1
            else:
                diff += 1
                if len(samples) < limit_show:
                    samples.append((vid, _norm(m)[:58], _norm(txt)[:58]))
        only_mine = len(set(mine) - set(got))
        tot = same + diff
        pct = (100.0 * same / tot) if tot else 0.0
        rows.append((vc, pct,
                     '절 %d · 같음 %d · 다름 %d · 받은 것만 %d · 우리만 %d · '
                     '스트롱 있는 절 %d · 좌표 못 맞춤 %d'
                     % (len(got), same, diff, only_got, only_mine,
                        n_str, len(miss)), samples))
    return rows


# ⚠⚠⚠ **선언만 보고 믿지 말 것 — 실측으로 걸렀다**(2026-09-22).
#   모듈 `.conf` 에 `Feature=StrongsNumbers` 가 적혀 있어도 본문에 태그가
#   없을 수 있다. 실측 `SpaRV` 는 선언은 있는데 **스트롱이 든 절이 31,103 중
#   2개**였다(스페인어 태그본은 `SpaRV1909` 인데 그쪽은 저작권이 있다).
#   ⇒ `apply` 가 **절반에 못 미치면 거부하고 까닭을 말한다**(§0-1).
MIN_COVER = 0.5

# 기준 역본 — 이것과 견주어 다른 역본의 스트롱이 제자리인지 본다
BASE_VERSION = 'BSB'
# 이웃이 더 맞는 절이 이 비율을 넘으면 **그 모듈은 밀린 것**이라 안 담는다.
#   실측 — 제대로 맞는 모듈은 0.1~0.3%, 밀린 ASV 는 5.4% 였다.
MAX_SHIFT = 0.02


def apply(conn, only=None, zip_dir=RAW_DIR):
    """적재(멱등 — 그 역본 것을 지우고 다시 넣는다).

    ⚠ 스트롱이 든 절이 **절반에 못 미치면 안 담는다** — 빈 서랍이 되고,
      그 역본으로 판정하면 「근거 없음」이 「같음」으로 읽힌다.
    """
    ensure(conn)
    done = []
    for vc, mod, folder, _l, _v, _s, _t in SOURCES:
        if only and vc != only:
            continue
        zp = os.path.join(zip_dir, mod + '.zip')
        if not os.path.exists(zp):
            continue
        got, _miss = read_module(zp, folder, conn, vc)
        n_str = sum(1 for _t, st in got.values() if st)
        if got and n_str < len(got) * MIN_COVER:
            done.append((vc, -n_str, '스트롱이 든 절이 %d개뿐' % n_str))
            continue
        # ⚠ 기준과 견주어 **스트롱이 제자리인가** — 밀린 모듈은 안 담는다
        if vc != BASE_VERSION:
            bm = dict((v, set(t.split())) for v, t in conn.execute(
                'SELECT verse_id, strongs FROM sys_verse_strong '
                'WHERE version_code=?', (BASE_VERSION,)))
            if bm:
                sh, jd = sanity(got, bm, conn)
                if jd and sh > jd * MAX_SHIFT:
                    done.append((vc, -1, '스트롱이 밀렸다 — %d/%d절(%.1f%%)'
                                 ' 에서 이웃이 더 맞는다'
                                 % (sh, jd, 100.0 * sh / jd)))
                    continue
        conn.execute('DELETE FROM sys_verse_strong WHERE version_code=?',
                     (vc,))
        n = 0
        for vid, (_txt, st) in got.items():
            if not st:
                continue                # ⚠ 빈 절은 안 넣는다(§0-1 빈 서랍)
            conn.execute('INSERT INTO sys_verse_strong(version_code, '
                         'verse_id, strongs, n_word) VALUES(?,?,?,?)',
                         (vc, vid, ' '.join(st), len(st)))
            n += 1
        conn.commit()
        done.append((vc, n, ''))
    return done


def _jac(a, b):
    """두 스트롱 집합의 겹침(자카드). 한쪽이 비면 0."""
    if not a or not b:
        return 0.0
    return len(a & b) / float(len(a | b))


def sanity(got, base_map, conn):
    """★★★ **스트롱이 제자리에 있나** — 이웃 절이 이기면 밀린 것이다.

    ⚠⚠⚠ **모듈 안에서 본문과 스트롱의 절체계가 다를 수 있다** (2026-09-22
      실측으로 당했다). `ASV` 모듈은 **본문은 영어 절체계인데 스트롱은
      히브리 절체계**라 창32부터 구약 내내 한 칸 어긋나 있다:

          ASV 31:55  본문 「라반이 일어나 입맞추고」 · 스트롱 **없음**
          ASV 32:1   본문 「야곱이 길을 가매」   · 스트롱 H1121 H7725 H4725
                                                   (= 31:55 의 아들·돌아가다·곳)

      본문 대조로는 안 잡힌다 — **본문은 제자리이기 때문이다.**
    ⇒ 기준(BSB)과 견주어 **제자리보다 이웃이 더 겹치는 절**을 센다.
      §268차 「어긋남 판정」과 같은 원리 — 아무 데도 없으면 번역 차이이고,
      **이웃에 있는데 제자리에 없을 때만** 밀림이다.
    """
    order = dict((v, i) for i, (v,) in enumerate(conn.execute(
        'SELECT verse_id FROM bible_index ORDER BY sort_order')))
    back = dict((i, v) for v, i in order.items())
    shifted = judged = 0
    for vid, (_t, st) in got.items():
        if vid not in base_map or vid not in order:
            continue
        here = _jac(set(st), base_map[vid])
        best = here
        for d in (-1, 1):
            nb = back.get(order[vid] + d)
            if nb in base_map:
                best = max(best, _jac(set(st), base_map[nb]))
        if best <= 0:
            continue
        judged += 1
        if best > here + 0.15:          # 이웃이 뚜렷하게 낫다
            shifted += 1
    return shifted, judged


def undo(conn, only=None):
    ensure(conn)
    if only:
        conn.execute('DELETE FROM sys_verse_strong WHERE version_code=?',
                     (only,))
    else:
        conn.execute('DELETE FROM sys_verse_strong')
    conn.commit()


def strongs_of(conn, version_code, verse_id):
    """그 역본 그 절의 스트롱 목록. 없으면 빈 목록."""
    r = conn.execute('SELECT strongs FROM sys_verse_strong '
                     'WHERE version_code=? AND verse_id=?',
                     (version_code, verse_id)).fetchone()
    return (r[0].split() if r and r[0] else [])


# ══════════════════════════════════════════════════════════════════════
def selftest():
    ok = [0, 0]

    def t(name, cond, note=''):
        ok[1] += 1
        if cond:
            ok[0] += 1
            print('  OK   %s' % name)
        else:
            print('  FAIL %s %s' % (name, note))

    # ① 스트롱 뽑기 — 앞의 0 을 뗀다
    t('스트롱 앞의 0 을 뗀다',
      strongs('<w lemma="strong:H09002 strong:H07225">x</w>')
      == ['H9002', 'H7225'])
    t('헬라어도 읽는다',
      strongs('<w lemma="strong:G2316">x</w>') == ['G2316'])
    t('스트롱이 없으면 빈 목록', strongs('<verse>x</verse>') == [])
    t('★ 같은 낱말의 두 표기가 같은 값이 된다',
      strongs('<w lemma="strong:H09002"/>')
      == strongs('<w lemma="strong:H9002"/>'))

    # ② 본문 뽑기 — 제목·각주는 본문이 아니다
    t('태그를 걷는다', plain('<w lemma="x">가나</w>다') == '가나다')
    t('★ 제목을 본문으로 안 센다',
      plain('<title>머리</title>본문') == '본문')
    t('★ 각주를 본문으로 안 센다',
      plain('<note type="x">주</note>본문') == '본문')

    # ③ 책 표 — 66권이고 겹치지 않는다
    t('책 66권', len(OSIS_BOOKS) == 66)
    t('책 이름이 겹치지 않는다', len(set(OSIS_BOOKS)) == 66)
    t('창세기=1 · 요한계시록=66',
      BCODE_OF['Gen'] == 1 and BCODE_OF['Rev'] == 66)
    t('★ 순서가 아니라 이름으로 푼다',
      BCODE_OF.get('Mal') == 39 and BCODE_OF.get('Matt') == 40)

    # ④ §0-1b ⓪ — 확인 없이는 안 받는다 (양방향)
    blocked = False
    try:
        require_ack([])
    except SystemExit:
        blocked = True
    t('★★★ 확인 없이는 한 바이트도 안 받는다', blocked)
    t('확인하면 지나간다', require_ack(['--links-confirmed']) is True)

    # ⑤ 링크 글이 판권을 함께 말한다
    lt = links_text()
    t('링크 글에 여섯 모듈이 다 있다',
      all(('[%s]' % s[0]) in lt for s in SOURCES))
    t('★ 링크 글이 판권을 말한다', lt.count('판권 :') == len(SOURCES))
    t('★ 받을 주소가 함께 있다', lt.count('받을 곳:') == len(SOURCES))

    # ⑥ 판권 — COPYRIGHTED 를 담지 않았다(§0-1b 규칙 ④)
    t('★★★ 저작권 있는 판본이 목록에 없다',
      not any('Copyrighted' in s[3] for s in SOURCES))
    t('전부 PD 또는 CC0',
      all(('Public Domain' in s[3] or 'CC0' in s[3]) for s in SOURCES))

    # ⑦ 표 — 메모리 DB 왕복
    import sqlite3
    m = sqlite3.connect(':memory:')
    m.execute('CREATE TABLE bible_index(verse_id INTEGER, bcode INTEGER, '
              'chapter INTEGER, verse INTEGER)')
    m.execute('INSERT INTO bible_index VALUES(1,1,1,1)')
    ensure(m)
    m.execute("INSERT INTO sys_verse_strong VALUES('BSB',1,'H7225 H1254',2)")
    t('적재한 것을 읽는다', strongs_of(m, 'BSB', 1) == ['H7225', 'H1254'])
    t('없는 절은 빈 목록', strongs_of(m, 'BSB', 999) == [])
    t('★ 다른 역본은 안 섞인다', strongs_of(m, 'CUVS', 1) == [])
    undo(m, 'BSB')
    t('되돌리면 사라진다', strongs_of(m, 'BSB', 1) == [])
    ensure(m)                               # 멱등
    t('★ 두 번 만들어도 안 터진다', True)
    t('좌표 표를 읽는다', _vid_map(m) == {(1, 1, 1): 1})
    m.close()

    # ⑩ 본문으로 자리 맞추기 — 겹치는 글은 안 옮긴다
    t('★ 짧은 글은 열쇠로 안 쓴다', len(_norm('짧다')) < 12)
    t('★ 긴 글은 열쇠가 된다',
      len(_norm('태초에 하나님이 천지를 창조하시니라')) >= 12)
    t('★★★ 열쇠는 문장부호를 걷는다',
      _key('And he said, "Go."') == _key('And he said: Go'))
    t('★ 열쇠는 대소문자를 안 가린다', _key('Abram') == _key('ABRAM'))
    t('★ 열쇠도 이체자는 가른다', _key('形象') != _key('形像'))
    t('★ 대조 잣대는 그대로 엄하다', _norm('a, b') != _norm('a b'))

    # ⑪ 스트롱이 밀렸는지 — 양방향 (실측 ASV 사고)
    t('겹침 셈', abs(_jac({'H1', 'H2'}, {'H1', 'H2'}) - 1.0) < 1e-9)
    t('안 겹치면 0', _jac({'H1'}, {'H2'}) == 0.0)
    t('한쪽이 비면 0', _jac(set(), {'H1'}) == 0.0)
    m3 = sqlite3.connect(':memory:')
    m3.execute('CREATE TABLE bible_index(verse_id INTEGER, bcode INTEGER, '
               'chapter INTEGER, verse INTEGER, sort_order INTEGER)')
    for i in range(1, 6):
        m3.execute('INSERT INTO bible_index VALUES(?,1,1,?,?)', (i, i, i * 10))
    bm = dict((i, {'H%d' % i, 'H%d0' % i, 'H%d00' % i}) for i in range(1, 6))
    same = dict((i, ('x', list(bm[i]))) for i in range(1, 6))
    sh, jd = sanity(same, bm, m3)
    t('★★★ 제자리면 밀림 0', sh == 0 and jd == 5)
    off = dict((i, ('x', list(bm.get(i + 1, set())))) for i in range(1, 5))
    sh2, jd2 = sanity(off, bm, m3)
    t('★★★ 한 칸 밀리면 잡는다 (탐지력)', sh2 >= 3, '%d/%d' % (sh2, jd2))
    t('문턱은 2%', MAX_SHIFT == 0.02)
    t('기준 역본은 BSB', BASE_VERSION == 'BSB')
    m3.close()

    # ⑧ 대조 잣대 — 공백만 걷고 글자는 안 건드린다
    t('대조는 공백을 걷는다', _norm(' 가 나  다 ') == '가나다')
    t('★ 이체자는 차이로 센다', _norm('形象') != _norm('形像'))

    # ⑨ 스트롱이 얇으면 안 담는다 (양방향 · 실측 SpaRV 사고)
    m2 = sqlite3.connect(':memory:')
    m2.execute('CREATE TABLE bible_index(verse_id INTEGER, bcode INTEGER, '
               'chapter INTEGER, verse INTEGER)')
    ensure(m2)
    t('문턱이 절반이다', MIN_COVER == 0.5)
    thin = dict((i, ('x', ['H1'] if i < 2 else [])) for i in range(10))
    t('★★★ 스트롱이 얇으면 거부한다',
      sum(1 for _x, st in thin.values() if st) < len(thin) * MIN_COVER)
    thick = dict((i, ('x', ['H1'])) for i in range(10))
    t('두꺼우면 담는다',
      sum(1 for _x, st in thick.values() if st) >= len(thick) * MIN_COVER)
    m2.close()

    print('\n%d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


def main(argv):
    if '--selftest' in argv:
        return 0 if selftest() else 1
    if '--links' in argv:
        print(links_text())
        return 0
    if '--fetch' in argv:
        fetch(argv)
        return 0
    only = None
    if '--version' in argv:
        only = argv[argv.index('--version') + 1]
    conn = appdb.connect()
    try:
        if '--undo' in argv:
            undo(conn, only)
            print('되돌렸다')
            return 0
        if '--apply' in argv:
            for vc, n, why in apply(conn, only):
                if n < 0:
                    print('  [%s] 담지 않았다 — %s' % (vc, why))
                else:
                    print('  [%s] %d절 적재' % (vc, n))
            return 0
        for vc, pct, note, samples in check(conn, only):
            head = ('%-7s %s' % (vc, note) if pct is None
                    else '%-7s 본문 일치 %6.2f%%  %s' % (vc, pct, note))
            print(head)
            for vid, a, b in samples:
                print('     vid %d' % vid)
                print('       우리: %s' % a)
                print('       받음: %s' % b)
        return 0
    finally:
        conn.close()


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
