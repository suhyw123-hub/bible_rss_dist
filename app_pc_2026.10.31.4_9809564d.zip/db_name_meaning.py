# -*- coding: utf-8 -*-
"""이름에 담긴 고백 — 인물·장소 이름의 뜻 (영구 도구)

2026-09-07 신설. 사용자 확정(1.txt 「형용사 동사는 어떻게 어휘를 활용하면
좋을까?」에 대한 제안 A).

★★★ **왜 이것이 「동사·형용사 활용」의 답인가**
  추상적인 형용사가 성경 안에서 **사람 이름으로 서 있다**:
      토브(좋다·형용사) → 도비야 「여호와의 선하심」
      샬롬(평화·명사)   → 압살롬 「평화의 아버지」
      다윗              → 「사랑받는 자」
  낱말을 사전에서 찾는 것이 아니라 **그 낱말을 이름으로 지닌 사람**을 만난다.
  ⚠ 게다가 이름 뜻과 그 사람의 행실이 어긋나는 자리가 그대로 묵상거리다
    (압살롬은 「평화의 아버지」라는 이름으로 반역했다).

★ **재료는 이미 있었다** — `sys_lemma_master.deriv`(어원) **99% 채움**.
  Strong 이 이름마다 뜻을 적어 두었고 우리는 그것을 읽지 않고 있었다.

⚠⚠ **자동 매칭은 정확 일치만**(§165차 교훈) — 이름은 겹치기 쉽다.
  「Tob」이 지명이자 사람 이름이고 「야고보」가 여럿이다. 애매한 것은
  **검토 목록으로 내고 사람이 정한다.**

⚠ **저장은 `json_detail`**(§0-3 규칙 2) — 짧은 번역 텍스트는 중첩 JSON:
      name_meaning: {"EN": "loving", "KO": "사랑받는 자"}
      name_strong:  "H1732"          ← 코드성이라 flat
  새 표를 만들지 않는다.

⚠ **`sys_entity_lemma` 에 넣지 않는다** — 그것은 「이 용어의 원어 앵커」라
  `db_term_load --relink` 가 **낱말연결(LEXICAL)을 만든다**. 인물은 이미
  구절·단락 연결이 있어 두 벌이 된다. 축이 다르다.
"""
from __future__ import annotations

import json
import re
import sys

try:
    import appdb
except Exception:                                        # pragma: no cover
    appdb = None

#: 손으로 정한 배정 — 이름 대조로는 못 닿는 자리(§165차 `MANUAL` 과 같은 문법).
#: ⚠ **자동이 틀린 것을 여기서 바로잡는다.** 실측으로 확인하고서만 적는다.
MANUAL = {
    # 방주의 노아는 H5146(안식) — gloss 가 「Noach」라 이름 대조에 안 걸린다.
    # ⚠ 자동은 H5270(**슬로브핫의 딸 노아** · movement)을 집었다.
    'P_NOAH': 'H5146',
    # 아담의 아들 아벨은 H1893(헛됨·숨) — H59 는 **지명 아벨**이다.
    'P_ABEL': 'H1893',
    # ── 이름 대조를 느슨하게 한 뒤 후보가 늘어 검토로 밀린 것들 ──────
    #   (2026-09-07 · 전부 실측으로 확인하고 표준 낱말로 고정)
    'P_JOSEPH': 'H3130',    # H3084 Jehoseph 은 같은 이름의 긴 꼴
    'P_EZRA': 'H5830',      # H5831·H5834 는 동명이인
    'P_ABIJAH': 'H29',      # H38 은 **Abijam**(다른 왕)
    'P_AMON': 'H526',       # H5983 은 **암몬 족속**이다
    'PL_MARAH': 'H4785',    # H4755 는 나오미가 자신을 부른 이름(마라)
}

#: **담지 않을 것** — 자동은 맞는데 화면에 적으면 오해가 되는 자리.
#: ⚠ 실측으로 확인하고서만 적는다(§165차 `EXCLUDE` 와 같은 문법).
EXCLUDE = {
    # 지명 하란은 H2771 인데 자동이 **사람 하란**(H2039 · 롯의 아버지)을 집었다.
    # ⚠ 장소는 품사로 못 거른다(Strong 이 지명을 `n-pr-f` 로도 적는다).
    'PL_HARRAN': '사람 하란(H2039)과 겹친다 — 지명은 H2771',
    # 「도금양」은 **히브리 이름 하닷사**의 뜻이고 「에스더」의 뜻이 아니다.
    # 그대로 적으면 「에스더 = 도금양」이라는 거짓이 된다.
    'P_ESTHER': '히브리 이름 하닷사의 뜻이라 오해가 된다',
    # Strong 이 `revulet` 이라 적었는데 그런 낱말이 없다(`rivulet` 의 오타로
    # 보이나 **짐작으로 고치지 않는다**). 통설은 「누가 하나님과 같으랴」다.
    'P_MICHAL': 'Strong 표기가 오타로 보인다 — 짐작으로 안 적는다',
    # ── 검토 39건 가운데 **비워 두기로 정한 것**(2026-09-07) ───────────
    #   ★ 전부 **스트롱 자신이 뜻을 모른다고 적은 자리**다. 세상에 떠도는
    #     통설이 있어도 여기서는 안 적는다(§0-1b 「지어내지 않는다」).
    #   ⚠ 비어 있는 것이 결함이 아니라 **정직한 상태**다 — 화면은 이름의 뜻
    #     줄 자체를 안 그린다(빈 서랍 금지).
    'P_AARON': 'H175 `of uncertain derivation`',
    'P_ACHISH': 'H397 `of uncertain derivation`',
    'P_ASA': 'H609 `of uncertain derivation`',
    'P_BOAZ': 'H1162 `from an unused root of uncertain meaning`',
    'P_CALEB': 'H3612 `perhaps a form of 3611`(개) — perhaps 를 뜻으로 안 적는다',
    'P_CAIN': 'H7014 `the same as 7013 (with a play upon the affinity to 7069)` '
              '— 스트롱이 「창」과 「얻다」 사이에서 못 정했다',
    'P_HAGAR': 'H1904 `of uncertain (perhaps foreign) derivation`',
    'P_MORDECAI': 'H4782 `of foreign derivation`',
    'P_APOLLOS': 'G625 `probably from the same as …` — 뜻이 아니다',
    # ⚠ 어원 안의 번호는 **수입 때 걷혔다**(`contraction for ;`) — 없는 번호를
    #   근거에 적지 않는다. 실릴 자리가 비어 있다는 사실 그대로 적는다.
    'P_SILAS': 'G4609 `contraction for ;`(실루아노) → `of Latin origin` '
               '— 뜻이 아니다',
    'PL_DAMASCUS': 'H1834 `of foreign origin`',
    'PL_DOTHAN': 'H1886 `of uncertain derivation`',
    'PL_GOSHEN': 'H1657 `probably of Egyptian origin`',
    'PL_NINEVEH': 'H5210 `of foreign origin`',
    'PL_JERICHO': 'H3405 `perhaps from 3394; its month; or else from 7306; '
                  'fragrant` — 스트롱이 **두 뜻을 나란히** 두고 못 정했다',
    'PL_DERBE': 'G1191 `of foreign origin`',
    'PL_EPHESUS': 'G2181 `probably of foreign origin`',
    'PL_LYSTRA': 'G3082 `of uncertain origin`',
    'PL_MILETUS': 'G3399 `of uncertain origin`',
    'PL_MYRA': 'G3460 `of uncertain derivation`',
    'PL_PHILIPPI': 'G5375 `plural of ;`(빌립 G5376 「말을 좋아하는」) — 그것은 '
                   '사람 이름의 뜻이지 이 도시의 뜻이 아니다',
    'PL_SALAMIS': 'G4529 `probably from (from the surge on the shore)` — '
                  '`probably` 를 뜻으로 안 적는다',
    'PL_SYRACUSE': 'G4946 `plural of uncertain derivation`',
}

#: **사람이 정한 뜻** — 낱말과 뜻을 함께 못 박는다(2026-09-07 검토 39건).
#:
#: ★★ **`MANUAL` 과 몫이 다르다** — `MANUAL` 은 「어느 낱말인가」만 정하고 뜻은
#:   기계가 읽는다. 여기는 **기계가 못 읽는 자리**다:
#:     · 이름 대조가 안 닿는다(스트롱의 독일식 음역 `Esav`·`Binjamin`·`Kajin`)
#:     · 어원 사슬이 **두 단계**라 기계가 일부러 안 따라간다(길갈·미스바)
#:     · 부모의 뜻이 `deriv` 에 있고 `gloss` 는 고유명사다(실로)
#: ⚠ **근거를 함께 적는다** — 스트롱의 어느 말에서 왔는지 대지 못하면 짐작이다.
#: ⚠ 값은 `(strong, 스트롱의 말(EN), 근거)`.
MANUAL_MEANING = {
    # ── 이름 대조가 안 닿는 자리(음역 차이) ────────────────────────────
    'P_ABIATHAR': ('H54', 'father of abundance',
                   'H54 `contracted from 1 and 3498; father of abundance`'),
    'P_ADAM': ('H121', 'a human being',
               'H121 `the same as 120` → H120 `ruddy i.e. a human being`'),
    'P_BENJAMIN': ('H1144', 'son of the right hand',
                   'H1144 `from 1121 and 3225; son of (the) right hand`'),
    'P_DANIEL': ('H1840', 'judge of God', 'H1840 어원이 그대로 적는다'),
    'P_ENOS': ('H583', 'a mortal',
               'H583 `the same as 582` → H582 `properly, a mortal`'),
    'P_EPHRAIM': ('H669', 'double fruit',
                  'H669 `dual of masculine form of 672; double fruit`'),
    'P_ESAU': ('H6215', 'rough', 'H6215 `… ; rough (i.e. sensibly felt)`'),
    'P_REUBEN': ('H7205', 'see ye a son',
                 'H7205 `from the imperative of 7200 and 1121; see ye a son`'),
    'P_MARTHA': ('G3136', 'mistress',
                 'G3136 `probably of Chaldee origin (meaning mistress)`'),
    # ── 어원 사슬이 두 단계(기계는 한 단계만 간다 — 사람이 확인했다) ────
    'PL_AI': ('H5857', 'a ruin',
              'H5857 `for 5856` → H5856 `a ruin (as if overturned)`'),
    'PL_GILGAL': ('H1537', 'a wheel',
                  'H1537 `the same as 1536` → H1536 `a variation of 1534` '
                  '→ H1534 `a wheel`. 수 5:9 「굴러가게 하였다」가 그 자리다'),
    'PL_MIZPAH': ('H4709', 'an observatory',
                  'H4709 `feminine of 4708` → H4708 `the same as 4707` '
                  '→ H4707 `an observatory`'),
    # ── 부모의 뜻이 gloss 가 아니라 deriv 에 있다 ──────────────────────
    'PL_SHILOH': ('H7887', 'tranquil',
                  'H7887 `from the same as 7886` → H7886 `from 7951; '
                  'tranquil`. ⚠ H7886 의 gloss 는 고유명사라 못 쓴다'),
    # ── 같은 이름의 낱말이 여럿이라 기계가 못 고른다 ───────────────────
    'PL_CANA': ('H7071', 'reediness',
                'H7071 `feminine of 7070; reediness`. ⚠ H2584(한나)는 '
                '음역이 겹쳤을 뿐 다른 낱말이다'),
    'PL_RAMAH': ('H7414', 'a height',
                 'H7414 `the same as 7413` → H7413 `a height`. '
                 '⚠ H7484(말갈기)는 다른 낱말이다'),
    'PL_SHECHEM': ('H7927', 'ridge',
                   'H7927 `the same as 7926; ridge`. ⚠ H7928 은 사람 이름이다'),
}

#: **한국어** — 파일 원장(§183차 ⑤). DB 가 무너져도 여기서 되살린다.
#: ⚠ **영어를 그대로 옮기지 않는다** — 스트롱의 말은 라틴 어법이라
#:   `Jehovah-saved` 를 「여호와-구원된」이라 적으면 우리말이 아니다.
KO = {
    'PL_BEERSHEBA': '맹세의 우물',
    'PL_BETHEL': '하나님의 집',
    'PL_ELIM': '종려나무들',
    'PL_ENDOR': '거처의 샘',
    'PL_ENGEDI': '염소 새끼의 샘',
    'PL_GERAR': '구릉진 땅',
    'PL_KADESH': '성소 (방랑의 광야에 있는)',
    'PL_MARAH': '쓰다',
    'PL_OPHRAH': '어린 암사슴',
    'PL_REPHIDIM': '받침대',
    'PL_SHUNEM': '고요히',
    'PL_SUCCOTH': '초막들',
    'PL_ZAREPHATH': '제련하는 곳',
    'PL_ZIPH': '흐름',
    'P_ABEL': '헛됨 · 숨',
    'P_ABIJAH': '여호와는 나의 아버지',
    'P_ABIMELECH': '왕의 아버지',
    'P_ABNER': '빛의 아버지',
    'P_ABRAHAM': '많은 무리의 아버지',
    'P_ADONIJAH': '여호와는 나의 주님',
    'P_AMON': '숙련된 자 · 장인',
    'P_AMOS': '짐을 진 자',
    'P_AMRAM': '높은 백성',
    'P_ASHER': '곧게 나아가다',
    'P_BARAK': '번개',
    'P_BARZILLAI': '무쇠 같은 사람',
    'P_BATHSHEBA': '맹세의 딸',
    'P_BATHSHUA': '풍요의 딸',
    'P_BETHUEL': '하나님께 무너진 자',
    'P_BILHAH': '수줍은',
    'P_DAN': '재판관',
    'P_DAVID': '사랑받는 자',
    'P_DEBORAH': '벌',
    'P_DELILAH': '시들게 하는 여자',
    'P_DINAH': '공의',
    'P_ELI': '높은',
    'P_ELIJAH': '나의 하나님은 여호와',
    'P_ELIMELECH': '내 하나님은 왕이시다',
    'P_ELISHA': '하나님은 나의 구원',
    'P_ELKANAH': '하나님이 얻으셨다',
    'P_ER': '깨어 있는',
    'P_EVE': '생명을 주는 이',
    'P_EZRA': '도움',
    'P_GAD': '몰려들다 · 습격하다',
    'P_ISAAC': '웃음',
    'P_JACOB': '발꿈치를 잡는 자',
    'P_JAEL': '산염소',
    'P_JEHORAM': '여호와께서 높이셨다',
    'P_JEHOSHAPHAT': '여호와께서 판단하셨다',
    'P_JEHOZADAK': '여호와께서 의롭게 하신다',
    'P_JEHU': '여호와는 그분이시다',
    'P_JETHRO': '그의 탁월함',
    'P_JOAB': '여호와는 아버지시다',
    'P_JOCHEBED': '여호와는 영광',
    'P_JOKSHAN': '덫을 놓는 자',
    'P_JONAH': '비둘기',
    'P_JONATHAN': '여호와께서 주셨다',
    'P_JOSEPH': '그가 더하시기를',
    'P_JOSHUA': '여호와께서 구원하신다',
    'P_JOTHAM': '여호와는 온전하시다',
    'P_KETURAH': '향을 피운',
    'P_LABAN': '흰',
    'P_LEAH': '지친 여자',
    'P_LOT': '가리개',
    'P_MALACHI': '섬기는 자 · 나의 사자',
    'P_MEPHIBOSHETH': '수치를 흩는 자',
    'P_MILCAH': '여왕',
    'P_NAAMAN': '쾌적함',
    'P_NABAL': '어리석은 자',
    'P_NABOTH': '열매들',
    'P_NAPHTALI': '나의 씨름',
    'P_NATHAN': '주어진 자',
    'P_NOAH': '안식',
    'P_OBED': '섬기는 자',
    'P_ONAN': '강한',
    'P_PEREZ': '터뜨림',
    'P_RACHEL': '암양',
    'P_RUTH': '벗',
    'P_SALMON': '옷 입힘',
    'P_SARAH': '여주인 · 귀부인',
    'P_SHEALTIEL': '내가 하나님께 구하였다',
    'P_SHELAH': '간구',
    'P_SHEM': '이름',
    'P_TAMAR': '종려나무',
    'P_ZADOK': '의로운',
    'P_ZERUBBABEL': '바벨론에서 난 자',
    'P_ZIBA': '자리에 선 자',
    'P_ZILPAH': '방울지는 향',
    'P_ZIPPORAH': '새',
    # ── 검토 39건에서 사람이 정한 것(2026-09-07) ──────────────────────
    'P_ABIATHAR': '풍성함의 아버지',
    'P_ADAM': '사람',
    'P_BENJAMIN': '오른손의 아들',
    'P_DANIEL': '하나님은 나의 재판장',
    'P_ENOS': '죽을 수밖에 없는 사람',
    'P_EPHRAIM': '두 배로 열매 맺음',
    'P_ESAU': '털이 많은 · 거친',
    'P_REUBEN': '보라, 아들이다',
    'P_MARTHA': '여주인',
    'PL_AI': '폐허 · 무너진 더미',
    'PL_CANA': '갈대가 우거진 곳',
    'PL_GILGAL': '굴러 감 · 바퀴',
    'PL_MIZPAH': '망대 · 지켜보는 곳',
    'PL_RAMAH': '높은 곳',
    'PL_SHECHEM': '등성이 · 어깨',
    'PL_SHILOH': '안식의 곳',
}

#: 뜻이 아니라 「어디서 왔나」만 말하는 꼬리 — 이런 것은 뜻으로 안 읽는다.
_NOT_MEANING = re.compile(
    r'^(of\s+(foreign|uncertain|egyptian|persian|hebrew|aramaic|chaldee)\b'
    r'|(intensive|contracted|contraction|patronymic|patrial|denominative'
    r'|probably|perhaps|apparently|prolonged|shortened|a\s+form|the\s+same'
    r'|a\s+variation|corresponding)\b'
    r'|from\b|or\b|a\s+primitive\b|akin\b|by\b|compare\b|see\b|feminine\b'
    r'|masculine\b|plural\b|dual\b|in\s+\w+\s+it\s+is\b)', re.I)

#: 어원 안의 낱말 번호(맨 숫자). ⚠ `H1234` 꼴이 아니다 — 실측으로 잡았다.
_NUM = re.compile(r'(?<![A-Za-z0-9])(\d{1,5})(?![0-9])')

#: 뜻 꼬리에서 걷을 군더더기
_TRIM = re.compile(r'\s*\((?:i\.e\.|apparently|probably)[^)]*\)')


def parse(deriv):
    """어원 한 줄 → `{'meaning': str|None, 'parents': [strong 번호(숫자)]}`.

    실측한 꼴은 이렇다(매우 규칙적):
        `from 1 and 3050; father (i.e. worshipper) of Jah;`
        `or prolonged אֲבִיָּהוּ ; from 1 and 3050; father of Jah;`
        `of foreign origin;`                    ← 뜻 없음
        `contracted from 23;`                   ← 뜻 없음
    ⇒ **`;` 로 잘라 마지막 조각**을 본다. 번호가 있거나 「어디서 왔나」를
      말하는 조각이면 뜻이 아니다.
    """
    dv = (deriv or '').strip()
    if not dv:
        return {'meaning': None, 'parents': []}
    parents = [int(x) for x in _NUM.findall(dv)]
    # ⚠⚠ **`or else` = 스트롱이 뜻을 둘 두고 못 정했다** — 하나를 고르면
    #   다른 하나를 버리는 것이라 뜻을 안 뽑는다(2026-09-07 실측으로 잡았다:
    #   여리고 H3405 `perhaps from 3394; its month; or else from 7306;
    #   fragrant` 에서 마지막 조각 `fragrant` 를 뽑고 있었다).
    #   ★ 번호는 그대로 낸다 — 어원 사슬을 사람이 따라갈 수 있어야 한다.
    if re.search(r'\bor\s+else\b', dv, re.I):
        return {'meaning': None, 'parents': parents}
    parts = [p.strip(' ;.') for p in dv.split(';')]
    parts = [p for p in parts if p]
    meaning = None
    for p in reversed(parts):
        if _NUM.search(p):
            continue                       # 번호가 든 조각은 출처다
        if _NOT_MEANING.match(p):
            continue
        if not re.search(r'[A-Za-z]', p):
            continue                       # 히브리 글자만 있는 이형 표기
        meaning = _TRIM.sub('', p).strip(' ,')
        break
    return {'meaning': meaning or None, 'parents': parents}


def _en_name(conn, eid):
    r = conn.execute(
        "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME' "
        "AND clicked_id=? AND lang_code='EN' AND record_status='LIVE' LIMIT 1",
        (eid,)).fetchone()
    return (r[0] or '').strip() if r else ''


def type_ok(ent_type, pos, gender=None):
    """엔티티 유형·성별이 낱말 품사와 맞는가.

    ★★★ **이 가드가 실제로 오매칭 둘을 잡았다**(2026-09-07 실측):
        노아(P_NOAH·남자) ↔ H5270 `n-pr-f` = **슬로브핫의 딸 노아**
          (방주의 노아는 H5146 이다)
        아벨(P_ABEL·사람) ↔ H59 `n-pr-loc` = **지명 아벨**
          (아담의 아들 아벨은 H1893/G6)
      §165차 「이름은 겹치기 쉽다」가 여기서 그대로 났다.
    ⚠ **품사가 비면 통과시킨다** — 헬라어는 품사가 통째로 비어 있어
      (실측 EL 5,624개) 막으면 신약 인물이 전부 사라진다.
    ⚠ 한 낱말이 여러 품사를 가질 수 있다(`n-pr-m n-pr-loc`) — 하나라도
      맞으면 통과.

    ⚠⚠⚠ **성별로는 못 거른다 — 양쪽 데이터가 다 부정확하다**(2026-09-07 실측).
      · 우리 `sys_person.gender` — **들릴라·레아가 `M`** 이다(F 18 · M 162).
      · Strong 품사 — **마라(지명)가 `n-pr-f`**, 르비딤(지명)이 `n-pr-m`.
      처음에 성별 가드를 넣었더니 **정당한 넷**(나봇·들릴라·레아·마라)을
      함께 걷었다. ⇒ **막는 것은 「사람 ↔ 지명 전용 낱말」 하나뿐**이다.
      나머지 오매칭은 `name_strong` 을 함께 담아 **사람이 되짚을 수 있게** 한다.
      ★ 여기서는 **미탐이 오탐보다 싸다** — 잘못 걸러내면 좋은 이름을 잃고,
        잘못 담긴 것은 목록에서 눈에 띈다.
    """
    p = (pos or '').strip()
    if not p:
        return True
    toks = p.split()
    is_loc = any(t.startswith('n-pr-loc') for t in toks)
    is_person = any(t in ('n-pr-m', 'n-pr-f') for t in toks)
    if ent_type == 'PERSON':
        # 지명 전용 낱말은 사람이 아니다(아벨 H59 = 지명 아벨)
        return not (is_loc and not is_person)
    return True


#: 철자만 다른 같은 소리 — 실측으로 정했다(2026-09-07).
#: ⚠ **차례가 중요하다** — `tsch` 를 `ts` 보다 먼저 본다.
_SOUND = (('tsch', 'sh'), ('ts', 'z'), ('tz', 'z'), ('ch', 'k'), ('kh', 'k'),
          ('ph', 'f'), ('j', 'y'), ('w', 'v'), ('c', 'k'), ('q', 'k'))


def _norm(s):
    """대조용 정규화 — 소문자 · 관사 · 부호 · **같은 소리의 철자 차이**.

    ★★★ **왜 필요한가**(2026-09-07 실측) — Strong 은 **히브리 음역**으로 적고
      우리는 **영어 이름**으로 적는다. 그래서 가장 유명한 이름들이 통째로
      안 걸렸다(287 중 **176**):
          요게벳 `Jochebed` ↔ `Jokebed`     (ch ↔ k)
          십보라 `Zipporah` ↔ `Tsipporah`   (ts ↔ z · 이중자음)
          미갈   `Michal`   ↔ `Mikal`
          바로   `Pharaoh`  ↔ `Pharao`      (끝 h)
    ⚠⚠ **모음을 지우면 안 된다**(자음 골격을 시험했다가 되돌렸다) — 그러면
      아히도벨 ↔ `Tophel` · 도마 ↔ `Timæus` · 베다니 ↔ `Bithynia` 가 걸린다.
      **모음을 남기니 그 오매칭이 전부 사라졌다.**
    ⚠ 겹친 결과가 나오면 `candidates` 가 **검토로 보낸다** — 느슨해져도
      자동이 더러워지지 않는 것이 이 설계의 안전장치다.
    """
    import unicodedata
    s = unicodedata.normalize('NFKD', s or '')
    s = ''.join(ch for ch in s if not unicodedata.combining(ch))
    s = s.strip().lower()
    s = re.sub(r'^(the|a|an)\s+', '', s)
    s = re.sub(r'[^a-z ]', '', s)
    for a, b in _SOUND:
        s = s.replace(a, b)
    s = re.sub(r'(.)\1+', r'\1', s)      # 이중자음
    s = re.sub(r'h$', '', s)             # 끝의 h
    return s.strip()


def gloss_names(gloss):
    """뜻풀이에서 **이름 후보들** — 첫 쉼표 앞 + 괄호 안 `(or X)`/`(i.e. X)`.

    ★★ 괄호가 다리다(실측) — `Jehoshua (i.e. Joshua)` · `Hadassah (or Esther)` ·
      `Solomon (i.e. Shelomoh)`. 첫 조각만 보면 여호수아·에스더가 안 걸린다.
    """
    g = gloss or ''
    head = g.split(',')[0]
    out = [re.sub(r'\(.*?\)', '', head)]
    out += re.findall(r'\((?:or|i\.e\.)\s+([A-Za-z\-]+)\)', g)
    return [x for x in (v.strip() for v in out) if x]


def lex_names(conn):
    """고유명사 낱말을 이름별로 모은다 → `{정규화 이름: [행…]}`.

    ⚠ **헬라어는 품사가 비어 있다**(실측 EL 5,624개 전부) — 그래서 히브리는
      `pos` 로, 헬라는 **gloss 꼴**로 가른다. 안 그러면 신약 인물이 통째로 빠진다.
    """
    out = {}
    q = ("SELECT strong, lang_code, translit, pos, gloss, deriv "
         "FROM sys_lemma_master WHERE gloss IS NOT NULL AND gloss<>''")
    for st, lg, tr, pos, gl, dv in conn.execute(q):
        is_pr = (pos or '').startswith('n-pr')
        if not is_pr and lg == 'EL':
            # 헬라 고유명사는 gloss 가 「이름, …」 꼴이고 첫 글자가 대문자다
            head = (gl or '').split(',')[0].strip()
            is_pr = bool(head) and head[:1].isupper() and ' ' not in head
        if not is_pr:
            continue
        row = {'strong': st, 'lang': lg, 'translit': tr, 'pos': pos,
               'gloss': gl, 'deriv': dv}
        for cand in gloss_names(gl):
            nm = _norm(cand)
            if nm:
                lst = out.setdefault(nm, [])
                if row not in lst:
                    lst.append(row)
    return out


#: Strong 자신이 확신하지 못한 어원 — 그런 것은 따라가지 않는다.
_UNSURE = re.compile(
    r'\b(perhaps|probably|apparently|or\s+else|uncertain)\b', re.I)


def _gloss_meaning(gloss):
    """뜻풀이에서 짧은 뜻 하나 — 부모를 따라갔을 때 쓴다.

    실측 꼴: `the bee (from its systematic instincts)` · `lightning; by analogy…`
    ⇒ **첫 절(;·(  앞)** 만 쓰고 앞의 관사를 걷는다.
    ⚠ 고유명사 뜻풀이(`Deborah, the name of…`)는 뜻이 아니다 — 쉼표 뒤에
      `the name of`·`a place`·`an Israelite` 가 오면 버린다.
    ⚠⚠ **꼬리를 열거해서는 다 못 막는다**(2026-09-07 실측) —
      실로 H7886 `Shiloh, an epithet of the Messiah` 가 그 목록에 없어
      **이름 자신이 뜻으로 읽혔다**. ⇒ **첫 낱말이 대문자면 고유명사 풀이**로
      본다(진짜 뜻은 소문자로 시작한다 — `a wheel`·`a mortal`·`ridge`).
      그런 낱말의 뜻은 gloss 가 아니라 **deriv** 에 있다.
    """
    g = (gloss or '').strip()
    if not g:
        return None
    if re.match(r'[A-Z][A-Za-z\'-]*(,|\s|$)', g):
        return None
    if re.search(r',\s*(the\s+name\s+of|an?\s+(place|city|town|region|'
                 r'israelit|man|woman|son|daughter))', g, re.I):
        return None
    g = re.split(r'[;(]', g)[0].strip(' ,.')
    g = re.sub(r'^(the|a|an)\s+', '', g, flags=re.I).strip()
    return g or None


def _by_strong(conn):
    """번호 → `(어원, 뜻풀이)` — 부모 한 단계 따라가기용. 한 번만 읽는다.

    ⚠⚠ **부모의 뜻은 `deriv` 가 아니라 `gloss` 에 있다**(2026-09-07 실측):
        H1682 gloss=`the bee` / deriv=`from 1696 ...`
        H1300 gloss=`lightning` / deriv=`from 1299`
      어원만 보면 계속 위로 올라가 아무 데도 닿지 못한다 — 실제로
      드보라·바락·사라가 그래서 죽어 있었다.
    """
    return {st: (dv, gl) for st, dv, gl in conn.execute(
        "SELECT strong, deriv, gloss FROM sys_lemma_master")}


def resolve_meaning(deriv, lang, idx, depth=1):
    """어원 → `(뜻, 간접인가)`. 뜻이 없으면 **부모를 한 단계** 따라간다.

    ★★ 이 한 걸음이 유명한 이름들을 살린다(실측):
        드보라 `the same as 1682` → H1682 **벌**
        바락   `the same as 1300` → H1300 **번개**
        엘리사 `contracted for 474` → H474 **하나님은 나의 구원**
    ⚠ **한 단계만** — 두 단계를 가면 뜻이 원래 이름에서 너무 멀어진다.
    ⚠ **부모가 여럿이면 안 따라간다** — `from 1 and 3050` 처럼 합성어는
      어느 쪽이 뜻인지 우리가 정할 수 없다(그런 것은 대개 자기 뜻이 있다).
    ⚠ **간접이라고 알린다** — 「그 낱말의 뜻」과 「그 뿌리의 뜻」은 다르다.
    """
    p = parse(deriv)
    if p['meaning']:
        return (p['meaning'], False)
    if depth <= 0 or len(p['parents']) != 1:
        return (None, False)
    # ⚠ **불확실한 어원은 안 따라간다** — `perhaps`·`or else` 가 있으면
    #   Strong 자신이 확신하지 못한 것이다(갈렙 `perhaps a form of 3611,
    #   or else …` → 「개」. 그런 것을 이름의 뜻이라 적으면 안 된다).
    if _UNSURE.search(deriv or ''):
        return (None, False)
    pre = 'G' if lang == 'EL' else 'H'
    got = idx.get('%s%d' % (pre, p['parents'][0]))
    if not got:
        return (None, False)
    pdv, pgl = got
    # ★ **부모의 뜻풀이(gloss)를 먼저 본다** — 거기에 뜻이 있다.
    m = _gloss_meaning(pgl)
    if m:
        return (m, True)
    m, _ = resolve_meaning(pdv, lang, idx, depth - 1)
    return (m, True) if m else (None, False)


def candidates(conn, types=('PERSON', 'PLACE')):
    """엔티티 ↔ 낱말 후보 → `(자동, 검토)`.

    ★ **정확 일치만 자동**(§165차) — 이름은 겹치기 쉽다.
    ⚠ 한 이름에 낱말이 여럿이면 **검토로 넘긴다**(고르는 것은 사람의 몫).
    """
    lx = lex_names(conn)
    idx = _by_strong(conn)
    # 성별 — 오매칭을 거르는 데 쓴다(표가 없어도 안 죽는다)
    gen = {}
    try:
        gen = {r[0]: r[1] for r in conn.execute(
            "SELECT person_id, gender FROM sys_person")}
    except Exception:
        pass
    auto, review = [], []
    q = ("SELECT entity_id, entity_code, entity_type FROM sys_entity_master "
         "WHERE record_status='LIVE' AND entity_type IN (%s)"
         % ','.join('?' * len(types)))
    by_strong = {}
    for lst in lx.values():
        for g in lst:
            by_strong[g['strong']] = g
    for eid, code, typ in conn.execute(q, list(types)):
        if code in EXCLUDE:
            continue                       # 담지 않기로 정한 자리
        if code in MANUAL_MEANING:
            continue                       # 사람이 뜻까지 정했다(apply_manual)
        # ★ 손으로 정한 것이 자동을 이긴다
        if code in MANUAL:
            g = by_strong.get(MANUAL[code])
            if g:
                m, ind = resolve_meaning(g.get('deriv'), g.get('lang'), idx)
                auto.append({'entity_id': eid, 'code': code, 'type': typ,
                             'name': _en_name(conn, eid), 'lex': g, 'n_lex': 1,
                             'meaning': m, 'indirect': ind, 'manual': True})
                continue
        nm = _en_name(conn, eid)
        if not nm:
            continue
        got = lx.get(_norm(nm))
        if not got:
            continue
        # ★ 유형·성별이 안 맞는 낱말을 먼저 걷는다(오매칭 방지)
        got = [g for g in got if type_ok(typ, g.get('pos'), gen.get(eid))]
        if not got:
            continue
        row = {'entity_id': eid, 'code': code, 'type': typ, 'name': nm,
               'lex': got[0], 'n_lex': len(got)}
        # ★★ **뜻을 가진 낱말이 하나뿐이면 그것을 고른다**(2026-09-07).
        #   ⚠ 헬라어 낱말은 대개 「of Hebrew origin」이라 뜻이 없는데, 그것이
        #     후보 수만 늘려 아브라함·아모스·에르가 검토로 밀려나 있었다.
        with_m = []
        for g in got:
            mm, ii = resolve_meaning(g.get('deriv'), g.get('lang'), idx)
            if mm:
                with_m.append((g, mm, ii))
        if len(with_m) == 1:
            g, m, indirect = with_m[0]
            row['lex'] = g
        else:
            m, indirect = resolve_meaning(got[0].get('deriv'),
                                          got[0].get('lang'), idx)
        row['meaning'] = m
        row['indirect'] = indirect
        (auto if (len(with_m) == 1) else review).append(row)
    return auto, review


# ── 저장 ───────────────────────────────────────────────────────────────
def get_meaning(conn, eid, lang='KO'):
    """이름의 뜻 — 요청 언어 → EN 폴백. 없으면 `(None, None)`.

    돌려주는 값 = `(뜻, strong)`.
    """
    r = conn.execute(
        "SELECT json_detail FROM sys_entity_master WHERE entity_id=?",
        (eid,)).fetchone()
    if not r or not r[0]:
        return (None, None)
    try:
        d = json.loads(r[0])
    except Exception:
        return (None, None)
    m = d.get('name_meaning')
    if not isinstance(m, dict):
        return (None, None)
    txt = m.get(lang) or m.get('EN')
    return ((txt or None), d.get('name_strong'))


def set_meaning(conn, eid, meaning_by_lang, strong=None):
    """뜻을 담는다(멱등 · 있는 언어만 덮는다).

    ⚠ **다른 열쇠를 지우지 않는다** — `json_detail` 에는 지파·역할 등이
      함께 산다. 통째로 갈아 끼우면 그것들이 사라진다.
    """
    r = conn.execute(
        "SELECT json_detail FROM sys_entity_master WHERE entity_id=?",
        (eid,)).fetchone()
    d = {}
    if r and r[0]:
        try:
            d = json.loads(r[0]) or {}
        except Exception:
            d = {}
    cur = d.get('name_meaning')
    if not isinstance(cur, dict):
        cur = {}
    for lg, v in (meaning_by_lang or {}).items():
        v = (v or '').strip()
        if v:
            cur[lg] = v
        else:
            cur.pop(lg, None)          # 빈 값 = 그 언어를 지운다
    if cur:
        d['name_meaning'] = cur
    else:
        d.pop('name_meaning', None)
    if strong:
        d['name_strong'] = strong
    conn.execute("UPDATE sys_entity_master SET json_detail=? WHERE entity_id=?",
                 (json.dumps(d, ensure_ascii=False), eid))
    conn.commit()


def apply_auto(conn, dry=False):
    """자동 후보를 담는다 → 담은 수. **영어만** 담는다(한국어는 사람이).

    ⚠ **이미 한국어가 있으면 안 건드린다** — 사람이 다듬은 것을 기계가
      덮으면 안 된다.
    """
    auto, _ = candidates(conn)
    n = 0
    for r in auto:
        got, _st = get_meaning(conn, r['entity_id'], 'EN')
        if got:
            continue                       # 이미 있다
        if not dry:
            set_meaning(conn, r['entity_id'], {'EN': r['meaning']},
                        strong=r['lex']['strong'])
        n += 1
    return n


def apply_manual(conn, dry=False, quiet=False):
    """사람이 정한 표를 담는다 → `(영어 n, 한국어 n)`.

    ★★ **파일이 정본이다**(§183차 ⑤) — DB 값이 파일과 다르면 파일로 덮는다.
      그래야 DB 가 무너져도 이 파일 하나로 되살아난다.
    ⚠ 멱등 — 같은 값이면 안 건드리고 세지도 않는다.
    ⚠ **없는 코드는 조용히 넘기지 않는다** — 이름을 대고 알린다(§0-1).
    """
    ids, miss = {}, []
    for code in set(list(MANUAL_MEANING) + list(KO)):
        r = conn.execute("SELECT entity_id FROM sys_entity_master "
                         "WHERE entity_code=?", (code,)).fetchone()
        if r:
            ids[code] = r[0]
        else:
            miss.append(code)
    n_en = n_ko = 0
    for code, (sn, en, _why) in MANUAL_MEANING.items():
        eid = ids.get(code)
        if eid is None:
            continue
        got, gsn = get_meaning(conn, eid, 'EN')
        if got == en and gsn == sn:
            continue
        if not dry:
            set_meaning(conn, eid, {'EN': en}, strong=sn)
        n_en += 1
    for code, ko in KO.items():
        eid = ids.get(code)
        if eid is None:
            continue
        if get_meaning(conn, eid, 'KO')[0] == ko:
            continue
        if not dry:
            set_meaning(conn, eid, {'KO': ko})
        n_ko += 1
    if miss and not dry and not quiet:
        print('⚠ 없는 엔티티 코드 %d: %s' % (len(miss), ', '.join(sorted(miss))))
    return n_en, n_ko


# ── selftest ───────────────────────────────────────────────────────────
def _selftest():
    import sqlite3
    ok, bad = [], []

    def chk(name, cond, extra=''):
        (ok if cond else bad).append(name + (('  ' + str(extra)) if extra else ''))

    # ── 어원 파싱 — 실측한 꼴 그대로 ──────────────────────────────
    t = parse('from 1 and 3050; father (i.e. worshipper) of Jah;')
    chk('★ 뜻을 뽑는다', t['meaning'] == 'father of Jah', t['meaning'])
    chk('★ 부모 번호를 뽑는다', t['parents'] == [1, 3050], t['parents'])

    t = parse('or prolonged אֵלִיָּהוּ; from 410 and 3050; God of Jehovah;')
    chk('★ 이형 표기가 섞여도 뜻', t['meaning'] == 'God of Jehovah', t['meaning'])
    chk('  히브리 글자를 뜻으로 안 읽는다', 'אֵ' not in (t['meaning'] or ''))

    chk('★ 「어디서 왔나」만 있으면 뜻 없음',
        parse('of foreign origin;')['meaning'] is None)
    chk('  contracted from N 도 뜻 없음',
        parse('contracted from 23;')['meaning'] is None)
    chk('  intensive from N 도 뜻 없음',
        parse('intensive from 6;')['meaning'] is None)
    chk('  the same as N 도 뜻 없음',
        parse('the same as 2896;')['meaning'] is None)
    chk('  빈 어원은 안 죽는다',
        parse('')['meaning'] is None and parse(None)['parents'] == [])
    t = parse('from 5414; given;')
    chk('★ 짧은 뜻도 뽑는다', t['meaning'] == 'given', t['meaning'])

    # ⚠ 뜻과 출처가 한 조각에 섞이면 **뜻으로 안 읽는다**(지어내지 않는다)
    chk('  번호가 든 조각은 뜻이 아니다',
        parse('from the same as 1730; loving;')['meaning'] == 'loving')

    # ── 이름 정규화 ───────────────────────────────────────────────
    chk('★ 대소문자·관사·부호를 걷는다',
        _norm('The Jordan!') == _norm('jordan')
        and _norm('David') == _norm('david'))
    # ── 같은 소리의 철자 차이 (2026-09-07) ───────────────────────
    for a, b in (('Jochebed', 'Jokebed'), ('Zipporah', 'Tsipporah'),
                 ('Michal', 'Mikal'), ('Pharaoh', 'Pharao'),
                 ('Rebekah', 'Rebecca'), ('Malachi', 'Malaki')):
        chk('★ 철자만 다른 같은 이름 — %s ↔ %s' % (a, b), _norm(a) == _norm(b),
            '%s | %s' % (_norm(a), _norm(b)))
    # ⚠⚠ **탐지력** — 모음을 지웠다가 이것들이 걸렸다. 되돌아가면 여기서 잡힌다.
    for a, b in (('Thomas', 'Timaeus'), ('Ahithophel', 'Tophel'),
                 ('Bethany', 'Bithynia'), ('Peniel', 'Phanuel')):
        chk('★★ 다른 이름은 안 맞는다 — %s ↔ %s' % (a, b), _norm(a) != _norm(b),
            '%s | %s' % (_norm(a), _norm(b)))
    chk('★ 괄호 안 이름을 뽑는다',
        gloss_names('Jehoshua (i.e. Joshua), the Jewish leader')
        == ['Jehoshua', 'Joshua'],
        gloss_names('Jehoshua (i.e. Joshua), the Jewish leader'))
    chk('  (or X) 도 뽑는다',
        gloss_names('Hadassah (or Esther)') == ['Hadassah', 'Esther'])
    chk('  괄호가 없으면 하나', gloss_names('David, the youngest son') == ['David'])
    chk('  빈 뜻풀이는 빈손', gloss_names('') == [] and gloss_names(None) == [])

    # ── 매칭·저장(메모리 DB) ──────────────────────────────────────
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY,
        entity_code TEXT, entity_type TEXT, json_detail TEXT,
        record_status TEXT DEFAULT 'LIVE');
      CREATE TABLE sys_text_asset(clicked_id INTEGER, text_type TEXT,
        lang_code TEXT, contents TEXT, record_status TEXT DEFAULT 'LIVE');
      CREATE TABLE sys_lemma_master(strong TEXT, lang_code TEXT, translit TEXT,
        pos TEXT, gloss TEXT, deriv TEXT);
    """)
    c.execute("INSERT INTO sys_entity_master(entity_id,entity_code,entity_type,"
              "json_detail) VALUES (1,'P_DAVID','PERSON','{\"tribe\":\"JUDAH\"}')")
    c.execute("INSERT INTO sys_entity_master(entity_id,entity_code,entity_type) "
              "VALUES (2,'P_TOB','PERSON')")
    for eid, nm in ((1, 'David'), (2, 'Tob')):
        c.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,"
                  "contents) VALUES (?,'ENTITY_NAME','EN',?)", (eid, nm))
    c.execute("INSERT INTO sys_lemma_master VALUES "
              "('H1732','HE','David','n-pr-m','David, the youngest son',"
              "'from the same as 1730; loving;')")
    # 같은 이름·같은 유형의 낱말 둘 → 검토로 가야 한다
    # ⚠ 유형이 다르면(지명 vs 인명) 가드가 걸러 자동이 된다 — 그것이 옳다.
    c.execute("INSERT INTO sys_lemma_master VALUES "
              "('H2898','HE','tuwb','n-pr-m','Tob, a man','from 2895; good;')")
    c.execute("INSERT INTO sys_lemma_master VALUES "
              "('H2899','HE','towb','n-pr-m','Tob, another man','from 2895; fine;')")
    c.commit()

    auto, rev = candidates(c)
    chk('★ 하나뿐이고 뜻이 있으면 자동',
        len(auto) == 1 and auto[0]['code'] == 'P_DAVID', [a['code'] for a in auto])
    chk('★ 같은 이름이 여럿이면 검토로',
        len(rev) == 1 and rev[0]['code'] == 'P_TOB', [r['code'] for r in rev])
    chk('  자동 후보가 뜻을 들고 온다', auto[0]['meaning'] == 'loving',
        auto[0]['meaning'])

    n = apply_auto(c)
    chk('★ 담긴다', n == 1)
    got, st = get_meaning(c, 1, 'EN')
    chk('  뜻이 읽힌다', got == 'loving', got)
    chk('  strong 도 함께', st == 'H1732', st)
    chk('★ 다른 열쇠를 안 지운다',
        json.loads(c.execute("SELECT json_detail FROM sys_entity_master "
                             "WHERE entity_id=1").fetchone()[0]).get('tribe') == 'JUDAH')
    chk('★ 두 번 돌려도 안 는다', apply_auto(c) == 0)

    set_meaning(c, 1, {'KO': '사랑받는 자'})
    chk('★ 한국어를 더해도 영어가 산다',
        get_meaning(c, 1, 'KO')[0] == '사랑받는 자'
        and get_meaning(c, 1, 'EN')[0] == 'loving')
    chk('  모르는 언어는 EN 으로 물러선다',
        get_meaning(c, 1, 'JA')[0] == 'loving')
    chk('★ 사람이 다듬은 것을 기계가 안 덮는다', apply_auto(c) == 0)
    set_meaning(c, 1, {'KO': ''})
    chk('  빈 값은 그 언어를 지운다', get_meaning(c, 1, 'KO')[0] == 'loving')
    chk('  뜻이 없는 엔티티는 (None, None)', get_meaning(c, 2) == (None, None))
    chk('★ 제외 표에 있으면 안 담는다',
        all(k not in {r['code'] for r in candidates(c)[0]} for k in EXCLUDE))
    chk('  제외 표는 까닭을 적는다', all(v for v in EXCLUDE.values()))

    # ── 가드 둘 — 뜻을 못 고르는 자리는 안 담는다(2026-09-07) ────────
    #   ⚠ **탐지력을 양방향으로** 잰다 — 막기만 하면 개선이 죽는다.
    chk('★ `or else` 로 뜻이 둘이면 안 뽑는다',
        parse('perhaps from 3394; its month; or else from 7306; fragrant;')
        ['meaning'] is None)
    chk('  그래도 번호는 낸다(사람이 따라가라고)',
        7306 in parse('perhaps from 3394; its month; or else from 7306; '
                      'fragrant;')['parents'])
    chk('  뜻이 하나면 그대로 뽑는다',
        parse('from 1 and 3050; father of Jah;')['meaning'] == 'father of Jah')
    chk('★ 부모 gloss 가 고유명사면 뜻이 아니다',
        _gloss_meaning('Shiloh, an epithet of the Messiah') is None)
    chk('  소문자로 시작하는 진짜 뜻은 통과',
        _gloss_meaning('a wheel; by analogy, a whirlwind') == 'wheel'
        and _gloss_meaning('properly, a mortal') == 'properly, a mortal')

    # ── 사람이 정한 표 = 파일 원장(§183차 ⑤) ─────────────────────────
    chk('★ 손으로 정한 뜻은 근거를 함께 적는다',
        all(len(v) == 3 and v[0] and v[1] and v[2]
            for v in MANUAL_MEANING.values()),
        [k for k, v in MANUAL_MEANING.items() if not (len(v) == 3 and all(v))])
    chk('  스트롱 번호 꼴이 맞다',
        all(re.match(r'^[HG]\d+$', v[0]) for v in MANUAL_MEANING.values()),
        [v[0] for v in MANUAL_MEANING.values()
         if not re.match(r'^[HG]\d+$', v[0])])
    chk('★ 한 코드가 두 표에 함께 들지 않는다',
        not (set(MANUAL_MEANING) & set(EXCLUDE))
        and not (set(MANUAL) & set(EXCLUDE)),
        sorted(set(MANUAL_MEANING) & set(EXCLUDE)))
    chk('★ 손으로 정한 것은 검토 목록에 안 남는다',
        all(k not in {r['code'] for r in candidates(c)[1]}
            for k in MANUAL_MEANING))
    chk('  한국어 원장이 EN 을 그대로 베끼지 않았다',
        all(v.strip() and not re.match(r'^[A-Za-z ,.()-]+$', v)
            for v in KO.values()),
        [k for k, v in KO.items() if re.match(r'^[A-Za-z ,.()-]+$', v)])

    # apply_manual — **있는 코드만** 건드린다(시험 DB 에는 다윗 하나뿐이다)
    n_en, n_ko = apply_manual(c, dry=True)
    chk('★ 없는 코드에는 아무것도 안 담는다',
        n_en == 0 and n_ko == 1, (n_en, n_ko))
    apply_manual(c, quiet=True)
    chk('  파일 원장대로 담긴다', get_meaning(c, 1, 'KO')[0] == KO['P_DAVID'],
        get_meaning(c, 1, 'KO')[0])
    chk('★ 두 번 돌려도 안 는다', apply_manual(c, quiet=True) == (0, 0))

    # ── 유형 가드 (실측으로 약하게 정한 규칙) ─────────────────────
    chk('★ 사람에게 지명 전용 낱말은 안 붙인다',
        not type_ok('PERSON', 'n-pr-loc'))
    chk('  인명 겸 지명은 통과', type_ok('PERSON', 'n-pr-m n-pr-loc'))
    chk('★ 성별로는 안 거른다(우리 데이터가 부정확)',
        type_ok('PERSON', 'n-pr-f', 'M') and type_ok('PERSON', 'n-pr-m', 'F'))
    chk('★ 장소는 안 거른다(Strong 품사가 부정확 — 마라가 n-pr-f)',
        type_ok('PLACE', 'n-pr-f') and type_ok('PLACE', 'n-pr-m'))
    chk('  품사가 비면 통과(헬라어)', type_ok('PERSON', '') and type_ok('PLACE', None))

    # ── 부모 한 단계 따라가기 (실측으로 정한 규칙) ────────────────
    # ⚠ 값은 `(어원, 뜻풀이)` 짝이다 — 부모의 뜻은 **뜻풀이**에 있다(실측).
    idx = {'H1682': ('from 1696 (in the sense of orderly);', 'the bee (from its instincts)'),
           'H1683': ('or (shortened); the same as 1682;', 'Deborah, the name of two Hebrews'),
           'H474': ('from 410 and 7768; God of supplication;', 'Elishua'),
           'H477': ('contracted for 474.;', 'Elisha, an Israelite'),
           'H99': ('from 1 and 2; father of two;', 'Abida'),
           'H3611': ('from an unused root;', 'a dog'),
           'H3612': ('perhaps a form of 3611, or else from the same root;', 'Caleb')}
    m, ind = resolve_meaning(idx['H1683'][0], 'HE', idx)
    chk('★ 부모의 뜻풀이를 따라간다(드보라 → 벌)',
        m == 'bee' and ind, m)
    m, ind = resolve_meaning(idx['H477'][0], 'HE', idx)
    chk('★ contracted for 도 따라간다(엘리사)', m and ind, m)
    m, ind = resolve_meaning(idx['H99'][0], 'HE', idx)
    chk('  제 뜻이 있으면 안 따라간다(간접 아님)',
        m == 'father of two' and not ind, m)
    m, _ = resolve_meaning('the same as 9999;', 'HE', idx)
    chk('  없는 부모면 뜻 없음', m is None)
    m, _ = resolve_meaning(idx['H1683'][0], 'HE', idx, depth=0)
    chk('★ 한 단계만 간다', m is None)
    m, _ = resolve_meaning(idx['H3612'][0], 'HE', idx)
    chk('★ 불확실한 어원은 안 따라간다(갈렙 perhaps → 개)', m is None, m)
    chk('★ 고유명사 뜻풀이는 뜻이 아니다',
        _gloss_meaning('Deborah, the name of two Hebrews') is None)
    chk('  뜻풀이는 첫 절만 · 관사를 걷는다',
        _gloss_meaning('the bee (from its instincts)') == 'bee'
        and _gloss_meaning('lightning; by analogy') == 'lightning')
    chk('  「contraction for」 는 뜻이 아니다',
        parse('contraction for ;')['meaning'] is None)
    chk('  「a variation of N」 도 뜻이 아니다',
        parse('a variation of 5833;')['meaning'] is None)
    chk('  「in Ezekiel it is」 를 뜻으로 안 읽는다',
        parse('in Ezekiel it is; דָּנִאֵל; from 1835 and 410; judge of God;')
        ['meaning'] == 'judge of God')

    print('db_name_meaning selftest: %d/%d' % (len(ok), len(ok) + len(bad)))
    for b in bad:
        print('  FAIL:', b)
    return 0 if not bad else 1


# ── CLI ────────────────────────────────────────────────────────────────
def main(argv):
    if '--selftest' in argv:
        return _selftest()
    c = (appdb.connect('bible_master.db') if appdb else None)
    if c is None:
        print('appdb 없음')
        return 1
    if '--check' in argv:
        auto, rev = candidates(c)
        print('자동 %d · 검토 %d' % (len(auto), len(rev)))
        for r in auto[:20]:
            print('  %-20s %-16s %-7s %s'
                  % (r['code'], r['name'], r['lex']['strong'], r['meaning']))
        if rev:
            print('  — 검토(같은 이름 여럿이거나 뜻 없음) —')
            for r in rev[:15]:
                print('  %-20s %-16s 낱말 %d개 · 뜻 %s'
                      % (r['code'], r['name'], r['n_lex'], r['meaning']))
        return 0
    if '--apply' in argv:
        # ★ 사람이 정한 표가 먼저다 — 자동이 그 자리를 채우면 안 된다.
        n_en, n_ko = apply_manual(c)
        n = apply_auto(c)
        print('사람이 정한 것 영어 %d · 한국어 %d · 자동 %d' % (n_en, n_ko, n))
        return 0
    n = c.execute("SELECT COUNT(*) FROM sys_entity_master "
                  "WHERE json_detail LIKE '%name_meaning%'").fetchone()[0]
    print('이름의 뜻을 가진 엔티티 %d' % n)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
