# -*- coding: utf-8 -*-
"""이단·타종교 정리 — 거르는 말(채널 층·콘텐츠 층)을 **이미 담긴 것**에 소급 적용한다.

수집 문지기(`media_intake.screen`)·최신 발행(`latest_rules`)·발굴(`db_channel_mine`)은
새로 들어오는 것만 거른다. 낱말을 늘려도 **이미 승인된 것은 안 바뀐다**(§207차
「규칙과 재분류는 별개」). 이 도구가 그 소급을 맡는다(2026-09-09 사용자 지시
「이미 승인 된 데이터를 모두 정리하라」).

  --scan     무엇이 걸리는지 채널별로 낸다(쓰지 않는다)
  --apply    ① 채널 층에 걸린 영상 → 승인 취소(표식) · 채널을 차단 표에(유튜브 id 와 함께)
               · 등록돼 있으면 수집 멈춤 · 발굴 표는 제외로
             ② 콘텐츠 층(교파)에 걸린 **승인** 영상 → ⚠ 제외후보 표식만(승인은 사람이 정한다)
  --undo     --apply 가 남긴 표식으로 전부 되돌린다
  --selftest 메모리 DB 로 양방향(적용 → 되돌림 · 탐지력)

★ 판정 문은 **수집 문지기와 같은 것**(`media_exclude.match_channel/match_exclude`) —
  여기서 다시 짜면 「수집은 막는데 정리는 못 잡는」 어긋남이 난다.
★ 채널을 차단하는 잣대 = **채널 이름·설명이 걸리거나, 그 채널의 영상이 둘 이상이고
  전부 걸릴 때**. 영상 하나만 걸린 채널(반박 영상일 수 있다)은 영상만 내리고
  채널은 보고에 남긴다 — 사람이 정한다.
⚠ 지우지 않는다 — `is_active` 만 내리고 표식(`swept`)을 적는다. `--undo` 가 되돌린다.
"""
import os, sys, json, sqlite3, collections
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb
import media_exclude as MX

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bible_master.db')
TAG = 'HERESY_SWEEP_%s' % date.today().strftime('%Y%m%d')
CFG_UNDO = 'HERESY_SWEEP_UNDO'     # 되돌릴 재료(수집 멈춘 채널 번호 등)


def _rows(conn):
    out = []
    for mid, lang, title, desc, act in conn.execute(
            "SELECT media_id, lang_code, title, description, is_active FROM sys_media_asset "
            "WHERE COALESCE(record_status,'LIVE')='LIVE'"):
        try:
            d = json.loads(desc or '{}') if desc else {}
        except Exception:
            d = {}
        if not isinstance(d, dict):
            d = {}
        out.append({'media_id': mid, 'lang': (lang or '').upper(), 'title': title or '',
                    'channel': d.get('channel') or '', 'channel_id': d.get('channel_id') or '',
                    'desc': d.get('yt_desc') or '', 'act': int(act or 0), 'd': d})
    return out


def scan(conn, chan_map=None, excl_map=None):
    """→ (채널 층 걸림 목록, 콘텐츠 층 걸림 목록, 채널 요약)."""
    chan_map = chan_map if chan_map is not None else MX.get_channel_map(DB)
    excl_map = excl_map if excl_map is not None else MX.get_exclude_map(DB)
    ch_hits, ex_hits = [], []
    per = collections.defaultdict(lambda: {'n': 0, 'hit': 0, 'act': 0, 'name_hit': None,
                                           'ids': set(), 'lang': ''})
    for r in _rows(conn):
        p = per[r['channel']]
        p['n'] += 1; p['lang'] = p['lang'] or r['lang']
        if r['channel_id']:
            p['ids'].add(r['channel_id'])
        kw = MX.match_channel('%s\n%s\n%s' % (r['channel'], r['title'], r['desc'][:600]),
                              kw_list=chan_map, lang=r['lang'] or None)
        if kw:
            r['kw'] = kw
            ch_hits.append(r)
            p['hit'] += 1; p['act'] += r['act']
            if MX.match_channel(r['channel'], kw_list=chan_map, lang=r['lang'] or None):
                p['name_hit'] = kw
            continue
        if r['act']:
            kx = MX.match_exclude('%s %s' % (r['title'], r['channel']), kw_list=excl_map,
                                  lang=r['lang'] or None)
            if kx:
                r['kw'] = kx
                ex_hits.append(r)
    return ch_hits, ex_hits, per


def channels_to_block(per):
    """차단할 채널 = 이름이 걸렸거나, 영상 둘 이상이 전부 걸린 채널."""
    out = []
    for name, p in per.items():
        if not name or not p['hit']:
            continue
        if p['name_hit'] or (p['n'] >= 2 and p['hit'] == p['n']):
            out.append((name, p))
    return out


def report(conn):
    ch_hits, ex_hits, per = scan(conn)
    blk = channels_to_block(per)
    print('채널 층 걸림 %d편(승인 %d) · 콘텐츠 층 승인 걸림 %d편'
          % (len(ch_hits), sum(r['act'] for r in ch_hits), len(ex_hits)))
    print('-- 차단할 채널 %d' % len(blk))
    for name, p in sorted(blk, key=lambda x: -x[1]['hit']):
        print('  %3d/%-3d 승인 %2d | %-45s | %s | id %s' % (
            p['hit'], p['n'], p['act'], name[:45], p['name_hit'] or '(영상 전부)',
            ','.join(sorted(p['ids']))[:30] or '-'))
    rest = [(n, p) for n, p in per.items() if p['hit'] and (n, p) not in blk]
    print('-- 영상만 내리는 채널 %d (사람이 채널 차단 여부를 정한다)' % len(rest))
    for name, p in sorted(rest, key=lambda x: -x[1]['hit'])[:40]:
        ex = next(r for r in ch_hits if r['channel'] == name)
        print('  %3d/%-3d 승인 %2d | %-40s | %s | %s' % (
            p['hit'], p['n'], p['act'], name[:40], ex['kw'], ex['title'][:50]))
    print('-- 콘텐츠 층(교파) 승인 걸림 — 낱말별')
    for kw, n in collections.Counter(r['kw'] for r in ex_hits).most_common():
        print('  %3d | %s' % (n, kw))
    return ch_hits, ex_hits, per


#: ★★ **사유 갈래를 낱말이 정한다**(2026-09-09 사용자 「다른 종교는 무조건 제외」).
#:   그전에는 걸린 채널이 전부 `HERESY`(이단/사이비)로 들어가 **가톨릭·정교회·불교가
#:   이단으로 기록**됐다 — 사유 분포가 곧 거짓이 된다.
#: ⚠ 여기 없는 낱말은 `HERESY` 다(이 도구의 본래 몫). **모르면 짐작하지 않는다.**
OTHER_RELIGION_KW = (
    '가톨릭', '천주교', '대교구', '수녀회', '평화방송', 'cpbc', 'katholisch',
    'catholic', 'católic', 'cattolic', 'catholique', 'カトリック', '司教区', '天主教',
    '한국정교회', '대한정교회', 'orthodox', 'ortodox', 'православ', 'coptic',
    'قبطي', 'الكنيسة القبطية', 'الكنيسة الكاثوليكية',
    '스님', '조계종', '조계사', '봉은사', '템플스테이', '불교', '仏教', '佛教',
    '원불교', '대순진리', '증산도', '천도교', '創価学会', '真言宗', '浄土真宗',
    'soka gakkai', 'hare krishna', 'bhagavad', 'buddhis', 'hindu',
    'islam', 'quran', "qur'an", 'koran', 'masjid', 'الدعوة الإسلامية',
    'الدعوة الاسلامية', '이슬람', '무슬림', '꾸란', '코란',
    # ★ 유대교(2026-09-12) — 이단이 아니라 **다른 종교**다. 분포가 곧 거짓이
    #   되지 않게 사유를 가른다(§228차 ③ 그 자리).
    'judaism', 'judaismo', 'judaísmo', 'jewish learning', 'chabad',
    'lubavitch', 'yeshiva', 'talmud', 'midrash', 'kollel', 'beth din',
    'bet din', 'daf yomi', 'gemara', 'mishnah', 'parsha', 'aish hatorah',
    'ohr somayach', 'hebrew union', '유대교', '탈무드', '카발라',
    'kabbalah', 'zohar', 'halakha', 'halacha', 'ユダヤ教', '猶太教', '犹太教',
)


def reason_of(kw):
    """걸린 낱말 → 차단 사유 코드. 갈래는 `sys_media_excl_reason` 의 것을 쓴다."""
    low = (kw or '').lower()
    for w in OTHER_RELIGION_KW:
        if w in low:
            return 'OTHER_RELIGION'
    return 'HERESY'


def apply(conn, dry=False):
    ch_hits, ex_hits, per = scan(conn)
    blk = channels_to_block(per)
    n_un = n_ex = n_blk = n_off = n_mine = 0
    undo = {'enabled_off': [], 'tag': TAG}
    try:   # 두 번째 적용이 첫 번째의 되돌림 재료를 덮지 않게 이어 붙인다
        _r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?", (CFG_UNDO,)).fetchone()
        if _r and _r[0]:
            undo['enabled_off'] = list(json.loads(_r[0]).get('enabled_off') or [])
    except Exception:
        pass
    if not dry:
        for r in ch_hits:
            d = dict(r['d']); d['swept'] = '%s:%s' % (TAG, r['kw'])
            d['exclude_kw'] = r['kw']
            if r['act']:
                d['swept_was_active'] = 1
                n_un += 1
            conn.execute("UPDATE sys_media_asset SET is_active=0, description=? WHERE media_id=?",
                         (json.dumps(d, ensure_ascii=False), r['media_id']))
        # ★ 콘텐츠 층(교파)은 **⚠ 표식만** 붙이고 승인은 안 내린다 — 실측 「주교」가
        #   방주교회·우리주교회에, 「Rosenkranz」가 목사 성(姓)에 걸렸다. 살릴 것이 섞이는
        #   층이라 사람이 본다(--scan 이 목록을 낸다).
        for r in ex_hits:
            d = dict(r['d'])
            if d.get('exclude_kw') == r['kw']:
                continue
            d['exclude_kw'] = r['kw']
            conn.execute("UPDATE sys_media_asset SET description=? WHERE media_id=?",
                         (json.dumps(d, ensure_ascii=False), r['media_id']))
            n_ex += 1
        have = {(row[0] or '').strip().lower() for row in conn.execute(
            "SELECT channel_name FROM sys_media_excluded_channel WHERE COALESCE(record_status,'LIVE')='LIVE'")}
        for name, p in blk:
            ext = sorted(p['ids'])[0] if p['ids'] else None
            if name.strip().lower() not in have:
                conn.execute("INSERT INTO sys_media_excluded_channel (channel_name, reason_code, "
                             "reason_detail, excluded_at, excluded_by, record_status, channel_ext_id) "
                             "VALUES (?,?,?,?,?,?,?)",
                             (name, reason_of(p['name_hit']),
                              '%s:%s' % (TAG, p['name_hit'] or '전부 걸림'),
                              date.today().isoformat(), 'SWEEP', 'LIVE', ext))
                n_blk += 1
            elif ext:
                conn.execute("UPDATE sys_media_excluded_channel SET channel_ext_id=COALESCE(channel_ext_id,?) "
                             "WHERE channel_name=? AND COALESCE(record_status,'LIVE')='LIVE'", (ext, name))
            for cid, en in conn.execute("SELECT channel_id, enabled FROM sys_media_channel WHERE "
                                        "(channel_name=? OR channel_ext_id=?) AND COALESCE(record_status,'LIVE')='LIVE'",
                                        (name, ext or '')).fetchall():
                if en:
                    conn.execute("UPDATE sys_media_channel SET enabled=0 WHERE channel_id=?", (cid,))
                    undo['enabled_off'].append(cid); n_off += 1
            try:
                cur = conn.execute("UPDATE sys_mine_channel SET status='BLOCK', note=? WHERE "
                                   "(channel_id=? OR title=?) AND status IN ('NEW','SKIP')",
                                   ('거르는 말: %s' % (p['name_hit'] or '전부 걸림'), ext or '', name))
                n_mine += cur.rowcount
            except Exception:
                pass
        conn.execute("CREATE TABLE IF NOT EXISTS sys_config(config_key TEXT PRIMARY KEY, config_val TEXT)")
        conn.execute("INSERT OR REPLACE INTO sys_config(config_key, config_val) VALUES(?,?)",
                     (CFG_UNDO, json.dumps(undo)))
        conn.commit()
    return {'ch_hits': len(ch_hits), 'unapproved': n_un, 'excl_unapproved': n_ex,
            'blocked': n_blk, 'enabled_off': n_off, 'mine_rej': n_mine, 'to_block': len(blk)}


BLOCK_TAG = 'CHANNEL_BLOCK'


def _chan_match_sql():
    return ("json_valid(description)=1 AND (json_extract(description,'$.channel_id')=? "
            "OR json_extract(description,'$.channel')=?)")


def unapprove_channel(conn, name=None, ext_id=None, today=None):
    """★★ **손으로 차단한 채널의 승인 영상을 내린다**(2026-09-16 · 1.txt 17-1 (4)).

    사용자 「채널을 차단하면 그 채널 영상은 **당연히 자동 차단될 것이라고 이해**한다」 —
    그전에는 `--apply` 가 **거르는 말로 걸린 채널만** 내렸고, 차단 채널 탭·발굴 화면·
    ④ 연결심사에서 손으로 차단한 채널의 승인 영상은 그대로 사용자에게 나갔다.
    ★ 문은 `panel_media_channel.exclude_channel` 하나라 거기서 이것을 부른다.
    ⚠ **지우지 않는다** — description 에 `swept=CHANNEL_BLOCK:날짜`·`swept_was_active` 를
      남겨 `undo_channel_block` 이 되돌린다(§222차). 등록 채널이면 **수집도 멈춘다**
      (`enabled=0` · note 에 표식) — 차단했는데 다음 날 또 담기면 거짓말이다.
    → {'unapproved': n, 'paused': m}
    """
    name = (name or '').strip(); ext_id = (ext_id or '').strip()
    if not name and not ext_id:
        return {'unapproved': 0, 'paused': 0}
    today = today or date.today().isoformat()
    tag = '%s:%s' % (BLOCK_TAG, today)
    n = 0
    rows = conn.execute("SELECT media_id, description FROM sys_media_asset WHERE "
                        "COALESCE(record_status,'LIVE')='LIVE' AND is_active=1 AND "
                        + _chan_match_sql(), (ext_id or '\x00', name or '\x00')).fetchall()
    for mid, desc in rows:
        try:
            d = json.loads(desc) if desc else {}
        except Exception:
            d = {}
        d['swept'] = tag; d['swept_was_active'] = 1
        conn.execute("UPDATE sys_media_asset SET is_active=0, description=? WHERE media_id=?",
                     (json.dumps(d, ensure_ascii=False), mid))
        n += 1
    m = 0
    try:
        have = {r[1] for r in conn.execute("PRAGMA table_info(sys_media_channel)")}
        if 'note' not in have:
            conn.execute("ALTER TABLE sys_media_channel ADD COLUMN note TEXT")
        for cid, en, note in conn.execute(
                "SELECT channel_id, enabled, COALESCE(note,'') FROM sys_media_channel WHERE "
                "COALESCE(record_status,'LIVE')='LIVE' AND (channel_ext_id=? OR channel_name=?)",
                (ext_id or '\x00', name or '\x00')).fetchall():
            if en:
                conn.execute("UPDATE sys_media_channel SET enabled=0, note=? WHERE channel_id=?",
                             ((note + ' ' if note else '') + tag, cid))
                m += 1
    except Exception:
        pass
    conn.commit()
    return {'unapproved': n, 'paused': m}


def undo_channel_block(conn, name=None, ext_id=None):
    """차단을 풀 때 — `unapprove_channel` 이 내린 승인과 멈춘 수집을 되돌린다."""
    name = (name or '').strip(); ext_id = (ext_id or '').strip()
    n = m = 0
    if not name and not ext_id:
        return {'videos': 0, 'enabled_on': 0}
    rows = conn.execute("SELECT media_id, description FROM sys_media_asset WHERE "
                        "description LIKE ? AND " + _chan_match_sql(),
                        ('%"swept": "' + BLOCK_TAG + '%', ext_id or '\x00', name or '\x00')).fetchall()
    for mid, desc in rows:
        try:
            d = json.loads(desc)
        except Exception:
            continue
        if not str(d.get('swept', '')).startswith(BLOCK_TAG):
            continue
        was = int(d.pop('swept_was_active', 0) or 0)
        d.pop('swept', None)
        conn.execute("UPDATE sys_media_asset SET is_active=?, description=? WHERE media_id=?",
                     (was, json.dumps(d, ensure_ascii=False), mid))
        n += 1
    try:
        for cid, note in conn.execute(
                "SELECT channel_id, COALESCE(note,'') FROM sys_media_channel WHERE "
                "note LIKE ? AND (channel_ext_id=? OR channel_name=?)",
                ('%' + BLOCK_TAG + ':%', ext_id or '\x00', name or '\x00')).fetchall():
            new = ' '.join(w for w in note.split() if not w.startswith(BLOCK_TAG + ':'))
            conn.execute("UPDATE sys_media_channel SET enabled=1, note=? WHERE channel_id=?",
                         (new or None, cid))
            m += 1
    except Exception:
        pass
    conn.commit()
    return {'videos': n, 'enabled_on': m}


def undo(conn):
    n_v = n_b = n_e = 0
    for mid, desc in conn.execute("SELECT media_id, description FROM sys_media_asset "
                                  "WHERE description LIKE '%\"swept\"%'").fetchall():
        try:
            d = json.loads(desc)
        except Exception:
            continue
        if not str(d.get('swept', '')).startswith('HERESY_SWEEP_'):
            continue
        was = int(d.pop('swept_was_active', 0) or 0)
        d.pop('swept', None); d.pop('exclude_kw', None)
        conn.execute("UPDATE sys_media_asset SET is_active=?, description=? WHERE media_id=?",
                     (was, json.dumps(d, ensure_ascii=False), mid))
        n_v += 1
    cur = conn.execute("DELETE FROM sys_media_excluded_channel WHERE reason_detail LIKE 'HERESY_SWEEP_%'")
    n_b = cur.rowcount
    try:
        row = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?", (CFG_UNDO,)).fetchone()
        for cid in (json.loads(row[0]).get('enabled_off') if row else []) or []:
            conn.execute("UPDATE sys_media_channel SET enabled=1 WHERE channel_id=?", (cid,)); n_e += 1
        conn.execute("DELETE FROM sys_config WHERE config_key=?", (CFG_UNDO,))
    except Exception:
        pass
    conn.commit()
    return {'videos': n_v, 'blocks': n_b, 'enabled_on': n_e}


def selftest():
    ok = [0, 0]
    def t(nm, cond, got=''):
        ok[0 if cond else 1] += 1
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got if not cond else ''))
    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY, lang_code TEXT, title TEXT, "
              "description TEXT, is_active INTEGER, record_status TEXT DEFAULT 'LIVE')")
    c.execute("CREATE TABLE sys_media_excluded_channel(excl_id INTEGER PRIMARY KEY, channel_name TEXT, "
              "reason_code TEXT, reason_detail TEXT, excluded_at TEXT, excluded_by TEXT, record_status TEXT, "
              "channel_ext_id TEXT)")
    c.execute("CREATE TABLE sys_media_channel(channel_id INTEGER PRIMARY KEY, channel_name TEXT, "
              "channel_ext_id TEXT, enabled INTEGER, record_status TEXT DEFAULT 'LIVE')")
    c.execute("CREATE TABLE sys_mine_channel(channel_id TEXT PRIMARY KEY, title TEXT, status TEXT, note TEXT)")
    def add(mid, lang, title, ch, act, cid='', desc=''):
        c.execute("INSERT INTO sys_media_asset(media_id,lang_code,title,description,is_active) VALUES(?,?,?,?,?)",
                  (mid, lang, title, json.dumps({'channel': ch, 'channel_id': cid, 'yt_desc': desc}), act))
    add(1, 'KO', '대속죄일의 의미 ▶ 하나님의교회 세계복음선교협회', 'Church of God TUBE', 1, 'UCWM1')
    add(2, 'KO', '성경의 안식일은 무슨 요일', 'Church of God TUBE', 1, 'UCWM1')
    add(3, 'KO', '창세기 1장 전능하신 하나님', '매일성경', 1)
    add(4, 'JA', '創世記18-23章', 'norio koyama', 1, '', '末日聖徒イエス・キリスト教会の学び')
    add(5, 'RU', 'Заблуждения Свидетелей Иеговы: Ин 1:1', 'Valery', 1)
    add(6, 'RU', 'Иоанна 1:2 проповедь', 'Valery', 1)
    add(7, 'EN', 'Day 49 The Bible in a Year with Fr. Mike Catholic Mass', 'Ascension', 1)
    add(8, 'EN', 'Holy Rosary meditation', 'X', 0)
    add(9, 'AR', 'نور يسوع المسيح', 'كنيسة يسوع المسيح لقديسي الأيام الأخيرة', 0, 'UCLDS')
    c.execute("INSERT INTO sys_media_channel VALUES(1,'كنيسة يسوع المسيح لقديسي الأيام الأخيرة','UCLDS',1,'LIVE')")
    c.execute("INSERT INTO sys_mine_channel VALUES('UCLDS','x','NEW',NULL)")
    c.commit()
    ch, ex, per = scan(c, MX.CHANNEL_KW_LANG, MX.EXCLUDE_KW_LANG)
    got = {r['media_id'] for r in ch}
    t('★ 채널 층 — 단체 표기가 든 것만 걸린다(1·4·5·9)', got == {1, 4, 5, 9}, got)
    t('  홑낱말 「전능하신 하나님」·같은 채널의 다른 제목은 안 걸린다', 2 not in got and 3 not in got)
    t('★ 콘텐츠 층 — 승인된 교파 낱말만(7 · 미승인 8 은 제외)', {r['media_id'] for r in ex} == {7})
    blk = {n for n, _ in channels_to_block(per)}
    t('★ 차단할 채널 = 이름이 걸린 것(몰몬 AR) 뿐 · 영상 하나만 걸린 Valery 는 아니다',
      blk == {'كنيسة يسوع المسيح لقديسي الأيام الأخيرة'}, blk)
    t('  Church of God TUBE 는 2편 중 1편 걸림 → 채널 차단 대상 아님(보고에 남는다)',
      'Church of God TUBE' not in blk)
    snap = c.execute("SELECT media_id, is_active FROM sys_media_asset ORDER BY 1").fetchall()
    res = apply(c)
    t('★ 적용 — 승인 취소 3(1·4·5) · 교파 ⚠ 1(7) · 차단 1 · 수집 멈춤 1 · 발굴 제외 1',
      (res['unapproved'], res['excl_unapproved'], res['blocked'], res['enabled_off'], res['mine_rej'])
      == (3, 1, 1, 1, 1), res)
    t('  3번(정통)은 그대로 승인', c.execute("SELECT is_active FROM sys_media_asset WHERE media_id=3").fetchone()[0] == 1)
    t('  교파 층은 승인을 안 내리고 ⚠ 만(7번 승인 유지)', c.execute(
        "SELECT is_active FROM sys_media_asset WHERE media_id=7").fetchone()[0] == 1
      and json.loads(c.execute("SELECT description FROM sys_media_asset WHERE media_id=7").fetchone()[0]).get('exclude_kw'))
    t('  차단 표에 유튜브 id 가 함께 간다', c.execute(
        "SELECT channel_ext_id FROM sys_media_excluded_channel").fetchone()[0] == 'UCLDS')
    t('  걸린 영상에 ⚠ 표식(exclude_kw)이 남는다', json.loads(c.execute(
        "SELECT description FROM sys_media_asset WHERE media_id=1").fetchone()[0]).get('exclude_kw') == '세계복음선교협회')
    res2 = apply(c)
    t('  두 번 돌려도 안 는다(멱등)', res2['unapproved'] == 0 and res2['blocked'] == 0, res2)
    u = undo(c)
    after = c.execute("SELECT media_id, is_active FROM sys_media_asset ORDER BY 1").fetchall()
    t('★ 되돌림 — 승인 상태·차단 표·수집 멈춤 전부 원복', after == snap and u['blocks'] == 1
      and c.execute("SELECT enabled FROM sys_media_channel").fetchone()[0] == 1
      and c.execute("SELECT COUNT(*) FROM sys_media_excluded_channel").fetchone()[0] == 0, (u, after))
    t('  표식도 걷힌다', c.execute("SELECT COUNT(*) FROM sys_media_asset WHERE description LIKE '%swept%'").fetchone()[0] == 0)
    # ★★ 손 차단 → 그 채널 승인 영상을 내린다(2026-09-16 · 1.txt 17-1 (4))
    c.execute("INSERT INTO sys_media_channel VALUES(2,'Valery','UCVAL',1,'LIVE')")
    before = c.execute("SELECT media_id, is_active FROM sys_media_asset ORDER BY 1").fetchall()
    r = unapprove_channel(c, name='Valery', ext_id='UCVAL')
    t('★ 손 차단 — 그 채널 승인 2편(5·6)을 내리고 등록 채널 수집을 멈춘다',
      r == {'unapproved': 2, 'paused': 1}
      and c.execute("SELECT SUM(is_active) FROM sys_media_asset WHERE media_id IN (5,6)").fetchone()[0] == 0
      and c.execute("SELECT enabled FROM sys_media_channel WHERE channel_id=2").fetchone()[0] == 0, r)
    t('  딴 채널(3번)은 그대로', c.execute("SELECT is_active FROM sys_media_asset WHERE media_id=3").fetchone()[0] == 1)
    t('  두 번 돌려도 안 는다', unapprove_channel(c, name='Valery')['unapproved'] == 0)
    u2 = undo_channel_block(c, name='Valery', ext_id='UCVAL')
    t('★ 되돌림 — 승인·수집 원복 · 표식 0',
      u2 == {'videos': 2, 'enabled_on': 1}
      and c.execute("SELECT media_id, is_active FROM sys_media_asset ORDER BY 1").fetchall() == before
      and c.execute("SELECT enabled, note FROM sys_media_channel WHERE channel_id=2").fetchone() == (1, None), u2)
    t('  이름도 id 도 없으면 아무것도 안 한다', unapprove_channel(c)['unapproved'] == 0)
    # ★ 사유 갈래 — 낱말이 정한다(2026-09-09)
    t('★ 다른 종교는 OTHER_RELIGION 으로', all(
        reason_of(k) == 'OTHER_RELIGION' for k in
        ('가톨릭', '천주교', 'Coptic', 'Православ', '스님', 'Islamic dawah',
         'katholisch.de', 'カトリック', '天主教會')))
    t('★ 이단은 HERESY 로', all(
        reason_of(k) == 'HERESY' for k in
        ('신천지예수교', '하나님의교회', 'Latter-day Saint', 'Watchtower',
         '전능신교', None, '(영상 전부)')))
    t('  갈래 코드가 사유표에 있는 것이다',
      set(reason_of(k) for k in ('가톨릭', '신천지예수교'))
      <= {'OTHER_RELIGION', 'HERESY'})
    print('db_heresy_sweep selftest %d/%d' % (ok[0], ok[0] + ok[1]))
    return ok[1] == 0


if __name__ == '__main__':
    import io
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False), encoding='utf-8', write_through=True)
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(DB)
    if '--apply' in sys.argv:
        print(apply(conn))
    elif '--undo' in sys.argv:
        print(undo(conn))
    else:
        report(conn)
    conn.close()
