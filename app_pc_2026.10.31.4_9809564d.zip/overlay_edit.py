# -*- coding: utf-8 -*-
"""덮개 편집 — **데이터 층** + 총괄 창 위임 (2026-08-26 재구성).

★ 화면은 `overlay_center.py`(총괄 창 「내 수정 (E)」) 하나다 — 사용자 확정:
  「덮개를 총괄하는 화면을 따로 만들고 클릭한 위치에 따라 탭을 포커스」.
  이 모듈은 ① 상태·비교 조회와 저장/가림/되돌림(엔진 위임) ② 옛 호출부
  (`open_editor`)를 총괄 창으로 넘기는 다리만 맡는다.
⚠ 옛 자체 팝업(_EditorPop — 콤보로 구획 하나씩)은 폐기 — 「따로따로
  표시하는 것보다 한눈에 모든 텍스트를 보면서 수정」(사용자).
`--selftest` 의무(데이터 층).
"""
import sys

import appdb
import overlay


def _adapter(text_type):
    if text_type in overlay.LENS_TEXT_TYPES:
        return overlay.LensTextOverlay(text_type)
    if text_type in overlay.ENTITY_TEXT_TYPES:
        return overlay.EntityTextOverlay(text_type)     # 열쇠 = entity_code
    if text_type in overlay.PERI_TEXT_TYPES:
        return overlay.PeriTextOverlay(text_type)       # 열쇠 = peri_code
    return overlay.TextOverlay(text_type)


def target_state(conn, text_type, clicked_id, lang, variant_pref):
    """지금 보이는 것 — (실제 변형, 상태, 글).

    상태: 'SYS'(기본) · 'EDIT'(내 버전) · 'HIDDEN'(가림) · 'NEW'(내 글) ·
    'NONE'(아무것도 없음 — 새로 쓰면 NEW).
    ⚠ 변형은 **실제 sys 행의 것**을 쓴다 — 선호(LAY)로 물었는데 그 행이
      레거시(NULL)면 열쇠도 '' 라야 fetch 층과 같은 행을 가리킨다.
    """
    lang = (lang or 'KO').upper()
    ad = _adapter(text_type)
    rows = ad.sys_rows(conn, clicked_id)
    cand = [r for r in rows if (r.get('lang_code') or '').upper() == lang
            and (r.get('text_variant') or '') in (variant_pref or '', '')]
    cand.sort(key=lambda r: 0 if (r.get('text_variant') or '') ==
              (variant_pref or '') else 1)
    if cand:
        row = cand[0]
        var = row.get('text_variant') or ''
        key = ad.key_of(row)
        w, p = ad.user_key_where(key)
        u = conn.execute('SELECT contents, record_status FROM %s WHERE %s'
                         % (ad.USER_TBL, w), p).fetchone()
        if u is None:
            return (var, 'SYS', row.get('contents') or '')
        if u[1] == 'HIDE':
            return (var, 'HIDDEN', row.get('contents') or '')
        return (var, 'EDIT', u[0] or '')
    # sys 가 없다 — 내가 새로 쓴 것(NEW)이 있나
    var = variant_pref or ''
    row = {'text_type': text_type, 'clicked_id': clicked_id,
           'lang_code': lang, 'text_variant': var}
    if isinstance(ad, overlay.LensTextOverlay):
        row['unit_name'] = ad._unit_name(conn, clicked_id)
    elif isinstance(ad, overlay.EntityTextOverlay):
        row['entity_code'] = ad._code(conn, clicked_id)
    key = ad.key_of(row)
    w, p = ad.user_key_where(key)
    u = conn.execute('SELECT contents, record_status FROM %s WHERE %s'
                     % (ad.USER_TBL, w), p).fetchone()
    if u is not None and u[1] != 'HIDE':
        return (var, 'NEW', u[0] or '')
    return (var, 'NONE', '')


def pair_state(conn, text_type, clicked_id, lang, variant_pref):
    """비교용 — (실제 변형, 상태, sys 원본 글, 내 버전 글).

    「사용자 수정본과 sys 원본을 **비교한 후에** 되돌릴지 판단해야 한다」
    (2026-08-26 사용자) — 되돌리기 전 비교 화면이 이것을 읽는다."""
    lang = (lang or 'KO').upper()
    ad = _adapter(text_type)
    rows = ad.sys_rows(conn, clicked_id)
    cand = [r for r in rows if (r.get('lang_code') or '').upper() == lang
            and (r.get('text_variant') or '') in (variant_pref or '', '')]
    cand.sort(key=lambda r: 0 if (r.get('text_variant') or '') ==
              (variant_pref or '') else 1)
    sys_text = (cand[0].get('contents') or '') if cand else ''
    var, state, shown = target_state(conn, text_type, clicked_id, lang,
                                     variant_pref)
    mine = shown if state in ('EDIT', 'NEW') else ''
    return (var, state, sys_text, mine)


def _row_for(conn, text_type, clicked_id, lang, variant):
    ad = _adapter(text_type)
    row = {'text_type': text_type, 'clicked_id': clicked_id,
           'lang_code': (lang or 'KO').upper(),
           'text_variant': variant or None}
    # ⚠⚠ **자연 열쇠를 쓰는 어댑터는 여기서 그 값을 채워야 한다.**
    #   안 채우면 `key_of` 가 `None` 을 읽어 `PERI_DESC|None|KO|` 같은
    #   **못 쓰는 열쇠**가 저장된다 — 오류도 안 나고, 다음에 그 글을 못 찾는다.
    #   실제로 났다(2026-08-29 `PeriTextOverlay` 를 새로 달고 여기를 빠뜨렸다).
    #   ⇒ 아래 selftest 가 **모든 자연 열쇠 어댑터**를 훑어 잰다.
    if isinstance(ad, overlay.LensTextOverlay):
        row['unit_name'] = ad._unit_name(conn, clicked_id)
    elif isinstance(ad, overlay.EntityTextOverlay):
        row['entity_code'] = ad._code(conn, clicked_id)   # 열쇠는 code 다
    elif isinstance(ad, overlay.PeriTextOverlay):
        row['peri_code'] = ad._code(conn, clicked_id)     # 열쇠는 peri_code
    return ad, row


def save_mine(conn, text_type, clicked_id, lang, variant, contents):
    ad, row = _row_for(conn, text_type, clicked_id, lang, variant)
    row['contents'] = contents
    row['title'] = None
    row['target_id'] = None
    return overlay.save(conn, ad, row)


def hide_sys(conn, text_type, clicked_id, lang, variant):
    ad, row = _row_for(conn, text_type, clicked_id, lang, variant)
    overlay.hide(conn, ad, row)


def revert_mine(conn, text_type, clicked_id, lang, variant):
    ad, row = _row_for(conn, text_type, clicked_id, lang, variant)
    overlay.revert(conn, ad, row)


# ══════════════════════════════════════════════════════════════════
#  옛 호출부의 다리 — 총괄 창으로 (호출부 셋: P2 설명 탭 · NodePanel ·
#  렌즈 상세 헤더. 서명을 지켜 호출부는 한 줄도 안 고친다)
# ══════════════════════════════════════════════════════════════════
def open_editor(parent, db_path, anchor_type, anchor_id, lang,
                mode=None, on_saved=None):
    """anchor_type: 'BIBLE'(vid) → 설명문 탭 · 'NODE'/'CONTAINER' → 렌즈 탭."""
    # ★★ 3단계 — **패키지 주방 한 문으로** (2026-08-28). 이 함수는 옛
    #   호출부 셋(P2 설명 탭·NodePanel·렌즈 상세)의 다리로 남고, 실제로
    #   여는 것은 `my_edit.open` 하나다 — 어디서 눌러도 같은 화면이 뜬다.
    import my_edit
    atype = 'CONTAINER' if anchor_type in ('CONT', 'CONTAINER') else anchor_type
    KIND = {'BIBLE': 'VERSE', 'VERSE': 'VERSE',
            'CONTAINER': 'LENS', 'NODE': 'NODE',
            'ENTITY': 'ENTITY', 'USER_REF': 'USER_REF'}
    kind = KIND.get(atype)
    if not kind:
        return None
    win = my_edit.open(parent, kind, int(anchor_id),
                       on_changed=(lambda _k=None: on_saved()
                                   if callable(on_saved) else None))
    # 「내 설명」에서 왔으면 **글 조리대**를 보여 준다(그 단추의 뜻이다)
    try:
        win.nb.select(win._decks['TEXT'])
    except Exception:
        pass
    return win


# ══════════════════════════════════════════════════════════════════
#  자가 검증 — 데이터 층
# ══════════════════════════════════════════════════════════════════
def selftest():
    import sqlite3
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    db = sqlite3.connect(':memory:')
    db.execute('ATTACH DATABASE ":memory:" AS userdb')
    db.execute('CREATE TABLE sys_text_asset (odd_pk INTEGER PRIMARY KEY, '
               'clicked_id INT, target_id INT, text_type TEXT, title TEXT, '
               'contents TEXT, lang_code TEXT, text_variant TEXT, '
               'record_status TEXT)')
    db.execute('CREATE TABLE userdb.user_text_asset (u_pk INTEGER PRIMARY KEY,'
               ' clicked_id INT, target_id INT, text_type TEXT, title TEXT, '
               'contents TEXT, lang_code TEXT, text_variant TEXT, '
               'record_status TEXT)')
    db.execute('CREATE TABLE sys_unit_asset (sys_unit_id INTEGER PRIMARY KEY, '
               'unit_type TEXT, unit_name_sid TEXT, record_status TEXT)')
    db.execute('CREATE TABLE sys_entity_master (entity_id INTEGER PRIMARY KEY,'
               ' entity_code TEXT, record_status TEXT)')
    db.execute('CREATE TABLE sys_pericope_asset (pericope_id INTEGER PRIMARY '
               'KEY, peri_code TEXT, record_status TEXT)')
    db.execute("INSERT INTO sys_entity_master VALUES (318,'P_DAVID','LIVE')")
    db.execute("INSERT INTO sys_pericope_asset VALUES "
               "(5214,'GEN_01_BODY_1','LIVE')")
    overlay.ensure_schema(db)

    # ★★★ **자연 열쇠 어댑터는 `_row_for` 가 그 값을 채워야 한다** (2026-08-29).
    #   안 채우면 `PERI_DESC|None|KO|` 같은 **못 쓰는 열쇠**가 저장되고,
    #   오류 없이 그 글을 다음에 못 찾는다. 실제로 그렇게 났다.
    #   ⚠ 어댑터를 늘릴 때 여기에 한 줄 더한다 — 안 그러면 조용히 새는 것을
    #     화면에서야 안다.
    _NAT = ((overlay.LENS_TEXT_TYPES[0], 1, 'unit_name'),
            (overlay.ENTITY_TEXT_TYPES[0], 318, 'entity_code'),
            (overlay.PERI_TEXT_TYPES[0], 5214, 'peri_code'))
    db.execute("INSERT INTO sys_unit_asset VALUES (1,'NODE','빛','LIVE')")
    for _tt, _cid, _kf in _NAT:
        _ad, _row = _row_for(db, _tt, _cid, 'KO', None)
        t('★★ %s 는 자연 열쇠(%s)를 채운다' % (_tt, _kf),
          _row.get(_kf) not in (None, ''), _row)
        _k = _ad.key_of(_row)
        t('   그 열쇠에 None 이 안 들어간다', 'None' not in str(_k[1]), _k)

    # ⚠ 레거시(NULL 변형) 행 — LAY 로 물어도 열쇠는 '' 이어야 한다
    db.execute("INSERT INTO sys_text_asset (clicked_id, text_type, contents, "
               "lang_code, text_variant, record_status) VALUES "
               "(71, 'VERS_DESC', '레거시 설명', 'KO', NULL, 'LIVE')")
    db.commit()

    var, st, txt = target_state(db, 'VERS_DESC', 71, 'KO', 'LAY')
    t('★ 레거시 행이면 실제 변형은 빈 값', (var, st, txt) ==
      ('', 'SYS', '레거시 설명'), (var, st))

    st2 = save_mine(db, 'VERS_DESC', 71, 'KO', var, '내가 고친 글')
    t('★ 저장 = EDIT (레거시 열쇠로)', st2 == 'EDIT', st2)
    var, st, txt = target_state(db, 'VERS_DESC', 71, 'KO', 'LAY')
    t('   상태·글 반영', (st, txt) == ('EDIT', '내가 고친 글'), (st, txt))

    # ★ 비교 — sys 원본과 내 버전을 나란히 (되돌리기 전 판단 재료)
    var, st, sys_t, mine = pair_state(db, 'VERS_DESC', 71, 'KO', 'LAY')
    t('★ pair_state — 원본·내 버전 나란히',
      (st, sys_t, mine) == ('EDIT', '레거시 설명', '내가 고친 글'),
      (sys_t, mine))

    revert_mine(db, 'VERS_DESC', 71, 'KO', var)
    var, st, txt = target_state(db, 'VERS_DESC', 71, 'KO', 'LAY')
    t('★ 되돌리면 기본', (st, txt) == ('SYS', '레거시 설명'), st)

    hide_sys(db, 'VERS_DESC', 71, 'KO', var)
    var, st, txt = target_state(db, 'VERS_DESC', 71, 'KO', 'LAY')
    t('★ 가리면 HIDDEN(기본 글은 보여 준다)', st == 'HIDDEN' and
      txt == '레거시 설명', st)
    var, st, sys_t, mine = pair_state(db, 'VERS_DESC', 71, 'KO', 'LAY')
    t('   pair_state — 가림이면 내 글은 빈 값',
      (st, sys_t, mine) == ('HIDDEN', '레거시 설명', ''), (st, mine))
    revert_mine(db, 'VERS_DESC', 71, 'KO', var)

    # sys 없는 자리에 새로 쓰기 = NEW
    st2 = save_mine(db, 'VERS_QUESTION', 71, 'KO', 'LAY', '내 질문')
    t('★ sys 없는 자리 = NEW', st2 == 'NEW', st2)
    var, st, txt = target_state(db, 'VERS_QUESTION', 71, 'KO', 'LAY')
    t('   NEW 상태·글', (st, txt) == ('NEW', '내 질문'), st)

    # 렌즈 노드 — 이름 열쇠
    db.execute("INSERT INTO sys_unit_asset VALUES (5, 'NODE', '빛', 'LIVE')")
    db.execute("INSERT INTO sys_text_asset (clicked_id, text_type, contents, "
               "lang_code, record_status) VALUES "
               "(5, 'NODE_DESC', '기본 노드 설명', 'KO', 'LIVE')")
    db.commit()
    st2 = save_mine(db, 'NODE_DESC', 5, 'KO', '', '내 노드 설명')
    t('★ 렌즈 노드 저장 = EDIT', st2 == 'EDIT', st2)
    ok_key = db.execute("SELECT origin_key FROM userdb.user_text_asset "
                        "WHERE text_type='NODE_DESC'").fetchone()[0]
    t('★ 렌즈 열쇠는 이름', ok_key.split('|')[1] == '빛', ok_key)

    db.close()
    print('overlay_edit selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)
