# -*- coding: utf-8 -*-
"""db_strong_import.py — 낱말 마스터 표(sys_lemma_master) 구축 (영구).

2026-09-02 사용자 확정 (178차): 「스트롱 번호를 기본적으로 수용 …
구조적 변경이 필요하다면 이러한 변경작업을 먼저 해야 한다」.

구조 판정:
  · **전환이 아니라 수용** — 스트롱은 낱말 축만 다루므로 앱의 마스터 키가
    될 수 없다(인물·교리·의미장·태그에는 번호가 없다). 낱말 층의 신원만
    스트롱 번호로 바로잡는다.
  · **낱말 마스터 = strong 이 PK** — 지금까지 낱말의 신원이 엔티티에 종속
    (sys_entity_lemma 의 합성 lemma_id, 재적재 때 불안정 §171차, G3084
    중복 보유)이던 것을 고친다. sys_entity_lemma 는 마스터를 참조하는
    큐레이션 층(KO 음역·뜻·엔티티 소속)으로 남는다 — 파괴 없는 더하기.

원자료 (2026-09-02 수령·검증 — _lexicon_raw/, 규칙 ③ 파일 자기 선언 확인):
  · sg.xml  스트롱 헬라 사전 1890 — 머리에 Public Domain 명기
  · sh.xml  스트롱 히브리 사전 (OpenScriptures HebrewLexicon) — 원문 PD,
    파일 형식 CC BY 4.0 (표기: Open Scriptures Hebrew Bible Project —
    배포 시 license_info 에 한 줄. §18-10 OSHB 와 같은 표기 대상)
  · 출현 수 = wlc_verify.db / gnt_verify.db 실측

유형 분류(wtype) — 0.txt 1번 「유형별로 정리 · 필요한 것만 채택 ·
조사나 접속사 제외」:
  · GENERAL  일반 낱말(명사·동사·형용사·부사) — 채택(LIVE)
  · PROPER   고유명사 — 채택(LIVE)하되 용어 승격 대상이 아니라 기존
             인물·장소 엔티티와 연결될 층
  · FUNCTION 기능어(관사·접속사·전치사·대명사·불변화사) — **제외(HIDE)**
             행은 남긴다(지우면 분류 근거가 사라진다) — 노출층이 거른다.

사용:
  python db_strong_import.py --selftest   (의무)
  python db_strong_import.py --load       (멱등 — 전체 재유도)
  python db_strong_import.py --status
  python db_strong_import.py --audit      (entity_lemma ↔ master 대조)
"""
import io
import os
import re
import sys
import sqlite3
import xml.etree.ElementTree as ET
from collections import Counter

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

RAW = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_lexicon_raw')
NS = '{http://openscriptures.github.com/morphhb/namespace}'
# 히브리 기능어 품사 (실측 분포 — prep·conj·prt·pron·지시/관계/의문 계열)
HE_FUNC = {'prep', 'conj', 'prt', 'pron', 'd', 'dp', 'x', 'p', 'r', 'i'}
# 헬라 기능어 = 신약 출현 700회 이상(관사·접속사·전치사 급 — 실측 25개)
EL_FUNC_FREQ = 700

DDL = """CREATE TABLE IF NOT EXISTS sys_lemma_master(
  strong TEXT PRIMARY KEY,
  lang_code TEXT NOT NULL,
  form TEXT,
  translit TEXT,
  pron TEXT,
  pos TEXT,
  wtype TEXT NOT NULL,
  gloss TEXT,
  deriv TEXT,
  def_en TEXT,
  kjv_def TEXT,
  occurrences INTEGER DEFAULT 0,
  record_status TEXT DEFAULT 'LIVE')"""


def _txt(el):
    if el is None:
        return ''
    return re.sub(r'\s+', ' ', ''.join(el.itertext())).strip()


def _freq(db, table):
    p = os.path.join(os.path.dirname(RAW), db)
    if not os.path.exists(p):
        return Counter()
    d = sqlite3.connect(p)
    f = Counter()
    for (s,) in d.execute('SELECT strongs FROM %s' % table):
        for c in (s or '').split():
            f[c] += 1
    d.close()
    return f


def parse_hebrew(path=None, freq=None):
    """sh.xml → 행 목록. pos 속성이 있어 분류가 정확하다."""
    tree = ET.parse(path or os.path.join(RAW, 'sh.xml'))
    rows = []
    for e in tree.getroot().iter(NS + 'entry'):
        st = e.get('id')
        w = e.find(NS + 'w')
        pos = (w.get('pos') or '') if w is not None else ''
        base = pos.split('-')[0] if pos else ''
        if pos.startswith('n-pr'):
            wt = 'PROPER'
        elif base in ('n', 'v', 'a') or pos in ('adv', 'inj'):
            wt = 'GENERAL'
        elif base in HE_FUNC or pos in HE_FUNC:
            wt = 'FUNCTION'
        else:
            wt = 'GENERAL'
        rows.append({
            'strong': st, 'lang': 'HE',
            'form': (w.text or '').strip() if w is not None else '',
            'translit': (w.get('xlit') or '') if w is not None else '',
            'pron': (w.get('pron') or '') if w is not None else '',
            'pos': pos, 'wtype': wt,
            'gloss': _txt(e.find(NS + 'meaning')),
            'deriv': _txt(e.find(NS + 'source')),
            'def_en': _txt(e.find(NS + 'meaning')),
            'kjv': _txt(e.find(NS + 'usage')),
            'occ': (freq or {}).get(st, 0)})
    return rows


def parse_greek(path=None, freq=None):
    """sg.xml → 행 목록. pos 가 없어 대문자(고유)·빈도(기능어)로 가른다."""
    tree = ET.parse(path or os.path.join(RAW, 'sg.xml'))
    rows = []
    freq = freq or {}
    for e in tree.getroot().iter('entry'):
        try:
            st = 'G' + str(int(e.get('strongs')))
        except (TypeError, ValueError):
            continue
        gk = e.find('greek')
        uni = (gk.get('unicode') or '') if gk is not None else ''
        occ = freq.get(st, 0)
        if uni and uni[0].isupper():
            wt = 'PROPER'
        elif occ >= EL_FUNC_FREQ:
            wt = 'FUNCTION'
        else:
            wt = 'GENERAL'
        rows.append({
            'strong': st, 'lang': 'EL', 'form': uni,
            'translit': (gk.get('translit') or '') if gk is not None else '',
            'pron': '', 'pos': '', 'wtype': wt,
            'gloss': _txt(e.find('strongs_def'))[:400],
            'deriv': _txt(e.find('strongs_derivation')),
            'def_en': _txt(e.find('strongs_def')),
            'kjv': _txt(e.find('kjv_def')),
            'occ': occ})
    return rows


def load(conn, he_rows=None, el_rows=None):
    """멱등 — 원본에서 전체 재유도(§174차 원본 재유도가 멱등의 정본)."""
    if he_rows is None:
        he_rows = parse_hebrew(freq=_freq('wlc_verify.db', 'wlc_verse'))
    if el_rows is None:
        el_rows = parse_greek(freq=_freq('gnt_verify.db', 'gnt_verse'))
    conn.execute(DDL)
    conn.execute('DELETE FROM sys_lemma_master')
    for r in he_rows + el_rows:
        conn.execute(
            'INSERT OR REPLACE INTO sys_lemma_master(strong,lang_code,form,'
            'translit,pron,pos,wtype,gloss,deriv,def_en,kjv_def,occurrences,'
            'record_status) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
            (r['strong'], r['lang'], r['form'], r['translit'], r['pron'],
             r['pos'], r['wtype'], r['gloss'], r['deriv'], r['def_en'],
             r['kjv'], r['occ'],
             'HIDE' if r['wtype'] == 'FUNCTION' else 'LIVE'))
    conn.commit()
    c = Counter(r['wtype'] for r in he_rows + el_rows)
    print('적재 %d행 (HE %d · EL %d) · GENERAL %d · PROPER %d · FUNCTION %d(HIDE)'
          % (len(he_rows) + len(el_rows), len(he_rows), len(el_rows),
             c['GENERAL'], c['PROPER'], c['FUNCTION']))


def status(conn):
    try:
        rows = conn.execute(
            "SELECT lang_code, wtype, COUNT(*), SUM(occurrences) FROM"
            " sys_lemma_master GROUP BY lang_code, wtype").fetchall()
    except sqlite3.OperationalError:
        print('sys_lemma_master 없음 — --load 먼저')
        return
    for r in rows:
        print('  %s %-9s %5d항목 · 출현 %d' % r)


def audit(conn):
    """entity_lemma ↔ master 대조 — 큐레이션 층이 마스터에 닻을 갖는가."""
    miss, n = [], 0
    for st, tr in conn.execute(
            'SELECT DISTINCT strong, translit FROM sys_entity_lemma'):
        n += 1
        r = conn.execute('SELECT wtype, translit FROM sys_lemma_master'
                         ' WHERE strong=?', (st,)).fetchone()
        if not r:
            miss.append(st)
    print('entity_lemma 낱말 %d종 — 마스터 미보유 %d %s'
          % (n, len(miss), miss[:10]))
    # 같은 스트롱을 여러 엔티티가 참조하는 것(공유)은 정상 — 중복이 아니라
    # 가알·파다가 뤼트로오를 나누어 갖는 꼴(§156차 판정)이다.
    dup = conn.execute(
        'SELECT strong, COUNT(*) c FROM sys_entity_lemma GROUP BY strong'
        ' HAVING c>1').fetchall()
    print('여러 엔티티가 공유하는 스트롱: %s' % (dup or '없음'))
    return miss


def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    # 실 파일 파싱 — 원자료가 있어야 한다(없으면 도구가 헛돈다)
    he = parse_hebrew(freq=Counter({'H2403': 296}))
    el = parse_greek(freq=Counter({'G266': 173, 'G2532': 9498}))
    t('히브리 8,600~8,700항목', 8600 <= len(he) <= 8700, len(he))
    t('헬라 5,500~5,700항목', 5500 <= len(el) <= 5700, len(el))
    hmap = {r['strong']: r for r in he}
    gmap = {r['strong']: r for r in el}
    t('H2403(하타트) 실재·일반 낱말',
      hmap.get('H2403', {}).get('wtype') == 'GENERAL',
      hmap.get('H2403', {}).get('gloss', '')[:30])
    t('H1732(다윗) 고유명사', hmap.get('H1732', {}).get('wtype') == 'PROPER')
    t('H5921(알 · 전치사) 기능어', hmap.get('H5921', {}).get('wtype') == 'FUNCTION',
      hmap.get('H5921', {}).get('pos'))
    t('G266(하마르티아) 일반 낱말', gmap.get('G266', {}).get('wtype') == 'GENERAL')
    t('G2532(카이) 기능어 — 빈도 분류', gmap.get('G2532', {}).get('wtype') == 'FUNCTION')
    t('G2424(예수) 고유명사 — 대문자 분류', gmap.get('G2424', {}).get('wtype') == 'PROPER')
    # 메모리 DB 적재 왕복 — 멱등
    conn = sqlite3.connect(':memory:')
    load(conn, he_rows=he[:50], el_rows=el[:50])
    c0 = conn.execute('SELECT COUNT(*) FROM sys_lemma_master').fetchone()[0]
    load(conn, he_rows=he[:50], el_rows=el[:50])
    c1 = conn.execute('SELECT COUNT(*) FROM sys_lemma_master').fetchone()[0]
    t('멱등(두 번 적재 행수 불변)', c0 == c1 == 100)
    t('기능어 = HIDE', conn.execute(
        "SELECT COUNT(*) FROM sys_lemma_master WHERE wtype='FUNCTION'"
        " AND record_status!='HIDE'").fetchone()[0] == 0)
    conn.close()
    print('db_strong_import selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect('bible_master.db')
    try:
        if '--load' in sys.argv:
            load(conn)
        elif '--audit' in sys.argv:
            audit(conn)
        else:
            status(conn)
    finally:
        conn.close()
