# -*- coding: utf-8 -*-
"""photo_pack — 시작화면·말씀카드 사진의 저장·추천·사진팩 (2026-10-11 · 영구 · --selftest 의무).

사용자 결정(2026-10-11)
  · 사진은 직접 찍은 것 · JPEG 로 줄인다 · 「Hagah Dabar」를 시작화면·카드 둘 다 오른쪽 아래에
  · 오늘 사진 = 구절 주제(장면)에 맞춰 · 사진팩 = 번호 팩(사진팩 1·2…) · 팩마다 「추가」/「교체」
  · 폰 홈 「오늘의 말씀」 = 사진 카드(자동) · 구절을 골라 공유할 때는 사진을 고른다(추천을 앞에)
  · 주제가 없으면 Claude 가 기준을 정한다 → BOOK_GROUPS

저장(sys_splash_image 에 칸을 더한다 — 표를 새로 만들지 않는다)
  png_blob  = 시작화면용 1920×1200 JPEG(옛 이름 그대로 · 옛 사진은 PNG 그대로 둔다 — 읽는 쪽이 머리 바이트로 가린다)
  jpg_card  = 말씀카드용 1080×729 JPEG(폰 카드 모양 · 2026-10-30)
  crop_json = {"splash":[cx,cy],"card":[cx,cy]} · jpeg_q = 품질 · photo_pack = 사진팩 번호(NULL = 코어/기본)
  sys_photo_original — 원본(관리자 PC 에만 · LOCAL · 배포 안 함)
  sys_photo_pack     — 사진팩 번호 · 이름 · 방식(ADD|REPLACE) · 메모 · 만든 때 · 올린 때 (LOCAL)
"""
import json
import random
import sys
from datetime import datetime

sys.path.insert(0, 'C:/Hagah/app')

MODES = (('ADD', '추가 — 받은 사진은 그대로 두고 더한다'),
         ('REPLACE', '교체 — 앞서 받은 사진팩 사진을 걷고 이 팩으로'))
#: 주제(장면)가 없는 구절 — 책의 갈래로 장면 묶음을 고른다(사용자 「네가 알아서 기준을 정하라」).
BOOK_GROUPS = ((1, 17, ('LAND', 'PLACE')),      # 율법·역사서
               (18, 22, ('SKY', 'WATER')),      # 시가서
               (23, 39, ('SKY', 'PLACE')),      # 예언서
               (40, 44, ('FARM', 'WATER')),     # 복음서·사도행전
               (45, 65, ('SKY', 'WORSHIP')),    # 서신서
               (66, 66, ('SKY',)))              # 계시록


def ensure(conn):
    def cols(t):
        return [r[1] for r in conn.execute('PRAGMA table_info(%s)' % t)]
    try:
        import db_splash_scene as SC
        SC.init(conn)
    except Exception:
        pass
    have = cols('sys_splash_image')
    for col, decl in (('jpg_card', 'BLOB'), ('crop_json', 'TEXT'), ('jpeg_q', 'INTEGER'),
                      ('photo_pack', 'INTEGER'), ('orig_w', 'INTEGER'), ('orig_h', 'INTEGER')):
        if col not in have:
            conn.execute('ALTER TABLE sys_splash_image ADD COLUMN %s %s' % (col, decl))
    conn.execute('CREATE TABLE IF NOT EXISTS sys_photo_original(img_id INTEGER PRIMARY KEY, blob BLOB, '
                 'fname TEXT, created_at TEXT)')
    conn.execute("CREATE TABLE IF NOT EXISTS sys_photo_pack(pack_no INTEGER PRIMARY KEY, title TEXT, "
                 "mode TEXT NOT NULL DEFAULT 'ADD', note TEXT, built_at TEXT, uploaded_at TEXT)")
    conn.commit()


def is_jpeg(b):
    return bool(b) and b[:3] == b'\xff\xd8\xff'


def crop_of(conn, img_id):
    r = conn.execute('SELECT crop_json FROM sys_splash_image WHERE img_id=?', (img_id,)).fetchone()
    try:
        return {k: tuple(v) for k, v in json.loads(r[0] or '{}').items()}
    except Exception:
        return {}


def add_photo(conn, src_bytes, name, fname='', crop=None, quality=None, pack_no=None):
    """원본을 받아 세 가지를 만들고 한 줄 넣는다 → img_id."""
    import photo_prep as P
    q = quality or P.JPEG_Q
    v = P.variants(src_bytes, crop, q)
    cur = conn.execute(
        "INSERT INTO sys_splash_image(png_blob, jpg_card, thumb_blob, name, width, height, attribution, license,"
        " is_active, sort_order, created_at, crop_json, jpeg_q, photo_pack, orig_w, orig_h)"
        " VALUES(?,?,?,?,?,?,?,?,1,0,?,?,?,?,?,?)",
        (v['splash'], v['card'], v['thumb'], name, P.SPLASH_SIZE[0], P.SPLASH_SIZE[1], 'Hagah Dabar', '본인 촬영',
         datetime.now().strftime('%Y-%m-%d %H:%M:%S'), json.dumps(crop or {}), q, pack_no,
         v['orig_size'][0], v['orig_size'][1]))
    iid = cur.lastrowid
    conn.execute('INSERT OR REPLACE INTO sys_photo_original VALUES(?,?,?,?)',
                 (iid, bytes(src_bytes), fname, datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
    conn.commit()
    return iid


def remake(conn, img_id, crop=None, quality=None):
    """자르는 자리·품질을 바꿔 다시 만든다(원본이 없으면 지금 시작화면 사진으로)."""
    import photo_prep as P
    r = conn.execute('SELECT blob FROM sys_photo_original WHERE img_id=?', (img_id,)).fetchone()
    src = r[0] if r and r[0] else conn.execute('SELECT png_blob FROM sys_splash_image WHERE img_id=?',
                                               (img_id,)).fetchone()[0]
    crop = crop if crop is not None else crop_of(conn, img_id)
    q = quality or conn.execute('SELECT COALESCE(jpeg_q,?) FROM sys_splash_image WHERE img_id=?',
                                (P.JPEG_Q, img_id)).fetchone()[0]
    v = P.variants(src, crop, q)
    conn.execute('UPDATE sys_splash_image SET png_blob=?, jpg_card=?, thumb_blob=?, width=?, height=?, crop_json=?,'
                 ' jpeg_q=?, orig_w=?, orig_h=? WHERE img_id=?',
                 (v['splash'], v['card'], v['thumb'], P.SPLASH_SIZE[0], P.SPLASH_SIZE[1],
                  json.dumps({k: list(x) for k, x in crop.items()}), q, v['orig_size'][0], v['orig_size'][1], img_id))
    conn.commit()
    return {'splash': len(v['splash']), 'card': len(v['card']), 'orig': v['orig_size'], 'has_orig': bool(r)}


# ── 추천 ──────────────────────────────────────────────────────────────
def _active(conn):
    return {r[0]: (r[1], r[2]) for r in conn.execute(
        "SELECT i.img_id, i.scene, COALESCE(p.pack_code,'') FROM sys_splash_image i"
        " LEFT JOIN sys_scene_pack p ON p.scene_code=i.scene WHERE COALESCE(i.is_active,1)=1")}


def book_groups(bcode):
    for a, b, g in BOOK_GROUPS:
        if a <= (bcode or 0) <= b:
            return g
    return ('SKY',)


def recommend(conn, verse_id):
    """그 구절에 어울리는 차례로 사진을 늘어놓는다 → [(img_id, 까닭)].

    차례: ① 구절의 장면(절 → 단락 → 장) ② 같은 장면 묶음 ③ 책 갈래의 기본 묶음 ④ 기본 사진 ⑤ 나머지.
    ★ PC 시작화면과 폰 카드가 같은 차례를 쓴다(폰은 mobile/lib/data/photo_repo.dart 가 이 규칙을 옮긴다).
    """
    import db_splash_scene as SC
    act = _active(conn)
    pairs, via = SC.scenes_for_verse(conn, verse_id)
    scenes = [s for s, _w in pairs]
    out, seen = [], set()

    def put(ids, why):
        for i in ids:
            if i not in seen:
                seen.add(i)
                out.append((i, why))
    put([i for i, (s, g) in act.items() if s in scenes], '구절 장면(%s)' % via if scenes else '')
    groups = {SC.SCENE_BY[s][1] for s in scenes if s in SC.SCENE_BY}
    put([i for i, (s, g) in act.items() if g in groups], '같은 장면 묶음')
    b = conn.execute('SELECT bcode FROM bible_index WHERE verse_id=?', (verse_id,)).fetchone()
    put([i for i, (s, g) in act.items() if g in book_groups(b[0] if b else 0)], '책 갈래 기본')
    put([r[0] for r in conn.execute("SELECT img_id FROM sys_splash_image WHERE COALESCE(basic,0)=1 "
                                    "AND COALESCE(is_active,1)=1")], '기본 사진')
    put(list(act), '그 밖')
    return out


def pick_today(conn, verse_id, day_seed=None):
    """오늘 보일 사진 하나 — 맨 앞 갈래 안에서 날짜로 선택한다(같은 날은 같은 사진)."""
    rec = recommend(conn, verse_id)
    if not rec:
        return None
    top = [i for i, w in rec if w == rec[0][1]]
    rnd = random.Random(day_seed if day_seed is not None else datetime.now().strftime('%Y%m%d'))
    return rnd.choice(top)


# ── 사진팩 ────────────────────────────────────────────────────────────
def packs(conn):
    return [dict(zip(('pack_no', 'title', 'mode', 'note', 'built_at', 'uploaded_at', 'n', 'kb'), r)) for r in conn.execute(
        "SELECT p.pack_no, p.title, p.mode, p.note, p.built_at, p.uploaded_at,"
        " (SELECT COUNT(*) FROM sys_splash_image i WHERE i.photo_pack=p.pack_no),"
        " (SELECT COALESCE(SUM(LENGTH(png_blob)+LENGTH(COALESCE(jpg_card,''))),0)/1024 FROM sys_splash_image i"
        "  WHERE i.photo_pack=p.pack_no) FROM sys_photo_pack p ORDER BY p.pack_no")]


def save_pack(conn, pack_no, title, mode, note=''):
    assert mode in dict(MODES), mode
    conn.execute('INSERT INTO sys_photo_pack(pack_no, title, mode, note) VALUES(?,?,?,?) '
                 'ON CONFLICT(pack_no) DO UPDATE SET title=excluded.title, mode=excluded.mode, note=excluded.note',
                 (pack_no, title, mode, note))
    conn.commit()


def mode_of(conn, pack_no):
    r = conn.execute('SELECT mode FROM sys_photo_pack WHERE pack_no=?', (pack_no,)).fetchone()
    return (r[0] if r else 'ADD') or 'ADD'


def replace_wipe(conn, keep_pack):
    """「교체」 팩을 받을 때 — 앞서 받은 다른 사진팩의 사진과 그 글을 걷는다(사용자 사진·기본 사진은 그대로)."""
    ids = [r[0] for r in conn.execute('SELECT img_id FROM sys_splash_image WHERE photo_pack IS NOT NULL '
                                      'AND photo_pack<>?', (keep_pack,))]
    if ids:
        q = ','.join('?' * len(ids))
        conn.execute("DELETE FROM sys_text_asset WHERE text_type IN ('SPLASH_TITLE','SPLASH_DESC') "
                     "AND clicked_id IN (%s)" % q, ids)
        conn.execute('DELETE FROM sys_splash_image WHERE img_id IN (%s)' % q, ids)
    return len(ids)


def audit(conn):
    """점검 — 사람이 볼 것을 줄로."""
    out = []
    for iid, name, scene, attr, ow, pk, card, png, act in conn.execute(
            "SELECT img_id, COALESCE(name,''), scene, attribution, orig_w, photo_pack, jpg_card IS NOT NULL,"
            " png_blob, COALESCE(is_active,1) FROM sys_splash_image"):
        if not act:
            continue
        if not scene:
            out.append((iid, name, '장면이 없다 — 구절과 이어지지 않는다'))
        if not card:
            out.append((iid, name, '말씀카드용 사진이 없다 — [다시 만들기]'))
        if not is_jpeg(png):
            out.append((iid, name, '시작화면 사진이 옛 PNG(960×600)다 — 원본으로 다시 넣으면 선명해진다'))
        elif (ow or 0) and ow < 1920:
            out.append((iid, name, '원본이 작다(가로 %d) — 시작화면이 흐릴 수 있다' % ow))
        if not (attr or '').strip():
            out.append((iid, name, '출처가 비었다'))
        if png and len(png) > 700 * 1024:
            out.append((iid, name, '시작화면 사진이 크다(%dKB)' % (len(png) // 1024)))
    n_basic = conn.execute("SELECT COUNT(*) FROM sys_splash_image WHERE COALESCE(basic,0)=1 AND "
                           "COALESCE(is_active,1)=1 AND photo_pack IS NULL").fetchone()[0]
    if not n_basic:
        out.append((None, '', '기본 사진이 한 장도 없다 — 팩을 안 받은 사용자에게 사진이 없다'))
    for p in packs(conn):
        if not p['n']:
            out.append((None, '사진팩 %d' % p['pack_no'], '사진이 없다'))
    return out


def selftest():
    import sqlite3
    import io
    from PIL import Image
    ok = []

    def t(n, c):
        ok.append(bool(c))
        print(('PASS ' if c else 'FAIL ') + n)
    c = sqlite3.connect(':memory:')
    c.execute('CREATE TABLE sys_splash_image(img_id INTEGER PRIMARY KEY AUTOINCREMENT, png_blob BLOB NOT NULL, name TEXT,'
              ' width INTEGER, height INTEGER, attribution TEXT, license TEXT, is_active INTEGER DEFAULT 1,'
              ' sort_order INTEGER DEFAULT 0, created_at TEXT, style TEXT, scene TEXT, basic INTEGER, thumb_blob BLOB,'
              ' continent TEXT, country TEXT)')
    c.execute('CREATE TABLE sys_text_asset(sys_text_id INTEGER PRIMARY KEY, clicked_id INTEGER, text_type TEXT,'
              ' contents TEXT, lang_code TEXT, record_status TEXT, title TEXT)')
    c.execute('CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY, bcode INTEGER, chapter INTEGER, verse INTEGER)')
    c.executemany('INSERT INTO bible_index VALUES(?,?,?,?)', [(1, 1, 1, 1), (2, 19, 23, 1), (3, 40, 5, 1)])
    ensure(c)
    buf = io.BytesIO()
    Image.new('RGB', (3000, 2000), (30, 120, 60)).save(buf, 'JPEG')
    a = add_photo(c, buf.getvalue(), 'River', crop={'card': (0.3, 0.5)})
    b = add_photo(c, buf.getvalue(), 'Mountain')
    d = add_photo(c, buf.getvalue(), 'Night', pack_no=2)
    c.execute("UPDATE sys_splash_image SET scene='RIVER' WHERE img_id=?", (a,))
    c.execute("UPDATE sys_splash_image SET scene='RIDGE', basic=1 WHERE img_id=?", (b,))
    c.execute("UPDATE sys_splash_image SET scene='NIGHT_SKY' WHERE img_id=?", (d,))
    t('시작화면 사진이 JPEG', is_jpeg(c.execute('SELECT png_blob FROM sys_splash_image WHERE img_id=?', (a,)).fetchone()[0]))
    t('카드 사진이 있다', c.execute('SELECT jpg_card IS NOT NULL FROM sys_splash_image WHERE img_id=?', (a,)).fetchone()[0])
    t('원본은 따로', c.execute('SELECT COUNT(*) FROM sys_photo_original').fetchone()[0] == 3)
    t('자르는 자리를 기억', crop_of(c, a).get('card') == (0.3, 0.5))
    r = remake(c, a, {'card': (0.7, 0.5)}, 70)
    t('다시 만들기 — 원본에서', r['has_orig'] and crop_of(c, a)['card'] == (0.7, 0.5))
    import db_splash_scene as SC
    SC.set_map(c, 'RIVER', 'VERSE', 1)
    rec = recommend(c, 1)
    t('구절 장면 사진이 맨 앞', rec[0][0] == a and rec[0][1].startswith('구절 장면'))
    t('모든 사진이 줄에 있다', {i for i, _ in rec} == {a, b, d})
    rec2 = recommend(c, 2)                         # 장면 없음 · 시가서 → 하늘·물
    t('주제 없으면 책 갈래(시가서 → 하늘·물)', rec2[0][1] == '책 갈래 기본' and rec2[0][0] in (a, d))
    t('같은 날은 같은 사진', pick_today(c, 2, 20261011) == pick_today(c, 2, 20261011))
    save_pack(c, 2, '사진팩 2', 'REPLACE')
    t('팩 방식', mode_of(c, 2) == 'REPLACE' and mode_of(c, 9) == 'ADD')
    e = add_photo(c, buf.getvalue(), 'Old', pack_no=1)
    n = replace_wipe(c, keep_pack=2)
    t('교체 — 다른 팩 사진만 걷는다(기본·이 팩은 그대로)', n == 1 and c.execute(
        'SELECT COUNT(*) FROM sys_splash_image WHERE img_id IN (?,?,?)', (a, b, d)).fetchone()[0] == 3)
    t('점검이 돈다', isinstance(audit(c), list))
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    if '--ensure' in sys.argv:
        import appdb
        cc = appdb.connect('bible_master.db')
        ensure(cc)
        print('ok')
