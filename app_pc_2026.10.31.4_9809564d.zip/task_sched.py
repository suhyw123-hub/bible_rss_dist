# -*- coding: utf-8 -*-
"""Windows 작업 스케줄러 등록 — **요일 여러 개 + 시각**, 노트북에서도 도는 설정
(2026-09-16 신설·영구 · 1.txt 15·16번).

왜 새로 지었나 — 실측(2026-09-16)
    옛 등록은 `schtasks /create /sc daily /st HH:MM` 한 줄이었다. 그 기본값이
    노트북에서 셋이나 걸렸다:
      · DisallowStartIfOnBatteries=true  — 배터리면 **시작하지 않는다**
      · StopIfGoingOnBatteries=true      — 도는 중에 전원을 뽑으면 **죽인다**
      · StartWhenAvailable 없음          — 그 시각에 꺼져 있었으면 **안 돈다**
    9월 15일 12:00 작업은 시작했지만 완료 기록이 없고(827채널 표식만), 9월 16일은
    12:00 에 안 돌고 13:28 시도가 0x800710E0(거부됨)로 끝났다. 사용자
    「10시에 노트북을 켰는데 12시에 작동하지 않았다」가 이 자리다.
    ⚠ `schtasks` 명령줄로는 이 셋을 못 바꾼다 — **XML 로 등록**해야 한다.
    ⚠ 요일 복수 선택(월·수·금)도 명령줄로는 `/d MON,WED,FRI` 가 되지만 위 셋과
      함께 두려면 어차피 XML 이다. 한 길로 간다.

무엇을 하나
    build_xml(...)      등록 XML 을 만든다(순수 함수 — selftest 가 잰다)
    register(name, xml) `schtasks /create /xml` — 있으면 덮어쓴다(/f)
    read(name)          등록된 것을 XML 로 되읽는다 → dict (없으면 None)
    info(name)          마지막 실행 시각·결과·다음 실행 — PowerShell 로 언어 무관하게
    unregister(name)
    explain(code)       결과 코드를 사람 말로

⚠ `schtasks` 출력은 콘솔 코드페이지(CP949)다 — 바이트로 받아 차례로 푼다
  (admin/panel_media_channel 이 2026-09-04 에 당한 자리).
⚠ 이 모듈은 tkinter 를 모른다 — 화면(관리자 자동실행 탭)이 부른다.
"""
from __future__ import annotations
import os
import re
import subprocess
import sys
import tempfile

DAYS = ('MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN')
DAY_TAG = {'MON': 'Monday', 'TUE': 'Tuesday', 'WED': 'Wednesday',
           'THU': 'Thursday', 'FRI': 'Friday', 'SAT': 'Saturday', 'SUN': 'Sunday'}
DAY_KO = {'MON': '월', 'TUE': '화', 'WED': '수', 'THU': '목', 'FRI': '금',
          'SAT': '토', 'SUN': '일'}
_OEM = 'oem' if sys.platform == 'win32' else 'utf-8'

#: 결과 코드 → 사람 말 (Task Scheduler 가 자주 내는 것만)
RESULTS = {
    0: '정상 종료',
    1: '오류로 종료(스크립트가 1 을 돌려줌 — 로그를 볼 것)',
    0x41300: '아직 실행 대기(준비됨)',
    0x41301: '지금 실행 중',
    0x41303: '아직 한 번도 실행되지 않음',
    0x41306: '사용자가 중지함',
    0x800710E0: '거부됨 — 시작 조건이 안 맞음(배터리 전원·로그인 안 됨·전원 정책). '
                '이 앱이 등록하는 작업은 배터리에서도 돌도록 고쳐 두었다',
    0x8007010B: '작업 폴더를 찾을 수 없음',
    0x80070002: '실행 파일(파이썬 또는 스크립트)을 찾을 수 없음',
}


def explain(code) -> str:
    try:
        c = int(code)
    except Exception:
        return str(code)
    if c < 0:
        c &= 0xFFFFFFFF
    return RESULTS.get(c, '코드 0x%08X' % c)


def build_xml(command: str, args: str, hh: int, mm: int, days=None,
              start_when_available=True, battery_ok=True,
              exec_limit='PT3H', description='') -> str:
    """등록 XML. `days` — DAYS 의 부분집합(전부/None 이면 매일)."""
    hh, mm = int(hh), int(mm)
    assert 0 <= hh <= 23 and 0 <= mm <= 59, (hh, mm)
    sel = [d for d in DAYS if not days or d in set(days)]
    if len(sel) == 7:
        sched = ('      <ScheduleByDay>\n'
                 '        <DaysInterval>1</DaysInterval>\n'
                 '      </ScheduleByDay>\n')
    else:
        tags = ''.join('          <%s />\n' % DAY_TAG[d] for d in sel)
        sched = ('      <ScheduleByWeek>\n'
                 '        <DaysOfWeek>\n%s        </DaysOfWeek>\n'
                 '        <WeeksInterval>1</WeeksInterval>\n'
                 '      </ScheduleByWeek>\n' % tags)
    b = 'false' if battery_ok else 'true'
    swa = 'true' if start_when_available else 'false'

    def _x(s):
        return (s or '').replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    return (
        '<?xml version="1.0" encoding="UTF-16"?>\n'
        '<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">\n'
        '  <RegistrationInfo>\n'
        '    <Description>%s</Description>\n'
        '  </RegistrationInfo>\n'
        '  <Triggers>\n'
        '    <CalendarTrigger>\n'
        '      <StartBoundary>2026-01-01T%02d:%02d:00</StartBoundary>\n'
        '      <Enabled>true</Enabled>\n'
        '%s'
        '    </CalendarTrigger>\n'
        '  </Triggers>\n'
        '  <Principals>\n'
        '    <Principal id="Author">\n'
        '      <LogonType>InteractiveToken</LogonType>\n'
        '      <RunLevel>LeastPrivilege</RunLevel>\n'
        '    </Principal>\n'
        '  </Principals>\n'
        '  <Settings>\n'
        '    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>\n'
        '    <DisallowStartIfOnBatteries>%s</DisallowStartIfOnBatteries>\n'
        '    <StopIfGoingOnBatteries>%s</StopIfGoingOnBatteries>\n'
        '    <AllowHardTerminate>true</AllowHardTerminate>\n'
        '    <StartWhenAvailable>%s</StartWhenAvailable>\n'
        '    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>\n'
        '    <IdleSettings>\n'
        '      <StopOnIdleEnd>false</StopOnIdleEnd>\n'
        '      <RestartOnIdle>false</RestartOnIdle>\n'
        '    </IdleSettings>\n'
        '    <AllowStartOnDemand>true</AllowStartOnDemand>\n'
        '    <Enabled>true</Enabled>\n'
        '    <Hidden>false</Hidden>\n'
        '    <RunOnlyIfIdle>false</RunOnlyIfIdle>\n'
        '    <WakeToRun>false</WakeToRun>\n'
        '    <ExecutionTimeLimit>%s</ExecutionTimeLimit>\n'
        '    <Priority>7</Priority>\n'
        '  </Settings>\n'
        '  <Actions Context="Author">\n'
        '    <Exec>\n'
        '      <Command>%s</Command>\n'
        '      <Arguments>%s</Arguments>\n'
        '    </Exec>\n'
        '  </Actions>\n'
        '</Task>\n'
    ) % (_x(description), hh, mm, sched, b, b, swa, exec_limit,
         _x(command), _x(args))


def parse_xml(xml: str) -> dict:
    """등록 XML → {'hh','mm','days','command','args','battery_ok','start_when_available'}."""
    m = re.search(r'<StartBoundary>\s*\S*?T(\d{2}):(\d{2})', xml)
    hh, mm = (int(m.group(1)), int(m.group(2))) if m else (0, 0)
    if 'ScheduleByWeek' in xml:
        days = [d for d in DAYS if re.search(r'<%s\s*/?>' % DAY_TAG[d], xml)]
    else:
        days = list(DAYS)

    def _tag(name, default=''):
        r = re.search(r'<%s>([^<]*)</%s>' % (name, name), xml)
        return (r.group(1) if r else default).strip()

    def _un(s):
        return s.replace('&lt;', '<').replace('&gt;', '>').replace('&amp;', '&')
    return {
        'hh': hh, 'mm': mm, 'days': days,
        'command': _un(_tag('Command')), 'args': _un(_tag('Arguments')),
        'battery_ok': _tag('DisallowStartIfOnBatteries', 'true').lower() != 'true',
        'start_when_available': _tag('StartWhenAvailable', 'false').lower() == 'true',
    }


def days_label(days) -> str:
    days = list(days or [])
    if len(days) >= 7 or not days:
        return '매일'
    return '매주 ' + '·'.join(DAY_KO[d] for d in DAYS if d in days)


def _run(cmd, timeout=15, xml=False):
    """명령을 돌리고 (코드, 글) — 글은 **바이트로 받아 차례로 푼다**.
    ⚠ 메시지(CP949)는 utf-8 → OEM 차례다. utf-16 을 앞에 두면 CP949 바이트가
      「성공」으로 풀려 깨진 글자가 나온다(실측 등록 메시지가 그랬다). XML 은
      `<Task` 가 들어 있는 풀이만 맞다고 본다."""
    r = subprocess.run(cmd, capture_output=True, timeout=timeout)
    out = b''
    for chunk in (r.stdout or b'', r.stderr or b''):
        out += chunk
    txt = ''
    order = ('utf-8', 'utf-16', _OEM) if xml else ('utf-8', _OEM, 'utf-16')
    for enc in order:
        try:
            t = out.decode(enc)
        except Exception:
            continue
        if xml and '<Task' not in t:
            continue
        txt = t
        break
    return r.returncode, txt


def read(name: str):
    """등록된 작업 → parse_xml 결과, 없으면 None."""
    try:
        code, txt = _run(['schtasks', '/query', '/tn', name, '/xml'], xml=True)
    except Exception:
        return None
    if code != 0 or '<Task' not in txt:
        return None
    return parse_xml(txt)


def register(name: str, xml: str):
    """`schtasks /create /xml` → (ok, 메시지). 있으면 덮어쓴다."""
    fd, path = tempfile.mkstemp(suffix='.xml')
    os.close(fd)
    try:
        with open(path, 'w', encoding='utf-16') as f:
            f.write(xml)
        code, txt = _run(['schtasks', '/create', '/tn', name, '/xml', path, '/f'], timeout=20)
        return code == 0, txt.strip()
    finally:
        try:
            os.remove(path)
        except Exception:
            pass


def unregister(name: str):
    code, txt = _run(['schtasks', '/delete', '/tn', name, '/f'])
    return code == 0, txt.strip()


def set_enabled(name: str, on: bool):
    """작업을 켜고 끈다(`schtasks /change /enable|/disable`) → (ok, 메시지). 등록이 없으면 (False, …).
    (2026-09-16 `gcloud_gate` — API 뿐인 작업을 지우지 않고 끈다. 재개하면 그대로 켠다.)"""
    try:
        code, txt = _run(['schtasks', '/change', '/tn', name, '/enable' if on else '/disable'], timeout=20)
        return code == 0, txt.strip()[:120]
    except Exception as e:
        return False, str(e)[:120]


def info(name: str):
    """마지막 실행 시각 · 결과 코드 · 다음 실행 — PowerShell(언어 무관) → dict|None."""
    ps = ("$i=Get-ScheduledTaskInfo -TaskName '%s' -ErrorAction Stop; "
          "'{0}|{1}|{2}' -f $i.LastRunTime.ToString('yyyy-MM-dd HH:mm'), "
          "$i.LastTaskResult, $i.NextRunTime.ToString('yyyy-MM-dd HH:mm')" % name)
    try:
        code, txt = _run(['powershell', '-NoProfile', '-Command', ps], timeout=25)
    except Exception:
        return None
    line = next((ln.strip() for ln in txt.splitlines() if '|' in ln), '')
    if code != 0 or not line:
        return None
    last, res, nxt = (line.split('|') + ['', '', ''])[:3]
    try:
        code_i = int(res)
    except Exception:
        code_i = None
    if code_i == 0x41303 or last.startswith('1999'):
        last = ''                       # 한 번도 안 돌았다 — 윈도우의 빈 값(1999-11-30)을 안 보인다
    return {'last_run': last, 'result': code_i, 'result_text': explain(code_i) if code_i is not None else '',
            'next_run': nxt}


def _selftest():
    ok = []
    x = build_xml('"C:\\py\\python.exe"', '"C:\\app\\a.py" --x', 12, 30, ('MON', 'WED', 'FRI'))
    ok.append(('요일 셋 → ScheduleByWeek 에 그 요일만', 'ScheduleByWeek' in x and x.count('<Monday />') == 1
               and '<Wednesday />' in x and '<Friday />' in x and '<Tuesday />' not in x))
    ok.append(('시각이 StartBoundary 에', 'T12:30:00' in x))
    ok.append(('배터리에서도 시작·계속', '<DisallowStartIfOnBatteries>false' in x and '<StopIfGoingOnBatteries>false' in x))
    ok.append(('놓친 시각은 켜지면 바로', '<StartWhenAvailable>true' in x))
    p = parse_xml(x)
    ok.append(('되읽기 — 시각·요일·인자', p['hh'] == 12 and p['mm'] == 30 and p['days'] == ['MON', 'WED', 'FRI']
               and p['args'] == '"C:\\app\\a.py" --x' and p['battery_ok'] and p['start_when_available'], p))
    x7 = build_xml('c', 'a', 3, 0, tuple(DAYS))
    ok.append(('일곱 요일 전부 = 매일(ScheduleByDay)', 'ScheduleByDay' in x7 and 'ScheduleByWeek' not in x7))
    ok.append(('None 도 매일', 'ScheduleByDay' in build_xml('c', 'a', 3, 0, None)))
    ok.append(('되읽기 — 매일이면 요일 일곱', parse_xml(x7)['days'] == list(DAYS)))
    ok.append(('요일 라벨', days_label(('MON', 'WED')) == '매주 월·수' and days_label(DAYS) == '매일'))
    ok.append(('결과 코드 — 거부됨을 사람 말로', '거부됨' in explain(-2147020576) and explain(0) == '정상 종료'))
    ok.append(('옛 등록 XML(배터리 막힘)을 읽으면 battery_ok=False',
               parse_xml('<Task><Settings><DisallowStartIfOnBatteries>true</DisallowStartIfOnBatteries></Settings>'
                         '<Triggers><CalendarTrigger><StartBoundary>2026-09-06T12:00:00</StartBoundary>'
                         '<ScheduleByDay/></CalendarTrigger></Triggers></Task>')['battery_ok'] is False))
    ok.append(('& < > 를 XML 로 피한다', '&amp;' in build_xml('c', 'a & b', 1, 0) and '<a>' not in build_xml('c', '<a>', 1, 0)))
    bad = [r for r in ok if not r[1]]
    for r in ok:
        print(('  OK   ' if r[1] else '  FAIL ') + r[0] + ('' if r[1] or len(r) < 3 else ' %r' % (r[2],)))
    print('task_sched selftest %d/%d' % (len(ok) - len(bad), len(ok)))
    return 0 if not bad else 1


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(_selftest())
    if '--read' in sys.argv:
        nm = sys.argv[sys.argv.index('--read') + 1]
        print(read(nm)); print(info(nm))
