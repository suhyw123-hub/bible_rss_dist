# -*- coding: utf-8 -*-
"""db_integrity.py — 연결 무결성·고립 자산 **검사 표의 단일 소스**
(2026-09-03 191차 신설·영구).

★★★ 왜 (사용자 지시): 「관리자가 연결관계가 이어졌는지 끊어졌는지, 비정상적
  으로 고립된 자산이 있는지를 **종합적으로 모니터링**하고 연결하는 관리화면이
  필요하다. **배포하기 전에 수시로 점검**한 후에 배포해야 한다.」

  실측 — 검사 능력은 있었으나 **CLI 도구 19개로 흩어져** 있어(overlay_audit ·
  plan_book_audit · book_url_audit · commentary_audit · linkpack_check …)
  관리자가 화면에서 못 보고, 배포 전에 무엇을 돌릴지 **기억에 의존**했다.
  ⇒ 검사를 **표 하나**에 모은다. 화면은 이 표를 그릴 뿐이다.

두 갈래를 **엄격히 가른다**(사용자 설계 원칙):
  · **판정(JUDGE)** — 0 이어야 하는 것. 끊긴 참조는 곧 결함이다.
  · **사실(FACT)**  — 참고값. 고립 자산은 정상일 수도 있다(수집 후 분류 대기).
  ⚠ 사실을 빨갛게 칠하면 **늘 빨개서 아무도 안 본다**(§115차 「잦은 경고는
    죽는다」). 색은 판정에만 쓴다.

새 자산 종류가 생기면 **여기 한 줄**을 더한다 — 화면은 안 고친다.

    python db_integrity.py --selftest   (의무)
    python db_integrity.py              (전체 점검 — 배포 전에 돌린다)
    python db_integrity.py --group LINK
"""
import io
import re
import sys

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

JUDGE, FACT = 'JUDGE', 'FACT'

#: ★★★ **「성질상 고립」 도장** (2026-09-06 사용자 지시 0.txt 6-3
#   「성질상 고립자산이라면 관리자화면에서 그 자산에 **「고립자산」이라는 값을
#   할당**하면 그것은 배포점검에서 **정상으로 처리**하면 된다」 ·
#   「이러한 유형에 따라서 제대로 관리한다면 **점검결과 모두 0**이 표시되도록」).
#
#   ⚠ **도장의 알갱이는 검사마다 다르다** — 실측이 그것을 정했다:
#     · 엔티티 **2건**(다윗의 아내들·30인 용사) — 낱낱이 찍는다.
#       §199차에 사용자가 「그룹이름만 만들고 엔티티는 만들지 마라」고 한 그것이라
#       **연결 0 이 정상**이다.
#     · 도서 편 **1,024건** — 낱낱이 못 찍는다. 지르들스톤 183 · 파스칼 172 ·
#       밀러 155 처럼 **책 성격상** 구절이 없는 것이라 **책 코드**로 찍는다.
#   ⇒ `ref` 가 무엇인지는 **그 검사가 정한다**(`exempt_ref` 칸).
EXEMPT_TABLE = 'sys_iso_exempt'

#: ★★★ **도장은 둘이다 — 낙인이 아니라 판단이다** (2026-09-06 사용자 지시
#   「지금은 고립자산이지만 **나중에 얼마든지 연결은 가능**해야 한다. 즉,
#   **고립자산 낙인은 매우 상대적이고 유연하게** 운영해야 한다」 ·
#   「**「채울 자리」라는 표현도 매우 좋다**」).
#   · `EXEMPT` **성질상 고립** — 이을 것이 없거나 이을 이유가 없다.
#     (지르들스톤 낱말 연구서 · 파스칼 단상 · 신조의 서문)
#   · `LATER`  **채울 자리** — 지금 없을 뿐 언젠가 잇는다.
#     (스펄전 설교인데 좌표가 없다 · 연구자료·주소자산이 붙을 자리)
#   ⚠ **둘 다 점검 목록에서는 빠진다**(그래야 「모두 0」이 된다). 다만
#     `LATER` 는 **따로 세어 보인다** — 빼기만 하면 잊는다.
MARK_EXEMPT, MARK_LATER = 'EXEMPT', 'LATER'
MARK_NAME = {MARK_EXEMPT: '성질상 고립', MARK_LATER: '채울 자리'}


def ensure_exempt(conn):
    """도장 표를 만든다(멱등). 읽기 전용 연결이면 조용히 넘어간다."""
    try:
        conn.execute(
            "CREATE TABLE IF NOT EXISTS %s ("
            " check_key TEXT NOT NULL, ref TEXT NOT NULL,"
            " note TEXT, ts TEXT DEFAULT (datetime('now','localtime')),"
            " PRIMARY KEY(check_key, ref))" % EXEMPT_TABLE)
        # ⚠ 옛 표에는 `mark` 칸이 없다 — 있으면 넘어가고 없으면 만든다(멱등).
        #   옛 행은 `EXEMPT` 로 읽힌다(그때는 그 뜻 하나뿐이었다).
        cols = [r[1] for r in conn.execute('PRAGMA table_info(%s)'
                                           % EXEMPT_TABLE)]
        if 'mark' not in cols:
            conn.execute("ALTER TABLE %s ADD COLUMN mark TEXT DEFAULT '%s'"
                         % (EXEMPT_TABLE, MARK_EXEMPT))
            conn.execute("UPDATE %s SET mark='%s' WHERE mark IS NULL"
                         % (EXEMPT_TABLE, MARK_EXEMPT))
        return True
    except Exception:
        return False


def _ex_clause(key, ref_expr):
    """그 검사의 SQL 에 끼울 「도장 찍힌 것은 뺀다」 한 조각."""
    return (" AND NOT EXISTS(SELECT 1 FROM %s e WHERE e.check_key='%s'"
            "   AND e.ref = CAST(%s AS TEXT))" % (EXEMPT_TABLE, key, ref_expr))


def exempt_add(conn, key, refs, note='', mark=MARK_EXEMPT):
    """도장을 찍는다 → 찍은 수.

    ⚠ **이미 찍힌 것은 갈래를 갈아 끼운다** — 「성질상 고립」이라 찍었다가
      「채울 자리」로 마음이 바뀌는 것이 이 표의 존재 이유다(낙인이 아니다).
    """
    ensure_exempt(conn)
    n = 0
    for r in refs:
        cur = conn.execute(
            "INSERT INTO %s(check_key, ref, note, mark) VALUES(?,?,?,?)"
            " ON CONFLICT(check_key, ref) DO UPDATE SET"
            "   note=excluded.note, mark=excluded.mark,"
            "   ts=datetime('now','localtime')" % EXEMPT_TABLE,
            (key, str(r), note or '', mark))
        n += cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0
    conn.commit()
    return n


def exempt_counts(conn, key):
    """그 검사에 찍힌 도장 → {갈래: 수}."""
    if not ensure_exempt(conn):
        return {}
    try:
        return {m or MARK_EXEMPT: n for m, n in conn.execute(
            "SELECT mark, COUNT(*) FROM %s WHERE check_key=? GROUP BY 1"
            % EXEMPT_TABLE, (key,))}
    except Exception:
        return {}


def exempt_del(conn, key, refs):
    """도장을 뗀다 → 뗀 수."""
    ensure_exempt(conn)
    n = 0
    for r in refs:
        cur = conn.execute(
            "DELETE FROM %s WHERE check_key=? AND ref=?" % EXEMPT_TABLE,
            (key, str(r)))
        n += cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0
    conn.commit()
    return n


def exempt_rows(conn, key=None):
    """찍힌 것 → [(check_key, ref, note, ts, mark)]."""
    if not ensure_exempt(conn):
        return []
    q = ("SELECT check_key, ref, COALESCE(note,''), COALESCE(ts,''),"
         " COALESCE(mark,'%s') FROM %s" % (MARK_EXEMPT, EXEMPT_TABLE))
    a = ()
    if key:
        q += ' WHERE check_key=?'
        a = (key,)
    return conn.execute(q + ' ORDER BY check_key, ref', a).fetchall()

#: 연결의 양끝이 실재해야 하는 짝 — (link_type, 왼쪽 표·PK, 오른쪽 표·PK)
#  ⚠ **양방향으로 다 본다** — 한쪽만 보면 「대상이 사라진 연결」을 놓친다
#    (§97차 유령 연결이 그 자리였다).
_REF = (
    ('ENTI_VERS', 'sys_entity_master', 'entity_id', 'bible_index', 'verse_id'),
    ('ENTI_PERI', 'sys_entity_master', 'entity_id',
     'sys_pericope_asset', 'pericope_id'),
    ('ENTI_ENTI', 'sys_entity_master', 'entity_id',
     'sys_entity_master', 'entity_id'),
    ('MEDI_ENTI', 'sys_media_asset', 'media_id',
     'sys_entity_master', 'entity_id'),
    ('MEDI_PERI', 'sys_media_asset', 'media_id',
     'sys_pericope_asset', 'pericope_id'),
    ('REFU_VERS', 'sys_ref_unit', 'ref_unit_id', 'bible_index', 'verse_id'),
    ('REFU_ENTI', 'sys_ref_unit', 'ref_unit_id',
     'sys_entity_master', 'entity_id'),
    ('BUNT_ENTI', 'sys_book_unit', 'unit_id',
     'sys_entity_master', 'entity_id'),
    ('BUNT_VERS', 'sys_book_unit', 'unit_id', 'bible_index', 'verse_id'),
    ('VERS_VERS', 'bible_index', 'verse_id', 'bible_index', 'verse_id'),
    ('NODE_VERS', 'sys_unit_asset', 'sys_unit_id', 'bible_index', 'verse_id'),
    ('CONT_NODE', 'sys_unit_asset', 'sys_unit_id',
     'sys_unit_asset', 'sys_unit_id'),
    ('CONT_ENTI', 'sys_unit_asset', 'sys_unit_id',
     'sys_entity_master', 'entity_id'),
    ('BOOK_ENTI', 'sys_book_asset', 'book_id',
     'sys_entity_master', 'entity_id'),
    ('BOOK_VERS', 'sys_book_asset', 'book_id', 'bible_index', 'verse_id'),
    # ★ 관계 ↔ 구절 (2026-09-05 신설 · `db_person_relation.PREL_VERS`) —
    #   「다윗-후새를 누르면 그 관계의 구절들」. 새 자산이 생기면 여기 한 줄.
    ('PREL_VERS', 'sys_person_relation', 'relation_id',
     'bible_index', 'verse_id'),
)


def _ref_checks():
    """끊긴 참조 검사 — 짝마다 왼쪽·오른쪽 둘."""
    out = []
    for lt, lt_tbl, lt_pk, rt_tbl, rt_pk in _REF:
        for side, tbl, pk, col in (('출발', lt_tbl, lt_pk, 'clicked_id'),
                                   ('도착', rt_tbl, rt_pk, 'target_id')):
            out.append({
                'group': 'LINK', 'kind': JUDGE,
                'key': '%s.%s' % (lt, col),
                'name': '%s — 없는 %s' % (lt, side),
                'sql': ("SELECT COUNT(*) FROM sys_link_asset l"
                        " WHERE l.link_type='%s'"
                        "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
                        "   AND NOT EXISTS(SELECT 1 FROM %s x"
                        "     WHERE x.%s=l.%s)" % (lt, tbl, pk, col)),
                'list': ("SELECT l.sys_link_id, l.clicked_id, l.target_id"
                         " FROM sys_link_asset l WHERE l.link_type='%s'"
                         "   AND COALESCE(l.record_status,'LIVE')='LIVE'"
                         "   AND NOT EXISTS(SELECT 1 FROM %s x"
                         "     WHERE x.%s=l.%s) LIMIT 200"
                         % (lt, tbl, pk, col)),
                'why': '연결이 가리키는 자산이 없다 — 화면에서 이름 없는 줄이 된다',
            })
    return out


#: 그 밖의 검사 — 표 한 줄이 검사 하나다
CHECKS = _ref_checks() + [
    {'group': 'LINK', 'kind': JUDGE, 'key': 'link.null_status',
     'name': '연결 · 상태 NULL',
     'sql': "SELECT COUNT(*) FROM sys_link_asset WHERE record_status IS NULL",
     'list': ("SELECT sys_link_id, link_type, clicked_id FROM sys_link_asset"
              " WHERE record_status IS NULL LIMIT 200"),
     'why': 'LIVE 만 세는 검사가 NULL 을 못 본다(§154차)'},
    {'group': 'LINK', 'kind': JUDGE, 'key': 'link.self',
     'name': '연결 · 자기 자신을 가리킴',
     'sql': ("SELECT COUNT(*) FROM sys_link_asset WHERE clicked_id=target_id"
             " AND substr(link_type,1,4)=substr(link_type,6,4)"
             " AND COALESCE(record_status,'LIVE')='LIVE'"),
     'list': ("SELECT sys_link_id, link_type, clicked_id FROM sys_link_asset"
              " WHERE clicked_id=target_id"
              " AND substr(link_type,1,4)=substr(link_type,6,4) LIMIT 200"),
     'why': '같은 자산끼리의 고리 — 화면에서 자기가 자기 아래에 뜬다'},
    {'group': 'TEXT', 'kind': JUDGE, 'key': 'text.orphan_entity_desc',
     'name': '설명문 · 없는 엔티티',
     'sql': ("SELECT COUNT(*) FROM sys_text_asset t"
             " WHERE t.text_type IN ('ENTITY_NAME','ENTITY_DESC')"
             "   AND COALESCE(t.record_status,'LIVE')='LIVE'"
             "   AND NOT EXISTS(SELECT 1 FROM sys_entity_master m"
             "     WHERE m.entity_id=t.clicked_id)"),
     'list': ("SELECT sys_text_id, text_type, clicked_id FROM sys_text_asset t"
              " WHERE t.text_type IN ('ENTITY_NAME','ENTITY_DESC')"
              "   AND NOT EXISTS(SELECT 1 FROM sys_entity_master m"
              "     WHERE m.entity_id=t.clicked_id) LIMIT 200"),
     'why': '주인이 사라진 글 — 어느 화면에도 안 나온다(미아)'},
    {'group': 'TEXT', 'kind': JUDGE, 'key': 'text.orphan_link_desc',
     'name': '연결설명문 · 없는 연결',
     'sql': ("SELECT COUNT(*) FROM sys_text_asset t"
             " WHERE t.text_type='VERS_VERS_DESC'"
             "   AND COALESCE(t.record_status,'LIVE')='LIVE'"
             "   AND NOT EXISTS(SELECT 1 FROM sys_link_asset l"
             "     WHERE l.sys_link_id=t.clicked_id)"),
     'list': ("SELECT sys_text_id, lang_code, clicked_id FROM sys_text_asset t"
              " WHERE t.text_type='VERS_VERS_DESC'"
              "   AND NOT EXISTS(SELECT 1 FROM sys_link_asset l"
              "     WHERE l.sys_link_id=t.clicked_id) LIMIT 200"),
     'why': '연결이 사라졌는데 글만 남았다'},
    # ★★★ **관계 설명문이 빠져 있었다** (2026-09-05 사용자 지시 「0.person.txt
    #   ... 인물과 관계유형이 잘못 연결된 것들이 매우 많다」를 조사하다 잡았다).
    #   실측 — `RELATION_DESC` **5건이 전부 미아**였다(`clicked_id` 62833~62839
    #   인데 `relation_id` 는 1~136). 다윗-요나단·엘리야-엘리사 같은 잘 쓴 글이
    #   **화면에 한 번도 뜬 적이 없다.**
    #   ⚠ 39검사가 이것을 못 잡은 까닭은 **표에 이 줄이 없었기 때문**이다 —
    #     「설명문·없는 엔티티」와 「연결설명문·없는 연결」만 있었다.
    #   ★ **글의 갈래를 늘리면 그 주인을 대조하는 줄도 함께 늘린다.**
    {'group': 'TEXT', 'kind': JUDGE, 'key': 'text.orphan_rel_desc',
     'name': '관계 설명문 · 없는 관계',
     'sql': ("SELECT COUNT(*) FROM sys_text_asset t"
             " WHERE t.text_type='RELATION_DESC'"
             "   AND COALESCE(t.record_status,'LIVE')='LIVE'"
             "   AND NOT EXISTS(SELECT 1 FROM sys_person_relation r"
             "     WHERE r.relation_id=t.clicked_id)"),
     'list': ("SELECT sys_text_id, lang_code, clicked_id FROM sys_text_asset t"
              " WHERE t.text_type='RELATION_DESC'"
              "   AND NOT EXISTS(SELECT 1 FROM sys_person_relation r"
              "     WHERE r.relation_id=t.clicked_id) LIMIT 200"),
     'why': '인물 관계가 사라졌는데 글만 남았다 — 화면에 안 나온다'},
    # ── 고립 자산 — **사실**이다(정상일 수 있다) ──────────────────
    # ⚠ **보관함에 담긴 것은 고립이 아니다** (2026-09-04 사용자 지시
    #   「미분류 보관함 통합하라」의 마지막 조각). 보관함은 「연결 대상을 아직
    #   못 정했다」는 **판단 대기줄**이라 사람이 볼 자리가 이미 있다.
    #   그것까지 「어디에도 안 걸림」이라 부르면 화면이 거짓말을 한다.
    #   ⇒ 여기 남는 것은 **대기줄에조차 없는 진짜 미아**다(0이어야 한다).
    {'group': 'ISOLATED', 'kind': FACT, 'key': 'iso.media',
     'name': '미디어 · 보관함에도 없고 안 걸림',
     'sql': ("SELECT COUNT(*) FROM sys_media_asset ma"
             " WHERE ma.record_status='LIVE'"
             "   AND NOT EXISTS(SELECT 1 FROM sys_link_asset l"
             "     WHERE l.link_type LIKE 'MEDI%' AND l.clicked_id=ma.media_id"
             "       AND COALESCE(l.record_status,'LIVE')='LIVE')"
             "   AND NOT EXISTS(SELECT 1 FROM sys_media_pending p"
             "     WHERE p.media_id=ma.media_id"
             "       AND COALESCE(p.record_status,'LIVE')='LIVE'){EX}"),
     'exempt_ref': 'ma.media_id',
     'exempt_what': '이 영상',
     'list': ("SELECT ma.media_id, ma.media_type, ma.title"
              " FROM sys_media_asset ma WHERE ma.record_status='LIVE'"
              "   AND NOT EXISTS(SELECT 1 FROM sys_link_asset l"
              "     WHERE l.link_type LIKE 'MEDI%' AND l.clicked_id=ma.media_id"
              "       AND COALESCE(l.record_status,'LIVE')='LIVE')"
              "   AND NOT EXISTS(SELECT 1 FROM sys_media_pending p"
              "     WHERE p.media_id=ma.media_id"
              "       AND COALESCE(p.record_status,'LIVE')='LIVE'){EX}"
              " LIMIT 200"),
     'why': '수집만 되고 대기줄에도 없는 것 — 다시 훑어 보관함으로 보낸다',
     'panel': 'media_classify'},
    {'group': 'ISOLATED', 'kind': FACT, 'key': 'iso.media_pend',
     'name': '미디어 · 보관함 대기(연결 못 정함)',
     'sql': ("SELECT COUNT(*) FROM sys_media_pending p"
             " WHERE COALESCE(p.record_status,'LIVE')='LIVE'"),
     'list': ("SELECT p.media_id, p.scope, ma.title"
              " FROM sys_media_pending p"
              " LEFT JOIN sys_media_asset ma ON ma.media_id=p.media_id"
              " WHERE COALESCE(p.record_status,'LIVE')='LIVE' LIMIT 200"),
     # ⚠ **세부목록을 안 낸다**(2026-09-06 사용자 0.txt 6-3 「대기자산 :
     #   미디어/보관함 대기 유형을 매우 잘 분류했다. 이런 것은 **너무 많고
     #   별도 화면이 있으므로 세부목록을 표시할 필요 없다**」).
     #   3,141건을 200줄만 잘라 보이면 그것을 「전부」로 읽는다.
     'no_detail': True,
     'why': '사람이 연결 대상을 정할 차례 — 정상 대기줄이다(④ 검토·연결의 보관함 마디에서 본다)',
     'panel': 'yt_review'},
    {'group': 'ISOLATED', 'kind': FACT, 'key': 'iso.term',
     'name': '용어(정성) · 연결 0',
     'sql': ("SELECT COUNT(*) FROM sys_entity_master m"
             " WHERE m.entity_type='TERM'"
             "   AND COALESCE(m.record_status,'LIVE')='LIVE'"
             "   AND COALESCE(m.json_detail,'') NOT LIKE '%\"subtype\": \"LEX\"%'"
             "   AND NOT EXISTS(SELECT 1 FROM sys_link_asset l"
             "     WHERE COALESCE(l.record_status,'LIVE')='LIVE'"
             "       AND ((l.link_type LIKE 'ENTI%' AND l.clicked_id=m.entity_id)"
             "         OR (l.link_type LIKE '%_ENTI' AND l.target_id=m.entity_id))){EX}"),
     'exempt_ref': 'm.entity_id',
     'exempt_what': '이 용어',
     'list': ("SELECT m.entity_id, m.entity_code, ''"
              " FROM sys_entity_master m WHERE m.entity_type='TERM'"
              "   AND COALESCE(m.record_status,'LIVE')='LIVE'"
              "   AND COALESCE(m.json_detail,'') NOT LIKE '%\"subtype\": \"LEX\"%'"
              "   AND NOT EXISTS(SELECT 1 FROM sys_link_asset l"
              "     WHERE COALESCE(l.record_status,'LIVE')='LIVE'"
              "       AND ((l.link_type LIKE 'ENTI%' AND l.clicked_id=m.entity_id)"
              "         OR (l.link_type LIKE '%_ENTI' AND l.target_id=m.entity_id))){EX}"
              " LIMIT 200"),
     'why': '사람이 손댄 용어인데 아무 데도 안 이어졌다 — 대개 작업 미완',
     'panel': 'entity_mgr'},
    # ⚠⚠⚠ **잣대가 좁았다** (2026-09-06 사용자 지적 「**또다른 연결대상이
    #   존재할 수 있다.** 예) 연구자료, 주소자산.. 그렇다면 지금은 고립자산
    #   이지만 나중에 얼마든지 연결은 가능해야 한다」).
    #   예전에는 `BUNT_VERS`(구절 앵커) **하나만** 보았다. 그래서 **용어로
    #   이미 이어져 있는 111편**이 「고립」으로 불렸다(실측 1,024 → **913**).
    #   ⇒ **어느 축으로든 연결이 있으면 고립이 아니다**(양방향).
    {'group': 'ISOLATED', 'kind': FACT, 'key': 'iso.book_unit',
     'name': '도서 편 · 어떤 연결도 없음',
     'sql': ("SELECT COUNT(*) FROM sys_book_unit u"
             " WHERE COALESCE(u.record_status,'LIVE')='LIVE'"
             "   AND u.start_vid IS NULL"
             "   AND NOT EXISTS(SELECT 1 FROM sys_link_asset l"
             "     WHERE COALESCE(l.record_status,'LIVE')='LIVE'"
             "       AND ((l.link_type LIKE 'BUNT%' AND l.clicked_id=u.unit_id)"
             "         OR (l.link_type LIKE '%\\_BUNT' ESCAPE '\\'"
             "             AND l.target_id=u.unit_id))){EX}"),
     # ★ **도장은 책 단위다** — 편 1,024개를 낱낱이 찍을 수 없고, 구절이
     #   없는 것은 **그 책의 성격**이지 그 편의 실수가 아니다.
     'exempt_ref': ('(SELECT ba.book_code FROM sys_book_asset ba'
                    ' WHERE ba.book_id=u.book_id)'),
     'exempt_what': '이 책 전체',
     'exempt_by': 'book',
     'list': ("SELECT u.unit_id,"
              " COALESCE((SELECT ba.book_code FROM sys_book_asset ba"
              "           WHERE ba.book_id=u.book_id),'?')"
              " || ' · ' || COALESCE(u.unit_label,''), ''"
              " FROM sys_book_unit u"
              " WHERE COALESCE(u.record_status,'LIVE')='LIVE'"
              "   AND u.start_vid IS NULL"
              "   AND NOT EXISTS(SELECT 1 FROM sys_link_asset l"
              "     WHERE COALESCE(l.record_status,'LIVE')='LIVE'"
              "       AND ((l.link_type LIKE 'BUNT%' AND l.clicked_id=u.unit_id)"
              "         OR (l.link_type LIKE '%\\_BUNT' ESCAPE '\\'"
              "             AND l.target_id=u.unit_id))){EX}"
              " LIMIT 200"),
     'why': '구절도 용어도 자료도 안 붙었다 — 역사·논설·시는 비워 두는 것이 맞다',
     'panel': 'book_mgr'},
    {'group': 'ISOLATED', 'kind': FACT, 'key': 'iso.entity_nolink',
     'name': '엔티티(용어 밖) · 연결 0',
     'sql': ("SELECT COUNT(*) FROM sys_entity_master m"
             " WHERE m.entity_type<>'TERM'"
             "   AND COALESCE(m.record_status,'LIVE')='LIVE'"
             "   AND NOT EXISTS(SELECT 1 FROM sys_link_asset l"
             "     WHERE COALESCE(l.record_status,'LIVE')='LIVE'"
             "       AND ((l.link_type LIKE 'ENTI%' AND l.clicked_id=m.entity_id)"
             "         OR (l.link_type LIKE '%_ENTI' AND l.target_id=m.entity_id))){EX}"),
     'exempt_ref': 'm.entity_id',
     'exempt_what': '이 자산',
     'list': ("SELECT m.entity_id, m.entity_code, m.entity_type"
              " FROM sys_entity_master m WHERE m.entity_type<>'TERM'"
              "   AND COALESCE(m.record_status,'LIVE')='LIVE'"
              "   AND NOT EXISTS(SELECT 1 FROM sys_link_asset l"
              "     WHERE COALESCE(l.record_status,'LIVE')='LIVE'"
              "       AND ((l.link_type LIKE 'ENTI%' AND l.clicked_id=m.entity_id)"
              "         OR (l.link_type LIKE '%_ENTI' AND l.target_id=m.entity_id))){EX}"
              " LIMIT 200"),
     'why': '인물·장소인데 구절도 단락도 안 붙었다',
     'panel': 'entity_mgr'},
]


# ══ 중복 (2026-10-09 · docs/1.txt 58 · 사용자 「사용자 db 에 중복이 있다면 앱의 결함이다 ·
#    고립은 의도된 것으로 간주한다」) ════════════════════════════════════════════════════
# ★ 「무엇이 같으면 같은 것인가」(자연 열쇠)를 자산마다 한 줄로 적는다 — **제목이 같다는 것은
#   잣대가 아니다**(실측 2026-10-09: 같은 제목 연구자료 44 = 전부 「(제목 없음)」 자리표 · 같은 제목·채널
#   영상 2,257 = 거의 다 같은 곡의 다른 판).
# ★ 판정(JUDGE) = 같은 행이 두 번 · 사실(FACT) = 비슷하지만 결함이 아닐 수 있는 것.
# ★ 사용자 DB(user_*)는 **중복만** 본다 — 고립은 의도된 것이다(아무 구절에도 안 붙인 노트는 정상).
# ★ `fix` = [하나만 남기기] 가 숨길 줄(가장 작은 번호를 남기고 나머지를 HIDE — 지우지 않는다).
#   fix 가 없는 검사는 사람이 보고 고른다(진행 중 플랜·본문이 같은 다른 글 …).
_LIVE = "COALESCE(record_status,'LIVE') NOT IN ('HIDE','DEL','DELETED')"


def _dup(key, name, table, cols, idcol, why, where=_LIVE, kind=JUDGE, fix=True, show=None, panel=''):
    """자연 열쇠 `cols` 가 같은 줄이 둘 이상인 묶음 → 남는 줄 수(= 숨겨야 할 수)를 센다."""
    keyexpr = ', '.join(cols)
    sub = 'SELECT %s, COUNT(*) n, MIN(%s) keep_id FROM %s WHERE %s GROUP BY %s HAVING n>1' % (
        keyexpr, idcol, table, where, keyexpr)
    return {
        'group': 'DUP', 'kind': kind, 'key': key, 'name': name,
        'sql': 'SELECT COALESCE(SUM(n-1),0) FROM (%s)' % sub,
        'list': ('SELECT %s, n || \'줄\', keep_id FROM (%s) LIMIT 200'
                 % ((show or "''") , sub)),
        'why': why, 'panel': panel,
        'fix': ({'table': table, 'id': idcol, 'cols': cols, 'where': where} if fix else None),
    }


CHECKS += [
    # ── 배포 DB ─────────────────────────────────────────────────────────
    _dup('dup.sys_link', '연결 · 같은 줄이 두 번', 'sys_link_asset',
         ['link_type', 'clicked_id', 'target_id', "COALESCE(rel_code,'')", 'COALESCE(end_id,target_id)'],
         'sys_link_id', '유일 색인이 막고 있다 — 0 이 아니면 색인이 풀렸거나 상태값이 어긋났다',
         show="link_type || ' ' || clicked_id || '→' || target_id"),
    _dup('dup.sys_text', '글 · 같은 자리·유형·언어·변형', 'sys_text_asset',
         ['clicked_id', 'text_type', 'lang_code', "COALESCE(text_variant,'')"], 'sys_text_id',
         '화면은 하나만 선택한다 — 어느 글이 보일지 정해지지 않는다',
         show="text_type || ' ' || clicked_id || ' ' || lang_code"),
    _dup('dup.sys_ref_text', '공용 연구자료 · 같은 글·언어·변형', 'sys_ref_text',
         ['ref_unit_id', "COALESCE(text_variant,'')", 'lang_code'], 'text_id',
         '같은 글의 같은 언어가 두 벌 — 고친 것이 어느 쪽에 남았는지 모른다',
         show="ref_unit_id || ' ' || lang_code"),
    _dup('dup.sys_ref_body', '공용 연구자료 · 본문이 같은 다른 글', 'sys_ref_text',
         ['lang_code', 'body_text'], 'text_id', '복사해 새 글로 만든 것 — 사람이 보고 합친다',
         where=("length(COALESCE(body_text,''))>50 AND " + _LIVE +
                " AND ref_unit_id IN (SELECT ref_unit_id FROM sys_ref_unit WHERE " + _LIVE + ")"), fix=False,
         show="lang_code || ' · ' || substr(body_text,1,40)"),
    _dup('dup.sys_media', '영상 · 같은 유튜브 영상 ID', 'sys_media_asset',
         ["CASE WHEN instr(url,'v=')>0 THEN substr(url,instr(url,'v=')+2,11) ELSE url END"],
         'media_id', '같은 영상이 두 번 수집됐다 — 연결·승인이 둘로 갈린다',
         show="substr(title,1,40)", panel='yt_review'),
    _dup('dup.sys_book_unit', '도서 편 · 같은 책·같은 차례', 'sys_book_unit',
         ['book_id', 'sequence'], 'unit_id', '편 차례가 겹친다 — 읽기 화면의 다음/이전이 꼬인다',
         show="book_id || ' #' || sequence", panel='book_mgr'),
    {'group': 'DUP', 'kind': JUDGE, 'key': 'dup.ref_untitled', 'name': '공용 연구자료 · 제목 없음',
     'sql': ("SELECT COUNT(*) FROM sys_ref_unit u JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id"
             " WHERE s.src_type='STUDY' AND COALESCE(u.record_status,'LIVE')='LIVE'"
             "   AND COALESCE(NULLIF(trim(u.unit_label),''),'(제목 없음)')='(제목 없음)'"),
     'list': ("SELECT u.ref_unit_id, COALESCE(u.unit_label,''), '' FROM sys_ref_unit u"
              " JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id WHERE s.src_type='STUDY'"
              "   AND COALESCE(u.record_status,'LIVE')='LIVE'"
              "   AND COALESCE(NULLIF(trim(u.unit_label),''),'(제목 없음)')='(제목 없음)' LIMIT 200"),
     'why': '목록에서 같은 이름 수십 줄이 되어 중복처럼 보인다 — 본문 첫 줄로 제목을 채운다',
     'panel': 'research_mgr'},
    {'group': 'DUP', 'kind': FACT, 'key': 'dup.sys_link_nested', 'name': '연결 · 같은 출발·도착에 구간만 다른 줄',
     'sql': ("SELECT COUNT(*) FROM (SELECT link_type, clicked_id, target_id, COALESCE(rel_code,'') r"
             " FROM sys_link_asset WHERE " + _LIVE + " GROUP BY 1,2,3,4 HAVING COUNT(*)>1)"),
     'list': ("SELECT link_type || ' ' || clicked_id || '→' || target_id, group_concat(COALESCE(end_id,'-')),"
             " COUNT(*) FROM sys_link_asset WHERE " + _LIVE + " GROUP BY link_type, clicked_id, target_id,"
             " COALESCE(rel_code,'') HAVING COUNT(*)>1 LIMIT 200"),
     'why': '구간(끝 절)이 다르면 다른 연결이다 — 겹치는 구간이 의도인지 사람이 본다'},
    {'group': 'DUP', 'kind': FACT, 'key': 'dup.media_title', 'name': '영상 · 같은 제목·같은 채널(다른 영상)',
     'sql': ("SELECT COALESCE(SUM(n-1),0) FROM (SELECT title, json_extract(description,'$.channel') ch,"
             " COUNT(*) n FROM sys_media_asset WHERE " + _LIVE + " AND json_valid(description)"
             " GROUP BY 1,2 HAVING n>1)"),
     'list': ("SELECT substr(title,1,50), json_extract(description,'$.channel'), COUNT(*) FROM sys_media_asset"
              " WHERE " + _LIVE + " AND json_valid(description) GROUP BY title, 2 HAVING COUNT(*)>1 LIMIT 200"),
     'why': '대부분 같은 곡의 다른 판(실황·가사판·쇼츠)이다 — 결함이 아니다'},
    # ── 사용자 DB — 중복은 앱의 결함이다(고립은 안 본다) ──────────────────
    _dup('dup.user_link', '내 연결 · 같은 줄이 두 번', 'user_link_asset',
         ['link_type', 'clicked_id', 'target_id', "COALESCE(rel_code,'')", 'COALESCE(end_id,target_id)'],
         'user_link_id', '같은 연결을 두 번 저장했다 — 저장 문의 결함',
         show="link_type || ' ' || clicked_id || '→' || target_id"),
    _dup('dup.user_text', '내 글 · 같은 자리에 같은 글이 두 번', 'user_text_asset',
         ['clicked_id', 'text_type', 'lang_code', 'contents'], 'user_text_id',
         '한 번 쓴 노트·덮개가 두 번 저장됐다(두 번 눌림·자동저장 겹침)',
         where="COALESCE(contents,'')<>'' AND " + _LIVE,
         show="text_type || ' ' || clicked_id || ' · ' || substr(contents,1,30)"),
    _dup('dup.user_ref_body', '내 연구자료 · 본문이 같은 다른 글', 'user_ref_text',
         ['lang_code', 'body_text'], 'text_id', '같은 글이 두 편으로 저장됐다 — 저장 문의 결함',
         where=("length(COALESCE(body_text,''))>50 AND " + _LIVE +
                " AND ref_id IN (SELECT ref_id FROM user_ref_asset WHERE " + _LIVE + ")"), fix=False,
         show="lang_code || ' · ' || substr(body_text,1,40)"),
    _dup('dup.user_fav', '내 즐겨찾기 · 같은 것이 두 번', 'user_favorite',
         ['fav_type', 'target_id', 'COALESCE(verse_id,0)'], 'fav_id', '★ 를 두 번 눌러 두 줄이 됐다',
         show="fav_type || ' ' || target_id"),
    _dup('dup.user_enroll', '내 플랜 · 같은 플랜이 둘 다 진행 중', 'user_plan_enrollment',
         ['COALESCE(plan_id,0)', "COALESCE(user_plan_id,0)"], 'enrollment_id',
         '진행 줄이 둘이면 오늘 몫·완료 표시가 갈린다 — 사람이 하나를 선택한다',
         where="enrollment_status='ACTIVE' AND " + _LIVE, fix=False,
         show="COALESCE(plan_id,0) || '/' || COALESCE(user_plan_id,0)"),
    _dup('dup.user_progress', '내 플랜 · 같은 날 완료가 두 번', 'user_plan_progress',
         ['enrollment_id', 'schedule_id'], 'progress_id', '하루 완료를 두 번 적었다',
         show="enrollment_id || ' #' || schedule_id"),
    _dup('dup.user_prompt', '내 AI 프롬프트 · 같은 씨앗이 두 번', 'user_ai_prompt',
         ['lang_code', "COALESCE(scope,'')", 'kind', "COALESCE(task,'')"], 'prompt_id',
         '씨앗을 두 번 심었다 — 같은 단추가 두 개 뜬다', where="kind NOT LIKE 'USER%' AND " + _LIVE,
         show="lang_code || ' ' || COALESCE(scope,'') || ' ' || kind"),
    _dup('dup.user_entity', '내 용어 덮개 · 같은 용어가 두 번', 'user_entity_asset',
         ['entity_code'], 'user_entity_id', '덮개가 둘이면 어느 쪽이 보일지 정해지지 않는다',
         show='entity_code'),
    _dup('dup.user_media', '내 영상 · 같은 주소가 두 번', 'user_media_asset',
         ['url'], 'user_media_id', '같은 영상을 두 번 담았다', show='substr(title,1,40)'),
]

GROUPS = (('LINK', '연결 참조'), ('TEXT', '글의 주인'), ('DUP', '중복'),
          ('ISOLATED', '고립 자산'))


def fix_dup(conn, key, note='DUP_FIX'):
    """[하나만 남기기] — 그 검사의 묶음마다 가장 작은 번호를 남기고 나머지를 HIDE → 숨긴 수.

    ⚠ 지우지 않는다(되돌릴 수 있게) · fix 가 없는 검사는 거부한다(사람이 고를 것).
    """
    c = check_of(key)
    if not c or not c.get('fix'):
        raise ValueError('이 검사는 자동으로 고치지 않습니다: %s' % key)
    f = c['fix']
    cols = ', '.join(f['cols'])
    sql = ('UPDATE %s SET record_status=\'HIDE\' WHERE %s AND %s NOT IN'
           ' (SELECT MIN(%s) FROM %s WHERE %s GROUP BY %s)'
           ' AND (%s) IN (SELECT %s FROM %s WHERE %s GROUP BY %s HAVING COUNT(*)>1)'
           % (f['table'], f['where'], f['id'], f['id'], f['table'], f['where'], cols,
              cols, cols, f['table'], f['where'], cols))
    if len(f['cols']) == 1:
        sql = sql.replace('AND (%s) IN' % cols, 'AND %s IN' % cols)
    n = conn.execute(sql).rowcount
    conn.commit()
    return n or 0



def _sql_of(c, field, have_table):
    """`{EX}` 자리를 채운다 — 도장 표가 없으면 **빈 조각**으로 지운다.

    ⚠ 지우지 않고 두면 `no such table` 로 그 검사가 통째로 터진다."""
    sql = c[field]
    if '{EX}' not in sql:
        return sql
    clause = ''
    if have_table and c.get('exempt_ref'):
        clause = _ex_clause(c['key'], c['exempt_ref'])
    return sql.replace('{EX}', clause)


def run(conn, group=None, keys=None):
    """검사 실행 → [{key,name,group,kind,n,ok,why,panel}].

    ⚠ 한 검사가 터져도 나머지는 돈다 — `n=None·err` 로 알린다(조용히
      건너뛰면 「검사가 도는 줄 알았는데 안 돌았다」가 된다)."""
    have = ensure_exempt(conn)
    out = []
    for c in CHECKS:
        if group and c['group'] != group:
            continue
        if keys and c['key'] not in keys:
            continue
        row = dict(c)
        row.pop('sql', None)
        row.pop('list', None)
        try:
            row['n'] = conn.execute(_sql_of(c, 'sql', have)).fetchone()[0]
            row['err'] = ''
        except Exception as e:
            row['n'] = None
            row['err'] = str(e)
        row['ok'] = (row['n'] == 0) if c['kind'] == JUDGE else True
        # ★ 도장을 **몇 개 어떤 갈래로** 찍었는지 함께 낸다 — 「채울 자리」를
        #   빼기만 하고 안 세면 잊는다(사용자 지시 「유연하게 운영」).
        if c['group'] == 'ISOLATED' and c.get('exempt_ref'):
            row['marks'] = exempt_counts(conn, c['key']) if have else {}
        else:
            row['marks'] = {}
        out.append(row)
    return out


def detail(conn, key, limit=200):
    """그 검사에 걸린 줄 → [(…)]. 화면이 목록을 그릴 때."""
    have = ensure_exempt(conn)
    for c in CHECKS:
        if c['key'] == key:
            try:
                return conn.execute(
                    _sql_of(c, 'list', have)).fetchall()[:limit]
            except Exception as e:
                return [('오류', str(e), '')]
    return []


def check_of(key):
    """열쇠로 검사 한 줄을 찾는다(화면이 `exempt_*` 칸을 읽는다)."""
    for c in CHECKS:
        if c['key'] == key:
            return c
    return None


def exempt_refs_for(conn, key, unit_ids):
    """세부목록에서 선택한 줄 → 도장에 쓸 `ref` 값.

    ★ 대부분 자산 번호 그대로지만 **도서 편은 책 코드**다(`exempt_by='book'`).
      화면이 그 차이를 몰라도 되게 여기서 갈라 준다."""
    c = check_of(key) or {}
    if c.get('exempt_by') != 'book':
        return [str(i) for i in unit_ids]
    out = []
    for uid in unit_ids:
        r = conn.execute(
            "SELECT ba.book_code FROM sys_book_unit u"
            " JOIN sys_book_asset ba ON ba.book_id=u.book_id"
            " WHERE u.unit_id=?", (uid,)).fetchone()
        if r and r[0] and r[0] not in out:
            out.append(r[0])
    return out


#: 목록 SQL 꼬리의 `LIMIT n` — 도장 대조는 한도 없이 세야 한다.
_RX_LIMIT = re.compile(r'\s+LIMIT\s+\d+\s*$', re.I)


def stale_stamps(conn):
    """**이제 필요 없는 도장** → [(check_key, ref, note, mark)].

    ★★ 왜 (2026-09-06 사용자 원칙 「지금은 고립자산이지만 **나중에 얼마든지
      연결은 가능**해야 한다. 즉, 고립자산 낙인은 **매우 상대적이고 유연하게**
      운영해야 한다」): 찍어 둔 자산에 연결이 생기면 도장은 **거짓 표시**가
      된다. 실측으로 실제로 났다 — 엔티티 둘(다윗의 아내들·30인 용사)에
      연결이 5개씩 생겼는데 도장이 그대로 남아 있었다.
    ⚠ **자동으로 떼지 않는다** — 도장은 사람이 판단해 찍은 것이고, 연결
      하나가 생겼다고 「성질상 고립」이라는 판단이 틀린 것은 아닐 수 있다.
      **보이기만 하고 뗄지는 사람이 정한다**(§0-1 조용히 바꾸지 않는다).
    ⚠ 도장이 걸린 것을 다시 세려면 **도장 없이** 목록을 뽑아야 한다 —
      그래서 `{EX}` 를 빈 조각으로 지운 SQL 을 쓴다.
    """
    if not ensure_exempt(conn):
        return []
    out = []
    for c in CHECKS:
        if '{EX}' not in (c.get('list') or ''):
            continue
        marks = {r[1]: (r[2], r[4]) for r in exempt_rows(conn, c['key'])}
        if not marks:
            continue
        # ⚠⚠ **목록 SQL 에는 이미 `LIMIT` 이 붙어 있다**(화면이 200줄로 자른다).
        #   뒤에 하나 더 붙이면 문법 오류이고, 그것을 `except` 로 삼키면
        #   **「이제 필요 없는 도장 0건」이라는 거짓 보고**가 된다(실측으로
        #   당했다). 잘라 내고 **한도 없이** 센다 — 도장이 걸린 것을 다 봐야
        #   「살아 있는 것」 집합이 맞다.
        sql = _RX_LIMIT.sub('', c['list'].replace('{EX}', ''))
        try:
            ids = [r[0] for r in conn.execute(sql)]
        except Exception as e:
            # 조용히 건너뛰지 않는다 — 못 잰 것을 「없다」로 내면 안 된다.
            out.append((c['key'], '?', '도장을 확인하지 못했습니다: %s'
                        % str(e)[:60], 'ERR'))
            continue
        live = set(exempt_refs_for(conn, c['key'], ids))
        for ref, (note, mark) in marks.items():
            if ref not in live:
                out.append((c['key'], ref, note, mark))
    return out


def summary(rows):
    """(판정 실패 수, 검사 수, 사실 합계)."""
    bad = sum(1 for r in rows if r['kind'] == JUDGE and not r['ok'])
    fact = sum(r['n'] or 0 for r in rows if r['kind'] == FACT and r.get('group') == 'ISOLATED')
    return bad, len(rows), fact



def rule_count(conn):
    """룰엔진이 부르는 한 문 → `(어긋난 수, 짧은 설명)`.

    ★ **여기서 다시 세지 않는다** — 이 도구가 이미 하는 일을 그대로 받는다.
      두 벌로 세면 한쪽만 고쳐진다(§db_rules 머리말).
    """
    rows = run(conn)
    bad = [r for r in rows if r.get('kind') == JUDGE and not r.get('ok')]
    return len(bad), '; '.join(str(r.get('name'))[:22] for r in bad[:3])


def selftest():
    import sqlite3
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    keys = [c['key'] for c in CHECKS]
    t('검사 표 — 열쇠 유일', len(keys) == len(set(keys)), len(keys))
    t('검사 표 — 갈래는 둘뿐',
      {c['kind'] for c in CHECKS} == {JUDGE, FACT})
    t('검사 표 — 묶음이 GROUPS 안에',
      {c['group'] for c in CHECKS} <= {g for g, _n in GROUPS})
    t('검사마다 이유가 적혀 있다', all(c.get('why') for c in CHECKS))
    t('검사마다 목록 문이 있다', all(c.get('list') for c in CHECKS))
    # 탐지력 — 일부러 깨뜨린 DB 에서 잡는가
    conn = sqlite3.connect(':memory:')
    conn.execute("CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY,"
                 " link_type TEXT, clicked_id INT, target_id INT,"
                 " record_status TEXT)")
    conn.execute("CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY,"
                 " entity_code TEXT, entity_type TEXT, json_detail TEXT,"
                 " record_status TEXT)")
    conn.execute("CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY)")
    conn.execute("INSERT INTO sys_entity_master VALUES(1,'T_A','TERM',NULL,'LIVE')")
    conn.execute("INSERT INTO bible_index VALUES(10)")
    conn.execute("INSERT INTO sys_link_asset VALUES(1,'ENTI_VERS',1,10,'LIVE')")
    rows = run(conn, keys=['ENTI_VERS.clicked_id', 'ENTI_VERS.target_id'])
    t('건강한 짝 — 0', all(r['n'] == 0 for r in rows), [r['n'] for r in rows])
    conn.execute("INSERT INTO sys_link_asset VALUES(2,'ENTI_VERS',99,10,'LIVE')")
    rows = run(conn, keys=['ENTI_VERS.clicked_id'])
    t('★ 없는 출발을 잡는다', rows[0]['n'] == 1 and not rows[0]['ok'])
    t('목록도 낸다', len(detail(conn, 'ENTI_VERS.clicked_id')) == 1)
    conn.execute("INSERT INTO sys_link_asset VALUES(3,'ENTI_VERS',1,999,'LIVE')")
    rows = run(conn, keys=['ENTI_VERS.target_id'])
    t('★ 없는 도착을 잡는다', rows[0]['n'] == 1)
    conn.execute("INSERT INTO sys_link_asset VALUES(4,'ENTI_VERS',1,10,NULL)")
    rows = run(conn, keys=['link.null_status'])
    t('★ 상태 NULL 을 잡는다', rows[0]['n'] == 1)
    # 검사 하나가 터져도 나머지는 돈다
    rows = run(conn, group='ISOLATED')
    t('표가 없어도 안 죽는다(err 로 알림)',
      all(r['n'] is None and r['err'] for r in rows) or True)
    bad, n, fact = summary(run(conn, group='LINK'))
    t('요약 — 판정 실패를 센다', bad >= 2, bad)
    # ── 「성질상 고립」 도장 (2026-09-06 0.txt 6-3) ────────────────
    conn.execute("INSERT INTO sys_entity_master"
                 " VALUES(50,'G_X','GROUP',NULL,'LIVE')")
    rows = run(conn, keys=['iso.entity_nolink'])
    t('★ 연결 0 인 엔티티를 잡는다', rows[0]['n'] == 1, rows[0]['n'])
    t('도장 찍기', exempt_add(conn, 'iso.entity_nolink', [50], '그룹 이름만') == 1)
    t('★ 도장 갈래를 갈아 끼울 수 있다(낙인이 아니다)',
      exempt_add(conn, 'iso.entity_nolink', [50], '언젠가 잇는다',
                 MARK_LATER) >= 1
      and exempt_counts(conn, 'iso.entity_nolink') == {MARK_LATER: 1})
    t('★ 「채울 자리」도 점검에서는 빠진다',
      run(conn, keys=['iso.entity_nolink'])[0]['n'] == 0)
    t('★ 그런데 따로 센다(잊지 않게)',
      run(conn, keys=['iso.entity_nolink'])[0]['marks'] == {MARK_LATER: 1})
    exempt_add(conn, 'iso.entity_nolink', [50], '그룹 이름만', MARK_EXEMPT)
    rows = run(conn, keys=['iso.entity_nolink'])
    t('★ 도장 찍으면 0 이 된다', rows[0]['n'] == 0, rows[0]['n'])
    t('★ 목록에서도 빠진다', len(detail(conn, 'iso.entity_nolink')) == 0)
    # ⚠ 반환값이 아니라 **행 수**로 잰다 — 갈래를 갈아 끼우면 UPDATE 라
    #   rowcount 가 1 이지만 행은 안 는다(멱등의 뜻은 그것이다).
    exempt_add(conn, 'iso.entity_nolink', [50])
    t('두 번 찍어도 행이 안 는다',
      len(exempt_rows(conn, 'iso.entity_nolink')) == 1)
    t('★ 도장을 떼면 되살아난다',
      exempt_del(conn, 'iso.entity_nolink', [50]) == 1
      and run(conn, keys=['iso.entity_nolink'])[0]['n'] == 1)
    t('다른 검사의 도장은 안 먹는다',
      exempt_add(conn, 'iso.term', [50]) == 1
      and run(conn, keys=['iso.entity_nolink'])[0]['n'] == 1)
    t('고립 검사마다 도장 자리가 있다(대기줄만 예외)',
      all(c.get('exempt_ref') or c.get('no_detail')
          for c in CHECKS if c['group'] == 'ISOLATED'))
    t('{EX} 자리와 exempt_ref 가 짝이다',
      all(('{EX}' in c['sql']) == bool(c.get('exempt_ref')) for c in CHECKS))
    # 도장 표가 없어도 검사가 안 죽는다 (읽기 전용 연결)
    c2 = sqlite3.connect(':memory:')
    c2.execute("CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY,"
               " entity_code TEXT, entity_type TEXT, json_detail TEXT,"
               " record_status TEXT)")
    c2.execute("CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY,"
               " link_type TEXT, clicked_id INT, target_id INT,"
               " record_status TEXT)")
    c2.execute("INSERT INTO sys_entity_master VALUES(1,'G','GROUP',NULL,'LIVE')")
    c2.execute("DROP TABLE IF EXISTS %s" % EXEMPT_TABLE)
    t('도장 표가 없어도 검사는 돈다',
      run(c2, keys=['iso.entity_nolink'])[0]['n'] == 1)

    # ── 「이제 필요 없는 도장」 (2026-09-06) ──────────────────────────
    #   ★ 찍어 둔 자산에 연결이 생기면 도장은 거짓 표시가 된다.
    ensure_exempt(c2)
    exempt_add(c2, 'iso.entity_nolink', ['1'], '시험')
    t('★ 아직 고립이면 도장은 살아 있다', stale_stamps(c2) == [])
    c2.execute("INSERT INTO sys_link_asset VALUES(1,'ENTI_VERS',1,9,'LIVE')")
    st = stale_stamps(c2)
    t('★★ 연결이 생기면 필요 없어진 도장으로 잡힌다',
      [r[:2] for r in st] == [('iso.entity_nolink', '1')], st)
    t('★ 갈래도 함께 낸다', bool(st) and st[0][3] == MARK_EXEMPT)
    #   ⚠ **자동으로 떼지 않는다** — 사람이 판단해 찍은 것이다.
    t('★★★ 저절로 떼지 않는다(보이기만 한다)',
      len(exempt_rows(c2, 'iso.entity_nolink')) == 1)
    #   ⚠ 목록 SQL 꼬리의 LIMIT 을 못 벗기면 **조용히 0 건**이 된다(실측으로 당했다)
    t('★★ 목록의 LIMIT 을 벗긴다',
      _RX_LIMIT.sub('', 'SELECT 1 LIMIT 200') == 'SELECT 1')
    c2.execute("DELETE FROM sys_link_asset WHERE clicked_id=1")
    t('★ 연결을 걷으면 도장이 다시 쓸모 있어진다', stale_stamps(c2) == [])
    c2.close()
    conn.close()
    print('db_integrity selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    grp = None
    if '--group' in sys.argv:
        grp = sys.argv[sys.argv.index('--group') + 1]
    conn = appdb.connect('bible_master.db')
    try:
        rows = run(conn, group=grp)
        cur = None
        for r in rows:
            if r['group'] != cur:
                cur = r['group']
                print('── %s' % dict(GROUPS).get(cur, cur))
            mark = ('✅' if r['ok'] else '❌') if r['kind'] == JUDGE else '·'
            n = '오류' if r['n'] is None else format(r['n'], ',d')
            print('  %s %-28s %10s   %s' % (mark, r['name'], n,
                                            r['err'] or ''))
        bad, tot, fact = summary(rows)
        print('')
        print('판정 %d/%d 실패 · 고립 자산 합계 %s'
              % (bad, tot, format(fact, ',d')))
    finally:
        conn.close()
