# -*- coding: utf-8 -*-
"""db_room_e2e.py — 공동체 묵상 **종단 시험**(영구, 2026-09-08).

사용자 지시 「코딩 끝나고 **처음부터 모든 프로세스를 실제처럼** 테스트하자」.

PC 셋(방장 김전도사 · 부방장 이집사 · 참여자 박청년)을 **각각의 user_data 와
각각의 방 파일 폴더**로 흉내 내고, 사이에 **공유 폴더 하나**(드라이브 동기화
폴더의 자리)를 둔다. 본체 DB 는 **실제 `bible_master.db`** 를 읽는다(플랜·구절이
진짜라야 시험이 뜻이 있다). 실제 화면 클래스(`RoomView`·`RoomMediView`·
`RoomAdminWin`·`_NewRoomDialog`·`_PostEdit`·`_NoticeEdit`)를 띄워 **단추가 하는
일을 그대로** 밟는다 — 데이터 층만 부르면 화면의 배선 결함을 못 본다.

⚠ **실 사용자 데이터를 안 건드린다** — `appdb.connect` 를 갈아 끼워 임시
  user DB 를 붙이고, 실 `user_data.db` 는 열지 않는다. 방장 연락처를 적지
  않으므로 등록 신고(실서버 전송)도 안 나간다.
⚠ 취소 목록 단계만 실 `sys_config` 에 한 줄을 넣었다가 **반드시 걷는다**
  (`finally`). 그 표는 감사 대상이 아니라 그 열쇠 하나만 확인한다.
⚠ 상자(messagebox·filedialog·simpledialog)는 전부 막는다 — 하나라도 뜨면
  시험이 멈춘다(§203차 ㉞ 그 함정).

사용:  python db_room_e2e.py
"""
import io
import os
import sys
import json
import shutil
import sqlite3
import tempfile
import time
import tkinter as tk
from datetime import date, timedelta

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
MAIN = os.path.join(HERE, 'bible_master.db')
REAL_USER = os.path.join(HERE, 'user_data.db')
PLAN = 'DIAG_ANXIETY_TRUST'      # 7일짜리 배포 플랜 — 훈련 한 기수의 흉내로 알맞다


def _out(s):
    os.write(1, (s + '\n').encode('utf-8', 'replace'))


class PC:
    """PC 하나 = 이름 · 자기 폴더(user DB + 방 파일) · `db_path`(폴더 자리표)."""

    def __init__(self, root_dir, tag, name):
        self.tag, self.name = tag, name
        self.dir = os.path.join(root_dir, 'pc_' + tag)
        os.makedirs(self.dir)
        self.udb = os.path.join(self.dir, 'user_data.db')
        self.db_path = os.path.join(self.dir, 'bible_master.db')   # dirname 만 쓴다
        self._make_user_db()
        self.opened = []

    def _make_user_db(self):
        src = sqlite3.connect(REAL_USER)
        ddl = {n: s for n, s in src.execute(
            "SELECT name, sql FROM sqlite_master WHERE type='table' AND name IN "
            "('user_text_asset','user_config','user_plan_enrollment','user_favorite',"
            "'user_room','user_link_asset','user_ref_asset')")}
        src.close()
        c = sqlite3.connect(self.udb)
        for n, s in ddl.items():
            c.execute(s)
        c.commit()
        c.close()

    def connect(self, *_a, **_k):
        c = sqlite3.connect(MAIN)
        c.execute("ATTACH DATABASE ? AS userdb", (self.udb,))
        self.opened.append(c)
        return c

    def close_all(self):
        for c in self.opened:
            try:
                c.close()
            except Exception:
                pass
        self.opened = []


def run():
    ok = [0, 0]
    steps = []

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        steps.append((cond, nm, got))
        _out('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got if not cond else ''))

    import appdb
    import room_core as RC
    import room_share as RS
    import room_view as RV
    import room_medi_view as RMV
    import room_admin_view as RAV
    import tkinter.messagebox as MB
    import tkinter.filedialog as FD
    import tkinter.simpledialog as SD

    errs = []
    root = tk.Tk()
    root.withdraw()
    tk.Tk.report_callback_exception = lambda s, e, v, tb: errs.append('%s: %s' % (e.__name__, v))
    d = tempfile.mkdtemp(prefix='room_e2e_')
    drive = os.path.join(d, 'drive')          # 공유 폴더 = 동기화 폴더의 자리
    os.makedirs(drive)
    box = {'file_open': '', 'file_save': '', 'name': '', 'yes': True}
    _orig = (appdb.connect, MB.showinfo, MB.showerror, MB.showwarning, MB.askyesno,
             FD.askopenfilename, FD.asksaveasfilename, SD.askstring, os.startfile)
    MB.showinfo = lambda *a, **k: None
    MB.showwarning = lambda *a, **k: None
    MB.showerror = lambda *a, **k: errs.append('showerror: %s' % (a[1:2],))
    MB.askyesno = lambda *a, **k: box['yes']
    FD.askopenfilename = lambda *a, **k: box['file_open']
    FD.asksaveasfilename = lambda *a, **k: box['file_save']
    SD.askstring = lambda *a, **k: box['name']
    opened_files = []
    os.startfile = lambda p, *a, **k: opened_files.append(p)

    main0 = sqlite3.connect(MAIN)
    sys_counts = {n: main0.execute('SELECT COUNT(*) FROM %s' % n).fetchone()[0]
                  for n in ('sys_text_asset', 'sys_link_asset', 'sys_bible_plan',
                            'user_room' if False else 'sys_config')}
    blk0 = main0.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                         (RC.BLOCK_KEY,)).fetchone()
    main0.close()
    real_user_mtime = os.path.getmtime(REAL_USER)
    stray_before = set(n for n in os.listdir(HERE) if n.startswith('room_') and n.endswith('.db'))

    lead = PC(d, 'lead', '김전도사')
    co = PC(d, 'co', '이집사')
    mem = PC(d, 'mem', '박청년')

    def use(pc):
        appdb.connect = pc.connect
        # ⚠ 세 PC 가 한 프로세스라 클래스 공유 억제(같은 방 10분)가 걸린다 —
        #   실제로는 PC 마다 프로세스가 달라 억제도 따로다. 여기서만 비운다.
        RMV.RoomMediView._pulled_at.clear()

    today = date.today()
    try:
        # ── 1. 방장: 방 만들기(대화상자) ──────────────────────────────────
        use(lead)
        rv = RV.RoomView(root, lead.db_path)
        rv.pack()
        root.update()
        dlg = RV._NewRoomDialog(rv, lead.db_path, lambda: 'KO', rv.reload)
        dlg._name_var.set('묵상훈련_2026_1기')
        dlg._leader.set('김전도사')
        dlg._agree.set(True)
        dlg._sync()
        dlg._ok()                      # 연락처 없음 → 등록 신고는 안 나간다
        root.update()
        with lead.connect() as c:
            rooms = RC.rooms(c)
        t('1 방장이 [방 만들기]로 방을 연다(책임 선언 동의)', len(rooms) == 1
          and rooms[0]['my_role'] == 'LEADER', rooms)
        rid = rooms[0]['room_id']
        rv.reload()
        root.update()
        rv._tv.selection_set(rid)
        rv._on_pick()
        t('   설정 ▸ 내 공동체 목록에 방장으로 뜬다', rv._sel and rv._sel['room_id'] == rid)

        # ── 2. 방장: 폴더 하나 ───────────────────────────────────────────
        rv._fold.set(drive)
        rv._save_folders()
        root.update()
        with lead.connect() as c:
            t('2 방 폴더를 정한다(하나)', RC.folder_of(RC.room(c, rid)) == drive)

        # ── 3. 방장: 방 관리 — 플랜 · 시작일 · 지침+교재 ──────────────────
        w = RAV.open_room_admin(rv, lead.db_path, rid, lambda: 'KO', rv.reload)
        root.update()
        t('3 [방 관리] 창이 방장에게 열린다', w is not None and w.winfo_exists())
        w._plan_var.set([n for c_, n in w._plans if c_ == PLAN][0])
        w._save_plan()
        start = (today - timedelta(days=2)).isoformat()
        w._start_var.set(start)
        w._save_start()
        root.update()
        with lead.connect() as c:
            r = RC.room(c, rid)
        t('   플랜과 시작일(그제)을 정한다', r['plan_code'] == PLAN and r['plan_start'] == start)
        t('   오늘 = 3일차', RC.today_day(r) == 3, RC.today_day(r))
        mat = os.path.join(d, '제자훈련_교재.txt')
        io.open(mat, 'w', encoding='utf-8').write('제자훈련 교재 본문')
        box['file_open'] = mat
        w._add_file()
        w._kind_var.set(RAV.kind_name('GUIDE'))
        w._body.insert('1.0', '이번 훈련의 지침입니다. 날마다 그 날 몫을 읽고 한 편씩 남깁니다.')
        w._save_post()
        root.update()
        files = os.listdir(drive)
        t('   지침 글이 교재 첨부와 함께 저절로 올라간다(공유 폴더에 방장 파일·교재)',
          any(f.startswith('note_') for f in files) and any(f.startswith('file_') for f in files),
          files)
        w._kind_var.set(RAV.kind_name('GREET'))
        w._body.insert('1.0', '반갑습니다. 서로 인사부터 나눕시다.')
        w._save_post()

        # ── 4. 방장: 초대 파일 ───────────────────────────────────────────
        inv = os.path.join(d, '초대.hagah')
        box['file_save'] = inv
        w._invite()
        t('4 초대 파일을 만든다', os.path.exists(inv))

        # ── 5. 부방장·참여자 PC: 초대 파일로 참여 ──────────────────────────
        views = {}
        for pc in (co, mem):
            use(pc)
            v = RV.RoomView(root, pc.db_path)
            v.pack()
            root.update()
            box['file_open'] = inv
            box['name'] = pc.name
            v._join()
            root.update()
            with pc.connect() as c:
                rr = RC.room(c, rid)
            t('5 %s 이(가) 초대 파일로 참여한다(플랜·시작일·폴더가 따라온다)' % pc.name,
              rr and rr['my_role'] == 'MEMBER' and rr['plan_code'] == PLAN
              and rr['plan_start'] == start and RC.folder_of(rr) == drive, rr)
            views[pc.tag] = v

        # ── 6. 참여자: 함께 묵상 — 저절로 받기 · 게시판 · 오늘 ────────────
        use(mem)
        mv = RMV.RoomMediView(root, mem.db_path)
        mv.pack()
        root.update()
        mv.reload()
        root.update()
        t('6 함께 묵상에 방이 뜨고 방 플랜이 맨 앞·기본이다',
          mv._room and mv._room['room_id'] == rid and '방 플랜' in mv._plan_var.get(),
          mv._plan_var.get())
        t('   오늘 = 3일차(방장 시작일 기준 · 등록 안 했어도)', mv._day == 3, mv._day)
        t('   탭에 들어오며 저절로 받았다(동기화 시각)', '동기화' in mv._sync_var.get())
        t('   그 날 몫이 진짜 구절 범위다', '~' in mv._span_var.get() or ':' in mv._span_var.get(),
          mv._span_var.get())
        t('   참여자에게는 [방 관리]가 없다', mv._adm_btn.winfo_manager() != 'pack')
        mv._toggle_board()
        root.update()
        kinds = [p['kind'] for p in mv._posts]
        t('   게시판에 방장의 인사·지침이 왔다', 'GUIDE' in kinds and 'GREET' in kinds, kinds)
        guide = next(p for p in mv._posts if p['kind'] == 'GUIDE')
        mv._open_attach(guide['files'][0])
        t('   첨부 교재가 앱 안 [열기]로 열린다(드라이브에 안 들어간다)',
          opened_files and opened_files[-1].startswith(drive), opened_files)
        pe = RMV._PostEdit(mv, mem.db_path, mv._room, lambda: 'KO', mv._draw_board)
        t('   참여자 글쓰기에 지침·마무리 갈래가 없다',
          all(c_ not in ('GUIDE', 'CLOSE') for c_, _n in pe._kinds))
        pe._txt.insert('1.0', '안녕하세요, 박청년입니다.')
        pe._save()
        root.update()
        mv._toggle_board()
        # 내 묵상 — 3일차 · 구절 연결 · 저장하면 저절로 올라간다
        mv._txt.insert('1.0', '오늘 읽은 범위 전체에 대한 묵상입니다.')
        mv._save()
        root.update()
        s_, e_ = mv._span
        mv._on_picked(s_)
        root.update()
        with mem.connect() as c:
            mine = RS.note_of_day(c, rid, PLAN, 3)
        t('   3일차 묵상을 쓰고 구절을 붙였다', mine and mine['clicked_id'] == s_, mine)
        t('   저장하자 참여자 파일이 공유 폴더에 올라갔다',
          any(f.startswith('note_') and f.endswith('.json') for f in os.listdir(drive))
          and len([f for f in os.listdir(drive) if f.startswith('note_')]) >= 2)

        # ── 7. 방장: 받아서 현황 · 부방장 지정 ───────────────────────────
        use(lead)
        w._pull()
        root.update()
        rows = {w._tv.item(i, 'values')[0]: w._tv.item(i, 'values') for i in w._tv.get_children()}
        t('7 방장 현황에 박청년이 뜬다(쓴 날 1/3 · 인사 ●)',
          '박청년' in rows and rows['박청년'][2] == '1 / 3' and rows['박청년'][6] == '●', rows)
        # 이집사는 아직 파일을 안 올렸다 → 목록에 없다(화면이 그 사실을 적는다)
        t('   아직 파일을 안 올린 이집사는 목록에 없다(받아 둔 파일이 재료)', '이집사' not in rows)
        use(co)
        cv = RMV.RoomMediView(root, co.db_path)
        cv.pack()
        root.update()
        cv.reload()
        cv._txt.insert('1.0', '이집사의 3일차 묵상')
        cv._save()
        root.update()
        use(lead)
        w._pull()
        root.update()
        rows = {w._tv.item(i, 'values')[0]: w._tv.item(i, 'values') for i in w._tv.get_children()}
        t('   이집사가 올리자 현황에 들어온다', '이집사' in rows, list(rows))
        co_uuid = next(x['member_id'] for x in w._stat_rows if x['name'] == '이집사')
        w._tv.selection_set(co_uuid)
        w._co(True)
        root.update()
        rows = {w._tv.item(i, 'values')[0]: w._tv.item(i, 'values') for i in w._tv.get_children()}
        t('   [부방장 지정] — 역할 칸에 부방장', rows['이집사'][1] == '부방장', rows['이집사'])

        # ── 8. 부방장 PC: 역할이 바뀌고 방 관리가 열린다 · 공지 ─────────────
        use(co)
        cv.reload()      # 저절로 받는다 → 방장 파일의 부방장 목록
        root.update()
        t('8 이집사 앱이 부방장 역할을 받아 [방 관리]가 생긴다',
          cv._room['my_role'] == 'CO_LEADER' and cv._adm_btn.winfo_manager() == 'pack',
          cv._room['my_role'])
        cw = RAV.open_room_admin(cv, co.db_path, rid, lambda: 'KO', cv.reload)
        root.update()
        t('   부방장 방 관리 창 — 방장 전용 단추가 잠겨 있다',
          cw is not None and 'disabled' in cw._btn_rename.state()
          and 'disabled' in cw._btn_co.state() and 'disabled' in cw._btn_plan.state())
        ne = RMV._NoticeEdit(cv, co.db_path, rid, None, cv._render)
        ne._txt.insert('1.0', '이번 주는 5일차까지 읽습니다 — 부방장 이집사')
        ne._save()
        root.update()
        cw._kind_var.set(RAV.kind_name('GUIDE'))
        cw._body.insert('1.0', '부방장이 덧붙이는 지침입니다.')
        cw._save_post()         # 조용히 올라간다
        root.update()
        cw.destroy()

        # ── 9. 참여자: 공지·부방장 지침이 도착 ─────────────────────────────
        use(mem)
        mv.reload()
        root.update()
        t('9 참여자 공지 띠에 부방장의 공지가 뜬다', '5일차' in mv._nt_lbl.cget('text'),
          mv._nt_lbl.cget('text'))
        t('   부방장의 지침이 「지침」으로 온다(평글로 안 내려간다)',
          any(p['kind'] == 'GUIDE' and '부방장' in p['contents'] and p.get('co')
              for p in mv._posts), [(p['kind'], p['contents'][:10]) for p in mv._posts])
        # 진도 — 누가 안 썼나
        t('   진도 줄에 쓴 사람이 보인다', '쓴 사람' in mv._who.get(), mv._who.get())

        # ── 10. 방장: 가리기 → 참여자 화면에서 사라짐 → 되살림 ────────────
        use(lead)
        w._pull()
        root.update()
        mem_uuid = next(x['member_id'] for x in w._stat_rows if x['name'] == '박청년')
        w._tv.selection_set(mem_uuid)
        w._hide(True)
        root.update()
        use(co)
        cv.reload()
        root.update()
        t('10 방장이 가리자 부방장 화면에서도 박청년 글이 사라진다',
          not any(x['name'] == '박청년' for x in RS.notes_of_day(
              co.connect(), rid, PLAN, 3, co.db_path)))
        use(lead)
        w._tv.selection_set(mem_uuid)
        w._hide(False)
        w._pull()
        root.update()
        use(co)
        cv.reload()
        root.update()
        t('   되살리면 다음 받기에 돌아온다',
          any(x['name'] == '박청년' for x in RS.notes_of_day(
              co.connect(), rid, PLAN, 3, co.db_path)))

        # ── 11. 며칠 뒤 — 마무리 · 수료 명단 ───────────────────────────────
        use(mem)
        for day in (1, 2):
            with mem.connect() as c:
                RS.save_note(c, rid, PLAN, day, '%d일차 묵상(늦게 씀)' % day)
        mv._auto_push()
        use(lead)
        w._pull()
        w._thr_var.set(80)
        w._fill_stats()
        rows = {w._tv.item(i, 'values')[0]: w._tv.item(i, 'values') for i in w._tv.get_children()}
        t('11 박청년 3/3 · 100% · 수료 ● / 이집사 1/3 · 33% · 수료 없음',
          rows['박청년'][2] == '3 / 3' and rows['박청년'][4] == '●'
          and rows['이집사'][2] == '1 / 3' and rows['이집사'][4] == '', rows)
        grad = os.path.join(d, '수료.txt')
        box['file_save'] = grad
        w._save_grad()
        t('   수료 명단 파일', os.path.exists(grad)
          and '박청년' in io.open(grad, encoding='utf-8').read())
        time.sleep(1.1)      # 게시판은 초 단위 시각순 — 앞 글과 같은 초에 쓰면 차례가 뜻이 없다
        w._kind_var.set(RAV.kind_name('CLOSE'))
        w._body.insert('1.0', '수고 많으셨습니다. 마지막 인사입니다.')
        w._save_post()
        w._toggle_close()
        root.update()
        use(mem)
        mv.reload()
        root.update()
        t('   참여자 화면에 「마무리됨」 띠, 재촉 줄 없음',
          '마무리' in mv._st_lbl.cget('text') and mv._who.get() == '',
          (mv._st_lbl.cget('text')[:20], mv._who.get(), mv._room.get('room_status'),
           [json.load(io.open(os.path.join(drive, f), encoding='utf-8')).get('room_status')
            for f in os.listdir(drive) if f.startswith('note_')]))
        mv._toggle_board()
        root.update()
        t('   마무리 인사가 게시판 맨 아래(시간순)', mv._posts and mv._posts[-1]['kind'] == 'CLOSE',
          [p['kind'] for p in mv._posts])
        mv._toggle_board()

        # ── 12. 다음 기수 — 이름만 바꾼다 ────────────────────────────────
        use(lead)
        w._toggle_close()          # 다시 열기
        w._name_var.set('묵상훈련_2027_1기')
        w._rename()
        root.update()
        use(mem)
        mv.reload()
        root.update()
        t('12 방 이름을 바꾸면 참여자 앱도 따라온다(초대 재발행 없이 · 글은 그대로)',
          mv._room['room_name'] == '묵상훈련_2027_1기'
          and RS.note_of_day(mem.connect(), rid, PLAN, 3) is not None, mv._room['room_name'])

        # ── 13. 최종관리자 취소 목록 ─────────────────────────────────────
        import db_room_block as RB
        mc = sqlite3.connect(MAIN)
        try:
            RB.add(mc, rid, '시험용 차단 사유')
            mc.close()
            mv.reload()
            root.update()
            t('13 취소 목록에 오르면 참여자 화면에 사유 띠 + 올리기 거부',
              '시험용 차단 사유' in mv._st_lbl.cget('text') and mv._stop_if_blocked())
        finally:
            mc = sqlite3.connect(MAIN)
            if blk0 and blk0[0]:
                mc.execute("UPDATE sys_config SET config_val=? WHERE config_key=?",
                           (blk0[0], RC.BLOCK_KEY))
            else:
                # 원래 없던 열쇠다 — `remove` 가 남기는 빈 `{}` 행까지 걷는다
                mc.execute("DELETE FROM sys_config WHERE config_key=?", (RC.BLOCK_KEY,))
            mc.commit()
            mc.close()
        mv.reload()
        root.update()
        t('   목록에서 빼면 띠가 걷힌다', mv._st_lbl.winfo_manager() != 'pack')

        # ── 14. 방장: 방 지우기 — 다른 PC 는 그대로 ──────────────────────
        use(lead)
        w._delete()
        root.update()
        with lead.connect() as c:
            t('14 방장이 방을 지우면 방장 PC 에서만 사라진다', RC.room(c, rid) is None)
        with mem.connect() as c:
            t('   참여자 PC 의 방·글은 그대로', RC.room(c, rid) is not None
              and RS.note_of_day(c, rid, PLAN, 3) is not None)

        t('Tk 오류 0', not errs, errs[:3])
    finally:
        (appdb.connect, MB.showinfo, MB.showerror, MB.showwarning, MB.askyesno,
         FD.askopenfilename, FD.asksaveasfilename, SD.askstring, os.startfile) = _orig
        try:
            root.destroy()
        except Exception:
            pass
        for pc in (lead, co, mem):
            pc.close_all()
        shutil.rmtree(d, ignore_errors=True)

    # ── 불변 — 실 DB·실 사용자 데이터·앱 폴더 ────────────────────────────
    main1 = sqlite3.connect(MAIN)
    after = {n: main1.execute('SELECT COUNT(*) FROM %s' % n).fetchone()[0] for n in sys_counts}
    blk1 = main1.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                         (RC.BLOCK_KEY,)).fetchone()
    main1.close()
    t('실 bible_master.db 행수 불변', after == sys_counts, (sys_counts, after))
    t('실 sys_config 취소 목록 원복', (blk1 or [None])[0] == (blk0 or [None])[0])
    t('실 user_data.db 를 안 건드렸다', os.path.getmtime(REAL_USER) == real_user_mtime)
    stray_after = set(n for n in os.listdir(HERE) if n.startswith('room_') and n.endswith('.db'))
    t('앱 폴더에 방 파일 잔재 0', stray_after == stray_before, stray_after - stray_before)
    t('임시 폴더 잔재 0', not os.path.exists(d))
    _out('db_room_e2e: %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    sys.exit(0 if run() else 1)
