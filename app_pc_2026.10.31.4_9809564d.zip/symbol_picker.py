# -*- coding: utf-8 -*-
"""symbol_picker.py — 글 쓰는 자리에 **기호를 눌러 넣는다** (영구 부품 · `--selftest` 의무)
================================================================================

사용자 지시(2026-08-23):
  「수정 버튼 아래에 편리한 이모지 버튼 배치. 수작업으로 이모지를 배치하기
    어려울 때 필요하다」  → 매뉴얼 팝업
  「연구자료/묵상노트 추가작성 또는 수정할 때에도 표시하라. 묵상노트 화면에
    한줄로 배치하면 공간이 좁으므로 버튼 배치하고 클릭하면 Recent 클릭할 때
    표시되는 방식으로 표시해라」  → 좁은 자리는 단추 + 드롭다운
  2차: 「화면 바깥에 배치되는 기호들이 있다(P2 오른쪽·P4 아래쪽) / 드래그되고
    직전 위치값 저장 / **하나 클릭하면 사라지고 있다. 닫기 전에는 유지** /
    크기는 인식할 수만 있다면 더 작게」

붙이는 법 — **모양은 하나**(단추 + 드롭다운). 네 자리가 같은 판을 쓴다.
    import symbol_picker
    symbol_picker.button(parent, lambda: self.txt, db_path=DB).pack(...)
⚠ 처음에는 넓은 자리(매뉴얼 팝업)용으로 「한 줄로 쫙」 늘어놓는 `row()` 를 따로
  두었는데 **36자가 1119px 이라 600px 창을 넘었다**(실측). 사용자가 드롭다운에서
  지적한 「화면 바깥에 배치되는 기호들이 있다」와 같은 사고다 ⇒ **모양을 하나로.**

★ **대상은 위젯이 아니라 「위젯을 주는 함수」로 받는다** — 글칸을 다시 만드는
  화면이 있어(연구자료 폼·묵상노트 카드) 위젯을 붙들면 죽은 것을 가리킨다.

★★ **이모지가 아니라 「기호」다.** 사용자 요청은 「이모지 버튼」이었으나 이 앱은
  두 가지를 이미 겪었다:
   ① 컬러 이모지는 첫 렌더에 Segoe UI Emoji 를 끌어와 ~0.6초가 걸린다(§29)
   ② **글꼴에 없는 글자를 넣으면 다른 PC 에서 네모로 뜬다** — `➔`(§54)·`🄼`(§66)
  ⇒ **cmap 으로 보유를 확인한 것만** 담는다. 「추가 이모지 고르기」는 두지
    않는다 — 고른 글자가 깨지면 사용자가 쓴 글이 고장난 것으로 보인다.
⚠⚠ 아래 목록은 **맑은 고딕·굴림·바탕 세 글꼴 모두 보유**를 실측한 것이다.
  **글자를 더하면 `--selftest` 가 그 자리에서 잡는다** — 실측을 건너뛸 수 없다.

⚠ 색은 전부 `ui_theme` 역할이고 **그릴 때마다** 읽는다. 드롭다운은
  `overrideredirect` 창이라 `ui_theme.paint` 가 영영 못 닿는다(§36-5b) —
  M 버튼 쪽지가 크림색으로 굳어 있던 것이 그 사고다.
"""

import os
import sys
import tkinter as tk

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

# ── 기호 목록 (묶음 이름, 글자들) ────────────────────────────────────────────
#   묶음은 **뜻**으로 나눈다 — 눈으로 찾는 시간을 줄인다.
GROUPS = (
    ('표식', '○ ● ◐ ★ ☆ ♥ ♡ ◈ ◆ ◇ ■ □'),
    ('방향', '→ ⇒ ◀ ▶ ▲ ▼ ‹ › « » ◁ ▷'),
    ('구분', '※ · ∙ ‥ … ─ │ ┌ ┐ └ ┘ ×'),
)

# 글꼴 보유를 재는 대상 — 앱이 실제로 쓰는 한글 글꼴
_CHECK_FONTS = ('malgun.ttf', 'gulim.ttc', 'batang.ttc')

_POS_KEY = 'SYMBOL_POP_XY'          # user_config — 판을 마지막으로 둔 자리


def symbols():
    """[글자] — 묶음을 편 것."""
    return [ch for _n, g in GROUPS for ch in g.split()]


def _C(role, fallback):
    try:
        import ui_theme
        return ui_theme.C(role) or fallback
    except Exception:
        return fallback


def _cfg_get(db, key):
    if not db:
        return None
    try:
        import appdb
        with appdb.connect(db) as c:
            r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                          (key,)).fetchone()
        return r[0] if r else None
    except Exception:
        return None


def _cfg_set(db, key, val):
    if not db:
        return
    try:
        import appdb
        with appdb.connect(db) as c:
            c.execute("INSERT OR REPLACE INTO user_config(config_key, config_val) "
                      "VALUES (?,?)", (key, val))
            c.commit()
    except Exception as e:
        print('[symbol_picker] %s' % e)


def _resolve(target):
    """`target` 은 위젯이거나 위젯을 주는 함수다 → 살아 있는 위젯 또는 None."""
    w = target() if callable(target) else target
    try:
        if w is not None and w.winfo_exists():
            return w
    except Exception:
        pass
    return None


def insert(target, ch):
    """커서 자리에 끼운다. 대상이 없거나 잠겨 있으면 조용히 아무 일도 안 한다."""
    w = _resolve(target)
    if w is None:
        return False
    try:
        if str(w.cget('state')) == 'disabled':
            return False
    except Exception:
        pass
    try:
        w.insert('insert', ch)
        w.focus_set()
        return True
    except Exception as e:
        print('[symbol_picker] %s' % e)
        return False


# ── 단추 + 드롭다운 ────────────────────────────────────────────
class _Drop:
    """단추 아래로 펼치는 기호판.

    ★★ **닫기 전에는 유지된다** (2026-08-23 사용자 「하나 클릭하면 사라지고
      있다. 닫기 전에는 유지되도록 하라」). 처음에는 Recent 팝업을 본떠 **고르면
      닫았는데**, 기호는 여러 개를 잇달아 넣는 일이 많아 그때마다 다시 열어야
      했다. ⇒ 고르면 **넣기만** 한다. 닫는 길은 `×` · `Esc` · 단추 다시 누르기.

    ★★ **화면 밖으로 안 나간다** (사용자 「P2 에서 오른쪽이 안 보임, P4 에서
      아래쪽이 살짝 안 보임」). 단추 바로 아래에 그냥 놓으면 가장자리를 넘는다
      — **판 크기를 재고 화면 안으로 끌어당긴다.**
      ⚠ 크기를 재려면 `update_idletasks()` **뒤**라야 한다(그 전에는 1×1).

    ★ **끌어서 옮기고 그 자리를 기억한다** (사용자 요청). 머리 띠를 잡고 끈다.
      자리는 `user_config['SYMBOL_POP_XY']` — **화면 좌표**다.
      ⚠ 저장된 자리가 지금 화면 밖이면(모니터·해상도가 달라졌다) **버리고
        단추 아래로** 돌아간다. 안 그러면 판이 안 보이는 곳에 뜬다.

    ★★ **`on_open`/`on_close` 가 왜 필요한가** (실측):
      판은 **딴 창**이라 열리는 순간 글칸이 `<FocusOut>` 을 받는다. 묵상노트는
      그 신호로 **자동 저장**을 하고, 저장은 목록을 다시 그리며 **글칸을 통째로
      새로 만든다**(`note_refr_panel._refresh_list`). 그러면 기호를 넣을 칸이
      이미 죽어 있다 — 오류도 안 나고 **글자만 조용히 사라진다.**
      ⇒ 판이 열려 있는 동안 그쪽이 자동 저장을 멈출 수 있게 알린다.
      ⚠ 부품이 남의 저장 로직을 알지 않는다 — **알리기만** 하고 판단은 그쪽이.
    """

    def __init__(self, btn, target, on_open=None, on_close=None, db_path=None):
        self.btn = btn
        self.target = target
        self.on_open = on_open
        self.on_close = on_close
        self.db_path = db_path
        self.pop = None
        self._drag = None
        btn.config(command=self.toggle)
        # 단추가 사라지면 열린 판도 함께 닫는다(떠 있는 창이 남지 않게)
        btn.bind('<Destroy>', lambda _e: self.close(), add='+')

    def _tell(self, cb):
        if cb is None:
            return
        try:
            cb()
        except Exception as e:
            print('[symbol_picker] %s' % e)

    def toggle(self):
        if self.pop is not None:
            self.close()
            return
        self.open()

    # ── 자리 ──────────────────────────────────────────────────────────────
    def _saved_xy(self):
        raw = _cfg_get(self.db_path, _POS_KEY)
        if not raw:
            return None
        try:
            x, y = [int(v) for v in str(raw).split(',')]
            return x, y
        except Exception:
            return None

    def _place(self, pop):
        """화면 안으로 끌어당겨 놓는다. 저장된 자리가 있으면 거기, 없으면 단추 아래."""
        pop.update_idletasks()
        w, h = pop.winfo_reqwidth(), pop.winfo_reqheight()
        sw, sh = pop.winfo_screenwidth(), pop.winfo_screenheight()
        xy = self._saved_xy()
        if xy and 0 <= xy[0] <= sw - 40 and 0 <= xy[1] <= sh - 40:
            x, y = xy
        else:
            b = self.btn
            x = b.winfo_rootx()
            y = b.winfo_rooty() + b.winfo_height() + 2
        # ⚠ 가장자리를 넘으면 안쪽으로 — 오른쪽·아래를 **둘 다** 본다
        x = max(0, min(x, sw - w - 4))
        y = max(0, min(y, sh - h - 4))
        pop.geometry('+%d+%d' % (x, y))

    def _drag_start(self, e):
        if self.pop is not None:
            self._drag = (e.x_root - self.pop.winfo_x(),
                          e.y_root - self.pop.winfo_y())

    def _drag_move(self, e):
        if not (self._drag and self.pop):
            return
        dx, dy = self._drag
        sw, sh = self.pop.winfo_screenwidth(), self.pop.winfo_screenheight()
        w, h = self.pop.winfo_width(), self.pop.winfo_height()
        x = max(0, min(e.x_root - dx, sw - w))
        y = max(0, min(e.y_root - dy, sh - h))
        self.pop.geometry('+%d+%d' % (x, y))

    def _drag_end(self, _e=None):
        self._drag = None
        self._remember()

    def _remember(self):
        if self.pop is None:
            return
        try:
            _cfg_set(self.db_path, _POS_KEY,
                     '%d,%d' % (self.pop.winfo_x(), self.pop.winfo_y()))
        except Exception:
            pass

    # ── 열고 닫기 ─────────────────────────────────────────────────────────
    def open(self):
        b = self.btn
        try:
            if not b.winfo_exists():
                return
        except Exception:
            return
        self._tell(self.on_open)          # ⚠ 창을 만들기 **전에** 알린다
        pop = tk.Toplevel(b)
        pop.overrideredirect(True)
        pop.attributes('-topmost', True)
        pop.configure(bg=_C('border', '#7F8C8D'))
        self.pop = pop
        pnl = _C('panel', '#FFFFFF')
        pnl2 = _C('panel_alt', '#F4F6F7')
        inner = tk.Frame(pop, bg=pnl)
        inner.pack(padx=1, pady=1, fill='both', expand=True)

        # 머리 띠 — 잡고 끄는 손잡이 + 닫기
        hdr = tk.Frame(inner, bg=pnl2, cursor='fleur')
        hdr.pack(fill='x')
        grip = tk.Label(hdr, text='···', bg=pnl2, fg=_C('fg_dim', '#7F8C8D'),
                        cursor='fleur')
        grip.pack(side='left', padx=(6, 0))
        # ⚠ `✕`(U+2715)는 맑은 고딕·굴림·바탕 **어디에도 없다** — `×`(U+00D7)로.
        tk.Button(hdr, text='×', bd=0, padx=5, pady=0, cursor='hand2',
                  bg=pnl2, fg=_C('fg_dim', '#7F8C8D'),
                  activebackground=_C('accent_bg', '#EAF2F8'),
                  command=self.close).pack(side='right', padx=(0, 2))
        for w in (hdr, grip):
            w.bind('<Button-1>', self._drag_start)
            w.bind('<B1-Motion>', self._drag_move)
            w.bind('<ButtonRelease-1>', self._drag_end)

        # ⚠ 단추를 **작게** — 사용자 「크기는 인식할 수만 있다면 더 작게」.
        #   글꼴 이름은 안 적는다(§36) — 여백만 줄인다.
        for name, group in GROUPS:
            line = tk.Frame(inner, bg=pnl)
            line.pack(fill='x', padx=3, pady=0)
            tk.Label(line, text=name, bg=pnl, fg=_C('fg_dim', '#7F8C8D'),
                     width=3, anchor='w').pack(side='left')
            for ch in group.split():
                tk.Button(line, text=ch, bd=1, relief='raised', padx=1, pady=0,
                          cursor='hand2', bg=pnl, fg=_C('fg', '#2C3E50'),
                          command=lambda c=ch: self._pick(c)).pack(side='left')
        self._place(pop)
        pop.bind('<Escape>', lambda _e: self.close())

    def _pick(self, ch):
        # ★ **닫지 않는다** — 잇달아 넣을 수 있어야 한다(사용자 지시).
        insert(self.target, ch)

    def close(self):
        pop, self.pop = self.pop, None
        if pop is None:
            return
        # 끌지 않고 그냥 닫아도 자리를 기억한다
        try:
            _cfg_set(self.db_path, _POS_KEY, '%d,%d' % (pop.winfo_x(), pop.winfo_y()))
        except Exception:
            pass
        try:
            pop.destroy()
        except Exception:
            pass
        self._tell(self.on_close)


def button(parent, target, text='기호', on_open=None, on_close=None,
           db_path=None, **kw):
    """기호 단추. 누르면 아래로 판이 펼쳐진다. 반환값 = 그 Button.

    `on_open`/`on_close` — 판이 열리고 닫힐 때 알린다. 글칸이 `<FocusOut>` 으로
    자동 저장·재렌더를 하는 화면(묵상노트)은 그 사이 저장을 멈춰야 한다.
    `db_path` — 주면 **판을 끌어 둔 자리를 기억한다**(`SYMBOL_POP_XY`).
    """
    opt = dict(bd=1, relief='raised', padx=6, pady=0, cursor='hand2',
               bg=_C('panel', '#FFFFFF'), fg=_C('fg', '#2C3E50'),
               activebackground=_C('panel_alt', '#E8E8E8'), activeforeground=_C('fg', '#2C3E50'))
    opt.update(kw)
    b = tk.Button(parent, text=text, **opt)
    b._symbol_drop = _Drop(b, target, on_open, on_close, db_path)  # 참조 붙들기
    return b


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def _font_ranges():
    """{글꼴 이름: [(시작, 끝)]} — 없는 글꼴은 건너뛴다."""
    import theme_font
    win = os.path.join(os.environ.get('WINDIR', 'C:/Windows'), 'Fonts')
    out = {}
    for fn in _CHECK_FONTS:
        p = os.path.join(win, fn)
        if not os.path.exists(p):
            continue
        try:
            out[fn] = theme_font._cmap_ranges(p)
        except Exception:
            pass
    return out


def _selftest():
    ok = fail = 0

    def t(name, cond, extra=''):
        nonlocal ok, fail
        if cond:
            ok += 1
        else:
            fail += 1
            print('  FAIL %s %s' % (name, extra))

    syms = symbols()
    t('기호가 있다', len(syms) >= 20, len(syms))
    t('겹치는 글자가 없다', len(syms) == len(set(syms)),
      [c for c in syms if syms.count(c) > 1])
    t('전부 한 글자', all(len(c) == 1 for c in syms))
    t('공백·줄바꿈이 안 섞였다', not any(c.isspace() for c in syms))

    # ★★ **이 검사가 이 파일의 핵심이다** — 글자를 더하면 여기서 걸린다.
    rng = _font_ranges()
    if not rng:
        print('  (건너뜀) 글꼴 파일을 못 찾음 — cmap 검사 불가')
    else:
        missing = []
        for ch in syms:
            cp = ord(ch)
            for fn, rs in rng.items():
                if not any(a <= cp <= b for a, b in rs):
                    missing.append((ch, fn))
        t('모든 기호가 %d개 글꼴에 다 있다' % len(rng), not missing, missing[:8])
        # 탐지력 — 없는 줄 아는 글자를 넣으면 잡아야 한다
        bad = [c for c in '✕✓✏' if any(
            not any(a <= ord(c) <= b for a, b in rs) for rs in rng.values())]
        t('탐지력 — ✕✓✏ 는 없는 것으로 잡힌다', len(bad) == 3, bad)
        # 이 파일이 화면에 그리는 글자(닫기 ×·손잡이 ···)도 있어야 한다
        t('닫기 × 와 손잡이 · 가 세 글꼴에 다 있다',
          all(any(a <= ord(c) <= b for a, b in rs)
              for c in '×·' for rs in rng.values()))

    # 화면 부품 — Tk 가 없는 자리에서는 건너뛴다
    try:
        root = tk.Tk()
        root.geometry('600x400')
    except Exception:
        print('  (건너뜀) Tk 없음')
        print('selftest %d/%d' % (ok, ok + fail))
        return fail == 0
    try:
        holder = tk.Frame(root)
        holder.pack()
        txt = tk.Text(holder)
        t('넣기', insert(lambda: txt, '★') and txt.get('1.0', 'end-1c') == '★')
        txt.config(state='disabled')
        t('잠긴 칸에는 안 넣는다', not insert(lambda: txt, '●'))
        txt.config(state='normal')
        dead = tk.Text(holder)
        dead.destroy()
        t('죽은 대상이면 조용히 넘어간다', not insert(lambda: dead, '●'))
        t('대상이 None 이어도 안 죽는다', not insert(lambda: None, '●'))

        # ── 드롭다운 (자리 기억은 db 없이 — user_config 를 안 건드린다) ──
        b = button(holder, lambda: txt)
        b.pack()
        root.update()
        d = b._symbol_drop
        t('처음엔 판이 닫혀 있다', d.pop is None)
        d.open()
        root.update()
        t('열린다', d.pop is not None)

        # ★ 고른 뒤에도 **닫히지 않는다**(사용자 지시)
        before = txt.get('1.0', 'end-1c')
        d._pick('→')
        t('선택하면 넣되 판은 그대로', d.pop is not None
          and txt.get('1.0', 'end-1c') == before + '→')
        d._pick('●')
        t('잇달아 넣을 수 있다', txt.get('1.0', 'end-1c') == before + '→●')

        # ★ 화면 밖으로 안 나간다
        pop = d.pop
        pop.update_idletasks()
        sw, sh = pop.winfo_screenwidth(), pop.winfo_screenheight()
        t('오른쪽이 화면 안', pop.winfo_x() + pop.winfo_reqwidth() <= sw,
          '%d+%d > %d' % (pop.winfo_x(), pop.winfo_reqwidth(), sw))
        t('아래쪽이 화면 안', pop.winfo_y() + pop.winfo_reqheight() <= sh,
          '%d+%d > %d' % (pop.winfo_y(), pop.winfo_reqheight(), sh))
        t('음수 자리가 아니다', pop.winfo_x() >= 0 and pop.winfo_y() >= 0)

        # ★ 화면 밖 좌표가 저장돼 있으면 **버린다**
        d2 = _Drop(tk.Button(holder), lambda: txt)
        d2._saved_xy = lambda: (99999, 99999)
        d2.btn.pack(); root.update()
        d2.open(); root.update()
        p2 = d2.pop
        t('말도 안 되는 저장 자리는 버린다',
          p2.winfo_x() + p2.winfo_reqwidth() <= sw
          and p2.winfo_y() + p2.winfo_reqheight() <= sh)
        d2.close()

        d.toggle()
        t('단추를 다시 누르면 닫힌다', d.pop is None)
        d.open(); root.update()
        b.destroy(); root.update()
        t('단추가 죽으면 판도 닫힌다', d.pop is None)
    finally:
        try:
            root.destroy()
        except Exception:
            pass

    print('selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    a = sys.argv[1:]
    if not a or a[0] == '--selftest':
        sys.exit(0 if _selftest() else 1)
    if a[0] == '--list':
        for name, g in GROUPS:
            print('%-5s %s' % (name, g))
        print('합계 %d자' % len(symbols()))
    else:
        print(__doc__)


if __name__ == '__main__':
    main()
