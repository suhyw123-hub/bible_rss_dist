"""AI 작업실 — **Batch(맡기기)** 엔진.

★ 2026-10-30 사용자 결정 — 「Pro low 를 선택하고 Batch 방식으로 처리하는 것이 최선」.
  · 값 = 바로 받는 것의 **절반**(Gemini 3.1 Pro 입력 $1 · 출력 $6 / 100만 토큰) — 묶어 보내기(생각이 준다) 위에 겹친다.
  · 한도 = 일반 호출과 **따로**(유료 1등급 Pro 「하루 250회」에 안 걸린다) · 대신 대기열 한도(모델마다 1등급 500만 토큰).
  · 결과 = 몇 분~24시간 · 48시간 안에 못 끝내면 만료 · 결과 파일은 6주 보관.
  문서: https://ai.google.dev/gemini-api/docs/batch-mode

흐름
  submit(conn, job_id, only)  — 선택한 건을 지금과 **같은 묶음**(db_ai_run.plan_batches)으로 만들어 요청 하나씩 ·
                                 대기열 한도를 넘는 몫은 `WAITING`(이 PC 의 줄)으로 두었다가 앞의 것이 끝나면 저절로 맡긴다.
  poll(conn)                  — 맡긴 일의 상태를 묻고, 끝난 것은 받아 **[전송하기]와 같은 문**으로 담는다
                                 (항목 나누기 → 건마다 게이트 → 「검수 대기」) · 못 나눈 묶음은 한 건씩 다시 맡긴다.
  cancel(conn, batch_id)      — 맡긴 일을 거두고 그 건들은 「대기」로.

건 상태 `QUEUED`(맡김) — `run_job` 은 PENDING·FAIL 만 집으므로 두 번 나가지 않는다.
⚠ 키·모델은 ai_client 그대로(유료 키 · 일별 설정 `task_model`·`task_think`).
"""
import json
import os
import sys
import time
import urllib.error
import urllib.request

APP = os.path.dirname(os.path.abspath(__file__))
if APP not in sys.path:
    sys.path.insert(0, APP)

import ai_client as AC          # noqa: E402
import db_ai_job as AJ          # noqa: E402
import db_ai_run as AR          # noqa: E402

BASE = 'https://generativelanguage.googleapis.com'
#: 한 번 맡길 때의 어림 토큰 상한 — 1등급 Pro 대기열 500만 토큰보다 넉넉히 아래(입력·출력 어림을 함께 센다)
CAP_TOKENS = 3500000
#: 요청 몸통이 이보다 크면 파일로 올린다(바로 담기 한도 20 MB)
INLINE_MAX = 15 * 1024 * 1024
ACTIVE = ('SUBMITTED', 'PENDING', 'RUNNING')

SCHEMA = """
CREATE TABLE IF NOT EXISTS sys_ai_batch (
    batch_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id      INTEGER NOT NULL,
    name        TEXT,              -- 구글 쪽 이름 batches/…(아직 안 맡겼으면 빈칸)
    model       TEXT,
    think       TEXT,
    state       TEXT,              -- WAITING · SUBMITTED · PENDING · RUNNING · SUCCEEDED · FAILED · CANCELLED · EXPIRED · DONE
    plan_json   TEXT,              -- [[열쇠, [건 번호…]] …]
    n_req       INTEGER, n_items INTEGER, est_tokens INTEGER,
    tok_in      INTEGER DEFAULT 0, tok_out INTEGER DEFAULT 0,
    why         TEXT,
    created_at  TEXT, updated_at TEXT
);
"""


def ensure(conn):
    AR.ensure(conn)
    conn.executescript(SCHEMA)
    # ★ 2026-10-31 오류 찾기도 Batch 로 — kind 'CHECK' 는 건의 상태를 안 바꾼다(글은 이미 받았다 · 결과는 check_json)
    if 'kind' not in [r[1] for r in conn.execute("PRAGMA table_info(sys_ai_batch)")]:
        conn.execute("ALTER TABLE sys_ai_batch ADD COLUMN kind TEXT DEFAULT ''")
    AR._ensure_check(conn)
    if 'QUEUED' not in AR.STATES:
        AR.STATES = AR.STATES + ('QUEUED',)
        AR.STATE_NAME['QUEUED'] = 'Batch 중'
    conn.commit()


# 상태 이름은 모듈을 읽는 순간 더한다(화면이 STATES 로 줄을 그린다)
if 'QUEUED' not in AR.STATES:
    AR.STATES = AR.STATES + ('QUEUED',)
    AR.STATE_NAME['QUEUED'] = 'Batch 중'

STATE_KO = {'WAITING': '차례 기다림', 'SUBMITTED': '보냄', 'PENDING': '구글 대기', 'RUNNING': '처리 중',
            'SUCCEEDED': '끝(받는 중)', 'DONE': '받음', 'FAILED': '실패', 'CANCELLED': '취소', 'EXPIRED': '만료'}


def _now():
    return AR._now()


# ── 망 ──────────────────────────────────────────────────────────────
def _http(method, url, body=None, headers=None, timeout=120, raw=False):
    data = None
    h = dict(headers or {})
    if body is not None:
        if isinstance(body, (bytes, bytearray)):
            data = bytes(body)
        else:
            data = json.dumps(body, ensure_ascii=False).encode('utf-8')
            h.setdefault('Content-Type', 'application/json; charset=utf-8')
    req = urllib.request.Request(url, data=data, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            b = r.read()
            return r.status, (b if raw else b.decode('utf-8', 'replace')), dict(r.headers)
    except urllib.error.HTTPError as e:
        try:
            b = e.read().decode('utf-8', 'replace')
        except Exception:                                 # noqa: BLE001
            b = ''
        return e.code, b, dict(e.headers or {})


class Net:
    """구글 Batch API — 시험은 이것을 가짜로 바꿔 끼운다"""

    def __init__(self, key):
        self.key = key

    def _u(self, path):
        return '%s/%s%skey=%s' % (BASE, path, '&' if '?' in path else '?', self.key)

    def create(self, model, display, requests=None, file_name=None):
        cfg = {'requests': {'requests': requests}} if requests is not None else {'file_name': file_name}
        code, b, _h = _http('POST', self._u('v1beta/models/%s:batchGenerateContent' % model),
                            {'batch': {'display_name': display, 'input_config': cfg}})
        if code != 200:
            raise RuntimeError('Batch 보내기 실패 HTTP %s %s' % (code, b[:300]))
        d = json.loads(b)
        return d.get('name') or (d.get('metadata') or {}).get('name')

    def upload(self, data, display):
        code, b, h = _http('POST', self._u('upload/v1beta/files'), {'file': {'display_name': display}},
                           headers={'X-Goog-Upload-Protocol': 'resumable', 'X-Goog-Upload-Command': 'start',
                                    'X-Goog-Upload-Header-Content-Length': str(len(data)),
                                    'X-Goog-Upload-Header-Content-Type': 'application/jsonl'})
        url = {k.lower(): v for k, v in h.items()}.get('x-goog-upload-url')
        if code != 200 or not url:
            raise RuntimeError('파일 올리기 시작 실패 HTTP %s %s' % (code, b[:300]))
        code, b, _h = _http('POST', url, data, headers={'X-Goog-Upload-Command': 'upload, finalize',
                                                         'X-Goog-Upload-Offset': '0',
                                                         'Content-Length': str(len(data))}, timeout=600)
        if code != 200:
            raise RuntimeError('파일 올리기 실패 HTTP %s %s' % (code, b[:300]))
        return json.loads(b)['file']['name']

    def get(self, name):
        code, b, _h = _http('GET', self._u('v1beta/%s' % name))
        if code != 200:
            raise RuntimeError('상태 묻기 실패 HTTP %s %s' % (code, b[:300]))
        return json.loads(b)

    def download(self, file_name):
        code, b, _h = _http('GET', self._u('download/v1beta/%s:download?alt=media' % file_name), raw=True, timeout=600)
        if code != 200:
            raise RuntimeError('결과 받기 실패 HTTP %s' % code)
        return b.decode('utf-8', 'replace')

    def cancel(self, name):
        _http('POST', self._u('v1beta/%s:cancel' % name), {})


def _net(conn, net=None):
    if net is not None:
        return net
    ks = AC.keys(conn)
    if not ks:
        raise RuntimeError('Gemini 키가 없습니다 — 「AI 연결」에서 넣으세요.')
    return Net(ks[0])


# ── 맡기기 ──────────────────────────────────────────────────────────
def _est(prompt):
    """어림 토큰 — 보낼 글 + 받을 글(대략 같은 길이) · 한글이 많으면 글자당 토큰이 많다"""
    return int(len(prompt) / 2.5) * 2


def build(conn, j, todo):
    """[(열쇠, [건…], 보낼 글)] — 묶을 수 있으면 지금 [전송하기]와 같은 묶음"""
    obj = AR.job_prompt_obj(conn, j)
    out = []
    if AR.batch_ok(j) and len(todo) > 1:
        groups, singles = AR.plan_batches(conn, j, todo)
    else:
        groups, singles = [], list(todo)
    for g in groups:
        out.append(([x[0] for x in g], AR.batch_prompt(obj, g)))
    fe, fd = AR.job_endings(conn, j, j['job_id'])
    for iid, sid, fixn in singles:
        ctx = AR.item_ctx(conn, j, sid, fixn, fe, fd)
        if '⚠' in ctx:
            AR._mark(conn, iid, 'FAIL', why=ctx['⚠'])
            continue
        out.append(([iid], AJ.render_prompt(obj, ctx)))
    return [('j%d_%d' % (j['job_id'], n), ids, p) for n, (ids, p) in enumerate(out, 1)]


def _request(prompt, think):
    gen = {}
    if think:
        gen['thinkingConfig'] = {'thinkingLevel': think}
    r = {'contents': [{'parts': [{'text': prompt}]}]}
    if gen:
        r['generationConfig'] = gen
    return r


def submit(conn, job_id, only=None, net=None):
    """선택한 건(없으면 그 작업의 대기·실패 전부)을 맡긴다 — 반환 {ok, batches, items, waiting, why}"""
    ensure(conn)
    j = AR.job(conn, job_id)
    q = ("SELECT item_id, slot_id, COALESCE(fix_note,'') FROM sys_ai_item WHERE job_id=? "
         "AND state IN ('PENDING','FAIL')")
    ar = [job_id]
    if only:
        q += " AND item_id IN (%s)" % ','.join('?' * len(only))
        ar += [int(x) for x in only]
    todo = conn.execute(q + " ORDER BY item_id", ar).fetchall()
    if not todo:
        return {'ok': False, 'why': 'Batch 로 보낼 건이 없습니다(대기·실패인 건만 보냅니다).', 'batches': 0, 'items': 0, 'waiting': 0}
    reqs = build(conn, j, todo)
    think = AC.task_think(conn, j['task'])
    # 대기열 한도로 자른다 — 넘는 몫은 WAITING(앞의 것이 끝나면 poll 이 맡긴다)
    parts, cur, cur_t = [], [], 0
    for key, ids, p in reqs:
        t = _est(p)
        if cur and cur_t + t > CAP_TOKENS:
            parts.append(cur)
            cur, cur_t = [], 0
        cur.append((key, ids, p))
        cur_t += t
    if cur:
        parts.append(cur)
    made = []
    for part in parts:
        plan = [[k, ids] for k, ids, _p in part]
        est = sum(_est(p) for _k, _i, p in part)
        cid = conn.execute(
            "INSERT INTO sys_ai_batch(job_id, model, think, state, plan_json, n_req, n_items, est_tokens, created_at, updated_at)"
            " VALUES(?,?,?,?,?,?,?,?,?,?)",
            (job_id, j['model'], think or '', 'WAITING', json.dumps(plan), len(part),
             sum(len(ids) for _k, ids, _p in part), est, _now(), _now())).lastrowid
        for _k, ids, _p in part:
            for iid in ids:
                AR._mark(conn, iid, 'QUEUED', why='Batch #%d' % cid)
        made.append(cid)
    conn.commit()
    # 지금 맡길 수 있는 만큼 맡긴다(대기열에 이미 있는 것과 합쳐 한도 아래)
    sent, why = _send_waiting(conn, net)
    return {'ok': True, 'batches': len(made), 'items': len(todo), 'sent': sent,
            'waiting': conn.execute("SELECT COUNT(*) FROM sys_ai_batch WHERE state='WAITING'").fetchone()[0], 'why': why}


def submit_check(conn, item_ids, net=None, redo=False):
    """오류 찾기를 맡긴다 — 받은 글이 있는 건만 · 이미 찾았거나 맡긴 건은 빼고(`redo` 면 찾은 건도 다시).
    묶음은 바로 찾기와 같다(`check_groups` — 3건씩). 반환 {ok, batches, items, sent, waiting, why}"""
    ensure(conn)
    held = {i for b in _rows(conn, "kind='CHECK' AND state IN ('WAITING','SUBMITTED','PENDING','RUNNING')")
            for _k, ids in json.loads(b['plan_json']) for i in ids}
    ids = []
    for iid in item_ids:
        r = conn.execute("SELECT COALESCE(check_json,'') FROM sys_ai_item WHERE item_id=?", (int(iid),)).fetchone()
        if r and int(iid) not in held and (redo or not r[0]):
            ids.append(int(iid))
    groups, _empty = AR.check_groups(conn, ids)
    if not groups:
        return {'ok': False, 'why': '오류 찾기를 맡길 건이 없습니다(받은 글이 없거나 이미 찾았거나 맡겼습니다).',
                'batches': 0, 'items': 0, 'sent': 0, 'waiting': 0}
    model = AR.check_model(conn)
    think = AC.task_think(conn, 'CHECK')
    byjob = {}
    for g in groups:
        byjob.setdefault(g[0]['job'], []).append(g)
    made = items = 0
    for jid, gs in sorted(byjob.items()):
        parts, cur, cur_t = [], [], 0
        for g in gs:
            t = _est(AR.check_batch_prompt(g))
            if cur and cur_t + t > CAP_TOKENS:
                parts.append((cur, cur_t))
                cur, cur_t = [], 0
            cur.append(g)
            cur_t += t
        if cur:
            parts.append((cur, cur_t))
        for part, est in parts:
            plan = [['c%d_%d' % (jid, n), [u['iid'] for u in g]] for n, g in enumerate(part, 1)]
            n_it = sum(len(g) for g in part)
            conn.execute(
                "INSERT INTO sys_ai_batch(job_id, model, think, state, plan_json, n_req, n_items, est_tokens, kind, created_at, updated_at)"
                " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (jid, model, think or '', 'WAITING', json.dumps(plan), len(part), n_it, est, 'CHECK', _now(), _now()))
            made += 1
            items += n_it
    conn.commit()
    sent, why = _send_waiting(conn, net)
    return {'ok': True, 'batches': made, 'items': items, 'sent': sent,
            'waiting': conn.execute("SELECT COUNT(*) FROM sys_ai_batch WHERE state='WAITING'").fetchone()[0], 'why': why}


def _prompts_of(conn, b):
    """WAITING 줄의 보낼 글을 다시 짓는다(저장하지 않는다 — 재료가 바뀌었으면 지금 것으로)"""
    if b.get('kind') == 'CHECK':
        out = []
        for key, ids in json.loads(b['plan_json']):
            us = [u for u in (AR._check_unit(conn, i) for i in ids) if u]
            if us:
                out.append((key, AR.check_batch_prompt(us)))
        return out
    j = AR.job(conn, b['job_id'])
    plan = json.loads(b['plan_json'])
    obj = AR.job_prompt_obj(conn, j)
    fe, fd = AR.job_endings(conn, j, j['job_id'])
    out = []
    for key, ids in plan:
        rows = [conn.execute("SELECT item_id, slot_id, COALESCE(fix_note,'') FROM sys_ai_item WHERE item_id=?", (i,)).fetchone()
                for i in ids]
        rows = [r for r in rows if r]
        if len(rows) > 1:
            g = [(r[0], r[1], AR.item_ctx(conn, j, r[1])) for r in rows]
            out.append((key, AR.batch_prompt(obj, g)))
        elif rows:
            out.append((key, AJ.render_prompt(obj, AR.item_ctx(conn, j, rows[0][1], rows[0][2], fe, fd))))
    return out


def _rows(conn, where, args=()):
    cols = [r[1] for r in conn.execute("PRAGMA table_info(sys_ai_batch)")]
    return [dict(zip(cols, r)) for r in conn.execute("SELECT * FROM sys_ai_batch WHERE " + where, args)]


def _send_waiting(conn, net=None):
    """기다리는 줄을 대기열 한도 안에서 맡긴다 — 반환 (맡긴 수, 까닭)"""
    waiting = _rows(conn, "state='WAITING' ORDER BY batch_id")
    if not waiting:
        return 0, ''
    busy = {}
    for b in _rows(conn, "state IN ('SUBMITTED','PENDING','RUNNING')"):
        busy[b['model']] = busy.get(b['model'], 0) + int(b['est_tokens'] or 0)
    n, why = 0, ''
    nt = None
    for b in waiting:
        if busy.get(b['model'], 0) + int(b['est_tokens'] or 0) > CAP_TOKENS and busy.get(b['model'], 0) > 0:
            why = '대기열이 차서 앞의 Batch 가 끝나면 보냅니다'
            continue
        try:
            nt = _net(conn, net) if nt is None else nt
            ps = _prompts_of(conn, b)
            reqs = [{'request': _request(p, b['think'] or None), 'metadata': {'key': k}} for k, p in ps]
            body = json.dumps(reqs, ensure_ascii=False).encode('utf-8')
            disp = 'hagah-job%d-b%d' % (b['job_id'], b['batch_id'])
            if len(body) <= INLINE_MAX:
                name = nt.create(b['model'], disp, requests=reqs)
            else:
                lines = '\n'.join(json.dumps({'key': k, 'request': _request(p, b['think'] or None)}, ensure_ascii=False)
                                  for k, p in ps).encode('utf-8')
                name = nt.create(b['model'], disp, file_name=nt.upload(lines, disp))
            conn.execute("UPDATE sys_ai_batch SET name=?, state='SUBMITTED', why='', updated_at=? WHERE batch_id=?",
                         (name, _now(), b['batch_id']))
            conn.commit()
            busy[b['model']] = busy.get(b['model'], 0) + int(b['est_tokens'] or 0)
            n += 1
            try:
                import ai_sent_log as _SL
                with _SL.tag('AI 작업실 · Batch', 'job %d · Batch #%d · 요청 %d' % (b['job_id'], b['batch_id'], len(ps)),
                             job_id=b['job_id']):
                    _SL.record('db_ai_batch', '\n\n'.join(p for _k, p in ps), model=b['model'], ok=True,
                               response='(Batch %s)' % name, why='')
            except Exception:                             # noqa: BLE001
                pass
        except Exception as e:                            # noqa: BLE001
            conn.execute("UPDATE sys_ai_batch SET why=?, updated_at=? WHERE batch_id=?", (str(e)[:300], _now(), b['batch_id']))
            conn.commit()
            why = str(e)[:200]
            break
    return n, why


# ── 받기 ────────────────────────────────────────────────────────────
def _state_of(d):
    s = str((d.get('metadata') or {}).get('state') or d.get('state') or '')
    for k in ('SUCCEEDED', 'FAILED', 'CANCELLED', 'EXPIRED', 'RUNNING', 'PENDING'):
        if k in s:
            return k
    return 'SUCCEEDED' if d.get('done') else 'PENDING'


def _results(d, nt):
    """끝난 일 → {열쇠: (글, 토큰, 오류)}"""
    resp = d.get('response') or (d.get('metadata') or {}).get('output') or {}
    out = {}

    def one(key, r, err):
        if err or not r:
            out[key] = ('', {}, (err or {}).get('message', '응답 없음') if isinstance(err, dict) else str(err or '응답 없음'))
            return
        txt, tok, why = AC._parse(json.dumps(r))
        out[key] = (txt or '', tok or {}, why or '')

    inl = resp.get('inlinedResponses')
    if isinstance(inl, dict):
        inl = inl.get('inlinedResponses')
    if inl:
        for n, x in enumerate(inl, 1):
            key = ((x.get('metadata') or {}).get('key')) or n
            one(key, x.get('response'), x.get('error'))
    elif resp.get('responsesFile'):
        for ln in nt.download(resp['responsesFile']).splitlines():
            if ln.strip():
                x = json.loads(ln)
                one(x.get('key'), x.get('response'), x.get('error'))
    return out


def _ingest(conn, b, res):
    """받은 글을 건에 담는다 — [전송하기]와 같은 문(나누기 · 게이트 · 검수 대기) · 반환 (담음, 다시 맡길 건)"""
    if b.get('kind') == 'CHECK':
        return _ingest_check(conn, b, res)
    j = AR.job(conn, b['job_id'])
    plan = json.loads(b['plan_json'])
    heads = set()
    done, retry = 0, []
    tin = tout = 0
    for n, (key, ids) in enumerate(plan, 1):
        txt, tok, err = res.get(key) or res.get(n) or ('', {}, '결과에 이 열쇠가 없습니다')
        tin += int(tok.get('in', 0))
        tout += int(tok.get('out', 0))
        if not txt:
            for iid in ids:
                AR._mark(conn, iid, 'PENDING', why='Batch 실패: %s' % err)
            continue
        texts = [txt.strip()] if len(ids) == 1 else AR.split_batch(txt, len(ids))
        if texts is None:
            retry += ids                           # 못 나눴다 — 한 건씩 다시 맡긴다
            continue
        share = {'in': int(tok.get('in', 0)) // len(ids), 'out': int(tok.get('out', 0)) // len(ids)}
        for iid, t in zip(ids, texts):
            sid, fixn = conn.execute("SELECT slot_id, COALESCE(fix_note,'') FROM sys_ai_item WHERE item_id=?", (iid,)).fetchone()
            t, _sn = AR.take_src_note(t)
            AR.keep_src_note(conn, j, iid, sid, _sn)
            g = AR.gate_for_job(conn, j, sid, t, heads, before=AR._before_of(conn, j, sid))
            heads.add(AR.head_of(t))
            AR._mark(conn, iid, 'DONE', text=t, gate=g, tok=share)
            if fixn:
                conn.execute("UPDATE sys_ai_item SET fix_note=NULL WHERE item_id=?", (iid,))
            done += 1
    try:
        AC.note_usage(conn, b['model'], True, tin, tout)
    except Exception:                                     # noqa: BLE001
        pass
    conn.execute("UPDATE sys_ai_batch SET state='DONE', tok_in=?, tok_out=?, updated_at=? WHERE batch_id=?",
                 (tin, tout, _now(), b['batch_id']))
    conn.commit()
    return done, retry


def _ingest_check(conn, b, res):
    """오류 찾기 결과 — 건의 상태는 그대로 · 못 받은 건은 비워 두어 다시 맡길 수 있다"""
    done = tin = tout = 0
    for n, (key, ids) in enumerate(json.loads(b['plan_json']), 1):
        txt, tok, _err = res.get(key) or res.get(n) or ('', {}, '')
        tin += int(tok.get('in', 0))
        tout += int(tok.get('out', 0))
        if not txt:
            continue
        us = [u for u in (AR._check_unit(conn, i) for i in ids) if u]
        AR.check_store(conn, us, txt, b['model'])
        done += len(us)
    try:
        AC.note_usage(conn, b['model'], True, tin, tout)
    except Exception:                                     # noqa: BLE001
        pass
    conn.execute("UPDATE sys_ai_batch SET state='DONE', tok_in=?, tok_out=?, updated_at=? WHERE batch_id=?",
                 (tin, tout, _now(), b['batch_id']))
    conn.commit()
    return done, []


def poll(conn, net=None):
    """맡긴 일을 모두 묻는다 — 반환 {checked, got, items, failed, sent, why}"""
    ensure(conn)
    r = {'checked': 0, 'got': 0, 'items': 0, 'failed': 0, 'sent': 0, 'why': ''}
    act = _rows(conn, "state IN ('SUBMITTED','PENDING','RUNNING') ORDER BY batch_id")
    nt = None
    for b in act:
        try:
            nt = _net(conn, net) if nt is None else nt
            d = nt.get(b['name'])
        except Exception as e:                            # noqa: BLE001
            r['why'] = str(e)[:200]
            continue
        r['checked'] += 1
        st = _state_of(d)
        if st in ('PENDING', 'RUNNING'):
            if st != b['state']:
                conn.execute("UPDATE sys_ai_batch SET state=?, updated_at=? WHERE batch_id=?", (st, _now(), b['batch_id']))
                conn.commit()
            continue
        if st == 'SUCCEEDED':
            try:
                done, retry = _ingest(conn, b, _results(d, nt))
            except Exception as e:                        # noqa: BLE001
                r['why'] = '결과 담기 실패: %s' % e
                continue
            r['got'] += 1
            r['items'] += done
            if retry:
                # 못 나눈 묶음 — 그 건들을 한 건씩 다시 맡긴다(새 WAITING 줄)
                plan = [['j%d_r%d_%d' % (b['job_id'], b['batch_id'], n), [i]] for n, i in enumerate(retry, 1)]
                conn.execute(
                    "INSERT INTO sys_ai_batch(job_id, model, think, state, plan_json, n_req, n_items, est_tokens, why, created_at, updated_at)"
                    " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                    (b['job_id'], b['model'], b['think'], 'WAITING', json.dumps(plan), len(plan), len(plan),
                     int(b['est_tokens'] or 0) // max(1, b['n_req'] or 1) * len(plan), '묶음 나누기 실패분', _now(), _now()))
                conn.commit()
        else:
            ids = [i for _k, ids in json.loads(b['plan_json']) for i in ids]
            for iid in (ids if b.get('kind') != 'CHECK' else []):
                AR._mark(conn, iid, 'PENDING', why='Batch %s' % STATE_KO.get(st, st))
            conn.execute("UPDATE sys_ai_batch SET state=?, updated_at=? WHERE batch_id=?", (st, _now(), b['batch_id']))
            conn.commit()
            r['failed'] += 1
    n, why = _send_waiting(conn, net)
    r['sent'] = n
    r['why'] = r['why'] or why
    return r


def cancel(conn, batch_id, net=None):
    """거둔다 — 그 건들은 「대기」로(다시 [전송하기]나 [맡기기])"""
    ensure(conn)
    b = (_rows(conn, "batch_id=?", (int(batch_id),)) or [None])[0]
    if not b:
        return False
    if b['name'] and b['state'] in ACTIVE:
        try:
            _net(conn, net).cancel(b['name'])
        except Exception:                                 # noqa: BLE001
            pass
    for _k, ids in json.loads(b['plan_json']):
        for iid in (ids if b.get('kind') != 'CHECK' else []):
            AR._mark(conn, iid, 'PENDING', why='Batch 취소')
    conn.execute("UPDATE sys_ai_batch SET state='CANCELLED', updated_at=? WHERE batch_id=?", (_now(), b['batch_id']))
    conn.commit()
    return True


def summary(conn, job_id=None):
    """화면 한 줄 — {상태: 수} (DONE·CANCELLED 는 오늘 것만)"""
    ensure(conn)
    q = "SELECT state, COUNT(*), SUM(n_items) FROM sys_ai_batch WHERE (state NOT IN ('DONE','CANCELLED','FAILED','EXPIRED') OR updated_at >= date('now','localtime'))"
    a = []
    if job_id:
        q += " AND job_id=?"
        a.append(job_id)
    return {s: (n, it or 0) for s, n, it in conn.execute(q + " GROUP BY 1", a)}


def active_of_items(conn, item_ids):
    """그 건들이 든 맡긴 일(아직 안 끝난 것)"""
    ensure(conn)
    want = {int(i) for i in item_ids}
    out = []
    for b in _rows(conn, "state IN ('WAITING','SUBMITTED','PENDING','RUNNING')"):
        if want & {i for _k, ids in json.loads(b['plan_json']) for i in ids}:
            out.append(b['batch_id'])
    return out


# ── 자가 검증(가짜 망 · 실제 DB 를 SAVEPOINT 없이 시험 작업으로) ──────────
class _FakeNet:
    def __init__(self, mode='ok'):
        self.mode, self.made, self.reqs = mode, [], {}

    def create(self, model, display, requests=None, file_name=None):
        name = 'batches/fake%d' % (len(self.made) + 1)
        self.made.append(name)
        self.reqs[name] = requests
        return name

    def upload(self, data, display):
        return 'files/fake'

    def get(self, name):
        rs = self.reqs[name]
        out = []
        for x in rs:
            p = x['request']['contents'][0]['parts'][0]['text']
            import re
            n = len(re.findall(r'^===== 항목 \d+ =====$', p, re.M))
            if self.mode == 'check':
                t = '\n'.join('%d | 번역 | 틀린말 | 왜 | 맞는말' % i for i in range(1, n + 1)) if n else '번역 | 틀린말 | 왜 | 맞는말'
            elif self.mode == 'bad' and n:
                t = '===== 항목 1 =====\n하나만'
            elif n:
                t = '\n'.join('===== 항목 %d =====\n맡김글%d' % (i, i) for i in range(1, n + 1))
            else:
                t = '맡김한건'
            out.append({'response': {'candidates': [{'content': {'parts': [{'text': t}]}}],
                                     'usageMetadata': {'promptTokenCount': 100, 'candidatesTokenCount': 20}},
                        'metadata': {'key': x['metadata']['key']}})
        return {'name': name, 'metadata': {'state': 'BATCH_STATE_SUCCEEDED'},
                'done': True, 'response': {'inlinedResponses': {'inlinedResponses': out}}}

    def cancel(self, name):
        pass


def selftest():
    import appdb
    bad = []

    def ck(c, m):
        print(('  PASS ' if c else '  FAIL ') + m)
        if not c:
            bad.append(m)

    conn = appdb.connect()
    ensure(conn)
    ck('QUEUED' in AR.STATES and AR.STATE_NAME.get('QUEUED') == 'Batch 중', '상태 「Batch 중」')
    ck(_state_of({'metadata': {'state': 'BATCH_STATE_RUNNING'}}) == 'RUNNING' and
       _state_of({'metadata': {'state': 'JOB_STATE_SUCCEEDED'}}) == 'SUCCEEDED', '상태 읽기(두 꼴)')
    # 시험 작업 — 1117 의 자리 4개를 빌려 새 작업(끝에 지운다)
    j0 = AR.job(conn, 1117)
    slots = [r[0] for r in conn.execute("SELECT slot_id FROM sys_ai_item WHERE job_id=1117 ORDER BY item_id LIMIT 4")]
    jid = None
    _sc0 = conn.execute("SELECT * FROM sys_ai_srccheck").fetchall()   # 원문 의심 「점검함」 — 시험이 남기지 않게
    try:
        jid, n = AR.create_job(conn, j0['asset_kind'], j0['scope_value'], 'TRANS', 'KO', slots, name='__맡김시험__',
                               base=j0['base_lang'], model='gemini-pro-latest')
        ids = [r[0] for r in conn.execute("SELECT item_id FROM sys_ai_item WHERE job_id=?", (jid,))]
        fn = _FakeNet('ok')
        r = submit(conn, jid, net=fn)
        ck(r['ok'] and r['sent'] >= 1 and AR.counts(conn, jid)['QUEUED'] == 4, '맡기면 「맡김」 · 보냄 %s' % r)
        ck(AR.run_job(conn, jid, _call=lambda *a, **k: {'ok': False})['tried'] == 0, '맡긴 건은 [전송하기]가 안 집는다')
        p = poll(conn, net=fn)
        c = AR.counts(conn, jid)
        ck(p['items'] == 4 and c['DONE'] == 4, '받으면 건마다 「검수 대기」 %s %s' % (p, c))
        txt = [conn.execute("SELECT out_text FROM sys_ai_item WHERE item_id=?", (i,)).fetchone()[0] for i in ids]
        ck(all(t.startswith('맡김') for t in txt), '건마다 제 글')
        # 못 나누면 한 건씩 다시 맡긴다
        conn.execute("UPDATE sys_ai_item SET state='PENDING', out_text=NULL WHERE job_id=?", (jid,))
        conn.commit()
        fb = _FakeNet('bad')
        submit(conn, jid, net=fb)
        p = poll(conn, net=fb)
        ck(p['sent'] >= 1, '나누기 실패분은 한 건씩 다시 맡김 %s' % p)
        p = poll(conn, net=fb)
        ck(AR.counts(conn, jid)['DONE'] == 4, '다시 맡긴 것도 받음 %s' % AR.counts(conn, jid))
        # 취소
        conn.execute("UPDATE sys_ai_item SET state='PENDING' WHERE job_id=?", (jid,))
        conn.commit()
        submit(conn, jid, net=_FakeNet('ok'))
        bid = active_of_items(conn, ids)
        ck(bid and cancel(conn, bid[0], net=_FakeNet()) and AR.counts(conn, jid)['QUEUED'] == 0, '취소하면 「대기」로')
        # 오류 찾기 맡기기 — 건 상태 불변 · 결과는 check_json · 두 번 안 나간다
        conn.execute("UPDATE sys_ai_item SET state='DONE', out_text='맡김글 틀린말 입니다', check_json=NULL WHERE job_id=?", (jid,))
        conn.commit()
        fc = _FakeNet('check')
        r = submit_check(conn, ids, net=fc)
        ck(r['ok'] and r['items'] == 4 and r['sent'] >= 1, '오류 찾기 맡김 %s' % r)
        ck(not submit_check(conn, ids, net=fc)['ok'], '맡긴 건은 두 번 안 나간다')
        ck(AR.counts(conn, jid)['DONE'] == 4, '오류 찾기는 건 상태를 안 바꾼다')
        p = poll(conn, net=fc)
        chk = [AR.check_of(conn, i) for i in ids]
        ck(p['items'] == 4 and all(c and c['found'] and c['found'][0]['wrong'] == '틀린말' for c in chk),
           '받으면 건마다 check_json %s' % p)
        ck(AR.counts(conn, jid)['DONE'] == 4 and not submit_check(conn, ids, net=fc)['ok'], '이미 찾은 건은 빼고')
        ck(submit_check(conn, ids, net=fc, redo=True)['ok'], 'redo 면 다시')
        bid = active_of_items(conn, ids)
        ck(bid and cancel(conn, bid[0], net=fc) and AR.counts(conn, jid)['DONE'] == 4, '오류 찾기 취소는 건 상태 불변')
    finally:
        if jid:
            conn.execute("DELETE FROM sys_ai_item WHERE job_id=?", (jid,))
            conn.execute("DELETE FROM sys_ai_batch WHERE job_id=?", (jid,))
            conn.execute("DELETE FROM sys_ai_job WHERE job_id=?", (jid,))
        conn.execute("DELETE FROM sys_ai_srccheck")
        conn.executemany("INSERT INTO sys_ai_srccheck VALUES (?,?,?,?)", _sc0)
        conn.commit()
    ck(conn.execute("SELECT COUNT(*) FROM sys_ai_job WHERE name='__맡김시험__'").fetchone()[0] == 0, '시험 자국 0')
    print('db_ai_batch selftest: %s' % ('OK' if not bad else 'FAIL %d' % len(bad)))
    return 0 if not bad else 1


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(selftest())
    import appdb
    c = appdb.connect()
    if '--poll' in sys.argv:
        print(poll(c))
    elif '--check' in sys.argv:          # --check 작업번호 : 그 작업의 받은 글 전부의 오류 찾기를 맡긴다
        jid = int(sys.argv[sys.argv.index('--check') + 1])
        print(submit_check(c, [r[0] for r in c.execute(
            "SELECT item_id FROM sys_ai_item WHERE job_id=? AND state='DONE' ORDER BY item_id", (jid,))]))
    elif '--submit' in sys.argv:
        i = sys.argv.index('--submit')
        jid = int(sys.argv[i + 1])
        only = [int(x) for x in sys.argv[i + 2].split(',')] if len(sys.argv) > i + 2 and sys.argv[i + 2][0].isdigit() else None
        print(submit(c, jid, only))
    else:
        for b in _rows(c, "1=1 ORDER BY batch_id DESC LIMIT 20"):
            print(b['batch_id'], b['job_id'], b['state'], b['n_items'], b['name'], (b['why'] or '')[:60])
