# -*- coding: utf-8 -*-
"""엔티티 ↔ 엔티티 연결의 단일 소스 (2026-08-25 연결 통합 12차).

옛 `sys_person_relation`(인물↔인물)과 `sys_idol_person_relation`(우상↔인물)이
통합 표 `sys_link_asset` 의 **같은 `link_type='ENTI_ENTI'`** 로 들어갔다.
`link_type` 은 **양 끝의 종류**를 말할 뿐이고(§81 사용자 설계), 무슨 관계인지는
`rel_code` 가 말한다.

    옛                                  새
    ---------------------------------   ------------------------------------
    sys_person_relation                 ENTI_ENTI + rel_code IN PERSON
      from_person_id / to_person_id       clicked_id / target_id
      relation_type                       rel_code
      relation_cat                        relation_cat
      is_directed                         is_directed
    sys_idol_person_relation            ENTI_ENTI + rel_code IN IDOL
      idol_id / person_id                 clicked_id / target_id
      relation_type                       rel_code
      note                                note
    sys_entity_compare                  ENTI_ENTI + rel_code IN COMPARE
      (가까운 낱말)                       ⚠ 옛 행은 NULL — CONFUSED 로 읽는다

⚠⚠ **인물 관계를 물을 때 우상 관계가 딸려 오면 안 된다.** 옛 화면은 표가 달라
  저절로 갈렸지만 이제는 한 표다. 엘리야로 물으면 「엘리야 ↔ 바알(OPPONENT)」이
  인물 관계 목록에 섞여 든다 — **조용한 동작 변화**다. 그래서 갈래마다
  `rel_code` 목록으로 좁힌다.

⚠ **목록을 손으로 적어 두었으므로 selftest 가 매번 데이터와 대조한다.**
  새 관계 이름이 생기면 **그 자리에서 실패**한다 — 조용히 빠지지 않는다.
"""
import sys

TBL = 'sys_link_asset'
LT = 'ENTI_ENTI'

#: 인물 ↔ 인물 (옛 `sys_person_relation.relation_type`)
PERSON = (
    'FATHER', 'MOTHER', 'SPOUSE', 'CHILD', 'SIBLING', 'IN_LAW', 'KIN',
    'CONCUBINE', 'INFORMAL_UNION',
    'CO_WORKER', 'ALLY', 'FRIEND', 'ENEMY', 'RIVAL', 'AUTHORITY',
    'STEWARDSHIP', 'MENTOR', 'FOLLOWER', 'BETRAYAL', 'CONFLICT_TEMP',
    'ORACLE', 'SPIRITUAL_LEGACY', 'OCCULT_DECEPTION', 'SACRED_ENCOUNTER',
    'SPIRITUAL_CATALYST',
)

#: 우상 ↔ 인물 (옛 `sys_idol_person_relation.relation_type`)
IDOL = ('WORSHIPPER', 'INTRODUCER', 'OPPONENT', 'PROPHET', 'VICTIM',
        'REFORMER')

#: 민족 ↔ 인물·우상 (2026-09-02 신설 — 0.txt 1번 관계 확대. 옛 표 없음,
#: 처음부터 통합 표에 산다. clicked=민족 · target=인물|우상).
#:   FOUNDER 조상 · KING 왕 · MEMBER 그 민족 사람 · PROPHET_TO 보냄 받은
#:   선지자 · COURT 궁정에 선 사람(요셉·다니엘·에스더) · NATIONAL_GOD 민족의 신
NATION = ('FOUNDER', 'KING', 'MEMBER', 'PROPHET_TO', 'COURT', 'NATIONAL_GOD')

#: **관문 ↔ 소속** (2026-09-07 사용자 지시 「하나님의 속성 - 편재성,
#: 전능성... 연결되어야 한다 … **유사한 것들이 많이 있을 것이다 모두
#: 일괄적으로 처리**하도록 하자」). clicked=관문 · target=소속 낱말.
#:
#: ★★ **관문이란** — 「하나님의 속성」·「성령의 열매」처럼 **여럿을 묶어
#:   부르는 이름**이다. 실측 그런 항목이 18개인데 **아무것도 안 이어져
#:   있었다**(DOCTRINE 46 중 40이 연결 0).
#: ⚠ **어휘를 하나만 둔다** — 「속성」·「열매」·「은사」로 가르면 관문마다
#:   낱말이 늘고, 그 이름은 **관문 엔티티가 이미 말한다**(「성령의 열매」
#:   아래 있으면 그것이 열매다). §168차 NATION 이 민족·그룹을 한 어휘로
#:   쓴 것과 같은 판단이다.
#: ⚠ **소속은 대개 TERM 이지만 유형을 안 가린다** — 「성령의 은사」에는
#:   인물이 붙을 수도 있다(대상을 좁히면 다음에 또 늘린다).
GATEWAY = ('ASPECT',)

#: **가까운 낱말** (2026-09-24 · 1.txt 15번 4번째 항목 — 사용자 「헷갈리는
#: 낱말만 표시하는 것은 부족하다. **비슷한 말, 반대말, 관련어**도 표시하면
#: 좋겠다」). 옛 `sys_entity_compare` 가 옮겨 온 자리이고, 그동안은
#: **`rel_code` 가 비어 있는 것**이 곧 이 갈래였다.
#:
#: ★★★ **칸을 새로 만들지 않았다** — 통합 표에 `rel_code` 가 **이미 있고**
#:   그것이 「무슨 관계인가」를 말하는 자리다(이 파일 머리글). 새 칸을 두면
#:   인물·우상·민족은 `rel_code`, 낱말만 다른 칸을 보는 꼴이 된다.
#: ⚠ 옛 행은 `rel_code` 가 `NULL` 이다 — **읽을 때 `CONFUSED` 로 본다**
#:   (`db_entity_compare._REL_SQL`). 지어서 채우는 것이 아니라 **그때의 뜻이
#:   실제로 「헷갈리는 낱말」**이었다.
#:   CONFUSED 헷갈리는 낱말 · SIMILAR 비슷한 말 · OPPOSITE 반대말 ·
#:   RELATED 관련어
COMPARE = ('CONFUSED', 'SIMILAR', 'OPPOSITE', 'RELATED')
COMPARE_DEFAULT = 'CONFUSED'


def compare_where(alias='l'):
    """가까운 낱말(옛 비교 짝)만. `(조건절, 인자)`.

    ⚠ **`rel_code IS NULL` 도 함께 잡는다** — 관계를 안 적은 옛 행이 곧
      `CONFUSED` 다. 빼면 그 20짝이 화면에서 통째로 사라진다.
    """
    w, a = _in(alias, COMPARE)
    return ('(%s OR (%s.link_type=? AND %s.rel_code IS NULL))'
            % (w, alias, alias), a + [LT])


def gateway_where(alias='l'):
    """관문 ↔ 소속. `(조건절, 인자)`."""
    return _in(alias, GATEWAY)


def _in(alias, names):
    ph = ','.join('?' * len(names))
    return ('%s.link_type=? AND %s.rel_code IN (%s)' % (alias, alias, ph),
            [LT] + list(names))


def person_where(alias='l'):
    """인물 관계만. `(조건절, 인자)`."""
    return _in(alias, PERSON)


def idol_where(alias='l'):
    """우상 관계만. `(조건절, 인자)`."""
    return _in(alias, IDOL)


def nation_where(alias='l'):
    """민족·그룹(집단) 관계. `(조건절, 인자)`.

    ★ 그룹-인물(2026-09-02 확장)도 **같은 어휘**를 쓴다 — 바리새파의
      MEMBER 와 모압의 MEMBER 는 같은 뜻이고, 행은 clicked(집단) 번호로
      갈리므로 목록을 또 만들면 두 벌이 된다."""
    return _in(alias, NATION)


#: 그룹-인물도 집단 갈래다 — 별칭(호출부가 뜻을 밝혀 쓰도록)
group_where = nation_where


def selftest():
    ok = fail = 0

    def t(n, cond, e=''):
        nonlocal ok, fail
        if cond:
            ok += 1
            print('  OK   %s' % n)
        else:
            fail += 1
            print('  FAIL %s  %s' % (n, e))

    _lists = (('인물', PERSON), ('우상', IDOL), ('민족', NATION),
              ('관문', GATEWAY), ('낱말', COMPARE))
    # ⚠ 한 쌍이라도 겹치면 화면에 남의 관계가 섞인다 — 전수로 잰다
    for i in range(len(_lists)):
        for j in range(i + 1, len(_lists)):
            (n1, l1), (n2_, l2) = _lists[i], _lists[j]
            both = set(l1) & set(l2)
            t('%s×%s 어휘가 안 겹친다' % (n1, n2_), not both, both)
    t('목록에 빈 값이 없다', all(all(l) for _n, l in _lists))
    t('가까운 낱말 기본값이 목록 안', COMPARE_DEFAULT in COMPARE)

    w, a = person_where('x')
    t('조건절 모양', w.startswith('x.link_type=? AND x.rel_code IN ('), w)
    t('인자 수가 맞는다', len(a) == 1 + len(PERSON), len(a))

    try:
        import appdb
        c = appdb.connect()

        # ★ **데이터와 대조한다** — 새 관계 이름이 생기면 여기서 잡힌다
        for tbl, col, names, label in (
                ('sys_person_relation', 'relation_type', PERSON, '인물'),
                ('sys_idol_person_relation', 'relation_type', IDOL, '우상')):
            try:
                got = {r[0] for r in c.execute(
                    'SELECT DISTINCT %s FROM %s' % (col, tbl)) if r[0]}
            except Exception:
                continue
            miss = got - set(names)
            t('%s 관계 이름이 목록에 다 있다' % label, not miss,
              '목록에 없는 이름: %s' % sorted(miss))

        # 통합 표 쪽 — 옛 표와 개수가 같은가
        for tbl, where_fn, label in (
                ('sys_person_relation', person_where, '인물'),
                ('sys_idol_person_relation', idol_where, '우상')):
            try:
                old = c.execute('SELECT COUNT(*) FROM %s' % tbl).fetchone()[0]
            except Exception:
                continue
            if not old:
                continue
            w, args = where_fn('l')
            new = c.execute('SELECT COUNT(*) FROM %s l WHERE %s'
                            % (TBL, w), args).fetchone()[0]
            t('%s 관계 %d건이 통합 표에 있다' % (label, old), new == old,
              (old, new))

        # ⚠ 갈래가 서로를 안 잡는가 (섞이면 화면에 남의 관계가 뜬다)
        wp, ap = person_where('l')
        wi, ai = idol_where('l')
        wn, an = nation_where('l')
        wc, ac = compare_where('l')
        for (w1, a1), (w2, a2), lbl in (
                ((wp, ap), (wi, ai), '인물×우상'),
                ((wp, ap), (wn, an), '인물×민족'),
                ((wi, ai), (wn, an), '우상×민족'),
                ((wp, ap), (wc, ac), '인물×낱말'),
                ((wi, ai), (wc, ac), '우상×낱말'),
                ((wn, an), (wc, ac), '민족×낱말')):
            both = c.execute(
                'SELECT COUNT(*) FROM %s l WHERE (%s) AND (%s)'
                % (TBL, w1, w2), a1 + a2).fetchone()[0]
            t('%s 갈래가 겹치는 행 0' % lbl, both == 0, both)
        c.close()
    except Exception as e:
        print('  --   DB 검사 건너뜀: %s' % e)

    print('\nentity_relation selftest %d/%d' % (ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
    sys.exit(0 if selftest() else 1)
