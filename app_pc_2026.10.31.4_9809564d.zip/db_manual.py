# -*- coding: utf-8 -*-
"""
db_manual.py — **화면 매뉴얼** 표·번호·초안 적재 (2026-08-22 신설 · 영구)
=========================================================================
`python db_manual.py --selftest`   — 의무
`python db_manual.py --init`       — 표 둘 만들고 화면 15개 등록 (멱등)
`python db_manual.py --list`       — 화면 목록 · 매뉴얼 있는지
`python db_manual.py --check`      — `_manual_draft/*.md` 훑어보기
`python db_manual.py --apply`      — 그 초안을 `sys_manual_asset_v2` 로 (멱등)
`python db_manual.py --absorb`     — 사용자가 고친 것을 **초안으로 꺼낸다**(미리보기)
`python db_manual.py --absorb-write` — 그 초안 파일을 실제로 쓴다

━━ 사용자 수정본 흡수 (`--absorb`) ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
사용자가 팝업에서 고친 글은 **자기 PC 의 `user_manual_asset_v2`** 에만 있다
(§0-6 C-2 — 앱은 배포 DB 에 쓰지 않는다). 그대로 두면 **다음 배포에서
`bible_master.db` 를 통째로 갈 때 그 수정이 묻힌다.**
⇒ `--absorb` 가 그것을 **초안 파일로 꺼낸다.** 그 뒤는 평소와 같은 길
  (`--check` 로 읽어 보고 → `--apply` 로 sys 에 넣는다). **sys 로 곧장 넣는
  두 번째 길을 만들지 않는다** — 길이 둘이면 사람이 읽어 보는 단계가 빠진다.
⚠ **사용자 행은 지우지 않는다.** 지우면 그 사람 화면에서 자기 글이 사라진다.
  sys 에 같은 내용이 들어가면 팝업이 「사용자 수정본」 띠만 계속 띄울 뿐이고,
  그건 [복구]로 사용자가 정리한다.
⚠ **덮어쓰기 전에 알린다** — 같은 번호·언어의 초안이 이미 있으면 건너뛰고
  세어서 말한다(`--force` 로만 덮는다). 내가 쓰던 초안을 조용히 잃지 않게.

━━ 왜 만들었나 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
★ **ⓜ 가 안 눌리던 원인은 표 하나가 없던 것**(2026-08-22 실측). 팝업이
  관리자 매뉴얼을 읽은 **다음 줄**에서 `user_manual_asset_v2`(사용자 수정본)
  를 찾는데 그 표가 아예 없어 거기서 터졌다. 화면·조회·편집 코드는 넉 달째
  다 완성돼 있었다. ⚠ §26 테이블 관리 목록에는 그 이름이 **올라 있었다** —
  「목록이 낡았다」로 읽고 넘어갔지만 실은 **표를 안 만든 것**이었다.
  ⇒ 목록에 있는데 DB 에 없는 표가 보이면 **어느 쪽이 맞는지 확인할 것.**

★★ **화면 목록이 어디에도 없었다.** 화면 코드가 `attach_manual_icon(...)`
  호출부에 흩어져 있어 「어느 화면에 매뉴얼이 없나」를 **셀 수가 없었다.**
  `sys_manual_screen` 이 그 목록이고, 그것이 곧 작업 진도표다.

━━ 번호 규칙 (사용자 확정) ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    1xx  P1(왼쪽 위)   2xx  P2(구절 패널)   4xx  P4(오른쪽)
    8xx  팝업 창       9xx  관리자
⚠⚠ **번호는 한 번 주면 안 바꾸고, 화면이 없어져도 재사용하지 않는다.**
  「M203 고쳐줘」가 나중에 딴 화면을 가리키면 안 된다.
⚠ **백의 자리에 패널만 담는다 — 탭 번호는 담지 않는다.** 지금 화면 코드
  `U_P4_T1`·`U_P4_T2` 가 낡은 이유가 그것이다(그 두 탭은 2026-08-12 에
  하나로 합쳤다). 패널(P1·P2·P4)은 앱이 시작된 뒤로 바뀐 적이 없다.

━━ 화면에 보이는 것 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  단추는 **네모 안에 `M` 한 글자**, 번호는 **누르면 팝업 제목**에 나온다
  (사용자 지시). ⚠ 네모를 글자(`🄼`)로 만들지 않는다 — 한글 글꼴에 없어서
  다른 글꼴로 대체돼 어긋난다(cmap 실측: 맑은 고딕·굴림 둘 다 없음).
  테두리는 **Tk 가 그리는 선**이라 어디서나 같다.
"""
import io
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb

DRAFT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         '_manual_draft')

# ── 표 둘 ────────────────────────────────────────────────────────────────
# ⚠ 사용자 수정본은 **userdb** 다(§0-6 C-2 — 사용자 동작이 배포 DB 를 건드리면
#   안 된다). 칼럼 이름은 `manual_popup.py` 가 쓰는 그대로여야 한다.
DDL_USER = """
CREATE TABLE IF NOT EXISTS userdb.user_manual_asset_v2 (
  user_manual_id INTEGER PRIMARY KEY AUTOINCREMENT,
  origin_id      INTEGER NOT NULL,      -- sys_manual_asset_v2.manual_id
  title          TEXT,
  contents       TEXT,
  lang_code      TEXT NOT NULL,
  record_status  TEXT NOT NULL DEFAULT 'EDIT',
  updated_at     TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS userdb.ux_uma2
  ON user_manual_asset_v2(origin_id, lang_code);
"""

# 화면 등록표 — **배포 DB**(관리자가 정하는 목록이라 sys 쪽이 맞다)
DDL_SCREEN = """
CREATE TABLE IF NOT EXISTS sys_manual_screen (
  manual_no     INTEGER PRIMARY KEY,    -- M101 … 재사용 금지
  screen_code   TEXT NOT NULL UNIQUE,   -- 화면이 쓰는 열쇠(안 바꾼다)
  area          TEXT,                   -- P1 · P2 · P4 · POPUP · ADMIN
  name_ko       TEXT,                   -- 목록에서 사람이 읽을 이름
  place         TEXT,                   -- 단추를 어디에 두었나(기록용)
  record_status TEXT NOT NULL DEFAULT 'LIVE'
);
"""

# ── 화면 15곳 (2026-08-22 사용자 확정) ───────────────────────────────────
# ⚠ 「특별히 복잡한 내용이 없는 화면에는 굳이 배치할 필요가 없다」(사용자).
#   기준 셋 — ㉠ 용어 설명이 필요 ㉡ 내비게이션이 복잡 ㉢ 대상 범위 설명이 필요.
SCREENS = [
    # 번호  코드            구역     이름                  자리
    (101, 'U_P1_T1',    'P1',    'P1 상단 도구 줄',      '도구 줄 오른쪽 끝'),
    (102, 'U_P1_T2',    'P1',    '묵상플랜',             '액션 bar 오른쪽'),
    (103, 'U_P1_T3',    'P1',    '도서·설교·교리자료',    '2단 bar 오른쪽'),
    (104, 'U_P1_LENS',  'P1',    '렌즈묵상',             '상단 bar 오른쪽'),
    (201, 'U_P2_DESC',  'P2',    '설명·주석',            '갈래 단추 줄 오른쪽'),
    (202, 'U_P2_NOTE',  'P2',    '자료·노트',            '갈래 단추 줄 오른쪽'),
    (203, 'U_P2_FLOW',  'P2',    '구속사연결',           '탭 상단 오른쪽'),
    (401, 'U_P4_T1',    'P4',    '구절 연결',            '상단 줄 오른쪽'),
    (402, 'U_P4_R_LIST', 'P4',   '연구자료 · 자료목록',   '갈래 줄 오른쪽(공용)'),
    (403, 'U_P4_R_COMPOSE', 'P4', '연구자료 · 작성도구',  '갈래 줄 오른쪽(공용)'),
    (404, 'U_P4_R_TAG', 'P4',    '연구자료 · 태그 탐색',  '갈래 줄 오른쪽(공용)'),
    (405, 'U_P4_R_SEARCH', 'P4', '연구자료 · 통합검색',   '갈래 줄 오른쪽(공용)'),
    (406, 'U_P4_T4',    'P4',    '주요용어',             '상단 bar 오른쪽'),
    (407, 'U_P4_PILGRIM', 'P4',  '믿음의 발자취',         '지역 bar 오른쪽'),
    (801, 'U_LINK_PICK', 'POPUP', '연결하기 창',          '제목 줄 오른쪽'),
]

# 붙이지 않기로 한 곳 — **떼는 것 둘**(사용자 확정). 기록으로 남긴다.
#   나의 길(U_P1_T4)      : 목록 셋이 이름 그대로
#   제자 가계도(U_P4_T5)  : 범례 카드가 화면에 이미 있고 매뉴얼도 없다
RETIRE = ('U_P1_T4', 'U_P4_T5')


def init_schema(conn):
    """멱등. ⚠ 사용자 표는 `userdb.` 접두 필수 — 빼면 배포 DB 에 생긴다."""
    for ddl in (DDL_USER, DDL_SCREEN):
        for stmt in ddl.strip().split(';'):
            if stmt.strip():
                conn.execute(stmt)
    conn.commit()


def seed_screens(conn):
    """화면 15곳 등록. **번호를 이미 쓰고 있으면 건드리지 않는다.**"""
    n_new = n_upd = 0
    for no, code, area, name, place in SCREENS:
        row = conn.execute("SELECT manual_no, screen_code FROM sys_manual_screen "
                           " WHERE manual_no=? OR screen_code=?",
                           (no, code)).fetchone()
        if row is None:
            conn.execute("INSERT INTO sys_manual_screen"
                         "(manual_no, screen_code, area, name_ko, place) "
                         "VALUES(?,?,?,?,?)", (no, code, area, name, place))
            n_new += 1
            continue
        if row[0] != no or row[1] != code:
            # ⚠ 번호↔코드 짝이 어긋났다 — **자동으로 안 고친다**(번호는 불변).
            print('  !! 짝이 다르다: 있는 것 %s=%s / 넣으려는 것 %s=%s'
                  % (row[0], row[1], no, code))
            continue
        cur = conn.execute("UPDATE sys_manual_screen SET area=?, name_ko=?, "
                           " place=?, record_status='LIVE' WHERE manual_no=?",
                           (area, name, place, no))
        n_upd += cur.rowcount
    conn.commit()
    return n_new, n_upd


def no_of(conn, screen_code):
    """화면 코드 → 번호(없으면 None). 팝업 제목과 툴팁이 쓴다."""
    try:
        r = conn.execute("SELECT manual_no FROM sys_manual_screen "
                         " WHERE screen_code=? AND record_status='LIVE'",
                         (screen_code,)).fetchone()
        return r[0] if r else None
    except Exception:
        return None


def label_of(conn, screen_code):
    """`M203` 꼴. 번호가 없으면 코드를 그대로 (조용히 비우지 않는다)."""
    n = no_of(conn, screen_code)
    return ('M%d' % n) if n else str(screen_code)


# ── 초안 파일 ────────────────────────────────────────────────────────────
# `_manual_draft/M203.KO.md` — 첫 줄 `# 제목`, 나머지가 본문.
# ⚠ **앱은 이 폴더에만 쓴다**(배포 DB 에 안 쓴다). 배포판에는 이 폴더가 없어
#   초안 모드가 저절로 꺼진다 — 지울 코드가 없으니 잊을 일도 없다.
_FN = re.compile(r'^M(\d+)\.([A-Za-z]{2,3})\.md$')


def draft_path(no, lang):
    return os.path.join(DRAFT_DIR, 'M%d.%s.md' % (int(no), str(lang).upper()))


def read_draft(no, lang):
    p = draft_path(no, lang)
    if not os.path.exists(p):
        return None
    s = io.open(p, encoding='utf-8').read()
    return parse_draft(s)


def parse_draft(s):
    """`# 제목` 첫 줄 + 본문. 제목 줄이 없으면 첫 줄을 제목으로."""
    lines = (s or '').replace('\r\n', '\n').split('\n')
    while lines and not lines[0].strip():
        lines.pop(0)
    if not lines:
        return None
    title = lines[0].lstrip('#').strip()
    body = '\n'.join(lines[1:]).strip()
    return {'title': title, 'contents': body}


def write_draft(no, lang, title, contents):
    if not os.path.isdir(DRAFT_DIR):
        os.makedirs(DRAFT_DIR)
    p = draft_path(no, lang)
    io.open(p, 'w', encoding='utf-8').write(
        '# %s\n\n%s\n' % ((title or '').strip(), (contents or '').strip()))
    return p


def drafts():
    """[(번호, 언어, 경로)] — 파일 이름에서 읽는다."""
    out = []
    if not os.path.isdir(DRAFT_DIR):
        return out
    for fn in sorted(os.listdir(DRAFT_DIR)):
        m = _FN.match(fn)
        if m:
            out.append((int(m.group(1)), m.group(2).upper(),
                        os.path.join(DRAFT_DIR, fn)))
    return out


def absorb_user(conn, write=False, force=False):
    """사용자 수정본(`user_manual_asset_v2`) → 초안 파일. → (쓴 것, 건너뛴 것, 문제)

    ⚠ **사용자 행은 읽기만 한다**(위 머리글 참조).
    """
    rows = conn.execute("""
        SELECT u.origin_id, u.lang_code, u.title, u.contents, u.updated_at,
               s.screen_code, s.icon_key
          FROM user_manual_asset_v2 u
          JOIN sys_manual_asset_v2 s ON s.manual_id = u.origin_id
         WHERE COALESCE(u.record_status,'EDIT')='EDIT'
         ORDER BY s.screen_code, u.lang_code""").fetchall()
    done, skip, bad = [], [], []
    for _oid, lang, title, contents, upd, screen, icon in rows:
        lang = (lang or 'KO').upper()
        if (icon or 'MAIN') != 'MAIN':
            # 초안 이름은 (번호, 언어)뿐이라 아이콘별 매뉴얼은 담지 못한다.
            # 조용히 빠뜨리지 않고 알린다(§0 no silent caps).
            bad.append((screen, icon, lang, '아이콘별 매뉴얼은 초안으로 못 꺼낸다'))
            continue
        no = no_of(conn, screen)
        if not no:
            bad.append((screen, icon, lang, '화면 번호가 없다 — --init 먼저'))
            continue
        if not (title or '').strip() or not (contents or '').strip():
            bad.append((screen, icon, lang, '제목이나 본문이 비었다'))
            continue
        p = draft_path(no, lang)
        if os.path.exists(p) and not force:
            skip.append((no, lang, p))
            continue
        if write:
            write_draft(no, lang, title, contents)
        done.append((no, lang, screen, upd, p))
    return done, skip, bad


def apply_drafts(conn, dry=True):
    """초안 → `sys_manual_asset_v2` (멱등 — 같은 (화면, 언어)는 덮어쓴다)."""
    n_ins = n_upd = n_skip = 0
    for no, lang, path in drafts():
        r = conn.execute("SELECT screen_code, area FROM sys_manual_screen "
                         " WHERE manual_no=?", (no,)).fetchone()
        if not r:
            print('  !! M%d — 등록 안 된 화면(건너뜀)' % no)
            n_skip += 1
            continue
        code, area = r
        d = parse_draft(io.open(path, encoding='utf-8').read())
        if not d or not d['title'] or not d['contents']:
            print('  !! M%d.%s — 제목이나 본문이 비었다(건너뜀)' % (no, lang))
            n_skip += 1
            continue
        cur = conn.execute(
            "SELECT manual_id FROM sys_manual_asset_v2 "
            " WHERE screen_code=? AND icon_key='MAIN' AND UPPER(lang_code)=?",
            (code, lang)).fetchone()
        if cur:
            n_upd += 1
            if not dry:
                conn.execute(
                    "UPDATE sys_manual_asset_v2 SET title=?, contents=?, "
                    "  record_status='LIVE', updated_at=datetime('now') "
                    " WHERE manual_id=?", (d['title'], d['contents'], cur[0]))
        else:
            n_ins += 1
            if not dry:
                conn.execute(
                    "INSERT INTO sys_manual_asset_v2"
                    "(user_type, area_code, screen_code, icon_key, title, "
                    " contents, lang_code, record_status, created_at) "
                    "VALUES('USER',?,?,'MAIN',?,?,?,'LIVE',datetime('now'))",
                    (area, code, d['title'], d['contents'], lang))
    if not dry:
        conn.commit()
    return n_ins, n_upd, n_skip


# ── 자가 검증 ────────────────────────────────────────────────────────────
def _selftest():
    ok = True

    def chk(name, cond, extra=''):
        nonlocal ok
        print(('  PASS ' if cond else '  FAIL ') + name +
              (' ' + str(extra) if extra else ''))
        if not cond:
            ok = False

    # ① 번호 규칙 — 겹치지 않고, 구역과 백의 자리가 맞는다
    nos = [s[0] for s in SCREENS]
    chk('번호가 안 겹친다', len(nos) == len(set(nos)))
    codes = [s[1] for s in SCREENS]
    chk('코드가 안 겹친다', len(codes) == len(set(codes)))
    band = {'P1': 1, 'P2': 2, 'P4': 4, 'POPUP': 8, 'ADMIN': 9}
    bad = [(n, a) for n, _c, a, _nm, _p in SCREENS if n // 100 != band.get(a)]
    chk('백의 자리 = 구역', not bad, bad)
    chk('자리를 다 적었다', all(s[4] for s in SCREENS))

    # ② 표가 제대로 생기나 — **실 DB 에 만들고 되돌린다**
    conn = appdb.connect()
    init_schema(conn)
    m = conn.execute("SELECT COUNT(*) FROM main.sqlite_master "
                     " WHERE type='table' AND name='user_manual_asset_v2'"
                     ).fetchone()[0]
    u = conn.execute("SELECT COUNT(*) FROM userdb.sqlite_master "
                     " WHERE type='table' AND name='user_manual_asset_v2'"
                     ).fetchone()[0]
    chk('사용자 수정본 표는 userdb 에만', m == 0 and u == 1, 'main %d/user %d' % (m, u))

    # ③ 팝업이 쓰는 SQL 이 실제로 돈다 (여기가 넉 달간 막혀 있던 자리)
    try:
        conn.execute("SELECT title, contents FROM user_manual_asset_v2 "
                     " WHERE origin_id=? AND UPPER(lang_code)=?", (-1, 'KO')
                     ).fetchall()
        chk('팝업 조회 SQL 이 돈다', True)
    except Exception as e:
        chk('팝업 조회 SQL 이 돈다', False, e)

    # ④ 화면 등록 — 멱등
    seed_screens(conn)
    n1 = conn.execute("SELECT COUNT(*) FROM sys_manual_screen").fetchone()[0]
    seed_screens(conn)
    n2 = conn.execute("SELECT COUNT(*) FROM sys_manual_screen").fetchone()[0]
    chk('두 번 등록해도 안 는다', n1 == n2, '%d → %d' % (n1, n2))
    chk('15곳이 다 들었다', n2 >= len(SCREENS), n2)
    chk('번호 조회', label_of(conn, 'U_P2_FLOW') == 'M203',
        label_of(conn, 'U_P2_FLOW'))
    chk('없는 화면은 코드를 그대로', label_of(conn, 'NO_SUCH') == 'NO_SUCH')

    # ⑤ 초안 파일 규약 — 쓰고 읽고 지운다
    d = parse_draft('# 제목입니다\n\n첫 줄.\n둘째 줄.')
    chk('초안 파싱', d and d['title'] == '제목입니다'
        and d['contents'].startswith('첫 줄'), d)
    p = write_draft(999, 'KO', '시험', '몸통')
    got = read_draft(999, 'KO')
    chk('초안 왕복', got and got['title'] == '시험' and got['contents'] == '몸통', got)
    found = [x for x in drafts() if x[0] == 999]
    chk('초안 목록에 잡힌다', len(found) == 1, found)

    # ⑥ 등록 안 된 번호는 적재하지 않는다
    ins, upd, skip = apply_drafts(conn, dry=True)
    chk('등록 안 된 번호는 건너뛴다', skip >= 1, 'skip=%d' % skip)

    os.remove(p)
    if os.path.isdir(DRAFT_DIR) and not os.listdir(DRAFT_DIR):
        os.rmdir(DRAFT_DIR)
    chk('시험 초안 물리 삭제', not os.path.exists(p))

    # ⑦ 사용자 수정본 흡수 — **미리보기는 파일도 DB 도 안 건드린다**
    #   ⚠ 자가 검증을 **데이터 상태에 걸지 않는다**(§0-5) — 사용자 수정본이
    #     0건이어도 정상이므로 「몇 건 나온다」로 재지 않고, **미리보기가
    #     아무것도 안 바꾼다**와 **문제 목록이 조용히 안 사라진다**만 잰다.
    n_user = conn.execute(
        "SELECT COUNT(*) FROM user_manual_asset_v2").fetchone()[0]
    before = sorted(os.listdir(DRAFT_DIR)) if os.path.isdir(DRAFT_DIR) else []
    done, skip2, bad2 = absorb_user(conn, write=False)
    after = sorted(os.listdir(DRAFT_DIR)) if os.path.isdir(DRAFT_DIR) else []
    chk('흡수 미리보기가 파일을 안 만든다', before == after,
        '수정본 %d건 · 꺼낼 것 %d' % (n_user, len(done)))
    chk('흡수 미리보기가 DB 를 안 바꾼다',
        conn.execute("SELECT COUNT(*) FROM user_manual_asset_v2").fetchone()[0]
        == n_user)
    chk('꺼낼 것 + 건너뛴 것 + 문제 = 수정본 이하',
        len(done) + len(skip2) + len(bad2) <= n_user)
    conn.close()
    print('RESULT:', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def _list(conn):
    print('%-6s %-22s %-6s %-24s %s' % ('번호', '코드', '구역', '이름', '매뉴얼'))
    for no, code, area, name, place in conn.execute(
            "SELECT manual_no, screen_code, area, name_ko, place "
            "  FROM sys_manual_screen WHERE record_status='LIVE' "
            " ORDER BY manual_no"):
        langs = [l for (l,) in conn.execute(
            "SELECT UPPER(lang_code) FROM sys_manual_asset_v2 "
            " WHERE screen_code=? AND record_status='LIVE' "
            "   AND TRIM(COALESCE(contents,''))<>'' ORDER BY 1", (code,))]
        print('M%-5d %-22s %-6s %-24s %s'
              % (no, code, area, name, ' '.join(langs) or '— 없음'))


def main():
    args = sys.argv[1:]
    if '--selftest' in args:
        raise SystemExit(_selftest())
    conn = appdb.connect()
    try:
        if '--init' in args:
            init_schema(conn)
            a, b = seed_screens(conn)
            print('표 준비됨 · 화면 새로 %d · 갱신 %d' % (a, b))
            _list(conn)
        elif '--list' in args:
            init_schema(conn)
            _list(conn)
        elif '--absorb' in args or '--absorb-write' in args:
            init_schema(conn)
            wr = '--absorb-write' in args
            done, skip, bad = absorb_user(conn, write=wr, force=('--force' in args))
            print('%s 꺼낼 것 %d · 이미 초안 있어 건너뜀 %d · 문제 %d'
                  % ('[씀]' if wr else '[미리보기]', len(done), len(skip), len(bad)))
            for no, lang, screen, upd, p in done:
                print('   M%-4d %-3s %-14s %s  →  %s'
                      % (no, lang, screen, upd, os.path.basename(p)))
            for no, lang, p in skip:
                print('   건너뜀 M%-4d %-3s (%s 이미 있음 — --force 로 덮는다)'
                      % (no, lang, os.path.basename(p)))
            for screen, icon, lang, why in bad:
                print('   ⚠ %s.%s %s — %s' % (screen, icon, lang, why))
            if done and not wr:
                print('   → 실제로 쓰려면 `--absorb-write`, 그 뒤 `--check` / `--apply`')
        elif '--check' in args or '--apply' in args:
            init_schema(conn)
            dry = '--apply' not in args
            print('초안 %d개' % len(drafts()))
            i, u, s = apply_drafts(conn, dry=dry)
            print('%s 새로 %d · 덮어씀 %d · 건너뜀 %d'
                  % ('(미리보기)' if dry else '적용', i, u, s))
        else:
            print(__doc__)
    finally:
        conn.close()


if __name__ == '__main__':
    main()
