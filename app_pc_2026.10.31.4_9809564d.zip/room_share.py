# -*- coding: utf-8 -*-
"""room_share.py — 공동체 묵상 3단계 · 나눔 (영구, 2026-09-08).

설계 = `정책자료/0.교회묵상.txt` §4-2 · §5-2 · §5-3 · §8 3단계.
1단계가 **나눌 파일**을, 2단계가 **누구와 나누는가**를 만들었고,
여기서 **내 글을 올리고 남의 글을 받는다**.

★★★ **파일 이름이 안전의 핵심이다**(§4-2) —
    `note_<uuid앞8자>_<날짜>.json`
  · 각자 **자기 id 로 시작하는 파일만** 만들고 고친다
  · 남의 파일은 **읽기만** 한다
  ⇒ **두 사람이 같은 파일을 만질 일이 구조적으로 없다. 충돌 0.**
  ⚠ 파일 권한으로 막는 것이 아니라 **앱이 규칙을 지킨다**(사용자 확정 ③-ⓐ).

★★★ **남의 글은 `user_data.db` 에 안 넣는다**(§1-③) — `room_<room_id>.db`
  라는 **별도 파일**에 담는다. `link_pack.db` 와 **같은 문법**이라
  ⓐ 배포분만 골라 지우는 수술이 필요 없고 ⓑ 내 글과 절대 안 섞이고
  ⓒ 방을 나가면 파일 하나만 지우면 된다.

★★ **`user_text_asset` 에 칸 둘**(§5-3) — `author_uuid`·`room_id`.
  ⚠⚠ **이것이 이 설계에서 유일하게 되돌리기 어려운 변경이다.**
    ★ **NULL 이 기본**이라 옛 글이 안 깨진다 — 전부 「내가 쓴 것」으로 읽힌다.
    ⚠ **남의 글은 여기 안 들어온다.** 이 칸이 필요한 까닭은
      **내보낼 때 「누가 썼나」를 파일에 적기 위해서**다.

★★ **전송은 `rss_transport.LocalDirTransport`** — 공유 폴더를 서버처럼 다룬다.
  클라우드 API 도 토큰도 필요 없다(§4-3). 폴더 동기화 클라이언트가 나른다.
  ⚠ **gzip 으로 올리지 않는다**(§195차 팩 규칙 ①) — JSON 글자 그대로.

사용:  python room_share.py --selftest | --status
"""
import io
import json
import os
import sqlite3
import sys
from datetime import datetime

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

FMT = 1
APP_MARK = 'hagah-note'          #: 나눔 파일 표식
KIND_NOTE = 'ROOM_NOTES'
SCHEMA = 'roomshare'             #: ATTACH 이름 — 한 번에 방 하나만 붙인다

#: ★★★ **공동체 묵상의 단위는 「플랜 하루」다**(2026-09-08 사용자 확정 —
#:   「공동체 묵상은 **구절단위가 아니라 하루 할당된 구절 전체 단위**」 ·
#:   「**p2와 차별화**해야 함」 · 「**플랜 날자 단위로 처리하는 것이 기본**」).
#:   ⚠⚠ **앞선 판이 축을 잘못 잡았다** — 구절(`VERS_NOTE`)로 만들었더니
#:     P2 묵상노트와 하는 일이 같아져 **공동체의 특성이 사라졌다.**
#:     P2 = 「이 구절에 대한 내 생각」 / 공동체 = 「오늘 읽은 범위 전체」.
NOTE_TYPE = 'ROOM_NOTE'
#: 앵커 — `<plan_code>|<day>`. **번호가 아니라 자연 열쇠**(`plan_code` 는
#: 실측 164개가 전부 유일하다). 배포가 갈려도 안 어긋난다.
ANCHOR_DAY = 'PLAN_DAY'
#: ★ **구절은 덤이다**(사용자 「본인이 원하면 구절과 연결하는 기능 · 그러면
#:   p2에 자동추가」) — 붙이면 P2 「함께 나눈 글」에도 뜨고, 안 붙이면 이
#:   방의 그 날짜에서만 보인다.

_DDL = (
    """CREATE TABLE IF NOT EXISTS room_member (
        member_id    TEXT PRIMARY KEY,
        display_name TEXT,
        cohort       TEXT,
        role         TEXT,
        last_seen    TEXT,
        record_status TEXT NOT NULL DEFAULT 'LIVE')""",
    """CREATE TABLE IF NOT EXISTS room_note (
        note_id      TEXT PRIMARY KEY,
        member_id    TEXT NOT NULL,
        display_name TEXT,
        cohort       TEXT,
        anchor_kind  TEXT NOT NULL,
        anchor_key   TEXT NOT NULL,
        verse_key    TEXT,
        title        TEXT,
        contents     TEXT,
        lang_code    TEXT,
        written_at   TEXT,
        record_status TEXT NOT NULL DEFAULT 'LIVE')""",
    "CREATE INDEX IF NOT EXISTS ix_room_note_anchor "
    "ON room_note(anchor_kind, anchor_key)",
    # ★ 구절을 붙인 글만 P2 에 뜬다 — 그 조회를 위한 색인
    "CREATE INDEX IF NOT EXISTS ix_room_note_verse ON room_note(verse_key)",
    """CREATE TABLE IF NOT EXISTS room_meta (
        k TEXT PRIMARY KEY, v TEXT)""",
    # ★★★ **방 공지 — 방장만 올린다**(2026-09-08 사용자 확정).
    #   ⚠ `member_id` 를 함께 담는다 — 「누가 올렸나」를 안 담으면 나중에
    #     방장이 바뀌었을 때 옛 공지를 가릴 수 없다.
    """CREATE TABLE IF NOT EXISTS room_notice (
        notice_id    TEXT PRIMARY KEY,
        member_id    TEXT NOT NULL,
        display_name TEXT,
        title        TEXT,
        contents     TEXT,
        lang_code    TEXT,
        written_at   TEXT,
        record_status TEXT NOT NULL DEFAULT 'LIVE')""",
    # ★★★ **방 게시판**(4단계 · 2026-09-08 사용자 확정 흐름) — 인사 · 지침 ·
    #   교재 첨부 · 마무리 인사. **누구나 쓴다**(인사말을 주고받는다) — 다만
    #   지침·마무리(`LEADER_KINDS`)는 방장 파일에서 온 것만 받는다.
    #   ⚠ 공지(`room_notice`)와 다르다 — 공지는 띠 한 줄, 게시판은 흐름이다.
    """CREATE TABLE IF NOT EXISTS room_post (
        post_id      TEXT PRIMARY KEY,
        member_id    TEXT NOT NULL,
        display_name TEXT,
        kind         TEXT,
        title        TEXT,
        contents     TEXT,
        attach_json  TEXT,
        lang_code    TEXT,
        written_at   TEXT,
        record_status TEXT NOT NULL DEFAULT 'LIVE')""",
)

#: 공지는 **내 쪽에도** 글로 남는다(방장이 쓴 원본) — 유형 하나.
#: ⚠ 나눔글(`ROOM_NOTE`)과 **갈라 둔다** — 한 유형이면 공지가 그날 묵상으로
#:   세어져 「썼다」로 잡힌다.
NOTICE_TYPE = 'ROOM_NOTICE'

#: ★★★ 게시판 글 — 내 쪽 원본 유형. 갈래는 `origin_key = 'POST|<kind>'`.
POST_TYPE = 'ROOM_POST'
#: 갈래 — 인사 · 지침 · 마무리 인사 · 그 밖(사용자 확정 흐름: 관리자가 서로
#: 인사하라고 한다 → 멤버들이 인사말 → 관리자가 지침 → … → 마지막 인사).
POST_KINDS = ('GREET', 'GUIDE', 'CLOSE', 'POST')
#: 방장만 쓰는 갈래 — 화면과 받는 쪽 **둘 다** 가린다(문을 둘로 막는다).
LEADER_KINDS = ('GUIDE', 'CLOSE')
#: 첨부 파일 이름 — `file_<uuid앞8자>_<이름>`. 나눔 파일과 **같은 규칙**이라
#: 남의 파일을 덮어쓸 일이 구조적으로 없다.
ATTACH_PFX = 'file_'


def _now():
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


# ── 내 글 쪽 — `user_text_asset` 칸 둘 ────────────────────────────────
def ensure_cols(conn):
    """`author_uuid`·`room_id` 칸을 만든다 — **멱등**(§5-3).

    ⚠⚠ **되돌리기 어려운 변경이라 여기 한 곳에서만 한다.**
      ★ **NULL 이 기본** — 옛 글 전부가 그대로 「내가 쓴 것」으로 읽힌다.
    """
    have = {r[1] for r in conn.execute("PRAGMA userdb.table_info(user_text_asset)")}
    if not have:      # userdb 가 안 붙은 연결 — main 을 본다
        have = {r[1] for r in conn.execute("PRAGMA table_info(user_text_asset)")}
    pfx = _pfx(conn)
    # ⚠ `origin_key` 는 덮개 시스템이 쓰는 **자연 열쇠 자리**이고 여기서
    #   **하루 앵커**(`<plan_code>|<day>`)를 담는다. 실 DB 에는 이미 있지만
    #   옛 판 사용자 DB 에는 없을 수 있어 함께 만든다(멱등이라 무해하다).
    # ⚠ `attach_json` — 게시판 글의 첨부 파일 이름 목록(4단계). NULL 이 기본.
    for col in ('author_uuid', 'room_id', 'origin_key', 'attach_json'):
        if col not in have:
            conn.execute("ALTER TABLE %suser_text_asset ADD COLUMN %s TEXT"
                         % (pfx, col))
    conn.commit()
    return True


def _pfx(conn):
    """표 접두 — **연결에 따라 다르다**(`room_core._pfx` 와 같은 규칙)."""
    try:
        for r in conn.execute('PRAGMA database_list'):
            if r[1] == 'userdb':
                return 'userdb.'
    except Exception:
        pass
    return ''


# ── 방 파일 ──────────────────────────────────────────────────────────
def room_path(room_id, db_path=None):
    """방 파일 자리 — **본체 옆**(`link_pack.pack_path` 와 같은 규약)."""
    if db_path:
        base = os.path.dirname(os.path.abspath(str(db_path)))
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, 'room_%s.db' % str(room_id)[:16])


def ensure_room(room_id, db_path=None):
    """방 파일과 표를 만든다(멱등) → 경로."""
    p = room_path(room_id, db_path)
    c = sqlite3.connect(p)
    try:
        for sql in _DDL:
            c.execute(sql)
        c.commit()
    finally:
        c.close()
    return p


def attach(conn, room_id, db_path=None):
    """열려 있는 연결에 방 파일을 붙인다 → 붙었나(bool).

    ⚠ **없으면 조용히 False** — 아직 아무것도 안 받은 사람에게도 앱은 그대로
      돌아야 한다(`link_pack.attach` 와 같은 규칙).
    ⚠ **한 번에 방 하나만** 붙는다 — 다른 방이 붙어 있으면 먼저 뗀다.
    """
    p = room_path(room_id, db_path)
    if not os.path.exists(p):
        return False
    try:
        for _sid, name, f in conn.execute('PRAGMA database_list'):
            if name == SCHEMA:
                if os.path.abspath(f or '') == os.path.abspath(p):
                    return True
                conn.execute('DETACH DATABASE %s' % SCHEMA)
                break
        conn.execute("ATTACH DATABASE ? AS %s" % SCHEMA, (p,))
        return True
    except Exception:
        return False


def detach(conn):
    try:
        conn.execute('DETACH DATABASE %s' % SCHEMA)
        return True
    except Exception:
        return False


# ── 내 글 내보내기 ───────────────────────────────────────────────────
def _anchor_of(conn, note_row):
    """구절 번호 → **자연 열쇠**(`창 1:1`).

    ★★★ **번호를 싣지 않는다**(§5-2) — 최종관리자가 배포를 갈면 번호가
      달라질 수 있는데 교회 폴더는 그 주기와 무관하다.
    """
    import scripture_ref_kr as SR
    vid = note_row['clicked_id']
    r = conn.execute(
        "SELECT b.full_name, i.chapter, i.verse FROM bible_index i "
        "JOIN book_names b ON b.book_code=i.bcode AND b.lang_code='KO' "
        "WHERE i.verse_id=?", (vid,)).fetchone()
    if not r:
        return None
    return '%s %d:%d' % (r[0], r[1], r[2])


def _resolve(conn, anchor_key):
    """자연 열쇠 → 구절 번호. **못 풀면 None**(건너뛰고 몇 건인지 말한다)."""
    try:
        import scripture_ref_kr as SR
        got = SR.resolve(conn, anchor_key)
        if isinstance(got, tuple):
            got = got[0]
        return got
    except Exception:
        return None


# ── 플랜 하루 — 이 설계의 축 ─────────────────────────────────────────
def day_key(plan_code, day):
    """`<plan_code>|<day>` — **번호가 아니라 자연 열쇠**."""
    return '%s|%d' % (str(plan_code or '').strip(), int(day or 0))


def split_day(key):
    """열쇠를 되푼다 → `(plan_code, day)` · 못 풀면 `(None, None)`."""
    try:
        a, b = str(key or '').rsplit('|', 1)
        return a, int(b)
    except Exception:
        return None, None


def day_span(conn, plan_code, day):
    """그 날 몫의 **구절 범위** → `(start_vid, end_vid)` · 없으면 `(None,None)`.

    ⚠ **하루는 여러 줄일 수 있다**(실측 최대 28줄 — 맥체인 4트랙·연대기).
      ⇒ **가장 앞과 가장 뒤**를 낸다. 그것이 「오늘 읽은 범위 전체」다.
    ⚠ sys 플랜과 사용자 파생 플랜을 **둘 다** 본다 — 방장이 만든 플랜을
      참여자가 등록했을 수 있다.
    """
    for tbl, idc, sch in (('sys_bible_plan', 'plan_id', 'sys_plan_schedule'),
                          ('userdb.user_bible_plan', 'user_plan_id',
                           'userdb.user_plan_schedule')):
        try:
            r = conn.execute("SELECT %s FROM %s WHERE plan_code=?" % (idc, tbl),
                             (plan_code,)).fetchone()
            if not r:
                continue
            g = conn.execute(
                "SELECT MIN(start_vid), MAX(COALESCE(end_vid,start_vid)) FROM %s "
                "WHERE %s=? AND day=?" % (sch, idc), (r[0], day)).fetchone()
            if g and g[0]:
                return g[0], g[1] or g[0]
        except Exception:
            continue
    return None, None


def day_label(conn, plan_code, day, lang='KO'):
    """화면에 적을 이름 — `창1:1~창2:3` 꼴. 못 읽으면 열쇠 그대로."""
    s_, e_ = day_span(conn, plan_code, day)
    if not s_:
        return day_key(plan_code, day)
    try:
        import db_media_range as MR
        return MR.span_label(conn, s_, e_)
    except Exception:
        return '%s~%s' % (s_, e_)


def my_notes(conn, room_id=None):
    """내가 쓴 **공동체 묵상 글** → dict 목록.

    ★★★ **앵커는 「플랜 하루」다**(사용자 확정) — `origin_key` 에 담는다.
      그 칸은 `user_text_asset` 에 **이미 있고**(자연 열쇠 자리) 새 칸을
      만들 필요가 없다.
    ★ `clicked_id` 는 **선택** — 「구절과 연결」을 눌렀을 때만 찬다.
      ⚠ 그래서 **`clicked_id IS NOT NULL` 을 요구하지 않는다**(앞선 판의 조건).
    """
    ensure_cols(conn)
    pfx = _pfx(conn)
    sql = ("SELECT user_text_id, clicked_id, title, contents, lang_code, "
           "COALESCE(updated_at, created_at), origin_key "
           "FROM %suser_text_asset "
           "WHERE text_type=? AND COALESCE(record_status,'') <> 'HIDE' "
           "AND COALESCE(contents,'') <> '' AND COALESCE(origin_key,'') <> ''"
           % pfx)
    args = [NOTE_TYPE]
    if room_id:
        sql += " AND COALESCE(room_id,'')=?"
        args.append(room_id)
    out = []
    for r in conn.execute(sql + " ORDER BY user_text_id", args):
        out.append({'pk': r[0], 'clicked_id': r[1], 'title': r[2] or '',
                    'contents': r[3] or '', 'lang_code': r[4] or 'KO',
                    'at': r[5] or '', 'day_key': r[6] or ''})
    return out


def save_note(conn, room_id, plan_code, day, contents, title='',
              verse_id=None, pk=None, lang='KO'):
    """내 공동체 묵상 글을 쓴다/고친다 → `pk`.

    ★ **하루에 한 편**이 기본이라 같은 (방, 날짜)면 **덮어쓴다** — 여러 편을
      허용하면 「오늘 몫 나눔」이 아니라 게시판이 된다.
    ★ `verse_id` 를 주면 **P2 에도 뜬다**(사용자 「본인이 원하면 구절과 연결 ·
      그러면 p2에 자동추가」). 안 주면 이 방의 그 날짜에서만 보인다.
    ⚠ **빈 글은 지운다**(HIDE) — 빈 카드를 남기면 목록이 더러워진다.
    """
    ensure_cols(conn)
    pfx = _pfx(conn)
    key = day_key(plan_code, day)
    body = (contents or '').strip()
    if pk is None:
        r = conn.execute(
            "SELECT user_text_id FROM %suser_text_asset WHERE text_type=? "
            "AND COALESCE(origin_key,'')=? AND COALESCE(room_id,'')=? "
            "AND COALESCE(record_status,'') <> 'HIDE'" % pfx,
            (NOTE_TYPE, key, room_id or '')).fetchone()
        pk = r[0] if r else None
    if not body:
        if pk:
            conn.execute("UPDATE %suser_text_asset SET record_status='HIDE' "
                         "WHERE user_text_id=?" % pfx, (pk,))
            conn.commit()
        return pk
    if pk:
        conn.execute(
            "UPDATE %suser_text_asset SET title=?, contents=?, clicked_id=?, "
            "lang_code=?, updated_at=?, record_status='EDIT' "
            "WHERE user_text_id=?" % pfx,
            (title or '', body, verse_id, lang, _now(), pk))
    else:
        cur = conn.execute(
            "INSERT INTO %suser_text_asset(clicked_id,text_type,title,contents,"
            "lang_code,record_status,created_at,updated_at,origin_key,room_id) "
            "VALUES(?,?,?,?,?, 'NEW', ?,?,?,?)" % pfx,
            (verse_id, NOTE_TYPE, title or '', body, lang, _now(), _now(),
             key, room_id or ''))
        pk = cur.lastrowid
    conn.commit()
    return pk


def note_of_day(conn, room_id, plan_code, day):
    """그 날짜에 내가 쓴 글 → dict 또는 None."""
    key = day_key(plan_code, day)
    for n in my_notes(conn, room_id):
        if n['day_key'] == key:
            return n
    return None


def export_notes(conn, room_id, my_name='', pick=None, db_path=None):
    """내 나눔글을 파일 내용(dict)으로 → `(draft, skipped)`.

    ★ **자기 id 로 시작하는 파일 하나**에 내 글을 전부 담는다(§4-2).
      매번 통째로 올리므로 **고친 것·지운 것이 저절로 반영된다**(전체본 문법).
    ⚠ **못 푸는 자리는 건너뛰고 몇 건인지 말한다**(§0-1).
    """
    import room_core as RC
    uid = RC.my_uuid(conn)
    rows, skipped = [], []
    for n in my_notes(conn, room_id):
        if pick is not None and n['pk'] not in pick:
            continue
        if not n['day_key']:
            skipped.append(n['pk'])
            continue
        rows.append({
            'note_id': '%s_%d' % (uid[:8], n['pk']),   # ★ 자연 열쇠
            'anchor_kind': ANCHOR_DAY, 'anchor_key': n['day_key'],
            # ★ 구절은 **덤** — 붙였을 때만 싣는다(자연 열쇠로).
            'verse_key': _anchor_of(conn, n) if n['clicked_id'] else '',
            'title': n['title'], 'contents': n['contents'],
            'lang_code': n['lang_code'], 'written_at': n['at'],
        })
    draft = {
        'app': APP_MARK, 'fmt': FMT, 'kind': KIND_NOTE,
        'room_id': room_id, 'member_id': uid,
        'display_name': (my_name or '').strip(),
        'made_at': _now(), 'notes': rows,
        # ★ 게시판 글은 **누구나** 싣는다(인사말) — 갈래 검사는 받는 쪽이 한다.
        'posts': my_posts(conn, room_id),
    }
    # ★★★ **방장 파일은 방의 이름과 플랜을 함께 나른다**(4단계) — 방장이
    #   이름을 바꾸거나 플랜을 정하면 참여자가 받아 적는다. 초대 파일을 다시
    #   만들 필요가 없다.
    try:
        import room_core as RC
        r = RC.room(conn, room_id) or {}
        draft['role'] = r.get('my_role') or 'MEMBER'
        if r.get('my_role') == RC.ROLE_LEADER:
            draft['room_name'] = r.get('room_name') or ''
            draft['plan_code'] = r.get('plan_code') or ''
            draft['plan_start'] = r.get('plan_start') or ''
            draft['co_leaders'] = RC.co_leaders(r)
        if r.get('my_role') in RC.MANAGER_ROLES:
            # ★ 5단계 — 마무리 상태 · **가린 참여자 목록**(방 전체에 전해진다).
            #   부방장 파일에서도 받는다(운영자 둘이 같은 것을 다룬다).
            draft['room_status'] = r.get('room_status') or 'OPEN'
            draft['closed_at'] = r.get('closed_at') or ''
            draft['status_at'] = r.get('status_at') or ''
            draft['hidden'] = hidden_members(conn, room_id, db_path)
            draft['hidden_at'] = _get_hidden_at(conn) if attach(conn, room_id, db_path) else ''
    except Exception:
        pass
    # ★★★ **공지는 방장의 파일에만 실린다** — 받는 쪽이 방장 번호와 대조해
    #   가리지만, 애초에 방장이 아니면 **싣지도 않는다**(문을 둘로 막는다).
    try:
        import room_core as RC
        if RC.can_notice(conn, room_id)[0]:
            # ★ 0건이어도 **열쇠는 싣는다** — 받는 쪽이 「방장이 지웠다」를
            #   알 수 있는 유일한 신호다(빈 목록 = 공지 없음).
            draft['notices'] = my_notices(conn, room_id)
    except Exception:
        pass
    return draft, skipped


# ── 방 공지 — **방장만** ─────────────────────────────────────────────
def my_notices(conn, room_id):
    """내가 쓴 공지(원본) → dict 목록. **최근이 위.**"""
    pfx = _pfx(conn)
    out = []
    for r in conn.execute(
            "SELECT user_text_id,title,contents,lang_code,"
            "COALESCE(updated_at,created_at) FROM %suser_text_asset "
            "WHERE text_type=? AND COALESCE(room_id,'')=? "
            "AND COALESCE(record_status,'') <> 'HIDE' "
            "ORDER BY COALESCE(updated_at,created_at) DESC" % pfx,
            (NOTICE_TYPE, room_id or '')):
        out.append({'notice_id': str(r[0]), 'title': r[1] or '',
                    'contents': r[2] or '', 'lang_code': r[3] or 'KO',
                    'written_at': r[4] or ''})
    return out


def save_notice(conn, room_id, contents, title='', pk=None, lang='KO'):
    """공지를 쓴다 → PK. **방장이 아니면 거부한다.**

    ⚠ **화면이 아니라 여기서 막는다** — 입구가 늘어도 안 샌다(§97차 규칙).
    ⚠ 빈 글이면 지운다(HIDE) — 「지우기」 단추를 따로 두지 않는다.
    """
    import room_core as RC
    ok, why = RC.can_notice(conn, room_id)
    if not ok:
        raise ValueError('NOT_ALLOWED:%s' % why)
    ensure_cols(conn)
    pfx = _pfx(conn)
    body = (contents or '').strip()
    uid = RC.my_uuid(conn)
    if pk and not body:
        conn.execute("UPDATE %suser_text_asset SET record_status='HIDE',"
                     " updated_at=? WHERE user_text_id=?" % pfx, (_now(), pk))
        conn.commit()
        return None
    if not body:
        return None
    if pk:
        conn.execute("UPDATE %suser_text_asset SET title=?, contents=?,"
                     " lang_code=?, record_status='NEW', updated_at=?"
                     " WHERE user_text_id=?" % pfx,
                     ((title or '').strip(), body, lang, _now(), pk))
        conn.commit()
        return pk
    cur = conn.execute(
        "INSERT INTO %suser_text_asset(clicked_id,text_type,title,contents,"
        "lang_code,record_status,created_at,updated_at,author_uuid,room_id) "
        "VALUES(NULL,?,?,?,?,'NEW',?,?,?,?)" % pfx,
        (NOTICE_TYPE, (title or '').strip(), body, lang, _now(), _now(),
         uid, room_id or ''))
    conn.commit()
    return cur.lastrowid


def notices(conn, room_id, db_path=None):
    """그 방의 공지 → dict 목록(내 것 + 받은 것, 최근이 위).

    ★★★ **방 단위로만 조회된다**(2026-09-08 사용자 「방 단위로만 조회 가능」) —
      `room_id` 없이 부를 길이 없고, 받은 것은 그 방 파일에만 있다.
    """
    out = []
    try:
        import room_core as RC
        if RC.can_notice(conn, room_id)[0]:
            for x in my_notices(conn, room_id):
                x = dict(x)
                x['name'] = (RC.room(conn, room_id) or {}).get('my_name') or ''
                x['mine'] = True
                out.append(x)
    except Exception:
        pass
    if attach(conn, room_id, db_path):
        try:
            for r in conn.execute(
                    "SELECT notice_id,display_name,title,contents,written_at "
                    "FROM %s.room_notice WHERE COALESCE(record_status,'')"
                    " <> 'HIDE' ORDER BY written_at DESC" % SCHEMA):
                out.append({'notice_id': r[0], 'name': r[1] or '',
                            'title': r[2] or '', 'contents': r[3] or '',
                            'written_at': r[4] or '', 'mine': False})
        except Exception:
            pass
    out.sort(key=lambda x: x.get('written_at') or '', reverse=True)
    return out


# ── 방 게시판 — 4단계 ────────────────────────────────────────────
def my_posts(conn, room_id):
    """내가 쓴 게시판 글(원본) → dict 목록. **오래된 것이 위**(흐름이다)."""
    ensure_cols(conn)
    pfx = _pfx(conn)
    out = []
    for r in conn.execute(
            "SELECT user_text_id,title,contents,lang_code,"
            "COALESCE(updated_at,created_at),origin_key,attach_json "
            "FROM %suser_text_asset "
            "WHERE text_type=? AND COALESCE(room_id,'')=? "
            "AND COALESCE(record_status,'') <> 'HIDE' "
            "ORDER BY created_at, user_text_id" % pfx,
            (POST_TYPE, room_id or '')):
        kind = (r[5] or '').split('|', 1)[-1] if r[5] else 'POST'
        try:
            files = json.loads(r[6]) if r[6] else []
        except Exception:
            files = []
        out.append({'post_id': str(r[0]), 'kind': kind if kind in POST_KINDS
                    else 'POST', 'title': r[1] or '', 'contents': r[2] or '',
                    'files': [str(x) for x in files if x],
                    'lang_code': r[3] or 'KO', 'written_at': r[4] or ''})
    return out


def save_post(conn, room_id, kind, contents, title='', files=None, pk=None,
              lang='KO'):
    """게시판 글을 쓴다/고친다 → PK.

    ★ **누구나 쓴다** — 인사말을 주고받는 자리다(사용자 확정 흐름).
    ⚠ 지침·마무리(`LEADER_KINDS`)는 **방장만** — 화면이 아니라 여기서 막는다.
    ⚠ 글도 첨부도 없으면 지운다(HIDE).
    """
    import room_core as RC
    kind = (kind or 'POST').upper()
    if kind not in POST_KINDS:
        raise ValueError('BAD_KIND:%s' % kind)
    if kind in LEADER_KINDS:
        ok, why = RC.can_notice(conn, room_id)
        if not ok:
            raise ValueError('NOT_ALLOWED:%s' % why)
    ensure_cols(conn)
    pfx = _pfx(conn)
    body = (contents or '').strip()
    files = [str(x) for x in (files or []) if x]
    uid = RC.my_uuid(conn)
    if pk and not body and not files:
        conn.execute("UPDATE %suser_text_asset SET record_status='HIDE',"
                     " updated_at=? WHERE user_text_id=?" % pfx, (_now(), pk))
        conn.commit()
        return None
    if not body and not files:
        return None
    aj = json.dumps(files, ensure_ascii=False) if files else None
    if pk:
        conn.execute("UPDATE %suser_text_asset SET title=?, contents=?,"
                     " lang_code=?, origin_key=?, attach_json=?,"
                     " record_status='NEW', updated_at=? WHERE user_text_id=?"
                     % pfx,
                     ((title or '').strip(), body, lang, 'POST|' + kind, aj,
                      _now(), pk))
        conn.commit()
        return pk
    cur = conn.execute(
        "INSERT INTO %suser_text_asset(clicked_id,text_type,title,contents,"
        "lang_code,record_status,created_at,updated_at,author_uuid,room_id,"
        "origin_key,attach_json) VALUES(NULL,?,?,?,?,'NEW',?,?,?,?,?,?)" % pfx,
        (POST_TYPE, (title or '').strip(), body, lang, _now(), _now(),
         uid, room_id or '', 'POST|' + kind, aj))
    conn.commit()
    return cur.lastrowid


def posts(conn, room_id, db_path=None):
    """그 방의 게시판 → dict 목록(내 것 + 받은 것, **오래된 것이 위**).

    ★ 흐름을 읽는 자리라 시간순이다 — 인사 → 지침 → … → 마무리.
    """
    out = []
    try:
        import room_core as RC
        r = RC.room(conn, room_id) or {}
        me = (r.get('my_name') or '').strip()
        lead = (r.get('my_role') == RC.ROLE_LEADER)
        for x in my_posts(conn, room_id):
            x = dict(x)
            x['name'] = me or '(나)'
            x['mine'] = True
            x['leader'] = lead
            x['co'] = (r.get('my_role') == RC.ROLE_CO)
            out.append(x)
    except Exception:
        pass
    if attach(conn, room_id, db_path):
        lead_uuid, cos = '', set()
        try:
            import room_core as RC2
            _r = RC2.room(conn, room_id) or {}
            lead_uuid = (_r.get('leader_uuid') or '').strip()
            cos = set(RC2.co_leaders(_r))
        except Exception:
            pass
        try:
            for r in conn.execute(
                    "SELECT post_id,member_id,display_name,kind,title,contents,"
                    "attach_json,written_at FROM %s.room_post "
                    "WHERE COALESCE(record_status,'LIVE')='LIVE' "
                    "ORDER BY written_at, post_id" % SCHEMA):
                try:
                    files = json.loads(r[6]) if r[6] else []
                except Exception:
                    files = []
                out.append({'post_id': r[0], 'member_id': r[1],
                            'name': r[2] or '(이름 없음)', 'kind': r[3] or 'POST',
                            'title': r[4] or '', 'contents': r[5] or '',
                            'files': [str(x) for x in files if x],
                            'written_at': r[7] or '', 'mine': False,
                            'leader': bool(lead_uuid) and r[1] == lead_uuid,
                            'co': r[1] in cos})
        except Exception:
            pass
    out.sort(key=lambda x: x.get('written_at') or '')
    return out


def _safe_name(name):
    base = os.path.basename(str(name or '')).strip()
    base = ''.join(ch for ch in base if ch not in '\\/:*?"<>|').strip()
    return base or 'file'


def attach_file(folder, uid, src_path):
    """교재 파일을 방 폴더에 담는다 → 폴더 안 이름.

    ★★★ **참여자는 구글드라이브에 들어가지 않는다**(사용자 확정 — 「참가자들이
      구글드라이브에 들어갈 것이라고 가정하는 이유를 모르겠다」). 방장이 여기서
      올리면 동기화 클라이언트가 나르고 참여자는 **앱 안에서** 연다.
    ⚠ 이름 규칙 = `file_<내 id 앞8자>_<원래 이름>` — 나눔 파일과 같은 규칙.
      남의 파일과 이름이 겹칠 일이 구조적으로 없다.
    """
    import shutil
    if not (src_path and os.path.isfile(src_path)):
        raise IOError('NO_SRC')
    os.makedirs(folder, exist_ok=True)
    name = '%s%s_%s' % (ATTACH_PFX, str(uid)[:8], _safe_name(src_path))
    shutil.copyfile(src_path, os.path.join(folder, name))
    return name


def attach_path(folder, name):
    """첨부 이름 → 폴더 안 실제 경로. **없으면 None**(동기화가 아직일 수 있다)."""
    nm = _safe_name(name)
    if not (folder and nm.startswith(ATTACH_PFX)):
        return None
    p = os.path.join(folder, nm)
    return p if os.path.isfile(p) else None


def attach_kind(path):
    """첨부가 무엇인가 → 'PACK'(이 앱의 자료 파일) · 'LENS' · 'FILE'.

    ★ 자료 파일(`share_pack` — 묵상노트·연구자료·구절연결·렌즈 한 벌)을
      게시판에 첨부하면 참여자가 **그 자리에서 앱에 담는다.** 「연구자산을
      나눌 다른 방법」이 따로 필요 없는 까닭이다.
    """
    try:
        if not str(path).lower().endswith('.json'):
            return 'FILE'
        with io.open(path, encoding='utf-8') as f:
            head = f.read(400)
        if '"hagah-share"' in head:
            return 'PACK'
        if '"hagah-lens"' in head:
            return 'LENS'
    except Exception:
        pass
    return 'FILE'


# ── 5단계 — 참여자 가리기 ─────────────────────────────────────────
HIDDEN_KEY = 'hidden_members'
HIDDEN_AT_KEY = 'hidden_at'      # ★ 가림 목록의 시각 — 운영자 둘의 파일이 다툴 때 새것이 이긴다


def _get_hidden(conn):
    try:
        r = conn.execute("SELECT v FROM %s.room_meta WHERE k=?" % SCHEMA,
                         (HIDDEN_KEY,)).fetchone()
        v = json.loads(r[0]) if r and r[0] else []
        return [str(x) for x in v if x]
    except Exception:
        return []


def _set_hidden(conn, ids, at=None):
    conn.execute("INSERT OR REPLACE INTO %s.room_meta(k,v) VALUES(?,?)" % SCHEMA,
                 (HIDDEN_KEY, json.dumps(sorted(set(str(x) for x in ids if x)))))
    conn.execute("INSERT OR REPLACE INTO %s.room_meta(k,v) VALUES(?,?)" % SCHEMA,
                 (HIDDEN_AT_KEY, _now() if at is None else at))
    conn.commit()


def _get_hidden_at(conn):
    try:
        r = conn.execute("SELECT v FROM %s.room_meta WHERE k=?" % SCHEMA,
                         (HIDDEN_AT_KEY,)).fetchone()
        return (r[0] or '') if r else ''
    except Exception:
        return ''


def _purge_member(conn, mid):
    conn.execute("DELETE FROM %s.room_note WHERE member_id=?" % SCHEMA, (mid,))
    conn.execute("DELETE FROM %s.room_post WHERE member_id=?" % SCHEMA, (mid,))
    conn.execute("UPDATE %s.room_member SET record_status='HIDE' WHERE member_id=?"
                 % SCHEMA, (mid,))
    conn.commit()


def hidden_members(conn, room_id, db_path=None):
    """가린 참여자 번호 목록 — 방 파일의 `room_meta` 에 산다."""
    if not room_id:
        return []
    # ⚠ 여기서 방 파일을 **만들지 않는다** — 읽기 문이 파일을 만들면 db_path 를
    #   안 넘긴 호출이 앱 폴더에 빈 방 파일을 남긴다(selftest 잔재로 실측).
    if not attach(conn, room_id, db_path):
        return []
    return _get_hidden(conn)


def set_member_hidden(conn, room_id, member_id, hidden=True, db_path=None):
    """★ 참여자를 가린다/되살린다 — **방장만.**

    ★★ **앱 안에서만 가려진다**(설계 §9-b ⓑ) — 앱은 폴더 권한을 못 바꾼다.
      진짜로 막으려면 방장이 드라이브 공유에서 그 사람을 빼야 한다. 화면이 그
      사실을 적는다.
    · 가리면 그 사람의 글·게시판 글을 걷고, 그 뒤로 그 사람 파일을 안 받는다.
    · 방장 파일에 목록이 실려 **모든 참여자 화면에서 같이** 가려진다.
    · 되살리면 다음 [받기] 때 그 사람 글이 파일에서 다시 들어온다.
    """
    import room_core as RC
    if not RC.is_manager(conn, room_id):
        raise ValueError('NOT_LEADER')
    mid = str(member_id or '').strip()
    if not mid or mid == _me(conn):
        raise ValueError('BAD_MEMBER')
    ensure_room(room_id, db_path)
    if not attach(conn, room_id, db_path):
        raise ValueError('NO_ROOM_DB')
    cur = set(_get_hidden(conn))
    if hidden:
        cur.add(mid)
        _purge_member(conn, mid)
    else:
        cur.discard(mid)
        conn.execute("UPDATE %s.room_member SET record_status='LIVE' "
                     "WHERE member_id=?" % SCHEMA, (mid,))
    _set_hidden(conn, cur)
    return sorted(cur)


def graduation_lines(rows, upto, threshold):
    """수료 명단 — 참가자 현황 표를 사람이 읽을 줄로(방장이 파일로 남긴다)."""
    out = ['%s\t%s\t%s\t%s' % ('이름', '쓴 날/%d' % int(upto), '출석률', '수료')]
    for x in rows:
        if x.get('hidden'):
            continue
        done = x['rate'] * 100 >= threshold
        out.append('%s\t%d\t%d%%\t%s' % (x['name'], x['days'],
                                           int(round(x['rate'] * 100)),
                                           '수료' if done else ''))
    return out


def member_stats(conn, room_id, plan_code, upto_day, db_path=None):
    """★★★ **방 관리 화면의 통계**(사용자 확정 — 「전체 참가자들의 반응 통계 ·
    묵상노트 작성여부 · 참가자별 출석률」).

    → `[{name, member_id, mine, notes, days, rate, last_at, linked, greeted}]`
      · `days` = 지금까지(`upto_day`) 중 글을 쓴 날 수 · `rate` = days/upto_day
      · `linked` = 구절을 붙인 글 수 · `greeted` = 인사말을 남겼나
    ⚠ **나부터 센다**(`wrote_map` 과 같은 규칙) — 방장 자신이 목록에 없으면
      「내가 안 보인다」가 된다.
    ⚠ 받아 둔 파일이 재료다 — 안 받았으면 0 이지 「안 썼다」가 아니다. 화면이
      그 사실을 적는다.
    """
    upto = max(1, int(upto_day or 1))
    pc = str(plan_code or '')
    out = []

    def _row(name, mid, mine, keys, linked, last_at, greeted):
        days = {split_day(k)[1] for k in keys if split_day(k)[0] == pc}
        days = {d for d in days if d and d <= upto}
        return {'name': name or '(이름 없음)', 'member_id': mid, 'mine': mine,
                'notes': len(keys), 'days': len(days),
                'rate': (len(days) / float(upto)) if upto else 0.0,
                'last_at': last_at or '', 'linked': linked,
                'greeted': greeted, 'hidden': False, 'role': 'MEMBER'}

    try:
        import room_core as RC
        r = RC.room(conn, room_id) or {}
        me = RC.my_uuid(conn) or ''
        mine = my_notes(conn, room_id)
        keys = [n['day_key'] for n in mine]
        linked = sum(1 for n in mine if n['clicked_id'])
        last = max([n['at'] for n in mine] or [''])
        greeted = any(p['kind'] == 'GREET' for p in my_posts(conn, room_id))
        out.append(_row((r.get('my_name') or '').strip() or '(나)', me, True,
                        keys, linked, last, greeted))
        out[-1]['role'] = r.get('my_role') or 'MEMBER'
        cos = set(RC.co_leaders(r))
        lead_uuid = (r.get('leader_uuid') or '').strip()
    except Exception:
        me, cos, lead_uuid = '', set(), ''
    if not attach(conn, room_id, db_path):
        return out
    greet = {x[0] for x in conn.execute(
        "SELECT DISTINCT member_id FROM %s.room_post WHERE kind='GREET' "
        "AND COALESCE(record_status,'LIVE')='LIVE'" % SCHEMA)}
    hid = set(_get_hidden(conn))
    for mid, nm, st in conn.execute(
            "SELECT member_id, display_name, COALESCE(record_status,'LIVE') "
            "FROM %s.room_member WHERE COALESCE(member_id,'') <> ? "
            "ORDER BY display_name" % SCHEMA, (me,)):
        if st != 'LIVE' and mid not in hid:
            continue
        rows = list(conn.execute(
            "SELECT anchor_key, verse_key, written_at FROM %s.room_note "
            "WHERE member_id=? AND anchor_kind=? "
            "AND COALESCE(record_status,'LIVE')='LIVE'" % SCHEMA,
            (mid, ANCHOR_DAY)))
        row = _row(nm, mid, False, [x[0] for x in rows],
                   sum(1 for x in rows if x[1]),
                   max([x[2] or '' for x in rows] or ['']), mid in greet)
        row['hidden'] = mid in hid
        row['role'] = ('LEADER' if mid == lead_uuid else
                       'CO_LEADER' if mid in cos else 'MEMBER')
        out.append(row)
    return out


def file_name(uid, when=None):
    """`note_<uuid앞8자>_<날짜>.json` — **이 규약이 충돌을 막는다**(§4-2)."""
    d = (when or datetime.now()).strftime('%Y%m%d')
    return 'note_%s_%s.json' % (str(uid)[:8], d)


def is_mine(name, uid):
    """그 파일이 내 것인가 — **남의 파일은 절대 안 건드린다**."""
    return os.path.basename(name or '').startswith('note_%s_' % str(uid)[:8])


# ── 받아 넣기 ────────────────────────────────────────────────────────
def apply_notes(conn, room_id, draft, db_path=None):
    """받은 파일 하나를 방 파일에 넣는다 → `(넣음, 건너뜀, 못함)`.

    ★ **한 사람의 글 전체가 한 파일**이라 **그 사람 것을 통째로 갈아 끼운다** —
      고친 글·지운 글이 저절로 맞는다.
      ⚠ 그래서 **`member_id` 로 먼저 지우고 다시 넣는다.** 부분 갱신을 하면
        지운 글이 남는다.
    ⚠ **자연 열쇠를 못 풀면 건너뛴다**(그 사람의 다른 글은 들어간다).
    ⚠ **내 글은 안 받는다** — 원본이 `user_text_asset` 에 있다.
    """
    if not isinstance(draft, dict) or draft.get('app') != APP_MARK:
        raise ValueError('NOT_NOTE_PACK')
    if int(draft.get('fmt') or 0) > FMT:
        raise ValueError('NEWER_FMT:%s' % draft.get('fmt'))
    import room_core as RC
    mine = RC.my_uuid(conn)
    mid = (draft.get('member_id') or '').strip()
    if not mid:
        raise ValueError('NO_MEMBER')
    if mid == mine:
        return 0, len(draft.get('notes') or []), 0   # ★ 내 것은 안 받는다
    ensure_room(room_id, db_path)
    if not attach(conn, room_id, db_path):
        raise ValueError('NO_ROOM_DB')
    # ★ 5단계 — **가린 참여자의 파일은 통째로 안 받는다.** 남아 있던 글도 걷는다.
    #   ⚠ 앱 안에서만 가려진다 — 파일은 폴더에 그대로 있다(설계 §9-b ⓑ).
    if mid in set(hidden_members(conn, room_id, db_path)):
        _purge_member(conn, mid)
        return 0, len(draft.get('notes') or []), 0
    nm = (draft.get('display_name') or '').strip()
    put = bad = 0
    conn.execute("DELETE FROM %s.room_note WHERE member_id=?" % SCHEMA, (mid,))
    for n in (draft.get('notes') or []):
        key = (n.get('anchor_key') or '').strip()
        kind = (n.get('anchor_kind') or ANCHOR_DAY).strip()
        # ⚠ **앵커를 못 읽으면 건너뛴다** — 하루 열쇠는 꼴을, 구절은 실재를 본다.
        if not key:
            bad += 1
            continue
        if kind == ANCHOR_DAY and split_day(key)[0] is None:
            bad += 1
            continue
        if kind == 'VERSE' and _resolve(conn, key) is None:
            bad += 1
            continue
        # ★ 구절은 덤이라 **못 풀어도 글은 받는다** — 그 방의 날짜에서는 보인다.
        vk = (n.get('verse_key') or '').strip()
        if vk and _resolve(conn, vk) is None:
            vk = ''
        conn.execute(
            "INSERT OR REPLACE INTO %s.room_note(note_id,member_id,"
            "display_name,cohort,anchor_kind,anchor_key,verse_key,title,"
            "contents,lang_code,written_at,record_status) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?, 'LIVE')" % SCHEMA,
            (n.get('note_id') or '%s_%d' % (mid[:8], put), mid, nm,
             draft.get('cohort') or '', kind, key, vk,
             n.get('title') or '', n.get('contents') or '',
             n.get('lang_code') or 'KO', n.get('written_at') or ''))
        put += 1
    # ── ★★★ 공지 — **방장 번호와 맞을 때만 받는다** ──────────────
    #   2026-09-08 사용자 「방 내부의 공지사항은 방장만 올릴 수 있다」.
    #   ⚠⚠ **보낸 사람이 방장인지 여기서 가린다** — 파일에 `notices` 가
    #     있어도 방장 번호와 다르면 **통째로 버린다.** 그러지 않으면 누구나
    #     제 파일에 공지를 넣어 방 전체에 띄울 수 있다.
    #   ⚠ 옛 방(번호 없음)이면 **아무 공지도 안 받는다** — 아무나 올리는
    #     것보다 아무것도 안 뜨는 쪽이 안전하다(`room_core.ensure` 주석).
    nlist = draft.get('notices') or []
    # ⚠⚠ **빈 목록도 「갈아 끼운다」** — `if nlist:` 로 쓰면 방장이 공지를
    #   지웠을 때 DELETE 를 건너뛰어 **옛 공지가 영영 남는다**(실측으로 잡았다).
    #   ⇒ 잣대는 「글이 있는가」가 아니라 **「방장이 보낸 파일인가」**다.
    #   ⚠ 방장이 아닌 사람의 파일에는 `notices` 열쇠가 **아예 없으므로**
    #     그 사람 때문에 공지가 지워지지 않는다.
    if 'notices' in draft:
        mgrs = set()
        try:
            import room_core as RC2
            mgrs = RC2.managers_of(RC2.room(conn, room_id))
        except Exception:
            mgrs = set()
        if mid in mgrs:
            conn.execute("DELETE FROM %s.room_notice WHERE member_id=?"
                         % SCHEMA, (mid,))
            for x in nlist:
                body = (x.get('contents') or '').strip()
                if not body:
                    continue
                conn.execute(
                    "INSERT OR REPLACE INTO %s.room_notice(notice_id,"
                    "member_id,display_name,title,contents,lang_code,"
                    "written_at,record_status) VALUES(?,?,?,?,?,?,?, 'LIVE')"
                    % SCHEMA,
                    ('%s_%s' % (mid[:8], x.get('notice_id') or ''), mid, nm,
                     x.get('title') or '', body, x.get('lang_code') or 'KO',
                     x.get('written_at') or ''))
    # ── ★★★ 게시판 — **누구나** 보내되 지침·마무리는 방장 것만 ─────────
    lead_uuid, mgrs = '', set()
    try:
        import room_core as RC3
        _r3 = RC3.room(conn, room_id) or {}
        lead_uuid = (_r3.get('leader_uuid') or '').strip()
        mgrs = RC3.managers_of(_r3)
    except Exception:
        pass
    is_lead = bool(lead_uuid) and lead_uuid == mid
    is_mgr = mid in mgrs
    if 'posts' in draft:
        conn.execute("DELETE FROM %s.room_post WHERE member_id=?" % SCHEMA,
                     (mid,))
        for x in (draft.get('posts') or []):
            body = (x.get('contents') or '').strip()
            files = [str(f) for f in (x.get('files') or []) if f]
            kind = (x.get('kind') or 'POST').upper()
            if kind not in POST_KINDS:
                kind = 'POST'
            # ⚠ 방장이 아닌 사람이 「지침」이라 적어 보내도 **평글로 내린다** —
            #   버리면 그 사람의 글이 사라지고, 그대로 받으면 아무나 지침을 쓴다.
            if kind in LEADER_KINDS and not is_mgr:
                kind = 'POST'
            if not body and not files:
                continue
            conn.execute(
                "INSERT OR REPLACE INTO %s.room_post(post_id,member_id,"
                "display_name,kind,title,contents,attach_json,lang_code,"
                "written_at,record_status) VALUES(?,?,?,?,?,?,?,?,?, 'LIVE')"
                % SCHEMA,
                ('%s_%s' % (mid[:8], x.get('post_id') or ''), mid, nm, kind,
                 x.get('title') or '', body,
                 json.dumps(files, ensure_ascii=False) if files else None,
                 x.get('lang_code') or 'KO', x.get('written_at') or ''))
    # ── ★★★ 방장 파일이 말하는 방 이름·플랜을 받아 적는다(4단계) ──────
    if is_mgr:
        try:
            import room_core as RC4
            RC4.adopt_leader_meta(
                conn, room_id,
                name=draft.get('room_name') if is_lead else None,
                plan_code=(draft.get('plan_code') if (is_lead and 'plan_code' in draft)
                           else None),
                plan_start=(draft.get('plan_start')
                            if (is_lead and 'plan_start' in draft) else None),
                co_leaders_list=(draft.get('co_leaders')
                                 if (is_lead and 'co_leaders' in draft) else None),
                status=draft.get('room_status') if 'room_status' in draft else None,
                closed_at=draft.get('closed_at'),
                status_at=draft.get('status_at'))
        except Exception:
            pass
    # ★ 운영자의 가림 목록을 받아 적고 그 사람들의 글을 걷는다(방 전체가 같게)
    if is_mgr and 'hidden' in draft:
        # ⚠⚠ 운영자가 둘이면 파일도 둘이다 — 부방장의 **옛** 파일(빈 목록)이 방장의
        #   방금 가림을 지우던 것을 종단 시험이 잡았다(2026-09-08). 목록마다 시각을
        #   싣고 **새 결정만** 받는다. 시각이 없는 옛 파일은 내 것도 없을 때만.
        d_at = str(draft.get('hidden_at') or '')
        my_at = _get_hidden_at(conn)
        # ⚠ 같은 초면 받는다(같은 결정을 다시 적을 뿐) · 시각 없는 파일을 받을 때는
        #   지금 시각을 찍지 않는다(찍으면 그 뒤 진짜 결정이 「옛것」으로 밀린다).
        if (d_at and d_at >= my_at) or (not d_at and not my_at):
            hid = [str(x) for x in (draft.get('hidden') or []) if x]
            _set_hidden(conn, hid, d_at or '')
            for h in hid:
                if h != _me(conn):
                    _purge_member(conn, h)
            # 되살아난 사람은 다시 산다(글은 다음 파일에서 돌아온다)
            conn.execute("UPDATE %s.room_member SET record_status='LIVE' "
                         "WHERE record_status<>'LIVE' AND member_id NOT IN (%s)"
                         % (SCHEMA, ','.join('?' * len(hid)) or "''"), hid)
    # ⚠ 파일을 받았다 = 가려지지 않은 사람이다 — 상태도 LIVE 로(옛 HIDE 잔재 해소)
    conn.execute(
        "INSERT INTO %s.room_member(member_id,display_name,cohort,role,"
        "last_seen,record_status) VALUES(?,?,?,?,?, 'LIVE') "
        "ON CONFLICT(member_id) DO UPDATE SET display_name=excluded.display_name,"
        " last_seen=excluded.last_seen, record_status='LIVE'" % SCHEMA,
        (mid, nm, draft.get('cohort') or '', draft.get('role') or 'MEMBER', _now()))
    conn.commit()
    return put, 0, bad


# ── 전송 ─────────────────────────────────────────────────────────────
def _transport(folder):
    import rss_transport as RT
    return RT.LocalDirTransport(folder)


def push(conn, room_id, folder, my_name='', db_path=None):
    """내 글을 나눔 폴더에 올린다 → `(파일이름, 건수, skipped)`.

    ⚠ **내 파일만 쓴다**(§4-2) — 이름이 내 id 로 시작한다.
    ⚠ **gzip 을 쓰지 않는다** — JSON 글자 그대로(§195차 팩 규칙 ①).
    """
    import room_core as RC
    uid = RC.my_uuid(conn)
    draft, skipped = export_notes(conn, room_id, my_name, db_path=db_path)
    name = file_name(uid)
    ok, msg = _transport(folder).put(
        name, json.dumps(draft, ensure_ascii=False, indent=1))
    if not ok:
        raise IOError(msg)
    return name, len(draft['notes']), skipped


def pull(conn, room_id, folder, db_path=None):
    """나눔 폴더에서 남의 글을 받는다 → `(받은 사람 수, 글 수, 못 푼 것)`.

    ⚠ **내 파일은 건너뛴다** — 원본이 내 DB 에 있다.
    ⚠ 한 파일이 깨져도 **나머지는 받는다**(§0-1) — 몇 건이 실패했는지 말한다.
    """
    import room_core as RC
    uid = RC.my_uuid(conn)
    try:
        names = sorted(os.listdir(folder))
    except Exception as e:
        raise IOError(str(e))
    who = notes = bad = 0
    # ★★★ 방장 파일부터 넣는다 — 부방장 목록·이름·플랜이 거기 실려 있어, 부방장
    #   파일이 먼저 들어오면 그 사람이 아직 참여자로 보여 지침이 평글로 내려가고
    #   공지가 버려진다(파일 이름의 uuid 차례에 따라 **되기도 안 되기도** 하던 것을
    #   종단 시험이 잡았다). 차례 = 방장 → 부방장 → 나머지(이름순).
    lead_uuid, cos = '', set()
    try:
        _r = RC.room(conn, room_id) or {}
        lead_uuid = (_r.get('leader_uuid') or '').strip()
        cos = set(RC.co_leaders(_r))
    except Exception:
        pass
    loaded = []
    for nm in names:
        if not (nm.startswith('note_') and nm.endswith('.json')):
            continue
        if is_mine(nm, uid):
            continue
        txt = _transport(folder).get(nm)
        if not txt:
            bad += 1
            continue
        try:
            d = json.loads(txt)
        except Exception:
            bad += 1
            continue
        mid = str((d or {}).get('member_id') or '') if isinstance(d, dict) else ''
        rank = 0 if (mid and mid == lead_uuid) else 1 if mid in cos else 2
        loaded.append((rank, nm, d))
    loaded.sort(key=lambda x: (x[0], x[1]))
    for _rank, nm, d in loaded:
        try:
            p, _s, b = apply_notes(conn, room_id, d, db_path)
        except Exception:
            bad += 1
            continue
        if p:
            who += 1
            notes += p
        bad += b
    return who, notes, bad


# ── 읽기 — 화면이 부르는 단일 문 ─────────────────────────────────────
def notes_of_day(conn, room_id, plan_code, day, db_path=None):
    """**그 날짜에 남들이 쓴 글** → dict 목록. ★ 이것이 공동체 묵상의 본문이다.

    ⚠ **내 글은 안 낸다** — 화면이 내 것을 따로 위에 보인다.
    ⚠ 방 파일이 없으면 **빈 목록**(오류가 아니다).
    """
    if not room_id or not attach(conn, room_id, db_path):
        return []
    key = day_key(plan_code, day)
    return [{'note_id': x[0], 'member_id': x[1],
             'name': x[2] or '(이름 없음)', 'title': x[3] or '',
             'contents': x[4] or '', 'at': x[5] or '', 'verse_key': x[6] or ''}
            for x in conn.execute(
                "SELECT note_id, member_id, display_name, title, contents, "
                "written_at, verse_key FROM %s.room_note WHERE anchor_kind=? "
                "AND anchor_key=? AND COALESCE(record_status,'LIVE')='LIVE' "
                "ORDER BY written_at DESC, note_id" % SCHEMA,
                (ANCHOR_DAY, key))]


def _me(conn):
    """내 번호 — **방 파일에서 내 글을 거르는 데 쓴다**.

    ⚠ `pull` 이 내 파일을 안 받으므로 보통은 없지만, 누가 내 파일을 복사해
      넣으면 **같은 글이 두 번 뜬다**. 읽는 자리에서 한 번 더 막는다.
    """
    try:
        import room_core as RC
        return RC.my_uuid(conn) or ''
    except Exception:
        return ''


def notes_of_verse(conn, room_id, vid, db_path=None):
    """그 구절에 **일부러 붙인** 남의 글 → dict 목록. **P2 곁들임**.

    ★★★ **구절을 붙인 것만 낸다**(2026-09-08 사용자 확정 — 「본인이 원하면
      구절과 연결하는 기능 · **그러면 p2에 자동추가**」).
      ⚠⚠ **앞선 판은 모든 나눔글을 구절로 보였다** — 그래서 P2 와 공동체가
        하는 일이 같아지고 **공동체의 특성이 사라졌다.**
      ⇒ 여기 뜨는 것은 **글쓴이가 「이 구절과 이어 주세요」라고 정한 것**뿐이다.
    ⚠ 방 파일이 없으면 빈 목록.
    """
    if not room_id or not vid:
        return []
    out = []
    # ── ★ **내 글도 함께 낸다** ──────────────────────────────────
    #   ⚠⚠ 남의 글만 내면 「구절을 붙이면 P2 에 자동추가」가 **내 글에는
    #     성립하지 않는다**(실측으로 잡았다). 내 원본은 방 파일이 아니라
    #     `user_text_asset` 에 있으므로 여기서 함께 읽는다.
    #   ⚠ **P2 묵상노트 카드로는 안 그린다** — 「함께 나눈 글」 묶음 안에서
    #     `mine` 표시로 보인다(P2 와 섞이면 차별화가 무너진다).
    try:
        pfx = _pfx(conn)
        import room_core as RC
        me = (RC.room(conn, room_id) or {}).get('my_name') or ''
        for x in conn.execute(
                "SELECT user_text_id,title,contents,"
                "COALESCE(updated_at,created_at) FROM %suser_text_asset "
                "WHERE text_type=? AND clicked_id=? AND COALESCE(room_id,'')=? "
                "AND COALESCE(record_status,'') <> 'HIDE'" % pfx,
                (NOTE_TYPE, vid, room_id)):
            out.append({'note_id': 'me_%s' % x[0], 'member_id': '',
                        'name': me or '(나)', 'title': x[1] or '',
                        'contents': x[2] or '', 'at': x[3] or '',
                        'mine': True})
    except Exception:
        pass
    if not attach(conn, room_id, db_path):
        return out
    r = conn.execute(
        "SELECT b.full_name, i.chapter, i.verse FROM bible_index i "
        "JOIN book_names b ON b.book_code=i.bcode AND b.lang_code='KO' "
        "WHERE i.verse_id=?", (vid,)).fetchone()
    if not r:
        return out
    key = '%s %d:%d' % (r[0], r[1], r[2])
    out += [{'note_id': x[0], 'member_id': x[1],
             'name': x[2] or '(이름 없음)', 'title': x[3] or '',
             'contents': x[4] or '', 'at': x[5] or '', 'mine': False}
            for x in conn.execute(
                "SELECT note_id, member_id, display_name, title, contents, "
                "written_at FROM %s.room_note WHERE COALESCE(verse_key,'')=? "
                "AND COALESCE(record_status,'LIVE')='LIVE' "
                "AND COALESCE(member_id,'') <> ? "
                "ORDER BY written_at DESC, note_id" % SCHEMA,
                (key, _me(conn)))]
    return out


def wrote_map(conn, room_id, plan_code, day, db_path=None):
    """★★★ **그 날짜에 누가 썼고 누가 안 썼나** → `[(이름, 썼나)]`.

    사용자·설계가 함께 못 박은 그 자리다(§3-1) — 「**「아직 안 썼습니다」를
    보인다** — 안 보이면 「나만 안 쓴 건가」를 모른다. ⓐ 격려가 되고
    ⓑ 방장이 진도를 본다」.
    ⚠ **이것이 P2 에서는 원리적으로 불가능하다** — 그래서 별도 화면이다.
    ⚠ **압박하지 않는다** — 「미제출」 같은 말을 쓰지 않는다(화면의 몫).
    """
    key = day_key(plan_code, day)
    # ── ★ **나부터 센다** ────────────────────────────────────────
    #   ⚠⚠ 방 파일의 `room_member` 는 **남의 파일을 받아야** 채워지므로,
    #     방을 막 연 사람은 **자기조차 목록에 없었다**(실측으로 잡았다).
    #     그러면 「누가 안 썼나」 줄이 늘 비어 이 화면의 요점이 사라진다.
    out, me = [], ''
    try:
        import room_core as RC
        r = RC.room(conn, room_id) or {}
        me = RC.my_uuid(conn) or ''
        out.append(((r.get('my_name') or '').strip() or '(나)',
                    note_of_day(conn, room_id, plan_code, day) is not None))
    except Exception:
        pass
    if not attach(conn, room_id, db_path):
        return out
    done = {x[0] for x in conn.execute(
        "SELECT DISTINCT member_id FROM %s.room_note WHERE anchor_kind=? "
        "AND anchor_key=? AND COALESCE(record_status,'LIVE')='LIVE'" % SCHEMA,
        (ANCHOR_DAY, key))}
    out += [(r[1] or '(이름 없음)', r[0] in done)
            for r in conn.execute(
                "SELECT member_id, display_name FROM %s.room_member "
                "WHERE COALESCE(record_status,'LIVE')='LIVE' "
                "AND COALESCE(member_id,'') <> ? "
                "ORDER BY display_name" % SCHEMA, (me,))]
    return out


def days_with_notes(conn, room_id, db_path=None):
    """글이 있는 날짜 → `[(plan_code, day, 글 수)]` (최근 것부터)."""
    if not attach(conn, room_id, db_path):
        return []
    out = []
    for k, n in conn.execute(
            "SELECT anchor_key, COUNT(*) FROM %s.room_note WHERE anchor_kind=? "
            "AND COALESCE(record_status,'LIVE')='LIVE' GROUP BY 1" % SCHEMA,
            (ANCHOR_DAY,)):
        pc, d = split_day(k)
        if pc:
            out.append((pc, d, n))
    out.sort(key=lambda x: (x[0], -x[1]))
    return out


def members(conn, room_id, db_path=None):
    """그 방에서 글을 올린 사람들 — **자동으로 채워진다**(§3-3 멤버).

    ★ 전도사가 30명을 손으로 등록하지 않는다. **파일을 올린 사람이 멤버다.**
    """
    if not attach(conn, room_id, db_path):
        return []
    return [{'member_id': r[0], 'name': r[1] or '', 'last_seen': r[2] or '',
             'notes': r[3]}
            for r in conn.execute(
                "SELECT m.member_id, m.display_name, m.last_seen, "
                "(SELECT COUNT(*) FROM %s.room_note n WHERE n.member_id="
                "m.member_id AND COALESCE(n.record_status,'LIVE')='LIVE') "
                "FROM %s.room_member m WHERE COALESCE(m.record_status,'LIVE')"
                "='LIVE' ORDER BY m.display_name" % (SCHEMA, SCHEMA))]


def counts(conn, room_id, db_path=None):
    """그 방에 받아 둔 것 → `(사람, 글)`."""
    if not attach(conn, room_id, db_path):
        return 0, 0
    a = conn.execute("SELECT COUNT(*) FROM %s.room_member" % SCHEMA).fetchone()[0]
    b = conn.execute("SELECT COUNT(*) FROM %s.room_note WHERE "
                     "COALESCE(record_status,'LIVE')='LIVE'" % SCHEMA).fetchone()[0]
    return a, b


def forget_room(room_id, db_path=None):
    """받아 둔 **남의 글을 걷는다** — 방을 나갈 때. → 남의 글이 0이 됐나.

    ⚠ **내 글은 한 글자도 안 지운다** — 이 파일에는 남의 글만 있다.
    ⚠⚠ **파일 삭제를 잣대로 삼지 않는다** — `with appdb.connect(...)` 는
      트랜잭션만 관리하고 **연결을 안 닫으므로**(§1 함정) 앱이 도는 동안
      ATTACH 가 살아 있어 파일이 잠긴다(실측으로 잡았다).
      ⇒ **지켜야 할 것은 「남의 글이 안 남는 것」**이고 빈 파일이 남는 것은
        해가 없다(다시 참여하면 그대로 쓴다). 지우지 못한 것을 「지웠다」고
        말하지 않는다(§0-1).
    """
    p = room_path(room_id, db_path)
    if not os.path.exists(p):
        return True
    try:
        c = sqlite3.connect(p)
        try:
            c.execute('DELETE FROM room_note')
            c.execute('DELETE FROM room_member')
            try:
                c.execute('DELETE FROM room_post')
            except Exception:
                pass
            c.commit()
            left = c.execute('SELECT COUNT(*) FROM room_note').fetchone()[0]
        finally:
            c.close()
    except Exception:
        return False
    try:
        os.remove(p)        # 잠겨 있지 않으면 파일째 없앤다(덤)
    except Exception:
        pass
    return left == 0


# ── 자가 검증 ────────────────────────────────────────────────────────
def selftest():
    """⚠ **실 DB·실 방 파일을 안 건드린다** — 임시 폴더로 잰다(§0-5)."""
    import tempfile
    import shutil
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    d = tempfile.mkdtemp(prefix='rs_st_')
    share = os.path.join(d, 'shared')
    os.makedirs(share, exist_ok=True)
    opened = []

    def mk(user_db):
        """본체(구절 표만) + 그 사람의 user_data 를 붙인 연결."""
        c = sqlite3.connect(os.path.join(d, 'bible_master.db'))
        c.execute("ATTACH ? AS userdb", (user_db,))
        opened.append(c)
        return c

    try:
        # 구절 표 — 자연 열쇠를 풀 재료
        c0 = sqlite3.connect(os.path.join(d, 'bible_master.db'))
        c0.execute("CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY,"
                   " bcode INTEGER, chapter INTEGER, verse INTEGER)")
        c0.execute("CREATE TABLE book_names(book_code INTEGER, lang_code TEXT,"
                   " full_name TEXT, short_name TEXT)")
        c0.executemany("INSERT INTO bible_index VALUES(?,?,?,?)",
                       [(1, 1, 1, 1), (2, 1, 1, 2), (3, 1, 1, 3)])
        c0.execute("INSERT INTO book_names VALUES(1,'KO','창세기','창')")
        # ★ 플랜 표 — 하루 범위를 읽는 재료. **하루가 여러 줄**임을 함께 잰다.
        c0.execute("CREATE TABLE sys_bible_plan(plan_id INTEGER PRIMARY KEY,"
                   " plan_code TEXT)")
        c0.execute("CREATE TABLE sys_plan_schedule(plan_id INTEGER, day INTEGER,"
                   " start_vid INTEGER, end_vid INTEGER, sort_order INTEGER)")
        c0.execute("INSERT INTO sys_bible_plan VALUES(1,'P1')")
        c0.executemany("INSERT INTO sys_plan_schedule VALUES(?,?,?,?,?)",
                       [(1, 1, 1, 1, 1), (1, 1, 2, 3, 2), (1, 2, 3, 3, 1)])
        c0.commit()
        c0.close()

        def user_db(nm):
            p = os.path.join(d, '%s.db' % nm)
            c = sqlite3.connect(p)
            c.execute("CREATE TABLE IF NOT EXISTS user_text_asset("
                      "user_text_id INTEGER PRIMARY KEY, clicked_id INTEGER,"
                      " target_id INTEGER, text_type TEXT, title TEXT,"
                      " contents TEXT, lang_code TEXT, record_status TEXT,"
                      " created_at TEXT, updated_at TEXT)")
            c.execute("CREATE TABLE IF NOT EXISTS user_config("
                      "config_key TEXT PRIMARY KEY, config_val TEXT)")
            c.commit()
            c.close()
            return p

        pa, pb = user_db('ua'), user_db('ub')
        ca, cb = mk(pa), mk(pb)

        def boom(fn_, why):
            try:
                fn_()
                return False
            except Exception as e:
                return why in str(e)

        # ── 칸 두 개 ─────────────────────────────────────────────
        ensure_cols(ca)
        ensure_cols(ca)                      # 두 번 해도 안 깨진다
        cols = {r[1] for r in ca.execute("PRAGMA userdb.table_info(user_text_asset)")}
        t('★ 작성자 칸 둘이 생긴다(멱등)',
          'author_uuid' in cols and 'room_id' in cols, sorted(cols)[-3:])
        ca.execute("INSERT INTO userdb.user_text_asset(clicked_id,text_type,"
                   "title,contents,lang_code,record_status,created_at) "
                   "VALUES(1,'VERS_NOTE','옛글','옛 내용','KO','NEW','2026-01-01')")
        ca.commit()
        oldv = ca.execute("SELECT author_uuid, room_id FROM userdb.user_text_asset"
                          " WHERE title='옛글'").fetchone()
        t('★★ 옛 글은 NULL 이라 안 깨진다', oldv == (None, None), oldv)

        # ── ★★★ 축 — 플랜 하루 ──────────────────────────────────
        t('★★★ 나눔글 유형이 구절이 아니다', NOTE_TYPE == 'ROOM_NOTE', NOTE_TYPE)
        t('  하루 열쇠는 자연 열쇠', day_key('CANONICAL_1Y', 3) == 'CANONICAL_1Y|3')
        t('  되풀 수 있다', split_day('CANONICAL_1Y|3') == ('CANONICAL_1Y', 3))
        t('  깨진 열쇠는 (None,None)', split_day('xxx') == (None, None))
        sp = day_span(ca, 'P1', 1)
        t('★ 하루 범위 = 가장 앞~가장 뒤(여러 줄이어도)', sp == (1, 3), sp)
        t('  없는 날은 (None,None)', day_span(ca, 'P1', 9) == (None, None))

        # ── 쓰기 — 하루에 한 편 ──────────────────────────────────
        pk = save_note(ca, 'ROOM1', 'P1', 1, '오늘 읽은 범위 전체 묵상')
        t('★ 하루 글을 쓴다', bool(pk))
        pk2 = save_note(ca, 'ROOM1', 'P1', 1, '고쳐 썼다')
        t('★★ 같은 날짜면 덮어쓴다(게시판이 아니다)', pk2 == pk, (pk, pk2))
        t('  내용이 바뀐다',
          note_of_day(ca, 'ROOM1', 'P1', 1)['contents'] == '고쳐 썼다')
        t('★ 구절을 안 붙이면 비어 있다',
          note_of_day(ca, 'ROOM1', 'P1', 1)['clicked_id'] is None)
        save_note(ca, 'ROOM1', 'P1', 2, '둘째 날')
        t('  다른 날짜는 새 글', len(my_notes(ca, 'ROOM1')) == 2)
        save_note(ca, 'ROOM1', 'P1', 2, '')
        t('★ 빈 글은 지운다(HIDE)', len(my_notes(ca, 'ROOM1')) == 1)

        # ── 내보내기 ─────────────────────────────────────────────
        import room_core as RC
        uid_a = RC.my_uuid(ca)
        draft, skipped = export_notes(ca, 'ROOM1', '김집사')
        t('★ 하루 글이 담긴다', len(draft['notes']) == 1, len(draft['notes']))
        n0 = draft['notes'][0]
        t('★★ 앵커가 「플랜 하루」다',
          n0['anchor_kind'] == ANCHOR_DAY and n0['anchor_key'] == 'P1|1',
          n0['anchor_key'])
        t('  구절을 안 붙였으면 verse_key 가 빈다', n0['verse_key'] == '')
        t('  글 안에 번호가 없다', 'clicked_id' not in json.dumps(draft))
        t('★★ 옛 구절 묵상노트는 안 실린다(P2 것)',
          all(x['anchor_kind'] == ANCHOR_DAY for x in draft['notes']))

        # ── 파일 이름 규약 ───────────────────────────────────────
        fn = file_name(uid_a)
        t('★★★ 파일 이름이 내 id 로 시작한다(충돌 0)',
          fn.startswith('note_%s_' % uid_a[:8]) and fn.endswith('.json'), fn)
        t('  내 파일인지 가린다', is_mine(fn, uid_a)
          and not is_mine(fn, 'ffffffffff'))

        # ── 올리기 ───────────────────────────────────────────────
        name, n, sk = push(ca, 'ROOM1', share, '김집사')
        t('★ 폴더에 올라간다',
          os.path.exists(os.path.join(share, name)) and n == 1, (name, n))
        raw = io.open(os.path.join(share, name), encoding='utf-8').read()
        t('★★ gzip 이 아니라 글자 그대로', raw.lstrip().startswith('{'))

        # ── 받기 (다른 사람) ─────────────────────────────────────
        xdb = os.path.join(d, 'x.db')
        who, notes, bad = pull(cb, 'ROOM1', share, db_path=xdb)
        t('★ 남의 글을 받는다', who == 1 and notes == 1, (who, notes, bad))
        got = notes_of_day(cb, 'ROOM1', 'P1', 1, xdb)
        t('★★★ **그 날짜에서** 읽힌다',
          len(got) == 1 and got[0]['name'] == '김집사', got[:1])
        t('  글 내용이 온다', got[0]['contents'] == '고쳐 썼다')
        t('★★ 구절을 안 붙였으면 P2 에 안 뜬다',
          notes_of_verse(cb, 'ROOM1', 1, xdb) == [])

        # ── 구절을 붙이면 P2 에도 ────────────────────────────────
        save_note(ca, 'ROOM1', 'P1', 1, '고쳐 썼다', verse_id=1)
        push(ca, 'ROOM1', share, '김집사')
        pull(cb, 'ROOM1', share, db_path=xdb)
        t('★★★ 구절을 붙이면 P2 에 자동으로 뜬다',
          len(notes_of_verse(cb, 'ROOM1', 1, xdb)) == 1,
          notes_of_verse(cb, 'ROOM1', 1, xdb))
        mineq = notes_of_verse(ca, 'ROOM1', 1, xdb)
        t('★★★ **내 글도 P2 에 뜬다**(자동추가는 내 것에도 성립한다)',
          len(mineq) == 1 and mineq[0]['mine'] is True, mineq)
        t('  그래도 날짜에서도 읽힌다',
          len(notes_of_day(cb, 'ROOM1', 'P1', 1, xdb)) == 1)

        who2, n2, _b = pull(ca, 'ROOM1', share, db_path=xdb)
        t('★★ 내가 올린 것을 내가 다시 안 받는다', who2 == 0 and n2 == 0,
          (who2, n2))

        # ── 누가 안 썼나 — **이 설계의 핵심** ────────────────────
        wm = wrote_map(cb, 'ROOM1', 'P1', 1, xdb)
        t('★★★ 누가 썼는지 나온다', ('김집사', True) in wm, wm)
        wm2 = wrote_map(cb, 'ROOM1', 'P1', 9, xdb)
        t('★★★ **안 쓴 날은 「안 썼다」로 나온다**(P2 에서는 불가능)',
          ('김집사', False) in wm2, wm2)
        # ★★ **방을 막 연 사람도 자기가 목록에 있다**(실측으로 잡은 결함)
        solo = wrote_map(ca, 'ROOM1', 'P1', 1)
        t('★★★ 방 파일이 없어도 **나는 세어진다**',
          len(solo) == 1 and solo[0][1] is True, solo)
        # ⚠ 이 시점에는 아직 방 표가 없어 이름이 폴백(`(나)`)이다 —
        #   **이름이 아니라 「썼나」를 잰다.**
        solo9 = wrote_map(ca, 'ROOM1', 'P1', 9)
        t('  안 쓴 날은 나도 「안 썼다」',
          len(solo9) == 1 and solo9[0][1] is False, solo9)

        # ── 고치고 다시 올리면 갈아 끼워진다 ─────────────────────
        save_note(ca, 'ROOM1', 'P1', 1, '다시 고침', verse_id=1)
        save_note(ca, 'ROOM1', 'P1', 5, '다섯째 날')
        push(ca, 'ROOM1', share, '김집사')
        pull(cb, 'ROOM1', share, db_path=xdb)
        g2 = notes_of_day(cb, 'ROOM1', 'P1', 1, xdb)
        t('★★ 고친 글이 반영된다', g2 and g2[0]['contents'] == '다시 고침',
          g2[0]['contents'] if g2 else None)
        t('  새 날짜도 온다', len(notes_of_day(cb, 'ROOM1', 'P1', 5, xdb)) == 1)
        save_note(ca, 'ROOM1', 'P1', 5, '')
        push(ca, 'ROOM1', share, '김집사')
        pull(cb, 'ROOM1', share, db_path=xdb)
        t('★★★ 지운 글이 사라진다(통째로 갈아 끼운다)',
          notes_of_day(cb, 'ROOM1', 'P1', 5, xdb) == [])
        dw = days_with_notes(cb, 'ROOM1', xdb)
        t('  글이 있는 날짜 목록', dw == [('P1', 1, 1)], dw)

        a_, b_ = counts(cb, 'ROOM1', db_path=xdb)
        t('  사람 1 · 글 1', (a_, b_) == (1, 1), (a_, b_))
        mem = members(cb, 'ROOM1', db_path=xdb)
        t('★ 멤버가 저절로 등록된다(손으로 안 적는다)',
          len(mem) == 1 and mem[0]['name'] == '김집사', mem)

        # ── 안 하는 것 ───────────────────────────────────────────
        n_before = cb.execute("SELECT COUNT(*) FROM userdb.user_text_asset"
                              ).fetchone()[0]
        t('★★★ 남의 글이 내 user_data.db 에 안 들어간다', n_before == 0,
          n_before)
        t('  방 파일은 따로 있다', os.path.exists(room_path('ROOM1', xdb)))

        t('★ 나눔 파일이 아니면 거부',
          boom(lambda: apply_notes(cb, 'R', {'app': 'x'}), 'NOT_NOTE_PACK'))
        t('  더 새 판도 거부',
          boom(lambda: apply_notes(cb, 'R', {'app': APP_MARK, 'fmt': 99,
                                             'member_id': 'z'}), 'NEWER_FMT'))
        _p, _s2, _b2 = apply_notes(cb, 'ROOM1', {
            'app': APP_MARK, 'fmt': 1, 'member_id': 'aaaa' + '0' * 28,
            'display_name': '깨진이',
            'notes': [{'anchor_kind': ANCHOR_DAY, 'anchor_key': 'nope',
                       'contents': 'x'},
                      {'anchor_kind': ANCHOR_DAY, 'anchor_key': 'P1|7',
                       'contents': '멀쩡'}]}, xdb)
        t('★ 깨진 앵커는 그 글만 건너뛴다', (_p, _b2) == (1, 1), (_p, _b2))

        # ── ★★★ 방 공지 — **방장만** ────────────────────────────
        #   2026-09-08 사용자 「방 내부의 공지사항은 방장만 올릴 수 있다」
        #   ⚠ 시험 DB 에 **진짜 방**을 만든다 — `can_notice` 가 방 표를 본다
        RC.ensure(ca)
        ca.execute("INSERT INTO userdb.user_room(room_id,room_name,room_type,"
                   "leader_name,my_name,leader_uuid,my_role,record_status) "
                   "VALUES('ROOM1','우리방','ETC','나','김집사',?,'LEADER',"
                   "'LIVE')", (uid_a,))
        RC.ensure(cb)
        cb.execute("INSERT INTO userdb.user_room(room_id,room_name,room_type,"
                   "leader_name,my_name,leader_uuid,my_role,record_status) "
                   "VALUES('ROOM1','우리방','ETC','나','박청년',?,'MEMBER',"
                   "'LIVE')", (uid_a,))
        ca.commit()
        cb.commit()
        npk = save_notice(ca, 'ROOM1', '이번 주는 3일차까지 읽습니다')
        t('★ 방장은 공지를 쓴다', bool(npk))
        t('  내 화면에 뜬다', len(notices(ca, 'ROOM1')) == 1)
        t('★★ 공지가 그날 묵상으로 안 세어진다(유형이 다르다)',
          len(my_notes(ca, 'ROOM1')) == 1, len(my_notes(ca, 'ROOM1')))
        dr2, _s3 = export_notes(ca, 'ROOM1', '김집사')
        t('★ 방장 파일에만 공지가 실린다', len(dr2.get('notices') or []) == 1)
        push(ca, 'ROOM1', share, '김집사')
        pull(cb, 'ROOM1', share, db_path=xdb)
        got_n = notices(cb, 'ROOM1', xdb)
        t('★★★ 참여자에게 공지가 도착한다',
          len(got_n) == 1 and '3일차' in got_n[0]['contents'], got_n[:1])
        t('  내 것이 아니라고 표시된다', got_n[0]['mine'] is False)

        # ⚠⚠ **남이 제 파일에 공지를 넣어도 안 받는다** — 이 대조가 실효다
        _p3, _s4, _b3 = apply_notes(cb, 'ROOM1', {
            'app': APP_MARK, 'fmt': 1, 'member_id': 'bbbb' + '0' * 28,
            'display_name': '가짜방장',
            'notes': [], 'notices': [{'notice_id': 'x',
                                      'contents': '내가 방장이다'}]}, xdb)
        t('★★★ **남이 올린 공지는 버린다**(방장 번호 대조)',
          len(notices(cb, 'ROOM1', xdb)) == 1,
          [x['contents'][:12] for x in notices(cb, 'ROOM1', xdb)])

        # 참여자는 애초에 못 쓴다
        def _try_notice():
            save_notice(cb, 'ROOM1', '나도 공지')
        t('★★ 참여자는 공지를 못 쓴다(화면이 아니라 여기서 막는다)',
          boom(_try_notice, 'NOT_ALLOWED'))
        # 지우면 사라진다
        save_notice(ca, 'ROOM1', '', pk=npk)
        push(ca, 'ROOM1', share, '김집사')
        pull(cb, 'ROOM1', share, db_path=xdb)
        t('★ 지운 공지가 사라진다', notices(cb, 'ROOM1', xdb) == [])
        # ⚠ 되살려 두고 — **남의 파일이 공지를 못 지운다**를 잰다
        save_notice(ca, 'ROOM1', '다시 공지')
        push(ca, 'ROOM1', share, '김집사')
        pull(cb, 'ROOM1', share, db_path=xdb)
        apply_notes(cb, 'ROOM1', {'app': APP_MARK, 'fmt': 1,
                                  'member_id': 'cccc' + '0' * 28,
                                  'display_name': '남', 'notes': []}, xdb)
        t('★★ 남의 파일은 공지를 못 지운다(notices 열쇠가 없다)',
          len(notices(cb, 'ROOM1', xdb)) == 1,
          len(notices(cb, 'ROOM1', xdb)))

        # ── ★★★ 4단계 — 게시판 · 첨부 · 방장 메타 · 통계 ──────────────
        #   2026-09-08 사용자 확정 흐름: 인사 → 지침(방장) → 날마다 묵상 →
        #   마무리 인사 → 방 이름 바꿔 다시 쓰기. 앱에 기수 개념 없음.
        gpk = save_post(ca, 'ROOM1', 'GUIDE', '이번 훈련의 지침입니다')
        t('★ 방장이 지침을 쓴다', bool(gpk))
        t('★★ 지침이 그날 묵상으로 안 세어진다',
          len(my_notes(ca, 'ROOM1')) == 1, len(my_notes(ca, 'ROOM1')))
        t('★ 참여자는 인사말을 쓴다', bool(save_post(cb, 'ROOM1', 'GREET',
                                                '안녕하세요 박청년입니다')))
        t('★★ 참여자는 지침을 못 쓴다(여기서 막는다)',
          boom(lambda: save_post(cb, 'ROOM1', 'GUIDE', '내가 지침'),
               'NOT_ALLOWED'))
        t('  모르는 갈래는 거부',
          boom(lambda: save_post(ca, 'ROOM1', 'XX', 'x'), 'BAD_KIND'))
        # 첨부 — 교재 파일을 방 폴더에
        src = os.path.join(d, '교재.pdf')
        io.open(src, 'w', encoding='utf-8').write('pdf?')
        an = attach_file(share, uid_a, src)
        t('★★★ 교재가 방 폴더에 담긴다(참여자는 드라이브에 안 들어간다)',
          an.startswith('file_%s_' % uid_a[:8])
          and os.path.exists(os.path.join(share, an)), an)
        t('  첨부 경로를 되찾는다', attach_path(share, an) is not None)
        t('  없는 첨부는 None', attach_path(share, 'file_zz_없음.pdf') is None)
        t('  이름에 경로 조각이 못 들어간다',
          attach_path(share, '../' + an) is not None
          and '..' not in _safe_name('../x'))
        save_post(ca, 'ROOM1', 'POST', '교재입니다', files=[an])
        # 방장 파일 — 이름·플랜을 나른다
        RC.set_plan(ca, 'ROOM1', 'P1')
        RC.rename_room(ca, 'ROOM1', '묵상훈련_2027_1기')
        dr4, _s5 = export_notes(ca, 'ROOM1', '김집사')
        t('★★ 방장 파일에 이름·플랜·게시판이 실린다',
          dr4.get('room_name') == '묵상훈련_2027_1기' and dr4.get('plan_code') == 'P1'
          and len(dr4.get('posts') or []) == 2, (dr4.get('room_name'),
                                                 dr4.get('plan_code')))
        push(ca, 'ROOM1', share, '김집사')
        pull(cb, 'ROOM1', share, db_path=xdb)
        bp = posts(cb, 'ROOM1', xdb)
        t('★★★ 참여자 게시판에 방장의 지침·교재가 도착한다',
          any(p['kind'] == 'GUIDE' for p in bp)
          and any(an in p['files'] for p in bp), [(p['kind'], p['files']) for p in bp])
        t('  참여자 자신의 인사말도 함께(시간순)',
          any(p['kind'] == 'GREET' and p['mine'] for p in bp))
        t('  지침에 「방장」 표식', all(p['leader'] for p in bp if p['kind'] == 'GUIDE'))
        rb = RC.room(cb, 'ROOM1')
        t('★★★ 참여자가 방 이름·플랜을 받아 적는다(초대 파일 재발행 없이)',
          rb['room_name'] == '묵상훈련_2027_1기' and rb['plan_code'] == 'P1',
          (rb['room_name'], rb['plan_code']))
        # 남이 「지침」이라 적어 보내면 평글로 내린다
        apply_notes(cb, 'ROOM1', {'app': APP_MARK, 'fmt': 1,
                                  'member_id': 'dddd' + '0' * 28,
                                  'display_name': '가짜', 'notes': [],
                                  'posts': [{'post_id': 'q', 'kind': 'GUIDE',
                                             'contents': '내가 지침'}],
                                  'room_name': '가짜방', 'plan_code': 'P9'}, xdb)
        bp2 = posts(cb, 'ROOM1', xdb)
        fake_g = [p for p in bp2 if p['contents'] == '내가 지침']
        t('★★ 남의 「지침」은 평글로 내려 받는다', fake_g and fake_g[0]['kind'] == 'POST',
          [p['kind'] for p in fake_g])
        rb2 = RC.room(cb, 'ROOM1')
        t('★★ 남의 파일은 방 이름·플랜을 못 바꾼다',
          rb2['room_name'] == '묵상훈련_2027_1기' and rb2['plan_code'] == 'P1')
        # 통계
        st = member_stats(cb, 'ROOM1', 'P1', 5, xdb)
        kim = next(x for x in st if x['name'] == '김집사')
        me_ = next(x for x in st if x['mine'])
        t('★★★ 참가자별 통계 — 쓴 날·출석률·구절 연결',
          kim['days'] == 1 and abs(kim['rate'] - 0.2) < 1e-9 and kim['linked'] == 1,
          (kim['days'], kim['rate'], kim['linked']))
        t('  나도 목록에 있고 인사말 여부가 나온다', me_['greeted'] is True
          and kim['greeted'] is False, (me_['greeted'], kim['greeted']))
        # ── 5단계 — 가리기 · 마무리 ─────────────────────────────────
        uid_b = RC.my_uuid(cb)
        t('★ 참여자는 못 가린다',
          boom(lambda: set_member_hidden(cb, 'ROOM1', uid_a, db_path=xdb),
               'NOT_LEADER'))
        # 방장(ca)이 박청년(uid_b)의 파일을 받은 상태를 만든다
        save_note(cb, 'ROOM1', 'P1', 2, '둘째 날 박청년')
        push(cb, 'ROOM1', share, '박청년', xdb)
        pull(ca, 'ROOM1', share, db_path=pa)
        t('  방장이 박청년 글을 받았다',
          len(notes_of_day(ca, 'ROOM1', 'P1', 2, pa)) == 1)
        set_member_hidden(ca, 'ROOM1', uid_b, db_path=pa)
        t('★★ 가리면 그 사람 글이 걷힌다', notes_of_day(ca, 'ROOM1', 'P1', 2, pa) == [])
        pull(ca, 'ROOM1', share, db_path=pa)
        t('★★ 가린 뒤에는 그 사람 파일을 안 받는다',
          notes_of_day(ca, 'ROOM1', 'P1', 2, pa) == [])
        st2 = member_stats(ca, 'ROOM1', 'P1', 5, pa)
        t('  현황에는 가림 표식으로 남는다(되살릴 수 있게)',
          any(x['hidden'] and x['member_id'] == uid_b for x in st2))
        RC.close_room(ca, 'ROOM1')
        # ⚠ 방장 파일은 **방장의 방 파일**(pa)에서 가림 목록을 읽는다 — db_path 필수
        push(ca, 'ROOM1', share, '김집사', pa)
        pull(cb, 'ROOM1', share, db_path=xdb)
        t('★★ 방장 파일로 가림 목록이 참여자에게도 간다',
          uid_b in hidden_members(cb, 'ROOM1', xdb))
        t('★★ 마무리 상태도 참여자가 받아 적는다',
          RC.is_closed(RC.room(cb, 'ROOM1')))
        set_member_hidden(ca, 'ROOM1', uid_b, hidden=False, db_path=pa)
        pull(ca, 'ROOM1', share, db_path=pa)
        # ── 부방장 — 방장 파일로 지정이 가고, 부방장 파일의 지침·공지를 받는다
        RC.set_co_leader(ca, 'ROOM1', uid_b)
        push(ca, 'ROOM1', share, '김집사', pa)
        pull(cb, 'ROOM1', share, db_path=xdb)
        t('★★★ 부방장 지정이 참여자 앱에 도착해 제 역할이 바뀐다',
          RC.room(cb, 'ROOM1')['my_role'] == RC.ROLE_CO, RC.room(cb, 'ROOM1')['my_role'])
        t('  부방장은 지침을 쓴다', bool(save_post(cb, 'ROOM1', 'GUIDE', '부방장 지침')))
        t('  부방장은 공지를 쓴다', bool(save_notice(cb, 'ROOM1', '부방장 공지')))
        push(cb, 'ROOM1', share, '박청년', xdb)
        pull(ca, 'ROOM1', share, db_path=pa)
        t('★★ 방장 화면에 부방장의 지침이 지침으로 온다',
          any(p['kind'] == 'GUIDE' and p['contents'] == '부방장 지침'
              for p in posts(ca, 'ROOM1', pa)))
        t('  부방장 공지도 온다', any('부방장 공지' in n['contents']
                                    for n in notices(ca, 'ROOM1', pa)))
        st3 = member_stats(ca, 'ROOM1', 'P1', 5, pa)
        t('  현황에 역할이 나온다', any(x['role'] == 'CO_LEADER' for x in st3))
        # ★★★ 부방장의 옛 파일(빈 가림 목록)이 방장의 새 가림을 지우지 않는다
        import time as _time
        _time.sleep(1.1)
        set_member_hidden(ca, 'ROOM1', uid_b, True, pa)
        pull(ca, 'ROOM1', share, db_path=pa)      # 부방장(cb) 옛 파일에는 hidden=[] 이 실려 있다
        t('★★★ 옛 운영자 파일이 방장의 새 가림을 못 지운다',
          uid_b in hidden_members(ca, 'ROOM1', pa), hidden_members(ca, 'ROOM1', pa))
        set_member_hidden(ca, 'ROOM1', uid_b, False, pa)
        pull(ca, 'ROOM1', share, db_path=pa)
        t('  되살리면 그 사람 파일이 다시 들어온다',
          any(p['contents'] == '부방장 지침' for p in posts(ca, 'ROOM1', pa)))
        RC.set_co_leader(ca, 'ROOM1', uid_b, on=False)
        push(ca, 'ROOM1', share, '김집사', pa)
        pull(cb, 'ROOM1', share, db_path=xdb)
        t('★ 해제하면 참여자로 돌아온다', RC.room(cb, 'ROOM1')['my_role'] == 'MEMBER')
        pull(ca, 'ROOM1', share, db_path=pa)
        t('  해제된 뒤 옛 파일의 지침은 평글로 내려간다',
          all(p['kind'] != 'GUIDE' for p in posts(ca, 'ROOM1', pa)
              if p['contents'] == '부방장 지침'))
        t('★ 되살리면 다음 받기에 글이 돌아온다',
          len(notes_of_day(ca, 'ROOM1', 'P1', 2, pa)) == 1)
        gl = graduation_lines(member_stats(ca, 'ROOM1', 'P1', 5, pa), 5, 80)
        t('  수료 명단 줄', len(gl) >= 2 and '출석률' in gl[0], gl[:2])
        RC.close_room(ca, 'ROOM1', closed=False)
        t('  첨부가 자료 파일인지 가린다 — 보통 파일',
          attach_kind(os.path.join(share, an)) == 'FILE')
        pk_ = os.path.join(share, 'file_x_pack.json')
        io.open(pk_, 'w', encoding='utf-8').write('{"app": "hagah-share", "fmt": 1}')
        t('  자료 파일이면 PACK', attach_kind(pk_) == 'PACK')

        # ── 방을 나갈 때 ─────────────────────────────────────────
        detach(cb)
        t('★ 방을 나가면 남의 글이 걷힌다', forget_room('ROOM1', xdb))
        t('  게시판도 걷힌다', posts(cb, 'ROOM1', xdb) == []
          or all(p['mine'] for p in posts(cb, 'ROOM1', xdb)))
        t('★★ 걷은 뒤 그 날짜에서 읽히는 것이 0',
          notes_of_day(cb, 'ROOM1', 'P1', 1, xdb) == [])
        t('  내 글은 그대로', len(my_notes(ca, 'ROOM1')) == 1)

        # ── 규약 ─────────────────────────────────────────────────
        src = io.open(os.path.abspath(__file__), encoding='utf-8').read()
        _g = 'gz' + 'ip.'
        t('★★ 압축해서 올리지 않는다(§195차 팩 규칙 ①)', _g not in src)
        t('  나눔글 유형이 단일 소스', NOTE_TYPE == 'ROOM_NOTE')
        # ⚠⚠ **P2 묵상노트와 저장소가 갈려 있다** — 같은 유형을 쓰면 P2 에
        #   공동체 글이 섞이고 「내가 두 번 썼나」가 된다(차별화의 근거).
        t('★★★ P2 묵상노트와 유형이 다르다',
          NOTE_TYPE != ('VERS' + '_NOTE'), NOTE_TYPE)
    finally:
        for c in opened:
            try:
                c.close()
            except Exception:
                pass
        try:
            shutil.rmtree(d)
        except Exception:
            pass
    t('  시험 파일 잔재 0', not os.path.exists(d))
    t('★ 앱 폴더에 방 파일 잔재 0(읽기 문이 파일을 안 만든다)',
      not os.path.exists(room_path('ROOM1')))
    print('room_share selftest: %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    import room_core as RC
    conn = appdb.connect()
    ensure_cols(conn)
    rs = RC.rooms(conn)
    print('■ 방 %d개' % len(rs))
    for r in rs:
        a, b = counts(conn, r['room_id'])
        print('  %-24s 받아 둔 것 — 사람 %d · 글 %d' % (r['room_name'], a, b))
    print('  내 나눔글 %d편' % len(my_notes(conn)))
