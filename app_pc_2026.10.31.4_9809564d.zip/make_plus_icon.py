# -*- coding: utf-8 -*-
"""make_plus_icon — 「+Hagah」 표준 아이콘 하나를 만들어 쓰는 곳마다 같은 그림을 둔다 (2026-10-11 · 영구).

사용자 지시: 「"하가에 저장" 같은 문구는 다국어 모드 적용하지 말고 "+Hagah" 로 표준화 · PC / 모바일 공통」 ·
「유투브 폴더 이름 아이콘 이름 등을 모두 통일 · 글로벌 표준 이미지를 만들어야 한다」.

★ 원본 = 앱 아이콘(icons/Hagah Dabar.png) + 오른쪽 아래 초록 「+」 둥근 표 — 앱이 같음을 알아보고, 「담는다」가 보인다.
★ 단일 소스는 이 파일 — 그림을 고치면 이것을 다시 돌린다:
   icons/plus_hagah_512.png(원본) · browser_ext/icons/icon{16,32,48,128}.png(확장) ·
   mobile/android/app/src/main/res/drawable-*/ic_plus_hagah.png(폰 공유 목록)
"""
import os

from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
NAME = '+Hagah'
GREEN = (30, 132, 73, 255)          # 성공 색(ui_theme success 와 같은 계열)


def master(size=512):
    base = Image.open(os.path.join(HERE, 'icons', 'Hagah Dabar.png')).convert('RGBA').resize((size, size), Image.LANCZOS)
    d = ImageDraw.Draw(base)
    r = int(size * 0.20)                       # 표 반지름
    cx = cy = size - r - int(size * 0.035)       # 흰 테두리까지 그림 안에
    d.ellipse((cx - r - size * 0.025, cy - r - size * 0.025, cx + r + size * 0.025, cy + r + size * 0.025),
              fill=(255, 255, 255, 255))       # 흰 테두리 — 어두운 바탕에서도 표가 떨어져 보인다
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=GREEN)
    w, L = max(2, int(r * 0.30)), int(r * 0.62)
    d.rounded_rectangle((cx - L, cy - w / 2, cx + L, cy + w / 2), radius=w / 2, fill=(255, 255, 255, 255))
    d.rounded_rectangle((cx - w / 2, cy - L, cx + w / 2, cy + L), radius=w / 2, fill=(255, 255, 255, 255))
    return base


def build():
    m = master(512)
    out = []
    p = os.path.join(HERE, 'icons', 'plus_hagah_512.png')
    m.save(p)
    out.append(p)
    for s in (16, 32, 48, 128):
        p = os.path.join(HERE, 'browser_ext', 'icons', 'icon%d.png' % s)
        m.resize((s, s), Image.LANCZOS).save(p)
        out.append(p)
    res = os.path.join(HERE, 'mobile', 'android', 'app', 'src', 'main', 'res')
    for dens, s in (('mdpi', 48), ('hdpi', 72), ('xhdpi', 96), ('xxhdpi', 144), ('xxxhdpi', 192)):
        d = os.path.join(res, 'drawable-' + dens)
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, 'ic_plus_hagah.png')
        m.resize((s, s), Image.LANCZOS).save(p)
        out.append(p)
    return out


if __name__ == '__main__':
    for p in build():
        print(p)
