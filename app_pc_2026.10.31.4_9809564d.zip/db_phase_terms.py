# -*- coding: utf-8 -*-
"""
db_phase_terms.py — **심리·국면 용어**(`entity_type='PHASE'`) 씨앗 (2026-09-18 신설)
------------------------------------------------------------------------------
★★★ **왜 새 유형인가** (2026-09-18 사용자 확정 — 「A로 하자. 모든 기능은
  오버레이 방식이어야 한다. 관리자가 만든 심리/국면 용어를 사용자도 사용하고
  사용자가 추가할 수도 있어야 한다」 · 「용어 분류값에 하나 추가하고 주요용어
  관리화면에서 모두 관리」).
  · 태그 축 16 가운데 **엔티티 축 10 은 `entity_type` 의 복제**였고, 개념 축
    여섯 중 넷도 다른 자산이 이미 맡고 있었다(신학주제·신앙실천 = TERM ·
    구속사사건 = 말씀흐름 · 큐레이션 = `sys_verse_highlight`).
  · 정말로 비어 있던 자리는 **「심리·국면」 하나**다 — 사용자가 손으로 다는
    말(불안·외로움·무기력)이 여기 들어온다.
  ⇒ 태그 층을 늘리지 않고 **주요용어에 유형 하나를 더한다.**

★★★ **재료를 지어내지 않는다 — 자가진단 플랜 열 개가 이미 그 축이다.**
  플랜 코드가 국면과 1:1 로 대응하고(`DIAG_ANXIETY_TRUST` …) 각각 **21개
  본문 구간**을 달고 있다. 용어 열 개를 만들면 **구절 1,881개가 따라온다.**

  ⚠ 절 연결은 **THEMATIC** 이다 — 이 용어들은 원어 앵커가 없다(§12-0 의
    「앵커가 0개인 것은 분류가 아니라 사실이다」 그 자리).
  ⚠ **대표(`is_key`)는 구간의 첫 절**이다 — 195절을 그대로 늘어놓으면 훑을
    수 없다. 화면이 대표부터 보이고 나머지는 [더 보기]로 간다.
  ⚠⚠ **자동 연결기에 이 유형을 넣지 말 것** — `media_text_linker.ENTITY_TYPES`
    와 `db_term_link_audit.JUDGE_TYPES` 는 **일부러 안 건드렸다**. 「불안」·
    「분노」는 흔한 말이라 영상 제목에 걸면 §195차 「엘」 사건이 되풀이된다.
    selftest 가 그 둘에 안 들어갔는지 잰다.

    python db_phase_terms.py --selftest     (의무)
    python db_phase_terms.py --check        (무엇이 될지만 본다)
    python db_phase_terms.py --apply        (멱등)
    python db_phase_terms.py --undo         (표식으로 되돌린다)
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb

ETYPE = 'PHASE'
#: 이 도구가 만든 것임을 밝히는 표식 — `--undo` 가 이것만 걷는다.
MARK = 'PHASE_SEED'

#: 열 국면 — 이름·설명·짝이 되는 자가진단 플랜.
#  ⚠ 이름이 기존 용어와 겹치지 않게 골랐다 — 「수치」는 이미 TERM(보쉬)이라
#    **「수치심」**으로, 「기도」도 TERM 이라 **「기도가 막힘」**으로 둔다.
#    selftest 가 겹침을 잰다.
TERMS = [
    dict(code='PH_ANXIETY', plan='DIAG_ANXIETY_TRUST', ko='불안', en='Anxiety',
         desc_ko='불안은 아직 일어나지 않은 일 앞에서 마음이 먼저 무너지는 '
                 '자리입니다. 성경은 불안을 꾸짖기보다 먼저 돌봅니다. 로뎀나무 '
                 '아래 쓰러진 엘리야에게 하나님은 책망 대신 떡과 잠을 주셨고, '
                 '예수님은 내일 일을 염려하지 말라고 하시며 들의 백합과 공중의 '
                 '새를 가리키셨습니다. 불안의 반대말은 담대함이 아니라 돌보시는 '
                 '분을 아는 신뢰입니다.',
         desc_en='Anxiety is the place where the heart gives way before '
                 'anything has actually happened. Scripture tends to it before '
                 'it corrects it: God gave the collapsed Elijah bread and sleep '
                 'rather than a rebuke, and Jesus pointed to lilies and birds '
                 'rather than scolding worry. The opposite of anxiety is not '
                 'bravery but trust in the One who provides.'),
    dict(code='PH_GRIEF', plan='DIAG_GRIEF_HOPE', ko='슬픔', en='Grief',
         desc_ko='슬픔은 잃은 것 앞에 서는 자리입니다. 성경은 슬픔을 서둘러 '
                 '덮지 않습니다. 시편의 많은 기도가 탄식으로 시작하고, 예수님도 '
                 '나사로의 무덤 앞에서 우셨습니다. 애도할 시간을 주는 것이 '
                 '위로의 첫걸음이고, 그 끝에 부활의 소망이 놓입니다.',
         desc_en='Grief is standing before what has been lost. Scripture does '
                 'not hurry to cover it: many psalms open in lament, and Jesus '
                 'wept at the tomb of Lazarus. Giving mourning its time is the '
                 'first step of comfort, and at the end of it stands the hope '
                 'of resurrection.'),
    dict(code='PH_SHAME', plan='DIAG_SHAME_GRACE', ko='수치심', en='Shame',
         desc_ko='수치심은 내가 한 일이 아니라 나라는 존재가 잘못되었다고 '
                 '느끼는 자리입니다. 죄책감이 행동을 가리킨다면 수치심은 자신을 '
                 '가립니다. 성경의 첫 수치는 에덴에서 몸을 가린 장면이고, '
                 '하나님은 그들을 내보내시기 전에 먼저 옷을 지어 입히셨습니다. '
                 '감추는 자리에 찾아오시는 은혜가 수치심을 푸는 길입니다.',
         desc_en='Shame says not that what I did was wrong but that I am. '
                 'Guilt points at an act; shame hides the person. The first '
                 'shame in Scripture is a covering in Eden, and before sending '
                 'them out God clothed them. Grace that comes to the hiding '
                 'place is what undoes shame.'),
    dict(code='PH_ANGER', plan='DIAG_ANGER_SURRENDER', ko='분노', en='Anger',
         desc_ko='분노는 무언가 잘못되었다는 신호입니다. 성경은 분노 자체를 '
                 '죄라 하지 않고 분을 내어도 죄를 짓지 말라고 합니다. 문제는 '
                 '분노가 오래 머물러 원한이 되고 내가 심판자의 자리에 앉는 '
                 '것입니다. 가인과 요나와 형들 앞에 선 요셉이 그 갈림길을 보여 '
                 '줍니다.',
         desc_en='Anger is a signal that something is wrong. Scripture does '
                 'not call the feeling itself sin, but says: in your anger do '
                 'not sin. The danger is anger that settles into resentment and '
                 'puts me in the seat of the judge. Cain, Jonah and Joseph '
                 'before his brothers each stand at that fork.'),
    dict(code='PH_LONELY', plan='DIAG_LONELY_PRESENCE', ko='외로움',
         en='Loneliness',
         desc_ko='외로움은 곁에 사람이 없을 때만이 아니라 사람들 사이에서도 '
                 '찾아옵니다. 성경은 혼자 남은 자리를 여러 번 보여 줍니다. '
                 '광야의 하갈, 동굴의 엘리야, 겟세마네의 예수님이 그렇습니다. '
                 '그 자리마다 내가 너와 함께 있다는 임재가 답이 됩니다.',
         desc_en='Loneliness comes not only when no one is near but also in '
                 'the middle of a crowd. Scripture shows the solitary place '
                 'again and again: Hagar in the desert, Elijah in the cave, '
                 'Jesus in Gethsemane. In each, the answer is a presence that '
                 'says, I am with you.'),
    dict(code='PH_DISTANT', plan='DIAG_DISTANT_ENCOUNTER', ko='하나님과 멀어짐',
         en='Distance from God',
         desc_ko='하나님이 멀게 느껴지는 때가 있습니다. 감정이 식고 기도가 '
                 '형식이 되고 말씀이 남의 말처럼 들립니다. 성경은 이 거리를 '
                 '감추지 않습니다. 어찌 나를 버리셨나이까가 시편에 그대로 적혀 '
                 '있고, 엠마오로 가던 두 사람은 곁에 계신 분을 알아보지 '
                 '못했습니다. 거리는 끝이 아니라 만남의 문턱일 수 있습니다.',
         desc_en='There are seasons when God feels far away: feeling cools, '
                 'prayer turns formal, the text reads like a letter to someone '
                 'else. Scripture does not hide this distance. Why have you '
                 'forsaken me stands written in the Psalms, and the two walking '
                 'to Emmaus did not recognise the One beside them. Distance can '
                 'be a threshold rather than an end.'),
    dict(code='PH_PRAYERLESS', plan='DIAG_PRAYERLESS_RETURN', ko='기도가 막힘',
         en='Prayerlessness',
         desc_ko='기도가 멈추는 것은 대개 결심이 약해서가 아니라 할 말이 '
                 '없어졌기 때문입니다. 성경은 기도를 다시 배우려는 사람에게 '
                 '본보기를 줍니다. 제자들은 기도를 가르쳐 달라고 청했고, 주님은 '
                 '짧은 기도 하나를 주셨습니다. 다시 시작하는 자리는 언제나 '
                 '작습니다.',
         desc_en='Prayer usually stops not because resolve failed but because '
                 'the words ran out. Scripture gives a pattern to anyone '
                 'learning again: the disciples asked to be taught to pray, and '
                 'the Lord gave them one short prayer. The place where a person '
                 'begins again is always small.'),
    dict(code='PH_GUILT', plan='DIAG_GUILT_FREEDOM', ko='죄책감', en='Guilt',
         desc_ko='죄책감은 내가 한 일을 바로 보는 데서 옵니다. 그 자체는 건강한 '
                 '신호이지만 갈 곳을 찾지 못하면 사람을 눌러 앉힙니다. 성경은 '
                 '두 갈래를 보여 줍니다. 베드로는 통곡한 뒤 다시 부르심을 받았고 '
                 '유다는 후회 뒤에 스스로 끊었습니다. 죄책감이 가야 할 곳은 '
                 '자책이 아니라 용서입니다.',
         desc_en='Guilt comes from seeing clearly what I have done. The signal '
                 'itself is healthy, but with nowhere to go it pins a person '
                 'down. Scripture shows two roads: Peter wept and was called '
                 'again; Judas regretted and cut himself off. Guilt is meant to '
                 'travel toward forgiveness, not toward self-punishment.'),
    dict(code='PH_CALLING', plan='DIAG_CALLING_RESPOND', ko='소명 앞에서',
         en='Facing a calling',
         desc_ko='부르심 앞에서 사람은 먼저 물러섭니다. 모세는 말이 둔하다 했고 '
                 '기드온은 가장 작은 자라 했고 예레미야는 아이라 했습니다. '
                 '성경은 그 머뭇거림을 불신앙으로 몰지 않고, 보내시는 분이 '
                 '누구신지를 다시 보여 주는 것으로 답합니다.',
         desc_en='People step back first when a call comes. Moses said he was '
                 'slow of speech, Gideon that he was the least, Jeremiah that '
                 'he was only a child. Scripture does not brand that hesitation '
                 'as unbelief; it answers by showing again who is doing the '
                 'sending.'),
    dict(code='PH_STAGNANT', plan='DIAG_STAGNANT_RENEW', ko='무기력',
         en='Spiritual burnout',
         desc_ko='처음의 뜨거움이 식고 제자리를 맴도는 때가 있습니다. 성경은 '
                 '그것을 처음 사랑을 버렸다고 말하고, 마른 뼈가 가득한 골짜기로 '
                 '그려 보이기도 합니다. 다시 타오르는 일은 힘을 쥐어짜는 것이 '
                 '아니라 생기를 불어넣으시는 분께 다시 서는 데서 시작합니다.',
         desc_en='There are times when the first heat cools and everything '
                 'circles in place. Scripture calls it leaving your first love, '
                 'and paints it as a valley full of dry bones. Burning again '
                 'does not start by squeezing out more strength but by standing '
                 'again before the One who breathes life.'),
]


# ── 도우미 ────────────────────────────────────────────────────────────
def _eid(conn, code):
    r = conn.execute('SELECT entity_id FROM sys_entity_master WHERE entity_code=?',
                     (code,)).fetchone()
    return r[0] if r else None


def _plan_id(conn, plan_code):
    r = conn.execute('SELECT plan_id FROM sys_bible_plan WHERE plan_code=?',
                     (plan_code,)).fetchone()
    return r[0] if r else None


def plan_spans(conn, plan_id):
    """그 플랜의 본문 구간 [(시작vid, 끝vid)] — 차례대로, 중복 없이."""
    out, seen = [], set()
    for sv, ev in conn.execute(
            'SELECT start_vid, COALESCE(NULLIF(end_vid,0), start_vid) '
            '  FROM sys_plan_schedule WHERE plan_id=? ORDER BY day, sort_order',
            (plan_id,)):
        if sv and (sv, ev) not in seen:
            seen.add((sv, ev))
            out.append((sv, ev))
    return out


def span_vids(conn, sv, ev):
    """구간이 덮는 절 — **차례는 `sort_order`**(§236차).

    ⚠ `verse_id` 로 재면 아6:1~6:14 가 13,488절을 먹는다."""
    return [r[0] for r in conn.execute(
        """SELECT bi.verse_id FROM bible_index bi
             JOIN bible_index a ON a.verse_id=?
             JOIN bible_index b ON b.verse_id=?
            WHERE bi.sort_order BETWEEN MIN(a.sort_order, b.sort_order)
                                    AND MAX(a.sort_order, b.sort_order)
            ORDER BY bi.sort_order""", (sv, ev))]


def _upsert_text(conn, cid, ttype, lang, body):
    conn.execute('DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type=?'
                 ' AND lang_code=?', (cid, ttype, lang))
    if body and body.strip():
        conn.execute('INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,'
                     " contents,record_status) VALUES(?,?,?,?,'LIVE')",
                     (cid, ttype, lang, body.strip()))


def _name_clash(conn, ko, code):
    """같은 한국어 이름을 쓰는 **다른** 살아 있는 용어 — 목록에서 둘이 같아 보인다."""
    return [r[0] for r in conn.execute(
        "SELECT e.entity_type FROM sys_text_asset ta"
        "  JOIN sys_entity_master e ON e.entity_id=ta.clicked_id"
        " WHERE ta.text_type='ENTITY_NAME' AND ta.lang_code='KO'"
        "   AND ta.contents=? AND e.entity_code<>?"
        "   AND COALESCE(e.record_status,'LIVE')='LIVE'", (ko, code))]


# ── 보기 ──────────────────────────────────────────────────────────────
def check(conn):
    """무엇이 될지만 본다 — **한 줄도 안 쓴다**."""
    print('심리·국면 용어 씨앗 — 계획')
    tot_v = bad = 0
    for t in TERMS:
        pid = _plan_id(conn, t['plan'])
        if pid is None:
            print('  ✗ %-14s 플랜 없음 — %s' % (t['ko'], t['plan']))
            bad += 1
            continue
        spans = plan_spans(conn, pid)
        vids = set()
        for sv, ev in spans:
            vids.update(span_vids(conn, sv, ev))
        eid = _eid(conn, t['code'])
        dup = _name_clash(conn, t['ko'], t['code'])
        print('  %-14s %-14s 구간 %2d · 절 %4d%s'
              % (t['ko'], ('이미 있음 #%d' % eid) if eid else '새로 만든다',
                 len(spans), len(vids),
                 ('  ⚠ 같은 이름 %s' % dup) if dup else ''))
        tot_v += len(vids)
        bad += 1 if dup else 0
    print('  ── 합계 용어 %d · 절 %d · 흠 %d' % (len(TERMS), tot_v, bad))
    return bad == 0


# ── 적용 ──────────────────────────────────────────────────────────────
def apply(conn, quiet=False):
    """멱등 — 용어·이름·설명·절 연결·플랜 연결."""
    n_new = n_v = n_l = 0
    for t in TERMS:
        pid = _plan_id(conn, t['plan'])
        if pid is None:
            continue
        eid = _eid(conn, t['code'])
        if eid is None:
            cur = conn.execute(
                'INSERT INTO sys_entity_master(entity_code,entity_type,importance,'
                " json_detail,record_status) VALUES(?,?,?,?,'LIVE')",
                (t['code'], ETYPE, 5, '{"seed": "%s"}' % MARK))
            eid = cur.lastrowid
            n_new += 1
        else:
            # ⚠ 있는 항목의 유형은 안 덮는다(§db_term_load 그 규칙)
            conn.execute("UPDATE sys_entity_master SET record_status='LIVE'"
                         ' WHERE entity_id=?', (eid,))
        _upsert_text(conn, eid, 'ENTITY_NAME', 'KO', t['ko'])
        _upsert_text(conn, eid, 'ENTITY_NAME', 'EN', t['en'])
        _upsert_text(conn, eid, 'ENTITY_DESC', 'KO', t['desc_ko'])
        _upsert_text(conn, eid, 'ENTITY_DESC', 'EN', t['desc_en'])

        # 절 연결 — **내가 만든 갈래만** 지우고 다시 넣는다(멱등)
        conn.execute("DELETE FROM sys_entity_verse WHERE entity_id=?"
                     "   AND link_kind='THEMATIC'", (eid,))
        order, seen = 0, set()
        for sv, ev in plan_spans(conn, pid):
            for i, v in enumerate(span_vids(conn, sv, ev)):
                if v in seen:
                    continue
                seen.add(v)
                order += 10
                conn.execute(
                    'INSERT INTO sys_entity_verse(entity_id,verse_id,link_kind,'
                    " is_key,sort_order,record_status)"
                    " VALUES(?,?,'THEMATIC',?,?,'LIVE')",
                    (eid, v, 1 if i == 0 else 0, order))
                n_v += 1

        # 플랜 연결 — 넉 자 코드 순(ENTI < PLAN)
        conn.execute("DELETE FROM sys_link_asset WHERE link_type='ENTI_PLAN'"
                     '   AND clicked_id=? AND target_id=?', (eid, pid))
        conn.execute("INSERT INTO sys_link_asset(clicked_id,target_id,link_type,"
                     " source,record_status) VALUES(?,?,'ENTI_PLAN',?,'LIVE')",
                     (eid, pid, MARK))
        n_l += 1
    conn.commit()
    if not quiet:
        print('심리·국면 용어 — 새로 %d개 · 절 연결 %d · 플랜 연결 %d'
              % (n_new, n_v, n_l))
    return n_new, n_v, n_l


def undo(conn, quiet=False):
    """되돌리기 — **이 도구가 만든 것만**(표식으로 좁힌다)."""
    ids = [r[0] for r in conn.execute(
        "SELECT entity_id FROM sys_entity_master WHERE entity_type=?"
        "   AND COALESCE(json_detail,'') LIKE ?", (ETYPE, '%' + MARK + '%'))]
    for eid in ids:
        conn.execute('DELETE FROM sys_entity_verse WHERE entity_id=?', (eid,))
        conn.execute("DELETE FROM sys_link_asset WHERE link_type='ENTI_PLAN'"
                     '   AND clicked_id=? AND source=?', (eid, MARK))
        conn.execute("DELETE FROM sys_text_asset WHERE clicked_id=?"
                     "   AND text_type IN ('ENTITY_NAME','ENTITY_DESC')", (eid,))
        conn.execute('DELETE FROM sys_entity_master WHERE entity_id=?', (eid,))
    conn.commit()
    if not quiet:
        print('되돌림 — 용어 %d개' % len(ids))
    return len(ids)


def listing(conn):
    rows = conn.execute(
        "SELECT e.entity_id,"
        " (SELECT contents FROM sys_text_asset t WHERE t.clicked_id=e.entity_id"
        "    AND t.text_type='ENTITY_NAME' AND t.lang_code='KO' LIMIT 1),"
        " (SELECT COUNT(*) FROM sys_entity_verse v WHERE v.entity_id=e.entity_id"
        "    AND COALESCE(v.record_status,'LIVE')='LIVE')"
        " FROM sys_entity_master e WHERE e.entity_type=?"
        "   AND COALESCE(e.record_status,'LIVE')='LIVE' ORDER BY e.entity_id",
        (ETYPE,)).fetchall()
    for eid, nm, n in rows:
        print('  #%-6d %-16s 절 %d' % (eid, nm or '-', n))
    print('  합계 %d개' % len(rows))
    return rows


# ── 자가 검증 ─────────────────────────────────────────────────────────
def selftest():
    ok = True

    def chk(name, cond, extra=''):
        nonlocal ok
        print(('  PASS ' if cond else '  FAIL ') + name
              + (' ' + str(extra) if extra != '' else ''))
        ok = ok and bool(cond)

    print('db_phase_terms selftest')
    chk('열 국면', len(TERMS) == 10, len(TERMS))
    chk('코드가 겹치지 않는다', len({t['code'] for t in TERMS}) == 10)
    chk('이름이 겹치지 않는다', len({t['ko'] for t in TERMS}) == 10)
    chk('설명이 다 있다', all(t['desc_ko'] and t['desc_en'] for t in TERMS))
    # ⚠ 우리 글 규약 — 빈 줄 금지(§28-11 ②) · 「—」 금지(§0-5 db_lens_load)
    chk('설명에 빈 줄 없음',
        not any('\n\n' in t['desc_ko'] or '\n\n' in t['desc_en'] for t in TERMS))
    chk('설명에 — 없음', not any('—' in t['desc_ko'] for t in TERMS))

    conn = appdb.connect()
    miss = [t['plan'] for t in TERMS if _plan_id(conn, t['plan']) is None]
    chk('짝이 되는 자가진단 플랜이 다 있다', not miss, miss)

    pid = _plan_id(conn, TERMS[0]['plan'])
    spans = plan_spans(conn, pid) if pid else []
    chk('구간을 읽는다', len(spans) > 0, len(spans))
    if spans:
        vs = span_vids(conn, *spans[0])
        chk('구간이 절로 풀린다', len(vs) >= 1, len(vs))
        chk('첫 절이 구간 시작', vs[0] == spans[0][0])
        chk('거꾸로 적힌 구간도 같은 절',
            span_vids(conn, spans[0][1], spans[0][0]) == vs)

    dups = [t['ko'] for t in TERMS if _name_clash(conn, t['ko'], t['code'])]
    chk('기존 용어와 이름이 안 겹친다', not dups, dups)

    # ★ 자동 연결기에 안 들어갔는가 — 들어가면 「불안」이 영상 제목을 먹는다
    try:
        import media_text_linker as _MT
        chk('자동 영상 연결기가 PHASE 를 안 본다', ETYPE not in _MT.ENTITY_TYPES)
        byl = getattr(_MT, 'TYPES_BY_LANG', {}) or {}
        chk('언어별 목록에도 없다', not any(ETYPE in v for v in byl.values()))
    except Exception as e:
        chk('자동 영상 연결기 확인', False, e)
    try:
        import db_term_link_audit as _TA
        chk('용어 재판정기가 PHASE 를 안 본다', ETYPE not in _TA.JUDGE_TYPES)
    except Exception as e:
        chk('용어 재판정기 확인', False, e)

    # 화면 배선 — 유형 단추·이름표
    try:
        import entity_browser as _EB
        chk('주요용어 유형 단추에 있다', ETYPE in _EB._TYPE_CODES)
        miss_l = [k for k, v in _EB._TYPE_LABEL.items() if ETYPE not in v]
        chk('유형 이름이 모든 언어에 있다', not miss_l, miss_l)
    except Exception as e:
        chk('주요용어 화면 확인', False, e)
    try:
        import admin.panel_entity_manager as _PE
        chk('관리자 유형 목록에 있다', ETYPE in _PE._ENTITY_TYPES)
    except Exception as e:
        chk('관리자 화면 확인', False, e)

    conn.close()
    print('RESULT:', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def main():
    args = sys.argv[1:]
    if '--selftest' in args:
        raise SystemExit(selftest())
    conn = appdb.connect()
    try:
        if '--apply' in args:
            apply(conn)
            listing(conn)
        elif '--undo' in args:
            undo(conn)
        elif '--list' in args:
            listing(conn)
        else:
            check(conn)
    finally:
        conn.close()


if __name__ == '__main__':
    main()
