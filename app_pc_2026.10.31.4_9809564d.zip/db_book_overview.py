# -*- coding: utf-8 -*-
"""db_book_overview.py — 책 개요(BOOK_DESC) 적재 + 게이트 (영구, 2026-08-26).

사용자 승인 구조(13-47 · CLAUDE.md 92차): 66권 × KO·EN, 한 편 = 6문단 —
  머리 한 줄(없음)
  누가 · 언제 — …   (컨센서스 먼저, 다른 견해는 한두 문장)
  배경 — …
  무엇을 말하나 — …  (컨센서스만 — 내용 요약에 학설을 섞지 않는다)
  어떻게 짜여 있나 — …
  묵상 참고 — …

게이트(§67차 도서 소개문 선례):
  · 문단 6개 정확히, 빈 줄(\n\n) 금지 — 문단 사이 \n 하나
  · 블록 머리 5개가 정해진 이름·순서(— 는 머리 구분자로만, 본문 전체 5개)
  · 분량 KO 600~1,200자 · EN 600~2,000자
  · 교단 귀속어·작업과정 낱말 금지(§28-11 — 종교개혁 등 역사 서술은 허용)
  · KO 합니다체(존댓말 어미 검사)

초안 = `_bookdesc_prep/*.txt` (gitignore). 형식:
  === <bcode> <이름> <KO|EN>
  <본문 6문단 — 실제 개행>
저장 = sys_text_asset(text_type='BOOK_DESC', clicked_id=bcode, variant NULL).
멱등 — LIVE 행 갱신 · HIDE 행 되살림 · 없으면 INSERT. 같으면 「그대로」.

사용:  python db_book_overview.py --selftest | --check | --apply | --status
"""
import os
import re
import sys
import glob

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
PREP = os.path.join(HERE, '_bookdesc_prep')
DB = os.path.join(HERE, 'bible_master.db')

HEAD = {
    'KO': ['누가 · 언제', '배경', '무엇을 말하나', '어떻게 짜여 있나', '묵상 참고'],
    'EN': ['Who · When', 'Background', 'What It Says', 'How It Is Arranged',
           'For Meditation'],
}
LEN = {'KO': (600, 1200), 'EN': (600, 2000)}

# 교단 귀속어(§28-11 — 역사적 사건·인물 서술은 허용이라 「종교개혁」은 안 막는다)
BAN_KO = ['칼뱅', '칼빈', '개혁주의', '개혁파', '루터파', '알미니안',
          '아르미니우스', '장로교', '감리교', '침례교', '천주교', '가톨릭',
          '화체설',
          # 작업과정 낱말(§67차)
          '적재', '파서', 'OCR', '임포트', '재추출', '멱등', '스크립트']
BAN_EN = ['Calvinis', 'Reformed', 'Lutheran', 'Arminian', 'Presbyterian',
          'Baptist', 'Methodist', 'Catholic doctrine', 'importer']


def gate(text, lang):
    """한 편 검사 → 위반 목록(비면 통과)."""
    errs = []
    t = (text or '').strip()
    if not t:
        return ['빈 본문']
    if '\n\n' in t:
        errs.append('빈 줄(\\n\\n) — 문단 사이는 \\n 하나')
    lines = t.split('\n')
    if len(lines) != 6:
        errs.append('문단 %d개 (6개여야)' % len(lines))
    else:
        # ⚠ 블록 머리 표식(``)을 걷었으므로(2026-09-07 사용자 지시) 머리
        #   한 줄은 **블록 이름으로 시작하지 않는가**로 가린다. 표식으로
        #   재던 것을 그대로 두면 `startswith('')` 가 늘 참이라 통째로 걸린다.
        if any(lines[0].startswith(nm) for nm in HEAD[lang]):
            errs.append('머리 한 줄이 블록 머리다')
        for i, name in enumerate(HEAD[lang]):
            want = '%s — ' % name
            if not lines[i + 1].startswith(want):
                errs.append('블록 %d ≠ 「%s」 (실제: %s…)'
                            % (i + 1, want.strip(), lines[i + 1][:16]))
    if t.count('—') != 5:
        errs.append('— 가 %d개 (블록 머리 구분자 5개만)' % t.count('—'))
    lo, hi = LEN[lang]
    if not (lo <= len(t) <= hi):
        errs.append('분량 %d자 (%d~%d)' % (len(t), lo, hi))
    # ⚠ 「John the Baptist」는 인명이지 교단이 아니다 — §67차 Scripture 함정과
    #   같은 계열(금지어가 정상 표현 안에 들어 있는 경우). 떼고 검사한다.
    scan = t.replace('John the Baptist', '')
    for w in (BAN_KO if lang == 'KO' else BAN_EN):
        if w in scan:
            errs.append('금지어 「%s」' % w)
    if lang == 'KO' and t.count('니다') < 5:
        errs.append('합니다체 아님(존댓말 어미 부족)')
    return errs


def parse(path):
    """초안 파일 → [(bcode, 이름, lang, text)]."""
    items = []
    cur = None
    body = []
    with open(path, encoding='utf-8') as f:
        for raw in f.read().splitlines():
            m = re.match(r'^===\s+(\d+)\s+(\S+)\s+(KO|EN)\s*$', raw)
            if m:
                if cur:
                    items.append((*cur, '\n'.join(body).strip()))
                cur = (int(m.group(1)), m.group(2), m.group(3))
                body = []
            elif cur is not None:
                body.append(raw)
    if cur:
        items.append((*cur, '\n'.join(body).strip()))
    return items


def load_all():
    items = []
    for p in sorted(glob.glob(os.path.join(PREP, '*.txt'))):
        items.append((p, parse(p)))
    return items


def check(verbose=True):
    ok = True
    seen = {}
    for path, items in load_all():
        for bcode, name, lang, text in items:
            key = (bcode, lang)
            if key in seen:
                ok = False
                print('FAIL %s %s %s — 중복(%s)' % (bcode, name, lang, seen[key]))
            seen[key] = os.path.basename(path)
            errs = gate(text, lang)
            if errs:
                ok = False
                for e in errs:
                    print('FAIL %s %s %s — %s' % (bcode, name, lang, e))
    missing = [(b, lg) for b in range(1, 67) for lg in ('KO', 'EN')
               if (b, lg) not in seen]
    if missing and seen:
        print('미완: %d편 — %s%s' % (len(missing), missing[:8],
                                     ' …' if len(missing) > 8 else ''))
    if verbose:
        print('check: %d편 · 위반 %s · 미완 %d'
              % (len(seen), '0' if ok else '있음', len(missing)))
    return ok, len(seen), len(missing)


def apply(db_path=None):
    import appdb
    ok, _n, _m = check(verbose=False)
    if not ok:
        print('게이트 위반이 있어 적재하지 않습니다 — --check 로 확인.')
        return None
    new = upd = same = 0
    with appdb.connect(db_path or DB) as c:
        for _path, items in load_all():
            for bcode, _name, lang, text in items:
                row = c.execute(
                    "SELECT sys_text_id, contents, record_status "
                    "FROM sys_text_asset WHERE text_type='BOOK_DESC' "
                    "AND clicked_id=? AND lang_code=? AND text_variant IS NULL "
                    "ORDER BY (CASE record_status WHEN 'LIVE' THEN 0 ELSE 1 END) "
                    "LIMIT 1", (bcode, lang)).fetchone()
                if row:
                    if row[1] == text and row[2] == 'LIVE':
                        same += 1
                        continue
                    c.execute("UPDATE sys_text_asset SET contents=?, "
                              "record_status='LIVE' WHERE sys_text_id=?",
                              (text, row[0]))
                    upd += 1
                else:
                    c.execute("INSERT INTO sys_text_asset(clicked_id, text_type, "
                              "contents, lang_code, record_status, text_variant) "
                              "VALUES(?, 'BOOK_DESC', ?, ?, 'LIVE', NULL)",
                              (bcode, text, lang))
                    new += 1
        c.commit()
    print('apply: 새로 %d · 갱신 %d · 그대로 %d' % (new, upd, same))
    return new, upd, same


def status(db_path=None):
    import appdb
    with appdb.connect(db_path or DB) as c:
        rows = c.execute(
            "SELECT lang_code, COUNT(DISTINCT clicked_id) FROM sys_text_asset "
            "WHERE text_type='BOOK_DESC' "
            "AND COALESCE(record_status,'LIVE')='LIVE' "
            "GROUP BY 1 ORDER BY 1").fetchall()
    for lg, n in rows:
        print('%s %d/66' % (lg, n))
    if not rows:
        print('(없음)')


_PAD = '이 문장은 분량을 채우는 시험 문장입니다. ' * 4
GOOD_KO = '\n'.join([
    '시험책은 시험을 위한 책입니다. ' + _PAD,
    '누가 · 언제 — 시험 저자가 썼다고 고백해 왔습니다. 다르게 보는 견해도 있습니다. ' + _PAD,
    '배경 — 시험 배경을 설명합니다. 독자를 생각하며 썼습니다. ' + _PAD,
    '무엇을 말하나 — 시험 내용을 말합니다. 약속이 이어집니다. ' + _PAD,
    '어떻게 짜여 있나 — 두 부분입니다. 견해가 조금씩 다릅니다. ' + _PAD,
    '묵상 참고 — 그리스도를 바라보며 읽습니다. 소망이 됩니다. ' + _PAD,
]).strip()


def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    g = GOOD_KO
    t('정상 통과', gate(g, 'KO') == [], gate(g, 'KO'))
    # 탐지력 — 위반을 실제로 잡는가(§0-1b: 탐지력 먼저)
    t('★ 빈 줄 잡음', any('빈 줄' in e for e in gate(g.replace('\n', '\n\n', 1), 'KO')))
    t('★ 블록 순서 잡음', any('블록' in e for e in
                          gate(g.replace('배경', '묵상 참고', 1), 'KO')))
    t('★ 문단 수 잡음', any('문단' in e for e in
                          gate(g + '\n덧붙임 문단입니다.', 'KO')))
    t('★ 금지어 잡음', any('금지어' in e for e in
                         gate(g.replace('시험 배경을', '개혁주의 배경을'), 'KO')))
    t('★ 여분 — 잡음', any('— 가' in e for e in
                         gate(g.replace('책입니다.', '책 — 입니다.', 1), 'KO')))
    t('★ 분량 잡음', any('분량' in e for e in gate(g[:300], 'KO')))
    t('★ 합니다체 잡음', any('합니다체' in e for e in
                          gate(g.replace('니다', '다'), 'KO')))
    # 파서 왕복
    import tempfile
    with tempfile.NamedTemporaryFile('w', suffix='.txt', delete=False,
                                     encoding='utf-8') as f:
        f.write('=== 1 창세기 KO\n%s\n=== 1 창세기 EN\nplaceholder\n' % g)
        p = f.name
    items = parse(p)
    os.unlink(p)
    t('파서 — 2편·본문 보존', len(items) == 2 and items[0][3] == g
      and items[0][:3] == (1, '창세기', 'KO'))
    print('db_book_overview selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv[1:] or ['--status']
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    elif '--check' in a:
        check()
    elif '--apply' in a:
        apply()
    else:
        status()
