# -*- coding: utf-8 -*-
"""주석 원문의 OCR 오자 바로잡기 — 다른 판을 **증인**으로만 쓴다(2026-10-31 사용자 「ocr 흠은 매우 중요하다」).

★ 까닭 — BARNES 빌립보서 시범에서 번역 AI 가 표시한 원문 의심은 27건인데, 대조하면 뚜렷한 오자가 약 60곳이다
  (axe→are · theft→their · tile→the · shah→shall · ill→in · 깨진 헬라어 음역 karpov→karpos).
⚠⚠ **BibleHub 글로 갈아 끼우지 않는다** — 그 판은 낱말을 현대식으로 바꿨고(slew→killed · peculiar→special)
  제 오자도 있다(jesus→jesses). 우리 글은 그대로 두고 **낱말 하나씩** 아래를 모두 만족할 때만 고친다:
    ① 같은 자리에서 낱말 하나가 낱말 하나로 바뀌었다 ② 철자가 비슷하다(편집 거리 2 이하)
    ③ 영·미 철자 차이가 아니다 ④ 우리 낱말은 그 주석 전권에서 드물고 증인 낱말은 흔하다(FREQ_*)
  또는 ⑤ 헬라어 음역의 끝 글자 v → s(줄기가 같다).
  그 밖의 후보(be/he · east/cast …)는 고치지 않고 **사람이 볼 목록**으로 낸다.

쓰는 법
  python db_comm_ocr.py --selftest
  python db_comm_ocr.py --check BARNES_NT PHP        고칠 것·볼 것을 찍는다(안 고친다)
  python db_comm_ocr.py --apply BARNES_NT PHP        고친다(멱등 · 기록 sys_comm_ocr_log)
  python db_comm_ocr.py --undo  BARNES_NT PHP        되돌린다(그 뒤 사람이 고친 글은 안 건드린다)
  python db_comm_ocr.py --known GILL [책]            오류점검용 목록(ocr_confusions.json) 낱말을 찾아 보인다(안 고친다 · 증인 불필요)
증인 글은 `_witness/` 에 두고(저장소·배포 밖) 앱에 싣지 않는다.
"""
import difflib
import html
import json
import os
import re
import sys
import time
import urllib.request

APP = os.path.dirname(os.path.abspath(__file__))
if APP not in sys.path:
    sys.path.insert(0, APP)

WITNESS_DIR = os.path.join(APP, '_witness')
#: 우리 낱말이 이보다 흔하면 오자로 안 본다 / 증인 낱말은 우리 낱말의 이 배수 이상 흔해야 한다
FREQ_MAX = 200
FREQ_RATIO = 20
FREQ_MIN_NEW = 30
#: 옛 철자 — 증인이 현대식으로 바꾼 것(오자가 아니다)
OLD_SPELL = {('dependant', 'dependent'), ('hinderance', 'hindrance'), ('intrusted', 'entrusted')}
#: 뜻이 있는 낱말이라 증인만 믿고 고치면 안 되는 것(실측: 빌 2:10 bow → 증인의 오자 how)
PROTECT = {'bow'}
#: 볼 것 가운데 사람이 읽어 확정한 것 — (주석, 책): [(옛 낱말, 새 낱말, 문맥 조각)]
MANUAL = {('BARNES_NT', 'PHP'): [('Part', 'Paul', 'Saviour Part preached'), ('east', 'cast', 'be east into the'),
                                  ('me', 'we', 'whom me may roll'), ('dosing', 'closing', 'this dosing chapter'),
                                  ('fails', 'falls', 'as he fails it'), ('he', 'be', 'It may he his')]}
BH_SLUG = {'MAT': 'matthew', 'MRK': 'mark', 'LUK': 'luke', 'JHN': 'john', 'ACT': 'acts', 'ROM': 'romans',
           '1CO': '1_corinthians', '2CO': '2_corinthians', 'GAL': 'galatians', 'EPH': 'ephesians',
           'PHP': 'philippians', 'COL': 'colossians', '1TH': '1_thessalonians', '2TH': '2_thessalonians',
           '1TI': '1_timothy', '2TI': '2_timothy', 'TIT': 'titus', 'PHM': 'philemon', 'HEB': 'hebrews',
           'JAS': 'james', '1PE': '1_peter', '2PE': '2_peter', '1JN': '1_john', '2JN': '2_john',
           '3JN': '3_john', 'JUD': 'jude', 'REV': 'revelation'}
#: 우리 DB 의 책 코드 → 위 표의 코드(주석 표는 옛 코드를 쓴다)
BCODE_ALIAS = {'CO1': '1CO', 'CO2': '2CO', 'TH1': '1TH', 'TH2': '2TH', 'TI1': '1TI', 'TI2': '2TI',
               'PE1': '1PE', 'PE2': '2PE', 'JO1': '1JN', 'JO2': '2JN', 'JO3': '3JN', 'JDE': 'JUD',
               'JOH': 'JHN', 'MAR': 'MRK', 'JAM': 'JAS'}
BH_NAME = {'BARNES_NT': 'barnes'}

#: ★ 2026-10-31 사용자 「오류점검용 목록에 저장해두었다가 다시 사용하자」 — 책·주석이 달라도 같은 스캔 오자가 되풀이된다
KNOWN_FILE = os.path.join(APP, 'ocr_confusions.json')


def load_known():
    """{'pairs': {'axe': {'new': 'are', 'n': 3, 'from': ['BARNES_NT:PHP']}}, 'protect': ['bow']}"""
    try:
        with open(KNOWN_FILE, encoding='utf-8') as f:
            d = json.load(f)
    except (OSError, ValueError):
        d = {}
    d.setdefault('pairs', {})
    d.setdefault('protect', sorted(PROTECT))
    return d


def save_known(d):
    d['pairs'] = dict(sorted(d['pairs'].items()))
    d['protect'] = sorted(set(d['protect']))
    d.setdefault('reject', [])
    with open(KNOWN_FILE, 'w', encoding='utf-8', newline=chr(10)) as f:
        json.dump(d, f, ensure_ascii=False, indent=1)


def learn(d, recs, where):
    """적용한 고침을 목록에 더한다 — 끝 글자가 깨진 헬라어는 낱말마다 달라 목록에 안 넣는다"""
    for r in recs:
        o, n = r[3].lower(), r[4].lower()
        if greek_end(o, n):
            continue
        p = d['pairs'].setdefault(o, {'new': n, 'n': 0, 'from': []})
        if p['new'] == n:
            p['n'] += 1
            if where not in p['from']:
                p['from'].append(where)


def known_hits(conn, code, book=None, d=None):
    """증인 없이 목록 낱말이 나오는 자리를 찾는다 — 다른 주석·다른 책 점검용 · [(글번호, 책, 장, 옛, 새, 판정, 문맥)]
    판정 = 앞뒤 낱말이 새 낱말 쪽을 가리키면 'LIKELY' · 아니면 'LOOK'(사람이 본다 · 고치지 않는다)"""
    d = d or load_known()
    cid = cid_of(conn, code)
    freq = book_freq(conn, cid)
    q = ("SELECT t.text_id, e.bcode, e.chapter, t.body_text FROM sys_commentary_entry e JOIN sys_commentary_text t USING(entry_id) "
         "WHERE e.commentary_id=? AND t.lang_code='EN' AND t.text_variant='ORIGINAL'")
    a = [cid]
    if book:
        q += ' AND e.bcode=?'
        a.append(book)
    out = []
    for tid, bc, ch, body in conn.execute(q, a).fetchall():
        ws = list(_WORD.finditer(body or ''))
        for i, m in enumerate(ws):
            o = m.group().lower()
            p = d['pairs'].get(o)
            if not p or o in d['protect']:
                continue
            pv = ws[i - 1].group().lower() if i else ''
            nx = ws[i + 1].group().lower() if i + 1 < len(ws) else ''
            v = 'LIKELY' if context_ok(o, p['new'], pv, nx, freq) else 'LOOK'
            ctx = ' '.join(w.group() for w in ws[max(0, i - 4):i + 4])
            out.append((tid, bc, ch, m.group(), same_case(p['new'], m.group()), v, ctx))
    return out


SCHEMA = """
CREATE TABLE IF NOT EXISTS sys_comm_ocr_log (
    log_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    text_id    INTEGER NOT NULL,
    entry_id   INTEGER NOT NULL,
    code       TEXT, bcode TEXT, chapter INTEGER,
    old_body   TEXT, new_body TEXT,
    changes    TEXT,
    undone     INTEGER DEFAULT 0,
    created_at TEXT
);
"""
_WORD = re.compile(r'[A-Za-z]+')


def ed(a, b):
    p = list(range(len(b) + 1))
    for i, x in enumerate(a, 1):
        q = [i]
        for j, y in enumerate(b, 1):
            q.append(min(p[j] + 1, q[-1] + 1, p[j - 1] + (x != y)))
        p = q
    return p[-1]


def spell_variant(a, b):
    """영·미 철자 차이 · 옛 철자 · 어미만 다른 것 — 증인의 현대화이지 오자가 아니다"""
    if (a, b) in OLD_SPELL:
        return True
    def n(s):
        return s.replace('our', 'or').replace('ll', 'l').replace('ae', 'e').replace('ise', 'ize').replace('xion', 'ction')
    if n(a) == n(b) or n(a).replace('re', 'er') == n(b).replace('re', 'er'):
        return True
    return a + 's' == b or b + 's' == a or a + 'ed' == b or a + 'd' == b or b + 'd' == a


def greek_end(o, n):
    """헬라어 음역의 끝 시그마가 v 로 깨진 것 — karpov→karpos"""
    return len(o) >= 4 and o.endswith('v') and n == o[:-1] + 's'


def judge(o, n, freq):
    """(o, n) → 'FIX'(고친다) · 'LOOK'(사람이 본다) · ''(증인의 표기 차이 — 버린다)"""
    if o == n or len(o) < 2 or ed(o, n) > 2 or spell_variant(o, n):
        return ''
    _kn = load_known()
    if '%s>%s' % (o, n) in _kn.get('reject', ()):
        return ''                                     # 사람이 읽고 버린 후보(증인의 현대어·증인의 오자)
    if o in PROTECT or o in _kn['protect']:
        return 'LOOK'
    if greek_end(o, n):
        return 'FIX'
    fo, fn = freq.get(o, 0), freq.get(n, 0)
    if fo <= FREQ_MAX and fn >= FREQ_MIN_NEW and fn >= fo * FREQ_RATIO:
        return 'FIX'
    # 증인 낱말이 우리 책에 드물면 증인의 오자일 가능성이 크다 — 안 보인다
    return 'LOOK' if fn >= FREQ_MIN_NEW and fn > fo else ''


def context_ok(o, n, pv, nx, freq):
    """★ 진짜 낱말을 증인의 오자로 고치지 않게 — 실측: 빌 2:10 「we bow at」 → 증인 「how」.
    낱말 빈도만으로는 못 가른다(bow 49 · how 1957). 앞뒤 낱말과 **붙어 나온 수**를 양쪽 다 견준다.
    이 글 자신의 한 번은 뺀다(한 번뿐인 오자를 근거로 삼지 않는다)."""
    lo, ln = max(0, freq.get((pv, o), 0) - 1), freq.get((pv, n), 0)
    ro, rn = max(0, freq.get((o, nx), 0) - 1), freq.get((n, nx), 0)
    return ln >= lo and rn >= ro and (ln + rn) > (lo + ro)


def same_case(new, old):
    if old.isupper() and len(old) > 1:
        return new.upper()
    return new[0].upper() + new[1:] if old[:1].isupper() else new


def find_fixes(entries, witness_text, freq):
    """entries [(entry_id, 글)] 를 이어 증인과 맞춘다 → (고칠 것[(entry, 시작, 끝, old, new, 문맥)], 볼 것[…])"""
    toks = []
    for eid, body in entries:
        for m in _WORD.finditer(body or ''):
            toks.append((eid, m.start(), m.end(), m.group()))
    wb = _WORD.findall(witness_text)
    sm = difflib.SequenceMatcher(None, [t[3].lower() for t in toks], [w.lower() for w in wb], autojunk=False)
    fix, look = [], []
    for op, a, e, x, y in sm.get_opcodes():
        if op != 'replace' or e - a != 1 or y - x != 1:
            continue
        t = toks[a]
        o, n = t[3].lower(), wb[x].lower()
        v = judge(o, n, freq)
        if not v:
            continue
        if v == 'FIX' and not greek_end(o, n):
            pv = toks[a - 1][3].lower() if a else ''
            nx = toks[a + 1][3].lower() if a + 1 < len(toks) else ''
            if not context_ok(o, n, pv, nx, freq):
                v = 'LOOK'
        ctx = ' '.join(w[3] for w in toks[max(0, a - 4):a + 4])
        rec = (t[0], t[1], t[2], t[3], same_case(n, t[3]), ctx)
        (fix if v == 'FIX' else look).append(rec)
    return fix, look


def apply_to(body, recs):
    for _e, s, en, old, new, _c in sorted(recs, key=lambda r: -r[1]):
        if body[s:en] == old:
            body = body[:s] + new + body[en:]
    return body


# ── 증인 ────────────────────────────────────────────────────────────
def witness(code, book, ch):
    slug = BH_SLUG[BCODE_ALIAS.get(book, book)]
    d = os.path.join(WITNESS_DIR, code)
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, '%s_%d.html' % (slug, ch))
    if not os.path.exists(p):
        u = 'https://biblehub.com/commentaries/%s/%s/%d.htm' % (BH_NAME[code], slug, ch)
        t = urllib.request.urlopen(urllib.request.Request(u, headers={'User-Agent': 'Mozilla/5.0'}), timeout=30).read()
        with open(p, 'wb') as f:
            f.write(t)
        time.sleep(1.0)
    t = open(p, encoding='utf-8', errors='replace').read()
    return html.unescape(re.sub(r'<[^>]+>', ' ', re.sub(r'(?s)<(script|style).*?</\1>', ' ', t)))


# ── DB ──────────────────────────────────────────────────────────────
def cid_of(conn, code):
    return conn.execute('SELECT commentary_id FROM sys_commentary_source WHERE commentary_code=?', (code,)).fetchone()[0]


def book_freq(conn, cid):
    c = {}
    for (b,) in conn.execute("SELECT t.body_text FROM sys_commentary_text t JOIN sys_commentary_entry e USING(entry_id) "
                             "WHERE e.commentary_id=? AND t.lang_code='EN' AND t.text_variant='ORIGINAL'", (cid,)):
        p = ''
        for w in _WORD.findall(b or ''):
            w = w.lower()
            c[w] = c.get(w, 0) + 1
            c[(p, w)] = c.get((p, w), 0) + 1
            p = w
    return c


def chapter_rows(conn, cid, book):
    rows = conn.execute(
        "SELECT e.chapter, e.entry_id, t.text_id, t.body_text FROM sys_commentary_entry e "
        "JOIN sys_commentary_text t USING(entry_id) WHERE e.commentary_id=? AND e.bcode=? AND t.lang_code='EN' "
        "AND t.text_variant='ORIGINAL' AND COALESCE(e.record_status,'LIVE')='LIVE' "
        "ORDER BY e.chapter, e.start_vid, e.entry_id", (cid, book)).fetchall()
    out = {}
    for ch, eid, tid, b in rows:
        out.setdefault(ch, []).append((eid, tid, b))
    return out


def scan(conn, code, book):
    cid = cid_of(conn, code)
    freq = book_freq(conn, cid)
    res = {}
    for ch, rows in chapter_rows(conn, cid, book).items():
        if not ch:
            continue
        fix, look = find_fixes([(e, b) for e, _t, b in rows], witness(code, book, ch), freq)
        man = MANUAL.get((code, book), ())
        for r in list(look):
            if any(r[3] == o and r[4] == n and c in r[5] for o, n, c in man):
                look.remove(r)
                fix.append(r)
        res[ch] = (rows, fix, look)
    return res


def do_apply(conn, code, book, learn_on=True):
    conn.executescript(SCHEMA)
    n_e = n_w = 0
    known = load_known()
    for ch, (rows, fix, _look) in scan(conn, code, book).items():
        for eid, tid, body in rows:
            recs = [r for r in fix if r[0] == eid]
            if not recs:
                continue
            new = apply_to(body, recs)
            conn.execute("UPDATE sys_commentary_text SET body_text=? WHERE text_id=?", (new, tid))
            conn.execute("INSERT INTO sys_comm_ocr_log(text_id, entry_id, code, bcode, chapter, old_body, new_body, changes, created_at)"
                         " VALUES(?,?,?,?,?,?,?,?,datetime('now','localtime'))",
                         (tid, eid, code, book, ch, body, new,
                          json.dumps([[r[3], r[4]] for r in recs], ensure_ascii=False)))
            n_e += 1
            n_w += len(recs)
            if learn_on:
                learn(known, recs, '%s:%s' % (code, book))
    conn.commit()
    if learn_on and n_w:
        save_known(known)
    return n_e, n_w


def do_undo(conn, code, book):
    conn.executescript(SCHEMA)
    n = kept = 0
    for lid, tid, old, new in conn.execute(
            "SELECT log_id, text_id, old_body, new_body FROM sys_comm_ocr_log WHERE code=? AND bcode=? AND undone=0 "
            "ORDER BY log_id DESC", (code, book)).fetchall():
        cur = conn.execute("SELECT body_text FROM sys_commentary_text WHERE text_id=?", (tid,)).fetchone()
        if cur and cur[0] == new:
            conn.execute("UPDATE sys_commentary_text SET body_text=? WHERE text_id=?", (old, tid))
            conn.execute("UPDATE sys_comm_ocr_log SET undone=1 WHERE log_id=?", (lid,))
            n += 1
        else:
            kept += 1
    conn.commit()
    return n, kept


# ── 자가 검증 ───────────────────────────────────────────────────────
def selftest():
    bad = []

    def ck(c, m):
        print(('  PASS ' if c else '  FAIL ') + m)
        if not c:
            bad.append(m)

    f = {'axe': 36, 'are': 12800, 'theft': 52, 'their': 12095, 'he': 32299, 'be': 35193, 'jesus': 4128, 'jesses': 0,
         'slew': 40, 'killed': 200, 'defence': 150, 'defense': 2, 'east': 318, 'cast': 398, 'connexion': 502,
         'connection': 65, 'dependant': 7, 'dependent': 133, 'religions': 14, 'religion': 3516}
    ck(judge('axe', 'are', f) == 'FIX', 'axe→are 고친다')
    ck(judge('bow', 'how', {'bow': 49, 'how': 1957}) == 'LOOK', '지킬 낱말 bow')
    ck(judge('theft', 'their', f) == 'FIX', 'theft→their 고친다')
    ck(judge('karpov', 'karpos', f) == 'FIX', '헬라어 끝 글자')
    ck(judge('be', 'he', f) == '', '흔한 낱말끼리는 안 고친다(be/he 빈도가 비슷)')
    ck(judge('jesus', 'jesses', f) == '', '증인의 오자는 버린다')
    ck(judge('slew', 'killed', f) == '', '증인의 현대어 바꿈은 버린다')
    ck(judge('defence', 'defense', f) == '', '영·미 철자')
    ck(judge('connexion', 'connection', f) == '', '옛 철자')
    ck(judge('dependant', 'dependent', f) == '', '옛 철자 표')
    ck(judge('religions', 'religion', f) == '', '어미만 다른 것은 안 고친다')
    ck(judge('east', 'cast', f) == 'LOOK', '판별 애매 = 사람이 본다')
    ck(same_case('their', 'Theft') == 'Their' and same_case('are', 'AXE') == 'ARE', '대소문자 지킴')
    ck(not context_ok('bow', 'how', 'we', 'at', {('we', 'bow'): 4, ('bow', 'at'): 5, ('we', 'how'): 9}), '진짜 낱말 bow 를 안 고친다')
    ck(context_ok('axe', 'are', 'motives', 'disinterested', {('motives', 'axe'): 1, ('axe', 'disinterested'): 1, ('motives', 'are'): 6}), '오자 axe 는 고친다')
    f.update({('they', 'are'): 9, ('are', 'bound'): 9, ('they', 'axe'): 1, ('axe', 'bound'): 1, ('desire', 'their'): 3, ('their', 'happiness'): 5})
    e = [(1, 'They axe bound to do this.'), (2, 'We desire theft happiness and be glad.')]
    w = 'Site menu They are bound to do this. We desire their happiness and he glad. Footer'
    fx, lk = find_fixes(e, w, f)
    ck([(r[0], r[3], r[4]) for r in fx] == [(1, 'axe', 'are'), (2, 'theft', 'their')], '자리 맞추기 %s' % [r[3] for r in fx])
    ck(apply_to(e[0][1], [r for r in fx if r[0] == 1]) == 'They are bound to do this.', '글 고치기')
    ck(apply_to('x', fx) == 'x', '글이 다르면 안 고친다')
    _d = {'pairs': {}, 'protect': []}
    learn(_d, [(1, 0, 3, 'Axe', 'Are', ''), (1, 0, 3, 'axe', 'are', ''), (1, 0, 3, 'karpov', 'karpos', '')], 'T:X')
    ck(_d['pairs'] == {'axe': {'new': 'are', 'n': 2, 'from': ['T:X']}}, '목록에 배운다(헬라어 끝 글자는 뺀다) %s' % _d['pairs'])
    # DB 왕복 — 메모리 DB
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.executescript("""CREATE TABLE sys_commentary_source(commentary_id INTEGER, commentary_code TEXT);
      CREATE TABLE sys_commentary_entry(entry_id INTEGER, commentary_id INTEGER, bcode TEXT, chapter INTEGER, start_vid INTEGER, record_status TEXT);
      CREATE TABLE sys_commentary_text(text_id INTEGER, entry_id INTEGER, lang_code TEXT, text_variant TEXT, body_text TEXT);
      INSERT INTO sys_commentary_source VALUES(1,'T');INSERT INTO sys_commentary_entry VALUES(1,1,'PHP',1,1,'LIVE');
      INSERT INTO sys_commentary_text VALUES(1,1,'EN','ORIGINAL','They axe bound.');""")
    global witness
    _w = witness
    witness = lambda code, book, ch: 'They are bound.'
    _bf = globals()['book_freq']
    globals()['book_freq'] = lambda conn, cid: {'axe': 1, 'are': 500, ('they', 'are'): 9, ('are', 'bound'): 9}
    try:
        ck(do_apply(c, 'T', 'PHP', False) == (1, 1), '적용')
        ck(c.execute('SELECT body_text FROM sys_commentary_text').fetchone()[0] == 'They are bound.', '글이 고쳐짐')
        ck(do_apply(c, 'T', 'PHP', False) == (0, 0), '멱등')
        ck(do_undo(c, 'T', 'PHP') == (1, 0), '되돌림')
        ck(c.execute('SELECT body_text FROM sys_commentary_text').fetchone()[0] == 'They axe bound.', '원래 글')
        do_apply(c, 'T', 'PHP', False)
        c.execute("UPDATE sys_commentary_text SET body_text='사람이 고침'")
        ck(do_undo(c, 'T', 'PHP') == (0, 1), '사람이 고친 글은 안 되돌림')
    finally:
        witness = _w
        globals()['book_freq'] = _bf
    print('db_comm_ocr selftest: %s' % ('OK' if not bad else 'FAIL %d' % len(bad)))
    return 1 if bad else 0


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    if '--selftest' in sys.argv:
        sys.exit(selftest())
    import appdb
    conn = appdb.connect()
    if '--apply' in sys.argv:
        i = sys.argv.index('--apply')
        print('고친 항목·낱말', do_apply(conn, sys.argv[i + 1], sys.argv[i + 2]))
    elif '--undo' in sys.argv:
        i = sys.argv.index('--undo')
        print('되돌림·그대로 둠', do_undo(conn, sys.argv[i + 1], sys.argv[i + 2]))
    elif '--known' in sys.argv:
        i = sys.argv.index('--known')
        hits = known_hits(conn, sys.argv[i + 1], sys.argv[i + 2] if len(sys.argv) > i + 2 else None)
        for h in hits:
            print('  %s %s %s:%s %s → %s | %s' % (h[5], h[0], h[1], h[2], h[3], h[4], h[6]))
        print('목록 낱말 %d곳 (LIKELY %d · LOOK %d) — 고치지 않았다' % (len(hits), sum(h[5] == 'LIKELY' for h in hits), sum(h[5] == 'LOOK' for h in hits)))
    elif '--seed-known' in sys.argv:
        k = load_known()
        for lid, cg, bk, ch in conn.execute("SELECT log_id, code, bcode, changes FROM sys_comm_ocr_log WHERE undone=0").fetchall():
            learn(k, [(0, 0, 0, o, n, '') for o, n in json.loads(ch)], '%s:%s' % (cg, bk))
        save_known(k)
        print('목록', len(k['pairs']), '낱말')
    elif '--check' in sys.argv:
        i = sys.argv.index('--check')
        F = L = 0
        for ch, (_r, fix, look) in scan(conn, sys.argv[i + 1], sys.argv[i + 2]).items():
            print('== %s장 고침 %d · 볼 것 %d' % (ch, len(fix), len(look)))
            for r in fix:
                print('  FIX  %s → %s   | %s' % (r[3], r[4], r[5]))
            for r in look:
                print('  LOOK %s → %s   | %s' % (r[3], r[4], r[5]))
            F += len(fix)
            L += len(look)
        print('합계 고침 %d · 볼 것 %d' % (F, L))
