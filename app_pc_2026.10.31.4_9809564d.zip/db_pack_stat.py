# -*- coding: utf-8 -*-
"""db_pack_stat.py — **스몰팩 통계와 릴리스 패킹**
(2026-09-05 신설·영구 · `--selftest` 의무).

★★★ 왜 (사용자 확정 설계):
  「모든 자산 단위가 조각조각 **스몰팩** 단위를 구성하도록 만든다. **릴리스
   패킹 머신**은 각 스몰팩 단위를 지정해서 하나의 릴리스 단위를 구성한다.
   스몰팩 단위의 업데이트 주기가 해마다 변동할 수 있다. 해마다(필요할 때)
   릴리스 결합 방식을 바꿀 수 있다. **코드를 수정하지 않는다는 것이 핵심**이다.」

  ⇒ 「무엇을 함께 묶을까」는 **데이터가 정할 일이지 코드가 정할 일이 아니다.**
    `sys_pack_plan` 한 표가 그 답을 담고, 화면은 그 표를 고칠 뿐이다.

★★ **화면이 보여야 하는 셋**(2026-09-05 사용자 지시):
  ① 각 자산마다 **얼마나 자주 업데이트 되는지 숫자**   → `stat()['freq']`
  ② 어떤 자산들과의 **연결이 포함되어 있는지**          → `links_of()`
  ③ **용량이 얼마나 되는지**                            → `stat()['bytes']`

⚠⚠ **통계로 주기를 자동 배정하지 않는다**(사용자 지적 — 「최근 30일 데이터에
  근거한 것이라면 부적절할 수 있다」). 실측 — 감사 로그가 2026-07-30~ 뿐이고
  그 기간은 **콘텐츠를 몰아 만든 기간**이라 정상 운영과 다르다.
  ⇒ 통계는 **권하고**(`advice`) 사람이 정한다. 배포는 되돌릴 수 없다.

⚠ **스몰팩을 새로 쪼개지 않는다** — 이미 조각이다:
  · 코어 표 하나 = 스몰팩 하나(`T:<표이름>`)
  · 본문 자산 하나 = 스몰팩 하나(`A:<갈래>:<열쇠>:<언어>:<변형>`)
  `db_pack_catalog.TABLES` 와 `sys_pack_item` 이 그 목록의 단일 소스다.

⚠ **주기 셋뿐**(사용자 확정 — 「현실적으로 매일, 주간, 연 2회 정도의 배포
  주기가 실현 가능성이 가장 높다」). 늘리려면 `CYCLES` 한 줄.

    python db_pack_stat.py --selftest        (의무)
    python db_pack_stat.py --units           스몰팩 목록
    python db_pack_stat.py --stat            빈도·용량·연결
    python db_pack_stat.py --bundles         주기별 묶음 요약
    python db_pack_stat.py --advice          권고(바꾸지는 않는다)
    python db_pack_stat.py --seed            지금 동작 그대로 초기값
    python db_pack_stat.py --set T:sys_link_asset DAILY --why "매일 는다"
"""
import io
import os
import sys
import time

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

import appdb                                                    # noqa: E402

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')

#: 배포 주기 — `(코드, 이름, 설명, 하루로 환산한 간격)`
#: ⚠ 늘리려면 **여기 한 줄**. 화면·룰엔진이 이 표를 읽는다.
CYCLES = (
    ('DAILY',    '매일',   '매일 한 번',      1),
    ('WEEKLY',   '주간',   '이레에 한 번',    7),
    ('BIANNUAL', '연 2회', '반년에 한 번',  182),
)
CYCLE_CODES = tuple(c for c, _n, _d, _i in CYCLES)
DEFAULT_CYCLE = 'BIANNUAL'

#: 처음부터 **매일** 묶음에 넣을 코어 표 — 지금은 **없다**.
#: ★★★ 2026-09-29 293차 — 매일 나가던 둘(영상 주소·영상 연결)은 **영상 연결
#:   팩**(`db_linkpack_build` · 갈래 `LINK`)이 제 길로 나른다. 영상 주소는
#:   코어 표가 아니고, `sys_link_asset` 은 코어에 남되 영상 연결(`MEDI_*`)이
#:   조건으로 빠지므로 코어 표 가운데 날마다 바뀌는 것이 없다.
#: ⚠ 옛 값 `('sys_media_asset','sys_link_asset')` 으로 되돌리면 두 경로가
#:   같은 행을 나른다 — selftest 가 잰다.
SEED_DAILY = ()

_SZ_CACHE = {}


# ── 표 ──────────────────────────────────────────────────────────────
def ensure(conn):
    """`sys_pack_plan` + 크기 캐시를 마련한다(멱등)."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sys_pack_plan (
            unit_code   TEXT PRIMARY KEY,
            cycle       TEXT NOT NULL,
            changed_at  TEXT,
            why         TEXT
        )""")
    # ★★ 크기 캐시 — **plan 과 따로 둔다**. plan 은 사람이 정한 것이고 이것은
    #   기계가 잰 것이라 성격이 다르다. 한 표에 섞으면 `seed` 가 지운다.
    #   ⚠ 실측 — 자산 190개를 다 재면 **15초**라 화면에 못 쓴다.
    #   ⚠ **잰 날짜를 함께 보인다** — 낡은 값을 지금 값인 척하면 거짓말이다.
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sys_pack_size (
            unit_code   TEXT PRIMARY KEY,
            n_bytes     INTEGER,
            n_rows      INTEGER,
            measured_at TEXT
        )""")
    conn.commit()
    return True


def size_cache(conn):
    """`{code: (바이트, 행, 잰 날)}`."""
    out = {}
    try:
        for c, b, n, at in conn.execute(
                "SELECT unit_code, n_bytes, n_rows, measured_at"
                "  FROM sys_pack_size"):
            out[str(c)] = (int(b or 0), int(n or 0), str(at or ''))
    except Exception:
        pass
    return out


def size_save(conn, code, b, n):
    conn.execute(
        "INSERT INTO sys_pack_size(unit_code,n_bytes,n_rows,measured_at)"
        " VALUES(?,?,?,?) ON CONFLICT(unit_code) DO UPDATE SET"
        "  n_bytes=excluded.n_bytes, n_rows=excluded.n_rows,"
        "  measured_at=excluded.measured_at",
        (code, int(b), int(n), time.strftime('%Y-%m-%d %H:%M')))


# ── 스몰팩 목록 ─────────────────────────────────────────────────────
def _core_tables():
    try:
        import db_pack_catalog as CAT
        return [(t, d) for t, (l, _k, d) in CAT.TABLES.items() if l == 'CORE']
    except Exception:
        return []


def units(conn, with_assets=True):
    """스몰팩 목록 → `[{code, kind, label, tables, note}]`.

    ★ **손으로 적지 않는다** — 카탈로그와 `sys_pack_item` 에서 유도한다.
      표나 자산이 늘면 저절로 는다.
    """
    out = []
    for t, d in sorted(_core_tables()):
        out.append({'code': 'T:' + t, 'kind': 'TABLE', 'label': t,
                    'tables': [t], 'note': d or ''})
    if not with_assets:
        return out
    try:
        rows = conn.execute(
            "SELECT kind, key, lang, variant, COALESCE(title,''),"
            "       COALESCE(version,0)"
            "  FROM sys_pack_item"
            " WHERE COALESCE(record_status,'LIVE')='LIVE'"
            "   AND UPPER(kind)<>'CORE'"
            " ORDER BY kind, key, lang, variant").fetchall()
    except Exception:
        rows = []
    for k, key, lg, vr, title, ver in rows:
        code = 'A:%s:%s:%s:%s' % (k, key, lg, vr)
        out.append({'code': code, 'kind': 'ASSET', 'label': title or key,
                    'tables': [], 'note': '%s · %s' % (k, lg),
                    'asset': (k, key, lg, vr), 'version': int(ver or 0)})
    return out


def unit_of(code):
    """`T:표` · `A:갈래:열쇠:언어:변형` → `('TABLE', 표)` / `('ASSET', 넷)`."""
    s = str(code or '')
    if s.startswith('T:'):
        return 'TABLE', s[2:]
    if s.startswith('A:'):
        p = s[2:].split(':')
        while len(p) < 4:
            p.append('-')
        return 'ASSET', tuple(p[:4])
    return '', None


# ── ① 얼마나 자주 바뀌나 ────────────────────────────────────────────
def freq_table(conn, table, days=30):
    """그 표의 최근 변경 횟수 → int. 감사 로그가 없으면 0."""
    try:
        return int(conn.execute(
            "SELECT COUNT(*) FROM sys_audit_log"
            " WHERE tbl=? AND ts>=date('now',?)",
            (table, '-%d day' % int(days))).fetchone()[0])
    except Exception:
        return 0


def log_span(conn):
    """감사 로그가 덮는 기간 → `(처음, 끝, 건수)`.

    ⚠ **이 기간을 화면이 반드시 함께 보인다** — 며칠치인지 모르고 숫자만
      보면 잘못 판단한다(사용자 지적).
    """
    try:
        r = conn.execute(
            "SELECT MIN(SUBSTR(ts,1,10)), MAX(SUBSTR(ts,1,10)), COUNT(*)"
            "  FROM sys_audit_log").fetchone()
        return (r[0] or ''), (r[1] or ''), int(r[2] or 0)
    except Exception:
        return '', '', 0


# ── ③ 용량 ──────────────────────────────────────────────────────────
def size_table(conn, table, cache=True):
    """그 표의 대략 크기 → `(바이트, 행수)`.

    ⚠ SQLite 는 표 크기를 안 알려 준다 — 칸 길이를 더해 **어림**한다.
      배포물은 JSON+gzip 이라 실제로는 이보다 작다(비교용 값이다).
    """
    if cache and table in _SZ_CACHE:
        return _SZ_CACHE[table]
    try:
        cols = [r[1] for r in conn.execute('PRAGMA table_info(%s)' % table)]
        if not cols:
            r = (0, 0)
        else:
            e = '+'.join("LENGTH(COALESCE(CAST(%s AS TEXT),''))" % c
                         for c in cols)
            row = conn.execute('SELECT COALESCE(SUM(%s),0), COUNT(*) FROM %s'
                               % (e, table)).fetchone()
            r = (int(row[0] or 0), int(row[1] or 0))
    except Exception:
        r = (0, 0)
    if cache:
        _SZ_CACHE[table] = r
    return r


def size_asset(conn, kind, key, lang, variant):
    """본문 자산 하나의 크기 → `(바이트, 행수)`.

    ★ **`db_pack_body` 가 담을 것을 그대로 센다** — 여기서 SQL 을 또 쓰면
      「팩에 든 것」과 「화면이 보이는 것」이 갈린다.
    ⚠⚠ **예외를 조용히 삼키지 않는다** — 첫 판이 `parts_for` 시그니처를
      잘못 불러 **자산 190개가 전부 0MB 로 나왔다**(실측으로 잡았다).
      0 은 「작다」로 읽혀 릴리스를 잘못 짜게 만든다. 못 재면 `-1` 을 낸다.
    """
    import db_pack_body as PB
    n = 0
    b = 0
    for tab, sql, argf in PB.parts_for(kind, key):
        try:
            args = argf(key, lang, variant) if callable(argf) else (argf or [])
            for row in conn.execute(sql, list(args)):
                n += 1
                b += sum(len(str(x)) for x in row if x is not None)
        except Exception:                                     # noqa: BLE001
            return -1, -1                  # 못 잰다 — 화면이 그렇게 말한다
    return b, n


# ── ② 어떤 자산들과의 연결이 포함되어 있는지 ────────────────────────
def _ref_pairs():
    """연결 짝 표 — **`db_integrity._REF` 가 단일 소스**.

    ⚠ 여기서 다시 적지 않는다 — 두 벌이면 한쪽만 고쳐진다.
    """
    try:
        import db_integrity as IG
        return list(IG._REF)                              # noqa: SLF001
    except Exception:
        return []


#: **연결을 담는 표** — `(표, 왼쪽 표, 오른쪽 표)`.
#: ⚠⚠ `sys_link_asset` 은 `_REF` 의 양끝 어디에도 안 나온다(그것은 연결을
#:   **담는 그릇**이다). 그래서 첫 판이 **가장 중요한 스몰팩의 연결을 0 으로**
#:   냈다(실측으로 잡았다). ⇒ 그릇은 그릇대로 센다.
#: ⚠ 늘리면 **여기 한 줄** — selftest 가 「빠진 것 0」을 잰다.
LINK_HOLDERS = {
    'sys_link_asset':       (None, None),          # 특례 — `_REF` 전부
    'sys_entity_verse':     ('sys_entity_master', 'bible_index'),
    'sys_entity_pericope':  ('sys_entity_master', 'sys_pericope_asset'),
    'sys_ref_verse_link':   ('sys_ref_unit', 'bible_index'),
    'sys_ref_entity_link':  ('sys_ref_unit', 'sys_entity_master'),
    'sys_person_relation':  ('sys_person', 'sys_person'),
    'sys_media_link':       ('sys_media_asset', None),
    'sys_book_unit_tag':    ('sys_book_unit', 'sys_tag_asset'),
    'sys_idol_person_relation': ('sys_entity_master', 'sys_person'),
    'sys_ref_verse_map':    ('sys_ref_site', 'bible_index'),
    'versification_map':    (None, 'bible_index'),
    # ⚠ 아래 일곱은 **selftest 가 잡아서** 채운 것이다(2026-09-05) — 손으로
    #   적어 두면 반드시 빠진다는 증거다. 검사를 지우지 말 것.
    'sys_book_asset_tag':   ('sys_book_asset', 'sys_tag_asset'),
    'sys_book_unit_entity': ('sys_book_unit', 'sys_entity_master'),
    'sys_book_unit_verse':  ('sys_book_unit', 'bible_index'),
    'sys_ref_asset_link':   ('sys_ref_asset', None),
    'sys_ref_book_link':    ('sys_ref_unit', 'sys_book_unit'),
    'sys_ref_entity_url':   ('sys_entity_master', 'sys_ref_site'),
    'sys_unit_tag_link':    ('sys_unit_asset', 'sys_tag_asset'),
    # ⚠ 2026-09-05 시작화면 장면 — selftest 가 또 잡았다(세 번째다).
    'sys_scene_map':        (None, 'bible_index'),
}


def _rows_of(conn, table):
    try:
        return int(conn.execute('SELECT COUNT(*) FROM %s' % table)
                   .fetchone()[0])
    except Exception:
        return 0


def link_counts(conn):
    """`link_type` 별 살아 있는 연결 수 → dict."""
    out = {}
    try:
        for lt, n in conn.execute(
                "SELECT link_type, COUNT(*) FROM sys_link_asset"
                " WHERE COALESCE(record_status,'LIVE')='LIVE'"
                " GROUP BY link_type"):
            out[str(lt)] = int(n)
    except Exception:
        pass
    return out


def _asset_shell_tables(kind):
    """그 갈래의 **껍데기 표** — 연결이 실제로 가리키는 자리."""
    return {
        'BOOK':   ('sys_book_asset', 'sys_book_unit'),
        'SERMON': ('sys_book_asset', 'sys_book_unit'),
        'BIBLE':  ('bible_index',),
        'DESC':   ('bible_index',),
        'COMM':   ('sys_commentary_source', 'sys_commentary_entry'),
        'DICT':   ('sys_ref_asset', 'sys_ref_unit'),
        'LEX':    ('sys_entity_master',),
    }.get(str(kind or '').upper(), ())


def links_of(conn, code, counts=None):
    """그 스몰팩이 **낀 연결** → `[{type, dir, other, rows, other_unit}]`.

    ★★★ **사용자 지시 ②의 답이다** — 「어떤 자산들과의 연결이 포함되어
      있는지 표시」. 릴리스를 짤 때 **상대가 같은 릴리스에 있나**를 이것으로 본다.

    · `dir='→'` 이 표가 상대를 가리킨다  · `dir='←'` 상대가 이 표를 가리킨다
    ⚠ 자산 스몰팩은 **본문만** 담고 껍데기·연결은 코어에 있다 — 그래서
      자산의 연결은 「껍데기 표에 붙은 연결」로 센다. 그것이 곧 **코어 의존**이다.
    """
    cnt = counts if counts is not None else link_counts(conn)
    kind, val = unit_of(code)
    if kind == 'TABLE':
        mine = {val}
    elif kind == 'ASSET':
        mine = set(_asset_shell_tables(val[0]))
    else:
        return []
    out = []

    # ── ⓐ 이 표가 **연결을 담는 그릇**이면 그 안의 연결을 전부 낸다 ────
    for tab in sorted(mine & set(LINK_HOLDERS)):
        if tab == 'sys_link_asset':
            for lt, ltab, _lp, rtab, _rp in _ref_pairs():
                n = cnt.get(lt, 0)
                if not n:
                    continue
                for other in (ltab, rtab):
                    out.append({'type': lt, 'dir': '∋', 'other': other,
                                'rows': n, 'other_unit': 'T:' + other})
            continue
        lt_, rt_ = LINK_HOLDERS[tab]
        n = _rows_of(conn, tab)
        if not n:
            continue
        for other in (lt_, rt_):
            if other:
                out.append({'type': tab, 'dir': '∋', 'other': other,
                            'rows': n, 'other_unit': 'T:' + other})

    # ── ⓑ `sys_link_asset` 이 이 표를 가리키는(가리켜지는) 연결 ────────
    for lt, ltab, _lpk, rtab, _rpk in _ref_pairs():
        n = cnt.get(lt, 0)
        if not n:
            continue
        if ltab in mine:
            out.append({'type': lt, 'dir': '→', 'other': rtab, 'rows': n,
                        'other_unit': 'T:' + rtab})
        if rtab in mine and rtab != ltab:
            out.append({'type': lt, 'dir': '←', 'other': ltab, 'rows': n,
                        'other_unit': 'T:' + ltab})
    # ⚠ 같은 줄이 두 번 나올 수 있다(양끝이 같은 표인 `ENTI_ENTI` 등)
    seen = set()
    uniq = []
    for x in out:
        k = (x['type'], x['dir'], x['other'])
        if k in seen:
            continue
        seen.add(k)
        uniq.append(x)
    uniq.sort(key=lambda x: -x['rows'])
    return uniq


# ── 주기 ────────────────────────────────────────────────────────────
def cycle_of(conn, code):
    """그 스몰팩의 주기 → 코드. 안 정했으면 기본값."""
    try:
        r = conn.execute("SELECT cycle FROM sys_pack_plan WHERE unit_code=?",
                         (code,)).fetchone()
        if r and str(r[0]) in CYCLE_CODES:
            return str(r[0])
    except Exception:
        pass
    return DEFAULT_CYCLE


def cycles(conn):
    """전부 한 번에 → `{code: cycle}`(안 정한 것은 안 담는다)."""
    out = {}
    try:
        for c, cy in conn.execute("SELECT unit_code, cycle FROM sys_pack_plan"):
            out[str(c)] = str(cy)
    except Exception:
        pass
    return out


def set_cycle(conn, code, cycle, why=''):
    """주기를 정한다(멱등). **여기가 릴리스 결합을 바꾸는 유일한 자리**."""
    cy = str(cycle or '').upper()
    if cy not in CYCLE_CODES:
        raise ValueError('모르는 주기: %s' % cycle)
    ensure(conn)
    conn.execute(
        "INSERT INTO sys_pack_plan(unit_code,cycle,changed_at,why)"
        " VALUES(?,?,?,?)"
        " ON CONFLICT(unit_code) DO UPDATE SET cycle=excluded.cycle,"
        "   changed_at=excluded.changed_at, why=excluded.why",
        (code, cy, time.strftime('%Y-%m-%d %H:%M'), str(why or '')))
    conn.commit()
    return cy


def seed(conn, force=False):
    """초기값 — **지금 동작 그대로**.

    ⚠ 통계로 정하지 않는다. `db_linkpack_build` 가 지금 매일 나르는 표만
      `DAILY`, 나머지는 `BIANNUAL`. 그래야 「바꾸기 전과 같다」가 보장된다.
    ⚠ **이미 정해 둔 것은 안 건드린다**(`force` 아니면).
    """
    ensure(conn)
    have = cycles(conn)
    n = 0
    for u in units(conn):
        c = u['code']
        if c in have and not force:
            continue
        kind, val = unit_of(c)
        cy = DEFAULT_CYCLE
        if kind == 'TABLE' and val in SEED_DAILY:
            cy = 'DAILY'
        set_cycle(conn, c, cy, '초기값(지금 동작 그대로)')
        n += 1
    return n


# ── 한 번에 재기 ────────────────────────────────────────────────────
def stat(conn, days=30, with_assets=True, with_links=True, on_step=None,
         refresh=False):
    """스몰팩마다 **빈도·용량·연결** → 목록.

    ★ 화면이 부르는 한 문. 여기서 다 재고 화면은 그리기만 한다.
    ⚠ 자산 크기는 **캐시**를 쓴다(다 재면 15초). `refresh=True` 면 다시 잰다.
      `measured` 칸에 잰 날이 들어가고 화면이 그것을 보인다.
    """
    cnt = link_counts(conn) if with_links else {}
    cy = cycles(conn)
    cache = size_cache(conn)
    rows = []
    dirty = False
    us = units(conn, with_assets=with_assets)
    for i, u in enumerate(us):
        if on_step:
            on_step(i + 1, len(us), u['label'])
        kind, val = unit_of(u['code'])
        at = ''
        if kind == 'TABLE':
            b, n = size_table(conn, val)
            f = freq_table(conn, val, days)
            at = 'now'
        else:
            f = 0                      # 자산은 판 번호가 곧 변경 이력이다
            hit = cache.get(u['code'])
            if hit and not refresh:
                b, n, at = hit
            else:
                b, n = size_asset(conn, *val)
                at = 'now'
                if b >= 0:
                    size_save(conn, u['code'], b, n)
                    dirty = True
        lk = links_of(conn, u['code'], cnt) if with_links else []
        rows.append(dict(u, bytes=b, rows=n, freq=f, measured=at,
                         cycle=cy.get(u['code'], DEFAULT_CYCLE),
                         links=lk,
                         link_rows=sum(x['rows'] for x in lk)))
    if dirty:
        conn.commit()
    return rows


def bundles(conn, days=30, rows=None):
    """주기별 묶음 요약 → `[{cycle, name, units, bytes, freq}]`.

    ★★ **릴리스가 실제로 어떤 모양이 되는지**를 이것으로 본다.
    """
    rs = rows if rows is not None else stat(conn, days)
    out = []
    for c, name, desc, _iv in CYCLES:
        mine = [r for r in rs if r['cycle'] == c]
        out.append({'cycle': c, 'name': name, 'desc': desc,
                    'units': len(mine),
                    'bytes': sum(r['bytes'] for r in mine),
                    'rows': sum(r['rows'] for r in mine),
                    'freq': sum(r['freq'] for r in mine)})
    return out


# ── 권고 — 바꾸지는 않는다 ──────────────────────────────────────────
def advice(conn, days=30, rows=None, hot=100, cold=0):
    """빈도와 주기가 어긋나는 것 → `[{code, label, now, want, why}]`.

    ⚠⚠ **자동으로 안 바꾼다**(사용자 지적 — 통계 기간이 편향될 수 있다).
      화면이 이 목록을 보이고 **사람이 누른다**.
    """
    rs = rows if rows is not None else stat(conn, days, with_links=False)
    out = []
    for r in rs:
        if r['kind'] != 'TABLE':
            continue
        f, cy = r['freq'], r['cycle']
        if f >= hot and cy == 'BIANNUAL':
            out.append({'code': r['code'], 'label': r['label'], 'now': cy,
                        'want': 'DAILY',
                        'why': '최근 %d일 %s번 바뀌었는데 연 2회 묶음에 있다'
                               % (days, format(f, ','))})
        elif f <= cold and cy == 'DAILY':
            out.append({'code': r['code'], 'label': r['label'], 'now': cy,
                        'want': 'BIANNUAL',
                        'why': '최근 %d일 한 번도 안 바뀌었는데 매일 나간다'
                               % days})
    return out


def overlap(conn, rows=None):
    """**한 스몰팩이 두 묶음에 실리나** → 겹치는 코드 목록(있으면 안 된다).

    ★★★ 사용자 물음(2026-09-05 「매일/매주/연간 주기가 겹칠 때 한 파일로
      릴리스하는가 따로 해야 하는가」)의 **첫 절반**이다.
      답 = **겹칠 수 없다.** `sys_pack_plan` 의 PK 가 `unit_code` 라
      스몰팩 하나는 주기 하나에만 속한다. 그러므로 어떤 표의 변경도
      **두 파일에 동시에 실리지 않는다** — 그것이 이 설계의 안전장치다.
    ⚠ 이 함수가 0 이 아니면 표가 깨진 것이다(selftest 가 잰다).
    """
    rs = rows if rows is not None else stat(conn, with_links=False)
    seen = {}
    dup = []
    for r in rs:
        c = r['code']
        if c in seen and seen[c] != r['cycle']:
            dup.append(c)
        seen[c] = r['cycle']
    return dup


def due(conn, days_since=0, rows=None):
    """그날 **실제로 나가는 묶음** → `[{cycle, name, units, bytes}]`.

    ★★★ 사용자 물음의 **뒤 절반**이다 — 주기가 겹치는 날에는 **여러 파일이
      나란히** 나간다. 한 파일로 합치지 않는다:
        ⓐ 합치면 매일 받는 사람이 **주간 것을 매일 다시** 받는다
           (지금 코어팩이 겪는 바로 그 낭비다)
        ⓑ 한 덩이가 실패하면 **나머지도 못 받는다**
      ⇒ **파일은 따로 · 릴리스 번호는 하나 · 받는 것은 앱이 고른다.**
        사용자는 「9번을 받았다」로 알면 되고, 무엇이 몇 개인지는 manifest 가
        안다(`pack_status.needed()` 가 이미 그 일을 한다).
    ⚠ `days_since` = 기준일로부터 며칠 지났나. 주기의 배수인 것만 나간다.
    """
    rs = rows if rows is not None else stat(conn, with_links=False)
    n = max(0, int(days_since))
    out = []
    for c, name, desc, iv in CYCLES:
        if iv > 0 and (n % iv) != 0:
            continue
        mine = [r for r in rs if r['cycle'] == c]
        if not mine:
            continue
        out.append({'cycle': c, 'name': name, 'desc': desc,
                    'units': len(mine),
                    'bytes': sum(r['bytes'] for r in mine if r['bytes'] > 0)})
    return out


def apply_order(cycles_list=None):
    """받는 쪽 **적재 순서** → 느린 것부터.

    ★★★ **껍데기가 먼저, 연결이 나중이다.** 연결이 껍데기를 가리키므로
      거꾸로 넣으면 그 순간 가리킬 것이 없는 연결이 생긴다.
      느린 주기에 구조(껍데기·좌표)가, 빠른 주기에 연결이 있는 것이 보통이라
      **간격이 긴 것부터** 넣으면 저절로 맞는다.
    ⚠ 한 파일에 다 넣으면 이 순서를 정할 자리가 없다 — 그것도 파일을 가르는 이유다.
    """
    iv = {c: i for c, _n, _d, i in CYCLES}
    src = list(cycles_list) if cycles_list else [c for c, _n, _d, _i in CYCLES]
    return sorted(src, key=lambda c: -iv.get(c, 0))


def cross_cycle(conn, rows=None):
    """**주기를 넘는 연결** → `[{code, other, type, rows, mine, theirs}]`.

    ★★★ 이것이 위험한 자리다 — A 는 매일 나가는데 A 가 가리키는 B 가 연 2회
      묶음에 있으면, **B 가 아직 안 온 사용자에게 A 의 연결이 미아**가 된다.
      룰엔진이 이것을 배포 직전에 잡는다.
    ⚠ 그렇다고 **금지가 아니다** — 폴백이 말해 주면 되는 경우도 있다.
      화면이 보이고 사람이 판단한다.
    """
    rs = rows if rows is not None else stat(conn)
    cy = {r['code']: r['cycle'] for r in rs}
    iv = {c: i for c, _n, _d, i in CYCLES}
    out = []
    for r in rs:
        mine = r['cycle']
        for lk in r.get('links') or []:
            theirs = cy.get(lk['other_unit'], DEFAULT_CYCLE)
            if theirs == mine:
                continue
            # 내가 더 자주 나가는데 상대가 느리면 → 미아 위험
            if iv.get(mine, 999) < iv.get(theirs, 999):
                out.append({'code': r['code'], 'label': r['label'],
                            'other': lk['other'], 'type': lk['type'],
                            'rows': lk['rows'], 'mine': mine,
                            'theirs': theirs})
    out.sort(key=lambda x: -x['rows'])
    return out


# ── selftest ────────────────────────────────────────────────────────
def selftest():
    import sqlite3
    ok = fail = 0

    def t(n, c, e=''):
        nonlocal ok, fail
        if c:
            ok += 1
            print('  OK   %-52s %s' % (n, e))
        else:
            fail += 1
            print('  FAIL %-52s %s' % (n, e))

    print('=== db_pack_stat selftest')
    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE sys_pack_item(kind TEXT,key TEXT,lang TEXT,"
              "variant TEXT,title TEXT,version INTEGER,record_status TEXT)")
    c.execute("INSERT INTO sys_pack_item VALUES('BOOK','X','KO','-',"
              "'책 하나',3,'LIVE')")
    c.execute("CREATE TABLE sys_audit_log(ts TEXT,tbl TEXT)")
    c.execute("CREATE TABLE sys_link_asset(link_type TEXT,record_status TEXT)")
    for _ in range(5):
        c.execute("INSERT INTO sys_link_asset VALUES('ENTI_VERS','LIVE')")
    c.execute("INSERT INTO sys_link_asset VALUES('MEDI_ENTI','LIVE')")
    c.execute("INSERT INTO sys_link_asset VALUES('ENTI_VERS','HIDE')")
    c.execute("CREATE TABLE bible_index(verse_id INTEGER, t TEXT)")
    c.execute("INSERT INTO bible_index VALUES(1,'가나다')")
    for d in ('now', '-2 day', '-40 day'):
        c.execute("INSERT INTO sys_audit_log VALUES(date('now',?),"
                  "'sys_link_asset')", (d if d != 'now' else '0 day',))
    c.commit()

    # ① 표
    t('★ 표를 만든다(멱등)', ensure(c) and ensure(c))

    # ② 스몰팩 목록
    us = units(c)
    codes = [u['code'] for u in us]
    t('★★ 코어 표가 스몰팩으로 나온다', 'T:sys_link_asset' in codes,
      '%d개' % len(us))
    t('★★ 자산도 스몰팩으로 나온다', 'A:BOOK:X:KO:-' in codes)
    t('  손으로 안 적는다(카탈로그에서 유도)',
      len([u for u in us if u['kind'] == 'TABLE']) > 50)
    t('  자산을 빼고도 낼 수 있다',
      'A:BOOK:X:KO:-' not in [u['code'] for u in units(c, with_assets=False)])

    # ③ 열쇠 왕복
    t('★ T: 왕복', unit_of('T:sys_link_asset') == ('TABLE', 'sys_link_asset'))
    t('★ A: 왕복', unit_of('A:BOOK:X:KO:-') == ('ASSET', ('BOOK', 'X', 'KO', '-')))
    t('  모르는 꼴은 빈손', unit_of('ZZZ') == ('', None))

    # ④ 빈도 — ①
    f30 = freq_table(c, 'sys_link_asset', 30)
    f365 = freq_table(c, 'sys_link_asset', 365)
    t('★★★ ① **얼마나 자주 바뀌나를 센다**', f30 == 2 and f365 == 3,
      '30일 %d · 365일 %d' % (f30, f365))
    t('  없는 표는 0', freq_table(c, 'nope', 30) == 0)
    lo, hi, n = log_span(c)
    t('★★ **로그 기간을 함께 낸다**(며칠치인지 모르면 잘못 읽는다)',
      bool(lo) and n == 3, '%s~%s %d건' % (lo, hi, n))

    # ⑤ 용량 — ③
    b, rows_n = size_table(c, 'bible_index')
    t('★★★ ③ **용량을 센다**', b > 0 and rows_n == 1, '%d바이트 %d행' % (b, rows_n))
    t('  없는 표는 0', size_table(c, 'nope') == (0, 0))
    t('★★★ **못 재면 0 이 아니라 −1**(0 은 「작다」로 읽혀 릴리스를 그르친다)',
      size_asset(c, 'BOOK', 'X', 'KO', '-') == (-1, -1),
      '%s' % str(size_asset(c, 'BOOK', 'X', 'KO', '-')))

    # ⑥ 연결 — ②
    cnt = link_counts(c)
    t('★ 살아 있는 것만 센다', cnt.get('ENTI_VERS') == 5, str(cnt))
    lk = links_of(c, 'T:sys_entity_master')
    types = {x['type'] for x in lk}
    t('★★★ ② **어떤 연결이 포함되는지 낸다**',
      'ENTI_VERS' in types and 'MEDI_ENTI' in types, str(sorted(types)))
    dirs = {(x['type'], x['dir']) for x in lk}
    t('★★ **방향을 가른다**(내가 가리킨다 ↔ 나를 가리킨다)',
      ('ENTI_VERS', '→') in dirs and ('MEDI_ENTI', '←') in dirs)
    t('★★ **상대가 어느 스몰팩인지 말한다**(릴리스 짤 때 이것을 본다)',
      all(x['other_unit'].startswith('T:') for x in lk))
    t('  건수 0 인 연결은 안 낸다',
      all(x['rows'] > 0 for x in links_of(c, 'T:bible_index')))
    t('★ **짝 표를 여기서 다시 적지 않는다**(db_integrity 단일 소스)',
      len(_ref_pairs()) >= 10, '%d짝' % len(_ref_pairs()))
    la = links_of(c, 'A:BOOK:X:KO:-')
    t('★★ 자산의 연결 = **껍데기에 붙은 것**(곧 코어 의존)',
      isinstance(la, list))

    # ⑥-b **연결을 담는 그릇** — 첫 판이 여기서 0 을 냈다
    hold = links_of(c, 'T:sys_link_asset')
    t('★★★ **그릇의 연결을 0 으로 내지 않는다**(실측으로 잡은 결함)',
      len(hold) > 0 and all(x['dir'] == '∋' for x in hold),
      '%d줄' % len(hold))
    t('★★ **양끝을 다 낸다**(어느 표가 있어야 살아나나)',
      {x['other'] for x in hold} >= {'sys_entity_master', 'bible_index'})
    t('  같은 줄을 두 번 안 낸다',
      len({(x['type'], x['dir'], x['other']) for x in hold}) == len(hold))
    try:
        import db_pack_catalog as _C
        # ⚠ **코어 표만** — `sys_verse_lemma`(PACK·LEX)처럼 팩으로 나가는 표는
        #   스몰팩 단위가 아니라 여기 목록에 있을 까닭이 없다(2026-09-29 정정 —
        #   그 표가 PACK 으로 옮겨진 뒤 이 검사가 계속 빨갰다).
        holder_like = {t_ for t_, (_l, _k, d) in _C.TABLES.items()
                       if '↔' in (d or '') and _l == 'CORE'}
        miss = sorted(holder_like - set(LINK_HOLDERS))
    except Exception:
        miss = []
    t('★★★ **연결을 담는 표가 목록에서 빠지지 않는다**(표가 늘면 여기서 잡힌다)',
      not miss, '빠진 것: %s' % (', '.join(miss) if miss else '0'))

    # ⑦ 주기
    t('  안 정하면 기본값', cycle_of(c, 'T:bible_index') == DEFAULT_CYCLE)
    set_cycle(c, 'T:sys_link_asset', 'DAILY', '매일 는다')
    t('★★★ **주기를 고치는 자리는 여기 하나**',
      cycle_of(c, 'T:sys_link_asset') == 'DAILY')
    set_cycle(c, 'T:sys_link_asset', 'WEEKLY')
    t('  다시 고쳐도 한 행', c.execute(
        "SELECT COUNT(*) FROM sys_pack_plan WHERE unit_code=?",
        ('T:sys_link_asset',)).fetchone()[0] == 1)
    bad = False
    try:
        set_cycle(c, 'T:x', 'MONTHLY')
    except ValueError:
        bad = True
    t('★★ **모르는 주기는 거부한다**(조용히 기본값으로 두지 않는다)', bad)
    r = c.execute("SELECT why, changed_at FROM sys_pack_plan"
                  " WHERE unit_code='T:sys_link_asset'").fetchone()
    t('  왜 바꿨는지·언제인지 남는다', r[1], str(r[1]))

    # ⑧ seed — 지금 동작 그대로
    set_cycle(c, 'T:sys_link_asset', 'WEEKLY', '사람이 정함')
    n1 = seed(c)
    # ★★★ 2026-09-29 — 영상 주소·연결은 영상 연결 팩이 나르므로 **씨앗이 매일
    #   묶음에 아무것도 안 넣는다**. 옛 검사(「sys_media_asset 이 DAILY」)를
    #   뒤집어 못 박는다.
    t('★★★ **초기값은 통계가 아니라 지금 동작** — 매일 묶음이 비어 있다',
      n1 > 0 and not [u for u in units(c, with_assets=False)
                      if cycle_of(c, u['code']) == 'DAILY'
                      and u['code'] != 'T:sys_link_asset'],
      '%d개 배정' % n1)
    t('★★ 영상 주소는 코어 단위가 아니다',
      'T:sys_media_asset' not in [u['code'] for u in units(c, with_assets=False)])
    t('★★ **이미 정해 둔 것은 안 건드린다**',
      cycle_of(c, 'T:sys_link_asset') == 'WEEKLY')
    t('  안 실린 표는 연 2회', cycle_of(c, 'T:bible_index') == 'BIANNUAL')
    t('  두 번 돌려도 새로 배정할 것이 없다', seed(c) == 0)

    # ⑨ 묶음 요약
    rs = stat(c, 30)
    bs = bundles(c, rows=rs)
    t('★★ **주기별 묶음을 낸다**(릴리스가 어떤 모양이 되나)',
      len(bs) == len(CYCLES) and sum(b['units'] for b in bs) == len(rs),
      ' · '.join('%s %d개' % (b['name'], b['units']) for b in bs))
    t('  묶음마다 크기가 함께 나온다',
      all('bytes' in b for b in bs))
    one = [r for r in rs if r['code'] == 'T:sys_link_asset'][0]
    t('★★★ **한 문이 셋을 다 낸다**(빈도·용량·연결)',
      'freq' in one and 'bytes' in one and 'links' in one,
      '빈도 %d · %d바이트 · 연결 %d종'
      % (one['freq'], one['bytes'], len(one['links'])))

    # ⑨-b 크기 캐시
    size_save(c, 'A:BOOK:X:KO:-', 4321, 7)
    c.commit()
    rs_c = stat(c, 30)
    a1 = [r for r in rs_c if r['code'] == 'A:BOOK:X:KO:-'][0]
    t('★★ **자산 크기는 캐시를 쓴다**(다 재면 15초라 화면에 못 쓴다)',
      a1['bytes'] == 4321 and a1['rows'] == 7, '%d바이트' % a1['bytes'])
    t('★★ **잰 날을 함께 낸다**(낡은 값을 지금 값인 척하지 않는다)',
      bool(a1['measured']) and a1['measured'] != 'now', a1['measured'])
    a2 = [r for r in stat(c, 30, refresh=True)
          if r['code'] == 'A:BOOK:X:KO:-'][0]
    t('  다시 재기를 부르면 캐시를 안 쓴다', a2['bytes'] == -1)

    # ⑩ 권고 — 바꾸지는 않는다
    set_cycle(c, 'T:sys_link_asset', 'BIANNUAL', '일부러 느리게')
    for _ in range(200):
        c.execute("INSERT INTO sys_audit_log VALUES(date('now'),"
                  "'sys_link_asset')")
    c.commit()
    ad = advice(c, 30)
    hit = [a for a in ad if a['code'] == 'T:sys_link_asset']
    t('★★★ **어긋나면 권한다**', hit and hit[0]['want'] == 'DAILY',
      hit[0]['why'] if hit else '(없다)')
    t('★★★ **권하기만 하고 안 바꾼다**(배포는 되돌릴 수 없다)',
      cycle_of(c, 'T:sys_link_asset') == 'BIANNUAL')
    set_cycle(c, 'T:bible_index', 'DAILY', '일부러 빠르게')
    ad2 = advice(c, 30)
    t('★★ **반대도 권한다**(안 바뀌는데 매일 나간다)',
      any(a['code'] == 'T:bible_index' and a['want'] == 'BIANNUAL'
          for a in ad2))

    # ⑩-b 겹침 · 그날 나가는 것 · 적재 순서
    t('★★★ **한 스몰팩이 두 묶음에 실릴 수 없다**(PK 가 막는다)',
      overlap(c) == [], '겹침 %d' % len(overlap(c)))
    set_cycle(c, 'T:bible_index', 'BIANNUAL', '')
    set_cycle(c, 'T:sys_unit_asset', 'DAILY', '')
    set_cycle(c, 'T:sys_tag_asset', 'WEEKLY', '')
    d0 = due(c, 0)
    t('★★★ **겹치는 날에는 여러 파일이 나란히 나간다**(합치지 않는다)',
      len(d0) == 3, ' · '.join(x['name'] for x in d0))
    d1 = due(c, 1)
    t('★★ 하루 뒤에는 매일 것만',
      [x['cycle'] for x in d1] == ['DAILY'],
      ' · '.join(x['name'] for x in d1))
    d7 = due(c, 7)
    t('★★ 이레 뒤에는 매일 + 주간',
      [x['cycle'] for x in d7] == ['DAILY', 'WEEKLY'],
      ' · '.join(x['name'] for x in d7))
    t('  나갈 것이 없는 묶음은 안 낸다',
      all(x['units'] > 0 for x in due(c, 0)))
    t('★★★ **적재는 느린 것부터**(껍데기가 먼저, 연결이 나중)',
      apply_order() == ['BIANNUAL', 'WEEKLY', 'DAILY'], str(apply_order()))
    t('  선택한 것만 줘도 순서를 지킨다',
      apply_order(['DAILY', 'BIANNUAL']) == ['BIANNUAL', 'DAILY'])

    # ⑪ 주기를 넘는 연결
    set_cycle(c, 'T:sys_entity_master', 'DAILY', '')
    set_cycle(c, 'T:bible_index', 'BIANNUAL', '')
    xs = cross_cycle(c)
    hit2 = [x for x in xs if x['code'] == 'T:sys_entity_master'
            and x['other'] == 'bible_index']
    t('★★★ **주기를 넘는 연결을 잡는다**(미아가 될 자리)', bool(hit2),
      '%s → %s (%s→%s)' % (hit2[0]['code'], hit2[0]['other'],
                           hit2[0]['mine'], hit2[0]['theirs']) if hit2 else '')
    set_cycle(c, 'T:bible_index', 'DAILY', '')
    t('★★ **같은 주기면 안 잡는다**',
      not [x for x in cross_cycle(c) if x['code'] == 'T:sys_entity_master'
           and x['other'] == 'bible_index'])
    set_cycle(c, 'T:sys_entity_master', 'BIANNUAL', '')
    set_cycle(c, 'T:bible_index', 'DAILY', '')
    t('★★ **느린 것이 빠른 것을 가리키는 것은 안 잡는다**(폴백이 말한다)',
      not [x for x in cross_cycle(c) if x['code'] == 'T:sys_entity_master'
           and x['other'] == 'bible_index'])

    # ⑫ 실 DB 에 안 쓴다
    t('★ 시험이 실 DB 를 안 건드린다', True, '메모리 DB')
    c.close()
    print('  %d/%d' % (ok, ok + fail))
    return fail == 0


# ── CLI ─────────────────────────────────────────────────────────────
def _mb(b):
    return '%.2f MB' % (b / 1048576.0)


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    days = 30
    if '--days' in a:
        days = int(a[a.index('--days') + 1])
    c = appdb.connect(DB)
    ensure(c)
    if '--seed' in a:
        n = seed(c, force='--force' in a)
        print('초기값 배정 %d개' % n)
    elif '--set' in a:
        i = a.index('--set')
        code, cy = a[i + 1], a[i + 2]
        why = a[a.index('--why') + 1] if '--why' in a else ''
        print('%s → %s' % (code, set_cycle(c, code, cy, why)))
    elif '--units' in a:
        for u in units(c):
            print('  %-40s %-6s %s' % (u['code'], u['kind'], u['label']))
    elif '--advice' in a:
        lo, hi, n = log_span(c)
        print('감사 로그 %s ~ %s · %s건' % (lo, hi, format(n, ',')))
        print('⚠ 이 기간이 대표성이 있는지 사람이 판단한다.')
        for x in advice(c, days):
            print('  %-34s %s → %s   %s'
                  % (x['label'], x['now'], x['want'], x['why']))
    elif '--bundles' in a:
        rs = stat(c, days)
        for b in bundles(c, rows=rs):
            print('  %-8s %4d개  %10s  %8s행  최근 %d일 변경 %s'
                  % (b['name'], b['units'], _mb(b['bytes']),
                     format(b['rows'], ','), days, format(b['freq'], ',')))
        xs = cross_cycle(c, rs)
        print('  주기를 넘는 연결 %d종' % len(xs))
        for x in xs[:6]:
            print('    %-28s → %-24s %s행 (%s→%s)'
                  % (x['label'], x['other'], format(x['rows'], ','),
                     x['mine'], x['theirs']))
    else:
        rs = stat(c, days)
        rs.sort(key=lambda r: -r['freq'])
        print('  %-34s %6s %10s %9s %5s %s'
              % ('스몰팩', '변경', '용량', '행', '연결', '주기'))
        for r in rs[:26]:
            print('  %-34s %6s %10s %9s %5d %s'
                  % (r['label'][:34], format(r['freq'], ','), _mb(r['bytes']),
                     format(r['rows'], ','), len(r['links']), r['cycle']))
        print('  … 모두 %d개' % len(rs))
    c.close()


if __name__ == '__main__':
    main()
