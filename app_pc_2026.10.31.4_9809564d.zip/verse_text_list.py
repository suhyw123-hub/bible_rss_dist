# -*- coding: utf-8 -*-
"""P1 성경 본문 목록 — Listbox 처럼 쓰되 속은 Text (2026-08-12 사용자 지시).

왜 만들었나
    `tk.Listbox` 는 **한 항목 = 한 줄이고 `wrap` 옵션이 아예 없다.** 그래서 P1 폭이
    좁아지면 본문 뒷부분이 잘렸고 가로 스크롤바로 밀어 봐야 했다. 데이터나 로직
    문제가 아니라 위젯 선택의 구조적 한계다.

무엇을 했나
    `tk.Text(wrap='word')` 로 바꾸되 **밖에서 보이는 얼굴은 Listbox 그대로** 두었다.
    `insert`·`delete`·`selection_set`·`curselection`·`see`·`get`·`size`·`nearest`·
    `activate` 를 같은 이름·같은 뜻으로 제공하므로 부르는 쪽(user_main 30여 곳)이
    거의 그대로 산다. 클릭하면 `<<ListboxSelect>>` 를 직접 쏘아 기존 바인딩도 살린다.

읽는 맛 (사용자 요청 「책을 읽는 것 같은 자연스러운 느낌」)
    ⚠ **핵심은 `lmargin2` 다.** 절 번호 폭만큼 「이어지는 줄」을 들여쓰지 않으면
      wrap 된 둘째 줄이 번호 아래로 흘러내려 목록처럼 보인다.

        3  세월이 지난 후에 가인은 땅의 소산으로 제물을 삼아
           여호와께 드렸고            ← lmargin2 로 본문 시작선에 맞춘다

    절 번호와 본문 사이는 탭 스톱으로 벌린다(공백 문자로 맞추면 폰트가 바뀔 때 어긋난다).

⚠ 인덱스 규약 — Listbox 항목 i ↔ Text 논리 줄 i+1. 항목 하나를 넣을 때마다 개행을
  하나만 붙여 이 대응을 지킨다. wrap 은 **화면 줄**만 늘리고 논리 줄은 그대로다.
"""

import tkinter as tk
from tkinter import ttk

import theme_font
import bidi

# 절 번호 뒤 공백을 몇 칸으로 잡을까 (2026-08-12 사용자 지시).
#   「그 장에서 가장 긴 절 번호 자릿수 + 1~2 스페이스」
# 예전에는 자릿수와 무관하게 34~40px 로 고정이라 2자리 장에서 지나치게 벌어졌다.
# 실측(Times New Roman 12): 숫자 1자리 8px · 2자리 16 · 3자리 24 / 공백 4px
#   ⇒ 2자리 장이면 16 + 6 = 22px — 예전 40px 의 절반 남짓이다.
NUM_GAP_SPACES = 1.5
NUM_W_MIN = 14          # 1자리 장에서도 너무 붙지 않게

# PageUp/PageDown 한 번에 옮길 절 수.
# ⚠ 화면에 보이는 줄 수로 맞추고 싶지만 wrap 때문에 절마다 화면 줄 수가 달라
#   같은 키가 장마다 다르게 움직인다. 고정값이 예측 가능하다.
PAGE_STEP = 10

SEL_BG = '#D6EAF8'      # 선택된 절 바탕
SEL_FG = '#000000'      # 선택된 절 글자 — 아래 ⚠ 참조
TITLE_FG = '#7B5E2A'    # 페리코프 제목
NUM_FG = '#95A5A6'      # 절 번호 — 본문보다 흐리게 두어야 글이 먼저 읽힌다
# ★ 히브리 절 번호(병기) — 우리 번호보다 **한 단계 더** 흐리다.
#   같은 색이면 둘 중 무엇이 이 앱의 번호인지 알 수 없다(279차).
NUM2_FG = '#BDC3C7'

# ⚠ **`'sel'` 은 Tk 가 예약해 둔 내장 태그 이름이다** (2026-08-13 사용자 지적).
#   그 이름으로 `tag_configure(background=...)` 를 하면 바탕만 덮이고 글자색은
#   위젯의 `-selectforeground`(윈도우에서 `SystemHighlightText` = 흰색)가 남는다.
#   ⇒ 연한 하늘색 바탕에 흰 글자가 되어 **고른 절이 오히려 안 읽혔다.**
#   전용 이름을 쓰고 글자색을 명시한다. `'sel'` 은 Tk 에게 돌려준다
#   (마우스로 끌어 선택하는 것이 그 태그를 쓴다 — 뺏으면 그쪽이 깨진다).
SEL_TAG = 'vsel'

# ★ 오른쪽에서 왼쪽으로 읽는 줄 (2026-08-13 사용자 결정 ②안).
#   히브리 성경은 **절 번호도 줄이 시작하는 오른쪽 끝**에 온다.
#   ⚠ 아랍어도 같은 길로 처리된다 — 판정이 글자 기준이라 역본을 가리지 않는다.
#   ⚠ 지금은 성경 본문뿐이지만, 나중에 설명문·도서가 히브리어로 번역되면
#     같은 방식이 그쪽에도 필요하다(사용자 확인 2026-08-13).
RTL_TAG = 'vrtl'


class VerseTextList(tk.Frame):

    def __init__(self, parent, db_path=None, on_select=None, **kw):
        super().__init__(parent, **kw)
        self.db_path = db_path
        self._on_select = on_select

        self._vsb = ttk.Scrollbar(self, orient='vertical')
        self._vsb.pack(side='right', fill='y')
        # ⚠ 가로 스크롤바는 두지 않는다 — wrap 이 있으면 가로로 넘칠 일이 없다.
        self.text = tk.Text(self, wrap='word', bg='#FFFFFF', bd=0,
                            highlightthickness=0, cursor='arrow',
                            padx=10, pady=6,
                            # ⚠ 끌어서 선택을 살리느라 Text 의 기본 클릭 처리를 되돌려
                            #   놓았더니 **깜빡이는 삽입 커서**가 함께 살아났다.
                            #   글을 넣을 수 없는 화면에서 커서가 깜빡이면 오해를 준다.
                            insertwidth=0,
                            yscrollcommand=self._vsb.set)
        self._vsb.config(command=self.text.yview)
        self.text.pack(side='left', fill='both', expand=True)

        self._items = []        # [(kind, key)] — kind: 'verse' | 'title' | 'plain'
        self._sel = None        # 선택된 항목 index
        self._active = None     # activate() 로 지정된 index
        self._max_num = 0       # 그 장의 가장 큰 절 번호 → 번호 칸 폭을 정한다
        # ★ 그 장에서 **가장 넓은 번호 글자**(히브리 병기 포함).
        #   자릿수만 세면 「3·25:19-26:1」 같은 줄에서 본문이 번호를 덮는다.
        self._numlab = ''

        # ⚠ 제목은 **왼쪽 정렬**이고 본문 첫 글자와 같은 자리에서 시작한다
        #   (2026-08-13 사용자 지시). `lmargin` 은 번호 칸 폭이 정해진 뒤
        #   `apply_font()` 에서 함께 잡는다 — 장마다 자릿수가 달라 고정할 수 없다.
        self.text.tag_configure('title', foreground=TITLE_FG,
                                font=('Malgun Gothic', 10, 'bold'),
                                spacing1=10, spacing3=4, justify='left')
        self.text.tag_configure('num', foreground=NUM_FG)
        self.text.tag_configure('num2', foreground=NUM2_FG)
        self.text.tag_configure(SEL_TAG, background=SEL_BG, foreground=SEL_FG)
        self.text.tag_configure(RTL_TAG, justify='right')
        # 제목이 RTL 일 때 쓰는 짝 — 색·굵기만 주고 정렬은 RTL_TAG 에 맡긴다
        self.text.tag_configure('title_fg', foreground=TITLE_FG,
                                font=('Malgun Gothic', 10, 'bold'),
                                spacing1=10, spacing3=4)
        self.text.bind('<Button-1>', self._on_click)
        # 읽기 전용으로 만든다.
        # ⚠ 이 줄은 **Ctrl+C 까지 함께 막는다**(2026-08-13 실측 — 클립보드가 그대로다).
        #   원래 주석은 「선택·복사는 되게 둔다」고 적혀 있었으나 사실이 아니었다.
        #   마우스로 끌어 선택하는 것은 되고 그것을 복사하는 것만 안 된다.
        self.text.bind('<Key>', lambda e: 'break')
        # ★ 복사만 되돌려 준다 (2026-08-13 사용자 지시 「여러 구절 Ctrl+C 복사」).
        #   `None` 을 돌려주면 Text 클래스 바인딩의 복사가 이어서 돈다.
        for _c in ('<Control-c>', '<Control-C>', '<Control-Insert>'):
            self.text.bind(_c, lambda e: None)
        # ⚠ 위 `<Key>` 는 화살표까지 삼킨다. **더 구체적인 패턴이 이기므로**
        #   아래 바인딩이 그 자리를 대신 가져간다(Tk 는 일치하는 것 중 가장
        #   구체적인 하나만 실행한다). `<Key>` 를 지우면 본문에 타자가 들어간다.
        for _seq, _n in (('<Up>', -1), ('<Down>', 1),
                         ('<Prior>', -PAGE_STEP), ('<Next>', PAGE_STEP)):
            self.text.bind(_seq, lambda e, n=_n: self._step(n))
        self.text.bind('<Home>', lambda e: self._jump(last=False))
        self.text.bind('<End>', lambda e: self._jump(last=True))
        self.text.config(state='normal')

        self.apply_font()

    # ── 겉모습 ────────────────────────────────────────────────────────────
    def _num_width(self):
        """번호 칸 폭 = 그 장 최대 절 번호의 자릿수 + 공백 1.5칸.

        ⚠ 폰트와 자릿수 **둘 다**를 따라야 한다. 고정 px 로 두면 글자를 키웠을 때
          번호와 본문이 겹치고, 자릿수를 무시하면 2자리 장이 3자리 장만큼 벌어진다.
        """
        try:
            import tkinter.font as tkfont
            f = tkfont.Font(font=self.text.cget('font'))
            digits = len(str(self._max_num)) if self._max_num else 2
            wide = self._numlab or ('0' * digits)
            # ⚠ 자릿수가 아니라 **글자 그대로** 잰다 — 히브리 번호를 병기하면
            #   「3·2」처럼 길어지고, 장을 넘는 자리는 훨씬 길다.
            return max(NUM_W_MIN,
                       f.measure(wide) + int(f.measure(' ') * NUM_GAP_SPACES))
        except Exception:
            return NUM_W_MIN * 2

    def apply_font(self, d=None):
        """읽기 설정을 반영하고 탭·들여쓰기를 그 폰트에 맞춘다.

        `d` 를 주면 **DB 를 읽지 않고 그 값으로** 그린다 — 읽기 설정 팝업이
        저장 전에 미리 보여 줄 때 쓴다.
        """
        # ⚠ 창을 닫는 중에 불릴 수 있다(팝업의 <Destroy> → 본문 갱신). 이미 파괴된
        #   위젯에 config 하면 TclError 가 난다 — 실제로 종료 때 그렇게 터졌다.
        try:
            if not self.text.winfo_exists():
                return
        except Exception:
            return
        if d is None:
            # (2026-08-13) `reading_font` → **`theme_font` 「본문」 구역**으로 갈아탔다.
            # ⚠ 성경 본문만 줄 사이(`spacing2`)를 벌린다 — 절마다 문단이 끊기고
            #   wrap 된 줄이 곧 그 절의 이어짐이라 이 값이 독서감을 좌우한다.
            theme_font.apply(self.text, self.db_path, 'bible')
            d = theme_font.resolve(self.db_path, 'bible')
        else:
            theme_font.set_if_changed(
                self.text, font=(d['family'], max(7, int(d['size']))),
                spacing1=d['para_gap'], spacing2=d['line_gap'],
                spacing3=d['para_gap'])
        theme_font.set_if_changed(self.text, padx=d.get('margin', 10), pady=6)
        w = self._num_width()
        # ⚠ **탭 폭은 픽셀 정수로 준다.** `f'{w}p'` 로 쓰면 Tk 가 40 **포인트**(≈53px)로
        #   읽어서 `lmargin2`(픽셀)와 13px 어긋난다 — 첫 줄 본문과 이어지는 줄이
        #   서로 다른 자리에서 시작해 목록처럼 보인다(2026-08-12 실측으로 잡았다).
        # ⚠ 같은 값이면 다시 넣지 않는다 — 본문을 다시 그려 **깜빡인다**
        theme_font.set_if_changed(self.text, tabs=(w,))
        self.text.tag_configure('verse', lmargin1=0, lmargin2=w)
        # 제목을 본문 첫 글자 자리에 맞춘다 (번호 칸만큼 들여쓴다)
        self.text.tag_configure('title', lmargin1=w, lmargin2=w)

    def longest_verse(self):
        """그 장에서 가장 긴 절 → (번호, 본문). 읽기 설정 미리보기가 쓴다.

        ⚠ 짧은 절만 있는 장에서는 P1 에서 줄바꿈이 안 보여 행간 변화를 느낄 수 없다.
          그래서 **가장 긴 절**을 골라 보여 준다.
        """
        best = None
        for i, (kind, num) in enumerate(self._items):
            if kind != 'verse':
                continue
            line = i + 1
            body = self.text.get(f'{line}.0', f'{line}.end')
            body = body.split('\t', 1)[-1]
            if best is None or len(body) > len(best[1]):
                best = (num, body)
        return best

    def finish_fill(self):
        """한 장을 다 채운 뒤 한 번 부른다 — 그때서야 최대 절 번호를 알 수 있다.

        ⚠ `insert` 는 절을 하나씩 받으므로 첫 절을 넣을 때는 그 장이 몇 절인지 모른다.
          `after_idle` 로 미루면 한 프레임 동안 옛 폭으로 그려졌다 바뀌어 깜빡인다.
        """
        self.apply_font()

    # ── Listbox 호환 API ──────────────────────────────────────────────────
    def mark_tags(self):
        """★ 2026-10-25 (docs/1.txt 1-3 · 폰/PC 공통) 절 번호 표시 — 즐겨찾기 = 빨강 굵게 · 녹음 있음 = 초록 밑줄.
        색은 테마 역할에서 그릴 때마다 다시 읽는다(태그 색은 paint 가 못 본다 §36-5b)."""
        try:
            import ui_theme
            red = ui_theme.C('danger') or '#D32F2F'
            green = ui_theme.C('success') or '#2E9D57'
        except Exception:
            red, green = '#D32F2F', '#2E9D57'
        opt = {'foreground': red}
        try:
            import tkinter.font as tkf
            a = tkf.Font(font=self.text.cget('font')).actual()
            opt['font'] = (a['family'], a['size'], 'bold')
        except Exception:
            pass
        self.text.tag_configure('num_fav', **opt)
        try:
            self.text.tag_configure('num_rec', underline=True, underlinefg=green)
        except tk.TclError:              # 옛 Tk — 밑줄 색을 못 준다
            self.text.tag_configure('num_rec', underline=True)
        self.text.tag_raise('num_fav')
        self.text.tag_raise('num_rec')

    def set_num_mark(self, row, mark, on):
        """그 줄 절 번호의 표시 하나를 켜고 끈다(즐겨찾기 단추를 누른 그 자리에서 — 장을 다시 안 그린다)."""
        line = row + 1
        r = self.text.tag_nextrange('num', f'{line}.0', f'{line}.end')
        if not r:
            return
        tag = 'num_' + mark
        if on:
            self.text.tag_add(tag, r[0], r[1])
        else:
            self.text.tag_remove(tag, r[0], r[1])

    def insert(self, index, text, kind='plain', num=None, num2=None, marks=()):
        """항목 하나 추가. `index` 는 END 만 뜻이 있다(Listbox 호출부가 그렇게 쓴다).

        `num2` = **히브리 절 번호**(279차 사용자 「히브리 절 번호 병기」).
          우리 번호와 다를 때만 온다 — 같은 자리에는 아예 안 그린다(§0-1).
        """
        self.text.config(state='normal')
        # ★ 오른쪽에서 왼쪽으로 읽는 글자는 **넣기 직전에** 되돌린다 (2026-08-13 · font.md §8).
        #   Tk 가 히브리·아랍을 왼쪽부터 그려서 그대로 두면 순서가 뒤집혀 보인다.
        #   ⚠ RTL 문자가 없으면 그대로 지나가므로 다른 역본에는 비용이 없다.
        #   ⚠ 여기서 바꾸므로 `get()` 은 **화면에 보이는 대로** 돌려준다 — 복사도 그렇게 된다.
        rtl = False
        try:
            # ⚠ 이 자리는 역본 코드를 안 받는다 — **글자로 짐작한다**
            #   (그래도 「하나라도」가 아니라 「주로」다 · 2026-09-23).
            rtl = bidi.is_rtl_text(text)
            text = bidi.for_display(text)
        except Exception:
            pass
        at = self.text.index('end-1c')
        if kind == 'verse' and num is not None:
            # 번호 칸 폭은 **그 장에서 가장 큰 절 번호**로 정한다 → 여기서 모아 둔다
            try:
                self._max_num = max(self._max_num, int(num))
            except Exception:
                pass
            lab2 = ('\u00b7%s' % num2) if num2 else ''
            if lab2:
                self._numlab = max(self._numlab, '%s%s' % (num, lab2),
                                   key=len)
            if rtl:
                # ★ 오른쪽에서 왼쪽으로 읽는 절은 **번호도 줄이 시작하는 오른쪽 끝**에 온다
                #   (2026-08-13 사용자 결정 ②안 — 실제 히브리 성경의 모습).
                #   ⚠ 탭 스톱은 왼쪽 기준이라 여기서 쓸 수 없다. 공백으로 벌린다.
                self.text.insert('end', f'{text}   ')
                self.text.insert('end', f'{num}', ('num',) + tuple('num_' + m for m in marks))
                if lab2:
                    self.text.insert('end', lab2, ('num2',))
                self.text.insert('end', '\n')
            else:
                self.text.insert('end', f'{num}', ('num',) + tuple('num_' + m for m in marks))
                if lab2:
                    self.text.insert('end', lab2, ('num2',))
                self.text.insert('end', '\t', ('num',))
                self.text.insert('end', f'{text}\n')
        else:
            self.text.insert('end', f'{text}\n')
        line = int(str(at).split('.')[0])
        tag = f'L{len(self._items)}'
        self.text.tag_add(tag, f'{line}.0', f'{line}.end+1c')
        if kind == 'verse':
            if rtl:
                # ⚠ 오른쪽 정렬 줄에는 왼쪽 들여쓰기(`lmargin2`)를 걸지 않는다 —
                #   본문이 오른쪽에서 시작하므로 그 값이 오히려 어긋나게 만든다.
                self.text.tag_add(RTL_TAG, f'{line}.0', f'{line}.end+1c')
            else:
                self.text.tag_add('verse', f'{line}.0', f'{line}.end+1c')
        elif kind == 'title':
            self.text.tag_add('title', f'{line}.0', f'{line}.end+1c')
            # ⚠ 제목도 오른쪽에서 왼쪽으로 읽는 글이면 그쪽으로 붙인다.
            #   지금 `PERI_TITLE` 에는 히브리·아랍 번역이 없어 한국어가 폴백되지만,
            #   **번역이 들어오는 날 이 줄이 그대로 받는다**(2026-08-13 사용자 지적).
            if rtl:
                self.text.tag_add(RTL_TAG, f'{line}.0', f'{line}.end+1c')
                self.text.tag_remove('title', f'{line}.0', f'{line}.end+1c')
                self.text.tag_add('title_fg', f'{line}.0', f'{line}.end+1c')
        self._items.append((kind, num))
        return len(self._items) - 1

    def delete(self, first, last=None):
        self.text.config(state='normal')
        self.text.delete('1.0', 'end')
        self._items = []
        self._sel = None
        self._active = None
        self._max_num = 0      # 장이 바뀌면 자릿수도 다시 센다
        self._numlab = ''

    def size(self):
        return len(self._items)

    def get(self, index):
        i = self._resolve(index)
        if i is None:
            return ''
        line = i + 1
        s = self.text.get(f'{line}.0', f'{line}.end')
        return s.replace('\t', ' ')      # 부르는 쪽이 공백으로 자르는 곳이 있다

    def verse_num(self, index):
        """그 줄의 절 번호. ⚠ **`get()` 을 잘라 쓰지 말 것.**

        오른쪽에서 왼쪽으로 읽는 절은 화면에서 `본문 … 번호` 차례라
        `get(i).split(' ')[0]` 이 번호가 아니라 **본문 조각**을 돌려준다.
        번호는 넣을 때부터 따로 들고 있으니 여기서 그대로 준다
        (2026-08-13 — 실제로 그 코드가 한 곳 있었다).
        """
        i = self._resolve(index)
        if i is None or not (0 <= i < len(self._items)):
            return ''
        kind, num = self._items[i]
        return str(num) if kind == 'verse' and num is not None else ''

    def curselection(self):
        return () if self._sel is None else (self._sel,)

    def selection_set(self, first, last=None):
        i = self._resolve(first)
        if i is None or not (0 <= i < len(self._items)):
            return
        self.selection_clear()
        self._sel = i
        line = i + 1
        self.text.tag_add(SEL_TAG, f'{line}.0', f'{line}.end+1c')
        # ⚠ 절 번호는 흐린 회색('num')이다. 그 태그가 나중에 만들어졌으면 글자색
        #   싸움에서 이겨 고른 절의 번호만 흐리게 남는다 — 맨 위로 올려 못 박는다.
        self.text.tag_raise(SEL_TAG)

    def selection_clear(self, first=None, last=None):
        self.text.tag_remove(SEL_TAG, '1.0', 'end')
        self._sel = None

    def see(self, index):
        i = self._resolve(index)
        if i is not None:
            self.text.see(f'{i + 1}.0')

    def activate(self, index):
        i = self._resolve(index)
        if i is not None:
            self._active = i

    def nearest(self, y):
        try:
            line = int(str(self.text.index(f'@0,{y}')).split('.')[0])
            return max(0, min(line - 1, len(self._items) - 1))
        except Exception:
            return -1

    def yview(self, *a):
        return self.text.yview(*a)

    def xview(self, *a):
        return None      # wrap 이라 가로 스크롤이 없다. 옛 배선이 불러도 조용히 넘긴다

    # ── 내부 ──────────────────────────────────────────────────────────────
    def _resolve(self, index):
        """Listbox 인덱스 표기(정수 · 'end' · ACTIVE)를 항목 번호로."""
        if index in ('end', tk.END):
            return len(self._items) - 1 if self._items else None
        if index in ('active', tk.ACTIVE):
            return self._active if self._active is not None else self._sel
        try:
            return int(index)
        except Exception:
            return None

    def _verse_rows(self):
        """선택할 수 있는 항목만. 페리코프 제목·안내 줄은 빠진다.

        ⚠ `user_main.p1_idx_map` 이 제목 자리에 `None` 을 넣어 두므로, 여기서
          거르는 것과 그쪽이 거르는 것이 **같은 줄이어야 한다**(kind=='verse').
        """
        return [i for i, (k, _) in enumerate(self._items) if k == 'verse']

    def _fire(self, i, scroll=False):
        """선택하고 알린다. 기존 배선(`<<ListboxSelect>>` → on_verse_selected)이 그대로 산다."""
        self.selection_set(i)
        self._active = i
        if scroll:
            self.see(i)
        self.event_generate('<<ListboxSelect>>')
        if callable(self._on_select):
            self._on_select(i)

    # ── 화살표 이동 (2026-08-13 사용자 지시) ──────────────────────────────
    # ⚠ `tk.Listbox` 는 Up/Down 을 **클래스 바인딩으로 공짜로** 해 주었다 —
    #   선택을 옮기고 `<<ListboxSelect>>` 까지 스스로 쏘았다. Text 로 바꾸면서
    #   그 동작이 통째로 사라졌다. 위젯을 갈아 끼울 때는 **그 위젯이 거저 해 주던
    #   일**을 함께 옮겨야 한다(탭 폭·lmargin2 에 이어 세 번째다).
    def _step(self, n):
        rows = self._verse_rows()
        if not rows:
            return 'break'
        cur = self._sel if self._sel is not None else self._active
        if cur in rows:
            pos = rows.index(cur) + n
        else:
            # 아직 고른 절이 없거나 제목 줄에 서 있으면 방향에 맞는 끝에서 시작한다
            pos = 0 if n > 0 else len(rows) - 1
        self._fire(rows[max(0, min(pos, len(rows) - 1))], scroll=True)
        return 'break'

    def _jump(self, last):
        rows = self._verse_rows()
        if rows:
            self._fire(rows[-1 if last else 0], scroll=True)
        return 'break'

    def _on_click(self, ev):
        """절을 선택하고 **Text 의 기본 클릭 처리는 그대로 흘려보낸다**.

        ⚠ 예전에는 여기서 `'break'` 를 돌려주었다. 그러면 Tk 가 끌어서 선택을 시작할
          기준점을 잡지 못해 **여러 절을 끌어 고르는 일이 아예 안 됐다**
          (2026-08-13 실측 — Ctrl+C 를 열어도 고른 것이 0줄이라 복사할 것이 없었다).
          그래서 `None` 을 돌려준다. 포커스도 그 기본 처리가 함께 해 준다.
        ⚠ 우리 하이라이트는 `SEL_TAG`, Tk 의 끌어 고르기는 `'sel'` 로 **서로 다른 태그**라
          한 화면에 겹쳐 있어도 부딪히지 않는다.
        """
        i = self.nearest(ev.y)
        if 0 <= i < len(self._items) and self._items[i][0] == 'verse':
            self._fire(i)        # 클릭은 스크롤하지 않는다 — 화면이 튀면 어색하다
        # 제목·안내 줄이면 고르지 않는다. 다만 그 줄에서 끌어 고르기를 시작할 수는 있다.
        return None
