# -*- coding: utf-8 -*-
"""my_edit.py — **My Edit 패키지 주방** (2026-08-27 신설·영구).

★★★ 왜 (사용자 확정 — 0.txt 1번 「사용자가 텍스트 자산, 링크자산, 유닛자산을
  마음대로 요리할 수 있는 패키지 주방을 설계하라. 어디에서든 어떤 요리든
  상황에 맞게 가능해야 한다」):
  같은 [My Edit] 를 눌러도 **어디서 눌렀느냐로 화면 문법이 셋**이었다
  (구절 창·용어 창·렌즈 스튜디오). 배우는 규칙이 셋이면 통합이 아니다.

재료는 셋뿐이다 (실측)
  · **텍스트 자산** — 그 자산에 붙는 글 (VERS_DESC 49,220 · NODE_DESC 702 …)
  · **링크 자산**   — 자산↔자산 (ENTI_VERS 18,868 · VERS_VERS 2,734 …)
  · **유닛 자산**   — 사용자가 **짓는 구조**(렌즈 52 · 노드 364)
  ⚠ **연결설명문은 별도 재료가 아니라 「링크 위의 텍스트」**다 — 이 한 줄이
    구절간 연결설명문과 렌즈 노드의 구간 설명을 같은 문법으로 묶는다.

골격 — 출발지 띠 + 조리대 탭
      ┏━ 출발지 (배경색 띠·상단 고정) ━━━━━━━━━━━━━┓
      ┃ [구절][단락][흐름] [용어][태그] [렌즈]…      ┃  ← 자산 갈래
      ┃ 창세기 1:20  "…"        [선택기] [최근 ▾]    ┃  ← 지금 잡은 것
      ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
      [연결][글][구조][연결설명문][고유…][휴지통]
  ⚠ **탭 자리는 늘 같다** (사용자 확정 — 「모든 탭 구조를 참고하지 않지만
    일정한 곳에 배치되는 것이 좋다」·「회색지대는 갈 필요 없다는 교육효과」).
    그 자산에 없는 재료면 **회색**으로 두고 왜 회색인지 한 줄 말한다.
    빈 서랍 금지(§4-⑤)는 목록 화면의 규칙이고, **작업대는 연장이 늘 같은
    자리에 있어야** 손이 기억한다 — 두 규칙이 부딪히면 여기서는 후자다.
  ⚠ 회색이어도 **비용은 0** — 탭 내용은 누를 때 짓는다(§29 지연 빌드).

`ASSET_CAPS` 한 표가 **회색 판정·선택기·고유 탭의 단일 소스**다.
화면을 늘릴 때 그 표만 고친다.

    python my_edit.py --selftest      (의무)
"""
import sys
import tkinter as tk
from tkinter import ttk

import appdb
import i18n

# ══════════════════════════════════════════════════════════════════
#  조리대 — 자리와 차례가 **전 자산 동일**
# ══════════════════════════════════════════════════════════════════
#: (열쇠, i18n, 기본 이름)
DECKS = (
    ('LINK', 'ME_D_LINK', '연결'),
    ('TEXT', 'ME_D_TEXT', '글'),
    ('BUILD', 'ME_D_BUILD', '구조'),
    ('LDESC', 'ME_D_LDESC', '연결설명문'),
    ('OWN', 'ME_D_OWN', '고유'),
    ('TRASH', 'TRASH_TAB', '휴지통'),
)

#: 자산 갈래 — **성경 묶음 → 용어 묶음 → 자료 묶음** (2026-08-27 사용자
#  「구절/단락은 성경에 관련된 것이니 가깝게. 용어/태그도. 흐름도 구절 옆에」).
#  ⚠ 플랜은 뺐다(사용자 확정 — 연결 15건뿐이라 실익이 적다).
KINDS = (
    ('VERSE',     'OC_K_VERSE',  '구절'),
    ('PERICOPE',  'LP_B_PERI',   '단락'),
    ('CHAIN',     'LP_B_CHAIN',  '말씀의 흐름'),
    ('ENTITY',    'OC_K_TERM',   '용어'),
    ('TAG',       'LP_B_TAG',    '태그'),
    ('LENS',      'OC_K_LENS',   '렌즈'),
    ('NODE',      'ME_K_NODE',   '노드'),
    ('BOOK_UNIT', 'LP_B_BOOK',   '도서'),
    ('REF_UNIT',  'LP_B_REF',    '자료집 글'),
    ('USER_REF',  'LP_B_STUDY',  '내 연구자료'),
    ('MEDIA',     'LP_B_MEDIA',  '외부연결'),
    # ★★★ **내 영상** (2026-09-10 사용자 「연결팝업 화면에서 다른 여러
    #   자산들과 연결될 수 있도록 해야 한다」) — 내가 담은 영상이 출발지가
    #   되어 태그·용어·구절·도서 어디에나 붙는다.
    ('UMEDIA',    'LP_K_UMEDIA', '내 영상'),
)

#: ★★ **능력표 — 회색 판정의 단일 소스** (실측 기반, 2026-08-27)
#   decks: 그 자산에서 **살아 있는** 조리대. 없는 것은 회색.
#   why:   회색인 이유를 말할 때 쓰는 열쇠(없으면 기본 문구)
#   pick:  출발지 선택기 종류 (asset_pick 이 읽는다)
#   own:   고유 탭 이름들(있으면 OWN 조리대가 산다)
ASSET_CAPS = {
    # ⚠⚠ **구절의 「고유」를 뺐다** (2026-08-29 사용자 되물음 — 「고유 탭은
    #   왜 필요한가? **재고창고에 이미 용어/태그가 있다.** 이것은 별명에만
    #   사용하는 것 아닌가?」). 맞다 — 구절의 고유 탭은 「태그·용어 잇기」였고
    #   그것은 **연결 조리대(작업대)가 하는 일**이다. 같은 일을 두 탭에 두면
    #   어느 것이 진짜인지 알 수 없다.
    #   ⇒ 「고유」에 남는 것은 **그 자산에만 있고 연결이 아닌 것**뿐이다:
    #     용어의 **별명·사전** · 도서 편의 **밑줄·메모**.
    'VERSE':     dict(decks=('LINK', 'TEXT', 'LDESC', 'TRASH'),
                      pick='BIBLE'),
    'PERICOPE':  dict(decks=('LINK', 'TEXT', 'TRASH'), pick='PERI'),
    'CHAIN':     dict(decks=('LINK', 'TEXT', 'TRASH'), pick='LIST'),
    'ENTITY':    dict(decks=('LINK', 'TEXT', 'LDESC', 'OWN', 'TRASH'),
                      pick='SEARCH', own=('ALIAS', 'DICT')),
    'TAG':       dict(decks=('LINK', 'TRASH'), pick='SEARCH'),
    'LENS':      dict(decks=('LINK', 'TEXT', 'BUILD', 'TRASH'), pick='LIST'),
    'NODE':      dict(decks=('LINK', 'TEXT', 'BUILD', 'LDESC', 'TRASH'),
                      pick='LIST'),
    'BOOK_UNIT': dict(decks=('LINK', 'OWN', 'TRASH'), pick='BOOK',
                      own=('MARKS',)),
    'REF_UNIT':  dict(decks=('LINK', 'TRASH'), pick='SRCSEARCH'),
    'USER_REF':  dict(decks=('LINK', 'TEXT', 'TRASH'), pick='LIST'),
    'MEDIA':     dict(decks=('LINK', 'TRASH'), pick='SEARCH'),
    # ★ 내 영상 — 연결과 휴지통. 글 조리대는 없다(제목·URL 은 연결팝업의
    #   가운데 확인 칸에서 그 자리에 고친다).
    'UMEDIA':    dict(decks=('LINK', 'TRASH'), pick='SEARCH'),
    # ★★★ **묵상노트 = 자산** (2026-08-30 사용자 확정 — 「출발지가 묵상노트가
    #   아니라 구절이라는 문제 … 본격적인 연결대상 자산으로 포함하라. 그래야
    #   출발지 이름 자체가 묵상노트의 제목으로 표시될 수 있음」).
    #   · `LINK`  — 태그·용어·구절·도서… 무엇이든 잇는다(그 노트가 출발지다)
    #   · `TEXT`  — 글은 **묵상노트 화면**이 쓴다. 여기서 또 지으면 두 벌이고,
    #                자동저장·카드 구조가 그 화면에만 있다 ⇒ 일부러 뺐다.
    #   · `TRASH` — 내가 숨긴 연결을 되살리는 자리(모든 자산 공통)
    'NOTE':      dict(decks=('LINK', 'TRASH'), pick='SEARCH'),
}

#: 회색 조리대에 뜨는 안내 — 「왜 여기는 갈 필요가 없는가」(교육 효과)
GRAY_WHY = {
    'BUILD': ('ME_W_BUILD', '구조를 짓는 것은 렌즈와 노드입니다. '
              '왼쪽 위에서 [렌즈]를 선택하면 렌즈·노드·구절을 만들 수 있습니다.'),
    'TEXT': ('ME_W_TEXT', '이 자산에는 내가 고칠 글이 없습니다. '
             '남의 저작(도서·사전)은 본문을 고치지 않습니다.'),
    'LDESC': ('ME_W_LDESC', '연결설명문은 구절끼리·용어와 구절·노드와 구절을 '
              '이었을 때 그 연결에 붙이는 글입니다.'),
    'OWN': ('ME_W_OWN', '이 자산에만 있는 기능이 없습니다.'),
}


def deck_alive(kind, deck):
    """그 자산에서 이 조리대가 살아 있나 (회색 판정의 단일 문)."""
    cap = ASSET_CAPS.get(str(kind).upper())
    if not cap:
        return deck in ('LINK', 'TRASH')      # 모르는 자산도 연결은 된다
    return deck in cap['decks']


def kind_name(kind):
    for k, i18k, dflt in KINDS:
        if k == kind:
            return i18n.t(i18k, dflt)
    return str(kind)


def deck_name(deck):
    for k, i18k, dflt in DECKS:
        if k == deck:
            return i18n.t(i18k, dflt)
    return str(deck)


def gray_why(deck):
    k = GRAY_WHY.get(deck)
    return i18n.t(k[0], k[1]) if k else i18n.t(
        'ME_W_ETC', '이 자산에서는 쓰지 않는 기능입니다.')


# ══════════════════════════════════════════════════════════════════
#  창 — 자산 종류마다 하나(싱글턴). 골격은 하나다.
# ══════════════════════════════════════════════════════════════════
#: **의도** — 이 창을 왜 열었나 (2026-08-31 사용자 확정 · 0.txt 3번)
#   `NEW`  단추만 눌렀다 → **새로 쓰려는 것**이다
#   `EDIT` 목록을 고르고 눌렀다 → **그것을 고치거나 다른 자산과 이으려는 것**이다
INTENT_NEW, INTENT_EDIT = 'NEW', 'EDIT'


def open(parent, kind='VERSE', asset_id=None, on_changed=None,
         pick_kind=None, pick_label=None, auto_create=False,
         focus_link=None, intent=None):
    """**어디에서든 한 문으로** — 화면이 보고 있는 것을 그대로 넘긴다.

    ⚠ 각 화면의 [My Edit] 가 자기 것을 안 넘기면 엉뚱한 기준이 뜬다
      (2026-08-27 연구자료가 그래서 창1:1 로 열렸다).

    ★★★ **모든 연결 팝업이 이 창 하나다** (2026-08-30 사용자 지시 「P2 클릭할
      때 팝업화면과 P4 화면 클릭할 때 팝업화면이 다르다. 왜 다른가? 휴지통이
      없다. 최대화 최소화도 안 된다. **모든 연결팝업 화면을 P4 팝업화면으로
      통일하라**」).
      ⚠ 그전에는 P2 가 `link_picker.open_picker`(맨 Toplevel · `grab_set` ·
        크기 고정 · 휴지통 없음)를, P4 가 이 창(조리대 여섯 · 크기 기억)을
        열었다. **같은 일에 창이 둘**이었다.
    `pick_kind`/`pick_label`/`auto_create` — 연결 조리대의 재고 갈래를 미리
    누르고, 그 갈래의 이름을 부른 화면의 말로 바꿔 달고, 만들기 폼까지 연다.
    """
    # ★★★ **의도가 세 칸을 정한다** (2026-08-31 사용자 확정 — 0.txt 3번).
    #   | | NEW(단추만) | EDIT(목록 고르고) |
    #   |①왼쪽| 구절의 모든 연결 | **그 자산**의 모든 연결 |
    #   |③오른쪽| 그 갈래에 **포커스** | 포커스 없음 |
    #   |②가운데| **빈 입력화면** | **수정화면** |
    #   ⚠⚠ 그전에는 `pick_kind` 가 ③을, `asset_id` 가 ①을 각각 정하고 **②는
    #     아무도 안 정했다** — 그것이 「묵상노트 My Edit 이 빈 화면을 안 띄운다」
    #     의 정체다(0.txt 1-4).
    #   ⚠ 규칙을 **여기 한 곳**에 둔다 — 화면마다 계산하면 늘 때마다 갈린다.
    if intent == INTENT_NEW:
        auto_create = True
    elif intent == INTENT_EDIT:
        auto_create = False
        pick_kind = pick_label = None
    root = parent.winfo_toplevel()
    win = getattr(root, '_my_edit_win', None)
    if win is not None:
        try:
            if win.winfo_exists():
                win.set_pick(pick_kind, pick_label, auto_create,
                             focus_link)
                win.set_anchor(kind, asset_id)
                win.lift()
                win.focus_force()
                if pick_kind:
                    win.focus_deck('LINK')
                return win
        except Exception:
            pass
    win = MyEditWin(root, appdb.MAIN_DB, on_changed=on_changed)
    root._my_edit_win = win
    win.set_pick(pick_kind, pick_label, auto_create, focus_link)
    win.set_anchor(kind, asset_id)
    if pick_kind:
        win.focus_deck('LINK')
    return win


class MyEditWin(tk.Toplevel):
    """골격 — 출발지 띠 + 조리대 탭. 몸통은 각 부품을 심는다."""

    def __init__(self, root, db_path, on_changed=None):
        super().__init__(root)
        _t = i18n.t
        self.db_path = db_path
        self.on_changed = on_changed
        self.kind = None
        self.asset_id = None
        self.lang = 'KO'
        try:
            with appdb.connect(db_path) as conn:
                import verse_tier
                self.lang = verse_tier.get_desc_lang(conn) or 'KO'
        except Exception:
            pass
        self.title(_t('OC_TITLE', 'My Edit'))
        # ★ 부품이 요구하는 표면 — 기존 조리대 부품(_SectionsPanel·_LinkTab·
        #   _TagTermTab)은 `db_path`·`lang`·`changed`·`_books` 넷만 쓴다
        #   (실측). 그래서 **그대로 심을 수 있다** — 베끼지 않는다.
        try:
            with appdb.connect(db_path) as conn:
                self._books = conn.execute(
                    'SELECT bn.book_code, bn.full_name FROM book_names bn '
                    'WHERE UPPER(bn.lang_code)=? AND bn.book_code IN '
                    '(SELECT DISTINCT bcode FROM bible_index) '
                    'ORDER BY bn.book_code',
                    ((self.lang or 'KO').upper(),)).fetchall()
        except Exception:
            self._books = []
        self._restore_geom()

        # ── 출발지 띠 — **배경색·상단 고정** (사용자 확정: 「기준점 선택
        #    콤보는 가시성이 매우 불편했다. 최상단에 배경색을 가진 출발지
        #    선택공간을 만들자」) ─────────────────────────────────
        # ★ 색은 **역할**로 (§0 하드코딩 금지). 띠 배경은 `panel_alt`.
        #   ⚠ 만들 때 한 번 읽은 값이라 테마를 바꾸면 이 띠만 남을 수 있다 —
        #     `apply_theme()` 를 두어 `ui_theme.paint` 뒤 다시 칠한다
        #     (paint 는 표에 있는 색을 역할로 번역하므로 대개 따라오지만,
        #      팔레트 밖 값이 되면 여기서 못 박는다).
        import ui_theme
        bar_bg = ui_theme.C('panel_alt') or '#ECF0F1'
        self._bar_role = 'panel_alt'
        self._bar = tk.Frame(self, bg=bar_bg)
        self._bar.pack(fill='x', side='top')
        # ⚠⚠ **「출발지」 라벨 줄을 통째로 걷었다** (2026-08-30 사용자 지시
        #   「최 상단의 "출발지"라는 라벨과 공간을 제거할 것」). 그 줄에는
        #   라벨 하나뿐이었는데 `pady=(6,0)` 까지 합쳐 **약 24px** 를 먹고
        #   있었다. 무엇이 기준인지는 **바로 아래 큰 글자**가 이미 말한다.
        head = tk.Frame(self._bar, bg=bar_bg)   # 호환용 빈 자리(안 그린다)
        # ⚠⚠ **갈래 단추와 선택기를 걷었다** (2026-08-29 사용자 판단 —
        #   「최상단 버튼 제거하면 작업대에서 얼마든지 항목까지 선택할 수 있고
        #     추가한 후에 그것을 출발지로 지정 가능하다. **장애요인이
        #     무엇인가**」). 실측으로 확인했다 — 장애요인이 없었다:
        #     · 작업대 ③ 에 자산 **열다섯 전부**가 있고 [↷ 출발지로 지정]이
        #       그 자리에서 기준을 바꾼다(실측 — 용어로 갈아탐).
        #     · 상단에만 있던 [지금 보는 절로]는 **작업대 성경 줄로 옮겼다.**
        #   ★ 게다가 상단이 **버그를 낳고 있었다** — 갈래 단추만 누르면
        #     `set_anchor(kind, None)` 이라 **종류만 바뀌고 번호는 옛것**이었다.
        #     실측: 창1:1 을 보다 [용어]를 누르면 기준이 **「다윗」**(entity 1)이
        #     됐다. 고르지도 않은 자산이다. 단추를 없애니 그 길이 사라진다.
        #   ⚠ 기준을 바꾸는 길은 이제 둘 — **작업대 ③**(새 자산) ·
        #     **지나온 출발지 띠**(다녀온 자리). 띠는 어느 탭에서나 보인다.
        self._kbtns = {}
        # ── **지나온 출발지 띠** (2026-08-29 사용자 — 「My Edit 때문에 띠를
        #    만든 것이다. 지난 경로를 다시 기준점으로 잡으려면 반드시 필요」).
        #    누르면 그것이 곧 출발지다. 자르지 않고, 20칸까지 쌓이며,
        #    한 번에 여섯 칸 보이고 나머지는 [◀][▶].
        #    ⚠ 저장소는 `asset_pick` 의 `ME_RECENT` **하나** — [최근 ▾] 과
        #      같은 것을 펼친 것이라 두 벌이 아니다.
        self._trail_host = tk.Frame(self._bar, bg=bar_bg)
        self._trail_host.pack(fill='x', padx=10, pady=(3, 0))
        self._trail_redraw = None

        # 지금 잡은 것 — 크게, **왼쪽 정렬** (2026-08-30 사용자 지시 「연결팝업
        #   화면의 출발지 표시(예: 창1:21 본문내용…)를 **오른쪽 정렬하고 있는데
        #   왼쪽 정렬로** 바꿀 것」).
        #   ⚠ 오른쪽 정렬이면 이름 길이에 따라 **시작 자리가 매번 달라져** 눈이
        #     따라가야 한다. 왼쪽에 못 박으면 늘 같은 자리에서 읽힌다.
        #   ★ 종류(`_sub_lbl`)는 이름 **오른쪽에 붙여** 함께 왼쪽으로 흐른다.
        row2 = tk.Frame(self._bar, bg=bar_bg)
        row2.pack(fill='x', padx=10, pady=(4, 5))
        self._pick_host = tk.Frame(row2, bg=bar_bg)   # 호환용 빈 자리
        # ★ 14pt — **관리자 연결 탭의 띠와 같은 규격** (2026-09-22 · 1.txt
        #   7-2 「사용자화면과 일치할 것」 · 「큰 글자(14p 이상)」).
        self._head_lbl = tk.Label(row2, text='', bg=bar_bg, anchor='w',
                                  font=('', 14, 'bold'))
        self._head_lbl.pack(side='left')
        self._sub_lbl = tk.Label(row2, text='', bg=bar_bg, anchor='w')
        self._sub_lbl.pack(side='left', padx=(8, 0))

        # ── 조리대 ────────────────────────────────────────────
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill='both', expand=True, padx=8, pady=(4, 8))
        self._decks = {}
        self._built = set()
        self._pick = (None, None, False)   # 연결 조리대 재고 갈래 (set_pick)
        self._focus_link = None            # ① 현황에서 미리 고를 줄
        for k, _i, _d in DECKS:
            f = ttk.Frame(self.nb)
            self.nb.add(f, text=' %s ' % deck_name(k))
            self._decks[k] = f
        self.nb.bind('<<NotebookTabChanged>>', self._on_deck, add='+')
        try:
            ui_theme.adopt(self)
        except Exception:
            pass

    def apply_theme(self):
        """테마가 바뀌면 띠 색을 다시 잡는다(theme_font/_poke 가 찾아 부른다)."""
        try:
            import ui_theme
            c = ui_theme.C(self._bar_role) or '#ECF0F1'
            for w in (self._bar,) + tuple(self._bar.winfo_children()):
                try:
                    w.configure(bg=c)
                except Exception:
                    pass
                for c2 in w.winfo_children():
                    try:
                        c2.configure(bg=c)
                    except Exception:
                        pass
        except Exception:
            pass

    # ── 기준(출발지) ────────────────────────────────────────
    def set_pick(self, pick_kind=None, pick_label=None, auto_create=False,
                 focus_link=None):
        """연결 조리대가 열릴 때 미리 누를 재고 갈래 (2026-08-30).

        `focus_link` — `(종류, 번호)`. 주면 **① 현황에서 그 줄을 골라 둔다**
          (2026-08-30 사용자 지시 「목록을 클릭하고 링크 숨기기 버튼을 누르면
          연결팝업 화면의 왼쪽 화면에서 **해당 링크가 선택된 상태로 자동 세팅**
          ⇒ 연결숨기기 버튼만 누르면 숨기기 완성」).
        ⚠ **이미 지어 둔 조리대는 다시 짓는다** — 값만 바꾸면 화면이 안 따라온다.
        """
        self._pick = (pick_kind, pick_label, bool(auto_create))
        self._focus_link = focus_link
        if 'LINK' in getattr(self, '_built', ()):
            self._built.discard('LINK')
            f = self._decks.get('LINK')
            if f is not None:
                for w in f.winfo_children():
                    w.destroy()

    def focus_deck(self, key):
        """그 조리대를 앞으로 — 부른 화면이 무엇을 하러 왔는지 안다."""
        try:
            for i, (k, _a, _b) in enumerate(DECKS):
                if k == key:
                    self.nb.select(i)
                    return
        except Exception:
            pass

    def set_anchor(self, kind, asset_id=None):
        kind = str(kind or 'VERSE').upper()
        changed = (kind != self.kind) or (asset_id != self.asset_id)
        self.kind = kind
        if asset_id is not None:
            self.asset_id = asset_id
        # ★ **지나온 출발지에 남긴다** — 띠가 읽는 그 목록이다.
        #   ⚠ `push_recent` 은 이미 있는 것의 자리를 **안 옮긴다**(지나온 길 보존).
        if self.asset_id:
            try:
                import asset_pick
                with appdb.connect(self.db_path) as c:
                    asset_pick.push_recent(c, self.kind, self.asset_id)
            except Exception as e:
                print('[my_edit] recent:', e)
        self._sync_kind_btns()
        self._sync_decks()
        self._sync_head()
        self._rebuild_picker()
        self._rebuild_trail()
        if changed:
            self._built.clear()               # 기준이 바뀌면 다시 짓는다
            for f in self._decks.values():
                for w in f.winfo_children():
                    w.destroy()
            self._on_deck()
        return True

    def _sync_kind_btns(self):
        for k, b in self._kbtns.items():        # 지금은 비어 있다
            b.config(relief='sunken' if k == self.kind else 'raised')

    def _sync_decks(self):
        """★ 회색지대 — 자리는 그대로, 갈 곳이 아니면 회색."""
        for k, f in self._decks.items():
            alive = deck_alive(self.kind, k)
            try:
                self.nb.tab(f, state='normal' if alive else 'disabled')
            except Exception:
                pass
        # 현재 탭이 회색이 됐으면 살아 있는 첫 탭으로
        try:
            cur = self.nb.index('current')
            if str(self.nb.tab(cur, 'state')) == 'disabled':
                for k, _i, _d in DECKS:
                    if deck_alive(self.kind, k):
                        self.nb.select(self._decks[k])
                        break
        except Exception:
            pass

    def _sync_head(self):
        nm, sub = self.label_of()
        self._head_lbl.config(text=nm)
        self._sub_lbl.config(text=sub)

    def label_of(self):
        """지금 잡은 것의 (이름, 곁들임)."""
        if not self.asset_id:
            return (i18n.t('ME_NOPICK', '선택하지 않음'),
                    i18n.t('ME_NOPICK_H', '오른쪽에서 선택하세요'))
        try:
            import link_picker as LP
            with appdb.connect(self.db_path) as conn:
                lbl = LP.label_of(conn, self.kind, self.asset_id, None,
                                  self.lang)
                # ★ **곁들임은 「무엇을 붙잡았나」를 말한다** (2026-08-30) —
                #   구절은 본문 맛보기, 나머지는 **종류 이름**이다. 그전에는
                #   구절이 아니면 통째로 비어 있어, 이름만 보고는 그것이 노트인지
                #   용어인지 알 수 없었다(묵상노트를 자산으로 올리며 드러났다).
                if self.kind == 'VERSE':
                    # ⚠ **사용자 역본**으로 (2026-08-27 — 그냥 LIMIT 1 이면
                    #   아랍어가 튀어나온다. 실측으로 잡았다).
                    import overlay_center as _oc
                    sub = '  "%s"' % _oc._verse_body(conn,
                                                     self.asset_id)[:60]
                else:
                    sub = '· ' + LP.kind_name(self.kind, self.lang)
            return (lbl or '#%s' % self.asset_id, sub)
        except Exception:
            return ('#%s' % self.asset_id, '')

    def _rebuild_trail(self):
        try:
            import asset_pick
            self._trail_redraw = asset_pick.build_trail(self._trail_host, self)
        except Exception as e:
            print('[my_edit] trail:', e)

    def _rebuild_picker(self):
        """⚠ 선택기는 걷었다(2026-08-29) — 선택하는 곳은 작업대 ③ 하나다.
        호출부를 지우지 않고 빈 함수로 둔다(옛 흐름이 그대로 지나간다)."""
        return

    # ── 조리대 지연 빌드 ────────────────────────────────────
    def _on_deck(self, _e=None):
        try:
            cur = self.nb.index('current')
        except Exception:
            return
        key = None
        for k, f in self._decks.items():
            if str(f) == str(self.nb.tabs()[cur]):
                key = k
                break
        if key is None or key in self._built:
            return
        self._built.add(key)
        host = self._decks[key]
        if not deck_alive(self.kind, key):
            tk.Label(host, text='ⓘ ' + gray_why(key), anchor='w',
                     justify='left', wraplength=700).pack(
                fill='x', padx=14, pady=14)
            return
        try:
            self._build_deck(key, host)
        except Exception as e:
            import traceback
            traceback.print_exc()
            tk.Label(host, text='읽지 못했다: %s' % e, anchor='w').pack(
                padx=12, pady=12)

    def _build_deck(self, key, host):
        """조리대 몸통 — **이미 있는 부품을 심는다**(두 벌 금지)."""
        if key == 'LINK':
            from admin import panel_std
            # ⚠⚠ **My Edit 은 자기 출발지 띠가 이미 있다** — 작업대가 띠를
            #   하나 더 얹으면 **두 줄**이 되어 무엇이 기준인지 안 갈린다.
            #   대신 `on_anchor` 만 넘겨 [↷ 이것을 출발지로] 가 **창 전체의
            #   기준**을 바꾸게 한다(2026-08-29 · 항목 5).
            self._link_api = panel_std.link_tab(
                host, lambda: ((self.kind, self.asset_id)
                               if self.asset_id else None),
                lang_getter=lambda: self.lang, scope='USER',
                db_path=self.db_path, on_saved=lambda: self.changed('LINK'),
                anchor_bar=False, on_anchor=self.set_anchor,
                focus_link=self._focus_link,
                pick_kind=self._pick[0], pick_label=self._pick[1],
                auto_create=self._pick[2])
        elif key == 'TRASH':
            import trash_view
            trash_view._TrashBody(host, self.db_path,
                                  lambda: self.lang).pack(fill='both',
                                                          expand=True)
        elif key == 'BUILD':
            import my_lens_edit
            my_lens_edit.LensBuildPanel(
                host, self.db_path, lambda: self.lang,
                on_changed=lambda: self.changed('LENS')).pack(fill='both',
                                                              expand=True)
        elif key == 'TEXT':
            self._build_text(host)
        elif key == 'LDESC':
            self._build_ldesc(host)
        elif key == 'OWN':
            self._build_own(host)

    # ── 글 — 자산마다 다른 구획 (2단계 이식) ──────────────────
    def _build_text(self, host):
        import overlay_center as OC
        if self.kind == 'VERSE':
            # 구절 6구획(장·일반·전문·묵상질문·연구질문·기도) — 그 부품 그대로
            self._text_panel = OC._SectionsPanel(host, self)
            self._text_panel.pack(fill='both', expand=True)
            if self.asset_id:
                self._text_panel.load_verse(self.asset_id)
            return
        if self.kind in ('LENS', 'NODE'):
            # 렌즈·노드 글 — 렌즈 탭 부품(자체 앵커)
            self._text_panel = OC._LensTab(host, self)
            self._text_panel.pack(fill='both', expand=True)
            try:
                self._text_panel.set_lens_anchor(
                    ('CONTAINER' if self.kind == 'LENS' else 'NODE',
                     self.asset_id))
            except Exception as e:
                print('[my_edit] lens text:', e)
            return
        if self.kind == 'ENTITY':
            # 용어 설명문 — MY 창 몸통을 통째로(별명·사전도 그 안에 있으나
            # 여기서는 글만 보이면 되므로 몸통을 심고 설명문 탭을 고른다)
            self._ensure_entity_body(host)
            return
        if self.kind == 'USER_REF':
            import p4_ref_view
            self._text_panel = p4_ref_view.RefDetailView(
                host, self.db_path, lang_getter=lambda: self.lang,
                show_list=False)
            self._text_panel.pack(fill='both', expand=True)
            try:
                self._text_panel.show_user(self.asset_id, _from_list=True)
            except Exception as e:
                print('[my_edit] ref text:', e)
            return
        if self.kind == 'PERICOPE':
            self._build_peri_text(host)
            return
        tk.Label(host, text='ⓘ ' + gray_why('TEXT'), anchor='w',
                 justify='left', wraplength=700).pack(fill='x', padx=14,
                                                      pady=14)

    def _build_peri_text(self, host):
        """단락 설명문 — **그 단락의 글**(`PERI_DESC`).

        ⚠⚠ **2026-08-29 수리.** 그전에는 그 단락의 **첫 절**을 앵커로 삼아
          **구절 6구획**을 띄웠다. 그래서 사용자 신고대로 「단락을 출발지로
          지정했는데 **단락 설명문을 표시하지도 못하고 수정할 수도 없다.
          「글」 탭이 구절 단위로 표준화되어 작동한다**」가 됐다.
          단락 설명문(3,075편)은 화면에 아예 없었다.
        ⇒ 덮개 어댑터 `PeriTextOverlay`(열쇠 = `peri_code`)를 세우고
          같은 구획 부품에 **단락 글 하나**를 실었다. 가리기·비교·되돌리기·
          저장이 구절 설명문과 똑같이 돈다.
        """
        import overlay_center as OC
        if not self.asset_id:
            tk.Label(host, text='ⓘ ' + gray_why('TEXT'), anchor='w').pack(
                fill='x', padx=14, pady=14)
            return
        with appdb.connect(self.db_path) as conn:
            r = conn.execute(
                'SELECT peri_code, start_vid, end_vid FROM sys_pericope_asset '
                'WHERE pericope_id=?', (self.asset_id,)).fetchone()
        if not r:
            tk.Label(host, text='ⓘ ' + gray_why('TEXT'), anchor='w').pack(
                fill='x', padx=14, pady=14)
            return
        self._text_panel = OC._SectionsPanel(host, self)
        self._text_panel.pack(fill='both', expand=True)
        self._text_panel.load([('pd', i18n.t('OC_S_PERIDESC', '단락 설명문'),
                                'PERI_DESC', self.asset_id, '')])

    # ── 연결설명문 — 링크 위의 글 ────────────────────────────
    def _build_ldesc(self, host):
        import overlay_center as OC
        if self.kind == 'VERSE':
            self._ldesc_panel = OC._LinkTab(host, self)
            self._ldesc_panel.pack(fill='both', expand=True)
            if self.asset_id:
                self._ldesc_panel.load(self.asset_id)
            return
        if self.kind == 'ENTITY':
            # 용어↔구절 연결설명문 = MY 창 「연결구절」 탭
            self._ensure_entity_body(host, focus='VERSE')
            return
        if self.kind == 'NODE':
            # 노드↔구절 구간 설명 = 렌즈 구성 화면의 그 자리
            import my_lens_edit
            my_lens_edit.LensBuildPanel(
                host, self.db_path, lambda: self.lang,
                on_changed=lambda: self.changed('LENS')).pack(fill='both',
                                                              expand=True)
            return
        tk.Label(host, text='ⓘ ' + gray_why('LDESC'), anchor='w',
                 justify='left', wraplength=700).pack(fill='x', padx=14,
                                                      pady=14)

    # ── 고유 — 그 자산에만 있는 것 ───────────────────────────
    def _build_own(self, host):
        # ⚠ 구절은 여기 오지 않는다 — 태그·용어 잇기는 **연결 조리대**의 일이다
        #   (2026-08-29). `OC._TagTermTab` 은 총괄 창이 계속 쓰므로 남는다.
        if self.kind == 'ENTITY':
            self._ensure_entity_body(host, focus='ALIAS')
            return
        if self.kind == 'BOOK_UNIT':
            tk.Label(host, anchor='w', justify='left', wraplength=700,
                     text='ⓘ ' + i18n.t(
                         'ME_W_MARKS',
                         '밑줄·메모는 도서를 **읽는 화면**에서 그 자리에 '
                         '긋습니다(P1 도서/설교). 여기서는 그 유닛의 연결만 '
                         '다룹니다.')).pack(fill='x', padx=14, pady=14)
            return
        tk.Label(host, text='ⓘ ' + gray_why('OWN'), anchor='w',
                 justify='left', wraplength=700).pack(fill='x', padx=14,
                                                      pady=14)

    def _ensure_entity_body(self, host, focus=None):
        """용어 몸통(MyBody) — **한 자리에만 산다.**

        ⚠⚠ Tk 는 위젯을 **다른 부모로 옮겨 pack 할 수 없다**(실측 TclError:
          can't pack … inside …). 그래서 조리대마다 심을 수 없고, 두 벌을
          만들면 한쪽에서 고친 것이 다른 쪽에 안 보인다(갈렙 계열 사고).
          ⇒ **몸통은 「글」 조리대 하나에 두고**, 다른 조리대(연결설명문·고유)
            는 「글 조리대에서 그 탭을 엽니다」로 보낸다 — 자리는 지키되
            길을 알려 준다(회색지대와 같은 문법).
        """
        import entity_overlay
        body = getattr(self, '_ent_body', None)
        if body is not None and body.winfo_exists() and                 str(body.master) != str(host):
            # 다른 조리대에서 부른 것 — 다리만 놓는다
            self._entity_bridge(host, focus)
            return
        if body is None or not body.winfo_exists():
            body = entity_overlay.MyBody(
                host, self.db_path, lambda: self.lang,
                on_changed=lambda _e=None: self.changed('ENTITY'))
            self._ent_body = body
            body.pack(fill='both', expand=True)
        if self.asset_id:
            body.load(self.asset_id)
        if focus:
            self._entity_focus(focus)

    def _entity_focus(self, key):
        body = getattr(self, '_ent_body', None)
        if body is None or not body.winfo_exists():
            return
        try:
            idx = [k for k, _i, _d in body.TABS].index(key)
            body.nb.select(idx)
        except Exception:
            pass

    def _entity_bridge(self, host, focus):
        """용어의 그 기능이 있는 곳으로 보내는 다리."""
        _t = i18n.t
        names = {'VERSE': _t('EBM_T_VERSE', '연결구절'),
                 'ALIAS': _t('EBM_T_ALIAS', '별명'),
                 'DICT': _t('EBM_T_DICT', '사전')}
        tk.Label(host, anchor='w', justify='left', wraplength=700,
                 text='ⓘ ' + _t('ME_ENT_BRIDGE',
                                '용어의 이 기능은 「글」 조리대 안의 '
                                '「{tab}」 탭에 있습니다.').format(
                     tab=names.get(focus, focus))).pack(fill='x', padx=14,
                                                        pady=(14, 6))

        def go():
            self.nb.select(self._decks['TEXT'])
            self.after(60, lambda: self._entity_focus(focus))
        tk.Button(host, text=_t('ME_ENT_GO', '그 탭으로 가기'), bd=1, padx=10,
                  cursor='hand2', command=go).pack(anchor='w', padx=14)

    def changed(self, what='LINK'):
        self._sync_head()
        if callable(self.on_changed):
            try:
                self.on_changed(what)
            except Exception:
                pass
        root = self.master
        hook = getattr(root, '_overlay_center_changed', None)
        if callable(hook):
            try:
                hook(what)
            except Exception:
                pass

    # ── 창 크기 기억 ────────────────────────────────────────
    def _restore_geom(self):
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        saved = None
        try:
            with appdb.connect(self.db_path) as conn:
                r = conn.execute("SELECT config_val FROM user_config "
                                 "WHERE config_key='OC_GEOM'").fetchone()
                saved = r and r[0]
        except Exception:
            pass
        geom = None
        if saved:
            try:
                size, _, pos = saved.partition('+')
                w0, h0 = (int(v) for v in size.split('x'))
                x0, y0 = (int(v) for v in pos.split('+')) if pos else (60, 40)
                geom = '%dx%d+%d+%d' % (w0, h0, max(0, min(x0, sw - 200)),
                                        max(0, min(y0, sh - 200)))
            except Exception:
                geom = None
        if not geom:
            w0 = max(1180, min(sw - 80, 1480))
            h0 = max(680, min(820, sh - 140))
            geom = '%dx%d+%d+%d' % (w0, h0, (sw - w0) // 2,
                                    max(20, (sh - h0) // 2 - 20))
        self.geometry(geom)
        self.minsize(980, 560)
        self._geom_after = None
        self.bind('<Configure>', self._save_geom_later, add='+')

    def _save_geom_later(self, ev=None):
        if ev is not None and ev.widget is not self:
            return
        if self._geom_after:
            try:
                self.after_cancel(self._geom_after)
            except Exception:
                pass
        self._geom_after = self.after(800, self._save_geom)

    def _save_geom(self):
        self._geom_after = None
        try:
            g = self.geometry()
            with appdb.connect(self.db_path) as conn:
                cur = conn.execute("UPDATE user_config SET config_val=? "
                                   "WHERE config_key='OC_GEOM'", (g,))
                if cur.rowcount == 0:
                    conn.execute("INSERT INTO user_config(config_key,"
                                 "config_val) VALUES('OC_GEOM',?)", (g,))
                conn.commit()
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════
#  자가 검증 — 능력표·회색 판정 (화면 없이)
# ══════════════════════════════════════════════════════════════════
def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    # ★ 2026-09-10 — **내 영상이 자산이 되어 열둘**
    t('조리대 6 · 자산 갈래 12', len(DECKS) == 6 and len(KINDS) == 12)
    t('★ 내 영상이 출발지가 된다',
      any(k == 'UMEDIA' for k, _i, _d in KINDS)
      and 'LINK' in ASSET_CAPS['UMEDIA']['decks'])
    t('플랜은 갈래에 없다(사용자 확정)',
      all(k != 'PLAN' for k, _i, _d in KINDS))
    t('★ 갈래 차례 — 성경(구절·단락·흐름) → 용어(용어·태그)',
      [k for k, _i, _d in KINDS][:5]
      == ['VERSE', 'PERICOPE', 'CHAIN', 'ENTITY', 'TAG'],
      [k for k, _i, _d in KINDS][:5])
    t('★ 연결은 **모든 자산**에서 산다',
      all(deck_alive(k, 'LINK') for k, _i, _d in KINDS))
    t('★ 휴지통도 모든 자산', all(deck_alive(k, 'TRASH')
                              for k, _i, _d in KINDS))
    t('★ 구조는 렌즈·노드만',
      deck_alive('LENS', 'BUILD') and deck_alive('NODE', 'BUILD')
      and not deck_alive('VERSE', 'BUILD')
      and not deck_alive('ENTITY', 'BUILD'))
    t('★ 연결설명문 = 구절·용어·노드',
      all(deck_alive(k, 'LDESC') for k in ('VERSE', 'ENTITY', 'NODE'))
      and not deck_alive('TAG', 'LDESC'))
    t('남의 글은 글 조리대가 회색',
      not deck_alive('BOOK_UNIT', 'TEXT')
      and not deck_alive('REF_UNIT', 'TEXT'))
    t('내 연구자료는 글이 산다', deck_alive('USER_REF', 'TEXT'))
    # ★ 2026-08-29 — 구절의 고유(태그·용어)는 **연결 조리대와 겹쳐** 뺐다.
    t('고유 탭 — 용어(별명·사전)·도서(밑줄). 구절은 없다',
      'own' not in ASSET_CAPS['VERSE']
      and not deck_alive('VERSE', 'OWN')
      and ASSET_CAPS['ENTITY']['own'] == ('ALIAS', 'DICT')
      and ASSET_CAPS['BOOK_UNIT']['own'] == ('MARKS',))
    t('★ 고유는 **연결이 아닌 것**만 담는다(별명·사전·밑줄)',
      all('own' not in c or c['own'] for c in ASSET_CAPS.values()))
    t('모르는 자산도 연결·휴지통은 열린다',
      deck_alive('WHATEVER', 'LINK') and deck_alive('WHATEVER', 'TRASH')
      and not deck_alive('WHATEVER', 'TEXT'))
    t('회색 이유가 말이 된다', len(gray_why('BUILD')) > 10
      and '렌즈' in gray_why('BUILD'))
    t('갈래마다 선택기가 정해져 있다',
      all('pick' in ASSET_CAPS[k] for k, _i, _d in KINDS))
    # ★ 회색지대가 **넓지 않은가** (사용자 예측 검증)
    live = sum(len(ASSET_CAPS[k]['decks']) for k, _i, _d in KINDS)
    tot = len(KINDS) * len(DECKS)
    t('회색지대 비율 %d/%d (%.0f%%) — 넓지 않다'
      % (tot - live, tot, (tot - live) * 100.0 / tot),
      (tot - live) * 100.0 / tot < 50)
    print('my_edit selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)
