# -*- coding: utf-8 -*-
"""db_book_entity_link.py — 설교집·도서 단위 ↔ 엔티티 연결 (영구 도구, §0-5 KEEP).

사전·문답 같은 자료집은 `sys_ref_entity_link` 로 엔티티에 붙는다(289건). 그런데
**설교집·도서(`sys_book_unit`, 4,371 단위)에는 붙일 표가 아예 없었다** — `_tag`·`_verse`
는 있는데 `_entity` 가 없어서, 「헤세드를 다룬 설교」를 엔티티에서 찾을 길이 없었다.
이 도구가 그 표를 세우고 후보를 뽑는다.

    python -X utf8 db_book_entity_link.py --init
    python -X utf8 db_book_entity_link.py --cand --book 3 [--min 2] [--out cand.tsv]
    python -X utf8 db_book_entity_link.py --adopt cand.tsv
    python -X utf8 db_book_entity_link.py --status
    python -X utf8 db_book_entity_link.py --selftest

★ **자동은 후보까지만 한다.** 채택은 사람이 한다.
  「헤세드가 나오는 절을 다룬 설교」와 「헤세드를 다룬 설교」는 다르다. 절이 겹친다는
  것만으로 이으면 다바르(1,608절)가 거의 모든 설교에 붙는다. 그래서 `--cand` 는
  TSV 를 뱉기만 하고, 사람이 `채택` 칸에 O 를 적은 것만 `--adopt` 가 넣는다.
"""
import argparse
import io
import os
import sys

# ★★ 구간 판정은 **한 문**이다(§verse_range) — 차례는 `sort_order` 다.
import verse_range as _vr
import appdb

#: ★★ 2026-08-24 — **통합 표로 옮겼다**(`db_link_migrate.py`).
#   `sys_link_asset(link_type='BUNT_ENTI')` 한 행 = 도서 편 ↔ 용어.
#   `link_role` 은 `rel_code` 로, `source` 는 그대로 곁다리 칸에 있다.
#   옛 표 `sys_book_unit_entity` 는 **되돌릴 수 있게 남아 있지만 읽지 않는다.**
TABLE      = 'sys_link_asset'
LINK_TYPE  = 'BUNT_ENTI'
A_COL, B_COL, ROLE_COL = 'clicked_id', 'target_id', 'rel_code'
OLD_TABLE  = 'sys_book_unit_entity'      # 옛 표 — 백업으로만 남는다
#: ⚠⚠ **지운 것(HIDE)을 세면 화면이 거짓말을 한다**(2026-09-07 실측으로
#:   잡았다) — 감사로 걷은 오연결 1건을 HIDE 로 돌렸는데 `--status` 가
#:   그대로 570 을 냈다. **세는 자리마다 상태를 함께 본다.**
WHERE_MINE = ("link_type='%s' AND COALESCE(record_status,'LIVE')='LIVE'"
              % LINK_TYPE)

COLS = ('unit_id', 'entity_id', 'link_role', 'source', '단위', '엔티티', '절겹침', '대표겹침', '제목', '채택')


def init(conn):
    """통합 표는 `db_link_unify.py` 가 맡는다 — 여기서는 세기만 한다.

    ⚠ 옛 표를 새로 만들지 않는다(빈 표가 되살아나면 어느 쪽이 진짜인지 흐려진다).
    """
    return conn.execute('SELECT COUNT(*) FROM %s WHERE %s'
                        % (TABLE, WHERE_MINE)).fetchone()[0]


def _unit_verses(conn, unit_id):
    """그 단위가 다루는 절. 절 목록 표와 start~end 범위를 합친다."""
    # ★ 2026-08-24 — 절 목록을 통합 표로 옮겼다(`BUNT_VERS`).
    #   옛 표 `sys_book_unit_verse` 는 되돌릴 수 있게 남아 있지만 읽지 않는다.
    vs = {r[0] for r in conn.execute(
        "SELECT target_id FROM sys_link_asset"
        " WHERE link_type='BUNT_VERS' AND clicked_id=?"
        " AND COALESCE(record_status,'LIVE')='LIVE'", (unit_id,))}
    r = conn.execute("SELECT start_vid, end_vid FROM sys_book_unit WHERE unit_id=?",
                     (unit_id,)).fetchone()
    if r and r[0]:
        # ⚠⚠⚠ **`verse_id` 는 연속이 아니다 — 같은 책 안일 것을 함께 본다**
        #   (§113차. 2026-09-07 실측으로 이 도구에서 잡았다).
        #   개역한글 절체계 이형 탓에 아6:14 가 vid 31113 이라, 범위만 쓰면
        #   **아6:1~6:14 한 편이 13,498절**이 되어 요한복음까지 덮는다.
        #   실측 그 편 하나에 용어가 **119개** 붙었다.
        #   ⇒ `db_media_range`·`refr_unified_panel` 이 이미 고친 그 병이
        #     여기 남아 있었다. **범위 질의를 새로 쓸 때마다 이 가드를 넣는다.**
        s0, e0 = r[0], (r[1] or r[0])
        b0 = conn.execute("SELECT bcode FROM bible_index WHERE verse_id=?",
                          (s0,)).fetchone()
        if b0:
            vs |= {x[0] for x in conn.execute(
                "SELECT bi.verse_id FROM bible_index bi WHERE "
                + _vr.between_sql('bi.verse_id'),
                _vr.between_args(s0, e0))}
        else:
            vs |= set(range(s0, e0 + 1))
    return vs


_STOP = {'the', 'of', 'and', 'a', 'an', 'in', 'to', 'for', 'on', 'god', 'lord',
         'christ', 'jesus', 'holy', 'spirit', 'man', 'men', 'our', 'his', 'its'}
_NOISE = __import__('re').compile(r'^\s*No\.\s*\d+\s*[—\-–]\s*', __import__('re').I)


def _title_terms(conn):
    """엔티티 → 제목에서 찾을 낱말들. 영문 이름에서 만든다.

    ⚠ 음역·뜻풀이는 한국어라 영문 제목에 못 쓴다(프로오리조 · 카파르). 쓸 수 있는 것은
      `ENTITY_NAME` 의 EN 뿐이다.
    """
    import re
    out = {}
    for eid, en in conn.execute(
            "SELECT clicked_id, contents FROM sys_text_asset"
            " WHERE text_type='ENTITY_NAME' AND lang_code='EN'"
            "   AND COALESCE(record_status,'LIVE')='LIVE'"):
        if not en:
            continue
        terms = set()
        par = re.findall(r'\(([^)]+)\)', en)          # Second Coming (Parousia) → Parousia
        body = re.sub(r'\([^)]*\)', ' ', en).strip()
        body = re.sub(r'^(the|a|an)\s+', '', body, flags=re.I).strip()
        if len(body) >= 4:
            terms.add(body.lower())
        for w in par:
            if len(w) >= 4:
                terms.add(w.strip().lower())
        for w in re.findall(r"[A-Za-z']+", body):
            if len(w) >= 5 and w.lower() not in _STOP:
                terms.add(w.lower())
        if terms:
            out[eid] = sorted(terms, key=len, reverse=True)
    return out


def _title_hit(title, terms):
    """제목에 걸린 낱말 하나(가장 긴 것). 없으면 ''."""
    import re
    t = _NOISE.sub('', title or '').lower()
    for w in terms:
        if re.search(r'\b%s\b' % re.escape(w), t):
            return w
    return ''


def candidates(conn, book_id=None, min_hits=2, limit=400, cat=None):
    """[(unit_id, unit_label, entity_id, entity_name, 절겹침, 대표겹침, 제목)] — 점수순.

    신호가 셋이다.
      절겹침   그 단위가 다루는 절에 그 낱말이 있다        (가장 약하다)
      대표겹침 그 절이 그 엔티티의 **대표 구절**이다        (중간)
      제목     설교·장 제목에 그 엔티티의 영문 이름이 있다   (**가장 강하다**)

    ⚠ 제목이 가장 강한 까닭 — 설교 한 편은 본문이 대개 한 절이라 대표겹침이 나와야
      최대 1이고 변별력이 없다(Spurgeon 3,243건 실측에서 「2 이상」이 0건). 반면 제목은
      그 설교가 무엇을 다루는지 저자가 직접 적어 둔 것이다.
    ⚠ 그래도 **후보까지만** 한다. Peace·Grace 같은 흔한 낱말은 제목에 자주 나온다.
    """
    q = ("SELECT u.unit_id, u.unit_label FROM sys_book_unit u"
         " JOIN sys_book_asset a ON a.book_id=u.book_id"
         " WHERE COALESCE(u.record_status,'LIVE')='LIVE'")
    p = []
    if book_id:
        ids = [int(x) for x in str(book_id).replace(' ', '').split(',') if x]
        q += ' AND u.book_id IN (%s)' % ','.join('?' * len(ids))
        p += ids
    if cat:
        q += ' AND a.book_category=?'
        p.append(cat)
    q += ' ORDER BY u.book_id, u.sequence, u.unit_id'
    names = {r[0]: r[1] for r in conn.execute(
        "SELECT clicked_id, contents FROM sys_text_asset"
        " WHERE text_type='ENTITY_NAME' AND lang_code='KO'")}
    # ★ 2026-08-24 통합 표(`ENTI_VERS`)
    anchored = {r[0] for r in conn.execute(
        "SELECT DISTINCT clicked_id FROM sys_link_asset WHERE link_type='ENTI_VERS'")}
    terms = {k: v for k, v in _title_terms(conn).items() if k in anchored}

    out = []
    for unit_id, label in conn.execute(q, p):
        vs = _unit_verses(conn, unit_id)
        by_verse = {}
        if vs:
            ph = ','.join('?' * len(vs))
            for eid, hits, keys in conn.execute(
                    # ★ 2026-08-24 통합 표(`ENTI_VERS`)
                    "SELECT ev.clicked_id, COUNT(DISTINCT ev.target_id), SUM(ev.is_key)"
                    " FROM sys_link_asset ev"
                    " WHERE ev.link_type='ENTI_VERS' AND ev.target_id IN (%s)"
                    "   AND COALESCE(ev.record_status,'LIVE')='LIVE'"
                    " GROUP BY ev.clicked_id" % ph, tuple(vs)):
                by_verse[eid] = (hits, keys or 0)
        by_title = {eid: w for eid, ws in terms.items()
                    if (w := _title_hit(label, ws))}
        for eid in set(by_verse) | set(by_title):
            hits, keys = by_verse.get(eid, (0, 0))
            term = by_title.get(eid, '')
            if not term and keys < 1 and hits < min_hits:
                continue
            out.append((unit_id, label or '', eid, names.get(eid, str(eid)),
                        hits, keys, term))
    out.sort(key=lambda r: (0 if r[6] else 1, -r[5], -r[4]))
    return out[:limit]


def write_tsv(rows, path):
    with io.open(path, 'w', encoding='utf-8', newline='') as f:
        f.write('\t'.join(COLS) + '\n')
        for unit_id, label, eid, nm, hits, keys, term in rows:
            f.write('\t'.join(str(x) for x in (
                unit_id, eid, 'MENTION', 'AUTO', label[:44], nm, hits, keys, term, '')) + '\n')


def adopt(conn, path):
    """`채택` 칸이 비지 않은 줄만 넣는다. 멱등(같은 짝은 한 번만).

    ⚠⚠ **센 것은 「읽은 줄」이 아니라 「정말 들어간 행」이다**(2026-09-07 실측
      으로 잡았다). SQL 이 `WHERE NOT EXISTS` 라 이미 있으면 안 넣는데 줄
      수를 그대로 세어, **두 번 돌려도 「114건 적재」**라는 거짓 보고가 났다.
      §205차 ⑪ 이 `LP.add` 에서 겪은 그 자리다 — **멱등한 문의 결과는
      반환값이 아니라 실제 변화로 센다.**
    """
    seen = 0
    before = conn.execute("SELECT COUNT(*) FROM %s WHERE %s"
                          % (TABLE, WHERE_MINE)).fetchone()[0]
    with io.open(path, encoding='utf-8') as f:
        head = f.readline().rstrip('\n').split('\t')
        ix = {k: i for i, k in enumerate(head)}
        for line in f:
            if not line.strip():
                continue
            v = line.rstrip('\n').split('\t')
            if not (len(v) > ix['채택'] and v[ix['채택']].strip()):
                continue
            # ⚠ 통합 표의 UNIQUE 는 `rel_code` 까지 본다. 옛 표는 (편, 용어)
            #   짝만 봤으므로, 그냥 넣으면 **역할만 다른 중복**이 생긴다.
            #   ⇒ 짝이 이미 있으면 안 넣는다(옛 동작과 같게).
            conn.execute(
                "INSERT INTO %s(link_type, %s, %s, %s, source, record_status)"
                " SELECT ?,?,?,?,?,'LIVE' WHERE NOT EXISTS ("
                "   SELECT 1 FROM %s WHERE %s AND %s=? AND %s=?)"
                % (TABLE, A_COL, B_COL, ROLE_COL, TABLE, WHERE_MINE, A_COL, B_COL),
                (LINK_TYPE, int(v[ix['unit_id']]), int(v[ix['entity_id']]),
                 (v[ix['link_role']] or 'MENTION').strip(),
                 (v[ix['source']] or 'AUTO').strip(),
                 int(v[ix['unit_id']]), int(v[ix['entity_id']])))
            seen += 1
    conn.commit()
    after = conn.execute("SELECT COUNT(*) FROM %s WHERE %s"
                         % (TABLE, WHERE_MINE)).fetchone()[0]
    return after - before, seen


# ── 화면용 ──────────────────────────────────────────────────────────────────
def fetch_units(conn, entity_id, exclude_books=()):
    """[(unit_id, 라벨, 절수, link_role, book_category)] — 엔티티에 걸린 설교집·도서 단위.

    exclude_books — **사전 갈래로 승격한 책**(overlay_read.BOOK_DICT_SRC)을
    내부연결 목록에서 뺀다(2026-09-03 — 166차 Easton 제외와 같은 원칙:
    같은 자료가 사전 탭과 내부연결 두 곳에 뜨면 안 된다)."""
    try:
        _ex = ''
        args = [entity_id]
        if exclude_books:
            _ex = (" AND a.book_code NOT IN (%s)"
                   % ','.join('?' * len(exclude_books)))
            args += list(exclude_books)
        return conn.execute("""
            SELECT u.unit_id,
                   COALESCE(a.title,'') || CASE WHEN u.unit_label IS NULL OR u.unit_label=''
                        THEN '' ELSE ' · ' || u.unit_label END,
                   -- ⚠ 절 목록은 8행뿐이다. 설교집·도서는 start_vid~end_vid
                   --   범위로만 붙어 있어, 목록만 세면 전부 0 이 된다.
                   -- ★ 2026-08-24 — 목록을 통합 표(BUNT_VERS)로 옮겼다.
                   MAX((SELECT COUNT(*) FROM sys_link_asset bv
                         WHERE bv.link_type='BUNT_VERS' AND bv.clicked_id=u.unit_id
                           AND COALESCE(bv.record_status,'LIVE')='LIVE'),
                       CASE WHEN u.start_vid IS NULL THEN 0
                            ELSE COALESCE(u.end_vid, u.start_vid) - u.start_vid + 1 END),
                   le.rel_code, a.book_category
            -- ★ 2026-08-24 — 통합 표(BUNT_ENTI). link_role 은 rel_code 다.
            FROM sys_link_asset le
            JOIN sys_book_unit  u ON u.unit_id = le.clicked_id
            JOIN sys_book_asset a ON a.book_id = u.book_id
            WHERE le.link_type='BUNT_ENTI' AND le.target_id=?
              AND COALESCE(le.record_status,'LIVE')='LIVE'
              AND COALESCE(u.record_status,'LIVE')='LIVE'
              AND COALESCE(a.record_status,'LIVE')='LIVE'
              {EX}
            ORDER BY CASE le.rel_code WHEN 'SUBJECT' THEN 0 ELSE 1 END,
                     a.book_category, u.sequence, u.unit_id
        """.replace('{EX}', _ex), args).fetchall()
    except Exception:
        return []          # 표가 아직 없으면 조용히 빈 목록 (--init 전)


def status(conn):
    try:
        n = conn.execute('SELECT COUNT(*) FROM %s WHERE %s'
                         % (TABLE, WHERE_MINE)).fetchone()[0]
    except Exception:
        return '표가 없다 — 먼저 db_link_unify --apply'
    e = conn.execute('SELECT COUNT(DISTINCT %s) FROM %s WHERE %s'
                     % (B_COL, TABLE, WHERE_MINE)).fetchone()[0]
    u = conn.execute('SELECT COUNT(DISTINCT %s) FROM %s WHERE %s'
                     % (A_COL, TABLE, WHERE_MINE)).fetchone()[0]
    tot = conn.execute("SELECT COUNT(*) FROM sys_book_unit"
                       " WHERE COALESCE(record_status,'LIVE')='LIVE'").fetchone()[0]
    return '연결 %d건 · 엔티티 %d개 · 단위 %d/%d' % (n, e, u, tot)


def selftest():
    """★ 의무. 여기서 막아야 하는 것은 **자동이 사람 손 없이 들어가는 것**이다."""
    print('db_book_entity_link 자가 검증')
    bad = []
    conn = appdb.connect()
    init(conn)

    # ① 후보는 DB 를 바꾸지 않는다
    cnt = lambda: conn.execute('SELECT COUNT(*) FROM %s WHERE %s'
                               % (TABLE, WHERE_MINE)).fetchone()[0]
    all_cnt = lambda: conn.execute('SELECT COUNT(*) FROM %s' % TABLE).fetchone()[0]
    before, before_all = cnt(), all_cnt()
    candidates(conn, book_id=None, min_hits=2, limit=5)
    if cnt() != before:
        bad.append('--cand 가 DB 를 바꾼다 — 후보는 읽기 전용이어야 한다')

    # ② 채택 칸이 빈 줄은 넣지 않는다
    tmp = '_run/_bue_selftest.tsv'
    os.makedirs('_run', exist_ok=True)
    with io.open(tmp, 'w', encoding='utf-8', newline='') as f:
        f.write('\t'.join(COLS) + '\n')
        f.write('\t'.join(['999999', '999999', 'MENTION', 'AUTO', 'x', 'y', '3', '1', '', '']) + '\n')
    if adopt(conn, tmp)[0] != 0:
        bad.append('채택 표시가 없는 줄을 넣는다')

    # ★★ **범위가 책을 넘지 않는가**(2026-09-07 신설) — 아6:1~6:14 처럼
    #   절체계 이형이 낀 편이 요한복음까지 덮던 것을 실측으로 잡았다.
    row = conn.execute(
        "SELECT u.unit_id, u.start_vid, u.end_vid FROM sys_book_unit u "
        "WHERE u.start_vid IS NOT NULL AND u.end_vid IS NOT NULL "
        "  AND u.end_vid - u.start_vid > 3000 LIMIT 1").fetchone()
    if row:
        vs = _unit_verses(conn, row[0])
        bs = {r[0] for r in conn.execute(
            "SELECT DISTINCT bcode FROM bible_index WHERE verse_id IN (%s)"
            % ','.join('?' * len(vs)), tuple(vs))} if vs else set()
        if len(bs) > 1:
            bad.append('범위가 책을 넘는다 — 편 %d 가 %d권을 덮는다'
                       % (row[0], len(bs)))
        if len(vs) > 500:
            bad.append('범위가 안 잘렸다 — 편 %d 가 %d절' % (row[0], len(vs)))

    # ③ 표시한 줄은 넣고, 두 번 넣어도 하나다
    with io.open(tmp, 'w', encoding='utf-8', newline='') as f:
        f.write('\t'.join(COLS) + '\n')
        f.write('\t'.join(['999999', '999999', 'MENTION', 'AUTO', 'x', 'y', '3', '1', '', 'O']) + '\n')
    n1, _ = adopt(conn, tmp)
    n2, _ = adopt(conn, tmp)
    # ★★ **두 번째는 0 이어야 한다**(2026-09-07 신설) — 그전에는 읽은 줄
    #   수를 세어 **두 번 다 「1건 적재」**라는 거짓 보고를 냈다.
    if not (n1 == 1 and n2 == 0):
        bad.append('멱등 계수가 거짓이다 — 첫 %d · 둘째 %d' % (n1, n2))
    n = conn.execute('SELECT COUNT(*) FROM %s WHERE %s AND %s=999999'
                     % (TABLE, WHERE_MINE, A_COL)).fetchone()[0]
    if n != 1:
        bad.append('멱등이 아니다 — 같은 짝이 %d건' % n)
    conn.execute('DELETE FROM %s WHERE %s AND %s=999999'
                 % (TABLE, WHERE_MINE, A_COL))

    # ④ ★★★ **rel_code 가 달라도 같은 짝이면 하나다**(2026-09-07 신설).
    #   ⚠⚠ 실측으로 잡았다 — 2026-09-01 일괄 적재가 짝 검사를 안 해
    #   `rel_code=NULL` 행을 만들었는데 같은 짝에 `SUBJECT` 행이 이미
    #   있었다. 화면(`link_picker.links_of`)은 rel 을 안 보므로
    #   **같은 용어 이름이 두 번 떴다**(편 175 「구원, 구원, 은혜」).
    #   ★ 통합 표의 UNIQUE 는 rel 까지 보므로 **DB 가 못 막는다** —
    #     그래서 여기서 잰다.
    dup = conn.execute(
        'SELECT COUNT(*) FROM (SELECT %s,%s FROM %s WHERE %s '
        'GROUP BY 1,2 HAVING COUNT(*)>1)'
        % (A_COL, B_COL, TABLE, WHERE_MINE)).fetchone()[0]
    if dup:
        bad.append('같은 짝이 여러 줄 — %d짝 (화면에 이름이 두 번 뜬다)' % dup)
    # 탐지력 — 일부러 rel 만 다른 짝을 넣어 잡히는지 본다.
    # ⚠ `ROLE_COL` 이 곧 `rel_code` 다 — 한 칸을 두 번 적으면 SQL 이 죽는다
    #   (실측으로 잡았다). ⚠ 유일 인덱스가 `COALESCE(rel_code,'')` 라
    #   NULL 과 'SUBJECT' 는 다른 줄로 들어간다 — 그래서 DB 가 못 막는다.
    for rc in ('SUBJECT', None):
        conn.execute('INSERT INTO %s(link_type,%s,%s,%s,record_status)'
                     " VALUES (?,?,?,?,'LIVE')"
                     % (TABLE, A_COL, B_COL, ROLE_COL),
                     (LINK_TYPE, 999998, 999998, rc))
    d2 = conn.execute(
        'SELECT COUNT(*) FROM (SELECT %s,%s FROM %s WHERE %s '
        'GROUP BY 1,2 HAVING COUNT(*)>1)'
        % (A_COL, B_COL, TABLE, WHERE_MINE)).fetchone()[0]
    if d2 != 1:
        bad.append('중복 검사에 탐지력이 없다 — 심었는데 %d' % d2)
    conn.execute('DELETE FROM %s WHERE %s AND %s=999998'
                 % (TABLE, WHERE_MINE, A_COL))
    conn.commit()
    # ⚠ 시험 잔재가 진짜로 사라졌는가 — 그리고 **남의 연결을 안 건드렸는가**
    if conn.execute('SELECT COUNT(*) FROM %s WHERE %s=999999'
                    % (TABLE, A_COL)).fetchone()[0]:
        bad.append('시험 잔재가 남았다')
    if all_cnt() != before_all:
        bad.append('통합 표 전체 행수가 달라졌다 — 남의 연결을 건드렸다')
    os.remove(tmp)

    # ④ 표가 없어도 화면 조회가 죽지 않는다
    if fetch_units(conn, -1) != []:
        bad.append('없는 엔티티에 결과가 나온다')
    conn.close()

    if bad:
        print('SELFTEST FAIL — %d건' % len(bad))
        for m in bad:
            print('  X ' + m)
        return 1
    print('SELFTEST PASS — 4개 항목')
    return 0


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('--init', action='store_true')
    ap.add_argument('--cand', action='store_true')
    ap.add_argument('--book', help='책 번호. 쉼표로 여럿')
    ap.add_argument('--cat', help='book_category (SERMON 등)')
    ap.add_argument('--min', type=int, default=2)
    ap.add_argument('--out', default='_run/book_entity_cand.tsv')
    ap.add_argument('--limit', type=int, default=400)
    ap.add_argument('--adopt')
    ap.add_argument('--status', action='store_true')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    conn = appdb.connect()
    if a.init:
        print('%s 준비 · 현재 %d행' % (TABLE, init(conn)))
    if a.cand:
        init(conn)
        rows = candidates(conn, a.book, a.min, limit=a.limit, cat=a.cat)
        os.makedirs(os.path.dirname(a.out) or '.', exist_ok=True)
        write_tsv(rows, a.out)
        print('후보 %d건 → %s' % (len(rows), a.out))
        print('⚠ 사람이 「채택」 칸에 O 를 적은 줄만 들어간다. 그다음 --adopt %s' % a.out)
    if a.adopt:
        _n, _seen = adopt(conn, a.adopt)
        print('채택 줄 %d · **새로 넣은 것 %d** (나머지는 이미 있었다)'
              % (_seen, _n))
    if a.status or not (a.init or a.cand or a.adopt):
        print(status(conn))
    conn.close()
    return 0


if __name__ == '__main__':
    sys.exit(main())
