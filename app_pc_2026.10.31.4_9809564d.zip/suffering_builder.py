# -*- coding: utf-8 -*-
"""suffering_builder.py — 주제읽기 「성경의 고난」 만들기 창 (2026-10-20 신설 · 시험판).

사용자 지시(docs/1.txt 5-2(5) · 2026-10-20) — 「인물, 고난의 유형, 돌파과정, 결과 등등 각종 구분값을
매트릭스 구조로 선택」 → 「이상적이지만 쉽지 않을 수 있다. 너무 이상적인 것을 추구하면 복잡하고 매칭되는
구절이 별로 없을 수 있다. **몇 가지로 시험하는 것도 좋다**」.

  ⇒ 시험판 = 사건 열다섯(`_POOL`) · 가르는 축 셋(고난의 유형 · 그 뒤 · 성경).
     재료 = docs/성경의 고난.txt 의 유형 체계(A~F) 그대로.

  하루 = ① 고난 본문(CORE) → ② 그 뒤 본문(EXPAND · 성경에 기록된 것만) → ③ 시편 짝(PSA).
  ★★ **결과를 지어내지 않는다** — 성경이 그 사람의 뒷날을 적지 않았으면 「기록 없음」이고
     ② 를 비운다(미가야). 「견딤」은 고난이 걷히지 않았는데 은혜로 버틴 자리(바울의 가시) ·
     「죽음까지」는 그 고난 안에서 생을 마친 자리(스데반)다 — 회복을 꾸며 붙이지 않는다.

  · 저장 = user_bible_plan(origin=SUFFERING_BUILDER 앵커, plan_type SUFFERING) + user_plan_schedule.
    sys 에는 쓰지 않는다(§0-6 C-2). 틀은 세 창과 같은 `builder_shell`.
"""
import json
import tkinter as tk
from tkinter import ttk, messagebox

import i18n
import appdb
import scripture_ref_kr
from plan_builder import FilterRow, check_plan_name, unique_sibling_name, _readable

ANCHOR_CODE = 'SUFFERING_BUILDER'

# 고난의 유형 — docs/성경의 고난.txt §1 의 A~F 그대로
_KINDS = [('ATTACK', '박해·위협'), ('RELATION', '배신·상실·관계'),
          ('BODY', '병·지침·두려움'), ('INJUSTICE', '억울함·누명'),
          ('SPIRIT', '죄책·징계'), ('LONG', '긴 시련·애도')]
# 그 뒤 — 성경이 적은 것만
_ENDS = [('RESTORE', '회복됨'), ('ENDURE', '견디며 지킴'),
         ('DEATH', '죽음까지 신실함'), ('NONE', '기록 없음')]
_TESTS = [('OT', '구약'), ('NT', '신약')]

# (이름, OT/NT, 고난 본문, 그 뒤 본문|None, 시편 짝, 유형들, 그 뒤, 포커스)
_POOL = [
 ('요셉, 형들에게 팔림', 'OT', '창 37:18-28', '창 50:15-21', '시 105:17-19',
  ('RELATION', 'INJUSTICE', 'LONG'), 'RESTORE',
  '구덩이와 종살이 끝에 그는 「당신들은 해하려 하였으나 하나님은 선으로」라고 말합니다.'),
 ('욥, 하루에 모든 것을 잃음', 'OT', '욥 1:13-22', '욥 42:10-17', '시 34:19',
  ('LONG', 'BODY', 'SPIRIT'), 'RESTORE',
  '까닭을 끝내 듣지 못한 고난 속에서도 그는 하나님을 원망하지 않았습니다.'),
 ('나오미, 빈손으로 돌아옴', 'OT', '룻 1:19-21', '룻 4:13-17', '시 30:11',
  ('LONG', 'RELATION'), 'RESTORE',
  '「마라라 부르라」던 사람의 품에 손자가 안깁니다.'),
 ('한나, 아이 없는 세월', 'OT', '삼상 1:4-8', '삼상 1:19-20', '시 113:9',
  ('RELATION', 'LONG'), 'RESTORE',
  '해마다 되풀이된 격동 속에서 그는 사람 대신 하나님 앞에 마음을 쏟았습니다.'),
 ('다윗, 사울에게 쫓김', 'OT', '삼상 23:14-29', '삼하 5:1-5', '시 57:1-3',
  ('ATTACK', 'LONG'), 'RESTORE',
  '굴과 광야를 떠돈 세월이 왕의 자리보다 먼저였습니다.'),
 ('다윗, 아이를 잃음', 'OT', '삼하 12:13-23', '삼하 12:24-25', '시 51:1-4',
  ('SPIRIT', 'RELATION'), 'ENDURE',
  '죄의 열매 앞에서 금식하던 그는 일어나 씻고 경배하러 갑니다.'),
 ('다윗, 아들의 반역', 'OT', '삼하 15:13-30', '삼하 19:8-15', '시 3:1-6',
  ('RELATION', 'ATTACK'), 'RESTORE',
  '맨발로 감람산을 울며 오르던 왕이 「눕고 자고 깨었으니」라고 노래합니다.'),
 ('엘리야, 로뎀나무 아래', 'OT', '왕상 19:1-4', '왕상 19:5-18', '시 34:18',
  ('BODY', 'ATTACK'), 'ENDURE',
  '죽기를 구하는 종을 하나님은 먼저 먹이고 재우신 뒤 다시 보내십니다.'),
 ('미가야, 바른말로 갇힘', 'OT', '왕상 22:24-28', None, '시 31:13-15',
  ('ATTACK', 'INJUSTICE'), 'NONE',
  '뺨을 맞고 고생의 떡을 먹으며 갇혔습니다. 그 뒤는 성경에 적혀 있지 않습니다.'),
 ('예레미야, 구덩이에 빠짐', 'OT', '렘 38:1-13', '렘 39:11-14', '시 40:1-3',
  ('ATTACK', 'INJUSTICE'), 'RESTORE',
  '진흙에 빠진 선지자를 이방 내시가 줄로 끌어올립니다.'),
 ('다니엘, 사자 굴', 'OT', '단 6:10-23', '단 6:25-28', '시 91:11-13',
  ('ATTACK', 'INJUSTICE'), 'RESTORE',
  '알면서도 창문을 열고 하루 세 번 기도한 사람이 굴에 던져집니다.'),
 ('베드로, 세 번 부인함', 'NT', '마 26:69-75', '요 21:15-19', '시 51:10-12',
  ('SPIRIT',), 'RESTORE',
  '심히 통곡한 그 사람에게 주님은 세 번 「내 양을 먹이라」 하십니다.'),
 ('스데반, 돌에 맞음', 'NT', '행 7:54-60', None, '시 31:5',
  ('ATTACK', 'INJUSTICE'), 'DEATH',
  '하늘이 열린 것을 보며 그는 자기를 치는 사람들을 위해 기도하고 잠듭니다.'),
 ('바울과 실라, 빌립보 감옥', 'NT', '행 16:19-24', '행 16:25-34', '시 42:8',
  ('ATTACK', 'INJUSTICE'), 'RESTORE',
  '매 맞고 차꼬에 채워진 밤, 찬송이 먼저였고 옥문은 그다음이었습니다.'),
 ('바울, 육체의 가시', 'NT', '고후 12:7-8', '고후 12:9-10', '시 94:18-19',
  ('BODY',), 'ENDURE',
  '세 번 구했으나 가시는 남고 「내 은혜가 네게 족하다」는 말씀이 남았습니다.'),
]


def anchor_plan_id(conn):
    row = conn.execute("SELECT plan_id FROM sys_bible_plan WHERE plan_code=?",
                       (ANCHOR_CODE,)).fetchone()
    return row[0] if row else None


class SufferingBuilderDialog(tk.Toplevel):
    """주제읽기 「성경의 고난」 만들기 — 기도 창과 같은 틀(`builder_shell`)."""

    def __init__(self, parent, db_path='bible_master.db'):
        super().__init__(parent)
        self.db_path = db_path
        self.created_user_plan_id = None
        self.enroll_now = None
        self.title(i18n.t('SFB_TITLE', '성경의 고난 만들기'))
        self.geometry('1060x640')
        try:
            import ui_theme
            ui_theme.adopt(self)
        except Exception:
            pass
        self._checked = [tk.BooleanVar(value=True) for _ in _POOL]
        self._build()
        self._refresh()

    def _build(self):
        import builder_shell
        self._shell = builder_shell.Shell(self, self._create_plan)
        self._name_var = self._shell.name_var
        ff = self._shell.filters
        self._fr_kind = FilterRow(ff, 0, i18n.t('SFB_KIND', '고난의 유형'),
                                  [k for k, _l in _KINDS], display=dict(_KINDS),
                                  on_change=self._refresh)
        self._fr_end = FilterRow(ff, 1, i18n.t('SFB_END', '그 뒤'),
                                 [k for k, _l in _ENDS], display=dict(_ENDS),
                                 on_change=self._refresh)
        self._fr_test = FilterRow(ff, 2, i18n.t('PRB_TEST', '성경'),
                                  [k for k, _l in _TESTS], display=dict(_TESTS),
                                  on_change=self._refresh)

        lf = ttk.LabelFrame(self._shell.body,
                            text=i18n.t('SFB_LIST', ' 고난 — 눌러서 담기/빼기 · 숫자 = 묵상 일차 '))
        lf.pack(fill='both', expand=True)
        cols = ('day', 'kind', 'ref', 'after', 'end')
        self._tv = ttk.Treeview(lf, columns=cols, show='tree headings', selectmode='browse')
        self._tv.heading('#0', text=i18n.t('COMMON_NAME', '이름'))
        self._tv.column('#0', width=230)
        for cid, key, dflt, w in (('day', 'PRB_DAY', '일차', 46),
                                  ('kind', 'SFB_KIND', '고난의 유형', 190),
                                  ('ref', 'SFB_REF', '고난 본문', 110),
                                  ('after', 'SFB_AFTER', '그 뒤 본문', 110),
                                  ('end', 'SFB_END', '그 뒤', 100)):
            self._tv.heading(cid, text=i18n.t(key, dflt))
            self._tv.column(cid, width=w, anchor='center' if cid != 'kind' else 'w')
        vsb = ttk.Scrollbar(lf, orient='vertical', command=self._tv.yview)
        self._tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        self._tv.pack(fill='both', expand=True, padx=(4, 0), pady=4)
        self._tv.bind('<Button-1>', self._on_click)

    def _visible(self):
        kinds = set(self._fr_kind.get_selected())
        ends = set(self._fr_end.get_selected())
        tests = set(self._fr_test.get_selected())
        out = []
        for i, u in enumerate(_POOL):
            _nm, test, _r, _a, _p, ukinds, end, _f = u
            if test not in tests or end not in ends:
                continue
            if not (set(ukinds) & kinds):          # 여러 유형 — 하나라도 맞으면
                continue
            out.append(i)
        return out

    def _picked(self):
        return [i for i in self._visible() if self._checked[i].get()]

    def _refresh(self):
        tv = self._tv
        tv.delete(*tv.get_children())
        kn, en = dict(_KINDS), dict(_ENDS)
        day = 0
        for i in self._visible():
            nm, _t, ref, after, _p, ukinds, end, _f = _POOL[i]
            on = self._checked[i].get()
            if on:
                day += 1
            tv.insert('', 'end', iid=str(i), text='%s %s' % ('☑' if on else '☐', nm),
                      values=(day if on else '', ' · '.join(kn[k] for k in ukinds),
                              ref, after or '—', en[end]))
        self._shell.set_count(day, day)

    def _on_click(self, ev):
        iid = self._tv.identify_row(ev.y)
        try:
            i = int(iid)
        except (TypeError, ValueError):
            return
        self._checked[i].set(not self._checked[i].get())
        self._refresh()
        return 'break'

    def _create_plan(self):
        picked = self._picked()
        if not picked:
            messagebox.showwarning(i18n.t('COMMON_WARNING', '경고'),
                                   i18n.t('SFB_EMPTY', '담긴 고난이 없습니다.'), parent=self)
            return
        plan_code = _readable(self._name_var.get().strip(), '내 고난 묵상')
        plan_code = check_plan_name(plan_code, self)
        if plan_code is None:
            return
        try:
            uid, days = save_plan(self.db_path, plan_code, picked, {
                'kind': self._fr_kind.get_selected(), 'end': self._fr_end.get_selected(),
                'testament': self._fr_test.get_selected()})
            self._name_var.set(plan_code)
            self.created_user_plan_id = uid
            self.enroll_now = messagebox.askyesno(
                i18n.t('COMMON_DONE', '완료'),
                i18n.t('MSG_PLAN_CREATED_ASK2',
                       '플랜을 만들었습니다 — {code} ({days}일)\n{status}\n\n'
                       '지금 등록할까요?').format(code=plan_code, days=days, status=''),
                parent=self)
            self.destroy()
        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), str(e), parent=self)


def save_plan(db_path, plan_code, picked, flt=None):
    """골라 담은 사건으로 내 플랜을 짓는다 → (user_plan_id, 일수). 화면 밖에서도 부른다(시험)."""
    with appdb.connect(db_path) as conn:
        anchor = anchor_plan_id(conn)
        if not anchor:
            raise RuntimeError('앵커 플랜(SUFFERING_BUILDER)이 없습니다.')
        plan_code = unique_sibling_name(conn, plan_code, anchor)
        bm = scripture_ref_kr.book_map_ko(conn)
        days = len(picked)
        cur = conn.execute(
            "INSERT INTO user_bible_plan (origin_plan_id, plan_code, plan_type, plan_category, "
            "duration_days, track_count, plan_config) VALUES (?, ?, 'SUFFERING', 'THEMATIC', ?, 1, ?)",
            (anchor, plan_code, days, json.dumps({'filter': flt or {}, 'units': picked,
                                                   'total_units': days}, ensure_ascii=False)))
        uid = cur.lastrowid
        for day, i in enumerate(picked, 1):
            nm, _t, ref, after, psa, _k, _e, focus = _POOL[i]
            wk = (day - 1) // 7 + 1
            for so, (r, stage, lvl, foc) in enumerate(
                    ((ref, 'CORE', 'CORE', '%s: %s' % (nm, focus)),
                     (after, 'EXPAND', 'EXPANSION', None),
                     (psa, 'PSA', 'EXPANSION', None)), 1):
                if not r:
                    continue                    # 그 뒤가 기록되지 않았으면 비운다(지어내지 않는다)
                a, b = scripture_ref_kr.resolve(conn, r, bm)
                if a is None:
                    raise RuntimeError('구절 해석 실패: %s' % r)
                conn.execute(
                    "INSERT INTO user_plan_schedule (user_plan_id, week, day, track, start_vid, end_vid, "
                    "stage_type, connection_level, sort_order, meditation_focus, unit_key) "
                    "VALUES (?,?,?,1,?,?,?,?,?,?,?)",
                    (uid, wk, day, a, b, stage, lvl, so, foc, 'SUFF_%d' % i if so == 1 else None))
    return uid, days


def selftest():
    ok = []
    c = appdb.connect()
    bm = scripture_ref_kr.book_map_ko(c)
    bad = [r for u in _POOL for r in (u[2], u[3], u[4]) if r and scripture_ref_kr.resolve(c, r, bm)[0] is None]
    ok.append(('본문 모두 풀린다', not bad))
    ok.append(('「기록 없음」은 그 뒤 본문이 비어 있다',
               all((u[3] is None) == (u[6] in ('NONE', 'DEATH')) for u in _POOL)))
    ok.append(('유형·그 뒤 값이 표 안에 있다',
               all(set(u[5]) <= {k for k, _ in _KINDS} and u[6] in {k for k, _ in _ENDS} for u in _POOL)))
    ok.append(('유형마다 하나 이상', all(any(k in u[5] for u in _POOL) for k, _ in _KINDS)))
    # 지어 보고 되돌린다
    c.execute('SAVEPOINT sf')
    try:
        a = anchor_plan_id(c)
        ok.append(('앵커가 있다', bool(a)))
    finally:
        c.execute('ROLLBACK TO sf'); c.execute('RELEASE sf')
    fails = [m for m, v in ok if not v]
    print('suffering_builder selftest %d/%d' % (len(ok) - len(fails), len(ok)), *fails, *(bad or []))
    return not fails


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        raise SystemExit(0 if selftest() else 1)
    root = tk.Tk()
    root.withdraw()
    dlg = SufferingBuilderDialog(root)
    root.wait_window(dlg)
    root.destroy()
