# -*- coding: utf-8 -*-
"""scripture_ref.py — **다국어 성경 구절 참조 읽기 · 단일 소스** (영구 · 314차 신설)
================================================================================
글 안에 적힌 구절 참조를 찾아 `verse_id` 좌표로 바꾼다. **사용자가 설정한 언어
하나**를 기준으로 읽는다.

★★★ **왜 새로 세웠나 — 읽는 문이 둘로 갈려 있었다.**
  · `scripture_ref_kr` — **한국어 전용**(머리글이 그렇게 적어 두었다)
  · `ref_candidate_detect` — 다국어이되 **RSS 기사 후보 탐지**용이고 아래 ⓐ~ⓒ
    세 가지 흠이 있다
  연구자료 구절 연결(314차 사용자 지시)은 **셋이 함께 쓸 문 하나**가 필요하다
  — 두 벌이 되면 「관리자에서는 걸리는데 사용자 화면에서는 안 걸린다」가 난다
  (§219차 ⑤).

★★★ **언어를 합치지 않는다 — 실측이 그것을 막았다** (314차).
  11언어 이름 1,211개를 한 표로 합치면 **책이 다른 겹침이 둘** 나온다:
      雅  : ZH 야고보서(雅各书) ↔ JA 아가(雅歌)
      Jn  : FR 요한복음(Jean)  ↔ PT 요나(Jonas)
  합치면 **야고보서가 아가로, 요한복음이 요나로** 간다. 사용자 지시
  「**다국어 모드는 성경 버전이 아니라 사용자가 설정한 언어 기준**」이 옳다.
  ⚠ `lang` 은 **역본 언어(`bible_version.lang_code`)가 아니다** — 앱 표시 언어다.

★★★ **USFM 과 100% 일치한다**(사용자 지시) — `USFM` 66줄이 그 표다.
  USFM/USX book ID 는 세계성서공회연합회(UBS)·Paratext 의 **언어 중립** 3글자
  식별자라 **언어가 몇 개로 늘어도 그대로**다(사용자 물음 「11개 언어 이외의
  다른 더 많은 언어에서도 가능해야 한다」의 답 — 아래 §언어 확장).
  ⚠ 실측 우리 `book_names(EN).short_name` 은 66권 중 **62권이 USFM 과
    대소문자만 달랐다**. 누군가 처음 담을 때 USFM 을 따랐고 그 사실이 어디에도
    안 적혀 있었다. 다른 넷도 한 글자 차이(Eze↔EZK · Joe↔JOL · Nah↔NAM ·
    Mar↔MRK)뿐이다.
  ⚠⚠ **그래서 `book_names` 를 고치지 않았다** — 그 칸은 **화면에 보이는
    약명**이고 11언어가 이미 정합하다. USFM 은 **코드 상수**로 둔다:
    국제 표준이라 변하지 않고, 관리자가 고칠 것도 아니며, DB 에 두면
    `SELECT DISTINCT lang_code FROM book_names` 를 쓰는 자리가 'USFM' 을
    언어로 읽는다(실측 그 표의 언어는 11개뿐이다).

★ **고친 흠 셋**(`ref_candidate_detect` 대비)
  ⓐ ⚠⚠⚠ **절 구분자에서 `·` 를 뺐다.** 그쪽은 `[:：·장章절节]` 라
    「출애굽기 21 **·** 레위기 1」의 나열 가운뎃점을 절 구분자로 읽어
    실측에서 `Judges 6 · 1` 이 나왔다. 가운뎃점은 **나열 구분자**다.
  ⓑ **나열을 읽는다** — 「신 15:4, 7; 16:1」 · 「28:8 and 39」(사용자 지시
    「세미콜론 등을 포함해서 읽어야 한다」).
  ⓒ **장만 적힌 참조는 1절만** 낸다(사용자 확정 「장 연결 : 1절만 연결하라」).
    그쪽은 장 전체를 구간으로 냈다 — 실측 946건 중 249건이 그것이고, 그중
    상당수가 「구약 39절 7권에 나온다(출애굽기 21 · 레위기 1 …)」처럼
    **절 개수를 장 번호로 읽은 것**이었다.

★ **변이 사전**(`ALIAS`) — 사람이 글에 쓰는 약명은 화면 약명과 다르다.
  실측 영어 본문에서 `Ex` 18회 · `Judg` 6회 · `1 Samuel` 이 나왔는데 우리
  표의 `Exo`·`Jdg` 는 **한 번도 안 나왔다**. 그래서 **SBL Handbook of Style
  §8.3**(학술 인용 표준)과 흔한 변이를 함께 받는다.
  ⚠ **애매한 변이는 안 넣는다** — 영어 `Jud` 는 Judges(JDG)와 Jude(JUD)
    어느 쪽도 될 수 있다. 조용히 틀리는 것이 안 걸리는 것보다 나쁘다.
  ★★ **316차 — JFB 주석(1871) 약어 체계를 넓혔다.**
    실제 「그 언어로 못 읽힐는 앞말」 9,577자리 가운들 **9,100여가
    영어 주석의 정당한 약어**였다(`Ro` 3,890 · `Mr` 1,660 · `Jo` 1,323 ·
    `Ec` 523 · `Zac` 469 · `Am` 397 · `So` 387 · `Ne` 209 · `Na` 95 · `He` 42).
    ⚠⚠⚠ **고칠 것은 본문이 아니라 사전이었다** — 주석·도서 `ORIGINAL` 은
      남의 원문이라(§0-1b 괜칙 ①) 글자를 고치면 주자 위작이 된다.
      **읽는 쏬을 넓햘다.**
    ⚠ `am`·`he`·`so`·`ne`·`na` 는 영어 낙말이지만 **숫자:숫자가
      바로 따라와야** 매치되고, **본문을 꺼내 읽어** 그 꼴이
      성경 참조만임을 확인했다.
    ⚠⚠ **`at` 은 안 넣었다** — 포르틀어 Atos 이지만 영어에서는
      전치사이고 「at 8:30」(시각)이 그 꼴이다(실제 주석에 0건).
  ⚠ AI 가 쓰는 글에는 변이가 없다(프롬프트가 서식을 못 박는다) — 변이 사전이
    필요한 것은 **사람이 쓴 글과 밖에서 들어온 글**이다.

§언어 확장 — 언어를 하나 더 켜려면
  ① `book_names` 에 그 언어 66행(약명·정식명)  ② `sys_language.is_ui=1`
  **그것으로 끝이다.** USFM 은 언어 중립이라 손댈 것이 없고, `ALIAS` 는
  **비어 있어도 된다**(그 언어 표준 약명만으로 읽는다). `--selftest` 가
  `ui_langs()` 를 돌며 **언어마다 실제로 읽히는지** 재므로, 이름표가 모자라면
  그 자리에서 잡힌다(조용히 0건이 되지 않는다).

쓰는 법
    import scripture_ref as SR
    SR.find(conn, text, lang='KO')        # [(start_vid, end_vid, matched, kind)]
    SR.resolve(conn, '신 15:4', 'KO')     # (start_vid, end_vid)
    SR.usfm_of(5) == 'DEU'
    python scripture_ref.py --selftest
"""
import re
import sys

# ════════════════════════════════════════════════════════════════════
#  USFM / USX book ID — 국제 표준(UBS · Paratext). 색인 = bcode - 1
# ════════════════════════════════════════════════════════════════════
#: ⚠ **고치지 말 것** — 밖에서 정한 표준이다. 우리 `bcode` 와의 대응만 여기 있다.
USFM = (
    'GEN', 'EXO', 'LEV', 'NUM', 'DEU', 'JOS', 'JDG', 'RUT', '1SA', '2SA',
    '1KI', '2KI', '1CH', '2CH', 'EZR', 'NEH', 'EST', 'JOB', 'PSA', 'PRO',
    'ECC', 'SNG', 'ISA', 'JER', 'LAM', 'EZK', 'DAN', 'HOS', 'JOL', 'AMO',
    'OBA', 'JON', 'MIC', 'NAM', 'HAB', 'ZEP', 'HAG', 'ZEC', 'MAL',
    'MAT', 'MRK', 'LUK', 'JHN', 'ACT', 'ROM', '1CO', '2CO', 'GAL', 'EPH',
    'PHP', 'COL', '1TH', '2TH', '1TI', '2TI', 'TIT', 'PHM', 'HEB', 'JAS',
    '1PE', '2PE', '1JN', '2JN', '3JN', 'JUD', 'REV',
)

#: OSIS 책 약어 — 원문 XML(OSHB·SWORD)이 쓴다. 참고용이고 읽기에도 받는다.
#: ⚠ 우리 EN 약명과는 22/66 만 같다(USFM 쪽이 훨씬 가깝다).
OSIS = (
    'Gen', 'Exod', 'Lev', 'Num', 'Deut', 'Josh', 'Judg', 'Ruth', '1Sam', '2Sam',
    '1Kgs', '2Kgs', '1Chr', '2Chr', 'Ezra', 'Neh', 'Esth', 'Job', 'Ps', 'Prov',
    'Eccl', 'Song', 'Isa', 'Jer', 'Lam', 'Ezek', 'Dan', 'Hos', 'Joel', 'Amos',
    'Obad', 'Jonah', 'Mic', 'Nah', 'Hab', 'Zeph', 'Hag', 'Zech', 'Mal',
    'Matt', 'Mark', 'Luke', 'John', 'Acts', 'Rom', '1Cor', '2Cor', 'Gal', 'Eph',
    'Phil', 'Col', '1Thess', '2Thess', '1Tim', '2Tim', 'Titus', 'Phlm', 'Heb',
    'Jas', '1Pet', '2Pet', '1John', '2John', '3John', 'Jude', 'Rev',
)


def usfm_of(bcode):
    """`bcode`(1~66) → USFM 코드. 범위 밖이면 `None`."""
    try:
        b = int(bcode)
    except (TypeError, ValueError):
        return None
    return USFM[b - 1] if 1 <= b <= 66 else None


def bcode_of_usfm(code):
    """USFM 코드(대소문자 무관) → `bcode`. 모르면 `None`."""
    c = (code or '').strip().upper()
    try:
        return USFM.index(c) + 1
    except ValueError:
        return None


def osis_of(bcode):
    """`bcode` → OSIS 약어."""
    try:
        b = int(bcode)
    except (TypeError, ValueError):
        return None
    return OSIS[b - 1] if 1 <= b <= 66 else None


# ════════════════════════════════════════════════════════════════════
#  변이 사전 — 사람이 글에 쓰는 약명
# ════════════════════════════════════════════════════════════════════
#: `{언어: {이름(소문자): bcode}}`. **비어 있어도 된다** — 그 언어 표준
#: 약명·정식명은 `book_names` 에서 온다. 여기 적는 것은 **그 밖의 꼴**이다.
#: ⚠ 애매한 것은 안 넣는다(위 머리글).
ALIAS = {
    # ── 영어 — SBL Handbook of Style §8.3 + 흔한 변이 ───────────────
    #   실측 근거: 본문에 `Ex` 18 · `Judg` 6 · `1 Samuel` 이 나왔다.
    'EN': {
        'gen': 1, 'ge': 1,
        'exod': 2, 'ex': 2,
        'lev': 3, 'lv': 3,
        'num': 4, 'nm': 4, 'nu': 4,
        'deut': 5, 'dt': 5,
        'josh': 6,
        'judg': 7, 'jg': 7,
        'ruth': 8, 'rth': 8,
        '1 sam': 9, '1sam': 9, '1 sm': 9, '1sm': 9,
        '2 sam': 10, '2sam': 10, '2 sm': 10, '2sm': 10,
        '1 kgs': 11, '1kgs': 11, '1 kings': 11, '1kg': 11,
        '2 kgs': 12, '2kgs': 12, '2 kings': 12, '2kg': 12,
        '1 chr': 13, '1chr': 13, '1 chron': 13,
        '2 chr': 14, '2chr': 14, '2 chron': 14,
        'ezra': 15,
        'neh': 16, 'ne': 16,                 # JFB (Ne 3:15)
        'esth': 17, 'est': 17,
        'ps': 19, 'psa': 19, 'psalm': 19, 'psalms': 19, 'pss': 19,
        'prov': 20, 'prv': 20, 'pr': 20,
        'eccl': 21, 'eccles': 21, 'qoh': 21, 'ec': 21,   # JFB (Ec 7:29)
        'song': 22, 'song of songs': 22, 'song of solomon': 22, 'cant': 22,
        'so': 22,                            # JFB (So 5:1)
        'isa': 23, 'is': 23,
        'jer': 24,
        'lam': 25,
        'ezek': 26, 'ezk': 26, 'eze': 26,
        'dan': 27, 'dn': 27,
        'hos': 28,
        'joel': 29, 'joe': 29, 'jol': 29,
        'amos': 30, 'am': 30,                # JFB (Am 6:6)
        'obad': 31, 'ob': 31,
        'jonah': 32, 'jon': 32,
        'mic': 33, 'mi': 33,
        'nah': 34, 'nam': 34, 'na': 34,      # JFB (Na 3:9)
        'hab': 35,
        'zeph': 36, 'zep': 36,
        'hag': 37,
        'zech': 38, 'zec': 38, 'zac': 38,    # old English
        'mal': 39,
        'matt': 40, 'mt': 40,
        'mark': 41, 'mk': 41, 'mar': 41, 'mrk': 41,
        'mr': 41,                            # JFB (Mr 9:49)
        'luke': 42, 'lk': 42, 'luk': 42,
        'john': 43, 'jn': 43, 'joh': 43, 'jhn': 43,
        'acts': 44, 'ac': 44, 'act': 44,
        'rom': 45, 'rm': 45, 'ro': 45,       # JFB (Ro 11:36)
        '1 cor': 46, '1cor': 46, '1 co': 46,
        '2 cor': 47, '2cor': 47, '2 co': 47,
        'gal': 48, 'ga': 48,
        'eph': 49,
        'phil': 50, 'php': 50, 'philip': 50,
        'col': 51,
        '1 thess': 52, '1thess': 52, '1 th': 52, '1 thes': 52,
        '2 thess': 53, '2thess': 53, '2 th': 53, '2 thes': 53,
        '1 tim': 54, '1tim': 54, '1 ti': 54,
        '2 tim': 55, '2tim': 55, '2 ti': 55,
        'titus': 56, 'tit': 56,
        'phlm': 57, 'philem': 57, 'phm': 57,
        'heb': 58, 'he': 58,                 # JFB (He 1:14)
        'jas': 59, 'jam': 59, 'james': 59,
        '1 pet': 60, '1pet': 60, '1 pe': 60, '1 pt': 60,
        '2 pet': 61, '2pet': 61, '2 pe': 61, '2 pt': 61,
        # JFB: 1 Jo / 2 Jo / 3 Jo  (not bare 'Jo' - ambiguous with
        #   John / Joel / Jonah / Job. The Gospel uses 'Joh'.)
        '1 john': 62, '1john': 62, '1 jn': 62, '1jo': 62,
        '2 john': 63, '2john': 63, '2 jn': 63, '2jo': 63,
        '3 john': 64, '3john': 64, '3 jn': 64, '3jo': 64,
        'jude': 65,
        'rev': 66, 'rv': 66, 'revelation': 66,
    },
    # ── 독일어 — Loccumer Richtlinien(공동 표기)도 함께 받는다 ────────
    #   표준 약명은 `1Mo`·`5Mo` 꼴인데 가톨릭·공동번역은 `Gen`·`Ex` 를 쓴다.
    'DE': {
        'gen': 1, 'ex': 2, 'lev': 3, 'num': 4, 'dtn': 5, 'dt': 5,
        'jos': 6, 'ri': 7, 'rut': 8,
        '1 sam': 9, '2 sam': 10, '1 kön': 11, '2 kön': 12,
        '1 chr': 13, '2 chr': 14, 'esra': 15, 'neh': 16, 'est': 17,
        'ijob': 18, 'hiob': 18, 'ps': 19, 'spr': 20, 'koh': 21, 'hld': 22,
        'jes': 23, 'jer': 24, 'klgl': 25, 'ez': 26, 'dan': 27,
        'hos': 28, 'joël': 29, 'am': 30, 'obd': 31, 'jona': 32, 'mi': 33,
        'nah': 34, 'hab': 35, 'zef': 36, 'hag': 37, 'sach': 38, 'mal': 39,
        'mt': 40, 'mk': 41, 'lk': 42, 'joh': 43, 'apg': 44, 'röm': 45,
        '1 kor': 46, '2 kor': 47, 'gal': 48, 'eph': 49, 'phil': 50,
        'kol': 51, '1 thess': 52, '2 thess': 53, '1 tim': 54, '2 tim': 55,
        'tit': 56, 'phlm': 57, 'hebr': 58, 'jak': 59,
        '1 petr': 60, '2 petr': 61, '1 joh': 62, '2 joh': 63, '3 joh': 64,
        'jud': 65, 'offb': 66, 'apk': 66,
    },
}

# ════════════════════════════════════════════════════════════════════
#  정규식 — 언어 중립 뼈대
# ════════════════════════════════════════════════════════════════════
#: 아라비아-인도 숫자(아랍어 ٠-٩)도 받는다 — 실측 0건이지만 아랍어 글에 쓰인다.
_D = r'[0-9٠-٩]'
_AR0 = 0x0660

#: 절 구분자. ⚠⚠⚠ **가운뎃점(`·`)을 넣지 않는다** — 그것은 **나열 구분자**다
#:   (실측 `ref_candidate_detect` 가 「Judges 6 · 1」을 읽었다).
#: ⚠ 마침표(`Gen 1.1`)도 안 받는다 — 판 번호·소수와 구분할 수 없다.
_SEP = r'(?:[:：]|장\s*|편\s*|章\s*|篇\s*)'      # : ： 장 편 章 篇
#: ★ 2026-10-13 docs/1.txt 84-2 — 시편은 「장」 대신 「편」을 쓴다(「시편 23편 1절」 → 23:1).
#:   그전에는 「편」을 몰라 23편 통째(장)로 읽었다.
_VTAIL = r'(?:\s*[절節节])?'                      # 「43절」의 꼬리
_DASH = r'[-–—~〜]'
#: 나열을 잇는 글자 — 사용자 지시 「세미콜론 등을 포함해서」
#: ⚠ **언어의 성질이 다르므로 갈라 적는다** — 한국어 조사(와·과·및)는 숫자에
#:   **붙어 쓴다**(「신 15:4과 7」). 영어 `and` 는 낱말이라 공백이 필요하다.
_JOIN = r'(?:[,;；，]|\s*(?:\uc640|\uacfc|\ubc0f)\s*|\s+and\s+)'


def _ar2a(s):
    """아랍어 숫자를 아라비아 숫자로. 다른 글자는 그대로."""
    out = []
    for ch in s or '':
        o = ord(ch)
        out.append(chr(o - _AR0 + 48) if _AR0 <= o <= _AR0 + 9 else ch)
    return ''.join(out)


def _i(s):
    """숫자 글자 → int (아랍어 숫자 포함). 못 읽으면 `None`."""
    try:
        return int(_ar2a(s))
    except (TypeError, ValueError):
        return None


def _npat(name):
    """책 이름 → 정규식 조각.

    ★ **공백과 숫자 경계를 느슨하게** 받는다 — 실측 우리 표는 `1Sa`(붙여 씀)인데
      본문은 `1 Samuel`·`1 Sa`(띄어 씀)다. 그대로 쓰면 정규식이 `Sa` 부터 집고
      **앞 숫자를 버려** 사무엘상·하가 구분되지 않는다(실측 `Sa` 16회).
    ⚠ 글자 사이를 전부 느슨하게 하지 않는다 — 「G e n」이 걸린다.
    """
    out, prev = [], ''
    for ch in name:
        if ch.isspace():
            if out and not out[-1].endswith(r'\s*'):
                out.append(r'\s*')
            prev = ' '
            continue
        if prev and prev != ' ':
            if prev.isdigit() != ch.isdigit() or prev == '.':
                out.append(r'\s*')
        out.append(re.escape(ch))
        prev = ch
    return ''.join(out)


_PAT_CACHE = {}

#: 책 이름 사전의 **열쇠 꼴**. ⚠⚠⚠ 만들 때와 물을 때 반드시 이 한 문을 쓴다 —
#:   `_npat` 이 공백을 느슨하게 받으므로(「1Sa」 ↔ 「1 Sa」) 맞힌 글자를 그대로
#:   물으면 조용히 실패한다(실측으로 당했다 · 오류도 안 난다).
#: ⚠ 점도 걷는다 — 「Gen.」·「1. Mose」.
def _nk(name):
    return ''.join(ch for ch in (name or '').lower()
                   if not ch.isspace() and ch != '.')


def book_map(conn, lang):
    """`{이름(소문자): bcode}` — **그 언어 하나** + USFM + OSIS + `ALIAS[언어]`.

    ⚠⚠⚠ **언어를 합치지 않는다** — 실측 겹침 둘(雅 · Jn · 위 머리글).
    ⚠ 차례가 뜻을 갖는다 — **그 언어의 표준 약명이 마지막에 이긴다**. 변이
      사전이 표준 약명을 덮으면 화면과 읽기가 갈린다.
    """
    lg = (lang or 'KO').upper()
    m = {}
    for code in USFM:                                 # 언어 중립 식별자
        m[_nk(code)] = bcode_of_usfm(code)
    for i, nm in enumerate(OSIS):                     # 원문 XML 약어
        m.setdefault(_nk(nm), i + 1)
    for nm, bc in (ALIAS.get(lg) or {}).items():      # 그 언어 변이
        m[_nk(nm)] = bc
    rows = conn.execute(
        "SELECT book_code, full_name, short_name FROM book_names "
        "WHERE lang_code=?", (lg,)).fetchall()
    for bc, full, short in rows:                      # ★ 표준 약명이 이긴다
        for nm in (full, short):
            nm = (nm or '').strip()
            if nm:
                m[_nk(nm)] = bc
    return m


def book_names_raw(conn, lang):
    """정규식에 넣을 **원래 글자** 이름 목록(공백·점이 살아 있다).

    ⚠ `book_map` 의 열쇠는 정규화된 꼴이라 정규식에 그대로 쓰면 「1 Samuel」의
      공백을 표현할 수 없다. 그래서 둘을 갈라 둔다.
    """
    lg = (lang or 'KO').upper()
    out = set(USFM) | set(OSIS) | set(ALIAS.get(lg) or {})
    for _bc, full, short in conn.execute(
            "SELECT book_code, full_name, short_name FROM book_names "
            "WHERE lang_code=?", (lg,)).fetchall():
        for nm in (full, short):
            if (nm or '').strip():
                out.add(nm.strip())
    return sorted(out)


def _pattern(names):
    """이름 목록 → 참조 정규식. **긴 이름 우선**(요한복음 > 요한 > 요)."""
    key = tuple(sorted(names, key=lambda s: (-len(s), s)))
    got = _PAT_CACHE.get(key)
    if got is not None:
        return got
    alt = '|'.join(_npat(n) for n in key)
    rx = re.compile(
        r'(?P<bk>' + alt + r')\s*\.?\s*'
        r'(?P<ch>' + _D + r'{1,3})'
        r'(?:'
        #  ① 장:절 [ ~ (장:)절 ]
        r'\s*' + _SEP + r'\s*(?P<v1>' + _D + r'{1,3})' + _VTAIL +
        r'(?:\s*' + _DASH + r'\s*(?:(?P<ch2>' + _D + r'{1,3})\s*' + _SEP +
        r'\s*)?(?P<v2>' + _D + r'{1,3})' + _VTAIL + r')?'
        #  ② 장만 — 「레위기 21장」 (꼬리 「장」이 있고 뒤에 숫자가 없다)
        r'|\s*(?:장|편|章|篇)(?!\s*' + _D + r')'
        #  ③ 장 범위 — 「마 5-7」·「마 5-7장」
        r'|\s*' + _DASH + r'\s*(?P<chr2>' + _D + r'{1,3})\s*(?:장|편|章|篇)?'
        r')?',
        re.IGNORECASE)
    _PAT_CACHE[key] = rx
    return rx


#: 나열 꼬리 — 「, 7」 · 「; 16:1」 · 「 and 39」
_TAIL = re.compile(
    _JOIN + r'\s*(?:(?P<ch>' + _D + r'{1,3})\s*' + _SEP + r'\s*)?'
    r'(?P<v1>' + _D + r'{1,3})' + _VTAIL +
    r'(?:\s*' + _DASH + r'\s*(?P<v2>' + _D + r'{1,3})' + _VTAIL + r')?',
    re.IGNORECASE)


# ════════════════════════════════════════════════════════════════════
#  좌표 풀기
# ════════════════════════════════════════════════════════════════════
def _vid(conn, bcode, ch, vs):
    r = conn.execute(
        "SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?",
        (bcode, ch, vs)).fetchone()
    return r[0] if r else None


def _chap_first(conn, bcode, ch):
    """그 장의 **첫 절** verse_id. ★ 장만 적힌 참조는 이것 하나만 낸다."""
    r = conn.execute(
        "SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? "
        "ORDER BY verse LIMIT 1", (bcode, ch)).fetchone()
    return r[0] if r else None


def _chap_last(conn, bcode, ch):
    r = conn.execute(
        "SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? "
        "ORDER BY verse DESC LIMIT 1", (bcode, ch)).fetchone()
    return r[0] if r else None


#: `kind` — 화면이 「무엇을 읽었나」를 사람 말로 말할 수 있게 한다.
KIND_VERSE = 'VERSE'        # 「신 15:4」 한 절
KIND_RANGE = 'RANGE'        # 「신 15:4-7」 절 구간
KIND_CHAPTER = 'CHAPTER'    # 「레위기 21장」 → **그 장 1절만**
KIND_LIST = 'LIST'          # 나열에서 온 것 — 「신 15:4, 7」의 7
KIND_LABEL = {
    KIND_VERSE: '구절',
    KIND_RANGE: '구절 구간',
    KIND_CHAPTER: '장만 적혀 1절만',
    KIND_LIST: '이어 적은 구절',
}


def linkable(rows):
    """연결에 쓸 것만 — **장·편만 적힌 참조는 아예 연결하지 않는다**(2026-10-13 docs/1.txt 84-2 사용자 확정).
    ★ 자동 연결·추천 줄·AI 적재가 모두 이 문을 지난다(두 벌이면 갈린다)."""
    return [r for r in (rows or []) if r[3] != KIND_CHAPTER]


def find(conn, text, lang='KO', limit=200):
    """글에서 구절 참조를 찾는다 → `[(start_vid, end_vid, matched, kind)]`.

    `lang` = **사용자가 설정한 앱 언어**(역본 언어가 아니다).
    같은 좌표가 여러 번 나오면 **한 번만** 낸다(먼저 나온 것이 남는다).
    """
    if not text:
        return []
    bm = book_map(conn, lang)
    if not bm:
        return []
    rx = _pattern(book_names_raw(conn, lang))
    out, seen = [], set()

    def _add(s, e, matched, kind):
        if s is None or e is None:
            return False
        if e < s:
            s, e = e, s
        if (s, e) in seen:
            return False
        seen.add((s, e))
        out.append((s, e, (matched or '').strip(), kind))
        return True

    for mt in rx.finditer(text):
        bc = bm.get(_nk(mt.group('bk')))        # ★ 같은 문으로 묻는다
        if not bc:
            continue
        ch = _i(mt.group('ch'))
        if not ch:
            continue
        v1, v2 = mt.group('v1'), mt.group('v2')
        ch2, chr2 = mt.group('ch2'), mt.group('chr2')
        if v1:                                        # ① 절이 있다
            a = _i(v1)
            s = _vid(conn, bc, ch, a)
            if s is None:
                continue
            if v2:
                ec = _i(ch2) if ch2 else ch
                e = _vid(conn, bc, ec, _i(v2))
                if e is None:                         # 끝 절이 없으면 장 끝까지
                    e = _chap_last(conn, bc, ec)
                _add(s, e or s, mt.group(0), KIND_RANGE)
            else:
                _add(s, s, mt.group(0), KIND_VERSE)
            # ── 나열 꼬리 — 「, 7」·「; 16:1」 ─────────────────────
            pos, cur = mt.end(), ch
            while len(out) < limit:
                tm = _TAIL.match(text, pos)
                if not tm:
                    break
                tch = _i(tm.group('ch'))
                if tch:
                    cur = tch
                ta = _i(tm.group('v1'))
                ts = _vid(conn, bc, cur, ta) if ta else None
                if ts is None:
                    break                             # 숫자가 절이 아니면 멈춘다
                tb = _i(tm.group('v2'))
                te = _vid(conn, bc, cur, tb) if tb else ts
                _add(ts, te or ts, tm.group(0), KIND_LIST)
                pos = tm.end()
        elif chr2:                                    # ③ 장 범위 — 시작 장 1절만
            #  ⚠ 「마 5-7장」을 구간으로 내지 않는다 — 사용자 확정
            s = _chap_first(conn, bc, ch)
            _add(s, s, mt.group(0), KIND_CHAPTER)
        else:                                         # ② 장만 — 1절만
            s = _chap_first(conn, bc, ch)
            _add(s, s, mt.group(0), KIND_CHAPTER)
        if len(out) >= limit:
            break
    return out[:limit]


def bad_refs(conn, text, lang='KO'):
    """글에 적힌 **없는 장·절** — `[(matched, 그 자리 시작 글자 번호)]`.

    ★ 2026-10-15 AI 답 검증 — `find` 는 없는 절을 **조용히 건너뛴다**(연결에는 그것이 옳다).
      AI 답에서는 그것이 곧 지어낸 참조이므로 따로 낸다. 책 이름이 이 언어 표에 있고
      장 또는 절이 그 책에 없을 때만 — 책 이름이 아닌 낱말은 건드리지 않는다.
    """
    if not text:
        return []
    bm = book_map(conn, lang)
    if not bm:
        return []
    rx = _pattern(book_names_raw(conn, lang))
    out = []
    for mt in rx.finditer(text):
        bc = bm.get(_nk(mt.group('bk')))
        ch = _i(mt.group('ch'))
        if not bc or not ch:
            continue
        #  ⚠ 낱말 꼬리에 붙은 책 이름은 참조가 아니다 — 「특히 28」의 「히」(실측으로 잡았다)
        if mt.start() > 0 and text[mt.start() - 1].isalpha():
            continue
        v1 = mt.group('v1')
        if v1:
            bad = _vid(conn, bc, ch, _i(v1)) is None
        elif mt.group(0).rstrip()[-1:] in ('장', '편', '章', '篇'):
            bad = _chap_first(conn, bc, ch) is None
        else:
            continue                                  # 「요 3」 같은 맨 숫자는 참조라 단정하지 않는다
        if bad:
            out.append((mt.group(0).strip(), mt.start()))
    return out


def resolve(conn, ref, lang='KO'):
    """참조 **하나**를 푼다 → `(start_vid, end_vid)`. 실패는 `(None, None)`.

    ⚠ 실패가 `None` 이 아니라 **`(None, None)`** 이다(`scripture_ref_kr` 와 같은
      계약 — §21-4. 바꾸면 그것을 쓰는 자리가 조용히 깨진다).
    """
    got = find(conn, ref, lang, limit=1)
    return (got[0][0], got[0][1]) if got else (None, None)


def label(conn, start_vid, end_vid=None, lang='KO'):
    """좌표 → 그 언어 약명 이름표. 구간 이름표는 `db_media_range.span_label`
    단일 소스를 쓴다 — 여기서 또 짓지 않는다."""
    try:
        import db_media_range as MR
        return MR.span_label(conn, start_vid, end_vid or start_vid, lang)
    except Exception:                                 # noqa: BLE001
        r = conn.execute("SELECT bcode, chapter, verse FROM bible_index "
                         "WHERE verse_id=?", (start_vid,)).fetchone()
        if not r:
            return ''
        nm = conn.execute("SELECT short_name FROM book_names "
                          "WHERE lang_code=? AND book_code=?",
                          ((lang or 'KO').upper(), r[0])).fetchone()
        return '%s %d:%d' % ((nm[0] if nm else usfm_of(r[0])), r[1], r[2])


# ════════════════════════════════════════════════════════════════════
#  자가 검증
# ════════════════════════════════════════════════════════════════════
def selftest():                                       # noqa: C901
    import appdb
    import lang_config
    conn = appdb.connect()
    ok = fail = 0
    msgs = []

    def ck(cond, what, got=''):
        nonlocal ok, fail
        if cond:
            ok += 1
        else:
            fail += 1
            msgs.append('FAIL %s %s' % (what, ('→ ' + str(got)) if got else ''))

    # ── ① USFM 표가 100% 맞는가 ───────────────────────────────────
    ck(len(USFM) == 66, 'USFM 66줄', len(USFM))
    ck(len(set(USFM)) == 66, 'USFM 겹침 0')
    ck(len(OSIS) == 66, 'OSIS 66줄', len(OSIS))
    ck(usfm_of(1) == 'GEN' and usfm_of(5) == 'DEU' and usfm_of(66) == 'REV',
       'usfm_of 보기')
    ck(usfm_of(0) is None and usfm_of(67) is None, 'usfm_of 범위 밖 None')
    ck(bcode_of_usfm('deu') == 5 and bcode_of_usfm('1SA') == 9,
       'bcode_of_usfm 대소문자 무관')
    ck(bcode_of_usfm('ZZZ') is None, '모르는 USFM 은 None')
    ck(all(bcode_of_usfm(usfm_of(b)) == b for b in range(1, 67)),
       'USFM 왕복 66권')
    ck(osis_of(19) == 'Ps', 'osis_of 보기', osis_of(19))
    # DB 의 책이 66권인가
    n66 = conn.execute("SELECT COUNT(DISTINCT bcode) FROM bible_index").fetchone()[0]
    ck(n66 == 66, 'bible_index 책 66권', n66)

    # ── ①-2 **USFM 이 표준과 100% 맞는가** (사용자 지시) ───────────
    #   ⚠⚠⚠ 보기 셋과 왕복만 재면 **값을 틀려도 통과한다**(실측으로 당했다).
    #     표준 목록을 두 번 적지 않고 **독립 잣대 셋**으로 잰다.
    #   ⓐ 꼴 규칙 — 세 글자 · 대문자·숫자 · 숫자로 시작하면 1·2·3
    bad_form = [c for c in USFM
                if len(c) != 3 or not c.isalnum() or c != c.upper()
                or (c[0].isdigit() and c[0] not in '123')
                or any(ch.isdigit() for ch in c[1:])]
    ck(not bad_form, 'USFM 꼴 규칙(3글자·대문자·숫자는 앞에만)', bad_form)
    #   ⓑ ★ **DB 의 EN 약명과 대조** — 우리 표와 독립된 재료다.
    #     실측 62/66 이 같고 다른 넷이 EZK·JOL·NAM·MRK 다.
    EN_DIFF = {26: 'EZK', 29: 'JOL', 34: 'NAM', 41: 'MRK'}
    en = {bc: (sn or '').strip().upper() for bc, sn in conn.execute(
        "SELECT book_code, short_name FROM book_names WHERE lang_code='EN'")}
    same = [b for b in range(1, 67) if en.get(b) == USFM[b - 1]]
    diff = {b: USFM[b - 1] for b in range(1, 67) if en.get(b) != USFM[b - 1]}
    ck(len(same) == 62, 'USFM ↔ EN 약명 같은 것 62권', len(same))
    ck(diff == EN_DIFF, 'USFM ↔ EN 약명 다른 넷이 못 박힌 그대로', diff)
    #   ⓒ 숫자 접두 17권 — 성경이 정한 수다
    numbered = [c for c in USFM if c[0].isdigit()]
    ck(len(numbered) == 17, '숫자 접두 책 17권', len(numbered))
    #     상·하가 짝을 이루는가 (요한서신만 1·2·3)
    stems = {}
    for c in numbered:
        stems.setdefault(c[1:], []).append(c[0])
    ck(all(sorted(v) == ['1', '2'] or sorted(v) == ['1', '2', '3']
           for v in stems.values()), '숫자 접두가 1·2(·3) 짝', stems)
    #   ⓓ 차례 — 신약 첫 책(마태)이 40번
    ck(USFM[39] == 'MAT' and USFM[38] == 'MAL',
       '구약 39권 · 신약 첫 책이 40번', (USFM[38], USFM[39]))

    # ── ② 언어마다 실제로 읽히는가 (★ 조용히 0건이 되지 않게) ──────
    LANGS = list(lang_config.ui_langs())
    ck(len(LANGS) >= 11, 'UI 언어 11개 이상', len(LANGS))
    for lg in LANGS:
        bm = book_map(conn, lg)
        ck(len(bm) >= 66, '%s 이름표 66개 이상' % lg, len(bm))
        # 그 언어의 실제 약명으로 지은 글에서 좌표가 나오는가
        row = conn.execute(
            "SELECT short_name, full_name FROM book_names "
            "WHERE lang_code=? AND book_code=5", (lg,)).fetchone()
        sn = (row[0] or '').strip() if row else ''
        fn = (row[1] or '').strip() if row else ''
        want = _vid(conn, 5, 15, 4)
        for nm, tag in ((sn, '약명'), (fn, '정식명')):
            if not nm:
                continue
            got = find(conn, '그래서 %s 15:4 를 보면 분명합니다.' % nm, lg)
            ck(got and got[0][0] == want,
               '%s %s 「%s 15:4」' % (lg, tag, nm), got[:1])
        # USFM 은 어느 언어에서나 읽힌다
        got = find(conn, 'DEU 15:4', lg)
        ck(got and got[0][0] == want, '%s 에서 USFM 읽기' % lg, got[:1])

    # ── ③ 언어를 섞지 않는가 (실측 겹침 둘을 재현) ─────────────────
    #   雅 : ZH 야고보서(59) ↔ JA 아가(22)
    g_zh = find(conn, '雅 1:2', 'ZH')
    g_ja = find(conn, '雅 1:2', 'JA')
    b_zh = conn.execute("SELECT bcode FROM bible_index WHERE verse_id=?",
                        (g_zh[0][0],)).fetchone()[0] if g_zh else None
    b_ja = conn.execute("SELECT bcode FROM bible_index WHERE verse_id=?",
                        (g_ja[0][0],)).fetchone()[0] if g_ja else None
    ck(b_zh == 59, 'ZH 「雅」는 야고보서', b_zh)
    ck(b_ja == 22, 'JA 「雅」는 아가', b_ja)
    ck(b_zh != b_ja, '언어가 다르면 다른 책 — 합치지 않았다')
    #   ★ 공백·점을 걷어도 한 언어 안에서 겹치지 않는가
    for lg in LANGS:
        seen, dup = {}, []
        for nm in book_names_raw(conn, lg):
            k = _nk(nm)
            bc = book_map(conn, lg).get(k)
            if k in seen and seen[k] != bc:
                dup.append(nm)
            seen[k] = bc
        ck(not dup, '%s 정규화 뒤 겹침 0' % lg, dup[:4])

    # ── ④ 표기 꼴 — 사용자 지시(세미콜론 등) ──────────────────────
    v = lambda b, c, s: _vid(conn, b, c, s)           # noqa: E731
    cases = [
        ('신 15:4', [(v(5, 15, 4), v(5, 15, 4))], '한 절'),
        ('신 15:4-7', [(v(5, 15, 4), v(5, 15, 7))], '절 구간'),
        ('신 15:4~7', [(v(5, 15, 4), v(5, 15, 7))], '물결 구간'),
        ('신명기 15장 4절', [(v(5, 15, 4), v(5, 15, 4))], '장 절 꼬리말'),
        ('신 15:4, 7', [(v(5, 15, 4), v(5, 15, 4)),
                        (v(5, 15, 7), v(5, 15, 7))], '쉼표 나열'),
        ('신 15:4; 16:1', [(v(5, 15, 4), v(5, 15, 4)),
                           (v(5, 16, 1), v(5, 16, 1))], '세미콜론 나열'),
        ('신 15:4; 마 7:7', [(v(5, 15, 4), v(5, 15, 4)),
                            (v(40, 7, 7), v(40, 7, 7))], '세미콜론+책명'),
        ('신 15:4-16:2', [(v(5, 15, 4), v(5, 16, 2))], '장 넘는 구간'),
        ('신 15:4 and 7', [(v(5, 15, 4), v(5, 15, 4)),
                           (v(5, 15, 7), v(5, 15, 7))], 'and 이어쓰기'),
        ('신 15:4과 7', [(v(5, 15, 4), v(5, 15, 4)),
                        (v(5, 15, 7), v(5, 15, 7))], '과 이어쓰기'),
        ('시편 23편 1절', [(v(19, 23, 1), v(19, 23, 1))], '편 절 꼬리말(84-2)'),
        ('시편 23편 1-3절', [(v(19, 23, 1), v(19, 23, 3))], '편 절 구간(84-2)'),
    ]
    for txt, want, nm in cases:
        got = [(a, b) for a, b, _m, _k in find(conn, txt, 'KO')]
        ck(got == want, '꼴 — %s 「%s」' % (nm, txt), got)

    # ── ⑤ 장만 적힌 참조는 **1절만** (사용자 확정) ────────────────
    got = find(conn, '레위기 21장의 규정', 'KO')
    ck(len(got) == 1 and got[0][0] == v(3, 21, 1) and got[0][1] == got[0][0]
       and got[0][3] == KIND_CHAPTER, '장만 → 1절만', got)
    got = find(conn, 'Leviticus 21', 'EN')
    ck(len(got) == 1 and got[0][0] == v(3, 21, 1) and got[0][1] == got[0][0],
       'EN 장만 → 1절만', got)
    got = find(conn, '마 5-7장', 'KO')
    ck(len(got) == 1 and got[0][0] == v(40, 5, 1) and got[0][1] == got[0][0],
       '장 범위도 시작 장 1절만', got)
    got = find(conn, '시편 1편은', 'KO')
    ck(len(got) == 1 and got[0][3] == KIND_CHAPTER, '「편」만 → 장만 적힌 참조', got)
    ck(linkable(got) == [] and len(linkable(find(conn, '시 1:1', 'KO'))) == 1,
       '★ 84-2 장·편만 적힌 참조는 연결하지 않는다 · 절은 연결한다')
    #   ⚠ 양방향 — 구간으로 내면 그 자리에서 잡힌다
    ck(_chap_last(conn, 3, 21) != _chap_first(conn, 3, 21),
       '그 장에 절이 둘 이상(잣대가 뜻을 갖는다)')

    # ── ⑥ 영어 변이 — 실측에서 나온 것들 ─────────────────────────
    for txt, want_b in (('Ex 25:40', 2), ('Judg 6:1', 7), ('1 Samuel 6:14', 9),
                        ('1 Sa 6:14', 9), ('2 Chron 7:14', 14),
                        ('Matt 7:7', 40), ('Exod 25:40', 2), ('Ps 23:1', 19)):
        got = find(conn, txt, 'EN')
        b = conn.execute("SELECT bcode FROM bible_index WHERE verse_id=?",
                         (got[0][0],)).fetchone()[0] if got else None
        ck(b == want_b, 'EN 변이 「%s」' % txt, b)
    #   ★ 숫자 책에서 숫자가 떨어지지 않는가 (실측 `Sa` 16회의 자리)
    g1 = find(conn, '1 Samuel 6:14', 'EN')
    g2 = find(conn, '2 Samuel 6:14', 'EN')
    b1 = conn.execute("SELECT bcode FROM bible_index WHERE verse_id=?",
                      (g1[0][0],)).fetchone()[0] if g1 else None
    b2 = conn.execute("SELECT bcode FROM bible_index WHERE verse_id=?",
                      (g2[0][0],)).fetchone()[0] if g2 else None
    ck(b1 == 9 and b2 == 10, '사무엘상·하가 갈린다', (b1, b2))
    #   ★ **공백이 든 이름의 조회** — `_nk` 를 안 쓰면 그 자리에서 실패한다
    #     (실측으로 당했다: 정규식은 「1 Sa」를 맞히는데 사전에 `'1 sa'` 가 없다)
    ck(_nk('1 Sa') == '1sa' and _nk('Gen.') == 'gen' and _nk('1. Mose') == '1mose',
       '열쇠 정규화 — 공백·점을 걷는다', _nk('1. Mose'))
    bmE = book_map(conn, 'EN')
    ck(bmE.get(_nk('1 Samuel')) == 9 and bmE.get(_nk('1Sa')) == 9,
       '띄어 쓴 이름과 붙여 쓴 이름이 한 자리', bmE.get(_nk('1 Samuel')))
    ck(set(book_names_raw(conn, 'EN')) >= set(USFM),
       '정규식 이름 목록에 USFM 이 든다')
    #   ⚠ 애매한 변이는 안 넣었다
    ck('jud' not in (ALIAS.get('EN') or {}), 'EN 「Jud」는 안 받는다(애매)')
    #   316: JFB commentary abbreviations (9,100+ real places)
    for txt, want_b in (('Ro 11:36', 45), ('Mr 9:49', 41), ('Ec 7:29', 21),
                        ('So 5:1', 22), ('Ne 3:15', 16), ('Na 3:9', 34),
                        ('He 1:14', 58), ('Am 6:6', 30), ('Zac 14:5', 38),
                        ('1 Jo 1:6', 62), ('2 Jo 1:1', 63), ('3 Jo 1:2', 64)):
        g = find(conn, txt, 'EN')
        b = conn.execute("SELECT bcode FROM bible_index WHERE verse_id=?",
                         (g[0][0],)).fetchone()[0] if g else None
        ck(b == want_b, 'JFB 약어 %s' % txt, b)
    #   ⚠⚠ 안 넣은 것 — 넣으면 영어 받장이 걸린다
    ck('at' not in (ALIAS.get('EN') or {}),
       'EN at 은 안 받는다 — at 8:30(시각)이 그 꼴이다')
    ck('jo' not in (ALIAS.get('EN') or {}),
       'EN 단독 Jo 는 안 받는다 — John/Joel/Jonah/Job 어느 쪽도 된다')
    ck(find(conn, 'at 8:30', 'EN') == [],
       'at 8:30 을 성경 참조로 안 읽는다')

    # ── ⑦ 가운뎃점을 절 구분자로 읽지 않는가 (ⓐ 흠 재현) ──────────
    got = find(conn, '구약 39절 7권에 나온다(출애굽기 21 · 레위기 1 · 사사기 6)', 'KO')
    bads = [g for g in got
            if conn.execute("SELECT chapter FROM bible_index WHERE verse_id=?",
                            (g[0],)).fetchone()[0] != 21
            and conn.execute("SELECT bcode FROM bible_index WHERE verse_id=?",
                             (g[0],)).fetchone()[0] == 2]
    ck(not bads, '「출애굽기 21 · 레위기 1」에서 21:1 을 21:레 로 안 읽는다', bads)
    got2 = find(conn, '사사기 6 · 1', 'KO')
    ck(got2 and got2[0][0] == v(7, 6, 1) and got2[0][3] == KIND_CHAPTER,
       '가운뎃점은 나열 — 「사사기 6」을 장으로 읽는다', got2[:2])

    # ── ⑧ 없는 절·거꾸로·중복 ────────────────────────────────────
    ck(find(conn, '신 99:1', 'KO') == [], '없는 장은 안 낸다')
    ck(find(conn, '없는책 1:1', 'KO') == [], '모르는 책 이름은 안 낸다')
    got = find(conn, '신 15:4 그리고 다시 신 15:4', 'KO')
    ck(len(got) == 1, '같은 좌표는 한 번만', len(got))
    got = find(conn, '신 15:7-4', 'KO')
    ck(got and got[0][0] <= got[0][1], '거꾸로 적어도 바로잡는다', got[:1])
    ck(resolve(conn, '없는책 1:1', 'KO') == (None, None),
       'resolve 실패는 (None, None)')
    ck(resolve(conn, '신 15:4', 'KO') == (v(5, 15, 4), v(5, 15, 4)),
       'resolve 보기')

    # ── ⑨ 아랍어 숫자 ────────────────────────────────────────────
    ck(_ar2a('١٥') == '15', '아랍어 숫자 변환', _ar2a('١٥'))
    row = conn.execute("SELECT short_name FROM book_names "
                       "WHERE lang_code='AR' AND book_code=5").fetchone()
    if row and (row[0] or '').strip():
        got = find(conn, '%s ١٥:٤' % row[0].strip(), 'AR')
        ck(got and got[0][0] == v(5, 15, 4), 'AR 아랍어 숫자로 읽기', got[:1])

    # ── ⑩ 상한·되돌림 ────────────────────────────────────────────
    many = ' '.join('신 15:%d' % i for i in range(1, 20))
    ck(len(find(conn, many, 'KO', limit=5)) == 5, '상한이 듣는다')
    ck(find(conn, '', 'KO') == [] and find(conn, None, 'KO') == [],
       '빈 글은 빈 목록')
    ck(KIND_LABEL.get(KIND_CHAPTER), 'kind 이름표가 있다')
    # ★ 2026-10-15 AI 답 검증 — 없는 장·절
    _bd = [m for m, _p in bad_refs(conn, '롬 16:85 와 시편 151편, 요 3:16 · 특히 28 · 요 3', 'KO')]
    ck(_bd == ['롬 16:85', '시편 151편'], '없는 장·절만 낸다(있는 절 · 낱말 꼬리 · 맨 숫자는 아니다)', _bd)
    ck([m for m, _p in bad_refs(conn, 'See Rom 16:85 and John 3:16', 'EN')] == ['Rom 16:85'], '없는 절 — 영어')

    # ── ⑪ 실제 연구자료에서 도는가 ───────────────────────────────
    r = conn.execute("""
        SELECT COALESCE(t.body_text,'') FROM sys_ref_text t
          JOIN sys_ref_unit u ON u.ref_unit_id=t.ref_unit_id
          JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id
         WHERE s.src_type='STUDY' AND UPPER(COALESCE(t.lang_code,'KO'))='KO'
           AND LENGTH(COALESCE(t.body_text,''))>500 LIMIT 1""").fetchone()
    if r:
        got = find(conn, r[0], 'KO')
        ck(len(got) > 0, '실제 연구자료에서 좌표가 나온다', len(got))

    conn.close()
    print('\n'.join(msgs))
    print('결과 %d/%d' % (ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    if '--usfm' in sys.argv:
        for b in range(1, 67):
            print('%2d  %-4s %-7s' % (b, usfm_of(b), osis_of(b)))
        sys.exit(0)
    print(__doc__)
