# -*- coding: utf-8 -*-
"""db_ref_link_fill.py — **칸으로만 붙은 연구자료를 연결 표에도 남긴다**
(2026-08-31 사용자 신고에서 나온 도구 · 영구 · `--selftest` 의무).

★★★ 왜 — 사용자 신고 「스펄전 아침묵상1은 연구자료(1) 제목=dfdf 와 연결되어
  있다고 표시되는데 **통합연결팝업의 왼쪽 화면에 전혀 표시되지 않는다**」.
  원인은 **쓰는 문이 갈려 있던 것**이다:
  · `p4_ref_view._link_origin` 이 **구절**은 연결 표에 남기고
  · **도서 편**은 `user_ref_asset.body_unit_id` **칸만** 채웠다
  그 결과 두 화면이 서로 다른 것을 세면서 같은 이름(「연구자료」)을 썼다:
  | 화면 | 무엇을 세나 | 편 1 |
  |---|---|---|
  | 3단 단추 `연구자료 (n)` | 칸 + 연결 표 | **1** |
  | My Edit ① 현황 | **연결 표만** | **0** |
  ①에 안 뜨니 `⇨` 로 뗄 수도 없었다.

⇒ **쓰는 문**은 고쳤다(`_link_origin` 에 도서 편 갈래 추가). 이 도구는
  **이미 쌓인 것**을 메운다.

⚠ **읽는 쪽을 고치지 않았다** — `links_of` 가 칸도 읽게 하면 자산 전반의
  단일 문에 **도서 유닛 특례**가 들어간다. 근본은 「쓸 때 한 번에 남기는」 것이다.

⚠ **지우지 않는다.** 넣기만 하고 멱등이다. 되돌리려면 `--undo`.

사용법
    python -X utf8 db_ref_link_fill.py --selftest
    python -X utf8 db_ref_link_fill.py --check     # 몇 편이 어긋났나
    python -X utf8 db_ref_link_fill.py --apply
    python -X utf8 db_ref_link_fill.py --undo      # 이 도구가 넣은 것만
"""
import sys

import appdb

#: (칸 이름, 상대 종류) — 자산을 늘리면 여기 한 줄.
COLS = (('body_unit_id', 'BOOK_UNIT'),
        ('verse_id', 'VERSE'),
        ('pericope_id', 'PERICOPE'))


def _pairs(conn, col, kind):
    """그 칸으로 붙었는데 **연결 표에 없는** 짝 → [(ref_id, 상대번호)]."""
    import link_picker as LP
    code = LP.CODE[kind]
    out = []
    for rid, tgt in conn.execute(
            "SELECT ref_id, %s FROM user_ref_asset "
            " WHERE COALESCE(record_status,'LIVE')='LIVE' "
            "   AND %s IS NOT NULL AND %s <> 0" % (col, col, col)):
        # ⚠ **두 이름을 다 본다** — 쓰는 곳이 둘이라 `UREF_BUNT` 와 `BUNT_UREF`
        #   가 섞여 있다(`db_user_ref_schema` 주석 참조). 한쪽만 보면 이미
        #   있는 것을 또 넣는다.
        got = conn.execute(
            "SELECT 1 FROM userdb.user_link_asset "
            " WHERE ((link_type=? AND clicked_id=? AND target_id=?) "
            "     OR (link_type=? AND clicked_id=? AND target_id=?)) LIMIT 1",
            ('UREF_' + code, rid, tgt, code + '_UREF', tgt, rid)).fetchone()
        if not got:
            out.append((rid, tgt))
    return out


def check(conn):
    """→ {종류: [(ref_id, 상대번호)]}"""
    return {k: _pairs(conn, c, k) for c, k in COLS}


def apply(conn):
    """어긋난 짝에 연결 행을 넣는다(멱등). → 넣은 수."""
    import link_picker as LP
    n = 0
    for col, kind in COLS:
        for rid, tgt in _pairs(conn, col, kind):
            # ⚠ **`link_picker.add` 를 쓴다** — 없는 자산을 거부하는 문이
            #   거기 있다(§97차 유령 연결). 여기서 INSERT 를 또 쓰면 그 문을
            #   비껴간다.
            try:
                LP.add(conn, ('USER_REF', rid), (kind, tgt))
                n += 1
            except Exception as e:
                print('  건너뜀 ref %s → %s %s : %s' % (rid, kind, tgt, e))
    conn.commit()
    return n


def undo(conn, pairs):
    """`apply` 가 넣은 것만 되돌린다 — `pairs` 는 넣기 전 `check()` 결과."""
    import link_picker as LP
    n = 0
    for kind, lst in pairs.items():
        code = LP.CODE[kind]
        for rid, tgt in lst:
            cur = conn.execute(
                "DELETE FROM userdb.user_link_asset "
                " WHERE (link_type=? AND clicked_id=? AND target_id=?) "
                "    OR (link_type=? AND clicked_id=? AND target_id=?)",
                ('UREF_' + code, rid, tgt, code + '_UREF', tgt, rid))
            n += cur.rowcount or 0
    conn.commit()
    return n


def selftest(db_path='bible_master.db'):
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %-4s %s %s' % ('OK' if cond else 'FAIL', name, extra))

    import link_picker as LP
    conn = appdb.connect(db_path)
    mx = conn.execute(
        "SELECT COALESCE(MAX(user_link_id),0) FROM userdb.user_link_asset"
    ).fetchone()[0]
    rmax = conn.execute(
        "SELECT COALESCE(MAX(ref_id),0) FROM user_ref_asset").fetchone()[0]
    uid = conn.execute(
        "SELECT unit_id FROM sys_book_unit LIMIT 1").fetchone()[0]
    try:
        cur = conn.execute(
            "INSERT INTO user_ref_asset (ref_type, title, body_unit_id, "
            " record_status) VALUES ('STUDY','__시험__',?,'LIVE')", (uid,))
        rid = cur.lastrowid
        conn.commit()
        got = check(conn)
        t('★ 칸만 있는 것을 찾아낸다',
          (rid, uid) in got['BOOK_UNIT'], got['BOOK_UNIT'][-2:])
        apply(conn)
        got2 = check(conn)
        t('★ 넣은 뒤에는 안 걸린다', (rid, uid) not in got2['BOOK_UNIT'])
        rows = [r for r in LP.links_of(conn, 'BOOK_UNIT', uid, 'KO')
                if r.get('kind') == 'USER_REF' and r.get('id') == rid]
        t('★ **My Edit ① 에 뜬다**(이것이 목적이다)', len(rows) == 1, rows)
        n0 = len(check(conn)['BOOK_UNIT'])
        apply(conn)
        t('★ 두 번 돌려도 안 는다', len(check(conn)['BOOK_UNIT']) == n0)
        undo(conn, {'BOOK_UNIT': [(rid, uid)]})
        t('★ 되돌린다', (rid, uid) in check(conn)['BOOK_UNIT'])
    finally:
        conn.execute("DELETE FROM user_ref_asset WHERE ref_id > ?", (rmax,))
        conn.execute("DELETE FROM userdb.user_link_asset WHERE user_link_id > ?",
                     (mx,))
        conn.commit()
        left = conn.execute(
            "SELECT COUNT(*) FROM userdb.user_link_asset WHERE user_link_id > ?",
            (mx,)).fetchone()[0] + conn.execute(
            "SELECT COUNT(*) FROM user_ref_asset WHERE ref_id > ?",
            (rmax,)).fetchone()[0]
        t('★ 시험 잔재 0', left == 0, left)
        conn.close()
    print('db_ref_link_fill selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect('bible_master.db')
    got = check(c)
    for k, v in got.items():
        print('%-10s 어긋남 %d편 %s' % (k, len(v), v[:6]))
    if '--apply' in a:
        print('넣은 연결:', apply(c))
    elif '--undo' in a:
        print('되돌린 연결:', undo(c, got))
    c.close()
