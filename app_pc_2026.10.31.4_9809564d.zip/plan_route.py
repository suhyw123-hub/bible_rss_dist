# -*- coding: utf-8 -*-
"""묵상경로 — 자산 사이의 「다음 걸음」 (영구 모듈, 2026-08-17 사용자 설계 승인)

  python plan_route.py --selftest      # 의무
  python plan_route.py --init          # 스키마 (멱등)
  python plan_route.py --seed          # 현재 자산 기반 초기 경로 (멱등)
  python plan_route.py --export routes.json   # 팩 동봉/배포용 전체본
  python plan_route.py --import routes.json   # version 높으면 전체 교체
  python plan_route.py --list

설계 (정책자료/0.txt 토론 확정):
  · 표 하나 `sys_plan_route(from_kind/from_id → to_kind/to_id, note, sort)` —
    **sys 자산만**(사용자 플랜 제외). 관리 원장은 관리자 DB.
  · **표시 게이트**: 양끝 자산이 로컬 DB 에 LIVE 로 존재할 때만 그린다 —
    팩을 안 받은 사용자에게 그 경로는 무해한 잠복 데이터다.
  · **배포 = 항상 전체본 하나** (routes.json, version 포함). 팩마다 동봉 +
    온라인 동기화 + 콘텐츠 통째 교체, **어느 길로 와도 version 높은 쪽
    전체가 이긴다**(행 병합 금지 — 갈라짐의 근원).
  · kind: PLAN(sys_bible_plan) · LENS(sys_unit_asset CONTAINER) ·
    BOOK(sys_book_asset) · REF(sys_ref_source). from 은 PLAN/LENS/BOOK.
  · 사용자 권한: 보기 + 찜(♥)만. 경로 편집은 관리자.
"""
import io
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bible_master.db')
VERSION_KEY = 'PLAN_ROUTE_VERSION'

# ★★★ **코드가 아니라 이름을 보인다**(2026-09-18 사용자 「LENS, PLAN,
#   REF 등의 기호 대신 렌즈묵상, 묵상플랜, 도서, 연구자료 — **모든 화면에서
#   모두 지켜야 할 원칙**」). 여기가 단일 소스라 관리자 콤보·목록과
#   사용자 화면(「다음 걸음」)이 한 번에 따라온다.
# ⚠ 사용자 화면이 이 글자를 그대로 그린다 — **한국어가 박혀 있다**(옛 흠).
#   다국어로 옮기려면 `ui_strings` 열쇠 넷이 필요하다(⏭ 할일).
KIND_LABEL = {'PLAN': '묵상플랜', 'LENS': '렌즈묵상', 'BOOK': '도서',
              'REF': '연구자료'}

#: ★★ 2026-08-24 — **경로를 통합 표로 옮겼다**(`db_link_migrate.py`).
#   `sys_link_asset(link_type='<A>_<B>', rel_code='NEXT')` 한 행이 한 걸음이다.
#   옛 표 `sys_plan_route` 는 되돌릴 수 있게 남아 있지만 **읽지 않는다.**
#   ★ **경로만 방향이 있다** — 다른 연결은 A·B 를 정렬하는데 이것은
#     from→to 를 그대로 둔다. 그래서 `rel_code='NEXT'` 로 표시한다.
#   ⚠ 렌즈는 `sys_unit_asset`(CONTAINER) 이라 코드가 `CONT` 다.
LINK_TBL = 'sys_link_asset'
NEXT = 'NEXT'
CODE = {'PLAN': 'PLAN', 'LENS': 'CONT', 'BOOK': 'BOOK', 'REF': 'REFS'}
KIND_OF = {v: k for k, v in CODE.items()}


def _lt(a_kind, b_kind):
    return '%s_%s' % (CODE.get(a_kind, a_kind), CODE.get(b_kind, b_kind))


def _route_where(side, kind):
    """`side`='from' 이면 A쪽, 'to' 면 B쪽에 그 종류가 오는 조건.

    ⚠⚠ **자리를 세지 않는다** (2026-08-27 — `TAG` 는 코드가 **세 자**라
      `substr(,1,4)`/`substr(,6,4)` 가 빗나간다. link_picker 에서 태그 연결이
      통째로 안 보이던 함정과 같은 계열). `instr` 로 밑줄 자리를 물어 가른다.
      (`LIKE 'PLAN\\_%'` 는 `_` 가 와일드카드라 여전히 안 쓴다.)"""
    if side == 'from':
        return ("substr(link_type,1,instr(link_type,'_')-1)=?",
                CODE.get(kind, kind))
    return ("substr(link_type,instr(link_type,'_')+1)=?",
            CODE.get(kind, kind))


# ── 스키마 ────────────────────────────────────────────────────────────────

def init_schema(conn):
    conn.execute("""CREATE TABLE IF NOT EXISTS sys_plan_route (
        route_id      INTEGER PRIMARY KEY AUTOINCREMENT,
        from_kind     TEXT NOT NULL,
        from_id       INTEGER NOT NULL,
        to_kind       TEXT NOT NULL,
        to_id         INTEGER NOT NULL,
        note          TEXT,
        sort_order    INTEGER DEFAULT 10,
        record_status TEXT DEFAULT 'LIVE',
        UNIQUE(from_kind, from_id, to_kind, to_id))""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_plan_route_from "
                 "ON sys_plan_route(from_kind, from_id)")
    conn.commit()


def get_version(conn):
    r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                     (VERSION_KEY,)).fetchone()
    try:
        return int(r[0]) if r else 0
    except (TypeError, ValueError):
        return 0


def set_version(conn, v):
    if conn.execute("SELECT 1 FROM sys_config WHERE config_key=?",
                    (VERSION_KEY,)).fetchone():
        conn.execute("UPDATE sys_config SET config_val=? WHERE config_key=?",
                     (str(v), VERSION_KEY))
    else:
        conn.execute("INSERT INTO sys_config (config_key, config_val) "
                     "VALUES (?, ?)", (VERSION_KEY, str(v)))


# ── 존재 게이트 + 라벨 ────────────────────────────────────────────────────

def _exists(conn, kind, tid):
    """그 자산이 이 DB 에 살아 있는가 — 팩 미보유 사용자 필터의 전부."""
    if kind == 'PLAN':
        return conn.execute("SELECT 1 FROM sys_bible_plan WHERE plan_id=? "
                            "AND record_status='LIVE'", (tid,)).fetchone()
    if kind == 'LENS':
        return conn.execute("SELECT 1 FROM sys_unit_asset WHERE sys_unit_id=? "
                            "AND unit_type='CONTAINER' "
                            "AND COALESCE(record_status,'LIVE')='LIVE'",
                            (tid,)).fetchone()
    if kind == 'BOOK':
        return conn.execute("SELECT 1 FROM sys_book_asset b WHERE b.book_id=? "
                            "AND b.record_status='LIVE' AND EXISTS("
                            "SELECT 1 FROM sys_book_unit u WHERE "
                            "u.book_id=b.book_id AND u.record_status='LIVE')",
                            (tid,)).fetchone()
    if kind == 'REF':
        return conn.execute("SELECT 1 FROM sys_ref_source WHERE ref_src_id=? "
                            "AND record_status='LIVE'", (tid,)).fetchone()
    return None


def _label(conn, kind, tid, lang='KO'):
    lang = (lang or 'KO').upper()
    if kind == 'PLAN':
        r = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE text_type='PLAN_TITLE' "
            "AND clicked_id=? AND record_status='LIVE' "
            "ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0 WHEN 'EN' THEN 1 "
            "ELSE 2 END LIMIT 1", (tid, lang)).fetchone()
        return r[0] if r else '플랜 %d' % tid
    if kind == 'LENS':
        r = conn.execute(
            "SELECT COALESCE((SELECT contents FROM sys_text_asset WHERE "
            "text_type='CONT_NAME' AND clicked_id=u.sys_unit_id AND "
            "UPPER(lang_code)=? AND COALESCE(record_status,'LIVE')='LIVE' "
            "LIMIT 1), u.unit_name_sid) FROM sys_unit_asset u "
            "WHERE u.sys_unit_id=?", (lang, tid)).fetchone()
        return r[0] if r else '렌즈 %d' % tid
    if kind == 'BOOK':
        # 번역 제목 층(sys_book_asset_text)을 먼저 — 원제 폴백 (2026-08-18
        #   도서 KO 제목 시드와 함께. 안 보면 경로 메뉴에 영어 제목이 샌다)
        r = conn.execute(
            "SELECT COALESCE((SELECT bat.title FROM sys_book_asset_text bat "
            "WHERE bat.book_id=b.book_id AND UPPER(bat.lang_code)=? AND "
            "bat.record_status='LIVE' LIMIT 1), b.title) "
            "FROM sys_book_asset b WHERE b.book_id=?", (lang, tid)).fetchone()
        return r[0] if r else '도서 %d' % tid
    if kind == 'REF':
        r = conn.execute("SELECT COALESCE(NULLIF(title_ko,''), title) "
                         "FROM sys_ref_source WHERE ref_src_id=?",
                         (tid,)).fetchone()
        return r[0] if r else '자료 %d' % tid
    return '?'


def routes_from(conn, kind, tid, lang='KO', limit=3):
    """이 자산에서 이어지는 「다음 걸음」 — 존재 게이트 통과분만.

    반환: [{'kind','id','label','note'}]  (라벨에 갈래 꼬리표는 화면이 붙인다)
    """
    out = []
    w, code = _route_where('from', kind)
    for lt, ti, note in conn.execute(
            "SELECT link_type, target_id, note FROM %s "
            "WHERE rel_code=? AND %s AND clicked_id=? "
            "AND COALESCE(record_status,'LIVE')='LIVE' "
            "ORDER BY sort_order, sys_link_id" % (LINK_TBL, w),
            (NEXT, code, tid)):
        tk = KIND_OF.get(lt.split('_')[-1], lt.split('_')[-1])
        if not _exists(conn, tk, ti):
            continue
        out.append({'kind': tk, 'id': ti,
                    'label': _label(conn, tk, ti, lang), 'note': note or ''})
        if len(out) >= limit:
            break
    return out


def routes_to(conn, kind, tid, lang='KO', limit=3):
    """이 자산으로 들어오는 앞 단계(역방향) — 통합 팝업용."""
    out = []
    w, code = _route_where('to', kind)
    for lt, fi, note in conn.execute(
            "SELECT link_type, clicked_id, note FROM %s "
            "WHERE rel_code=? AND %s AND target_id=? "
            "AND COALESCE(record_status,'LIVE')='LIVE' "
            "ORDER BY sort_order, sys_link_id" % (LINK_TBL, w),
            (NEXT, code, tid)):
        fk = KIND_OF.get(lt.split('_')[0], lt.split('_')[0])
        if not _exists(conn, fk, fi):
            continue
        out.append({'kind': fk, 'id': fi,
                    'label': _label(conn, fk, fi, lang), 'note': note or ''})
        if len(out) >= limit:
            break
    return out


def prev_click(event, prevs, on_jump):
    """「◀ 이전 단계」 클릭 (2026-08-18 사용자 지시 — 줄에는 이름을 안 적는다:
    자산 이름까지 적으면 너무 길다). 하나면 바로 점프, 여럿이면 이름 메뉴."""
    if not prevs or not callable(on_jump):
        return
    if len(prevs) == 1:
        on_jump(prevs[0]['kind'], prevs[0]['id'])
        return
    import tkinter as tk
    m = tk.Menu(event.widget, tearoff=0)
    for r in prevs:
        m.add_command(
            label='%s (%s)' % (r['label'], KIND_LABEL.get(r['kind'], r['kind'])),
            command=lambda k=r['kind'], i=r['id']: on_jump(k, i))
    m.tk_popup(event.x_root, event.y_root)


# ── 배포 — 전체본 export/import (version 높은 쪽 전체 승리) ────────────────

#: ⚠⚠ **경로 행만 고르는 조건.** 통합 표에는 다른 연결이 28,000행 넘게 있다 —
#   `rel_code='NEXT'` 하나로는 부족할 수 있어 **link_type 목록까지** 함께 건다.
#   내보내기·들여오기가 이 조건으로만 움직인다.
def _route_types():
    return tuple('%s_%s' % (a, b) for a in CODE.values() for b in CODE.values())


def _route_filter():
    ph = ','.join('?' * len(_route_types()))
    return ("rel_code=? AND link_type IN (%s)" % ph,
            (NEXT,) + _route_types())


def export_routes(conn, path):
    w, args = _route_filter()
    rows = []
    for lt, fi, ti, note, so in conn.execute(
            "SELECT link_type, clicked_id, target_id, note, sort_order "
            "FROM %s WHERE %s AND COALESCE(record_status,'LIVE')='LIVE' "
            "ORDER BY link_type, clicked_id, sort_order" % (LINK_TBL, w), args):
        a, b = lt.split('_')
        rows.append({'from_kind': KIND_OF.get(a, a), 'from_id': fi,
                     'to_kind': KIND_OF.get(b, b), 'to_id': ti,
                     'note': note, 'sort_order': so})
    doc = {'version': get_version(conn), 'routes': rows}
    io.open(path, 'w', encoding='utf-8').write(
        json.dumps(doc, ensure_ascii=False, indent=1))
    return len(rows)


AUTO_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         'routes.json')


def autosave(conn, path=None):
    """경로를 고칠 때마다 **백업 파일을 그 자리에서 다시 쓴다** → `(줄수, 까닭)`.

    ★ 사용자 지시(2026-09-18) — 「경로를 수정한 경우 즉시 자동저장」.
    ⚠⚠ **이것이 배포를 지켜 주지는 않는다** — 배포는 이 파일이 아니라
      코어팩(`sys_link_asset` 통째)이 한다(이 파일을 읽는 코드 0곳).
      배포가 낡는 것을 막는 문은 **`db_pack_fresh`** 다.
      이 파일의 몫은 **백업·이관** 하나다.
    ⚠ 실패해도 경로 저장을 죽이지 않는다(파일이 잠겨 있을 수 있다).
      다만 조용히 넘기지 않고 까닭을 돌려준다(§0-1) — 부르는 쪽이 말한다.
    """
    p = path or AUTO_PATH
    try:
        return export_routes(conn, p), ''
    except Exception as e:                                    # noqa: BLE001
        return -1, str(e)[:80]


def import_routes(conn, path):
    """version 이 로컬보다 높을 때만 **전체 교체**. 낮거나 같으면 무시.

    ⚠⚠⚠ **지우는 범위를 반드시 좁힌다.** 옛 표에서는 `DELETE FROM sys_plan_route`
      한 줄이면 됐지만, 통합 표에서 그렇게 하면 **모든 연결이 사라진다**
      (구절 연결·용어 연결까지 28,000행). `rel_code='NEXT'` + link_type 목록
      두 겹으로 건다.
    ⚠ 그리고 **`commit` 은 호출자가 한다**(§0-5 — selftest 가 실 DB 를 파괴한 사고).
    """
    doc = json.loads(io.open(path, encoding='utf-8').read())
    ver = int(doc.get('version', 0))
    local = get_version(conn)
    if ver <= local:
        return ('skip', local, ver)
    w, args = _route_filter()
    conn.execute('DELETE FROM %s WHERE %s' % (LINK_TBL, w), args)
    for r in doc.get('routes', []):
        conn.execute(
            "INSERT OR IGNORE INTO %s (link_type, clicked_id, target_id, "
            "rel_code, note, sort_order, record_status) "
            "VALUES (?,?,?,?,?,?,'LIVE')" % LINK_TBL,
            (_lt(r['from_kind'], r['to_kind']), r['from_id'], r['to_id'],
             NEXT, r.get('note'), r.get('sort_order', 10)))
    set_version(conn, ver)
    # ⚠ commit 은 호출자가 한다 — 함수 안에서 commit 하면 selftest 의
    #   트랜잭션(BEGIN…rollback)이 풀려 **실 DB 를 지운 채 확정**된다
    #   (2026-08-17 실제로 당해서 시드를 다시 돌렸다).
    return ('replaced', local, ver)


# ── 완주 축하 + 다음 걸음 팝업 (사용자 화면 공용) ─────────────────────────

def show_completion_popup(parent, db_path, kind, tid, lang='KO',
                          on_jump=None, done_label=''):
    """완료 순간의 추천 팝업. 경로가 있으면 띄우고 True, 없으면 False —
    False 면 호출자가 기존 완료 알림을 그대로 쓴다."""
    conn = appdb.connect(db_path)
    try:
        routes = routes_from(conn, kind, tid, lang)
        name = done_label or _label(conn, kind, tid, lang)
    finally:
        conn.close()
    if not routes:
        return False
    import tkinter as tk
    from tkinter import ttk
    try:
        import i18n
        _t = i18n.t
    except Exception:
        def _t(_k, d):
            return d
    win = tk.Toplevel(parent)
    win.title(_t('ROUTE_DONE_TITLE', '완주를 축하합니다'))
    win.transient(parent.winfo_toplevel())
    win.grab_set()
    try:
        import ui_theme
        ui_theme.adopt(win)
    except Exception:
        pass
    frm = ttk.Frame(win, padding=14)
    frm.pack(fill='both', expand=True)
    ttk.Label(frm, text=_t('ROUTE_DONE_MSG', '「{name}」을(를) 마쳤습니다.'
                           ).format(name=name),
              font=('', 10, 'bold')).pack(anchor='w')
    ttk.Label(frm, text=_t('ROUTE_DONE_NEXT', '이어서 걷기 좋은 길:'),
              foreground='#7F8C8D').pack(anchor='w', pady=(8, 4))
    for r in routes:
        row = ttk.Frame(frm)
        row.pack(fill='x', pady=2)
        ttk.Label(row, text='%s (%s)' % (
            r['label'], KIND_LABEL.get(r['kind'], r['kind']))).pack(side='left')
        if r['note']:
            ttk.Label(row, text=' %s' % r['note'], foreground='#7F8C8D'
                      ).pack(side='left', padx=(6, 0))
        ttk.Button(row, text=_t('ROUTE_GO', '보기'), width=6,
                   command=lambda k=r['kind'], i=r['id']:
                   (win.destroy(),
                    callable(on_jump) and on_jump(k, i))).pack(side='right')
    ttk.Button(frm, text=_t('COMMON_CLOSE', '닫기'), width=8,
               command=win.destroy).pack(anchor='e', pady=(12, 0))
    win.geometry('+%d+%d' % (parent.winfo_rootx() + 150,
                             parent.winfo_rooty() + 150))
    return True


# ── 초기 경로 시드 (2026-08-17 현재 자산 실측 기반, 멱등) ─────────────────

SEED = [
    # 전체읽기 → 주제
    ('PLAN', 4,  'PLAN', 2,   '통독을 마쳤다면 절기의 흐름으로 구속사를 다시 봅니다'),
    ('PLAN', 10, 'PLAN', 17,  '연대기 통독 뒤에는 복음서를 연대순으로 깊이'),
    ('PLAN', 14, 'PLAN', 95,  '맥체인의 넓은 읽기 뒤에 시편을 스펄전과 함께 천천히'),
    # 주제읽기 → 렌즈/다음 주제 (주제 완주 후 렌즈 추천 — 사용자 확정 방향)
    ('PLAN', 2,  'LENS', 168, '절기의 뼈대인 언약을 렌즈로 짚습니다'),
    ('PLAN', 2,  'LENS', 151, '구속사 전체를 한 편의 드라마로'),
    ('PLAN', 16, 'LENS', 156, '제사의 핵심인 희생제사와 피를 렌즈로'),
    ('PLAN', 16, 'LENS', 205, '제사가 가리키는 것, 믿음으로 의롭다 하심'),
    ('PLAN', 17, 'PLAN', 18,  '연대순으로 읽었다면 이제 예표로 복음서를'),
    ('PLAN', 18, 'LENS', 166, '예표의 큰 그림, 에덴과 새에덴'),
    ('PLAN', 50, 'LENS', 152, '참예배의 대상이신 하나님의 성품을 렌즈로'),
    ('PLAN', 30, 'PLAN', 17,  '기적을 보았다면 그 기적의 주인공을 연대순으로'),
    ('PLAN', 75, 'BOOK', 32,  '다윗을 묵상했다면 매클라렌의 다윗 전기로'),
    # 자가진단 → 렌즈/도서/플랜
    ('PLAN', 37, 'PLAN', 48,  '불안을 지나며 임재 연습을 배웁니다'),
    ('PLAN', 38, 'LENS', 165, '슬픔 너머의 소망, 종말과 신부'),
    ('PLAN', 39, 'BOOK', 30,  '수치에서 은혜로, 스펄전의 All of Grace'),
    ('PLAN', 40, 'LENS', 162, '분노를 다루는 윤리와 도덕의 렌즈'),
    ('PLAN', 41, 'PLAN', 48,  '고독 속에서 하나님의 임재를 연습합니다'),
    ('PLAN', 42, 'LENS', 167, '거리에서 만남으로, 구원의 여정을 따라'),
    ('PLAN', 43, 'PLAN', 49,  '기도를 다시 시작했다면 바운즈와 함께 더 깊이'),
    ('PLAN', 44, 'LENS', 205, '죄책감의 답, 믿음으로 의롭다 하심'),
    ('PLAN', 44, 'BOOK', 30,  '값없이 주시는 은혜, All of Grace'),
    ('PLAN', 45, 'LENS', 161, '부르심과 사명을 렌즈로 정리합니다'),
    ('PLAN', 45, 'BOOK', 29,  '부르심의 실천, 스펄전의 영혼 인도'),
    ('PLAN', 46, 'PLAN', 49,  '다시 타오르는 불씨에 기도의 기름을'),
    # 도서 플랜 → 다음
    ('PLAN', 47, 'PLAN', 95,  '아침저녁 묵상 뒤에 시편 150일의 긴 호흡으로'),
    ('PLAN', 48, 'PLAN', 49,  '임재 연습에서 기도의 능력으로'),
    ('PLAN', 49, 'BOOK', 10,  '기도의 능력을 배웠다면 뮬러의 응답 이야기로'),
    ('PLAN', 95, 'BOOK', 32,  '시편을 지었던 다윗의 생애를 매클라렌과 함께'),
    ('PLAN', 95, 'LENS', 152, '시편이 노래한 하나님의 성품을 렌즈로'),
    # 렌즈 → 다음 (from LENS = 컨테이너 unit_id)
    ('LENS', 156, 'LENS', 205, '희생제사가 가리키는 칭의로'),
    ('LENS', 205, 'BOOK', 30,  '칭의의 복음을 스펄전의 언어로, All of Grace'),
    ('LENS', 205, 'LENS', 167, '의롭다 하심에서 구원의 여정 전체로'),
    ('LENS', 167, 'LENS', 205, '여정의 중심 사건, 믿음으로 의롭다 하심'),
    ('LENS', 168, 'PLAN', 2,   '언약의 렌즈로 절기의 흐름을 읽습니다'),
    ('LENS', 161, 'BOOK', 29,  '부르심의 실천, 스펄전의 영혼 인도'),
    ('LENS', 152, 'REF', 2,    '하나님의 성품을 문답으로 정리합니다'),
    ('LENS', 205, 'REF', 1,    '칭의와 위로, 하이델베르크 문답으로'),
    # 도서 → 플랜/렌즈 (도서읽기 화면의 역방향 입구)
    ('BOOK', 32, 'PLAN', 95,  '다윗의 생애를 읽었다면 그의 시편을 150일로'),
    ('BOOK', 30, 'LENS', 205, '은혜의 교리를 렌즈 한 편으로 복습합니다'),
    ('BOOK', 29, 'LENS', 161, '영혼 인도의 뿌리, 부르심과 사명'),
    ('BOOK', 31, 'PLAN', 95,  '서론을 선택해 읽었다면 150일 플랜으로 완주를'),
    ('BOOK', 1,  'PLAN', 47,  '이 책으로 7일 묵상 플랜을 시작할 수 있습니다'),
    ('BOOK', 8,  'PLAN', 49,  '이 책으로 20일 기도 묵상 플랜을 시작할 수 있습니다'),
]


def seed(conn):
    init_schema(conn)
    n_new = 0
    for fk, fi, tk, ti, note in SEED:
        if not _exists(conn, fk, fi) or not _exists(conn, tk, ti):
            print('  건너뜀(자산 없음): %s %s → %s %s' % (fk, fi, tk, ti))
            continue
        cur = conn.execute(
            "INSERT OR IGNORE INTO %s "
            "(link_type, clicked_id, target_id, rel_code, note) "
            "VALUES (?,?,?,?,?)" % LINK_TBL,
            (_lt(fk, tk), fi, ti, NEXT, note))
        n_new += cur.rowcount
    if n_new:
        set_version(conn, get_version(conn) + 1)
    conn.commit()
    w, args = _route_filter()
    total = conn.execute("SELECT COUNT(*) FROM %s WHERE %s "
                         "AND COALESCE(record_status,'LIVE')='LIVE'"
                         % (LINK_TBL, w), args).fetchone()[0]
    print('시드 — 신규 %d · 전체 %d · version %d'
          % (n_new, total, get_version(conn)))


# ── selftest ──────────────────────────────────────────────────────────────

def selftest():
    ok = True
    conn = appdb.connect(DB)
    try:
        init_schema(conn)          # 자체 commit — BEGIN 보다 먼저
        conn.execute('BEGIN')      # ⚠ init 의 commit 이 BEGIN 을 풀어 시험
                                   #   행이 실 DB 에 샌 적이 있다(잔재 원칙)
        # 존재 게이트 — 있는 것과 없는 것
        if not _exists(conn, 'PLAN', 4):
            print('FAIL 게이트: plan 4 가 없다고 한다'); ok = False
        if _exists(conn, 'PLAN', 999999):
            print('FAIL 게이트: 유령 플랜이 있다고 한다'); ok = False
        # 경로 왕복 + 게이트 필터
        conn.execute("INSERT OR IGNORE INTO %s "
                     "(link_type, clicked_id, target_id, rel_code, note) "
                     "VALUES ('PLAN_PLAN', 4, 999999, 'NEXT', '유령')" % LINK_TBL)
        conn.execute("INSERT OR IGNORE INTO %s "
                     "(link_type, clicked_id, target_id, rel_code, note) "
                     "VALUES ('PLAN_PLAN', 4, 14, 'NEXT', '실재')" % LINK_TBL)
        got = routes_from(conn, 'PLAN', 4)
        if any(r['id'] == 999999 for r in got):
            print('FAIL 유령 경로가 게이트를 통과'); ok = False
        if not any(r['id'] == 14 and r['kind'] == 'PLAN' for r in got):
            print('FAIL 실재 경로가 안 나옴: %s' % got); ok = False
        # 라벨 — 렌즈는 CONT_NAME 폴백
        lb = _label(conn, 'LENS', 156, 'KO')
        if not lb or lb.startswith('렌즈 '):
            print('FAIL 렌즈 라벨: %r' % lb); ok = False
        # export/import — version 규칙
        import tempfile
        p = os.path.join(tempfile.gettempdir(), 'routes_selftest.json')
        set_version(conn, 5)
        export_routes(conn, p)
        doc = json.loads(io.open(p, encoding='utf-8').read())
        doc['version'] = 4
        io.open(p, 'w', encoding='utf-8').write(json.dumps(doc))
        st, lo, ve = import_routes(conn, p)
        if st != 'skip':
            print('FAIL 낮은 version 이 교체됨'); ok = False
        doc['version'] = 6
        doc['routes'] = doc['routes'][:1]
        io.open(p, 'w', encoding='utf-8').write(json.dumps(doc))
        # ★★ 남의 연결이 이 자리에 있어야 한다 — **전체 교체가 그것을 지우면
        #   안 된다.** 통합 표에서는 `DELETE FROM` 한 줄이 28,000행을 날린다.
        other = conn.execute(
            "SELECT COUNT(*) FROM %s WHERE COALESCE(rel_code,'')<>'NEXT'"
            % LINK_TBL).fetchone()[0]
        st, lo, ve = import_routes(conn, p)
        w, args = _route_filter()
        n = conn.execute('SELECT COUNT(*) FROM %s WHERE %s'
                         % (LINK_TBL, w), args).fetchone()[0]
        if st != 'replaced' or n != 1 or get_version(conn) != 6:
            print('FAIL 전체 교체: %s n=%d v=%d' % (st, n, get_version(conn)))
            ok = False
        after = conn.execute(
            "SELECT COUNT(*) FROM %s WHERE COALESCE(rel_code,'')<>'NEXT'"
            % LINK_TBL).fetchone()[0]
        if after != other:
            print('FAIL **전체 교체가 남의 연결을 건드렸다**: %d → %d'
                  % (other, after)); ok = False
        os.remove(p)
        conn.rollback()
    finally:
        try:
            conn.rollback()
        except Exception:
            pass
        conn.close()
    # ★ 자동저장 — 고치면 파일이 따라오는가
    try:
        import tempfile
        import shutil
        d2 = tempfile.mkdtemp()
        c2 = appdb.connect(DB)
        try:
            ap = os.path.join(d2, 'auto.json')
            n_, why_ = autosave(c2, ap)
            if n_ < 0 or not os.path.exists(ap):
                print('FAIL 자동저장이 파일을 안 썼다: %s' % why_); ok = False
            else:
                v0 = json.loads(io.open(ap, encoding='utf-8').read())
                if 'version' not in v0 or 'routes' not in v0:
                    print('FAIL 자동저장 파일 꼴이 다르다'); ok = False
                if len(v0.get('routes') or []) != n_:
                    print('FAIL 자동저장 줄수가 파일과 다르다'); ok = False
            # ⚠ 못 쓰는 자리를 줘도 죽지 않아야 한다
            bad_, _w = autosave(c2, os.path.join(d2, 'x', 'y', 'z.json'))
            if bad_ != -1:
                print('FAIL 못 쓰는 자리인데 성공이라 한다'); ok = False
        finally:
            c2.close()
            shutil.rmtree(d2, ignore_errors=True)
    except Exception as e:                                    # noqa: BLE001
        print('FAIL 자동저장: %s' % e); ok = False
    print('plan_route selftest', 'OK' if ok else 'FAIL')
    return ok


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--init', action='store_true')
    ap.add_argument('--seed', action='store_true')
    ap.add_argument('--export', metavar='FILE')
    ap.add_argument('--import', dest='imp', metavar='FILE')
    ap.add_argument('--list', action='store_true')
    a = ap.parse_args()
    conn = appdb.connect(DB)
    try:
        if a.selftest:
            conn.close()
            sys.exit(0 if selftest() else 1)
        if a.init:
            init_schema(conn)
            print('스키마 OK · version', get_version(conn))
        elif a.seed:
            seed(conn)
        elif a.export:
            n = export_routes(conn, a.export)
            print('내보냄 %d행 · version %d → %s'
                  % (n, get_version(conn), a.export))
        elif a.imp:
            st, lo, ve = import_routes(conn, a.imp)
            conn.commit()
            print('%s (로컬 v%d, 파일 v%d)' % (st, lo, ve))
        elif a.list:
            w, args = _route_filter()
            for lt, fi, ti, note in conn.execute(
                    "SELECT link_type, clicked_id, target_id, note "
                    "FROM %s WHERE %s ORDER BY link_type, clicked_id"
                    % (LINK_TBL, w), args):
                a, b = lt.split('_')
                print('  %s %s → %s %s  %s'
                      % (KIND_OF.get(a, a), fi, KIND_OF.get(b, b), ti,
                         (note or '')[:34]))
        else:
            ap.print_help()
    finally:
        try:
            conn.close()
        except Exception:
            pass


if __name__ == '__main__':
    main()
