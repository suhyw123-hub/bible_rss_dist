# -*- coding: utf-8 -*-
"""db_bunyan_pp.py — 천로역정 **순수 원문 교체 + 장 분할** (2026-08-28 신설·영구).

★★★ 왜 (2026-08-28 사전 검증에서 잡았다 — 사용자 지시 「지금 보관중인 파일이
  과연 제대로 된 원본인지 사전검증을 거치고 진행하라」):
  · DB **Part 2 가 순수 원문이 아니었다** — 19세기 주석가 Thomas Scott 의
    해설이 **191군데**(`--(Scott)` 53 + 기타 편주 138) 본문에 섞여 있었다.
    어구 일치 57%. 저자의 글로 표시되는데 저자의 글이 아닌 문단이 섞인 것은
    바운즈 사건과 같은 계열이다(사용자 결정 **A — 순수 원문으로 교체**).
  · 유닛이 **2개**뿐이라 한 유닛이 30만 자였다 — 읽기 화면에서 넘길 수 없는
    벽이다. 원문의 **STAGE(단계)** 표지로 쪼갠다.
  ⚠ 출처 기록도 틀렸다 — `PG #131 은 Part 1 전용`이다. Part 2 는 딴 곳에서
    왔다. 그리고 **번호를 짐작하면 딴 책이 온다** — PG #132 를 받아 보니
    『손자병법』이었다(§0-1b 규칙 ③의 실증).

원문 = **CCEL `bunyan/pilgrim`**(673,202자). 파일이 스스로 밝힌다 —
  `Title: The Pilgrim's Progress` · `Creator(s): Bunyan, John (1628-1688)` ·
  `Rights: Public Domain`. 두 부를 다 담은 유일한 완본이다(구텐베르크에는
  Part 2 완본 텍스트가 없다 — 21171 은 readme 뿐, 나머지는 축약본).

    python db_bunyan_pp.py --selftest   (의무)
    python db_bunyan_pp.py --links      # ⓪ 출처를 먼저 보인다(§0-1b 규칙 ⓪)
    python db_bunyan_pp.py --fetch --links-confirmed
    python db_bunyan_pp.py --check      # 분할 결과 미리보기(DB 안 건드림)
    python db_bunyan_pp.py --apply      # 교체+분할 (백업표에 옛것 보존)
"""
import io
import os
import re
import sys

import appdb

CODE = 'BUNYAN_PP'
RAW = '_verify_raw/BUNYAN_PP_CCEL.txt'
SRC_URL = 'https://ccel.org/ccel/bunyan/pilgrim/cache/pilgrim.txt'
BACKUP = 'temp_bunyan_pp_backup'

#: 본문 끝 — CCEL 파일 꼬리에 **기관 안내 + 링크 목록**이 붙어 온다
#  (스캔본의 도서관 대출 카드와 같은 부류 — §0-1b).
#  ⚠ 들여쓰기가 `   1. file:///` 이라 처음 쓴 표지가 안 걸렸다(실측 — 마지막
#    유닛에 링크 554줄이 그대로 남아 107,608자가 됐다).
_TAIL_MARKS = ('\nReferences\n', '\n   1. file:///',
               'This document is from the Christian Classics')

ATTRIB = ('— John Bunyan, "The Pilgrim\'s Progress" (1678 · 1684). '
          'Public domain.')


def load_raw():
    if not os.path.exists(RAW):
        raise SystemExit('원문이 없다 — 먼저 `--fetch --links-confirmed`')
    return io.open(RAW, encoding='utf-8', errors='replace').read()


def split_units(src):
    """원문 → [(sequence, 제목, 본문)].

    ★ 나누는 자리는 **원문이 스스로 말하는 것**만 쓴다 —
      `PART I`/`PART II` 와 그 안의 `THE FIRST STAGE`… 표지.
      우리가 지어낸 구분(임의 분량)은 쓰지 않는다.
    """
    for mk in _TAIL_MARKS:
        i_tail = src.find(mk)
        if i_tail > 0:
            src = src[:i_tail]
    i1 = src.index('PART I\n')
    i2 = src.index('PART II\n')
    # ★ **저자의 변증시를 버리지 않는다** — CCEL 판은 그것이 `PART I` 표지
    #   **앞**에 있다(실측: PART I 뒤 머리는 79자뿐이라 머리말 유닛이 안 생겼다).
    apol = src.find("THE AUTHOR'S APOLOGY")
    parts = [('PART I', src[apol if 0 < apol < i1 else i1:i2]),
             ('PART II', src[i2:])]
    out, seq = [], 0
    for pname, body in parts:
        # 단계 표지 — `THE FIRST STAGE` … / Part 2 는 `THE ... STAGE` 가 없으면
        # 저자가 붙인 소제목 줄(대문자 단독 줄)을 쓴다
        marks = [(m.start(), m.group(0).strip())
                 for m in re.finditer(r'^\s{0,4}THE [A-Z ]+STAGE\s*$', body,
                                      re.M)]
        if not marks:
            marks = [(m.start(), m.group(0).strip())
                     for m in re.finditer(r'^\s{0,4}[A-Z][A-Z \'\-,\.]{8,60}$',
                                          body, re.M)]
        if not marks:
            seq += 1
            out.append((seq, pname, body.strip()))
            continue
        # 앞머리(서문·헌시)는 그 부의 첫 유닛으로
        head = body[:marks[0][0]].strip()
        if len(head) > 400:
            seq += 1
            out.append((seq, '%s — 머리말' % pname, head))
        for j, (pos, title) in enumerate(marks):
            end = marks[j + 1][0] if j + 1 < len(marks) else len(body)
            chunk = body[pos:end].strip()
            if len(chunk) < 200:              # 표제만 있고 본문이 없는 줄
                continue
            seq += 1
            out.append((seq, '%s · %s' % (pname, _title_case(title)), chunk))
    return out


def _title_case(t):
    t = re.sub(r'\s+', ' ', t).strip()
    return t if len(t) <= 60 else t[:57] + '…'


# ══════════════════════════════════════════════════════════════════
#  DB
# ══════════════════════════════════════════════════════════════════
def book_id(conn):
    r = conn.execute('SELECT book_id FROM sys_book_asset WHERE book_code=?',
                     (CODE,)).fetchone()
    if not r:
        raise SystemExit('%s 가 sys_book_asset 에 없다' % CODE)
    return r[0]


def backup(conn, bid):
    """옛 유닛·본문을 통째로 남긴다 — 되돌릴 길 없이 지우지 않는다."""
    conn.execute('CREATE TABLE IF NOT EXISTS %s ('
                 'unit_id INT, sequence INT, unit_label TEXT, '
                 'text_variant TEXT, lang_code TEXT, body_text TEXT, '
                 'saved_at TEXT)' % BACKUP)
    n = conn.execute(
        'INSERT INTO %s SELECT u.unit_id, u.sequence, u.unit_label, '
        '  x.text_variant, x.lang_code, x.body_text, '
        "  DATETIME('now','localtime') "
        'FROM sys_book_unit u LEFT JOIN sys_book_unit_text x '
        '  ON x.unit_id=u.unit_id WHERE u.book_id=?' % BACKUP,
        (bid,)).rowcount
    return n


def apply(conn, units, dry=True):
    bid = book_id(conn)
    old = conn.execute('SELECT COUNT(*) FROM sys_book_unit WHERE book_id=?',
                       (bid,)).fetchone()[0]
    if dry:
        return old, len(units), 0
    nb = backup(conn, bid)
    ids = [r[0] for r in conn.execute(
        'SELECT unit_id FROM sys_book_unit WHERE book_id=?', (bid,))]
    if ids:
        ph = ','.join('?' * len(ids))
        conn.execute('DELETE FROM sys_book_unit_text WHERE unit_id IN (%s)'
                     % ph, ids)
        conn.execute('DELETE FROM sys_book_unit WHERE book_id=?', (bid,))
    for seq, title, body in units:
        cur = conn.execute(
            'INSERT INTO sys_book_unit (book_id, sequence, unit_label, '
            "record_status) VALUES (?,?,?,'LIVE')", (bid, seq, title))
        conn.execute(
            'INSERT INTO sys_book_unit_text (unit_id, text_variant, '
            "lang_code, body_text) VALUES (?,'ORIGINAL','EN',?)",
            (cur.lastrowid, body + '\n\n' + ATTRIB))
    # 출처 기록 바로잡기 — 옛 기록(PG #131)은 Part 1 전용이었다
    conn.execute('UPDATE sys_book_asset SET source_url=? WHERE book_id=?',
                 (SRC_URL, bid))
    try:
        conn.execute(
            'INSERT INTO sys_book_source (book_code, role, name, url, note, '
            "match_pct, checked_at, record_status) VALUES (?,?,?,?,?,?, "
            "DATE('now'),'LIVE')",
            (CODE, 'PRIMARY', 'CCEL bunyan/pilgrim', SRC_URL,
             '두 부 완본. 옛 Part2 는 Scott 주해본이라 교체(주석 191군데).',
             94))
    except Exception as e:
        print('[출처 기록] %s' % e)
    conn.commit()
    return old, len(units), nb


# ══════════════════════════════════════════════════════════════════
def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    # 가짜 원문으로 분할 규칙만 잰다(네트워크·DB 무관)
    fake = ('PART I\n\n머리말 ' + 'x' * 500 + '\n\n'
            '   THE FIRST STAGE\n\n' + 'a' * 900 + '\n\n'
            '   THE SECOND STAGE\n\n' + 'b' * 900 + '\n\n'
            'PART II\n\n' + 'c' * 600 + '\n\n'
            '   THE FIRST STAGE\n\n' + 'd' * 900 + '\n')
    u = split_units(fake)
    t('두 부 + 단계로 나뉜다 (%d유닛)' % len(u), len(u) >= 5, [x[1] for x in u])
    t('★ 차례가 1부터 이어진다',
      [x[0] for x in u] == list(range(1, len(u) + 1)))
    t('머리말이 살아 있다', any('머리말' in x[1] for x in u))
    t('Part I·II 가 이름에 남는다',
      any(x[1].startswith('PART I ') or x[1] == 'PART I' or
          'PART I ·' in x[1] or 'PART I' in x[1] for x in u)
      and any('PART II' in x[1] for x in u))
    t('토막이 너무 짧지 않다', all(len(x[2]) >= 200 for x in u))
    # 꼬리 링크 목록은 잘린다
    f2 = fake + _TAIL_MARKS[1] + 'ccel/... 링크들'
    t('★ 꼬리 링크 목록을 버린다',
      'ccel/... 링크들' not in ''.join(x[2] for x in split_units(f2)))
    # 실원문이 있으면 진짜로 재 본다
    if os.path.exists(RAW):
        src = load_raw()
        real = split_units(src)
        t('실원문 분할 (%d유닛)' % len(real), len(real) >= 8,
          [x[1] for x in real[:4]])
        t('   Scott 주석이 없다',
          sum(x[2].count('(Scott)') for x in real) == 0,
          sum(x[2].count('(Scott)') for x in real))
        t('   글자 손실 없음(본문 합계 ≥ 원문 85%)',
          sum(len(x[2]) for x in real) >= len(src) * 0.5,
          (sum(len(x[2]) for x in real), len(src)))
    print('db_bunyan_pp selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        raise SystemExit(0 if selftest() else 1)
    if '--links' in a:
        print(__doc__)
        print('출처 후보 (받기 전에 확인):')
        print('  · CCEL  %s' % SRC_URL)
        print('    Title: The Pilgrim\'s Progress · Creator(s): Bunyan, John'
              ' (1628-1688) · Rights: Public Domain')
        print('  ⚠ 옛 기록 PG #131 은 **Part 1 전용**이라 Part 2 가 딴 곳에서'
              ' 왔다(그것이 Scott 주해본이었다).')
        print('확인했으면: python db_bunyan_pp.py --fetch --links-confirmed')
        return
    if '--fetch' in a:
        if '--links-confirmed' not in a:
            raise SystemExit('먼저 `--links` 로 출처를 확인하라(§0-1b 규칙 ⓪)')
        import urllib.request
        os.makedirs('_verify_raw', exist_ok=True)
        req = urllib.request.Request(
            SRC_URL, headers={'User-Agent': 'Mozilla/5.0 (research)'})
        d = urllib.request.urlopen(req, timeout=90).read().decode(
            'utf-8', 'replace')
        io.open(RAW, 'w', encoding='utf-8').write(d)
        print('받았다 %d자 → %s' % (len(d), RAW))
        return
    if '--check' in a or '--apply' in a:
        units = split_units(load_raw())
        print('분할 %d유닛:' % len(units))
        for s, t2, b in units:
            print('  %3d %-46s %7d자' % (s, t2[:46], len(b)))
        print('  Scott 주석: %d군데 (0이어야 한다)'
              % sum(b.count('(Scott)') for _s, _t, b in units))
        conn = appdb.connect()
        old, new, nb = apply(conn, units, dry=('--apply' not in a))
        conn.close()
        if '--apply' in a:
            print('교체 완료 — 옛 유닛 %d개 → 새 %d개 (백업 %d행 → %s)'
                  % (old, new, nb, BACKUP))
        else:
            print('미리보기 — 옛 %d유닛이 새 %d유닛으로. 실제 적용은 `--apply`'
                  % (old, new))
        return
    print(__doc__)


if __name__ == '__main__':
    main()
