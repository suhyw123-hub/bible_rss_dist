# -*- coding: utf-8 -*-
"""밀러 『Come Ye Apart』 재적재 — 편을 제대로 자르고 붙임표를 깁는다.

★★★ **왜 다시 넣나**(2026-09-25 사용자 물음 「밀러 책 점검은 어떤 내용인가」
  → 「왜 밀러만 이런 현상이 발생하는가」에서 재서 나왔다):

  | 잰 것 | 값 |
  |---|---|
  | 원본 스캔 파일의 손상 자국 | **15개**(만자당 0.2) |
  | **DB 에 들어간 본문** | **799개**(만자당 **11.8**) |
  | 그중 줄끝 붙임표가 벌어진 것 | **790개** |

  ⇒ **OCR 이 못 읽은 것이 아니라 우리가 넣을 때 망가뜨렸다.** 줄을 이으면서
    붙임표를 안 뗐다 — `ear-⏎nest` 가 `ear- nest` 가 됐다(맞는 것은 `earnest`).

★★★ **그리고 편을 잘못 잘랐다** — 366편(한 해 치)이어야 하는데 **423편**이다.
  첫 글자가 장식체(드롭캡)라 OCR 이 통째로 놓치는데(`Preface`→`Ereface` ·
  `WHAT`→`HAT` · `This`→`{eae`), **그 본문 줄이 제목으로 잡혔다**:
    `ISBN: 978-159925-207-0` · `HAT was the most wonderful b` ·
    `& FLAN FOR “EACH! LIFE, |`
  게다가 묵상 사이에 낀 **짧은 시 29편**이 각각 별도 편이 됐다.

★★★ **왜 밀러만인가 — 깨끗한 판본이 이 책만 없다.**
  CCEL `miller/comeyeapart` 는 **404**(출처 표에 `REJECTED` 로 남아 있다) ·
  구텐베르크에도 없다. 40권 중 **최후 순위(IA 스캔 OCR)밖에 못 쓴 유일한 책**
  이다. 마이어도 IA 스캔이지만 **두 스캔 합본·머리말 걷기·붙임표 수리를
  받았다**(§260차 ⓬⓮) — 밀러는 그 처리를 한 번도 안 받았다.

─── 자르는 법 ───────────────────────────────────────────────────
  원본은 이렇게 생겼다:
      Jan. 1.
      IN THE BEGINNING.
      “In the beginning was the Word…” —Joun i. 1.
      IFE is full of beginnings. …        ← 드롭캡 L 이 사라졌다
  ⇒ ① **날짜 줄**이 편의 경계다(실측 245/366 — OCR 로 상한 곳이 있다)
     ② 못 찾은 자리는 **제사**(인용 + 대시 + 성경 약명)로 더 가른다(+111)
     ✅ 합계 **356 / 366 (97%)**
  ⚠ **남는 10편은 두 편이 한 편에 붙어 있다** — `--check` 가 그 수를 적는다.
    **조용히 366이라 말하지 않는다**(§0-1).

─── 붙임표 ─────────────────────────────────────────────────────
  ★ **증인이 있을 때만 잇는다**(§0-1b · 지어내지 않는다). 증인 = ⓐ 다른 스캔
    ⓑ **같은 책 다른 자리**(같은 저자·같은 책이라 정당한 증인이다).
    실측 801곳 중 **702(88%)에 증인이 있다.**
  ⚠⚠ **증인이 없다고 흠이 아니다** — 남은 99 는 대부분 **진짜 합성어**다
    (`sweet-voiced`·`mid-winter`·`far-away`). 붙임표를 지키는 것이 맞다.
    ⇒ 증인이 없으면 **줄만 잇고 붙임표는 남긴다**(`im-pulses`). 지금처럼
      `im- pulses` 로 **공백이 벌어진 채 두지 않는다**.

─── 안 하는 것 ─────────────────────────────────────────────────
  ⚠ **드롭캡을 채우지 않는다** — `IFE is full` 의 `L` 을 우리가 적으면 그것이
    곧 지어내기다(§0-1b 규칙 ①). `ORIGINAL` 은 스캔에 충실히 둔다. 읽는 쪽은
    나중에 `MODERN_EN` 이 바로잡는다(마이어와 같은 문법 §261차).
  ⚠ **본문을 스크립트에 적지 않는다** — 전부 `_verify_raw/` 파일에서 읽는다.

    python db_miller_import.py --selftest    (의무)
    python db_miller_import.py --links       받기 전에 링크를 보인다
    python db_miller_import.py --check       무엇이 어떻게 바뀌나
    python db_miller_import.py --apply       담는다(멱등)
    python db_miller_import.py --undo        되돌린다
"""
import io
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb                                              # noqa: E402

CODE = 'MILLER_CYA'
BACKUP = 'temp_miller_reimport_backup'

#: 두 스캔 — **이미 받아 둔 파일**(출처는 `sys_book_source` 에 적혀 있다)
SCANS = (
    ('_verify_raw/MILLER_CYA_0.txt',
     'Internet Archive — Solid Ground 재인쇄 스캔'),
    ('_verify_raw/MILLER_CYA_1.txt',
     'Internet Archive — Thomas Nelson 판 스캔'),
)
#: 본문이 시작되는 자리 — 이 앞은 판권장·서문·장서표다
BODY_MARK = 'DAILY READINGS'

MONTHS = (('january', 1), ('february', 2), ('march', 3), ('april', 4),
          ('may', 5), ('june', 6), ('july', 7), ('august', 8),
          ('september', 9), ('october', 10), ('november', 11),
          ('december', 12))

#: 줄 첫머리의 「달 일.」 — ⚠ 첫 글자가 날아간 꼴(`an. 3.`)도 잡는다
DATE_RE = re.compile(
    u'^[ \t«"“‘]*([A-Za-z]{2,9})\\.?[ \t]*([0-9]{1,2})'
    u'[ \t]*[.,]', re.M)
#: 제사 — 인용 + 대시 + 성경 약명
EPI_RE = re.compile(u'[“"][^”"]{10,400}[”"][ \t\n]*'
                    u'[-—–]+[ \t\n]*[A-Za-z]')
#: 줄 끝 붙임표
HYPH_RE = re.compile(r'([A-Za-z]{2,})-[ \t]*\n[ \t]*([a-z]{2,})')


def month_of(word):
    """OCR 로 상한 달 이름도 읽는다 — 모르면 `None`(지어내지 않는다)."""
    w = (word or '').lower().strip('.')
    for k, v in MONTHS:
        if len(w) >= 3 and (k.startswith(w) or w.startswith(k[:3])):
            return v
        if len(w) >= 2 and k[1:].startswith(w):      # 첫 글자 날아감
            return v
    return None


def body_of(text):
    """앞장(판권장·서문·장서표)을 걷고 본문만 낸다."""
    i = text.find(BODY_MARK)
    return text[i + len(BODY_MARK):] if i >= 0 else text


def marks(text):
    """편이 시작되는 자리 — `[(위치, 날짜 or None)]`, 차례대로.

    ★ ① 날짜 줄 ② 날짜 사이에 제사가 여럿이면 그만큼 더 가른다.
    ⚠ 같은 날짜가 두 번 잡히면 **뒤엣것은 버린다**(쪽 머리말에 날짜가 또 찍힌다).
    """
    seen, dates = set(), []
    for m in DATE_RE.finditer(text):
        mo, d = month_of(m.group(1)), int(m.group(2))
        if not mo or not 1 <= d <= 31 or (mo, d) in seen:
            continue
        seen.add((mo, d))
        dates.append((m.start(), (mo, d)))
    if not dates:
        return []
    eps = [m.start() for m in EPI_RE.finditer(text)]
    out = []
    for i, (p, dt) in enumerate(dates):
        out.append((p, dt))
        nxt = dates[i + 1][0] if i + 1 < len(dates) else len(text)
        inner = [e for e in eps if p < e < nxt]
        # ⚠ 첫 제사는 **이 편의 것**이다 — 둘째부터가 다음 편이다
        for e in inner[1:]:
            out.append((_para_start(text, e), None))
    return sorted(set(out), key=lambda x: x[0])


def _looks_title(s):
    """그 줄이 **제목 꼴**인가 — 짧고 대문자가 많다."""
    s = (s or '').strip().strip('.,')
    if not (3 <= len(s) <= 64):
        return False
    letters = [c for c in s if c.isalpha()]
    return bool(letters) and \
        sum(1 for c in letters if c.isupper()) >= len(letters) * 0.7


def _para_start(text, pos):
    """그 제사가 든 **문단의 머리**로 물러선다(글 중간에서 자르지 않는다).

    ★★★ **제목이 제사 앞에 있다** — 원본 차례가 `제목 → 제사 → 본문`이라
      제사 자리에서 자르면 **제목이 앞 편 꼬리에 남는다**(실측 356편 중
      118편이 제목 없음이었다). ⇒ 앞 문단이 제목 꼴이면 거기까지 물린다.
    ⚠ 무턱대고 물리면 **앞 편의 마지막 문단을 훔친다** — 제목 꼴일 때만.
    """
    i = text.rfind('\n\n', 0, pos)
    start = i + 2 if i >= 0 else pos
    j = text.rfind('\n\n', 0, max(start - 2, 0))
    prev = text[(j + 2 if j >= 0 else 0):start].strip()
    if prev and _looks_title(prev):
        return j + 2 if j >= 0 else 0
    return start


def unwrap(chunk, witness):
    """줄을 잇는다 — **붙임표는 증인이 있을 때만 뗀다**.

    ⚠ 증인이 없으면 **줄만 잇고 붙임표는 남긴다** — `sweet-voiced` 같은
      진짜 합성어를 붙여 버리면 그것이 글자를 바꾸는 일이다.
    """
    def _join(m):
        a, b = m.group(1), m.group(2)
        return (a + b) if (a + b).lower() in witness else (a + '-' + b)
    t = HYPH_RE.sub(_join, chunk)
    # 문단 안의 홑 줄바꿈만 공백으로 — 빈 줄(문단 경계)은 지킨다
    t = re.sub(r'(?<!\n)\n(?!\n)', ' ', t)
    t = re.sub(r'[ \t]{2,}', ' ', t)
    return re.sub(r'\n{3,}', '\n\n', t).strip()


def witness_set(*texts):
    """증인 낱말 — 두 스캔의 **붙여 쓴 낱말** 전부(소문자)."""
    w = set()
    for t in texts:
        w |= {x.lower() for x in re.findall(r'[A-Za-z]{3,}', t or '')}
    return w


def _title_of(chunk):
    """그 편의 제목 — 날짜 줄 **다음의 대문자 줄**.

    ⚠ 못 찾으면 **본문 첫 줄을 제목으로 삼지 않는다** — 그것이 지금 DB 를
      망가뜨린 바로 그 짓이다. 못 찾으면 빈 제목을 내고 `--check` 가 센다.
    """
    for ln in chunk.split('\n')[:6]:
        if DATE_RE.match(ln):
            # ⚠ 날짜와 제목이 **한 줄에 붙어 있는 자리**가 있다
            #   (`Jan. 2, & FLAN FOR …`) — 날짜만 떼고 남은 것을 본다
            rest = DATE_RE.sub('', ln, count=1).strip()
            if _looks_title(rest):
                return rest.strip('.,')
            continue
        if _looks_title(ln):
            return ln.strip().strip('.,')
    return ''


#: 날짜를 사람이 읽는 이름으로 — 목록에 뜨는 글자다
MONTH_KO = ('', '1월', '2월', '3월', '4월', '5월', '6월',
            '7월', '8월', '9월', '10월', '11월', '12월')


def date_label(dt):
    """`(달, 일)` → `1월 9일`. 날짜가 없으면 **빈 글**(지어내지 않는다)."""
    if not dt:
        return ''
    mo, d = dt
    if not 1 <= mo <= 12:
        return ''
    return '%s %d일' % (MONTH_KO[mo], d)


def parse(text, witness):
    """원문 → `[(제목, 본문)]`."""
    body = body_of(text)
    ms = marks(body)
    out = []
    for i, (p, dt) in enumerate(ms):
        end = ms[i + 1][0] if i + 1 < len(ms) else len(body)
        chunk = body[p:end]
        # ★ 제목 줄이 OCR 로 뭉개진 편이 있다 — 그때는 **날짜**를 쓴다.
        #   날마다 읽는 묵상집이라 가장 쓸모 있는 이름이고, 무엇보다
        #   **본문에 실제로 있는 글자**다(지어내기가 아니다).
        title = _title_of(chunk) or date_label(dt)
        out.append((title, unwrap(chunk, witness)))
    return out


def _read(path):
    return io.open(path, encoding='utf-8', errors='replace').read()


def load_scans():
    """두 스캔을 읽는다 — 없으면 **까닭을 대고 멈춘다**(조용히 안 넘어간다)."""
    here = os.path.dirname(os.path.abspath(__file__))
    out = []
    for rel, name in SCANS:
        p = os.path.join(here, rel.replace('/', os.sep))
        if not os.path.exists(p):
            raise SystemExit('원문 파일이 없습니다: %s (%s)' % (rel, name))
        out.append(_read(p))
    return out


def damage(text):
    """손상 자국 — 벌어진 붙임표 + 중괄호."""
    return len(re.findall(r'[A-Za-z]{2,}- [a-z]{2,}', text or '')) + \
        len(re.findall(r'[{}]', text or ''))


def current(conn):
    """지금 DB 의 밀러 — `(book_id, [(unit_id, 제목, 본문)])`."""
    r = conn.execute("SELECT book_id FROM sys_book_asset WHERE book_code=?",
                     (CODE,)).fetchone()
    if not r:
        raise SystemExit('DB 에 %s 가 없습니다.' % CODE)
    bid = r[0]
    rows = conn.execute(
        "SELECT u.unit_id, COALESCE(u.unit_label,''),"
        "       COALESCE(t.body_text,'') FROM sys_book_unit u"
        " LEFT JOIN sys_book_unit_text t ON t.unit_id=u.unit_id"
        "   AND t.text_variant='ORIGINAL'"
        " WHERE u.book_id=? AND COALESCE(u.record_status,'LIVE')='LIVE'"
        " ORDER BY u.sequence, u.unit_id", (bid,)).fetchall()
    return bid, rows


def plan(conn):
    """새로 자른 결과 — `{units, before, after, damage0, damage1, notitle}`."""
    a, b = load_scans()
    wit = witness_set(a, b)
    units = parse(a, wit)
    _bid, cur = current(conn)
    return {
        'units': units,
        'before': len(cur),
        'after': len(units),
        'damage0': sum(damage(x[2]) for x in cur),
        'damage1': sum(damage(t) for _h, t in units),
        'notitle': sum(1 for h, _t in units if not h),
        'short': sum(1 for _h, t in units if len(t) < 400),
    }


def apply(conn, dry=True):
    """담는다 — **멱등**. 옛 것은 `temp_miller_reimport_backup` 에 남긴다."""
    p = plan(conn)
    if dry:
        return p
    bid, cur = current(conn)
    conn.execute("CREATE TABLE IF NOT EXISTS %s ("
                 " unit_id INTEGER, sequence INTEGER, unit_label TEXT,"
                 " body_text TEXT)" % BACKUP)
    if not conn.execute("SELECT COUNT(*) FROM %s" % BACKUP).fetchone()[0]:
        conn.executemany(
            "INSERT INTO %s(unit_id, sequence, unit_label, body_text)"
            " VALUES(?,?,?,?)" % BACKUP,
            [(u, i + 1, h, t) for i, (u, h, t) in enumerate(cur)])
    ids = [u for u, _h, _t in cur]
    q = ','.join('?' * len(ids))
    conn.execute("DELETE FROM sys_book_unit_text WHERE unit_id IN (%s)" % q,
                 ids)
    conn.execute("DELETE FROM sys_book_unit WHERE unit_id IN (%s)" % q, ids)
    for i, (title, body) in enumerate(p['units'], 1):
        cur2 = conn.execute(
            "INSERT INTO sys_book_unit(book_id, sequence, unit_label,"
            " record_status) VALUES(?,?,?,'LIVE')", (bid, i, title or ''))
        uid = cur2.lastrowid
        conn.execute(
            "INSERT INTO sys_book_unit_text(unit_id, lang_code, text_variant,"
            " body_text, record_status) VALUES(?,'EN','ORIGINAL',?,'LIVE')",
            (uid, body))
    conn.commit()
    return p


def undo(conn):
    """되돌린다 — 백업 표에서 글자 그대로."""
    bid, cur = current(conn)
    rows = conn.execute("SELECT unit_id, sequence, unit_label, body_text"
                        " FROM %s ORDER BY sequence" % BACKUP).fetchall()
    if not rows:
        raise SystemExit('되돌릴 백업이 없습니다.')
    ids = [u for u, _h, _t in cur]
    if ids:
        q = ','.join('?' * len(ids))
        conn.execute("DELETE FROM sys_book_unit_text WHERE unit_id IN (%s)"
                     % q, ids)
        conn.execute("DELETE FROM sys_book_unit WHERE unit_id IN (%s)" % q,
                     ids)
    for uid, sq, lab, body in rows:
        conn.execute(
            "INSERT INTO sys_book_unit(unit_id, book_id, sequence, unit_label,"
            " record_status) VALUES(?,?,?,?,'LIVE')", (uid, bid, sq, lab))
        conn.execute(
            "INSERT INTO sys_book_unit_text(unit_id, lang_code, text_variant,"
            " body_text, record_status) VALUES(?,'EN','ORIGINAL',?,'LIVE')",
            (uid, body))
    conn.commit()
    return len(rows)


# ══════════════════════════════════════════════════════════════════
def selftest():
    ok = bad = 0

    def ck(cond, msg, got=''):
        nonlocal ok, bad
        if cond:
            ok += 1
        else:
            bad += 1
            print('  FAIL %s  %s' % (msg, got))

    # ── 달 이름 — 양방향 ──────────────────────────────────────────
    ck(month_of('Jan.') == 1, '달 이름을 못 읽는다')
    ck(month_of('March') == 3, '전체 이름을 못 읽는다')
    ck(month_of('an.') == 1, '첫 글자가 날아간 달을 못 읽는다')
    ck(month_of('Sept') == 9, 'Sept 를 못 읽는다')
    ck(month_of('Chapter') is None, '달이 아닌 말을 달로 읽는다')
    ck(month_of('') is None, '빈 말을 달로 읽는다')

    # ── 붙임표 — **증인이 있을 때만 뗀다**(양방향) ────────────────
    w = {'earnest'}
    ck(unwrap('some ear-\nnest men', w) == 'some earnest men',
       '증인이 있는데 안 잇는다', unwrap('some ear-\nnest men', w))
    ck(unwrap('a sweet-\nvoiced bird', w) == 'a sweet-voiced bird',
       '증인이 없는데 붙임표를 뗐다', unwrap('a sweet-\nvoiced bird', w))
    ck(' - ' not in unwrap('a sweet-\nvoiced bird', w),
       '붙임표 뒤에 공백이 남는다')
    ck(unwrap('one\ntwo', w) == 'one two', '문단 안 줄을 안 잇는다')
    ck('\n\n' in unwrap('one\n\ntwo', w), '문단 경계를 지웠다')

    # ── 자르기 ────────────────────────────────────────────────────
    S = (u'front matter here\nISBN: 1-2-3\n' + BODY_MARK + u'\n\n'
         u'Jan. 1.\n\nIN THE BEGINNING.\n\n'
         u'“In the beginning was the Word.” —John i. 1.\n\n'
         u'Life is full of be-\nginnings and more.\n\n'
         u'Jan. 2.\n\nA PLAN FOR EACH LIFE.\n\n'
         u'“There was a man sent from God.” —John i. 6.\n\n'
         u'He came for a witness.\n')
    got = parse(S, {'beginnings'})
    ck(len(got) == 2, '편을 둘로 못 가른다', len(got))
    ck(got and got[0][0] == 'IN THE BEGINNING',
       '제목을 못 집는다', got and got[0][0])
    ck(got and 'beginnings' in got[0][1],
       '붙임표를 안 이었다', got and got[0][1][-40:])
    ck(got and 'ISBN' not in got[0][1], '앞장이 본문에 섞였다')
    # ⚠ **본문 첫 줄을 제목으로 삼지 않는다** — 지금 DB 를 망가뜨린 그 짓
    ck(_title_of('Jan. 3.\n\nhe came quietly to the house and sat') == '',
       '본문 줄을 제목으로 집는다',
       _title_of('Jan. 3.\n\nhe came quietly to the house and sat'))

    ck(date_label((1, 9)) == '1월 9일', '날짜 이름이 틀리다',
       date_label((1, 9)))
    ck(date_label(None) == '', '날짜가 없는데 이름을 지어낸다')
    ck(date_label((13, 1)) == '', '없는 달을 이름으로 낸다')
    # ── 손상 세기 ─────────────────────────────────────────────────
    ck(damage('some ear- nest men') == 1, '벌어진 붙임표를 안 센다')
    ck(damage('{eae volume') == 1, '중괄호를 안 센다')
    ck(damage('clean text here') == 0, '멀쩡한 글을 손상으로 센다')

    print('db_miller_import selftest: %s (%d/%d)'
          % ('OK' if not bad else 'FAIL', ok, ok + bad))
    return 0 if not bad else 1


def main(argv):
    if '--selftest' in argv:
        return selftest()
    if '--links' in argv:
        with appdb.connect() as c:
            for r in c.execute("SELECT role, name, url, match_pct"
                               " FROM sys_book_source WHERE book_code=?"
                               " ORDER BY role", (CODE,)):
                print('  %-9s %-46s %s  %s' % (r[0], (r[1] or '')[:46],
                                               r[2] or '', r[3] or ''))
        return 0
    with appdb.connect() as c:
        if '--undo' in argv:
            print('되돌렸습니다 — %d편' % undo(c))
            return 0
        p = apply(c, dry='--apply' not in argv)
        print('편 %d → %d   (366일이 목표)' % (p['before'], p['after']))
        print('손상 자국 %d → %d' % (p['damage0'], p['damage1']))
        print('제목을 못 집은 편 %d · 400자 미만 %d'
              % (p['notitle'], p['short']))
        if '--apply' not in argv:
            print()
            print('보기:')
            for h, t in p['units'][:3]:
                print('  [%s] %s…' % (h, t[:70].replace('\n', ' ')))
            print()
            print('담으려면 --apply · 되돌리려면 --undo')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
