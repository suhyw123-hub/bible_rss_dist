# -*- coding: utf-8 -*-
"""onboarding.py — 첫 실행 설정 마법사 (언어·국가·기본역본·개인정보 동의).

run.py 에서 **앱 빌드 전**에 `maybe_run_first(master)` 호출 → first_run 이면 모달 표시,
선택값을 user_config 에 기록(앱이 그 값으로 빌드). 비-첫실행이면 즉시 반환.
전부 로컬 저장 · IP/위치 미수집. 미동의도 전기능 사용 가능(opt-in).
"""
import tkinter as tk
from tkinter import ttk

import appdb
import i18n
import lang_config
import ads

# 언어 → 추천 기본 역본
DEFAULT_VERSION_BY_LANG = {
    'KO': 'KRV', 'EN': 'BSB', 'ZH': 'CUV', 'ZHT': 'CUV', 'JA': 'JLV',
    'DE': 'GerElb', 'FR': 'FreJND', 'ES': 'SpaRV', 'RU': 'RusSyn',
    'PT': 'PorBL', 'AR': 'ARB',
}


def _cfg_get(db, key, default=None):
    try:
        with appdb.connect(db) as c:
            r = c.execute("SELECT config_val FROM user_config WHERE config_key=?", (key,)).fetchone()
        return r[0] if r and r[0] is not None else default
    except Exception:
        return default


def _cfg_set(db, key, val):
    with appdb.connect(db) as c:
        if c.execute("SELECT 1 FROM user_config WHERE config_key=?", (key,)).fetchone():
            c.execute("UPDATE user_config SET config_val=? WHERE config_key=?", (val, key))
        else:
            c.execute("INSERT INTO user_config(config_key,config_val) VALUES(?,?)", (key, val))
        c.commit()


def needs_onboarding(db):
    return _cfg_get(db, 'first_run_done', '0') != '1'


def _guess_lang(db, ui_codes):
    """OS 로캘/국가 → UI 언어 추정(없으면 KO). 마법사 초기 표시 언어."""
    cc = ads.default_country()
    by_country = {'KR': 'KO', 'US': 'EN', 'GB': 'EN', 'CA': 'EN', 'AU': 'EN',
                  'JP': 'JA', 'CN': 'ZH', 'TW': 'ZHT', 'HK': 'ZHT',
                  'DE': 'DE', 'AT': 'DE', 'CH': 'DE', 'FR': 'FR', 'ES': 'ES',
                  'MX': 'ES', 'BR': 'PT', 'PT': 'PT', 'RU': 'RU', 'SA': 'AR', 'AE': 'AR'}
    g = by_country.get(cc, 'KO')
    return g if g in ui_codes else (ui_codes[0] if ui_codes else 'KO')


class OnboardingDialog(tk.Toplevel):
    def __init__(self, master, db_path):
        super().__init__(master)
        self.db = db_path
        self.title(i18n.t('ONB_TITLE', '환영합니다'))
        self.geometry('460x520')
        self.resizable(False, False)
        try:
            self.transient(master); self.grab_set()
        except Exception:
            pass

        self._ui_codes = lang_config.ui_langs() or ['KO', 'EN']
        # 버전 목록(FULL 우선)
        with appdb.connect(self.db) as c:
            self._vers = c.execute(
                "SELECT version_code, COALESCE(display_name, version_name, version_code), lang_code "
                "FROM bible_version ORDER BY CASE coverage_scope WHEN 'FULL' THEN 0 ELSE 1 END, "
                "version_code COLLATE NOCASE").fetchall()
        self._vcodes = [v[0] for v in self._vers]

        # 초기 언어
        init_lang = _guess_lang(self.db, self._ui_codes)
        try:
            i18n.load(self.db, init_lang)
        except Exception:
            pass

        self._body = tk.Frame(self, bg='#FFFFFF')
        self._body.pack(fill='both', expand=True)
        self._render(init_lang, country=ads.default_country(),
                     ver=DEFAULT_VERSION_BY_LANG.get(init_lang), consent=False)

    # ── 렌더(언어 바뀌면 재구성) ──
    def _render(self, lang, country, ver, consent):
        for w in self._body.winfo_children():
            w.destroy()
        f = self._body

        tk.Label(f, text=i18n.t('ONB_TITLE', '환영합니다'), bg='#FFFFFF',
                 font=('Malgun Gothic', 14, 'bold'), fg='#1A5276').pack(anchor='w', padx=18, pady=(16, 2))
        tk.Label(f, text=i18n.t('ONB_INTRO', '시작 전에 몇 가지만 설정합니다. 모두 나중에 [지원/설정]에서 변경할 수 있습니다.'),
                 bg='#FFFFFF', fg='#555', wraplength=420, justify='left',
                 font=('Malgun Gothic', 9)).pack(anchor='w', padx=18, pady=(0, 10))

        # 언어
        tk.Label(f, text=i18n.t('SET_UILANG', 'UI 언어'), bg='#FFFFFF',
                 font=('Malgun Gothic', 10, 'bold')).pack(anchor='w', padx=18)
        self._lang_cb = ttk.Combobox(f, state='readonly', width=30,
                                     values=[f'{lang_config.lang_name(c)} ({lang_config.std_code(c)})'
                                             for c in self._ui_codes])
        if lang in self._ui_codes:
            self._lang_cb.current(self._ui_codes.index(lang))
        self._lang_cb.pack(anchor='w', padx=18, pady=(2, 8))
        self._lang_cb.bind('<<ComboboxSelected>>', self._on_lang_change)

        # 국가
        tk.Label(f, text=i18n.t('SET_COUNTRY', '국가/지역'), bg='#FFFFFF',
                 font=('Malgun Gothic', 10, 'bold')).pack(anchor='w', padx=18)
        self._ccodes = [c for c, _ in ads.COUNTRIES]
        self._country_cb = ttk.Combobox(f, state='readonly', width=30,
                                        values=[n for _, n in ads.COUNTRIES])
        if country in self._ccodes:
            self._country_cb.current(self._ccodes.index(country))
        self._country_cb.pack(anchor='w', padx=18, pady=(2, 8))

        # 기본 역본
        tk.Label(f, text=i18n.t('SET_DEFAULT_VER', '기본 버전'), bg='#FFFFFF',
                 font=('Malgun Gothic', 10, 'bold')).pack(anchor='w', padx=18)
        self._ver_cb = ttk.Combobox(f, state='readonly', width=34,
                                    values=[f'{nm} ({code})' for code, nm, _ in self._vers])
        if ver in self._vcodes:
            self._ver_cb.current(self._vcodes.index(ver))
        elif self._vcodes:
            self._ver_cb.current(0)
        self._ver_cb.pack(anchor='w', padx=18, pady=(2, 12))

        # 개인정보 동의(opt-in)
        pf = tk.Frame(f, bg='#F4F8FB', bd=1, relief='solid')
        pf.pack(fill='x', padx=18, pady=(2, 10))
        tk.Label(pf, text=i18n.t('SET_PRIV_NOTE',
                 '개인정보·노트 내용·IP·국가는 수집하지 않고 카운트만 익명 수집합니다. 동의 안 해도 모든 기능 사용 가능.'),
                 bg='#F4F8FB', fg='#555', wraplength=410, justify='left',
                 font=('Malgun Gothic', 8)).pack(anchor='w', padx=8, pady=(6, 2))
        self._consent_var = tk.IntVar(value=1 if consent else 0)
        tk.Checkbutton(pf, text=i18n.t('ONB_CONSENT', '익명 이용통계에 동의합니다 (선택)'),
                       variable=self._consent_var, bg='#F4F8FB',
                       font=('Malgun Gothic', 9)).pack(anchor='w', padx=8, pady=(0, 6))

        tk.Button(f, text='  ' + i18n.t('ONB_START', '시작하기') + '  ',
                  bg='#1E8449', fg='white', bd=0, font=('Malgun Gothic', 11, 'bold'),
                  padx=20, pady=6, command=self._finish).pack(pady=(4, 8))

    def _on_lang_change(self, _e=None):
        li = self._lang_cb.current()
        if li < 0:
            return
        lang = self._ui_codes[li]
        # 현재 선택값 보존
        ci = self._country_cb.current()
        country = self._ccodes[ci] if ci >= 0 else ads.default_country()
        consent = bool(self._consent_var.get())
        try:
            i18n.load(self.db, lang)
        except Exception:
            pass
        # 언어 바뀌면 추천 역본 재설정
        ver = DEFAULT_VERSION_BY_LANG.get(lang)
        self._render(lang, country=country, ver=ver, consent=consent)
        self.title(i18n.t('ONB_TITLE', '환영합니다'))

    def _finish(self):
        li = self._lang_cb.current()
        if li >= 0:
            _cfg_set(self.db, 'user_lang', self._ui_codes[li])
        ci = self._country_cb.current()
        if ci >= 0:
            ads.set_country(self.db, self._ccodes[ci])
        vi = self._ver_cb.current()
        if vi >= 0:
            _cfg_set(self.db, 'v1_code', self._vcodes[vi])
        # 동의(opt-in)
        try:
            import usage_stats
            usage_stats.set_consent(bool(self._consent_var.get()))
        except Exception:
            pass
        _cfg_set(self.db, 'first_run_done', '1')
        try:
            self.grab_release()
        except Exception:
            pass
        self.destroy()


def maybe_run_first(master, db_path=None):
    """run.py 에서 앱 빌드 전 호출. first_run 이면 모달 마법사 표시(완료까지 블록)."""
    db = db_path or appdb.MAIN_DB
    try:
        if not needs_onboarding(db):
            return
        dlg = OnboardingDialog(master, db)
        master.wait_window(dlg)
    except Exception as e:
        print(f'[onboarding] skip: {e}')
