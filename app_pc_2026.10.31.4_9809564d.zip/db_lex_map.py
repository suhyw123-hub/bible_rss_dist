# -*- coding: utf-8 -*-
"""원어 낱말 대응·의미영역 — **로컬 전용 집필 보조** (영구 도구, §0-5 KEEP)

`db_wlc_lookup`(구약) · `db_gnt_verify`(신약)가 「그 낱말이 어느 절에 있는가」를 답한다면,
이 도구는 **「그 낱말이 다른 언약에서는 무엇인가」와 「같은 뜻 갈래에 무엇이 있는가」**를 답한다.
주요용어(§12-0)에 앵커를 달 때 쓴다.

**왜 필요한가.** 「헤세드」에 신약 앵커 `G1656` 을 손으로 골라 달았는데, 근거가 호 6:6 을
예수께서 인용하신 자리 **한 건**이었다. 짐작이다. 세어 보니 89%였지만 **세기 전에는
알 수 없었다.** 용어 30~50개에 앵커를 손으로 고르면 그만큼 짐작이 쌓인다.

**자료 (둘 다 CC BY 4.0)**
  · **MACULA Hebrew** (Clear Bible / Biblica) — 히브리 낱말 475,911개에 **70인역 헬라어 대응**
    (`greekstrong`)이 붙어 있다. 이것이 구약↔신약 대응표다. 우리가 만드는 것이 아니라
    **70인역 번역자들이 실제로 고른 낱말**을 세는 것이다.
  · **MACULA Greek** (Nestle1904) — 헬라어 낱말의 **Louw-Nida 의미영역**(`ln`).
    Strong 이 낱말 **형태**로 묶는다면 Louw-Nida 는 **뜻**으로 묶는다 —
    명사 ἔλεος(G1656)와 동사 ἐλεέω(G1653)가 LN 88.76 한 자리에 온다. Strong 으로는 못 묶는다.

★ **배포하지 않는다.** `lexmap.db`(gitignore). `wlc_verify.db` · `gnt_verify.db` 와 같은 취급 —
  집필 중에만 쓰고, 배포물에는 여기서 **고른 결과**(앵커 몇 줄)만 들어간다.

★ **Strong 을 버리지 않는다.** 모든 자료가 Strong 으로 서로를 가리키므로 공통 열쇠다.
  이 도구는 그 위에 두 층을 얹을 뿐이다.

    Strong 번호   ← 앵커 · 절 목록          (그대로)
       ↓
    LXX 대응      ← MACULA Hebrew           구약↔신약이 수로 이어진다
       ↓
    의미영역      ← Louw-Nida / SDBH        형태가 달라도 뜻으로 묶인다

  --selftest            (의무)
  --build               lexmap.db 생성 (MACULA 두 파일에서)
  --pair  H2617|G1656   그 낱말의 반대편 언약 대응 (횟수·비율)
  --sense G1656         같은 의미영역에 든 낱말
  --check               적재된 용어의 앵커를 대응표와 대조 — **빠진 앵커를 잡는다**
"""
import io, os, re, sys, sqlite3, collections

APP = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(APP, '_gnt_raw')
OUT = os.path.join(APP, 'lexmap.db')            # ★ 배포 대상 아님
HEB = os.path.join(RAW, 'macula-hebrew.tsv')
GRK = os.path.join(RAW, 'macula-greek.tsv')

# ⚠ MACULA 의 Strong 표기가 우리와 다르다. 맞추지 않으면 조용히 0건이 된다.
#   히브리: `2617` · `0871a` · `0871b`  — 네 자리 padding + 동음이의 letter 꼬리
#   헬라  : `976` · `1656`              — padding 없음
#   우리  : `H2617` · `G1656`           — padding 없는 정수 (wlc/gnt_verify 와 같은 꼴)
NUM = re.compile(r'^0*(\d+)')


def norm(v, lang):
    """`0871a` → `H871` · `1656` → `G1656`. 못 읽으면 ''."""
    m = NUM.match((v or '').strip())
    return ('%s%d' % (lang, int(m.group(1)))) if m else ''


def _cols(path):
    with io.open(path, encoding='utf-8', errors='replace') as f:
        return {k: i for i, k in enumerate(f.readline().rstrip('\n').split('\t'))}


def build():
    for p in (HEB, GRK):
        if not os.path.exists(p):
            raise SystemExit('자료 없음: %s\n  Clear-Bible/macula-* 의 TSV 를 _gnt_raw/ 에 둘 것' % p)
    if os.path.exists(OUT):
        os.remove(OUT)
    db = sqlite3.connect(OUT)
    db.execute('CREATE TABLE lex_pair (he TEXT, gk TEXT, n INTEGER)')
    db.execute('CREATE TABLE lex_sense (strong TEXT, lang TEXT, domain TEXT, n INTEGER)')
    db.execute('CREATE TABLE lex_gloss (strong TEXT PRIMARY KEY, lemma TEXT, gloss TEXT)')
    db.execute('CREATE TABLE lex_meta (k TEXT PRIMARY KEY, v TEXT)')

    # ① 히브리 → 70인역 헬라어 대응
    I = _cols(HEB)
    pair = collections.Counter()
    hsense = collections.Counter()
    hgloss = {}
    nh = 0
    with io.open(HEB, encoding='utf-8', errors='replace') as f:
        f.readline()
        for ln in f:
            c = ln.rstrip('\n').split('\t')
            if len(c) < len(I):
                continue
            nh += 1
            h = norm(c[I['strongnumberx']], 'H')
            if not h:
                continue
            hgloss.setdefault(h, (c[I['lemma']].strip(), c[I['gloss']].strip()))
            g = c[I['greekstrong']].strip()
            if g and '|' not in g:                 # 두 낱말로 갈린 자리는 세지 않는다
                gk = norm(g, 'G')
                if gk:
                    pair[(h, gk)] += 1
            for k in ('coredomain', 'lexdomain'):
                d = c[I[k]].strip()
                if d:
                    hsense[(h, 'H', d)] += 1
    # ② 헬라어 의미영역 (Louw-Nida)
    J = _cols(GRK)
    gsense = collections.Counter()
    ggloss = {}
    ng = 0
    with io.open(GRK, encoding='utf-8', errors='replace') as f:
        f.readline()
        for ln in f:
            c = ln.rstrip('\n').split('\t')
            if len(c) < len(J):
                continue
            ng += 1
            g = norm(c[J['strong']], 'G')
            if not g:
                continue
            ggloss.setdefault(g, (c[J['lemma']].strip(), c[J['gloss']].strip()))
            d = c[J['ln']].strip()
            if d:
                gsense[(g, 'G', d)] += 1

    db.executemany('INSERT INTO lex_pair VALUES(?,?,?)',
                   [(h, g, n) for (h, g), n in pair.items()])
    db.executemany('INSERT INTO lex_sense VALUES(?,?,?,?)',
                   [(s, l, d, n) for (s, l, d), n in list(hsense.items()) + list(gsense.items())])
    db.executemany('INSERT OR IGNORE INTO lex_gloss VALUES(?,?,?)',
                   [(s, v[0], v[1]) for s, v in list(hgloss.items()) + list(ggloss.items())])
    db.execute('CREATE INDEX idx_pair_he ON lex_pair(he)')
    db.execute('CREATE INDEX idx_pair_gk ON lex_pair(gk)')
    db.execute('CREATE INDEX idx_sense ON lex_sense(strong)')
    db.execute('CREATE INDEX idx_sense_dom ON lex_sense(domain)')
    for k, v in (('source_he', 'MACULA Hebrew (Clear Bible / Biblica) CC BY 4.0'),
                 ('source_gk', 'MACULA Greek Nestle1904 (Clear Bible / Biblica) CC BY 4.0'),
                 ('pairs_from', 'Septuagint rendering counted per Hebrew word'),
                 ('distribute', 'NO — local authoring aid only')):
        db.execute('INSERT OR REPLACE INTO lex_meta VALUES(?,?)', (k, v))
    db.commit()
    print('  히브리 낱말 %d · 헬라 낱말 %d' % (nh, ng))
    print('  대응쌍 %d · 의미영역 %d · 뜻풀이 %d'
          % (len(pair), len(hsense) + len(gsense), len(hgloss) + len(ggloss)))
    db.close()


# ── 조회 ────────────────────────────────────────────────────────────────────
def _db():
    if not os.path.exists(OUT):
        raise SystemExit('lexmap.db 없음 — --build 를 먼저 실행할 것')
    return sqlite3.connect(OUT)


def pairs(strong, top=12):
    """[(반대편 Strong, 횟수, 비율)] — 많은 것부터. 없으면 빈 리스트."""
    db = _db()
    col, other = ('he', 'gk') if strong.startswith('H') else ('gk', 'he')
    rows = db.execute('SELECT %s, n FROM lex_pair WHERE %s=? ORDER BY n DESC' % (other, col),
                      (strong,)).fetchall()
    tot = sum(n for _, n in rows)
    gl = {}
    for s, _ in rows[:top]:
        r = db.execute('SELECT lemma,gloss FROM lex_gloss WHERE strong=?', (s,)).fetchone()
        gl[s] = r or ('', '')
    db.close()
    return [(s, n, n / tot if tot else 0, gl.get(s, ('', ''))) for s, n in rows[:top]], tot


def senses(strong, top=14):
    """같은 의미영역에 든 낱말. [(영역, [(strong, lemma, gloss, 횟수)])]"""
    db = _db()
    doms = [r[0] for r in db.execute(
        'SELECT domain FROM lex_sense WHERE strong=? ORDER BY n DESC LIMIT 3', (strong,))]
    out = []
    for d in doms:
        rows = db.execute(
            'SELECT s.strong, g.lemma, g.gloss, SUM(s.n) FROM lex_sense s'
            ' LEFT JOIN lex_gloss g ON g.strong=s.strong'
            ' WHERE s.domain=? GROUP BY s.strong ORDER BY SUM(s.n) DESC LIMIT ?', (d, top)).fetchall()
        out.append((d, rows))
    db.close()
    return out


def check_terms(conn):
    """적재된 용어의 앵커를 대응표와 대조한다.

    ⚠ **빠진 앵커를 잡는 것이 목적이다.** 구약 앵커만 달아 두면 신약 절이 통째로 빠지는데,
       화면에는 아무 표시도 안 난다 — 조용히 반쪽이 된다.
    """
    import db_term_load as T
    rows = conn.execute(
        "SELECT entity_id, entity_code FROM sys_entity_master"
        " WHERE entity_type='TERM' AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY entity_code"
    ).fetchall()
    if not rows:
        print('  적재된 용어가 없다')
        return
    for eid, code in rows:
        have = {s for _l, s, _t, _g in T.fetch_lemmas(conn, eid)}
        notes = []
        for s in sorted(have):
            ps, tot = pairs(s, top=4)
            for other, n, share, (lem, gl) in ps:
                if share >= 0.25 and other not in have:
                    notes.append('%s → **%s** %s (%s) %d회 %.0f%%'
                                 % (s, other, lem, gl[:22], n, share * 100))
        print('  %-14s 앵커 %-18s %s'
              % (code, ' '.join(sorted(have)) or '—',
                 ('빠진 것 없음' if not notes else '')))
        for x in notes:
            print('       ! %s' % x)


def selftest():
    ok = True

    def chk(label, got, want=True):
        nonlocal ok
        good = bool(got) == bool(want)
        ok &= good
        print('  [%s] %s' % ('PASS' if good else 'FAIL', label))

    # ① 번호 정규화 — 여기가 틀리면 전부 0건이 된다
    chk('히브리 padding 제거', norm('2617', 'H') == 'H2617')
    chk('히브리 letter 꼬리 제거', norm('0871a', 'H') == 'H871')
    chk('히브리 다른 꼬리도', norm('0871b', 'H') == 'H871')
    chk('헬라 padding 없는 것', norm('976', 'G') == 'G976')
    chk('헬라 네 자리', norm('1656', 'G') == 'G1656')
    chk('빈 칸은 빈 문자열', norm('', 'H') == '')
    chk('숫자 아닌 것도', norm('n/a', 'G') == '')

    if not os.path.exists(OUT):
        print('  [SKIP] lexmap.db 없음 — 내용 검사 못 함')
        print('selftest', 'PASS' if ok else 'FAIL')
        return ok

    # ② 대응표가 **살아 있는가** — 아는 답으로 확인한다.
    #    헤세드가 엘레오스로 가는 것은 70인역의 압도적 관행이다. 이것이 무너지면
    #    파싱이 반쯤 죽은 것이고, 조용히 엉뚱한 앵커를 추천하게 된다.
    ps, tot = pairs('H2617')
    top = ps[0] if ps else ('', 0, 0, ('', ''))
    chk('헤세드 H2617 대응이 있다 (총 %d회)' % tot, tot > 100)
    chk('으뜸이 엘레오스 G1656 (실제 %s %.0f%%)' % (top[0], top[2] * 100),
        top[0] == 'G1656' and top[2] > 0.7)
    ps2, tot2 = pairs('H1285')                      # 베리트 → 디아데케
    chk('베리트 H1285 → 디아데케 G1242 (실제 %s)' % (ps2[0][0] if ps2 else '—'),
        bool(ps2) and ps2[0][0] == 'G1242')
    # ③ 역방향도 되는가
    ps3, _ = pairs('G1656')
    chk('거꾸로 G1656 → H2617 (실제 %s)' % (ps3[0][0] if ps3 else '—'),
        bool(ps3) and ps3[0][0] == 'H2617')
    # ④ 의미영역이 **형태를 넘어 묶는가** — 이것이 Strong 과 다른 점이다.
    #    엘레오스(명사)와 엘레에오(동사)가 한 영역에 없으면 층을 얹을 이유가 없다.
    sn = senses('G1656')
    got = {r[0] for d, rr in sn for r in rr}
    chk('LN 이 명사 G1656 과 동사 G1653 을 묶는다', 'G1653' in got and 'G1656' in got)
    # ⑤ 없는 번호는 조용히 빈 결과
    chk('없는 번호는 빈 결과', pairs('H99999')[0] == [])

    print('selftest', 'PASS' if ok else 'FAIL')
    return ok


def _show_pair(strong):
    ps, tot = pairs(strong)
    print('%s → 반대편 언약 대응 (총 %d회)' % (strong, tot))
    for s, n, share, (lem, gl) in ps:
        print('   %-7s %-14s %-24s %5d회  %5.1f%%' % (s, lem, gl[:24], n, share * 100))


def _show_sense(strong):
    for d, rows in senses(strong):
        print('의미영역 %s' % d)
        for s, lem, gl, n in rows:
            print('   %-7s %-14s %-24s %5d회' % (s, lem or '', (gl or '')[:24], n))


if __name__ == '__main__':
    a = sys.argv
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    if '--build' in a:
        build()
    if '--pair' in a:
        _show_pair(a[a.index('--pair') + 1].upper())
    if '--sense' in a:
        _show_sense(a[a.index('--sense') + 1].upper())
    if '--check' in a:
        import appdb
        check_terms(appdb.connect())
