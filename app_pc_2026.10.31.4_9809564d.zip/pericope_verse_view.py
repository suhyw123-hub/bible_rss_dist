"""
pericope_verse_view.py
----------------------
페리코프 구절 표시 + ±5구절 확장 위젯.

entity_browser.py 우측 하단(구절 패널)에서 분리. P4 NodePanel 탭6에서도 재사용.

진입점:
  view = PericopeVerseView(parent, db_path, lang_getter, ver_getter)
  view.show_for_vid(vid)               # vid가 속한 페리코프 자동 선택
  view.show_for_pericope(pericope_id)  # 페리코프 직접 지정

내부 구조:
  - 헤더 (제목 라벨 + [+5구절] 버튼)
  - 페리코프 설명문 라벨 (PERI_DESC, 있을 때만)
  - 구절 본문 Text (스크롤)

확장 동작:
  [+5구절] 클릭 시 현재 범위에서 위로 5절·아래로 5절씩 동시에 확대.
"""

import tkinter as tk
import i18n
from tkinter import ttk
import sqlite3
# ★★ 구간 판정은 **한 문**이다(§verse_range) — `verse_id` 는 신원이고
#   차례는 `sort_order` 다. 번호로 재면 절체계 이형 구간에서 샌다.
import verse_range as _vr
import appdb
import bidi
import verse_ref                # 약명 형식·본문 시작선 (font.md §22 2단계)


def _C(role, fallback):
    """ui_theme 역할 색 — 표준 서식 (2026-08-19 사용자 지시, font.md §36)."""
    try:
        import ui_theme
        return ui_theme.C(role)
    except Exception:
        return fallback


class PericopeVerseView(tk.Frame):

    def __init__(self, parent, db_path,
                              lang_getter=None, ver_getter=None, autosize=False,
                 ext_bar=None, ext_before=None, **kwargs):
        super().__init__(parent, bg=_C('bg', 'white'), **kwargs)
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.ver_getter = ver_getter or (lambda: 'KRV')
        # autosize — 내용 줄 수만큼만 높이를 차지한다 (2026-08-19 구속사 연결
        # 설명: ±5 선택에 따라 본문 칸이 자동으로 늘고 줄어 아래 설명문·노트
        # 공간이 확보된다). 이때는 바깥에서 expand 없이 fill='x' 로 pack 한다.
        self._autosize = bool(autosize)
        self._as_w = 0

        # 현재 확장 상태
        self._peri_id = None
        self._base_start = None   # 페리코프 원본 start_vid
        self._base_end = None     # 페리코프 원본 end_vid
        self._cur_start = None    # 확장 후 start_vid
        self._cur_end = None      # 확장 후 end_vid
        self._title = ''
        self._peri_desc = ''
        self._desc_open = False   # ★ 단락 설명은 접힌 채 시작한다(2026-10-13 docs/1.txt 76-1)

        self._ext_bar = ext_bar
        self._ext_before = ext_before
        self._build()
        if self._autosize:
            # 구절 아래 공백은 **한 줄 구분 수준만** (2026-08-19 사용자 —
            # 「+5 를 늘려도 아래 공백이 여전하다. 한 줄 정도만」).
            self._txt.config(pady=4)

    # ───────── UI ─────────

    def _build(self):
        # ★ 서식 표준 (2026-08-19 사용자 지시) — 색은 전부 ui_theme 역할,
        #   글꼴은 theme_font 구역(제목·단추 'ui' · 설명 'meta' · 본문 'bible').
        #   태그에는 글꼴을 두지 않는다 — 태그 font 가 위젯 글꼴(통합폰트)을
        #   이긴다(§25 함정). 태그 색은 그릴 때마다 그 시점 테마로 다시 칠한다.
        # ★★ **밖의 줄을 받으면 머리를 안 만든다** (2026-08-31 사용자 지시
        #   「+-5구절 버튼, My Edit, M 버튼 등을 **구절단락, 흐름묵상 버튼과
        #   같은 라인**에 배치하라」).
        #   ⚠ 그전에는 이 위젯이 제 머리 줄(약 30px)을 따로 만들어, 갈래 줄
        #     바로 아래에 **줄이 하나 더** 있었다.
        #   ⚠ 밖의 줄이 없는 자리(주요용어 단락 탭)는 종전대로 제가 만든다.
        ext = getattr(self, '_ext_bar', None)
        if ext is not None:
            hdr = ext
        else:
            hdr = tk.Frame(self, bg=_C('panel', '#F8F9FA'))
            hdr.pack(fill='x')
        self._title_lbl = tk.Label(
            hdr, text='', bg=_C('panel', '#F8F9FA'),
            fg=_C('fg', '#2C3E50'), anchor='w')
        if ext is not None:
            self._title_lbl.pack(side='left', padx=(10, 0), pady=2)
        else:
            self._title_lbl.pack(side='left', padx=10, pady=4,
                                 fill='x', expand=True)
        self._expand_btn = tk.Button(
            hdr, text=i18n.t('EB_PLUS5','+5구절'), command=self._expand,
            bg=_C('accent_bg', '#AED6F1'), fg=_C('accent', '#1A5276'),
            bd=0, padx=6, pady=2, cursor='hand2', state='disabled')
        # ⚠ 밖의 줄에서는 [M] 이 이미 오른쪽 끝에 못 박혀 있다 — 이 둘은 그
        #   왼쪽에 **−5 · +5** 차례로 놓인다(`side='right'` 는 부른 차례로
        #   오른쪽부터 쌓이므로 **+5 를 나중에** 붙인다).
        if ext is None:
            self._expand_btn.pack(side='right', padx=6, pady=4)
        # [−5구절] — 원래 단락까지 되돌아간다 (2026-08-19 사용자 「+5 를 한 번
        # 누르면 영원히 유지된다. 처음으로 못 돌아간다」). 단락보다 좁혀지지는
        # 않고, 원래 범위에 닿으면 비활성.
        self._shrink_btn = tk.Button(
            hdr, text=i18n.t('EB_MINUS5','−5구절'), command=self._shrink,
            bg=_C('panel_alt', '#E5E8E8'), fg=_C('fg', '#333'),
            bd=0, padx=6, pady=2, cursor='hand2', state='disabled')
        if ext is None:
            self._shrink_btn.pack(side='right', pady=4)
        else:
            # ⚠ **[M] 앞에 못 박는다** — `side='right'` 만 쓰면 붙이는 차례에
            #   따라 M 오른쪽으로 새어 나간다(실측 `+5 | M | −5`).
            _bf = getattr(self, '_ext_before', None)
            _kw = {'before': _bf} if _bf is not None else {}
            self._shrink_btn.pack(side='right', padx=(0, 2), pady=2, **_kw)
            self._expand_btn.pack(side='right', padx=(6, 2), pady=2, **_kw)
        # ★ 2026-10-13 (docs/1.txt 76-1 사용자 「설명문은 제거하라 … 구간 설명문 버튼을 배치해서 표시하고 접을 수 있도록」) —
        #   단락 설명은 **늘 위에 펼치지 않는다**. 「단락 설명 ▾」 단추로 펴고 접는다 · 설명이 없는 단락에서는 단추가 없다.
        #   ⚠ ±5절로 넓혀도 같은 글이다 — 그 글은 **처음 단락**의 설명이라 단추 이름이 그 사실을 말한다.
        self._desc_btn = tk.Button(
            hdr, text='', command=self._toggle_desc,
            bg=_C('panel_alt', '#E5E8E8'), fg=_C('fg', '#333'),
            bd=0, padx=6, pady=2, cursor='hand2')

        # 페리코프 설명문 (있을 때만)
        self._desc_lbl = tk.Label(
            self, text='', bg=_C('panel_alt', '#E5E8E8'),
            fg=_C('fg_dim', '#6C3483'),
            anchor='w', justify='left', wraplength=600,
            padx=10, pady=5)

        # 구절 본문
        body_f = tk.Frame(self, bg=_C('bg', 'white'))
        body_f.pack(fill='both', expand=True)
        vsb = ttk.Scrollbar(body_f, orient='vertical')
        vsb.pack(side='right', fill='y')
        self._txt = tk.Text(
            body_f, wrap='word', relief='flat',
            bg=_C('bg', '#FFFEF8'),
            yscrollcommand=vsb.set,
            state='disabled', cursor='arrow',
            padx=14, pady=10, spacing1=3, spacing2=1)
        # ★ 성경 구절은 **어디에 있든 「성경」 역할**이다 (font.md §22).
        #   화면마다 크기가 달라 「같은 구절인데 다르게 느껴진다」던 것을 묶는다.
        #   제목·단추·설명 라벨도 통합폰트 구역에 등록한다.
        try:
            import theme_font
            theme_font.register(self._txt, self.db_path, 'bible')
            theme_font.register(self._title_lbl, self.db_path, 'ui')
            theme_font.register(self._expand_btn, self.db_path, 'ui')
            theme_font.register(self._desc_lbl, self.db_path, 'meta')
            theme_font.register(self._desc_btn, self.db_path, 'ui')
        except Exception:
            pass
        vsb.config(command=self._txt.yview)
        self._txt.pack(fill='both', expand=True)
        # ★ **이어지는 줄을 본문 시작선에 맞춘다** — P1 본문과 같은 규칙
        #   (2026-08-14 표준화). 이것이 없으면 둘째 줄이 절 표기 아래로
        #   흘러내려 **본문이 아니라 목록처럼** 보인다.
        # ⚠ lmargin2 값은 **첫 값일 뿐**이다 — 실제 들여쓰기는 그릴 때
        #   `verse_ref.width_hint(범위)` 가 정한다.
        self._retag()

    def _retag(self):
        """태그 색을 지금 테마로 — 렌더마다 부른다(§36-5b 동적 위젯 패턴)."""
        self._txt.tag_configure('ref', foreground=_C('accent', '#1A5276'))
        self._txt.tag_configure('body', foreground=_C('fg', '#2C3E50'),
                                lmargin1=0)
        self._txt.tag_configure('cur', background=_C('accent_bg', '#EAF2F8'))
        # 단락 설명 — 본문과 **같은 글상자** 맨 위(함께 스크롤 · 폭에 맞춰 다시 흐름)
        self._txt.tag_configure('pdesc', foreground=_C('fg_dim', '#5D6D7E'),
                                background=_C('panel_alt', '#F2F3F4'),
                                lmargin1=4, lmargin2=4, rmargin=4, spacing3=2)

    # ───────── 외부 API ─────────

    def show_verse(self, vid, context=5, end_vid=None):
        """★ 구절(또는 구간)을 **기준**으로 보인다 (2026-08-19 구속사 연결
        설명 — 「핵심 구절은 하나뿐인데 수십 개가 표시된다」).

        단락이 아니라 그 절(구간)이 기준 범위다: 기본 = 기준 ± context(문맥),
        [−5구절] 은 기준까지 되돌아가고 [+5구절] 로 더 넓힌다. 기준 전체가
        옅은 강조로 두드러진다. 단락 설명문(PERI_DESC)은 그리지 않는다 —
        설명문이 길면 좁은 칸에서 구절을 통째로 밀어내던 문제의 뿌리였다."""
        if vid is None:
            self.clear()
            return
        vid = int(vid)
        ev = int(end_vid) if end_vid else vid
        self._peri_id = -vid                  # 절 기준 표식(페리코프 id 아님)
        self._focus_vid = vid
        self._focus_end = ev
        self._base_start, self._base_end = vid, ev
        self._cur_start, self._cur_end = vid, ev
        self._title = self._range_label()     # 「창 15:6」/「창 1:2~6」 원복 제목
        self._peri_desc = ''
        self._sync_desc()
        self._expand_btn.config(state='normal')
        try:
            with appdb.connect(self.db_path) as conn:
                r = conn.execute(
                    "SELECT verse_id FROM bible_index WHERE verse_id < ? "
                    "ORDER BY verse_id DESC LIMIT ?", (vid, context)).fetchall()
                if r:
                    self._cur_start = r[-1][0]
                r = conn.execute(
                    "SELECT verse_id FROM bible_index WHERE verse_id > ? "
                    "ORDER BY verse_id ASC LIMIT ?", (ev, context)).fetchall()
                if r:
                    self._cur_end = r[-1][0]
        except Exception:
            pass
        self._render_verses(extended=True)    # 제목 = 지금 보이는 범위

    def show_for_vid(self, vid):
        """vid가 속한 페리코프(LINK 우선, 없으면 BODY)를 자동 선택.

        ★ 그 절은 본문 안에서 옅은 강조('cur' 태그)로 두드러진다 (2026-08-19
        구속사 연결 설명 화면 요구 — 문맥 속에서 마디가 보여야 한다)."""
        if vid is None:
            self.clear()
            return
        self._focus_vid = int(vid)
        self._focus_end = int(vid)
        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                row = conn.execute(
                    "SELECT pericope_id, start_vid, end_vid "
                    "  FROM sys_pericope_asset "
                    "  p WHERE p.peri_type='LINK' AND p.record_status='LIVE' "
                    "   AND " + _vr.covers_sql('p', 'start_vid', 'end_vid')
                    + " LIMIT 1", _vr.covers_args(vid)).fetchone()
                if not row:
                    row = conn.execute(
                        "SELECT pericope_id, start_vid, end_vid "
                        "  FROM sys_pericope_asset "
                        "  p WHERE p.peri_type='BODY'"
                        "   AND p.record_status='LIVE' AND "
                        + _vr.covers_sql('p', 'start_vid', 'end_vid')
                        + " LIMIT 1", _vr.covers_args(vid)).fetchone()
        except Exception as e:
            self._render_msg(f'(페리코프 조회 오류: {e})')
            return
        if not row:
            self._render_msg('(이 구절이 속한 페리코프 없음)')
            return
        self.show_for_pericope(row['pericope_id'])

    def show_for_pericope(self, pericope_id):
        """페리코프 ID로 직접 표시."""
        if pericope_id is None:
            self.clear()
            return
        try:
            lang = self.lang_getter() or 'KO'
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                meta = conn.execute(
                    "SELECT pa.start_vid, pa.end_vid, "
                    "  COALESCE(("
                    "    SELECT ta.contents FROM sys_text_asset ta "
                    "     WHERE ta.text_type='PERI_TITLE' "
                    "       AND ta.clicked_id=pa.pericope_id "
                    "       AND ta.lang_code=? AND ta.record_status='LIVE' LIMIT 1), "
                    "  ("
                    "    SELECT ta.contents FROM sys_text_asset ta "
                    "     WHERE ta.text_type='PERI_TITLE' "
                    "       AND ta.clicked_id=pa.pericope_id "
                    "       AND ta.lang_code='EN' AND ta.record_status='LIVE' LIMIT 1), "
                    "  ("
                    "    SELECT ta.contents FROM sys_text_asset ta "
                    "     WHERE ta.text_type='PERI_TITLE' "
                    "       AND ta.clicked_id=pa.pericope_id "
                    "       AND ta.lang_code='KO' AND ta.record_status='LIVE' LIMIT 1), "
                    "  '') AS title, "
                    # ⚠ 옛 폴백 `pa.peri_code` 폐기 (2026-08-19 사용자 지시) —
                    #   제목 없는 페리코프에서 GEN_08_BODY 같은 내부 코드가 샜다.
                    #   표준 제목이 없으면 아무것도 안 보이는 것이 맞다(범위 표기는
                    #   확장 시 _range_label 이 따로 만든다).
                    "  ("
                    "    SELECT ta.contents FROM sys_text_asset ta "
                    "     WHERE ta.text_type='PERI_DESC' "
                    "       AND ta.clicked_id=pa.pericope_id "
                    "       AND ta.lang_code=? AND ta.record_status='LIVE' LIMIT 1) AS peri_desc "
                    "  FROM sys_pericope_asset pa "
                    " WHERE pa.pericope_id=?",
                    (lang, lang, pericope_id)).fetchone()
        except Exception as e:
            self._render_msg(f'(페리코프 로드 오류: {e})')
            return
        if not meta:
            self._render_msg('(페리코프 없음)')
            return

        self._peri_id = pericope_id
        self._base_start = meta['start_vid']
        self._base_end = meta['end_vid']
        self._cur_start = self._base_start
        self._cur_end = self._base_end
        self._title = meta['title'] or ''
        self._peri_desc = meta['peri_desc'] or ''

        self._title_lbl.config(text=self._title)
        self._expand_btn.config(state='normal')
        self._desc_lbl.config(text=self._peri_desc)
        self._sync_desc()

        self._render_verses()

    def clear(self):
        self._peri_id = None
        self._focus_vid = None
        self._focus_end = None
        self._base_start = self._base_end = None
        self._cur_start = self._cur_end = None
        self._title_lbl.config(text='')
        self._expand_btn.config(state='disabled')
        try:
            self._shrink_btn.config(state='disabled')
        except Exception:
            pass
        self._peri_desc = ''
        self._sync_desc()
        self._fill('')

    # ───────── 내부 ─────────

    def _toggle_desc(self):
        self._desc_open = not self._desc_open
        self._sync_desc()
        if self._cur_start is not None:
            y = self._txt.yview()[0]
            self._render_verses()
            if not self._desc_open:
                self._txt.yview_moveto(0)
            elif y == 0:
                self._txt.yview_moveto(0)

    def _sync_desc(self):
        """단락 설명 단추·칸을 지금 상태로 — 설명이 없으면 단추째 감춘다."""
        has = bool(self._peri_desc)
        try:
            if has:
                self._desc_btn.config(text=i18n.t('PV_DESC_BTN', '단락 설명') + (' ▴' if self._desc_open else ' ▾'))
                if not self._desc_btn.winfo_manager():
                    self._desc_btn.pack(side='right', padx=(0, 6), pady=2)
            else:
                self._desc_btn.pack_forget()
            self._desc_lbl.pack_forget()      # 옛 라벨은 쓰지 않는다(글상자 안으로 옮겼다)
        except Exception:
            pass

    def _expand(self):
        if self._peri_id is None or self._cur_start is None:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT verse_id FROM bible_index WHERE verse_id < ? "
                    "ORDER BY verse_id DESC LIMIT 5",
                    (self._cur_start,)).fetchall()
                if rows:
                    self._cur_start = rows[-1][0]
                rows = conn.execute(
                    "SELECT verse_id FROM bible_index WHERE verse_id > ? "
                    "ORDER BY verse_id ASC LIMIT 5",
                    (self._cur_end,)).fetchall()
                if rows:
                    self._cur_end = rows[-1][0]
        except Exception:
            return
        self._render_verses(extended=True)

    def _shrink(self):
        """+5 로 넓힌 범위를 5절씩 **원래 단락 쪽으로** 되돌린다."""
        if self._peri_id is None or self._cur_start is None:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                if self._cur_start < self._base_start:
                    rows = conn.execute(
                        "SELECT verse_id FROM bible_index WHERE verse_id > ? "
                        "ORDER BY verse_id ASC LIMIT 5",
                        (self._cur_start,)).fetchall()
                    if rows:
                        self._cur_start = min(rows[-1][0], self._base_start)
                if self._cur_end > self._base_end:
                    rows = conn.execute(
                        "SELECT verse_id FROM bible_index WHERE verse_id < ? "
                        "ORDER BY verse_id DESC LIMIT 5",
                        (self._cur_end,)).fetchall()
                    if rows:
                        self._cur_end = max(rows[-1][0], self._base_end)
        except Exception:
            return
        back_home = (self._cur_start == self._base_start
                     and self._cur_end == self._base_end)
        self._render_verses(extended=not back_home)
        if back_home:
            self._title_lbl.config(text=self._title)   # 원래 제목 복원

    def _sync_shrink_btn(self):
        widened = (self._cur_start is not None
                   and (self._cur_start < (self._base_start or 0)
                        or self._cur_end > (self._base_end or 0)))
        try:
            self._shrink_btn.config(state=('normal' if widened else 'disabled'))
        except Exception:
            pass

    def _render_verses(self, extended=False):
        try:
            lang = self.lang_getter() or 'KO'
            ver = self.ver_getter() or 'KRV'
            book_lang = lang if lang in ('KO', 'EN') else 'KO'
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT bi.bcode, bi.chapter, bi.verse, "
                    "       bc.verse_text, bn.short_name, bi.verse_id "
                    "  FROM bible_index bi "
                    "  LEFT JOIN bible_content bc "
                    "    ON bc.verse_id=bi.verse_id AND bc.version_code=? "
                    "  LEFT JOIN book_names bn "
                    "    ON bn.book_code=bi.bcode AND bn.lang_code=? "
                    " WHERE " + _vr.between_sql('bi.verse_id') +
                    " ORDER BY bi.sort_order",
                    [ver, book_lang]
                    + _vr.between_args(self._cur_start,
                                       self._cur_end)).fetchall()
        except Exception as e:
            self._fill(f'(구절 로드 오류: {e})')
            return

        if extended:
            self._title_lbl.config(text=self._range_label())

        self._retag()               # 테마가 바뀌었어도 이번 렌더부터 맞는 색
        self._txt.config(state='normal')
        self._txt.delete('1.0', 'end')
        # ★ 2026-10-13 (76-1 사용자 「스크롤이 안된다 · 문장이 고정되어 있다 · 좌우 리사이즈 하면 전체를 볼 수 있어야」) —
        #   단락 설명을 라벨(줄 폭 600px 고정 · 스크롤 없음)이 아니라 **본문 글상자 맨 위**에 넣는다.
        if self._peri_desc and self._desc_open:
            self._txt.insert('end', self._peri_desc.strip() + '\n', ('pdesc',))
            self._txt.insert('end', '\n')
        # ★ **보이는 범위가 약명 형식을 정한다** (`verse_ref` · 2026-08-14 사용자 판단).
        #   한 장 안이면 `1`, 장을 넘으면 `1:1`, 책을 넘으면 `창 1:1`.
        #   ⚠ 늘 `창 1:1` 로 쓰면 한 장짜리 단락에서 같은 책 이름이 열 줄 되풀이된다.
        _scope = verse_ref.scope_of(rows)
        self._txt.tag_configure('body', lmargin1=0,
                                lmargin2=verse_ref.width_hint(_scope))
        prev_book = None
        focus = getattr(self, '_focus_vid', None)
        focus_end = getattr(self, '_focus_end', None) or focus
        for bcode, ch, v, text, bname, vid_row in rows:
            if bname and bname != prev_book:
                if prev_book is not None:
                    self._txt.insert('end', '\n')
                prev_book = bname
            hot = ('cur',) if (focus and focus <= vid_row <= focus_end) else ()
            ref = verse_ref.label(_scope, bname or bcode, ch, v)
            self._txt.insert('end', ref, ('ref',) + hot)
            # 히브리·아랍 본문은 읽는 차례를 맞춰 넣는다(오른쪽 정렬 포함)
            bidi.insert(self._txt, f"  {text or ''}\n", ('body',) + hot)
        if focus:
            # 초점 절이 화면에 들어오게 — 단락이 길면 스크롤로 데려간다
            try:
                rng = self._txt.tag_ranges('cur')
                if rng:
                    self._txt.see(rng[0])
            except Exception:
                pass
        self._txt.config(state='disabled')
        if not focus:
            self._txt.see('1.0')
        self._sync_shrink_btn()
        if self._autosize:
            self.after_idle(self._fit_height)
            # ⚠ 첫 렌더는 폭이 확정되기 전이라 표시줄 수가 부풀려 잡힌다(실측
            #   477px) — 폭이 실제로 정해지거나 바뀌면 한 번 더 맞춘다.
            #   높이 변경은 폭을 안 건드리므로 이 바인딩이 되돌지 않는다.
            if not getattr(self, '_as_bound', False):
                self._as_bound = True
                self._txt.bind('<Configure>', self._on_autosize_cfg, add='+')

    def _on_autosize_cfg(self, e):
        if abs(e.width - self._as_w) > 8:
            self._as_w = e.width
            self.after_idle(self._fit_height)

    def _fit_height(self):
        """내용 표시줄 수만큼 Text 높이를 맞춘다 (autosize 모드).

        ⚠ 여유 줄(+1)을 두지 않는다 (2026-08-19 사용자 — 구절 아래 공백이
          공간을 낭비했다). end 앞 개행 하나가 이미 한 줄로 세어져 구분 여백
          역할을 한다."""
        try:
            n = self._txt.count('1.0', 'end', 'displaylines')
            if isinstance(n, (tuple, list)):
                n = n[0]
            self._txt.config(height=max(2, min(int(n or 1), 18)))
        except Exception:
            pass

    def _range_label(self):
        if self._cur_start is None or self._cur_end is None:
            return self._title
        try:
            lang = self.lang_getter() or 'KO'
            book_lang = lang if lang in ('KO', 'EN') else 'KO'
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT bn.short_name, bi1.chapter, bi1.verse, "
                    "       bi2.chapter, bi2.verse "
                    "  FROM bible_index bi1 "
                    "  JOIN bible_index bi2 ON bi2.verse_id=? "
                    "  LEFT JOIN book_names bn ON bn.book_code=bi1.bcode "
                    "                         AND bn.lang_code=? "
                    " WHERE bi1.verse_id=?",
                    (self._cur_end, book_lang, self._cur_start)).fetchone()
            if row:
                bk, c1, v1, c2, v2 = row
                if c1 == c2 and v1 == v2:
                    c2v2 = f'{c1}:{v1}'          # 단일 절 — 「15:6~6」 방지
                elif c1 == c2:
                    c2v2 = f'{c1}:{v1}~{v2}'
                else:
                    c2v2 = f'{c1}:{v1}~{c2}:{v2}'
                return f'{bk or ""} {c2v2}'
        except Exception:
            pass
        return self._title

    def _render_msg(self, msg):
        self.clear()
        self._fill(msg)

    def _fill(self, text):
        self._txt.config(state='normal')
        self._txt.delete('1.0', 'end')
        if text:
            self._txt.insert('1.0', text)
        self._txt.config(state='disabled')
