# -*- coding: utf-8 -*-
"""낱말 ↔ 구속사 흐름 잇기 (영구 도구)

2026-09-07 신설. 1.txt 제안 C — 「낱말을 따라가는 묵상」.
사용자 확정: 「낱말묵상플랜은 분량이 크다면 주제읽기 형식도 가능하겠지만
**연결되는 구절의 분량이 작다면 흐름묵상과 같이 해도 좋다**」.

★★★ **새 흐름을 만들지 않는다 — 이미 있었다**(2026-09-07 실측).
  처음에 「할라크 플랜」을 새로 만들려 했는데, 재 보니 **흐름 81개**가
  이미 있고 품질이 우리 대표 절보다 낫다:
      PRG-LOVE  「사랑」        8절 (레19:18 · 신6:5 · 마22:37 · 계19:7 …)
      PRG-WALK  「하나님과 동행」 11절 (창5:22 · 창5:24 · 미6:8 · 갈5:16 …)
  ⇒ **빠진 것은 흐름이 아니라 「낱말 ↔ 흐름」의 다리**였다. 그 한 줄을 놓으면
    「낱말을 따라가는 묵상」이 새 콘텐츠 없이 그 자리에서 선다.
  ⚠ 새로 만들었으면 **두 벌**이 됐다 — 같은 주제에 흐름이 둘이면 어느 것이
    진짜인지 알 수 없다.

★ **저장은 통합 표**(§1-A) — `link_picker.add(('CHAIN', id), ('ENTITY', id))`
  → `CHAI_ENTI`. 새 표 0.
  ⚠ 흐름의 열쇠는 **글자**(`PRG-LOVE`)인데 통합 표는 **정수**다 —
    `db_person_relation.ensure_chain_ids` 가 그 다리다(§198차).

⚠⚠ **잣대 둘 — 실측으로 정했다.** 겹침만 보면 잡음이 많다(「언약」 흐름은
  68절이라 무엇과도 겹치고, 창1:31 은 흐름 여섯에 들어 있다):
      ① 겹치는 절이 **3개 이상**              — 우연으로는 잘 안 난다
      ② 겹치는 절이 있고 **이름이 맞는다**     — 「빛 · 오르」 ↔ 「빛」
  둘 중 하나면 자동, 아니면 검토.
"""
from __future__ import annotations

import re
import sys

try:
    import appdb
except Exception:                                        # pragma: no cover
    appdb = None

MIN_OVERLAP = 3          # 이름이 안 맞아도 이 정도 겹치면 잇는다

#: **이름 대조에서 빼는 낱말** — 축이 아니라 주어인 것(`name_words` 주석 참조).
NAME_STOP = {'하나님'}

#: **사람이 이은 것** — 잣대 둘에 안 걸리는데 근거가 뚜렷한 짝(2026-09-07).
#:
#: ★★★ **잣대는 「겹침 수」가 아니라 「그 낱말이 그 절의 축인가」다.**
#:   기계는 겹치는 절의 **수**만 셀 수 있고 그 절 안에서 낱말이 무슨 일을
#:   하는지는 못 본다. 창1:27 「자기 형상대로 사람을 **창조**하시되」에서
#:   바라는 그 절의 동사 자체다 — 겹침이 둘뿐이어도 우연이 아니다.
#: ⚠ **겹치는 절을 근거로 적는다** — 대지 못하면 그것은 느낌이다.
MANUAL = {
    ('T_BARA', 'INC-IMAGE'):
        '창1:27 「자기 형상대로 사람을 **창조**하시되」 · 창5:1 — '
        '그 흐름의 뿌리 절에서 이 낱말이 동사다',
    ('T_BARA', 'INC-COSMIC'):
        '창1:1 「태초에 하나님이 천지를 **창조**하시니라」 — '
        '흐름 이름이 「창조와 새 창조」이고 이 낱말이 그 주어다',
    ('T_NEPHESH', 'PRG-LOVE'):
        '신6:5 「**성품**을 다하고」 · 마22:37 「**목숨**을 다하고」 — '
        '대계명이 두 축이 만나는 자리다',
    ('T_RUACH', 'PRG-SPIRIT'):
        '창1:2 「하나님의 **신**」 · 시51:11 「주의 **성신**」 — '
        '루아흐가 그 흐름의 낱말 자체다',
    ('T_TSEDEQ', 'PRG-FAITH'):
        '창15:6 「믿으니 … 그의 **의**로 여기시고」 · 롬1:17 '
        '「하나님의 **의** … 믿음으로」 — 한 절에서 두 축이 만난다',
    ('T_ZAKAR', 'PRG-COVENANT'):
        '출2:24 「그 언약을 **기억**하사」 · 창8:1 「**권념**하사」 — '
        '「하나님이 언약을 기억하신다」가 그 흐름의 뼈대다',
    ('T_ADAM', 'INC-IMAGE'):
        '창1:26 「우리의 형상을 따라 우리가 **사람**을 만들고」 · 창1:27 — '
        '그 형상을 지닌 것이 아담이다',
    ('T_ELYON', 'INC-MELCHIZEDEK'):
        '창14:18 「**지극히 높으신 하나님**의 제사장」 · 창14:19 — '
        '멜기세덱을 부르는 이름 자체가 이 낱말이다',
    ('T_MAVET', 'INC-DEATH'):
        '창2:17 「반드시 **죽으리라**」 · 롬6:23 「죄의 삯은 **사망**이요」 — '
        '흐름 이름이 「죽음의 시작과 끝」이고 이 낱말이 그 축이다',
    ('T_DAM', 'PRG-SACRIFICE'):
        '레17:11 「피가 죄를 속하느니라」 · 히9:22 「피 흘림이 없은즉 사함이 '
        '없느니라」 — 흐름 이름이 「희생제사·피」이고 이 낱말이 그 축이다',
    ('T_TAMIM', 'PRG-WALK'):
        '창6:9 「**완전**한 자라 … 하나님과 동행하였으며」 · 창17:1 '
        '「내 앞에서 행하여 **완전**하라」 — 두 절에서 완전함과 동행이 한 몸이다',
}

#: **안 잇기로 정한 짝** — 겹치기는 하는데 축이 다르다.
#: ⚠ 실측으로 확인하고서만 적는다(§165차 `EXCLUDE` 와 같은 문법).
EXCLUDE = {
    ('T_BARAK', 'PRG-COVENANT'):
        '창12:2·창22:17 은 **언약 흐름의 절이라 걸린 것**이고 「복」이 그 '
        '흐름을 관통하는 실은 아니다. 언약 흐름은 53절이라 무엇과도 겹친다',
    ('T_AHAV', 'INC-SEED'):
        '대표 절 겹침 **0** — 의미연결로만 걸렸다. 「사랑」과 「씨」는 축이 다르다',
    ('T_ANASTASIS', 'INC-DEATH'):
        '대표 절 겹침 **0** — 뜻으로는 이어질 법하나 댈 절이 없다. '
        '느낌으로 잇지 않는다',
}


def _term_name(conn, eid, lang='KO'):
    r = conn.execute(
        "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
        " AND clicked_id=? AND lang_code=? AND record_status='LIVE' LIMIT 1",
        (eid, lang)).fetchone()
    return (r[0] or '').strip() if r else ''


def name_words(name):
    """용어 이름을 가운뎃점으로 가른다 → 대조에 쓸 낱말들.

    이름 규약이 `사랑 · 아하브 · 아가페`(대표어 · 음역)다.
    ★ **음역을 버리지 않는다**(2026-09-07 실측) — 우리 음역은 한글로 적혀
      있어(「아하브」·「샬롬」) 대표어와 기계로 못 가르고, 게다가 **버리면
      손해다**: 「평강 · 샬롬」 ↔ 흐름 「평화·샬롬」이 음역으로 맞는다.
    ⚠ 한 글자 낱말은 안 쓴다 — 「의」·「길」이 아무 데나 걸린다.
    ⚠ 라틴 글자는 안 쓴다(코드가 섞여 들어올 수 있다).
    ⚠⚠ **`NAME_STOP` 은 안 쓴다**(2026-09-07 실측으로 잡았다) — 「하나님 ·
      엘로힘」이 「하나님의 형상」에, 「하나님 · 엘」이 「하나님과 동행」에
      **이름 일치로 자동 등록**됐다. 그 흐름의 축은 형상·동행이고 하나님은
      **거의 모든 흐름의 주어**라 이름에 있어도 축이 아니다(§165차 「이름은
      겹치기 쉽다」의 그 자리). 실측 — 「하나님」이 든 흐름 3/81 ·
      「여호와」·「예수」·「주님」 0 ⇒ **이렇게 도는 낱말은 하나뿐이라 하나만 뺀다.**
    """
    out = []
    for part in re.split(r'[·|/]', name or ''):
        w = part.strip()
        if len(w) >= 2 and re.match(r'^[가-힣]+$', w) and w not in NAME_STOP:
            out.append(w)
    return out


def name_match(term_name, chain_name):
    """이름이 맞는가 — 어느 한쪽이 다른 쪽에 들어 있으면 맞다."""
    cn = (chain_name or '').strip()
    if not cn:
        return False
    for w in name_words(term_name):
        if w in cn:
            return True
    # 흐름 이름 쪽 낱말이 용어 이름에 들어 있는 경우(「평화·샬롬」 ↔ 「평강·샬롬」)
    for w in name_words(cn):
        if w in (term_name or ''):
            return True
    return False


def chain_verses(conn):
    """흐름 코드 → 그 흐름이 지나는 절 집합."""
    out = {}
    for cc, a, b in conn.execute(
            "SELECT chain_code, clicked_id, target_id FROM sys_link_asset "
            "WHERE chain_code IS NOT NULL AND COALESCE(record_status,'LIVE')='LIVE'"):
        s = out.setdefault(cc, set())
        s.add(a)
        s.add(b)
    return out


def chain_names(conn, lang='KO'):
    return {r[0]: r[1] for r in conn.execute(
        "SELECT chain_code, chain_name FROM sys_chain_catalog "
        "WHERE lang_code=? AND COALESCE(record_status,'LIVE')='LIVE'", (lang,))}


def term_verses(conn):
    """용어 → 그 용어의 **대표·의미 절**(낱말연결은 뺀다).

    ⚠ 낱말연결(LEXICAL)까지 넣으면 「여호와」가 5,786절이라 모든 흐름과
      겹친다. 대표(`is_key`)와 사람이 이은 의미연결만 본다.
    ⚠ 기계 낱말(subtype='LEX')은 대상이 아니다(§181차).
    """
    out, names = {}, {}
    q = ("SELECT m.entity_id, m.entity_code, l.target_id "
         "FROM sys_entity_master m JOIN sys_link_asset l ON l.clicked_id=m.entity_id "
         "WHERE m.entity_type='TERM' AND m.record_status='LIVE' "
         "  AND COALESCE(json_extract(m.json_detail,'$.subtype'),'')<>'LEX' "
         "  AND l.link_type='ENTI_VERS' AND COALESCE(l.record_status,'LIVE')='LIVE' "
         "  AND (l.is_key=1 OR l.rel_code='THEMATIC')")
    for eid, code, vid in conn.execute(q):
        out.setdefault(eid, set()).add(vid)
        names[eid] = code
    return out, names


def candidates(conn):
    """`(자동, 검토)` — 각 항목은 dict.

    ⚠⚠ **겹침 1 · 이름도 안 맞으면 후보가 아니다**(2026-09-07 실측).
      그전에는 검토 71건 중 **62건(87%)이 그 잡음**이었다. 검토 목록의
      열에 아홉이 잡음이면 그것은 검토 목록이 아니라 **벽**이라 사람이
      아예 안 본다 — 그러면 정작 볼 아홉 건이 함께 묻힌다.
      ⇒ 실측 근거: 「언약」 흐름은 53절이라 무엇과도 한 절씩 겹치고
        창1:31 은 흐름 여섯에 들어 있다. **한 절 겹침은 우연이다.**
      ★ 이름이 맞으면 한 절이어도 남긴다(창조하다 ↔ 「창조와 새 창조」).
    ⚠ 사람이 정한 것은 자동으로 · 안 잇기로 정한 것은 목록에서 뺀다.
    """
    cv = chain_verses(conn)
    cn = chain_names(conn)
    tv, tcode = term_verses(conn)
    auto, review = [], []
    for eid, vs in tv.items():
        tname = _term_name(conn, eid)
        code = tcode.get(eid)
        for cc, cvs in cv.items():
            ov = vs & cvs
            if not ov:
                continue
            if (code, cc) in EXCLUDE:
                continue                   # 안 잇기로 정했다
            nm = name_match(tname, cn.get(cc))
            row = {'entity_id': eid, 'code': code, 'term': tname,
                   'chain_code': cc, 'chain': cn.get(cc, cc),
                   'overlap': len(ov), 'name_match': nm,
                   'n_term': len(vs), 'n_chain': len(cvs),
                   'manual': (code, cc) in MANUAL}
            if (code, cc) in MANUAL or len(ov) >= MIN_OVERLAP or nm:
                auto.append(row)
            elif len(ov) >= 2:
                review.append(row)         # 둘 이상 겹치면 볼 만하다
            # 겹침 1 · 이름 불일치 = 잡음 — 목록에 안 올린다
    auto.sort(key=lambda r: (-r['overlap'], r['code'] or ''))
    review.sort(key=lambda r: (-r['overlap'], r['code'] or ''))
    return auto, review


# ── 저장 ───────────────────────────────────────────────────────────────
def _chain_id(conn, chain_code):
    r = conn.execute("SELECT chain_id FROM sys_chain_master WHERE chain_code=?",
                     (chain_code,)).fetchone()
    return int(r[0]) if r else None


def links_of_term(conn, eid):
    """그 용어에 이어진 흐름 → `[(chain_code, chain_name)]`."""
    out = []
    try:
        rows = conn.execute(
            "SELECT m.chain_code FROM sys_link_asset l "
            "JOIN sys_chain_master m ON m.chain_id=l.clicked_id "
            "WHERE l.link_type='CHAI_ENTI' AND l.target_id=? "
            "  AND COALESCE(l.record_status,'LIVE')='LIVE'", (eid,)).fetchall()
    except Exception:
        return out
    nm = chain_names(conn)
    for (cc,) in rows:
        out.append((cc, nm.get(cc, cc)))
    return out


def terms_of_chain(conn, chain_code, lang='KO'):
    """그 흐름에 이어진 용어 → `[(entity_id, 이름)]`."""
    cid = _chain_id(conn, chain_code)
    if cid is None:
        return []
    out = []
    for (eid,) in conn.execute(
            "SELECT target_id FROM sys_link_asset WHERE link_type='CHAI_ENTI' "
            "AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'", (cid,)):
        out.append((eid, _term_name(conn, eid, lang)))
    return out


def apply_auto(conn, dry=False):
    """자동 후보를 잇는다 → 새로 이은 수.

    ⚠ **`link_picker.add` 를 쓴다**(§135차) — 없는 자산을 거부하는 문이
      거기 있고, 여기서 INSERT 를 또 쓰면 그 문을 비껴간다.
    """
    import link_picker as LP
    try:
        import db_person_relation as PR
        PR.ensure_chain_ids(conn)          # 글자 코드 → 정수 다리(멱등)
    except Exception:
        pass
    auto, _ = candidates(conn)
    # ⚠ **이미 이어진 것은 안 센다** — `LP.add` 는 있어도 참을 돌려주므로
    #   그대로 세면 「멱등인데 12를 새로 이었다」는 거짓 보고가 된다.
    have = set()
    try:
        for a, b in conn.execute(
                "SELECT clicked_id, target_id FROM sys_link_asset "
                "WHERE link_type='CHAI_ENTI' "
                "  AND COALESCE(record_status,'LIVE')='LIVE'"):
            have.add((a, b))
    except Exception:
        pass
    n = 0
    for r in auto:
        cid = _chain_id(conn, r['chain_code'])
        if cid is None:
            continue
        if (cid, r['entity_id']) in have:
            continue
        if dry:
            n += 1
            continue
        try:
            if LP.add(conn, ('CHAIN', cid), ('ENTITY', r['entity_id']),
                      scope='SYS'):
                n += 1
                have.add((cid, r['entity_id']))
        except Exception as e:
            print('[word_chain] %s ↔ %s: %s' % (r['code'], r['chain_code'], e))
    return n


# ── selftest ───────────────────────────────────────────────────────────
def _selftest():
    import sqlite3
    ok, bad = [], []

    def chk(name, cond, extra=''):
        (ok if cond else bad).append(name + (('  ' + str(extra)) if extra else ''))

    # ── 이름 대조 ────────────────────────────────────────────────
    chk('★ 대표어가 흐름 이름에 있으면 맞다',
        name_match('사랑 · 아하브 · 아가페', '사랑'))
    chk('★ 흐름 이름 쪽이 용어에 있어도 맞다',
        name_match('평강 · 샬롬', '평화·샬롬'))
    chk('  겹치는 낱말이 없으면 안 맞는다',
        not name_match('할라크', '하나님과 동행'))
    chk('★ 한 글자는 안 쓴다(「의」·「길」이 아무 데나 걸린다)',
        not name_match('의 · 체데크', '길'))
    chk('  빈 이름은 안 맞는다',
        not name_match('사랑', '') and not name_match('', '사랑'))
    chk('  낱말 뽑기 — 가운뎃점으로 가른다',
        name_words('사랑 · 아하브 · 아가페') == ['사랑', '아하브', '아가페'],
        name_words('사랑 · 아하브 · 아가페'))
    chk('★ 음역도 쓴다 — 「평강 · 샬롬」 ↔ 「평화·샬롬」이 그것으로 맞는다',
        name_match('평강 · 샬롬', '평화·샬롬'))
    chk('  한 글자는 버린다', name_words('의 · 체데크') == ['체데크'],
        name_words('의 · 체데크'))
    chk('★ 「하나님」은 축이 아니라 주어라 이름 대조에서 뺀다',
        not name_match('하나님 · 엘로힘', '하나님의 형상')
        and not name_match('하나님 · 엘', '하나님과 동행'),
        name_words('하나님 · 엘로힘'))
    chk('  탐지력 — 그 낱말을 되돌리면 다시 걸린다',
        (lambda: [NAME_STOP.discard('하나님'),
                  name_match('하나님 · 엘로힘', '하나님의 형상'),
                  NAME_STOP.add('하나님')][1])())
    chk('  음역은 남는다 — 엘로힘으로는 여전히 맞는다',
        name_match('하나님 · 엘로힘', '엘로힘 이름'))

    # ── 매칭(메모리 DB) ──────────────────────────────────────────
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY,
        entity_code TEXT, entity_type TEXT, json_detail TEXT,
        record_status TEXT DEFAULT 'LIVE');
      CREATE TABLE sys_text_asset(clicked_id INTEGER, text_type TEXT,
        lang_code TEXT, contents TEXT, record_status TEXT DEFAULT 'LIVE');
      CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY,
        clicked_id INTEGER, target_id INTEGER, link_type TEXT, rel_code TEXT,
        chain_code TEXT, is_key INTEGER DEFAULT 0, end_id INTEGER,
        record_status TEXT DEFAULT 'LIVE');
      CREATE TABLE sys_chain_master(chain_id INTEGER PRIMARY KEY, chain_code TEXT);
      CREATE TABLE sys_chain_catalog(chain_code TEXT, lang_code TEXT,
        chain_name TEXT, record_status TEXT DEFAULT 'LIVE');
    """)
    # 용어 둘
    c.execute("INSERT INTO sys_entity_master(entity_id,entity_code,entity_type) "
              "VALUES (1,'T_AHAV','TERM')")
    c.execute("INSERT INTO sys_entity_master(entity_id,entity_code,entity_type) "
              "VALUES (2,'T_TOV','TERM')")
    # 기계 낱말 — 대상이 아니어야 한다
    c.execute("INSERT INTO sys_entity_master(entity_id,entity_code,entity_type,"
              "json_detail) VALUES (3,'W_H1','TERM','{\"subtype\":\"LEX\"}')")
    # 겹침 1 짜리 — **잡음이라 목록에 안 올라야** 한다
    c.execute("INSERT INTO sys_entity_master(entity_id,entity_code,entity_type) "
              "VALUES (4,'T_OR','TERM')")
    for eid, nm in ((1, '사랑 · 아하브'), (2, '좋다 · 토브'), (3, '낱말'),
                    (4, '빛 · 오르')):
        c.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,"
                  "contents) VALUES (?,'ENTITY_NAME','KO',?)", (eid, nm))
    # 용어 절 (대표)
    for eid, vids in ((1, [10, 11, 12]), (2, [49, 50]), (3, [10, 11, 12, 50]),
                      (4, [50])):
        for v in vids:
            c.execute("INSERT INTO sys_link_asset(clicked_id,target_id,link_type,"
                      "is_key) VALUES (?,?,'ENTI_VERS',1)", (eid, v))
    # 흐름 둘 — 사랑(10·11·12 지남) · 언약(50 지남)
    for i, (cc, nm) in enumerate((('PRG-LOVE', '사랑'), ('PRG-COV', '언약')), 1):
        c.execute("INSERT INTO sys_chain_master VALUES (?,?)", (i, cc))
        c.execute("INSERT INTO sys_chain_catalog(chain_code,lang_code,chain_name) "
                  "VALUES (?,?,?)", (cc, 'KO', nm))
    for a, b, cc in ((10, 11, 'PRG-LOVE'), (11, 12, 'PRG-LOVE'),
                     (49, 50, 'PRG-COV')):
        c.execute("INSERT INTO sys_link_asset(clicked_id,target_id,link_type,"
                  "rel_code,chain_code) VALUES (?,?,'VERS_VERS','PRG',?)",
                  (a, b, cc))
    c.commit()

    cv = chain_verses(c)
    chk('흐름 절을 모은다', cv['PRG-LOVE'] == {10, 11, 12}, cv.get('PRG-LOVE'))
    tv, _n = term_verses(c)
    chk('★ 기계 낱말은 대상이 아니다', 3 not in tv, sorted(tv))
    chk('  대표 절만 본다', tv[1] == {10, 11, 12})

    auto, rev = candidates(c)
    got = {(r['code'], r['chain_code']) for r in auto}
    chk('★ 겹침 3 + 이름 일치 → 자동',
        ('T_AHAV', 'PRG-LOVE') in got, sorted(got))
    # ★ 2026-09-07 개정 — **겹침 1 · 이름 불일치는 잡음이라 목록에서 뺀다**
    #   (실검토 71건 중 62건이 그 부류였다. 열에 아홉이 잡음이면 벽이 된다.)
    rvs = {(r['code'], r['chain_code']) for r in rev}
    chk('★ 겹침 1 · 이름 불일치 = 잡음 — 목록에 안 올린다',
        ('T_OR', 'PRG-COV') not in rvs and ('T_OR', 'PRG-COV') not in got,
        sorted(rvs))
    chk('★ 겹침 2 · 이름 불일치 → 검토로는 올린다',
        ('T_TOV', 'PRG-COV') in rvs, sorted(rvs))
    chk('  겹침이 0이면 후보가 아니다',
        ('T_TOV', 'PRG-LOVE') not in got)

    # ── 사람이 정한 두 표 — 탐지력을 양방향으로 ─────────────────────
    _m, _e = dict(MANUAL), dict(EXCLUDE)
    try:
        MANUAL[('T_TOV', 'PRG-COV')] = '시험'
        a2, r2 = candidates(c)
        chk('★ 사람이 이은 짝은 자동으로 간다',
            ('T_TOV', 'PRG-COV') in {(x['code'], x['chain_code']) for x in a2}
            and ('T_TOV', 'PRG-COV') not in
            {(x['code'], x['chain_code']) for x in r2})
        chk('  사람이 이은 것은 표식이 붙는다',
            any(x.get('manual') for x in a2
                if (x['code'], x['chain_code']) == ('T_TOV', 'PRG-COV')))
        MANUAL.clear(); MANUAL.update(_m)
        EXCLUDE[('T_TOV', 'PRG-COV')] = '시험'
        a3, r3 = candidates(c)
        chk('★ 안 잇기로 정한 짝은 어디에도 안 나온다',
            ('T_TOV', 'PRG-COV') not in
            {(x['code'], x['chain_code']) for x in a3 + r3})
    finally:
        MANUAL.clear(); MANUAL.update(_m)
        EXCLUDE.clear(); EXCLUDE.update(_e)
    chk('  시험 뒤 두 표가 원래대로', MANUAL == _m and EXCLUDE == _e)
    chk('★ 두 표는 까닭을 적는다',
        all(v for v in MANUAL.values()) and all(v for v in EXCLUDE.values()))
    chk('  한 짝이 두 표에 함께 들지 않는다',
        not (set(MANUAL) & set(EXCLUDE)), sorted(set(MANUAL) & set(EXCLUDE)))
    a0 = [r for r in auto if r['code'] == 'T_AHAV'][0]
    chk('  겹침 수를 들고 온다', a0['overlap'] == 3, a0['overlap'])
    chk('  이름 일치를 들고 온다', a0['name_match'] is True)

    # 문턱 탐지력 — 이름이 안 맞아도 겹침이 크면 자동
    chk('★ 이름이 안 맞아도 겹침 3이면 자동(문턱이 실제로 돈다)',
        MIN_OVERLAP == 3 and not name_match('좋다 · 토브', '사랑'))

    # ── 조회 ─────────────────────────────────────────────────────
    c.execute("INSERT INTO sys_link_asset(clicked_id,target_id,link_type) "
              "VALUES (1,1,'CHAI_ENTI')")
    c.commit()
    chk('★ 용어 → 흐름을 읽는다',
        links_of_term(c, 1) == [('PRG-LOVE', '사랑')], links_of_term(c, 1))
    chk('★ 흐름 → 용어를 읽는다',
        [e for e, _ in terms_of_chain(c, 'PRG-LOVE')] == [1],
        terms_of_chain(c, 'PRG-LOVE'))
    chk('  없는 흐름은 빈손', terms_of_chain(c, 'NOPE') == [])
    chk('  이어진 것 없는 용어는 빈손', links_of_term(c, 2) == [])

    # 표가 없어도 안 죽는다
    c2 = sqlite3.connect(':memory:')
    c2.execute("CREATE TABLE sys_link_asset(clicked_id INTEGER, target_id INTEGER,"
               " link_type TEXT, chain_code TEXT, record_status TEXT)")
    chk('  표가 없어도 조회가 안 죽는다', links_of_term(c2, 1) == [])

    print('db_word_chain selftest: %d/%d' % (len(ok), len(ok) + len(bad)))
    for b in bad:
        print('  FAIL:', b)
    return 0 if not bad else 1


# ── CLI ────────────────────────────────────────────────────────────────
def main(argv):
    if '--selftest' in argv:
        return _selftest()
    c = appdb.connect('bible_master.db') if appdb else None
    if c is None:
        print('appdb 없음')
        return 1
    if '--check' in argv:
        auto, rev = candidates(c)
        print('자동 %d · 검토 %d' % (len(auto), len(rev)))
        for r in auto:
            print('  %-16s %-16s ↔ %-18s 겹침 %d%s'
                  % (r['code'], (r['term'] or '')[:16], (r['chain'] or '')[:18],
                     r['overlap'], ' · 이름' if r['name_match'] else ''))
        return 0
    if '--apply' in argv:
        print('이은 것 %d' % apply_auto(c))
        return 0
    n = c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type='CHAI_ENTI'"
                  " AND COALESCE(record_status,'LIVE')='LIVE'").fetchone()[0]
    print('낱말 ↔ 흐름 연결 %d' % n)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
