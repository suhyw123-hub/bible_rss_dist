# -*- coding: utf-8 -*-
"""
figure_tree.py  v2
------------------
인물 족보 트리 캔버스 (p4_nb Tab3 "인물 족보").

레이아웃 규칙:
  부모   → 위 (gen -1, -2, ...)
  자녀   → 아래 (gen +1, +2, ...)
  형제   → 좌측 (gen=0, root 왼쪽)
  배우자 → 우측 (root 오른쪽)
  연결선 → 꺽은선 (L-shape orthogonal)

상태:
  _nodes  : {eid: NodeInfo}   — 캔버스의 모든 인물
  _edges  : [EdgeInfo]        — 연결선 목록
  _edge_set: set              — 중복 엣지 방지
  _root   : int | None        — 현재 루트
  _focus  : int | None        — 하이라이트 인물
  _gen_min: int               — 현재 표시 최상위 세대
  _gen_max: int               — 현재 표시 최하위 세대

동작:
  싱글클릭  → 하이라이트 + 하단 정보 패널
  ▼ 클릭   → 그 인물의 자녀 전개
  더블클릭  → 이 인물을 새 루트로 재로드
  ↑ 버튼   → 위로 1세대 확장
  ↓ 버튼   → 아래로 1세대 확장 (최하단 모든 노드 자녀 전개)
  드래그   → 패닝
"""

import sqlite3
import appdb
import entity_relation          # 엔티티↔엔티티 연결 단일 소스

# ⚠⚠ **옛 `sys_person_relation` 은 통합 표로 옮겼다**(2026-08-25).
#   이 파일은 행을 **이름으로** 읽는다(`p['from_person_id']`) — 칼럼 이름을
#   바꾸면 SQL 은 도는데 값만 조용히 안 잡힌다(§81 `ep.ep_id` 사고와 같은 계열).
#   ⇒ **옛 이름을 그대로 내주는 조회**로 감싼다. 아래 11곳은 글자 하나 안 바뀐다.
#   ⚠ 우상 관계가 같은 표에 있으므로 **인물 관계만** 좁힌다.
_PR = ("(SELECT sys_link_id AS relation_id, clicked_id AS from_person_id,"
       " target_id AS to_person_id, rel_code AS relation_type,"
       " relation_cat, is_directed,"
       " COALESCE(record_status,'LIVE') AS record_status"
       " FROM %s WHERE link_type='%s' AND rel_code IN (%s))"
       % (entity_relation.TBL, entity_relation.LT,
          ','.join("'%s'" % r for r in entity_relation.PERSON)))
import i18n
import tkinter as tk
from tkinter import ttk, scrolledtext
import bidi                               # 오른쪽에서 왼쪽으로 읽는 글 (font.md §8)

# ── 색상 ──────────────────────────────────────────────────────────────────────

_CLR = {
    'root':    ('#1A3A6B', '#FFFFFF'),
    'ancestor':('#1A5E20', '#FFFFFF'),
    'sibling': ('#2E86C1', '#FFFFFF'),
    'spouse':  ('#784212', '#FFFFFF'),
    'concub':  ('#6C3483', '#FFFFFF'),
    'descendant': ('#117A65', '#FFFFFF'),
    'canvas':  '#F8F9FA',
    'line':    '#95A5A6',
    'line_spouse': '#784212',
}

_REL_KO = {
    'FATHER': '부', 'MOTHER': '모',
    'SPOUSE': '배우자', 'CONCUBINE': '첩', 'INFORMAL_UNION': '비혼',
}
_ROLE_KO = {
    'PROTAGONIST':'주인공', 'ANTAGONIST':'대적', 'SUPPORTER':'조력자',
    'MENTIONED':'언급', 'BACKGROUND':'배경',
}

# ── 레이아웃 상수 ─────────────────────────────────────────────────────────────

_NW, _NH         = 130, 40    # 일반 노드
_CTR_W, _CTR_H   = 150, 46    # 루트 노드
_SP_W, _SP_H     = 115, 38    # 배우자 노드
_H_GAP           = 180        # 형제 수평 간격
_SP_GAP          = 145        # 배우자 간격
_V_GAP           = 155        # 세대 수직 간격
_BASE_X          = 900        # 루트 기본 X
_BASE_Y          = 80         # 최상단 여백
_CV_W, _CV_H     = 3600, 2400


def _rr(cv, x1, y1, x2, y2, r=8, **kw):
    pts = [x1+r,y1, x2-r,y1, x2,y1, x2,y1+r,
           x2,y2-r, x2,y2, x2-r,y2, x1+r,y2,
           x1,y2, x1,y2-r, x1,y1+r, x1,y1]
    return cv.create_polygon(pts, smooth=True, **kw)


def _fmt_yr(y):
    return f'BC {abs(y)}' if y < 0 else f'AD {y}'


def _peri_label(conn, start_vid: int, end_vid: int, lang: str = 'KO') -> str:
    """start_vid/end_vid → '삼상 17:1-10' 형식 문자열.

    ⚠ 책 약명이 `lang_code='KO'` 로 **박혀 있었다**(2026-08-14) — 다른 언어
      사용자에게 한국어 약명이 떴다. 그 언어에 없으면 EN→KO 로 떨어진다(§0-3).
    """
    s = conn.execute(
        'SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?',
        (start_vid,)
    ).fetchone()
    if not s:
        return f'vid:{start_vid}'
    bn = conn.execute(
        "SELECT short_name FROM book_names WHERE book_code=? "
        "AND UPPER(lang_code) IN (?,'EN','KO') "
        "ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END "
        "LIMIT 1",
        (s['bcode'], (lang or 'KO').upper(), (lang or 'KO').upper())
    ).fetchone()
    book = bn['short_name'] if bn else f'B{s["bcode"]}'
    e = conn.execute(
        'SELECT chapter, verse FROM bible_index WHERE verse_id=?',
        (end_vid,)
    ).fetchone()
    if not e:
        return f'{book} {s["chapter"]}:{s["verse"]}'
    if s['chapter'] == e['chapter']:
        return f'{book} {s["chapter"]}:{s["verse"]}-{e["verse"]}'
    return f'{book} {s["chapter"]}:{s["verse"]}~{e["chapter"]}:{e["verse"]}'


class FigureTreeCanvas(ttk.Frame):

    def __init__(self, parent, db_path, lang_getter=None, on_peri_nav=None):
        super().__init__(parent)
        self.db_path     = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.on_peri_nav = on_peri_nav

        # ── 상태 ─────────────────────────────────────────────────────────────
        self._nodes:    dict[int, dict] = {}
        self._edges:    list[dict]      = []
        self._edge_set: set[tuple]      = set()
        self._root:     int | None      = None
        self._focus:    int | None      = None
        self._gen_min:  int             = 0
        self._gen_max:  int             = 0

        self._search_results: list[tuple] = []
        self._peri_data:      list[tuple] = []

        # 드래그
        self._drag_x = self._drag_y = 0
        self._dragging = False

        self._build()

    # ── 공개 API ─────────────────────────────────────────────────────────────

    def load_person(self, eid: int) -> None:
        """새 루트로 족보 로드 (항상 캔버스 초기화 후 재구성)."""
        self._nodes.clear()
        self._edges.clear()
        self._edge_set.clear()
        self._root     = eid
        self._focus    = eid
        self._gen_min  = -2
        self._gen_max  = 1

        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                self._build_tree(conn, eid)
        except Exception as e:
            print(f'[figure_tree] load_person error: {e}')
            return

        self._layout()
        self._render()
        self._refresh_info(eid)
        self._update_nav_label()

    def highlight(self, eid: int) -> None:
        """이미 캔버스에 있으면 하이라이트만, 없으면 새 로드."""
        if eid in self._nodes:
            self._focus = eid
            self._render()
            self._refresh_info(eid)
        else:
            self.load_person(eid)

    def clear(self) -> None:
        self._nodes.clear()
        self._edges.clear()
        self._edge_set.clear()
        self._root = self._focus = None
        self._cv.delete('all')
        self._placeholder('인물을 검색하거나 엔티티 목록에서 선택하세요.')
        self._clear_info()
        self._update_nav_label()

    # ── UI 구성 ──────────────────────────────────────────────────────────────

    def _build(self):
        self._build_top_bar()

        # 검색 드롭다운 (place로 띄움)
        self._result_outer = tk.Frame(self, bg='white', bd=1, relief='solid')
        self._result_lb = tk.Listbox(
            self._result_outer, font=('Malgun Gothic', 9),
            height=6, selectmode='browse', bg='#FDFEFE')
        self._result_lb.pack(fill='both', expand=True)
        self._result_lb.bind('<<ListboxSelect>>', self._on_result_select)

        # 캔버스 (좌) + 정보 패널 (우) 가로 분할
        self._main_pw = tk.PanedWindow(self, orient='horizontal',
                                        sashwidth=5, bg='#BDC3C7')
        self._main_pw.pack(fill='both', expand=True)

        cv_f = tk.Frame(self._main_pw, bg=_CLR['canvas'])
        self._main_pw.add(cv_f)
        self._build_canvas(cv_f)

        self._info_outer = tk.Frame(self._main_pw, bg='white')
        self._main_pw.add(self._info_outer, width=280)
        self._build_info_panel(self._info_outer)

    def _build_top_bar(self):
        bar = tk.Frame(self, bg='#EEF2F7', height=34)
        bar.pack(fill='x')
        bar.pack_propagate(False)

        tk.Label(bar, text=i18n.t('FT_PERSON','인물:'), bg='#EEF2F7',
                 font=('Malgun Gothic', 9)).pack(side='left', padx=(6, 2), pady=4)

        self._search_var = tk.StringVar()
        self._search_ent = tk.Entry(bar, textvariable=self._search_var,
                                    width=18, font=('Malgun Gothic', 9))
        self._search_ent.pack(side='left', pady=4)
        self._search_ent.bind('<Return>', lambda _: self._on_search())
        self._search_ent.bind('<Escape>', lambda _: self._hide_results())

        tk.Button(bar, text=i18n.t('COMMON_SEARCH','검색'), command=self._on_search,
                  font=('Malgun Gothic', 8), bg='#2874A6', fg='white',
                  relief='flat', padx=6, pady=1).pack(side='left', padx=(2, 6), pady=4)

        tk.Button(bar, text=i18n.t('COMMON_RESET','초기화'), command=self.clear,
                  font=('Malgun Gothic', 8), bg='#E74C3C', fg='white',
                  relief='flat', padx=4, pady=1).pack(side='left', padx=(0, 8), pady=4)

        ttk.Separator(bar, orient='vertical').pack(side='left', fill='y', pady=5, padx=3)

        tk.Button(bar, text=i18n.t('FT_GENUP','↑ 세대'), command=self._nav_up,
                  font=('Malgun Gothic', 8), bg='#D5DBDB',
                  relief='flat', padx=5, pady=1).pack(side='left', padx=2, pady=4)
        tk.Button(bar, text=i18n.t('FT_GENDOWN','↓ 세대'), command=self._nav_down,
                  font=('Malgun Gothic', 8), bg='#D5DBDB',
                  relief='flat', padx=5, pady=1).pack(side='left', padx=2, pady=4)

        ttk.Separator(bar, orient='vertical').pack(side='left', fill='y', pady=5, padx=5)

        self._nav_lbl = tk.Label(bar, text='', bg='#EEF2F7',
                                 font=('Malgun Gothic', 9, 'bold'), fg='#1A3A6B')
        self._nav_lbl.pack(side='left', padx=4)

        tk.Label(bar, text=i18n.t('FT_HELP','클릭:정보  ▼:자녀펼치기  더블클릭:재로드  드래그:이동'),
                 bg='#EEF2F7', font=('Malgun Gothic', 7), fg='#95A5A6').pack(side='right', padx=8)

    def _build_canvas(self, parent):
        vsb = ttk.Scrollbar(parent, orient='vertical')
        hsb = ttk.Scrollbar(parent, orient='horizontal')
        vsb.pack(side='right', fill='y')
        hsb.pack(side='bottom', fill='x')
        self._cv = tk.Canvas(parent, bg=_CLR['canvas'],
                             yscrollcommand=vsb.set, xscrollcommand=hsb.set,
                             scrollregion=(0, 0, _CV_W, _CV_H))
        self._cv.pack(fill='both', expand=True)
        vsb.config(command=self._cv.yview)
        hsb.config(command=self._cv.xview)
        self._cv.xview_moveto(_BASE_X / _CV_W - 0.15)
        self._cv.yview_moveto(0.05)
        self._placeholder('인물을 검색하거나 엔티티 목록에서 선택하세요.')

        self._cv.bind('<ButtonPress-1>',   self._press)
        self._cv.bind('<B1-Motion>',       self._b1_motion)
        self._cv.bind('<ButtonRelease-1>', self._release)
        self._cv.bind('<Double-Button-1>', self._dbl_click)

    def _build_info_panel(self, parent):
        hdr = tk.Frame(parent, bg='#D6EAF8')
        hdr.pack(fill='x')
        self._info_name = tk.Label(hdr, text=i18n.t('FT_SELECT','인물을 선택하세요'), bg='#D6EAF8',
                                   font=('Malgun Gothic', 11, 'bold'),
                                   anchor='w', padx=8, pady=4)
        self._info_name.pack(fill='x')

        self._info_meta = tk.Label(parent, text='', bg='#EAF2FF',
                                   font=('Malgun Gothic', 8), fg='#555',
                                   anchor='w', padx=8, pady=2)
        self._info_meta.pack(fill='x')

        tk.Label(parent, text=i18n.t('COMMON_DESCTEXT','설명문'), bg='white',
                 font=('Malgun Gothic', 8, 'bold'), anchor='w', padx=4
                 ).pack(fill='x', pady=(4, 0))
        self._info_desc = scrolledtext.ScrolledText(
            parent, font=('Malgun Gothic', 9), wrap='word',
            state='disabled', bg='#FAFAFA', bd=0, height=4)
        self._info_desc.pack(fill='x', padx=4)

        tk.Label(parent, text=i18n.t('FT_LINKEDPERI','연결 페리코프'), bg='white',
                 font=('Malgun Gothic', 8, 'bold'), anchor='w', padx=4
                 ).pack(fill='x', pady=(6, 0))
        peri_frame = tk.Frame(parent, bg='white')
        peri_frame.pack(fill='x', padx=4)
        pvsb = ttk.Scrollbar(peri_frame, orient='vertical')
        pvsb.pack(side='right', fill='y')
        self._info_peri = tk.Listbox(peri_frame, font=('Malgun Gothic', 8),
                                     yscrollcommand=pvsb.set,
                                     bg='#F5EEF8', selectmode='browse', height=5)
        pvsb.config(command=self._info_peri.yview)
        self._info_peri.pack(side='left', fill='both', expand=True)
        self._info_peri.bind('<<ListboxSelect>>', self._on_peri_select)

        tk.Label(parent, text=i18n.t('FT_VERSEBODY','구절 본문 (KRV)'), bg='white',
                 font=('Malgun Gothic', 8, 'bold'), anchor='w', padx=4
                 ).pack(fill='x', pady=(6, 0))
        self._info_verse = scrolledtext.ScrolledText(
            parent, font=('Malgun Gothic', 9), wrap='word',
            state='disabled', bg='#FFFDE7', bd=0)
        # ★ 성경 구절은 **어디에 있든 「성경」 역할**이다 (font.md §22).
        #   화면마다 크기가 달라 「같은 구절인데 다르게 느껴진다」던 것을 묶는다.
        try:
            import theme_font
            theme_font.register(self._info_verse, self.db_path, 'bible')
        except Exception:
            pass
        self._info_verse.pack(fill='both', expand=True, padx=4, pady=(0, 4))

    # ── 데이터 로드 ───────────────────────────────────────────────────────────

    def _build_tree(self, conn, root_eid: int) -> None:
        """루트 기준 가족 트리를 BFS로 구성.
        직계 조상: gen_min ~ -1  자동 전개
        직계 자녀: gen+1  자동 전개 (루트만)
        형제/배우자: gen=0, 자녀 접힘
        """
        lang = self.lang_getter()

        def add_node(eid, gen, is_sibling=False, is_spouse_of=None):
            if eid in self._nodes:
                return False
            info = self._get_pinfo(conn, eid, lang)
            has_ch = bool(conn.execute(
                "SELECT 1 FROM " + _PR + " "
                "WHERE from_person_id=? AND relation_type IN ('FATHER','MOTHER') "
                "AND record_status='LIVE' LIMIT 1", (eid,)
            ).fetchone())
            self._nodes[eid] = {
                **info,
                'gen': gen,
                'is_sibling': is_sibling,
                'is_spouse_of': is_spouse_of,
                'expanded': False,
                'has_children': has_ch,
                'x': 0, 'y': 0,
            }
            return True

        def add_edge(a, b, rel, style):
            key = (a, b)
            if key not in self._edge_set:
                self._edge_set.add(key)
                self._edges.append({'a': a, 'b': b, 'rel': rel, 'style': style})

        # 1. 루트
        add_node(root_eid, 0)
        self._nodes[root_eid]['expanded'] = True  # 루트의 직계 자녀는 자동 전개

        # 2. 조상 (위로 gen_min까지)
        ancestor_eids = [root_eid]
        for g in range(-1, self._gen_min - 1, -1):
            next_tier = []
            for eid in ancestor_eids:
                parents = conn.execute(
                    "SELECT from_person_id, relation_type FROM " + _PR + " "
                    "WHERE to_person_id=? AND relation_type IN ('FATHER','MOTHER') "
                    "AND record_status='LIVE'", (eid,)
                ).fetchall()
                for p in parents:
                    pid = p['from_person_id']
                    if add_node(pid, g):
                        next_tier.append(pid)
                    add_edge(pid, eid, p['relation_type'], 'parent')
            ancestor_eids = next_tier

        # 3. 루트의 형제 (공통 부모의 다른 자녀)
        root_parents = conn.execute(
            "SELECT from_person_id FROM " + _PR + " "
            "WHERE to_person_id=? AND relation_type IN ('FATHER','MOTHER') "
            "AND record_status='LIVE'", (root_eid,)
        ).fetchall()
        for pp in root_parents:
            pid = pp['from_person_id']
            sibling_rows = conn.execute(
                "SELECT to_person_id, relation_type FROM " + _PR + " "
                "WHERE from_person_id=? AND relation_type IN ('FATHER','MOTHER') "
                "AND record_status='LIVE'", (pid,)
            ).fetchall()
            for sr in sibling_rows:
                sid = sr['to_person_id']
                if sid != root_eid:
                    add_node(sid, 0, is_sibling=True)
                    add_edge(pid, sid, sr['relation_type'], 'parent')

        # 4. 루트의 배우자
        spouses = conn.execute(
            "SELECT CASE WHEN from_person_id=? THEN to_person_id "
            "           ELSE from_person_id END as sp_id, relation_type "
            "FROM " + _PR + " "
            "WHERE (from_person_id=? OR to_person_id=?) "
            "AND relation_type IN ('SPOUSE','CONCUBINE','INFORMAL_UNION') "
            "AND record_status='LIVE'",
            (root_eid, root_eid, root_eid)
        ).fetchall()
        for sp in spouses:
            sp_id = sp['sp_id']
            add_node(sp_id, 0, is_spouse_of=root_eid)
            add_edge(root_eid, sp_id, sp['relation_type'], 'spouse')

        # 5. 루트의 직계 자녀 (gen+1)
        if self._gen_max >= 1:
            children = conn.execute(
                "SELECT to_person_id, relation_type FROM " + _PR + " "
                "WHERE from_person_id=? AND relation_type IN ('FATHER','MOTHER') "
                "AND record_status='LIVE'", (root_eid,)
            ).fetchall()
            for c in children:
                cid = c['to_person_id']
                add_node(cid, 1)
                add_edge(root_eid, cid, c['relation_type'], 'parent')

    def _get_pinfo(self, conn, eid: int, lang: str) -> dict:
        em = conn.execute(
            "SELECT entity_id, entity_code, year_start, year_end "
            "FROM sys_entity_master WHERE entity_id=?", (eid,)
        ).fetchone()
        if not em:
            return {'entity_id': eid, 'name': f'EID:{eid}',
                    'ys': None, 'ye': None, 'tribe': None, 'role': None}
        nm = conn.execute(
            "SELECT contents FROM sys_text_asset "
            "WHERE text_type='ENTITY_NAME' AND clicked_id=? AND lang_code=? LIMIT 1",
            (eid, lang)
        ).fetchone()
        if not nm:
            nm = conn.execute(
                "SELECT contents FROM sys_text_asset "
                "WHERE text_type='ENTITY_NAME' AND clicked_id=? AND lang_code IN ('EN','KO') AND record_status='LIVE' "
                "ORDER BY CASE lang_code WHEN 'EN' THEN 0 ELSE 1 END LIMIT 1",
                (eid,)
            ).fetchone()
        name = (nm[0] if nm else None) or em['entity_code']
        sp = conn.execute(
            "SELECT tribe_code, role_primary FROM sys_person WHERE person_id=?",
            (eid,)
        ).fetchone()
        return {
            'entity_id': eid, 'name': name,
            'ys': em['year_start'], 'ye': em['year_end'],
            'tribe': sp['tribe_code']  if sp else None,
            'role':  sp['role_primary'] if sp else None,
        }

    # ── 레이아웃 ─────────────────────────────────────────────────────────────

    def _layout(self) -> None:
        if not self._nodes:
            return

        # 배우자 분리
        spouses_by: dict[int, list[int]] = {}
        regular: dict[int, list[int]] = {}
        for eid, n in self._nodes.items():
            if n.get('is_spouse_of') is not None:
                spouses_by.setdefault(n['is_spouse_of'], []).append(eid)
            else:
                regular.setdefault(n['gen'], []).append(eid)

        if not regular:
            return

        gen_min = min(regular)

        def y_of(gen: int) -> int:
            return _BASE_Y + (gen - gen_min) * _V_GAP + 60

        # ── gen=0: [형제...] [루트] ───────────────────────────────────────
        gen0 = regular.get(0, [])
        sibs  = [e for e in gen0 if self._nodes[e].get('is_sibling')]
        roots = [e for e in gen0 if not self._nodes[e].get('is_sibling')]
        # 루트를 roots 마지막으로 (형제 오른쪽 끝)
        if self._root in roots:
            roots.remove(self._root)
            roots.append(self._root)
        gen0_ordered = sibs + roots
        n0 = len(gen0_ordered)

        root_idx = gen0_ordered.index(self._root) if self._root in gen0_ordered else n0 - 1
        start_x0 = _BASE_X - root_idx * _H_GAP

        for i, eid in enumerate(gen0_ordered):
            self._nodes[eid]['x'] = start_x0 + i * _H_GAP
            self._nodes[eid]['y'] = y_of(0)

        # 배우자: gen=0 오른쪽 끝 이후
        rightmost_x = max((self._nodes[e]['x'] for e in gen0_ordered), default=_BASE_X)
        if self._root in spouses_by:
            for j, sp_eid in enumerate(spouses_by[self._root]):
                self._nodes[sp_eid]['x'] = rightmost_x + (j + 1) * _SP_GAP
                self._nodes[sp_eid]['y'] = y_of(0)

        # ── 조상 세대 (gen < 0): 각 세대 중앙 정렬 ───────────────────────
        for gen in sorted(regular):
            if gen >= 0:
                continue
            eids = regular[gen]
            n = len(eids)
            start_x = _BASE_X - (n - 1) * _H_GAP // 2
            for i, eid in enumerate(eids):
                self._nodes[eid]['x'] = start_x + i * _H_GAP
                self._nodes[eid]['y'] = y_of(gen)

        # ── 자손 세대 (gen > 0): 부모 중심 정렬 ─────────────────────────
        for gen in sorted(regular):
            if gen <= 0:
                continue
            eids = regular[gen]
            # 부모 X 평균 → 자녀 중심
            parent_xs: list[int] = []
            for eid in eids:
                for edge in self._edges:
                    if edge['b'] == eid and edge['style'] == 'parent':
                        peid = edge['a']
                        if peid in self._nodes and self._nodes[peid]['gen'] == gen - 1:
                            parent_xs.append(self._nodes[peid]['x'])
                            break
            center = int(sum(parent_xs) / len(parent_xs)) if parent_xs else _BASE_X
            n = len(eids)
            start_x = center - (n - 1) * _H_GAP // 2
            for i, eid in enumerate(eids):
                self._nodes[eid]['x'] = start_x + i * _H_GAP
                self._nodes[eid]['y'] = y_of(gen)

            # 자손 세대 배우자
            rightmost = max(self._nodes[e]['x'] for e in eids)
            for partner_eid in eids:
                if partner_eid in spouses_by:
                    for j, sp_eid in enumerate(spouses_by[partner_eid]):
                        self._nodes[sp_eid]['x'] = rightmost + (j + 1) * _SP_GAP
                        self._nodes[sp_eid]['y'] = y_of(gen)
                    rightmost += len(spouses_by[partner_eid]) * _SP_GAP

    # ── 렌더링 ───────────────────────────────────────────────────────────────

    def _render(self) -> None:
        cv = self._cv
        cv.delete('all')

        if not self._nodes:
            self._placeholder('인물을 검색하거나 엔티티 목록에서 선택하세요.')
            return

        # 1. 연결선 (노드 아래)
        for edge in self._edges:
            a, b = edge['a'], edge['b']
            if a not in self._nodes or b not in self._nodes:
                continue
            self._draw_edge(a, b, edge['style'], edge['rel'])

        # 2. 인물 노드
        for eid in self._nodes:
            self._draw_node(eid)

        # 스크롤 영역 갱신
        xs = [n['x'] for n in self._nodes.values()]
        ys = [n['y'] for n in self._nodes.values()]
        mg = 200
        cv.config(scrollregion=(min(xs)-mg, min(ys)-mg, max(xs)+mg, max(ys)+mg))

    def _node_hw(self, eid: int) -> tuple[int, int]:
        n = self._nodes[eid]
        if n.get('is_spouse_of') is not None:
            return _SP_W, _SP_H
        if eid == self._root:
            return _CTR_W, _CTR_H
        return _NW, _NH

    def _draw_edge(self, a: int, b: int, style: str, rel: str) -> None:
        cv = self._cv
        na, nb = self._nodes[a], self._nodes[b]
        ax, ay = na['x'], na['y']
        bx, by = nb['x'], nb['y']
        aw, ah = self._node_hw(a)
        bw, bh = self._node_hw(b)

        if style == 'spouse':
            col = _CLR['line_spouse']
            # 이중 수평선
            x1 = ax + aw // 2
            x2 = bx - bw // 2
            cv.create_line(x1, ay - 4, x2, ay - 4, fill=col, width=2)
            cv.create_line(x1, ay + 4, x2, ay + 4, fill=col, width=2)
            return

        # parent style: 꺽은선 (L-shape)
        # 위 노드 → 아래 노드
        if ay <= by:
            top_x, top_y = ax, ay + ah // 2
            bot_x, bot_y = bx, by - bh // 2
        else:
            top_x, top_y = bx, by + bh // 2
            bot_x, bot_y = ax, ay - ah // 2

        mid_y = (top_y + bot_y) // 2
        col = _CLR['line']
        cv.create_line(top_x, top_y, top_x, mid_y,   fill=col, width=2)
        cv.create_line(top_x, mid_y, bot_x, mid_y,   fill=col, width=2)
        cv.create_line(bot_x, mid_y, bot_x, bot_y,   fill=col, width=2)

    def _draw_node(self, eid: int) -> None:
        cv = self._cv
        n  = self._nodes[eid]
        x, y = n['x'], n['y']
        is_focus  = (eid == self._focus)
        is_root   = (eid == self._root)
        sp_of     = n.get('is_spouse_of')
        gen       = n['gen']

        # 크기
        w, h = self._node_hw(eid)

        # 색상
        if is_root:
            fill, fg = _CLR['root']
        elif sp_of is not None:
            rel_tag = n.get('_rel_type', 'SPOUSE')
            fill, fg = _CLR['concub'] if rel_tag == 'CONCUBINE' else _CLR['spouse']
        elif n.get('is_sibling'):
            fill, fg = _CLR['sibling']
        elif gen < 0:
            fill, fg = _CLR['ancestor']
        else:
            fill, fg = _CLR['descendant']

        tag = f'P{eid}'
        outline = '#1A3A6B' if is_focus else ('#FFD700' if is_root else '#BDC3C7')
        ow = 3 if is_focus else (2 if is_root else 1)

        _rr(cv, x - w//2, y - h//2, x + w//2, y + h//2,
            r=8, fill=fill, outline=outline, width=ow,
            tags=('person', tag))

        name_y = y - 7 if n.get('has_children') and not n.get('expanded') else y
        cv.create_text(x, name_y, text=n['name'],
                       fill=fg,
                       font=('Malgun Gothic', 9, 'bold' if is_root or is_focus else 'normal'),
                       tags=('person', tag))

        # ▼ 자녀 펼치기 표시
        if n.get('has_children') and not n.get('expanded'):
            exp_tag = f'EXP{eid}'
            cv.create_text(x, y + 9, text='▼',
                           fill='#F39C12',
                           font=('Malgun Gothic', 7, 'bold'),
                           tags=('expand', exp_tag))

    # ── 노드/세대 확장 ────────────────────────────────────────────────────────

    def _expand_node(self, eid: int) -> None:
        if self._nodes[eid].get('expanded'):
            return
        self._nodes[eid]['expanded'] = True
        child_gen = self._nodes[eid]['gen'] + 1

        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                lang = self.lang_getter()
                rows = conn.execute(
                    "SELECT to_person_id, relation_type FROM " + _PR + " "
                    "WHERE from_person_id=? AND relation_type IN ('FATHER','MOTHER') "
                    "AND record_status='LIVE'", (eid,)
                ).fetchall()
                for r in rows:
                    cid = r['to_person_id']
                    if cid not in self._nodes:
                        info = self._get_pinfo(conn, cid, lang)
                        has_ch = bool(conn.execute(
                            "SELECT 1 FROM " + _PR + " WHERE from_person_id=? "
                            "AND relation_type IN ('FATHER','MOTHER') "
                            "AND record_status='LIVE' LIMIT 1", (cid,)
                        ).fetchone())
                        self._nodes[cid] = {
                            **info, 'gen': child_gen,
                            'is_sibling': False, 'is_spouse_of': None,
                            'expanded': False, 'has_children': has_ch,
                            'x': 0, 'y': 0,
                        }
                    key = (eid, cid)
                    if key not in self._edge_set:
                        self._edge_set.add(key)
                        self._edges.append({'a': eid, 'b': cid,
                                            'rel': r['relation_type'], 'style': 'parent'})
        except Exception as e:
            print(f'[expand_node] {e}')
            return

        self._layout()
        self._render()

    def _nav_up(self) -> None:
        """↑: 위로 1세대 확장."""
        if not self._root:
            return
        new_gen = self._gen_min - 1
        top_eids = [eid for eid, n in self._nodes.items()
                    if n['gen'] == self._gen_min and n.get('is_spouse_of') is None]
        added = False
        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                lang = self.lang_getter()
                for eid in top_eids:
                    parents = conn.execute(
                        "SELECT from_person_id, relation_type FROM " + _PR + " "
                        "WHERE to_person_id=? AND relation_type IN ('FATHER','MOTHER') "
                        "AND record_status='LIVE'", (eid,)
                    ).fetchall()
                    for p in parents:
                        pid = p['from_person_id']
                        if pid not in self._nodes:
                            info = self._get_pinfo(conn, pid, lang)
                            self._nodes[pid] = {
                                **info, 'gen': new_gen,
                                'is_sibling': False, 'is_spouse_of': None,
                                'expanded': False, 'has_children': True,
                                'x': 0, 'y': 0,
                            }
                            added = True
                        key = (pid, eid)
                        if key not in self._edge_set:
                            self._edge_set.add(key)
                            self._edges.append({'a': pid, 'b': eid,
                                                'rel': p['relation_type'], 'style': 'parent'})
        except Exception as e:
            print(f'[nav_up] {e}')
            return
        if added:
            self._gen_min = new_gen
        self._layout()
        self._render()

    def _nav_down(self) -> None:
        """↓: 최하단 모든 노드의 자녀 일괄 전개."""
        if not self._root:
            return
        bottom_eids = [eid for eid, n in self._nodes.items()
                       if n['gen'] == self._gen_max and n.get('is_spouse_of') is None
                       and not n.get('expanded') and n.get('has_children')]
        if not bottom_eids:
            return

        added = False
        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                lang = self.lang_getter()
                for eid in bottom_eids:
                    self._nodes[eid]['expanded'] = True
                    child_gen = self._nodes[eid]['gen'] + 1
                    rows = conn.execute(
                        "SELECT to_person_id, relation_type FROM " + _PR + " "
                        "WHERE from_person_id=? AND relation_type IN ('FATHER','MOTHER') "
                        "AND record_status='LIVE'", (eid,)
                    ).fetchall()
                    for r in rows:
                        cid = r['to_person_id']
                        if cid not in self._nodes:
                            info = self._get_pinfo(conn, cid, lang)
                            has_ch = bool(conn.execute(
                                "SELECT 1 FROM " + _PR + " WHERE from_person_id=? "
                                "AND relation_type IN ('FATHER','MOTHER') "
                                "AND record_status='LIVE' LIMIT 1", (cid,)
                            ).fetchone())
                            self._nodes[cid] = {
                                **info, 'gen': child_gen,
                                'is_sibling': False, 'is_spouse_of': None,
                                'expanded': False, 'has_children': has_ch,
                                'x': 0, 'y': 0,
                            }
                            added = True
                        key = (eid, cid)
                        if key not in self._edge_set:
                            self._edge_set.add(key)
                            self._edges.append({'a': eid, 'b': cid,
                                                'rel': r['relation_type'], 'style': 'parent'})
        except Exception as e:
            print(f'[nav_down] {e}')
            return
        if added:
            self._gen_max += 1
        self._layout()
        self._render()

    # ── 이벤트 핸들러 ─────────────────────────────────────────────────────────

    def _hit(self, ex: int, ey: int) -> tuple[int | None, bool]:
        """(eid | None, is_expand_btn) 반환."""
        cx = self._cv.canvasx(ex)
        cy = self._cv.canvasy(ey)
        items = list(reversed(self._cv.find_overlapping(cx-3, cy-3, cx+3, cy+3)))
        for item in items:
            for tag in self._cv.gettags(item):
                if tag.startswith('EXP') and tag[3:].isdigit():
                    return int(tag[3:]), True
        for item in items:
            for tag in self._cv.gettags(item):
                if tag.startswith('P') and tag[1:].isdigit():
                    return int(tag[1:]), False
        return None, False

    def _press(self, event):
        self._drag_x = event.x
        self._drag_y = event.y
        self._dragging = False
        self._cv.scan_mark(event.x, event.y)

    def _b1_motion(self, event):
        if abs(event.x - self._drag_x) > 3 or abs(event.y - self._drag_y) > 3:
            self._dragging = True
        if self._dragging:
            self._cv.scan_dragto(event.x, event.y, gain=1)

    def _release(self, event):
        if not self._dragging:
            eid, is_exp = self._hit(event.x, event.y)
            if eid is not None:
                if is_exp:
                    self._expand_node(eid)
                else:
                    self._focus = eid
                    self._render()
                    self._refresh_info(eid)
        self._dragging = False

    def _dbl_click(self, event):
        eid, is_exp = self._hit(event.x, event.y)
        if eid is not None and not is_exp:
            self.load_person(eid)

    # ── 검색 ─────────────────────────────────────────────────────────────────

    def _on_search(self):
        q = self._search_var.get().strip()
        if not q:
            self._hide_results()
            return
        lang = self.lang_getter()
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT em.entity_id, ta.contents "
                    "FROM sys_text_asset ta "
                    "JOIN sys_entity_master em ON em.entity_id=ta.clicked_id "
                    "WHERE ta.text_type='ENTITY_NAME' AND ta.lang_code=? "
                    "  AND ta.contents LIKE ? AND em.entity_type='PERSON' "
                    "  AND em.record_status='LIVE' "
                    "ORDER BY em.importance DESC LIMIT 20",
                    (lang, f'%{q}%')
                ).fetchall()
        except Exception:
            return
        self._search_results = [(r[0], r[1]) for r in rows]
        self._result_lb.delete(0, 'end')
        for _, name in self._search_results:
            self._result_lb.insert('end', f'  {name}')
        if self._search_results:
            self._result_outer.place(in_=self._search_ent, x=0,
                                     y=self._search_ent.winfo_height()+2, width=220)
            self._result_outer.lift()
        else:
            self._hide_results()

    def _on_result_select(self, _=None):
        sel = self._result_lb.curselection()
        if not sel:
            return
        eid, name = self._search_results[sel[0]]
        self._search_var.set(name)
        self._hide_results()
        self.load_person(eid)

    def _hide_results(self):
        self._result_outer.place_forget()

    # ── 정보 패널 ─────────────────────────────────────────────────────────────

    def _refresh_info(self, eid: int) -> None:
        n = self._nodes.get(eid)
        if not n:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                _lang = (self.lang_getter() if callable(self.lang_getter) else 'KO') or 'KO'
                desc = (conn.execute(
                    "SELECT contents FROM sys_text_asset "
                    "WHERE text_type='ENTITY_DESC' AND clicked_id=? AND lang_code IN (?,'EN','KO') AND record_status='LIVE' "
                    "ORDER BY CASE lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                    (eid, _lang, _lang)
                ).fetchone() or [None])[0]
                peris = conn.execute(
                    # ★ 2026-08-24 통합 표(`ENTI_PERI`)
                    "SELECT ep.rel_code AS role_in_peri, "
                    "       (ep.milestone_type IS NOT NULL) AS is_milestone, "
                    "       pa.start_vid, pa.end_vid, pa.peri_code "
                    "FROM sys_link_asset ep "
                    "JOIN sys_pericope_asset pa ON pa.pericope_id=ep.target_id "
                    "WHERE ep.link_type='ENTI_PERI' AND ep.clicked_id=? "
                    "  AND COALESCE(ep.record_status,'LIVE')='LIVE' "
                    "ORDER BY (ep.milestone_type IS NOT NULL) DESC, ep.importance DESC",
                    (eid,)
                ).fetchall()
                peri_labels = [_peri_label(conn, p['start_vid'], p['end_vid'], _lang)
                               for p in peris]
        except Exception:
            return

        ys, ye = n.get('ys'), n.get('ye')
        years = ''
        if ys:
            years = _fmt_yr(ys) + (f' ~ {_fmt_yr(ye)}' if ye else '')
        meta = [p for p in [
            years,
            f'지파: {n["tribe"]}' if n.get('tribe') else '',
            f'역할: {n["role"]}' if n.get('role') else '',
        ] if p]

        self._info_name.config(text=n['name'])
        self._info_meta.config(text='  |  '.join(meta))

        self._info_desc.config(state='normal')
        self._info_desc.delete('1.0', 'end')
        self._info_desc.insert('end', desc or i18n.t('FT_NO_DESC', '(설명문 없음)'))
        self._info_desc.config(state='disabled')

        self._info_peri.delete(0, 'end')
        self._peri_data = []
        for i, p in enumerate(peris):
            ms = '★ ' if p['is_milestone'] else '   '
            role = i18n.t('FT_ROLE_'+str(p['role_in_peri']), _ROLE_KO.get(p['role_in_peri'], p['role_in_peri'] or ''))
            self._info_peri.insert('end', f'{ms}{peri_labels[i]}  [{role}]')
            self._peri_data.append((p['start_vid'], p['end_vid']))

        self._info_verse.config(state='normal')
        self._info_verse.delete('1.0', 'end')
        self._info_verse.config(state='disabled')

    def _clear_info(self):
        self._info_name.config(text=i18n.t('FT_SELECT','인물을 선택하세요'))
        self._info_meta.config(text='')
        self._info_desc.config(state='normal')
        self._info_desc.delete('1.0', 'end')
        self._info_desc.config(state='disabled')
        self._info_peri.delete(0, 'end')
        self._peri_data = []
        self._info_verse.config(state='normal')
        self._info_verse.delete('1.0', 'end')
        self._info_verse.config(state='disabled')

    def _on_peri_select(self, _=None):
        sel = self._info_peri.curselection()
        if not sel:
            return
        start_vid, end_vid = self._peri_data[sel[0]]
        if not start_vid:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                import verse_tier
                _ver = verse_tier.get_version(conn)   # 단일 소스(2026-07-30)
                rows = conn.execute(
                    "SELECT bi.chapter, bi.verse, bc.verse_text "
                    "FROM bible_content bc "
                    "JOIN bible_index bi ON bi.verse_id = bc.verse_id "
                    "WHERE bc.version_code=? "
                    "  AND bc.verse_id >= ? AND bc.verse_id <= ? "
                    "ORDER BY bc.verse_id",
                    (_ver, start_vid, end_vid)
                ).fetchall()
        except Exception:
            return
        self._info_verse.config(state='normal')
        self._info_verse.delete('1.0', 'end')
        prev_chap = None
        for r in rows:
            if r[0] != prev_chap:
                if prev_chap is not None:
                    self._info_verse.insert('end', '\n')
                prev_chap = r[0]
            bidi.insert(self._info_verse, f'{r[1]}  {r[2]}\n')
        self._info_verse.config(state='disabled')
        self._info_verse.yview_moveto(0)

    # ── 헬퍼 ─────────────────────────────────────────────────────────────────

    def _update_nav_label(self):
        if self._root and self._root in self._nodes:
            self._nav_lbl.config(text=self._nodes[self._root]['name'])
        else:
            self._nav_lbl.config(text='')

    def _placeholder(self, text: str):
        self._cv.create_text(_BASE_X, 300, text=text,
                             font=('Malgun Gothic', 11), fill='#95A5A6')
