# -*- coding: utf-8 -*-
"""PERI_DESC 작성 준비 — 자료 수집을 한 번에 (영구 도구, 읽기 전용)

  python -X utf8 db_peri_prep.py --book 41 --ch 14-16
  python -X utf8 db_peri_prep.py --book 41 --ch 14        # 한 장
  python -X utf8 db_peri_prep.py --book 41 --todo         # 미작성분 전체 목록만

peri.md §3-0 이 요구하는 작성 절차의 1번(절별 VERS_DESC 를 먼저 읽는다)을
한 명령으로 끝낸다. 이전에는 페리코프 목록 · 본문 덤프 · VERS_DESC 덤프 ·
규칙 확인 · 스키마 확인이 각각 따로였고, 그만큼 승인이 필요했다.

출력 (기본 경로 = 스크래치패드, --out 으로 변경):
  peri_<bcode>_<ch>.md    장마다 하나 — 페리코프별 KRV/BSB 본문 + 절별 VERS_DESC(KO EXPERT 우선·없으면 LAY)
  draft_<bcode>_<범위>.json  db_peri_load.py 가 먹는 초안 뼈대 (KO/EN 빈칸)

읽기 전용이다. DB 를 쓰지 않는다.
"""
import argparse
import io
import json
import os
import sys

import appdb
import db_peri_gate as g

DB = 'bible_master.db'
# 출력은 반드시 프로젝트 안에 둔다. 처음에 %TEMP% 로 뒀더니 자료 파일을 열 때마다
# 승인이 필요했다(프로젝트 밖 경로라 Read 가 매번 물음). 한 장에 승인 한 번이
# 되려면 자료가 프로젝트 안에 있어야 한다. .gitignore 대상.
DEFAULT_OUT = os.environ.get(
    'PERI_PREP_OUT',
    os.path.join(os.path.dirname(os.path.abspath(__file__)), '_peri_prep'))


def parse_ch(s):
    if '-' in s:
        a, b = s.split('-', 1)
        return list(range(int(a), int(b) + 1))
    return [int(s)]


def book_name(conn, bcode):
    # book_names.book_code 는 bcode 와 같은 정수다. bible_index 에 book_code 컬럼은 없다
    # (예전 구현이 서브쿼리로 우회하다 상관 참조가 되어 늘 창세기를 반환했다).
    r = conn.execute("SELECT full_name FROM book_names WHERE book_code=? "
                     "AND lang_code='KO'", (bcode,)).fetchone()
    return r[0] if r else f'bcode {bcode}'


def peris_of(conn, bcode, chapters=None, only_missing=False):
    q = """SELECT p.pericope_id, p.start_vid, p.end_vid, bi.chapter, bi.verse,
                  bj.chapter, bj.verse,
                  (SELECT title FROM sys_text_asset WHERE clicked_id=p.pericope_id
                    AND text_type='PERI_TITLE' AND lang_code='KO'),
                  (SELECT title FROM sys_text_asset WHERE clicked_id=p.pericope_id
                    AND text_type='PERI_TITLE' AND lang_code='EN'),
                  (SELECT COUNT(*) FROM sys_text_asset WHERE clicked_id=p.pericope_id
                    AND text_type='PERI_DESC' AND COALESCE(record_status,'LIVE')='LIVE')
             FROM sys_pericope_asset p
             JOIN bible_index bi ON bi.verse_id=p.start_vid
             JOIN bible_index bj ON bj.verse_id=p.end_vid
            WHERE p.peri_type='BODY' AND bi.bcode=?
              AND COALESCE(p.record_status,'LIVE')='LIVE'"""
    args = [bcode]
    if chapters:
        q += ' AND bi.chapter IN (%s)' % ','.join('?' * len(chapters))
        args += chapters
    q += ' ORDER BY p.start_vid'
    rows = conn.execute(q, args).fetchall()
    if only_missing:
        rows = [r for r in rows if r[9] == 0]
    return rows


# ── 주석 DB 자료 (2026-08-02 신설) ────────────────────────────────────────
# 재료가 얇은 책에서 배경을 어디서 가져올 것인가에 대한 답이다.
#
# 실측(VERS_DESC KO EXPERT, 1000자당 배경 표현):  마가 0.51 · 요한 0.34 · 사도행전 0.16
# 사도행전 재료는 딱딱하지 않다 — 오히려 주석 장치 0.00 · 문서 주어 1.51 로 가장 깨끗하다.
# 문제는 **평이하게 줄거리만 적혀 있다**는 것이다. 그래서 압축하면 줄거리만 남는다.
# 사용자 반려("구절 내용을 줄줄이 재정리하는 느낌")의 실제 원인이 이것이다.
#
# 그런데 같은 DB 안에 **사도행전 주석이 약 5MB** 들어 있다(BARNES_NT 936 · CLARKE 884
# entries). 배경을 내 기억에서 끌어오는 대신 여기서 가져오면 두 가지가 한꺼번에 해결된다.
#   ① 얇은 재료를 보충한다 — 로마 관직·지리·화폐·관습이 이 두 주석의 주특기다.
#   ② **근거를 남길 수 있다**(chapter.md §6). 내 기억은 검증 절차가 없지만 이건 행이 있다.
#
# ⚠ `end_vid` 가 33,178행 중 29,716행에서 NULL 이다. `start_vid<=? AND end_vid>=?` 만
#   쓰면 조용히 0건이 나온다(실제로 당했다). CLAUDE.md §8 이 적어 둔 대로
#   `start_vid=? OR (start_vid<=? AND end_vid>=?)` 로 조회할 것.
# **소스마다 층이 다르다** (2026-08-02 실측, 신약 전체 평균):
#   BARNES_NT  6,521항목 · 2,274자 · 1.0절   <- 절 단위
#   CLARKE     6,669항목 · 1,170자 · 1.0절   <- 절 단위
#   JFB          475항목 · 10,706자 · 16.5절 <- **단락 단위. 페리코프와 층이 같다**
#   HENRY_MHC    257항목 · 52,350자 · 30.8절 <- 장 단위. 장 설명문(chapter.md)의 몫
# 그래서 절 단위 소스는 절마다, 단락 단위 소스는 페리코프마다 한 번 뽑는다.
# JFB 를 넣는 이유가 하나 더 있다 — 마가는 BARNES 39% · CLARKE 47% 로 구멍이 큰데
# JFB 는 96% 다. 절 단위 소스가 비는 자리를 이쪽이 메운다.
COMM_SRC_VERSE = ('BARNES_NT', 'CLARKE')
COMM_SRC_PERI = ('JFB',)
COMM_SRC = COMM_SRC_VERSE + COMM_SRC_PERI
COMM_MAX = 1500      # 절 단위 소스의 절당 글자 상한(배경은 대개 앞머리에 있다)
COMM_MAX_PERI = 6000  # 단락 단위 소스의 페리코프당 상한


def _fetch(conn, code, where, params, cap):
    r = conn.execute(
        f"""SELECT x.body_text FROM sys_commentary_entry e
              JOIN sys_commentary_source s ON s.commentary_id = e.commentary_id
              JOIN sys_commentary_text  x ON x.entry_id = e.entry_id
             WHERE s.commentary_code = ? AND {where}
               AND x.text_variant = 'ORIGINAL'
               AND COALESCE(e.record_status,'LIVE') = 'LIVE'
               AND COALESCE(x.record_status,'LIVE') = 'LIVE'
             ORDER BY LENGTH(x.body_text) DESC LIMIT 1""",
        (code,) + params).fetchone()
    if not r or not r[0]:
        return None
    t = ' '.join(r[0].split())
    return t[:cap].rsplit(' ', 1)[0] + ' …' if len(t) > cap else t


def commentary_for(conn, vid, sources, cap):
    """절 단위 소스 — 그 한 절에 붙은 주석."""
    out = []
    for code in sources:
        # ⚠ end_vid 가 33,178행 중 29,716행에서 NULL 이다. start_vid= 조건이 먼저다.
        t = _fetch(conn, code, '(e.start_vid = ? OR (e.start_vid <= ? AND e.end_vid >= ?))',
                   (vid, vid, vid), cap)
        if t:
            out.append((code, t))
    return out


def commentary_for_span(conn, sv, ev, sources, cap):
    """단락 단위 소스 — 페리코프 범위와 겹치는 항목 하나."""
    out = []
    for code in sources:
        t = _fetch(conn, code,
                   'e.start_vid <= ? AND COALESCE(e.end_vid, e.start_vid) >= ?',
                   (ev, sv), cap)
        if t:
            out.append((code, t))
    return out


def rules_digest():
    """게이트가 실제로 검사하는 값 — 단일 소스는 db_peri_gate 다."""
    return f"""작성 규칙 (db_peri_gate.py 가 기계 검사하는 항목만. 서사 = bcode 40~44)
  분량      KO {g.LEN_KO_NARR[0]}~{g.LEN_KO_NARR[1]}자 · EN {g.LEN_EN_NARR[0]}~{g.LEN_EN_NARR[1]}자
  문장      KO 문장 평균 {g.AVG_SENT_MIN}자 이상 (짧게 끊지 말고 연결어미로 이을 것)
  겹침      본문 어휘 겹침 {g.OVERLAP_WARN}% 이하 권장 · {g.OVERLAP_FAIL}% 초과 실패
  문체      경어체(~습니다). 평서체 종결(~이다/~한다) 금지
  금지1     예고형 — 중요합니다 / 핵심은 / 눈여겨볼 / 주목할 것 / 뜻밖 / 흥미로운 / 특이합니다
  금지2     은유 요약 — 예고편 / 두 무대 / 한 폭의 / 메아리 / 물결처럼 / 씨줄 / 날줄 / 밀고 가
  금지3     메타 문장 — 말하려는 것이 / 이 대목이 말하는 것은
  금지4     문서 관찰 — 배치가 / …다는 서술이 / 이 문장이 놓 / 눈여겨볼 만
  금지5     번역투 — 에 있어서 / 되어지 / 로 하여금 / 문맥 한가운데 / 않을 수 없다
  한도      "…라는 것입니다" 2회 · 접속뼈대어(그다음에/그러고는/이어서) 2회
            저자 주어 문장 2개 (야고보·바울·요한·베드로·유다·모세·다윗 + 조사)
  기타      동그라미 번호 금지 · 헬라어는 한글(헬라어) 순서·핵심어 1개 · 교단 귀속어 금지
            첫머리에 제목 재진술 금지 · 큰따옴표 인용으로 시작 금지

작성 절차 (peri.md §3-0 — 이 순서를 지키지 않으면 재진술이 된다)
  1. 아래 절별 VERS_DESC 를 먼저 읽는다. 본문만 읽고 쓰면 반드시 재진술이 된다.
  2. 흩어진 절별 관찰을 관통하는 줄기 하나를 찾는다. 그게 페리코프의 몫이다.
  3. 모든 절을 다루지 않는다. 줄기에 실리는 것만 가져온다.
  4. 본문 문장을 다시 쓰지 않는다. KRV 옛말투를 옮기면 겹침이 곧바로 올라간다.
  5. 본문에 없는 것을 보태지 않는다."""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--book', type=int, required=True)
    ap.add_argument('--ch', help='14 또는 14-16')
    ap.add_argument('--todo', action='store_true', help='미작성 페리코프 목록만 출력')
    ap.add_argument('--out', default=DEFAULT_OUT)
    ap.add_argument('--comm', action='store_true',
                    help='주석 DB 자료를 comm_<bcode>_<ch>.md 로 함께 뽑는다 (배경 보충용)')
    ap.add_argument('--comm-src', default=','.join(COMM_SRC),
                    help=f'주석 소스 (기본 {",".join(COMM_SRC)})')
    ap.add_argument('--comm-max', type=int, default=COMM_MAX,
                    help=f'소스·절당 글자 상한 (기본 {COMM_MAX})')
    a = ap.parse_args()
    conn = appdb.connect(DB)
    bname = book_name(conn, a.book)

    if a.todo or not a.ch:
        rows = peris_of(conn, a.book, None, only_missing=True)
        if not rows:
            print(f'{bname}({a.book}): 미작성 페리코프 없음')
            return
        by_ch = {}
        for r in rows:
            by_ch.setdefault(r[3], []).append(r)
        print(f'{bname}({a.book}) 미작성 {len(rows)}개')
        for ch in sorted(by_ch):
            ids = ', '.join(str(r[0]) for r in by_ch[ch])
            print(f'  {ch}장: {len(by_ch[ch])}개  peri {ids}')
        print(f'\n다음: python -X utf8 db_peri_prep.py --book {a.book} '
              f'--ch {min(by_ch)}-{min(min(by_ch) + 2, max(by_ch))}')
        return

    chapters = parse_ch(a.ch)
    os.makedirs(a.out, exist_ok=True)
    rows = peris_of(conn, a.book, chapters)
    if not rows:
        print('해당 장에 BODY 페리코프가 없다.'); sys.exit(1)

    done = [r for r in rows if r[9] > 0]
    todo = [r for r in rows if r[9] == 0]
    print(f'{bname}({a.book}) {a.ch}장 — 페리코프 {len(rows)}개 '
          f'(미작성 {len(todo)} · 기작성 {len(done)})')
    for r in rows:
        mark = '  ' if r[9] == 0 else '* '
        print(f'  {mark}peri {r[0]}  {r[3]}:{r[4]}-{r[5]}:{r[6]}  '
              f'{r[2]-r[1]+1}절  | {r[7]} / {r[8]}')
    if done:
        print('  (* = 이미 PERI_DESC 있음 — 초안 뼈대에서 제외)')

    written = []
    for ch in chapters:
        crows = [r for r in rows if r[3] == ch]
        if not crows:
            continue
        L = [f'# {bname} {ch}장 — 작성 자료', '', rules_digest(), '']
        for pid, sv, ev, c1, v1, c2, v2, tko, ten, has in crows:
            L.append(f'\n{"="*70}')
            L.append(f'## peri {pid}  {c1}:{v1}-{c2}:{v2}  ({ev-sv+1}절)'
                     + ('   [이미 작성됨]' if has else ''))
            L.append(f'제목 KO: {tko}')
            L.append(f'제목 EN: {ten}')
            L.append(f'\n### 본문')
            for vid in range(sv, ev + 1):
                cc, vv = conn.execute(
                    'SELECT chapter,verse FROM bible_index WHERE verse_id=?', (vid,)).fetchone()
                krv = conn.execute("SELECT verse_text FROM bible_content WHERE verse_id=? "
                                   "AND version_code='KRV'", (vid,)).fetchone()
                bsb = conn.execute("SELECT verse_text FROM bible_content WHERE verse_id=? "
                                   "AND version_code='BSB'", (vid,)).fetchone()
                L.append(f'{cc}:{vv}  KRV  {krv[0] if krv else "(없음)"}')
                L.append(f'      BSB  {bsb[0] if bsb else "(없음)"}')
            L.append(f'\n### 절별 VERS_DESC (KO EXPERT/LAY) — 이것을 읽고 줄기를 찾는다')
            for vid in range(sv, ev + 1):
                cc, vv = conn.execute(
                    'SELECT chapter,verse FROM bible_index WHERE verse_id=?', (vid,)).fetchone()
                # EXPERT 가 가장 밀도 높지만 LAY 만 있는 책이 있다(구약 — data.md).
                # 없는 티어를 고집하면 재료가 통째로 비고, 그러면 §3-0 이 금지한
                # "재료를 안 보고 요약하기" 가 된다. EXPERT 우선 · 없으면 LAY.
                r = conn.execute(
                    "SELECT contents, text_variant FROM sys_text_asset WHERE clicked_id=? "
                    "AND text_type='VERS_DESC' AND lang_code='KO' "
                    "AND text_variant IN ('EXPERT','LAY') "
                    "AND COALESCE(record_status,'LIVE')='LIVE' "
                    "ORDER BY CASE text_variant WHEN 'EXPERT' THEN 0 ELSE 1 END "
                    "LIMIT 1", (vid,)).fetchone()
                tag = f' [{r[1]}]' if r and r[1] else ''
                L.append(f'\n--- {cc}:{vv}{tag} ---')
                L.append(r[0].strip() if r and r[0] else '(VERS_DESC 없음)')
            L.append('')
        p = os.path.join(a.out, f'peri_{a.book}_{ch}.md')
        io.open(p, 'w', encoding='utf-8').write('\n'.join(L))
        written.append(p)

        if a.comm:
            srcs = [s.strip() for s in a.comm_src.split(',') if s.strip()]
            C = [f'# {bname} {ch}장 — 배경 자료 (주석 DB)', '',
                 '절별 VERS_DESC 가 줄거리 위주라 배경이 얇을 때 여기서 보충한다.',
                 '**줄거리는 가져오지 않는다** — 이미 절별설명에 있다. 그 시대는 알았고',
                 '지금 독자는 모르는 것(관직·화폐·지리·관습·법)만 가져온다.',
                 '학설이 갈리는 대목은 소개하지 않는다(peri.md §3-0c 주석 장치).',
                 '', f'출처: {", ".join(srcs)} — 전부 PUBLIC_DOMAIN. 쓴 것은 초안 `sources` 에 남긴다.', '']
            n_hit = 0
            v_srcs = [s for s in srcs if s in COMM_SRC_VERSE]
            p_srcs = [s for s in srcs if s in COMM_SRC_PERI]
            for pid, sv, ev, c1, v1, c2, v2, tko, ten, has in crows:
                C.append(f'\n{"="*70}')
                C.append(f'## peri {pid}  {c1}:{v1}-{c2}:{v2}   {tko}')
                for code, t in commentary_for_span(conn, sv, ev, p_srcs, COMM_MAX_PERI):
                    C.append(f'\n[{code} — 단락 전체]\n{t}')
                for vid in range(sv, ev + 1):
                    cc, vv = conn.execute(
                        'SELECT chapter,verse FROM bible_index WHERE verse_id=?', (vid,)).fetchone()
                    got = commentary_for(conn, vid, v_srcs, a.comm_max)
                    if not got:
                        continue
                    n_hit += 1
                    C.append(f'\n--- {cc}:{vv} ---')
                    for code, t in got:
                        C.append(f'[{code}] {t}')
            cp = os.path.join(a.out, f'comm_{a.book}_{ch}.md')
            io.open(cp, 'w', encoding='utf-8').write('\n'.join(C))
            written.append(f'{cp}  ({n_hit}절 적중)')

    skel = {'book': a.book, 'peris': {}, 'title_fix': {}}
    for r in todo:
        skel['peris'][str(r[0])] = {'KO': '', 'EN': ''}
    dp = os.path.join(a.out, f'draft_{a.book}_{a.ch}.json')
    io.open(dp, 'w', encoding='utf-8').write(
        json.dumps(skel, ensure_ascii=False, indent=2))

    print('\n자료:')
    for p in written:
        print(f'  {p}')
    print(f'초안 뼈대:\n  {dp}')
    print(f'\n다음: 초안을 채운 뒤\n'
          f'  python -X utf8 db_peri_load.py --check {dp}')


if __name__ == '__main__':
    main()
