# -*- coding: utf-8 -*-
"""db_meyer_plans.py — 마이어 『Our Daily Homily』 묵상플랜
================================================================================
`python db_meyer_plans.py --selftest`   — 의무
`python db_meyer_plans.py --plan`       — 구성표 (적재 전 검토용)
`python db_meyer_plans.py --apply`      — 적재 (멱등)

━━ 무엇을 만드나 (2026-08-22 사용자 확정 「네 추천대로 하자」) ━━━━━━━━━━━━
  **가) 전권 통독 1,189일** — 성경 창세기 1장부터 계시록 22장까지 한 장에
       한 편. 원저의 순서 그대로라 **내 판단이 안 들어간다**(cat 12).
  **나) 성경 66권 — 권별 플랜 66개** — 「지금 창세기를 읽는다」는 사람이
       그 권만 고른다(cat 신설, 묶음 하나 아래 66개).
  ⚠ **365일 발췌는 만들지 않는다** — 1,189편에서 365편을 고르는 순간 그것은
    마이어의 책이 아니라 내가 만든 선집이다(사용자 동의).

━━ 하루의 구성 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      BOOK_TEXT  그 편 (unit_key = `BOOK_<unit_id>`) · 범위 = 그 장 전체
      CORE       **그 편이 인용한 그 절** (사용자 확정 「원문에 충실」)
  ⚠ 인용 절을 못 찾은 149편은 **그 장 전체**로 둔다 — 짐작으로 절을 찍지
    않는다(절은 제목↔성경 본문 대조로 찾은 것이고 87.5%만 확실하다).
  ⚠ **`meditation_focus` 는 비운다.** 1,189일에 한 줄씩 지어 넣으면 반드시
    형식화된다. 선례가 있다 — 스펄전 시편 150일(plan 95)도 비어 있고,
    디다케 16일처럼 사람이 쓸 수 있는 분량일 때만 채웠다.

⚠ 옛 껍데기 `MEYER_ODH_7D`(plan 60)·`MEYER_ODH_365D`(61)는 스케줄이 0행인
  채 HIDE 로 있었다. **61 을 전권 통독으로 되쓰고** 60 은 HIDE 로 남긴다
  (지우지 않는다 — 되돌릴 수 있게).
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import appdb

DB = 'bible_master.db'
BOOK_CODE = 'MEYER_ODH'
CAT_ALL = 12                 # 이미 있는 「마이어 일일 묵상」 묶음을 되쓴다
CAT_BOOKS = 228              # 신설 — 성경 66권
PLAN_ALL = 61                # 옛 `MEYER_ODH_365D` 를 되쓴다
PLAN_BOOK_FROM = 129         # 66권 플랜 시작 번호
NAME_ALL = '마이어 전권 통독'
NAME_BOOKS = '마이어 성경 66권'
SORT_ALL, SORT_BOOKS = 30, 35


def units(conn):
    """→ [(unit_id, seq, bcode, chapter, start_vid, end_vid, core_vid)]"""
    bid = conn.execute("SELECT book_id FROM sys_book_asset WHERE book_code=?",
                       (BOOK_CODE,)).fetchone()
    if not bid:
        return []
    out = []
    for uid, seq, kv, sv, ev in conn.execute(
            "SELECT unit_id, sequence, key_verse_ref, start_vid, end_vid"
            "  FROM sys_book_unit WHERE book_id=?"
            "   AND COALESCE(record_status,'LIVE')='LIVE'"
            " ORDER BY sequence", (bid[0],)):
        r = conn.execute("SELECT bcode, chapter FROM bible_index"
                         " WHERE verse_id=?", (sv,)).fetchone()
        if not r:
            continue
        bc, ch = r
        core_s, core_e = sv, ev          # 절을 못 찾았으면 그 장 전체
        m = re.match(r'^(.+?)\s+(\d+):(\d+)$', kv or '')
        if m:
            v = conn.execute("SELECT verse_id FROM bible_index"
                             " WHERE bcode=? AND chapter=? AND verse=?",
                             (bc, int(m.group(2)), int(m.group(3)))).fetchone()
            if v:
                core_s = core_e = v[0]
        out.append((uid, seq, bc, ch, sv, ev, core_s, core_e))
    return out


def books_of(rows):
    """→ [(bcode, [행…])] — 정경 순서."""
    out, cur, bc0 = [], [], None
    for r in rows:
        if r[2] != bc0:
            if cur:
                out.append((bc0, cur))
            cur, bc0 = [], r[2]
        cur.append(r)
    if cur:
        out.append((bc0, cur))
    return out


def _names(conn, bc):
    """그 성경책의 언어별 이름 {lang: full_name}."""
    return {l.upper(): n for l, n in conn.execute(
        "SELECT lang_code, full_name FROM book_names WHERE book_code=?"
        "   AND full_name IS NOT NULL AND full_name<>''", (bc,))}


def _cat(conn, cat_id, parent, sort_order, ko, dry):
    if dry:
        return
    conn.execute(
        "INSERT INTO sys_plan_category(cat_id,parent_id,sort_order,scope,"
        "record_status) VALUES(?,?,?,'BOOK','LIVE')"
        " ON CONFLICT(cat_id) DO UPDATE SET parent_id=excluded.parent_id,"
        " sort_order=excluded.sort_order, scope='BOOK', record_status='LIVE'",
        (cat_id, parent, sort_order))
    _text(conn, 'PLAN_CAT_NAME', cat_id, {'KO': ko}, dry)


def _text(conn, ttype, cid, by_lang, dry):
    if dry:
        return
    for lang, val in by_lang.items():
        if not val:
            continue
        conn.execute("DELETE FROM sys_text_asset WHERE text_type=?"
                     "  AND clicked_id=? AND UPPER(lang_code)=?",
                     (ttype, cid, lang.upper()))
        conn.execute(
            "INSERT INTO sys_text_asset(text_type,clicked_id,lang_code,"
            "title,contents,record_status) VALUES(?,?,?,?,?,'LIVE')",
            (ttype, cid, lang.upper(), val, val))


def _plan(conn, pid, code, cat_id, days, titles, dry):
    if dry:
        return
    conn.execute(
        "INSERT INTO sys_bible_plan(plan_id,plan_code,plan_type,plan_category,"
        "cat_id,duration_days,track_count,record_status)"
        " VALUES(?,?,'BOOK_BASED','THEMATIC',?,?,1,'LIVE')"
        " ON CONFLICT(plan_id) DO UPDATE SET plan_code=excluded.plan_code,"
        " plan_type='BOOK_BASED', plan_category='THEMATIC',"
        " cat_id=excluded.cat_id, duration_days=excluded.duration_days,"
        " record_status='LIVE'", (pid, code, cat_id, days))
    _text(conn, 'PLAN_TITLE', pid, titles, dry)


def _sched(conn, pid, rows, dry):
    """하루 = BOOK_TEXT + CORE. 멱등 — 그 플랜 것을 지우고 다시 넣는다."""
    if dry:
        return len(rows) * 2
    conn.execute("DELETE FROM sys_plan_schedule WHERE plan_id=?", (pid,))
    n = 0
    for day, (uid, seq, bc, ch, sv, ev, cs, ce) in enumerate(rows, 1):
        # ★ **구절이 먼저, 도서 본문이 뒤** (2026-08-22 사용자 지시
        #   「구절이 도서 본문 앞에 항상 추가적으로 표시되어야 한다」).
        #   다른 플랜이 「구절 → 설명문」인 것과 같은 차례다 — 도서묵상은
        #   설명문 자리를 도서 본문이 대신하므로 구절이 앞이라야 한다.
        #   ⚠ 코드에 이미 같은 원칙이 적혀 있다(`_build_section`):
        #     「설명문을 구절 앞에 두면 본문을 읽기 전에 해설부터 읽게 된다」.
        conn.execute(
            "INSERT INTO sys_plan_schedule(plan_id,day,track,start_vid,"
            "end_vid,stage_type,sort_order) VALUES(?,?,1,?,?,'CORE',1)",
            (pid, day, cs, ce))
        conn.execute(
            "INSERT INTO sys_plan_schedule(plan_id,day,track,start_vid,"
            "end_vid,stage_type,sort_order,unit_key)"
            " VALUES(?,?,1,?,?,'BOOK_TEXT',2,?)",
            (pid, day, sv, ev, 'BOOK_%d' % uid))
        n += 2
    return n


def apply(conn, dry=False):
    rows = units(conn)
    if len(rows) != 1189:
        raise SystemExit('마이어 편이 %d개 — 1,189편이어야 한다' % len(rows))
    made = []
    # 가) 전권 통독
    _cat(conn, CAT_ALL, 4, SORT_ALL, NAME_ALL, dry)
    _plan(conn, PLAN_ALL, 'MEYER_ODH_ALL', CAT_ALL, len(rows),
          {'KO': NAME_ALL, 'EN': 'Meyer — Whole Bible'}, dry)
    made.append((PLAN_ALL, NAME_ALL, len(rows), _sched(conn, PLAN_ALL, rows,
                                                       dry)))
    # 나) 성경 66권
    _cat(conn, CAT_BOOKS, 4, SORT_BOOKS, NAME_BOOKS, dry)
    for i, (bc, rs) in enumerate(books_of(rows)):
        pid = PLAN_BOOK_FROM + i
        nm = _names(conn, bc)
        _plan(conn, pid, 'MEYER_ODH_B%02d' % bc, CAT_BOOKS, len(rs), nm, dry)
        made.append((pid, nm.get('KO') or nm.get('EN'), len(rs),
                     _sched(conn, pid, rs, dry)))
    return made


def plan_report(conn):
    rows = units(conn)
    bks = books_of(rows)
    exact = sum(1 for r in rows if r[6] == r[7])
    print('\n  마이어 편 %d · 성경 %d권' % (len(rows), len(bks)))
    print('  CORE = 인용한 그 절 %d편 · 그 장 전체 %d편 (절을 못 찾은 편)'
          % (exact, len(rows) - exact))
    print('\n  ── 가) 전권 통독 ──────────────────────────────────────')
    print('     plan %d  %-22s %5d일   스케줄 %d행'
          % (PLAN_ALL, NAME_ALL, len(rows), len(rows) * 2))
    print('\n  ── 나) 성경 66권 (묶음 「%s」) ─────────────' % NAME_BOOKS)
    for i, (bc, rs) in enumerate(bks):
        nm = _names(conn, bc)
        if i < 4 or i >= len(bks) - 2:
            print('     plan %3d  %-14s %4d일' % (PLAN_BOOK_FROM + i,
                                                 nm.get('KO', '?'), len(rs)))
        elif i == 4:
            print('     …  (가운데 %d권 줄임)' % (len(bks) - 6))
    print('\n  플랜 %d개 · 스케줄 %d행 · 제목 다국어 %d언어'
          % (1 + len(bks), (len(rows) * 2) * 2, len(_names(conn, 1))))
    print('  ⚠ meditation_focus 는 비운다 (스펄전 시편 150일과 같은 선례)\n')
    # 표본
    print('  1일차 표본:')
    for uid, seq, bc, ch, sv, ev, cs, ce in rows[:2]:
        lab = conn.execute("SELECT unit_label, key_verse_ref FROM sys_book_unit"
                           " WHERE unit_id=?", (uid,)).fetchone()
        print('     BOOK_TEXT %s · %s' % (lab[1], lab[0][:44]))
        print('     CORE      vid %d~%d %s'
              % (cs, ce, '(그 절)' if cs == ce else '(장 전체)'))


def _selftest():
    fails = []

    def ck(n, ok, got=''):
        print(('  OK  ' if ok else '  FAIL') + ' ' + n +
              ('  | ' + str(got) if got != '' else ''))
        if not ok:
            fails.append(n)

    conn = appdb.connect(DB)
    try:
        rows = units(conn)
        ck('마이어 1,189편을 읽는다', len(rows) == 1189, len(rows))
        ck('성경 66권으로 갈린다', len(books_of(rows)) == 66,
           len(books_of(rows)))
        ck('첫 편은 창세기 1장', rows[0][2] == 1 and rows[0][3] == 1)
        ck('끝 편은 계시록 22장', rows[-1][2] == 66 and rows[-1][3] == 22)
        ex = sum(1 for r in rows if r[6] == r[7])
        ck('CORE 가 인용 절인 편이 900 이상', ex >= 900, ex)
        ck('★ 절을 못 찾은 편은 그 장 전체 (짐작으로 안 찍는다)',
           all(r[6] == r[4] and r[7] == r[5] for r in rows if r[6] != r[7]))
        ck('CORE 는 늘 그 장 안에 있다',
           all(r[4] <= r[6] <= r[7] <= r[5] for r in rows))

        n0 = conn.execute("SELECT COUNT(*) FROM sys_plan_schedule").fetchone()[0]
        p0 = conn.execute("SELECT COUNT(*) FROM sys_bible_plan"
                          " WHERE COALESCE(record_status,'LIVE')='LIVE'"
                          ).fetchone()[0]
        conn.execute('BEGIN')
        made = apply(conn)
        ck('플랜 67개를 만든다 (전권 1 + 66권)', len(made) == 67, len(made))
        got = conn.execute(
            "SELECT COUNT(*) FROM sys_plan_schedule WHERE plan_id=?",
            (PLAN_ALL,)).fetchone()[0]
        ck('전권 통독 스케줄 2,378행', got == 2378, got)
        d = conn.execute("SELECT duration_days FROM sys_bible_plan"
                         " WHERE plan_id=?", (PLAN_ALL,)).fetchone()[0]
        ck('기간이 1,189일', d == 1189, d)
        r = conn.execute(
            "SELECT start_vid, end_vid, stage_type FROM sys_plan_schedule"
            " WHERE plan_id=? AND day=1 ORDER BY sort_order",
            (PLAN_ALL,)).fetchall()
        ck('★ 1일차 = CORE(구절) 먼저, BOOK_TEXT(도서) 뒤',
           [x[2] for x in r] == ['CORE', 'BOOK_TEXT'], [x[2] for x in r])
        ck('★ CORE 가 창 1:5 한 절', r[0][0] == r[0][1] and r[0][0] == 5,
           r[0][:2])
        ck('BOOK_TEXT 는 창 1장 전체', r[1][0] == 1 and r[1][1] == 31, r[1][:2])
        t = conn.execute("SELECT contents FROM sys_text_asset"
                         " WHERE text_type='PLAN_TITLE' AND clicked_id=?"
                         "   AND lang_code='KO'", (PLAN_BOOK_FROM,)).fetchone()
        ck('66권 첫 플랜 제목이 「창세기」', t and t[0] == '창세기', t)
        nf = conn.execute(
            "SELECT COUNT(*) FROM sys_plan_schedule WHERE plan_id=?"
            "  AND meditation_focus IS NOT NULL", (PLAN_ALL,)).fetchone()[0]
        ck('meditation_focus 는 비어 있다 (지어내지 않는다)', nf == 0, nf)
        made2 = apply(conn)                      # 멱등
        got2 = conn.execute(
            "SELECT COUNT(*) FROM sys_plan_schedule WHERE plan_id=?",
            (PLAN_ALL,)).fetchone()[0]
        ck('★ 두 번 돌려도 행이 안 는다 (멱등)', got2 == got and
           len(made2) == 67, '%d → %d' % (got, got2))
        conn.rollback()
        n1 = conn.execute("SELECT COUNT(*) FROM sys_plan_schedule").fetchone()[0]
        p1 = conn.execute("SELECT COUNT(*) FROM sys_bible_plan"
                          " WHERE COALESCE(record_status,'LIVE')='LIVE'"
                          ).fetchone()[0]
        ck('되돌리면 흔적이 없다', n1 == n0 and p1 == p0,
           '스케줄 %d→%d · 플랜 %d→%d' % (n0, n1, p0, p1))
    finally:
        conn.close()
    print('\n=== %s (%d fail) ===' %
          ('PASS' if not fails else 'FAIL: ' + ', '.join(fails), len(fails)))
    return 1 if fails else 0


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(_selftest())
    conn = appdb.connect(DB)
    try:
        if '--apply' in a:
            made = apply(conn)
            conn.commit()
            print('플랜 %d개 · 스케줄 %d행'
                  % (len(made), sum(m[3] for m in made)))
        else:
            plan_report(conn)
    finally:
        conn.close()


if __name__ == '__main__':
    main()
