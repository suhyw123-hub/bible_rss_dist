# -*- coding: utf-8 -*-
"""Q&A 유사 질문 찾기 — **에이전트(Claude Code)에게 주는 읽기 전용 도구** (2026-10-08 · docs/1.txt 57).

  python qa_search_tool.py search 낱말 [낱말 …]   지난 문의에서 찾기(한국어 번역·원문·답 · 낱말 하나라도)
  python qa_search_tool.py get 문의번호            그 문의 전문(질문·한국어 번역·답·날짜·언어)
  python qa_search_tool.py faq_search 낱말 …      FAQ(한국어)에서 찾기
  python qa_search_tool.py faq_get FAQ번호         FAQ 전문
  python qa_search_tool.py list [개수]             최근 문의 요지(훑기용 · 기본 40)
  python qa_search_tool.py --selftest

★ **읽기만 한다** — DB 를 `mode=ro` 로 연다. 쓰는 문이 이 파일에 없다.
★ 이메일·전화번호를 가려서 내놓는다(`qa_ai.scrub`) — 에이전트에게 가는 글이 곧 밖으로 나가는 글이다.
★ 찾을 문의 DB = 환경 변수 `QA_DB`(시험용) · 없으면 `admin_comm.db`.
   FAQ DB = 환경 변수 `QA_FAQ_DB` · 없으면 `bible_master.db`.
"""
import os
import sqlite3
import sys

APP = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP)
import qa_ai  # noqa: E402

LIMIT = 15


def _ro(path):
    return sqlite3.connect('file:%s?mode=ro' % path.replace('\\', '/'), uri=True)


def _qa_db():
    return os.environ.get('QA_DB') or os.path.join(APP, 'admin_comm.db')


def _faq_db():
    return os.environ.get('QA_FAQ_DB') or os.path.join(APP, 'bible_master.db')


def _has(c, tbl):
    return bool(c.execute("SELECT 1 FROM sqlite_master WHERE name=?", (tbl,)).fetchone())


def _qa_rows(c, where='1=1', args=()):
    ai = _has(c, 'qa_ai')
    sql = ('SELECT q.msg_id, q.ts, q.lang, q.question, q.reply, %s FROM qa q %s WHERE %s'
           % ('a.q_ko, a.summary' if ai else "'', ''",
              'LEFT JOIN qa_ai a ON a.msg_id=q.msg_id' if ai else '', where))
    return c.execute(sql + ' ORDER BY q.ts DESC', args).fetchall()


def _short(s, n=160):
    s = ' '.join((s or '').split())
    return s if len(s) <= n else s[:n] + '…'


def search(words, exclude=''):
    words = [w for w in words if w.strip()]
    if not words:
        return '검색어가 없습니다.'
    c = _ro(_qa_db())
    try:
        out = []
        for mid, ts, lang, q, rep, qko, summ in _qa_rows(c):
            if mid == exclude:
                continue
            hay = ' '.join(x or '' for x in (q, qko, rep, summ)).lower()
            hit = [w for w in words if w.lower() in hay]
            if hit:
                out.append((len(hit), mid, ts, lang, qko or q, bool(rep), hit))
        out.sort(key=lambda x: (-x[0], x[2] or ''), reverse=False)
        if not out:
            return '찾은 문의 없음 (검색어: %s)' % ', '.join(words)
        lines = ['찾은 문의 %d건 (많이 맞은 순 · 최대 %d):' % (len(out), LIMIT)]
        for n, mid, ts, lang, q, answered, hit in out[:LIMIT]:
            lines.append('- %s · %s · %s · %s · 맞은 낱말 %s · %s'
                         % (mid, (ts or '')[:10], lang, '답 있음' if answered else '답 없음',
                            '/'.join(hit), qa_ai.scrub(_short(q))))
        return '\n'.join(lines)
    finally:
        c.close()


def get(mid):
    c = _ro(_qa_db())
    try:
        r = _qa_rows(c, 'q.msg_id=?', (mid,))
        if not r:
            return '문의 %s 없음' % mid
        mid, ts, lang, q, rep, qko, summ = r[0]
        return '\n'.join(['[문의 %s] %s · 언어 %s' % (mid, ts or '', lang),
                          '[원문] ' + qa_ai.scrub(q or ''),
                          '[한국어 번역] ' + qa_ai.scrub(qko or ('(원문이 한국어)' if (lang or '').upper() == 'KO' else '(아직 없음)')),
                          '[답] ' + qa_ai.scrub(rep or '(아직 답 없음)')])
    finally:
        c.close()


def _faq(c):
    if not _has(c, 'sys_faq_text'):
        return []
    return c.execute("SELECT t.faq_id, t.question, t.answer FROM sys_faq_text t"
                     " WHERE t.lang_code='KO' AND COALESCE(t.record_status,'LIVE')='LIVE'"
                     " ORDER BY t.faq_id").fetchall()


def faq_search(words):
    words = [w for w in words if w.strip()]
    c = _ro(_faq_db())
    try:
        out = []
        for fid, q, a in _faq(c):
            hay = ((q or '') + ' ' + (a or '')).lower()
            hit = [w for w in words if w.lower() in hay]
            if hit:
                out.append((len(hit), fid, q, hit))
        out.sort(key=lambda x: -x[0])
        if not out:
            return '찾은 FAQ 없음 (검색어: %s)' % ', '.join(words)
        return '\n'.join(['찾은 FAQ %d건:' % len(out)] +
                         ['- FAQ %s · 맞은 낱말 %s · %s' % (fid, '/'.join(h), _short(q))
                          for _n, fid, q, h in out[:LIMIT]])
    finally:
        c.close()


def faq_get(fid):
    c = _ro(_faq_db())
    try:
        for f, q, a in _faq(c):
            if str(f) == str(fid):
                return '[FAQ %s]\n[물음] %s\n[답] %s' % (f, q or '', a or '')
        return 'FAQ %s 없음' % fid
    finally:
        c.close()


def list_recent(n=40):
    c = _ro(_qa_db())
    try:
        rows = _qa_rows(c)[:max(1, min(int(n), 200))]
        return '\n'.join(['최근 문의 %d건:' % len(rows)] +
                         ['- %s · %s · %s · %s' % (mid, (ts or '')[:10], lang,
                                                   qa_ai.scrub(_short(summ or qko or q, 100)))
                          for mid, ts, lang, q, rep, qko, summ in rows])
    finally:
        c.close()


def main(argv):
    if not argv or argv[0] in ('-h', '--help'):
        print(__doc__)
        return 0
    cmd, rest = argv[0], argv[1:]
    try:
        if cmd == 'search':
            ex = os.environ.get('QA_EXCLUDE', '')
            print(search(rest, exclude=ex))
        elif cmd == 'get' and rest:
            print(get(rest[0]))
        elif cmd == 'faq_search':
            print(faq_search(rest))
        elif cmd == 'faq_get' and rest:
            print(faq_get(rest[0]))
        elif cmd == 'list':
            print(list_recent(rest[0] if rest else 40))
        elif cmd == '--selftest':
            return 0 if selftest() else 1
        else:
            print('모르는 명령: %s (search · get · faq_search · faq_get · list)' % cmd)
            return 2
    except sqlite3.OperationalError as e:
        print('DB 를 읽지 못했습니다: %s' % e)
        return 1
    return 0


def selftest():
    import tempfile
    n = [0, 0]

    def ck(cond, m):
        n[0] += 1
        n[1] += bool(cond)
        if not cond:
            print('  FAIL', m)
    d = tempfile.mkdtemp()
    p = os.path.join(d, 'q.db')
    c = qa_ai.conn(p)
    c.executemany('INSERT INTO qa(msg_id,lang,question,reply,ts) VALUES(?,?,?,?,?)', [
        ('a1', 'KO', '휴대폰을 PC 와 연결하는 방법? 연락 a@b.com', '설정 ▸ 모바일 연결', '2026-10-01'),
        ('a2', 'PT', 'Como mudo o tamanho da letra?', '', '2026-10-02')])
    c.execute("INSERT INTO qa_ai(msg_id,q_ko,summary) VALUES('a2','글자 크기를 어떻게 바꾸나요?','글꼴 크기')")
    c.commit()
    c.close()
    os.environ['QA_DB'] = p
    os.environ['QA_FAQ_DB'] = p
    s = search(['휴대폰', '연결'])
    ck('a1' in s and 'a@b.com' not in s, '찾기 · 이메일 가림')
    ck('a2' in search(['글자']), '한국어 번역에서도 찾는다')
    ck('a1' not in search(['연결'], exclude='a1'), '새 문의 자신은 뺀다')
    g = get('a2')
    ck('Como mudo' in g and '글자 크기' in g, '전문 = 원문 + 한국어 번역')
    ck('없음' in get('zz'), '없는 번호')
    ck('a1' in list_recent(5), '최근 목록')
    ck('없음' in faq_search(['x']), 'FAQ 표가 없어도 견딘다')
    ro = _ro(p)
    try:
        ro.execute("INSERT INTO qa(msg_id) VALUES('x')")
        ck(False, '읽기 전용')
    except sqlite3.OperationalError:
        ck(True, '읽기 전용 — 쓰기가 막힌다')
    ro.close()
    print('qa_search_tool selftest %d/%d' % (n[1], n[0]))
    return n[0] == n[1]


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
