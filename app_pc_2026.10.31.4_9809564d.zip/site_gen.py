"""
site_gen.py — 하가 홈페이지(정적) 생성기 · GitHub Pages 로 보낸다 (2026-10-12 신설·영구).

사용자 확정(2026-10-12):
  · 콘텐츠는 앱(모바일·PC)에 풍성하다 — 홈페이지는 「모양을 갖추고 앱으로 안내」하는 곳이다.
  · ★ 쇼핑 기능은 사용자가 많아진 뒤에 켠다(아마존 180일·3건 같은 탈락 요건) —
    **상품을 등록하지 않으면 쇼핑 메뉴·고지는 아예 안 나온다**(`products(lang)` 가 0 이면).
  · 디자인 = A「말씀 종이」(기본) + 왼쪽 위 다크모드 단추 · 오른쪽 위 언어 선택기.
  · 「이런 일을 합니다」 = 설명 + 그 화면(모바일·PC)을 한 세트로 · 화면 미리보기는 모바일/PC 갈래.
  · 폰과 PC 동기화 — 이동 중 짧은 묵상, 집에서 PC 로 깊은 묵상을 강조.
  · 자유게시판 없음 · 문의 폼 하나(나중에 앱 1:1 문의와 같은 통로로 · 지금은 보내지 않는다).
  · 다국어 = 앱과 같은 체계 — 화면 글자는 `ui_strings` 의 `WEB_*` 열쇠(KO 는 아래 표가 씨앗).
    그 언어로 **열쇠가 다 옮겨진 언어만** 만든다(반쯤 한국어인 쪽을 내지 않는다).
  · 서버 = GitHub 무료 주소(`suhyw123-hub.github.io`) · 도메인은 나중에 CNAME 한 줄.

원칙: 추적 0 — 분석 도구·외부 글꼴·외부 그림·외부 스크립트 없음.
  자바스크립트는 **다크모드 기억 한 줄**뿐(이 기기의 브라우저에만 적는다 · 밖으로 안 나간다).

명령:
  --selftest            자가 검증
  --seed-i18n           WEB_* 의 KO 값을 ui_strings 에 넣는다(없는 것만 · 번역 도구가 그것을 옮긴다)
  --build               _site_dist/ 에 만든다
  --publish             만든 것을 GitHub Pages 저장소에 올린다(바뀐 것만 커밋)
"""
import html
import os
import shutil
import subprocess
import sys

import appdb

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, '_site_dist')
ASSETS = os.path.join(HERE, 'site_assets')
REPO_URL = 'https://github.com/suhyw123-hub/suhyw123-hub.github.io.git'
SITE_URL = 'https://suhyw123-hub.github.io/'
WORK = os.path.join(HERE, '_site_repo')
HOME_LANG = 'KO'            # 첫 화면(/) 의 언어 · 다른 언어는 /en/ 처럼 제 폴더

# ── 화면 글자 — KO 씨앗(열쇠는 ui_strings WEB_*) ─────────────────────────
KO = {
    'WEB_APP_NAME': '하가 다바르',
    'WEB_APP_SUB': '성경 묵상과 연구',
    'WEB_NAV_NAME': '이름 이야기', 'WEB_NAV_SYNC': '폰과 PC', 'WEB_NAV_FEAT': '기능',
    'WEB_NAV_SHOT': '화면', 'WEB_NAV_GET': '앱 받기', 'WEB_NAV_ASK': '문의',
    'WEB_DARK': '어두운 화면', 'WEB_LANG': '언어',
    'WEB_HERO_T': '말씀을 읽고, 묵상하고, 이어 보다',
    'WEB_HERO_D': '하가 다바르는 성경 본문과 구절 해설, 묵상플랜, 연결된 구절과 원어, 도서·설교집을 '
                  '한 자리에서 읽는 개신교 성경 묵상 앱입니다. 폰에서도 PC에서도 같은 말씀을 이어서 읽습니다.',
    'WEB_HERO_BTN': '앱 받기',
    'WEB_VERSE_T': '오늘 마음에 둘 말씀',
    'WEB_NAME_T': '「하가 다바르」라는 이름',
    'WEB_NAME_P1': '하가는 히브리어로 「소리 내어 되뇌다, 나직이 읊조리다」라는 뜻입니다. 시편 1편의 '
                   '「그 율법을 주야로 묵상하는도다」에서 「묵상하다」가 바로 이 낱말입니다. 같은 낱말이 사자가 먹이를 '
                   '움키고 낮게 으르렁거리는 소리(사 31:4)와 비둘기가 구구 우는 소리(사 38:14)에도 쓰였습니다.',
    'WEB_NAME_P2': '성경이 말하는 묵상은 머릿속 생각에 그치지 않습니다. 말씀을 입에 올려 거듭 되뇌며 마음에 새기는 일입니다.',
    'WEB_NAME_P3': '다바르는 「말씀」입니다. 하나님께서 하신 말이면서 그 말씀이 이루는 일까지 함께 뜻하는 낱말입니다.',
    'WEB_NAME_P4': '그래서 하가 다바르는 「말씀을 되뇌다」입니다. 바쁜 하루 중에도 말씀 한 구절을 입에 올리고, '
                   '시간이 날 때는 그 말씀을 깊이 파고들 수 있도록 이 앱을 만들었습니다.',
    'WEB_STAT_DESC': '구절 해설', 'WEB_STAT_PLAN': '묵상플랜', 'WEB_STAT_LENS': '렌즈 묵상',
    'WEB_STAT_BOOK': '고전 도서·설교집', 'WEB_STAT_VER': '성경 역본',
    'WEB_SYNC_T': '폰과 PC, 하나의 묵상',
    'WEB_SYNC_D': '두 앱은 따로 놀지 않습니다. 이동 중에 폰으로 시작한 묵상을 집에서 PC로 깊이 이어 갑니다.',
    'WEB_SYNC_M_T': '이동 중에는 폰으로',
    'WEB_SYNC_M_D': '출근길과 쉬는 시간에 오늘의 말씀과 묵상플랜 한 몫을 읽고, 떠오른 생각을 짧은 묵상노트로 남깁니다. '
                    '설교·기도·찬양 영상도 멈춘 곳에서 다시 이어 듣습니다.',
    'WEB_SYNC_P_T': '집에서는 PC로 깊이',
    'WEB_SYNC_P_D': '넓은 화면에서 구절 연결과 말씀의 흐름, 주석과 원어, 고전 도서를 나란히 펼쳐 놓고 폰에서 남긴 노트를 '
                    '다듬어 연구노트로 키웁니다.',
    'WEB_SYNC_L_T': '같은 와이파이에서 서로 이어집니다',
    'WEB_SYNC_L_D': '폰에서 쓴 노트와 즐겨찾기, 플랜 진행이 PC로 오고 PC에서 정리한 자료가 폰으로 갑니다. '
                    '집의 와이파이 안에서 두 기기가 직접 주고받을 뿐 인터넷 서버에 올리지 않습니다.',
    'WEB_FEAT_T': '이런 일을 합니다',
    'WEB_F1_T': '구절마다 쉬운 해설', 'WEB_F1_D': '구절을 누르면 해설과 묵상질문, 묵상기도가 열립니다. 장과 단락의 흐름도 같은 자리에서 봅니다.',
    'WEB_F2_T': '뜻으로 이어진 구절', 'WEB_F2_D': '한 구절이 성경 전체의 어느 구절과 이어지는지, 왜 이어지는지를 설명과 함께 보여 줍니다. 말씀의 흐름을 따라 창세기에서 요한계시록까지 걸어 봅니다.',
    'WEB_F3_T': '주석과 원어', 'WEB_F3_D': '여러 고전 주석을 오늘의 말로 옮겨 읽고, 히브리어·헬라어 낱말이 성경 어디에 다시 나오는지 찾아갑니다.',
    'WEB_F4_T': '묵상플랜과 렌즈 묵상', 'WEB_F4_D': '통독부터 주제 묵상까지 하루 몫을 정해 주고, 한 주제를 여러 각도에서 비추어 읽게 합니다.',
    'WEB_F5_T': '고전 도서와 설교집', 'WEB_F5_D': '스펄전, 머레이, 바운즈 같은 신앙 고전을 오늘의 말로 옮겨 읽습니다.',
    'WEB_F6_T': '설교·기도·찬양 영상', 'WEB_F6_D': '구절과 이어진 설교와 기도, 찬양을 언어별로 선택해 듣고 멈춘 곳에서 다시 이어 듣습니다.',
    'WEB_F7_T': 'AI 도우미', 'WEB_F7_D': '내가 선택한 AI 에게 구절을 묻고, 여러 답을 한 글로 정리해 내 연구노트로 남깁니다.',
    'WEB_MOBILE': '모바일', 'WEB_PC': 'PC',
    'WEB_SHOT_T': '화면 미리보기',
    'WEB_GET_T': '앱 받기',
    'WEB_GET_ANDROID': '안드로이드', 'WEB_GET_IOS': '아이폰', 'WEB_GET_PC': 'Windows PC',
    'WEB_GET_SOON': '준비 중', 'WEB_GET_NOTE': '출시되면 이 자리에서 받으실 수 있습니다.',
    'WEB_ASK_T': '문의하기',
    'WEB_ASK_D': '앱 사용 중 궁금한 점이나 고칠 점을 보내 주세요. 답장은 적어 주신 메일로 드립니다.',
    'WEB_ASK_MAIL': '답장 받을 메일', 'WEB_ASK_BODY': '문의 내용', 'WEB_ASK_SEND': '보내기',
    'WEB_ASK_PREVIEW': '문의 접수는 곧 열립니다. 지금은 보내지지 않습니다.',
    'WEB_PRIV_T': '개인정보',
    'WEB_PRIV_D': '이 홈페이지와 앱은 방문 기록을 모으지 않습니다. 분석 도구, 광고 추적, 외부 글꼴을 쓰지 않습니다. '
                  '문의를 보내실 때 적으신 메일과 내용만 답장을 위해 보관합니다.',
    'WEB_FOOT': '하가 다바르 · 성경 본문의 저작권은 각 역본의 권리자에게 있습니다.',
}
KEYS = tuple(KO)

# 기능 세트 = (번호, 모바일 그림, PC 그림) — 없는 쪽은 None
FEATS = [(1, '04_sheet_desc.png', 'pc_desc.png'), (2, '05_sheet_links.png', 'pc_flow.png'),
         (3, '06e_sheet_lex.png', 'pc_comm.png'), (4, '13_plan_today_card.png', None),
         (5, '17_reader.png', 'pc_reading.png'), (6, '25_youtube.png', None),
         (7, '22c_ai_final.png', 'pc_ai.png')]
GALLERY_M = ['01_home.png', '04_sheet_desc.png', '05_sheet_links.png', '06e_sheet_lex.png',
             '14_lens_page.png', '17_reader.png', '25c_youtube_prayer.png', '22c_ai_final.png']
GALLERY_PC = ['pc_desc.png', 'pc_flow.png', 'pc_comm.png', 'pc_reading.png', 'pc_ai.png']


def _ui(conn, lang, key):
    try:
        r = conn.execute('SELECT string_value FROM ui_strings WHERE string_id=? AND lang_code=?', (key, lang)).fetchone()
        return (r[0] or '').strip() if r else ''
    except Exception:                                        # noqa: BLE001
        return ''


def t(conn, lang, key):
    """그 언어 → KO(DB) → KO(씨앗) → 열쇠."""
    if conn is not None:
        v = _ui(conn, lang, key) or _ui(conn, 'KO', key)
        if v:
            return v
    return KO.get(key, key)


def ready_langs(conn):
    """만들 언어 — KO 와, WEB_* 열쇠가 **다 옮겨진** 언어."""
    import lang_config
    out = []
    for lg in lang_config.ui_langs():
        if lg == 'KO' or all(_ui(conn, lg, k) for k in KEYS):
            out.append(lg)
    return out


def seed_ko(conn):
    n = 0
    for k, v in KO.items():
        if not _ui(conn, 'KO', k):
            conn.execute('INSERT INTO ui_strings(string_id, lang_code, string_value) VALUES(?,?,?)', (k, 'KO', v))
            n += 1
    conn.commit()
    return n


def products(conn, lang):
    """홈페이지에 실을 상품 — ★ 지금은 상품 표가 없다 → 늘 0 → 쇼핑 메뉴·고지를 안 그린다."""
    return []


def stats(conn):
    q = lambda s: (conn.execute(s).fetchone() or [0])[0]   # noqa: E731
    return {
        'desc': q("SELECT COUNT(DISTINCT clicked_id) FROM sys_text_asset WHERE text_type='VERS_DESC' AND lang_code='KO'"),
        'plan': q("SELECT COUNT(*) FROM sys_bible_plan WHERE COALESCE(record_status,'LIVE')='LIVE'"),
        'lens': q("SELECT COUNT(*) FROM sys_unit_asset WHERE unit_type='CONTAINER' AND COALESCE(record_status,'LIVE')='LIVE'"),
        'book': q("SELECT COUNT(*) FROM sys_book_asset WHERE COALESCE(record_status,'LIVE')='LIVE'"),
        'ver': q('SELECT COUNT(*) FROM bible_version'),
    }


def verse(conn, lang):
    """대표 말씀 — 시 119:105 · 그 언어 기준 역본(없으면 BSB) · 책 이름은 그 언어."""
    try:
        import db_cite_gate
        ver = db_cite_gate.VERSION_OF.get(lang)
    except Exception:                                        # noqa: BLE001
        ver = None
    vid = conn.execute('SELECT verse_id FROM bible_index WHERE bcode=19 AND chapter=119 AND verse=105').fetchone()
    if not vid:
        return '', ''
    txt = ''
    for v in [x for x in (ver, 'BSB') if x]:
        r = conn.execute('SELECT verse_text FROM bible_content WHERE verse_id=? AND version_code=?', (vid[0], v)).fetchone()
        if r and (r[0] or '').strip():
            txt = r[0].strip()
            break
    nm = conn.execute("SELECT full_name FROM book_names WHERE book_code=19 AND lang_code=?", (lang,)).fetchone() \
        or conn.execute("SELECT full_name FROM book_names WHERE book_code=19 AND lang_code='EN'").fetchone()
    return txt, '%s 119:105' % (nm[0] if nm else 'Psalm')


def lang_self(lg):
    try:
        import lang_config
        return lang_config.lang_name(lg) or lg
    except Exception:                                        # noqa: BLE001
        return lg


def lang_dir(lg):
    return '' if lg == HOME_LANG else lg.lower() + '/'


# ── 디자인 A「말씀 종이」 + 어두운 짝 ────────────────────────────────────
CSS = """
:root{--bg:#f6f1e7;--panel:#fffdf8;--ink:#2b2a27;--dim:#6b665c;--accent:#7a4e2d;--line:#e2d8c6;--hero:#efe5d3;--frame:#3a3530}
:root[data-theme=dark]{--bg:#1b1916;--panel:#25221e;--ink:#ece6d9;--dim:#b4ab99;--accent:#d8a874;--line:#3a352e;--hero:#221f1b;--frame:#0e0d0c}
*{box-sizing:border-box}html{scroll-behavior:smooth}
body{margin:0;background:var(--bg);color:var(--ink);line-height:1.8;font-size:17px;word-break:keep-all;
font-family:"Noto Serif KR","Batang","바탕","Noto Serif",Georgia,serif;transition:background .2s,color .2s}
a{color:var(--accent)}.wrap{max-width:1100px;margin:0 auto;padding:0 20px}
header{position:sticky;top:0;background:var(--bg);border-bottom:1px solid var(--line);z-index:5}
header .wrap{display:flex;align-items:center;gap:12px;height:62px}
.mode{background:none;border:1px solid var(--line);color:var(--ink);border-radius:50%;width:34px;height:34px;cursor:pointer;font-size:16px;line-height:1}
header img{width:30px;height:30px;border-radius:7px}.brand{font-weight:700;font-size:19px;color:var(--ink);text-decoration:none;white-space:nowrap}
nav{margin-left:auto;display:flex;gap:16px;flex-wrap:wrap}nav a{color:var(--dim);text-decoration:none;font-size:15px}nav a:hover{color:var(--accent)}
.lang{position:relative;font-size:15px}.lang summary{cursor:pointer;list-style:none;border:1px solid var(--line);padding:4px 12px;border-radius:4px;color:var(--ink)}
.lang summary::-webkit-details-marker{display:none}
.lang ul{position:absolute;right:0;top:36px;margin:0;padding:6px 0;list-style:none;background:var(--panel);border:1px solid var(--line);min-width:150px;box-shadow:0 6px 18px rgba(0,0,0,.12)}
.lang li a{display:block;padding:6px 16px;color:var(--ink);text-decoration:none}.lang li a:hover,.lang li a.on{color:var(--accent)}
.hero{background:var(--hero);padding:76px 0 64px;text-align:center}.hero .wrap{max-width:780px}
.hero h1{font-size:40px;line-height:1.35;margin:0 0 18px;letter-spacing:-.01em}.hero p{color:var(--dim);font-size:18px;margin:0 0 28px}
.btn{display:inline-block;background:var(--accent);color:#fff;padding:12px 30px;text-decoration:none;font-weight:700;border-radius:2px;border:0;font:inherit}
:root[data-theme=dark] .btn{color:#1b1916}
.verse{margin:38px auto 0;max-width:640px;padding:22px 26px;background:var(--panel);border-left:4px solid var(--accent);text-align:left}
.verse b{display:block;font-size:13px;color:var(--dim);font-weight:600;margin-bottom:6px}.verse q{font-size:19px}
.verse cite{display:block;margin-top:8px;color:var(--dim);font-style:normal;font-size:14px}
section{padding:68px 0}section h2{font-size:28px;margin:0 0 14px;text-align:center}.lead{color:var(--dim);text-align:center;max-width:720px;margin:0 auto 34px}
.name{max-width:760px;margin:auto}.name .heb{text-align:center;font-size:30px;color:var(--accent);margin:0 0 18px;direction:rtl;font-family:"SBL Hebrew","Ezra SIL","Times New Roman",serif}
.name p{margin:0 0 14px}
.stats{display:grid;grid-template-columns:repeat(5,1fr);gap:14px}
.stat{text-align:center;padding:18px 8px;background:var(--panel);border:1px solid var(--line);border-radius:4px}
.stat b{display:block;font-size:26px;color:var(--accent)}.stat span{color:var(--dim);font-size:14px}
.sync{display:grid;grid-template-columns:1fr 1fr;gap:22px}.sync .card{padding:26px}
.sync .link{grid-column:1/3;text-align:center;border-style:dashed}
.card{background:var(--panel);border:1px solid var(--line);border-radius:4px;padding:24px}.card h3{margin:0 0 8px;font-size:20px}.card p{margin:0;color:var(--dim)}
.set{display:grid;grid-template-columns:250px 200px 1fr;gap:30px;align-items:center;padding:34px 0;border-top:1px solid var(--line)}
.set h3{font-size:23px;margin:0 0 10px}.set p{color:var(--dim);margin:0}.set .nopc{grid-column:3}
.set figure{margin:0;text-align:center}.set figcaption{color:var(--dim);font-size:13px;margin-top:6px}
.shots figure{margin:0;text-align:center}.shots figcaption{color:var(--dim);font-size:13px;margin-top:6px}
img.m{width:200px;border-radius:18px;border:6px solid var(--frame);display:block}
img.p{width:100%;max-width:560px;border-radius:6px;border:1px solid var(--line);display:block;box-shadow:0 4px 14px rgba(0,0,0,.08)}
.gal input{display:none}.tabs{text-align:center;margin-bottom:22px}
.tabs label{display:inline-block;padding:7px 26px;border:1px solid var(--line);cursor:pointer;color:var(--dim);margin:0 -1px}
#gm:checked~.tabs label[for=gm],#gp:checked~.tabs label[for=gp]{background:var(--accent);color:#fff;border-color:var(--accent)}
.strip{display:none;gap:18px;overflow-x:auto;padding-bottom:12px}
#gm:checked~.sm,#gp:checked~.sp{display:flex}.strip figure{margin:0;flex:0 0 auto}.sp img.p{width:620px;max-width:none}
.get{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;text-align:center}.get b{display:block;font-size:20px}.soon{color:var(--dim)}
form{max-width:620px;margin:auto;display:grid;gap:14px}label.f{font-size:14px;color:var(--dim)}
input.f,textarea{width:100%;padding:12px;font:inherit;color:var(--ink);background:var(--panel);border:1px solid var(--line);border-radius:4px}textarea{min-height:140px}
.hp{position:absolute;left:-9999px}.note{color:var(--dim);font-size:14px;text-align:center}
footer{border-top:1px solid var(--line);padding:34px 0;color:var(--dim);font-size:14px}footer h3{color:var(--ink);font-size:15px;margin:0 0 6px}
@media(max-width:860px){nav{display:none}.hero h1{font-size:30px}.stats{grid-template-columns:repeat(2,1fr)}
.sync,.get{grid-template-columns:1fr}.sync .link{grid-column:auto}
.set{grid-template-columns:1fr}.set figure{justify-self:center}img.m{width:170px}}
"""

THEME_JS = ("(function(){var k='hagah_theme',t;try{t=localStorage.getItem(k)}catch(e){}"
            "if(!t)t=(window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches)?'dark':'light';"
            "document.documentElement.setAttribute('data-theme',t);})();")
TOGGLE_JS = ("var r=document.documentElement,t=r.getAttribute('data-theme')=='dark'?'light':'dark';"
             "r.setAttribute('data-theme',t);try{localStorage.setItem('hagah_theme',t)}catch(e){}")


def _e(s):
    return html.escape(s or '', quote=True)


def page(conn, lang, langs):
    T = lambda k: _e(t(conn, lang, k))                       # noqa: E731
    up = '' if lang == HOME_LANG else '../'
    a = up + 'a/'
    st = stats(conn)
    vt, vref = verse(conn, lang)

    def mimg(f, cap=''):
        return '<figure><img class="m" src="%sm/%s" alt="%s" loading="lazy"><figcaption>%s</figcaption></figure>' % (a, f, cap, cap)

    def pimg(f, cap=''):
        return '<figure><img class="p" src="%spc/%s" alt="%s" loading="lazy"><figcaption>%s</figcaption></figure>' % (a, f, cap, cap)

    sets = ''
    for i, mf, pf in FEATS:
        media = (mimg(mf, T('WEB_MOBILE')) if mf else '<div></div>') + (pimg(pf, T('WEB_PC')) if pf else '')
        sets += ('<div class="set"><div class="txt"><h3>%s</h3><p>%s</p></div>%s</div>'
                 % (T('WEB_F%d_T' % i), T('WEB_F%d_D' % i), media))
    stat_html = ''.join('<div class="stat"><b>%s</b><span>%s</span></div>' % ('{:,}'.format(st[k]), T(lbl))
                        for k, lbl in (('desc', 'WEB_STAT_DESC'), ('plan', 'WEB_STAT_PLAN'),
                                       ('lens', 'WEB_STAT_LENS'), ('book', 'WEB_STAT_BOOK'), ('ver', 'WEB_STAT_VER')))
    get = ''.join('<div class="card"><b>%s</b><span class="soon">%s</span></div>' % (T(k), T('WEB_GET_SOON'))
                  for k in ('WEB_GET_ANDROID', 'WEB_GET_IOS', 'WEB_GET_PC'))
    gal_m = ''.join(mimg(f) for f in GALLERY_M)
    gal_p = ''.join(pimg(f) for f in GALLERY_PC)
    lang_ul = ''.join('<li><a href="%s%s"%s>%s</a></li>' % (up, lang_dir(lg), ' class="on"' if lg == lang else '',
                                                            _e(lang_self(lg))) for lg in langs)
    shop_nav = ''   # ★ 상품이 없으면 쇼핑 메뉴·고지를 안 그린다(products(lang) 가 0)
    # ★ 2026-10-15 잡지 「이렇게 읽습니다」 — 그 언어 글 파일이 있을 때만 메뉴에 단다(site_magazine)
    try:
        import site_magazine as MAG
        _mc = MAG.copy_of(lang)
    except Exception:                                     # noqa: BLE001
        _mc = None
    shop_nav += ('<a href="%s">%s</a>' % (MAG.PAGE, _e(_mc['title']))) if _mc else ''
    rtl = ' dir="rtl"' if lang in ('AR', 'HE') else ''
    return f"""<!doctype html>
<html lang="{lang.lower()}"{rtl}><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex">
<title>{T('WEB_APP_NAME')} · {T('WEB_APP_SUB')}</title>
<meta name="description" content="{T('WEB_HERO_D')}">
<link rel="icon" href="{a}icon.png">
<script>{THEME_JS}</script>
<style>{CSS}</style></head><body>
<header><div class="wrap"><button class="mode" type="button" title="{T('WEB_DARK')}" aria-label="{T('WEB_DARK')}" onclick="{TOGGLE_JS}">&#9680;</button>
<img src="{a}icon.png" alt=""><a class="brand" href="#top">{T('WEB_APP_NAME')}</a>
<nav><a href="#name">{T('WEB_NAV_NAME')}</a><a href="#sync">{T('WEB_NAV_SYNC')}</a><a href="#feat">{T('WEB_NAV_FEAT')}</a><a href="#shots">{T('WEB_NAV_SHOT')}</a><a href="#get">{T('WEB_NAV_GET')}</a><a href="#ask">{T('WEB_NAV_ASK')}</a>{shop_nav}</nav>
<details class="lang"><summary>{_e(lang_self(lang))} &#9662;</summary><ul>{lang_ul}</ul></details></div></header>
<div class="hero" id="top"><div class="wrap"><h1>{T('WEB_HERO_T')}</h1><p>{T('WEB_HERO_D')}</p>
<a class="btn" href="#get">{T('WEB_HERO_BTN')}</a>
<div class="verse"><b>{T('WEB_VERSE_T')}</b><q>{_e(vt)}</q><cite>{_e(vref)}</cite></div></div></div>
<section id="name"><div class="wrap name"><h2>{T('WEB_NAME_T')}</h2><p class="heb">&#1492;&#1464;&#1490;&#1464;&#1492; &#183; &#1491;&#1468;&#1464;&#1489;&#1464;&#1512;</p>
<p>{T('WEB_NAME_P1')}</p><p>{T('WEB_NAME_P2')}</p><p>{T('WEB_NAME_P3')}</p><p>{T('WEB_NAME_P4')}</p></div></section>
<section style="padding-top:0"><div class="wrap"><div class="stats">{stat_html}</div></div></section>
<section id="sync"><div class="wrap"><h2>{T('WEB_SYNC_T')}</h2><p class="lead">{T('WEB_SYNC_D')}</p>
<div class="sync"><div class="card"><h3>{T('WEB_SYNC_M_T')}</h3><p>{T('WEB_SYNC_M_D')}</p></div>
<div class="card"><h3>{T('WEB_SYNC_P_T')}</h3><p>{T('WEB_SYNC_P_D')}</p></div>
<div class="card link"><h3>&#8644; {T('WEB_SYNC_L_T')}</h3><p>{T('WEB_SYNC_L_D')}</p></div></div></div></section>
<section id="feat"><div class="wrap"><h2>{T('WEB_FEAT_T')}</h2>{sets}</div></section>
<section id="shots"><div class="wrap gal"><h2>{T('WEB_SHOT_T')}</h2>
<input type="radio" name="g" id="gm" checked><input type="radio" name="g" id="gp">
<div class="tabs"><label for="gm">{T('WEB_MOBILE')}</label><label for="gp">{T('WEB_PC')}</label></div>
<div class="strip sm">{gal_m}</div><div class="strip sp">{gal_p}</div></div></section>
<section id="get"><div class="wrap"><h2>{T('WEB_GET_T')}</h2><div class="get">{get}</div><p class="note">{T('WEB_GET_NOTE')}</p></div></section>
<section id="ask"><div class="wrap"><h2>{T('WEB_ASK_T')}</h2><p class="lead">{T('WEB_ASK_D')}</p>
<form onsubmit="return false"><label class="f">{T('WEB_ASK_MAIL')}<input class="f" type="email" name="email" required></label>
<label class="f">{T('WEB_ASK_BODY')}<textarea name="body" required></textarea></label>
<input class="hp" name="website" tabindex="-1" autocomplete="off" aria-hidden="true">
<button class="btn" type="submit" disabled>{T('WEB_ASK_SEND')}</button><p class="note">{T('WEB_ASK_PREVIEW')}</p></form></div></section>
<footer><div class="wrap"><h3>{T('WEB_PRIV_T')}</h3><p>{T('WEB_PRIV_D')}</p><p>{T('WEB_FOOT')}</p></div></footer>
</body></html>"""


def build(out=OUT, conn=None):
    own = conn is None
    conn = conn or appdb.connect()
    try:
        if os.path.isdir(out):
            for n in os.listdir(out):
                if n == '.git':
                    continue
                p = os.path.join(out, n)
                shutil.rmtree(p) if os.path.isdir(p) else os.remove(p)
        os.makedirs(os.path.join(out, 'a'), exist_ok=True)
        shutil.copyfile(os.path.join(HERE, 'icons', 'Hagah Dabar.png'), os.path.join(out, 'a', 'icon.png'))
        for sub in ('m', 'pc'):
            shutil.copytree(os.path.join(ASSETS, sub), os.path.join(out, 'a', sub))
        langs = ready_langs(conn)
        files = []
        for lg in langs:
            d = os.path.join(out, lang_dir(lg))
            os.makedirs(d, exist_ok=True)
            with open(os.path.join(d, 'index.html'), 'w', encoding='utf-8') as f:
                f.write(page(conn, lg, langs))
            files.append(lang_dir(lg) + 'index.html')
        try:
            import site_magazine as MAG
            for lg in MAG.build_into(out, conn, lang_dir):
                files.append(lang_dir(lg) + MAG.PAGE)
        except Exception as ex:                           # noqa: BLE001
            print('잡지를 못 만듦:', ex)
        open(os.path.join(out, '.nojekyll'), 'w').close()
        return files
    finally:
        if own:
            conn.close()


def publish(out=OUT, work=WORK):
    """만든 것을 Pages 저장소에 올린다 — 바뀐 것만 커밋 · 비밀값 검사(secret_store) 거친다."""
    import secret_store
    for d, _ds, fs in os.walk(out):
        for f in fs:
            with open(os.path.join(d, f), 'rb') as fh:
                secret_store.assert_clean(fh.read(), f)
    git = lambda *a, cwd=work: subprocess.run(['git', *a], cwd=cwd, capture_output=True,  # noqa: E731
                                              text=True, encoding='utf-8', errors='replace')
    if not os.path.isdir(os.path.join(work, '.git')):
        subprocess.run(['git', 'clone', REPO_URL, work], capture_output=True, text=True,
                       encoding='utf-8', errors='replace')
        if not os.path.isdir(os.path.join(work, '.git')):
            os.makedirs(work, exist_ok=True)
            git('init')
            git('remote', 'add', 'origin', REPO_URL)
    git('pull', '--ff-only', 'origin', 'main')
    for n in os.listdir(work):
        if n == '.git':
            continue
        p = os.path.join(work, n)
        shutil.rmtree(p) if os.path.isdir(p) else os.remove(p)
    for n in os.listdir(out):
        s, dd = os.path.join(out, n), os.path.join(work, n)
        shutil.copytree(s, dd) if os.path.isdir(s) else shutil.copyfile(s, dd)
    if not (git('config', 'user.email').stdout or '').strip():
        git('config', 'user.email', 'suhyw123@gmail.com')
        git('config', 'user.name', 'suhyw123-hub')
    git('checkout', '-B', 'main')
    git('add', '-A')
    cm = git('commit', '-m', 'site publish')
    if cm.returncode != 0 and 'nothing to commit' in (cm.stdout + cm.stderr):
        return True, '바뀐 것 없음'
    p = git('push', '-u', 'origin', 'main')
    return p.returncode == 0, (p.stderr or p.stdout)[-200:]


def selftest():
    import re
    import tempfile
    ok = []
    ck = lambda c, m: (ok.append(bool(c)), print(('PASS ' if c else 'FAIL ') + m))   # noqa: E731
    conn = appdb.connect()
    try:
        d = tempfile.mkdtemp()
        files = build(d, conn)
        ck('index.html' in files, '첫 화면 = KO (%d 언어)' % len(files))
        h = open(os.path.join(d, 'index.html'), encoding='utf-8').read()
        ck(not re.search(r'<script[^>]+src=', h, re.I), '외부 스크립트 없음(다크모드 한 줄만)')
        ck(not re.search(r'(?:src|href)="https?://', h), '외부 그림·글꼴·링크 없음(추적 0)')
        ck('googletagmanager' not in h and 'analytics' not in h.lower(), '분석 도구 0')
        ck('쿠팡' not in h and 'coupang' not in h.lower() and '수수료' not in h, '상품이 없으면 쇼핑·고지 없음')
        ck('하가 다바르' in h and '119:105' in h and '사 31:4' in h, '앱 이름·이름 이야기·대표 말씀')
        ck('data-theme' in h and 'class="mode"' in h and h.index('class="mode"') < h.index('class="brand"'),
           '다크모드 단추가 왼쪽 위')
        ck('class="lang"' in h and h.index('class="lang"') > h.index('<nav>'), '언어 선택기가 오른쪽 위')
        ck(h.count('class="set"') == len(FEATS), '기능 세트 = 설명 + 화면')
        ck('id="gm"' in h and 'id="gp"' in h, '화면 미리보기 모바일/PC 갈래')
        ck('WEB_SYNC_L_T' not in h and '와이파이' in h, '폰·PC 동기화 절')
        missing = [p for p in re.findall(r'src="([^"]+)"', h) if not os.path.exists(os.path.join(d, p))]
        ck(not missing, '그림이 다 있다 %s' % missing[:3])
        ck(products(conn, 'KO') == [], '상품 표 없음 → 0')
        ck(t(conn, 'EN', 'WEB_NOPE') == 'WEB_NOPE', '모르는 열쇠는 열쇠 그대로')
        ck('KO' in ready_langs(conn), 'KO 는 늘 만든다')
        shutil.rmtree(d, ignore_errors=True)
    finally:
        conn.close()
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    if '--seed-i18n' in a:
        c = appdb.connect()
        print('KO 씨앗', seed_ko(c))
        c.close()
    if '--build' in a:
        print(build(), '→', OUT)
    if '--publish' in a:
        print(publish())
