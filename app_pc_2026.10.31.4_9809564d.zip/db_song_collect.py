# -*- coding: utf-8 -*-
"""곡 하나로 원곡·번안곡을 함께 수집한다 (2026-09-09 신설 · 영구 도구 · 멱등).

사용자 지시 — 「**지금 수집된 찬양을 기준으로 원곡, 번안곡을 수집해보자.
그러면 번안곡 관리의 아이디어가 나올 것이다**」.

★★★ **왜 곡이 축인가 — 실측이 그것을 말한다.**
  · 같은 원곡을 **두 사역팀이 다른 제목**으로 번안한다:
    `Always You, Jesus` → 「난 언제나 예수」(아가파오) · 「**언제나 주만**」(제이어스).
    **제목으로는 절대 못 묶는다.**
  · 한 곡에 판이 여섯 이상이다 — 「우리 주 안에서 노래하며」가 어노인팅·잔치공동체·
    팀룩·예람·한성교회·아가파오.
  ⇒ 곡 층이 없으면 같은 곡이 목록에 여섯 번 뜬다.

★★★ **다리는 「번안 영상이 스스로 원제를 말한다」는 것이다**(실측) —
  `우리 주 안에서 노래하며 That's What We Came Here For` ·
  `New Thing Coming (새 일이 일어나네)` · `언제나 주만 Always You, Jesus`.
  기계가 읽을 수 있는 자리는 여기뿐이다.

⚠⚠ **제목 파싱은 후보만 낸다 — 사람이 정한다.** 실측 285편에서 짝을 뽑으니
  절반이 잡음이었다(`⇄ Official` · `⇄ CCM Playlist` · `⇄ Unspeakable Joy`(부제)).
  그래서 `SONGS` 는 **사람이 확인한 표**이고 `parse()` 는 그 표를 채울 후보를 낸다.

⚠⚠ **흔한 낱말 곡명은 영문으로 검색하지 않는다** — 실측 「Secret」 검색에
  DIMO REX(찬양 아님)가 왔고 「My God You are King above all」에 Lenny LeBlanc 의
  **딴 곡**(`Above All`)이 왔다. `en_search=False` 로 끈다.

⚠ **「- Topic」은 유튜브가 저작권 정보로 자동 만든 음원 채널**이라 사역팀 것이
  아니다. 다만 **그 이름이 곡을 부른 사역자를 말해 준다**(실측 한 검색에
  `어노인팅 - Topic` 과 `Hillsong Worship - Topic` 이 함께 나왔다 = 원곡↔번안 짝).
  담지는 않고 **알려만 준다**.

⚠ 담는 문은 **`media_intake.admit` 하나**다(§195차 ⑨) — 여기서 INSERT 하지 않는다.
★★★ **분야를 준다(`domain='WORSHIP'`)** — 오프토픽 낱말 `worship song`·
  `ccm`·`music video`·`choir` 는 **구절 수집 관점**의 말이라 찬양 수집에서는
  정반대로 작동한다. 실측 겨냥 검색 625편 중 **86편(14%)** 이 그 셋에
  죽고 있었고 전부 정당한 찬양이었다(2026-09-10).
"""
import json
import re
import sys

import appdb

DB = 'bible_master.db'

#: 검색 한 번 = **100 units**. 하루 예산을 넘기지 않게 상한을 둔다.
DAILY_MAX_SEARCH = 40

#: ★ 곡 표 — **사람이 확인한 것만**. `(코드, 한국어 제목들, 영문 제목, 영문 검색 여부)`
#:   한국어 제목이 여럿인 것이 이 표의 존재 이유다(번안 제목이 팀마다 다르다).
#: ⚠ 영문 제목이 흔한 낱말이면 `en_search=False` — 딴 곡이 섞인다.
SONGS = [
    ('HOLY_FOREVER',  ['거룩 영원히'], 'Holy Forever', True),
    ('LIVING_HOPE',   ['주 예수 나의 산 소망'], 'Living Hope', True),
    ('NEW_THING',     ['새 일이 일어나네'], 'New Thing Coming', True),
    ('CAME_HERE_FOR', ['우리 주 안에서 노래하며', '우리 주안에서 노래하며'],
     "That's What We Came Here For", True),
    ('ALWAYS_YOU',    ['난 언제나 예수', '언제나 주만'], 'Always You Jesus', True),
    # ⚠ 영문 이름이 짧으면 **딴 곡을 먹는다** — 「Hold Me Fast」로 찾으니
    #   시편 139편의 딴 곡(`Hold Me Fast (Psalm 139)`)이 왔다(실측).
    #   원제 그대로 「He Will Hold Me Fast」를 쓴다.
    ('HOLD_ME_FAST',  ['주 말씀대로 날 붙드소서'], 'He Will Hold Me Fast', True),
    ('NEVER_SLUMBER', ['그는 졸지 않고'], 'He Will Never Slumber', True),
    ('HIGHEST_HONOUR', ['주님 큰 영광 받으소서'],
     'Jesus Shall Take the Highest Honour', True),
    ('ALL_HEAVEN',    ['선포하라'], 'All Heaven Declares', True),
    # ⚠ 흔한 낱말 — 한국어로만 찾는다
    ('MY_GOD_KING',   ['왕이신 나의 하나님'], 'My God You are King above all', False),
    # ⚠⚠ 「기억하네」는 **흔한 말**이다 — 쿠팡플레이 드라마·트로트 콘서트가
    #   문지기를 통과했다(실측 12편 중 3편). 「축복 The Blessing」 선례대로
    #   **부제를 곡명 자리에 넣어** 그것으로만 찾는다.
    #   ⚠ 성가대 「기억하네」는 **딴 곡**이라 함께 빠지는 것이 맞다.
    ('I_REMEMBER',    ['기억하네 (시편 77편)'], 'I Remember (Psalm 77)', True),
    # ★ 중화권 — 讚美之泉·小羊詩歌 (2026-09-09 사용자 「외국 채널도 분석해야
    #   더 다양한 패턴을 알 수 있을 것이다」). 제목 꼴이 가장 깨끗하다:
    #   `【곡명 원제】官方歌詞版MV - 사역자 (앨범번호)` — 갈래가 제목에 박혀 있다.
    ('THE_CROSS',     ['十字架', '십자가'], 'The Cross', False),
    ('PATH_OF_GRACE', ['恩典之路'], 'The Path of Grace', True),
    ('ENDLESS_LOVE',  ['深不見底的愛', '深不见底的爱'], 'Endless Love', False),
    ('REDEEMER_LIVES', ['我的救贖者活著', '我的救赎者活着'],
     'My Redeemer Lives', True),
    ('GOD_REIGNS',    ['神掌權', '神掌权'], 'God Reigns', False),
    # ★ 영어권 원곡 — 번안이 여럿인 것
    ('WAY_MAKER',     ['웨이메이커', '길을 만드시는'], 'Way Maker', True),
    ('GOODNESS_GOD',  ['선하신 하나님'], 'Goodness of God', True),
    ('GRAVES_GARDENS', ['무덤에서 정원으로'], 'Graves Into Gardens', True),
    # ★ 수확기(`--harvest`)가 찾아낸 곡 — 사람이 확인해 담은 것(2026-09-09)
    # ⚠ 「축복」은 흔한 낱말이라 **곡명으로 못 쓴다**(실측 신명기 28장 설교
    #   다섯 편이 왔다). 마커스 판 제목이 「축복 The Blessing」이므로 **영문
    #   원제를 한국어 이름 자리에 두고** 그것으로만 찾는다.
    ('THE_BLESSING',   ['축복 The Blessing'], 'The Blessing', True),
    ('EVERYTHING_I_AM', ['내 안에 있는 것'], 'Everything I am', True),
    ('WASHED',         ['깨끗케 해'], 'Washed', False),
    ('COME_HOLY_SPIRIT', ['임재 Come Holy Spirit'], 'Come Holy Spirit', True),
    ('THOSE_WHO_SEEK', ['주를 찾는 모든 자들이'], 'Those Who Seek the Lord', True),
    ('HANDS_OF_GOD',   ['주의 손이'], 'Hands of God', True),
    ('TO_BE_LIKE_JESUS', ['예수 닮기를'], 'To Be Like Jesus', True),
    ('LORDS_PASSOVER', ['여호와의 유월절'], "The Lord's Passover", False),
    ('RUSHING_WIND',   ['임하소서'], 'Come Like A Rushing Wind', True),
    ('LOVE_MAKES_BRAVE', ['愛使我們勇敢', '爱使我们勇敢'],
     'Love Can Make Us Brave', False),
    ('KNOW_I_AM_GOD',  ['要知道我是神', '要知道我是神'], 'Know That I Am God', False),
    ('WAIT_WITH_FAITH', ['信心的等待'], 'Wait with faith', False),
    ('AT_CALVARY',     ['在各各他'], 'At Calvary', True),
]

#: ⚠⚠ **곡명이 흔한 낱말이면 그 곡은 수집 대상이 아니다**(2026-09-09 실측).
#:   「비밀」로 찾으니 **KBS 드라마·이승기·부활 밴드가 9편** 들어왔다 — 제목
#:   일치 문지기를 통과했고 오프토픽 필터도 못 막았다(기독교 낱말이 없는 것이
#:   아니라 **그 낱말이 어느 장르에나 있는 것**이라서다). 그 9편은 걷었다.
#:   ⇒ 곡을 표에 넣기 전에 **그 이름이 찬양 밖에서도 흔한가**를 먼저 본다.
#: ⚠ 중국어도 같다 — 「我們愛」로 찾으니 **경매 물품(我們愛國旗)·중국 음악
#:   프로그램·태국 팝(Four-Mod)** 이 왔다.
COMMON_WORD_SONGS = ('비밀', 'Secret', '사랑', '기쁨', '소망', '축복', '은혜',
                     '임재', '갈보리', '평강', '자유', '기억하네',
                     'Hold Me Fast',
                     '我們愛', '我们爱', 'We Will Love', '愛', '爱')

#: 제목 파싱이 곡명으로 잘못 집는 꼬리말 — 실측으로 모은 것
SONG_STOP = {
    'official', 'lyrics', 'lyric', 'live', 'mv', 'm/v', 'audio', 'video',
    'cover', 'playlist', 'palylist', 'ccm playlist', 'official audio',
    'official video', 'official lyrics', 'ver', 'inst', 'karaoke', 'full',
    'shorts', 'teaser', 'medley', 'remix', 'acoustic',
}

_HAN = re.compile(r'[가-힣]')
_LAT = re.compile(r'[A-Za-z]')


def _clean(t):
    """앞머리 `[사역자]` 와 `|` 뒤 부제를 걷는다."""
    t = re.sub(r'^\s*\[[^\]]{1,30}\]\s*', '', t or '')
    t = re.sub(r'\s*[|｜].*$', '', t)
    return t.strip()


def parse(title):
    """제목에서 (한국어 곡명, 영문 곡명) **후보**를 낸다 — 판정은 사람이 한다.

    ⚠ 실측 정확도가 절반이라 **자동으로 `SONGS` 에 넣지 않는다.**
    """
    t = _clean(title)
    cands = []
    if ' / ' in t:
        a, b = [x.strip() for x in t.split(' / ', 1)]
        cands.append((a, b))
    m = re.match(r'^(.+?)\s*[\(（]([^)）]{3,40})[\)）]\s*$', t)
    if m:
        cands.append((m.group(1).strip(), m.group(2).strip()))
    m = re.match(r'^([^A-Za-z]*[가-힣][^A-Za-z]*?)\s+'
                 r'([A-Za-z][A-Za-z0-9\'’,\.\s!\?&-]{4,40})$', t)
    if m:
        cands.append((m.group(1).strip(), m.group(2).strip()))
    out = []
    for a, b in cands:
        ka, kb = bool(_HAN.search(a)), bool(_HAN.search(b))
        la, lb = bool(_LAT.search(a)), bool(_LAT.search(b))
        ko, en = (a, b) if (ka and lb and not kb) else (
            (b, a) if (kb and la and not ka) else (None, None))
        if not ko or not en:
            continue
        if en.strip().lower() in SONG_STOP:
            continue
        if (ko, en) not in out:
            out.append((ko, en))
    return out


# ── 곡명 수확 — 사역자 채널이 광산이다 (2026-09-09) ─────────────────────────
#: 사용자 관찰(2026-09-09) — 「**여러 곡을 한 컨텐츠로 만든 경우 보통 곡이름이
#:   열거된다**」 · 「**사역자 db 를 만들어보면 곡이름이 더 추출될 것 같다**」.
#:   둘 다 실측으로 확인됐다.
#:
#: ★★★ **사역팀마다 제목 꼴이 다르다** — 팀별 파서를 만들 것이 아니라 **여러
#:   규칙을 함께 걸어** 후보를 모은다(실측):
#:   | 사역팀 | 꼴 |
#:   |---|---|
#:   | 레비스탕스 | `[For Your Glory] LEVISTANCE in PRAYER ROOM` — **대괄호가 곡명** |
#:   | 마커스워십 | `축복 The Blessing - 마커스워십 … \| A Key` |
#:   | 아이자야씩스티원 | `주를 기억하라 + 보라 너희는 두려워 말고` — **`+` 가 곡 구분자** |
#:   | 讚美之泉 | `【곡명 영문명】官方歌詞版MV - 사역자 (앨범번호)` |
#:
#: ⚠⚠ **전각 `【 】` 만 곡 열거로 읽는다** — 반각 `[ ]` 는 한국어에서 채널·갈래
#:   표기라 실측 `[CCD농장/워십댄스/워십댄스 배우기]` 가 곡명 셋으로 잡혔다.

#: 곡명이 아닌 것 — 대괄호·열거에 흔히 오는 말(실측으로 모았다)
NOT_SONG = {
    'official', 'live', 'mv', 'audio', 'video', 'lyrics', 'cover', 'playlist',
    'shorts', 'teaser', 'full', 'ver', 'inst', 'karaoke', 'medley', 'remix',
    'worship', 'live worship', 'prayer room', 'key', 'sub', 'eng sub',
    'kor sub', '워십', '워십댄스', '찬양', '예배', '실황', '라이브', '가사',
    '악보', '반주', '커버', '모음', '연속듣기', '플레이리스트', '사역 스케치',
    '재업', '요청', '거울모드', '공식', '공식음원', '뮤직비디오', '미리보기',
    # ⚠ 실측 후보에 섞여 나온 채널·갈래 표기(2026-09-09)
    '트롯찬양', '은혜찬양', '감사찬양', '성경탐구', '악보&찬양', '중앙아트',
    '中英字幕', '官方', '生中継', 'official audio', 'official mv',
    'lyrics mv', 'live clip', '현장예배', '수요성경공부', '뉴시즌 투어',
}


#: ⚠⚠ 라틴 짧은 낱말을 **부분 일치로 보면 안 된다** — 실측 `ver` 가
#:   `Everything I am` 을, `live` 가 `주님의 긍휼 (live)` 를 먹었다(§228차 함정).
#:   ⇒ **한국어 갈래어만 부분 일치**(합성어가 흔하다) · 라틴은 정확 일치.
_PAREN_TAIL = re.compile(r"\s*[\(（\[][^)）\]]{1,20}[\)）\]]\s*$")


def _is_song_name(s):
    """곡명으로 쓸 만한가 — 길이·금지어·숫자만 등을 본다."""
    s = (s or '').strip()
    # ★ 꼬리 괄호 갈래 표기를 먼저 걷는다 — `주님의 긍휼 (live)` · `… (Official)`
    s = _PAREN_TAIL.sub('', s).strip()
    if not (2 <= len(s) <= 40):
        return False
    low = s.lower()
    if low in NOT_SONG:
        return False
    # ⚠ 반각 대괄호 안 `/` 는 **열거가 아니라 채널·갈래 표기**다(실측
    #   `[CCD농장/워십댄스/워십댄스 배우기]`). 전각 `【】` 만 열거로 읽는다.
    if '/' in s:
        return False
    for w in NOT_SONG:
        if len(w) >= 3 and re.search(r'[가-힣]', w) and w in low:
            return False
    if re.fullmatch(r'[\d\s\.\-:/#]+', s):      # 날짜·번호만
        return False
    if not re.search(r'[가-힣A-Za-z一-鿿]', s):
        return False
    return True


_BRACE_FULL = re.compile(r'【(.{2,120}?)】')       # ★ 전각만
_BRACKET = re.compile(r'\[([^\]]{2,40})\]')
_SPLIT = re.compile(r'\s*[/+]\s*')


#: 성경 책 이름 + 장 = 곡명이 아니다(실측 `Exodus 23` · `Leviticus 2`)
_BIBLE_REF = re.compile(
    r'^(genesis|exodus|leviticus|numbers|deuteronomy|joshua|judges|ruth|samuel|'
    r'kings|chronicles|ezra|nehemiah|esther|job|psalms?|proverbs|ecclesiastes|'
    r'isaiah|jeremiah|lamentations|ezekiel|daniel|hosea|joel|amos|obadiah|jonah|'
    r'micah|nahum|habakkuk|zephaniah|haggai|zechariah|malachi|matthew|mark|luke|'
    r'john|acts|romans|corinthians|galatians|ephesians|philippians|colossians|'
    r'thessalonians|timothy|titus|philemon|hebrews|james|peter|jude|revelation)'
    r'[\s\d:.\-–~]*$', re.I)


def harvest_title(title, drop=None):
    """제목 하나에서 곡명 **후보**를 뽑는다 → [이름].

    ⚠ **후보다** — 사람이 `SONGS` 에 넣을지 정한다(파싱 정확도가 절반이다).
    ⚠ `drop` 에 **그 영상의 채널 이름·사역자 이름**을 주면 뺀다 — 실측 후보
      110개 중 `하루예배`·`AGAPAO Worship`·`Leeland`·`Chris Tomlin` 처럼
      **채널·사역자 이름이 곡명 자리에** 오는 것이 절반이었다.
    """
    t = (title or '').strip()
    if not t:
        return []
    out = []

    low_drop = {str(d).strip().lower() for d in (drop or []) if d}

    def add(x):
        x = re.sub(r'\s+', ' ', (x or '').strip(' ·-–—|｜'))
        # ⚠ HTML 엔티티가 제목에 그대로 온다(`악보&amp;찬양`)
        x = x.replace('&amp;', '&').replace('&#39;', "'").replace('&quot;', '"')
        # ★ 판정만이 아니라 **담는 이름에서도** 꼬리 갈래 괄호를 걷는다
        #   — `주님의 긍휼 (live)` 를 그대로 두면 곡명이 판마다 갈린다.
        x = _PAREN_TAIL.sub('', x).strip()
        if x.lower() in low_drop:          # 채널·사역자 이름은 곡명이 아니다
            return
        if _BIBLE_REF.match(x):            # 성경 참조도 아니다
            return
        if _is_song_name(x) and x not in out:
            out.append(x)

    # ① 【곡 / 곡 / 곡】 — 중화권 특집(전각만)
    for m in _BRACE_FULL.finditer(t):
        inner = m.group(1)
        parts = _SPLIT.split(inner) if re.search(r'[/+]', inner) else [inner]
        for p in parts:
            add(re.sub(r'^\[|\]$', '', p))
    # ② [곡명] 사역자 — 레비스탕스 꼴. **맨 앞 대괄호 하나**만 본다
    m = re.match(r'^\s*\[([^\]]{2,40})\]', t)
    if m:
        add(m.group(1))
    # ③ 곡 + 곡 — 아이자야씩스티원 꼴(전각 대괄호 밖에서)
    head = _BRACE_FULL.sub(' ', t)
    head = re.split(r'\s*[|｜]\s*', head)[0]
    if ' + ' in head:
        for p in head.split(' + '):
            add(p)
    # ④ 앞머리 = 곡명 — `곡명 - 사역자` · `곡명 (…) - 사역자`
    m = re.match(r'^([^\[\]|｜【】]{2,40}?)\s+[-–—]\s+', t)
    if m:
        add(m.group(1))
    return out


def harvest(conn, min_hit=1, limit=200):
    """**사역자 채널 영상**의 제목에서 곡명 후보를 모은다 → [(이름, 몇 편, 사역자)].

    ★ 사용자 관찰 그대로 — 사역자 DB 가 커질수록 곡명이 더 나온다.
    ⚠ 이미 `SONGS` 에 있는 이름은 뺀다.
    """
    import db_worship_artist as WA
    _artist_names = {n for a in WA.artists(conn) for n in
                     ([a[1]] + list(WA.names_of(conn, a[0]).values()))}
    have = set()
    for _c, kos, en, _s in SONGS:
        have |= {k.lower() for k in kos}
        have.add(en.lower())
    seen = {}
    for aid, nm, _co, _kd, _ext, n in WA.artists(conn):
        if not n:
            continue
        for (ti,) in conn.execute(
                "SELECT m.title FROM sys_link_asset l"
                " JOIN sys_media_asset m ON m.media_id=l.clicked_id"
                " WHERE l.link_type=? AND l.target_id=? AND m.record_status='LIVE'"
                "   AND m.media_type='WORSHIP'", (WA.LINK, aid)).fetchall():  # status-ok: 영상은 상태를 본다(`m.record_status`) · 연결은 **곡 이름을 캐는 재료**라 상태가 가르는 것이 없다
            for s in harvest_title(ti, drop=[nm] + list(_artist_names)):
                if s.lower() in have:
                    continue
                k = seen.setdefault(s, [0, set()])
                k[0] += 1
                k[1].add(nm)
    out = [(s, v[0], ' · '.join(sorted(v[1]))) for s, v in seen.items()
           if v[0] >= min_hit]
    return sorted(out, key=lambda x: -x[1])[:limit]


def harvest_all(conn, limit=200):
    """사역자를 안 가리고 **찬양 전체**에서 모은다 — 특집 제목이 여기 걸린다."""
    have = set()
    for _c, kos, en, _s in SONGS:
        have |= {k.lower() for k in kos}
        have.add(en.lower())
    seen = {}
    import db_worship_artist as WA
    import json as _json
    drop = {n for a in WA.artists(conn) for n in
            ([a[1]] + list(WA.names_of(conn, a[0]).values()))}
    for ti, d in conn.execute(
            "SELECT title, COALESCE(description,'') FROM sys_media_asset"
            " WHERE record_status='LIVE' AND media_type='WORSHIP'").fetchall():
        ch = ''
        if d.startswith('{'):
            try:
                ch = _json.loads(d).get('channel') or ''
            except Exception:
                ch = ''
        for s in harvest_title(ti, drop=list(drop) + ([ch] if ch else [])):
            if s.lower() in have:
                continue
            seen[s] = seen.get(s, 0) + 1
    return sorted(seen.items(), key=lambda x: -x[1])[:limit]


def suggest(conn, limit=40):
    """지금 찬양 제목에서 **곡 표에 없는** 후보를 낸다 → [(후보, 제목)]."""
    have = set()
    for _c, kos, en, _s in SONGS:
        have |= {k.lower() for k in kos}
        have.add(en.lower())
    out = []
    for (ti,) in conn.execute(
            "SELECT title FROM sys_media_asset WHERE record_status='LIVE'"
            " AND media_type='WORSHIP'"):
        for ko, en in parse(ti or ''):
            if ko.lower() in have or en.lower() in have:
                continue
            out.append(((ko, en), (ti or '')[:60]))
            if len(out) >= limit:
                return out
    return out


# ── 수집 ────────────────────────────────────────────────────────────────────

def names_of(song):
    """그 곡의 모든 이름(한국어 여럿 + 영문).

    ⚠ 다섯째 칸(**찾을 때 앞에 붙일 말**)은 **이름이 아니다** — 문지기는
      이름으로만 잰다(§2026-09-12).
    """
    _c, kos, en = song[0], song[1], song[2]
    return list(kos) + [en]


def _prefix(song):
    """찾을 때 **이름 앞에 붙일 말**(사역자 이름) — 없으면 `''`.

    ★★★ 2026-09-12 표본 조사 — 「Made a Way」만으로는 못 찾고
      **「Travis Greene Made a Way」**로 찾았다. 곡 이름이 짧고 흔할수록
      사역자 이름이 결정적이다.
    ⚠ **문지기에는 안 쓴다** — 제목에 사역자 이름이 없어도 그 곡일 수 있다.
    """
    return (song[4] if len(song) > 4 else '') or ''


def gate(title, song):
    """제목에 그 곡의 이름이 **통째로** 들어 있나 → 걸린 이름 | None.

    ★ 이것이 문지기다 — 검색은 엉뚱한 것을 준다(실측 「My God You are King
      above all」 검색에 Lenny LeBlanc 의 딴 곡 `Above All` 이 왔다).
    """
    low = (title or '').lower()
    for nm in names_of(song):
        if nm.lower() in low:
            return nm
    # ⚠ 한국어는 띄어쓰기가 흔들린다 — 공백을 지우고 한 번 더 본다
    flat = re.sub(r'\s+', '', low)
    for nm in names_of(song):
        if _HAN.search(nm) and re.sub(r'\s+', '', nm.lower()) in flat:
            return nm
    return None


#: 한 검색에 받는 수 — **비용과 무관**(1개든 50개든 100 units · 2026-09-17 점검).
SEARCH_PAGE = 25


def search(keys, q, n=SEARCH_PAGE):
    """유튜브 검색 → [dict] (100 units). 키가 막히면 다음 키로.

    ⚠ `n` 은 **비용과 무관**하다 — 1개를 받든 50개를 받든 100 units 다(2026-09-17 점검).
      12 → 25. 곡 이름 검색은 같은 곡의 다른 판을 모으는 일이라 깊이 볼수록 값이 있다."""
    from googleapiclient.discovery import build
    for i in range(len(keys)):
        try:
            yt = build('youtube', 'v3', developerKey=keys[i],
                       cache_discovery=False)
            r = yt.search().list(part='snippet', type='video', q=q,
                                 maxResults=n).execute()
            return r.get('items', [])
        except Exception:
            continue
    return []


def api_keys(conn):
    row = __import__('secret_store').row('YOUTUBE_API_KEYS')  # 열쇠는 배포 DB 밖(2026-10-11)
    return [k.strip() for k in (row[0] if row else '').split(',') if k.strip()]


def collect(conn, songs=None, keys=None, dry=False, log=print):
    """곡마다 한국어·영문 이름으로 찾아 담는다 → 요약 dict.

    ⚠ 담는 문은 `media_intake.admit` 하나다 — 문지기(채널 차단·오프토픽)·분류·
      연결이 전부 거기에 있다.
    """
    import media_intake as MI
    import media_taxonomy as _tax
    songs = songs or SONGS
    keys = keys if keys is not None else api_keys(conn)
    if not keys:
        log('  [곡 수집] API 키가 없습니다.')
        return {'skipped': 'NO_KEY'}
    gate_obj = MI.Gate(conn)
    out = {'q': 0, 'seen': 0, 'kept': 0, 'new': 0, 'skip_gate': 0,
           'skip_intake': 0, 'topic': {}, 'by_song': {}}
    for song in songs:
        code, kos, en, en_search = song[0], song[1], song[2], song[3]
        _pf = _prefix(song)
        # ★ 사역자 이름을 앞에 붙여 찾는다 — **문지기는 이름만 본다**
        qs = [((_pf + ' ' + q).strip() if _pf else q)
              for q in (list(kos) + ([en] if en_search else []))]
        got = []
        for q in qs:
            if out['q'] >= DAILY_MAX_SEARCH:
                log('  [곡 수집] 검색 상한 %d 에 닿아 멈춥니다.' % DAILY_MAX_SEARCH)
                # ⚠⚠ **이른 반환이 `commit` 을 건너뛰면 그동안 담은 것이 통째로
                #   롤백된다**(실측 110편이 그렇게 사라졌다 — §229차 그 자리).
                if not dry:
                    conn.commit()
                return out
            out['q'] += 1
            got += search(keys, q)
        seen_ids = set()
        n_new = 0
        for it in got:
            vid = it['id']['videoId']
            if vid in seen_ids:
                continue
            seen_ids.add(vid)
            out['seen'] += 1
            sn = it['snippet']
            ti = sn['title']
            ch = sn['channelTitle']
            # ★ 「- Topic」 은 담지 않고 **원곡 사역자 실마리로 적어 둔다**
            if ch.endswith('- Topic'):
                out['topic'].setdefault(code, set()).add(ch[:-8].strip())
                continue
            hit = gate(ti, song)
            if not hit:
                out['skip_gate'] += 1
                continue
            out['kept'] += 1
            if dry:
                continue
            r = MI.admit(gate_obj, {
                'title': ti,
                'url': 'https://www.youtube.com/watch?v=%s' % vid,
                # ⚠ **한글이 아니면 EN 으로 정하면 안 된다** — 실측 중국어
                #   讚美之泉 제목 60여 편이 통째로 EN 으로 들어갔다. 언어 판정은
                #   `media_taxonomy.guess_lang` **한 문**이 한다.
                'lang_code': _tax.guess_lang(ti),
                'channel': ch, 'channel_id': sn.get('channelId', ''),
                'published': sn.get('publishedAt', ''),
                'yt_desc': sn.get('description', ''),
                'desc_extra': {'song_code': code, 'song_hit': hit,
                               'song_collected': True,
                               # ★ 판 갈래 — 제목이 스스로 말한다(넷째 축)
                               'rend_kind': _tax.rend_kinds(
                                   ti, _tax.guess_lang(ti))},
            }, domain='WORSHIP')
            # ★★ **곡으로 찾은 것은 찬양이 확실하다 — 유형을 못 박는다**
            #   (2026-09-09 실측). 낱말 분류가 이것을 못 잡는다 — 「우리 주
            #   안에서 노래하며」에는 찬양 낱말이 하나도 없어 **163편 중 92편이
            #   SERMON** 으로 찍혔다. 곡 이름이 걸렸다는 사실이 낱말보다 강하다.
            _mid = r.get('media_id')
            if _mid:
                conn.execute("UPDATE sys_media_asset SET media_type='WORSHIP'"
                             " WHERE media_id=? AND media_type<>'WORSHIP'", (_mid,))
            if r.get('action') == MI.ACT_NEW:
                out['new'] += 1
                n_new += 1
            elif r.get('action') not in (MI.ACT_NEW, MI.ACT_EXIST):
                out['skip_intake'] += 1
        out['by_song'][code] = n_new
        log('  %-16s 검색 %d · 새로 %d편' % (code, len(qs), n_new))
    if not dry:
        conn.commit()
    return out


def sweep(conn, dry=True, log=print):
    """이미 담은 곡 영상에 **문지기를 다시 건다** → 요약 dict.

    ★★★ **곡명 표를 고치면 반드시 이것을 돌린다.** 문지기가 느슨했던 동안
      들어온 것은 스스로 안 나간다 — 그리고 `collect` 가 `media_type='WORSHIP'`
      을 **못 박으므로** 오탐이 찬양 분류를 통째로 오염시킨다(실측 쿠팡플레이
      드라마·트로트 콘서트가 「기억하네」로 들어와 WORSHIP 이 됐다).

    ★★★ **두 가지를 갈라야 한다**(실측으로 배웠다):
      ⓐ **곡 연결이 틀린 것** — 그 곡이 아니다. **연결만 걷는다.**
      ⓑ **아예 찬양이 아닌 것** — 쿠팡플레이 드라마·트로트 콘서트.
      ⚠ 그런데 **표에서 뺀 곡**(「我們愛」처럼 흔한 낱말이라 버린 것)의 영상은
        멀쩡한 찬양이다 — 통째로 걷으면 정당한 讚美之泉 영상을 잃는다.
      ⇒ 잣대는 **「다른 연결이 있는가」**다. 구절·용어에 걸려 있으면 그 영상은
        제 자리를 얻은 것이라 연결만 걷고, 아무 데도 안 걸렸으면
        **승인을 내린다**(`is_active=0` — 지우지 않는다. 검토 화면이 판단한다).
    """
    import json as _js
    import db_song as _S
    by_code = {s[0]: s for s in SONGS}
    out = {'seen': 0, 'bad': 0, 'moved': 0, 'unlinked': 0, 'unapproved': 0}
    for mid, ti, desc in conn.execute(
            "SELECT media_id, title, COALESCE(description,'')"
            " FROM sys_media_asset WHERE record_status='LIVE'").fetchall():
        if not desc.startswith('{'):
            continue
        try:
            d = _js.loads(desc)
        except Exception:
            continue
        code = d.get('song_code')
        if not code:
            continue
        out['seen'] += 1
        song = by_code.get(code)
        if song is not None and gate(ti or '', song):
            continue
        # ★ 딴 곡으로 갈아탄다 — 「여러 곡을 한 영상」이 흔하다(사용자 관찰).
        #   실측 【愛使我們勇敢 / 我們愛】 한 영상이 두 곡을 담는다. 표에서 뺀
        #   곡의 코드가 붙어 있어도 **다른 곡이 제목에 있으면 그리로 옮긴다.**
        alt = None
        for s2 in SONGS:
            if s2[0] != code and gate(ti or '', s2):
                alt = s2[0]
                break
        if alt:
            out['moved'] += 1
            log('  ~ %-13s -> %-13s %s' % (code[:13], alt[:13], (ti or '')[:44]))
            if not dry:
                d['song_code'] = alt
                conn.execute("UPDATE sys_media_asset SET description=?"
                             " WHERE media_id=?", (_js.dumps(d, ensure_ascii=False), mid))
                conn.execute("UPDATE sys_link_asset SET record_status='HIDE'"
                             " WHERE link_type=? AND clicked_id=?",
                             (_S.LINK_MEDI, mid))
            continue
        out['bad'] += 1
        other = conn.execute(
            "SELECT COUNT(*) FROM sys_link_asset WHERE clicked_id=?"
            "   AND link_type LIKE 'MEDI%' AND link_type<>?"
            "   AND COALESCE(record_status,'LIVE')='LIVE'",
            (mid, _S.LINK_MEDI)).fetchone()[0]
        mark = '연결만' if other else '승인 내림'
        log('  x %-13s [%s] %s' % (code[:13], mark, (ti or '')[:56]))
        if dry:
            out['unlinked'] += 1
            if not other:
                out['unapproved'] += 1
            continue
        # ⚠⚠ **곡 코드를 지우지 않으면 `derive` 가 도로 잇는다**(실측 —
        #   연결을 걷었는데 재유도 뒤 12편이 그대로 있었다). 걷은 근거를
        #   `song_drop` 에 남긴다(무엇을 왜 걷었는지 되짚을 수 있게).
        d.pop('song_code', None)
        d['song_drop'] = code
        conn.execute("UPDATE sys_media_asset SET description=?"
                     " WHERE media_id=?",
                     (_js.dumps(d, ensure_ascii=False), mid))
        n = conn.execute(
            "UPDATE sys_link_asset SET record_status='HIDE'"
            " WHERE link_type=? AND clicked_id=?",
            (_S.LINK_MEDI, mid)).rowcount
        out['unlinked'] += max(0, n)
        if not other:
            conn.execute("UPDATE sys_media_asset SET is_active=0"
                         " WHERE media_id=?", (mid,))
            out['unapproved'] += 1
    if not dry:
        conn.commit()
    return out


# ── selftest ────────────────────────────────────────────────────────────────

def selftest():
    ok = [0, 0]

    def t(nm, cond, extra=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, extra if not cond else ''))

    # 곡 표
    codes = [s[0] for s in SONGS]
    t('★ 곡 코드가 겹치지 않는다', len(codes) == len(set(codes)))
    t('  곡마다 한국어 이름이 하나 이상', all(s[1] for s in SONGS))
    t('★ 한 곡에 번안 제목이 여럿일 수 있다',
      any(len(s[1]) > 1 for s in SONGS),
      [s[0] for s in SONGS if len(s[1]) > 1])
    t('★ 흔한 낱말은 영문 검색을 끈다',
      not dict((s[0], s[3]) for s in SONGS)['MY_GOD_KING'])
    t('★★ 흔한 낱말 곡은 표에 안 넣는다(실측 「비밀」이 드라마 9편을 끌고 왔다)',
      not ({n.lower() for s in SONGS for n in s[1]} & 
           {w.lower() for w in COMMON_WORD_SONGS}),
      sorted({n for s in SONGS for n in s[1]} & set(COMMON_WORD_SONGS)))

    # 파싱 — 후보를 낸다
    t('  「한글 / English」 를 읽는다',
      parse('[AGAPAO Worship] 난 언제나 예수 / Always You Jesus')[0]
      == ('난 언제나 예수', 'Always You Jesus'))
    t('  「English / 한글」 도 뒤집어 읽는다',
      parse('[AGAPAO Worship] New Thing Coming / 새 일이 일어나네')[0]
      == ('새 일이 일어나네', 'New Thing Coming'))
    t('  「한글 English」 붙은 것도', ('거룩 영원히', 'Holy Forever')
      in parse('거룩 영원히 Holy Forever | 소진영 인도 | 마커스워십'))
    t('★ 꼬리말은 곡명이 아니다(Official·Playlist)',
      not parse('[Official Lyrics] 우리 주안에서 노래하며 / Official')
      or all(p[1].lower() not in SONG_STOP
             for p in parse('어떤 찬양 모음 / CCM Playlist')))
    t('  한글만 있으면 짝이 없다', parse('구원열차') == [])

    # 문지기
    s = ('CAME_HERE_FOR', ['우리 주 안에서 노래하며', '우리 주안에서 노래하며'],
         "That's What We Came Here For", True)
    t('★ 한국어 이름이 들어 있으면 통과',
      gate('03 우리 주안에서 노래하며(Official Lyrics) | WLC20', s)
      == '우리 주안에서 노래하며')
    t('★ 띄어쓰기가 흔들려도 잡는다',
      gate('우리주안에서 노래하며 라이브', s) is not None)
    t('★ 영문 원제로도 통과',
      gate("That's What We Came Here For - Hillsong Worship", s)
      == "That's What We Came Here For")
    t('★★ 딴 곡은 막는다(실측 함정)',
      gate('Above All | Lenny LeBlanc (Lyrics)',
           ('MY_GOD_KING', ['왕이신 나의 하나님'],
            'My God You are King above all', False)) is None)
    t('  빈 제목은 안 통과', gate('', s) is None)

    # 담는 문
    src = open('db_song_collect.py', encoding='utf-8').read()
    # ⚠ 찾는 글자를 그대로 적으면 **검사 코드 자신이 걸린다**(§199차) — 조립한다
    _needle = 'INSERT INTO ' + 'sys_media_' + 'asset'
    t('★ 여기서 INSERT 하지 않는다(media_intake 한 문)', _needle not in src)
    t('★★ 언어를 짐작하지 않고 한 문에 맡긴다(중국어가 EN 으로 들어갔다)',
      'guess_lang' in src and ("else '" + "EN'") not in src)
    t('★★ 곡으로 찾은 것은 찬양으로 못 박는다(낱말 분류가 못 잡는다)',
      "media_type='WORSHIP'" in src)
    t('  검색 상한이 있다', isinstance(DAILY_MAX_SEARCH, int) and DAILY_MAX_SEARCH > 0)
    # ⚠ 이른 반환이 commit 을 건너뛰면 담은 것이 통째로 롤백된다(실측 110편)
    _seg = src[src.index('검색 상한 %d 에 닿아'):]
    t('★★ 상한에 닿아 멈출 때도 commit 한다',
      'conn.commit()' in _seg[:400] and _seg.index('conn.commit()') < _seg.index('return out'))
    # ── 곡명 수확(2026-09-09 사용자 관찰) ──────────────────────────────
    t('★ 여러 곡을 담은 제목은 곡명을 열거한다(전각 【】)',
      harvest_title('復活節敬拜特輯【我的救贖者活著 / 寶貴十架 / 聖潔的羔羊】｜讚美之泉')
      == ['我的救贖者活著', '寶貴十架', '聖潔的羔羊'])
    t('  `+` 도 곡 구분자다(아이자야씩스티원 꼴)',
      harvest_title('주를 기억하라 + 보라 너희는 두려워 말고 | 2026 Born Zeal')
      == ['주를 기억하라', '보라 너희는 두려워 말고'])
    t('  맨 앞 대괄호가 곡명인 꼴(레비스탕스)',
      harvest_title('[For Your Glory] LEVISTANCE in PRAYER ROOM') == ['For Your Glory'])
    t('  `곡명 - 사역자` 꼴(마커스워십)',
      harvest_title('축복 The Blessing - 마커스워십 Live Clip | A Key')
      == ['축복 The Blessing'])
    t('★★ 반각 `[ ]` 안 `/` 는 열거가 아니다 — 채널·갈래 표기다',
      harvest_title('[CCD농장/워십댄스/워십댄스 배우기] (요청) 언제나주만_제이어스') == [],
      harvest_title('[CCD농장/워십댄스/워십댄스 배우기] (요청) 언제나주만_제이어스'))
    t('★★ 라틴 짧은 낱말을 부분 일치로 안 본다(ver ← Everything)',
      harvest_title('내 안에 있는 것 Everything I am - 마커스워십 Live Clip')
      == ['내 안에 있는 것 Everything I am'])
    t('  꼬리 갈래 괄호를 이름에서 걷는다((live))',
      harvest_title('주님의 긍휼 (live) - LEVISTANCE') == ['주님의 긍휼'])
    t('★ 채널·사역자 이름은 곡명이 아니다',
      harvest_title('[하루예배] 무언가', drop=['하루예배']) == [])
    t('  성경 참조도 아니다',
      harvest_title('Exodus 23 - Bible Study') == []
      and harvest_title('Psalm 119 - teaching') == [])
    t('  HTML 엔티티를 푼다',
      harvest_title('[악보&amp;찬양] 무언가')
      == [] or '&amp;' not in ''.join(harvest_title('[악보&amp;찬양] 무언가')))
    t('  빈 제목은 빈 목록', harvest_title('') == [] and harvest_title(None) == [])
    # ── 문지기 다시 걸기(sweep) ───────────────────────────────────────
    import io as _io
    src = _io.open('db_song_collect.py', encoding='utf-8').read()
    t('★ sweep 이 곡 코드를 지운다(안 지우면 derive 가 도로 잇는다)',
      "d.pop('song" + "_code', None)" in src)
    t('★ sweep 은 지우지 않고 걷는다(승인 내림·HIDE)',
      'is_active=0' in src and 'DELETE' not in src.split('def sweep')[1][:2600])
    t('★ sweep 이 딴 곡으로 갈아탈 줄 안다(여러 곡 한 영상)',
      "out['moved']" in src)
    t('★ 흔한 낱말 표에 「기억하네」가 들어 있다',
      '기억하네' in COMMON_WORD_SONGS)
    t('  영문 이름은 원제로(짧으면 딴 곡을 먹는다)',
      all(s2[2] != 'Hold Me Fast' for s2 in SONGS))

    print('db_song_collect selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


def main(argv):
    if '--selftest' in argv:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(DB)
    try:
        if '--harvest' in argv:
            for nm, n in harvest_all(conn):
                print('  %3d편  %s' % (n, nm))
        elif '--suggest' in argv:
            for (ko, en), ti in suggest(conn):
                print('  %-26s ⇄ %-30s   %s' % (ko[:26], en[:30], ti))
        elif '--sweep' in argv:
            r = sweep(conn, dry='--apply' not in argv)
            print()
            print('곡 영상 %d편 · 딴 곡으로 옮김 %d · 문지기 탈락 %d'
                  ' · 걷은 연결 %d · 승인 내림 %d%s'
                  % (r['seen'], r['moved'], r['bad'], r['unlinked'], r['unapproved'],
                     '' if '--apply' in argv else '  (미적용 — --apply)'))
        elif '--collect' in argv or '--dry' in argv:
            r = collect(conn, dry='--dry' in argv)
            print()
            print('검색 %d · 본 것 %d · 문지기 통과 %d · 새로 %d편'
                  % (r.get('q', 0), r.get('seen', 0), r.get('kept', 0), r.get('new', 0)))
            print('문지기가 막은 것 %d' % r.get('skip_gate', 0))
            if r.get('topic'):
                print()
                print('★ 「- Topic」 이 알려 준 사역자(원곡·번안 실마리):')
                for code, names in sorted(r['topic'].items()):
                    print('   %-16s %s' % (code, ' · '.join(sorted(names))))
        else:
            print('사용법: --harvest | --suggest | --sweep [--apply]'
              ' | --dry | --collect | --selftest')
    finally:
        conn.close()


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    main(sys.argv[1:])
