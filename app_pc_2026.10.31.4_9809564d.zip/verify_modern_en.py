"""
verify_modern_en.py -- MODERN_EN 삽입 후 내용 검증 스크립트
Usage: python verify_modern_en.py <bcode> [commentary_id]
Default commentary_id: 5 (CLARKE)

고어체 패턴 주의:
- " ye " 는 KJV 성경 인용구 안에도 등장하므로 위양성 가능 -> 수동 확인 필요
- thee/thou/thy/hath 등은 Clarke 본문에서 현대화 대상
"""

import sqlite3
import appdb
import sys
import io

# Windows cp949 환경에서 UTF-8 출력 강제
try:  # 2026-10-29 제자리에서 — 새 래퍼를 만들면 버려지는 옛 래퍼가 진짜 출력을 닫는다
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:  # noqa: BLE001
    pass

DB_PATH = "bible_master.db"

# 확실한 고어체 (Clarke 산문에서 현대화 필수)
ARCHAIC_HARD = [
    " thee ", " thou ", " thy ", " thine ",
    " hath ", " hast ", " doth ", " dost ",
    " wilt ", " saith ", " spake ",
    " &c.", " whilst ",
]

# 위양성 가능 패턴 (KJV 인용 안에도 등장) -> 별도 표시
ARCHAIC_SOFT = [
    " ye ",
]

def check_patterns(cur, bcode, commentary_id, patterns, label):
    conditions = " OR ".join([f"body_text LIKE ?" for _ in patterns])
    params = [f"%{p}%" for p in patterns]
    cur.execute(f"""
        SELECT e.entry_id, e.chapter, substr(t.body_text, 1, 120)
        FROM sys_commentary_text t
        JOIN sys_commentary_entry e ON t.entry_id=e.entry_id
        WHERE e.bcode=? AND e.commentary_id=?
          AND t.text_variant='MODERN_EN' AND t.record_status='LIVE'
          AND ({conditions})
    """, [bcode, commentary_id] + params)
    hits = cur.fetchall()
    if hits:
        print(f"  {label}: {len(hits)}건 발견")
        for row in hits:
            print(f"    entry_id={row[0]}, chapter={row[1]}: {row[2]!r}")
    else:
        print(f"  {label}: OK")
    return hits

def run(bcode, commentary_id=5):
    conn = appdb.connect(DB_PATH)
    cur = conn.cursor()

    print(f"\n{'='*60}")
    print(f"MODERN_EN 검증: bcode={bcode}, commentary_id={commentary_id}")
    print(f"{'='*60}")

    # 1단계: 카운트
    cur.execute("""
        SELECT COUNT(*) FROM sys_commentary_text t
        JOIN sys_commentary_entry e ON t.entry_id=e.entry_id
        WHERE e.bcode=? AND e.commentary_id=?
          AND t.text_variant='MODERN_EN' AND t.record_status='LIVE'
    """, (bcode, commentary_id))
    count = cur.fetchone()[0]
    print(f"\n[1단계] 총 삽입 건수: {count}")
    if count == 0:
        print("  ERROR: 삽입된 MODERN_EN 항목이 없습니다.")
        conn.close()
        return

    # 2단계: 고어체 잔존 검사
    print(f"\n[2단계] 고어체 잔존 검사")
    hard_hits = check_patterns(cur, bcode, commentary_id, ARCHAIC_HARD,
                               "확실한 고어체 (수정 필요)")
    soft_hits = check_patterns(cur, bcode, commentary_id, ARCHAIC_SOFT,
                               "위양성 가능 패턴 'ye' (KJV 인용 포함 -- 수동 확인)")

    # 3단계: 샘플 내용 확인 (앞/중간/끝)
    print(f"\n[3단계] 샘플 내용 확인 (앞/중간/끝)")
    cur.execute("""
        SELECT e.entry_id, e.chapter, t.body_text
        FROM sys_commentary_text t
        JOIN sys_commentary_entry e ON t.entry_id=e.entry_id
        WHERE e.bcode=? AND e.commentary_id=?
          AND t.text_variant='MODERN_EN' AND t.record_status='LIVE'
        ORDER BY e.entry_id
    """, (bcode, commentary_id))
    all_rows = cur.fetchall()

    indices = [0, len(all_rows) // 2, len(all_rows) - 1]
    labels = ["첫 번째", "중간", "마지막"]
    for label, idx in zip(labels, indices):
        row = all_rows[idx]
        print(f"\n  [{label}] entry_id={row[0]}, chapter={row[1]}")
        text = row[2]
        preview = text[:300] + ("..." if len(text) > 300 else "")
        print(f"  {preview}")

    # 4단계: 길이 이상값 검사 (20자 미만)
    print(f"\n[4단계] 길이 이상값 검사 (20자 미만)")
    cur.execute("""
        SELECT e.entry_id, e.chapter, length(t.body_text), t.body_text
        FROM sys_commentary_text t
        JOIN sys_commentary_entry e ON t.entry_id=e.entry_id
        WHERE e.bcode=? AND e.commentary_id=?
          AND t.text_variant='MODERN_EN' AND t.record_status='LIVE'
          AND length(t.body_text) < 20
    """, (bcode, commentary_id))
    short_hits = cur.fetchall()
    if short_hits:
        print(f"  WARNING: 20자 미만 항목 {len(short_hits)}건 발견")
        for row in short_hits:
            print(f"  entry_id={row[0]}, chapter={row[1]}, len={row[2]}: {row[3]!r}")
    else:
        print(f"  OK: 이상값 없음")

    print(f"\n{'='*60}")
    hard_issues = len(hard_hits) + len(short_hits)
    if hard_issues == 0 and len(soft_hits) == 0:
        print("검증 완료 -- 이상 없음")
    elif hard_issues == 0:
        print(f"검증 완료 -- 확실한 오류 없음 / 'ye' 위양성 {len(soft_hits)}건 수동 확인 권장")
    else:
        print(f"검증 완료 -- {hard_issues}건 수정 필요")
    print(f"{'='*60}\n")

    conn.close()


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python verify_modern_en.py <bcode> [commentary_id]")
        sys.exit(1)
    bcode = sys.argv[1].upper()
    commentary_id = int(sys.argv[2]) if len(sys.argv) > 2 else 5
    run(bcode, commentary_id)
