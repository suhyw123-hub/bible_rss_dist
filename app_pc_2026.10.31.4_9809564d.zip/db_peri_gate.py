# -*- coding: utf-8 -*-
"""db_peri_gate.py — 페리코프 설명문(PERI_DESC) 서술 표준 검증 게이트 (영구 도구)

peri.md §2 의 규칙을 기계로 검사한다. 문서에 적어두는 것만으로는 드리프트가 멈추지
않았다(CLAUDE.md §28-11 재발원인) — 매 책 적재 직후 이 게이트를 돌린다.

사용법:
  python -X utf8 db_peri_gate.py --book 50     # 책 단위(bcode)
  python -X utf8 db_peri_gate.py --all         # PERI_DESC 보유 BODY 전체
  python -X utf8 db_peri_gate.py --selftest    # 게이트 자체 탐지력 확인(의무)
"""
import argparse
import re
import sys

import appdb

LEN_KO = (150, 350)
# EN 범위는 추측이 아니라 실측 근거로 정한다. 완성된 신약 자산의 KO:EN 길이비는
# VERS_DESC LAY 1.97 · EXPERT 2.04 · VERS_QUESTION 1.93 로 일관되게 약 2.0배다.
# KO 150~350자에 대응하는 구간에 여유를 둬 300~750자로 잡는다.
LEN_EN = (300, 750)

# ── 서사(복음서·사도행전) 전용 ─────────────────────────────────────────────
# peri.md §3. 서사는 흐르는 산문이라 문장이 길어지고 그만큼 글도 길어진다.
# 확정 샘플 5개 실측: 320~358자 / 문장 평균 40~57자.
NARRATIVE_BOOKS = {
    # 신약 서사 — 마태·마가·누가·요한·사도행전
    40, 41, 42, 43, 44,
    # ★ 구약 서사 (2026-08-04 추가, 창세기 착수 때).
    #   §3-0c 의 550~800자는 「PERI_DESC 는 VERS_DESC 의 요약」이라는 재정의에서 나온 것이라
    #   신약 전용일 이유가 없다. 창세기를 서신 기준(150~350)으로 재면 8절짜리 단락 요약이
    #   두세 문장으로 쪼그라든다. 서사인지 아닌지는 성격의 문제이지 신구약의 문제가 아니다.
    1, 2, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17,
    #   창·출·민·수·삿·룻·삼상·삼하·왕상·왕하·대상·대하·스·느·에
    27, 32,                      # 단(1~6장 궁정 서사)·욘
    # ⚠ 일부러 뺀 것 — 그 책에 닿을 때 따로 판단한다.
    #   레(3)·신(5) = 율법·설교 / 욥(18)·시(19)·잠(20)·전(21)·아(22) = 시가 /
    #   사(23)~말(39) 예언서 = 신탁이 주라 서사 기준이 맞지 않는다.
}
# PERI_DESC = 그 페리코프 절들의 VERS_DESC 를 포괄 요약한 글(2026-08-01 재정의).
# 분량은 절 수와 무관하게 일정하게 간다(사용자 결정). 승인 샘플 611자가 기준.
LEN_KO_NARR = (550, 800)
LEN_EN_NARR = (1150, 1750)   # 실측 KO:EN = 2.16 (막1장 7개), 550~800 x 2.16

# ── 율법서 전용 (2026-08-12 레위기 착수, 사용자 결정) ──────────────────────
# NARRATIVE_BOOKS 주석이 「레·신은 성격이 달라 그 책에 닿을 때 따로 판단한다」고
# 남겨 둔 자리다. 레위기에 닿아 실측하고 정했다.
#
#   레위기 페리코프 70개 · 절수 3~47(평균 12.3) · 요약 대상 VERS_DESC KO 중앙 1,759자
#   서신 기준 350자 = 원문의 20%  / 서사 기준 800자 = 45%
#
# ⚠ **어느 쪽이든 한 끝이 깨진다.** 서사 기준(550~800)을 쓰면 3~5절짜리 12개가
#   원문(436~1,004자)보다 긴 요약을 갖게 되어 **재진술이 강제된다**. 서신 기준을
#   쓰면 13·14·11장처럼 한 페리코프가 한 장을 통째로 덮는 곳에서 줄거리만 남는다.
# ⇒ 하한을 낮추고 상한은 서사에 맞춘다. 짧은 페리코프는 짧게 쓸 수 있고
#   긴 페리코프는 담을 항목을 골라 넣을 수 있다(peri.md §3-0c 「20절 이상은
#   처음부터 항목을 골라 놓고 쓴다」와 같은 방식).
# ⚠ **문장 평균 하한(AVG_SENT_MIN)은 서사에만 건다.** 율법 설명은 조문을 하나씩
#   짚으므로 짧은 문장이 유효하다 — 서사의 「흐르는 산문」 근거가 여기엔 없다.
LAW_BOOKS = {3, 5}       # 레위기 · 신명기
LEN_KO_LAW = (300, 800)
LEN_EN_LAW = (630, 1680)  # KO x 2.1

# ── 설교(강론)서 — 신명기 (2026-08-12 사용자 지시로 판단) ────────────────────
# 위 주석이 「신명기(5)는 그 책에 닿을 때 다시 판단한다」고 남겨 둔 자리다.
# 닿아서 실측했고, **분량은 율법 쪽 · 문체는 서사 쪽**으로 갈렸다.
#
#   페리코프당 원문 자수(KRV) — 신명기 693 / 중앙 549  ← 오경에서 가장 길다
#                               레위기 662/514 · 민수기 594/407 · 창세기 569/437
#   절당 자수 — 신명기 64.3  ← 66권에서 가장 길다 (창 54.1 · 레 53.9 · 민 52.1)
#
# ⚠ **서사 분량(550~800)을 쓸 수 없다.** 중앙 원문이 549자라 요약이 원문보다 길어진다
#   — 레위기에서 겪은 「재진술이 강제된다」가 그대로 재현된다. ⇒ LAW_BOOKS 에 넣었다.
# ⚠ **그러나 문체는 서사다.** 신명기는 조문을 짚는 글이 아니라 **모세의 설교**이고
#   절이 가장 길다. 짧은 문장이 끊기면 강론이 아니라 목록이 된다.
#   ⇒ 문장 평균 하한·「…라는 것입니다」·뼈대어 검사를 **서사와 같이 건다**.
#   (레위기를 뺀 근거 「조문을 하나씩 짚으므로 짧은 문장이 유효하다」가 여기엔 없다.)
SERMON_BOOKS = {5}       # 신명기. 문체 검사만 서사와 같이 받는다.

# ── 장 설명문(CHAP_DESC) — chapter.md §4 ──────────────────────────────────
# 문체 검사는 페리코프와 **하나를 공유한다**(딱딱함을 막는 규칙은 층이 달라도 같다).
# 다른 것은 분량뿐이라 kind='CHAP' 로 그 부분만 갈아 끼운다.
# 블록 3개 x 2~4문장. 사용자 결정으로 페리코프보다 길어도 된다 —
# "장별로 한 번만 읽으면 되기 때문에 부담이 덜하다"(2026-08-02).
LEN_KO_CHAP = (500, 900)
LEN_EN_CHAP = (1050, 1900)   # KO x 2.1
# 문장 평균 길이 하한 — 이 값 아래면 짧은 문장이 끊기는 글이다.
# 기존 서신 자산 실측 중앙 33자 / 서사 확정 샘플 40~57자 → 36자로 가른다.
AVG_SENT_MIN = 36
MIN_SENT_FOR_AVG = 3
# "…라는 것입니다" 를 설명 종결의 기본형으로 쓰지 않는다.
RAGO = re.compile(r'(라|다)는 것입니다')
RAGO_MAX = 2
# 접속어를 단락 진행의 뼈대로 쓰지 않는다.
SCAFFOLD = re.compile(r'(그다음에|그러고는|그러면서|이어서)')
SCAFFOLD_MAX = 2

CIRCLED = re.compile(r'[①-⑳]')
EN_NUMLIST = re.compile(r'\(\s*[1-9]\s*\)')
# 헬라어(한글) 역순 — 그리스 문자 뒤 괄호 안이 한글
GREEK_REV = re.compile(r'[Ͱ-Ͽἀ-῿]+\s*\([^)]*[가-힣][^)]*\)')
# 교단 귀속어
SECT = re.compile(r'(칼뱅|칼빈|개혁주의|개혁파|루터파|알미니안|장로교|Calvinis|Reformed theolog|Arminian)',
                  re.I)
# peri.md §2-10 쉬운 말 — 번역투/현학 표현 (확실한 것만. 오탐이 나면 목록에서 뺀다)
TRANSLATIONESE = re.compile(
    r'(에 있어서|되어지|지어지는|로 하여금|에 다름 아니|라는 점을 먼저|문맥 한가운데|'
    r'힘주어 말하는 것은|않을 수 없다|아니라 할 수 없)')
PEDANTIC_KO = re.compile(r'(담지|정위|지평 융합|층위|전유(?!물)|소여|규정성|정초|호전(?=[을를은는 ]))')
# peri.md §2-12 차분한 설명체 — 내용 대신 '중요한 게 나온다'고 알리는 예고형 문장
SIGNPOST = re.compile(r'(뜻밖|중요합니다|중요하다|핵심은|눈에 띄는 것|눈에 띈다|눈에 띕니다|눈여겨볼|그 답입니다|'
                      r'주목할 것|주목할 점|주목할 만|이 단락의 중심|재미있는 것은|특이합니다|특이하다|흥미로운)')
# ⚠ 금지어는 낱말이 아니라 구(句) 단위로 등록한다. 낱말만 넣어 생긴 오탐이 세 번 있었다 —
#   '울립니다'→계 19:6-10 / '서술이'→막 3:13-19 / '주목할'→막 4:30-34.
#   새 금지어를 추가하면 반드시 --all 로 기존 자산에 돌려 오탐을 확인할 것.
# peri.md §0 — 저자를 주어로 세운 문장(한 글에 2개까지)
AUTHOR_SUBJ = re.compile(r'(야고보|바울|요한|베드로|유다|모세|다윗)(는|가|은|도)\s')
AUTHOR_MAX = 2
# 서사(40~44)는 명단이 다르다 (2026-08-02, 사도행전 시작 전 정정).
# 이 검사는 **글 쓰는 사람을 주어로 세우는 버릇**을 막으려는 것인데, 서사에서
# 베드로·바울·모세·다윗은 저자가 아니라 **움직이는 인물**이다. 사도행전 2장은
# 베드로가 처음부터 끝까지 말하는 단락이라, 원래 명단대로 두 번으로 묶으면
# `설교가 이어집니다` 같은 문서 주어로 달아날 수밖에 없다 —
# **DOC_SUBJ 가 막으려는 바로 그 방향으로 몰아붙이는 셈이다.**
# ⇒ 서사에서는 실제로 글을 쓴 사람(복음서 기자·저자)만 센다.
#
# ⚠ 그런데 이름만으로는 못 가른다. `요한` 은 마가 1장에서 세례 요한이고
#   요한복음에서는 기자다. 이름 명단만 바꿨더니 확정 샘플과 막 1:1-11 이
#   걸렸다(자가 검사가 잡았다). ⇒ **이름 + 글 쓰는 동사**가 한 문장에
#   같이 있을 때만 센다. 인물이 무엇을 하는 문장은 자유롭게 쓴다.
NARR_AUTHOR = re.compile(r'(누가|마가|마태|요한|저자|글쓴이)(는|가|은|도)\s')
NARR_WRITE = re.compile(r'(적어|적습니다|적었|적지|씁니다|썼|기록|남깁니다|남겨|'
                        r'전합니다|밝혀 둡|덧붙입니다|묶어)')
# peri.md §3-0b ① — 내용을 말하지 않고 문서를 관찰하는 표현
# '서술이' 를 통째로 넣으면 '이름은 서술이 아니라 선언입니다' 같은 정당한 용법까지
# 잡힌다(2026-08-01 실측). 절 뒤에 붙는 '…다는 서술이' 형태로만 좁힌다.
DOC_OBSERVE = re.compile(r'(배치를|배치가|다는 [^ ]*\s?서술이|이 문장이 놓|그냥 지나칠 수 없|'
                         r'눈여겨볼 만|방향이 여기 드러)')
# peri.md §0 — 요점을 말해 놓고 그것이 요점이라고 다시 알리는 메타 문장
META_COMMENT = re.compile(r'(말하려는 것이|말하려는 바는|말하고자 하는|하려는 말은|'
                          r'이 대목이 말하는 것은|여기서 하려는 말)')
# 독자에게 해석을 시키는 은유 요약
# 열거식 목록은 새로 만들어 낸 은유를 막지 못한다(구조적 한계, peri.md §중단기록).
# 그래도 실제로 지적받은 것은 반드시 등록해 같은 표현이 재발하지 않게 한다.
# 아래 2026-08-01 추가분은 마가 1장 작성에서 실제로 잡힌 것들이다.
# ⚠ `문을 여는` 이 `말문을 여는 방식`(행 13:16)을 잡았다 — 말문을 열다는 그냥
#   말을 꺼낸다는 뜻의 평범한 관용구다. 앞 글자로 갈라낸다.
METAPHOR = re.compile(r'(높이 올라가|두 무대|무대가 겹|그림이 (크게 )?열리|(?<!말)문을 여는 |'
                      r'노래처럼|숨을 선택하는|예고편|한 폭의|'
                      r'겹으로 울리|겹으로 울립|길목에 서|끝을 스스로 그|두 번 뚫리|두 번 뚫립|'
                      r'말이 떨어집니다|어둠이 숨어|눈이 .{0,4}갈리|위에 얹힌|'
                      r'두 축이|밀고 가|씨줄|날줄|물결처럼|메아리)')

# peri.md §2-11 구어체 — 평서체 종결(~이다/~한다/~된다)을 잡는다.
# 경어체는 "니다."/"까요?"/"세요." 로 끝나므로 그 앞 글자로 구분한다.
PLAIN_ENDING = re.compile(r'(?<![니습])다[.!?]')
# 기준 확정(2026-07-31 §0) 이전에 작성된 책. 사용자 결정으로 수정하지 않으므로
# 문체 계열 검사(경어체·예고형·은유·메타)에서 제외한다. 분량·번역투·교단중립 등
# 나머지 검사는 그대로 적용된다.
LEGACY_STYLE_BOOKS = {50, 51}   # 빌립보서, 골로새서
POLITE_EXEMPT_BOOKS = LEGACY_STYLE_BOOKS

PEDANTIC_EN = re.compile(
    r'(ontolog\w*|soteriolog\w*|christolog\w*|hermeneutic\w*|epistemolog\w*|'
    r'adumbrat\w*|free-standing theological|salvific|pericopal)', re.I)


# ── 분석체 어휘 (peri.md §2-10, 2026-08-02 사용자 반려 후 신설) ────────────
# 사용자 지적: "이해하기 어려운 표현이 많다. 자기지칭? 우리 안의 절차도 관계로
# 그려집니다? 사람이 설명하는 것처럼 서술하라."
#
# 원인은 명확하다. PERI_DESC 의 재료인 절별 VERS_DESC(EXPERT)가 논문 문체로
# 쓰여 있고(`자기 규정이 제시된다` · `층위 이동이 주목된다` · `판별 기준을
# 확인해야 한다`), 그것을 읽고 요약하다 보니 그 어휘가 그대로 따라 나왔다.
# 실측(1000자당 출현): 기준 일반설명(LAY) 0.7 · 마가 1.0 · 요한 2.2(최악 7.5).
#
# 두 겹으로 막는다. 평신도가 쓰지 않는 말은 아예 금지하고, 그 밖의 분석체
# 명사는 밀도로 제한한다. 밀도 상한 3.0 은 실측 분포에서 잡았다.
# ⚠ 낱말이 아니라 조사까지 붙여 등록한다. `함의` 만 넣었더니 확정 승인 샘플의
#   `죄 사함의 세례` 가 걸렸다(2026-08-02). peri.md 가 이미 세 번 기록해 둔
#   오탐 유형이며 이번이 네 번째다. 자가 검사가 잡았다.
JARGON_HARD = re.compile(
    r'(자기 지칭|자기 규정|자기 선언|판별 기준|서사적|'
    r'층위[가를로에]|논증[이을은의]|함의[가를는한]|귀결[이을로된]|병치[되가를]|수렴[하되이]|'
    r'정합[성적]|소급[하되]|반향[하이을])')
# ⚠ 자연스러운 우리말까지 잡으면 고치다가 오히려 나빠진다. `규정이` 는 음식 규정 ·
#   제사 규정 · 신명기의 규정에서, `계열` 은 다윗 계열에서, `항목` 은 목록의 항목에서
#   정상적으로 쓰인다. 그래서 명사형은 빼고 **문서를 분석하는 서술어**만 남긴다.
JARGON_SOFT = re.compile(
    r'(배치가|배치는|배치를|배치입니다|배치이다|'
    r'구조입니다|구조가 닫|구조가 성립|구조로 제시|구조를 보면|'
    r'규정됩니다|규정된다|진술됩니다|진술이 됩니다|서술됩니다|'
    r'어휘가|어휘를|전제가|국면이|제시됩니다|확장됩니다|기능합니다)')
JARGON_PER_1000 = 3.0

# ── 문서가 주어인 문장 (peri.md §3-2 표, 2026-08-02 두 번째 반려 후 신설) ──
# 사용자: "아무리 강조해도 계속 기계적이고 수동태 현학적 표현들을 남발하고 있다."
#
# 수동태 종결(~됩니다/~집니다)로 재 보니 가르지 못했다. 기준 원고(VERS_DESC LAY)도
# 중앙 22% · 최대 86% 라 상한을 걸면 멀쩡한 우리말까지 잡는다.
# peri.md §3-2 가 이미 진짜 기준을 적어 두었다 — **주어가 사람인가 문서인가.**
#
# 실측(1000자당 `추상명사+이/가`, 2026-08-02)
#   기준 일반설명(LAY)  0.78   <- 목표. 400자 이상 항목의 중앙값은 0.0
#   마가 PERI 2.30 · 요한 PERI 2.91
#
# ⚠ 2026-08-02 정정 — 여기 적었던 "재료 절별설명(EXPERT) 0.70, 그러므로 재료에서
#   옮아온 것이 아니라 내가 만든 버릇" 은 **표본을 잘못 잡은 결론이다.**
#   그 0.70 은 EXPERT 전권 평균이고 그 절반이 서신서(0.82)라 복음서가 묻혔다.
#   실제로 읽으며 쓴 재료를 다시 재면 요한 11~13장 7.75 · 14~21장 6.3 · 마가 4.53 이다.
#   재료는 기준의 8~10 배로 딱딱하다. 재료 탓이 아니라던 진단이 틀렸다.
#   교훈: **corpus 평균으로 결론 내지 말 것.** 내가 실제로 읽은 구간만 잘라서 잰다.
DOC_SUBJ = re.compile(
    r'(예고|질문|응답|반응|선언|진술|서술|지시|명령|조건|근거|대비|구조|배치|'
    r'표현|초점|논점|쟁점|평가|해석|판단|결론|전환|확장|반복|강조|규정|비유|'
    r'약속|경고|고백|요구|요청|논의|기록|장면|사건|결과|원인|목적|의도|기능|'
    r'순서|위치|시점|범위|어휘|낱말|문장|단락)(?:이|가)\s')
# 상한 보정(2026-08-02). 5.0 은 최악만 걷어낼 뿐 평균을 못 내렸다 —
# 소급 교정 뒤에도 마가 1.99 · 요한 2.39 로 기준(0.78)의 3배였다.
# 3.5 에서 기준 원고 초과 5% · 서신 PERI 는 애초에 이 검사 대상이 아니다(서사 전용).
DOC_SUBJ_PER_1000 = 3.5

# ── 주석 장치 (2026-08-02 신설, 서사 KO 전용) ─────────────────────────────
#
# 문체 검사를 세 번 통과시켰는데도 사용자가 "여전히 딱딱하다" 고 했다. 그래서
# 문장 층위 지표를 전부 다시 쟀더니 **내 글이 이미 기준과 같거나 더 낫다** —
# 명사형 종결 9.4%(기준 12.9%) · 문장 평균 39자(기준 38.9자) · 문서 주어 0.91(기준 0.80).
# 즉 지금까지의 지표로는 더 잡을 것이 없었다. 남은 차이는 다른 층위에 있었다.
#
# 실측(1000자당, 2026-08-02)
#                     기준 LAY   내 마가   내 요한
#   학계 장치            0.03      0.44     0.64   <- 최대 21배
#   문서 지칭            0.36      1.62     1.34   <- 4배
#
# **원인은 문장이 아니라 내용이었다.** 재료(EXPERT)가 "두 견해가 갈린다 · 논의되어
# 왔다 · 이 복음서는" 으로 가득한데, 나는 그 *내용까지* 페리코프 설명문으로 옮겨 왔다.
# 학설을 소개하는 글은 문장을 아무리 다듬어도 사람이 들려주는 이야기가 되지 못한다.
# 앞선 세 번의 교정이 증상만 옮겨 다닌 이유가 이것이다(분석체 -> 문서 주어 -> 짧은 문장).
#
# ⇒ 이 검사는 **표현이 아니라 무엇을 담을지**를 제한한다. 견해가 갈리면 본문이
#   받쳐 주는 쪽 하나만 쓰거나 아예 빼라. 학설 소개는 절별 EXPERT 의 몫이다.
#
# ⚠ 낱말이 아니라 구(句) 로 등록한다 — peri.md 가 네 번 기록한 오탐 유형이다.
#   그리고 **이번에 다섯 번째로 또 당했다**(2026-08-02). 처음에 `두고 (갈|다투)` 를
#   넣었더니 `가져갈 것과 두고 갈 것을`(막 6장 파송)과 `누가 크냐를 두고 다투었고`
#   (제자들의 다툼)가 걸렸다. 학설과 아무 상관이 없는 문장이다.
#   `제시됩니다` 도 뺐다 — 이미 JARGON_SOFT 가 잡으므로 중복이다.
#   ⇒ 앞뒤로 학설을 가리키는 말이 붙은 형태만 남긴다.
COMMENTARY = re.compile(
    # `견해를` 도 뺐다 — "서기관들은 앞선 랍비들의 견해를 인용하며"(막 1:22)가 걸렸다.
    r'(견해가|견해도|견해와|다투어 온|논의되어 (왔|온)|지적이 (있|되)|지적되어|'
    # ⚠ 여섯 번째 오탐(2026-08-02). `보는 쪽이` 가 `알아보는 쪽이 없었습니다`(행 7:25)를
    #   잡았다. 학설을 가리키려면 앞에 `…로/으로` 가 붙는다. 조사까지 넣어 좁힌다.
    r'(로|으로) 보는 쪽이|(로|으로) 읽는 쪽이|읽기도 합니다|으로 읽습니다|로 읽힙니다|읽는 견해|'
    r'입장도|널리 제시)')
# 기준 원고 1343건에서 16회(0.03/1000) — 오탐 거의 없음. 상한 0.5 는 기준의 16배로
# 넉넉히 잡은 값이며, 그래도 마가+요한 243개 중 34개(14%)가 걸린다.
COMMENTARY_PER_1000 = 0.5

# 문서를 가리키며 설명하는 버릇. `이 복음서는` 이 압도적이다.
# 앞 장·다음 장 같은 정상적인 상호 참조는 넣지 않는다(오탐).
DOC_REF = re.compile(r'(이 복음서|이 책은|이 책이|본문이|본문은|본문에는)')
# ⚠ 처음에 1.0 으로 걸었더니 **확정 샘플이 걸렸다**(700자에 `이 책은` 한 번 = 1.3).
#   자가 검사가 잡았다. 한 번 언급하는 것은 정상이고 되풀이하는 것이 버릇이다.
#   기준 원고 78건의 p99 가 1.95 이므로 2.0 이면 1회 통과 · 2회부터 실패.
#
# ⚠⚠ 그런데 **실패로 걸면 안 된다 — 규칙 둘이 서로 싸운다.**
#   `이 복음서에서 여기 한 번뿐입니다` 를 사람 말로 고치면 `요한은 여기서 한 번만
#   씁니다` 가 되는데, 그러면 **저자 주어 상한(2개)** 에 걸린다. 두 표현은 같은
#   행동(글 쓰는 일을 이야기하기)의 두 형태인데 한쪽만 막으면 다른 쪽으로 샌다.
#   실제로 걸린 30여 곳 가운데 상당수는 읽어 보면 딱딱하지 않았다.
#   ⇒ 지금은 **경고만** 한다. 되풀이되면 저자 주어와 하나의 예산으로 합칠 것.
DOC_REF_PER_1000 = 2.0

# ── 서술 균형 (2026-08-02 신설, 서사 KO 전용, 경고만) ─────────────────────
#
# 사용자 반려(사도행전 1~9장): *"구절의 내용을 줄줄이 재정리하는 느낌이다. 신앙적·
# 신학적 시사점에 대한 기술이 부족하다."* 실측으로 그대로 확인됐다.
#
#   1000자당            배경 설명   까닭·의미   사건 나열
#     기준 일반설명(LAY)     0.17      2.80       0.31
#     마가                 0.53      0.80       0.39
#     요한                 0.39      1.40       1.25
#     사도행전               0.19      1.28       1.13   <- 배경 최저 · 나열 최다
#
# **사건 나열은 기준의 3~4배이고 까닭·의미는 절반 이하다.** 사건은 이미 절별설명에
# 절마다 적혀 있으므로, 페리코프에서 그것을 다시 늘어놓으면 자리만 차지한다.
# peri.md §3-2 ④ 가 "나열만 하지 말고 왜 그런지 한 겹을 붙이라" 고 이미 적어 두었으나
# 게이트가 재지 않아 지켜지지 않았다.
#
# ⚠ 실패가 아니라 **경고**로 둔다. 이 세 지표는 낱말 목록으로 재는 거친 대리 지표라
#   상한을 걸면 낱말을 바꿔치기하는 쪽으로 도망가게 된다. 숫자를 눈앞에 띄워
#   쓰는 사람이 판단하게 하는 것이 목적이다.
BACKGROUND = re.compile(r'(당시|그 시절|그때는|그 무렵|본래|원래|여기던|불리던|'
                        r'쓰던 말|하던 일이었|관습|여겨지던|시절에는|그 시대)')
MEANING = re.compile(r'(까닭|때문입니다|때문이었|셈입니다|셈이었|뜻입니다|뜻이었|'
                     r'무게가|무게입니다|이유입니다|이유였)')
EVENTSEQ = re.compile(r'(그러고는|그러자|이어\s|그다음|그러더니|곧바로|그리고 나)')
# 목표: 배경 0.3+ · 의미 1.5+ · 나열 1.0-
#
# ⚠ **경고로 걸지 않는다.** 목표치로 경고를 걸었더니 마가 94% · 요한 99% · 행 100%,
#   기준을 크게 낮춰도 82~100% 가 걸렸다. 늘 울리는 경고는 신호가 아니라 소음이다.
#   대신 `db_peri_load --check` 가 **항목마다 세 수치를 찍는다.** 고칠지 말지는
#   숫자를 보고 사람이 정한다. 낱말 목록으로 재는 거친 대리 지표라 상한을 걸면
#   낱말을 바꿔치기하는 쪽으로 도망가게 되는 것도 이유다.
BALANCE = (('배경 설명', BACKGROUND, 0.30, 'min'),
           ('까닭·의미', MEANING, 1.50, 'min'),
           ('사건 나열', EVENTSEQ, 1.00, 'max'))

# ── 본문 어휘 겹침 (peri.md §3-0) ──────────────────────────────────────────
# 2자 이상 한글 토큰 기준. 서사(40~44)의 KO 에만 적용한다 —
# 서신 398개는 §3-0 재정의 이전 기준이라 중앙 28%·최대 59%로 척도가 다르다.
# 실측(2026-08-02, 서사 74개): 중앙 9% · 최대 17% · 13% 초과 8건 · 15% 초과 2건.
# 긴 페리코프는 고유명사가 늘어 구조적으로 올라간다(막9:1 13절 17% — 모세·엘리야·초막).
# 그래서 13%는 '낱말을 보고 판단하라'는 경고이고, 18% 초과만 실패로 잡는다
# (peri.md 기록: 반려 초고가 16·18·20%, 반려된 막1장 구작성분이 31%).
OVERLAP_WARN = 13
OVERLAP_FAIL = 18
KO_TOK = re.compile(r'[가-힣]{2,}')


def overlap_pct(conn, desc, a, b):
    src = ' '.join(r[0] or '' for r in conn.execute(
        "SELECT verse_text FROM bible_content WHERE verse_id BETWEEN ? AND ? "
        "AND version_code='KRV'", (a, b)))
    toks = set(KO_TOK.findall(desc or ''))
    if not toks:
        return 0, []
    hit = sorted(t for t in toks if t in src)
    return round(100 * len(hit) / len(toks)), hit


def overlap_scan(conn, rows, vids=None):
    """서사·율법 KO 겹침 검사. (fails, warns) 반환 — warns 는 PASS/FAIL 을 바꾸지 않는다.

    vids: {pericope_id: (start_vid, end_vid)}. 없으면 DB 에서 조회한다.

    ⚠ **율법서를 2026-08-12 에 더했다.** 그전에는 NARRATIVE_BOOKS 뿐이라 레위기 겹침이
      화면에 찍히기만 하고 판정되지 않았다 — 레 2장 첫 초안이 20%(FAIL 기준 18%)인 채로
      PASS 로 나왔다. peri.md 가 민 30~33장에서 「조문·명단 구간은 바꿔 쓸 낱말이 적어
      33%까지 오른다」고 기록해 둔 바로 그 자리라, 검사가 가장 필요한 곳이 빠져 있었다.
    """
    fails, warns = [], []
    scope = NARRATIVE_BOOKS | LAW_BOOKS
    need = [r for r in rows if r[4] == 'KO' and _bcode_of(r[1]) in scope]
    if not need:
        return fails, warns
    if vids is None:
        ids = {r[0] for r in need}
        vids = {p: (a, b) for p, a, b in conn.execute(
            'SELECT pericope_id, start_vid, end_vid FROM sys_pericope_asset '
            'WHERE pericope_id IN (%s)' % ','.join('?' * len(ids)), tuple(ids))}
    for pid, ref, _tko, _ten, lang, _v, txt in need:
        if pid not in vids:
            continue
        a, b = vids[pid]
        pct, hit = overlap_pct(conn, txt, a, b)
        tag = f'peri {pid} [{ref}] KO'
        if pct > OVERLAP_FAIL:
            fails.append((tag, f'본문 어휘 겹침 {pct}% (상한 {OVERLAP_FAIL}) — KRV 문장을 '
                               f'그대로 옮긴 자리가 있다. 평이한 현대어로 (peri.md §3-0/§2-10)\n'
                               f'      겹친 낱말: {" · ".join(hit)}'))
        elif pct > OVERLAP_WARN:
            warns.append((tag, f'본문 어휘 겹침 {pct}% (권장 {OVERLAP_WARN} 이하) — '
                               f'고유명사 때문이면 그대로 두고, KRV 어투를 옮긴 자리면 고칠 것\n'
                               f'      겹친 낱말: {" · ".join(hit)}'))
    return fails, warns


def _bcode_of(ref):
    """load() 가 만드는 ref 문자열 'bcode ch:v-ch:v' 에서 bcode 를 뽑는다."""
    try:
        return int(str(ref).split()[0])
    except (ValueError, IndexError):
        return None


# check() 가 남기는 경고. 실패는 아니지만 사람이 읽어 볼 자리다(문서 지칭 등).
# 반환값을 튜플로 바꾸면 호출부를 다 고쳐야 해서 모듈 변수로 둔다. 호출 때마다 비운다.
LAST_WARNS = []


def check(conn, rows, exempt=False, kind='PERI'):
    """kind='PERI'(페리코프) | 'CHAP'(장 설명문). 갈리는 것은 분량 기준과 표시 이름뿐이고
    문체 검사는 전부 공유한다 — 딱딱함을 막는 규칙은 층이 달라도 같기 때문이다."""
    bad = []
    LAST_WARNS.clear()
    for pid, ref, title_ko, title_en, lang, variant, txt in rows:
        t = (txt or '').strip()
        tag = f'{"chap" if kind == "CHAP" else "peri"} {pid} [{ref}] {lang}'
        narrative = _bcode_of(ref) in NARRATIVE_BOOKS
        law = _bcode_of(ref) in LAW_BOOKS
        # 설교서(신명기)는 **분량은 율법, 문체는 서사**다 — 두 기준이 갈린다.
        prose = narrative or _bcode_of(ref) in SERMON_BOOKS
        # 기준 확정 이전 책(§LEGACY_STYLE_BOOKS)은 행 단위로 문체 검사에서 뺀다.
        # 예전에는 --book 으로 그 책을 콕 집었을 때만 면제돼서, --all 이 늘 그 책들
        # 때문에 FAIL 로 끝났다. peri.md 가 요구하는 "새 금지어를 --all 로 돌려
        # 오탐 확인" 이 그래서 불가능했다.
        row_exempt = exempt or _bcode_of(ref) in LEGACY_STYLE_BOOKS

        def fail(msg):
            bad.append((tag, msg))

        def warn(msg):
            LAST_WARNS.append((tag, msg))

        if variant is not None:
            fail(f'text_variant 가 NULL 이 아님 ({variant}) — 티어 금지')
        if kind == 'CHAP':
            lo, hi = LEN_KO_CHAP if lang == 'KO' else LEN_EN_CHAP
        elif narrative:
            lo, hi = LEN_KO_NARR if lang == 'KO' else LEN_EN_NARR
        elif law:
            lo, hi = LEN_KO_LAW if lang == 'KO' else LEN_EN_LAW
        else:
            lo, hi = LEN_KO if lang == 'KO' else LEN_EN
        if not (lo <= len(t) <= hi):
            fail(f'분량 {len(t)}자 (허용 {lo}~{hi})')
        if CIRCLED.search(t):
            fail('동그라미 번호 사용')
        if lang == 'EN' and EN_NUMLIST.search(t):
            fail('(1)(2) 형식 번호 사용')
        if GREEK_REV.search(t):
            fail('헬라어(한글) 역순 표기')
        if SECT.search(t):
            fail(f'교단 귀속어: {SECT.search(t).group(0)}')
        m = TRANSLATIONESE.search(t)
        if m:
            fail(f'번역투 표현: "{m.group(0)}" (peri.md §2-10)')
        m = (PEDANTIC_KO if lang == 'KO' else PEDANTIC_EN).search(t)
        if m:
            fail(f'현학적 표현: "{m.group(0)}" (peri.md §2-10)')
        if lang == 'KO' and not row_exempt:
            hits = PLAIN_ENDING.findall(t)
            if hits:
                fail(f'평서체 종결 {len(hits)}회 — 경어체(~습니다)로 (peri.md §2-11)')
        if lang == 'KO' and not row_exempt:
            m = SIGNPOST.search(t)
            if m:
                fail(f'예고형 표현: "{m.group(0)}" — 내용을 바로 말할 것 (peri.md §2-12)')
            m = METAPHOR.search(t)
            if m:
                fail(f'은유 요약: "{m.group(0)}" — 평범한 말로 (peri.md §2-12)')
            m = META_COMMENT.search(t)
            if m:
                fail(f'메타 문장: "{m.group(0)}" — 요점만 말하고 끝낼 것 (peri.md §0)')
            m = DOC_OBSERVE.search(t)
            if m:
                fail(f'문서 관찰 표현: "{m.group(0)}" — 문서가 아니라 내용을 말할 것 '
                     f'(peri.md §3-0b)')
            sents = re.split(r'(?<=[.!?])\s+', t)
            if narrative:
                n_auth = sum(1 for x in sents
                             if NARR_AUTHOR.search(x) and NARR_WRITE.search(x))
            else:
                n_auth = sum(1 for x in sents if AUTHOR_SUBJ.search(x))
            if n_auth > AUTHOR_MAX:
                fail(f'저자 주어 문장 {n_auth}개 (허용 {AUTHOR_MAX}) — 내용을 직접 서술할 것 '
                     f'(peri.md §0)')
        # ── 흐르는 산문 문체 검사 (peri.md §3) — 서사 + 설교서 ───────────
        if prose and lang == 'KO' and not row_exempt:
            sents = [x for x in re.split(r'(?<=[.!?])\s+', t) if x.strip()]
            if len(sents) >= MIN_SENT_FOR_AVG:
                avg = len(t) / len(sents)
                if avg < AVG_SENT_MIN:
                    fail(f'문장 평균 {avg:.1f}자 (하한 {AVG_SENT_MIN}) — 짧은 문장이 끊긴다. '
                         f'연결어미로 이어 붙일 것 (peri.md §3-2)')
            n = len(RAGO.findall(t))
            if n > RAGO_MAX:
                fail(f'"…라는 것입니다" {n}회 (허용 {RAGO_MAX}) — 설명 종결의 기본형으로 '
                     f'쓰지 말 것 (peri.md §3-2)')
            n = len(SCAFFOLD.findall(t))
            if n > SCAFFOLD_MAX:
                fail(f'접속 뼈대어 {n}회 (허용 {SCAFFOLD_MAX}) — 내용 자체가 이어지게 쓸 것 '
                     f'(peri.md §3-2)')
            m = JARGON_HARD.search(t)
            if m:
                fail(f'분석체 낱말: "{m.group(0)}" — 평신도가 쓰는 말로 바꿀 것 '
                     f'(peri.md §2-10)')
            ds = DOC_SUBJ.findall(t)
            per1000 = len(ds) / len(t) * 1000 if t else 0
            if per1000 > DOC_SUBJ_PER_1000:
                fail(f'문서가 주어인 문장 {len(ds)}회 · 1000자당 {per1000:.1f} '
                     f'(상한 {DOC_SUBJ_PER_1000}) — 사람이 무엇을 하는지로 쓸 것 '
                     f'(peri.md §3-2)\n      해당: {" · ".join(sorted(set(ds)))}')
            cm = [m.group(0) for m in COMMENTARY.finditer(t)]
            per1000 = len(cm) / len(t) * 1000 if t else 0
            if per1000 > COMMENTARY_PER_1000:
                fail(f'주석 장치 {len(cm)}회 · 1000자당 {per1000:.1f} '
                     f'(상한 {COMMENTARY_PER_1000}) — 학설을 소개하지 말 것. 본문이 받쳐 '
                     f'주는 쪽 하나만 쓰거나 빼라 (peri.md §3-0c)\n'
                     f'      해당: {" · ".join(sorted(set(cm)))}')
            dr = [m.group(0) for m in DOC_REF.finditer(t)]
            per1000 = len(dr) / len(t) * 1000 if t else 0
            if per1000 > DOC_REF_PER_1000:
                warn(f'문서를 가리키는 말 {len(dr)}회 · 1000자당 {per1000:.1f} — 읽어 보고 '
                     f'딱딱하면 고칠 것. 저자 주어로 바꾸면 그 상한에 걸리니 아예 빼는 쪽이 낫다 '
                     f'(peri.md §3-0c)\n      해당: {" · ".join(sorted(set(dr)))}')
            hits = JARGON_SOFT.findall(t)
            per1000 = len(hits) / len(t) * 1000 if t else 0
            if per1000 > JARGON_PER_1000:
                fail(f'분석체 어휘 {len(hits)}회 · 1000자당 {per1000:.1f} '
                     f'(상한 {JARGON_PER_1000}) — 논문이 아니라 사람이 설명하듯 쓸 것 '
                     f'(peri.md §2-10)\n      해당 낱말: {" · ".join(sorted(set(hits)))}')
        # 제목 재진술 — 제목을 그대로 옮겨 적고 시작
        title = (title_ko if lang == 'KO' else title_en) or ''
        title = title.strip().rstrip('.')
        if title and len(title) >= 6 and t[:len(title) + 12].find(title) >= 0:
            fail(f'첫머리에 제목 재진술: "{title}"')
        # 본문 재진술 — 큰따옴표 인용이 문단 첫머리에 오는 형태
        if re.match(r'^\s*[""\"]', t):
            fail('본문 인용으로 시작(재진술 금지)')
    return bad


def load(conn, where, params):
    return conn.execute(f"""
        SELECT p.pericope_id,
               b1.bcode || ' ' || b1.chapter || ':' || b1.verse || '-' || b2.chapter || ':' || b2.verse,
               (SELECT title FROM sys_text_asset WHERE clicked_id=p.pericope_id
                 AND text_type='PERI_TITLE' AND lang_code='KO' LIMIT 1),
               (SELECT title FROM sys_text_asset WHERE clicked_id=p.pericope_id
                 AND text_type='PERI_TITLE' AND lang_code='EN' LIMIT 1),
               t.lang_code, t.text_variant, t.contents
          FROM sys_pericope_asset p
          JOIN bible_index b1 ON b1.verse_id = p.start_vid
          JOIN bible_index b2 ON b2.verse_id = p.end_vid
          JOIN sys_text_asset t ON t.clicked_id = p.pericope_id AND t.text_type='PERI_DESC'
         WHERE p.peri_type='BODY' AND COALESCE(t.record_status,'LIVE')='LIVE' AND {where}
         ORDER BY p.start_vid, t.lang_code""", params).fetchall()


def pair_check(rows):
    """KO·EN 쌍 누락 검사"""
    seen = {}
    for pid, ref, *_rest in rows:
        lang = _rest[2]
        seen.setdefault((pid, ref), set()).add(lang)
    return [(f'peri {pid} [{ref}]', f'언어 누락 — 보유 {sorted(lg)}')
            for (pid, ref), lg in seen.items() if lg != {'KO', 'EN'}]


# 서사 승인 샘플(막 1:1-11 계열) — 오탐 확인용. 새 분량 기준의 기준선.
GOOD_NARRATIVE = (
    # peri 7425(막 1:1-11) 교정본과 동일. 기준 샘플이 낡으면 게이트가 자기 기준에
    # 걸리므로, 표준을 고칠 때 이 문자열도 함께 갱신한다.
    '마가는 족보도 탄생 이야기도 없이 한 줄 선언으로 책을 엽니다. 여기 쓰인 복음이라는 말은 본래 임금이 즉위했거나 싸움에서 이겼을 때 알리던 소식이라, 이 책은 교훈집이 아니라 승전보로 시작합니다. 이어 인용된 옛 예언에서 사자가 예비할 길은 본래 여호와의 길이었는데, 마가는 그것을 예수께 이르는 길과 같게 봅니다.\n\n그 길을 예비한 사람이 세례 요한입니다. 낙타털 옷과 가죽 띠는 엘리야의 차림 그대로여서 옷차림이 그가 누구인지 알립니다. 그가 요구한 회개는 뉘우치는 감정이 아니라 걸음의 방향을 바꾸는 일이었고, 그가 베푼 세례는 본래 밖에서 들어온 사람에게 하던 예식이었습니다. 그것을 유대인에게 요구했다는 것은 혈통만으로 충분하지 않다는 선언이었습니다. 요한은 자기 일의 한계를 스스로 밝혔습니다. 자기는 물로 씻길 뿐이고 속을 새롭게 하는 일은 뒤에 오시는 분의 몫이라 했습니다.\n\n그렇게 준비된 자리에 예수께서 나사렛에서 오셔서 세례를 받으십니다. 죄 없으신 분이 죄 사함의 세례를 받으신 것은 자기 죄를 씻으신 것이 아니라 죄인의 줄에 서신 것입니다. 물에서 올라오실 때 하늘이 갈라지는데, 마가가 쓴 말은 찢는다는 뜻입니다. 하늘을 가르고 내려오시기를 부르짖던 이사야의 기도가 여기서 응답되고, 같은 낱말이 책 끝에서 성소 휘장이 찢어질 때 다시 나옵니다. 하늘이 찢어지며 사역이 시작되고 휘장이 찢어지며 끝납니다. 그리고 소리가 들립니다. 너는 내 사랑하는 아들이라. 이 말은 왕의 즉위를 노래한 시편과 고난받는 종을 말한 이사야를 합친 것이고, 아직 아무 일도 시작하지 않으신 때에 그렇게 불리십니다.')


# 장 설명문 확정 샘플(요 9장, 패턴 ① A+B+C) — chapter.md §7 과 같은 글이다.
# 표준을 고치면 이 문자열도 함께 갱신할 것(GOOD_NARRATIVE 와 같은 이유).
GOOD_CHAPTER = (
    '한 사건이 통째로 한 장을 이루는 드문 경우입니다. 나면서 못 보던 사람이 눈을 뜨고(1~12절), '
    '그 일이 안식일 심문으로 번져 끝내 회당에서 쫓겨나며(13~34절), 밀려난 그를 예수께서 '
    '찾아가십니다(35~41절). 짜임에서 특별한 것은 가운데 스물두 절 동안 예수께서 무대에 '
    '계시지 않다는 점인데, 고침받은 사람이 혼자 서서 답하는 그 구간이 장의 절반을 넘습니다.\n\n'
    '눈이 열리는 이야기이면서 동시에 눈이 닫히는 이야기입니다. 못 보던 사람은 심문을 한 번 '
    '거칠 때마다 그분을 부르는 이름이 올라가고, 잘 본다고 여기던 이들은 같은 사실 앞에서 '
    '점점 더 완강해집니다. 마지막에 놓인 판정이 그 둘을 갈라 세우는데, 못 보는 것 자체는 '
    '죄로 지목되지 않고 본다고 하는 그 주장이 문제로 지목됩니다.\n\n'
    '읽기 전에 세 가지를 알아 두면 본문이 달리 보입니다. 첫째, 그 시대는 고난을 누군가의 '
    '죄와 곧장 이어서 이해했고 제자들의 첫 물음이 거기서 나옵니다. 둘째, 안식일에 금지된 '
    '서른아홉 가지 일 가운데 반죽하기가 들어 있어서, 굳이 진흙을 개어 바르신 방식 자체가 '
    '쟁점을 만듭니다. 셋째, 회당에서 쫓겨난다는 것은 예배 자리만 잃는 일이 아니라 생계와 '
    '혼인까지 걸린 문제였습니다. 부모가 아들 편에 서지 못하고 당사자에게 떠넘긴 까닭이 '
    '여기 있습니다.')


def selftest(conn):
    """탐지력 확인 — 일부러 위반한 문자열이 반드시 걸려야 한다."""
    NARR = '41 4:35-4:41'    # 마가복음 — 서사 전용 검사가 걸리는 ref
    # ⚠ 야고보서(59). 예전에는 빌립보서(50)를 썼는데 그 책이 LEGACY_STYLE_BOOKS 라
    #   행 단위 면제가 걸리면서 **문체 검사 7종이 통째로 건너뛰어졌다**(2026-08-02 발견).
    #   면제가 --all 을 살리려고 행 단위로 바뀐 뒤로 자가 검사가 그 7종을 못 재고 있었다.
    #   ⇒ 표본 ref 에는 절대 면제 대상 책을 쓰지 말 것.
    EPI = '59 1:1-1:8'       # 야고보서 — 서사 검사가 걸리지 않고 면제도 아닌 ref
    cases = [
        (EPI, 'KO', '①' + '가' * 200, '동그라미'),
        (EPI, 'KO', '짧다', '분량'),
        (EPI, 'KO', '가' * 200 + ' λόγος(말씀)', '헬라어 역순'),
        (EPI, 'KO', '칼뱅주의 관점에서 ' + '가' * 200, '교단 귀속어'),
        (EPI, 'KO', '"태초에 하나님이" ' + '가' * 200, '인용 시작'),
        (EPI, 'KO', '이 단락은 문맥 한가운데 놓여 있다. ' + '가' * 190, '번역투'),
        (EPI, 'KO', '형편의 호전을 구하지 않는다. ' + '가' * 190, '현학적(KO)'),
        (EPI, 'EN', 'This is a free-standing theological treatise. ' + 'a ' * 200, '현학적(EN)'),
        (EPI, 'KO', '이것은 중요한 대목이다. ' + '가' * 190, '평서체 종결'),
        (EPI, 'KO', '바울의 반응이 뜻밖입니다. ' + '가' * 190, '예고형'),
        (EPI, 'KO', '가장 높이 올라가는 대목입니다. ' + '가' * 190, '은유 요약'),
        (EPI, 'KO', '바울이 말하려는 것이 그것입니다. ' + '가' * 190, '메타 문장'),
        (EPI, 'KO', ('야고보는 이렇게 말합니다. ' * 3) + '가' * 150, '저자 주어 남용'),
        (EPI, 'KO', '광야에서 지낸 사십 일은 여러 겹으로 울립니다. ' + '가' * 180, '은유(신규 등록)'),
        (EPI, 'KO', '그 배치를 그냥 지나칠 수 없습니다. ' + '가' * 190, '문서 관찰'),
        # ── 서사 전용 3종 ────────────────────────────────────────────────
        (NARR, 'KO', ('배를 탑니다. 바람이 붑니다. 물이 찹니다. 제자들이 깨웁니다. '
                      '예수님이 일어나십니다. 바람을 꾸짖으십니다. 바다가 잔잔합니다. '
                      '제자들이 두려워합니다. 서로 묻습니다. 저가 뉘신가 합니다. '
                      '아무도 답하지 못합니다. 배가 건너갑니다. 날이 저뭅니다. '
                      '무리가 흩어집니다. 그 밤이 지납니다. 아침이 옵니다. 다시 떠납니다. '
                      '길이 이어집니다. 사람들이 모입니다. 이야기가 퍼집니다. ') * 3,
         '문장 평균 짧음'),
        (NARR, 'KO', ('배를 타고 건너가는 길에 큰 광풍이 일어나 물이 배에 가득 차게 '
                      '되었다는 것입니다. ' * 3) +
                     ('제자들이 깨우면서 우리가 죽게 된 것을 돌아보지 않으시느냐고 물었고 '
                      '예수님이 바람을 꾸짖으시자 바다가 곧 아주 잔잔해졌습니다. ' * 8),
         '"…라는 것입니다" 남용'),
        (NARR, 'KO', ('배를 타고 건너가는 길에 큰 광풍이 일어나 물이 배에 차오르기 '
                      '시작했습니다. 그다음에 제자들이 깨우면서 우리가 죽게 된 것을 돌아보지 '
                      '않으시느냐고 물었습니다. 그러고는 예수님이 일어나 바람을 꾸짖으시며 '
                      '바다에게 잠잠하라고 하셨습니다. 이어서 바다가 아주 잔잔해지자 제자들이 '
                      '도리어 심히 두려워하였습니다. 그러면서 저가 뉘기에 바람과 바다라도 '
                      '순종하느냐고 서로 말하였습니다. ') * 3, '접속 뼈대어 남용'),
    ]
    ok = True
    for ref, lang, txt, label in cases:
        bad = check(conn, [(0, ref, '제목', 'Title', lang, None, txt)])
        hit = bool(bad)
        print(f'  [{"PASS" if hit else "FAIL"}] {label} 탐지 → {bad[0][1] if bad else "못 잡음"}')
        ok = ok and hit
    g1 = check(conn, [(0, EPI, '감사와 기도', 'Thanksgiving', 'KO', None,
                       '이 단락은 ' + '가' * 200 + ' 보여 줍니다.')])
    print(f'  [{"PASS" if not g1 else "FAIL"}] 정상 문장 오탐 없음(서신) {g1 or ""}')
    g2 = check(conn, [(0, NARR, '풍랑을 잔잔케 하심', 'Calming the Storm', 'KO', None,
                       GOOD_NARRATIVE)])
    print(f'  [{"PASS" if not g2 else "FAIL"}] 확정 샘플 오탐 없음(서사) {g2 or ""}')

    # ── 장 설명문(kind='CHAP') ────────────────────────────────────────────
    CHAP = '43 9:1-9:41'
    c1 = check(conn, [(43009, CHAP, None, None, 'KO', None, GOOD_CHAPTER)], kind='CHAP')
    print(f'  [{"PASS" if not c1 else "FAIL"}] 확정 샘플 오탐 없음(장) {c1 or ""}')
    # 분량 기준이 실제로 갈리는지 — 페리코프에서는 통과하는 850자가 장에서도 통과하고,
    # 페리코프 상한(800)을 넘는 글이 장에서 걸리지 않아야 kind 분기가 산 것이다.
    long_ok = check(conn, [(0, CHAP, None, None, 'KO', None,
                            GOOD_CHAPTER + '이어지는 이야기가 여기서 한 번 더 이어집니다. ' * 3)],
                    kind='CHAP')
    short = check(conn, [(0, CHAP, None, None, 'KO', None, '짧습니다.')], kind='CHAP')
    print(f'  [{"PASS" if not long_ok else "FAIL"}] 장 상한 900자까지 허용 {long_ok or ""}')
    print(f'  [{"PASS" if short else "FAIL"}] 장 분량 미달 탐지 → {short[0][1] if short else "못 잡음"}')
    return ok and not g1 and not g2 and not c1 and not long_ok and bool(short)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--book', type=int)
    ap.add_argument('--all', action='store_true')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    conn = appdb.connect('bible_master.db')

    if a.selftest:
        print('=== 게이트 자가 탐지력 ===')
        sys.exit(0 if selftest(conn) else 1)

    if a.book:
        rows = load(conn, 'b1.bcode = ?', (a.book,))
        scope = f'bcode {a.book}'
    else:
        rows = load(conn, '1=1', ())
        scope = '전체'

    if not rows:
        print(f'{scope}: PERI_DESC 없음'); sys.exit(0)

    exempt = bool(a.book) and a.book in LEGACY_STYLE_BOOKS
    if exempt:
        print(f'  (bcode {a.book} 은 기준 확정 이전 작성분 — 문체 검사 제외)')
    ov_fail, ov_warn = overlap_scan(conn, rows)
    bad = check(conn, rows, exempt) + pair_check(rows) + ov_fail
    n_peri = len({r[0] for r in rows})
    print(f'{scope}: 페리코프 {n_peri}개 / {len(rows)}행 검사')
    for tag, msg in ov_warn:
        print(f'  ! {tag}: {msg}')
    if not bad:
        print('게이트 PASS — 위반 0건'
              + (f' (겹침 경고 {len(ov_warn)}건)' if ov_warn else ''))
        sys.exit(0)
    print(f'게이트 FAIL — 위반 {len(bad)}건')
    for tag, msg in bad:
        print(f'  {tag}: {msg}')
    sys.exit(1)


if __name__ == '__main__':
    main()
