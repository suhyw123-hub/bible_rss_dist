# -*- coding: utf-8 -*-
"""book_link.py — **도서·설교 편이 어느 구절에 걸리나** 단일 문 (2026-10-13 신설 · 영구 · `--selftest`).

사용자 지시(docs/1.txt 72-2) — 「Our Daily Homily 는 어떤 책/장/절을 클릭해도 항상 표시되고 있다
… 실제로 장 단위로 모든 장을 연결했는가?」 → 「**도서 설교 원본에 따라서 구절만 연결 또는 장연결을
결정하라**」.

★★★ 편의 `start_vid~end_vid` 는 **두 가지 뜻**으로 쓰여 왔다.
  | 원본 | 그 범위의 뜻 | 구절에 거는 기준 |
  |---|---|---|
  | 마이어 『Our Daily Homily』 | **읽을 장**(묵상 플랜이 그 장을 읽힌다) · 글은 **주제 구절 하나**를 붙잡고 쓴다 | **주제 구절만** (`KEY_ONLY`) |
  | 스펄전 『다윗의 보고』 | 시편 한 편 **통째의 강해** | 범위(장) 그대로 |
  | 설교집·묵상집(한 절 본문) | 설교 본문 한 절 | 그 절(범위 = 한 절) |
  | 클레멘스·헤르마스(편집 배정 2~6절) · 스펄전 은혜 (롬 8:33-34) | 다루는 본문 단락 | 범위 그대로 |
  ⇒ 범위를 바꾸면 **플랜·읽는 화면의 「장 전체」** 가 깨진다(그 범위는 읽을 장이다). 그래서
    **데이터는 그대로 두고 「구절에 거는 기준」만** 원본마다 정한다 — 그것이 이 모듈이다.

⚠ 주제 구절은 `key_verse_ref` 의 **장:절**(언어 무관 · 책은 `start_vid` 가 안다). 장만 적힌 편은
  절을 모르므로 **범위(장)로 물러난다** — 지어내지 않는다(`db_book_linkbasis` 가 원본 스캔에서
  되살린 것만 절로 걸린다).
⚠ 화면마다 SQL 을 다시 쓰지 않는다 — 한 곳만 빠지면 그 화면에서 마이어가 다시 장 전체에 뜬다.
"""
import verse_range as _vr

#: 주제 구절에만 거는 원본(책 코드) — 까닭은 머리글 표.
KEY_ONLY = ('MEYER_ODH',)

#: `key_verse_ref` 끝의 「장:절」 — 「Matthew 1:21」 → 「1:21」
_TAIL = "substr({u}.key_verse_ref, length(rtrim({u}.key_verse_ref,'0123456789:'))+1)"


def key_vid_sql(u='bu'):
    """그 편 주제 구절의 `verse_id` SQL 조각(인자 없음) — 절을 모르면 NULL."""
    t = _TAIL.format(u=u)
    return ("(SELECT k.verse_id FROM bible_index s0 JOIN bible_index k ON k.bcode=s0.bcode"
            " AND k.chapter=CAST(substr({t},1,instr({t},':')-1) AS INTEGER)"
            " AND k.verse=CAST(substr({t},instr({t},':')+1) AS INTEGER)"
            " WHERE s0.verse_id={u}.start_vid AND instr({t},':')>0)").format(t=t, u=u)


def _is_key_book(a):
    return "%s.book_code IN (%s)" % (a, ','.join("'%s'" % c for c in KEY_ONLY))


def hit_sql(u='bu', a='ba'):
    """「이 편이 이 절에 걸리나」 SQL 조각 → 인자 `hit_args(vid)`(넷).

    ⚠ `a` 는 `sys_book_asset` 별칭이다 — 부르는 쪽이 JOIN 해 둔다.
    """
    kv = key_vid_sql(u)
    return ("(CASE WHEN %s AND %s IS NOT NULL THEN %s=? ELSE (%s.start_vid=? OR (%s)) END)"
            % (_is_key_book(a), kv, kv, u, _vr.covers_sql(u, 'start_vid', 'end_vid')))


def hit_args(vid):
    return [vid, vid] + _vr.covers_args(vid)


def anchor_sql(u='bu', a='ba'):
    """그 편이 구절에 거는 자리(SELECT 칸 둘) — 주제 구절이면 (k, k), 아니면 (start, end)."""
    kv = key_vid_sql(u)
    cond = "%s AND %s IS NOT NULL" % (_is_key_book(a), kv)
    return ("CASE WHEN %s THEN %s ELSE %s.start_vid END, "
            "CASE WHEN %s THEN %s ELSE COALESCE(NULLIF(%s.end_vid,0),%s.start_vid) END"
            % (cond, kv, u, cond, kv, u, u))


def selftest():
    import appdb
    ok = []

    def ck(c, m):
        ok.append(bool(c))
        print(('PASS ' if c else 'FAIL ') + m)

    c = appdb.connect()
    q = ("SELECT bu.unit_id FROM sys_book_unit bu JOIN sys_book_asset ba ON ba.book_id=bu.book_id"
         " WHERE bu.record_status='LIVE' AND bu.start_vid IS NOT NULL AND " + hit_sql())

    def vid(b, ch, v):
        return c.execute('SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?',
                         (b, ch, v)).fetchone()[0]
    mt1 = c.execute("SELECT bu.unit_id FROM sys_book_unit bu JOIN sys_book_asset ba ON ba.book_id=bu.book_id"
                    " WHERE ba.book_code='MEYER_ODH' AND bu.key_verse_ref='Matthew 1:21'").fetchone()
    if mt1:
        on = {r[0] for r in c.execute(q, hit_args(vid(40, 1, 21)))}
        off = {r[0] for r in c.execute(q, hit_args(vid(40, 1, 3)))}
        ck(mt1[0] in on, '마이어 마 1장 편 — 주제 구절(마 1:21)에 걸린다')
        ck(mt1[0] not in off, '마이어 마 1장 편 — 족보(마 1:3)에는 안 걸린다')
    tod = c.execute("SELECT bu.unit_id FROM sys_book_unit bu JOIN sys_book_asset ba ON ba.book_id=bu.book_id"
                    " WHERE ba.book_code='SPURGEON_TOD' AND bu.start_vid=?", (vid(19, 23, 1),)).fetchone()
    if tod:
        ck(tod[0] in {r[0] for r in c.execute(q, hit_args(vid(19, 23, 4)))},
           '다윗의 보고 시 23편 — 범위(장) 그대로 23:4 에도 걸린다')
    # 장만 적힌 마이어 편은 범위로 물러난다
    ch_only = c.execute("SELECT bu.unit_id, bu.start_vid, bu.end_vid FROM sys_book_unit bu JOIN sys_book_asset ba"
                        " ON ba.book_id=bu.book_id WHERE ba.book_code='MEYER_ODH' AND bu.record_status='LIVE'"
                        " AND bu.key_verse_ref NOT LIKE '%:%' LIMIT 1").fetchone()
    if ch_only:
        ck(ch_only[0] in {r[0] for r in c.execute(q, hit_args(ch_only[2]))},
           '절을 모르는 마이어 편 — 장으로 물러난다(지어내지 않는다)')
    # 아가 6:14(vid 31113) 끝 이형이 계시록을 덮지 않는다
    ck(not {r[0] for r in c.execute(q, hit_args(vid(66, 1, 1)))} & {
        r[0] for r in c.execute("SELECT unit_id FROM sys_book_unit bu JOIN bible_index b ON b.verse_id=bu.start_vid"
                                " WHERE b.bcode=22")}, '아가 편이 계시록에 안 걸린다')
    an = c.execute("SELECT " + anchor_sql() + " FROM sys_book_unit bu JOIN sys_book_asset ba"
                   " ON ba.book_id=bu.book_id WHERE bu.unit_id=?", (mt1[0],)).fetchone() if mt1 else None
    if an:
        ck(an[0] == an[1] == vid(40, 1, 21), '자리 칸 = 주제 구절 한 절')
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
