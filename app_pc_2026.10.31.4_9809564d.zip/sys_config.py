import tkinter as tk
from tkinter import ttk, messagebox, colorchooser
import sqlite3
import appdb
import os

class SettingsApp(tk.Tk):
    def __init__(self, db_path="bible_master.db"):
        super().__init__()
        self.db_path = db_path
        self.title("⚙️ Matrix 시스템 환경 설정")
        self.geometry("1150x850") 
        
        # 데이터 매핑용 딕셔너리
        self.font_options = ["맑은 고딕", "나눔고딕", "본고딕", "Arial", "Consolas"]
        self.size_options = [str(i) for i in range(10, 32, 2)]
        self.version_map = {}   # {성경버전명: 코드}
        self.lang_map = {}      # {표시용문구: 코드}
        
        self.v1_color_hex = "#0000FF"
        
        # 1. UI 뼈대 구축 (화면 먼저 출력)
        self.setup_ui()
        
        # 2. 데이터 로드 (정렬 및 명칭 병기 로직 포함)
        self.safe_init_data()

    def setup_ui(self):
        """요청하신 패널 순서: 1. 언어 -> 2. 성경버전 -> 3. 스타일 -> 4. 미리보기"""
        main_paned = tk.PanedWindow(self, orient=tk.HORIZONTAL, bg="#DCDDE1", sashwidth=4)
        main_paned.pack(fill="both", expand=True)

        # 좌측: 설정 영역
        left_area = tk.Frame(main_paned)
        main_paned.add(left_area, width=500)
        
        canvas = tk.Canvas(left_area)
        scrollbar = ttk.Scrollbar(left_area, orient="vertical", command=canvas.yview)
        self.scroll_frame = tk.Frame(canvas, padx=15, pady=15)
        
        self.scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.scroll_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # [1] 언어 설정 패널 (알파벳 순 + 병기 표시)
        p_lang = tk.LabelFrame(self.scroll_frame, text=" 1. 시스템 언어 설정 (Language) ", padx=10, pady=10, font=("맑은 고딕", 10, "bold"))
        p_lang.pack(fill="x", pady=5)
        self.lang_combo = ttk.Combobox(p_lang, state="readonly")
        self.lang_combo.pack(fill="x", padx=5)

        # [2] 성경 버전 설정 패널 (알파벳 순 정렬)
        p_ver = tk.LabelFrame(self.scroll_frame, text=" 2. 성경 버전 설정 (기본 버전) ", padx=10, pady=10, font=("맑은 고딕", 10, "bold"))
        p_ver.pack(fill="x", pady=5)

        tk.Label(p_ver, text="V1 (기본 버전):").pack(anchor="w", padx=5)
        self.v1_combo = ttk.Combobox(p_ver, state="readonly")
        self.v1_combo.pack(fill="x", padx=5, pady=(0, 5))
        # (V2 대조 버전 — 폐기. 비교 버전은 사용자 앱 환경설정의 '비교 버전'으로 일원화)

        # [3] 폰트 및 스타일 설정 패널
        p_font = tk.LabelFrame(self.scroll_frame, text=" 3. 폰트 및 스타일 설정 ", padx=10, pady=10, font=("맑은 고딕", 10, "bold"))
        p_font.pack(fill="x", pady=5)

        # 스타일 구성 (그리드 정렬)
        for i, (label, prefix) in enumerate([("V1 스타일", "v1")]):
            tk.Label(p_font, text=label).grid(row=i*2, column=0, sticky="w", padx=5, pady=(5 if i>0 else 0))
            
            f_cb = ttk.Combobox(p_font, values=self.font_options, width=18)
            f_cb.grid(row=i*2+1, column=0, padx=5, pady=2)
            setattr(self, f"{prefix}_font", f_cb)
            
            s_cb = ttk.Combobox(p_font, values=self.size_options, width=5)
            s_cb.grid(row=i*2+1, column=1, padx=5)
            setattr(self, f"{prefix}_size", s_cb)
            
            sw = tk.Label(p_font, width=2, relief="ridge")
            sw.grid(row=i*2+1, column=2, padx=2)
            setattr(self, f"{prefix}_swatch", sw)
            
            tk.Button(p_font, text="색상", command=lambda n=i+1: self.pick_color(n)).grid(row=i*2+1, column=3)

        # 저장 버튼
        tk.Button(self.scroll_frame, text="💾 모든 설정 저장 및 적용", command=self.save_settings, 
                  bg="#27AE60", fg="white", font=("맑은 고딕", 11, "bold"), pady=10).pack(fill="x", pady=20)

        # [4] 미리보기 패널 (우측)
        right_area = tk.Frame(main_paned, bg="white", padx=20, pady=20)
        main_paned.add(right_area)
        tk.Label(right_area, text=" 4. 성경 버전 대비 미리보기 (Preview) ", font=("맑은 고딕", 12, "bold"), bg="white").pack(anchor="w", pady=(0, 10))
        self.preview_text = tk.Text(right_area, font=("맑은 고딕", 12), padx=15, pady=15, relief="flat", highlightthickness=1, highlightbackground="#DCDDE1")
        self.preview_text.pack(fill="both", expand=True)

    def safe_init_data(self):
        try:
            self.load_languages()
            self.load_versions()
            self.load_settings()
            self.refresh_preview()
        except Exception as e:
            print(f"데이터 로드 실패: {e}")

    def load_languages(self):
        """영문명(현지명) 병기 및 알파벳 순 정렬"""
        try:
            conn = appdb.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("SELECT lang_code, lang_name_en, lang_name_local FROM sys_language ORDER BY lang_name_en ASC")
            rows = cur.fetchall()
            display_list = []
            for code, en, local in rows:
                display_str = f"{en} ({local})"
                display_list.append(display_str)
                self.lang_map[display_str] = code
            self.lang_combo['values'] = display_list
            conn.close()
        except Exception as e:
            print(f"Language Load Error: {e}")

    def load_versions(self):
        """성경 버전 알파벳 순 정렬 (NT_ONLY/OT_ONLY 배지 포함)"""
        _badge = {'NT_ONLY': ' [NT전용]', 'OT_ONLY': ' [OT전용]'}
        try:
            conn = appdb.connect(self.db_path)
            cur = conn.cursor()
            cur.execute(
                "SELECT version_code, version_name, coverage_scope "
                "FROM bible_version ORDER BY version_name ASC"
            )
            rows = cur.fetchall()
            v_list = []
            for code, name, cov in rows:
                display = name + _badge.get(cov or 'FULL', '')
                v_list.append(display)
                self.version_map[display] = code
            self.v1_combo['values'] = v_list
            conn.close()
        except Exception as e:
            print(f"Version Load Error: {e}")

    def load_settings(self):
        """[오류 수정] DB 설정을 UI에 반영"""
        try:
            conn = appdb.connect(self.db_path)
            cur = conn.cursor()
            cur.execute("SELECT config_key, config_value FROM sys_config")
            cfg = {k: v for k, v in cur.fetchall()}
            conn.close()

            # 언어 설정 반영
            saved_lang_code = cfg.get("ui_language", "EN")
            for display_name, code in self.lang_map.items():
                if code == saved_lang_code:
                    self.lang_combo.set(display_name)
                    break

            # V1 상세 설정 반영
            self._apply_config_to_ui(cfg, "v1")
        except: pass

    def _apply_config_to_ui(self, cfg, prefix):
        """[중요] SyntaxError 지점 수정 완료"""
        # 성경 버전 콤보 세팅
        code = cfg.get(f"{prefix}_code")
        if code:
            for name, c in self.version_map.items():
                if c == code:
                    getattr(self, f"{prefix}_combo").set(name)
                    break
        
        # 폰트 및 색상 세팅
        getattr(self, f"{prefix}_font").set(cfg.get(f"{prefix}_font", "맑은 고딕"))
        getattr(self, f"{prefix}_size").set(cfg.get(f"{prefix}_size", "12"))
        
        # 색상 값 가져오기 (메서드 누락 수정)
        color = cfg.get(f"{prefix}_color", "#0000FF" if prefix=="v1" else "#008000")
        setattr(self, f"{prefix}_color_hex", color)
        getattr(self, f"{prefix}_swatch").config(bg=color)

    def save_settings(self):
        """설정을 sys_config에 저장"""
        lang_code = self.lang_map.get(self.lang_combo.get(), "EN")
        data = {
            "ui_language": lang_code,
            "v1_code": self.version_map.get(self.v1_combo.get(), ""),
            "v1_font": self.v1_font.get(), "v1_size": self.v1_size.get(), "v1_color": self.v1_color_hex,
        }
        try:
            conn = appdb.connect(self.db_path)
            cur = conn.cursor()
            for k, v in data.items():
                cur.execute("INSERT OR REPLACE INTO sys_config (config_key, config_value) VALUES (?, ?)", (k, v))
            conn.commit()
            conn.close()
            messagebox.showinfo("성공", "설정이 저장되었습니다.")
            self.refresh_preview()
        except Exception as e:
            messagebox.showerror("오류", f"저장 실패: {e}")

    def pick_color(self, num):
        color = colorchooser.askcolor()[1]
        if color:
            p = f"v{num}"
            setattr(self, f"{p}_color_hex", color)
            getattr(self, f"{p}_swatch").config(bg=color)
            self.refresh_preview()

    def refresh_preview(self):
        self.preview_text.config(state="normal")
        self.preview_text.delete("1.0", tk.END)
        for i in [1]:
            p = f"v{i}"
            font_info = (getattr(self, p+"_font").get(), int(getattr(self, p+"_size").get() or 12))
            color_info = getattr(self, p+"_color_hex")
            self.preview_text.tag_configure(p, font=font_info, foreground=color_info)
            v_name = getattr(self, p+"_combo").get() or f"Version {i}"
            self.preview_text.insert(tk.END, f"[{v_name}]\n태초에 하나님이 천지를 창조하시니라. (Genesis 1:1)\n\n", p)
        self.preview_text.config(state="disabled")

if __name__ == "__main__":
    app = SettingsApp()
    app.mainloop()