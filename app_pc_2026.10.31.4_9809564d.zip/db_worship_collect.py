# -*- coding: utf-8 -*-
"""찬양 자동수집 — **모든 언어를 돌아가며** 한 문 (2026-09-11 신설·영구).

사용자 지시 — 「언어별로 **일일이 언어와 콤보를 선택**해야 한다. 그런데 콤보
하나당 서너곡만 나올 때가 있다. **한번에 모든 언어를 로테이션 방식으로** 수집
하는 것이 좋겠다. **빠짐없이 수집할 때마다 직전 수집어를 기억**하도록 하면 된다.
그리고 **이 기능도 자동설정**하자」 · 「**일반찬양 수집**도 찬양수집기 화면에
배치하자. 기능은 자동크롤러를 활용하되, **옵션 설정을 차별화**하자」.

★★★ **왜 손으로 고르면 안 되는가 — 실측이 답했다**(2026-09-11):
    찬양 검색어 **75개 중 59개(79%)가 한 번도 안 돌았다.**
    돈 것은 **한국어 16개뿐**이고 **나머지 열 언어는 0회**다.
  ⇒ 사람이 콤보를 고르는 얼개에서는 **늘 쓰던 것만** 돈다. 기계가 돌아가며
    뽑아야 한다.

★★★ **갈래 둘 — 묻는 것이 다르다.**
    `PLAYLIST` 연속듣기 묶음  — 「찬양 연속듣기」·「1 hour worship」
    `SONG`     일반 찬양     — 「워십 라이브」·「CCM」·「찬송가」
  ⚠ **분야(`domain`)를 나누지 않는다** — 둘 다 `WORSHIP` 이라야
    `media_exclude` 의 찬양 면제 19낱말이 그대로 듣는다(§237차 ②).
    갈래는 **칸 하나**(`kind`)로 가른다.

★ **차례는 `db_media_attempt.arrange` 가 정한다** — 구절·용어 수집기와 **같은
  문**이다(§241차 ⑲). 묶음이 **언어**라 한 바퀴에 언어마다 한 자리씩 돈다.
  ⚠ **정경 순서·언어 차례로 줄 세우지 않는다** — 그러면 앞 언어만 돈다.

⚠ **담는 문은 `media_intake.admit` 하나다**(§237차 ③) — 여기서 따로 담지
  않는다. 쇼츠·이단·거르는 말이 그 문에만 있기 때문이다.
⚠ **`domain='WORSHIP'` 을 반드시 준다** — 안 주면 `worship song`·`ccm` 이
  오프토픽에 걸려 **정당한 찬양 14%가 죽는다**(§237차 ① 실측).

CLI
  python db_worship_collect.py --selftest
  python db_worship_collect.py --plan            # 다음에 돌 검색어만 본다(쿼터 0)
  python db_worship_collect.py --run --kind SONG --n 10
"""
from __future__ import annotations

import io
import sys

import appdb

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

DB = 'bible_master.db'
TBL = 'sys_mine_keyword'

#: 검색어 갈래 — **분야가 아니라 갈래다**(셋 다 `domain='WORSHIP'`)
#: ★ `ARTIST` = **사역자 이름**(2026-09-26 · 1.txt 17번 1)). 규칙이 둘 다르다 —
#:   ⓐ **이름이 제목·채널에 실제로 있는 것만 담는다** ⓑ **유형을 안 못 박는다**.
KINDS = (('PLAYLIST', '연속듣기'), ('SONG', '일반 찬양'),
         ('ARTIST', '사역자'))
#: 사역자 갈래 — 이름이 걸려야 담고, 유형은 분류기가 정한다
KIND_ARTIST = 'ARTIST'
#: 씨앗으로 쓸 이름의 최소 글자 — 짧은 이름은 아무 데나 걸린다(§195차 「엘」)
ARTIST_MIN_LEN = 3
KIND_LABEL = dict(KINDS)
KIND_DEFAULT = 'PLAYLIST'
#: 분야 — 이 문이 도는 두 분야 (2026-09-16 · 1.txt 16번 「성경듣기 / 찬양」).
#:   찬양은 갈래 둘(위)을 함께 돌고, 성경듣기는 갈래가 없다(한 덩어리).
#:   ⚠ 분야 값은 `media_intake.admit(domain=)` 과 `media_type` 에 그대로 쓴다.
#: ★ 2026-10-23 성지·유적 답사(SITE) — 사용자 「성지유적 유투브 수집분야를 열어야 한다」. 검색어로 모으고 유형은 SITE 로 못 박는다(아래 run).
DOMAINS = (('WORSHIP', '찬양'), ('READING', '성경듣기'), ('PRAYER', '기도'), ('SITE', '성지·유적'))
DOMAIN_LABEL = dict(DOMAINS)

#: 검색 한 번의 비용(YouTube `search.list`)
UNITS_PER_QUERY = 100
#: 한 번에 돌 검색어 수 — 기본값. 10개면 1,000 units(키 하나 하루 10,000)
DEFAULT_N = 10
#: 검색어마다 받는 편 수
#: ⚠ **비용은 결과 수와 무관하다** — 1개든 50개든 100 units(2026-09-17 점검). 25 → **50**(최대).
#:   여기는 `order='date'` 라 뒤쪽도 앞쪽과 같은 최신분이므로 깎을 까닭이 없다.
DEFAULT_PER = 50

#: 검색어마다 **어디까지 봤나**(쪽 토큰) — 다시 누르면 다음 쪽
PAGE_KEY = 'WORSHIP_FIND_PAGE'


def ensure(conn):
    """`kind` 칸을 만든다(멱등).

    ⚠ 옛 줄은 전부 **연속듣기**다 — 그 탭에서 만들어진 것이기 때문이다.
    """
    cols = [r[1] for r in conn.execute('PRAGMA table_info(%s)' % TBL)]
    if 'kind' not in cols:
        conn.execute("ALTER TABLE %s ADD COLUMN kind TEXT" % TBL)
    conn.execute("UPDATE %s SET kind=? WHERE COALESCE(domain,'')='WORSHIP'"
                 "   AND (kind IS NULL OR kind='')" % TBL, (KIND_DEFAULT,))
    return True


def keywords(conn, kind=None, langs=None, only_on=True, domain='WORSHIP'):
    """검색어 → [(kw_id, lang, kw, n_run, last_run)]. `domain` = 찬양 | 성경듣기.

    ⚠ **지정(`enabled`)된 것만** 낸다 — 꺼 둔 것을 돌면 사람이 끈 뜻이 없어진다.
    ⚠ 갈래(`kind`)는 **찬양에만** 있다 — 성경듣기에서는 무시한다.
    """
    ensure(conn)
    # ⚠ `sys_mine_keyword` 에는 **상태 칸이 없다**(실측) — 지우면 줄이 없어지는
    #   표다. 있는 DB 에서만 본다(옛·새 DB 를 함께 견딘다).
    w = ["COALESCE(domain,'')=?"]  # status-ok: 그 표에 상태 칸이 없다
    a = [(domain or 'WORSHIP').upper()]
    if 'record_status' in [r[1] for r in conn.execute(
            'PRAGMA table_info(%s)' % TBL)]:
        w.append("COALESCE(record_status,'LIVE')='LIVE'")
    if kind and (domain or 'WORSHIP').upper() == 'WORSHIP':
        w.append("COALESCE(kind,?)=?")
        a += [KIND_DEFAULT, kind]
    if only_on:
        w.append("COALESCE(enabled,0)=1")
    if langs:
        w.append("lang IN (%s)" % ','.join('?' * len(langs)))
        a += list(langs)
    return [tuple(r) for r in conn.execute(
        "SELECT kw_id, lang, kw, COALESCE(n_run,0), COALESCE(last_run,'')"
        "  FROM %s WHERE %s" % (TBL, ' AND '.join(w)), a)]


def artist_forms(conn, kw):
    """그 사역자 이름의 **다른 언어 표기까지** → set.

    ★★ KO 이름 하나로 재면 영문 제목의 `Bethel Music`·`Chris Tomlin`·
      `Hillsong` 을 통째로 놓친다(실측 0편 → 78편). 씨앗에 적힌 이름으로
      사역자를 찾아 **그 사람의 이름 전부**를 쓴다.
    ⚠ 못 찾으면 **적힌 이름 하나**를 그대로 쓴다(지어내지 않는다).
    ⚠ 띄어쓰기를 뗀 꼴도 함께 본다 — 제목은 `#다윗과요나단` 처럼 붙여 쓴다.
    """
    import db_worship_artist as WA
    kwn = (kw or '').strip()
    out = {kwn} if kwn else set()
    try:
        for aid, in conn.execute(
                "SELECT artist_id FROM %s"
                " WHERE COALESCE(record_status,'LIVE')='LIVE'" % WA.TBL):
            ns = [v for v in WA.names_of(conn, aid).values() if v]
            if any((v or '').strip() == kwn for v in ns):
                out |= {v.strip() for v in ns if v}
                break
    except Exception:
        pass
    out |= {v.replace(' ', '') for v in out}
    return {v for v in out if len(v) >= ARTIST_MIN_LEN}


def name_hit(title, channel, forms):
    """제목·채널에 그 이름이 **실제로 있나** → bool.

    ⚠ 낱말 경계를 보는 `contains_exact` 를 쓴다 — 글자 맞춤으로 재면
      「교회에서」의 `에서` 같은 것이 걸린다(§256차 ⑳ ⓑ).
    """
    import db_song_match as SM
    hay = '%s%s%s' % (title or '', chr(10), channel or '')
    return any(SM.contains_exact(hay, f) for f in (forms or ()))


def seed_artists(conn, on_featured=True, langs=('KO',)):
    """사역자 이름을 **씨앗으로 담는다**(멱등) → dict.

    ★ 전문찬양팀만 **켠 채** 담고 나머지는 **꺼 둔 채** 담는다 — 실측이
      전문팀에서만 났다(씨앗 하나 100 units 에 이름 걸림 21.2편). 나머지
      77팀은 사람이 화면에서 켠다.
    ⚠ **짧은 이름은 안 담는다**(`ARTIST_MIN_LEN`) — 아무 데나 걸린다.
    ⚠ **이미 있는 줄은 안 건드린다** — 사람이 켜고 끈 것을 되돌리지 않는다.
    """
    import db_worship_artist as WA
    ensure(conn)
    feat = WA.featured(conn)
    add = skip = 0
    for aid, in conn.execute(
            "SELECT artist_id FROM %s"
            " WHERE COALESCE(record_status,'LIVE')='LIVE'" % WA.TBL):
        on = 1 if (on_featured and aid in feat) else 0
        # ★ **이름이 있는 언어마다** 한 줄 — 그래야 그 나라 말로 찾는다.
        for lg, nm in sorted(WA.names_of(conn, aid).items()):
            nm = (nm or '').strip()
            if len(nm) < ARTIST_MIN_LEN:
                skip += 1
                continue
            # ⚠ 이 표의 유일 열쇠는 **`(lang, kw)`** 다 — 분야가 달라도
            #   같은 낱말이면 못 넣는다(COMMON 채널 발굴 씨앗과 겹친다).
            #   남의 줄은 **안 건드리고** 건너뛴다.
            if conn.execute(
                    "SELECT 1 FROM %s WHERE lang=? AND kw=?"
                    % TBL, (lg, nm)).fetchone():
                skip += 1
                continue
            conn.execute(
                "INSERT INTO %s (lang, kw, enabled, n_run, n_seen, n_new,"
                "  domain, kind, note) VALUES (?,?,?,0,0,0,'WORSHIP',?,?)"
                % TBL, (lg, nm, on, KIND_ARTIST, '사역자 이름 씨앗'))
            add += 1
    conn.commit()
    return {'add': add, 'skip': skip}


def round_n(rows):
    """**한 바퀴 = 언어 수** — 언어를 늘리면 저절로 따라온다.

    ⚠ 숫자를 못 박으면(10) 언어가 열하나인 지금 **한 언어가 늘 빠진다**.
    """
    return len({r[1] for r in rows}) or DEFAULT_N


def next_keywords(conn, kind=None, n=None, langs=None, domain='WORSHIP'):
    """**다음에 돌 검색어** n개 — 언어를 돌아가며 · 오래 안 돈 것부터.

    ★★★ 차례는 `db_media_attempt.arrange` 가 정한다 — 구절·용어 수집기와
      **같은 문**이다(§241차 ⑲). 묶음이 **언어**라 한 바퀴에 언어마다 한 자리.
    ⚠ 그래서 **한국어가 서른셋이어도 한 바퀴에 하나**만 돈다 — 실측 한국어만
      열여섯 번 돌고 열 언어가 0회였던 그 자리를 막는다.
    """
    rows = keywords(conn, kind, langs, domain=domain)
    if not rows:
        return []
    if n is None:
        n = round_n(rows)
    try:
        import db_media_attempt as AT
        got = AT.arrange(rows, AT.ORDER_EVEN, lambda r: r[3],
                         bucket_of=lambda r: r[1])
    except Exception:
        got = sorted(rows, key=lambda r: (r[3], r[4]))
    return got[:int(n)]


def plan(conn, kind=None, n=None, langs=None, domain='WORSHIP'):
    """무엇을 돌지 **미리 보인다** → dict. 쿼터 0.

    ⚠ **돌리기 전에 무엇을 할지 말한다** — 말 없이 쿼터를 태우지 않는다.
    """
    got = next_keywords(conn, kind, n, langs, domain=domain)
    all_ = keywords(conn, kind, langs, domain=domain)
    never = sum(1 for r in all_ if not r[3])
    return {'rows': got, 'total': len(all_), 'never': never,
            'units': len(got) * UNITS_PER_QUERY,
            'langs': sorted({r[1] for r in got})}


def _since_of(last_run, days=30, today=None):
    """검색 기간의 시작(RFC3339) — 직전 실행일, 없거나 그보다 오래됐으면 오늘−days.

    ⚠ 직전 실행이 30일보다 더 오래됐으면 **그 날부터** 본다(빠뜨리지 않는다)."""
    import datetime as _dt
    t = today or _dt.date.today()
    base = t - _dt.timedelta(days=days)
    try:
        d = _dt.date.fromisoformat(str(last_run or '')[:10])
        if d < base:
            base = d
    except Exception:
        pass
    return base.isoformat() + 'T00:00:00Z'


#: ⚠ **쪽 토큰은 이제 안 쓴다**(2026-09-16 · 기간+최신순으로 바꿨다 — 기간이 달라지면 토큰이 안 맞는다).
#:   표와 두 문은 **되돌릴 자리**로 남긴다(`WORSHIP_FIND_PAGE`). 부르는 곳 = selftest 뿐.
def _page_map(conn):
    import json
    r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                     (PAGE_KEY,)).fetchone()
    try:
        return json.loads(r[0]) if r and r[0] else {}
    except Exception:
        return {}


def _page_save(conn, m):
    import json
    conn.execute(
        "INSERT INTO sys_config(config_key, config_val) VALUES(?,?)"
        " ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
        (PAGE_KEY, json.dumps(m, ensure_ascii=False)))


#: 라틴 글자 언어 — 제목 글자만으로는 영어와 갈리지 않는다(2026-10-12 기도 첫 바퀴 실측:
#:   스페인어·포르투갈어·프랑스어·독일어 검색 결과가 전부 EN 으로 담겼다).
_LATIN_WORDS = {
    'ES': r'el|los|las|del|que|mi|tu|de|la|señor|dios|con|para|oración|oracion|mañana|noche|alabanza|adoración|día|hoy',
    'PT': r'o|os|da|do|das|dos|não|meu|minha|deus|senhor|oração|oracao|manhã|noite|louvor|hoje|dia',
    'DE': r'der|die|das|und|ich|mein|gott|herr|nicht|gebet|morgengebet|abendgebet|für|zum|ist|du|dich|dir|mich|heute|wenn|danke|deine|kraftvolles',
    'FR': r'le|la|les|des|du|et|mon|ma|de|seigneur|dieu|prière|priere|matin|soir|louange|pour',
    'EN': r'the|and|of|my|you|your|god|lord|is|for|with|prayer|morning|night|worship|song|to',
}


def latin_lang(title, kw_lang):
    """검색어가 라틴 글자 언어(ES·PT·FR·DE)이고 제목이 영어로 판정되면 → 낱말로 다시 가른다.

    그 언어 낱말이 영어 낱말만큼 있으면 검색어 언어 · 영어가 뚜렷하면 EN.
    """
    import re
    kw_lang = (kw_lang or '').upper()
    if kw_lang not in ('ES', 'PT', 'FR', 'DE'):
        return None
    words = re.findall(r'\w+', (title or '').lower())
    sc = {k: sum(1 for w in words if re.fullmatch(p, w)) for k, p in _LATIN_WORDS.items()}
    return kw_lang if sc[kw_lang] >= max(1, sc['EN']) else 'EN'


#: 기도 검색의 길이 조건 차례 — 그 검색어가 돈 횟수로 돌린다.
PRAYER_DURATIONS = (None, 'medium', 'long')


def prayer_duration(n_run):
    """기도 검색어가 n번째 돌 때의 videoDuration(None = 조건 없음)."""
    return PRAYER_DURATIONS[int(n_run or 0) % len(PRAYER_DURATIONS)]


def run(conn, keys, kind=None, n=None, per=DEFAULT_PER, langs=None,
        log=print, stop=None, dry=False, domain='WORSHIP'):
    """검색어 n개를 **돌아가며** 돌고 담는다 → dict.

    ⚠⚠ **담는 문은 `media_intake.admit` 하나다** — 여기서 따로 INSERT 하지
      않는다. 쇼츠·이단·거르는 말이 그 문에만 있다(§237차 ③).
    ⚠ **`domain='WORSHIP'`** 을 준다 — 안 주면 찬양 낱말이 오프토픽에 걸린다.
    ⚠ **돈 사실을 반드시 적는다**(`n_run`·`last_run`) — 그것이 「직전 수집어를
      기억한다」의 실체이고, 다음 바퀴의 차례를 정한다.
    """
    import media_intake as MI
    import media_taxonomy as TX
    import db_channel_mine as CM
    ensure(conn)
    domain = (domain or 'WORSHIP').upper()
    got = next_keywords(conn, kind, n, langs, domain=domain)
    out = {'kw': 0, 'seen': 0, 'new': 0, 'skip': 0, 'units': 0, 'langs': []}
    if not got:
        log('돌 검색어가 없습니다 — ⑤ 설정에서 지정하세요.')
        return out
    if dry:
        out['kw'] = len(got)
        out['units'] = len(got) * UNITS_PER_QUERY
        out['langs'] = sorted({r[1] for r in got})
        return out
    try:
        from googleapiclient.discovery import build
    except ImportError:
        log('[오류] google-api-python-client 가 없습니다.')
        return out
    gate = MI.Gate(conn)
    # ★ 갈래를 행마다 읽는다 — `kind=None` 으로 부르면 갈래가 섞여 돈다.
    #   `keywords()` 의 반환 모양은 안 바꾼다(쓰는 쪽이 깨진다).
    kmap = {r[0]: (r[1] or KIND_DEFAULT) for r in conn.execute(
        "SELECT kw_id, kind FROM %s" % TBL)}
    for kid, lg, kw, _n, _last in got:
        k_of = kmap.get(kid, KIND_DEFAULT)
        # ⚠ 사역자 갈래는 **그 이름의 다른 언어 표기까지** 본다 — KO 이름
        #   하나로 재면 영문 제목을 통째로 놓친다(실측 0편 → 78편).
        a_names = artist_forms(conn, kw) if k_of == KIND_ARTIST else None
        if stop is not None and stop.is_set():
            log('[중지됨]')
            break
        items = []
        for k in (keys or []):
            try:
                yt = build('youtube', 'v3', developerKey=k,
                           cache_discovery=False)
                # ★★★ **기간 + 최신순**(2026-09-16 사용자 「유닛을 낭비하는 씨앗 낱말을
                #   분석하라. 원인이 무엇인가?」). 그전에는 `order`(기본 relevance)도
                #   `publishedAfter` 도 없어 **늘 같은 인기 영상 25편**이 왔고 그것은
                #   첫 바퀴에 이미 담긴 것이라 두 번째부터 새것 0 이었다(실측 기본 검색
                #   18~22/25 이미 있음 · 기간 30일+최신순 16~25/25 새것). 쪽 토큰으로
                #   둘째 쪽을 넘기는 것은 답이 아니었다 — 오래된 인기 영상만 더 온다.
                #   기간 = **직전 실행일**(없으면 30일). 쪽 토큰은 안 쓴다(기간이 다르면
                #   토큰이 안 맞는다) — `WORSHIP_FIND_PAGE` 표는 읽지 않고 남겨 둔다.
                req = dict(part='snippet', type='video', q=kw, maxResults=per,
                           order='date', publishedAfter=_since_of(_last))
                # ★ 2026-10-12 기도 — 최신순 검색은 1~3분짜리로 쏠린다(첫 바퀴 415편 중 300편이 3분 이하).
                #   숏츠는 담되(사용자) 긴 기도도 모이게 **바퀴마다 길이 조건을 돌린다** — 비용은 그대로다.
                dur = prayer_duration(_n) if domain == 'PRAYER' else None
                if dur:
                    req['videoDuration'] = dur
                res = yt.search().list(**req).execute()
                items = res.get('items', [])
                out['units'] += UNITS_PER_QUERY
                break
            except Exception:
                continue
        n_new = 0
        for it in items:
            vid = (it.get('id') or {}).get('videoId')
            if not vid:
                continue
            sn = it.get('snippet') or {}
            ti = sn.get('title') or ''
            lgv = TX.guess_lang(ti)
            if lgv == 'EN':                       # 라틴 글자 언어는 검색어 언어로 다시 가른다
                lgv = latin_lang(ti, lg) or lgv
            # ★★ 사역자 갈래 — **이름이 실제로 있는 것만 담는다.**
            #   검색 엔진이 섞어 준 관련 영상(실측 42%)을 그 자리에서 거른다.
            if a_names is not None and not name_hit(
                    ti, sn.get('channelTitle') or '', a_names):
                out['skip'] += 1
                continue
            res = MI.admit(gate, {
                'title': ti,
                'url': 'https://www.youtube.com/watch?v=%s' % vid,
                'lang_code': lgv, 'channel': sn.get('channelTitle') or '',
                'channel_id': sn.get('channelId') or '',
                'published': sn.get('publishedAt') or '',
                'yt_desc': sn.get('description') or '',
                'desc_extra': {'rend_kind': TX.rend_kinds(ti, lgv)},
            }, domain=domain)             # 찬양이면 domain='WORSHIP' — 면제 낱말이 듣는다
            act = res.get('action')
            if act == getattr(MI, 'ACT_NEW', 'NEW'):
                mid = res.get('media_id')
                # ⚠⚠ **사역자 갈래는 유형을 안 못 박는다** — 이름으로 왔다고
                #   찬양이 아니다(실측 「레위지파」 44편이 거의 다 성경 지파
                #   설교였다). 분류기가 정하게 두면 설교는 설교로 담긴다.
                if mid and k_of == KIND_ARTIST:
                    mid = None
                if mid:
                    # 검색어가 걸렸다는 사실이 낱말 분류보다 강한 신호(§233차) —
                    #   그 분야로 못 박는다(찬양 → WORSHIP · 성경듣기 → READING).
                    conn.execute(
                        "UPDATE sys_media_asset SET media_type=?"
                        "  WHERE media_id=? AND media_type<>?", (domain, mid, domain))
                n_new += 1
            elif act and str(act).startswith('SKIP'):
                out['skip'] += 1
        out['kw'] += 1
        out['seen'] += len(items)
        out['new'] += n_new
        try:
            CM.record_run(conn, kid, len(items), n_new)
        except Exception as e:
            log('[시도 기록] %r' % e)
        log('  [%s] %-28s 본 것 %2d · 새것 %2d' % (lg, kw[:28], len(items),
                                                n_new))
    conn.commit()
    out['langs'] = sorted({r[1] for r in got})
    return out


def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    import sqlite3
    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE %s(kw_id INTEGER PRIMARY KEY, lang TEXT, kw TEXT,"
              " enabled INT, last_run TEXT, n_run INT, n_seen INT, n_new INT,"
              " note TEXT, domain TEXT, record_status TEXT)" % TBL)
    c.execute("CREATE TABLE sys_config(config_key TEXT PRIMARY KEY,"
              " config_val TEXT)")
    t('★ `kind` 칸이 멱등으로 선다', ensure(c) and ensure(c))
    t('★★ **옛 줄은 연속듣기로 본다**(그 탭에서 만들어졌다)',
      'kind' in [r[1] for r in c.execute('PRAGMA table_info(%s)' % TBL)])

    def add(lg, kw, kind=KIND_DEFAULT, n=0, on=1):
        c.execute("INSERT INTO %s(lang, kw, enabled, n_run, domain, kind,"
                  " record_status) VALUES(?,?,?,?,'WORSHIP',?,'LIVE')" % TBL,
                  (lg, kw, on, n, kind))
    # 한국어가 많고 나머지는 하나씩 — 실측과 같은 모양
    for i in range(6):
        add('KO', 'ko%d' % i, n=3)
    for lg in ('EN', 'JA', 'ZH'):
        add(lg, '%s1' % lg, n=0)
    add('KO', 'song1', KINDS[1][0])
    add('KO', 'off1', n=0, on=0)

    t('★ 갈래로 가른다',
      len(keywords(c, 'PLAYLIST')) == 9 and len(keywords(c, 'SONG')) == 1,
      (len(keywords(c, 'PLAYLIST')), len(keywords(c, 'SONG'))))
    t('★★ **꺼 둔 것은 안 돈다**(사람이 끈 뜻을 지킨다)',
      all(r[2] != 'off1' for r in keywords(c, 'PLAYLIST')))
    got = next_keywords(c, 'PLAYLIST', 4)
    t('★★★ **한 바퀴에 언어가 골고루 든다**(한국어가 여섯이어도) %s'
      % [(r[1], r[2]) for r in got],
      len({r[1] for r in got}) >= 3, [(r[1], r[2]) for r in got])
    t('★★★ **한 번도 안 돈 것이 먼저**',
      all(r[3] == 0 for r in got[:3]), [(r[1], r[3]) for r in got])
    p = plan(c, 'PLAYLIST', 4)
    t('★ 미리 보기가 비용을 말한다', p['units'] == 400, p['units'])
    t('★★ **한 번도 안 돈 검색어 수를 말한다**', p['never'] == 3, p['never'])
    r = run(c, keys=[], kind='PLAYLIST', n=4, dry=True)
    t('★ 안 돌고도 셈을 낸다(dry)', r['kw'] == 4 and r['units'] == 400, r)
    t('★★ 돌 것이 없으면 그렇게 말한다',
      run(c, keys=[], kind='SONG', n=4, langs=['FR'])['kw'] == 0)
    # 쪽 기억
    _page_save(c, {'ko0': 'TOK'})
    t('★★ **직전 자리를 기억한다**(쪽 토큰)', _page_map(c).get('ko0') == 'TOK')
    import inspect as _i
    src = _i.getsource(run)
    t('★★★ **담는 문은 `media_intake.admit` 하나다**',
      'MI.admit(' in src and ('INSERT INTO ' + 'sys_media_asset') not in src)
    t('★★★ **분야를 반드시 준다**(찬양 면제가 듣는다)',
      "domain='WORSHIP'" in src)
    t('★★ **돈 사실을 적는다**(다음 차례를 정한다)', 'CM.record_run(' in src)
    # ── 기간 + 최신순(2026-09-16 — 씨앗이 유닛을 낭비하던 까닭) ──
    import datetime as _dt
    _td = _dt.date(2026, 9, 16)
    t('★★★ 검색에 기간(publishedAfter)과 최신순(order=date)을 준다 · 쪽 토큰은 안 쓴다',
      'publishedAfter=' in src and "order='date'" in src and 'pageToken' not in src)
    t('★★ 기간 시작 = 직전 실행일(없으면 30일 전)',
      _since_of(None, today=_td) == '2026-08-17T00:00:00Z'
      and _since_of('2026-09-10 12:00', today=_td) == '2026-08-17T00:00:00Z',
      (_since_of(None, today=_td), _since_of('2026-09-10 12:00', today=_td)))
    t('  직전 실행이 30일보다 오래됐으면 그 날부터(빠뜨리지 않는다)',
      _since_of('2026-06-01', today=_td) == '2026-06-01T00:00:00Z')
    t('★★ 차례는 `db_media_attempt` 가 정한다(문이 하나)',
      'AT.arrange(' in _i.getsource(next_keywords))
    t('★★ **분야를 나누지 않는다**(둘 다 WORSHIP)',
      "domain='WORSHIP'" in _i.getsource(ensure).replace('  ', ' ')
      or "COALESCE(domain,'')='WORSHIP'" in _i.getsource(ensure))
    # ── 사역자 갈래(2026-09-26 · 1.txt 17번 1)) ──
    t('★★ 갈래가 셋이다(연속듣기·일반 찬양·**사역자**)',
      KIND_ARTIST in dict(KINDS) and len(KINDS) == 3, [k for k, _ in KINDS])
    t('★★★ 사역자 갈래는 **이름이 있는 것만 담는다**',
      'name_hit(' in src and 'a_names' in src)
    t('★★★ 사역자 갈래는 **유형을 안 못 박는다**(설교가 찬양으로 굳지 않게)',
      'k_of == KIND_ARTIST' in src and 'mid = None' in src)
    # ★ 이름 걸림 — **양방향**(걸려야 할 것은 걸리고 아닌 것은 안 걸린다)
    _f = {'어노인팅', 'ANOINTING'}
    t('  이름이 제목에 있으면 걸린다',
      name_hit('사랑의 노래 드리네 | ANOINTING CLIP', 'ANOINTING', _f))
    t('  채널에만 있어도 걸린다', name_hit('주를 경배', '어노인팅', _f))
    t('  **없으면 안 걸린다**(검색 엔진이 섞어 준 관련 영상을 거른다)',
      not name_hit('신나는 찬양 모음 | Joyful Worship', 'GLOBAL PRAISE', _f))
    # ★ 다국어 표기 — KO 하나로 재면 영문 제목을 통째로 놓친다(실측 0 → 78편)
    t('★★ 씨앗 이름의 **다른 언어 표기까지** 본다',
      'names_of(' in _i.getsource(artist_forms))
    t('  띄어쓰기를 뗀 꼴도 본다(제목은 `#다윗과요나단` 처럼 붙여 쓴다)',
      "replace(' ', '')" in _i.getsource(artist_forms))
    t('★★ **짧은 이름은 씨앗으로 안 담는다**(§195차 「엘」)',
      'ARTIST_MIN_LEN' in _i.getsource(seed_artists) and ARTIST_MIN_LEN >= 3,
      ARTIST_MIN_LEN)
    t('★★ **이미 있는 줄은 안 건드린다**(사람이 켜고 끈 것을 안 되돌린다)',
      'SELECT 1 FROM' in _i.getsource(seed_artists))
    c.close()
    print('db_worship_collect selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


def main(argv):
    if '--selftest' in argv:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(DB)
    try:
        kind = KIND_DEFAULT
        if '--kind' in argv:
            kind = argv[argv.index('--kind') + 1].upper()
        n = DEFAULT_N
        if '--n' in argv:
            n = int(argv[argv.index('--n') + 1])
        p = plan(conn, kind, n)
        print('갈래 [%s] — 검색어 %d개 · 한 번도 안 돈 것 %d개'
              % (KIND_LABEL.get(kind, kind), p['total'], p['never']))
        print('다음 바퀴 %d개 · 언어 %s · 예상 %d units'
              % (len(p['rows']), ','.join(p['langs']), p['units']))
        for kid, lg, kw, nr, last in p['rows']:
            print('   %-4s %-32s %d회  %s' % (lg, kw[:32], nr, last[:16]))
        if '--run' not in argv:
            print()
            print('※ 실제로 돌리려면 --run')
            return
        row = __import__('secret_store').row('YOUTUBE_API_KEYS')  # 열쇠는 배포 DB 밖(2026-10-11)
        keys = [k.strip() for k in (row[0] if row else '').split(',')
                if k.strip()]
        if not keys:
            print('API 키가 없습니다.')
            return
        print()
        got = run(conn, keys, kind, n)
        print()
        print('검색어 %d개 · 본 것 %d · 새것 %d · 걸러짐 %d · 쓴 %d units'
              % (got['kw'], got['seen'], got['new'], got['skip'], got['units']))
    finally:
        conn.close()


if __name__ == '__main__':
    main(sys.argv[1:])
