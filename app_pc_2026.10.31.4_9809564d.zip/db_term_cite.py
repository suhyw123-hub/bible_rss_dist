# -*- coding: utf-8 -*-
"""db_term_cite.py — **우리 글이 이미 이름을 댄 낱말**을 찾아 승격한다
(영구 도구 · §0-5 KEEP · 2026-09-24 · 1.txt 15번 3단계).

왜 만드나
    승격 후보를 **빈도 순**으로 뽑으면 맨 위가 `말하다`(4,337절) · `모든`
    (4,242) · `아들`(3,653) · `있다`(3,131) 다. 전부 **문법 낱말**이라
    주요용어 훑기 목록이 「to say · all · to be」로 찬다.
    ⇒ **잣대를 바꾼다 — 「우리가 쓴 글이 이미 그 낱말을 부르고 있나」.**
       실측 절 설명문 27,101편에 **`한국어(한글음역)` 꼴 인용이 7,210가지**
       있다(`은혜(카리스)` · `영광(독사)` · `믿음(피스티스)`). 사용자가 그
       글을 읽다 누를 낱말이 바로 그것이다.

★★★ **이름을 지어내지 않는다 — 우리 글에서 그대로 가져온다.**
    `db_term_promote` 가 「한국어는 사람이 적는다(기계로 짓지 않는다)」로
    막아 둔 자리인데, 여기서 쓰는 한국어는 **사람이 설명문에 쓴 그 낱말**이라
    그 규칙을 어기지 않는다.

★★★ **스트롱 번호도 짐작하지 않는다 — 본문으로 증명한다.**
    「은혜(카리스)」가 인용된 절들의 **원어 낱말 집합**(`sys_verse_strong` BSB
    ∪ `sys_verse_lemma`)을 모아, 그 절들에 유난히 몰려 있는 스트롱을 고른다.
    실측 상위 25가지가 전부 맞았다(G5485 cháris · G1391 dóxa · G4102 pístis
    · G26 agápē · G3466 mystḗrion …). **내 기억이 아니라 본문이 고른 것이다.**

⚠⚠⚠ **`share` 만 보면 문법 낱말이 이긴다.** `H853`(목적격 표지)·`G846`(그)·
  `G1510`(이다)는 거의 모든 절에 있어 무엇을 인용하든 `share` 가 1.0 이다.
  ⇒ **lift**(몰린 정도 = share ÷ 전체 절에서의 비율)로 거른다. 실측 참 후보는
    lift 44~1,473 이고 문법 낱말은 20 미만이다.

⚠ **한 낱말에 한국어가 여럿일 수 있다**(G1515 → 평강·평안·화평). 인용이
  가장 많은 것을 쓰고 나머지는 적어만 둔다(사람이 본다).
⚠ **이름은 `한국어 · 음역`** — 이미 승격된 123개가 쓰는 꼴 그대로다
  (「인애 · 헤세드」). 「때」처럼 한국어가 겹치는 낱말이 실제로 있다
  (G2540 카이로스 · G5610 호라) — 음역이 그것을 가른다.

쓰는 법
    python db_term_cite.py --selftest        ← 의무
    python db_term_cite.py --check [--limit N]
    python db_term_cite.py --apply [--limit N]
"""
from __future__ import annotations

import argparse
import collections
import difflib
import os
import re
import sys
import unicodedata

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb                                              # noqa: E402

#: 인용 꼴 — `은혜(카리스)`. 앞은 한국어 낱말, 괄호 안은 한글 음역.
CITE = re.compile(r'([가-힣]{1,8})\s*\(([가-힣]{2,12})\)')

MIN_VERSES = 3      # 이보다 적으면 우연일 수 있다
MIN_SHARE  = 0.7    # 인용한 절 가운데 그 낱말이 실제로 있는 비율
MIN_LIFT   = 20.0   # 문법 낱말을 거르는 잣대(실측 참 후보 44 이상)
MIN_TR     = 0.5    # 음역이 얼마나 맞나(실측 참 0.62~1.00 · 틀린 것 0.17·0.33)

#: 한글 자모 → 로마자. **표준 로마자 표기가 아니다** — 음역끼리 견주기만
#: 하면 되므로 글자 하나에 하나씩 성기게 편다.
_CHO = ('g', 'kk', 'n', 'd', 'tt', 'r', 'm', 'b', 'pp', 's', 'ss', '',
        'j', 'jj', 'ch', 'k', 't', 'p', 'h')
_JUNG = ('a', 'ae', 'ya', 'yae', 'eo', 'e', 'yeo', 'ye', 'o', 'wa', 'wae',
         'oe', 'yo', 'u', 'wo', 'we', 'wi', 'yu', 'eu', 'ui', 'i')
_JONG = ('', 'k', 'k', 'k', 'n', 'n', 'n', 't', 'l', 'l', 'l', 'l', 'l', 'l',
         'l', 'l', 'm', 'p', 'p', 't', 't', 'ng', 't', 't', 'k', 't', 'p', 't')


#: **문법 낱말** — 본문 증거로는 못 가른다(우리 글이 실제로 그렇게 쓴다).
#: 까닭을 적어 둔다. 적지 않으면 예외가 아니라 구멍이다(§0-5).
FUNCTION_WORDS = {
    'G2443': 'ἵνα — 목적 접속사',
    'G1352': 'διό — 접속사 「그러므로」',
    'G4218': 'ποτέ — 부사 「언젠가」',
    'G4412': 'πρῶτον — 부사 「먼저」',
    'G686':  'ἄρα — 추론 불변화사',
    'G3767': 'οὖν — 접속사 「그런즉」',
}

#: 이름이 **표제어 꼴이 아닌** 자리 — 활용형·조각
_TAIL = ('라', '여', '니', '며', '게', '히', '신', '았다', '었다', '였다',
         '없이', '번에')
_FRAG = ('자', '것', '본', '상', '들', '중', '분', '말')


def looks_inflected(ko):
    """이름이 **활용형이나 조각**인가. 참이면 사람이 짓는다.

    ⚠ 「믿다」·「섬기다」처럼 **사전형 동사는 통과**시킨다 — 그것은 표제어다.
    ⚠ 「불」·「손」·「샘」처럼 **한 글자라도 멀쩡한 낱말**이 있다. 그래서
      글자 수가 아니라 **조각 목록**으로 가른다.
    """
    k = (ko or '').strip()
    if not k:
        return True
    if k in _FRAG:
        return True
    if k.endswith('다'):
        # ⚠ **과거형 `-았/었/였다` 는 사전형이 아니다.** 앞 글자의 받침이
        #   ㅆ 이면 과거다(`버렸다`·`하셨다`) — 글자를 늘어놓아 맞추면
        #   `렸다`·`켰다`처럼 끝없이 샌다(실측으로 당했다).
        if len(k) >= 2:
            o = ord(k[-2]) - 0xAC00
            if 0 <= o < 11172 and (o % 28) == 20:      # 받침 ㅆ
                return True
        #   ⚠ `있다`·`했다` 도 받침 ㅆ 이라 함께 걸린다 — 둘 다 주요용어가
        #     아니므로 손해가 없다(잘못 통과시키는 쪽이 더 비싸다).
        return False            # 사전형 동사 — 표제어다
    return k.endswith(_TAIL)


def romanize(s):
    """한글 음역 → 로마자(성기게). 한글이 아닌 글자는 그대로 내린다."""
    out = []
    for ch in s or '':
        o = ord(ch) - 0xAC00
        if 0 <= o < 11172:
            out.append(_CHO[o // 588] + _JUNG[(o % 588) // 28] + _JONG[o % 28])
        elif ch.isalpha():
            out.append(ch.lower())
    return ''.join(out)


def _plain(s):
    """라틴 음역에서 **덧기호를 걷는다** — `cháris` → `charis`."""
    s = unicodedata.normalize('NFD', s or '')
    return ''.join(c for c in s
                   if c.isalpha() and not unicodedata.combining(c)).lower()


def translit_match(ko_tr, latin):
    """한글 음역 ↔ 라틴 음역이 얼마나 맞나 (0~1).

    ★★★ **본문 증거와 **독립된** 둘째 잣대**다. 첫째(share·lift)는 「그 절에
      그 낱말이 있나」를 묻고, 이것은 「부르는 소리가 같은가」를 묻는다.
      둘이 함께 맞아야 받아들인다.
    ⚠ 표기 규칙이 저마다라 **완전 일치를 요구하지 않는다**(카리스 ↔ cháris 는
      0.62 다). 잡으려는 것은 **아예 다른 낱말**이다.
    """
    a, b = romanize(ko_tr), _plain(latin)
    if not a or not b:
        return 0.0
    return difflib.SequenceMatcher(None, a, b).ratio()


def cites(conn, min_verses=MIN_VERSES):
    """{(한국어, 음역): {verse_id…}} — **절 설명문만** 본다.

    ⚠ 단락·장 설명문은 좌표가 절이 아니라 **어느 절의 원어인지 못 댄다**.
      증거가 흐려지므로 안 쓴다(§0-1 — 못 재면 안 재는 것이 낫다).
    """
    out = collections.defaultdict(set)
    for vid, txt in conn.execute(
            "SELECT clicked_id, contents FROM sys_text_asset"
            " WHERE text_type='VERS_DESC' AND lang_code='KO'"
            "   AND COALESCE(record_status,'LIVE')='LIVE'"):
        for ko, tr in CITE.findall(txt or ''):
            out[(ko, tr)].add(vid)
    return {k: v for k, v in out.items() if len(v) >= min_verses}


def strong_sets(conn):
    """{verse_id: {스트롱…}} — 배포 표 둘을 합친다(구약·신약 모두).

    ⚠ `sys_verse_strong` 은 **번역문에 붙은** 번호이고 `sys_verse_lemma` 는
      원문 쪽이다. 어느 하나만 보면 한쪽 성경이 통째로 빈다.
    """
    S = {}
    for vid, ss in conn.execute(
            "SELECT verse_id, strongs FROM sys_verse_strong"
            " WHERE version_code='BSB'"):
        S[vid] = set((ss or '').split())
    for vid, ss in conn.execute("SELECT verse_id, strongs FROM sys_verse_lemma"):
        S.setdefault(vid, set()).update((ss or '').split())
    return S


def _lemma(conn):
    return {r[0]: (r[1], r[2] or '', r[3] or 0) for r in conn.execute(
        "SELECT strong, translit, gloss, n_verse FROM sys_lemma_master")}


def plan(conn, min_verses=MIN_VERSES, min_share=MIN_SHARE, min_lift=MIN_LIFT):
    """승격 후보 — `[dict(strong, ko, translit, n_cite, share, lift, …)]`.

    같은 스트롱에 여러 한국어가 걸리면 **인용이 가장 많은 것**을 쓰고
    나머지는 `alt` 에 적는다(사람이 본다).
    """
    import db_term_promote as TP
    S = strong_sets(conn)
    tot = float(len(S)) or 1.0
    base = collections.Counter()
    for s in S.values():
        base.update(s)
    lem = _lemma(conn)

    rows = []
    for (ko, tr), vids in cites(conn, min_verses).items():
        cc = collections.Counter()
        for v in vids:
            cc.update(S.get(v, ()))
        best = None
        for st, n in cc.items():
            share = n / float(len(vids))
            b = base.get(st, 0) / tot
            if b <= 0 or share < min_share:
                continue
            lift = share / b
            if lift >= min_lift and (best is None or lift > best[2]):
                best = (st, share, lift)
        if best:
            rows.append((best[0], ko, tr, len(vids), best[1], best[2]))

    # 스트롱마다 한 줄로 모은다 — 인용이 많은 한국어가 대표
    by = collections.defaultdict(list)
    for st, ko, tr, n, share, lift in rows:
        by[st].append((n, ko, tr, share, lift))
    out = []
    for st, lst in by.items():
        lst.sort(reverse=True)
        n, ko, tr, share, lift = lst[0]
        state = TP.state_of(conn, st)
        la, gl, nv = lem.get(st, ('', '', 0))
        out.append(dict(
            strong=st, ko=ko, translit=tr, n_cite=n, share=share, lift=lift,
            latin=la, gloss=gl, n_verse=nv, tr_score=translit_match(tr, la),
            kind=(state or {}).get('kind'), entity_id=(state or {}).get('entity_id'),
            func=FUNCTION_WORDS.get(st), inflected=looks_inflected(ko),
            alt=[x[1] for x in lst[1:]],
            name='%s · %s' % (ko, tr)))
    out.sort(key=lambda d: -d['n_cite'])
    return out


def todo(conn, min_tr=MIN_TR, **kw):
    """올려도 되는 것 — 아직 용어가 아니고 **두 잣대가 다 맞는** 것.

    ⚠ 음역이 안 맞는 줄은 **버리지 않고 `shaky()` 로 뺀다** — 틀렸다는 뜻이
      아니라 **기계가 못 고른다**는 뜻이다. 사람이 본다(§0-1).
    """
    return [d for d in plan(conn, **kw) if _clean(d, min_tr)]


def _clean(d, min_tr=MIN_TR):
    """세 잣대를 다 통과했나 — 본문 증거 · 음역 · 이름 꼴."""
    return (d['kind'] != 'TERM' and d['tr_score'] >= min_tr
            and not d['func'] and not d['inflected'])


def shaky(conn, min_tr=MIN_TR, **kw):
    """증거는 섰는데 **사람이 봐야 하는** 줄 → `(줄, 까닭)`."""
    out = []
    for d in plan(conn, **kw):
        if d['kind'] == 'TERM' or _clean(d, min_tr):
            continue
        why = ('문법 낱말 — ' + d['func']) if d['func'] else (
            '이름이 활용형·조각' if d['inflected'] else
            '음역이 안 맞는다 %.2f' % d['tr_score'])
        out.append((d, why))
    return out


def name_clash(conn, names):
    """이미 쓰이고 있는 한국어 이름 — **겹치면 훑기 목록에서 구별이 안 된다.**"""
    have = {r[0] for r in conn.execute(
        "SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME'"
        " AND lang_code='KO' AND COALESCE(record_status,'LIVE')='LIVE'")}
    dup = collections.Counter(names)
    return sorted({n for n in names if n in have or dup[n] > 1})


def apply(conn, rows, limit=None, verbose=True):
    """`db_term_promote.promote` 로 하나씩 올린다.

    ⚠ **승격 문을 여기서 다시 짜지 않는다** — 코드 바꾸기·앵커·절 연결이
      거기 한 곳에 있다. 두 벌이 되면 한쪽만 고쳐진다.
    """
    import db_term_promote as TP
    done, fail = [], []
    for d in rows[:limit] if limit else rows:
        try:
            eid = TP.promote(conn, d['strong'], d['name'])
            done.append((d['strong'], d['name'], eid))
            if verbose:
                print('  + %-7s %s → entity %d' % (d['strong'], d['name'], eid))
        except Exception as e:                            # noqa: BLE001
            fail.append((d['strong'], d['name'], str(e)))
            if verbose:
                print('  X %-7s %s — %s' % (d['strong'], d['name'], e))
    return done, fail


# ── 자가 검사 ─────────────────────────────────────────────────────────
def selftest():
    """★ 의무. **재료를 만들어서 잰다** — 실 DB 상태를 전제하지 않는다(§0-5)."""
    import sqlite3
    print('db_term_cite 자가 검증')
    ok = fail = 0

    def t(n, cond, e=''):
        nonlocal ok, fail
        if cond:
            ok += 1
            print('  OK   %s' % n)
        else:
            fail += 1
            print('  FAIL %s  %s' % (n, e))

    d = sqlite3.connect(':memory:')
    d.executescript("""
      CREATE TABLE sys_text_asset(clicked_id INT, text_type TEXT,
        lang_code TEXT, contents TEXT, record_status TEXT);
      CREATE TABLE sys_verse_strong(version_code TEXT, verse_id INT,
        strongs TEXT, n_word INT);
      CREATE TABLE sys_verse_lemma(verse_id INT, strongs TEXT);
      CREATE TABLE sys_lemma_master(strong TEXT, translit TEXT, gloss TEXT,
        n_verse INT);
      CREATE TABLE sys_entity_lemma(lemma_id INTEGER PRIMARY KEY, entity_id INT,
        strong TEXT, record_status TEXT);
      CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY,
        entity_code TEXT, entity_type TEXT, json_detail TEXT,
        record_status TEXT);
    """)
    # ★ 재료를 **실제 크기 비슷하게** 만든다 — `lift` 는 전체 절 수로
    #   재므로 10절짜리 장난감에서는 참 후보도 문턱을 못 넘는다(실측으로 당했다).
    N = 200
    for v in range(1, N + 1):
        # 문법 낱말 G846 은 **모든 절**에 있다(어디에나 있는 낱말)
        d.execute("INSERT INTO sys_verse_strong VALUES('BSB',?,?,0)",
                  (v, 'G846 G%d' % (1000 + v)))
    # 절 1~4 에만 G5485 — 「은혜(카리스)」를 그 넷에서 인용한다
    for v in range(1, 5):
        d.execute("UPDATE sys_verse_strong SET strongs=strongs||' G5485'"
                  " WHERE verse_id=?", (v,))
        d.execute("INSERT INTO sys_text_asset VALUES(?,'VERS_DESC','KO',"
                  "'이 절은 은혜(카리스)를 말한다.','LIVE')", (v,))
    # ★ **가려낼 것** — 「아들(벤)」은 특징 있는 낱말이 없는 절들에서 인용된다.
    #   가장 몰린 것이 문법 낱말 G846 이라 문턱이 없으면 그것이 뽑힌다.
    for v in range(20, 26):
        d.execute("INSERT INTO sys_text_asset VALUES(?,'VERS_DESC','KO',"
                  "'여기는 아들(휘오스)이 나온다.','LIVE')", (v,))
    # 두 절짜리 인용 — 증거가 모자라 안 든다
    for v in (50, 51):
        d.execute("INSERT INTO sys_text_asset VALUES(?,'VERS_DESC','KO',"
                  "'여기는 얕음(테스트)이다.','LIVE')", (v,))
    d.execute("INSERT INTO sys_lemma_master VALUES('G5485','cháris','grace',4)")
    d.execute("INSERT INTO sys_lemma_master VALUES('G846','autós','he',200)")
    d.commit()

    cc = cites(d)
    t('인용을 뽑는다', ('은혜', '카리스') in cc, sorted(cc))
    t('★ 3절 미만은 안 든다', ('얕음', '테스트') not in cc)

    pl = plan(d)
    got = {r['strong']: r for r in pl}
    t('★★★ **본문이 스트롱을 선택한다** — 은혜 → G5485',
      'G5485' in got and got['G5485']['ko'] == '은혜', sorted(got))
    t('★★★ **문법 낱말은 안 든다**(G846 은 어디에나 있다)', 'G846' not in got)
    t('★ 이름이 `한국어 · 음역`',
      got.get('G5485', {}).get('name') == '은혜 · 카리스',
      got.get('G5485', {}).get('name'))
    t('  증거 수를 함께 낸다',
      got.get('G5485', {}).get('n_cite') == 4 and got['G5485']['share'] == 1.0)

    t('★ 특징 없는 인용은 버린다(「아들」)',
      '아들' not in {r['ko'] for r in pl}, sorted(r['ko'] for r in pl))
    # ★★ 탐지력 — lift 문턱을 없애면 **문법 낱말이 뽑힌다**(잣대가 실제로 일한다)
    loose = {r['strong'] for r in plan(d, min_lift=0)}
    t('★★ 탐지력 — 문턱을 없애면 G846 이 들어온다', 'G846' in loose, sorted(loose))

    # ★ 이미 사람 용어면 `todo` 에서 빠진다
    d.execute("INSERT INTO sys_entity_master VALUES(9,'T_G5485','TERM',NULL,'LIVE')")
    d.execute("INSERT INTO sys_entity_lemma VALUES(1,9,'G5485','LIVE')")
    d.commit()
    t('★★ 이미 사람 용어면 할 일에서 빠진다',
      not [r for r in todo(d) if r['strong'] == 'G5485'])
    t('  그래도 목록에는 상태가 적힌다',
      next((r['kind'] for r in plan(d) if r['strong'] == 'G5485'), None) == 'TERM')

    # ★ 이름 겹침을 잡는다
    d.execute("INSERT INTO sys_text_asset VALUES(9,'ENTITY_NAME','KO',"
              "'은혜 · 카리스','LIVE')")
    d.commit()
    # ★★★ **둘째 잣대 — 음역 대조.** 실 DB 에서 실제로 틀렸던 둘을 재료로.
    t('★★★ 맞는 음역은 통과 (카리스 ↔ cháris)',
      translit_match('카리스', 'cháris') >= MIN_TR,
      translit_match('카리스', 'cháris'))
    t('  덧기호를 걷는다 (아가페 ↔ agápē 는 온전히 같다)',
      translit_match('아가페', 'agápē') == 1.0)
    t('★★★ **틀린 짝을 잡는다** (멜로스 ↔ sōma — 실 DB 에서 나온 오답)',
      translit_match('멜로스', 'sōma') < MIN_TR,
      translit_match('멜로스', 'sōma'))
    t('★★★ **괄호 안이 음역이 아닌 것을 잡는다** (선물(은혜) ↔ keçeph)',
      translit_match('은혜', 'keçeph') < MIN_TR,
      translit_match('은혜', 'keçeph'))
    t('  재료가 비면 0 (모르면 0.5 가 아니다)',
      translit_match('', 'charis') == 0.0 and translit_match('카리스', '') == 0.0)

    # ★★★ **셋째 잣대 — 이름이 표제어 꼴인가** (실 DB 에서 나온 보기로)
    t('★★ 활용형을 잡는다 (서라·좇으라·버렸다)',
      all(looks_inflected(x) for x in ('서라', '좇으라', '버렸다', '담대히')))
    t('★★ **사전형 동사는 통과** (믿다·섬기다·생각하다)',
      not any(looks_inflected(x) for x in ('믿다', '섬기다', '생각하다')))
    t('★★ 조각을 잡는다 (자·것)',
      looks_inflected('자') and looks_inflected('것'))
    t('★★ **한 글자라도 멀쩡한 낱말은 통과** (불·손·샘·복)',
      not any(looks_inflected(x) for x in ('불', '손', '샘', '복')))
    t('★ 문법 낱말 목록에 까닭이 적혀 있다',
      all(FUNCTION_WORDS.values()) and 'G2443' in FUNCTION_WORDS)

    t('★★ 이름이 겹치면 알린다',
      name_clash(d, ['은혜 · 카리스', '새 이름']) == ['은혜 · 카리스'],
      name_clash(d, ['은혜 · 카리스', '새 이름']))
    t('  안 겹치면 조용하다', name_clash(d, ['새 이름']) == [])
    d.close()

    print('\ndb_term_cite selftest %d/%d' % (ok, ok + fail))
    return fail == 0


# ── CLI ───────────────────────────────────────────────────────────────
def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:                                     # noqa: BLE001
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--limit', type=int)
    ap.add_argument('--min-verses', type=int, default=MIN_VERSES)
    a = ap.parse_args()

    if a.selftest:
        sys.exit(0 if selftest() else 1)

    conn = appdb.connect()
    pl = plan(conn, min_verses=a.min_verses)
    td = [d for d in pl if _clean(d)]
    sh = [(d, ('문법 낱말 — ' + d['func']) if d['func'] else
           ('이름이 활용형·조각' if d['inflected'] else
            '음역 %.2f' % d['tr_score']))
          for d in pl if d['kind'] != 'TERM' and not _clean(d)]
    clash = name_clash(conn, [d['name'] for d in td])
    print('우리 글이 이름을 댄 낱말 %d가지 · 그중 아직 용어가 아닌 것 **%d**'
          % (len(pl), len(td)))
    print('  (이미 사람 용어 %d · 엔티티 없음 %d · 기계 낱말 %d)'
          % (sum(1 for d in pl if d['kind'] == 'TERM'),
             sum(1 for d in td if d['kind'] is None),
             sum(1 for d in td if d['kind'] == 'W')))
    if clash:
        print('  ⚠ 이름이 겹치는 것 %d개 — 그대로 두면 훑기 목록에서 구별이 '
              '안 된다: %s' % (len(clash), ', '.join(clash[:8])))
    if sh:
        print('  ⚠ **기계가 이름을 못 짓는 것 %d개** — 사람이 본다:' % len(sh))
        for d, why in sh:
            print('      %-7s %-24s ↔ %-14s  %-22s %s'
                  % (d['strong'], d['name'], d['latin'], why,
                     (d['gloss'] or '')[:26]))

    if a.check or not a.apply:
        for d in (td[:a.limit] if a.limit else td):
            print('  %-7s %-24s %3d절 share %.2f lift %7.1f 음역 %.2f  %-14s %s%s'
                  % (d['strong'], d['name'], d['n_cite'], d['share'], d['lift'],
                     d['tr_score'], d['latin'], (d['gloss'] or '')[:30],
                     ('  · 다른 이름 ' + '·'.join(d['alt'])) if d['alt'] else ''))
        return

    td = [d for d in td if d['name'] not in clash]
    done, bad = apply(conn, td, limit=a.limit)
    print('\n승격 %d개 · 실패 %d개' % (len(done), len(bad)))


if __name__ == '__main__':
    main()
