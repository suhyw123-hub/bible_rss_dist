# -*- coding: utf-8 -*-
"""앱 소개 — 관리자가 글만 관리하고 저절로 보낸다(2026-10-21 · docs/1.txt 3번).

★ 사용자 「관리자화면에서 관리하고 필요할 때 자동전송 되는 방식 · 단순한 텍스트 관리만」 ·
  「기본형식을 네 제안대로 · 이름 등은 내가 수정 · 이메일도 가상으로 서식처럼 · 후원안내도 간단하게」.
  · 칸(sec_key) 마다 언어별 제목·본문·링크 한 줄. 차례는 `SECTIONS`.
  · 출처·라이선스 · 문제 신고 단추 · 앱 판 번호는 **앱 코드**가 그린다(여기는 안내 글만).
  · 보내는 길 = 날마다 자동 배포의 한 종류(`rss_publish` kind `appinfo` · 파일 app_info.json · 바뀐 것 없으면 안 보냄) +
    모바일 공통팩(처음 깐 폰의 바탕).

표 `sys_app_info(sec_key, lang_code, title, body, link, sort_order)` PK(sec_key, lang_code) · 판 = sys_config['APP_INFO_VER']

  python app_info.py --selftest | --seed [--force] | --export
"""
import json
import sys
import time

VER_KEY = 'APP_INFO_VER'

#: (칸 열쇠, 차례) — 화면은 이 차례로 그린다
SECTIONS = [('INTRO', 10), ('MAKER', 20), ('HOME', 30), ('PRIVACY', 40), ('TERMS', 50),
            ('REPORT', 60), ('DONATE', 70)]

SEED = {
    'KO': {
        'INTRO': ('Hagah Dabar 소개',
                  'Hagah Dabar 는 「말씀(다바르)을 읊조리며 묵상한다(하가)」는 뜻입니다(시편 1:2).\n'
                  '성경 본문과 쉬운 설명, 묵상질문과 기도, 연결된 구절, 묵상플랜을 한자리에 모아 '
                  '날마다 말씀을 읽고 묵상하도록 돕는 앱입니다. PC 앱과 함께 쓰면 PC 에서 정리한 것을 폰에서 이어 볼 수 있습니다.', ''),
        'MAKER': ('만든 사람', '개발·운영: 홍길동 (Hagah Dabar 팀)\n연락: contact@example.com', ''),
        'HOME': ('홈페이지', '앱 안내와 새 소식은 홈페이지에서 볼 수 있습니다.', 'https://www.example.com'),
        'PRIVACY': ('개인정보 처리방침(요약)',
                    '· 묵상노트 · 기도 · AI 대화 같은 내 글은 내 폰과 내 PC 에만 있고, 우리 서버로 보내지 않습니다.\n'
                    '· 기도 노트는 폰에만 있고 백업에서도 빠집니다.\n'
                    '· AI 를 쓰면 질문이 내가 고른 AI 회사로 바로 갑니다. 하가는 그 내용을 받지 않습니다.\n'
                    '· AI 키는 그 기기에만 저장합니다.\n'
                    '· 이용통계는 동의했을 때만 익명 집계로 보냅니다.', 'https://www.example.com/privacy'),
        'TERMS': ('이용약관(요약)',
                  '· 이 앱은 무료로 제공되며, 성경 묵상과 공부를 돕는 것을 목적으로 합니다.\n'
                  '· 앱에 담긴 자료의 저작권은 각 출처를 따릅니다(출처·라이선스 참고).\n'
                  '· AI 의 답은 참고 자료이며 틀릴 수 있습니다. 중요한 판단은 성경 본문과 교회의 가르침으로 확인하세요.\n'
                  '· 앱을 더 낫게 하려고 내용과 기능이 예고 없이 바뀔 수 있습니다.', 'https://www.example.com/terms'),
        'REPORT': ('문제 신고 · 제안',
                   '오류를 발견했거나 바라는 기능이 있으면 알려 주세요. 어떤 화면에서 무엇을 했을 때 어떻게 되었는지 적어 주시면 빨리 고칠 수 있습니다.',
                   'mailto:contact@example.com'),
        'DONATE': ('후원 안내',
                   'Hagah Dabar 는 광고 없이 운영됩니다. 기도와 후원으로 함께해 주시면 자료를 늘리고 앱을 더 좋게 만드는 데 쓰겠습니다.\n'
                   '후원 계좌: ○○은행 000-0000-0000 (예금주: 홍길동)', 'https://www.example.com/donate'),
    },
    'EN': {
        'INTRO': ('About Hagah Dabar',
                  'Hagah Dabar means "to murmur and meditate (hagah) on the Word (dabar)" (Psalm 1:2).\n'
                  'The app gathers the Bible text, plain explanations, reflection questions and prayers, linked verses and '
                  'reading plans in one place to help you read and meditate on Scripture every day. Used with the PC app, '
                  'what you organize on the PC continues on your phone.', ''),
        'MAKER': ('Made by', 'Development: Gildong Hong (Hagah Dabar team)\nContact: contact@example.com', ''),
        'HOME': ('Website', 'Guides and news are on our website.', 'https://www.example.com'),
        'PRIVACY': ('Privacy policy (summary)',
                    '· Your notes, prayers and AI chats stay on your phone and PC; we do not send them to our server.\n'
                    '· The prayer notebook stays on the phone and is left out of backups.\n'
                    '· When you use AI, your question goes straight to the AI company you chose; Hagah does not receive it.\n'
                    '· AI keys are stored only on that device.\n'
                    '· Usage statistics are sent only with your consent, as anonymous totals.', 'https://www.example.com/privacy'),
        'TERMS': ('Terms of use (summary)',
                  '· The app is free and aims to help Bible meditation and study.\n'
                  '· Copyright of included materials follows each source (see Sources & licenses).\n'
                  '· AI answers are for reference and may be wrong; check important matters against Scripture and your church.\n'
                  '· Content and features may change without notice to improve the app.', 'https://www.example.com/terms'),
        'REPORT': ('Report a problem · Suggest',
                   'Found a bug or want a feature? Tell us which screen, what you did and what happened.',
                   'mailto:contact@example.com'),
        'DONATE': ('Support us',
                   'Hagah Dabar runs without ads. Your prayers and support help us add materials and improve the app.',
                   'https://www.example.com/donate'),
    },
}


def init(conn):
    conn.execute("CREATE TABLE IF NOT EXISTS sys_app_info (sec_key TEXT NOT NULL, lang_code TEXT NOT NULL,"
                 " title TEXT, body TEXT, link TEXT, sort_order INTEGER DEFAULT 0, PRIMARY KEY(sec_key, lang_code))")


def version(conn):
    r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?", (VER_KEY,)).fetchone()
    try:
        return int(r[0]) if r else 0
    except (TypeError, ValueError):
        return 0


def _bump(conn):
    v = version(conn) + 1
    conn.execute("INSERT OR REPLACE INTO sys_config(config_key, config_val) VALUES(?,?)", (VER_KEY, str(v)))
    return v


def seed(conn, force=False):
    """처음 판 — 칸이 이미 있으면 안 덮는다(관리자가 고친 것) · force 면 덮는다."""
    init(conn)
    order = dict(SECTIONS)
    n = 0
    for lang, secs in SEED.items():
        for k, (t, b, l) in secs.items():
            have = conn.execute("SELECT 1 FROM sys_app_info WHERE sec_key=? AND lang_code=?", (k, lang)).fetchone()
            if have and not force:
                continue
            conn.execute("INSERT OR REPLACE INTO sys_app_info(sec_key, lang_code, title, body, link, sort_order)"
                         " VALUES(?,?,?,?,?,?)", (k, lang, t, b, l, order[k]))
            n += 1
    if n:
        _bump(conn)
    conn.commit()
    return n


def get(conn, sec, lang):
    init(conn)
    r = conn.execute("SELECT title, body, link FROM sys_app_info WHERE sec_key=? AND lang_code=?", (sec, lang)).fetchone()
    return (r[0] or '', r[1] or '', r[2] or '') if r else ('', '', '')


def save(conn, sec, lang, title, body, link):
    """한 칸 저장 — 글이 실제로 바뀌었을 때만 판을 올린다(안 바뀌면 발행도 SKIP)."""
    init(conn)
    old = get(conn, sec, lang)
    new = ((title or '').strip(), (body or '').strip(), (link or '').strip())
    if old == new:
        return False
    if not any(new):
        conn.execute("DELETE FROM sys_app_info WHERE sec_key=? AND lang_code=?", (sec, lang))
    else:
        conn.execute("INSERT OR REPLACE INTO sys_app_info(sec_key, lang_code, title, body, link, sort_order)"
                     " VALUES(?,?,?,?,?,?)", (sec, lang) + new + (dict(SECTIONS).get(sec, 99),))
    _bump(conn)
    conn.commit()
    return True


def export_payload(conn):
    """보내는 꾸러미 — {ver, sections:[{key, sort, text:{LANG:{title, body, link}}}]}"""
    init(conn)
    secs = {}
    for k, lg, t, b, l, so in conn.execute(
            "SELECT sec_key, lang_code, title, body, link, sort_order FROM sys_app_info ORDER BY sort_order, sec_key"):
        d = secs.setdefault(k, {'key': k, 'sort': so, 'text': {}})
        d['text'][lg] = {'title': t or '', 'body': b or '', 'link': l or ''}
    return {'ver': version(conn), 'sections': sorted(secs.values(), key=lambda x: (x['sort'], x['key']))}


def export_json(conn):
    return json.dumps(export_payload(conn), ensure_ascii=False, indent=1, sort_keys=True) + '\n'


def selftest():
    import sqlite3
    ok = []

    def ck(c, m):
        ok.append(bool(c))
        print(('PASS ' if c else 'FAIL ') + m)

    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE sys_config (config_key TEXT PRIMARY KEY, config_val TEXT)")
    n = seed(c)
    ck(n == sum(len(v) for v in SEED.values()), '처음 판 %d' % n)
    v1 = version(c)
    ck(v1 == 1, '판 1')
    ck(seed(c) == 0 and version(c) == v1, '두 번째는 안 덮고 판도 그대로')
    ck(not save(c, 'MAKER', 'KO', *get(c, 'MAKER', 'KO')), '같은 글은 저장 안 함')
    ck(save(c, 'MAKER', 'KO', '만든 사람', '개발: 김하가', '') and version(c) == v1 + 1, '고치면 판이 오른다')
    p = export_payload(c)
    ck([s['key'] for s in p['sections']] == [k for k, _ in SECTIONS], '칸 차례')
    ck(p['sections'][1]['text']['KO']['body'] == '개발: 김하가', '꾸러미에 고친 글')
    ck(export_json(c) == export_json(c), '같은 글이면 같은 파일(지문 같음)')
    ck(all('@' not in (p2 or '') or 'example.com' in p2 for p2 in [get(c, 'REPORT', 'KO')[2]]), '가상 이메일')
    print('app_info %d/%d' % (sum(ok), len(ok)))
    return all(ok)


def main(argv):
    if not argv or argv[0] == '--selftest':
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect()
    if argv[0] == '--seed':
        print('심음', seed(conn, force='--force' in argv), '판', version(conn))
    elif argv[0] == '--export':
        print(export_json(conn))


if __name__ == '__main__':
    main(sys.argv[1:])
