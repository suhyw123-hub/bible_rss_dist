import sqlite3
import appdb
import traceback
import json
from shared_map import NAV_REGISTRY, RELATION_GATES

class MasterIntegrityTester:
    def __init__(self, db_path):
        self.db_path = db_path
        self.conn = appdb.connect(db_path)
        
    def check_terminology_sync(self):
        """DB의 용어와 자산맵의 용어가 일치하는지 검증합니다."""
        print("[진단 1] 용어 일치성 검사 시작...")
        # 자산맵에 정의된 모든 유효 text_type 추출
        valid_types = {v['filter']['text_type'] for k, v in NAV_REGISTRY.items() if v['tgt'] == 'TEXT'}
        
        cursor = self.conn.cursor()
        cursor.execute("SELECT DISTINCT text_type FROM sys_text_asset UNION SELECT DISTINCT text_type FROM user_text_asset")
        db_types = {row[0] for row in cursor.fetchall()}
        
        diff = db_types - valid_types
        if diff:
            print(f"❌ 오류: 자산맵에 정의되지 않은 용어가 DB에 존재합니다: {diff}")
            return False
        print("✅ PASS: 모든 용어가 자산맵과 일치합니다.")
        return True

    def check_vers_vers_alignment(self):
        """VERS_VERS 데이터가 [작은ID:큰ID] 순서로 정렬되어 있는지 검증합니다."""
        print("[진단 2] VERS_VERS 정렬 검사 시작...")
        cursor = self.conn.cursor()
        bad_data = []
        for table in ['sys_link_asset', 'user_link_asset']:
            cursor.execute(f"SELECT * FROM {table} WHERE link_type='VERS_VERS' AND clicked_id > target_id")
            bad_data.extend(cursor.fetchall())
            
        if bad_data:
            print(f"❌ 오류: 정렬되지 않은 VERS_VERS 데이터가 {len(bad_data)}건 발견되었습니다.")
            return False
        print("✅ PASS: 모든 VERS_VERS 데이터가 올바르게 정렬되었습니다.")
        return True

    def log_diagnostic(self, phase, category, scenario, status, error="", context=""):
        """진단 결과를 DB에 기록하여 나중에 대시보드로 확인합니다."""
        cursor = self.conn.cursor()
        cursor.execute("""
            INSERT INTO sys_diag_logs (phase, category, scenario_name, status, error_stack, context_data)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (phase, category, scenario, status, error, context))
        self.conn.commit()

# 실행 예시
if __name__ == "__main__":
    tester = MasterIntegrityTester("bible_master.db")
    if tester.check_terminology_sync() and tester.check_vers_vers_alignment():
        print("\n🏆 시스템 무결성 진단 통과! 통합 개발을 시작해도 좋습니다.")
    else:
        print("\n⚠️ 진단 실패: 위 오류를 먼저 수정해야 합니다.")


