# -*- coding: utf-8 -*-
"""branch_tabs.py — 탭 안 「갈래 단추」 줄 (2026-08-19 탭모음 4탭 통합).

세 탭모음(P2 · 캔버스/트리뷰 오른쪽)을 4탭으로 합치면서, 합쳐진 탭 안을
서브 노트북이 아니라 **갈래 단추**로 가른다(사용자 승인). 근거 셋:
  ① 노트북 속 노트북은 탭 줄이 두 줄 겹쳐 어디가 상위인지 혼란스럽다.
  ② 이 앱의 문법이 이미 갈래 단추다 — 도서/설교 1단(27px·노트북 탭 서식).
  ③ 단추에는 개수 (N) 를 자연스럽게 넣을 수 있다.

사용:
    bt = BranchTabs(parent, db_path=DB, state_key='P4_NODE_BR_NOTE')
    f1 = bt.frame_for('refr');  RefUnifiedPanel(f1, ...).pack(...)
    f2 = bt.frame_for('note');  NoteRefrPanel(f2, ...).pack(...)
    bt.add('refr', 'TAB_INTERNAL', '내부자료')
    bt.add('note', 'TAB_NOTE', '묵상노트')
    bt.finish()                      # 직전값(또는 첫 갈래) 선택
    bt.set_count('note', 3)          # 단추 라벨 ' 묵상노트 (3) '

  · **줄이 둘일 수 있다** (2026-09-15 · `1.txt` 6번 P2 분해) —
    `BranchTabs(parent, rows=2)` 로 만들고 `add(..., row=1)` 로 둘째 줄에 둔다.
    ⚠ **자동 줄바꿈이 아니다.** 창 폭에 따라 줄 수가 바뀌면 본문 높이가 함께
      흔들리고 어느 줄이 활성인지 읽기 어렵다(사용자 물음에 낸 의견). 줄은
      만들 때 **고정**이고, 좁은 자리(NodePanel 420px)만 둘로 만든다.
    ⚠ `ttk.Notebook` 은 탭을 줄바꿈하지 않는다 — 실측 420px 에 러시아어 열
      탭을 넣어도 **한 줄에 눌러 담고 글자를 잘라 버린다.** 그래서 이 부품이다.

규칙:
  · 전환은 pack_forget — 패널 상태(스크롤·입력)가 산다(§3 캔버스/트리뷰 방식).
  · 단추 줄 = 27px 고정(노트북 탭 줄 실측) · bd=0 · 색은 ui_theme 역할에서
    그때그때(활성 dark_bg+fg_on_dark / 비활성 panel_alt+fg — 테마 추종).
  · state_key 를 주면 user_config 에 직전 갈래를 기억한다.
"""

import tkinter as tk

BAR_H = 27          # 노트북 탭 줄 실측(clam) — p1_reading_view 갈래 줄과 동일


def _colors():
    try:
        import ui_theme
        return ((ui_theme.C('dark_bg'), ui_theme.C('fg_on_dark')),
                (ui_theme.C('panel_alt'), ui_theme.C('fg')))
    except Exception:
        return (('#5D6D7E', '#FFFFFF'), ('#ECECEC', '#000000'))


def _border():
    """단추 테두리 색 — P1 노트북 탭(`TNotebook.Tab` bordercolor)과 같은 역할."""
    try:
        import ui_theme
        return ui_theme.C('border')
    except Exception:
        return '#C8C8C8'


#: 단추 안 여백 — `ui_theme.apply_notebook_tabs` 의 `TNotebook.Tab` padding=(10, 3)
#: 과 **같은 값**. 2026-09-16 사용자 「P1 의 탭 메뉴와 규격이 비슷하게」.
#: ★ 가로 여백은 **줄 폭에 맞춰 줄어든다**(10 → 8 → 6 → 4) — P1 은 1,000px 인데
#:   P2 는 565px(실측 · 사용자 배치)이고 러시아어는 같은 다섯 갈래가 455px 다.
#:   안 줄이면 마지막 단추가 잘린다. 세로 여백은 안 건드린다(줄 높이가 흔들린다).
TAB_PADX, TAB_PADY = 10, 3
PADX_STEPS = (10, 8, 6, 4, 3, 2)   # 3·2 는 마지막 수단(P2 552px · KO 도구 233px 에서 1px 모자랐다 · 2026-09-16)


class BranchTabs(tk.Frame):

    def __init__(self, parent, db_path=None, state_key=None,
                 on_change=None, rows=1, **kw):
        super().__init__(parent, **kw)
        self.db_path = db_path
        self.state_key = state_key
        self.on_change = on_change
        self._items = {}        # key → {'btn','frame','i18n','dflt','count','row'}
        self._order = []
        self._cur = None

        # ★ 줄은 만들 때 고정(rows) — 위 머리말 참조. 첫 줄이 `bar()` 다.
        self._bars = []
        self._padx = {}                  # 줄 → 지금 쓰는 가로 여백
        for _r in range(max(1, int(rows or 1))):
            _b = tk.Frame(self, height=BAR_H)
            _b.pack(fill='x')
            _b.pack_propagate(False)     # 단추가 줄 높이를 못 바꾼다
            _b.bind('<Configure>', lambda e: self.refit_later(), add='+')
            self._bars.append(_b)
            self._padx[_r] = TAB_PADX
        self._bar = self._bars[0]
        # ★★★ **[M] 자리를 먼저 잡아 둔다** (2026-08-30 — `desc_comm_group` 과
        #   같은 문법). `pack(side='right')` 는 **부른 차례로 오른쪽부터** 쌓이므로
        #   나중에 붙는 M 이 오히려 왼쪽으로 간다. 빈 프레임을 가장 먼저 못 박고
        #   호스트는 `manual_slot()` **안에** 심는다 — 붙이는 차례가 자리를 못 바꾼다.
        self._m_slot = tk.Frame(self._bar)
        self._m_slot.pack(side='right', padx=(0, 2))
        self._body = tk.Frame(self)
        self._body.pack(fill='both', expand=True)

    # ── 구성 ─────────────────────────────────────────────────────────

    def bar(self, row=0):
        """단추 줄 프레임 — 갈래 오른쪽에 도구(Focus 등)를 붙일 때 쓴다.

        ⚠ 여기에 `side='right'` 로 붙이면 **[M] 보다 왼쪽**에 놓인다(그것이
          바라는 자리다). M 자체는 `manual_slot()` 안에 심는다.
        `row` — 둘째 줄이 있으면 그 줄(0 이 첫 줄)."""
        return self._bars[min(max(0, int(row)), len(self._bars) - 1)]

    def rows(self):
        return len(self._bars)

    def set_bar_visible(self, on, row=0):
        """단추 줄을 보이거나 감춘다 — **몸통은 그대로 둔다**.

        쓰는 자리 = 주요용어 「더보기」(통합탭이면 갈래 줄이 뜻이 없다).
        ⚠ 다시 붙일 때 **몸통 앞**이라야 줄이 위로 간다(`pack` 은 붙인 차례로
          자리를 준다 — 그냥 붙이면 목록 아래로 내려간다)."""
        b = self.bar(row)
        if on:
            if not b.winfo_manager():
                b.pack(fill='x', before=self._body)
        elif b.winfo_manager():
            b.pack_forget()

    def manual_slot(self):
        """[M] 을 심을 자리 — **줄의 맨 오른쪽으로 못 박아 둔 빈 프레임**."""
        return self._m_slot

    def frame_for(self, key):
        """이 갈래의 내용을 담을 프레임 — 패널은 이 안에 pack 한다."""
        it = self._items.get(key)
        if it is None:
            it = {'frame': tk.Frame(self._body), 'btn': None,
                  'i18n': '', 'dflt': key, 'count': None, 'row': 0}
            self._items[key] = it
        return it['frame']

    def add(self, key, i18n_key, default_label, share_with=None, row=0):
        """갈래 단추 등록. frame_for(key) 를 먼저/나중 어느 쪽에 불러도 된다.

        share_with — 다른 갈래와 **같은 프레임**을 쓴다 (2026-08-19 3갈래:
        연구자료/내부연결이 RefUnifiedPanel 하나를 공유하고 scope 만 바꾼다).
        전환 판정이 프레임 단위라 형제 갈래로 옮겨도 위젯이 안 사라진다.
        row — 단추를 둘 줄(0 이 첫 줄 · `rows` 보다 크면 마지막 줄)."""
        self.frame_for(key)
        it = self._items[key]
        if share_with and share_with in self._items:
            it['frame'] = self._items[share_with]['frame']
        it['i18n'], it['dflt'] = i18n_key, default_label
        row = min(max(0, int(row or 0)), len(self._bars) - 1)
        it['row'] = row
        first = not any(self._items[k]['row'] == row for k in self._order)
        # ★★ **P1 노트북 탭과 같은 규격** (2026-09-16 사용자 「P1 의 탭 메뉴와
        #   규격이 비슷하게」 · 1.txt 19-1) — 여백 (10, 3) · 테두리 1px(테마
        #   `border`) · 고른 것은 진한 바탕. 노트북 위젯 자체로는 못 바꾼다 —
        #   더보기 안 줄을 눌렀을 때만 보이기 · 갈래 감추기 · 배지가 거기 없다.
        #   ⚠ 2026-09-15 에 예산 때문에 padx 6 으로 줄였던 것을 되돌렸다 — 지금은
        #     윗줄이 주 탭 넷 + 더보기뿐이라 자리가 있다(하네스가 11언어를 잰다).
        #   ⚠ `highlightthickness` 가 테두리다 — `relief='solid'` 는 검정으로만
        #     그려져 테마를 안 탄다.
        b = tk.Button(self._bars[row], bd=0, relief='flat',
                      padx=self._padx.get(row, TAB_PADX), pady=TAB_PADY,
                      highlightthickness=1, highlightbackground=_border(),
                      highlightcolor=_border(),
                      cursor='hand2', command=lambda k=key: self.select(k))
        b.pack(side='left', padx=(0 if first else 2, 0))
        it['btn'] = b
        self._order.append(key)
        self._set_btn_text(key)

    def finish(self):
        """등록이 끝났다 — 직전값(state_key) 또는 첫 갈래를 편다."""
        want = self._load_state()
        self.select(want if want in self._items else
                    (self._order[0] if self._order else None), save=False)

    # ── 동작 ─────────────────────────────────────────────────────────

    def select(self, key, save=True):
        if key is None or key not in self._items:
            return
        self._cur = key
        # ⚠ 프레임 공유(share_with) 대비 — 판정은 열쇠가 아니라 **프레임 동일성**
        chosen = self._items[key]['frame']
        for it in self._items.values():
            if it['frame'] is chosen:
                continue
            it['frame'].pack_forget()
        if not chosen.winfo_manager():
            chosen.pack(fill='both', expand=True)
        self._sync_btns()
        if save:
            self._save_state(key)
        if callable(self.on_change):
            try:
                self.on_change(key)
            except Exception:
                pass

    def current(self):
        return self._cur

    def set_visible(self, key, on):
        """갈래 단추를 보이거나 감춘다 — **빈 서랍 금지**(§0-1).

        ⚠ **차례를 지킨다** — `pack` 은 다시 붙이면 맨 뒤로 간다. 뒤에 있는
          보이는 단추 **앞에** 붙여 등록 차례를 지킨다.
        ⚠ **지금 보고 있는 갈래를 감추면** 다른 갈래로 옮긴다(감춘 화면이
          그대로 남아 있으면 「없는 갈래를 보고 있는」 꼴이 된다).
        """
        it = self._items.get(key)
        if it is None or it['btn'] is None:
            return
        b = it['btn']
        shown = bool(b.winfo_manager())
        if bool(on) == shown:
            return
        if on:
            nxt = None
            after = False
            for k in self._order:
                if k == key:
                    after = True
                    continue
                if after and self._items[k]['btn'] is not None                         and self._items[k]['row'] == it['row']                         and self._items[k]['btn'].winfo_manager():
                    nxt = self._items[k]['btn']
                    break
            if nxt is not None:
                b.pack(side='left', padx=(2, 0), before=nxt)
            else:
                b.pack(side='left', padx=(2, 0))
        else:
            b.pack_forget()
            if self._cur == key:
                for k in self._order:
                    if k != key and self._items[k]['btn'] is not None                             and self._items[k]['btn'].winfo_manager():
                        self.select(k)
                        break

    def set_count(self, key, n):
        """단추 라벨에 (N). None = 개수 없이(빈칸 = 있음 규칙)."""
        it = self._items.get(key)
        if it is None:
            return
        it['count'] = n
        self._set_btn_text(key)

    # ── 내부 ─────────────────────────────────────────────────────────

    def _set_btn_text(self, key):
        it = self._items[key]
        if it['btn'] is None:
            return
        try:
            import i18n
            base = i18n.t(it['i18n'], it['dflt']) if it['i18n'] else it['dflt']
        except Exception:
            base = it['dflt']
        # ★ 많으면 「9+」 — 탭 배지와 **같은 문**을 쓴다(갈리면 탭과 갈래가
        #   다른 수를 말한다). 2026-09-09 사용자 확정.
        try:
            import p4_node_panel as _np
            n = _np.badge(it['count'])
        except Exception:
            n = None if it['count'] is None else str(it['count'])
        # ★ 배지는 **괄호** — 「주석(9+)」 (2026-09-16 사용자 「괄호가 사라졌다.
        #   주석(9+)와 같이 표시하라」). 255차의 「이름 N」을 되돌렸다.
        it['btn'].config(text=('%s(%s)' % (base, n)) if n is not None else base)

    def _fit_padx(self, row):
        """줄 폭에 맞는 가장 넉넉한 가로 여백을 선택한다(10 → 8 → 6 → 4).

        계산 — 단추 글자 폭(지금 reqwidth − 2·지금 여백)의 합 + 단추 사이 2px +
        그 줄의 **다른 것들**(도구 칸 등 pack 된 비단추) 폭 ≤ 줄 폭.
        ⚠ 여백이 실제로 바뀔 때만 config 한다 — `<Configure>` 가 되돌아 도는
          고리를 끊는다."""
        try:
            bar = self._bars[row]
            w = bar.winfo_width()
            if w <= 1:
                return
            btns = [it['btn'] for k, it in self._items.items()
                    if it['row'] == row and it['btn'] is not None
                    and it['btn'].winfo_manager()]
            if not btns:
                return
            cur = self._padx.get(row, TAB_PADX)
            base = sum(b.winfo_reqwidth() - 2 * cur for b in btns) + 2 * (len(btns) - 1)
            others = sum(c.winfo_reqwidth() for c in bar.winfo_children()
                         if c.winfo_manager() and c not in btns) + 6
            pick = PADX_STEPS[-1]
            for p in PADX_STEPS:
                if base + 2 * p * len(btns) + others <= w:
                    pick = p
                    break
            if pick != cur:
                self._padx[row] = pick
                for b in btns:
                    b.config(padx=pick)
        except Exception as e:
            print('[branch_tabs fit_padx] %s' % e)

    def refit(self):
        """밖에서 줄의 내용이 바뀌었을 때(도구 칸이 붙거나 떨어짐) 다시 맞춘다."""
        for r in range(len(self._bars)):
            self._fit_padx(r)

    def refit_later(self, ms=40):
        """기하가 가라앉은 뒤 한 번만(SplitTabs 와 같은 까닭)."""
        try:
            if getattr(self, '_fit_after_id', None):
                self.after_cancel(self._fit_after_id)
            self._fit_after_id = self.after(ms, self._refit_now)
        except Exception:
            pass

    def _refit_now(self):
        self._fit_after_id = None
        try:
            self.update_idletasks()
        except Exception:
            pass
        self.refit()

    def _sync_btns(self):
        on, off = _colors()
        bd = _border()
        for k, it in self._items.items():
            b = it['btn']
            if b is None:
                continue
            bg, fg = on if k == self._cur else off
            try:
                b.config(bg=bg, fg=fg, activebackground=bg, activeforeground=fg,
                         highlightbackground=bd, highlightcolor=bd)
            except Exception:
                pass

    def _load_state(self):
        if not (self.db_path and self.state_key):
            return None
        try:
            import appdb
            with appdb.connect(self.db_path) as c:
                r = c.execute("SELECT config_val FROM user_config "
                              "WHERE config_key=?", (self.state_key,)).fetchone()
            return r[0] if r and r[0] else None
        except Exception:
            return None

    def _save_state(self, key):
        if not (self.db_path and self.state_key):
            return
        try:
            import appdb
            with appdb.connect(self.db_path) as c:
                c.execute("INSERT INTO user_config (config_key, config_val) VALUES (?,?) "
                          "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                          (self.state_key, key))
                c.commit()
        except Exception:
            pass



class _Tier:
    """`SplitTabs` 의 한 층(윗줄 · 더보기 안 줄)을 **BranchTabs 처럼** 보이게 하는 창.

    하네스·옛 호출부가 `T._top._order` · `T._inner._items[k]['btn']` ·
    `T._top.frame_for('MORE')` · `T._top._padx[0]` 을 읽는다. 층은 이제 단추 줄일
    뿐이고 내용 프레임은 `SplitTabs` 가 한 몸통에 두므로(살아서 주 탭을 바꾸기
    위해서다 — 2026-09-16 19-2), 그 이름들을 여기서 그대로 낸다.
    """

    def __init__(self, owner, tier):
        self._o, self._t = owner, tier

    @property
    def _order(self):
        o = [k for k in self._o._order if self._o._items[k]['tier'] == self._t]
        if self._t == 'TOP' and self._o._more_btn is not None:
            o.append(self._o.more_key)
        return o

    @property
    def _items(self):
        d = {k: self._o._items[k] for k in self._order if k in self._o._items}
        if self._t == 'TOP' and self._o._more_btn is not None:
            d[self._o.more_key] = {'btn': self._o._more_btn, 'count': None,
                                   'frame': self._o._inner_bar, 'row': 0,
                                   'i18n': self._o._more[0], 'dflt': self._o._more[1]}
        return d

    @property
    def _padx(self):
        return {0: self._o._padx[self._t]}

    def current(self):
        if self._t == 'TOP':
            return self._o.more_key if self._o._more_open else self._o._cur
        return self._o._cur if self._o._more_open else None

    def frame_for(self, key):
        if key == self._o.more_key:
            return self._o._inner_bar
        return self._o.frame_for(key)

    def winfo_manager(self):
        return self._o._inner_bar.winfo_manager() if self._t == 'IN' else 'pack'

    def bar(self):
        return self._o._top_bar if self._t == 'TOP' else self._o._inner_bar

    def _set_btn_text(self, key):
        self._o._set_btn_text(key)

    def refit(self):
        self._o._fit_padx(self._t)


class SplitTabs(tk.Frame):
    """주 탭 몇 + **「더보기」 하나에 나머지를 결합** (2026-09-15 · `1.txt` 6번 —
    사용자 「탭을 항상 2열로 만든 것은 절대로 안 된다 … 설명/주석/원어/묵상노트
    이외의 다른 것들을 하나의 탭 내부에 결합하는 방안」 + 4번 「사용자가 선호하는
    것을 표시하도록 설정 … 제외된 것은 묶어서 한 탭에」).

    겉으로는 BranchTabs 와 같은 문(frame_for · add · finish · select · current ·
    set_count · set_visible · bar · manual_slot)이라 부르는 쪽이 어느 갈래가 주
    탭인지 몰라도 된다.
      · `main` 에 든 열쇠는 윗줄에, 나머지는 더보기 안에. **더보기는 늘 맨 뒤.**
      · 더보기 안의 줄은 **더보기를 눌렀을 때만** 보인다 — 늘 두 줄이 아니다.
      · `current()` 는 실제로 보이는 갈래(더보기 안이면 그 안의 것).
      · **더보기 단추에 안의 합계를 적는다**(2026-09-17 사용자 「더보기 눌렀는데
        아무것도 없으면 허탈」) — 안의 갈래는 눌러야 보이므로 빈칸은 「있음」이
        아니라 **「모름」**이었다. 셀 수 없는 갈래는 합계에서 빠진다.

    ★★★ **2026-09-16 다시 지었다 — 내용 프레임은 한 몸통에, 층은 단추 줄뿐.**
      (1.txt 19-2 사용자 「사용자가 직접 표시대상 선택기능을 개발한 후에 …」)
      그전에는 층마다 BranchTabs 가 제 몸통을 가져 갈래의 내용이 **그 층의 프레임
      안에** 살았다. 그러면 설정에서 주 탭을 바꿔도 내용을 다른 층으로 **옮길 수
      없어**(Tk 는 자식을 다른 부모로 못 옮긴다) 앱을 다시 켜야 했다.
      이제 `set_main(keys)` 가 단추만 다시 짓고 내용은 그대로라 **그 자리에서 바뀐다.**
    ⚠ `share_with` 짝(연구자료/내부연결)은 **같은 층**에 있어야 한다 — 부르는 쪽이
      `main` 을 만들 때 짝을 함께 넣는다(`set_main` 도 같은 규칙으로 부른다).
    ⚠ 하네스가 읽는 `_top` · `_inner` 는 `_Tier` 창이다(BranchTabs 가 아니다).
    """

    def __init__(self, parent, db_path=None, state_key=None, on_change=None,
                 main=(), more_key='MORE', more_i18n='P2T_MORE',
                 more_label='더보기', **kw):
        super().__init__(parent, **kw)
        self.db_path = db_path
        self.state_key = state_key
        self.on_change = on_change
        self.main = tuple(main)
        self.more_key = more_key
        self._more = (more_i18n, more_label)
        self._items = {}            # key → {frame, btn, i18n, dflt, count, tier, visible}
        self._order = []
        self._cur = None
        self._more_open = False
        self._more_btn = None
        self._padx = {'TOP': TAB_PADX, 'IN': TAB_PADX}
        self._top_bar = tk.Frame(self, height=BAR_H)
        self._top_bar.pack(fill='x')
        self._top_bar.pack_propagate(False)
        self._fit_after = {}
        self._top_bar.bind('<Configure>', lambda e: self.refit_later(), add='+')
        self._inner_bar = tk.Frame(self, height=BAR_H)   # 더보기를 눌렀을 때만 pack
        self._inner_bar.pack_propagate(False)
        self._inner_bar.bind('<Configure>', lambda e: self.refit_later(), add='+')
        # M 자리 — 윗줄 맨 오른쪽에 먼저 못 박는다(BranchTabs 와 같은 문법)
        self._m_slot = tk.Frame(self._top_bar)
        self._m_slot.pack(side='right', padx=(0, 2))
        # ★ 왼쪽 칸(2026-09-16 · 1.txt 22) — **첫 주 탭보다 왼쪽**에 늘 있는 자리.
        #   P2 가 「지금 무슨 절인지」 약명을 여기 둔다. 갈래 단추는 뒤에 `side='left'` 로
        #   붙으므로 이 칸이 먼저 pack 된 것만으로 차례가 지켜진다.
        self._l_slot = tk.Frame(self._top_bar)
        self._l_slot.pack(side='left', padx=(2, 0))
        self._body = tk.Frame(self)
        self._body.pack(fill='both', expand=True)
        self._top = _Tier(self, 'TOP')
        self._inner = _Tier(self, 'IN')

    # ── 구성 ──
    def is_main(self, key):
        return key in self.main

    def frame_for(self, key):
        it = self._items.get(key)
        if it is None:
            it = {'frame': tk.Frame(self._body), 'btn': None, 'i18n': '',
                  'dflt': key, 'count': None,
                  'tier': ('TOP' if key in self.main else 'IN'), 'visible': True}
            self._items[key] = it
        return it['frame']

    def add(self, key, i18n_key, default_label, share_with=None, row=0):
        self.frame_for(key)
        it = self._items[key]
        if share_with and share_with in self._items:
            it['frame'] = self._items[share_with]['frame']
        it['i18n'], it['dflt'] = i18n_key, default_label
        it['tier'] = 'TOP' if key in self.main else 'IN'
        if key not in self._order:
            self._order.append(key)
        self._mk_btn(key)

    def finish(self):
        self._ensure_more_btn()
        want = self._load_state(self.state_key)
        if want == self.more_key:
            want = self._load_state(self.state_key + '_MORE') if self.state_key else None
        if want not in self._items:
            want = next((k for k in self._order if self._items[k]['tier'] == 'TOP'), None) \
                or (self._order[0] if self._order else None)
        self.select(want, save=False)       # 여기서 on_change 가 한 번 난다

    # ★ 2026-10-07 (docs/1.txt 51-4) — **이 갈래만 남긴다.** P2 와 P4 오른쪽 패널은
    #   설명·묵상노트만 두고 나머지는 P4 탭이 맡는다(사용자 「P2의 탭을 최소화한다.
    #   묵상노트/설명문 이외에는 모두 P4에서 취급한다」 · 「제거할 대상 : 더보기, T 버튼 …」).
    #   ⚠ 갈래를 **지우지 않고 잠근다** — 부르는 자리(배지 세기·옛 핀·지연 빌드)가 여럿이라
    #     프레임은 그대로 두고 단추만 숨긴다. 잠근 뒤로는 `set_visible(True)` 도,
    #     `set_main` 도 잠긴 갈래를 되살리지 못하고 더보기 단추도 안 생긴다.
    _locked = None

    def lock_to(self, keys):
        self._locked = tuple(k for k in keys if k in self._items)
        for k, it in self._items.items():
            if k not in self._locked:
                it['visible'] = False
        self.set_main(self._locked)
        for k, it in self._items.items():
            if k not in self._locked and it['btn'] is not None:
                it['btn'].pack_forget()
        if self._more_btn is not None:
            self._more_btn.destroy()
            self._more_btn = None
        self._inner_bar.pack_forget()
        self._more_open = False
        if self._cur not in self._locked and self._locked:
            self.select(self._locked[0], save=False)

    def set_main(self, keys):
        """주 탭을 **살아서** 바꾼다(2026-09-16 19-2) — 단추만 다시 짓고 내용은 그대로.
        `keys` 에 없는 갈래는 더보기 안으로. 지금 보던 갈래는 그대로 보인다."""
        if self._locked is not None:
            keys = self._locked
        self.main = tuple(k for k in keys if k in self._items)
        for k, it in self._items.items():
            it['tier'] = 'TOP' if k in self.main else 'IN'
            if it['btn'] is not None:
                it['btn'].destroy()
                it['btn'] = None
        if self._more_btn is not None:
            self._more_btn.destroy()
            self._more_btn = None
        for k in self._order:
            self._mk_btn(k)
        self._ensure_more_btn()
        cur = self._cur
        self._more_open = False
        self._inner_bar.pack_forget()
        if cur in self._items:
            self.select(cur, save=False)
        self.refit()

    # ── 동작 ──
    def select(self, key, save=True):
        if key is None or key not in self._items:
            return
        it = self._items[key]
        self._cur = key
        inner = (it['tier'] == 'IN')
        if inner != self._more_open:
            self._more_open = inner
            if inner:
                self._inner_bar.pack(fill='x', after=self._top_bar)
            else:
                self._inner_bar.pack_forget()
        chosen = it['frame']
        for other in self._items.values():
            if other['frame'] is chosen:
                continue
            other['frame'].pack_forget()
        if not chosen.winfo_manager():
            chosen.pack(fill='both', expand=True)
        self._sync_btns()
        if save:
            self._save_state(key)
        if callable(self.on_change):
            try:
                self.on_change(key)
            except Exception:
                pass

    def current(self):
        return self._cur

    def set_count(self, key, n):
        it = self._items.get(key)
        if it is None:
            return
        it['count'] = n
        self._set_btn_text(key)
        if it['tier'] == 'IN':
            self._set_more_text()       # 합계가 바뀌었다
            self.refit_later()

    def set_visible(self, key, on):
        it = self._items.get(key)
        if it is None or it['btn'] is None:
            return
        if getattr(self, '_locked', None) is not None and key not in self._locked:
            on = False                  # 잠긴 갈래는 되살리지 않는다(51-4)
        it['visible'] = bool(on)
        b = it['btn']
        shown = bool(b.winfo_manager())
        if bool(on) == shown:
            return
        if it['tier'] == 'IN':
            self.after_idle(self._set_more_text)   # 감춘 것은 합계에서 빠진다
        if on:
            nxt = self._next_shown_btn(key)
            if nxt is not None:
                b.pack(side='left', padx=(2, 0), before=nxt)
            else:
                b.pack(side='left', padx=(2, 0))
        else:
            b.pack_forget()
            if self._cur == key:
                for k in self._order:
                    o = self._items[k]
                    if k != key and o['btn'] is not None and o['btn'].winfo_manager():
                        self.select(k)
                        break

    def rows(self):
        return 1

    def refit(self):
        self._fit_padx('TOP')
        self._fit_padx('IN')

    def refit_later(self, ms=40):
        """조금 뒤에 다시 맞춘다 — **기하가 가라앉은 뒤** 재야 한다.
        ⚠ `<Configure>` 가 오는 순간이나 도구를 방금 편 직후에는 옆 칸의
          `winfo_reqwidth` 가 아직 옛 값이라(실측) 그때 재면 여백이 안 줄고
          더보기가 잘린다. 여러 번 불려도 마지막 한 번만 돈다."""
        try:
            if self._fit_after.get('id'):
                self.after_cancel(self._fit_after['id'])
            self._fit_after['id'] = self.after(ms, self._refit_now)
        except Exception:
            pass

    def _refit_now(self):
        self._fit_after['id'] = None
        try:
            self.update_idletasks()
        except Exception:
            pass
        self.refit()

    def bar(self, row=0):
        return self._top_bar

    def inner_bar(self):
        return self._inner_bar

    def manual_slot(self):
        return self._m_slot

    def left_slot(self):
        """윗줄 **맨 왼쪽** 칸 — 첫 주 탭보다 왼쪽(약명 라벨 자리)."""
        return self._l_slot

    # ── 내부 ──
    def _bar_of(self, tier):
        return self._top_bar if tier == 'TOP' else self._inner_bar

    def _mk_btn(self, key):
        it = self._items[key]
        tier = it['tier']
        bar = self._bar_of(tier)
        b = tk.Button(bar, bd=0, relief='flat',
                      padx=self._padx[tier], pady=TAB_PADY,
                      highlightthickness=1, highlightbackground=_border(),
                      highlightcolor=_border(),
                      cursor='hand2', command=lambda k=key: self.select(k))
        it['btn'] = b
        if it.get('visible', True):
            # 등록 차례를 지킨다 — 뒤에 이미 있는 단추(더보기 포함) 앞에
            nxt = self._next_shown_btn(key)
            if nxt is not None:
                b.pack(side='left', padx=(2, 0), before=nxt)
            else:
                first = not any(self._items[k]['btn'] is not None
                                and self._items[k]['btn'].winfo_manager()
                                for k in self._order
                                if k != key and self._items[k]['tier'] == tier)
                b.pack(side='left', padx=(0 if first else 2, 0))
        self._set_btn_text(key)
        self._sync_btns()

    def _next_shown_btn(self, key):
        """같은 층에서 `key` 뒤에 오는 첫 보이는 단추(더보기 포함) — 없으면 None."""
        tier = self._items[key]['tier']
        after = False
        for k in self._order:
            if k == key:
                after = True
                continue
            o = self._items[k]
            if after and o['tier'] == tier and o['btn'] is not None and o['btn'].winfo_manager():
                return o['btn']
        if tier == 'TOP' and self._more_btn is not None and self._more_btn.winfo_manager():
            return self._more_btn
        return None

    def _ensure_more_btn(self):
        if getattr(self, '_locked', None) is not None:
            return                      # 잠근 줄에는 더보기가 없다(51-4)
        has_inner = any(it['tier'] == 'IN' for it in self._items.values())
        if not has_inner or self._more_btn is not None:
            return
        b = tk.Button(self._top_bar, bd=0, relief='flat',
                      padx=self._padx['TOP'], pady=TAB_PADY,
                      highlightthickness=1, highlightbackground=_border(),
                      highlightcolor=_border(),
                      cursor='hand2', command=self._on_more)
        b.pack(side='left', padx=(2, 0))          # 늘 맨 뒤(M 자리는 side='right')
        self._more_btn = b
        self._set_more_text()
        self._sync_btns()

    def _on_more(self):
        """더보기 — 안의 직전 갈래(없으면 첫 갈래)를 편다."""
        want = self._load_state(self.state_key + '_MORE') if self.state_key else None
        inner = [k for k in self._order if self._items[k]['tier'] == 'IN'
                 and self._items[k]['btn'] is not None and self._items[k]['btn'].winfo_manager()]
        if want not in inner:
            want = inner[0] if inner else None
        if want:
            self.select(want)

    def more_count(self):
        """더보기 안에 **지금 들어 있는 것의 합** — 셀 수 없는 갈래는 뺀다.

        ⚠ **감춘 갈래는 안 센다** — 빈 갈래 감추기로 사라진 것을 세면 눌렀을 때
          없는 수가 된다(그것이 곧 「허탈」이다).
        ⚠ 셀 수 있는 것이 하나도 없으면 `None` — 0 과 다르다(모름과 없음).
        """
        n, seen = 0, False
        for k in self._order:
            it = self._items.get(k)
            if it is None or it['tier'] != 'IN':
                continue
            b = it['btn']
            if b is None or not b.winfo_manager():
                continue
            c = it.get('count')
            if c is None:
                continue
            seen = True
            n += int(c)
        return n if seen else None

    def _set_more_text(self):
        if self._more_btn is None:
            return
        try:
            import i18n
            txt = i18n.t(self._more[0], self._more[1]) if self._more[0] else self._more[1]
        except Exception:
            txt = self._more[1]
        # ★ 배지 규칙은 갈래 단추와 **같은 문**(`p4_node_panel.badge` — 9+ 상한)
        n = self.more_count()
        if n is not None:
            try:
                import p4_node_panel as _np
                lbl = _np.badge(n)
            except Exception:
                lbl = str(n)
            if lbl is not None:
                txt = '%s(%s)' % (txt, lbl)
        self._more_btn.config(text=txt)

    def _set_btn_text(self, key):
        if key == self.more_key:
            return self._set_more_text()
        it = self._items.get(key)
        if it is None or it['btn'] is None:
            return
        try:
            import i18n
            base = i18n.t(it['i18n'], it['dflt']) if it['i18n'] else it['dflt']
        except Exception:
            base = it['dflt']
        try:
            import p4_node_panel as _np
            n = _np.badge(it['count'])
        except Exception:
            n = None if it['count'] is None else str(it['count'])
        it['btn'].config(text=('%s(%s)' % (base, n)) if n is not None else base)

    def _sync_btns(self):
        on, off = _colors()
        bd = _border()
        for k, it in self._items.items():
            b = it['btn']
            if b is None:
                continue
            bg, fg = on if k == self._cur else off
            try:
                b.config(bg=bg, fg=fg, activebackground=bg, activeforeground=fg,
                         highlightbackground=bd, highlightcolor=bd)
            except Exception:
                pass
        if self._more_btn is not None:
            bg, fg = on if self._more_open else off
            try:
                self._more_btn.config(bg=bg, fg=fg, activebackground=bg,
                                      activeforeground=fg,
                                      highlightbackground=bd, highlightcolor=bd)
            except Exception:
                pass

    def _fit_padx(self, tier):
        """줄 폭에 맞는 가장 넉넉한 가로 여백(10 → 8 → 6 → 4) — BranchTabs 와 같은 잣대."""
        try:
            bar = self._bar_of(tier)
            w = bar.winfo_width()
            if w <= 1:
                return
            btns = [it['btn'] for k, it in self._items.items()
                    if it['tier'] == tier and it['btn'] is not None
                    and it['btn'].winfo_manager()]
            if tier == 'TOP' and self._more_btn is not None and self._more_btn.winfo_manager():
                btns.append(self._more_btn)
            if not btns:
                return
            cur = self._padx[tier]
            base = sum(b.winfo_reqwidth() - 2 * cur for b in btns) + 2 * (len(btns) - 1)
            others = sum(c.winfo_reqwidth() for c in bar.winfo_children()
                         if c.winfo_manager() and c not in btns) + 6
            pick = PADX_STEPS[-1]
            for p in PADX_STEPS:
                if base + 2 * p * len(btns) + others <= w:
                    pick = p
                    break
            if pick != cur:
                self._padx[tier] = pick
                for b in btns:
                    b.config(padx=pick)
        except Exception as e:
            print('[split_tabs fit_padx] %s' % e)

    def _load_state(self, key):
        if not (self.db_path and key):
            return None
        try:
            import appdb
            with appdb.connect(self.db_path) as c:
                r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                              (key,)).fetchone()
            return r[0] if r and r[0] else None
        except Exception:
            return None

    def _save_state(self, key):
        """직전 갈래 — 주 탭이면 `state_key`, 더보기 안이면 `state_key`=MORE 와
        `state_key_MORE`=그 갈래(옛 두 열쇠 그대로 · P2_TAB · P2_TAB_MORE)."""
        if not (self.db_path and self.state_key):
            return
        inner = self._items[key]['tier'] == 'IN'
        rows = [(self.state_key, self.more_key if inner else key)]
        if inner:
            rows.append((self.state_key + '_MORE', key))
        try:
            import appdb
            with appdb.connect(self.db_path) as c:
                for k, v in rows:
                    c.execute("INSERT INTO user_config (config_key, config_val) VALUES (?,?) "
                              "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                              (k, v))
                c.commit()
        except Exception:
            pass


def _selftest():
    ok = []
    root = tk.Tk()
    root.withdraw()
    bt = BranchTabs(root)                       # state_key 없음 — DB 무접촉
    fa, fb = bt.frame_for('a'), bt.frame_for('b')
    tk.Label(fa, text='A').pack()
    tk.Label(fb, text='B').pack()
    bt.add('a', '', '갈래A')
    bt.add('b', '', '갈래B')
    bt.finish()
    bt.pack()
    root.update_idletasks()
    ok.append(('첫 갈래 선택', bt.current() == 'a'))
    ok.append(('A 표시·B 숨김', fa.winfo_manager() == 'pack'
               and fb.winfo_manager() == ''))
    bt.select('b')
    ok.append(('전환', bt.current() == 'b' and fb.winfo_manager() == 'pack'
               and fa.winfo_manager() == ''))
    bt.set_count('b', 3)
    ok.append(('개수 「갈래B(3)」', bt._items['b']['btn'].cget('text') == '갈래B(3)'))
    bt.set_count('b', 0)
    ok.append(('0 도 「갈래B(0)」', bt._items['b']['btn'].cget('text') == '갈래B(0)'))
    bt.set_count('b', None)
    ok.append(('None = 이름만', bt._items['b']['btn'].cget('text') == '갈래B'))
    ok.append(('줄 높이 고정', int(bt._bar.cget('height')) == BAR_H))
    # ★ 두 줄 (2026-09-15) — 줄은 고정이고 둘째 줄 단추는 둘째 프레임에 산다
    b2 = BranchTabs(root, rows=2)
    for k in ('a', 'b', 'c', 'd'):
        tk.Label(b2.frame_for(k), text=k).pack()
    b2.add('a', '', 'A'); b2.add('b', '', 'B')
    b2.add('c', '', 'C', row=1); b2.add('d', '', 'D', row=1)
    b2.finish(); b2.pack(); root.update_idletasks()
    ok.append(('두 줄 — 줄 수 2', b2.rows() == 2))
    ok.append(('두 줄 — c·d 는 둘째 줄에',
               b2._items['c']['btn'].master is b2.bar(1)
               and b2._items['a']['btn'].master is b2.bar(0)))
    ok.append(('두 줄 — 첫 줄 높이 고정 · 둘째 줄도',
               all(int(x.cget('height')) == BAR_H for x in b2._bars)))
    b2.set_visible('c', False); b2.set_visible('c', True)
    ok.append(('두 줄 — 감췄다 되살리면 같은 줄 제자리(d 앞)',
               b2._items['c']['btn'].master is b2.bar(1)
               and b2.bar(1).pack_slaves().index(b2._items['c']['btn'])
               < b2.bar(1).pack_slaves().index(b2._items['d']['btn'])))
    b2.select('d')
    ok.append(('두 줄 — 둘째 줄 갈래 전환', b2.current() == 'd'
               and b2.frame_for('d').winfo_manager() == 'pack'
               and b2.frame_for('a').winfo_manager() == ''))
    # ★ 주 탭 + 더보기 (2026-09-15)
    got = []
    st = SplitTabs(root, main=('a', 'c'), on_change=lambda k: got.append(k))
    for k in ('a', 'b', 'c', 'd'):
        tk.Label(st.frame_for(k), text=k).pack()
    for k in ('a', 'b', 'c', 'd'):
        st.add(k, '', k.upper())
    st.finish(); st.pack(); root.update_idletasks()
    ok.append(('더보기 — 윗줄은 a·c·더보기(맨 뒤)', st._top._order == ['a', 'c', 'MORE']))
    ok.append(('더보기 — 안은 b·d', st._inner._order == ['b', 'd']))
    ok.append(('더보기 — 처음은 a 이고 안쪽 줄은 안 보인다',
               st.current() == 'a' and st._inner.winfo_manager() == ''
               or st._top.frame_for('MORE').winfo_manager() == ''))
    ok.append(('더보기 — finish 가 실제 갈래로 한 번만 알린다', got == ['a'], got))
    got.clear(); st.select('d'); root.update_idletasks()
    ok.append(('더보기 — 안의 갈래를 선택하면 더보기가 눌리고 current 는 d',
               st._top.current() == 'MORE' and st.current() == 'd' and got[-1] == 'd', got))
    ok.append(('더보기 — 그때만 안쪽 줄이 보인다', st._top.frame_for('MORE').winfo_manager() == 'pack'))
    got.clear(); st.select('c'); root.update_idletasks()
    ok.append(('더보기 — 주 탭으로 돌아오면 안쪽 줄이 사라진다',
               st.current() == 'c' and st._top.frame_for('MORE').winfo_manager() == '' and got == ['c'], got))
    st.set_count('b', 3); st.set_count('a', 1)
    ok.append(('더보기 — 개수는 제 층의 단추에', st._inner._items['b']['btn'].cget('text') == 'B(3)'
               and st._top._items['a']['btn'].cget('text') == 'A(1)'))
    # ★★ **더보기(N)** — 2026-09-17 사용자 「눌렀는데 아무것도 없으면 허탈」
    ok.append(('★★ 더보기에 안의 합계가 적힌다',
               st._top._items['MORE']['btn'].cget('text') == '더보기(3)',
               st._top._items['MORE']['btn'].cget('text')))
    st.set_count('d', 2); root.update_idletasks()
    ok.append(('★ 안의 갈래가 늘면 합계도 는다',
               st._top._items['MORE']['btn'].cget('text') == '더보기(5)',
               st._top._items['MORE']['btn'].cget('text')))
    st.set_visible('d', False); root.update_idletasks()
    ok.append(('더보기 — 안의 갈래 감추기', st._inner._items['d']['btn'].winfo_manager() == ''))
    ok.append(('★★ 감춘 갈래는 합계에서 빠진다',
               st._top._items['MORE']['btn'].cget('text') == '더보기(3)',
               st._top._items['MORE']['btn'].cget('text')))
    st.set_count('b', None); st.set_count('d', None); root.update_idletasks()
    ok.append(('★ 셀 수 있는 것이 없으면 수를 안 적는다(모름 ≠ 없음)',
               st._top._items['MORE']['btn'].cget('text') == '더보기',
               st._top._items['MORE']['btn'].cget('text')))
    st.set_count('b', 3); st.set_visible('d', True); st.set_count('d', 2)
    root.update_idletasks()
    # ★ 살아서 주 탭 바꾸기 (2026-09-16 19-2) — 내용은 그대로, 단추만 다시
    st.set_visible('d', True)
    fb_id = str(st.frame_for('b'))
    got.clear(); st.select('b'); root.update_idletasks()
    st.set_main(('b', 'd')); root.update_idletasks()
    ok.append(('set_main — 윗줄 b·d·더보기 · 안 a·c', st._top._order == ['b', 'd', 'MORE'] and st._inner._order == ['a', 'c'], (st._top._order, st._inner._order)))
    ok.append(('set_main — 보던 갈래(b)가 그대로 보이고 프레임 동일 · 안쪽 줄은 사라짐',
               st.current() == 'b' and str(st.frame_for('b')) == fb_id and st.frame_for('b').winfo_manager() == 'pack'
               and st._top.frame_for('MORE').winfo_manager() == ''))
    ok.append(('set_main — 개수가 남아 있다(B(3))', st._top._items['b']['btn'].cget('text') == 'B(3)'))
    st.set_main(('a', 'b', 'c', 'd')); root.update_idletasks()
    ok.append(('set_main — 전부 주 탭이면 더보기가 없다', st._more_btn is None and st._top._order == ['a', 'b', 'c', 'd']))
    root.destroy()
    for row in ok:
        name, passed = row[0], row[1]
        print(('  OK ' if passed else 'FAIL ') + name + ('' if passed or len(row) < 3 else ' %r' % (row[2],)))
    if not all(r[1] for r in ok):
        raise SystemExit(1)
    print('branch_tabs selftest: %d/%d' % (len(ok), len(ok)))


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        _selftest()
