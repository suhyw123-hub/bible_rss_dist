# -*- coding: utf-8 -*-
"""미디어 수집 제외후보 키워드 필터 (개신교 전용 앱 — 가톨릭 등 타교파 콘텐츠 식별).

**소프트 필터**: 키워드가 제목/설명에 있어도 **폐기하지 않고** 수집한 뒤
`description.exclude_kw` 에 매칭어를 기록(플래그)한다. 검토 탭에서 표시되어
관리자가 확인 후 승인(복구)/거부한다. → 개신교 채널의 '미사/연옥 반박' 같은
정당한 콘텐츠를 자동으로 잃지 않는다(오탐 복구 가능).

키워드는 sys_config['MEDIA_EXCLUDE_KW'](JSON 배열, 관리자 편집)에서 로드.
없으면 아래 DEFAULT(보수적 초안). 식별성 높은 가톨릭 용어만 — '마리아·교회·믿음'
처럼 개신교도 쓰는 모호어는 넣지 않는다(오탐 방지).
"""
import json
import re
import os
import sqlite3
import appdb

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')
CFG_KEY = 'MEDIA_EXCLUDE_KW'

# 보수적 초안 — 관리자가 sys_config 또는 분류관리 UI에서 가감.
DEFAULT_EXCLUDE_KW = [
    # 가톨릭 전례·제도 (식별성 높음)
    '미사', '영성체', '성체성사', '고해성사', '견진성사', '병자성사', '종부성사',
    '묵주기도', '묵주', '연옥', '교황', '추기경', '천주교', '대축일', '전대사', '면죄부',
    # 가톨릭 인명 음역 (KO — 개신교 표기와 다른 것만)
    '바오로', '마태오', '마르코', '루카', '에제키엘', '이사야서(공동)',
    # 가톨릭 인명 음역 (ZH 思高本)
    '梅瑟', '達味', '保祿', '伯多禄', '瑪竇', '路加福音(思高)',
    # 가톨릭 호칭/장소 (강한 식별어만)
    '성모송', '삼종기도', '봉헌미사',
    # 영어 전례·교리 식별어 (라틴문자권은 음역차 작음 → 전례어 위주, 모호어 Mass/Pope 제외)
    'Eucharist', 'Purgatory', 'Rosary', 'Magisterium', 'transubstantiation',
    'Our Lady', 'Immaculate Conception', 'papal', 'Holy See',
    # 일본어 가톨릭 기본어 (음역+전례어, 모호어 제외)
    'ミサ', '煉獄', 'ロザリオ', '聖体拝領', '告解', '教皇', 'カトリック',
    '聖母マリア', '無原罪',
]


#: 수집 제외 채널 목록의 **옛 자리**(지금은 비어 있다 — 아래 참조).
EXCL_CH_KEY = 'MEDIA_EXCLUDED_CHANNELS'


def excluded_channels(conn):
    """수집에서 뺄 채널 이름 → set. **단일 소스는 `sys_media_excluded_channel`.**

    ⚠⚠⚠ **목록이 두 벌이었고 수집기가 빈 쪽을 읽고 있었다**(2026-09-06 실측).
      관리자 화면·자동크롤러는 **표**에 담는데(실측 LIVE **20개**),
      `db_media_crawler._load_excluded_channels` 만 `sys_config` 열쇠
      (실측 **없음**)를 봤다 — **구절·용어 수집기에서 제외가 한 번도 안
      걸리고 있었다.** 사용자 지시 「제거대상으로 등록한 채널은 최신컨텐츠
      에서도 제거 … **수집단계에서부터 제거되면 제일 좋다**」.
    ★ **여기가 그 판정의 집이다** — 수집기·RSS 수집기·최신 발행이 이 문을
      함께 쓴다. 이 모듈은 가볍다(표준 라이브러리 + appdb 뿐).
      ⚠ **`db_media_crawler` 에 두면 안 된다** — 그것을 부르는 순간 수집기
        전체(`db_media_range`·`media_text_linker`·`db_media_attempt`)가
        사용자 앱 폐포로 딸려 들어온다(실측 4파일 38자리).
    ⚠ 옛 config 열쇠도 함께 읽어 합친다 — 누가 거기 넣어 두었을 수 있다.
    """
    out = set()
    try:
        for (nm,) in conn.execute(
                "SELECT channel_name FROM sys_media_excluded_channel"
                " WHERE COALESCE(record_status,'LIVE')='LIVE'"):
            if nm:
                out.add(nm.strip())
    except Exception:
        pass
    try:
        row = conn.execute("SELECT config_val FROM sys_config"
                           " WHERE config_key=?", (EXCL_CH_KEY,)).fetchone()
        for nm in (json.loads(row[0]) if row and row[0] else []):
            if nm:
                out.add(str(nm).strip())
    except Exception:
        pass
    return out


def excluded_ids(conn):
    """차단 채널의 **유튜브 id** 집합 — 이름은 채널이 바꿀 수 있어 id 가 먼저다
    (2026-09-09 실측 — 「하나님의교회 세계복음선교협회」를 이름으로 차단했는데
    같은 단체가 다섯 이름으로 15편 들어와 있었다)."""
    out = set()
    try:
        for (cid,) in conn.execute(
                "SELECT channel_ext_id FROM sys_media_excluded_channel"
                " WHERE COALESCE(record_status,'LIVE')='LIVE' AND channel_ext_id IS NOT NULL"):
            if cid:
                out.add(str(cid).strip())
    except Exception:
        pass
    return out


def chan_excluded(name, excluded):
    """이 채널이 제외 목록에 있나 — **대소문자·앞뒤 공백을 안 따진다.**

    ★ 판정 문을 하나로 둔다 — 자리마다 `in` 을 쓰면 한쪽만 대소문자를 눌러
      서로 다르게 걸린다.
    """
    if not name or not excluded:
        return False
    n = str(name).strip().lower()
    return any(n == str(x).strip().lower() for x in excluded)


#: ★★★ **언어 축** (2026-09-06 사용자 지시 「한국어 이외에는 **그 나라의
#:   실정(특히 카톨릭과의 용어사용의 동일성 여부)에 맞게** 적용하라」).
#:   ⚠⚠ **한 목록에 섞여 있으면 표현할 수 없는 것이 있다** — 실측 옛 목록 49개가
#:     KO 25 · 한자 12 · 라틴 9 · 일본어 3 으로 섞여, 「한국어에서는 걸러야
#:     하지만 영어에서는 아니다」를 적을 자리가 없었다.
#:
#:   ★★★ **언어마다 실정이 다르다 — 그것이 이 표의 존재 이유다**:
#:     · **KO** — 개신교와 천주교의 낱말이 잘 갈린다(미사·성체성사·묵주기도).
#:       가장 넓게 잡아도 안전하다.
#:     · **ZH/ZHT/JA** — 天主教·弥撒·ミサ 처럼 갈리는 말이 있다. 중간.
#:     · **EN/DE/FR/ES/PT** — ⚠ **여러 말을 개신교도 쓴다.** 영어 Mass·
#:       communion·confession, 독일어 Messe·Beichte(루터교가 쓴다),
#:       프랑스어·스페인어 confession/confesión(신앙고백과 겹친다).
#:       ⇒ **여러 낱말 구(句)만** 넣는다(`Catholic Mass`·`Holy Rosary`).
#:     · **RU·AR** — **정교회권**이다. ⇒ 2026-09-06 사용자 확정으로
#:       **정교회도 가톨릭과 같이 거른다**(아래 RU·AR 버킷 주석 참조).
#:       이 앱의 기준은 **개신교**이고 정교회는 가톨릭과 같은 자리에 선다.
#:   ⚠ **모르면 안 넣는다** — 잘못 빼면 좋은 콘텐츠를 조용히 잃고, 안 빼면
#:     사람이 한 번 볼 뿐이다. **오탐이 미탐보다 비싸다.**
#:
#:   `'*'` = **언어를 안 가리는 것**(고유명사·라틴 표기 등).
EXCLUDE_KW_LANG = {
    'KO': [
        # ⚠⚠⚠ **「미사」는 공백을 전제로 한다**(2026-09-06 사용자 확정
        #   「검색어는 유사어 **미사동**을 찾아야 함 · 제외필터에서는 **정확한
        #   것만** 제외해야 함 · **카톨릭 미사는 공백을 전제로 함**」).
        #   실측 — 하남시 **미사동**이 개신교회 이름에 들어간다:
        #     `#미사온누리교회` 93건 · `(미사강변 우리들교회)` 32건.
        #   「미사」 단독으로 거르면 127건 중 **125건(98%)이 오탐**이었다.
        #   ★ **잣대는 「뒤에 한글이 안 붙는다」**(`WORD_END` — 아래).
        #     공백·부호·문장 끝이 전부 여기 들어가므로 사용자가 말한 「공백을
        #     전제로」와 뜻이 같고, **한 가지를 더 막는다**:
        #       걸림 — `& 미사(주님 승천 대축일)` · `[매일미사 강론]` · `주일 미사`
        #       통과 — 미사동 · 미사온누리교회 · 미사강변 우리들교회 · 미사동교회
        #     ⚠ 공백 두 꼴(`' 미사'`·`'미사 '`)로 하면 **「하남 미사동 …」이
        #       걸린다**(앞 공백 + 뒤 한글). 실측 데이터엔 아직 없지만
        #       미사동에 교회가 많아 언젠가 난다.
        #   ★★ **한 낱말로 끝난다** — 구(句)를 열거하면 새 지명마다 는다.
        #   ⚠ **검색어 쪽과 축이 다르다** — 찾을 때는 유사어까지 넓게, 거를
        #     때는 정확히만. 실측 `media_exclude` 는 **거르는 자리에서만**
        #     쓰이고 검색어를 만드는 문에는 안 걸린다(호출부 전수 확인).
        '미사$',
        '영성체', '성체성사', '고해성사', '견진성사', '병자성사',
        '종부성사', '묵주기도', '묵주', '연옥', '교황', '추기경', '천주교',
        '대축일', '전대사', '면죄부', '성모송', '삼종기도', '봉헌미사',
        '주모경', '무염시태', '성모 승천', '교황청', '주교회의',
        # 가톨릭 인명 음역 — 개신교 표기와 다른 것만
        '바오로', '마태오', '마르코', '루카', '에제키엘', '즈카르야',
    ],
    'ZH': ['天主教', '弥撒', '教宗', '玫瑰经', '炼狱', '圣体圣事', '告解',
           '梵蒂冈', '枢机', '大赦',
           # 思高本 인명 — 和合本과 다른 것만
           '梅瑟', '达味', '保禄', '伯多禄', '玛窦'],
    'ZHT': ['天主教', '彌撒', '教宗', '玫瑰經', '煉獄', '聖體聖事', '告解',
            '梵蒂岡', '樞機', '大赦',
            '梅瑟', '達味', '保祿', '伯多祿', '瑪竇'],
    'JA': ['カトリック', 'ミサ', '煉獄', 'ロザリオ', '聖体拝領', '告解',
           '教皇', '無原罪', 'バチカン', '枢機卿'],
    # ⚠ 아래 라틴문자권은 **여러 낱말 구만** — 홑낱말은 개신교도 쓴다
    'EN': ['Catholic Mass', 'Holy Rosary', 'the Rosary', 'Purgatory',
           'Magisterium', 'transubstantiation', 'Immaculate Conception',
           'Holy See', 'papal', 'Marian apparition', 'Hail Mary',
           'Our Lady of',
           # 정교회 — 구로만. ⚠ 홑낱말 `orthodox` 는 **개신교도 쓴다**
           #   (orthodox theology · orthodox Christianity = 정통 교리).
           #   ⚠⚠ **`Coptic Orthodox` 를 여기 넣지 않는다** — 콥트는 허용이다
           #     (2026-09-12). `COPT_OK` 가 그 자리를 지킨다.
           'Orthodox Church', 'Eastern Orthodox', 'Greek Orthodox',
           'Russian Orthodox', 'Divine Liturgy', 'Orthodox Liturgy'],
    'DE': ['katholische Messe', 'Rosenkranz', 'Fegefeuer', 'der Papst',
           'Unbefleckte Empfängnis', 'Heiliger Stuhl', 'Marienerscheinung',
           'orthodoxe Kirche', 'Göttliche Liturgie'],
    'FR': ['messe catholique', 'chapelet', 'purgatoire', 'le Pape',
           'Immaculée Conception', 'Saint-Siège', 'Je vous salue Marie',
           'Église orthodoxe', 'liturgie orthodoxe'],
    'ES': ['misa católica', 'santo rosario', 'purgatorio', 'el Papa',
           'Inmaculada Concepción', 'Santa Sede', 'Ave María',
           'Iglesia Ortodoxa', 'liturgia ortodoxa'],
    'PT': ['missa católica', 'santo terço', 'purgatório', 'o Papa',
           'Imaculada Conceição', 'Santa Sé', 'Ave Maria',
           'Igreja Ortodoxa', 'liturgia ortodoxa'],
    # ★★★ **정교회도 가톨릭과 같이 거른다** (2026-09-06 사용자 확정
    #   「정교회도 카톨릭과 같이 취급하라 · **제외후보에 포함하라**」).
    #   ⚠⚠ **제 앞선 판단을 뒤집는다** — §202·203차에 「RU 는 정교회권이라
    #     литургия·исповедь 를 거르면 러시아어 기독교 콘텐츠가 통째로
    #     사라진다」고 적어 두었다. 그 걱정은 **「기독교 콘텐츠를 넓게
    #     담는다」를 전제**한 것인데, 이 앱의 기준은 **개신교**다. 정교회는
    #     가톨릭과 같은 자리에 선다. ⇒ 사용자 판단이 맞다.
    #   ⚠ 그래도 **정확한 것만** 넣는다(사용자 「정확한 것만 제외해야 함」) —
    #     교파를 못 박는 말만이고, 개신교도 쓰는 일반어(храм 성전 ·
    #     молитва 기도 · служение 예배)는 **안 넣는다**.
    # ⚠ **RU 는 정교회권이다** — §202·203차가 「литургия·исповедь 를 거르면
    #   러시아어 기독교 콘텐츠가 통째로 사라진다」고 걱정했으나, 이 앱의 기준은
    #   **개신교**라 2026-09-06 에 거르기로 했고 그대로 간다.
    #   ⚠⚠ 2026-09-12 사용자 정정 — 허용은 **콥트**이지 정교회가 아니다.
    'RU': ['католическ', 'чистилище', 'розарий', 'папа римский',
           'Ватикан', 'непорочное зачатие',
           'православн', 'литургия', 'исповедь', 'Богородиц',
           'патриарх', 'акафист', 'молебен', 'панихида', 'икона'],
    # ⚠⚠ **콥트 정교회권** — 그전에는 قداس·البابا 를 「콥트가 쓴다」고 뺐다.
    #   이제 정교회도 거르므로 **넣는다**(위 결정과 같은 이유).
    # ★★★ **콥트는 허용한다**(2026-09-12 사용자 「정교회가 아니라 **콥트교**를
    #   말한 것이다」) — `قبطي`·`قداس`·콥트 성직 호칭을 **안 넣는다**.
    #   ⚠ `أرثوذكس`(정교회)는 넣되 **콥트 표식이 있으면 `COPT_OK` 가 건너뛴다.**
    'AR': ['كاثوليك', 'الفاتيكان', 'المطهر', 'أرثوذكس'],
    #: 언어를 안 가리는 것 — 글자 자체가 그 교파를 말하는 것만
    '*': ['Vaticano', 'Vatican',
          # 그리스 문자 — 정교회 전용 표기(우리 언어 목록에 EL 이 없어
          # 여기 둔다. 글자가 달라 다른 언어를 안 건드린다)
          'Ορθόδοξ', 'Θεία Λειτουργία', 'Θεοτόκο'],
}


def _as_lang_map(v, flat_default):
    """옛 평면 목록도 받는다 → `{lang: [...]}`.

    ⚠ **옛 값을 버리지 않는다** — 관리자가 손으로 넣은 것이 있을 수 있다.
      평면 목록이면 `'*'`(언어 무관)로 읽는다.
    """
    if isinstance(v, dict):
        return {str(k).upper(): [x for x in (val or []) if x and str(x).strip()]
                for k, val in v.items()}
    if isinstance(v, list):
        return {'*': [x for x in v if x and str(x).strip()]}
    return dict(flat_default)


def _cfg_json(db_path, key):
    try:
        conn = appdb.connect(db_path)
        row = conn.execute("SELECT config_val FROM sys_config"
                           " WHERE config_key=?", (key,)).fetchone()
        conn.close()
        if row and row[0]:
            return json.loads(row[0])
    except Exception:
        pass
    return None


def get_exclude_map(db_path=DB):
    """제외 키워드 → `{lang: [...]}`. 없으면 기본값."""
    return _as_lang_map(_cfg_json(db_path, CFG_KEY), EXCLUDE_KW_LANG)


def kw_for(kw_map, lang):
    """그 언어에 걸리는 낱말 → 목록. **그 언어 + `'*'`** 를 합친다.

    ⚠ 언어를 모르면(`None`) **전부** 본다 — 옛 동작과 같다(덜 거르는 쪽이
      아니라 더 거르는 쪽이 안전하다. 사람이 한 번 더 볼 뿐이다).
    """
    if not kw_map:
        return []
    if not lang:
        out = []
        for v in kw_map.values():
            out.extend(v or [])
        return out
    L = str(lang).upper()
    return list(kw_map.get(L) or []) + list(kw_map.get('*') or [])


#: 옛 이름 — 평면 목록을 기대하는 자리가 있다(호환).
DEFAULT_EXCLUDE_KW_FLAT = DEFAULT_EXCLUDE_KW


def get_exclude_kw(db_path=DB, lang=None):
    """제외 키워드 목록. `lang` 을 주면 **그 언어 + 언어무관**만."""
    return kw_for(get_exclude_map(db_path), lang)


#: ★★★ **낱말 끝 표시** — 키워드 끝에 이 글자를 붙이면 **뒤에 한글이 붙은
#:   것은 안 걸린다**(2026-09-06 사용자 「제외필터에서는 **정확한 것만**
#:   제외해야 함 · 카톨릭 미사는 **공백을 전제로** 함」).
#:   ⚠ 공백 두 꼴(`' 미사'`·`'미사 '`)로는 **「하남 미사동 …」이 걸린다**
#:     (앞 공백 + 뒤 한글). 실측 데이터에는 아직 없지만 미사동에 교회가 많아
#:     언젠가 난다 — **오탐이 미탐보다 비싸다.**
#:   ⇒ 잣대는 「공백」이 아니라 **「뒤에 한글이 안 붙는다」**이고, 그것이
#:     사용자가 말한 뜻이다(공백·부호·문장 끝이 전부 여기 든다).
#:   ★ **한 낱말로 끝난다** — 구(句)를 열거하면 새 지명·새 표현마다 는다.
WORD_END = '$'

#: 한글 음절 — 뒤에 이것이 붙으면 복합어(미사동·미사강변)라 안 거른다.
_HANGUL = re.compile(r'[가-힣]')


def _hit_word_end(low, k):
    """`k` 가 있되 **뒤에 한글이 안 붙은** 자리가 하나라도 있나."""
    i = low.find(k)
    while i >= 0:
        nxt = low[i + len(k):i + len(k) + 1]
        if not nxt or not _HANGUL.match(nxt):
            return True
        i = low.find(k, i + 1)
    return False


def match_exclude(text, kw_list=None, db_path=DB, lang=None):
    """text(제목+설명+채널)에 제외 키워드가 있으면 첫 매칭어, 없으면 None.

    ★ `lang` 을 주면 **그 언어의 실정**으로 잰다(2026-09-06 사용자 지시).
    """
    if not text:
        return None
    # ★ **미리 받아 둔 것이 「언어별 표」면 그 자리에서 언어로 가른다** —
    #   수집 한 바퀴에 수백 번 도는 자리라 미리 받아 두는데(kw_list), 그것이
    #   평면 목록이면 언어가 안 먹는다. 표를 주면 여기서 갈라 준다.
    if isinstance(kw_list, dict):
        kw_list = kw_for(kw_list, lang)
    if kw_list is None:
        kw_list = get_exclude_kw(db_path, lang)
    low = text.lower()
    for kw in kw_list:
        if not kw:
            continue
        k = str(kw)
        if k.endswith(WORD_END):
            if _hit_word_end(low, k[:-1].lower()):
                return kw
        elif k.lower() in low:
            return kw
    return None


# ── 채널 거르는 말 — 이단·타종교 「단체」 (2026-09-09 신설) ───────────────
#: ★★★ **세 층 가운데 가장 센 층이다.** 위 `EXCLUDE_KW`(콘텐츠 거르는 말)는 제목에
#:   걸리면 ⚠ 표식을 붙이고 최신 발행에서만 뺀다 — 검토자가 한 번 보고 살릴 수
#:   있게. 이 표는 **단체 자체가 이단·타종교**라 살릴 것이 없으므로 **채널째
#:   건너뛴다**(앵커가 있어도 못 이긴다).
#:   사용자 지시(2026-09-09) 「채널 단위, 컨텐츠 단위로 거르는 말을 정교하게
#:   설계하라 · RSS 첫단계의 씨앗낱말 키워드에도 제외낱말 개념이 반드시 필요하다」.
#:
#: ★★★ **넣는 잣대 = 그 단체의 고유 이름 · 경전 · 창시자 · 직제.** 실측(수집
#:   19,104편)에서 **홑낱말은 예외 없이 정통 채널에 걸렸다**:
#:     `LDS`(Toward·reward 31/31 오탐) · `ward`·`stake`(전부 오탐) · `Elder`(개신교
#:     장로) · `Allah`(인도네시아 개신교의 하나님) · `전능하신 하나님`(정통 QT 3편) ·
#:     `Church of God`(정통 Church of God 교단 4채널) · `신천지` 홑낱말(반박 채널) ·
#:     `유월절`·`안식일`·`시온`(정통 41편) · `全能神`(「教會」를 붙여야 단체) ·
#:     `Muslim`·`Islam` 홑낱말(종교사·변증) · `adventist` 설명문 걸림.
#:   ⇒ 여기 든 것은 전부 **그 단체만 쓰는 표기**다. 늘릴 때도 같은 잣대.
#:
#: ⚠ **본다 = 채널 이름 · 채널 설명 · 표본 제목 · 영상 제목 · 설명문.** 콘텐츠
#:   거르는 말과 달리 설명문까지 보는 까닭 — 몰몬 채널 둘(norio koyama · Scripture
#:   Central Japanese)은 **설명문에만** 「末日聖徒イエス・キリスト教会」가 있다.
#: ⚠ **꾸란 비교 영상은 낱말로 못 가른다** — 이슬람 선교 채널과 기독교 변증 채널이
#:   같은 제목(「노아의 방주: 성경 대 꾸란」)을 쓴다. 그것은 **채널 차단**의 몫이고
#:   여기서는 `الدعوة الإسلامية`(이슬람 선교) 같은 단체 표기만 넣는다.
#: ⚠ **안식교는 KO 에만**(사용자 확정 「제칠일안식교는 한국의 경우에만」) —
#:   한국 주요 교단은 이단으로 분류하지만 해외 복음주의권은 그렇게 보지 않는다.
#: ⚠ **여호와의 증인 반박 영상도 걸린다**(「Заблуждения Свидетелей Иеговы」) —
#:   채널째 거르는 층이라 살릴 길이 좁다. 실측 0편이라 지금은 감수하고,
#:   반박 채널이 실제로 걸리면 그때 「등록 채널은 이 층을 안 지난다」는 예외를 논한다.
#:   지금은 **등록 채널도 예외가 아니다** — 등록이 실수일 수 있다(실측 몰몬 아랍어 공식
#:   채널이 등록돼 있었다). `media_intake.screen` 이 그 규칙의 집이다.
CHANNEL_KEY = 'MEDIA_EXCLUDE_KW_CHANNEL'

CHANNEL_KW_LANG = {
    # ★ 언어무관 = 그 단체가 스스로 쓰는 고유명. 라틴·CJK·아랍 표기가 어느 언어 제목에도
    #   오므로 여기 둔다(중국어는 간체·번체가 한 채널에 섞인다 — §203차. 둘 다 적는다).
    '*': [  # 몰몬(LDS)
          'Latter-day Saint', 'Latter Day Saint', 'Book of Mormon', 'Joseph Smith',
          'Doctrine and Covenants', 'Pearl of Great Price', 'Scripture Central',
          'Book of Mormon Central',
          '末日聖徒', '末日圣徒', '摩爾門經', '摩尔门经', 'モルモン書',
          'قديسي الأيام الأخيرة', 'قديسي الايام الاخيرة', 'كتاب مورمون',
          # 여호와의 증인
          "Jehovah's Witness", 'Jehovah’s Witness', 'Watchtower', 'JW.org',
          'New World Translation', 'Kingdom Hall', 'JW Broadcasting',
          '耶和華見證人', '耶和华见证人', '守望台', 'エホバの証人', 'ものみの塔',
          'شهود يهوه', 'برج المراقبة',
          # 하나님의교회(안상홍) · 신천지 · 전능신교 · 통일교 · 구원파 · JMS
          'World Mission Society', 'WMSCOG', 'Ahnsahnghong', 'Shincheonji',
          'Church of Almighty God', 'Eastern Lightning', 'Unification Church',
          'Family Federation', 'GoodNews Mission', 'Providence Church',
          '上帝的教會世界福音宣教協會', '上帝的教会世界福音宣教协会', '安商洪',
          '全能神教會', '全能神教会', '東方閃電', '东方闪电', '統一教', '统一教',
          # 암스트롱 계열(Worldwide Church of God 분파)
          'Living Church of God', "Tomorrow's World", 'Philadelphia Church of God',
          'United Church of God', 'Restored Church of God',
          # 이슬람 선교 단체(꾸란 자체는 콘텐츠 층 — 변증 채널과 같은 제목을 쓴다)
          'Islamic dawah', 'Let the Quran Speak', 'الدعوة الإسلامية', 'الدعوة الاسلامية'],
    'EN': ['Christian Science', 'Iglesia ni Cristo', 'Unitarian Universalist'],
    'KO': ['후기 성도', '후기성도', '말일성도', '몰몬경', '몰몬의 책',
           '여호와의 증인', '여호와의증인', '파수대', '왕국회관', '신세계역',
           '세계복음선교협회', '하나님의교회', '안상홍', '어머니 하나님', '어머니하나님',
           '전능하신 하나님 교회', '전능하신하나님교회', '전능신교', '동방번개',
           '신천지예수교', '신천지 예수교', '증거장막성전', '이만희',
           '기쁜소식선교회', '박옥수',
           '가정연합', '문선명', '기독교복음선교회', '정명석',
           '만민중앙', '이재록', '천부교', '박태선',
           # 안식교 — 한국에서만(사용자 확정)
           '제칠일안식일', '안식일예수재림', '안식교', '재림교회', '엘렌 화잇', '엘렌 G. 화잇'],
    'JA': ['統一教会', '家庭連合'],
    'ES': ['Santos de los Últimos Días', 'Libro de Mormón', 'Testigos de Jehová',
           'Atalaya', 'Iglesia de Dios Sociedad Misionera Mundial'],
    'PT': ['Santos dos Últimos Dias', 'Livro de Mórmon', 'Testemunhas de Jeová', 'Sentinela'],
    'DE': ['Heiligen der Letzten Tage', 'Buch Mormon', 'Zeugen Jehovas', 'Wachtturm'],
    'FR': ['Saints des Derniers Jours', 'Livre de Mormon', 'Témoins de Jéhovah', 'Tour de Garde'],
    # ⚠ 러시아어는 굴절한다 — 「Свидетели/Свидетелей/Свидетелям Иеговы」. 격마다 적는다.
    'RU': ['Святых последних дней', 'Книга Мормона', 'Свидетели Иеговы', 'Свидетелей Иеговы',
           'Свидетелям Иеговы', 'Сторожевая башня', 'Церковь Бога Общество Всемирной Миссии'],
}

#: ★★ **비판자 라벨·타종교 경전 이름은 여기(콘텐츠 층·⚠ 표식)** — 채널 층에 넣으면
#:   정통 설교가 걸린다(실측 「구원파」가 분당샛별교회 이한규 목사 설명문에 · 「Koran」이
#:   「Koran Dothan and Abiram」 오타에 · 꾸란 비교는 변증 채널과 이슬람 선교 채널이
#:   같은 제목). 이 층은 담기는 하되 ⚠ 를 붙이고 최신 발행에서만 뺀다.
_EXCLUDE_MORE = {
    'EN': ['Quran', "Qur'an", 'Koran', 'Hadith', 'Surah', 'Ramadan', 'Sharia', 'Mormon',
           'Mormonism', 'Catholic Bible', 'Catholic Church', 'homily', 'Fr. '],
    'KO': ['꾸란', '코란', '이슬람', '무슬림', '하디스', '몰몬', '모르몬', '구원파', '통일교',
           '신천지', '안식교인', '천주교회', '신부님', '가톨릭'],
    'JA': ['イスラム教', 'コーラン', 'モルモン', '神父', '司祭', '司教'],
    'ZH': ['古兰经', '古蘭經', '伊斯兰教', '伊斯蘭教', '摩尔门', '摩爾門', '神父'],
    'ZHT': ['古蘭經', '古兰经', '伊斯蘭教', '伊斯兰教', '摩爾門', '摩尔门', '神父'],
    'AR': ['القرآن', 'سورة ', 'حديث نبوي', 'عيسى ابن مريم', 'عيسى بن مريم', 'النبي محمد',
           'رمضان', 'الشريعة الإسلامية', 'مورمون',
           ],
    'ES': ['Corán', 'islámic', 'mormón', 'mormon', 'católic'],
    'PT': ['Alcorão', 'islâmic', 'mórmon', 'católic'],
    'DE': ['Koran', 'islamisch', 'Mormonen', 'katholisch'],
    'FR': ['Coran', 'islamique', 'mormon', 'catholique', 'abbé'],
    'RU': ['Коран', 'исламск', 'мормон'],
    # ★ **유대교는 `_JEW_CONTENT` 가 아래에서 함께 넣는다**(채널 층과 한 자리에
    #   두어야 「무엇을 채널 층에 두고 무엇을 콘텐츠 층에 뒀나」가 한눈에 보인다).
}
for _k, _v in _EXCLUDE_MORE.items():
    _cur = EXCLUDE_KW_LANG.setdefault(_k, [])
    for _w in _v:
        if _w not in _cur:
            _cur.append(_w)

#: ★★★ **교회 살림 공지** — 콘텐츠 층에 더한다(2026-09-12 사용자 「부적절한
#:   데이터를 수집제외할 수 있는 **거르는 말을 발굴**하라」).
#: ✅ **전 수집분 21,698편에 걸어 오탐 0 을 확인하고** 담았다 — 성경 본문을
#:   다루지 않고 **그 교회 안에서만 뜻이 있는 것**이다(모집·졸업식·임직식).
#: ⚠⚠ **실측이 거의 없다는 것이 결론이다** — 후보 다섯 갈래를 전수로 걸어
#:   보니 쓸 만한 것이 **7편**뿐이었다. 「반주 강좌」는 2편인데 **둘 다 정당한
#:   Piano tutorial** 이고, 「논란·폭로」 10편은 **설교 제목의 수사**였다
#:   (「시내산 위치 **논란**」·「느부갓네살 비석의 **폭로**」).
#: ⚠⚠⚠ **「김장」이 「김장환목사」를 먹었다** — §228차 홑낱말 함정의 여섯째
#:   자리다. 교회 나들이 후보 5편 중 **4편이 그 오탐**이었다. 그래서 **뺐다.**
#: ⚠ 이 층은 **⚠ 표식**이라 사람이 보고 살릴 수 있다 — 채널 층이 아니다.
_EXCLUDE_NOTICE = {
    'KO': ['모집합니다', '모집 안내', '수강생 모집', '신입생 모집', '입학설명회',
           '수강 신청', '공지사항 및', '졸업식', '임직식', '정기총회'],
    'EN': ['Graduation Day', 'Closing Program', 'Enrollment Now Open'],
}
for _k, _v in _EXCLUDE_NOTICE.items():
    _cur = EXCLUDE_KW_LANG.setdefault(_k, [])
    for _w in _v:
        if _w not in _cur:
            _cur.append(_w)

#: ★★★ **다른 종교는 무조건 제외한다**(2026-09-09 사용자 확정). 그전에는 가톨릭·
#:   정교회·타종교가 **콘텐츠 층(⚠ 표식)** 에만 있어 사람이 승인하면 나갈 수
#:   있었다 — 「무조건」은 그 재량을 없앤다는 뜻이라 **채널 층**으로 올린다.
#: ⚠⚠ **홑낱말은 여기서도 예외 없이 정통 채널을 먹는다**(§228차 그 자리 · 전수 실측):
#:   `정교회`←**송정교회·예정교회** · `유교`←**자유교회·온유교회** ·
#:   `불교`←**등불교회** · `신부`←**예수님의신부TV·성령과 신부** ·
#:   `교구`←**수원성교회 청년교구** · `道教`←**真道教會·大道教會** ·
#:   `Orthodox`←**Tyrannus' Orthodox Theological Seminary** ·
#:   `católic`←개신교 채널의 「어느 성경을 고를까」 제목 ·
#:   `天主教`←개신교 채널 설명문의 언급.
#:   ⇒ **자칭 고유명·기관명, 그리고 라틴권은 구(句)로만.** 아래는 전 19,301편에
#:     걸어 **오탐 0** 을 확인하고 담은 것이다.
_CHANNEL_MORE = {
    # ★★★ **콥트는 채널 층에서 뺐다**(2026-09-12 사용자 「정교회가 아니라
    #   **콥트교**를 말한 것이다」) — 여기는 **채널째 건너뛰는** 가장 센 층이라
    #   남겨 두면 콥트 채널을 영영 못 담는다. `Coptic`·`القبطية` 를 안 넣는다.
    #   ⚠ 정교회(`Orthodox Church`·`Православ`)는 **그대로 거른다**.
    '*': ['cpbc', 'Orthodox Church', 'Ortodox', 'ortodoxa', 'Православ',
          # 아직 자료에 없지만 자칭이라 오탐이 없다(예방)
          'Soka Gakkai', 'Hare Krishna', 'Bhagavad Gita', 'Buddhist Temple',
          'Islamic Center', 'Masjid'],
    # 2026-09-16 · 1.txt 사용자 「기독교에서 신부 용어 등장한다. 그러나 신부님은 등장하지
    #   않는다」 — 홑낱말 '신부' 는 예수님의신부TV 를 먹는다(§233차). 호칭 '신부님' 만.
    #   실측 53,117편 — 채널 이름에 든 곳은 「홍성남신부님의 톡쏘는 영성심리」 하나(14편 재승인),
    #   제목에 든 것은 가톨릭스튜디오 4편뿐 · 개신교 채널 0.
    'KO': ['신부님', '가톨릭', '천주교', '대교구', '수녀회', '평화방송',
           '한국정교회', '대한정교회',
           '스님', '조계종', '조계사', '봉은사', '템플스테이',
           '원불교', '대순진리', '증산도', '천도교'],
    'JA': ['カトリック', '司教区', '創価学会', '真言宗', '浄土真宗'],
    'ZH': ['天主教會', '天主教会', '天主教之聲', '佛教協會', '佛教协会'],
    'ZHT': ['天主教會', '天主教会', '天主教之聲', '佛教協會', '佛教协会'],
    'EN': ['Catholic Church', 'Catholic Bible', 'Catholic TV', 'Catholic Diocese'],
    'ES': ['Iglesia Católica', 'Biblia Católica'],
    'PT': ['Igreja Católica', 'Bíblia Católica'],
    'DE': ['katholisch.de', 'Katholisches Fernsehen', 'Katholische Kirche'],
    'FR': ['Église catholique', 'Eglise catholique'],
    'AR': ['الكنيسة الكاثوليكية'],
}
#: ★★★ **유대교 — 채널 층**(2026-09-12 사용자 「유대교 거르는 말 진행하라」).
#: ⚠⚠⚠ **홑낱말은 여기서도 예외 없이 기독교 자료를 먹는다**(§228차 홑낱말
#:   함정의 **일곱째** 자리). 실측 42,344편 전수:
#:   | 홑낱말 | 걸린 것 | 무엇이 걸렸나 |
#:   |---|---|---|
#:   | `torah` | **105편 · 27채널** | **Carmen Joy Imes**(기독교 구약학자) · **BibleProject** · **바이블프로젝트 BibleProject - Korean** · Pastor Randy Powell |
#:   | `rabbi` | 24편 | **Discovering the Jewish Jesus with Rabbi Schneider**(메시아닉 방송 — 예수를 전한다) |
#:   | `유대인`·`토라`·`랍비` | 37편 | 대부분 기독교 설교 |
#:   | `talmud`·`synagogue`·`kabbalah` | 6편 | 기독교 비교 강의 |
#:   ⇒ **자칭 단체명·교파 구(句)만** 담는다. 아래는 전 42,344편에 걸어
#:     **걸린 것 5편 · 오탐 0** 을 확인한 것이다(Jews for Judaism ·
#:     Lapid Judaism · Jewels of Judaism · Judaismo Abierto ·
#:     Jewish Learning Institute — **다섯 곳 다 진짜 유대교 단체**다).
#: ⚠ `yeshiva` 를 홑낱말로 안 넣는다 — 실측 **夏達華研道中心 HaDavar Yeshiva**
#:   가 로마서를 강해하는 **중국어 기독교 채널**이다. `yeshiva university` 처럼
#:   기관 전체 이름으로만 적는다.
_JEW_MORE = {
    # ★★★ **채널 층에는 「자칭 조직 고유명」만** — 실측이 그 선을 그었다.
    '*': ['Jews for Judaism', 'Lapid Judaism', 'Jewels of Judaism',
          'Jewish Learning Institute', 'Chabad', 'Lubavitch',
          'Aish HaTorah', 'Ohr Somayach'],
    'ES': ['Judaismo Abierto', 'Judaísmo Abierto'],
    'KO': ['유대교 회당', '랍비 유대교'],
}
#: ⚠⚠⚠ **아래는 채널 층에서 뺐다 — 설명문 오탐을 실측으로 잡았다**(2026-09-12).
#:   첫 판에서 두 편이 걸렸고 **둘 다 기독교 자료**였다:
#:   · `Jewish Theological Seminary` ← **Northville Baptist Church** 목사의
#:     학력(「Dr. Christopher Dost (Ph.D., The Jewish Theological Seminary)」)
#:   · `Rabbinic Judaism` ← **Pastor Randy Powell** 「"Jesus, My Rabbi"」
#:   ★★★ **자칭은 채널 이름에 나오고 언급은 설명문에 나온다** — 채널 층은
#:     「**누가 만들었나**」를 묻는 층이라(§237차 ⓪) 학교·문헌·교파 이름은
#:     그 물음에 답하지 못한다. 그것은 「무엇을 가르치나」(콘텐츠 층)다.
#:   ⇒ 아래는 **콘텐츠 층(⚠ 표식)** 으로 내렸다 — 사람이 보고 살릴 수 있다.
_JEW_CONTENT = {
    '*': ['Orthodox Judaism', 'Reform Judaism', 'Conservative Judaism',
          'Rabbinic Judaism', 'Rabbinical Judaism', 'Hasidic Judaism',
          'Reconstructionist Judaism', 'Yeshiva University',
          'Jewish Theological Seminary', 'Hebrew Union College',
          'Beit Midrash', 'Beth Midrash', 'Beth Din', 'Bet Din', 'Kollel',
          'Babylonian Talmud', 'Jerusalem Talmud', 'Daf Yomi',
          'Gemara Shiur', 'Mishnah Study', 'Parsha Shiur',
          'Kabbalah', 'Zohar', 'Halakha', 'Halacha'],
    'ES': ['Judaísmo Ortodoxo', 'Judaismo Ortodoxo'],
    'PT': ['Judaísmo Ortodoxo'],
    'KO': ['정통 유대교', '유대교 랍비', '탈무드 강해', '카발라'],
    'JA': ['ユダヤ教'],
    'ZH': ['猶太教', '犹太教'],
    'ZHT': ['猶太教', '犹太教'],
}
for _k, _v in _JEW_CONTENT.items():
    _cur = EXCLUDE_KW_LANG.setdefault(_k, [])
    for _w in _v:
        if _w not in _cur:
            _cur.append(_w)
for _k, _v in _JEW_MORE.items():
    _cur = _CHANNEL_MORE.setdefault(_k, [])
    for _w in _v:
        if _w not in _cur:
            _cur.append(_w)
for _k, _v in _CHANNEL_MORE.items():
    _cur = CHANNEL_KW_LANG.setdefault(_k, [])
    for _w in _v:
        if _w not in _cur:
            _cur.append(_w)



def get_channel_map(db_path=DB):
    """채널 거르는 말 → `{lang: [...]}`. 없으면 기본값."""
    return _as_lang_map(_cfg_json(db_path, CHANNEL_KEY), CHANNEL_KW_LANG)


def get_channel_kw(db_path=DB, lang=None):
    return kw_for(get_channel_map(db_path), lang)


def save_channel_kw(db_path, lang, words):
    """그 언어 버킷만 갈아 끼운다(다른 언어는 지킨다). 씨앗 탭·분류관리가 함께 쓴다."""
    cur = get_channel_map(db_path)
    cur[str(lang).upper()] = [str(w).strip() for w in (words or []) if str(w).strip()]
    conn = appdb.connect(db_path)
    try:
        conn.execute("INSERT OR REPLACE INTO sys_config (config_key, config_val) VALUES (?,?)",
                     (CHANNEL_KEY, json.dumps(cur, ensure_ascii=False)))
        conn.commit()
    finally:
        conn.close()
    return cur


#: ★★★ **콥트 표식** — 이 말이 있으면 **정교회 낱말이 안 듣는다**(2026-09-12
#:   사용자 「**콥트교를 복구하라**는 것이었다. 정교회는 일단 기존 상태를 유지」).
#: ⚠⚠⚠ **낱말만으로는 못 가른다** — 콥트 정교회는 이름에 「Orthodox」가 들어간다
#:   (실측 「St. Mary & St. Joseph **Coptic Orthodox** Church」). 정교회를 거르면서
#:   콥트를 허용하려면 **콥트가 이긴다**는 규칙이 있어야 한다.
#: ⚠ 정교회 낱말에만 듣는다 — 몰몬·이슬람·가톨릭 낱말은 그대로 건다.
COPT_OK = ('coptic', 'copte', 'kopt', 'قبطي', 'القبطية', 'الأقباط', '콥트',
           '科普特')

#: 콥트가 이기는 **정교회 계열** 낱말 — 위 표들에서 뽑은 것과 같은 글자여야 한다
ORTHO_WORDS = ('orthodox church', 'eastern orthodox', 'greek orthodox',
               'russian orthodox', 'divine liturgy', 'orthodox liturgy',
               'ortodox', 'ortodoxa', 'orthodoxe kirche', 'göttliche liturgie',
               'église orthodoxe', 'liturgie orthodoxe', 'iglesia ortodoxa',
               'liturgia ortodoxa', 'igreja ortodoxa', 'православн',
               'православ', 'أرثوذكس', 'ορθόδοξ', '한국정교회', '대한정교회')


def is_coptic(text):
    """이 글이 **스스로 콥트라고 말하는가** — 그러면 정교회 낱말이 안 듣는다."""
    low = str(text or '').lower()
    return any(w in low for w in COPT_OK)


def _ortho_only(hit):
    """걸린 낱말이 **정교회 계열인가**."""
    return str(hit or '').lower().strip() in ORTHO_WORDS


#: ★★★ **메시아닉 표식** — 이 말이 있으면 **유대교 낱말이 안 듣는다**
#:   (2026-09-12 · §245차 콥트 장치와 **같은 모양**).
#: ⚠⚠⚠ **메시아닉은 우리가 일부러 담은 갈래다**(§245~247차 — 사역자 15명 ·
#:   앨범 · 곡 10개). 그들은 **스스로를 유대교 낱말로 말한다**(「Messianic
#:   Judaism」·「Torah Life Ministries」). 막으면 우리가 공들여 모은 것을
#:   우리 손으로 끊는다.
#: ⚠ **유대교 낱말에만 듣는다** — 메시아닉 채널이라도 이슬람·몰몬·가톨릭
#:   낱말에는 그대로 걸린다(콥트와 같은 경계).
MESS_OK = ('messianic', 'mesianic', 'mesiánic', 'messianisch', 'messianique',
           'yeshua', 'yeshuah', 'mashiach', 'meshiach', 'moshiach',
           'hebrew roots', 'netzarim', 'nazarene israel',
           '메시아닉', '예슈아', '彌賽亞信徒', '弥赛亚信徒', 'メシアニック')


def is_messianic(text):
    """이 글이 **스스로 메시아닉이라고 말하는가** — 그러면 유대교 낱말이
    안 듣는다.

    ⚠⚠⚠ **첫 줄(채널 이름)만 본다 — 실측으로 당해서 고쳤다**(2026-09-12).
      콥트는 「스스로 콥트라고 말한다」가 설명문에서도 참인데, 유대교 반선교
      단체는 **반박 대상으로 메시아닉을 언급한다**. 실측 —
      **Jews for Judaism** 이 설명문에 「Reply2 One for Israel Maoz
      **Messianic** Jews for Jesus & ASKDrBrown」이라 적어 두어, 글 전체를
      보던 첫 판이 그 언급을 **자칭으로 읽고 차단을 껐다**.
      ★★★ **자칭은 채널 이름에, 언급은 설명문에** — 오늘 같은 원리에 두 번
      걸렸다(학교 이름 · 이 자리).
    ⚠ **규약 — `match_channel` 에 주는 글은 첫 줄이 채널 이름이다.** 부르는
      곳 여섯이 전부 그렇다(`media_intake` 2 · `db_heresy_sweep` ·
      `db_channel_mine` · `latest_rules` · `db_channel_vet`). 규약을 어기면
      메시아닉 채널이 막히므로 **selftest 가 그 여섯을 소스로 잰다**.
    """
    low = str(text or '').split(chr(10))[0].lower()
    return any(w in low for w in MESS_OK)


def _jew_only(hit):
    """걸린 낱말이 **유대교 계열인가**."""
    low = str(hit or '').lower().strip()
    return any(low == str(w).lower() for v in _JEW_MORE.values() for w in v)


def match_channel(text, kw_list=None, db_path=DB, lang=None):
    """채널 거르는 말이 있으면 걸린 낱말, 없으면 None. `match_exclude` 와 같은 문법
    (`$` 낱말 끝 표시 · 대소문자 무시) — 두 벌이 되지 않게 그 문을 그대로 부른다."""
    if not text:
        return None
    if isinstance(kw_list, dict):
        kw_list = kw_for(kw_list, lang)
    if kw_list is None:
        kw_list = get_channel_kw(db_path, lang)
    hit = match_exclude(text, kw_list=kw_list, lang=lang)
    # ★★★ **콥트가 이긴다** — 정교회 낱말에만 듣는다(2026-09-12).
    if hit and _ortho_only(hit) and is_coptic(text):
        rest = [k for k in (kw_list or []) if not _ortho_only(k)]
        hit = match_exclude(text, kw_list=rest, lang=lang)
    # ★★★ **메시아닉이 이긴다** — 유대교 낱말에만 듣는다(2026-09-12).
    if hit and _jew_only(hit) and is_messianic(text):
        rest = [k for k in (kw_list or []) if not _jew_only(k)]
        return match_exclude(text, kw_list=rest, lang=lang)
    return hit


# ── 관련성 필터 — 「성경 본문을 다루지 않는 영상」 ─────────────────────────
#: ★★★ **교파 필터와 다른 갈래다** (2026-09-04 사용자 지적 「크롤러가 키워드를
#:   제대로 필터링하지 않는구나」 · 「**필터링 로직 보강해라**」).
#:   위 `EXCLUDE_KW` 는 **타교파**를 가리고, 이것은 **성경 본문과 무관한 꼴**을
#:   가린다. 실측 — 보관함 「실마리 없음」 1,727건의 제목 낱말 상위가
#:   주일 202 · 예배 184 · 주일예배 95 · 부예배 58 · 실황 56 · 중계 35 다.
#: ⚠⚠ **낱말만으로 거르면 안 된다** — 실측 1,247건 중 **58%(722건)가 좌표·용어를
#:   함께 갖고 있다**(「주일예배 | 창세기 1장」). 그래서 **앵커가 있으면 필터가
#:   진다** — 이 규칙이 없으면 정당한 722건을 잃는다.
#: ⚠ **낭독·오디오는 여기 넣지 않는다** — 「마태복음 전체낭독」은 버릴 것이
#:   아니라 **책 전체로 걸 것**이다(보관함 BOOK 유형이 맡는다).
OFFTOPIC_KEY = 'MEDIA_OFFTOPIC_KW'

DEFAULT_OFFTOPIC_KW = [
    # 예배 실황·중계 — 그 자체로는 어느 본문인지 알 수 없다
    '주일예배', '주일 예배', '수요예배', '수요 예배', '금요철야', '철야예배',
    '새벽기도회', '대예배', '부예배', '예배실황', '예배 실황', '실시간 예배',
    '실시간예배', '온라인 예배', '온라인예배', '인터넷예배', '예배중계', '예배 중계', '생중계',
    'live worship', 'sunday service', 'worship service',
    # 음악·행사
    '찬양집회', '성가대', '합창단', 'worship song', 'music video', 'ccm',
    # 그 밖
    '간증', '광고', '후원 안내', '교회 소개', '헌금 안내',
]


#: ★★ **관련성 필터도 언어 축**(2026-09-06) — 「주일예배」에 해당하는 말이
#:   언어마다 다르다. 옛 평면 목록은 KO 25 · 라틴 6 이라 그 밖 아홉 언어에서
#:   **한 번도 안 걸렸다**.
#: ⚠ 이 필터는 교파 판정이 아니라 **「본문이 안 보이는 꼴인가」**다 —
#:   그래서 언어별 실정 문제가 작다. 다만 **말이 있어야 걸린다.**
OFFTOPIC_KW_LANG = {
    'KO': ['주일예배', '주일 예배', '수요예배', '수요 예배', '금요철야',
           '철야예배', '새벽기도회', '대예배', '부예배', '예배실황',
           '예배 실황', '실시간 예배', '온라인 예배', '온라인예배', '실시간예배', '인터넷예배',
           '예배중계', '예배 중계', '생중계', '찬양집회', '성가대', '합창단',
           '간증', '광고', '후원 안내', '교회 소개', '헌금 안내'],
    'EN': ['sunday service', 'worship service', 'live worship',
           'sunday worship', 'live stream', 'livestream', 'praise night',
           'choir', 'testimony', 'announcement', 'giving', 'church tour'],
    'ZH': ['主日崇拜', '主日礼拜', '晚崇拜', '祷告会', '直播', '诗班',
           '见证', '奉献', '教会介绍'],
    'ZHT': ['主日崇拜', '主日禮拜', '晚崇拜', '禱告會', '直播', '詩班',
            '見證', '奉獻', '教會介紹'],
    'JA': ['主日礼拝', '日曜礼拝', '祈祷会', 'ライブ配信', '聖歌隊',
           '証し', '献金', '教会紹介'],
    'DE': ['Gottesdienst', 'Livestream', 'Lobpreisabend', 'Chor',
           'Zeugnis', 'Kollekte'],
    'FR': ['culte du dimanche', 'culte en direct', 'chorale',
           'témoignage', 'offrande'],
    'ES': ['culto dominical', 'servicio dominical', 'en vivo', 'coro',
           'testimonio', 'ofrenda'],
    'PT': ['culto de domingo', 'culto ao vivo', 'coral', 'testemunho',
           'oferta'],
    'RU': ['воскресное богослужение', 'прямая трансляция', 'хор',
           'свидетельство', 'пожертвование'],
    'AR': ['خدمة الأحد', 'بث مباشر', 'كورال', 'شهادة'],
    '*': ['ccm', 'music video', 'worship song'],
}


#: ★★★ **분야(domain) — 「원하는가」를 묻는 층에만 있는 축** (2026-09-10
#:   사용자 지시 「씨앗낱말을 공통·분야별 개별 두 가지로 운영하라 · 전능신교는
#:   공통 · 연속듣기는 개별 필터링」).
#:
#:   원리 한 줄 — **「무엇인가」를 묻는 층은 공통, 「원하는가」를 묻는 층은 분야별.**
#:     · 채널 거르는 말(누가 만들었나) · 콘텐츠 거르는 말(무엇을 가르치나) ·
#:       분류 낱말(무엇인가) → **분야가 못 바꾼다.** 전능신교는 어느 분야에서
#:       찾아도 전능신교다.
#:     · 오프토픽(이번에 원하는가) · 씨앗 낱말(무엇을 찾나) → **분야를 탄다.**
#:
#:   ⚠⚠ **분야별 층은 「공통과의 차이」만 담는다** — 통째로 복제하면 갈라지고,
#:     갈라지면 오래된 쪽이 남는다(§0-1). 그래서 `exempt`(면제) · `extra`(추가)
#:     두 줄뿐이다.
#:   ⚠ **분야는 콘텐츠 속성이 아니라 「이번 수집의 의도」다.** 담긴 뒤의 유형은
#:     `media_taxonomy` 가 정한다(공통 층). 이 구분이 흐려지면 분야가 여섯 번째
#:     분류 축이 되어 버린다. `audience`(KIDS/SIGN)·`SCOPE_AXIS`(연결 대상)와
#:     **이름도 뜻도 다르다.**
DOMAIN_COMMON = 'COMMON'
OFFTOPIC_DOMAIN_KEY = 'MEDIA_OFFTOPIC_DOMAIN'

#: ★★★ **찬양 겨냥 수집에서 면제하는 19낱말** — 2026-09-10 실측으로 골랐다.
#:   오프토픽 97낱말 중 이 19개만 분야를 탄다(20%). 전부 **성악·찬양집회·
#:   라이브·CCM** 이고, 구절 수집에서는 「이건 설교가 아니다」이지만 **찬양
#:   수집에서는 그것이 바로 대상**이다(성악합창은 `rend_kind` 의 정식 갈래다).
#:   ⚠ 이 19개가 겨냥 검색 625편 중 **86편(14%)** 을 죽이고 있었다 —
#:     전부 정당한 찬양 묶음이었다(DonMoenTV · Hillsong · Top 100 Praise).
#:   ⚠ 한국어만 살아남던 까닭 = 한국 제목은 「찬양 모음」이라 쓰고
#:     `worship song` 이라 쓰지 않기 때문이다. 그것이 전부였다.
_WORSHIP_EXEMPT = [
    '찬양집회', '성가대', '합창단',
    'live worship', 'praise night', 'choir',
    '诗班', '詩班', '聖歌隊', 'Lobpreisabend', 'Chor', 'chorale',
    'coro', 'coral', 'хор', 'كورال',
    'ccm', 'music video', 'worship song',
]

#: 낭독(성경듣기) 겨냥 수집 — 설교·강해가 섞이면 걸러야 한다(**추가** 쪽 보기).
#: ⚠ 아직 쓰는 곳이 없다 — `READING` 분야를 실제로 세울 때 실측으로 채운다.
_READING_EXTRA = []

#: ★ 기도 겨냥 수집(2026-10-12) — **개신교 중심 앱**이라 가톨릭·정교회 예식 기도와 다른 종교 기도를 거른다.
#:   표본 실측: 프랑스어 「Avec Marie」 20/48 · 포르투갈어 「Padre …」 · 일본어 「カトリック」 · 러시아·아랍 정교회.
#:   ⚠ 러시아어 「святой」(거룩한)는 안 넣는다 — 찬양 점검 때 헛걸렸다(Святой = 개신교 찬양에도 흔하다).
_PRAYER_EXTRA = [
    # 묵주·성모·9일기도·자비의 기도
    'rosary', 'rosario', 'rosaire', 'rosenkranz', 'terço', '묵주', '로사리오', 'ロザリオ', '玫瑰经', '玫瑰經', 'مسبحة',
    'hail mary', 'ave maria', 'ave maría', 'avec marie', 'virgin mary', 'virgen maría', 'nossa senhora',
    'mère de dieu', 'gottesmutter', 'богородиц', 'العذراء', '성모', '聖母', '圣母',
    'novena', 'novène', 'novene', '9일기도', 'divine mercy', 'divina misericordia', 'divina misericórdia',
    'chapelet', 'coronilla', 'padre pio', 'акафист', 'catholic', 'católica', 'catholique', 'katholisch',
    'カトリック', '天主教', '가톨릭', '천주교',
    # 다른 종교
    'سورة', 'القرآن', 'quran', 'dua for', 'mantra', 'law of attraction', '끌어당김',
    # 2026-10-12 첫 바퀴 실측 — 이슬람 기도(두아)·힌두 축제가 「morning prayer」 로 섞였다
    'duasi', 'duası', 'doa ', '#doa', 'navratri', 'durga', 'hindu', 'krishna', 'allah', 'insha',
    'aigenerated', 'ai generated',
]

DEFAULT_OFFTOPIC_DOMAIN = {
    'WORSHIP': {'exempt': _WORSHIP_EXEMPT, 'extra': []},
    'PRAYER': {'exempt': [], 'extra': _PRAYER_EXTRA},
    'READING': {'exempt': [], 'extra': _READING_EXTRA},
    # ★ 등록 채널 수집(RSS·API) — 2026-09-16 저녁부터 **관련성 필터를 아예 안 거친다**
    #   (`media_intake.screen` 이 `domain='CHANNEL'` 이면 오프토픽을 묻지 않는다).
    #   이 줄은 옛 호출·재심사 도구가 분야 표를 물을 때를 위해 남긴다(뜻은 「면제」).
    'CHANNEL': {'exempt': _WORSHIP_EXEMPT, 'extra': []},
}

#: ★★★ **예배 실황 낱말 — 거르는 말이 아니라 「보관함 갈래」다**(2026-09-16 사용자
#:   「실황설교는 보관함에 담아 두었다가 다시 분석하자」). 실측 실황 낱말 영상 4,034편 중
#:   97% 가 설교이고 78% 가 교회 이름 채널 · 등록 채널이 98.5% 였다 — 「상관없는 영상」이
#:   아니라 **좌표가 없어 아직 못 건 영상**이다. 그래서 오프토픽 목록과 따로 둔다.
#:   ⚠ 성가대·합창단·testimony·giving 은 안 넣는다 — 실황이 아니라 다른 갈래다.
LIVE_SERVICE_KW = {
    'KO': ['주일예배', '주일 예배', '수요예배', '수요 예배', '금요철야', '철야예배',
           '새벽기도회', '대예배', '예배실황', '예배 실황', '실시간 예배', '온라인 예배',
           '인터넷예배', '예배중계', '예배 중계', '생중계', '온라인예배', '실시간예배'],
    'EN': ['sunday service', 'worship service', 'sunday worship', 'live stream', 'livestream'],
    'ZH': ['主日崇拜', '主日礼拜', '晚崇拜', '直播'],
    'ZHT': ['主日崇拜', '主日禮拜', '晚崇拜', '直播'],
    'JA': ['主日礼拝', '日曜礼拝', 'ライブ配信'],
    'DE': ['Gottesdienst', 'Livestream'],
    'FR': ['culte du dimanche', 'culte en direct'],
    'ES': ['culto dominical', 'servicio dominical', 'en vivo'],
    'PT': ['culto de domingo', 'culto ao vivo'],
    'RU': ['воскресное богослужение', 'прямая трансляция'],
    'AR': ['خدمة الأحد', 'بث مباشر'],
}


def match_live_service(text, lang=None):
    """제목이 예배 실황 꼴인가 → 걸린 낱말 또는 None. (앞 경계 규칙은 `_hits` 와 같다)"""
    if not text:
        return None
    words = list(LIVE_SERVICE_KW.get((lang or '').upper(), []))
    if not words:
        for v in LIVE_SERVICE_KW.values():
            words.extend(v)
    low = text.lower()
    for kw in words:
        if kw and _hits(str(kw).lower(), low):
            return kw
    return None


def get_offtopic_domain(db_path=DB):
    """분야별 오프토픽 차이 → `{domain: {'exempt': [...], 'extra': [...]}}`."""
    raw = _cfg_json(db_path, OFFTOPIC_DOMAIN_KEY)
    if not isinstance(raw, dict) or not raw:
        return DEFAULT_OFFTOPIC_DOMAIN
    for _k, _v in DEFAULT_OFFTOPIC_DOMAIN.items():      # 저장 표에 없는 분야는 기본값으로
        raw.setdefault(_k, _v)
    out = {}
    for d, v in raw.items():
        if isinstance(v, dict):
            out[str(d).upper()] = {'exempt': list(v.get('exempt') or []),
                                   'extra': list(v.get('extra') or [])}
        elif isinstance(v, list):        # 옛 꼴 — 면제 목록만 적은 것
            out[str(d).upper()] = {'exempt': list(v), 'extra': []}
    return out or DEFAULT_OFFTOPIC_DOMAIN


def save_domain_extra(db_path, domain, words):
    """그 분야의 「더 거르는 말」을 저장한다(기도 수집기 ② 화면 · 2026-10-12) → 저장한 수.

    ⚠ 다른 분야와 그 분야의 면제 목록은 **그대로** 둔다 — 표 전체를 읽어 그 칸만 바꾼다.
    """
    # ⚠ 저장 표에는 **고친 분야만** 적는다 — 나머지 분야는 코드 기본값을 계속 따른다(굳지 않게)
    d = dict(_cfg_json(db_path, OFFTOPIC_DOMAIN_KEY) or {})
    dom = str(domain).upper()
    cur = get_offtopic_domain(db_path).get(dom) or {'exempt': [], 'extra': []}
    seen, out = set(), []
    for w in words or []:
        w = str(w).strip()
        if w and w.lower() not in seen:
            seen.add(w.lower())
            out.append(w)
    d[dom] = {'exempt': list(cur.get('exempt') or []), 'extra': out}
    conn = appdb.connect(db_path)
    try:
        conn.execute("INSERT OR REPLACE INTO sys_config (config_key, config_val) VALUES (?,?)",
                     (OFFTOPIC_DOMAIN_KEY, json.dumps(d, ensure_ascii=False)))
        conn.commit()
    finally:
        conn.close()
    return len(out)


def apply_domain(kw_list, domain, dmap=None, db_path=DB):
    """공통 목록에 **그 분야의 차이만** 입힌다 → 목록.

    ⚠ `domain` 이 없거나 `COMMON` 이면 **글자 그대로 돌려준다** — 옛 동작과
      같다(회귀 0). 모르는 분야도 마찬가지다(조용히 덜 거르지 않는다).
    """
    kw_list = list(kw_list or [])
    if not domain or str(domain).upper() == DOMAIN_COMMON:
        return kw_list
    d = (dmap if dmap is not None else get_offtopic_domain(db_path)).get(
        str(domain).upper())
    if not d:
        return kw_list
    ex = {str(k).lower() for k in (d.get('exempt') or [])}
    out = [k for k in kw_list if str(k).lower() not in ex]
    for k in (d.get('extra') or []):
        if str(k).lower() not in {str(x).lower() for x in out}:
            out.append(k)
    return out


def get_offtopic_map(db_path=DB):
    """관련성 필터 → `{lang: [...]}`. 없으면 기본값."""
    return _as_lang_map(_cfg_json(db_path, OFFTOPIC_KEY), OFFTOPIC_KW_LANG)


def get_offtopic_kw(db_path=DB, lang=None):
    """관련성 필터 키워드. `lang` 을 주면 그 언어 + 언어무관."""
    return kw_for(get_offtopic_map(db_path), lang)


def match_offtopic(text, has_anchor=False, kw_list=None, db_path=DB,
                   lang=None, domain=None, dmap=None):
    """성경 본문과 무관한 꼴인가 → 매칭어 또는 None.

    `has_anchor` — 제목·설명문에서 **구절 좌표나 용어를 찾았는가**.
    ★ **앵커가 있으면 언제나 통과**한다(필터가 앵커를 이기지 못한다).
    ★ `lang` 을 주면 그 언어의 말로만 잰다.
    ★★ `domain` 을 주면 **그 분야의 차이만** 입힌다(면제·추가).
       ⚠ 안 주면 옛 동작 그대로다 — 이 인자는 **덜 거르는 쪽으로만** 움직이므로
         기본값이 늘 안전한 쪽이어야 한다.
    """
    if has_anchor or not text:
        return None
    if isinstance(kw_list, dict):        # 언어별 표를 주면 여기서 가른다
        kw_list = kw_for(kw_list, lang)
    if kw_list is None:
        kw_list = get_offtopic_kw(db_path, lang)
    kw_list = apply_domain(kw_list, domain, dmap, db_path)
    low = str(text).lower()
    for kw in kw_list:
        if kw and _hits(str(kw).lower(), low):
            return kw
    return None


#: ★★★ **라틴 낱말은 앞 경계를 본다**(2026-09-11 · §228차 홑낱말 함정의
#:   네 번째 자리). 실측 — `giving` 이 **`Thanksgiving`·`Forgiving`** 을 먹어
#:   「Todah 감사제」·「Thanksgiving for Kids」 같은 **정당한 찬양이 걸러졌다**.
#:   ⚠⚠ **뒤 경계까지 걸면 안 된다** — 재서 정했다. 뒤까지 걸면 `ofrendas`·
#:     `Gottesdienste`·`Zeugnisse`·`livestreaming` 같은 **어미 변화 24편**을
#:     함께 잃는다. **앞만** 걸면 잘못 걸린 6편만 정확히 빠진다(실측).
#:   ⚠ **한글·한자에는 안 건다** — 「2026주일예배」처럼 앞에 숫자가 붙어 있어
#:     경계가 없고, CJK 는 애초에 띄어쓰기로 낱말을 가르지 않는다.
_LAT_HEAD = re.compile(r'[a-z]')
_RX_CACHE = {}


def _hits(kw, low):
    """그 말이 글에 있나 — **라틴으로 시작하면 앞 경계를 본다**."""
    if not _LAT_HEAD.match(kw):
        return kw in low
    rx = _RX_CACHE.get(kw)
    if rx is None:
        rx = _RX_CACHE[kw] = re.compile(r'\b' + re.escape(kw))
    return bool(rx.search(low))


def seed_offtopic(db_path=DB):
    """`sys_config` 에 관련성 키워드를 1회 시드(멱등)."""
    conn = appdb.connect(db_path)
    try:
        if not conn.execute("SELECT 1 FROM sys_config WHERE config_key=?",
                            (OFFTOPIC_KEY,)).fetchone():
            conn.execute("INSERT INTO sys_config(config_key, config_val)"
                         " VALUES(?,?)",
                         (OFFTOPIC_KEY,
                          json.dumps(DEFAULT_OFFTOPIC_KW, ensure_ascii=False)))
            conn.commit()
            return True
    finally:
        conn.close()
    return False


def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', name, extra))

    # ⚠ **DB 설정값을 전제하지 않는다**(§0-5) — 관리자가 낱말을 빼면 시험이
    #   깨진다. 실제로 sys_config 에서 「미사」가 빠져 한 번 FAIL 했다.
    t('교파 필터가 돈다',
      match_exclude('연옥 교리 강해', kw_list=DEFAULT_EXCLUDE_KW) is not None)
    t('교파 필터가 개신교 글을 안 잡는다',
      match_exclude('창세기 1장 강해 설교', kw_list=DEFAULT_EXCLUDE_KW) is None)

    # ── ★★★ 언어 축 (2026-09-06 사용자 지시) ────────────────────────
    EM = EXCLUDE_KW_LANG
    t('★ 언어별 목록이 11언어를 덮는다',
      {'KO', 'EN', 'ZH', 'ZHT', 'JA', 'DE', 'FR', 'ES', 'AR', 'RU', 'PT'}
      <= set(EM), sorted(EM))
    t('★ 그 언어 + 언어무관만 본다',
      set(kw_for(EM, 'KO')) == set(EM['KO']) | set(EM['*']))
    t('★★ **한국어에서는 걸리고 영어에서는 안 걸린다**(같은 뜻·다른 실정)',
      match_exclude('교황 미사', kw_list=kw_for(EM, 'KO')) is not None
      and match_exclude('Sunday Mass at our church',
                        kw_list=kw_for(EM, 'EN')) is None)
    # ★★★ **뒤집힌 항목** — 2026-09-06 사용자 확정 「정교회도 카톨릭과 같이
    #   취급하라」. 옛 시험은 「정교회 말을 **안** 잡는다」를 잠그고 있었다.
    #   ⚠ 결정이 바뀌면 **그것을 잠근 시험도 함께 뒤집는다** — 안 그러면
    #     낡은 시험이 개선을 막는다(§db_pack_body 「시험이 낡으면」).
    t('★★ **러시아어 — 정교회 말도 잡는다**(가톨릭과 같이 취급)',
      match_exclude('Божественная литургия. Исповедь',
                    kw_list=kw_for(EM, 'RU')) is not None
      and match_exclude('католическая месса',
                        kw_list=kw_for(EM, 'RU')) is not None)
    # ★★★ **콥트는 허용한다**(2026-09-12 사용자 「**콥트교를 복구하라**는
    #   것이었다. **정교회는 일단 기존 상태를 유지**하라」).
    t('★★★ **아랍어 — 콥트 말은 안 잡는다**(가톨릭은 잡는다)',
      match_exclude('القداس الإلهي مع البابا شنودة',
                    kw_list=kw_for(EM, 'AR')) is None
      and match_exclude('الكنيسة كاثوليك',
                        kw_list=kw_for(EM, 'AR')) is not None)
    t('★★ 그래도 **개신교도 쓰는 일반어는 안 잡는다**(RU)',
      match_exclude('Молитва в храме. Служение',
                    kw_list=kw_for(EM, 'RU')) is None)
    t('★ 독일어 — 홑낱말 Messe 로는 안 잡는다(루터교가 쓴다)',
      match_exclude('Die Messe am Sonntag', kw_list=kw_for(EM, 'DE')) is None)
    # ⚠ **홑낱말은 그 언어에서 「가톨릭만 쓰는 말」일 때만 넣는다.**
    #   여기 없는 홑낱말이 들어오면 그 자리에서 잡힌다 — 넣으려면 **왜
    #   안전한지**를 아래 목록에 함께 적는다.
    SAFE_SINGLE = {
        'Purgatory',            # 개신교 교리에 없다
        'Magisterium',          # 가톨릭 교도권 — 개신교에 없는 개념
        'transubstantiation',   # 화체설 — 가톨릭 교리 용어
        'papal',                # 교황의 — 가톨릭을 말할 때만 쓴다
        'Rosenkranz', 'Fegefeuer',   # 묵주·연옥 (DE)
        'chapelet', 'purgatoire',    # (FR)
        'purgatorio', 'purgatório',  # (ES/PT)
        'Marienerscheinung',    # 마리아 발현 — 가톨릭 신심
        'Saint-Siège',          # 교황청 (FR)
        # 타종교·이단 라벨 — 개신교가 자기 것을 이렇게 부르지 않는다(2026-09-09)
        'Quran', "Qur'an", 'Koran', 'Hadith', 'Surah', 'Ramadan', 'Sharia',
        'Mormon', 'Mormonism', 'Mormonen', 'mormón', 'mórmon', 'mormon',
        'Corán', 'Coran', 'Alcorão', 'islámic', 'islâmic', 'islamisch', 'islamique',
        # 가톨릭·정교회 표지(⚠ 표식 층이라 변증·교회사 영상은 검토자가 살린다)
        'homily', 'católic', 'catholique', 'katholisch', 'abbé',
    }
    bad_single = [k for lg in ('EN', 'DE', 'FR', 'ES', 'PT') for k in EM[lg]
                  if ' ' not in k and k not in SAFE_SINGLE]
    t('★★ 라틴문자권 홑낱말은 **가톨릭만 쓰는 말**만', not bad_single,
      bad_single)
    # ── ★★★ 분야 축 (2026-09-10 사용자 지시) ──────────────────────
    OMD = DEFAULT_OFFTOPIC_DOMAIN
    _en = kw_for(OFFTOPIC_KW_LANG, 'EN')
    t('★★★ **분야를 안 주면 옛 판정 그대로**(회귀 0)',
      apply_domain(_en, None) == _en and apply_domain(_en, 'COMMON') == _en)
    t('★ 모르는 분야도 옛 판정 그대로(조용히 덜 거르지 않는다)',
      apply_domain(_en, 'NO_SUCH_DOMAIN', OMD) == _en)
    t('★★★ **찬양 분야에서 `worship song` 이 면제된다**',
      match_offtopic('Best Worship Songs 2026 | Nonstop Playlist',
                     kw_list=_en) is not None
      and match_offtopic('Best Worship Songs 2026 | Nonstop Playlist',
                         kw_list=_en, domain='WORSHIP', dmap=OMD) is None)
    t('★★★ **그래도 예배 실황은 찬양 분야에서도 걸린다**(면제는 19개뿐)',
      match_offtopic('Sunday Service Live 09.07',
                     kw_list=_en, domain='WORSHIP', dmap=OMD) is not None)
    t('★★ 성악(choir)은 찬양 분야에서 **대상**이다',
      match_offtopic('Hymn Choir Medley 1 Hour', kw_list=_en) is not None
      and match_offtopic('Hymn Choir Medley 1 Hour', kw_list=_en,
                         domain='WORSHIP', dmap=OMD) is None)
    t('★★ 한국어도 같다(성가대)',
      match_offtopic('성가대 찬양 모음', kw_list=kw_for(OFFTOPIC_KW_LANG, 'KO'))
      is not None
      and match_offtopic('성가대 찬양 모음',
                         kw_list=kw_for(OFFTOPIC_KW_LANG, 'KO'),
                         domain='WORSHIP', dmap=OMD) is None)
    t('★★★ **앵커는 분야보다 세다**(면제해도 앵커 규칙이 먼저)',
      match_offtopic('Sunday Service 요한복음 3:16', has_anchor=True,
                     kw_list=_en, domain='WORSHIP', dmap=OMD) is None)
    t('★ 면제 목록이 오프토픽에 실제로 있는 말만 담는다(죽은 낱말 0)',
      not [k for k in _WORSHIP_EXEMPT
           if k.lower() not in {x.lower() for v in OFFTOPIC_KW_LANG.values()
                                for x in v}])
    t('★★ **추가(extra)도 돈다** — 분야가 더 거를 수도 있어야 한다',
      match_offtopic('구절 강해 설교', kw_list=[],
                     domain='T', dmap={'T': {'exempt': [], 'extra': ['설교']}})
      == '설교')
    # ⚠⚠ **「무엇인가」를 묻는 층은 분야가 못 바꾼다** — 전능신교는 어느
    #   분야에서 찾아도 전능신교다(사용자 확정 2026-09-10).
    t('★★★ **채널 거르는 말에는 분야 인자가 없다**(공통 층)',
      'domain' not in match_channel.__code__.co_varnames
      and 'domain' not in match_exclude.__code__.co_varnames)

    t('★ 옛 평면 목록도 읽는다(관리자가 손으로 넣은 것을 안 버린다)',
      _as_lang_map(['미사', '연옥'], EM) == {'*': ['미사', '연옥']})
    t('★ 언어를 모르면 전부 본다(옛 동작)',
      len(kw_for(EM, None)) == sum(len(v) for v in EM.values()))
    OM = OFFTOPIC_KW_LANG
    t('★ 관련성 필터도 11언어',
      {'KO', 'EN', 'ZH', 'ZHT', 'JA', 'DE', 'FR', 'ES', 'AR', 'RU', 'PT'}
      <= set(OM))
    # ★★★ §228차 홑낱말 함정 — 앞 경계(2026-09-11)
    t('★★★ **`giving` 이 Thanksgiving 을 안 먹는다**(사용자 신고)',
      _hits('giving', 'sunday giving message')
      and not _hits('giving', 'thanksgiving for kids')
      and not _hits('giving', 'forgiving others'))
    t('★★ **어미 변화는 그대로 잡는다** — 뒤 경계는 안 건다',
      _hits('ofrenda', 'las ofrendas del pueblo')
      and _hits('gottesdienst', 'gottesdienste heute')
      and _hits('livestream', 'livestreaming now'))
    t('★★ **한글·한자에는 경계를 안 건다**(앞에 숫자가 붙는다)',
      _hits('주일예배', '2026주일예배 3부') and _hits('主日崇拜', '本週主日崇拜'))
    t('★ 실제 판정에도 걸린다',
      match_offtopic('Todah - The Sacrifice of Thanksgiving',
                     kw_list=kw_for(OFFTOPIC_KW_LANG, 'EN')) is None)
    t('★ 언어별 예배 실황을 잡는다',
      match_offtopic('Sunday Service Live', kw_list=kw_for(OM, 'EN'))
      and match_offtopic('主日崇拜', kw_list=kw_for(OM, 'ZH'))
      and match_offtopic('Gottesdienst 07.09.', kw_list=kw_for(OM, 'DE')))
    t('★★ 언어별로도 앵커가 이긴다',
      match_offtopic('Sunday Service | Genesis 1:1-5', has_anchor=True,
                     kw_list=kw_for(OM, 'EN')) is None)

    KW = DEFAULT_OFFTOPIC_KW
    t('★ 관련성 필터가 예배 실황을 잡는다',
      match_offtopic('2026년 8월 3일 주일예배', kw_list=KW) is not None)
    t('★★ **앵커가 있으면 필터가 진다**',
      match_offtopic('주일예배 | 창세기 1:1-5', has_anchor=True,
                     kw_list=KW) is None)
    t('  앵커가 없으면 잡는다',
      match_offtopic('주일예배 실황', has_anchor=False, kw_list=KW) is not None)
    t('★ 낭독은 안 잡는다(책 전체로 걸 것)',
      match_offtopic('마태복음 전체낭독', kw_list=KW) is None)
    t('  빈 글은 안 잡는다', match_offtopic('', kw_list=KW) is None)
    # ⚠⚠⚠ **짧은 낱말은 한국어에서도 위험하다** (2026-09-06 실측) —
    #   하남시 **미사동**이 개신교회 이름에 들어간다(미사온누리교회 93건 ·
    #   미사강변 우리들교회 32건). 「미사」 단독으로 거르면 127건 중
    #   **125건(98%)이 오탐**이었다. 되돌아가지 못하게 잠근다.
    t('★★★ 「미사」를 단독으로 안 쓴다(하남 미사동 = 개신교회 이름)',
      '미사' not in EXCLUDE_KW_LANG['KO'])
    _ko = {'KO': EXCLUDE_KW_LANG['KO']}
    _m = lambda s: match_exclude(s, kw_list=_ko, lang='KO')
    #   ★ 뒤에 한글이 붙으면 지명·교회 이름이다 — 안 거른다
    for _t in ('주일 2부 예배 (미사강변 우리들교회)', '#QT #미사온누리교회',
               '하남 미사동 성경공부', '미사동교회 주일예배'):
        t('★★ 안 걸린다 — %s' % _t[:18], _m(_t) is None, _m(_t))
    #   ★ 공백·부호·끝에서는 걸린다
    for _t in ('[매일미사 강론] 연중 제34주간', '& 미사(주님 승천 대축일)',
               '주일 미사'):
        t('★★ 걸린다 — %s' % _t[:18], _m(_t) == '미사$', _m(_t))
    t('  낱말 끝 표시가 이름에 안 새어 나온다', WORD_END == '$')
    # ★★★ **정교회는 거르고 콥트는 허용한다**(2026-09-12 사용자 정정)
    t('★★★ 정교회 용어가 제외후보에 있다(RU)',
      'православн' in EXCLUDE_KW_LANG['RU']
      and 'литургия' in EXCLUDE_KW_LANG['RU'])
    t('★★★ **콥트 용어는 제외후보에 없다**(AR)',
      'قبطي' not in EXCLUDE_KW_LANG['AR']
      and 'قداس' not in EXCLUDE_KW_LANG['AR'])
    # ★★★ 교회 살림 공지(2026-09-12) — **오탐 0 을 확인하고 담은 것**
    t('★★★ 교회 살림 공지가 걸린다(모집·졸업식·임직식)',
      all(match_exclude(x, kw_list=kw_for(EM, 'KO')) for x in
          ('라마드아카데미 제3기 월요반을 모집합니다', '2025 졸업식 영상',
           '권사회 헌신예배 및 임직식')))
    t('★★★ **「김장」을 안 넣는다** — 「김장환목사」를 먹는다(§228차 함정)',
      not any('김장' == str(x) for x in EXCLUDE_KW_LANG['KO']))
    t('★★ **설교 제목의 수사는 안 걸린다**(「시내산 위치 논란」)',
      not match_exclude('출애굽기 19-23장 시내산 위치 논란',
                        kw_list=kw_for(EM, 'KO')))
    t('★★ **정당한 강좌 영상은 안 걸린다**(Piano tutorial)',
      not match_exclude('恩典之路 - 钢琴伴奏 The Path of Grace - Piano tutorial',
                        kw_list=kw_for(EM, 'EN')))
    t('★★★ **가톨릭은 그대로 거른다**',
      'католическ' in EXCLUDE_KW_LANG['RU']
      and 'كاثوليك' in EXCLUDE_KW_LANG['AR']
      and any('Catholic' in x for x in EXCLUDE_KW_LANG['EN']))
    # ★★★ **콥트가 이긴다** — 콥트 정교회는 이름에 「Orthodox」가 들어간다
    t('★★★ **「Coptic Orthodox」 는 안 걸린다**(콥트가 정교회 낱말을 이긴다)',
      is_coptic('St. Mary & St. Joseph Coptic Orthodox Church')
      and _ortho_only('Orthodox Church'))
    t('  ⚠ 콥트가 **정교회 낱말에만** 이긴다(가톨릭·몰몬은 그대로)',
      not _ortho_only('Catholic Bible') and not _ortho_only('Book of Mormon'))
    t('★★ 홑낱말 orthodox 는 안 넣는다(개신교도 「정통」으로 쓴다)',
      'orthodox' not in [x.lower() for x in EXCLUDE_KW_LANG['EN']])
    t('  개신교도 쓰는 일반어는 안 넣는다(храм·молитва)',
      not ({'храм', 'молитва', 'служение'}
           & {x.lower() for x in EXCLUDE_KW_LANG['RU']}))
    t('두 필터의 낱말이 겹치지 않는다',
      not (set(x.lower() for x in DEFAULT_EXCLUDE_KW)
           & set(x.lower() for x in DEFAULT_OFFTOPIC_KW)))

    # ── 다른 종교 = 채널 층(2026-09-09 사용자 「무조건 제외」) ──────────────
    t('★ 가톨릭·정교회 자칭이 채널 층에 있다',
      all(match_channel(x, lang='KO') for x in
          ('가톨릭TV', '천주교 서울대교구', 'cpbcTV가톨릭콘텐츠의모든것', '천주섭리수녀회')))
    # ★★★ **콥트 채널은 안 걸리고 정교회 채널은 걸린다**(2026-09-12 사용자
    #   「콥트교를 복구하라는 것이었다. 정교회는 일단 기존 상태를 유지하라」).
    t('★★★ **콥트 채널은 안 걸린다**(허용)',
      not any(match_channel(x, lang=lg) for x, lg in
              (('Coptic Mix', 'AR'), ('MRTv Coptic Channel', 'EN'),
               ('St. Mary & St. Joseph Coptic Orthodox Church', 'EN'))))
    t('★★★ **정교회 채널은 그대로 걸린다**',
      all(match_channel(x, lang=lg) for x, lg in
          (('Канал "Православный"', 'RU'), ('한국정교회', 'KO'))))
    t('★★ 홑낱말 함정은 그대로 막는다(송정교회는 통과)',
      not match_channel('송정교회', lang='KO'))
    t('★ 가톨릭 채널은 그대로 걸린다',
      all(match_channel(x, lang=lg) for x, lg in
          (('cpbcTV가톨릭콘텐츠의모든것', 'KO'), ('Catholic Bible', 'EN'))))
    t('★ 불교·타종교 자칭도 걸린다',
      all(match_channel(x, lang='KO') for x in ('법륜스님의 희망세상만들기', '조계종 불교방송')))

    # ── ★★★ **유대교** (2026-09-12 사용자 「유대교 거르는 말 진행하라」) ────
    #   실측 42,344편 전수 · 걸린 것 5편 · **오탐 0**.
    t('★★★ **유대교 단체 다섯 곳이 걸린다**(실측 전수)',
      all(match_channel(x, lang=lg) for x, lg in
          (('Jews for Judaism', 'EN'), ('Lapid Judaism', 'EN'),
           ('Jewels of Judaism', 'EN'), ('Judaismo Abierto', 'ES'),
           ('Jewish Learning Institute', 'EN'))))
    t('★★★ **메시아닉이 이긴다** — 유대교 낱말이 안 듣는다',
      not match_channel('Messianic Judaism Today', lang='EN')
      and not match_channel('Yeshua Chabad House', lang='EN'))
    t('★★★ **설명문의 언급은 자칭이 아니다**(Jews for Judaism 이 반박으로 적었다)',
      bool(match_channel(
          'Jews for Judaism%sGENESIS 3:15%sReply2 One for Israel Maoz '
          'Messianic Jews for Jesus & ASKDrBrown' % (chr(10), chr(10)),
          lang='EN')))
    t('  ⚠ 부르는 곳이 **첫 줄에 채널 이름**을 둔다(규약)',
      is_messianic('Messianic Life%s어떤 제목' % chr(10))
      and not is_messianic('어떤 채널%sMessianic 을 반박한다' % chr(10)))
    t('  ⚠ 메시아닉이 **유대교 낱말에만** 이긴다(가톨릭·이슬람은 그대로)',
      bool(match_channel('Messianic Catholic Church', lang='EN')))
    # ⚠⚠⚠ **홑낱말은 기독교 자료를 먹는다 — 전수 실측으로 잡은 것들**
    for _nm, _lg in (('Carmen Joy Imes', 'EN'),         # 기독교 구약학자
                     ('BibleProject', 'EN'),
                     ('바이블프로젝트 BibleProject - Korean', 'KO'),
                     ('Torah Life Ministries', 'EN'),   # 히브리 뿌리 기독교
                     ('American Torah', 'EN'),
                     ('Discovering the Jewish Jesus with Rabbi Schneider', 'EN'),
                     ('夏達華研道中心 HaDavar Yeshiva', 'ZHT'),
                     ('MyHolyReads', 'EN'),
                     ('영광장로교회', 'KO')):
        t('  ⚠ 「%s」 는 통과한다(홑낱말 함정)' % _nm[:26],
          not match_channel(_nm, lang=_lg), _nm)
    t('★★ 홑낱말 torah·rabbi·talmud 를 안 넣는다',
      not ({'torah', 'rabbi', 'rabbinic', 'talmud', 'synagogue', 'yeshiva',
            'jewish', 'judaism', '유대인', '랍비', '토라', '탈무드'}
           & {x.lower() for v in CHANNEL_KW_LANG.values() for x in v}))
    t('★ 유대교 비교 설교는 채널 층을 통과한다(콘텐츠 층이 본다)',
      not match_channel('유대교와 기독교의 공통점 | 영광장로교회', lang='KO'))
    # ★★★ **자칭은 채널 이름에, 언급은 설명문에** — 설명문까지 재서 잡은 둘
    #   (담는 문도 정리 도구도 `yt_desc[:600]` 을 함께 본다).
    t('★★★ **학교 이름이 채널 층에 없다**(기독교 목사의 학력이다)',
      not match_channel(
          'Biblical Languages & Literature\nSermon: Daniel 1:17-21\n'
          'Dr. Christopher Dost (Ph.D., The Jewish Theological Seminary) is '
          'the pastor of Northville Baptist Church', lang='EN'))
    t('★★★ **학술 교파어가 채널 층에 없다**(기독교 강의가 대조로 쓴다)',
      not match_channel(
          'Pastor Randy Powell\n"Jesus, My Rabbi" Torah Club lesson 27\n'
          'a comparison with Rabbinic Judaism', lang='EN'))
    t('  ⚠ 그래도 **콘텐츠 층은 표식을 붙인다**(사람이 본다)',
      bool(match_exclude('Ph.D., The Jewish Theological Seminary', lang='EN'))
      and bool(match_exclude('a comparison with Rabbinic Judaism', lang='EN')))
    t('  ★ 옮긴 낱말은 채널 층에서 걷혔다',
      not ({w.lower() for v in _JEW_CONTENT.values() for w in v}
           & {x.lower() for v in CHANNEL_KW_LANG.values() for x in v}))
    t('  ⚠ 세속 비교종교는 콘텐츠 층이 표식을 붙인다',
      bool(match_exclude('ユダ王国の滅亡　ユダヤ教とユダヤ人の誕生', lang='JA')))
    # ⚠⚠ **홑낱말은 정통 채널을 먹는다 — 전수 실측으로 잡은 것들**
    for _nm, _lg in (('송정교회', 'KO'), ('예정교회_교육위원회', 'KO'),
                     ('자유교회', 'KO'), ('세종온유교회', 'KO'), ('등불교회', 'KO'),
                     ('예수님의신부TV', 'KO'), ('수원성교회 청년교구', 'KO'),
                     ('함라이언 신부의 말씀사탕', 'KO'),
                     ('Truth Church 真道教會', 'ZHT'), ('大道教會', 'ZH'),
                     ("Tyrannus' Orthodox Theological Seminary", 'EN')):
        t('  ★ 정통 채널 「%s」 는 안 걸린다' % _nm,
          not match_channel(_nm, lang=_lg), match_channel(_nm, lang=_lg))
    t('★ 홑낱말을 채널 층에 안 넣었다',
      not ({'정교회', '유교', '불교', '신부', '교구', '道教', 'orthodox', 'católic',
            '天主教', 'catholic'}
           & {x.lower() for v in CHANNEL_KW_LANG.values() for x in v}))
    # ── 예배 실황 낱말 = 보관함 갈래(2026-09-16) ──
    t('★★ 예배 실황 낱말이 제목에서 걸린다(KO·EN)',
      match_live_service('2026.5.3 주일예배 설교', 'KO') == '주일예배'
      and match_live_service('Sunday Service Live Stream', 'EN') == 'sunday service')
    t('  실황이 아닌 것은 안 걸린다(Thanksgiving · 성가대 · 언어 모르면 전부 본다)',
      match_live_service('Thanksgiving message', 'EN') is None
      and match_live_service('성가대 찬양', 'KO') is None
      and match_live_service('主日崇拜 講道', None) == '主日崇拜')
    t('★ 실황 목록은 오프토픽 목록과 다른 표다(성가대·testimony·giving 이 없다)',
      not ({'성가대', '합창단', 'testimony', 'giving', 'choir'}
           & {x for v in LIVE_SERVICE_KW.values() for x in v}))
    print('media_exclude selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


def seed_default(db_path=DB):
    """sys_config 에 기본 키워드가 없으면 1회 시드(멱등)."""
    conn = appdb.connect(db_path)
    try:
        ex = conn.execute("SELECT 1 FROM sys_config WHERE config_key=?", (CFG_KEY,)).fetchone()
        if not ex:
            conn.execute("INSERT INTO sys_config (config_key, config_val) VALUES (?,?)",
                         (CFG_KEY, json.dumps(DEFAULT_EXCLUDE_KW, ensure_ascii=False)))
            conn.commit()
            return True
    finally:
        conn.close()
    return False


if __name__ == '__main__':
    import sys, io
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', write_through=True)
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    if '--seed' in sys.argv:
        print('관련성 키워드 시드:', '신규' if seed_offtopic() else '이미 존재')
    seeded = seed_default()
    print('시드:', '신규 삽입' if seeded else '이미 존재')
    print('현재 키워드:', get_exclude_kw())
    for t in ['창세기 1장 강해 설교', '가톨릭 미사 전례 해설', '개신교가 보는 연옥 교리 반박']:
        print(f'  "{t}" → 매칭: {match_exclude(t)}')
