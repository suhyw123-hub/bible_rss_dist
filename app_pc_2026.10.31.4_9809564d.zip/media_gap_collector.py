"""
media_gap_collector.py
----------------------
§19-11 ⑤단계 — 커버리지 빈틈 타겟만 API 검색 + 결과를 풀에 넣고 엔티티·페리코프 양쪽 교차 연결.

unit 절약 원리(§ 사용자 합의):
  · 빈틈(active<임계) 타겟만 검색 — 풀로 메워진 건 검색 안 함.
  · 한 검색 결과를 공유 풀(sys_media_asset)에 dedup 저장 → **엔티티 autolink + 페리코프 ref-link 동시**.
    → 엔티티 검색 결과가 페리코프도 채우고(역도 성립), 같은 영상 재발견은 0 추가(멱등).
  · 페리코프는 **책 단위 broad 검색** → 제목의 "N장" 파싱 → 그 장의 BODY 페리코프 다수에 한 번에 연결.

검색·삽입·분류·Shorts·NFC·키순환은 db_media_crawler 재사용. 엔티티 연결은 media_entity_link 재사용.
search_fn 주입 가능(테스트용 모킹).
"""

import json
import re
from datetime import datetime

import appdb
import media_coverage as MC

try:
    import media_entity_link as _mel
except ImportError:
    from admin import media_entity_link as _mel
import media_exclude
import media_link
import db_media_crawler as DMC


# ── 풀 삽입 — **공통 품질관리 문을 지난다** ────────────────────────────
def _upsert_pool(gate, r, dry_run=False, also=None):
    """url 기준 dedup. → (media_id, is_new, 사유).

    ⚠⚠ **그전에는 여기서 직접 INSERT 하며 분류를 아예 안 했다** —
      `r.get('media_type', 'SERMON')` 이라 **저밀도로 수집한 것은 전부
      SERMON** 이 됐다(2026-09-08 실측으로 잡았다).
    ⇒ 사용자 지시 「**어떤 방법으로 수집했던지 공통적으로 거쳐야 할 품질관리는
      반드시 거치도록**」에 따라 `media_intake.admit` 한 문으로 옮겼다.
      그 문이 문지기·분류·저장·연결을 같은 차례로 한다.
    """
    import media_intake
    out = media_intake.admit(gate, r, link=True, also_entity=also,
                             dry_run=dry_run)
    act = out['action']
    lk = out.get('links') or (0, 0)
    if act == media_intake.ACT_NEW:
        return out['media_id'], True, '', lk
    if act == media_intake.ACT_EXIST:
        return out['media_id'], False, '', lk
    if act == media_intake.ACT_DRY:
        return -1, True, '', (0, 0)
    return 0, False, act, (0, 0)   # 건너뜀 — **왜인지 돌려준다**(§0-1)


def _link(conn, media_id, scope, key, dry_run=False):
    """영상 연결 멱등 삽입(통합 표). → 1 if 신규 else 0.

    ⚠ `target_id` 는 숫자다 — 옛 `str(key)` 를 그대로 넘기면 안 걸린다.
    """
    if media_id <= 0 or dry_run:
        return 0
    ty = media_link.lt(scope)
    tgt = media_link.key_int(key)
    if not ty or tgt is None:
        return 0
    ex = conn.execute(
        "SELECT 1 FROM %s WHERE link_type=? AND clicked_id=? AND target_id=?"
        % media_link.TBL, (ty, media_id, tgt)).fetchone()
    if ex:
        return 0
    conn.execute(
        "INSERT INTO %s (link_type, clicked_id, target_id, record_status) "
        "VALUES (?,?,?,'LIVE')" % media_link.TBL, (ty, media_id, tgt))
    return 1


# ── 페리코프: 책별 (chapter → BODY pericope_id 목록) 사전 ─────────────────
def _book_chapter_pericopes(conn, bcode):
    out = {}
    for pid, ch in conn.execute(
            "SELECT p.pericope_id, bs.chapter FROM sys_pericope_asset p "
            "LEFT JOIN bible_index bs ON bs.verse_id=p.start_vid "
            "WHERE p.record_status='LIVE' AND p.peri_type='BODY' AND bs.bcode=?", (bcode,)):
        if ch is not None:
            out.setdefault(ch, []).append(pid)
    return out


def global_book_terms(conn, lang):
    """[(정규식, bcode)] — 모든 책의 '책이름 + N장/N:' 패턴. 풀/약칭, 현지+EN. 긴 이름 우선.
    어떤 검색 결과든 제목에서 '책+장'을 잡아 그 장의 페리코프에 연결(교차연결=단위절약)."""
    pairs = []
    for L in {(lang or 'KO').upper(), 'EN'}:
        for col in ('full_name', 'short_name'):
            for bc, nm in conn.execute(
                    f"SELECT book_code, {col} FROM book_names WHERE UPPER(lang_code)=?", (L,)):
                if nm and nm.strip():
                    pairs.append((nm.strip(), bc))
    seen, out = set(), []
    for nm, bc in sorted(pairs, key=lambda x: -len(x[0])):   # 풀네임 먼저
        if (nm, bc) in seen:
            continue
        seen.add((nm, bc))
        # '책이름 [구분기호] 숫자 (장|:)'  — 인접해야 매칭(우발적 책 언급 배제)
        out.append((re.compile(re.escape(nm) + r'\s*[\-\s]?\s*(\d{1,3})\s*(?:장|:)'), bc))
    return out


def _link_result_pericopes(conn, mid, title, book_terms, ch_cache, dry_run):
    """제목의 모든 '책+장' 매칭 → 그 장의 BODY 페리코프에 연결. → 신규 링크 수."""
    n = 0
    t = title or ''
    for rx, bc in book_terms:
        for m in rx.finditer(t):
            ch = int(m.group(1))
            if bc not in ch_cache:
                ch_cache[bc] = _book_chapter_pericopes(conn, bc)
            for pid in ch_cache[bc].get(ch, []):
                n += _link(conn, mid, 'PERICOPE', pid, dry_run)
    return n


def interleave(*lists):
    """여러 잡 리스트를 라운드로빈으로 섞음(예산이 한쪽에 몰리지 않게)."""
    out, i = [], 0
    while True:
        added = False
        for L in lists:
            if i < len(L):
                out.append(L[i]); added = True
        if not added:
            break
        i += 1
    return out


# ── 계획 수립 ────────────────────────────────────────────────────────────
def _clean_query(name):
    """검색어 정제 — 괄호 주석 제거 + **여러 이름 중 첫 이름만**.

    ★ 우리 이름 규약은 「대표어 · 음역」이다(§12-0) — 「사망 · 마베트 ·
      타나토스」를 그대로 유튜브에 넣으면 **0건**이다. 실측 이 꼴이 검색
      대상 130개 중 **23개**(그 밖에 DOCTRINE 「세례·침례」 2 · PERSON
      「사탄 · 마귀」 1 · NATION 1).
    ⚠ **괄호를 먼저 걷고 나서 가른다** — 「페니키아 (두로·시돈)」은 괄호 안에
      가운뎃점이 있어 순서를 바꾸면 「페니키아」가 아니라 통째로 잘린다.
    """
    s = re.sub(r'\s*[\(（].*?[\)）]\s*', ' ', name or '').strip()
    if '·' in s:
        s = s.split('·')[0].strip() or s
    return s or (name or '')


def build_entity_jobs(conn, threshold=1, limit=50, lang='KO'):
    """엔티티 빈틈 → 검색 잡. query=정제된 엔티티 이름. → [{kind,query,lang,eid,name}]."""
    # ⚠ **의미장(FIELD)은 검색 대상이 아니다** — 「사랑의 낱말 가족」은 우리가
    #   지은 묶음 이름이라 세상에 그 이름의 영상이 없다(실측 7개).
    #   기계 낱말(LEX)은 `MC.entity_rows` 가 이미 뺀다.
    skip = _skip_ids(conn, ('FIELD',))
    # ★★ **검색 언어 = 그 언어의 빈틈**(2026-09-06) — 「KO 로 검색한다」는
    #   「한국어 영상이 없는 자리를 메운다」는 뜻이다. 그전에는 언어를 안 봐서
    #   **영어 영상만 있는 용어를 「커버됨」으로 세고 한국어를 영영 안 모았다**
    #   (실측 543 중 KO 365 · EN 298 · 한 언어에만 149).
    gaps = [g for g in MC.gaps(
                MC.entity_rows(conn, lang, media_lang=lang), threshold)
            if g['id'] not in skip][:limit]
    return [{'kind': 'ENTITY', 'query': _clean_query(g['name']), 'lang': lang,
             'eid': g['id'], 'name': g['name']} for g in gaps if g['name']]


def _skip_ids(conn, subtypes):
    """검색하지 않을 엔티티 번호 — `json_detail.subtype` 으로 가린다."""
    if not subtypes:
        return set()
    qs = ','.join('?' * len(subtypes))
    return {r[0] for r in conn.execute(
        "SELECT entity_id FROM sys_entity_master"
        " WHERE COALESCE(json_extract(json_detail,'$.subtype'),'') IN (%s)"
        % qs, tuple(subtypes))}


_SERMON_KW = {'KO': '설교', 'EN': 'sermon', 'ZH': '讲道', 'JA': '説教',
              'ES': 'sermón', 'PT': 'sermão', 'FR': 'sermon', 'DE': 'Predigt', 'RU': 'проповедь'}


def build_pericope_book_jobs(conn, threshold=1, lang='KO', max_books=66):
    """페리코프 빈틈을 책 단위로 묶어 broad 검색 잡. query='<책이름> 설교'. → [{kind,query,lang,bcode,book_terms,gap_n}]."""
    # ★★ 여기도 **그 언어의 빈틈**을 본다(위와 같은 이유).
    rows = MC.pericope_rows(conn, lang, peri_type='BODY', media_lang=lang)
    bshort = MC.book_short_map(conn, lang)
    bshort_en = MC.book_short_map(conn, 'EN')
    L = (lang or 'KO').upper()
    bfull = {bc: fn for bc, fn in conn.execute(
        "SELECT book_code, full_name FROM book_names WHERE UPPER(lang_code)=?", (L,))}
    bfull_en = {bc: fn for bc, fn in conn.execute(
        "SELECT book_code, full_name FROM book_names WHERE UPPER(lang_code)='EN'")}
    gap_by_book = {}
    for r in rows:
        if r['active'] < threshold and r['bcode']:
            gap_by_book[r['bcode']] = gap_by_book.get(r['bcode'], 0) + 1
    kw = _SERMON_KW.get(L, 'sermon')
    jobs = []
    for bc, n in sorted(gap_by_book.items(), key=lambda x: -x[1])[:max_books]:
        name = bfull.get(bc) or bfull_en.get(bc) or bshort.get(bc) or str(bc)  # 검색=풀네임
        # 장-파싱 매칭용 책 용어(풀/약칭, 현지+EN)
        terms = [t for t in {bfull.get(bc), bshort.get(bc), bfull_en.get(bc), bshort_en.get(bc)} if t]
        jobs.append({'kind': 'PERICOPE_BOOK', 'query': f'{name} {kw}', 'lang': lang,
                     'bcode': bc, 'book_terms': terms, 'gap_n': n})
    return jobs


# ── 실행 ────────────────────────────────────────────────────────────────
def run_collection(conn, jobs, max_searches=10, per_query=5, log=print,
                   dry_run=False, search_fn=None, classify_sets=None, exclude_kw=None):
    """잡 목록을 max_searches 한도 내 실행. 각 결과를 풀 dedup 저장 + 엔티티 autolink + (책잡은)페리코프 장-연결.
    → stats dict. search_fn(query,lang,max,sets)->[r] 주입 가능(없으면 db_media_crawler.youtube_search)."""
    if search_fn is None:
        search_fn = DMC.youtube_search
    if classify_sets is None:
        try:
            classify_sets = __import__('media_taxonomy').load_classify_sets(conn)
        except Exception:
            classify_sets = {}
    if exclude_kw is None:
        exclude_kw = media_exclude.get_exclude_map()
    # ★★★ **공통 품질관리 문** — 재료를 한 번만 읽어 돌려 쓴다.
    #   ⚠ 언어별 컨텍스트도 `Gate` 가 들고 있다(여기서 또 만들지 않는다).
    import media_intake
    gate = media_intake.Gate(conn)
    st = {'searches': 0, 'new_videos': 0, 'ent_links': 0, 'peri_links': 0,
          'targets': 0, 'skipped': 0}
    for job in jobs:
        if st['searches'] >= max_searches:
            log(f"  [한도 도달] {max_searches}회 검색 — 중단")
            break
        st['searches'] += 1; st['targets'] += 1
        log(f"[{st['searches']}/{max_searches}] {job['kind']} 검색: \"{job['query']}\" ({job['lang']}, +100u)")
        try:
            results = search_fn(job['query'], job['lang'], per_query, classify_sets) or []
        except Exception as e:
            log(f"  검색 오류: {str(e)[:80]}"); continue
        also = job.get('eid') if job['kind'] == 'ENTITY' else None
        for r in results:
            # ★★★ **공통 품질관리 문** — 문지기·분류·저장·연결을 한 번에 한다.
            #   ⚠ 연결도 그 문이 하므로 여기서 `TL.link_media` 를 또 부르지
            #     않는다(두 번 부르면 같은 일을 두 번 하고 규칙이 갈린다).
            mid, is_new, skip, nlk = _upsert_pool(gate, r, dry_run,
                                                  also=also)
            if skip:
                st['skipped'] += 1
                continue
            if is_new:
                st['new_videos'] += 1
            st['peri_links'] += nlk[0]
            st['ent_links'] += nlk[1]
        if not dry_run:
            conn.commit()
        # ⚠ **건너뛴 것을 조용히 넘기지 않는다**(§0-1)
        _sk = ("  건너뜀 %d" % st["skipped"]) if st.get("skipped") else ""
        log("  → 신규영상 %d · 용어링크 %d · 구절링크 %d%s"
            % (st["new_videos"], st["ent_links"], st["peri_links"], _sk))
    return st


def relink_pool_pericopes(conn, lang='KO', media_ids=None, log=print, dry_run=False):
    """이미 풀에 있는 영상 제목을 전역 '책+장' 매칭으로 페리코프 재연결(쿼터 0, 멱등).
    media_ids=None 이면 전체 풀. → 신규 페리코프 링크 수."""
    book_terms = global_book_terms(conn, lang)
    ch_cache = {}
    if media_ids is None:
        rows = conn.execute("SELECT media_id, title FROM sys_media_asset "
                            "WHERE COALESCE(record_status,'LIVE')='LIVE'").fetchall()
    else:
        rows = [(m, conn.execute("SELECT title FROM sys_media_asset WHERE media_id=?", (m,)).fetchone()[0])
                for m in media_ids]
    n = 0
    for i, (mid, title) in enumerate(rows):
        n += _link_result_pericopes(conn, mid, title, book_terms, ch_cache, dry_run)
        if (i + 1) % 500 == 0:
            if not dry_run:
                conn.commit()
            log(f"  {i+1}/{len(rows)} 처리 (페리코프 링크 누적 {n})")
    if not dry_run:
        conn.commit()
    return n
