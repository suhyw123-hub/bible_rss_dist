# -*- coding: utf-8 -*-
"""db_pref_preset.py — **환경설정 양식**(A 타입 · B 타입 …) (2026-09-29 293차 신설 · 영구).

★★★ 왜 (사용자 · `docs/1.txt` 22-1(3) 「관리자가 미리 세팅한 사용자 환경설정 양식을
  몇가지 나누어서 배포 … 다운로드 화면에 A 타입, B 타입 등으로 구분해서 미리보기
  화면이나 캔버스 등의 설정값을 입력한 환경설정을 제공하면 어떨까? 코어팩에 추가해도
  좋을 것 같다」).
  · 양식 = **이 PC 의 설정 한 벌을 이름 붙여 담은 것**. 담는 열쇠는 배포 기본값과
    **같은 허용 목록**(`db_dist_build.SEED_CFG` · `SEED_STATE`) — 테마·글꼴·역본·설명
    모드·탭 짜임·캔버스 배치·표시 언어·렌즈 보기. 기기 번호·읽은 기록·초안은 안 담는다.
  · 집 = `sys_pref_preset`(**CORE**) — 코어팩에 실려 나가므로 팩을 따로 만들지 않는다.
  · 사용자 = 설정 ▸ 다운로드 ▸ **환경설정 양식** 줄을 고르고 [이 양식 적용].
    ⚠ `app_state.json` 몫(캔버스 배치)은 **다음에 켤 때** 보인다 — 화면이 그 말을 한다.
  · 관리자 = 배포 센터 ▸ 배포 관리 ▸ 코어팩 ▸ 아래 「환경설정 양식」 칸에서
    [지금 이 PC 설정으로 담기].

    python db_pref_preset.py --selftest   (의무)
    python db_pref_preset.py --list
    python db_pref_preset.py --capture CODE "이름" ["설명"]
"""
import io
import json
import os
import sys
import time

import appdb

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bible_master.db')
TABLE = 'sys_pref_preset'
DDL = ("CREATE TABLE IF NOT EXISTS %s("
       " code TEXT PRIMARY KEY, name TEXT NOT NULL, descr TEXT,"
       " cfg_json TEXT NOT NULL, state_json TEXT,"
       " sort_order INTEGER DEFAULT 100, made_at TEXT,"
       " record_status TEXT DEFAULT 'LIVE')" % TABLE)


def ensure(conn):
    conn.execute(DDL)
    conn.commit()


def _keys():
    """담는 열쇠 — 배포 기본값과 **같은 허용 목록**(두 벌이면 갈린다)."""
    import db_dist_build as DD
    return tuple(DD.SEED_CFG), tuple(DD.SEED_STATE)


def snapshot(user_conn, state_path=None):
    """지금 이 PC 의 설정 → (cfg dict, state dict). 허용 목록에 든 것만.

    ★ 317차 — 양식 담기(`capture`)와 **모바일로 보내는 설정**(`mobile_sync`)이
      이 한 문을 쓴다. 허용 목록이 둘이 되면 개인 자료가 새는 쪽이 생긴다(§C-2).
    """
    cfg_keys, st_keys = _keys()
    cfg = {}
    for k, v in user_conn.execute('SELECT config_key, config_val FROM user_config'):
        if k in cfg_keys and v is not None:
            cfg[k] = v
    sp = state_path or os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    'app_state.json')
    try:
        d = json.load(io.open(sp, encoding='utf-8'))
        st = {k: d[k] for k in st_keys if k in d}
    except Exception:
        st = {}
    return cfg, st


def capture(conn, code, name, descr='', user_conn=None, state_path=None):
    """지금 이 PC 의 설정을 양식으로 담는다(같은 코드면 덮어쓴다) → dict.

    ⚠ `user_conn` 이 없으면 본체 옆 `user_data.db` 를 읽는다(appdb 가 붙인 userdb).
    """
    ensure(conn)
    code = (code or '').strip().upper()
    if not code or not (name or '').strip():
        raise ValueError('양식 코드와 이름이 있어야 한다')
    uc = user_conn if user_conn is not None else conn
    cfg, st = snapshot(uc, state_path)
    conn.execute(
        "INSERT INTO %s(code, name, descr, cfg_json, state_json, made_at,"
        " record_status) VALUES(?,?,?,?,?,?,'LIVE')"
        " ON CONFLICT(code) DO UPDATE SET name=excluded.name,"
        " descr=excluded.descr, cfg_json=excluded.cfg_json,"
        " state_json=excluded.state_json, made_at=excluded.made_at,"
        " record_status='LIVE'" % TABLE,
        (code, name.strip(), descr or '', json.dumps(cfg, ensure_ascii=False),
         json.dumps(st, ensure_ascii=False), time.strftime('%Y-%m-%d %H:%M')))
    conn.commit()
    return {'code': code, 'cfg': len(cfg), 'state': len(st)}


def remove(conn, code):
    """양식을 걷는다(`HIDE`) — 지우지 않는다(되돌릴 자리)."""
    ensure(conn)
    conn.execute("UPDATE %s SET record_status='HIDE' WHERE code=?" % TABLE,
                 ((code or '').upper(),))
    conn.commit()


def list_presets(conn, live_only=True):
    """→ `[{'code','name','descr','n_cfg','n_state','made_at'}]`."""
    try:
        ensure(conn)
    except Exception:
        return []
    out = []
    for code, name, descr, cj, sj, made in conn.execute(
            "SELECT code, name, COALESCE(descr,''), cfg_json, COALESCE(state_json,'{}'),"
            " COALESCE(made_at,'') FROM %s"
            " WHERE (? OR COALESCE(record_status,'LIVE')='LIVE')"
            " ORDER BY sort_order, code" % TABLE, (0 if live_only else 1,)):
        try:
            n1 = len(json.loads(cj or '{}'))
            n2 = len(json.loads(sj or '{}'))
        except Exception:
            n1 = n2 = 0
        out.append({'code': code, 'name': name, 'descr': descr,
                    'n_cfg': n1, 'n_state': n2, 'made_at': made})
    return out


def apply(conn, code, user_conn=None, state_path=None):
    """양식을 이 PC 에 적용 → `{'cfg', 'state', 'name'}`.

    ⚠ **허용 목록 밖 열쇠는 적용하지 않는다** — 양식 파일이 손으로 고쳐졌어도
      기기 번호·초안 같은 것이 덮이지 않게(§C-2).
    ⚠ `app_state.json` 몫은 파일에 적는다 — **다음에 켤 때** 반영된다.
    """
    ensure(conn)
    r = conn.execute("SELECT name, cfg_json, COALESCE(state_json,'{}') FROM %s"
                     " WHERE code=? AND COALESCE(record_status,'LIVE')='LIVE'"
                     % TABLE, ((code or '').upper(),)).fetchone()
    if not r:
        raise KeyError('그 양식이 없다: %s' % code)
    cfg_keys, st_keys = _keys()
    cfg = json.loads(r[1] or '{}')
    st = json.loads(r[2] or '{}')
    uc = user_conn if user_conn is not None else conn
    n = 0
    for k, v in cfg.items():
        if k not in cfg_keys:
            continue
        if uc.execute('SELECT 1 FROM user_config WHERE config_key=?', (k,)).fetchone():
            uc.execute('UPDATE user_config SET config_val=? WHERE config_key=?', (v, k))
        else:
            uc.execute('INSERT INTO user_config(config_key, config_val) VALUES(?,?)', (k, v))
        n += 1
    uc.commit()
    try:
        import theme_font
        theme_font.forget()          # 글꼴 설정(THEME)을 갈았을 수 있다 — 기억한 옛 값을 버린다
    except Exception:
        pass
    m = 0
    sp = state_path or os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    'app_state.json')
    try:
        d = json.load(io.open(sp, encoding='utf-8')) if os.path.exists(sp) else {}
    except Exception:
        d = {}
    for k, v in st.items():
        if k in st_keys:
            d[k] = v
            m += 1
    if m:
        io.open(sp, 'w', encoding='utf-8').write(json.dumps(d, ensure_ascii=False, indent=1))
    return {'cfg': n, 'state': m, 'name': r[0]}


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def selftest():
    import sqlite3
    import tempfile
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    d = tempfile.mkdtemp()
    sp = os.path.join(d, 'app_state.json')
    io.open(sp, 'w', encoding='utf-8').write(json.dumps(
        {'cfg_node_mode': 'A', 'cfg_h_gap': 12, 'win_w': 1500, 'last_verse_id': 7}))
    sysdb = sqlite3.connect(':memory:')
    usr = sqlite3.connect(':memory:')
    usr.executescript("""
      CREATE TABLE user_config(config_key TEXT PRIMARY KEY, config_val TEXT);
      INSERT INTO user_config VALUES('UI_THEME','BLACK_L'),('font_size','11'),
        ('SUPPORT_UUID','secret-uuid'),('READING_HISTORY','[1,2,3]'),('first_run_done','1');
    """)
    try:
        import db_pack_catalog as PC
        t('표가 카탈로그에 CORE 로 있다(코어팩에 실려 나간다)',
          PC.TABLES.get(TABLE, ('',))[0] == PC.CORE)
        r = capture(sysdb, 'a', 'A 타입 — 밝은 화면', '설명', user_conn=usr, state_path=sp)
        t('★ 담으면 코드가 대문자·열쇠 수가 온다', r['code'] == 'A' and r['cfg'] == 2 and r['state'] == 2, r)
        row = sysdb.execute("SELECT cfg_json, state_json FROM %s WHERE code='A'" % TABLE).fetchone()
        cfg = json.loads(row[0])
        t('★★★ 허용 목록 밖은 안 담는다(기기 번호·읽은 기록·첫 실행)',
          'SUPPORT_UUID' not in cfg and 'READING_HISTORY' not in cfg and 'first_run_done' not in cfg,
          sorted(cfg))
        t('  화면 배치도 허용 목록만(창 크기·마지막 절은 안 담는다)',
          set(json.loads(row[1])) == {'cfg_node_mode', 'cfg_h_gap'})
        # 적용 — 다른 사용자 DB 에
        usr2 = sqlite3.connect(':memory:')
        usr2.executescript("CREATE TABLE user_config(config_key TEXT PRIMARY KEY, config_val TEXT);"
                           "INSERT INTO user_config VALUES('UI_THEME','WHITE'),('SUPPORT_UUID','other');")
        sp2 = os.path.join(d, 'state2.json')
        io.open(sp2, 'w', encoding='utf-8').write(json.dumps({'win_w': 900, 'cfg_h_gap': 3}))
        a = apply(sysdb, 'a', user_conn=usr2, state_path=sp2)
        t('★★ 적용 — 설정이 덮이고(테마 BLACK_L) 없던 열쇠는 생긴다',
          a['cfg'] == 2 and usr2.execute("SELECT config_val FROM user_config WHERE config_key='UI_THEME'"
                                          ).fetchone()[0] == 'BLACK_L'
          and usr2.execute("SELECT config_val FROM user_config WHERE config_key='font_size'").fetchone()[0] == '11')
        t('  받는 쪽 기기 번호는 그대로다',
          usr2.execute("SELECT config_val FROM user_config WHERE config_key='SUPPORT_UUID'").fetchone()[0] == 'other')
        d2 = json.load(io.open(sp2, encoding='utf-8'))
        t('  app_state 는 허용 열쇠만 덮이고 창 크기는 그대로',
          d2['cfg_h_gap'] == 12 and d2['cfg_node_mode'] == 'A' and d2['win_w'] == 900, d2)
        # 손으로 고친 양식에 금지 열쇠가 들어 있어도 적용하지 않는다
        sysdb.execute("UPDATE %s SET cfg_json=? WHERE code='A'" % TABLE,
                      (json.dumps({'UI_THEME': 'GREY', 'SUPPORT_UUID': 'hacked'}),))
        sysdb.commit()
        apply(sysdb, 'a', user_conn=usr2, state_path=sp2)
        t('★★★ 양식에 금지 열쇠가 들어 있어도 적용하지 않는다',
          usr2.execute("SELECT config_val FROM user_config WHERE config_key='SUPPORT_UUID'").fetchone()[0] == 'other')
        t('  같은 코드로 다시 담으면 덮어쓴다(행은 하나)',
          capture(sysdb, 'A', 'A 타입', user_conn=usr, state_path=sp)['code'] == 'A'
          and sysdb.execute("SELECT COUNT(*) FROM %s" % TABLE).fetchone()[0] == 1)
        capture(sysdb, 'B', 'B 타입', user_conn=usr, state_path=sp)
        t('  목록은 두 개', [x['code'] for x in list_presets(sysdb)] == ['A', 'B'])
        remove(sysdb, 'B')
        t('  걷으면 목록에서 사라지되 행은 남는다',
          [x['code'] for x in list_presets(sysdb)] == ['A']
          and sysdb.execute("SELECT COUNT(*) FROM %s" % TABLE).fetchone()[0] == 2)
        bad = False
        try:
            capture(sysdb, '', '이름', user_conn=usr, state_path=sp)
        except ValueError:
            bad = True
        t('  코드가 비면 거부한다', bad)
        bad = False
        try:
            apply(sysdb, 'ZZZ', user_conn=usr2, state_path=sp2)
        except KeyError:
            bad = True
        t('  없는 양식은 KeyError', bad)
    finally:
        sysdb.close()
        usr.close()
        import shutil
        shutil.rmtree(d, ignore_errors=True)
    print('db_pref_preset selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', errors='replace')
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect(DB)
    try:
        if '--capture' in sys.argv:
            i = sys.argv.index('--capture')
            code, name = sys.argv[i + 1], sys.argv[i + 2]
            descr = sys.argv[i + 3] if len(sys.argv) > i + 3 else ''
            print(capture(c, code, name, descr))
        else:
            for x in list_presets(c):
                print('  %-8s %-24s 설정 %d · 배치 %d · %s' % (x['code'], x['name'], x['n_cfg'], x['n_state'], x['made_at']))
            if not list_presets(c):
                print('  양식이 없다 — 배포 관리 ▸ 코어팩 ▸ 환경설정 양식에서 담는다')
    finally:
        c.close()
