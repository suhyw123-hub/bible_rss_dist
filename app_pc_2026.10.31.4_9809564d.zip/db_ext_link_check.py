# -*- coding: utf-8 -*-
"""외부 원어·용어 링크 사전 점검 — 「접속이 되는 링크만 보인다」(2026-10-25 docs/1.txt 2-5 사용자 지시).

두 갈래:
  ① 용어(인물·장소·…) 주소 `sys_ref_entity_url` — **줄마다** 다시 열어 본다(760줄 남짓).
     열리면 http_status=200 · is_active=1 · 아니면 is_active=0 (지우지 않는다 — 다음 점검에 살아날 수 있다).
  ② 원어사전 틀 `sys_ref_site`(scope='STRONG') — 낱말이 14,298개라 하나하나 열면 바깥 사이트에 2만 8천 번을 두드린다.
     틀은 번호만 바꾸는 꼴이라 **표본**(양 끝 + 무작위)으로 잰다 — 표본이 다 열리면 그 사이트를 살리고,
     하나라도 안 열리면 끈다(is_active=0). 잘못된 번호는 404 가 나므로(실측) 표본이 헛것을 놓치지 않는다.
  결과는 로컬 기록 `sys_ext_link_check`(배포 안 함).

쓰는 법:
  python db_ext_link_check.py --selftest
  python db_ext_link_check.py --entity        # 용어 주소 줄마다
  python db_ext_link_check.py --entity --failed   # 안 열린 줄만 다시
  python db_ext_link_check.py --strong [N]    # 원어사전 틀 표본(기본 24)
  python db_ext_link_check.py --status
⚠ 바깥 사이트를 두드린다 — 줄 사이 0.4초 쉰다 · 브라우저 머리글(봇 차단 사이트가 있다).
⚠ 판정 뒤에 모바일 공통팩을 다시 만들어야 폰에 간다(db_mobile_core).
"""
import datetime
import random
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

import appdb

DB = 'bible_master.db'
UA = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                    '(KHTML, like Gecko) Chrome/120 Safari/537.36',
      'Accept-Language': 'en-US,en;q=0.8'}
PAUSE = 0.4
MAX_STRONG = {'H': 8674, 'G': 5624}


def _now():
    return datetime.datetime.now().isoformat(timespec='seconds')


def fetch_status(url, timeout=20):
    """주소를 열어 HTTP 상태 — 연결이 안 되면 0."""
    try:
        # ⚠ 한글 주소(ko.wikipedia/wiki/다윗)는 그대로 보내면 urllib 가 못 보낸다 → 첫 판에서 한국어 위키 190줄이 다 0 이었다
        url = urllib.parse.quote(url, safe=":/?&=#%+,;@!$'()*~")
        r = urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout)
        r.read(2048)
        return r.status
    except urllib.error.HTTPError as e:
        return e.code
    except Exception:
        return 0


def ensure(conn):
    conn.execute('CREATE TABLE IF NOT EXISTS sys_ext_link_check (check_id INTEGER PRIMARY KEY AUTOINCREMENT,'
                 ' checked_at TEXT, kind TEXT, site_code TEXT, n INTEGER, ok INTEGER, note TEXT)')


def strong_url(template, strong):
    import overlay_read
    return overlay_read.strong_url(template, strong)


def sample_strongs(n=24, seed=None):
    """양 끝(첫·끝 번호) + 무작위 — 히브리·헬라 반씩."""
    rnd = random.Random(seed)
    out = ['H1', 'H%d' % MAX_STRONG['H'], 'G1', 'G%d' % MAX_STRONG['G']]
    while len(out) < n:
        k = 'H' if len(out) % 2 else 'G'
        s = '%s%d' % (k, rnd.randint(2, MAX_STRONG[k] - 1))
        if s not in out:
            out.append(s)
    return out


def check_entity(conn, fetch=fetch_status, pause=PAUSE, log=print, only_failed=False):
    rows = conn.execute("SELECT rel_id, url FROM sys_ref_entity_url"
                        " WHERE COALESCE(record_status,'LIVE')='LIVE' AND COALESCE(map_status,'') <> 'EXCLUDED'"
                        " AND url IS NOT NULL AND url <> ''"
                        + (" AND COALESCE(http_status,0) <> 200" if only_failed else "")).fetchall()
    ok = 0
    for i, (rid, url) in enumerate(rows):
        st = fetch(url)
        good = st == 200
        ok += good
        conn.execute('UPDATE sys_ref_entity_url SET http_status=?, last_checked=?, is_active=? WHERE rel_id=?',
                     (st, _now(), 1 if good else 0, rid))
        # ★ 줄마다 곧바로 적는다 — 쉬는 동안 쓰기 잠금을 쥐고 있으면 관리자 앱의 AI 작업이 「database is locked」로
        #   실패한다(2026-10-25 실제로 주석 번역 2건이 그렇게 실패했다)
        conn.commit()
        if (i + 1) % 50 == 0:
            log('  %d/%d · 열림 %d' % (i + 1, len(rows), ok))
        if pause:
            time.sleep(pause)
    ensure(conn)
    conn.execute('INSERT INTO sys_ext_link_check(checked_at, kind, site_code, n, ok, note) VALUES(?,?,?,?,?,?)',
                 (_now(), 'ENTITY', '*', len(rows), ok, ''))
    conn.commit()
    return len(rows), ok


def check_strong(conn, n=24, fetch=fetch_status, pause=PAUSE, seed=None, log=print):
    """틀마다 표본을 열어 본다 → {site_code: (표본 수, 열린 수, 살렸나)}"""
    sites = conn.execute("SELECT site_id, site_code, url_template FROM sys_ref_site WHERE scope='STRONG'"
                         " AND COALESCE(record_status,'LIVE')='LIVE'").fetchall()
    sample = sample_strongs(n, seed)
    res = {}
    ensure(conn)
    for sid, code, tpl in sites:
        ok, bad = 0, []
        for s in sample:
            st = fetch(strong_url(tpl, s))
            if st == 200:
                ok += 1
            else:
                bad.append('%s=%s' % (s, st))
            if pause:
                time.sleep(pause)
        alive = ok == len(sample)
        conn.execute('UPDATE sys_ref_site SET is_active=? WHERE site_id=?', (1 if alive else 0, sid))
        conn.execute('INSERT INTO sys_ext_link_check(checked_at, kind, site_code, n, ok, note) VALUES(?,?,?,?,?,?)',
                     (_now(), 'STRONG', code, len(sample), ok, ' '.join(bad)[:400]))
        conn.commit()
        res[code] = (len(sample), ok, alive)
        log('  %s 표본 %d · 열림 %d · %s %s' % (code, len(sample), ok, '살림' if alive else '끔', ' '.join(bad)[:120]))
    conn.commit()
    return res


def status(conn):
    ensure(conn)
    for r in conn.execute('SELECT checked_at, kind, site_code, n, ok, note FROM sys_ext_link_check'
                          ' ORDER BY check_id DESC LIMIT 10'):
        print(r)
    print(conn.execute("SELECT s.site_code, COUNT(*), SUM(u.is_active) FROM sys_ref_entity_url u"
                       " JOIN sys_ref_site s ON s.site_id=u.site_id GROUP BY 1").fetchall())


def selftest():
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.execute('CREATE TABLE sys_ref_entity_url (rel_id INTEGER PRIMARY KEY, entity_id INT, site_id INT, url TEXT,'
              ' http_status INT, last_checked TEXT, is_active INT, alias_used TEXT, record_status TEXT, map_status TEXT)')
    c.execute('CREATE TABLE sys_ref_site (site_id INTEGER PRIMARY KEY, site_code TEXT, url_template TEXT, scope TEXT,'
              ' is_active INT, record_status TEXT)')
    c.executemany('INSERT INTO sys_ref_entity_url(rel_id, url, is_active, record_status, map_status) VALUES(?,?,?,?,?)',
                  [(1, 'https://ok/a', 1, 'LIVE', 'AUTO'), (2, 'https://dead/b', 1, 'LIVE', 'AUTO'),
                   (3, 'https://ok/c', 0, 'LIVE', 'EXCLUDED')])
    c.executemany('INSERT INTO sys_ref_site VALUES(?,?,?,?,?,?)',
                  [(19, 'GOOD', 'https://good/{strong_lang}/{strong_num}.htm', 'STRONG', 1, 'LIVE'),
                   (20, 'HALF', 'https://half/{strong_code_lc}', 'STRONG', 1, 'LIVE')])
    seen = []

    def fake(u):
        seen.append(u)
        if u.startswith('https://dead'):
            return 404
        if u.startswith('https://half/') and u.endswith('h1'):
            return 403
        return 200

    ok = []
    n, good = check_entity(c, fetch=fake, pause=0, log=lambda *a: None)
    ok.append((n, good) == (2, 1))
    ok.append(c.execute('SELECT is_active, http_status FROM sys_ref_entity_url WHERE rel_id=2').fetchone() == (0, 404))
    ok.append('https://ok/c' not in seen)   # 사람이 뺀(EXCLUDED) 줄은 두드리지 않는다
    r = check_strong(c, n=10, fetch=fake, pause=0, seed=1, log=lambda *a: None)
    ok.append(r['GOOD'] == (10, 10, True))
    ok.append(r['HALF'][2] is False and c.execute('SELECT is_active FROM sys_ref_site WHERE site_id=20').fetchone()[0] == 0)
    ok.append('https://good/hebrew/8674.htm' in seen and 'https://good/greek/1.htm' in seen)  # 양 끝을 잰다
    s = sample_strongs(24, seed=3)
    ok.append(len(s) == 24 == len(set(s)))
    print('db_ext_link_check selftest %d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(DB)
    if '--entity' in a:
        n, ok = check_entity(conn, only_failed='--failed' in a)
        print('용어 주소 %d줄 중 %d 열림' % (n, ok))
    if '--strong' in a:
        i = a.index('--strong')
        n = int(a[i + 1]) if len(a) > i + 1 and a[i + 1].isdigit() else 24
        check_strong(conn, n)
    if '--status' in a:
        status(conn)
