"""db_book_provenance.py — 수입 자료의 판본·전사 무결성 전수검사 (영구 도구).

**착수 전에 돌린다.** 번역·현대영어화에 손대기 전, 우리가 가진 것이 무슨 판본이고
받은 그대로인지 확인한다. 절차와 판정 등급은 `booktrans.md` §1.

대상 — 남의 글을 담는 세 곳:
    sys_book_asset  → sys_book_unit_text (도서·설교집)
    sys_ref_source  → sys_ref_text       (교리문답·사전·자료집)
    sys_commentary_source → sys_commentary_text (주석)

기계가 하는 것은 네 단계뿐이다(`booktrans.md` §1-2):
    ① 도달      source_url 이 지금 열리는가            --net 일 때만
    ③ 지어냄    임포터가 덧붙인 글자가 있는가
    ④ 전사자    편집자 주·쪽번호·HTML 잔재·OCR 손상
    ⑤ 이음매    여러 번 나눠 임포트한 흔적

**② 판본 확인과 ⑥ 표본 대조는 기계가 못 한다.** 사람이 출처를 열어 판본 표기를 읽고,
확인된 스캔과 앞·중간·끝 세 지점을 맞춘다. 이 도구는 그 일을 **줄여 주지 않는다** —
어디를 봐야 하는지 알려 줄 뿐이다.

⚠ 이 도구는 **판정하지 않는다.** 등급(확정/미상/불일치)은 사람이 매긴다.
   ①③④⑤ 가 깨끗한 것은 「흠이 안 보인다」이지 「원본과 같다」가 아니다.

사용:
    python db_book_provenance.py --selftest      (의무)
    python db_book_provenance.py --inventory     대장 (booktrans.md §1-1)
    python db_book_provenance.py --scan          ③④⑤ 전수
    python db_book_provenance.py --scan --code MURRAY_AIC
    python db_book_provenance.py --net           ① source_url 도달 확인
"""
import argparse
import re
import sys
import appdb

# ── ④ 전사자·기계가 남긴 흔적 ──────────────────────────────────────────────
# ⚠ 값은 (이름, 정규식, 이것만으로 「불일치」인가).
#    OCR 손상은 흔하고 고칠 수 있어 경고에 그친다. 편집자 주는 다르다 —
#    저자의 글도 그 판본 편집자의 글도 아닌 것이 본문에 섞였다는 뜻이다.
ARTIFACTS = [
    ('편집자·출판사 주', r"Publisher'?s Note|Editor'?s Note|Transcriber'?s Note", True),
    ('각주 표시 [n]',    r'\[\d{1,2}\]',                                        False),
    ('Footnotes 절',     r'^\s*Footnotes?\s*:',                                 False),
    ('HTML 잔재',        r'<[a-zA-Z/][^>]{0,40}>|&nbsp;|&amp;|&quot;|&#\d+;',   True),
    ('쪽 번호 줄',       r'^\s*\d{1,4}\s*$',                                    False),
    ('OCR 손상 의심',    r'\b[a-z]{1,2}[A-Z][a-z]{2,}\b|\b[A-Za-z]*[0O]{1}[a-z]{3,}\b', False),
    ('제어문자',         r'[\x00-\x08\x0b\x0c\x0e-\x1f]',                       True),
]

# ── ③ 임포터가 덧붙였을 만한 것 ────────────────────────────────────────────
# 본문 끝의 「— 저자, 제목 (연도)」 줄. 출처가 준 것이 아니라 우리가 붙였다면
# **연도가 우리 추측**일 수 있다(머레이가 그랬다).
TAIL_ATTRIB = re.compile(r'^\s*(--|—|–)\s*(.{3,90}?)\s*(\((\d{4})\))?\s*$')


def _tables(conn):
    """(갈래, 자료집표, 본문표, 자료집PK, 본문FK, 코드칸, 제목칸, 연도칸, url칸)"""
    out = [('도서·설교집', 'sys_book_asset', 'sys_book_unit_text', 'book_id',
            None, 'book_code', 'title', 'pub_year', 'source_url')]
    have = {r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'")}
    if 'sys_ref_source' in have and 'sys_ref_text' in have:
        out.append(('교리문답·사전', 'sys_ref_source', 'sys_ref_text', 'ref_src_id',
                    None, 'src_code', 'title', 'pub_year', 'source_url'))
    if 'sys_commentary_source' in have:
        out.append(('주석', 'sys_commentary_source', 'sys_commentary_text',
                    'source_id', None, 'commentary_code', 'title', 'pub_year',
                    'source_url'))
    return out


def _book_rows(conn, code=None):
    """도서·설교집의 (코드, 제목, 연도, url, seq, 본문). ORIGINAL 만."""
    q = ("SELECT ba.book_code, ba.title, ba.pub_year, ba.source_url, "
         "       bu.sequence, t.body_text "
         "FROM sys_book_unit_text t "
         "JOIN sys_book_unit  bu ON bu.unit_id = t.unit_id "
         "JOIN sys_book_asset ba ON ba.book_id = bu.book_id "
         "WHERE t.text_variant='ORIGINAL' "
         "  AND COALESCE(t.record_status,'LIVE')='LIVE' ")
    a = ()
    if code:
        q += "AND ba.book_code=? "
        a = (code,)
    return conn.execute(q + "ORDER BY ba.book_code, bu.sequence", a).fetchall()


def _ref_rows(conn, code=None):
    have = {r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'")}
    if 'sys_ref_text' not in have:
        return []
    cols = {r[1] for r in conn.execute("PRAGMA table_info(sys_ref_text)")}
    body = 'body_text' if 'body_text' in cols else None
    if not body:
        return []
    q = ("SELECT rs.src_code, rs.title, rs.pub_year, rs.source_url, "
         "       ru.unit_id, t.%s "
         "FROM sys_ref_text t "
         "JOIN sys_ref_unit   ru ON ru.unit_id = t.ref_id "
         "JOIN sys_ref_source rs ON rs.ref_src_id = ru.ref_src_id " % body)
    a = ()
    if code:
        q += "WHERE rs.src_code=? "
        a = (code,)
    try:
        return conn.execute(q + "ORDER BY rs.src_code, ru.unit_id", a).fetchall()
    except Exception:
        return []


def inventory(conn):
    print('=' * 78)
    print('대장 — booktrans.md §1-1')
    print('=' * 78)
    print('%-20s %-34s %6s %5s %9s  %s'
          % ('코드', '제목', '연도', '편수', '평균자수', '출처'))
    for code, title, yr, url, cnt, avg in conn.execute("""
        SELECT ba.book_code, ba.title, ba.pub_year, ba.source_url,
               COUNT(t.text_id), CAST(AVG(LENGTH(t.body_text)) AS INT)
        FROM sys_book_asset ba
        LEFT JOIN sys_book_unit bu ON bu.book_id = ba.book_id
        LEFT JOIN sys_book_unit_text t
               ON t.unit_id = bu.unit_id AND t.text_variant='ORIGINAL'
        GROUP BY ba.book_id ORDER BY ba.book_code"""):
        u = (url or '')
        u = (u[:40] + '…') if len(u) > 41 else (u or '(없음)')
        print('%-20s %-34s %6s %5s %9s  %s'
              % (code, (title or '')[:34], yr if yr is not None else '(없음)',
                 cnt or 0, avg or 0, u))
    print()
    print('⚠ 연도가 있어도 「확인된 값」이라는 뜻이 아니다 — 임포터의 추측일 수 있다.')
    print('  판정 등급(확정/미상/불일치)은 description 에 사람이 남긴다.')


def scan_one(rows):
    """한 자료집의 ③④⑤. rows = [(seq, body), …]"""
    found = {}
    tails = {}
    for seq, body in rows:
        b = body or ''
        for name, rx, hard in ARTIFACTS:
            n = len(re.findall(rx, b, re.M))
            if n:
                d = found.setdefault(name, {'n': 0, 'seq': [], 'hard': hard})
                d['n'] += n
                d['seq'].append(seq)
        lines = [l for l in b.rstrip().split('\n') if l.strip()]
        if lines:
            m = TAIL_ATTRIB.match(lines[-1])
            if m:
                tails.setdefault((m.group(1), m.group(2), m.group(4)), []).append(seq)
    return found, tails


def scan(conn, code=None):
    groups = {}
    for c, title, yr, url, seq, body in _book_rows(conn, code):
        groups.setdefault((c, title, yr, url), []).append((seq, body))
    for c, title, yr, url, seq, body in _ref_rows(conn, code):
        groups.setdefault((c, title, yr, url), []).append((seq, body))

    if not groups:
        print('대상 없음')
        return

    for (c, title, yr, url), rows in sorted(groups.items()):
        found, tails = scan_one(rows)
        hard = [k for k, v in found.items() if v['hard']]
        mixed = len(tails) > 1
        if not found and not mixed:
            continue
        print('─' * 78)
        print('%s  (%s · %d편 · 연도 %s)'
              % (c, (title or '')[:40], len(rows), yr if yr is not None else '없음'))
        for name, v in sorted(found.items()):
            s = v['seq']
            loc = str(s) if len(s) <= 8 else '%d편에 걸침' % len(s)
            print('  %-16s %5d건  %s%s'
                  % (name, v['n'], loc, '   ← 이것만으로 불일치 후보' if v['hard'] else ''))
        if tails:
            print('  %-16s' % '본문 끝 출처 줄')
            for (dash, txt, year), s in sorted(tails.items(), key=lambda x: -len(x[1])):
                loc = str(s) if len(s) <= 8 else '%d편' % len(s)
                print('       %r  연도 %s  %s' % (dash + ' ' + txt[:46],
                                                  year or '없음', loc))
            if mixed:
                print('       ⑤ ⚠ **모양이 %d가지다 — 여러 번 나눠 임포트한 이음매**' % len(tails))
    print('─' * 78)
    print('※ ② 판본 확인과 ⑥ 표본 대조는 기계가 못 한다 — booktrans.md §1-2.')
    print('  깨끗하게 나온 자료집도 「흠이 안 보인다」이지 「원본과 같다」가 아니다.')


def net(conn):
    import urllib.request
    import urllib.error
    print('① 출처 도달 확인 (booktrans.md §1-2)')
    seen = {}
    for tbl, ccol, ucol in (('sys_book_asset', 'book_code', 'source_url'),
                            ('sys_ref_source', 'src_code', 'source_url'),
                            ('sys_commentary_source', 'commentary_code', 'source_url')):
        try:
            rows = conn.execute("SELECT %s, %s FROM %s" % (ccol, ucol, tbl)).fetchall()
        except Exception:
            continue
        for code, url in rows:
            if not url:
                print('  %-22s (출처 없음)' % code)
                continue
            if url in seen:
                print('  %-22s %s' % (code, seen[url]))
                continue
            try:
                req = urllib.request.Request(
                    url, headers={'User-Agent': 'Mozilla/5.0'}, method='HEAD')
                with urllib.request.urlopen(req, timeout=15) as r:
                    st = 'OK %d' % r.status
            except urllib.error.HTTPError as e:
                st = '⚠ HTTP %d' % e.code
            except Exception as e:
                st = '⚠ %s' % type(e).__name__
            seen[url] = st
            print('  %-22s %-10s %s' % (code, st, url[:52]))


def selftest():
    """흠을 넣어 보고 잡히는지, 멀쩡한 글이 안 잡히는지 **양쪽 다** 본다."""
    ok = True
    clean = [(1, 'A plain paragraph of ordinary prose.\n\n— Someone, A Book'),
             (2, 'Another plain paragraph here.\n\n— Someone, A Book')]
    f, t = scan_one(clean)
    strayed = {k: v['n'] for k, v in f.items()}
    if strayed:
        print('FAIL 멀쩡한 글에서 흠을 찾았다:', strayed); ok = False
    if len(t) != 1:
        print('FAIL 같은 출처 줄을 여러 모양으로 셌다:', t); ok = False

    cases = [
        ('편집자 주',  "text\n\nPublisher's Note: reissued 1955.", '편집자·출판사 주'),
        ('각주 표시',  'Holy is higher than righteous.[1] More text.', '각주 표시 [n]'),
        ('HTML 잔재',  'text <br> more &nbsp; text',                  'HTML 잔재'),
        ('쪽 번호',    'text\n\n  147  \n\nmore text',                '쪽 번호 줄'),
        ('제어문자',   'text\x07more',                                 '제어문자'),
    ]
    for name, body, want in cases:
        f, _ = scan_one([(1, body)])
        if want not in f:
            print('FAIL %s 를 못 잡는다 (잡은 것: %s)' % (name, list(f))); ok = False

    # ⑤ 이음매 — 대시가 다르면 두 모양으로 세야 한다
    _, t = scan_one([(1, 'a\n\n-- X, Y (1895)'), (2, 'b\n\n— X, Y (1895)')])
    if len(t) != 2:
        print('FAIL 이음매(대시 차이)를 못 잡는다:', t); ok = False
    # 같은 모양이면 한 묶음
    _, t = scan_one([(1, 'a\n\n-- X, Y (1895)'), (2, 'b\n\n-- X, Y (1895)')])
    if len(t) != 1:
        print('FAIL 같은 출처 줄을 갈라 셌다:', t); ok = False
    # 연도를 뽑아내는가
    if list(t)[0][2] != '1895':
        print('FAIL 연도를 못 뽑는다:', t); ok = False

    print('selftest', 'OK' if ok else 'FAIL')
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--inventory', action='store_true')
    ap.add_argument('--scan', action='store_true')
    ap.add_argument('--net', action='store_true')
    ap.add_argument('--code')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect()
    if a.inventory:
        inventory(conn)
    elif a.net:
        net(conn)
    else:
        scan(conn, a.code)
    conn.close()


if __name__ == '__main__':
    main()
