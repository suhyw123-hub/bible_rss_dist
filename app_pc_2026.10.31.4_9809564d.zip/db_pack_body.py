# -*- coding: utf-8 -*-
"""본문팩 빌더 — **사용자가 선택해 받는 것**을 자산 하나씩 만든다.

★★★ 왜 (2026-09-04 사용자 지시 — 「도서/설교를 한 묶음으로 배포한다고 가정하지
  마라. 사용자는 **책 한권 선호하는 언어로** 선택하여 다운로드 할 것이다.
  **그래야 최소용량을 사용**한다」).
  실측이 그것을 못 박았다 — 도서 (책×언어×변형) 67짝의 **중앙이 0.13MB** 인데
  **스펄전 설교 한 권이 124MB(전체의 85%)** 다. 묶으면 한 권 때문에 모두가
  124MB 를 받는다.

**팩 하나 = 사용자가 하나로 고르는 것**
  BIBLE 역본 하나 · BOOK/SERMON 책×언어×변형 · COMM 주석서×언어 ·
  DICT 자료집×언어 · DESC **성경책 묶음×언어** · LEX 사전 하나

★ **형식은 코어팩과 같다**(`db_pack_core` 의 `{cols, rows}`) — 받는 쪽이 한
  가지 적재기로 둘 다 읽는다. 두 형식을 만들면 적재기도 둘이 된다.

⚠ **담을 조회는 갈래마다 다르다**(`PARTS`) — 갈래를 늘리면 거기 한 줄.
  안 적으면 `build` 가 **거부한다**(조용히 빈 팩을 만들지 않는다).

`--selftest`(의무) · `--build KIND KEY [LANG] [VARIANT]` · `--list` · `--size`.
"""
import argparse
import gzip
import hashlib
import io
import json
import os
import re
import sqlite3
import sys
import time

import appdb
import db_pack_core as PK

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')
DIST = PK.DIST
FORMAT = PK.FORMAT

#: 갈래 → `(표, 조회 SQL, 인자 만들기)`.
#: SQL 은 **그 자산의 행만** 골라야 한다. `?` 자리는 `args(key, lang, variant)`.
#: ⚠⚠ 갈래를 늘리면 **여기 한 줄** — 없으면 `build` 가 거부한다.
PARTS = {
    # ★★ **시작 이미지 — 스타일 하나가 팩 하나**(2026-09-05).
    #   열쇠 = 스타일 이름. ⚠ 기본(스타일 없음)은 **코어에 남는다** —
    #   팩을 안 받은 사용자에게도 시작 화면 사진이 있어야 한다.
    #   ⚠ BLOB 이라 base64 봉투(`db_pack_core.__b64__`)를 그대로 탄다.
    # ★★ **팩 하나 = 장면 묶음 하나**(2026-09-05 사용자 확정).
    #   열쇠 = 팩 코드(BASIC·LAND·WATER·SKY·FARM·PLACE·WORSHIP).
    #   ⚠⚠ **BASIC 은 「모든 장면을 조금씩」**이라 장면으로 못 가른다 —
    #     사진에 `basic=1` 로 표시한다(사용자 지적 「산 팩 하나만 선택하면
    #     하늘 구절에 표시할 사진이 없다」).
    #   ⚠ 장면을 안 고른 사진은 **코어에 남는다**(팩을 안 받아도 하나는 뜬다).
    'IMAGE': [
        ('sys_splash_image',
         # ★ 2026-10-11 **번호 사진팩** — 열쇠가 숫자면 그 사진팩(photo_pack). 옛 장면 열쇠도 그대로 읽는다.
         "SELECT * FROM sys_splash_image WHERE"
         " CASE WHEN ? GLOB '[0-9]*' THEN photo_pack=CAST(? AS INTEGER)"
         "      WHEN ?='BASIC' THEN COALESCE(basic,0)=1"
         "      ELSE scene IN (SELECT scene_code FROM sys_scene_pack"
         "                      WHERE pack_code=?) END",
         (lambda k, l, v: [k, k, k, k])),
        # ★★ **다국어 제목·설명을 함께 싣는다** (2026-09-05) — 안 실으면
        #   사용자 화면이 사진만 받고 **설명 줄이 영영 안 뜬다**.
        #   ⚠ `sys_text_asset` 은 코어에 안 실리고(PACK/DESC) DESC 팩은
        #     `text_type` 으로 걸러 **겹치지 않는다**(실측으로 확인).
        ('sys_text_asset',
         "SELECT t.* FROM sys_text_asset t"
         " WHERE t.text_type IN ('SPLASH_TITLE','SPLASH_DESC')"
         "   AND COALESCE(t.record_status,'LIVE')='LIVE'"
         "   AND t.clicked_id IN (SELECT img_id FROM sys_splash_image WHERE"
         "     CASE WHEN ? GLOB '[0-9]*' THEN photo_pack=CAST(? AS INTEGER)"
         "          WHEN ?='BASIC' THEN COALESCE(basic,0)=1"
         "          ELSE scene IN (SELECT scene_code FROM sys_scene_pack"
         "                          WHERE pack_code=?) END)",
         (lambda k, l, v: [k, k, k, k])),
    ],

    'BIBLE': [(
        'bible_content',
        "SELECT * FROM bible_content WHERE version_code=?",
        lambda k, l, v: [k])],
    'BOOK': [(
        'sys_book_unit_text',
        "SELECT t.* FROM sys_book_unit_text t"
        " JOIN sys_book_unit u ON u.unit_id=t.unit_id"
        " JOIN sys_book_asset ba ON ba.book_id=u.book_id"
        " WHERE ba.book_code=? AND UPPER(t.lang_code)=?"
        "   AND COALESCE(t.text_variant,'-')=?",
        lambda k, l, v: [k, (l or '').upper(), v or '-'])],
    'COMM': [(
        'sys_commentary_text',
        "SELECT t.* FROM sys_commentary_text t"
        " JOIN sys_commentary_entry e ON e.entry_id=t.entry_id"
        " JOIN sys_commentary_source cs ON cs.commentary_id=e.commentary_id"
        " WHERE cs.commentary_code=? AND UPPER(t.lang_code)=?",
        lambda k, l, v: [k, (l or '').upper()])],
    'DICT': [(
        'sys_ref_text',
        "SELECT t.* FROM sys_ref_text t"
        " JOIN sys_ref_unit u ON u.ref_unit_id=t.ref_unit_id"
        " JOIN sys_ref_source rs ON rs.ref_src_id=u.ref_src_id"
        " WHERE rs.src_code=? AND UPPER(t.lang_code)=?",
        lambda k, l, v: [k, (l or '').upper()])],
    # ★★★ 설명문 — **(성경책 묶음 × 언어)가 팩 하나**(2026-09-24 286차).
    #   ⚠⚠ 그전에는 **책 하나 × 언어**였다. 66권 × 11언어 = **726 팩**이고
    #     요한이서 한국어는 **12 KB** 다 — 사전의 낱말 하나하나를 팩으로 만드는
    #     꼴이라 사용자가 고를 수가 없다(사용자 지적 그대로).
    #   ⇒ `BOOK_GROUPS` 여덟 묶음 × 언어 = **최대 88 팩**, 한 팩 0.8~6.4 MB
    #     (전권을 다 채웠을 때의 gzip 어림). 고를 만한 크기다.
    #   ★ 유형(전문/일반/질문/기도)은 **한 팩 안에** 넣는다 — 따로 고르게 하면
    #     「일반 설명은 있는데 묵상질문은 없는」 반쪽 화면이 된다.
    'DESC': [(
        'sys_text_asset',
        "SELECT t.* FROM sys_text_asset t"
        " JOIN bible_index bi ON bi.verse_id=t.clicked_id"
        " WHERE bi.bcode BETWEEN ? AND ? AND UPPER(t.lang_code)=?"
        "   AND t.record_status='LIVE'"
        "   AND t.text_type IN ('VERS_DESC','VERS_QUESTION','VERS_PRAYER',"
        "                       'VERS_VERS_DESC')",
        lambda k, l, v: list(group_range(k)) + [(l or '').upper()])],
}
PARTS['SERMON'] = PARTS['BOOK']

#: 원어 사전 — 표 통째. `key` 가 어느 사전인지 정한다.
LEX_TABLES = {
    'STRONG': ['sys_lemma_master'],
    'BDB': ['sys_bdb_entry', 'sys_bdb_map'],
    'ABSMITH': ['sys_absmith_entry', 'sys_absmith_map'],
    'THAYER': ['sys_thayer_entry'],
}


#: **자산 하나가 너무 커서 쪼갠 것** → `(kind, key)` → `[(코드, 이름, 첫책, 끝책)]`.
#:
#: ★★★ 왜 (2026-09-04 사용자 지시 「스펄전 어떻게 분할할지 정하라. **주제를
#:   고려하라**. **사용자의 선호가 갈리는 기준으로 분할하는 방식이 제일 좋다**」).
#:   실측 — 스펄전 설교 한 권이 **31MB** 라 jsDelivr 20MB 를 넘어 CDN 이 안
#:   서빙한다. 게다가 한 편을 읽으려고 31MB 를 받게 하는 것은 쪼갠 뜻이 없다.
#:
#: ★★ **주제 태그는 데이터가 0 이라 못 쓴다**(실측 `TAG_BUNT` 0행 ·
#:   `BUNT_ENTI` 296행 = 8%). **지어내지 않는다**(§0-1b).
#:   ⇒ **본문이 곧 주제다** — 시가서는 위로·탄식, 바울서신은 구원론,
#:     복음서는 그리스도의 생애다. 그리고 그것이 **사용자의 실제 동선**이다
#:     (시편을 읽다 시편 설교를 찾는다).
#:
#: ⚠ **구약/신약 둘로 가르지 않았다** — 15MB 씩이라 한도는 통과하지만
#:   **선호를 못 가른다**(「구약 설교만」 원하는 사람은 드물다).
#: ⚠ **책별 65개로도 안 쪼갰다** — 시편만 3.8MB 이고 나머지는 0.1MB 이하라
#:   목록이 65줄이 되어 고르기가 더 어렵다.
#: ⚠ **좌표 없는 편은 버리지 않는다** — 42편이 목회 서신·예배 안내다.
#:   `NOBOOK` 묶음이 그것을 받는다(빠지면 영영 못 받는다).
#: ★★★ **성경책 묶음 — 단일 소스**(2026-09-24 286차).
#: 스펄전 설교집을 쪼갤 때 쓰던 표를 **설명문 팩도 함께 쓴다** — 두 곳에 적으면
#: 「설교는 오경인데 설명문은 모세오경」처럼 이름이 갈린다.
#: ⚠ 경계를 바꾸면 **이미 발행한 팩의 범위가 달라진다** — 바꾸기 전에
#:   `sys_pack_item` 에 그 묶음의 판이 올라 있는지 먼저 본다.
BOOK_GROUPS = (
    ('PENT', '오경', 1, 5),
    ('HIST', '역사서', 6, 17),
    ('POET', '시가서', 18, 22),
    ('MAJP', '대선지서', 23, 27),
    ('MINP', '소선지서', 28, 39),
    ('GOSP', '복음서·사도행전', 40, 44),
    ('PAUL', '바울서신', 45, 57),
    ('GENE', '일반서신·계시록', 58, 66),
)

SPLIT = {
    ('SERMON', 'SPURGEON_SERMONS'): list(BOOK_GROUPS) + [
        # ⚠ 설교집에만 있는 자리 — 성경 좌표가 없는 편(목회 서신·예배)
        ('NOBOOK', '그 밖(목회 서신·예배)', 0, 0),
    ],
}


def group_range(code):
    """묶음 코드 → `(첫 책, 끝 책)`. 모르면 **온 성경**(조용히 비우지 않는다)."""
    for c_, _n, a, b in BOOK_GROUPS:
        if c_ == str(code or '').upper():
            return a, b
    return 1, 66


def group_name(code):
    """묶음 코드 → 사람이 읽는 이름. ⚠ 화면이 코드를 그대로 적지 않게 한다."""
    for c_, n, _a, _b in BOOK_GROUPS:
        if c_ == str(code or '').upper():
            return n
    return str(code or '')


def group_of(bcode):
    """책 번호 → 묶음 코드. 어느 묶음에도 없으면 `None`."""
    try:
        b = int(bcode)
    except Exception:                                        # noqa: BLE001
        return None
    for c_, _n, a, b2 in BOOK_GROUPS:
        if a <= b <= b2:
            return c_
    return None


def split_of(kind, key):
    """그 자산의 쪼갠 묶음 → `[(코드, 이름, 첫책, 끝책)]`. 안 쪼갠 것은 빈 목록."""
    return SPLIT.get(((kind or '').upper(), str(key or '')), [])


def split_key(key, code):
    """쪼갠 자산의 열쇠 — `SPURGEON_SERMONS#POET`.

    ⚠ **`key` 안에 넣는다** — `sys_pack_item` 열쇠가
      `(kind, key, lang, variant)` 라 묶음 자리가 따로 없다. 표를 고치면
      이미 매긴 판·받은 기록이 어긋나므로 열쇠 안에서 푼다.
    """
    return '%s#%s' % (key, code)


def split_parts(key):
    """`SPURGEON_SERMONS#POET` → `('SPURGEON_SERMONS', 'POET')`."""
    k, _, g = str(key or '').partition('#')
    return k, g


def safe_name(s):
    """파일 이름에 쓸 수 있게. ⚠ 코드에 `/`·공백이 섞인 것이 있다."""
    return re.sub(r'[^A-Za-z0-9_.-]', '_', str(s or '-'))[:40]


def pack_name(kind, key='-', lang='-', variant='-'):
    return 'pack_%s_%s_%s_%s.json.gz' % (
        safe_name(kind), safe_name(key), safe_name(lang), safe_name(variant))


def _dump_query(conn, table, sql, args):
    """조회 결과 → `{'cols','rows'}`. 형식은 코어팩과 같다."""
    cur = conn.execute(sql, args)
    cols = [d[0] for d in cur.description]
    rows = [[PK._enc(v) for v in r] for r in cur]
    return {'cols': cols, 'rows': rows}


def parts_for(kind, key):
    """그 자산이 담을 `[(표, sql, args)]`. 모르면 빈 목록.

    ★★ **쪼갠 자산이면 범위 조건을 더한다**(`SPLIT`) — 담는 문과 지우는 문이
      이 한 곳을 함께 쓰므로 **정의상 범위가 같다**(§db_pack_body.remove).
    """
    kind = (kind or '').upper()
    base, grp = split_parts(key)
    if kind == 'LEX':
        return [(t, "SELECT * FROM %s" % t, (lambda k, l, v: []))
                for t in LEX_TABLES.get((base or '').upper(), [])]
    ps = PARTS.get(kind, [])
    if not grp:
        return ps
    rng = None
    for code, _nm, a, b in split_of(kind, base):
        if code == grp:
            rng = (a, b)
            break
    if rng is None:
        return []                      # 모르는 묶음 — 빈 팩을 만들지 않는다
    if rng == (0, 0):
        # ⚠ 「그 밖」 = 성경 좌표가 없는 편. 빠뜨리면 영영 못 받는다.
        cond = " AND u.start_vid IS NULL"
    else:
        cond = (" AND u.start_vid IN (SELECT verse_id FROM bible_index"
                "  WHERE bcode BETWEEN %d AND %d)" % rng)
    out = []
    for tbl, sql, argf in ps:
        out.append((tbl, sql + cond,
                    (lambda k, l, v, _f=argf, _b=base: _f(_b, l, v))))
    return out


def build(conn, kind, key='-', lang='-', variant='-', out_dir=None, name=None):
    """본문팩 하나를 만든다 → `{'file','bytes','rows','sha1',…}`.

    ⚠ **모르는 갈래는 거부한다** — 조용히 빈 팩을 만들면 사용자가 받고도
      아무것도 안 생긴다(가장 나쁜 실패다).
    """
    kind = (kind or '').upper()
    ps = parts_for(kind, key)
    if not ps:
        raise ValueError('담을 것을 모르는 갈래다: %s (PARTS 에 한 줄)' % kind)
    out_dir = out_dir or DIST
    os.makedirs(out_dir, exist_ok=True)
    # ★★★ **팩이 자기 릴리스를 적는다**(2026-09-05 · 사용자 확정 체계).
    #   ⚠⚠ 이것이 없으면 적재기가 「이 본문이 내 코어보다 새것인가」를 알 수
    #     없다. 그러면 **새 자료가 DB 에 있는데 가리키는 연결이 없어 안 보인다**
    #     (받고도 아무 일이 안 일어나는 가장 나쁜 실패).
    rel = 0
    try:
        import db_pack_release as RL
        rel = RL.item_release(conn, kind, key, lang, variant)
    except Exception:
        rel = 0
    body = {'format': FORMAT, 'kind': kind, 'key': key, 'lang': lang,
            'variant': variant, 'release': rel,
            'made_at': time.strftime('%Y-%m-%d %H:%M'),
            'tables': {}}
    # ★ 2026-10-11 번호 사진팩 — 「추가」/「교체」를 팩이 싣고 간다(받는 쪽이 그대로 따른다).
    if kind == 'IMAGE' and str(key).isdigit():
        try:
            import photo_pack as _PP
            body['mode'] = _PP.mode_of(conn, int(key))
        except Exception:
            body['mode'] = 'ADD'
    n = 0
    for table, sql, argf in ps:
        try:
            d = _dump_query(conn, table, sql, argf(key, lang, variant))
        except Exception as e:                               # noqa: BLE001
            raise ValueError('%s 를 담을 수 없다: %s' % (table, str(e)[:80]))
        body['tables'][table] = d
        n += len(d['rows'])
    # ⚠ **빈 팩은 만들지 않는다** — 담을 것이 0 이면 자산을 잘못 고른 것이다
    if n == 0:
        raise ValueError('담을 것이 없다: %s %s %s %s'
                         % (kind, key, lang, variant))
    path = os.path.join(out_dir, name or pack_name(kind, key, lang, variant))
    raw = json.dumps(body, ensure_ascii=False).encode('utf-8')
    with gzip.open(path, 'wb', compresslevel=6) as f:
        f.write(raw)
    return {'file': path, 'bytes': os.path.getsize(path), 'raw': len(raw),
            'rows': n, 'tables': len(body['tables']),
            'sha1': hashlib.sha1(raw).hexdigest(), 'release': rel,
            # ★★ **담긴 것만의 해시** — 만든 시각을 빼야 「내용이 그대로인가」를
            #   잴 수 있다(§db_pack_core.content_sha1 · 실측으로 잡은 함정).
            'content_sha1': PK.content_sha1(body),
            'kind': kind, 'key': key, 'lang': lang, 'variant': variant}


def remove(conn, kind, key='-', lang='-', variant='-', dry=False):
    """그 자산의 **본문을 지운다** → 지운 행 수.

    ★★★ 왜 (2026-09-04 사용자 지시 「사용자가 이미 다운로드 한 이후 **용량이
      부족해서 삭제하고 또 다시 다운로드 하는 상황**도 고려하라」).
      지우는 것은 **본문뿐**이다 — 껍데기·연결·좌표는 코어라 남고, 그래서
      지운 뒤에도 「멜기세덱 반차 — 스펄전 설교 선집」은 그대로 보이며
      폴백이 [받기] 를 낸다.

    ⚠⚠ **`build` 와 같은 SQL 을 쓴다**(`parts_for`) — 담는 문과 지우는 문이
      갈리면 「받은 것보다 더 지우거나 덜 지운다」. 지우는 범위는 **정의상**
      받은 범위와 같아야 한다.
    ⚠ **PK 로 지운다** — SQLite 는 DELETE 에 JOIN 을 못 쓴다. 그 SQL 로 PK 를
      먼저 뽑고 그 번호만 지운다(조건을 다시 적으면 두 벌이 된다).
    ⚠⚠ PK 도 UNIQUE 도 없으면 **`rowid`** 로 지운다 — 지우기는 **이 DB 안에서만**
      하는 일이라 그것으로 정확하다(붙이는 쪽 `db_pack_apply` 는 rowid 를 쓰면
      안 된다 — 그 번호는 DB 마다 다르다).
    ⚠ **내가 쓴 글은 안 건드린다** — `user_*` 표는 이 표에 없다.
    """
    import db_pack_apply as AP
    kind = (kind or '').upper()
    ps = parts_for(kind, key)
    if not ps:
        raise ValueError('지울 것을 모르는 갈래다: %s (PARTS 에 한 줄)' % kind)
    n = 0
    for tbl, sql, argf in ps:
        pkc = AP.pk_cols(conn, tbl) or ['rowid']
        args = argf(key, lang, variant)
        pick = ', '.join(('t.rowid' if c == 'rowid' and ' t' in sql else c)
                         for c in pkc)
        try:
            ids = [tuple(r) for r in conn.execute(
                "SELECT %s FROM (%s)" % (', '.join(pkc), sql), args)]
        except Exception:
            # ⚠ `SELECT t.*` 는 rowid 를 안 내보낸다 — 원 SQL 에 끼워 뽑는다
            ids = [tuple(r) for r in conn.execute(
                sql.replace('SELECT t.*', 'SELECT ' + pick, 1)
                   .replace('SELECT *', 'SELECT ' + pick, 1), args)]
        if not ids or dry:
            n += len(ids)
            continue
        where = ' AND '.join('%s=?' % c for c in pkc)
        conn.executemany("DELETE FROM %s WHERE %s" % (tbl, where), ids)
        n += len(ids)
    return n


def verify(conn, path):
    """만든 것이 DB 와 맞는가 → `[문제…]`.

    ★ **DB 를 직접 다시 센다** — 만들 때와 잴 때가 같은 코드면 시험이 헛돈다.
    """
    try:
        body = PK.read(path)
    except Exception as e:
        return ['팩을 읽을 수 없다: %s' % e]
    bad = []
    if int(body.get('format') or 0) != FORMAT:
        bad.append('형식 판이 다르다: %s' % body.get('format'))
    kind, key = body.get('kind'), body.get('key')
    lang, variant = body.get('lang'), body.get('variant')
    ps = {t: (sql, argf) for t, sql, argf in parts_for(kind, key)}
    for t, d in (body.get('tables') or {}).items():
        if t not in ps:
            bad.append('담기면 안 되는 표: %s' % t)
            continue
        sql, argf = ps[t]
        try:
            n = conn.execute(
                'SELECT COUNT(*) FROM (%s)' % sql,
                argf(key, lang, variant)).fetchone()[0]
        except Exception:
            continue
        if n != len(d.get('rows') or []):
            bad.append('행수가 다르다 %s: 팩 %d ≠ DB %d'
                       % (t, len(d.get('rows') or []), n))
    for t in ps:
        if t not in (body.get('tables') or {}):
            bad.append('빠진 표: %s' % t)
    return bad


def estimate(conn, kind, key='-', lang='-', variant='-'):
    """만들기 전에 **크기를 짐작한다** → (행수, 글자수).

    ⚠ 스펄전 설교 한 권이 124MB 다 — 누르기 전에 알아야 한다.
    ★★ **세는 일을 SQL 에 맡긴다**(286차) — 그전에는 본문 행을 전부 파이썬으로
      끌어와 재어 자산 하나에 **87ms**, 도서 갈래 한 번에 **10초**가 걸렸다.
      배포 관리 화면이 늦던 까닭의 절반이 이것이다.
    ⚠ 잣대는 `db_pack_catalog.core_bytes` 와 **같은 글자 수**다(`LENGTH`).
      둘을 더해 「나갈 크기」를 내므로 잣대가 달라지면 안 된다.
    ⚠ SQL 로 못 재면 **옛 방식으로 물러선다** — 조용히 0 을 내지 않는다.
    """
    ps = parts_for(kind, key)
    rows = chars = 0
    for table, sql, argf in ps:
        a = None
        try:
            a = argf(key, lang, variant)
            cur = conn.execute('SELECT * FROM (%s) LIMIT 0' % sql, a)
            cols = [d[0] for d in cur.description]
            expr = '+'.join(
                "LENGTH(COALESCE(CAST(\"%s\" AS TEXT),''))" % c
                for c in cols) or '0'
            r = conn.execute(
                'SELECT COUNT(*), COALESCE(SUM(%s),0) FROM (%s) x'
                % (expr, sql), a).fetchone()
            rows += int(r[0] or 0)
            chars += int(r[1] or 0)
            continue
        except Exception:                                    # noqa: BLE001
            pass
        try:
            cur = conn.execute(sql, a if a is not None
                               else argf(key, lang, variant))
            for r in cur:
                rows += 1
                for v in r:
                    if isinstance(v, (str, bytes, bytearray)):
                        chars += len(v)
        except Exception:                                    # noqa: BLE001
            pass
    return rows, chars


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', name, extra))

    import tempfile
    d = tempfile.mkdtemp()
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE bible_content(verse_id INTEGER, version_code TEXT,
                                 verse_text TEXT);
      CREATE TABLE sys_book_asset(book_id INTEGER, book_code TEXT);
      CREATE TABLE sys_book_unit(unit_id INTEGER, book_id INTEGER);
      CREATE TABLE sys_book_unit_text(unit_id INTEGER, lang_code TEXT,
                                      text_variant TEXT, body_text TEXT);
      INSERT INTO bible_content VALUES(1,'KRV','태초에'),(2,'KRV','땅이'),
                                      (3,'BSB','In the beginning');
      INSERT INTO sys_book_asset VALUES(1,'BK');
      INSERT INTO sys_book_unit VALUES(10,1);
      INSERT INTO sys_book_unit_text VALUES(10,'KO','TRANSLATED','본문'),
                                           (10,'EN','ORIGINAL','text');
    """)
    c.commit()

    r = build(c, 'BIBLE', 'KRV', out_dir=d)
    body = PK.read(r['file'])
    t('★ 역본 팩이 만들어진다', r['rows'] == 2, '%d행' % r['rows'])
    t('★★ **그 역본만 담긴다**(다른 역본이 안 섞인다)',
      all(x[1] == 'KRV' for x in body['tables']['bible_content']['rows']))
    t('  형식이 코어팩과 같다',
      body.get('format') == FORMAT
      and set(body['tables']['bible_content']) == {'cols', 'rows'})
    t('  팩에 무엇인지 적혀 있다',
      body.get('kind') == 'BIBLE' and body.get('key') == 'KRV')
    t('★ 검증이 통과한다', not verify(c, r['file']), str(verify(c, r['file'])))

    r2 = build(c, 'BOOK', 'BK', 'KO', 'TRANSLATED', out_dir=d)
    t('★★ **책·언어·변형이 정확히 갈린다**', r2['rows'] == 1, '%d행' % r2['rows'])
    t('  다른 언어는 다른 팩',
      build(c, 'BOOK', 'BK', 'EN', 'ORIGINAL', out_dir=d)['rows'] == 1)
    t('  파일 이름이 자산을 말한다',
      'pack_BOOK_BK_KO_TRANSLATED' in os.path.basename(r2['file']),
      os.path.basename(r2['file']))

    # 거부해야 하는 것들
    for why, args in (('모르는 갈래', ('ZZZ', 'X')),
                      ('담을 것이 없는 자산', ('BIBLE', 'NOPE'))):
        try:
            build(c, *args, out_dir=d)
            got = False
        except ValueError:
            got = True
        t('★★ **%s는 거부한다**(빈 팩 금지)' % why, got)

    c.execute("INSERT INTO bible_content VALUES(4,'KRV','추가')")
    c.commit()
    t('★★ **DB 가 바뀌면 검증이 잡는다**',
      any('bible_content' in x for x in verify(c, r['file'])))

    n_rows, n_chars = estimate(c, 'BIBLE', 'KRV')
    t('★ 만들기 전에 크기를 짐작한다', n_rows == 3 and n_chars > 0,
      '%d행 %d자' % (n_rows, n_chars))

    t('  파일 이름이 안전하다',
      pack_name('BOOK', 'A/B C', 'KO') == 'pack_BOOK_A_B_C_KO_-.json.gz',
      pack_name('BOOK', 'A/B C', 'KO'))
    for f in os.listdir(d):
        os.remove(os.path.join(d, f))
    os.rmdir(d)
    # ── 지우기(용량 확보) — **받은 만큼만 지운다** ─────────────────
    n_all = c.execute("SELECT COUNT(*) FROM bible_content").fetchone()[0]
    n_pack = len(PK.read(build(c, 'BIBLE', 'KRV', out_dir=d)['file'])
                 ['tables']['bible_content']['rows'])
    n_dry = remove(c, 'BIBLE', 'KRV', dry=True)
    t('★★★ **지울 행 수 = 담을 행 수**(같은 SQL 을 쓰므로)',
      n_dry == n_pack, '지움 %d · 담음 %d' % (n_dry, n_pack))
    t('★ 지울 행 수를 미리 센다(dry)', n_dry > 0, '%d행' % n_dry)
    t('  dry 는 아무것도 안 지운다',
      c.execute("SELECT COUNT(*) FROM bible_content").fetchone()[0] == n_all)
    n_del = remove(c, 'BIBLE', 'KRV')
    left = c.execute("SELECT COUNT(*) FROM bible_content").fetchone()[0]
    t('★★ 실제로 그만큼 지워진다', n_del == n_dry and left == n_all - n_del,
      '%d행 지움 · %d행 남음' % (n_del, left))
    t('★★ **다른 자산은 안 건드린다**(BSB 가 남는다)',
      c.execute("SELECT COUNT(*) FROM bible_content"
                " WHERE version_code='BSB'").fetchone()[0] == 1)
    t('  다 지운 뒤 또 지워도 0행(멱등)',
      remove(c, 'BIBLE', 'KRV') == 0)
    n_v = remove(c, 'BOOK', 'BK', 'KO', 'TRANSLATED')
    t('★★ **변형까지 가려 지운다**(같은 책 EN 은 남는다)',
      n_v == 1 and c.execute(
          "SELECT COUNT(*) FROM sys_book_unit_text").fetchone()[0] == 1,
      '%d행' % n_v)
    try:
        remove(c, 'ZZZ', 'x')
        t('  모르는 갈래는 거부한다', False)
    except ValueError:
        t('★ **모르는 갈래는 거부한다**(조용히 0행 아님)', True)

    c.close()

    # ── 실 DB — 읽기만 한다 ──────────────────────────────────────────────
    c2 = appdb.connect(DB)
    try:
        import db_pack_item as PI
        kinds = {g[0] for g in PI.discover(c2)} - {'CORE'}
        # ★★ **모든 본문 갈래에 빌더가 있다** — 안 그러면 화면에서 회색으로 남는다
        miss = [k for k in kinds if not PARTS.get(k) and k != 'LEX']
        t('★★★ **모든 본문 갈래에 담을 조회가 있다**', not miss, str(miss))
        rows, chars = estimate(c2, 'BIBLE', 'KRV')
        t('  실 DB 역본 크기가 재어진다', rows > 30000,
          '%s절 %.1f MB' % (f'{rows:,}', chars / 1048576))
        rows2, chars2 = estimate(c2, 'BOOK', 'SPURGEON_SERMONS', 'EN',
                                 'ORIGINAL')
        t('★ 큰 책을 미리 잰다(누르기 전에 안다)', chars2 > 50 * 1048576,
          '%s편 %.0f MB' % (f'{rows2:,}', chars2 / 1048576))
        # ★ 설명문은 **성경책 묶음** 단위다(286차) — 66권 × 11언어 = 726 팩을
        #   여덟 묶음 × 언어로 줄였다.
        rows3, _c3 = estimate(c2, 'DESC', 'PENT', 'KO')
        t('  설명문이 **묶음 단위**로 재어진다', rows3 > 0, '%s편' % f'{rows3:,}')
        rows4, _c4 = estimate(c2, 'DESC', 'GOSP', 'KO')
        t('    묶음마다 다른 범위를 잰다', rows4 > 0 and rows4 != rows3,
          '오경 %s ↔ 복음서 %s' % (f'{rows3:,}', f'{rows4:,}'))
        t('    모르는 묶음은 온 성경(조용히 0 을 내지 않는다)',
          group_range('NOPE') == (1, 66))
    finally:
        c2.close()
    print('db_pack_body selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--build', nargs='+', metavar='ARG')
    ap.add_argument('--size', nargs='+', metavar='ARG')
    a = ap.parse_args()
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', write_through=True)
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect(DB)
    try:
        if a.size:
            g = list(a.size) + ['-'] * 4
            rows, chars = estimate(c, g[0], g[1], g[2], g[3])
            print('%s %s %s %s — %s행 · %.2f MB(글자)'
                  % (g[0], g[1], g[2], g[3], f'{rows:,}', chars / 1048576))
        if a.build:
            g = list(a.build) + ['-'] * 4
            r = build(c, g[0], g[1], g[2], g[3])
            print('만듦: %s' % r['file'])
            print('  %s행 · 원본 %.2f MB → gzip %.2f MB'
                  % (f"{r['rows']:,}", r['raw'] / 1048576,
                     r['bytes'] / 1048576))
            bad = verify(c, r['file'])
            print('  검증: %s' % ('문제 없음' if not bad else bad[:3]))
    finally:
        c.close()


if __name__ == '__main__':
    main()
