# -*- coding: utf-8 -*-
"""책 읽는 화면 한 벌 (2026-08-14 신설 · font.md §22 2단계).

무엇을 푸나 — 실측한 문제 넷
    묵상플랜은 한 절마다 `Frame → Frame → Label` 을 쌓는다. 한 절에 위젯 6~8개,
    **색 다섯 겹**(`#1C2833 → #212F3D → #1A2035 → #243342 → #154360`),
    폭 세 가지(460·500·520px)가 박혀 있고 전체가 `Canvas` 위에 얹혀 있다.
      ① 눈이 글자가 아니라 **상자 경계**를 먼저 본다 — 책에는 상자가 없다.
      ② 절마다 배경이 끊겨 **목록으로 읽힌다**.
      ③ `wraplength` 가 박혀 있어 **창을 넓혀도 줄이 안 늘어난다.**
      ④ `Canvas` 스크롤이라 휠·키보드·복사·검색이 전부 안 된다.

이 화면이 하는 것
    **`Text` 한 덩어리**로 그린다. 구분은 색 상자가 아니라 **여백과 글자색**이다.
    휠·키보드·복사·검색은 `Text` 가 공짜로 해 준다.

⚠ **기능을 덜어내지 않는다** (사용자 지시). 절 약명은 여전히 눌러서 P2·엔티티로
  간다 — 다만 버튼이 아니라 **눌리는 글자**다. 밑줄과 색으로 눌리는 것임을 보이고,
  마우스를 올리면 바뀐다.

⚠ **폰트는 `theme_font` 역할을 그대로 쓴다** — 새 체계를 만들지 않는다.
  성경 구절은 `bible`, 설명·해설은 `prose`, 곁들이는 글은 `meta`.
"""

import tkinter as tk
from tkinter import ttk

import theme_font

try:
    import bidi
except Exception:                                   # 단독 실행 대비
    bidi = None


def enable_copy(txt):
    """읽기 전용 Text 에서 **드래그 선택 + Ctrl+C 복사**를 보장한다.

    ⚠ disabled Text 는 클릭해도 포커스를 못 받아 Ctrl+C 가 조용히 죽는다
      (2026-08-17 사용자 「각종 설명문 공간은 복사가 안 된다」 — P1 본문
      `verse_text_list` 에서 겪은 것과 같은 계열). 포커스와 복사 바인딩을 직접 건다.
      설명문을 보이는 Text 를 새로 만들면 이 함수를 한 번 불러 준다.
    """
    def _focus(_e):
        try:
            txt.focus_set()
        except Exception:
            pass
    def _copy(_e=None):
        try:
            s = txt.get('sel.first', 'sel.last')
        except Exception:
            return 'break'
        try:
            txt.clipboard_clear()
            txt.clipboard_append(s)
        except Exception:
            pass
        return 'break'
    txt.bind('<Button-1>', _focus, add='+')
    for seq in ('<Control-c>', '<Control-C>', '<Control-Insert>'):
        txt.bind(seq, _copy)


class ReadingPane(ttk.Frame):
    """읽기 전용 본문 칸. 화면은 `add_*` 만 부르고 서식은 여기가 정한다."""

    def __init__(self, parent, db_path, on_ref_click=None, **kw):
        super().__init__(parent, **kw)
        self.db_path = db_path
        self.on_ref_click = on_ref_click
        self._refs = {}                 # 태그 이름 → 그 약명이 가리키는 것
        self._seq = 0

        vsb = ttk.Scrollbar(self, orient='vertical')
        vsb.pack(side='right', fill='y')
        self.text = tk.Text(self, wrap='word', relief='flat', bd=0,
                            cursor='arrow', insertwidth=0,
                            yscrollcommand=vsb.set, state='disabled')
        vsb.config(command=self.text.yview)
        self.text.pack(side='left', fill='both', expand=True)

        # ⚠ 읽는 폭은 **창이 바뀔 때마다** 다시 잰다 — 창을 넓히면 좌우 여백이 늘고
        #   글줄은 그대로 있어야 「책」이 된다.
        self.text.bind('<Configure>', lambda e: self._fit_width())
        theme_font.register(self.text, db_path, 'prose')
        enable_copy(self.text)          # 드래그 선택 + Ctrl+C (2026-08-17)
        self._styles()

    # ── 서식 ────────────────────────────────────────────────────────────────
    def _styles(self):
        """태그 = 서식. **색 상자를 쓰지 않는다** — 여백과 글자색으로 가른다.

        ★ **구절은 「성경」, 설명문은 「문장」을 그대로 따른다** (2026-08-14 사용자 질문
          「제대로 분리할 것인가, 할 수 있는가?」에 대한 답 — 분리한다).
          ⚠ 전에는 설명문을 「문장 크기 − 1」로 만들었다. 역할을 따르는 척하면서
            실제로는 **내 임의값**이라, 통합 폰트에서 「문장」을 키워도 어중간했다.
            임의 보정을 없앤다 — 크기를 달리하고 싶으면 통합 폰트에서 정한다.
        """
        d = theme_font.resolve(self.db_path, 'prose')     # 문장
        b = theme_font.resolve(self.db_path, 'bible')     # 성경
        fam, size = d['family'], int(d['size'])

        # ★ **왼쪽 시작선을 하나로 맞춘다** (사용자 지시). 구절과 설명문이
        #   같은 선에서 시작해야 읽는 흐름이 끊기지 않는다.
        self._indent = ind = int(b.get('first_indent') or 0)

        self.text.tag_configure('h1', font=(fam, size + 3, 'bold'),
                                lmargin1=ind, lmargin2=ind,
                                spacing1=18, spacing3=8)
        # ⚠ 제목 **뒤**(spacing3)를 벌리지 않으면 바로 아래 구절이 달라붙는다
        #   (2026-08-14 사용자 지적 「단락 구분이 전혀 없어서 달라붙어 있다」).
        # ★ **배수·바닥값 금지** (2026-08-17 사용자 — 「사전 세팅값이 서식 차원에서
        #   정해진 것이 없었으면 좋겠다」 + 「Font 로 조절하면 간격이 너무 커진다」).
        #   예전 `max(4, …) * 3` 은 통합 폰트의 문단간격을 **세 배로 뻥튀기**해서,
        #   Font 에서 6 으로 올리면 18px 이 됐다. 이제 저장값 그대로 1:1 이다 —
        #   0 으로 내리면 P2 구절설명처럼 아무 간격도 없다.
        _pg = int(d.get('para_gap') or 0)
        self.text.tag_configure('h2', font=(fam, size + 1, 'bold'),
                                lmargin1=ind, lmargin2=ind,
                                spacing1=_pg, spacing3=_pg)
        # 설명문 — 「문장」 역할 **그대로**.
        # ⚠ 설명문은 **위쪽**을 크게 벌린다 — 구절 묶음과 설명문 사이가 갈려야 한다
        # ⚠ **`spacing1` 만으로는 부족했다** — 앞 줄(구절)의 `spacing3` 가 0 이면
        #   Tk 는 둘을 더하지 않고 그냥 붙인다. 그래서 「아직도 간격이 없다」가 났다
        #   (2026-08-14 사용자 재지적). 화면 쪽에서 **빈 줄 하나**를 넣어 확실히 가른다.
        # ★ **블록 인용 방식** (2026-08-17 사용자 확정 — 2차에서 **반전**).
        #   「구절본문이 단락을 나누는 의미가 있으므로 배경색이 진하고, 설명문은
        #    아무런 배경색 없이 인덴트만」 — 옅은 바탕은 **구절**(verse) 쪽이고
        #   딸림글은 한 단 안쪽(+20px)일 뿐 바탕이 없다. 태그라 리사이즈 완전 연동.
        self.text.tag_configure(
            'aside', font=(fam, size), lmargin1=ind + 20, lmargin2=ind + 20,
            rmargin=8,
            spacing1=_pg, spacing2=int(d.get('line_gap') or 0),
            spacing3=0)
        # 성경 본문 — 「성경」 역할. **이어지는 줄은 약명 폭만큼 들여쓴다.**
        # ⚠ `lmargin2` 를 약명 폭에 맞추지 않으면 둘째 줄이 **약명 한가운데서**
        #   시작한다(사용자 지적). 그래서 실제 글꼴로 약명 폭을 잰다.
        # ⚠ **spacing3 금지 — 여기도** (2026-08-17 전수 조사에서 잡힌 마지막 이탈).
        #   위(spacing1)+아래(spacing3)를 둘 다 걸면 절 사이가 문단간격의 **두 배**
        #   (12px)가 되어 P1 성경 본문(6px)과 어긋났다. 문단간격은 1:1, 위에만.
        self.text.tag_configure(
            'verse', font=(b['family'], int(b['size'])),
            lmargin1=ind, lmargin2=ind + self._ref_w(),
            spacing1=int(b.get('para_gap') or 0),
            spacing2=int(b.get('line_gap') or 0),
            spacing3=0)
        # 도서·설교 본문 — 「문장」 역할, 문단 첫 줄만 들여쓴다
        self.text.tag_configure(
            'book', font=(fam, size), lmargin1=ind, lmargin2=ind,
            spacing1=int(d.get('para_gap') or 0),
            spacing2=int(d.get('line_gap') or 0), spacing3=0)
        # ★ 운문(시·인용시) — **한 단 더 안쪽** (2026-08-28 사용자 지시
        #   「시, 인용구절 인덴트를 넣어서 본문과 구별 가능하도록」).
        #   ⚠ 글자에 공백을 넣지 않는다 — `lmargin2` 로 **접힌 둘째 줄까지**
        #     들여쓴다. 공백을 넣으면 접힌 줄이 왼쪽으로 튀어나오고, 밑줄·메모의
        #     닻(고른 글 자체)과 검색·복사에 군더더기가 섞인다.
        #   ⚠ 갈래 판정은 `book_blocks` 한 곳이 한다 — 화면마다 다시 짜지 않는다.
        self.text.tag_configure(
            'poem', font=(fam, size), lmargin1=ind + 28, lmargin2=ind + 28,
            spacing1=int(d.get('line_gap') or 0), spacing2=0, spacing3=0)
        # ★ 절 약명 — **눌리는 글자**. 버튼이 아니지만 눌리는 것이 보여야 한다.
        self.text.tag_configure('ref', font=(b['family'], int(b['size']), 'bold'),
                                underline=True)
        self.text.tag_configure('refhot', underline=True)
        # ★ **빈 줄은 순수한 빈 줄** (2026-08-17 사용자 「문단간격 여전히 그대로다」
        #   실측으로 잡음). `theme_font.register` 가 위젯 전체에 spacing1/3=문단간격을
        #   깔아서 **빈 줄마다 12px 이 몰래 얹혀** 이중 엔터처럼 보였다 — 데이터가
        #   아니라 여기였다. gap 태그가 그 여백을 0 으로 되돌린다.
        self.text.tag_configure('gap', spacing1=0, spacing2=0, spacing3=0)
        # ⚠ **선택 하이라이트('sel')를 맨 위로** — 우리 태그가 나중에 생겨 우선순위가
        #   높아지면 verse 바탕이 선택 표시를 덮어 **드래그해도 안 보인다**
        #   (2026-08-17 사용자 「구절본문이 복사되지 않는다」의 정체 — 복사 기능이
        #   아니라 선택이 안 보이는 것. P1 verse_text_list 의 'sel' 함정과 같은 계열).
        self.text.tag_raise('sel')
        self._paint()

    def _ref_w(self):
        """절 약명이 차지하는 폭(px). **이어지는 줄을 여기에 맞춘다.**

        ⚠ 고정값을 쓰면 글꼴·크기를 바꿀 때마다 어긋난다 — 실제 글꼴로 잰다.
          `창 11:10` 처럼 가장 긴 형태를 기준 삼고 뒤 공백 두 칸을 더한다.
        """
        try:
            import tkinter.font as tkfont
            b = theme_font.resolve(self.db_path, 'bible')
            f = tkfont.Font(self.text, font=(b['family'], int(b['size']), 'bold'))
            return f.measure('창 11:10') + f.measure('  ')
        except Exception:
            return 62

    def _paint(self):
        """색은 테마에서 가져온다 — 하드코딩하지 않는다."""
        try:
            import ui_theme
            self.text.config(bg=ui_theme.C('bg'), fg=ui_theme.C('fg'))
            self.text.tag_configure('h1', foreground=ui_theme.C('fg_title'))
            self.text.tag_configure('h2', foreground=ui_theme.C('fg_title'))
            # ★ 설명문 색 — 통합 폰트에서 고른 것이 있으면 그것을, 없으면 테마 색
            #   (2026-08-14 사용자 지시 「글자 색상/크기 모두 표준화 기준을 따르자」).
            #   ⚠ 예전에는 무조건 `fg_dim`(흐린 색)이라 **통합 폰트에서 무엇을 골라도
            #     안 먹었다.**
            _d = theme_font.resolve(self.db_path, 'prose')
            _b = theme_font.resolve(self.db_path, 'bible')
            # 구절 바탕 — 테마의 바탕·글자색을 94:6 으로 섞어 **계산**한다.
            #   박아 둔 색이 아니라 어떤 테마에서도 은은하게 따라온다
            #   (highlight_notes 가 화면색에서 색을 계산하는 방식과 같다).
            #   ⚠ 딸림글(aside)에는 바탕을 깔지 않는다 — 2026-08-17 사용자 반전 지시.
            self.text.tag_configure(
                'aside', foreground=_d.get('color') or ui_theme.C('fg'),
                background='')
            self.text.tag_configure(
                'book', foreground=_d.get('color') or ui_theme.C('fg'))
            self.text.tag_configure(
                'verse', foreground=_b.get('color') or ui_theme.C('fg'),
                background=self._mix(ui_theme.C('bg'), ui_theme.C('fg'), 0.06))
            self.text.tag_configure('ref', foreground=ui_theme.C('accent'))
            self.text.tag_configure('refhot', foreground=ui_theme.C('danger'))
        except Exception:
            pass

    def _mix(self, base, ink, t=0.06):
        """`base` 색에 `ink` 색을 비율 `t` 만큼 섞는다 — 딸림글의 옅은 바탕용."""
        try:
            br, bg_, bb = [x // 256 for x in self.text.winfo_rgb(base)]
            ir, ig, ib = [x // 256 for x in self.text.winfo_rgb(ink)]
            return '#%02x%02x%02x' % (round(br + (ir - br) * t),
                                      round(bg_ + (ig - bg_) * t),
                                      round(bb + (ib - bb) * t))
        except Exception:
            return base

    def _fit_width(self):
        """읽는 폭을 지킨다 — 넓은 창에서는 **좌우 여백**이 늘어난다.

        ⚠ 한 줄이 너무 길면 다음 줄 첫머리를 놓친다. 책이 여백을 두는 이유다.
          `read_width` 가 0 이면 지금까지처럼 창 전체를 쓴다.
        """
        try:
            d = theme_font.resolve(self.db_path, 'prose')
            cols = int(d.get('read_width') or 0)
            if cols <= 0:
                return
            import tkinter.font as tkfont
            f = tkfont.Font(self.text, font=self.text.cget('font'))
            want = f.measure('가') * cols
            pad = max(int(d.get('margin') or 0), (self.text.winfo_width() - want) // 2)
            theme_font.set_if_changed(self.text, padx=pad)
        except Exception:
            pass

    def apply_font(self):
        """★ 설정이 바뀌면 **`theme_font.reapply_all` 이 저절로 부른다.**

        ⚠ 이름이 `apply_font` 여야 한다 — `_poke()` 가 그 이름을 찾는다.
          처음에 `refresh_style` 로 지었더니 **아무도 안 불러서** 통합 폰트 화면에서
          값을 바꿔도 이 화면만 그대로였다(2026-08-14 사용자 지적 ③⑤).
          서식이 **태그**에 들어 있으니 태그를 다시 잡지 않으면 아무 일도 안 일어난다.
        """
        self._styles()
        self._fit_width()

    # 옛 이름 — 부르던 곳이 있으면 그대로 통한다
    refresh_style = apply_font

    # ── 채우기 ──────────────────────────────────────────────────────────────
    def start(self):
        self.text.config(state='normal')
        self.text.delete('1.0', 'end')
        self._refs.clear()
        self._seq = 0

    def finish(self):
        self.text.config(state='disabled')
        self.text.yview_moveto(0)
        self._fit_width()

    def title(self, s, level=1):
        if s:
            self.text.insert('end', s + '\n', ('h1' if level == 1 else 'h2',))

    def aside(self, s):
        """묵상 포커스·단락설명처럼 **본문에 곁들이는 글** — 한 단 안쪽 + 옅은 바탕."""
        if s:
            self.text.insert('end', s + '\n', ('aside',))

    def body(self, s):
        """설명문 같은 **본문 문단** — 딸림글(aside)과 달리 바탕 없이 제 선에서
        시작한다 (2026-08-17 사용자 지시 「노드 설명문도 렌즈 설명문처럼 독립적
        구분」 — 렌즈 설명이 민바탕 본문으로 서듯 노드 설명도 그렇게)."""
        if s:
            self.text.insert('end', s + '\n', ('book',))

    def book_text(self, s):
        """도서 본문 — **운문은 한 단 안쪽으로** 그린다 (2026-08-28).

        `body()` 와 달리 글을 덩어리로 갈라 넣는다. 글자는 그대로이고
        여백만 다르다(`book_blocks` 가 갈래를 정한다).
        """
        if not s:
            return
        try:
            import book_blocks
            parts = book_blocks.blocks(s)
        except Exception:
            parts = [('body', s)]
        for kind, chunk in parts:
            if chunk == '' and kind == 'body':
                continue
            self.text.insert('end', chunk + '\n',
                             ('poem' if kind == 'poem' else 'book',))

    def gap(self, n=1):
        self.text.insert('end', '\n' * n, ('gap',))

    def verse(self, ref, body, payload=None):
        """성경 한 절 — `약명`(눌림) + 본문.

        ⚠ 약명을 지우지 않는다. **버튼이 아니라 눌리는 글자**로 바꿀 뿐이고,
          누르면 화면이 준 `payload` 를 그대로 돌려준다(사용자 지시:
          「클릭하면 p2탭, 엔티티 등으로 연결되기만 하면 문제 없다」).
        """
        if ref:
            self._seq += 1
            tag = f'r{self._seq}'
            self._refs[tag] = payload
            # ⚠ 약명에도 'verse' 태그를 함께 — 구절 바탕 띠가 약명 자리에서
            #   끊기지 않게 한다('ref' 는 바탕을 정의하지 않아 verse 것이 비친다).
            self.text.insert('end', ref, ('verse', 'ref', tag))
            self.text.insert('end', '  ', ('verse',))
            self.text.tag_bind(tag, '<Button-1>',
                               lambda e, t=tag: self._hit(t))
            self.text.tag_bind(tag, '<Enter>',
                               lambda e, t=tag: self._hot(t, True))
            self.text.tag_bind(tag, '<Leave>',
                               lambda e, t=tag: self._hot(t, False))
        s = body or ''
        if bidi is not None:
            bidi.insert(self.text, s + '\n', ('verse',))
        else:
            self.text.insert('end', s + '\n', ('verse',))

    def widget(self, make, pad=(0, 4)):
        """본문 흐름 안에 **살아 있는 위젯**을 끼운다 (라디오·버튼 등).

        ★ 이것이 있어서 「Text 로 바꾸면 기능을 잃는다」가 성립하지 않는다
          (사용자 지시: 「기능적인 부분을 제거하지 않고 수정하되」).
          `make(parent)` 가 위젯을 만들어 돌려주면 그 자리에 심는다.
        """
        try:
            holder = tk.Frame(self.text, bg=self.text.cget('bg'))
            w = make(holder)
            if w is not None:
                w.pack(side='left')
            self.text.insert('end', '\n' * (1 if pad[0] else 0), ('gap',))
            self.text.window_create('end', window=holder, padx=2)
            self.text.insert('end', '\n' * (1 if pad[1] else 0), ('gap',))
            return holder
        except Exception:
            return None

    def _hot(self, tag, on):
        try:
            self.text.config(cursor='hand2' if on else 'arrow')
            self.text.tag_configure(tag, foreground=(
                self.text.tag_cget('refhot', 'foreground') if on
                else self.text.tag_cget('ref', 'foreground')))
        except Exception:
            pass

    def _hit(self, tag):
        if callable(self.on_ref_click):
            try:
                self.on_ref_click(self._refs.get(tag))
            except Exception:
                pass


def _selftest():
    """Tk 를 띄우지 않고 **서식 규칙**만 본다."""
    bad = []
    import inspect
    src = inspect.getsource(ReadingPane)

    # ① 색을 박아 두지 않는다 — 테마에서 가져와야 한다
    import re
    hard = re.findall(r"(?:bg|fg|foreground|background)\s*=\s*'(#[0-9A-Fa-f]{3,6})'", src)
    if hard:
        bad.append(f'색을 박아 두었다: {sorted(set(hard))}')

    # ② `wraplength` 를 쓰지 않는다 — 그것이 「창을 넓혀도 안 늘어남」의 원인이었다
    if 'wraplength' in src:
        bad.append('wraplength 를 쓰고 있다 — Text 는 창을 따라 늘어나야 한다')

    # ③ 약명은 눌려야 한다
    for need in ('tag_bind', '<Button-1>', 'on_ref_click'):
        if need not in src:
            bad.append(f'약명을 누를 수 없다: {need} 없음')

    # ④ 폰트는 역할을 쓴다
    for need in ("resolve(self.db_path, 'prose')", "resolve(self.db_path, 'bible')"):
        if need not in src:
            bad.append(f'폰트 역할을 안 쓴다: {need}')

    print('reading_pane selftest: ' + ('OK' if not bad else 'FAIL'))
    for b in bad:
        print('  X', b)
    return 1 if bad else 0


if __name__ == '__main__':
    import sys
    sys.exit(_selftest())
