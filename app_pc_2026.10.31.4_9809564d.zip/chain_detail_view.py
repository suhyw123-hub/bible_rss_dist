# -*- coding: utf-8 -*-
"""
chain_detail_view.py — P4 「구속사 연결 설명」 (2026-08-19 사용자 확정 설계).

구속사연결을 만든 진정한 목적 — **한 주제가 창세기에서 계시록까지 어떻게
발전하는가를 따라 읽는 것** — 을 이루는 화면. P4 가 좌우로 길어 이 구도가 산다:

  왼쪽  = 흐름 전체 목록 (책 이름 구분선 — 정경을 가로지르는 궤적이 보인다)
  오른쪽 = 마디 읽기 (체인 이름·위치·설명 / ◀▶ 마디 순회 / 단락 문맥(±5 확장,
          그 절 강조 — PericopeVerseView 재사용) / 연결설명문 두 방향 /
          [이 구절로 이동 → P1] / **이 주제로 하는 묵상** 안내 칩)

역할 분담(사용자 확정): P2·오른쪽 패널의 구속사연결 탭 = 설명문+약명 훑기,
여기 = 본문과 함께 읽는 화면. 내부자료(P2 목록 → P4 자료 탭)와 같은 문법이다.

진입: ① 구속사연결 탭 약명/[자세히 읽기] 클릭 → show(chain, vid)
     ② 탭을 직접 열면 체인 콤보에 전체 81개 — 구절 경유 없는 **브라우저**.
P1 이동은 [이 구절로 이동] 단추만 — 순회는 P1 을 절대 건드리지 않는다.

묵상 안내 = `sys_chain_route(chain_code → to_kind/to_id)` — 체인 주제와 닿는
렌즈·플랜으로 잇는다(2026-08-19 사용자 「연결된 묵상플랜으로 안내하는 장치」).
라벨·존재 게이트는 plan_route 의 것을 그대로 쓴다.
"""

import tkinter as tk
from tkinter import ttk
import i18n
# ★★ 구간 판정은 **한 문**이다(§verse_range) — `verse_id` 는 신원이고
#   차례는 `sort_order` 다. 번호로 재면 아6:1~6:14 가 13,488절을 먹는다.
import verse_range as _vr
import appdb
from p4_chain_slide import all_chains, chain_meta, chain_members


def _C(role, fallback):
    try:
        import ui_theme
        return ui_theme.C(role)
    except Exception:
        return fallback


class ChainDetailView(tk.Frame):

    def __init__(self, parent, db_path, ext_bar=None,
                 lang_getter=None, ver_getter=None,
                 on_verse_jump=None, on_route_jump=None, **kw):
        super().__init__(parent, bg=_C('bg', 'white'), **kw)
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.ver_getter = ver_getter or (lambda: 'KRV')
        self._ext_bar = ext_bar
        self.on_verse_jump = on_verse_jump      # P1 이동 (명시적 단추만)
        self.on_route_jump = on_route_jump      # 묵상 안내 칩 → user_main._route_jump
        self._chains = []                       # [(code, name)]
        self._code = None
        self._members = []                      # [(vid, ref, body, bcode)]
        self._links = []                        # [(ai, bi, desc)]
        self._idx = None                        # 현재 마디 색인
        self._build()

    # ── UI ──────────────────────────────────────────────────────────

    def _build(self):
        pw = tk.PanedWindow(self, orient='horizontal', sashwidth=5,
                            bg=_C('panel', '#F4F6F7'), bd=0)
        pw.pack(fill='both', expand=True)

        # ── 왼쪽: 체인 콤보 + 흐름 목록 ──
        left = tk.Frame(pw, bg=_C('bg', 'white'))
        pw.add(left, width=360, minsize=240)
        top = tk.Frame(left, bg=_C('panel', '#F4F6F7'))
        top.pack(fill='x')
        # ★ [전체보기] — 콤보는 가나다순 한 줄이라 전체 지형이 안 보인다
        #   (2026-08-19 사용자 — 「카테고리별로 한눈에 표시하는 화면도 필요하다」).
        tk.Button(top, text=i18n.t('CD_ALL', '전체보기'),
                  bd=1, padx=4, pady=0, cursor='hand2',
                  font=('Malgun Gothic', 8),
                  bg=_C('panel_alt', '#E5E8E8'), fg=_C('fg', '#333'),
                  command=self._open_overview).pack(side='right', padx=(2, 6), pady=5)
        self._combo = ttk.Combobox(top, state='readonly')
        self._combo.pack(fill='x', padx=(6, 0), pady=5)
        self._combo.bind('<<ComboboxSelected>>', self._on_combo)

        self._tv = ttk.Treeview(left, show='tree', selectmode='browse')
        try:
            import theme_font
            theme_font.list_style('ChainDet.Treeview', self.db_path)
            self._tv.configure(style='ChainDet.Treeview')
        except Exception:
            pass
        sb = ttk.Scrollbar(left, orient='vertical', command=self._tv.yview)
        self._tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._tv.pack(fill='both', expand=True)
        # 태그 색 표준(§트리 태그 색): 묶음(책) #1A5276 bold · 항목 기본색
        self._tv.tag_configure('book', foreground='#1A5276')
        self._tv.tag_configure('cur', background=_C('accent_bg', '#EAF2F8'))
        self._tv.bind('<<TreeviewSelect>>', self._on_pick)

        # ── 오른쪽: 마디 읽기 ──
        right = tk.Frame(pw, bg=_C('bg', 'white'))
        pw.add(right, minsize=380)

        # ── 단추 줄 (2026-09-03 0.txt 1번 사용자 확정 배치 —
        #    Focus·역본비교·말씀의 흐름 · (여백) 이전·다음·묵상노트·이 구절을…
        #    · (여백) 연결된 자산 보기·My Edit **한 줄**).
        #    ⚠ ext_bar(갈래 줄)를 받으면 거기 심고, 없으면 제 줄(호환).
        #    ⚠ 규격 = 도서/설교와 같은 flat_btn(사용자 지시 「같은 크기로」).
        try:
            import ui_theme as _ut
            _fk = _ut.flat_btn()
        except Exception:
            _fk = dict(bd=0, padx=8, cursor='hand2')
        if self._ext_bar is not None:
            btnrow = self._ext_bar
        else:
            btnrow = tk.Frame(right, bg=_C('panel', '#F4F6F7'))
            btnrow.pack(fill='x')
        self._prev_btn = tk.Button(btnrow, text=i18n.t('CD_PREV', '◀ 이전'),
                                   command=lambda: self._step(-1), **_fk)
        self._next_btn = tk.Button(btnrow, text=i18n.t('CD_NEXT', '다음 ▶'),
                                   command=lambda: self._step(+1), **_fk)
        # 이모지 제거 (0.txt 1번 「묵상노트 버튼 글자 왼쪽의 이모지 제거」)
        self._note_btn = tk.Button(btnrow, text=i18n.t('TAB_NOTE', '묵상노트'),
                                   command=self._toggle_notes, **_fk)
        self._goto_btn = tk.Button(
            btnrow, text=i18n.t('CD_GOTO', '이 구절을 중심으로 성경읽기'),
            command=self._goto_p1, **_fk)
        self._assets_btn = tk.Button(
            btnrow, text=i18n.t('PR_ASSETS_SHOW', '연결된 자산 보기') + ' (0)',
            command=self._toggle_assets, **_fk)
        self._me_btn = tk.Button(btnrow, text=i18n.t('OE_BTN', 'My Edit'),
                                 command=self._open_my_edit, **_fk)
        # (묶음, side, padx) — set_bar_visible 이 이 차례대로 편다
        # ★ 2026-09-16 · 1.txt 12번 사용자 차례 — 「(이전/다음 버튼 제거), 묵상노트,
        #   연결된 자산 보기, (공백), 이 구절 중심으로 성경읽기, (공백) My Edit」.
        #   이전·다음은 왼쪽 목록이 그 일을 한다(단추는 남겨 두고 줄에 안 편다).
        self._bar_widgets = [
            (self._me_btn, 'right', (2, 6)),
            (self._note_btn, 'left', (24, 2)),
            (self._assets_btn, 'left', (2, 2)),
            (self._goto_btn, 'left', (24, 2)),
        ]
        if self._ext_bar is None:
            self.set_bar_visible(True)

        # ── 체인 이름·위치 + 체인 전체 설명문 (항상 최상단 유지 — 사용자 확인) ──
        hd = tk.Frame(right, bg=_C('panel', '#F4F6F7'))
        hd.pack(fill='x')
        self._hd = hd
        # ── 연결된 자산 판 (도서/설교 모델 — asset_strip 공용 부품) ──
        try:
            from asset_strip import AssetStrip
            self._assets = AssetStrip(right, self.db_path,
                                      lang_getter=self.lang_getter,
                                      on_jump=self.on_asset_jump)
        except Exception as _e:
            print('[chain assets] %s' % _e)
            self._assets = None
        self._assets_on = False
        self._name_lbl = tk.Label(hd, text='', bg=_C('panel', '#F4F6F7'),
                                  fg=_C('fg_title', '#1A5276'), anchor='w',
                                  padx=10, pady=2)
        self._name_lbl.pack(side='left', fill='x', expand=True)
        # (2026-09-16 · 1.txt 12번) 제목 오른쪽의 약명 · 쪽 번호(3/4)는 **안 그린다** —
        #   왼쪽 목록이 그 자리를 이미 보여 준다. 라벨은 남겨 값만 받는다.
        self._pos_lbl = tk.Label(hd, text='', bg=_C('panel', '#F4F6F7'),
                                 fg=_C('fg_dim', '#666'), padx=10)
        # ★ 추천묵상 — 이름만, 상단에 미리 (2026-08-19 사용자 「연쇄묵상 끝나고
        #   추천할 묵상플랜을 상단에. 공간배치 잘」). 이름 줄 오른쪽 한 자리 —
        #   줄을 늘리지 않는다. 클릭 = 그 자산으로 점프(sys_chain_route).
        self._guide_lbl = tk.Label(hd, text='', bg=_C('panel', '#F4F6F7'),
                                   fg=_C('accent', '#1F618D'), padx=8,
                                   cursor='hand2')

        self._desc_lbl = tk.Label(right, text='', bg=_C('bg', 'white'),
                                  fg=_C('fg_dim', '#666'), anchor='w',
                                  justify='left', padx=10, pady=4,
                                  wraplength=600)
        self._desc_lbl.pack(fill='x')

        # ⚠ 줄바꿈 폭은 **부모(right) 폭**에서 받고, 값이 실제로 달라졌을 때만
        #   바꾼다 — 라벨 자신의 <Configure> 안에서 wraplength 를 바꾸면
        #   요청 크기가 다시 바뀌어 리사이즈가 무한 반복된다(실측 — 이벤트
        #   루프가 그대로 멈췄다).
        def _wrap_sync(e):
            w = max(200, e.width - 24)
            try:
                if abs(int(self._desc_lbl.cget('wraplength')) - w) > 8:
                    self._desc_lbl.config(wraplength=w)
            except Exception:
                pass
        right.bind('<Configure>', _wrap_sync, add='+')

        # ★ 배치 = 본문 → 구절 설명문 → 묵상노트 (2026-08-19 사용자 확정).
        #   본문은 **내용만큼만** 높이를 차지한다(autosize — 초기값은 핵심
        #   구절만, ±5 를 누르면 그만큼 자동으로 늘고 줄어 아래 공간이 따라
        #   조절된다). 설명문/노트 사이에는 사시(리사이즈).
        from pericope_verse_view import PericopeVerseView
        self._peri = PericopeVerseView(right, self.db_path,
                                       lang_getter=self.lang_getter,
                                       ver_getter=self.ver_getter,
                                       autosize=True)
        self._peri.pack(fill='x')

        vpw = tk.PanedWindow(right, orient='vertical', sashwidth=5,
                             bg=_C('panel', '#F4F6F7'), bd=0)
        vpw.pack(fill='both', expand=True)

        # 가운데 칸: **구절 설명문**(VERS_DESC — P2 설명 탭과 같은 자산의 일반
        # 설명. 2026-08-19 사용자 「마디 핵심 구절의 설명문도 사라졌다」)
        descf = tk.Frame(vpw, bg=_C('bg', 'white'))
        vpw.add(descf, minsize=80, stretch='always')
        dsb = ttk.Scrollbar(descf, orient='vertical')
        self._vdesc_txt = tk.Text(descf, wrap='word', bd=0,
                                  state='disabled', cursor='arrow',
                                  bg=_C('bg', 'white'), padx=10, pady=6,
                                  yscrollcommand=dsb.set)
        dsb.config(command=self._vdesc_txt.yview)
        dsb.pack(side='right', fill='y')
        self._vdesc_txt.pack(fill='both', expand=True)

        # 아래 칸: **묵상노트** (연결설명문은 이 화면에 절대 표시하지 않는다 —
        # 사용자 확정). 이 마디의 구절을 닻으로 커버하는 노트 목록 — P2
        # 묵상노트와 같은 저장소·같은 조회라 어느 쪽에서 써도 양쪽에 보인다.
        self._bottom = tk.Frame(vpw, bg=_C('bg', 'white'))
        self._vpw = vpw
        # ★ 기본 접힘 (2026-09-03 0.txt 1번 — 「입력화면이 항상 노출되어
        #   자리를 차지함 : 묵상노트 버튼 누를 때에만 표시」). 노트가 있어도
        #   목록·쓰기 띠는 단추가 열고, 개수는 단추 글자가 말한다.
        self._notes_on = False
        lsb = ttk.Scrollbar(self._bottom, orient='vertical')
        self._notes_txt = tk.Text(self._bottom, wrap='word', bd=0,
                                  state='disabled', cursor='arrow',
                                  bg=_C('bg', 'white'), padx=10, pady=6,
                                  yscrollcommand=lsb.set)
        lsb.config(command=self._notes_txt.yview)
        lsb.pack(side='right', fill='y')
        self._notes_txt.pack(fill='both', expand=True)
        self._note_bar = None            # 열려 있는 쓰기 띠 (NoteBar)
        try:
            import theme_font
            theme_font.register(self._notes_txt, self.db_path, 'prose')
            theme_font.register(self._vdesc_txt, self.db_path, 'prose')
            theme_font.register(self._name_lbl, self.db_path, 'ui')
            theme_font.register(self._desc_lbl, self.db_path, 'meta')
        except Exception:
            pass

    def _retag(self):
        for t in (self._notes_txt, self._vdesc_txt):
            t.tag_configure('meta', foreground=_C('fg_dim', '#888'), spacing1=6)
            t.tag_configure('d', foreground=_C('fg', '#333'),
                            lmargin1=14, lmargin2=14)
            t.tag_configure('empty', foreground=_C('fg_dim', '#999'), spacing1=10)
        self._notes_txt.tag_configure('edit', foreground=_C('accent', '#1F618D'),
                                      underline=True)

    # ── 외부 API ────────────────────────────────────────────────────

    def show(self, chain_code=None, vid=None):
        """체인+마디로 열기. 코드가 없으면 브라우저(첫/직전 체인)."""
        lang = self.lang_getter() or 'KO'
        self._chains = all_chains(self.db_path, lang)
        self._combo['values'] = [n for _c, n in self._chains]
        if not self._chains:
            return
        codes = [c for c, _n in self._chains]
        if chain_code not in codes:
            chain_code = self._code if self._code in codes else codes[0]
        self._combo.current(codes.index(chain_code))
        self._load_chain(chain_code, vid)

    # ── 전체보기 — 카테고리별 한눈 화면 (2026-08-19 사용자 지시) ──────

    _GROUPS = (('PRG',   'CD_G_PRG', '주제의 진행'),
               ('INC',   'CD_G_INC', '그리스도의 성취'),
               ('REV',   'CD_G_REV', '역전'),
               ('DEP',   'CD_G_DEP', '가르침의 심화'),
               ('CHAIN', 'CD_G_ETC', '창조와 완성'))

    def _open_overview(self):
        """「말씀의 흐름」 전체보기 — **상단 = 카테고리 버튼(2단), 아래 = 흐름
        제목 한 줄 세로 목록**(2026-08-19 사용자 — 「매트릭스는 좌우를 왔다갔다
        정신없다. 한 줄로 아래로 늘어뜨려라. 화면 오른쪽에, 폭은 절반으로.
        간격은 묵상플랜 왼쪽 트리 수준」). 제목 클릭 = 뒤 화면에서 열린다."""
        old = getattr(self, '_ov_win', None)
        if old is not None and old.winfo_exists():
            old.lift(); return
        lang = self.lang_getter() or 'KO'
        chains = all_chains(self.db_path, lang)          # 이미 가나다순
        counts = {}                     # 마디 수 — 행마다 물으면 81번 질의가 된다
        try:
            import appdb
            with appdb.connect(self.db_path) as c:
                for cc, a, b in c.execute(
                        "SELECT chain_code, clicked_id, target_id"
                        "  FROM sys_link_asset WHERE link_type='VERS_VERS'"
                        "   AND chain_code IS NOT NULL"
                        "   AND COALESCE(record_status,'LIVE')='LIVE'"):
                    counts.setdefault(cc, set()).update((a, b))
        except Exception:
            pass

        def _grp_of(code):
            head = code.split('-')[0].split('_')[0]
            return head if head in ('PRG', 'INC', 'REV', 'DEP') else 'CHAIN'
        by = {}
        for code, name in chains:
            by.setdefault(_grp_of(code), []).append((code, name))

        win = tk.Toplevel(self)
        self._ov_win = win
        win.title(i18n.t('CD_ALL_TITLE', '말씀의 흐름'))
        # 화면 오른쪽에 세로로 길게 (사용자 — 「오른쪽으로 배치, 아래로 길게,
        # 좌우 폭은 절반」)
        try:
            sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
            w, h = 520, max(600, sh - 120)
            win.geometry('%dx%d+%d+%d' % (w, h, sw - w - 12, 40))
        except Exception:
            win.geometry('520x820')
        try:
            import ui_theme
            ui_theme.adopt(win)
        except Exception:
            pass
        hdr = tk.Frame(win, bg=_C('panel', '#F4F6F7'))
        hdr.pack(fill='x')
        tk.Label(hdr, text=i18n.t('CD_ALL_TITLE', '말씀의 흐름'),
                 bg=_C('panel', '#F4F6F7'), fg=_C('fg_title', '#1A5276'),
                 font=('', 11, 'bold'), anchor='w', padx=10, pady=6
                 ).pack(side='left')
        # ⚠ 자체 ✕ 를 걷었다 (2026-09-03 0.txt 1번 — 창 장식의 X 와
        #   겹쳐 「x 버튼이 2개」였다). 닫기는 창 장식이 맡는다.

        # ── 상단: 카테고리 버튼 줄 (갈래 단추 표준 — 활성 dark_bg·비활성 panel_alt)
        catbar = tk.Frame(win, bg=_C('panel', '#F4F6F7'))
        catbar.pack(fill='x', padx=8, pady=(6, 2))
        self._ov_cat = getattr(self, '_ov_cat', 'ALL')
        cat_btns = {}
        cats = [('ALL', None, i18n.t('COMMON_ALL', '전체'), len(chains))]
        cats += [(g, k, i18n.t(k, d), len(by.get(g, ())))
                 for g, k, d in self._GROUPS if by.get(g)]

        # ── 아래: 흐름 제목 목록 — 간격은 플랜 트리 수준(목록 글꼴·행높이)
        try:
            import theme_font
            _lf = theme_font.resolve(self.db_path, 'list')
            list_font = (_lf.get('family') or '', int(_lf.get('size') or 11))
        except Exception:
            list_font = ('', 11)
        cv = tk.Canvas(win, bg=_C('bg', 'white'), highlightthickness=0)
        sb = ttk.Scrollbar(win, orient='vertical', command=cv.yview)
        cv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        cv.pack(fill='both', expand=True)
        body = tk.Frame(cv, bg=_C('bg', 'white'))
        _bwin = cv.create_window((0, 0), window=body, anchor='nw')
        cv.bind('<Configure>', lambda e: cv.itemconfigure(_bwin, width=e.width))
        body.bind('<Configure>',
                  lambda _e: cv.configure(scrollregion=cv.bbox('all')))
        cv.bind_all('<MouseWheel>',
                    lambda e: cv.yview_scroll(-1 * (e.delta // 120), 'units')
                    if win.winfo_exists() else None)
        win.bind('<Destroy>', lambda e: cv.unbind_all('<MouseWheel>')
                 if e.widget is win else None, add='+')

        def _fill(cat):
            self._ov_cat = cat
            for gk, b in cat_btns.items():
                on = (gk == cat)
                b.configure(bg=_C('dark_bg', '#2C4259') if on
                            else _C('panel_alt', '#E5E8E8'),
                            fg=_C('fg_on_dark', 'white') if on
                            else _C('fg', '#333'))
            for w in body.winfo_children():
                w.destroy()
            rows = (chains if cat == 'ALL' else by.get(cat, []))
            # ★ 한 줄 세로 목록 — 매트릭스 금지(사용자: 「좌우를 왔다갔다
            #   정신없다」). 가나다가 위에서 아래로 그대로 흐른다.
            for code, name in rows:
                lb = tk.Label(
                    body, text='%s (%d)' % (name, len(counts.get(code, ()))),
                    anchor='w', padx=10, pady=1, cursor='hand2',
                    font=list_font,
                    bg=_C('bg', 'white'), fg=_C('fg', '#333'))
                lb.pack(fill='x')
                lb.bind('<Button-1>', lambda _e, cc=code: self.show(cc))
                lb.bind('<Enter>', lambda _e, w=lb: w.configure(
                    bg=_C('accent_bg', '#EAF2F8')))
                lb.bind('<Leave>', lambda _e, w=lb: w.configure(
                    bg=_C('bg', 'white')))
            cv.yview_moveto(0)

        # 카테고리 버튼 — 폭이 절반이라 한 줄에 안 들어간다 → 3개씩 2단 grid
        for c in range(3):
            catbar.columnconfigure(c, weight=1, uniform='cat')
        for i, (gk, _key, label, n) in enumerate(cats):
            b = tk.Button(catbar, text='%s (%d)' % (label, n),
                          bd=0, padx=6, pady=3, cursor='hand2',
                          command=lambda g=gk: _fill(g))
            b.grid(row=i // 3, column=i % 3, sticky='ew', padx=2, pady=1)
            cat_btns[gk] = b
        _fill(self._ov_cat if self._ov_cat in cat_btns else 'ALL')
        win.transient(self.winfo_toplevel())

    # ── 내부 ────────────────────────────────────────────────────────

    def _on_combo(self, _e=None):
        i = self._combo.current()
        if 0 <= i < len(self._chains):
            self._load_chain(self._chains[i][0], None)

    # ── 구속사 단계 (2026-08-19 사용자 승인 — 「이 정도로 커버되면 그대로」) ──
    # 그룹 축 = 시간축 하나. 마디 표식(이모지류)은 넣지 않는다(사용자 지시).
    _STAGES = (('CD_ST_ORIGIN', '기원'), ('CD_ST_DEV', '전개'),
               ('CD_ST_PROPHECY', '예언'), ('CD_ST_FULFILL', '성취'),
               ('CD_ST_CHURCH', '확장'), ('CD_ST_CONSUM', '완성'))

    @staticmethod
    def _stage_of(i, bcode):
        """단계 판정 — 첫 마디 = 기원, 이후는 정경 구역."""
        if i == 0:
            return 0
        if bcode <= 22:      # 창~아가 (역사·시가)
            return 1
        if bcode <= 39:      # 사~말 (선지서)
            return 2
        if bcode <= 43:      # 마~요 (복음서)
            return 3
        if bcode <= 65:      # 행~유 (교회)
            return 4
        return 5             # 계시록

    def _load_chain(self, code, vid):
        lang = self.lang_getter() or 'KO'
        self._code = code
        try:
            members, links = chain_members(
                self.db_path, code, lang, self.ver_getter())
        except Exception:
            members, links = [], []
        # 흐름 연결(체인 내부 연결설명문 — 2026-08-19 사용자 승인 「접힘/펼침,
        # 이동은 불필요」)용 원자료: vid 쌍 + 글, 약명 사전.
        self._reflab = {m[0]: m[1] for m in members}
        self._vlinks = [(members[a][0], members[b][0], d)
                        for (a, b, d) in links if d]
        # ★ 정렬 = **정경 순서(verse_id)** — 링크 입력 순서 시퀀스는 허브형
        #   체인에서 창세기가 중간에 다시 나와 흐름 읽기를 해친다(실측).
        #   정경순이면 단계 그룹도 저절로 한 방향으로 흐른다.
        members = sorted(members, key=lambda m: m[0])
        # ★ 연속 절은 **한 마디로 병합** (2026-08-19 사용자 — 「여러 구절을 한
        #   마디로 취급한다면 왼쪽에서 창1:2~6 구간으로 표시하라」).
        groups = []
        for (mvid, ref, body, bc, ch, vs) in members:
            if groups and groups[-1]['bc'] == bc and mvid == groups[-1]['ev'] + 1:
                g = groups[-1]
                g['ev'], g['ech'], g['evs'] = mvid, ch, vs
            else:
                groups.append({'sv': mvid, 'ev': mvid, 'ref': ref, 'body': body,
                               'bc': bc, 'sch': ch, 'ech': ch, 'evs': vs})
        for g in groups:
            if g['ev'] != g['sv']:
                g['ref'] += ('~%d' % g['evs'] if g['ech'] == g['sch']
                             else '~%d:%d' % (g['ech'], g['evs']))
        # 마디 = (시작vid, 끝vid, 구간표기, 첫 절 본문, bcode)
        self._members = [(g['sv'], g['ev'], g['ref'], g['body'], g['bc'])
                         for g in groups]
        # 목록 — 구속사 단계 구분선 (기원→전개→예언→성취→확장→완성)
        # 태그 색은 **로드마다 그 시점 테마로** (2026-08-19 사용자 「단계
        # 구분값 색이 안 보인다 — 표준서식으로」. 하드코딩 #1A5276 은 검정
        # 테마에서 묻힌다).
        self._tv.tag_configure('book', foreground=_C('fg_title', '#1A5276'))
        self._tv.tag_configure('cur', background=_C('accent_bg', '#EAF2F8'))
        self._tv.delete(*self._tv.get_children())
        prev_stage = None
        for i, (sv, ev, ref, body, bcode) in enumerate(self._members):
            st = self._stage_of(i, bcode)
            if st != prev_stage:
                prev_stage = st
                key, dflt = self._STAGES[st]
                self._tv.insert('', 'end', iid=f'b{i}', open=True,
                                text='── %s ──' % i18n.t(key, dflt),
                                tags=('book',))
            one = body.replace('\n', ' ')
            # 축약했으면 그 사실을 보인다 (2026-08-19 사용자 「…… 표시 추가」)
            cut = one[:34] + ('……' if len(one) > 34 else '')
            self._tv.insert('', 'end', iid=f'm{i}',
                            text=' %2d. %s  %s' % (i + 1, ref, cut))
        idx = 0
        if vid:
            for i, (sv, ev, *_r) in enumerate(self._members):
                if sv <= int(vid) <= ev:
                    idx = i
                    break
        self._show_member(idx)
        self._load_guides(code, lang)
        self._sync_assets(code)

    def _show_member(self, idx):
        if not self._members:
            return
        idx = max(0, min(idx, len(self._members) - 1))
        self._idx = idx
        sv, ev, ref, _body, _bc = self._members[idx]
        lang = self.lang_getter() or 'KO'
        name, desc = chain_meta(self.db_path, self._code, lang)
        n, m = idx + 1, len(self._members)
        self._name_lbl.config(text='◆ %s' % (name or self._code))
        self._desc_lbl.config(text=desc or '')
        self._pos_lbl.config(text='%s  ·  %d / %d' % (ref, n, m))
        self._prev_btn.config(state=('normal' if idx > 0 else 'disabled'))
        self._next_btn.config(state=('normal' if idx < m - 1 else 'disabled'))

        # 목록 강조 동기화
        for iid in self._tv.get_children():
            self._tv.item(iid, tags=('book',) if iid.startswith('b')
                          else ())
        try:
            self._tv.item(f'm{idx}', tags=('cur',))
            self._tv.selection_set(f'm{idx}')
            self._tv.see(f'm{idx}')
        except Exception:
            pass

        # 본문 = **마디(구절 또는 구간)가 기준, 초기값은 핵심 구절만**
        # (2026-08-19 사용자 — 「초기값으로 ±5 를 붙이면 설명문 공간이 좁다」).
        # +5/−5 를 누르는 만큼 본문 칸이 자동으로 늘고 준다(autosize).
        try:
            self._peri.show_verse(sv, context=0, end_vid=ev)
        except Exception:
            pass

        # 본문 아래 = 구절 설명문 · 그 아래 = 묵상노트 (사용자 확정 순서)
        self._last_vd = (sv, ev, lang)
        self._refresh_vdesc(sv, ev, lang)
        self._refresh_notes()

    def _refresh_vdesc(self, sv, ev, lang):
        """마디 구절의 **구절 설명문**(VERS_DESC 일반 설명 — P2 설명 탭과 같은
        자산). 구간이면 절마다 약명 머리 + 설명문. 체인 흐름 해설이 아니라
        「이 절 자체」의 설명이다(연결설명문은 이 화면에 표시하지 않는다)."""
        self._retag()
        t = self._vdesc_txt
        t.config(state='normal')
        t.delete('1.0', 'end')
        lang = (lang or 'KO').upper()
        found = False
        try:
            with appdb.connect(self.db_path) as c:
                for v in range(sv, ev + 1):
                    row = None
                    for lg in (lang, 'EN', 'KO'):
                        row = c.execute(
                            "SELECT contents FROM sys_text_asset "
                            " WHERE text_type='VERS_DESC' AND clicked_id=? "
                            "   AND UPPER(lang_code)=? "
                            "   AND COALESCE(record_status,'LIVE')='LIVE' "
                            " ORDER BY (CASE WHEN text_variant='LAY' THEN 0 "
                            "           WHEN text_variant IS NULL THEN 1 "
                            "           ELSE 2 END) LIMIT 1",
                            (v, lg)).fetchone()
                        if row and (row[0] or '').strip():
                            break
                    if not (row and (row[0] or '').strip()):
                        continue
                    found = True
                    if ev != sv:                      # 구간 — 절마다 약명 머리
                        r = c.execute(
                            "SELECT bn.short_name, bi.chapter, bi.verse "
                            "  FROM bible_index bi "
                            "  JOIN book_names bn ON bn.book_code=bi.bcode "
                            "   AND bn.lang_code IN (?,'EN','KO') "
                            " WHERE bi.verse_id=? LIMIT 1", (lang, v)).fetchone()
                        if r:
                            t.insert('end', '%s %d:%d\n' % r, ('meta',))
                    t.insert('end', row[0].strip() + '\n', ('d',))
        except Exception:
            pass
        if not found:
            t.insert('end', i18n.t('COMMON_NODESC', '(설명문이 없습니다.)'),
                     ('empty',))

        # ★ 흐름 연결 — 접힌 한 줄, 클릭 = 펼침/접힘 (2026-08-19 사용자 승인.
        #   왼쪽 목록이 흐름을 보여주므로 **이동은 없다**). 대상 = 이 마디에
        #   닿는 **체인 내부** 연결설명문(전수 보유 — 마디당 평균 1.9개).
        flows = []
        for (a, b, d) in getattr(self, '_vlinks', []):
            if (sv <= a <= ev) or (sv <= b <= ev):
                flows.append((a, b, d))
        if flows:
            t.tag_configure('flowhdr', foreground=_C('accent', '#1F618D'),
                            underline=True, spacing1=10)
            mark = '▾' if getattr(self, '_flow_open', False) else '▸'
            # ⚠ 태그는 **글자에만** (2026-09-16 · 1.txt 12번 「오른쪽의 빈 공간을
            #   클릭해도 링크가 작동한다. 제거하라」) — 줄바꿈까지 태그에 넣으면
            #   줄 끝 빈 자리도 눌린다.
            t.insert('end', '\n')
            t.insert('end', '%s %s (%d)' % (
                mark, i18n.t('CD_FLOW', '이 구절의 흐름 연결'), len(flows)),
                ('flowhdr',))
            t.insert('end', '\n')
            t.tag_bind('flowhdr', '<Button-1>', self._toggle_flow)
            if getattr(self, '_flow_open', False):
                for (a, b, d) in flows:
                    t.insert('end', '%s ↔ %s  ' % (
                        self._reflab.get(a, a), self._reflab.get(b, b)),
                        ('meta',))
                    t.insert('end', d + '\n', ('d',))
        t.config(state='disabled')

    def _toggle_flow(self, _e=None):
        self._flow_open = not getattr(self, '_flow_open', False)
        if getattr(self, '_last_vd', None):
            self._refresh_vdesc(*self._last_vd)
        return 'break'

    def _step(self, d):
        if self._idx is not None:
            self._show_member(self._idx + d)

    # ── 묵상노트 (2026-08-19 사용자 확정 — 아래 칸이 노트 자리) ─────────

    def _cur_range(self):
        """지금 마디의 (시작vid, 끝vid) — 구간 마디면 둘이 다르다."""
        if self._idx is None or not self._members:
            return None
        m = self._members[self._idx]
        return m[0], m[1]

    def _note_rows(self, sv, ev):
        """이 마디(구간)와 겹치는 닻의 노트 — P2 묵상노트와 같은 조회식.
        ⚠ 생애 상태는 LIVE/NEW/EDIT (notes.md §0 함정 — LIVE 만 세면 0)."""
        try:
            with appdb.connect(self.db_path) as c:
                return c.execute(
                    "SELECT user_text_id, contents, "
                    "       COALESCE(updated_at, created_at), "
                    "       clicked_id, COALESCE(NULLIF(target_id,0), clicked_id) "
                    "  FROM user_text_asset "
                    " WHERE text_type='VERS_NOTE' "
                    "   AND COALESCE(record_status,'LIVE') IN ('LIVE','NEW','EDIT') "
                    "   AND "
                    + _vr.overlaps_sql('user_text_asset', 'clicked_id',
                                       'target_id') +
                    " ORDER BY user_text_id DESC",
                    _vr.overlaps_args(sv, ev)).fetchall()
        except Exception:
            return []

    def _refresh_notes(self):
        """아래 칸 — 이 마디의 노트 목록 + 단추 개수 (N)."""
        rng = self._cur_range()
        rows = self._note_rows(*rng) if rng else []
        try:
            self._note_btn.config(text='%s (%d)' % (
                i18n.t('TAB_NOTE', '묵상노트'), len(rows)))
        except Exception:
            pass
        self._retag()
        import medi_note
        t = self._notes_txt
        t.config(state='normal')
        t.delete('1.0', 'end')
        for tag in t.tag_names():
            if tag.startswith('e_'):
                t.tag_delete(tag)
        if not rows:
            t.insert('end', i18n.t('CD_NONOTE',
                                   '아직 이 구절에 쓴 묵상노트가 없습니다.'),
                     ('empty',))
        for (nid, contents, ts, sv, ev) in rows:
            p = medi_note.parse(contents or '')
            meta = ' · '.join(x for x in ((ts or '')[:10], p['src_label'],
                                          p['verse_label']) if x)
            t.insert('end', meta + '  ', ('meta',))
            etag = 'e_%d' % nid
            t.insert('end', i18n.t('COMMON_EDIT', '수정'), ('meta', 'edit', etag))
            rec = {'id': nid, 'body': p['body'], 'start_vid': sv, 'end_vid': ev}
            t.tag_bind(etag, '<Button-1>',
                       lambda e, r=rec: self._open_note_bar(rec=r))
            t.insert('end', '\n')
            t.insert('end', (p['body'] or '') + '\n', ('d',))
        t.config(state='disabled')

    def _open_note_bar(self, rec=None):
        """쓰기/수정 띠 — 아래 칸 맨 위에 잠깐 펼쳐진다 (렌즈 화면 방식).

        닻 후보(닻은 사용자 결정 — 원칙 ⑤): 구간 마디면 [구간 전체] 가 기본,
        이어서 개별 절들. 한 절 마디면 그 절 하나."""
        rng = self._cur_range()
        if not rng:
            return
        sv, ev = rng
        if self._note_bar is not None and self._note_bar.winfo_exists():
            self._note_bar.destroy()
        import medi_note
        lang = self.lang_getter() or 'KO'
        if ev != sv:
            cands = [(medi_note.verse_label(self.db_path, sv, ev, lang), sv, ev)]
            cands += [(medi_note.verse_label(self.db_path, v, None, lang), v, 0)
                      for v in range(sv, ev + 1)]
        else:
            cands = [(medi_note.verse_label(self.db_path, sv, None, lang), sv, 0)]
        name, _d = chain_meta(self.db_path, self._code, lang)
        self._note_bar = medi_note.NoteBar(
            self._bottom, self.db_path, cands,
            src_key='CHAIN:%s' % (self._code or ''),
            src_label='%s · %s' % (i18n.t('TAB_CHAIN', '흐름묵상'),
                                   name or self._code or ''),
            lang=lang, rec=rec, on_done=self._refresh_notes)
        # ⚠ expand 자식(_notes_txt)보다 앞으로 — 안 당기면 1×1 (§pack 함정)
        self._note_bar.pack(fill='x', before=self._notes_txt)

    def _on_pick(self, _e=None):
        sel = self._tv.selection()
        if sel and sel[0].startswith('m'):
            idx = int(sel[0][1:])
            # ⚠ _show_member 가 selection_set 을 하면 이 핸들러가 되돌아온다 —
            #   같은 마디면 아무 것도 안 해서 무한 고리를 끊는다(§3 refr 패턴.
            #   실측 — update() 가 통째로 멈췄다).
            if idx != self._idx:
                self._show_member(idx)

    def _goto_p1(self):
        if self._idx is not None and callable(self.on_verse_jump):
            self.on_verse_jump(self._members[self._idx][0])

    def set_bar_visible(self, on):
        """갈래 줄에 심은 단추를 펴고 접는다 — 역본비교 갈래에서는 접는다
        (같은 줄을 두 갈래가 나눠 쓰므로 흐름 단추가 남으면 거짓말이 된다)."""
        for w, side, px in getattr(self, '_bar_widgets', ()):
            try:
                w.pack_forget()
                if on:
                    w.pack(side=side, padx=px, pady=2)
            except Exception:
                pass

    def _toggle_notes(self):
        """[묵상노트] — 아래 칸(댓글 목록 + 쓰기 띠)을 펴고 접는다."""
        self._notes_on = not getattr(self, '_notes_on', False)
        if self._notes_on:
            try:
                self._vpw.add(self._bottom, height=150, minsize=60,
                              stretch='never')
            except Exception:
                pass
            self._open_note_bar()
        else:
            nb = getattr(self, '_note_bar', None)
            if nb is not None and nb.winfo_exists():
                nb.destroy()
            self._note_bar = None
            try:
                self._vpw.forget(self._bottom)
            except Exception:
                pass

    def _toggle_assets(self):
        """[연결된 자산 보기] — 도서/설교 모델: 단추 아래에 펼쳐진다."""
        if self._assets is None or not getattr(self, '_assets_n', 0):
            return
        self._assets_on = not self._assets_on
        if self._assets_on:
            self._assets.pack(fill='x', after=self._hd, padx=4, pady=(0, 2))
            self._assets_btn.config(text='%s (%d)' % (
                i18n.t('PR_ASSETS_HIDE', '연결된 자산 접기'), self._assets_n))
        else:
            self._assets.pack_forget()
            self._assets_btn.config(text='%s (%d)' % (
                i18n.t('PR_ASSETS_SHOW', '연결된 자산 보기'), self._assets_n))

    def _sync_assets(self, code):
        """흐름이 바뀌면 자산 판을 다시 세고 **접는다**(도서/설교 모델 —
        안 접으면 판 높이가 흐름마다 달라 본문 시작선이 오르내린다)."""
        if self._assets is not None:
            self._assets.pack_forget()
        self._assets_on = False
        cid, cnt = None, 0
        try:
            import appdb
            import link_picker
            with appdb.connect(self.db_path) as c:
                cid = link_picker.ensure_chain_ids(c).get(code)
            if cid and self._assets is not None:
                cnt = self._assets.load('CHAIN', cid)
        except Exception as e:
            print('[chain assets sync] %s' % e)
        self._chain_id = cid
        self._assets_n = cnt
        try:
            self._assets_btn.config(
                text='%s (%d)' % (i18n.t('PR_ASSETS_SHOW', '연결된 자산 보기'),
                                  cnt),
                state=('normal' if cnt else 'disabled'))
        except Exception:
            pass

    def on_asset_jump(self, kind, aid):
        """자산 판 클릭 — 호스트의 만능 점프(user_main._tag_asset_jump)."""
        cb = getattr(self, 'on_link_open', None)
        if callable(cb):
            cb(kind, aid)

    def _open_my_edit(self):
        """[My Edit] — **지금 보는 흐름이 출발지**로 연결팝업을 연다
        (0.txt 1번 「선택된 말씀의 흐름이 연결팝업 화면의 왼쪽에 자동
        포커스」 = 출발지 앵커가 곧 그 포커스다)."""
        cid = getattr(self, '_chain_id', None)
        if not cid:
            return
        try:
            import my_edit
            my_edit.open(self, 'CHAIN', cid)
        except Exception as e:
            print('[chain my edit] %s' % e)

    # ── 묵상 안내 (sys_chain_route) ─────────────────────────────────

    def _load_guides(self, code, lang):
        rows = []
        try:
            import plan_route
            with appdb.connect(self.db_path) as c:
                for kind, tid in c.execute(
                        "SELECT to_kind, to_id FROM sys_chain_route "
                        " WHERE chain_code=? AND COALESCE(record_status,'LIVE')='LIVE' "
                        " ORDER BY sort_order", (code,)).fetchall():
                    if not plan_route._exists(c, kind, tid):
                        continue        # 팩 미보유 필터 — plan_route 와 같은 게이트
                    label = plan_route._label(c, kind, tid, lang)
                    if label:
                        rows.append((kind, tid, label))
        except Exception:
            rows = []
        # ★ 상단 이름 줄 오른쪽 한 자리 — 「추천묵상: 이름」만 (2026-08-19 사용자
        #   「연쇄묵상 끝나고 추천할 묵상플랜을 상단에 미리. 이름만. 공간배치 잘」).
        #   여럿이면 첫째만 보인다(자리 하나). 클릭 = 그 자산으로 점프.
        if not rows:
            self._guide_lbl.pack_forget()
            return
        kind, tid, label = rows[0]
        self._guide_lbl.config(text='%s: %s' % (
            i18n.t('CD_RECOMMEND', '추천묵상'), label))
        self._guide_lbl.bind(
            '<Button-1>',
            lambda e, k=kind, t=tid: (callable(self.on_route_jump)
                                      and self.on_route_jump(k, t)))
        self._guide_lbl.pack(side='right', before=self._pos_lbl)
