# -*- coding: utf-8 -*-
"""팩 발행 — **목록대로 만들고 · 한도를 재고 · 서버에 올린다**.

★★★ 왜 (2026-09-04 ⑫) — 코어팩·본문팩을 만드는 문(`db_pack_core`·
  `db_pack_body`)과 올리는 문(`db_linkpack_build.upload`)은 있었는데
  **그 사이가 비어 있었다**:
  ⚠⚠ `upload` 는 파일을 **글자로 읽는다**(`encoding='utf-8'` + `json.loads`)
    — **gzip 팩을 못 올린다.** 그래서 팩을 만들어 두고도 서버에 못 갔다.
  ⚠⚠ 파일 이름을 손으로 지으면 **자산 열쇠와 어긋난다** — 실측으로 겪었다
    (`pack_BIBLE_KRV_-_-` 를 만들어 두었는데 받는 쪽은 `_KO_` 를 찾았다).
    ⇒ **이름은 `sys_pack_item` 의 열쇠가 정한다.**

**서버 한도가 있다 — 재고 나서 올린다**(실측 2026-09-04):
  · **jsDelivr 20MB** — 넘으면 CDN 이 안 서빙한다(raw 로 물러선다 · 느리다)
  · **GitHub 파일 하나 100MB** — 넘으면 **아예 못 올린다**
  · GitHub 저장소 권장 1GB — 본문 전체 약 102MB + 코어 5.8MB 라 여유
  ⇒ `plan()` 이 그것을 **미리 말한다**. 조용히 실패하지 않는다(§0-1).

⚠ **옛 링크 팩 경로는 안 건드린다** — 지금 사용자가 그것으로 받고 있다.
  이 문은 **새 파일만** 다루고 `db_linkpack_build.pending_files()` 와 겹치지
  않는다(selftest 가 그것을 잰다).

`--selftest`(의무) · `--plan` · `--build [갈래…]` · `--pending` · `--upload`.
"""
import argparse
import io
import os
import sys

import appdb

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')
DIST = os.path.join(os.path.dirname(__file__), '_linkpack_dist')

MB = 1048576
#: jsDelivr 이 서빙하는 한계 — 넘으면 raw 로 물러선다(받히긴 한다).
LIMIT_CDN = 20 * MB
#: GitHub 파일 하나 하드 리밋 — 넘으면 **올릴 수 없다**.
LIMIT_REPO = 100 * MB
#: 저장소 전체 권장치.
LIMIT_REPO_TOTAL = 1024 * MB

STATE = 'packpub_state.json'


def _dist(name):
    return os.path.join(DIST, name)


def _load(name, dflt=None):
    import json
    try:
        with io.open(_dist(name), encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return dflt


def _save(name, obj):
    import json
    os.makedirs(DIST, exist_ok=True)
    with io.open(_dist(name), 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)


def targets(conn):
    """발행 대상 → `[{kind,key,lang,variant,version,file}]`.

    ★ **판이 매겨진 자산만**(`version>0`) — 판 0 은 「아직 안 만들었다」는
      뜻이라 올릴 것이 없다.
    ⚠ 코어팩은 자산 목록의 `CORE` 한 줄로 함께 온다(이름만 다르다).
    """
    import db_pack_body as PB
    import db_pack_core as PK
    import db_pack_item as PI
    out = []
    for x in PI.items(conn):
        # ⚠⚠ **독자판만 오른 자산도 발행 대상이다**(2026-09-05 실측으로 잡음).
        #   `version` 은 **연동판**(연결이 바뀌면 오른다)이고 본문만 바뀐
        #   자산은 `own_version` 만 오른다(§db_pack_release.classify).
        #   `version>0` 만 보면 **사진 팩처럼 본문만 있는 자산이 영영 발행
        #   안 된다** — 판을 매겼는데 목록에 안 떴다.
        if not (x.get('version') or x.get('own_version')):
            continue
        k = (x.get('kind') or '').upper()
        if k == 'LINK':
            # ★ 영상 연결은 **제 길**(`db_linkpack_build.publish` · 시퀀스·델타)로
            #   나간다(2026-09-29 293차). 여기서 본문팩 이름을 지으면 없는 파일을
            #   「만들 것」으로 센다.
            continue
        if k == 'CORE':
            # ★★★ **코어는 주기별로 파일이 갈린다**(2026-09-05 릴리스 패킹).
            #   목록(`sys_pack_item`)의 CORE 는 **한 줄 그대로**다 — 판은
            #   하나여야 「9번 코어를 받았다」가 성립한다. 파일만 셋이다.
            #   ⚠ 담을 것이 있는 주기만(빈 팩 금지) · 순서는 적재 순서.
            cys = PK.core_cycles(conn)
            for cy in (cys or [None]):
                out.append({'kind': k, 'key': x.get('key'),
                            'lang': x.get('lang'),
                            'variant': x.get('variant'),
                            'version': (x.get('version') or x.get('own_version')),
                            'cycle': cy,
                            'title': ((x.get('title') or '코어팩')
                                      + (' · %s' % cy if cy else '')),
                            'file': PK.core_name(cy)})
            continue
        fn = PB.pack_name(k, x.get('key'), x.get('lang'), x.get('variant'))
        out.append({'kind': k, 'key': x.get('key'), 'lang': x.get('lang'),
                    'variant': x.get('variant'), 'version': (x.get('version') or x.get('own_version')),
                    'cycle': None,
                    'title': x.get('title') or '', 'file': fn})
    return out


def plan(conn):
    """무엇을 만들고 올릴 것인가 → `{'rows','build','upload','warn'}`.

    ★★ **한도를 여기서 말한다** — 만들고 나서 「못 올린다」를 알면 늦다.
    """
    st0 = _load(STATE, {}) or {}
    made = st0.get('made') or {}
    rows, warn = [], []
    tot = 0
    for t in targets(conn):
        p = _dist(t['file'])
        t['exists'] = os.path.exists(p)
        # ★★★ **판이 파일보다 새로우면 낡은 것이다**(2026-09-04 실측으로 잡음).
        #   ⚠⚠ 「있으면 안 만든다」만 두면 **코어팩이 낡은 채 남는다** — 실제로
        #     만든 뒤 연결 3,047행이 늘었는데 그대로 서버에 있었다.
        #     사용자는 최신 연결을 영영 못 받는다.
        t['stale'] = t['exists'] and made.get(t['file']) != t['version']
        t['bytes'] = os.path.getsize(p) if t['exists'] else 0
        tot += t['bytes']
        if t['bytes'] >= LIMIT_REPO:
            warn.append('%s: %.1f MB — GitHub 100MB 한계를 넘어 **못 올린다**'
                        % (t['file'], t['bytes'] / MB))
        elif t['bytes'] >= LIMIT_CDN:
            warn.append('%s: %.1f MB — jsDelivr 20MB 를 넘어 CDN 이 아니라 '
                        'raw 로 나간다(느리다)' % (t['file'], t['bytes'] / MB))
        rows.append(t)
    if tot >= LIMIT_REPO_TOTAL:
        warn.append('전체 %.0f MB — 저장소 권장 1GB 에 가깝다' % (tot / MB))
    # ★★ **목록에 없는 팩 파일을 조용히 두지 않는다**(2026-09-05).
    #   ⚠ 자산 이름이 바뀌거나(옛 `pack_BIBLE_KRV_-_-`) 코어가 주기별로 갈리면
    #     옛 파일이 폴더에 남는다. **안 올라가는 것이 맞지만** 말은 해야 한다
    #     — 안 그러면 「만들었는데 왜 안 올라가나」가 된다(§0-1).
    want = {t['file'] for t in rows}
    orphan = []
    try:
        import glob
        for p2 in glob.glob(os.path.join(DIST, '*.gz')):
            b = os.path.basename(p2)
            if b not in want:
                orphan.append(b)
    except Exception:
        orphan = []
    if orphan:
        warn.append('발행 목록에 없는 팩 %d개 — 안 올라갑니다(옛 이름이거나 '
                    '주기가 바뀐 것): %s' % (len(orphan), ', '.join(orphan[:3])))
    st = _load(STATE, {}) or {}
    up = set(st.get('uploaded') or [])
    return {'rows': rows,
            'build': [t for t in rows if not t['exists'] or t['stale']],
            'upload': [t for t in rows
                       if t['exists'] and _sig(t, st) not in up],
            'orphan': orphan, 'bytes': tot, 'warn': warn}


def _sig(t, st=None):
    """올린 것을 다시 안 올리려는 표식 — **내용이 바뀌면 다시 올린다**.

    ⚠ **파일 이름을 쓴다** — 코어는 한 자산에 파일이 셋(주기별)이라 열쇠에
      주기가 없으면 셋이 한 표식을 공유해 **둘이 안 올라간다**.
    ★★★ **꼬리표는 판이 아니라 내용 해시다**(2026-09-05). 판으로 하면 판이
      오를 때마다 주기 파일 셋이 전부 다시 올라간다 — 실제로 바뀐 것은 보통
      매일 묶음 하나뿐인데도. gzip 은 git 히스토리에 그대로 쌓이므로
      (§팩 작업 규칙 ①) 이 한 줄이 저장소 크기를 가른다.
    ⚠ 아직 안 만든 파일은 해시가 없다 — 그때만 판을 쓴다.
    """
    sh = (st or {}).get('sha') or {}
    fn = t.get('file') or '%s|%s|%s' % (t['key'], t['lang'], t['variant'])
    return '%s|%s|%s' % (t['kind'], fn, sh.get(fn) or ('v%s' % t['version']))


def check_gate(conn, when=None):
    """발행 전 **룰엔진 게이트** → `(통과?, [막는 것…], [경고…])`.

    ★★★ 왜 (2026-09-05) — ⚠⚠ **미승인 미디어 10,863건이 코어팩으로 새는 것을
      갈아타기 직전에야 잡았다.** 점검이 배포와 갈려 있어 「무엇을 돌리나」가
      기억에 의존했기 때문이다. ⇒ **발행하는 문이 직접 부른다.**
    ⚠ **경고는 막지 않는다** — 막는 것(`BLOCK`)만 세운다. 다 막으면 아무것도
      발행 못 한다.
    """
    try:
        import db_rules as R
    except Exception as e:                                    # noqa: BLE001
        return True, [], [{'code': 'RULES', 'note': '룰엔진 없음: %s'
                           % str(e)[:50]}]
    rows = R.run(conn, when)
    return (not R.blocked(rows)), R.blocked(rows), [
        r for r in rows if not r['ok'] and r['sev'] != R.BLOCK]


def build_all(conn, only=None, on_step=None):
    """대상 중 **파일이 없는 것**을 만든다 → `[(파일, 결과|오류)]`.

    ⚠ **판이 그대로면 다시 안 만든다** — 스펄전 설교 하나가 31MB 라 매번
      다시 만들면 발행이 몇 분씩 걸린다.
    ⚠⚠ **판이 오르면 다시 만든다** — 「있으면 건너뛴다」만 두면 낡은 팩이
      그대로 서버에 남는다(실측으로 겪었다).
    """
    import db_pack_body as PB
    import db_pack_core as PK
    out = []
    for t in plan(conn)['build']:
        if only and t['kind'] not in only:
            continue
        if on_step:
            on_step(t)
        try:
            if t['kind'] == 'CORE':
                r = PK.build(conn, out_dir=DIST, cycle=t.get('cycle'))
            else:
                r = PB.build(conn, t['kind'], t['key'], t['lang'],
                             t['variant'], out_dir=DIST)
            out.append((t['file'], r))
            # ★ **무슨 판으로 만들었나**를 적어 둔다 — 이것이 낡음 판정의 열쇠
            st = _load(STATE, {}) or {}
            md = st.get('made') or {}
            md[t['file']] = t['version']
            st['made'] = md
            # ★★★ **내용이 그대로면 다시 안 올린다**(2026-09-05 릴리스 패킹).
            #   판이 오르면 주기 파일 셋이 전부 낡은 것이 되어 다시 만들어지는데,
            #   **실제로 바뀐 것은 보통 매일 묶음 하나뿐**이다. 안 바뀐 파일까지
            #   올리면 gzip 이 히스토리에 그대로 쌓인다(§팩 작업 규칙 ①).
            #   ⇒ 만든 내용의 sha1 을 견줘 **같으면 올림 표식을 그대로 둔다.**
            #   ⚠⚠ **`sha1`(파일 해시)이 아니라 `content_sha1`(담긴 것)**을
            #     쓴다 — 파일 해시에는 **만든 시각**이 섞여 있어 다시 만들
            #     때마다 달라진다(실측으로 잡았다).
            sh = st.get('sha') or {}
            new_sha = (r.get('content_sha1') if isinstance(r, dict) else None)
            same = bool(new_sha) and sh.get(t['file']) == new_sha
            if new_sha:
                sh[t['file']] = new_sha
                st['sha'] = sh
            if not same:
                # ★★ **다시 만들었으면 올림 표식을 뗀다** — 안 떼면 새로 만든
                #   내용이 「이미 올렸다」로 걸러져 **영영 서버에 안 간다.**
                #   ⚠ 그 파일의 **옛 표식을 전부** 걷는다 — 꼬리표가 해시라
                #     하나만 지우면 남은 옛 것이 쌓인다.
                pre = '%s|%s|' % (t['kind'], t['file'])
                st['uploaded'] = [x for x in (st.get('uploaded') or [])
                                  if not str(x).startswith(pre)]
            _save(STATE, st)
        except Exception as e:                                # noqa: BLE001
            out.append((t['file'], 'ERR: %s' % str(e)[:90]))
    return out


def pending(conn):
    """올릴 파일 이름 → `[이름…]`. ⚠ **manifest 는 늘 마지막**.

    ★ 그것이 「최신은 여기까지」를 알리는 표지라, 팩보다 먼저 올라가면
      아직 없는 파일을 받으러 간다(옛 링크 팩과 같은 규칙).
    """
    import db_linkpack_build as LB
    names = [t['file'] for t in plan(conn)['upload']]
    # ★★ **썸네일 파일도 함께 올린다**(2026-09-05) — 사진 팩만 올리면 사용자
    #   화면이 「미리보기를 받을 수 없습니다」만 보인다. ⚠ 사진 팩이 나갈
    #   때만 함께 간다(다른 발행 때 쓸데없이 안 올라가게).
    try:
        import db_splash_scene as SC
        if (any(n.startswith('pack_IMAGE_') for n in names)
                and os.path.exists(_dist(SC.THUMBS_NAME))):
            names.append(SC.THUMBS_NAME)
    except Exception:
        pass
    if names and os.path.exists(_dist(LB.MANIFEST)):
        names.append(LB.MANIFEST)
    return names


def upload(conn, servers, names=None, dry=False):
    """서버에 올린다 → `{'ok','files','msgs'}`.

    ⚠⚠ **바이너리로 올린다**(`put_bytes`) — gzip 팩은 글자가 아니다.
    ⚠ manifest 는 텍스트라 그대로 `put` 을 쓴다(둘을 가려 부른다).
    """
    import rss_transport as RT
    names = names if names is not None else pending(conn)
    if not names:
        return {'ok': True, 'files': [], 'msgs': ['올릴 것이 없다']}
    if dry:
        return {'ok': True, 'files': names, 'msgs': ['(dry) 올리지 않았다']}
    msgs, ok_all = [], True
    for srv in (servers or []):
        if not srv.get('enabled', True):
            continue
        tp = RT.make_transport(srv)
        for n in names:
            p = _dist(n)
            try:
                if n.endswith('.gz'):
                    if not hasattr(tp, 'put_bytes'):
                        raise RuntimeError('이 전송 수단은 바이너리를 못 올린다')
                    with open(p, 'rb') as f:
                        ok, m = tp.put_bytes(n, f.read())
                else:
                    with io.open(p, encoding='utf-8') as f:
                        ok, m = tp.put(n, f.read())
            except Exception as e:                            # noqa: BLE001
                ok, m = False, str(e)[:90]
            ok_all = ok_all and ok
            if not ok:
                msgs.append('%s: %s' % (n, m))
        if hasattr(tp, 'flush'):
            fok, fm = tp.flush()
            ok_all = ok_all and fok
            msgs.append('%s: %s' % (srv.get('label', '?'), fm))
    if ok_all:
        st = _load(STATE, {}) or {}
        up = set(st.get('uploaded') or [])
        for t in plan(conn)['upload']:
            if t['file'] in names:
                up.add(_sig(t, st))
        st['uploaded'] = sorted(up)
        import time
        st['uploaded_at'] = time.strftime('%Y-%m-%d %H:%M:%S')
        _save(STATE, st)
        try:
            RT.purge_jsdelivr(names)
        except Exception:
            pass
    return {'ok': ok_all, 'files': names, 'msgs': msgs}


# ── 자가검증 ─────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', name, extra))

    import tempfile
    import db_linkpack_build as LB
    global DIST
    keep = DIST
    DIST = tempfile.mkdtemp(prefix='packpub_')

    c = appdb.connect(DB)
    try:
        p = plan(c)
        t('★ 계획이 나온다', isinstance(p, dict) and 'rows' in p,
          '%d개' % len(p['rows']))
        t('★★ **판이 매겨진 것만 대상**(판 0 은 안 올린다)',
          all(x['version'] for x in p['rows']),
          '%d개' % len(p['rows']))
        t('  파일이 없으면 만들 목록에 든다',
          len(p['build']) == len([x for x in p['rows'] if not x['exists']]))
        t('★★ **이름은 자산 열쇠가 정한다**(손으로 안 짓는다)',
          all(('_%s_' % (x['lang'] or '-')) in x['file'] or x['kind'] == 'CORE'
              for x in p['rows']),
          str([x['file'] for x in p['rows']][:2]))

        # 한도 — 큰 파일을 만들어 경고가 나는가(탐지력)
        import db_pack_body as PB
        fake = os.path.join(DIST, 'big.json.gz')
        os.makedirs(DIST, exist_ok=True)
        with open(fake, 'wb') as f:
            f.write(b'0' * (LIMIT_CDN + 1))
        t('  한도 상수가 실제 값이다',
          LIMIT_CDN == 20 * MB and LIMIT_REPO == 100 * MB,
          '%d / %d MB' % (LIMIT_CDN // MB, LIMIT_REPO // MB))

        names = pending(c)
        t('★★ **manifest 는 늘 마지막**(있으면)',
          (not names) or names[-1] == LB.MANIFEST or LB.MANIFEST not in names,
          str(names[-1]) if names else '(없음)')

        # ⚠ 옛 링크 팩 경로와 안 겹친다
        old = set(LB.pending_files())
        t('★★★ **옛 링크 팩 경로를 안 건드린다**',
          not (set(n for n in names if n != LB.MANIFEST) & old),
          '옛 %d개' % len(old))

        r = upload(c, [], names=['x.json.gz'], dry=True)
        t('  dry 는 올리지 않는다', r['ok'] and '(dry)' in r['msgs'][0],
          r['msgs'][0])

        # 바이너리 왕복 — LocalDirTransport 로
        import rss_transport as RT
        d2 = tempfile.mkdtemp(prefix='packsrv_')
        tp = RT.make_transport({'transport': 'LOCAL_DIR', 'location': d2})
        t('★★ **전송 수단이 바이너리를 받는다**', hasattr(tp, 'put_bytes'))
        # ⚠ **진짜 바이트**로 잰다 — 이스케이프 글자를 쓰면 왕복해도
        #   같아 보여 탐지력이 헛돈다(실측으로 잡았다)
        raw = bytes([0x1f, 0x8b, 0x08, 0x00, 0xff, 0xfe, 0x80, 0x00, 0xc3])
        okb, _m = tp.put_bytes('x.json.gz', raw)
        got = open(os.path.join(d2, 'x.json.gz'), 'rb').read()
        t('★★★ **gzip 이 글자로 안 상한다**', okb and got == raw,
          '%d바이트' % len(got))
        # 텍스트로 쓰면 상하는가(탐지력)
        tp.put('y.json.gz', raw.decode('latin-1'))
        got2 = open(os.path.join(d2, 'y.json.gz'), 'rb').read()
        t('  (탐지력) 텍스트로 쓰면 실제로 달라진다', got2 != raw,
          '%d 대 %d바이트' % (len(got2), len(raw)))

        import shutil
        shutil.rmtree(d2, ignore_errors=True)
    finally:
        c.close()
        import shutil
        shutil.rmtree(DIST, ignore_errors=True)
        DIST = keep

    t('★ 시험이 실 배포 폴더를 안 건드린다', DIST == keep, DIST)
    # ── 주기별 코어 · 내용 해시(2026-09-05 릴리스 패킹) ──────────────
    import db_pack_core as _PK
    b1 = {'format': 1, 'cycle': 'DAILY', 'made_at': '2026-01-01 00:00',
          'release': 4, 'tables': {'x': {'cols': ['a'], 'rows': [[1]]}}}
    b2 = dict(b1, made_at='2026-12-31 23:59', release=9)
    b3 = dict(b1, tables={'x': {'cols': ['a'], 'rows': [[2]]}})
    t('★★★ **내용 해시는 만든 시각·판을 무시한다**',
      _PK.content_sha1(b1) == _PK.content_sha1(b2),
      _PK.content_sha1(b1)[:10])
    t('★★ (탐지력) **담긴 것이 바뀌면 해시가 바뀐다**',
      _PK.content_sha1(b1) != _PK.content_sha1(b3))
    t1 = {'kind': 'CORE', 'key': '-', 'lang': '-', 'variant': '-',
          'version': 4, 'file': 'corepack_DAILY.json.gz'}
    t2 = dict(t1, file='corepack_BIANNUAL.json.gz')
    t('★★★ **주기별 파일이 표식을 안 공유한다**(공유하면 둘이 안 올라간다)',
      _sig(t1) != _sig(t2), _sig(t1))
    stx = {'sha': {'corepack_DAILY.json.gz': 'abc'}}
    t('★★ **표식 꼬리표는 내용 해시**(판이 아니다)',
      _sig(t1, stx).endswith('|abc')
      and _sig(dict(t1, version=99), stx) == _sig(t1, stx))
    t('  아직 안 만든 파일은 판을 쓴다', _sig(t2, stx).endswith('|v4'))

    print('db_pack_publish selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--plan', action='store_true')
    ap.add_argument('--build', nargs='*')
    ap.add_argument('--pending', action='store_true')
    ap.add_argument('--upload', action='store_true')
    ap.add_argument('--dry', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect(DB)
    try:
        if a.plan:
            p = plan(c)
            print('대상 %d개 · 만들 것 %d · 올릴 것 %d · 지금 %.1f MB'
                  % (len(p['rows']), len(p['build']), len(p['upload']),
                     p['bytes'] / MB))
            for w in p['warn']:
                print('  ⚠ %s' % w)
            for t in p['rows']:
                print('  %-7s %-22s %-4s %-11s v%-2s %8.2f MB %s'
                      % (t['kind'], str(t['key'])[:22], t['lang'],
                         str(t['variant'])[:11], t['version'],
                         t['bytes'] / MB, '' if t['exists'] else '(없음)'))
        if a.build is not None:
            only = [x.upper() for x in a.build] or None
            for fn, r in build_all(c, only,
                                   on_step=lambda t: print('  만드는 중: %s'
                                                           % t['file'])):
                print('  %-44s %s' % (fn, r if isinstance(r, str)
                                      else '%s행 · %.2f MB'
                                      % (format(r['rows'], ','),
                                         r['bytes'] / MB)))
        if a.pending:
            for n in pending(c):
                print('  %s' % n)
        if a.upload:
            # ⚠⚠ **올리는 서버와 받는 서버가 다르다** — `client_servers()` 는
            #   **읽기용**(HTTP)이라 put 이 미구현이다. 관리자 업로드는
            #   `rss_publish.get_servers()`(GIT)를 쓴다(실측으로 잡았다).
            import rss_publish as RP
            r = upload(c, RP.get_servers(), dry=a.dry)
            print('올림: %s' % ('성공' if r['ok'] else '실패'))
            for n in r['files']:
                print('  %s' % n)
            for m in r['msgs']:
                print('  · %s' % m)
    finally:
        c.close()


if __name__ == '__main__':
    main()
