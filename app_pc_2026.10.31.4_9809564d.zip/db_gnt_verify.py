# -*- coding: utf-8 -*-
"""헬라어 신약(낱말 + Strong 번호)을 **로컬 전용 검증 데이터**로 만든다.

`db_wlc_verify.py`(구약, §18-10)의 신약 짝이다. 하는 일도 지키는 규칙도 같다.

**왜 필요한가 — 셋이다.**
  ① **주요용어의 「낱말이 있는 구절」**(§12-0). 신약 앵커(아가페·카리스·피스티스)가
     지금은 붙을 데가 없다. `bible_content` 의 `TRC` 는 등록만 되고 **0행**이다.
  ② **구약↔신약 대응.** 「헤세드」에 `G1656` 앵커를 달아 뒀는데 놀고 있다.
  ③ **신약 EXPERT 괄호 원어 11,616건 검증.** 지금까지 **한 건도 확인된 적이 없다** —
     `db_vers_gate` 의 원어 검사는 표기 **형식**만 본다.

★ **배포하지 않는다.** 저장 위치는 `gnt_verify.db`(앱 폴더, gitignore).
  `bible_master.db` 에 넣지 않는다. 여기서 뽑아 낸 `(entity_id, verse_id)` 행만 배포되므로
  **Strong 번호도 헬라어 글자도 배포물에 실리지 않는다.**

**자료 = STEPBible TAGNT (Tyndale House Cambridge, CC BY 4.0).**
  §18-7 에서 TVTMS 를 같은 기관에서 받아 쓴 전례가 있다. OSHB(구약 lemma)와 같은 라이선스다.
  낱말마다 `G####` dStrong + 어느 편집본에 있는지(`NA28+…+TR+Byz`)가 붙어 있다.

★ **절체계를 추측하지 않는다.** TAGNT 기준 절번호는 NRSV 인데, 다를 때는 **대괄호로 KJV
  번호를 함께 준다**(`Mat.17.15[17.14]`). 우리 축이 KJV 계열이므로(§18-7) **대괄호가 있으면
  그것을 쓴다.** 자료가 직접 말해 주는 것이라 짐작이 아니다. 전체 141,720줄 중 376줄.
    `[..]`=KJV  `(..)`=NA  `{..}`=기타   ← TAGNT 머리말이 밝힌 규약

★ **정렬을 스스로 검증한다.** 밀린 채 저장하면 검증이 통째로 거짓말이 된다(§18-7 전례).
  TAGNT 는 낱말마다 **영어 뜻**을 함께 주므로, 고유명사(`N-…-P`)의 영어가 그 절 BSB 본문에
  들어 있는지로 **외부 자료 없이** 확인한다. offset 0 이 ±1 을 압도해야 한다.

사용:
    python -X utf8 db_gnt_verify.py --selftest   # 파싱·정렬 탐지력 (의무)
    python -X utf8 db_gnt_verify.py --align      # 정렬만 보고, 저장 안 함
    python -X utf8 db_gnt_verify.py --build      # gnt_verify.db 생성 (로컬 검증용)
    python -X utf8 db_gnt_verify.py --load-text  # bible_content 에 헬라어 본문 (배포됨)
"""
import io, os, re, sys, sqlite3, collections

APP = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(APP, '_gnt_raw')
OUT_DB = os.path.join(APP, 'gnt_verify.db')        # ★ 배포 대상 아님
FILES = ('TAGNT_Mat-Jhn.txt', 'TAGNT_Act-Rev.txt')

# TAGNT 책 코드 → 우리 bcode (40~66). 27권이 다 있어야 한다 — selftest 가 센다.
BOOKS = ['Mat', 'Mrk', 'Luk', 'Jhn', 'Act', 'Rom', '1Co', '2Co', 'Gal', 'Eph',
         'Php', 'Col', '1Th', '2Th', '1Ti', '2Ti', 'Tit', 'Phm', 'Heb', 'Jas',
         '1Pe', '2Pe', '1Jn', '2Jn', '3Jn', 'Jud', 'Rev']
BCODE = {b: 40 + i for i, b in enumerate(BOOKS)}

# Mat.17.15[17.14]#01=NKO  ·  Mat.1.1#01=NKO
REF = re.compile(r'^([A-Za-z0-9]{2,4})\.(\d+)\.(\d+)'
                 r'(?:\[(\d+)\.(\d+)\])?(?:\((\d+)\.(\d+)\))?(?:\{(\d+)\.(\d+)\})?#')
# ⚠ **dStrong 은 네 자리 zero-padding 에 뜻 구분용 letter 접미가 붙는다.**
#   실측 11종: `G0976`(130,866) · `G2424G`(8,659) · `G2384H`(2,122) · `G0863I` ·
#   `G2541J` · `G4613O` · `G1487M` · `G2455N` · `G1487L` · `G5376K` · `G20447`(5자리 3개).
#   처음에 `\bG\d{1,5}\b` 로 잡았다가 **접미가 붙은 11,230낱말(7.9%)을 통째로 잃었다** —
#   피스티스(`G4102G`)가 0건으로 나와서 발견했다. 조용히 0건이 되는 자리다.
#   ⇒ 접미를 흘려보내고 **번호는 padding 을 벗겨 저장한다**(히브리어 `H2617` 과 같은 꼴).
STRONG = re.compile(r'G(\d{1,5})[A-Za-z]?')
PROPER = re.compile(r'=N-[A-Z]{3}-P')          # 고유명사 형태 태그
PAREN = re.compile(r'\s*\([^)]*\)\s*$')        # 「καί (kai)」 의 음역 꼬리


def norm_strong(tag):
    """`G4102G=N-ASF` · `G0026=N-NSF` → `G4102` · `G26`. 못 읽으면 ''."""
    m = STRONG.match(tag.strip())
    return ('G%d' % int(m.group(1))) if m else ''


def parse_ref(line):
    """(bcode, chapter, verse) — 대괄호(KJV)가 있으면 그것을 쓴다. 못 읽으면 None."""
    m = REF.match(line)
    if not m:
        return None
    bc = BCODE.get(m.group(1))
    if bc is None:
        return None
    if m.group(4):                              # [KJV] — 우리 축
        return bc, int(m.group(4)), int(m.group(5))
    return bc, int(m.group(2)), int(m.group(3))


def read_words():
    """[(bcode, ch, vs, 헬라어, Strong, 형태, 영어뜻, 편집본)] — 파일 순서 그대로."""
    out = []
    for f in FILES:
        p = os.path.join(RAW, f)
        if not os.path.exists(p):
            raise SystemExit('자료 없음: %s\n  STEPBible-Data 의 TAGNT 두 파일을 _gnt_raw/ 에 둘 것' % p)
        for ln in io.open(p, encoding='utf-8', errors='replace'):
            ref = parse_ref(ln)
            if not ref:
                continue
            c = ln.rstrip('\n').split('\t')
            grk = PAREN.sub('', c[1]).strip() if len(c) > 1 else ''
            eng = c[2].strip() if len(c) > 2 else ''
            tag = c[3].strip() if len(c) > 3 else ''
            eds = c[5].strip() if len(c) > 5 else ''
            out.append((ref[0], ref[1], ref[2], grk, norm_strong(tag), tag, eng, eds))
    return out


def group(words):
    """(bcode,ch,vs) -> (헬라어 본문, [Strong], [(영어뜻, 고유명사?)])"""
    g = collections.OrderedDict()
    for bc, ch, vs, grk, st, tag, eng, eds in words:
        k = (bc, ch, vs)
        if k not in g:
            g[k] = ([], [], [])
        g[k][0].append(grk)
        if st:
            g[k][1].append(st)
        g[k][2].append((eng, bool(PROPER.search(tag))))
    return g


# ── 정렬 자가 검증 ──────────────────────────────────────────────────────────
def _bsb(conn, bc, ch, vs):
    r = conn.execute(
        'SELECT bc.verse_text FROM bible_index bi JOIN bible_content bc'
        ' ON bc.verse_id=bi.verse_id'
        " WHERE bi.bcode=? AND bi.chapter=? AND bi.verse=? AND bc.version_code='BSB'",
        (bc, ch, vs)).fetchone()
    return (r[0] if r else '') or ''


NAME_TOK = re.compile(r"[A-Za-z']{4,}")


def align_score(conn, g, offset=0, limit=None):
    """고유명사 영어가 그 절 BSB 본문에 들어 있는 비율. 밀리면 뚝 떨어진다.

    ⚠ **뜻풀이를 통째로 찾으면 안 된다.** TAGNT 는 전치사를 달고 온다 —
       `To Gaius` · `To Demetrius`. 통째로 찾으면 요삼이 0.33 으로 떨어져
       **정상 자료가 밀린 것처럼 보였다**(2026-08-09 실제로 겪음).
       ⇒ 네 글자 이상 토막으로 쪼개 찾는다. 길이 하한이 전치사·관사를 걸러 준다.
    """
    hit = tot = 0
    keys = list(g)
    for i, (bc, ch, vs) in enumerate(keys):
        if limit and i >= limit:
            break
        names = set()
        for e, p in g[(bc, ch, vs)][2]:
            if p:
                names |= {t.lower() for t in NAME_TOK.findall(e)}
        if not names:
            continue
        txt = _bsb(conn, bc, ch, vs + offset).lower()
        if not txt:
            continue
        for n in names:
            tot += 1
            if n in txt:
                hit += 1
    return (hit / tot) if tot else 0.0, tot


def align(conn, g):
    """책마다 offset 0 이 ±1 을 압도하는지 본다. 하나라도 지면 저장하지 않는다."""
    ok = True
    print('  %-6s %8s %8s %8s   %s' % ('책', 'off 0', 'off -1', 'off +1', '판정'))
    per = collections.defaultdict(collections.OrderedDict)
    for k, v in g.items():
        per[k[0]][k] = v
    for bc in sorted(per):
        s0, n0 = align_score(conn, per[bc], 0)
        sm, _ = align_score(conn, per[bc], -1)
        sp, _ = align_score(conn, per[bc], +1)
        good = n0 == 0 or (s0 > 0.55 and s0 > sm + 0.15 and s0 > sp + 0.15)
        ok &= good
        print('  %-6d %7.2f %8.2f %8.2f   %s%s'
              % (bc, s0, sm, sp, 'OK' if good else '<<< 의심',
                 '' if n0 else '  (고유명사 없음 — 검사 못 함)'))
    return ok


def build(conn, g):
    if os.path.exists(OUT_DB):
        os.remove(OUT_DB)
    db = sqlite3.connect(OUT_DB)
    db.execute('CREATE TABLE gnt_verse (verse_id INTEGER PRIMARY KEY,'
               ' grk TEXT, strongs TEXT)')
    db.execute('CREATE TABLE gnt_meta (k TEXT PRIMARY KEY, v TEXT)')
    n = miss = 0
    missing = []
    for (bc, ch, vs), (grk, st, _e) in g.items():
        r = conn.execute('SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?',
                         (bc, ch, vs)).fetchone()
        if not r:
            miss += 1
            missing.append('%d %d:%d' % (bc, ch, vs))
            continue
        db.execute('INSERT OR REPLACE INTO gnt_verse VALUES(?,?,?)',
                   (r[0], ' '.join(grk), ' '.join(st)))
        n += 1
    for k, v in (('source', 'STEPBible TAGNT (Tyndale House Cambridge)'),
                 ('license', 'CC BY 4.0'),
                 ('axis', 'KJV bracket refs used where TAGNT gives them'),
                 ('distribute', 'NO — local verification only')):
        db.execute('INSERT OR REPLACE INTO gnt_meta VALUES(?,?)', (k, v))
    db.commit()
    total = conn.execute('SELECT COUNT(*) FROM bible_index WHERE bcode>=40').fetchone()[0]
    print('  저장 %d절 · 우리 신약 %d절 · 커버 %.1f%%' % (n, total, 100.0 * n / total))
    if miss:
        print('  ! bible_index 에 없는 참조 %d개: %s' % (miss, ' '.join(missing[:10])))
    words = sum(len(v[1]) for v in g.values())
    print('  Strong 붙은 낱말 %d개' % words)
    db.close()


# ── 본문 적재 (bible_content) ───────────────────────────────────────────────
# ★ 여기가 `gnt_verify.db`(로컬 전용)와 갈린다. **이쪽은 배포된다.**
#   그래서 자료를 CC BY 4.0 인 TAGNT 하나로 골랐다 — 흔히 쓰이는 Textus Receptus
#   파싱 모듈은 CC BY-NC-SA 라 상업 제약이 생긴다(§18-11).
#
# ⚠ **TAGNT 는 여러 편집본의 낱말을 모아 놓은 것이라 그대로 쓰면 어느 사본에도 없는 글이 된다.**
#   낱말마다 `#01=NKO` 꼴로 어디에 있는지가 붙는다(N=Nestlé-Aland · K=KJV/TR · O=기타,
#   소문자·괄호는 사소한 차이). **N 계열만 골라 비평본문을 세운다** — 우리 영어 축인
#   BSB 가 그 계열이고, 의미영역 자료(MACULA Nestle1904)도 그렇다.
#   K 전용 낱말 4,124개는 빠지므로 마 17:21 같은 절이 비고, 그 자리는 §18-5 방식으로 채운다.
VERSION = 'GNT'
VER_NAME = 'Greek New Testament (Nestlé-Aland base)'
VER_DISPLAY = 'Ἡ Καινὴ Διαθήκη'
PARENS = re.compile(r'\([^)]*\)')
ABSENT = '<Ἀπόν>'          # §18-5 규약 — 부등호 + 그 행 언어의 낱말


def in_na(wtype):
    """이 낱말이 비평본문(Nestlé-Aland)에 있는가.

    괄호 안은 「그 전통에서는 다르다」는 표시라 먼저 걷어 낸다.
    `N(k)O` → `NO` → N 있음.  `K(o)` → `K` → N 없음.
    """
    return 'N' in PARENS.sub('', wtype).upper()


def load_text(conn):
    """N 계열 낱말을 절로 모아 `bible_content` 에 넣는다. 멱등(지우고 다시)."""
    # 유형(`#01=NKO`)은 참조 줄에 붙어 있어 `read_words()` 가 들고 오지 않는다.
    # 파서를 새로 만들지 않고 같은 파일을 다시 읽는다 — **파서는 하나여야 한다.**
    g = collections.OrderedDict()
    trad_words = collections.OrderedDict()      # 전통본문(K) 읽기 — 빈 절 채울 때
    kept = drop = 0
    TYPE = re.compile(r'^[A-Za-z0-9]{2,4}\.[^#\t]+#\d+=([A-Za-z()\[\]]+)')
    for f in FILES:
        for ln in io.open(os.path.join(RAW, f), encoding='utf-8', errors='replace'):
            ref = parse_ref(ln)
            if not ref:
                continue
            m = TYPE.match(ln)
            if not m:
                continue
            c = ln.rstrip('\n').split('\t')
            w = PAREN.sub('', c[1]).strip() if len(c) > 1 else ''
            if not w:
                continue
            wt = PARENS.sub('', m.group(1)).upper()
            if 'N' in wt:
                g.setdefault(ref, []).append(w)
                kept += 1
            else:
                drop += 1
            if 'K' in wt:
                trad_words.setdefault(ref, []).append(w)
    print('  낱말 %d 채택 · %d 제외(K 전용·기타)' % (kept, drop))

    cur = conn.cursor()
    cur.execute("DELETE FROM bible_content WHERE version_code=?", (VERSION,))
    n = 0
    for (bc, ch, vs), ws in g.items():
        r = conn.execute('SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?',
                         (bc, ch, vs)).fetchone()
        if not r:
            continue
        cur.execute('INSERT INTO bible_content(verse_id, version_code, verse_text) VALUES(?,?,?)',
                    (r[0], VERSION, ' '.join(ws)))
        n += 1
    # 빈 슬롯 — 비평본문에 없는 절(41개: 누락 16절 + 막 16:9-20 + 요 7:53-8:11 + 요삼 1:15).
    # §18-5 방식 그대로 — **마커만 두지 않고 전통본문 읽기를 함께 채운다.**
    # 마커만 두면 요 8:1-11 과 막 16:9-20 이 통째로 비는데, 그 두 대목은 한국어·영어 쪽에는
    # 본문이 있어서 독자가 헬라어만 사라진 것을 보게 된다. 「비평본문에는 없고 전통본문은
    # 이렇게 읽는다」를 보이는 편이 정직하고 쓸모 있다.
    empty = [r[0] for r in conn.execute(
        'SELECT bi.verse_id FROM bible_index bi'
        ' LEFT JOIN bible_content bc ON bc.verse_id=bi.verse_id AND bc.version_code=?'
        ' WHERE bi.bcode>=40 AND bc.verse_id IS NULL', (VERSION,))]
    filled = 0
    for vid in empty:
        r = conn.execute('SELECT bcode,chapter,verse FROM bible_index WHERE verse_id=?',
                         (vid,)).fetchone()
        trad = ' '.join(trad_words.get((r[0], r[1], r[2]), []))
        body = ('%s %s' % (ABSENT, trad)) if trad else ABSENT
        if trad:
            filled += 1
        cur.execute('INSERT INTO bible_content(verse_id, version_code, verse_text) VALUES(?,?,?)',
                    (vid, VERSION, body))
    # 역본 등록
    cur.execute('SELECT 1 FROM bible_version WHERE version_code=?', (VERSION,))
    if cur.fetchone():
        cur.execute("UPDATE bible_version SET version_name=?, lang_code='EL',"
                    " versification_system='MT', coverage_scope='NT_ONLY', display_name=?"
                    ' WHERE version_code=?', (VER_NAME, VER_DISPLAY, VERSION))
    else:
        cur.execute('INSERT INTO bible_version(version_code, version_name, lang_code,'
                    ' versification_system, coverage_scope, display_name)'
                    " VALUES(?,?,'EL','MT','NT_ONLY',?)", (VERSION, VER_NAME, VER_DISPLAY))
    cur.execute("UPDATE bible_version SET copyright_type='PERMISSIVE', license_note=?,"
                ' source_url=? WHERE version_code=?',
                ('STEPBible TAGNT (Tyndale House Cambridge) CC BY 4.0. 비평본문(Nestlé-Aland) '
                 '계열 낱말만 선택해 세웠다. 철자는 NA28 기준이라 특정 인쇄본의 영인이 아니다',
                 'https://github.com/STEPBible/STEPBible-Data', VERSION))
    conn.commit()
    print('  본문 %d절 저장 · 비평본문에 없는 절 %d개 (그중 %d개는 %s 뒤에 전통본문 읽기)'
          % (n, len(empty), filled, ABSENT))
    return n, empty


def selftest():
    """**탐지력**을 확인한다 — 조용히 틀릴 자리를 짚는다."""
    ok = True

    def chk(label, got, want=True):
        nonlocal ok
        good = bool(got) == bool(want)
        ok &= good
        print('  [%s] %s' % ('PASS' if good else 'FAIL', label))

    chk('책 코드 27권', len(BOOKS) == 27 and len(set(BOOKS)) == 27)
    chk('bcode 범위 40~66', min(BCODE.values()) == 40 and max(BCODE.values()) == 66)
    # ① 참조 파싱 — 대괄호를 놓치면 376줄이 조용히 엉뚱한 절에 붙는다
    chk('기본 참조', parse_ref('Mat.1.1#01=NKO') == (40, 1, 1))
    chk('대괄호(KJV)를 쓴다', parse_ref('Mat.17.15[17.14]#01=NKO') == (40, 17, 14))
    chk('소괄호(NA)는 쓰지 않는다', parse_ref('Mrk.12.15(12.14)#01=NKO') == (41, 12, 15))
    chk('중괄호(기타)는 쓰지 않는다', parse_ref('Mat.15.6{15.5}#01=k') == (40, 15, 6))
    chk('모르는 책은 None', parse_ref('Gen.1.1#01=NKO') is None)
    chk('머리말 줄은 None', parse_ref('FIELD DESCRIPTIONS:') is None)
    # ② Strong 추출 — 이것이 죽으면 조용히 0건이 된다. **접미가 진짜 함정이었다.**
    chk('평범한 번호', norm_strong('G2532=CONJ') == 'G2532')
    chk('zero-padding 을 벗긴다', norm_strong('G0026=N-NSF') == 'G26')
    chk('letter 접미를 흘려보낸다 (피스티스)', norm_strong('G4102G=N-ASF') == 'G4102')
    chk('다른 접미도 (예수)', norm_strong('G2424G=N-NSM-P') == 'G2424')
    chk('다섯 자리도 읽는다', norm_strong('G20447=X') == 'G20447')
    chk('형태만 있는 칸에서는 안 뽑는다', norm_strong('T-ASM') == '')
    chk('고유명사 태그', bool(PROPER.search('G2196=N-ASM-P')))
    chk('일반명사는 고유명사 아님', not PROPER.search('G3056=N-NSM'))
    chk('음역 꼬리 제거', PAREN.sub('', 'καὶ (kai)').strip() == 'καὶ')
    # ★ 본문 계열 판정 — 여기가 틀리면 **어느 사본에도 없는 글**이 배포된다.
    chk('모든 편집본에 있는 낱말', in_na('NKO'))
    chk('비평본문에만 있는 낱말', in_na('NO') and in_na('no'))
    chk('괄호는 걷어 낸다 (N(k)O)', in_na('N(k)O'))
    chk('TR 전용은 뺀다 (K)', not in_na('K'))
    chk('TR 전용 소문자도 (k·ko·K(o))',
        not in_na('k') and not in_na('ko') and not in_na('K(o)'))
    chk('기타 전용도 뺀다 (O·o)', not in_na('O') and not in_na('o'))
    chk('괄호 안 N 은 있는 것이 아니다', not in_na('K(N)'))

    # ③ 정렬 — 인위로 한 절 민 자료를 넣으면 반드시 잡혀야 한다.
    #    이 검사가 없으면 「전부 OK」를 찍는 껍데기가 된다 (temp_code_greek_check 전례).
    if not all(os.path.exists(os.path.join(RAW, f)) for f in FILES):
        print('  [SKIP] TAGNT 자료 없음 — 정렬 탐지력 검사 못 함')
        print('selftest', 'PASS' if ok else 'FAIL')
        return ok
    import appdb
    conn = appdb.connect()
    w = [x for x in read_words() if x[0] == 40 and x[1] <= 4]      # 마태 1~4장
    g = group(w)
    s0, n0 = align_score(conn, g, 0)
    chk('정상 자료가 높은 점수 (>0.55, 실제 %.2f · 표본 %d)' % (s0, n0), s0 > 0.55 and n0 > 30)
    shifted = collections.OrderedDict()
    for (bc, ch, vs), v in g.items():
        shifted[(bc, ch, vs + 1)] = v                              # 인위 밀림
    s1, _ = align_score(conn, shifted, 0)
    chk('한 절 민 자료를 잡는다 (%.2f → %.2f)' % (s0, s1), s1 < s0 - 0.15)
    # ④ 빌드 결과가 있으면 **빈도 높은 낱말이 0건이 아닌지** 본다.
    #    파싱이 반쯤 죽어도 정렬 검사는 통과한다 — 그 구멍을 여기서 막는다.
    if os.path.exists(OUT_DB):
        gdb = sqlite3.connect(OUT_DB)
        for code, nm, lo in (('G4102', '피스티스', 150), ('G26', '아가페', 80),
                             ('G5485', '카리스', 120), ('G2424', '예수', 800)):
            n = gdb.execute("SELECT COUNT(*) FROM gnt_verse WHERE ' '||strongs||' ' LIKE ?",
                            ('%% %s %%' % code,)).fetchone()[0]
            chk('%s(%s) %d절 이상 (실제 %d)' % (nm, code, lo, n), n >= lo)
        gdb.close()
    else:
        print('  [SKIP] gnt_verify.db 없음 — 빈도 검사 못 함')
    conn.close()

    print('selftest', 'PASS' if ok else 'FAIL')
    return ok


if __name__ == '__main__':
    a = sys.argv
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect()
    words = read_words()
    print('낱말 %d개' % len(words))
    g = group(words)
    print('절 %d개' % len(g))
    if '--align' in a or '--build' in a:
        print('[정렬 검사]')
        good = align(conn, g)
        print('  =>', 'PASS' if good else 'FAIL — 저장하지 않는다')
        if '--build' in a:
            if not good:
                sys.exit(1)
            print('[저장]')
            build(conn, g)
    if '--load-text' in a:
        print('[본문 적재 — bible_content]')
        load_text(conn)
