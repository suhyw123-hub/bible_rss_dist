# -*- coding: utf-8 -*-
"""book_shelf.py — 「서재」 도서 탐색 대시보드 (영구 부품 · `--selftest` 의무)
================================================================================

사용자 지시(0.txt 8번):
  「도서/설교가 많아지고 있다 … **한눈에 등록된 모든 도서를 파악할 수 있도록
    분류하는 탐색 대시보드**를 만들고 싶다」

★★ **트리가 부족해서가 아니라 「축」이 하나뿐이라서 만든다.** 실측 — 35권을
  7분류에 나누면 분류당 5권이라 트리 자체는 아직 안 무너진다. 진짜 결핍은
  **`book_category` 말고는 훑을 길이 없다**는 것이고, **소개문이 35/35 다 있는데
  책을 골라 들어가야만 보인다**는 것이다.

★★★ 필터 = **묶음 안 OR · 묶음 사이 AND** (2026-08-24 사용자 확정)
--------------------------------------------------------------------------
  「분류/분량/연대 각각에 대해 **옵션값(전체 포함)을 적용하는 멀티옵션 방식**.
    **읽은 것은 모든 필터링에서 공통 적용되는 체크박스**로 두자.
    **저자를 옵션으로 사용하지는 못한다. 정렬기준이 맞는 것 같다.**
    정렬 기준은 위 옵션 버튼과 혼동하기 쉽다. 따라서 **다른 것으로 표시**하라」

  ⇒ 분류·분량·연대 = **체크박스 세 줄**(`plan_builder.FilterRow` — 새로 만들지
    않는다. 그 부품이 「한 차원에 한 줄」 규격의 단일 소스다) ·
    읽은 것 = **공통 체크박스 하나** · 정렬 = **가로선 아래 라디오버튼**.

★★ 분량의 자 = **글자 수(어림 쪽수)** 이지 편이 아니다 (2026-08-24 개정)
--------------------------------------------------------------------------
  실측 — 편당 글자가 1,085 ~ 372,255 로 **343배** 벌어져, 천로역정은 **2편인데
  74만 자**이고 디다케는 **16편에 1.7만 자**다. 편 수로 재면 순서가 뒤집힌다.

  ⚠⚠ 한때 「유닛(파트)」으로 쟀으나 **파트를 전량 폐기했다**(사용자 「다시는
    파트 따위의 설계를 하지 마라」). 파트는 본문을 우리가 자른 가짜 단위였다.
    ⇒ 이제 **저자가 쓴 글의 글자 수**를 재고 **1,800자 = 1쪽**으로 어림한다.
      실측 31/35권이 옛 파트 수와 ±35% 안이라 **같은 정보**이고 이름만 정직해졌다.
  ★ 값은 `sys_book_asset.body_chars`(`db_book_chars --apply`)에 담긴다 —
    그때그때 세면 **788ms**(스펄전 130MB), 캐시는 **0.1ms**.

★ **담는 것은 `sys_book_asset` 뿐**(도서 30 + 설교 5). 교리자료는 다른 표
  (`sys_ref_*`)이고 성격도 다르다(읽는 것이 아니라 찾아보는 것).

⏭ **다운로드 표식은 아직 넣지 않았다** — 서버·팩 인프라가 0이라 지금 넣으면
  「설치됨」이 늘 참인 **가짜 상태**가 된다(§0-1). 다만 그날 표식만 켜면 되도록
  `fetch` 가 **본문 보유 여부(`has_text`)를 이미 함께 읽는다**.
"""

import os
import sys
import tkinter as tk
from tkinter import ttk

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

import appdb
import i18n
from plan_builder import FilterRow

# 분류 — 화면 이름은 `p1_reading_view._CATEGORY_LABELS` 와 같은 말을 쓴다.
#   ⚠ 여기서 이름을 새로 짓지 말 것(두 화면이 다른 말을 쓰면 같은 책이 달라 보인다).
CAT_ORDER = ('DEVOTIONAL', 'SPIRITUALITY', 'DOCTRINE', 'SERMON',
             'BIOGRAPHY', 'HISTORY', 'FICTION')

# 분량 5구간 — **실측 분포에서 골랐다**(35권을 7·7·9·9·3 으로 가른다).
#   ⚠ 눈대중으로 자르면 한 칸에 1권, 다른 칸에 17권이 된다(첫 안이 그랬다).
#   단위는 **어림 쪽수**(`db_book_chars.pages` — 1,800자 = 1쪽).
SIZE_BANDS = (('S1', 'BS_SZ1', '~50쪽',        0,      50),
              ('S2', 'BS_SZ2', '51~150쪽',    51,     150),
              ('S3', 'BS_SZ3', '151~300쪽',  151,     300),
              ('S4', 'BS_SZ4', '301~1000쪽', 301,    1000),
              ('S5', 'BS_SZ5', '1001쪽~',   1001, 10 ** 9))

# 연대 3구간 (사용자 확정) — 실측 8 · 10 · 17.
#   ⚠ 5구간으로 자르면 한 칸이 1권이 된다(실측). 3구간이 고른 유일한 나눔이다.
ERA_BANDS = (('E1', 'BS_ERA1', '고대~1500',      0, 1500),
             ('E2', 'BS_ERA2', '1501~1850',  1501, 1850),
             ('E3', 'BS_ERA3', '1851~',      1851, 9999))

# 정렬 — **필터가 아니다**(사용자: 「저자를 옵션으로 쓰지는 못한다」).
# ★★ **「읽을 차례」를 맨 앞에** (2026-08-31 사용자 「서재 대시보드 자체 내에서
#   읽기 우선순위에 따라 표시하도록 **체크박스 하나 배치하고 우선순위 조정
#   (위/아래)하는 화면**을 배치하면 될 것 같다」).
#   ⇒ 새 화면을 안 만든다 — **정렬 갈래 하나**를 더하고 그 갈래일 때만 카드에
#     순위와 ▲▼ 가 뜬다. 서재가 이미 카드 격자·필터를 갖고 있다.
# ⚠ **「읽을 차례」는 정렬이 아니라 모드다** (2026-08-31 사용자 「도서서재에서
#   읽을차례 버튼이 **정렬기능에 표시되어 있다**. 읽은 것만 버튼 오른쪽에 여백을
#   두고 배치하라」 — 앞서 말한 「**체크박스 하나**」가 원래 뜻이었다).
#   켜면 순위와 ▲▼ 가 뜬다 — 분류·저자와 같은 층이 아니다. ⇒ 아래 목록에서
#   빼고 「읽은 것만」 오른쪽에 체크로 둔다.
SORTS = (('cat', 'BS_SORT_CAT', '분류'),
         ('author', 'BS_SORT_AUTHOR', '저자'),
         ('year', 'BS_SORT_YEAR', '연대'),
         ('size', 'BS_SORT_SIZE', '분량'))

CARD_W = 232          # 카드 한 장 폭(실측으로 정한 값 — 셋이 700px 에 들어간다)
DESC_CHARS = 78       # 소개문 미리보기 길이


def _C(role, fallback):
    try:
        import ui_theme
        return ui_theme.C(role) or fallback
    except Exception:
        return fallback


def band_of(value, bands):
    """그 값이 드는 구간 코드. 어느 구간에도 안 들면 `None`."""
    for code, _ikey, _lbl, lo, hi in bands:
        if lo <= value <= hi:
            return code
    return None


def fetch(db_path, lang='KO'):
    """[{book_id, title, orig, author, cat, year, units, pages, has_text, read, desc}].

    ⚠ 책마다 따로 물으면 35번이 아니라 **35×4번**이 된다(제목·유닛·읽음·소개문).
      한 방에 모아 온다 — 책이 늘어도 질의 수는 그대로다.
    ⚠ `pages`(어림 쪽수)는 **`sys_book_asset.body_chars`** 에서 온다. 그때그때
      세면 788ms 다(스펄전 130MB) — 그 칸은 `db_book_chars --apply` 가 채운다.
      **비어 있으면 0 이고 그것이 정직하다** — 편 수로 물러서면 천로역정(2편)이
      「~50쪽」 칸에 들어가 거짓이 된다.
    ⚠ `has_text` 는 **본문을 실제로 가졌는가**. 지금은 전권 참이지만, 팩 배포가
      생기면 그날 「받은 것/안 받은 것」이 이 값 하나로 갈린다.
    """
    out = []
    import book_langs                       # ★ 2026-10-31 번역 없는 책은 그 언어에서 감춘다(docs/통계_설계.md §9)
    vis = book_langs.visible_for(db_path, lang)
    try:
        with appdb.connect(db_path) as c:
            agg = {r[0]: (r[1], 0) for r in c.execute(
                "SELECT book_id, COUNT(*) FROM sys_book_unit "
                "WHERE COALESCE(record_status,'LIVE')='LIVE' GROUP BY book_id")}
            # 어림 쪽수 — 캐시 칸이 없는 DB 도 견딘다(0 = 「아직 안 쟀다」)
            import db_book_chars as bc
            acols = [r[1] for r in c.execute('PRAGMA table_info(sys_book_asset)')]
            pg = ({r[0]: bc.pages(r[1]) for r in c.execute(
                      'SELECT book_id, %s FROM sys_book_asset' % bc.COL)}
                  if bc.COL in acols else {})
            has = {r[0] for r in c.execute(
                "SELECT DISTINCT u.book_id FROM sys_book_unit u "
                " JOIN sys_book_unit_text x ON x.unit_id = u.unit_id")}
            # 번역 제목 층 — 없으면 원제(§17 `sys_book_asset_text`)
            tr = {}
            try:
                for bid, t in c.execute(
                        "SELECT book_id, title FROM sys_book_asset_text "
                        "WHERE lang_code=? AND title IS NOT NULL", (lang,)):
                    tr[bid] = t
            except Exception:
                pass
            for bid, title, author, cat, year, desc in c.execute(
                    "SELECT book_id, title, author, book_category, pub_year, description "
                    "FROM sys_book_asset WHERE COALESCE(record_status,'LIVE')='LIVE'"):
                if vis is not None and bid not in vis:
                    continue
                n, p = agg.get(bid, (0, 0))
                out.append({
                    'book_id': bid,
                    'title': tr.get(bid) or title or '',
                    'orig': title or '',
                    'author': author or '',
                    'cat': cat or '',
                    'year': year or 0,
                    'units': n,
                    'pages': pg.get(bid, 0),
                    'has_text': bid in has,
                    'read': 0,
                    'desc': (desc or '').strip().replace('\n', ' '),
                })
    except Exception as e:
        print('[book_shelf fetch] %s' % e)
    return out


def sort_rows(rows, key, rank=None):
    """정렬 — 축마다 **두 번째 기준까지** 정한다(같은 값이 뭉치면 순서가 흔들린다).

    `rank` = `{book_id: 순위}`(읽을 차례). 주면 `key='order'` 가 그것을 따른다.
    ⚠ 차례에 없는 책은 **뒤에 분류순**으로 붙는다 — 빼지 않는다. 사용자가
      「다운로드 받지 않은 것도 조정 대상」이라 했듯 **후보에서 지우지 않는다.**
    """
    if key == 'order':
        rk = rank or {}
        order0 = {c: i for i, c in enumerate(CAT_ORDER)}
        return sorted(rows, key=lambda r: (
            0 if r['book_id'] in rk else 1,
            rk.get(r['book_id'], 0),
            order0.get(r['cat'], 99), r['title']))
    if key == 'author':
        return sorted(rows, key=lambda r: (r['author'] or '￿', r['title']))
    if key == 'year':
        # ⚠ 연대 미상(0)은 **맨 뒤로** — 앞에 두면 1418년보다 오래된 것처럼 보인다
        return sorted(rows, key=lambda r: (r['year'] == 0, r['year'], r['title']))
    if key == 'size':
        return sorted(rows, key=lambda r: (-r['pages'], r['title']))
    order = {c: i for i, c in enumerate(CAT_ORDER)}
    return sorted(rows, key=lambda r: (order.get(r['cat'], 99), r['title']))


def apply_filters(rows, cats, sizes, eras, read_only):
    """묶음 안 OR · 묶음 사이 AND. 순수 함수라 selftest 가 화면 없이 잰다."""
    out = []
    for r in rows:
        if cats is not None and r['cat'] not in cats:
            continue
        if sizes is not None and band_of(r['pages'], SIZE_BANDS) not in sizes:
            continue
        if eras is not None and band_of(r['year'], ERA_BANDS) not in eras:
            continue
        if read_only and not r.get('read'):
            continue
        out.append(r)
    return out


def empty_reason(rows, cats, sizes, eras, read_only):
    """0건일 때 **어느 묶음이 다 걷어냈는지** 한 줄로. 조용히 비면 고장으로 읽힌다.

    재는 방법 = 그 묶음만 풀었을 때 몇 권이 살아나는가.
    """
    if not rows:
        return i18n.t('BS_EMPTY_NONE', '등록된 도서가 없습니다.')
    trials = (
        ('BS_G_CAT', '분류', (None, sizes, eras, read_only)),
        ('BS_G_SIZE', '분량', (cats, None, eras, read_only)),
        ('BS_G_ERA', '연대', (cats, sizes, None, read_only)),
    )
    guilty = [i18n.t(k, d) for k, d, a in trials if apply_filters(rows, *a)]
    if read_only and apply_filters(rows, cats, sizes, eras, False):
        guilty.append(i18n.t('BS_READ_ONLY', '읽은 것만'))
    if guilty:
        return i18n.t('BS_EMPTY_BY',
                      '선택한 조건에 맞는 도서가 없습니다 — 「{g}」 조건을 넓혀 보세요.'
                      ).format(g=' · '.join(guilty))
    return i18n.t('BS_EMPTY_ALL', '선택한 조건에 맞는 도서가 없습니다.')


class BookShelf(tk.Frame):
    """서재 — 필터 세 줄 + 읽은 것 + 정렬 + 카드 격자."""

    ORDER_KIND = 'BOOK'          # 읽을 차례의 갈래(설교 서재는 'SERMON')
    on_order_changed = None      # 차례가 바뀌면 호스트(2단 콤보)에 알린다

    def __init__(self, parent, db_path, lang_getter=None, on_open=None,
                 cat_label=None, read_getter=None, only_cats=None,
                 on_download=None, **kw):
        """on_open(book_id) — 카드를 누르면 그 책을 도서읽기 갈래에서 연다.
        on_download(book_id) — **아직 안 받은 책**은 여기로(다운로드 화면).
        cat_label(code) → 사람이 읽는 분류 이름(도서 트리와 **같은 말**을 쓴다).
        read_getter(book_id) → 읽은 유닛 수(없으면 0).
        only_cats — 담을 분류(없으면 전부).

        ⚠ **설교집(`SERMON`)은 여기서 뺀다** — 편이 3,573개라 카드로 못 그린다.
          설교는 `sermon_shelf`(목록)가 맡는다. 두 화면의 단위가 다르다.
        """
        super().__init__(parent, **kw)
        self.only_cats = set(only_cats) if only_cats else None
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.on_open = on_open
        self.cat_label = cat_label or (lambda c: c)
        self.read_getter = read_getter
        self.on_download = on_download
        self._rows = []
        self._sort = tk.StringVar(value='cat')
        self._read_only = tk.BooleanVar(value=False)
        self._f_cat = self._f_size = self._f_era = None
        self._built_bar = False
        self._build()

    # ── 화면 ──────────────────────────────────────────────────────────────
    def _build(self):
        bg = _C('bg', '#FDFEFE')
        self.configure(bg=bg)
        pnl = _C('panel_alt', '#F4F6F7')
        self._bar = tk.Frame(self, bg=pnl)
        self._bar.pack(fill='x')
        # ⚠ FilterRow 는 **부모의 grid 에 직접** 놓는다 — 줄마다 프레임으로 감싸면
        #   라벨 열이 어긋나 「줄줄이」가 안 된다.
        self._opt_f = tk.Frame(self._bar, bg=pnl)
        self._opt_f.pack(fill='x', padx=6, pady=(4, 2))
        ttk.Separator(self._bar, orient='horizontal').pack(fill='x', padx=6)
        self._sort_f = tk.Frame(self._bar, bg=pnl)
        self._sort_f.pack(fill='x', padx=6, pady=(3, 4))

        wrap = tk.Frame(self, bg=bg)
        wrap.pack(fill='both', expand=True)
        self._cv = tk.Canvas(wrap, bg=bg, highlightthickness=0)
        sb = ttk.Scrollbar(wrap, orient='vertical', command=self._cv.yview)
        self._cv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._cv.pack(side='left', fill='both', expand=True)
        self._grid = tk.Frame(self._cv, bg=bg)
        self._win = self._cv.create_window((0, 0), window=self._grid, anchor='nw')
        self._grid.bind('<Configure>',
                        lambda e: self._cv.config(scrollregion=self._cv.bbox('all')))
        # ⚠ 안쪽 폭을 캔버스에 맞춘다 — 안 맞추면 카드가 왼쪽에 몰린다
        self._cv.bind('<Configure>', self._on_resize)
        # ⚠ 자식 위젯이 휠을 먹으므로 들어올 때 `bind_all`, 나갈 때 푼다
        #   (카드는 다시 그릴 때마다 새로 만들어져 하나씩 걸 수 없다 — 묵상노트와 같다)
        wrap.bind('<Enter>', lambda _e: self._cv.bind_all('<MouseWheel>', self._wheel))
        wrap.bind('<Leave>', lambda _e: self._cv.unbind_all('<MouseWheel>'))
        self._cols = 0

    def _wheel(self, e):
        try:
            self._cv.yview_scroll(-1 if e.delta > 0 else 1, 'units')
        except Exception:
            pass

    def _on_resize(self, e):
        self._cv.itemconfig(self._win, width=e.width)
        cols = max(1, e.width // CARD_W)
        if cols != self._cols:      # 칸 수가 바뀔 때만 다시 그린다
            self._cols = cols
            self._render()

    # ── 데이터 ────────────────────────────────────────────────────────────
    def reload(self):
        self._rows = fetch(self.db_path, (self.lang_getter() or 'KO').upper())
        if self.only_cats is not None:
            self._rows = [r for r in self._rows if r['cat'] in self.only_cats]
        if callable(self.read_getter):
            for r in self._rows:
                try:
                    r['read'] = int(self.read_getter(r['book_id']) or 0)
                except Exception:
                    r['read'] = 0
        self._build_bar()
        self._render()

    def _build_bar(self):
        """필터 줄은 **한 번만 짓는다** — 다시 지으면 사용자가 켠 체크가 풀린다."""
        if self._built_bar:
            self._sync_count()
            return
        pnl = _C('panel_alt', '#F4F6F7')

        used = {r['cat'] for r in self._rows}
        cats = [c for c in CAT_ORDER if c in used]
        self._f_cat = FilterRow(self._opt_f, 0, i18n.t('BS_G_CAT', '분류'), cats,
                                {c: self.cat_label(c) for c in cats}, self._render)
        self._f_size = FilterRow(self._opt_f, 1, i18n.t('BS_G_SIZE', '분량'),
                                 [b[0] for b in SIZE_BANDS],
                                 {b[0]: i18n.t(b[1], b[2]) for b in SIZE_BANDS},
                                 self._render)
        self._f_era = FilterRow(self._opt_f, 2, i18n.t('BS_G_ERA', '연대'),
                                [b[0] for b in ERA_BANDS],
                                {b[0]: i18n.t(b[1], b[2]) for b in ERA_BANDS},
                                self._render)

        # 정렬 = **라디오버튼**(사용자: 「위 옵션 버튼과 혼동하기 쉬우니 다른 것으로」)
        tk.Label(self._sort_f, text=i18n.t('BS_SORT', '정렬'), bg=pnl,
                 fg=_C('fg_dim', '#7F8C8D')).pack(side='left', padx=(2, 8))
        for key, ikey, dflt in SORTS:
            ttk.Radiobutton(self._sort_f, text=i18n.t(ikey, dflt),
                            value=key, variable=self._sort,
                            command=self._render).pack(side='left', padx=(0, 10))
        # 읽은 것 = **모든 필터에 공통으로 얹히는 하나**(사용자 확정)
        ttk.Checkbutton(self._sort_f,
                        text=i18n.t('BS_READ_ONLY', '읽은 것만'),
                        variable=self._read_only,
                        command=self._render).pack(side='left', padx=(24, 0))
        # ★ **읽을 차례 = 체크박스** — 켜면 순위·▲▼·[＋ 차례에] 가 뜬다.
        self._order_on = tk.BooleanVar(value=False)
        ttk.Checkbutton(self._sort_f,
                        text=i18n.t('BS_SORT_ORDER', '읽을 차례'),
                        variable=self._order_on,
                        command=self._render).pack(side='left', padx=(24, 0))
        self._cnt_lbl = tk.Label(self._sort_f, text='', bg=pnl,
                                 fg=_C('fg_dim', '#7F8C8D'))
        self._cnt_lbl.pack(side='right', padx=(0, 4))
        self._built_bar = True

    def _sel(self):
        """(분류, 분량, 연대) — 「전체」면 `None`(거르지 않는다)."""
        def s(f):
            if f is None or f.is_all():
                return None
            return set(f.get_selected())
        return s(self._f_cat), s(self._f_size), s(self._f_era)

    def visible(self):
        cats, sizes, eras = self._sel()
        rows = apply_filters(self._rows, cats, sizes, eras, self._read_only.get())
        return sort_rows(rows, 'order' if self.order_mode() else self._sort.get(),
                         self._rank())

    def order_mode(self):
        """읽을 차례 모드인가 — 체크박스 하나가 정한다."""
        try:
            return bool(self._order_on.get())
        except Exception:
            return False

    def _rank(self):
        """읽을 차례 `{book_id: 순위}` — 다 읽은 것은 빠지고 번호가 다시 매겨진다."""
        if not self.order_mode():
            return {}
        try:
            import read_order, appdb as _a
            fin = {r['book_id'] for r in self._rows
                   if r.get('units') and r.get('read', 0) >= r['units']}
            with _a.connect(self.db_path) as c:
                return read_order.rank_map(c, self.ORDER_KIND, fin)
        except Exception as e:
            print('[shelf rank] %s' % e)
            return {}

    def _order_add(self, book_id):
        self._order_edit('add', book_id)

    def _order_drop(self, book_id):
        self._order_edit('remove', book_id)

    def _order_edit(self, what, book_id):
        """차례에 담거나 뺀다 — **책을 지우는 것이 아니다.**"""
        try:
            import read_order, appdb as _a
            with _a.connect(self.db_path) as c:
                getattr(read_order, what)(c, self.ORDER_KIND, book_id)
        except Exception as e:
            print('[shelf order %s] %s' % (what, e))
            return
        self._render()
        self._sync_count()
        if callable(getattr(self, 'on_order_changed', None)):
            self.on_order_changed()

    def _move(self, book_id, delta):
        """▲▼ 한 칸 — 누르면 그 자리에서 다시 그린다."""
        try:
            import read_order, appdb as _a
            with _a.connect(self.db_path) as c:
                read_order.move(c, self.ORDER_KIND, book_id, delta)
        except Exception as e:
            print('[shelf move] %s' % e)
            return
        self._render()
        self._sync_count()
        if callable(getattr(self, 'on_order_changed', None)):
            self.on_order_changed()

    def _sync_count(self):
        try:
            n = len(self.visible())
            self._cnt_lbl.config(
                text=i18n.t('BS_COUNT', '{n}권').format(n=n)
                if n == len(self._rows) else
                i18n.t('BS_COUNT_OF', '{n} / {t}권').format(n=n, t=len(self._rows)))
        except Exception:
            pass

    # ── 카드 ──────────────────────────────────────────────────────────────
    def _render(self, *_a):
        for w in self._grid.winfo_children():
            w.destroy()
        rows = self.visible()
        rk = self._rank()
        cols = max(1, self._cols or 3)
        for i, r in enumerate(rows):
            self._card(self._grid, r, rk).grid(row=i // cols, column=i % cols,
                                               padx=4, pady=4, sticky='nsew')
        for c in range(cols):
            self._grid.columnconfigure(c, weight=1, uniform='shelf')
        if not rows:
            # ★ **왜 비었는지 말한다**(§0 no silent caps) — 조용히 비면 고장으로 읽힌다
            cats, sizes, eras = self._sel()
            tk.Label(self._grid,
                     text=empty_reason(self._rows, cats, sizes, eras,
                                       self._read_only.get()),
                     bg=_C('bg', '#FDFEFE'), fg=_C('fg_dim', '#95A5A6'),
                     wraplength=560, justify='left'
                     ).grid(row=0, column=0, padx=12, pady=14, sticky='w')
        self._sync_count()

    def _size_text(self, r):
        """「N편 · 약 M쪽」 — 쪽수를 아직 안 쟀으면 **편 수만** 적는다.

        ⚠ 「약」을 붙인다 — 1,800자 어림이라 정확한 값이 아니다. 빼면 인쇄본
          쪽수로 읽힌다.
        """
        n, p = r['units'], r['pages']
        if not n:
            return ''
        if p:
            return i18n.t('BS_UNITS2', '{n}편 · 약 {p}쪽').format(
                n='{:,}'.format(n), p='{:,}'.format(p))
        return i18n.t('BS_UNITS', '{n}편').format(n='{:,}'.format(n))

    def _card(self, parent, r, rank=None):
        pnl = _C('panel', '#FFFFFF')
        hov = _C('accent_bg', '#EAF2F8')
        # ★★ **안 받은 책** (2026-08-24 사용자 「다운로드 받지 않았다면 도서 탭으로
        #   가면 안 된다. 다운로드 화면으로 가야 한다」).
        #   ⚠ 표식을 읽음 축(●/○)과 **섞지 않는다** — 두 축을 한 글자에 넣으면
        #     4상태가 되어 아무도 못 읽는다. 다운로드는 **카드 상태**로 말한다:
        #     제목을 흐리게 + 아래에 「↓ 받기」.
        #   ⚠ `⤓ ⇩ ⬇` 는 맑은 고딕·굴림·바탕 **셋 다 없다**(cmap 실측). `↓` 는 있다.
        #   ⚠ 오늘은 35/35 가 본문을 가져 이 길이 안 열린다. **가짜 상태를 짓지
        #     않으려고** 필터는 아직 안 만들었다 — 팩이 생기면 그때 켠다.
        got = r.get('has_text', True)
        f = tk.Frame(parent, bg=pnl, bd=1, relief='solid', cursor='hand2')
        # ★★ **읽을 차례일 때만** 순위와 ▲▼ (2026-08-31). 다른 정렬에서는
        #   줄째 안 만든다 — 늘 두면 카드가 그만큼 길어진다.
        _rk = (rank or {}).get(r['book_id'])
        _ord = self.order_mode()
        if _ord:
            row = tk.Frame(f, bg=pnl)
            row.pack(fill='x', padx=8, pady=(6, 0))
            if _rk:
                tk.Label(row, text='%d' % _rk, bg=pnl, font=('', 11, 'bold'),
                         fg=_C('accent', '#2E86C1')).pack(side='left')
                # ✕ = **차례에서만 뺀다**(책을 지우는 것이 아니다)
                tk.Button(row, text='✕', bg=pnl, bd=0, relief='flat',
                          font=('', 8), cursor='hand2', padx=3, pady=0,
                          fg=_C('fg_dim', '#7F8C8D'),
                          command=lambda b=r['book_id']: self._order_drop(b)
                          ).pack(side='right', padx=(6, 0))
                for _t, _d in (('▼', +1), ('▲', -1)):
                    tk.Button(row, text=_t, bg=pnl, bd=0, relief='flat',
                              font=('', 8), cursor='hand2', padx=3, pady=0,
                              command=lambda b=r['book_id'], d=_d: self._move(b, d)
                              ).pack(side='right')
            else:
                # ★★ **차례에 없는 책은 여기서 담는다** (2026-08-31 사용자
                #   「콤보에서 차례조정 → 읽을차례 체크 → **어떻게 조정하는가?**」).
                #   ⚠ 그전에는 담는 길이 **소개문의 ♥ 뿐**이라, 조정 화면에
                #     와서도 새로 담을 수 없었다 — 반쪽이었다.
                tk.Button(row, text=i18n.t('BS_ORDER_ADD', '＋ 차례에'),
                          bg=pnl, bd=0, relief='flat', font=('', 8),
                          cursor='hand2', padx=3, pady=0,
                          fg=_C('accent', '#2E86C1'),
                          command=lambda b=r['book_id']: self._order_add(b)
                          ).pack(side='right')
        mark = ('●' if r.get('read') else '○') if got else '↓'
        tk.Label(f, text='%s %s' % (mark, r['title']), bg=pnl,
                 fg=_C('fg_title', '#1A5276') if got else _C('fg_dim', '#95A5A6'),
                 font=('', 10, 'bold'),
                 anchor='w', justify='left', wraplength=CARD_W - 24
                 ).pack(fill='x', padx=8, pady=(6, 0))
        # ★ **원제를 늘 함께** (0.txt 8-1 — 「다국어 모드로 조회하더라도 항상
        #   원문의 제목을 표시하자」). 번역 제목과 같으면 두 번 안 적는다.
        if r['orig'] and r['orig'] != r['title']:
            tk.Label(f, text=r['orig'], bg=pnl, fg=_C('fg_dim', '#7F8C8D'),
                     font=('', 8), anchor='w', justify='left',
                     wraplength=CARD_W - 24).pack(fill='x', padx=8)
        meta = ' · '.join([x for x in (
            r['author'], self.cat_label(r['cat']),
            (str(r['year']) if r['year'] else ''), self._size_text(r)
        ) if x])
        tk.Label(f, text=meta, bg=pnl, fg=_C('accent', '#1A5276'), font=('', 8),
                 anchor='w', justify='left', wraplength=CARD_W - 24
                 ).pack(fill='x', padx=8, pady=(3, 0))
        d = r['desc']
        if d:
            tk.Label(f, text=(d[:DESC_CHARS] + '…') if len(d) > DESC_CHARS else d,
                     bg=pnl, fg=_C('fg', '#2C3E50'), font=('', 8), anchor='w',
                     justify='left', wraplength=CARD_W - 24
                     ).pack(fill='x', padx=8, pady=(4, 7))

        if not got:
            tk.Label(f, text=i18n.t('BS_GET', '↓ 받기'), bg=pnl,
                     fg=_C('warning', '#B7950B'), font=('', 8, 'bold'),
                     anchor='w').pack(fill='x', padx=8, pady=(0, 6))

        def _click(_e=None, bid=r['book_id'], ok=got):
            # ★★★ **받았든 안 받았든 소개문으로 간다** (2026-08-31 사용자 지적
            #   「코어팩 상태에서 클릭하면 도서소개문을 읽고 다운로드 받을 수
            #   있는 화면으로 연결되는가? **도서소개문 없이 곧장 설정/다운로드
            #   화면으로 이동하는가**」).
            #   ⚠⚠ 그전에는 안 받은 책이 **곧장 다운로드 화면**이었다 —
            #     소개문을 못 읽으니 **♥ 를 누를 수 없고**, 그러면 읽을 차례의
            #     후보가 될 길이 아예 없었다(막다른 골목).
            #   ⚠ 받은 책도 소개문을 건너뛰고 **첫 편**으로 갔다 — 서재는
            #     「무엇을 읽을까」를 고르는 자리인데 곧장 본문을 폈다.
            #   ⇒ 한 화면에서 **읽고 · 담고(♥) · 받는다**. 다운로드는 그 안의
            #     [↓ 받기]가 맡는다(`on_download` 는 그대로 쓰인다).
            if callable(self.on_open):
                self.on_open(bid)

        def _paint(w, bg):
            try:
                w.config(bg=bg)
            except Exception:
                pass
            for ch in w.winfo_children():
                _paint(ch, bg)

        for w in [f] + f.winfo_children():
            w.bind('<Button-1>', _click)
            w.bind('<Enter>', lambda _e, x=f: _paint(x, hov))
            w.bind('<Leave>', lambda _e, x=f: _paint(x, pnl))
        return f


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def _selftest():
    ok = fail = 0

    def t(name, cond, extra=''):
        nonlocal ok, fail
        if cond:
            ok += 1
        else:
            fail += 1
            print('  FAIL %s %s' % (name, extra))

    db = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bible_master.db')
    rows = fetch(db, 'KO')
    t('책을 읽어 온다', len(rows) >= 30, len(rows))
    t('제목이 다 있다', all(r['title'] for r in rows))
    with appdb.connect(db) as _c:
        _chars = {r[0]: (r[1] or 0) for r in _c.execute(
            'SELECT book_id, body_chars FROM sys_book_asset')}
    t('원제가 다 있다', all(r['orig'] for r in rows))
    t('편 수가 붙는다', sum(r['units'] for r in rows) > 5000)
    # ⚠ 쪽수는 편 수와 무관하다 — 2편에 414쪽(천로역정)도 있고 66편에 44쪽
    #   (클레멘트)도 있다. **그 어긋남을 쓰려고** 이 자를 쓴다.
    t('본문 있는 책은 쪽수가 있다',
      all(r['pages'] > 0 for r in rows if r['has_text']),
      [r['title'] for r in rows if r['has_text'] and not r['pages']][:3])
    t('본문 없는 책은 0쪽', all(r['pages'] == 0 for r in rows if not r['has_text']))
    t('쪽수로 재면 편과 순서가 달라진다',
      [r['book_id'] for r in sort_rows(rows, 'size')]
      != [r['book_id'] for r in sorted(rows, key=lambda x: -x['units'])])
    # ⚠⚠ **파트가 되살아나지 않는가** — 편 수보다 큰 「우리가 만든 단위」를
    #   다시 세면 안 된다. 쪽수는 **글자에서 나온 어림값**이라 편과 무관해야 한다.
    import db_book_chars as _bc
    t('쪽수가 글자에서 나온다',
      all(r['pages'] == _bc.pages(ch) for r, ch in
          [(x, _chars.get(x['book_id'], 0)) for x in rows]))
    t('소개문이 다 있다', all(r['desc'] for r in rows),
      [r['title'] for r in rows if not r['desc']][:3])
    # ⚠ **「전권이 본문을 갖는다」로 재지 않는다** — 명단에만 올린 책
    #   (`db_book_catalog`)이 생기면 곧바로 깨진다. 실제로 깨졌다(2026-08-24).
    #   **결함을 고치거나 자료를 더하는 것이 본업인 저장소에서 「지금 데이터가
    #   이렇다」를 전제한 검사는 반드시 깨진다**(§0-5).
    #   ⇒ 재는 것은 **칸을 제대로 읽는가**다.
    t('본문 보유를 참·거짓으로 읽는다',
      all(isinstance(r['has_text'], bool) for r in rows))
    t('본문 있는 책이 대부분이다', sum(1 for r in rows if r['has_text']) >= 30,
      sum(1 for r in rows if r['has_text']))
    t('편이 있으면 본문도 있다',
      all(r['has_text'] for r in rows if r['units'] > 0),
      [r['title'] for r in rows if r['units'] > 0 and not r['has_text']][:3])

    # ★ 구간이 **모든 책을 하나씩** 담는가 (경계에 구멍이 있으면 책이 사라진다)
    t('분량 구간이 전 책을 덮는다',
      all(band_of(r['pages'], SIZE_BANDS) for r in rows),
      [(r['title'], r['pages']) for r in rows if not band_of(r['pages'], SIZE_BANDS)][:3])
    t('연대 구간이 전 책을 덮는다',
      all(band_of(r['year'], ERA_BANDS) for r in rows),
      [(r['title'], r['year']) for r in rows if not band_of(r['year'], ERA_BANDS)][:3])
    t('구간이 겹치지 않는다',
      all(SIZE_BANDS[i][4] + 1 == SIZE_BANDS[i + 1][3] for i in range(len(SIZE_BANDS) - 1))
      and all(ERA_BANDS[i][4] + 1 == ERA_BANDS[i + 1][3] for i in range(len(ERA_BANDS) - 1)))
    # 구간마다 실제로 책이 있는가 — 빈 서랍에 단추를 만들지 않는다(§4-⑤)
    for code, _ik, lbl, _lo, _hi in SIZE_BANDS:
        t('분량 「%s」 에 책이 있다' % lbl,
          any(band_of(r['pages'], SIZE_BANDS) == code for r in rows))
    for code, _ik, lbl, _lo, _hi in ERA_BANDS:
        t('연대 「%s」 에 책이 있다' % lbl,
          any(band_of(r['year'], ERA_BANDS) == code for r in rows))

    # ★ 묶음 안 OR · 묶음 사이 AND
    t('전체면 다 나온다',
      len(apply_filters(rows, None, None, None, False)) == len(rows))
    s1 = {'S1'}
    t('분량 한 칸만 선택하면 그 칸만',
      all(band_of(r['pages'], SIZE_BANDS) in s1
          for r in apply_filters(rows, None, s1, None, False)))
    two = {'S1', 'S2'}
    t('두 칸은 합집합(OR)',
      len(apply_filters(rows, None, two, None, False))
      == len(apply_filters(rows, None, {'S1'}, None, False))
      + len(apply_filters(rows, None, {'S2'}, None, False)))
    cat1 = {rows[0]['cat']}
    both = apply_filters(rows, cat1, s1, None, False)
    t('묶음 사이는 교집합(AND)',
      all(r['cat'] in cat1 and band_of(r['pages'], SIZE_BANDS) in s1 for r in both))
    t('AND 는 각각보다 크지 않다',
      len(both) <= min(len(apply_filters(rows, cat1, None, None, False)),
                       len(apply_filters(rows, None, s1, None, False))))
    for r in rows:
        r['read'] = 1 if r['book_id'] % 2 == 0 else 0
    t('읽은 것만은 모든 필터 위에 얹힌다',
      all(r['read'] for r in apply_filters(rows, cat1, None, None, True)))
    for r in rows:
        r['read'] = 0

    # ★ 0건이면 **이유를 말한다**
    msg = empty_reason(rows, {'DEVOTIONAL'}, {'S1'}, None, False)
    t('0건 이유가 묶음을 짚는다', '분량' in msg or '분류' in msg, msg)
    t('0건 이유가 빈 글이 아니다', bool(msg.strip()))

    # ★ 정렬 — **한 축도 책을 잃거나 더하지 않는다**
    for key, _i, _d in SORTS:
        s = sort_rows(rows, key)
        t('정렬 %s 가 같은 집합이다' % key,
          {r['book_id'] for r in s} == {r['book_id'] for r in rows})
    y = sort_rows(rows, 'year')
    zero = [i for i, r in enumerate(y) if r['year'] == 0]
    t('연대 미상은 맨 뒤', (not zero) or min(zero) >= len(y) - len(zero), zero[:3])
    z = sort_rows(rows, 'size')
    t('분량은 큰 것부터',
      all(z[i]['pages'] >= z[i + 1]['pages'] for i in range(len(z) - 1)))

    try:
        root = tk.Tk()
        root.geometry('1100x700')
    except Exception:
        print('  (건너뜀) Tk 없음')
        print('selftest %d/%d' % (ok, ok + fail))
        return fail == 0
    try:
        opened = []
        sh = BookShelf(root, db, lambda: 'KO', on_open=opened.append,
                       cat_label=lambda c: c)
        sh.pack(fill='both', expand=True)
        root.update()
        sh.reload()
        root.update()
        t('카드가 그려진다', len(sh._grid.winfo_children()) == len(rows),
          '%d/%d' % (len(sh._grid.winfo_children()), len(rows)))
        # 필터를 실제로 만져 본다
        sh._f_size._all_var.set(False)
        for k, v in sh._f_size._vars.items():
            v.set(k == 'S1')
        sh._render()
        root.update()
        want = len(apply_filters(rows, None, {'S1'}, None, False))
        t('체크박스를 만지면 그만큼만', len(sh.visible()) == want,
          '%d/%d' % (len(sh.visible()), want))
        t('개수 라벨이 부분을 알린다', '/' in sh._cnt_lbl.cget('text'),
          sh._cnt_lbl.cget('text'))
        # 전부 끄면 0건 + 이유
        for v in sh._f_size._vars.values():
            v.set(False)
        sh._render()
        root.update()
        t('전부 끄면 0건', len(sh.visible()) == 0)
        kids = sh._grid.winfo_children()
        t('0건이면 이유가 뜬다',
          len(kids) == 1 and bool(kids[0].cget('text').strip()),
          kids[0].cget('text') if kids else '(없음)')
        # 되돌리기
        sh._f_size._all_var.set(True)
        sh._f_size._on_all()
        root.update()
        t('전체로 돌아온다', len(sh.visible()) == len(rows))
        # 정렬 라디오
        sh._sort.set('year')
        sh._render()
        root.update()
        t('정렬을 바꿔도 책 수는 그대로', len(sh.visible()) == len(rows))
        t('정렬이 실제로 걸린다',
          [r['book_id'] for r in sh.visible()]
          == [r['book_id'] for r in sort_rows(rows, 'year')])
        # 카드를 누르면 book_id 가 나간다
        # ⚠ **`update_idletasks()` 뒤라야 클릭이 간다** — 그 전에는 카드가 아직
        #   `mapped` 가 아니라 `event_generate` 가 아무 데도 안 닿는다(실측).
        root.update_idletasks()
        card = sh._grid.winfo_children()[0]
        card.event_generate('<Button-1>', x=5, y=5)
        root.update()
        t('카드를 누르면 열린다', len(opened) == 1, opened)
        t('나간 것이 그 책이다', (not opened) or opened[0] == sh.visible()[0]['book_id'])
        # 필터 줄을 두 번 지어 체크가 풀리지 않는가
        sh._f_era._all_var.set(False)
        for k, v in sh._f_era._vars.items():
            v.set(k == 'E3')
        sh.reload()
        root.update()
        t('다시 불러도 켠 체크가 살아 있다',
          (not sh._f_era.is_all()) and sh._f_era.get_selected() == ['E3'],
          sh._f_era.get_selected())
    finally:
        try:
            root.destroy()
        except Exception:
            pass
    print('selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    a = sys.argv[1:]
    if not a or a[0] == '--selftest':
        sys.exit(0 if _selftest() else 1)
    if a[0] == '--list':
        db = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bible_master.db')
        for r in sort_rows(fetch(db, 'KO'), a[1] if len(a) > 1 else 'cat'):
            print('%-13s %-24s %-14s %-5s %5d편 %6d쪽  %s'
                  % (r['cat'], r['title'][:24], r['author'][:14],
                     r['year'] or '-', r['units'], r['pages'], r['desc'][:34]))
    else:
        print(__doc__)


if __name__ == '__main__':
    main()
