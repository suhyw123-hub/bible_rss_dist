# -*- coding: utf-8 -*-
"""plan_share.py — 내 플랜(복제·수정) + 플랜 파일(SNS 로 주고받기) + 받은 묵상노트의 자리 (영구, 2026-10-14 신설).

★★★ docs/1.txt 87 My Plan Builder 1단계 — 사용자 확정(data.md Z-3l):
  · **공유 = SNS 로 파일 하나** — 메시지 속 다운로드 링크 · 우리 서버는 안 쓴다.
  · **주차 개념은 버린다** — 주 경계 대신 「구간 제목」(그 구간이 시작하는 날에 붙는 글).
  · **받은 묵상노트는 별도 방이 아니라 그 플랜의 그날 묵상노트에 덧붙인다** —
    사용자 「날자보다 플랜, 구절이 연결에서 중요한 변수」 ⇒ 묵상노트 꼬리표 = **플랜 열쇠 + 구절**,
    받는 쪽이 **제 플랜에서 그 구절이 든 날**을 찾는다(일차는 받는 쪽이 정한다).

★★ **플랜 열쇠(key)** — 기기를 넘어 같은 플랜을 가리키는 글자.
  · 배포 플랜 = `plan_code`(모든 기기에 같다 — 파일에는 열쇠만 싣고 일정은 안 싣는다).
  · 내 플랜 = `S-` + 열 자 — 새로 만들면 `plan_code` 가 곧 그 열쇠다(노트 출처 `PLAN:<code>:<일차>` 가
    기기마다 같아진다). 옛 내 플랜(plan_code 가 이름)은 `plan_config.share_key` 에 열쇠를 적는다.

★★ **파일 = `share_pack` 꼴**(`app='hagah-share'`) 에 갈래 `plan` — 두 벌을 만들지 않는다.
    {key, origin, title, desc, lang, days:[{d, sec, q, r:[{v:[a,b], ref, f}]}]}
  ⚠ 구절은 `v`(verse_id — 앱 전체가 같은 번호를 쓴다) + `ref`(사람이 읽는 약명 · `v` 를 못 풀 때만).
  ⚠ 폰(`mobile/lib/data/plan_share.dart`)이 같은 꼴을 읽고 쓴다 — **꼴을 바꾸면 거기도.**

★ 구간 제목·질문은 `plan_config` 에 일차별로 담는다(`sections`·`questions`) — 일정 행 번호(sched_id)는
  고칠 때마다 바뀌므로 거기에 매지 않는다.
⚠ 내 플랜 일정은 `sys_text_asset` 의 PLAN_FOCUS 를 읽지 않는다 — sched_id 와 schedule_id 는 다른 번호 공간이다
  (`plan_focus_view._load_rows` 가 그렇게 읽어 남의 플랜 포커스가 뜨던 자리를 함께 고쳤다).

    python plan_share.py --selftest     (의무)
"""
import json
import os
import random
import string
import sys

import appdb

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

APP_MARK = 'hagah-share'
FMT = 1
KEY_PFX = 'S-'
#: 바탕 플랜이 없는 내 플랜이 기대는 자리 — 골라담기의 조립 앵커와 같은 갈래(주제읽기 ▸ 골라담기)
ANCHOR_CODE = 'BIOGRAPHICAL_BUILDER'


def new_key():
    return KEY_PFX + ''.join(random.choice(string.ascii_lowercase + string.digits) for _ in range(10))


def _cfg(conn, uid):
    r = conn.execute("SELECT plan_config FROM user_bible_plan WHERE user_plan_id=?", (uid,)).fetchone()
    try:
        return json.loads(r[0]) if r and r[0] else {}
    except Exception:
        return {}


def _set_cfg(conn, uid, cfg):
    conn.execute("UPDATE user_bible_plan SET plan_config=? WHERE user_plan_id=?",
                 (json.dumps(cfg, ensure_ascii=False), uid))


def key_of(conn, plan_id=None, user_plan_id=None, make=True):
    """그 플랜의 열쇠 — 배포 = plan_code · 내 플랜 = `S-…`(없으면 지어 적는다)."""
    if user_plan_id:
        r = conn.execute("SELECT plan_code FROM user_bible_plan WHERE user_plan_id=?", (user_plan_id,)).fetchone()
        if r and (r[0] or '').startswith(KEY_PFX):
            return r[0]
        cfg = _cfg(conn, user_plan_id)
        if cfg.get('share_key'):
            return cfg['share_key']
        if not make:
            return ''
        cfg['share_key'] = new_key()
        _set_cfg(conn, user_plan_id, cfg)
        return cfg['share_key']
    r = conn.execute("SELECT plan_code FROM sys_bible_plan WHERE plan_id=?", (plan_id,)).fetchone()
    return r[0] if r else ''


def find(conn, key):
    """열쇠 → ('SYS', plan_id) · ('USER', user_plan_id) · None. 내 플랜은 지운 것을 빼고 찾는다."""
    if not key:
        return None
    r = conn.execute("SELECT plan_id FROM sys_bible_plan WHERE plan_code=? AND record_status='LIVE'",
                     (key,)).fetchone()
    if r:
        return ('SYS', r[0])
    for uid, code, cfg in conn.execute(
            "SELECT user_plan_id, plan_code, plan_config FROM user_bible_plan "
            "WHERE COALESCE(record_status,'LIVE')='LIVE' ORDER BY user_plan_id"):
        if code == key:
            return ('USER', uid)
        try:
            if cfg and json.loads(cfg).get('share_key') == key:
                return ('USER', uid)
        except Exception:
            pass
    return None


def title_of(conn, kind, pid, lang='KO'):
    if kind == 'SYS':
        rows = conn.execute("SELECT UPPER(lang_code), contents FROM sys_text_asset WHERE clicked_id=? "
                            "AND text_type='PLAN_TITLE' AND record_status='LIVE'", (pid,)).fetchall()
        by = {lg: (v or '').strip() for lg, v in rows if (v or '').strip()}
        r = conn.execute("SELECT plan_code FROM sys_bible_plan WHERE plan_id=?", (pid,)).fetchone()
        return by.get(lang.upper()) or by.get('EN') or by.get('KO') or (r[0] if r else '')
    r = conn.execute("SELECT COALESCE(NULLIF(contents,''), title) FROM user_text_asset WHERE "
                     "text_type='PLAN_TITLE' AND clicked_id=? AND COALESCE(record_status,'LIVE')<>'HIDE' "
                     "ORDER BY user_text_id DESC LIMIT 1", (pid,)).fetchone()
    if r and (r[0] or '').strip():
        return r[0].strip()
    r = conn.execute("SELECT plan_code FROM user_bible_plan WHERE user_plan_id=?", (pid,)).fetchone()
    return (r[0] or '') if r else ''


def desc_of(conn, kind, pid, lang='KO'):
    if kind == 'SYS':
        rows = conn.execute("SELECT UPPER(lang_code), contents FROM sys_text_asset WHERE clicked_id=? "
                            "AND text_type='PLAN_DESC' AND record_status='LIVE'", (pid,)).fetchall()
        by = {lg: (v or '').strip() for lg, v in rows if (v or '').strip()}
        return by.get(lang.upper()) or by.get('EN') or by.get('KO') or ''
    r = conn.execute("SELECT contents FROM user_text_asset WHERE text_type='PLAN_DESC' AND clicked_id=? "
                     "AND COALESCE(record_status,'LIVE')<>'HIDE' ORDER BY user_text_id DESC LIMIT 1",
                     (pid,)).fetchone()
    return (r[0] or '').strip() if r else ''


def _ref(conn, a, b):
    import lens_share
    return lens_share._ref_of(conn, a, b) or ''


def _txt(conn, sid, ttype, col, lang):
    rows = conn.execute("SELECT UPPER(lang_code), %s FROM sys_text_asset WHERE clicked_id=? AND text_type=? "
                        "AND record_status='LIVE'" % col, (sid, ttype)).fetchall()
    by = {lg: (v or '').strip() for lg, v in rows if (v or '').strip()}
    v = by.get(lang.upper()) or by.get('EN') or by.get('KO') or ''
    # 자가진단 플랜의 내부 코드(DIAG_…)는 글이 아니다
    if v and v.replace('_', '').isalnum() and v.upper() == v and '_' in v:
        return ''
    return v


def days_of(conn, kind, pid, lang='KO'):
    """일정 → [{d, sec, q, r:[{v:[a,b], ref, f}]}] (일차 차례)."""
    days = {}
    if kind == 'SYS':
        week_title = {}
        for cid, t in conn.execute(
                "SELECT clicked_id, title FROM sys_text_asset WHERE text_type='WEEK_TITLE' "
                "AND clicked_id BETWEEN ? AND ? AND UPPER(lang_code)=? AND record_status='LIVE'",
                (pid * 10000, pid * 10000 + 9999, lang.upper())):
            if (t or '').strip():
                week_title[cid - pid * 10000] = t.strip()
        for sid, day, week, a, b, mf in conn.execute(
                "SELECT schedule_id, day, week, start_vid, end_vid, meditation_focus FROM sys_plan_schedule "
                "WHERE plan_id=? ORDER BY day, sort_order, track", (pid,)):
            dd = days.setdefault(day, {'d': day, 'r': []})
            f = _txt(conn, sid, 'PLAN_FOCUS', 'title', lang) or (mf or '').strip()
            dd['r'].append({'v': [a, b or a], 'ref': _ref(conn, a, b), 'f': f})
            if not dd.get('q'):
                qt = _txt(conn, sid, 'PLAN_QUESTION', 'title', lang)
                qb = _txt(conn, sid, 'PLAN_QUESTION', 'contents', lang)
                q = ('%s\n%s' % (qt, qb)).strip() if qb and qt and qt not in qb else (qb or qt)
                if q:
                    dd['q'] = q
        # ★ 주 제목 → 구간 제목(그 주가 시작하는 날) — 주차는 버리고 글은 읽을 거리와 함께 움직인다
        for w, t in week_title.items():
            d0 = (w - 1) * 7 + 1
            if d0 in days:
                days[d0]['sec'] = t
    else:
        cfg = _cfg(conn, pid)
        secs, qs = cfg.get('sections') or {}, cfg.get('questions') or {}
        for day, a, b, mf in conn.execute(
                "SELECT day, start_vid, end_vid, meditation_focus FROM user_plan_schedule WHERE user_plan_id=? "
                "ORDER BY day, sort_order, sched_id", (pid,)):
            dd = days.setdefault(day, {'d': day, 'r': []})
            dd['r'].append({'v': [a, b or a], 'ref': _ref(conn, a, b), 'f': (mf or '').strip()})
        for d, dd in days.items():
            if secs.get(str(d)):
                dd['sec'] = secs[str(d)]
            if qs.get(str(d)):
                dd['q'] = qs[str(d)]
    return [days[k] for k in sorted(days)]


def export_plan(conn, plan_id=None, user_plan_id=None, lang='KO', made_by=''):
    """플랜 하나 → 파일 dict(share_pack 꼴).

    ★ 배포 플랜은 **열쇠만** 싣는다 — 받는 쪽에도 같은 플랜이 있다(일정을 실을 까닭이 없다).
    """
    d = {'app': APP_MARK, 'fmt': FMT}
    if made_by:
        d['made_by'] = made_by
    if user_plan_id:
        key = key_of(conn, user_plan_id=user_plan_id)
        conn.commit()
        cfg = _cfg(conn, user_plan_id)
        o = conn.execute("SELECT origin_plan_id FROM user_bible_plan WHERE user_plan_id=?",
                         (user_plan_id,)).fetchone()
        origin = key_of(conn, plan_id=o[0]) if o and o[0] else ''
        p = {'key': key, 'lang': lang.upper(), 'title': title_of(conn, 'USER', user_plan_id, lang),
             'desc': desc_of(conn, 'USER', user_plan_id, lang),
             'days': days_of(conn, 'USER', user_plan_id, lang)}
        if origin and origin != ANCHOR_CODE:
            p['origin'] = origin
        if cfg.get('char_limit'):
            p['char_limit'] = cfg['char_limit']
    else:
        p = {'key': key_of(conn, plan_id=plan_id), 'sys': True, 'lang': lang.upper(),
             'title': title_of(conn, 'SYS', plan_id, lang)}
    d['title'] = p['title']
    d['plan'] = [p]
    return d


def file_name(title):
    bad = '\\/:*?"<>|\n\r\t'
    t = ''.join('_' if ch in bad else ch for ch in (title or 'plan')).strip() or 'plan'
    return t[:60] + '.hagah.json'


def write_file(path, draft):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(draft, f, ensure_ascii=False, indent=1)


def read_file(path):
    with open(path, encoding='utf-8-sig') as f:
        return json.load(f)


# ── 만들기 · 수정 ─────────────────────────────────────────────────────────

def _anchor_id(conn):
    r = conn.execute("SELECT plan_id FROM sys_bible_plan WHERE plan_code=?", (ANCHOR_CODE,)).fetchone()
    return r[0] if r else None


def _put_text(conn, uid, ttype, text, lang):
    conn.execute("UPDATE user_text_asset SET record_status='HIDE' WHERE text_type=? AND clicked_id=? "
                 "AND COALESCE(record_status,'LIVE')<>'HIDE'", (ttype, uid))
    if (text or '').strip():
        conn.execute("INSERT INTO user_text_asset (text_type, clicked_id, contents, lang_code, record_status, "
                     "created_at, updated_at) VALUES (?,?,?,?,'NEW',DATETIME('now','localtime'),"
                     "DATETIME('now','localtime'))", (ttype, uid, text.strip(), (lang or 'KO').upper()))


def _resolve_v(conn, r):
    """일정 한 줄 → (a, b) — verse_id 가 이 앱에 있으면 그것, 아니면 약명을 푼다. 못 풀면 None."""
    v = r.get('v') or []
    if v:
        a = int(v[0])
        b = int(v[1]) if len(v) > 1 and v[1] else a
        n = conn.execute("SELECT COUNT(*) FROM bible_index WHERE verse_id IN (?,?)", (a, b)).fetchone()[0]
        if n == (1 if a == b else 2):
            return a, b
    ref = (r.get('ref') or '').strip()
    if ref:
        import scripture_ref_kr
        a, b = scripture_ref_kr.resolve(conn, ref)
        if a is not None:
            return a, (b or a)
    return None


def save_plan(conn, title, days, *, desc='', lang='KO', uid=None, key=None, origin_id=None,
              char_limit=None, ptype='CUSTOM'):
    """내 플랜을 짓거나 통째로 다시 적는다 → (user_plan_id, 못 푼 줄 수).

    `days` = [{d, sec, q, r:[{v|ref, f}]}] — 빈 날은 버리고 **1부터 다시 번호를 매긴다**(밀고 당기기).
    ⚠ 커밋은 부르는 쪽.
    """
    clean, bad = [], 0
    for dd in days:
        rows = []
        for r in dd.get('r') or []:
            ab = _resolve_v(conn, r)
            if ab:
                rows.append((ab[0], ab[1], (r.get('f') or '').strip()))
            else:
                bad += 1
        if rows:
            clean.append((dd, rows))
    if not clean:
        raise ValueError('읽을 곳이 하나도 없습니다')
    if uid is None:
        key = key or new_key()
        cur = conn.execute(
            "INSERT INTO user_bible_plan (origin_plan_id, plan_code, plan_type, plan_category, duration_days, "
            "track_count, plan_config, record_status, created_at) VALUES (?,?,?,'THEMATIC',?,1,'{}','LIVE',"
            "DATETIME('now','localtime'))", (origin_id or _anchor_id(conn), key, ptype, len(clean)))
        uid = cur.lastrowid
    else:
        conn.execute("UPDATE user_bible_plan SET duration_days=? WHERE user_plan_id=?", (len(clean), uid))
        conn.execute("DELETE FROM user_plan_schedule WHERE user_plan_id=?", (uid,))
    cfg = _cfg(conn, uid)
    secs, qs = {}, {}
    for i, (dd, rows) in enumerate(clean, 1):
        if (dd.get('sec') or '').strip():
            secs[str(i)] = dd['sec'].strip()
        if (dd.get('q') or '').strip():
            qs[str(i)] = dd['q'].strip()
        for j, (a, b, f) in enumerate(rows):
            conn.execute("INSERT INTO user_plan_schedule (user_plan_id, day, track, start_vid, end_vid, "
                         "stage_type, sort_order, meditation_focus) VALUES (?,?,1,?,?,'CORE',?,?)",
                         (uid, i, a, b, j, f))
    cfg['sections'], cfg['questions'] = secs, qs
    if char_limit is not None:
        cfg['char_limit'] = char_limit
    _set_cfg(conn, uid, cfg)
    _put_text(conn, uid, 'PLAN_TITLE', title, lang)
    _put_text(conn, uid, 'PLAN_DESC', desc, lang)
    return uid, bad


def clone(conn, plan_id=None, user_plan_id=None, lang='KO', title=None, hide=True):
    """배포 플랜이나 내 플랜을 「내 플랜」으로 복사 → user_plan_id. 커밋은 부르는 쪽.

    ★ 2026-10-15 — 배포 플랜을 복사하면 원본을 기록한다(`copy_own` PLAN · 렌즈·연구노트와 같은 표).
      사용자에게는 「수정하기」 하나이고 [원본 가리기]/[원본 표시하기]로 원래 플랜을 감추거나 보인다."""
    kind, pid = ('USER', user_plan_id) if user_plan_id else ('SYS', plan_id)
    t = title or (title_of(conn, kind, pid, lang) + ' (내 플랜)')
    origin = plan_id
    if user_plan_id:
        r = conn.execute("SELECT origin_plan_id FROM user_bible_plan WHERE user_plan_id=?",
                         (user_plan_id,)).fetchone()
        origin = r[0] if r else None
    uid, _ = save_plan(conn, t, days_of(conn, kind, pid, lang), desc=desc_of(conn, kind, pid, lang),
                       lang=lang, origin_id=origin)
    if not user_plan_id and plan_id:
        import copy_own
        key = copy_own.sys_key(conn, 'PLAN', plan_id)
        if key:
            copy_own._record(conn, 'PLAN', key, uid, hide)
    return uid


def save_copy(conn, src_kind, src_id, title, days, *, desc='', lang='KO', hide=True):
    """[수정하기] 초안을 처음 저장할 때 — 내 플랜을 짓고, 배포 플랜이 바탕이면 원본을 기록한다(`clone` 과 같은 규칙).
    ⚠ 커밋은 부르는 쪽. (2026-10-15 88-8 — 누르는 순간이 아니라 저장할 때 생긴다)"""
    origin = src_id if src_kind == 'SYS' else None
    if src_kind == 'USER':
        r = conn.execute("SELECT origin_plan_id FROM user_bible_plan WHERE user_plan_id=?", (src_id,)).fetchone()
        origin = r[0] if r else None
    uid, _ = save_plan(conn, title, days, desc=desc, lang=lang, origin_id=origin)
    if src_kind == 'SYS':
        import copy_own
        key = copy_own.sys_key(conn, 'PLAN', src_id)
        if key:
            copy_own._record(conn, 'PLAN', key, uid, hide)
    return uid


PICK_TYPES = ('THEMATIC', 'JOURNEY', 'PRAYER', 'BIOGRAPHICAL')   # 골라담기 빌더가 짓는 갈래


def kind_of(conn, uid, ptype=None, cfg=None):
    """「내 플랜」 목록의 종류 — MINE(만든 것 ✎) · COPY(앱 플랜을 수정한 것 ⧉) · RECV(받은 것 ↓) · PICK(골라 담은 것 ◇)."""
    if cfg is None:
        cfg = _cfg(conn, uid)
    if ptype is None:
        r = conn.execute("SELECT plan_type FROM user_bible_plan WHERE user_plan_id=?", (uid,)).fetchone()
        ptype = r[0] if r else ''
    try:
        import copy_own
        if copy_own.origin_of(conn, 'PLAN', uid):
            return 'COPY'
    except Exception:
        pass
    if cfg.get('received'):
        return 'RECV'
    if (ptype or '').upper() in PICK_TYPES:
        return 'PICK'
    return 'MINE'


KIND_MARK = {'MINE': '✎', 'COPY': '⧉', 'RECV': '↓', 'PICK': '◇'}
ORDER_KEY = 'MY_PLAN_ORDER'


def get_order(conn):
    """사람이 끌어 정한 「내 플랜」 차례(user_plan_id 목록). 없으면 []."""
    try:
        r = conn.execute("SELECT config_val FROM user_config WHERE config_key=?", (ORDER_KEY,)).fetchone()
        v = json.loads(r[0]) if r and r[0] else []
        return [int(x) for x in v]
    except Exception:
        return []


def set_order(conn, uids):
    """차례를 적는다. ⚠ 커밋은 부르는 쪽."""
    val = json.dumps([int(x) for x in uids])
    if conn.execute("SELECT 1 FROM user_config WHERE config_key=?", (ORDER_KEY,)).fetchone():
        conn.execute("UPDATE user_config SET config_val=? WHERE config_key=?", (val, ORDER_KEY))
    else:
        conn.execute("INSERT INTO user_config (config_key, config_val) VALUES (?,?)", (ORDER_KEY, val))


def ordered(uids, order):
    """새로 생긴 것(차례에 없는 것)은 **맨 위**(최근 것 먼저) · 그 아래 사람이 정한 차례."""
    have = list(uids)
    known = [u for u in order if u in have]
    new = sorted([u for u in have if u not in order], reverse=True)
    return new + known


def delete_plan(conn, uid):
    conn.execute("UPDATE user_bible_plan SET record_status='HIDE' WHERE user_plan_id=?", (uid,))


# ── 받기 ───────────────────────────────────────────────────────────────────

def put_plan(conn, p, made_by=''):
    """파일의 플랜 하나 → ('SYS'|'USER'|'NEW'|'SAME'|'BAD', 번호, 말).

    · 배포 플랜(`sys`) — 이 PC 에도 있으면 그것을 가리킨다(아무것도 안 만든다).
    · 내 플랜 — 같은 열쇠가 이미 있으면 **안 덮는다**(SAME · 받는 사람이 고쳐 둔 것을 지킨다).
    """
    key = (p.get('key') or '').strip()
    hit = find(conn, key)
    if p.get('sys'):
        if hit and hit[0] == 'SYS':
            return 'SYS', hit[1], '이 PC 에 있는 플랜입니다'
        return 'BAD', None, '이 앱의 판에 없는 배포 플랜입니다(%s) — 앱을 갱신하세요' % key
    if hit:
        return 'SAME', hit[1], '이미 받은 플랜입니다'
    origin = find(conn, p.get('origin') or '')
    oid = origin[1] if origin and origin[0] == 'SYS' else None
    uid, bad = save_plan(conn, p.get('title') or key, p.get('days') or [], desc=p.get('desc') or '',
                         lang=p.get('lang') or 'KO', key=key if key.startswith(KEY_PFX) else None,
                         origin_id=oid, char_limit=p.get('char_limit'))
    cfg = _cfg(conn, uid)
    if not key.startswith(KEY_PFX):
        cfg['share_key'] = key
    cfg['received'] = 1                    # 「내 플랜」 목록의 ↓ 표시(2026-10-15)
    if made_by:
        cfg['made_by'] = made_by
    _set_cfg(conn, uid, cfg)
    return 'NEW', uid, ('못 읽은 줄 %d개를 건너뛰었습니다' % bad) if bad else ''


def import_file(conn, draft):
    """파일 → [(결과, 번호, 말, 제목)] · 원자성 — 하나라도 터지면 모두 되돌린다."""
    if not isinstance(draft, dict) or draft.get('app') != APP_MARK:
        raise ValueError('하가 플랜 파일이 아닙니다')
    if int(draft.get('fmt') or 0) > FMT:
        raise ValueError('더 새로운 판의 파일입니다 — 앱을 갱신하세요')
    out = []
    try:
        for p in draft.get('plan') or []:
            st, pid, msg = put_plan(conn, p, made_by=(draft.get('made_by') or '').strip())
            out.append((st, pid, msg, p.get('title') or p.get('key') or ''))
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    return out


# ── 받은 묵상노트의 자리 ────────────────────────────────────────────────────

def day_of_verse(conn, key, vid):
    """그 플랜에서 이 구절이 든 첫 날 → (출처 열쇠 `PLAN:<code>:<일차>`, 플랜 제목, 일차) · 없으면 None."""
    hit = find(conn, key)
    if not hit or not vid:
        return None
    kind, pid = hit
    if kind == 'SYS':
        r = conn.execute("SELECT MIN(day) FROM sys_plan_schedule WHERE plan_id=? AND start_vid<=? "
                         "AND COALESCE(end_vid,start_vid)>=?", (pid, vid, vid)).fetchone()
        code = conn.execute("SELECT plan_code FROM sys_bible_plan WHERE plan_id=?", (pid,)).fetchone()[0]
    else:
        r = conn.execute("SELECT MIN(day) FROM user_plan_schedule WHERE user_plan_id=? AND start_vid<=? "
                         "AND COALESCE(end_vid,start_vid)>=?", (pid, vid, vid)).fetchone()
        code = conn.execute("SELECT plan_code FROM user_bible_plan WHERE user_plan_id=?",
                            (pid,)).fetchone()[0] or ('U%d' % pid)
    if not r or not r[0]:
        return None
    return 'PLAN:%s:%d' % (code, r[0]), title_of(conn, kind, pid), r[0]


# ── 자가 검증 ─────────────────────────────────────────────────────────────

def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    conn = appdb.connect()
    base = {tb: conn.execute('SELECT COALESCE(MAX(%s),0) FROM %s' % (pk, tb)).fetchone()[0]
            for tb, pk in (('user_bible_plan', 'user_plan_id'), ('user_plan_schedule', 'sched_id'),
                           ('user_text_asset', 'user_text_id'))}
    sys0 = conn.execute('SELECT COUNT(*) FROM sys_plan_schedule').fetchone()[0]
    try:
        sp = conn.execute("SELECT plan_id, plan_code FROM sys_bible_plan WHERE plan_code='CANONICAL_1Y'").fetchone()
        t('배포 플랜이 있다', bool(sp), sp)
        pid = sp[0]
        f = export_plan(conn, plan_id=pid)
        t('★ 배포 플랜 파일은 열쇠만(일정 없음)', f['plan'][0].get('sys') and 'days' not in f['plan'][0],
          len(json.dumps(f)))
        st = import_file(conn, f)
        t('  배포 플랜 파일을 받으면 그 플랜을 가리킨다', st and st[0][0] == 'SYS' and st[0][1] == pid, st)

        uid = clone(conn, plan_id=pid, title='시험 복제')
        n = conn.execute("SELECT COUNT(*) FROM user_plan_schedule WHERE user_plan_id=?", (uid,)).fetchone()[0]
        n0 = conn.execute("SELECT COUNT(*) FROM sys_plan_schedule WHERE plan_id=?", (pid,)).fetchone()[0]
        t('★★ 복제 = 일정 줄 수가 같다', n == n0, '%d vs %d' % (n, n0))
        key = key_of(conn, user_plan_id=uid)
        t('★ 복제한 플랜의 plan_code 가 곧 열쇠(S-)', key.startswith(KEY_PFX) and find(conn, key) == ('USER', uid), key)
        t('  제목이 내 글로', title_of(conn, 'USER', uid) == '시험 복제')

        f2 = export_plan(conn, user_plan_id=uid)
        p2 = f2['plan'][0]
        nd = conn.execute("SELECT COUNT(DISTINCT day) FROM sys_plan_schedule WHERE plan_id=?", (pid,)).fetchone()[0]
        t('★★ 내 플랜 파일에 일정이 실린다', len(p2['days']) == nd and p2['days'][0]['r'][0]['v'],
          len(p2['days']))
        t('  바탕 플랜 열쇠가 실린다', p2.get('origin') == 'CANONICAL_1Y', p2.get('origin'))
        t('★ 받은 것을 다시 넣어도 안 는다(같은 열쇠)', import_file(conn, f2)[0][0] == 'SAME')

        # 다른 기기에서 받은 것처럼 — 열쇠를 바꿔 넣는다
        p3 = dict(p2, key=new_key(), title='받은 플랜')
        p3['days'] = [dict(p2['days'][0], sec='첫 구간', q='무엇을 보았습니까?'),
                      {'d': 2, 'r': [{'ref': '요 3:16', 'f': '사랑'}]},
                      {'d': 3, 'r': [{'v': [999999999, 999999999], 'ref': '없는책 1:1'}]}]
        st = import_file(conn, {'app': APP_MARK, 'fmt': FMT, 'plan': [p3]})
        uid3 = st[0][1]
        t('★★ 새 플랜으로 들어간다 · 못 읽은 줄은 건너뛰고 말한다', st[0][0] == 'NEW' and '1개' in st[0][2], st)
        d3 = days_of(conn, 'USER', uid3)
        t('★ 빈 날은 버리고 다시 번호 · 약명으로 푼 줄', len(d3) == 2 and d3[1]['r'][0]['ref'].startswith('요 3:16'), d3[1])
        t('★ 구간 제목·질문이 일차에 붙어 온다', d3[0].get('sec') == '첫 구간' and d3[0].get('q') == '무엇을 보았습니까?')

        jn = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=43 AND chapter=3 AND verse=16").fetchone()[0]
        loc = day_of_verse(conn, p3['key'], jn)
        t('★★★ 받은 노트의 자리 = 그 플랜에서 그 구절이 든 날', loc and loc[0] == 'PLAN:%s:2' % p3['key'], loc)
        g = conn.execute("SELECT start_vid FROM sys_plan_schedule WHERE plan_id=? AND day=40", (pid,)).fetchone()[0]
        loc2 = day_of_verse(conn, 'CANONICAL_1Y', g)
        t('★ 배포 플랜도 같은 규칙', loc2 and loc2[0] == 'PLAN:CANONICAL_1Y:40', loc2)
        t('  플랜에 없는 구절 → None', day_of_verse(conn, p3['key'], g) is None)

        # 수정 — 날을 밀고 당긴다
        dd = days_of(conn, 'USER', uid3)
        dd.insert(0, {'d': 0, 'sec': '서론', 'r': [{'ref': '시 1:1-6'}]})
        save_plan(conn, '받은 플랜', dd, uid=uid3)
        d4 = days_of(conn, 'USER', uid3)
        t('★ 날을 끼우면 뒤가 밀리고 구간 제목이 함께 움직인다',
          len(d4) == 3 and d4[0].get('sec') == '서론' and d4[1].get('sec') == '첫 구간', [x.get('sec') for x in d4])
        t('★★ 플랜 열쇠는 고쳐도 그대로', key_of(conn, user_plan_id=uid3) == p3['key'])
        try:
            import_file(conn, {'app': 'X'})
            t('남의 파일 거부', False)
        except ValueError:
            t('남의 파일 거부', True)
        t('★★★ sys 를 한 줄도 안 건드린다', conn.execute('SELECT COUNT(*) FROM sys_plan_schedule').fetchone()[0] == sys0)
    finally:
        for tb, pk in (('user_bible_plan', 'user_plan_id'), ('user_plan_schedule', 'sched_id'),
                       ('user_text_asset', 'user_text_id')):
            conn.execute('DELETE FROM %s WHERE %s>?' % (tb, pk), (base[tb],))
        conn.commit()
        left = sum(conn.execute('SELECT COUNT(*) FROM %s WHERE %s>?' % (tb, pk), (base[tb],)).fetchone()[0]
                   for tb, pk in (('user_bible_plan', 'user_plan_id'), ('user_plan_schedule', 'sched_id'),
                                  ('user_text_asset', 'user_text_id')))
        t('★ 시험 잔재 0', left == 0, left)
        conn.close()
    print('plan_share selftest: %d/%d' % tuple(ok))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print(__doc__)
