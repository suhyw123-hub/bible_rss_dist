# -*- coding: utf-8 -*-
"""검색칸에 들어가면 **그 언어로 바로 칠 수 있게** 한다 (2026-09-11 사용자).

사용자 — 「현재 : 초기값은 무조건 EN · 사용자가 **KO를 설정하였다면 검색창에
입력할 때 기본 언어를 KO로** 세팅 · **프랑스어 사용자라면 FR로** 세팅」
· 「검색창에 **반드시 KO만 되면 안 된다. 바꿀 수 있게 하되 기본 값이 KO**」
· 「**러시아어는 RU 기본세팅**」

★★★ **윈도우에는 두 층이 있고 둘 다 건드려야 한다** (실측으로 갈랐다):
  ⓐ **자판 배열**(keyboard layout · HKL) — RU·FR·DE·ES·AR·PT 는 이 층이다.
     `ActivateKeyboardLayout`. **그 자판이 깔려 있어야** 바뀐다.
  ⓑ **IME 변환 상태**(한/영 · かな/英) — KO·JA·ZH 는 이 층이다.
     자판은 하나뿐이고 그 **안에서 모드가 갈린다.** `ImmSetConversionStatus`.
  ⚠⚠ 실측 — 이 PC 에 깔린 자판은 **한국어 하나뿐**이었다. 사용자가 보는 "EN"
    은 자판이 아니라 **한국어 IME 의 영문 모드**다. ⓑ 를 안 하면 아무 일도
    안 일어난다.

★★★ **들어갈 때마다 기본 언어다**(2026-09-17 사용자 「기본세팅을 사용자 설정
  언어로 바꾸어라. 이전에 요구했는데 아직 반영되지 않은 부분이 있다」).
  ⚠⚠⚠ **그전에는 나갈 때 상태를 기억해 되살렸는데, 그것이 칸을 영문으로
    굳혔다 — 실측:** 처음 한글 → 사람이 영어 한 낱말 치려고 한/영 → 그 뒤로는
    **다시 들어와도·탭을 돌고 와도 영문**. 세션 내내 그렇다.
    「사람이 바꾼 것을 지킨다」는 뜻이었지만 실제로는 **기본값이 한 번 쓰이고
    죽는** 장치였다.
  ⚠ **칠 때마다 되돌리지는 않는다** — 칸 안에 있는 동안은 아무도 안 건드리므로
    한/영을 눌러 영어를 치는 데 아무 지장이 없다(사용자 「반드시 KO만 되면
    안 된다」). 다시 들어올 때 기본으로 돌아갈 뿐이다.

⚠ **윈도우가 아니거나 자판이 없으면 아무 일도 안 한다** — 터지지 않는다.
  다만 **조용히 넘기지는 않는다**(§0-1) — `why()` 가 까닭을 말하고 화면이
  한 번 적을 수 있다.

CLI
  python ime_hint.py --selftest
  python ime_hint.py --list      # 이 PC 에 깔린 자판
"""
from __future__ import annotations

import sys

#: 우리 언어 코드 → 윈도우 **주 언어 번호**(primary langid · 하위 10비트).
#:   ⚠ 지역까지 맞추지 않는다 — `0x0C0A`(ES-ES)·`0x080A`(ES-MX) 가 다 스페인어다.
PRIMARY = {
    'EN': 0x09, 'KO': 0x12, 'JA': 0x11, 'ZH': 0x04, 'ZHT': 0x04,
    'DE': 0x07, 'FR': 0x0C, 'ES': 0x0A, 'AR': 0x01, 'RU': 0x19,
    'PT': 0x16,
}

#: **IME 변환 상태**를 함께 켜야 하는 언어 — 자판 하나 안에서 모드가 갈린다.
IME_LANGS = ('KO', 'JA', 'ZH', 'ZHT')

_IME_CMODE_NATIVE = 0x0001

_u = _imm = None
if sys.platform == 'win32':          # pragma: no cover - 윈도우에서만
    try:
        import ctypes
        from ctypes import wintypes
        _u = ctypes.WinDLL('user32', use_last_error=True)
        _imm = ctypes.WinDLL('imm32', use_last_error=True)
        _u.GetKeyboardLayoutList.argtypes = [ctypes.c_int,
                                             ctypes.POINTER(wintypes.HKL)]
    except Exception:
        _u = _imm = None


def available():
    """이 PC 에서 손댈 수 있나."""
    return _u is not None and _imm is not None


def layouts():
    """깔린 자판 → {주 언어 번호: HKL}. 못 읽으면 빈 것."""
    if not available():
        return {}
    try:
        import ctypes
        from ctypes import wintypes
        n = _u.GetKeyboardLayoutList(0, None)
        if n <= 0:
            return {}
        arr = (wintypes.HKL * n)()
        _u.GetKeyboardLayoutList(n, arr)
        out = {}
        for h in arr:
            out.setdefault((h & 0xFFFF) & 0x3FF, h)
        return out
    except Exception:
        return {}


def why(lang):
    """그 언어로 못 맞추는 까닭 → 사람 말, 되면 `None`.

    ★ **조용히 넘기지 않는다**(§0-1) — 화면이 이것을 한 번 적을 수 있다.
    ⚠⚠ **영어는 자판이 없어도 된다** — 한국어·일본어 자판 **안의 영문 모드**가
      곧 영어다(실측 이 PC 에 깔린 자판은 한국어 하나뿐인데 영문이 잘 쳐진다).
      「EN 자판이 없습니다」라고 말하면 **틀린 말**이다.
    """
    if not available():
        return '이 운영체제에서는 입력기를 바꿀 수 없습니다.'
    lg = (lang or '').upper()
    p = PRIMARY.get(lg)
    if p is None:
        return '「%s」 는 입력기를 아는 언어가 아닙니다.' % lang
    if lg == 'EN':
        return None
    if p not in layouts():
        return ('「%s」 자판이 이 PC 에 깔려 있지 않습니다 — '
                '윈도우 설정에서 더하면 바로 듣습니다.' % lang)
    return None


def _conv(hwnd):
    """그 창의 IME 변환 상태 → (값, 문장 값) 또는 None."""
    if not available() or not hwnd:
        return None
    try:
        import ctypes
        h = _imm.ImmGetContext(ctypes.c_void_p(int(hwnd)))
        if not h:
            return None
        c = ctypes.c_ulong()
        s = ctypes.c_ulong()
        _imm.ImmGetConversionStatus(h, ctypes.byref(c), ctypes.byref(s))
        _imm.ImmReleaseContext(ctypes.c_void_p(int(hwnd)), h)
        return c.value, s.value
    except Exception:
        return None


def _set_conv(hwnd, native):
    """그 창의 IME 를 **한글/영문** 으로. 됐으면 True."""
    got = _conv(hwnd)
    if got is None:
        return False
    try:
        import ctypes
        cur, sent = got
        new = (cur | _IME_CMODE_NATIVE) if native else (cur & ~_IME_CMODE_NATIVE)
        if new == cur:
            return True
        h = _imm.ImmGetContext(ctypes.c_void_p(int(hwnd)))
        if not h:
            return False
        ok = _imm.ImmSetConversionStatus(h, new, sent)
        _imm.ImmReleaseContext(ctypes.c_void_p(int(hwnd)), h)
        return bool(ok)
    except Exception:
        return False


_NI_COMPOSITIONSTR = 0x15
_CPS_COMPLETE = 0x1


def commit(hwnd):
    """그 창에서 **조합 중인 글자를 확정**한다 → 확정할 것이 있었고 됐으면 True.

    ★★★ 317차 — docs/1.txt 3-1 「요구사항 프롬프트에 타이핑 하면 **마지막 글자가 한글자씩
      잘린다**」의 정체. 한글은 마지막 음절이 **조합 중**이면 아직 칸에 안 들어가 있어
      그 순간 글을 읽으면 그 글자가 빠진다(입력기는 다음 글자나 포커스 이동 때 확정한다).
      ⇒ 글을 읽기 **바로 전에** 확정하라고 입력기에 알린다(`ImmNotifyIME · CPS_COMPLETE`).
    ⚠ 확정된 글자는 **창 메시지로** 들어온다 — 부르는 쪽이 이벤트를 한 번 돌린 뒤 읽는다.
    ⚠ 윈도우가 아니거나 문맥이 없으면 아무 일도 안 한다(False).
    """
    if not available() or not hwnd:
        return False
    try:
        import ctypes
        h = _imm.ImmGetContext(ctypes.c_void_p(int(hwnd)))
        if not h:
            return False
        ok = _imm.ImmNotifyIME(h, _NI_COMPOSITIONSTR, _CPS_COMPLETE, 0)
        _imm.ImmReleaseContext(ctypes.c_void_p(int(hwnd)), h)
        return bool(ok)
    except Exception:
        return False


def set_for(hwnd, lang):
    """그 창의 입력기를 `lang` 으로 맞춘다 → 됐으면 True.

    ⚠ **자판을 먼저, 변환 상태를 나중에** — 자판을 바꾸면 IME 문맥이 새로
      붙으므로 차례가 바뀌면 모드가 날아간다.
    """
    lg = (lang or '').upper()
    p = PRIMARY.get(lg)
    if p is None or not available():
        return False
    ok = False
    hkl = layouts().get(p)
    if hkl is not None:
        try:
            import ctypes
            cur = _u.GetKeyboardLayout(0)
            if ((cur & 0xFFFF) & 0x3FF) != p:
                _u.ActivateKeyboardLayout(ctypes.c_void_p(int(hkl)), 0)
            ok = True
        except Exception:
            pass
    if lg in IME_LANGS:
        # ★ 한글·가나 모드까지 켜야 **바로 칠 수 있다**
        ok = _set_conv(hwnd, True) or ok
    elif _conv(hwnd) is not None:
        # ⚠⚠ **영문 모드로 내린다** — 라틴·키릴 자판으로 갔으면 한글이 남으면
        #   안 되고, **자판이 없는 영어**도 이 한 줄이 곧 답이다(한국어 자판
        #   안의 영문 모드가 영어다).
        ok = _set_conv(hwnd, False) or ok
    return ok


#: 칸마다 「사람이 마지막으로 둔 상태」 — 기본값이 사람을 이기지 않게 한다
_MEM = {}


def attach(widget, lang_getter):
    """검색칸 하나에 붙인다 — **들어올 때마다** 기본 언어로 맞춘다.

    `lang_getter` 는 **부를 때마다** 지금 환경설정 언어를 낸다(굳히지 않는다).
    ⚠ 붙이는 것 자체는 **어디서나 안전**하다 — 윈도우가 아니면 아무 일도 안 한다.
    """
    if widget is None:
        return False

    def _in(_e=None):
        if not available():
            return
        try:
            hwnd = widget.winfo_id()
        except Exception:
            return
        set_for(hwnd, lang_getter() if callable(lang_getter) else lang_getter)

    try:
        widget.bind('<FocusIn>', _in, add='+')
    except Exception:
        return False
    return True


def attach_class(root, lang_getter,
                 classes=('TEntry', 'Entry', 'TCombobox', 'Text')):
    """**글자 칸 갈래 전체**에 한 번에 붙인다 → 붙인 갈래 수.

    ★★★ **문이 하나여야 한다** — 화면마다 손으로 붙이면 반드시 몇 개를
      빠뜨린다(§0-1 그 자리). 앱을 켤 때 이 한 줄이면 **앞으로 생길 칸까지**
      따라온다.
    ⚠⚠ **`bind_all` 을 쓰지 않는다**(§238차 ⑩ — 한 화면이 앱 전체의 휠을
      먹었던 자리). `bind_class` 는 **그 갈래의 위젯만** 받고 `add='+'` 라
      남이 건 것을 안 걷는다.
    ⚠ **가린 칸(비밀번호)은 건너뛴다** — 거기서 한글로 바뀌면 못 친다.
    ⚠⚠ **읽기전용 콤보를 건너뛰려다 되돌렸다**(2026-09-17) — 못 치는 칸이라
      뜻이 없어 보였지만, 빼자 **한글로 열리는 칸이 37 → 0** 이 됐다. 입력기
      문맥이 창마다가 아니라 **한 벌로 공유**되어, 그 칸들이 실제로는 모드를
      **유지해 주고** 있었다. **재 보고 되돌렸다.**
    ★ **`Text` 도 붙인다**(2026-09-17) — 묵상노트·메모·내 자료 본문은 사용자가
      한국어로 **쓰는** 칸인데 갈래가 빠져 있었다.
    """
    if root is None or not available():
        return 0
    n = 0

    def _on(ev):
        w = getattr(ev, 'widget', None)
        if w is None:
            return
        try:
            if str(w.cget('show') or ''):
                return          # ⚠ 비밀번호 칸
        except Exception:
            pass
        try:
            hwnd = w.winfo_id()
        except Exception:
            return
        set_for(hwnd, lang_getter() if callable(lang_getter) else lang_getter)

    for cls in classes:
        try:
            root.bind_class(cls, '<FocusIn>', _on, add='+')
            n += 1
        except Exception:
            pass
    return n


def forget():
    """기억을 지운다 — 시험이 자국을 안 남기게."""
    _MEM.clear()


def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    t('★ 11언어가 다 표에 있다',
      {'EN', 'KO', 'ZH', 'ZHT', 'JA', 'DE', 'FR', 'ES', 'AR', 'RU', 'PT'}
      <= set(PRIMARY))
    t('★★ **러시아어도 있다**(사용자 「러시아어는 RU 기본세팅」)',
      PRIMARY.get('RU') == 0x19)
    t('★★ **IME 층은 CJK 뿐이다**(나머지는 자판 층)',
      set(IME_LANGS) == {'KO', 'JA', 'ZH', 'ZHT'})
    t('★ 주 언어 번호는 **하위 10비트**라 지역을 안 가린다',
      (0x0C0A & 0x3FF) == PRIMARY['ES'] and (0x080A & 0x3FF) == PRIMARY['ES'])
    t('★ 모르는 언어는 까닭을 말한다(조용히 안 넘긴다)',
      why('XX') is not None)
    t('★★ 안 깔린 자판도 **까닭을 말한다**',
      (why('KO') is None) or ('깔려' in why('KO')))
    t('★ 붙일 것이 없으면 False', attach(None, 'KO') is False)

    # 실제 위젯에 붙여 본다 — 창을 띄우지 않고
    try:
        import tkinter as tk
        from tkinter import ttk
        r = tk.Tk()
        r.withdraw()
        e = ttk.Entry(r)
        e.pack()
        r.update()
        t('★★ 검색칸에 붙는다', attach(e, lambda: 'KO') is True)
        t('★ 조합 확정 문이 터지지 않는다(조합 중인 것이 없으면 False 도 정상)',
          commit(e.winfo_id()) in (True, False) and commit(0) is False)
        got = _conv(e.winfo_id())
        t('★ 상태를 읽는다(윈도우일 때)',
          got is not None or sys.platform != 'win32', got)
        # ⚠ **포커스로 재지 않는다** — 안 보이는 창에는 포커스가 안 붙어
        #   「안 된다」로 나온다(실측으로 당했다). 재는 것은 **문 자체**다.
        if got is not None and why('KO') is None:
            set_for(e.winfo_id(), 'KO')
            g2 = _conv(e.winfo_id())
            t('★★★ **한글 모드가 켜진다**(0x%X → 0x%X)' % (got[0], g2[0]),
              bool(g2[0] & _IME_CMODE_NATIVE), g2)
            set_for(e.winfo_id(), 'EN')
            g3 = _conv(e.winfo_id())
            t('★★★ **영어는 영문 모드로 내린다**(자판이 없어도 된다)',
              not (g3[0] & _IME_CMODE_NATIVE), g3)
        else:
            t('★★★ 한글 모드 — 한국어 자판이 없어 건너뜀', True)
            t('★★★ 영문 모드 — 건너뜀', True)
        # ★★★ **들어갈 때마다 기본값이다**(2026-09-17) — 나갈 때 기억해
        #   되살리던 것을 걷었다. 그것이 칸을 영문으로 굳혔다(실측).
        import inspect as _i0
        _src0 = _i0.getsource(attach_class)
        t('★★★ **나갈 때 기억하지 않는다**(칸이 영문으로 굳던 자리)',
          "'<FocusOut>'" not in _src0 and '_MEM.get(' not in _src0)
        t('★★★ **들어올 때마다 기본 언어로 맞춘다**', 'set_for(' in _src0)
        # ★★★ 갈래 전체에 한 번에 — **문이 하나다** (Text 까지 넷)
        t('★★★ **글자 칸 갈래에 한 번에 붙는다**(Text 까지 넷)',
          attach_class(r, lambda: 'KO') == 4)
        t('★★ **`Text` 갈래가 든다** — 묵상노트·메모는 여기서 쓴다',
          'Text' in attach_class.__defaults__[0])
        import inspect as _i
        # ⚠ 글에 든 낱말이 아니라 **부르는 줄**을 본다(설명이 제 시험을 깼다)
        _src = _i.getsource(attach_class)
        t('★★ **`bind_all` 을 안 쓴다**(§238차 — 앱 전체를 먹는다)',
          '.bind_all(' not in _src and '.bind_class(' in _src)
        t('★★ **비밀번호 칸은 건너뛴다**',
          "cget('show')" in _i.getsource(attach_class))
        t('★ 붙일 창이 없으면 0', attach_class(None, 'KO') == 0)
        forget()
        t('★ 기억을 지우면 자국이 없다', not _MEM)
        r.destroy()
    except Exception as _e:
        t('★ 위젯 시험이 돈다', False, repr(_e))

    print('ime_hint selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    if '--list' in sys.argv:
        print('손댈 수 있나 :', available())
        rev = {v: k for k, v in PRIMARY.items()}
        for p, h in sorted(layouts().items()):
            print('  0x%03X  %-4s  HKL=0x%08X'
                  % (p, rev.get(p, '?'), h & 0xFFFFFFFF))
        for lg in PRIMARY:
            print('  %-4s → %s' % (lg, why(lg) or 'OK'))
        sys.exit(0)
    print(__doc__)
