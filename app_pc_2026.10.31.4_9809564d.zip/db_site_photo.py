# -*- coding: utf-8 -*-
"""db_site_photo.py — **성경 유적 사진·사진 링크** (2026-10-23 신설 · 영구 · docs/둘러보기_04).

사용자 확정 — 「말씀카드 관리도구와 성경유적사진으로 분리 · 의미도 다르고 용도가 다르다 · 사용자가 따로 선택」.
말씀카드 사진(`sys_splash_image` · 자연경관 · 카드에 쓴다)과 **유적 사진**(장소·인물·사건에 매인 사진 · 보기만)은 표가 다르다.

표 둘 —
· `sys_site_photo`  유적 사진(관리자가 올린 파일 · 장소 용어에 맨다 · 출처·저작권) — jpg(긴 변 1600) + 작은 그림(320).
· `sys_photo_link`  사진 **링크**(바깥 사이트 · 그림은 받지 않는다 — 저작권) — 갈래 SITE(유적) · MUSEUM(유물·박물관) · ART(옛 지도·성경화) · MAP(지도).
  썸네일은 싣지 않는다. 폰은 출처 이름을 배지로 보이고 누르면 브라우저로 연다.
폰 = 유적 사진은 사진 팩(MPHOTO) · 링크는 공통팩. 사용자가 AI 로 찾은 링크는 폰 표(`phone_photo_link`)에만.
`--selftest` · `--init` · `--status`.
"""
import io
import sqlite3
import sys
import time

DB = 'bible_master.db'
LINK_KINDS = (('SITE', '유적지'), ('MUSEUM', '유물·박물관'), ('ART', '옛 지도·성경화'), ('MAP', '지도'))
MAX_SIDE, THUMB_SIDE = 1600, 320

DDL = (
    """CREATE TABLE IF NOT EXISTS sys_site_photo (
        photo_id INTEGER PRIMARY KEY AUTOINCREMENT,
        entity_id INTEGER, title TEXT, caption TEXT, source TEXT, source_url TEXT, license TEXT,
        jpg BLOB, thumb BLOB, width INTEGER, height INTEGER,
        sort_order INTEGER DEFAULT 0, record_status TEXT DEFAULT 'LIVE', created_at TEXT)""",
    """CREATE TABLE IF NOT EXISTS sys_photo_link (
        link_id INTEGER PRIMARY KEY AUTOINCREMENT,
        kind TEXT NOT NULL DEFAULT 'SITE', title TEXT NOT NULL, url TEXT NOT NULL, source TEXT, note TEXT,
        entity_id INTEGER, event_id INTEGER,
        sort_order INTEGER DEFAULT 0, record_status TEXT DEFAULT 'LIVE', created_at TEXT)""",
    "CREATE INDEX IF NOT EXISTS ix_site_photo_ent ON sys_site_photo(entity_id)",
    "CREATE INDEX IF NOT EXISTS ix_photo_link_ent ON sys_photo_link(entity_id)",
)


def ensure(conn):
    for d in DDL:
        conn.execute(d)
    conn.commit()


def _now():
    return time.strftime('%Y-%m-%dT%H:%M:%S')


def make_jpgs(raw):
    """원본 바이트 → (jpg 1600, thumb 320, w, h). PIL 이 없으면 원본 그대로·thumb 없음."""
    try:
        from PIL import Image
    except Exception:                                  # noqa: BLE001
        return raw, None, None, None
    im = Image.open(io.BytesIO(raw))
    im = im.convert('RGB')
    w, h = im.size
    big = im.copy()
    big.thumbnail((MAX_SIDE, MAX_SIDE))
    th = im.copy()
    th.thumbnail((THUMB_SIDE, THUMB_SIDE))
    b1, b2 = io.BytesIO(), io.BytesIO()
    big.save(b1, 'JPEG', quality=86, optimize=True)
    th.save(b2, 'JPEG', quality=80, optimize=True)
    return b1.getvalue(), b2.getvalue(), big.size[0], big.size[1]


def add_photo(conn, raw, title, entity_id=None, caption='', source='', source_url='', license_='', commit=True):
    """사진 하나를 담는다 → photo_id. ⚠ 출처가 비면 담지 않는다(저작권 — 어디서 온 사진인지 적어야 한다)."""
    if not (source or '').strip():
        raise ValueError('출처를 적어야 합니다')
    jpg, th, w, h = make_jpgs(raw)
    cur = conn.execute(
        'INSERT INTO sys_site_photo(entity_id, title, caption, source, source_url, license, jpg, thumb, width, height, created_at) '
        'VALUES (?,?,?,?,?,?,?,?,?,?,?)', (entity_id, title, caption, source, source_url, license_, jpg, th, w, h, _now()))
    if commit:
        conn.commit()
    return cur.lastrowid


def update_photo(conn, photo_id, commit=True, **f):
    cols = [k for k in ('entity_id', 'title', 'caption', 'source', 'source_url', 'license', 'sort_order', 'record_status') if k in f]
    if not cols:
        return
    conn.execute('UPDATE sys_site_photo SET %s WHERE photo_id=?' % ','.join('%s=?' % k for k in cols), [f[k] for k in cols] + [photo_id])
    if commit:
        conn.commit()


def add_link(conn, kind, title, url, source='', note='', entity_id=None, event_id=None, commit=True):
    """사진 링크 하나 → link_id. ⚠ 주소·제목·출처 셋이 있어야 한다. 같은 주소가 LIVE 로 있으면 그 번호를 돌려준다(멱등)."""
    if kind not in {k for k, _ in LINK_KINDS}:
        raise ValueError('모르는 갈래: %s' % kind)
    if not (url or '').strip().lower().startswith('http'):
        raise ValueError('주소는 http 로 시작해야 합니다')
    if not (title or '').strip() or not (source or '').strip():
        raise ValueError('제목과 출처를 적어야 합니다')
    r = conn.execute("SELECT link_id FROM sys_photo_link WHERE url=? AND COALESCE(record_status,'LIVE')='LIVE'", (url.strip(),)).fetchone()
    if r:
        return r[0]
    cur = conn.execute('INSERT INTO sys_photo_link(kind, title, url, source, note, entity_id, event_id, created_at) VALUES (?,?,?,?,?,?,?,?)',
                       (kind, title.strip(), url.strip(), source.strip(), note, entity_id, event_id, _now()))
    if commit:
        conn.commit()
    return cur.lastrowid


def update_link(conn, link_id, commit=True, **f):
    cols = [k for k in ('kind', 'title', 'url', 'source', 'note', 'entity_id', 'event_id', 'sort_order', 'record_status') if k in f]
    if not cols:
        return
    conn.execute('UPDATE sys_photo_link SET %s WHERE link_id=?' % ','.join('%s=?' % k for k in cols), [f[k] for k in cols] + [link_id])
    if commit:
        conn.commit()


def photos(conn, entity_id=None, live=True):
    w = ["COALESCE(record_status,'LIVE')='LIVE'"] if live else []
    a = []
    if entity_id is not None:
        w.append('entity_id=?')
        a.append(entity_id)
    return conn.execute('SELECT photo_id, entity_id, title, caption, source, source_url, license, width, height, record_status, created_at '
                        'FROM sys_site_photo%s ORDER BY sort_order, photo_id' % ((' WHERE ' + ' AND '.join(w)) if w else ''), a).fetchall()


def links(conn, kind=None, entity_id=None, live=True):
    w = ["COALESCE(record_status,'LIVE')='LIVE'"] if live else []
    a = []
    if kind:
        w.append('kind=?')
        a.append(kind)
    if entity_id is not None:
        w.append('entity_id=?')
        a.append(entity_id)
    return conn.execute('SELECT link_id, kind, title, url, source, note, entity_id, event_id, record_status FROM sys_photo_link%s '
                        'ORDER BY kind, sort_order, link_id' % ((' WHERE ' + ' AND '.join(w)) if w else ''), a).fetchall()


def status(conn):
    ensure(conn)
    print('유적 사진', conn.execute("SELECT COUNT(*) FROM sys_site_photo WHERE COALESCE(record_status,'LIVE')='LIVE'").fetchone()[0],
          '· 링크', conn.execute("SELECT kind, COUNT(*) FROM sys_photo_link WHERE COALESCE(record_status,'LIVE')='LIVE' GROUP BY 1").fetchall())


def selftest():
    bad, n = [], [0]

    def ck(c, m):
        n[0] += 1
        if not c:
            bad.append(m)
    m = sqlite3.connect(':memory:')
    ensure(m)
    ensure(m)
    ck(m.execute("SELECT COUNT(*) FROM sqlite_master WHERE name IN ('sys_site_photo','sys_photo_link')").fetchone()[0] == 2, '표 둘')
    try:
        add_photo(m, b'x', 't', source='')
        ck(False, '출처 없는 사진을 막는다')
    except ValueError:
        ck(True, '')
    # 작은 진짜 그림
    try:
        from PIL import Image
        b = io.BytesIO()
        Image.new('RGB', (2000, 1200), (120, 100, 80)).save(b, 'PNG')
        pid = add_photo(m, b.getvalue(), '가버나움 회당', entity_id=5, source='Wikimedia', license_='CC BY-SA 4.0')
        r = m.execute('SELECT width, height, LENGTH(jpg), LENGTH(thumb) FROM sys_site_photo WHERE photo_id=?', (pid,)).fetchone()
        ck(r[0] == 1600 and r[1] == 960 and r[2] > 0 and r[3] > 0 and r[3] < r[2], '긴 변 1600 · 작은 그림: %s' % (r,))
    except ImportError:
        pid = add_photo(m, b'raw', '가버나움 회당', entity_id=5, source='Wikimedia')
    ck(len(photos(m, entity_id=5)) == 1 and len(photos(m, entity_id=6)) == 0, '장소별 사진')
    update_photo(m, pid, record_status='HIDE')
    ck(len(photos(m, entity_id=5)) == 0 and len(photos(m, entity_id=5, live=False)) == 1, '숨기기')
    for bad_args in (('SITE', '', 'http://a', 'src'), ('SITE', 't', 'ftp://a', 'src'), ('NOPE', 't', 'http://a', 'src'), ('SITE', 't', 'http://a', '')):
        try:
            add_link(m, *bad_args)
            ck(False, '막아야 한다: %s' % (bad_args,))
        except ValueError:
            ck(True, '')
    l1 = add_link(m, 'SITE', '헐몬산 설경', 'https://commons.wikimedia.org/x', 'Wikimedia Commons', entity_id=7)
    l2 = add_link(m, 'SITE', '헐몬산 설경(다시)', 'https://commons.wikimedia.org/x', 'Wikimedia Commons', entity_id=7)
    ck(l1 == l2, '같은 주소는 한 번(멱등)')
    l3 = add_link(m, 'MUSEUM', '산헤립 각주', 'https://britishmuseum.org/y', 'British Museum', event_id=3)
    ck([r[0] for r in links(m, entity_id=7)] == [l1] and len(links(m, kind='MUSEUM')) == 1 and len(links(m)) == 2, '갈래·장소로 거르기: %s' % (links(m),))
    update_link(m, l3, record_status='HIDE')
    ck(len(links(m)) == 1, '링크 숨기기')
    m.close()
    print('\n'.join('FAIL ' + b for b in bad))
    print('db_site_photo selftest: %s (%d/%d)' % ('OK' if not bad else 'FAIL', n[0] - len(bad), n[0]))
    return not bad


if __name__ == '__main__':
    a = sys.argv[1:] or ['--status']
    if a[0] == '--selftest':
        sys.exit(0 if selftest() else 1)
    conn = sqlite3.connect(DB)
    if a[0] == '--init':
        ensure(conn)
        print('ok')
    else:
        status(conn)
