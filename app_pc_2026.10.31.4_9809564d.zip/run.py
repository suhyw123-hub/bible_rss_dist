# -*- coding: utf-8 -*-
"""run.py — 스플래시(오늘의 구절)를 먼저 띄우고, 그 뒤에서 본체 앱을 빌드한다.
자동 전환하지 않는다 — 사용자가 스플래시를 '클릭'해야 앱으로 들어간다(구절 읽을 시간 확보).
실행: python run.py   (또는 python user_main.py — 첫 줄에서 여기 `main()` 으로 넘긴다)

★★★ **시작 절차는 이 한 곳이다**(2026-10-09 사용자 「바로시작에 마우스 아이콘을 클릭할 수
  있는 상태까지 시간이 걸린다 · 클릭 가능하다고 표시되더라도 클릭이 안된다 · 지금까지 지속된
  현상」). 바탕화면 바로가기는 `user_main.py` 를 켜는데 그 파일 끝에 **따로 지은 시작
  절차**가 있었고, 거기에는 ⓐ 짓는 동안 스플래시 클릭을 받아 주는 고리(`ON_PROGRESS`)가
  없어 **「바로 시작」이 보여도 앱을 다 지을 때까지 클릭이 안 먹고 그 클릭은 사라졌다**
  ⓑ 첫 실행 안내(온보딩)도 없었다 ⓒ 스플래시가 **1만 3천 줄을 다 읽은 뒤에야** 떴다.
  ⇒ `user_main.py` 는 맨 위에서 `run.main()` 을 부르고 여기만 시작 절차를 갖는다.
"""
import time
_t0 = time.perf_counter()

import os
import sys
import tkinter as tk


class _KeepOpen(__import__('io').RawIOBase):
    """★ 2026-10-29 닫히지 않는 출력 — 모듈 29개가 import 하자마자 `sys.stdout = TextIOWrapper(sys.stdout.buffer)` 로
    갈아 끼운다. 그때 앞 모듈이 만든 래퍼가 버려지며 닫히면 **그 밑의 진짜 출력까지 닫혀** 다음 print 에서
    앱이 통째로 죽었다(「나의 묵상」 탭으로 시작할 때 · book_label). 밑 출력을 이것으로 감싸 두면 버려지는 래퍼가
    무엇을 닫아도 진짜 출력은 산다. 모듈 29개를 고치는 대신 시작하는 문 한 곳에서 막는다."""

    def __init__(self, b):
        super().__init__()
        self._b = b

    def writable(self):
        return True

    def write(self, d):
        return self._b.write(d)

    def flush(self):
        try:
            self._b.flush()
        except Exception:                                   # noqa: BLE001
            pass

    def close(self):
        pass

    def fileno(self):
        return self._b.fileno()

    def isatty(self):
        return self._b.isatty()


def _keep_streams_open():
    import io
    for name in ('stdout', 'stderr'):
        s = getattr(sys, name, None)
        b = getattr(s, 'buffer', None)
        if b is None or isinstance(b, _KeepOpen):            # pythonw(창 없음)는 출력이 없다
            continue
        try:
            setattr(sys, name, io.TextIOWrapper(_KeepOpen(b), encoding='utf-8', errors='replace', line_buffering=True))
        except Exception:                                   # noqa: BLE001
            pass


def main(t0=None):
    t0 = t0 or _t0
    _keep_streams_open()
    import splash_screen

    # ★★ **안 보겠다면 아예 안 띄운다** (2026-09-05 사용자 지시 — 「표시안함
    #   즉, SKIP을 선택하면 **시작화면 없이 곧장 앱 실행**」).
    #   ⚠ 띄웠다가 곧 닫는 것이 아니라 **만들지도 않는다** — 그래야 실제로 빠르다.
    show = splash_screen.splash_enabled()
    splash = splash_screen.show_splash() if show else None
    if show:
        print(f"SPLASH_VISIBLE {time.perf_counter()-t0:.2f}s", flush=True)
    else:
        print("SPLASH_SKIP", flush=True)

    # ①-a 내 자료 되살리기 — 설정 ▸ 앱 관리에서 올려 둔 백업을 **DB 를 열기 전에** 갈아 끼운다(2026-10-13)
    try:
        import app_housekeep
        _kept = app_housekeep.apply_pending_restore()
        if _kept:
            print('[restore] 내 자료를 백업에서 되살렸다 — 옛 파일: %s' % _kept, flush=True)
    except Exception as _e:
        print(f"[restore] {_e}", flush=True)

    # ①-a2 앱 새 판 — 받아 둔 코드 꾸러미를 **DB 를 열기 전에** 갈아 끼운다(2026-10-25 · 데이터는 안 건드린다)
    #   ⚠ 이미 import 한 모듈은 옛것이다 — 갈아 끼웠으면 이 프로세스를 새로 띄워 새 코드로 시작한다.
    try:
        import app_update
        _um = app_update.apply_pending()
        if _um:
            print('[update] %s' % _um, flush=True)
            if splash is not None:
                try:
                    splash.destroy()
                except Exception:
                    pass
            import subprocess
            subprocess.Popen([sys.executable] + sys.argv, cwd=os.path.dirname(os.path.abspath(__file__)))
            return
    except Exception as _e:
        print(f"[update] {_e}", flush=True)

    # ①-b 첫 실행 온보딩 (앱 빌드 전 — 선택 언어/국가/역본/동의를 config에 기록 → 앱이 그 값으로 빌드)
    #    ⚠⚠ SKIP 이면 스플래시가 없어 부모가 `None` 이다 — 그대로 넘기면
    #      `master.wait_window` 가 터지고 `except` 가 삼켜 **첫 실행 마법사가
    #      조용히 건너뛰어진다**. 그래서 임시 창을 만들어 부모로 준다.
    ob_tmp = None
    try:
        import onboarding
        if splash is None:
            ob_tmp = tk.Tk()
            ob_tmp.withdraw()
        onboarding.maybe_run_first(splash or ob_tmp)
    except Exception as _e:
        print(f"[onboarding] {_e}", flush=True)
    finally:
        if ob_tmp is not None:
            try:
                ob_tmp.destroy()
            except Exception:
                pass

    # ② 본체 import + 빌드(스플래시 뒤에서). 앱은 숨겨둔 채 준비만.
    if splash is not None:
        try:
            splash.update()          # 무거운 import 전에 한 번 — 스플래시가 그려진 채 기다린다
        except Exception:
            pass
    import user_main
    tk._default_root = None     # 스플래시(별도 Tk)가 default root 점유 방지 → 앱이 default root

    clicked = [False]

    def _go(*_):
        # ★ 본체를 짓는 동안 눌렀으면 표식만 남는다 — 아래에서 mainloop 를 건너뛴다
        #   (`quit()` 은 도는 mainloop 가 없으면 아무 일도 안 한다).
        clicked[0] = True
        try:
            splash.quit()
        except Exception:
            pass

    # ★★★ **P1 이 서면 곧바로 무장한다** (2026-09-05 사용자 — 「p1 화면만 표시될
    #   수 있는 상황이면 바로시작 라벨이 표시되어도 된다」).
    #   탭은 이미 지연 빌드라(§29) 눌러 들어가도 안전하다.
    def _arm_early(_app):
        if splash is None:
            return
        try:
            splash_screen.arm_dismiss(splash, _go)
            print(f"P1_READY {time.perf_counter()-t0:.2f}s", flush=True)
        except Exception:
            pass

    def _pump():
        """본체가 한 단계를 지날 때마다 스플래시 이벤트를 한 번 돌린다(2026-09-16 · 1.txt 2·55).
        그전에는 P1_READY 뒤 APP_READY 까지 클릭이 큐에만 쌓여 「눌러도 안 된다」로 보였다."""
        if splash is None:
            return
        try:
            splash.update()
        except Exception:
            pass

    user_main.ON_P1_READY = _arm_early
    user_main.ON_PROGRESS = _pump
    # ★ 짓는 동안 본 창이 화면에 올라가지 않게 한다(2026-09-17 「메인화면이 반짝」) —
    #   `_pump` 가 이벤트를 돌리므로 **다 짓고 숨기면 늦다**.
    if splash is not None:
        user_main.START_HIDDEN = True
    app = user_main.MatrixMasterApp()
    try:
        app.withdraw()          # 클릭 전까지 앱은 숨김(구절화면 뒤에 대기)
    except Exception:
        pass
    print(f"APP_READY {time.perf_counter()-t0:.2f}s", flush=True)

    # ③ 클릭 대기 — 자동 전환 없음. 스플래시 클릭 시 그 자체 mainloop 탈출.
    #    ⚠ SKIP 이면 기다릴 것이 없다(스플래시 자체가 없다).
    if splash is not None:
        # ⚠ **다시 무장해도 해가 없다**(멱등) — P1 훅이 이미 켰으면 같은 값이다.
        #   훅이 어떤 이유로 안 불렸을 때의 안전망이다.
        splash_screen.arm_dismiss(splash, _go)
        if os.environ.get('SPLASH_TEST'):
            splash.after(1200, _go)    # 테스트: 자동 클릭

        if not clicked[0]:
            splash.mainloop()          # 사용자가 구절 읽고 클릭할 때까지 대기

    # ④ 클릭됨 → 스플래시 닫고 앱 표시
    try:
        if splash is not None:
            splash.destroy()
    except Exception:
        pass
    try:
        app.deiconify(); app.lift()
    except Exception:
        pass
    try:
        app.restore_window_state()     # ★ 최대화로 닫았으면 다시 최대화(나타난 뒤에)
    except Exception:
        pass

    if os.environ.get('SPLASH_TEST'):
        app.after(1500, app.destroy)

    # ⚠ ad-config 원격 fetch 는 **여기서 안 부른다** — `MatrixMasterApp` 안으로
    #   옮겼다(2026-09-26). 같은 일을 하는 자리를 둘로 두지 않는다.
    app.mainloop()


if __name__ == '__main__':
    main()
