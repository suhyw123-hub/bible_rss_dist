# -*- coding: utf-8 -*-
"""insert_helpers — 연구/설교노트 **구절 넣기 · 원어 넣기** 팝업 (317차-18 ⑨ · data.md Z-2v · docs/1.txt 41).

★ 사용자 설계 — 「책/장/절 콤보상자를 배치해놓고 선택하면 본문 표시되고, 입력 버튼 누르면 선택한 포맷에
  맞게 본문을 입력」. 글 속 약명을 골라 바꾸는 길은 안 만든다(영역을 잘못 잡으면 엉뚱한 구절이 들어간다).
  · 약명 입력란은 **콤보를 맞추기만** 한다 — 넣는 것은 언제나 미리보기를 본 뒤 [넣기].
★ 고른 포맷은 기억한다 — 사용자 = user_config · 관리자 = sys_config(`side`).
⚠ 단추는 위(§0) · 색은 테마 역할(§36) · 사용자·관리자 화면이 **이 모듈 하나**를 쓴다.
"""
import tkinter as tk
from tkinter import ttk

import appdb
import cite_format as CF
import i18n


def _btn(parent, text, cmd, C):
    return tk.Button(parent, text=text, command=cmd, bd=0, padx=10, pady=2,
                     bg=C('accent_bg', '#D6EAF8'), fg=C('accent', '#1A5276'))


class _Base(tk.Toplevel):
    def __init__(self, parent, target, db_path=None, lang='KO', side='USER', C=None, title=''):
        super().__init__(parent)
        self.C = C or (lambda r, f: f)
        self.target, self.db_path, self.side = target, db_path, side
        self.lang = (lang or 'KO').upper()
        self.title(title)
        self.top = tk.Frame(self)
        self.top.pack(fill='x', padx=8, pady=(8, 4))
        self.put_btn = _btn(self.top, i18n.t('IH_PUT', '넣기'), self._put, self.C)
        self.put_btn.pack(side='left')
        with appdb.connect(db_path) as c:
            self.fmt_c, self.fmt_o = CF.get_fmt(c, side)
        self.preview = tk.Label(self, text='', anchor='nw', justify='left', wraplength=560, padx=8, pady=6,
                                bg=self.C('view_bg', '#FFFFFF'), fg=self.C('fg', '#222222'), relief='solid', bd=1)

    def _adopt(self):
        try:
            import ui_theme
            ui_theme.adopt(self)
        except Exception:                                 # noqa: BLE001
            pass

    def text(self):
        return ''

    def _put(self):
        s = self.text()
        if not s or self.target is None:
            return
        try:
            self.target.insert('insert', s)
            self.target.focus_set()
        except Exception:                                 # noqa: BLE001
            pass
        self.destroy()


# ══════════════════════════════════════════════════════════════════
class VerseInsert(_Base):
    def __init__(self, parent, target, db_path=None, lang='KO', side='USER', C=None):
        super().__init__(parent, target, db_path, lang, side, C, i18n.t('IH_VERSE', '구절 넣기'))
        with appdb.connect(db_path) as c:
            self.books = c.execute(
                "SELECT b.bcode, COALESCE(n.full_name, CAST(b.bcode AS TEXT)) FROM"
                " (SELECT DISTINCT bcode FROM bible_index) b LEFT JOIN book_names n"
                " ON n.book_code=b.bcode AND n.lang_code=? ORDER BY b.bcode", (self.lang,)).fetchall()
            vers = [r[0] for r in c.execute(
                "SELECT version_code FROM bible_version WHERE coverage_scope IN ('FULL','NT_ONLY','OT_ONLY')"
                " AND version_code IN (SELECT DISTINCT version_code FROM bible_content) ORDER BY version_code")]
            self.ver0 = CF.version_for(c, self.lang) or 'BSB'
        # 위 띠 — [넣기] · 포맷
        tk.Label(self.top, text=i18n.t('IH_FMT', '꼴')).pack(side='left', padx=(12, 2))
        self.fmt_cb = ttk.Combobox(self.top, state='readonly', width=16,
                                   values=[i18n.t('IH_C_' + k, CF.CITE_LABEL[k]) for k in CF.CITE])
        self.fmt_cb.current(CF.CITE.index(self.fmt_c))
        self.fmt_cb.pack(side='left')
        self.fmt_cb.bind('<<ComboboxSelected>>', lambda _e: self._fmt_pick())
        tk.Label(self.top, text=i18n.t('IH_VER', '역본')).pack(side='left', padx=(12, 2))
        self.ver_cb = ttk.Combobox(self.top, state='readonly', width=8, values=vers)
        if self.ver0 in vers:
            self.ver_cb.set(self.ver0)
        self.ver_cb.pack(side='left')
        self.ver_cb.bind('<<ComboboxSelected>>', lambda _e: self._show())
        # 둘째 줄 — 약명 입력(콤보를 맞추기만) · 책·장·절~끝절
        r2 = tk.Frame(self)
        r2.pack(fill='x', padx=8, pady=2)
        tk.Label(r2, text=i18n.t('IH_ABBR', '약명')).pack(side='left')
        self.abbr_e = ttk.Entry(r2, width=12)
        self.abbr_e.pack(side='left', padx=(2, 4))
        self.abbr_e.bind('<Return>', lambda _e: self._from_abbr())
        _btn(r2, i18n.t('IH_FIND', '맞추기'), self._from_abbr, self.C).pack(side='left', padx=(0, 10))
        self.book_cb = ttk.Combobox(r2, state='readonly', width=14, values=[b[1] for b in self.books])
        self.book_cb.pack(side='left')
        self.ch_cb = ttk.Combobox(r2, state='readonly', width=4)
        self.ch_cb.pack(side='left', padx=2)
        self.vs_cb = ttk.Combobox(r2, state='readonly', width=4)
        self.vs_cb.pack(side='left', padx=2)
        tk.Label(r2, text='~').pack(side='left')
        self.ve_cb = ttk.Combobox(r2, state='readonly', width=4)
        self.ve_cb.pack(side='left', padx=2)
        self.book_cb.bind('<<ComboboxSelected>>', lambda _e: self._fill_ch())
        self.ch_cb.bind('<<ComboboxSelected>>', lambda _e: self._fill_vs())
        self.vs_cb.bind('<<ComboboxSelected>>', lambda _e: self._vs_pick())
        self.ve_cb.bind('<<ComboboxSelected>>', lambda _e: self._show())
        self.msg = tk.Label(self, text='', anchor='w', padx=8, fg=self.C('danger', '#922B21'))
        self.msg.pack(fill='x')
        self.preview.pack(fill='both', expand=True, padx=8, pady=(2, 8))
        self.geometry('680x260')
        if self.books:
            self.book_cb.current(0)
            self._fill_ch()
        self._adopt()

    def _bcode(self):
        i = self.book_cb.current()
        return self.books[i][0] if i >= 0 else None

    def _fill_ch(self, ch=None):
        with appdb.connect(self.db_path) as c:
            chs = [str(r[0]) for r in c.execute("SELECT DISTINCT chapter FROM bible_index WHERE bcode=? ORDER BY chapter",
                                                (self._bcode(),))]
        self.ch_cb.config(values=chs)
        self.ch_cb.set(str(ch) if ch and str(ch) in chs else (chs[0] if chs else ''))
        self._fill_vs()

    def _fill_vs(self, vs=None, ve=None):
        with appdb.connect(self.db_path) as c:
            vss = [str(r[0]) for r in c.execute("SELECT verse FROM bible_index WHERE bcode=? AND chapter=? ORDER BY verse",
                                                (self._bcode(), int(self.ch_cb.get() or 1)))]
        self.vs_cb.config(values=vss)
        self.ve_cb.config(values=vss)
        self.vs_cb.set(str(vs) if vs and str(vs) in vss else (vss[0] if vss else ''))
        self.ve_cb.set(str(ve) if ve and str(ve) in vss else self.vs_cb.get())
        self._show()

    def _vs_pick(self):
        if int(self.ve_cb.get() or 0) < int(self.vs_cb.get() or 0):
            self.ve_cb.set(self.vs_cb.get())
        self._show()

    def _from_abbr(self):
        """약명 → 콤보만 맞춘다(넣지 않는다). 못 읽으면 그렇다고 말한다."""
        s = (self.abbr_e.get() or '').strip()
        try:
            import scripture_ref as SR
            with appdb.connect(self.db_path) as c:
                got = SR.find(c, s, self.lang, limit=1) or SR.find(c, s, 'KO', limit=1) or SR.find(c, s, 'EN', limit=1)
                if not got:
                    raise ValueError
                sv, ev = got[0][0], got[0][1] or got[0][0]
                a = c.execute("SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?", (sv,)).fetchone()
                b = c.execute("SELECT chapter, verse FROM bible_index WHERE verse_id=?", (ev,)).fetchone()
        except Exception:                                 # noqa: BLE001
            self.msg.config(text=i18n.t('IH_ABBR_BAD', '이 약명을 읽지 못했습니다 — 예: 요3:16 · 요 3:16-18'))
            return
        self.msg.config(text='')
        idx = [x[0] for x in self.books].index(a[0])
        self.book_cb.current(idx)
        self._fill_ch(a[1])
        self._fill_vs(a[2], b[1] if b and b[0] == a[1] else a[2])

    def _range(self):
        with appdb.connect(self.db_path) as c:
            b, ch = self._bcode(), int(self.ch_cb.get() or 1)
            sv = c.execute("SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?",
                           (b, ch, int(self.vs_cb.get() or 1))).fetchone()
            ev = c.execute("SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?",
                           (b, ch, int(self.ve_cb.get() or 1))).fetchone()
        return (sv[0] if sv else None), (ev[0] if ev else None)

    def _fmt_pick(self):
        self.fmt_c = CF.CITE[max(0, self.fmt_cb.current())]
        with appdb.connect(self.db_path) as c:
            CF.set_fmt(c, self.side, cite=self.fmt_c)
        self._show()

    def text(self):
        sv, ev = self._range()
        if not sv:
            return ''
        ver = self.ver_cb.get() or self.ver0
        with appdb.connect(self.db_path) as c:
            body = CF.verse_text(c, sv, ev, ver)
            if not body:
                return ''
            ref = CF.abbr(c, sv, ev if ev != sv else None, self.lang)
            return CF.render_cite(self.fmt_c, body, ref, self.lang, CF.version_label(c, ver, self.lang))

    def _show(self):
        s = self.text()
        self.preview.config(text=s or i18n.t('IH_NO_TEXT', '이 역본에 이 구절 본문이 없습니다.'))
        self.put_btn.config(state='normal' if s else 'disabled')


# ══════════════════════════════════════════════════════════════════
class OrigInsert(_Base):
    def __init__(self, parent, target, db_path=None, lang='KO', side='USER', C=None, word=''):
        super().__init__(parent, target, db_path, lang, side, C, i18n.t('IH_ORIG', '원어 넣기'))
        tk.Label(self.top, text=i18n.t('IH_FMT', '꼴')).pack(side='left', padx=(12, 2))
        self.fmt_cb = ttk.Combobox(self.top, state='readonly', width=18,
                                   values=[i18n.t('IH_O_' + k, CF.ORIG_LABEL[k]) for k in CF.ORIG])
        self.fmt_cb.current(CF.ORIG.index(self.fmt_o))
        self.fmt_cb.pack(side='left')
        self.fmt_cb.bind('<<ComboboxSelected>>', lambda _e: self._fmt_pick())
        r2 = tk.Frame(self)
        r2.pack(fill='x', padx=8, pady=2)
        tk.Label(r2, text=i18n.t('IH_WORD', '낱말')).pack(side='left')
        self.word_e = ttk.Entry(r2, width=16)
        self.word_e.pack(side='left', padx=(2, 4))
        self.word_e.insert(0, word or '')
        self.word_e.bind('<Return>', lambda _e: self._find())
        _btn(r2, i18n.t('IH_FIND2', '찾기'), self._find, self.C).pack(side='left')
        tk.Label(r2, text=i18n.t('IH_MEAN', '뜻')).pack(side='left', padx=(12, 2))
        self.mean_e = ttk.Entry(r2, width=14)
        self.mean_e.pack(side='left')
        self.mean_e.bind('<KeyRelease>', lambda _e: self._show())
        lf = tk.Frame(self)
        lf.pack(fill='both', expand=True, padx=8, pady=2)
        self.lb = tk.Listbox(lf, height=8, exportselection=False, activestyle='none')
        sb = ttk.Scrollbar(lf, orient='vertical', command=self.lb.yview)
        self.lb.config(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self.lb.pack(side='left', fill='both', expand=True)
        self.lb.bind('<<ListboxSelect>>', lambda _e: self._show())
        self.msg = tk.Label(self, text='', anchor='w', padx=8, fg=self.C('fg_dim', '#7F8C8D'))
        self.msg.pack(fill='x')
        self.preview.pack(fill='x', padx=8, pady=(2, 8))
        self.rows = []
        self.geometry('640x380')
        if word:
            self._find()
        self._adopt()

    def _find(self):
        w = (self.word_e.get() or '').strip()
        with appdb.connect(self.db_path) as c:
            self.rows = CF.lemma_candidates(c, w, self.lang)
        self.lb.delete(0, 'end')
        for st, form, tr, lat, gl, occ in self.rows:
            self.lb.insert('end', '%s  %s  %s · %s  (%d)  %s' % (form, tr, lat, st, occ, (gl or '')[:40]))
        if self.rows:
            self.lb.selection_set(0)
            if not self.mean_e.get().strip():
                self.mean_e.insert(0, w)
        self.msg.config(text=(i18n.t('IH_N', '%d개') % len(self.rows)) if self.rows else
                        i18n.t('IH_NONE', '찾은 원어가 없습니다 — 주요용어 이름이나 영어 뜻으로 찾습니다.'))
        self._show()

    def _fmt_pick(self):
        self.fmt_o = CF.ORIG[max(0, self.fmt_cb.current())]
        with appdb.connect(self.db_path) as c:
            CF.set_fmt(c, self.side, orig=self.fmt_o)
        self._show()

    def text(self):
        sel = self.lb.curselection()
        if not sel or sel[0] >= len(self.rows):
            return ''
        st, form, tr, lat, _gl, _o = self.rows[sel[0]]
        return CF.render_orig(self.fmt_o, self.mean_e.get() or self.word_e.get(), tr, form, lat, st)

    def _show(self):
        s = self.text()
        self.preview.config(text=s)
        self.put_btn.config(state='normal' if s else 'disabled')


def selftest():
    ok = fail = 0

    def ck(c, m, got=''):
        nonlocal ok, fail
        if c:
            ok += 1
            print('  OK  ', m)
        else:
            fail += 1
            print('  FAIL', m, '|', got)
    root = tk.Tk()
    root.withdraw()
    t = tk.Text(root)
    with appdb.connect() as c:
        keep = CF.get_fmt(c, 'USER'), [r for r in c.execute(
            "SELECT config_key, config_val FROM user_config WHERE config_key IN ('CITE_FMT','ORIG_FMT')")]
    try:
        v = VerseInsert(root, t, lang='KO')
        v.abbr_e.insert(0, '요3:16'); v._from_abbr()
        ck(v.text().startswith('“하나님이 세상을') and v.text().endswith('(요3:16)'), '★ 약명 → 콤보 → 미리보기(포맷 ①)', v.text())
        v.abbr_e.delete(0, 'end'); v.abbr_e.insert(0, '없는책9:9'); v._from_abbr()
        ck('읽지 못했습니다' in v.msg.cget('text'), '못 읽은 약명은 말하고 콤보를 안 바꾼다')
        v.ve_cb.set('18'); v._show()
        ck(v.text().endswith('(요3:16-18)'), '끝절 콤보 → 구간', v.text()[-14:])
        v.fmt_cb.current(2); v._fmt_pick()
        ck('개역한글' in v.text(), '포맷 ③ — 역본 이름', v.text()[-20:])
        v._put()
        ck('개역한글' in t.get('1.0', 'end'), '[넣기] — 커서 자리에 들어간다')
        o = OrigInsert(root, t, lang='KO', word='은혜')
        o.fmt_cb.current(0); o._fmt_pick()    # 저장된 서식에 기대지 않는다(사용자가 다른 꼴을 골라 둘 수 있다)
        ck(o.rows and o.text() == '은혜(카리스)', '★ 원어 — 「은혜」 → 은혜(카리스)', o.text())
        o.fmt_cb.current(2); o._fmt_pick()
        ck(o.text() == '은혜(카리스, charis)', '원어 포맷 ③(사용자 예)', o.text())
        with appdb.connect() as c:
            ck(CF.get_fmt(c, 'USER') == ('Q_REF_VER', 'M_T_L'), '선택한 포맷을 기억한다', CF.get_fmt(c, 'USER'))
        o.destroy()
    finally:
        with appdb.connect() as c:                        # 설정 원복
            c.execute("DELETE FROM user_config WHERE config_key IN ('CITE_FMT','ORIG_FMT')")
            for k, val in keep[1]:
                c.execute("INSERT INTO user_config(config_key, config_val) VALUES(?,?)", (k, val))
            c.commit()
        root.destroy()
    print('insert_helpers selftest: %s (%d/%d)' % ('OK' if not fail else 'FAIL', ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
