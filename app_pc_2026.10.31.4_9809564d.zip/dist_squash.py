# -*- coding: utf-8 -*-
"""배포 저장소(GitHub bible_rss_dist) 기록을 한 판으로 다시 세운다 (2026-10-25 신설·영구 · `--selftest` 의무).

★ 왜 — 팩을 올릴 때마다 옛 판이 git 기록에 남는다(사진 팩 50 MB 포함). 실측 2026-10-25 커밋 122 · 기록(.git) 547 MB · 지금 파일 ≈234 MB.
  사용자 폰·PC 는 **파일 주소**(jsDelivr · raw · `@main/<이름>`)로 받으므로 기록이 없어도 아무 영향이 없다.
★ 하는 일 — 지금 파일 그대로 **커밋 하나**로 다시 세워 강제로 올린다(`--force-with-lease` — 그사이 남이 올렸으면 멈춘다)
  → 이 PC 의 옛 기록도 걷는다(reflog · gc).
⚠⚠ **되돌릴 수 없는 일이다** — GitHub 의 옛 기록이 사라진다. 그래서 문 셋:
  ① 작업 복사본이 깨끗하고 원격과 같아야 한다(안 올린 변경이 있으면 멈춘다)
  ② 새 커밋의 파일 나무(tree)가 옛 것과 **글자 그대로 같아야** 올린다 — 다르면 되돌리고 멈춘다
  ③ `run(confirm=True)` 라야 돈다(화면은 한 번 더 누르게 한다 · 명령줄은 `--run --yes`).

    python dist_squash.py --selftest     # 임시 저장소 둘(원격 흉내 bare + 작업 복사본)에서만 — 진짜 저장소 0
    python dist_squash.py --status       # 커밋 수 · 기록 크기 · 지금 파일 크기
    python dist_squash.py --run --yes    # 다시 세운다(되돌릴 수 없다)
"""
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.path.join(HERE, 'rss_dist', '_repo')
BRANCH = 'main'
#: 기록이 이만큼 넘으면 「다시 세울 때」라고 알린다(자동 배포 점검 · 화면)
WARN_MB = 400


def _git(work, *args):
    import locale
    return subprocess.run(['git', *args], cwd=work, capture_output=True, text=True,
                          encoding=locale.getpreferredencoding(False), errors='replace')


def _dir_mb(p):
    n = 0
    for root, _ds, fs in os.walk(p):
        for f in fs:
            try:
                n += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return n / 1048576


def status(work=WORK):
    """→ dict(ok, commits, git_mb, files_mb, warn, msg)."""
    if not os.path.isdir(os.path.join(work, '.git')):
        return {'ok': False, 'msg': '배포 저장소 작업 복사본이 없습니다(한 번이라도 발행하면 생깁니다)'}
    n = _git(work, 'rev-list', '--count', 'HEAD')
    commits = int(n.stdout.strip() or 0) if n.returncode == 0 else 0
    git_mb = _dir_mb(os.path.join(work, '.git'))
    files = 0.0
    for name in os.listdir(work):
        if name == '.git':
            continue
        p = os.path.join(work, name)
        files += _dir_mb(p) if os.path.isdir(p) else os.path.getsize(p) / 1048576
    return {'ok': True, 'commits': commits, 'git_mb': round(git_mb, 1), 'files_mb': round(files, 1),
            'warn': git_mb >= WARN_MB and commits > 1,
            'msg': '커밋 %d · 기록 %.0f MB · 지금 파일 %.0f MB' % (commits, git_mb, files)}


def run(work=WORK, confirm=False, log=print, branch=BRANCH):
    """다시 세운다 → dict(ok, msg, before, after). ⚠ confirm=True 라야 돈다."""
    if not confirm:
        return {'ok': False, 'msg': '확인 없이 돌지 않습니다(되돌릴 수 없는 일)'}
    if not os.path.isdir(os.path.join(work, '.git')):
        return {'ok': False, 'msg': '작업 복사본이 없습니다'}
    before = status(work)
    # ① 깨끗하고 원격과 같아야
    if _git(work, 'status', '--porcelain').stdout.strip():
        return {'ok': False, 'msg': '안 올린 변경이 있습니다 — 먼저 발행을 끝내세요'}
    f = _git(work, 'fetch', 'origin', branch)
    if f.returncode != 0:
        return {'ok': False, 'msg': '원격을 못 읽었습니다: %s' % (f.stderr or f.stdout)[:120]}
    head = _git(work, 'rev-parse', 'HEAD').stdout.strip()
    remote = _git(work, 'rev-parse', 'origin/%s' % branch).stdout.strip()
    if head != remote:
        return {'ok': False, 'msg': '이 PC 와 원격이 다릅니다(%s ↔ %s) — 먼저 맞추세요' % (head[:7], remote[:7])}
    tree = _git(work, 'rev-parse', 'HEAD^{tree}').stdout.strip()
    log('  지금 %s · 나무 %s' % (before['msg'], tree[:10]))
    # ② 한 커밋으로 — 옛 나무 그대로(commit-tree 는 작업 복사본을 안 건드린다)
    msg = 'dist squash %s (from %s · %d commits)' % (time.strftime('%Y-%m-%d'), head[:7], before['commits'])
    ct = _git(work, 'commit-tree', tree, '-m', msg)
    new = ct.stdout.strip()
    if ct.returncode != 0 or not new:
        return {'ok': False, 'msg': '커밋을 못 만들었습니다: %s' % (ct.stderr or '')[:120]}
    if _git(work, 'rev-parse', new + '^{tree}').stdout.strip() != tree:
        return {'ok': False, 'msg': '새 커밋의 파일이 옛 것과 다릅니다 — 올리지 않습니다'}
    # ③ 강제로 — 그사이 남이 올렸으면 멈춘다(lease)
    p = _git(work, 'push', '--force-with-lease=%s:%s' % (branch, head), 'origin', '%s:refs/heads/%s' % (new, branch))
    if p.returncode != 0:
        return {'ok': False, 'msg': '올리지 못했습니다(원격 그대로): %s' % (p.stderr or p.stdout)[:160]}
    # 이 PC — 새 커밋으로 옮기고 옛 기록을 걷는다
    _git(work, 'reset', '--soft', new)
    _git(work, 'update-ref', 'refs/remotes/origin/%s' % branch, new)
    _git(work, 'reflog', 'expire', '--expire=now', '--all')
    _git(work, 'gc', '--prune=now', '--quiet')
    after = status(work)
    log('  다시 세웠습니다 — %s' % after['msg'])
    return {'ok': True, 'msg': '다시 세웠습니다 · %s → %s' % (before['msg'], after['msg']), 'before': before, 'after': after}


def selftest():
    import shutil
    import tempfile
    ok = [0, 0]

    def ck(m, c):
        ok[0 if c else 1] += 1
        print(('  PASS ' if c else '  FAIL ') + m)
    root = tempfile.mkdtemp()
    try:
        bare = os.path.join(root, 'remote.git')
        work = os.path.join(root, 'work')
        subprocess.run(['git', 'init', '--bare', '-q', '-b', 'main', bare], check=True)
        subprocess.run(['git', 'clone', '-q', bare, work], check=True, capture_output=True)
        _git(work, 'config', 'user.email', 't@t')
        _git(work, 'config', 'user.name', 't')
        _git(work, 'checkout', '-q', '-B', 'main')
        for i in range(5):                       # 판 다섯 — 큰 파일을 바꿔 가며
            with open(os.path.join(work, 'pack.bin'), 'wb') as f:
                f.write(os.urandom(200_000))
            with open(os.path.join(work, 'manifest.tsv'), 'w', encoding='utf-8') as f:
                f.write('v%d\n' % i)
            _git(work, 'add', '-A')
            _git(work, 'commit', '-q', '-m', 'p%d' % i)
        _git(work, 'push', '-q', '-u', 'origin', 'main')
        st = status(work)
        ck('상태 — 커밋 5', st['ok'] and st['commits'] == 5)
        tree0 = _git(work, 'rev-parse', 'HEAD^{tree}').stdout.strip()
        ck('확인 없이는 안 돈다', not run(work, confirm=False, log=lambda *_: None)['ok'])
        with open(os.path.join(work, 'manifest.tsv'), 'a', encoding='utf-8') as f:
            f.write('x\n')
        ck('안 올린 변경이 있으면 멈춘다', '안 올린 변경' in run(work, confirm=True, log=lambda *_: None)['msg'])
        _git(work, 'checkout', '-q', '--', 'manifest.tsv')
        r = run(work, confirm=True, log=lambda *_: None)
        ck('다시 세움 — 성공', r['ok'])
        ck('원격 커밋 하나', _git(work, 'rev-list', '--count', 'origin/main').stdout.strip() == '1'
           and subprocess.run(['git', 'rev-list', '--count', 'main'], cwd=bare, capture_output=True, text=True).stdout.strip() == '1')
        ck('파일은 글자 그대로', _git(work, 'rev-parse', 'HEAD^{tree}').stdout.strip() == tree0
           and open(os.path.join(work, 'manifest.tsv'), encoding='utf-8').read() == 'v4\n')
        ck('작업 복사본 깨끗', not _git(work, 'status', '--porcelain').stdout.strip())
        # 그사이 다른 곳에서 올렸으면(원격이 앞서면) 멈춘다
        other = os.path.join(root, 'other')
        subprocess.run(['git', 'clone', '-q', bare, other], check=True, capture_output=True)
        _git(other, 'config', 'user.email', 't@t')
        _git(other, 'config', 'user.name', 't')
        with open(os.path.join(other, 'new.txt'), 'w') as f:
            f.write('n')
        _git(other, 'add', '-A')
        _git(other, 'commit', '-q', '-m', 'other')
        _git(other, 'push', '-q', 'origin', 'main')
        r2 = run(work, confirm=True, log=lambda *_: None)
        ck('원격이 앞서면 멈추고 원격 그대로', not r2['ok'] and '다릅니다' in r2['msg']
           and subprocess.run(['git', 'rev-list', '--count', 'main'], cwd=bare, capture_output=True, text=True).stdout.strip() == '2')
        ck('작업 복사본이 없으면 그렇게 말한다', not status(os.path.join(root, 'none'))['ok'])
    finally:
        shutil.rmtree(root, ignore_errors=True)
    print('dist_squash selftest %d/%d' % (ok[0], sum(ok)))
    return ok[1] == 0


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    elif '--status' in a:
        print(status()['msg'])
    elif '--run' in a:
        print(run(confirm='--yes' in a)['msg'])
    else:
        print(__doc__)
