# -*- coding: utf-8 -*-
"""구절 구간 판정 — **단일 문** (2026-09-09 신설 · 2026-09-10 `sort_order` 로 개정).

★★★ **`verse_id` 는 신원이고 `sort_order` 가 차례다.**

      계 22:21 = vid 31102 · sort 306730      ← 성경의 마지막
      아  6:14 = vid **31113** · sort 176285   ← 번호는 맨 뒤, 차례는 제자리
      요삼1:15 = vid **31114** · sort 306735

  `verse_id` 로 범위를 재면 **「아6:1~6:14」 한 편이 그 사이 13,447절
  (요한계시록까지)을 통째로 덮는다.** 실측 그런 연결 18행이 **31,104절 중
  13,448절(43.2%)** 을 오염시키고 있었다(2026-09-09 사용자 신고
  「계1:1에 아가서 6장 영상이 걸려 있다」).

★★★ **왜 이렇게 될 수밖에 없나 — 끼어드는 절은 번호를 뒤에서 받는다.**
  새 역본이 우리에게 없는 절을 가져오면 `bible_contents_importer` 가
  `verse_id = MAX+1`(31115, 31116 …)을 준다. **가운데에 번호를 끼울 수 없기
  때문이다.** 그래서 `sort_order`(절 번호 × 10)를 따로 두어 **가운데를
  비워 두었다** — 176280 과 176290 사이에 176285 가 들어간다.
  ⇒ **차례를 묻는 자리는 언제나 `sort_order` 를 본다.** 역본을 담을 때마다
    이런 절이 하나씩 늘므로, 이것은 지금 두 절의 문제가 아니라 **구조**다.

★★ **책 가드는 남긴다.** `sort_order` 만으로 이미 정확하지만, 옛 DB 에 그 칸이
  비어 있으면 조용히 늘 참이 될 수 있다. 한 줄 값이 싸다.
  ⚠ 그리고 책 가드**만**으로는 못 막는 자리가 있다 — 아6:1~6:14 가 **같은 책**
    아7·8장을 먹는 것(실측 216절). 그것이 이번 개정의 이유다.

⚠ **`verse_id` 를 다시 매기지 않는다** — 31,104절의 번호가 바뀌면 그것을
  가리키는 연결·플랜·주석이 통째로 깨진다. 판정하는 쪽을 고치는 것이 싸다.
⚠ **화면마다 SQL 을 다시 쓰지 않는다** — 한 곳만 빠져도 그 화면에서 43%가
  오염된다. 실제로 `link_picker` 만 가드가 있고 나머지는 없었다.
"""
import io
import sys

#: 이 절이 그 구간 안인가 — **물음표 셋**(vid, vid, vid)
#: ⚠⚠⚠ **끝 절 0 은 「없음」이다** (2026-09-15 실측으로 잡았다) — 묵상노트가
#:   단일 절을 `target_id=0` 으로 적는데(`note_refr_panel._save_record` ·
#:   `medi_note`), `COALESCE({e},{s})` 는 0 을 값으로 보아 **0번 절의 차례**를
#:   묻고 NULL 이 되어 그 노트가 **조용히 목록에서 빠졌다**. 실측 노트 40편 중
#:   31편이 안 보였고, 새로 쓴 글이 저장되는 순간 사라졌다. 0 은 어느 표에서도
#:   절 번호가 아니므로 `NULLIF(…,0)` 이 어디에나 안전하다. selftest 가 잰다.
_COVERS = (
    "(SELECT sort_order FROM bible_index WHERE verse_id={a}.{s})"
    " <= (SELECT sort_order FROM bible_index WHERE verse_id=?)"
    " AND (SELECT sort_order FROM bible_index"
    "       WHERE verse_id=COALESCE(NULLIF({a}.{e},0),{a}.{s}))"
    " >= (SELECT sort_order FROM bible_index WHERE verse_id=?)"
    " AND (SELECT bcode FROM bible_index WHERE verse_id={a}.{s})"
    "    =(SELECT bcode FROM bible_index WHERE verse_id=?)")

#: 그 구간의 절들 — 구간 열쇠가 상수일 때(파이썬 값). 물음표 셋(sv, ev, sv)
#: ⚠⚠ **칸 이름을 반드시 별칭으로 한정한다**(`bi.verse_id`) — 안 하면
#:   하위질의 안에서 `verse_id=verse_id` 가 되어 **제 칸끼리 비교**하고 늘
#:   참이 된다(§223차 `m.media_id=media_id` 와 같은 함정). selftest 가 잰다.
BETWEEN_SQL = (
    "(SELECT sort_order FROM bible_index WHERE bible_index.verse_id={v})"
    " BETWEEN (SELECT sort_order FROM bible_index WHERE bible_index.verse_id=?)"
    "     AND (SELECT sort_order FROM bible_index WHERE bible_index.verse_id=?)"
    " AND (SELECT bcode FROM bible_index WHERE bible_index.verse_id={v})"
    "    =(SELECT bcode FROM bible_index WHERE bible_index.verse_id=?)")


def covers_sql(alias='l', start='target_id', end='end_id'):
    """「이 절이 그 구간 안인가」 SQL 조각 → **물음표 3개**(vid, vid, vid).

    ★ 견주는 것은 `verse_id` 가 아니라 **`sort_order`** 다 — 빼면 43%가 샌다.
    """
    return _COVERS.format(a=alias, s=start, e=end)


def covers_args(vid):
    """`covers_sql` 에 넣을 인자 셋."""
    return [vid, vid, vid]


#: 그 구간이 **[lo, hi] 와 겹치는가** — 물음표 셋(hi, lo, lo)
#: ⚠ `covers` 는 **한 절**을 묻고 이것은 **구간 대 구간**이다. 둘을 섞으면
#:   조용히 다른 뜻이 된다(실측 `ref_compose`·`chain_detail_view` 가 겹침이었다).
_OVERLAPS = (
    "(SELECT sort_order FROM bible_index WHERE verse_id={a}.{s})"
    " <= (SELECT sort_order FROM bible_index WHERE verse_id=?)"
    " AND (SELECT sort_order FROM bible_index"
    "       WHERE verse_id=COALESCE(NULLIF({a}.{e},0),{a}.{s}))"
    " >= (SELECT sort_order FROM bible_index WHERE verse_id=?)"
    " AND (SELECT bcode FROM bible_index WHERE verse_id={a}.{s})"
    "    =(SELECT bcode FROM bible_index WHERE verse_id=?)")


def overlaps_sql(alias='l', start='target_id', end='end_id'):
    """「그 구간이 [lo, hi] 와 겹치는가」 → **물음표 3개**(hi, lo, lo)."""
    return _OVERLAPS.format(a=alias, s=start, e=end)


def overlaps_args(lo, hi=None):
    """`overlaps_sql` 인자 — **(hi, lo, lo)** 차례다."""
    hi = hi if hi is not None else lo
    return [hi, lo, lo]


def between_sql(vcol):
    """「그 구간의 절들」 SQL 조각 → 물음표 3개(시작, 끝, 시작).

    ⚠ `vcol` 은 **별칭으로 한정한 칸 이름**이어야 한다(`bi.verse_id`) —
      맨 이름을 주면 하위질의가 제 칸을 가리켜 가드가 조용히 죽는다.
    """
    if '.' not in vcol:
        raise ValueError('vcol 은 별칭으로 한정한다 (예: bi.verse_id) — 받은 것: %r'
                         % vcol)
    return BETWEEN_SQL.format(v=vcol)


def between_args(sv, ev=None):
    return [sv, ev if ev is not None else sv, sv]


def covers(conn, sv, ev, vid):
    """파이썬 판정 — 같은 책 안에서 차례상 `sv <= vid <= ev` 인가."""
    ev = ev if ev is not None else sv
    r = conn.execute(
        "SELECT (SELECT sort_order FROM bible_index WHERE verse_id=?),"
        "       (SELECT sort_order FROM bible_index WHERE verse_id=?),"
        "       (SELECT sort_order FROM bible_index WHERE verse_id=?),"
        "       (SELECT bcode FROM bible_index WHERE verse_id=?),"
        "       (SELECT bcode FROM bible_index WHERE verse_id=?)",
        (sv, ev, vid, sv, vid)).fetchone()
    if not r or r[0] is None or r[1] is None or r[2] is None:
        return False
    return r[0] <= r[2] <= r[1] and r[3] is not None and r[3] == r[4]


#: 범위를 가진 표 — `--audit` 이 훑는다. 표를 늘리면 여기 한 줄.
RANGE_TABLES = (
    ('sys_link_asset', 'target_id', 'end_id', "link_type LIKE '%_VERS'"),
    ('sys_book_unit', 'start_vid', 'end_vid', '1=1'),
    ('sys_pericope_asset', 'start_vid', 'end_vid', '1=1'),
    ('sys_plan_schedule', 'start_vid', 'end_vid', '1=1'),
    ('sys_commentary_entry', 'start_vid', 'end_vid', '1=1'),
    ('user_plan_schedule', 'start_vid', 'end_vid', '1=1'),
    ('user_link_asset', 'target_id', 'end_id', "link_type LIKE '%_VERS'"),
)


def health(conn):
    """`sort_order` 가 성한가 → `([문제…], 절 수)`. 비면 성하다.

    ★★★ **이것이 새 역본을 담을 때의 안전망이다** — 끼어든 절에 차례를 안
      주면 그 절은 어떤 구간에도 안 들어가고(누락) 조용하다. 오류도 안 난다.
    """
    bad = []
    n = conn.execute("SELECT COUNT(*) FROM bible_index").fetchone()[0]
    z = conn.execute("SELECT COUNT(*) FROM bible_index"
                     " WHERE sort_order IS NULL").fetchone()[0]
    if z:
        bad.append('차례(sort_order)가 빈 절 %d개' % z)
    d = conn.execute("SELECT COUNT(*) FROM (SELECT sort_order FROM bible_index"
                     " GROUP BY sort_order HAVING COUNT(*)>1)").fetchone()[0]
    if d:
        bad.append('차례가 겹치는 자리 %d곳' % d)
    o = conn.execute(
        "SELECT COUNT(*) FROM bible_index a JOIN bible_index b"
        "  ON b.bcode=a.bcode AND b.chapter=a.chapter AND b.verse=a.verse+1"
        " WHERE b.sort_order<=a.sort_order").fetchone()[0]
    if o:
        bad.append('뒤 절의 차례가 앞 절보다 빠른 자리 %d곳' % o)
    c = conn.execute(
        "SELECT COUNT(*) FROM bible_content"
        " WHERE verse_id NOT IN (SELECT verse_id FROM bible_index)").fetchone()[0]
    if c:
        bad.append('좌표 없는 본문 %d행 — 코어팩이 낡았다' % c)
    return bad, n


#: 「번호로 재는」 자리를 찾는 무늬 — `sweep()` 이 쓴다.
_NAIVE = (r'(start_vid\s*<=\s*\?|target_id\s*<=\s*\?'
          r'|verse_id\s+BETWEEN\s+\?|clicked_id\s*<=\s*\?)')


def sweep(roots=('user_main',)):
    """폐포를 훑어 **번호로 재는 조회**를 찾는다 → [(모듈, 줄, 글)].

    ★★★ **이것이 재발 방지 장치다**(2026-09-10). 화면을 늘릴 때 이 판정을
      다시 쓰면 그 화면에서만 43%가 샌다 — 그것을 사람이 기억으로 막을 수 없다.
      selftest 가 **0 이 아니면 실패**한다.
    ⚠ 자기 자신(`verse_range`)과 주석 줄은 뺀다.
    """
    import ast
    import os
    import re
    here = os.path.dirname(os.path.abspath(__file__))
    pat = re.compile(_NAIVE)

    def path_of(m):
        p = os.path.join(here, m.replace('.', os.sep) + '.py')
        return p if os.path.exists(p) else None

    def imports(path):
        try:
            tree = ast.parse(io.open(path, encoding='utf-8').read())
        except Exception:                                     # noqa: BLE001
            return []
        out = []
        for n in ast.walk(tree):
            if isinstance(n, ast.Import):
                out += [a.name for a in n.names]
            elif isinstance(n, ast.ImportFrom) and n.module and n.level == 0:
                out.append(n.module)
        return out

    seen, stack = set(), list(roots)
    # ⚠⚠ **관리자 패널은 문자열 + importlib 로 로드된다** — import 문만 따라가면
    #   48패널이 통째로 빠진다(§0-5 「정적 grep 만으로 판정하면 안 된다」).
    if 'admin_main' in stack:
        try:
            import admin_main as _am
            stack += [v[0] for v in _am.PANEL_REGISTRY.values()]
        except Exception:                                     # noqa: BLE001
            pass
    while stack:
        m = stack.pop()
        if m in seen:
            continue
        p = path_of(m)
        if not p:
            continue
        seen.add(m)
        stack += imports(p)
    hits = []
    for m in sorted(seen):
        if m == 'verse_range':
            continue
        for i, ln in enumerate(io.open(path_of(m), encoding='utf-8'), 1):
            if (pat.search(ln) and 'verse_range' not in ln
                    and not ln.strip().startswith('#')):
                hits.append((m, i, ln.strip()[:88]))
    return hits


def pair_check():
    """`*_sql()` 과 `*_args()` 가 **파일마다 짝이 맞는가** → [(파일, 문, sql, args)].

    ★★★ **인자 수를 손으로 세다 두 번 당했다**(2026-09-10) — 물음표를 늘리고
      인자를 그대로 두면 `Incorrect number of bindings` 가 나고 `except` 가
      삼켜 **그 목록이 통째로 빈다**(주석 탭 · 묵상노트). 오류도 안 난다.
    ⚠ 완전한 증명은 아니다(한 문에 두 번 쓸 수 있다) — 그래도 **빠뜨림**은 잡는다.
    """
    import os
    here = os.path.dirname(os.path.abspath(__file__))
    files = [f for f in os.listdir(here) if f.endswith('.py')]
    ad = os.path.join(here, 'admin')
    if os.path.isdir(ad):
        files += ['admin/' + f for f in os.listdir(ad) if f.endswith('.py')]
    bad = []
    for f in sorted(files):
        if f == os.path.basename(__file__):
            continue
        try:
            s = io.open(os.path.join(here, f), encoding='utf-8').read()
        except Exception:                                     # noqa: BLE001
            continue
        for a, b in (('covers_sql(', 'covers_args('),
                     ('between_sql(', 'between_args('),
                     ('overlaps_sql(', 'overlaps_args(')):
            n1, n2 = s.count('_vr.' + a), s.count('_vr.' + b)
            if n1 != n2:
                bad.append((f, a, n1, n2))
    return bad


def audit(conn):
    """**번호로 재면** 새는 구간 → [(표, rowid, 시작, 끝, 먹는 절 수)] + 유령 행.

    ⚠ **행이 잘못된 것이 아니다** — 아6:1~6:14 는 정당한 구간이다. 이 목록은
      「그 표를 `verse_id` 로 재는 조회가 남아 있으면 거기서 샌다」는 지도다.

    ★ 잣대가 `sort_order` 라 **같은 책 안에서 새는 것도 잡는다**(아6:1~6:14 가
      아7·8장을 먹던 216절 — 책 가드만으로는 못 봤다).
    """
    bad, ghost = [], []
    for t, a, b, w in RANGE_TABLES:
        tt = 'userdb.' + t if t.startswith('user_') else t
        try:
            for rid, sv, ev, n in conn.execute(
                    "SELECT x.rowid, x.{a}, COALESCE(x.{b},x.{a}),"
                    " (SELECT COUNT(*) FROM bible_index m"
                    "   WHERE m.verse_id BETWEEN x.{a} AND COALESCE(x.{b},x.{a})"
                    "     AND (m.bcode<>s.bcode"
                    "          OR m.sort_order<s.sort_order"
                    "          OR m.sort_order>e.sort_order))"
                    " FROM {t} x JOIN bible_index s ON s.verse_id=x.{a}"
                    "            JOIN bible_index e"
                    "              ON e.verse_id=COALESCE(x.{b},x.{a})"
                    " WHERE {w}".format(t=tt, a=a, b=b, w=w)):
                if n:
                    bad.append((t, rid, sv, ev, n))
            for rid, sv, ev in conn.execute(
                    "SELECT x.rowid, x.{a}, x.{b} FROM {t} x WHERE {w}"
                    "  AND (x.{a} NOT IN (SELECT verse_id FROM bible_index)"
                    "   OR (x.{b} IS NOT NULL AND x.{b} NOT IN"
                    "       (SELECT verse_id FROM bible_index)))"
                    .format(t=tt, a=a, b=b, w=w)):
                ghost.append((t, rid, sv, ev))
        except Exception:
            continue
    return bad, ghost


# ── selftest ────────────────────────────────────────────────────────────────

def _so(bc, ch, vs):
    return bc * 1000000 + ch * 1000 + vs * 10


def _mem():
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY, bcode INT,
                               chapter INT, verse INT, sort_order INT);
      CREATE TABLE bible_content(verse_id INT, version_code TEXT);
      CREATE TABLE lk(target_id INT, end_id INT);
    """)

    def ins(vid, bc, ch, vs):
        c.execute("INSERT INTO bible_index VALUES(?,?,?,?,?)",
                  (vid, bc, ch, vs, _so(bc, ch, vs)))

    # 아가(22) 6:1~6:13 = vid 100~112 · 6:14 = vid 900 (이형, 차례는 제자리)
    for i in range(13):
        ins(100 + i, 22, 6, i + 1)
    ins(900, 22, 6, 14)
    # ★ 같은 책 뒷장 — 번호로는 구간 「안」, 차례로는 「밖」
    ins(113, 22, 7, 1)
    ins(114, 22, 8, 1)
    # 계시록(66) 1:1~1:3 = vid 500~502 — 번호로는 아가 구간 「사이」
    for i in range(3):
        ins(500 + i, 66, 1, i + 1)
    c.execute("INSERT INTO lk VALUES(100,900)")     # 아6:1~6:14
    c.commit()
    return c


def selftest():
    ok = fail = 0

    def t(name, cond, got=None):
        nonlocal ok, fail
        if cond:
            ok += 1
            print('  OK   %s' % name)
        else:
            fail += 1
            print('  FAIL %s %r' % (name, got))

    c = _mem()
    sql = "SELECT COUNT(*) FROM lk l WHERE " + covers_sql()
    naive = ("SELECT COUNT(*) FROM lk l WHERE l.target_id<=?"
             " AND COALESCE(l.end_id,l.target_id)>=?")

    # ★ 탐지력 — 번호로 재면 딴 책도 같은 책 뒷장도 걸린다
    t('★ 번호로 재면 계1:1 이 아가 구간에 걸린다',
      c.execute(naive, (500, 500)).fetchone()[0] == 1)
    t('★ 번호로 재면 아7:1 도 걸린다 (책 가드가 못 막던 자리)',
      c.execute(naive, (113, 113)).fetchone()[0] == 1)

    t('차례로 재면 계1:1 은 안 걸린다',
      c.execute(sql, covers_args(500)).fetchone()[0] == 0)
    t('★★ 차례로 재면 아7:1 도 안 걸린다',
      c.execute(sql, covers_args(113)).fetchone()[0] == 0)
    t('★★ 아8:1 도 안 걸린다',
      c.execute(sql, covers_args(114)).fetchone()[0] == 0)
    t('아가 안의 절은 걸린다 (아6:5)',
      c.execute(sql, covers_args(104)).fetchone()[0] == 1)
    t('★ 이형 절(아6:14)도 걸린다',
      c.execute(sql, covers_args(900)).fetchone()[0] == 1)
    # ★★★ **끝 절 0 = 단일 절** (2026-09-15 — 묵상노트가 그렇게 적는다).
    #   0 을 값으로 보면 0번 절의 차례(NULL)와 견주어 **조용히 빠진다**.
    c.execute("INSERT INTO lk VALUES(104, 0)")
    t('★★★ 끝 절이 0 이면 시작 절 하나짜리다 — 그 절에 걸린다',
      c.execute(sql, covers_args(104)).fetchone()[0] == 2,
      c.execute(sql, covers_args(104)).fetchone()[0])
    t('  끝 절 0 — 옆 절에는 안 걸린다',
      c.execute(sql, covers_args(105)).fetchone()[0] == 1)
    t('  끝 절 0 — 겹침도 그 절 하나로 본다',
      c.execute("SELECT COUNT(*) FROM lk l WHERE " + overlaps_sql(),
                overlaps_args(104, 104)).fetchone()[0] == 2
      and c.execute("SELECT COUNT(*) FROM lk l WHERE " + overlaps_sql(),
                    overlaps_args(105, 107)).fetchone()[0] == 1)
    c.execute("DELETE FROM lk WHERE target_id=104 AND end_id=0")

    t('파이썬 판정 — 계1:1 은 아니다', not covers(c, 100, 900, 500))
    t('파이썬 판정 — 아7:1 도 아니다', not covers(c, 100, 900, 113))
    t('파이썬 판정 — 아6:5 는 맞다', covers(c, 100, 900, 104))
    t('파이썬 판정 — 이형 절도 맞다', covers(c, 100, 900, 900))

    # 「그 구간의 절들」 방향
    bsql = ("SELECT COUNT(*) FROM bible_index bi WHERE "
            + between_sql('bi.verse_id'))
    t('★ 구간의 절 나열 — 13절 + 이형 1절 = 14 (뒷장·딴 책 안 먹는다)',
      c.execute(bsql, between_args(100, 900)).fetchone()[0] == 14,
      c.execute(bsql, between_args(100, 900)).fetchone()[0])
    t('  번호로 세면 딴 책·뒷장까지 센다',
      c.execute("SELECT COUNT(*) FROM bible_index WHERE verse_id BETWEEN ? AND ?",
                (100, 900)).fetchone()[0] == 19,
      c.execute("SELECT COUNT(*) FROM bible_index WHERE verse_id BETWEEN ? AND ?",
                (100, 900)).fetchone()[0])
    # ⚠ 맨 칸 이름은 **거부한다** — 조용히 죽는 가드보다 터지는 것이 낫다
    try:
        between_sql('verse_id')
        _raised = False
    except ValueError:
        _raised = True
    t('★ 별칭 없는 칸 이름은 거부한다', _raised)

    # 겹침(구간 대 구간)
    osql = "SELECT COUNT(*) FROM lk l WHERE " + overlaps_sql()
    t('★ 겹침 — 아6:3~6:8 은 그 구간과 겹친다',
      c.execute(osql, overlaps_args(102, 107)).fetchone()[0] == 1)
    t('★★ 겹침 — 아7:1~8:1 은 안 겹친다(차례로 재야 안다)',
      c.execute(osql, overlaps_args(113, 114)).fetchone()[0] == 0)
    t('★ 겹침 — 계1:1~1:3 도 안 겹친다',
      c.execute(osql, overlaps_args(500, 502)).fetchone()[0] == 0)
    t('  겹침 인자는 (hi, lo, lo) 차례다', overlaps_args(1, 9) == [9, 1, 1])

    # 안전망 — 차례가 비면 알린다
    c.execute("UPDATE bible_index SET sort_order=NULL WHERE verse_id=113")
    hb, _n = health(c)
    t('★ 차례가 빈 절을 health 가 잡는다', any('빈 절' in x for x in hb), hb)
    c.execute("UPDATE bible_index SET sort_order=? WHERE verse_id=113",
              (_so(22, 7, 1),))
    c.execute("INSERT INTO bible_content VALUES(9999,'X')")
    hb, _n = health(c)
    t('★ 좌표 없는 본문을 health 가 잡는다',
      any('좌표 없는 본문' in x for x in hb), hb)
    c.execute("DELETE FROM bible_content")
    hb, _n = health(c)
    t('  고치면 성하다고 말한다', not hb, hb)

    # ★★★ **재발 방지 — 번호로 재는 자리가 남아 있으면 실패한다.**
    for _nm, _roots in (('사용자 앱', ('user_main',)),
                        ('관리자 앱', ('admin_main',))):
        try:
            _h = sweep(_roots)
        except Exception as _e:                               # noqa: BLE001
            _h = [('sweep 실패', 0, str(_e)[:60])]
        t('★★★ %s 폐포에 번호로 재는 조회 0' % _nm, not _h,
          _h[:3])

    _pc = pair_check()
    t('★★★ 조각과 인자의 짝이 맞는다(물음표 수 어긋남 0)', not _pc, _pc[:3])

    src = io.open(__file__, encoding='utf-8').read()
    t('물음표 셋을 쓴다(인자 헬퍼가 짝을 맞춘다)',
      len(covers_args(1)) == 3 and covers_sql().count('?') == 3)
    t('표 목록이 밖에 있다(늘리면 한 줄)', 'RANGE_TABLES' in src)
    t('★ 차례로 견준다(칸 이름이 소스에 있다)', 'sort_order' in src)

    # 실 DB — 오늘 잡은 그 자리
    try:
        import appdb
        rc = appdb.connect('bible_master.db')
        hb, n = health(rc)
        t('실 DB — 차례가 성하다 (%d절)' % n, not hb, hb)
        rev = rc.execute("SELECT verse_id FROM bible_index"
                         " WHERE bcode=66 AND chapter=1 AND verse=1").fetchone()[0]
        sos = rc.execute("SELECT verse_id FROM bible_index"
                         " WHERE bcode=22 AND chapter=7 AND verse=1").fetchone()[0]
        for nm, vid in (('계1:1', rev), ('아7:1', sos)):
            n_bad = rc.execute(
                "SELECT COUNT(*) FROM sys_link_asset l"
                " WHERE l.link_type='MEDI_VERS'"
                " AND l.target_id<=? AND COALESCE(l.end_id,l.target_id)>=?",
                (vid, vid)).fetchone()[0]
            n_ok = rc.execute(
                "SELECT COUNT(*) FROM sys_link_asset l"
                " WHERE l.link_type='MEDI_VERS' AND " + covers_sql(),
                [vid] * 3).fetchone()[0]
            t('실 DB — %s 오염 %d → %d' % (nm, n_bad, n_ok), n_ok < n_bad)
        bad, ghost = audit(rc)
        print('       (실 DB 새는 구간 %d행 · 없는 절 %d행)'
              % (len(bad), len(ghost)))
        rc.close()
    except Exception as e:
        t('실 DB (%s)' % e, False)

    print('verse_range selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main(argv):
    if '--selftest' in argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    c = appdb.connect('bible_master.db')
    hb, n = health(c)
    print('■ 차례(sort_order) 상태 — 절 %d' % n)
    for x in hb:
        print('   ⚠ %s' % x)
    if not hb:
        print('   성하다')
    bad, ghost = audit(c)
    print('■ 번호로 재면 새는 구간 %d행' % len(bad))
    print('   ⚠ **데이터는 정당하다** — 아6:1~6:14 · 요삼1:1~1:15 처럼 절체계')
    print('     이형을 끝으로 가진 구간이다. 새는 것은 조회이므로, 아래 행이')
    print('     있다는 것은 「그 표를 번호로 재는 화면이 있으면 거기서 샌다」는 뜻이다.')
    for t, rid, sv, ev, n in bad:
        print('   %-22s rowid %-8d vid %5d~%5d · 번호로 재면 딴 절 %d개를 먹는다'
              % (t, rid, sv, ev, n))
    print('■ 없는 절을 가리키는 구간 %d행' % len(ghost))
    for t, rid, sv, ev in ghost:
        print('   %-22s rowid %-8d vid %s~%s' % (t, rid, sv, ev))
    c.close()


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    main(sys.argv[1:])
