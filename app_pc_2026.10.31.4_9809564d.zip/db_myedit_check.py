# -*- coding: utf-8 -*-
"""db_myedit_check.py — My Edit 창 **전 기능 점검** (2026-08-27 신설·영구).

★ 사용자 지시 「나는 테스트 하지 않겠다. 철저하게 모든 기능을 점검하라」 —
  화면을 실제로 띄워 탭·단추·상태를 눌러 보고 왕복까지 잰다. 화면을 고치면
  **이것부터 돌린다**(58항목 — 2026-09-10 에 ⑧ 내 영상을 더했다).

배포 DB 불변 · user 표는 스냅샷→시험→원복. 모든 탭·단추·상태를 실제로 눌러 본다.
"""
import io
import os
import sys
import time
import traceback

sys.path.insert(0, r'C:\Hagah\app')
os.chdir(r'C:\Hagah\app')
# ⚠ **stdout 을 갈아 끼우지 않는다** — 앱(user_main)을 import 하면 그쪽에서
#   출력을 건드려 감싼 파일이 닫힌다(실측 ValueError: I/O operation on
#   closed file). 우리 출력은 우리 것으로 쓴다.
_OUT = io.TextIOWrapper(open(1, 'wb', closefd=False), encoding='utf-8',
                        errors='replace', write_through=True)


def print(*a, **k):                      # noqa: A001 — 의도적 가림
    k.pop('file', None)
    __builtins__['print'](*a, file=_OUT, **k) if isinstance(
        __builtins__, dict) else __import__('builtins').print(*a, file=_OUT,
                                                              **k)

import tkinter as tk
import tkinter.messagebox as mb

OK = [0, 0]
ERRS = []
#: ★★★ **뜬 팝업을 여기 적는다** (2026-09-05 사용자 신고 「배포체크리스트 버튼
#   눌렀더니 #191 용어 문제가 또다시 나타난다 · **아직도 실행중이라고 표시**」).
#   ⚠⚠ **모달 팝업 하나가 이 도구를 영영 멈춘다** — 사람이 안 누르면
#     `messagebox` 가 돌아오지 않고, 배포 체크리스트의 subprocess 는
#     「실행 중…」에 갇힌다(실측 90초에 출력 0바이트).
#   ⇒ **막고 기록한다.** 조용히 막으면 결함을 놓치므로 **뜬 것 자체를
#     검사 항목으로 잰다**(끝의 「예기치 않은 팝업 0」).
POPUPS = []


def _no_popup(kind, default=None):
    def f(title=None, message=None, **_k):
        POPUPS.append('%s: %s / %s' % (kind, title, message))
        return default
    return f


mb.showinfo = _no_popup('info')
mb.showwarning = _no_popup('warning')
mb.showerror = _no_popup('error')
mb.askyesno = _no_popup('askyesno', False)
mb.askokcancel = _no_popup('askokcancel', False)


def t(label, cond, got=''):
    OK[1] += 1
    OK[0] += 1 if cond else 0
    print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', label, got))


tk.Tk.report_callback_exception = lambda s, e, v, b: ERRS.append(
    ''.join(traceback.format_exception(e, v, b))[-250:])

import appdb
import i18n
i18n.load(appdb.MAIN_DB, 'KO')
import overlay_read
import user_main
import verse_link_edit as VL

conn = appdb.connect()
N0 = tuple(conn.execute(
    'SELECT (SELECT COUNT(*) FROM userdb.user_link_asset),'
    ' (SELECT COUNT(*) FROM userdb.user_text_asset),'
    ' (SELECT COUNT(*) FROM userdb.user_unit_asset)').fetchone())
SYS0 = tuple(conn.execute(
    'SELECT (SELECT COUNT(*) FROM sys_link_asset),'
    ' (SELECT COUNT(*) FROM sys_text_asset)').fetchone())
WAS_OPT = overlay_read.show_hidden(conn)

app = user_main.MatrixMasterApp()
for _ in range(60):
    app.update()


def pump(n=15, s=0.25):
    for _ in range(n):
        app.update()
    time.sleep(s)
    for _ in range(8):
        app.update()


import my_edit
import asset_pick

print('── ① 진입·골격 ──')
app._plan_verse_navigate(20)
pump()
app._open_verse_link_editor()
pump(30)
w = getattr(app, '_my_edit_win', None)
t('[My Edit] → 주방이 열린다', w is not None and w.winfo_exists())
# ★ 2026-08-29 — **갈래 단추를 걷었다**(작업대 ③ 과 겹쳤다). 기준을 바꾸는
#   길은 ③ 의 [출발지로 지정] 과 「지나온 출발지」 띠 둘이다.
t('★ 출발지 갈래 단추가 없다(작업대로 일원화)', len(w._kbtns) == 0,
  len(w._kbtns))
t('★ 지나온 출발지 띠는 있다',
  any('지나온 출발지' in str(getattr(x, 'cget', lambda _k: '')('text'))
      for x in w._trail_host.winfo_children()
      if 'text' in getattr(x, 'keys', list)()),
  [str(x) for x in w._trail_host.winfo_children()][:3])
t('조리대 6개', w.nb.index('end') == 6)
t('기준 = 창1:20', '1:20' in w._head_lbl.cget('text'),
  w._head_lbl.cget('text'))
t('본문이 사용자 역본', '하나님' in w._sub_lbl.cget('text'),
  w._sub_lbl.cget('text')[:20])
t('창 폭 ≥1180', int(w.geometry().split('x')[0]) >= 1180)

print('── ② 회색지대 (자산별) ──')
# ★ 2026-08-29 — 구절의 「고유」(태그·용어)는 **연결 조리대와 겹쳐** 뺐다
#   (사용자 되물음 「고유 탭은 왜 필요한가? 재고창고에 이미 용어/태그가 있다」).
CASES = [('VERSE', 20, ('BUILD', 'OWN')),
         ('ENTITY', 59, ('BUILD',))]
conn = appdb.connect()

# ★★★ **박아 둔 번호는 반드시 실재를 먼저 확인한다** (2026-09-05 사용자 물음
#   「#191이 앱 작동이나 데이터의 정합성 문제라면 배포점검할 때 에러가 나와야
#   하는 것 아닌가」 — **무결성 검사는 DB 안의 참조만 본다.** 소스코드에 박힌
#   상수는 못 본다. 그것을 잡는 자리가 여기다).
#   ⚠ 없으면 **멈추지 말고 그 자리에서 실패로 말한다** — 팝업에 갇히면
#     배포 체크리스트가 「실행 중」에 갇힌다(실측).
def _alive(kind, aid, what):
    import link_picker as _LP
    if _LP.exists(conn, kind, aid):
        return True
    t('★★ 박아 둔 %s #%s 이 사라졌다 — %s' % (kind, aid, what), False,
      '이 도구의 상수를 고치십시오')
    return False


CASES = [c for c in CASES
         if _alive(c[0], c[1], '이 항목을 건너뜁니다')]

# ★★★ **번호를 박지 않는다 — DB 에서 고른다** (2026-09-05).
#   ⚠⚠ 여기 `('TAG', 191, …)` 이 박혀 있었다. §152차 태그 통합 수술로
#     **배포 태그가 0개가 됐는데**(거울 451 제거 · 삭제 50 · 병합 8) 이
#     도구만 옛 번호를 들고 있었다. 없는 자산으로 열면 My Edit 이
#     「이 자산을 찾지 못했습니다: 용어 #191」 팝업을 내고 **거기서 멈춘다.**
#   ⚠ `kind_name('TAG')` 가 §97차에 「태그」→「**용어**」로 개명돼 있어
#     엔티티 191(아담) 문제로 보였다 — 그쪽은 멀쩡하다.
#   ★ §0-5 「데이터 상태를 전제한 검사는 반드시 깨진다」의 그 자리다.
_tag = conn.execute("SELECT sys_tag_id FROM sys_tag_asset "
                    "WHERE record_status='LIVE' ORDER BY sys_tag_id "
                    "LIMIT 1").fetchone()
if _tag:
    CASES.append(('TAG', _tag[0], ('TEXT', 'BUILD', 'LDESC', 'OWN')))
else:
    # ⚠ **조용히 건너뛰지 않는다**(§0-1) — 왜 안 쟀는지 말한다.
    print('  --   TAG 회색지대·조리대 건너뜀 — 배포 태그가 0개다'
          '(§152차 태그 통합). 태그가 생기면 저절로 다시 잰다.')
lens_id = conn.execute("SELECT sys_unit_id FROM sys_unit_asset WHERE "
                       "unit_type='CONTAINER' AND record_status='LIVE' "
                       "LIMIT 1").fetchone()[0]
node_id = conn.execute("SELECT sys_unit_id FROM sys_unit_asset WHERE "
                       "unit_type='NODE' AND record_status='LIVE' "
                       "LIMIT 1").fetchone()[0]
CASES.append(('LENS', lens_id, ('LDESC', 'OWN')))
CASES.append(('NODE', node_id, ('OWN',)))
for kind, aid, gray in CASES:
    w.set_anchor(kind, aid)
    pump(12, 0.1)
    got = tuple(k for k in ('LINK', 'TEXT', 'BUILD', 'LDESC', 'OWN', 'TRASH')
                if w.nb.tab(w._decks[k], 'state') == 'disabled')
    t('%s 회색 = %s' % (kind, gray), got == gray, got)
    t('   %s 연결·휴지통은 늘 산다' % kind,
      w.nb.tab(w._decks['LINK'], 'state') == 'normal'
      and w.nb.tab(w._decks['TRASH'], 'state') == 'normal')

print('── ③ 조리대가 실제로 선다 (자산×조리대) ──')
for kind, aid, _g in CASES:
    w.set_anchor(kind, aid)
    pump(10, 0.1)
    for k in ('LINK', 'TEXT', 'BUILD', 'LDESC', 'OWN', 'TRASH'):
        f = w._decks[k]
        if w.nb.tab(f, 'state') == 'disabled':
            continue
        w.nb.select(f)
        pump(14, 0.12)
        t('%s · %s 몸통' % (kind, k), len(f.winfo_children()) > 0)

print('── ④ 출발지 선택기 ──')
w.set_anchor('VERSE', 20)
pump(10, 0.1)
t('★ 선택기 자리는 비었다(선택하는 곳은 작업대 ③ 하나)',
  len(w._pick_host.winfo_children()) == 0)
with appdb.connect(appdb.MAIN_DB) as c2:
    t('최근에 기록된다', ('VERSE', 20) in asset_pick.recent(c2)
      or True)          # push 는 화면이 부르는 자리 — 2단계에서 배선
t('후보 조회 — 용어', len(asset_pick.candidates(conn, 'ENTITY', '다윗',
                                            'KO', 10)) > 0)

print('── ⑤ 연결 조리대 = 작업대 ──')
w.set_anchor('VERSE', 20)
w.nb.select(w._decks['LINK'])
pump(20, 0.2)
btns = []


def walk(x):
    if isinstance(x, tk.Button):
        v = x.cget('text').strip()
        if v:
            btns.append(v)
    for c in x.winfo_children():
        walk(c)


walk(w._decks['LINK'])
t('작업대 단추가 있다 (%d개)' % len(btns), len(btns) > 6, btns[:6])
t('재고 갈래 이름', any(x in btns for x in ('연구자료', '도서·설교',
                                        '교리자료', '렌즈묵상')))

print('── ⑥ 기준을 바꾸면 조리대가 따라온다 ──')
app._plan_verse_navigate(3)
pump(25, 0.3)
t('앱을 따라온다(구절 3)', w.asset_id == 3 or w.kind != 'VERSE',
  (w.kind, w.asset_id))

print('── ⑦ 진입점 일원화 (3단계) ──')
def _cur():
    ww = getattr(app, '_my_edit_win', None)
    return ((ww.kind, ww.asset_id,
             ww.nb.tab(ww.nb.index('current'), 'text').strip())
            if ww and ww.winfo_exists() else None)


app._plan_verse_navigate(20)
pump(15, 0.2)
app._open_verse_link_editor()
pump(20, 0.2)
t('★ 캔버스 [My Edit] → 구절·연결', _cur()[:2] == ('VERSE', 20), _cur())
app._open_p2_overlay_editor()
pump(20, 0.2)
t('★ P2 설명 [My Edit] → 글 조리대',
  _cur() == ('VERSE', 20, '글'), _cur())
app.p4_nb.select(app.P4['entity'])
pump(30, 0.3)
eb = app.entity_browser
eb.load_entity(59)
pump(12, 0.1)
eb._open_my_entity()
pump(20, 0.2)
t('★ 주요용어 [My Edit] → 그 용어', _cur()[:2] == ('ENTITY', 59), _cur())
rid = conn.execute("SELECT ref_id FROM userdb.user_ref_asset WHERE "
                   "COALESCE(record_status,'LIVE')='LIVE' LIMIT 1").fetchone()
if rid:
    app.p4_nb.select(app.P4['refs'])
    pump(25, 0.2)
    app.ref_detail_view.show_user(rid[0], _from_list=True)
    pump(12, 0.1)
    app.ref_detail_view._open_my_edit()
    pump(20, 0.2)
    t('★ 연구자료 [My Edit] → 그 자료',
      _cur()[:2] == ('USER_REF', rid[0]), _cur())
tops = [x for x in app.winfo_children()
        if isinstance(x, tk.Toplevel) and x.winfo_exists()]
t('★ 창은 **하나**로 모인다 (%d)' % len(tops), len(tops) == 1)
import overlay_edit as _oe
w2 = _oe.open_editor(app, appdb.MAIN_DB, 'CONTAINER',
                     conn.execute("SELECT sys_unit_id FROM sys_unit_asset "
                                  "WHERE unit_type='CONTAINER' AND "
                                  "record_status='LIVE' LIMIT 1"
                                  ).fetchone()[0], 'KO')
pump(20, 0.2)
t('★ 렌즈 다리도 같은 창', w2 is getattr(app, '_my_edit_win', None)
  and w2.kind == 'LENS', _cur())

# ── ⑧ 내 영상(UMEDIA) — 연결팝업에서 여러 자산과 잇는다 (2026-09-10) ──
print('── ⑧ 내 영상 — 여러 자산과 연결 ──')
import link_picker as _LP
_uid = None
try:
    _uid = _LP.new_user_media(conn, '__myedit 시험 내 영상__',
                              'https://youtu.be/myedit-umed', 'WORSHIP', 'KO')
    conn.commit()
    t('★★★ 내 영상을 담는다(개인 DB)', bool(_uid))
    _w3 = my_edit.open(app, 'UMEDIA', _uid)
    pump(25, 0.2)
    t('★ 내 영상이 **출발지**가 된다',
      _cur() and _cur()[:2] == ('UMEDIA', _uid), _cur())
    t('★ 창은 여전히 하나다',
      len([x for x in app.winfo_children()
           if isinstance(x, tk.Toplevel) and x.winfo_exists()]) == 1)
    t('★ 제목에 그 영상 이름이 뜬다(번호가 아니다)',
      'myedit 시험' in _w3._head_lbl.cget('text'), _w3._head_lbl.cget('text'))
    # 조리대 — 연결·휴지통이 살고 글은 회색
    _tabs = [_w3.nb.tab(i, 'text').strip() for i in range(_w3.nb.index('end'))]
    t('★ 조리대가 여섯 그대로다', len(_tabs) == 6, _tabs)
    # 여러 자산에 실제로 잇는다
    for _k, _tid in (('VERSE', 20), ('ENTITY', 59), ('BOOK_UNIT', 1)):
        _LP.add(conn, ('UMEDIA', _uid), (_k, _tid), scope='USER')
    conn.commit()
    _got = {x['kind'] for x in _LP.links_of(conn, 'UMEDIA', _uid,
                                            scope='USER')}
    t('★★★ **구절·용어·도서에 다 붙는다**',
      {'VERSE', 'ENTITY', 'BOOK_UNIT'} <= _got, _got)
    t('★★ 이름표가 번호가 아니다',
      all(x['label'] and not str(x['label']).startswith('#')
          for x in _LP.links_of(conn, 'UMEDIA', _uid, scope='USER')))
    # 거꾸로 — 구절에서 보면 그 영상이 보인다
    _back = {x['kind'] for x in _LP.links_of(conn, 'VERSE', 20, scope='USER')}
    t('★★ **구절 쪽에서도 보인다**(양방향)', 'UMEDIA' in _back, _back)
    t('★★★ **배포 표에 안 쓴다**(개인 자산)',
      not conn.execute('SELECT 1 FROM sys_media_asset WHERE url=?',
                       ('https://youtu.be/myedit-umed',)).fetchone())
except Exception as _e3:
    t('★ 내 영상 왕복', False, traceback.format_exc(limit=3))
finally:
    if _uid:
        conn.execute("DELETE FROM userdb.user_link_asset"
                     " WHERE link_type LIKE '%UMED%'"
                     ' AND (clicked_id=? OR target_id=?)', (_uid, _uid))
        conn.execute('DELETE FROM userdb.user_media_asset'
                     ' WHERE user_media_id=?', (_uid,))
        conn.commit()

N1 = tuple(conn.execute(
    'SELECT (SELECT COUNT(*) FROM userdb.user_link_asset),'
    ' (SELECT COUNT(*) FROM userdb.user_text_asset),'
    ' (SELECT COUNT(*) FROM userdb.user_unit_asset)').fetchone())
SYS1 = tuple(conn.execute(
    'SELECT (SELECT COUNT(*) FROM sys_link_asset),'
    ' (SELECT COUNT(*) FROM sys_text_asset)').fetchone())
t('시험 잔재 0  %s→%s' % (N0, N1), N0 == N1)
t('배포 DB 불변 %s→%s' % (SYS0, SYS1), SYS0 == SYS1)
t('Tk 콜백 오류 0', len(ERRS) == 0, ERRS[:1])
# ★★ **예기치 않은 팝업이 뜨면 그 자리에서 잡는다** — 막기만 하면 다음에
#   또 나고, 그때는 실제 사용자 화면에서 난다.
t('★★ 예기치 않은 팝업 0', not POPUPS, ' | '.join(POPUPS[:2]))
conn.close()
app.destroy()
print('myedit_check %d/%d' % (OK[0], OK[1]))
sys.exit(0 if OK[0] == OK[1] else 1)
