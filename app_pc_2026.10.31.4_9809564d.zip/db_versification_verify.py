# -*- coding: utf-8 -*-
"""
db_versification_verify.py  (영구 도구)

목적: 성경 버전이 우리 영어축(bible_index)에 절 단위로 정렬돼 있는지 검증한다.
      일부 버전(프랑스 Darby=FreJND, 스페인 Reina-Valera=SpaRV)은 히브리 절체계라
      naive 임포트 시 장경계에서 밀려 저장된다(같은 약명에 다른 내용 → 설명문 오정렬).
      **새 버전을 추가할 때마다 반드시 이 도구로 검증**한다(CLAUDE.md §18-8 필수 절차).

두 검사:
  ① 내부 검사(소스 불필요, 모든 버전): 각 OT 장에서 대상 버전의 절 길이를 KJV와 비교 —
     offset 0(정렬) vs ±1(밀림) 상관 + 꼬리 밀림(장 후반부만 밀린 느7 유형) + 공백 슬롯.
  ② 근본원인 교차검사(getbible 소스 있을 때, 권장): 그 버전의 '원본 절체계'를 영어와 대조해
     절체계가 다른 후보 장을 색출 → 그 장들에서 우리 DB 정렬 여부를 정밀 확인.

사용법:
  python -X utf8 db_versification_verify.py --all                 # 전 버전(대응본 자동=근본원인 교차검사)
  python -X utf8 db_versification_verify.py --version <CODE>      # 한 버전
  python -X utf8 db_versification_verify.py --version <CODE> --source <getbible_code>   # 소스 지정
  python -X utf8 db_versification_verify.py --version <CODE> --no-fetch                 # 내부검사만
  (GB_MAP 에 매핑된 버전은 getbible 대응본 자동 다운로드·캐시=.versif_cache/. 신규 버전은
   여기 한 줄 추가하거나 --source 로 지정. 대응본 없으면 내부검사 fallback[시가서 오탐 가능].)

판정: 미정렬 장이 나오면 그 버전은 재정렬 필요(temp_db_versif_fix 방식: 구역한정 평탄화+제한DP).
      시가서(시편 표제·잠언)·CJK는 길이 노이즈로 오탐 가능 → 반드시 해당 절 내용을 눈으로 확인.
"""
import sqlite3, sys, os, json, urllib.request, ssl

DB='bible_master.db'
CACHE='.versif_cache'
# 우리 버전 → getbible v2 code (근본원인 교차검사용, 알려진 것만)
GB_MAP={'FreJND':'darby','FreLSG':'ls1910','SpaRV':'valera','KRV':'korean','CUV':'cut','CUVS':'cus',
        'ARB':'arabicsv','GerElb':'elberfelder','PorBL':'livre','KJV':'kjv','ASV':'asv','WEB':'web','BSB':'kjv',
        # ★ RusSyn 은 오래 **교차검사 소스가 없는 유일한 내용 역본**이었다 —
        #   그래서 시편이 통째로 어긋난 채 늘 내부검사만 지나갔다(267차).
        'RusSyn':'synodal'}

def corr(a,b):
    n=len(a)
    if n<4: return None
    ma=sum(a)/n; mb=sum(b)/n
    num=sum((a[i]-ma)*(b[i]-mb) for i in range(n))
    da=sum((x-ma)**2 for x in a)**.5; db=sum((x-mb)**2 for x in b)**.5
    return num/(da*db) if da and db else None

def chap_lens(c, bcode, ch, ver):
    vids=[r[0] for r in c.execute("SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? ORDER BY verse",(bcode,ch))]
    out=[]
    for vid in vids:
        t=c.execute("SELECT verse_text FROM bible_content WHERE verse_id=? AND version_code=?",(vid,ver)).fetchone()
        out.append(len(t[0]) if t and t[0] else 0)
    return out

def fetch_gb(code):
    os.makedirs(CACHE, exist_ok=True)
    path=os.path.join(CACHE, f'{code}.json')
    if not os.path.exists(path):
        ctx=ssl.create_default_context(); ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
        url=f'https://api.getbible.net/v2/{code}.json'
        req=urllib.request.Request(url, headers={'User-Agent':'Mozilla/5.0'})
        open(path,'wb').write(urllib.request.urlopen(req, context=ctx, timeout=180).read())
    d=json.load(open(path,encoding='utf-8'))
    return {b['nr']:b for b in d['books']}

def hole_flag(vl):
    """**빈 슬롯이 많다** — 옛 검사가 여기서 판정을 포기하고 「정상」이라 했다.

    ⚠⚠ 이것이 RusSyn 시편을 십 년 지나가게 한 구멍이다. 절반이 비었다는 것은
      「잴 수 없다」이지 「성하다」가 아니다. **모르면 모른다고 말한다**(§0-1).
    ⚠ 통째로 빈 장은 여기서 안 본다 — 그것은 「안 담았다」이고 다른 검사의 몫.
    """
    n = len(vl)
    if n < 6:
        return None
    got = sum(1 for x in vl if x > 0)
    if got == 0 or got >= n * 0.9:
        return None
    return ('hole', f'{got}/{n}')


def chap_shift_flag(c, bcode, ch, ver, kjv_of):
    """**편(장)이 통째로 밀렸는가** — 옛 검사는 절 밀림만 보았다.

    ⚠⚠ 시노드역 시편처럼 **장 번호 자체가 다른 체계**면 같은 장끼리 견주는
      검사로는 영영 안 걸린다. 앞뒤 장까지 견주고, 장이 밀리면 **절도 함께**
      밀리므로(표제가 1절) 두 축을 같이 잰다.
    """
    vl = chap_lens(c, bcode, ch, ver)
    if len(vl) < 6 or sum(1 for x in vl if x > 0) < len(vl) * 0.5:
        return None
    here = best = None
    bd = None
    for dch in (0, 1, -1):
        kl = kjv_of(bcode, ch + dch)
        if not kl:
            continue
        for dv in (0, -1, -2, 1):
            a = vl[max(0, -dv):]
            b = kl[max(0, dv):]
            m = min(len(a), len(b))
            if m < 10:          # ⚠ 겁줄 점이 여섯·일곱이면 우연히 0.85 가 나온다
                continue        #   (실측 오탐은 전부 m≤7 · 진짜 밀림은 m=14)
            r = corr(a[:m], b[:m])
            if r is None:
                continue
            if dch == 0 and dv == 0:
                here = r
            if best is None or r > best:
                best, bd = r, (dch, dv)
    if best is None or bd == (0, 0) or best < 0.85:
        return None
    if here is not None and here >= 0.5:
        return None                      # 제자리 상관이 이미 충분하다
    return ('chap%+d:v%+d' % bd, round(best, 2))


def shift_flag(vl, kl, tail=False):
    """정렬(offset0) 낮고 밀림(±1) 높으면 밀림 후보.
    표제합침 오탐 제거: v1이 이상하게 길면(표제+본문) v1 빼고 재계산해 정렬이면 통과."""
    if len(vl)<6 or sum(1 for x in vl if x>0)<len(vl)*0.9: return None
    c0=corr(vl,kl)
    c0b=corr(vl[1:],kl[1:]) if len(vl)>6 else c0     # v1 제외(표제합침 보정)
    cp=corr(vl[1:],kl[:-1]); cm=corr(vl[:-1],kl[1:])
    best=max([x for x in (cp,cm) if x is not None]+[-1])
    # 정렬 판정: 전체 or v1제외 상관이 충분히 높으면 OK
    if (c0 is not None and c0>=0.5) or (c0b is not None and c0b>=0.6): return None
    if c0 is not None and best>c0+0.25 and best>0.6:
        return ('full', round(c0,2))
    # 꼬리 밀림(내부검사 fallback 전용, 강한 신호만): 후반부만 밀림
    if tail:
        n=len(vl); s=n-max(6,n//2)
        if n-s>=6:
            t0=corr(vl[s:],kl[s:]); tp=corr(vl[s+1:],kl[s:-1])
            if t0 is not None and tp is not None and t0<0.25 and tp>0.7:
                return ('tail', round(t0,2))
    return None

def main():
    args=sys.argv[1:]
    src=None
    if '--source' in args: src=args[args.index('--source')+1]
    vers=[]
    if '--all' in args:
        conn0=sqlite3.connect(DB)
        vers=[r[0] for r in conn0.execute("SELECT version_code FROM bible_version WHERE versification_system='MT'")]
        vers=[v for v in vers if conn0.execute("SELECT COUNT(*) FROM bible_content WHERE version_code=? AND TRIM(verse_text)!=''",(v,)).fetchone()[0]>0]
        conn0.close()
    elif '--version' in args:
        vers=[args[args.index('--version')+1]]
    else:
        print(__doc__); return
    conn=sqlite3.connect(DB); c=conn.cursor()
    names={r[0]:r[1] for r in c.execute("SELECT book_code, short_name FROM book_names WHERE lang_code='EN'")}
    _kc={}
    def _kjv(b, ch):
        """KJV 그 장의 절 길이(캐시) — 없는 장이면 빈 목록."""
        k=(b,ch)
        if k not in _kc: _kc[k]=chap_lens(c,b,ch,'KJV')
        return _kc[k]
    no_fetch = '--no-fetch' in args
    for ver in vers:
        GB=None
        code = src or GB_MAP.get(ver)
        if code and not no_fetch:   # 근본원인 교차검사 우선(캐시라 재실행 빠름). --no-fetch 로 내부검사만.
            try: GB=fetch_gb(code)
            except Exception as e: print(f"[{ver}] 소스 로드 실패({code}) → 내부검사로: {e}"); GB=None
        flags=[]
        for bcode in range(1,67):
            for ch in [r[0] for r in c.execute("SELECT DISTINCT chapter FROM bible_index WHERE bcode=? ORDER BY chapter",(bcode,))]:
                E=c.execute("SELECT COUNT(*) FROM bible_index WHERE bcode=? AND chapter=?",(bcode,ch)).fetchone()[0]
                # 근본원인: 소스 절체계가 영어와 다른 후보만 정밀 검사(있을 때)
                if GB is not None:
                    G=next((len(x['verses']) for x in GB.get(bcode,{}).get('chapters',[]) if x['chapter']==ch),None)
                    cand = (G is not None and G!=E)
                else:
                    cand=True   # 내부검사: 전 장
                if not cand: continue
                vl=chap_lens(c,bcode,ch,ver); kl=chap_lens(c,bcode,ch,'KJV')
                f=shift_flag(vl,kl, tail=(GB is None))
                if not f: f=chap_shift_flag(c,bcode,ch,ver,_kjv)   # 편 밀림
                if not f: f=hole_flag(vl)                          # 빈 슬롯
                if f: flags.append(f"{names[bcode]}{ch}[{f[0]} c0={f[1]}]")
        mode = f"근본원인(getbible '{code}')" if GB is not None else "내부검사"
        if flags:
            print(f"[{ver}] {mode}: ⚠ 미정렬 후보 {len(flags)} — {flags[:20]}")
            print(f"        → 해당 절 내용을 KJV와 눈으로 대조. 진짜 밀림이면 재정렬(temp_db_versif_fix 방식). (시가서·CJK는 오탐 가능)")
        elif GB is None:
            # ⚠ 교차검사 없이는 **판정력이 낮다** — ✅ 라 적지 않는다.
            #   왜 약한지를 정확히 말한다(끄고 돌렸는지 · 코드가 없는지).
            why = ('--no-fetch 로 교차검사를 꺼 둔 것' if (code and no_fetch)
                   else 'GB_MAP 에 getbible 코드가 없다')
            print(f"[{ver}] {mode}: 후보 0 — ⚠ {why}. 근본원인 검사가 "
                  f"아니므로 「성하다」가 아니라 「그것으로는 못 잡았다」이다.")
        else:
            print(f"[{ver}] {mode}: ✅ 정렬 OK (미정렬 후보 0)")
    conn.close()

def selftest():
    """**탐지력**을 잰다 — 심어 보고 잡히는가, 멀쩡한 것을 안 잡는가."""
    ok=[0]; bad=[]
    def chk(name, cond, extra=''):
        if cond: ok[0]+=1; print('  OK   ', name)
        else: bad.append(name); print('  FAIL ', name, extra)

    base=[120,80,200,60,150,90,175,55,210,70]
    chk('빈 슬롯 — 절반만 차 있으면 잡는다',
        hole_flag(base[:5]+[0]*15) is not None)
    chk('빈 슬롯 — 다 차 있으면 안 잡는다', hole_flag(base) is None)
    chk('빈 슬롯 — 통째로 비면 안 잡는다(다른 검사의 몫)',
        hole_flag([0]*20) is None)
    chk('빈 슬롯 — 짧은 장은 안 잡는다', hole_flag([10,0,0]) is None)

    # 편 밀림 — 가짜 DB 로 잰다
    # ⚠ 상관은 **평행이동·배율에 불변**이다 — `base+3` 은 base 와
    #   상관 1.0 이라 시험이 헛돌았다(실측으로 잡았다). **무늬이 다른** 장을 쓴다.
    K={(19,1):base,(19,2):[40,190,65,210,88,55,230,120,70,160],
       (19,3):[300,20,140,95,60,180,45,210,33,120]}
    V={(19,1):list(K[(19,2)])}      # 1편 슬롯에 2편 내용
    W={(19,1):list(K[(19,1)])}      # 제자리
    class _C:
        def __init__(s,m): s.m=m
        def execute(s,q,a=None): raise AssertionError('안 쓴다')
    import db_versification_verify as M
    _old=M.chap_lens
    try:
        M.chap_lens=lambda c,b,ch,v: (V if v=='X' else W).get((b,ch),[]) \
            if v in ('X','Y') else K.get((b,ch),[])
        f=M.chap_shift_flag(None,19,1,'X',lambda b,ch: K.get((b,ch),[]))
        chk('편 밀림 — 옆 편 내용이 들어 있으면 잡는다', f is not None, f)
        g=M.chap_shift_flag(None,19,1,'Y',lambda b,ch: K.get((b,ch),[]))
        chk('편 밀림 — 제자리면 안 잡는다', g is None, g)
    finally:
        M.chap_lens=_old

    chk('교차검사 소스 — RusSyn 이 등록돼 있다', GB_MAP.get('RusSyn')=='synodal')
    print('db_versification_verify selftest %d/%d' % (ok[0], ok[0]+len(bad)))
    return not bad


if __name__=='__main__':
    if '--selftest' in sys.argv[1:]:
        sys.exit(0 if selftest() else 1)
    main()
