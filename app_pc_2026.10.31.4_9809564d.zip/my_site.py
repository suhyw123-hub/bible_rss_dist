# -*- coding: utf-8 -*-
"""내가 모은 사이트 — 글 RSS (2026-10-24 · 폰 my_site_repo.dart 와 같은 규칙 · 「내가 모은 채널」의 글 판).

사용자가 밖에서 담은 글(웹 주소)의 **사이트**를 수집 대상으로 삼고, 그 사이트의 새 글 목록(RSS/Atom)을 하루 한 번 받는다.
· 사이트 목록 `userdb.user_my_site` — PC 가 정본 · 폰으로 사본(mobile_sync MIRROR) · 폰에서 담으면 MY_SITE 사건.
· 받은 글 `userdb.user_my_site_item` — **이 PC 에만**(제목·주소·날짜만 · 본문은 안 담는다 — 최신 콘텐츠와 같은 선).
· 앱(관리자)이 이미 받는 피드(`user_rss_registry`)와 겹치면 받지 않고 「앱이 받고 있습니다」.
· 피드를 못 찾으면 까닭을 말하고 관리자 추천(소통 통로 kind SITE)을 권한다.
⚠ 이상한 자료 막기 — 주소는 http(s) 만 · 제목은 글자로만(태그 걷음) · 실패해도 지난 목록 유지 · 하루 한 번.

`python my_site.py --selftest` — 의무(망 없이 가짜 get 으로 잰다).
"""
import html as _html
import re
from datetime import datetime, timedelta
from urllib.parse import urljoin, urlsplit
from urllib.request import Request, urlopen

DDL = (
    "CREATE TABLE IF NOT EXISTS userdb.user_my_site (feed_url TEXT PRIMARY KEY, site_name TEXT,"
    " page_url TEXT, feed_kind TEXT DEFAULT 'NEWS', created_at TEXT DEFAULT (datetime('now','localtime')))",
    "CREATE TABLE IF NOT EXISTS userdb.user_my_site_item (url TEXT PRIMARY KEY, feed_url TEXT,"
    " site TEXT, title TEXT, published TEXT, fetched_at TEXT)",
    "CREATE TABLE IF NOT EXISTS userdb.user_my_site_ok (feed_url TEXT PRIMARY KEY, ok_at TEXT, fail_at TEXT)",
)
DUE_HOURS = 24
KINDS = ('NEWS', 'DEVOTIONAL')
GAP = (2.0, 6.0)
HEADERS = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
                         'Chrome/130.0.0.0 Safari/537.36',
           'Accept-Language': 'ko-KR,ko;q=0.9,en;q=0.8',
           'Accept': 'application/rss+xml,application/atom+xml,application/xml;q=0.9,text/html;q=0.8,*/*;q=0.7'}
#: 흔한 피드 자리 — 쪽에 피드 표시(link rel=alternate)가 없을 때만 차례로 본다
GUESS = ('/feed', '/rss', '/feed.xml', '/rss.xml', '/atom.xml', '/index.xml', '/feed/')


def _get(url):
    try:
        with urlopen(Request(url, headers=HEADERS), timeout=15) as r:
            if r.status != 200:
                return None
            return r.read(2_000_000).decode('utf-8', 'ignore')
    except Exception:
        return None


def ensure(conn):
    for s in DDL:
        conn.execute(s)


def ok_url(u):
    return bool(re.match(r'^https?://[^\s/]+\.[^\s]+$', u or ''))


def norm(u):
    """견주기용 — 스킴·www·끝 / 를 뗀다(같은 피드를 다르게 적어도 같게 본다)."""
    s = urlsplit((u or '').strip())
    host = (s.netloc or '').lower()
    if host.startswith('www.'):
        host = host[4:]
    return host + (s.path or '').rstrip('/') + (('?' + s.query) if s.query else '')


def _txt(s):
    s = re.sub(r'<!\[CDATA\[(.*?)\]\]>', r'\1', s or '', flags=re.S)
    s = re.sub(r'<[^>]+>', ' ', s)
    return ' '.join(_html.unescape(s).split())[:300]


def is_feed(text):
    head = (text or '')[:2000].lower()
    return '<rss' in head or '<feed' in head or '<rdf:rdf' in head


def parse_feed(xml, base=''):
    """RSS·Atom → [{title, url, published}] · 사이트 이름. 주소는 http(s) 만 · 제목은 글자로만."""
    out = []
    t = re.search(r'<channel[^>]*>.*?<title[^>]*>(.*?)</title>', xml or '', re.S) or \
        re.search(r'<feed[^>]*>.*?<title[^>]*>(.*?)</title>', xml or '', re.S)
    name = _txt(t.group(1)) if t else ''
    for blk in re.findall(r'<item[\s>].*?</item>|<entry[\s>].*?</entry>', xml or '', re.S):
        tm = re.search(r'<title[^>]*>(.*?)</title>', blk, re.S)
        lm = re.search(r'<link[^>]*?href=["\']([^"\']+)["\'][^>]*?/?>', blk) if '<entry' in blk[:7] else None
        if not lm:
            lm = re.search(r'<link>(.*?)</link>', blk, re.S) or re.search(r'<link[^>]*?href=["\']([^"\']+)["\']', blk)
        pm = re.search(r'<(?:pubDate|published|updated|dc:date)>(.*?)</', blk, re.S)
        url = _html.unescape(_txt(lm.group(1)) if lm else '').strip()
        if url and base and not url.startswith('http'):
            url = urljoin(base, url)
        title = _txt(tm.group(1)) if tm else ''
        if not ok_url(url) or not title:
            continue
        out.append({'title': title, 'url': url[:500], 'published': iso(_txt(pm.group(1)) if pm else '')})
    return out[:50], name


def iso(s):
    """날짜 글자 → ISO(모르면 그대로 앞 25자)."""
    s = (s or '').strip()
    if not s:
        return ''
    try:
        from email.utils import parsedate_to_datetime
        return parsedate_to_datetime(s).isoformat()
    except Exception:
        pass
    try:
        return datetime.fromisoformat(s.replace('Z', '+00:00')).isoformat()
    except Exception:
        return s[:25]


def feed_links(page, base):
    """쪽 안의 피드 표시(link rel=alternate type=rss/atom) → 주소들."""
    out = []
    for tag in re.findall(r'<link\b[^>]*>', page or '', re.I):
        if not re.search(r'rel=["\']?alternate', tag, re.I):
            continue
        if not re.search(r'type=["\']?application/(rss|atom)\+xml', tag, re.I):
            continue
        h = re.search(r'href=["\']([^"\']+)["\']', tag, re.I)
        if h:
            u = urljoin(base, _html.unescape(h.group(1)))
            if ok_url(u) and u not in out:
                out.append(u)
    return out


def find_feed(url, get=_get):
    """글(또는 사이트) 주소 → {feed, name, page, items} · 못 찾으면 None. 사람이 누를 때만 묻는다.
    차례 = ① 그 주소가 곧 피드 ② 쪽 안의 피드 표시 ③ 사이트 첫 쪽의 피드 표시 ④ 흔한 자리."""
    if not ok_url(url):
        return None
    s = urlsplit(url)
    root = '%s://%s/' % (s.scheme, s.netloc)

    def _try(fu):
        x = get(fu)
        if x and is_feed(x):
            items, name = parse_feed(x, fu)
            if items:
                return {'feed': fu, 'name': name or s.netloc, 'page': root, 'items': items}
        return None

    page = get(url)
    if page and is_feed(page):
        return _try(url)
    cands = feed_links(page or '', url)
    if url.rstrip('/') != root.rstrip('/'):
        cands += [u for u in feed_links(get(root) or '', root) if u not in cands]
    cands += [urljoin(root, g) for g in GUESS]
    for fu in cands[:12]:
        r = _try(fu)
        if r:
            return r
    return None


def by_app(conn):
    """앱(관리자)이 이미 받는 피드 — 주소록(user_rss_registry LIVE)."""
    try:
        return {norm(r[0]) for r in conn.execute(
            "SELECT feed_url FROM user_rss_registry WHERE COALESCE(record_status,'LIVE')='LIVE'")}
    except Exception:
        return set()


def sites(conn, kind=None):
    ensure(conn)
    ok = {r[0]: r[1] or '' for r in conn.execute('SELECT feed_url, ok_at FROM userdb.user_my_site_ok')}
    app = by_app(conn)
    q = 'SELECT feed_url, site_name, page_url, feed_kind FROM userdb.user_my_site'
    args = ()
    if kind:
        q += ' WHERE feed_kind=?'
        args = (kind,)
    return [{'feed': r[0], 'name': r[1] or r[0], 'page': r[2] or '', 'kind': r[3] or 'NEWS',
             'ok_at': ok.get(r[0], ''), 'by_app': norm(r[0]) in app}
            for r in conn.execute(q + ' ORDER BY lower(site_name)', args)]


def add(conn, feed, name, page='', kind='NEWS'):
    if not ok_url(feed):
        return False
    ensure(conn)
    kind = kind if kind in KINDS else 'NEWS'
    page = page if ok_url(page) else ''
    conn.execute('INSERT OR IGNORE INTO userdb.user_my_site(feed_url) VALUES(?)', (feed[:500],))
    conn.execute('UPDATE userdb.user_my_site SET site_name=?, page_url=?, feed_kind=? WHERE feed_url=?',
                 ((name or '')[:200], page[:500], kind, feed[:500]))
    conn.commit()
    return True


def remove(conn, feed):
    ensure(conn)
    conn.execute('DELETE FROM userdb.user_my_site WHERE feed_url=?', (feed,))
    conn.execute('DELETE FROM userdb.user_my_site_item WHERE feed_url=?', (feed,))
    conn.commit()


def _cfg(conn, k, v=None):
    if v is None:
        r = conn.execute('SELECT config_val FROM user_config WHERE config_key=?', (k,)).fetchone()
        return r[0] if r else ''
    conn.execute('INSERT OR REPLACE INTO user_config(config_key, config_val) VALUES(?,?)', (k, v))


def due(conn, now=None):
    now = now or datetime.now()
    try:
        last = datetime.fromisoformat(_cfg(conn, 'MY_SITE_AT'))
    except Exception:
        return True
    return now - last >= timedelta(hours=DUE_HOURS)


def _store(conn, feed, name, items, n0):
    n = 0
    for it in items:
        cur = conn.execute('INSERT OR IGNORE INTO userdb.user_my_site_item(url, feed_url, site, title, published, fetched_at)'
                           ' VALUES(?,?,?,?,?,?)', (it['url'], feed, name, it['title'], it['published'] or n0, n0))
        n += cur.rowcount or 0
    return n


def _mark(conn, feed, col, at):
    conn.execute('INSERT OR IGNORE INTO userdb.user_my_site_ok(feed_url) VALUES(?)', (feed,))
    conn.execute('UPDATE userdb.user_my_site_ok SET %s=? WHERE feed_url=?' % col, (at, feed))


def _take(conn, s, get, n0):
    x = get(s['feed'])
    items = parse_feed(x, s['feed'])[0] if x and is_feed(x) else []
    if not items:
        _mark(conn, s['feed'], 'fail_at', n0)
        return -1
    n = _store(conn, s['feed'], s['name'], items, n0)
    _mark(conn, s['feed'], 'ok_at', n0)
    return n


def fetch(conn, force=False, get=_get, now=None):
    """하루 한 번 — 사이트마다 피드 → 쌓는다(60일 넘은 것은 걷는다) · 앱이 받는 피드는 건너뛴다. → 새 글 수."""
    ss = [s for s in sites(conn) if not s['by_app']]
    if not ss or (not force and not due(conn, now)):
        return 0
    n0 = (now or datetime.now()).isoformat(timespec='seconds')
    added = 0
    import random
    import time
    for i, s in enumerate(ss):
        if i and get is _get:
            time.sleep(random.uniform(*GAP))
        added += max(_take(conn, s, get, n0), 0)
    cut = ((now or datetime.now()) - timedelta(days=60)).isoformat()
    conn.execute('DELETE FROM userdb.user_my_site_item WHERE COALESCE(published, fetched_at) < ?', (cut,))
    _cfg(conn, 'MY_SITE_AT', n0)
    conn.commit()
    return added


def probe(conn, url, kind='NEWS', get=_get):
    """주소 하나 → 피드를 찾아 담고 그 자리에서 받는다.
    → ('ADDED', 사이트, 받은 수) · ('BYAPP', 사이트, 0) · ('NOFEED', 주소의 사이트 이름, 0)."""
    ensure(conn)
    r = find_feed(url, get)
    if not r:
        return ('NOFEED', {'name': urlsplit(url).netloc, 'page': url, 'feed': ''}, 0)
    s = {'feed': r['feed'], 'name': r['name'], 'page': r['page']}
    add(conn, r['feed'], r['name'], r['page'], kind)
    if norm(r['feed']) in by_app(conn):
        return ('BYAPP', s, 0)
    n0 = datetime.now().isoformat(timespec='seconds')
    _store(conn, r['feed'], r['name'], r['items'], n0)
    _mark(conn, r['feed'], 'ok_at', n0)
    conn.commit()
    return ('ADDED', s, len(r['items']))


def items(conn, kind=None, limit=200):
    """받은 글 — reading_news 목록 꼴 {title,url,site,published}. 뺀 사이트의 글은 안 나온다."""
    ensure(conn)
    q = ('SELECT i.title, i.url, i.site, COALESCE(i.published, i.fetched_at) FROM userdb.user_my_site_item i '
         'JOIN userdb.user_my_site s ON s.feed_url=i.feed_url')
    args = []
    if kind:
        q += ' WHERE s.feed_kind=?'
        args.append(kind)
    q += ' ORDER BY 4 DESC LIMIT ?'
    args.append(int(limit))
    return [{'title': r[0], 'url': r[1], 'site': r[2] or '', 'published': r[3] or '', 'lang': ''}
            for r in conn.execute(q, args) if ok_url(r[1] or '')]


def saved_web(conn, limit=200):
    """+Hagah 로 저장한 웹 글(폰·PC 공유 · user_ref_asset WEB) — reading_news 목록 꼴. ★ 2026-10-24 「저장한 글」 갈래."""
    from urllib.parse import urlsplit as _us
    try:
        rows = conn.execute("SELECT title, url FROM userdb.user_ref_asset WHERE ref_type='WEB' "
                            "AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY ref_id DESC LIMIT ?", (int(limit),)).fetchall()
    except Exception:
        return []
    return [{'title': t or u, 'url': u, 'site': _us(u).netloc, 'published': '', 'lang': ''}
            for t, u in rows if ok_url(u or '')]


def site_reco_text(name, page, feed=''):
    """사이트 추천 글(관리자 소통 통로 kind SITE) — 폰 siteRecoText 와 글자 그대로 같은 꼴."""
    lines = ['[사이트 추천]', '사이트: %s' % (name or '').strip()]
    if page:
        lines.append('주소: %s' % page.strip())
    if feed:
        lines.append('피드: %s' % feed.strip())
    return '\n'.join(lines)


def recommend(conn, name, page, feed=''):
    """관리자에게 사이트 추천 → (보냄?, 까닭)."""
    import user_feedback as F
    return F.submit(conn, 'SITE', site_reco_text(name, page, feed))


def selftest():
    import sqlite3
    ok = []

    def ck(n, c):
        ok.append(bool(c))
        print(('OK   ' if c else 'FAIL ') + n)

    rss = ('<?xml version="1.0"?><rss><channel><title>말씀 신문</title>'
           '<item><title><![CDATA[오늘의 <b>말씀</b> &amp; 기도]]></title><link>https://news.ex.com/a/1</link>'
           '<pubDate>Fri, 24 Oct 2026 09:00:00 +0900</pubDate></item>'
           '<item><title>나쁜 주소</title><link>javascript:alert(1)</link></item></channel></rss>')
    atom = ('<feed xmlns="http://www.w3.org/2005/Atom"><title>묵상 블로그</title><entry><title>시편 23</title>'
            '<link rel="alternate" href="/p/23"/><published>2026-10-23T05:00:00Z</published></entry></feed>')
    page = '<html><head><link rel="alternate" type="application/rss+xml" href="/rss.xml"></head></html>'
    state = {'fail': False}
    asked = []

    def get(u):
        asked.append(u)
        if state['fail']:
            return None
        return {'https://news.ex.com/a/1': page, 'https://news.ex.com/rss.xml': rss,
                'https://blog.ex.com/': '<html></html>', 'https://blog.ex.com/feed': atom,
                'https://blog.ex.com/p/9': '<html></html>'}.get(u)

    its, name = parse_feed(rss)
    ck('RSS 읽기 — 태그 걷고 글자만 · 이상한 주소 버림', len(its) == 1 and its[0]['title'] == '오늘의 말씀 & 기도' and name == '말씀 신문')
    a, _ = parse_feed(atom, 'https://blog.ex.com/feed')
    ck('Atom 읽기 — 상대 주소를 붙인다', a and a[0]['url'] == 'https://blog.ex.com/p/23')
    ck('쪽 안의 피드 표시', find_feed('https://news.ex.com/a/1', get)['feed'] == 'https://news.ex.com/rss.xml')
    ck('표시가 없으면 흔한 자리', find_feed('https://blog.ex.com/p/9', get)['feed'] == 'https://blog.ex.com/feed')
    ck('http(s) 가 아니면 묻지 않는다', find_feed('file:///c:/x', get) is None)

    c = sqlite3.connect(':memory:')
    c.execute("ATTACH ':memory:' AS userdb")
    c.execute('CREATE TABLE user_config(config_key TEXT PRIMARY KEY, config_val TEXT)')
    c.execute("CREATE TABLE user_rss_registry(feed_url TEXT, record_status TEXT)")
    ck('사이트가 없으면 묻지 않는다', fetch(c, get=get) == 0)
    st, s, n = probe(c, 'https://news.ex.com/a/1', 'NEWS', get)
    ck('담기 — 그 자리에서 받는다', st == 'ADDED' and n == 1 and len(items(c)) == 1)
    ck('하루 한 번', fetch(c, get=get) == 0)
    state['fail'] = True
    fetch(c, force=True, get=get)
    ck('실패해도 지난 목록 유지', len(items(c)) == 1)
    st, s, n = probe(c, 'https://nowhere.ex.com/x', 'NEWS', get)
    ck('피드가 없으면 NOFEED · 담지 않는다', st == 'NOFEED' and len(sites(c)) == 1)
    state['fail'] = False
    c.execute("INSERT INTO user_rss_registry VALUES('http://www.news.ex.com/rss.xml/','LIVE')")
    asked.clear()
    ck('앱이 받는 피드는 건너뛴다(주소 적는 꼴이 달라도)', fetch(c, force=True, get=get) == 0 and not asked
       and sites(c)[0]['by_app'])
    ck('갈래로 거른다', items(c, 'DEVOTIONAL') == [] and len(items(c, 'NEWS')) == 1)
    c.execute('DELETE FROM user_rss_registry')
    remove(c, 'https://news.ex.com/rss.xml')
    ck('빼면 그 글도 안 나온다', items(c) == [] and sites(c) == [])
    ck('추천 글 꼴', site_reco_text('a', 'https://a.com', 'https://a.com/feed') ==
       '[사이트 추천]\n사이트: a\n주소: https://a.com\n피드: https://a.com/feed')
    print('%d/%d' % (sum(ok), len(ok)))
    return all(ok)


if __name__ == '__main__':
    import sys
    sys.exit(0 if selftest() else 1)
