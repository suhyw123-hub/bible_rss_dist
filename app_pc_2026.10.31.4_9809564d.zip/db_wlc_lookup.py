# -*- coding: utf-8 -*-
"""db_wlc_lookup.py — 히브리 원문·Strong 조회 (영구 도구, **로컬 전용**).

왜 필요한가 — 2026-08-07 실측.
  설명문에 쓰는 원어를 **기억으로 단정**해 왔다. 출애굽기 51절을 쓰며 십브라·르우엘·코헨·스네를
  검증 없이 적었다. 확인해 보니 20건이 다 맞았지만 그건 **확인한 것이지 보장된 것이 아니었다.**
  `db_vers_gate` 의 원어 검사는 표기 **형식**만 본다(순서·과밀) — 어휘집을 우리가 쓴 글에서
  만들기 때문에 「그 낱말이 그 절에 실제로 있는가」는 아무도 묻지 않는다.

  그리고 이 도구는 점검만이 아니라 **증명**을 한다. 「테바는 성경에서 딱 두 곳」 같은 주장을
  세어서 확인할 수 있고, 세어 보면 못 보던 것이 나온다 — 파레크(H6531)를 세다가
  겔 34:4(목자가 양을 파레크로 다스렸다)를 찾았다. **절별 주석은 절을 넘는 반복을 못 본다.
  그 빈자리가 이 자산이 주석보다 나을 수 있는 몇 안 되는 자리다.**

⚠ `wlc_verify.db` 는 **배포하지 않는다**(§18-10). 본문은 Public Domain 이나 lemma 층이
  CC BY 4.0 이라, 검증용 로컬 파일로만 둔다. `bible_master.db` 에 넣지 말 것.

사용:
  python db_wlc_lookup.py --verse 2 1 13            # 그 절의 낱말·Strong
  python db_wlc_lookup.py --strong H6531            # 전권 출현 위치
  python db_wlc_lookup.py --strong H8392 --book 2   # 그 책 안에서만
  python db_wlc_lookup.py --claim 2:1:13=H6531 2:1:14=H4843   # 주장 일괄 검증
  python db_wlc_lookup.py --selftest                # 의무
"""
import argparse
import os
import sqlite3
import sys

import appdb

APP = os.path.dirname(os.path.abspath(__file__))
WLC = os.path.join(APP, 'wlc_verify.db')


def _wlc():
    if not os.path.exists(WLC):
        print('wlc_verify.db 가 없다. `python db_wlc_verify.py --build` 로 만든다.')
        sys.exit(2)
    return sqlite3.connect(WLC)


def _ref(b, vid):
    r = b.execute('SELECT bcode,chapter,verse FROM bible_index WHERE verse_id=?', (vid,)).fetchone()
    return r if r else None


def _bookname(b, bcode):
    r = b.execute("SELECT short_name FROM book_names WHERE book_code=? AND lang_code='KO'",
                  (bcode,)).fetchone()
    return r[0] if r else str(bcode)


def show_verse(bcode, ch, vs):
    b, w = appdb.connect(), _wlc()
    r = b.execute('SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?',
                  (bcode, ch, vs)).fetchone()
    if not r:
        print('그런 절이 없다'); return 1
    row = w.execute('SELECT heb,strongs FROM wlc_verse WHERE verse_id=?', (r[0],)).fetchone()
    if not row:
        print('WLC 에 그 절이 없다 (구약만 담겨 있다)'); return 1
    krv = b.execute("SELECT verse_text FROM bible_content WHERE verse_id=? AND version_code='KRV'",
                    (r[0],)).fetchone()
    print('%s %d:%d  (vid %d)' % (_bookname(b, bcode), ch, vs, r[0]))
    print('KRV %s' % (krv[0] if krv else ''))
    print()
    words, strongs = (row[0] or '').split(), (row[1] or '').split()
    if len(words) != len(strongs):
        print('⚠ 낱말 %d개 · Strong %d개 — 개수가 어긋난다. 짝을 믿지 말 것.'
              % (len(words), len(strongs)))
    for i, s in enumerate(strongs):
        print('  %-8s %s' % (s, words[i] if i < len(words) else ''))
    return 0


def show_strong(strong, book=None):
    """그 Strong 이 나오는 모든 절. 되울림·독점 주장을 **세어서** 확인한다."""
    b, w = appdb.connect(), _wlc()
    strong = strong.upper()
    if not strong.startswith('H'):
        strong = 'H' + strong
    hits = []
    for vid, ss in w.execute('SELECT verse_id,strongs FROM wlc_verse'):
        if strong in (ss or '').split():
            rf = _ref(b, vid)
            if rf and (book is None or rf[0] == book):
                hits.append(rf)
    books = {}
    for bc, ch, vs in hits:
        books.setdefault(bc, []).append('%d:%d' % (ch, vs))
    print('%s — %d절 · %d권%s' % (strong, len(hits), len(books),
                                 ('' if book is None else ' (책 %d 로 한정)' % book)))
    for bc, lst in sorted(books.items()):
        print('  %-5s %s' % (_bookname(b, bc), ' '.join(lst)))
    return 0


def check_claims(claims):
    """`bcode:ch:vs=H1234` 형식을 일괄 검증. 초안을 쓰며 원어를 댈 때마다 여기 통과시킨다."""
    b, w = appdb.connect(), _wlc()
    ok = bad = 0
    for cl in claims:
        try:
            ref, strong = cl.split('=')
            bc, ch, vs = (int(x) for x in ref.split(':'))
        except ValueError:
            print('  ? 형식 오류: %s  (bcode:ch:vs=H1234)' % cl); bad += 1; continue
        strong = strong.upper()
        if not strong.startswith('H'):
            strong = 'H' + strong
        r = b.execute('SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?',
                      (bc, ch, vs)).fetchone()
        row = w.execute('SELECT strongs FROM wlc_verse WHERE verse_id=?', (r[0],)).fetchone() if r else None
        hit = bool(row) and strong in (row[0] or '').split()
        print('  %s %s %d:%d  %s' % ('O' if hit else 'X', _bookname(b, bc), ch, vs, strong))
        ok, bad = (ok + 1, bad) if hit else (ok, bad + 1)
    print()
    print('확인 %d · 불일치 %d' % (ok, bad))
    return 1 if bad else 0


def selftest():
    """★ 의무. **양방향** — 맞는 주장은 통과, 틀린 주장은 걸려야 한다."""
    print('db_wlc_lookup 자가 검증')
    bad = []
    if not os.path.exists(WLC):
        print('SKIP — wlc_verify.db 없음'); return 0
    b, w = appdb.connect(), _wlc()

    def has(bc, ch, vs, s):
        r = b.execute('SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?',
                      (bc, ch, vs)).fetchone()
        if not r:
            return None
        row = w.execute('SELECT strongs FROM wlc_verse WHERE verse_id=?', (r[0],)).fetchone()
        return bool(row) and s in (row[0] or '').split()

    # ① 맞는 주장 — 창 1:1 의 '창조하시니라'(바라, H1254)
    if not has(1, 1, 1, 'H1254'):
        bad.append('참인 주장을 놓친다 (창 1:1 H1254)')
    # ② 틀린 주장 — 창 1:1 에 '방주'(H8392)는 없다
    if has(1, 1, 1, 'H8392'):
        bad.append('거짓 주장을 통과시킨다 (창 1:1 H8392)')
    # ③ 되울림 — 테바(H8392)는 창세기와 출애굽기 두 권뿐이어야 한다
    seen = set()
    for vid, ss in w.execute('SELECT verse_id,strongs FROM wlc_verse'):
        if 'H8392' in (ss or '').split():
            rf = _ref(b, vid)
            if rf:
                seen.add(rf[0])
    if seen != {1, 2}:
        bad.append('테바(H8392) 분포가 창·출 두 권이 아니다 → %s' % sorted(seen))
    # ④ 신약은 담겨 있지 않다 (구약 전용 파일)
    if has(40, 1, 1, 'H1254'):
        bad.append('신약 절에 결과를 낸다 — 이 파일은 구약 전용이다')

    if bad:
        print('SELFTEST FAIL — %d건' % len(bad))
        for m in bad:
            print('  X ' + m)
        return 1
    print('SELFTEST PASS — 4개 항목')
    return 0


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('--verse', nargs=3, type=int, metavar=('BCODE', 'CH', 'VS'))
    ap.add_argument('--strong')
    ap.add_argument('--book', type=int, help='--strong 을 한 책으로 한정')
    ap.add_argument('--claim', nargs='+', metavar='BCODE:CH:VS=H1234')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if a.verse:
        return show_verse(*a.verse)
    if a.strong:
        return show_strong(a.strong, a.book)
    if a.claim:
        return check_claims(a.claim)
    ap.print_help()
    return 0


if __name__ == '__main__':
    sys.exit(main())
