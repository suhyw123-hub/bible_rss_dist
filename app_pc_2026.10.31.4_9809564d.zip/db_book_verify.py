# -*- coding: utf-8 -*-
"""
db_book_verify.py — **DB 의 도서 본문이 진짜 그 저자의 글인가** (2026-08-22 신설·영구)
====================================================================================
`python db_book_verify.py --selftest`                         — 의무
`python db_book_verify.py --check BOUNDS_PTP _bounds_raw/ccel_power.txt`
`python db_book_verify.py --show  BOUNDS_PTP 2 <원문>`        — 그 유닛을 문장별로
`python db_book_verify.py --purge BOUNDS_PTP --yes`           — 위작 판정분 제거(백업 후)

━━ 왜 만들었나 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
★★★ **바운즈 『기도의 능력』 20장 중 19장이 저자의 글이 아니었다** (2026-08-22
  실측). 바운즈 문체를 흉내 낸 글이 「— E.M. Bounds, Power Through Prayer
  (1907)」라는 출처와 함께 들어가 있었다. 문장 197개 중 원문에 실제로 있는
  것은 11개(6%)뿐이고, 장 제목 20개 중 18개는 이 책에 **없는 제목**이었다.
  사용자 지적: *"말도 안된다 · 정말 엉망이다 · 진정한 원본 아니면 제거하라"*.

★ **이것은 「덜 받은 것」과 다른 종류의 사고다.** 빈 것은 비어 보이지만
  지어낸 것은 **그럴듯해 보인다.** 눈으로 읽어서는 못 잡는다 — 원문과 문장
  단위로 대조해야만 드러난다. 그래서 도구로 만들었다.

⚠ **적재 전에 이 검사를 통과해야 한다**(§0-1b 샘플 검수와 함께). 새 도서를
  넣거나 옛 도서를 의심할 때 돌린다.

━━ 판정 방법 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
문장을 잘라 **정규화한 뒤 원문 안에 그 문장이 통째로 있는지** 본다.
  · 정규화 = 소문자 · 따옴표/대시 통일 · 공백 접기 · 글자와 숫자만 남김
    (하드랩·문장부호·유니코드 변형 때문에 헛되이 못 찾는 것을 막는다)
  · 한 문장에서 **여러 창(window)** 을 떠서 하나라도 맞으면 찾은 것으로 센다
    (OCR 오식 한 글자 때문에 통째로 놓치지 않게)
  · 45자 미만 문장은 세지 않는다 — 짧은 문장은 우연히 맞을 수 있다

판정: 일치율 **90% 이상 = 진본** · 10~90% = **일부** · 10% 미만 = **위작**
⚠ 「일부」는 사람이 봐야 한다. 발췌일 수도, 위작에 진짜 문장을 섞은 것일 수도.
"""
import io
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb

WIN = 55          # 문장에서 떠 볼 창 길이
MIN_SENT = 45     # 이보다 짧은 문장은 세지 않는다
GENUINE = 0.90    # 진본 문턱
FAKE = 0.10       # 위작 문턱

_QUOTE = {'‘': "'", '’': "'", '“': '"', '”': '"',
          '–': '-', '—': '-', '―': '-', ' ': ' '}


def norm(t):
    """대조용 정규화 — **글자와 숫자와 공백만** 남긴다.

    ⚠ 문장부호를 남기면 하드랩·따옴표 변형 때문에 진본도 안 맞는다(실측)."""
    t = t or ''
    for a, b in _QUOTE.items():
        t = t.replace(a, b)
    t = t.lower()
    t = re.sub(r'[^0-9a-z가-힣]+', ' ', t)
    return re.sub(r'\s+', ' ', t).strip()


def sentences(body):
    """본문 → 문장 목록. 머리 제목 줄과 꼬리 출처 줄은 뺀다."""
    b = body or ''
    b = re.sub(r'^\s*CHAPTER\b.*?\n', '', b, flags=re.I)
    # 출처 줄(§17-8) — 맨 끝의 「— …」 줄. **저자의 글이 아니다.**
    # ⚠ 예전에는 `(연도)` 로 끝나는 것만 뗐다. 판본 표기로 바꾸자
    #   (`— 저자, "제목" (Revell, 1895). Public domain.`) 안 떼어져서
    #   검증기가 이 줄을 「원문에 없는 문장」으로 세었다(2026-08-22 실측).
    #   ⇒ **끝에 붙은 대시 줄은 모양을 가리지 않고 뗀다.**
    #   본문 속 제사(`--Name`)는 끝이 아니므로 걸리지 않는다.
    b = re.sub(r'\n\s*[—–]\s*[^\n]{5,200}\s*$', '', b.rstrip())
    b = re.sub(r'\n\s*[—-]\s*[^\n]{5,90}\(\d{4}\)\s*$', '', b)
    out = []
    for s in re.split(r'(?<=[.!?])\s+|\n{2,}', b):
        s = s.strip()
        if len(s) >= MIN_SENT:
            out.append(s)
    return out


def found_in(sent, src_norm):
    """그 문장이 원문에 있나 — 여러 창 중 하나라도 맞으면 있다."""
    n = norm(sent)
    if len(n) < 25:
        return False
    if len(n) <= WIN:
        return n in src_norm
    # 앞·가운데·뒤 세 자리에서 창을 뜬다
    for st in (0, (len(n) - WIN) // 2, len(n) - WIN):
        if n[st:st + WIN] in src_norm:
            return True
    return False


def verdict(ratio, n_sent):
    if n_sent == 0:
        return '빈글'
    if ratio >= GENUINE:
        return '진본'
    if ratio < FAKE:
        return '위작'
    return '일부'


def scan(conn, book_code, src_text, variant=None):
    """[{seq, unit_id, variant, label, n, hit, ratio, verdict}]"""
    S = norm(src_text)
    titles = [m.group(2).strip() for m in
              re.finditer(r'^(\d{1,2}) (.{4,70})$', src_text, re.M)]
    T = {norm(x) for x in titles}
    sql = ("SELECT u.sequence, u.unit_id, x.text_variant, x.lang_code, "
           "       u.unit_label, x.body_text "
           "  FROM sys_book_unit u "
           "  JOIN sys_book_asset b ON b.book_id=u.book_id "
           "  JOIN sys_book_unit_text x ON x.unit_id=u.unit_id "
           " WHERE b.book_code=? ")
    args = [book_code]
    if variant:
        sql += " AND x.text_variant=? "
        args.append(variant)
    sql += " ORDER BY u.sequence, x.text_variant"
    out = []
    for seq, uid, var, lang, label, body in conn.execute(sql, args):
        ss = sentences(body)
        hit = sum(1 for s in ss if found_in(s, S))
        ratio = hit / len(ss) if ss else 0.0
        lab = re.sub(r'^Chapter \d+:\s*', '', label or '').strip()
        out.append({'seq': seq, 'unit_id': uid, 'variant': var, 'lang': lang,
                    'label': label, 'n': len(ss), 'hit': hit, 'ratio': ratio,
                    'verdict': verdict(ratio, len(ss)),
                    'title_in_src': norm(lab) in T})
    return out, titles


def purge(conn, book_code, rows, dry=True):
    """위작 판정분을 **백업하고** 지운다.

    ⚠ 백업표 `temp_fake_book_backup` 에 원문을 남긴다 — 되돌릴 수 있게.
    ⚠ 유닛 자체는 지우지 않고 **본문만** 지운 뒤 유닛을 HIDE 한다.
      `unit_id` 를 없애면 그것을 가리키는 묵상플랜이 통째로 깨진다."""
    conn.execute("""CREATE TABLE IF NOT EXISTS temp_fake_book_backup(
        book_code TEXT, unit_id INTEGER, sequence INTEGER, unit_label TEXT,
        text_variant TEXT, lang_code TEXT, body_text TEXT, saved_at TEXT)""")
    n = 0
    for r in rows:
        if r['verdict'] != '위작':
            continue
        n += 1
        if dry:
            continue
        body = conn.execute("SELECT body_text FROM sys_book_unit_text "
                            " WHERE unit_id=? AND text_variant=?",
                            (r['unit_id'], r['variant'])).fetchone()
        conn.execute(
            "INSERT INTO temp_fake_book_backup(book_code, unit_id, sequence,"
            " unit_label, text_variant, lang_code, body_text, saved_at) "
            "VALUES(?,?,?,?,?,?,?,datetime('now'))",
            (book_code, r['unit_id'], r['seq'], r['label'], r['variant'],
             r['lang'], body[0] if body else None))
        conn.execute("DELETE FROM sys_book_unit_text "
                     " WHERE unit_id=? AND text_variant=?",
                     (r['unit_id'], r['variant']))
    if not dry:
        # 본문이 하나도 안 남은 유닛은 HIDE (지우지 않는다 — 플랜이 가리킨다)
        conn.execute("""UPDATE sys_book_unit SET record_status='HIDE'
             WHERE book_id=(SELECT book_id FROM sys_book_asset WHERE book_code=?)
               AND unit_id NOT IN (SELECT unit_id FROM sys_book_unit_text
                                    WHERE TRIM(COALESCE(body_text,''))<>'')""",
                     (book_code,))
        conn.commit()
    return n


# ── 자가 검증 ────────────────────────────────────────────────────────────
def _selftest():
    ok = True

    def chk(name, cond, extra=''):
        nonlocal ok
        print(('  PASS ' if cond else '  FAIL ') + name +
              (' ' + str(extra) if extra else ''))
        if not cond:
            ok = False

    src = ("1 Men of Prayer Needed\n\n"
           "WE are constantly on a stretch, if not on a strain, to devise new "
           "methods, new plans, new organizations to advance the Church and "
           "secure enlargement and efficiency for the gospel.\n\n"
           "The Church is looking for better methods; God is looking for "
           "better men. What the Church needs today is not more machinery or "
           "better, not new organizations or more and novel methods, but men "
           "whom the Holy Ghost can use.\n")
    S = norm(src)

    # ① 진짜 문장은 찾는다 — 하드랩·따옴표가 달라도
    real = ("WE are constantly on a stretch, if not on a strain,\n   to devise "
            "new methods, new plans, new organizations to advance the Church")
    chk('하드랩이 있어도 찾는다', found_in(real, S))
    curly = 'The Church is looking for better methods—God is looking for better men.'
    chk('대시가 달라도 찾는다', found_in(curly, S))

    # ② 지어낸 문장은 못 찾는다 — **탐지력 검사**
    fake = ("No man can be a prayer without being devoted to prayer. "
            "The closet is the vestibule of heaven and the antechamber of God.")
    chk('지어낸 문장은 못 찾는다', not found_in(fake, S))

    # ③ 짧은 문장은 안 센다(우연 일치 방지)
    chk('짧은 문장은 안 센다', not sentences('God is love. Amen.'))

    # ④ 출처 줄과 제목 줄은 떼어 낸다
    body = ('CHAPTER 2: PRAYER AND DEVOTION UNITED\n\n'
            + 'x' * 60 + '.\n\n— E.M. Bounds, Power Through Prayer (1907)')
    ss = sentences(body)
    chk('제목·출처 줄 제외', len(ss) == 1 and ss[0].startswith('x'), ss)

    # ⑤ 판정 문턱
    chk('진본 판정', verdict(1.0, 10) == '진본')
    chk('위작 판정', verdict(0.0, 10) == '위작')
    chk('일부 판정', verdict(0.5, 10) == '일부')
    chk('빈 글', verdict(0.0, 0) == '빈글')

    # ⑥ 실제 원문이 있으면 **진짜 1장은 진본으로 나와야** 한다
    p = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                     '_bounds_raw', 'ccel_power.txt')
    if os.path.exists(p):
        real_src = io.open(p, encoding='utf-8', errors='replace').read()
        RS = norm(real_src)
        # 원문에서 문장을 떠서 스스로 대조 — 100% 나와야 한다
        m = re.search(r'^1 Men of Prayer Needed$', real_src, re.M)
        chunk = real_src[m.end():m.end() + 6000]
        ss = sentences(chunk)
        hit = sum(1 for s in ss if found_in(s, RS))
        chk('원문 자기 대조 100%', ss and hit == len(ss),
            '%d/%d' % (hit, len(ss)))
    else:
        print('  --   원문 없음 — 자기 대조 건너뜀')

    # ⑦ purge 는 미리보기에서 아무것도 안 지운다
    conn = appdb.connect()
    n0 = conn.execute("SELECT COUNT(*) FROM sys_book_unit_text").fetchone()[0]
    purge(conn, 'NO_SUCH_BOOK', [{'verdict': '위작', 'unit_id': -1, 'seq': 0,
                                  'label': '', 'variant': 'X', 'lang': 'EN'}],
          dry=True)
    n1 = conn.execute("SELECT COUNT(*) FROM sys_book_unit_text").fetchone()[0]
    chk('미리보기는 안 지운다', n0 == n1, '%d → %d' % (n0, n1))
    conn.close()
    print('RESULT:', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def _report(rows, titles, book_code):
    print('원문 장 제목 %d개' % len(titles))
    print()
    print('%-4s %-10s %-42s %5s %5s %6s %-5s %s'
          % ('seq', '변형', '제목', '문장', '일치', '비율', '판정', '제목'))
    agg = {}
    for r in rows:
        agg[r['verdict']] = agg.get(r['verdict'], 0) + 1
        print('%-4d %-10s %-42s %5d %5d %5.0f%% %-5s %s'
              % (r['seq'], r['variant'], (r['label'] or '')[:40], r['n'],
                 r['hit'], r['ratio'] * 100, r['verdict'],
                 'O' if r['title_in_src'] else 'X'))
    print()
    print('판정:', ' · '.join('%s %d' % (k, v) for k, v in sorted(agg.items())))
    tot_n = sum(r['n'] for r in rows)
    tot_h = sum(r['hit'] for r in rows)
    print('문장 %d개 중 원문 일치 %d개 (%.0f%%)'
          % (tot_n, tot_h, 100.0 * tot_h / max(1, tot_n)))


def main():
    args = sys.argv[1:]
    if '--selftest' in args:
        raise SystemExit(_selftest())
    if '--check' in args or '--purge' in args or '--show' in args:
        conn = appdb.connect()
        if '--show' in args:
            i = args.index('--show')
            code, seq, path = args[i + 1], int(args[i + 2]), args[i + 3]
            src = io.open(path, encoding='utf-8', errors='replace').read()
            S = norm(src)
            for _s, _u, var, _l, label, body in conn.execute(
                    "SELECT u.sequence,u.unit_id,x.text_variant,x.lang_code,"
                    "       u.unit_label,x.body_text FROM sys_book_unit u "
                    "  JOIN sys_book_asset b ON b.book_id=u.book_id "
                    "  JOIN sys_book_unit_text x ON x.unit_id=u.unit_id "
                    " WHERE b.book_code=? AND u.sequence=?", (code, seq)):
                print('=== seq %d · %s · %s ===' % (seq, var, label))
                for s in sentences(body):
                    print('  %s %s' % ('O' if found_in(s, S) else 'X', s[:96]))
                print()
            conn.close()
            return
        i = args.index('--check' if '--check' in args else '--purge')
        code = args[i + 1]
        path = args[i + 2] if len(args) > i + 2 and not args[i + 2].startswith('--') else None
        if not path:
            raise SystemExit('원문 파일 경로가 필요하다')
        src = io.open(path, encoding='utf-8', errors='replace').read()
        rows, titles = scan(conn, code, src)
        _report(rows, titles, code)
        if '--purge' in args:
            n = purge(conn, code, rows, dry=('--yes' not in args))
            print()
            if '--yes' in args:
                print('제거 %d건 (백업표 temp_fake_book_backup 에 남겼다)' % n)
            else:
                print('제거 대상 %d건 — 실제로 지우려면 `--yes`' % n)
        conn.close()
        return
    print(__doc__)


if __name__ == '__main__':
    main()
