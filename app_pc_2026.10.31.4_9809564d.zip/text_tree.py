# -*- coding: utf-8 -*-
"""text_tree.py — **줄바꿈이 되는 나무 목록**(P4 구절연결 「트리뷰」 · 2026-10-11 docs/1.txt 2).

    python text_tree.py --selftest

★★★ **왜 만들었나** — 트리뷰를 `ttk.Treeview` 로 지었는데 그 부품은 **줄바꿈을 못 한다**
  (줄 높이도 모든 줄이 같게 못 박힌다). 그래서 구절 본문이 칸 끝에서 잘렸다(사용자 「P1 구절
  본문 화면처럼 줄바꿈」). 설정으로는 못 고친다 — 글상자(`tk.Text`)로 다시 지었다.
★★★ **`Treeview` 를 쓰던 코드가 그대로 돈다** — 캔버스↔트리 양방향 연동(▸ = 캔버스 지도에
  펼치기 · ▾ = 보기만 접기 · ＋ 다음 묶음)이 `insert`·`item`·`get_children`·`selection`·`focus`·
  `<<TreeviewSelect>>`·`<<TreeviewOpen>>`·`<<TreeviewClose>>` 로 짜여 있다. 그 말을 그대로 받는다
  — 연동 코드를 다시 쓰면 지난번 맞춘 「100% 연동」이 또 갈린다.

줄 하나 = `[관계명] (약명) 본문`(사용자 지시 — 관계명이 앞 · 약명과 본문을 한 덩어리로).
  · 단계는 **들여쓰기**(접힌 둘째 줄도 같은 자리 · `lmargin2`).
  · ▸/▾ 는 누를 수 있는 글자다 — 자녀가 있는 줄에만.
  · 자리표 줄(`__EXPAND__…`)은 그리지 않는다 — 그 줄이 있다는 것이 곧 ▸ 다(Treeview 와 같다).
⚠ **색은 전부 역할로**(`ui_theme.C`) — 옛 트리는 단계마다 흰색 계열 바탕을 박아(`#FFFFFF`…)
  어두운 화면색에서 펼칠 때 반전처럼 보였다(사용자 신고 · 그 자리를 걷었다).
"""
import tkinter as tk

try:
    import ui_theme
except Exception:                                             # noqa: BLE001
    ui_theme = None


def _C(role, fb):
    try:
        v = ui_theme.C(role) if ui_theme else ''
    except Exception:                                         # noqa: BLE001
        v = ''
    return v or fb


INDENT = 18          # 단계 하나의 들여쓰기(px)
_VIRTUAL = ('<<TreeviewSelect>>', '<<TreeviewOpen>>', '<<TreeviewClose>>')


class TextTree(tk.Frame):
    """`ttk.Treeview` 의 쓰는 말만 받는 글상자 나무."""

    def __init__(self, parent, db_path=None, font_scope='list', **kw):
        bg = _C('panel', 'white')
        super().__init__(parent, bg=bg)
        self._items = {}              # iid → dict(parent, text, values, tags, open, kids)
        self._roots = []
        self._n = 0
        self._sel = None
        self._focus = ''
        self._cols = {}
        sb = tk.Scrollbar(self, orient='vertical')
        sb.pack(side='right', fill='y')
        # ⚠ 요구 크기를 옛 Treeview 와 비슷하게(높이 12줄 · 폭은 칸을 따른다). P1·P4 를 나누는 칸이
        #   **요구 높이**를 보고 처음 나누므로, 너무 작게 요구하면 P4 가 167px 로 눌려 다른 탭(AI 도우미)의
        #   단추가 화면 밖으로 밀렸다 · 기본값(80자×24줄)이면 반대로 부푼다(배선 하네스가 잡았다).
        self.txt = tk.Text(self, wrap='word', bd=0, highlightthickness=0, cursor='arrow', width=1, height=12,
                           padx=8, pady=6, yscrollcommand=sb.set,
                           bg=bg, fg=_C('fg', '#2C3E50'))
        self.txt.pack(side='left', fill='both', expand=True)
        sb.config(command=self.txt.yview)
        if db_path:
            try:
                import theme_font
                theme_font.register(self.txt, db_path, font_scope)
            except Exception:                                 # noqa: BLE001
                pass
        self.txt.bind('<Button-1>', self._click)
        self.txt.bind('<Key>', lambda e: 'break' if e.keysym not in
                      ('Up', 'Down', 'Prior', 'Next', 'Home', 'End', 'c', 'C') else None)
        self._retag()

    # ── 색·글자 꼴 — 그릴 때마다 역할로(태그 색은 테마 칠하기가 못 본다 §36-5b) ──
    def _retag(self):
        t = self.txt
        t.config(bg=_C('panel', 'white'), fg=_C('fg', '#2C3E50'))
        t.tag_configure('rel', foreground=_C('accent', '#1A5276'))
        t.tag_configure('ref', foreground=_C('fg_title', '#1B2631'))
        t.tag_configure('tog', foreground=_C('accent', '#1A5276'))
        t.tag_configure('plus', foreground=_C('accent', '#1A5276'), underline=True)
        t.tag_configure('sel', background=_C('select_bg', '#D6EAF8'))
        t.tag_configure('row', spacing1=3, spacing3=3)
        t.tag_raise('sel')
        t.tag_bind('tog', '<Enter>', lambda e: t.config(cursor='hand2'))
        t.tag_bind('tog', '<Leave>', lambda e: t.config(cursor='arrow'))
        t.tag_bind('plus', '<Enter>', lambda e: t.config(cursor='hand2'))
        t.tag_bind('plus', '<Leave>', lambda e: t.config(cursor='arrow'))

    # ── Treeview 의 말 ────────────────────────────────────────────────
    def heading(self, *a, **k):
        return None

    def column(self, col, **kw):
        self._cols.setdefault(col, {}).update(kw)

    def tag_configure(self, *a, **k):
        # ⚠ 단계 바탕색(옛 Treeview)은 받지 않는다 — 어두운 화면색에서 반전처럼 보였다
        return None

    def insert(self, parent, index='end', iid=None, text='', values=(), tags=(), open=False):
        if iid is None:
            self._n += 1
            iid = 'T%05d' % self._n
        iid = str(iid)
        self._items[iid] = {'parent': parent or '', 'text': text, 'values': tuple(values),
                            'tags': tuple(tags), 'open': bool(open), 'kids': []}
        (self._items[parent]['kids'] if parent else self._roots).append(iid)
        self._dirty()
        return iid

    def exists(self, iid):
        return str(iid) in self._items

    def parent(self, iid):
        it = self._items.get(str(iid))
        return it['parent'] if it else ''

    def get_children(self, item=''):
        if not item:
            return tuple(self._roots)
        it = self._items.get(str(item))
        return tuple(it['kids']) if it else ()

    def item(self, iid, option=None, **kw):
        it = self._items.get(str(iid))
        if it is None:
            raise tk.TclError('Item %s not found' % iid)
        if kw:
            for k, v in kw.items():
                if k == 'open':
                    it['open'] = bool(v)
                elif k in ('text', 'tags'):
                    it[k] = v
                elif k == 'values':
                    it['values'] = tuple(v)
            self._dirty()
            return None
        if option is None:
            return {'text': it['text'], 'values': list(it['values']), 'open': it['open'],
                    'tags': list(it['tags'])}
        if option == 'values':
            return it['values']
        return it.get(option)

    def delete(self, *iids):
        for iid in iids:
            iid = str(iid)
            it = self._items.get(iid)
            if not it:
                continue
            for k in list(it['kids']):
                self.delete(k)
            sib = self._items[it['parent']]['kids'] if it['parent'] in self._items else self._roots
            if iid in sib:
                sib.remove(iid)
            self._items.pop(iid, None)
            if self._sel == iid:
                self._sel = None
            if self._focus == iid:
                self._focus = ''
        self._dirty()

    def selection(self):
        return (self._sel,) if self._sel and self._sel in self._items else ()

    def selection_set(self, iid):
        iid = str(iid[0] if isinstance(iid, (list, tuple)) else iid)
        if iid not in self._items:
            return
        self._sel = iid
        self._focus = iid
        # 접힌 조상은 연다(Treeview 의 see 와 같은 결 — 고른 줄이 보여야 한다)
        p = self._items[iid]['parent']
        while p:
            self._items[p]['open'] = True
            p = self._items[p]['parent']
        self._dirty()
        self.event_generate('<<TreeviewSelect>>', when='tail')

    def selection_remove(self, *a):
        self._sel = None
        self._dirty()

    def focus(self, iid=None):
        if iid is None:
            return self._focus
        self._focus = str(iid)
        return None

    def see(self, iid):
        self._render_now()
        r = self.txt.tag_ranges('R_' + str(iid))
        if r:
            self.txt.see(r[0])

    def bbox(self, iid, column=None):
        self._render_now()
        r = self.txt.tag_ranges('R_' + str(iid))
        if not r:
            return ''
        b = self.txt.bbox(r[0])
        if not b:
            return ''
        x, y, w, h = b
        return (x, y, max(1, self.txt.winfo_width() - x), h)

    def yview(self, *a):
        return self.txt.yview(*a)

    def yview_moveto(self, f):
        self._render_now()
        self.txt.yview_moveto(f)

    def xview(self, *a):
        return (0.0, 1.0)

    def bind(self, seq=None, func=None, add=None):
        if seq in _VIRTUAL:
            return super().bind(seq, func, add)
        return self.txt.bind(seq, func, add)

    # ── 그리기 ────────────────────────────────────────────────────────
    def _dirty(self):
        if getattr(self, '_pending', False):
            return
        self._pending = True
        self.after_idle(self._render_now)

    def _visible_kids(self, it):
        return [k for k in it['kids'] if not str(self._items[k]['values'][:1][0]
                                                if self._items[k]['values'] else '').startswith('__EXPAND__')]

    def _render_now(self):
        self._pending = False
        t = self.txt
        try:
            y0 = t.yview()[0]
        except tk.TclError:
            return
        self._retag()
        t.config(state='normal')
        t.delete('1.0', 'end')
        for tg in t.tag_names():
            if tg.startswith(('R_', 'D_', 'G_')):
                t.tag_delete(tg)

        def put(iid, depth):
            it = self._items[iid]
            vals = it['values']
            v0 = str(vals[0]) if vals else ''
            if v0.startswith('__EXPAND__'):
                return
            dtag = 'D_%d' % depth
            m = 6 + depth * INDENT
            t.tag_configure(dtag, lmargin1=m, lmargin2=m + INDENT)
            row = 'R_' + iid
            start = t.index('end-1c')
            tags = (row, dtag, 'row') + (('sel',) if iid == self._sel else ())
            if v0.startswith('__PLUS__'):
                t.insert('end', '   ' + str(it['text']), tags + ('plus',))
                t.insert('end', '\n', tags)
                return
            has_kids = bool(it['kids'])
            if has_kids:
                t.insert('end', ('▾ ' if it['open'] else '▸ '), tags + ('tog', 'G_' + iid))
            else:
                t.insert('end', '   ', tags)
            rel = str(vals[1]) if len(vals) > 1 and vals[1] else ''
            body = str(vals[2]) if len(vals) > 2 and vals[2] else ''
            if rel:
                t.insert('end', rel + '  ', tags + ('rel',))
            name = str(it['text'] or '')
            if name:
                t.insert('end', '(%s) ' % name if body else name, tags + ('ref',))
            if body:
                t.insert('end', body, tags)
            t.insert('end', '\n', tags)
            _ = start
            if it['open']:
                for k in it['kids']:
                    put(k, depth + 1)

        for r in self._roots:
            put(r, 0)
        t.config(state='disabled')
        try:
            t.yview_moveto(y0)
        except tk.TclError:
            pass

    def _row_at(self, idx):
        for tg in self.txt.tag_names(idx):
            if tg.startswith('R_'):
                return tg[2:]
        return None

    def _click(self, e):
        idx = self.txt.index('@%d,%d' % (e.x, e.y))
        iid = self._row_at(idx)
        if not iid or iid not in self._items:
            return 'break'
        on_tog = any(tg.startswith('G_') for tg in self.txt.tag_names(idx))
        self._focus = iid
        if on_tog:
            it = self._items[iid]
            it['open'] = not it['open']
            self._render_now()
            self.event_generate('<<TreeviewOpen>>' if it['open'] else '<<TreeviewClose>>', when='tail')
            return 'break'
        self._sel = iid
        self._render_now()
        self.event_generate('<<TreeviewSelect>>', when='tail')
        return 'break'


# ── 자가 점검 ─────────────────────────────────────────────────────────
def selftest():
    bad, n = [], [0]

    def ck(c, m):
        n[0] += 1
        if not c:
            bad.append(m)
    r = tk.Tk()
    r.geometry('320x300')
    tv = TextTree(r)
    tv.pack(fill='both', expand=True)
    got = []
    tv.bind('<<TreeviewSelect>>', lambda e: got.append(('S', tv.selection())))
    tv.bind('<<TreeviewOpen>>', lambda e: got.append(('O', tv.focus())))
    tv.bind('<<TreeviewClose>>', lambda e: got.append(('C', tv.focus())))
    a = tv.insert('', 'end', text='창 1:1', values=('v1', '', '태초에 하나님이 천지를 창조하시니라 ' * 4))
    b = tv.insert(a, 'end', text='요 1:1', values=('v2', '병행', '태초에 말씀이 계시니라'))
    tv.insert(b, 'end', text='…', values=('__EXPAND__v2', '', ''))
    tv.insert(a, 'end', text='＋ 다음 묶음 (3)', values=('__PLUS__v1', '', ''))
    tv.item(a, open=True)
    r.update()
    body = tv.txt.get('1.0', 'end')
    ck('(창 1:1)' in body and '병행  (요 1:1) 태초에 말씀' in body, '줄 = 관계명 (약명) 본문')
    ck('…' not in body, '자리표 줄은 안 그린다')
    ck('▸ ' in body and '▾ ' in body, '자녀가 있으면 ▸/▾')
    ck('＋ 다음 묶음 (3)' in body, '＋ 다음 묶음 줄')
    lines = int(tv.txt.count('1.0', 'end', 'displaylines')[0])
    ck(lines > 4, '긴 본문이 여러 줄로 감긴다 (%d)' % lines)
    ck(tv.get_children() == (a,) and tv.get_children(a)[0] == b and tv.parent(b) == a, '나무 구조')
    ck(tv.item(b, 'values')[0] == 'v2' and tv.item(b, 'text') == '요 1:1', 'item 읽기')
    tv.selection_set(b)
    r.update()
    ck(tv.selection() == (b,) and got and got[-1][0] == 'S', 'selection_set → <<TreeviewSelect>>')
    ck(tv.txt.tag_ranges('sel') != (), '선택한 줄에 색')
    # ▸ 누르기
    rng = tv.txt.tag_ranges('G_' + b)
    ck(bool(rng), '▸ 자리')
    if rng:
        x, y, _w, _h = tv.txt.bbox(rng[0])
        tv._click(type('E', (), {'x': x + 2, 'y': y + 2})())
        r.update()
        ck(got[-1] == ('O', b) and tv.item(b, 'open'), '▸ → <<TreeviewOpen>> · 포커스 = 그 줄')
        tv._click(type('E', (), {'x': x + 2, 'y': y + 2})())
        r.update()
        ck(got[-1] == ('C', b) and not tv.item(b, 'open'), '▾ → <<TreeviewClose>>')
    ck(bool(tv.bbox(b)), 'bbox')
    tv.delete(*tv.get_children())
    r.update()
    ck(tv.get_children() == () and tv.txt.get('1.0', 'end').strip() == '' and tv.selection() == (), '모두 지우기')
    r.destroy()
    print('text_tree selftest:', 'OK (%d/%d)' % (n[0], n[0]) if not bad else 'FAIL %d/%d' % (n[0] - len(bad), n[0]))
    for m in bad:
        print('  FAIL', m)
    return not bad


if __name__ == '__main__':
    import sys
    sys.exit(0 if selftest() else 1)
