# -*- coding: utf-8 -*-
"""오늘의 묵상 / 교계 뉴스 — 사용자 앱용 RSS 읽기 백엔드 (외부 의존성 없음).

설계 (CLAUDE.md §21 RSS 트랙 B):
- 실시간 fetch(앱이 직접) + DB 베이스라인(sys_ref_asset, 관리자 수집·배포) 합집합.
- 매 fetch 결과를 user_data.db(user_rss_cache)에 누적 → RSS가 최신만 노출해도
  시간이 지나며 과거분이 쌓임(서버 없이 누적). 오프라인 시 캐시 표시.
- feed_kind: 'DEVOTIONAL'(오늘의 묵상) / 'NEWS'(교계 뉴스).
- 관련성 필터는 적용 안 함(신뢰 사이트 최신글 그대로 — 트랙 A의 연결과 무관).
"""
import html
import re
import json
import sqlite3
import appdb
import xml.etree.ElementTree as ET
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen
from email.utils import parsedate_to_datetime
from datetime import datetime

# 내부 lang_code → 구글번역 ISO 코드
_ISO = {'zht': 'zh-TW', 'zh': 'zh-CN', 'ko': 'ko', 'ja': 'ja', 'en': 'en',
        'de': 'de', 'fr': 'fr', 'es': 'es', 'ru': 'ru', 'pt': 'pt', 'ar': 'ar'}


def _iso_lang(code):
    return _ISO.get((code or 'en').lower(), (code or 'en').lower())

_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) BibleMatrixApp/1.0'
_CE = '{http://purl.org/rss/1.0/modules/content/}encoded'


def _strip(s):
    return re.sub(r'<[^>]+>', ' ', s or '').strip()


def _iso(pubdate):
    """RSS pubDate / Atom updated → 정렬용 ISO 문자열 (실패 시 '')."""
    if not pubdate:
        return ''
    try:
        return parsedate_to_datetime(pubdate).isoformat()
    except Exception:
        pass
    try:
        return datetime.fromisoformat(pubdate.replace('Z', '+00:00')).isoformat()
    except Exception:
        return ''


_DATE_TITLE = re.compile(r'(19|20)\d{2}[-./]?\d{2}[-./]?\d{2}')
_HEAD = re.compile(r'<h([1-3])[^>]*>(.*?)</h\1>', re.S | re.I)


def is_date_title(title):
    """제목이 날짜뿐인가(20261025 · 2026-10-25 · 2026.10.25)."""
    return bool(_DATE_TITLE.fullmatch((title or '').strip()))


def title_from_body(content):
    """★ 2026-10-25 날짜뿐인 제목의 진짜 제목 — 본문 첫 큰 머리글(h1~h3).
    사용자 「오늘의 묵상 … 제목에 날자만 표시되는것 같다」 — 오늘의 양식 한국어판은 피드 제목이 `20261025` 이고
    진짜 제목은 본문 `<h2>하나님이 그리신 당신의 초상화</h2>` 에 있다. ⚠ 본문은 **담지 않는다**(제목만 읽는다)."""
    for _lv, h in _HEAD.findall(content or ''):
        t = html.unescape(re.sub(r'<[^>]+>', ' ', h))
        t = re.sub(r'\s+', ' ', t).strip()
        if 2 <= len(t) <= 120 and not is_date_title(t):
            return t
    return ''


def fix_title(title, content=''):
    """★ 2026-10-24 — 제목이 날짜 숫자뿐인 피드(오늘의 양식 한국어판 `20261024`)는
    ① 본문 첫 머리글이 있으면 그것(2026-10-25) ② 없으면 읽기 좋은 날짜로. 그 밖은 그대로."""
    t = (title or '').strip()
    if is_date_title(t):
        h = title_from_body(content)
        if h:
            return h
        d = re.sub(r'\D', '', t)
        return '%s-%s-%s' % (d[:4], d[4:6], d[6:])
    return t


_CE = '{http://purl.org/rss/1.0/modules/content/}encoded'


def parse_feed(feed_url, max_results=15):
    """RSS/Atom → [{title,url,summary,published}]. 외부 라이브러리 없이."""
    req = Request(feed_url, headers={'User-Agent': _UA})
    with urlopen(req, timeout=12) as r:
        data = r.read()
    root = ET.fromstring(data)
    out = []
    for it in root.iter('item'):
        def t(tag):
            el = it.find(tag)
            return (el.text or '').strip() if el is not None else ''
        _ti = t('title')
        out.append({'title': fix_title(_ti, t(_CE) if is_date_title(_ti) else ''), 'url': t('link'),
                    'summary': _strip(t('description'))[:400],
                    'published': _iso(t('pubDate'))})
        if len(out) >= max_results:
            return out
    if not out:
        NS = 'http://www.w3.org/2005/Atom'
        for e in root.iter(f'{{{NS}}}entry'):
            def at(tag):
                f = e.find(f'{{{NS}}}{tag}')
                return (f.text or '').strip() if f is not None else ''
            le = e.find(f'{{{NS}}}link')
            url = le.get('href', '') if le is not None else ''
            _ti = at('title')
            out.append({'title': fix_title(_ti, at('content') if is_date_title(_ti) else ''), 'url': url,
                        'summary': _strip(at('summary'))[:400],
                        'published': _iso(at('updated') or at('published'))})
            if len(out) >= max_results:
                return out
    return out


def list_feeds(conn, kind, exclude_ids=None, langs=None):
    """해당 kind의 LIVE·enabled 피드 [(feed_id, site_name, feed_url, lang_code)].
       공급자 기본 피드(sys_rss_feed, 양수 id) + 사용자 추가 피드(user_rss_feed, 음수 id=-pk).
       음수 id 로 namespace 분리 → id 충돌 없음, 캐시·제외 모두 정수 그대로."""
    out = []
    ex = set(exclude_ids or [])
    # 공급자 기본 (배포 bible_master.db) — feed_url 키로 baseline 구성
    base = {}  # feed_url -> (fid, name, url, lang)
    for fid, name, url, lang in conn.execute(
            "SELECT feed_id, site_name, feed_url, lang_code FROM sys_rss_feed "
            "WHERE record_status='LIVE' AND enabled=1 AND feed_kind=? ORDER BY lang_code, site_name",
            (kind,)):
        base[url] = (fid, name, url, lang or 'EN')
    # 서버 동기화 레지스트리 오버레이 (user_rss_registry, 연 1~2회 DB배포 사이 증분 갱신)
    try:
        for fid, name, url, lang, status in conn.execute(
                "SELECT feed_id, site_name, feed_url, lang, record_status "
                "FROM user_rss_registry WHERE feed_kind=?", (kind,)):
            if (status or 'LIVE') in ('DELETED', 'HIDE'):
                base.pop(url, None)              # 묘비/숨김 → 표시 제외
            else:
                base[url] = (int(fid) if fid else 0, name, url, (lang or 'EN').upper())
    except Exception:
        pass                                      # 레지스트리 미생성(구버전 user_data)
    for fid, name, url, lang in base.values():
        if fid in ex or (langs and (lang or 'EN') not in langs):
            continue
        out.append((fid, name, url, lang or 'EN'))
    # 사용자 추가 (로컬, 음수 id)
    try:
        for pk, name, url, lang in conn.execute(
                "SELECT feed_id, site_name, feed_url, lang_code FROM user_rss_feed "
                "WHERE enabled=1 AND feed_kind=? ORDER BY lang_code, site_name", (kind,)):
            fid = -int(pk)
            if fid in ex or (langs and (lang or 'EN') not in langs):
                continue
            out.append((fid, name, url, lang or 'EN'))
    except Exception:
        pass
    return out


def feed_channel_title(url):
    """RSS <channel><title> / Atom <feed><title> 반환 (피드 자체 제목). 실패 시 ''.
       같은 사이트의 분야별 피드를 구분하는 데 사용(예: 'Desiring God // Articles')."""
    try:
        req = Request(url, headers={'User-Agent': _UA})
        with urlopen(req, timeout=12) as r:
            data = r.read()
        root = ET.fromstring(data)
    except Exception:
        return ''
    ch = root.find('channel')
    if ch is not None:                       # RSS 2.0
        t = ch.find('title')
        return _strip((t.text or '')) if t is not None else ''
    NS = '{http://www.w3.org/2005/Atom}'      # Atom
    t = root.find(f'{NS}title')
    return _strip((t.text or '')) if t is not None else ''


def discover_feeds(page_url):
    """홈페이지(또는 피드) URL에서 RSS/Atom 피드를 발견. [(feed_url, title)] 반환.
       ① 입력이 이미 피드면 그대로 ② HTML <head>의 <link rel=alternate type=rss/atom>
       ③ 둘 다 없으면 흔한 경로(/feed/, /rss 등) 폴백 검증. (선언 안 된 분야별 피드는 못 찾음)"""
    import re
    import html as _html
    from urllib.parse import urljoin, urlsplit
    page_url = (page_url or '').strip()
    if not (page_url.startswith('http://') or page_url.startswith('https://')):
        return []
    out, seen = [], set()
    text, ctype = '', ''
    try:
        req = Request(page_url, headers={'User-Agent': _UA,
                      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'})
        with urlopen(req, timeout=12) as r:
            ctype = (r.headers.get('Content-Type') or '').lower()
            text = r.read(200000).decode('utf-8', 'replace')
    except Exception:
        return []
    head = text[:1500].lower()
    # ① 입력 자체가 피드인 경우
    if 'xml' in ctype or '<rss' in head or '<feed' in head or head.lstrip().startswith('<?xml'):
        return [(page_url, feed_channel_title(page_url) or _site_from_url(page_url))]
    # ② <link rel="alternate" type="application/(rss|atom)+xml" href="..." title="...">
    for m in re.finditer(r'<link\b[^>]*>', text, re.I):
        tag = m.group(0)
        if 'alternate' not in tag.lower():
            continue
        if not re.search(r'type\s*=\s*["\']application/(rss|atom)\+xml', tag, re.I):
            continue
        hm = re.search(r'href\s*=\s*["\']([^"\']+)["\']', tag, re.I)
        if not hm:
            continue
        href = urljoin(page_url, _html.unescape(hm.group(1)))
        if href in seen:
            continue
        tm = re.search(r'title\s*=\s*["\']([^"\']*)["\']', tag, re.I)
        title = _html.unescape(tm.group(1)) if tm else ''
        seen.add(href)
        out.append((href, title or feed_channel_title(href) or _site_from_url(href)))
    # ③ 폴백: 흔한 경로 (선언된 게 하나도 없을 때만)
    if not out:
        s = urlsplit(page_url)
        base = f"{s.scheme}://{s.netloc}"
        for path in ('/feed/', '/feed', '/rss', '/rss.xml', '/feed.xml', '/atom.xml', '/index.xml'):
            cand = base + path
            if cand in seen:
                continue
            try:
                if parse_feed(cand, 1):
                    seen.add(cand)
                    out.append((cand, feed_channel_title(cand) or _site_from_url(cand)))
            except Exception:
                pass
    return out


def add_user_feed(conn, url, kind, lang='', site_name=''):
    """사용자 RSS 추가 — 실제 fetch로 검증 + 피드 자체 제목 캡처 후 user_rss_feed INSERT.
       (성공bool, 메시지) 반환. 배포 DB(sys_rss_feed) 아닌 로컬(user_rss_feed)에만 저장."""
    url = (url or '').strip()
    if not (url.startswith('http://') or url.startswith('https://')):
        return False, 'http(s) URL을 입력하세요.'
    if conn.execute("SELECT 1 FROM user_rss_feed WHERE feed_url=?", (url,)).fetchone():
        return False, '이미 추가된 피드입니다.'
    try:
        items = parse_feed(url, max_results=1)
    except Exception as e:
        return False, f'피드를 읽을 수 없습니다: {str(e)[:50]}'
    if not items:
        return False, '유효한 RSS 항목이 없습니다.'
    # 이름 우선순위: 사용자 지정 제목 > 피드 자체 제목(channel title) > 도메인
    name = (site_name or '').strip() or feed_channel_title(url) or _site_from_url(url)
    now = datetime.now().isoformat(timespec='seconds')
    from urllib.parse import urlsplit
    base = ''
    try:
        s = urlsplit(url); base = f"{s.scheme}://{s.netloc}"
    except Exception:
        pass
    conn.execute(
        "INSERT INTO user_rss_feed(site_name, feed_url, base_url, lang_code, feed_kind, enabled, added_at) "
        "VALUES(?,?,?,?,?,1,?)", (name[:120], url, base, (lang or 'EN'), kind, now))
    conn.commit()
    return True, f"'{name}' 추가됨"


def remove_user_feed(conn, pk):
    conn.execute("DELETE FROM user_rss_feed WHERE feed_id=?", (int(pk),))
    # 그 피드의 로컬 캐시도 제거 (음수 id 로 저장됨)
    conn.execute("DELETE FROM user_rss_cache WHERE feed_id=?", (-int(pk),))
    conn.commit()


def list_user_feeds(conn, kind=None):
    """사용자 추가 피드 목록 [(pk, site_name, feed_url, lang_code, feed_kind, enabled)]."""
    if kind:
        return conn.execute("SELECT feed_id, site_name, feed_url, lang_code, feed_kind, enabled "
                            "FROM user_rss_feed WHERE feed_kind=? ORDER BY lang_code, site_name",
                            (kind,)).fetchall()
    return conn.execute("SELECT feed_id, site_name, feed_url, lang_code, feed_kind, enabled "
                        "FROM user_rss_feed ORDER BY feed_kind, lang_code, site_name").fetchall()


def _site_from_url(url):
    from urllib.parse import urlsplit
    try:
        return urlsplit(url).netloc.replace('www.', '') or url[:40]
    except Exception:
        return url[:40]


# ── 자동 동기화 throttle (앱 실행마다 재수집 방지) ───────────────────

def should_auto_sync(conn, key, min_hours=6):
    """마지막 자동 동기화 후 min_hours 안 지났으면 False(네트워크 수집 생략, 캐시만).
       [새로고침] 같은 수동 동작은 이 검사 없이 강제 동기화한다.
       테스트용: user_config 'RSS_SYNC_MIN_HOURS' 가 있으면 그 값으로 단축(출시 전 그 행만 삭제→6h 복귀)."""
    try:
        ov = conn.execute("SELECT config_val FROM user_config WHERE config_key='RSS_SYNC_MIN_HOURS'").fetchone()
        if ov and ov[0]:
            min_hours = float(ov[0])
    except Exception:
        pass
    try:
        r = conn.execute("SELECT config_val FROM user_config WHERE config_key=?",
                         (f'AUTOSYNC_{key}',)).fetchone()
        if not r or not r[0]:
            return True
        from datetime import timedelta
        last = datetime.fromisoformat(r[0])
        return (datetime.now() - last) >= timedelta(hours=min_hours)
    except Exception:
        return True


def mark_auto_sync(conn, key):
    """자동 동기화 완료 시각 기록(throttle 기준)."""
    try:
        ts = datetime.now().isoformat(timespec='seconds')
        conn.execute("INSERT INTO user_config(config_key,config_val) VALUES(?,?) "
                     "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                     (f'AUTOSYNC_{key}', ts))
        conn.commit()
    except Exception:
        pass


# ── 서버 피드 주소록 동기화 (날짜 기준 증분, A→B 절체) ────────────────

def ensure_sync_tables(conn):
    """동기화 테이블을 **userdb(user_data.db)** 에 생성(멱등). 배포 DB(main=bible_master.db)는
    콘텐츠 교체 시 통째 대체되므로 user 데이터를 절대 두지 않는다(§1)."""
    conn.execute(
        "CREATE TABLE IF NOT EXISTS userdb.user_rss_registry ("
        " feed_url TEXT PRIMARY KEY, feed_id INTEGER, site_name TEXT, lang TEXT,"
        " feed_kind TEXT, record_status TEXT, updated_at TEXT)")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS userdb.user_rss_sync ("
        " file_name TEXT PRIMARY KEY, last_published_at TEXT, last_sync_at TEXT)")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS userdb.user_announcement ("
        " ann_id INTEGER NOT NULL, lang TEXT NOT NULL, title TEXT, body TEXT,"
        " published TEXT, pin INTEGER DEFAULT 0, audience TEXT DEFAULT 'ALL',"
        " PRIMARY KEY(ann_id, lang))")
    # 최신 콘텐츠 즐겨찾기 — 롤링 캐시(user_rss_cache)와 독립한 영구 스냅샷(90일 삭제 면제).
    conn.execute(
        "CREATE TABLE IF NOT EXISTS userdb.user_rss_favorite ("
        " url TEXT PRIMARY KEY, feed_kind TEXT, site_name TEXT, lang_code TEXT,"
        " title TEXT, published TEXT, added_at TEXT)")
    # 구 userdb 테이블에 audience 없으면 보강
    acols = [r[1] for r in conn.execute("PRAGMA userdb.table_info(user_announcement)").fetchall()]
    if acols and 'audience' not in acols:
        conn.execute("ALTER TABLE userdb.user_announcement ADD COLUMN audience TEXT DEFAULT 'ALL'")
    # user_rss_cache.collected_at (유튜브 수집순 정렬용 — 늦게 수집해도 최신처럼)
    try:
        ccols = [r[1] for r in conn.execute("PRAGMA userdb.table_info(user_rss_cache)").fetchall()]
        if ccols and 'collected_at' not in ccols:
            conn.execute("ALTER TABLE userdb.user_rss_cache ADD COLUMN collected_at TEXT")
    except Exception:
        pass
    # 구버전: 과거 prefix 없이 main(배포 DB)에 잘못 생성된 동기화 테이블 → userdb 로 1회 이전 후 main 드롭
    for t, cols in (('user_rss_registry', 'feed_url,feed_id,site_name,lang,feed_kind,record_status,updated_at'),
                    ('user_rss_sync', 'file_name,last_published_at,last_sync_at'),
                    ('user_announcement', 'ann_id,lang,title,body,published,pin')):
        if conn.execute("SELECT 1 FROM main.sqlite_master WHERE type='table' AND name=?", (t,)).fetchone():
            try:
                conn.execute(f"INSERT OR IGNORE INTO userdb.{t}({cols}) SELECT {cols} FROM main.{t}")
            except Exception:
                pass
            conn.execute(f"DROP TABLE main.{t}")
    conn.commit()


def _pick_manifest(servers, target_file):
    """모든 미러에서 manifest 를 받아 target_file 의 published_at 이 가장 최신인 (server, entry) 선택.
       CDN(jsDelivr) 브랜치 캐시가 stale 일 수 있어 '첫 응답 맹신'을 피하고 최신본을 선택한다."""
    import rss_registry as RR
    import rss_transport as RT
    best = None   # (published_at, server, entry)
    any_manifest = False
    for srv in (servers or []):
        if not srv.get('enabled', True):
            continue
        m = RT.make_transport(srv).get(RR.MANIFEST_FILE)
        if m is None:
            continue
        any_manifest = True
        man = {e['file']: e for e in RR.parse_manifest_tsv(m)}
        e = man.get(target_file)
        if not e:
            continue
        pub = e.get('published_at', '')
        if best is None or pub > best[0]:
            best = (pub, srv, e)
    if best:
        return best[1], best[2], any_manifest
    return None, None, any_manifest


def _download_verified(servers, name, sha1, prefer=None):
    """name 파일을 미러들에서 받아 sha1 일치본 반환(prefer 서버 우선). 불일치/실패 시 다음 미러."""
    import rss_registry as RR
    import rss_transport as RT
    order = ([prefer] if prefer else []) + [s for s in (servers or []) if s is not prefer]
    for srv in order:
        if not srv or not srv.get('enabled', True):
            continue
        t = RT.make_transport(srv).get(name)
        if t is None:
            continue
        if not sha1 or RR.sha1_text(t) == sha1:
            return t
    return None


def sync_registry(conn, servers, force=False):
    """서버에서 피드 주소록을 받아 user_rss_registry에 증분 적용.
       ① manifest 받기(enabled 서버 순서대로 A→B 절체) ② published_at 비교
       ③ 변경 시 feeds.tsv 받아 sha1 검증 후 멱등 적용(LIVE/HIDE upsert, DELETED 삭제)
       ④ last_published_at 갱신. → 결과 dict.
       사용자 접속 시점 불규칙 대응: 전체 스냅샷이라 공백 길어도 현재 진실로 수렴."""
    import rss_registry as RR
    ensure_sync_tables(conn)
    res = {'status': 'NO_SERVER', 'server': '', 'published_at': '',
           'applied': 0, 'deleted': 0, 'message': ''}
    used, fe, any_m = _pick_manifest(servers, RR.FEEDS_FILE)   # 최신 manifest 채택(stale 회피)
    if used is None:
        res['message'] = ('manifest에 feeds 없음' if any_m else '서버 접속 실패(A·B 모두)')
        res['status'] = 'NO_FEEDS' if any_m else 'NO_SERVER'
        return res
    res['server'] = used.get('label', '?')
    pub = fe.get('published_at', '')
    res['published_at'] = pub
    row = conn.execute("SELECT last_published_at FROM user_rss_sync WHERE file_name=?",
                       (RR.FEEDS_FILE,)).fetchone()
    last = row[0] if row else ''
    if not force and last and pub and pub <= last:
        res['status'] = 'UP_TO_DATE'; res['message'] = f'최신 (published {pub})'; return res
    # ★ 받을 이름은 **manifest 가 정한다**(내용 지문이 붙어 있다).
    #   옛 발행분이면 논리 이름으로 떨어진다(`RR.entry_path`).
    feeds_txt = _download_verified(servers, RR.entry_path(fe),
                                   fe.get('content_sha1'), prefer=used)
    if feeds_txt is None:
        res['status'] = 'CORRUPT'; res['message'] = 'feeds.tsv 다운로드/검증 실패'; return res
    # 멱등 적용
    applied = deleted = 0
    for r in RR.parse_feeds_tsv(feeds_txt):
        url = (r.get('feed_url') or '').strip()
        if not url:
            continue
        status = (r.get('record_status') or 'LIVE').upper()
        if status == 'DELETED':
            conn.execute("DELETE FROM user_rss_registry WHERE feed_url=?", (url,))
            deleted += 1
        else:
            conn.execute(
                "INSERT INTO user_rss_registry(feed_url, feed_id, site_name, lang, feed_kind, "
                " record_status, updated_at) VALUES(?,?,?,?,?,?,?) "
                "ON CONFLICT(feed_url) DO UPDATE SET feed_id=excluded.feed_id, "
                " site_name=excluded.site_name, lang=excluded.lang, feed_kind=excluded.feed_kind, "
                " record_status=excluded.record_status, updated_at=excluded.updated_at",
                (url, int(r.get('feed_id') or 0), r.get('site_name', ''), (r.get('lang') or 'EN').upper(),
                 r.get('feed_kind', 'DEVOTIONAL'), status, r.get('updated_at', '')))
            applied += 1
    now = datetime.now().isoformat(timespec='seconds')
    conn.execute(
        "INSERT INTO user_rss_sync(file_name, last_published_at, last_sync_at) VALUES(?,?,?) "
        "ON CONFLICT(file_name) DO UPDATE SET last_published_at=excluded.last_published_at, "
        " last_sync_at=excluded.last_sync_at", (RR.FEEDS_FILE, pub, now))
    conn.commit()
    res.update(status='UPDATED', applied=applied, deleted=deleted,
               message=f'적용 {applied} · 삭제 {deleted} (published {pub})')
    return res


def _pick_lang_file(servers, fname_for, ui):
    """언어별 파일 선택: 내 언어 파일 → 없으면 EN 폴백. (used, entry, any_m, fname) 반환."""
    fname = fname_for(ui)
    used, e, any_m = _pick_manifest(servers, fname)
    if used is None and ui != 'EN':
        fname = fname_for('EN')
        used, e, any_m = _pick_manifest(servers, fname)
    return used, e, any_m, fname


def sync_items(conn, servers, force=False, ui_lang=None):
    """방식 A(언어별 파일): 사용자 언어 items_<LANG>.tsv 수신 → user_rss_cache upsert.
       title = 그 언어 번역제목(서버 공식번역), lang_code = 원본 언어(필터·표시용).
       내 언어 파일 없으면 EN 폴백. manifest published_at 비교 + sha1 검증. → 결과 dict."""
    import rss_registry as RR
    ensure_sync_tables(conn)
    ui = (ui_lang or 'KO').upper()
    res = {'status': 'NO_SERVER', 'server': '', 'published_at': '', 'added': 0, 'message': ''}
    used, ie, any_m, fname = _pick_lang_file(servers, RR.items_lang_file, ui)
    if used is None:
        res['status'] = 'NO_ITEMS' if any_m else 'NO_SERVER'
        res['message'] = (f'서버에 항목 색인({fname}) 없음' if any_m else '서버 접속 실패(A·B 모두)'); return res
    res['server'] = used.get('label', '?')
    pub = ie.get('published_at', '')
    res['published_at'] = pub
    row = conn.execute("SELECT last_published_at FROM user_rss_sync WHERE file_name=?",
                       (fname,)).fetchone()
    last = row[0] if row else ''
    if not force and last and pub and pub <= last:
        res['status'] = 'UP_TO_DATE'; res['message'] = f'최신 (published {pub})'; return res
    items_txt = _download_verified(servers, RR.entry_path(ie),
                                   ie.get('content_sha1'), prefer=used)
    if items_txt is None:
        res['status'] = 'CORRUPT'; res['message'] = f'{fname} 다운로드/검증 실패'; return res
    now = datetime.now().isoformat(timespec='seconds')
    added = 0
    for r in RR.parse_items_tsv(items_txt):
        u = (r.get('item_url') or '').strip()
        if not u:
            continue
        # title=이미 ui 언어로 번역됨. 언어 변경 시 같은 url 의 title 을 새 언어로 갱신(upsert).
        # summary 는 라이브 fetch 가 채운 값을 보존(여기선 안 건드림).
        cur = conn.execute(
            "INSERT INTO user_rss_cache(url,feed_id,feed_kind,site_name,lang_code,"
            "title,summary,published,fetched_at,is_dead) VALUES(?,?,?,?,?,?,?,?,?,0) "
            "ON CONFLICT(url) DO UPDATE SET title=excluded.title, lang_code=excluded.lang_code, "
            " site_name=excluded.site_name, published=excluded.published, is_dead=0",
            (u, None, r.get('feed_kind', 'DEVOTIONAL'), r.get('site_name', ''),
             (r.get('lang') or 'EN').upper(), (r.get('title', '') or '')[:300],
             '', r.get('published', ''), now))
        added += 1 if cur.rowcount else 0
    conn.execute(
        "INSERT INTO user_rss_sync(file_name, last_published_at, last_sync_at) VALUES(?,?,?) "
        "ON CONFLICT(file_name) DO UPDATE SET last_published_at=excluded.last_published_at, "
        " last_sync_at=excluded.last_sync_at", (fname, pub, now))
    conn.execute(   # 현재 표시 언어 기록(언어 변경 감지 → 강제 재동기화 기준)
        "INSERT INTO user_config(config_key,config_val) VALUES('RSS_XL_LANG_ITEMS',?) "
        "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val", (ui,))
    conn.commit()
    res.update(status='UPDATED', added=added, message=f'신규 {added}건 (published {pub})')
    return res


def sync_youtube(conn, servers, force=False, ui_lang=None):
    """방식 A(언어별 파일): 사용자 언어 youtube_<LANG>.tsv 수신 → user_rss_cache(YOUTUBE) upsert.
       title = 그 언어 번역제목, lang_code = 원본 언어. 내 언어 파일 없으면 EN 폴백."""
    import rss_registry as RR
    ensure_sync_tables(conn)
    ui = (ui_lang or 'KO').upper()
    res = {'status': 'NO_SERVER', 'server': '', 'published_at': '', 'added': 0, 'message': ''}
    used, ye, any_m, fname = _pick_lang_file(servers, RR.youtube_lang_file, ui)
    if used is None:
        res['status'] = 'NO_YOUTUBE' if any_m else 'NO_SERVER'
        res['message'] = (f'서버에 유튜브 색인({fname}) 없음' if any_m else '서버 접속 실패(A·B 모두)'); return res
    res['server'] = used.get('label', '?')
    pub = ye.get('published_at', '')
    res['published_at'] = pub
    row = conn.execute("SELECT last_published_at FROM user_rss_sync WHERE file_name=?",
                       (fname,)).fetchone()
    last = row[0] if row else ''
    if not force and last and pub and pub <= last:
        res['status'] = 'UP_TO_DATE'; res['message'] = f'최신 (published {pub})'; return res
    yt_txt = _download_verified(servers, RR.entry_path(ye),
                                ye.get('content_sha1'), prefer=used)
    if yt_txt is None:
        res['status'] = 'CORRUPT'; res['message'] = f'{fname} 다운로드/검증 실패'; return res
    now = datetime.now().isoformat(timespec='seconds')
    added = 0
    for r in RR.parse_items_tsv(yt_txt):
        u = (r.get('item_url') or '').strip()
        if not u:
            continue
        cur = conn.execute(
            "INSERT INTO user_rss_cache(url,feed_id,feed_kind,site_name,lang_code,"
            "title,summary,published,fetched_at,is_dead,collected_at) VALUES(?,?,?,?,?,?,?,?,?,0,?) "
            "ON CONFLICT(url) DO UPDATE SET site_name=excluded.site_name, title=excluded.title, "
            "lang_code=excluded.lang_code, published=excluded.published, "
            "collected_at=excluded.collected_at, is_dead=0",
            (u, None, 'YOUTUBE', r.get('site_name', 'YouTube'),
             (r.get('lang') or 'EN').upper(), (r.get('title', '') or '')[:300],
             '', r.get('published', ''), now, r.get('collected', '')))
        added += 1 if cur.rowcount else 0
    conn.execute(
        "INSERT INTO user_rss_sync(file_name, last_published_at, last_sync_at) VALUES(?,?,?) "
        "ON CONFLICT(file_name) DO UPDATE SET last_published_at=excluded.last_published_at, "
        " last_sync_at=excluded.last_sync_at", (fname, pub, now))
    conn.execute(   # 유튜브 표시 언어 기록(언어 변경 감지)
        "INSERT INTO user_config(config_key,config_val) VALUES('RSS_XL_LANG_YT',?) "
        "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val", (ui,))
    conn.commit()
    res.update(status='UPDATED', added=added, message=f'신규 {added}건 (published {pub})')
    return res


def sync_announcements(conn, servers, force=False):
    """공지(announcements.json) 수신 → user_announcement 멱등 적용(upsert, DELETED 삭제).
       1차 콘텐츠라 본문 포함. manifest 절체 + published_at 비교 + sha1 검증."""
    import rss_registry as RR
    ensure_sync_tables(conn)
    res = {'status': 'NO_SERVER', 'server': '', 'published_at': '', 'applied': 0, 'deleted': 0, 'message': ''}
    used, ae, any_m = _pick_manifest(servers, RR.ANN_FILE)
    if used is None:
        res['status'] = 'NO_ANN' if any_m else 'NO_SERVER'
        res['message'] = ('서버에 공지 없음' if any_m else '서버 접속 실패'); return res
    res['server'] = used.get('label', '?')
    pub = ae.get('published_at', '')
    res['published_at'] = pub
    row = conn.execute("SELECT last_published_at FROM user_rss_sync WHERE file_name=?",
                       (RR.ANN_FILE,)).fetchone()
    last = row[0] if row else ''
    if not force and last and pub and pub <= last:
        res['status'] = 'UP_TO_DATE'; res['message'] = f'최신 (published {pub})'; return res
    txt = _download_verified(servers, RR.entry_path(ae),
                             ae.get('content_sha1'), prefer=used)
    if txt is None:
        res['status'] = 'CORRUPT'; res['message'] = 'announcements 다운로드/검증 실패'; return res
    applied = deleted = 0
    # ★★★ **파일이 정본이다**(2026-09-22 · 1.txt 10) — 파일에 없는 공지는
    #   **지운다.** 그래야 서버가 오래된 묘비를 걷어도 사용자 앱에 옛 공지가
    #   남지 않는다. 그전에는 「묘비를 본 적이 있는가」에 기대고 있어서
    #   묘비를 **영원히** 실어야 했다.
    #   ⚠ 받다가 깨지면 위에서 이미 `CORRUPT` 로 돌아갔다 — 여기까지 왔다는
    #     것은 파일이 온전하다는 뜻이다(안 그러면 통째로 지울 뻔했다).
    _seen = set()
    for r in RR.parse_announcements_json(txt):
        try:
            aid = int(r.get('ann_id'))
        except Exception:
            continue
        lang = (r.get('lang') or 'EN').upper()
        _seen.add((aid, lang))
        if (r.get('record_status') or 'LIVE').upper() == 'DELETED':
            conn.execute("DELETE FROM user_announcement WHERE ann_id=? AND lang=?", (aid, lang))
            deleted += 1
        else:
            conn.execute(
                "INSERT INTO user_announcement(ann_id,lang,title,body,published,pin,audience) VALUES(?,?,?,?,?,?,?) "
                "ON CONFLICT(ann_id,lang) DO UPDATE SET title=excluded.title, body=excluded.body, "
                " published=excluded.published, pin=excluded.pin, audience=excluded.audience",
                (aid, lang, r.get('title', ''), r.get('body', ''), r.get('published', ''),
                 int(r.get('pin') or 0), (r.get('audience') or 'ALL').upper()))
            applied += 1
    # ★ 파일에 없는 것은 걷는다 — 오래된 묘비가 파일에서 빠져도 안전하다
    # ⚠⚠ **빈 파일이면 안 걷는다** — 서버가 실수로 빈 것을 올렸을 때
    #   사용자 공지가 **통째로 사라지는** 것을 막는다(조용한 전멸 금지).
    for aid, lang in (conn.execute(
            'SELECT ann_id, lang FROM user_announcement').fetchall()
            if _seen else []):
        if (int(aid), (lang or '').upper()) not in _seen:
            conn.execute('DELETE FROM user_announcement WHERE ann_id=? '
                         'AND lang=?', (aid, lang))
            deleted += 1
    now = datetime.now().isoformat(timespec='seconds')
    conn.execute(
        "INSERT INTO user_rss_sync(file_name, last_published_at, last_sync_at) VALUES(?,?,?) "
        "ON CONFLICT(file_name) DO UPDATE SET last_published_at=excluded.last_published_at, "
        " last_sync_at=excluded.last_sync_at", (RR.ANN_FILE, pub, now))
    conn.commit()
    res.update(status='UPDATED', applied=applied, deleted=deleted,
               message=f'적용 {applied} · 삭제 {deleted}')
    return res


def sync_aimodels(conn, servers, force=False):
    """AI 모델 목록(ai_models.json) 수신 → `userdb.user_ai_model` 적용.

    ★★★ **왜 날마다 받나**(2026-09-29 299차-3) — 회사가 모델 판을 물리면 그 이름을
      쓰던 사용자는 **그 자리에서 HTTP 404** 다. 코어팩은 연 2회라 늦다.
    ⚠ 담는 표는 **개인 DB** 다 — `sys_ai_model` 에 쓰면 코어팩이 그 표를 통째로
      갈아 끼울 때 되돌아간다(`db_ai_models` 머리글).
    ⚠ **판 판정은 `db_ai_models.apply_payload` 한 문**이 한다 — 여기서 또 재면
      「받았다는데 안 바뀐다」가 난다.
    """
    import rss_registry as RR
    import db_ai_models as AM
    res = {'status': 'NO_SERVER', 'server': '', 'published_at': '', 'applied': 0,
           'version': 0, 'message': ''}
    used, ae, any_m = _pick_manifest(servers, RR.AIMODELS_FILE)
    if used is None:
        res['status'] = 'NO_MODELS' if any_m else 'NO_SERVER'
        res['message'] = ('서버에 모델 목록 없음' if any_m else '서버 접속 실패')
        return res
    res['server'] = used.get('label', '?')
    pub = ae.get('published_at', '')
    res['published_at'] = pub
    row = conn.execute("SELECT last_published_at FROM user_rss_sync WHERE file_name=?",
                       (RR.AIMODELS_FILE,)).fetchone()
    last = row[0] if row else ''
    if not force and last and pub and pub <= last:
        res['status'] = 'UP_TO_DATE'
        res['message'] = '최신 (published %s)' % pub
        res['version'] = AM.user_version(conn)
        return res
    txt = _download_verified(servers, RR.entry_path(ae), ae.get('content_sha1'), prefer=used)
    if txt is None:
        res['status'] = 'CORRUPT'
        res['message'] = 'ai_models 내려받기/검증 실패'
        return res
    parsed = RR.parse_aimodels_json(txt)
    got = AM.apply_payload(conn, parsed)
    res['version'] = got.get('version') or 0
    # ★ 317차 — 같은 꾸러미의 **필수 지침**을 담는다(판은 따로 잰다 — 모델 목록이
    #   그대로여도 지침만 바뀔 수 있다).
    g = {'applied': False}
    try:
        import db_ai_guard as GUARD
        if isinstance(parsed, dict) and parsed.get('guard'):
            g = GUARD.apply_payload(conn, parsed['guard'])
    except Exception:                                     # noqa: BLE001
        pass
    res['guard_applied'] = bool(g.get('applied'))
    # ⚠ 담지 않았어도 **받은 때는 적는다** — 같은 파일을 날마다 다시 내려받지 않게.
    #   판이 같거나 낮아서 안 담은 것은 고장이 아니다.
    now = datetime.now().isoformat(timespec='seconds')
    conn.execute(
        "INSERT INTO user_rss_sync(file_name, last_published_at, last_sync_at) VALUES(?,?,?) "
        "ON CONFLICT(file_name) DO UPDATE SET last_published_at=excluded.last_published_at, "
        " last_sync_at=excluded.last_sync_at", (RR.AIMODELS_FILE, pub, now))
    conn.commit()
    if got.get('applied') or g.get('applied'):
        res.update(status='UPDATED', applied=int(got.get('n') or 0),
                   message='회사 %d · 판 %d%s' % (int(got.get('n') or 0), res['version'],
                                                ' · 필수 지침 판 %s' % g.get('version')
                                                if g.get('applied') else ''))
    else:
        res.update(status='UP_TO_DATE', message=got.get('why') or '변경 없음')
    return res


def sync_app_channels(conn, servers, force=False):
    """앱이 받는 유튜브 채널 번호(app_channels.txt) → `userdb.user_app_channel`(통째로 갈아 끼운다 · 2026-10-24).
    ★ 「내가 모은 채널」이 이것과 겹치는 채널은 제 받기를 멈춘다(`my_channel.fetch`) — 관리자가 빼면 다음 날 이어 받는다.
    ⚠ 받지 못하면 지난 목록을 그대로 둔다."""
    import rss_registry as RR
    conn.execute('CREATE TABLE IF NOT EXISTS userdb.user_app_channel (channel_id TEXT PRIMARY KEY)')
    ensure_sync_tables(conn)
    res = {'status': 'NO_SERVER', 'n': 0, 'message': ''}
    used, e, any_m = _pick_manifest(servers, RR.APP_CHANNELS_FILE)
    if used is None:
        res['status'] = 'NO_FILE' if any_m else 'NO_SERVER'
        return res
    pub = e.get('published_at', '')
    row = conn.execute("SELECT last_published_at FROM user_rss_sync WHERE file_name=?",
                       (RR.APP_CHANNELS_FILE,)).fetchone()
    if not force and row and row[0] and pub and pub <= row[0]:
        res['status'] = 'UP_TO_DATE'
        return res
    txt = _download_verified(servers, RR.entry_path(e), e.get('content_sha1'), prefer=used)
    if txt is None:
        res['status'] = 'CORRUPT'
        return res
    ids = RR.parse_app_channels_txt(txt)
    conn.execute('DELETE FROM userdb.user_app_channel')
    conn.executemany('INSERT OR IGNORE INTO userdb.user_app_channel(channel_id) VALUES(?)', [(i,) for i in ids])
    now = datetime.now().isoformat(timespec='seconds')
    conn.execute(
        "INSERT INTO user_rss_sync(file_name, last_published_at, last_sync_at) VALUES(?,?,?) "
        "ON CONFLICT(file_name) DO UPDATE SET last_published_at=excluded.last_published_at, "
        " last_sync_at=excluded.last_sync_at", (RR.APP_CHANNELS_FILE, pub, now))
    conn.commit()
    res.update(status='UPDATED', n=len(ids), message='앱 채널 %d' % len(ids))
    return res


def sync_shop(conn, servers, force=False, images=True):
    """추천몰(shop.json) 수신 → `userdb.user_shop_feed` + 썸네일 캐시(2026-10-23).

    ⚠ 판 판정은 `db_shop.apply_payload` 한 문 · 받은 때는 담지 않았어도 적는다.
    ⚠ 그림은 지문 이름이라 받은 뒤 확인한다 — 빠진 것만 받는다.
    """
    import rss_registry as RR
    import db_shop as SH
    res = {'status': 'NO_SERVER', 'server': '', 'published_at': '', 'applied': 0,
           'version': 0, 'images': 0, 'message': ''}
    used, ae, any_m = _pick_manifest(servers, RR.SHOP_FILE)
    if used is None:
        res['status'] = 'NO_SHOP' if any_m else 'NO_SERVER'
        res['message'] = ('서버에 추천몰 없음' if any_m else '서버 접속 실패')
        return res
    res['server'] = used.get('label', '?')
    pub = ae.get('published_at', '')
    res['published_at'] = pub
    ensure_sync_tables(conn)
    row = conn.execute("SELECT last_published_at FROM user_rss_sync WHERE file_name=?",
                       (RR.SHOP_FILE,)).fetchone()
    last = row[0] if row else ''
    if not force and last and pub and pub <= last:
        res['status'] = 'UP_TO_DATE'
        res['message'] = '최신 (published %s)' % pub
        res['version'] = SH.user_version(conn)
        if images:
            try:
                res['images'] = SH.fetch_images(SH.catalog(conn), servers)
            except Exception:                              # noqa: BLE001
                pass
        return res
    txt = _download_verified(servers, RR.entry_path(ae), ae.get('content_sha1'), prefer=used)
    if txt is None:
        res['status'] = 'CORRUPT'
        res['message'] = 'shop 내려받기/검증 실패'
        return res
    parsed = SH.parse_json(txt)
    got = SH.apply_payload(conn, parsed)
    res['version'] = got.get('version') or 0
    if images:
        try:
            res['images'] = SH.fetch_images(parsed, servers)
        except Exception:                                  # noqa: BLE001
            pass
    now = datetime.now().isoformat(timespec='seconds')
    conn.execute(
        "INSERT INTO user_rss_sync(file_name, last_published_at, last_sync_at) VALUES(?,?,?) "
        "ON CONFLICT(file_name) DO UPDATE SET last_published_at=excluded.last_published_at, "
        " last_sync_at=excluded.last_sync_at", (RR.SHOP_FILE, pub, now))
    conn.commit()
    if got.get('applied'):
        res.update(status='UPDATED', applied=len(parsed.get('items') or []),
                   message='상품 %d · 판 %d' % (len(parsed.get('items') or []), res['version']))
    else:
        res.update(status='UP_TO_DATE', message=got.get('why') or '변경 없음')
    return res


def announcement_items(conn, lang='KO'):
    """표시용 공지 목록 — audience + 언어 정책 적용. ann_id별 1건. pin·최신 우선.
       audience='ALL'  : 사용자 lang 있으면 그것, 없으면 EN 폴백, 둘 다 없으면 비노출
                         (한국 사용자에게 번역 안 된 외국어 원문 노출 방지)
       audience=특정언어: 그 언어 사용자에게만 그 언어로 노출(언어권 전용 공지)"""
    ensure_sync_tables(conn)
    lang = (lang or 'KO').upper()
    by_ann = {}  # ann_id -> {lang: row, 'audience':..}
    for aid, lg, title, body, pub, pin, aud in conn.execute(
            "SELECT ann_id, lang, title, body, published, COALESCE(pin,0), COALESCE(audience,'ALL') "
            "FROM user_announcement"):
        d = by_ann.setdefault(aid, {'audience': (aud or 'ALL').upper(), 'langs': {}})
        d['audience'] = (aud or 'ALL').upper()
        d['langs'][lg] = {'ann_id': aid, 'lang': lg, 'title': title, 'body': body,
                          'published': pub or '', 'pin': int(pin or 0)}
    items = []
    for aid, d in by_ann.items():
        aud = d['audience']
        langs = d['langs']
        if aud != 'ALL':
            # 언어권 전용 — 그 언어 사용자에게만
            if lang == aud and aud in langs:
                items.append(langs[aud])
        else:
            # 전체 대상 — 사용자 언어 → EN 폴백 → (없으면 비노출)
            chosen = langs.get(lang) or langs.get('EN')
            if chosen:
                items.append(chosen)
    items.sort(key=lambda r: (r['pin'], r['published']), reverse=True)  # 고정 먼저, 최신 먼저
    return items


def get_announce_last_seen(conn):
    r = conn.execute("SELECT config_val FROM user_config WHERE config_key='ANNOUNCE_LAST_SEEN'").fetchone()
    return r[0] if r else ''


def set_announce_last_seen(conn, ts=None):
    ts = ts or datetime.now().isoformat(timespec='seconds')
    conn.execute("INSERT INTO user_config(config_key,config_val) VALUES('ANNOUNCE_LAST_SEEN',?) "
                 "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val", (ts,))
    conn.commit()
    return ts


def unread_announcements(conn, lang='KO'):
    """마지막 열람 이후 게시된, '사용자에게 실제 보이는' 공지 수(audience/lang 필터 반영)."""
    last = get_announce_last_seen(conn)
    n = 0
    for it in announcement_items(conn, lang):
        if it.get('published') and (not last or it['published'] > last):
            n += 1
    return n


# ── 죽은 URL 정리 (사용자 앱 관리기능) ───────────────────────────────

def _url_alive(url, timeout=8):
    """'alive' | 'dead' | 'unknown'. 보수적 — 404/410·DNS·연결거부만 dead,
       403/타임아웃 등 모호한 경우는 unknown(삭제 안 함, 봇차단 오판 방지)."""
    import socket
    from urllib.error import HTTPError, URLError
    for method in ('HEAD', 'GET'):
        try:
            req = Request(url, method=method, headers={'User-Agent': _UA})
            with urlopen(req, timeout=timeout) as r:
                return 'alive' if getattr(r, 'status', 200) < 400 else 'unknown'
        except HTTPError as e:
            if e.code in (404, 410):
                return 'dead'
            if method == 'GET':
                return 'unknown'      # 403/5xx 등 → 모호
        except (socket.timeout, TimeoutError):
            return 'unknown'
        except URLError as e:
            reason = str(getattr(e, 'reason', '')).lower()
            if any(k in reason for k in ('name or service', 'getaddrinfo', 'refused', 'no address')):
                return 'dead'
            if method == 'GET':
                return 'unknown'
        except Exception:
            if method == 'GET':
                return 'unknown'
    return 'unknown'


def check_dead_items(conn, kind=None, limit=50, log=None):
    """캐시 항목 URL을 오래된 점검순으로 N개 확인 → 죽은 것 is_dead=1.
       (점검수, 죽은수) 반환. last_checked 갱신으로 매 실행 다음 N개 진행."""
    ensure_sync_tables(conn)
    _ensure_cache_checked_col(conn)
    kc = " AND feed_kind=?" if kind else ""
    ka = (kind,) if kind else ()
    rows = conn.execute(
        f"SELECT url FROM user_rss_cache WHERE COALESCE(is_dead,0)=0{kc} "
        f"ORDER BY COALESCE(last_checked,'') ASC LIMIT ?", (*ka, int(limit))).fetchall()
    now = datetime.now().isoformat(timespec='seconds')
    checked = dead = 0
    for (u,) in rows:
        checked += 1
        st = _url_alive(u)
        if st == 'dead':
            conn.execute("UPDATE user_rss_cache SET is_dead=1, last_checked=? WHERE url=?", (now, u))
            dead += 1
            if log:
                log(f"  dead: {u[:60]}\n")
        else:
            conn.execute("UPDATE user_rss_cache SET last_checked=? WHERE url=?", (now, u))
    conn.commit()
    return checked, dead


def purge_dead(conn, kind=None):
    """is_dead=1 캐시 행 물리삭제. 삭제 건수 반환."""
    kc = " AND feed_kind=?" if kind else ""
    ka = (kind,) if kind else ()
    n = conn.execute(f"DELETE FROM user_rss_cache WHERE is_dead=1{kc}", ka).rowcount
    conn.commit()
    return n


def check_dead_feeds(conn, kind=None, log=None):
    """사용자 추가 피드(user_rss_feed)만 점검 — fetch 실패 시 dead 목록 반환
       [(pk, site_name, feed_url)]. (서버 레지스트리·sys 피드는 서버가 묘비 관리 → 손대지 않음.)
       실제 삭제는 호출측이 remove_user_feed 로(사용자 확인)."""
    kc = " WHERE feed_kind=?" if kind else ""
    ka = (kind,) if kind else ()
    dead = []
    for pk, name, url, lang, fk, en in conn.execute(
            f"SELECT feed_id, site_name, feed_url, lang_code, feed_kind, enabled "
            f"FROM user_rss_feed{kc}", ka).fetchall():
        try:
            items = parse_feed(url, 1)
            ok = bool(items)
        except Exception:
            ok = False
        if not ok:
            # fetch 실패 = 삭제 후보(사용자 확인 후 remove_user_feed). 일시적 실패 가능성 있어 자동삭제 안 함
            dead.append((pk, name, url))
            if log:
                log(f"  dead feed: {name} - {url[:50]}\n")
    return dead


def _ensure_cache_checked_col(conn):
    cols = [r[1] for r in conn.execute("PRAGMA userdb.table_info(user_rss_cache)").fetchall()]
    if 'last_checked' not in cols:
        conn.execute("ALTER TABLE user_rss_cache ADD COLUMN last_checked TEXT")
        conn.commit()


def fetch_live(conn, kind, exclude_ids=None, langs=None, per_feed=15, log=None, user_only=False):
    """비제외 피드를 실시간 fetch → user_rss_cache에 누적(upsert). (신규수, 실패수) 반환.
       user_only=True(방식 A): **사용자 추가 피드(음수 feed_id)만** 긁는다 — 기본 피드는 관리자가
       번역해 배포(items_<lang>.tsv)하므로, 클라가 또 긁어 번역제목을 원문으로 덮어쓰는 것을 방지."""
    now = datetime.now().isoformat(timespec='seconds')
    new = fail = 0
    for fid, name, url, lang in list_feeds(conn, kind, exclude_ids, langs):
        if user_only and fid is not None and fid >= 0:
            continue   # 기본 피드(양수 id)는 건너뜀 — 관리자 번역 배포본만 사용
        try:
            items = parse_feed(url, per_feed)
        except Exception as e:
            fail += 1
            if log:
                log(f"  [{name}] 실패: {str(e)[:50]}\n")
            continue
        for it in items:
            u = it.get('url')
            if not u:
                continue
            exists = conn.execute("SELECT 1 FROM user_rss_cache WHERE url=?", (u,)).fetchone()
            conn.execute(
                "INSERT INTO user_rss_cache(url,feed_id,feed_kind,site_name,lang_code,title,summary,published,fetched_at,is_dead) "
                "VALUES(?,?,?,?,?,?,?,?,?,0) "
                "ON CONFLICT(url) DO UPDATE SET title=excluded.title, summary=excluded.summary, "
                "published=excluded.published, is_dead=0",
                (u, fid, kind, name, lang, it.get('title', '')[:300],
                 it.get('summary', '')[:400], it.get('published', ''), now))
            if not exists:
                new += 1
        conn.commit()   # 피드 단위 커밋 — 트랜잭션 락을 길게 잡지 않음(관리자앱과 동시 사용 시 잠금 방지)
    return new, fail


def sync_baseline(conn, kind, exclude_ids=None):
    """DB 베이스라인(sys_ref_asset, 관리자 수집·배포)을 user_rss_cache에 흡수(INSERT OR IGNORE).
       → 표시·번역이 캐시 한 곳으로 통일(라이브 항목은 덮어쓰지 않음). 로컬 작업."""
    now = datetime.now().isoformat(timespec='seconds')
    rows = conn.execute(
        "SELECT a.url, s.feed_id, s.site_name, a.lang_code, a.title, a.summary, a.collected_at "
        "FROM sys_ref_asset a JOIN sys_rss_feed s ON s.feed_id=a.site_id "
        "WHERE a.record_status='LIVE' AND s.feed_kind=? AND a.url IS NOT NULL", (kind,)).fetchall()
    ex = set(exclude_ids or [])
    for url, fid, site, lang, title, summ, coll in rows:
        if fid in ex:
            continue
        conn.execute(
            "INSERT OR IGNORE INTO user_rss_cache(url,feed_id,feed_kind,site_name,lang_code,"
            "title,summary,published,fetched_at,is_dead) VALUES(?,?,?,?,?,?,?,?,?,0)",
            (url, fid, kind, site, lang or 'EN', title or '', (summ or '')[:400],
             coll or '', now))
    conn.commit()


def reading_items(conn, kind, exclude_ids=None, langs=None, limit=200,
                  exclude_channels=None, fav_channels=None):
    """표시용 목록 = user_rss_cache(라이브 누적 + 흡수된 베이스라인) 단일 소스.
       정렬: 유튜브=수집순(collected_at, 늦게 수집해도 최신처럼) / 나머지=published. 둘 다 최신 우선.
       exclude_channels: 표시 제외 채널명(site_name) set. fav_channels: 위로 끌어올릴 채널명 set.
       [{title,url,site,lang,published,collected,title_xl,xl_lang}]."""
    ex = set(exclude_ids or [])
    exch = set(exclude_channels or [])
    favch = set(fav_channels or [])
    is_yt = (kind == 'YOUTUBE')
    out = []
    for url, fid, site, lang, title, pub, txl, xll, coll in conn.execute(
            "SELECT url, feed_id, site_name, lang_code, title, published, title_xl, xl_lang, "
            "COALESCE(collected_at,'') FROM user_rss_cache "
            "WHERE feed_kind=? AND COALESCE(is_dead,0)=0", (kind,)):
        if fid in ex:
            continue
        if langs and (lang or 'EN') not in langs:
            continue
        site = site or ''
        if site in exch:
            continue
        out.append({'title': title or '(제목없음)', 'url': url, 'site': site,
                    'lang': lang or 'EN', 'published': pub or '', 'collected': coll or '',
                    'title_xl': txl or '', 'xl_lang': xll or ''})
    # 날짜 역순 정렬 후, 안정 정렬로 즐겨찾기 채널을 위로(Python sort 안정성 이용)
    out.sort(key=lambda x: (x['collected'] or x['published']) if is_yt else x['published'],
             reverse=True)
    if favch:
        out.sort(key=lambda x: 0 if x['site'] in favch else 1)
    return out[:limit]


def translate_url(url, target_lang):
    """구글 번역 페이지 프록시 URL (현행 .translate.goog 형식).
       구형 translate.google.com/translate?u= 는 폐지(지역 차단)되어 사용 불가.
       host 변환: 라벨의 '-'→'--', '.'→'-' 뒤 '.translate.goog' (예 www.a.org→www-a-org.translate.goog)."""
    from urllib.parse import urlsplit, urlunsplit
    tl = _iso_lang(target_lang)
    try:
        s = urlsplit(url)
        host = s.hostname or ''
        if not host:
            return url
        thost = host.replace('-', '--').replace('.', '-') + '.translate.goog'
        if s.port:
            thost += f':{s.port}'
        extra = f'_x_tr_sl=auto&_x_tr_tl={tl}&_x_tr_hl={tl}&_x_tr_pto=wapp'
        query = (s.query + '&' + extra) if s.query else extra
        return urlunsplit((s.scheme or 'https', thost, s.path or '/', query, s.fragment))
    except Exception:
        return url


def translate_text(text, target_lang):
    """무료 구글 번역 엔드포인트로 짧은 텍스트(제목) 번역. API키·의존성 없음.
       (비공식 — 과도 호출 시 차단 가능. 결과는 캐싱해 1회만 호출.)"""
    if not text or not text.strip():
        return text
    q = urlencode({'client': 'gtx', 'sl': 'auto', 'tl': _iso_lang(target_lang),
                   'dt': 't', 'q': text})
    req = Request('https://translate.googleapis.com/translate_a/single?' + q,
                  headers={'User-Agent': _UA})
    with urlopen(req, timeout=10) as r:
        data = json.loads(r.read().decode('utf-8'))
    return ''.join(seg[0] for seg in data[0] if seg and seg[0])


def translate_titles(conn, kind, lang, limit=80, log=None):
    """user_rss_cache의 미번역(현재 lang) 제목을 번역해 저장. (번역 건수) 반환.
       백그라운드 스레드에서 호출 권장(네트워크). 같은 lang은 1회만 번역(캐시)."""
    # 화면은 최신순으로 보이므로 번역도 최신(상단)부터 — 보이는 제목이 먼저 번역되게.
    rows = conn.execute(
        "SELECT url, title FROM user_rss_cache WHERE feed_kind=? AND COALESCE(is_dead,0)=0 "
        "AND title IS NOT NULL AND title<>'' AND (xl_lang IS NULL OR xl_lang<>?) "
        "ORDER BY COALESCE(published,'') DESC, COALESCE(collected_at,'') DESC LIMIT ?",
        (kind, lang, limit)).fetchall()
    n = 0
    for url, title in rows:
        try:
            xl = translate_text(title, lang)
        except Exception as e:
            if log:
                log(f"  번역 실패: {str(e)[:40]}\n")
            break   # 차단/네트워크 오류 시 중단 (다음 기회에 재시도)
        conn.execute("UPDATE user_rss_cache SET title_xl=?, xl_lang=? WHERE url=?", (xl, lang, url))
        n += 1
    if n:
        conn.commit()
    return n


def mark_dead(conn, url):
    conn.execute("UPDATE user_rss_cache SET is_dead=1 WHERE url=?", (url,))
    conn.commit()


def purge_cache(conn, kind=None, max_days=90, max_per_feed=300):
    """로컬 캐시를 '유한한 롤링 캐시'로 유지 — 영구 콘텐츠 DB화 방지(저작권 관점).
       ① published(없으면 fetched_at) 기준 max_days 초과분 삭제
       ② 피드별 최신 max_per_feed 건만 유지(초과분 삭제). (삭제 건수) 반환."""
    from datetime import timedelta
    deleted = 0
    cutoff = (datetime.now() - timedelta(days=max_days)).isoformat(timespec='seconds')
    kclause = " AND feed_kind=?" if kind else ""
    kargs = (kind,) if kind else ()
    # ① 기간 초과 (published 또는 fetched_at 둘 다 cutoff 이전)
    #   단, YOUTUBE는 서버 배포 큐레이션 — 옛 영상도 유효한 콘텐츠라 게시일 기준 삭제 안 함
    #   (실제 게시일 보강 후 옛 영상이 통째로 사라지던 버그 방지). 라이브 뉴스류만 롤링 삭제.
    if kind != 'YOUTUBE':
        yt_guard = '' if kind else " AND feed_kind<>'YOUTUBE'"
        deleted += conn.execute(
            f"DELETE FROM user_rss_cache WHERE COALESCE(NULLIF(published,''), fetched_at) < ?{kclause}{yt_guard}",
            (cutoff,) + kargs).rowcount
    # ② 피드별 상한
    for (fid,) in conn.execute(
            f"SELECT DISTINCT feed_id FROM user_rss_cache WHERE 1=1{kclause}", kargs).fetchall():
        deleted += conn.execute(
            "DELETE FROM user_rss_cache WHERE feed_id IS ? AND url NOT IN ("
            "  SELECT url FROM user_rss_cache WHERE feed_id IS ? "
            "  ORDER BY COALESCE(NULLIF(published,''), fetched_at) DESC LIMIT ?)",
            (fid, fid, max_per_feed)).rowcount
    conn.commit()
    return deleted


def clear_cache(conn, kind=None):
    """사용자 요청 시 로컬 캐시 비우기 (사적 복제 통제 강화). (삭제 건수) 반환."""
    if kind:
        n = conn.execute("DELETE FROM user_rss_cache WHERE feed_kind=?", (kind,)).rowcount
    else:
        n = conn.execute("DELETE FROM user_rss_cache").rowcount
    conn.commit()
    return n


# ── 최신 콘텐츠 즐겨찾기 (영구 스냅샷 — 롤링 삭제 면제) ─────────────────
def add_favorite(conn, item):
    """항목을 즐겨찾기. item dict(url, feed_kind/kind, site/site_name, lang/lang_code, title, published).
    롤링 캐시와 독립한 영구 테이블에 스냅샷 저장 → 90일 뒤 캐시에서 사라져도 유지."""
    ensure_sync_tables(conn)
    u = (item.get('url') or '').strip()
    if not u:
        return False
    now = datetime.now().isoformat(timespec='seconds')
    conn.execute(
        "INSERT INTO user_rss_favorite(url,feed_kind,site_name,lang_code,title,published,added_at) "
        "VALUES(?,?,?,?,?,?,?) ON CONFLICT(url) DO UPDATE SET title=excluded.title, "
        "site_name=excluded.site_name, feed_kind=excluded.feed_kind, lang_code=excluded.lang_code",
        (u, item.get('feed_kind') or item.get('kind') or '',
         item.get('site') or item.get('site_name') or '',
         (item.get('lang') or item.get('lang_code') or '').upper(),
         item.get('title') or '', item.get('published') or '', now))
    conn.commit()
    return True


def remove_favorite(conn, url):
    ensure_sync_tables(conn)
    conn.execute("DELETE FROM user_rss_favorite WHERE url=?", ((url or '').strip(),))
    conn.commit()


def is_favorite(conn, url):
    try:
        return conn.execute("SELECT 1 FROM user_rss_favorite WHERE url=?",
                            ((url or '').strip(),)).fetchone() is not None
    except Exception:
        return False


def favorite_urls(conn):
    """현재 즐겨찾기된 url set (목록 ★ 표시용)."""
    try:
        return {r[0] for r in conn.execute("SELECT url FROM user_rss_favorite")}
    except Exception:
        return set()


def list_favorites(conn, kind=None):
    """즐겨찾기 목록(최근 추가순). kind 주면 그 종류만. → reading_items 와 같은 dict 형태."""
    ensure_sync_tables(conn)
    q = ("SELECT url,feed_kind,site_name,lang_code,title,published,added_at "
         "FROM user_rss_favorite")
    args = ()
    if kind:
        q += " WHERE feed_kind=?"; args = (kind,)
    q += " ORDER BY added_at DESC"
    out = []
    for url, fk, site, lang, title, pub, added in conn.execute(q, args):
        out.append({'url': url, 'feed_kind': fk or '', 'site': site or '', 'lang': lang or '',
                    'title': title or '', 'published': pub or '', 'collected': '', 'added_at': added or ''})
    return out
