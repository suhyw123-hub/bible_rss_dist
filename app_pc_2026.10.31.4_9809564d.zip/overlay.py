# -*- coding: utf-8 -*-
"""덮개(overlay) 엔진 — 관리자 자산을 사용자가 고쳐 쓰는 **공통 로직 하나**.

★★★ 왜 엔진 하나인가 (2026-08-26 사용자 확정 「유지보수의 단순성」) —
  화면마다 만들면 반드시 갈라진다. 실증: 비교 편집이 일곱 벌로 갈라져 원문
  자물쇠가 전부 빠져 있었다(2-A). 덮개의 로직은 자산이 무엇이든 똑같다:
      읽기    user 있으면 user, 없으면 sys
      쓰기    user 에만 (NEW / EDIT / HIDE)
      되돌림  user 행을 지우면 sys 가 되살아난다
      나눔    무엇이 추가/수정/숨김인지 표시 (diff)

★★★ **판정 기준 — 「같은 정체성을 가리는가(덮개) / 새 정체성을 만드는가(파생)」**
  (2026-08-26 사용자 확인). 골라담기·파생 플랜은 **파생**이라 이 엔진과 무관 —
  sys 는 그대로 보이고 내 것이 추가될 뿐, 읽기 분기가 없다.

★★ 대상(사용자 확정): 1단계 구절연결+점수 → **2단계 설명문·렌즈·태그·엔티티**
  (이 판이 그것이다) → 마지막 매뉴얼 이관(검증 뒤 — 첫 적용 사례로 쓰지 않는다).
  제외 = 남의 글(원문·번역 — 위작 방지) · 묵상플랜(파생이 맡는다) ·
  사용자 자기 글(VERS_NOTE·BUNT_MEMO·내 렌즈 글 — 덮개가 아니라 자기 자산).

⚠⚠⚠ **자연 열쇠를 엔진이 강제한다.** sys 숫자 PK 는 배포마다 바뀐다
  (2026-08-25 이전에서 42,142개 **0% 보존** 실측). 어댑터는 반드시
  `key_of(row)` 로 자연 열쇠를 정의하고, 엔진은 **PK 로 짝짓지 않는다.**
  selftest 가 「sys 를 재적재해 PK 가 전부 바뀌어도 덮개가 살아남는가」를 잰다.

★★ **2단계의 자연 열쇠 표** (앵커가 흔들리는 것은 이름으로 못 박는다):
  | 어댑터 | 자연 열쇠 | 왜 |
  |---|---|---|
  | LinkOverlay | (link_type, clicked, target, rel, end) | 통합 유일 열쇠(§81) |
  | TextOverlay | (text_type, clicked_id, LANG, variant) | 절 vid·장 chap_key 는 **절체계 고정**이라 안전 |
  | LensTextOverlay | (text_type, **unit_name**, LANG, variant) | sys_unit_id 는 재적재로 바뀌고 **user 번호와 겹친다** — 렌즈 멱등 열쇠(이름, 전역 UNIQUE)를 그대로 쓴다 |
  | TagOverlay | ('P', tag_name_sid) / ('E', **entity_code**) | entity_id 는 PK — code 가 자연 열쇠 |
  | EntityOverlay | (entity_code,) | 〃 |

★★ **덮개 행의 표식 = `origin_key`** (2026-08-26 신설 칼럼 — user_text_asset ·
  user_tag_asset). user 표는 **자기 글(파생)과 덮개 글이 한 표에 산다** —
  내 렌즈의 NODE_DESC(clicked_id=user_unit_id)와 sys 렌즈를 고친 NODE_DESC
  (clicked_id=sys_unit_id)는 **번호가 겹쳐** 칼럼만으로 못 가른다(§46 이름
  충돌과 같은 계열). origin_key(자연 열쇠 문자열)가 있는 행만 덮개다 —
  없는 행(기존 노트·내 렌즈 글·내 태그 3행)은 덮개 엔진이 **아예 안 본다.**

★★ **HIDE 의 두 의미는 「sys 매칭 여부」로 저절로 갈린다** (스키마 실측):
  | user 행 | sys 에 같은 자연 열쇠가 | 뜻 |
  |---|---|---|
  | LIVE/EDIT | 있다 | **sys 를 내 버전으로 대체** (EDIT) |
  | HIDE      | 있다 | **sys 를 가린다** (덮개 숨김) |
  | LIVE      | 없다 | **내가 새로 만든 것** (NEW) |
  | HIDE      | 없다 | 내가 만든 것을 뗀 것 (기존 §10 의미 — 안 보임) |
"""
import sys


# ══════════════════════════════════════════════════════════════════
#  스키마 — 덮개가 요구하는 user 쪽 칼럼·표 (멱등)
# ══════════════════════════════════════════════════════════════════
def ensure_schema(conn):
    """user 쪽 덮개 칼럼·표를 만든다 — 몇 번 돌려도 같다.

    ⚠ 칼럼을 더한 표(user_text_asset·user_tag_asset)는 감사 트리거를
      다시 설치해야 한다(§10-1) — `db_audit_triggers.py` 재실행.
    """
    def _cols(tbl):
        try:
            return [r[1] for r in conn.execute(
                'PRAGMA userdb.table_info(%s)' % tbl)]
        except Exception:
            return []
    txt_cols = _cols('user_text_asset')
    if txt_cols and 'origin_key' not in txt_cols:
        conn.execute('ALTER TABLE userdb.user_text_asset ADD COLUMN origin_key TEXT')
    tag_cols = _cols('user_tag_asset')
    if tag_cols and 'tag_kind' not in tag_cols:
        conn.execute('ALTER TABLE userdb.user_tag_asset ADD COLUMN tag_kind TEXT')
    if tag_cols and 'origin_key' not in tag_cols:
        conn.execute('ALTER TABLE userdb.user_tag_asset ADD COLUMN origin_key TEXT')
    if not txt_cols or not tag_cols:
        # 조용히 건너뛰지 않는다 — 표가 없는 DB 는 붙일 자리도 없다는 뜻
        print('[overlay] ensure_schema: user_text/tag_asset 없음 — 그 표는 건너뜀')
    conn.execute(
        'CREATE TABLE IF NOT EXISTS userdb.user_entity_asset ('
        ' user_entity_id INTEGER PRIMARY KEY AUTOINCREMENT,'
        ' entity_code TEXT NOT NULL,'
        ' entity_type TEXT,'
        ' json_detail TEXT,'
        " record_status TEXT NOT NULL DEFAULT 'LIVE')")
    if txt_cols:
        conn.execute('CREATE INDEX IF NOT EXISTS userdb.idx_uta_origin_key '
                     'ON user_text_asset(origin_key)')
    if tag_cols:
        conn.execute('CREATE INDEX IF NOT EXISTS userdb.idx_utag_origin_key '
                     'ON user_tag_asset(origin_key)')
    conn.execute('CREATE INDEX IF NOT EXISTS userdb.idx_uent_code '
                 'ON user_entity_asset(entity_code)')
    conn.commit()


# ══════════════════════════════════════════════════════════════════
#  어댑터 — 자산마다 얇게. 표 이름 · 자연 열쇠 · 앵커 조회만 안다.
# ══════════════════════════════════════════════════════════════════
class Adapter(object):
    """자산 하나의 덮개 규칙.

    어댑터가 정의하는 것:
      SYS_TBL / USER_TBL       표 이름 (user 쪽은 userdb. 접두)
      COLS                     엔진이 user 표에 복사하는 칸
      key_of(row_dict)         **자연 열쇠** 튜플 — PK 금지
      sys_rows(conn, anchor)   앵커에 딸린 sys 행들 (LIVE 만)
      user_rows(conn, anchor)  같은 앵커의 **덮개** user 행들 (HIDE 포함)
      user_key_where(key)      user 표에서 이 열쇠를 찾는 (WHERE 조각, 인자)
      sys_has(conn, key)       sys 에 이 열쇠가 사는가 (EDIT/NEW 판정)
      prep_insert(row)         저장 직전 훅 — origin_key 채우기 등
    """
    SYS_TBL = USER_TBL = None
    COLS = ()

    def key_of(self, row):
        raise NotImplementedError

    def sys_rows(self, conn, anchor):
        raise NotImplementedError

    def user_rows(self, conn, anchor):
        raise NotImplementedError

    def user_key_where(self, key):
        raise NotImplementedError

    def sys_has(self, conn, key):
        raise NotImplementedError

    def prep_insert(self, row):
        pass


class LinkOverlay(Adapter):
    """구절연결(VERS_VERS) 덮개 — 1단계 첫 적용 사례.

    앵커 = verse_id (절체계 고정이라 배포에 안전 — §18-8).
    자연 열쇠 = (link_type, clicked_id, target_id, rel, end) —
    통합 때 세운 유일 열쇠(§81) 그대로. 실측 중복 0.
    """
    SYS_TBL = 'sys_link_asset'
    USER_TBL = 'userdb.user_link_asset'
    COLS = ('link_type', 'clicked_id', 'target_id', 'rel_code', 'end_id',
            'note', 'chain_code', 'sort_order')
    LT = 'VERS_VERS'

    def key_of(self, row):
        return (row.get('link_type'), row.get('clicked_id'),
                row.get('target_id'),
                row.get('rel_code') or '',
                row.get('end_id') or row.get('target_id'))

    def _rows(self, conn, tbl, anchor):
        cur = conn.execute(
            "SELECT %s, COALESCE(record_status,'LIVE') AS record_status "
            'FROM %s WHERE link_type=? AND (clicked_id=? OR target_id=?)'
            % (', '.join(self.COLS), tbl), (self.LT, anchor, anchor))
        names = [d[0] for d in cur.description]
        return [dict(zip(names, r)) for r in cur.fetchall()]

    def sys_rows(self, conn, anchor):
        return [r for r in self._rows(conn, self.SYS_TBL, anchor)
                if r['record_status'] == 'LIVE']

    def user_rows(self, conn, anchor):
        return self._rows(conn, self.USER_TBL, anchor)

    def user_key_where(self, key):
        return ('link_type=? AND clicked_id=? AND target_id=? '
                "AND COALESCE(rel_code,'')=? "
                'AND COALESCE(end_id, target_id)=?', list(key))

    def sys_has(self, conn, key):
        return any(self.key_of(s) == key
                   for s in self.sys_rows(conn, key[1]))


# ── 설명문 덮개 대상 — 앵커가 안정적인 유형만 이 어댑터를 쓴다 ──────────
#   VERS_* = verse_id(절체계 고정 §18-8) · CHAP_DESC = chap_key(§3-1 규칙값).
#   ⚠ PERI_DESC 는 pericope_id 가 sys PK 라 재적재 보존이 **증명되지 않았다**
#     — 앵커 안정성을 확인하기 전에는 목록에 넣지 않는다(13-46 정신:
#     짐작으로 열쇠를 세우지 않는다). 단락 설명 덮개는 그 확인 뒤에.
# ★★★ `BOOK_DESC` 를 더했다 (2026-08-30 사용자 지시 0.txt 1-2 「책 설명문은
#   표시하지 않으므로 수정할 수 없다 … 허용하면 문제가 있는가?」).
#   ⇒ **재 보니 가장 안전한 열쇠였다.** `clicked_id` 가 `bcode`(1~66) 정경
#     번호라 재적재로도 배포로도 안 바뀐다 — 지금 덮개가 쓰는 어떤 열쇠보다
#     안정적이다(실측 66권 전부·빈 값 0). 짐작으로 미뤄 두면 그대로 굳는다.
#   ⚠ 이 줄에 넣기 전까지 **`_ov_mark` 의 「책」 표식이 늘 꺼져 있었다** —
#     `text_override` 가 None 을 돌려주어 오류 없이 죽은 표식이었다.
TEXT_OVERLAY_TYPES = ('VERS_DESC', 'VERS_QUESTION', 'VERS_PRAYER',
                      'CHAP_DESC', 'BOOK_DESC')
# 렌즈 글 — 앵커가 sys_unit_id(불안정·user 번호와 겹침)라 **이름 열쇠** 전용
LENS_TEXT_TYPES = ('CONT_DESC', 'CONT_NAME', 'NODE_DESC', 'NODE_QUESTION',
                   'NODE_PRAYER', 'NODE_NAME')

# 주요용어 글 — 열쇠가 번호가 아니라 `entity_code` 다 (2026-08-26).
# ⚠ ENTITY_NAME 은 **일부러 뺐다** — 이름은 고치지 않고 별명으로 받는다
#   (사용자 확정. `entity_aliases` 가 그 자리다).
ENTITY_TEXT_TYPES = ('ENTITY_DESC',)

# ★★★ 단락 글 — 열쇠는 **`peri_code`** (2026-08-29 신설).
#   사용자 신고 「단락을 출발지로 지정했다. **단락 설명문을 표시하지도 못한다.
#   수정할 수도 없다.**」 — 위 `TEXT_OVERLAY_TYPES` 주석이 「pericope_id 가
#   sys PK 라 재적재 보존이 증명되지 않았다」며 미뤄 둔 자리였다.
#   ⇒ **재 보았다.** `peri_code` 는 3,413개 전부 고유하고 빈 값 0이며
#     내용에서 나온 코드다(`GEN_01_BODY_1`). `entity_code`·유닛 이름과 **같은
#     문법**이다 — 짐작이 아니라 실측으로 열쇠가 있음을 확인하고 연다.
#   ⚠ 제목(PERI_TITLE)은 넣지 않는다 — 그 값은 `title` 칸에 살고 검색·목록이
#     그것을 쓴다(엔티티 이름을 뺀 것과 같은 까닭).
PERI_TEXT_TYPES = ('PERI_DESC',)


class TextOverlay(Adapter):
    """설명문 덮개 — 앵커(clicked_id)가 배포에 안정적인 text_type 용.

    앵커 = clicked_id (절 vid · 장 chap_key). 언어·변형마다 행이 다르므로
    자연 열쇠에 둘 다 들어간다. **한 유형 = 한 인스턴스**(`TextOverlay('VERS_DESC')`).
    ⚠ user_rows 는 **origin_key 있는 행만** 본다 — 같은 표의 사용자 자기 글
      (VERS_NOTE 등은 유형이 달라 안 겹치지만, 원칙을 코드로 못 박는다).
    """
    SYS_TBL = 'sys_text_asset'
    USER_TBL = 'userdb.user_text_asset'
    COLS = ('text_type', 'clicked_id', 'target_id', 'title', 'contents',
            'lang_code', 'text_variant', 'origin_key')

    def __init__(self, text_type):
        self.TT = text_type

    def key_of(self, row):
        ok = row.get('origin_key')
        if ok:
            return tuple(ok.split('|'))
        return (row.get('text_type'), str(row.get('clicked_id')),
                (row.get('lang_code') or '').upper(),
                row.get('text_variant') or '')

    def _okey(self, key):
        return '|'.join(str(k) for k in key)

    def prep_insert(self, row):
        row['origin_key'] = self._okey(self.key_of(row))

    def sys_rows(self, conn, anchor):
        cur = conn.execute(
            'SELECT text_type, clicked_id, target_id, title, contents, '
            'lang_code, text_variant, '
            "COALESCE(record_status,'LIVE') AS record_status "
            'FROM %s WHERE text_type=? AND clicked_id=? '
            "AND COALESCE(record_status,'LIVE')='LIVE'"
            % self.SYS_TBL, (self.TT, anchor))
        names = [d[0] for d in cur.description]
        return [dict(zip(names, r)) for r in cur.fetchall()]

    def user_rows(self, conn, anchor):
        cur = conn.execute(
            'SELECT text_type, clicked_id, target_id, title, contents, '
            'lang_code, text_variant, origin_key, '
            "COALESCE(record_status,'LIVE') AS record_status "
            'FROM %s WHERE text_type=? AND clicked_id=? '
            'AND origin_key IS NOT NULL' % self.USER_TBL, (self.TT, anchor))
        names = [d[0] for d in cur.description]
        return [dict(zip(names, r)) for r in cur.fetchall()]

    def user_key_where(self, key):
        return ('origin_key=?', [self._okey(key)])

    def sys_has(self, conn, key):
        return conn.execute(
            'SELECT 1 FROM %s WHERE text_type=? AND clicked_id=? '
            'AND UPPER(lang_code)=? AND COALESCE(text_variant,\'\')=? '
            "AND COALESCE(record_status,'LIVE')='LIVE'" % self.SYS_TBL,
            (key[0], int(key[1]), key[2], key[3])).fetchone() is not None


class LensTextOverlay(TextOverlay):
    """렌즈 글 덮개 — 자연 열쇠가 번호가 아니라 **유닛 이름**이다.

    ⚠ sys_unit_id 는 ① 재적재로 바뀔 수 있고 ② user_unit_id 와 번호가
      겹친다(§46 이름 충돌 실측). 렌즈의 멱등 열쇠는 처음부터 이름이었다
      (`db_lens_load` — unit_name_sid 전역 UNIQUE). 덮개도 그것을 쓴다.
    앵커 = sys_unit_id (화면이 그렇게 부른다) — user_rows 가 이름으로
    바꿔 맞추므로 **재적재로 번호가 바뀌어도 덮개가 산다**(selftest).
    """

    def _unit_name(self, conn, unit_id):
        r = conn.execute(
            'SELECT unit_name_sid FROM sys_unit_asset WHERE sys_unit_id=?',
            (unit_id,)).fetchone()
        return r[0] if r else None

    def key_of(self, row):
        ok = row.get('origin_key')
        if ok:
            return tuple(ok.split('|'))
        return (row.get('text_type'), row.get('unit_name'),
                (row.get('lang_code') or '').upper(),
                row.get('text_variant') or '')

    def sys_rows(self, conn, anchor):
        cur = conn.execute(
            'SELECT t.text_type, t.clicked_id, t.target_id, t.title, '
            't.contents, t.lang_code, t.text_variant, u.unit_name_sid AS unit_name, '
            "COALESCE(t.record_status,'LIVE') AS record_status "
            'FROM %s t JOIN sys_unit_asset u ON u.sys_unit_id = t.clicked_id '
            'WHERE t.text_type=? AND t.clicked_id=? '
            "AND COALESCE(t.record_status,'LIVE')='LIVE'"
            % self.SYS_TBL, (self.TT, anchor))
        names = [d[0] for d in cur.description]
        return [dict(zip(names, r)) for r in cur.fetchall()]

    def user_rows(self, conn, anchor):
        """이름으로 맞춘다 — 번호(clicked_id)는 낡아 있을 수 있다."""
        name = self._unit_name(conn, anchor)
        cur = conn.execute(
            'SELECT text_type, clicked_id, target_id, title, contents, '
            'lang_code, text_variant, origin_key, '
            "COALESCE(record_status,'LIVE') AS record_status "
            'FROM %s WHERE text_type=? AND origin_key IS NOT NULL'
            % self.USER_TBL, (self.TT,))
        names = [d[0] for d in cur.description]
        out = []
        for r in cur.fetchall():
            d = dict(zip(names, r))
            if name is not None and self.key_of(d)[1] == name:
                out.append(d)
        return out

    def sys_has(self, conn, key):
        return conn.execute(
            'SELECT 1 FROM %s t JOIN sys_unit_asset u '
            'ON u.sys_unit_id = t.clicked_id '
            'WHERE t.text_type=? AND u.unit_name_sid=? '
            'AND UPPER(t.lang_code)=? AND COALESCE(t.text_variant,\'\')=? '
            "AND COALESCE(t.record_status,'LIVE')='LIVE'" % self.SYS_TBL,
            (key[0], key[1], key[2], key[3])).fetchone() is not None


class EntityTextOverlay(TextOverlay):
    """주요용어 글 덮개 — 자연 열쇠가 번호가 아니라 **`entity_code`** 다.

    ★ 2026-08-26 신설 (사용자 승인 「설명 탭: 사용자가 수정 가능하도록 한다」).
      8단계에서 이 유형을 뺀 이유가 「앵커(entity_id)가 PK 라 미확증」이었는데,
      엔티티에는 `entity_code`(P_DAVID)라는 자연 열쇠가 처음부터 있고
      `EntityOverlay`(가림)가 이미 그것을 쓴다. `LensTextOverlay` 가 유닛
      번호 대신 이름을 쓰는 것과 **같은 문법**이다.
    앵커 = entity_id (화면이 그렇게 부른다) — user_rows 가 code 로 맞춘다.

    ⚠ **이름(ENTITY_NAME)은 이 덮개에 넣지 않는다** (사용자 확정
      「이름 고치지 말고 별명을 추가하는 방식으로」). 이름을 고치면 그 이름을
      쓰는 태그·연결·검색이 전부 따라가야 한다. 별명은 `entity_aliases` 가
      이미 맡고 있고 검색이 곧바로 걸린다.
    """

    def _code(self, conn, entity_id):
        r = conn.execute('SELECT entity_code FROM sys_entity_master '
                         'WHERE entity_id=?', (entity_id,)).fetchone()
        return r[0] if r else None

    def key_of(self, row):
        ok = row.get('origin_key')
        if ok:
            return tuple(ok.split('|'))
        return (row.get('text_type'), row.get('entity_code'),
                (row.get('lang_code') or '').upper(),
                row.get('text_variant') or '')

    def sys_rows(self, conn, anchor):
        cur = conn.execute(
            'SELECT t.text_type, t.clicked_id, t.target_id, t.title, '
            't.contents, t.lang_code, t.text_variant, em.entity_code, '
            "COALESCE(t.record_status,'LIVE') AS record_status "
            'FROM %s t JOIN sys_entity_master em ON em.entity_id = t.clicked_id '
            'WHERE t.text_type=? AND t.clicked_id=? '
            "AND COALESCE(t.record_status,'LIVE')='LIVE'"
            % self.SYS_TBL, (self.TT, anchor))
        names = [d[0] for d in cur.description]
        return [dict(zip(names, r)) for r in cur.fetchall()]

    def user_rows(self, conn, anchor):
        """code 로 맞춘다 — 번호(clicked_id)는 낡아 있을 수 있다."""
        code = self._code(conn, anchor)
        cur = conn.execute(
            'SELECT text_type, clicked_id, target_id, title, contents, '
            'lang_code, text_variant, origin_key, '
            "COALESCE(record_status,'LIVE') AS record_status "
            'FROM %s WHERE text_type=? AND origin_key IS NOT NULL'
            % self.USER_TBL, (self.TT,))
        names = [d[0] for d in cur.description]
        out = []
        for r in cur.fetchall():
            d = dict(zip(names, r))
            if code is not None and self.key_of(d)[1] == code:
                out.append(d)
        return out

    def sys_has(self, conn, key):
        return conn.execute(
            'SELECT 1 FROM %s t JOIN sys_entity_master em '
            'ON em.entity_id = t.clicked_id '
            'WHERE t.text_type=? AND em.entity_code=? '
            'AND UPPER(t.lang_code)=? AND COALESCE(t.text_variant,\'\')=? '
            "AND COALESCE(t.record_status,'LIVE')='LIVE'" % self.SYS_TBL,
            (key[0], key[1], key[2], key[3])).fetchone() is not None


class PeriTextOverlay(TextOverlay):
    """단락 설명문 덮개 — 자연 열쇠가 번호가 아니라 **`peri_code`** 다.

    `EntityTextOverlay` 와 **같은 문법**이다(번호 대신 코드로 짝짓는다).
    앵커 = pericope_id (화면이 그렇게 부른다) — user_rows 가 code 로 맞춘다.
    """

    def _code(self, conn, pid):
        r = conn.execute('SELECT peri_code FROM sys_pericope_asset '
                         'WHERE pericope_id=?', (pid,)).fetchone()
        return r[0] if r else None

    def key_of(self, row):
        ok = row.get('origin_key')
        if ok:
            return tuple(ok.split('|'))
        return (row.get('text_type'), row.get('peri_code'),
                (row.get('lang_code') or '').upper(),
                row.get('text_variant') or '')

    def sys_rows(self, conn, anchor):
        cur = conn.execute(
            'SELECT t.text_type, t.clicked_id, t.target_id, t.title, '
            't.contents, t.lang_code, t.text_variant, pa.peri_code, '
            "COALESCE(t.record_status,'LIVE') AS record_status "
            'FROM %s t JOIN sys_pericope_asset pa '
            '  ON pa.pericope_id = t.clicked_id '
            'WHERE t.text_type=? AND t.clicked_id=? '
            "AND COALESCE(t.record_status,'LIVE')='LIVE'"
            % self.SYS_TBL, (self.TT, anchor))
        names = [d[0] for d in cur.description]
        return [dict(zip(names, r)) for r in cur.fetchall()]

    def user_rows(self, conn, anchor):
        code = self._code(conn, anchor)
        cur = conn.execute(
            'SELECT text_type, clicked_id, target_id, title, contents, '
            'lang_code, text_variant, origin_key, '
            "COALESCE(record_status,'LIVE') AS record_status "
            'FROM %s WHERE text_type=? AND origin_key IS NOT NULL'
            % self.USER_TBL, (self.TT,))
        names = [d[0] for d in cur.description]
        out = []
        for r in cur.fetchall():
            d = dict(zip(names, r))
            if code is not None and self.key_of(d)[1] == code:
                out.append(d)
        return out

    def sys_has(self, conn, key):
        return conn.execute(
            'SELECT 1 FROM %s t JOIN sys_pericope_asset pa '
            'ON pa.pericope_id = t.clicked_id '
            'WHERE t.text_type=? AND pa.peri_code=? '
            "AND UPPER(t.lang_code)=? AND COALESCE(t.text_variant,'')=? "
            "AND COALESCE(t.record_status,'LIVE')='LIVE'" % self.SYS_TBL,
            (key[0], key[1], key[2], key[3])).fetchone() is not None


class TagOverlay(Adapter):
    """태그 덮개 — 이름 수정(EDIT)·숨김(HIDE)·추가(NEW).

    자연 열쇠: PLAIN = ('P', tag_name_sid) / ENTITY = ('E', entity_code).
    ⚠ entity_id 는 sys PK 라 못 쓴다 — sys_rows 가 entity_code 를 조인해 온다.
    ⚠ user_tag_asset 의 **origin_key 없는 행(내 태그 3행)은 덮개가 아니다** —
      그것은 파생(자기 것)이고 tag_picker 흐름이 그대로 맡는다.
    ⚠ 이름 수정의 결과는 user 행의 tag_name_sid 에 **글자 그대로** 담는다
      (user 태그가 이미 그 문법이다 — '사랑'·'비난' 실측).
    앵커 = None(전체) 또는 tag_category.
    ⚠ DICT 태그는 아직 0행이라 열쇠를 정하지 않았다 — 생기면 자료집·글 제목
      자연 열쇠로 더한다(짐작으로 dict_ref PK 를 쓰지 않는다).
    """
    SYS_TBL = 'sys_tag_asset'
    USER_TBL = 'userdb.user_tag_asset'
    COLS = ('tag_name_sid', 'tag_category', 'tag_kind', 'origin_key')

    def key_of(self, row):
        ok = row.get('origin_key')
        if ok:
            return tuple(ok.split('|'))
        if (row.get('tag_kind') or 'PLAIN') == 'ENTITY':
            return ('E', row.get('entity_code'))
        return ('P', row.get('tag_name_sid'))

    def prep_insert(self, row):
        row['origin_key'] = '|'.join(str(k) for k in self.key_of(row))

    def sys_rows(self, conn, anchor=None):
        w, p = '', []
        if anchor:
            w, p = ' AND t.tag_category=?', [anchor]
        cur = conn.execute(
            'SELECT t.tag_name_sid, t.tag_category, t.tag_kind, t.dict_ref, '
            'e.entity_code, '
            "COALESCE(t.record_status,'LIVE') AS record_status "
            'FROM %s t LEFT JOIN sys_entity_master e '
            'ON e.entity_id = t.entity_id '
            "WHERE COALESCE(t.record_status,'LIVE')='LIVE' "
            "AND COALESCE(t.tag_kind,'PLAIN') != 'DICT'" % self.SYS_TBL + w, p)
        names = [d[0] for d in cur.description]
        return [dict(zip(names, r)) for r in cur.fetchall()]

    def user_rows(self, conn, anchor=None):
        w, p = '', []
        if anchor:
            w, p = ' AND tag_category=?', [anchor]
        cur = conn.execute(
            'SELECT tag_name_sid, tag_category, tag_kind, origin_key, '
            "COALESCE(record_status,'LIVE') AS record_status "
            'FROM %s WHERE origin_key IS NOT NULL' % self.USER_TBL + w, p)
        names = [d[0] for d in cur.description]
        return [dict(zip(names, r)) for r in cur.fetchall()]

    def user_key_where(self, key):
        return ('origin_key=?', ['|'.join(str(k) for k in key)])

    def sys_has(self, conn, key):
        if key[0] == 'E':
            return conn.execute(
                'SELECT 1 FROM %s t JOIN sys_entity_master e '
                'ON e.entity_id = t.entity_id '
                "WHERE e.entity_code=? AND COALESCE(t.record_status,'LIVE')='LIVE'"
                % self.SYS_TBL, (key[1],)).fetchone() is not None
        return conn.execute(
            'SELECT 1 FROM %s WHERE tag_name_sid=? '
            "AND COALESCE(record_status,'LIVE')='LIVE'" % self.SYS_TBL,
            (key[1],)).fetchone() is not None


class EntityOverlay(Adapter):
    """엔티티 덮개 — 주 용도는 **가림**(내 화면에서 이 용어를 숨긴다).

    자연 열쇠 = (entity_code,) — TEXT UNIQUE, 배포에 안전.
    user 표는 `ensure_schema` 가 만든다(user_entity_asset).
    이름·설명 수정은 이 어댑터가 아니라 **ENTITY_NAME/ENTITY_DESC 덮개**의
    몫인데, 그 앵커(entity_id)가 PK 라 지금은 목록에 안 넣었다 — 엔티티
    재적재 규칙이 정해지면(code 로 재해석) 그때 잇는다.
    앵커 = entity_code 하나 또는 None(전체).
    """
    SYS_TBL = 'sys_entity_master'
    USER_TBL = 'userdb.user_entity_asset'
    COLS = ('entity_code', 'entity_type', 'json_detail')

    def key_of(self, row):
        return (row.get('entity_code'),)

    def _rows(self, conn, tbl, anchor, live_only):
        w, p = '', []
        if anchor:
            w, p = ' AND entity_code=?', [anchor]
        cur = conn.execute(
            'SELECT entity_code, entity_type, json_detail, '
            "COALESCE(record_status,'LIVE') AS record_status FROM %s "
            'WHERE 1=1%s' % (tbl, w), p)
        names = [d[0] for d in cur.description]
        rows = [dict(zip(names, r)) for r in cur.fetchall()]
        if live_only:
            rows = [r for r in rows if r['record_status'] == 'LIVE']
        return rows

    def sys_rows(self, conn, anchor=None):
        return self._rows(conn, self.SYS_TBL, anchor, True)

    def user_rows(self, conn, anchor=None):
        return self._rows(conn, self.USER_TBL, anchor, False)

    def user_key_where(self, key):
        return ('entity_code=?', [key[0]])

    def sys_has(self, conn, key):
        return conn.execute(
            'SELECT 1 FROM %s WHERE entity_code=? '
            "AND COALESCE(record_status,'LIVE')='LIVE'" % self.SYS_TBL,
            (key[0],)).fetchone() is not None


# ══════════════════════════════════════════════════════════════════
#  읽기 배선용 얇은 조회 — 화면 fetch 층이 행마다 부른다 (2026-08-26)
# ══════════════════════════════════════════════════════════════════
def entity_aliases_user(conn, lang):
    """사용자가 더한 **별명** — `{entity_code: [별명…]}` (2026-08-26).

    ★ 사용자 확정 「이름 고치지 말고 별명을 추가하는 방식으로 하라.
      좋다 / 토브를 같은 한 단어의 언어별 별명으로 한 것처럼」.
      이름을 고치면 그 이름을 쓰는 태그·연결·검색이 전부 따라가야 하는데,
      별명은 **찾는 길만 하나 더 여는 것**이라 아무것도 안 깨진다.
    ⚠⚠ **배포 DB(`sys_entity_master`)에 쓰지 않는다** — 사용자 동작이
      배포물을 고치면 다음 콘텐츠 교체에서 조용히 사라진다(§0-6 C-2).
      사용자 별명은 `userdb.user_entity_asset.json_detail` 에 산다.
    """
    out = {}
    try:
        cur = conn.execute(
            "SELECT entity_code, json_detail FROM userdb.user_entity_asset "
            "WHERE COALESCE(record_status,'LIVE')='LIVE' "
            "  AND json_detail IS NOT NULL")
    except Exception:
        return out
    import json as _j
    lg = (lang or 'KO').upper()
    for code, jd in cur.fetchall():
        try:
            al = (_j.loads(jd) or {}).get('aliases', {}).get(lg) or []
        except Exception:
            al = []
        if al:
            out[code] = list(al)
    return out


def save_entity_aliases(conn, entity_code, lang, aliases):
    """사용자 별명 저장 — `user_entity_asset` 한 행에 언어별로 쌓는다.

    ⚠ 그 용어의 **다른 언어 별명을 지우지 않는다** — 한 행에 함께 살기 때문에
      통째로 덮으면 옆 언어가 사라진다.
    ⚠ 이 행은 **가림(HIDE)과 같은 표**를 쓴다. 가려 둔 용어에 별명을 저장해도
      가림 상태를 건드리지 않는다(record_status 를 안 만진다).
    """
    import json as _j
    lg = (lang or 'KO').upper()
    row = conn.execute(
        'SELECT json_detail, record_status FROM userdb.user_entity_asset '
        'WHERE entity_code=?', (entity_code,)).fetchone()
    jd = {}
    if row and row[0]:
        try:
            jd = _j.loads(row[0]) or {}
        except Exception:
            jd = {}
    al = jd.get('aliases') or {}
    clean = []
    for a in (aliases or []):
        a = (a or '').strip()
        if a and a not in clean:
            clean.append(a)
    if clean:
        al[lg] = clean
    else:
        al.pop(lg, None)
    if al:
        jd['aliases'] = al
    else:
        jd.pop('aliases', None)
    blob = _j.dumps(jd, ensure_ascii=False) if jd else None
    if row:
        conn.execute('UPDATE userdb.user_entity_asset SET json_detail=? '
                     'WHERE entity_code=?', (blob, entity_code))
    else:
        conn.execute(
            'INSERT INTO userdb.user_entity_asset '
            '(entity_code, json_detail, record_status) VALUES (?,?,?)',
            (entity_code, blob, 'LIVE'))
    conn.commit()


def text_override(conn, text_type, clicked_id, lang, variant):
    """설명문 한 행의 덮개 — None(없음) · ('HIDE', None) ·
    (status, (title, contents)).

    ⚠ 렌즈 글(LENS_TEXT_TYPES)은 열쇠가 번호가 아니라 **유닛 이름**이다 —
      여기서 이름으로 바꿔 짓는다. sys 에 없는 유닛(내 렌즈)은 덮개 밖.
    ⚠ origin_key 칼럼이 없는 옛 DB 에서는 조용히 None — 덮개 자체가 없다."""
    ident = clicked_id
    if text_type in LENS_TEXT_TYPES:
        r = conn.execute('SELECT unit_name_sid FROM sys_unit_asset '
                         'WHERE sys_unit_id=?', (clicked_id,)).fetchone()
        if not r:
            return None
        ident = r[0]
    elif text_type in ENTITY_TEXT_TYPES:
        # 주요용어 — 번호 대신 entity_code (2026-08-26). 렌즈와 같은 문법.
        r = conn.execute('SELECT entity_code FROM sys_entity_master '
                         'WHERE entity_id=?', (clicked_id,)).fetchone()
        if not r:
            return None
        ident = r[0]
    elif text_type in PERI_TEXT_TYPES:
        # 단락 — 번호 대신 peri_code (2026-08-29). 같은 문법.
        r = conn.execute('SELECT peri_code FROM sys_pericope_asset '
                         'WHERE pericope_id=?', (clicked_id,)).fetchone()
        if not r:
            return None
        ident = r[0]
    okey = '%s|%s|%s|%s' % (text_type, ident, (lang or '').upper(),
                            variant or '')
    try:
        u = conn.execute(
            'SELECT title, contents, record_status FROM userdb.user_text_asset '
            'WHERE origin_key=?', (okey,)).fetchone()
    except Exception:
        return None
    if not u:
        return None
    if u[2] == 'HIDE':
        return ('HIDE', None)
    return (u[2], (u[0], u[1]))


# ══════════════════════════════════════════════════════════════════
#  엔진 — 다섯 동작. 자산을 모른다 (표·열쇠는 전부 어댑터에게 묻는다).
# ══════════════════════════════════════════════════════════════════
def resolve(conn, ad, anchor):
    """덮개를 적용한 최종 목록 — **화면이 읽는 것은 이것 하나다.**

    각 행에 `_src` 를 붙인다: 'SYS'(그대로) · 'EDIT'(내 버전이 대체) ·
    'NEW'(내가 만든 것). 가려진 sys 행은 **아예 안 나온다.**
    """
    users = {}
    for u in ad.user_rows(conn, anchor):
        users[ad.key_of(u)] = u
    out = []
    for s in ad.sys_rows(conn, anchor):
        k = ad.key_of(s)
        u = users.pop(k, None)
        if u is None:
            s['_src'] = 'SYS'
            out.append(s)
        elif u['record_status'] == 'HIDE':
            continue                        # 덮개 숨김 — sys 가 가려진다
        else:
            u['_src'] = 'EDIT'              # 내 버전이 sys 를 대체
            out.append(u)
    for k, u in users.items():
        if u['record_status'] != 'HIDE':    # sys 미매칭 HIDE = 내 것을 뗀 것
            u['_src'] = 'NEW'
            out.append(u)
    return out


def _upsert(conn, ad, row, status):
    key = ad.key_of(row)
    ad.prep_insert(row)                     # origin_key 등 채우기
    cols = [c for c in ad.COLS if c in row]
    w, p = ad.user_key_where(key)
    ex = conn.execute('SELECT 1 FROM %s WHERE %s' % (ad.USER_TBL, w),
                      p).fetchone()
    if ex is None:
        conn.execute(
            'INSERT INTO %s (%s, record_status) VALUES (%s, ?)'
            % (ad.USER_TBL, ', '.join(cols), ','.join('?' * len(cols))),
            [row[c] for c in cols] + [status])
    else:
        sets = ', '.join('%s=?' % c for c in cols)
        # ⚠ 자연 열쇠로 갱신한다 — user PK 도 쓰지 않는다(대칭 원칙)
        conn.execute(
            'UPDATE %s SET %s, record_status=? WHERE %s'
            % (ad.USER_TBL, sets, w),
            [row[c] for c in cols] + [status] + list(p))
    conn.commit()


def save(conn, ad, row):
    """사용자 버전 저장. sys 에 같은 열쇠가 있으면 EDIT, 없으면 NEW."""
    is_edit = ad.sys_has(conn, ad.key_of(row))
    _upsert(conn, ad, row, 'EDIT' if is_edit else 'LIVE')
    return 'EDIT' if is_edit else 'NEW'


def hide(conn, ad, row):
    """sys 자산을 가린다(덮개 숨김). 내 NEW 행이면 그냥 뗀 것이 된다."""
    _upsert(conn, ad, row, 'HIDE')


def revert(conn, ad, row):
    """되돌림 — **user 행을 물리 삭제**하면 sys 가 되살아난다.

    ⚠ HIDE 로 남기지 않는다 — 남기면 「가림」과 구별이 안 된다.
      되돌림은 「내 손댄 흔적을 지운다」는 뜻이고, 사용자가 고른 것이다(13-43).
    """
    w, p = ad.user_key_where(ad.key_of(row))
    conn.execute('DELETE FROM %s WHERE %s' % (ad.USER_TBL, w), p)
    conn.commit()


def diff(conn, ad, anchor):
    """나눔·표시용 — 「무엇이 추가/수정/숨김인가」(사용자 지시 그대로)."""
    users = {ad.key_of(u): u for u in ad.user_rows(conn, anchor)}
    sys_keys = {ad.key_of(s) for s in ad.sys_rows(conn, anchor)}
    out = {'added': [], 'edited': [], 'hidden': []}
    for k, u in users.items():
        if k in sys_keys:
            (out['hidden'] if u['record_status'] == 'HIDE'
             else out['edited']).append(u)
        elif u['record_status'] != 'HIDE':
            out['added'].append(u)
    return out


# ══════════════════════════════════════════════════════════════════
#  자가 검증
# ══════════════════════════════════════════════════════════════════
def selftest():
    import sqlite3
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    db = sqlite3.connect(':memory:')
    db.execute('ATTACH DATABASE ":memory:" AS userdb')
    # ⚠ 가짜 표의 PK 이름은 일부러 다르게(weird_pk) — 「스키마에 묻는가」를
    #   진짜로 재기 위해서다(§0-5 · lang_compare 의 교훈).
    ddl = ('(weird_pk INTEGER PRIMARY KEY, link_type TEXT, clicked_id INT, '
           'target_id INT, rel_code TEXT, end_id INT, note TEXT, '
           'chain_code TEXT, sort_order INT, record_status TEXT)')
    db.execute('CREATE TABLE sys_link_asset ' + ddl)
    db.execute('CREATE TABLE userdb.user_link_asset ' + ddl)

    def sys_ins(a, b, rel, note=None, pk=None):
        db.execute('INSERT INTO sys_link_asset (weird_pk, link_type, clicked_id, '
                   "target_id, rel_code, note, record_status) "
                   "VALUES (?,?,?,?,?,?,'LIVE')",
                   (pk, 'VERS_VERS', a, b, rel, note))
    sys_ins(1, 100, 'PRG', '점진')
    sys_ins(1, 200, 'TYP', '예표')
    sys_ins(1, 300, 'REF', '참조')
    db.commit()
    ad = LinkOverlay()

    r = resolve(db, ad, 1)
    t('덮개 없으면 sys 그대로', len(r) == 3 and all(x['_src'] == 'SYS' for x in r))

    # ① 가리기
    hide(db, ad, {'link_type': 'VERS_VERS', 'clicked_id': 1, 'target_id': 300,
                  'rel_code': 'REF'})
    r = resolve(db, ad, 1)
    t('★ 가린 sys 가 안 나온다', len(r) == 2 and
      all(x['target_id'] != 300 for x in r), [x['target_id'] for x in r])

    # ② 고쳐 쓰기 (EDIT)
    st = save(db, ad, {'link_type': 'VERS_VERS', 'clicked_id': 1,
                       'target_id': 200, 'rel_code': 'TYP', 'note': '내 설명'})
    t('★ sys 와 같은 열쇠면 EDIT', st == 'EDIT', st)
    r = resolve(db, ad, 1)
    ed = [x for x in r if x['target_id'] == 200][0]
    t('★ 내 버전이 sys 를 대체한다', ed['_src'] == 'EDIT'
      and ed['note'] == '내 설명', ed.get('note'))
    t('   행 수는 그대로 (두 번 안 나온다)', len(r) == 2, len(r))

    # ③ 새로 만들기 (NEW)
    st = save(db, ad, {'link_type': 'VERS_VERS', 'clicked_id': 1,
                       'target_id': 900, 'rel_code': 'PAR', 'note': '내 연결'})
    t('★ sys 에 없는 열쇠면 NEW', st == 'NEW', st)
    r = resolve(db, ad, 1)
    t('   NEW 가 목록에 든다', any(x['_src'] == 'NEW' and
      x['target_id'] == 900 for x in r), len(r))

    # ④ diff — 나눔용
    d = diff(db, ad, 1)
    t('★ diff = 추가1 · 수정1 · 숨김1',
      (len(d['added']), len(d['edited']), len(d['hidden'])) == (1, 1, 1),
      {k: len(v) for k, v in d.items()})

    # ⑤ 되돌림 — sys 부활
    revert(db, ad, {'link_type': 'VERS_VERS', 'clicked_id': 1,
                    'target_id': 300, 'rel_code': 'REF'})
    r = resolve(db, ad, 1)
    back = [x for x in r if x['target_id'] == 300]
    t('★ 되돌리면 sys 가 되살아난다', len(back) == 1
      and back[0]['_src'] == 'SYS')

    # ⑥ ★★★ 핵심 — sys 재적재로 PK 가 전부 바뀌어도 덮개가 살아남는가
    db.execute('DELETE FROM sys_link_asset')
    sys_ins(1, 100, 'PRG', '점진', pk=7001)      # PK 1→7001
    sys_ins(1, 200, 'TYP', '예표', pk=7002)      # PK 2→7002
    sys_ins(1, 300, 'REF', '참조', pk=7003)
    db.commit()
    r = resolve(db, ad, 1)
    ed = [x for x in r if x['target_id'] == 200]
    t('★★★ 재적재(PK 전부 변경) 뒤에도 EDIT 가 산다',
      ed and ed[0]['_src'] == 'EDIT' and ed[0]['note'] == '내 설명')
    t('★★★ NEW 도 산다', any(x['_src'] == 'NEW' for x in r))

    # ⑦ 기존 §10 의미 보존 — sys 미매칭 HIDE = 내 것을 뗀 것
    db.execute("INSERT INTO userdb.user_link_asset (link_type, clicked_id, "
               "target_id, rel_code, record_status) "
               "VALUES ('VERS_VERS', 1, 950, 'ALL', 'HIDE')")
    db.commit()
    r = resolve(db, ad, 1)
    t('★ 내 것을 뗀 HIDE 는 그냥 안 보인다 (가림과 다르다)',
      all(x['target_id'] != 950 for x in r))
    d = diff(db, ad, 1)
    t('   그것은 diff 의 hidden 에도 섞이지 않는다… ',
      all(u['target_id'] != 950 for u in d['hidden']), None)

    # ⑧ 탐지력 — key_of 를 PK 로 바꾸면 재적재 검사가 깨져야 한다
    class BadAdapter(LinkOverlay):
        def key_of(self, row):
            return (row.get('weird_pk'),)   # ⚠ 금지된 방식
    bad = BadAdapter()
    try:
        rb = resolve(db, bad, 1)
        broken = not any(x.get('_src') == 'EDIT' for x in rb)
        t('★ (탐지력) PK 짝짓기면 덮개가 죽는 것이 보인다', broken)
    except Exception:
        t('★ (탐지력) PK 짝짓기면 덮개가 죽는 것이 보인다', True)

    # ══════════════ 2단계 — 설명문 (TextOverlay) ══════════════
    db.execute('CREATE TABLE sys_text_asset (odd_pk INTEGER PRIMARY KEY, '
               'clicked_id INT, target_id INT, text_type TEXT, title TEXT, '
               'contents TEXT, lang_code TEXT, text_variant TEXT, '
               'record_status TEXT)')
    db.execute('CREATE TABLE userdb.user_text_asset (u_pk INTEGER PRIMARY KEY, '
               'clicked_id INT, target_id INT, text_type TEXT, title TEXT, '
               'contents TEXT, lang_code TEXT, text_variant TEXT, '
               'record_status TEXT)')
    db.execute('CREATE TABLE userdb.user_tag_asset (u_tag_pk INTEGER PRIMARY '
               'KEY, tag_name_sid TEXT, tag_category TEXT, record_status TEXT)')
    ensure_schema(db)                        # origin_key 칼럼이 여기서 붙는다
    t('ensure_schema 멱등', (ensure_schema(db) or True))

    db.execute("INSERT INTO sys_text_asset (clicked_id, text_type, contents, "
               "lang_code, text_variant, record_status) "
               "VALUES (71, 'VERS_DESC', '관리자 설명', 'KO', 'LAY', 'LIVE')")
    db.commit()
    tx = TextOverlay('VERS_DESC')
    r = resolve(db, tx, 71)
    t('설명문: sys 그대로', len(r) == 1 and r[0]['_src'] == 'SYS')
    st = save(db, tx, {'text_type': 'VERS_DESC', 'clicked_id': 71,
                       'contents': '내가 고친 설명', 'lang_code': 'KO',
                       'text_variant': 'LAY'})
    t('★ 설명문 고치면 EDIT', st == 'EDIT', st)
    r = resolve(db, tx, 71)
    t('★ 내 설명이 sys 를 대체', len(r) == 1 and r[0]['_src'] == 'EDIT'
      and r[0]['contents'] == '내가 고친 설명')
    # 사용자 자기 글(origin_key 없음)은 덮개가 안 본다
    db.execute("INSERT INTO userdb.user_text_asset (clicked_id, text_type, "
               "contents, lang_code, record_status) "
               "VALUES (71, 'VERS_DESC', '옛 방식 잔재', 'KO', 'LIVE')")
    db.commit()
    r = resolve(db, tx, 71)
    t('★ origin_key 없는 행은 덮개 밖', len(r) == 1
      and r[0]['contents'] == '내가 고친 설명', len(r))
    revert(db, tx, {'text_type': 'VERS_DESC', 'clicked_id': 71,
                    'lang_code': 'KO', 'text_variant': 'LAY'})
    r = resolve(db, tx, 71)
    t('★ 설명문 되돌림 — sys 부활', len(r) == 1 and r[0]['_src'] == 'SYS')
    db.execute('DELETE FROM userdb.user_text_asset')
    db.commit()

    # ══════════════ 2단계 — 렌즈 글 (LensTextOverlay) ══════════════
    db.execute('CREATE TABLE sys_unit_asset (sys_unit_id INTEGER PRIMARY KEY, '
               'unit_type TEXT, unit_name_sid TEXT, record_status TEXT)')
    db.execute("INSERT INTO sys_unit_asset VALUES (5, 'NODE', '빛이 있으라', 'LIVE')")
    db.execute("INSERT INTO sys_text_asset (clicked_id, text_type, contents, "
               "lang_code, record_status) "
               "VALUES (5, 'NODE_DESC', '관리자 노드 설명', 'KO', 'LIVE')")
    db.commit()
    lz = LensTextOverlay('NODE_DESC')
    st = save(db, lz, dict(resolve(db, lz, 5)[0], contents='내 노드 설명'))
    t('★ 렌즈 글 고치면 EDIT', st == 'EDIT', st)
    r = resolve(db, lz, 5)
    t('   내 버전이 보인다', len(r) == 1 and r[0]['contents'] == '내 노드 설명')
    # ★★★ 재적재 — 유닛 번호가 5→9005 로 바뀌어도 이름 열쇠라 산다
    db.execute('DELETE FROM sys_unit_asset')
    db.execute("INSERT INTO sys_unit_asset VALUES (9005, 'NODE', '빛이 있으라', 'LIVE')")
    db.execute("UPDATE sys_text_asset SET clicked_id=9005 WHERE text_type='NODE_DESC'")
    db.commit()
    r = resolve(db, lz, 9005)
    t('★★★ 유닛 재적재(번호 변경) 뒤에도 렌즈 덮개가 산다',
      len(r) == 1 and r[0]['_src'] == 'EDIT'
      and r[0]['contents'] == '내 노드 설명')
    # 탐지력 — 번호로 짝지으면 죽는다
    bad_lz = TextOverlay('NODE_DESC')       # clicked_id 열쇠 = 금지된 방식
    rb = resolve(db, bad_lz, 9005)
    t('★ (탐지력) 번호 짝짓기 렌즈 덮개는 재적재에서 죽는 것이 보인다',
      not any(x.get('_src') == 'EDIT' for x in rb))

    # ══════════════ 2단계 — 태그 (TagOverlay) ══════════════
    db.execute('CREATE TABLE sys_tag_asset (odd_tag_pk INTEGER PRIMARY KEY, '
               'tag_name_sid TEXT, tag_category TEXT, tag_kind TEXT, '
               'entity_id INT, dict_ref INT, record_status TEXT)')
    # entity_id 는 어댑터가 **이름으로 조인하는 실제 칼럼**(PRAGMA 실측)이라
    # 가짜 표도 같은 이름을 쓴다 — weird_pk 원칙은 「짐작한 이름」에만 건다.
    db.execute('CREATE TABLE sys_entity_master (entity_id INTEGER PRIMARY KEY, '
               'entity_code TEXT, entity_type TEXT, json_detail TEXT, '
               'record_status TEXT)')
    db.execute("INSERT INTO sys_entity_master VALUES "
               "(318, 'P_DAVID', 'PERSON', NULL, 'LIVE')")
    # ★ 단락 — 열쇠는 peri_code (2026-08-29)
    db.execute('CREATE TABLE sys_pericope_asset (pericope_id INTEGER PRIMARY '
               'KEY, peri_code TEXT, peri_type TEXT, start_vid INTEGER, '
               'end_vid INTEGER, record_status TEXT)')
    db.execute("INSERT INTO sys_tag_asset (tag_name_sid, tag_category, "
               "tag_kind, record_status) VALUES "
               "('TAG_GOSPEL', 'THEME', 'PLAIN', 'LIVE')")
    db.execute("INSERT INTO sys_tag_asset (tag_category, tag_kind, entity_id, "
               "record_status) VALUES ('THEME', 'ENTITY', 318, 'LIVE')")
    # ⚠ entity_id 를 EntityOverlay 의 sys 로도 쓰므로 표 하나로 겸한다
    db.commit()
    tg = TagOverlay()
    r = resolve(db, tg, None)
    t('태그: sys 둘 그대로', len(r) == 2, len(r))
    # 이름 수정 — PLAIN
    st = save(db, tg, {'tag_kind': 'PLAIN', 'tag_name_sid': '복음(내 이름)',
                       'tag_category': 'THEME',
                       'origin_key': 'P|TAG_GOSPEL'})
    t('★ 태그 이름 수정 = EDIT', st == 'EDIT', st)
    r = resolve(db, tg, None)
    ed = [x for x in r if x.get('_src') == 'EDIT']
    t('   내 이름이 대체한다', len(ed) == 1
      and ed[0]['tag_name_sid'] == '복음(내 이름)')
    # 엔티티 태그 숨김
    hide(db, tg, {'tag_kind': 'ENTITY', 'entity_code': 'P_DAVID',
                  'tag_category': 'THEME'})
    r = resolve(db, tg, None)
    t('★ 엔티티 태그 가림', len(r) == 1, len(r))
    # ★★★ 재적재 — entity_id 가 318→9318 로 바뀌어도 code 열쇠라 산다
    db.execute('DELETE FROM sys_entity_master')
    db.execute("INSERT INTO sys_entity_master VALUES "
               "(9318, 'P_DAVID', 'PERSON', NULL, 'LIVE')")
    db.execute("UPDATE sys_tag_asset SET entity_id=9318 WHERE tag_kind='ENTITY'")
    db.commit()
    r = resolve(db, tg, None)
    t('★★★ 엔티티 재적재(번호 변경) 뒤에도 태그 가림이 산다',
      len(r) == 1 and all(x.get('entity_code') != 'P_DAVID' for x in r))
    # 내 태그(origin_key 없음)는 덮개 밖
    db.execute("INSERT INTO userdb.user_tag_asset (tag_name_sid, tag_category, "
               "record_status) VALUES ('사랑', 'THEME', 'LIVE')")
    db.commit()
    r = resolve(db, tg, None)
    t('★ origin_key 없는 내 태그는 덮개 밖', len(r) == 1, len(r))

    # ══════════════ 2단계 — 엔티티 (EntityOverlay) ══════════════
    en = EntityOverlay()
    r = resolve(db, en, None)
    t('엔티티: sys 그대로', len(r) == 1 and r[0]['_src'] == 'SYS')
    hide(db, en, {'entity_code': 'P_DAVID', 'entity_type': 'PERSON'})
    r = resolve(db, en, None)
    t('★ 엔티티 가림', len(r) == 0, len(r))
    d = diff(db, en, None)
    t('   diff.hidden 에 잡힌다', len(d['hidden']) == 1)
    revert(db, en, {'entity_code': 'P_DAVID'})
    r = resolve(db, en, None)
    t('★ 엔티티 가림 해제 — sys 부활', len(r) == 1 and r[0]['_src'] == 'SYS')

    # ═══════ 주요용어 글 (EntityTextOverlay) — 2026-08-26 ═══════
    # ⚠ 번호를 코드에 박지 않는다 — 앞 검사(태그 재적재)가 이미 갈아 두었다.
    #   지금 표에 있는 번호를 읽어 쓴다(§0-5 「검사를 데이터 상태에 걸지 말 것」).
    eid0 = db.execute("SELECT entity_id FROM sys_entity_master "
                      "WHERE entity_code='P_DAVID'").fetchone()[0]
    db.execute("INSERT INTO sys_text_asset (clicked_id, text_type, contents, "
               "lang_code, record_status) "
               "VALUES (?, 'ENTITY_DESC', '관리자 용어 설명', 'KO', 'LIVE')", (eid0,))
    db.commit()
    et = EntityTextOverlay('ENTITY_DESC')
    st = save(db, et, dict(resolve(db, et, eid0)[0], contents='내 용어 설명'))
    t('★ 용어 설명 고치면 EDIT', st == 'EDIT', st)
    r = resolve(db, et, eid0)
    t('   내 버전이 보인다', len(r) == 1 and r[0]['contents'] == '내 용어 설명')
    ov = text_override(db, 'ENTITY_DESC', eid0, 'KO', '')
    t('   text_override 가 내 글을 준다',
      ov and ov[0] == 'EDIT' and ov[1][1] == '내 용어 설명', ov)
    # ★★★ 재적재 — 번호가 바뀌어도 code 열쇠라 산다
    db.execute("UPDATE sys_entity_master SET entity_id=7318 WHERE entity_id=?",
               (eid0,))
    db.execute("UPDATE sys_text_asset SET clicked_id=7318 "
               "WHERE text_type='ENTITY_DESC'")
    db.commit()
    r = resolve(db, et, 7318)
    t('★★★ 용어 재적재(번호 변경) 뒤에도 덮개가 산다',
      len(r) == 1 and r[0]['_src'] == 'EDIT' and r[0]['contents'] == '내 용어 설명')
    # 탐지력 — 번호로 짝지으면 죽는다
    rb = resolve(db, TextOverlay('ENTITY_DESC'), 7318)
    t('★ (탐지력) 번호 짝짓기면 재적재에서 죽는 것이 보인다',
      not any(x.get('_src') == 'EDIT' for x in rb))
    # ★★ 가림 — 폴백 보호의 근거. `text_override` 가 ('HIDE', None) 을 줘야
    #    화면이 「가려서 빈 것」과 「원래 없는 것」을 가를 수 있다(§88차).
    hide(db, et, dict(resolve(db, et, 7318)[0]))
    ov = text_override(db, 'ENTITY_DESC', 7318, 'KO', '')
    t('★★ 가리면 text_override 가 HIDE 를 준다 (폴백 금지 신호)',
      ov == ('HIDE', None), ov)
    t('   가린 뒤 resolve 는 빈다', len(resolve(db, et, 7318)) == 0)
    revert(db, et, {'origin_key': 'ENTITY_DESC|P_DAVID|KO|'})
    t('   되돌리면 sys 부활',
      [x['_src'] for x in resolve(db, et, 7318)] == ['SYS'])

    # ── 단락 설명문 덮개 (2026-08-29 신설) ──────────────────────────
    # ★ 사용자 신고 「단락을 출발지로 지정했다. **단락 설명문을 표시하지도
    #   못한다. 수정할 수도 없다.**」 — 열쇠가 없다고 미뤄 둔 자리였는데
    #   `peri_code` 가 3,413개 전부 고유했다(실측).
    db.execute("INSERT INTO sys_pericope_asset "
               "(pericope_id, peri_code, peri_type, start_vid, end_vid, "
               " record_status) VALUES (99001,'ZZZ_01_BODY_1','BODY',1,2,"
               "'LIVE')")
    db.execute("INSERT INTO sys_text_asset (clicked_id, text_type, contents, "
               "lang_code, record_status) "
               "VALUES (99001, 'PERI_DESC', '기본 단락 설명', 'KO', 'LIVE')")
    db.commit()
    pt = PeriTextOverlay('PERI_DESC')
    r = resolve(db, pt, 99001)
    t('★ 단락 — 기본 설명이 보인다', len(r) == 1 and r[0]['_src'] == 'SYS', r)
    st = save(db, pt, dict(r[0], contents='내 단락 설명'))
    t('★ 단락 설명 고치면 EDIT', st == 'EDIT', st)
    r = resolve(db, pt, 99001)
    t('   내 버전이 보인다',
      len(r) == 1 and r[0]['contents'] == '내 단락 설명', r)
    ov = text_override(db, 'PERI_DESC', 99001, 'KO', '')
    t('   text_override 가 내 글을 준다',
      ov and ov[0] == 'EDIT' and ov[1][1] == '내 단락 설명', ov)
    # ★★★ 재적재 — 번호가 바뀌어도 peri_code 라 산다
    db.execute("UPDATE sys_pericope_asset SET pericope_id=99777 "
               "WHERE pericope_id=99001")
    db.execute("UPDATE sys_text_asset SET clicked_id=99777 "
               "WHERE text_type='PERI_DESC' AND clicked_id=99001")
    db.commit()
    r = resolve(db, pt, 99777)
    t('★★★ 단락 재적재(번호 변경) 뒤에도 덮개가 산다',
      len(r) == 1 and r[0]['_src'] == 'EDIT'
      and r[0]['contents'] == '내 단락 설명', r)
    rb = resolve(db, TextOverlay('PERI_DESC'), 99777)
    t('★ (탐지력) 번호 짝짓기면 재적재에서 죽는 것이 보인다',
      not any(x.get('_src') == 'EDIT' for x in rb))
    hide(db, pt, dict(resolve(db, pt, 99777)[0]))
    t('★★ 단락도 가리면 HIDE 를 준다',
      text_override(db, 'PERI_DESC', 99777, 'KO', '') == ('HIDE', None))
    revert(db, pt, {'origin_key': 'PERI_DESC|ZZZ_01_BODY_1|KO|'})
    t('   되돌리면 sys 부활',
      [x['_src'] for x in resolve(db, pt, 99777)] == ['SYS'])

    db.close()
    print('overlay selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] != '--selftest':
        print(__doc__)
    else:
        sys.exit(0 if selftest() else 1)
