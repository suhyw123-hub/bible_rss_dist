# -*- coding: utf-8 -*-
"""지역구분 코드표 (영구 도구 · 2026-09-02 사용자 확정 「장소분류: 계획대로 진행하라」).

★ 장소가 106곳을 넘어서서 목록만으로는 못 찾는다(0.txt 8번). 시대 코드표
  (`db_era_code`)와 같은 문법 — 값 목록을 작은 코드표 하나로 통제한다.
★ **분류값은 이미 데이터에 있었다** — `sys_entity_master.json_detail.region_code`
  가 105/106곳에 12개 코드로 들어 있다(실측). 이 도구는 그 값의 **명부**를
  세우고(표기가 갈리는 것을 막는다) 이름을 11개 언어로 등록한다.
  ⚠ 자유 글 `region`(24곳, 「유다 산지」 등)은 **건드리지 않는다** — 그것은
    상세 표시용 산문이고, 거르기는 코드가 맡는다(§12-5 ①/③ 구분).

표: `sys_region_code`(코드·차례). 이름은 `ui_strings`(`REGION_*`).
쓰는 곳: 주요용어 [장소] 유형의 지역 콤보(인물의 시대 콤보와 같은 자리).

사용법
  python db_region_code.py --selftest
  python db_region_code.py --init      # 표·이름 적재(멱등)
  python db_region_code.py --status
"""
import sys

import appdb

#: 지역 값 — 차례는 성경 서사의 지리 순(동→서). 코드 = 실데이터의 12개 그대로.
#  (code, sort, KO, EN, {그 밖 언어})
REGIONS = [
    ('MESOPOTAMIA', 10, '메소포타미아', 'Mesopotamia',
     {'ZH': '美索不达米亚', 'ZHT': '美索不達米亞', 'JA': 'メソポタミア',
      'DE': 'Mesopotamien', 'FR': 'Mésopotamie', 'ES': 'Mesopotamia',
      'AR': 'بلاد الرافدين', 'RU': 'Месопотамия', 'PT': 'Mesopotâmia'}),
    ('EGYPT', 20, '애굽', 'Egypt',
     {'ZH': '埃及', 'ZHT': '埃及', 'JA': 'エジプト', 'DE': 'Ägypten',
      'FR': 'Égypte', 'ES': 'Egipto', 'AR': 'مصر', 'RU': 'Египет', 'PT': 'Egito'}),
    ('SINAI', 30, '시내·광야', 'Sinai & Desert',
     {'ZH': '西奈·旷野', 'ZHT': '西奈·曠野', 'JA': 'シナイ・荒野',
      'DE': 'Sinai & Wüste', 'FR': 'Sinaï et désert', 'ES': 'Sinaí y desierto',
      'AR': 'سيناء والبرية', 'RU': 'Синай и пустыня', 'PT': 'Sinai e deserto'}),
    ('TRANSJORDAN', 40, '요단 동편', 'Transjordan',
     {'ZH': '约旦河东', 'ZHT': '約旦河東', 'JA': 'ヨルダン川東',
      'DE': 'Ostjordanland', 'FR': 'Transjordanie', 'ES': 'Transjordania',
      'AR': 'شرق الأردن', 'RU': 'Заиорданье', 'PT': 'Transjordânia'}),
    ('JUDEA', 50, '유대', 'Judea',
     {'ZH': '犹太', 'ZHT': '猶太', 'JA': 'ユダヤ', 'DE': 'Judäa',
      'FR': 'Judée', 'ES': 'Judea', 'AR': 'اليهودية', 'RU': 'Иудея', 'PT': 'Judeia'}),
    ('SAMARIA', 60, '사마리아', 'Samaria',
     {'ZH': '撒玛利亚', 'ZHT': '撒瑪利亞', 'JA': 'サマリア', 'DE': 'Samaria',
      'FR': 'Samarie', 'ES': 'Samaria', 'AR': 'السامرة', 'RU': 'Самария', 'PT': 'Samaria'}),
    ('GALILEE', 70, '갈릴리', 'Galilee',
     {'ZH': '加利利', 'ZHT': '加利利', 'JA': 'ガリラヤ', 'DE': 'Galiläa',
      'FR': 'Galilée', 'ES': 'Galilea', 'AR': 'الجليل', 'RU': 'Галилея', 'PT': 'Galileia'}),
    ('SYRIA', 80, '수리아·베니게', 'Syria & Phoenicia',
     {'ZH': '叙利亚·腓尼基', 'ZHT': '敘利亞·腓尼基', 'JA': 'シリア・フェニキア',
      'DE': 'Syrien & Phönizien', 'FR': 'Syrie et Phénicie',
      'ES': 'Siria y Fenicia', 'AR': 'سوريا وفينيقية',
      'RU': 'Сирия и Финикия', 'PT': 'Síria e Fenícia'}),
    ('CYPRUS', 90, '구브로', 'Cyprus',
     {'ZH': '塞浦路斯', 'ZHT': '塞浦路斯', 'JA': 'キプロス', 'DE': 'Zypern',
      'FR': 'Chypre', 'ES': 'Chipre', 'AR': 'قبرص', 'RU': 'Кипр', 'PT': 'Chipre'}),
    ('ASIA_MINOR', 100, '소아시아', 'Asia Minor',
     {'ZH': '小亚细亚', 'ZHT': '小亞細亞', 'JA': '小アジア', 'DE': 'Kleinasien',
      'FR': 'Asie Mineure', 'ES': 'Asia Menor', 'AR': 'آسيا الصغرى',
      'RU': 'Малая Азия', 'PT': 'Ásia Menor'}),
    ('GREECE', 110, '헬라·마게도냐', 'Greece & Macedonia',
     {'ZH': '希腊·马其顿', 'ZHT': '希臘·馬其頓', 'JA': 'ギリシャ・マケドニア',
      'DE': 'Griechenland & Mazedonien', 'FR': 'Grèce et Macédoine',
      'ES': 'Grecia y Macedonia', 'AR': 'اليونان ومقدونية',
      'RU': 'Греция и Македония', 'PT': 'Grécia e Macedônia'}),
    ('ITALY', 120, '이탈리아', 'Italy',
     {'ZH': '意大利', 'ZHT': '義大利', 'JA': 'イタリア', 'DE': 'Italien',
      'FR': 'Italie', 'ES': 'Italia', 'AR': 'إيطاليا', 'RU': 'Италия', 'PT': 'Itália'}),
]


def init(conn):
    """표·이름 적재 — 멱등."""
    conn.execute("CREATE TABLE IF NOT EXISTS sys_region_code ("
                 " region_code TEXT PRIMARY KEY, sort_order INTEGER NOT NULL)")
    conn.execute("DELETE FROM sys_region_code")
    langs = [r[0] for r in conn.execute(
        "SELECT lang_code FROM sys_language WHERE is_ui=1")]
    for code, so, ko, en, others in REGIONS:
        conn.execute("INSERT INTO sys_region_code VALUES(?,?)", (code, so))
        for lg in langs:
            v = ko if lg == 'KO' else others.get(lg, en) if lg != 'EN' else en
            conn.execute("INSERT OR REPLACE INTO ui_strings"
                         " (string_id, lang_code, string_value) VALUES(?,?,?)",
                         ('REGION_%s' % code, lg, v))
    conn.commit()


def regions(conn, lang='KO'):
    """[(code, 이름)] — 콤보가 쓴다. 이름은 ui_strings(요청 언어→EN 폴백)."""
    out = []
    for code, in conn.execute("SELECT region_code FROM sys_region_code"
                              " ORDER BY sort_order"):
        r = conn.execute(
            "SELECT string_value FROM ui_strings WHERE string_id=?"
            " AND lang_code IN (?, 'EN') ORDER BY (lang_code=?) DESC LIMIT 1",
            ('REGION_%s' % code, lang, lang)).fetchone()
        out.append((code, r[0] if r else code))
    return out


def status(conn):
    import json
    from collections import Counter
    dist = Counter()
    missing = []
    for code, jd in conn.execute(
            "SELECT entity_code, json_detail FROM sys_entity_master"
            " WHERE entity_type='PLACE'"
            " AND COALESCE(record_status,'LIVE')='LIVE'"):
        try:
            rc = json.loads(jd or '{}').get('region_code')
        except Exception:
            rc = None
        if rc:
            dist[rc] += 1
        else:
            missing.append(code)
    print('지역 코드표:', [c for c, *_r in REGIONS])
    for c, *_r in REGIONS:
        print('  %-12s %3d곳' % (c, dist.get(c, 0)))
    unknown = [c for c in dist if c not in {x[0] for x in REGIONS}]
    print('코드표 밖 값:', unknown or 0, '· 빈 곳:', missing or 0)


def selftest():
    import json
    import sqlite3
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    codes = [c for c, *_r in REGIONS]
    t('코드 중복 없음', len(codes) == len(set(codes)))
    t('12개 지역', len(codes) == 12, len(codes))
    # 가짜 DB 왕복 — 멱등·이름 폴백
    db = sqlite3.connect(':memory:')
    db.execute('CREATE TABLE sys_language (lang_code TEXT, is_ui INT)')
    db.execute("INSERT INTO sys_language VALUES ('KO',1),('EN',1),('JA',1)")
    db.execute('CREATE TABLE ui_strings (string_id TEXT, lang_code TEXT,'
               ' string_value TEXT, PRIMARY KEY(string_id, lang_code))')
    db.execute('CREATE TABLE sys_entity_master (entity_code TEXT,'
               ' entity_type TEXT, record_status TEXT, json_detail TEXT)')
    init(db)
    init(db)                                       # 멱등
    t('표 행수 = 지역 수(두 번 넣어도)', db.execute(
        'SELECT COUNT(*) FROM sys_region_code').fetchone()[0] == 12)
    got = regions(db, 'KO')
    t('KO 이름', got[0] == ('MESOPOTAMIA', '메소포타미아'), got[0])
    got_ja = regions(db, 'JA')
    t('JA 이름', got_ja[1][1] == 'エジプト', got_ja[1])
    # ★ 실데이터 정합 — 진짜 DB 의 PLACE region_code 가 전부 코드표 안인가.
    #   ⚠ 데이터 상태(개수)를 못 박지 않는다(§0-5) — 「코드표 밖 값 0 ·
    #     빈 곳 0」이라는 **불변식**만 잰다.
    try:
        real = appdb.connect(appdb.MAIN_DB)
        bad, empty = [], []
        for code, jd in real.execute(
                "SELECT entity_code, json_detail FROM sys_entity_master"
                " WHERE entity_type='PLACE'"
                " AND COALESCE(record_status,'LIVE')='LIVE'"):
            try:
                rc = json.loads(jd or '{}').get('region_code')
            except Exception:
                rc = None
            if not rc:
                empty.append(code)
            elif rc not in set(codes):
                bad.append((code, rc))
        real.close()
        t('★ 실데이터 — 코드표 밖 값 0', not bad, bad[:5])
        t('★ 실데이터 — region_code 빈 장소 0', not empty, empty[:5])
    except Exception as e:
        t('실데이터 접근', False, e)
    db.close()
    print('db_region_code selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv[1] if len(sys.argv) > 1 else '--status'
    if a == '--selftest':
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(appdb.MAIN_DB)
    if a == '--init':
        init(conn)
        print('sys_region_code + REGION_* 적재 완료')
    status(conn)
    conn.close()
