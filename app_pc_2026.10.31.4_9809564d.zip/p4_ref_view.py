# -*- coding: utf-8 -*-
"""p4_ref_view.py — P4 '자료' 탭 (2026-08-03 신설)

무엇을 띄우나
    ① 연구 자료 글 (`sys_ref_unit` + `sys_ref_text`) — 읽기, 언어 선택
    ② 내 자료 (`user_ref_asset`)                     — 읽기 / 수정하기 / 새로 쓰기
    ③ 영상                                          — YouTube 임베드

왜 한 탭에 넣나
    P4 는 이미 9탭이라 글 탭과 영상 탭을 따로 두면 10·11번째가 되어 라벨이 무너진다.
    그리고 글과 영상이 **동시에** 필요한 경우가 없다. 그래서 한 탭 안에서
    내용에 따라 위젯만 갈아 끼운다.

⚠ 영상 프로세스를 탭 전환 때마다 죽이지 말 것.
    QtWebEngine 은 첫 재생에 시간이 걸린다(§30). 글을 보다가 영상으로 돌아왔을 때
    다시 기다리게 되므로, **위젯만 pack_forget 하고 프로세스는 살려 둔다.**
    실제 종료는 이 뷰가 파괴될 때뿐이다.

왜 P2 가 아니라 P4 인가
    P1 은 노트북이라 읽기 탭으로 가면 성경 본문이 가려진다. P4 는 P1 과 좌우로
    나뉜 별개 패널이라 **본문을 띄워 둔 채** 자료를 넓게 읽을 수 있다.
"""
from __future__ import annotations
import tkinter as tk
import os
import shutil
from tkinter import ttk, messagebox, filedialog

import appdb
import verse_text as _vt   # ★ 절 본문은 이 문 하나로(합쳐짐·없는절 보완 §verse_text)
import lang_combo
import verse_ref, i18n

def _flat(**over):
    """My Edit·Recent 류 **테두리 없는 단추** — 모양의 단일 소스는 `ui_theme`.

    ⚠ 화면마다 손으로 적으면 갈라진다(실측 7곳이 bd·padx·글꼴이 제각각이었다 —
      2026-08-30 사용자 지시 「My Edit 버튼의 디자인을 통일하라. Recent 버튼과
      동일하게」).
    """
    try:
        import ui_theme
        return ui_theme.flat_btn(**over)
    except Exception:
        return dict(bd=1, padx=6, pady=2, cursor='hand2', **over)


try:
    import media_player
except Exception:
    media_player = None
try:
    import theme_font
except Exception:
    theme_font = None

_MODE_EMPTY, _MODE_TEXT, _MODE_FORM, _MODE_VIDEO = 'EMPTY', 'TEXT', 'FORM', 'VIDEO'


def _ref_lang():
    """구절약명에 쓸 언어 — **성경 역본**을 따른다(표시언어 콤보가 아니다).

    2026-08-15 사용자 지시: 「구절약명은 버전을 바꿀 때에만 바뀌어야 한다」.
    ⚠ `book_names` 에 EL·HE·COP 가 없어 원문 역본(GNT·WLC·COP*)은 **영어**로 떨어진다.
    """
    try:
        import lang_config
        return lang_config.ref_lang()
    except Exception:
        return 'EN'

def _user_type_label(k):
    """내 자료 유형 코드 → 라벨 — ★ 2026-10-16 셋(연구·설교·참고자료)만 · `ref_kinds` 한 문(옛 유형도 접는다)."""
    try:
        import ref_kinds
        return ref_kinds.kind_label(k)
    except Exception:
        return str(k)


# ⚠ 유형 목록·자료집 종류를 여기서 다시 적지 않는다. 내부자료 목록
#    (refr_unified_panel)이 단일 소스이고, 두 곳에 적으면 한쪽만 고쳐져
#    콤보와 목록이 어긋난다.
try:
    from refr_unified_panel import _REF_TYPES as _USER_TYPES
except Exception:
    _USER_TYPES = ('NOTE', 'OTHER')

# 우리가 쓴 글이 담기는 자료집 종류(`sys_ref_source.src_type`).
# 이 탭의 목록은 수입 저작(문답·사전)이 아니라 이것만 뒤진다.
_STUDY_TYPE = 'STUDY'


WORD_WARN_KEY = {'그림·도형': 'REFV_WW_PIC', '글상자': 'REFV_WW_BOX', '각주': 'REFV_WW_FOOT',
                 '칸 합치기': 'REFV_WW_MERGE', '표 안의 표': 'REFV_WW_NEST', '머리글·바닥글': 'REFV_WW_HF'}


def docx_app_ok():
    """이 PC 에 .docx 를 여는 프로그램이 있나(워드·한글·WPS·LibreOffice … 무엇이든) — 레지스트리를 본다."""
    try:
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                                r'Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.docx\UserChoice') as k:
                if winreg.QueryValueEx(k, 'ProgId')[0]:
                    return True
        except OSError:
            pass
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, '.docx') as k:
            prog = winreg.QueryValueEx(k, '')[0]
        if not prog:
            return False
        with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, prog + r'\shell') as _k:
            return True
    except Exception:                                     # noqa: BLE001
        return False


def word_edit_path(ref_id, lang, title=''):
    """워드 왕복 파일 자리 — 앱 폴더 `word_edit/` · 이름에 제목 앞부분(사람이 알아보게)."""
    import os
    import re as _re
    d = os.path.join(os.path.dirname(os.path.abspath(appdb.__file__)), 'word_edit')
    os.makedirs(d, exist_ok=True)
    safe = _re.sub(r'[\\/:*?"<>|\s]+', '_', (title or '').strip())[:40] or 'note'
    return os.path.join(d, '%s_%d_%s.docx' % (safe, int(ref_id), str(lang or 'KO').upper()))


class RefDetailView(ttk.Frame):
    def __init__(self, parent, db_path, lang_getter=None,
                 on_verse_jump=None, show_list=True, on_entity_jump=None,
                 seed_entity_getter=None, on_saved=None, on_book_jump=None,
                 on_my_edit=None, on_ai=None, **kw):
        """show_list=False 면 **왼쪽 목록·검색을 안 만든다.**

        ★ 2026-08-10 — P4 주요용어 안에서도 같은 화면으로 읽고 쓰게 하려고 낸 스위치다.
          이 위젯을 쪼개 부품으로 빼는 대신 스위치 하나를 달았다 — 잘 도는 화면을
          가르면 표시 방법이 둘로 갈릴 위험이 크고, 여기 붙은 저장·삭제·연결·영상
          로직이 전부 딸려 나온다. 목록만 감추면 같은 코드가 두 자리에서 그대로 돈다.
        """
        super().__init__(parent, **kw)
        self.db_path      = db_path
        self.lang_getter  = lang_getter or (lambda: 'KO')
        self.on_verse_jump = on_verse_jump
        self.on_entity_jump = on_entity_jump
        self.on_book_jump  = on_book_jump   # 도서·설교 유닛 → P1 읽기 화면
        # 이 뷰가 어느 용어 안에 심겨 있으면, 새로 쓴 글은 그 용어에 저절로 걸린다.
        # 「헤세드를 보다가 메모를 썼는데 헤세드에 안 붙는다」를 막는다.
        self.seed_entity_getter = seed_entity_getter
        self.on_saved     = on_saved      # 저장·삭제 뒤 바깥 목록을 다시 그리라는 신호
        self.on_my_edit   = on_my_edit    # [My Edit] — 내 것 총괄 창(주면 단추가 생긴다)
        # ★ [AI] — 연구자료를 닻으로 AI 도우미(303차). **주면 단추가 생긴다.**
        self.on_ai        = on_ai
        self._show_list   = show_list

        self._mode      = _MODE_EMPTY
        self._cur_unit  = None      # 보고 있는 sys 글
        self._cur_user  = None      # 보고 있는 내 자료
        self._new_vid   = None      # 새로 쓸 때 걸 구절
        self._player    = None      # EmbeddedPlayer — 한 번 만들면 살려 둔다
        self._fields    = {}

        self._syncing = False
        self._build()
        if self._show_list:
            self._search()
        self.bind('<Destroy>', self._on_destroy)

    # ── 화면 ──────────────────────────────────────────────────────
    def _build(self):
        # 버튼은 항상 상단 (CLAUDE.md §0)
        # ⚠ 높이를 못 박는다 — 단추가 들고 날 때마다 이 줄이 몇 px 오르내리면 아래 화면 전체가 흔들린다.
        bar = ttk.Frame(self, height=30)
        bar.pack(fill='x', padx=6, pady=(6, 2))
        bar.pack_propagate(False)
        # ★★ 2026-10-15 docs/1.txt 91-1 — 위 띠 차례(사용자 지시 그대로):
        #   검색창 · 찾기 · X · 연결자산 표시(구절 칩) ……(긴 여백)…… 추가 · 수정 · 삭제 …… AI 분석 · 언어 …… My Edit …… Word편집 · to Word · from Word
        #   · 모든 단추 = My Edit 모양(`ui_theme.flat_btn`) · [연결] 걷음(My Edit 와 같은 일) · 「AI」→「AI 분석」 ·
        #     「+ 추가하기」·「수정하기」→ 추가 · 수정 · 「내 연구노트로 복사하여 수정하기」 단추 걷음 → [수정]이 맡는다.
        #   ⚠ 오른쪽 무리는 `side='right'` 로 **오른쪽 끝부터** 붙인다(차례를 거꾸로) — 들고 나는 단추(Word편집·원본)는
        #     `after=` 로 제자리에 다시 끼운다.
        self._lang_var = tk.StringVar(value=(self.lang_getter() or 'KO').upper())
        self._lang_cb = None
        if self._show_list:
            self._q_var = tk.StringVar()
            import search_row
            _sr = search_row.build(bar, self._q_var, self._search, self._clear_search,
                                   db_path=self.db_path, width=24, expand=False)
            for _k in ('search', 'clear'):          # 크기를 My Edit 와 같게(이 화면만)
                try:
                    _sr[_k].config(**{k: v for k, v in _flat().items() if k != 'cursor'})
                except Exception:
                    pass
            self._clr_btn = None
            # ★ **구절 거르개 칩**(연결자산 표시) — 걸려 있을 때만 보인다(누르면 풀린다).
            #   ★ 2026-10-15 91 후속 — **자리를 늘 비워 둔다**(칩이 들고 나도 오른쪽 단추가 안 움직인다).
            self._chip_slot = ttk.Frame(bar, width=150, height=26)
            self._chip_slot.pack_propagate(False)
            self._chip_slot.pack(side='left', padx=(6, 0))
            self._vchip = tk.Button(self._chip_slot, text='', command=self.clear_verse_filter,
                                    **_flat(bg=self._C('accent_bg', '#D6EAF8'), fg=self._C('accent', '#1A5276')))
        # ── 오른쪽 무리(오른쪽 끝부터) — 언어 · My Edit · to Word · from Word ──
        self._fromw_btn = tk.Button(bar, text=i18n.t('REFV_B_FROMWORD', 'from Word'),
                                    command=self._word_import, **_flat())
        self._fromw_btn.pack(side='right', padx=(2, 0))
        self._wexp_btn = tk.Button(bar, text=i18n.t('REFV_B_TOWORD', 'to Word'), state='disabled',
                                   command=self._word_export, **_flat())
        self._wexp_btn.pack(side='right', padx=(2, 2))
        self._medit_btn = tk.Button(bar, text=i18n.t('OE_BTN', 'My Edit'), command=self._open_my_edit, **_flat())
        self._medit_btn.pack(side='right', padx=(2, 18))
        self._build_lang_cb(bar).pack(side='right', padx=(4, 18))
        # ── 왼쪽 무리(차례대로 · 자리 고정 · 2026-10-15 91 후속 사용자 2·4) ──
        #   (칩 자리) · 추가 · 삭제 ·(공백)· 수정 · Word편집 ·(공백)· AI 분석 · [원본 가리기/표시하기 자리]
        #   ⚠ 들고 나는 단추를 pack_forget 하지 않는다 — 자리가 흔들린다. 쓸 수 없을 때는 흐리게만.
        self._add_btn = tk.Button(bar, text=i18n.t('COMMON_ADD', '추가'), command=self._add_click, **_flat())
        self._add_btn.pack(side='left', padx=(12, 2))
        self._del_list_btn = tk.Button(bar, text=i18n.t('COMMON_DELETE', '삭제'), state='disabled',
                                       command=self._delete, **_flat())
        self._del_list_btn.pack(side='left', padx=(2, 2))
        self._del_btn = self._del_list_btn          # 옛 이름(폼 모드 삭제) — 같은 단추
        # [수정] — 읽는 중이면 수정 · 고치는 칸이면 [저장]으로 바뀐다(같은 자리)
        self._save_btn = tk.Button(bar, text=i18n.t('COMMON_EDIT', '수정'), state='disabled',
                                   command=self._edit_click, **_flat())
        self._save_btn.pack(side='left', padx=(16, 2))
        # ★ 2026-10-15 사용자 「워드 편집은 제거하자」 — [Word편집] 걷음([to Word]·[from Word] 는 남는다)
        self._ai_btn = None
        if callable(getattr(self, 'on_ai', None)):
            self._ai_btn = tk.Button(bar, text=i18n.t('PFV_NOTE_AI', 'AI 분석'), command=self._open_ai, **_flat())
            self._ai_btn.pack(side='left', padx=(16, 2))
        # 원본 가리기/표시하기 — 배포 연구노트를 수정한 내 것일 때만(`_sync_copy`) · **자리는 늘 비워 둔다**
        self._orig_slot = ttk.Frame(bar, width=220, height=26)
        self._orig_slot.pack_propagate(False)
        self._orig_slot.pack(side='left', padx=(6, 0))
        self._orig_f = tk.Frame(self._orig_slot)
        self._orig_btns = {}
        for _hv, _k, _t in ((True, 'CO_HIDE', '원본 가리기'), (False, 'CO_SHOW', '원본 표시하기')):
            _b = tk.Button(self._orig_f, text=i18n.t(_k, _t), command=lambda h=_hv: self._set_orig(h), **_flat())
            _b.pack(side='left', padx=(0, 2))
            self._orig_btns[_hv] = _b

        def _fit_orig():
            try:
                self._orig_slot.config(width=sum(b.winfo_reqwidth() + 2 for b in self._orig_btns.values()) + 4)
            except Exception:                             # noqa: BLE001
                pass
        self.after_idle(_fit_orig)
        self._tag_btn = None                          # [연결] 걷음(2026-10-15 · My Edit 와 같은 일)
        self._copy_btn = None                         # 「복사하여 수정하기」 걷음 — [수정]이 맡는다
        self._draft_src = None                        # 배포 연구노트를 수정 중인 초안(저장 전 DB 0)

        # 좌: 검색 + 목록 / 우: 내용 — 엔티티 탭과 같은 얼개.
        # P2 에서 밀어 넣는 길과 이 탭에서 직접 찾는 길을 한 화면이 함께 받는다.
        pw = ttk.PanedWindow(self, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=6, pady=2)

        if not self._show_list:
            # 목록 없이 뷰만. 연결 칸은 왼쪽에 좁게 두고 본문이 나머지를 쓴다.
            lnk = ttk.Frame(pw)
            pw.add(lnk, weight=1)
            # (2026-08-14) 언어 콤보는 **상단 bar 로 올라갔다.**
            self._build_link_panel(lnk)
            self._body = ttk.Frame(pw)
            pw.add(self._body, weight=3)
            self._build_body()
            self.clear()
            return

        side = ttk.Frame(pw)
        pw.add(side, weight=1)
        # (2026-08-13) 언어 콤보·검색창은 **상단 bar 로 올라갔다.** 여기 있던 줄을 없앤다.
        # ⚠ 목록은 위쪽만 쓴다 — 아래가 연결 칸이다(2026-08-10 사용자 지시).
        #   위아래 PanedWindow 라 목록이 길어질 때 사용자가 손잡이로 넓힐 수 있다.
        # ★ 2026-10-15 91 후속 7 — 목록 바로 위 **유형 체크**(목록에 실제로 있는 유형만 · 하나뿐이면 감춘다)
        self._kind_f = ttk.Frame(side)
        self._kind_f.pack(fill='x', pady=(0, 2))
        self._kind_off = set()
        self._kind_shown = ()
        lpw = ttk.PanedWindow(side, orient='vertical')
        lpw.pack(fill='both', expand=True)
        self._lpw = lpw
        lf = ttk.Frame(lpw)
        lpw.add(lf, weight=2)
        # ⚠ 「구분」 칸이 따로 있어야 한다(2026-08-10 사용자 지시). 목록은 표가 둘이라
        #   SYS(배포되는 우리 글)와 USER(내 자료)가 섞여 있는데, 「유형」 칸만으로는
        #   그 둘이 안 갈린다 — 연구는 자료집 이름이고 나머지는 내 자료의 갈래다.
        # 「연결대상」 칸 추가 (2026-08-19 0.txt ⑧) — 이 글을 쓴 도서/설교/교리 유닛.
        #   옛 글은 body_unit_id 가 비어 공란이 정상이다(칸 자체가 2026-08-16 신설).
        # ⚠ **「연결대상」 칸은 없앴다** (2026-08-21 사용자 —
        #   「복수입력이기 때문에 이상하다」). 연결은 여러 개인데 한 칸에는
        #   하나밖에 못 담아, 나머지를 감춘 채 그것이 전부인 양 보였다.
        #   연결은 오른쪽 본문 상단 표시줄과 [연결] 창이 온전히 보여 준다.
        self._list = ttk.Treeview(lf, columns=('scope', 'kind', 'title'),
                                  show='headings', selectmode='browse', height=8)
        self._list.heading('scope', text=i18n.t('REFV_SCOPE', '구분'))
        self._list.heading('kind',  text=i18n.t('COMMON_TYPE', '유형'))
        self._list.heading('title', text=i18n.t('COMMON_TITLE', '제목'))
        self._list.column('scope', width=42, minwidth=38, stretch=False, anchor='center')
        self._list.column('kind',  width=54, minwidth=48, stretch=False, anchor='center')
        self._list.column('title', width=250, minwidth=90)
        # sys/user 는 「구분」 칸이 이미 가른다 — 항목은 기본색(2026-08-18
        #   목록 표준 전수 정리), 빈 줄만 흐린 색(역할 — _search 가 렌더마다 재적용).
        self._list.tag_configure('empty', foreground=self._C('fg_dim', '#95A5A6'))
        lvsb = ttk.Scrollbar(lf, orient='vertical', command=self._list.yview)
        self._list.configure(yscrollcommand=lvsb.set)
        lvsb.pack(side='right', fill='y')
        self._list.pack(fill='both', expand=True)
        self._list.bind('<<TreeviewSelect>>', self._on_list_select)
        # ★ 2026-10-15 91 후속 6 — 목록 아래 「연결 N건」 줄은 걷었다(화면에 안 붙인다 · 읽기 문은 그대로 산다)
        lnk = ttk.Frame(side)
        self._build_link_panel(lnk)

        # 내용 — 세 위젯을 만들어 두고 갈아 끼운다
        self._body = ttk.Frame(pw)
        pw.add(self._body, weight=3)
        self._build_body()
        self.clear()

    # ── 표시 언어 ─────────────────────────────────────────────────
    # ⚠ 전에는 이 콤보가 **본문에만** 걸렸고, 그나마 sys 글을 볼 때만 상단에 나타났다
    #   가 내 자료로 옮기면 [수정하기]로 바뀌어 사라졌다. 상단이 자료마다 달라 보인
    #   원인이 이것이다. 이제 **탭 전체의 표시 언어**이므로 늘 같은 자리에 있다.
    def _build_lang_cb(self, parent):
        """표시 언어 콤보 — 목록은 **고정**이고 이름은 그 언어의 자기 이름으로.

        ⚠ 예전에는 `['KO','EN','ZH',…]` 코드를 그대로 보였다. 코드는 그 언어를
          쓰는 사람에게 아무것도 알려 주지 않는다 — `한국어`·`日本語` 로 적는다.
        ★ **이 콤보는 「무슨 언어로 쓸까」도 겸한다** — `_save` 가 이 값으로 새 글의
          `lang_code` 를 정한다. 아직 일본어 글이 없어도 골라야 첫 일본어 글을 쓴다.
        """
        import lang_combo
        self._lang = lang_combo.LangCombo(
            parent, db_path=self.db_path, on_change=lambda _c: self._on_view_lang(),
            width=13, gap=0, pady=0,
            default_lang=(self.lang_getter() or 'KO').upper(),
            # ⚠ 한 클래스가 **두 화면**이다 — P4 자료(목록 있음)와 주요용어 ▸
            #   내부자료(목록 없음). 열쇠를 갈라야 따로 기억한다.
            key='LANGSEL_REF' if self._show_list else 'LANGSEL_REF_EMB')
        # ★ **콘텐츠 축**(히브리어 포함) — 자료를 어느 언어로 읽을까다
        #   (1.txt 8-3). 앱 표시 언어 축과 다르다.
        self._lang.set_items(lang_combo.content_items())
        self._lang_cb = self._lang.combo
        self._lang_var.set(self._lang.lang())
        return self._lang_cb

    def _view_lang(self):
        """이 탭이 지금 쓰는 언어. 밖에서 받은 `lang_getter` 는 첫 기본값일 뿐이다."""
        lc = getattr(self, '_lang', None)
        if lc is not None:
            cur = lc.current()
            if cur and cur[1]:
                return str(cur[1]).upper()
        return (self._lang_var.get() or self.lang_getter() or 'KO').upper()

    def _list_lang(self):
        """**목록**이 쓰는 언어 = 앱 설정 언어. **콤보를 안 따른다.**

        ★★★ 2026-09-22 (1.txt 8-3) — 그전에는 콤보 하나가 목록·본문을 함께
          몰아서, 본문을 러시아어로 읽으려고 콤보를 바꾸면 **왼쪽 목록이
          통째로 러시아어 목록으로 바뀌었다.** 사용자가 고른 설정 언어가
          그 순간 사라진 것이다.
        ⇒ **목록은 설정 언어로 못 박고**(그 언어로 있는 자료만 보인다),
          콤보는 **고른 글의 본문만** 바꾼다. 「KO 로 번역된 것을 읽다가 그
          자료의 EN 판을 읽을 수 있다. 그러나 KO 판이 없는 자료는 애초에
          목록에 없다」가 사용자가 적은 규칙 그대로다.
        """
        return (self.lang_getter() or 'KO').upper()

    def _on_view_lang(self):
        """언어를 바꾸면 **본문과 연결 표시줄만** 따라온다.

        ★★★ 2026-09-22 (1.txt 8-3) — 그전에는 여기서 `self._search(...)` 를
          불러 **왼쪽 목록을 그 언어로 다시 그렸다.** 그래서 러시아어 본문을
          한 번 보면 목록이 통째로 러시아어 목록이 되어, 사용자가 고른 설정
          언어(예: KO)가 그 순간 사라졌다 — 사용자 신고 그 자리.
        ⇒ **목록의 언어는 `_list_lang()`(설정 언어) 하나**다. 이 콤보는
          「고른 글을 어느 언어로 읽을까」만 정한다.
        ⚠ 옛 책 콤보를 지키던 줄은 없앴다 — 입력칸을 걷었다(2026-08-21).
        """
        if self._cur_unit:
            self._reload_text()
        elif self._cur_user and self._mode == _MODE_TEXT:
            # ★ 내 자료도 **그 언어판으로 다시 그린다**(2026-08-14
            #   `user_ref_text`). ⚠ 고치는 중(`_MODE_FORM`)에는 건드리지
            #   않는다 — 쓰던 글이 날아간다.
            self.show_user(self._cur_user, _from_list=True)
            return
        self._link_load()

    def _foot_order(self):
        """아래 고정 칸의 차례를 맞춘다 — 추천 줄 → 연결구절/용어 → 도서·설교 콤보(보이는 것만)."""
        ws = [getattr(self, n, None) for n in ('_sug', '_link_strip', '_book_row')]
        vis = []
        for w in ws:
            try:
                if w is not None and w.winfo_manager():
                    vis.append(w)
            except Exception:                             # noqa: BLE001
                pass
        for w in vis:
            w.pack_forget()
        for w in vis:
            w.pack(fill='x', pady=(0, 2))

    def _set_title(self, text, lang=None):
        """제목 라벨 — RTL 이면 **오른쪽 붙임**(1.txt 8-3).

        ⚠ 한 번 오른쪽으로 붙인 라벨은 **되돌려야 한다** — 안 그러면 아랍어
          글을 한 번 본 뒤 한국어 글이 오른쪽에 붙은 채로 남는다(§7-3 에서
          겪은 「상태를 안 되돌린 자리」와 같은 갈래).
        """
        try:
            import bidi as _bd
            # ★ **언어 코드가 정한다**(2026-09-23) — 원어를 인용한 한국어
            #   제목이 오른쪽에 붙던 자리다.
            s, opt = _bd.label(text or '', lang)
            self._title.config(text=s, justify=opt.get('justify', 'left'),
                               anchor=opt.get('anchor', 'w'))
        except Exception:                                 # noqa: BLE001
            self._title.config(text=text or '')

    def _sync_web_rows(self):
        """외부 수집일 때만 지은이·출처·URL 칸을 보인다(내가 작성·AI 작성은 구분값만 · docs/1.txt 2-2)."""
        try:
            on = self._origin_map.get(self._fields['ref_origin'].get()) == 'WEB'
        except Exception:                                   # noqa: BLE001
            on = True
        for w in getattr(self, '_web_rows', []):
            try:
                w.grid() if on else w.grid_remove()
            except Exception:                               # noqa: BLE001
                pass

    # ── 읽었음 (2026-10-16 docs/1.txt 2-1) ─────────────────────────────
    def _hide_read_btn(self):
        try:
            self._read_btn.pack_forget()
        except Exception:                                   # noqa: BLE001
            pass

    def _sync_read_btn(self):
        """지금 연 연구 글의 읽음 상태대로 단추를 보인다(누를 때만 바뀐다)."""
        uid = getattr(self, '_cur_unit', None)
        if not uid:
            self._hide_read_btn()
            return
        _when = ''
        try:
            import db_read_state as _rs
            with appdb.connect(self.db_path) as _c:
                _rs.ensure(_c)
                _r = _c.execute("SELECT read_at FROM user_book_read WHERE kind=? AND unit_id=?",
                                (_rs.REF, uid)).fetchone()
            self._read_on = _r is not None
            _when = str(_r[0] or '')[:10] if _r else ''
        except Exception:                                   # noqa: BLE001
            self._read_on = False
        on = self._read_on
        # ★ 2026-10-16 사용자 「"읽었음 표시하기" · 클릭하면 "2025-10-1 읽었음"」 — 언제 읽었는지가 보인다(다시 누르면 푼다)
        self._read_btn.config(
            text=(i18n.t('REFV_READ_AT', '%s 읽었음').replace('%s', _when).strip()) if on
            else i18n.t('REFV_READ', '읽었음 표시하기'),
            fg=self._C('accent', '#1A5276') if on else self._C('fg_dim', '#888'))
        if not self._read_btn.winfo_manager():
            # ★ 맨 오른쪽 기준(사용자 「제목 길이에 따라 들쭉날쭉」) — 부제보다 오른쪽 끝에
            self._read_btn.pack(side='right', padx=(10, 0), before=self._sub)

    def _toggle_read(self):
        uid = getattr(self, '_cur_unit', None)
        if not uid:
            return
        try:
            import db_read_state as _rs
            with appdb.connect(self.db_path) as _c:
                if self._read_on:
                    _rs.unmark(_c, uid, kind=_rs.REF)
                else:
                    _rs.mark(_c, uid, kind=_rs.REF)
        except Exception as e:                              # noqa: BLE001
            print('[ref read] %s' % e)
        self._sync_read_btn()
        # 목록 줄의 ✓ 를 그 자리에서 맞춘다
        _iid = f'A|{uid}'
        try:
            if self._list.exists(_iid):
                _v = list(self._list.item(_iid, 'values'))
                t = str(_v[-1])
                t = t[2:] if t.startswith('✓ ') else t
                _v[-1] = ('✓ ' + t) if self._read_on else t
                self._list.item(_iid, values=_v)
        except Exception:                                   # noqa: BLE001
            pass

    def _build_body(self):
        """본문 칸 — 글·폼·영상 셋을 만들어 두고 갈아 끼운다."""
        # ★ 제목·부제는 **본문 머리**에 둔다 (2026-08-13). 상단 bar 에서 내려온 것이다.
        #   모드를 갈아 끼워도 자리가 흔들리지 않게 `_body` 에 직접 붙인다.
        head = ttk.Frame(self._body)
        head.pack(fill='x', pady=(0, 2))
        self._title = ttk.Label(head, text='', font=('', 11, 'bold'))
        self._title.pack(side='left')
        self._sub = ttk.Label(head, text='',
                              foreground=self._C('fg_dim', '#888'))
        # ★ 2026-10-16 사용자 「제목 오른쪽 라벨들이 제목 길이에 따라 들쭉날쭉 — 맨 오른쪽을 기준으로」
        self._sub.pack(side='right', padx=6)
        # ★ 2026-10-16 (docs/1.txt 2-1 · 사용자 「목록을 클릭했는데 체크 표시를 한다 · 본문 제목 오른쪽에
        #   "읽었음" 버튼」) — 읽음은 **사람이 누를 때만**. 연구 글(배포 자료)을 볼 때만 보인다.
        try:
            import ui_theme as _ut
            _fb = _ut.flat_btn()
        except Exception:                                   # noqa: BLE001
            _fb = {}
        self._read_btn = tk.Button(head, text='', command=self._toggle_read, **_fb)
        self._read_on = False
        # ★ 2026-10-15 사용자 「본문 상단이 매우 복잡하다」 — 추천 줄 · 연결구절/용어 줄 · 도서·설교 콤보를
        #   **본문 칸 바로 아래 고정 칸**으로 내렸다(굴리지 않아도 늘 보인다 · 차례 = 추천 → 연결 → 도서·설교).
        #   ⚠ `side='bottom'` 을 본문보다 **먼저** 담아야 본문이 늘어나도 밀려나지 않는다.
        self._foot = ttk.Frame(self._body)
        self._foot.pack(side='bottom', fill='x', pady=(2, 0))

        # ★ 연결대상 표시 (옛 자리 = 본문 상단) (2026-08-19 사용자 — 「화면이 좌우로
        #   길다. 입력창은 왼쪽 하단, 표시는 오른쪽 본문 상단」).
        #   구속사연결 화면처럼 **약명만 유형별로 줄줄이** — 클릭 기능 없음
        #   (추가/빼기는 왼쪽 하단 입력창 몫). 없으면 통째로 숨긴다.
        self._link_strip = tk.Text(self._foot, height=2, wrap='word', bd=0,
                                   state='disabled', cursor='arrow',
                                   bg=self._C('panel', '#F4F8FB'),
                                   padx=8, pady=4)
        self._strip_retag()
        if theme_font:
            try:
                theme_font.register(self._link_strip, self.db_path, 'meta')
            except Exception:
                pass
        try:
            import verse_ref_suggest as _VRS
            self._sug = _VRS.SuggestBar(self._foot, db_path=self.db_path,
                                        on_link=self._sug_link, on_dismiss=self._sug_dismiss,
                                        lang_getter=self._view_lang, instant=True)

            def _place_sug(w):
                w.pack(fill='x', pady=(0, 2))
                self._foot_order()
            self._sug.set_place(_place_sug)
        except Exception as e:                            # noqa: BLE001
            print('[refview suggest] %s' % e)
            self._sug = None
        # ★ 도서·설교 연결은 **콤보로** (2026-08-19 사용자 — 유닛 라벨이
        #   「Book1, No-10…」처럼 암호 같아 줄줄이 열거가 안 읽힌다. 구절·용어만
        #   나열하고, 도서·설교는 그 아래 눈에 안 띄는 표준 콤보 하나로).
        self._book_row = ttk.Frame(self._foot)
        ttk.Label(self._book_row, text=i18n.t('REFV_KIND_BOOK', '도서·설교집'),
                  foreground=self._C('fg_dim', '#888')).pack(side='left', padx=(8, 4))
        # 폭 45자 (2026-08-19 사용자 — 「5자 정도 더 표시되도록」. 자름도 45자)
        self._book_combo = ttk.Combobox(self._book_row, state='readonly', width=45)
        self._book_combo.pack(side='left', pady=1)
        # ★ 콤보에서 고른 도서·설교의 P1 읽기 화면으로 (2026-08-19 사용자 —
        #   「클릭한 후 해당 p1화면으로 이동할 수 있는 버튼 하나 추가하자」).
        #   콜백이 없는 자리(관리자 등)에서는 버튼을 만들지 않는다.
        self._book_ids = []
        if self.on_book_jump:
            tk.Button(self._book_row, text=i18n.t('REFV_BOOK_GO', '▶ 보기'),
                      bg=self._C('panel', '#F4F6F7'), fg=self._C('fg', '#333'),
                      bd=1, padx=6,
                      command=self._book_jump).pack(side='left', padx=(4, 0))

        # ⚠ 아래 본문 프레임 생성부는 **_build_body 의 몸통**이다 — 메서드 def 를
        #   이 위에 끼우면 여기부터가 그 메서드로 삼켜진다(2026-08-19 실제 사고:
        #   `_strip_retag` 안으로 들어가 **렌더마다 본문 위젯이 새로 만들어져**
        #   목록을 클릭해도 내용이 영영 안 열렸다. 밤 12차와 같은 계열).
        self._txt_f = ttk.Frame(self._body)
        vsb = ttk.Scrollbar(self._txt_f, orient='vertical')
        self._txt = tk.Text(self._txt_f, wrap='word', bd=0, padx=10, pady=8,
                            bg=self._C('panel', '#FCFCFC'),
                            fg=self._C('fg', '#222'),
                            yscrollcommand=vsb.set)
        vsb.config(command=self._txt.yview)
        vsb.pack(side='right', fill='y')
        self._txt.pack(fill='both', expand=True)
        if theme_font:
            try:
                theme_font.register(self._txt, self.db_path, 'ref')
            except Exception:
                pass

        self._form_f = ttk.Frame(self._body)
        # 영상 뒤판만은 의도된 검정(레터박스) — dark_bg 역할로 테마를 따른다
        _vbg = self._C('dark_bg', '#111')
        self._video_f = tk.Frame(self._body, bg=_vbg)

    @staticmethod
    def _C(role, fallback):
        try:
            import ui_theme
            return ui_theme.C(role)
        except Exception:
            return fallback

    def _strip_retag(self):
        """연결대상 표시줄 태그 색 — **그릴 때마다 그 시점 테마로** (§36-5b.
        2026-08-19 사용자 「배경색과 무관하게 잘 보여야 한다. 하드코딩 금지」)."""
        try:
            self._link_strip.config(bg=self._C('panel', '#F4F8FB'))
            self._link_strip.tag_configure('k', foreground=self._C('fg_dim', '#888'))
            self._link_strip.tag_configure('v', foreground=self._C('accent', '#1A5276'))
        except Exception:
            pass

    # ── 연결 칸 — **보기와 넣기를 한 자리에서** (2026-08-10 사용자 지시) ──────
    # ⚠ 전에는 아래에 「연결된 구절」 표가 따로 있고 폼 안에 또 편집기가 있었다.
    #   같은 것이 두 군데라 무엇이 진짜인지 알 수 없었다. 하나로 합친다.
    # ⚠ **sys 자료(작성자료)는 여기서 못 고친다.** 그건 관리자 화면 몫이다.
    _ENT_TYPES = ('PERSON', 'PLACE', 'TERM', 'DOCTRINE', 'GROUP', 'IDOL',
                  'NATION', 'FEAST', 'OBJECT', 'SYSTEM')

    def _build_link_panel(self, parent):
        wrap = ttk.Frame(parent)
        wrap.pack(fill='x', pady=(6, 0))
        self._link_lbl = ttk.Label(wrap, text='',
                                   foreground=self._C('fg_dim', '#555'))
        self._link_lbl.pack(anchor='w')

        # ★ **입력칸은 걷었다** (2026-08-21 사용자 지시 「옛 입력칸 걷어라」).
        #   그전에는 구절·용어·도서 세 줄과 빼기 콤보가 여기 있었는데,
        #   [연결] 창이 같은 일을 다 하면서 **입력이 둘·저장소가 둘**이 됐다.
        #   이제 연결을 넣고 빼는 자리는 **[연결] 창 하나**고,
        #   이 칸은 「지금 몇 건이 걸렸나」만 보이는 요약 라벨로 남긴다.
        #   ⚠ 보이는 것만 없앱다 — 읽기(`_link_load`·`_link_redraw`·표시줄)는
        #     그대로 산다. 그것까지 지우면 본문 위 표시줄이 함께 죽는다.
        self._lnk_edit = []          # 잠금 대상 없음(입력칸이 없다)
        self._lnk_rows = []
        self._lnk_from_link = set()
        self._lnk_books = []

        # ★★★ 315차 — **구절약명 추천 줄**(사용자 지시 「사용자 화면도 대상」).
        #   ⚠ 요약 라벨 **아래**, 연결 목록 **위**. 찾은 것이 없으면 스스로 숨는다.
        # ★ 2026-10-13 docs/1.txt 84-2 — 추천 줄은 **오른쪽 본문 위, 연결 구절 줄 바로 아래**로 옮겼다
        #   (사용자 「왼쪽 하단에 가려져서 없는 줄 알았다」) — `_build_body` 가 짓는다.
        if not hasattr(self, '_sug'):
            self._sug = None

    # ⚠ `_link_fill_books`(책 콤보 채우기)는 입력칸과 함께 걷었다 —
    #   책 고르기는 이제 [연결] 창이 한다(2026-08-21).

    # ── 구절약명 추천 (315차) ─────────────────────────────────────
    def _sug_soon(self, ms=700):
        """고치는 칸에서 치거나 붙여 넣은 뒤 잠깐 멈추면 추천을 다시 뽑는다."""
        try:
            if getattr(self, '_sug_job', None):
                self.after_cancel(self._sug_job)
        except Exception:                                     # noqa: BLE001
            pass
        self._sug_job = self.after(ms, self._sug_refresh)

    def _sug_refresh(self):
        """보고 있는 **내 자료**의 본문에서 추천을 다시 뽑는다.

        ⚠⚠ **sys 자료는 안 그린다** — 연결 입력이 잠긴 화면이라 누를 수 없는
          추천이 된다(§0-1 빈 서랍 금지).
        ⚠ 연결 칸이 아직 없을 수 있다(지연 빌드) — 그때는 아무 일도 안 한다.
        """
        bar = getattr(self, '_sug', None)
        if bar is None:
            return
        rid = getattr(self, '_cur_user', None)
        if not rid or getattr(self, '_cur_unit', None):
            bar.clear()
            self._sug_mark()
            return
        lang = self._view_lang()
        body = ''
        have = set()
        have_o = set()
        try:
            import db_user_ref_schema as U
            with appdb.connect(self.db_path) as conn:
                _t, body, _used = U.fetch_text(conn, int(rid), lang)
                # ★ 2026-10-16 — 고치는 칸이 열려 있으면 **그 칸의 글**(저장 전이라도 붙여 넣은 약명이 바로 추천된다)
                _ed = (getattr(self, '_fields', None) or {}).get('summary') \
                    if isinstance(getattr(self, '_fields', None), dict) else None
                try:
                    if _ed is not None and _ed.winfo_exists():
                        body = _ed.get('1.0', 'end')
                except Exception:                         # noqa: BLE001
                    pass
                # ★ 84-2 — LIVE 뿐 아니라 사람이 뗀 것·[남은 추천 모두 지우기]로 지운 것도 「이미 다룬 것」
                have = U.all_coords(conn, int(rid))
                # ★ 2026-10-25 원어 — 이미 이은 용어·원어(사람이 뗀 것·지운 추천 포함)
                have_o = {('ENTITY', a) for a, _b in U.all_coords(conn, int(rid), 'ENTITY')} |                          {('LEMMA', a) for a, _b in U.all_coords(conn, int(rid), 'LEMMA')}
                try:
                    import ref_doc as _RD
                    body = (body or '') + '\n' + _RD.all_cells_text(conn, 'USER', int(rid), lang)
                except Exception:                         # noqa: BLE001
                    pass
        except Exception:                                     # noqa: BLE001
            body = ''
        bar.load(body or '', lang, have, have_orig=have_o)
        # ★ 2026-10-13 docs/1.txt 84 — 추천된 약명이 본문 어디 있는지 형광색으로(본문이 다 그려진 뒤)
        self.after_idle(self._sug_mark)

    def _sug_mark(self):
        """추천 줄에 남은 약명을 본문(읽기 칸·고치는 칸)에서 찾아 형광색으로 칠한다 · 추천이 없으면 지운다."""
        bar = getattr(self, '_sug', None)
        rows = list(getattr(bar, '_rows', []) or []) if bar is not None else []
        bg = self._C('warning_bg', '#FCF3CF')
        for w in (getattr(self, '_txt', None), (self._fields or {}).get('summary')
                  if isinstance(getattr(self, '_fields', None), dict) else None):
            if w is None:
                continue
            try:
                if not w.winfo_exists():
                    continue
                w.tag_remove('sugmark', '1.0', 'end')
                w.tag_configure('sugmark', background=bg)
                for _a, _b, m, _k in rows:
                    m = (m or '').strip()
                    if not m:
                        continue
                    at = '1.0'
                    while True:
                        at = w.search(m, at, stopindex='end')
                        if not at:
                            break
                        end = '%s+%dc' % (at, len(m))
                        w.tag_add('sugmark', at, end)
                        at = end
                w.tag_raise('sugmark')
            except Exception:                             # noqa: BLE001
                pass

    def _sug_dismiss(self, rows):
        """[남은 추천 모두 지우기] — 연결은 안 하고 다시 안 뜨게 적어 둔다(84-2)."""
        rid = getattr(self, '_cur_user', None)
        if not rid or not rows:
            return 0
        try:
            import db_user_ref_schema as U
            with appdb.connect(self.db_path) as conn:
                import verse_ref_suggest as _VRS
                n = U.dismiss(conn, int(rid), [_VRS.link_of(r) for r in rows])
        except Exception as e:                                # noqa: BLE001
            print('[refview suggest dismiss] %s' % e)
            return 0
        self._sug_refresh()
        return n

    def _sug_link(self, rows):
        """선택한 추천을 내 자료에 **보탠다** → 보탠 수.

        ⚠ 보태기만 한다(`add_links`) — 사람이 체크해 누르는 자리다. 글을 저장할
          때의 동기화(`sync_links`)와 몫이 다르다.
        """
        rid = getattr(self, '_cur_user', None)
        if not rid or not rows:
            return 0
        n = 0
        try:
            import db_user_ref_schema as U
            with appdb.connect(self.db_path) as conn:
                # ⚠⚠⚠ **표식을 반드시 준다** — 안 적으면 「사람이 이은 것」이
                #   되어 글을 고쳐도 동기화가 건드리지 않는다(실측으로 당했다).
                import verse_ref_suggest as _VRS
                n = U.add_links(conn, int(rid), [_VRS.link_of(r) for r in rows],
                                src=U.AUTO_SRC)
        except Exception as e:                                # noqa: BLE001
            print('[refview suggest link] %s' % e)
            return 0
        try:
            self._link_load()
            self._link_redraw()      # ⚠ 그 끝이 `_sug_refresh` 를 부른다
        except Exception:                                     # noqa: BLE001
            pass
        return n

    # ── 첨부 파일 ─────────────────────────────────────────────────
    # ★ 2026-08-14 사용자 지시 — 「사용자 pc의 특정 폴더에 파일을 저장하면 좋겠다」.
    #   ⚠ **원본을 옮기거나 지우지 않는다.** 고른 파일을 `user_files/` 로 **복사**한다.
    #     앱이 사용자 폴더를 어지럽히면 안 되고, 원본이 사라지면 첨부도 끊긴다.
    #   ⚠ 이름이 겹치면 `_2`·`_3` 을 붙인다 — 덮어쓰면 남의 첨부가 사라진다.
    USER_FILES = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'user_files')

    def _attach_file(self, var):
        path = filedialog.askopenfilename(
            parent=self, title=i18n.t('REFV_ATTACH', '찾기'))
        if not path:
            return
        try:
            os.makedirs(self.USER_FILES, exist_ok=True)
            name = os.path.basename(path)
            base, ext = os.path.splitext(name)
            dest = os.path.join(self.USER_FILES, name)
            n = 2
            while os.path.exists(dest):
                name = '%s_%d%s' % (base, n, ext)
                dest = os.path.join(self.USER_FILES, name)
                n += 1
            shutil.copy2(path, dest)
            var.set(name)
        except Exception as e:
            messagebox.showwarning(i18n.t('REFV_ATTACH', '찾기'), str(e), parent=self)

    def _open_file(self, name):
        """첨부를 연다 — 파일 이름만 저장하므로 여기서 자리를 붙인다.

        ⚠ **옛 글은 폴더 이름까지 적혀 있다**(`user_files\\어쩌고.txt`). 그대로 이으면
          `user_files/user_files\\…` 가 된다 — 실제 데이터에서 잡았다.
        """
        if not name:
            return
        name = str(name).replace('\\', '/')
        base = os.path.basename(self.USER_FILES).lower()
        parts = [x for x in name.split('/') if x and x.lower() != base]
        p = os.path.join(self.USER_FILES, *parts) if parts else ''
        if not p or not os.path.exists(p):
            messagebox.showwarning(
                i18n.t('REFV_FILE', '첨부파일'),
                i18n.t('REFV_FILE_GONE', '첨부파일을 찾을 수 없습니다.'), parent=self)
            return
        try:
            os.startfile(p)                     # Windows
        except Exception:
            import webbrowser
            webbrowser.open('file:///' + p.replace(os.sep, '/'))

    # ── 자체 검색 ─────────────────────────────────────────────────
    def _clear_search(self):
        """X — 검색어를 비우고 **구절 거르개도 푼다**(전체 목록). `Esc` 로도 된다.

        ★ 2026-10-07 (51-4(5)) — 사용자 「특정 구절과 연결된 상태에서 전체 검색하기 위해서는
          구절 필터링 조건을 해제/제거하는 버튼(x버튼)」. 칩을 눌러도 같다."""
        if getattr(self, '_q_var', None) is None:
            return
        self._q_var.set('')
        if self._flt_vid:
            self._flt_off = True
        self._search()

    # ── 구절 거르개 (2026-10-07 · docs/1.txt 51-3·4(5)) ─────────────
    #   P1·P4 에서 **사람이 구절을 누르면** 그 구절에 연결된 글만 보인다.
    #   안 눌렀으면 지금 그대로(전체) · 검색어를 넣으면 거르개를 무시하고 전체에서 찾는다 ·
    #   칩/X 로 풀면 다음에 구절을 누를 때까지 전체다.
    #   연결을 세는 문은 P2 의 그것(`refr_unified_panel.verse_ref_ids`) — 두 벌을 두지 않는다.
    _flt_vid = None
    _flt_off = False

    _ctx = None          # 자리 거르개 {'vid','label','user_ids','src'} — 79-2

    def set_context(self, ctx):
        """★ 2026-10-13 docs/1.txt 79-2 — 도서 편·플랜 하루를 열면 **그 자리에 걸린 글만** 보이게 미리 건다
        (「P1 구절을 누르면 역본비교가 그 구절로 준비되는 것처럼」). 칩 = 그 자리 이름 · ✕ 로 풀린다 ·
        [+ 추가하기] 는 그 자리를 미리 걸어 새 글을 연다(도서 화면에서 걷은 [연구/설교노트] 단추의 몫).
        걸리는 글 = 그 자리의 기준 구절에 걸린 글 ∪ 그 자리에 직접 걸린 내 글(`user_ids`)."""
        ctx = dict(ctx or {})
        self._ctx = ctx
        try:
            self._flt_vid = int(ctx.get('vid')) if ctx.get('vid') else None
        except (TypeError, ValueError):
            self._flt_vid = None
        self._flt_off = False
        if not self._flt_vid:
            self._flt_vid = -1          # 기준 구절이 없는 자리 — 직접 걸린 글만(없으면 빈 목록)
        if getattr(self, '_show_list', True):
            self._search()

    def _add_click(self):
        self._draft_src = None
        c = self._ctx if (self._ctx and not self._flt_off) else None
        if c:
            self.show_new(c.get('vid'), src=c.get('src'))
        else:
            self.show_new(None)

    def set_verse(self, vid):
        """밖(P1·P4 구절 클릭)에서 구절이 바뀌었다 — 거르개를 그 구절로 다시 건다."""
        try:
            vid = int(vid) if vid else None
        except (TypeError, ValueError):
            vid = None
        self._ctx = None
        self._flt_vid = vid
        self._flt_off = False
        if getattr(self, '_show_list', True):
            self._search()

    def clear_verse_filter(self):
        if self._flt_vid and not self._flt_off:
            self._flt_off = True
            self._search()

    def _verse_filter_ids(self):
        """지금 걸린 거르개 → (sys 번호 집합, 내 글 번호 집합) · 안 걸렸으면 None."""
        if not self._flt_vid or self._flt_off:
            return None
        if (self._q_var.get() or '').strip():
            return None                      # 검색은 전체에서
        try:
            import refr_unified_panel as _ru
            sy, us = ((_ru.verse_ref_ids(self.db_path, self._flt_vid, self._list_lang()))
                      if self._flt_vid and self._flt_vid > 0 else (set(), set()))
            if self._ctx:
                us = set(us) | set(self._ctx.get('user_ids') or ())
            return sy, us
        except Exception:
            return None

    def _sync_vchip(self, active):
        chip = getattr(self, '_vchip', None)
        if chip is None:
            return
        try:
            if active:
                if self._ctx and self._ctx.get('label'):
                    lab = self._ctx['label']
                else:
                    with appdb.connect(self.db_path) as conn:
                        lab = self._ref_label(conn, self._flt_vid, self._flt_vid, _ref_lang())
                lab = str(lab or '')
                chip.config(text='%s ✕' % (lab if len(lab) <= 14 else lab[:13] + '…'))
                if not chip.winfo_manager():
                    chip.pack(side='left', fill='both', expand=True)
            else:
                chip.pack_forget()
        except Exception:
            pass

    def _sync_clear_btn(self):
        b = getattr(self, '_clr_btn', None)
        if b is None:
            return
        if self._q_var.get().strip():
            if not b.winfo_manager():
                b.pack(side='left', padx=(6, 0), before=self._add_btn)
        else:
            b.pack_forget()

    on_count = None      # 목록이 다시 그려지면 — P4 탭 배지가 다시 센다(80-2)

    def badge_count(self):
        """탭 배지 = 지금 목록 줄 수. 구절·자리 거르개가 안 걸렸으면 None."""
        if not self._flt_vid or self._flt_off or (self._q_var.get() or '').strip():
            return None
        try:
            return len([i for i in self._list.get_children() if i != 'EMPTY'])
        except Exception:
            return None

    def _search(self, select_iid=None):
        self._search_body(select_iid)
        if callable(self.on_count):
            try:
                self.on_count()
            except Exception:
                pass

    def _search_body(self, select_iid=None):
        """자료집 글과 내 자료를 함께 뒤진다. 검색어가 비면 전부 보여 준다.

        `_syncing` 은 목록을 다시 그리면서 selection_set 하면
        `<<TreeviewSelect>>` 가 다시 돌아 무한히 되도는 것을 막는다.

        ⚠ `show_list=False` 로 심은 자리에는 목록 자체가 없다 — 밖에서 글을 밀어 넣는다.
        """
        if not getattr(self, '_show_list', True):
            return
        # Treeview 태그 색은 paint 가 못 바꾼다 — 그릴 때마다 역할로(§36-5b)
        try:
            self._list.tag_configure('empty',
                                     foreground=self._C('fg_dim', '#95A5A6'))
        except Exception:
            pass
        q = self._q_var.get().strip()
        like = f'%{q}%'
        # ★ 목록은 **설정 언어** — 콤보(본문 언어)를 안 따른다(1.txt 8-3).
        lang = self._list_lang()
        rows = []
        _codes = {}   # (머리, 번호) → 유형 코드(STUDY·SERMON·REFERENCE) — 체크는 코드로 거른다
        try:
            with appdb.connect(self.db_path) as conn:
                # ★ 목록은 **고른 언어로 있는 자료만** 보인다(2026-08-10 사용자 지시).
                #   전에는 전부 보이고 제목만 폴백해서, FR 을 골라도 한국어 목록이
                #   그대로 남아 「번역이 다 돼 있다」로 보였다. 이제 FR 에 아무것도
                #   없으면 목록이 비고, 비었다고 한 줄로 말한다.
                # 제목도 그 언어의 것을 쓴다. (본문이 그 언어로 있는 글만 남으므로
                #  `unit_label` 폴백은 제목만 아직 안 옮긴 옛 글을 위한 것이다.)
                sql = ("SELECT u.ref_unit_id,"
                       " COALESCE((SELECT t.title FROM sys_ref_text t"
                       "            WHERE t.ref_unit_id=u.ref_unit_id"
                       "              AND UPPER(t.lang_code)=?"
                       "              AND t.record_status='LIVE'"
                       "              AND t.title IS NOT NULL AND t.title<>'' LIMIT 1),"
                       "          u.unit_label),"
                       " u.unit_question, s.src_type "
                       "FROM sys_ref_unit u JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id "
                       "WHERE u.record_status='LIVE' AND s.record_status='LIVE' "
                       f"  AND s.src_type='{_STUDY_TYPE}' "
                       "  AND EXISTS (SELECT 1 FROM sys_ref_text b"
                       "               WHERE b.ref_unit_id=u.ref_unit_id"
                       "                 AND (UPPER(b.lang_code)=? OR 1=?)"
                       "                 AND b.record_status='LIVE'"
                       "                 AND b.body_text IS NOT NULL AND b.body_text<>'') ")
                # ★ **검색은 언어를 가리지 않는다** (2026-08-14 사용자 지적
                #   「어떤 언어든지 입력하고 검색버튼 누르면 알아서 매칭되는 결과가
                #    표시되는 것 아닌가? 오히려 불편한것 같다」 — 맞다).
                #   ⚠ 검색어가 **비었을 때만** 고른 언어로 좁힌다. 그 규칙은 2026-08-10
                #     사용자 결정이라 살린다 — 전부 보이고 제목만 폴백하면 「번역이
                #     다 돼 있다」로 보였다.
                #        ↑제목 언어   ↑본문 언어   ↑검색 중이면 언어를 안 가린다
                args = [lang, lang, 1 if q else 0]
                if q:
                    # ⚠ **제목도 언어마다 따로 있다**(`sys_ref_text.title`).
                    #   `unit_label`(언어 없는 옛 칸)과 본문만 뒤지면, 영어 제목만
                    #   있고 영어 본문에 그 낱말이 없는 글을 못 찾는다.
                    sql += ("  AND (u.unit_label LIKE ? OR u.unit_question LIKE ? "
                            "    OR EXISTS (SELECT 1 FROM sys_ref_text t "
                            "        WHERE t.ref_unit_id=u.ref_unit_id "
                            "          AND (t.body_text LIKE ? OR t.title LIKE ?))) ")
                    args += [like, like, like, like]   # ⚠ 덮어쓰면 앞의 lang 이 날아간다
                # ★ 2026-10-13 docs/1.txt 83 — 내 연구노트로 가져와 「원본 가리기」를 고른 원본은 뺀다
                try:
                    import copy_own
                    _hid = copy_own.hidden_sys_ids(conn, 'REF')
                except Exception:
                    _hid = set()
                for r in conn.execute(sql + "ORDER BY u.sequence, u.ref_unit_id", args):
                    if r[0] in _hid:
                        continue
                    rows.append(('A', r[0], i18n.t('REFR_KIND_STUDY', '연구'),
                                 r[1] or r[2] or '', (), ''))
                    _codes[('A', r[0])] = 'STUDY'

                # 내 자료는 언어 칸이 하나뿐이라 그 값으로 곧장 가른다.
                # ⚠ 언어를 안 적어 둔 옛 글은 앱 언어의 것으로 친다 — 아무 언어에도
                #   안 걸리면 사용자가 자기 글에 다시 닿을 길이 없어진다.
                # ★ 제목은 **그 언어의 것**을 쓰고, 목록에 들지 말지도 그 언어로
                #   가른다 (2026-08-14 `user_ref_text` 신설).
                #   ⚠ 아직 언어별 본문으로 안 옮긴 옛 글은 `lang_code` 칸으로 본다 —
                #     그러지 않으면 사용자가 자기 글에 닿을 길이 없어진다.
                sql = ("SELECT a.ref_id, a.ref_type, "
                       " COALESCE((SELECT t.title FROM user_ref_text t "
                       "            WHERE t.ref_id=a.ref_id AND UPPER(t.lang_code)=? "
                       "              AND COALESCE(t.record_status,'LIVE')='LIVE' "
                       "              AND TRIM(COALESCE(t.title,''))<>'' LIMIT 1), "
                       "          a.title), a.summary, "
                       # 연결대상 (2026-08-19 0.txt ⑧) — 이 글을 쓴 도서/설교/교리 유닛
                       " (SELECT ba.title || ' · ' || COALESCE(bu.unit_label,'') "
                       "    FROM sys_book_unit bu JOIN sys_book_asset ba "
                       "      ON ba.book_id=bu.book_id "
                       "   WHERE bu.unit_id=a.body_unit_id) "
                       "FROM user_ref_asset a "
                       "WHERE a.record_status='LIVE' "
                       "  AND (EXISTS (SELECT 1 FROM user_ref_text t2 "
                       "                WHERE t2.ref_id=a.ref_id AND UPPER(t2.lang_code)=? "
                       "                  AND COALESCE(t2.record_status,'LIVE')='LIVE') "
                       "       OR (NOT EXISTS (SELECT 1 FROM user_ref_text t3 "
                       "                        WHERE t3.ref_id=a.ref_id) "
                       "           AND UPPER(COALESCE(NULLIF(a.lang_code,''), ?))=?) "
                       "       OR 1=?) ")
                args = [lang, lang, (self.lang_getter() or 'KO').upper(), lang,
                        1 if q else 0]
                if q:
                    # ⚠ 검색은 **언어를 안 가린다** — 어느 언어판에 걸려도 찾힌다
                    sql += ("  AND (a.title LIKE ? OR a.summary LIKE ? "
                            "    OR EXISTS (SELECT 1 FROM user_ref_text t4 "
                            "        WHERE t4.ref_id=a.ref_id "
                            "          AND (t4.title LIKE ? OR t4.body_text LIKE ?))) ")
                    args += [like, like, like, like]
                for r in conn.execute(sql + "ORDER BY a.ref_id", args):
                    try:
                        import ref_kinds as _rk
                        _codes[('U', r[0])] = _rk.normalize(r[1])[0]
                    except Exception:                       # noqa: BLE001
                        _codes[('U', r[0])] = 'STUDY'
                    rows.append(('U', r[0], _user_type_label(r[1]),
                                 r[2] or i18n.t('REFR_NOTITLE', '(제목없음)'),
                                 ('user',), (r[4] or '')))
        except Exception as e:
            print(f'RefDetailView._search: {e}')

        # ★ 구절 거르개 — 그 구절에 연결된 것만(51-3·4(5))
        _flt = self._verse_filter_ids()
        if _flt is not None:
            _sa, _su = _flt
            rows = [r for r in rows
                    if (r[0] == 'A' and r[1] in _sa) or (r[0] == 'U' and r[1] in _su)]
        self._sync_vchip(_flt is not None)
        self._sync_clear_btn()
        # ★ 유형 체크 — 2026-10-16 사용자 「유형 구분값이 사라졌다 · 다시 체크상자를 · 전체/연구/설교/참고자료」
        #   (그전엔 목록에 있는 유형만 보이고 하나뿐이면 감췄다 — 그래서 사라졌다)
        self._sync_kinds()
        _before_kind = len(rows)
        _off = getattr(self, '_kind_off', set())
        if _off:
            rows = [r for r in rows if _codes.get((r[0], r[1]), 'STUDY') not in _off]
        _kind_cut = bool(_before_kind) and not rows
        # ★ 읽었음으로 표시한 연구자료에 ✓ (2026-10-16 — 사람이 [읽었음]을 누른 것만)
        try:
            import db_read_state as _rs
            with appdb.connect(self.db_path) as _c:
                _readm = _rs.ref_marks(_c)
        except Exception:                                   # noqa: BLE001
            _readm = set()
        rows = [((h, i, k, ('✓ ' + t) if (h == 'A' and i in _readm) else t, tg, tt))
                for h, i, k, t, tg, tt in rows]
        self._syncing = True
        try:
            self._list.delete(*self._list.get_children())
            for head, rid, kind, title, tags, _target in rows:
                # A = sys_ref_unit(배포되는 우리 글) · U = user_ref_asset(내 자료)
                scope = i18n.t('REFV_SCOPE_USER', 'USER') if head == 'U' \
                    else i18n.t('REFV_SCOPE_SYS', 'SYS')
                self._list.insert('', 'end', iid=f'{head}|{rid}',
                                  values=(scope, kind, title), tags=tags)
            if not rows:
                # 빈 목록을 그냥 두면 고장으로 보인다. 왜 비었는지 적어 둔다.
                # iid 에 `|` 가 없어 `_on_list_select` 가 스스로 걸러 낸다.
                self._list.insert(
                    '', 'end', iid='EMPTY', tags=('empty',),
                    values=('', '' if (q or _kind_cut) else lang,
                            i18n.t('COMMON_NORESULT', '찾은 것이 없습니다.') if (q or _kind_cut)
                            else (i18n.t('REFV_NO_CTX', '여기에 연결된 노트가 없습니다. X 를 누르면 전체를 봅니다.')
                                  if self._ctx else
                                  i18n.t('REFV_NO_VERSE',
                                         '이 구절에 연결된 노트가 없습니다. X 를 누르면 전체를 봅니다.'))
                            if _flt is not None
                            else i18n.t('REFV_NO_LANG',
                                        '이 언어로 된 자료가 아직 없습니다.')))
            if select_iid and self._list.exists(select_iid):
                self._list.selection_set(select_iid)
                self._list.see(select_iid)
        finally:
            self._syncing = False
        return len(rows)

    def _sync_kinds(self):
        """유형 체크 줄 — 늘 넷: [전체] [연구] [설교] [참고자료](`ref_kinds.KINDS` 한 표 · 이름은 그 언어)."""
        f = getattr(self, '_kind_f', None)
        if f is None:
            return
        try:
            import ref_kinds as _rk
            kinds = tuple(_rk.KINDS)
        except Exception:                                   # noqa: BLE001
            kinds = ('STUDY', 'SERMON', 'REFERENCE')
        if kinds != self._kind_shown:
            for w in f.winfo_children():
                w.destroy()
            self._kind_vars = {}
            self._kind_all = tk.BooleanVar(value=not self._kind_off)
            ttk.Checkbutton(f, text=i18n.t('COMMON_ALL', '전체'), variable=self._kind_all,
                            command=self._kind_all_toggle).pack(side='left', padx=(0, 8))
            for k in kinds:
                v = tk.BooleanVar(value=k not in self._kind_off)
                ttk.Checkbutton(f, text=_user_type_label(k), variable=v,
                                command=lambda k=k, v=v: self._kind_toggle(k, v)).pack(side='left', padx=(0, 8))
                self._kind_vars[k] = v
            self._kind_shown = kinds
        if not f.winfo_manager():
            f.pack(fill='x', pady=(0, 2), before=self._lpw)

    def _kind_all_toggle(self):
        on = self._kind_all.get()
        self._kind_off = set() if on else set(self._kind_vars)
        for v in self._kind_vars.values():
            v.set(on)
        self._search()

    def _kind_toggle(self, k, v):
        if v.get():
            self._kind_off.discard(k)
        else:
            self._kind_off.add(k)
        try:
            self._kind_all.set(not self._kind_off)
        except Exception:                                   # noqa: BLE001
            pass
        self._search()

    def _on_list_select(self, _):
        if getattr(self, '_syncing', False):
            return
        sel = self._list.selection()
        if not sel:
            return
        head, _, rest = sel[0].partition('|')
        try:
            rid = int(rest)
        except ValueError:
            return
        if head == 'A':
            self.show_article(rid, _from_list=True)
        else:
            self.show_user(rid, _from_list=True)

    # ── 모드 전환 ─────────────────────────────────────────────────
    def _set_mode(self, mode):
        """위젯만 바꾼다. 영상 프로세스는 건드리지 않는다."""
        for w in (self._txt_f, self._form_f, self._video_f):
            w.pack_forget()
        if mode == _MODE_TEXT or mode == _MODE_EMPTY:
            self._txt_f.pack(fill='both', expand=True)
        elif mode == _MODE_FORM:
            self._form_f.pack(fill='both', expand=True)
        elif mode == _MODE_VIDEO:
            self._video_f.pack(fill='both', expand=True)
        self._mode = mode

        # ★ 2026-10-15 91-1 — [수정] 한 자리: 읽는 중 = 수정(내 것 · 배포 연구노트) · 고치는 칸 = 저장
        try:
            self._del_list_btn.config(state=('normal' if self._cur_user else 'disabled'))
        except Exception:
            pass
        self._sync_copy()
        if mode == _MODE_FORM:
            self._save_btn.config(text=i18n.t('COMMON_SAVE', '저장'), command=self._save, state='normal',
                                  fg=self._C('success', '#1E8449'))
        else:
            self._save_btn.config(text=i18n.t('COMMON_EDIT', '수정'), command=self._edit_click,
                                  state='normal' if (mode == _MODE_TEXT and self._can_edit()) else 'disabled',
                                  fg=self._C('fg', '#2C3E50'))
        try:
            self._wexp_btn.config(state='normal' if (mode == _MODE_TEXT and (
                self._cur_user or getattr(self, '_cur_unit', None))) else 'disabled')
        except Exception as e:                            # noqa: BLE001
            print(f'[refv word btn] {e}')
        # ★ 91 후속 3 — 고치는 칸·빈 화면은 언어 전부(새 언어판을 쓴다) · 읽는 중은 `_lang_avail` 이 좁힌다
        if mode in (_MODE_FORM, _MODE_EMPTY):
            self._lang_full()

    def _lang_full(self):
        lc = getattr(self, '_lang', None)
        if lc is None:
            return
        import lang_combo
        cur = self._view_lang()
        lc.set_items(lang_combo.content_items(), select=(None, cur))
        self._lang_var.set(lc.lang())

    def _lang_avail(self, langs):
        """★ 2026-10-15 91 후속 3 — 콤보에는 **이 글에 실제로 있는 언어만**.
        고르는 차례 = 사람이 마지막에 고른 언어 → 설정 언어 → EN → KO → 첫째. 없으면 전부."""
        lc = getattr(self, '_lang', None)
        if lc is None:
            return
        import lang_combo
        langs = lang_combo.order([str(x).upper() for x in (langs or ()) if x])
        if not langs:
            self._lang_full()
            return
        saved = lang_combo.get_sel(lc.key, self.db_path) if lc.key else None
        pref = [(saved[1] or '').upper()] if saved and saved[1] else []
        pref += [(self.lang_getter() or 'KO').upper(), 'EN', 'KO']
        pick = next((x for x in pref if x in langs), langs[0])
        lc.set_items([(None, x) for x in langs], select=(None, pick))
        self._lang_var.set(lc.lang())

    def _q_ent_last(self):
        """검색 줄의 마지막 위젯(X) — 칩을 그 바로 뒤에 붙인다."""
        kids = [w for w in self._save_btn.master.pack_slaves() if w.pack_info().get('side') == 'left'
                and w is not getattr(self, '_vchip', None)]
        return kids[-1] if kids else self._save_btn

    def _can_edit(self):
        """[수정]이 할 일이 있나 — 내 글이거나, 배포 연구노트(STUDY)."""
        if self._cur_user:
            return True
        if getattr(self, '_cur_unit', None):
            try:
                with appdb.connect(self.db_path) as c:
                    st = c.execute("SELECT s.src_type FROM sys_ref_unit u JOIN sys_ref_source s"
                                   " ON s.ref_src_id=u.ref_src_id WHERE u.ref_unit_id=?", (self._cur_unit,)).fetchone()
                return bool(st and st[0] == _STUDY_TYPE)
            except Exception:
                return False
        return False

    def _edit_click(self):
        """[수정] — 내 글이면 고치는 칸 · 배포 연구노트면 **초안**(저장할 때 내 연구노트가 생긴다 · 91-1)."""
        if self._cur_user:
            self._to_form()
            return
        if not self._can_edit():
            return
        import copy_own
        with appdb.connect(self.db_path) as c:
            rid = copy_own.copy_of(c, 'REF', self._cur_unit)
        if rid:                       # 이미 수정해 둔 내 것이 있으면 그것(두 벌 안 만든다)
            self.show_user(rid)
            self.after(80, lambda: (self._cur_user == rid) and self._to_form())
            return
        self._draft_form(self._cur_unit)

    def _draft_form(self, unit):
        """배포 연구노트의 이 언어 글을 고치는 칸에 불러온다 — DB 에는 아무것도 안 쓴다."""
        want = self._view_lang()
        with appdb.connect(self.db_path) as conn:
            r = conn.execute("SELECT title, body_text FROM sys_ref_text WHERE ref_unit_id=? AND UPPER(lang_code)=?"
                             " AND record_status='LIVE' AND COALESCE(text_variant,'ORIGINAL')='ORIGINAL'",
                             (unit, want)).fetchone()
            lab = conn.execute("SELECT unit_label FROM sys_ref_unit WHERE ref_unit_id=?", (unit,)).fetchone()
        self._draft_src = unit
        self._build_form({'ref_type': 'STUDY', 'title': ((r[0] if r else '') or (lab[0] if lab else '') or ''),
                          'author': '', 'source_name': '', 'url': '', 'file_path': '',
                          'summary': (r[1] if r else '') or ''})
        try:
            import ref_doc as _RD
            with appdb.connect(self.db_path) as conn:
                self._pending_tables = _RD.get_tables(conn, 'SYS', unit, want, fallback=())
        except Exception as e:                            # noqa: BLE001
            print(f'[refv draft tables] {e}')
        self._set_mode(_MODE_FORM)
        try:
            self._tbl_decorate()
        except Exception:
            pass

    def _show_text(self, body, file_name=None, notes=(), lang=None, tables=None):
        """본문을 보인다. `file_name` 을 주면 **맨 위에 눌리는 줄**로 붙인다.

        `lang` = **지금 보여 주는 글의 실제 언어**(고른 언어가 아니다).
        ⚠⚠⚠ 2026-09-23 — 여기에 `_view_lang()`(고른 언어)을 넘겼다가 사용자
          신고를 받았다: 「아랍어로 선택하면 **한국어 자료까지 아랍어라고
          생각해서 오른쪽으로 배치**한다」. 이 화면은 고른 언어가 없으면
          **있는 것을 대신 보이므로**(폴백) 두 값이 다를 수 있다.
          ⇒ 부르는 쪽이 **실제로 꺼낸 행의 언어**를 넘긴다. 모르면 비워 두고
            `bidi` 가 글자로 짐작한다.

        ★ 2026-08-14 사용자 지적 「첨부파일을 다운로드 하려고 하는데 클릭되지 않는다」.
          ⚠ 파일 이름을 **글자로만** 넣어 두었다 — 눈에는 보이는데 아무 일도 안 났다.
            `_open_file` 은 만들어 두고 **아무도 부르지 않았다**(unwired.md 부류).
        """
        self._txt.config(state='normal')
        self._txt.delete('1.0', 'end')
        # ★ 317차-18 — 심어 둔 표 위젯도 걷는다(글자만 지우면 위젯이 남는다)
        for _w in getattr(self, '_tbl_wins', []) or []:
            try:
                _w.destroy()
            except Exception:                             # noqa: BLE001
                pass
        self._tbl_wins = []
        # ⚠ 심어 둔 폴백 단추도 함께 걷는다(글자만 지우면 위젯이 남는다)
        try:
            import pack_fallback as _FB
            _FB.clear_get_buttons(self._txt)
        except Exception:
            pass
        if file_name:
            # ⚠ 옛 글은 폴더까지 적혀 있다 — **이름만** 보인다(여는 것은 `_open_file`).
            self._txt.insert('end', '📎 %s\n'
                             % str(file_name).replace('\\', '/').rsplit('/', 1)[-1],
                             ('file',))
        for n in notes:
            self._txt.insert('end', '%s\n' % n, ('note',))
        if file_name or notes:
            self._txt.insert('end', '\n')
        # ★ **오른쪽에서 시작한다**(1.txt 8-3) — 아랍어·히브리어 본문.
        #   ⚠ 글자는 안 건드린다. `bidi` 가 정렬 태그만 얹는다(§256차 ①).
        try:
            # ★ 317차-18 — 자리표 [[T1]] 자리에 표를 심는다(ref_doc 한 문 · 표가 없으면 글만)
            #   ★ **지금 보여 주는 글의 언어**로 정한다(2026-09-23) — 고른 언어가 아니다.
            import ref_doc as _RD
            self._tbl_wins = _RD.render(self._txt, body or '', tables or {}, lang=lang,
                                        C=self._C, font=self._txt.cget('font'))
        except Exception as e:                            # noqa: BLE001
            print(f'[refv render] {e}')
            self._txt.insert('end', body or '')
        # ★ 태그 색은 paint 가 못 바꾼다 — **그릴 때마다 역할로 재적용**(§36-5b.
        #   2026-08-19 사용자 「첨부파일 이름이 보이지 않는다」 — 검정 테마에서
        #   하드코딩 남색 #1A5276 이 배경에 묻혀 있었다).
        self._txt.tag_config('file', foreground=self._C('accent', '#1A5276'),
                             underline=1)
        self._txt.tag_config('note', foreground=self._C('warning', '#9C6708'))
        # 본문 바탕·글자색도 지금 테마로 (위젯 옵션이라 생성 때 값이 굳는다)
        self._txt.config(bg=self._C('panel', '#FCFCFC'), fg=self._C('fg', '#222'))
        self._txt.tag_bind('file', '<Button-1>',
                           lambda _e: self._open_file(getattr(self, '_cur_file', '')))
        self._txt.tag_bind('file', '<Enter>',
                           lambda _e: self._txt.config(cursor='hand2'))
        self._txt.tag_bind('file', '<Leave>',
                           lambda _e: self._txt.config(cursor=''))
        # ★ 본문 속 URL 자동 링크 (2026-08-19 0.txt ⑨)
        try:
            import url_text
            url_text.linkify(self._txt)
        except Exception:
            pass
        self._txt.config(state='disabled')
        self._txt.yview_moveto(0)

    def clear(self):
        self._cur_unit = self._cur_user = self._new_vid = None
        self._hide_read_btn()
        self._new_eid = None
        # 빈 화면 제목도 탭과 같은 말로 (2026-08-13). 같은 키를 쓰면 갈라지지 않는다.
        self._title.config(text=i18n.t('TAB_RESEARCH', '연구/설교노트'))
        self._sub.config(text='')
        self._set_mode(_MODE_EMPTY)
        # 안내문은 넣지 않는다 (2026-08-19 사용자 — 「이런 메시지 필요 없다」).
        self._show_text('')
        self._link_load()

    # ── 가져와서 고치기 (2026-10-13 docs/1.txt 83) ──────────────────
    def _sync_copy(self):
        """원본 가리기/표시하기 — 배포 연구노트를 수정한 내 것일 때만 [삭제] 오른쪽에(눌린 쪽이 지금 상태)."""
        of = getattr(self, '_orig_f', None)
        if of is None:
            return
        of.pack_forget()
        if not self._cur_user:
            return
        try:
            import copy_own
            with appdb.connect(self.db_path) as c:
                o = copy_own.origin_of(c, 'REF', self._cur_user)
            if not o:
                return
            of.pack(side='left', fill='y')
            for hv, b in self._orig_btns.items():
                on = (hv == o['hide'])
                b.config(relief='sunken' if on else 'flat',
                         fg=self._C('accent', '#1A5276') if on else self._C('fg_dim', '#7F8C8D'))
        except Exception as e:                              # noqa: BLE001
            print('[ref copy btns] %s' % e)

    def _copy_ref(self):
        if not self._cur_unit or self._cur_user:
            return
        import copy_own
        try:
            with appdb.connect(self.db_path) as c:
                rid = copy_own.copy_of(c, 'REF', self._cur_unit)
                if rid is None:
                    rid = copy_own.copy_ref(c, self._cur_unit, self._view_lang(), hide=True)
        except Exception as e:                              # noqa: BLE001
            print('[ref copy] %s' % e)
            return
        self.show_user(rid)
        # 곧바로 고치는 칸으로 — ⚠ 목록 줄을 고른 이벤트가 뒤에 와서 읽기 모드로 되돌리므로 그 뒤에
        self.after(80, lambda: (self._cur_user == rid) and self._to_form())

    def _set_orig(self, hide):
        if not self._cur_user:
            return
        import copy_own
        with appdb.connect(self.db_path) as c:
            copy_own.set_hide(c, 'REF', self._cur_user, bool(hide))
        self._search(select_iid=f'U|{self._cur_user}')
        self._sync_copy()

    # ── ① 연구 자료 글 ────────────────────────────────────────────
    def show_article(self, ref_unit_id: int, _from_list=False):
        self._draft_src = None
        self._cur_user = None
        self._cur_unit = int(ref_unit_id)
        # ⚠ 새 글 시드의 출처 줄(▣ 도서 …)을 지운다 (2026-08-19 0.txt ⑦) —
        #   안 지우면 목록에서 다른 글을 열어도 읽던 도서 이름이 계속 남는다.
        self._src = {}
        self._show_src_line()
        # ★ 2026-10-16 (docs/1.txt 2-1) — 열기만 해서는 읽음으로 안 적는다 · 제목 오른쪽 [읽었음]을 눌러야 한다
        self._sync_read_btn()
        if not _from_list:                 # P2 에서 밀어 넣은 것 — 목록도 그 줄로 맞춘다
            self._search(select_iid=f'A|{self._cur_unit}')
        with appdb.connect(self.db_path) as conn:
            self._lang_avail([x[0] for x in conn.execute(
                "SELECT DISTINCT UPPER(lang_code) FROM sys_ref_text WHERE ref_unit_id=? AND record_status='LIVE'"
                "  AND TRIM(COALESCE(body_text,''))<>''", (self._cur_unit,))])
        with appdb.connect(self.db_path) as conn:
            # ⚠ 제목을 **두 칸으로 나눠 받는다**(2026-09-23) — 앞 칸이 차면 그
            #   제목은 고른 언어로 실재하고, 비면 `unit_label`(관리자 표기)이다.
            #   COALESCE 로 합치면 **어느 쪽이 나왔는지 모르게** 되어 정렬을
            #   엉뚱한 언어로 잡는다(사용자 신고 그 자리).
            u = conn.execute(
                "SELECT (SELECT t.title FROM sys_ref_text t"
                "         WHERE t.ref_unit_id=u.ref_unit_id"
                "           AND UPPER(t.lang_code)=?"
                "           AND t.record_status='LIVE'"
                "           AND t.title IS NOT NULL AND t.title<>'' LIMIT 1),"
                "       u.unit_question, s.title_ko, s.title, s.src_type,"
                "       u.unit_label "
                "FROM sys_ref_unit u JOIN sys_ref_source s ON s.ref_src_id=u.ref_src_id "
                "WHERE u.ref_unit_id=?", (self._view_lang(), self._cur_unit)).fetchone()
        if not u:
            self.clear(); return
        # sys 연구 글도 **같은 규칙**으로 언어를 적는다 (2026-08-14).
        with appdb.connect(self.db_path) as conn:
            _lgs = [x[0] for x in conn.execute(
                "SELECT DISTINCT UPPER(lang_code) FROM sys_ref_text "
                "WHERE ref_unit_id=? AND record_status='LIVE' "
                "  AND TRIM(COALESCE(body_text,''))<>''",
                (self._cur_unit,)).fetchall()]
        # ⚠ 고른 언어 제목이 있으면 그 언어, 없으면 **모른다**(글자로 짐작).
        _t_lang = self._view_lang() if u[0] else None
        self._set_title((u[0] or u[5] or u[1] or '')[:70], _t_lang)
        # ★ 91 후속 3 — 제목 옆 언어 표기 걷음(어느 언어가 있는지는 언어 콤보가 말한다)
        self._sub.config(text='  ·  '.join([x for x in (u[2] or u[3] or '',) if x]))
        self._set_mode(_MODE_TEXT)
        self._reload_text()
        self._link_load()

    def _reload_text(self):
        """선택한 언어로 읽되, 그 언어가 없으면 **있는 것을 보이고 그렇다고 알린다**.

        ⚠ 조용히 다른 언어를 보이면 번역이 다 된 것처럼 보인다(§3-1 전문 설명 폴백과
          같은 함정). 한 줄로 무슨 일이 일어났는지 적어 둔다.
        """
        if not self._cur_unit:
            return
        want = self._view_lang()
        order = ("ORDER BY CASE WHEN UPPER(lang_code)=? THEN 0"
                 "          WHEN UPPER(lang_code)='EN' THEN 1"
                 "          WHEN UPPER(lang_code)='KO' THEN 2 ELSE 3 END,"
                 "  CASE WHEN UPPER(text_variant)='ORIGINAL' THEN 0 ELSE 1 END LIMIT 1")
        with appdb.connect(self.db_path) as conn:
            r = conn.execute(
                "SELECT body_text, UPPER(lang_code) FROM sys_ref_text WHERE ref_unit_id=?"
                "  AND record_status='LIVE' AND body_text IS NOT NULL AND body_text<>'' "
                + order, (self._cur_unit, want)).fetchone()
        if not r:
            # ★★★ **안 받은 자료집이면 그렇게 말한다**(2026-09-04 ⑦ 폴백).
            #   코어팩이 껍데기를 담으므로 본문이 없어도 **무슨 자료인지는 안다**.
            #   ⚠ 문답형(하이델베르크 등)은 본문이 `unit_answer` 에 있어
            #     `pack_fallback` 이 그것까지 본다 — 갖고 있는 것을 「안 받았다」고
            #     하지 않는다.
            msg, _fb = '', None
            try:
                import pack_fallback as _FB
                with appdb.connect(self.db_path) as conn:
                    _s = conn.execute(
                        "SELECT rs.src_code FROM sys_ref_unit u"
                        "  JOIN sys_ref_source rs ON rs.ref_src_id=u.ref_src_id"
                        " WHERE u.ref_unit_id=?", (self._cur_unit,)).fetchone()
                    if _s:
                        # ⚠ 안내문(`where`)을 비운다 — **단추가 그 몫을 맡는다**
                        msg = _FB.as_text(conn, 'DICT', _s[0], want,
                                          t=i18n.t, where='')
                        _fb = ('DICT', _s[0], want)
            except Exception:
                msg, _fb = '', None
            self._show_text(msg or i18n.t('REFV_NOBODY', '(본문 없음)'))
            # ★★★ **받는 길이 그 자리에 있다**(2026-09-04 ⑪)
            if _fb and msg:
                try:
                    import ui_theme as _UT
                    _FB.attach_get_button(
                        self._txt, _fb[0], _fb[1], _fb[2],
                        on_get=self._on_fb_get, t=i18n.t, C=_UT.C)
                except Exception:
                    pass
            return
        body, got = r[0], r[1]
        if got != want:
            body = (i18n.t('REFV_LANG_FALLBACK',
                           '이 글은 {want} 로 아직 준비되지 않아 {got} 본문을 보이고 있습니다.'
                           ).format(want=want, got=got) + '\n\n' + body)
        # ⚠ `got` = **실제로 꺼낸 행의 언어**. `want`(고른 언어)가 아니다 —
        #   폴백이 일어난 자리에서 둘이 갈린다(2026-09-23 사용자 신고).
        _tbls = {}
        try:
            import ref_doc as _RD                         # ★ 317차-18 — 이 글의 표
            with appdb.connect(self.db_path) as conn:
                _tbls = _RD.get_tables(conn, 'SYS', self._cur_unit, got)
        except Exception as e:                            # noqa: BLE001
            print(f'[refv tables] {e}')
        self._show_text(body, lang=got, tables=_tbls)

    def _on_fb_get(self, kind, key, lang):
        """폴백의 [지금 받기] — 받고 나면 **그 글을 다시 그린다**.

        ⚠ 받는 문은 `pack_status.fetch_asset` 하나(다운로드 화면과 같다).
        ⚠ **왜 안 되는지 말한다**(§0-1).
        """
        from tkinter import messagebox
        import pack_status as _PS
        if not messagebox.askyesno(
                i18n.t('SET_DL_GET', '지금 받기'),
                i18n.t('DL_GET_ASK',
                       '「%s」 를 지금 받습니다.\n\n'
                       '받는 동안 앱을 켜 두세요. 인터넷을 씁니다.')
                % str(key)[:50]):
            return
        r = _PS.fetch_asset(kind, key, lang, self.db_path)
        if not r['ok']:
            messagebox.showinfo(
                i18n.t('SET_DL_GET', '지금 받기'),
                i18n.t('DL_NOT_ON_SERVER',
                       '아직 서버에 올라오지 않은 자료입니다. '
                       '나중에 다시 눌러 주세요.')
                if r['why'] == 'NOT_ON_SERVER'
                else i18n.t('DL_GET_FAIL', '받지 못했습니다: %s') % r['why'])
            return
        msg = i18n.t('DL_GET_DONE_N', '「%s」 를 받았습니다. (%s개)')             % (str(key)[:40], format(r['rows'], ','))
        # ⚠ **바꿔 받았으면 그렇게 말한다** — 조용히 다른 언어를 넣지 않는다
        if r.get('sub'):
            msg += chr(10) * 2 + i18n.t(
                'DL_GET_SUBLANG',
                '요청하신 언어는 아직 없어 %s 자료를 받았습니다.') % r.get('lang')
        messagebox.showinfo(i18n.t('SET_DL_GET', '지금 받기'), msg)
        try:
            self._reload_text()
        except Exception:
            pass

    def _article_links(self, uid):
        """글에 걸린 구절 — 범위(시작~끝) 그대로, 여러 개."""
        out = []
        with appdb.connect(self.db_path) as conn:
            lang = self._view_lang()
            for sv, ev, role in conn.execute(
                    # ★ 2026-08-24 통합 표(`REFU_VERS`)
                    "SELECT target_id, end_id, rel_code FROM sys_link_asset "
                    "WHERE link_type='REFU_VERS' AND clicked_id=? "
                    "  AND COALESCE(record_status,'LIVE')='LIVE' "
                    "ORDER BY sort_order, target_id", (uid,)):
                out.append((sv, ev, role, self._ref_label(conn, sv, ev, lang),
                            self._verse_text(conn, sv)))
        return out

    def _ref_label(self, conn, sv, ev, lang):
        r = conn.execute(
            "SELECT COALESCE(bn.short_name, bn2.short_name, bi.bcode), bi.chapter, bi.verse "
            "FROM bible_index bi "
            "LEFT JOIN book_names bn  ON bn.book_code=bi.bcode AND UPPER(bn.lang_code)=? "
            "LEFT JOIN book_names bn2 ON bn2.book_code=bi.bcode AND bn2.lang_code='EN' "
            "WHERE bi.verse_id=?", (_ref_lang(), sv)).fetchone()
        if not r:
            return str(sv)
        e = None
        if ev and ev != sv:
            e = conn.execute("SELECT chapter, verse FROM bible_index WHERE verse_id=?",
                             (ev,)).fetchone()
        # ★ 형식은 `verse_ref` 가 정한다 (2026-08-14) — 전에는 여기가 붙임표(`-`)라
        #   같은 구간이 화면마다 `창1:1~15` / `창 1:1-15` 로 갈렸다.
        return verse_ref.range_label(r[0], r[1], r[2],
                                     e[0] if e else None, e[1] if e else None)

    def _verse_text(self, conn, vid):
        # ★ 합쳐진 절·없는 절도 뜻이 통하게(§verse_text)
        return _vt.resolve(conn, vid, 'KRV')['text'][:110]

    # ── ② 내 자료 ─────────────────────────────────────────────────
    def show_user(self, ref_id: int, _from_list=False):
        self._hide_read_btn()
        self._draft_src = None
        self._cur_unit = None
        self._cur_user = int(ref_id)
        self._src = {}                     # 출처 줄 잔존 방지 (0.txt ⑦)
        self._show_src_line()
        if not _from_list:
            self._search(select_iid=f'U|{self._cur_user}')
        import db_user_ref_schema as U
        with appdb.connect(self.db_path) as conn:
            _ls = U.text_langs(conn, self._cur_user) or [x[0] for x in conn.execute(
                "SELECT UPPER(COALESCE(NULLIF(lang_code,''), ?)) FROM user_ref_asset WHERE ref_id=?",
                ((self.lang_getter() or 'KO').upper(), self._cur_user))]
        self._lang_avail(_ls)
        want = self._view_lang()
        with appdb.connect(self.db_path) as conn:
            try:
                import ref_kinds as _RK
                _RK.ensure(conn)
                _og = conn.execute("SELECT ref_type, ref_origin, url, COALESCE(ai_edited,0)"
                                   " FROM user_ref_asset WHERE ref_id=?", (self._cur_user,)).fetchone()
                _org_txt = _RK.origin_label(_RK.normalize(_og[0], _og[1], _og[2])[1], bool(_og[3])) if _og else ''
            except Exception:                               # noqa: BLE001
                _org_txt = ''
            r = conn.execute(
                "SELECT ref_type, title, author, source_name, url, summary, "
                "       lang_code, file_path "
                "FROM user_ref_asset WHERE ref_id=?", (self._cur_user,)).fetchone()
            if not r:
                self.clear(); return
            # ★ **언어별 본문**을 먼저 본다 (2026-08-14). 없으면 옛 단일 칸.
            t, b, used = U.fetch_text(conn, self._cur_user, want)
            langs = U.text_langs(conn, self._cur_user)
        # ⚠ 옛 칸(`user_ref_asset.title`·`summary`)은 **언어별 본문이 아예 없을 때만**
        title = t if t is not None else ((r[1] or '') if not langs else '')
        body = b if b is not None else ((r[5] or '') if not langs else '')
        self._set_title((title or i18n.t('REFR_NOTITLE', '(제목없음)'))[:70],
                        (used if t is not None else None))
        # ⚠ **언어는 두 벌 이상일 때만 적는다** (2026-08-14 사용자 지적 「sys 데이터는
        #   제목 란에 언어표시가 없는데 사용자 데이터는 한국어라고 표시하고 있다」).
        #   한 벌뿐이면 지금 보는 언어와 같아 아무것도 알려 주지 않는다 —
        #   **번역이 있는 글에서만** 뜻이 생긴다. sys 쪽도 같은 규칙을 쓴다.
        sub = [x for x in (_org_txt, r[2], r[3]) if x]      # 91 후속 3 — 언어 표기 걷음 · ★ 2026-10-16 출처 맨 앞
        self._sub.config(text='  ·  '.join(sub))

        notes = []
        # ⚠ 이 언어로 아직 아무것도 없으면 **그렇게 말한다** — 빈 화면은 고장으로 보인다.
        if langs and want not in langs and not used:
            notes.append(i18n.t('REFV_NO_THIS_LANG',
                                '이 언어로 된 본문이 아직 없습니다. '
                                '[수정하기] 로 이 언어판을 쓸 수 있습니다.'))
        # ⚠ 고른 언어가 없어 다른 언어를 보이는 중이면 **한 줄로 알린다.**
        if used and used != want:
            notes.append(i18n.t('REFV_LANG_FALLBACK',
                                '이 언어로 된 본문이 아직 없어 {lang} 로 보입니다.')
                         .format(lang=lang_combo.label(used, None, self.db_path)))
        if r[4]:
            body = (body or '') + '\n\n' + r[4]
        # ★ 첨부는 **눌리는 줄**로 맨 위에 (2026-08-14 「클릭되지 않는다」).
        self._cur_file = r[7] or ''
        self._set_mode(_MODE_TEXT)
        # ⚠ `used` = `U.fetch_text` 가 **실제로 꺼낸 언어**(2026-09-23).
        _tbls = {}
        try:
            import ref_doc as _RD                         # ★ 317차-18 — 이 글의 표
            with appdb.connect(self.db_path) as conn:
                _tbls = _RD.get_tables(conn, 'USER', self._cur_user, used or want)
        except Exception as e:                            # noqa: BLE001
            print(f'[refv tables] {e}')
        self._show_text(body or i18n.t('REFV_NOBODY', '(본문 없음)'),
                        file_name=self._cur_file or None, notes=notes,
                        lang=(used if b is not None else None), tables=_tbls)
        self._link_load()

    def _lang_note(self, langs):
        """부제에 붙일 언어 표기 — **두 벌 이상일 때만.** sys·user 가 함께 쓴다."""
        codes = lang_combo.order(langs or [])
        if len(codes) < 2:
            return []
        return [' · '.join(lang_combo.label(c, None, self.db_path) for c in codes)]

    def show_new(self, verse_id, entity_id=None, src=None):
        self._hide_read_btn()
        self._draft_src = None
        """새 글. 구절이나 용어를 받으면 그것을 **미리 걸어 둔다**.

        용어는 이 뷰가 어느 용어 안에 심겨 있는지(`seed_entity_getter`)로도 온다.
        `src` 는 도서·설교·교리자료에서 왔을 때의 문맥 — 유형을 정하고
        **어느 자료에서 왔는지 제목 위에 적는다**(2026-08-15 사용자 지시).
        """
        self._cur_unit = self._cur_user = None
        self._src = src or {}
        self._new_vid = int(verse_id) if verse_id else None
        if entity_id is None and callable(self.seed_entity_getter):
            entity_id = self.seed_entity_getter()
        self._new_eid = int(entity_id) if entity_id else None
        self._title.config(text=i18n.t('REFV_NEW', '새 내 자료'))
        self._show_src_line()
        self._sub.config(text='')
        # ★ 2026-10-15 사용자 「새 글 작성할 때 설정언어가 기본값」 — 직전에 읽던 글의 언어를 물려받지 않는다
        if getattr(self, '_lang', None) is not None:
            import lang_combo as _lcb
            self._lang.set_items(_lcb.content_items(), select=(None, (self.lang_getter() or 'KO').upper()))
            self._lang_var.set(self._lang.lang())
        self._build_form({})
        self._set_mode(_MODE_FORM)
        self._link_load()

    def _show_src_line(self):
        """어느 도서·설교·교리자료에서 왔는지 **제목 위**에 한 줄.

        ⚠ 구절·엔티티는 아래 연결 칸이 맡는데, 도서 유닛은 담을 자리가 없었다.
          제목 아래에 두면 본문에 묻히고, 버튼 줄에 두면 자리를 다툰다.
        """
        src = getattr(self, '_src', None) or {}
        book, unit = src.get('book_title', ''), src.get('unit_label', '')
        if not (book or unit):
            if getattr(self, '_src_lbl', None) is not None:
                self._src_lbl.pack_forget()
            return
        if getattr(self, '_src_lbl', None) is None:
            self._src_lbl = tk.Label(
                self._title.master, text='', anchor='w',
                fg=self._C('accent', '#2E86C1'),
                bg=self._C('bg', '#FFFFFF'))
        kind = {'BOOK': '도서', 'SERMON': '설교', 'STUDY': '교리자료'}.get(
            src.get('ref_type'), '자료')
        txt = ' · '.join(x for x in (book, unit) if x)
        self._src_lbl.config(text='%s %s  %s' % ('▣', kind, txt),
                             fg=self._C('accent', '#2E86C1'),
                             bg=self._C('bg', '#FFFFFF'))
        try:
            self._src_lbl.pack(fill='x', before=self._title)
        except Exception:
            self._src_lbl.pack(fill='x')

    def _to_form(self):
        if not self._cur_user:
            return
        import db_user_ref_schema as U
        want = self._view_lang()
        with appdb.connect(self.db_path) as conn:
            try:
                import ref_kinds as _RK
                _RK.ensure(conn)
                _og = conn.execute("SELECT ref_origin, COALESCE(ai_edited,0) FROM user_ref_asset WHERE ref_id=?",
                                   (self._cur_user,)).fetchone()
            except Exception:                               # noqa: BLE001
                _og = None
            r = conn.execute(
                "SELECT ref_type, title, author, source_name, url, summary, file_path "
                "FROM user_ref_asset WHERE ref_id=?", (self._cur_user,)).fetchone()
            # ⚠ **고칠 때는 폴백하지 않는다.** 영어 본문을 띄워 놓고 「한국어」라 적으면
            #   그대로 저장돼 영어가 한국어 자리에 들어간다. 없으면 **빈 칸**으로 연다.
            t, b, used = U.fetch_text(conn, self._cur_user, want, fallback=None)
            has_any = bool(U.text_langs(conn, self._cur_user))
        # ⚠ **옛 칸으로 떨어지는 것은 언어별 본문이 아예 없을 때뿐이다.**
        #   있는데 이 언어만 없으면 **빈 칸**으로 열어야 한다 — 안 그러면 한국어
        #   제목을 띄워 놓고 「언어: English」라 적혀, 그대로 저장하면 한국어가
        #   영어 자리에 들어간다(실측으로 잡았다).
        if has_any:
            t = t if t is not None else ''
            b = b if b is not None else ''
        self._build_form({'ref_type': (r[0] if r else None) or 'STUDY', '_existing': True,
                          'ref_origin': (_og[0] if _og else None), 'ai_edited': (_og[1] if _og else 0),
                          'title': (t if t is not None else (r[1] if r else '')) or '',
                          'author': (r[2] if r else '') or '',
                          'source_name': (r[3] if r else '') or '',
                          'url': (r[4] if r else '') or '',
                          'file_path': (r[6] if r else '') or '',
                          'summary': (b if b is not None else (r[5] if r else '')) or ''})
        # ★ 317차-18 — 이 언어 표(폴백 없이 — 고칠 때 다른 언어 칸을 이 언어로 굳히지 않는다)
        try:
            import ref_doc as _RD
            with appdb.connect(self.db_path) as conn:
                self._pending_tables = _RD.get_tables(conn, 'USER', self._cur_user, want, fallback=())
        except Exception as e:                            # noqa: BLE001
            print(f'[refv form tables] {e}')
        self._set_mode(_MODE_FORM)
        self._tbl_decorate()

    def _build_form(self, row):
        """머리 칸은 **두 줄에 두 개씩** 벌인다(2026-08-10 사용자 지시).

        전에는 다섯 칸이 세로로 다섯 줄을 먹어 내용 칸이 아래로 밀렸다.
        P4 는 좌우로 길어 가로가 남으므로 세로를 아낀다.
        ⚠ 연결 칸은 여기 없다 — 왼쪽 기둥의 `_build_link_panel` 하나뿐이다.
        """
        for w in self._form_f.winfo_children():
            w.destroy()
        self._fields = {}
        self._pending_tables = {}          # ★ 317차-18 — 이 고치는 칸의 표(이 언어) · 저장 때 담긴다
        g = ttk.Frame(self._form_f); g.pack(fill='both', expand=True, padx=4, pady=4)
        g.columnconfigure(1, weight=1)
        g.columnconfigure(3, weight=1)

        # (키, 라벨, 위젯, 행, 열쌍, 가로합침)
        specs = [('ref_type',    i18n.t('COMMON_TYPE', '유형'),   'combo', 0, 0, 1),
                 ('title',       i18n.t('COMMON_TITLE', '제목'),  'entry', 0, 1, 1),
                 ('author',      i18n.t('REFV_AUTHOR', '지은이'), 'entry', 1, 0, 1),
                 ('source_name', i18n.t('REFV_SOURCE', '출처'),   'entry', 1, 1, 1),
                 ('url',         'URL',                          'entry', 2, 0, 1)]
        for key, label, kind, r, cp, span in specs:
            c = cp * 2
            ttk.Label(g, text=label).grid(row=r, column=c, sticky='w', padx=4, pady=2)
            if kind == 'combo':
                # ★ 2026-10-16 (docs/1.txt 2-2) — 유형 = 내용 셋(연구·설교·참고자료) · 출처를 따로(내가 작성·AI 작성·외부 수집)
                import ref_kinds as _RK
                _rt = row.get(key)
                if row.get('_existing'):
                    _k0, _o0 = _RK.normalize(_rt, row.get('ref_origin'), row.get('url', ''))
                else:                                       # 새 글 — 도서·교리에서 시작해도 연구 · 설교면 설교
                    _k0, _o0 = ('SERMON' if str(_rt or '').upper() == 'SERMON' else 'STUDY'), 'MINE'
                self._kind_map = {_RK.kind_label(k): k for k in _RK.KINDS}
                self._origin_map = {_RK.origin_label(o): o for o in _RK.ORIGINS}
                self._form_ai_edited = int(row.get('ai_edited') or 0)
                self._form_body0 = row.get('summary', '') or ''
                cell = ttk.Frame(g)
                cell.grid(row=r, column=c + 1, sticky='w', padx=4)
                v = tk.StringVar(value=_RK.kind_label(_k0))
                ttk.Combobox(cell, textvariable=v, values=list(self._kind_map), width=9,
                             state='readonly').pack(side='left')
                ttk.Label(cell, text=i18n.t('REFO_LBL', '출처')).pack(side='left', padx=(10, 4))
                ov = tk.StringVar(value=_RK.origin_label(_o0))
                ocb = ttk.Combobox(cell, textvariable=ov, values=list(self._origin_map), width=10,
                                   state='readonly')
                ocb.pack(side='left')
                if _o0 == 'AI' and self._form_ai_edited:
                    ttk.Label(cell, text=i18n.t('REFO_EDITED', '수정함'),
                              foreground=self._C('fg_dim', '#888')).pack(side='left', padx=(6, 0))
                self._fields['ref_origin'] = ov
                self._web_rows = []
                ocb.bind('<<ComboboxSelected>>', lambda e: self._sync_web_rows())
            else:
                v = tk.StringVar(value=row.get(key, ''))
                lw = g.grid_slaves(row=r, column=c)
                ew = ttk.Entry(g, textvariable=v)
                ew.grid(row=r, column=c + 1, columnspan=span, sticky='ew', padx=4)
                if key in ('author', 'source_name', 'url'):
                    self._web_rows.extend(lw + [ew])
            self._fields[key] = v

        # ★ **첨부파일 — URL 옆** (2026-08-14 사용자 지시).
        #   고른 파일은 `user_files/` 로 **복사**한다. 원본을 옮기거나 지우지 않는다 —
        #   사용자 폴더를 앱이 어지럽히면 안 된다.
        ttk.Label(g, text=i18n.t('REFV_FILE', '첨부파일')).grid(
            row=2, column=2, sticky='w', padx=4, pady=2)
        fw = ttk.Frame(g)
        fw.grid(row=2, column=3, sticky='ew', padx=4)
        fv = tk.StringVar(value=row.get('file_path', '') or '')
        self._fields['file_path'] = fv
        ttk.Entry(fw, textvariable=fv, state='readonly').pack(
            side='left', fill='x', expand=True)
        tk.Button(fw, text=i18n.t('REFV_ATTACH', '찾기'),
                  bg=self._C('warning_bg', '#FCF3CF'), fg=self._C('warning', '#7E5109'),
                  bd=0, padx=6, command=lambda: self._attach_file(fv)
                  ).pack(side='left', padx=(3, 0))
        tk.Button(fw, text='✕',
                  bg=self._C('panel', '#F4F6F7'), fg=self._C('fg_dim', '#7B7D7D'),
                  bd=0, padx=4,
                  command=lambda: fv.set('')).pack(side='left', padx=(2, 0))

        # ★ **어느 언어로 쓰는지 폼에 드러낸다** (2026-08-14 사용자 지적
        #   「EN 이라는 언어코드를 선택하고 한글로 입력할 위험도 있다」 ·
        #    「그 값을 텍스트 라벨로 표시/확인해주면 좋겠다」).
        #   ⚠ 값은 **상단 표시 언어 콤보**가 정한다 — 폼에 따로 고르는 칸을 두지 않는다.
        #     두 곳에서 정하면 어느 것이 이기는지 알 수 없다.
        #   ⚠ 처음에는 이 줄을 **내용 칸 아래**(row 4)에 두었다. 내용이 세로를 다 먹어
        #     화면 밖으로 밀려 **사실상 안 보였다**(사용자가 「콤보가 없다」고 한 이유).
        #     ⇒ **쓰기 시작하는 자리 바로 위**로 옮긴다.
        self._sync_web_rows()
        self._form_lang = self._view_lang()
        _lb = tk.Label(g, bg=self._C('accent_bg', '#EAF2FB'),
                       fg=self._C('accent', '#1A5276'), anchor='w', padx=8, pady=3,
                       text='%s : %s' % (i18n.t('COMMON_LANG', '언어'),
                                         lang_combo.label(self._form_lang, None,
                                                          self.db_path)))
        _lb.grid(row=3, column=0, columnspan=4, sticky='ew', padx=4, pady=(8, 2))

        # ★ **기호 단추** (2026-08-23 사용자 「연구자료/묵상노트 추가작성 또는
        #   수정할 때에도 표시하라」). 라벨 아래 — 폼은 세로가 빠듯해 한 줄을
        #   더 쓰지 않고 「내용」 라벨 칸에 함께 넣는다.
        #   ⚠ 이 폼은 열 때마다 다시 짓는다 — **위젯이 아니라 함수로** 넘긴다.
        _lblf = ttk.Frame(g)
        _lblf.grid(row=4, column=0, sticky='nw', padx=4, pady=(4, 2))
        ttk.Label(_lblf, text=i18n.t('REFV_BODY', '내용')).pack(anchor='w')
        try:
            import symbol_picker
            symbol_picker.button(
                _lblf, lambda: (self._fields or {}).get('summary'),
                text=i18n.t('MP_SYMBOLS', '기호'), db_path=self.db_path
                ).pack(anchor='w', pady=(6, 0))
        except Exception as e:
            print(f'[refv symbol] {e}')
        # ★ 317차-18 ⑤ — [표 넣기] — 칸 편집 팝업에서 만들어 커서 자리에 넣는다
        tk.Button(_lblf, text=i18n.t('REFV_TBL_INSERT', '표 넣기'), command=self._tbl_insert,
                  **_flat()).pack(anchor='w', pady=(6, 0))
        # ★ 2026-10-13 docs/1.txt 84-1 B — 쉼표·탭·`|` 로 나뉜 글을 선택하고 누르면 표로
        self._tbl_conv_btn = tk.Button(_lblf, text=i18n.t('REFV_TBL_CONVERT', '표로 바꾸기'),
                                       command=self._tbl_convert, **_flat())
        self._tbl_conv_btn.pack(anchor='w', pady=(6, 0))
        # ★ 317차-18 ⑨ — 구절 넣기 · 원어 넣기(콤보로 고르고 미리보기를 본 뒤 [넣기] · 포맷은 기억한다)
        tk.Button(_lblf, text=i18n.t('IH_VERSE', '구절 넣기'), command=lambda: self._ih_open('VERSE'),
                  **_flat()).pack(anchor='w', pady=(6, 0))
        tk.Button(_lblf, text=i18n.t('IH_ORIG', '원어 넣기'), command=lambda: self._ih_open('ORIG'),
                  **_flat()).pack(anchor='w', pady=(6, 0))
        t = tk.Text(g, wrap='word', height=14, bd=1, relief='solid', padx=6, pady=4)
        t.grid(row=4, column=1, columnspan=3, sticky='nsew', padx=4, pady=(4, 2))
        g.rowconfigure(4, weight=1)
        t.insert('1.0', row.get('summary', ''))
        self._fields['summary'] = t
        # ★ 2026-10-16 — 붙여넣기는 **글 그대로**(표는 [표 넣기]/[표로 바꾸기]) · 치거나 붙여 넣는 대로 추천 줄을 다시 뽑는다
        t.bind('<KeyRelease>', lambda _e: self._sug_soon(), add='+')
        t.bind('<<Paste>>', lambda _e: self._sug_soon(), add='+')
        # 편집 중에도 URL 이 링크로 보인다 (2026-08-19 0.txt ⑨)
        try:
            import url_text
            url_text.linkify(t)
            t.bind('<KeyRelease>', lambda _e, w=t: url_text.linkify(w), add='+')
        except Exception:
            pass
        if theme_font:
            try:
                theme_font.register(t, self.db_path, 'ref')
            except Exception:
                pass
        self._save_btn.config(text=i18n.t('COMMON_SAVE', '저장'),
                              bg=self._C('success_bg', '#A9DFBF'),
                              fg=self._C('success', '#1E8449'), command=self._save)

    # ── 연결 — 읽기·쓰기가 같은 목록을 본다 ───────────────────────
    def _link_load(self):
        """지금 보고 있는 것의 연결을 `_lnk_rows` 에 담는다.

        ⚠ sys 자료(`sys_ref_unit`)는 **읽기만** 한다 — 연결 입력은 관리자 화면 몫이다
          (2026-08-10 사용자 지시). 여기서 고칠 수 있는 것은 `user_ref_asset` 뿐이다.
        """
        import db_user_ref_schema as U
        self._lnk_rows = []
        self._lnk_from_link = set()     # `user_link` 에서 온 줄 (아래 참조)
        try:
            with appdb.connect(self.db_path) as conn:
                if self._cur_unit:                      # sys 연구 글 — 읽기 전용
                    for sv, ev, _role, label, _txt in self._article_links(self._cur_unit):
                        self._lnk_rows.append(('VERSE', sv, ev, label))
                    for eid, name, _ty in self._entity_links(ref_unit_id=self._cur_unit):
                        self._lnk_rows.append(('ENTITY', eid, None, name))
                    try:                                # ★ 2026-10-25 원어 연결(REFU_LEMM)
                        for (lk,) in conn.execute(
                                "SELECT target_id FROM sys_link_asset WHERE link_type='REFU_LEMM'"
                                " AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'"
                                " ORDER BY sort_order", (self._cur_unit,)).fetchall():
                            self._lnk_rows.append(('LEMMA', lk, None,
                                                   self._link_name(conn, 'LEMMA', lk, None)))
                    except Exception:                       # noqa: BLE001
                        pass
                    try:                                # 도서/설교 연결 (2026-08-19)
                        for (uid,) in conn.execute(
                                # ★ 2026-08-24 통합 표(`REFU_BUNT`)
                                "SELECT target_id FROM sys_link_asset "
                                "WHERE link_type='REFU_BUNT' AND clicked_id=? "
                                "  AND COALESCE(record_status,'LIVE')='LIVE' "
                                "ORDER BY sort_order", (self._cur_unit,)).fetchall():
                            self._lnk_rows.append(
                                ('BOOK_UNIT', uid, None,
                                 self._link_name(conn, 'BOOK_UNIT', uid, None)))
                    except Exception:
                        pass                            # 표가 아직 없는 DB
                elif self._cur_user:
                    rows = U.fetch_links(conn, self._cur_user)
                    if not rows:                        # 링크 표로 옮기기 전의 옛 글
                        r = conn.execute('SELECT verse_id, pericope_id FROM user_ref_asset'
                                         ' WHERE ref_id=?', (self._cur_user,)).fetchone()
                        rows = [(k, t, None) for k, t in
                                (('VERSE', r[0] if r else None),
                                 ('PERICOPE', r[1] if r else None)) if t]
                    for k, tid, end in rows:
                        self._lnk_rows.append((k, tid, end,
                                               self._link_name(conn, k, tid, end)))
                else:
                    if self._new_vid:
                        self._lnk_rows.append(
                            ('VERSE', self._new_vid, None,
                             self._link_name(conn, 'VERSE', self._new_vid, None)))
                    eid = getattr(self, '_new_eid', None)
                    if eid:
                        self._lnk_rows.append(
                            ('ENTITY', eid, None,
                             self._link_name(conn, 'ENTITY', eid, None)))
                # ★★ **[연결] 창으로 붙인 것(`user_link`)을 갈래 밖에서 합친다**
                #   (2026-08-21 사용자 신고 「sys 데이터에 입력했는데 표시가
                #   안 되고 오류도 없었다」).
                #   ⚠ 원인: 이 합치기가 **내 자료 갈래 안에만** 있었다. 자료집
                #     글은 [연결] 창의 대상이 `REF_UNIT` 인데 읽는 쪽은 sys 표만
                #     봐서, 넣은 것이 어디에도 안 보였다. **저장은 잘 됐다.**
                #   ⇒ 넣는 쪽(`_tag_target`)과 읽는 쪽이 **같은 대상**을 본다.
                #   ⚠ 이 줄들은 **옛 표에 되쓰면 안 된다** — 두 표에 한 벌씩
                #     생긴다. `_lnk_from_link` 로 표시해 둔다.
                tgt = self._tag_target()
                if tgt:
                    have = {(k, t, e) for k, t, e, _n in self._lnk_rows}
                    try:
                        import link_picker
                        for x in link_picker.links_of(conn, tgt[0], tgt[1],
                                                      self._view_lang()):
                            if x['src'] != 'LINK':   # 태그·기본 연결은 딴 데서
                                continue
                            key = (x['kind'], x['id'], x['end'])
                            if key in have:
                                continue
                            have.add(key)
                            self._lnk_from_link.add(key)
                            self._lnk_rows.append(
                                (x['kind'], x['id'], x['end'], x['label']))
                    except Exception as e:
                        print(f'[RefDetailView _link_load user_link] {e}')
        except Exception as e:
            print(f'[RefDetailView _link_load] {e}')
        self._link_redraw()

    def _link_name(self, conn, kind, tid, end):
        lang = self._view_lang()
        if kind == 'LEMMA':                 # ★ 2026-10-25 승격 안 된 원어 — 「χάρις charis (G5485)」
            try:
                import orig_ref as _OR
                return _OR.label(conn, 'LEMMA', tid, lang)
            except Exception:                             # noqa: BLE001
                return str(tid)
        if kind == 'ENTITY':
            r = conn.execute("SELECT contents FROM sys_text_asset WHERE clicked_id=?"
                             " AND text_type='ENTITY_NAME' AND lang_code=? LIMIT 1",
                             (tid, lang)).fetchone()
            return r[0] if r else str(tid)
        if kind == 'PERICOPE':
            r = conn.execute('SELECT start_vid, end_vid FROM sys_pericope_asset'
                             ' WHERE pericope_id=?', (tid,)).fetchone()
            return self._ref_label(conn, r[0], r[1], lang) if r else str(tid)
        if kind == 'BOOK_UNIT':
            # 콤보 표시로 바뀌어(2026-08-19 2차 — 라벨이 암호 같아 나열 폐지)
            # 넉넉히 담되 40자에서 자른다. 책 제목(번역 우선)을 앞에 붙인다.
            r = conn.execute(
                "SELECT COALESCE((SELECT t.title FROM sys_book_asset_text t "
                "                  WHERE t.book_id=ba.book_id "
                "                    AND UPPER(t.lang_code)=? LIMIT 1), ba.title), "
                "       COALESCE(bu.unit_label,'') "
                "  FROM sys_book_unit bu "
                "  JOIN sys_book_asset ba ON ba.book_id=bu.book_id "
                " WHERE bu.unit_id=?", (lang, tid)).fetchone()
            nm = ('%s · %s' % (r[0], r[1])) if r else str(tid)
            return nm[:45] + ('…' if len(nm) > 45 else '')
        return self._ref_label(conn, tid, end or tid, lang)

    _KIND_LBL = {'VERSE': ('REFV_KIND_VERSE', '구절'),
                 'PERICOPE': ('REFV_KIND_PERI', '단락'),
                 'ENTITY': ('REFV_ROLE_ENTITY', '용어'),
                 'LEMMA': ('REFV_KIND_LEMMA', '원어'),
                 'BOOK_UNIT': ('REFV_KIND_BOOK', '도서·설교'),
                 # [연결] 창이 데려오는 것들 (2026-08-21) — 이름을 못 대면
                 # 표시줄에서 통째로 빠져 「붙였는데 안 보인다」가 된다.
                 'LENS': ('LP_K_LENS', '렌즈'),
                 'NODE': ('LP_K_NODE', '노드'),
                 'ULENS': ('LP_K_ULENS', '내 렌즈'),
                 'UNODE': ('LP_K_UNODE', '내 노드'),
                 'BOOK': ('LP_K_BOOK', '도서'),
                 'REF_UNIT': ('LP_K_REF_UNIT', '교리자료'),
                 'USER_REF': ('LP_K_USER_REF', '연구자료')}

    # 표시줄 유형 묶음 — 구절·단락/용어. 도서·설교 유닛은 아래 콤보(2026-08-19).
    # 머리글은 묶음 **첫 종류**의 이름을 쓴다.
    _STRIP_GROUPS = (('VERSE', 'PERICOPE'), ('ENTITY',), ('LEMMA',),
                     ('LENS', 'NODE', 'ULENS', 'UNODE'),   # → 「렌즈」
                     ('BOOK',), ('REF_UNIT',), ('USER_REF',))

    def _link_redraw(self):
        """연결대상 표시 = 오른쪽 본문 상단 약명 나열 + 빼기 콤보 갱신
        (2026-08-19 사용자 재설계 — 왼쪽 목록 Treeview 폐지)."""
        # ① 본문 상단 표시줄 — 유형별 「구절·단락 / 용어 / 도서·설교」 나열
        self._strip_retag()                 # 테마가 바뀌었어도 이번 렌더부터 맞는 색
        t = self._link_strip
        t.config(state='normal')
        t.delete('1.0', 'end')
        any_row = False
        for group in self._STRIP_GROUPS:
            names = [nm for (k, _t2, _e, nm) in self._lnk_rows if k in group]
            if not names:
                continue
            if any_row:
                t.insert('end', '   ')
            any_row = True
            key, dflt = self._KIND_LBL[group[0] if group[0] != 'VERSE'
                                       else 'VERSE']
            hdr = (i18n.t('REFV_KIND_VP', '구절·단락')
                   if group[0] == 'VERSE' else i18n.t(key, dflt))
            t.insert('end', hdr + '  ', ('k',))
            t.insert('end', ' · '.join(names), ('v',))
        # ★ 태그도 같은 줄에 (2026-08-21) — sys 글이든 내 글이든. 없으면 안 나온다.
        _tgt = self._tag_target()
        if _tgt:
            try:
                import tag_picker
                tg = [nm for _s, _t3, nm, _c in tag_picker.tags_of(
                    self.db_path, _tgt[0], _tgt[1], self._view_lang())]
                if tg:
                    if any_row:
                        t.insert('end', '   ')
                    any_row = True
                    t.insert('end', i18n.t('TAG_BTN', '태그') + '  ', ('k',))
                    t.insert('end', ' · '.join(tg), ('v',))
            except Exception:
                pass
        t.config(state='disabled')
        if any_row:
            if not t.winfo_manager():
                t.pack(fill='x', pady=(0, 2))
                self._foot_order()
        else:
            t.pack_forget()

        # ①-2 도서·설교 콤보 — 있을 때만, 표시줄(또는 제목) 바로 아래
        pairs = [(t2, nm) for (k, t2, _e, nm) in self._lnk_rows if k == 'BOOK_UNIT']
        self._book_ids = [t2 for t2, _nm in pairs]     # [▶ 보기] 가 콤보 순번으로 읽는다
        books = [nm for _t2, nm in pairs]
        if books:
            self._book_combo.config(values=books)
            self._book_combo.current(0)
            if not self._book_row.winfo_manager():
                self._book_row.pack(fill='x', pady=(0, 2))
                self._foot_order()
        else:
            self._book_row.pack_forget()

        # ② 요약 라벨 — 「지금 몇 건이 걸렸나」
        #   ⚠ 옛 빼기 콤보와 잠금 처리는 입력칸과 함께 걷었다(2026-08-21).
        #     넣고 빼는 자리는 이제 [연결] 창 하나다.
        nv = sum(1 for r in self._lnk_rows if r[0] in ('VERSE', 'PERICOPE'))
        ne = sum(1 for r in self._lnk_rows if r[0] == 'ENTITY')
        nb = sum(1 for r in self._lnk_rows if r[0] == 'BOOK_UNIT')
        parts = []
        if nv:
            parts.append(i18n.t('REFV_LINKS', '연결된 구절') + ' (%d)' % nv)
        if ne:
            parts.append(i18n.t('REFV_LINKS_ENT', '연결된 용어') + ' (%d)' % ne)
        if nb:
            parts.append(i18n.t('REFV_KIND_BOOK', '도서·설교집') + ' (%d)' % nb)
        self._link_lbl.config(text='   '.join(parts)
                              or i18n.t('REFV_LINKS', '연결된 구절'))
        # ★ 315차 — **연결이 바뀌는 단일 통로**라 추천도 여기서 따라온다
        #   (자리마다 흩으면 하나가 반드시 빠진다).
        try:
            self._sug_refresh()
        except Exception:                                     # noqa: BLE001
            pass

    def _book_jump(self):
        """도서·설교 콤보에서 선택한 유닛의 P1 읽기 화면으로 (2026-08-19)."""
        if not (self.on_book_jump and getattr(self, '_book_ids', None)):
            return
        try:
            i = self._book_combo.current()
        except Exception:
            return
        if 0 <= i < len(self._book_ids):
            try:
                self.on_book_jump(self._book_ids[i])
            except Exception as e:
                print(f'[RefDetailView _book_jump] {e}')

    # ── 도서/설교 연결 (2026-08-19 — user db 에만 저장, 사용자 화면 원칙) ──

    def _save(self):
        title = self._fields['title'].get().strip()
        body  = self._fields['summary'].get('1.0', 'end').strip()
        # ★ 317차-18 — 글 속 `|` 표·격자 표는 **구조로 바꾸고 자리표를 둔다**(ref_doc.absorb ·
        #   워드에서 가져온 표는 `_pending_tables` 에 이미 있다)
        _tables = dict(getattr(self, '_pending_tables', None) or {})
        try:
            import ref_doc as _RD
            body, _abs = _RD.absorb(body, tsv=False)
            _tables.update(_abs)
        except Exception as e:                            # noqa: BLE001
            print(f'[refv absorb] {e}')
        if not title and not body:
            messagebox.showwarning(i18n.t('COMMON_SAVE', '저장'),
                                   i18n.t('REFV_NEED_BODY', '제목이나 내용 가운데 하나는 있어야 합니다.'),
                                   parent=self)
            return
        # ★ **글자와 언어가 어긋나면 한 번 묻는다** (2026-08-14 사용자 제안).
        #   ⚠ 막지는 않는다 — 사람이 무엇을 치든 막을 수 없다. 다만 흔한 실수
        #     (콤보가 English 인 줄 모르고 한글로 씀)는 여기서 거의 다 잡힌다.
        lang = getattr(self, '_form_lang', None) or self._view_lang()
        got = lang_combo.mismatch(title + '\n' + body, lang)
        if got:
            if not messagebox.askyesno(
                    i18n.t('COMMON_SAVE', '저장'),
                    i18n.t('REFV_LANG_MISMATCH',
                           '{sel} 로 선택해 두셨는데 {got} 로 쓰신 것 같습니다.\n'
                           '이대로 저장할까요?').format(
                        sel=lang_combo.label(lang, None, self.db_path),
                        got=lang_combo.label(got, None, self.db_path)),
                    parent=self):
                return
        file_path = (self._fields.get('file_path').get().strip()
                     if self._fields.get('file_path') else '')
        _km = getattr(self, '_kind_map', {})
        _om = getattr(self, '_origin_map', {})
        _kind = _km.get(self._fields['ref_type'].get(), 'STUDY')
        _orig = _om.get(self._fields['ref_origin'].get(), 'MINE') if 'ref_origin' in self._fields else 'MINE'
        _web = _orig == 'WEB'
        # AI 가 쓴 글을 사람이 고쳐 저장하면 「수정함」(한 번 켜지면 그대로)
        _edited = 1 if (_orig == 'AI' and (getattr(self, '_form_ai_edited', 0)
                                           or body.strip() != (getattr(self, '_form_body0', '') or '').strip())) else 0
        vals = (_kind, title,
                self._fields['author'].get().strip() if _web else '',
                self._fields['source_name'].get().strip() if _web else '',
                self._fields['url'].get().strip() if _web else '', body, file_path)
        import db_user_ref_schema as U
        if getattr(self, '_draft_src', None) and not self._cur_user:
            # ★ 2026-10-15 91-1 — 배포 연구노트의 초안 → **지금** 내 연구노트로(모든 언어·표·연결 함께 · 원본 가림)
            import copy_own
            try:
                with appdb.connect(self.db_path) as c0:
                    self._cur_user = copy_own.copy_ref(c0, self._draft_src, lang, hide=True)
            except Exception as e:                        # noqa: BLE001
                messagebox.showerror(i18n.t('COMMON_SAVE', '저장'), str(e), parent=self)
                return
            self._draft_src = None
            self._new_vid = None
            self._src = {}
        with appdb.connect(self.db_path) as conn:
            U.init(conn)              # 멱등 — 표가 없는 첫 실행을 막는다
            if self._cur_user:
                conn.execute("UPDATE user_ref_asset SET ref_type=?, title=?, author=?, "
                             "source_name=?, url=?, summary=?, file_path=? WHERE ref_id=?",
                             vals + (self._cur_user,))
                new_id = self._cur_user
            else:
                cur = conn.execute(
                    # ★ **어느 도서·설교 유닛에서 왔는지 남긴다** (2026-08-16).
                    #   ⚠ 칸(`body_unit_id`)은 있는데 **아무도 안 채우고 있었다**
                    #     (실측 0행). 그래서 「도서 A에 연결된 연구자료」를 물어도
                    #     늘 빈 목록이었다 — 화면이 없어서가 아니라 **자료가 안 남아서**다.
                    "INSERT INTO user_ref_asset (verse_id, ref_type, title, author, "
                    "  source_name, url, summary, file_path, lang_code, "
                    "  body_unit_id, record_status) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?,'LIVE')",
                    (self._new_vid,) + vals + (lang, (self._src or {}).get('unit_id')))
                new_id = cur.lastrowid
            try:
                import ref_kinds as _RK
                _RK.ensure(conn)
                conn.execute("UPDATE user_ref_asset SET ref_origin=?, ai_edited=? WHERE ref_id=?",
                             (_orig, _edited, new_id))
            except Exception as e:                        # noqa: BLE001
                print(f'[refv origin] {e}')
            conn.commit()
            # ★ **언어별 본문**에 적는다 — 같은 글의 다른 언어판이 서로를 안 밀어낸다
            #   (2026-08-14). `user_ref_asset.title`·`summary` 는 옛 칸이라 함께 맞춰만 둔다.
            U.set_text(conn, new_id, lang, title, body)
            # ★ 317차-18 — 표 맞추기(이 언어 표를 담고 어느 언어 글에도 자리표가 없는 표는 HIDE)
            try:
                import ref_doc as _RD
                _RD.ensure(conn, ('USER',))
                _all = [r_[0] or '' for r_ in conn.execute(
                    "SELECT body_text FROM user_ref_text WHERE ref_id=? AND COALESCE(record_status,'LIVE')='LIVE'",
                    (new_id,))]
                _RD.sync(conn, 'USER', new_id, _all, _tables, lang, commit=False)
            except Exception as e:                        # noqa: BLE001
                print(f'[refv tables save] {e}')
            self._pending_tables = {}
            # ★ **글이 시작된 자리를 그대로 이어 준다** (2026-08-21 재작성).
            #   구절을 보다가, 또는 주요용어를 보다가 [+ 추가하기]로 이 글을
            #   썼다면 그 구절·용어가 저절로 걸린다. 옛 입력칸을 걷었으므로
            #   **새 표(`user_link`)** 로 적는다. 용어는 이관 때와 같은 규칙으로
            #   **그 용어의 태그**가 된다(엔티티 451개가 전부 태그로 승격돼 있다).
            self._link_origin(conn, new_id)
            conn.commit()
            # ★ 2026-10-13 docs/1.txt 84-2 — **저장하면 자동 연결을 다시 본다**: 모든 언어판의 글(표 칸 포함)에서
            #   약명을 다시 읽어, 글에서 사라진 자동 연결(CITE_AUTO)은 걷는다. 새로 거는 것은 추천 줄에서
            #   사람이 체크한다(장·편만 적힌 것은 아예 안 건다). 사람이 손으로 이은 것·지운 것은 안 건드린다.
            try:
                import scripture_ref as _SR
                import ref_doc as _RD
                _found = []
                for _lg, _bt in conn.execute(
                        "SELECT UPPER(lang_code), body_text FROM user_ref_text WHERE ref_id=?"
                        " AND COALESCE(record_status,'LIVE')='LIVE'", (new_id,)).fetchall():
                    _txt = (_bt or '') + '\n' + _RD.all_cells_text(conn, 'USER', new_id, _lg or lang)
                    _found += _SR.linkable(_SR.find(conn, _txt, _lg or lang, limit=200))
                U.sync_links(conn, new_id, [('VERSE', a, b) for a, b, _m, _k in _found], add=False)
                # ★ 2026-10-25 원어 — 글에서 사라진 자동 원어 연결도 걷는다(사람이 이은 것·지운 것은 그대로)
                import orig_ref as _OR
                _of = []
                for _lg, _bt in conn.execute(
                        "SELECT UPPER(lang_code), body_text FROM user_ref_text WHERE ref_id=?"
                        " AND COALESCE(record_status,'LIVE')='LIVE'", (new_id,)).fetchall():
                    _txt = (_bt or '') + '\n' + _RD.all_cells_text(conn, 'USER', new_id, _lg or lang)
                    _of += [(k, t, None) for k, t, _m, _s in _OR.find(conn, _txt, _lg or lang)]
                U.sync_links(conn, new_id, _of, add=False, kinds=('ENTITY', 'LEMMA'))
            except Exception as e:                        # noqa: BLE001
                print(f'[refv relink] {e}')
        # ★ 2026-10-13 docs/1.txt 84 — **저장할 때 연결 창을 저절로 띄우지 않는다**(사용자 「제거해도 좋다」).
        #   구절은 본문 위 추천 줄에서 체크로 잇고, 그 밖의 연결은 [연결]·[My Edit] 단추가 연다.
        #   (옛 2026-08-21 「저장되자마자 연결하기 창」을 걷었다.)
        self._search(select_iid=f'U|{new_id}')
        self.show_user(new_id, _from_list=True)
        if callable(self.on_saved):
            self.on_saved(new_id)

    # ══════════════════════════════════════════════════════════════
    #  ★ 317차-18 ③ — 워드로 편집(A 방식) · 워드 파일 가져오기 (ref_docx)
    # ══════════════════════════════════════════════════════════════
    def export_doc(self):
        """지금 보는 글 → (제목, 본문, 표, 언어). 내 글은 선택한 언어 · 공용 글은 그 언어 → EN → KO."""
        import ref_doc as _RD
        lang = self._view_lang()
        with appdb.connect(self.db_path) as conn:
            if self._cur_user:
                import db_user_ref_schema as U
                t, b, _u = U.fetch_text(conn, self._cur_user, lang, fallback=None)
                return t or '', b or '', _RD.get_tables(conn, 'USER', self._cur_user, lang, fallback=()), lang
            unit = getattr(self, '_cur_unit', None)
            if not unit:
                return None
            for lg in (lang, 'EN', 'KO'):
                r = conn.execute("SELECT title, body_text FROM sys_ref_text WHERE ref_unit_id=?"
                                 " AND UPPER(lang_code)=? AND record_status='LIVE' AND COALESCE(body_text,'')<>''"
                                 " LIMIT 1", (unit, lg)).fetchone()
                if r:
                    return r[0] or '', r[1] or '', _RD.get_tables(conn, 'SYS', unit, lg), lg
        return None

    def _word_export(self, path=None):
        """[워드로 내보내기] — 선택한 자리에 .docx 를 짓는다(표는 진짜 표로). `path` 를 주면 묻지 않는다."""
        import re as _re
        import ref_docx as _DX
        doc = self.export_doc()
        if not doc:
            return None
        title, body, tables, _lg = doc
        asked = path is None
        if asked:
            from tkinter import filedialog
            name = _re.sub(r'[\\/:*?"<>|]+', ' ', title or 'note').strip()[:60] or 'note'
            path = filedialog.asksaveasfilename(parent=self, defaultextension='.docx',
                                                initialfile=name + '.docx',
                                                title=i18n.t('REFV_WORD_EXPORT', '워드로 내보내기'),
                                                filetypes=[('Word', '*.docx')])
            if not path:
                return None
        try:
            _DX.write_docx(path, title, body, tables)
        except Exception as e:                            # noqa: BLE001
            messagebox.showwarning(i18n.t('REFV_WORD_EXPORT', '워드로 내보내기'),
                                   i18n.t('REFV_WORD_FAIL', '파일을 열지 못했습니다: %s') % e, parent=self)
            return None
        if asked:
            messagebox.showinfo(i18n.t('REFV_WORD_EXPORT', '워드로 내보내기'),
                                i18n.t('REFV_WORD_SAVED', '저장했습니다: %s') % path, parent=self)
        return path

    def _word_fill(self, data, lang, draft=False):
        """가져온 글로 고치는 칸을 채운다 — 사람이 살펴보고 [저장]을 누른다(그 자리에서 담지 않는다)."""
        if draft:
            pass                              # `_draft_form` 이 이미 칸을 지었다
        elif self._cur_user:
            self._to_form()
        else:
            self._build_form({})
            self._set_mode(_MODE_FORM)
        self._form_lang = lang
        try:
            f = self._fields
            if data.get('title'):
                f['title'].set(data['title'])             # 제목 칸은 StringVar
            f['summary'].delete('1.0', 'end')
            f['summary'].insert('1.0', data.get('text') or '')
            # ⚠ 칸을 코드로 갈아 끼웠다 — 칩 기억을 비운다(안 비우면 「사람이 칩을 지웠다」로 보고
            #   새로 들어온 자리표까지 지운다 · 하네스가 잡았다)
            f['summary']._rd_chips = {}
        except Exception as e:                            # noqa: BLE001
            print(f'[refv word fill] {e}')
        self._pending_tables = dict(data.get('tables') or {})
        self._tbl_decorate()
        msg = i18n.t('REFV_WORD_GOT', '워드에서 수정한 글을 가져왔습니다 — 살펴보고 [저장]을 누르세요.')
        warn = data.get('warn') or {}
        if warn:
            msg += '  ' + i18n.t('REFV_WORD_WARN', '가져오지 않은 것: %s') % ' · '.join(
                '%s %d' % (i18n.t(WORD_WARN_KEY.get(k, ''), k), n) for k, n in warn.items())
        kids = self._form_f.winfo_children()
        lb = tk.Label(self._form_f, text=msg, anchor='w', justify='left', wraplength=700,
                      bg=self._C('warning_bg', '#FDEBD0'), fg=self._C('fg', '#222222'), padx=6, pady=3)
        lb.pack(fill='x', before=kids[0]) if kids else lb.pack(fill='x')

    def _ih_open(self, kind):
        import insert_helpers as _IH
        t = (self._fields or {}).get('summary')
        lang = getattr(self, '_form_lang', None) or self._view_lang()
        cls = _IH.VerseInsert if kind == 'VERSE' else _IH.OrigInsert
        kw = {}
        if kind == 'ORIG' and t is not None:
            try:
                kw['word'] = t.get('sel.first', 'sel.last').strip()[:20]   # 선택해 둔 낱말이 있으면 그것으로
            except Exception:                             # noqa: BLE001
                pass
        return cls(self, t, db_path=self.db_path, lang=lang, side='USER', C=self._C, **kw)

    # ── ★ 317차-18 ⑤ — 고치는 칸의 표 칩 · 칸 편집 ─────────────────────
    def _tbl_decorate(self):
        try:
            import ref_table_edit as _TE
            t = (self._fields or {}).get('summary')
            if t is not None:
                _TE.decorate(t, lambda: self._pending_tables, self._tbl_edit, C=self._C)
        except Exception as e:                            # noqa: BLE001
            print(f'[refv tbl chip] {e}')

    def _tbl_open(self, table, on_save):
        import ref_table_edit as _TE
        hint = i18n.t('REFV_TBL_HINT', '빈 칸은 읽을 때 기본 언어의 글로 보입니다.')
        return _TE.TableEditor(self, table, on_save, db_path=self.db_path, C=self._C, hint=hint)

    def _tbl_edit(self, no):
        def done(t):
            self._pending_tables[no] = t
            self._tbl_decorate()
        return self._tbl_open(self._pending_tables.get(no), done)

    def _tbl_insert(self):
        """새 표 — 팝업에서 만들고 [저장]하면 커서 자리에 자리표를 넣는다."""
        import ref_doc as _RD
        import ref_table_edit as _TE
        txt = (self._fields or {}).get('summary')
        if txt is None:
            return None
        existing = []
        if self._cur_user:
            try:
                with appdb.connect(self.db_path) as conn:
                    existing = [r_[0] for r_ in conn.execute(
                        'SELECT table_no FROM user_ref_table WHERE ref_id=?', (self._cur_user,))]
            except Exception:                             # noqa: BLE001
                pass
        no = _TE.next_no(txt.get('1.0', 'end-1c'), self._pending_tables, existing)

        def done(t):
            self._pending_tables[no] = t
            at = txt.index('insert')
            pre = '' if txt.compare(at, '==', '%s linestart' % at) else '\n'
            txt.insert(at, pre + _RD.token(no) + '\n')
            self._tbl_decorate()
        return self._tbl_open(None, done)

    def _tbl_existing(self):
        if not self._cur_user:
            return []
        try:
            with appdb.connect(self.db_path) as conn:
                return [r_[0] for r_ in conn.execute(
                    'SELECT table_no FROM user_ref_table WHERE ref_id=?', (self._cur_user,))]
        except Exception:                                 # noqa: BLE001
            return []

    def _tbl_convert(self):
        """[표로 바꾸기] — 선택한 글(탭·쉼표·`|` 로 나뉜 줄)을 표로(84-1 B)."""
        import ref_table_edit as _TE
        txt = (self._fields or {}).get('summary')
        if txt is None:
            return None
        no = _TE.text_to_table(txt, self._pending_tables, self._tbl_existing(),
                               decorate=self._tbl_decorate)
        if not no:
            b = getattr(self, '_tbl_conv_btn', None)
            if b is not None:
                b.config(text=i18n.t('REFV_TBL_CONVERT_HINT', '표 모양의 글을 먼저 선택하세요'))
                b.after(2500, lambda: b.winfo_exists() and b.config(
                    text=i18n.t('REFV_TBL_CONVERT', '표로 바꾸기')))
        return no

    def _word_import(self):
        """이미 워드로 보관한 글을 **새 노트**로 — 파일을 선택하면 고치는 칸에 채운다."""
        from tkinter import filedialog
        path = filedialog.askopenfilename(parent=self, title=i18n.t('REFV_WORD_IMPORT', '워드 파일 가져오기'),
                                          filetypes=[('Word', '*.docx'), ('*', '*.*')])
        if not path:
            return
        self.import_docx(path)

    def import_docx(self, path):
        """(하네스·다른 화면도 부른다) 파일 하나를 새 노트 칸으로."""
        try:
            import ref_docx as _DX
            data = _DX.read_docx(path)
        except Exception as e:                            # noqa: BLE001
            messagebox.showwarning(i18n.t('REFV_WORD_IMPORT', '워드 파일 가져오기'),
                                   i18n.t('REFV_WORD_FAIL', '파일을 읽지 못했습니다: %s') % e, parent=self)
            return False
        if not data.get('title'):
            import os
            data['title'] = os.path.splitext(os.path.basename(path))[0]
        self.show_new(None)
        self._word_fill(data, self._view_lang())
        return True

    def _link_origin(self, conn, ref_id):
        """새 글이 **시작된 자리**를 그 글에 이어 준다 (2026-08-21).

        구절을 보다가 [+ 추가하기] 를 누르면 `_new_vid`, 주요용어에서 누르면
        `_new_eid` 가 들어 있다. 그 자리를 안 이어 주면 사용자가 방금 어디서
        썼는지가 글에 남지 않는다.
        ⚠ 용어는 **`user_link` 에 넣을 수 없다** — 연결 대상 열에 엔티티가
          없다. 이관 때와 같은 규칙으로 **그 용어의 태그**를 붙인다."""
        try:
            import link_picker
            if self._new_vid:
                link_picker.add(conn, ('USER_REF', ref_id),
                                ('VERSE', self._new_vid))
            # ★★★ **도서 편도 이어 준다** (2026-08-31 사용자 신고 「스펄전
            #   아침묵상1은 연구자료(1) 제목=dfdf 와 연결되어 있다고 표시되는데
            #   **통합연결팝업의 왼쪽 화면에 전혀 표시되지 않는다**」).
            #   ⚠⚠ 원인 — 여기가 **구절과 용어만** 이어 주고 도서 편은
            #     `body_unit_id` **칸만** 채웠다. 그래서
            #     · 3단 단추 「연구자료 (n)」 = 칸 + 연결 표 → 1
            #     · My Edit ① 현황 = **연결 표만** → 0
            #     두 화면이 **서로 다른 것을 세면서 같은 이름**을 썼다.
            #     ①에 안 뜨니 ⇨ 로 뗄 수도 없었다.
            #   ⇒ **쓰는 문에서 함께 남긴다** — 읽는 쪽을 고치면(칸도 읽게 하면)
            #     자산 전반의 단일 문에 도서 특례가 들어간다. 근본은 여기다.
            #   실측 그 어긋남 = `body_unit_id` 3편 중 **3편 전부**
            #   (구절 13편은 위 한 줄 덕에 어긋남 0이었다).
            _bu = (self._src or {}).get('unit_id')
            if _bu:
                link_picker.add(conn, ('USER_REF', ref_id),
                                ('BOOK_UNIT', _bu))
            eid = getattr(self, '_new_eid', None)
            if eid:
                r = conn.execute(
                    "SELECT sys_tag_id FROM sys_tag_asset WHERE entity_id=? "
                    "  AND COALESCE(record_status,'LIVE')='LIVE'", (eid,)).fetchone()
                if r:
                    # ⚠⚠ **2026-08-25 정정** — 여기만 옛 표(`user_tag_link`)에
                    #   쓰고 있었다. 통합 이후 화면은 통합 표를 읽으므로
                    #   **붙인 태그가 어디에도 안 보였다.** 저장은
                    #   `tag_picker` 한 곳으로 모은다(멱등).
                    import tag_picker
                    cur = {(s2, t2) for s2, t2, _n, _c
                           in tag_picker.tags_of(None, 'USER_REF', ref_id)}
                    tag_picker.save_links(None, 'USER_REF', ref_id,
                                          cur | {('SYS', r[0])})
            # 옛 단일 칸도 맞춰 둔다 — 아직 이 칸을 읽는 화면이 있다
            conn.execute('UPDATE user_ref_asset SET entity_id=COALESCE(?, entity_id),'
                         ' verse_id=COALESCE(?, verse_id) WHERE ref_id=?',
                         (eid, self._new_vid, ref_id))
        except Exception as e:
            print(f'[RefDetailView _link_origin] {e}')

    def _refresh_open(self, ref_id):
        """[연결] 창에서 넣거나 뺄 때마다 **이 화면도 곧바로 되그린다**
        (2026-08-21 사용자 — 「닫기 전에 실제 화면이 바뀌는 것을 확인하기 좋다」)."""
        try:
            self.show_user(ref_id, _from_list=True)
        except Exception as e:
            print(f'[RefDetailView _refresh_open] {e}')

    def _tag_target(self):
        """지금 보고 있는 것의 태그 열쇠 → (target_type, target_id) 또는 None.

        ★ **기본(sys) 자료에도 사용자가 태그를 단다** (2026-08-21 사용자 —
          「sys 자료에 태그를 연결하는 것은 데이터 안전에 문제가 없다」).
          맞는 말이다: 연결은 **`user_tag_link`(내 DB)** 에만 남고 배포 DB 는
          읽기만 한다. 콘텐츠를 교체해도 내 태그는 살아남는다.
        ⚠ 그래서 target_type 이 둘이다 — 내 글은 `USER_REF`, 자료집 글은
          `REF_UNIT`(관리자가 sys_tag_link 에 쓰는 것과 **같은 이름·다른 표**)."""
        if self._cur_user:
            return ('USER_REF', self._cur_user)
        if self._cur_unit:
            return ('REF_UNIT', self._cur_unit)
        return None

    def _edit_tags(self):
        """[연결] — 지금 보고 있는 글에 **모든 종류를 한 창에서** 잇는다.

        ★ **[태그] 단추를 대체한다** (2026-08-21 사용자 확정 — 0.txt 3번).
          그전에는 연결 입력이 네 군데였다: 태그는 저장 직후 팝업, 구절·용어·
          도서는 왼쪽 하단 입력칸. **같은 일인데 방법이 넷**이었다.
          이제 `link_picker` 한 창이 성경·태그·렌즈·도서·교리자료·연구자료를
          다 받고 **자기 종류만 잠긴다**.
        ★ **잠그지 않고 이유를 알린다** — 눌리지 않는 단추는 「고장」으로 읽힌다.
        ⚠ 함수 이름은 `_edit_tags` 그대로 두었다 — 부르는 곳이 여럿이다."""
        tgt = self._tag_target()
        if not tgt:
            import tag_picker
            tag_picker.need_target(self, i18n.t('TAG_NEED_REF', '연구/설교노트'))
            return
        tt, tid = tgt
        try:
            import link_picker

            def redraw():
                # ★ 넣거나 뺄 때마다 **곧바로** 되그린다 — 창을 닫기 전에
                #   표시줄이 실제로 바뀌는 것을 볼 수 있어야 한다(사용자 지시).
                if self._mode != _MODE_TEXT:
                    return
                if self._cur_user:
                    self.show_user(self._cur_user, _from_list=True)
                elif self._cur_unit:
                    self.show_article(self._cur_unit, _from_list=True)
            link_picker.open_picker(
                self, self.db_path, tt, tid,
                lang_getter=self._view_lang,
                ver_getter=(self.ver_getter if callable(
                    getattr(self, 'ver_getter', None)) else None),
                on_open=(self.on_link_open if callable(
                    getattr(self, 'on_link_open', None)) else None),
                on_saved=redraw)
        except Exception as e:
            print(f'[RefDetailView _edit_tags] {e}')

    def _open_ai(self):
        """[AI] — 지금 보고 있는 연구자료를 닻으로 AI 도우미를 연다.

        ★ 닻은 `'USER_REF:175'`·`'REF_UNIT:9'` 글자다 — 내 글과 자료집 글이
          **번호 공간이 달라** 번호만으로는 어느 표인지 알 수 없다(§240차).
        ⚠ 보고 있는 글이 없으면 아무 일도 안 한다(엉뚱한 닻을 세우지 않는다).
        """
        anchor = None
        if self._cur_user:
            anchor = 'USER_REF:%d' % int(self._cur_user)
        elif self._cur_unit:
            anchor = 'REF_UNIT:%d' % int(self._cur_unit)
        if not anchor:
            return
        if callable(getattr(self, 'on_ai', None)):
            try:
                self.on_ai(anchor)
            except Exception as e:                        # noqa: BLE001
                print('[RefDetailView ai] %s' % e)

    def _open_my_edit(self):
        """[My Edit] — **지금 보고 있는 자료**를 기준으로 연다 (2026-08-27
        사용자 — 「선택한 연구자료로 자동 변경될 것으로 기대했다」).

        · 내 자료(user_ref_asset) → 그 자료 기준 연결 작업대(USER)
        · 수입 글(sys_ref_unit) → 내가 고칠 것이 없다. 그 글이 걸린
          **구절**을 기준으로 총괄 창을 연다(호스트가 준 콜백).
        ⚠ 기준을 안 옮기면 창1:1 같은 엉뚱한 기준이 뜬다 — 그것이 신고였다.
        """
        if self._cur_user:
            # ★ 3단계 — 팝업 대신 **주방**(2026-08-28). 연결뿐 아니라 본문·
            #   휴지통까지 한 창에서 다룬다.
            try:
                import my_edit
                my_edit.open(self, 'USER_REF', int(self._cur_user),
                             on_changed=lambda _k=None:
                             self._refresh_open(self._cur_user))
            except Exception as e:
                print(f'[RefDetailView my edit] {e}')
            return
        if callable(self.on_my_edit):
            self.on_my_edit()
        else:
            messagebox.showinfo(
                i18n.t('OE_BTN', 'My Edit'),
                i18n.t('REFV_ME_PICK', '내 자료를 선택하면 그 자료의 연결을 '
                       '여기서 고칠 수 있습니다.'), parent=self)

    def _delete(self):
        if not self._cur_user:
            return
        if not messagebox.askyesno(i18n.t('COMMON_DELETE', '삭제'),
                                   i18n.t('REFV_DEL_ASK', '이 자료를 삭제할까요?'), parent=self):
            return
        with appdb.connect(self.db_path) as conn:
            conn.execute("UPDATE user_ref_asset SET record_status='HIDE' WHERE ref_id=?",
                         (self._cur_user,))
            conn.commit()
        gone, self._cur_user = self._cur_user, None
        if callable(self.on_saved):
            self.on_saved(gone)
        self._search()
        self.clear()

    # ── ③ 영상 ────────────────────────────────────────────────────
    def show_video(self, video_id: str, title: str = ''):
        self._hide_read_btn()
        self._cur_unit = self._cur_user = None
        self._title.config(text=title[:70] or i18n.t('REFV_VIDEO', '영상'))
        self._sub.config(text='')
        self._set_mode(_MODE_VIDEO)
        self._link_load()
        if media_player is None or not media_player.embed_available():
            return
        if self._player is None:
            self._player = media_player.EmbeddedPlayer(self._video_f, min_w=480, min_h=270)
        self._player.play(video_id)

    def _entity_links(self, *, ref_unit_id=None, user_ref_id=None):
        """[(entity_id, 이름, 유형)] — 글에 걸린 용어."""
        out = []
        try:
            with appdb.connect(self.db_path) as conn:
                lang = self._view_lang()
                if ref_unit_id:
                    rows = conn.execute(
                        # ★ 2026-08-24 통합 표(`REFU_ENTI`)
                        "SELECT el.target_id FROM sys_link_asset el"
                        " WHERE el.link_type='REFU_ENTI' AND el.clicked_id=?"
                        "   AND COALESCE(el.record_status,'LIVE')='LIVE'",
                        (ref_unit_id,)).fetchall()
                elif user_ref_id:
                    import db_user_ref_schema as U
                    rows = [(t,) for k, t, _e in U.fetch_links(conn, user_ref_id)
                            if k == 'ENTITY']
                else:
                    return []
                for (eid,) in rows:
                    nm = conn.execute(
                        "SELECT contents FROM sys_text_asset WHERE clicked_id=?"
                        " AND text_type='ENTITY_NAME' AND lang_code=? LIMIT 1",
                        (eid, lang)).fetchone()
                    ty = conn.execute("SELECT entity_type FROM sys_entity_master"
                                      " WHERE entity_id=?", (eid,)).fetchone()
                    out.append((eid, nm[0] if nm else str(eid), ty[0] if ty else ''))
        except Exception as e:
            print(f'[RefDetailView _entity_links] {e}')
        return out

    # (구) _on_link_click — 연결 목록 Treeview 와 함께 폐기 (2026-08-19 사용자
    #   「클릭하는 기능이 필요하지도 않다. 추가/빼기만 작동하면 된다」).
    #   표시 = 본문 상단 약명 나열(_link_strip), 조작 = 왼쪽 하단 입력창.

    # ── 뒷정리 ────────────────────────────────────────────────────
    def _on_destroy(self, event):
        if event.widget is self and self._player is not None:
            try:
                self._player.stop()
            except Exception:
                pass
            self._player = None
