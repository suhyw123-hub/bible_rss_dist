# -*- coding: utf-8 -*-
"""하가 진단 — **왜 안 켜지는지 말한다**.

⚠⚠⚠ 이 파일이 있는 까닭: 첫 배포가 **아무 말 없이 안 켜졌다**(2026-09-17
  사용자 「아이콘도 하가실행 파일도 작동하지 않는다. **아무런 메시지도 없다**」).
  `pythonw.exe` 는 오류를 **어디에도 안 적는다** — 그것이 침묵의 정체였다.
  ⇒ 여기서는 걸음마다 찍고, 무엇이 없어서 막혔는지 **이름을 대고** 말한다.
"""
import os
import sys
import traceback

OUT = []


def say(s=''):
    print(s)
    OUT.append(s)


def step(name, fn):
    try:
        got = fn()
        say('  OK   %-34s %s' % (name, got if got is not None else ''))
        return True
    except BaseException as e:
        say('  FAIL %-34s %s: %s' % (name, type(e).__name__, e))
        for ln in traceback.format_exc().splitlines()[-4:]:
            say('        %s' % ln)
        return False


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    say('하가 진단')
    say('=' * 60)
    say('  이 파일   %s' % here)
    say('  파이썬    %s' % sys.executable)
    say('  판        %s' % sys.version.replace('\n', ' '))
    say('  윈도우    %s' % str(getattr(sys, 'getwindowsversion', lambda: '?')()))
    say('  코드페이지 %s / %s' % (sys.getdefaultencoding(),
                              sys.stdout.encoding))
    say('')
    say('① 파이썬이 혼자 서는가')
    step('sqlite3', lambda: __import__('sqlite3').sqlite_version)
    step('tkinter', lambda: __import__('tkinter').TkVersion)
    step('창을 실제로 연다', _tk_open)
    say('')
    say('② 바깥 꾸러미')
    for m in ('PIL', 'numpy', 'requests', 'sounddevice', 'soundfile'):
        step(m, (lambda mm: (lambda: __import__(mm) and 'ok'))(m))
    step('PyQt6 QtWidgets',
         lambda: __import__('PyQt6.QtWidgets', fromlist=['x']) and 'ok')
    step('PyQt6 QtWebEngine(유튜브 재생기)',
         lambda: __import__('PyQt6.QtWebEngineWidgets', fromlist=['x'])
         and 'ok')
    say('')
    say('③ 자료')
    app = os.path.join(here, 'app')
    for f in ('bible_master.db', 'user_data.db', 'user_main.py', 'appdb.py'):
        p = os.path.join(app, f)
        say('  %-4s %-20s %s' % ('OK' if os.path.exists(p) else 'FAIL', f,
                                 ('%.1f MB' % (os.path.getsize(p) / 1e6))
                                 if os.path.exists(p) else '없다'))
    say('')
    say('④ DB 를 실제로 연다')
    sys.path.insert(0, app)
    step('appdb.connect + 구절 수', _db)
    say('')
    say('⑤ 앱을 import 만 해 본다(창은 안 띄운다)')
    step('user_main import', _import_app)
    say('')
    say('=' * 60)
    say('이 글 전체를 그대로 보내 주십시오.')


def _tk_open():
    import tkinter as tk
    r = tk.Tk()
    r.withdraw()
    v = r.tk.call('info', 'patchlevel')
    r.destroy()
    return 'tcl %s' % v


def _db():
    import appdb
    c = appdb.connect()
    n = c.execute('SELECT COUNT(*) FROM bible_index').fetchone()[0]
    c.close()
    return '구절 %d' % n


def _import_app():
    os.chdir(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'app'))
    import user_main          # noqa: F401
    return 'ok'


if __name__ == '__main__':
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass
    try:
        main()
    except BaseException:
        OUT.append(traceback.format_exc())
        print(traceback.format_exc())
    try:
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         '진단결과.txt')
        with open(p, 'w', encoding='utf-8') as fh:
            fh.write('\n'.join(OUT))
        print('\n⇒ %s 에도 적었습니다.' % p)
    except Exception as e:
        print('진단결과.txt 를 못 적었습니다: %s' % e)
