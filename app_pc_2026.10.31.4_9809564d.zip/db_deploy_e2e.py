# -*- coding: utf-8 -*-
"""db_deploy_e2e.py — 배포 종단간 점검 (영구 · 2026-09-03 192차).

★ **관리자 전송 → 서버 → 트레이 수신 → 화면 표시**를 실제로 왕복시킨다.
  단위 selftest 는 각자의 자리만 재므로 **이어 붙였을 때 끊기는 곳**을 못 본다
  — 실제로 이 시험이 「트레이가 본체 연결을 안 넘겨 연결이 통째로 보류되고
  화면이 조용히 비는」 결함을 잡았다(단위 시험 전부 통과 상태에서).
  **배포 파이프를 고치면 이것을 돌린다.**

원래 물음: 관리자 전송 → 서버(로컬 시뮬) → 트레이 수신 → 화면 표시.

⚠ 실데이터·실 배포 폴더를 안 건드린다 — 임시 폴더로 갈아 끼우고 되돌린다.
"""
import io
import json
import os
import shutil
import sqlite3
import sys
import tempfile

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')
sys.path.insert(0, r'C:\Hagah\app')
os.chdir(r'C:\Hagah\app')

import appdb                                    # noqa: E402
import db_linkpack_build as LB                  # noqa: E402
import db_linkpack_sync as SYNC                 # noqa: E402
import link_pack                                # noqa: E402
import overlay_read as OR                       # noqa: E402
import tray_agent as TA                         # noqa: E402

OK = [0, 0]


def t(name, cond, extra=''):
    OK[0] += 1
    OK[1] += 1 if cond else 0
    print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))


tmp = tempfile.mkdtemp()
SRV = os.path.join(tmp, 'server')       # 정적 서버 시늉
os.makedirs(SRV, exist_ok=True)
keep_dist, LB.DIST = LB.DIST, os.path.join(tmp, 'dist')
# ⚠⚠⚠ **시험용 팩 이름으로 갈아 끼운다** (2026-09-03 — 실제로 당했다).
#   `had_pack` 는 **삭제만** 막았지 덮어쓰는 것은 못 막았다. 그래서 배포로
#   받은 실 팩(2,077 미디어) 위에 시험 델타가 얹혀 **시험 잔재만 남은 팩**이
#   됐고, 사용자 화면에 「팩 강해 1」 같은 가짜 줄이 떴다.
#   ⇒ 이름을 갈아 끼워 실 팩을 아예 안 만진다. 커서 검사도 그래야 참값이 된다.
_KEEP_PACK_NAME = link_pack.PACK_NAME
link_pack.PACK_NAME = 'link_pack_e2e.db'
# ⚠ 실 배포 폴더의 **시작 전 목록**을 적어 둔다 — 「파일이 있나」로 재면
#   1차 배포본이 이미 있는 한 영원히 FAIL 한다(데이터 상태 의존).
_dist_before = (sorted(os.listdir(keep_dist))
                if os.path.isdir(keep_dist) else [])
had_pack = os.path.exists(link_pack.pack_path())
had_mark = os.path.exists(TA.RUNNING_MARK)

conn = appdb.connect('bible_master.db')
EID = conn.execute("SELECT entity_id FROM sys_entity_master"
                   " WHERE entity_code='P_DAVID'").fetchone()[0]
base = len(OR.media(conn, EID, 'ALL', 'KO'))
print('기준 — 다윗 미디어 %d · 배포 폴더 %s' % (base, LB.DIST))

print('\n── ① 관리자: 전체본 만들기 ──')
r = LB.build(conn, full=True)
t('전체본 생성', bool(r['file']) and os.path.exists(r['file']))
full = json.load(open(r['file'], encoding='utf-8'))
# ⚠⚠ **데이터 상태를 전제하지 않는다**(§0-5) — 예전에는 「2,000~2,200」으로
#   못 박아 두었는데, 승인이 4,290 이 되자 **통째로 FAIL** 했다. 콘텐츠를
#   채우는 것이 본업인 저장소에서 개수를 박은 검사는 반드시 깨진다.
#   ⇒ **DB 의 승인 수와 팩의 수가 같은가**로 잰다 — 늘어도 안 깨지고,
#     미승인이 새면 그 자리에서 잡힌다.
_n_ap = conn.execute("SELECT COUNT(*) FROM sys_media_asset"
                     " WHERE is_active=1 AND record_status='LIVE'").fetchone()[0]
t('★ 승인분만 담긴다(DB 와 같은 수)', len(full['media']) == _n_ap,
  '팩 %d / DB %d' % (len(full['media']), _n_ap))
t('연결도 함께', len(full['links']) > 0, len(full['links']))
t('자연 열쇠로 실림',
  any('target_code' in l or 'target_peri' in l for l in full['links']))

print('\n── ② 서버에 올림(정적 파일) ──')
shutil.copy(r['file'], os.path.join(SRV, 'linkpack_full.json'))
t('서버에 전체본', os.path.exists(os.path.join(SRV, 'linkpack_full.json')))

print('\n── ③ 트레이: 본체가 떠 있으면 안 받는다 ──')
TA.mark_running()
srv = [{'location': SRV, 'enabled': True}]
res = TA.check_once()
t('본체 실행 중 = 건너뜀', res['skipped'] is True)
TA.clear_running()

print('\n── ④ 트레이: 델타 받기(커서 따라) ──')
# 서버에 델타 1을 둔다 — 관리자가 나중에 하나 더 보낸 상황
d1 = {'seq': 1, 'media': [
    {'media_id': 9990001, 'media_type': 'SERMON', 'format_type': 'VIDEO',
     'title': '[E2E] 새 강해', 'url': 'https://youtu.be/E2ETESTAAA',
     'lang_code': 'KO'}],
    'links': [{'link_type': 'MEDI_ENTI', 'clicked': 9990001,
               'target_code': 'P_DAVID'}]}
json.dump(d1, open(os.path.join(SRV, 'linkpack_00001.json'), 'w',
                   encoding='utf-8'), ensure_ascii=False)
got = TA.fetch_pack_deltas.__wrapped__ if hasattr(
    TA.fetch_pack_deltas, '__wrapped__') else None
# 서버 목록을 갈아 끼워 부른다
import rss_transport as RT                                   # noqa: E402
keep_srv, RT.client_servers = RT.client_servers, (lambda: srv)
try:
    n = TA.fetch_pack_deltas()
finally:
    RT.client_servers = keep_srv
t('델타 1개 받음', n == 1, n)
t('커서 전진', link_pack.cursor(link_pack.pack_path()) == 1)

print('\n── ⑤ 화면에 도착했는가 ──')
conn2 = appdb.connect('bible_master.db')
rows = OR.media(conn2, EID, 'ALL', 'KO')
hit = [x for x in rows if x['mid'] == 9990001]
t('새 링크가 화면에', len(hit) == 1, hit[0]['title'] if hit else '')
t('개수가 하나 늘었다', len(rows) == base + 1, '%d → %d' % (base, len(rows)))

print('\n── ⑥ 같은 델타를 또 받아도(멱등) ──')
keep_srv, RT.client_servers = RT.client_servers, (lambda: srv)
try:
    n2 = TA.fetch_pack_deltas()
finally:
    RT.client_servers = keep_srv
t('더 받을 것 없음', n2 == 0, n2)
t('행수 그대로', len(OR.media(conn2, EID, 'ALL', 'KO')) == base + 1)

print('\n── ⑦ 관리자가 링크를 내림(승인 해제) → 델타 → 수신 ──')
d2 = {'seq': 2, 'media': [{'media_id': 9990001, 'record_status': 'DELETED'}]}
json.dump(d2, open(os.path.join(SRV, 'linkpack_00002.json'), 'w',
                   encoding='utf-8'), ensure_ascii=False)
keep_srv, RT.client_servers = RT.client_servers, (lambda: srv)
try:
    n3 = TA.fetch_pack_deltas()
finally:
    RT.client_servers = keep_srv
t('묘비 델타 수신', n3 == 1, n3)
t('화면에서 사라짐', len(OR.media(conn2, EID, 'ALL', 'KO')) == base)

print('\n── ⑧ 서버가 죽어도(미러 없음) 앱은 멀쩡한가 ──')
keep_srv, RT.client_servers = RT.client_servers, (lambda: [
    {'location': os.path.join(tmp, '없는폴더'), 'enabled': True}])
try:
    n4 = TA.fetch_pack_deltas()
finally:
    RT.client_servers = keep_srv
t('서버 없어도 안 죽는다', n4 == 0)
t('화면도 그대로', len(OR.media(conn2, EID, 'ALL', 'KO')) == base)

print('\n── ⑨ 뒷정리 ──')
conn2.close()
link_pack.detach(conn)
conn.close()
import gc
for _ in range(5):
    gc.collect()
    try:
        if os.path.exists(link_pack.pack_path()) and not had_pack:
            os.remove(link_pack.pack_path())
        break
    except Exception:
        pass
t('시험 팩 삭제', had_pack or not os.path.exists(link_pack.pack_path()))
t('실행 표식 원복', had_mark or not os.path.exists(TA.RUNNING_MARK))
LB.DIST = keep_dist
_dist_after = (sorted(os.listdir(keep_dist))
               if os.path.isdir(keep_dist) else [])
t('배포 폴더 원복(실 폴더 안 건드림)', _dist_after == _dist_before,
  '%d → %d개' % (len(_dist_before), len(_dist_after)))
shutil.rmtree(tmp, ignore_errors=True)
_e2e_path = link_pack.pack_path()
link_pack.PACK_NAME = _KEEP_PACK_NAME
t('★ 실 팩 이름 원복', link_pack.PACK_NAME == 'link_pack.db')
t('★ 실 팩을 안 건드렸다', not os.path.exists(_e2e_path))
conn3 = appdb.connect('bible_master.db')
t('팩 없는 상태 = 기준 복귀',
  len(OR.media(conn3, EID, 'ALL', 'KO')) == base)
conn3.close()
print('\n종단간 점검 %d/%d' % (OK[1], OK[0]))
