# -*- coding: utf-8 -*-
"""db_meyer_import.py — 마이어 『Our Daily Homily』 **다섯 권 전권** 적재
================================================================================
`python db_meyer_import.py --selftest`   — 의무
`python db_meyer_import.py --links`      — **받기 전에** 주소를 보인다 (규칙 ⓪)
`python db_meyer_import.py --fetch --links-confirmed`
`python db_meyer_import.py --check`      — 파싱 결과만 (DB 안 건드림)
`python db_meyer_import.py --plan`       — **권별 편 수 구성표** (적재 전 검토용)
`python db_meyer_import.py --apply`      — 적재 (멱등 · `unit_id` 보존)

━━ 정답을 원문에서 찾았다 (2026-08-22 재작성) ━━━━━━━━━━━━━━━━━━━━━━━━━━━
★★★ **이 책은 성경 한 장에 한 편, 한 쪽에 한 편이다.**

  | 권 | 범위 | 성경 장 | 스캔 마지막 쪽 |
  |---|---|---|---|
  | 1 | 창세기~룻기       | 236 | 236 |
  | 2 | 사무엘상~욥기     | 242 | 242 |
  | 3 | 시편~아가         | 201 | 201 |
  | 4 | 이사야~말라기     | 250 | 250 |
  | 5 | 마태~계시록       | 260 | 260 |
  | | | **1,189** | **= 성경 전체 장 수** |

  다섯 권이 전부 맞는다. 그리고 쪽 번호는 **그 쪽 끝**에 찍히고 **바로 다음
  줄이 다음 편의 제목**이다(실측 — `231 | We have sworn by the Lord.` =
  삿 21:7 = 232번째 장). ⇒ **쪽 번호가 곧 편 경계이고 편 번호다.**

⚠⚠ **2026-08-22 첫 적재는 이것을 몰라 301편으로 잘못 나뉘었다.**
  약 890편이 앞 편에 삼켜졌고(가장 큰 편이 114,063자 = 평균의 20배)
  창세기·출애굽기·사사기·사무엘상·다니엘·호세아~말라기가 통째로 빠졌다.
  ★★★ **그런데 원문 문장 대조는 94% 로 통과했다** — 뭉친 덩어리도 글자는
  전부 저자의 것이라 대조가 만점이 나온다. **문장 대조는 「진본인가」만 재지
  「제대로 나뉘었는가」는 못 잰다.** 그래서 이 파일의 `check()` 는
  **편 수·길이 분포·장 순서**를 함께 잰다.

━━ 편 경계를 찾는 세 겹 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ① **쪽 번호**(뼈대, 92.5%) — 홑줄 숫자. OCR 이 `235`→`335`·`236`→`836`
     으로 읽으므로 **세 자리에서만** 한 자리 어긋남을 봐준다.
     ⚠ 한 자리 수에까지 관용을 주면 `2` 를 `1` 로 받아들여 뼈대가 통째로
       무너진다(실측: 그렇게 했다가 v1 이 4쪽에서 멈췄다).
  ② **제목블록**(빈 곳 메우기) — 짧은 문단이 참조로 끝나고 **다음 문단이
     대문자로 시작**한다(본문 첫 낱말은 늘 대문자다: `HOW`·`THIS`·`BOAZ`).
  ③ **성경 장 순서**(검산) — i번째 편은 i번째 장이어야 한다.

⚠ **판이 두 가지이고 한 권 안에 섞여 있다** (실측):
     ㉠ `제목… Genesis i. 5.` / 빈 줄 / 본문      ← 참조가 제목 끝에
     ㉡ `제목` / 빈 줄 / `Matt. i. 21 (R. v.).` / 빈 줄 / 본문
  줄머리 고정 규칙만 쓰면 ㉠ 을 통째로 놓친다(첫 적재의 원인 하나).
⚠ **책 이름 OCR 을 믿지 말 것** — `Isa.` 가 `ha.`·`Jsa.` 로 찍혀 유사도로는
  Habakkuk 에 붙는다(실측). 책·장은 **성경 순서에서 배정**하고 OCR 은
  검산에만 쓴다.
⚠ 스캔 끝에 **출판사 광고와 도서관 장서표**가 붙어 온다.
"""
import io
import os
import re
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.stdout.reconfigure(encoding='utf-8', errors='replace')
import appdb
import db_book_source_match as SM

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, '_meyer_raw')
DB = 'bible_master.db'
BOOK_CODE = 'MEYER_ODH'
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/125.0 Safari/537.36')
ATTRIB = '— F.B. Meyer, "Our Daily Homily" (1898). Public domain.'

# ── 권별 성경 장 (정경 순서) — 이것이 정답이다 ──────────────────────────
#    (책 이름, bcode, 장 수)
VOLS = [
    (1, '창세기~룻기', 'ourdailyhomily01meye', [
        ('Genesis', 1, 50), ('Exodus', 2, 40), ('Leviticus', 3, 27),
        ('Numbers', 4, 36), ('Deuteronomy', 5, 34), ('Joshua', 6, 24),
        ('Judges', 7, 21), ('Ruth', 8, 4)]),
    (2, '사무엘상~욥기', 'ourdailyhomily02meye', [
        ('1 Samuel', 9, 31), ('2 Samuel', 10, 24), ('1 Kings', 11, 22),
        ('2 Kings', 12, 25), ('1 Chronicles', 13, 29),
        ('2 Chronicles', 14, 36), ('Ezra', 15, 10), ('Nehemiah', 16, 13),
        ('Esther', 17, 10), ('Job', 18, 42)]),
    (3, '시편~아가', 'ourdailyhomily03meye', [
        ('Psalms', 19, 150), ('Proverbs', 20, 31),
        # ⚠ 책 이름은 **DB(`book_names` EN)의 정식 이름과 같아야** 한다 —
        #   `key_verse_ref` 를 화면이 그 이름으로 되짚어 한국어로 옮긴다.
        #   `Song of Solomon` 이라 적었더니 아가 8편만 영어로 남았다(실측).
        ('Ecclesiastes', 21, 12), ('Song of Songs', 22, 8)]),
    (4, '이사야~말라기', 'ourdailyhomily04meye', [
        ('Isaiah', 23, 66), ('Jeremiah', 24, 52), ('Lamentations', 25, 5),
        ('Ezekiel', 26, 48), ('Daniel', 27, 12), ('Hosea', 28, 14),
        ('Joel', 29, 3), ('Amos', 30, 9), ('Obadiah', 31, 1),
        ('Jonah', 32, 4), ('Micah', 33, 7), ('Nahum', 34, 3),
        ('Habakkuk', 35, 3), ('Zephaniah', 36, 3), ('Haggai', 37, 2),
        ('Zechariah', 38, 14), ('Malachi', 39, 4)]),
    (5, '마태~계시록', 'ourdailyhomily05meye', [
        ('Matthew', 40, 28), ('Mark', 41, 16), ('Luke', 42, 24),
        ('John', 43, 21), ('Acts', 44, 28), ('Romans', 45, 16),
        ('1 Corinthians', 46, 16), ('2 Corinthians', 47, 13),
        ('Galatians', 48, 6), ('Ephesians', 49, 6), ('Philippians', 50, 4),
        ('Colossians', 51, 4), ('1 Thessalonians', 52, 5),
        ('2 Thessalonians', 53, 3), ('1 Timothy', 54, 6),
        ('2 Timothy', 55, 4), ('Titus', 56, 3), ('Philemon', 57, 1),
        ('Hebrews', 58, 13), ('James', 59, 5), ('1 Peter', 60, 5),
        ('2 Peter', 61, 3), ('1 John', 62, 5), ('2 John', 63, 1),
        ('3 John', 64, 1), ('Jude', 65, 1), ('Revelation', 66, 22)]),
]


def chapters_of(vol):
    """그 권이 덮는 (책 이름, bcode, 장) 목록 — 정경 순서."""
    for v, _, _, books in VOLS:
        if v == vol:
            return [(nm, bc, ch) for nm, bc, n in books
                    for ch in range(1, n + 1)]
    return []


# ── 낱낱의 규칙 ────────────────────────────────────────────────────────
# ⚠ 쪽 번호 줄에 부스러기가 붙는다 — `.  152` (실측 잠언 2장 끝).
#   그대로 두면 그 쪽을 통째로 놓쳐 두 편이 한 편으로 붙는다.
_NUMLINE = re.compile(r'^[\s.,\-—\'"*]*([\dOolIiSsB]{1,3})[\s.,\-—\'"*]*$')
_DIGIT = str.maketrans({'O': '0', 'o': '0', 'l': '1', 'I': '1', 'i': '1',
                        'S': '5', 's': '5', 'B': '8'})
# 본문 첫 낱말은 늘 대문자다 (`HOW`·`THIS`·`BOAZ`).
# ⚠ **한 글자 관사로 시작하는 것도 있다** — `A  COVENANT is a promise…` ·
#   `A  SAFE carriage was that!`. `[A-Z]{2,}` 만 보면 이것들을 놓쳐
#   **본문이 통째로 제목이 된다**(실측: 창세기 9장·신명기 1장).
_CAPS = re.compile(r"^[\s\"'‘“*\(\)\[\]{}<>|/\\.,;:!\-—]*"
                   r"(?:[A-Z]\s+)?[A-Z]{2,}")
# ⚠⚠ **줄머리로 못 박고 대소문자를 가린다.** `re.I` + 위치 자유로 두었더니
#   본문 산문의 「…contains a list of the stations…」에 걸려 에스겔 38장을
#   광고로 오판했다(§0-1b 「Produced by」 오탐과 같은 계열 — 지우거나 자르는
#   규칙에는 **오탐 검사를 selftest 에 반드시 넣는다**).
_CATALOG = re.compile(
    r'^[ \t]*(?:A\s+List\s+of|PUBLISHED\s+BY\s+Fleming|'
    r'By\s+the\s+Same\s+Author|Princeton\s+Theological\s+Seminary)', re.M)
_HEAD = re.compile(r'^(OUR\s+DAILY\s+HOMILY|PREFACE)\.?$', re.I)
# 책 이름 표기 — 약자·전체·흔한 OCR 손상까지 (검산·제목 다듬기용)
_BOOKWORD = (
    r'Gen(?:esis)?|Exod?(?:us)?|Lev(?:iticus)?|Num(?:bers)?|De[un]t?(?:eronomy)?'
    r'|Josh?(?:ua)?|Judg(?:es)?|Ruth|Sam(?:uel)?|Kin(?:gs)?|Chr(?:on)?'
    # ⚠ `Psa.` 가 `Fsa,` 로 찍힌다 — OCR 이 P 를 F 로 읽는다(실측 시편 119편)
    r'(?:icles)?|Ezra|Ne[hk](?:emiah)?|Esth?(?:er)?|Job|[PF]sa?(?:lms?)?'
    r'|Prov?(?:erbs)?|Eccl?(?:es)?(?:iastes)?|Cant(?:icles)?|Song'
    r'|[IJTh]sa(?:iah)?|Jer(?:emiah)?|Lam(?:entations)?|Ezek?(?:iel)?'
    r'|Dan(?:iel)?|Hos(?:ea)?|Joel|Amos|Obad(?:iah)?|Jon(?:ah)?|Mic(?:ah)?'
    r'|Nah(?:um|utn)?|Hab(?:akkuk)?|Zeph?(?:aniah)?|Hag(?:gai)?'
    # ⚠ `John` 이 `yohn` 으로 찍힌다 — OCR 이 J 를 y 로 읽는다(실측 요 14장)
    r'|Zech?(?:ariah)?|Ma[il](?:achi)?|Matt?(?:hew)?|Mark|Luke|[JjYy][on]h?n'
    r'|Jno|Acts|Rom(?:ans)?|Cor(?:inthians)?|Gal(?:atians)?|Eph(?:esians)?'
    r'|Phil(?:ippians)?|Col(?:ossians)?|Thess?(?:alonians)?|Tim(?:othy)?'
    r'|Tit(?:us)?|Philem(?:on)?|Heb(?:rews)?|Jas|James|Pet(?:er)?|Jude'
    r'|Rev(?:elation)?')
# ⚠ 장 번호도 OCR 이 흔든다 — `iii`→`in`·`Hi` · `ii`→`U` · `viii`→`via`
#   (실측 `Num. U. 2-34` · `Titus Hi. 4.` · `Neh. via. lo.`).
#   앞에 책 이름이 오고 뒤에 마침표가 오는 자리라 넓혀도 오탐이 적다.
_NUMTOK = r'[0-9A-Za-z!\|]{1,8}'
# ⚠ **절 번호는 OCR 이 가장 심하게 망가뜨린다** — `Genesis ii. /j*.` ·
#   `Genesis iv. g.` · `Psa. xlix. jr.` · `Deut. i. SI.`
#   글자가 뭐로 바뀔지 알 수 없으므로 **절 자리는 열어 두고 길이로만 묶는다**.
#   앞에 `책 이름 + 장 + 마침표` 가 오고 뒤가 문단 끝이라 오탐이 거의 없다.
_VERSETOK = r'[0-9A-Za-z/^*&,\.\s\-]{1,14}'
# 문단 **끝**의 참조 — 제목에서 떼어 내고, 제목블록임을 알리는 표지
_REF_TAIL = re.compile(
    # ⚠ 앞쪽에서 마침표를 먹지 말 것 — 제목이 줄임표로 끝나면(`My . . .`)
    #   그것까지 참조로 삼켜 제목이 두 글자가 된다(실측 시 144).
    r'[\s,;:]*(?:[123IJ]\s*\.?\s*)?(?:' + _BOOKWORD + r')\s*\.?\s+' +
    _NUMTOK + r'\s*[.,]\s*(?:' + _VERSETOK + r')?'
    r'(?:\s*\([^)]{0,18}\))?\s*[.,]?\s*$')
_ROMAN = {'i': 1, 'v': 5, 'x': 10, 'l': 50, 'c': 100, 'd': 500, 'm': 1000}
# ⚠ 실제로 본 손상만 넣는다 — 짐작으로 넣으면 틀린 장 번호가 나와
#   정렬 점수를 깎는다(못 읽는 편이 차라리 낫다).
_RFIX = str.maketrans({'j': 'i', 'J': 'i', '1': 'i', '!': 'i', '|': 'i',
                       't': 'i', 'I': 'i', 'V': 'v', 'X': 'x', 'L': 'l',
                       'C': 'c', 'D': 'd', 'M': 'm',
                       'H': 'ii', 'U': 'ii', 'u': 'ii'})


def _to_int(tok):
    """로마숫자/아라비아 — OCR 손상 허용. 못 읽으면 None."""
    tok = tok.strip()
    if tok.isdigit():
        return int(tok)
    t = tok.translate(_RFIX).lower()
    if not t or any(c not in _ROMAN for c in t):
        return None
    tot = 0
    for i, c in enumerate(t):
        v = _ROMAN[c]
        tot += -v if i + 1 < len(t) and _ROMAN[t[i + 1]] > v else v
    return tot if 0 < tot <= 200 else None


def _flat(s):
    return ' '.join(s.split())


def body_span(raw):
    """앞부속(장서표·판권장·서문)과 뒤부속(출판사 광고)을 잘라 낸다."""
    m = None
    for m2 in re.finditer(r'OUR\s+DAILY\s+HOMILY\s*\n', raw):
        m = m2
        if m2.start() > len(raw) * 0.005:
            break
    i0 = m.end() if m else 0
    i1 = len(raw)
    for mm in _CATALOG.finditer(raw):
        if mm.start() > len(raw) * 0.80:
            i1 = min(i1, mm.start())
            break
    return i0, i1


def _page_close(val, exp):
    """쪽 번호 비교 — OCR 이 **앞자리**를 잘못 읽은 것만 봐준다(335=235·836=236).

    ⚠⚠ 「세 자리면 한 자리 어긋남 허용」은 **너무 넓다** — 이웃 쪽 번호
      118↔119 가 바로 한 자리 차이라, 같은 번호가 두 번 찍히면 그것을
      다음 쪽으로 받아들여 **뼈대가 통째로 한 칸씩 밀린다**(실측: 시편
      119·139·159·179·199 가 20쪽 간격으로 줄줄이 빠졌다).
    ⚠ 한 자리 수에까지 관용을 주면 `2` 를 `1` 로 받아 처음부터 무너진다.
    ⇒ **뒷자리는 정확히 맞아야 하고, 앞자리만 다를 수 있다.**
    """
    if val == exp:
        return True
    a, b = str(val), str(exp)
    if len(a) != len(b) or len(a) < 3:
        return False
    return a[1:] == b[1:] and a[0] != b[0]


def _page_marks(s, n_pages):
    """쪽 번호 → {쪽: 그 줄 다음 위치}. 쪽 p 다음이 p+1 편의 시작이다."""
    cands, off = [], 0
    for ln in s.split('\n'):
        m = _NUMLINE.match(ln)
        if m:
            t = m.group(1).translate(_DIGIT)
            if t.isdigit():
                cands.append((off + len(ln) + 1, int(t)))
        off += len(ln) + 1
    close = _page_close
    got, exp = {}, 1
    for pos, val in cands:
        if exp > n_pages - 1:
            break
        for step in range(0, 9):          # OCR 이 몇 쪽을 놓쳐도 따라간다
            if close(val, exp + step):
                got[exp + step] = pos
                exp += step + 1
                break
    return got


def _title_marks(s, loose=False):
    """제목블록이 시작하는 위치들 — 판 ㉠㉡ 둘 다.

    `loose=False` = 참조로 끝나는 짧은 문단만 (정밀).
    `loose=True`  = 참조를 요구하지 않는다 (빈 곳 메우기용).
      ⚠ 느슨해도 오탐이 거의 없다 — 본문 문단은 **대문자로 시작하지 않기**
        때문이다(첫 낱말 대문자는 편의 첫 문단뿐). 실측: 느슨한 신호가
        권마다 N 을 한 번도 넘지 않았다(229/236 · 250/260 …).
    """
    paras, pos = [], 0
    for p in re.split(r'(\n\s*\n)', s):
        if p.strip() and not p.startswith('\n'):
            paras.append((pos, _flat(p)))
        pos += len(p)
    out = []
    for k, (st, p) in enumerate(paras):
        if k + 1 >= len(paras) or len(p) > 230:
            continue
        if _NUMLINE.match(p) or _HEAD.match(p):
            continue
        if not loose and not _REF_TAIL.search(p):
            continue
        nxt = paras[k + 1][1]
        j = k + 1
        while j < len(paras) and (_NUMLINE.match(nxt) or _HEAD.match(nxt)):
            j += 1
            if j < len(paras):
                nxt = paras[j][1]
        if not _CAPS.match(nxt):
            continue
        start = st
        # 판 ㉡ — 참조만 있는 짧은 문단이면 제목은 그 앞 문단이다
        if len(p) < 44 and k > 0:
            prev = paras[k - 1][1]
            if not _NUMLINE.match(prev) and not _HEAD.match(prev) \
                    and len(prev) < 210:
                start = paras[k - 1][0]
        out.append(start)
    return sorted(set(out))


# 이보다 가까우면 «같은 경계의 두 신호» 로 본다.
# ⚠ 실측으로 정했다 — 쪽 번호와 바로 뒤 제목 사이는 **중앙값 2자 · 90%가 2자**
#   이고 가장 먼 것이 63자다. 편과 편 사이는 1,600자쯤이라 80은 안전하다.
#   넓게(320) 잡으면 짧은 편 둘이 한 덩이로 묶인다.
_GAP = 80


def _clusters(pages, titles, strict):
    """쪽 번호와 제목은 **같은 경계의 두 신호**다 — 먼저 하나로 묶는다.

    ⚠ 따로 다루면 같은 편을 두 번 세어 0자 조각이 생긴다(실측: 쪽 `91` 이
      레위기 2장의 시작을 잡았는데 바로 두 칸 뒤의 그 편 제목을 다음 편으로
      또 세었다). 묶은 뒤에는 **제목 위치**를 대표로 쓴다 — 쪽 번호 다음
      빈 줄보다 제목 첫 글자가 참된 시작이다.
    """
    marks = [(pos, 'page', p) for p, pos in pages.items()]
    marks += [(t, 'title', None) for t in titles]
    marks.sort()
    out = []
    for pos, kind, p in marks:
        if out and pos - out[-1]['lo'] < _GAP:
            c = out[-1]
            if kind == 'title' and c['title'] is None:
                c['title'] = pos
            if kind == 'page' and c['page'] is None:
                c['page'] = p
        else:
            out.append({'lo': pos,
                        'page': p if kind == 'page' else None,
                        'title': pos if kind == 'title' else None})
    for c in out:
        c['pos'] = c['title'] if c['title'] is not None else c['lo']
        c['strict'] = any(abs(c['pos'] - t) < _GAP for t in strict)
    return out


_CHAP_IN_TITLE = re.compile(
    r'(?:' + _BOOKWORD + r')\s*\.?\s+(' + _NUMTOK + r')\s*[.,]')


def _cluster_chapter(s, c, nxt):
    """덩이의 **제목에서만** 장 번호를 읽는다.

    ⚠ 본문에는 인용 참조가 흔하다(`(Eph. v. 2)`). 조각 머리 340자를 통째로
      보면 **본문 인용이 제목의 장 번호를 덮어써** 정렬이 한 칸 밀린다
      (실측: 시편 119편 자리에 120편이 들어갔다).
    """
    title, _ = split_entry(s[c['pos']:min(nxt, c['pos'] + 900)])
    best = None
    for m in _CHAP_IN_TITLE.finditer(title):
        v = _to_int(m.group(1))
        if v and 1 <= v <= 150:
            best = v
    return best


def boundaries(s, n, chaps=None):
    """편 n개의 시작 위치 {편번호: 위치}. 못 채우면 (…, 못 채운 편 번호).

    ① 쪽 번호와 제목을 **한 덩이로 묶는다**(같은 경계의 두 신호).
    ② 덩이마다 두 가지 증거를 읽는다 — 쪽 번호(p → 편 p+1)와
       제목 속 **장 번호**.
    ③ 덩이 열과 기대 편 열을 **정렬**한다(Needleman-Wunsch). 두 증거가
       서로를 검산하므로 한쪽이 틀려도 다른 쪽이 잡는다.
       ⚠ 쪽 번호만 쓰면 어긋난 자리를 바로잡지 못한다(실측: 민수기 구간이
         한 칸 밀린 채 개수만 맞았다).
    """
    pages = {p: pos for p, pos in _page_marks(s, n).items() if 1 < p + 1 <= n}
    strict = _title_marks(s, loose=False)
    cl = _clusters(pages, _title_marks(s, loose=True), strict)
    if not cl:
        return {1: 0}, list(range(2, n + 1))
    for k, c in enumerate(cl):
        nxt = cl[k + 1]['pos'] if k + 1 < len(cl) else len(s)
        c['chap'] = _cluster_chapter(s, c, nxt)

    want_ch = [c for _, _, c in (chaps or [])] or [None] * n
    m = len(cl)

    def score(k, i):
        """덩이 k 를 편 i(1-based) 에 놓는 점수."""
        sc = 1.0                            # 놓는 것 자체를 조금 선호
        c = cl[k]
        if c['page'] is not None:
            sc += 4.0 if c['page'] + 1 == i else -4.0
        if c['chap'] is not None and i - 1 < len(want_ch) \
                and want_ch[i - 1] is not None:
            sc += 4.0 if c['chap'] == want_ch[i - 1] else -3.0
        if c['strict']:
            sc += 0.5
        return sc

    GAP = -2.0
    dp = [[0.0] * (n + 1) for _ in range(m + 1)]
    bt = [[0] * (n + 1) for _ in range(m + 1)]
    for k in range(1, m + 1):
        dp[k][0] = dp[k - 1][0] + GAP
        bt[k][0] = 1
    for i in range(1, n + 1):
        dp[0][i] = dp[0][i - 1] + GAP
        bt[0][i] = 2
    for k in range(1, m + 1):
        row, prev = dp[k], dp[k - 1]
        brow = bt[k]
        for i in range(1, n + 1):
            a = prev[i - 1] + score(k - 1, i)
            b2 = prev[i] + GAP              # 덩이를 버린다 (군더더기)
            c2 = row[i - 1] + GAP           # 편을 비운다 (못 찾음)
            if a >= b2 and a >= c2:
                row[i], brow[i] = a, 0
            elif b2 >= c2:
                row[i], brow[i] = b2, 1
            else:
                row[i], brow[i] = c2, 2
    b, k, i = {}, m, n
    while k > 0 or i > 0:
        d = bt[k][i]
        if d == 0 and k > 0 and i > 0:
            b[i] = cl[k - 1]['pos']
            k, i = k - 1, i - 1
        elif d == 1 and k > 0:
            k -= 1
        else:
            i -= 1
    b.setdefault(1, 0)                    # 1편의 제목을 못 잡았으면 본문 머리
    return b, sorted(i for i in range(1, n + 1) if i not in b)


def _break_glued(seg):
    """⚠ **판 ㉢** — 참조 줄과 본문 사이에 빈 줄이 없는 자리가 있다:
           `Genesis  iv.  g.`
           `THE  first  question  God  puts …`      ← 바로 다음 줄
       이대로 두면 문단 하나로 읽혀 **본문이 통째로 제목이 된다**(실측:
       창세기 4장 제목이 1,034자였다). 참조로 끝나는 줄 다음 줄이 대문자로
       시작하면 그 사이에 빈 줄을 넣는다."""
    lines = seg.split('\n')
    out = []
    for i, ln in enumerate(lines):
        out.append(ln)
        if i + 1 >= len(lines):
            continue
        nxt = lines[i + 1].strip()
        if not nxt or not _CAPS.match(nxt):
            continue
        if _REF_TAIL.search(_flat(ln)) and len(_flat(ln)) < 120:
            out.append('')
    return '\n'.join(out)


def split_entry(seg):
    """조각 → (제목, 본문).

    ★ **제목은 참조에서 끝난다** — 이것이 가장 확실한 규칙이다.
    ⚠ 「본문은 대문자로 시작한다」만 믿으면 안 된다. **대문자 첫 낱말이
      없는 편이 있다**(실측: 삼하 15장 `There is the patience of hope.` ·
      대하 11장 `All the tribes were represented`). 그러면 본문이 통째로
      제목이 된다. 대문자는 참조를 못 찾았을 때의 **보조** 규칙으로만 쓴다.
    """
    seg = _break_glued(seg)
    parts = [p for p in re.split(r'\n\s*\n', seg) if p.strip()]
    parts = [p for p in parts
             if not _NUMLINE.match(_flat(p)) and not _HEAD.match(_flat(p))]
    if not parts:
        return '', []
    ti, bi = [], None
    for i, p in enumerate(parts[:3]):
        f = _flat(p)
        ti.append(f)
        if _REF_TAIL.search(f):
            bi = i + 1
            break
    if bi is None:                        # 참조를 못 읽었다 — 대문자로 가른다
        ti = []
        for i, p in enumerate(parts):
            f = _flat(p)
            if _CAPS.match(f) and ti:
                bi = i
                break
            ti.append(f)
            if len(ti) >= 2:              # ⚠ 3 이면 본문 두 문단을 삼킨다
                bi = len(ti)
                break
        if bi is None:
            ti, bi = [_flat(parts[0])], 1
    return ' '.join(ti), parts[bi:]


def clean_title(t):
    """제목 끝의 참조를 떼어 내고 다듬는다. → (제목, 참조 문자열)"""
    t = _flat(t)
    m = _REF_TAIL.search(t)
    ref = ''
    if m:
        ref = _flat(m.group(0)).strip(' ,;:.-—')
        t = t[:m.start()]
    keep = _flat(t)
    t = keep.strip(' ,;:*\'"’”—-')
    # ⚠ 줄임표로 끝나는 제목이 있다 — `My . . .`(시 144). 다듬다가 통째로
    #   깎이면 제목이 두 글자가 된다. 너무 짧아지면 되돌린다.
    if len(t) < 5 <= len(keep):
        t = keep.strip(' ,;:*\'"’”—')
    return t, ref


def _join_body(paras):
    """줄 끝 하이픈 이음 · 쪽번호 제거 · 문단 유지."""
    out = []
    for p in paras:
        lines = [l.strip() for l in p.split('\n') if l.strip()]
        lines = [l for l in lines
                 if not _NUMLINE.match(l) and not _HEAD.match(l)]
        buf = ''
        for l in lines:
            if buf.endswith('-'):
                buf = buf[:-1] + l.lstrip()
            elif buf:
                buf += ' ' + l
            else:
                buf = l
        buf = re.sub(r'  +', ' ', buf).strip()
        if buf:
            out.append(buf)
    return out


def parse_vol(vol):
    """→ [(장인덱스, 책, bcode, 장, 제목, 참조, 본문문단들)], 못 채운 쪽"""
    p = os.path.join(RAW, 'v%d.txt' % vol)
    if not os.path.exists(p):
        return [], ['원문 파일이 없다: %s' % p]
    raw = io.open(p, encoding='utf-8', errors='replace').read()
    i0, i1 = body_span(raw)
    # ★ **판 ㉢ 을 먼저 편다** — 참조 줄과 본문이 붙은 자리를 빈 줄로 가른다.
    #   경계 찾기 전에 해야 한다: 붙어 있으면 그 문단이 230자를 넘어 제목
    #   후보에서 걸러지고, 두 편이 한 편으로 붙는다(실측 눅 19~20 · 딛 2~3).
    s = _break_glued(raw[i0:i1])
    chs = chapters_of(vol)
    n = len(chs)
    b, unresolved = boundaries(s, n, chs)
    keys = sorted(b)
    out = []
    for k, idx in enumerate(keys):
        st = b[idx]
        en = b[keys[k + 1]] if k + 1 < len(keys) else len(s)
        title, paras = split_entry(s[st:en])
        title, ref = clean_title(title)
        nm, bc, ch = chs[idx - 1]
        out.append((idx, nm, bc, ch, title, ref, _join_body(paras)))
    return out, unresolved


def parse_all():
    got, probs = [], []
    for vol, rng, ident, _ in VOLS:
        items, un = parse_vol(vol)
        for it in items:
            got.append((vol,) + it)
        for u in un:
            probs.append('제%d권 %d번째 편의 경계를 못 찾았다' % (vol, u))
    return got, probs


# ── 받기 ───────────────────────────────────────────────────────────────
def links():
    return [('제%d권 %s' % (v, r), 'https://archive.org/details/%s' % i)
            for v, r, i, _ in VOLS]


def fetch():
    SM.require_ack(BOOK_CODE, links(),
                   note='1898년판 · 대출 제한 없음 · 한 장에 한 편, 한 쪽에 한 편')
    if not os.path.isdir(RAW):
        os.makedirs(RAW)
    for vol, rng, ident, _ in VOLS:
        p = os.path.join(RAW, 'v%d.txt' % vol)
        u = 'https://archive.org/download/%s/%s_djvu.txt' % (ident, ident)
        for _ in (1, 2):
            subprocess.run(['curl', '-sL', '--max-time', '300', '-A', UA,
                            '-o', p, u], capture_output=True)
            if os.path.exists(p) and os.path.getsize(p) > 20000:
                break
            time.sleep(5)
        sz = os.path.getsize(p) if os.path.exists(p) else 0
        print('  %-4s 제%d권 %-14s %10s  %s'
              % ('O' if sz > 20000 else 'x', vol, rng, format(sz, ','), u))


# ── 게이트 ─────────────────────────────────────────────────────────────
def check(items, probs):
    """★ 문장 대조가 못 잡는 것을 잰다 — 편 수 · 길이 분포 · 장 순서."""
    bad = list(probs)
    want = {v: len(chapters_of(v)) for v, _, _, _ in VOLS}
    by = {}
    for it in items:
        by[it[0]] = by.get(it[0], 0) + 1
    for v in sorted(want):
        if by.get(v, 0) != want[v]:
            bad.append('제%d권 %d편 — %d편이어야 한다 (성경 장 수)'
                       % (v, by.get(v, 0), want[v]))
    if not items:
        return bad, by

    lens = sorted(len(' '.join(it[7])) for it in items)
    med = lens[len(lens) // 2]
    for it in items:
        vol, idx, nm, bc, ch, title, ref, paras = it
        n = len(' '.join(paras))
        # ★ 뭉친 편 잡기 — 첫 적재가 놓친 바로 그것
        if n > med * 3:
            bad.append('%s %d장 편이 %d자 — 중앙값 %d 의 3배를 넘는다 (뭉침?)'
                       % (nm, ch, n, med))
        if n < 400:
            bad.append('%s %d장 편이 %d자뿐' % (nm, ch, n))
        if not title or len(title) < 5:
            bad.append('%s %d장 제목이 비었다: %r' % (nm, ch, title))
        if len(title) > 200:
            bad.append('%s %d장 제목이 %d자 — 본문이 섞였다' % (nm, ch, len(title)))
        for para in paras:
            if _NUMLINE.match(para):
                bad.append('%s %d장 본문에 쪽번호가 남았다' % (nm, ch))
                break
            # ⚠ 꼬리만 본다 — `$` 앵커 정규식을 긴 문단 전체에 걸면
            #   시작 위치마다 훑어 O(n²) 가 된다(실측: 9만 자에서 몇 분).
            if re.search(r'[A-Za-z]{3,}-$', para.rstrip()[-48:]):
                bad.append('%s %d장 문단이 하이픈으로 끝난다 (낱말 잘림)'
                           % (nm, ch))
                break
        if _CATALOG.search(' '.join(paras)):
            bad.append('%s %d장 에 출판사 광고' % (nm, ch))
    # 장 순서 검산 — OCR 이 읽히는 편에서 배정한 장과 맞는가
    agree = seen = 0
    for it in items:
        m = re.search(r'(?:' + _BOOKWORD + r')\s*\.?\s+(' + _NUMTOK + r')\s*[.,]',
                      it[6])
        if not m:
            continue
        v = _to_int(m.group(1))
        if v is None:
            continue
        seen += 1
        if v == it[4]:
            agree += 1
    if seen >= 50 and agree < seen * 0.60:
        bad.append('장 순서 검산 %d/%d (%.0f%%) — 경계가 밀렸다'
                   % (agree, seen, 100.0 * agree / seen))
    return bad, by


def plan(items):
    """적재 전 검토용 구성표."""
    by = {}
    for it in items:
        by.setdefault(it[0], []).append(it)
    print('\n  권  범위             편수  기대   평균자   가장 짧은 편 / 가장 긴 편')
    print('  ' + '─' * 74)
    for vol, rng, _, _ in VOLS:
        got = by.get(vol, [])
        want = len(chapters_of(vol))
        if not got:
            print('  %2d  %-16s %4d  %4d   (없음)' % (vol, rng, 0, want))
            continue
        ls = [len(' '.join(x[7])) for x in got]
        print('  %2d  %-16s %4d  %4d  %7d   %d / %d'
              % (vol, rng, len(got), want, sum(ls) // len(ls),
                 min(ls), max(ls)))
    print('  ' + '─' * 74)
    print('  합계 %d편 (기대 1,189 = 성경 전체 장 수)\n' % len(items))
    for vol, rng, _, _ in VOLS:
        got = by.get(vol, [])
        if not got:
            continue
        print('  ── 제%d권 %s — 처음 둘 · 마지막 하나 ──' % (vol, rng))
        for x in (got[:2] + got[-1:]):
            print('     %-18s %-52s %6d자'
                  % ('%s %d' % (x[2], x[4]), x[5][:52], len(' '.join(x[7]))))


# ── 적재 ───────────────────────────────────────────────────────────────
def _vid(conn, bc, ch):
    r = conn.execute("SELECT MIN(verse_id), MAX(verse_id) FROM bible_index "
                     " WHERE bcode=? AND chapter=?", (bc, ch)).fetchone()
    return (r[0], r[1]) if r and r[0] else (None, None)


# ── 제목이 인용한 «그 절» 찾기 ─────────────────────────────────────────
# ★ 사용자 확정(2026-08-22): **범위는 장 전체, 표시는 정확한 절.**
#   ⓐ `start_vid`~`end_vid` = 그 장 전체 → P2 「내부자료」에서 **그 장 어느
#      절을 읽든** 이 편이 걸린다(선례 = SPURGEON_TOD 시편 강해).
#      마이어는 성경을 장 단위로 차례로 읽는 사람을 위한 책이다(서문).
#   ⓑ `key_verse_ref` = 「Genesis 1:5」 — **OCR 절 번호를 믿지 않고**
#      제목(인용문)을 성경 본문과 글자로 대조해 찾는다.
# ⚠ 마이어는 **개정역(RV)** 을 즐겨 썼다(서문) — 그 자매판이 ASV 다.
#   세 역본을 합치면 1,094/1,189 = 92% 를 찾는다(KJV 86 · ASV 86 · WEB 58).
_MATCH_VERS = ('KJV', 'ASV', 'WEB')
_MATCH_MIN = 0.60

# ── 개정역(RV) 1895 — **마이어가 실제로 쓴 판** ────────────────────────
# ★ 서문이 밝힌다: "often in the fresh light thrown on it from the Revised
#   Version". 그러니 제목의 글자는 **RV 가 정답**이다.
#   출처 https://ebible.org/find/details.php?id=engRV  (**public domain**)
#   파일 https://ebible.org/Scriptures/eng-rv_vpl.zip  (절마다 한 줄)
# ⚠ **배포용 DB 에 넣지 않는다** — 제목을 되살리는 대조에만 쓴다
#   (§18-10 WLC·GNT 검증 DB 와 같은 취급). `_rv_raw/` 는 gitignore.
# ⚠ 없어도 도구는 그대로 돈다 — 그때는 KJV·ASV·WEB 만 쓴다.
RV_ZIP = os.path.join(HERE, '_rv_raw', 'eng-rv_vpl.zip')
RV_URL = 'https://ebible.org/Scriptures/eng-rv_vpl.zip'
# 우리 bcode(1~66) → RV 파일의 책 코드. ⚠ 이 파일은 외경을 끼워 두었으므로
#   자리로 세면 안 되고 **이름으로** 맞춘다.
_RV_CODE = (
    'GEN EXO LEV NUM DEU JOS JDG RUT 1SA 2SA 1KI 2KI 1CH 2CH EZR NEH EST JOB '
    'PSA PRO ECC SOL ISA JER LAM EZE DAN HOS JOE AMO OBA JON MIC NAH HAB ZEP '
    'HAG ZEC MAL MAT MAR LUK JOH ACT ROM 1CO 2CO GAL EPH PHI COL 1TH 2TH 1TI '
    '2TI TIT PHM HEB JAM 1PE 2PE 1JO 2JO 3JO JUD REV').split()
_RV = None


def rv_text():
    """→ {(bcode, chapter, verse): 본문}. 파일이 없으면 빈 표."""
    global _RV
    if _RV is None:
        _RV = {}
        try:
            import zipfile
            z = zipfile.ZipFile(RV_ZIP)
            raw = z.read('eng-rv_vpl.txt').decode('utf-8', errors='replace')
            back = {c: i + 1 for i, c in enumerate(_RV_CODE)}
            for ln in raw.splitlines():
                m = re.match(r'^([A-Z0-9]{3})\s+(\d+):(\d+)\s+(.*)$', ln)
                if not m:
                    continue
                bc = back.get(m.group(1))
                if bc:
                    _RV[(bc, int(m.group(2)), int(m.group(3)))] = m.group(4)
        except Exception as e:
            print('[RV] 없다 — KJV·ASV·WEB 만 쓴다 (%s)' % e)
    return _RV


def _nwords(s):
    s = re.sub(r'[^a-z ]', ' ', s.lower())
    return [w for w in s.split() if len(w) > 2]


def _subseq(small, big):
    """small 의 낱말이 big 안에 **순서대로** 다 나오는가."""
    it = iter(big)
    return all(w in it for w in small)


def find_verse(conn, bc, ch, title, cache=None):
    """제목(인용문)과 가장 잘 맞는 절 번호. 못 찾으면 None.

    ⚠ 판정은 **낱말 포함률**이 주(0.75)이고 문자열 유사도가 보조(0.25)다 —
      OCR 이 제목의 글자를 흔들어도 낱말은 대개 살아 있다.
    """
    import difflib
    tw = _nwords(title)
    if len(tw) < 2:
        return None
    flat = ' '.join(re.sub(r'[^a-z ]', ' ', title.lower()).split())[:90]
    if cache is None:
        cache = {}
    # ⚠ **절마다 최고점을 모은 뒤** 견준다 — 세 역본을 도는 동안 같은 절이
    #   세 번 나오므로, 도는 김에 1·2위를 갱신하면 「자기 자신이 2위」가 된다.
    per, exact = {}, set()
    for ver in ('RV',) + _MATCH_VERS:
        key = (bc, ch, ver)
        if key not in cache:
            if ver == 'RV':
                rv = rv_text()
                cache[key] = [(v, t) for (b, c2, v), t in rv.items()
                              if b == bc and c2 == ch]
            else:
                cache[key] = conn.execute(
                    "SELECT bi.verse, c.verse_text FROM bible_index bi"
                    "  JOIN bible_content c ON c.verse_id = bi.verse_id"
                    " WHERE bi.bcode=? AND bi.chapter=? AND c.version_code=?",
                    (bc, ch, ver)).fetchall()
        for v, txt in cache[key]:
            vws = _nwords(txt or '')
            vw = set(vws)
            if not vw:
                continue
            # ★ **제목의 낱말이 그 절 안에 순서대로 다 들어 있는가** —
            #   이것이 가장 날카롭다. 낱말 자루로는 창 1 의 「…첫째/셋째/
            #   다섯째 날」을 못 가른다(실측 0.8984 대 0.8958).
            #   ⚠ 연속 포함으로 하면 OCR 이 낱말 하나만 깨뜨려도 무너진다
            #     (`and`→`a7id`). **순서만 지키면 되는 부분수열**로 본다.
            vflat = ' '.join(vws)
            if len(tw) >= 4 and _subseq(tw, vws):
                exact.add(v)
            cov = sum(1 for w in tw if w in vw) / float(len(tw))
            sim = difflib.SequenceMatcher(None, flat, vflat).ratio()
            sc = cov * 0.75 + sim * 0.25
            if sc > per.get(v, 0.0):
                per[v] = sc
    if len(exact) == 1:                   # 통째로 든 절이 딱 하나면 그것이다
        return exact.pop()
    if not per:
        return None
    rank = sorted(per.items(), key=lambda kv: -kv[1])
    best = rank[0][1]
    second = rank[1][1] if len(rank) > 1 else 0.0
    # ⚠ **애매하면 못 찾았다고 한다.** 같은 장에 비슷한 절이 여럿인 곳이 있다
    #   (창 1 은 「저녁이 되고 아침이 되니 …째 날」이 여섯 번). 구별하는
    #   낱말이 OCR 로 깨지면 아무 절이나 집게 된다 — 그럴 바엔 장만 적는다.
    if best < _MATCH_MIN or best - second < 0.05:
        return None
    return rank[0][0]


# ── 제목의 OCR 손상 되살리기 ───────────────────────────────────────────
# ★ 제목은 **성경 인용문**이다. 그러니 지어낼 필요가 없다 — 그 절의 실제
#   본문에서 낱말을 가져오면 된다(2026-08-22 사용자 「마이어 제목 OCR 문제는
#   해결하라」). 실측 204/1,189 편이 깨져 있었다(`Where a^t thou ?`).
# ⚠ **깨진 낱말만** 바꾼다. 제목을 통째로 성경 본문으로 갈아치우면 그것은
#   되살리는 것이 아니라 **다른 번역으로 바꿔치기**다(마이어는 RV 를 썼다).
# ⚠ 대조가 안 되는 편은 **손대지 않는다** — 짐작으로 고치면 그게 위작이다.
_DMG = re.compile(r"[A-Za-z]*[0-9^*{}|\\/]+[A-Za-z]+|[A-Za-z]+[0-9^*{}|\\/]+")
_TOKEN = re.compile(r"[A-Za-z0-9^*{}|\\/']+|[^A-Za-z0-9^*{}|\\/']+")


_VOCAB = None


def bible_vocab(conn):
    """성경 전체(KJV·ASV·WEB)에 **한 번이라도 나오는 낱말**의 모음.

    ★ 사전 대신 쓴다 — 여기 없는 낱말은 사실상 OCR 부스러기다(`tmto`·
      `agaifist`). 반대로 마이어가 쓴 RV 낱말은 그 자매판 ASV 에 대개 있어
      **엉뚱하게 바꾸지 않는다.**
    """
    global _VOCAB
    if _VOCAB is None:
        v = set()
        for (t,) in conn.execute(
                "SELECT verse_text FROM bible_content"
                " WHERE version_code IN ('KJV','ASV','WEB')"):
            if t:
                # ⚠ 성경 본문은 **굽은 아포스트로피**(U+2019)를 쓴다 —
                #   곧은 것으로 맞추지 않으면 `god's` 를 영영 못 찾는다(실측).
                v.update(re.findall(r"[a-z']+",
                                    t.lower().replace('’', "'")))
        # ★ **RV 낱말도 사전에** — 마이어가 쓴 판이라 그 표기가 정답이다
        for t in rv_text().values():
            v.update(re.findall(r"[a-z']+", t.lower().replace('’', "'")))
        _VOCAB = v
    return _VOCAB


def _is_damaged(w, vocab=None):
    """깨진 낱말인가 — ⓐ 숫자·기호가 끼었거나 ⓑ 성경 어디에도 없는 낱말."""
    if _DMG.fullmatch(w) or _DMG.search(w):
        return True
    if vocab is None:
        return False
    # ⚠ **붙임표로 이은 합성어는 성한 낱말이다** — `Peace-offering` ·
    #   `Jehovah-Jireh`. 통째로는 사전에 없어 깨진 것으로 잡히고, 그러면
    #   장 안의 `offering` 으로 바꿔 **낱말을 죽인다**(실측으로 잡았다).
    if '-' in w:
        bits = [b for b in re.split(r'-+', w.lower()) if b]
        if bits and all(re.sub(r"[^a-z']", '', b) in vocab for b in bits):
            return False
    k = re.sub(r"[^a-z']", '', w.lower())
    return bool(k) and len(k) > 2 and k not in vocab


def _keepcase(old, new):
    if old[:1].isupper():
        return new[:1].upper() + new[1:]
    return new


# 낱말 양끝의 문장부호 (하이픈은 뺀다 — `obedi-` 를 살려 뒤에서 잇는다)
_EDGE = '.,;:!?"\u2018\u2019\u201c\u201d()[]{}<>«»—–*'
_MAXRUN = 4          # 한 번에 통째로 갈아 끼울 수 있는 낱말 수


def _chunk(ch):
    """한 덩이 → (앞 부호, 알맹이, 뒤 부호). 알맹이 안의 부호는 그대로 둔다."""
    i, j = 0, len(ch)
    while i < j and ch[i] in _EDGE:
        i += 1
    while j > i and ch[j - 1] in _EDGE:
        j -= 1
    return ch[:i], ch[i:j], ch[j:]


def _norm(w):
    return re.sub(r"[^a-z']", '', w.lower().replace('\u2019', "'"))


def repair_title(conn, bc, ch, verse, title, cache=None):
    """제목의 깨진 낱말을 **그 절의 성경 본문**에서 되살린다. → (제목, 고친 수)

    ★ 참조는 **성경 본문**이다 — 제목이 성경 인용문이기 때문이다. 다른 마이어
      판본을 보지 않는다(1898 IA 스캔이 유일하고, 다른 스캔이 있어도 그것도
      OCR 이라 **다른 잡음**일 뿐이다).
    ⚠ 마이어는 **RV**(개정역)를 썼고 우리에겐 RV 가 없다. 그래서 **깨진 낱말만**
      바꾸고 성한 낱말은 절대 건드리지 않는다 — 안 그러면 RV 를 KJV 로
      바꿔치기하게 된다.

    ━━ 세 겹으로 고친다 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      ① **1:1** — 자리가 같고 비슷한 낱말 (`a^t` → `art`)
      ② **n:m 구간** — 낱말이 붙거나 갈라진 자리 (`theefj'om` → `thee from`).
         **양옆이 성한 낱말로 고정**되어 자리가 확정될 때만.
      ③ **기호 연결 해제** — `Behold^` · `God^s`(→ `God's`, `Gods` 아님)
    안전장치 넷 — 하나라도 어긋나면 손대지 않는다:
      ⓐ 그 구간의 **모든** 낱말이 깨진 것이라야 한다 (하나라도 성하면 그것은
        마이어의 표현 차이다)
      ⓑ **양옆이 성한 낱말로 고정**될 것 (자리가 확정되어야 한다)
      ⓒ 구간은 %d낱말 이하
      ⓓ 넣을 낱말은 **그 절에 실제로 있는 것**
    """ % _MAXRUN
    import difflib
    if not title or verse is None:
        return title, 0
    if cache is None:
        cache = {}
    vocab = bible_vocab(conn)
    src = []
    # ★ **RV 를 맨 앞에** — 마이어가 쓴 판이라 글자가 맞는다
    rvt = rv_text().get((bc, ch, verse))
    if rvt:
        src.append(rvt)
    for ver in _MATCH_VERS:
        key = (bc, ch, ver)
        if key not in cache:
            cache[key] = conn.execute(
                "SELECT bi.verse, c.verse_text FROM bible_index bi"
                "  JOIN bible_content c ON c.verse_id = bi.verse_id"
                " WHERE bi.bcode=? AND bi.chapter=? AND c.version_code=?",
                (bc, ch, ver)).fetchall()
        for v, txt in cache[key]:
            if v == verse and txt:
                src.append(txt)
    if not src:
        return title, 0

    # ⚠ **띄어쓰기로 먼저 나눈다.** 예전에는 기호로 쪼개서 `who7?i` 가
    #   `who7`+`?`+`i` 세 조각이 되어 낱말 단위 정렬이 아예 안 됐다.
    chunks = [_chunk(x) for x in _flat(title).split(' ') if x]
    widx = [k for k, (_p, core, _s) in enumerate(chunks)
            if re.search(r'[A-Za-z]', core)]
    tw = [chunks[k][1] for k in widx]
    low = [_norm(w) for w in tw]
    fixed = 0

    for txt in src:
        # \u26a0 \uc131\uacbd \ubcf8\ubb38\uc758 **\uad7d\uc740 \uc544\ud3ec\uc2a4\ud2b8\ub85c\ud53c**\ub97c \uace7\uac8c \ub9de\ucdb0 \ub123\ub294\ub2e4 \u2014
        #   \uc548 \uadf8\ub7ec\uba74 \uc81c\ubaa9\ub9c8\ub2e4 `God's` \uc640 `God\u2019s` \uac00 \uc11e\uc778\ub2e4.
        vw = [w.replace('\u2019', "'")
              for w in re.findall(r"[A-Za-z'\u2019]+", txt)]
        vl = [_norm(w) for w in vw]
        ops = difflib.SequenceMatcher(None, low, vl).get_opcodes()
        for oi, (tag, i1, i2, j1, j2) in enumerate(ops):
            if tag != 'replace':
                continue
            n, m = i2 - i1, j2 - j1
            # ⓐ 그 구간이 **전부** 깨진 낱말이라야 한다
            if not all(_is_damaged(tw[t], vocab) for t in range(i1, i2)):
                continue
            # ⓓ 넣을 낱말은 그 절에 있는 것 (성경 본문이니 당연하지만 확인)
            if any(vl[v] and vl[v] not in vocab for v in range(j1, j2)):
                continue
            if n == m:
                for k in range(n):
                    t, v = i1 + k, j1 + k
                    if difflib.SequenceMatcher(None, low[t], vl[v]).ratio() < 0.5:
                        # ⓑ 자리가 양옆으로 고정되어 있으면 닮지 않아도 받는다
                        anchored = (oi > 0 and ops[oi - 1][0] == 'equal'
                                    and oi + 1 < len(ops)
                                    and ops[oi + 1][0] == 'equal')
                        if not (anchored and n == 1):
                            continue
                    p, s = chunks[widx[t]][0], chunks[widx[t]][2]
                    chunks[widx[t]] = (p, _keepcase(tw[t], vw[v]), s)
                    tw[t], low[t] = vw[v], vl[v]
                    fixed += 1
            else:
                # ② 낱말이 붙거나 갈라진 자리 — ⓑⓒ 를 함께 지킨다
                if n > _MAXRUN or m > _MAXRUN:
                    continue
                if not (oi > 0 and ops[oi - 1][0] == 'equal'
                        and oi + 1 < len(ops) and ops[oi + 1][0] == 'equal'):
                    continue
                # ⚠⚠ **글자가 닮아야 한다.** 자리가 고정돼 있어도 길이가 다른
                #   구간은 엉뚱하게 늘어날 수 있다 — 실측: `7na?i`(=man) 를
                #   `rod of the man` 으로 바꿔 **없던 낱말을 넣을 뻔했다.**
                #   붙였다 떼는 것(`theefj'om`→`thee from`)만 통과시킨다.
                if difflib.SequenceMatcher(
                        None, ''.join(low[i1:i2]),
                        ''.join(vl[j1:j2])).ratio() < 0.6:
                    continue
                p = chunks[widx[i1]][0]
                s = chunks[widx[i2 - 1]][2]
                repl = ' '.join(vw[j1:j2])
                chunks[widx[i1]] = (p, _keepcase(tw[i1], repl), s)
                for t in range(i1 + 1, i2):          # 나머지 자리는 비운다
                    chunks[widx[t]] = ('', '', '')
                fixed += n
                break        # 자리표가 흔들리니 이 절에서는 여기까지

    # ③ 기호만 붙은 낱말 — 정렬에서 「같음」으로 잡혀 위 고리를 지나간다
    for k in widx:
        w = chunks[k][1]
        if not w:
            continue
        # ⚠ `^` 가 **아포스트로피**인 경우를 먼저 — 그냥 떼면 `God^s`→`Gods`
        for cand in (w.replace('^', "'"), re.sub(r"[0-9^*{}|\\/]+", '', w)):
            if cand == w or not cand:
                continue
            if _norm(cand) in vocab:
                chunks[k] = (chunks[k][0], cand, chunks[k][2])
                fixed += 1
                break

    out = _flat(' '.join(p + c + s for p, c, s in chunks))
    # 줄 안쪽 하이픈 조각 (`obedi- ence`) — 붙인 낱말이 그 절에 있을 때만
    joined = set()
    for txt in src:
        joined |= {_norm(w) for w in re.findall(r"[A-Za-z'\u2019]+", txt)}

    def _join(mm):
        w = mm.group(1) + mm.group(2)
        return w if _norm(w) in joined else mm.group(0)
    out2 = re.sub(r'([A-Za-z]{2,})-\s+([a-z]{2,})', _join, out)
    if out2 != out:
        fixed += 1
        out = out2
    return _flat(out), fixed


def strip_ref_tail(out, book, vocab=None):
    """제목 끝에 **남은 참조**를 뗀다 — `… Me. Getiesis xx. 6.` → `… Me.`

    ★ 이것은 저자의 글이 아니라 **인쇄된 참조**다. `_REF_TAIL` 이 책 이름의
      OCR 손상(`Getiesis`·`A^um`·`Exodtis`)을 못 읽어 105편에 남아 있었다.
      ⇒ **어느 책인지 이미 아니까**(성경 순서에서 배정했다) 그 이름과 닮은
        낱말을 꼬리에서 찾으면 된다. 성경 본문이 없어도 확실하다.
    ⚠ 뒤쪽 46자 안에서만 찾고, 떼고 남는 제목이 **8자 이상**일 때만 뗀다 —
      제목을 통째로 지우면 안 된다.
    """
    import difflib
    flat = _flat(out)
    tail_from = max(0, len(flat) - 46)
    b = (book or '').lower()
    if not b:
        return flat, 0
    best = None
    for m in re.finditer(r"[A-Za-z][A-Za-z'’]{2,}", flat[tail_from:]):
        w = m.group(0).lower().strip('.')
        r = max(difflib.SequenceMatcher(None, w, b).ratio(),
                difflib.SequenceMatcher(None, w, b[:4]).ratio())
        if r < 0.72:
            continue
        rest = flat[tail_from + m.end():]
        # ⚠⚠ **책 이름만 보고 자르면 안 된다.** 여호수아서 본문의 인물 이름
        #   「Joshua」를 책 이름으로 알아듣고 **저자의 글을 잘랐다**
        #   (`The Lord said unto Joshua^ Get thee up.` → `The Lord said unto`).
        #   룻·욥·다니엘·요한·야고보처럼 **사람 이름이 곧 책 이름**인 것이
        #   수두룩하다. ⇒ 뒤에 **장·절 꼴**이 따라올 때만 참조로 본다.
        mm = re.match(r"^[\s.,;:^*'\"’]*"
                      r"[ivxlcdmIVXLCDM0-9jJ1lt!\|nNuUwWhHaA]{1,8}\s*[.,]", rest)
        if not mm:
            continue
        # ⚠ 그 뒤에 **진짜 낱말이 없어야** 한다 — 참조는 숫자·부호뿐이다.
        #   길이로 재면 `N'um. via. iiy ijy /J, 21 (R. v.).` 처럼 절 번호가
        #   여럿인 것을 놓친다.
        words_after = [w for w in re.findall(r"[A-Za-z']{3,}", rest)
                       if w.lower() not in ('r', 'v', 'rv', 'marg', 'margin')]
        if vocab is not None:
            if any(re.sub(r"[^a-z']", '', w.lower()) in vocab
                   for w in words_after):
                continue
        elif len(rest) - mm.end() > 24:
            continue
        best = tail_from + m.start()
        break
    if best is None:
        return flat, 0
    head = flat[:best].rstrip(' ,;:')
    if len(head) < 8:
        return flat, 0
    return head, 1


def annotate_verses(conn, items):
    """→ {(권, 편번호): 절} · 찾은 개수."""
    cache, out = {}, {}
    for it in items:
        v = find_verse(conn, it[3], it[4], it[5], cache)
        if v:
            out[(it[0], it[1])] = v
    return out, len(out)


def apply(conn, items, dry=False):
    """이름으로 짝지어 `unit_id` 를 지키며 덮는다. 남는 옛 유닛은 HIDE.

    ⚠ 남는 유닛을 `sequence` 로 고르면 안 된다 — 옛 유닛의 번호는 1~301 이라
      새 번호 범위(1~1189) 안에 들어와 **하나도 안 걸린다**. 이번에 실제로
      쓴 `unit_id` 를 모아 두고 그 밖을 숨긴다.
    """
    bid = conn.execute("SELECT book_id FROM sys_book_asset WHERE book_code=?",
                       (BOOK_CODE,)).fetchone()[0]
    # ★ 짝짓기 열쇠 = **그 장의 첫 절**(`start_vid`) — 편 하나가 성경 한 장이라
    #   변하지 않는다. ⚠ 예전에는 **이름**으로 짝지었는데, 제목의 OCR 을
    #   고치자 164편이 새 `unit_id` 를 받아 **플랜이 그 유닛을 잃었다**(실측).
    #   이름은 다듬을 수 있는 것이라 열쇠가 될 수 없다.
    have, byname = {}, {}
    for uid, lab, sv in conn.execute(
            "SELECT unit_id, unit_label, start_vid FROM sys_book_unit"
            "  WHERE book_id=?"
            # 살아 있는 유닛을 먼저 — 숨긴 옛것을 되살리며 새것을 숨기면
            # 플랜의 `unit_key` 가 또 어긋난다
            "  ORDER BY CASE WHEN COALESCE(record_status,'LIVE')='LIVE'"
            "                THEN 0 ELSE 1 END, unit_id", (bid,)):
        if sv and sv not in have:
            have[sv] = uid
        k = re.sub(r'\W+', '', (lab or '').lower())
        if k and k not in byname:
            byname[k] = uid            # 옛 유닛(기준 구절 없음)을 위한 폴백
    verses, _n = annotate_verses(conn, items)
    rcache, n_fix = {}, 0
    kept, n_new, n_upd = set(), 0, 0
    for seq, it in enumerate(items, 1):
        vol, idx, nm, bc, ch, title, ref, paras = it
        # ★ 제목의 깨진 낱말을 그 절의 성경 본문에서 되살린다
        title, nf = repair_title(conn, bc, ch, verses.get((vol, idx)), title,
                                 rcache)
        # ★ 제목 끝에 남은 **인쇄된 참조**를 뗀다(저자의 글이 아니다)
        title, nr = strip_ref_tail(title, nm, bible_vocab(conn))
        n_fix += nf + nr
        body = '\n\n'.join(paras) + '\n\n' + ATTRIB
        # ★ 범위는 **장 전체**(그 장 어느 절에서나 걸린다) ·
        #   표시는 **제목 대조로 찾은 정확한 절**. OCR 절 번호는 안 쓴다.
        v = verses.get((vol, idx))
        kref = '%s %d:%d' % (nm, ch, v) if v else '%s %d' % (nm, ch)
        sv, ev = _vid(conn, bc, ch)
        uid = have.get(sv) or byname.get(re.sub(r'\W+', '', title.lower()))
        if uid in kept:
            uid = None                    # 같은 제목이 둘이면 앞것만 이어받는다
        if uid:
            n_upd += 1
            if not dry:
                conn.execute(
                    "UPDATE sys_book_unit SET sequence=?, unit_label=?,"
                    " session_type='CHAPTER', key_verse_ref=?, start_vid=?,"
                    " end_vid=?, record_status='LIVE' WHERE unit_id=?",
                    (seq, title, kref, sv, ev, uid))
        else:
            n_new += 1
            if dry:
                continue
            uid = conn.execute(
                "INSERT INTO sys_book_unit(book_id,sequence,session_type,"
                "unit_label,key_verse_ref,start_vid,end_vid,record_status)"
                " VALUES(?,?,'CHAPTER',?,?,?,?,'LIVE')",
                (bid, seq, title, kref, sv, ev)).lastrowid
        kept.add(uid)
        if dry:
            continue
        conn.execute("DELETE FROM sys_book_unit_text "
                     " WHERE unit_id=? AND text_variant='ORIGINAL'", (uid,))
        conn.execute(
            "INSERT INTO sys_book_unit_text(unit_id,text_variant,lang_code,"
            "body_text,record_status) VALUES(?,'ORIGINAL','EN',?,'LIVE')",
            (uid, body))
    # 새 파싱에 없는 옛 유닛 — **지우지 않고 숨긴다**(되돌릴 수 있게)
    n_hide = 0
    for (uid,) in conn.execute(
            "SELECT unit_id FROM sys_book_unit WHERE book_id=?"
            "   AND COALESCE(record_status,'LIVE')='LIVE'", (bid,)).fetchall():
        if uid in kept:
            continue
        n_hide += 1
        if not dry:
            conn.execute("UPDATE sys_book_unit SET record_status='HIDE'"
                         " WHERE unit_id=?", (uid,))
    return n_new, n_upd, n_hide


# ── 자가 검증 ──────────────────────────────────────────────────────────
def _selftest():
    fails = []

    def ck(n, ok, got=''):
        print(('  OK  ' if ok else '  FAIL') + ' ' + n +
              ('  | ' + str(got) if got != '' else ''))
        if not ok:
            fails.append(n)

    # 판 ㉠ (참조가 제목 끝) 과 판 ㉡ (참조가 따로) 를 한 글에 섞는다
    sample = '\n'.join([
        'OUR  DAILY  HOMILY', '',
        'The  Evening  and  the  Morning  were  the  First',
        'Day.  Genesis  i.  j. ', '',
        'HOW  different  is  God\'s  method  from  man\'s  !  The  crea-',
        'ture  works  from  day  to  night. ', '',
        'Art  thou  disappointed  ?  God  wrought  on. ', '',
        '1 ', '',
        'The  Lord  God  put  him  into  the  Garden. ', '',
        'Genesis  ii.  /j*. ', '',
        'THIS  is  the  first  charge.  Man  was  put  there  to  dress  it. ',
        '', '2 ', '',
        'Where  art  thou  ?  Genesis  iii.  p. ', '',
        'WHERE  indeed  !  The  voice  still  calls. ', '',
    ])
    b, un = boundaries(sample, 3)
    ck('경계 3개를 찾는다 (판 ㉠㉡ 혼재)', len(b) == 3 and not un,
       '%s · 못찾음 %s' % (sorted(b), un))
    segs = []
    keys = sorted(b)
    for k, i in enumerate(keys):
        en = b[keys[k + 1]] if k + 1 < len(keys) else len(sample)
        t, ps = split_entry(sample[b[i]:en])
        t, r = clean_title(t)
        segs.append((t, r, _join_body(ps)))
    # 제목 끝 마침표는 원문 그대로 살린다 (문장의 일부다)
    ck('첫 편 제목에서 참조를 뗀다',
       segs[0][0] == 'The Evening and the Morning were the First Day.'
       and 'Genesis' in segs[0][1], segs[0][:2])
    ck('둘째 편 제목은 앞 문단 (판 ㉡)',
       segs[1][0] == 'The Lord God put him into the Garden.', segs[1][0])
    ck('셋째 편 본문이 산다', segs[2][2] and 'WHERE indeed' in segs[2][2][0],
       segs[2][2])
    ck('본문에 쪽번호가 안 남는다',
       not any(_NUMLINE.match(p) for s in segs for p in s[2]))
    ck('하이픈 이음을 붙인다',
       any('creature' in p for p in segs[0][2]), segs[0][2])

    # ⚠ 쪽번호 관용 — 한 자리 수에 주면 안 된다 (규칙을 직접 잰다)
    ck('세 자리는 한 자리 어긋남을 봐준다 (335=235 · 836=236)',
       _page_close(335, 235) and _page_close(836, 236))
    ck('★ 한 자리 수는 정확히 맞아야 한다 (2 를 1 로 받지 않는다)',
       not _page_close(2, 1) and not _page_close(9, 8)
       and not _page_close(35, 25))
    ck('두 자리 이상 어긋나면 안 받는다', not _page_close(199, 235))
    ck('★ 이웃 쪽 번호를 받지 않는다 (118 ≠ 119 · 뼈대가 밀린다)',
       not _page_close(118, 119) and not _page_close(139, 138))
    pm = _page_marks('a\n\n2\n\nb\n\n3\n\nc\n', 10)
    ck('실제 배정에서도 1 은 안 채워진다', 1 not in pm and 2 in pm and 3 in pm,
       sorted(pm))

    # ★ 게이트가 «뭉친 편» 을 실제로 잡는가 — 첫 적재가 놓친 그것
    ok_items = [(5, i, 'Matthew', 40, i, '제목 %d' % i, 'Matt. i. 1',
                 ['x' * 2000]) for i in range(1, 261)]
    bad_items = list(ok_items)
    bad_items[3] = (5, 4, 'Matthew', 40, 4, '제목 4', 'Matt. iv. 1',
                    ['x' * 90000])
    b1, _ = check(ok_items, [])
    b2, _ = check(bad_items, [])
    ck('정상 260편은 길이 게이트를 지난다',
       not any('뭉침' in x for x in b1), [x for x in b1 if '뭉침' in x][:1])
    ck('★ 뭉친 편(20배)을 잡는다', any('뭉침' in x for x in b2),
       [x for x in b2 if '뭉침' in x][:1])
    short = ok_items[:200]
    b3, _ = check(short, [])
    ck('★ 편 수가 모자라면 잡는다 (성경 장 수와 대조)',
       any('성경 장 수' in x for x in b3), [x for x in b3 if '장 수' in x][:1])

    ck('권별 장 수 합계 = 1,189',
       sum(len(chapters_of(v)) for v, _, _, _ in VOLS) == 1189,
       sum(len(chapters_of(v)) for v, _, _, _ in VOLS))
    ck('제1권은 창세기 1장에서 시작해 룻기 4장에서 끝난다',
       chapters_of(1)[0] == ('Genesis', 1, 1)
       and chapters_of(1)[-1] == ('Ruth', 8, 4))
    ck('제5권은 마태 1장에서 시작해 계시록 22장에서 끝난다',
       chapters_of(5)[0] == ('Matthew', 40, 1)
       and chapters_of(5)[-1] == ('Revelation', 66, 22))
    ck('로마숫자 OCR 을 읽는다 (l=50 · xlviii=48)',
       _to_int('l') == 50 and _to_int('xlviii') == 48 and _to_int('23') == 23)
    ck('앞뒤 부속을 자른다',
       body_span('junk\nOUR  DAILY  HOMILY\nbody' + 'x' * 900
                 + '\nA  List  of\ntail')[0] > 0)
    # ⚠ 지우는 규칙에는 **오탐 검사**를 함께 (§0-1b 「Produced by」 사고)
    ck('★ 본문의 「a list of the stations」 를 광고로 오판하지 않는다',
       not _CATALOG.search('which contains a list of the stations through'))
    ck('줄머리의 「A List of」 는 잡는다',
       bool(_CATALOG.search('body\nA  List  of  Books\n')))

    # ★ 적재 — 실제 DB 에 넣었다 되돌린다 (남는 옛 유닛 처리를 잰다)
    try:
        conn = appdb.connect(DB)
    except Exception as e:
        ck('DB 를 연다', False, e)
        conn = None
    if conn is not None:
        try:
            # ★ 제목 → 절 찾기 (OCR 절 번호를 안 믿는 근거)
            ck('제목으로 절을 찾는다 (창 1 「저녁과 아침이 첫째 날」 → 5절)',
               find_verse(conn, 1, 1,
                          'The Evening and the Morning were the First Day.') == 5,
               find_verse(conn, 1, 1,
                          'The Evening and the Morning were the First Day.'))
            # 실제 손상 꼴 — `and`→`a7id` (구별하는 낱말 `first` 는 살아 있다)
            ck('OCR 로 깨진 제목도 낱말이 남으면 찾는다',
               find_verse(conn, 1, 1,
                          'The  Evening  a7id  the  Morning  were  the  First  Day.')
               == 5)
            # ★ 창 1 은 「저녁이 되고 아침이 되니 …째 날」이 여섯 번 나온다.
            #   구별하는 낱말이 깨지면 **아무 절이나 집지 말고 포기해야** 한다.
            ck('★ 비슷한 절이 여럿이고 구별 낱말이 깨지면 포기한다',
               find_verse(conn, 1, 1,
                          "The  Evening  and  the  Morning  were  the  fii'st  Day.")
               is None,
               find_verse(conn, 1, 1,
                          "The  Evening  and  the  Morning  were  the  fii'st  Day."))
            ck('★ 엉뚱한 글은 못 찾았다고 한다 (아무 절이나 집지 않는다)',
               find_verse(conn, 1, 1, 'the quick brown fox jumps over') is None,
               find_verse(conn, 1, 1, 'the quick brown fox jumps over'))
            # ★ 책 이름이 DB 정식 이름과 어긋나면 화면이 한국어로 못 옮긴다
            dbn = {r[0]: r[1] for r in conn.execute(
                "SELECT book_code, full_name FROM book_names"
                " WHERE lang_code='EN'")}
            odd = [(nm, dbn.get(bc)) for v, _, _, bks in VOLS
                   for nm, bc, _n in bks if dbn.get(bc) != nm]
            ck('★ 책 이름이 DB(book_names EN)와 같다', not odd, odd[:3])
            # ★ 제목 OCR 되살리기 — **성경 본문에서 낱말을 가져온다**
            V = bible_vocab(conn)
            ck('성경 낱말 사전을 만든다 (1만 개 이상)', len(V) > 10000, len(V))
            ck("굽은 아포스트로피를 곧게 맞춘다 (god's)", "god's" in V)
            rc = {}
            t, n = repair_title(conn, 1, 3, 9, 'Where a^t thou ?', rc)
            ck('숫자·기호가 낀 낱말을 되살린다 (a^t → art)',
               t == 'Where art thou ?' and n == 1, (t, n))
            t, n = repair_title(conn, 1, 37, 24,
                                'They took him a7id cast him into a pit.', rc)
            ck('a7id → and', 'and cast' in t, t)
            t, n = repair_title(conn, 56, 1, 1,
                                'According to the faith of God^s elect', rc)
            ck("★ `^` 가 아포스트로피면 붙인다 (God^s → God's, Gods 아님)",
               "God's" in t and 'Gods' not in t, t)
            t, n = repair_title(conn, 1, 1, 5,
                                'The Evening and the Morning were the First Day.',
                                rc)
            ck('★ 성한 제목은 손대지 않는다',
               t == 'The Evening and the Morning were the First Day.'
               and n == 0, (t, n))
            t, n = repair_title(conn, 1, 1, None, 'Wi^h an awl.', rc)
            ck('★ 절을 모르면 손대지 않는다 (짐작 금지)',
               t == 'Wi^h an awl.' and n == 0, (t, n))
            # ★ 구(句) 단위 — 낱말이 갈라졌다 붙는 자리
            t, n = repair_title(conn, 41, 2, 22,
                                'New wine into fresh wine- skins.', rc)
            ck('★ 갈라진 낱말을 잇는다 (wine- skins → wineskins)',
               'wineskins' in t, t)
            # ⚠⚠ **없던 낱말을 넣지 않는다** — 자리가 고정돼 있어도 글자가
            #   안 닮으면 거른다(실측: `7na?i`(man) 를 `rod of the man` 으로
            #   늘릴 뻔했다).
            t, n = repair_title(conn, 4, 17, 5,
                                'The 7na?i whom I shall choose', rc)
            ck('★ 없던 낱말을 끼워 넣지 않는다',
               'rod of the' not in t, t)
            # ⚠ 붙임표 합성어는 성한 낱말이다
            V2 = bible_vocab(conn)
            ck('★ `Peace-offering` 을 깨진 낱말로 보지 않는다',
               not _is_damaged('Peace-offering', V2))
            ck('`Jehovah-Jireh` 도 성한 낱말', not _is_damaged('Jehovah-Jireh', V2))
            ck('진짜 깨진 것은 여전히 잡는다',
               _is_damaged('agai7ist', V2) and _is_damaged('tmto', V2))
            def strip_ref_tail_V(t, b):
                return strip_ref_tail(t, b, V2)
            # ★ 제목 끝에 남은 **인쇄된 참조** 연결 해제 (저자의 글이 아니다)
            t, k = strip_ref_tail_V('/ am not Eloquent. Exodtis iv. lo.', 'Exodus')
            ck('★ 깨진 책 이름의 참조도 뗀다 (Exodtis)',
               t == '/ am not Eloquent.' and k == 1, (t, k))
            t, k = strip_ref_tail_V('Aaron offered them for a wave offering.'
                                  " N'um. via. iiy ijy /J, 21 (R. v.).", 'Numbers')
            ck("★ N'um 도 뗀다", t == 'Aaron offered them for a wave offering.', t)
            t, k = strip_ref_tail_V('The Evening and the Morning were the First Day.',
                                  'Genesis')
            ck('★ 참조가 없으면 손대지 않는다',
               t == 'The Evening and the Morning were the First Day.' and k == 0, t)
            t, k = strip_ref_tail_V('Genesis speaks here.', 'Genesis')
            ck('★ 떼면 너무 짧아지면 손대지 않는다 (제목을 지우지 않는다)', k == 0, (t, k))
            # ⚠⚠ **사람 이름이 곧 책 이름인 경우** — 이것을 못 가리면 저자의 글을 자른다
            t, k = strip_ref_tail_V('The Lord said unto Joshua^ Get thee up.', 'Joshua')
            ck('★★ 본문 속 사람 이름을 참조로 오인하지 않는다 (여호수아)',
               t == 'The Lord said unto Joshua^ Get thee up.' and k == 0, (t, k))
            t, k = strip_ref_tail_V('So Joshua took the whole land, . . . and Joshua'
                                  ' gave it. . . .', 'Joshua')
            ck('★★ 같은 이름이 두 번 나와도 안 자른다', k == 0, t)
            t, k = strip_ref_tail_V('Those twelve stones did Joshua set up in Gilgal.'
                                  ' Josh. iv. 20 (R. v.)', 'Joshua')
            ck('★ 진짜 참조는 뗀다 (Josh. iv. 20)',
               t == 'Those twelve stones did Joshua set up in Gilgal.', t)
            t, k = strip_ref_tail_V('And Ruth said, Entreat me not to leave thee.',
                                  'Ruth')
            ck('★★ 룻(사람=책 이름)도 안 자른다', k == 0, t)
            bid = conn.execute("SELECT book_id FROM sys_book_asset"
                               " WHERE book_code=?", (BOOK_CODE,)).fetchone()
            ck('마이어 도서가 등록돼 있다', bid is not None)
            if bid:
                bid = bid[0]
                n0 = conn.execute(
                    "SELECT COUNT(*) FROM sys_book_unit WHERE book_id=?"
                    "  AND COALESCE(record_status,'LIVE')='LIVE'",
                    (bid,)).fetchone()[0]
                conn.execute('BEGIN')
                fake = [(1, 1, 'Genesis', 1, 1, '_시험 제목 하나', '', ['본문'])]
                n_new, n_upd, n_hide = apply(conn, fake)
                left = conn.execute(
                    "SELECT COUNT(*) FROM sys_book_unit WHERE book_id=?"
                    "  AND COALESCE(record_status,'LIVE')='LIVE'",
                    (bid,)).fetchone()[0]
                # 시험 항목이 창 1장이라 그 유닛은 **되쓰인다**(짝짓기 열쇠가
                # start_vid 이므로). 나머지는 전부 숨겨져 하나만 남아야 한다.
                ck('★ 새 파싱에 없는 옛 유닛을 숨긴다 (sequence 로 선택하면 0건)',
                   left == 1 and n_hide >= n0 - 1,
                   '숨김 %d / 살아있던 %d / 남은 %d' % (n_hide, n0, left))
                row = conn.execute(
                    "SELECT key_verse_ref, start_vid, end_vid"
                    "  FROM sys_book_unit WHERE book_id=?"
                    "   AND COALESCE(record_status,'LIVE')='LIVE'",
                    (bid,)).fetchone()
                g1 = conn.execute("SELECT MIN(verse_id), MAX(verse_id) FROM"
                                  " bible_index WHERE bcode=1 AND chapter=1"
                                  ).fetchone()
                ck('범위는 장 전체로 적힌다 (창 1:1~1:31)',
                   row[1] == g1[0] and row[2] == g1[1], row[1:])
                conn.rollback()
                n1 = conn.execute(
                    "SELECT COUNT(*) FROM sys_book_unit WHERE book_id=?"
                    "  AND COALESCE(record_status,'LIVE')='LIVE'",
                    (bid,)).fetchone()[0]
                ck('되돌리면 흔적이 없다', n1 == n0, '%d → %d' % (n0, n1))
        finally:
            conn.close()

    print('\n=== %s (%d fail) ===' %
          ('PASS' if not fails else 'FAIL: ' + ', '.join(fails), len(fails)))
    return 1 if fails else 0


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(_selftest())
    if '--links' in a:
        SM.show_links(BOOK_CODE, links(),
                      note='1898년판 · 한 장에 한 편, 한 쪽에 한 편')
        return
    if '--fetch' in a:
        fetch()
        return
    items, probs = parse_all()
    if '--plan' in a:
        plan(items)
        bad, by = check(items, probs)
        print('  게이트: %s' % ('통과' if not bad else '%d건' % len(bad)))
        for x in bad[:20]:
            print('    ⚠', x)
        if len(bad) > 20:
            print('    … 외 %d건' % (len(bad) - 20))
        return
    bad, by = check(items, probs)
    print('파싱 %d편  %s' % (len(items),
                           ' · '.join('제%d권 %d' % (v, by.get(v, 0))
                                      for v, _, _, _ in VOLS)))
    for x in bad[:30]:
        print('  ⚠', x)
    if len(bad) > 30:
        print('  … 외 %d건' % (len(bad) - 30))
    if '--apply' in a:
        if bad:
            print('\n게이트를 통과하지 못했다 — 적재하지 않는다.')
            sys.exit(1)
        conn = appdb.connect(DB)
        try:
            n, u, h = apply(conn, items)
            conn.commit()
            print('\n새로 %d · 덮음 %d · 숨김 %d' % (n, u, h))
        finally:
            conn.close()


if __name__ == '__main__':
    main()
