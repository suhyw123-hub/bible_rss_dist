# -*- coding: utf-8 -*-
"""찬양 자동 연결 판정 — **곡 · 사역자** (2026-09-10 신설 · 영구).

사용자 지시: 「연결할 때 **exact 개념**을 활용하라. **애매하면 자동추천에서
(검토중)으로** 분류하라. 구절/용어 연결기능도 있지만 **원곡/사역자 연결 기능**도
있어야 한다.」

★★★ **판정은 두 값뿐이다.**

    EXACT  정확히 같다        → 바로 연결한다(LIVE)
    MAYBE  같아 보인다        → **자동추천에 「검토중」으로** 둔다(PEND)

  ⚠⚠ **애매한 것을 연결하지 않는다** — 「검토중」은 화면에 회색으로 뜨고 사람이
    눌러야 살아난다. 안 누르면 사용자에게 안 나간다(§220차 규칙 그대로).

★★★ **왜 부분 일치를 금지하나 — 실측으로 배운 것들.**
  · 「Bethel」 이라는 **딴 채널**이 있어 「BETHEL OF KOREA」와 섞였다(§233차).
  · 「Hold Me Fast」 로 찾으니 시편 139편의 **딴 곡**이 왔다 —
    원제는 「He Will Hold Me Fast」다(§234차).
  · 「기억하네」·「축복」·「임재」·「我們愛」 같은 **흔한 말**은 곡명 자리에 두면
    드라마·트로트·경매 물품을 끌고 온다(§234차 `COMMON_WORD_SONGS`).
  ⇒ **라틴문자는 낱말 경계로만 · 한글/CJK 는 긴 이름을 먼저 잡고 자리를 소비한다.**

★ 이 문 하나가 판정의 집이다 — 화면(심사)·유도(`db_song.derive`)·수집이
  **같은 답**을 쓴다. 두 벌이 되면 「화면에서는 되는데 유도하면 안 되는」 꼴이 난다.
"""
import json
import re
import sys

import appdb

DB = 'bible_master.db'

EXACT = 'EXACT'
MAYBE = 'MAYBE'

#: 라틴문자 이름은 이 길이 미만이면 **정확 일치만** 인정한다(부분 일치 금지).
_SHORT_LATIN = 6
#: 한글/CJK 이름은 이 길이 미만이면 흔한 말일 가능성이 커 **검토중**으로 내린다.
_SHORT_CJK = 3

_CJK = re.compile(r'[가-힣ぁ-ゖァ-ヺ一-鿿]')
_PUNCT = re.compile(r"[\s\-–—_·,.'\"“”‘’!?()（）\[\]【】/|:：]+")


def norm(s):
    """정규화 — 공백·부호를 걷고 소문자로. `db_song.title_key` 와 같은 규칙."""
    return _PUNCT.sub('', (s or '').lower())


def _has_cjk(s):
    return bool(_CJK.search(s or ''))


def _common_words(conn=None):
    """흔한 말 곡명 → 소문자 집합.

    ★★★ 2026-09-11 — **주제 용어**를 여기에 더한다(사용자 「십자가 영화가 섞인
      것과 유사한 현상을 예방할 방법」). 주제는 「이 찬양이 무엇에 관한
      것인가」를 적은 말이라 곡 이름이 되면 그 주제의 영상을 통째로 먹는다.
      ✅ 실측 곡 31 「십자가」에 **53편**이 붙었고 진짜 그 곡은 **3편**이었다.
    ⚠ **주제는 지금 둘뿐**(은혜·십자가)이라 과잉 검출이 없다. 주제를 늘리면
      이 목록도 저절로 따라온다 — 두 곳에 적지 않는다.
    ⚠ 연결을 안 주면 **옛 동작 그대로**다(코드 목록만).
    """
    out = set()
    try:
        import db_song_collect as SC
        out |= {str(w).lower() for w in SC.COMMON_WORD_SONGS}
    except Exception:
        pass
    if conn is not None:
        try:
            import db_worship_topic as _TP
            for _t in _TP.topics(conn):
                out |= {x.strip().lower()
                        for x in _TP.names_of(conn, _t[0]) if x and x.strip()}
        except Exception:
            pass
    return out


def contains_exact(hay, needle):
    """`hay` 가 `needle` 을 **낱말 하나로** 품는가.

    ⚠ 라틴문자는 앞뒤가 글자면 안 걸린다(`Hold Me Fast` ⊂ `He Will Hold Me
      Fast` 를 막는 자리는 여기가 아니라 **길이·정확 일치 규칙**이지만, 이
      함수는 `ver` 가 `Everything` 을 먹는 것을 막는다 — §233차).
    ⚠ CJK 는 낱말 경계가 없다 — 그대로 품기만 보고, 짧은 이름은 부르는 쪽이
      **검토중으로 내린다.**
    """
    h, n = (hay or ''), (needle or '')
    if not h or not n:
        return False
    if _has_cjk(n):
        return n in h
    m = re.search(r'(?<![0-9A-Za-z])%s(?![0-9A-Za-z])' % re.escape(n), h,
                  re.IGNORECASE)
    return bool(m)


# ── 재료 ──────────────────────────────────────────────────────────────
def song_names(conn):
    """[(song_id, rend_id|None, 이름, 언어)] — 곡 이름과 판 제목 전부.

    ⚠ 판 제목까지 봐야 한다 — 「새 일이 일어나네」로 들어온 영상이 곡
      `New Thing Coming` 의 **한국어 판**에 붙어야 하기 때문이다.
    """
    import db_song as SG
    out = []
    for sid, in conn.execute(
            "SELECT song_id FROM %s WHERE COALESCE(record_status,'LIVE')='LIVE'"
            % SG.T_SONG):
        for lg, nm in SG.names_of(conn, SG.NAME_SONG, sid).items():
            if nm:
                out.append((sid, None, nm, lg))
    for rid, sid, lg in conn.execute(
            "SELECT rend_id, song_id, lang_code FROM %s"
            " WHERE COALESCE(record_status,'LIVE')='LIVE'" % SG.T_REND):
        for _lg, nm in SG.names_of(conn, SG.NAME_REND, rid).items():
            if nm:
                out.append((sid, rid, nm, lg or _lg))
    return out


def artist_names(conn):
    """[(artist_id, 이름, 채널id, 채널이름)] — 사역자 이름 전부(언어별)."""
    import db_worship_artist as WA
    out = []
    for aid, ext, chn in conn.execute(
            "SELECT artist_id, channel_ext_id, channel_name FROM %s"
            " WHERE COALESCE(record_status,'LIVE')='LIVE'" % WA.TBL):
        for _lg, nm in WA.names_of(conn, aid).items():
            if nm:
                out.append((aid, nm, ext, chn))
        if not any(x[0] == aid for x in out):
            out.append((aid, '', ext, chn))
    return out


# ── ① 곡 판정 ─────────────────────────────────────────────────────────
def match_song(title, names, common=None):
    """제목에서 곡을 선택한다 → `[(song_id, rend_id, 판정, 근거, 걸린 이름)]`.

    차례가 곧 잣대다:
      ⓐ **정규화 후 제목 전체가 곡 이름과 같다** → `EXACT`
      ⓑ 제목이 곡 이름을 **낱말 하나로** 품고 이름이 **짧지도 흔하지도 않다**
         → `EXACT`
      ⓒ 품기는 하는데 **짧거나 흔한 말**이다 → `MAYBE`
      ⓓ **여러 곡이 걸렸다** → 전부 `MAYBE`(사람이 고른다)

    ⚠ **긴 이름을 먼저 본다** — 「Hold Me Fast」와 「He Will Hold Me Fast」가
      함께 있으면 긴 쪽이 이겨야 한다.
    """
    common = _common_words() if common is None else common
    t = title or ''
    tn = norm(t)
    hit = {}
    for sid, rid, nm, lg in sorted(names, key=lambda x: -len(x[2] or '')):
        nn = norm(nm)
        if not nn:
            continue
        key = (sid, rid)
        if key in hit:
            continue
        low = str(nm).lower()
        short = (len(nn) < _SHORT_CJK if _has_cjk(nm)
                 else len(nn) < _SHORT_LATIN)
        if tn == nn:
            hit[key] = (EXACT, '제목 전체가 같다', nm)
        elif contains_exact(t, nm):
            if low in common:
                hit[key] = (MAYBE, '흔한 말 곡명이라 사람이 본다', nm)
            elif short:
                hit[key] = (MAYBE, '이름이 짧아 딴 곡일 수 있다', nm)
            else:
                hit[key] = (EXACT, '제목이 곡 이름을 그대로 품는다', nm)
    out = [(k[0], k[1], v[0], v[1], v[2]) for k, v in hit.items()]
    # ⓓ 여러 곡이면 아무것도 못 박지 않는다 — **같은 곡의 여러 판은 예외**다
    if len({o[0] for o in out}) > 1:
        out = [(a, b, MAYBE, '곡이 여럿 걸렸다 — 사람이 선택한다', e)
               for a, b, _c, _d, e in out]
    return sorted(out, key=lambda x: (x[2] != EXACT, -len(x[4] or '')))


# ── ② 사역자 판정 ─────────────────────────────────────────────────────
def match_artist(title, channel, channel_id, names):
    """사역자를 선택한다 → `[(artist_id, 판정, 근거, 걸린 이름)]`.

      ⓐ **채널 id 가 같다** → `EXACT` (이름을 바꿔도 안 흔들린다)
      ⓑ **채널 이름이 정규화 후 완전히 같다** → `EXACT`
      ⓒ 제목·채널이 사역자 이름을 **낱말 하나로** 품는다 → `MAYBE`
      ⓓ 여럿 걸리면 전부 `MAYBE`

    ⚠⚠ **부분 일치로 못 박지 않는다** — 「Bethel」 이라는 딴 채널이 실제로
      있고 「BETHEL OF KOREA」와 섞였다(§233차). 그래서 ⓒ 는 언제나 검토중이다.
    """
    ch = channel or ''
    chn = norm(ch)
    cid = (channel_id or '').strip()
    t = title or ''
    hit = {}
    for aid, nm, ext, cname in sorted(names, key=lambda x: -len(x[1] or '')):
        if aid in hit:
            continue
        if cid and ext and cid == ext:
            hit[aid] = (EXACT, '채널 id 가 같다', cname or nm)
            continue
        if chn and cname and chn == norm(cname):
            hit[aid] = (EXACT, '채널 이름이 정확히 같다', cname)
            continue
        if nm and (contains_exact(ch, nm) or contains_exact(t, nm)):
            hit[aid] = (MAYBE, '이름이 제목·채널에 보인다', nm)
    out = [(a, v[0], v[1], v[2]) for a, v in hit.items()]
    if len(out) > 1:
        ex = [o for o in out if o[1] == EXACT]
        if len(ex) != 1:
            out = [(a, MAYBE, '사역자가 여럿 걸렸다 — 사람이 선택한다', n)
                   for a, _c, _d, n in out]
        else:
            out = ex + [(a, MAYBE, d, n) for a, c, d, n in out if c != EXACT]
    # ★★★ **채널이 곧 찬양팀이 아니다**(2026-09-25 · 1.txt 17번 2) (2)).
    #   사용자 「일반 채널관리자가 **다른 사람의 찬양곡을 올리는 경우도 많다**」.
    #   ⇒ 확정을 얻은 팀이 **제목에 한 번도 안 나오고** 제목이 다른 찬양팀만
    #     말하면, 그 확정은 「채널 주인」이라는 뜻뿐이라 **검토중으로 내린다**.
    #   ⚠⚠ 잣대를 실측으로 좁혔다 — 「제목이 다른 팀을 말한다」로 재면
    #     **함께 부른 자리**(Bethel Music + Jenn Johnson · Elevation Worship
    #     ft. Brandon Lake)를 전부 걸어 43편이 흔들린다. 채널 주인이 제목에
    #     함께 있으면 그것은 공동 크레딧이지 남의 곡을 올린 것이 아니다.
    #     좁힌 잣대로는 **18편**이고 그중 15편이 음반사 채널이다.
    #   ⚠ 막지 않는다 — 공식 채널이 제목에 이름을 안 적는 일도 있다.
    in_title = {}
    for aid, nm, _e2, _c2 in names:
        if nm and aid not in in_title and contains_exact(t, nm):
            in_title[aid] = nm
    ex_ids = {o[0] for o in out if o[1] == EXACT}
    if ex_ids and in_title and not (in_title.keys() & ex_ids):
        _who = ' · '.join(sorted(in_title.values())[:2])
        out = [(a, MAYBE,
                ('채널 주인이지만 제목은 다른 찬양팀(「%s」)을 말한다' % _who)
                if c == EXACT else d, n)
               for a, c, d, n in out]
        # ★ 제목이 말하는 팀을 **앞에** 둔다 — 사람이 먼저 보는 것이 답일 확률이 높다
        return sorted(out, key=lambda x: x[0] not in in_title)
    return sorted(out, key=lambda x: x[1] != EXACT)


# ── ③ 한 영상에 대한 추천 ─────────────────────────────────────────────
#: 사람이 지운 추천 — `(영상, 갈래, 대상)` 짝. **다시 안 띄운다.**
#:   ⚠ 연결을 지우는 것이 아니다 — 이미 살린 연결은 그대로 두고 추천 줄만 없앤다.
#:   ⚠ 「왜 지웠나」를 못 물으므로 **판정 규칙을 고치는 재료**로는 못 쓴다.
#:     그 재료는 `db_media_range --reclass` 처럼 따로 모은다(§222차).
REJ_TBL = 'sys_song_match_reject'


def ensure_rej(conn):
    conn.execute(
        "CREATE TABLE IF NOT EXISTS %s ("
        " media_id INTEGER NOT NULL,"
        " link_type TEXT NOT NULL,"
        " target_id INTEGER NOT NULL,"
        " at TEXT,"
        " PRIMARY KEY (media_id, link_type, target_id))" % REJ_TBL)
    return True


def reject(conn, media_id, link_type, target_id):
    """추천 하나를 지운다 → 새로 지웠으면 True.

    ⚠ **살아 있는 연결은 안 건드린다** — 검토중(PEND)인 줄만 걷는다.
    """
    ensure_rej(conn)
    cur = conn.execute(
        "INSERT OR IGNORE INTO %s(media_id, link_type, target_id, at)"
        " VALUES(?,?,?,datetime('now','localtime'))" % REJ_TBL,
        (int(media_id), link_type, int(target_id)))
    conn.execute(
        "UPDATE sys_link_asset SET record_status='HIDE'"
        " WHERE link_type=? AND clicked_id=? AND target_id=?"
        "   AND COALESCE(record_status,'LIVE')='PEND'",
        (link_type, int(media_id), int(target_id)))
    return bool(cur.rowcount)


def unreject(conn, media_id=None):
    """지운 추천을 되살린다(영상 하나 또는 전부) → 되살린 수."""
    ensure_rej(conn)
    if media_id is None:
        n = conn.execute("DELETE FROM %s" % REJ_TBL).rowcount
    else:
        n = conn.execute("DELETE FROM %s WHERE media_id=?" % REJ_TBL,
                         (int(media_id),)).rowcount
    conn.commit()
    return n


def unreject(conn, media_id, link_type=None, target_id=None):
    """**지운 추천을 되살린다** → 되살린 수.

    ★★★ 2026-09-11 사용자 — 「**실수로 제거하면 어떻게 복구하는가**」.
      답이 **없었다.** ✕ 가 되돌릴 수 없는 일을 하면서 그렇다고 말하지도
      않았다. ⇒ 되살릴 문과 자리를 만든다.
    ⚠ 가려 둔 연결도 함께 되살린다 — **사람이 따로 뗀 것이 아니면.**
    """
    ensure_rej(conn)
    q = "DELETE FROM %s WHERE media_id=?" % REJ_TBL
    args = [int(media_id)]
    if link_type:
        q += " AND link_type=?"
        args.append(link_type)
    if target_id is not None:
        q += " AND target_id=?"
        args.append(int(target_id))
    n = conn.execute(q, args).rowcount or 0
    return n


def rejected_rows(conn, media_id):
    """지운 추천을 **이름과 함께** → [(link_type, target_id, 이름)]."""
    out = []
    for lt, tid in rejected(conn, media_id):
        nm = '#%s' % tid
        try:
            if lt == 'MEDI_REND':
                import db_song as _SG
                _s = conn.execute("SELECT song_id FROM sys_song_rendition"
                                  " WHERE rend_id=?",
                                  (tid,)).fetchone()  # status-ok: 번호 하나로 제 줄의 곡 번호를 읽는다(이름표)
                if _s:
                    nm = '곡  %s' % (_SG.label(conn, _SG.NAME_SONG, _s[0], 'KO')
                                    or nm)
            else:
                import db_worship_artist as _WA
                nm = '사역자  %s' % (_WA.label(conn, tid, 'KO') or nm)
        except Exception:
            pass
        out.append((lt, tid, nm))
    return out


def rejected(conn, media_id):
    """그 영상에서 지운 추천 → {(갈래, 대상)}."""
    try:
        ensure_rej(conn)
        return {(r[0], r[1]) for r in conn.execute(
            "SELECT link_type, target_id FROM %s WHERE media_id=?" % REJ_TBL,
            (int(media_id),))}
    except Exception:
        return set()


#: ★★★ **찬양 아닌 갈래어가 있으면 정확성을 내린다**(2026-09-11 사용자 —
#:   「제이어스가 만든 **십자가** 찬양이 있다. 중국어로 십자가라는 제목의 영상이
#:   있는데 **영화**. 설명문에 영화라는 표현이 있음에도 불구하고 **이름이 같아서
#:   찬양으로 수집**한 것 같다. 찬양과 이름이 같아도 **찬양 이외의 다른 용어가
#:   있으면 정확성이 떨어지는 것으로 취급**해야 한다」).
#:   ✅ 실측이 그 자리를 그대로 보였다 — 곡 「十字架」에
#:     **《十字架：耶穌在中國》第一集**(다큐 시리즈)이 걸려 있었다.
#:   ⚠⚠ **낱말을 베끼지 않는다** — 갈래어의 집은 `media_taxonomy` 하나다
#:     (§241차 ① 「베낀 상수는 반드시 갈라진다」). 거기 것을 그대로 읽는다.
#:   ⚠ **연결을 끊지는 않는다** — 「십자가」가 그 곡인 것은 맞을 수 있다.
#:     **확정을 검토중으로 내려** 사람이 들어 보게 한다.
OTHER_GENRES = ('FILM', 'STUDY', 'READING')

#: 연재물 표시 — 「第一集」·「Episode 1」·「EP.125」·「제23화」.
#:   ⚠ 낱말이 아니라 **꼴**이라 `media_taxonomy` 의 낱말표에 못 담는다.
_RX_EPISODE = re.compile(
    r'\u7b2c\s*(?:\d{1,3}|[\u4e00\u4e8c\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u5341]{1,3})\s*[\u96c6\u8a71\u8bdd]|\bEpisode\s*\d{1,3}\b|\bEP\.?\s*\d{1,3}\b'
    r'|\uc81c\s*\d{1,3}\s*[\ubd80\ud654](?![\uac00-\ud7a3])', re.I)


def _genre_clash(title, desc='', lang=None):
    """이 영상에 **찬양 아닌 갈래어**가 있나 → 걸린 갈래 목록.

    ⚠ 찬양 낱말이 **더 세면** 충돌로 안 본다 — 「찬양 낭독 모음」은 찬양이 맞다
      (§237차 ⑲ 와 같은 잣대).
    """
    # ⚠⚠ **`load_classify_sets` 는 연결을 받는다**(경로가 아니다) — 경로를
    #   주면 조용히 터져 **아무것도 안 걸린다**(실측으로 당했다).
    try:
        import media_taxonomy as TX
        import appdb as _ad
        _c = _ad.connect(DB)
        try:
            sets = TX.load_classify_sets(_c)
        finally:
            _c.close()
    except Exception:
        sets = {}
    low = ((title or '') + ' ' + (desc or '')).lower()
    lg = lang or TX.guess_lang(title or '')

    def _n(cat):
        kws = TX.kw_for_lang(sets.get(cat, {}), lg)
        return [k for k in kws if k and k.lower() in low]

    wors = len(_n('WORSHIP'))
    got = []
    for cat in OTHER_GENRES:
        hit = _n(cat)
        if hit and len(hit) > wors:
            got.append((cat, hit[0]))
    # ★★★ **연재물 표시**(第N集 · Episode N · EP.N · 제N화) — 갈래어가 하나도
    #   없는 다큐·드라마를 잡는 유일한 신호다.
    #   ✅ 실측 — 찬양 1,707편 중 **6편**만 걸리고 그 가운데 하나가 바로
    #     《十字架：耶穌在中國》**第一集**(다큐)이다. 나머지 다섯은 찬양
    #     플레이리스트 시리즈인데 **이미 연속듣기로 내려간다**(겹쳐도 해가 없다).
    #   ⚠ 설교에는 282편이 걸린다 — 찬양 쪽에서만 쓰는 잣대다.
    # ⚠⚠ **찬양 낱말이 하나라도 있으면 안 본다**(2026-09-11 실측으로 고쳤다).
    #   처음에는 무조건 걸었는데, 데이터가 늘자 **걸린 8편 중 6편이 정당한 찬양
    #   플레이리스트**였다 — 「사순절 찬양 모음 Ep.1」·「[창세기 플레이리스트]
    #   EP1」. 연재 표시는 **찬양이라는 말이 어디에도 없을 때만** 신호다
    #   (실측 그 자리 = 《十字架：耶穌在中國》第一集 — 찬양 낱말 0).
    if not wors:
        m = _RX_EPISODE.search((title or '') + ' ' + (desc or '')[:300])
        if m:
            got.append(('FILM', m.group(0).strip()))
    return got


def _is_playlist(title, media_id=None, conn=None):
    """이 영상이 **여러 곡을 담은 묶음**인가.

    ⚠ 갈래는 제목에서 읽는다(§233차) — 「연속듣기」·「N곡」·「Nonstop」.
    """
    try:
        import media_taxonomy as TX
    except Exception:
        return False
    lg = None
    if conn is not None and media_id:
        r = conn.execute("SELECT lang_code FROM sys_media_asset"
                         # status-ok: 번호 하나로 언어만 읽는다
                         "  WHERE media_id=?", (media_id,)).fetchone()
        lg = r[0] if r else None
    # ⚠⚠ **언어를 모르면 `rend_kinds` 가 조용히 빈 목록을 낸다**(실측으로
    #   잡았다) — 그러면 묶음을 못 알아보고 한 곡에 못 박는다. 짐작이라도 한다.
    if not lg:
        lg = TX.guess_lang(title or '')
    return 'PLAYLIST' in (TX.rend_kinds(title or '', lg) or [])


def suggest(conn, media_id, snames=None, anames=None, common=None):
    """그 영상의 곡·사역자 추천 → dict.

    돌려주는 것 — `{'song': [...], 'artist': [...], 'title': …}`
    ⚠ **여기서 연결하지 않는다** — 판정만 한다. 연결은 `apply` 가 한다.
    """
    r = conn.execute("SELECT title, COALESCE(description,'')"
                     " FROM sys_media_asset WHERE media_id=?",
                     (media_id,)).fetchone()  # status-ok: 번호 하나로 제 줄의 제목·설명문을 읽어 판정한다(미검토도 심사 대상)
    if not r:
        return {'song': [], 'artist': [], 'title': ''}
    ti, d = r[0] or '', r[1] or ''
    ch = cid = ''
    if d.startswith('{'):
        try:
            j = json.loads(d)
            ch = j.get('channel') or ''
            cid = j.get('channel_id') or ''
        except Exception:
            pass
    snames = song_names(conn) if snames is None else snames
    anames = artist_names(conn) if anames is None else anames
    # ★ 사람이 지운 추천은 **다시 안 띄운다**(0.txt 3-2).
    rej = rejected(conn, media_id)
    import db_song as _SG
    import db_worship_artist as _WA
    common = common or _common_words(conn)   # ★ 주제 용어를 함께 본다
    songs = [x for x in match_song(ti, snames, common)
             if (_SG.LINK_MEDI, x[1]) not in rej]
    # ★★★ **연속듣기 묶음은 한 곡으로 못 박지 않는다**(§⑤-2 · 2026-09-11 실측).
    #   실측으로 잡았다 — 「[12시간 연속듣기] 보혈찬송 **25곡** | 나의 죄를
    #   씻기는 …」 이 「나의 죄를 씻기는」 하나에 **확정**으로 걸렸다. 그 영상은
    #   그 곡이 아니라 **그 곡을 담은 묶음**이다.
    #   ⇒ 이어는 두되 **검토중**으로 내린다 — 사람이 보고 정한다.
    if songs and _is_playlist(ti, media_id, conn):
        songs = [(a, b, MAYBE, '연속듣기 묶음이라 한 곡으로 못 박지 않는다', e)
                 for a, b, _c, _d, e in songs]
    # ★★★ **찬양 아닌 갈래어가 있으면 확정을 내린다**(2026-09-11 사용자).
    #   실측 — 곡 「十字架」에 **《十字架：耶穌在中國》第一集**(다큐)이 걸렸다.
    if songs and any(x[2] == EXACT for x in songs):
        _cl = _genre_clash(ti, d[:600] if d else '')
        if _cl:
            _lab = {'FILM': '영상물', 'STUDY': '성경공부', 'READING': '성경듣기'}
            _w = ' · '.join('%s 낱말 「%s」' % (_lab.get(c0, c0), k0)
                            for c0, k0 in _cl[:2])
            songs = [(a, b, MAYBE, '찬양 아닌 갈래어가 있다 — ' + _w, e)
                     for a, b, _c, _d, e in songs]
    arts = [x for x in match_artist(ti, ch, cid, anames)
            if (_WA.LINK, x[0]) not in rej]
    return {'title': ti, 'song': songs, 'artist': arts}


# ── ④ 연결 ────────────────────────────────────────────────────────────
def _link(conn, ltype, mid, tid, verdict):
    """연결 한 줄 — `EXACT` 면 LIVE, `MAYBE` 면 PEND(검토중). 멱등."""
    st = 'LIVE' if verdict == EXACT else 'PEND'
    row = conn.execute(  # status-ok: 연결 중복 확인 — 상태를 **값으로 읽어** 사람이 뗀 것(HIDE·MANUAL)을 안 되살린다
        "SELECT sys_link_id, record_status FROM sys_link_asset"
        " WHERE link_type=? AND clicked_id=? AND target_id=?",
        (ltype, mid, tid)).fetchone()
    if row:
        # ⚠ **사람이 살린 것을 도로 검토중으로 내리지 않는다.**
        if row[1] == 'LIVE' or st == row[1]:
            return False
        conn.execute("UPDATE sys_link_asset SET record_status=?"
                     " WHERE sys_link_id=?", (st, row[0]))
        return True
    conn.execute(
        "INSERT INTO sys_link_asset(link_type, clicked_id, target_id,"
        " record_status, confidence) VALUES(?,?,?,?,'AUTO')",
        (ltype, mid, tid, st))
    return True


def apply(conn, media_id, sug=None, only=None):
    """추천을 실제 연결로 → `{'song_live':n,'song_pend':n,'artist_live':n,…}`.

    `only` — `EXACT` 만 걸고 싶으면 `EXACT` 를 준다(수집 때 쓰는 값).
    ⚠ 판이 안 정해진 곡 추천(`rend_id=None`)은 **연결하지 않는다** — 영상은
      판에 붙지 곡에 붙지 않는다. 판을 고르는 것은 사람 몫이다.
    """
    import db_song as SG
    import db_worship_artist as WA
    sug = sug or suggest(conn, media_id)
    out = {'song_live': 0, 'song_pend': 0, 'artist_live': 0, 'artist_pend': 0}
    for sid, rid, v, _why, _nm in sug['song']:
        if rid is None or (only and v != only):
            continue
        if _link(conn, SG.LINK_MEDI, media_id, rid, v):
            out['song_live' if v == EXACT else 'song_pend'] += 1
    for aid, v, _why, _nm in sug['artist']:
        if only and v != only:
            continue
        if _link(conn, WA.LINK, media_id, aid, v):
            out['artist_live' if v == EXACT else 'artist_pend'] += 1
    return out


def run(conn, mids=None, only=None, dry=False, log=print):
    """여러 영상에 한꺼번에 → 요약. 재료를 **한 번만** 읽는다."""
    sn, an, cw = song_names(conn), artist_names(conn), _common_words()
    if mids is None:
        mids = [r[0] for r in conn.execute(
            "SELECT media_id FROM sys_media_asset"
            " WHERE record_status='LIVE' AND media_type='WORSHIP'")]
    tot = {'n': 0, 'song_live': 0, 'song_pend': 0,
           'artist_live': 0, 'artist_pend': 0}
    for mid in mids:
        s = suggest(conn, mid, sn, an, cw)
        tot['n'] += 1
        if dry:
            for sid, rid, v, why, nm in s['song']:
                if rid is not None:
                    tot['song_live' if v == EXACT else 'song_pend'] += 1
            for aid, v, why, nm in s['artist']:
                tot['artist_live' if v == EXACT else 'artist_pend'] += 1
            continue
        r = apply(conn, mid, s, only)
        for k in ('song_live', 'song_pend', 'artist_live', 'artist_pend'):
            tot[k] += r[k]
    if not dry:
        conn.commit()
    log('  영상 %d편 · 곡 연결 %d(검토중 %d) · 사역자 연결 %d(검토중 %d)'
        % (tot['n'], tot['song_live'], tot['song_pend'],
           tot['artist_live'], tot['artist_pend']))
    return tot


# ── 자가검증 ──────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    CW = {'기억하네', '축복', '임재', '我們愛', 'secret'}
    N = [
        (1, 11, 'New Thing Coming', 'EN'),
        (1, 12, '새 일이 일어나네', 'KO'),
        (2, 21, 'He Will Hold Me Fast', 'EN'),
        (3, 31, '기억하네 (시편 77편)', 'KO'),
        (3, 32, '기억하네', 'KO'),
        (4, 41, '十字架', 'ZH'),
    ]

    def v(res, sid):
        for a, b, c, d, e in res:
            if a == sid:
                return c
        return None

    # ── exact ──────────────────────────────────────────────────────
    t('★★★ 제목 전체가 같으면 EXACT',
      v(match_song('New Thing Coming', N, CW), 1) == EXACT)
    t('★★★ 제목이 곡 이름을 그대로 품으면 EXACT',
      v(match_song('[MV] 새 일이 일어나네 - 제이어스', N, CW), 1) == EXACT)
    t('★ 부호·공백이 달라도 같은 것으로 본다',
      v(match_song('New  Thing-Coming!', N, CW), 1) == EXACT)
    # ── maybe ──────────────────────────────────────────────────────
    t('★★★ **흔한 말 곡명은 검토중**(「기억하네」)',
      v(match_song('기억하네 - 어느 채널', N, CW), 3) == MAYBE)
    t('★★ 짧은 CJK 이름은 검토중(「十字架」는 3자라 통과 · 2자면 검토중)',
      v(match_song('十字架 讚美', N, CW), 4) == EXACT
      and v(match_song('사랑 노래', [(9, 91, '사랑', 'KO')], CW), 9) == MAYBE)
    t('★★★ **곡이 여럿 걸리면 전부 검토중**',
      all(x[2] == MAYBE for x in
          match_song('New Thing Coming 그리고 十字架', N, CW)))
    # ── 안 걸려야 하는 것 ──────────────────────────────────────────
    t('★★★ **「Hold Me Fast」 로 딴 곡을 먹지 않는다**',
      v(match_song('Hold Me Fast - 딴 곡', N, CW), 2) is None)
    # ★★★ **주제 용어가 흔한 말 목록에 든다**(2026-09-11 · 십자가 사고)
    import appdb as _ad9
    _c9 = _ad9.connect(DB)
    try:
        _cw9 = _common_words(_c9)
        _tp9 = set()
        try:
            import db_worship_topic as _TP9
            for _t9 in _TP9.topics(_c9):
                _tp9 |= {x.strip().lower() for x in _TP9.names_of(_c9, _t9[0])}
        except Exception:
            pass
        t('★★★ **주제 용어가 흔한 말에 든다**(십자가 사선택할 막는 자리)',
          bool(_tp9) and _tp9 <= _cw9, sorted(_tp9)[:4])
        t('★ 연결을 안 주면 **옛 동작 그대로**', _common_words() <= _cw9)
        import db_song as _SG9
        t('★★ `name_risk` 가 **주제어를 잡는다**',
          any(k == 'TOPIC' for k, _ in _SG9.name_risk(_c9, '십자가')))
        t('★★ `name_risk` 가 **채널·사역팀 이름을 잡는다**',
          any(k == 'TEAM' for k, _ in _SG9.name_risk(_c9, 'agapao worship')))
        t('★ 멀쩡한 이름은 **아무 말도 안 한다**',
          not _SG9.name_risk(_c9, '주 말씀대로 날 붙드소서'))
    finally:
        _c9.close()
    t('★★ 라틴 짧은 낱말이 낱말 속을 안 먹는다(ver ⊄ Everything)',
      not match_song('Everything I am', [(9, 91, 'ver', 'EN')], CW))
    t('★ 안 걸리면 빈 목록', match_song('아무 상관없는 제목', N, CW) == [])

    # ── 사역자 ─────────────────────────────────────────────────────
    A = [(1, '마커스워십', 'UC_MARKERS', 'MARKERS WORSHIP'),
         (1, 'MARKERS WORSHIP', 'UC_MARKERS', 'MARKERS WORSHIP'),
         (2, '베델 오브 코리아', 'UC_BETHELKR', 'BETHEL OF KOREA'),
         (3, 'Hillsong Worship', None, None)]

    def va(res, aid):
        for a, c, d, n in res:
            if a == aid:
                return c
        return None

    t('★★★ **채널 id 가 같으면 EXACT**',
      va(match_artist('아무 제목', '이름이 바뀐 채널', 'UC_MARKERS', A), 1) == EXACT)
    t('★★★ **채널 이름이 정확히 같으면 EXACT**',
      va(match_artist('아무 제목', 'MARKERS WORSHIP', '', A), 1) == EXACT)
    t('★★★ **「Bethel」 딴 채널을 안 먹는다**(부분 일치 금지)',
      va(match_artist('worship', 'Bethel', '', A), 2) is None)
    t('★★ 이름이 제목에 보이기만 하면 **검토중**',
      va(match_artist('Hillsong Worship - Oceans', '아무 채널', '', A), 3) == MAYBE)
    t('★★ 사역자가 여럿 걸리면 전부 검토중',
      all(x[1] == MAYBE for x in
          match_artist('마커스워십 과 Hillsong Worship 합동', '딴 채널', '', A)))

    # ── 채널이 곧 찬양팀이 아니다(1.txt 17번 2) (2)) ─────────────────
    #   ⚠ 음반사 채널(Integrity Worship)이 남의 곡을 올린 자리 — 실측 15편.
    A2 = A + [(4, 'Integrity Worship', 'UC_INTEG', 'Integrity Worship'),
              (5, 'Paul Wilbur', None, None)]
    _r2 = match_artist('Paul Wilbur - Baruch Haba', 'Integrity Worship',
                       'UC_INTEG', A2)
    t('★★★ **채널 주인이 제목에 없고 다른 팀만 있으면 확정을 내린다**',
      va(_r2, 4) == MAYBE, _r2)
    t('★★ 그때 **까닭을 사람 말로 적는다**',
      any('채널 주인이지만' in d for _a, _c, d, _n in _r2 if _a == 4), _r2)
    t('★★ 제목이 말하는 팀을 **앞에** 둔다', _r2 and _r2[0][0] == 5, _r2)
    # ★★★ **안 내려야 할 자리** — 공동 크레딧(채널 주인도 제목에 있다)
    _r3 = match_artist('Oceans - 마커스워십 & Hillsong Worship',
                       'MARKERS WORSHIP', 'UC_MARKERS', A2)
    t('★★★ **함께 부른 자리는 안 내린다**(채널 주인이 제목에도 있다)',
      va(_r3, 1) == EXACT, _r3)
    # ★ 제목에 아무 팀도 없으면 종전대로 확정
    t('★ 제목이 아무 팀도 안 말하면 채널 확정 그대로',
      va(match_artist('Baruch Haba (Live)', 'Integrity Worship',
                      'UC_INTEG', A2), 4) == EXACT)

    # ── 연결 ───────────────────────────────────────────────────────
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY,"
              " link_type TEXT, clicked_id INT, target_id INT, end_id INT,"
              " record_status TEXT, confidence TEXT)")
    sug = {'song': [(1, 11, EXACT, '', 'x'), (2, 21, MAYBE, '', 'y')],
           'artist': [(1, EXACT, '', 'z')]}
    r = apply(c, 100, sug)
    st = dict(c.execute("SELECT target_id, record_status FROM sys_link_asset"
                        " WHERE link_type='MEDI_REND'").fetchall())
    t('★★★ **EXACT 는 LIVE · MAYBE 는 PEND(검토중)**',
      st.get(11) == 'LIVE' and st.get(21) == 'PEND', st)
    t('★ 사역자도 같은 규칙',
      c.execute("SELECT record_status FROM sys_link_asset"
                " WHERE link_type='MEDI_ARTI'").fetchone()[0] == 'LIVE')
    r2 = apply(c, 100, sug)
    t('★★ 멱등 — 두 번 걸어도 안 는다',
      c.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0] == 3
      and sum(r2.values()) == 0, r2)
    c.execute("UPDATE sys_link_asset SET record_status='LIVE' WHERE target_id=21")
    apply(c, 100, sug)
    t('★★★ **사람이 살린 것을 도로 검토중으로 안 내린다**',
      c.execute("SELECT record_status FROM sys_link_asset"
                " WHERE target_id=21").fetchone()[0] == 'LIVE')
    r3 = apply(c, 101, sug, only=EXACT)
    t('★★ `only=EXACT` 면 검토중은 안 건다',
      r3['song_live'] == 1 and r3['song_pend'] == 0, r3)
    t('★ 판이 없는 곡 추천은 연결하지 않는다(영상은 판에 붙는다)',
      apply(c, 102, {'song': [(5, None, EXACT, '', 'q')], 'artist': []})
      ['song_live'] == 0)
    c.close()

    # ── 추천 지우기 ────────────────────────────────────────────────
    c2 = __import__('sqlite3').connect(':memory:')
    c2.execute("CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY,"
               " link_type TEXT, clicked_id INT, target_id INT, end_id INT,"
               " record_status TEXT, confidence TEXT)")
    c2.execute("CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY,"
               " title TEXT, description TEXT)")
    c2.execute("INSERT INTO sys_media_asset VALUES(7,'New Thing Coming','')")
    apply(c2, 7, {'song': [(1, 11, MAYBE, '', 'x')], 'artist': []})
    t('★ 검토중 연결이 걸렸다',
      c2.execute("SELECT record_status FROM sys_link_asset").fetchone()[0] == 'PEND')
    t('★★★ **추천을 지우면 검토중 줄이 걷힌다**',
      reject(c2, 7, 'MEDI_REND', 11)
      and c2.execute("SELECT record_status FROM sys_link_asset"
                     " WHERE target_id=11").fetchone()[0] == 'HIDE')
    t('★★ 지운 것은 추천에 다시 안 뜬다',
      (11,) not in [(x[1],) for x in
                    suggest(c2, 7, [(1, 11, 'New Thing Coming', 'EN')], [])['song']])
    t('★★ 두 번 지워도 안 는다', not reject(c2, 7, 'MEDI_REND', 11))
    c2.execute("UPDATE sys_link_asset SET record_status='LIVE'")
    reject(c2, 7, 'MEDI_REND', 11)
    t('★★★ **살아 있는 연결은 안 건드린다**',
      c2.execute("SELECT record_status FROM sys_link_asset").fetchone()[0] == 'LIVE')
    t('★ 되살릴 수 있다', unreject(c2, 7) >= 1 and not rejected(c2, 7))
    c2.close()

    # ── 실 DB 탐침 ─────────────────────────────────────────────────
    try:
        rc = appdb.connect(DB)
        sn, an = song_names(rc), artist_names(rc)
        t('★ 실 DB 에서 곡 이름을 읽는다', len(sn) > 0, len(sn))
        t('★ 실 DB 에서 사역자 이름을 읽는다', len(an) > 0, len(an))
        got = run(rc, mids=[r[0] for r in rc.execute(
            "SELECT media_id FROM sys_media_asset WHERE record_status='LIVE'"
            "   AND media_type='WORSHIP' LIMIT 300")], dry=True, log=lambda s: None)
        t('★★ 실 DB 300편에서 추천이 나온다',
          got['song_live'] + got['song_pend'] > 0, got)
        rc.close()
    except Exception as e:
        t('★ 실 DB 탐침', False, repr(e))

    # ── ⑧ 연속듣기 묶음 ──────────────────────────────────────────────
    t('★★★ **연속듣기 묶음을 알아본다**',
      _is_playlist('[12시간 연속듣기] 보혈찬송 25곡 | 나의 죄를 씻기는')
      and not _is_playlist('나의 죄를 씻기는 - 마커스워십'))
    try:
        import sqlite3 as _s3
        c9 = _s3.connect(':memory:')
        c9.execute("CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY,"
                   " title TEXT, description TEXT, lang_code TEXT)")
        c9.execute("INSERT INTO sys_media_asset VALUES(1,?,'','KO')",
                   ('[12시간 연속듣기] 보혈찬송 25곡 | 나의 죄를 씻기는',))
        c9.execute("INSERT INTO sys_media_asset VALUES(2,?,'','KO')",
                   ('나의 죄를 씻기는 - 특송',))
        c9.execute("CREATE TABLE sys_media_reject(media_id INT, link_type TEXT,"
                   " target_id INT, record_status TEXT)")
        nm = [(7, 70, '나의 죄를 씻기는', 'KO')]
        g1 = suggest(c9, 1, snames=nm, anames=[], common=set())
        g2 = suggest(c9, 2, snames=nm, anames=[], common=set())
        t('★★★ **묶음이면 검토중으로 내린다**(한 곡이 아니다)',
          bool(g1['song']) and g1['song'][0][2] == MAYBE, g1['song'][:1])
        t('★ 한 곡짜리는 그대로 확정',
          bool(g2['song']) and g2['song'][0][2] == EXACT, g2['song'][:1])
        c9.close()
    except Exception as _e:
        t('★ 묶음 시험이 돈다', False, repr(_e))

    # ── ⑨ 찬양 아닌 갈래어(2026-09-11 사용자) ────────────────────────
    t('★★★ **연재물 표시를 잡는다**(다큐·드라마)',
      bool(_RX_EPISODE.search('《十字架：耶穌在中國》第一集'))
      and bool(_RX_EPISODE.search('EP.125'))
      and bool(_RX_EPISODE.search('제23화')))
    t('★★ **찬양 제목은 안 잡는다**',
      not _RX_EPISODE.search('십자가 The Cross | 제이어스 J-US')
      and not _RX_EPISODE.search('【十字架 The Cross】現場敬拜MV'))
    t('★★ **제1부작 같은 말은 안 먹는다**(뒤에 한글이 이어지면 아니다)',
      not _RX_EPISODE.search('제3화음으로'))
    t('★★★ **그 다큐가 실제로 걸린다**',
      any(c0 == 'FILM' for c0, _k in
          _genre_clash('《十字架：耶穌在中國》第一集 生命泉')),
      _genre_clash('《十字架：耶穌在中國》第一集 生命泉'))
    t('★★★ **제이어스 십자가는 안 걸린다**(찬양이 맞다)',
      not _genre_clash('십자가 The Cross | 제이어스 J-US | Live Worship'))
    import inspect as _i9
    t('★★ **갈래 낱말을 베끼지 않는다**(`media_taxonomy` 가 집)',
      'media_taxonomy' in _i9.getsource(_genre_clash))
    t('★★★ **확정을 내리기만 한다 — 연결을 끊지 않는다**',
      "'찬양 아닌 갈래어가 있다 — '" in _i9.getsource(suggest))

    print('db_song_match selftest %d/%d' % (ok[0], ok[1]))
    return 0 if ok[0] == ok[1] else 1


def main(argv):
    if '--selftest' in argv:
        return selftest()
    conn = appdb.connect(DB)
    try:
        if '--suggest' in argv:
            mid = int(argv[argv.index('--suggest') + 1])
            s = suggest(conn, mid)
            print('제목:', s['title'])
            for sid, rid, v, why, nm in s['song']:
                print('  곡   %-6s 곡%s 판%s  %-28s %s' % (v, sid, rid, nm, why))
            for aid, v, why, nm in s['artist']:
                print('  사역자 %-6s %s  %-28s %s' % (v, aid, nm, why))
            return 0
        dry = '--apply' not in argv
        only = EXACT if '--exact-only' in argv else None
        run(conn, only=only, dry=dry)
        if dry:
            print('  (미리보기입니다 — 실제로 걸려면 --apply)')
    finally:
        conn.close()
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
