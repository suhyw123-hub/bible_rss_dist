# -*- coding: utf-8 -*-
"""
search_view.py — **통합검색** 화면 (2026-08-21 신설)
=====================================================
P4 연구자료 탭의 넷째 갈래. 뒤판은 `search.py` 하나뿐이고 이 파일은 **화면만**
맡는다 — 나중에 색인으로 갈아 끼워도 이 파일은 안 바뀐다.

★ **팝업이 아니라 갈래다** (사용자 판단): 「사용자는 태그와 검색의 차이를
  모른다. 태그 화면은 P4 에 숨어 있어 검색창으로 접근하려 할 것이다」 —
  두 화면을 나란히 두어 차이를 저절로 배우게 한다.

★ **체크칸은 묶음, 점프는 세부 자산** (사용자 지시 — 「성격이 비슷한 것끼리
  묶어서 체크 표시하고 괄호로 묶어라. 실제 연결은 각 세부 자산별로 연결되어야
  한다. **중요하다.**」). 묶음·자산군 표는 전부 `search.py` 에 있고 이 화면은
  그것을 **읽어서 그린다** — 나중에 묶음을 쪼개도 여기는 안 고친다.

배치 (사용자 지정):
    좌 ── 검색창 + 언어 + 역본 (폭이 넓을 필요 없다)
    우 ── 찾을 곳 체크칸 1~2줄

⚠ 질의는 **일하는 실**에서 돈다. 거기서는 위젯도 `StringVar` 도 만지지 않는다
  (둘 다 Tk 호출이라 `main thread is not in main loop` 로 죽는다 — 실측).
  결과는 **큐**로 넘기고 화면 쪽 `_poll` 이 꺼내 간다.
"""
import queue
import threading
import tkinter as tk
from tkinter import ttk

import appdb
import i18n
import search

DEBOUNCE_MS = 200
PAGE = 20


def _C(role, dflt):
    try:
        import ui_theme
        return ui_theme.C(role) or dflt
    except Exception:
        return dflt


class SearchView(ttk.Frame):
    """통합검색 갈래 본체."""

    def __init__(self, parent, db_path, lang_getter=None, ver_getter=None,
                 on_jump=None, **kw):
        super().__init__(parent, **kw)
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.ver_getter = ver_getter or (lambda: 'KRV')
        self.on_jump = on_jump              # (kind, id) → 그 화면
        self._job = None
        self._gen = 0
        self._worker_conn = None
        self._hits = {}
        self._limits = {}
        self._ref = None
        self._out = queue.Queue()
        self._poll_job = None
        self._pref_sig = None
        self._build()

    # ── 화면 ────────────────────────────────────────────────────────────
    def _build(self):
        top = tk.Frame(self)
        top.pack(fill='x', padx=6, pady=(6, 2))

        # 좌 — 검색창 · 언어 · 역본 (넓을 필요 없다)
        # ⚠ **`pack_propagate(False)` 로 폭을 고정하지 말 것** — 그러면 **높이
        #   전파도 함께 끊겨** 안쪽 콤보가 26px → **12px 로 눌렸다**(실측).
        #   폭은 검색창 `width=` 로 정하고 세로는 Tk 에 맡긴다.
        left = tk.Frame(top)
        left.pack(side='left', fill='y')
        # ⚠ **글꼴을 적지 않는다** (§36 표준서식 · 2026-08-21 사용자 지시
        #   「검색창·버전콤보·언어콤보 크기 등을 표준서식 따르도록」).
        #   비우면 TkDefaultFont = 통합폰트 「ui」 구역을 따라 표시부·펼침
        #   목록·높이가 함께 표준을 탄다. `font=('', 11)` 은 §36 위반이었다.
        r1 = tk.Frame(left)
        r1.pack(fill='x')
        self._q = tk.StringVar()
        ent = ttk.Entry(r1, textvariable=self._q, width=30)
        ent.pack(side='left')
        ent.bind('<KeyRelease>', self._on_type)
        ent.bind('<Return>', lambda _e: self._run_now())
        self._entry = ent
        tk.Button(r1, text=i18n.t('COMMON_SEARCH', '찾기'), font=('', 9),
                  bd=1, padx=8, pady=0, cursor='hand2',
                  command=self._run_now).pack(side='left', padx=(4, 0))
        # ★ 한 줄 — 검색창 · 찾기 · (공백) · 언어콤보 · 역본콤보 (2026-09-16 ·
        #   1.txt 8-2 사용자 지정 차례. 「어디서」·언어·역본 **라벨은 걷었다**).
        r2 = r1
        tk.Frame(r2, width=14).pack(side='left')
        # ★ **언어는 앱 표준 부품**(`lang_combo.LangCombo`) — 이름을 그 언어의
        #   자기 이름으로 보이고 직전값을 화면마다 따로 기억한다. 직접 콤보를
        #   만들었더니 코드가 그대로 뜨고 `ui_langs()` 를 잘못 풀어 한 글자만
        #   보였다(사용자 신고).
        import lang_combo as _lc
        self._lang_combo = _lc.LangCombo(
            r2, db_path=self.db_path, width=14, gap=4, pady=0, side='left',
            default_lang=(self.lang_getter() or 'KO'), key='LANGSEL_SEARCH',
            on_change=lambda _cur: self._run_now())
        self._lang_combo.set_items(_lc.lang_items())
        self._ver = tk.StringVar(value=self.ver_getter())
        # 역본 콤보 규격은 작성도구(`ref_compose`)와 같게 — width 10 · 글꼴 없음
        self._ver_cb = ttk.Combobox(r2, textvariable=self._ver, width=10,
                                    state='readonly')
        self._ver_cb.pack(side='left', padx=(4, 0))
        self._ver_cb.bind('<<ComboboxSelected>>', self._on_ver_change)

        # 우 — 찾을 곳 (묶음 체크칸 · 괄호 안에 무엇이 들었나)
        # 찾을 곳 체크칸 — **라벨 없이** 줄 아래에(2026-09-16 · 1.txt 8-2 「"어디서"
        #   라벨 삭제」). 묶음 이름이 체크칸 글자에 이미 있다.
        right = tk.Frame(self)
        right.pack(fill='x', padx=6, pady=(0, 2), after=top)
        self._cond = tk.Frame(right)
        self._cond.pack(fill='x')
        self._on = {}
        self._boxes = []
        for bk in search.buckets():
            v = tk.IntVar(value=1)
            self._on[bk] = v
            cb = tk.Checkbutton(self._cond, text=search.bucket_label(bk),
                                variable=v, font=('', 9), command=self._run_now)
            self._boxes.append(cb)
        self._rows_f = []
        self._reflow_w = 0
        self._cond.bind('<Configure>', self._reflow)

        # 안내 줄 — 찾은 것이 없을 때만 (꺼 둔 묶음을 권한다)
        self._hint = tk.Frame(self)
        self._hint_lb = tk.Label(self._hint, text='', anchor='w', font=('', 9),
                                 padx=8, pady=4)
        self._hint_lb.pack(side='left', fill='x', expand=True)
        self._hint_btn = tk.Button(self._hint, text='', font=('', 9), bd=1,
                                   padx=8, pady=0, cursor='hand2',
                                   command=self._hint_go)
        self._hint_btn.pack(side='right', padx=6, pady=3)

        # 결과 — 좌(세부 자산군) / 우(그 군의 줄). 태그 탐색과 같은 좌우 구조
        pw = ttk.PanedWindow(self, orient='horizontal')
        self._pw = pw
        pw.pack(fill='both', expand=True, padx=6, pady=(2, 6))
        lf = ttk.Frame(pw)
        pw.add(lf, weight=1)
        self._gtv = ttk.Treeview(lf, columns=('n',), show='tree headings',
                                 selectmode='browse')
        self._gtv.heading('#0', text=i18n.t('SEARCH_WHERE', '찾을 곳'))
        self._gtv.heading('n', text=i18n.t('COMMON_COUNT', '건수'))
        self._gtv.column('#0', width=140, anchor='w')
        self._gtv.column('n', width=60, anchor='e', stretch=False)
        self._gtv.pack(side='left', fill='both', expand=True)
        self._gtv.bind('<<TreeviewSelect>>', lambda _e: self._show_group())

        rf = ttk.Frame(pw)
        pw.add(rf, weight=3)
        # ★ [더 보기] 는 **왼쪽 위**(2026-09-16 · 1.txt 8-3 사용자 「20개가 표시한도.
        #   더 보기 기능이 없는 것처럼 보인다. 상단 왼쪽에 배치하라」) — 아래 두면
        #   목록에 가려 안 보였다. 머리글과 같은 줄 왼쪽.
        self._morebar = tk.Frame(rf)
        self._morebar.pack(side='top', fill='x')
        self._more = tk.Button(self._morebar, text=i18n.t('COMMON_MORE', '더 보기'),
                               font=('', 9), bd=1, padx=8, pady=0,
                               cursor='hand2', command=self._load_more)
        self._head = tk.Label(self._morebar, text='', anchor='w', font=('', 9))
        self._head.pack(side='left', fill='x', expand=True, padx=(4, 0))
        self._rtv = ttk.Treeview(rf, columns=('t', 's'), show='headings')
        self._rtv.heading('t', text=i18n.t('COMMON_NAME', '이름'))
        self._rtv.heading('s', text=i18n.t('TAGS_BODY', '본문'))
        self._rtv.column('t', width=150, anchor='w', stretch=False)
        self._rtv.column('s', width=360, anchor='w')
        sb = ttk.Scrollbar(rf, command=self._rtv.yview)
        self._rtv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._rtv.pack(side='left', fill='both', expand=True)
        # ★ 한 번 누르면 **오른쪽에 본문**, 두 번 누르거나 [이동] 이면 그 화면으로
        #   (2026-09-16 · 1.txt 8-4). 그전에는 한 번에 이동해 버려 고를 수 없었다.
        self._rtv.bind('<ButtonRelease-1>', self._on_click_row)
        self._rtv.bind('<Double-1>', self._on_go)
        self._rtv.bind('<Return>', self._on_go)

        pf = ttk.Frame(pw)
        pw.add(pf, weight=3)
        pbar = tk.Frame(pf)
        pbar.pack(side='top', fill='x')
        self._go_btn = tk.Button(pbar, text='▶ ' + i18n.t('SEARCH_GO', '이동'),
                                 font=('', 9), bd=1, padx=8, pady=0,
                                 cursor='hand2', command=self._on_go)
        self._go_btn.pack(side='left')
        self._pv_title = tk.Label(pbar, text='', anchor='w', font=('', 9, 'bold'))
        self._pv_title.pack(side='left', fill='x', expand=True, padx=(8, 0))
        self._pv = tk.Text(pf, wrap='word', bd=0, padx=8, pady=6, state='disabled',
                           bg=_C('bg', '#FFFFFF'), fg=_C('fg', '#2C3E50'))
        psb = ttk.Scrollbar(pf, command=self._pv.yview)
        self._pv.configure(yscrollcommand=psb.set)
        psb.pack(side='right', fill='y')
        self._pv.pack(side='left', fill='both', expand=True)
        try:
            import theme_font
            theme_font.register(self._pv, self.db_path, 'prose')
        except Exception:
            pass
        self._pv_hit = None
        self.after(150, self._load_prefs)
        self.after(300, lambda: self._reflow(force=True))
        self._poll()

    def _reflow(self, ev=None, force=False):
        """체크칸을 폭에 맞춰 접는다 — 1~2줄(사용자 지정)."""
        w = self._cond.winfo_width()
        if w <= 1 or (not force and abs(w - self._reflow_w) < 20):
            return
        self._reflow_w = w
        for f in self._rows_f:
            f.destroy()
        self._rows_f = []
        line = 0
        row = None
        for cb in self._boxes:
            need = cb.winfo_reqwidth() or 120
            if row is None or (line and line + need > w):
                row = tk.Frame(self._cond)
                row.pack(fill='x', anchor='w')
                self._rows_f.append(row)
                line = 0
            cb.pack(in_=row, side='left', anchor='w')
            line += need

    # ── 직전값 ──────────────────────────────────────────────────────────
    def _cfg(self, key, val=None):
        try:
            with appdb.connect(self.db_path) as c:
                if val is None:
                    r = c.execute("SELECT config_val FROM user_config "
                                  "WHERE config_key=?", (key,)).fetchone()
                    return r[0] if r else None
                c.execute("INSERT OR REPLACE INTO user_config"
                          "(config_key, config_val) VALUES(?,?)", (key, str(val)))
                c.commit()
        except Exception:
            pass
        return None

    def _load_prefs(self):
        # ⚠ 언어 목록은 이제 `LangCombo` 가 맡는다 — 직접 만들었다가
        #   `ui_langs()` 를 튜플로 잘못 풀어 한 글자만 떴다(문서에 적힌 함정).
        # ⚠ **`bible_version` 에는 `record_status` 칼럼이 없다** — 그걸 쓴 SQL 이
        #   터져 except 폴백으로 역본이 하나만 떴다(사용자 신고). 21개다.
        try:
            with appdb.connect(self.db_path) as c:
                vs = [r[0] for r in c.execute(
                    "SELECT version_code FROM bible_version ORDER BY version_code")]
            self._ver_cb['values'] = vs or [self.ver_getter()]
            saved = self._cfg('SEARCH_VER_CODE')
            self._ver.set(saved if saved in (vs or []) else
                          (self.ver_getter() or (vs[0] if vs else 'KRV')))
        except Exception as e:
            print('[search_view ver] %s' % e)
            self._ver_cb['values'] = [self.ver_getter()]
        off = set((self._cfg('SEARCH_BUCKET_OFF') or '').split(','))
        for bk, v in self._on.items():
            v.set(0 if bk in off else 1)
        self._pref_sig = self._sig()

    def _cur_lang(self):
        """지금 선택한 언어 코드 — 표준 부품이 `(변형, 언어)` 를 준다."""
        try:
            cur = self._lang_combo.current()
            if cur and cur[1]:
                return cur[1]
        except Exception:
            pass
        return (self.lang_getter() or 'KO')

    def _on_ver_change(self, _e=None):
        self._cfg('SEARCH_VER_CODE', self._ver.get())
        self._run_now()

    def _sig(self):
        return ','.join(bk for bk, v in self._on.items() if not v.get())

    def _save_prefs(self):
        """조건이 **바뀌었을 때만** 쓴다 — `_run_now` 는 타자에서도 불린다.
        매번 DB 에 쓰면 그 자리에서 70ms 가 막혔다(실측 → 12ms)."""
        sig = self._sig()
        if sig == self._pref_sig:
            return
        self._pref_sig = sig
        self._cfg('SEARCH_BUCKET_OFF', sig)

    # ── 밖에서 열기 ─────────────────────────────────────────────────────
    def focus_search(self, q=None):
        if q:
            self._q.set(q)
        self._entry.focus_set()
        self._entry.select_range(0, 'end')
        if q:
            self._run_now()

    # ── 찾기 ────────────────────────────────────────────────────────────
    def _on_type(self, _e=None):
        if self._job:
            try:
                self.after_cancel(self._job)
            except Exception:
                pass
        self._cancel_running()
        self._job = self.after(DEBOUNCE_MS, self._run_now)

    def _cancel_running(self):
        c = self._worker_conn
        if c is not None:
            try:
                c.interrupt()
            except Exception:
                pass

    def _run_now(self):
        if self._job:
            try:
                self.after_cancel(self._job)
            except Exception:
                pass
            self._job = None
        self._save_prefs()
        self._cancel_running()
        q = search.normalize(self._q.get())
        self._gen += 1
        gen = self._gen
        self._hits.clear()
        self._limits.clear()
        self._ref = None
        self._gtv.delete(*self._gtv.get_children())
        self._rtv.delete(*self._rtv.get_children())
        self._head.config(text='')
        self._hint.pack_forget()
        self._more.pack_forget()
        self._pv_hit = None
        self._set_preview(None)
        if not q:
            if (self._q.get() or '').strip():
                self._head.config(text=i18n.t('SEARCH_MIN',
                                              '두 글자 이상 입력하세요.'))
            return
        on = [bk for bk, v in self._on.items() if v.get()]
        want = [g for g in search.groups() if search.GROUP_BUCKET[g] in on]
        self._head.config(text=i18n.t('SEARCH_RUNNING', '찾는 중…'))
        # ⚠ `StringVar.get()` 도 Tk 호출이다 — 일하는 실에 **글자로 떠서** 넘긴다
        ctx = {'lang': self._cur_lang(), 'ver': self._ver.get()}
        threading.Thread(target=self._work, args=(gen, q, want, ctx),
                         daemon=True).start()

    def _work(self, gen, q, want, ctx):
        """일하는 실 — 여기서는 Tk 를 한 번도 만지지 않는다."""
        conn = None
        try:
            conn = appdb.connect(self.db_path)
            self._worker_conn = conn
            ref = search.verse_ref_of(conn, q)
            if ref:
                self._post(gen, '__REF__', ref)
            for gk in want:
                if gen != self._gen:
                    return
                self._post(gen, gk, search.find_group(conn, gk, q, ctx, PAGE))
        except Exception as e:
            # ⚠⚠ **데몬 실에서 `print` 를 쓰지 않는다**(§193차 ⑧) — 이 앱은
            #   실행 중 `sys.stdout` 을 닫으므로(§97차) 종료할 때 이 줄이
            #   `ValueError: I/O operation on closed file` 로 터진다.
            try:
                import sys as _s
                _s.stderr.write('[search_view] %s\n' % e)
            except Exception:
                pass
        finally:
            self._worker_conn = None
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass
            self._post(gen, '__DONE__', None)

    def _post(self, gen, key, payload):
        """일하는 실 → 화면 실. **큐로만** 건넨다(`after` 를 부르면 죽는다)."""
        self._out.put((gen, key, payload))

    def _poll(self):
        try:
            while True:
                gen, key, payload = self._out.get_nowait()
                self._apply(gen, key, payload)
        except queue.Empty:
            pass
        except Exception as e:
            print('[search_view poll] %s' % e)
        finally:
            self._poll_job = self.after(60, self._poll)

    # ── 결과 붙이기 ─────────────────────────────────────────────────────
    def _apply(self, gen, key, payload):
        if gen != self._gen:
            return
        if key == '__DONE__':
            self._done()
            return
        if key == '__REF__':
            self._ref = payload
            self._gtv.insert('', 0, iid='__REF__',
                             text='▶ ' + i18n.t('SEARCH_GO', '이동'), values=('',))
            if not self._gtv.selection():
                self._gtv.selection_set('__REF__')
            return
        if not payload:
            return
        self._hits[key] = payload
        self._limits[key] = PAGE
        self._gtv.insert('', 'end', iid=key, text=search.label(key),
                         values=('%d%s' % (len(payload),
                                           '+' if payload.more else ''),))
        if not self._gtv.selection():
            self._gtv.selection_set(key)

    def _done(self):
        if self._gtv.get_children():
            if self._head.cget('text') == i18n.t('SEARCH_RUNNING', '찾는 중…'):
                self._head.config(text='')
            return
        # ★ **0건일 때 다음 수를 권한다** — 꺼 둔 묶음이 있으면 그것부터.
        off = [bk for bk, v in self._on.items() if not v.get()]
        if off:
            names = ' · '.join(search.bucket_label(b, with_sub=False) for b in off)
            self._hint_lb.config(
                text=i18n.t('SEARCH_TRY_OFF',
                            "찾은 것이 없습니다. 꺼 둔 곳({names})도 찾아볼까요?"
                            ).format(names=names),
                bg=_C('accent_bg', '#EAF2F8'), fg=_C('accent', '#1A5276'))
            self._hint.configure(bg=_C('accent_bg', '#EAF2F8'))
            self._hint_btn.config(text=i18n.t('SEARCH_TRY_GO', '여기도 찾기'))
            self._hint.pack(fill='x', padx=6, pady=(0, 3), before=self._pw)
            self._head.config(text='')
        else:
            self._head.config(text=i18n.t('SEARCH_NONE', '찾은 것이 없습니다.'))

    def _hint_go(self):
        for v in self._on.values():
            v.set(1)
        self._run_now()

    def _show_group(self):
        sel = self._gtv.selection()
        self._rtv.delete(*self._rtv.get_children())
        self._more.pack_forget()
        if not sel:
            return
        gk = sel[0]
        if gk == '__REF__':
            self._head.config(text=i18n.t('SEARCH_GO_HINT',
                                          '누르면 그 구절로 갑니다.'))
            self._rtv.insert('', 'end', iid='ref',
                             values=(self._q.get().strip(), ''))
            return
        h = self._hits.get(gk) or []
        self._head.config(text='%s — %d%s' % (
            search.label(gk), len(h), '+' if getattr(h, 'more', False) else ''))
        for i, x in enumerate(h):
            self._rtv.insert('', 'end', iid='r%d' % i,
                             values=(x['title'], x['snippet'] or x['sub']))
        if getattr(h, 'more', False):
            self._more.pack(side='left', pady=(2, 0), padx=(0, 2), before=self._head)

    def _load_more(self):
        sel = self._gtv.selection()
        if not sel or sel[0] == '__REF__':
            return
        gk = sel[0]
        lim = self._limits.get(gk, PAGE) + PAGE
        self._limits[gk] = lim
        try:
            with appdb.connect(self.db_path) as conn:
                h = search.find_group(conn, gk, search.normalize(self._q.get()),
                                      {'lang': self._cur_lang(),
                                       'ver': self._ver.get()}, lim)
        except Exception as e:
            print('[search_view more] %s' % e)
            return
        self._hits[gk] = h
        self._gtv.item(gk, values=('%d%s' % (len(h), '+' if h.more else ''),))
        self._show_group()

    def _picked(self):
        """지금 선택한 줄 → hit dict (없으면 None)."""
        sel = self._rtv.selection()
        gsel = self._gtv.selection()
        if not sel or not gsel:
            return None
        if gsel[0] == '__REF__':
            return {'kind': 'VERSE', 'id': self._ref[0], 'sub': self._ver.get(),
                    'title': self._q.get().strip()} if self._ref else None
        h = self._hits.get(gsel[0]) or []
        try:
            return h[int(sel[0][1:])]
        except Exception:
            return None

    def _on_click_row(self, _e=None):
        """한 번 누름 = 오른쪽 미리보기(2026-09-16 · 8-4)."""
        x = self._picked()
        self._pv_hit = x
        self._set_preview(x)

    def _on_go(self, _e=None):
        """두 번 누름 · [이동] = 그 화면으로."""
        x = self._picked() or self._pv_hit
        if x and callable(self.on_jump):
            self.on_jump(x['kind'], x['id'])
        return 'break'

    def _set_preview(self, x):
        txt = ''
        title = ''
        if x:
            title = '%s%s' % (x.get('title') or '', (' · ' + str(x['sub'])) if x.get('sub') else '')
            try:
                with appdb.connect(self.db_path) as conn:
                    txt = search.preview(conn, x, self._cur_lang(), self._ver.get())
            except Exception as e:
                print('[search preview] %s' % e)
        if x and not txt:
            txt = i18n.t('SEARCH_NO_PREVIEW', '미리보기할 본문이 없습니다 — [이동]으로 그 화면에서 보세요.')
        try:
            self._pv_title.config(text=title)
            self._pv.config(state='normal')
            self._pv.delete('1.0', 'end')
            self._pv.insert('end', txt)
            self._pv.config(state='disabled')
        except Exception:
            pass

    def apply_font(self):
        try:
            import theme_font
            theme_font.list_style('Search.Treeview', self.db_path)
            self._gtv.configure(style='Search.Treeview')
            self._rtv.configure(style='Search.Treeview')
        except Exception:
            pass
