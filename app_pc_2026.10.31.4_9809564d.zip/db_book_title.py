# -*- coding: utf-8 -*-
"""db_book_title.py — 도서 유닛 제목 다국어 덮개 (영구 도구 · `--selftest` 의무)
================================================================================

**원제(`sys_book_unit.unit_label`)는 한 글자도 안 건드린다.** 표시용 덮개만
`sys_text_asset(text_type='BOOK_UNIT_LABEL')` 에 얹는다. 화면이 이미
`COALESCE(ta.contents, bu.unit_label)` 로 읽으므로 **목록·본문 머리·노트 라벨이
함께** 바뀐다(`p1_reading_view` 1235·1321·1805 행).

★ 이 도구는 **책을 가리지 않는다** — `--book <BOOK_CODE>` 로 고른다.
  마이어 전용 `db_meyer_title.py` 가 먼저 있었고 그 얼개를 그대로 물려받았다.
  ⏭ 마이어 초안도 이 도구로 읽히므로(`_LEGACY_DRAFT`) **옛 도구는 정리 대상**이다
     (할일목록 — 같은 일을 하는 코드를 두 벌 두면 반드시 갈라진다).

초안 = `_title_prep/<BOOK_CODE>.json`
    {"titles": {"1": {"ko": "…", "en": "…"}, …}}   ← 열쇠는 `sequence`

사용법
    python db_book_title.py --selftest                 (의무)
    python db_book_title.py --check KEMPIS_IOC
    python db_book_title.py --apply KEMPIS_IOC         (멱등)
    python db_book_title.py --list  KEMPIS_IOC KO 20

⚠ **「원제와 글자가 같음」은 차단하지 않는다**(마이어에서 배운 것) — 원제가 이미
  깨끗한 현대 영어인 자리가 있고, 억지로 바꾸면 원제보다 나빠진다. 알리기만 한다.
⚠ **잘린 원제를 덮개가 고칠 수 있다.** 켐피스 58·96·114·116편은 적재 당시
  제목 뒷부분이 본문 첫 줄로 흘러들어 `unit_label` 이 「…after the example of」
  처럼 끊겨 있다. 덮개에는 **온전한 제목**을 넣는다 — 원문은 그대로 두고
  보이는 것만 고치는 것이라 되돌리기도 쉽다.
"""
import io
import json
import os
import re
import sys

try:
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:
    pass

import appdb

HERE = os.path.dirname(os.path.abspath(__file__))
DRAFT_DIR = os.path.join(HERE, '_title_prep')
TEXT_TYPE = 'BOOK_UNIT_LABEL'

# 먼저 만든 도구의 초안 자리 — 옮기지 않고 그대로 읽는다
_LEGACY_DRAFT = {'MEYER_ODH': os.path.join(HERE, '_meyer_prep', 'titles.json')}

LANGS = ('KO', 'EN')
MAXLEN = {'KO': 40, 'EN': 70}

# OCR 잔재 — 낱말 안에 숫자·^·/ 가 섞인 것
_OCR = re.compile(r'[A-Za-z]+[0-9^/][A-Za-z]*|[A-Za-z]*[0-9^/][A-Za-z]+|[\^]')
_HANGUL = re.compile(r'[가-힣]')
_BAD_CHARS = re.compile(r'[\r\n\t—]')          # 줄바꿈·탭·엠대시

# 차단하지 않고 알리기만 하는 것
WARN_ONLY = ('원제와 글자가 같음',)


# ───────────────────────────── 조회

def book_id(conn, code):
    r = conn.execute("SELECT book_id FROM sys_book_asset WHERE book_code=?",
                     (code,)).fetchone()
    if not r:
        raise SystemExit('도서 %s 가 없습니다.' % code)
    return r[0]


def units(conn, code):
    """{sequence: (unit_id, unit_label)} — LIVE 만."""
    bid = book_id(conn, code)
    return {r[0]: (r[1], r[2]) for r in conn.execute(
        "SELECT sequence, unit_id, unit_label FROM sys_book_unit "
        "WHERE book_id=? AND COALESCE(record_status,'LIVE')='LIVE'", (bid,))}


def draft_path(code):
    p = os.path.join(DRAFT_DIR, '%s.json' % code)
    if os.path.exists(p):
        return p
    return _LEGACY_DRAFT.get(code, p)


def load_draft(code):
    path = draft_path(code)
    if not os.path.exists(path):
        raise SystemExit('초안이 없습니다: %s' % path)
    with open(path, encoding='utf-8') as f:
        d = json.load(f)
    return {int(k): v for k, v in (d.get('titles') or d).items()}


# ───────────────────────────── 게이트

def check_one(seq, lang, text, en_orig=''):
    """한 제목을 잰다 → 문제 목록(빈 목록이면 통과)."""
    bad = []
    t = (text or '').strip()
    if not t:
        return ['빈 제목']
    if _BAD_CHARS.search(text or ''):
        bad.append('줄바꿈·탭·엠대시')
    if len(t) > MAXLEN[lang]:
        bad.append('%d자 (상한 %d)' % (len(t), MAXLEN[lang]))
    if _OCR.search(t):
        bad.append('OCR 잔재')
    if lang == 'KO' and not _HANGUL.search(t):
        bad.append('한글이 없음')
    if lang == 'EN' and _HANGUL.search(t):
        bad.append('한글이 섞임')
    if lang == 'EN' and t == (en_orig or '').strip():
        bad.append('원제와 글자가 같음')
    return bad


def check(conn, code, draft=None, verbose=True):
    draft = draft if draft is not None else load_draft(code)
    u = units(conn, code)
    problems, warns = [], []
    missing = [s for s in sorted(u) if s not in draft]
    extra = [s for s in sorted(draft) if s not in u]
    for s in sorted(draft):
        if s not in u:
            continue
        en_orig = u[s][1] or ''
        for lang in LANGS:
            key = lang.lower()
            if key not in draft[s]:
                problems.append((s, lang, '없음'))
                continue
            for b in check_one(s, lang, draft[s][key], en_orig):
                (warns if b in WARN_ONLY else problems).append((s, lang, b))
    if verbose:
        print('%s — 유닛 %d · 초안 %d' % (code, len(u), len(draft)))
        print('  초안에 없는 유닛 %d · 유닛에 없는 초안 %d' % (len(missing), len(extra)))
        if missing[:10]:
            print('   빠진 것 앞 10: %s' % missing[:10])
        if extra[:10]:
            print('   남는 것 앞 10: %s' % extra[:10])
        print('  게이트 위반 %d건' % len(problems))
        for s, lang, b in problems[:30]:
            print('   #%-5d %s  %s' % (s, lang, b))
        if len(problems) > 30:
            print('   … 외 %d건' % (len(problems) - 30))
        print('  경고 %d건 (원제가 이미 현대 영어 — 그대로 둔다)' % len(warns))
        for s, lang, b in warns[:10]:
            print('   #%-5d %s  %s' % (s, lang, b))
    return missing, extra, problems


# ───────────────────────────── 적재

def apply(conn, code, draft=None, dry=False):
    draft = draft if draft is not None else load_draft(code)
    u = units(conn, code)
    ins = upd = same = 0
    for s in sorted(draft):
        if s not in u:
            continue
        uid = u[s][0]
        for lang in LANGS:
            txt = (draft[s].get(lang.lower()) or '').strip()
            if not txt:
                continue
            row = conn.execute(
                "SELECT sys_text_id, contents FROM sys_text_asset "
                "WHERE text_type=? AND clicked_id=? AND lang_code=?",
                (TEXT_TYPE, uid, lang)).fetchone()
            if row is None:
                if not dry:
                    conn.execute(
                        "INSERT INTO sys_text_asset "
                        "(clicked_id, text_type, title, contents, lang_code, record_status) "
                        "VALUES (?,?,?,?,?,'LIVE')",
                        (uid, TEXT_TYPE, 'UL_%d' % uid, txt, lang))
                ins += 1
            elif (row[1] or '') != txt:
                if not dry:
                    conn.execute(
                        "UPDATE sys_text_asset SET contents=?, record_status='LIVE' "
                        "WHERE sys_text_id=?", (txt, row[0]))
                upd += 1
            else:
                if not dry:
                    conn.execute(
                        "UPDATE sys_text_asset SET record_status='LIVE' "
                        "WHERE sys_text_id=?", (row[0],))
                same += 1
    if not dry:
        conn.commit()
    print('%s 새로 %d · 고침 %d · 그대로 %d' % ('[모의]' if dry else '[적재]',
                                            ins, upd, same))
    return ins, upd, same


def show(conn, code, lang='KO', n=20):
    bid = book_id(conn, code)
    rows = conn.execute(
        "SELECT u.sequence, u.unit_label, ta.contents "
        "FROM sys_book_unit u LEFT JOIN sys_text_asset ta "
        "  ON ta.text_type=? AND ta.clicked_id=u.unit_id AND ta.lang_code=? "
        " AND COALESCE(ta.record_status,'LIVE')='LIVE' "
        "WHERE u.book_id=? AND COALESCE(u.record_status,'LIVE')='LIVE' "
        "ORDER BY u.sequence LIMIT ?", (TEXT_TYPE, lang, bid, n)).fetchall()
    for s, orig, tr in rows:
        print('#%-5d %-58s | %s' % (s, (orig or '')[:58], tr or '(없음)'))
    got = conn.execute(
        "SELECT COUNT(*) FROM sys_book_unit u JOIN sys_text_asset ta "
        "  ON ta.text_type=? AND ta.clicked_id=u.unit_id AND ta.lang_code=? "
        " AND COALESCE(ta.record_status,'LIVE')='LIVE' "
        "WHERE u.book_id=? AND COALESCE(u.record_status,'LIVE')='LIVE'",
        (TEXT_TYPE, lang, bid)).fetchone()[0]
    tot = conn.execute(
        "SELECT COUNT(*) FROM sys_book_unit WHERE book_id=? "
        "AND COALESCE(record_status,'LIVE')='LIVE'", (bid,)).fetchone()[0]
    print('%s 보유 %d / %d' % (lang, got, tot))


# ───────────────────────────── 자가 검증

def selftest():
    ok = fail = 0

    def t(name, cond):
        nonlocal ok, fail
        if cond:
            ok += 1
        else:
            fail += 1
            print('  FAIL %s' % name)

    t('빈 제목', check_one(1, 'KO', '') == ['빈 제목'])
    t('공백뿐', check_one(1, 'KO', '   ') == ['빈 제목'])
    t('줄바꿈', '줄바꿈·탭·엠대시' in check_one(1, 'KO', '진리를\n아는 것'))
    t('엠대시', '줄바꿈·탭·엠대시' in check_one(1, 'KO', '진리 — 아는 것'))
    t('KO 길이', any('상한' in b for b in check_one(1, 'KO', '가' * 41)))
    t('KO 41자는 걸리고 40자는 통과', not check_one(1, 'KO', '가' * 40))
    t('EN 길이', any('상한' in b for b in check_one(1, 'EN', 'a' * 71)))
    t('KO 에 한글 없음', '한글이 없음' in check_one(1, 'KO', 'Truth'))
    t('EN 에 한글 섞임', '한글이 섞임' in check_one(1, 'EN', 'Truth 진리'))
    t('OCR 잔재', 'OCR 잔재' in check_one(1, 'EN', 'Of the kn0wledge'))
    t('원제와 같음은 경고', check_one(1, 'EN', 'Same', 'Same') == ['원제와 글자가 같음'])
    t('경고는 차단 목록에 있다', '원제와 글자가 같음' in WARN_ONLY)
    t('정상 KO 통과', not check_one(1, 'KO', '진리를 아는 것'))
    t('정상 EN 통과', not check_one(1, 'EN', 'The Knowledge of Truth', 'Of the knowledge of truth'))

    conn = appdb.connect('bible_master.db')
    try:
        # ★ **먼저 만든 마이어 도구와 같은 결과를 내는가** — 두 벌이 갈라지지
        #   않았음을 여기서 증명한다. 이미 적재돼 있으므로 **전부 「그대로」**여야
        #   하고, 새로 쓰거나 고치는 것이 하나라도 있으면 갈라진 것이다.
        if os.path.exists(draft_path('MEYER_ODH')):
            d = load_draft('MEYER_ODH')
            i, up, sm = apply(conn, 'MEYER_ODH', d, dry=True)
            t('마이어 초안 1,189편', len(d) == 1189)
            t('마이어와 같은 결과 (새로 0)', i == 0)
            t('마이어와 같은 결과 (고침 0)', up == 0)
            t('마이어 그대로 2,378', sm == 2378)

        # 적재·되돌리기 — 실 DB 에 넣었다 **원래대로** 돌려놓는다
        # ⚠ 「비어 있다」를 전제로 삼지 않는다(§0-5) — 찍어 두고 그대로 되살린다.
        code = 'KEMPIS_IOC'
        u = units(conn, code)
        t('켐피스 118편', len(u) == 118)
        uid = u[4][0]
        SNAP = ("SELECT sys_text_id, lang_code, contents, record_status "
                "FROM sys_text_asset WHERE text_type=? AND clicked_id=? "
                "ORDER BY sys_text_id")
        before = conn.execute(SNAP, (TEXT_TYPE, uid)).fetchall()
        d = {4: {'ko': '자가검증 임시', 'en': 'Selftest Temp'}}
        apply(conn, code, d, dry=True)
        t('모의는 안 쓴다', conn.execute(
            "SELECT COUNT(*) FROM sys_text_asset WHERE clicked_id=? "
            "AND contents='자가검증 임시'", (uid,)).fetchone()[0] == 0)
        apply(conn, code, d)
        t('적재됨', conn.execute(
            "SELECT COUNT(*) FROM sys_text_asset WHERE clicked_id=? AND "
            "contents IN ('자가검증 임시','Selftest Temp')", (uid,)).fetchone()[0] == 2)
        t('멱등', apply(conn, code, d) == (0, 0, 2))
        conn.execute("DELETE FROM sys_text_asset WHERE text_type=? AND clicked_id=?",
                     (TEXT_TYPE, uid))
        for r in before:
            conn.execute(
                "INSERT INTO sys_text_asset (sys_text_id, clicked_id, text_type, "
                " title, contents, lang_code, record_status) VALUES (?,?,?,?,?,?,?)",
                (r[0], uid, TEXT_TYPE, 'UL_%d' % uid, r[2], r[1], r[3]))
        conn.commit()
        t('시험 글 0', conn.execute(
            "SELECT COUNT(*) FROM sys_text_asset WHERE contents IN "
            "('자가검증 임시','Selftest Temp')").fetchone()[0] == 0)
        t('원래대로 되돌림', conn.execute(SNAP, (TEXT_TYPE, uid)).fetchall() == before)
    finally:
        conn.close()

    print('selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main():
    a = sys.argv[1:]
    if not a or a[0] == '--selftest':
        sys.exit(0 if selftest() else 1)
    cmd = a[0]
    code = a[1] if len(a) > 1 else ''
    if not code:
        raise SystemExit('도서 코드를 주십시오. 예: --check KEMPIS_IOC')
    conn = appdb.connect('bible_master.db')
    try:
        if cmd == '--check':
            _m, _e, p = check(conn, code)
            sys.exit(1 if p else 0)
        elif cmd == '--apply':
            _m, _e, p = check(conn, code)
            if p:
                raise SystemExit('게이트를 통과하지 못했습니다 — 적재하지 않습니다.')
            apply(conn, code)
        elif cmd == '--list':
            show(conn, code, (a[2] if len(a) > 2 else 'KO'),
                 int(a[3]) if len(a) > 3 else 20)
        else:
            print(__doc__)
    finally:
        conn.close()


if __name__ == '__main__':
    main()
