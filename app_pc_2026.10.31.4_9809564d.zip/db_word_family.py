# -*- coding: utf-8 -*-
"""낱말 가족 — 같은 뿌리에서 갈라진 낱말들 (영구 도구)

2026-09-07 신설. 1.txt 제안 B(어근 패밀리 트리) + 사용자 「A → C → B → D」.

★★★ **가장 값진 것은 「그 낱말을 이름으로 지닌 사람」이다**(실측):
      카보드(영광) → **요게벳**「여호와는 영광」(모세의 어머니) ·
                     **이가봇**「영광이 떠났다」(삼상4:21)
      헤세드(인애) → **하사댜**「여호와의 인애」
      토브(좋다)   → **다브엘**「하나님은 선하시다」 · **도비야**
  ⇒ **A(이름에 담긴 고백)와 한 몸이다.** 낱말이 사람의 이름으로 살아 있고,
    그 이름을 받은 사람의 삶이 그 뜻과 어긋나기도 한다(이가봇).

★ **재료는 `sys_lemma_master.deriv`** — `db_name_meaning.parse` 를 그대로
  쓴다. **파서를 두 벌 만들지 않는다.**

⚠ **헬라어는 가족이 거의 없다**(실측 헬라 앵커 가족 0) — 헬라 어원이
  「of Hebrew origin」 꼴이라 번호 참조가 적다. 히브리 앵커 82/146 이 가족을
  가진다. **그 사실을 화면이 숨기지 않는다** — 없으면 안 그린다.

⚠ **뿌리를 지나 형제까지만** 본다(부모의 다른 자식). 두 단계를 가면
  「엘(H410)」 같은 큰 뿌리에서 147개가 쏟아진다.
"""
from __future__ import annotations

import sys

try:
    import appdb
except Exception:                                        # pragma: no cover
    appdb = None

import db_name_meaning as NM

#: 한 낱말에 보일 가족 상한 — 넘으면 자른다.
#: ⚠ 「엘」·「야」는 자식이 134~147개다. 다 보이면 목록이 아니라 벽이 된다.
MAX_FAMILY = 12


def _graph(conn):
    """`(자식맵, 부모맵, 낱말정보)` — 한 번 읽어 재사용한다."""
    info = {}
    for r in conn.execute(
            "SELECT strong, lang_code, translit, pos, gloss, deriv, occurrences "
            "FROM sys_lemma_master"):
        info[r[0]] = {'strong': r[0], 'lang': r[1], 'translit': r[2],
                      'pos': r[3], 'gloss': r[4], 'deriv': r[5], 'occ': r[6]}
    kids, par = {}, {}
    for st, d in info.items():
        dv = d.get('deriv')
        if not dv:
            continue
        pre = 'H' if st.startswith('H') else 'G'
        for num in NM.parse(dv)['parents']:
            pp = '%s%d' % (pre, num)
            if pp in info and pp != st:
                kids.setdefault(pp, set()).add(st)
                par.setdefault(st, set()).add(pp)
    return kids, par, info


def is_name(row):
    """고유명사인가 — 인명·지명은 따로 묶어 보인다."""
    return (row.get('pos') or '').startswith('n-pr')


def family(conn, strong, graph=None):
    """그 낱말의 가족 → `{'root':…, 'words':[…], 'names':[…]}`.

    · `root`  — 뿌리 낱말(부모가 하나뿐일 때만)
    · `words` — 보통 낱말 형제·자식
    · `names` — **인명·지명** 형제·자식 ← 이것이 이 화면의 값이다
    ⚠ 자기 자신은 뺀다. 출현 수가 많은 것부터.
    """
    kids, par, info = graph or _graph(conn)
    if strong not in info:
        return {'root': None, 'words': [], 'names': []}
    fam = set(kids.get(strong, ()))
    ps = par.get(strong, set())
    root = None
    if len(ps) == 1:
        root = next(iter(ps))
        fam |= set(kids.get(root, ()))
    fam.discard(strong)
    rows = [info[f] for f in fam if f in info]
    rows.sort(key=lambda r: (-(r.get('occ') or 0), r['strong']))
    words = [r for r in rows if not is_name(r)][:MAX_FAMILY]
    names = [r for r in rows if is_name(r)][:MAX_FAMILY]
    return {'root': (info.get(root) if root else None),
            'words': words, 'names': names}


def family_of_entity(conn, eid, graph=None):
    """용어의 모든 앵커를 합친 가족(중복 없음).

    ⚠ 앵커가 여럿이면(히브리+헬라) 각각의 가족을 합친다. 헬라 쪽은 대개 비어
      있어 실제로는 히브리 가족 하나가 된다.
    """
    g = graph or _graph(conn)
    seen, words, names, roots = set(), [], [], []
    for (st,) in conn.execute(
            "SELECT strong FROM sys_entity_lemma WHERE entity_id=? "
            "ORDER BY sort_order", (eid,)):
        f = family(conn, st, g)
        if f['root'] and f['root']['strong'] not in seen:
            seen.add(f['root']['strong'])
            roots.append(f['root'])
        for key, dst in (('words', words), ('names', names)):
            for r in f[key]:
                if r['strong'] not in seen:
                    seen.add(r['strong'])
                    dst.append(r)
    return {'roots': roots, 'words': words[:MAX_FAMILY],
            'names': names[:MAX_FAMILY]}


def entity_of_strong(conn):
    """Strong 번호 → 우리 엔티티 — 가족 중 **누를 수 있는 것**을 가른다.

    ★ `name_strong`(A 단계에서 담은 것)과 `sys_entity_lemma` 를 함께 본다.
      전자는 인명·지명, 후자는 용어다.
    """
    out = {}
    try:
        for eid, st in conn.execute(
                "SELECT entity_id, strong FROM sys_entity_lemma"):
            out.setdefault(st, eid)
    except Exception:
        pass
    try:
        for eid, jd in conn.execute(
                "SELECT entity_id, json_detail FROM sys_entity_master "
                "WHERE json_detail LIKE '%name_strong%'"):
            import json
            try:
                st = (json.loads(jd or '{}') or {}).get('name_strong')
            except Exception:
                st = None
            if st:
                out.setdefault(st, eid)
    except Exception:
        pass
    return out


def label(row, lang='KO'):
    """가족 한 줄의 이름 — `음역 (짧은 뜻)`.

    ⚠ **뜻은 첫 절만** — 뜻풀이가 길어 그대로 쓰면 줄이 벽이 된다.
    """
    tr = (row.get('translit') or row.get('strong') or '').strip()
    # ⚠ **고유명사는 뜻풀이를 안 쓴다** — 그것은 뜻이 아니라 「누구인가」다
    #   (`Jochebed, the mother of Moses`). 이름의 뜻은 A 단계
    #   (`db_name_meaning`)가 어원에서 따로 뽑는다.
    if is_name(row):
        return tr
    g = NM._gloss_meaning(row.get('gloss')) or ''
    return ('%s (%s)' % (tr, g[:24])) if g else tr


# ── selftest ───────────────────────────────────────────────────────────
def _selftest():
    import sqlite3
    ok, bad = [], []

    def chk(name, cond, extra=''):
        (ok if cond else bad).append(name + (('  ' + str(extra)) if extra else ''))

    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE sys_lemma_master(strong TEXT, lang_code TEXT, translit TEXT,
        pos TEXT, gloss TEXT, deriv TEXT, occurrences INTEGER);
      CREATE TABLE sys_entity_lemma(entity_id INTEGER, strong TEXT,
        sort_order INTEGER DEFAULT 0);
      CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY,
        json_detail TEXT);
    """)
    rows = [
        # 뿌리
        ('H3513', 'HE', 'kabad', 'v', 'to be heavy', 'a primitive root;', 100),
        # 그 자식들
        ('H3519', 'HE', 'kabowd', 'n-m', 'glory', 'from 3513;', 200),
        ('H3515', 'HE', 'kabed', 'a', 'heavy', 'from 3513;', 40),
        ('H3068', 'HE', 'Yhovah', 'n-pr', 'Jehovah', 'from 1961;', 6000),
        ('H3115', 'HE', 'Yowkebed', 'n-pr-f', 'Jochebed, the mother of Moses',
         'from 3068 and 3513;', 2),
        ('H350', 'HE', 'Iy-kabowd', 'n-pr-m', 'Ikabod, a son of Phinehas',
         'from 336 and 3519;', 2),
        # 딴 뿌리
        ('H157', 'HE', 'ahab', 'v', 'to have affection', 'a primitive root;', 200),
    ]
    for r in rows:
        c.execute("INSERT INTO sys_lemma_master VALUES (?,?,?,?,?,?,?)", r)
    c.execute("INSERT INTO sys_entity_lemma(entity_id,strong) VALUES (1,'H3519')")
    c.execute("INSERT INTO sys_entity_master VALUES (1,NULL)")
    c.commit()

    g = _graph(c)
    kids, par, info = g
    chk('어근 그래프 — 자식을 모은다',
        kids.get('H3513') == {'H3519', 'H3515', 'H3115'}, kids.get('H3513'))
    chk('  합성어는 부모가 둘', par.get('H3115') == {'H3068', 'H3513'},
        par.get('H3115'))

    f = family(c, 'H3519', g)
    chk('★ 뿌리를 찾는다', f['root'] and f['root']['strong'] == 'H3513',
        f['root'])
    chk('★ 형제 낱말을 낸다(카보드 ↔ 카베드)',
        'H3515' in [r['strong'] for r in f['words']],
        [r['strong'] for r in f['words']])
    chk('★★ **인명을 따로 묶는다**(요게벳·이가봇)',
        {r['strong'] for r in f['names']} == {'H3115', 'H350'},
        [r['strong'] for r in f['names']])
    chk('  자기 자신은 뺀다',
        'H3519' not in [r['strong'] for r in f['words'] + f['names']])
    chk('  딴 뿌리는 안 섞인다',
        'H157' not in [r['strong'] for r in f['words'] + f['names']])
    chk('  출현 수가 많은 것부터',
        [r['strong'] for r in f['words']][0] == 'H3515',
        [r['strong'] for r in f['words']])

    chk('  모르는 번호는 빈손',
        family(c, 'H9999', g)['words'] == [])

    fe = family_of_entity(c, 1, g)
    chk('★ 용어의 앵커로 가족을 찾는다',
        {r['strong'] for r in fe['names']} == {'H3115', 'H350'},
        [r['strong'] for r in fe['names']])
    chk('  뿌리도 함께', [r['strong'] for r in fe['roots']] == ['H3513'])

    # 부모가 여럿이면 뿌리를 안 정한다(합성어)
    f2 = family(c, 'H3115', g)
    chk('★ 부모가 여럿이면 뿌리 없음(합성어)', f2['root'] is None, f2['root'])

    es = entity_of_strong(c)
    chk('  엔티티 다리 — 용어 앵커', es.get('H3519') == 1, es)

    chk('★ 이름표는 「음역 (짧은 뜻)」',
        label(info['H3519']) == 'kabowd (glory)', label(info['H3519']))
    chk('  고유명사 뜻풀이는 뜻으로 안 쓴다',
        label(info['H3115']) == 'Yowkebed', label(info['H3115']))

    chk('★ 상한이 있다(「엘」은 자식이 147개다)', MAX_FAMILY == 12)

    print('db_word_family selftest: %d/%d' % (len(ok), len(ok) + len(bad)))
    for b in bad:
        print('  FAIL:', b)
    return 0 if not bad else 1


def main(argv):
    if '--selftest' in argv:
        return _selftest()
    c = appdb.connect('bible_master.db') if appdb else None
    if c is None:
        print('appdb 없음')
        return 1
    g = _graph(c)
    q = ("SELECT m.entity_id, m.entity_code, "
         " (SELECT contents FROM sys_text_asset WHERE text_type='ENTITY_NAME' "
         "   AND clicked_id=m.entity_id AND lang_code='KO' "
         "   AND record_status='LIVE' LIMIT 1) "
         "FROM sys_entity_master m WHERE m.entity_type='TERM' "
         " AND m.record_status='LIVE' "
         " AND COALESCE(json_extract(m.json_detail,'$.subtype'),'')<>'LEX'")
    n_w = n_n = 0
    for eid, code, nm in c.execute(q):
        f = family_of_entity(c, eid, g)
        if not (f['words'] or f['names']):
            continue
        n_w += bool(f['words'])
        n_n += bool(f['names'])
        if '-v' in argv:
            print('%-16s %-16s 낱말 %d · 이름 %d'
                  % (code, (nm or '')[:16], len(f['words']), len(f['names'])))
    print('가족 있는 용어 — 낱말 %d · 이름 %d' % (n_w, n_n))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
