# -*- coding: utf-8 -*-
"""ref_docx — 연구/설교노트 ↔ .docx (2026-10-07 317차-18 ③ · data.md Z-2v · 파이썬 표준만).

★ 「워드로 편집」(A 방식)의 두 문 — `write_docx` · `read_docx`.
  · .docx 는 zip 안의 XML 이다. 워드·한글·WPS·LibreOffice·MyOffice 가 다 읽고 쓴다(나라별 코드 0).
  · 우리 꼴 = 글 + 자리표 `[[T1]]` + 표 구조(ref_doc). 그 밖의 꾸밈(글꼴·색·굵기)은 **가져오지 않는다**.
★ 줄 하나 = 문단 하나(빈 줄도 빈 문단) — 그래야 엔터가 왕복해도 그대로다.
★ 제목 = 첫 문단(스타일 Title) · 문서 속성(dc:title)에도 적는다 — 되읽을 때 첫 문단이 Title 이면 제목으로.

읽을 때 받는 법(호환성 — 사용방법에 그대로 적는다):
  · 변경 추적 — **받아들인 결과**만(삭제 표시 글은 버리고 삽입 표시 글은 넣는다)
  · 자동 번호·글머리표 — 번호 글자를 지어 앞에 붙인다(1. / a) / A. / i. · 글머리표는 「- 」)
  · 칸 합치기 — 우리 표에 없다 → 합친 칸은 첫 칸에 글, 나머지는 빈칸(**경고**)
  · 표 안의 표 — 안쪽 표 글을 그 칸 글로 편다(**경고**)
  · 그림·도형·글상자·각주·머리글/바닥글 — 가져오지 않는다(**개수를 경고**)
  · 하이퍼링크 — 글만 남긴다
"""
import io
import re
import sys
import zipfile
from xml.etree import ElementTree as ET
from xml.sax.saxutils import escape

import ref_doc as RD

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS = {'w': W}


def _q(tag):
    return '{%s}%s' % (W, tag)


# ══════════════════════════════════════════════════════════════════
#  쓰기
# ══════════════════════════════════════════════════════════════════
_CT = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
       '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
       '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
       '<Default Extension="xml" ContentType="application/xml"/>'
       '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.'
       'wordprocessingml.document.main+xml"/>'
       '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.'
       'wordprocessingml.styles+xml"/>'
       '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.'
       'core-properties+xml"/></Types>')
_RELS = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
         '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
         '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/'
         'officeDocument" Target="word/document.xml"/>'
         '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/'
         'core-properties" Target="docProps/core.xml"/></Relationships>')
_DOC_RELS = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
             '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
             '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/'
             'styles" Target="styles.xml"/></Relationships>')
_STYLES = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           '<w:styles xmlns:w="%s">'
           '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/>'
           '<w:pPr><w:spacing w:after="0"/></w:pPr></w:style>'
           '<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/>'
           '<w:pPr><w:spacing w:after="200"/></w:pPr><w:rPr><w:b/><w:sz w:val="32"/></w:rPr></w:style>'
           '</w:styles>' % W)


def _core(title):
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties"'
            ' xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>%s</dc:title></cp:coreProperties>'
            % escape(title or ''))


def _p(text, style=None, bold=False):
    ppr = '<w:pPr><w:pStyle w:val="%s"/></w:pPr>' % style if style else ''
    rpr = '<w:rPr><w:b/></w:rPr>' if bold else ''
    if not text:
        return '<w:p>%s</w:p>' % ppr
    return '<w:p>%s<w:r>%s<w:t xml:space="preserve">%s</w:t></w:r></w:p>' % (ppr, rpr, escape(text))


def _tbl(t):
    cols = t['cols']
    out = ['<w:tbl><w:tblPr><w:tblW w:w="5000" w:type="pct"/><w:tblBorders>']
    for side in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        out.append('<w:%s w:val="single" w:sz="4" w:space="0" w:color="808080"/>' % side)
    out.append('</w:tblBorders><w:tblLayout w:type="autofit"/></w:tblPr><w:tblGrid>')
    out.append(''.join('<w:gridCol w:w="%d"/>' % (9000 // max(1, cols)) for _ in range(cols)))
    out.append('</w:tblGrid>')
    for i, r in enumerate(t['cells']):
        head = i < (t.get('head') or 0)
        out.append('<w:tr>' + ('<w:trPr><w:tblHeader/></w:trPr>' if head else ''))
        for v in r:
            out.append('<w:tc><w:tcPr><w:tcW w:w="0" w:type="auto"/></w:tcPr>')
            out.append(''.join(_p(x, bold=head) for x in ((v or '').split('\n') or [''])))
            out.append('</w:tc>')
        out.append('</w:tr>')
    out.append('</w:tbl>')
    return ''.join(out)


def write_docx(path, title, text, tables):
    """글 + 표 → .docx(문단 = 줄 하나 · 자리표 = 표)."""
    body = [_p(title or '', style='Title')]
    for line in (text or '').split('\n'):
        m = RD.TOKEN_RE.fullmatch(line.strip())
        t = (tables or {}).get(int(m.group(1))) if m else None
        if t:
            body.append(_tbl(t))
            body.append('<w:p/>') if False else None
        else:
            body.append(_p(line))
    doc = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           '<w:document xmlns:w="%s"><w:body>%s<w:sectPr><w:pgSz w:w="11906" w:h="16838"/>'
           '<w:pgMar w:top="1418" w:right="1418" w:bottom="1418" w:left="1418" w:header="851" w:footer="851"'
           ' w:gutter="0"/></w:sectPr></w:body></w:document>' % (W, ''.join(body)))
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', _CT)
        z.writestr('_rels/.rels', _RELS)
        z.writestr('word/_rels/document.xml.rels', _DOC_RELS)
        z.writestr('word/document.xml', doc)
        z.writestr('word/styles.xml', _STYLES)
        z.writestr('docProps/core.xml', _core(title))
    return path


# ══════════════════════════════════════════════════════════════════
#  읽기
# ══════════════════════════════════════════════════════════════════
_ROMAN = [(1000, 'm'), (900, 'cm'), (500, 'd'), (400, 'cd'), (100, 'c'), (90, 'xc'), (50, 'l'),
          (40, 'xl'), (10, 'x'), (9, 'ix'), (5, 'v'), (4, 'iv'), (1, 'i')]


def _roman(n):
    s = ''
    for v, r in _ROMAN:
        while n >= v:
            s += r
            n -= v
    return s


def _fmt_num(fmt, n):
    if fmt == 'decimal':
        return '%d. ' % n
    if fmt == 'lowerLetter':
        return '%s) ' % chr(ord('a') + (n - 1) % 26)
    if fmt == 'upperLetter':
        return '%s. ' % chr(ord('A') + (n - 1) % 26)
    if fmt == 'lowerRoman':
        return '%s. ' % _roman(n)
    if fmt == 'upperRoman':
        return '%s. ' % _roman(n).upper()
    if fmt in ('none', ''):
        return ''
    if fmt == 'bullet':
        return '- '
    return '%d. ' % n                                     # 그 밖의 꼴(한글 숫자 등)은 아라비아 숫자로


class _Reader:
    def __init__(self, z):
        self.warn = {}
        self.fmt = {}                                     # (numId, ilvl) → numFmt
        self.count = {}                                   # (numId, ilvl) → 지금 번호
        try:
            self._numbering(ET.fromstring(z.read('word/numbering.xml')))
        except Exception:                                 # noqa: BLE001
            pass

    def _w(self, key):
        self.warn[key] = self.warn.get(key, 0) + 1

    def _numbering(self, root):
        absf = {}
        for a in root.findall('w:abstractNum', NS):
            aid = a.get(_q('abstractNumId'))
            for lv in a.findall('w:lvl', NS):
                f = lv.find('w:numFmt', NS)
                absf[(aid, lv.get(_q('ilvl')))] = f.get(_q('val')) if f is not None else 'decimal'
        for n in root.findall('w:num', NS):
            nid = n.get(_q('numId'))
            a = n.find('w:abstractNumId', NS)
            aid = a.get(_q('val')) if a is not None else None
            for (x, lvl), f in absf.items():
                if x == aid:
                    self.fmt[(nid, lvl)] = f

    def runs_text(self, el):
        """문단 속 글 — 받아들인 결과(삭제 표시 글은 w:delText 라 저절로 빠진다)."""
        out = []
        for node in el.iter():
            tag = node.tag
            if tag == _q('t'):
                out.append(node.text or '')
            elif tag == _q('tab'):
                out.append('\t')
            elif tag in (_q('br'), _q('cr')):
                out.append('\n')
            elif tag == _q('drawing') or tag == _q('pict'):
                self._w('그림·도형')
            elif tag == _q('footnoteReference') or tag == _q('endnoteReference'):
                self._w('각주')
            elif tag == _q('txbxContent'):
                self._w('글상자')
        return ''.join(out)

    def para(self, p):
        # 글상자 안 글은 문단 글에서 빼낸다(가져오지 않는다)
        for tx in list(p.iter(_q('txbxContent'))):
            self._w('글상자')
            for ch in list(tx):
                tx.remove(ch)
        txt = self.runs_text(p)
        ppr = p.find('w:pPr', NS)
        num = ppr.find('w:numPr', NS) if ppr is not None else None
        if num is not None:
            nid = num.find('w:numId', NS)
            lvl = num.find('w:ilvl', NS)
            nid = nid.get(_q('val')) if nid is not None else '0'
            lvl = lvl.get(_q('val')) if lvl is not None else '0'
            if nid != '0':
                key = (nid, lvl)
                self.count[key] = self.count.get(key, 0) + 1
                for k in list(self.count):                # 아래 단계 번호는 다시 1부터
                    if k[0] == nid and int(k[1]) > int(lvl):
                        del self.count[k]
                txt = '   ' * int(lvl) + _fmt_num(self.fmt.get(key, 'decimal'), self.count[key]) + txt
        style = ppr.find('w:pStyle', NS) if ppr is not None else None
        return txt, (style.get(_q('val')) if style is not None else '')

    def cell_text(self, tc):
        lines = []
        for ch in tc:
            if ch.tag == _q('p'):
                lines.append(self.para(ch)[0])
            elif ch.tag == _q('tbl'):
                self._w('표 안의 표')
                t = self.table(ch)
                lines.extend(' / '.join(x for x in r if x) for r in t['cells'])
            elif ch.tag == _q('sdt'):
                c = ch.find('w:sdtContent', NS)
                if c is not None:
                    lines.append(self.cell_text(c))
        return '\n'.join(lines).strip('\n')

    def table(self, tbl):
        rows, head = [], 0
        for tr in tbl.findall('w:tr', NS):
            trpr = tr.find('w:trPr', NS)
            if trpr is not None and trpr.find('w:tblHeader', NS) is not None and len(rows) == head:
                head += 1
            r = []
            for tc in tr.findall('w:tc', NS):
                tcpr = tc.find('w:tcPr', NS)
                span, vcont = 1, False
                if tcpr is not None:
                    gs = tcpr.find('w:gridSpan', NS)
                    if gs is not None:
                        span = int(gs.get(_q('val')) or 1)
                    vm = tcpr.find('w:vMerge', NS)
                    if vm is not None and (vm.get(_q('val')) or 'continue') == 'continue':
                        vcont = True
                if span > 1 or vcont:
                    self._w('칸 합치기')
                r.append('' if vcont else self.cell_text(tc))
                r.extend([''] * (span - 1))
            rows.append(r)
        return RD.make(rows, head)

    def body(self, body):
        lines, tables, title = [], {}, ''
        first = True
        for el in body:
            if el.tag == _q('p'):
                txt, style = self.para(el)
                if first and style.lower() in ('title', '제목'):
                    title = txt.strip()
                else:
                    lines.append(txt)
                first = False
            elif el.tag == _q('tbl'):
                no = len(tables) + 1
                tables[no] = self.table(el)
                lines.append(RD.token(no))
                first = False
            elif el.tag == _q('sdt'):
                c = el.find('w:sdtContent', NS)
                if c is not None:
                    t2, l2, tb2 = self.body(c)
                    for k, t in tb2.items():
                        n = len(tables) + 1
                        tables[n] = t
                        l2 = [x.replace(RD.token(k), RD.token(n)) for x in l2]
                    lines.extend(l2)
        while lines and not lines[-1].strip():
            lines.pop()
        return title, lines, tables


def read_docx(path_or_bytes):
    """.docx → dict(title, text, tables, warn={종류: 개수}).

    ⚠ 머리글·바닥글·각주 본문은 읽지 않는다(본문만). 그 사실은 warn 에 개수로 남는다.
    """
    src = io.BytesIO(path_or_bytes) if isinstance(path_or_bytes, (bytes, bytearray)) else path_or_bytes
    with zipfile.ZipFile(src) as z:
        rd = _Reader(z)
        root = ET.fromstring(z.read('word/document.xml'))
        names = z.namelist()
        title2 = ''
        try:
            core = ET.fromstring(z.read('docProps/core.xml'))
            t = core.find('{http://purl.org/dc/elements/1.1/}title')
            title2 = (t.text or '').strip() if t is not None else ''
        except Exception:                                 # noqa: BLE001
            pass
    if any(n.startswith('word/header') or n.startswith('word/footer') for n in names):
        rd.warn['머리글·바닥글'] = rd.warn.get('머리글·바닥글', 0) + 1
    body = root.find('w:body', NS)
    title, lines, tables = rd.body(body if body is not None else [])
    return {'title': title or title2, 'text': '\n'.join(lines), 'tables': tables, 'warn': rd.warn}


# ══════════════════════════════════════════════════════════════════
def selftest():
    import os
    import tempfile
    ok = fail = 0

    def ck(c, m, got=''):
        nonlocal ok, fail
        if c:
            ok += 1
            print('  OK  ', m)
        else:
            fail += 1
            print('  FAIL', m, '|', str(got)[:300])

    text = ('첫 문단입니다.\n\n둘째 문단 <꺾쇠> & 앰퍼샌드\n' + RD.token(1) + '\n마지막 줄')
    t = RD.make([['낱말', '뜻'], ['은혜', '값없이 주심\n둘째 줄'], ['믿음', '']], 1)
    d = tempfile.mkdtemp()
    p = os.path.join(d, 'a.docx')
    write_docx(p, '제목 P326', text, {1: t})
    with zipfile.ZipFile(p) as z:
        ck(set(z.namelist()) >= {'[Content_Types].xml', 'word/document.xml', '_rels/.rels'}, '.docx 꾸러미 꼴')
        ET.fromstring(z.read('word/document.xml'))
        ck(True, 'document.xml 이 올바른 XML')
    r = read_docx(p)
    ck(r['title'] == '제목 P326', '★ 제목이 왕복', r['title'])
    ck(r['text'] == text, '★★ 글이 글자 그대로 왕복(빈 줄·꺾쇠·& 포함)', repr(r['text']))
    ck(r['tables'].get(1) == t, '★★ 표가 왕복(머리 줄·칸 안 여러 줄·빈 칸)', r['tables'])
    ck(r['warn'] == {}, '우리가 쓴 파일은 경고 0', r['warn'])

    # 워드가 쓰는 꼴 흉내 — 변경 추적 · 자동 번호 · 칸 합치기 · 그림 · 하이퍼링크
    doc = ('<w:document xmlns:w="%s"><w:body>'
           '<w:p><w:r><w:t>남는 </w:t></w:r><w:del><w:r><w:delText>지운 글</w:delText></w:r></w:del>'
           '<w:ins><w:r><w:t>넣은 글</w:t></w:r></w:ins></w:p>'
           '<w:p><w:pPr><w:numPr><w:ilvl w:val="0"/><w:numId w:val="1"/></w:numPr></w:pPr><w:r><w:t>하나</w:t></w:r></w:p>'
           '<w:p><w:pPr><w:numPr><w:ilvl w:val="0"/><w:numId w:val="1"/></w:numPr></w:pPr><w:r><w:t>둘</w:t></w:r></w:p>'
           '<w:p><w:pPr><w:numPr><w:ilvl w:val="1"/><w:numId w:val="1"/></w:numPr></w:pPr><w:r><w:t>둘-가</w:t></w:r></w:p>'
           '<w:p><w:hyperlink><w:r><w:t>링크 글</w:t></w:r></w:hyperlink><w:r><w:drawing/></w:r></w:p>'
           '<w:tbl><w:tr><w:tc><w:tcPr><w:gridSpan w:val="2"/></w:tcPr><w:p><w:r><w:t>합친 칸</w:t></w:r></w:p></w:tc></w:tr>'
           '<w:tr><w:tc><w:p><w:r><w:t>가</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>나</w:t></w:r></w:p></w:tc></w:tr>'
           '</w:tbl></w:body></w:document>' % W)
    num = ('<w:numbering xmlns:w="%s"><w:abstractNum w:abstractNumId="0">'
           '<w:lvl w:ilvl="0"><w:numFmt w:val="decimal"/></w:lvl><w:lvl w:ilvl="1"><w:numFmt w:val="lowerLetter"/></w:lvl>'
           '</w:abstractNum><w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num></w:numbering>' % W)
    bio = io.BytesIO()
    with zipfile.ZipFile(bio, 'w') as z:
        z.writestr('word/document.xml', doc)
        z.writestr('word/numbering.xml', num)
    r = read_docx(bio.getvalue())
    L = r['text'].split('\n')
    ck(L[0] == '남는 넣은 글', '★ 변경 추적 — 받아들인 결과만', L[0])
    ck(L[1:4] == ['1. 하나', '2. 둘', '   a) 둘-가'], '★ 자동 번호 — 번호 글자를 지어 붙인다', L[1:4])
    ck(L[4] == '링크 글', '하이퍼링크는 글만', L[4])
    ck(r['tables'][1]['cells'] == [['합친 칸', ''], ['가', '나']] and r['warn'].get('칸 합치기') == 1,
       '★ 칸 합치기 — 첫 칸에 글 · 경고', (r['tables'], r['warn']))
    ck(r['warn'].get('그림·도형') == 1, '그림은 가져오지 않고 개수를 경고', r['warn'])
    print('ref_docx selftest: %s (%d/%d)' % ('OK' if not fail else 'FAIL', ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print(__doc__)
