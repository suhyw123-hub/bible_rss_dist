# -*- coding: utf-8 -*-
"""설정 ▸ 공동체몰 관리 (PC · 2026-10-28 신설) — 교회 관리자가 쓴다. 알맹이 = `cmall_admin`.

위 띠(단추는 전부 여기 §0): [몰 ▾] [몰 추가] [연결 고치기] … [연결 시험] [성도 초대 복사] [사장님 초대 복사] [새로 고침]
왼쪽 — 갈래 [대기][게시][보류][내림][전체] + 목록 / 오른쪽 — 고른 가게의 글(고칠 수 있다 · 다른 곳을 누르면 저장) ·
  고침이면 「지금 게시된 글」을 옆 칸에 두고 바뀐 칸을 칠한다 · 단추 [게시][보류][열쇠 새로][지우기](지우기는 한 번 더 눌러야).
처음(관리하는 몰이 없을 때) — 설치 순서와 연결 칸이 오른쪽에 · [스크립트 복사].
★ 2026-10-28 방식 둘 — 몰 추가에서 「구글 시트 방식 / 파일 방식」 선택 · [교회 서식](작성 안내 · 추가 칸 · 쓰는 카테고리 · 두 방식 공통) ·
  파일 몰이면 위 띠 오른쪽이 [가게 파일 넣기][몰 파일 만들기][폴더 열기] · 고른 가게 칸 아래에 그 교회 추가 칸(한 줄 / 큰 상자).
· 망을 쓰는 일은 일꾼 스레드 + 큐 + after · 팝업 없음 · 색은 역할(ui_theme) · 글꼴은 박지 않는다.
"""
import os
import queue
import threading
import tkinter as tk
from tkinter import ttk

import appdb
import cmall_admin as CA

try:
    import i18n
    _t = i18n.t
except Exception:          # pragma: no cover
    def _t(k, d=''):
        return d

try:
    import ui_theme
except Exception:          # pragma: no cover
    ui_theme = None


def _C(role, fb):
    try:
        v = ui_theme.C(role) if ui_theme else ''
        return v or fb
    except Exception:
        return fb


def _bold():
    try:
        from tkinter import font as tkfont
        f = tkfont.nametofont('TkDefaultFont').actual()
        return (f['family'], f['size'], 'bold')
    except Exception:
        return None


STATES = (('PENDING', 'CM_S_PEND', '대기'), ('PUBLISHED', 'CM_S_PUB', '게시'), ('HELD', 'CM_S_HELD', '보류'),
          ('REMOVED', 'CM_S_REM', '내림'), ('', 'CM_S_ALL', '전체'))
KINDS = {'NEW': ('CM_K_NEW', '새 가게'), 'EDIT': ('CM_K_EDIT', '고침'), 'DROP': ('CM_K_DROP', '내리기')}
MODES = (('SNS', 'CM_MODE_SNS', '인사말 + SNS 자세히 보기'), ('SELF', 'CM_MODE_SELF', '내가 자세히 설명'))
LABELS = (('name', 'CM_F_NAME', '가게 이름'), ('cat', 'CM_F_CAT', '분류'), ('mode', 'CM_F_MODE', '보이는 방식'),
          ('intro', 'CM_F_INTRO2', '인사말'), ('desc', 'CM_F_DESC', '자세한 설명'),
          ('phone', 'CM_F_PHONE', '전화'), ('addr', 'CM_F_ADDR', '주소'), ('hours', 'CM_F_HOURS', '영업시간'),
          ('owner', 'CM_F_OWNER', '사장님 이름'), ('link', 'CM_F_LINK2', 'SNS · 지도 주소'),
          ('dc_on', 'CM_F_DC_ON', '성도 할인'), ('dc_text', 'CM_F_DC_TEXT', '할인 내용'),
          ('dc_until', 'CM_F_DC_UNTIL', '할인 기간(YYYY-MM-DD · 비우면 늘)'))
GUIDE = (
    # 화면 이름은 구글 한국어 화면에 보이는 글자 그대로(2026-10-28 사용자 캡처로 확인) · 단계마다 그림 자리
    # (cmall_guide/step1.png … 또는 cmall_guide/<언어>/step1.png 가 있으면 그 아래에 작게 보인다).
    ('CM_G1B', '구글 드라이브(drive.google.com) ▸ 왼쪽 위 [+ 신규] ▸ Google Sheets ▸ 빈 스프레드시트. 교회 공용 구글 계정으로 하기를 권합니다.'),
    ('CM_G2B', '그 시트 위 메뉴 「확장 프로그램」 ▸ 「Apps Script」. 「Code.gs」 안의 글을 모두 지우고 위 [스크립트 복사]로 복사한 글을 붙여 넣은 뒤 '
               '저장 아이콘(또는 Ctrl+S)을 누릅니다. ▷ 실행은 누르지 않아도 됩니다.'),
    ('CM_G3B', '오른쪽 위 파란 [배포] ▸ 「새 배포」 ▸ 「유형 선택」 옆 톱니 ▸ 「웹 앱」 ▸ 「액세스 권한이 있는 사용자」를 「모든 사용자」로 ▸ [배포] ▸ '
               '[액세스 승인] ▸ 계정 선택 ▸ 「Google에서 확인하지 않은 앱」이 나오면 「고급」 ▸ 「…(으)로 이동(안전하지 않음)」 ▸ [계속]. '
               '교회가 직접 만든 스크립트라 안전합니다.'),
    ('CM_G4B', '「웹 앱」 URL 아래 [복사]를 누르고 아래 칸에 붙여 넣습니다. 몰 이름 · 교회 이름 · 관리자 비밀번호(처음 정하는 것 · 네 글자 이상)를 적고 '
               '[연결]을 누르면 끝입니다. 시트는 열어 볼 필요가 없습니다.'),
)



def _mode_name(code):
    return next((_t(k, d) for c, k, d in MODES if c == code), _t('CM_MODE_SELF', '내가 자세히 설명'))


class _ModeVar:
    """보이는 방식 콤보 — 화면은 사람 말, 값은 SNS/SELF."""

    def __init__(self, code):
        self.shown = tk.StringVar(value=_mode_name(code))

    def get(self):
        v = self.shown.get()
        return next((c for c, k, d in MODES if _t(k, d) == v), 'SELF')


class _CatVar:
    """분류 콤보 — 화면은 이름, 값은 코드(옛 한국어 이름도 코드로 읽는다)."""

    def __init__(self, raw):
        self.shown = tk.StringVar(value=CA.cat_name(raw))

    def get(self):
        v = self.shown.get()
        return next((c for c, _k in CA.CATS if CA.cat_name(c) == v), '')


class _TextVar:
    """여러 줄 글상자를 StringVar 처럼 읽는다."""

    def __init__(self, w):
        self.w = w

    def get(self):
        return self.w.get('1.0', 'end-1c')

class CmallAdminView(ttk.Frame):
    def __init__(self, master, db_path=None, call=None, **kw):
        super().__init__(master, **kw)
        self.db_path = db_path or appdb.MAIN_DB
        self._call = call  # 시험이 참고 서버를 끼운다
        self._q = queue.Queue()
        self._malls = []
        self._cur = None        # 지금 몰 dict
        self._rows = []
        self._cats = list(CA.CATS)
        self._state = 'PENDING'
        self._sel = None        # 고른 줄 dict
        self._vals = {}         # 칸 → Variable
        self._armed = ''
        self._busy = False
        self._img = None
        self._form = {'guide': '', 'fields': [], 'cats': []}
        self._new_mode = CA.MODE_SHEET
        self._build_top()
        self._body = ttk.Frame(self)
        self._body.pack(fill='both', expand=True, padx=6, pady=(0, 6))
        self.after(120, self._pump)
        self._load_malls()

    # ── 일꾼 ──────────────────────────────────────────────────────────
    def _bg(self, fn, done):
        def run():
            try:
                r = fn()
            except Exception as e:      # noqa: BLE001
                r = {'ok': False, 'err': '%s' % e}
            self._q.put((done, r))
        self._busy = True
        threading.Thread(target=run, daemon=True).start()

    def _pump(self):
        try:
            while True:
                done, r = self._q.get_nowait()
                self._busy = False
                try:
                    done(r)
                except tk.TclError:
                    pass
        except queue.Empty:
            pass
        if self.winfo_exists():
            self.after(120, self._pump)

    def _opener(self):
        return appdb.connect(self.db_path)

    def _client(self, m=None):
        m = m or self._cur or {}
        return CA.client_for(m, self._opener, call=self._call)

    def _is_file(self):
        return CA.is_file(self._cur)

    def _say(self, s, bad=False):
        self._status.config(text=s, fg=_C('danger', '#C0392B') if bad else _C('accent', '#2471A3'))

    # ── 위 띠 ─────────────────────────────────────────────────────────
    def _build_top(self):
        bar = ttk.Frame(self)
        bar.pack(fill='x', padx=6, pady=(6, 2))
        self._mall_var = tk.StringVar()
        self._mall_cb = ttk.Combobox(bar, textvariable=self._mall_var, state='readonly', width=22)
        self._mall_cb.pack(side='left')
        self._mall_cb.bind('<<ComboboxSelected>>', lambda e: self._pick_mall(self._mall_cb.current()))
        ttk.Button(bar, text=_t('CM_ADD', '몰 추가'), command=lambda: self._show_setup(None)).pack(side='left', padx=(6, 0))
        self._b_edit = ttk.Button(bar, text=_t('CM_EDIT_CONN', '연결 고치기'), command=lambda: self._show_setup(self._cur))
        self._b_edit.pack(side='left', padx=(6, 0))
        self._b_form = ttk.Button(bar, text=_t('CM_FORM', '교회 서식'), command=self._show_form)
        self._b_form.pack(side='left', padx=(6, 0))
        # 스크립트 복사는 늘 위 띠에 — 몰이 이미 있어도 스크립트를 새 판으로 바꿔 붙일 일이 있다
        self._b_script = ttk.Button(bar, text=_t('CM_COPY_SCRIPT', '스크립트 복사'), command=self._copy_script)
        self._b_script.pack(side='left', padx=(6, 0))
        try:
            from manual_widget import attach_manual_icon
            attach_manual_icon(bar, 'U_SET_CMALL').pack(side='right', padx=(4, 0))
        except Exception:
            pass
        ttk.Button(bar, text=_t('CM_RELOAD', '새로 고침'), command=self._refresh).pack(side='right')
        self._b_inv_a = ttk.Button(bar, text=_t('CM_INV_A', '내 폰으로 옮길 글 복사'), command=lambda: self._copy_invite('ADMIN'))
        self._b_inv_a.pack(side='right', padx=(6, 0))
        self._b_inv_o = ttk.Button(bar, text=_t('CM_INV_O', '사장님 초대 복사'), command=lambda: self._copy_invite('OWNER'))
        self._b_inv_o.pack(side='right', padx=(6, 0))
        self._b_inv_m = ttk.Button(bar, text=_t('CM_INV_M', '성도 초대 복사'), command=lambda: self._copy_invite('MEMBER'))
        self._b_inv_m.pack(side='right', padx=(6, 0))
        self._b_test = ttk.Button(bar, text=_t('CM_TEST', '연결 시험'), command=self._test_cur)
        self._b_test.pack(side='right', padx=(6, 0))
        # 파일 몰 — 둘째 줄에 셋(위 띠 한 줄에는 안 들어간다 · 시트 몰이면 감춘다)
        self._file_box = ttk.Frame(self)
        tk.Label(self._file_box, text=_t('CM_FILE_BAR', '파일 방식'), font=_bold(), fg=_C('fg_title', '#1F3A5F'),
                 bg=_C('bg', '#FFFFFF')).pack(side='left', padx=(2, 4))
        ttk.Button(self._file_box, text=_t('CM_TAKE', '가게 파일 넣기'), command=self._take_files).pack(side='left', padx=(6, 0))
        ttk.Button(self._file_box, text=_t('CM_MAKE_FILE', '몰 파일 만들기'), command=self._make_file).pack(side='left', padx=(6, 0))
        ttk.Button(self._file_box, text=_t('CM_OPEN_DIR', '폴더 열기'), command=self._open_dir).pack(side='left', padx=(6, 0))
        self._bar = bar
        self._status = tk.Label(self, text='', anchor='w', justify='left', wraplength=1000,
                                fg=_C('accent', '#2471A3'), bg=_C('bg', '#FFFFFF'))
        self._status.pack(fill='x', padx=8, pady=(0, 4))

    def _sync_top(self):
        on = self._cur is not None
        for b in (self._b_edit, self._b_form, self._b_test, self._b_inv_m, self._b_inv_o, self._b_inv_a):
            b.state(['!disabled'] if on else ['disabled'])
        if on and self._is_file():
            self._b_test.pack_forget()
            self._b_script.pack_forget()
            if not self._file_box.winfo_manager():
                self._file_box.pack(fill='x', padx=6, pady=(0, 2), after=self._bar)
            self._b_edit.config(text=_t('CM_EDIT_FILE', '이름 고치기'))
        else:
            self._file_box.pack_forget()
            if not self._b_test.winfo_manager():
                self._b_test.pack(side='right', padx=(6, 0), after=self._b_inv_m)
            if not self._b_script.winfo_manager():
                self._b_script.pack(side='left', padx=(6, 0), after=self._b_form)
            self._b_edit.config(text=_t('CM_EDIT_CONN', '연결 고치기'))
        self._mall_cb['values'] = [m.get('name') or m['url'] for m in self._malls]
        if on:
            self._mall_cb.current(self._malls.index(self._cur))

    def _load_malls(self):
        with appdb.connect(self.db_path) as c:
            self._malls = CA.load(c)
        if not self._malls:
            self._cur = None
            self._sync_top()
            self._show_setup(None)
            return
        self._cur = self._cur if self._cur in self._malls else self._malls[0]
        self._sync_top()
        self._show_main()
        self._refresh()

    def _pick_mall(self, i):
        if 0 <= i < len(self._malls):
            self._save_fields()
            self._cur = self._malls[i]
            self._sel = None
            self._form = {'guide': '', 'fields': [], 'cats': []}   # 몰마다 서식이 다르다 — 새로 받는다
            self._sync_top()   # 시트 몰 / 파일 몰 단추 갈이
            self._show_main()
            self._refresh()

    def _copy_invite(self, role):
        m = self._cur
        if not m:
            return
        txt = CA.invite_text(m['url'], m.get('name') or '', m.get('church') or '', role, form=self._form)
        self.clipboard_clear()
        self.clipboard_append(txt)
        if role == 'ADMIN':
            return self._say(_t('CM_COPIED_A2', '복사했습니다 — 이메일·문자·메모 무엇으로든 내 폰에 보내세요. 폰에서 그 글의 링크를 누르고 '
                                                '「하가에서 열기」를 누르면, 그 폰에서 성도 초대·사장님 초대를 카톡으로 나눌 수 있습니다.'))
        self._say(_t('CM_COPIED_O', '사장님 초대를 복사했습니다 — 사장님들께만 카톡으로 붙여 넣어 보내세요.') if role == 'OWNER'
                  else _t('CM_COPIED_M', '성도 초대를 복사했습니다 — 성도 방·새가족 교육 카톡에 붙여 넣어 보내세요.'))

    # ── 처음 · 연결 칸 ─────────────────────────────────────────────────
    def _clear_body(self):
        for w in self._body.winfo_children():
            w.destroy()
        self._vals = {}

    def _show_setup(self, m):
        self._save_fields()
        self._clear_body()
        f = ttk.Frame(self._body)
        f.pack(fill='both', expand=True)
        if m is None:
            # ★ 몰 추가 — 방식 선택(구글 시트 방식 / 파일 방식)
            mv = tk.StringVar(value=self._new_mode)
            mr = ttk.Frame(f)
            mr.pack(fill='x', pady=(4, 6))
            for code, k, d, hk, hd in (
                    (CA.MODE_SHEET, 'CM_MODE_SHEET', '구글 시트 방식', 'CM_MODE_SHEET_D',
                     '교회 구글 시트에 둡니다 · 게시하면 성도 폰이 저절로 새 목록을 받습니다'),
                    (CA.MODE_FILE, 'CM_MODE_FILE', '파일 방식', 'CM_MODE_FILE_D',
                     '서버 없이 파일을 카톡으로 나눕니다 · 새 파일을 나눌 때 바뀝니다')):
                ttk.Radiobutton(mr, text='%s — %s' % (_t(k, d), _t(hk, hd)), value=code, variable=mv,
                                command=lambda: self._set_new_mode(mv.get())).pack(anchor='w')
            if self._new_mode == CA.MODE_FILE:
                return self._setup_file(f, None)
        elif CA.is_file(m):
            return self._setup_file(f, m)
        tk.Label(f, text=_t('CM_SETUP_T', '공동체몰 열기 — 교회 구글 계정으로 무료'), font=_bold(), anchor='w',
                 fg=_C('fg_title', '#1F3A5F'), bg=_C('bg', '#FFFFFF')).pack(fill='x', pady=(4, 2))
        tk.Label(f, text=_t('CM_SETUP_D', '목록은 교회의 구글 시트에 있고, 성도 폰은 몰을 열 때 그 시트에서 받아 갑니다. 하가 쪽으로는 아무것도 가지 않습니다. '
                                          '이미 교회 서버가 있다면 공개된 공동체몰 약속대로 주소 하나를 만들어 아래에 넣으면 됩니다.'),
                 anchor='w', justify='left', wraplength=900, fg=_C('fg_dim', '#5D6D7E'), bg=_C('bg', '#FFFFFF')).pack(fill='x')
        row = ttk.Frame(f)
        row.pack(fill='x', pady=(8, 4))
        ttk.Button(row, text=_t('CM_COPY_SCRIPT', '스크립트 복사'), command=self._copy_script).pack(side='left')
        self._guide_imgs = []
        for i, (k, d) in enumerate(GUIDE, 1):
            tk.Label(f, text='%d. %s' % (i, _t(k, d)), anchor='w', justify='left', wraplength=900,
                     fg=_C('fg', '#1F2A24'), bg=_C('bg', '#FFFFFF')).pack(fill='x', pady=1)
            im = self._guide_img(i)
            if im is not None:
                self._guide_imgs.append(im)
                tk.Label(f, image=im, anchor='w', bg=_C('bg', '#FFFFFF')).pack(anchor='w', padx=18, pady=(0, 4))
        tk.Label(f, text=_t('CM_G_WARN', '⚠ 나중에 스크립트를 고칠 때는 [새 배포]가 아니라 [배포 관리] ▸ 수정 ▸ 새 버전으로 하세요. 새 배포를 하면 주소가 바뀌어 초대를 다시 보내야 합니다.'),
                 anchor='w', justify='left', wraplength=900, fg=_C('warning', '#9A6B12'), bg=_C('bg', '#FFFFFF')).pack(fill='x', pady=(6, 8))
        g = ttk.Frame(f)
        g.pack(fill='x')
        self._u_var = tk.StringVar(value=(m or {}).get('url', ''))
        self._n_var = tk.StringVar(value=(m or {}).get('name', ''))
        self._c_var = tk.StringVar(value=(m or {}).get('church', ''))
        self._p_var = tk.StringVar(value=(m or {}).get('pw', ''))
        ttk.Label(g, text=_t('CM_URL', '웹 앱 주소')).grid(row=0, column=0, sticky='w')
        ttk.Entry(g, textvariable=self._u_var, width=80).grid(row=0, column=1, sticky='we', padx=6)
        ttk.Label(g, text=_t('CM_MALL_NAME', '몰 이름(예: 하나몰)')).grid(row=1, column=0, sticky='w', pady=4)
        ttk.Entry(g, textvariable=self._n_var, width=30).grid(row=1, column=1, sticky='w', padx=6)
        ttk.Label(g, text=_t('CM_CHURCH', '교회 이름')).grid(row=2, column=0, sticky='w', pady=4)
        ttk.Entry(g, textvariable=self._c_var, width=30).grid(row=2, column=1, sticky='w', padx=6)
        ttk.Label(g, text=_t('CM_PW', '관리자 비밀번호')).grid(row=3, column=0, sticky='w', pady=4)
        ttk.Entry(g, textvariable=self._p_var, width=24, show='•').grid(row=3, column=1, sticky='w', padx=6)
        bt = ttk.Frame(f)
        bt.pack(fill='x', pady=6)
        self._b_connect = ttk.Button(bt, text=_t('CM_CONNECT2', '연결'), command=self._connect)
        self._b_connect.pack(side='left')
        if self._malls:
            ttk.Button(bt, text=_t('M_CANCEL', '취소'), command=self._show_main).pack(side='left', padx=6)
        if m:
            self._b_forget = ttk.Button(bt, text=_t('CM_FORGET', '이 PC 에서 이 몰 빼기'), command=lambda: self._forget(m))
            self._b_forget.pack(side='right')

    def _set_new_mode(self, mode):
        self._new_mode = mode
        self._show_setup(None)

    def _setup_file(self, f, m):
        """파일 방식 — 몰 이름 · 교회 이름만(서버 없음 · 이 PC 가 곧 서버)."""
        tk.Label(f, text=_t('CM_FILE_T', '파일 방식 공동체몰 — 서버 없이'), font=_bold(), anchor='w',
                 fg=_C('fg_title', '#1F3A5F'), bg=_C('bg', '#FFFFFF')).pack(fill='x', pady=(4, 2))
        tk.Label(f, text=_t('CM_FILE_D', '가게 목록은 이 PC 에 둡니다. 사장님은 하가에서 가게 파일을 만들어 카톡으로 관리자에게 보내고, '
                                         '관리자는 [가게 파일 넣기]로 받아 검토·게시한 뒤 [몰 파일 만들기]로 한 파일로 묶어 성도 카톡방에 나눕니다. '
                                         '몰 파일은 다음 PC 동기화 때 관리자 폰으로도 갑니다(그 폰에서 바로 카톡으로).'),
                 anchor='w', justify='left', wraplength=900, fg=_C('fg_dim', '#5D6D7E'), bg=_C('bg', '#FFFFFF')).pack(fill='x')
        g = ttk.Frame(f)
        g.pack(fill='x', pady=(8, 4))
        self._n_var = tk.StringVar(value=(m or {}).get('name', ''))
        self._c_var = tk.StringVar(value=(m or {}).get('church', ''))
        ttk.Label(g, text=_t('CM_MALL_NAME', '몰 이름(예: 하나몰)')).grid(row=0, column=0, sticky='w', pady=4)
        ttk.Entry(g, textvariable=self._n_var, width=30).grid(row=0, column=1, sticky='w', padx=6)
        ttk.Label(g, text=_t('CM_CHURCH', '교회 이름')).grid(row=1, column=0, sticky='w', pady=4)
        ttk.Entry(g, textvariable=self._c_var, width=30).grid(row=1, column=1, sticky='w', padx=6)
        bt = ttk.Frame(f)
        bt.pack(fill='x', pady=6)
        ttk.Button(bt, text=_t('CM_FILE_MAKE', '만들기') if m is None else _t('CM_FILE_SAVE', '저장'),
                   command=lambda: self._save_file_mall(m)).pack(side='left')
        if self._malls:
            ttk.Button(bt, text=_t('M_CANCEL', '취소'), command=self._show_main).pack(side='left', padx=6)
        if m:
            ttk.Button(bt, text=_t('CM_FORGET', '이 PC 에서 이 몰 빼기'), command=lambda: self._forget(m)).pack(side='right')

    def _save_file_mall(self, m):
        name, church = self._n_var.get().strip(), self._c_var.get().strip()
        if not name:
            return self._say(_t('CM_E_NAME', '몰 이름을 적으세요.'), bad=True)
        with appdb.connect(self.db_path) as c:
            ms = CA.load(c)
            if m is None:
                m = CA.new_file_mall(self._opener, name, church)
                ms.append(m)
            else:
                ms = CA.upsert(ms, m['url'], name=name, church=church, mode=CA.MODE_FILE)
            CA.save(c, ms)
        self._client(m).admin('settings', name=name, church=church)
        self._malls = ms
        self._cur = next(x for x in ms if x['url'] == m['url'])
        self._sync_top()
        self._show_main()
        self._refresh()
        self._say(_t('CM_FILE_READY', '「%s」 파일 방식 몰을 만들었습니다 — [사장님 초대 복사]로 사장님께 서식을 보내세요.') % name)

    # ── 파일 몰 단추 ──
    def _file_mall(self):
        return CA.file_mall(self._opener, self._cur)

    def _take_files(self):
        if not self._is_file():
            return
        from tkinter import filedialog
        ps = filedialog.askopenfilenames(parent=self, title=_t('CM_TAKE', '가게 파일 넣기'),
                                         filetypes=[('Hagah', '*.json'), ('*', '*.*')])
        if not ps:
            return
        res = CA.take_store_files(self._file_mall(), ps)
        self._state = 'PENDING'
        self._show_main()   # 서식 화면에서 넣었어도 대기 목록으로
        self._refresh()
        self.after(60, lambda: self._say(' · '.join('%s: %s' % (n, CA.take_text(r)) for n, r in res),
                                         bad=not all(r.get('ok') for _n, r in res)))

    def _make_file(self):
        if not self._is_file():
            return
        self._save_fields()
        p, n, ver, mb = CA.write_mall_file(self._file_mall(), opener=self._opener)
        self._last_file = p
        if n == 0:
            return self._say(_t('CM_FILE_EMPTY', '게시된 가게가 없어 빈 몰 파일을 만들었습니다: %s') % p, bad=True)
        self._say(_t('CM_FILE_DONE', '몰 파일을 만들었습니다 — 가게 %d곳 · 판 %d · %.1f MB · %s\n'
                                     '메일로 보내려면 [폴더 열기]에서 이 파일을 첨부하세요. 다음 PC 동기화 때 관리자 폰으로도 갑니다.')
                  % (n, ver, mb, p))

    def _open_dir(self):
        try:
            p = getattr(self, '_last_file', '')
            if p and os.path.isfile(p):
                import subprocess
                subprocess.Popen(['explorer', '/select,', os.path.normpath(p)])
            else:
                os.startfile(CA.out_dir())
        except Exception as e:      # noqa: BLE001
            self._say('%s' % e, bad=True)

    # ── 교회 서식 ──
    def _show_form(self):
        """작성 안내 글 · 추가 칸(개수 제한 없음 · 이름 · 한 줄/큰 상자 · ▲▼ · 지우기) · 쓰는 카테고리 — 고치면 곧바로 저장."""
        if not self._cur:
            return
        self._save_fields()
        self._clear_body()
        top = ttk.Frame(self._body)
        top.pack(fill='x', pady=(0, 4))
        ttk.Button(top, text=_t('CM_BACK_LIST', '가게 목록으로'), command=self._show_main).pack(side='left')
        ttk.Button(top, text=_t('CM_FIELD_ADD', '+ 칸 추가'), command=self._field_add).pack(side='left', padx=(6, 0))
        tk.Label(top, text=_t('CM_FORM_NOTE', '앱 표준 서식(가게 이름·카테고리·전화·주소·사진 다섯 …)은 모든 교회가 같습니다. 여기서는 이 교회만의 것을 더합니다. 고치면 곧바로 저장됩니다.'),
                 anchor='w', justify='left', wraplength=760, fg=_C('fg_dim', '#5D6D7E'), bg=_C('bg', '#FFFFFF')).pack(side='left', padx=10)
        cv = tk.Canvas(self._body, highlightthickness=0, bg=_C('bg', '#FFFFFF'))
        sb = ttk.Scrollbar(self._body, orient='vertical', command=cv.yview)
        cv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        cv.pack(fill='both', expand=True)
        f = ttk.Frame(cv)
        win = cv.create_window(0, 0, window=f, anchor='nw')
        f.bind('<Configure>', lambda e: cv.configure(scrollregion=cv.bbox('all')))
        cv.bind('<Configure>', lambda e: cv.itemconfigure(win, width=e.width))
        self._form_frame = f
        self._draw_form()

    def _draw_form(self):
        f = self._form_frame
        for w in f.winfo_children():
            w.destroy()
        fm = self._form
        tk.Label(f, text=_t('CM_GUIDE_L', '작성 안내 글 — 사장님 등록 화면 맨 위에 보입니다'), font=_bold(), anchor='w',
                 bg=_C('bg', '#FFFFFF'), fg=_C('fg', '#1F2A24')).pack(fill='x', pady=(4, 2))
        g = tk.Text(f, height=3, wrap='word', bg=_C('edit_bg', '#FFFFFF'), fg=_C('fg', '#1F2A24'), insertbackground=_C('fg', '#1F2A24'))
        g.insert('1.0', fm.get('guide', ''))
        g.pack(fill='x')
        g.bind('<FocusOut>', lambda e: self._form_set(guide=g.get('1.0', 'end-1c').strip()))
        tk.Label(f, text=_t('CM_FIELDS_L', '추가 칸 — 이름과 입력 모양(한 줄 / 큰 상자) · 가게 화면에서 표준 칸 아래에 이 차례대로 · 글이 빈 칸은 안 보입니다'),
                 font=_bold(), anchor='w', bg=_C('bg', '#FFFFFF'), fg=_C('fg', '#1F2A24')).pack(fill='x', pady=(10, 2))
        shapes = ((('LINE', _t('CM_SHAPE_LINE', '한 줄'))), (('BOX', _t('CM_SHAPE_BOX', '큰 상자'))))
        if not fm.get('fields'):
            tk.Label(f, text=_t('CM_FIELDS_NONE', '추가 칸이 없습니다. 위 [+ 칸 추가]로 더합니다.'), anchor='w',
                     bg=_C('bg', '#FFFFFF'), fg=_C('fg_dim', '#7F8C8D')).pack(fill='x')
        for i, x in enumerate(fm.get('fields') or []):
            r = ttk.Frame(f)
            r.pack(fill='x', pady=2)
            nv = tk.StringVar(value=x['label'])
            e = ttk.Entry(r, textvariable=nv, width=36)
            e.pack(side='left')
            e.bind('<FocusOut>', lambda ev, i=i, nv=nv: self._field_set(i, label=nv.get().strip()))
            sv = tk.StringVar(value=dict(shapes)[x['shape']])
            cb = ttk.Combobox(r, textvariable=sv, values=[n for _c, n in shapes], state='readonly', width=8)
            cb.pack(side='left', padx=6)
            cb.bind('<<ComboboxSelected>>', lambda ev, i=i, sv=sv: self._field_set(
                i, shape=next(c for c, n in shapes if n == sv.get())))
            ttk.Button(r, text='▲', width=3, command=lambda i=i: self._field_move(i, -1)).pack(side='left')
            ttk.Button(r, text='▼', width=3, command=lambda i=i: self._field_move(i, 1)).pack(side='left', padx=(2, 0))
            ttk.Button(r, text=_t('CM_DELETE', '지우기'), command=lambda i=i: self._field_del(i)).pack(side='left', padx=(10, 0))
        tk.Label(f, text=_t('CM_CATS_L', '쓰는 카테고리 — 사장님 등록 화면에 이것만 보입니다 · 아무것도 선택하지 않으면 전부'),
                 font=_bold(), anchor='w', bg=_C('bg', '#FFFFFF'), fg=_C('fg', '#1F2A24')).pack(fill='x', pady=(12, 2))
        cg = ttk.Frame(f)
        cg.pack(fill='x')
        on = set(fm.get('cats') or [])
        self._cat_vars = {}
        for i, (c, _k) in enumerate(CA.CATS):
            v = tk.BooleanVar(value=c in on)
            self._cat_vars[c] = v
            ttk.Checkbutton(cg, text=CA.cat_name(c), variable=v, command=self._cats_set).grid(row=i // 4, column=i % 4, sticky='w', padx=(0, 16))

    def _form_set(self, **kw):
        fm = dict(self._form)
        fm.update(kw)
        if fm == self._form:
            return
        self._form = fm
        cl = self._client()
        self._bg(lambda: cl.admin('settings', form=fm), self._form_done)

    def _form_done(self, r):
        if not r.get('ok'):
            return self._say(CA.err_text(r.get('err', 'NET')), bad=True)
        if r.get('form') is not None:
            self._form = r['form']
        self._say(_t('CM_FORM_SAVED', '교회 서식을 저장했습니다.'))

    def _fields(self):
        return [dict(x) for x in self._form.get('fields') or []]

    def _field_add(self):
        fs = self._fields()
        fs.append({'k': CA.next_key(self._form, self._rows), 'label': _t('CM_FIELD_NEW', '새 칸') + ' %d' % (len(fs) + 1), 'shape': 'LINE'})
        self._form_set(fields=fs)
        self._draw_form()

    def _field_set(self, i, **kw):
        fs = self._fields()
        if 0 <= i < len(fs):
            if kw.get('label') == '':
                return self._draw_form()
            fs[i].update(kw)
            self._form_set(fields=fs)

    def _field_move(self, i, d):
        fs = self._fields()
        j = i + d
        if 0 <= j < len(fs):
            fs[i], fs[j] = fs[j], fs[i]
            self._form_set(fields=fs)
            self._draw_form()

    def _field_del(self, i):
        fs = self._fields()
        if self._armed != 'FDEL%d' % i:
            self._armed = 'FDEL%d' % i
            return self._say(_t('CM_ARM_FDEL', '한 번 더 누르면 이 칸을 지웁니다(사장님이 적은 그 칸의 글은 더 이상 보이지 않습니다).'))
        self._armed = ''
        if 0 <= i < len(fs):
            del fs[i]
            self._form_set(fields=fs)
            self._draw_form()

    def _cats_set(self):
        self._form_set(cats=[c for c, _k in CA.CATS if self._cat_vars[c].get()])

    @staticmethod
    def _guide_img(i):
        """설치 단계 그림(있으면) — cmall_guide/<언어>/stepN.png → cmall_guide/stepN.png · 폭 520 으로 줄인다."""
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cmall_guide')
        try:
            lang = (i18n.get_lang() if hasattr(i18n, 'get_lang') else '') or ''
        except Exception:
            lang = ''
        for p in ([os.path.join(base, lang.upper(), 'step%d.png' % i)] if lang else []) + [os.path.join(base, 'step%d.png' % i)]:
            if os.path.isfile(p):
                try:
                    from PIL import Image, ImageTk
                    im = Image.open(p)
                    if im.width > 520:
                        im = im.resize((520, max(1, im.height * 520 // im.width)))
                    return ImageTk.PhotoImage(im)
                except Exception:
                    return None
        return None

    def _copy_script(self):
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'cmall_apps_script.gs')
        try:
            txt = open(p, encoding='utf-8').read()
        except Exception:
            return self._say(_t('CM_NO_SCRIPT', '스크립트 파일(cmall_apps_script.gs)을 찾지 못했습니다.'), bad=True)
        self.clipboard_clear()
        self.clipboard_append(txt)
        if self._malls:
            return self._say(_t('CM_SCRIPT_COPIED2', '스크립트를 복사했습니다 — Apps Script 「Code.gs」의 글을 모두 지우고 붙여 넣어 저장한 뒤 '
                                                     '[배포] ▸ 「배포 관리」 ▸ 연필(수정) ▸ 버전 「새 버전」 ▸ [배포]. 「새 배포」는 주소가 바뀌니 누르지 마세요.'))
        self._say(_t('CM_SCRIPT_COPIED', '스크립트를 복사했습니다 — Apps Script 편집기에 붙여 넣으세요.'))

    def _connect(self):
        url, pw = self._u_var.get().strip(), self._p_var.get().strip()
        name, church = self._n_var.get().strip(), self._c_var.get().strip()
        if not url.startswith('http'):
            return self._say(_t('CM_E_URL', '웹 앱 주소를 넣으세요(https://script.google.com/…/exec).'), bad=True)
        self._say(_t('CM_TESTING', '연결을 시험하는 중…'))
        cl = CA.Client(url, pw, call=self._call)

        def done(r):
            ok, msg, h = r
            if not ok:
                return self._say(msg, bad=True)
            m = h.get('mall') or {}
            with appdb.connect(self.db_path) as c:
                ms = CA.upsert(CA.load(c), url, name=m.get('name') or '', church=m.get('church') or '', pw=pw)
                CA.save(c, ms)
            self._malls = ms
            self._cur = next(x for x in ms if x['url'] == url)
            self._sync_top()
            self._show_main()
            self._refresh()
            self._say(msg)
        self._bg(lambda: cl.connect(name, church), done)

    def _forget(self, m):
        if self._armed != 'FORGET':
            self._armed = 'FORGET'
            return self._say(_t('CM_ARM_FORGET', '한 번 더 누르면 이 PC 의 목록에서 뺍니다(교회 시트는 그대로입니다).'))
        self._armed = ''
        with appdb.connect(self.db_path) as c:
            ms = [x for x in CA.load(c) if x['url'] != m['url']]
            CA.save(c, ms)
        self._cur = None
        self._load_malls()

    def _test_cur(self):
        if not self._cur:
            return
        self._say(_t('CM_TESTING', '연결을 시험하는 중…'))
        self._bg(self._client().test, lambda r: self._say(r[1], bad=not r[0]))

    # ── 본 화면 ────────────────────────────────────────────────────────
    def _show_main(self):
        if not self._cur:
            return self._show_setup(None)
        self._clear_body()
        pw = ttk.PanedWindow(self._body, orient='horizontal')
        pw.pack(fill='both', expand=True)
        left, right = ttk.Frame(pw), ttk.Frame(pw)
        pw.add(left, weight=2)
        pw.add(right, weight=3)
        chips = ttk.Frame(left)
        chips.pack(fill='x', pady=(0, 4))
        self._state_var = tk.StringVar(value=self._state)
        self._chip_btns = {}
        for code, k, d in STATES:
            b = ttk.Radiobutton(chips, text=_t(k, d), value=code, variable=self._state_var, style='Toolbutton',
                                command=lambda: self._set_state(self._state_var.get()))
            b.pack(side='left', padx=(0, 4))
            self._chip_btns[code] = (b, _t(k, d))
        self._tv = ttk.Treeview(left, columns=('k', 'n', 'c', 'd'), show='headings', selectmode='browse')
        for col, k, d, w in (('k', 'CM_COL_KIND', '갈래', 80), ('n', 'CM_COL_NAME', '가게', 180),
                             ('c', 'CM_COL_CAT', '분류', 90), ('d', 'CM_COL_DATE', '때', 90)):
            self._tv.heading(col, text=_t(k, d))
            self._tv.column(col, width=w, anchor='w')
        self._tv.pack(fill='both', expand=True)
        self._tv.bind('<<TreeviewSelect>>', self._on_pick)
        self._right = right
        self._fill_list()
        self._draw_detail()

    def _set_state(self, s):
        self._save_fields()
        self._state = s
        self._sel = None
        self._fill_list()
        self._draw_detail()

    def _refresh(self):
        if not self._cur:
            return
        self._save_fields()

        def done(r):
            if not r.get('ok'):
                return self._say(CA.err_text(r.get('err', 'NET')), bad=True)
            self._rows = r.get('rows', [])
            self._cats = r.get('cats') or list(CA.CATS)
            if isinstance(r.get('form'), dict):
                self._form = r['form']
            if self._sel:
                self._sel = next((x for x in self._rows if x['id'] == self._sel['id']), None)
            self._fill_list()
            self._draw_detail()
            n = sum(1 for x in self._rows if x.get('state') == 'PENDING')
            self._say(_t('CM_LOADED', '%s · 게시 %d · 대기 %d') % (self._cur.get('name') or '', int(r.get('count') or 0), n))
        self._bg(lambda: self._client().admin('all'), done)

    def _fill_list(self):
        if not hasattr(self, '_tv') or not self._tv.winfo_exists():
            return
        cnt = {}
        for r in self._rows:
            cnt[r.get('state')] = cnt.get(r.get('state'), 0) + 1
        for code, (b, name) in self._chip_btns.items():
            b.config(text='%s %d' % (name, cnt.get(code, 0)) if code else name)
        self._tv.delete(*self._tv.get_children())
        for r in self._rows:
            if self._state and r.get('state') != self._state:
                continue
            kind = r.get('kind', 'NEW')
            k = _t(*KINDS[kind]) if r.get('state') == 'PENDING' else dict((c, _t(kk, d)) for c, kk, d in STATES).get(r.get('state'), '')
            when = ('%s' % (r.get('made') if r.get('state') == 'PENDING' else r.get('changed') or r.get('posted') or ''))[:10]
            self._tv.insert('', 'end', iid=r['id'], values=(k, r.get('name', ''), CA.cat_name(r.get('cat', '')), when))
        if self._sel and self._tv.exists(self._sel['id']):
            self._tv.selection_set(self._sel['id'])

    def _on_pick(self, _e=None):
        s = self._tv.selection()
        if not s:
            return
        r = next((x for x in self._rows if x['id'] == s[0]), None)
        if r is None or (self._sel and r['id'] == self._sel['id']):
            return
        self._save_fields()
        self._sel = r
        self._armed = ''
        self._draw_detail()

    # ── 오른쪽 — 고른 가게 ─────────────────────────────────────────────
    def _draw_detail(self):
        for w in self._right.winfo_children():
            w.destroy()
        self._vals = {}
        r = self._sel
        if r is None:
            tk.Label(self._right, text=_t('CM_PICK', '왼쪽에서 가게를 선택하세요. 대기 = 사장님이 보내 온 글입니다.'),
                     anchor='w', justify='left', fg=_C('fg_dim', '#7F8C8D'), bg=_C('bg', '#FFFFFF')).pack(fill='x', padx=8, pady=8)
            return
        bar = ttk.Frame(self._right)
        bar.pack(fill='x', padx=4, pady=(0, 6))
        st = r.get('state')
        if st in ('PENDING', 'HELD'):
            ttk.Button(bar, text=_t('CM_PUBLISH', '게시'), command=lambda: self._act('publish')).pack(side='left')
        if st in ('PENDING', 'PUBLISHED'):
            ttk.Button(bar, text=_t('CM_HOLD', '보류'), command=lambda: self._act('hold')).pack(side='left', padx=(6, 0))
        if r.get('kind') == 'NEW':
            ttk.Button(bar, text=_t('CM_REKEY', '열쇠 새로'), command=self._rekey).pack(side='left', padx=(6, 0))
        self._b_del = ttk.Button(bar, text=_t('CM_DELETE', '지우기'), command=lambda: self._act('delete'))
        self._b_del.pack(side='right')
        base = None
        if r.get('kind') in ('EDIT', 'DROP'):
            base = next((x for x in self._rows if x['id'] == '%s' % r.get('ref')), None)
        diff = set(CA.diff_fields(base, r)) if base else set()
        if r.get('kind') == 'DROP':
            tk.Label(self._right, text=_t('CM_DROP_NOTE', '사장님이 이 가게를 내려 달라고 보냈습니다. [게시]하면 목록에서 빠집니다.'),
                     anchor='w', fg=_C('warning', '#9A6B12'), bg=_C('bg', '#FFFFFF')).pack(fill='x', padx=6)
        g = ttk.Frame(self._right)
        g.pack(fill='x', padx=6)
        if base:
            ttk.Label(g, text=_t('CM_NOW_PUB', '지금 게시된 글'), foreground=_C('fg_dim', '#7F8C8D')).grid(row=0, column=2, sticky='w', padx=6)
        hi = _C('warning_bg', '#FFF3CD')
        for i, (f, k, d) in enumerate(LABELS, 1):
            ttk.Label(g, text=_t(k, d)).grid(row=i, column=0, sticky='nw', pady=2)
            if f == 'dc_on':
                v = tk.BooleanVar(value=bool(r.get(f)) and r.get(f) not in ('false', 'FALSE'))
                w = ttk.Checkbutton(g, variable=v, command=self._save_fields)
            elif f == 'cat':
                v = _CatVar(r.get(f, ''))
                w = ttk.Combobox(g, textvariable=v.shown, values=[CA.cat_name(c) for c, _k in CA.CATS], state='readonly', width=24)
                w.bind('<<ComboboxSelected>>', lambda e: self._save_fields())
            elif f == 'mode':
                v = _ModeVar(r.get(f) or 'SELF')
                w = ttk.Combobox(g, textvariable=v.shown, values=[_t(k, d) for _c, k, d in MODES], state='readonly', width=24)
                w.bind('<<ComboboxSelected>>', lambda e: self._save_fields())
            elif f == 'desc':
                w = tk.Text(g, height=4, width=48, wrap='word', bg=_C('edit_bg', '#FFFFFF'), fg=_C('fg', '#1F2A24'),
                            insertbackground=_C('fg', '#1F2A24'))
                w.insert('1.0', '%s' % (r.get(f) or ''))
                v = _TextVar(w)
            else:
                v = tk.StringVar(value='%s' % (r.get(f) or ''))
                w = ttk.Entry(g, textvariable=v, width=48)
            w.grid(row=i, column=1, sticky='we', pady=2)
            w.bind('<FocusOut>', lambda e: self._save_fields())
            self._vals[f] = v
            if base:
                bv = base.get(f, '')
                if f == 'dc_on':
                    bv = _t('CM_YES', '있음') if (bv and bv not in ('false', 'FALSE')) else _t('CM_NO', '없음')
                elif f == 'mode':
                    bv = _mode_name(bv)
                elif f == 'cat':
                    bv = CA.cat_name(bv)
                tk.Label(g, text='%s' % (bv or ''), anchor='w', wraplength=260, justify='left',
                         bg=hi if f in diff else _C('bg', '#FFFFFF'), fg=_C('fg', '#1F2A24')).grid(row=i, column=2, sticky='we', padx=6)
        # ★ 교회별 추가 칸 — 서식 차례 · 한 줄 / 큰 상자
        ex = CA._extra(r.get('extra'))
        bex = CA._extra(base.get('extra')) if base else {}
        n0 = len(LABELS) + 1
        for j, x in enumerate(self._form.get('fields') or []):
            row = n0 + j
            ttk.Label(g, text=x['label']).grid(row=row, column=0, sticky='nw', pady=2)
            if x['shape'] == 'BOX':
                w = tk.Text(g, height=4, width=48, wrap='word', bg=_C('edit_bg', '#FFFFFF'), fg=_C('fg', '#1F2A24'),
                            insertbackground=_C('fg', '#1F2A24'))
                w.insert('1.0', ex.get(x['k'], ''))
                v = _TextVar(w)
            else:
                v = tk.StringVar(value=ex.get(x['k'], ''))
                w = ttk.Entry(g, textvariable=v, width=48)
            w.grid(row=row, column=1, sticky='we', pady=2)
            w.bind('<FocusOut>', lambda e: self._save_fields())
            self._vals['x:' + x['k']] = v
            if base:
                tk.Label(g, text=bex.get(x['k'], ''), anchor='w', wraplength=260, justify='left',
                         bg=hi if ('x:' + x['k']) in diff else _C('bg', '#FFFFFF'), fg=_C('fg', '#1F2A24')).grid(
                    row=row, column=2, sticky='we', padx=6)
        g.columnconfigure(1, weight=1)
        self._loaded = self._field_vals()
        self._show_photos([r.get(f) or '' for f in ('photo',) + CA.SUB_PHOTOS])

    def _show_photos(self, b64s):
        """사진 다섯(대표 + 넷) — 한 줄에 작게. 첫째가 대표."""
        b64s = [b for b in b64s if b]
        if not b64s:
            return
        row = tk.Frame(self._right, bg=_C('bg', '#FFFFFF'))
        row.pack(anchor='w', padx=6, pady=6)
        self._imgs = []
        try:
            import base64
            import io
            from PIL import Image, ImageTk
        except Exception:
            return
        for i, b in enumerate(b64s):
            try:
                im = Image.open(io.BytesIO(base64.b64decode(b)))
                im.thumbnail((180, 135) if i == 0 else (110, 82))
                self._imgs.append(ImageTk.PhotoImage(im))
                tk.Label(row, image=self._imgs[-1], bg=_C('bg', '#FFFFFF')).pack(side='left', padx=(0, 6), anchor='n')
            except Exception:
                pass

    def _field_vals(self):
        return {f: v.get() for f, v in self._vals.items()}

    def _save_fields(self):
        """다른 곳을 누르면 저장 — 바뀐 것이 있을 때만(사람이 쓴 글 · 저장 단추 없음)."""
        r = self._sel
        if r is None or not self._vals or not self._cur:
            return
        try:
            now = self._field_vals()
        except tk.TclError:
            return
        if now == getattr(self, '_loaded', None):
            return
        self._loaded = now
        store = {f: r.get(f, '') for f in CA.FIELDS}
        ex = CA._extra(r.get('extra'))
        for k, v in now.items():
            if k.startswith('x:'):
                ex[k[2:]] = ('%s' % v).strip()
            else:
                store[k] = v
                r[k] = v
        store['extra'] = {k: v for k, v in ex.items() if v}
        r['extra'] = store['extra']
        rid = r['id']
        self._bg(lambda: self._client().admin('save', id=rid, store=store),
                 lambda res: self._say(_t('CM_SAVED_F', '고친 글을 저장했습니다.') if self._is_file()
                                       else _t('CM_SAVED', '고친 글을 시트에 저장했습니다.')) if res.get('ok')
                 else self._say(CA.err_text(res.get('err', 'NET')), bad=True))

    def _act(self, op):
        r = self._sel
        if r is None:
            return
        if op == 'delete' and self._armed != 'DEL%s' % r['id']:
            self._armed = 'DEL%s' % r['id']
            return self._say(_t('CM_ARM_DEL', '한 번 더 누르면 시트에서 지웁니다(되돌릴 수 없습니다). 목록에서만 빼려면 [보류].'))
        self._armed = ''
        self._save_fields()
        rid = r['id']
        msgs = {'publish': _t('CM_DONE_PUB', '게시했습니다 — 성도 폰이 몰을 열 때 보입니다.'),
                'hold': _t('CM_DONE_HOLD', '보류했습니다(목록에서 빠집니다).'),
                'delete': _t('CM_DONE_DEL', '지웠습니다.')}

        def done(res):
            if not res.get('ok'):
                return self._say(CA.err_text(res.get('err', 'NET')), bad=True)
            self._sel = None
            self._refresh()
            self.after(50, lambda: self._say(msgs[op]))
        self._bg(lambda: self._client().admin(op, id=rid), done)

    def _rekey(self):
        r = self._sel
        if r is None:
            return
        rid, name = r['id'], r.get('name', '')

        def done(res):
            if not res.get('ok'):
                return self._say(CA.err_text(res.get('err', 'NET')), bad=True)
            txt = CA.key_text(self._cur['url'], self._cur.get('name') or '', rid, res['key'], name)
            self.clipboard_clear()
            self.clipboard_append(txt)
            self._say(_t('CM_KEY_COPIED', '새 열쇠를 복사했습니다 — 그 사장님께만 카톡으로 보내세요. 옛 열쇠는 더 이상 쓰이지 않습니다.'))
        self._bg(lambda: self._client().admin('rekey', id=rid), done)


def selftest():
    """화면을 실제로 띄워 참고 서버(가짜 교회)와 왕복한다 — 실제 DB 는 안 건드린다(임시 user_config)."""
    import sqlite3
    import tempfile
    import cmall_ref
    ok, bad = 0, []

    def ck(c, m):
        nonlocal ok
        if c:
            ok += 1
        else:
            bad.append(m)

    m = cmall_ref.Mall(None, pw='pw1', name='하나몰', church='수원하나교회')
    cmall_ref.seed(m)
    r = m.submit({'op': 'new', 'store': {'name': '대기 가게', 'cat': '카페'}})
    m.submit({'op': 'edit', 'id': '1', 'key': 'nokey', 'store': {}})  # 열쇠 틀림 → 안 들어감
    d = tempfile.mkdtemp()
    db = os.path.join(d, 'u.db')
    con = sqlite3.connect(db)
    con.execute('CREATE TABLE user_config(config_key TEXT PRIMARY KEY, config_val TEXT)')
    con.commit()
    con.close()

    class _Conn:
        def __init__(self, p):
            self.c = sqlite3.connect(p)

        def __enter__(self):
            return self.c

        def __exit__(self, *a):
            self.c.commit()
            self.c.close()
    real = appdb.connect
    appdb.connect = lambda p=None, **kw: _Conn(db)
    root = tk.Tk()
    root.geometry('1200x700')
    try:
        v = CmallAdminView(root, db, call=CA.fake_call(m))
        v.pack(fill='both', expand=True)

        def spin(n=20):
            import time
            for _ in range(n):
                root.update()
                time.sleep(0.03)
        spin()
        ck(hasattr(v, '_u_var'), '처음 = 설치 안내 + 연결 칸')
        v._u_var.set('https://x/exec')
        v._p_var.set('pw1')
        v._connect()
        spin(30)
        ck(v._cur and v._cur.get('name') == '하나몰', '연결 시험 후 저장')
        ck(len([x for x in v._rows if x['state'] == 'PENDING']) == 1, '대기 하나')
        ck('대기 1' in v._chip_btns['PENDING'][0].cget('text'), '갈래 칩에 수')
        v._tv.selection_set(r['id'])
        spin()
        ck(v._sel and v._sel['id'] == r['id'], '고르면 오른쪽')
        ck('mode' in v._vals and 'desc' in v._vals and v._vals['mode'].get() in ('SNS', 'SELF'), '보이는 방식 · 자세한 설명 칸')
        v._vals['intro'].set('새 소개')
        v._save_fields()
        spin(20)
        ck(next(x for x in m.d['rows'] if x['id'] == r['id'])['intro'] == '새 소개', '다른 곳 누르면 시트에 저장')
        v._act('publish')
        spin(30)
        ck(m.list()['count'] == 4, '게시')
        v._copy_invite('MEMBER')
        clip = root.clipboard_get()
        ck(CA.parse_tag(clip).get('role') == 'MEMBER', '성도 초대 복사')
        v._copy_invite('ADMIN')
        ck(CA.parse_tag(root.clipboard_get()).get('role') == 'ADMIN', '내 폰으로 옮길 글 복사')
        v._copy_script()
        ck('function doGet' in root.clipboard_get(), '몰이 있을 때도 위 띠에서 스크립트 복사')
        ck(len(GUIDE) == 4 and all('setup' not in _t(k, d) for k, d in GUIDE), '설치 넷 · setup 실행 없음')
        v._state_var.set('PUBLISHED')
        v._set_state('PUBLISHED')
        v._tv.selection_set('1')
        spin()
        v._act('delete')
        spin(10)
        ck(m.list()['count'] == 4, '지우기는 한 번 더')
        v._act('delete')
        spin(30)
        ck(m.list()['count'] == 3, '두 번 누르면 지움')
        # ★ 파일 방식 — 몰 추가 · 교회 서식 · 가게 파일 넣기 · 추가 칸 · 게시 · 몰 파일 만들기
        import json as _json
        CA.out_dir = lambda: d
        v._show_setup(None)
        v._set_new_mode(CA.MODE_FILE)
        spin()
        v._n_var.set('파일몰')
        v._c_var.set('새교회')
        v._save_file_mall(None)
        spin(30)
        ck(v._is_file() and v._cur['name'] == '파일몰' and len(v._malls) == 2, '파일 방식 몰 추가')
        ck(v._file_box.winfo_manager() and not v._b_test.winfo_manager(), '파일 몰 — 연결 시험 대신 둘째 줄 파일 단추 셋')
        v._show_form()
        spin()
        v._field_add()
        spin(20)
        v._field_add()
        spin(20)
        v._field_set(1, shape='BOX', label='교인 할인 내용')
        spin(20)
        v._field_move(1, -1)
        spin(20)
        v._form_set(guide='교인 할인을 꼭 적어 주세요')
        v._cat_vars['CAFE'].set(True)
        v._cats_set()
        spin(20)
        fm = v._file_mall().form
        ck([x['label'] for x in fm['fields']][0] == '교인 할인 내용' and fm['fields'][0]['shape'] == 'BOX' and len(fm['fields']) == 2,
           '서식 — 칸 둘 · 이름 · 큰 상자 · 차례 바꾸기')
        ck(fm['guide'] == '교인 할인을 꼭 적어 주세요' and fm['cats'] == ['CAFE'], '작성 안내 · 쓰는 카테고리')
        v._copy_invite('OWNER')
        iv = CA.parse_tag(root.clipboard_get())
        ck(iv and iv.get('mode') == 'FILE' and iv['form']['fields'][0]['label'] == '교인 할인 내용', '사장님 초대 = 파일 몰 + 서식')
        k1 = fm['fields'][0]['k']
        sid, key = cmall_ref.new_sid(), 'q' * 24
        sp = os.path.join(d, 'shop.hagah.json')
        _json.dump(cmall_ref.store_file(v._cur['url'], 'new', sid, key, {'name': '파일 카페', 'cat': 'CAFE', 'extra': {k1: '음료 10%'}}),
                   open(sp, 'w', encoding='utf-8'))
        res = CA.take_store_files(v._file_mall(), [sp])
        v._show_main()
        v._refresh()
        spin(30)
        ck(res[0][1]['ok'] and any(x['id'] == sid and x['state'] == 'PENDING' for x in v._rows), '가게 파일 → 대기')
        v._set_state('PENDING')
        v._tv.selection_set(sid)
        spin()
        ck(('x:' + k1) in v._vals and v._vals['x:' + k1].get() == '음료 10%', '추가 칸이 모양대로 보인다')
        v._vals['x:' + k1].w.delete('1.0', 'end')
        v._vals['x:' + k1].w.insert('1.0', '음료 20%')
        v._save_fields()
        spin(20)
        v._act('publish')
        spin(30)
        v._make_file()
        p = v._last_file
        got = cmall_ref.read_mall_file(open(p, encoding='utf-8').read())
        ck(got and got['stores'][0]['extra'] == {k1: '음료 20%'} and got['form']['guide'].startswith('교인'), '몰 파일 — 고친 추가 칸 · 서식')
        v._pick_mall(0)
        spin(30)
        ck(not v._file_box.winfo_manager() and v._b_test.winfo_manager() and v._b_script.winfo_manager(), '시트 몰로 돌아가면 연결 시험 · 스크립트 복사')
    finally:
        appdb.connect = real
        root.destroy()
    print('cmall_view selftest %d/%d' % (ok, ok + len(bad)))
    for b in bad:
        print('  FAIL', b)
    return not bad


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
