# -*- coding: utf-8 -*-
"""성지순례 **길 모양**(2026-10-30 신설 · 영구) — 거점 탐방의 「거점」·「10km 둘레」 단계에서도 고른 곳을 잇는 실제 도로 선을 그린다
(사용자 「거점 탐방, 10km 모드에서도 이동경로 표시기능이 가능해야 한다」).

★ 거리·시간은 이미 있다(sys_pilgrim_near · sys_pilgrim_base_road) — 여기는 **선 모양만** 따로 담는다.
  옛 표에 칸을 더하지 않는 까닭: 폰이 옛 공통팩의 표를 갖고 있으면 칸이 모자라 새 팩 적재가 어긋날 수 있다(새 표는 안전).
★ 이 PC 의 도로 엔진(GraphHopper — 이스라엘·요르단·이집트 8989 · 튀르키예·그리스 8991)으로 잰다 · 선은 약 30m 로 덜어 낸다.

표(CORE · 폰 공통팩)
  sys_pilgrim_line  a TEXT · b TEXT · poly TEXT · PRIMARY KEY(a, b)
    열쇠 = 'P<용어>' · 'S<순례 장소>' · 'B<거점>' — a < b(글자 차례 · 폰은 거꾸로 찾으면 선을 뒤집는다)
    쌍 = sys_pilgrim_near 의 도로 MAX_ROAD_KM 안 쌍 + sys_pilgrim_base_road 의 차 MAX_BASE_MIN 분 안 쌍

  python db_pilgrim_line.py --selftest | --run [--redo] | --status
"""
import sys
import urllib.error

import appdb
import db_place_road as R

MAX_ROAD_KM = 30.0      # 10km 둘레 단계가 보이는 범위(10·20·30km)
MAX_BASE_MIN = 120.0    # 거점 단계가 보이는 범위(차로 2시간까지)
TOL = 0.0003            # 약 30m

DDL = """CREATE TABLE IF NOT EXISTS sys_pilgrim_line(
    a TEXT NOT NULL, b TEXT NOT NULL, poly TEXT, PRIMARY KEY(a, b))"""


def ensure(conn):
    conn.execute(DDL)


def coords(conn):
    """열쇠 → (위도, 경도)"""
    out = {}
    for p in R.places(conn, 'ALL'):
        out['P%d' % p[0]] = (p[1], p[2])
    for i, la, lo in conn.execute("SELECT site_id, lat, lng FROM sys_pilgrim_site WHERE lat IS NOT NULL"):
        out['S%d' % i] = (float(la), float(lo))
    try:
        for i, la, lo in conn.execute("SELECT base_id, lat, lng FROM sys_pilgrim_base"):
            out['B%d' % i] = (float(la), float(lo))
    except Exception:                                   # noqa: BLE001
        pass
    return out


def key(a, b):
    return (a, b) if a < b else (b, a)


def wanted(conn):
    """잴 쌍 — [(a, b)]"""
    out = set()
    for a, b in conn.execute('SELECT a_key, b_key FROM sys_pilgrim_near WHERE km<=?', (MAX_ROAD_KM,)):
        out.add(key(a, b))
    for bid, kind, tid in conn.execute('SELECT base_id, kind, target_id FROM sys_pilgrim_base_road WHERE minutes<=?',
                                       (MAX_BASE_MIN,)):
        out.add(key('B%d' % bid, '%s%d' % (kind, tid)))
    return sorted(out)


def run(conn, redo=False, say=print, path_fn=None):
    ensure(conn)
    xy = coords(conn)
    have = set() if redo else {(r[0], r[1]) for r in conn.execute('SELECT a, b FROM sys_pilgrim_line')}
    todo = [p for p in wanted(conn) if p not in have and p[0] in xy and p[1] in xy]

    def gh(pa, pb):
        eng = R.engine_of(pa[1], pa[2])
        try:
            return R._gh_path(eng, pa, pb, True)
        except urllib.error.HTTPError as e:
            if e.code != 400:
                raise
            return R._gh_path(eng, R.snap(pa), R.snap(pb), True)
    fn = path_fn or gh
    ok = fail = 0
    for n, (a, b) in enumerate(todo, 1):
        pa, pb = (a,) + xy[a], (b,) + xy[b]
        try:
            p = fn(pa, pb)
            pts = R.decode(p.get('points') or '') if p else []
            if len(pts) > 1:
                conn.execute('INSERT OR REPLACE INTO sys_pilgrim_line VALUES(?,?,?)', (a, b, R.encode(R.simplify(pts, TOL))))
                ok += 1
            else:
                fail += 1
        except Exception:                               # noqa: BLE001
            fail += 1
        if n % 200 == 0:
            conn.commit()
        if n % 2000 == 0:
            say('  %d/%d (받음 %d · 실패 %d)' % (n, len(todo), ok, fail))
    conn.commit()
    return len(todo), ok, fail


def status(conn):
    ensure(conn)
    n, size = conn.execute('SELECT COUNT(*), COALESCE(SUM(LENGTH(poly)),0) FROM sys_pilgrim_line').fetchone()
    print('잴 쌍 %d · 담은 선 %d · %.2f MB' % (len(wanted(conn)), n, size / 1e6))


def selftest():
    import sqlite3
    ok, bad = [0], [0]

    def ck(c, m, got=''):
        (ok if c else bad)[0] += 1
        print('  %s %s%s' % ('OK  ' if c else 'FAIL', m, '' if c else '  ← %s' % (got,)))
    ck(key('S5', 'P12') == ('P12', 'S5') and key('B1', 'S2') == ('B1', 'S2'), '열쇠 차례')
    c = sqlite3.connect(':memory:')
    c.execute('CREATE TABLE sys_pilgrim_near(a_key TEXT, b_key TEXT, km REAL, minutes REAL)')
    c.execute('CREATE TABLE sys_pilgrim_base_road(base_id INTEGER, kind TEXT, target_id INTEGER, km REAL, minutes REAL)')
    c.executemany('INSERT INTO sys_pilgrim_near VALUES(?,?,?,?)', [('P1', 'S2', 5, 8), ('P1', 'S3', 45, 50)])
    c.executemany('INSERT INTO sys_pilgrim_base_road VALUES(?,?,?,?,?)', [(1, 'S', 2, 20, 30), (1, 'P', 9, 200, 190)])
    w = wanted(c)
    ck(w == [('B1', 'S2'), ('P1', 'S2')], '잴 쌍 = 도로 30km · 차 2시간 안', w)
    import db_place_road as RR
    real_coords = globals()['coords']
    globals()['coords'] = lambda _c: {'P1': (31.0, 35.0), 'S2': (31.01, 35.0), 'B1': (31.02, 35.0)}
    try:
        def fake(pa, pb):
            return {'points': RR.encode([(pa[1], pa[2]), ((pa[1] + pb[1]) / 2, 35.0005), (pb[1], pb[2])])}
        ensure(c)
        res = run(c, say=lambda *_: None, path_fn=fake)
        ck(res == (2, 2, 0), '두 쌍 선 받음', res)
        poly = c.execute("SELECT poly FROM sys_pilgrim_line WHERE a='P1' AND b='S2'").fetchone()[0]
        ck(len(RR.decode(poly)) >= 2, '선이 풀린다')
        ck(run(c, say=lambda *_: None, path_fn=fake) == (0, 0, 0), '다시 돌리면 건너뛴다(멱등)')
    finally:
        globals()['coords'] = real_coords
    print('\ndb_pilgrim_line selftest %d/%d' % (ok[0], ok[0] + bad[0]))
    return bad[0] == 0


def main(a):
    if '--selftest' in a:
        return 0 if selftest() else 1
    conn = appdb.connect()
    if '--run' in a:
        print('잴 것 %d · 받음 %d · 실패 %d' % run(conn, redo='--redo' in a))
    status(conn)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
