# note_refr_panel.py
import sqlite3
import sys


def _quiet(msg):
    """오류를 조용히 알린다 — **`print` 를 쓰지 않는다**(§193차 ⑧ · §208차 ⑤).
    앱은 실행 중 `sys.stdout` 을 닫으므로(§97차) 종료 경로의 `print` 는
    `ValueError: I/O operation on closed file` 로 터진다."""
    try:
        sys.stderr.write(str(msg) + chr(10))
    except Exception:
        pass

import verse_ref
# ★★ 구간 판정은 **한 문**이다(§verse_range) — `verse_id` 는 신원이고
#   차례는 `sort_order` 다. 번호로 재면 절체계 이형 구간에서 샌다.
import verse_range as _vr
import appdb
import i18n
import webbrowser
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox

_VERSE_PREFIX = "관련구절 "


def count_for(db_path, verse_id):
    """P2 탭 배지용 개수 (2026-08-19 0.txt ①) — 목록과 같은 커버 조회.

    ⚠ 노트의 생애 상태는 NEW/EDIT — `LIVE` 로만 세면 전부 0 이 된다(notes.md §0)."""
    if not verse_id:
        return 0
    try:
        with appdb.connect(db_path) as conn:
            n = conn.execute(
                "SELECT COUNT(*) FROM user_text_asset "
                "WHERE text_type='VERS_NOTE' "
                "  AND record_status IN ('LIVE','NEW','EDIT') "
                "  AND "
                + _vr.covers_sql('user_text_asset', 'clicked_id', 'target_id'),
                _vr.covers_args(verse_id)).fetchone()[0]
            # ★ 편 닻 노트도 함께 센다 — 목록과 배지가 어긋나면 안 된다
            import medi_note
            return n + medi_note.count_unit_notes_for_verse(conn, verse_id)
    except Exception:
        return 0



def _c(role, dflt):
    """테마 색. 카드 배경·글자를 여기서 가져온다 (2026-08-15).

    ⚠ 박힌 색을 쓰면 테마를 바꿔도 이 화면만 남는다 — 실제로 그렇게 지었다가 고쳤다.
    """
    try:
        import ui_theme
        return ui_theme.C(role)
    except Exception:
        return dflt


class NoteRefrPanel(ttk.Frame):
    """
    재사용 가능한 묵상노트/참고자료 CRUD 패널.
    - 상단: [+ 새 항목] [저장] [삭제]  |  [관련구절 창1:1]
    - 참고자료 표시 영역: sys_text_asset VERS_QUESTION / VERS_PRAYER (관리자 입력, 읽기전용)
    - 하단 좌: 레코드 목록
    - 하단 우: 제목 입력 + 내용 편집기
    """
    def __init__(self, parent, db_path, text_type, lang_code_getter, **kwargs):
        super().__init__(parent, **kwargs)
        self.db_path = db_path
        self.text_type = text_type          # 'VERS_NOTE' or 'VERS_REFR'
        self.lang_code_getter = lang_code_getter  # callable → current lang str
        self.clicked_id = None              # 클릭한 구절 verse_id (범위 기준)
        self.current_record_id = None
        self._records = []
        self._verse_label = ""              # "창 1:1" 또는 "창 1:1~3" 형태 (현재 범위)
        self._chap_verses = []              # [(verse_num, verse_id)] — 클릭 구절의 장 전체
        self._book_short = ""               # 책 약명
        self._chap = None                   # 장 번호
        self._clicked_verse_num = None      # 클릭한 절 번호
        self._build_ui()

    def set_ai_note(self, cb):
        """[AI묵상분석] 단추를 건다 — `cb(verse_id)` · 걸면 [+ 추가하기]와 [기호] 사이에 보인다."""
        self.on_ai_note = cb
        try:
            if cb and not self._ai_note_btn.winfo_manager():
                self._ai_note_btn.pack(side='right', padx=2, before=self._add_btn)
            elif not cb and self._ai_note_btn.winfo_manager():
                self._ai_note_btn.pack_forget()
        except Exception as e:
            _quiet(f'[note ai btn] {e}')

    def _ai_note_click(self):
        if callable(self.on_ai_note) and self.clicked_id:
            try:
                self._autosave()
            except Exception:
                pass
            self.on_ai_note(self.clicked_id)

    def _build_ui(self):
        # ★ **상단 묵상질문·묵상기도 칸을 없앴다 (2026-08-15 사용자 지시).**
        #   같은 글이 P2 탭1 「설명」 Lay 모드에 이미 나온다(§3-1 `MODE_SECTIONS`).
        #   두 탭에 같은 것이 있으면 어느 쪽이 진짜인지 헷갈리고, 노트 쓰는 자리만 좁아졌다.
        #   ⚠ 질문만 빼면 기도만 남아 어색하다 — **칸째로** 뺀다.

        # 버튼 바 — 관련구절 레이블 좌측, CRUD 버튼 우측
        # ★ 2026-10-15 — 단추 줄 바탕도 역할로(박힌 #EAECEE 가 어두운 화면색에서 흰 띠로 남았다 · 사용자 두 번 지적)
        btn_bar = tk.Frame(self, bg=_c('panel_alt', '#EAECEE'))
        btn_bar.pack(fill='x', padx=4, pady=3)
        self._btn_bar = btn_bar

        # ★★ **좌측 = 「연결구간: 창1:1~4  시작 [콤보]  종료 [콤보]」**
        #   (2026-08-30 사용자 지시 0.txt 1-3 의 차례 그대로).
        #   ⚠⚠ 그전에는 `[콤보] 창1:1~4 [콤보]` 로 **글자 라벨이 하나도 없어**
        #     무엇을 고르는 칸인지 읽히지 않았다(콤보 둘이 맨몸으로 붙어 있었다).
        #   ⚠ 라벨 색은 역할로 — 굳은 색을 새로 짓지 않는다(§0).
        # ★★★ **구간 칸은 글을 쓸 때만 보인다** (2026-08-30 사용자 지시 0.txt
        #   1-2 「탭 화면에 들어가자 마자 연결구간 표시, 시작~종료 구간 표시가
        #   표시되는 것이 어색하다. **[+ 추가하기] 를 클릭한 다음에 표시되는
        #   것이 가장 이상적이다.** 대신, 저장된 후에는 사라지고 결과값만
        #   표시해야 한다. 그리고, 수정하려면 구간 입력 화면이 표시되어야 한다」).
        #   ⇒ 구간은 **패널의 것이 아니라 그 노트의 것**이다. 카드가 펼쳐져
        #     있을 때만 보이고, 접히면 사라진다. **결과값**(창1:1~4)은 접힌
        #     카드의 회색 정보 줄이 **이미** 보이고 있다(`meta_line`).
        #   ⚠ **위젯을 카드 안으로 옮기지는 않았다** — Tk 는 다른 부모로 못
        #     옮기고, 카드는 그릴 때마다 파괴된다. 그 안에 두면 자동저장이
        #     죽은 위젯을 읽는다(§기호판 사고와 같은 자리). 보이고 감추는 것으로
        #     같은 결과를 낸다.
        _bb = _c('panel_alt', '#EAECEE')
        rng = tk.Frame(btn_bar, bg=_bb)
        self._rng_f = rng
        tk.Label(rng, text=i18n.t('NR_RANGE', '연결구간:'), bg=_bb,
                 fg=_c('fg_dim', '#5D6D7E'), font=('', 9)).pack(side='left')
        self.verse_lbl = tk.Label(
            rng, text="", bg=_bb,
            font=('', 9, "bold"), fg=_c('accent', '#1A5276'), padx=5
        )
        self.verse_lbl.pack(side='left')
        tk.Label(rng, text=i18n.t('NR_START', '시작'), bg=_bb,
                 fg=_c('fg_dim', '#5D6D7E'), font=('', 9)).pack(side='left',
                                                                padx=(8, 2))
        self._v_start = ttk.Combobox(rng, width=3, state='readonly',
                                     font=('', 9))
        self._v_start.pack(side='left')
        tk.Label(rng, text=i18n.t('NR_END', '종료'), bg=_bb,
                 fg=_c('fg_dim', '#5D6D7E'), font=('', 9)).pack(side='left',
                                                                padx=(8, 2))
        self._v_end = ttk.Combobox(rng, width=3, state='readonly',
                                   font=('', 9))
        self._v_end.pack(side='left')
        self._v_start.bind('<<ComboboxSelected>>', self._on_range_change)
        self._v_end.bind('<<ComboboxSelected>>', self._on_range_change)
        # ⚠ 콤보를 고르면 **포커스가 안 옮겨질 수도 있다** — 그 자리에서 저장한다
        self._v_start.bind('<<ComboboxSelected>>', lambda _e: self._autosave(), add='+')
        self._v_end.bind('<<ComboboxSelected>>', lambda _e: self._autosave(), add='+')

        # ★ **저장·삭제 단추를 뺐다** (2026-08-15 사용자 지시).
        #   저장은 **칸을 벗어날 때 저절로** 되고(`_autosave`), 삭제는 댓글마다 ✕ 다.
        #   위에 두면 「어느 댓글을 지우는 것인가」가 안 보인다.
        # ★ 2026-10-15 88-1 — 누른 색(activebackground)을 역할로. 비워 두면 Tk 기본(SystemButtonFace)이라
        #   어두운 화면색에서 누르는 순간 단추가 **흰색**으로 바뀌었다(P2 실측 · 캔버스 쪽은 paint 가 덮어 멀쩡했다).
        btn_cfg = dict(font=('', 9, "bold"), bd=0, padx=8, pady=3,
                       activebackground=_c('select_bg', '#D6EAF8'), activeforeground=_c('fg', '#1A1A1A'))
        # ★★ **오른쪽 차례 = `+추가 · 저장 · (공백) · 기호`**
        #   `side='right'` 는 부른 차례로 오른쪽부터 쌓이므로 **거꾸로 붙인다**.
        # ⚠⚠ **[태그] 단추를 걷었다** (2026-08-30 사용자 확정 — 「지금 태그
        #   연결만 따로 취급하고 있다. 결국 **My Edit 가 서브탭 3개에 모두
        #   적용된다면 태그 버튼 자체도 삭제해도 좋다**」).
        #   ⇒ 태그 잇기·연결 해제는 **갈래 줄의 공통 [My Edit]** 이 맡는다. 그 팝업은
        #     묵상노트를 **출발지**로 열므로 「이 노트의 태그」가 된다 — 구절을
        #     출발지로 삼던 그전과 달라진 점이 이것이다.
        #   ★ 여기에 단추를 남기면 **같은 일에 입구가 둘**이고, 그중 하나(태그
        #     고르기)는 파생 태그를 못 뗀다 — 그래서 없애는 것이 맞다.
        # ★ **기호 단추** (2026-08-23 사용자 「연구자료/묵상노트 추가작성 또는
        #   수정할 때에도 표시하라 … 버튼 배치하고 클릭하면 Recent 방식으로」).
        #   ⚠⚠ **자동 저장을 그 사이 멈춘다.** 판은 딴 창이라 열리는 순간 글칸이
        #     `<FocusOut>` 을 받고, 그 신호로 `_autosave` → `_save_record` →
        #     `_refresh_list` 가 돌아 **글칸을 통째로 새로 만든다**. 그러면 넣을
        #     칸이 이미 죽어 있어 **오류도 없이 기호만 사라진다**(실측).
        try:
            import symbol_picker
            symbol_picker.button(
                btn_bar, lambda: getattr(self, 'contents_txt', None),
                text=i18n.t('MP_SYMBOLS', '기호'),
                on_open=lambda: setattr(self, '_sym_open', True),
                on_close=lambda: setattr(self, '_sym_open', False),
                db_path=self.db_path,          # 판을 끌어 둔 자리를 기억한다
            ).pack(side='right', padx=(2, 10))
        except Exception as e:
            _quiet(f'[note symbol] {e}')
        # ★ [저장] 단추를 걷었다 (2026-09-15 `1.txt` 14번 사용자 「저장버튼 없애고
        #   자동저장 되도록 하자」) — 칸을 벗어나면 저절로 저장된다(`_autosave`).
        #   단추가 남아 있으면 「눌러야 저장되나」를 매번 묻게 된다.
        self._add_btn = tk.Button(btn_bar, text=i18n.t('NR_NEWITEM','+ 추가하기'), command=self._new_record,
                                  bg=_c('accent_bg', '#AED6F1'), fg=_c('accent', '#1A5276'), **btn_cfg)
        self._add_btn.pack(side='right', padx=2)
        # ★ 317차-15 — [AI묵상분석](추가하기와 기호 사이) — 부르는 쪽이 `set_ai_note` 로 걸 때만 보인다
        self._ai_note_btn = tk.Button(btn_bar, text=i18n.t('NR_AI_NOTE', 'AI묵상분석'),
                                      command=self._ai_note_click,
                                      bg=_c('accent_bg', '#AED6F1'), fg=_c('accent', '#1A5276'), **btn_cfg)
        self.on_ai_note = None
        # ★★★ **태그 칩 줄을 걷었다 — 하단 연결자료 띠로 내렸다**
        #   (2026-08-30 사용자 지시 0.txt 1-3 「상단 태그 버튼 및 태그이름
        #   표시하는 구간은 삭제함 / 하단 : 연구자료·내부연결 탭의 하단 연결자료
        #   표시구간과 동일하게 표시(여기에 연결된 태그이름을 표시함)」).
        #   ⚠ 그 줄이 **한 줄을 통째로** 먹고 있었다(칩이 많으면 더). 글 쓰는
        #     화면에서 그만큼이 본문 자리가 된다.
        #   ⚠ [태그] **단추는 위 줄로 옮겼다** — 함께 없애면 태그를 다는 길이
        #     사라진다(§0-1 「기능을 조용히 없애지 않는다」).

        # ── 하단 연결자료 띠 (2026-08-30 신설) ───────────────────────────
        #   ★ 연구자료/내부연결 탭과 **같은 모양**이다. 다만 저 화면은 「고른
        #     자료의 연결」을 보이고, 여기는 **이 구절에 걸린 태그**를 보인다
        #     (묵상노트의 닻은 언제나 구절이다 — `notes.md` §0-1).
        #   ⚠ 그 자리에 쓰이는 이름·셈 규칙은 `refr_unified_panel` 것을 그대로
        #     쓴다 — 두 곳에서 따로 지으면 같은 것이 다른 이름·다른 수로 보인다.
        self._link_strip = tk.Text(self, height=2, wrap='word', bd=1,
                                   relief='solid', font=('Malgun Gothic', 9),
                                   bg=_c('panel_alt', '#F7F9F9'),
                                   fg=_c('fg', '#34495E'),
                                   state='disabled', cursor='arrow')
        self._link_strip.pack(side='bottom', fill='x', padx=4, pady=(2, 4))

        # ★ **댓글 스타일** (2026-08-15 사용자 지시).
        #   예전에는 좌(제목만 목록) + 우(편집기) 라 **한 번에 하나**만 보였다.
        #   그런데 같은 절에 글이 여러 개 쌓여 있어(실측 2건) 나머지가 안 보였다.
        #   위에 카드 목록(날짜·제목·미리보기), 아래에 편집기.
        body_pw = tk.PanedWindow(self, orient='vertical', sashwidth=4, bg=_c('border', '#D5DBDB'))
        body_pw.pack(expand=True, fill='both', padx=4, pady=(0, 4))
        self._body_pw = body_pw

        # 카드 스택 — 카드마다 진짜 프레임. 접었다 펴는 것이 자연스럽다.
        wrap = tk.Frame(body_pw, bg=_c('bg', '#FDFEFE'))
        body_pw.add(wrap)
        self._cv = tk.Canvas(wrap, bg=_c('bg', '#FDFEFE'), highlightthickness=0)
        cv_sb = ttk.Scrollbar(wrap, orient='vertical', command=self._cv.yview)
        self._cv.config(yscrollcommand=cv_sb.set)
        cv_sb.pack(side='right', fill='y')
        self._cv.pack(side='left', fill='both', expand=True)
        self._stack = tk.Frame(self._cv, bg=_c('bg', '#FDFEFE'))
        self._stack_win = self._cv.create_window((0, 0), window=self._stack, anchor='nw')
        # ⚠ 안쪽 프레임 폭을 캔버스에 맞춘다 — 안 맞추면 카드가 안 늘어난다
        self._cv.bind('<Configure>',
                      lambda e: self._cv.itemconfig(self._stack_win, width=e.width))
        self._stack.bind('<Configure>',
                         lambda e: self._cv.config(scrollregion=self._cv.bbox('all')))
        # ★ **마우스 휠** (2026-08-15 사용자 지적 「마우스로 스크롤 안 된다」).
        #   ⚠ 카드 안쪽 위젯에 커서가 있으면 **그 위젯이 휠을 먹는다.** 카드는
        #     다시 그릴 때마다 새로 만들어지므로 하나하나 걸 수 없다.
        #     ⇒ 들어올 때 `bind_all`, 나갈 때 푼다. 자식이 바뀌어도 따라온다.
        wrap.bind('<Enter>', lambda _e: self._cv.bind_all('<MouseWheel>', self._on_wheel))
        wrap.bind('<Leave>', lambda _e: self._cv.unbind_all('<MouseWheel>'))

        # 저장 로직이 읽는 이름 — 펼친 카드가 만든다
        self.title_ent = None
        self.contents_txt = None
        self._open_idx = None          # 펼친 카드 (정수) 또는 'NEW'
        # ★ 호스트가 달면 글을 쓰거나 지운 뒤 부른다(배지 = 목록 · 2026-09-15).
        #   `links_panel.on_changed` 와 같은 문법. 없으면 아무 일도 없다.
        self.on_changed = None

    # ── 연결자료 띠 (파생 + 내가 단 태그) ─────────────────────────
    def _refresh_tags(self):
        """이 구절에 걸린 태그를 **하단 띠 한 줄**로 그린다 (2026-08-30 개편).

        ★ **파생 + 내가 단 것이 결합된다**(사용자 지시 「묵상노트의 태그는
          구절에 연결된 태그와 사용자가 연결하는 태그가 결합/추가되어야」).
          파생 = 그 절의 엔티티·렌즈·체인에서 저절로 온 것이고 **뗄 수 없다** —
          그 절의 연결에서 나온 것이라 태그만 떼는 것은 말이 안 된다.
          내가 단 것은 `(N)` 표식으로 갈린다(`overlay_mark` 한 곳에서 온다).
        ⚠ 이름·셈은 `refr_unified_panel` 의 것을 그대로 쓴다 — 같은 것이 화면
          마다 다른 이름·다른 수로 보이면 안 된다.
        ⚠ 함수 이름은 그대로 둔다 — 부르는 자리가 넷이다(`load`·저장·태그 편집)."""
        strip = getattr(self, '_link_strip', None)
        if strip is None:
            return

        def _put(text):
            strip.configure(state='normal')
            strip.delete('1.0', 'end')
            strip.insert('1.0', text or '')
            strip.configure(state='disabled')

        lang = self.lang_code_getter() or 'KO'
        nid = getattr(self, 'current_record_id', None)

        # ★★★ **고른 노트의 연결을 보인다** (2026-08-30 사용자 신고 「용어/태그를
        #   묵상노트에 연결했는데 연결된 결과가 묵상노트 아래에 표시되지 않는다.
        #   **어떤 노트를 클릭해도 「목숨」이 연결되었다고 표시**한다」).
        #   ⚠⚠ 그전에는 **구절의 파생 태그**만 읽었다 — 그러니 같은 절의 노트가
        #     열이어도 **전부 같은 줄**이 떴고, 노트에 새로 단 태그는 **아예
        #     안 보였다.** 묵상노트가 자산이 된 지금은 **그 노트가 주인**이다.
        #   ★ 노트를 안 골랐으면 **그 구절의 태그**를 보인다(맥락) — 무엇을
        #     보고 있는지 이름으로 갈라 말한다.
        if nid:
            # ⚠ `links_of` 는 **자산 + 태그를 함께** 낸다(2026-08-25 통합) —
            #   여기서 태그를 또 물으면 같은 이름이 두 번 뜬다.
            try:
                import link_picker as LP
                names, seen = [], set()
                with appdb.connect(self.db_path) as conn:
                    for x in LP.links_of(conn, 'NOTE', int(nid), lang,
                                         scope='USER'):
                        nm = x.get('label')
                        if nm and nm not in seen:
                            seen.add(nm)
                            names.append(nm)
            except Exception as e:
                _quiet('[note links] %s' % e)
                names = []
            if names:
                _put('%s (%d) · %s' % (i18n.t('REFR_LINKED', '연결 자료'),
                                       len(names), ' · '.join(names)))
            else:
                _put(i18n.t('NR_NO_LINK',
                            '이 노트에 연결된 것이 없습니다. [My Edit] 로 이어 보세요.'))
            return

        # ⚠⚠ **「이 구절의 태그」를 걷었다** (2026-08-30 사용자 지시 「하단에
        #   "이 구절의 태그" 표시하는 것 제거하라. **혼란소지가 있다.** 이미
        #   P1 하단에 용어 연결된 목록이 표시되기 때문이다」).
        #   ⇒ 이 띠는 **고른 노트의 것만** 말한다. 노트를 안 골랐으면 무엇을
        #     고르라고만 한다 — 구절 태그를 여기서 또 보이면 P1 티커와 두 벌이고,
        #     「어떤 노트를 눌러도 같은 줄」이라는 그 혼란이 되돌아온다.
        _put(i18n.t('NR_PICK_FOR_LINK', '노트를 클릭하면 그 노트의 연결이 여기 보입니다.'))

    def _edit_verse_tags(self):
        """[태그] — **통합 연결팝업**을 「용어」 갈래가 눌린 채로 연다.

        ★★★ **태그 고르기 직접 호출을 그만뒀다** (2026-08-30 사용자 지시
          0.txt 1-2 「태그를 다른 연결대상 자산과 **동일한 패턴에 흡수**하여
          통합연결팝업에 수용하라」).
        ⚠⚠ **왜 바꿨나 — 「제거가 안 된다」의 진짜 원인.** 이 화면에 보이는
          태그는 옛 `tag_derive`(2026-09-18 참고코드/)가 내던 것이라 **파생 태그가 섞여 있었다**(실측:
          창1:1 은 화면에 「창조하다」 1개인데 `tags_of` 는 **0개**).
          파생 태그는 그 절의 엔티티 연결(`ENTI_VERS`)에서 나온 것이라
          태그 고르기 목록에 **아예 없고**, 그래서 찾을 수도 뗄 수도 없었다.
          그것을 떼려면 **밑에 깔린 연결을 숨겨야** 하고 그 일은 작업대의 몫이다.
        ★ 중간 절차를 없애려던 본뜻(사용자)은 `pick_kind` 로 지킨다 — 팝업이
          열리자마자 **「용어」 갈래가 눌려 있다.** 연구자료·영상링크와 같은 문법.
        ★ 축 거르기·원어 검색은 작업대로 **옮겨 갔다**(`link_picker` 축 필터) —
          흡수가 기능을 줄이는 일이 되지 않게.
        ⚠ 닻은 언제나 **구절**이다 — 노트마다 따로 달면 같은 절에 노트가 둘일 때
          태그가 갈린다(`notes.md` §0-1 과 같은 원칙)."""
        if not self.clicked_id:
            return
        try:
            import my_edit
            my_edit.open(self, kind='VERSE', asset_id=self.clicked_id,
                         on_changed=lambda _w=None: self._refresh_tags(),
                         pick_kind='ENTITY',
                         pick_label=i18n.t('TAG_BTN', '태그'))
        except Exception as e:
            _quiet('[note tag edit] %s' % e)
            # ⚠ 폴백을 남긴다 — 팝업이 안 뜨는 자리에서 조용히 아무 일도 안 하면
            #   그것이 더 나쁘다(§0-1). 옛 길은 붙이기까지는 제대로 한다.
            try:
                import tag_picker
                lang = self.lang_code_getter() or 'KO'
                cur = {(s, t) for s, t, _n, _c in tag_picker.tags_of(
                    self.db_path, 'VERSE', self.clicked_id, lang)}
                got = tag_picker.pick(self, self.db_path, cur, lang)
                if got is not None:
                    tag_picker.save_links(self.db_path, 'VERSE',
                                          self.clicked_id, got)
                    self._refresh_tags()
            except Exception as e2:
                _quiet('[note tag fallback] %s' % e2)

    # ── 외부 API ──────────────────────────────────────────────────

    def load(self, clicked_id):
        """구절이 바뀔 때 외부에서 호출. clicked_id는 정수 verse_id."""
        # ★ **여기가 자동저장의 자리다** — `clicked_id` 를 바꾸기 **전**이다.
        #   `_refresh_list` 안에서 부르면 이미 늦어, 쓰던 글이 **옮겨 간 절에**
        #   `current_record_id=None` 인 채 **새 행으로** 생긴다(실측 26→27행).
        self._autosave()
        self.clicked_id = int(clicked_id) if clicked_id else None
        self.current_record_id = None
        self._load_chapter_verses(self.clicked_id)   # 장 전체 절 + 콤보 기준 세팅
        self._reset_range_to_clicked()               # 콤보 기본 = 클릭 절
        self._load_qp_refs()
        self._refresh_list()
        self._refresh_tags()          # 그 구절의 태그(파생 + 내 것) — 2026-08-21
        self._clear_editor()

    # ── 구절 범위 컨트롤 ──────────────────────────────────────────────

    def _load_chapter_verses(self, verse_id):
        """클릭 구절이 속한 장의 (절번호, verse_id) 목록 + 책약명/장/클릭절번호 적재."""
        self._chap_verses = []
        self._book_short = ""
        self._chap = None
        self._clicked_verse_num = None
        if not verse_id:
            return
        lang = self.lang_code_getter() if self.lang_code_getter else 'KO'
        try:
            with appdb.connect(self.db_path) as conn:
                base = conn.execute(
                    "SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?",
                    (verse_id,)).fetchone()
                if not base:
                    return
                bcode, chap, vnum = base
                self._chap = chap
                self._clicked_verse_num = vnum
                sn = conn.execute(
                    "SELECT short_name FROM book_names WHERE book_code=? "
                    "AND lang_code IN (?,'EN','KO') "
                    "ORDER BY CASE lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                    (bcode, lang, lang)).fetchone()
                self._book_short = (sn[0] if sn else str(bcode))
                self._chap_verses = [(r[0], r[1]) for r in conn.execute(
                    "SELECT verse, verse_id FROM bible_index WHERE bcode=? AND chapter=? "
                    "ORDER BY verse", (bcode, chap)).fetchall()]
        except Exception:
            pass

    def _reset_range_to_clicked(self):
        """콤보 시작=끝=클릭 절로 초기화."""
        vn = self._clicked_verse_num
        if vn is None or not self._chap_verses:
            self._v_start.config(values=[], state='disabled'); self._v_start.set('')
            self._v_end.config(values=[], state='disabled'); self._v_end.set('')
            self.verse_lbl.config(text='')
            return
        self._set_combo_ranges(vn, vn)

    def _set_combo_ranges(self, start_num, end_num):
        """시작콤보=1..클릭절, 끝콤보=클릭절..장끝. 값 세팅 후 라벨 갱신."""
        nums = [v for v, _ in self._chap_verses]
        cv = self._clicked_verse_num
        starts = [str(v) for v in nums if v <= cv]
        ends = [str(v) for v in nums if v >= cv]
        self._v_start.config(values=starts, state='readonly')
        self._v_end.config(values=ends, state='readonly')
        self._v_start.set(str(start_num))
        self._v_end.set(str(end_num))
        self._update_range_label()

    def _on_range_change(self, _evt=None):
        """콤보 변경 → 시작>끝 보정 후 라벨 갱신."""
        try:
            s = int(self._v_start.get()); e = int(self._v_end.get())
        except (ValueError, TypeError):
            return
        if s > e:   # 교차 시 클릭 절 기준으로 보정
            if self._v_start.focus_get() is self._v_start:
                self._v_end.set(str(s))
            else:
                self._v_start.set(str(e))
        self._update_range_label()

    def _update_range_label(self):
        """기준 절(단일) 또는 범위(단3:13~18)를 라벨에 표시."""
        try:
            s = int(self._v_start.get()); e = int(self._v_end.get())
        except (ValueError, TypeError):
            self.verse_lbl.config(text=''); return
        if s == e:
            txt = f"{self._book_short} {self._chap}:{s}"
        else:
            txt = f"{self._book_short} {self._chap}:{s}~{e}"
        self._verse_label = txt
        self.verse_lbl.config(text=txt)

    def _current_range_vids(self):
        """현재 콤보 → (start_vid, end_vid). 실패 시 (clicked_id, clicked_id)."""
        vmap = {v: vid for v, vid in self._chap_verses}
        try:
            s = int(self._v_start.get()); e = int(self._v_end.get())
            return vmap.get(s, self.clicked_id), vmap.get(e, self.clicked_id)
        except (ValueError, TypeError):
            return self.clicked_id, self.clicked_id

    # ── 내부 로직 ─────────────────────────────────────────────────

    def _load_qp_refs(self):
        """(2026-08-15) 상단 묵상질문·묵상기도 칸이 없어져 할 일이 없다.

        ⚠ **부르는 곳을 지우지 않고 여기를 비웠다** — 이 함수는 절이 바뀔 때마다
          여러 경로에서 불린다. 호출부를 일일이 걷어내면 하나를 놓쳤을 때 조용히 터진다.
        """
        return

    def _get_verse_label(self, verse_id):
        """verse_id → '창 1:1' 형태의 약명 반환. 실패 시 빈 문자열."""
        if not verse_id:
            return ""
        lang = self.lang_code_getter() if self.lang_code_getter else 'KO'
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT bn.short_name, bi.chapter, bi.verse "
                    "FROM bible_index bi "
                    "JOIN book_names bn ON bi.bcode = bn.book_code AND bn.lang_code = ? "
                    "WHERE bi.verse_id = ?",
                    (lang, verse_id)
                ).fetchone()
            if row:
                return verse_ref.label(verse_ref.SCOPE_BOOK, row[0], row[1], row[2])
        except Exception:
            pass
        return str(verse_id)

    def _refresh_list(self):
        self._sel_idx = None
        self._open_idx = None         # ⚠ **이것을 안 비워서** 앞 절에서 펼친 번호가
        #   남아 새 절의 그 카드가 펼쳐진 채 떴다(「접기를 눌러야 글씨가 보인다」).
        self._shown = self._PAGE      # 절을 옮기면 페이지를 처음으로
        self._records = []
        if not self.clicked_id:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                # 범위 포함 조회: 노트의 [clicked_id, target_id]가 클릭 구절을 포함하면 표시
                # (단일 노트는 target_id 0/NULL → clicked_id 로 폴백, 기존 동작 유지)
                rows = conn.execute(
                    "SELECT user_text_id, title, contents, created_at, updated_at, "
                    "       clicked_id, target_id "
                    "FROM user_text_asset "
                    "WHERE text_type=? AND record_status IN ('LIVE','NEW','EDIT') "
                    "  AND "
                    + _vr.covers_sql('user_text_asset', 'clicked_id',
                                     'target_id') + " "
                    # ★ **최근 글이 위** (2026-08-16 사용자 지시).
                    #   고친 날이 있으면 그것을, 없으면 만든 날을 본다.
                    "ORDER BY COALESCE(updated_at, created_at) DESC, "
                    "         user_text_id DESC",
                    [self.text_type] + _vr.covers_args(self.clicked_id)
                ).fetchall()
                # ★★ **편 닻 노트를 합친다** (2026-08-24) — 도서묵상노트는
                #   편에 달리고, 그 편에 기준 구절이 있으면 여기 함께 보인다.
                #   ⚠ 묵상노트 갈래에서만 — 연구자료(`VERS_REFR`)는 다른 것이다.
                if self.text_type == 'VERS_NOTE':
                    import medi_note
                    rows = list(rows) + list(
                        medi_note.unit_notes_for_verse(conn, self.clicked_id))
                    rows.sort(key=lambda r: ((r[4] or r[3] or ''), r[0]),
                              reverse=True)
        except Exception as e:
            _quiet('[note load] %s' % e)
            rows = []
        for row in rows:
            rec_id, title, contents, created_at, updated_at, start_vid, end_vid = row
            self._records.append({
                'id': rec_id, 'title': title, 'contents': contents,
                'created_at': created_at, 'updated_at': updated_at,
                'start_vid': start_vid, 'end_vid': (end_vid or start_vid),
            })
        self._render_cards()

    _PAGE = 30         # 한 번에 그리는 장수 — 실측으로 정했다(67ms)

    def _preview_len(self):
        """접힘 카드에서 몇 자까지 보일까 — **분량을 따라간다** (2026-08-15 사용자 지시).

        「댓글이 하나 뿐이라면 그냥 전문을 표시하면 된다」.
        하나뿐인데 50자에서 자르면 `…` 을 눌러야 나머지를 볼 수 있는데,
        그 아래에 다른 메모도 없다 — 접을 이유가 없다.
        """
        n = len(self._records)
        if n <= 1:
            return None        # 전문
        return 200 if n <= 3 else 50

    def _on_wheel(self, e):
        """휠 한 칸에 세 줄. 편집칸 안에서는 캔버스를 움직이지 않는다."""
        w = self.contents_txt
        if w is not None and str(e.widget) == str(w):
            return                      # 글 쓰는 칸 안이면 그쪽에 맡긴다
        self._cv.yview_scroll(-1 * (e.delta // 120) * 3, 'units')

    def _show_more(self):
        self._shown = getattr(self, '_shown', self._PAGE) + self._PAGE
        self._render_cards()

    def _sync_rng_vis(self):
        """구간 칸 — **카드를 펼쳤을 때만** 보인다 (2026-08-30, 위 설명 참조).

        ⚠ `side='left'` 로 다시 붙이면 왼쪽 첫 자리로 돌아온다(그 줄의 왼쪽에는
          다른 것이 없다). 차례가 흔들리지 않는다."""
        f = getattr(self, '_rng_f', None)
        if f is None or not f.winfo_exists():
            return
        want = self._open_idx is not None
        try:
            if want and not f.winfo_manager():
                f.pack(side='left', padx=(6, 0))
            elif not want and f.winfo_manager():
                f.pack_forget()
        except Exception:
            pass

    def _render_cards(self):
        """카드 스택을 다시 그린다. 펼친 카드만 편집칸을 갖는다."""
        self._sync_rng_vis()      # 구간 칸은 펼친 카드의 것이다
        # ★★ **띠도 함께 다시 그린다** (2026-08-30 사용자 신고 「**어떤 노트를
        #   클릭해도** 「목숨」이 연결되었다고 표시한다」). 띠가 **고른 노트의
        #   것**이 된 뒤로는, 카드를 열고 닫을 때마다 따라와야 한다.
        #   ⚠ 여기 한 곳에 두면 `_open_card`·`_close_card`·`_new_record`·
        #     `_show_more` 가 **전부** 따라온다 — 네 곳에 흩으면 하나를 빠뜨린다.
        try:
            self._refresh_tags()
        except Exception as e:
            _quiet('[note strip] %s' % e)
        for w in self._stack.winfo_children():
            w.destroy()
        self.title_ent = self.contents_txt = None

        if not self._records and self._open_idx != 'NEW':
            tk.Label(self._stack, text=i18n.t('NR_EMPTY', '아직 메모가 없습니다.'),
                     bg=_c('bg', '#FDFEFE'), fg=_c('fg_dim', '#95A5A6'),
                     anchor='w').pack(fill='x', padx=8, pady=8)
        # ⚠ **한 번에 30장까지.** 실측 — 30장 67ms · 100장 180ms · 300장 550ms.
        #   매번 전부 부수고 다시 만들기 때문이다. 최근 것부터 보이고 나머지는 미룬다.
        # ★ **새 글이 맨 위** (2026-08-16 사용자 지시). 예전에는 끝에 붙여서,
        #   글이 여러 개면 **화면 밖**에 입력칸이 생겼다.
        if self._open_idx == 'NEW':
            self._card(None, None)
        n = len(self._records)
        shown = getattr(self, '_shown', self._PAGE)
        # ⚠ 목록이 **최근 것부터**라 앞에서 자른다. 예전처럼 뒤에서 자르면
        #   가장 오래된 30장이 보인다 — 정렬만 뒤집고 여기를 안 고치면 그렇게 된다.
        last = min(n, shown)
        for i in range(last):
            self._card(i, self._records[i])
        if n > last:
            tk.Button(self._stack,
                      text=i18n.t('NR_MORE', '이전 메모 %d개 더 보기') % (n - last),
                      bd=1, relief='raised', cursor='hand2', command=self._show_more
                      ).pack(fill='x', padx=6, pady=(3, 0))
        # ★★★ **함께 나눈 글** — 공동체 묵상 3단계(2026-09-08).
        #   ⚠ **내 글 아래**에 둔다 — 「먼저 쓰고 그다음 읽는다」가 묵상의
        #     순서이고, 화면이 그 순서를 지켜야 한다(설계 §3-1).
        try:
            self._render_shared()
        except Exception as e:
            _quiet('[shared] %s' % e)
        # 카드 안 글자도 **통합 폰트**를 따른다 (2026-08-15).
        # ⚠ 다시 그릴 때마다 불러야 한다 — 위젯을 매번 새로 만들기 때문이다.
        try:
            import theme_font
            theme_font.scale(self._stack, self.db_path)
        except Exception:
            pass
        self._stack.update_idletasks()
        self._cv.config(scrollregion=self._cv.bbox('all'))
        # ★ 방금 만든 카드에 화면색 (2026-08-17) — 카드는 **누를 때** 새로 만들어져
        #   탭 열 때 도는 `ui_theme.paint` 가 못 본다. 렌즈 카드에서 실측으로 잡은
        #   것과 같은 병이고, 이 패널은 구절노트·렌즈 내 묵상이 함께 쓴다.
        try:
            import ui_theme
            if ui_theme.current() != ui_theme.DEFAULT:
                ui_theme.paint(self._stack)
        except Exception:
            pass

    # ── 함께 나눈 글 (공동체 묵상 3단계) ─────────────────────────────
    def _render_shared(self):
        """이 구절에 달린 **남의 나눔글**.

        ★★★ 설계 §3-1 — 「나눔은 **접어 둔다**(개수만). 열자마자 남의 글이
          쏟아지면 내 묵상을 쓰기 전에 읽게 된다. **먼저 쓰고 그다음 읽는다**가
          묵상의 순서이고, 화면이 그 순서를 지켜야 한다.」
        ⚠ **방이 없거나 받은 글이 없으면 아무것도 안 그린다**(§0-1 빈 서랍).
        ⚠ **내 글은 안 낸다** — 위 카드가 이미 보인다(`room_share` 가 거른다).
        """
        # ⚠ **칸 이름을 짐작하지 않는다** — 이 패널의 구절은 `self.vid` 가
        #   아니라 **`self.clicked_id`** 다(실측으로 잡았다. `AttributeError`
        #   가 `except` 에 삼켜져 **조용히 아무것도 안 그렸다**).
        vid = getattr(self, 'clicked_id', None)
        if self.text_type != 'VERS_NOTE' or not vid:
            return
        try:
            import room_core as RC
            import room_share as RS
        except Exception:
            return
        rows = []
        try:
            with appdb.connect(self.db_path) as conn:
                for r in RC.rooms(conn):
                    for x in RS.notes_of_verse(conn, r['room_id'], vid,
                                               self.db_path):
                        x['room'] = r['room_name']
                        rows.append(x)
        except Exception as e:
            _quiet('[shared] %s' % e)
            return
        if not rows:
            return
        want = bool(getattr(self, '_shared_open', False))
        head = tk.Button(
            self._stack, bd=0, relief='flat', cursor='hand2', anchor='w',
            text=('%s %s (%d)'
                  % ('▾' if want else '▸',
                     i18n.t('NR_SHARED', '함께 나눈 글'), len(rows))),
            bg=_c('panel_alt', '#F2F3F4'), fg=_c('fg_title', '#1A5276'),
            command=self._toggle_shared)
        head.pack(fill='x', padx=6, pady=(10, 0))
        if not want:
            return
        for x in rows:
            f = tk.Frame(self._stack, bg=_c('bg', '#FDFEFE'))
            f.pack(fill='x', padx=6, pady=(4, 0))
            # ★★★ **방 이름을 늘 적는다**(2026-09-08 사용자 「방 단위로만
            #   조회 가능」) — 어느 공동체의 글인지 안 적으면 방이 둘일 때
            #   섞여 보인다.
            meta = '%s · %s' % (x['name'], (x['at'] or '')[:10])
            if x.get('room'):
                meta += ' · %s' % x['room']
            if x.get('mine'):
                meta += ' · %s' % i18n.t('NR_SHARED_MINE', '내 글')
            tk.Label(f, text=meta, anchor='w', bg=_c('bg', '#FDFEFE'),
                     fg=_c('fg_dim', '#95A5A6')).pack(fill='x')
            if x['title']:
                tk.Label(f, text=x['title'], anchor='w', justify='left',
                         bg=_c('bg', '#FDFEFE'), fg=_c('fg', '#000')).pack(fill='x')
            body = tk.Label(f, text=x['contents'], anchor='w', justify='left',
                            wraplength=self._wrap_px(), bg=_c('bg', '#FDFEFE'),
                            fg=_c('fg', '#000'))
            body.pack(fill='x')
            tk.Frame(f, height=1, bg=_c('border', '#E5E7E9')).pack(fill='x', pady=(4, 0))

    def _toggle_shared(self):
        self._shared_open = not bool(getattr(self, '_shared_open', False))
        self._render_cards()

    def _wrap_px(self):
        try:
            w = self._stack.winfo_width()
            return max(240, w - 30)
        except Exception:
            return 360

    def _bind_open(self, w, idx):
        """이 카드의 **모든 자손**에 「누르면 열기」를 건다 (2026-08-30).

        ⚠ Tk 는 자식이 받은 클릭을 부모로 올려 주지 않는다 — 프레임만 묶으면
          그 위에 놓인 라벨은 눌러도 아무 일이 없다.
        ⚠ 단추(`Button`)는 **건너뛴다** — ✕(삭제)까지 묶으면 지우려다 열린다.
        """
        try:
            if w.winfo_class() != 'Button':
                w.bind('<Button-1>', lambda _e, k=idx: self._open_card(k))
                try:
                    w.config(cursor='hand2')
                except Exception:
                    pass
            for ch in w.winfo_children():
                self._bind_open(ch, idx)
        except Exception:
            pass

    def _card(self, idx, rec):
        """댓글 한 편. `rec` 가 None 이면 새 글.

        ⚠ **테두리를 그리지 않는다** — 「박스가 너무 경직적이다」(2026-08-15).
          가는 가로줄 하나로 나눈다. 뉴스 댓글이 그렇게 생겼다.
        """
        opened = (self._open_idx == (idx if idx is not None else 'NEW'))
        bg = _c('accent_bg', '#EAF2F8') if opened else _c('bg', '#FDFEFE')
        f = tk.Frame(self._stack, bg=bg)
        f.pack(fill='x')

        head = tk.Frame(f, bg=bg)
        head.pack(fill='x', padx=10, pady=(6, 0))
        date_str = ((rec.get('updated_at') or rec.get('created_at') or '')[:10]
                    if rec else i18n.t('NR_NEW', '새 메모'))

        _raw = (rec.get('contents') if rec else '') or ''
        ref_line, src_label, question, body_raw = self._split_verse_ref(_raw)
        # 회색 정보 줄 — 구절 약명 + (있으면) 출처 라벨. 질문 스냅샷은 그 아래 줄.
        meta_line = ref_line + ((' · ' + src_label) if src_label else '') \
            if (ref_line or src_label) else src_label
        src_key = self._src_key_of(_raw)

        # ★ 펼친 카드는 **약명이 날짜 왼쪽** (2026-09-16 · 1.txt 14번 사용자 「"시 4:7"
        #   라벨을 … 날자표시의 왼쪽에 표시하라. 제목과 본문 입력화면 사이의 공간을
        #   제거하라」) — 정보 줄이 제목과 본문 사이에 끼어 있던 자리를 걷는다.
        if opened and meta_line:
            self._meta_label(head, bg, meta_line, src_key, src_label).pack(
                side='left', padx=(0, 8))
        tk.Label(head, text=date_str, bg=bg,
                 fg=_c('fg_dim', '#7F8C8D')).pack(side='left')

        # 삭제는 그 댓글 오른쪽 끝 — 저장 옆에 두면 실수한다(2026-08-15)
        if rec:
            tk.Button(head, text='✕', bd=0, cursor='hand2', bg=bg, padx=2, pady=0,
                      fg=_c('fg_dim', '#7F8C8D'),
                      command=lambda k=idx: self._del_card(k)).pack(side='right')

        if not opened:
            tk.Label(head, text=(rec.get('title') or '').strip()
                     or i18n.t('NR_NOTITLE', '(제목 없음)'),
                     bg=bg, fg=_c('fg_title', '#1A5276'),
                     font=('', 9, 'bold')).pack(side='left', padx=(8, 0))
            if meta_line:
                self._meta_label(f, bg, meta_line, src_key, src_label).pack(
                    fill='x', padx=10)
            if question:
                tk.Label(f, text=question, bg=bg, fg=_c('fg_dim', '#95A5A6'),
                         font=('', 9, 'italic'), anchor='w', justify='left',
                         wraplength=520).pack(fill='x', padx=10)
            lim = self._preview_len()
            body = body_raw.strip()
            cut = lim is not None and len(body) > lim
            # ⚠ **줄바꿈을 그대로 둔다** — 눌러 버리면 펼쳤을 때와 모양이 달라져
            #   「클릭할 때와 안 할 때가 다르다」가 된다(2026-08-15 사용자 지적).
            prev = tk.Label(f, text=(body[:lim] + '…') if cut else (body or ' '),
                            bg=bg, fg=_c('fg', '#566573'), anchor='w',
                            justify='left', cursor='hand2', wraplength=520)
            prev.pack(fill='x', padx=10, pady=(1, 6))
            # ★★★ **카드가 차지하는 자리 아무 데나 눌러도 열린다**
            #   (2026-08-30 사용자 신고 「지금은 **제목 등을 클릭하면 반응이 없고
            #   오로지 내용을 클릭해야** 반응하는 것 같다. 묵상노트가 차지하는
            #   공간 **아무곳이나 클릭하면 출발지로 인식**해야 한다」).
            #   ⚠⚠ 그전에는 `f`·`head`·`prev` **셋만** 묶었다. Tk 는 자식이 받은
            #     클릭을 부모에게 올려 주지 않으므로, `head` 안의 **날짜·제목
            #     라벨**과 `f` 안의 **회색 정보 줄·질문 줄**은 눌러도 아무 일이
            #     없었다. 실측 — 눌리는 자리가 세 곳뿐이었다.
            #   ⇒ **자손을 훑어 전부 묶는다.** ✕(삭제) 단추만 뺀다 — 그것을
            #     묶으면 지우려다 카드가 열린다.
            self._bind_open(f, idx)
            self._rule()
            return

        # ── 펼친 댓글 — 그 자리에서 고친다. 단추가 없다 ──────────────────
        # ⚠ 입력칸 표준 바탕은 `bg` 다(`ui_theme._SYS_ROLE` 이 `SystemWindow` 를 옮긴다).
        #   커서 색까지 줘야 검은 테마에서 커서가 보인다.
        _fld = dict(bg=_c('bg', '#FFFFFF'), fg=_c('fg', '#000000'),
                    insertbackground=_c('fg', '#000000'),
                    relief='flat', highlightthickness=1,
                    highlightbackground=_c('border', '#BDC3C7'))
        self.title_ent = tk.Entry(head, **_fld)
        self.title_ent.pack(side='left', fill='x', expand=True, padx=(8, 0))
        if rec and rec.get('title'):
            self.title_ent.insert(0, rec['title'])

        # (2026-09-16) 정보 줄은 머리(날짜 왼쪽)로 올라갔다 — 여기 두면 제목과
        #   본문 사이가 벌어진다.
        if question:
            tk.Label(f, text=question, bg=bg, fg=_c('fg_dim', '#95A5A6'),
                     font=('', 9, 'italic'), anchor='w', justify='left',
                     wraplength=520).pack(fill='x', padx=10)

        # ⚠ **높이에 상한을 두지 않는다.** 상한이 있으면 긴 글이 이 칸 안에서 또
        #   스크롤된다 — 스크롤이 두 겹이면 바깥 것이 안 듣는다(2026-08-15 사용자).
        rows = sum(max(1, len(ln) // 46 + 1)
                   for ln in body_raw.split('\n')) if body_raw else 3
        self.contents_txt = tk.Text(f, wrap='word', height=max(3, rows + 1), **_fld)
        self.contents_txt.pack(fill='x', padx=10, pady=(0, 6))   # 제목 바로 아래(2026-09-16)
        if body_raw:
            self.contents_txt.insert('1.0', body_raw)
        self.contents_txt.tag_config('url_link', foreground=_c('accent', '#2E86C1'), underline=True)
        self.contents_txt.tag_config('verse_ref', foreground=_c('fg_dim', '#7F8C8D'))
        self.contents_txt.bind('<ButtonRelease-1>', self._on_url_click)
        self.contents_txt.bind('<Motion>', self._on_mouse_move)
        self.contents_txt.bind('<KeyRelease>', self._on_body_key)
        # ★ **칸을 벗어나면 저장한다** — 단추가 없는 대신
        self.title_ent.bind('<FocusOut>', lambda _e: self._autosave())
        self.contents_txt.bind('<FocusOut>', lambda _e: self._autosave())
        try:
            import theme_font
            theme_font.register(self.contents_txt, self.db_path, 'ref')
        except Exception:
            pass
        self._apply_url_tags()
        self._edit_snap = self._snap()
        self._rule()

    def _on_body_key(self, _e=None):
        """글을 치면 칸이 따라 자란다 — 안에서 스크롤하지 않기 위해."""
        self._apply_url_tags()
        t = self.contents_txt
        if t is None:
            return
        try:
            need = int(t.index('end-1c').split('.')[0])
            # 줄바꿈 없이 길게 쓴 줄도 센다
            need = max(need, sum(max(1, len(ln) // 46 + 1)
                                 for ln in t.get('1.0', 'end-1c').split('\n')))
            if need + 1 != int(t.cget('height')):
                t.config(height=max(3, need + 1))
                self._stack.update_idletasks()
                self._cv.config(scrollregion=self._cv.bbox('all'))
        except Exception:
            pass

    def _rule(self):
        """댓글 사이 가는 줄. 테두리 대신 이것 하나."""
        tk.Frame(self._stack, height=1, bg=_c('border', '#D5DBDB')
                 ).pack(fill='x', padx=6)

    def _del_card(self, idx):
        """그 댓글을 지운다 — 펼치지 않고 바로."""
        try:
            self.current_record_id = self._records[idx]['id']
        except Exception:
            return
        self._delete_record()

    def _open_card(self, idx):
        """카드를 펼친다.

        ⚠ **`_load_record` 를 여기서 부르지 않는다** — 그 함수는 `title_ent` 를
          만지는데 위젯은 `_render_cards` 가 만든다. 순서가 뒤집혀 터졌다.
          펼친 카드는 `_card` 가 `rec` 을 보고 스스로 채운다.
        """
        self._autosave()                # ⚠ 옮기기 **전에** — 안 하면 쓰던 글이 사라진다
        self._open_idx = idx
        self._sel_idx = idx
        if idx is not None and idx < len(self._records):
            rec = self._records[idx]
            self.current_record_id = rec['id']
            vmap = {vid: v for v, vid in self._chap_verses}
            sn = vmap.get(rec['start_vid'], self._clicked_verse_num)
            en = vmap.get(rec['end_vid'], self._clicked_verse_num)
            if sn is not None and en is not None:
                self._set_combo_ranges(sn, en)
        else:
            self.current_record_id = None
        self._render_cards()

    def _close_card(self):
        self._autosave()
        self._open_idx = None
        self.current_record_id = None
        self._render_cards()

    def _mark_card(self, idx):
        """(옛 이름 유지) 카드 색은 펼침 여부가 정한다 — 따로 할 일이 없다."""
        return

    def _on_card_click(self, event=None):
        """(옛 이름 유지) 이제 카드마다 자기 클릭을 갖는다."""
        return


    def _on_list_select(self, event=None):
        """(옛 이름 유지) 지금 선택한 카드를 편집기에 싣는다."""
        idx = getattr(self, '_sel_idx', None)
        if idx is None:
            return
        self._load_record(idx)

    def _load_record(self, idx):
        """카드 하나를 편집기로. **카드 클릭과 저장 뒤 복귀가 같은 길을 쓴다.**"""
        if idx is None or idx >= len(self._records):
            return
        rec = self._records[idx]
        self.current_record_id = rec['id']
        # ⚠ 접힌 상태에서는 편집칸이 없다 — 펼친 카드가 `rec` 을 보고 스스로 채운다
        if self.title_ent is not None:
            self.title_ent.delete(0, 'end')
            self.title_ent.insert(0, rec['title'] or '')
        if self.contents_txt is not None:
            self.contents_txt.config(state='normal')
            self.contents_txt.delete('1.0', 'end')
            self.contents_txt.insert('1.0', rec['contents'] or '')
        self._apply_url_tags()
        # 선택한 노트의 구절 범위를 콤보에 반영
        vmap = {vid: v for v, vid in self._chap_verses}
        sn = vmap.get(rec['start_vid'], self._clicked_verse_num)
        en = vmap.get(rec['end_vid'], self._clicked_verse_num)
        if sn is not None and en is not None:
            self._set_combo_ranges(sn, en)

    def _new_record(self):
        """빈 카드를 하나 펼친다.

        ⚠ 카드 구조로 바꾸기 전에는 아래 편집기가 **늘 있어서** 비우기만 하면 됐다.
          지금은 펼친 카드에만 편집칸이 있으므로 **`_open_idx` 를 켜고 다시 그려야**
          한다. 안 하면 눌러도 아무 일이 없다(사용자 신고 2026-08-15).
        """
        self._autosave()
        self.current_record_id = None
        self._reset_range_to_clicked()   # 새 노트: 범위 = 클릭 절 단일
        self._sel_idx = None
        self._open_idx = 'NEW'
        self._render_cards()
        if self.title_ent is not None:
            self.title_ent.focus_set()

    def _clear_editor(self):
        if self.title_ent is None or self.contents_txt is None:
            return                      # 접혀 있으면 지울 것이 없다
        self.title_ent.delete(0, 'end')
        self.contents_txt.config(state='normal')
        self.contents_txt.delete('1.0', 'end')

    # ── 출처 줄 — 짧게 보이고 눌러서 전문 (2026-08-24) ────────────────────────
    #
    # ★ 사용자 지시 「책 제목 짧은 것만 표시하라. **클릭하면 풍선처럼 전체이름**」.
    #   실측 — 영어 제목 최대 49자(`Metropolitan Tabernacle Pulpit — Selected
    #   Sermons`) ↔ 한국어 제목 중앙값 9자. 저장된 라벨은 **짧은 쪽**이고,
    #   전문은 §54 원칙대로 **키에서 그때그때 다시 짓는다**(제목을 고치거나
    #   화면 언어를 바꾸면 따라온다).
    # ⚠ 호버가 아니라 **클릭**이다 — 지시가 그렇고, 스치기만 해도 뜨면 목록을
    #   훑는 동안 계속 방해한다.

    def _src_key_of(self, contents):
        try:
            import medi_note
            return medi_note.parse(contents or '')['src_key']
        except Exception:
            return ''

    def _meta_label(self, parent, bg, text, src_key, src_label=''):
        lab = tk.Label(parent, text=text, bg=bg, fg=_c('fg_dim', '#95A5A6'),
                       anchor='w')
        if not src_key:
            return lab
        lab.config(cursor='hand2')
        box = {'w': None}

        def _close(_e=None):
            if box['w'] is not None:
                try:
                    box['w'].destroy()
                except Exception:
                    pass
                box['w'] = None

        def _show(_e=None):
            _close()
            try:
                with appdb.connect(self.db_path) as conn:
                    import medi_note
                    full = medi_note.full_label(
                        conn, src_key, self._lang(), fallback='')
            except Exception:
                full = ''
            # ⚠ **줄 전체(`text`)가 아니라 출처 라벨과 견준다** — 줄에는 구절
            #   약명이 앞에 붙어 있어 절대 같아지지 않는다. 그대로 두면 자르지
            #   않았는데도 풍선이 떠서 **줄보다 정보가 적은 창**이 나온다.
            if not full or full == (src_label or text):
                return                       # 보일 것이 없으면 안 띄운다
            w = tk.Toplevel(lab)
            w.wm_overrideredirect(True)
            w.wm_geometry('+%d+%d' % (lab.winfo_rootx() + 12,
                                      lab.winfo_rooty() + 20))
            # ⚠ overrideredirect 창은 `paint` 가 못 닿는다 — 그릴 때 역할색을 읽는다
            tk.Label(w, text=full, bg=_c('panel_alt', '#F4F6F7'),
                     fg=_c('fg', '#2C3E50'), padx=8, pady=3,
                     relief='solid', borderwidth=1, justify='left',
                     wraplength=380).pack()
            box['w'] = w
            w.bind('<Button-1>', _close)
            lab.after(6000, _close)

        lab.bind('<Button-1>', _show)
        lab.bind('<Destroy>', lambda e: _close() if e.widget is lab else None)
        return lab

    def _lang(self):
        # ⚠ 이름은 **`lang_code_getter`** 다. `lang_getter` 로 쓰면 `getattr` 가
        #   None 을 주고 `callable(None)` 이 거짓이라 **조용히 KO 로 떨어진다**
        #   (§53차 「hasattr 로 감싼 호출은 이름이 틀려도 소리를 안 낸다」와 같은 계열 —
        #   실제로 그렇게 썼다가 잡았다).
        try:
            g = getattr(self, 'lang_code_getter', None)
            return (g() or 'KO') if callable(g) else 'KO'
        except Exception:
            return 'KO'

    def _split_verse_ref(self, contents):
        """`(관련구절 줄, 출처 라벨, 질문 스냅샷, 나머지 본문)`.

        ⚠ 관련구절·출처·질문은 **사람이 쓰는 글이 아니다** — 규약 줄이다(medi_note).
          편집칸에 넣어 두면 지웠다 썼다 하게 되고, 미리보기에서는 본문과 붙어
          한 줄로 보였다(2026-08-15 사용자 지적). 화면에는 따로(회색 줄) 보이고
          저장 때 다시 끼운다.
        ★ 묵상노트 통합 (2026-08-19) — 다른 화면(렌즈·플랜·도서)에서 쓴 노트가
          같은 저장소로 오므로, 출처 라벨과 질문 스냅샷까지 여기서 갈라 보인다.
        """
        try:
            import medi_note
            m = medi_note.parse(contents or '')
            return m['verse_label'], m['src_label'], m['question'], m['body']
        except Exception:
            lines = (contents or '').split('\n')
            if lines and lines[0].startswith(_VERSE_PREFIX):
                return (lines[0][len(_VERSE_PREFIX):].strip(), '', '',
                        '\n'.join(lines[1:]).lstrip('\n'))
            return '', '', '', contents or ''

    def _snap(self):
        """지금 편집칸의 상태. **범위까지 담는다.**

        ⚠ 제목·본문만 담았더니 **관련구절 범위만 바꿨을 때** 「바뀐 게 없다」로
          판정돼 그냥 지나갔다(2026-08-15 사용자 지적).
        """
        return (self.title_ent.get(),
                self.contents_txt.get('1.0', 'end-1c'),
                self._current_range_vids())

    def _autosave(self):
        """펼친 카드가 있으면 조용히 저장한다.

        ⚠ **바뀐 게 없으면 쓰지 않는다.** 그냥 지나가기만 해도 `updated_at` 이
          바뀌면 목록 차례가 흔들린다.
        ⚠ 카드를 옮길 때·절을 바꿀 때도 여기를 먼저 지난다. 셋 중 하나만 빠져도
          쓰던 글이 **오류 없이** 사라진다.
        """
        # ⚠ **기호판이 열려 있으면 저장하지 않는다** (2026-08-23) — 저장이
        #   목록을 다시 그려 글칸을 죽이면 기호가 들어갈 자리가 없어진다.
        #   판을 닫는 순간 어차피 다음 `<FocusOut>` 에서 저장된다.
        if getattr(self, '_sym_open', False):
            return
        if self.title_ent is None or self.contents_txt is None:
            return
        try:
            cur = self._snap()
        except Exception:
            return
        if cur == getattr(self, '_edit_snap', None):
            return
        if not (cur[0].strip() or cur[1].strip()):
            return                      # 빈 채로 지나가면 빈 글을 만들지 않는다
        self._edit_snap = cur
        self._save_record(silent=True)

    def _build_verse_ref_line(self):
        """저장 시 첫 줄에 기록할 관련구절 문자열."""
        return f"{_VERSE_PREFIX}{self._verse_label}" if self._verse_label else ""

    def _inject_verse_ref(self, contents):
        """
        contents 첫 줄을 관련구절 줄로 교체/삽입.
        이미 있으면 현재 구절로 업데이트, 없으면 맨 앞에 추가.
        """
        ref_line = self._build_verse_ref_line()
        if not ref_line:
            return contents
        lines = contents.split('\n')
        if lines and lines[0].startswith(_VERSE_PREFIX):
            lines[0] = ref_line
        else:
            lines.insert(0, ref_line)
        return '\n'.join(lines)

    def _save_record(self, silent=False):
        """`silent=True` 는 자동저장 — 대화상자를 띄우지 않는다."""
        if not self.clicked_id:
            if not silent:
                messagebox.showwarning(i18n.t('MSG_T_SAVEERR', "저장 오류"), i18n.t('MSG_NO_VERSE_SELECTED', "선택된 구절이 없습니다."))
            return
        if self.title_ent is None or self.contents_txt is None:
            return          # 펼친 카드가 없다 — 빈 글로 덮어쓰지 않는다
        title = self.title_ent.get().strip()
        raw = self.contents_txt.get('1.0', 'end-1c').strip()
        # ★ 묵상노트 통합 (2026-08-19) — 다른 화면에서 온 노트의 출처·질문 규약 줄을
        #   **보존**하며 다시 조립한다. 편집칸에는 본문만 있었으므로, 여기서 안 끼우면
        #   P2 에서 한 번 고치는 순간 출처가 사라진다.
        src_key = src_label = question = ''
        if self.current_record_id:
            for r in self._records:
                if r['id'] == self.current_record_id:
                    try:
                        import medi_note
                        m = medi_note.parse(r.get('contents') or '')
                        src_key, src_label, question = (m['src_key'],
                                                        m['src_label'],
                                                        m['question'])
                    except Exception:
                        pass
                    break
        try:
            import medi_note
            contents = medi_note.compose(raw, self._verse_label,
                                         src_key, src_label, question)
        except Exception:
            contents = self._inject_verse_ref(raw)
        lang = self.lang_code_getter() if self.lang_code_getter else 'KO'

        # ⚠ 관련구절 줄을 **편집칸에 되돌려 넣지 않는다** — 그 줄은 제 자리(회색 줄)에
        #   따로 보이고, 넣으면 사람이 지웠다 썼다 하게 된다.

        start_vid, end_vid = self._current_range_vids()
        tgt = end_vid if (end_vid and end_vid != start_vid) else 0   # 단일이면 0
        try:
            with appdb.connect(self.db_path) as conn:
                if self.current_record_id:
                    conn.execute(
                        "UPDATE user_text_asset "
                        "SET clicked_id=?, target_id=?, title=?, contents=?, record_status='EDIT', "
                        "    updated_at=DATETIME('now','localtime') "
                        "WHERE user_text_id=?",
                        (start_vid, tgt, title, contents, self.current_record_id)
                    )
                    try:
                        import usage_stats; usage_stats.bump('note_edit')
                    except Exception:
                        pass
                else:
                    cur = conn.execute(
                        "INSERT INTO user_text_asset "
                        "(clicked_id, target_id, text_type, title, contents, lang_code, record_status, "
                        " created_at, updated_at) "
                        "VALUES (?, ?, ?, ?, ?, ?, 'NEW', DATETIME('now','localtime'), DATETIME('now','localtime'))",
                        (start_vid, tgt, self.text_type, title, contents, lang)
                    )
                    self.current_record_id = cur.lastrowid
                    try:
                        import usage_stats; usage_stats.bump('note_create')
                    except Exception:
                        pass
        except Exception as e:
            if not silent:
                messagebox.showerror(i18n.t('MSG_T_SAVEFAIL', "저장 실패"), str(e))
            return

        # ★★★ **자동저장은 화면을 다시 그리지 않는다** (2026-09-15 `1.txt` 14번
        #   사용자 「깜빡거리는 현상, 뭔가 불안정하다」).
        #   ⚠⚠ 그전에는 제목 칸에서 본문 칸으로 **포커스만 옮겨도** `<FocusOut>`
        #     → 자동저장 → 목록을 다시 읽고 **카드 전부를 부수고 다시 만들었다**
        #     (실측 한 번에 두 번 그렸다). 그래서 화면이 깜빡이고, 방금 누른 본문
        #     칸이 **죽은 위젯**이 되어 포커스가 새 칸으로 안 갔다.
        #   ⇒ 조용한 저장은 **`_records` 만 제자리에서 고친다**. 펼친 카드는 그대로
        #     있고 사용자는 계속 쓴다. 카드를 닫거나 절을 옮길 때(그때는 어차피
        #     다시 그린다) 날짜·✕ 가 따라온다.
        saved_id = self.current_record_id
        now_txt = None
        try:
            with appdb.connect(self.db_path) as conn:
                now_txt = conn.execute(  # status-ok: 방금 저장한 제 줄의 시각만 읽는다(번호 하나)
                    "SELECT updated_at, created_at FROM user_text_asset "
                    "WHERE user_text_id=?", (saved_id,)).fetchone()
        except Exception:
            pass
        hit = None
        for r in self._records:
            if r['id'] == saved_id:
                hit = r
                break
        if hit is None:
            hit = {'id': saved_id, 'created_at': None, 'updated_at': None}
            self._records.insert(0, hit)        # 새 글은 맨 위
            if self._open_idx == 'NEW':
                self._open_idx = 0
        hit.update({'title': title, 'contents': contents,
                    'start_vid': start_vid, 'end_vid': (tgt or start_vid)})
        if now_txt:
            hit['updated_at'], hit['created_at'] = now_txt[0], now_txt[1]
        if not silent:
            self._render_cards()
            self._cv.yview_moveto(0)    # 방금 쓴 글은 맨 위에 있다
        self._notify_changed()

    def _notify_changed(self):
        cb = getattr(self, 'on_changed', None)
        if callable(cb):
            try:
                cb()
            except Exception as e:
                _quiet('[note on_changed] %s' % e)

    def _delete_record(self):
        if not self.current_record_id:
            messagebox.showwarning(i18n.t('MSG_T_DELERR', "삭제 오류"), i18n.t('MSG_SELECT_TO_DELETE', "삭제할 항목을 먼저 선택하세요."))
            return
        if messagebox.askyesno(i18n.t('MSG_T_DELCONFIRM', "삭제 확인"), i18n.t('MSG_DELETE_SELECTED_Q', "선택한 항목을 삭제할까요?")):
            try:
                with appdb.connect(self.db_path) as conn:
                    conn.execute(
                        "UPDATE user_text_asset SET record_status='HIDE' WHERE user_text_id=?",
                        (self.current_record_id,)
                    )
            except Exception as e:
                messagebox.showerror(i18n.t('MSG_T_DELFAIL', "삭제 실패"), str(e))
                return
            self.current_record_id = None
            self._clear_editor()
            self._refresh_list()
            self._notify_changed()

    def _apply_url_tags(self):
        if self.contents_txt is None:
            return
        """'URL '로 시작하는 줄 → 파란 밑줄, '관련구절 '로 시작하는 줄 → 회색.
        ★ 본문 중 http(s)://… 도 자동 링크 (2026-08-19 0.txt ⑨ — `url_text` 공용)."""
        try:
            import url_text
            url_text.linkify(self.contents_txt)
        except Exception:
            pass
        self.contents_txt.tag_remove('url_link', '1.0', 'end')
        self.contents_txt.tag_remove('verse_ref', '1.0', 'end')
        content = self.contents_txt.get('1.0', 'end')
        for i, line in enumerate(content.split('\n'), start=1):
            stripped = line.strip()
            if stripped.upper().startswith('URL') and len(stripped) > 4:
                self.contents_txt.tag_add('url_link', f"{i}.0", f"{i}.end")
            elif stripped.startswith(_VERSE_PREFIX):
                self.contents_txt.tag_add('verse_ref', f"{i}.0", f"{i}.end")

    def _on_url_click(self, event):
        """URL 링크 클릭 시 브라우저 열기."""
        idx = self.contents_txt.index(f"@{event.x},{event.y}")
        if 'url_link' not in self.contents_txt.tag_names(idx):
            return
        line_num = int(idx.split('.')[0])
        line = self.contents_txt.get(f"{line_num}.0", f"{line_num}.end").strip()
        colon_pos = line.find(':')
        if colon_pos != -1:
            url = line[colon_pos + 1:].strip()
            if url:
                webbrowser.open(url)

    def _on_mouse_move(self, event):
        """URL 위에서 커서를 손가락 모양으로 변경."""
        idx = self.contents_txt.index(f"@{event.x},{event.y}")
        cursor = "hand2" if 'url_link' in self.contents_txt.tag_names(idx) else ""
        self.contents_txt.config(cursor=cursor)
