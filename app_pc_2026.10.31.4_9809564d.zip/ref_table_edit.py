# -*- coding: utf-8 -*-
"""ref_table_edit — 연구/설교노트 고치는 칸의 **표 칩**과 **칸 편집 팝업** (317차-18 ⑤ · data.md Z-2v).

★ 고치는 칸(tk.Text)에는 자리표 `[[T1]]` 글자가 있다(저장되는 것은 그 글자다). 사람 눈에는
  그 글자를 숨기고(elide) 바로 뒤에 「표 1 · 3×2 [고치기]」 칩을 심는다.
  ⚠ `Text.get()` 은 숨긴 글자는 돌려주고 심은 위젯은 안 돌려준다 — 그래서 저장되는 글이 그대로다.
  ⚠ 사람이 칩을 지우면(백스페이스) 숨은 자리표도 함께 지운다 — 남겨 두면 안 보이는 표가 살아남는다.
★ 칸 편집 팝업 — 칸마다 여러 줄 · 줄·칸 더하기/빼기 · 머리 줄 · **A4(기본 종이)·폰 폭 재기**.
  폭 = 열마다 「가장 긴 낱말 하나 + 칸 여백」의 합(줄바꿈을 다 해도 더는 안 주는 폭).
⚠ 사용자 화면·관리자 화면이 **이 모듈 하나**를 쓴다(두 벌이면 갈린다).
"""
import tkinter as tk
import tkinter.font as tkfont

import i18n
import ref_doc as RD

#: 본문 폭(cm) — 종이 폭 − 좌우 여백
PAPER_CM = {'A4': 16.0, 'LETTER': 16.5, 'A5': 10.8, 'B5': 13.2}
PHONE_CM = 6.5
CELL_PAD_CM = 0.4
TAG = 'rd_tok'


def paper(db_path=None):
    """설정의 기본 종이(없으면 A4)."""
    try:
        import appdb
        with appdb.connect(db_path) as c:
            r = c.execute("SELECT config_val FROM user_config WHERE config_key='PAPER'").fetchone()
        v = (r[0] if r else '') or 'A4'
        return v.upper() if v.upper() in PAPER_CM else 'A4'
    except Exception:                                     # noqa: BLE001
        return 'A4'


def set_paper(v, db_path=None):
    """기본 종이를 저장한다(모르는 값은 무시)."""
    v = (v or '').upper()
    if v not in PAPER_CM:
        return False
    import appdb
    with appdb.connect(db_path) as c:
        if c.execute("UPDATE user_config SET config_val=? WHERE config_key='PAPER'", (v,)).rowcount == 0:
            c.execute("INSERT INTO user_config(config_key, config_val) VALUES('PAPER', ?)", (v,))
        c.commit()
    return True


def min_width(t, measure, pad=0):
    """표가 줄바꿈을 다 해도 더는 안 줄어드는 폭 → (폭, 그 열에서 가장 긴 낱말들).

    `measure(글)` = 그 글의 폭(px · cm 무엇이든 같은 단위) · `pad` = 칸 하나의 여백.
    """
    tot, worst = 0, []
    for j in range(t['cols']):
        best, wd = 0, ''
        for r in t['cells']:
            for w in (r[j] or '').split():
                m = measure(w)
                if m > best:
                    best, wd = m, w
        tot += best + pad
        worst.append(wd)
    return tot, worst


# ══════════════════════════════════════════════════════════════════
#  칸 편집 팝업
# ══════════════════════════════════════════════════════════════════
class TableEditor(tk.Toplevel):
    def __init__(self, parent, table, on_save, db_path=None, title=None, C=None, hint=''):
        super().__init__(parent)
        self.C = C or (lambda r, f: f)
        self.db_path = db_path
        self.on_save = on_save
        self.title(title or i18n.t('REFV_TBL_TITLE', '표 수정하기'))
        self.geometry('760x460')
        t = table or RD.make([['', ''], ['', '']], 1)
        self._rows, self._cols = t['rows'], t['cols']
        self._head = tk.IntVar(value=1 if t.get('head') else 0)
        bar = tk.Frame(self)
        bar.pack(fill='x', padx=6, pady=(6, 2))
        for txt, fn in ((i18n.t('COMMON_SAVE', '저장'), self._save),
                        (i18n.t('REFV_TBL_ROW_ADD', '줄 더하기'), lambda: self._resize(1, 0)),
                        (i18n.t('REFV_TBL_ROW_DEL', '줄 빼기'), lambda: self._resize(-1, 0)),
                        (i18n.t('REFV_TBL_COL_ADD', '칸 더하기'), lambda: self._resize(0, 1)),
                        (i18n.t('REFV_TBL_COL_DEL', '칸 빼기'), lambda: self._resize(0, -1))):
            tk.Button(bar, text=txt, command=fn, bd=0, padx=8, pady=2,
                      bg=self.C('accent_bg', '#D6EAF8'), fg=self.C('accent', '#1A5276')).pack(side='left', padx=2)
        tk.Checkbutton(bar, text=i18n.t('REFV_TBL_HEAD', '첫 줄은 제목 줄'), variable=self._head).pack(side='left', padx=8)
        # ★ 317차-18 ⑪ — 기본 종이(재는 잣대) · 고르면 그 자리에서 저장하고 다시 잰다
        from tkinter import ttk as _ttk
        self._paper = tk.StringVar(value=paper(db_path))
        _pc = _ttk.Combobox(bar, textvariable=self._paper, values=list(PAPER_CM), width=7, state='readonly')
        _pc.pack(side='right', padx=2)
        tk.Label(bar, text=i18n.t('REFV_TBL_PAPER', '종이')).pack(side='right')
        _pc.bind('<<ComboboxSelected>>', lambda e: (set_paper(self._paper.get(), self.db_path), self._measure()))
        self._meter = tk.Label(self, text='', anchor='w', padx=8)
        self._meter.pack(fill='x')
        if hint:
            tk.Label(self, text=hint, anchor='w', padx=8, fg=self.C('fg_dim', '#7F8C8D')).pack(fill='x')
        self._grid = tk.Frame(self)
        self._grid.pack(fill='both', expand=True, padx=6, pady=6)
        self._cells = []
        self._build(t['cells'])
        try:
            import ui_theme
            ui_theme.adopt(self)
        except Exception:                                 # noqa: BLE001
            pass

    def _build(self, cells):
        for w in self._grid.winfo_children():
            w.destroy()
        self._cells = []
        for i in range(self._rows):
            row = []
            for j in range(self._cols):
                e = tk.Text(self._grid, width=14, height=2, wrap='word', undo=True, bd=1, relief='solid')
                e.grid(row=i, column=j, sticky='nsew', padx=1, pady=1)
                v = cells[i][j] if i < len(cells) and j < len(cells[i]) else ''
                e.insert('1.0', v)
                e.bind('<KeyRelease>', lambda _e: self._measure())
                row.append(e)
            self._cells.append(row)
        for j in range(self._cols):
            self._grid.columnconfigure(j, weight=1)
        for i in range(self._rows):
            self._grid.rowconfigure(i, weight=1)
        self._measure()

    def cells(self):
        return [[e.get('1.0', 'end-1c').rstrip('\n') for e in r] for r in self._cells]

    def table(self):
        return RD.make(self.cells(), self._head.get())

    def _resize(self, dr, dc):
        cells = self.cells()
        self._rows = max(1, self._rows + dr)
        self._cols = max(1, self._cols + dc)
        self._build(RD.reshape(cells, self._rows, self._cols))

    def _measure(self):
        """A4(기본 종이)·폰 폭 — 넘치면 어느 칸의 어느 낱말 때문인지 말한다."""
        try:
            f = tkfont.Font(family='Arial', size=10)
            cm = self.winfo_fpixels('1c') or 37.8
            wpx, worst = min_width(self.table(), f.measure, pad=CELL_PAD_CM * cm)
            w = wpx / cm
            pp = paper(self.db_path)
            pa, ph = w / PAPER_CM[pp] * 100, w / PHONE_CM * 100
            msg = i18n.t('REFV_TBL_METER', '최소 폭 — %s %d%% · 폰 %d%%') % (pp, pa, ph)
            if pa > 100:
                j = max(range(len(worst)), key=lambda k: f.measure(worst[k] or ''))
                msg += '  ' + i18n.t('REFV_TBL_OVER', '%s 에 안 들어갑니다 — %d번째 칸 「%s」 낱말이 깁니다') % (
                    pp, j + 1, worst[j])
            self._meter.config(text=msg, fg=self.C('danger', '#922B21') if pa > 100 else self.C('fg', '#222222'))
            self.last_meter = (pa, ph)
        except Exception as e:                            # noqa: BLE001
            self._meter.config(text=str(e)[:80])

    def _save(self):
        t = self.table()
        try:
            self.on_save(t)
        finally:
            self.destroy()


# ══════════════════════════════════════════════════════════════════
#  고치는 칸 — 자리표 숨기기 + 칩
# ══════════════════════════════════════════════════════════════════
def decorate(txt, tables_get, on_edit, C=None):
    """고치는 칸의 자리표를 숨기고 칩을 심는다(다시 불러도 겹치지 않는다).

    `tables_get()` = {번호: 표} · `on_edit(번호)` = 칩의 [고치기].
    사람이 칩을 지웠으면 숨은 자리표도 함께 지운다.
    ⚠ 칸 글을 **코드로 통째로 갈아 끼우면** 부르기 전에 `txt._rd_chips = {}` — 안 그러면 사라진
      칩을 「사람이 지웠다」로 보고 새 글의 자리표를 지운다.
    """
    C = C or (lambda r, f: f)
    txt.tag_configure(TAG, elide=True)
    chips = getattr(txt, '_rd_chips', {})
    alive = set(str(w) for w in txt.window_names())
    # ① 사람이 지운 칩 → 자리표도 지운다
    for no, w in list(chips.items()):
        if str(w) not in alive:
            idx = txt.search(RD.token(no), '1.0', 'end', elide=True)   # ⚠ 숨긴 글자는 elide 를 줘야 찾는다
            if idx:
                txt.delete(idx, '%s+%dc' % (idx, len(RD.token(no))))
            chips.pop(no, None)
    # ② 자리표마다 칩
    tbls = tables_get() or {}
    pos = '1.0'
    while True:
        idx = txt.search(r'\[\[T\d{1,3}\]\]', pos, 'end', regexp=True, elide=True)
        if not idx:
            break
        end = txt.index('%s lineend' % idx)
        seg = txt.get(idx, end)
        m = RD.TOKEN_RE.match(seg)
        n = int(m.group(1))
        stop = '%s+%dc' % (idx, len(m.group(0)))
        txt.tag_add(TAG, idx, stop)
        t = tbls.get(n)
        lbl = (i18n.t('REFV_TBL_CHIP', '표 %d · %d×%d') % (n, t['rows'], t['cols'])) if t else \
            (i18n.t('REFV_TBL_CHIP0', '표 %d') % n)
        w = chips.get(n)
        if w is None or str(w) not in set(str(x) for x in txt.window_names()):
            w = tk.Button(txt, text='', bd=0, padx=8, pady=1, cursor='hand2',
                          bg=C('accent_bg', '#D6EAF8'), fg=C('accent', '#1A5276'),
                          command=lambda n=n: on_edit(n))
            txt.window_create(stop, window=w)
            chips[n] = w
        w.config(text='%s  [%s]' % (lbl, i18n.t('REFV_TBL_EDIT', '수정하기')))
        pos = '%s+1c' % stop
    txt._rd_chips = chips
    if not getattr(txt, '_rd_dec_bound', False):
        txt.bind('<KeyRelease>', lambda _e: decorate(txt, tables_get, on_edit, C), add='+')
        txt._rd_dec_bound = True
    return chips


def text_to_table(txt, tables, existing=(), raw=None, decorate=None, delim=None):
    """글 → 표 자리표(2026-10-13 docs/1.txt 84-1) → 넣은 번호 · 표가 아니면 None.

    raw=None 이면 **선택한 글**을 바꾸고([표로 바꾸기]), raw 를 주면 커서 자리에 넣는다(붙여넣기).
    ⚠ 표 모양은 `ref_doc.parse_delimited` 한 문이 정한다(탭·쉼표·`|`)."""
    if raw is None:
        try:
            raw = txt.get('sel.first', 'sel.last')
            sel = True
        except tk.TclError:
            return None
    else:
        sel = False
    t = RD.parse_delimited(raw, delim)
    if not t:
        return None
    no = next_no(txt.get('1.0', 'end-1c'), tables, existing)
    tables[no] = t
    if sel:
        at = txt.index('sel.first')
        txt.delete('sel.first', 'sel.last')
    else:
        try:
            txt.delete('sel.first', 'sel.last')
        except tk.TclError:
            pass
        at = txt.index('insert')
    pre = '' if txt.compare(at, '==', '%s linestart' % at) else '\n'
    txt.insert(at, pre + RD.token(no) + '\n')
    if callable(decorate):
        decorate()
    return no


# ★ 2026-10-16 — 붙여넣기를 표로 바꾸던 `bind_paste` 를 걷었다(사용자 「다른 자료를 Ctrl C 로 복사하여 붙여넣기 하려는데
#   무조건 표로 복사한다. 일반 문서인데도 · 표 넣기 버튼이 있으므로 이런 제약을 해제」). 탭이 하나라도 든 글(목록 번호 뒤 탭 ·
#   들여쓰기)을 통째로 표로 읽었다. 표는 [표 넣기] · 글을 선택하고 [표로 바꾸기](`text_to_table`)로 만든다.


def next_no(text, *nos):
    """새 표 번호 — 글 속 자리표와 이미 있는 표 번호 다음."""
    used = set(RD.tokens(text))
    for s_ in nos:
        used.update(int(x) for x in s_)
    return max(used or {0}) + 1


def selftest():
    ok = fail = 0

    def ck(c, m, got=''):
        nonlocal ok, fail
        if c:
            ok += 1
            print('  OK  ', m)
        else:
            fail += 1
            print('  FAIL', m, '|', got)
    t = RD.make([['짧', '아주긴낱말하나 둘'], ['a b', 'c']], 1)
    w, worst = min_width(t, len, pad=1)
    ck(w == (1 + 1) + (7 + 1) and worst == ['짧', '아주긴낱말하나'], '최소 폭 = 열마다 가장 긴 낱말 + 여백', (w, worst))
    ck(next_no('x [[T2]] y', [1, 5]) == 6 and next_no('') == 1, '새 표 번호')
    root = tk.Tk()
    root.withdraw()
    txt = tk.Text(root)
    txt.pack()
    txt.insert('1.0', '앞\n[[T1]]\n뒤')
    tb = {1: t}
    edits = []
    decorate(txt, lambda: tb, edits.append)
    root.update()
    ck(txt.get('1.0', 'end-1c') == '앞\n[[T1]]\n뒤', '★ 저장될 글은 자리표 그대로(칩은 글에 안 들어간다)',
       repr(txt.get('1.0', 'end-1c')))
    ck(len(txt.window_names()) == 1, '칩 하나')
    decorate(txt, lambda: tb, edits.append)
    ck(len(txt.window_names()) == 1, '다시 불러도 칩이 겹으로 안 생긴다', txt.window_names())
    root.nametowidget(txt.window_names()[0]).invoke()
    ck(edits == [1], '칩을 누르면 그 표 번호로 고치기')
    txt.delete(txt.index(txt.window_names()[0]))
    decorate(txt, lambda: tb, edits.append)
    ck('[[T1]]' not in txt.get('1.0', 'end') and not txt.window_names(), '★ 칩을 지우면 숨은 자리표도 지운다',
       repr(txt.get('1.0', 'end')))
    saved = []
    ed = TableEditor(root, t, saved.append)
    ed._resize(1, 1)
    ck(len(ed.cells()) == 3 and len(ed.cells()[0]) == 3 and ed.cells()[0][1] == '아주긴낱말하나 둘',
       '줄·칸 더하기 — 있던 칸은 자리를 지킨다', ed.cells())
    ck(getattr(ed, 'last_meter', None) is not None and paper() in ed._meter.cget('text'), '폭 재기 줄', ed._meter.cget('text'))
    # 종이를 바꾸면 그 자리에서 저장하고 다시 잰다(앞 값은 되돌린다 — 자국 0)
    import appdb
    with appdb.connect() as c:
        _old = c.execute("SELECT config_val FROM user_config WHERE config_key='PAPER'").fetchone()
    try:
        _p0 = ed.last_meter[0]
        ed._paper.set('A5'); set_paper('A5'); ed._measure()
        ck(paper() == 'A5' and 'A5' in ed._meter.cget('text') and ed.last_meter[0] > _p0,
           '★ 종이 A5 — 저장되고 다시 잰 비율이 커진다', (ed._meter.cget('text'), _p0))
        ck(not set_paper('B9'), '모르는 종이는 안 받는다')
    finally:
        with appdb.connect() as c:
            if _old is None:
                c.execute("DELETE FROM user_config WHERE config_key='PAPER'")
            else:
                c.execute("UPDATE user_config SET config_val=? WHERE config_key='PAPER'", (_old[0],))
            c.commit()
    ed._save()
    ck(saved and saved[0]['rows'] == 3 and saved[0]['head'] == 1, '[저장] 이 표를 넘긴다', saved)
    root.destroy()
    print('ref_table_edit selftest: %s (%d/%d)' % ('OK' if not fail else 'FAIL', ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
