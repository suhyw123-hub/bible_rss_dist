# -*- coding: utf-8 -*-
"""「내 구절연결 (E)」 — 구절↔구절 연결의 사용자 입력·숨김 팝업 (2026-08-26).

★ 왜 — 사용자 VERS_VERS 가 0건이었다: 엔진(overlay.LinkOverlay)은 1단계에
  완성됐는데 **화면에서 잇는 길이 아예 없었다**(실측 — 쓰는 곳은 관리자
  도구뿐). 0.txt 3번 「E 버튼 — 구절-구절 연결을 추가하거나 숨기기」의 구현.
★ 무엇 — 지금 절(A)의 연결 목록(기본/내 것 구분) + 새 연결 추가(책·장·절
  콤보 + 유형) + 숨기기 + 내 것 되돌리기. 저장은 전부 user db(덮개) —
  기본 자산은 안 바뀐다. 가린 연결의 해제는 설정 ▸ 휴지통.
⚠ VERS_VERS 는 **clicked < target 정렬**이 규약이다(§28-7 트리거) — 여기서
  정렬해 넣는다. 유형 어휘는 sys_rel_scope(VERS_VERS·LIVE)만 — 카탈로그
  전체를 쓰면 남의 갈래 어휘가 샌다(§구절연결 어휘 오염의 교훈).
입구 = P4 캔버스 상단 bar [E] → 총괄 창(overlay_center) 구절연결 탭.
`--selftest` 의무(데이터 층).
"""
import sys
import tkinter as tk
from tkinter import ttk, messagebox

import appdb
import i18n
import overlay


# ══════════════════════════════════════════════════════════════════
#  데이터 — 화면과 분리 (selftest 가 이 층을 잰다)
# ══════════════════════════════════════════════════════════════════
def _vlabel(conn, vid, lang='KO'):
    try:
        import verse_ref
        r = conn.execute(
            'SELECT bn.short_name, bi.chapter, bi.verse FROM bible_index bi '
            'JOIN book_names bn ON bn.book_code = bi.bcode '
            'AND UPPER(bn.lang_code)=? WHERE bi.verse_id=?',
            ((lang or 'KO').upper(), vid)).fetchone()
        if r:
            return verse_ref.label(lang, r[0], r[1], r[2])
    except Exception:
        pass
    return '#%s' % vid


def rel_options(conn, lang='KO'):
    """유형 콤보 — sys_rel_scope 의 VERS_VERS 어휘만. [(rel_code, 이름)]."""
    out = []
    try:
        import rel_vocab
        for (rc,) in conn.execute(
                "SELECT rel_code FROM sys_rel_scope "
                "WHERE link_type='VERS_VERS' "
                "AND COALESCE(record_status,'LIVE')='LIVE' "
                "ORDER BY sort_order, rel_code"):
            out.append((rc, rel_vocab.name(conn, 'VERS_VERS', rc, lang)))
    except Exception as e:
        print('[verse link edit] rel options:', e)
    return out


def list_links(conn, vid, lang='KO', show_hidden=None):
    """이 절의 연결(덮개 적용) → [{key…, other, other_label, rel, rel_name,
    src(SYS/EDIT/NEW/HIDE)}].

    ★ `show_hidden` — 「가린 것도 보기」(2026-08-27). 켜면 가린 줄이
      `src='HIDE'` 로 **함께 나온다**(화면이 H 로 그린다). 끄면 종전대로
      엔진 규칙에 따라 안 나온다. None 이면 사용자 옵션을 따른다.
      ⚠ 사용자 신고 「숨기기 눌러도 H 표시 안 된다」의 자리 — 목록은 늘
        「보이는 것만」 그렸고 옵션이 여기까지 배선돼 있지 않았다.
    """
    if show_hidden is None:
        try:
            import overlay_read
            show_hidden = overlay_read.show_hidden(conn)
        except Exception:
            show_hidden = False
    ad = overlay.LinkOverlay()
    out = []
    try:
        import rel_vocab
    except Exception:
        rel_vocab = None
    for r in overlay.resolve(conn, ad, vid):
        other = r['target_id'] if r['clicked_id'] == vid else r['clicked_id']
        rel = r.get('rel_code') or ''
        nm = rel
        if rel and rel_vocab is not None:
            try:
                nm = rel_vocab.name(conn, 'VERS_VERS', rel, lang)
            except Exception:
                pass
        # ★ **등급(rel_tier)** 을 함께 싣는다 (2026-08-27 사용자 신고 —
        #   「캔버스 숫자와 My Edit 구절연결 목록이 다르다. 심각하다」).
        #   원인은 데이터가 아니라 **규칙이 둘**이었다: 캔버스는 [설정]의
        #   등급(A/AB/ABC)·범위 필터를 태우고 이 목록은 전부 보인다.
        #   ⇒ 목록이 **그 사실을 말하게** 한다 — 등급 칸 + 「캔버스에 보이는가」.
        tier = ''
        try:
            tr = conn.execute(
                'SELECT rel_tier FROM sys_rel_catalog WHERE rel_code=? '
                'LIMIT 1', (rel,)).fetchone()
            tier = (tr[0] if tr else '') or ''
        except Exception:
            pass
        out.append({'clicked_id': r['clicked_id'], 'target_id': r['target_id'],
                    'rel_code': r.get('rel_code'), 'end_id': r.get('end_id'),
                    'link_type': 'VERS_VERS', 'tier': tier,
                    'other': other, 'other_label': _vlabel(conn, other, lang),
                    'rel': rel, 'rel_name': nm, 'src': r.get('_src', 'SYS')})
    if show_hidden:
        # 가린 줄을 **덧붙인다** — 엔진이 뺀 것들(sys 를 가림 · 내 것을 뗌)
        seen = {(r['clicked_id'], r['target_id'], r.get('rel_code') or '')
                for r in out}
        try:
            import rel_vocab as _rv
        except Exception:
            _rv = None
        for a, b, rel2, end2 in conn.execute(
                "SELECT clicked_id, target_id, rel_code, end_id "
                "  FROM userdb.user_link_asset "
                " WHERE link_type='VERS_VERS' AND record_status='HIDE' "
                "   AND (clicked_id=? OR target_id=?)", (vid, vid)):
            if (a, b, rel2 or '') in seen:
                continue
            other2 = b if a == vid else a
            nm2 = rel2 or ''
            if rel2 and _rv is not None:
                try:
                    nm2 = _rv.name(conn, 'VERS_VERS', rel2, lang)
                except Exception:
                    pass
            tier2 = ''
            try:
                tr2 = conn.execute('SELECT rel_tier FROM sys_rel_catalog '
                                   'WHERE rel_code=? LIMIT 1',
                                   (rel2,)).fetchone()
                tier2 = (tr2[0] if tr2 else '') or ''
            except Exception:
                pass
            out.append({'clicked_id': a, 'target_id': b, 'rel_code': rel2,
                        'end_id': end2, 'link_type': 'VERS_VERS',
                        'tier': tier2, 'other': other2,
                        'other_label': _vlabel(conn, other2, lang),
                        'rel': rel2 or '', 'rel_name': nm2, 'src': 'HIDE'})
    out.sort(key=lambda x: (x['other'], x['rel']))
    return out


def add_link(conn, vid_a, vid_b, rel):
    """새 연결 — clicked < target 정렬(§28-7) 후 엔진 저장.
    sys 에 같은 열쇠가 있으면 EDIT(사실상 이미 있는 연결), 없으면 NEW."""
    a, b = sorted((int(vid_a), int(vid_b)))
    if a == b:
        return 'SELF'
    row = {'link_type': 'VERS_VERS', 'clicked_id': a, 'target_id': b,
           'rel_code': rel or None}
    return overlay.save(conn, overlay.LinkOverlay(), row)


def _sys_link_id(conn, row):
    r = conn.execute(
        "SELECT sys_link_id FROM sys_link_asset WHERE link_type='VERS_VERS' "
        "AND clicked_id=? AND target_id=? "
        "AND COALESCE(rel_code,'')=COALESCE(?,'') "
        "AND COALESCE(record_status,'LIVE')='LIVE'",
        (row['clicked_id'], row['target_id'], row.get('rel_code'))).fetchone()
    return r and r[0]


def _user_link_id(conn, row):
    r = conn.execute(
        "SELECT user_link_id FROM userdb.user_link_asset "
        "WHERE link_type='VERS_VERS' AND clicked_id=? AND target_id=? "
        "AND COALESCE(rel_code,'')=COALESCE(?,'') "
        "AND COALESCE(record_status,'LIVE')='LIVE'",
        (row['clicked_id'], row['target_id'], row.get('rel_code'))).fetchone()
    return r and r[0]


def link_desc(conn, row, lang='KO'):
    """선택한 연결의 **연결설명문** → (글, 상태 SYS/EDIT/NEW/NONE).

    · sys 연결 — `sys_text_asset(VERS_VERS_DESC, clicked_id=sys_link_id)`
      위에 내 덮개(`overlay.text_override` — 캔버스 읽기와 같은 문법).
    · 내 연결(NEW) — 앵커가 내 링크 PK(`user_link_id`). 배포와 무관한 내
      DB 라 안정적이다.
    · 언어 폴백 요청→EN→KO — 단 **가림은 폴백을 이긴다**(§88차).
    """
    lg0 = (lang or 'KO').upper()
    order = [lg0] + [x for x in ('EN', 'KO') if x != lg0]
    lid = _sys_link_id(conn, row)
    if lid:
        for lg in order:
            ov = overlay.text_override(conn, 'VERS_VERS_DESC', lid, lg, None)
            if ov is not None:
                st, body = ov
                if st == 'HIDE' or body is None:
                    return '', 'NONE'          # 가림 — 폴백 금지
                return (body[1] or ''), 'EDIT'
            r = conn.execute(
                "SELECT contents FROM sys_text_asset "
                "WHERE text_type='VERS_VERS_DESC' AND clicked_id=? "
                "AND UPPER(lang_code)=? "
                "AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
                (lid, lg)).fetchone()
            if r and (r[0] or '').strip():
                return r[0], 'SYS'
        return '', 'NONE'
    uid = _user_link_id(conn, row)
    if uid:
        for lg in order:
            r = conn.execute(
                "SELECT contents FROM userdb.user_text_asset "
                "WHERE text_type='VERS_VERS_DESC' AND clicked_id=? "
                "AND UPPER(lang_code)=? "
                "AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
                (uid, lg)).fetchone()
            if r and (r[0] or '').strip():
                return r[0], 'NEW'
    return '', 'NONE'


def save_link_desc(conn, row, lang, text):
    """연결설명문 저장 — sys 연결이면 덮개(EDIT), 내 연결이면 내 글(NEW).
    빈 글 저장 = 내 것 걷어내기(덮개 되돌림 / 내 글 삭제). 반환 상태."""
    lg = (lang or 'KO').upper()
    text = (text or '').strip()
    lid = _sys_link_id(conn, row)
    if lid:
        ad = overlay.TextOverlay('VERS_VERS_DESC')
        trow = {'text_type': 'VERS_VERS_DESC', 'clicked_id': lid,
                'target_id': None, 'title': None, 'contents': text,
                'lang_code': lg, 'text_variant': None}
        if not text:
            overlay.revert(conn, ad, trow)     # 덮개 걷기 — sys 가 되살아난다
            return 'SYS'
        overlay.save(conn, ad, trow)
        return 'EDIT'
    uid = _user_link_id(conn, row)
    if not uid:
        return None
    if not text:
        conn.execute("DELETE FROM userdb.user_text_asset "
                     "WHERE text_type='VERS_VERS_DESC' AND clicked_id=? "
                     "AND UPPER(lang_code)=?", (uid, lg))
        conn.commit()
        return 'NONE'
    cur = conn.execute(
        "UPDATE userdb.user_text_asset SET contents=?, record_status='LIVE' "
        "WHERE text_type='VERS_VERS_DESC' AND clicked_id=? "
        "AND UPPER(lang_code)=?", (text, uid, lg))
    if cur.rowcount == 0:
        conn.execute(
            "INSERT INTO userdb.user_text_asset(text_type, clicked_id, "
            "contents, lang_code, record_status) "
            "VALUES('VERS_VERS_DESC', ?, ?, ?, 'LIVE')", (uid, text, lg))
    conn.commit()
    return 'NEW'


def hide_link(conn, row):
    overlay.hide(conn, overlay.LinkOverlay(), row)


def revert_link(conn, row):
    overlay.revert(conn, overlay.LinkOverlay(), row)


# ══════════════════════════════════════════════════════════════════
#  화면은 총괄 창(overlay_center) 「구절연결」 탭이 맡는다 (2026-08-26
#  사용자 확정 — 화면별 팝업 대신 총괄 팝업 + 위치 포커스).
#  옛 자체 팝업(_LinkEditPop)은 폐기 — 출발지가 암묵적이었고 본문
#  미리보기가 없었다(둘 다 총괄 창 탭에서 해결).
# ══════════════════════════════════════════════════════════════════
def open_editor(parent, db_path, vid, lang='KO', on_changed=None):
    """(다리) 총괄 창의 구절연결 탭으로."""
    if not vid:
        return None
    import overlay_center
    return overlay_center.open_center(parent, db_path, focus='LINK',
                                      vid=int(vid), on_changed=on_changed)


# ══════════════════════════════════════════════════════════════════
#  자가 검증 — 데이터 층
# ══════════════════════════════════════════════════════════════════
def selftest():
    import sqlite3
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    db = sqlite3.connect(':memory:')
    db.execute('ATTACH DATABASE ":memory:" AS userdb')
    ddl = ('(weird_pk INTEGER PRIMARY KEY, link_type TEXT, clicked_id INT, '
           'target_id INT, rel_code TEXT, end_id INT, note TEXT, '
           'chain_code TEXT, sort_order INT, record_status TEXT)')
    db.execute('CREATE TABLE sys_link_asset ' + ddl)
    db.execute('CREATE TABLE userdb.user_link_asset ' + ddl)
    db.execute('CREATE TABLE bible_index (verse_id INTEGER PRIMARY KEY, '
               'bcode INT, chapter INT, verse INT)')
    db.execute('CREATE TABLE book_names (book_code INT, lang_code TEXT, '
               'short_name TEXT, full_name TEXT)')
    db.execute("INSERT INTO book_names VALUES (1,'KO','창','창세기')")
    for vid, b, c, v in ((1, 1, 1, 1), (100, 1, 3, 2), (200, 1, 5, 1)):
        db.execute('INSERT INTO bible_index VALUES (?,?,?,?)', (vid, b, c, v))
    db.execute("INSERT INTO sys_link_asset (link_type, clicked_id, target_id,"
               " rel_code, record_status) VALUES ('VERS_VERS',1,100,'PRG','LIVE')")
    db.commit()

    r = list_links(db, 1)
    t('기본 연결 목록', len(r) == 1 and r[0]['src'] == 'SYS'
      and r[0]['other'] == 100, r and r[0]['other'])

    # 추가 — 정렬(§28-7): 큰 절에서 작은 절로 이어도 clicked<target
    st = add_link(db, 200, 1, 'PAR')
    t('★ 새 연결 = NEW', st == 'NEW', st)
    row = db.execute('SELECT clicked_id, target_id FROM userdb.user_link_asset'
                     ).fetchone()
    t('★ clicked < target 정렬', row == (1, 200), row)
    r = list_links(db, 1)
    t('   목록에 내 연결', len(r) == 2
      and any(x['src'] == 'NEW' and x['other'] == 200 for x in r), len(r))

    st = add_link(db, 1, 1, 'PAR')
    t('같은 절끼리 거부', st == 'SELF', st)

    # sys 와 같은 열쇠면 EDIT (이미 있는 연결)
    st = add_link(db, 100, 1, 'PRG')
    t('sys 와 같은 열쇠 = EDIT', st == 'EDIT', st)
    revert_link(db, {'link_type': 'VERS_VERS', 'clicked_id': 1,
                     'target_id': 100, 'rel_code': 'PRG'})

    # 숨기기 — 목록·resolve 에서 빠진다
    hide_link(db, {'link_type': 'VERS_VERS', 'clicked_id': 1,
                   'target_id': 100, 'rel_code': 'PRG'})
    r = list_links(db, 1)
    t('★ 숨긴 기본 연결이 목록에서 빠진다',
      all(x['other'] != 100 for x in r), [x['other'] for x in r])
    revert_link(db, {'link_type': 'VERS_VERS', 'clicked_id': 1,
                     'target_id': 100, 'rel_code': 'PRG'})
    r = list_links(db, 1)
    t('   되돌리면 복귀', any(x['other'] == 100 for x in r))

    db.close()

    # ── 연결설명문 (2026-08-27) — 실제 PK 이름 스키마로 따로 잰다 ──
    d2 = sqlite3.connect(':memory:')
    d2.execute('ATTACH DATABASE ":memory:" AS userdb')
    d2.execute('CREATE TABLE sys_link_asset (sys_link_id INTEGER PRIMARY KEY,'
               ' link_type TEXT, clicked_id INT, target_id INT, rel_code TEXT,'
               ' end_id INT, record_status TEXT)')
    d2.execute('CREATE TABLE userdb.user_link_asset (user_link_id INTEGER '
               'PRIMARY KEY, link_type TEXT, clicked_id INT, target_id INT,'
               ' rel_code TEXT, end_id INT, origin_id INT, record_status TEXT)')
    d2.execute('CREATE TABLE sys_text_asset (sys_text_id INTEGER PRIMARY KEY,'
               ' text_type TEXT, clicked_id INT, target_id INT, title TEXT,'
               ' contents TEXT, lang_code TEXT, text_variant TEXT,'
               ' record_status TEXT)')
    d2.execute('CREATE TABLE userdb.user_text_asset (user_text_id INTEGER '
               'PRIMARY KEY, text_type TEXT, clicked_id INT, target_id INT,'
               ' title TEXT, contents TEXT, lang_code TEXT, text_variant TEXT,'
               ' origin_key TEXT, record_status TEXT)')
    d2.execute("INSERT INTO sys_link_asset VALUES (77,'VERS_VERS',1,100,"
               "'PRG',NULL,'LIVE')")
    d2.execute("INSERT INTO sys_text_asset VALUES (1,'VERS_VERS_DESC',77,"
               "NULL,NULL,'빛의 첫걸음','KO',NULL,'LIVE')")
    d2.commit()
    sysrow = {'link_type': 'VERS_VERS', 'clicked_id': 1, 'target_id': 100,
              'rel_code': 'PRG'}
    txt, st = link_desc(d2, sysrow, 'KO')
    t('연결설명문 — sys 읽기', txt == '빛의 첫걸음' and st == 'SYS', (txt, st))
    st = save_link_desc(d2, sysrow, 'KO', '내가 고친 글')
    txt, st2 = link_desc(d2, sysrow, 'KO')
    t('★ 수정 = 덮개(EDIT) — sys 불변', st == 'EDIT' and txt == '내가 고친 글'
      and d2.execute('SELECT contents FROM sys_text_asset WHERE sys_text_id=1'
                     ).fetchone()[0] == '빛의 첫걸음', (st, txt))
    st = save_link_desc(d2, sysrow, 'KO', '')
    txt, st2 = link_desc(d2, sysrow, 'KO')
    t('   빈 저장 = 되돌림(sys 부활)', txt == '빛의 첫걸음' and st2 == 'SYS',
      (txt, st2))
    # 내 연결(NEW) — 앵커는 내 링크 PK
    d2.execute("INSERT INTO userdb.user_link_asset VALUES (5,'VERS_VERS',1,"
               "200,'PRG',NULL,NULL,'LIVE')")
    d2.commit()
    myrow = {'link_type': 'VERS_VERS', 'clicked_id': 1, 'target_id': 200,
             'rel_code': 'PRG'}
    st = save_link_desc(d2, myrow, 'KO', '내 연결의 설명')
    txt, st2 = link_desc(d2, myrow, 'KO')
    t('★ 내 연결 설명문 왕복(NEW)', st == 'NEW' and txt == '내 연결의 설명'
      and st2 == 'NEW', (st, txt))
    st = save_link_desc(d2, myrow, 'KO', '')
    txt, st2 = link_desc(d2, myrow, 'KO')
    t('   빈 저장 = 삭제', txt == '' and st2 == 'NONE', (txt, st2))
    d2.close()

    print('verse_link_edit selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)
