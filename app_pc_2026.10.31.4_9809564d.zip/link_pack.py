# -*- coding: utf-8 -*-
"""link_pack.py — 외부 링크 자산 팩 (2026-09-03 190차 신설·영구).

★★★ 왜 별도 파일인가 (사용자 확정 설계 · 0.txt 3번):
  URL 은 빨리 썩고 그 연결도 함께 썩는다. 본체(bible_master.db)는 6개월
  주기라 그 속도를 못 따라간다. 그렇다고 **user_data.db 에 배포 데이터를
  실으면** 사용자 자산과 섞여, 코어팩 갱신 때 「배포분만 골라 지우는 수술」이
  필요해진다(사용자 데이터 삭제 위험 · §139차류 사고의 자리).
  ⇒ **제3의 파일**(link_pack.db · sys 성격 · 읽기 전용)이 링크의 집이다.
    · 증분이든 전체본이든 도착지가 여기 하나 — user.db 는 안 건드린다.
    · 풀싱크 = **파일 통째 교체** 한 줄(파일이 갈려 있으므로).
    · 본체에서 링크를 은퇴시켜도 「옮기고 지우는」 병행 로직이 필요 없다.

배포 모델 (증분 + 안전장치 넷 — 사용자 제시):
  ① 트랜잭션 원자성   — 적용은 all-or-nothing(중간 실패면 롤백)
  ② 멱등 Upsert       — 고유 키(media_id · 링크 자연 열쇠) 기준
  ③ 커서              — 마지막 성공 시퀀스를 팩에 기록
  ④ 주기적 풀싱크     — 파일 교체(별도 도구)
  ⚠ 삭제 전파는 **묘비 행**으로 — `record_status='DELETED'` 를 실어 보낸다
    (공지 동기화가 쓰는 그 규약 그대로 · rss_reader.sync_announcements).

스키마 (본체 sys_media_* 와 **같은 모양** — 화면이 합칠 수 있게):
  pack_media(media_id PK · media_type · format_type · title · description ·
             url · lang_code · is_active · sort_order · record_status)
  pack_link(link_type · clicked_id · target_id · rel_code · end_id ·
            record_status · PRIMARY KEY(link_type, clicked_id, target_id))
    ⚠ 참조는 **자연 열쇠**로 싣고 적재 때 해석한다(entity_code·구절 번호) —
      본체 주기와 팩 주기가 어긋나도 안전(모르는 대상은 보류).
  pack_meta(k PK · v)   — 커서(cursor)·팩 버전·마지막 적용 시각

    python link_pack.py --selftest   (의무)
    python link_pack.py --status
"""
import io
import os
import sqlite3
import sys

PACK_NAME = 'link_pack.db'

DDL = (
    "CREATE TABLE IF NOT EXISTS pack_media("
    " media_id INTEGER PRIMARY KEY, media_type TEXT, format_type TEXT,"
    " title TEXT, description TEXT, url TEXT, lang_code TEXT,"
    " is_active INTEGER DEFAULT 1, sort_order INTEGER DEFAULT 0,"
    " record_status TEXT DEFAULT 'LIVE')",
    "CREATE TABLE IF NOT EXISTS pack_link("
    " link_type TEXT, clicked_id INTEGER, target_id INTEGER,"
    " rel_code TEXT, end_id INTEGER, record_status TEXT DEFAULT 'LIVE',"
    " PRIMARY KEY(link_type, clicked_id, target_id))",
    "CREATE TABLE IF NOT EXISTS pack_meta(k TEXT PRIMARY KEY, v TEXT)",
    "CREATE INDEX IF NOT EXISTS ix_pack_link_t"
    " ON pack_link(link_type, target_id)",
)


def pack_path(db_path=None):
    """팩 파일 자리 — **본체 옆**(appdb 와 같은 폴더 규약)."""
    if db_path:
        base = os.path.dirname(os.path.abspath(str(db_path)))
    else:
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, PACK_NAME)


def ensure(path=None):
    """팩 파일과 표를 만든다(멱등). → 경로."""
    p = path or pack_path()
    conn = sqlite3.connect(p)
    try:
        for sql in DDL:
            conn.execute(sql)
        conn.commit()
    finally:
        conn.close()
    return p


def attach(conn, path=None):
    """열려 있는 연결에 팩을 붙인다 → 붙었나(bool).

    ⚠ **없으면 조용히 False** — 팩이 아직 없는 사용자(첫 실행·수신 전)에게도
      앱은 그대로 돌아야 한다. 화면은 이 값을 보고 팩 조회를 건너뛴다.
    ⚠ 두 번 붙이면 sqlite 가 오류를 낸다 — 이미 붙었으면 True 로 돌아간다.
    """
    p = path or pack_path()
    if not os.path.exists(p):
        return False
    try:
        for _sid, name, _f in conn.execute('PRAGMA database_list'):
            if name == 'linkpack':
                return True
        conn.execute("ATTACH DATABASE ? AS linkpack", (p,))
        return True
    except Exception:
        return False


def detach(conn):
    """붙인 팩을 뗀다 → 뗐나(bool).

    ★★ **파일 교체(풀싱크 스왑)를 하려면 반드시 먼저 뗀다** — 붙어 있는
      동안 윈도우가 파일을 잠가 교체·삭제가 실패한다(2026-09-03 점검에서
      실제로 PermissionError 로 잡았다). 트레이는 본체가 꺼진 뒤에 받으므로
      보통은 안 걸리지만, 앱 안에서 갈아 끼우는 길을 열려면 이 문이 있어야 한다.
    """
    try:
        conn.execute('DETACH DATABASE linkpack')
        return True
    except Exception:
        return False


def available(conn):
    """이 연결에서 팩을 읽을 수 있나 — 화면이 합류 여부를 정하는 문."""
    try:
        conn.execute('SELECT 1 FROM linkpack.pack_media LIMIT 1')
        return True
    except Exception:
        return False


def cursor(conn_or_path=None):
    """마지막으로 적용한 델타 시퀀스(없으면 0).

    ⚠ 연결을 받을 때 **두 경우가 있다** — 팩을 직접 연 연결(표가 맨 이름)과
      본체에 ATTACH 한 연결(`linkpack.` 접두). 접두를 단정하면 한쪽이 조용히
      0 을 돌려준다(실측으로 잡았다 — 커서가 안 오르는 것처럼 보였다).
      ⇒ **맨 이름을 먼저 보고, 없으면 접두를 본다.**
    """
    own = not hasattr(conn_or_path, 'execute')
    c = sqlite3.connect(conn_or_path or pack_path()) if own else conn_or_path
    try:
        for pre in ('', 'linkpack.'):
            try:
                r = c.execute("SELECT v FROM %spack_meta WHERE k='cursor'"
                              % pre).fetchone()
            except Exception:
                continue
            if r and str(r[0]).isdigit():
                return int(r[0])
        return 0
    except Exception:
        return 0
    finally:
        if own:
            c.close()


def counts(path=None):
    """(미디어, 링크) — 상태 표시용."""
    p = path or pack_path()
    if not os.path.exists(p):
        return (0, 0)
    conn = sqlite3.connect(p)
    try:
        m = conn.execute("SELECT COUNT(*) FROM pack_media"
                         " WHERE COALESCE(record_status,'LIVE')='LIVE'"
                         ).fetchone()[0]
        l = conn.execute("SELECT COUNT(*) FROM pack_link"
                         " WHERE COALESCE(record_status,'LIVE')='LIVE'"
                         ).fetchone()[0]
        return (m, l)
    except Exception:
        return (0, 0)
    finally:
        conn.close()


def status():
    p = pack_path()
    if not os.path.exists(p):
        print('팩 없음 (%s) — 정상: 수신 전이면 앱은 본체만 읽는다' % p)
        return
    m, l = counts(p)
    print('팩 %s · 미디어 %d · 링크 %d · 커서 %d · %.1fKB'
          % (p, m, l, cursor(p), os.path.getsize(p) / 1024))


def selftest():
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', errors='replace')
    import tempfile
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    d = tempfile.mkdtemp()
    p = os.path.join(d, PACK_NAME)
    ensure(p)
    t('팩 파일 생성', os.path.exists(p))
    ensure(p)
    t('ensure 멱등(두 번 불러도 무해)', os.path.exists(p))
    t('빈 팩 개수 (0,0)', counts(p) == (0, 0))
    t('빈 팩 커서 0', cursor(p) == 0)
    # ATTACH 왕복
    main = sqlite3.connect(':memory:')
    t('팩 없으면 조용히 False', attach(main, os.path.join(d, 'nope.db')) is False)
    t('붙는다', attach(main, p) is True)
    t('두 번 붙여도 True', attach(main, p) is True)
    t('available', available(main) is True)
    main2 = sqlite3.connect(':memory:')
    t('안 붙은 연결은 available False', available(main2) is False)
    main2.close()
    # 뗐다 다시 붙이기 — 파일 교체의 전제
    t('뗀다', detach(main) is True)
    t('떼면 available False', available(main) is False)
    t('두 번 떼면 False(무해)', detach(main) is False)
    t('다시 붙는다', attach(main, p) is True)
    # 스키마가 본체와 같은 모양인가 — 화면이 합칠 수 있어야 한다
    cols = {r[1] for r in main.execute('PRAGMA linkpack.table_info(pack_media)')}
    need = {'media_id', 'media_type', 'format_type', 'title', 'description',
            'url', 'lang_code', 'is_active', 'record_status'}
    t('미디어 칸이 본체 모양을 덮는다', need <= cols, sorted(need - cols))
    main.close()
    import shutil
    shutil.rmtree(d, ignore_errors=True)
    print('link_pack selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', errors='replace')
    if '--init' in sys.argv:
        print('팩 준비:', ensure())
    else:
        status()
