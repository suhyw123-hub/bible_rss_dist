# -*- coding: utf-8 -*-
"""db_term_link_audit.py — 용어(엔티티) 연결 품질 · **후보(검토중) 상태** · 재판정 (영구).

★★★ 핵심과제(2026-09-09 사용자 확정 — 「용어 연결 후보추천 시스템을 강력하게
  보완할 방법을 만들어야 한다 … 지금은 사용자가 없으므로 자동승인 방식을 적용하고
  나중에 승인품질을 업그레이드하는 재분류 절차를 만들면 된다」).

■ 무엇이 문제였나 (2026-09-09 실측 · 살아 있는 용어 연결 15,351건)
  | 유형 | 건수 | 뜻 |
  |---|---|---|
  | E 옛 규칙 잔재 | 2,429 | 지금 규칙으로는 안 만들어지는 연결(교리 1,012 · 용어 650) |
  | C 책 이름 동음 | 1,532 | 야곱←별명 「이스라엘」 485 · 유다 · 여호수아 · 로마 · 다니엘 |
  | D 설명문에만 | 2,901 | 제목엔 없고 설명문의 지나가는 언급으로 걸림 |
  | B 언어 칸 오류 |   876 | 연결이 아니라 영상의 `lang_code` 가 제목 문자와 다름 |
  사람이 [연결 해제]로 걷은 162건 중 139건이 E 였다 — 사람 판단과 규칙이 일치한다.

■ 설계 — 승인은 영상 단위, 연결은 링크 단위
  · 구절 연결은 정확도가 높아 **일단 승인**하고 개별 제외로 간다(사용자 확정).
  · 용어 연결은 **후보(`record_status='PEND'`)** 로 들어와 사람이 확인해야
    `LIVE` 가 된다. 사용자 화면·코어팩·자동 승인은 전부 `LIVE` 만 읽으므로
    후보는 아무 데도 안 나간다. 승인 단추는 하나로 남는다.
  · 근거가 강한 것(제목에 이름)은 처음부터 `LIVE` — 지금 사용자가 없어 자동
    연결로 두고, 규칙이 좋아지면 **재판정**(`--recheck`)으로 소급한다.
  · 사람이 뗀 것은 `note='MANUAL_HIDE'` 로 표식 — 재판정이 손대지 않는다.
  · 규칙 판(`TERM_LINK_RULE_VER`)을 `sys_config` 에 적어 「무슨 규칙으로
    판정했나」를 남긴다(207차 재분류와 같은 얼개).

■ 판정 규칙(`RULE_VER`)
  · 판정 재료 = **그 영상의 언어 이름표**로 제목·설명문을 다시 대조한다
    (`media_text_linker.build_context` · `db_media_range.name_ok`). 원래 연결을
    만든 문과 같은 문이다 — 두 벌이면 갈린다.
  · 살아 있는 자동 연결(`confidence` AUTO 또는 빈 값)을:
      E  지금 규칙으로 안 걸리는 것 ...................... PEND
      D  설명문에서만 걸리는 것 .......................... PEND
      C1 별명이 **민족·나라 이름**과 같은 것(이스라엘→야곱) .. PEND
      C2 책 이름과 같은 이름이 제목에서 **장·절 숫자 앞**에 선 것 PEND
      H  제목에 이름 ..................................... LIVE(유지)
    검색 근거(`confidence='TERM'`)·사람이 이은 것(`MANUAL`)·사람이 뗀 것은
    **손대지 않는다.**
  · 언어 칸(`sys_media_asset.lang_code`)이 제목 문자와 **또렷이** 어긋난 것
    (한글·가나·한자·아랍·키릴)은 제목 문자로 고친다. 라틴 문자권끼리는 못
    가르므로 안 건드린다. 옛 값은 `sys_config` 에 남겨 되돌린다.

사용:
  python db_term_link_audit.py --selftest
  python db_term_link_audit.py --check           # 판정만(쓰지 않음) · 유형표
  python db_term_link_audit.py --apply           # PEND 이관 + 언어 칸 수리 + 표식
  python db_term_link_audit.py --recheck         # 재판정(규칙이 바뀐 뒤) — apply 와 같은 문
  python db_term_link_audit.py --undo            # 이번 판 PEND 이관·언어 수리를 되돌린다
  python db_term_link_audit.py --restore ID,ID   # 사람이 뗀 것을 되살린다(번호 지정)
"""
import io
import os
import re
import sys
import json
import sqlite3
from datetime import date

sys.stdout.reconfigure(encoding='utf-8', errors='replace')
HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, 'bible_master.db')
RULE_VER = 5                        # 규칙을 바꾸면 올린다 — 재판정이 이 값을 적는다
#   판 5(2026-09-09) — **이름 앞뒤 문맥**(`db_media_range.name_context`): 성직 호칭 앞
#     (Pastor David Guzik) · 라틴 성 뒤(David Suchet) · 보통 낱말 「바로」에 애굽 문맥
#     없음 → 유형 N(설교자·보통 낱말). 사용자 메모 「베드로 키윅」·「Pastor Elias Morkos」.
#   판 3(2026-09-09) — 가타카나 경계 + 긴 이름 우선·소비(엘·레아·한나 조사에서)
#   판 4(2026-09-09) — ⓐ 판정 이름표에 교리·용어 유형을 넣는다(3패스 대상 밖이라
#     제목에 있어도 「없음」으로 읽혀 후보로 내려갔던 1,662건을 되살린다) ⓑ 중국어
#     책 접미(雅各書·彼得前书·约拿书)는 인물이 아니라 책 → C2 ⓒ 검색 근거(TERM)라도
#     **인물·장소 유형**의 이름이 제목·설명문 어디에도 없으면 후보(엘 → 아랍어 강론 14건)
#     ⓓ 재판정이 **후보를 되살린다** — 규칙이 좋아지면 내려간 것이 돌아온다
JUDGE_TYPES = ('PERSON', 'PLACE', 'NATION', 'GROUP', 'IDOL', 'OBJECT', 'FEAST',
               'SYSTEM', 'DOCTRINE', 'TERM')
_CJK_BOOK_SFX = ('書', '书', '記', '记', '前書', '後書', '前书', '后书')
RULE_KEY = 'TERM_LINK_RULE_VER'
LANG_BAK_KEY = 'TERM_LINK_LANG_BACKUP'
ORPHAN_KEY = 'TERM_LINK_UNAPPROVED'   # 연결이 후보뿐이라 승인을 내린 영상(undo 가 되돌린다)
#: ★★★ 용어 연결 전체 보류(2026-09-09 사용자 「안보이게 진행하라」) — 용어 검토를
#:   마칠 때까지 자동·검색 근거 용어 연결을 **전부 후보로** 내려 사용자 화면에 아무
#:   용어도 안 보이게 한다. 표식이 `TERMAUDIT_` 접두가 아니라 `--recheck` 가 되살리지
#:   않고 `--undo` 도 안 건드린다 — 푸는 문은 `--release-hold` 하나.
NOTE_HOLD = 'HOLD_ALL_20260909'
HOLD_KEY = 'TERM_HOLD_UNAPPROVED'    # 보류로 연결이 0 이 되어 승인을 내린 영상
ST_PEND = 'PEND'                    # 후보(검토중) — 사용자 화면·팩·자동 승인이 안 읽는다
NOTE_PFX = 'TERMAUDIT_'             # 이 도구가 옮긴 표식 — undo 가 이것만 되돌린다
NOTE_MANUAL = 'MANUAL_HIDE'         # 사람이 [연결 해제]로 걷은 것
NOTE_RECLASS = 'RECLASS_HIDE'       # [재검토 유보]가 뗀 것 — 사람 판정이 아니라 **분석 재료**
#   (2026-09-09 사용자 「사람이 뗀 것이라고 표시하지 마라. 그것조차 네가 다시 분석하는 게
#    좋다. 그래야 자동연결 도구 기능이 개선된다」). `--reclass-hidden` 이 「왜 걸렸나」를 낸다.
NOTE_RESTORE = 'RESTORED_'
TBL = 'sys_link_asset'
LT_ENTI = 'MEDI_ENTI'

_NATION_ALIAS = {'이스라엘', 'israel', 'judah', 'edom', 'moab', 'ammon', '유다', '에돔',
                 '모압', '암몬', 'egypt', '애굽', 'canaan', '가나안'}
_SCRIPT_OF_LANG = {'KO': 'KO', 'JA': 'JA', 'ZH': 'ZH', 'ZHT': 'ZH', 'AR': 'AR', 'RU': 'RU'}


def _quiet(msg):
    try:
        sys.stderr.write(str(msg) + '\n')
    except Exception:
        pass


def title_script(s):
    """제목의 문자 종류 — 또렷한 것만(라틴은 어느 언어인지 못 가르므로 'LAT')."""
    s = s or ''
    if re.search('[가-힣]', s):
        return 'KO'
    if re.search('[぀-ヿ]', s):
        return 'JA'
    if re.search('[一-鿿]', s):
        return 'ZH'
    if re.search('[؀-ۿ]', s):
        return 'AR'
    if re.search('[Ѐ-ӿ]', s):
        return 'RU'
    return 'LAT'


class Judge:
    """한 연결을 **원래 연결을 만든 문**으로 다시 대조한다(컨텍스트는 언어별 캐시)."""

    def __init__(self, conn):
        import media_text_linker as TL
        import db_media_range as MR
        self.conn, self.TL, self.MR = conn, TL, MR
        self._ctx = {}
        self._books = None

    def ctx(self, lang):
        lg = (lang or 'KO').upper()
        if lg not in self._ctx:
            cx = self.TL.build_context(self.conn, lg, types=JUDGE_TYPES)
            # ⚠ 기계 낱말(LEX 1만 개)은 뺀다 — 아무 글에나 걸린다(§181차)
            lex = self._lex_ids()
            cx['ent_terms'] = {k: v for k, v in cx['ent_terms'].items() if k not in lex}
            self._ctx[lg] = cx
        return self._ctx[lg]

    def _lex_ids(self):
        if not hasattr(self, '_lex'):
            try:
                self._lex = {r[0] for r in self.conn.execute(
                    "SELECT entity_id FROM sys_entity_master WHERE "
                    "COALESCE(json_extract(json_detail,'$.subtype'),'')='LEX'")}
            except Exception:
                self._lex = set()
        return self._lex

    def _etype(self, eid):
        if not hasattr(self, '_et'):
            self._et = {r[0]: r[1] for r in self.conn.execute(
                "SELECT entity_id, entity_type FROM sys_entity_master")}
        return self._et.get(int(eid), '')

    def book_ids(self):
        if self._books is None:
            try:
                self._books = set(int(k) for k in self.MR.book_name_entities(self.conn))
            except Exception:
                self._books = set()
        return self._books

    def explain(self, eid, lang, title, desc_json):
        """→ (where, term) : where ∈ title | desc | none.

        ⚠ 판정 문은 **링커와 같은 `match_terms`** 다 — 모든 엔티티 이름을 함께 놓고
          긴 이름이 먼저 자리를 차지한다. 그래야 「亞伯 in 亞伯拉罕」이 여기서도
          같은 답을 낸다(두 벌이면 재판정과 수집이 갈린다).
        """
        ent_terms = self.ctx(lang)['ent_terms']
        if int(eid) not in ent_terms:
            return 'none', ''
        try:
            yd = self.MR.yt_desc(desc_json)
        except Exception:
            yd = ''
        for where, txt in (('title', title or ''), ('desc', yd or '')):
            got = self.TL.match_terms(txt, ent_terms, persons=self.ctx(lang).get('person_ids'))
            if int(eid) in got:
                return where, got[int(eid)][0]
        # 문맥 때문에 떨어졌나 — 이름은 있는데 설교자·성·보통 낱말이면 'ctx'
        for txt in (title or '', yd or ''):
            got = self.TL.match_terms(txt, ent_terms, ctx_check=False)
            if int(eid) in got:
                return 'ctx', got[int(eid)][0]
        return 'none', ''

    def judge(self, eid, lang, title, desc_json, conf=''):
        """→ (유형 코드, 낱말). 유형 E·D·C1·C2 는 PEND, H 는 LIVE.

        ⚠ 검색 근거(`conf='TERM'`)는 제목에 이름이 없어도 정당하다(§210차 — 그
          용어로 찾았으니까). 다만 **인물·장소 등 실재 유형**은 이름이 어디에도
          없으면 검색어가 엉뚱한 것을 물어온 것이다(「엘」→아랍어 강론).
        """
        where, term = self.explain(eid, lang, title, desc_json)
        if where == 'ctx':
            return 'N', term          # 이름 문맥 — 설교자·성·보통 낱말
        if conf == 'TERM':
            if where == 'none' and self._etype(eid) not in ('TERM', 'DOCTRINE'):
                return 'E', term
            return 'H', term
        if where == 'none':
            return 'E', term
        if where == 'desc':
            return 'D', term
        # 중국어 책 접미 — 雅各書(야고보서)·彼得前书(베드로전서)·约拿书(요나서)
        for sfx in _CJK_BOOK_SFX:
            if (term + sfx) in (title or ''):
                return 'C2', term
        if term.strip().lower() in _NATION_ALIAS and int(eid) not in self._nation_ids():
            return 'C1', term
        if int(eid) in self.book_ids():
            # 이름 바로 뒤에 장·절 숫자(「Josué 1:9」·「다니엘 3장」) → 책을 가리킨 것
            if re.search(re.escape(term) + r'[\s\.]{0,2}\d', title or '', re.I):
                return 'C2', term
        return 'H', term

    def _nation_ids(self):
        if not hasattr(self, '_nat'):
            try:
                self._nat = {r[0] for r in self.conn.execute(
                    "SELECT entity_id FROM sys_entity_master WHERE entity_type='NATION'")}
            except Exception:
                self._nat = set()
        return self._nat


def rows_live_auto(conn):
    """판정 대상 — 살아 있는 자동·검색 근거 링크 + **이 도구가 후보로 내린 것**
    (규칙이 좋아지면 되살아나야 한다). 사람이 이은 것(MANUAL)·사람이 뗀 것은 밖."""
    return conn.execute(
        "SELECT l.sys_link_id, l.target_id, COALESCE(l.confidence,''), a.media_id, "
        "       a.title, a.description, a.lang_code, l.record_status "
        "FROM %s l JOIN sys_media_asset a ON a.media_id=l.clicked_id "
        "WHERE l.link_type=? AND COALESCE(a.record_status,'LIVE')='LIVE' "
        "  AND COALESCE(l.confidence,'') IN ('', 'AUTO', 'TERM') "
        "  AND (l.record_status='LIVE' OR (l.record_status=? AND l.note LIKE ?))"
        % TBL, (LT_ENTI, ST_PEND, NOTE_PFX + '%')).fetchall()


def classify(conn, log=None):
    """살아 있는 자동 용어 연결 전부를 판정 → {'PEND': [(link_id, code, term)…], 'LIVE': n, 'by': {code: n}}"""
    J = Judge(conn)
    pend, keep, by, revive = [], 0, {}, []
    for lid, eid, conf, _mid, title, desc, lang, st in rows_live_auto(conn):
        code, term = J.judge(eid, lang, title, desc, conf)
        by[code] = by.get(code, 0) + 1
        if code == 'H':
            keep += 1
            if st == ST_PEND:
                revive.append(lid)          # 규칙이 좋아져 되살아나는 것
        elif st == 'LIVE':
            pend.append((lid, code, term))
        # 이미 후보인데 여전히 후보면 그대로(표식 유지)
    return {'PEND': pend, 'LIVE': keep, 'by': by, 'REVIVE': revive}


def lang_fixes(conn):
    """제목 문자와 또렷이 어긋난 언어 칸 → [(media_id, 옛값, 새값)]."""
    out = []
    for mid, lang, title in conn.execute(
            "SELECT media_id, lang_code, title FROM sys_media_asset "
            "WHERE COALESCE(record_status,'LIVE')='LIVE' AND format_type='VIDEO'"):
        sc = title_script(title)
        if sc == 'LAT':
            continue                    # 라틴권은 어느 언어인지 못 가른다
        L = (lang or '').upper()
        if _SCRIPT_OF_LANG.get(L) == sc:
            continue
        if sc == 'ZH' and L in ('ZH', 'ZHT'):
            continue
        new = 'ZH' if sc == 'ZH' else sc
        out.append((mid, lang, new))
    return out


def human_hidden_ids(conn):
    """사람이 [연결 해제]로 걷은 것 — 감사 로그에서 초당 20건 미만으로 HIDE 된 것.
    (표식이 없던 옛 기록용. 이제 화면이 `MANUAL_HIDE` 를 적으므로 앞으로는 표식을 본다.)"""
    import collections
    hid = {r[0] for r in conn.execute(
        "SELECT sys_link_id FROM %s WHERE link_type=? AND record_status='HIDE' "
        "AND COALESCE(note,'')=''" % TBL, (LT_ENTI,))}
    if not hid:
        return []
    try:
        ev = {}
        for pk, ts, old in conn.execute(
                "SELECT pk, ts, old_json FROM sys_audit_log "
                "WHERE tbl=? AND action='UPDATE'", (TBL,)):
            try:
                pk = int(pk)
            except Exception:
                continue
            if pk not in hid:
                continue
            try:
                o = json.loads(old or '{}')
            except Exception:
                o = {}
            if (o.get('record_status') or 'LIVE') == 'LIVE':
                ev[pk] = max(ev.get(pk, ''), ts or '')
    except Exception:
        return []
    sec = collections.Counter(t[:19] for t in ev.values())
    return sorted(pk for pk, t in ev.items() if sec[t[:19]] < 20)


def apply(conn, log=print, tag=None):
    """판정대로 옮긴다 → 요약 dict. 멱등(이미 옮긴 것은 다시 안 옮긴다)."""
    tag = tag or NOTE_PFX + date.today().isoformat().replace('-', '')
    res = classify(conn)
    n = 0
    for lid, code, term in res['PEND']:
        conn.execute("UPDATE %s SET record_status=?, note=? WHERE sys_link_id=? "
                     "AND record_status='LIVE'" % TBL,
                     (ST_PEND, '%s_%s' % (tag, code), lid))
        n += 1
    nr = 0
    for lid in res.get('REVIVE') or []:
        nr += conn.execute("UPDATE %s SET record_status='LIVE', note=NULL "
                           "WHERE sys_link_id=? AND record_status=?" % TBL,
                           (lid, ST_PEND)).rowcount
    # 사람이 뗀 것에 표식
    hm = human_hidden_ids(conn)
    if hm:
        conn.executemany("UPDATE %s SET note=? WHERE sys_link_id=? AND COALESCE(note,'')=''"
                         % TBL, [(NOTE_MANUAL, i) for i in hm])
    # 언어 칸
    fixes = lang_fixes(conn)
    if fixes:
        bak = {}
        try:
            r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                             (LANG_BAK_KEY,)).fetchone()
            bak = json.loads(r[0]) if r and r[0] else {}
        except Exception:
            bak = {}
        for mid, old, new in fixes:
            bak.setdefault(str(mid), old or '')
            conn.execute("UPDATE sys_media_asset SET lang_code=? WHERE media_id=?", (new, mid))
        conn.execute("INSERT OR REPLACE INTO sys_config(config_key, config_val) VALUES(?,?)",
                     (LANG_BAK_KEY, json.dumps(bak)))
    # ★★ 승인 = 연결(§194차). 살아 있는 연결이 후보로 다 옮겨져 **연결이 0 이 된
    #   승인 영상**은 미검토로 내린다 — 어느 화면에도 안 나오는데 승인만 남으면
    #   무결성 검사가 「고립」으로 잡는다. 후보를 [확인]하면 다시 승인하면 된다.
    orphans = [r[0] for r in conn.execute(
        "SELECT a.media_id FROM sys_media_asset a WHERE a.is_active=1 "
        "AND COALESCE(a.record_status,'LIVE')='LIVE' AND NOT EXISTS("
        " SELECT 1 FROM %s l WHERE l.clicked_id=a.media_id "
        " AND l.link_type IN ('MEDI_ENTI','MEDI_VERS') AND l.record_status='LIVE') "
        "AND EXISTS(SELECT 1 FROM %s l WHERE l.clicked_id=a.media_id "
        " AND l.link_type='MEDI_ENTI' AND l.record_status=?)" % (TBL, TBL), (ST_PEND,))]
    if orphans:
        conn.executemany("UPDATE sys_media_asset SET is_active=0 WHERE media_id=?",
                         [(m,) for m in orphans])
        try:
            r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                             (ORPHAN_KEY,)).fetchone()
            prev = json.loads(r[0]) if r and r[0] else []
        except Exception:
            prev = []
        conn.execute("INSERT OR REPLACE INTO sys_config(config_key, config_val) VALUES(?,?)",
                     (ORPHAN_KEY, json.dumps(sorted(set(prev) | set(orphans)))))
    conn.execute("INSERT OR REPLACE INTO sys_config(config_key, config_val) VALUES(?,?)",
                 (RULE_KEY, json.dumps({'ver': RULE_VER, 'at': date.today().isoformat(),
                                        'tag': tag})))
    conn.commit()
    out = {'pend': n, 'revived': nr, 'by': res['by'], 'live': res['LIVE'],
           'manual_marked': len(hm), 'lang_fixed': len(fixes),
           'unapproved': len(orphans), 'tag': tag}
    if log:
        log('용어 연결 재판정(규칙 %d) — 후보로 %d · 되살림 %d · 유지 %d · 유형 %s · '
            '사람 표식 %d · 언어 칸 수리 %d · 연결 0 이 된 승인 영상 미검토로 %d'
            % (RULE_VER, n, nr, res['LIVE'], res['by'], len(hm), len(fixes),
               len(orphans)))
    return out


def hold_all(conn, log=print):
    """살아 있는 자동·검색 근거 용어 연결을 전부 후보로(사람이 이은 MANUAL·확인한 것은 둔다).
    연결이 후보뿐이 된 승인 영상은 미검토로(승인=연결 §194차)."""
    n = conn.execute(
        "UPDATE %s SET record_status=?, note=? WHERE link_type=? AND record_status='LIVE'"
        " AND COALESCE(confidence,'') IN ('', 'AUTO', 'TERM') AND COALESCE(note,'')<>'CONFIRMED'"
        % TBL, (ST_PEND, NOTE_HOLD, LT_ENTI)).rowcount
    orphans = [r[0] for r in conn.execute(
        "SELECT a.media_id FROM sys_media_asset a WHERE a.is_active=1"
        "  AND NOT EXISTS(SELECT 1 FROM %s l WHERE l.clicked_id=a.media_id"
        "                 AND l.link_type LIKE 'MEDI%%' AND l.record_status='LIVE')" % TBL)]
    for mid in orphans:
        conn.execute("UPDATE sys_media_asset SET is_active=0 WHERE media_id=?", (mid,))
    conn.execute("INSERT OR REPLACE INTO sys_config(config_key, config_val) VALUES(?,?)",
                 (HOLD_KEY, json.dumps(orphans)))
    conn.commit()
    if log:
        log('용어 연결 보류 — 후보로 %d · 연결이 없어진 승인 영상 미검토로 %d' % (n, len(orphans)))
    return n, len(orphans)


def release_hold(conn, log=print):
    """보류를 푼다 — 그 표식의 후보만 LIVE 로, 내린 승인을 되돌린다."""
    n = conn.execute("UPDATE %s SET record_status='LIVE', note=NULL WHERE link_type=?"
                     " AND record_status=? AND note=?" % TBL, (LT_ENTI, ST_PEND, NOTE_HOLD)).rowcount
    k = 0
    r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?", (HOLD_KEY,)).fetchone()
    for mid in (json.loads(r[0]) if r and r[0] else []):
        k += conn.execute("UPDATE sys_media_asset SET is_active=1 WHERE media_id=?", (int(mid),)).rowcount
    conn.execute("DELETE FROM sys_config WHERE config_key=?", (HOLD_KEY,))
    conn.commit()
    if log:
        log('보류 해제 — LIVE 로 %d · 승인 복귀 %d' % (n, k))
    return n, k


def undo(conn, log=print, tag=None):
    """이 도구가 옮긴 PEND 를 LIVE 로 · 언어 칸을 옛 값으로. 사람 표식은 남긴다."""
    like = (tag or NOTE_PFX) + '%'
    n = conn.execute("UPDATE %s SET record_status='LIVE', note=NULL "
                     "WHERE link_type=? AND record_status=? AND note LIKE ?" % TBL,
                     (LT_ENTI, ST_PEND, like)).rowcount
    m = 0
    try:
        r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                         (LANG_BAK_KEY,)).fetchone()
        bak = json.loads(r[0]) if r and r[0] else {}
        for mid, old in bak.items():
            conn.execute("UPDATE sys_media_asset SET lang_code=? WHERE media_id=?",
                         (old or None, int(mid)))
            m += 1
        conn.execute("DELETE FROM sys_config WHERE config_key=?", (LANG_BAK_KEY,))
    except Exception:
        pass
    k = 0
    try:
        r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                         (ORPHAN_KEY,)).fetchone()
        for mid in (json.loads(r[0]) if r and r[0] else []):
            k += conn.execute("UPDATE sys_media_asset SET is_active=1 WHERE media_id=?",
                              (int(mid),)).rowcount
        conn.execute("DELETE FROM sys_config WHERE config_key=?", (ORPHAN_KEY,))
    except Exception:
        pass
    conn.commit()
    if log:
        log('되돌림 — 후보 %d → LIVE · 언어 칸 %d 원복 · 승인 복귀 %d' % (n, m, k))
    return n, m


def restore(conn, ids, log=print):
    """사람이 뗀 것을 되살린다(번호 지정 · 표식 남김)."""
    tag = NOTE_RESTORE + date.today().isoformat()
    n = 0
    for i in ids:
        n += conn.execute("UPDATE %s SET record_status='LIVE', note=? "
                          "WHERE sys_link_id=? AND record_status='HIDE'" % TBL,
                          (tag, int(i))).rowcount
    conn.commit()
    if log:
        log('되살림 %d/%d' % (n, len(ids)))
    return n


# ── 후보(검토중) 줄 비우기 ─────────────────────────────────────────────
#: 「붙박이 소개문」 판정 — 한 채널에서 같은 용어가 이만큼 되풀이되는데 **제목에는 한 번도 없다**.
BOILER_MIN = 5
PEND_TAG = 'TERMPEND_'          # 이 문이 내린 표식 — `pend_undo` 가 이것만 되돌린다


def pend_rows(conn):
    """심사대기(PEND) 용어 연결 — **미승인 영상**의 것만. → [(link_id, eid, mid, 제목, 설명문, 언어, 채널, 근거)]

    ⚠ 승인된 영상의 후보 연결은 여기서 안 건드린다 — 그것은 「보일까 말까」의 문제라
      결이 다르다(사용자 화면은 어차피 LIVE 만 읽는다)."""
    return conn.execute(
        "SELECT l.sys_link_id, l.target_id, a.media_id, a.title, a.description, a.lang_code,"
        "       COALESCE(json_extract(a.description,'$.channel'),''), COALESCE(l.confidence,'')"
        "  FROM %s l JOIN sys_media_asset a ON a.media_id=l.clicked_id"
        " WHERE l.link_type=? AND l.record_status=? AND a.is_active=0"
        "   AND COALESCE(a.record_status,'LIVE')='LIVE'"
        "   AND COALESCE(l.confidence,'') IN ('', 'AUTO', 'TERM')"
        "   AND COALESCE(l.note,'') <> 'MANUAL_HIDE'" % TBL,
        (LT_ENTI, ST_PEND)).fetchall()


def pend_plan(conn, log=None):
    """후보 줄을 셋으로 가른다 → {'UP': [id…], 'BOILER': [(id, 채널, 낱말)…], 'KEEP': n, 'by': {…}}

    ★★★ 잣대는 **실측이 정했다**(2026-09-17 · 용어 연결 73,513건 전수):
      | 근거 | 건수 | 살아남은 비율 |
      |---|---|---|
      | **제목**(`TITLE:…`) | 7,867 | **99%** — 사람이 뗀 것 0 |
      | 설명문(`DESC:…`) | 29,742 | **0.3%** |
      ⇒ **제목에 이름이 있으면 올리고**(`Judge` 가 지금 규칙으로도 H 라 해야 한다),
        **붙박이 소개문은 내린다**. 나머지(설명문에 한 번 지나간 것)는 **그대로 둔다** —
        틀렸다고 단정할 근거가 없고, 후보는 어차피 아무 데도 안 나간다.
    ⚠ 「제목에 있다」를 글자 맞춤으로만 보면 **「교회에서」의 `에서`(에서)·「아이들」의 `아이`(아이 성)**
      가 올라온다. 그래서 판정은 **이 파일의 `Judge`**(`name_ok`·문맥·책 이름 규칙)가 한다."""
    J = Judge(conn)
    rows = pend_rows(conn)
    # ⚠⚠ **갈래 규칙을 먼저 본다**(2026-09-17 하네스가 잡았다) — 찬양에서 「가사」(유대 지명 Gaza)는
    #   안 잇는다(§241차 ⑫). 제목에 그 글자가 있으니 `Judge` 는 H 라 하는데 **그 갈래에서는 틀린 연결**
    #   이다. 올리는 문이 그 규칙을 안 보면 걷어 둔 것이 되살아난다(실측 1건).
    import media_text_linker as _TL
    _TL.skip_reset()
    pair = {}
    judged = []
    for lid, eid, mid, ti, de, lg, ch, conf in rows:
        code, term = J.judge(eid, lg, ti, de, conf)
        if code == 'H' and _TL._skip_entity(conn, mid, eid):
            code = 'S'                      # 갈래 규칙이 막는다 — 올리지 않는다
        judged.append((lid, eid, ch, code, term))
        k = (ch, eid)
        p = pair.setdefault(k, [0, 0])
        p[0] += 1
        if code == 'H':
            p[1] += 1
    boiler_keys = {k for k, v in pair.items() if v[0] >= BOILER_MIN and v[1] == 0}
    out = {'UP': [], 'BOILER': [], 'KEEP': 0, 'by': {}}
    for lid, eid, ch, code, term in judged:
        out['by'][code] = out['by'].get(code, 0) + 1
        if code == 'H':
            out['UP'].append(lid)
        elif (ch, eid) in boiler_keys:
            out['BOILER'].append((lid, ch, term))
        else:
            out['KEEP'] += 1
    if log:
        log('  후보 %d건 → 올림(제목 근거) %d · 붙박이 소개문 내림 %d · 그대로 %d  %s'
            % (len(rows), len(out['UP']), len(out['BOILER']), out['KEEP'], out['by']))
    return out


def pend_apply(conn, dry=False, log=print, tag=None):
    """`pend_plan` 을 적용 → (올린 수, 내린 수). `--pend-undo` 로 되돌린다."""
    p = pend_plan(conn, log=log)
    if dry:
        return 0, 0
    tag = tag or PEND_TAG + date.today().isoformat().replace('-', '')
    up = 0
    for i in p['UP']:
        up += conn.execute(
            "UPDATE %s SET record_status='LIVE', note=? WHERE sys_link_id=? AND record_status=?" % TBL,
            (tag + '_UP', int(i), ST_PEND)).rowcount
    down = 0
    for i, _ch, _t in p['BOILER']:
        down += conn.execute(
            "UPDATE %s SET record_status='HIDE', note=? WHERE sys_link_id=? AND record_status=?" % TBL,
            (tag + '_BOILER', int(i), ST_PEND)).rowcount
    conn.commit()
    log('  **올림 %d · 내림 %d** (표식 %s)' % (up, down, tag))
    return up, down


def pend_undo(conn, log=print, tag=None):
    """이 문이 올리거나 내린 것을 후보로 되돌린다."""
    like = (tag or PEND_TAG) + '%'
    n = conn.execute(
        "UPDATE %s SET record_status=?, note=NULL WHERE link_type=? AND COALESCE(note,'') LIKE ?" % TBL,
        (ST_PEND, LT_ENTI, like)).rowcount
    conn.commit()
    log('  후보로 되돌림 %d건' % n)
    return n


def confirm(conn, link_ids):
    """검토 화면 [확인] — 후보를 LIVE 로(사람이 확인한 표식)."""
    n = 0
    for i in link_ids:
        n += conn.execute("UPDATE %s SET record_status='LIVE', confidence='MANUAL', "
                          "note='CONFIRMED' WHERE sys_link_id=? AND record_status=?" % TBL,
                          (int(i), ST_PEND)).rowcount
    conn.commit()
    return n


def reclass_hidden_rows(conn):
    """[재검토 유보]가 뗀 용어 연결 — 자동연결이 왜 그것을 걸었는지 판정과 함께 낸다.
    → [(link_id, 엔티티 코드, 이름, 유형, lang, 판정 코드, 걸린 낱말, 제목)]
    분석자가 읽고 **규칙(판)을 올리는 재료**다."""
    J = Judge(conn)
    out = []
    for lid, eid, conf, title, desc, lang, code, nm, et in conn.execute(
            "SELECT l.sys_link_id, l.target_id, COALESCE(l.confidence,''), a.title,"
            "       a.description, a.lang_code, em.entity_code,"
            "       COALESCE((SELECT contents FROM sys_text_asset WHERE clicked_id=em.entity_id"
            "                 AND text_type='ENTITY_NAME' AND lang_code='KO'), em.entity_code),"
            "       em.entity_type"
            "  FROM %s l JOIN sys_media_asset a ON a.media_id=l.clicked_id"
            "  JOIN sys_entity_master em ON em.entity_id=l.target_id"
            " WHERE l.link_type=? AND l.record_status='HIDE' AND l.note=?"
            " ORDER BY em.entity_code, l.sys_link_id" % TBL, (LT_ENTI, NOTE_RECLASS)):
        jc, term = J.judge(eid, lang, title, desc, conf)
        out.append((lid, code, nm, et, lang or '', jc, term, title or ''))
    return out


def status(conn):
    q = lambda s, a=(): conn.execute(s, a).fetchone()[0]
    return {
        'reclass_hide': q("SELECT COUNT(*) FROM %s WHERE link_type=? AND note=?" % TBL, (LT_ENTI, NOTE_RECLASS)),
        'hold': q("SELECT COUNT(*) FROM %s WHERE link_type=? AND note=?" % TBL, (LT_ENTI, NOTE_HOLD)),
        'live': q("SELECT COUNT(*) FROM %s WHERE link_type=? AND record_status='LIVE'" % TBL, (LT_ENTI,)),
        'pend': q("SELECT COUNT(*) FROM %s WHERE link_type=? AND record_status=?" % TBL, (LT_ENTI, ST_PEND)),
        'hide': q("SELECT COUNT(*) FROM %s WHERE link_type=? AND record_status='HIDE'" % TBL, (LT_ENTI,)),
        'manual_hide': q("SELECT COUNT(*) FROM %s WHERE link_type=? AND note=?" % TBL, (LT_ENTI, NOTE_MANUAL)),
        'rule': (conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                              (RULE_KEY,)).fetchone() or [''])[0],
    }


# ── 자가 검증(메모리 DB · 실 DB 불변) ──────────────────────────────────
def _mem():
    c = sqlite3.connect(':memory:')
    c.executescript("""
    CREATE TABLE sys_config(config_key TEXT PRIMARY KEY, config_val TEXT);
    CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY, media_type TEXT, format_type TEXT,
        title TEXT, description TEXT, url TEXT, lang_code TEXT, is_active INT, record_status TEXT);
    CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY, clicked_id INT, target_id INT,
        link_type TEXT, rel_code TEXT, record_status TEXT, end_id INT, note TEXT, confidence TEXT);
    CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY, entity_code TEXT, entity_type TEXT,
        json_detail TEXT, record_status TEXT);
    CREATE TABLE sys_text_asset(clicked_id INT, text_type TEXT, lang_code TEXT, contents TEXT, record_status TEXT);
    CREATE TABLE book_names(book_code INT, lang_code TEXT, full_name TEXT, short_name TEXT);
    CREATE TABLE sys_pericope_asset(pericope_id INTEGER PRIMARY KEY, start_vid INT, end_vid INT,
        record_status TEXT, peri_type TEXT);
    CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY, bcode INT, chapter INT, verse INT);
    CREATE TABLE sys_audit_log(audit_id INTEGER PRIMARY KEY, ts TEXT, tbl TEXT, pk TEXT, action TEXT, old_json TEXT);
    """)
    ents = [(1, 'P_DAVID', 'PERSON', '다윗', 'David'), (2, 'P_JACOB', 'PERSON', '야곱', 'Jacob'),
            (3, 'P_DANIEL', 'PERSON', '다니엘', 'Daniel'), (4, 'D_COVENANT', 'DOCTRINE', '언약', 'Covenant'),
            (5, 'N_ISRAEL', 'NATION', '이스라엘', 'Israel'),
            (6, 'P_HAM', 'PERSON', '함', 'Ham'), (7, 'P_ABRAHAM', 'PERSON', '아브라함', 'Abraham'),
            (8, 'P_ZECH', 'PERSON', '스가랴', 'Zechariah'), (9, 'P_LEAH', 'PERSON', '레아', 'Leah')]
    for eid, ja in ((6, 'ハム'), (7, 'アブラハム')):
        c.execute("INSERT INTO sys_text_asset VALUES(?,?,?,?, 'LIVE')", (eid, 'ENTITY_NAME', 'JA', ja))
    for eid, zh in ((8, '撒迦利亞'), (9, '利亞'), (2, '雅各')):
        c.execute("INSERT INTO sys_text_asset VALUES(?,?,?,?, 'LIVE')", (eid, 'ENTITY_NAME', 'ZHT', zh))
    for eid, code, ty, ko, en in ents:
        jd = json.dumps({'aliases': {'KO': ['이스라엘']}}) if code == 'P_JACOB' else None
        c.execute("INSERT INTO sys_entity_master VALUES(?,?,?,?, 'LIVE')", (eid, code, ty, jd))
        c.execute("INSERT INTO sys_text_asset VALUES(?,?,?,?, 'LIVE')", (eid, 'ENTITY_NAME', 'KO', ko))
        c.execute("INSERT INTO sys_text_asset VALUES(?,?,?,?, 'LIVE')", (eid, 'ENTITY_NAME', 'EN', en))
    for bc, ko, kos, en, ens in ((1, '창세기', '창', 'Genesis', 'Gen'), (27, '다니엘', '단', 'Daniel', 'Dan')):
        c.execute("INSERT INTO book_names VALUES(?,?,?,?)", (bc, 'KO', ko, kos))
        c.execute("INSERT INTO book_names VALUES(?,?,?,?)", (bc, 'EN', en, ens))
    vids = [(1, 1, 1, 1), (2, 1, 1, 2), (100, 27, 3, 1)]
    for v in vids:
        c.execute("INSERT INTO bible_index VALUES(?,?,?,?)", v)
    c.execute("INSERT INTO sys_pericope_asset VALUES(1,1,2,'LIVE','BODY')")
    med = [(1, '다윗과 골리앗 설교', '{"yt_desc":"삼상 17장"}', 'KO'),           # H
           (2, "오늘의 말씀", "{\"yt_desc\":\"다윗이 기도합니다\"}", "KO"),       # D
           (3, '주일예배 실황', '{"yt_desc":"은혜로운 예배"}', 'KO'),            # E (언약) · 승인됨
           (4, '이스라엘 성지순례', '{"yt_desc":""}', 'KO'),                    # C1 (야곱←이스라엘)
           (5, 'Daniel 3 Bible Study', '{"yt_desc":""}', 'EN'),                 # C2
           (6, '한국어 제목인데 언어가 틀림', '{"yt_desc":""}', 'ZHT'),        # lang fix
           (7, 'Daniel and the lions', '{"yt_desc":""}', 'EN'),                 # H (숫자 없음)
           (8, 'アブラハムの試練', '{"yt_desc":""}', 'JA'),                      # 함=조각 · 아브라함 H
           (9, '撒迦利亞先知的異象', '{"yt_desc":""}', 'ZHT'),                   # 레아=조각 · 스가랴 H
           (10, '언약의 하나님', '{"yt_desc":""}', 'KO'),                          # 교리 이름이 제목에 → H
           (11, '雅各書1章', '{"yt_desc":""}', 'ZHT'),                             # 야곱 ← 雅各書 = 책 → C2
           (12, 'Homily on trust', '{"yt_desc":"nothing"}', 'AR'),                # 검색 근거 인물, 이름 없음 → E
           (13, 'Daily devotional by Pastor David Guzik', '{"yt_desc":""}', 'EN')]  # 성직 호칭 → N
    for mid, ti, de, lg in med:
        c.execute("INSERT INTO sys_media_asset VALUES(?,?,?,?,?,?,?,?,?)",
                  (mid, 'SERMON', 'VIDEO', ti, de, 'https://x/%d' % mid, lg,
                   1 if mid == 3 else 0, 'LIVE'))
    links = [(11, 1, 1), (12, 2, 1), (13, 3, 4), (14, 4, 2), (15, 5, 3), (17, 7, 3),
             (21, 8, 6), (22, 8, 7), (23, 9, 9), (24, 9, 8), (25, 10, 4), (26, 11, 2),
             (29, 13, 1)]
    for lid, mid, eid in links:
        c.execute("INSERT INTO sys_link_asset VALUES(?,?,?,?,?,?,?,?,?)",
                  (lid, mid, eid, LT_ENTI, None, 'LIVE', None, None, 'AUTO'))
    # 사람이 이은 것·검색 근거는 안 건드린다
    c.execute("INSERT INTO sys_link_asset VALUES(18,7,1,?,NULL,'LIVE',NULL,NULL,'MANUAL')", (LT_ENTI,))
    c.execute("INSERT INTO sys_link_asset VALUES(19,7,1,?,NULL,'LIVE',NULL,NULL,'TERM')", (LT_ENTI,))
    c.execute("INSERT INTO sys_link_asset VALUES(27,12,1,?,NULL,'LIVE',NULL,NULL,'TERM')", (LT_ENTI,))
    c.execute("INSERT INTO sys_link_asset VALUES(28,12,4,?,NULL,'LIVE',NULL,NULL,'TERM')", (LT_ENTI,))
    # 사람이 뗀 것 하나(감사 로그로 갈린다)
    c.execute("INSERT INTO sys_link_asset VALUES(20,1,2,?,NULL,'HIDE',NULL,NULL,'AUTO')", (LT_ENTI,))
    c.execute("INSERT INTO sys_audit_log VALUES(1,'2026-09-08 10:00:01','sys_link_asset','20','UPDATE',?)",
              (json.dumps({'record_status': 'LIVE'}),))
    c.commit()
    return c


def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got if not cond else ''))

    c = _mem()
    res = classify(c)
    by = res['by']
    pend = {lid: code for lid, code, _t in res['PEND']}
    t('H 제목에 이름은 유지', 11 not in pend and 17 not in pend, pend)
    t('★★★ D 설명문에만 → 후보', pend.get(12) == 'D', pend)
    t('★★★ E 옛 규칙 잔재(교리) → 후보', pend.get(13) == 'E', pend)
    t('★★★ C1 별명 이스라엘→야곱 → 후보', pend.get(14) == 'C1', pend)
    t('★★★ C2 책 이름 + 장 숫자 → 후보', pend.get(15) == 'C2', pend)
    t('★★★ 가타카나 조각(ハム in アブラハム) → 후보 · 긴 이름은 유지',
      pend.get(21) == 'E' and 22 not in pend, pend)
    t('★★★ 한자 조각(利亞 in 撒迦利亞) → 후보 · 긴 이름은 유지',
      pend.get(23) == 'E' and 24 not in pend, pend)
    t('★★★ 교리 이름이 제목에 있으면 유지(판정 이름표에 교리·용어 포함)', 25 not in pend, pend)
    t('★★★ 중국어 책 접미(雅各書) → 후보', pend.get(26) == 'C2', pend)
    t('★★★ 성직 호칭 앞의 이름은 설교자 → N(판 5)', pend.get(29) == 'N', pend)
    t('★★★ 검색 근거라도 인물 이름이 어디에도 없으면 후보 · 교리는 유지',
      pend.get(27) == 'E' and 28 not in pend, pend)
    t('  사람이 이은 것은 판정 밖 · 검색 근거라도 인물 이름이 없으면 후보',
      18 not in pend and pend.get(19) == 'E', res)
    out = apply(c, log=None)
    st = status(c)
    t('★★ apply — 후보 10', out['pend'] == 10 and st['pend'] == 10, (out, st))
    # ★★★ 규칙이 좋아지면 후보가 되살아난다 — 12번(D)을 제목에 이름을 넣어 다시 판정
    c.execute("UPDATE sys_media_asset SET title='다윗의 기도' WHERE media_id=2")
    c.commit()
    out2 = apply(c, log=None)
    t('★★★ 재판정이 후보를 되살린다', out2['revived'] == 1
      and c.execute("SELECT record_status FROM sys_link_asset WHERE sys_link_id=12").fetchone()[0] == 'LIVE', out2)
    t('  표식이 유형을 적는다', c.execute("SELECT note FROM sys_link_asset WHERE sys_link_id=14").fetchone()[0].endswith('_C1'))
    t('★★ 사람이 뗀 것에 MANUAL_HIDE 표식', st['manual_hide'] == 1, st)
    t('★★ 언어 칸 수리(한글 제목 ZHT → KO)',
      c.execute("SELECT lang_code FROM sys_media_asset WHERE media_id=6").fetchone()[0] == 'KO')
    t('  규칙 판을 남긴다', '"ver": %d' % RULE_VER in (st['rule'] or ''), st['rule'])
    t('★★ 연결이 후보뿐이 된 승인 영상은 미검토로', out['unapproved'] == 1
      and c.execute("SELECT is_active FROM sys_media_asset WHERE media_id=3").fetchone()[0] == 0, out)
    t('  멱등 — 다시 apply 해도 0', apply(c, log=None)['pend'] == 0)
    # 확인·되돌리기
    t('★ [확인]이 후보를 LIVE 로', confirm(c, [13]) == 1
      and c.execute("SELECT record_status, confidence FROM sys_link_asset WHERE sys_link_id=13").fetchone() == ('LIVE', 'MANUAL'))
    n, m = undo(c, log=None)
    st2 = status(c)
    t('★★ undo — 남은 후보 → LIVE · 언어 칸 원복', n == 8 and st2['pend'] == 0
      and c.execute("SELECT lang_code FROM sys_media_asset WHERE media_id=6").fetchone()[0] == 'ZHT', (n, st2))
    t('  undo 가 사람 표식은 안 지운다', st2['manual_hide'] == 1)
    t('  undo 가 승인을 되돌린다', c.execute("SELECT is_active FROM sys_media_asset WHERE media_id=3").fetchone()[0] == 1)
    t('  undo 가 확인한 것은 안 건드린다',
      c.execute("SELECT note FROM sys_link_asset WHERE sys_link_id=13").fetchone()[0] == 'CONFIRMED')
    # ── [재검토 유보]가 뗀 것 — 사람 표식이 아니라 분석 재료
    c.execute("UPDATE sys_link_asset SET record_status='HIDE', note=? WHERE sys_link_id=11", (NOTE_RECLASS,))
    c.commit()
    rr = reclass_hidden_rows(c)
    t('★★ 유보가 뗀 것은 --reclass-hidden 재료로 나온다(판정 코드 포함)',
      len(rr) == 1 and rr[0][0] == 11 and rr[0][5] == 'H', rr)
    t('  사람 표식(MANUAL_HIDE)으로 세지 않는다 · 재판정 대상도 아니다',
      status(c)['manual_hide'] == 1 and status(c)['reclass_hide'] == 1
      and 11 not in {r[0] for r in rows_live_auto(c)})
    undo(c)
    t('  undo 가 유보가 뗀 것을 되살리지 않는다',
      c.execute("SELECT record_status FROM sys_link_asset WHERE sys_link_id=11").fetchone()[0] == 'HIDE')
    # ── 전체 보류(안보이게) — 사람이 이은 것·확인한 것만 남는다
    live0 = c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type=? AND record_status='LIVE'", (LT_ENTI,)).fetchone()[0]
    act0 = c.execute("SELECT COUNT(*) FROM sys_media_asset WHERE is_active=1").fetchone()[0]
    nh, no = hold_all(c, log=None)
    left = c.execute("SELECT confidence, note FROM sys_link_asset WHERE link_type=? AND record_status='LIVE'", (LT_ENTI,)).fetchall()
    t('★★★ 보류 — 남는 LIVE 는 MANUAL·CONFIRMED 뿐',
      nh > 0 and all((cf == 'MANUAL') or (nt == 'CONFIRMED') for cf, nt in left), left)
    t('  연결이 없어진 승인 영상은 미검토로', no >= 0 and
      c.execute("SELECT COUNT(*) FROM sys_media_asset a WHERE is_active=1 AND NOT EXISTS("
                "SELECT 1 FROM sys_link_asset l WHERE l.clicked_id=a.media_id AND l.record_status='LIVE')").fetchone()[0] == 0)
    apply(c, log=None)
    t('★★ 재판정이 보류를 되살리지 않는다',
      c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE note=?", (NOTE_HOLD,)).fetchone()[0] == nh)
    undo(c, log=None)
    t('  undo 도 보류를 안 건드린다',
      c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE note=?", (NOTE_HOLD,)).fetchone()[0] == nh)
    nr, nk = release_hold(c, log=None)
    t('★★ 보류 해제 — LIVE 수·승인 수가 돌아온다', nr == nh and nk == no
      and c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type=? AND record_status='LIVE'", (LT_ENTI,)).fetchone()[0] == live0
      and c.execute("SELECT COUNT(*) FROM sys_media_asset WHERE is_active=1").fetchone()[0] == act0,
      (nr, nh, nk, no))
    t('★ restore 가 뗀 것을 되살린다', restore(c, [20], log=None) == 1
      and c.execute("SELECT record_status FROM sys_link_asset WHERE sys_link_id=20").fetchone()[0] == 'LIVE')
    # 탐지력 — 판정 문을 늘 참으로 되돌리면 후보가 0 이 된다
    J0 = Judge.judge
    Judge.judge = lambda self, *a: ('H', '')
    try:
        t('★ 탐지력 — 판정을 죽이면 후보 0', not classify(c)['PEND'])
    finally:
        Judge.judge = J0
    # 읽는 쪽 — 사용자 화면·팩·자동 승인이 PEND 를 안 읽는다(소스로 잰다)
    def src(p):
        return io.open(os.path.join(HERE, p), encoding='utf-8').read()
    t('★★★ 사용자 조회 문이 LIVE 만 읽는다(overlay_read — 링크 별칭 ml 에 상태 조건)',
      "COALESCE(ml.record_status,'LIVE')='LIVE'" in src('overlay_read.py'))
    t('★★★ 어린이 화면 세 조회가 링크 상태를 본다',
      src('kids_view.py').count("COALESCE(l.record_status,'LIVE')='LIVE'") >= 2
      and "WHERE COALESCE(record_status,'LIVE')='LIVE' AND (" in src('kids_view.py'))
    # ★★★ 실 DB 로 실제로 잰다 — 후보(PEND)뿐인 승인 영상이 용어 화면에 안 나온다
    try:
        import appdb as _ap, overlay_read as _or
        _rc = _ap.connect()
        try:
            _r = _rc.execute(
                "SELECT l.target_id, l.clicked_id FROM sys_link_asset l"
                " JOIN sys_media_asset a ON a.media_id=l.clicked_id"
                " WHERE l.link_type='MEDI_ENTI' AND l.record_status='PEND' AND a.is_active=1"
                "   AND NOT EXISTS(SELECT 1 FROM sys_link_asset x WHERE x.clicked_id=l.clicked_id"
                "                  AND x.target_id=l.target_id AND x.record_status='LIVE') LIMIT 1").fetchone()
            if _r:
                _mids = {d['mid'] for d in (_or.media(_rc, _r[0], 'ALL', 'KO') or []) if not d['is_user']}
                t('★★★ 실측 — 후보(PEND) 연결의 영상이 그 용어 화면에 없다', _r[1] not in _mids, _r)
            else:
                t('  (실 DB 에 후보 연결이 없어 실측 건너뜀)', True)
        finally:
            _rc.close()
    except Exception as _e:
        t('  (실 DB 없음 — 실측 건너뜀)', True, str(_e)[:40])
    t('★★★ 자동 승인이 LIVE 만 센다', "record_status,'LIVE')='LIVE'" in src('db_media_autoapprove.py'))
    t('★★★ 코어팩이 후보를 안 싣는다', "'PEND'" in src('db_pack_catalog.py'))
    t('★★★ 링크 팩이 LIVE 만 싣는다', "record_status,'LIVE')='LIVE'" in src('db_linkpack_build.py'))
    t('★★ 수집 문이 설명문 근거를 후보로 넣는다', "ST_PEND" in src('media_intake.py'))
    t('★★ 검토 화면이 [연결 해제]에 사람 표식을 적는다', "MANUAL_HIDE" in src('admin/panel_media.py'))
    print('db_term_link_audit selftest: %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    conn = sqlite3.connect(DB, timeout=60)
    if '--check' in a:
        res = classify(conn)
        print('후보로 옮길 것 %d · 유지 %d · 유형 %s' % (len(res['PEND']), res['LIVE'], res['by']))
        print('언어 칸 수리 대상 %d' % len(lang_fixes(conn)))
        print('사람이 뗀 것(표식 없음) %d' % len(human_hidden_ids(conn)))
    elif '--pend-check' in a:
        pend_apply(conn, dry=True)
    elif '--pend-apply' in a:
        pend_apply(conn)
    elif '--pend-undo' in a:
        pend_undo(conn)
    elif '--apply' in a or '--recheck' in a:
        print(apply(conn))
        print(status(conn))
    elif '--undo' in a:
        undo(conn)
        print(status(conn))
    elif '--hold-all' in a:
        hold_all(conn)
        print(status(conn))
    elif '--release-hold' in a:
        release_hold(conn)
        print(status(conn))
    elif '--reclass-hidden' in a:
        rows = reclass_hidden_rows(conn)
        print('link_id\tcode\tname\ttype\tlang\tjudge\tterm\ttitle')
        for r in rows:
            print('\t'.join(str(x) for x in r))
        print('# %d건 — judge H 는 지금 규칙이 여전히 「맞다」고 보는 것(규칙을 고칠 자리)' % len(rows))
    elif '--restore' in a:
        ids = [int(x) for x in a[a.index('--restore') + 1].split(',')]
        restore(conn, ids)
    else:
        print(status(conn))
    conn.close()
