# -*- coding: utf-8 -*-
"""db_thayer_import.py — Thayer 헬라어 사전 심층 층 적재 (영구).

2026-09-03 (189차) — 헬라어 [사전] 3층. A-S(1922)가 간결한 표준 사전이라면
Thayer(1889)는 **항목당 3~5배 깊은 심층 사전**이다. TDNT·NIDNTTE 는 저작권이
유효해 원천 불가(0.txt 1번 판정) — 합법적으로 확보 가능한 가장 깊은 헬라어
사전이 이것이다.

원자료 (2026-09-03 수령·검증 — 규칙 ③ 파일이 스스로 밝힘):
  · github.com/EveryPromiseBible/Every-Promise-Thayers `book/*.md` 27파일
    5.4MB(G1~G5624 연속). NOTICE 가 **PUBLIC DOMAIN** 명기 + 마크업까지
    CC0 1.0 헌정. 「a faithful digital reproduction of that public-domain text」.
  · 형식 = 마크다운. 항목마다
        ### 표제어 — 음역
        `Strong's G266`
        본문…
        ---
    라 **스트롱 번호가 항목에 내장**(A-S 의 n= 열쇠와 같은 이점).

저장 (원본 재유도가 멱등의 정본 — §174차):
  sys_thayer_entry(strong PK · grk · translit · body)
  ⚠ 다리 표가 없다 — 스트롱이 곧 PK 라 필요 없다(BDB 는 색인, A-S 는 n=,
    Thayer 는 PK. 원자료 형편에 맞춘다).

사용:
  python db_thayer_import.py --selftest   (의무)
  python db_thayer_import.py --load      (멱등 — 전체 재유도)
  python db_thayer_import.py --status
"""
import glob
import io
import os
import re
import sys

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

RAW = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   '_lexicon_raw', 'thayer')

DDL = ("CREATE TABLE IF NOT EXISTS sys_thayer_entry("
       "strong TEXT PRIMARY KEY, grk TEXT, translit TEXT, body TEXT)")

_RX_HEAD = re.compile(r'^###\s+(.+?)\s*$', re.M)
_RX_STRONG = re.compile(r"^`Strong's\s+(G\d+)`\s*$", re.M)


def parse_dir(path=None):
    """→ [(strong, grk, translit, body)] — 파일 차례·항목 차례 보존."""
    out, seen = [], set()
    files = sorted(glob.glob(os.path.join(path or RAW, '*.md')))
    if not files:
        raise SystemExit('원자료가 없다: %s' % (path or RAW))
    for fp in files:
        txt = open(fp, encoding='utf-8').read()
        # 항목 = ### 머리 ~ 다음 ### 머리(또는 파일 끝)
        heads = list(_RX_HEAD.finditer(txt))
        for i, m in enumerate(heads):
            head = m.group(1).strip()
            end = heads[i + 1].start() if i + 1 < len(heads) else len(txt)
            chunk = txt[m.end():end]
            sm = _RX_STRONG.search(chunk)
            if not sm:
                continue                    # 목차·머리말 등 — 항목이 아니다
            strong = sm.group(1)
            body = chunk[sm.end():]
            # 항목 사이 구분선과 꼬리 항해 줄을 걷는다
            body = re.sub(r'^\s*---\s*$', '', body, flags=re.M)
            body = re.sub(r'^\[←[^\n]*\n?', '', body, flags=re.M)
            body = re.sub(r'\n{3,}', '\n\n', body).strip()
            if len(body) < 10:
                continue
            grk, _, tr = head.partition('—')
            if strong in seen:
                continue                    # 같은 번호 재등장 — 첫 항목 유지
            seen.add(strong)
            out.append((strong, grk.strip(), tr.strip(), body))
    return out


def load(conn, entries=None):
    if entries is None:
        entries = parse_dir()
    conn.execute(DDL)
    conn.execute('DELETE FROM sys_thayer_entry')
    conn.executemany('INSERT OR REPLACE INTO sys_thayer_entry VALUES(?,?,?,?)',
                     entries)
    conn.commit()
    print('Thayer 항목 %d' % len(entries))


def status(conn):
    try:
        n = conn.execute('SELECT COUNT(*) FROM sys_thayer_entry').fetchone()[0]
        j = conn.execute(
            "SELECT COUNT(*) FROM sys_thayer_entry t"
            " JOIN sys_lemma_master lm ON lm.strong=t.strong").fetchone()[0]
        sz = conn.execute('SELECT SUM(LENGTH(body)) FROM sys_thayer_entry'
                          ).fetchone()[0] or 0
        print('항목 %d · 마스터와 겹치는 스트롱 %d · 본문 %.1fMB'
              % (n, j, sz / 1e6))
    except Exception as e:
        print('미적재 (%s)' % e)


def selftest():
    import sqlite3
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    entries = parse_dir()
    t('항목 5,000~6,000', 5000 <= len(entries) <= 6000, len(entries))
    by = {e[0]: e for e in entries}
    t('스트롱 PK 유일', len(by) == len(entries))
    ham = by.get('G266')
    t('하마르티아 실재', bool(ham), (ham[1] if ham else ''))
    t('하마르티아 본문 2,000자+', bool(ham and len(ham[3]) > 2000),
      (len(ham[3]) if ham else 0))
    t('음역 칸', bool(ham and ham[2]))
    t('머리·구분선 잔재 0',
      bool(ham and '###' not in ham[3] and "Strong's" not in ham[3]
           and '[←' not in ham[3]))
    # A-S 보다 깊은가 — 이 사전을 더하는 이유가 그것이다.
    # ⚠ 문턱은 **실측으로** 정한다(982 — 짐작 1,500 은 틀렸다). 깊이의
    #   증거는 개수가 아니라 대표 항목의 두께다(하마르티아 5,007자).
    deep = sum(1 for e in entries if len(e[3]) > 1000)
    t('1,000자 넘는 항목 800+', deep >= 800, deep)
    conn = sqlite3.connect(':memory:')
    load(conn, entries[:50])
    c0 = conn.execute('SELECT COUNT(*) FROM sys_thayer_entry').fetchone()[0]
    load(conn, entries[:50])
    c1 = conn.execute('SELECT COUNT(*) FROM sys_thayer_entry').fetchone()[0]
    t('멱등', c0 == c1 == 50)
    conn.close()
    print('db_thayer_import selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect('bible_master.db')
    try:
        if '--load' in sys.argv:
            load(conn)
        else:
            status(conn)
    finally:
        conn.close()
