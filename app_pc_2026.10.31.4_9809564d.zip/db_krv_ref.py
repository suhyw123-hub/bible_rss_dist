# -*- coding: utf-8 -*-
"""개역한글 대조 자료 — 성서공회판 본문·소제목 (영구 도구, §0-5 KEEP)

**왜 있나.** 페리코프 제목을 세션마다 다시 고치고 있었다(창세기 11 · 마태 39 · 누가 88 ·
출애굽기 95). 원인은 한국어 쪽에 정답이 없어서였다 — 제목의 원본은 BSB 영어 헤딩이고
KO 는 그것을 개역한글 낱말로 옮긴 것인데, 그 「개역한글 낱말」을 기억으로 댔다(peri.md §4-0).
이 도구가 그 정답 사전을 준다.

**출처** 대한성서공회 온라인 성경 `version=HAN`(개역한글). 소제목이 `<font class="smallTitle">`
하나로 구분되고 상호참조는 앵커에 박혀 있다. 66권 코드는 각 권 1장의 절 수를 bible_index 와
대조해 전수 검증했다(--validate).

⚠ **로컬 전용. 배포하지 않는다.** `_krv_raw/`(gitignore)에 두고 `bible_master.db` 에 넣지 않는다.
   §18-7 TVTMS · §18-10 WLC 와 같은 취급이다. 본문은 이미 DB 에 있고, 필요한 것은 대조뿐이다.

**2026-08-09 전권 대조 결과** — 31,081절 중 그대로 일치 27,735(89.2%).
   불일치 3,346 은 거의 전부 **정서법**이다(우리 DB=현대 표기 / 성서공회=1961년 원표기):
   할지로다/할찌로다 1,949 · 숫양/수양 278 · 할진대/할찐대 140 · 파수꾼/파숫군 121 ·
   셋째·넷째/세째·네째 86 · 육·여·연/륙·예·년 109. 여기에 각주 표시와 시편 표제 표기.
   **맞춤법·각주·표제를 정규화하면 남는 차이는 561절(1.8%)** — 본문 자체는 98.2% 같다.
   그 561 안에서 **고유명사 한 글자 오류 23절을 찾아 복구했다**(웹→웻 11 · 브사렐→브살렐 8 ·
   훔빔→훕빔 3 · 훔바→훕바 1). 「웹」은 성경 이름에 쓰이지 않는 음절이라 임포트 오류가 확실했다.

**소제목 2,422개 / 1,095장.** BSB 페리코프 3,061개와 견주면 시작점이 겹치는 것이 **2,041(66.7%)**.
   ⇒ **제목을 갈아 끼우는 용도로는 못 쓴다** — 1,020개가 비고, 창 1장 일곱 페리코프가
   「천지 창조」 하나로 뭉개진다. **낱말 대조용으로만 쓴다.**

  --validate  66권 코드 검증
  --fetch     전권 수집 (멱등, 요청 간격 0.8초)
  --compare   본문 대조 보고
  --head --book N   그 책의 BSB 페리코프마다 개역한글 소제목을 나란히 (제목 작업용)
  --selftest  (의무)
"""
import os, re, sys, time, json, urllib.request, appdb

RAW = '_krv_raw'
HEAD_JSON = os.path.join(RAW, 'headings.json')
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
URL = 'https://www.bskorea.or.kr/bible/korbibReadpage.php?version=HAN&book=%s&chap=%d'
DELAY = 0.8

CODE = ('gen exo lev num deu jos jdg rut 1sa 2sa 1ki 2ki 1ch 2ch ezr neh est job psa pro '
        'ecc sng isa jer lam ezk dan hos jol amo oba jnh mic nam hab zep hag zec mal '
        'mat mrk luk jhn act rom 1co 2co gal eph php col 1th 2th 1ti 2ti tit phm heb '
        'jas 1pe 2pe 1jn 2jn 3jn jud rev').split()
assert len(CODE) == 66

TITLE_RE = re.compile(r'<font class="smallTitle">(.*?)</font>', re.S)
NUM_RE = re.compile(r'<span class="number">(\d+)')
FOOTDIV = re.compile(r"<div id='D_\d+_\d+'.*?</div>", re.S)      # 각주 뜻풀이(숨은 div)
TAIL = re.compile(r'<div style="width:100%;text-align: center">')  # 이전/다음 버튼부터가 꼬리


def chapters(conn):
    return {b: n for b, n in conn.execute(
        'SELECT bcode, MAX(chapter) FROM bible_index GROUP BY bcode')}


def path_of(code, ch):
    return os.path.join(RAW, '%s_%03d.html' % (code, ch))


def fetch(code, ch):
    p = path_of(code, ch)
    if os.path.exists(p) and os.path.getsize(p) > 2000:
        return open(p, encoding='utf-8', errors='replace').read(), False
    req = urllib.request.Request(URL % (code, ch), headers={'User-Agent': UA})
    with urllib.request.urlopen(req, timeout=40) as r:
        html = r.read().decode('utf-8', 'replace')
    os.makedirs(RAW, exist_ok=True)
    open(p, 'w', encoding='utf-8').write(html)
    return html, True


def parse(html):
    """-> (verses{n:text}, headings[(시작 절, 제목)])

    ⚠ 셋을 처리하지 않으면 조용히 틀린다 — 전부 실제로 겪었다.
      ① 각주 뜻풀이가 숨은 div 로 본문 뒤에 붙는다(「진주」·「생명」)
      ② 페이지 꼬리(검색 스크립트)가 마지막 절에 딸려 온다
      ③ 소제목이 절과 절 **사이**에 있어 절을 먼저 쪼개면 어느 절 것인지 잃는다
    """
    html = FOOTDIV.sub(' ', html)
    m = TAIL.search(html)
    if m:
        html = html[:m.start()]
    marks = []

    def _mark(mo):
        marks.append(re.sub(r'<[^>]+>', '', mo.group(1)).replace('&nbsp;', ' ').strip())
        return '\x00%d\x00' % (len(marks) - 1)

    body = TITLE_RE.sub(_mark, html)
    parts = NUM_RE.split(body)
    verses, heads, pending = {}, [], []
    for i in range(1, len(parts) - 1, 2):
        n = int(parts[i])
        seg = parts[i + 1]
        for h in re.findall(r'\x00(\d+)\x00', seg):
            pending.append(int(h))          # 이 절 뒤의 제목 -> 다음 절이 시작점
        txt = re.sub(r'\x00\d+\x00', ' ', seg)
        txt = re.sub(r'<[^>]+>', ' ', txt).replace('&nbsp;', ' ')
        verses[n] = re.sub(r'\s+', ' ', txt).strip()
        while pending:
            heads.append((n + 1, marks[pending.pop(0)]))
    for h in (re.findall(r'\x00(\d+)\x00', parts[0]) if parts else []):
        heads.insert(0, (1, marks[int(h)]))
    return verses, heads


def db_krv(conn):
    d = {}
    for b, c, v, t in conn.execute(
            "SELECT bi.bcode,bi.chapter,bi.verse,bc.verse_text FROM bible_content bc "
            "JOIN bible_index bi ON bi.verse_id=bc.verse_id WHERE bc.version_code='KRV'"):
        d.setdefault((b, c), {})[v] = t
    return d


def validate(conn):
    kr = db_krv(conn)
    bad = []
    for i, code in enumerate(CODE, start=1):
        html, got = fetch(code, 1)
        if got:
            time.sleep(DELAY)
        vs, _ = parse(html)
        if not (vs and abs(len(vs) - len(kr.get((i, 1), {}))) <= 1):
            bad.append((i, code, len(vs), len(kr.get((i, 1), {}))))
    print('코드 검증 — 불일치 %d건 %s' % (len(bad), bad or ''))
    return not bad


def fetch_all(conn):
    ch = chapters(conn)
    tot = sum(ch.values())
    done = new = 0
    for i, code in enumerate(CODE, start=1):
        for c in range(1, ch[i] + 1):
            _, got = fetch(code, c)
            done += 1
            if got:
                new += 1
                time.sleep(DELAY)
            if done % 100 == 0:
                print('  %d/%d (신규 %d)' % (done, tot, new), flush=True)
    print('수집 %d장 (신규 %d)' % (done, new))
    build_heads(conn)


def build_heads(conn):
    ch = chapters(conn)
    out = {}
    for i, code in enumerate(CODE, start=1):
        for c in range(1, ch[i] + 1):
            p = path_of(code, c)
            if not os.path.exists(p):
                continue
            _, hd = parse(open(p, encoding='utf-8', errors='replace').read())
            if hd:
                out['%d:%d' % (i, c)] = hd
    json.dump(out, open(HEAD_JSON, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    n = sum(len(v) for v in out.values())
    print('소제목 %d개 / %d장 -> %s' % (n, len(out), HEAD_JSON))
    return out


NORM = re.compile(r'[\s ]+')
FOOT = re.compile(r'[0-9ㄱ-ㅎ]\)')


def norm(s):
    return NORM.sub('', FOOT.sub('', s or ''))


def compare(conn):
    ch = chapters(conn)
    kr = db_krv(conn)
    same = diff = 0
    for i, code in enumerate(CODE, start=1):
        for c in range(1, ch[i] + 1):
            p = path_of(code, c)
            if not os.path.exists(p):
                continue
            vs, _ = parse(open(p, encoding='utf-8', errors='replace').read())
            for v, t in kr.get((i, c), {}).items():
                w = vs.get(v)
                if w is None:
                    continue
                if norm(w) == norm(t):
                    same += 1
                else:
                    diff += 1
    print('본문 대조 — 일치 %d · 불일치 %d (%.1f%%)' % (same, diff, 100 * diff / max(1, same + diff)))
    print('※ 불일치 대부분은 정서법이다. 독스트링의 2026-08-09 실측을 볼 것.')


def heads_map():
    if not os.path.exists(HEAD_JSON):
        print('!! %s 가 없다 — --fetch 를 먼저 돌릴 것' % HEAD_JSON)
        return {}
    return json.load(open(HEAD_JSON, encoding='utf-8'))


def head_table(conn, bcode):
    """그 책의 BSB 페리코프마다 개역한글 소제목을 나란히 — 제목 작업의 정답 사전."""
    hm = heads_map()
    idx = {}
    for k, v in hm.items():
        b, c = map(int, k.split(':'))
        for a, t in v:
            idx[(b, c, a)] = t
    rows = conn.execute("""
        SELECT p.pericope_id, bi.chapter, bi.verse, bj.chapter, bj.verse,
               (SELECT title FROM sys_text_asset WHERE clicked_id=p.pericope_id
                  AND text_type='PERI_TITLE' AND lang_code='EN'),
               (SELECT title FROM sys_text_asset WHERE clicked_id=p.pericope_id
                  AND text_type='PERI_TITLE' AND lang_code='KO')
          FROM sys_pericope_asset p
          JOIN bible_index bi ON bi.verse_id=p.start_vid
          JOIN bible_index bj ON bj.verse_id=p.end_vid
         WHERE p.peri_type='BODY' AND COALESCE(p.record_status,'LIVE')='LIVE' AND bi.bcode=?
         ORDER BY p.start_vid""", (bcode,)).fetchall()
    hit = 0
    for pid, c1, v1, c2, v2, en, ko in rows:
        krv = idx.get((bcode, c1, v1), '')
        if krv:
            hit += 1
        print('%d  %d:%d-%d:%d\n    EN  %s\n    KO  %s\n    개역 %s' %
              (pid, c1, v1, c2, v2, en, ko, krv or '— (그 자리에 소제목 없음)'))
    print('\n페리코프 %d개 중 개역한글 소제목이 그 자리에 있는 것 %d (%.0f%%)'
          % (len(rows), hit, 100 * hit / max(1, len(rows))))


def selftest():
    """탐지력 확인 — 파서가 무엇을 놓치면 조용히 틀리는지 되짚는다."""
    ok = True
    sample = ('<span class="number">1&nbsp;</span>가나<font class="name">브살렐</font>다 '
              "<div id='D_1_1' class=D2>각주뜻풀이</div>"
              '<br /><font class="smallTitle">첫 제목</font><br />'
              '<span class="number">2&nbsp;</span>라마바'
              '<div style="width:100%;text-align: center">꼬리</div>')
    vs, hd = parse(sample)
    for label, got, want in (
            ('절 수', len(vs), 2),
            ('1절 본문', vs.get(1, '').replace(' ', ''), '가나브살렐다'),
            ('각주 뜻풀이 제거', '각주뜻풀이' not in ''.join(vs.values()), True),
            ('꼬리 제거', '꼬리' not in ''.join(vs.values()), True),
            ('소제목 개수', len(hd), 1),
            ('소제목 시작 절', hd[0][0] if hd else None, 2),
            ('소제목 본문', hd[0][1] if hd else None, '첫 제목')):
        good = got == want
        ok &= good
        print('  [%s] %-16s %r' % ('PASS' if good else 'FAIL', label, got))
    # 소제목이 절 앞에 오는 경우
    vs2, hd2 = parse('<font class="smallTitle">머리</font><span class="number">1&nbsp;</span>가')
    good = hd2 == [(1, '머리')]
    ok &= good
    print('  [%s] %-16s %r' % ('PASS' if good else 'FAIL', '절 앞 소제목', hd2))
    print('selftest', 'PASS' if ok else 'FAIL')
    return ok


if __name__ == '__main__':
    a = sys.argv
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect()
    if '--validate' in a:
        sys.exit(0 if validate(conn) else 1)
    if '--fetch' in a:
        fetch_all(conn)
    if '--heads' in a:
        build_heads(conn)
    if '--compare' in a:
        compare(conn)
    if '--head' in a:
        head_table(conn, int(a[a.index('--book') + 1]))
