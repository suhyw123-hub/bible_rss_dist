# -*- coding: utf-8 -*-
"""히브리어 신약(델리치) 적재 — §0-1b 규칙 다섯을 **코드가 지킨다**.

사용자 「히브리어 버전은 **메시아닉 공동체가 실제로 읽는 public domain
성경**을 다운로드 받도록 하라. 여러개 받아도 좋다. **테아밈은 유지**하라.」

★★★ **왜 신약인가** — 우리 `WLC` 는 `OT_ONLY` 라 **히브리어 신약이 한 절도
  없다**. 구약은 마소라 본문이 곧 히브리어 성경이고 우리 WLC 가 테아밈까지
  갖고 있어 더 받을 것이 없다(사용자 지시대로 **손대지 않는다**).

★ **델리치(Franz Delitzsch)** — 1877 초판 · 1892 제11판. 메시아닉 회중이
  실제로 읽는 표준 히브리어 신약이고 본문은 **퍼블릭 도메인**이다.

⚠⚠ **알레포 사본(bolls `HAC`)은 담지 않는다** — 받아 보니 **모음도 악센트도
  없는 자음 본문**이다(`בראשית ברא אלהים`). 사용자 지시가 「테아밈 유지」인데
  그것은 테아밈은커녕 니쿠드도 없다. **우리 WLC 가 더 낫다.**

순서 — `--links` → `--fetch --links-confirmed` → `--check` → `--apply`.
`--selftest`(의무) · `--undo`.
"""
import argparse
import io
import json
import os
import re
import ssl
import sys
import time
import urllib.request

import appdb

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, '_hebrew_raw')          # gitignore — 받은 원본
VER = 'DHNT'
VER_NAME = 'Delitzsch Hebrew New Testament (1877/1892)'

#: 본문을 받는 곳 · 대조하는 곳 — **받기 전에 보인다**(§0-1b 규칙 ⓪)
LINKS = [
    ('PRIMARY', 'bolls.life — Delitzsch Hebrew NT (모음 포함)',
     'https://bolls.life/get-chapter/DHNT/{book}/{chapter}/'),
    ('CROSS', 'Internet Archive — Delitzsch 1892 제11판 스캔 OCR',
     'https://archive.org/download/dielitz-nt/Dielitz-NT_djvu.txt'),
    ('PRIMARY', 'hangl.net — Salkinson-Ginsburg Hebrew NT (1886, 모음 포함)',
     'https://hangl.net/hbm/hebrew/hebhnt/index.php/{book}/{chapter}/'),
    ('CROSS', 'Internet Archive — Salkinson-Ginsburg 1886 스캔 OCR',
     'https://archive.org/download/salkinsonginsbur0000unse/'
     'salkinsonginsbur0000unse_djvu.txt'),
    ('REJECTED', 'bolls.life — Aleppo Codex (HAC) · **모음·악센트 없음**',
     'https://bolls.life/get-chapter/HAC/{book}/{chapter}/'),
]

_ACK = '--links-confirmed'
UA = {'User-Agent': 'Mozilla/5.0 (HagahBible/1.0)'}



def _ctx():
    """⚠ archive.org 인증서 사슬이 이 파이썬에서 안 풀린다(실측
    `Basic Constraints of CA cert not marked critical`). **받는 것은 공개
    퍼블릭 도메인 텍스트**이고 두 곳 대조로 내용을 따로 검증하므로, 이
    도구에 한해 확인을 끈다. ⚠ 다른 도구에 베끼지 말 것."""
    c = ssl.create_default_context()
    c.check_hostname = False
    c.verify_mode = ssl.CERT_NONE
    return c


def show_links(note=''):
    print('── 받을 곳 · 대조할 곳 (%s) ' % VER + '─' * 30)
    for role, name, url in LINKS:
        print('  [%-8s] %s' % (role, name))
        print('             %s' % url)
    print('  ⚠ 델리치 본문은 퍼블릭 도메인이다(1877·1892). bolls 판이 '
          '「1877, 1998」이라 적으므로')
    print('    **1892 제11판 스캔과 두 곳 대조를 통과한 것만** 담는다'
          '(절의 앞·가운데·뒤 조각 셋 중 %.1f개 이상).' % MIN_CHUNKS)
    if note:
        print('  ' + note)
    print('─' * 60)


def require_ack(argv=None):
    """확인을 받지 않았으면 **한 바이트도 안 받는다**(§0-1b 규칙 ⓪)."""
    argv = sys.argv[1:] if argv is None else argv
    if _ACK in argv:
        return True
    show_links()
    raise SystemExit(
        '[%s] 링크 확인 전이다 — 내려받지 않는다.\n'
        '        (사용자 지침 2026-08-22: 받기 전에 반드시 링크를 보인다)' % VER)


# ══════════════════════════════════════════════════════════════════
#  글자 다루기
# ══════════════════════════════════════════════════════════════════

NIQQUD = re.compile(r'[֑-ׇ]')          # 니쿠드 + 테아밈
NOT_HEB = re.compile(r'[^א-ת]')        # 히브리 자음이 아닌 것


def cons(s):
    """**자음만** 남긴다 — OCR 대조용.

    ⚠ 니쿠드·테아밈은 스캔에서 가장 잘 깨지는 자리라 대조 잣대로 쓰면
      멀쩡한 본문이 「다르다」로 나온다. **자음은 뼈대라 잘 안 깨진다.**
    ⚠ 본문 자체는 **안 건드린다** — 대조할 때만 접는다(테아밈 유지 지시).
    """
    return NOT_HEB.sub('', NIQQUD.sub('', s or ''))


def has_vowels(s):
    return bool(NIQQUD.search(s or ''))


# ══════════════════════════════════════════════════════════════════
#  받기
# ══════════════════════════════════════════════════════════════════

def _get(url, timeout=60):
    req = urllib.request.Request(url, headers=UA)
    return urllib.request.urlopen(req, timeout=timeout, context=_ctx()).read()


def nt_books(conn):
    """신약 책 → `[(bcode, 장 수)]`. **우리 좌표가 기준이다.**"""
    return [(r[0], r[1]) for r in conn.execute(
        "SELECT bcode, MAX(chapter) FROM bible_index WHERE bcode>=40 "
        "GROUP BY bcode ORDER BY bcode")]


def fetch(conn, argv=None, sleep=0.25):
    """본문과 대조본을 받아 `_hebrew_raw/` 에 둔다."""
    require_ack(argv)
    os.makedirs(RAW, exist_ok=True)
    books = nt_books(conn)
    got, miss = 0, []
    out = {}
    for bcode, nch in books:
        for ch in range(1, nch + 1):
            key = '%d_%d' % (bcode, ch)
            try:
                raw = _get(LINKS[0][2].format(book=bcode, chapter=ch))
                rows = json.loads(raw.decode('utf-8'))
                out[key] = {str(r['verse']): r['text'] for r in rows
                            if r.get('text')}
                got += len(out[key])
            except Exception as e:                        # noqa: BLE001
                miss.append('%s(%s)' % (key, str(e)[:30]))
            time.sleep(sleep)
        print('  %2d권 … 받은 절 %s' % (bcode, '{:,}'.format(got)))
    io.open(os.path.join(RAW, 'dhnt.json'), 'w', encoding='utf-8').write(
        json.dumps(out, ensure_ascii=False))
    print('본문 %s절 · 못 받은 장 %d' % ('{:,}'.format(got), len(miss)))
    if miss:
        print('  ' + ' / '.join(miss[:6]))

    # 대조본
    try:
        t = _get(LINKS[1][2], timeout=120).decode('utf-8', 'ignore')
        io.open(os.path.join(RAW, 'cross.txt'), 'w', encoding='utf-8').write(t)
        print('대조본 %s자 (히브리 %.0f%%)'
              % ('{:,}'.format(len(t)),
                 100.0 * len(re.findall(r'[֐-׿]', t)) / max(1, len(t))))
    except Exception as e:                                # noqa: BLE001
        print('⚠ 대조본을 못 받았다: %s' % str(e)[:70])
    return {'verses': got, 'miss': len(miss)}


#: 우리 bcode → hangl.net 책 코드 (실측으로 받은 27권)
SG_BOOKS = {
    40: 'Mt', 41: 'Mr', 42: 'Lu', 43: 'Joh', 44: 'Ac', 45: 'Ro',
    46: '1Co', 47: '2Co', 48: 'Ga', 49: 'Eph', 50: 'Php', 51: 'Col',
    52: '1Th', 53: '2Th', 54: '1Ti', 55: '2Ti', 56: 'Tit', 57: 'Phm',
    58: 'Heb', 59: 'Jas', 60: '1Pe', 61: '2Pe', 62: '1Jo', 63: '2Jo',
    64: '3Jo', 65: 'Jude', 66: 'Re',
}

#: 담는 역본 둘 — **한 표가 단일 소스**다(도구를 두 벌로 쓰지 않는다)
VERSIONS = {
    'DHNT': {
        'name': 'Delitzsch Hebrew New Testament (1877/1892)',
        'file': 'dhnt.json',
        'cross': 'cross.txt',
        'note': '델리치 히브리어 신약 — 퍼블릭 도메인(1877 초판 · 1892 '
                '제11판). 1892 스캔과 두 곳 대조 통과.',
    },
    'SGHNT': {
        'name': 'Salkinson-Ginsburg Hebrew New Testament (1886)',
        'file': 'sghnt.json',
        'cross': 'cross_sg.txt',
        'note': '살킨슨-긴스버그 히브리어 신약 — 퍼블릭 도메인(1886 · '
                'Salkinson 1883 사망 · Ginsburg 1914 사망). 1886 스캔과 '
                '두 곳 대조 통과. ⚠ 행 4:14 는 원본 사이트에 결손이라 비어 있다. '
                '낱말 안 공백 16절(0.2%)은 원본의 표기 오류다.',
    },
}

SG_URL = 'https://hangl.net/hbm/hebrew/hebhnt/index.php/{book}/{chapter}/'
SG_CROSS = ('https://archive.org/download/salkinsonginsbur0000unse/'
            'salkinsonginsbur0000unse_djvu.txt')
SG_ROW = re.compile(
    r'<sup><a[^>]*>(\d+):(\d+)</a></sup>\s*(.*?)(?=<sup>|</p>|$)', re.S)


def fetch_sg(conn, argv=None, sleep=0.25):
    """살킨슨-긴스버그 — hangl.net 에서 장별로 받아 절로 가른다."""
    require_ack(argv)
    os.makedirs(RAW, exist_ok=True)
    out, got, miss = {}, 0, []
    for bcode, nch in nt_books(conn):
        code = SG_BOOKS.get(bcode)
        if not code:
            miss.append('bcode %d 코드 없음' % bcode)
            continue
        for ch in range(1, nch + 1):
            try:
                html = _get(SG_URL.format(book=code, chapter=ch)).decode(
                    'utf-8', 'ignore')
                d = {}
                for _c, v, body in SG_ROW.findall(html):
                    txt = re.sub(r'<[^>]+>', '', body)
                    txt = re.sub(r'\s+', ' ', txt).strip()
                    if txt:
                        d[v] = txt
                if d:
                    out['%d_%d' % (bcode, ch)] = d
                    got += len(d)
                else:
                    miss.append('%s %d장 비었다' % (code, ch))
            except Exception as e:                        # noqa: BLE001
                miss.append('%s %d(%s)' % (code, ch, str(e)[:24]))
            time.sleep(sleep)
        print('  %-4s … 받은 절 %s' % (code, '{:,}'.format(got)))
    io.open(os.path.join(RAW, 'sghnt.json'), 'w', encoding='utf-8').write(
        json.dumps(out, ensure_ascii=False))
    print('본문 %s절 · 못 받은 장 %d' % ('{:,}'.format(got), len(miss)))
    if miss:
        print('  ' + ' / '.join(miss[:6]))
    try:
        t = _get(SG_CROSS, timeout=120).decode('utf-8', 'ignore')
        io.open(os.path.join(RAW, 'cross_sg.txt'), 'w',
                encoding='utf-8').write(t)
        print('대조본 %s자 (히브리 %.0f%%)'
              % ('{:,}'.format(len(t)),
                 100.0 * len(re.findall(r'[\u0590-\u05FF]', t))
                 / max(1, len(t))))
    except Exception as e:                                # noqa: BLE001
        print('⚠ 대조본을 못 받았다: %s' % str(e)[:70])
    return {'verses': got, 'miss': len(miss)}



# ══════════════════════════════════════════════════════════════════
#  문지기 — 두 곳 대조 (§0-1b 규칙 ②)
# ══════════════════════════════════════════════════════════════════

#: 두 곳 대조 — **조각 셋 중 몇 개**(§0-1b 규칙 ②)
#  ⚠ 「앞 24자 연속」으로 재다 19% 가 나와 막혔다. 본문을 나란히 놓아 보니
#    델리치가 맞고 **OCR 이 깨진 것**이었다. 히브리 스캔은 ד/ר·ח/ה/ת·י/ו 를
#    헷갈려 긴 조각이 거의 반드시 깨진다.
#  ★ 탐지력을 재서 골랐다 — 델리치 **1.99** ↔ 구약 WLC 0.19 ↔ 섞은 가짜 0.24.
CHUNK = 8
MIN_CHUNKS = 1.5


def chunk_hits(text, cross_c, n=CHUNK):
    """절의 **앞·가운데·뒤** 조각이 대조본에 있는가 → 0~3 (짧으면 None).

    ⚠ 한 자리만 보면 그 자리가 깨졌을 때 멀쩡한 절을 버린다. 세 자리를 본다.
    """
    c = cons(text)
    if len(c) < n * 2:
        return None
    sp = (c[:n], c[len(c) // 2:len(c) // 2 + n], c[-n:])
    return sum(1 for s in sp if s in cross_c)


def check(conn, sample=400, ver=VER):
    """받은 본문이 **정말 델리치인가** — 1892 스캔과 대조.

    ⚠ 절 단위로 못 맞춘다(스캔에 절 번호가 온전치 않다). 그래서 **절의
      자음 조각이 대조본 어딘가에 있는가**를 표본으로 센다.
    """
    cfg = VERSIONS[ver]
    p = os.path.join(RAW, cfg['file'])
    if not os.path.exists(p):
        return {'ok': False, 'why': '받은 본문이 없다 — --fetch 먼저'}
    body = json.loads(io.open(p, encoding='utf-8').read())
    n_v = sum(len(v) for v in body.values())
    out = {'verses': n_v, 'chapters': len(body)}

    # ① 모음이 살아 있는가(사용자 지시 — 테아밈·니쿠드 유지)
    vs = [t for ch in body.values() for t in ch.values()]
    out['vowel_ratio'] = sum(1 for t in vs if has_vowels(t)) / max(1, len(vs))

    # ② 두 곳 대조
    cp = os.path.join(RAW, cfg['cross'])
    if not os.path.exists(cp):
        out['chunks'] = None
        out['ok'] = False
        out['why'] = '대조본이 없다 — 규칙 ②(두 곳)를 못 지킨다'
        return out
    cross = cons(io.open(cp, encoding='utf-8').read())
    import random
    random.seed(7)
    keys = [(k, v) for k in sorted(body) for v in body[k]]
    random.shuffle(keys)
    got = []
    for k, v in keys:
        h = chunk_hits(body[k][v], cross)
        if h is not None:
            got.append(h)
        if len(got) >= sample:
            break
    out['sampled'] = len(got)
    out['chunks'] = sum(got) / max(1, len(got))
    out['ok'] = (out['chunks'] >= MIN_CHUNKS and out['vowel_ratio'] >= 0.9
                 and n_v > 7000)
    out['why'] = '' if out['ok'] else (
        '조각 %.2f/3 (문턱 %.2f) · 모음 %.0f%% · 절 %d'
        % (out['chunks'] or 0, MIN_CHUNKS, 100 * out['vowel_ratio'], n_v))
    return out

# ══════════════════════════════════════════════════════════════════
#  절체계 — 우리 영어축에 맞춘다 (§18-8)
# ══════════════════════════════════════════════════════════════════
#
# ★★★ **번호로 맞추지 않는다 — 본문을 읽어서 확정했다.** 실측 260장 가운데
#   **두 장**만 다르다. naive 적재는 그 자리에서 **조용한 오정렬**을 냈다
#   (고후 13:13 에 축도가 들어갔다 — §267차 ⑤ 「빈칸보다 나쁘다」).
#
#   ┌ 롬 7 — 델리치가 우리 25절을 **둘로 나눈다**
#   │   델리치 25 「…하나님께 감사하리로다」 + 26 「그런즉 내 마음으로는…」
#   │   = 우리 25 ⇒ **이어 붙인다**
#   └
#   ┌ 고후 13 — 델리치가 우리 12·13 을 **합치고** 축도를 13 으로 매긴다
#   │   델리치 12 「…거룩한 입맞춤으로 문안하라 거룩한 이들이(=모든 성도가)」
#   │   델리치 13 = 축도 = 우리 14
#   └
#
# 값의 꼴 — `{우리 절: [델리치 절, …]}` 이면 이어 붙이고,
#           `{우리 절: ('MERGED', '장:절')}` 이면 **병합 표식**을 넣는다.
# ⚠⚠ **역본마다 다르다** — 살킨슨은 롬 7·고후 13 이 우리와 같고 대신
#   행 4:14 가 **원본 사이트에 아예 없다**(파싱 실패가 아니라 결손 —
#   4:13 다음에 곧바로 4:15 다). **지어내지 않고 비워 둔다**(§0-1b).
VERSIFY_BY_VER = {
    'DHNT': {
        (45, 7): {25: [25, 26]},
        (47, 13): {13: ('MERGED', '13:12'), 14: [13]},
    },
    'SGHNT': {},
}


def versify(ver):
    return VERSIFY_BY_VER.get(ver, {})

#: 합쳐진 자리에 남기는 표식 — `verse_text.classify` 가 알아본다(§267차 ①)
MERGE_MARK = '<병합 %s> %s'


# ══════════════════════════════════════════════════════════════════
#  적재
# ══════════════════════════════════════════════════════════════════

def apply(conn, force=False, ver=VER):
    """`bible_version` 등록 + `bible_content` 적재. **멱등**."""
    cfg = VERSIONS[ver]
    d = check(conn, ver=ver)
    if not d.get('ok') and not force:
        raise SystemExit('문지기가 막았다: %s' % d.get('why'))
    body = json.loads(io.open(os.path.join(RAW, cfg['file']),
                              encoding='utf-8').read())
    conn.execute(
        "INSERT OR REPLACE INTO bible_version(version_code, version_name,"
        " lang_code, versification_system, coverage_scope, display_name,"
        " copyright_type, license_note, source_url) "
        "VALUES(?,?,?,?,?,?,?,?,?)",
        (ver, cfg['name'], 'HE', 'MT', 'NT_ONLY', cfg['name'],
         'PUBLIC_DOMAIN', cfg['note'], LINKS[0][2]))
    n, miss, fixed = 0, [], 0
    for key, verses in body.items():
        bcode, ch = (int(x) for x in key.split('_'))
        rule = versify(ver).get((bcode, ch))
        # ── 절체계가 다른 장은 **표대로** 담는다 ────────────────────
        if rule:
            done = set()
            for ours, how in rule.items():
                r = conn.execute(
                    "SELECT verse_id FROM bible_index WHERE bcode=? "
                    "AND chapter=? AND verse=?", (bcode, ch, ours)).fetchone()
                if not r:
                    miss.append('%d:%d 자리가 없다' % (ch, ours))
                    continue
                if isinstance(how, tuple) and how[0] == 'MERGED':
                    # ★ 합쳐진 자리 — **표식 + 그 절 본문**(지어내지 않는다)
                    src = how[1].split(':')[1]
                    txt = MERGE_MARK % (how[1], verses.get(src, ''))
                    # ⚠⚠ **원본 절은 건너뛰지 않는다** — `done` 에 넣었더니
                    #   고후 13:12 가 통째로 비었다(실측으로 당했다).
                    #   병합 표식은 **딸린 절**에 넣는 것이지 원본을 대신하지
                    #   않는다.
                else:
                    parts = [verses.get(str(x), '') for x in how]
                    txt = ' '.join(p for p in parts if p)
                    done |= {str(x) for x in how}
                conn.execute(
                    "INSERT OR REPLACE INTO bible_content(verse_id,"
                    " version_code, verse_text) VALUES(?,?,?)",
                    (r[0], ver, txt))
                n += 1
                fixed += 1
            # 규칙에 안 걸린 나머지 절은 그대로
            for v, txt in verses.items():
                if v in done:
                    continue
                r = conn.execute(
                    "SELECT verse_id FROM bible_index WHERE bcode=? "
                    "AND chapter=? AND verse=?", (bcode, ch, int(v))).fetchone()
                if not r:
                    miss.append('%d:%s 자리가 없다' % (ch, v))
                    continue
                conn.execute(
                    "INSERT OR REPLACE INTO bible_content(verse_id,"
                    " version_code, verse_text) VALUES(?,?,?)",
                    (r[0], ver, txt))
                n += 1
            continue
        for v, txt in verses.items():
            r = conn.execute(
                "SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? "
                "AND verse=?", (bcode, ch, int(v))).fetchone()
            if not r:
                # ⚠⚠ **버린 절을 조용히 넘기지 않는다** — 자국을 안 남기면
                #   아무 검사도 못 잡는다(§267차 ⑤-2).
                miss.append('%d:%s(bcode %d) 자리가 없다' % (ch, v, bcode))
                continue
            conn.execute(
                "INSERT OR REPLACE INTO bible_content(verse_id, version_code,"
                " verse_text) VALUES(?,?,?)", (r[0], ver, txt))
            n += 1
    conn.commit()
    return {'loaded': n, 'no_slot': miss, 'versified': fixed, 'check': d}


def undo(conn, ver=VER):
    n = conn.execute("DELETE FROM bible_content WHERE version_code=?",
                     (ver,)).rowcount
    conn.execute("DELETE FROM bible_version WHERE version_code=?", (ver,))
    conn.commit()
    return n


# ══════════════════════════════════════════════════════════════════
#  자가 검증 (의무)
# ══════════════════════════════════════════════════════════════════

def selftest():
    bad, nck = [], [0]

    def ck(c, m):
        nck[0] += 1
        if not c:
            bad.append(m)

    # ① 링크 확인 문 — 양방향
    try:
        require_ack([])
        ck(False, '확인 없이도 받으려 한다')
    except SystemExit:
        ck(True, '')
    ck(require_ack([_ACK]) is True, '확인했는데도 막는다')

    # ② 자음 접기
    s = 'סֵפֶר תּוֹלְדֹת יֵשׁוּעַ'
    ck(cons(s) == 'ספרתולדתישוע', '자음 접기가 틀리다: %s' % cons(s))
    ck(has_vowels(s), '모음을 못 알아본다')
    ck(not has_vowels('ספר תולדת'), '모음 없는 글을 있다고 한다')
    # ⚠ 테아밈도 접힌다 — 대조용이지 저장용이 아니다
    ck(cons('בְּרֵאשִׁ֖ית') == 'בראשית', '테아밈이 안 접힌다')

    # ③ 알레포는 **안 담는다**는 것이 목록에 적혀 있다
    roles = {r for r, _n, _u in LINKS}
    ck('REJECTED' in roles, '버린 후보를 안 적었다')
    ck(any('HAC' in u for _r, _n, u in LINKS if _r == 'REJECTED'),
       '알레포를 버린 자리에 안 적었다')

    # ④ 문지기 — 재료가 없으면 **막는다**
    conn = appdb.connect()
    try:
        d = check(conn)
        ck(d.get('ok') in (True, False), '문지기가 값을 안 낸다')
        if not os.path.exists(os.path.join(RAW, 'dhnt.json')):
            ck(d['ok'] is False, '받은 것이 없는데 통과시킨다')
        # ⑤ 우리 좌표가 신약을 안다
        nb = nt_books(conn)
        ck(len(nb) == 27, '신약이 27권이 아니다: %d' % len(nb))
        ck(nb[0][0] == 40, '첫 신약 책이 40(마태)이 아니다')
    finally:
        conn.close()

    # ⑤-2 절체계 표 — **실재하는 자리**를 가리키는가
    _c3 = appdb.connect()
    for _v, _rules in VERSIFY_BY_VER.items():
      for (bc, ch), rule in _rules.items():
        for ours in rule:
            ck(_c3.execute(
                "SELECT COUNT(*) FROM bible_index WHERE bcode=? AND chapter=? "
                "AND verse=?", (bc, ch, ours)).fetchone()[0] == 1,
               '절체계 표가 없는 자리를 가리킨다: %s %d %d:%d'
               % (_v, bc, ch, ours))
    # ★ 담고 나면 **빈 슬롯이 없어야** 한다(이미 담았을 때만 잰다)
    _n = _c3.execute(
        "SELECT COUNT(*) FROM bible_content WHERE version_code=?",
        (VER,)).fetchone()[0]
    if _n:
        _hole = _c3.execute(
            "SELECT COUNT(*) FROM bible_index i WHERE i.bcode>=40 AND NOT "
            "EXISTS(SELECT 1 FROM bible_content b WHERE b.verse_id=i.verse_id "
            "AND b.version_code=?)", (VER,)).fetchone()[0]
        # ⚠ **살킨슨은 행 4:14 가 원본에 없다** — 1절까지는 견딘다.
        ck(_hole <= 1, '신약에 빈 슬롯이 %d절 남았다' % _hole)
    _c3.close()

    # ⑥ ★★★ **탐지력** — 잣대가 가짜를 잡는가(느슨하게 한 것이 아니다)
    cp = os.path.join(RAW, 'cross.txt')
    if os.path.exists(cp):
        _cr = cons(io.open(cp, encoding='utf-8').read())
        _p = os.path.join(RAW, 'dhnt.json')
        if os.path.exists(_p):
            _b = json.loads(io.open(_p, encoding='utf-8').read())
            _ks = [(k, v) for k in sorted(_b) for v in _b[k]][:200]
            _pos = [chunk_hits(_b[k][v], _cr) for k, v in _ks]
            _pos = [x for x in _pos if x is not None]
            ck(sum(_pos) / max(1, len(_pos)) >= MIN_CHUNKS,
               '진짜 델리치를 걸러 낸다: %.2f' % (sum(_pos) / max(1, len(_pos))))
        # ⚠ **음성 대조군** — 구약을 신약 대조본에 대면 걸려야 한다
        _c2 = appdb.connect()
        _ot = [r[0] for r in _c2.execute(
            "SELECT verse_text FROM bible_content WHERE version_code='WLC' "
            "LIMIT 200")]
        _c2.close()
        _neg = [chunk_hits(t, _cr) for t in _ot]
        _neg = [x for x in _neg if x is not None]
        if _neg:
            _m = sum(_neg) / len(_neg)
            ck(_m < MIN_CHUNKS,
               '구약을 신약 대조본에 대도 통과시킨다: %.2f' % _m)
    else:
        ck(True, '')          # 아직 안 받았으면 건너뛴다

    for b in bad:
        print('  FAIL ' + b)
    print('db_hebrew_import selftest: %s (%d/%d)'
          % ('OK' if not bad else 'FAIL', nck[0] - len(bad), nck[0]))
    return 0 if not bad else 1


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--links', action='store_true')
    ap.add_argument('--fetch', action='store_true')
    ap.add_argument(_ACK, dest='ack', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--force', action='store_true')
    ap.add_argument('--undo', action='store_true')
    # ★ 역본을 고른다 — 안 주면 델리치(지금까지와 같다)
    ap.add_argument('--ver', default=VER, choices=sorted(VERSIONS))
    ap.add_argument('--sg', action='store_true', help='살킨슨-긴스버그 받기')
    a = ap.parse_args(argv)
    if a.selftest:
        return selftest()
    if a.links:
        show_links()
        return 0
    conn = appdb.connect()
    try:
        if a.fetch:
            print(fetch_sg(conn, argv=sys.argv[1:]) if a.sg
                  else fetch(conn, argv=sys.argv[1:]))
        if a.check:
            d = check(conn, ver=a.ver)
            print('절 %s · 장 %s · 모음 %.0f%% · 대조 %s · %s'
                  % ('{:,}'.format(d.get('verses', 0)), d.get('chapters'),
                     100 * d.get('vowel_ratio', 0),
                     ('%.2f/3' % d['chunks']) if d.get('chunks') is not None
                     else '못 쟀다',
                     '✅ 통과' if d.get('ok') else '⛔ ' + d.get('why', '')))
        if a.apply:
            print(apply(conn, force=a.force, ver=a.ver))
        if a.undo:
            print('지운 절 %d' % undo(conn, ver=a.ver))
    finally:
        conn.close()
    return 0


if __name__ == '__main__':
    sys.exit(main())
