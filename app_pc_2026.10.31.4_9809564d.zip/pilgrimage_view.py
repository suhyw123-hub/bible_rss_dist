"""
pilgrimage_view.py — P4 탭7 '성지순례' 지도 뷰
----------------------------------------------
좌측 사이드바(장소 / 테마 모드) + 우측 위성 지도(웹 메르카토르, 핀·경로선).

- 배경: Esri World Imagery 위성 타일(전 배율, 온라인). 오프라인이면 Natural Earth(PD)
  윤곽 + "인터넷 필요" 안내로 폴백. 위성 위에 국경선(PD)만 노란 선으로 오버레이.
- 투영: 웹 메르카토르(_wx/_wy) — 타일과 핀이 동일 좌표계로 정확히 정렬.
- 줌/이동은 성지 bbox 로 제한(빈 공간·세계지도 수준 축소 금지).
- 장소 모드: 지역 칩 필터 + 장소 목록 → 클릭하면 지도가 그 장소로 이동·선택.
- 테마 모드: 테마 → 경로(학설) 목록. 경로를 켜면 정류장이 순서대로 번호+선으로 표시.
  여러 학설을 동시에 켜서 색깔별 비교 가능(경로1/경로n). 정류장 클릭 → 지도 이동.
- 핀/정류장 더블클릭 → on_place_jump(eid) (Entity Info 이동).
- 라이선스: 'ⓘ 출처'(Esri 출처표시 + Natural Earth PD).
"""
import os
import i18n
import json
import math
import sqlite3
import appdb
import threading
import ui_theme
import theme_font
import scripture_ref_kr
import urllib.request
import tkinter as tk
from tkinter import ttk


def _C(role, fb):
    """역할색 (§36). ⚠ **지도 자체(위성·바다·경로선·핀)는 콘텐츠라 제외한다** —
    위성 사진 위 대비를 위해 고른 색이라 테마가 번역하면 안 읽힌다.
    여기서 다루는 것은 **단추·라벨·목록 같은 화면 껍데기**뿐이다
    (2026-08-20 사용자 「믿음의 발자취 내부의 버튼·라벨이 표준서식을 안 따른다」)."""
    try:
        return ui_theme.C(role) or fb
    except Exception:
        return fb


def _MAPF(size, *style):
    """지도 위 글자 — **패밀리만** 통합 폰트에서 가져온다 (2026-08-21).

    ★ 색(흰 글자 + 검은 후광)과 크기는 **일부러 테마·설정 밖에 둔다** —
      위성 사진 위에서 읽히려고 고른 값이고, 본문 글꼴을 키운 사람의 지도가
      글자로 덮이면 안 된다(사용자: 「휠로 확대·축소가 되니 작아도 괜찮다」).
    ⚠ 그런데 **글꼴 이름을 적어 두면** 그 글꼴이 없는 PC 에서 지도 글자만
      기본 글꼴로 떨어진다 — `resolve_family` 가 설치 확인·현지화명을 처리한다."""
    try:
        fam = theme_font.resolve_family('Malgun Gothic') or ''
    except Exception:
        fam = ''
    return (fam, size) + tuple(style)


def _reg(w, db, scope='ui'):
    """글꼴을 통합 폰트에 맡긴다 — 글꼴 이름을 화면이 적지 않는다(§36).
    ⚠ `db_path` 를 빠뜨리면 theme_font 가 경고만 찍고 기본값으로 떨어진다."""
    try:
        theme_font.register(w, db, scope)
    except Exception:
        pass
    return w

try:
    from PIL import Image, ImageTk
    _PIL_OK = True
except Exception:
    _PIL_OK = False

_CONF_LABEL = {'TRADITIONAL': '전통설', 'MAJORITY': '다수설', 'MINORITY': '소수설',
               'LATER_TRADITION': '전승'}
# 본문 근거 희박(후대 전승) — 점선·가는 선으로 성경 경로와 구분해 렌더
_TRADITION_CONF = ('LATER_TRADITION',)
# '이전 세대 회색 overlay'는 진짜 계승(부자·왕위·영적 계승) 그룹에서만. 동료 그룹(사도 등)은 제외.
_SUCCESSION_GROUPS = {'PATRIARCHS', 'WILDERNESS_CONQUEST', 'KINGS', 'PROPHETS'}
_ROUTE_COLORS = ['#C0392B', '#2471A3', '#1E8449', '#8E44AD', '#B9770E']
# 지도 데이터 영역(Natural Earth 클립 bbox) — 이 밖의 빈 공간은 보여주지 않음
_BBOX = (11.0, 18.0, 50.0, 42.5)   # lng0, lat0, lng1, lat1 (신약 바울 여정 위해 서쪽 로마까지 확장)
# 위성 타일(Esri World Imagery, 무료·출처표시). 전 배율 온라인 로드(오프라인 시 윤곽 폴백).
_TILE_URL = ('https://server.arcgisonline.com/ArcGIS/rest/services/'
             'World_Imagery/MapServer/tile/{z}/{y}/{x}')
_SAT_CREDIT = 'Esri, Maxar, Earthstar Geographics'
_STORY_W = [400]   # 스토리 슬라이드 폭 직전값(세션 공유, mutable)
# 통제된 지역 대분류(지도 표시·필터용). KO/EN/sort. 신약권 확장 시 행 추가.
# (엔티티 json_detail.region_code 와 동일 코드)
_REGIONS = {
    'EGYPT': ('애굽', 'Egypt', 10), 'SINAI': ('시내·광야', 'Sinai', 20),
    'JUDEA': ('유대', 'Judea', 30), 'TRANSJORDAN': ('요단 동편', 'Transjordan', 35),
    'SAMARIA': ('사마리아', 'Samaria', 40), 'GALILEE': ('갈릴리', 'Galilee', 45),
    'SYRIA': ('시리아·아람', 'Syria', 60), 'MESOPOTAMIA': ('메소포타미아', 'Mesopotamia', 70),
    'CYPRUS': ('구브로', 'Cyprus', 80), 'ASIA_MINOR': ('소아시아', 'Asia Minor', 82),
    'GREECE': ('그리스·마게도냐', 'Greece', 85), 'ITALY': ('이탈리아·지중해', 'Italy', 88),
}
# 장소 모드 상단바 지역 그룹(대권역) — 세부 region_code 묶음. (key, KO, EN, {region_codes})
_REGION_GROUPS = [
    ('EGYPT_WILD', '애굽·광야', 'Egypt & Wilderness', {'EGYPT', 'SINAI'}),
    ('CANAAN', '이스라엘', 'Israel', {'JUDEA', 'SAMARIA', 'GALILEE', 'TRANSJORDAN'}),
    # 동방(족장 기원·다메섹·안디옥) / 서방(바울 선교권) 2분 — 외곽 권역 통합(2026-06-08)
    ('SYRIA_MESO', '시리아·메소포타미아', 'Syria & Mesopotamia', {'SYRIA', 'MESOPOTAMIA'}),
    ('NT_MISSION', '소아시아·그리스·로마', 'Asia Minor, Greece & Rome',
     {'CYPRUS', 'ASIA_MINOR', 'GREECE', 'ITALY'}),
]
# 그룹별 선호 뷰(핵심지 중심) — 아웃라이어(우르 남부설·바벨론·인도방향 등)로 전체 bbox
# fit 시 시야가 쏠리는 그룹은 명시 bounds로 재배치. (lng0, lat0, lng1, lat1) — 중점이 화면 중심.
_REGION_GROUP_VIEW = {
    # 비옥한 초승달 전체(우르 남부설→하란→다메섹)를 담아 우르가 하단에 보이도록.
    # 하란(39.03,36.86)은 상단부, 우르 남부설(30.96,46.1)은 하단. 애굽은 박스 밖(서/남).
    'SYRIA_MESO': (35.5, 30.5, 46.8, 38.6),
}


def journey_exists(db_path, entity_id, entity_type):
    """엔티티 탭 '여정' 서브탭 표시 여부 판단(가벼운 쿼리, PilgrimageView 불필요).
    PLACE=거쳐간 인물 경로 있음 / PERSON=그 인물 테마의 경로 있음."""
    try:
        conn = appdb.connect(db_path)
    except Exception:
        return False
    try:
        if entity_type == 'PLACE':
            r = conn.execute(
                "SELECT 1 FROM sys_place_route_stop s JOIN sys_place_route r ON r.route_id=s.route_id "
                "WHERE s.entity_id=? AND s.record_status='LIVE' AND r.record_status='LIVE' "
                "AND COALESCE(s.is_waypoint,0)=0 LIMIT 1",
                (entity_id,)).fetchone()
            return bool(r)
        if entity_type == 'PERSON':
            cols = [x[1] for x in conn.execute("PRAGMA table_info(sys_place_route_theme)")]
            if 'entity_id' not in cols:
                return False
            r = conn.execute(
                "SELECT 1 FROM sys_place_route_theme t JOIN sys_place_route r ON r.theme_id=t.theme_id "
                "WHERE t.entity_id=? AND t.record_status='LIVE' AND r.record_status='LIVE' LIMIT 1",
                (entity_id,)).fetchone()
            return bool(r)
        return False
    except Exception:
        return False
    finally:
        conn.close()


class PilgrimageView(ttk.Frame):
    def __init__(self, parent, db_path, lang_getter=None,
                 on_place_jump=None, open_license=None,
                 state_get=None, state_set=None, on_verse_jump=None, embed=False):
        super().__init__(parent)
        self.db_path = db_path
        self._embed = bool(embed)   # 엔티티 탭 '여정' 임베드(모드버튼·장소목록 없이 지도+발자취선택)
        self.on_verse_jump = on_verse_jump   # verse_id → P1 본문 + P2 주석 + 묵상
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.on_place_jump = on_place_jump
        self.open_license = open_license
        self._state_get = state_get   # _load_state(key, default)
        self._state_set = state_set   # _save_state(key, val)
        self._places = []          # [(eid, name, lat, lng)]
        self._place_xy = {}        # eid -> (lat,lng,name)
        self._region_of = {}       # eid -> region_code
        self._cur_region = None    # 지역 필터(None=전체)
        self._active_routes = {}   # route_id -> {'color','stops':[(seq,eid,ref)]}
        self._sel_eid = None
        self._mode = 'place'
        self._ne = self._load_ne()   # Natural Earth(PD) 해안선·국경·강·바다
        self._tile_mem = {}          # (z,x,y) -> PIL.Image (메모리 캐시)
        self._sat_fetching = set()   # 받는 중인 타일 키
        self._sat_failed = False     # 마지막 fetch 전부 실패(오프라인 추정)
        self._sat_tk = None          # 현재 위성 합성 이미지(참조 유지)
        self._on_sat = False         # 현재 위성 표시중 여부(라벨 색)
        self._cx, self._cy, self._scale = 35.0, 31.5, 40.0
        self._drag = None
        if self._state_get:        # 스토리 슬라이드 폭 직전값 복원
            try:
                _STORY_W[0] = int(self._state_get('pilgrimage_story_w', _STORY_W[0]) or _STORY_W[0])
            except Exception:
                pass
        if self._embed:
            self._build_embed()
            self.after_idle(self._load_places)   # 데이터만 — 뷰는 focus_*가 설정
        else:
            self._build()
            self.after_idle(self._load_and_fit)

    def _load_ne(self):
        p = os.path.join(os.path.dirname(__file__), 'data', 'ne_bible_lands.json')
        try:
            with open(p, encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return None

    # ── 위성 타일(Esri, 포커스 전용 · 온라인) ─────────────────────────────────
    def _tile_dir(self):
        d = os.path.join(os.path.dirname(__file__), 'data', 'tiles')
        return d

    def _tile_path(self, z, x, y):
        return os.path.join(self._tile_dir(), str(z), str(x), f'{y}.jpg')

    def _get_tile(self, z, x, y):
        """메모리→디스크 캐시. 없으면 None(호출자가 비동기 fetch 트리거)."""
        key = (z, x, y)
        if key in self._tile_mem:
            return self._tile_mem[key]
        p = self._tile_path(z, x, y)
        if os.path.exists(p):
            try:
                im = Image.open(p).convert('RGB')
                self._tile_mem[key] = im
                return im
            except Exception:
                try: os.remove(p)
                except Exception: pass
        return None

    def _fetch_tiles_async(self, keys):
        """없는 타일을 백그라운드로 받아오고, 끝나면 redraw 예약."""
        todo = [k for k in keys if k not in self._tile_mem and k not in self._sat_fetching]
        if not todo:
            return
        for k in todo:
            self._sat_fetching.add(k)

        def worker():
            got = 0
            for (z, x, y) in todo:
                url = _TILE_URL.format(z=z, x=x, y=y)
                try:
                    req = urllib.request.Request(url, headers={'User-Agent': 'BibleMatrix/1.0'})
                    with urllib.request.urlopen(req, timeout=8) as r:
                        data = r.read()
                    p = self._tile_path(z, x, y)
                    os.makedirs(os.path.dirname(p), exist_ok=True)
                    with open(p, 'wb') as f:
                        f.write(data)
                    got += 1
                except Exception:
                    pass
                finally:
                    self._sat_fetching.discard((z, x, y))
            # 한 묶음 전부 실패 = 오프라인/차단 추정 → 안내 폴백
            self._sat_failed = (got == 0)
            try:
                self.after(0, self._redraw)
            except Exception:
                pass

        threading.Thread(target=worker, daemon=True).start()

    def _sat_zoom(self):
        # self._scale(px/world) → 웹 메르카토르 정수 줌. 타일 native=256*2^z px/world.
        z = int(round(math.log2(max(1.0, self._scale / 256.0))))
        return min(19, max(2, z))

    def _coarse_tile(self, z, x, y):
        """정확한 타일이 없을 때, 이미 캐시된 상위 줌(부모) 타일의 해당 영역을
        확대해 임시 대체(흐릿하지만 즉시 표시). 없으면 None."""
        for k in range(1, min(z, 7)):
            pz = z - k
            px = x >> k; py = y >> k
            anc = self._get_tile(pz, px, py)
            if anc is None:
                continue
            s = 256 >> k                       # 부모 안에서 이 타일이 차지하는 픽셀 크기
            if s < 1:
                continue
            ox = (x - (px << k)) * s
            oy = (y - (py << k)) * s
            try:
                return anc.crop((ox, oy, ox + s, oy + s)).resize((256, 256))
            except Exception:
                return None
        return None

    def _build_sat(self, w, h):
        """현재 뷰의 위성 배경 PhotoImage.
        정확한 타일이 없으면 (1) 거친 상위-줌 타일로 즉시 대체 + (2) 비동기 fetch
        (보이는 영역 + 가장자리 1줄 prefetch). 아무 타일도 없을 때만 None(폴백 안내)."""
        if not _PIL_OK:
            return None
        z = self._sat_zoom()
        world_px = 256 * (2 ** z)
        n = 2 ** z
        ratio = self._scale / world_px            # 버퍼(타일 px) → 캔버스 px 비율(≈1)
        if ratio <= 0:
            return None
        cwx = self._wx(self._cx); cwy = self._wy(self._cy)   # 정규화 [0,1]
        left = (cwx - (w / 2) / self._scale) * world_px      # 타일 px
        top = (cwy - (h / 2) / self._scale) * world_px
        bw = w / ratio; bh = h / ratio
        tx0 = math.floor(left / 256); tx1 = math.floor((left + bw) / 256)
        ty0 = math.floor(top / 256); ty1 = math.floor((top + bh) / 256)
        # fetch 대상: 보이는 영역 + 가장자리 1줄(prefetch) 의 미수신 타일
        fetch = [(z, tx % n, ty) for tx in range(tx0 - 1, tx1 + 2)
                 for ty in range(ty0 - 1, ty1 + 2)
                 if 0 <= ty < n and self._get_tile(z, tx % n, ty) is None]
        if fetch:
            self._fetch_tiles_async(fetch)
        try:
            buf = Image.new('RGB', (max(1, math.ceil(bw)), max(1, math.ceil(bh))), (30, 30, 30))
            any_drawn = False
            for tx in range(tx0, tx1 + 1):
                for ty in range(ty0, ty1 + 1):
                    if not (0 <= ty < n):
                        continue
                    im = self._get_tile(z, tx % n, ty) or self._coarse_tile(z, tx % n, ty)
                    if im is None:
                        continue
                    buf.paste(im, (int(tx * 256 - left), int(ty * 256 - top)))
                    any_drawn = True
            if not any_drawn:
                return None     # 정확·거친 타일 모두 없음 → 로딩/오프라인 폴백
            img = buf.resize((w, h))
            self._sat_tk = ImageTk.PhotoImage(img)
            return self._sat_tk
        except Exception:
            return None

    # ── UI ──────────────────────────────────────────────────────────────────
    def _build(self):
        bar = tk.Frame(self, bg=_C('accent_bg', '#EAF2F8'))
        ui_theme.bar_height(bar)        # P4 서브탭 공통 높이(32px)
        bar.pack(fill='x')
        # 모드 토글(상단 바 좌측): 장소 기준 / 인물 기준
        self._mode_btns = {}
        for i, (val, txt) in enumerate([('theme', i18n.t('PV_MODE_THEME','인물 기준')), ('place', i18n.t('PV_MODE_PLACE','장소 기준'))]):
            b = tk.Button(bar, text=txt, bd=1,
                          relief='solid', cursor='hand2',
                          command=lambda v=val: self._set_mode(v))
            _reg(b, self.db_path)
            b.pack(side='left', padx=(10 if i == 0 else 3), pady=2)
            self._mode_btns[val] = b
        # 장소 모드 지역 대권역 버튼 행(모드 전환 시 채움/비움) — §31-3 Phase 2
        self._region_bar = tk.Frame(bar, bg=_C('accent_bg', '#EAF2F8'))
        self._region_bar.pack(side='left', padx=(10, 2))
        self._region_btns = {}
        # M407 — 두 모드(인물 기준/장소 기준) · **실선과 점선의 뜻**(성경 근거 /
        #   전승). ⚠ `_region_bar` 안에 두면 모드가 바뀔 때 함께 지워진다
        #   (그 프레임은 자식을 통째로 destroy 한다) — 바깥 `bar` 에 붙인다.
        try:
            from manual_widget import attach_manual_icon
            attach_manual_icon(bar, 'U_P4_PILGRIM',
                               lang_provider=self._lang,
                               db_path=self.db_path).pack(side='right', padx=(4, 6))
        except Exception as e:
            print('[manual pilgrim] %s' % e)
        _reg(tk.Button(bar, text=i18n.t('UM_LICENSE','ⓘ 출처·라이선스'), bd=0,
                       bg=_C('accent_bg', '#EAF2F8'), fg=_C('accent', '#1A5276'), cursor='hand2',
                       command=lambda: self.open_license and self.open_license()),
             self.db_path).pack(side='right', padx=8)
        _reg(tk.Button(bar, text=i18n.t('PV_RESET','⟳ 기준'), bd=0,
                       bg=_C('accent_bg', '#D6EAF8'), fg=_C('fg', '#2C3E50'),
                       cursor='hand2', command=self._fit),
             self.db_path).pack(side='right', padx=2)
        # ⚠ 확대·축소 단추는 **pady 0** — 기본값이면 35px 이라 32px bar 에서 잘린다(실측).
        for txt, f in (('＋', 1.25), ('－', 0.8)):
            _reg(tk.Button(bar, text=txt, width=2, bd=1, cursor='hand2',
                           command=lambda k=f: self._zoom_at(k)),
                 self.db_path).pack(side='right', pady=2)
        self._zoom_var = tk.StringVar(value='')
        _reg(tk.Label(bar, textvariable=self._zoom_var,
                      bg=_C('accent_bg', '#EAF2F8'), fg=_C('fg_dim', '#555')),
             self.db_path).pack(side='right', padx=6)
        # ★ **고른 장소를 주요용어 탭에서 보기** (2026-08-21 사용자 지시 —
        #   「지명을 고른 뒤 정보를 얻으려면 주요용어로 넘어가면 된다. 별도로
        #   입력하지 않고 넘어갈 수 있게」). 핀 **더블클릭**으로 가는 길이
        #   원래 있었지만 아무도 모른다 — 단추로 드러낸다.
        #   ⚠ 라벨에 **장소 이름을 담는다** — 무엇이 열릴지 안 보이면 안 누른다.
        self._ent_btn = tk.Button(bar, text=i18n.t('PV_ENTITY_GO', '⇒ 주요용어'),
                                  bd=1, relief='raised', cursor='hand2',
                                  state='disabled', command=self._jump_entity)
        _reg(self._ent_btn, self.db_path)
        self._ent_btn.pack(side='right', padx=(2, 8), pady=2)

        pw = tk.PanedWindow(self, orient='horizontal', sashwidth=5, bg=_C('border', '#BFD3E6'))
        pw.pack(fill='both', expand=True)

        # 좌측 사이드바 (모드별 내용 — 모드 토글은 상단 바)
        side = tk.Frame(pw, bg=_C('panel', 'white'))
        pw.add(side, minsize=150, width=210, stretch='never')
        self._side_body = tk.Frame(side, bg=_C('panel', 'white'))
        self._side_body.pack(fill='both', expand=True)

        # 우측 지도 (육지=진한 양피 탄색, 바다는 _redraw 에서 연한 색 채움)
        right = tk.Frame(pw, bg='#0E2A38')
        pw.add(right, minsize=320, stretch='always')
        self._map_pw = pw; self._map_anchor = right   # 스토리 슬라이드 anchor
        pw.bind('<ButtonRelease-1>', lambda e: self._save_story_w()
                if getattr(self, '_story_visible', False) else None)
        self._canvas = tk.Canvas(right, bg='#0E2A38', highlightthickness=0)
        self._canvas.pack(fill='both', expand=True)
        self._canvas.bind('<ButtonPress-1>', self._on_press)
        self._canvas.bind('<B1-Motion>', self._on_drag)
        self._canvas.bind('<ButtonRelease-1>', self._on_release)
        self._canvas.bind('<Double-Button-1>', self._on_double)
        self._canvas.bind('<MouseWheel>', self._on_wheel)
        self._canvas.bind('<Configure>', lambda e: self._redraw())
        self._status = tk.Label(self, text=i18n.t('PV_HELP','드래그=이동 · 휠=확대/축소 · 더블클릭=상세'),
                                bg=_C('panel_alt', '#F4F6F7'), fg=_C('fg_dim', '#555'), anchor='w')
        _reg(self._status, self.db_path)
        self._status.pack(fill='x')
        self._update_mode_btns()
        self._build_place_panel()
        self._build_region_bar()

    # ── 임베드 모드(엔티티 탭 '여정') ─────────────────────────────────────────
    def _build_embed(self):
        bar = tk.Frame(self, bg=_C('accent_bg', '#EAF2F8')); bar.pack(fill='x')
        # 거쳐간 인물 선택(장소 포커스): 동적 버튼 행 / 인물 포커스: 이름 라벨
        self._embed_sel = tk.Frame(bar, bg=_C('accent_bg', '#EAF2F8'))
        self._embed_sel.pack(side='left', fill='x', expand=True, padx=4, pady=2)
        self._embed_pers_btns = {}
        if self.open_license:
            _reg(tk.Button(bar, text='ⓘ', bd=0, bg=_C('accent_bg', '#EAF2F8'),
                           fg=_C('accent', '#1A5276'), cursor='hand2',
                           command=lambda: self.open_license and self.open_license()),
                 self.db_path).pack(side='right', padx=4)
        for txt, f in (('＋', 1.25), ('－', 0.8)):
            _reg(tk.Button(bar, text=txt, width=2, bd=1, cursor='hand2',
                           command=lambda k=f: self._zoom_at(k)),
                 self.db_path).pack(side='right', pady=2)
        self._zoom_var = tk.StringVar(value='')
        # 정류장 텍스트 버튼 행(클릭 → 스토리 슬라이드). 가로 스크롤(많을 때).
        stopbar = tk.Frame(self, bg=_C('panel_alt', '#F4EFE0')); stopbar.pack(fill='x')
        self._embed_stops = tk.Frame(stopbar, bg=_C('panel_alt', '#F4EFE0'))
        self._embed_stops.pack(fill='x', padx=4, pady=2)
        self._embed_stop_btns = []
        self._embed_stops_w = 0
        self._embed_stops.bind('<Configure>', self._on_stopbar_configure)
        # 지도 + 스토리 슬라이드용 PanedWindow(가계도 §25.8 패턴)
        pw = tk.PanedWindow(self, orient='horizontal', sashwidth=4, bg='#23404F')
        pw.pack(fill='both', expand=True)
        canvas_frm = tk.Frame(pw, bg='#0E2A38')
        pw.add(canvas_frm, minsize=300, stretch='always')
        self._canvas = tk.Canvas(canvas_frm, bg='#0E2A38', highlightthickness=0)
        self._canvas.pack(fill='both', expand=True)
        self._canvas.bind('<ButtonPress-1>', self._on_press)
        self._canvas.bind('<B1-Motion>', self._on_drag)
        self._canvas.bind('<ButtonRelease-1>', self._on_release)
        self._canvas.bind('<Double-Button-1>', self._on_double)
        self._canvas.bind('<MouseWheel>', self._on_wheel)
        self._canvas.bind('<Configure>', lambda e: self._redraw())
        self._map_pw = pw; self._map_anchor = canvas_frm   # 스토리 슬라이드 anchor
        pw.bind('<ButtonRelease-1>', lambda e: self._save_story_w()
                if getattr(self, '_story_visible', False) else None)
        # 임베드는 사이드 패널·모드버튼 없음. _redraw 등은 그대로 동작.

    def _activate_route(self, rid):
        self._active_routes = {rid: self._build_route_info(rid)}

    def focus_person(self, entity_id):
        """인물 엔티티 → 그 인물 테마의 기본 경로를 지도에 표시(임베드용)."""
        if not self._places:
            self._load_places()
        for w in self._embed_sel.winfo_children():
            w.destroy()
        conn = appdb.connect(self.db_path)
        try:
            r = conn.execute(
                "SELECT r.route_id, COALESCE(tn.contents, en.contents, t.theme_code) "
                "FROM sys_place_route_theme t JOIN sys_place_route r ON r.theme_id=t.theme_id "
                "LEFT JOIN sys_text_asset tn ON tn.clicked_id=t.theme_id "
                "  AND tn.text_type='ROUTE_THEME_NAME' AND tn.lang_code=? "
                "LEFT JOIN sys_text_asset en ON en.clicked_id=t.theme_id "
                "  AND en.text_type='ROUTE_THEME_NAME' AND en.lang_code='EN' "
                "WHERE t.entity_id=? AND t.record_status='LIVE' AND r.record_status='LIVE' "
                "ORDER BY r.is_default DESC, r.sort_order LIMIT 1", (self._lang(), entity_id)).fetchone()
        finally:
            conn.close()
        if not r:
            self._active_routes = {}; self._fill_embed_stops(None, ''); self._redraw(); return
        _reg(tk.Label(self._embed_sel, text=f'{r[1]}의 여정',
                      bg=_C('accent_bg', '#EAF2F8'), fg=_C('accent', '#1A5276')),
             self.db_path).pack(side='left')
        self._activate_route(r[0])
        self._fill_embed_stops(r[0], r[1])
        self._fit_to_routes(); self._redraw()

    def focus_place(self, entity_id):
        """장소 엔티티 → 거쳐간 인물 선택 버튼 + 첫 인물 경로 표시(임베드용)."""
        if not self._places:
            self._load_places()
        for w in self._embed_sel.winfo_children():
            w.destroy()
        fps = self._footprints_for(entity_id)
        if not fps:
            self._active_routes = {}
            _reg(tk.Label(self._embed_sel, text=i18n.t('PV_NOPERSON','(거쳐간 인물 경로 없음)'),
                          bg=_C('accent_bg', '#EAF2F8'), fg=_C('fg_dim', '#888')),
                 self.db_path).pack(side='left')
            self._redraw(); return
        self._sel_eid = entity_id
        _reg(tk.Label(self._embed_sel, text=i18n.t('PV_PASSEDPERSON','거쳐간 인물:'),
                      bg=_C('accent_bg', '#EAF2F8'), fg=_C('accent', '#5B2C6F')),
             self.db_path).pack(side='left', padx=(0, 4))
        self._embed_pers_btns = {}
        for d in fps:
            b = tk.Button(self._embed_sel, text=f"{d['name']}",
                          bd=1, relief='solid', bg=_C('panel_alt', '#C8CDD3'),
                          fg=_C('fg', '#000000'), cursor='hand2',
                          command=lambda x=d: self._embed_pick_person(x))
            _reg(b, self.db_path)
            b.pack(side='left', padx=1)
            self._embed_pers_btns[d['rid']] = b
        self._embed_pick_person(fps[0])

    def _embed_pick_person(self, d):
        for rid, b in getattr(self, '_embed_pers_btns', {}).items():
            on = (rid == d['rid'])
            b.configure(bg=_C('dark_bg', '#2C4259') if on else _C('panel_alt', '#C8CDD3'),
                        fg=_C('fg_on_dark', 'white') if on else _C('fg', '#000000'))
        self._activate_route(d['rid'])
        self._fill_embed_stops(d['rid'], d['name'])
        self._fit_to_routes(); self._redraw()

    def _fill_embed_stops(self, route_id, person):
        """여정 탭 정류장 텍스트 버튼 행 — 클릭 시 스토리 슬라이드. 많으면 줄바꿈."""
        if not hasattr(self, '_embed_stops'):
            return
        for w in self._embed_stops.winfo_children():
            w.destroy()
        self._embed_stop_btns = []
        if not route_id:
            return
        conn = appdb.connect(self.db_path)
        try:
            rows = conn.execute(
                "SELECT s.seq, s.stop_id, s.scripture_ref, "
                "  COALESCE(t.contents, en.contents, e.entity_code) "
                "FROM sys_place_route_stop s JOIN sys_entity_master e ON e.entity_id=s.entity_id "
                "LEFT JOIN sys_text_asset t ON t.clicked_id=s.entity_id "
                "  AND t.text_type='ENTITY_NAME' AND t.lang_code=? "
                "LEFT JOIN sys_text_asset en ON en.clicked_id=s.entity_id "
                "  AND en.text_type='ENTITY_NAME' AND en.lang_code='EN' "
                "WHERE s.route_id=? AND s.record_status='LIVE' ORDER BY s.seq",
                (self._lang(), route_id)).fetchall()
        except Exception:
            rows = []
        finally:
            conn.close()
        for seq, stop_id, ref, nm in rows:
            b = tk.Button(self._embed_stops, text=f'{seq}.{nm}',
                          bd=1, relief='solid', bg=_C('panel', '#FCFAF2'),
                          fg=_C('fg', '#5B4A2A'), cursor='hand2',
                          command=lambda sid=stop_id, rf=ref: self._open_story(sid, rf, person))
            _reg(b, self.db_path)
            self._embed_stop_btns.append(b)
        self._embed_stops_w = 0   # 강제 재배치
        self.after_idle(self._reflow_embed_stops)

    def _on_stopbar_configure(self, e):
        if abs(e.width - getattr(self, '_embed_stops_w', 0)) > 8:
            self._embed_stops_w = e.width
            self._reflow_embed_stops()

    def _reflow_embed_stops(self):
        btns = getattr(self, '_embed_stop_btns', [])
        if not btns:
            return
        avail = self._embed_stops.winfo_width() or 800
        if avail <= 1:
            avail = 800
        col = row = x = 0
        for b in btns:
            bw = b.winfo_reqwidth() + 3
            if x + bw > avail and col > 0:
                row += 1; col = 0; x = 0
            b.grid(row=row, column=col, padx=1, pady=1, sticky='w')
            col += 1; x += bw

    def _footprints_for(self, eid):
        """장소를 지나간 인물 목록 [{name,ref,rid,stop_id}] (중복 제거)."""
        conn = appdb.connect(self.db_path)
        try:
            rows = conn.execute(
                "SELECT t.theme_id, COALESCE(tn.contents, en.contents, t.theme_code), "
                "  s.scripture_ref, r.route_id, r.is_default, t.sort_order, s.stop_id "
                "FROM sys_place_route_stop s "
                "JOIN sys_place_route r ON r.route_id=s.route_id "
                "JOIN sys_place_route_theme t ON t.theme_id=r.theme_id "
                "LEFT JOIN sys_text_asset tn ON tn.clicked_id=t.theme_id "
                "  AND tn.text_type='ROUTE_THEME_NAME' AND tn.lang_code=? "
                "LEFT JOIN sys_text_asset en ON en.clicked_id=t.theme_id "
                "  AND en.text_type='ROUTE_THEME_NAME' AND en.lang_code='EN' "
                "WHERE s.entity_id=? AND s.record_status='LIVE' AND r.record_status='LIVE' "
                "AND COALESCE(s.is_waypoint,0)=0 "
                "ORDER BY t.sort_order, s.seq", (self._lang(), eid)).fetchall()
        except Exception:
            rows = []
        finally:
            conn.close()
        seen = {}
        for tid, tname, ref, rid, isdef, _so, stop_id in rows:
            if tid not in seen or isdef:
                seen[tid] = {'name': tname, 'ref': ref, 'rid': rid, 'stop_id': stop_id}
        return list(seen.values())

    def _clear_side(self):
        for w in self._side_body.winfo_children():
            w.destroy()

    def _build_place_panel(self):
        self._clear_side()
        if not hasattr(self, '_cur_region'):
            self._cur_region = None
        # 지역 필터는 상단바 대권역 버튼(_build_region_bar)으로 이동 — §31-3 Phase 2
        # 상하 분할: 장소 목록 ↕ 이곳의 발자취
        vp = tk.PanedWindow(self._side_body, orient='vertical', sashwidth=5,
                            bg=_C('border', '#C9B998'), sashrelief='raised')
        vp.pack(fill='both', expand=True)
        top = tk.Frame(vp, bg=_C('panel', 'white')); vp.add(top, minsize=80, stretch='always')
        _reg(tk.Label(top, text=i18n.t('PV_PLACELIST','장소 목록'),
                      bg=_C('warning_bg', '#FDEBC8'), fg=_C('warning', '#7A4F00')),
             self.db_path).pack(fill='x')
        f = tk.Frame(top, bg=_C('panel', 'white')); f.pack(fill='both', expand=True)
        self._place_lb = tk.Listbox(f, activestyle='none',
                                    bg=_C('panel', 'white'), fg=_C('fg', '#2C3E50'))
        _reg(self._place_lb, self.db_path, 'list')
        sb = ttk.Scrollbar(f, command=self._place_lb.yview)
        self._place_lb.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y'); self._place_lb.pack(side='left', fill='both', expand=True)
        self._place_lb.bind('<<ListboxSelect>>', self._on_place_lb)
        # 하단: 이곳의 발자취 (선택 장소를 지나간 인물 여정)
        bot = tk.Frame(vp, bg=_C('panel', 'white')); vp.add(bot, minsize=60, height=150, stretch='never')
        self._fp_label_var = tk.StringVar(value=i18n.t('PV_FOOTPRINTS','이곳의 발자취'))
        _reg(tk.Label(bot, textvariable=self._fp_label_var,
                      bg=_C('accent_bg', '#E8DCF0'), fg=_C('accent', '#5B2C6F')),
             self.db_path).pack(fill='x')
        ff = tk.Frame(bot, bg=_C('panel', 'white')); ff.pack(fill='both', expand=True)
        self._fp_lb = tk.Listbox(ff, activestyle='none',
                                 bg=_C('panel', 'white'), fg=_C('fg', '#2C3E50'))
        _reg(self._fp_lb, self.db_path, 'list')
        fsb = ttk.Scrollbar(ff, command=self._fp_lb.yview)
        self._fp_lb.configure(yscrollcommand=fsb.set)
        fsb.pack(side='right', fill='y'); self._fp_lb.pack(side='left', fill='both', expand=True)
        self._fp_lb.bind('<<ListboxSelect>>', self._on_footprint_click)
        self._fp_data = []
        self._fill_place_lb()

    def _region_codes_for(self, key):
        """대권역 그룹 key → 세부 region_code 집합. None=전체(필터 없음)."""
        if key is None:
            return None
        for k, _ko, _en, codes in _REGION_GROUPS:
            if k == key:
                return codes
        return set()

    def _build_region_bar(self):
        """장소 모드 상단바 대권역 버튼([전체] + 데이터 존재 그룹). 인물 모드면 비움."""
        if not hasattr(self, '_region_bar'):
            return
        for w in self._region_bar.winfo_children():
            w.destroy()
        self._region_btns = {}
        if self._mode != 'place':
            return
        present = {rc for rc in self._region_of.values() if rc}
        ko = (self._lang() == 'KO')
        groups = [(None, '전체')]
        for key, g_ko, g_en, codes in _REGION_GROUPS:
            if present & codes:
                groups.append((key, g_ko if ko else g_en))
        for key, label in groups:
            on = (key == self._cur_region)
            # 활성/비활성 색은 앱 표준(갈래 단추와 같은 역할쌍).
            # ⚠ 옛 값(선택=warning)은 **검정 테마에서 밝은 금색 바탕**이 되어
            #   흰 글자와 대비가 무너졌다(2026-08-20 실측 — 밝은 바탕 1건).
            b = tk.Button(self._region_bar, text=label,
                          bd=1, relief='solid', cursor='hand2',
                          bg=_C('dark_bg', '#2C4259') if on else _C('panel_alt', '#C8CDD3'),
                          fg=_C('fg_on_dark', 'white') if on else _C('fg', '#000000'),
                          command=lambda k=key: self._on_region_chip(k))
            _reg(b, self.db_path)
            b.pack(side='left', padx=1, pady=2)
            self._region_btns[key] = b

    def _visible_places(self):
        """현재 대권역 필터에 맞는 장소(전체=None 이면 전부)."""
        codes = self._region_codes_for(self._cur_region)
        if codes is None:
            return self._places
        return [p for p in self._places if self._region_of.get(p[0]) in codes]

    def _on_region_chip(self, key):
        self._cur_region = key
        # 버튼 하이라이트 갱신
        for code, btn in getattr(self, '_region_btns', {}).items():
            on = (code == key)
            btn.configure(bg=_C('dark_bg', '#2C4259') if on else _C('panel_alt', '#C8CDD3'),
                          fg=_C('fg_on_dark', 'white') if on else _C('fg', '#000000'))
        self._fill_place_lb()
        self._fit_to_region(key)

    def _fit_to_region(self, rc):
        """선택 지역 장소들이 보이도록 확대(전체=기본 뷰)."""
        if rc is None:
            self._default_view(); self._save_view(); self._redraw(); return
        ov = _REGION_GROUP_VIEW.get(rc)   # 핵심지 중심 명시 뷰(아웃라이어 무시)
        if ov:
            self._set_view_bounds(*ov)
            self._save_view(); self._redraw(); return
        pts = self._visible_places()
        if len(pts) == 0:
            self._default_view(); self._save_view(); self._redraw(); return
        lats = [p[2] for p in pts]; lngs = [p[3] for p in pts]
        pad = 0.25   # 단일/근접 장소도 너무 확대되지 않게 여유
        self._set_view_bounds(min(lngs) - pad, min(lats) - pad,
                              max(lngs) + pad, max(lats) + pad)
        self._save_view(); self._redraw()

    def _build_theme_panel(self):
        self._clear_side()
        # 단일 트리(정류장 하단 패널 흡수 — Phase 2): 경로 클릭=지도표시+정류장 펼침,
        # 정류장 자식 클릭=지도 이동+스토리 슬라이드.
        top = tk.Frame(self._side_body, bg=_C('panel', 'white')); top.pack(fill='both', expand=True)
        _reg(tk.Label(top, text=i18n.t('PV_HELP2','클릭=지도 표시(체크) · 펼치면 정류장 · 정류장 클릭=묵상'),
                      bg=_C('warning_bg', '#FDEBC8'), fg=_C('warning', '#7A4F00'),
                      wraplength=200, justify='left'),
             self.db_path).pack(fill='x')
        f = tk.Frame(top, bg=_C('panel', 'white')); f.pack(fill='both', expand=True)
        # 목록 트리는 표준 스타일 하나로 — 여기서 글꼴·행높이를 손으로 적지 않는다
        # (theme_font.list_style 이 통합 폰트를 따라 자동 갱신한다).
        st = 'Treeview'
        try:
            theme_font.list_style('Pilgrim.Treeview', self.db_path)   # 글꼴 튜플을 돌려준다
            st = 'Pilgrim.Treeview'
        except Exception:
            pass
        self._theme_tv = ttk.Treeview(f, show='tree', selectmode='browse', style=st)
        sb = ttk.Scrollbar(f, command=self._theme_tv.yview)
        self._theme_tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y'); self._theme_tv.pack(side='left', fill='both', expand=True)
        self._theme_tv.bind('<ButtonRelease-1>', self._on_theme_click)
        self._fill_theme_tv()

    def _update_mode_btns(self):
        for val, b in getattr(self, '_mode_btns', {}).items():
            on = (val == self._mode)
            b.configure(bg=_C('dark_bg', '#1A5276') if on else _C('accent_bg', '#EAF2F8'),
                        fg=_C('fg_on_dark', 'white') if on else _C('accent', '#1A5276'))

    def _set_mode(self, m):
        self._mode = m
        self._update_mode_btns()
        self._active_routes = {}   # 모드 전환 시 경로 초기화(트리 체크와 일관)
        if m == 'place':
            self._build_place_panel()
        else:
            self._build_theme_panel()
        self._build_region_bar()
        self._redraw()

    # ── 데이터 로드 ──────────────────────────────────────────────────────────
    def _lang(self):
        return (self.lang_getter() or 'KO').upper()

    def _load_places(self):
        """지도용 PLACE 데이터(_places/_place_xy/_region_of)만 로드 — 뷰/패널 무관."""
        conn = appdb.connect(self.db_path)
        rows = conn.execute(
            "SELECT em.entity_id, COALESCE(t.contents, en.contents, em.entity_code), "
            "  em.geo_lat, em.geo_lng, COALESCE(em.json_detail,'') "
            "FROM sys_entity_master em "
            "LEFT JOIN sys_text_asset t ON t.clicked_id=em.entity_id "
            "  AND t.text_type='ENTITY_NAME' AND t.lang_code=? "
            "LEFT JOIN sys_text_asset en ON en.clicked_id=em.entity_id "
            "  AND en.text_type='ENTITY_NAME' AND en.lang_code='EN' "
            "WHERE em.entity_type='PLACE' AND em.record_status='LIVE' "
            "  AND em.geo_lat IS NOT NULL AND em.geo_lng IS NOT NULL "
            "ORDER BY 2", (self._lang(),)).fetchall()
        conn.close()
        # 지도 표시 분리: map_show!=0 인 좌표 보유 PLACE 만 지도에 (엔티티 목록과 별개)
        self._places = []
        self._region_of = {}
        for r in rows:
            eid, name, lat, lng = r[0], r[1], float(r[2]), float(r[3])
            rc = None; show = 1
            try:
                d = json.loads(r[4]) if r[4].strip() else {}
                rc = d.get('region_code')
                show = 0 if d.get('map_show') == 0 else 1
            except Exception:
                pass
            if not show:
                continue
            self._places.append((eid, name, lat, lng))
            self._region_of[eid] = rc
        self._place_xy = {p[0]: (p[2], p[3], p[1]) for p in self._places}
        if not hasattr(self, '_cur_region'):
            self._cur_region = None

    def _load_and_fit(self):
        self._load_places()
        if hasattr(self, '_place_lb'):
            self._build_place_panel()
        self._build_region_bar()
        # 직전값(단순 저장)이 있으면 복원, 없으면 애굽~이스라엘이 보이는 기본 확대 뷰
        if not self._restore_view():
            self._default_view()
        self._redraw()

    # ── 뷰 상태 저장/복원(단순) + 기본 뷰 + 포커스 ──────────────────────────────
    def _default_view(self):
        # 애굽(나일)~이스라엘~다메섹이 보이는 기본 뷰
        self._set_view_bounds(29.0, 26.5, 38.0, 34.0)

    def _save_view(self):
        if self._state_set:
            try:
                self._state_set('pilgrimage_view2',
                                [round(self._cx, 4), round(self._cy, 4), round(self._scale, 2)])
            except Exception:
                pass

    def _restore_view(self):
        if not self._state_get:
            return False
        v = self._state_get('pilgrimage_view2', None)
        if isinstance(v, list) and len(v) == 3:
            try:
                self._cx, self._cy, self._scale = float(v[0]), float(v[1]), float(v[2])
                return True
            except Exception:
                return False
        return False

    def _focus_jerusalem(self):
        # 밀집 지역(예루살렘 주변: 시온·골고다·겟세마네·감람·베다니) 확대
        self._set_view_bounds(35.05, 31.62, 35.50, 31.95)
        self._save_view(); self._redraw()

    def _fill_place_lb(self):
        self._place_lb.delete(0, 'end')
        self._lb_eids = []
        for eid, name, lat, lng in self._visible_places():
            self._place_lb.insert('end', f'  {name}')
            self._lb_eids.append(eid)

    def _fill_theme_tv(self):
        # Phase 2: 인물 중간 단계 제거(인물명을 경로 라벨로) + 정류장을 경로 펼침 자식으로 흡수.
        self._theme_tv.delete(*self._theme_tv.get_children())
        self._route_meta = {}   # route_iid -> (route_id, color)
        self._stop_meta = {}    # stop_iid -> (eid, ref, stop_id, person_name)
        conn = appdb.connect(self.db_path)
        # parent_id 컬럼 유무(그룹 계층) 감지 — 없으면 단층으로 동작(하위 호환)
        has_parent = any(r[1] == 'parent_id'
                         for r in conn.execute("PRAGMA table_info(sys_place_route_theme)"))
        pcol = 'th.parent_id' if has_parent else 'NULL'
        themes = conn.execute(
            f"SELECT th.theme_id, COALESCE(tn.contents, en.contents, th.theme_code), {pcol} "
            "FROM sys_place_route_theme th "
            "LEFT JOIN sys_text_asset tn ON tn.clicked_id=th.theme_id "
            "  AND tn.text_type='ROUTE_THEME_NAME' AND tn.lang_code=? "
            "LEFT JOIN sys_text_asset en ON en.clicked_id=th.theme_id "
            "  AND en.text_type='ROUTE_THEME_NAME' AND en.lang_code='EN' "
            "WHERE th.record_status='LIVE' ORDER BY th.sort_order", (self._lang(),)).fetchall()
        by_parent = {}
        names = {}
        for tid, tname, par in themes:
            by_parent.setdefault(par, []).append(tid)
            names[tid] = tname

        def theme_routes(tid):
            return conn.execute(
                "SELECT r.route_id, COALESCE(rn.contents, en.contents, r.variant_code), "
                "  r.confidence, COALESCE(r.color,'#C0392B') "
                "FROM sys_place_route r "
                "LEFT JOIN sys_text_asset rn ON rn.clicked_id=r.route_id "
                "  AND rn.text_type='ROUTE_VARIANT_NAME' AND rn.lang_code=? "
                "LEFT JOIN sys_text_asset en ON en.clicked_id=r.route_id "
                "  AND en.text_type='ROUTE_VARIANT_NAME' AND en.lang_code='EN' "
                "WHERE r.theme_id=? AND r.record_status='LIVE' ORDER BY r.sort_order",
                (self._lang(), tid)).fetchall()

        def add_route(parent_iid, rid, label, conf, color, compete, person_name):
            # 학설 배지는 '서로 다른 confidence'(진짜 경쟁: 남부설 vs 북부설)일 때만.
            # 바울 4경로처럼 같은 confidence 순차 여정엔 배지 없음. 전승은 항상 표시.
            show = compete or conf == 'LATER_TRADITION'
            badge = _CONF_LABEL.get(conf, conf or '') if show else ''
            text = f'☐ ● {label}  [{badge}]' if badge else f'☐ ● {label}'
            ritem = self._theme_tv.insert(parent_iid, 'end', text=text, open=False)
            self._route_meta[ritem] = (rid, color)
            # 정류장 흡수(펼침 자식) — 생전 정류장은 번호, 사후 운구는 ✝
            n = 0
            for seq, eid, ref, sid, post in self._stop_rows(conn, rid):
                nm = self._place_xy.get(eid, (0, 0, str(eid)))[2]
                if post:
                    stxt = f'   ✝ {nm}  {ref}  (운구)'
                else:
                    n += 1
                    stxt = f'   {n}. {nm}  {ref}'
                sitem = self._theme_tv.insert(ritem, 'end', text=stxt)
                self._stop_meta[sitem] = (eid, ref, sid, person_name)

        for tid in by_parent.get(None, []):
            children = by_parent.get(tid, [])
            if children:    # 그룹 테마(족장들의 여정 등) → 경로 평탄화(그룹 직속, 인물 단계 제거)
                gitem = self._theme_tv.insert('', 'end', text=f'{names[tid]}', open=True)
                for ctid in children:
                    routes = theme_routes(ctid)
                    compete = len({r[2] for r in routes}) > 1
                    for rid, rname, conf, color in routes:
                        # 단일 경로=인물명만 / 다중 경로=인물명·경로명
                        label = names[ctid] if len(routes) == 1 else f'{names[ctid]} · {rname}'
                        add_route(gitem, rid, label, conf, color, compete, names[ctid])
            else:           # 단일 테마(예수·바울 등) — 단일 경로=최상위 경로 행, 다중=헤더+경로명
                routes = theme_routes(tid)
                compete = len({r[2] for r in routes}) > 1
                if len(routes) == 1:
                    rid, rname, conf, color = routes[0]
                    add_route('', rid, names[tid], conf, color, compete, names[tid])
                else:
                    titem = self._theme_tv.insert('', 'end', text=f'{names[tid]}', open=True)
                    for rid, rname, conf, color in routes:
                        add_route(titem, rid, rname, conf, color, compete, names[tid])
        conn.close()

    def _stop_rows(self, conn, route_id):
        """경로의 정류장 행 → [(seq, eid, ref, stop_id, is_posthumous)]. 경유점 제외."""
        try:
            return conn.execute(
                "SELECT s.seq, s.entity_id, COALESCE(s.scripture_ref,''), s.stop_id, "
                "  COALESCE(s.is_posthumous,0) FROM sys_place_route_stop s "
                "WHERE s.route_id=? AND s.record_status='LIVE' "
                "AND COALESCE(s.is_waypoint,0)=0 ORDER BY s.seq", (route_id,)).fetchall()
        except sqlite3.OperationalError:   # 구 DB(컬럼 없음) 폴백
            return [(*r, 0) for r in conn.execute(
                "SELECT s.seq, s.entity_id, COALESCE(s.scripture_ref,''), s.stop_id "
                "FROM sys_place_route_stop s WHERE s.route_id=? AND s.record_status='LIVE' "
                "ORDER BY s.seq", (route_id,)).fetchall()]

    def _route_stops(self, route_id):
        """실제 생전 정류장만(핀·번호·스토리 대상). 경유점·사후 운구는 제외."""
        conn = appdb.connect(self.db_path)
        try:
            rows = conn.execute(
                "SELECT s.seq, s.entity_id, COALESCE(s.scripture_ref,'') "
                "FROM sys_place_route_stop s WHERE s.route_id=? AND s.record_status='LIVE' "
                "AND COALESCE(s.is_waypoint,0)=0 AND COALESCE(s.is_posthumous,0)=0 "
                "ORDER BY s.seq", (route_id,)).fetchall()
        except sqlite3.OperationalError:   # 구 DB(컬럼 없음) 폴백
            rows = conn.execute(
                "SELECT s.seq, s.entity_id, COALESCE(s.scripture_ref,'') "
                "FROM sys_place_route_stop s WHERE s.route_id=? AND s.record_status='LIVE' "
                "ORDER BY s.seq", (route_id,)).fetchall()
        conn.close()
        return rows

    def _route_path(self, route_id):
        """경로 선용 생전 좌표(실제 정류장 + 경유점), seq 순 → [(lat,lng),...].
        경유점은 wp_lat/wp_lng, 실제 정류장은 엔티티 좌표. 사후 운구는 제외(회색 오버레이 별도)."""
        conn = appdb.connect(self.db_path)
        try:
            rows = conn.execute(
                "SELECT COALESCE(s.is_waypoint,0), s.wp_lat, s.wp_lng, em.geo_lat, em.geo_lng "
                "FROM sys_place_route_stop s "
                "LEFT JOIN sys_entity_master em ON em.entity_id=s.entity_id "
                "WHERE s.route_id=? AND s.record_status='LIVE' AND COALESCE(s.is_posthumous,0)=0 "
                "ORDER BY s.seq", (route_id,)).fetchall()
        except sqlite3.OperationalError:
            rows = []
        finally:
            conn.close()
        path = []
        for is_wp, wlat, wlng, glat, glng in rows:
            if is_wp and wlat is not None and wlng is not None:
                path.append((float(wlat), float(wlng)))
            elif glat is not None and glng is not None:
                path.append((float(glat), float(glng)))
        return path

    def _route_post(self, route_id):
        """사후 운구(장례 등) 회색 꼬리 → {'path':[(lat,lng)..], 'stops':[(seq,eid,ref,stop_id)..]}.
        없으면 None. path 는 마지막 생전 정류장에서 시작하도록 연결점 prepend(선 이어짐)."""
        conn = appdb.connect(self.db_path)
        try:
            post = conn.execute(
                "SELECT s.seq, s.entity_id, COALESCE(s.scripture_ref,''), s.stop_id, "
                "  COALESCE(s.is_waypoint,0), s.wp_lat, s.wp_lng, em.geo_lat, em.geo_lng "
                "FROM sys_place_route_stop s LEFT JOIN sys_entity_master em ON em.entity_id=s.entity_id "
                "WHERE s.route_id=? AND s.record_status='LIVE' AND COALESCE(s.is_posthumous,0)=1 "
                "ORDER BY s.seq", (route_id,)).fetchall()
            if not post:
                return None
            last = conn.execute(
                "SELECT em.geo_lat, em.geo_lng FROM sys_place_route_stop s "
                "JOIN sys_entity_master em ON em.entity_id=s.entity_id "
                "WHERE s.route_id=? AND s.record_status='LIVE' AND COALESCE(s.is_posthumous,0)=0 "
                "AND COALESCE(s.is_waypoint,0)=0 ORDER BY s.seq DESC LIMIT 1", (route_id,)).fetchone()
        except sqlite3.OperationalError:
            return None
        finally:
            conn.close()
        path = []
        if last and last[0] is not None:
            path.append((float(last[0]), float(last[1])))
        stops = []
        for seq, eid, ref, sid, is_wp, wlat, wlng, glat, glng in post:
            if is_wp and wlat is not None and wlng is not None:
                path.append((float(wlat), float(wlng)))
            elif glat is not None and glng is not None:
                path.append((float(glat), float(glng)))
                stops.append((seq, eid, ref, sid))
        return {'path': path, 'stops': stops}

    def _route_conf(self, route_id):
        conn = appdb.connect(self.db_path)
        try:
            r = conn.execute("SELECT confidence FROM sys_place_route WHERE route_id=?",
                             (route_id,)).fetchone()
            return r[0] if r else None
        except Exception:
            return None
        finally:
            conn.close()

    def _build_route_info(self, rid, color=None):
        """활성 경로 info 중앙 생성 — color/stops(생전)/path(선)/pred(이전 세대)/post(사후 운구)/tradition."""
        info = {'color': color or self._route_color(rid) or '#C0392B',
                'stops': self._route_stops(rid), 'path': self._route_path(rid),
                'tradition': self._route_conf(rid) in _TRADITION_CONF}
        pred = self._predecessor_route(rid)
        if pred:
            info['pred_name'], info['pred_stops'], info['pred_path'] = pred
        post = self._route_post(rid)
        if post:
            info['post'] = post
        return info

    def _route_color(self, route_id):
        conn = appdb.connect(self.db_path)
        try:
            r = conn.execute("SELECT COALESCE(color,'#C0392B') FROM sys_place_route "
                             "WHERE route_id=?", (route_id,)).fetchone()
            return r[0] if r else None
        finally:
            conn.close()

    def _predecessor_route(self, route_id):
        """같은 그룹(족장 등)에서 이 인물의 '이전 세대' 경로(부모)를 찾아
        (이름, 정류장목록) 반환. 없으면 None. — faded overlay 용."""
        conn = appdb.connect(self.db_path)
        try:
            if not any(r[1] == 'parent_id'
                       for r in conn.execute("PRAGMA table_info(sys_place_route_theme)")):
                return None
            row = conn.execute(
                "SELECT th.theme_id, th.parent_id, th.sort_order FROM sys_place_route r "
                "JOIN sys_place_route_theme th ON th.theme_id=r.theme_id "
                "WHERE r.route_id=?", (route_id,)).fetchone()
            if not row or row[1] is None:
                return None
            _tid, parent, sort = row
            # 계승 그룹만 회색 overlay (동료 그룹 — 사도 등 — 제외)
            pcode = conn.execute("SELECT theme_code FROM sys_place_route_theme WHERE theme_id=?",
                                 (parent,)).fetchone()
            if not pcode or pcode[0] not in _SUCCESSION_GROUPS:
                return None
            prev = conn.execute(
                "SELECT theme_id FROM sys_place_route_theme "
                "WHERE parent_id=? AND sort_order < ? AND record_status='LIVE' "
                "ORDER BY sort_order DESC LIMIT 1", (parent, sort)).fetchone()
            if not prev:
                return None
            ptid = prev[0]
            prt = conn.execute(
                "SELECT route_id FROM sys_place_route WHERE theme_id=? AND record_status='LIVE' "
                "ORDER BY is_default DESC, sort_order LIMIT 1", (ptid,)).fetchone()
            if not prt:
                return None
            nm = conn.execute(
                "SELECT COALESCE(tn.contents, en.contents, th.theme_code) "
                "FROM sys_place_route_theme th "
                "LEFT JOIN sys_text_asset tn ON tn.clicked_id=th.theme_id "
                "  AND tn.text_type='ROUTE_THEME_NAME' AND tn.lang_code=? "
                "LEFT JOIN sys_text_asset en ON en.clicked_id=th.theme_id "
                "  AND en.text_type='ROUTE_THEME_NAME' AND en.lang_code='EN' "
                "WHERE th.theme_id=?", (self._lang(), ptid)).fetchone()
            try:
                stops = conn.execute(
                    "SELECT s.seq, s.entity_id, COALESCE(s.scripture_ref,'') "
                    "FROM sys_place_route_stop s WHERE s.route_id=? AND s.record_status='LIVE' "
                    "AND COALESCE(s.is_waypoint,0)=0 AND COALESCE(s.is_posthumous,0)=0 "
                    "ORDER BY s.seq", (prt[0],)).fetchall()
            except sqlite3.OperationalError:
                stops = conn.execute(
                    "SELECT s.seq, s.entity_id, COALESCE(s.scripture_ref,'') "
                    "FROM sys_place_route_stop s WHERE s.route_id=? AND s.record_status='LIVE' "
                    "ORDER BY s.seq", (prt[0],)).fetchall()
            return (nm[0] if nm else '', stops, self._route_path(prt[0]))
        finally:
            conn.close()

    # ── 사이드바 핸들러 ──────────────────────────────────────────────────────
    def _on_place_lb(self, _e):
        sel = self._place_lb.curselection()
        if not sel:
            return
        eid = self._lb_eids[sel[0]]
        if eid in self._place_xy:
            lat, lng, name = self._place_xy[eid]
            self._cx, self._cy = lng, lat
            self._sel_eid = eid
            self._active_routes = {}   # 새 장소 선택 시 이전 발자취 여정 초기화
            self._status.config(text=f'선택: {name} (더블클릭=상세)')
            self._sync_place_btn()
            self._load_footprints(eid, name)
            self._save_view(); self._redraw()

    def _sync_place_btn(self):
        """선택한 장소를 상단 단추에 비춘다 — 세 경로(목록·핀·정류장)가 함께 쓴다."""
        b = getattr(self, '_ent_btn', None)
        if b is None:
            return
        eid = getattr(self, '_sel_eid', None)
        nm = ''
        if eid and eid in getattr(self, '_place_xy', {}):
            nm = self._place_xy[eid][2] or ''
        # ★ 라벨은 **「이 장소 ⇒ 주요용어」** — 「주요용어: 빌립보」는 무엇을
        #   보고 있는지처럼 읽힌다. 화살표가 「더 알려면 저리로 가라」를 말한다
        #   (2026-08-21 사용자 지시).
        # ⚠ 화살표는 **맑은 고딕·굴림체가 둘 다 가진 것**에서 고른다 —
        #   `➔`(캔버스 Journey 티커가 쓰는 것)는 **두 글꼴에 없어** Segoe UI
        #   Symbol 폴백으로 그려진다(cmap 실측). 둘 다 가진 것은 → ⇒ ▶ » 뿐.
        if eid:
            b.config(state='normal',
                     text=(i18n.t('PV_ENTITY_GO_N', '%s ⇒ 주요용어') % nm) if nm
                     else i18n.t('PV_ENTITY_GO', '⇒ 주요용어'))
        else:
            b.config(state='disabled', text=i18n.t('PV_ENTITY_GO', '⇒ 주요용어'))

    def _jump_entity(self):
        """상단 단추 → P4 주요용어 탭에서 그 장소를 연다(더블클릭과 같은 길)."""
        eid = getattr(self, '_sel_eid', None)
        if eid and self.on_place_jump:
            self.on_place_jump(eid)

    def _load_footprints(self, eid, place_name):
        """선택 장소를 지나간 인물 여정(이곳의 발자취)을 하단 목록에 채운다.
        sys_place_route_stop 역질의 — (인물, 본문) 단위로 중복 제거."""
        if not hasattr(self, '_fp_lb'):
            return
        self._fp_lb.delete(0, 'end')
        self._fp_data = []
        conn = appdb.connect(self.db_path)
        try:
            rows = conn.execute(
                "SELECT t.theme_id, COALESCE(tn.contents, en.contents, t.theme_code), "
                "  s.scripture_ref, r.route_id, r.is_default, t.sort_order, s.seq, s.stop_id "
                "FROM sys_place_route_stop s "
                "JOIN sys_place_route r ON r.route_id=s.route_id "
                "JOIN sys_place_route_theme t ON t.theme_id=r.theme_id "
                "LEFT JOIN sys_text_asset tn ON tn.clicked_id=t.theme_id "
                "  AND tn.text_type='ROUTE_THEME_NAME' AND tn.lang_code=? "
                "LEFT JOIN sys_text_asset en ON en.clicked_id=t.theme_id "
                "  AND en.text_type='ROUTE_THEME_NAME' AND en.lang_code='EN' "
                "WHERE s.entity_id=? AND s.record_status='LIVE' AND r.record_status='LIVE' "
                "AND COALESCE(s.is_waypoint,0)=0 "
                "ORDER BY t.sort_order, s.seq", (self._lang(), eid)).fetchall()
        except Exception:
            rows = []
        finally:
            conn.close()
        # (인물, 본문) 중복 제거 — 같은 인물의 학설 변형은 default 경로로 묶음
        seen = {}
        for tid, tname, ref, rid, isdef, _so, _seq, stop_id in rows:
            key = (tid, ref)
            if key not in seen or isdef:
                seen[key] = {'name': tname, 'ref': ref, 'rid': rid, 'stop_id': stop_id}
        ordered = list(seen.values())
        n = len({k[0] for k in seen})
        self._fp_label_var.set(i18n.t('PV_FOOTPRINTS_N','이곳의 발자취 — {place} ({n}명)').format(place=place_name, n=n)
                               if ordered else i18n.t('PV_FOOTPRINTS_NONE','이곳의 발자취 — {place} (없음)').format(place=place_name))
        for d in ordered:
            self._fp_lb.insert('end', f"  {d['name']}  ·  {d['ref']}")
            self._fp_data.append(d)
        if not ordered:
            self._fp_lb.insert('end', i18n.t('PV_NO_JOURNEY', '  (이 장소를 지나간 인물 여정이 아직 없습니다)'))
            self._fp_data.append(None)

    def _on_footprint_click(self, _e):
        sel = self._fp_lb.curselection()
        if not sel or sel[0] >= len(self._fp_data):
            return
        d = self._fp_data[sel[0]]
        if not d:
            return
        rid = d['rid']
        # 테마순례처럼 그 인물 여정을 지도에 단독 표시(이전 세대 overlay 포함)
        self._active_routes = {rid: self._build_route_info(rid)}
        self._fit_to_routes()
        # 스토리 슬라이딩 패널(장소×인물) — 인물기준과 동일
        self._open_story(d['stop_id'], d['ref'], d['name'])
        self._save_view(); self._redraw()

    def _on_theme_click(self, e):
        iid = self._theme_tv.identify_row(e.y)
        if not iid:
            return
        if iid in self._stop_meta:      # 정류장 자식 클릭 → 지도 이동 + 스토리 슬라이드
            eid, ref, sid, person = self._stop_meta[iid]
            if eid in self._place_xy:
                lat, lng, _name = self._place_xy[eid]
                self._cx, self._cy = lng, lat
                self._sel_eid = eid
                self._sync_place_btn()
                self._redraw()
            self._open_story(sid, ref, person)
            return
        if iid not in self._route_meta:  # 그룹/테마 헤더 클릭 → 무시
            return
        rid, color = self._route_meta[iid]
        # 토글(체크 + 정류장 펼침/접기)
        if rid in self._active_routes:
            del self._active_routes[rid]
            cur = self._theme_tv.item(iid, 'text').replace('☑', '☐', 1)
            self._theme_tv.item(iid, text=cur, open=False)
        else:
            self._active_routes[rid] = self._build_route_info(rid, color)
            cur = self._theme_tv.item(iid, 'text').replace('☐', '☑', 1)
            self._theme_tv.item(iid, text=cur, open=True)
            self._fit_to_routes()
            self._save_view()
        self._redraw()

    def _fit_to_routes(self):
        pts = []
        for info in self._active_routes.values():
            for lat, lng in info.get('path', []):     # 경유점 포함 전체 경로
                pts.append((lat, lng))
            for lat, lng in info.get('post', {}).get('path', []):   # 사후 운구 꼬리도 포함
                pts.append((lat, lng))
            for _s, eid, _r in info.get('stops', []):
                if eid in self._place_xy:
                    pts.append(self._place_xy[eid][:2])
        if not pts:
            return
        lats = [p[0] for p in pts]; lngs = [p[1] for p in pts]
        self._set_view_bounds(min(lngs), min(lats), max(lngs), max(lats), pad=0.7)

    # ── 투영 ────────────────────────────────────────────────────────────────
    # ── 웹 메르카토르 투영 (위성 타일과 동일 좌표계) ──────────────────────────
    # self._scale = 전세계 폭(정규화 1.0 = 경도 360°)을 덮는 픽셀 수(px/world).
    @staticmethod
    def _wx(lng):
        return (lng + 180.0) / 360.0

    @staticmethod
    def _wy(lat):
        s = math.sin(math.radians(lat))
        s = min(0.9999, max(-0.9999, s))
        return 0.5 - math.log((1 + s) / (1 - s)) / (4 * math.pi)

    @staticmethod
    def _inv_wy(wy):
        return math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * wy))))

    def _coslat(self):
        return max(0.2, math.cos(math.radians(self._cy)))

    def _to_xy(self, lat, lng):
        w = self._canvas.winfo_width() or 1; h = self._canvas.winfo_height() or 1
        S = self._scale
        return (w / 2 + (self._wx(lng) - self._wx(self._cx)) * S,
                h / 2 + (self._wy(lat) - self._wy(self._cy)) * S)

    def _set_view_bounds(self, lng0, lat0, lng1, lat1, pad=0.82):
        """주어진 경위도 범위가 캔버스에 들어오도록 중심·배율(S) 설정."""
        w = self._canvas.winfo_width() or 800; h = self._canvas.winfo_height() or 500
        self._cx = (lng0 + lng1) / 2; self._cy = (lat0 + lat1) / 2
        dwx = abs(self._wx(lng1) - self._wx(lng0)) or 1e-4
        dwy = abs(self._wy(lat0) - self._wy(lat1)) or 1e-4
        self._scale = min(w * pad / dwx, h * pad / dwy)

    def _fit(self):
        if not self._places:
            self._redraw(); return
        lats = [p[2] for p in self._places]; lngs = [p[3] for p in self._places]
        self._set_view_bounds(min(lngs), min(lats), max(lngs), max(lats))
        self._save_view(); self._redraw()

    def _zoom_at(self, factor):
        self._scale *= factor
        self._save_view(); self._redraw()

    # ── 그리기 ──────────────────────────────────────────────────────────────
    def _draw_poly(self, c, poly, color, width, dash=None):
        w = c.winfo_width() or 1; h = c.winfo_height() or 1
        pts = []
        for lng, lat in poly:
            pts.append(self._to_xy(lat, lng))
        if not any(-60 <= x <= w + 60 and -60 <= y <= h + 60 for x, y in pts):
            return
        flat = [v for p in pts for v in p]
        if len(flat) >= 4:
            if dash:
                c.create_line(*flat, fill=color, width=width, dash=dash)
            else:
                c.create_line(*flat, fill=color, width=width)

    def _clamp_view(self):
        """지도 영역(bbox) 밖 빈 공간이 안 보이도록 줌·이동 제한 (메르카토르 world 좌표)."""
        w = self._canvas.winfo_width() or 800
        h = self._canvas.winfo_height() or 500
        lng0, lat0, lng1, lat1 = _BBOX
        wx0 = self._wx(lng0); wx1 = self._wx(lng1)
        wy0 = self._wy(lat1); wy1 = self._wy(lat0)   # wy 는 위도↑ 일수록 작음
        dwx = wx1 - wx0; dwy = wy1 - wy0
        # 최소 배율: bbox 가 캔버스를 가득(더 축소 = 빈 공간 → 금지)
        smin = max(w / dwx, h / dwy)
        self._smin = smin
        self._scale = max(smin, min(self._scale, 256.0 * 2 ** 18))
        S = self._scale
        # 이동 제한: 보이는 영역이 bbox 안에 머물게
        halfwx = (w / 2) / S; halfwy = (h / 2) / S
        cwx = self._wx(self._cx); cwy = self._wy(self._cy)
        if halfwx >= dwx / 2:
            cwx = (wx0 + wx1) / 2
        else:
            cwx = min(max(cwx, wx0 + halfwx), wx1 - halfwx)
        if halfwy >= dwy / 2:
            cwy = (wy0 + wy1) / 2
        else:
            cwy = min(max(cwy, wy0 + halfwy), wy1 - halfwy)
        self._cx = cwx * 360.0 - 180.0
        self._cy = self._inv_wy(cwy)

    def _redraw(self):
        c = self._canvas
        c.delete('all')
        self._clamp_view()
        w = c.winfo_width() or 1; h = c.winfo_height() or 1
        # 전면 위성(모든 배율). 타일 준비됐으면 위성, 아니면 오프라인 윤곽 폴백.
        sat = self._build_sat(w, h)
        self._on_sat = (sat is not None)
        if sat is not None:
            c.create_image(0, 0, anchor='nw', image=sat)
            # 국경선(PD) 오버레이 — 정치 경계(위성엔 없음). 가는 노란 선.
            if self._ne:
                for poly in self._ne.get('borders', []):
                    self._draw_poly(c, poly, '#F4D03F', 1.4)
            c.create_text(w - 6, h - 5, text='Source: ' + _SAT_CREDIT, anchor='se',
                          fill='white', font=_MAPF(7))
        else:
            # 오프라인/로딩 폴백 — Natural Earth(PD) 윤곽 지도 + 안내
            c.create_rectangle(0, 0, w, h, fill='#0E2A38', outline='')
            if self._ne:
                for poly in self._ne.get('ocean', []):
                    pts = [self._to_xy(lat, lng) for lng, lat in poly]
                    flat = [v for p in pts for v in p]
                    if len(flat) >= 6:
                        c.create_polygon(*flat, fill='#14384A', outline='')
                for poly in self._ne.get('coast', []):
                    self._draw_poly(c, poly, '#6E8CA0', 1.1)
                for poly in self._ne.get('borders', []):
                    self._draw_poly(c, poly, '#C8B273', 1.6)
            msg = ('위성 지도 불러오는 중…' if self._sat_fetching
                   else '인터넷에 연결하면 위성 지도가 표시됩니다 (오프라인)')
            c.create_text(w / 2, 18, text=msg, fill='#EAF2F8',
                          font=_MAPF(9, 'bold'))
            c.create_text(w - 6, h - 5, text='Natural Earth (PD)', anchor='se',
                          fill='#9AB0BF', font=_MAPF(7))
        # 장소 핀 — 장소 모드에선 지역 필터 적용, 테마 모드에선 전체(배경)
        base = '#7FA8C9' if self._mode == 'theme' and self._active_routes else '#2980B9'
        pins = self._places if self._mode == 'theme' else self._visible_places()
        for eid, name, lat, lng in pins:
            x, y = self._to_xy(lat, lng)
            if not (-40 <= x <= w + 40 and -40 <= y <= h + 40):
                continue
            sel = (eid == self._sel_eid)
            r = 6 if sel else 4
            c.create_oval(x - r, y - r, x + r, y + r,
                          fill='#C0392B' if sel else base, outline='white', width=1)
            # 라벨 겹침 정리: 선택 항목 + (장소모드에서 충분히 확대했을 때)만 표시
            show_label = sel or (self._mode == 'place' and self._scale >= 70
                                 and not self._active_routes)
            if show_label:
                self._label(c, x + 8, y, name, 'w',
                            _MAPF(9, 'bold' if sel else 'normal'))
        # 이전 세대(부모) 경로 — 회색 곡선(계승 맥락). 활성 경로보다 먼저(아래) 그림.
        for rid, info in self._active_routes.items():
            pstops = info.get('pred_stops')
            if not pstops:
                continue
            # 선: 전체 경로(경유점 포함) / 점: 실제 정류장만
            ppath = info.get('pred_path') or [self._place_xy[eid][:2]
                                              for _s, eid, _r in pstops if eid in self._place_xy]
            lpts = [self._to_xy(lat, lng) for lat, lng in ppath]
            for i in range(len(lpts) - 1):
                c.create_line(*self._curve(*lpts[i], *lpts[i + 1], i),
                              fill='#AEB8C2', width=3, smooth=True, splinesteps=16)
            dots = [self._to_xy(*self._place_xy[eid][:2])
                    for _s, eid, _r in pstops if eid in self._place_xy]
            for px, py in dots:
                c.create_oval(px - 4, py - 4, px + 4, py + 4, fill='#AEB8C2', outline='white', width=1)
            if dots:
                self._label(c, dots[0][0] + 8, dots[0][1] - 9,
                            f'이전 세대: {info.get("pred_name", "")}', 'w',
                            _MAPF(8, 'italic'))
        # 활성 경로(학설) 오버레이 — 색깔 곡선 + 작은 점·번호(배경 원 없음)
        for rid, info in self._active_routes.items():
            color = info['color']
            # 선: 전체 경로(실제 정류장 + 경유점) — 육지 경유 표현
            # 전승(LATER_TRADITION) 경로는 점선·가는 선으로 성경 경로와 구분
            trad = info.get('tradition')
            lopts = {'fill': color, 'width': 4 if trad else 3, 'arrow': 'last',
                     'smooth': True, 'splinesteps': 16}
            if trad:
                lopts['dash'] = (10, 6)   # 굵은 점선 — 전승 경로 가시성
            path = info.get('path') or [self._place_xy[eid][:2]
                                        for _s, eid, _r in info['stops'] if eid in self._place_xy]
            lpts = [self._to_xy(lat, lng) for lat, lng in path]
            for i in range(len(lpts) - 1):
                c.create_line(*self._curve(*lpts[i], *lpts[i + 1], i), **lopts)
            # 핀·번호: 실제 정류장만, 표시 번호는 실제 순서대로(seq 간격 무관)
            n = 0
            for seq, eid, ref in info['stops']:
                if eid not in self._place_xy:
                    continue
                n += 1
                lat, lng, name = self._place_xy[eid]
                x, y = self._to_xy(lat, lng)
                c.create_oval(x - 5, y - 5, x + 5, y + 5, fill=color, outline='white', width=1)
                self._label(c, x + 9, y, f'{n}. {name}', 'w', _MAPF(9, 'bold'))
            # 사후 운구(장례 등) — 회색 점선 + ✝ 라벨(생전 경로와 구분)
            post = info.get('post')
            if post and post.get('path'):
                ppts = [self._to_xy(lat, lng) for lat, lng in post['path']]
                for i in range(len(ppts) - 1):
                    c.create_line(*self._curve(*ppts[i], *ppts[i + 1], i),
                                  fill='#7F8C8D', width=2, arrow='last', dash=(6, 4),
                                  smooth=True, splinesteps=16)
                for seq, eid, ref, _sid in post['stops']:
                    if eid not in self._place_xy:
                        continue
                    lat, lng, name = self._place_xy[eid]
                    x, y = self._to_xy(lat, lng)
                    c.create_oval(x - 4, y - 4, x + 4, y + 4, fill='#7F8C8D',
                                  outline='white', width=1)
                    self._label(c, x + 9, y, f'✝ {name}', 'w', _MAPF(9, 'bold'))
        self._draw_scalebar(c, w, h)

    @staticmethod
    def _nice_km(v):
        if v <= 0:
            return 1
        p = 10 ** int(math.floor(math.log10(v)))
        for m in (1, 2, 5):
            if v <= m * p:
                return int(m * p)
        return int(10 * p)

    @staticmethod
    def _curve(ax, ay, bx, by, idx):
        """A→B 를 직선이 아니라 완만한 S커브로(현대 도로처럼 구불구불 — 정확성 아님).
        세그먼트 인덱스로 휘는 방향을 번갈아 → 결정적(드래그/줌에도 흔들림 없음)."""
        dx, dy = bx - ax, by - ay
        L = math.hypot(dx, dy) or 1.0
        nx, ny = -dy / L, dx / L          # 수직 단위벡터
        amp = min(L * 0.13, 36.0)
        s = 1.0 if idx % 2 == 0 else -1.0
        return [ax, ay,
                ax + dx / 3 + nx * amp * s, ay + dy / 3 + ny * amp * s,
                ax + 2 * dx / 3 - nx * amp * s, ay + 2 * dy / 3 - ny * amp * s,
                bx, by]

    def _label(self, c, x, y, text, anchor, font):
        """지도 라벨 — 어두운 배경(위성·오프라인) 위 흰 글자 + 검은 후광."""
        for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
            c.create_text(x + dx, y + dy, text=text, anchor=anchor, fill='black', font=font)
        c.create_text(x, y, text=text, anchor=anchor, fill='white', font=font)

    def _draw_scalebar(self, c, w, h):
        # 메르카토르: px/도(경도) = S/360, 중심 위도의 지상거리로 환산
        ppk = (self._scale / 360.0) / (111.32 * self._coslat())   # px/km
        if ppk <= 0:
            return
        km = self._nice_km(90 / ppk)
        barpx = km * ppk
        x0, y0 = 16, h - 18
        c.create_line(x0 - 1, y0, x0 + barpx + 1, y0, fill='black', width=5)
        c.create_line(x0, y0, x0 + barpx, y0, fill='white', width=3)
        c.create_line(x0, y0 - 4, x0, y0 + 4, fill='white', width=2)
        c.create_line(x0 + barpx, y0 - 4, x0 + barpx, y0 + 4, fill='white', width=2)
        self._label(c, x0 + barpx / 2, y0 - 9, f'{km:,} km', 'center',
                    _MAPF(8, 'bold'))
        if hasattr(self, '_zoom_var'):
            ref = getattr(self, '_smin', 0) or self._scale
            self._zoom_var.set(f'배율 ×{self._scale / ref:.1f}')

    # ── 상호작용 ────────────────────────────────────────────────────────────
    def _nearest(self, ex, ey, thresh=16):
        best, bd = None, thresh * thresh
        for eid, name, lat, lng in self._places:
            x, y = self._to_xy(lat, lng)
            d = (x - ex) ** 2 + (y - ey) ** 2
            if d <= bd:
                bd = d; best = (eid, name)
        return best

    def _on_press(self, e):
        self._drag = (e.x, e.y, False)

    def _on_drag(self, e):
        if not self._drag:
            return
        x0, y0, _ = self._drag
        dx, dy = e.x - x0, e.y - y0
        if abs(dx) + abs(dy) > 3:
            S = self._scale
            cwx = self._wx(self._cx) - dx / S
            cwy = self._wy(self._cy) - dy / S
            self._cx = cwx * 360.0 - 180.0
            self._cy = self._inv_wy(cwy)
            self._drag = (e.x, e.y, True)
            self._redraw()

    def _on_release(self, e):
        moved = self._drag[2] if self._drag else False
        self._drag = None
        if moved:
            self._save_view()
            return
        hit = self._nearest(e.x, e.y)
        if hit:
            self._sel_eid, name = hit
            self._sync_place_btn()
            if hasattr(self, '_status'):
                self._status.config(text=f'선택: {name} (더블클릭=상세)')
            # 활성 경로의 정류장이면 → 스토리 슬라이드인
            self._show_stop_story(hit[0], name)
            self._redraw()

    # ── 정류장 스토리 슬라이딩(가계도 §25.8 패턴) ─────────────────────────────
    def _stops_in_active(self, eid):
        """클릭한 장소가 활성 경로의 정류장이면 [{stop_id,ref,person}] 목록(복수 방문 포함)."""
        out = []
        if not self._active_routes:
            return out
        conn = appdb.connect(self.db_path)
        try:
            for rid in self._active_routes:
                rows = conn.execute(
                    "SELECT s.stop_id, s.scripture_ref, "
                    "  COALESCE(tn.contents, en.contents, t.theme_code) "
                    "FROM sys_place_route_stop s "
                    "JOIN sys_place_route r ON r.route_id=s.route_id "
                    "JOIN sys_place_route_theme t ON t.theme_id=r.theme_id "
                    "LEFT JOIN sys_text_asset tn ON tn.clicked_id=t.theme_id "
                    "  AND tn.text_type='ROUTE_THEME_NAME' AND tn.lang_code=? "
                    "LEFT JOIN sys_text_asset en ON en.clicked_id=t.theme_id "
                    "  AND en.text_type='ROUTE_THEME_NAME' AND en.lang_code='EN' "
                    "WHERE s.route_id=? AND s.entity_id=? AND s.record_status='LIVE' "
                    "ORDER BY s.seq", (self._lang(), rid, eid)).fetchall()
                for sid, ref, person in rows:
                    out.append({'stop_id': sid, 'ref': ref, 'person': person})
        except Exception:
            pass
        finally:
            conn.close()
        return out

    def _show_stop_story(self, eid, _name):
        stops = self._stops_in_active(eid)
        if stops:
            self._open_story(stops[0]['stop_id'], stops[0]['ref'], stops[0]['person'],
                             siblings=stops)

    def _story_width(self):
        """오버레이 카드 폭 — **직전값 우선**, 없으면 다국어 글꼴 실측
        (CJK 21자가 편하게 앉는 폭, 320~460 클램프)."""
        if self._state_get:
            try:
                w = int(self._state_get('pilgrimage_story_w', 0) or 0)
                if w >= 280:
                    return w
            except Exception:
                pass
        try:
            import tkinter.font as tkfont
            f = tkfont.Font(font=('', 10))
            w = f.measure('가' * 21) + 36
        except Exception:
            w = 400
        return max(320, min(460, w))

    def _story_height(self):
        """저장된 높이 — 없으면 None(내용 따라 자동)."""
        if self._state_get:
            try:
                h = int(self._state_get('pilgrimage_story_h', 0) or 0)
                if h >= 120:
                    return h
            except Exception:
                pass
        return None

    def _story_resized(self, w, h):
        """그립 드래그 → 크기 적용 + 직전값 저장 (2026-08-18 사용자)."""
        try:
            maxw = int(self._map_anchor.winfo_width() * 0.9) or 700
            maxh = int(self._map_anchor.winfo_height() * 0.95) or 760
        except Exception:
            maxw, maxh = 700, 760
        # 최소 높이 120 — 상단에 길게 눕힌 1~2줄 bar 로도 쓸 수 있게
        # (2026-08-18 사용자 「최소높이를 더 줄여라」)
        w = max(280, min(maxw, int(w)))
        h = max(120, min(maxh, int(h)))
        try:
            self._story.place_configure(width=w, height=h)
        except Exception:
            return
        if self._state_set:
            try:
                self._state_set('pilgrimage_story_w', w)
                self._state_set('pilgrimage_story_h', h)
            except Exception:
                pass

    def _open_story(self, stop_id, ref, person, siblings=None):
        """정류장 스토리 — **지도 위 왼쪽 상단 오버레이 카드** (2026-08-18).

        PanedWindow add 는 지도를 밀어 리사이즈시키므로 place() 로 띄운다 —
        지도는 그대로다. 높이는 내용을 따라 아래로 펼쳐진다(±5절 확장 포함).
        ⚠ 자리는 **왼쪽 트리 바로 오른쪽**(예전 자리) — 처음에 오른쪽 끝에
          붙였다가 사용자 지적(「위치는 예전이 맞다」)으로 좌상단으로."""
        if not hasattr(self, '_map_anchor'):
            return
        if getattr(self, '_story', None) is None:
            from journey_story import JourneyStorySlide
            self._story = JourneyStorySlide(
                self._map_anchor, db_path=self.db_path,
                lang_getter=self.lang_getter,
                on_close=self._hide_story, on_verse_jump=self.on_verse_jump,
                on_sibling=self._open_story)
            self._story.configure(bd=1, relief='solid')
            self._story_visible = False
        try:
            self._story.set_max_height(
                int(self._map_anchor.winfo_height() * 0.92) or 520)
        except Exception:
            pass
        self._story.show_stop(stop_id, ref, person, siblings=siblings)
        self._story.on_resize = self._story_resized
        if not getattr(self, '_story_visible', False):
            try:
                kw = dict(x=8, y=8, anchor='nw', width=self._story_width())
                h = self._story_height()
                if h:
                    kw['height'] = h       # 저장된 크기 복원
                self._story.place(**kw)
                self._story_visible = True
            except Exception as ex:
                print(f'[story slide] {ex}')
        self._story.lift()

    def _hide_story(self):
        if getattr(self, '_story', None) is not None and getattr(self, '_story_visible', False):
            try:
                self._story.place_forget()
                self._story_visible = False
            except Exception:
                pass

    def _save_story_w(self):
        """스토리 슬라이드 현재 폭을 직전값으로 저장(세션 + state)."""
        try:
            w = self._story.winfo_width()
        except Exception:
            return
        if w and w > 60:
            _STORY_W[0] = w
            if self._state_set:
                try:
                    self._state_set('pilgrimage_story_w', w)
                except Exception:
                    pass

    def _on_double(self, e):
        hit = self._nearest(e.x, e.y)
        if hit and self.on_place_jump:
            self._sel_eid = hit[0]; self._redraw()
            self.on_place_jump(hit[0])

    def _on_wheel(self, e):
        self._zoom_at(1.2 if e.delta > 0 else 0.83)

    def set_background(self, photo_image, bounds=None):
        """배경 지도 이미지 교체용(추후)."""
        self._bg_image = photo_image
        self._bg_bounds = bounds
        self._redraw()
