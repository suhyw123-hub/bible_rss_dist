# -*- coding: utf-8 -*-
"""db_index_tune.py — 자산·연결·텍스트 표의 **조회 인덱스**를 맞춘다 (영구 도구).

**왜 필요한가.** 인덱스가 한 방향만 있으면 반대 방향 질의가 **표를 통째로
훑는다**. 실측 — `sys_text_asset`(183,027행):

    WHERE text_type=? AND clicked_id=?     SEARCH USING INDEX   0.038 ms
    WHERE clicked_id=?                     **SCAN**             8.114 ms   ← 213배
    WHERE clicked_id=? AND lang_code=?     **SCAN**            42.043 ms   ← 거를수록 느리다

⚠⚠ **거르는 조건을 더했는데 더 느려지는 것**이 인덱스가 반쪽이라는 신호다.
  인덱스가 `(text_type, …)` 로 시작하면 `clicked_id` 만으로는 못 쓴다.

★ 규모가 커질수록 벌어진다 (합성 실측):
        183,027행   8.1 ms → 0.026 ms
        915,135행   1.96 ms → 0.63 ms   · 화면 20개 37.1 ms → 5.2 ms
      5,673,837행  27.8 ms → 4.70 ms   · 화면 20개 543 ms → 81 ms

★★ **덮개 인덱스**(covering) — 인덱스 안에 필요한 값이 다 있으면 표를 안 읽는다.
  본문(`contents`)은 넣지 않는다. 넣으면 인덱스가 표만큼 커진다.

⚠ 이 도구는 **인덱스만** 만든다. 데이터를 한 줄도 안 건드린다.
⚠ 표가 없는 DB 에서도 죽지 않는다(건너뛰고 알린다).

사용:
    python db_index_tune.py --selftest    (의무)
    python db_index_tune.py --check
    python db_index_tune.py --apply       (멱등)
    python db_index_tune.py --drop        (되돌리기 — 이 도구가 만든 것만)
"""
import sys
import time

import appdb

PREFIX = 'idx_tune_'          # ⚠ 이 접두가 붙은 것만 `--drop` 이 지운다

#: (스키마, 표, 이름, 칸, 왜)
INDEXES = [
    ('main', 'sys_text_asset', PREFIX + 'text_anchor',
     'clicked_id, text_type, lang_code, text_variant',
     '「그 자산에 붙은 글 전부」 — 없으면 전수 SCAN(8ms). '
     '관리자 엔티티 관리·렌즈 관리가 실제로 이 꼴로 묻는다'),
    ('userdb', 'user_text_asset', PREFIX + 'utext_anchor',
     'clicked_id, text_type, lang_code',
     '내 글도 같은 꼴 — 지금은 작지만 규칙을 같게 둔다'),
]


def _tables(conn, sch):
    return {r[0] for r in conn.execute(
        "SELECT name FROM %s.sqlite_master WHERE type='table'" % sch)}


def _indexes(conn, sch):
    return {r[0] for r in conn.execute(
        "SELECT name FROM %s.sqlite_master WHERE type='index'" % sch)}


def check(conn, verbose=True):
    """빠진 인덱스 목록. 비어 있으면 다 맞다."""
    miss = []
    for sch, tbl, name, cols, why in INDEXES:
        if tbl not in _tables(conn, sch):
            if verbose:
                print('  (건너뜀) %s.%s 표가 없다' % (sch, tbl))
            continue
        if name in _indexes(conn, sch):
            if verbose:
                print('  있음   %-28s %s' % (name, cols))
        else:
            miss.append((sch, tbl, name, cols, why))
            if verbose:
                print('  **없음** %-28s %s' % (name, cols))
                print('           ↳ %s' % why)
    return miss


def apply(conn, verbose=True):
    miss = check(conn, verbose=False)
    made = 0
    for sch, tbl, name, cols, _why in miss:
        t0 = time.perf_counter()
        conn.execute('CREATE INDEX IF NOT EXISTS %s.%s ON %s(%s)'
                     % (sch, name, tbl, cols))
        conn.commit()
        made += 1
        if verbose:
            print('  만듦   %-28s %.1f초' % (name, time.perf_counter() - t0))
    if verbose:
        print('  ANALYZE …')
    conn.execute('ANALYZE')
    conn.commit()
    if verbose:
        print('새로 %d · 그대로 %d' % (made, len(INDEXES) - made))
    return made


def drop(conn, verbose=True):
    """이 도구가 만든 것만 지운다 — 원래 있던 인덱스는 안 건드린다."""
    n = 0
    for sch, tbl, name, _c, _w in INDEXES:
        if name in _indexes(conn, sch):
            conn.execute('DROP INDEX %s.%s' % (sch, name))
            n += 1
    conn.commit()
    if verbose:
        print('지운 인덱스 %d개' % n)
    return n


def plan(conn, sql):
    """실행계획 한 줄 — `SEARCH`(인덱스) 인가 `SCAN`(전수) 인가."""
    return ' | '.join(r[3] for r in conn.execute('EXPLAIN QUERY PLAN ' + sql))


def report(conn):
    """지금 무엇이 SCAN 인가 — 사람이 읽는 진단."""
    print('\n── 실행계획 ─────────────────────────────────────────────')
    for lbl, sql in (
            ('유형+번호+언어',
             "SELECT contents FROM sys_text_asset "
             "WHERE text_type='VERS_DESC' AND clicked_id=1 AND lang_code='KO'"),
            ('번호만',
             "SELECT text_type FROM sys_text_asset WHERE clicked_id=1"),
            ('번호+언어',
             "SELECT text_type FROM sys_text_asset "
             "WHERE clicked_id=1 AND lang_code='KO'")):
        p = plan(conn, sql)
        mark = '  SCAN ⚠' if 'SCAN' in p else '  SEARCH'
        print('  %-16s %-8s %s' % (lbl, mark, p[:70]))


# ── 자가 검증 ────────────────────────────────────────────────────────────────

def selftest():
    """⚠ **진짜 DB 를 안 건드린다** — 작은 복제본을 만들어 잰다.

    ⚠⚠ 시간으로 재지 않는다(§61차 — 같은 스캔이 150ms↔2,100ms 로 흔들린다).
      **실행계획이 SCAN → SEARCH 로 바뀌는가**로 잰다.
    """
    import os
    import sqlite3
    ok = fail = 0

    def t(n, c, e=''):
        nonlocal ok, fail
        if c:
            ok += 1
        else:
            fail += 1
            print('  FAIL %s  %s' % (n, e))

    tmp = os.path.join(os.environ.get('TEMP', '.'), 'idxtune_selftest.db')
    for e in ('', '-wal', '-shm'):
        if os.path.exists(tmp + e):
            os.remove(tmp + e)
    d = sqlite3.connect(tmp)
    try:
        d.execute("""CREATE TABLE sys_text_asset (
          sys_text_id INTEGER PRIMARY KEY, clicked_id INTEGER, target_id INTEGER,
          text_type TEXT, title TEXT, contents TEXT, lang_code TEXT,
          record_status TEXT, origin_id INTEGER, created_at TEXT, text_variant TEXT)""")
        d.executemany("INSERT INTO sys_text_asset (clicked_id, text_type, lang_code, contents)"
                      " VALUES (?,?,?,?)",
                      [(i % 500, 'T%d' % (i % 7), 'KO' if i % 2 else 'EN', 'x' * 40)
                       for i in range(4000)])
        # 지금 앱이 가진 것과 같은 「한 방향」 인덱스
        d.execute("CREATE INDEX idx_text_tier ON sys_text_asset"
                  "(text_type, clicked_id, lang_code, text_variant)")
        d.commit(); d.execute('ANALYZE'); d.commit()

        q_fwd = ("SELECT contents FROM sys_text_asset "
                 "WHERE text_type='T1' AND clicked_id=3 AND lang_code='KO'")
        q_rev = "SELECT text_type FROM sys_text_asset WHERE clicked_id=3"
        q_lng = ("SELECT text_type FROM sys_text_asset "
                 "WHERE clicked_id=3 AND lang_code='KO'")

        # ① 인덱스가 없으면 **새 인덱스를 못 쓴다**
        # ⚠⚠ 「SCAN 이 나오는가」로 재면 안 된다 — **작은 표에서는 SQLite 가
        #   skip-scan**(`ANY(text_type)`)을 골라 SCAN 이 안 나온다(실측으로 잡았다).
        #   진짜 표(183,027행 · 유형 18종)에서는 SCAN 이다. 표 크기에 따라 답이
        #   달라지는 검사는 못 쓴다 ⇒ **「어느 인덱스를 골랐는가」**로 잰다.
        NEW = PREFIX + 'text_anchor'
        t('한 방향은 원래 인덱스를 쓴다',
          'idx_text_tier' in plan(d, q_fwd), plan(d, q_fwd))
        t('반대 방향은 아직 새 인덱스가 없다',
          NEW not in plan(d, q_rev), plan(d, q_rev))
        t('언어를 더해도 아직 없다', NEW not in plan(d, q_lng), plan(d, q_lng))

        # ② 고쳐지는가 — **새 인덱스를 골라야** 한다
        d.execute("CREATE INDEX %s ON sys_text_asset"
                  "(clicked_id, text_type, lang_code, text_variant)" % NEW)
        d.commit(); d.execute('ANALYZE'); d.commit()
        t('반대 방향이 새 인덱스를 쓴다', NEW in plan(d, q_rev), plan(d, q_rev))
        t('그때 clicked_id 가 앞선다',
          'clicked_id=?' in plan(d, q_rev), plan(d, q_rev))
        t('언어를 더해도 새 인덱스', NEW in plan(d, q_lng), plan(d, q_lng))
        # ⚠ 새 인덱스가 **양방향을 다 감당**한다 — 세 칸이 전부 등호로 걸리면
        #   SQLite 가 어느 쪽을 골라도 같다. 「원래 것을 계속 쓰는가」로 재면
        #   틀린다(실측). 재야 할 것은 **여전히 인덱스를 쓰는가**이다.
        t('한 방향도 여전히 인덱스를 쓴다',
          'SEARCH' in plan(d, q_fwd) and 'text_type=?' in plan(d, q_fwd),
          plan(d, q_fwd))
        # 옛 인덱스는 **유형만으로 찾는 자리**를 위해 남긴다
        t('유형만으로도 인덱스를 쓴다',
          'SEARCH' in plan(d, "SELECT clicked_id FROM sys_text_asset WHERE text_type='T1'"),
          plan(d, "SELECT clicked_id FROM sys_text_asset WHERE text_type='T1'"))

        # ③ 값이 안 바뀐다 — 인덱스는 결과를 바꾸지 않아야 한다
        a = d.execute("SELECT COUNT(*) FROM sys_text_asset WHERE clicked_id=3").fetchone()[0]
        t('행 수 불변', a == 4000 // 500, a)
        t('데이터 총량 불변',
          d.execute("SELECT COUNT(*) FROM sys_text_asset").fetchone()[0] == 4000)
    finally:
        d.close()
        for e in ('', '-wal', '-shm'):
            if os.path.exists(tmp + e):
                os.remove(tmp + e)

    # ④ 진짜 DB — 멱등과 「안 건드림」만 확인(만들지는 않는다)
    conn = appdb.connect()
    try:
        before = {(s, n) for s, _t, n, _c, _w in INDEXES for n in [n]
                  if n in _indexes(conn, s)}
        miss = check(conn, verbose=False)
        t('check 가 목록을 준다', isinstance(miss, list))
        after = {(s, n) for s, _t, n, _c, _w in INDEXES for n in [n]
                 if n in _indexes(conn, s)}
        t('check 는 아무것도 안 만든다', before == after)
    finally:
        conn.close()

    print('selftest %d/%d' % (ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a or not a:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect()
    try:
        if '--apply' in a:
            apply(c); report(c)
        elif '--drop' in a:
            drop(c); report(c)
        else:
            miss = check(c); report(c)
            sys.exit(0 if not miss else 1)
    finally:
        c.close()
