# user_lens_manager.py
# -*- coding: utf-8 -*-
"""
P1 탭2 묵상플랜 → 렌즈묵상 서브탭의 메인 뷰.

두 클래스:
  - LensView (신규, Phase 2-E)     : 좌측 카테고리 트리 + 우측 계단식 패널 — 현재 사용
  - AppContent (구식, 롤백용 보존) : ComponentFactory 기반 4단 수평 패널 — 미사용
"""

import sqlite3
import appdb
import verse_text as _vt   # ★ 절 본문은 이 문 하나로(합쳐짐·없는절 보완 §verse_text)
import i18n
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from ui_components import BibleUI, ComponentFactory, COMPONENT_MATRIX
from shared_map import NAV_REGISTRY, EVENT_MAP, SYS_MASTER_MAP, USER_MASTER_MAP, RELATION_GATES
from ui_components import UniversalCascadeDialog
import bidi                               # 오른쪽에서 왼쪽으로 읽는 글 (font.md §8)

def _flat(**over):
    """My Edit·Recent 류 **테두리 없는 단추** — 모양의 단일 소스는 `ui_theme`.

    ⚠ 화면마다 손으로 적으면 갈라진다(실측 7곳이 bd·padx·글꼴이 제각각이었다 —
      2026-08-30 사용자 지시 「My Edit 버튼의 디자인을 통일하라. Recent 버튼과
      동일하게」).
    """
    try:
        import ui_theme
        return ui_theme.flat_btn(**over)
    except Exception:
        return dict(bd=1, padx=6, pady=2, cursor='hand2', **over)



# ═══════════════════════════════════════════════════════════════════════════
# [Phase 2-E Step 1] LensView — 신규 렌즈묵상 메인 뷰
# ═══════════════════════════════════════════════════════════════════════════


def _tf(w, db, scope='bible'):
    """글꼴을 **구역**으로 입힌다 (font.md §22 · §36).

    구역: `bible` 성경 · `prose` 문장(설명·묵상) · `list` 목록 · `meta` 딸림글 ·
          `ui` 조작. **화면이 글꼴 이름을 직접 적지 않는다.**

    ⚠ 카드처럼 **그릴 때마다 새로 만드는** 위젯은 `apply`(한 번 입히고 잊는다).
      화면에 계속 사는 위젯은 `_tfr` 로 **등록**해야 설정을 바꿀 때 따라온다.
    """
    try:
        import theme_font
        theme_font.apply(w, db, scope)
    except Exception:
        pass


def _repaint(w):
    """동적으로 새로 만든 위젯에 화면색을 입힌다 (2026-08-17).

    ★ **「표준테마가 전혀 작동하지 않는다」의 원인이 이것이었다.** `ui_theme.paint` 는
      탭을 열 때 한 번 돈다(`user_main._paint_new_tab`). 그런데 렌즈 카드·질문·댓글은
      **노드를 클릭할 때** 새로 만들어진다 — 그 위젯들은 아무도 안 칠했다.
      실측: 검정 테마에서 카드 영역에 밝은 바탕 72개가 그대로 남았다.
    ⚠ 내 측정이 이것을 놓쳤던 이유 — 「테마 전환 + paint 직후」만 쟀다. 사용자의
      실제 흐름은 「테마 저장 → 앱 켬 → 렌즈 클릭 → 노드 클릭」이다.
      **동적으로 위젯을 만드는 화면은 만든 직후 스스로 paint 를 불러야 한다.**
    """
    try:
        import ui_theme
        if ui_theme.current() != ui_theme.DEFAULT:
            ui_theme.paint(w)
    except Exception:
        pass


def _tfr(w, db, scope='prose'):
    """오래 사는 위젯 — **등록**한다. `reapply_all()` 이 설정 변경 때 다시 입힌다."""
    try:
        import theme_font
        theme_font.register(w, db, scope)
    except Exception:
        pass

class LensView(ttk.Frame):
    """렌즈묵상 메인 뷰: 좌측 카테고리 트리 + 우측 계단식 (상단 컨테이너 상세 / 하단 노드)."""

    def __init__(self, parent, db_path,
                 lang_getter=None, version_getter=None,
                 on_verse_navigate=None, on_route_jump=None):
        super().__init__(parent)
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.version_getter = version_getter or (lambda: 'KRV')
        self.on_verse_navigate = on_verse_navigate  # 향후 Step 3에서 사용
        self.on_route_jump = on_route_jump          # 묵상경로 「다음 걸음」

        self._cat_tree_data: dict = {}  # iid → {'kind': 'cat'/'cont', 'id': X, ...}
        self._curr_container_id: int | None = None
        self._curr_container_source: str | None = None  # [Phase 2-F] 'SYS' | 'USER'
        self._curr_node_id: int | None = None
        self._curr_node_source: str | None = None       # [Phase 2-F] 'SYS' | 'USER'
        self._node_data: dict = {}  # iid → {'node_id': X, ...}
        self._book_name_cache: dict = {}  # (bcode, lang) → short_name
        # [Step 4 → Turn 3] 마커 캐시 (set of (source, container_id) 튜플)
        self._fav_container_ids: set = set()   # {('SYS',1), ('USER',2), ...}
        self._read_container_ids: set = set()

        self._build()
        self.refresh()

    # ── 표시 언어 ────────────────────────────────────────────────────────────

    _disp_lang_code = None      # 상단 띠의 콤보가 정해 준다

    def _lang(self):
        """이 화면의 글을 어느 언어로 볼까 (2026-08-14).

        ⚠ 성경 본문은 여기 안 걸린다 — 그쪽은 **역본**이 정한다.
        """
        return (self._disp_lang_code
                or (self.lang_getter() if callable(self.lang_getter) else 'KO')
                or 'KO')

    def set_display_lang(self, lang):
        """상단 띠의 표시 언어 콤보가 부른다."""
        lg = (lang or '').upper()
        if lg == (self._disp_lang_code or ''):
            return
        self._disp_lang_code = lg
        try:
            self.refresh()
            if self._curr_container_id is not None:
                self.select_container(self._curr_container_id)
        except Exception as e:
            print('[lens lang] %s' % e)

    # ── UI 구성 ──────────────────────────────────────────────────────────────

    def _build(self):
        # 메인 좌·우 분할 — 접기 토글(◀)이 쓰도록 참조를 남긴다
        main_pw = tk.PanedWindow(self, orient='horizontal', sashwidth=4, bg='#D5DBDB')
        main_pw.pack(fill='both', expand=True)
        self._main_pw = main_pw

        left = self._build_left()
        main_pw.add(left, width=240)
        self._left_f = left

        right = self._build_right()
        main_pw.add(right, minsize=400)
        self._right_f = right

        # 직전에 접어 두었으면 접힌 채로 연다 (2026-08-17 사용자 지시 A안)
        if self._lens_tree_hidden():
            main_pw.forget(left)
            self._sync_tree_toggle()

    def _build_left(self):
        """좌측: 카테고리 + 컨테이너 트리."""
        f = tk.Frame(self, bg='#FDFEFE')

        # ⚠ 「렌즈 카테고리」 머리글을 없앴다 (2026-08-14 사용자 지시).
        #   목록을 보면 아는 것을 한 줄 더 쓰고 있었다 — 묵상플랜 탭에서 「전체플랜」
        #   라벨을 없앤 것과 같은 이유다.

        # 트리
        wrap = tk.Frame(f, bg='#FDFEFE')
        wrap.pack(fill='both', expand=True)
        vsb = ttk.Scrollbar(wrap, orient='vertical')
        vsb.pack(side='right', fill='y')

        # 글꼴·행높이·태그는 `apply_font()` 가 정한다 — 통합 폰트를 바꾸면
        #   `theme_font.reapply_all → _poke` 가 그 이름을 찾아 다시 부른다.
        self.apply_font()

        self._cat_tv = ttk.Treeview(wrap, show='tree', selectmode='browse',
                                     style='Lens.Treeview',
                                     yscrollcommand=vsb.set)
        vsb.config(command=self._cat_tv.yview)
        self._cat_tv.pack(side='left', fill='both', expand=True)
        # 태그 **색**만 여기서 — 글꼴(크기 포함)은 `apply_font()` 가 잡는다.
        #   ⚠ 태그에 font 를 박으면 스타일을 이겨서 통합 폰트가 안 닿는다(§25 함정).
        #   ⚠ 색은 플랜 트리(Plan.Treeview)와 같게 — 묶음(cat)만 #1A5276,
        #     렌즈 줄은 기본색. 내 렌즈는 ◈ 표식이 이미 가른다(2026-08-18
        #     사용자 「푸른색 계열 — 표준서식을 따르지 않는다」).
        self._cat_tv.tag_configure('cat',  foreground='#1A5276')
        self._cat_tv.tag_configure('empty', foreground='#95A5A6')
        self.apply_font()          # 태그가 생긴 뒤 한 번 더 — 태그 글꼴을 입힌다
        self._cat_tv.bind('<<TreeviewSelect>>', self._on_cat_tree_select)

        return f

    def _build_right(self):
        """우측: 상단(컨테이너 상세) + 하단(노드 목록 + 노드 상세 placeholder)."""
        f = tk.Frame(self)

        right_pw = tk.PanedWindow(f, orient='vertical', sashwidth=4, bg='#D5DBDB')
        right_pw.pack(fill='both', expand=True)

        # ── 우측 상단: 컨테이너 상세 ───────────────────────────────────────
        top = tk.Frame(right_pw, bg='#FDFEFE')
        right_pw.add(top, height=160, minsize=80)

        top_header = tk.Frame(top, bg='#EBF5FB')
        top_header.pack(fill='x')
        # ★ **단추가 맨 왼쪽, 진짜 단추** (2026-08-17 사용자 지시 「다른 묵상플랜과
        #   동일하게 디자인 통일. 위치도 왼쪽으로 — 찾기 힘들다」).
        #   플랜 상세 상단 띠(`_PlanDetailFrame._btn_start`)와 같은 모양이다:
        #   초록 바탕 · 흰 글자 · 왼쪽 끝. 글자 라벨이던 것을 tk.Button 으로 바꿨다.
        self._enroll_btn = tk.Button(
            top_header, text=i18n.t('PMV_START', '▶ 시작하기'), bd=0, padx=12, pady=3,
            font=('', 10, 'bold'), cursor='hand2',
            bg='#1A5276', fg='white', activebackground='#1A5276',
            activeforeground='white', command=self._toggle_enroll)
        # ★ 2026-10-13 docs/1.txt 77-2 — **렌즈 제목은 왼쪽 · 시작하기는 오른쪽**(묵상플랜 상세 띠와 같다 · 76-2).
        #   색도 플랜과 같게(형광 초록 걷음).
        self._enroll_btn.pack(side='right', padx=(6, 8), pady=4)
        self._cont_title_lbl = tk.Label(
            top_header, text=i18n.t('LENS_SELECT','(렌즈를 선택하세요)'), bg='#EBF5FB',
            font=('', 11, 'bold'), fg='#1A5276', anchor='w')
        self._cont_title_lbl.pack(side='left', padx=(8, 4), pady=6)

        # ★ **읽음 토글을 없앴다** (2026-08-16 — 사용자 물음 「읽음 표시 등 다른
        #   플랜과의 차이가 필요한지 판단하라」에 대한 판단).
        #   읽음은 등록/완료(enrollment)가 생기기 **전 시대의 자취**다 — 지금은
        #   `✓ 완료하기`가 같은 뜻을 더 정확히 담는다(언제 마쳤는지까지 남는다).
        #   손으로 눌러 둔 옛 읽음 표시는 지우지 않는다 — 트리 ✓ 마커가 **읽음 ∪ 완료**
        #   를 함께 본다(`_load_marker_sets`). 단추만 없앴다.
        # ★ **즐겨찾기 = 별표 하나** (2026-08-16 사용자 물음 「렌즈의 즐겨찾기와 다른
        #   플랜의 별표가 서로 다른가?」— **개념이 다르다**: 플랜 상세의 ☆는 묵상후보
        #   (아직 안 본 것 찜), 이것은 즐겨찾기(다시 볼 것, 나의 길 ▸ ★ 연동).
        #   개념은 갈라 두고 **모양·자리만** 다른 플랜과 맞췄다 — 제목 옆 별표 하나.
        self._fav_btn = tk.Label(
            top_header, text='☆', bg='#EBF5FB', fg='#ABB2B9',
            font=('', 13), cursor='hand2', padx=4, pady=0)
        # ★ 2026-10-13 — 렌즈(묵상플랜)는 즐겨찾기 대상에서 뺐다(사용자). 위젯은 두되 안 붙인다.
        # self._fav_btn.pack(side='left', padx=(2, 0), pady=4)
        # 「내 설명」 — sys 렌즈의 설명·이름 덮개 편집 (2026-08-26 읽기 배선.
        #   내 렌즈(USER)는 My Lens 가 맡으므로 잠근다)
        self._ov_edit_btn = tk.Button(
            top_header, text=i18n.t('OE_BTN', 'My Edit'),
            command=self._open_cont_overlay_editor, **_flat())
        # ★ 2026-10-15 88-9 「My Edit : 제거」 — 만들되 안 놓는다(사용자 모드 콤보 [수정하기]가 맡는다).
        # ★ 2026-10-13 docs/1.txt 83 — **가져와서 고치기**: 배포 렌즈를 내 렌즈로 옮겨 구조·이름·설명을
        #   마음대로 고친다(원본은 안 건드린다). 가져온 내 렌즈에는 [원본 가리기][원본 표시하기].
        self._copy_btn = tk.Button(
            top_header, text=i18n.t('CO_LENS_COPY', '내 렌즈로 복사하여 수정하기'),
            command=self._copy_lens, **_flat())
        self._orig_f = tk.Frame(top_header, bg='#EBF5FB')
        self._orig_btns = {}
        for _hv, _k, _t in ((True, 'CO_HIDE', '원본 가리기'), (False, 'CO_SHOW', '원본 표시하기')):
            _b = tk.Button(self._orig_f, text=i18n.t(_k, _t), command=lambda h=_hv: self._set_orig(h), **_flat())
            _b.pack(side='left', padx=(0, 2))
            self._orig_btns[_hv] = _b
        self._fav_btn.bind('<Button-1>', lambda _e: self._toggle_fav_container())
        self._read_btn = None      # 옛 이름을 참조하는 코드가 있어 None 으로 남긴다

        # ★ [연결] 단추를 걷었다 (2026-10-13 docs/1.txt 77-1 「My Edit 와 중복」) · [연결된 자산 보기] 도 걷고
        #   자산은 있으면 늘 펼친다(77-1 · 76-6 과 같은 규칙).
        try:
            from asset_strip import AssetStrip
            self._assets = AssetStrip(
                top, self.db_path, lang_getter=self.lang_getter,
                on_jump=lambda k, i: (self.on_link_open(k, i)
                                      if callable(getattr(self, 'on_link_open',
                                                          None)) else None))
        except Exception as _e:
            print('[lens assets] %s' % _e)
            self._assets = None
        self._assets_n = 0

        # ★ **[등록하기] / [완료]** (2026-08-15 사용자 지시).
        #   렌즈가 묵상플랜이 됐으므로 다른 세 서브탭과 **같은 표**를 쓴다
        #   (`user_plan_enrollment`). 등록하면 진행중 콤보에 `[렌즈]` 로 뜬다.
        #   ⚠ 날짜(일차)는 다루지 않는다 — 렌즈는 `duration_days=1` 이다.

        # ★ **관리 요소를 걷어냈다 (2026-08-15 사용자 지시).**
        #   `[+ My Lens][이름][삭제]` 가 읽는 화면 머리에 붙어 있어 잘못 누르면 지워졌다.
        #   내 렌즈를 고치는 일은 **별도 관리 팝업**이 맡는다.
        #   ⚠ 기능(`_add_my_lens` 등)은 지우지 않았다 — 그 팝업이 그대로 부른다.
        self._set_toggle_buttons_enabled(False)

        desc_wrap = tk.Frame(top, bg='#FDFEFE')
        desc_wrap.pack(fill='both', expand=True, padx=8, pady=(4, 8))
        self._desc_wrap = desc_wrap
        self._cont_desc_txt = tk.Text(desc_wrap, height=4, wrap='word',
                                       font=('', 9),
                                       bg='#FBFCFC', relief='flat', bd=1)
        self._cont_desc_txt.pack(fill='both', expand=True)
        self._cont_desc_txt.insert('1.0', '')
        self._cont_desc_txt.config(state='disabled')
        _tfr(self._cont_desc_txt, self.db_path, 'prose')   # 읽는 본문 (§36)

        # ── 우측 하단: 노드 목록(좌) + 노드 상세(우) ────────────────────────
        bottom = tk.Frame(right_pw)
        right_pw.add(bottom, minsize=200)

        bot_pw = tk.PanedWindow(bottom, orient='horizontal', sashwidth=4, bg='#D5DBDB')
        bot_pw.pack(fill='both', expand=True)

        # 하단 좌: 노드 목록 — 폭은 이름 실측 기준으로 슬림하게 (2026-08-17 C안,
        #   240 → 190. 본문이 그만큼 넓어진다)
        node_f = tk.Frame(bot_pw, bg='#FDFEFE')
        bot_pw.add(node_f, width=190, minsize=140)

        nh = tk.Frame(node_f, bg='#FEF9E7')
        nh.pack(fill='x')
        # ◀ 렌즈트리 접기 — 누르면 왼쪽 렌즈트리 칸이 통째로 사라져 본문이
        #   넓어진다(A안). ▶ 로 복원. 노드 목차는 늘 보인다(사용자 요구).
        #   ⚠ 자동 접기(B안)는 하지 않는다 — 「렌즈트리를 연습삼아 누를 때마다
        #     덮는 문제가 크다」(2026-08-17 사용자).
        self._tree_toggle_btn = tk.Button(
            nh, text='◀', bd=0, padx=6, cursor='hand2',
            command=self._toggle_lens_tree)
        self._tree_toggle_btn.pack(side='left', padx=(4, 0), pady=2)
        tk.Label(nh, text=i18n.t('LENS_NODELIST','노드 목록'), bg='#FEF9E7',
                 font=('', 9, 'bold'), fg='#7D6608'
                 ).pack(side='left', padx=6, pady=4)

        # ★ 노드 편집 도구도 걷어냈다 (2026-08-15) — 관리 팝업으로 옮긴다.

        nw = tk.Frame(node_f, bg='#FDFEFE')
        nw.pack(fill='both', expand=True)
        nvsb = ttk.Scrollbar(nw, orient='vertical')
        nvsb.pack(side='right', fill='y')
        self._node_tv = ttk.Treeview(nw, show='tree', selectmode='browse',
                                      style='Lens.Treeview',
                                      yscrollcommand=nvsb.set)
        nvsb.config(command=self._node_tv.yview)
        self._node_tv.pack(side='left', fill='both', expand=True)
        # 태그 **색**만 — 글꼴은 `apply_font()` 가 잡는다. 태그에 font 를 박으면
        #   스타일을 이겨서 통합 폰트가 영영 안 닿는다(§25 함정 — 실제로 그랬다).
        self._node_tv.tag_configure('empty', foreground='#95A5A6')
        self._node_tv.bind('<<TreeviewSelect>>', self._on_node_select)
        self.apply_font()          # 태그가 생긴 뒤 — 노드 태그에도 글꼴을 입힌다

        # 하단 우: 노드 상세 (Step 2에서 구현)
        self._node_detail_f = tk.Frame(bot_pw, bg='#FAFAFA')
        bot_pw.add(self._node_detail_f, minsize=300)
        self._node_placeholder = tk.Label(
            self._node_detail_f,
            text=i18n.t('LENS_NODE_HINT', '노드를 선택하면 연결된 구절 세트가 표시됩니다.'),
            bg='#FAFAFA', fg='#566573', font=('', 10), justify='center')
        self._node_placeholder.pack(expand=True)

        return f

    # ── 데이터 로딩 ──────────────────────────────────────────────────────────

    def refresh(self):
        self._load_marker_sets()
        self._load_category_tree()
        self._clear_container_detail()
        self._clear_node_list()

    # ── [Step 4] 마커 (★ 즐겨찾기 / ● 읽음) ─────────────────────────────────

    def _load_marker_sets(self):
        """user_favorite (CONTAINER) + user_config (READ_LENS_CONTAINERS) 로드.
        Phase 2-F: SYS/USER 구분 — source_code 컬럼 활용. NULL은 SYS로 간주."""
        import json
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            c.execute('''SELECT target_id, COALESCE(source_code,'SYS')
                          FROM user_favorite
                         WHERE fav_type='CONTAINER'
                           AND COALESCE(record_status,'LIVE')='LIVE' ''')
            self._fav_container_ids = {
                (src, tid) for tid, src in c.fetchall() if tid is not None}

            c.execute('''SELECT config_val FROM user_config
                          WHERE config_key='READ_LENS_CONTAINERS' LIMIT 1''')
            row = c.fetchone()
            self._read_container_ids = set()
            if row and row[0]:
                try:
                    raw = json.loads(row[0])
                    if isinstance(raw, list):
                        for item in raw:
                            # 호환: int (구버전 SYS) 또는 [src, id] 또는 (src, id)
                            if isinstance(item, int):
                                self._read_container_ids.add(('SYS', item))
                            elif isinstance(item, (list, tuple)) and len(item) == 2:
                                src, tid = item
                                if isinstance(tid, int) and src in ('SYS', 'USER'):
                                    self._read_container_ids.add((src, tid))
                except Exception:
                    pass

            # ★ **완료한 렌즈도 ✓ 다** (2026-08-16 — 읽음 토글을 없앤 판단의 짝).
            #   읽음은 옛 손 표시고, 완료(enrollment COMPLETED)가 지금의 그 뜻이다.
            #   트리 마커는 **읽음 ∪ 완료**를 본다 — 옛 표시를 지우지 않으면서
            #   새 완료가 저절로 ✓ 로 나타난다.
            try:
                for code, in c.execute(
                        """SELECT DISTINCT p.plan_code FROM user_plan_enrollment e
                            JOIN sys_bible_plan p ON p.plan_id=e.plan_id
                           WHERE e.enrollment_status='COMPLETED'
                             AND e.record_status='LIVE'
                             AND p.plan_code LIKE 'LENS_%'"""):
                    try:
                        self._read_container_ids.add(('SYS', int(code.split('_')[1])))
                    except (ValueError, IndexError):
                        pass
            except Exception as e2:
                print('[lens marker] %s' % e2)
        finally:
            conn.close()

    def _save_read_set(self):
        """user_config['READ_LENS_CONTAINERS'] 저장 — [[src,id], ...] 형태."""
        import json
        val = json.dumps(sorted([list(k) for k in self._read_container_ids]))
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            c.execute("SELECT 1 FROM user_config WHERE config_key='READ_LENS_CONTAINERS' LIMIT 1")
            if c.fetchone():
                c.execute("UPDATE user_config SET config_val=? "
                           "WHERE config_key='READ_LENS_CONTAINERS'", (val,))
            else:
                c.execute("INSERT INTO user_config (config_key, config_val) "
                           "VALUES ('READ_LENS_CONTAINERS', ?)", (val,))
            conn.commit()
        finally:
            conn.close()

    # ── 등록·완료·이력 (렌즈 = 묵상플랜, 2026-08-15) ───────────────────

    def _lens_plan_id(self, cid=None):
        """그 렌즈의 플랜 id. `db_lens_plan.py --apply` 로 만들어 둔 것."""
        # ⚠ 내 렌즈(USER)는 플랜이 없다 — `db_lens_plan` 은 sys 렌즈만 만든다.
        #   사용자가 만든 렌즈까지 플랜으로 올릴지는 따로 정할 일이다.
        if (getattr(self, '_curr_container_source', 'SYS') or 'SYS') != 'SYS':
            return None
        cid = cid if cid is not None else getattr(self, '_curr_container_id', None)
        if not cid:
            return None
        try:
            with appdb.connect(self.db_path) as conn:
                r = conn.execute("SELECT plan_id FROM sys_bible_plan "
                                 "WHERE plan_code=? AND record_status='LIVE'",
                                 ('LENS_%d' % int(cid),)).fetchone()
            return r[0] if r else None
        except Exception:
            return None

    def _enroll_rows(self, pid):
        """그 렌즈의 등록 이력. 최근 것이 앞."""
        if not pid:
            return []
        try:
            with appdb.connect(self.db_path) as conn:
                return conn.execute(
                    "SELECT enrollment_id, enrollment_status, start_date, end_date "
                    "FROM user_plan_enrollment "
                    "WHERE plan_id=? AND record_status='LIVE' "
                    "ORDER BY enrollment_id DESC", (pid,)).fetchall()
        except Exception:
            return []

    def _toggle_enroll(self):
        """등록 안 했으면 등록, 진행중이면 완료로. 완료된 것은 다시 등록한다.

        ⚠ **다시 읽으면 등록 행을 새로 만든다** — 한 행을 되살리면 이력이 사라진다.
          렌즈는 짧아서 여러 번 보는 자산이라 이력이 도서보다 오히려 쓸모 있다.
        """
        cid = getattr(self, '_curr_container_id', None)
        pid = self._lens_plan_id(cid)
        if not pid:
            messagebox.showinfo(
                i18n.t('LENS_ENROLL', '＋ 등록하기'),
                i18n.t('LENS_NO_PLAN',
                       '이 렌즈는 아직 플랜으로 등록되지 않았습니다.\n'
                       '관리자가 `db_lens_plan.py --apply` 를 한 번 돌려야 합니다.'),
                parent=self)
            return
        from datetime import date
        today = date.today().isoformat()
        rows = self._enroll_rows(pid)
        active = next((r for r in rows if r[1] == 'ACTIVE'), None)
        try:
            with appdb.connect(self.db_path) as conn:
                if active:
                    conn.execute(
                        "UPDATE user_plan_enrollment SET enrollment_status='COMPLETED',"
                        " end_date=?, final_status='COMPLETED' WHERE enrollment_id=?",
                        (today, active[0]))
                else:
                    conn.execute(
                        "INSERT INTO user_plan_enrollment (plan_id, start_date,"
                        " current_day, enrollment_status, record_status) "
                        "VALUES (?,?,1,'ACTIVE','LIVE')", (pid, today))
                conn.commit()
        except Exception as e:
            messagebox.showwarning(i18n.t('PMV_START', '▶ 시작하기'), str(e), parent=self)
            return
        self._refresh_enroll_ui()
        if callable(getattr(self, 'on_enroll_changed', None)):
            try:
                self.on_enroll_changed()      # 진행중 콤보를 다시 읽게 한다
            except Exception:
                pass
        # 묵상경로 — 렌즈 완료 순간의 「다음 걸음」 추천 (2026-08-17).
        if active and self._curr_container_id:
            try:
                import plan_route
                plan_route.show_completion_popup(
                    self, self.db_path, 'LENS', self._curr_container_id,
                    lang=self._lang(),
                    on_jump=getattr(self, 'on_route_jump', None))
            except Exception as _e:
                print('[lens route done popup] %s' % _e)

    def _refresh_enroll_ui(self):
        """버튼 글자와 상단 이력 줄을 지금 상태에 맞춘다."""
        if not hasattr(self, '_enroll_btn'):
            return
        pid = self._lens_plan_id()
        rows = self._enroll_rows(pid)
        active = next((r for r in rows if r[1] == 'ACTIVE'), None)
        done = [r for r in rows if r[1] == 'COMPLETED']
        if active:
            # 진행중 → 완료 단추 (플랜 상세의 「이어서 읽기」 색과 같은 진초록 계열)
            self._enroll_btn.config(text=i18n.t('LENS_DONE', '✓ 완료하기'),
                                    bg='#1A5276', fg='white', state='normal')
        else:
            self._enroll_btn.config(text=i18n.t('PMV_START', '▶ 시작하기'),
                                    bg='#1A5276', fg='white', state='normal')
        # 이력 줄 — 완료한 적이 있을 때만 보인다
        if getattr(self, '_hist_lbl', None) is None:
            self._hist_lbl = tk.Label(
                self._cont_desc_txt.master, text='', bg='#FDFEFE', anchor='w',
                fg='#7F8C8D', font=('', 8))
            _repaint(self._hist_lbl)   # 늦게 태어나는 위젯 — 만든 즉시 칠한다
        if done:
            dates = ', '.join(r[3] or '?' for r in done[:5])
            more = '' if len(done) <= 5 else ' 외 %d회' % (len(done) - 5)
            self._hist_lbl.config(text=i18n.t('LENS_HIST', '완료 %d회  ·  %s%s')
                                  % (len(done), dates, more))
            try:
                self._hist_lbl.pack(fill='x', before=self._cont_desc_txt)
            except Exception:
                self._hist_lbl.pack(fill='x')
        else:
            self._hist_lbl.pack_forget()

    def _edit_lens_tags(self):
        """[연결] — 이 렌즈에서 다른 자산으로 잇는다 (2026-08-21).

        ★ **[태그] 단추를 대체한다**(사용자 확정 — 0.txt 3번). 태그는 그
          창 안에 갈래 하나로 들어가 있으므로 잃는 것이 없다.
        ⚠ 사용자 렌즈는 `target_type='ULENS'` 로 갈라 둔다(sys 렌즈와
          번호가 겹친다). `link_picker` 는 두 이름을 다 받는다.
        ⚠ 함수 이름은 그대로 두었다 — 부르는 곳이 여럿이다."""
        cid = self._curr_container_id
        if not cid:
            import tag_picker
            tag_picker.need_target(self, i18n.t('TAG_NEED_LENS', '렌즈'))
            return
        src = self._curr_container_source or 'SYS'
        tt = 'LENS' if src == 'SYS' else 'ULENS'
        try:
            import link_picker
            link_picker.open_picker(
                self, self.db_path, tt, cid,
                lang_getter=(self.lang_getter if callable(
                    getattr(self, 'lang_getter', None)) else None),
                on_open=(self.on_link_open if callable(
                    getattr(self, 'on_link_open', None)) else None),
                # ★ 넣거나 뺄 때마다 태그 칩을 곧바로 되그린다 — 창을 닫기
                #   전에 실제 화면이 바뀌는 것을 볼 수 있어야 한다(사용자 지시).
                on_saved=lambda: self._sync_lens_tags(cid, src))
        except Exception as e:
            print(f'[lens link] {e}')

    def _toggle_fav_container(self):
        """★ 즐겨찾기 토글. source_code로 SYS/USER 구분."""
        cid = self._curr_container_id
        src = self._curr_container_source or 'SYS'
        if not cid:
            return
        key = (src, cid)
        name = None
        for d in self._cat_tree_data.values():
            if (d.get('kind') == 'cont' and d.get('unit_id') == cid
                    and d.get('source') == src):
                name = d.get('name')
                break

        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            if key in self._fav_container_ids:
                # 해제
                c.execute('''UPDATE user_favorite SET record_status='HIDE'
                              WHERE fav_type='CONTAINER' AND target_id=?
                                AND COALESCE(source_code,'SYS')=?
                                AND COALESCE(record_status,'LIVE')='LIVE' ''',
                          (cid, src))
                self._fav_container_ids.discard(key)
            else:
                # 같은 (src, cid)의 HIDE 행 복구 또는 신규 INSERT
                row = c.execute('''SELECT fav_id FROM user_favorite
                                    WHERE fav_type='CONTAINER' AND target_id=?
                                      AND COALESCE(source_code,'SYS')=? LIMIT 1''',
                                  (cid, src)).fetchone()
                if row:
                    c.execute("UPDATE user_favorite SET record_status='LIVE' "
                               "WHERE fav_id=?", (row[0],))
                else:
                    label = ('[My] ' if src == 'USER' else '') + (name or f'렌즈 #{cid}')
                    c.execute('''INSERT INTO user_favorite
                                  (fav_type, target_id, source_code, label, record_status)
                                  VALUES ('CONTAINER', ?, ?, ?, 'LIVE')''',
                              (cid, src, label))
                self._fav_container_ids.add(key)
            conn.commit()
        finally:
            conn.close()
        self._refresh_toggle_buttons()
        self._refresh_tree_markers()

    def _toggle_read_container(self):
        """● 읽음 토글 — (source, cid) 튜플."""
        cid = self._curr_container_id
        src = self._curr_container_source or 'SYS'
        if not cid:
            return
        key = (src, cid)
        if key in self._read_container_ids:
            self._read_container_ids.discard(key)
        else:
            self._read_container_ids.add(key)
        self._save_read_set()
        self._refresh_toggle_buttons()
        self._refresh_tree_markers()

    def _set_toggle_buttons_enabled(self, enabled: bool):
        """토글 버튼 활성/비활성 시각 처리."""
        if not enabled:
            self._fav_btn.config(text='☆', fg='#BDC3C7', cursor='arrow')
            if hasattr(self, '_enroll_btn'):
                self._enroll_btn.config(state='disabled')

    def _refresh_toggle_buttons(self):
        """현재 컨테이너 상태에 맞춰 토글 버튼 표시 갱신."""
        try:
            self._refresh_enroll_ui()      # 등록/완료 버튼·이력 줄도 함께 (2026-08-15)
        except Exception:
            pass
        cid = self._curr_container_id
        src = self._curr_container_source or 'SYS'
        if not cid:
            self._set_toggle_buttons_enabled(False)
            return
        key = (src, cid)
        if key in self._fav_container_ids:
            self._fav_btn.config(text='★', fg='#F39C12', cursor='hand2')
        else:
            self._fav_btn.config(text='☆', fg='#ABB2B9', cursor='hand2')

    def _refresh_tree_markers(self):
        """좌측 트리 컨테이너 행의 prefix 마커만 갱신."""
        self._any_fav = bool(self._fav_container_ids)
        self._any_my = any(d.get('source') == 'USER'
                           for d in self._cat_tree_data.values()
                           if d.get('kind') == 'cont')
        for iid, d in self._cat_tree_data.items():
            if d.get('kind') != 'cont':
                continue
            cid = d.get('unit_id')
            name = d.get('name', f'#{cid}')
            src = d.get('source', 'SYS')
            self._cat_tv.item(iid, text=self._format_cont_text(cid, name, src))

    def _format_cont_text(self, container_id: int, name: str,
                           source: str = 'SYS') -> str:
        """컨테이너 트리 행 텍스트 — 표식 + 이름. (source, id) 튜플 검사.

        ★ 표식은 둘뿐이다 (2026-08-17 사용자 지시):
            ★ 즐겨찾기 · ◈ 내가 만든 것.
          **✓(완료)는 뺐다** — 「다른 묵상플랜에는 없던 것이다. 삭제하라.
          완료이력을 입력한 것으로 충분하다.」 완료는 상세의 이력 줄이 말한다.
        ★ ◈ 는 **맑은 고딕이 실제로 가진 글리프**다. 연필류(✎✏✒)는 전부 없어서
          Segoe 폴백으로 그려졌고 그래서 「나뭇잎」처럼 보였다(cmap 실측).
        ★ **표식이 있는 줄이 하나라도 있을 때만 그 자리를 만든다** — 늘 자리를 잡으면
          트리가 통째로 오른쪽으로 밀린다(「인덴트가 더 깊어졌다」의 한 원인).
          폭은 실측 공백(`_measure_marker_pads`) — 비례폭이라 문자 수로는 안 맞는다.
        """
        pads = getattr(self, '_marker_pads', None) or self._measure_marker_pads()
        key = (source, container_id)
        out = ''
        if getattr(self, '_any_fav', False):
            # 표식 매트릭스(2026-08-18 `0.txt` 1번): 즐겨찾기 글리프가 읽음
            #   상태를 따른다 — ★ 읽음∧다시 · ♥ 안 읽었는데 찜.
            #   상태 단독 표식(○●)은 렌즈에서 안 그린다 — 「완료이력으로
            #   충분하다」(2026-08-17 사용자, ✓ 삭제 지시)를 존중.
            if key in self._fav_container_ids:
                out += ('★' if key in getattr(self, '_read_container_ids', ())
                        else '♥') + ' '
            else:
                out += pads['★'] + ' '
        if getattr(self, '_any_my', False):
            out += ('◈' if source == 'USER' else pads['◈']) + ' '
        return out + name

    def apply_font(self):
        """렌즈·노드 트리 글꼴을 통합 폰트 「목록」 역할로 (2026-08-17 사용자 지적
        「트리 서식이 폰트 수정에 반응하지 않는다」).

        ⚠ **이름이 `apply_font` 여야 한다** — `theme_font.reapply_all → _poke` 가
          그 이름을 찾아 부른다. 묵상플랜 트리(`_apply_list_font`)와 같은 장치인데
          렌즈 트리에만 없어서 만들 때 박힌 9pt 로 굳어 있었다.
        ⚠ 표식 폭(`_marker_pads`)도 글꼴에 달렸다 — 함께 다시 재고 트리를 다시 쓴다.
        """
        try:
            import theme_font
            f = theme_font.list_style('Lens.Treeview', self.db_path,
                                      heading=False)
            ttk.Style().configure('Lens.Treeview', background='#FDFEFE')
            for tv, tags in ((getattr(self, '_cat_tv', None),
                              (('cat', ('bold',)), ('cont', ()),
                               ('user_cont', ()), ('empty', ('italic',)))),
                             (getattr(self, '_node_tv', None),
                              (('node', ()), ('empty', ('italic',))))):
                if tv is None:
                    continue
                for tag, extra in tags:
                    tv.tag_configure(tag, font=f + tuple(extra))
            # 표식 폭은 글꼴을 따라간다 — 무효화하고 다시 잰다
            self._marker_pads = None
            if getattr(self, '_cat_tree_data', None):
                self._refresh_tree_markers()
        except Exception as e:
            print('[lens font] %s' % e)

    def _measure_marker_pads(self):
        """표식 글자와 **같은 폭**의 공백을 실측으로 만든다.

        ⚠ 비례폭 글꼴에서 ★ 와 공백 두 칸은 폭이 다르다 — 문자 수로 맞추면
          이름 시작이 도로 흔들린다(플랜 트리 `_wish_pad` 와 같은 함정).
        """
        try:
            from tkinter import font as tkf
            # ⚠ **트리 글꼴로 잰다** — TkDefaultFont 로 재면 통합 폰트에서 크기를
            #   바꿨을 때 표식과 공백의 폭이 어긋난다(2026-08-17).
            try:
                import theme_font
                d = theme_font.resolve(self.db_path, 'list')
                fo = tkf.Font(family=d['family'], size=int(d['size']))
            except Exception:
                fo = tkf.nametofont('TkDefaultFont')
            pads = {}
            for ch in ('★', '◈'):
                w = fo.measure(ch)
                best, diff = ' ', 10 ** 9
                for k in range(1, 8):
                    d = abs(fo.measure(' ' * k) - w)
                    if d < diff:
                        best, diff = ' ' * k, d
                pads[ch] = best
            self._marker_pads = pads
            return pads
        except Exception:
            return {'★': '  ', '◈': '  '}

    def _load_category_tree(self):
        """LENS 카테고리 + SYS 컨테이너 + USER 컨테이너 통합 표시 (Phase 2-F)."""
        self._cat_tv.delete(*self._cat_tv.get_children())
        self._cat_tree_data = {}

        lang = self._lang()
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()

            # 1. 카테고리 (LENS scope, LIVE만)
            c.execute('''
                SELECT pc.cat_id, pc.sort_order,
                       (SELECT contents FROM sys_text_asset
                          WHERE text_type='PLAN_CAT_NAME' AND clicked_id=pc.cat_id
                            AND UPPER(lang_code)=UPPER(?) AND record_status='LIVE' LIMIT 1) AS name_loc,
                       (SELECT contents FROM sys_text_asset
                          WHERE text_type='PLAN_CAT_NAME' AND clicked_id=pc.cat_id
                            AND lang_code='EN' AND record_status='LIVE' LIMIT 1) AS name_en
                  FROM sys_plan_category pc
                 WHERE pc.scope='LENS' AND pc.record_status='LIVE'
              ORDER BY pc.sort_order
            ''', (lang,))
            cats = c.fetchall()

            # 2-A. SYS 컨테이너 (LIVE만)
            #   ★ 렌즈 이름 다국어 (2026-08-17) — 표시 = CONT_NAME(사용자 언어)
            #     → unit_name_sid 폴백. 원본(멱등 열쇠)은 여전히 unit_name_sid.
            c.execute('''
                SELECT u.sys_unit_id, u.cat_id,
                       COALESCE((SELECT contents FROM sys_text_asset
                                  WHERE text_type='CONT_NAME'
                                    AND clicked_id=u.sys_unit_id
                                    AND UPPER(lang_code)=UPPER(?)
                                    AND COALESCE(record_status,'LIVE')='LIVE'
                                  LIMIT 1), u.unit_name_sid)
                  FROM sys_unit_asset u
                  JOIN sys_plan_category pc ON pc.cat_id = u.cat_id
                 WHERE u.unit_type='CONTAINER'
                   AND pc.scope='LENS'
                   AND COALESCE(u.record_status, 'LIVE') = 'LIVE'
                   -- ★ 마디가 하나도 없는 렌즈는 안 그린다 (§0-1 빈 서랍 금지)
                   --   ⚠ 아직 안 채운 껍데기가 목록에 뜨면 고장으로 읽힌다.
                   --     카테고리가 비면 「(렌즈 없음)」 이 그 말을 대신한다.
                   AND EXISTS (SELECT 1 FROM sys_link_asset l
                                WHERE l.link_type='CONT_NODE'
                                  AND l.clicked_id = u.sys_unit_id
                                  AND COALESCE(l.record_status,'LIVE')='LIVE')
              ORDER BY u.sort_order, u.sys_unit_id
            ''', (lang,))
            sys_by_cat: dict = {}
            # ★ 2026-10-13 docs/1.txt 83 — 내 렌즈로 가져와 「원본 가리기」를 고른 원본은 안 그린다
            try:
                import copy_own as _co
                _hid = _co.hidden_sys_ids(conn, 'LENS')
            except Exception:
                _hid = set()
            for unit_id, cat_id, name_sid in c.fetchall():
                if unit_id in _hid:
                    continue
                # ★ 렌즈 이름 덮개 (2026-08-26) — 내가 바꾼 이름이 이긴다.
                #   가림(HIDE)은 이름에는 뜻이 없다 — 기본 이름 그대로.
                try:
                    import overlay as _ov
                    ov = _ov.text_override(c, 'CONT_NAME', unit_id, lang, '')
                    if ov is not None and ov[0] != 'HIDE' and (ov[1][1] or '').strip():
                        name_sid = ov[1][1].strip()
                except Exception:
                    pass
                sys_by_cat.setdefault(cat_id, []).append({
                    'unit_id': unit_id, 'source': 'SYS',
                    'name': name_sid or f'(이름 없음 #{unit_id})'})

            # 2-B. USER 컨테이너 (LIVE만, My Lens) — Phase 2-F
            #   ★ cat_id 가 NULL 이면 「나의 렌즈」(사용자 전용 카테고리) 소속
            #     (2026-08-17 의견서 7 채택 — sys 카테고리 안에도 넣을 수 있고,
            #      어디에도 안 넣은 것은 여기 모인다). LEFT JOIN 이라야 NULL 이 산다.
            c.execute('''
                SELECT u.user_unit_id, u.cat_id, u.unit_name_sid
                  FROM user_unit_asset u
                  LEFT JOIN sys_plan_category pc ON pc.cat_id = u.cat_id
                 WHERE u.unit_type='CONTAINER'
                   AND (u.cat_id IS NULL
                        OR (pc.scope='LENS' AND pc.record_status='LIVE'))
                   AND COALESCE(u.record_status, 'LIVE') = 'LIVE'
              ORDER BY u.sort_order, u.user_unit_id
            ''')
            user_by_cat: dict = {}
            for unit_id, cat_id, name_sid in c.fetchall():
                user_by_cat.setdefault(cat_id, []).append({
                    'unit_id': unit_id, 'source': 'USER',
                    'name': name_sid or f'(이름 없음 #{unit_id})'})

            # 표식 자리 — **있는 줄이 하나라도 있을 때만** 만든다 (2026-08-17)
            self._any_my = any(user_by_cat.values())
            self._any_fav = False      # 렌즈 즐겨찾기 걷음(2026-10-13) — ★/♥ 표식 자리도 없다

            # ★ 2026-10-13 docs/1.txt 77-4 — **이름이 지워진 카테고리**(이름 줄이 모두 HIDE · 실측 200 「구속사흐름」 ·
            #   2026-08-17 에 이름만 지워지고 카테고리 줄은 LIVE 로 남았다)가 「카테고리 200 (0+My1)」 로 떴다.
            #   ⇒ 이름도 렌즈도 없는 카테고리는 그리지 않고, 그 안의 **내 렌즈는 「My 렌즈」로** 보인다(데이터 불변).
            _gone = [cid for cid, _, nl, ne in cats
                     if not nl and not ne and not sys_by_cat.get(cid)]
            for cid in _gone:
                user_by_cat.setdefault(None, []).extend(user_by_cat.pop(cid, []))
            cats = [r for r in cats if r[0] not in _gone]

            # 3. 트리 빌드 — 카테고리당 SYS 컨테이너 먼저, 그 다음 USER (My Lens)
            for cat_id, _, name_loc, name_en in cats:
                display = name_loc or name_en or f'카테고리 {cat_id}'
                sys_conts = sys_by_cat.get(cat_id, [])
                user_conts = user_by_cat.get(cat_id, [])
                total_n = len(sys_conts) + len(user_conts)
                # 카운트 표시 — 옛 「0+My1」 은 무슨 뜻인지 알 수 없었다(77-4) ⇒ 「5 · 내 렌즈 1」
                cnt_disp = f'{total_n}'          # 합계 하나(2026-10-13 사용자 「내 렌즈 개수 표기 필요 없다」)
                cat_iid = f'CAT_{cat_id}'
                self._cat_tv.insert('', 'end', iid=cat_iid,
                                     text=f'{display}  ({cnt_disp})',
                                     open=True, tags=('cat',))
                self._cat_tree_data[cat_iid] = {'kind': 'cat', 'cat_id': cat_id}

                # SYS 컨테이너
                for ct in sys_conts:
                    c_iid = f'CONT_S_{ct["unit_id"]}'
                    self._cat_tv.insert(
                        cat_iid, 'end', iid=c_iid,
                        text=self._format_cont_text(ct['unit_id'], ct['name'], 'SYS'),
                        tags=('cont',))
                    self._cat_tree_data[c_iid] = {
                        'kind': 'cont', 'source': 'SYS',
                        'unit_id': ct['unit_id'], 'name': ct['name'],
                        'cat_id': cat_id}

                # USER 컨테이너 (My Lens)
                for ct in user_conts:
                    c_iid = f'CONT_U_{ct["unit_id"]}'
                    self._cat_tv.insert(
                        cat_iid, 'end', iid=c_iid,
                        text=self._format_cont_text(ct['unit_id'], ct['name'], 'USER'),
                        tags=('user_cont',))
                    self._cat_tree_data[c_iid] = {
                        'kind': 'cont', 'source': 'USER',
                        'unit_id': ct['unit_id'], 'name': ct['name'],
                        'cat_id': cat_id}

                if not sys_conts and not user_conts:
                    self._cat_tv.insert(cat_iid, 'end',
                                         text=i18n.t('LENS_NOLENS','      (렌즈 없음)'), tags=('empty',))

            # ★ 「나의 렌즈」 — 사용자 전용 카테고리 (2026-08-17 의견서 7 채택).
            #   DB 행이 아니라 화면 마디다: cat_id 없는(NULL) 사용자 렌즈의 집.
            #   늘 보인다 — 골라서 [추가]하면 여기로 들어간다.
            my_conts = user_by_cat.get(None, [])
            my_iid = 'CAT_MY'
            self._cat_tv.insert('', 'end', iid=my_iid,
                                 text='%s  (%d)' % (i18n.t('LENS_MYCAT', 'My 렌즈'),
                                                    len(my_conts)),
                                 open=True, tags=('cat',))
            self._cat_tree_data[my_iid] = {'kind': 'cat', 'cat_id': None,
                                           'is_my': True}
            for ct in my_conts:
                c_iid = f'CONT_U_{ct["unit_id"]}'
                self._cat_tv.insert(
                    my_iid, 'end', iid=c_iid,
                    text=self._format_cont_text(ct['unit_id'], ct['name'], 'USER'),
                    tags=('user_cont',))
                self._cat_tree_data[c_iid] = {
                    'kind': 'cont', 'source': 'USER',
                    'unit_id': ct['unit_id'], 'name': ct['name'],
                    'cat_id': None}
        finally:
            conn.close()
        # ★ 2026-10-15 — 줄을 끌어 차례를 바꾼다(같은 묶음 안에서 · tree_reorder)
        try:
            import tree_reorder
            tree_reorder.enable(self._cat_tv, 'TREE_ORDER_LENS', self.db_path)
            tree_reorder.apply(self._cat_tv, 'TREE_ORDER_LENS', self.db_path)
        except Exception as e:
            print('[lens reorder] %s' % e)

    def _open_cont_overlay_editor(self):
        """「내 설명」 — sys 렌즈 설명(CONT_DESC)·이름(CONT_NAME) 덮개 팝업."""
        cid = getattr(self, '_curr_container_id', None)
        src = getattr(self, '_curr_container_source', 'SYS')
        if cid and src == 'USER':
            self._open_studio(int(cid))  # 내 렌즈 = 「렌즈 구성」(노드·구절·설명문 · 83)
            return
        if not cid or src != 'SYS':
            return
        # ★ 3단계 — 주방으로(2026-08-28). 렌즈 글·구조·연결이 한 창에서 된다.
        import my_edit
        my_edit.open(self, 'LENS', int(cid),
                     on_changed=lambda _k=None:
                     self._load_container_detail(int(cid), 'SYS'))

    # ── 가져와서 고치기 (2026-10-13 docs/1.txt 83) ──────────────────────
    def _sync_copy_btns(self, container_id, source):
        """★ 2026-10-15 — 머리 줄의 [가져와 수정][원본 …] 을 걷고 띠(Font 오른쪽) 단추를 맞춘다."""
        self._bar_sync()

    # ── 띠 단추 (2026-10-15 사용자 「모든 플랜에 버튼 이름을 통일」) ────────────
    #   [수정하기] [원본 가리기][원본 표시하기] [내보내기] [가져오기] [삭제] — 묵상플랜 탭과 같은 이름·서식.
    #   배포 렌즈의 [수정하기] = 내 렌즈로 복사해서 수정(이미 있으면 그것) · 원본 옵션은 그 사본에만.
    def attach_bar(self, bar, combo=None):
        """★ 2026-10-15 88-4·9 — 단추 줄 대신 **사용자 모드 콤보**(M 왼쪽 · `plan_active_bar.ModeCombo`).
        항목 = 나의 렌즈 만들기 · 수정하기 · 가져오기 · 내보내기 · 삭제 (고른 렌즈에 맞는 것만) ·
        원본 가리기/표시하기는 배포 렌즈를 수정한 사본일 때 콤보 왼쪽 단추로."""
        from plan_active_bar import ModeCombo
        self._act_bar, self._act_combo = bar, combo
        self._mode = ModeCombo(bar, always=('new', 'import'))
        self._mode.pack()
        self._acts = self._mode.acts
        for k, cmd in (('new', self.open_my_lens), ('edit', self._bar_edit),
                       ('hide', lambda: self._set_orig(True)), ('show', lambda: self._set_orig(False)),
                       ('export', self._export_my_lens), ('import', self._import_lens_file),
                       ('delete', self._delete_my_lens)):
            self._acts[k].config(command=cmd)
        bar.bind('<Configure>', lambda _e: self.after_idle(self._fit_bar), add='+')
        self._bar_sync()

    def _bar_edit(self):
        cid = getattr(self, '_curr_container_id', None)
        if not cid:
            return
        if getattr(self, '_curr_container_source', 'SYS') == 'USER':
            self._open_studio(int(cid))
        else:
            self._copy_lens()

    def _bar_sync(self):
        acts = getattr(self, '_acts', None)
        if not acts:
            return
        cid = getattr(self, '_curr_container_id', None)
        src = getattr(self, '_curr_container_source', None) or 'SYS'
        keys = []
        if cid:
            keys = ['edit']
            if src == 'USER':
                o = None
                try:
                    import copy_own
                    with appdb.connect(self.db_path) as c:
                        o = copy_own.origin_of(c, 'LENS', int(cid))
                except Exception:
                    o = None
                if o:
                    import ui_theme
                    for hv, k in ((True, 'hide'), (False, 'show')):
                        on = (hv == o['hide'])
                        acts[k].config(relief='sunken' if on else 'flat',
                                       fg=ui_theme.C('accent') if on else ui_theme.C('fg'))
                    keys += ['hide', 'show']
                keys += ['export', 'delete']
        self._mode.place(keys)
        self.after_idle(self._fit_bar)

    def _fit_bar(self):
        """띠가 모자라면 진행중 콤보를 줄인다(묵상플랜 탭과 같은 규칙)."""
        try:
            bar, cb = self._act_bar, self._act_combo
            W = bar.winfo_width()
            if W <= 1 or cb is None:
                return
            import tkinter.font as tkf
            others = sum(w.winfo_reqwidth() + 12 for w in bar.pack_slaves() if w is not cb)
            ch = max(tkf.nametofont('TkDefaultFont').measure('0'), 6)
            want = int(max(12, min(34, (W - others - 30) / ch)))
            if int(cb.cget('width')) != want:
                cb.config(width=want)
        except Exception:
            pass

    def _copy_lens(self):
        cid = getattr(self, '_curr_container_id', None)
        if not cid or getattr(self, '_curr_container_source', 'SYS') != 'SYS':
            return
        import copy_own
        try:
            with appdb.connect(self.db_path) as c:
                uid = copy_own.copy_of(c, 'LENS', int(cid))
                fresh = uid is None
                if fresh:
                    uid, _nm = copy_own.copy_lens(c, int(cid), self._lang(), hide=True)
        except Exception as e:
            print('[lens copy] %s' % e)
            return
        self._load_category_tree()
        iid = 'CONT_U_%d' % uid
        if self._cat_tv.exists(iid):
            self._cat_tv.selection_set(iid)
            self._cat_tv.see(iid)
            self._on_cat_tree_select()
            self.after(150, lambda: self._open_studio(uid, draft=fresh))

    def _open_studio(self, user_unit_id, draft=False):
        """내 렌즈 고치기 = My Edit 「렌즈 구성」(렌즈→노드 나무 · 노드 더하기/이름/삭제 · 구절 · 설명문).
        ⚠ 옛 「렌즈 관리」 팝업(open_my_lens)은 이름만 바꿀 수 있어 가져온 렌즈를 고칠 수 없었다(사용자 지적)."""
        import my_lens_edit
        cid = int(user_unit_id)

        def _changed(*_a):
            try:
                self._load_category_tree()
                iid = 'CONT_U_%d' % cid
                if self._cat_tv.exists(iid):
                    self._cat_tv.selection_set(iid)
                    self._load_container_detail(cid, 'USER')
                    self._load_node_list(cid, 'USER')
            except Exception as e:
                print('[lens studio changed] %s' % e)
        touched = [False]
        # ⚠ 렌즈 구성 창은 하나뿐이다 — 이미 떠 있으면 그 창의 알림이 이 초안을 모른다. 그때는 초안으로 안 본다
        #   (고친 사본을 잘못 거두는 것보다 안 고친 사본이 남는 것이 낫다).
        try:
            _old = getattr(self.winfo_toplevel(), '_my_lens_studio', None)
            if _old is not None and _old.winfo_exists():
                draft = False
        except Exception:
            pass

        def _changed2(*_a):
            touched[0] = True
            _changed()
        win = my_lens_edit.open_my_lens_studio(self, self.db_path, self._lang,
                                               on_changed=_changed2 if draft else _changed, select=cid)
        # ★ 2026-10-15 88-8 — 배포 렌즈의 [수정하기]로 막 만든 사본은 **초안**이다. 한 번도 고치지 않고
        #   창을 닫으면 그 사본을 거둔다(원본은 다시 보인다). 고쳤으면 그때부터 내 렌즈다.
        #   ⚠ 렌즈 구성 창은 고칠 때마다 곧바로 저장하는 창이라, 「저장할 때 처음 생긴다」를 이렇게 맞춘다.
        if draft and win is not None:
            def _gone(e, w=win):
                if e.widget is w and not touched[0]:
                    self.after(50, lambda: self._discard_draft(cid))
            try:
                win.bind('<Destroy>', _gone, add='+')
            except Exception:
                pass

    def _set_orig(self, hide):
        cid = getattr(self, '_curr_container_id', None)
        if not cid or getattr(self, '_curr_container_source', 'SYS') != 'USER':
            return
        import copy_own
        with appdb.connect(self.db_path) as c:
            copy_own.set_hide(c, 'LENS', int(cid), bool(hide))
        self._load_category_tree()
        iid = 'CONT_U_%d' % int(cid)
        if self._cat_tv.exists(iid):
            self._cat_tv.selection_set(iid)
            self._cat_tv.see(iid)
        self._sync_copy_btns(int(cid), 'USER')

    def _sync_assets(self, container_id, source):
        """렌즈가 바뀌면 자산 판을 다시 센다 — **있으면 늘 펼친다**(77-1)."""
        if getattr(self, '_assets', None) is None:
            return
        cnt = 0
        try:
            kind = 'ULENS' if (source or 'SYS') == 'USER' else 'LENS'
            cnt = self._assets.load(kind, container_id)
        except Exception as e:
            print('[lens assets sync] %s' % e)
        self._assets_n = cnt
        if cnt:
            if not self._assets.winfo_manager():
                self._assets.pack(fill='x', before=self._desc_wrap, padx=8, pady=(0, 2))
            _repaint(self._assets)
        else:
            self._assets.pack_forget()

    def _load_container_detail(self, container_id: int, source: str = 'SYS'):
        """우측 상단: 컨테이너 상세 (이름 + 설명). source에 따라 sys_*/user_* 분기."""
        # 「내 설명」은 sys 렌즈에서만 (덮개 대상 — USER 는 My Lens 몫)
        try:
            if getattr(self, '_ov_edit_btn', None):
                # 내 렌즈는 「렌즈 관리」 창으로 고친다(83 — 가져온 렌즈를 고칠 길)
                self._ov_edit_btn.config(state='normal')
        except Exception:
            pass
        self._sync_copy_btns(container_id, source)
        info = None
        for iid, d in self._cat_tree_data.items():
            if (d.get('kind') == 'cont' and d.get('unit_id') == container_id
                    and d.get('source', 'SYS') == source):
                info = d
                break

        name = (info or {}).get('name', '(이름 없음)')
        src_prefix = '◈ ' if source == 'USER' else ''   # 표식 사전(§ 기호) — [My] 잔재 정리
        self._cont_title_lbl.config(text=f'{src_prefix}{name}')
        self._sync_assets(container_id, source)

        # 설명 조회 — ★ USER 글은 **언어 필터 없음** (2026-08-17 채택 원칙)
        lang = self._lang()
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            if source == 'USER':
                # 언어 필터는 없되 **지금 언어를 먼저**(가져온 렌즈는 여러 언어를 갖는다 — 83)
                c.execute('''SELECT contents FROM user_text_asset
                              WHERE text_type='CONT_DESC' AND clicked_id=?
                                AND COALESCE(record_status,'LIVE')='LIVE'
                              ORDER BY (UPPER(lang_code)=UPPER(?)) DESC,
                                       (UPPER(lang_code)='KO') DESC LIMIT 1''',
                          (container_id, lang))
                row = c.fetchone()
            else:
                c.execute('''SELECT contents FROM sys_text_asset
                              WHERE text_type='CONT_DESC' AND clicked_id=?
                                AND UPPER(lang_code)=UPPER(?)
                                AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1''',
                          (container_id, lang))
                row = c.fetchone()
                # ★ 덮개 (2026-08-26 읽기 배선) — 내가 고친 렌즈 설명이 있으면
                #   그것을, 가렸으면 숨긴다(KO 폴백으로 되살아나면 안 된다).
                #   열쇠는 유닛 이름(overlay 참조).
                _hidden = False
                try:
                    import overlay as _ov
                    ov = _ov.text_override(c, 'CONT_DESC', container_id, lang, '')
                    if ov is not None:
                        if ov[0] == 'HIDE':
                            row, _hidden = None, True
                        else:
                            row = (ov[1][1],)
                except Exception:
                    pass
                if not row and not _hidden and lang.upper() != 'KO':
                    c.execute('''SELECT contents FROM sys_text_asset
                                  WHERE text_type='CONT_DESC' AND clicked_id=?
                                    AND UPPER(lang_code)='KO'
                                    AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1''',
                              (container_id,))
                    row = c.fetchone()
            desc = row[0] if row else '(설명 없음)'
        finally:
            conn.close()

        self._cont_desc_txt.config(state='normal')
        self._cont_desc_txt.delete('1.0', 'end')
        self._cont_desc_txt.insert('1.0', desc)
        self._cont_desc_txt.config(state='disabled')
        # [Turn 3] SYS·USER 모두 ★/● 토글 활성
        self._refresh_toggle_buttons()
        self._sync_lens_routes(container_id, source)
        self._sync_lens_tags(container_id, source)

    def _sync_lens_tags(self, container_id, source):
        """태그 칩 줄 (2026-08-18 새 태그 체계) — SYS 렌즈만, 태그 있을 때만.
        연동 태그(◈)는 클릭하면 그 엔티티(P4 주요용어)로 — 분류는 태그,
        지식은 엔티티라는 확정 규칙 그대로."""
        if getattr(self, '_tag_row_f', None) is None:
            self._tag_row_f = tk.Frame(self._route_f.master)
        for w in self._tag_row_f.winfo_children():
            w.destroy()
        tags = []
        if source == 'SYS':
            try:
                import db_tag_system
                conn = appdb.connect(self.db_path)
                try:
                    tags = db_tag_system.fetch_tags_for(
                        conn, 'LENS', container_id, self._lang())
                finally:
                    conn.close()
            except Exception as e:
                print('[lens tags] %s' % e)
        if not tags:
            self._tag_row_f.pack_forget()
            return
        for tid, name, kind, _cat, eid in tags:
            chip = tk.Label(self._tag_row_f,
                            text='# %s%s' % (name,
                                             ' ◈' if kind != 'PLAIN' else ''),
                            fg='#B7770D', font=('', 8), padx=6, pady=1)
            chip.pack(side='left', padx=(4, 2), pady=1)
            if kind == 'ENTITY' and eid and callable(
                    getattr(self, 'on_entity_jump', None)):
                chip.config(cursor='hand2')
                chip.bind('<Button-1>',
                          lambda _e, i=eid: self.on_entity_jump(i))
        if not self._tag_row_f.winfo_manager():
            self._tag_row_f.pack(fill='x',
                                 after=self._cont_title_lbl.master)

    def _sync_lens_routes(self, container_id, source):
        """묵상경로 「다음 걸음」 줄 (2026-08-17) — sys 렌즈만, 경로 있을 때만.
        플랜 상세와 같은 규칙. 점프는 user_main._route_jump(on_route_jump)."""
        if getattr(self, '_route_f', None) is None:
            self._route_f = tk.Frame(self._cont_title_lbl.master.master)
        for w in self._route_f.winfo_children():
            w.destroy()
        routes, prevs = [], []
        if source == 'SYS':
            try:
                import plan_route
                conn = appdb.connect(self.db_path)
                try:
                    routes = plan_route.routes_from(
                        conn, 'LENS', container_id, lang=self._lang())
                    prevs = plan_route.routes_to(
                        conn, 'LENS', container_id, lang=self._lang())
                finally:
                    conn.close()
            except Exception as e:
                print('[lens routes] %s' % e)
        # ★ 다음 단계가 없어도 이전 단계만으로 줄을 띄운다 (2026-08-18 지시)
        if ((not routes and not prevs)
                or not callable(getattr(self, 'on_route_jump', None))):
            self._route_f.pack_forget()
            return
        import plan_route
        if prevs:
            # ★ 이름 없이 「◀ 이전 단계」만 — 하나면 바로, 여럿이면 이름 메뉴
            back = tk.Label(self._route_f,
                            text=i18n.t('PMV_PREV_STEP', '◀ 이전 단계'),
                            fg='#1A5276', cursor='hand2',
                            font=('', 8, 'underline'))
            back.pack(side='left', padx=(4, 12))
            back.bind('<Button-1>',
                      lambda e, pv=prevs:
                      plan_route.prev_click(e, pv, self.on_route_jump))
        if routes:
            tk.Label(self._route_f, text=i18n.t('PMV_NEXT_STEP', '다음 단계:'),
                     fg='#7F8C8D', font=('', 8)).pack(side='left', padx=(4, 4))
            for r in routes:
                lbl = '%s (%s)' % (
                    r['label'],
                    plan_route.KIND_LABEL.get(r['kind'], r['kind']))
                link = tk.Label(self._route_f, text=lbl, fg='#1A5276',
                                cursor='hand2', font=('', 8, 'underline'))
                link.pack(side='left', padx=(0, 8))
                link.bind('<Button-1>',
                          lambda _e, k=r['kind'], i=r['id']:
                          self.on_route_jump(k, i))
        if not self._route_f.winfo_manager():
            self._route_f.pack(fill='x',
                               after=self._cont_title_lbl.master)

    def _clear_container_detail(self):
        self._cont_title_lbl.config(text=i18n.t('LENS_SELECT','(렌즈를 선택하세요)'))
        self._cont_desc_txt.config(state='normal')
        self._cont_desc_txt.delete('1.0', 'end')
        self._cont_desc_txt.config(state='disabled')
        # [Step 4] 토글 비활성
        self._set_toggle_buttons_enabled(False)
        # [Phase 2-F Turn 2] My Lens 편집 도구 비활성
        self._set_my_lens_tools(add=False, rename=False, delete=False)

    def _load_node_list(self, container_id: int, source: str = 'SYS'):
        """우측 하단 좌: 컨테이너에 연결된 노드 목록. source 분기."""
        self._node_tv.delete(*self._node_tv.get_children())
        self._node_data = {}

        link_tbl = 'user_link_asset' if source == 'USER' else 'sys_link_asset'
        unit_tbl = 'user_unit_asset' if source == 'USER' else 'sys_unit_asset'
        unit_pk = 'user_unit_id' if source == 'USER' else 'sys_unit_id'

        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            # ★ 노드 이름 다국어 (2026-09-18) — 렌즈 이름과 **같은 비대칭**:
            #   KO 원본은 `unit_name_sid`(멱등 열쇠)이고 타 언어는
            #   `sys_text_asset('NODE_NAME')` 행이 덮는다. 없으면 폴백.
            #   ⚠ user 노드는 sys 표에 글이 없으므로 폴백만 탄다.
            c.execute(f'''
                SELECT n.{unit_pk},
                       COALESCE((SELECT contents FROM sys_text_asset
                                  WHERE text_type='NODE_NAME'
                                    AND clicked_id=n.{unit_pk}
                                    AND UPPER(lang_code)=UPPER(?)
                                    AND COALESCE(record_status,'LIVE')='LIVE'
                                  LIMIT 1), n.unit_name_sid),
                       l.sort_order
                  FROM {link_tbl} l
                  JOIN {unit_tbl} n ON n.{unit_pk} = l.target_id
                 WHERE l.link_type='CONT_NODE'
                   AND l.clicked_id=?
                   AND COALESCE(l.record_status, 'LIVE') = 'LIVE'
                   AND n.unit_type='NODE'
                   AND COALESCE(n.record_status, 'LIVE') = 'LIVE'
              ORDER BY l.sort_order, n.{unit_pk}
            ''', (self._lang(), container_id))
            rows = c.fetchall()
        finally:
            conn.close()

        if not rows:
            # ⚠ 글자 앞 공백 금지 — indent=8 과 겹쳐 이중 들여쓰기가 된다(§36-3)
            self._node_tv.insert('', 'end',
                                  text=i18n.t('LENS_NONODE','(연결된 노드 없음)').strip(),
                                  tags=('empty',))
            return

        for node_id, name_sid, _ in rows:
            # iid에 source 표기로 SYS/USER ID 충돌 방지
            iid = f'NODE_{"U" if source == "USER" else "S"}_{node_id}'
            display = name_sid or f'(이름 없음 #{node_id})'
            self._node_tv.insert('', 'end', iid=iid,
                                  text=display, tags=('node',))
            self._node_data[iid] = {
                'node_id': node_id, 'name': display, 'source': source}

    def _clear_node_list(self):
        self._node_tv.delete(*self._node_tv.get_children())
        self._node_data = {}

    def _show_node_placeholder(self, msg: str | None = None):
        # (자리표시도 새로 만든 위젯이다 — 아래 본문 끝에서 _repaint 를 부른다)
        """노드 상세 영역 초기화 (Step 2에서 본격 구현)."""
        for child in self._node_detail_f.winfo_children():
            child.destroy()
        text = msg or i18n.t('LENS_NODE_HINT', '노드를 선택하면 연결된 구절 세트가 표시됩니다.')
        tk.Label(self._node_detail_f, text=text,
                 bg='#FAFAFA', fg='#566573',
                 font=('', 10), justify='center').pack(expand=True)
        _repaint(self._node_detail_f)

    # ── 이벤트 핸들러 ────────────────────────────────────────────────────────

    def _on_cat_tree_select(self, _evt=None):
        sel = self._cat_tv.selection()
        if not sel:
            return
        iid = sel[0]
        info = self._cat_tree_data.get(iid)
        if not info:
            return

        if info['kind'] == 'cat':
            self._curr_container_id = None
            self._curr_container_source = None
            self._clear_container_detail()
            self._clear_node_list()
            self._show_node_placeholder()
            # 카테고리 선택 → [+ My Lens]만 활성
            self._set_my_lens_tools(add=True, rename=False, delete=False)
            self._set_node_tools(add=False, rename=False, move=False, delete=False)
        elif info['kind'] == 'cont':
            self._curr_container_id = info['unit_id']
            self._curr_container_source = info.get('source', 'SYS')
            self._load_container_detail(info['unit_id'], self._curr_container_source)
            self._load_node_list(info['unit_id'], self._curr_container_source)
            self._show_node_placeholder()
            # 컨테이너 선택 — USER만 편집 가능
            is_user = self._curr_container_source == 'USER'
            self._set_my_lens_tools(add=True, rename=is_user, delete=is_user)
            # 노드 도구: USER 컨테이너 선택 시 [+ 노드]만 활성 (나머지는 노드 선택 후)
            self._set_node_tools(add=is_user, rename=False, move=False, delete=False)
        self._curr_node_id = None
        self._bar_sync()
        self._sync_mylens_dlg()        # My Lens 팝업이 떠 있으면 따라온다
        self._sync_share_dlg()         # 공유하기 팝업도 같은 선택을 본다

    def _on_node_select(self, _evt=None):
        sel = self._node_tv.selection()
        if not sel:
            return
        info = self._node_data.get(sel[0])
        if not info:
            return
        self._curr_node_id = info['node_id']
        self._curr_node_source = info.get('source', 'SYS')
        # [Step 2] 노드 → 구절 세트 표시 (source 전달)
        self._show_node_verse_sets(info['node_id'], info['name'],
                                     self._curr_node_source)
        # 노드 도구 활성 — USER 노드만 편집 가능
        is_user = self._curr_node_source == 'USER'
        self._set_node_tools(add=is_user, rename=is_user, move=is_user, delete=is_user)
        self._sync_mylens_dlg()

    # ── [Step 2] 노드 → 구절 세트 표시 ──────────────────────────────────────

    def _show_node_verse_sets(self, node_id: int, node_name: str,
                                source: str = 'SYS', page=None):
        """노드의 구절들 — **다른 묵상플랜과 같은 서식**(`ReadingPane`) (2026-08-17).

        ★ 「카드·박스를 최대한 제거하고 다른 묵상플랜처럼 서식 자체를 바꾸어라」
          (사용자 지시). 예전에는 LabelFrame 카드 + 색깔 상자 4종(초록·베이지·보라·
          분홍)이었다 — 그 색·글꼴이 테마를 계속 벗어났다. `ReadingPane` 은
          PlanFocusView 가 쓰는 **읽는 화면 한 벌**이라 색 상자가 없고 글꼴·색이
          통합 표준을 스스로 따른다(§22 · font.md).
        ★ **렌즈/노드 설명문은 항상, 구절 딸림글은 체크박스** (2026-08-17 사용자
          결정 — §4-2 「그리지 않는다」를 뒤집었다). 노드 설명(NODE_DESC)은 값이
          있으면 늘 그리고, 구절설명·묵상질문·묵상기도는 체크박스 3개(기본 **체크**,
          직전값 `user_config['LENS_VERS_SHOW']`)로 켜고 끈다.
        ★ **구간은 절 단위로 분리해 그린다** — 약명이 절마다 눌린다.
        ★ **보기 방식 = 스크롤/페이지** (2026-08-17 사용자 지시, 0.app수정.txt 4-1).
          페이지면 링크당 단추 하나(구간=한 단추 — 절 단위로 쪼개면 단추 줄이
          넘친다) + 마지막 「렌즈노트」 단추(노드 질문·기도·내 묵상이 모이는 장).
          `page` = 페이지 번호(None 이면 첫 장). 직전값 `LENS_VIEW_MODE`.
        ★ 연결 설명(NODE_VERS_DESC)은 **값이 있을 때만** — 형식적 입력을 하지
          않기로 했으므로(사용자 결정) 빈 자리도 정상이다.
        """
        for child in self._node_detail_f.winfo_children():
            child.destroy()

        # 머리 — 노드 이름 + 표시 체크박스 + (USER 면) [+ 구절]
        header = tk.Frame(self._node_detail_f, bg='#EBF5FB')
        header.pack(fill='x')
        tk.Label(header, text=node_name, bg='#EBF5FB',
                 font=('', 10, 'bold'), fg='#1A5276'
                 ).pack(side='left', padx=8, pady=4)
        if source == 'USER':
            add_v = tk.Label(header, text=i18n.t('LENS_ADDVERSE', '[+ 구절]'),
                             bg='#EBF5FB', fg='#1E8449', font=('', 9, 'bold'),
                             cursor='hand2', padx=6, pady=2)
            add_v.pack(side='right', padx=6, pady=2)
            add_v.bind('<Button-1>', lambda _e, nid=node_id: self._add_my_verse(nid))
        # 구절 딸림글 체크박스 — 끄면 약명 클릭(P2)으로 대신 본다
        show = self._vers_show()
        self._vshow_vars = {}
        for key, label in (('prayer', i18n.t('LENS_SHOW_VP', '묵상기도')),
                           ('question', i18n.t('LENS_SHOW_VQ', '묵상질문')),
                           ('desc', i18n.t('LENS_SHOW_VDESC', '구절설명'))):
            var = tk.BooleanVar(value=show[key])
            self._vshow_vars[key] = var
            tk.Checkbutton(header, text=label, variable=var, bg='#EBF5FB',
                           activebackground='#EBF5FB',
                           command=lambda nid=node_id, nm=node_name, s=source:
                               self._on_vers_show_toggle(nid, nm, s)
                           ).pack(side='right', padx=2)
        # 보기 방식 — **라디오버튼**, 체크박스와 간격을 두고 오른쪽에 (2026-08-17
        #   사용자 지시. 「버튼이 너무 크고 두드러진다 — 라디오버튼 수준이면 된다」).
        #   ⚠ side='right' 는 먼저 pack 한 것이 더 오른쪽 — 페이지를 먼저 넣어야
        #     왼쪽부터 「스크롤 페이지」 순으로 읽힌다. 체크박스와의 간격은
        #     **페이지의 오른쪽 padx** — padx 는 pack 방향과 무관하게 (왼쪽, 오른쪽)이다.
        self._vmode_var = tk.StringVar(value=self._lens_view_mode())
        for m, lb, px in (('PAGE', i18n.t('LENS_VIEW_PAGE', '페이지'), (1, 16)),
                          ('SCROLL', i18n.t('LENS_VIEW_SCROLL', '스크롤'), 1)):
            tk.Radiobutton(header, text=lb, value=m, variable=self._vmode_var,
                           font=('', 9), bg='#EBF5FB', activebackground='#EBF5FB',
                           cursor='hand2',
                           command=lambda nid=node_id, nm=node_name, s=source:
                               self._set_lens_view_mode(self._vmode_var.get(),
                                                        nid, nm, s)
                           ).pack(side='right', padx=px)

        from reading_pane import ReadingPane
        pane = ReadingPane(self._node_detail_f, self.db_path,
                           on_ref_click=self._navigate_to_verse)
        pane.pack(fill='both', expand=True)
        pane.start()

        # 노드 설명 — **항상 표시** (2026-08-17 사용자 지적 「노드설명문이 전혀
        #   없다」 — 데이터는 12/12 있는데 화면이 그리지 않고 있었다).
        nd = None
        try:
            with appdb.connect(self.db_path) as conn:
                if source == 'USER':
                    # ★ USER 글은 언어 필터 없음 (2026-08-17 채택 원칙)
                    r = conn.execute("""SELECT contents FROM user_text_asset
                                        WHERE text_type='NODE_DESC' AND clicked_id=?
                                          AND COALESCE(record_status,'LIVE')='LIVE'
                                        ORDER BY (UPPER(lang_code)=UPPER(?)) DESC,
                                                 (UPPER(lang_code)='KO') DESC
                                        LIMIT 1""", (node_id, self._lang())).fetchone()
                else:
                    r = conn.execute("""SELECT contents FROM sys_text_asset
                                        WHERE text_type='NODE_DESC' AND clicked_id=?
                                          AND UPPER(lang_code)=UPPER(?)
                                          AND COALESCE(record_status,'LIVE')='LIVE'
                                        LIMIT 1""",
                                    (node_id, self._lang())).fetchone()
                    # ★ 덮개 (2026-08-26 읽기 배선) — 이름 열쇠(overlay 참조)
                    try:
                        import overlay as _ov
                        ov = _ov.text_override(conn, 'NODE_DESC', node_id,
                                               self._lang(), '')
                        if ov is not None:
                            r = None if ov[0] == 'HIDE' else (ov[1][1],)
                    except Exception:
                        pass
            nd = (r[0] or '').strip() if r else None
        except Exception as e:
            print('[node desc] %s' % e)
        verses = self._fetch_node_verses(node_id, source)
        if not verses:
            if nd:
                pane.body(nd)
                pane.gap()
            pane.aside(i18n.t('LENS_NOVERSE', '(연결된 구절이 없습니다)'))
            pane.finish()
            _repaint(self._node_detail_f)
            return

        # 보기 방식 — 페이지면 단추 줄을 pane **위**에 끼운다.
        #   ⚠ pane 이 이미 expand 로 pack 돼 있어 그냥 pack 하면 공간 0 —
        #     `before=pane` 으로 순서를 당긴다(편집 띠에서 겪은 함정과 같다).
        sel = None                          # None = 스크롤(전부 한 흐름)
        if self._lens_view_mode() == 'PAGE':
            labels = [self._link_ref_label(v) for v in verses] \
                     + [i18n.t('LENS_PAGE_NOTE', '묵상노트')]
            sel = 0 if page is None else max(0, min(int(page), len(labels) - 1))
            self._cur_page = sel
            bar = tk.Frame(self._node_detail_f)
            bar.pack(fill='x', padx=4, pady=(2, 0), before=pane)
            # 단추 크기 = **중간** — 글자는 본문(성경) 크기 수준 (2026-08-17 사용자
            #   「처음엔 너무 컸고 줄이니 너무 작다 — 본문 글자 수준의 중간으로」).
            #   그리고 **가운데 정렬** — 안쪽 프레임을 fill 없이 pack 하면 어떤
            #   폭에서도 가운데 온다.
            try:
                import theme_font
                _bs = int(theme_font.resolve(self.db_path, 'bible')['size'])
            except Exception:
                _bs = 10
            inner = tk.Frame(bar)
            inner.pack(anchor='center')
            for i, lb in enumerate(labels):
                tk.Button(inner, text=lb, bd=1, padx=6, pady=1, font=('', _bs),
                          cursor='hand2',
                          relief=('sunken' if i == sel else 'raised'),
                          command=lambda i=i, nid=node_id, nm=node_name,
                                         s=source:
                              self._show_node_verse_sets(nid, nm, s, page=i)
                          ).pack(side='left', padx=2, pady=1)
        else:
            self._cur_page = None

        # 노드 설명 — 스크롤이면 맨 위에 늘, 페이지면 첫 장과 렌즈노트 장에.
        #   `body`(민바탕 본문) — 딸림글과 **독립적으로 구분**한다(2026-08-17 사용자).
        if nd and sel in (None, 0, len(verses)):
            pane.body(nd)
            pane.gap()

        for idx, v in enumerate(verses, 1):
            if sel is not None and idx - 1 != sel:
                continue
            bn = self._get_book_short_name(v['bcode']) if v.get('bcode') else ''
            # 구간도 **절마다** 약명(눌림) + 본문 — 딸림글은 체크박스를 따른다.
            # ★ 구절·설명·질문·기도 **사이마다 빈 줄 하나** (2026-08-17 사용자 지시).
            #   기호 접두어(? ▷ ※)는 뗐다 — 콘텐츠가 아니라 표시 로직이 붙이던
            #   것이었고 사용자가 요구한 적 없는 기호였다. 갈래는 빈 줄·들여쓰기·
            #   옅은 바탕(reading_pane 의 aside 서식)이 가른다.
            # ★ **비대칭 규칙** (2026-08-17 사용자 채택 — `0.app수정.txt` 「재수정」).
            #   구간 = 본문을 통으로 읽고 **구간 연결설명문 하나**가 노드 관점을
            #   대변한다. 절별 딸림글은 그리지 않는다(가운데 절 설명문을 쓸데없이
            #   읽는 문제·분량 과다). 절별 심화는 약명 클릭(P2)으로.
            #   단일 = 구절 자산이 담당, 체크박스대로.
            is_range = bool(v.get('end_id') and v['end_id'] != v['verse_id'])
            prev_aside = False
            for it in (v.get('items') or []):
                if prev_aside:
                    pane.gap()
                ref = f"{bn} {it['chapter']}:{it['verse']}" if bn else ''
                pane.verse(ref, it.get('text') or '', payload=it['verse_id'])
                prev_aside = False
                if is_range:
                    continue
                for key in ('desc', 'question', 'prayer'):
                    if show[key] and it.get(key):
                        pane.gap()
                        pane.aside(it[key])
                        prev_aside = True
            if v.get('link_desc'):
                pane.gap()
                pane.aside(v['link_desc'])
            if sel is None and idx != len(verses):
                pane.gap()

        if sel is not None and sel < len(verses):
            # 구절 장 — 노드 단위 꼬리(질문·기도·내 묵상)는 렌즈노트 장의 몫이다
            pane.finish()
            _repaint(self._node_detail_f)
            return

        # 노드 묵상질문·묵상기도 — 본문 흐름의 꼬리에, **체크박스와 무관하게 항상**
        #   (2026-08-17 사용자 지시 「구절 단위와 내용이 다르기 때문에 표시해야
        #   한다」 — 체크박스는 구절 딸림글만 끈다). 값이 있을 때만 그린다.
        #   ⚠ NODE_PRAYER 는 아직 데이터 0편(초안에 question 만 있었다) —
        #     콘텐츠가 들어오면 저절로 나타난다.
        tail = []
        try:
            with appdb.connect(self.db_path) as conn:
                for ttype, mark in (('NODE_QUESTION', '◆ '),
                                    ('NODE_PRAYER', '▷ ')):
                    if source == 'USER':
                        # ★ USER 글은 언어 필터 없음 (2026-08-17 채택 원칙)
                        r = conn.execute(
                            """SELECT contents FROM user_text_asset
                                WHERE text_type=? AND clicked_id=?
                                  AND COALESCE(record_status,'LIVE')='LIVE'
                                ORDER BY (UPPER(lang_code)=UPPER(?)) DESC,
                                         (UPPER(lang_code)='KO') DESC
                                LIMIT 1""", (ttype, node_id, self._lang())).fetchone()
                    else:
                        r = conn.execute(
                            """SELECT contents FROM sys_text_asset
                                WHERE text_type=? AND clicked_id=?
                                  AND UPPER(lang_code)=UPPER(?)
                                  AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1""",
                            (ttype, node_id, self._lang())).fetchone()
                        # ★ 덮개 (2026-08-26 읽기 배선) — 이름 열쇠
                        try:
                            import overlay as _ov
                            ov = _ov.text_override(conn, ttype, node_id,
                                                   self._lang(), '')
                            if ov is not None:
                                r = None if ov[0] == 'HIDE' else (ov[1][1],)
                        except Exception:
                            pass
                    s = (r[0] or '').strip() if r else None
                    if s:
                        tail.append(mark + s)
        except Exception as e:
            print('[node q/p] %s' % e)
        if tail:
            pane.gap()
            for s in tail:
                pane.aside(s)

        # 내 묵상 — **텍스트 흐름으로** (2026-08-17 사용자 지시 「작성 버튼만 배치,
        #   작성화면은 잠시 보였다가 저장하면 사라지고, 결과는 텍스트처럼 화면
        #   리사이즈에 연동」). 예전엔 NoteRefrPanel 을 `pane.widget()` 으로 심었는데
        #   Text 안에 박힌 위젯은 창 크기를 따라오지 못해 고정폭으로 남았다.
        #   저장 행 모양(user_text_asset · NODE_NOTE/UNODE_NOTE)은 그대로라
        #   기존 글이 그대로 보인다.
        # 「― 내 묵상」 머리글은 뗐다 — 단추 하나면 된다 (2026-08-17 사용자:
        #   「내묵상·쓰기 두 개가 분리되어 있다. 내묵상을 삭제하고 렌즈노트 쓰기로」).
        pane.gap()
        pane.widget(lambda parent: tk.Button(
            parent, text=i18n.t('MN_WRITE', '묵상노트 쓰기'), bd=1, padx=8,
            cursor='hand2',
            command=lambda: self._open_note_editor(node_id, node_name, source)),
            pad=(0, 1))
        for n in self._fetch_node_notes(node_id, source):
            date = (n['updated_at'] or n['created_at'] or '')[:10]
            head = date + ((' · ' + n['title']) if n['title'] else '')
            # 통합 노트는 닻 약명을 작게 함께 보인다 (사용자 결정 원칙 — 닻이 늘 보임)
            if n.get('kind') == 'new' and n.get('verse_label'):
                head += '  ▸ ' + n['verse_label']
            pane.widget(lambda parent, rec=n, h=head: self._make_note_head(
                parent, h, node_id, node_name, source, rec), pad=(1, 0))
            pane.aside((n.get('body') if n.get('kind') == 'new'
                        else n.get('contents')) or '')
        pane.finish()
        _repaint(self._node_detail_f)

    # ── 내 묵상 — **묵상노트 통합** (2026-08-19 사용자 확정 7원칙) ─────────────
    #   새 글은 전부 구절 닻 통합 저장소(medi_note · VERS_NOTE)로 쓴다. 렌즈·노드는
    #   맥락 라벨(출처 키)이고, 노드 질문은 스냅샷으로 노트에 담긴다. 옛
    #   NODE_NOTE/UNODE_NOTE 행은 그대로 보이고 고쳐진다(legacy 경로 보존).

    def _note_src(self, node_name: str):
        """이 노드의 맥락 (키, 라벨). 키는 이름 기반 글자 키 — FK 가 아니다."""
        cname = ''
        try:
            tbl = ('user_unit_asset' if self._curr_container_source == 'USER'
                   else 'sys_unit_asset')
            pk = ('user_unit_id' if self._curr_container_source == 'USER'
                  else 'sys_unit_id')
            with appdb.connect(self.db_path) as conn:
                r = conn.execute(f"SELECT unit_name_sid FROM {tbl} WHERE {pk}=?",
                                 (self._curr_container_id,)).fetchone()
                cname = (r[0] or '') if r else ''
        except Exception:
            pass
        key = f'LENS:{cname}:{node_name}'
        label = (i18n.t('TAB_LENS', '렌즈묵상') + ' · ' + cname + ' · ' + node_name
                 if cname else node_name)
        return key, label

    def _fetch_node_notes(self, node_id: int, source: str) -> list[dict]:
        """옛 노드 단위 글(legacy) + 통합 구절 닻 글(new)을 한 목록으로."""
        ntt = 'NODE_NOTE' if source == 'SYS' else 'UNODE_NOTE'
        out = []
        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    "SELECT user_text_id, title, contents, created_at, updated_at "
                    "FROM user_text_asset "
                    "WHERE text_type=? AND clicked_id=? "
                    "  AND record_status IN ('LIVE','NEW','EDIT') "
                    "ORDER BY COALESCE(updated_at, created_at) DESC, "
                    "         user_text_id DESC",
                    (ntt, node_id)).fetchall()
            out = [{'id': r[0], 'title': r[1], 'contents': r[2], 'body': r[2],
                    'created_at': r[3], 'updated_at': r[4], 'kind': 'legacy',
                    'verse_label': ''} for r in rows]
        except Exception as e:
            print('[lens notes] %s' % e)
        try:
            import medi_note
            key, _lbl = self._note_src(self._node_name_by_id(node_id, source))
            for n in medi_note.notes_for_context(self.db_path, key):
                n['kind'] = 'new'
                out.append(n)
        except Exception as e:
            print('[lens notes/new] %s' % e)
        out.sort(key=lambda n: (n.get('updated_at') or n.get('created_at') or ''),
                 reverse=True)
        return out

    def _node_name_by_id(self, node_id: int, source: str) -> str:
        try:
            tbl = 'user_unit_asset' if source == 'USER' else 'sys_unit_asset'
            pk = 'user_unit_id' if source == 'USER' else 'sys_unit_id'
            with appdb.connect(self.db_path) as conn:
                r = conn.execute(f"SELECT unit_name_sid FROM {tbl} WHERE {pk}=?",
                                 (node_id,)).fetchone()
            return (r[0] or '') if r else ''
        except Exception:
            return ''

    def _make_note_head(self, parent, head, node_id, node_name, source, rec):
        """글 머리 한 줄 — 날짜 + [수정] (누르면 그 글을 편집기로).

        ⚠ 연필 글리프(✎)를 쓰지 않는다 — 맑은 고딕 cmap 에 없어 폴백 렌더로
          「나뭇잎」처럼 보인다(§36-5b 기호 규칙).
        """
        f = tk.Frame(parent)
        tk.Label(f, text=head).pack(side='left', padx=(0, 4))
        tk.Button(f, text=i18n.t('COMMON_EDIT', '수정'), bd=1, padx=4, pady=0,
                  font=('', 8), cursor='hand2',
                  command=lambda: self._open_note_editor(
                      node_id, node_name, source, rec)).pack(side='left')
        return f

    def _open_note_editor(self, node_id, node_name, source, rec=None):
        """작성 띠 진입점 — 새 글·통합 글은 묵상노트 쓰기 띠(medi_note.NoteBar)로,
        옛 노드 단위 글(legacy)의 수정만 예전 편집기로 보낸다 (2026-08-19 통합)."""
        if rec is not None and rec.get('kind') == 'legacy':
            return self._open_note_editor_legacy(node_id, node_name, source, rec)
        return self._open_note_editor_new(node_id, node_name, source, rec)

    def _open_note_editor_new(self, node_id, node_name, source, rec=None):
        """묵상노트 쓰기 띠 — 닻(약명)이 항상 보이고 후보에서 선택한다.

        후보 = 이 노드의 구절 링크들(구간은 구간 그대로). 기본 = 첫 링크.
        노드 질문은 **스냅샷**으로 노트에 담긴다 — 렌즈가 개편돼도 문답이 산다.
        """
        import medi_note
        old = getattr(self, '_note_editor_f', None)
        if old is not None and old.winfo_exists():
            old.destroy()
        cands = []
        try:
            for v in self._fetch_node_verses(node_id, source):
                sv = v.get('verse_id')
                if not sv:
                    continue
                ev = v.get('end_id') or sv
                cands.append((medi_note.verse_label(self.db_path, sv, ev,
                                                    self._lang()), sv, ev))
        except Exception as e:
            print('[note cands] %s' % e)
        if not cands:
            return          # 구절 없는 빈 노드 — 붙일 여백이 없다 (기존 정책 그대로)
        question = ''
        try:
            ttbl = 'user_text_asset' if source == 'USER' else 'sys_text_asset'
            with appdb.connect(self.db_path) as conn:
                if source == 'USER':
                    r = conn.execute(
                        "SELECT contents FROM user_text_asset WHERE "
                        "text_type='NODE_QUESTION' AND clicked_id=? AND "
                        "COALESCE(record_status,'LIVE')='LIVE' "
                        "ORDER BY (UPPER(lang_code)=UPPER(?)) DESC, (UPPER(lang_code)='KO') DESC LIMIT 1",
                        (node_id, self._lang())).fetchone()
                else:
                    r = conn.execute(
                        "SELECT contents FROM sys_text_asset WHERE "
                        "text_type='NODE_QUESTION' AND clicked_id=? AND "
                        "UPPER(lang_code)=UPPER(?) AND "
                        "COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
                        (node_id, self._lang())).fetchone()
            question = (r[0] or '').strip() if r else ''
        except Exception:
            pass
        key, label = self._note_src(node_name)

        def _done():
            self._show_node_verse_sets(node_id, node_name, source,
                                       page=getattr(self, '_cur_page', None))

        f = medi_note.NoteBar(
            self._node_detail_f, self.db_path, cands, src_key=key,
            src_label=label, question=question, lang=self._lang(), rec=rec,
            on_done=_done,
            title_text=i18n.t('MN_WRITE', '묵상노트 쓰기') + ' — ' + node_name)
        self._note_editor_f = f
        # ⚠ pack 순서를 앞으로 당긴다 — ReadingPane 이 expand 라 뒤에 붙이면 1×1 (§ 함정)
        kids = [c for c in self._node_detail_f.winfo_children()
                if c is not f and c.winfo_ismapped()]
        if kids:
            f.pack(side='bottom', fill='x', padx=4, pady=4, before=kids[0])
        else:
            f.pack(side='bottom', fill='x', padx=4, pady=4)
        _repaint(f)

    def _open_note_editor_legacy(self, node_id, node_name, source, rec=None):
        """옛 노드 단위 글(NODE_NOTE/UNODE_NOTE) 수정 전용 — 기존 행 무손상 보존."""
        old = getattr(self, '_note_editor_f', None)
        if old is not None and old.winfo_exists():
            old.destroy()
        f = tk.Frame(self._node_detail_f, bd=1, relief='solid')
        self._note_editor_f = f
        # ⚠ **pack 순서를 앞으로 당긴다**(`before=첫 자식`). ReadingPane 이 expand 라
        #   순서상 뒤에 pack 하면 남은 공간이 0 — 띠가 화면에 아예 안 잡힌다
        #   (실측: mapped=0 · 1×1). before 는 늘 떠 있는 위젯이어야 한다(§ 함정).
        kids = [c for c in self._node_detail_f.winfo_children()
                if c is not f and c.winfo_ismapped()]
        if kids:
            f.pack(side='bottom', fill='x', padx=4, pady=4, before=kids[0])
        else:
            f.pack(side='bottom', fill='x', padx=4, pady=4)

        bar = tk.Frame(f)
        bar.pack(fill='x')
        tk.Label(bar, text=(i18n.t('LENS_NOTE_WRITE', '묵상노트 쓰기') + ' — '
                            + node_name)).pack(side='left', padx=6, pady=2)

        txt = tk.Text(f, height=5, wrap='word', bd=0)
        try:
            import theme_font
            theme_font.register(txt, self.db_path, 'prose')
        except Exception:
            pass
        if rec and rec.get('contents'):
            txt.insert('1.0', rec['contents'])

        def _close():
            if f.winfo_exists():
                f.destroy()

        def _save():
            body = txt.get('1.0', 'end-1c').strip()
            if not body:
                _close()
                return
            ntt = 'NODE_NOTE' if source == 'SYS' else 'UNODE_NOTE'
            try:
                with appdb.connect(self.db_path) as conn:
                    if rec:
                        conn.execute(
                            "UPDATE user_text_asset SET contents=?, "
                            "record_status='EDIT', "
                            "updated_at=DATETIME('now','localtime') "
                            "WHERE user_text_id=?", (body, rec['id']))
                    else:
                        conn.execute(
                            "INSERT INTO user_text_asset (clicked_id, target_id, "
                            "text_type, title, contents, lang_code, record_status, "
                            "created_at, updated_at) VALUES (?, 0, ?, '', ?, ?, "
                            "'NEW', DATETIME('now','localtime'), "
                            "DATETIME('now','localtime'))",
                            (node_id, ntt, body, self._lang()))
            except Exception as e:
                print('[lens note save] %s' % e)
            _close()
            self._show_node_verse_sets(node_id, node_name, source,
                                       page=getattr(self, '_cur_page', None))

        def _delete():
            from tkinter import messagebox
            if not rec:
                return
            if not messagebox.askyesno(i18n.t('LENS_NOTE_DELT', '삭제'),
                                       i18n.t('LENS_NOTE_DELQ',
                                              '이 글을 삭제할까요?')):
                return
            try:
                with appdb.connect(self.db_path) as conn:
                    conn.execute("UPDATE user_text_asset SET record_status='HIDE' "
                                 "WHERE user_text_id=?", (rec['id'],))
            except Exception as e:
                print('[lens note del] %s' % e)
            _close()
            self._show_node_verse_sets(node_id, node_name, source,
                                       page=getattr(self, '_cur_page', None))

        tk.Button(bar, text=i18n.t('COMMON_CANCEL', '취소'), bd=0, padx=8,
                  cursor='hand2', command=_close).pack(side='right', padx=2)
        if rec:
            tk.Button(bar, text=i18n.t('COMMON_DELETE', '삭제'), bd=0, padx=8,
                      cursor='hand2', command=_delete).pack(side='right', padx=2)
        tk.Button(bar, text=i18n.t('COMMON_SAVE', '저장'), bd=0, padx=8,
                  cursor='hand2', command=_save).pack(side='right', padx=2)

        txt.pack(fill='x', padx=6, pady=(0, 6))
        txt.focus_set()
        _repaint(f)                     # 동적 위젯 — 테마를 직접 입힌다(§36-5b)

    def _fetch_node_verses(self, node_id: int, source: str = 'SYS') -> list[dict]:
        """노드에 연결된 모든 구절 + 텍스트 자산 조회. source 분기.

        강건성:
          - lang_code: UPPER() 양측 정규화 (CLAUDE.md §0-2)
          - record_status: COALESCE(...,'LIVE')='LIVE' — NULL도 LIVE로 간주
          - 공백/None 텍스트는 None 처리 (동적 숨김 신뢰성)
          - 같은 키에 여러 행이 있으면 LIVE 우선
          - source='USER'면 user_link_asset/user_text_asset, 'SYS'면 sys_*
        """
        lang = self._lang()
        version = (self.version_getter() if callable(self.version_getter) else 'KRV') or 'KRV'

        def _clean(s):
            """공백/빈 문자열은 None."""
            if s is None:
                return None
            stripped = str(s).strip()
            return stripped if stripped else None

        link_tbl = 'user_link_asset' if source == 'USER' else 'sys_link_asset'
        link_pk = 'user_link_id' if source == 'USER' else 'sys_link_id'
        text_tbl = 'user_text_asset' if source == 'USER' else 'sys_text_asset'

        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            # ★ **구간 = 한 링크** (2026-08-16 사용자 지시). `end_id` 가 있으면
            #   시작~끝 절이 **카드 하나**다. 없으면(NULL·옛 데이터) 절 하나 그대로.
            #   ⚠ 칸이 없는 옛 DB 로 열 수도 있다 — 있는지 먼저 본다.
            _cols = [r[1] for r in c.execute('PRAGMA table_info(%s)' % link_tbl)]
            _has_end = 'end_id' in _cols
            c.execute(f'''
                SELECT l.{link_pk}, l.target_id, l.sort_order
                       {', l.end_id' if _has_end else ", NULL"}
                  FROM {link_tbl} l
                 WHERE l.link_type='NODE_VERS'
                   AND l.clicked_id=?
                   AND COALESCE(l.record_status, 'LIVE') = 'LIVE'
              ORDER BY l.sort_order, l.{link_pk}
            ''', (node_id,))
            links = c.fetchall()

            import verse_tier
            _tier = verse_tier.tier_for_mode(verse_tier.get_desc_mode(c))
            verses = []
            for link_id, verse_id, sort_order, end_id in links:
                v = {'link_id': link_id, 'verse_id': verse_id,
                     'sort_order': sort_order, 'source': source,
                     'end_id': end_id}

                # 구절 참조 (bible_index — 성경 자산은 공통)
                c.execute('SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?',
                          (verse_id,))
                row = c.fetchone()
                if row:
                    v['bcode'], v['chapter'], v['verse'] = row
                else:
                    v['bcode'] = v['chapter'] = v['verse'] = None
                # 구간의 끝 절 번호 (제목 `창 22:1-14` 용)
                v['verse_end'] = v['chapter_end'] = None
                if end_id and end_id != verse_id:
                    row = c.execute('SELECT chapter, verse FROM bible_index '
                                    'WHERE verse_id=?', (end_id,)).fetchone()
                    if row:
                        v['chapter_end'], v['verse_end'] = row

                # 구절 본문 + 절별 딸림글 — **절 단위로 담는다** (2026-08-17 사용자
                #   지시 「구절약명 + 구절본문을 구절 단위로 분리하여 표시해야
                #   구절약명 각각 클릭 가능하다」). 구간(end_id)은 **데이터는 한 링크
                #   그대로**, 표시만 절마다 가른다 — 예전 병합 방식은 구간 둘째
                #   절부터의 설명문을 볼 길이 없었다.
                last = end_id if (end_id and end_id > verse_id) else verse_id
                items = []
                for vid2 in range(verse_id, last + 1):
                    row = c.execute('SELECT chapter, verse FROM bible_index '
                                    'WHERE verse_id=?', (vid2,)).fetchone()
                    if not row:
                        continue
                    it = {'verse_id': vid2, 'chapter': row[0], 'verse': row[1]}
                    # ★ 「(본문 없음)」으로 끝내지 않는다 — 합쳐진 절이면
                    #   그 절 본문을, 없는 절이면 까닭과 빌려 온 글을(§verse_text)
                    it['text'] = _vt.resolve(c, vid2, version)['text']
                    # VERS_DESC / VERS_QUESTION / VERS_PRAYER — 절마다.
                    #   ★ 절별자산은 **늘 sys**(전 성경 공용) — USER 렌즈에서도
                    #     구절설명문이 보여야 한다(2026-08-17 전수 점검).
                    for ttype, key in [('VERS_DESC', 'desc'),
                                       ('VERS_QUESTION', 'question'),
                                       ('VERS_PRAYER', 'prayer')]:
                        c.execute(f'''SELECT contents, text_variant FROM sys_text_asset
                                      WHERE text_type=? AND clicked_id=?
                                        AND UPPER(lang_code)=UPPER(?)
                                        AND COALESCE(record_status,'LIVE')='LIVE'
                                   ORDER BY {verse_tier.TIER_ORDER},
                                            (CASE WHEN record_status='LIVE' THEN 0 ELSE 1 END)
                                      LIMIT 1''',
                                  (ttype, vid2, lang, _tier))
                        row = c.fetchone()
                        it[key] = _clean(row[0]) if row else None
                        # ★ 덮개 (2026-08-26 읽기 배선) — 절 자산도 내 버전이
                        #   이기고, 가린 것은 렌즈 화면에서도 숨는다.
                        try:
                            import overlay as _ov
                            ov = _ov.text_override(
                                c, ttype, vid2, lang,
                                (row[1] if row else None) or '')
                            if ov is not None:
                                it[key] = (None if ov[0] == 'HIDE'
                                           else _clean(ov[1][1]))
                        except Exception:
                            pass
                    items.append(it)
                v['items'] = items

                # NODE_VERS_DESC: clicked_id=link_id (source별).
                #   ★ USER 글은 **언어 필터 없음** (2026-08-17 채택 원칙 — 사용자
                #     데이터는 입력한 그대로. 필터를 걸면 언어 설정을 바꾼 사용자에게
                #     자기 글이 사라져 보인다).
                if source == 'USER':
                    c.execute('''SELECT contents FROM user_text_asset
                                  WHERE text_type='NODE_VERS_DESC' AND clicked_id=?
                                    AND COALESCE(record_status,'LIVE')='LIVE'
                                  ORDER BY (UPPER(lang_code)=UPPER(?)) DESC,
                                           (UPPER(lang_code)='KO') DESC
                                  LIMIT 1''', (link_id, self._lang()))
                else:
                    c.execute('''SELECT contents FROM sys_text_asset
                                  WHERE text_type='NODE_VERS_DESC' AND clicked_id=?
                                    AND UPPER(lang_code)=UPPER(?)
                                    AND COALESCE(record_status,'LIVE')='LIVE'
                               ORDER BY (CASE WHEN record_status='LIVE' THEN 0 ELSE 1 END)
                                  LIMIT 1''', (link_id, lang))
                row = c.fetchone()
                v['link_desc'] = _clean(row[0]) if row else None

                verses.append(v)
            return verses
        finally:
            conn.close()

    # ⚠ 옛 카드 서식(`_build_verse_card`·`_add_card_section`)은 **지웠다** (2026-08-17).
    #   LabelFrame 카드 + 색 상자 4종이 테마를 계속 벗어났고, 사용자 지시
    #   「카드·박스를 최대한 제거, 다른 묵상플랜처럼 서식 자체를 바꾸어라」로
    #   `ReadingPane` 이 그 자리를 맡는다(위 `_show_node_verse_sets`).
    #   되살리지 말 것. (절별자산 표시는 2026-08-17 체크박스로 부활 — 카드가 아니라
    #   ReadingPane 흐름 안에서다.)

    # ── 렌즈트리 접기 (2026-08-17 사용자 A안 — 본문 폭 확보) ─────────────────

    _TREE_HIDE_KEY = 'LENS_TREE_HIDDEN'

    def _lens_tree_hidden(self) -> bool:
        try:
            with appdb.connect(self.db_path) as conn:
                r = conn.execute('SELECT config_val FROM user_config '
                                 'WHERE config_key=? LIMIT 1',
                                 (self._TREE_HIDE_KEY,)).fetchone()
            return bool(r and r[0] == '1')
        except Exception:
            return False

    def _toggle_lens_tree(self):
        """◀ = 렌즈트리 숨김(본문 +240px) / ▶ = 복원. 직전값 저장."""
        try:
            hidden = self._left_f not in [
                self._main_pw.nametowidget(p) for p in self._main_pw.panes()]
        except Exception:
            hidden = False
        try:
            if hidden:
                # ⚠ 그냥 add 하면 오른쪽 뒤에 붙는다 — before 로 제자리에
                self._main_pw.add(self._left_f, before=self._right_f, width=240)
            else:
                self._main_pw.forget(self._left_f)
        except Exception as e:
            print('[lens tree toggle] %s' % e)
            return
        try:
            conn = appdb.connect(self.db_path)
            c = conn.cursor()
            val = '0' if hidden else '1'
            c.execute('SELECT 1 FROM user_config WHERE config_key=? LIMIT 1',
                      (self._TREE_HIDE_KEY,))
            if c.fetchone():
                c.execute('UPDATE user_config SET config_val=? WHERE config_key=?',
                          (val, self._TREE_HIDE_KEY))
            else:
                c.execute('INSERT INTO user_config (config_key, config_val) '
                          'VALUES (?,?)', (self._TREE_HIDE_KEY, val))
            conn.commit()
            conn.close()
        except Exception as e:
            print('[lens tree save] %s' % e)
        self._sync_tree_toggle()

    def _sync_tree_toggle(self):
        btn = getattr(self, '_tree_toggle_btn', None)
        if btn is None or not btn.winfo_exists():
            return
        try:
            shown = self._left_f in [
                self._main_pw.nametowidget(p) for p in self._main_pw.panes()]
        except Exception:
            shown = True
        btn.config(text='◀' if shown else '▶')

    # ── 보기 방식 — 스크롤 / 페이지 (2026-08-17, 0.app수정.txt 4-1) ──────────

    _VIEW_MODE_KEY = 'LENS_VIEW_MODE'

    def _lens_view_mode(self) -> str:
        """'SCROLL'(기본) | 'PAGE'. 직전값 저장."""
        try:
            with appdb.connect(self.db_path) as conn:
                r = conn.execute('SELECT config_val FROM user_config '
                                 'WHERE config_key=? LIMIT 1',
                                 (self._VIEW_MODE_KEY,)).fetchone()
            if r and r[0] == 'PAGE':
                return 'PAGE'
        except Exception as e:
            print('[lens vmode] %s' % e)
        return 'SCROLL'

    def _set_lens_view_mode(self, mode, node_id, node_name, source):
        try:
            conn = appdb.connect(self.db_path)
            c = conn.cursor()
            c.execute('SELECT 1 FROM user_config WHERE config_key=? LIMIT 1',
                      (self._VIEW_MODE_KEY,))
            if c.fetchone():
                c.execute('UPDATE user_config SET config_val=? WHERE config_key=?',
                          (mode, self._VIEW_MODE_KEY))
            else:
                c.execute('INSERT INTO user_config (config_key, config_val) '
                          'VALUES (?,?)', (self._VIEW_MODE_KEY, mode))
            conn.commit()
            conn.close()
        except Exception as e:
            print('[lens vmode save] %s' % e)
        self._show_node_verse_sets(node_id, node_name, source)

    def _link_ref_label(self, v) -> str:
        """링크 하나의 약명 — 구간이면 `창 22:1-14` (페이지 단추 라벨)."""
        if not (v.get('bcode') and v.get('chapter') and v.get('verse')):
            return '?'
        bn = self._get_book_short_name(v['bcode'])
        ref = f"{bn} {v['chapter']}:{v['verse']}"
        ce, ve = v.get('chapter_end'), v.get('verse_end')
        if ve:
            ref += (f'-{ve}' if ce in (None, v['chapter']) else f'-{ce}:{ve}')
        return ref

    # ── 구절 딸림글 표시 설정 (2026-08-17 사용자 결정 「기본은 체크」) ─────────

    _VERS_SHOW_KEY = 'LENS_VERS_SHOW'

    def _vers_show(self) -> dict:
        """구절설명·묵상질문·묵상기도 표시 여부 — 기본은 **전부 표시**."""
        import json
        try:
            with appdb.connect(self.db_path) as conn:
                r = conn.execute('SELECT config_val FROM user_config '
                                 'WHERE config_key=? LIMIT 1',
                                 (self._VERS_SHOW_KEY,)).fetchone()
            if r and r[0]:
                d = json.loads(r[0])
                return {k: bool(d.get(k, 1)) for k in ('desc', 'question', 'prayer')}
        except Exception as e:
            print('[lens vshow] %s' % e)
        return {'desc': True, 'question': True, 'prayer': True}

    def _on_vers_show_toggle(self, node_id, node_name, source):
        """체크박스 토글 — 저장하고 그 자리에서 다시 그린다."""
        import json
        val = json.dumps({k: (1 if v.get() else 0)
                          for k, v in self._vshow_vars.items()})
        try:
            conn = appdb.connect(self.db_path)
            c = conn.cursor()
            c.execute('SELECT 1 FROM user_config WHERE config_key=? LIMIT 1',
                      (self._VERS_SHOW_KEY,))
            if c.fetchone():
                c.execute('UPDATE user_config SET config_val=? WHERE config_key=?',
                          (val, self._VERS_SHOW_KEY))
            else:
                c.execute('INSERT INTO user_config (config_key, config_val) '
                          'VALUES (?,?)', (self._VERS_SHOW_KEY, val))
            conn.commit()
            conn.close()
        except Exception as e:
            print('[lens vshow save] %s' % e)
        self._show_node_verse_sets(node_id, node_name, source,
                                   page=getattr(self, '_cur_page', None))


    # ── 외부 진입 API ────────────────────────────────────────────────────────

    def select_container(self, container_id: int, source: str = 'SYS'):
        """외부(나의 길 즐겨찾기 등)에서 컨테이너 직접 선택.
        source: 'SYS' (기본) | 'USER' (My Lens).
        트리 노드 선택 → _on_cat_tree_select 자동 트리거 → 우측 상세 갱신."""
        if not container_id:
            return
        prefix = 'CONT_U_' if source == 'USER' else 'CONT_S_'
        iid = f'{prefix}{container_id}'
        if not self._cat_tv.exists(iid):
            return
        # 부모 카테고리 펼침 보장
        parent_iid = self._cat_tv.parent(iid)
        if parent_iid:
            self._cat_tv.item(parent_iid, open=True)
        self._cat_tv.see(iid)
        self._cat_tv.selection_set(iid)
        self._cat_tv.focus(iid)

    # ── [Phase 2-F Turn 2] My Lens 도구 활성/비활성 ──────────────────────────

    def _set_my_lens_tools(self, *a, **kw):
        """(2026-08-15) 관리 요소를 화면에서 뺐다 — 할 일이 없다.

        ⚠ **부르는 곳을 지우지 않고 여기를 비웠다** — 여러 경로에서 불린다.
          호출부를 걷어내다 하나를 놓치면 조용히 터진다.
        """
        return
    def _set_node_tools(self, *a, **kw):
        """(2026-08-15) 관리 요소를 화면에서 뺐다 — 할 일이 없다.

        ⚠ **부르는 곳을 지우지 않고 여기를 비웠다** — 여러 경로에서 불린다.
          호출부를 걷어내다 하나를 놓치면 조용히 터진다.
        """
        return
    def _navigate_to_verse(self, vid):
        """[Step 3] 구절로 이동 — P1 탭1 + P4 캔버스 + P2 탭 자동 갱신."""
        if not vid or not self.on_verse_navigate:
            return
        try:
            self.on_verse_navigate(vid)
        except Exception as ex:
            import traceback
            print(f'[LensView] navigate error: {ex}')
            traceback.print_exc()

    # ── [Phase 2-F Turn 2] My Lens CRUD ─────────────────────────────────────
    # user_unit_asset / user_link_asset / user_text_asset 만 다룸.
    # USER 영역은 단일 사용자라 공유 자식 없음 → cascade 단순.

    def open_my_lens(self):
        """「My Lens」 관리 팝업 (2026-08-16 — `0.app수정.txt` 4-3).

        > 「상단 bar 오른쪽에 사용자의 관리버튼(My Lens)을 하나 만들고 별도 모달
        >  팝업화면에서 관리기능 수행하도록 수정」

        ⚠ **2026-08-15 에 편집 도구를 화면에서 걷어내며 「별도 관리 팝업이 맡는다」고
          적어 두고 그 팝업을 만들지 않았다** — 기능(`_add_my_lens` 등 11개)은 살아
          있는데 부르는 곳이 없었다. 이 팝업이 그 기능들을 모아 담는다.
        ★ **대상은 메인 화면의 지금 선택**이다 — 팝업이 따로 트리를 갖지 않는다.
          같은 트리를 두 벌 그리면 선택이 어긋난다. 팝업을 띄운 채 메인에서 다른
          렌즈를 고르면 팝업 머리글이 따라온다(`_sync_mylens_dlg`).
        ⚠ sys 렌즈를 고르면 편집 단추가 잠긴다 — **내 것만 고친다**(4-3 「user db 저장」).
        """
        if getattr(self, '_mylens_win', None) is not None:
            try:
                if self._mylens_win.winfo_exists():
                    self._mylens_win.lift()
                    return
            except Exception:
                pass
        win = tk.Toplevel(self)
        self._mylens_win = win
        win.title(i18n.t('LENS_MYLENS', 'My Edit — 렌즈 관리'))
        # ★ **세로로 길게, 화면 오른쪽에** (2026-08-17 3차 재설계 — 사용자
        #   「팝업 화면을 상하로 길게 만들어서 오른쪽으로 배치. 그래야 왼쪽에 각종
        #   입력사항 확인이 쉬움」). 리사이즈 없이도 내용이 한 화면에 다 들어와야
        #   한다(준수사항) — [렌즈][노드][구절] 모드 전환으로 높이를 아낀다.
        # ⚠ 예전 팝업(470×400 고정)은 **공유 행이 창 밖으로 잘려** 「내보내기 화면이
        #   없다」로 보였다 — 고정 크기 창에 행을 늘리면 늘어난 높이를 실측할 것.
        sw = win.winfo_screenwidth()
        sh = win.winfo_screenheight()
        h = min(830, sh - 90)
        win.geometry('460x%d+%d+40' % (h, sw - 478))
        win.transient(self.winfo_toplevel())
        win.resizable(True, True)

        self._ml_head = tk.Label(win, text='', anchor='w', font=('', 11, 'bold'),
                                 padx=10, pady=6)
        self._ml_head.pack(fill='x')
        tk.Label(win, text=i18n.t('LENS_MYLENS_HINT',
                                  '왼쪽 화면에서 선택한 렌즈·노드가 대상입니다. '
                                  '내가 만든 것(◈)만 고칠 수 있습니다.'),
                 anchor='w', justify='left', fg='#7F8C8D',
                 font=('', 9), padx=10).pack(fill='x')

        self._ml_btns = {}
        self._ml_texts = {}

        def tools(parent, items):
            fr = ttk.Frame(parent)
            fr.pack(fill='x', padx=4, pady=(2, 2))
            for key, txt, cmd in items:
                # ⚠ ttk 의 width 는 평균 글자폭 단위 — 한글은 두 칸을 먹는다.
                #   len+2 로 재면 「숨겨진 렌즈」가 잘렸다(사용자 「버튼 폭이 좁다」).
                w = 4 if len(txt) == 1 else max(6, len(txt) * 2 + 1)
                b = ttk.Button(fr, text=txt, width=w, command=cmd)
                b.pack(side='left', padx=1)
                self._ml_btns[key] = b
            return fr

        def editor(parent, key, label, height, expand=True):
            box = ttk.Frame(parent)
            box.pack(fill='both', expand=expand, padx=4, pady=(0, 4))
            hd = ttk.Frame(box)
            hd.pack(fill='x')
            ttk.Label(hd, text=label).pack(side='left')
            b = ttk.Button(hd, text=i18n.t('COMMON_SAVE', '저장'), width=6,
                           command=lambda k=key: self._ml_save(k))
            b.pack(side='right')
            self._ml_btns['save_' + key] = b
            t = tk.Text(box, height=height, wrap='word', bd=1)
            try:
                import theme_font
                theme_font.register(t, self.db_path, 'prose')
            except Exception:
                pass
            t.pack(fill='both', expand=True, pady=(1, 0))
            self._ml_texts[key] = t

        # ── 1단: 모드 전환 [렌즈][노드][구절] — 눌린 쪽이 지금 화면
        sw_row = ttk.Frame(win)
        sw_row.pack(fill='x', padx=8, pady=(2, 2))
        self._ml_mode_btns = {}
        for mkey, label in (('lens', i18n.t('LENS_ML_LENS', '내 렌즈')),
                            ('node', i18n.t('LENS_ML_NODE', '노드')),
                            ('verse', i18n.t('LENS_ML_VERSE', '구절'))):
            b = tk.Button(sw_row, text=label, bd=1, pady=3,
                          font=('', 10, 'bold'), cursor='hand2',
                          command=lambda m=mkey: self._ml_show_mode(m))
            b.pack(side='left', expand=True, fill='x', padx=2)
            self._ml_mode_btns[mkey] = b

        # ── 2단: 고른 모드의 관리 단추 + 글 (pack_forget 전환 — 리사이즈 없이도
        #   한 화면에 다 들어온다. §3 캔버스/트리뷰 통합과 같은 방식)
        holder = ttk.Frame(win)
        holder.pack(fill='both', expand=True, padx=8, pady=(2, 8))
        self._ml_mode_frames = {}

        lens_f = ttk.Frame(holder)
        self._ml_mode_frames['lens'] = lens_f
        tools(lens_f, [
            ('lens_add', i18n.t('COMMON_ADD', '추가'), self._add_my_lens),
            ('lens_ren', i18n.t('COMMON_NAME', '이름'), self._rename_my_lens),
            ('lens_up', '▲', lambda: self._move_my_lens(-1)),
            ('lens_dn', '▼', lambda: self._move_my_lens(1)),
            # ★ 「삭제」가 아니라 **「숨기기」** — 실제 동작(HIDE)과 말을 맞춘다
            #   (2026-08-17 사용자 지시). 진짜 삭제는 휴지통의 [완전 삭제]다.
            ('lens_del', i18n.t('LENS_HIDE_BTN', '숨기기'), self._delete_my_lens),
            ('trash_open', i18n.t('LENS_TRASH', '숨겨진 렌즈'),
             self._open_my_trash)])
        editor(lens_f, 'cont', i18n.t('LENS_ML_LDESC', '렌즈 설명'), 10)

        node_f = ttk.Frame(holder)
        self._ml_mode_frames['node'] = node_f
        tools(node_f, [
            ('node_add', i18n.t('COMMON_ADD', '추가'), self._add_my_node),
            ('node_ren', i18n.t('COMMON_NAME', '이름'), self._rename_my_node),
            ('node_up', '▲', lambda: self._move_my_node(-1)),
            ('node_dn', '▼', lambda: self._move_my_node(1)),
            ('node_del', i18n.t('LENS_HIDE_BTN', '숨기기'), self._delete_my_node)])
        editor(node_f, 'ndesc', i18n.t('LENS_ML_NDESC', '노드 설명'), 7)
        editor(node_f, 'nq', i18n.t('LENS_SHOW_VQ', '묵상질문'), 5)
        editor(node_f, 'np', i18n.t('LENS_SHOW_VP', '묵상기도'), 5)

        verse_f = ttk.Frame(holder)
        self._ml_mode_frames['verse'] = verse_f
        tools(verse_f, [
            ('vers_add', i18n.t('COMMON_ADD', '추가'),
             lambda: self._curr_node_id and (
                 self._add_my_verse(self._curr_node_id),
                 self._ml_reload_verses())),
            ('vers_up', '▲', lambda: self._ml_move_verse(-1)),
            ('vers_dn', '▼', lambda: self._ml_move_verse(1)),
            ('vers_del', i18n.t('LENS_HIDE_BTN', '숨기기'), self._ml_del_verse)])
        self._ml_verse_lb = tk.Listbox(verse_f, activestyle='none', height=6)
        self._ml_verse_lb.pack(fill='x', padx=4, pady=(0, 4))
        self._ml_verse_lb.bind('<<ListboxSelect>>',
                               lambda e: self._ml_load_link_desc())
        self._ml_verse_rows = []
        ttk.Label(verse_f, text=i18n.t('LENS_ML_BODY', '본문')).pack(
            anchor='w', padx=4)
        self._ml_body_txt = tk.Text(verse_f, height=8, wrap='word', bd=1,
                                    state='disabled')
        try:
            import theme_font
            theme_font.register(self._ml_body_txt, self.db_path, 'bible')
        except Exception:
            pass
        try:
            from reading_pane import enable_copy
            enable_copy(self._ml_body_txt)
        except Exception:
            pass
        self._ml_body_txt.pack(fill='both', expand=True, padx=4, pady=(1, 4))
        editor(verse_f, 'ldesc', i18n.t('LENS_ML_LINKDESC', '연결설명 (선택한 구절)'),
               5, expand=False)

        self._ml_show_mode(getattr(self, '_ml_mode', 'lens'))

        try:
            import ui_theme
            ui_theme.adopt(win)                    # 화면색·글꼴 (font.md §36-4)
        except Exception:
            pass
        win.bind('<Destroy>', lambda e: (setattr(self, '_mylens_win', None)
                                         if e.widget is win else None))
        self._sync_mylens_dlg()

    def _sync_mylens_dlg(self):
        """팝업 머리글·단추 상태를 지금 선택에 맞춘다."""
        win = getattr(self, '_mylens_win', None)
        if win is None:
            return
        try:
            if not win.winfo_exists():
                self._mylens_win = None
                return
        except Exception:
            return
        cid = getattr(self, '_curr_container_id', None)
        src = getattr(self, '_curr_container_source', 'SYS') or 'SYS'
        name = ''
        if cid:
            for d in self._cat_tree_data.values():
                if d.get('kind') == 'cont' and d.get('unit_id') == cid                         and d.get('source', 'SYS') == src:
                    name = d.get('name', '')
                    break
        mine = (src == 'USER')
        if not cid:
            head = i18n.t('LENS_ML_NONE', '(렌즈를 선택하세요)')
        elif mine:
            head = '✎ %s' % name
        else:
            head = '%s  —  %s' % (name, i18n.t('LENS_ML_SYS', '기본 렌즈(수정 불가)'))
        self._ml_head.config(text=head)
        # lens_add 는 늘 열린다(카테고리만 고르면 만든다). 나머지는 내 것일 때만.
        node_on = mine and getattr(self, '_curr_node_id', None) \
            and getattr(self, '_curr_node_source', 'SYS') == 'USER'
        for key, b in self._ml_btns.items():
            # ⚠ 내보내기/가져오기는 **상단 bar [공유하기]** 로 옮겼다
            #   (2026-08-21 `0.txt` 3번) — 여기 `share_*` 키는 이제 없다.
            if key in ('lens_add', 'trash_open'):
                b.config(state='normal')            # 늘 열린다
            elif key == 'save_cont' or key.startswith('lens_'):
                b.config(state='normal' if mine else 'disabled')
            elif key == 'node_add':
                b.config(state='normal' if mine else 'disabled')
            else:                       # node_* · vers_* · save_* — 내 노드 선택 시
                b.config(state='normal' if node_on else 'disabled')
        # 편집기 채우기 — 내 것이 아니면 비우고 잠근다
        texts = getattr(self, '_ml_texts', {})
        if texts:
            def fill(key, on, tt=None, tcid=None):
                t = texts.get(key)
                if t is None:
                    return
                t.config(state='normal')
                t.delete('1.0', 'end')
                if on and tt and tcid:
                    t.insert('1.0', self._fetch_my_text(tt, tcid))
                if not on:
                    t.config(state='disabled')
            fill('cont', mine, 'CONT_DESC', cid)
            nid = getattr(self, '_curr_node_id', None)
            fill('ndesc', node_on, 'NODE_DESC', nid)
            fill('nq', node_on, 'NODE_QUESTION', nid)
            fill('np', node_on, 'NODE_PRAYER', nid)
            self._ml_reload_verses()
            self._ml_load_link_desc()

    def _place_left_of_mylens(self, dlg, dy=60):
        """작은 팝업을 My Lens 창 **바로 왼쪽**에 (2026-08-17 사용자 지시
        「너무 왼쪽에 나타난다 — 겹치지 않게 바로 왼쪽에」)."""
        try:
            dlg.update_idletasks()
            # ⚠ geometry('300x…') 로 폭을 지정한 창은 reqwidth(내용물 폭)가 그보다
            #   작을 수 있다 — 둘 중 큰 값으로 계산해야 겹치지 않는다(실측으로 잡음)
            w = max(dlg.winfo_width(), dlg.winfo_reqwidth())
            anchor = getattr(self, '_mylens_win', None)
            if anchor is not None and anchor.winfo_exists():
                x = anchor.winfo_rootx() - w - 12
                y = anchor.winfo_rooty() + dy
            else:
                x = self.winfo_rootx() + 200
                y = self.winfo_rooty() + 120
            dlg.geometry('+%d+%d' % (max(0, x), max(0, y)))
        except Exception:
            pass

    def _open_my_trash(self):
        """삭제된(HIDE) 내 렌즈 목록 + 복구 (2026-08-17 사용자 물음 「어디에서
        조회해야 하는가」에 대한 답 — 트리에는 안 보이는 것이 맞고, 여기서 본다).

        삭제 직전의 카테고리(cat_id)가 그대로 남아 있으므로 **목록에 함께 보이고
        복구하면 그 자리로 돌아간다.**
        """
        dlg = tk.Toplevel(self)
        dlg.title(i18n.t('LENS_TRASH', '숨겨진 렌즈'))
        dlg.transient(self.winfo_toplevel())
        dlg.geometry('300x360')
        bar = ttk.Frame(dlg)
        bar.pack(fill='x', padx=6, pady=4)
        lb = tk.Listbox(dlg, activestyle='none')
        lb.pack(fill='both', expand=True, padx=8, pady=(0, 8))
        rows = []

        def cat_name(cat_id):
            if cat_id is None:
                return i18n.t('LENS_MYCAT', 'My 렌즈')
            try:
                with appdb.connect(self.db_path) as conn:
                    r = conn.execute(
                        """SELECT contents FROM sys_text_asset
                            WHERE text_type='PLAN_CAT_NAME' AND clicked_id=?
                              AND UPPER(lang_code)=UPPER(?)
                              AND record_status='LIVE' LIMIT 1""",
                        (cat_id, self._lang())).fetchone()
                return (r and r[0]) or ('카테고리 %s' % cat_id)
            except Exception:
                return '카테고리 %s' % cat_id

        def _reload():
            lb.delete(0, 'end')
            rows.clear()
            try:
                with appdb.connect(self.db_path) as conn:
                    for uid, nm, cat in conn.execute(
                            """SELECT user_unit_id, unit_name_sid, cat_id
                                 FROM user_unit_asset
                                WHERE unit_type='CONTAINER'
                                  AND record_status='HIDE'
                             ORDER BY user_unit_id DESC"""):
                        rows.append(uid)
                        lb.insert('end', '%s  (%s)' % (nm, cat_name(cat)))
            except Exception as e:
                print('[my trash] %s' % e)

        def _restore():
            i = lb.curselection()
            if not i:
                return
            uid = rows[i[0]]
            self._restore_my_lens(uid)
            _reload()
            self._load_category_tree()
            iid = f'CONT_U_{uid}'
            if self._cat_tv.exists(iid):
                self._cat_tv.selection_set(iid)
                self._cat_tv.see(iid)

        def _purge():
            i = lb.curselection()
            if not i:
                return
            uid = rows[i[0]]
            if not messagebox.askyesno(
                    i18n.t('LENS_PURGE', '완전 삭제'),
                    i18n.t('LENS_PURGE_Q',
                           '이 렌즈를 완전히 삭제합니다. 복구할 수 없습니다.\n'
                           '같은 이름을 다시 쓸 수 있게 됩니다. 진행할까요?'),
                    parent=dlg):
                return
            self._purge_my_lens(uid)
            _reload()

        ttk.Button(bar, text=i18n.t('COMMON_RESTORE', '복구'), width=8,
                   command=_restore).pack(side='left', padx=2)
        # ★ 완전 삭제 (2026-08-17 사용자 결정) — HIDE 행이 이름을 점유해서
        #   (unit_name_sid 전역 UNIQUE) 내보냈다 지운 렌즈를 다시 가져오면
        #   ` (2)` 가 붙었다. 휴지통 비우기가 이름을 해방한다.
        ttk.Button(bar, text=i18n.t('LENS_PURGE', '완전 삭제'), width=10,
                   command=_purge).pack(side='left', padx=2)
        ttk.Button(bar, text=i18n.t('COMMON_CLOSE', '닫기'), width=8,
                   command=dlg.destroy).pack(side='right', padx=2)
        _reload()
        self._place_left_of_mylens(dlg)
        try:
            import ui_theme
            ui_theme.adopt(dlg)
        except Exception:
            pass

    def _purge_my_lens(self, cid):
        """휴지통의 렌즈를 **물리 삭제** — 이름(전역 UNIQUE)을 해방한다.

        지우는 것: 렌즈·노드 본체, CONT_NODE·NODE_VERS 링크, 딸린 글 전부
        (CONT_DESC · NODE_DESC/QUESTION/PRAYER · NODE_VERS_DESC · 내 묵상
        UNODE_NOTE), 즐겨찾기 행. 휴지통에서만 부른다 — 복구 불가를 확인받는다.
        """
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            node_ids = [r[0] for r in c.execute(
                "SELECT target_id FROM user_link_asset "
                "WHERE link_type='CONT_NODE' AND clicked_id=?", (cid,))]
            if node_ids:
                qn = ','.join('?' * len(node_ids))
                links = [r[0] for r in c.execute(
                    f"SELECT user_link_id FROM user_link_asset "
                    f"WHERE link_type='NODE_VERS' AND clicked_id IN ({qn})",
                    node_ids)]
                if links:
                    ql = ','.join('?' * len(links))
                    c.execute(f"DELETE FROM user_text_asset "
                              f"WHERE text_type='NODE_VERS_DESC' "
                              f"AND clicked_id IN ({ql})", links)
                c.execute(f"DELETE FROM user_link_asset "
                          f"WHERE link_type='NODE_VERS' AND clicked_id IN ({qn})",
                          node_ids)
                c.execute(f"DELETE FROM user_text_asset "
                          f"WHERE text_type IN ('NODE_DESC','NODE_QUESTION',"
                          f"'NODE_PRAYER','UNODE_NOTE') AND clicked_id IN ({qn})",
                          node_ids)
                c.execute(f"DELETE FROM user_unit_asset "
                          f"WHERE user_unit_id IN ({qn})", node_ids)
            c.execute("DELETE FROM user_link_asset "
                      "WHERE link_type='CONT_NODE' AND clicked_id=?", (cid,))
            c.execute("DELETE FROM user_text_asset "
                      "WHERE text_type='CONT_DESC' AND clicked_id=?", (cid,))
            c.execute("DELETE FROM user_favorite "
                      "WHERE fav_type='CONTAINER' AND target_id=?", (cid,))
            c.execute("DELETE FROM user_unit_asset WHERE user_unit_id=?", (cid,))
            conn.commit()
        finally:
            conn.close()

    def _restore_my_lens(self, cid):
        """삭제 cascade 의 거울 — 렌즈·노드·링크·글을 함께 되살린다.

        ⚠ 관리자 sys 복구(Option A — 본체만)와 다르다. 사용자 렌즈는 단순 사용
          시나리오라 통째로 돌아오는 것이 기대 동작이다. 삭제 전에 「지움」으로
          일부러 숨긴 글이 함께 살아날 수 있는데, 그건 편집기에서 다시 지우면 된다.
        """
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            c.execute("UPDATE user_unit_asset SET record_status='LIVE' "
                      "WHERE user_unit_id=?", (cid,))
            c.execute("UPDATE user_text_asset SET record_status='LIVE' "
                      "WHERE text_type='CONT_DESC' AND clicked_id=? "
                      "AND record_status='HIDE'", (cid,))
            c.execute("UPDATE user_link_asset SET record_status='LIVE' "
                      "WHERE link_type='CONT_NODE' AND clicked_id=? "
                      "AND record_status='HIDE'", (cid,))
            node_ids = [r[0] for r in c.execute(
                "SELECT target_id FROM user_link_asset "
                "WHERE link_type='CONT_NODE' AND clicked_id=?", (cid,))]
            for nid in node_ids:
                c.execute("UPDATE user_unit_asset SET record_status='LIVE' "
                          "WHERE user_unit_id=?", (nid,))
                c.execute("UPDATE user_text_asset SET record_status='LIVE' "
                          "WHERE text_type IN ('NODE_DESC','NODE_QUESTION',"
                          "'NODE_PRAYER') AND clicked_id=? "
                          "AND record_status='HIDE'", (nid,))
                links = [r[0] for r in c.execute(
                    "SELECT user_link_id FROM user_link_asset "
                    "WHERE link_type='NODE_VERS' AND clicked_id=?", (nid,))]
                c.execute("UPDATE user_link_asset SET record_status='LIVE' "
                          "WHERE link_type='NODE_VERS' AND clicked_id=? "
                          "AND record_status='HIDE'", (nid,))
                if links:
                    q = ','.join('?' * len(links))
                    c.execute("UPDATE user_text_asset SET record_status='LIVE' "
                              "WHERE text_type='NODE_VERS_DESC' "
                              "AND clicked_id IN (%s) AND record_status='HIDE'"
                              % q, links)
            conn.commit()
        finally:
            conn.close()

    def _ml_show_mode(self, mode):
        """3단 전환 — [렌즈][노드][구절] 중 하나만 보인다(pack_forget)."""
        frames = getattr(self, '_ml_mode_frames', None)
        if not frames:
            return
        self._ml_mode = mode
        for k, f in frames.items():
            if k == mode:
                f.pack(fill='both', expand=True)
            else:
                f.pack_forget()
        for k, b in getattr(self, '_ml_mode_btns', {}).items():
            try:
                b.config(relief=('sunken' if k == mode else 'raised'))
            except Exception:
                pass

    # ── My Lens 큰 화면 — 편집기·구절 목록 헬퍼 (2026-08-17 재설계) ──────────

    def _fetch_my_text(self, tt, cid):
        """user_text_asset 글 하나 — ★ 언어 필터 없음 (언어 공통원칙)."""
        if not cid:
            return ''
        try:
            with appdb.connect(self.db_path) as conn:
                r = conn.execute(
                    """SELECT contents FROM user_text_asset
                        WHERE text_type=? AND clicked_id=?
                          AND COALESCE(record_status,'LIVE')='LIVE'
                        ORDER BY (UPPER(lang_code)=UPPER(?)) DESC,
                                 (UPPER(lang_code)='KO') DESC
                        LIMIT 1""", (tt, cid, self._lang())).fetchone()
            return (r[0] or '') if r else ''
        except Exception as e:
            print('[my text load] %s' % e)
            return ''

    def _save_my_text(self, tt, cid, body):
        """UPSERT — 빈 글이면 HIDE. 개행은 공백으로(한 줄 정책)."""
        body = ' '.join((body or '').split())
        try:
            conn = appdb.connect(self.db_path)
            c = conn.cursor()
            r = c.execute("""SELECT user_text_id FROM user_text_asset
                              WHERE text_type=? AND clicked_id=?
                                AND COALESCE(record_status,'LIVE')='LIVE'
                              LIMIT 1""", (tt, cid)).fetchone()
            if r:
                if body:
                    c.execute("UPDATE user_text_asset SET contents=?, "
                              "updated_at=DATETIME('now','localtime') "
                              "WHERE user_text_id=?", (body, r[0]))
                else:
                    c.execute("UPDATE user_text_asset SET record_status='HIDE' "
                              "WHERE user_text_id=?", (r[0],))
            elif body:
                c.execute("INSERT INTO user_text_asset (text_type, clicked_id, "
                          "lang_code, contents, record_status, created_at, "
                          "updated_at) VALUES (?,?,?,?,'LIVE',"
                          "DATETIME('now','localtime'),"
                          "DATETIME('now','localtime'))",
                          (tt, cid, self._lang(), body))
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print('[my text save] %s' % e)
            return False

    def _ml_sel_link(self):
        """구절 목록에서 선택한 (link_id, verse_id) — 없으면 None."""
        lb = getattr(self, '_ml_verse_lb', None)
        if lb is None or not lb.winfo_exists():
            return None
        i = lb.curselection()
        rows = getattr(self, '_ml_verse_rows', [])
        return rows[i[0]] if (i and i[0] < len(rows)) else None

    def _ml_reload_verses(self):
        lb = getattr(self, '_ml_verse_lb', None)
        if lb is None or not lb.winfo_exists():
            return
        lb.delete(0, 'end')
        self._ml_verse_rows = []
        nid = getattr(self, '_curr_node_id', None)
        if not (nid and getattr(self, '_curr_node_source', 'SYS') == 'USER'):
            return
        try:
            with appdb.connect(self.db_path) as conn:
                for lid, a, e in conn.execute(
                        """SELECT user_link_id, target_id, end_id
                             FROM user_link_asset
                            WHERE link_type='NODE_VERS' AND clicked_id=?
                              AND COALESCE(record_status,'LIVE')='LIVE'
                         ORDER BY sort_order, user_link_id""", (nid,)):
                    r = conn.execute('SELECT bcode, chapter, verse FROM '
                                     'bible_index WHERE verse_id=?', (a,)).fetchone()
                    label = ('%s %s:%s' % (self._get_book_short_name(r[0]),
                                           r[1], r[2])) if r else str(a)
                    if e and e != a:
                        r2 = conn.execute('SELECT chapter, verse FROM bible_index '
                                          'WHERE verse_id=?', (e,)).fetchone()
                        if r2:
                            label += ('-%s' % r2[1] if r2[0] == r[1]
                                      else '-%s:%s' % r2)
                    self._ml_verse_rows.append((lid, a, e))
                    lb.insert('end', label)
        except Exception as ex:
            print('[ml verses] %s' % ex)

    def _ml_load_link_desc(self):
        t = getattr(self, '_ml_texts', {}).get('ldesc')
        if t is None or not t.winfo_exists():
            return
        s = self._ml_sel_link()
        t.config(state='normal')
        t.delete('1.0', 'end')
        if s:
            t.insert('1.0', self._fetch_my_text('NODE_VERS_DESC', s[0]))
        else:
            t.config(state='disabled')
        self._ml_show_body(s)

    def _ml_show_body(self, s):
        """선택한 구절(구간)의 본문 — **사용자가 설정한 버전**으로 (2026-08-17
        사용자 지시 「구절추가하면 본문을 표시하라」)."""
        bt = getattr(self, '_ml_body_txt', None)
        if bt is None or not bt.winfo_exists():
            return
        bt.config(state='normal')
        bt.delete('1.0', 'end')
        if s:
            _lid, a, e = s
            last = e if (e and e > a) else a
            version = (self.version_getter() if callable(self.version_getter)
                       else 'KRV') or 'KRV'
            try:
                with appdb.connect(self.db_path) as conn:
                    lines = []
                    for vid in range(a, last + 1):
                        # ★ 합쳐진 절·없는 절도 뜻이 통하게(§verse_text)
                        _b = _vt.resolve(conn, vid, version)['text']
                        vn = conn.execute('SELECT verse FROM bible_index '
                                          'WHERE verse_id=?', (vid,)).fetchone()
                        if _b:
                            lines.append('%s %s' % (vn[0] if vn else '', _b))
                    bt.insert('1.0', '\n'.join(lines))
            except Exception as ex:
                print('[ml body] %s' % ex)
        bt.config(state='disabled')

    def _ml_move_verse(self, d):
        s = self._ml_sel_link()
        if s:
            self._move_my_verse(s[0], d)
            self._ml_reload_verses()

    def _ml_del_verse(self):
        s = self._ml_sel_link()
        if s:
            self._delete_my_verse(s[0])
            self._ml_reload_verses()

    def _ml_save(self, key):
        """큰 화면의 [저장] — 어느 편집기든 여기로 모인다."""
        texts = getattr(self, '_ml_texts', {})
        t = texts.get(key)
        if t is None:
            return
        body = t.get('1.0', 'end-1c')
        nid = getattr(self, '_curr_node_id', None)
        if key == 'cont':
            cid = self._curr_container_id
            if not (cid and self._curr_container_source == 'USER'):
                return
            if self._save_my_text('CONT_DESC', cid, body):
                self._load_container_detail(cid, 'USER')
            return
        if key == 'ldesc':
            s = self._ml_sel_link()
            if not s:
                return
            ok = self._save_my_text('NODE_VERS_DESC', s[0], body)
        else:
            if not (nid and self._curr_node_source == 'USER'):
                return
            tt = {'ndesc': 'NODE_DESC', 'nq': 'NODE_QUESTION',
                  'np': 'NODE_PRAYER'}[key]
            ok = self._save_my_text(tt, nid, body)
        if ok and nid:
            info = self._node_data.get(f'NODE_U_{nid}')
            if info:
                self._show_node_verse_sets(nid, info['name'], 'USER',
                                           page=getattr(self, '_cur_page', None))

    def _add_my_lens(self):
        """현재 선택된 카테고리에 My Lens 컨테이너 신규 생성."""
        # 선택된 카테고리 또는 부모 카테고리 — **None = 「나의 렌즈」**(사용자 전용,
        #   2026-08-17). sys 카테고리를 골랐으면 그 안에 넣는다(의견서 7 채택안).
        cat_id = None
        picked = False
        sel = self._cat_tv.selection()
        if sel:
            info = self._cat_tree_data.get(sel[0], {})
            if info.get('kind') in ('cat', 'cont'):
                cat_id = info.get('cat_id')
                picked = True
        if not picked:
            messagebox.showinfo(i18n.t('MSG_T_SELCAT', '카테고리 선택'),
                                  i18n.t('MSG_SELECT_CAT_LEFT', '좌측에서 카테고리를 먼저 선택하세요.'))
            return
        name = simpledialog.askstring('새 My Lens',
                                        f'카테고리에 추가할 렌즈 이름:',
                                        parent=self)
        if not name or not name.strip():
            return
        name = name.strip()
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            # ⚠ NULL 은 `=` 로 안 잡힌다 — 「나의 렌즈」(cat_id NULL)도 세려면 COALESCE
            row = c.execute('''SELECT COALESCE(MAX(sort_order),0) FROM user_unit_asset
                                WHERE unit_type='CONTAINER'
                                  AND COALESCE(cat_id,-1)=COALESCE(?,-1)''',
                              (cat_id,)).fetchone()
            sort_order = (row[0] or 0) + 10
            c.execute('''INSERT INTO user_unit_asset
                          (unit_type, unit_name_sid, sort_order, record_status, cat_id)
                          VALUES ('CONTAINER', ?, ?, 'LIVE', ?)''',
                      (name, sort_order, cat_id))
            conn.commit()
            new_id = c.lastrowid
        finally:
            conn.close()
        self._load_category_tree()
        new_iid = f'CONT_U_{new_id}'
        if self._cat_tv.exists(new_iid):
            self._cat_tv.see(new_iid)
            self._cat_tv.selection_set(new_iid)

    def _rename_my_lens(self):
        if not (self._curr_container_id and self._curr_container_source == 'USER'):
            return
        old = ''
        for d in self._cat_tree_data.values():
            if (d.get('kind') == 'cont' and d.get('source') == 'USER'
                    and d.get('unit_id') == self._curr_container_id):
                old = d.get('name', '')
                break
        new = simpledialog.askstring('이름 변경', '새 이름:',
                                       initialvalue=old, parent=self)
        if not new or not new.strip() or new.strip() == old:
            return
        conn = appdb.connect(self.db_path)
        try:
            conn.execute('UPDATE user_unit_asset SET unit_name_sid=? WHERE user_unit_id=?',
                          (new.strip(), self._curr_container_id))
            conn.commit()
        finally:
            conn.close()
        cur_id = self._curr_container_id
        self._load_category_tree()
        new_iid = f'CONT_U_{cur_id}'
        if self._cat_tv.exists(new_iid):
            self._cat_tv.selection_set(new_iid)

    def _move_my_lens(self, direction: int):
        """USER 렌즈 순서 이동 — 같은 카테고리(「나의 렌즈」=NULL 포함) 안에서만.

        ⚠ 렌즈는 노드와 달리 링크가 아니라 **자산 자체**(`user_unit_asset.sort_order`)
          를 옮긴다(관리자 `_move_container` 와 같은 방식). sort_order 가 겹치면
          10 단위로 다시 매긴 뒤 바꾼다.
        """
        if not (self._curr_container_id and self._curr_container_source == 'USER'):
            return
        cid = self._curr_container_id
        cat = None
        for d in self._cat_tree_data.values():
            if (d.get('kind') == 'cont' and d.get('source') == 'USER'
                    and d.get('unit_id') == cid):
                cat = d.get('cat_id')
                break
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            rows = c.execute('''SELECT user_unit_id FROM user_unit_asset
                WHERE unit_type='CONTAINER'
                  AND COALESCE(cat_id,-1)=COALESCE(?,-1)
                  AND COALESCE(record_status,'LIVE')='LIVE'
             ORDER BY sort_order, user_unit_id''', (cat,)).fetchall()
            ids = [r[0] for r in rows]
            if cid not in ids:
                return
            i = ids.index(cid)
            j = i + direction
            if j < 0 or j >= len(ids):
                return
            ids[i], ids[j] = ids[j], ids[i]
            for order, uid in enumerate(ids, 1):
                c.execute('UPDATE user_unit_asset SET sort_order=? '
                          'WHERE user_unit_id=?', (order * 10, uid))
            conn.commit()
        finally:
            conn.close()
        self._load_category_tree()
        iid = f'CONT_U_{cid}'
        if self._cat_tv.exists(iid):
            self._cat_tv.selection_set(iid)
            self._cat_tv.see(iid)

    # ── 공유하기 (2026-08-21 `0.txt` 3번) ────────────────────────────────
    def open_share(self):
        """「공유하기」 — 내보내기/가져오기 (렌즈묵상 상단 bar 단추).

        > 「My Lens 에 있는 내보내기/가져오기 기능을 상단에 별도 버튼을 배치하자.
        >  눈에 잘 보이도록, 버튼 이름은 "공유하기"가 어떨까?」 (사용자)

        ★ **My Lens 창 1단에서 옮겨 왔다** — 두 곳에 두면 어느 것이 진짜인지
          알 수 없다(같은 기능 두 곳 금지). 기능 자체(`_export_my_lens`·
          `_import_lens_file`)는 그대로 쓴다.
        ★ **대상은 메인 화면의 지금 선택**이다 — 팝업이 트리를 따로 갖지 않는다
          (My Lens 팝업과 같은 원칙). 렌즈를 바꾸면 머리글·단추가 따라온다.
        ⚠ 내보내기는 **내가 만든 렌즈(◈)만** — sys 렌즈는 모두가 이미 갖고 있어
          내보낼 이유가 없고, 가져오기는 늘 열려 있다(`나의 렌즈`로 들어간다).
        """
        win = getattr(self, '_share_win', None)
        if win is not None:
            try:
                if win.winfo_exists():
                    win.lift()
                    self._sync_share_dlg()
                    return
            except Exception:
                pass
        win = tk.Toplevel(self)
        self._share_win = win
        win.title(i18n.t('LENS_SHARE', '공유하기'))
        win.transient(self.winfo_toplevel())
        win.resizable(False, False)

        # ⚠ 단추는 맨 위 (§0 — 아래에 두면 창이 작을 때 잘려 안 보인다)
        bar = ttk.Frame(win)
        bar.pack(fill='x', padx=10, pady=(10, 4))
        self._share_btns = {}
        for key, txt, cmd in (
                ('exp', i18n.t('LENS_ML_EXPORT', '내보내기'), self._export_my_lens),
                ('imp', i18n.t('LENS_ML_IMPORT', '가져오기'), self._import_lens_file)):
            b = tk.Button(bar, text=txt, bd=1, padx=12, pady=4,
                          font=('', 10, 'bold'), cursor='hand2', command=cmd)
            b.pack(side='left', expand=True, fill='x', padx=3)
            self._share_btns[key] = b

        self._share_head = tk.Label(win, text='', anchor='w', font=('', 10, 'bold'),
                                    padx=10, pady=2)
        self._share_head.pack(fill='x')
        tk.Label(win, text=i18n.t(
            'LENS_SHARE_HINT',
            '내보내기는 왼쪽에서 선택한 내 렌즈(◈)를 파일로 저장합니다.\n'
            '가져온 렌즈는 「나의 렌즈」에 담깁니다.'),
            anchor='w', justify='left', font=('', 9), padx=10,
            pady=(0)).pack(fill='x', pady=(0, 10))

        try:
            import ui_theme
            ui_theme.adopt(win)
        except Exception:
            pass
        win.protocol('WM_DELETE_WINDOW',
                     lambda: (setattr(self, '_share_win', None), win.destroy()))
        self._sync_share_dlg()
        win.update_idletasks()
        # 렌즈묵상 화면 오른쪽 위 — 왼쪽 트리를 가리지 않는다
        try:
            top = self.winfo_toplevel()
            x = top.winfo_rootx() + max(0, top.winfo_width() - win.winfo_width() - 40)
            win.geometry('+%d+%d' % (x, top.winfo_rooty() + 90))
        except Exception:
            pass

    def _sync_share_dlg(self):
        """공유하기 팝업이 떠 있으면 지금 선택을 비춘다."""
        win = getattr(self, '_share_win', None)
        if win is None:
            return
        try:
            if not win.winfo_exists():
                self._share_win = None
                return
        except Exception:
            self._share_win = None
            return
        cid = getattr(self, '_curr_container_id', None)
        mine = (getattr(self, '_curr_container_source', 'SYS') == 'USER')
        name = ''
        if cid:
            for d in self._cat_tree_data.values():
                if (d.get('kind') == 'cont' and d.get('unit_id') == cid
                        and d.get('source', 'SYS') == ('USER' if mine else 'SYS')):
                    name = d.get('name', '')
                    break
        if not cid:
            head = i18n.t('LENS_ML_NONE', '(렌즈를 선택하세요)')
        elif mine:
            head = '✎ %s' % name
        else:
            head = '%s  —  %s' % (name, i18n.t('LENS_ML_SYS', '기본 렌즈(수정 불가)'))
        self._share_head.config(text=head)
        self._share_btns['exp'].config(state='normal' if mine else 'disabled')
        self._share_btns['imp'].config(state='normal')

    def _export_my_lens(self):
        """내 렌즈 → `.lens.json` 파일 (의견서 10 · 1단계)."""
        if not (self._curr_container_id and self._curr_container_source == 'USER'):
            return
        import lens_share
        conn = appdb.connect(self.db_path)
        try:
            d = lens_share.export_lens(conn, self._curr_container_id)
        finally:
            conn.close()
        if not d:
            return
        from tkinter import filedialog
        path = filedialog.asksaveasfilename(
            parent=self, defaultextension='.lens.json',
            initialfile='%s.lens.json' % d['lens'],
            filetypes=[(i18n.t('LENS_FILE', '렌즈 파일'), '*.lens.json'),
                       ('JSON', '*.json')])
        if not path:
            return
        import io as _io
        import json as _json
        with _io.open(path, 'w', encoding='utf-8') as f:
            f.write(_json.dumps(d, ensure_ascii=False, indent=1))
        messagebox.showinfo(i18n.t('LENS_ML_EXPORT', '내보내기'),
                            i18n.t('LENS_EXPORTED',
                                   '렌즈를 파일로 내보냈습니다.') + '\n' + path)

    def _import_lens_file(self):
        """`.lens.json` → **나의 렌즈**로 (미리보기 확인 후. sys 는 불가침)."""
        import lens_share
        from tkinter import filedialog
        path = filedialog.askopenfilename(
            parent=self,
            filetypes=[(i18n.t('LENS_FILE', '렌즈 파일'), '*.lens.json'),
                       ('JSON', '*.json')])
        if not path:
            return
        import json as _json
        try:
            draft = _json.load(open(path, encoding='utf-8'))
        except Exception as e:
            messagebox.showerror(i18n.t('LENS_ML_IMPORT', '가져오기'), str(e))
            return
        if not messagebox.askyesno(
                i18n.t('LENS_ML_IMPORT', '가져오기'),
                lens_share.preview(draft) + '\n'
                + i18n.t('LENS_IMPORT_Q', '「나의 렌즈」로 가져올까요?')):
            return
        conn = appdb.connect(self.db_path)
        try:
            # ★ 이름 중복 검사 → **사용자가 이름을 정한다** (2026-08-17 지시
            #   「중복검사를 한 후에 이름을 수정할 수 있으면 좋겠다」).
            #   자동 ` (2)` 꼬리표는 최후 안전망으로만 남는다.
            name_pick = (draft.get('lens') or '').strip() or '이름 없는 렌즈'
            while conn.execute(
                    'SELECT 1 FROM user_unit_asset WHERE unit_name_sid=? '
                    'LIMIT 1', (name_pick,)).fetchone():
                new = simpledialog.askstring(
                    i18n.t('LENS_ML_IMPORT', '가져오기'),
                    i18n.t('LENS_IMPORT_DUP',
                           '「{name}」 이름의 렌즈가 이미 있습니다.\n'
                           '가져올 이름을 입력하세요:').format(name=name_pick),
                    initialvalue=lens_share._unique_name(conn, name_pick),
                    parent=self)
                if not new or not new.strip():
                    return              # 취소
                name_pick = new.strip()
            _lid, name = lens_share.import_lens(conn, draft,
                                                name=name_pick)   # cat=None → 나의 렌즈
        except Exception as e:
            messagebox.showerror(i18n.t('LENS_ML_IMPORT', '가져오기'), str(e))
            return
        finally:
            conn.close()
        self._load_category_tree()
        messagebox.showinfo(i18n.t('LENS_ML_IMPORT', '가져오기'),
                            i18n.t('LENS_IMPORTED',
                                   '「{name}」 렌즈를 가져왔습니다.').format(name=name))

    def _delete_my_lens(self):
        """USER 컨테이너 cascade HIDE (단순 — 단일 사용자 가정)."""
        if not (self._curr_container_id and self._curr_container_source == 'USER'):
            return
        cid = self._curr_container_id
        # 영향 카운트
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            node_ids = [r[0] for r in c.execute(
                '''SELECT target_id FROM user_link_asset
                    WHERE link_type='CONT_NODE' AND clicked_id=?
                      AND COALESCE(record_status,'LIVE')='LIVE' ''',
                (cid,)).fetchall()]
        finally:
            conn.close()
        _nm = ''
        try:
            _nm = next((d.get('name') or '') for d in self._cat_tree_data.values()
                       if d.get('kind') == 'cont' and d.get('unit_id') == cid and d.get('source') == 'USER')
        except Exception:
            pass
        msg = i18n.t('PMV_DELPLAN_Q', '「%s」을(를) 삭제할까요? 쓴 묵상노트는 구절에 그대로 남습니다.') % _nm
        if not messagebox.askyesno(i18n.t('PMV_B_DELETE', '삭제'), msg, parent=self):
            return
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            # 컨테이너 본체
            c.execute("UPDATE user_unit_asset SET record_status='HIDE' "
                       "WHERE user_unit_id=?", (cid,))
            # CONT_DESC
            c.execute("UPDATE user_text_asset SET record_status='HIDE' "
                       "WHERE text_type='CONT_DESC' AND clicked_id=? "
                       "AND COALESCE(record_status,'LIVE')='LIVE'", (cid,))
            # CONT_NODE 링크
            c.execute("UPDATE user_link_asset SET record_status='HIDE' "
                       "WHERE link_type='CONT_NODE' AND clicked_id=? "
                       "AND COALESCE(record_status,'LIVE')='LIVE'", (cid,))
            # 각 자식 노드 cascade
            for nid in node_ids:
                self._cascade_hide_user_node(c, nid)
            conn.commit()
        finally:
            conn.close()
        self._curr_container_id = None
        self._curr_container_source = None
        self._load_category_tree()
        self._bar_sync()

    def _discard_draft(self, cid):
        """고치지 않고 닫은 초안 사본을 거둔다 — HIDE(cascade) + 원본 기록도 걷는다(원본이 다시 보인다)."""
        try:
            conn = appdb.connect(self.db_path)
            try:
                c = conn.cursor()
                node_ids = [r[0] for r in c.execute(
                    "SELECT target_id FROM user_link_asset WHERE link_type='CONT_NODE' AND clicked_id=? "
                    "AND COALESCE(record_status,'LIVE')='LIVE'", (cid,)).fetchall()]
                c.execute("UPDATE user_unit_asset SET record_status='HIDE' WHERE user_unit_id=?", (cid,))
                c.execute("UPDATE user_text_asset SET record_status='HIDE' WHERE text_type IN ('CONT_DESC','CONT_NAME') "
                          "AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'", (cid,))
                c.execute("UPDATE user_link_asset SET record_status='HIDE' WHERE link_type='CONT_NODE' "
                          "AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'", (cid,))
                for nid in node_ids:
                    self._cascade_hide_user_node(c, nid)
                try:
                    c.execute("DELETE FROM user_copy_origin WHERE kind='LENS' AND user_id=?", (cid,))
                except Exception:
                    pass
                conn.commit()
            finally:
                conn.close()
        except Exception as e:
            print('[lens draft discard] %s' % e)
            return
        if getattr(self, '_curr_container_id', None) == cid:
            self._curr_container_id = None
            self._curr_container_source = None
        self._load_category_tree()
        self._bar_sync()

    def _cascade_hide_user_node(self, c, node_id):
        """USER 노드 cascade HIDE — 호출자가 commit."""
        # 노드 본체
        c.execute("UPDATE user_unit_asset SET record_status='HIDE' WHERE user_unit_id=?",
                   (node_id,))
        # 노드의 글 — 질문·기도도 함께 (2026-08-17 빠져 있던 것을 채움)
        c.execute("UPDATE user_text_asset SET record_status='HIDE' "
                   "WHERE text_type IN ('NODE_DESC','NODE_QUESTION','NODE_PRAYER') "
                   "AND clicked_id=? "
                   "AND COALESCE(record_status,'LIVE')='LIVE'", (node_id,))
        # CONT_NODE 링크 (모든 부모)
        c.execute("UPDATE user_link_asset SET record_status='HIDE' "
                   "WHERE link_type='CONT_NODE' AND target_id=? "
                   "AND COALESCE(record_status,'LIVE')='LIVE'", (node_id,))
        # NODE_VERS 링크 + NODE_VERS_DESC
        nv_links = [r[0] for r in c.execute(
            "SELECT user_link_id FROM user_link_asset "
            "WHERE link_type='NODE_VERS' AND clicked_id=? "
            "AND COALESCE(record_status,'LIVE')='LIVE'", (node_id,)).fetchall()]
        if nv_links:
            ph = ','.join('?' * len(nv_links))
            c.execute(f"UPDATE user_text_asset SET record_status='HIDE' "
                       f"WHERE text_type='NODE_VERS_DESC' AND clicked_id IN ({ph}) "
                       f"AND COALESCE(record_status,'LIVE')='LIVE'", nv_links)
            c.execute(f"UPDATE user_link_asset SET record_status='HIDE' "
                       f"WHERE user_link_id IN ({ph})", nv_links)

    def _add_my_node(self):
        """현재 USER 컨테이너에 새 노드 생성."""
        if not (self._curr_container_id and self._curr_container_source == 'USER'):
            return
        name = simpledialog.askstring('새 노드', '노드 이름:', parent=self)
        if not name or not name.strip():
            return
        name = name.strip()
        cid = self._curr_container_id
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            c.execute('''INSERT INTO user_unit_asset
                          (unit_type, unit_name_sid, sort_order, record_status)
                          VALUES ('NODE', ?, 1, 'LIVE')''', (name,))
            new_node_id = c.lastrowid
            row = c.execute('''SELECT COALESCE(MAX(sort_order),0) FROM user_link_asset
                                WHERE link_type='CONT_NODE' AND clicked_id=?''',
                              (cid,)).fetchone()
            link_sort = (row[0] or 0) + 10
            c.execute('''INSERT INTO user_link_asset
                          (clicked_id, target_id, link_type, sort_order, record_status)
                          VALUES (?, ?, 'CONT_NODE', ?, 'LIVE')''',
                      (cid, new_node_id, link_sort))
            conn.commit()
        finally:
            conn.close()
        self._load_node_list(cid, 'USER')
        new_iid = f'NODE_U_{new_node_id}'
        if self._node_tv.exists(new_iid):
            self._node_tv.see(new_iid)
            self._node_tv.selection_set(new_iid)

    def _rename_my_node(self):
        if not (self._curr_node_id and self._curr_node_source == 'USER'):
            return
        old = self._node_data.get(f'NODE_U_{self._curr_node_id}', {}).get('name', '')
        new = simpledialog.askstring('노드 이름 변경', '새 이름:',
                                       initialvalue=old, parent=self)
        if not new or not new.strip() or new.strip() == old:
            return
        conn = appdb.connect(self.db_path)
        try:
            conn.execute('UPDATE user_unit_asset SET unit_name_sid=? WHERE user_unit_id=?',
                          (new.strip(), self._curr_node_id))
            conn.commit()
        finally:
            conn.close()
        cur = self._curr_node_id
        self._load_node_list(self._curr_container_id, 'USER')
        new_iid = f'NODE_U_{cur}'
        if self._node_tv.exists(new_iid):
            self._node_tv.selection_set(new_iid)

    def _move_my_node(self, direction: int):
        if not (self._curr_container_id and self._curr_node_id
                and self._curr_node_source == 'USER'):
            return
        cid = self._curr_container_id
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            rows = c.execute('''SELECT user_link_id, target_id, sort_order
                                  FROM user_link_asset
                                 WHERE link_type='CONT_NODE' AND clicked_id=?
                                   AND COALESCE(record_status,'LIVE')='LIVE'
                              ORDER BY sort_order, user_link_id''', (cid,)).fetchall()
            idx_map = {tgt: i for i, (_, tgt, _) in enumerate(rows)}
            cur_idx = idx_map.get(self._curr_node_id)
            if cur_idx is None:
                return
            new_idx = cur_idx + direction
            if new_idx < 0 or new_idx >= len(rows):
                return
            a_lid, _, a_sort = rows[cur_idx]
            b_lid, _, b_sort = rows[new_idx]
            c.execute('UPDATE user_link_asset SET sort_order=? WHERE user_link_id=?',
                       (b_sort, a_lid))
            c.execute('UPDATE user_link_asset SET sort_order=? WHERE user_link_id=?',
                       (a_sort, b_lid))
            conn.commit()
        finally:
            conn.close()
        cur = self._curr_node_id
        self._load_node_list(cid, 'USER')
        new_iid = f'NODE_U_{cur}'
        if self._node_tv.exists(new_iid):
            self._node_tv.selection_set(new_iid)

    def _delete_my_node(self):
        if not (self._curr_node_id and self._curr_node_source == 'USER'):
            return
        nid = self._curr_node_id
        msg = (f'노드를 cascade HIDE 하시겠습니까?\n\n'
                f'  • 노드 본체 + CONT_NODE 링크 + NODE_VERS 링크 + 노드 텍스트 자산 모두 HIDE\n\n'
                f'진행하시겠습니까?')
        if not messagebox.askyesno(i18n.t('MSG_T_DELNODE', '노드 삭제'), msg):
            return
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            self._cascade_hide_user_node(c, nid)
            conn.commit()
        finally:
            conn.close()
        self._load_node_list(self._curr_container_id, 'USER')
        self._show_node_placeholder()
        self._set_node_tools(add=True, rename=False, move=False, delete=False)

    def _add_my_verse(self, node_id: int):
        """USER 노드에 구절 추가 — **콤보로 단일/구간 모두** (2026-08-17 사용자
        지시 「예전처럼 콤보상자를 제공해라」+ 「범위 입력이 가능해야 한다」).

        끝 절을 고르면 구간 한 링크(end_id)로 들어간다 — sys 렌즈와 같은 방식이다.
        """
        if not node_id:
            return
        rng = self._pick_range_dialog()
        if not rng:
            return
        a, end = rng
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            dup = c.execute(
                "SELECT 1 FROM user_link_asset "
                "WHERE link_type='NODE_VERS' AND clicked_id=? AND target_id=? "
                "AND COALESCE(end_id,-1)=COALESCE(?,-1) "
                "AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
                (node_id, a, end)).fetchone()
            if dup:
                messagebox.showinfo(i18n.t('MSG_T_DUPLICATE', '중복'),
                                    i18n.t('LENS_RANGE_DUP',
                                           '이미 이 노드에 있는 구절입니다.'))
                return
            row = c.execute('''SELECT COALESCE(MAX(sort_order),0) FROM user_link_asset
                                WHERE link_type='NODE_VERS' AND clicked_id=?''',
                              (node_id,)).fetchone()
            sort_order = (row[0] or 0) + 10
            c.execute('''INSERT INTO user_link_asset
                          (clicked_id, target_id, end_id, link_type, sort_order,
                           record_status)
                          VALUES (?, ?, ?, 'NODE_VERS', ?, 'LIVE')''',
                      (node_id, a, end, sort_order))
            conn.commit()
        finally:
            conn.close()
        # 묵상 화면 다시 표시
        info = self._node_data.get(f'NODE_U_{node_id}')
        if info:
            self._show_node_verse_sets(node_id, info['name'], 'USER')

    def _move_my_verse(self, link_id: int, direction: int):
        """USER NODE_VERS 링크 순서 swap (위=-1, 아래=1)."""
        if not (link_id and self._curr_node_id and self._curr_node_source == 'USER'):
            return
        nid = self._curr_node_id
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            rows = c.execute('''SELECT user_link_id, sort_order FROM user_link_asset
                                 WHERE link_type='NODE_VERS' AND clicked_id=?
                                   AND COALESCE(record_status,'LIVE')='LIVE'
                              ORDER BY sort_order, user_link_id''', (nid,)).fetchall()
            idx_map = {lid: i for i, (lid, _) in enumerate(rows)}
            cur_idx = idx_map.get(link_id)
            if cur_idx is None:
                return
            new_idx = cur_idx + direction
            if new_idx < 0 or new_idx >= len(rows):
                return
            a_lid, a_sort = rows[cur_idx]
            b_lid, b_sort = rows[new_idx]
            c.execute('UPDATE user_link_asset SET sort_order=? WHERE user_link_id=?',
                       (b_sort, a_lid))
            c.execute('UPDATE user_link_asset SET sort_order=? WHERE user_link_id=?',
                       (a_sort, b_lid))
            conn.commit()
        finally:
            conn.close()
        info = self._node_data.get(f'NODE_U_{nid}')
        if info:
            self._show_node_verse_sets(nid, info['name'], 'USER')


    def _delete_my_verse(self, link_id: int):
        """NODE_VERS 링크 HIDE + NODE_VERS_DESC HIDE."""
        if not link_id:
            return
        if not messagebox.askyesno(i18n.t('MSG_T_DELVERSE', '구절 삭제'),
                                     i18n.t('MSG_HIDE_VERSE_Q', '구절 링크를 숨김(HIDE) 처리하시겠습니까?\n(NODE_VERS_DESC 텍스트도 함께 HIDE)')):
            return
        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            c.execute("UPDATE user_link_asset SET record_status='HIDE' "
                       "WHERE user_link_id=?", (link_id,))
            c.execute("UPDATE user_text_asset SET record_status='HIDE' "
                       "WHERE text_type='NODE_VERS_DESC' AND clicked_id=? "
                       "AND COALESCE(record_status,'LIVE')='LIVE'", (link_id,))
            conn.commit()
        finally:
            conn.close()
        # 카드 다시
        if self._curr_node_id and self._curr_node_source == 'USER':
            info = self._node_data.get(f'NODE_U_{self._curr_node_id}')
            if info:
                self._show_node_verse_sets(self._curr_node_id, info['name'], 'USER')

    def _pick_verse_dialog(self):
        """책/장/절 콤보 다이얼로그 → verse_id 반환 (취소 시 None)."""
        dlg = tk.Toplevel(self)
        dlg.title(i18n.t('WIN_SELECT_VERSE', '구절 선택'))
        dlg.transient(self.winfo_toplevel())
        dlg.grab_set()
        dlg.resizable(False, False)

        lang = self._lang()
        conn = appdb.connect(self.db_path)
        try:
            book_rows = conn.execute('''SELECT DISTINCT bi.bcode, bn.short_name, bn.full_name
                                          FROM bible_index bi
                                          LEFT JOIN book_names bn
                                            ON bn.book_code=bi.bcode AND bn.lang_code=?
                                         ORDER BY bi.bcode''', (lang,)).fetchall()
            if not book_rows:
                book_rows = conn.execute('''SELECT DISTINCT bi.bcode, bn.short_name, bn.full_name
                                              FROM bible_index bi
                                              LEFT JOIN book_names bn
                                                ON bn.book_code=bi.bcode AND bn.lang_code='KO'
                                             ORDER BY bi.bcode''').fetchall()
        finally:
            conn.close()
        book_map = {}
        book_labels = []
        for bcode, short_name, full_name in book_rows:
            label = f'{bcode:02d}. {short_name or full_name or "?"}'
            book_map[label] = bcode
            book_labels.append(label)

        frm = ttk.Frame(dlg, padding=10)
        frm.pack()
        ttk.Label(frm, text=i18n.t('LENS_BOOK','책:')).grid(row=0, column=0, sticky='w', pady=2)
        book_var = tk.StringVar()
        book_cb = ttk.Combobox(frm, textvariable=book_var, values=book_labels,
                                 width=22, state='readonly')
        book_cb.grid(row=0, column=1, padx=4, pady=2)

        ttk.Label(frm, text=i18n.t('LENS_CHAP','장:')).grid(row=1, column=0, sticky='w', pady=2)
        ch_var = tk.StringVar()
        ch_cb = ttk.Combobox(frm, textvariable=ch_var, values=[],
                              width=8, state='readonly')
        ch_cb.grid(row=1, column=1, sticky='w', padx=4, pady=2)

        ttk.Label(frm, text=i18n.t('LENS_VERSE','절:')).grid(row=2, column=0, sticky='w', pady=2)
        vs_var = tk.StringVar()
        vs_cb = ttk.Combobox(frm, textvariable=vs_var, values=[],
                              width=8, state='readonly')
        vs_cb.grid(row=2, column=1, sticky='w', padx=4, pady=2)

        preview_lbl = ttk.Label(frm, text='', foreground='#566573',
                                  font=('', 9))
        preview_lbl.grid(row=3, column=0, columnspan=2, sticky='w', pady=(8, 0))

        def _on_book(_e=None):
            bcode = book_map.get(book_var.get())
            if not bcode:
                return
            conn2 = appdb.connect(self.db_path)
            try:
                chs = [r[0] for r in conn2.execute(
                    'SELECT DISTINCT chapter FROM bible_index WHERE bcode=? ORDER BY chapter',
                    (bcode,)).fetchall()]
            finally:
                conn2.close()
            ch_cb.config(values=[str(c) for c in chs])
            ch_var.set(''); vs_cb.config(values=[]); vs_var.set('')
            preview_lbl.config(text='')

        def _on_ch(_e=None):
            bcode = book_map.get(book_var.get())
            ch = ch_var.get()
            if not bcode or not ch.isdigit():
                return
            conn2 = appdb.connect(self.db_path)
            try:
                vss = [(r[0], r[1]) for r in conn2.execute(
                    'SELECT verse, verse_id FROM bible_index WHERE bcode=? AND chapter=? ORDER BY verse',
                    (bcode, int(ch))).fetchall()]
            finally:
                conn2.close()
            dlg._vs_to_vid = {str(v): vid for v, vid in vss}
            vs_cb.config(values=[str(v) for v in dlg._vs_to_vid])
            vs_var.set(''); preview_lbl.config(text='')

        def _on_vs(_e=None):
            vid = getattr(dlg, '_vs_to_vid', {}).get(vs_var.get())
            if vid:
                preview_lbl.config(text=f'verse_id = {vid}')

        book_cb.bind('<<ComboboxSelected>>', _on_book)
        ch_cb.bind('<<ComboboxSelected>>', _on_ch)
        vs_cb.bind('<<ComboboxSelected>>', _on_vs)

        result = {'vid': None}

        def _ok():
            vid = getattr(dlg, '_vs_to_vid', {}).get(vs_var.get())
            if vid:
                result['vid'] = vid
            dlg.destroy()

        btn_row = ttk.Frame(frm); btn_row.grid(row=4, column=0, columnspan=2, pady=(10, 0))
        ttk.Button(btn_row, text=i18n.t('COMMON_ADD','추가'), command=_ok).pack(side='left', padx=4)
        ttk.Button(btn_row, text=i18n.t('COMMON_CANCEL','취소'), command=dlg.destroy).pack(side='left', padx=4)

        dlg.wait_window()
        return result['vid']

    def _pick_range_dialog(self):
        """책/장/절 **콤보** + 끝 절 콤보 → (시작 vid, 끝 vid|None).

        2026-08-17 사용자 지시 — 「예전처럼 콤보상자를 제공해라. 제거하라고 말한
        적 없다」+ 「범위 입력이 가능해야 한다」. 끝 절을 고르지 않으면 단일이다.
        """
        dlg = tk.Toplevel(self)
        dlg.title(i18n.t('LENS_ADDVERSE_T', '구절 추가'))
        dlg.transient(self.winfo_toplevel())
        dlg.grab_set()
        dlg.resizable(False, False)

        lang = self._lang()
        conn = appdb.connect(self.db_path)
        try:
            book_rows = conn.execute(
                '''SELECT DISTINCT bi.bcode, bn.short_name, bn.full_name
                     FROM bible_index bi
                     LEFT JOIN book_names bn
                       ON bn.book_code=bi.bcode AND bn.lang_code=?
                    ORDER BY bi.bcode''', (lang,)).fetchall()
        finally:
            conn.close()
        book_map = {}
        book_labels = []
        for bcode, short_name, full_name in book_rows:
            label = f'{bcode:02d}. {short_name or full_name or "?"}'
            book_map[label] = bcode
            book_labels.append(label)

        frm = ttk.Frame(dlg, padding=10)
        frm.pack()
        ttk.Label(frm, text=i18n.t('LENS_BOOK', '책:')).grid(
            row=0, column=0, sticky='w', pady=2)
        book_var = tk.StringVar()
        book_cb = ttk.Combobox(frm, textvariable=book_var, values=book_labels,
                               width=22, state='readonly')
        book_cb.grid(row=0, column=1, columnspan=3, sticky='w', padx=4, pady=2)

        ttk.Label(frm, text=i18n.t('LENS_CHAP', '장:')).grid(
            row=1, column=0, sticky='w', pady=2)
        ch_var = tk.StringVar()
        ch_cb = ttk.Combobox(frm, textvariable=ch_var, values=[],
                             width=6, state='readonly')
        ch_cb.grid(row=1, column=1, sticky='w', padx=4, pady=2)

        ttk.Label(frm, text=i18n.t('LENS_VERSE', '절:')).grid(
            row=2, column=0, sticky='w', pady=2)
        vs_var = tk.StringVar()
        vs_cb = ttk.Combobox(frm, textvariable=vs_var, values=[],
                             width=6, state='readonly')
        vs_cb.grid(row=2, column=1, sticky='w', padx=4, pady=2)
        ttk.Label(frm, text=i18n.t('LENS_VERSE_END', '끝 절(구간이면):')).grid(
            row=2, column=2, sticky='w', padx=(10, 0), pady=2)
        ve_var = tk.StringVar()
        ve_cb = ttk.Combobox(frm, textvariable=ve_var, values=[],
                             width=6, state='readonly')
        ve_cb.grid(row=2, column=3, sticky='w', padx=4, pady=2)

        preview_lbl = ttk.Label(frm, text='', foreground='#566573', font=('', 9))
        preview_lbl.grid(row=3, column=0, columnspan=4, sticky='w', pady=(8, 0))

        def _on_book(_e=None):
            bcode = book_map.get(book_var.get())
            if not bcode:
                return
            with appdb.connect(self.db_path) as c2:
                chs = [r[0] for r in c2.execute(
                    'SELECT DISTINCT chapter FROM bible_index WHERE bcode=? '
                    'ORDER BY chapter', (bcode,))]
            ch_cb.config(values=[str(c) for c in chs])
            ch_var.set('')
            vs_cb.config(values=[]); vs_var.set('')
            ve_cb.config(values=[]); ve_var.set('')
            preview_lbl.config(text='')

        def _on_ch(_e=None):
            bcode = book_map.get(book_var.get())
            ch = ch_var.get()
            if not bcode or not ch.isdigit():
                return
            with appdb.connect(self.db_path) as c2:
                vss = c2.execute(
                    'SELECT verse, verse_id FROM bible_index WHERE bcode=? '
                    'AND chapter=? ORDER BY verse', (bcode, int(ch))).fetchall()
            dlg._vs_to_vid = {str(v): vid for v, vid in vss}
            vals = [str(v) for v, _ in vss]
            vs_cb.config(values=vals); vs_var.set('')
            ve_cb.config(values=[''] + vals); ve_var.set('')
            preview_lbl.config(text='')

        def _cur_range():
            m = getattr(dlg, '_vs_to_vid', {})
            a = m.get(vs_var.get())
            b = m.get(ve_var.get())
            if a and b and b < a:
                a, b = b, a
            return a, (b if (a and b and b != a) else None)

        def _on_pick(_e=None):
            a, b = _cur_range()
            if a:
                preview_lbl.config(text='%s%s' % (
                    vs_var.get(), ('-%s' % ve_var.get()) if b else ''))

        book_cb.bind('<<ComboboxSelected>>', _on_book)
        ch_cb.bind('<<ComboboxSelected>>', _on_ch)
        vs_cb.bind('<<ComboboxSelected>>', _on_pick)
        ve_cb.bind('<<ComboboxSelected>>', _on_pick)

        result = {'rng': None}

        def _ok():
            a, b = _cur_range()
            if a:
                result['rng'] = (a, b)
            dlg.destroy()

        btn_row = ttk.Frame(frm)
        btn_row.grid(row=4, column=0, columnspan=4, pady=(10, 0))
        ttk.Button(btn_row, text=i18n.t('COMMON_ADD', '추가'),
                   command=_ok).pack(side='left', padx=4)
        ttk.Button(btn_row, text=i18n.t('COMMON_CANCEL', '취소'),
                   command=dlg.destroy).pack(side='left', padx=4)
        try:
            import ui_theme
            ui_theme.adopt(dlg)
        except Exception:
            pass
        # My Lens 창 바로 왼쪽에 (2026-08-17 사용자 지시)
        self._place_left_of_mylens(dlg)
        dlg.wait_window()
        return result['rng']

    def _get_book_short_name(self, bcode) -> str:
        """책 약명 조회 (캐싱). 사용자 lang → KO 폴백 → bcode 문자열."""
        lang = self._lang()
        cache_key = (bcode, lang)
        if cache_key in self._book_name_cache:
            return self._book_name_cache[cache_key]

        conn = appdb.connect(self.db_path)
        try:
            c = conn.cursor()
            c.execute('''SELECT short_name FROM book_names
                          WHERE book_code=? AND lang_code=? LIMIT 1''',
                      (bcode, lang))
            row = c.fetchone()
            if not row and lang != 'KO':
                c.execute('''SELECT short_name FROM book_names
                              WHERE book_code=? AND lang_code='KO' LIMIT 1''',
                          (bcode,))
                row = c.fetchone()
            name = row[0] if row else str(bcode)
            self._book_name_cache[cache_key] = name
            return name
        finally:
            conn.close()


# ═══════════════════════════════════════════════════════════════════════════
# [구식] AppContent — Phase 2-E 이전의 ComponentFactory 기반 화면. 롤백용 보존.
# ═══════════════════════════════════════════════════════════════════════════

class AppContent:
    def __init__(self, parent_frame, engine):
        self.parent_frame = parent_frame
        self.engine = engine 
        self.mode = getattr(engine, 'mode', 'user_admin') 
        self.admin_mode = getattr(engine, 'admin_mode', True)
        
        self.comp_widgets = {}
        self.setup_layout()
        self.load_init()

    def load_init(self):
        """[초기화] 화면 시작 시 전체 목록을 불러옵니다."""
        self.load_panel('CONT_list')
        self.load_panel('NODE_list')

    def setup_layout(self):
        """[레이아웃 최종 확정] 수평 4단 전역 제어 및 수직 독립 제어 구조를 구현했습니다."""
        # 🎯 메인 수직 PanedWindow (4개의 수평 층 생성)
        main_v_pw = tk.PanedWindow(self.parent_frame, orient="vertical", sashwidth=6, bg="#AEB6BF")
        main_v_pw.pack(fill="both", expand=True)

        # --- 🎯 Tier 1 (LIST): Tier 1-1 (CONT_list) / Tier 1-2 (CN_list) / Tier 1-3 (NODE_list) ---
        t1_h_pw = tk.PanedWindow(main_v_pw, orient="horizontal", bg="#ABB2B9")
        main_v_pw.add(t1_h_pw, height=250)
        for comp in ['CONT_list', 'CN_list', 'NODE_list']:
            f, w = ComponentFactory.create(t1_h_pw, comp, mode=self.mode)
            t1_h_pw.add(f, width=450)
            self.comp_widgets[comp] = w

        # --- 🎯 Tier 2 (DESC) : Tier 2-1 (CONT_desc) / Tier 2-2 (CN_desc) / Tier 2-3 (NODE_desc) ---
        t2_h_pw = tk.PanedWindow(main_v_pw, orient="horizontal", bg="#ABB2B9")
        main_v_pw.add(t2_h_pw, height=180)
        for comp in ['CONT_desc', 'CN_desc', 'NODE_desc']:
            f, w = ComponentFactory.create(t2_h_pw, comp, mode=self.mode)
            t2_h_pw.add(f, width=450)
            self.comp_widgets[comp] = w

        # --- 🎯 Tier 3: Tier 3-1 (COMM_desc) / Tier 3-2 (NV_list) ---
        t3_h_pw = tk.PanedWindow(main_v_pw, orient="horizontal", bg="#ABB2B9")
        main_v_pw.add(t3_h_pw, height=220)
        for comp in ['COMM_desc', 'NV_list']:
            f, w = ComponentFactory.create(t3_h_pw, comp, mode=self.mode)
            t3_h_pw.add(f, width=700 if comp == 'COMM_desc' else 900)
            self.comp_widgets[comp] = w
            if comp == 'NV_list': self._setup_bible_selector(w['verse_hub'])

        # --- 🎯 Tier 4: Tier 4-1 (NV_desc) / Tier 4-2(QUESTION_desc) / Tier 4-3(PRAYER_desc) ---
        t4_h_pw = tk.PanedWindow(main_v_pw, orient="horizontal", bg="#ABB2B9")
        main_v_pw.add(t4_h_pw, height=200)
        for comp in ['NV_desc', 'QUESTION_desc', 'PRAYER_desc']:
            f, w = ComponentFactory.create(t4_h_pw, comp, mode=self.mode)
            t4_h_pw.add(f, width=600 if comp == 'NV_desc' else 450)
            self.comp_widgets[comp] = w

        # 🎯 모든 컴포넌트 버튼 및 트리뷰 이벤트 통합 배선
        self._bind_all_widgets()

    def _bind_all_widgets(self):
        """[최종 확정] FocusOut 자동 저장과 콤보박스 즉시 집행 로직을 신경계에 주입합니다."""
        for name, widgets in self.comp_widgets.items():
            # 1. 🎯 [이동 버튼] Up/Down 등 물리 이동 버튼 배선 (저장 버튼은 제외됨)
            for btn in ['up', 'down']:
                if btn in widgets:
                    widgets[btn].config(command=lambda n=name, a=btn: self.on_universal_action(n, a))
            
            # 2. 🎯 [자동 저장] 설명창(desc) 포커스 아웃 시 즉시 save 실행
            if 'desc' in widgets:
                # 사용자가 수정을 마치고 다른 패널을 클릭하거나 리스트를 선택하면 자동 저장
                widgets['desc'].bind("<FocusOut>", 
                    lambda e, n=name: self.on_universal_action(n, 'save'))
            
            # 3. 🎯 [즉시 집행] 콤보박스에서 액션 선택 즉시 라우터 가동
            if 'combo' in widgets:
                widgets['combo'].bind("<<ComboboxSelected>>", 
                    lambda e, n=name: self.on_universal_action(n, 'combo_change'))
            
            # 4. 🎯 [선택 전파] 트리뷰 항목 선택 시 하위 패널 로드 유지
            if 'tree' in widgets:
                widgets['tree'].bind("<<TreeviewSelect>>", lambda e, n=name: self.on_universal_select(n))

    def on_universal_select(self, comp_name):
        """[정상화] 오직 트리뷰 선택에 따른 데이터 동기화와 하위 패널 로드만 담당합니다."""
        widgets = self.comp_widgets.get(comp_name)
        if not widgets or 'tree' not in widgets: return
        
        sel = widgets['tree'].selection()
        if not sel: return
        
        # 1. 데이터 캐시 확보 및 현재 레코드 업데이트
        data = widgets.get('data_cache', {}).get(sel[0])
        if not data: return
        widgets['curr_record'] = data 

        # 2. 상위 ID 보존 (연결 기능을 위함)
        if comp_name == 'CONT_list': self.last_cont_id = data['pk']
        elif comp_name == 'NODE_list': self.last_node_id = data['pk']

        # 3. 리스트 하단 Footer(부모/태그 칩) 갱신
        nav = NAV_REGISTRY.get(comp_name)
        if 'footer_f' in widgets:
            adj = self.engine.get_adjacent_assets(nav['tgt'], data['pk'], mode=self.mode)
            if adj:
                tags = [f"#{self._truncate_chip(t)}" for t in adj.get('tags', [])]
                parents = [] if comp_name == 'CONT_list' else [self._truncate_chip(p) for p in adj.get('parents', [])]
                self._render_list_footer(
                    widgets['footer_f'], parents, tags, 
                    on_add_tag=lambda: self.open_tag_popup(comp_name, data['pk'])
                )

        # 4. 하위 패널 연쇄 로드 (EVENT_MAP 기준)
        for trigger in EVENT_MAP.get(comp_name, []):
            self.load_panel(trigger['comp'], data.get('target_id') if trigger.get('use_target') else data['pk'])

    def load_panel(self, comp_name, source_id=None, clicked_name=None, parent_source=None):
        """[에러 해결] data_cache 초기화 한 줄을 넣어 시동 KeyError를 차단합니다."""
        nav = NAV_REGISTRY.get(comp_name); widgets = self.comp_widgets.get(comp_name)
        if not nav or not widgets: return
        if source_id is not None: widgets['curr_source_id'] = source_id
        filters = nav.get('filter', {}).copy()
        if widgets.get('curr_source_id'):
            s_key = nav.get('src_key', 'pk')
            if not comp_name.endswith('_list') or s_key != 'pk': filters[s_key] = widgets['curr_source_id']
        res = self.engine.process('FETCH', nav['tgt'], filters=filters, mode=self.mode)
        data = res.get('data', []); widgets['curr_record'] = data[0] if data else None
        if 'tree' in widgets:
            tree = widgets['tree']; tree.delete(*tree.get_children()); tree.tag_configure('hidden', foreground='gray')
            # 🎯 [핵심 수리] KeyError 방지용 초기화
            widgets['data_cache'] = {} 
            for r in data:
                fmt_d = self.engine._apply_display_policy(r, nav['tgt'])
                display_name, pk, status = fmt_d['fetch_name'], fmt_d['pk'], r.get('record_status', 'LIVE')
                tag = 'hidden' if status == 'HIDE' else ''
                vals = (display_name, pk, status, r.get('target_status', 'LIVE')) if comp_name == 'CN_list' else (display_name, pk, status)
                iid = tree.insert("", "end", values=vals, tags=(tag,)); widgets['data_cache'][iid] = r
        if 'desc' in widgets:
            curr_stat = widgets['curr_record'].get('record_status') if widgets.get('curr_record') else 'LIVE'
            BibleUI.render_flow_header(widgets, parents=[], tags=[], mode=self.mode, current_status=curr_stat, on_add_tag=None)
            widgets['desc'].delete("1.0", "end")
            if data:
                content = data[0].get('contents', '')
                if curr_stat == 'HIDE': widgets['desc'].config(bg="#F2F4F4", fg="gray"); widgets['desc'].insert("1.0", i18n.t('LENS_HIDE_PREFIX', '[HIDE 상태] {content}').format(content=content))
                else: widgets['desc'].config(bg="white", fg="black"); widgets['desc'].insert("1.0", content)

    def _truncate_chip(self, name):
        """[복구] 칩 렌더링을 위한 글자 생략 메서드입니다."""
        if not name: return ""
        w = 0; res = ""
        for c in name:
            w += 2 if ord(c) > 127 else 1
            if w > 8: return res + ".."
            res += c
        return res

    ### p1, p2, p3 패널에서 콤보박스에 의한 조치 관리
    def on_universal_action(self, comp_name, action_type):
        """[정상화] 콤보박스와 버튼에 의한 모든 '조치'를 여기서 집중 관리합니다."""
        widgets = self.comp_widgets.get(comp_name)
        nav = NAV_REGISTRY.get(comp_name)
        if not widgets or not nav: return

        # 🎯 A. 콤보박스 상태 변경 처리
        if action_type == 'combo_change':
            user_select = widgets['combo'].get()
            sel = widgets['tree'].selection() if 'tree' in widgets else None
            r = widgets.get('data_cache', {}).get(sel[0]) if sel else widgets.get('curr_record')
            curr_stat = r.get('record_status', 'LIVE') if r else 'LIVE'

            if user_select == curr_stat: return

            # 철옹성 정책: 신규 생성 외 조치는 허용 목록(allowed_actions) 체크
            if user_select not in ['NEW', 'ADD_LINK']:
                if r and user_select not in r.get('allowed_actions', []):
                    messagebox.showwarning(i18n.t('MSG_T_ACTIONREFUSED', "조치 거부"), i18n.t('MSG_ACTION_IMPOSSIBLE', "'{sel}' 조치는 불가능합니다.").format(sel=user_select))
                    widgets['combo'].set(curr_stat); return

            # 조치 집행 분기
            if user_select == 'NEW': self._handle_add(comp_name, nav)
            elif user_select == 'ADD_LINK': self._handle_link(comp_name, widgets, nav)
            elif user_select == 'EDIT': self._handle_rename(comp_name, widgets, nav)
            elif user_select in ['DELETE', 'UNLINK', 'HIDE']:
                self._handle_delete(comp_name, widgets, nav, is_physical=(user_select != 'HIDE'))
            
            widgets['combo'].set('LIVE') # 작업 후 리셋
            return

        # 🎯 B. 버튼 및 기타 직접 액션 처리
        if action_type == 'add': self._handle_add(comp_name, nav)
        elif action_type in ['del', 'delete']: self._handle_delete(comp_name, widgets, nav, is_physical=True)
        elif action_type in ['link', 'add_link']: self._handle_link(comp_name, widgets, nav)
        elif action_type == 'rename': self._handle_rename(comp_name, widgets, nav)
        elif action_type in ['up', 'down']: self._handle_reorder(comp_name, widgets, nav, action_type)
        elif action_type == 'save': self._handle_save(comp_name, widgets, nav)


    def _handle_add(self, comp_name, nav):
        """[전담] UNIT/TAG 신규 추가 팝업 관리"""
        asset_type = nav.get('tgt')
        
        # 🎯 1. [유닛 생성] P1, P3 패널에서 새로운 독립 컨테이너/노드 추가
        if asset_type == 'UNIT':
            self.open_add_popup(comp_name) 
            
        # 🎯 2. [태그 생성] 태그 허브 패널에서 신규 태그 생성
        elif asset_type == 'TAG':
            from ui_components import TagSelectionPopup
            TagSelectionPopup(
                self.parent_frame, self.engine, 
                asset_id=None, link_type=None, 
                on_refresh_callback=lambda: self.load_panel(comp_name)
            )
        
        # 🎯 [자동 리셋] 작업 완료 후 콤보박스를 'LIVE'로 되돌립니다.
        widgets = self.comp_widgets.get(comp_name)
        if widgets and 'combo' in widgets:
            widgets['combo'].set('LIVE')

    def _handle_link(self, comp_name, widgets, nav):
        if comp_name == 'CN_list':
            target_parent_id = getattr(self, 'last_cont_id', None)
        else: # NV_list인 경우
            target_parent_id = getattr(self, 'last_node_id', None)
        
        if not target_parent_id:
            messagebox.showwarning(i18n.t('COMMON_NOTICE', "알림"), i18n.t('MSG_SELECT_PARENT', "연결을 시작할 부모 자산을 먼저 선택하십시오.")); return

        new_link = {
            'data_src': 'USER', 'record_status': 'NEW', 
            'clicked_id': target_parent_id, **nav.get('filter', {})
        }
        
        # 🎯 목적지(Node 또는 Bible) 결정
        if comp_name == 'CN_list':
            n_id = getattr(self, 'last_node_id', None)
            if not n_id: messagebox.showwarning(i18n.t('COMMON_NOTICE', "알림"), i18n.t('MSG_SELECT_NODE', "연결할 노드(P3)를 선택하십시오.")); return
            new_link['target_id'] = n_id
        elif comp_name == 'NV_list' and 'verse_hub' in widgets:
            vid = widgets['verse_hub'].selected_verse_id
            if not vid: messagebox.showwarning(i18n.t('COMMON_NOTICE', "알림"), i18n.t('MSG_SELECT_VERSE_LINK', "연결할 성경 구절을 선택하십시오.")); return
            new_link['target_id'] = vid

        # 🎯 이제 정확한 부모 ID로 엔진에 요청합니다.
        res = self.engine.process('SAVE', 'LINK', filters=new_link)
        if res.get('status') == 'success':
            self.load_panel(comp_name, target_parent_id)
        else:
            messagebox.showerror(i18n.t('MSG_T_LINKFAIL', "연결 실패"), res.get('message'))

    def _handle_save(self, comp_name, widgets, nav):
        """[최종] 변경 시에만 저장하며, 중복/보안/회귀 에러를 모두 처리합니다."""
        sel = widgets['tree'].selection() if 'tree' in widgets else None
        r = widgets.get('data_cache', {}).get(sel[0]) if sel else widgets.get('curr_record')
        
        if not r:
            # 신규 데이터 생성을 위한 기본 틀 준비
            r = {'pk': None, 'data_src': 'USER', 'record_status': 'NEW', 
                 'clicked_id': widgets.get('curr_source_id'),
                 'text_type': nav.get('filter', {}).get('text_type')}
        
        save_data = r.copy()
        if nav.get('tgt') == 'TEXT':
            save_data['lang_code'] = self.engine.config.get('config_lang', 'EN')

        # 1. 데이터 변경 확인 (Dirty Check)
        has_changed = False
        for col, widget in widgets.items():
            if col in ['unit_name_sid', 'contents', 'desc']:
                # 텍스트 위젯에서 공백을 제거하고 현재 값을 가져옴
                current_val = widget.get("1.0", "end-1c").strip()
                # 데이터 캐시의 원본 값과 대조
                original_val = (r.get('contents' if col == 'desc' else col) or "").strip()

                if current_val != original_val:
                    save_data['contents' if col == 'desc' else col] = current_val
                    has_changed = True

        # 변경 사항이 없으면 엔진 호출 없이 즉시 종료 (에러 로그 방지)
        if not has_changed:
            return

        # 🎯 [하이브리드 정책] SYS 데이터는 사용자 모드에서 수정 불가.
        # 관리자가 작성한 컨텐츠는 읽기 전용. 사용자는 새 항목 추가만 가능.
        if r.get('data_src') == 'SYS' and self.mode != 'sys':
            messagebox.showinfo(
                i18n.t('MSG_T_NOEDIT', "수정 불가"),
                "관리자가 작성한 데이터는 수정할 수 없습니다.\n"
                "필요하면 새로운 항목을 추가하세요."
            )
            # 위젯을 원본 값으로 되돌리기 위해 패널 새로고침
            self.load_panel(comp_name, widgets.get('curr_source_id'))
            return

        # 2. 엔진 저장 요청 및 결과 처리
        try:
            res = self.engine.process('SAVE', nav['tgt'], filters=save_data)

            if res.get('status') == 'success':
                # 저장 성공 시 해당 패널만 새로고침 (불필요한 전체 리로드 방지)
                self.load_panel(comp_name, widgets.get('curr_source_id'))
            else:
                messagebox.showerror(i18n.t('MSG_T_SAVEFAIL', "저장 실패"), res.get('message', i18n.t('MSG_UNKNOWN_ERROR', "알 수 없는 오류가 발생했습니다.")))

        except (PermissionError, ValueError, Exception) as e:
            # 중복 에러(ValueError) 등 모든 예외 상황을 팝업으로 사용자에게 알림
            messagebox.showerror(i18n.t('MSG_T_ERROROCCUR', "오류 발생"), str(e))

##### 예외적으로 사용자가 SYS 데이터의 sort_order를 직접 수정할 수 있음 ##### 
##### 관리자가 DB importing 할 때 sort_order 컬럼은 제외해야 함            #####
    def _handle_reorder(self, comp_name, widgets, nav, direction):
        """[최종 수리] 쉐도우 복제 없이 원본 SYS의 sort_order를 직접 수정합니다."""
        tree = widgets['tree']
        sel = tree.selection()
        if not sel: return
        
        iid = sel[0]
        items = list(tree.get_children(''))
        curr_idx = items.index(iid)
        
        target_idx = curr_idx - 1 if direction == 'up' else curr_idx + 1
        if not (0 <= target_idx < len(items)): return 

        # 1. 🎯 UI 물리 이동
        tree.move(iid, '', target_idx)
        
        # 2. 🎯 [직접 수정 집행] 모든 항목의 순서를 재계산하여 DB에 직접 투사
        new_items = tree.get_children('')
        for idx, item_iid in enumerate(new_items):
            r = widgets['data_cache'].get(item_iid)
            if not r: continue
            
            new_so = (idx + 1) * 10
            # 💡 값이 변한 항목에 대해서만 SAVE 요청 (필드: pk, data_src, sort_order)
            if r.get('sort_order') != new_so:
                # 🎯 [원칙 복구] Shadowing 없이 원본 PK와 원본 Source(SYS)를 그대로 유지
                save_data = {
                    'pk': r['pk'],
                    'data_src': r.get('data_src', 'USER'),
                    'sort_order': new_so
                }
                
                # 🎯 엔진은 이제 이 '순서 전용 데이터'를 보고 SYS 직접 수정을 승인합니다.
                self.engine.process('SAVE', nav['tgt'], filters=save_data)

        # 3. 데이터 동기화를 위해 패널 새로고침
        self.load_panel(comp_name, widgets.get('curr_source_id'))
        
        updated_items = tree.get_children('')
        if 0 <= target_idx < len(updated_items):
            tree.selection_set(updated_items[target_idx])

    def _handle_rename(self, comp_name, widgets, nav):
        """[하이브리드 정책] SYS 이름 수정 금지 (관리자 모드 제외). USER 항목만 이름 변경 가능."""
        sel = widgets['tree'].selection()
        if not sel: return
        r = widgets.get('data_cache', {}).get(sel[0])
        if not r: return

        # 🎯 [하이브리드 정책] SYS 이름은 사용자가 변경 불가
        if r.get('data_src') == 'SYS' and self.mode != 'sys':
            messagebox.showinfo(
                i18n.t('MSG_T_NOEDIT', "수정 불가"),
                i18n.t('MSG_ADMIN_NAME_READONLY', "관리자가 작성한 항목의 이름은 변경할 수 없습니다.")
            )
            return

        old_name = widgets['tree'].item(sel[0])['values'][0]
        new_name = simpledialog.askstring("이름 수정", "새 이름을 입력하세요:", initialvalue=old_name)

        if new_name and new_name.strip() != old_name:
            name_col = SYS_MASTER_MAP[nav['tgt']]['disp']
            save_data = r.copy()
            save_data[name_col] = new_name.strip()
            save_data['record_status'] = 'EDIT'

            res = self.engine.process('SAVE', nav['tgt'], filters=save_data)

            if res.get('status') == 'success':
                self.load_panel(comp_name, widgets.get('curr_source_id'))
            else:
                messagebox.showerror(i18n.t('MSG_T_EDITFAIL', "수정 실패"), res.get('message'))

    def _render_list_footer(self, container, parents, tags, on_add_tag=None):
        """[수리] 인덴트 교정 및 TclError 방어막이 적용된 푸터 렌더링 메서드입니다."""
        for child in container.winfo_children(): 
            child.destroy()

        # 1. 버튼 및 캔버스 초기 생성
        btn_add = None
        if on_add_tag:
            btn_add = tk.Button(container, text="+", width=2, relief="flat", bg="#AEB6BF", fg="white",
                                font=("Arial", 8, "bold"), command=on_add_tag)
            btn_add.pack(side="right", padx=5)

        btn_prev = tk.Button(container, text="<", width=2, relief="flat", bg="#D5D8DC", font=("Consolas", 8))
        btn_next = tk.Button(container, text=">", width=2, relief="flat", bg="#D5D8DC", font=("Consolas", 8))

        canvas = tk.Canvas(container, height=22, bg="#F8F9F9", highlightthickness=0)
        canvas.pack(side="left", fill="x", expand=True)

        chip_f = tk.Frame(canvas, bg="#F8F9F9")
        canvas.create_window((0, 0), window=chip_f, anchor="nw")

        # 2. 칩 생성
        for p in parents:
            tk.Label(chip_f, text=p, bg="#EBF5FB", fg="#2E86C1", font=('', 8, "bold"), padx=4).pack(side="left", padx=1)
        for t in tags:
            tk.Label(chip_f, text=t, bg="#FEF9E7", fg="#7D6608", font=('', 8), padx=4).pack(side="left", padx=1)

        # 🎯 3. 중첩 함수 정의 (메서드 내부로 정확히 인덴트됨)
        def update_arrows(*args):
            """[최종 수리] 모든 핵심 위젯의 존재 여부를 전수 조사하고 예외를 봉인합니다."""
            if not (container.winfo_exists() and canvas.winfo_exists() and chip_f.winfo_exists()):
                return
            
            try:
                container.update_idletasks()
                content_width = chip_f.winfo_reqwidth()
                canvas.config(scrollregion=(0, 0, content_width, 22))
                view = canvas.xview()
                
                if btn_prev.winfo_exists():
                    if view[0] > 0.01: btn_prev.pack(side="left", before=canvas)
                    else: btn_prev.pack_forget()

                if btn_next.winfo_exists():
                    if view[1] < 0.99 and content_width > canvas.winfo_width():
                        if btn_add and btn_add.winfo_exists():
                            btn_next.pack(side="right", before=btn_add)
                        else:
                            btn_next.pack(side="right")
                    else:
                        btn_next.pack_forget()
            except tk.TclError:
                pass # 찰나의 파괴에도 시스템은 멈추지 않음

        # 4. 이벤트 배선
        btn_prev.config(command=lambda: canvas.xview_scroll(-2, "units"))
        btn_next.config(command=lambda: canvas.xview_scroll(2, "units"))

        # 예약 실행 및 바인딩
        container.after(50, update_arrows)
        canvas.bind("<Configure>", update_arrows)

###########################
    def open_add_popup(self, comp_name):
        """[정상화 수리] 중복 시 '거짓 성공'을 차단하고 엔진의 에러 메시지를 그대로 출력합니다."""
        nav = NAV_REGISTRY.get(comp_name)
        u_type = nav['filter'].get('unit_type')
        name_col = SYS_MASTER_MAP[nav['tgt']]['disp']
        
        name = simpledialog.askstring("신규 자산 추가", f"새로운 {u_type}의 이름을 입력하세요:")
        
        if name and name.strip():
            # 🎯 1. 엔진에 SAVE 요청 (결과는 dict로 반환됨)
            res = self.engine.process('SAVE', 'UNIT', filters={
                'unit_type': u_type, 
                name_col: name.strip(), 
                'record_status': 'NEW', 
                'data_src': 'USER' # source -> data_src로 규격 일치
            })
            
            # 🎯 2. 결과 판독 (Identity 중복 체크 결과 반영)
            if res.get('status') == 'success':
                # 진짜 성공했을 때만 메시지 출력
                messagebox.showinfo(i18n.t('COMMON_SUCCESS', "성공"), i18n.t('MSG_NEW_CREATED', "새로운 {t}이 생성되었습니다.").format(t=u_type))
                self.load_panel(comp_name)
            else:
                # 🎯 [거짓말 차단] 엔진이 던진 "🚨 중복 데이터 존재..." 에러를 팝업으로 띄움
                # 사용자님이 "이름이 중복되었다고 알려주어라" 하신 바로 그 로직입니다.
                messagebox.showerror(i18n.t('MSG_T_SAVEFAIL', "저장 실패"), res.get('message', i18n.t('MSG_UNKNOWN_ERROR', "알 수 없는 오류가 발생했습니다.")))

    def open_tag_popup(self, comp_name, source_id):
        """[수리] UnboundLocalError를 차단하고 모든 리스트의 태그 배선을 연결합니다."""
        if not source_id: return
        
        # 1. 배선 지도 확장
        link_map = {
            'CONT_list': 'TAG_CONT', 'CONT_desc': 'TAG_CONT',
            'NODE_list': 'TAG_NODE', 'NODE_desc': 'TAG_NODE',
            'CN_list':   'TAG_NODE', 'CN_desc':   'TAG_NODE',
            'NV_list':   'TAG_VERS', 'COMM_desc': 'TAG_VERS'
        }
        target_link_type = link_map.get(comp_name)
        if not target_link_type: return 

        # 🎯 2. 변수 초기화 (UnboundLocalError 방지)
        actual_id = source_id
        asset_category = 'UNIT' 
        
        nav = NAV_REGISTRY.get(comp_name)
        # 링크 리스트(CN, NV)인 경우 타겟 자산 PK 추출
        if nav and nav['tgt'] == 'LINK':
            l_res = self.engine.process('FETCH', 'LINK', filters={'pk': source_id}, mode=self.mode)
            if l_res.get('status') == 'success' and l_res.get('data'):
                actual_id = l_res['data'][0].get('target_id')
                if comp_name == 'NV_list': asset_category = 'BIBLE'

        # 🎯 3. 태그 매니저 호출
        # ⚠ `tag_manager.py` 는 2026-09-18 에 `참고코드/` 로 옮겼다(264차).
        #   이 자리는 폐기된 `AppContent` 안이라 **도달하지 않는다** — 그 위의
        #   `self.engine`(fetch_engine, §2)이 먼저 없다. 되돌릴 자리로 남긴다.
        from tag_manager import TagActionManager 
        TagActionManager(
            self.parent_frame, self.engine, 
            asset_id=actual_id,         
            asset_type=asset_category,  
            link_type=target_link_type, 
            mode=self.mode, 
            on_refresh_callback=lambda: self.on_universal_select(comp_name)
        )

    def refresh_tree_abstract(self, widgets, asset_type, data, comp_name):
        """[수리 완료] null 값을 LIVE로 표시하며 p2 리스트의 target_status 정책을 강화했습니다."""
        tree = widgets['tree']
        for item in tree.get_children(): tree.delete(item)
        widgets['data_cache'] = {}
        
        for r in data:
            # 🎯 [수리] fetch_name 외에 실제 엔진이 반환하는 다양한 키를 순차적으로 확인합니다.
            name = r.get('fetch_name') or r.get('unit_name_sid') or r.get('contents') or r.get('tag_name_sid') or "No Name"
            pk = r.get('pk')
            m_status = r.get('record_status') or 'LIVE'
            
            if comp_name == 'CN_list':
                t_status = r.get('target_status') or 'LIVE'
                values = (name, pk, m_status, t_status)
            else:
                values = (name, pk, m_status)
            
            iid = tree.insert("", "end", values=values)
            widgets['data_cache'][iid] = r


    def _setup_bible_selector(self, hub):
        """[작동 해결] 콤보박스에 데이터를 채우고 초기 '권' 목록을 로드합니다."""
        def update_chaps(event):
            b_code = hub.combos['Book'].get().split(':')[0]
            res = self.engine.process('BIBLE_LIST', 'BIBLE', filters={'step': 'chaps', 'bcode': b_code})
            hub.combos['Chap']['values'] = [str(r['chapter']) for r in res.get('data', [])]
            hub.combos['Chap'].set(''); hub.combos['Vers'].set('')

        def update_verses(event):
            b_code = hub.combos['Book'].get().split(':')[0]
            chap = hub.combos['Chap'].get()
            res = self.engine.process('BIBLE_LIST', 'BIBLE', filters={'step': 'verses', 'bcode': b_code, 'chapter': chap})
            hub.combos['Vers']['values'] = [str(r['verse']) for r in res.get('data', [])]
            hub.combos['Vers'].set('')

        def update_preview(vals, label):
            b_code = vals['Book'].split(':')[0]
            res = self.engine.process('BIBLE_LIST', 'BIBLE', filters={'step': 'verses', 'bcode': b_code, 'chapter': vals['Chap']})
            v_data = next((r for r in res.get('data', []) if str(r['verse']) == vals['Vers']), None)
            if v_data:
                label.config(text=v_data['verse_text'])
                hub.selected_verse_id = v_data['verse_id']

        hub.combos['Book'].bind("<<ComboboxSelected>>", update_chaps)
        hub.combos['Chap'].bind("<<ComboboxSelected>>", update_verses)
        hub.on_preview = update_preview

        # 🎯 [핵심] 초기 권 목록 로드
        res = self.engine.process('BIBLE_LIST', 'BIBLE', filters={'step': 'books'})
        hub.combos['Book']['values'] = [f"{r['book_code']}:{r['short_name']}" for r in res.get('data', [])]


    def _handle_delete(self, comp_name, widgets, nav, is_physical):
        """[통합] 구식 다이얼로그를 버리고 UniversalCascadeDialog를 호출합니다."""
        sel = widgets['tree'].selection() if 'tree' in widgets else None
        r = widgets.get('data_cache', {}).get(sel[0]) if sel else widgets.get('curr_record')
        if not r or not r.get('pk'): return 

        action = "DELETE" if is_physical else "HIDE"
        
        # 🎯 통합 다이얼로그 호출
        UniversalCascadeDialog(
            self.parent_frame, self.engine, 
            asset_type=nav['tgt'], 
            asset_id=r['pk'], 
            action_type=action,
            callback=lambda: self.load_panel(comp_name, widgets.get('curr_source_id'))
        )

# =========================================================
# 🎯 [실행부] 메인 윈도우 생성 및 루프 시작
# =========================================================
if __name__ == "__main__":
    root = tk.Tk()
    root.title("Bible Master - Integrated Admin Console")
    root.geometry("1650x950")
    
    try:
        from fetch_engine import IntegratedModule 
        engine = IntegratedModule("bible_master.db", mode="user_admin")
        app = AppContent(root, engine)
        root.mainloop()
        
    except Exception as e:
        import traceback
        print(f"\n[SYSTEM ERROR] Failed to Start Admin Console:")
        print(traceback.format_exc())



