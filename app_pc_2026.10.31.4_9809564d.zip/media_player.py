"""
media_player.py
---------------
인라인 미디어 플레이어 런처 (표준 모듈, 4개 영역 공용).

tkinter 쪽(user_main / admin)에서 import 하는 가벼운 런처. **PyQt 를 import 하지 않는다**
(PyQt 는 별도 프로세스 pyqt_media_player.py 안에서만 로드 → tkinter 이벤트 루프와 충돌 없음).

사용:
    import media_player
    media_player.launch('다윗 — 관련 영상', [
        {'title': '다윗과 골리앗 설교', 'url': 'https://youtube.com/watch?v=...', 'tag': '[설교]'},
        ...
    ])

videos 각 항목: {'title': str, 'url': str, 'tag': str(선택)}. URL 은 YouTube 면 인라인 재생,
아니면 플레이어에서 [브라우저에서 열기] 로 처리.
"""

import os
import sys
import json
import tempfile
import subprocess

_PYQT_SCRIPT = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            'pyqt_media_player.py')

#: 영상 칸의 가로세로비. 유튜브 기본이 16:9 이고, 그 밖의 비율은 이 칸 안에서
#: 플레이어가 다시 레터박스로 맞춘다(그래도 **전부 보인다**).
ASPECT = 16.0 / 9.0
#: 영상 둘레 여백(밀리미터) — 2026-09-17 사용자 「유투브 영상을 모두 보여주고
#: 5mm 정도의 빈공간을 배치하는 것이 차라리 낫다」.
PAD_MM = 5

#: ★★★ **지금 소리를 내고 있는 재생기 하나**(2026-09-17 사용자 「찬양듣기를
#:   플래이 한 상태에서 성경듣기를 플래이 하면 둘다 플래이 된다. 사용자들은
#:   이전 것은 자동으로 꺼질 것으로 기대하고 있다」).
#:   ⚠ 화면마다 `EmbeddedPlayer` 를 따로 만들므로(목록·맞춤 화면·주요용어·
#:     연구자료·뉴스) **서로를 모른다** — 그래서 모듈에 자리를 하나 둔다.
_PLAYING = [None]


def now_playing():
    """지금 소리를 내는 재생기(없으면 None) — 점검·시험용."""
    return _PLAYING[0]


def fit_box(w, h, pad=0, aspect=ASPECT):
    """칸 `w×h` 안에 영상을 **통째로** 넣고 가운데에 둔다 → (x, y, 폭, 높이).

    ★★★ **절대로 칸을 넘지 않는다.** 넘으면 부모 창이 잘라 내고, 그것이
      2026-09-17 사용자가 본 「모든 테두리가 잘려나가는 느낌」의 실체였다
      (실측 창 900×560 에서 칸 605×209 인데 자식이 605×270 → 아래 61px 잘림).
    ⚠ 칸이 여백을 감당 못 할 만큼 작으면 **여백을 접는다** — 여백을 지키느라
      영상이 사라지면 안 된다."""
    w = max(1, int(w))
    h = max(1, int(h))
    p = max(0, int(pad))
    if w - 2 * p < 40 or h - 2 * p < 40:
        p = 0
    aw = max(1, w - 2 * p)
    ah = max(1, h - 2 * p)
    bw = max(1, min(aw, int(round(ah * aspect))))
    bh = max(1, min(ah, int(round(aw / aspect))))
    return ((w - bw) // 2, (h - bh) // 2, bw, bh)


def launch(title: str, videos: list) -> bool:
    """별도 PyQt 프로세스로 인라인 플레이어 창을 띄운다. 성공 시 True.

    실패해도(PyQt 미설치 등) 예외를 던지지 않고 False 반환 — 호출자는 폴백(브라우저 열기)
    하면 된다."""
    try:
        if not videos:
            return False
        fd, path = tempfile.mkstemp(suffix='.json', prefix='mediaplayer_')
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump({'title': title, 'videos': videos}, f, ensure_ascii=False)
        # 진단용: 자식 프로세스 출력/오류를 로그파일로 남긴다 (문제 시 원인 확인)
        log_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                '_media_player.log')
        logf = open(log_path, 'w', encoding='utf-8')
        # 콘솔 없는 GUI 실행: pythonw.exe 사용(자연히 콘솔 없음).
        # CREATE_NO_WINDOW 는 QtWebEngine 헬퍼 프로세스(렌더러) 초기화를 깨뜨려
        # 우측 웹뷰가 빈 화면이 되는 사례가 있어 사용하지 않는다.
        exe = sys.executable
        if os.name == 'nt' and exe.lower().endswith('python.exe'):
            candw = exe[:-len('python.exe')] + 'pythonw.exe'
            if os.path.exists(candw):
                exe = candw
        subprocess.Popen([exe, _PYQT_SCRIPT, '--data', path],
                         stdout=logf, stderr=logf)
        return True
    except Exception as e:
        print(f'[media_player.launch] 실패: {e}')
        return False


def available() -> bool:
    """PyQt6 + WebEngine 사용 가능 여부 (UI에서 버튼 표시 결정용)."""
    try:
        import importlib.util
        return (importlib.util.find_spec('PyQt6.QtWebEngineWidgets') is not None
                and os.path.exists(_PYQT_SCRIPT))
    except Exception:
        return False


def embed_available() -> bool:
    """임베드(인라인) 재생 가능 여부. Windows + PyQt6 필요 (SetParent 재부모화)."""
    return os.name == 'nt' and available()


class EmbeddedPlayer:
    """별도 PyQt 프로세스의 YouTube 플레이어 창을 tkinter 프레임 '안에' 이식(SetParent)한다.
    → 한 창 안에서 좌 목록(tkinter) + 우 인라인 재생(임베드). Windows 전용.

    영상은 **호스트 칸 안에 통째로** 들어간다(`fit_box`) — 16:9 로 맞추고 둘레에
    5mm 여백을 둔다. 칸이 작아지면 영상도 함께 작아진다.
    ⚠⚠ **2026-09-17 에 뒤집힌 약속** — 그전에는 「칸이 작으면 최소 크기를 유지하고
      프레임이 잘라 낸다」였고, 그래서 창을 줄이면 영상 아래가 실제로 잘렸다.
      `MIN_W`·`MIN_H` 는 **더 이상 칸을 넘는 근거가 아니다**(옛 호출부가 넘기는
      인자는 그대로 받되 크기를 정하지 않는다).

    사용:
        self._player = EmbeddedPlayer(right_frame)   # right_frame: tk.Frame
        self._player.play('VIDEO_ID')                # 목록 클릭 시
        self._player.stop()                          # 탭/엔티티 전환·종료 시
    """
    MIN_W, MIN_H = 480, 270

    def __init__(self, host_widget, min_w=None, min_h=None):
        self._host = host_widget        # 임베드 대상 tk 위젯(Frame)
        if min_w:
            self.MIN_W = int(min_w)
        if min_h:
            self.MIN_H = int(min_h)
        self._proc = None
        self._hwnd = None
        self._u32 = None
        self._hwnd_file = None
        self._cmd_file = None
        self._logf = None
        self._poll_id = None
        self._pending_vid = None
        #: 아직 창이 안 붙었을 때 **보낼 명령 전체**(목록·후보 줄).
        #: ⚠ `_pending_vid` 만 두면 `__TRY__`·`__LIST__` 가 **첫 편 하나로 줄어든다**
        #:   (2026-09-17 실측 — 새로 뜬 재생기에서 건너뛰기를 통째로 잃었다).
        self._pending_cmd = None
        self._note_file = None
        self._note_id = None
        self._last_blocked = None
        self._resize_bound = False
        #: 지금 담은 것이 **웹페이지인가**(True) **영상인가**(False).
        #: ★★★ 웹페이지는 칸을 **꽉 채운다** — 관리자 찬양수집기가 유튜브 쪽
        #:   페이지를 통째로 열어 **제목·설명문까지** 보이기 때문이다(2026-09-17
        #:   사용자 「관리자 화면은 현재대로 유지한다 … 제목, 설명문 모두 볼 수
        #:   있어서 좋다」). 거기에 16:9 를 씌우면 글이 잘린다.
        self._fill = False

    def _ensure_started(self) -> bool:
        if os.name != 'nt' or not available():
            return False
        if self._proc is not None and self._proc.poll() is None:
            return True
        import ctypes
        self._u32 = ctypes.windll.user32
        self._hwnd = None
        self._hwnd_file = tempfile.mktemp(suffix='.hwnd', prefix='mp_')
        self._cmd_file = tempfile.mktemp(suffix='.cmd', prefix='mp_')
        # ★ 자식이 알리는 쪽지 — 지금은 「임베드 차단」 하나다(283차 ③).
        self._note_file = tempfile.mktemp(suffix='.note', prefix='mp_')
        try:
            log_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                    '_media_player.log')
            self._logf = open(log_path, 'w', encoding='utf-8')
        except Exception:
            self._logf = None
        exe = sys.executable
        if exe.lower().endswith('python.exe'):
            candw = exe[:-len('python.exe')] + 'pythonw.exe'
            if os.path.exists(candw):
                exe = candw
        self._proc = subprocess.Popen(
            [exe, _PYQT_SCRIPT, '--embed',
             '--hwnd-file', self._hwnd_file, '--cmd-file', self._cmd_file,
             '--note-file', self._note_file],
            stdout=self._logf, stderr=self._logf)
        if not self._resize_bound:
            try:
                self._host.bind('<Configure>', self._on_host_configure, add='+')
                self._resize_bound = True
            except Exception:
                pass
        self._attach()
        # ★ 자식이 알리는 쪽지를 지켜본다(283차 ③ — 임베드 차단 자동 전환).
        if self._note_id is None:
            self._watch_note()
        return True

    def _on_host_configure(self, event):
        # 이벤트의 새 크기를 직접 사용 (winfo_width 는 갱신 지연 가능)
        self._resize(event.width, event.height)

    def _attach(self):
        """자식 HWND 가 준비되면 호스트 프레임에 SetParent."""
        if self._hwnd:
            return
        try:
            if self._hwnd_file and os.path.exists(self._hwnd_file):
                raw = open(self._hwnd_file).read().strip()
                if raw:
                    self._hwnd = int(raw)
                    self._u32.SetParent(self._hwnd, self._host.winfo_id())
                    self._resize()
                    if self._pending_cmd:
                        self._write_cmd(self._pending_cmd)
                        self._pending_cmd = None
                    elif self._pending_vid:
                        self._write_cmd(self._pending_vid)
                    return
        except Exception as e:
            print(f'[EmbeddedPlayer attach] {e}')
        # 아직 — 재시도
        try:
            self._poll_id = self._host.after(250, self._attach)
        except Exception:
            pass

    def _set_fill(self, on):
        """담은 것의 갈래가 바뀌면 자리도 다시 잡는다."""
        on = bool(on)
        if on == self._fill:
            return
        self._fill = on
        self._resize()

    def _pad_px(self):
        """5mm 를 이 화면의 픽셀로 — 화면 배율이 달라도 같은 크기로 보인다."""
        try:
            return int(round(self._host.winfo_fpixels('%dm' % PAD_MM)))
        except Exception:
            return 19

    def _resize(self, w=None, h=None):
        if not (self._hwnd and self._u32):
            return
        try:
            if w is None:
                w = self._host.winfo_width()
            if h is None:
                h = self._host.winfo_height()
            if self._fill:
                x, y, bw, bh = 0, 0, max(1, int(w)), max(1, int(h))
            else:
                x, y, bw, bh = fit_box(w, h, self._pad_px())
            self._u32.MoveWindow(self._hwnd, x, y, bw, bh, True)
        except Exception:
            pass

    # ── 한 번에 한 재생기만 ──────────────────────────────────────────
    def _claim_play(self):
        """내가 틀기 시작한다 — 딴 화면에서 울리던 것을 멎게 한다.

        ⚠ **프로세스는 안 죽인다**(§30) — QtWebEngine 첫 재생이 느려서
          다시 살리면 사용자가 기다린다. 소리만 멈추고 검은 화면으로 둔다."""
        cur = _PLAYING[0]
        if cur is not None and cur is not self:
            try:
                cur._yield_play()
            except Exception:
                pass
        _PLAYING[0] = self

    def _yield_play(self):
        """딴 재생기가 틀기 시작했다 — 소리를 멈춘다."""
        self._pending_vid = None      # 아직 붙는 중이면 그것도 취소한다
        self._pending_cmd = None
        try:
            self.clear()
        except Exception:
            pass

    def _release_play(self):
        if _PLAYING[0] is self:
            _PLAYING[0] = None

    def clear(self):
        """우측 패널을 비운다(검정). 엔티티 전환 시 직전 영상 잔상 제거."""
        self._release_play()
        if self._proc is not None and self._proc.poll() is None:
            self._write_cmd('__BLANK__')

    # ── 자식이 알리는 것 (283차 ③) ────────────────────────────────
    def _watch_note(self):
        """쪽지를 읽어 **임베드 차단을 그 자리에서 처리**한다.

        ★ 무엇으로 열지는 `video_open` 이 정한다 — 여기서 정하면 규칙이 갈린다.
        ⚠ 읽은 줄은 **지운다** — 안 지우면 같은 영상을 되풀이해 연다.
        ⚠ 이 재생기가 지금 소리를 낼 차례가 아니면 무시한다(딴 화면 것이다).
        """
        self._note_id = None
        try:
            if not self._host.winfo_exists():
                return
        except Exception:                                    # noqa: BLE001
            return
        try:
            if self._note_file and os.path.exists(self._note_file):
                with open(self._note_file, encoding='utf-8') as f:
                    lines = [x.strip() for x in f if x.strip()]
                if lines:
                    open(self._note_file, 'w').close()
                    for ln in lines:
                        if ln.startswith('BLOCKED '):
                            self._on_blocked(ln[8:].strip())
        except Exception:                                    # noqa: BLE001
            pass
        try:
            self._note_id = self._host.after(400, self._watch_note)
        except Exception:                                    # noqa: BLE001
            pass

    def _on_blocked(self, vid):
        """임베드가 막혔다 — **저절로 다른 방식으로** 연다."""
        if not vid or vid == self._last_blocked:
            return
        self._last_blocked = vid
        try:
            import video_open as _VO
            _VO.on_blocked(self, vid)
        except Exception as e:                               # noqa: BLE001
            print('[player] blocked fallback: %s' % e)

    def _write_cmd(self, text):
        try:
            with open(self._cmd_file, 'w', encoding='utf-8') as f:
                f.write(text)
        except Exception:
            pass

    def play(self, video_id: str):
        """해당 YouTube 영상을 임베드 패널에서 재생. 프로세스 없으면 시작."""
        if not video_id:
            return
        self._set_fill(False)
        self._claim_play()
        # ⚠ 다른 영상을 틀면 「방금 막힌 것」 기억을 푼다 — 안 풀면 되돌아왔을
        #   때 그 영상의 차단을 두 번째부터 조용히 흘린다.
        if video_id != self._last_blocked:
            self._last_blocked = None
        self._pending_cmd = None
        self._pending_vid = video_id
        if not self._ensure_started():
            return
        if self._hwnd:                 # 이미 이식됨 → 즉시 전환
            self._write_cmd(video_id)
        # 아직 attach 전이면 _attach 가 _pending_vid 를 반영

    def play_list(self, video_ids):
        """선택한 영상 여러 편을 **순서대로** 재생 (2026-09-10 사용자 요구).

        ★ 지금 플레이어가 YouTube IFrame API 라 `loadPlaylist` 가 그대로 있다 —
          페이지를 다시 열지 않고 목록만 넘긴다.
        ⚠ **임베드가 막힌 영상이 섞이면 거기서 멈춘다** — 목록을 만들 때
          `sys_media_check.status='EMBED_BLOCKED'` 인 것을 빼야 한다.
        ⚠ 한 편이면 그냥 `play` 와 같다.
        """
        ids = [str(v).strip() for v in (video_ids or []) if str(v or '').strip()]
        if not ids:
            return
        if len(ids) == 1:
            return self.play(ids[0])
        self._set_fill(False)
        self._claim_play()
        cmd = '__LIST__' + ','.join(ids[:200])
        self._pending_vid = ids[0]
        self._pending_cmd = cmd
        if not self._ensure_started():
            return
        if self._hwnd:
            self._pending_cmd = None
            self._write_cmd(cmd)

    def play_try(self, video_ids):
        """**대표 후보를 차례로** 건다 — 첫 후보가 막히면 다음으로 저절로 넘어간다.

        ★ `play_list`(이어듣기)와 뜻이 다르다 — 후보는 **같은 곡의 다른 판**이라
          한 편이 끝나면 **멈춘다**(딴 판이 이어 울리면 무엇을 듣는지 모른다).
        ⚠ 실측 승인 찬양 2,826편 중 임베드 차단을 점검한 것이 **91편**뿐이라
          첫 후보가 막힐 수 있다 — 그때 검은 화면으로 끝나지 않게 하는 장치다.
        """
        ids = [str(v).strip() for v in (video_ids or []) if str(v or '').strip()]
        if not ids:
            return
        self._set_fill(False)
        self._claim_play()
        if len(ids) == 1:
            self._pending_cmd = None
            self._pending_vid = ids[0]
            if not self._ensure_started():
                return
            if self._hwnd:
                self._write_cmd(ids[0])
            return
        cmd = '__TRY__' + ','.join(ids[:200])
        self._pending_vid = ids[0]
        self._pending_cmd = cmd
        if not self._ensure_started():
            return
        if self._hwnd:
            self._pending_cmd = None
            self._write_cmd(cmd)

    def open_url(self, url: str):
        """일반 웹페이지(http/https)를 임베드 브라우저에 로드 (오늘의 묵상/뉴스).
        YouTube가 아닌 기사 페이지도 표시 — iframe 이 아니라 브라우저 탐색이라 X-Frame 무관."""
        if not url or not (url.startswith('http://') or url.startswith('https://')):
            return
        self._set_fill(True)
        self._claim_play()
        self._pending_cmd = None
        self._pending_vid = url        # attach 전이면 _attach 가 반영
        if not self._ensure_started():
            return
        if self._hwnd:
            self._write_cmd(url)

    def stop(self):
        """자식 프로세스 종료 + 임시파일 정리."""
        self._release_play()
        try:
            if self._poll_id is not None:
                self._host.after_cancel(self._poll_id)
            if self._note_id is not None:
                self._host.after_cancel(self._note_id)
        except Exception:
            pass
        self._poll_id = None
        self._note_id = None
        if self._proc is not None:
            try:
                self._write_cmd('__QUIT__')
            except Exception:
                pass
            try:
                self._proc.terminate()
            except Exception:
                pass
            self._proc = None
        self._hwnd = None
        for f in (self._hwnd_file, self._cmd_file):
            try:
                if f and os.path.exists(f):
                    os.remove(f)
            except Exception:
                pass
        try:
            if self._logf:
                self._logf.close()
        except Exception:
            pass
        self._logf = None


# ── 자가검증 ─────────────────────────────────────────────────────────
def selftest():
    """python media_player.py --selftest"""
    import io as _io
    import sys as _sys
    _sys.stdout = _io.TextIOWrapper(_sys.stdout.buffer, encoding='utf-8',
                                    errors='replace', line_buffering=True)
    n = [0, 0]

    def t(name, ok, got=''):
        n[1] += 1
        if ok:
            n[0] += 1
        print(('  OK  ' if ok else '  실패 ') + name + ('' if ok else '  ' + str(got)))

    # ① 자리 셈 — 칸을 절대 넘지 않는다
    for w, h in ((1205, 549), (1200, 775), (605, 209), (100, 50), (1, 1),
                 (2000, 80), (80, 2000), (480, 270), (0, 0)):
        x, y, bw, bh = fit_box(w, h, 19)
        t('① %dx%d 가 칸을 안 넘는다' % (w, h),
          x >= 0 and y >= 0 and x + bw <= max(1, w) and y + bh <= max(1, h),
          (x, y, bw, bh))
    x, y, bw, bh = fit_box(1205, 549, 19)
    t('① 넓은 칸은 높이에 맞춘다 · 16:9', abs(bw / bh - ASPECT) < 0.02, (bw, bh))
    t('① 위아래 여백이 생긴다(옛 동작은 0)', y >= 15, y)
    x, y, bw, bh = fit_box(1200, 775, 19)
    t('① 높은 칸은 폭에 맞춘다 · 16:9', abs(bw / bh - ASPECT) < 0.02, (bw, bh))
    t('① 좌우 여백이 생긴다', x >= 15, x)
    _, _, bw, bh = fit_box(605, 209, 19)
    t('★ 옛 최소치(480x270)가 칸을 넘던 자리 — 이제 안 넘는다',
      bw <= 605 and bh <= 209, (bw, bh))
    _, _, bw, bh = fit_box(100, 50, 19)
    t('① 너무 작은 칸에서는 여백을 접는다', bw >= 80, (bw, bh))
    t('① 가로세로비 상수를 화면이 안 적는다', abs(ASPECT - 16 / 9) < 1e-9)

    # ② 한 번에 하나만
    class _Fake:
        def __init__(self, nm):
            self.nm = nm
            self.cleared = 0
            self._pending_vid = None
        _claim_play = EmbeddedPlayer._claim_play
        _yield_play = EmbeddedPlayer._yield_play
        _release_play = EmbeddedPlayer._release_play

        def clear(self):
            self.cleared += 1
            self._release_play()

    _PLAYING[0] = None
    a, b = _Fake('a'), _Fake('b')
    a._claim_play()
    t('② 처음 틀면 그것이 지금 트는 것', now_playing() is a)
    b._pending_vid = 'x'
    a.cleared = 0
    b._claim_play()
    t('★★★ 둘째를 틀면 첫째가 멎는다', a.cleared == 1, a.cleared)
    t('② 지금 트는 것은 둘째', now_playing() is b)
    b.cleared = 0
    b._claim_play()
    t('② 같은 재생기를 다시 틀어도 제 소리를 안 끊는다', b.cleared == 0, b.cleared)
    c = _Fake('c')
    b._pending_vid = 'yy'
    c._claim_play()
    t('② 아직 안 붙은 예약 재생도 취소한다', b._pending_vid is None, b._pending_vid)
    c._release_play()
    t('② 멈추면 자리가 빈다', now_playing() is None)

    # ②-2 웹페이지는 꽉 채운다
    src0 = open(os.path.abspath(__file__), encoding='utf-8').read()
    seg = src0.split('def open_url(', 1)[1].split('\n    def ', 1)[0]
    t('★ 웹페이지는 꽉 채우기로 연다(관리자 제목·설명문)', '_set_fill(True)' in seg)
    for fn in ('def play(', 'def play_list('):
        s2 = src0.split(fn, 1)[1].split('\n    def ', 1)[0]
        t('② %s 는 영상 자리로 연다' % fn.strip('def ('), '_set_fill(False)' in s2)
    rs = src0.split('def _resize(', 1)[1].split('\n    def ', 1)[0]
    t('② 꽉 채울 때는 0,0 에서 칸 전체', 'if self._fill:' in rs and '0, 0, max(1, int(w))' in rs)

    # ③ 부르는 자리가 실제로 붙어 있는가
    src = open(os.path.abspath(__file__), encoding='utf-8').read()
    for fn in ('def play(', 'def play_list(', 'def open_url('):
        seg = src.split(fn, 1)[1].split('\n    def ', 1)[0]
        t('③ %s 가 자리를 잡는다' % fn.strip('def ('), '_claim_play()' in seg)
    t('③ stop 이 자리를 비운다',
      '_release_play()' in src.split('def stop(', 1)[1].split('\n    def ', 1)[0])
    # ⚠ 제 시험 글자에 제가 걸리지 않게 쪼갠다(§199차 그 함정)
    t('③ 옛 최소치 클램프가 남아 있지 않다',
      ('max(int(w), ' + 'self.MIN_W)') not in src)

    print('media_player selftest: %d/%d' % (n[0], n[1]))
    return n[0] == n[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print('media_player — 인라인 재생 런처. --selftest 로 자가검증.')
