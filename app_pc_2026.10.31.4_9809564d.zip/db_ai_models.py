# -*- coding: utf-8 -*-
"""db_ai_models — **AI 모델 목록을 배포한다**(관리자가 고치면 사용자가 자동으로 받는다).

★★★ **왜 필요한가** (2026-09-29 299차-3 · 사용자 「관리자가 이런 새로운 AI 모델이 출시되면
  업그레이드 하고 사용자에게 설정값을 전송하고 사용자는 앱+트레이 모드에서 자동수신하여
  사용하는 기능이 필요할 것 같다」).
  ⚠⚠ 실측이 그 까닭을 그대로 보였다 — 새 Gemini 키로 `gemini-2.5-flash` 를 부르니
    **HTTP 404 「no longer available to new users … use gemini-3.8-flash」**. 모델 이름을
    **코드에 박아 두면** 회사가 판을 물릴 때마다 **그 사용자는 앱을 다시 받기 전까지 404 만
    본다**. 우리가 고쳐도 닿지 않는다.

★★★ **배포하는 것은 「모델 이름 목록」뿐이다 — 회사(어댑터)는 코드다.**
  | 무엇 | 어디 | 왜 |
  |---|---|---|
  | 회사 이름 · 키 받는 곳 · 요청 꼴 | **코드**(`user_ai.PROVIDERS`) | 새 회사는 **어댑터**가 필요하다 — 목록 한 줄로 안 된다 |
  | 모델 후보 · 기본 모델 · **물린 이름 → 별칭** | **이 표**(배포) | 이름만 바뀐다. 자주 바뀐다. 안 바뀌면 404 |
  ⇒ 경계가 「코드가 필요한가」다. 목록에 회사를 적을 수 있게 하면 **어댑터 없는 회사**를
    고를 수 있게 되어 화면이 거짓말을 한다(§0-1).

★★★ **키는 절대 안 나간다** — 이 표에는 `provider`·`model`·차례·기본·별칭뿐이다(§C-2).
  사용자 키는 그 PC 의 `userdb.user_config['AI_ACCOUNTS']` 에만 산다. selftest 가 잰다.

★★★ **사용자가 고른 모델을 안 덮는다** — 받는 것은 **목록**이고 고른 값이 아니다.
  다만 그 사람이 쓰던 이름이 **물린 이름**이면 `user_ai.model_alias` 가 **읽을 때** 살아 있는
  이름으로 옮긴다(§258차 ⑰ 「저장값은 안 고치고 쓰는 순간만」과 같은 원칙).

표 `sys_ai_model` — `db_pack_catalog` 에 **CORE** 로 분류한다(코어팩에도 실리고 **날마다
RSS 로도 온다** — `sys_announcement` 과 같은 두 길 · 코어팩은 연 2회라 그것만으로는 늦다).

`--selftest`(의무) · `--list` · `--seed` · `--export` · `--version`.
"""
import json
import sys
import time

import appdb

#: 관리자가 고치는 표 — 코어팩에 실려 나간다(연 2회).
TABLE = 'sys_ai_model'
#: ★★★ **받는 표는 개인 DB 다** — 날마다 RSS 로 온다(2026-09-29 299차-3).
#  ⚠⚠⚠ `sys_ai_model` 에 받으면 안 된다: 코어팩이 그 표를 **통째로 갈아 끼우므로**
#    (`db_pack_apply._wipe_scope` → `db_pack_core.core_tables` 의 조건으로 DELETE)
#    **반년 전 코어팩 하나가 어제 받은 목록을 되돌린다** — 이 기능이 막으려던 그 일이다.
#  ⚠ 그리고 사용자 PC 에서 sys 표를 쓰는 길을 하나 더 내지 않는다(§C-2).
UTABLE = 'userdb.user_ai_model'
VER_KEY = 'AI_MODEL_CATALOG_VER'
TS_KEY = 'AI_MODEL_CATALOG_TS'

_DDL = (" provider TEXT NOT NULL,"
        " model TEXT NOT NULL,"
        " sort_order INTEGER DEFAULT 0,"
        " is_default INTEGER DEFAULT 0,"
        " alias_to TEXT DEFAULT '',"
        " note TEXT DEFAULT '',"
        " record_status TEXT DEFAULT 'LIVE',"
        " PRIMARY KEY (provider, model)")


def _now():
    return time.strftime('%Y-%m-%d %H:%M:%S')


def ensure(conn):
    """관리자 표를 만든다(멱등)."""
    conn.execute("CREATE TABLE IF NOT EXISTS %s (%s)" % (TABLE, _DDL))
    conn.commit()


def ensure_user(conn):
    """받는 표를 개인 DB 에 만든다(멱등).

    ⚠ 꼴은 관리자 표와 **글자 그대로 같다**(`_DDL` 한 곳) — 두 곳에 적으면 갈린다.
    """
    conn.execute("CREATE TABLE IF NOT EXISTS %s (%s)" % (UTABLE, _DDL))
    conn.commit()


# ══════════════════════════════════════════════════════════════════════
#  읽기 — 화면·`user_ai.providers` 가 쓰는 단일 문
# ══════════════════════════════════════════════════════════════════════
def catalog(conn):
    """`{provider: {'model': 기본, 'models': [...], 'alias': {옛: 새}}}` — LIVE 만.

    ★★★ **두 길이 겹친다 — 판이 더 새것이 이긴다**(2026-09-29 299차-3):
      | 길 | 표 | 주기 |
      |---|---|---|
      | 코어팩 | `sys_ai_model` | 연 2회 |
      | **RSS 자동 수신** | `userdb.user_ai_model` | **날마다** |
      코어팩이 나중에 와도 **판이 낮으면 덮지 못한다** — 그것이 이 갈래의 알맹이다.
    ⚠ 덮는 단위는 **회사**다(줄이 아니다) — 회사 하나를 갈아 끼우면 그 회사의 옛
      별칭도 함께 걷혀야 한다(`set_provider` 와 같은 규칙).
    ⚠ 표가 없으면 **빈 dict** 를 낸다(코드 씨앗이 그대로 쓰인다) — 조용히 터지지 않는다.
    ⚠ **별칭 줄은 후보 목록에 안 넣는다** — 물린 이름을 고르게 하면 그 자리에서 404 다.
    """
    out = _read(conn, TABLE)
    if user_version(conn) > version(conn):
        got = _read(conn, UTABLE)
        if got:
            out = dict(out)
            out.update(got)                               # 회사 단위로 덮는다
    return out


def _read(conn, table):
    """한 표를 읽어 `{provider: {...}}`. 표가 없으면 빈 dict."""
    try:
        rows = conn.execute(
            "SELECT provider, model, COALESCE(alias_to,''), COALESCE(is_default,0)"
            " FROM %s WHERE COALESCE(record_status,'LIVE')='LIVE'"
            " ORDER BY provider, sort_order, model" % table).fetchall()
    except Exception:                                     # noqa: BLE001
        return {}
    out = {}
    for prov, model, alias, dflt in rows:
        p = (prov or '').strip().upper()
        m = (model or '').strip()
        if not p or not m:
            continue
        d = out.setdefault(p, {'model': '', 'models': [], 'alias': {}})
        if (alias or '').strip():
            d['alias'][m] = alias.strip()
            continue                                      # 물린 이름은 후보가 아니다
        if m not in d['models']:
            d['models'].append(m)
        if int(dflt or 0) and not d['model']:
            d['model'] = m
    for d in out.values():
        if not d['model'] and d['models']:
            d['model'] = d['models'][0]                   # 기본을 안 정했으면 첫째
    return {p: d for p, d in out.items() if d['models'] or d['alias']}


def version(conn):
    """관리자·코어팩이 실어 온 판(`sys_config`)."""
    return _get_int(conn, 'sys_config', VER_KEY)


def user_version(conn):
    """RSS 로 받은 판(`userdb.user_config`). 아직 못 받았으면 0."""
    return _get_int(conn, 'userdb.user_config', VER_KEY)


def _get_int(conn, table, key):
    try:
        r = conn.execute("SELECT config_val FROM %s WHERE config_key=?" % table, (key,)).fetchone()
        return int(r[0]) if r and r[0] else 0
    except Exception:                                     # noqa: BLE001
        return 0


def _set_cfg(conn, key, val, table='sys_config'):
    if conn.execute("SELECT 1 FROM %s WHERE config_key=?" % table, (key,)).fetchone():
        conn.execute("UPDATE %s SET config_val=? WHERE config_key=?" % table, (str(val), key))
    else:
        conn.execute("INSERT INTO %s(config_key, config_val) VALUES(?,?)" % table, (key, str(val)))


# ══════════════════════════════════════════════════════════════════════
#  쓰기 — 관리자 화면 · 씨앗
# ══════════════════════════════════════════════════════════════════════
def set_provider(conn, provider, models, default='', alias=None, bump=True, table=None):
    """한 회사의 목록을 **통째로 갈아 끼운다**(차례 = 적은 차례).

    ⚠ 그 회사 줄만 지우고 다시 넣는다 — 남의 회사는 안 건드린다.
    ⚠ `table` 을 주면 그 표에 쓴다(받는 쪽은 `UTABLE`). 기본은 관리자 표다.
    """
    table = table or TABLE
    (ensure_user if table == UTABLE else ensure)(conn)
    p = (provider or '').strip().upper()
    models = [str(m).strip() for m in (models or []) if str(m).strip()]
    alias = {str(k).strip(): str(v).strip() for k, v in (alias or {}).items()
             if str(k).strip() and str(v).strip()}
    if not p:
        raise ValueError('회사를 적어야 한다')
    dflt = (default or '').strip() or (models[0] if models else '')
    conn.execute("DELETE FROM %s WHERE provider=?" % table, (p,))
    for i, m in enumerate(models):
        conn.execute("INSERT INTO %s(provider, model, sort_order, is_default, alias_to, note,"
                     " record_status) VALUES(?,?,?,?,'','','LIVE')" % table,
                     (p, m, i, 1 if m == dflt else 0))
    for i, (old, new) in enumerate(sorted(alias.items())):
        conn.execute("INSERT OR REPLACE INTO %s(provider, model, sort_order, is_default, alias_to,"
                     " note, record_status) VALUES(?,?,?,0,?,'','LIVE')" % table,
                     (p, old, 900 + i, new))
    if bump:
        _bump(conn)
    conn.commit()
    return len(models)


def _bump(conn):
    _set_cfg(conn, VER_KEY, version(conn) + 1)
    _set_cfg(conn, TS_KEY, _now())


def seed(conn, force=False):
    """코드 씨앗(`user_ai.PROVIDERS` · `MODEL_ALIAS`)을 표에 심는다.

    ⚠ **이미 있는 회사는 안 덮는다**(`force` 라야 덮는다) — 관리자가 고쳐 둔 목록을
      다음 실행이 되돌리면 안 된다(§294차 「이미 적힌 칸은 안 덮는다」와 같은 규칙).
    """
    import user_ai as UA                                  # ⚠ 늦게 부른다(서로 부른다)
    ensure(conn)
    have = {r[0] for r in conn.execute("SELECT DISTINCT provider FROM %s" % TABLE)}
    n = 0
    for key, _name, dflt, _url, models in UA.PROVIDERS:
        if key in have and not force:
            continue
        al = UA.MODEL_ALIAS if key == 'GEMINI' else {}
        set_provider(conn, key, models, dflt, al, bump=False)
        n += 1
    if n:
        _bump(conn)
    conn.commit()
    return n


# ══════════════════════════════════════════════════════════════════════
#  발행 · 받기 — 관리자가 고치면 사용자가 자동으로 받는다
# ══════════════════════════════════════════════════════════════════════
def export_payload(conn):
    """발행할 꾸러미(dict). **키는 한 글자도 안 들어간다.**"""
    return {'version': version(conn), 'updated': _now(), 'providers': catalog(conn)}


def export_json(conn):
    return json.dumps(export_payload(conn), ensure_ascii=False, sort_keys=True)


def apply_payload(conn, payload, to_user=True):
    """받은 꾸러미를 담는다 — `{applied, n, version, why}`.

    ★ 기본은 **받는 쪽**(개인 표 `UTABLE` · 판은 `userdb.user_config`).
      `to_user=False` 면 관리자 표에 담는다(꾸러미를 손으로 들여올 때).
    ⚠⚠ **판이 같거나 낮으면 안 쓴다** — 날마다 같은 파일이 와도 표를 안 건드린다
      (감사 트리거가 행마다 남는다 §293차 「같은 값이면 안 쓴다」).
      ⚠ 견주는 판은 **둘 중 큰 것**이다 — 코어팩이 방금 새 판을 실어 왔는데 CDN 에
        낡은 파일이 남아 있으면 그것으로 되돌아가면 안 된다.
    ⚠ 꼴이 깨졌으면 **아무것도 안 쓴다** — 반쯤 담으면 목록이 통째로 비는 날이 온다.
    """
    _tab = UTABLE if to_user else TABLE
    _cfg = 'userdb.user_config' if to_user else 'sys_config' 
    if isinstance(payload, (str, bytes)):
        try:
            payload = json.loads(payload)
        except Exception as e:                            # noqa: BLE001
            return {'applied': False, 'n': 0, 'version': max(version(conn), user_version(conn)),
                    'why': 'JSON 이 아니다: %s' % e}
    if not isinstance(payload, dict) or not isinstance(payload.get('providers'), dict):
        return {'applied': False, 'n': 0, 'version': max(version(conn), user_version(conn)), 'why': '꼴이 아니다'}
    try:
        ver = int(payload.get('version') or 0)
    except Exception:                                     # noqa: BLE001
        return {'applied': False, 'n': 0, 'version': max(version(conn), user_version(conn)),
                'why': '판이 숫자가 아니다'}
    cur = max(version(conn), user_version(conn))
    if ver <= cur:
        return {'applied': False, 'n': 0, 'version': cur, 'why': '이미 그 판(또는 더 새것)이다'}
    # ⚠ 모르는 회사는 건너뛴다 — 어댑터가 없으면 고를 수 있어도 못 보낸다(§0-1)
    import user_ai as UA
    known = set(UA.PROVIDER)
    clean = []
    for p, d in payload['providers'].items():
        p = str(p).strip().upper()
        if p not in known or not isinstance(d, dict):
            continue
        models = [str(m).strip() for m in (d.get('models') or []) if str(m).strip()]
        alias = {str(k).strip(): str(v).strip() for k, v in (d.get('alias') or {}).items()
                 if str(k).strip() and str(v).strip()}
        if not models and not alias:
            continue
        clean.append((p, models, str(d.get('model') or d.get('default') or '').strip(), alias))
    if not clean:
        return {'applied': False, 'n': 0, 'version': cur, 'why': '담을 회사가 없다'}
    (ensure_user if to_user else ensure)(conn)
    for p, models, dflt, alias in clean:
        set_provider(conn, p, models, dflt, alias, bump=False, table=_tab)
    _set_cfg(conn, VER_KEY, ver, _cfg)
    _set_cfg(conn, TS_KEY, str(payload.get('updated') or _now()), _cfg)
    conn.commit()
    return {'applied': True, 'n': len(clean), 'version': ver, 'why': ''}


# ══════════════════════════════════════════════════════════════════════
#  자가 검증 — 망 안 씀 · 실 DB 자국 0
# ══════════════════════════════════════════════════════════════════════
def selftest():
    import sqlite3
    bad, n = [], [0]

    def ck(c, m, got=''):
        n[0] += 1
        if not c:
            bad.append('%s %s' % (m, ('| ' + str(got)[:120]) if got else ''))

    import user_ai as UA

    def _db():
        """실제 모양 — main + `userdb` 붙임(`appdb.connect` 와 같다)."""
        c = sqlite3.connect(':memory:')
        c.execute("ATTACH ':memory:' AS userdb")
        c.execute("CREATE TABLE sys_config(config_key TEXT PRIMARY KEY, config_val TEXT)")
        c.execute("CREATE TABLE userdb.user_config(config_key TEXT PRIMARY KEY, config_val TEXT)")
        return c

    mem = _db()
    ensure(mem)
    ensure(mem)
    ck(True, '표 만들기가 멱등이다')
    ck(catalog(mem) == {}, '표가 비면 빈 목록(코드 씨앗이 쓰인다)')

    n_seed = seed(mem)
    ck(n_seed == len(UA.PROVIDERS), '씨앗 — 회사 전부를 심는다', n_seed)
    cat = catalog(mem)
    ck(set(cat) == set(UA.PROVIDER), '목록에 회사 넷', sorted(cat))
    ck(cat['GEMINI']['model'] == UA.PROVIDER['GEMINI']['model'], '기본 모델이 코드와 같다')
    ck(cat['GEMINI']['models'] == UA.PROVIDER['GEMINI']['models'], '후보 차례가 적은 차례대로')
    ck(cat['GEMINI']['alias'].get('gemini-2.5-flash') == 'gemini-flash-latest', '별칭이 함께 실린다')
    ck(all(a not in cat['GEMINI']['models'] for a in cat['GEMINI']['alias']),
       '★ 물린 이름은 후보 목록에 없다(선택하면 그 자리에서 404)')

    v1 = version(mem)
    ck(v1 >= 1, '판이 올랐다', v1)
    ck(seed(mem) == 0 and version(mem) == v1, '★ 이미 있는 회사는 씨앗이 안 덮는다(판도 그대로)')
    seed(mem, force=True)
    ck(version(mem) == v1 + 1, 'force 면 덮고 판이 오른다')

    set_provider(mem, 'GEMINI', ['m-a', 'm-b'], 'm-b', {'old-x': 'm-a'})
    cat = catalog(mem)
    ck(cat['GEMINI']['models'] == ['m-a', 'm-b'] and cat['GEMINI']['model'] == 'm-b',
       '한 회사를 갈아 끼운다 · 기본을 선택한다', cat['GEMINI'])
    ck(cat['OPENAI']['models'] == UA.PROVIDER['OPENAI']['models'], '남의 회사는 안 건드린다')
    set_provider(mem, 'GEMINI', ['m-a'], '')
    ck(catalog(mem)['GEMINI']['model'] == 'm-a' and not catalog(mem)['GEMINI']['alias'],
       '기본을 안 주면 첫째 · 옛 별칭은 함께 걷힌다')

    # 발행 꾸러미 — 키가 안 들어간다
    pay = export_payload(mem)
    txt = export_json(mem)
    ck(set(pay) == {'version', 'updated', 'providers'}, '꾸러미 칸 셋', sorted(pay))
    ck('key' not in txt.lower() and 'sk-' not in txt and 'AIza' not in txt,
       '★ 발행 꾸러미에 키가 한 글자도 없다')
    ck(json.loads(txt)['providers']['GEMINI']['models'] == ['m-a'], '꾸러미가 지금 목록을 담는다')

    # 받기 — 판이 낮으면 안 쓴다 · 모르는 회사는 건너뛴다 · 깨졌으면 아무것도 안 쓴다
    mem2 = _db()
    ensure(mem2)
    got = apply_payload(mem2, {'version': 5, 'updated': 'x', 'providers': {
        'GEMINI': {'model': 'g2', 'models': ['g1', 'g2'], 'alias': {'g0': 'g1'}},
        'NOSUCH': {'models': ['z']}}})
    ck(got['applied'] and got['n'] == 1 and user_version(mem2) == 5, '받으면 담고 판이 그 판이 된다', got)
    ck(version(mem2) == 0, '★ 받는 것은 개인 표다 — 관리자 판은 안 건드린다', version(mem2))
    ck(not mem2.execute("SELECT COUNT(*) FROM %s" % TABLE).fetchone()[0],
       '★ 받아도 `sys_ai_model` 은 한 줄도 안 늘어난다(§C-2)')
    ck(catalog(mem2)['GEMINI']['model'] == 'g2', '받은 기본 모델')
    ck('NOSUCH' not in catalog(mem2), '★ 어댑터가 없는 회사는 안 담는다(선택할 수 있는데 못 보내면 안 된다)')
    got = apply_payload(mem2, {'version': 5, 'providers': {'GEMINI': {'models': ['zzz']}}})
    ck(not got['applied'] and catalog(mem2)['GEMINI']['models'] == ['g1', 'g2'],
       '★ 같은 판이면 한 줄도 안 쓴다(날마다 같은 파일이 와도)', got)
    got = apply_payload(mem2, {'version': 6, 'providers': 'nope'})
    ck(not got['applied'] and user_version(mem2) == 5, '꼴이 깨졌으면 아무것도 안 쓴다')
    got = apply_payload(mem2, 'not json')
    ck(not got['applied'], 'JSON 이 아니면 안 쓴다')
    got = apply_payload(mem2, export_json(mem2))
    ck(not got['applied'], '제 꾸러미를 다시 받아도 안 쓴다(멱등)')
    got = apply_payload(mem2, {'version': 7, 'providers': {'GEMINI': {'models': ['g9']}}})
    ck(got['applied'] and catalog(mem2)['GEMINI']['models'] == ['g9'], '판이 오르면 담는다')

    # ★★★ 두 길이 겹치는 자리 — 코어팩(연 2회) ↔ RSS(날마다). **판이 새것이 이긴다**
    set_provider(mem2, 'GEMINI', ['core-1'], 'core-1')     # 코어팩이 실어 온 셈(판 1)
    ck(version(mem2) == 1 and user_version(mem2) == 7, '관리자 판과 받은 판이 따로 센다',
       (version(mem2), user_version(mem2)))
    ck(catalog(mem2)['GEMINI']['models'] == ['g9'],
       '★★★ 낡은 코어팩이 어제 받은 목록을 못 되돌린다(이 갈래를 만든 까닭)')
    ck(apply_payload(mem2, {'version': 6, 'providers': {'GEMINI': {'models': ['old']}}})['applied'] is False,
       '★ CDN 에 낡은 파일이 남아도 되돌아가지 않는다')
    for _i in range(9):
        set_provider(mem2, 'OPENAI', ['core-o'], 'core-o')  # 관리자 판을 7 위로 올린다
    ck(version(mem2) > user_version(mem2), '관리자 판이 받은 판을 넘었다', (version(mem2), user_version(mem2)))
    ck(catalog(mem2)['GEMINI']['models'] == ['core-1'],
       '★ 관리자 판이 더 새것이면 코어팩이 이긴다(양방향)')
    ck(apply_payload(mem2, {'version': 99, 'providers': {'GEMINI': {'models': ['g99']}}})['applied']
       and catalog(mem2)['GEMINI']['models'] == ['g99'], '더 새 판을 받으면 다시 RSS 가 이긴다')

    # user_ai 병합 — 표가 코드를 이긴다 · 표가 비면 코드
    ck(UA.providers(mem2)['GEMINI']['models'] == ['g99'], '★ user_ai 가 표를 읽는다(표가 코드를 이긴다)')
    ck(UA.providers(mem2)['GEMINI']['name'] == UA.PROVIDER['GEMINI']['name'],
       '회사 이름·키 받는 곳은 코드 그대로(어댑터가 코드에 있다)')
    mem3 = sqlite3.connect(':memory:')
    ck(UA.providers(mem3)['OPENAI']['models'] == UA.PROVIDER['OPENAI']['models'],
       '표에 없는 회사는 코드 씨앗')
    ck(UA.providers(mem3)['GEMINI']['models'] == UA.PROVIDER['GEMINI']['models'],
       '표가 아예 없어도 코드로 돈다(조용히 안 터진다)')
    ck(UA.model_alias('GEMINI', 'g0', mem2) == 'g0', '판을 갈아 끼우면 옛 별칭은 사라진다')
    apply_payload(mem2, {'version': 100, 'providers': {'GEMINI': {'models': ['g9'], 'alias': {'g0': 'g9'}}}})
    ck(UA.model_alias('GEMINI', 'g0', mem2) == 'g9', '★ 받은 별칭이 물린 이름을 옮긴다')
    ck(UA.model_alias('GEMINI', 'gemini-2.5-flash', mem2) == 'gemini-flash-latest',
       '표에 없는 별칭은 코드 씨앗이 받친다')

    # 실 DB — 자국 0(읽기만)
    conn = appdb.connect()
    try:
        before = conn.execute("SELECT COUNT(*) FROM sys_config").fetchone()[0]
        _c = catalog(conn)
        ck(isinstance(_c, dict), '실 DB 에서 읽힌다', type(_c))
        ck(conn.execute("SELECT COUNT(*) FROM sys_config").fetchone()[0] == before, '실 DB 자국 0')
        ck(not conn.execute("SELECT 1 FROM main.sqlite_master WHERE name='user_ai_chat'").fetchone(),
           '개인 표는 main 에 안 만든다')
        ck(not conn.execute("SELECT 1 FROM main.sqlite_master WHERE name='user_ai_model'").fetchone(),
           '★ 받는 표를 main 에 만들지 않는다(userdb 뿐)')
    finally:
        conn.close()
    mem.close(); mem2.close(); mem3.close()

    for b in bad:
        print('  FAIL', b)
    print('db_ai_models selftest: %s (%d/%d)' % ('OK' if not bad else 'FAIL', n[0] - len(bad), n[0]))
    return 0 if not bad else 1


def main(argv):
    if '--selftest' in argv:
        return selftest()
    conn = appdb.connect()
    try:
        if '--seed' in argv:
            print('씨앗 심은 회사 %d · 판 %d' % (seed(conn, '--force' in argv), version(conn)))
        elif '--export' in argv:
            sys.stdout.write(export_json(conn) + chr(10))
        elif '--version' in argv:
            # ⚠ 판이 둘이다 — 관리자·코어팩(sys)과 **RSS 로 받은 것**(userdb).
            #   쓰이는 것은 **더 새것**이다(`catalog`).
            print('관리자 판 %d · 받은 판 %d  → 쓰이는 것 %s'
                  % (version(conn), user_version(conn),
                     '받은 목록' if user_version(conn) > version(conn) else '관리자 목록'))
        else:
            cat = catalog(conn)
            print('AI 모델 목록 — 관리자 판 %d · 받은 판 %d' % (version(conn), user_version(conn)))
            for p in sorted(cat):
                d = cat[p]
                print('  %-10s 기본 %-28s 후보 %d · 별칭 %d' % (p, d['model'], len(d['models']), len(d['alias'])))
                for m in d['models']:
                    print('      %s%s' % (m, '  ← 기본' if m == d['model'] else ''))
                for k, v in sorted(d['alias'].items()):
                    print('      %s → %s  (물린 이름)' % (k, v))
            if not cat:
                print('  (표가 비었습니다 — `--seed` 로 코드 씨앗을 심으세요. 지금은 코드 목록이 쓰입니다.)')
    finally:
        conn.close()
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
