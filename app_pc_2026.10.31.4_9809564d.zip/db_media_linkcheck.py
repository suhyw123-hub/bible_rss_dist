# -*- coding: utf-8 -*-
"""유튜브 링크 점검 흐름 — **장부 하나 · 화면 하나 · 매일 한 번**.

★ 왜 만들었나 (2026-09-08 사용자 지시 — 「**링크점검은 반드시 하나만 두어야
  한다. 휴면링크는 별도 보관함으로 옮겼다가 다시 점검해도 비활성화 상태라면
  제거**해야 한다」).
  그전 상태(실측):
  · 점검 화면이 **셋**(구절·용어 탭 둘 + 상태점검 메뉴) — `ALL` ⊃ 나머지.
  · 18,380건 중 **269건(1.5%)** 만 점검됐다 — 사람이 눌러야 돌았다.
  · `is_active=0`(8,828건)이 **「미검토」와 「점검 실패」 두 뜻**이라 가릴 수
    없었고, 죽은 것을 「죽은 것만 보기」로 모을 재료(`http_status`)가 없었다.

★★★ **장부는 별도 표 `sys_media_check` 다 — `sys_media_asset` 에 칸을 더하지
  않는다.** 그 표는 **코어팩(RULE_ONLY)** 이고 **감사 트리거 대상**이라,
  매일 수천 행의 `checked_at` 을 거기에 쓰면 ⓐ 감사 로그가 하루 4~5MB 씩
  는다(UPDATE 는 옛 행 전체를 남긴다) ⓑ 코어 델타가 매일 수천 행을 싣는다.
  점검 기록은 콘텐츠가 아니라 **운영 장부**다 — `db_pack_catalog` 에 LOCAL.
  ⚠ 옛 칸 `sys_media_asset.last_checked`·`fail_count` 는 **읽지도 쓰지도
    않는다** — `init` 이 한 번 옮겨 오고 그 뒤로는 이 표가 단일 소스다.

★★★ **조회수도 이 장부에 있다**(2026-09-09 사용자 「조회수 데이터도 중요하다」).
  `videos.list` 는 **50개당 1 unit** 이라 `part` 에 `statistics` 를 더해도
  **비용이 0**이다 — 점검이 이미 날마다 2,000건을 그 문으로 묻고 있었다.
  ⇒ **수집 경로를 하나하나 고치지 않는다.** RSS(쿼터 0)·검색·옛 자료가
    전부 이 뒤채움 하나로 덮인다(19,301편 ÷ 2,000 = 열흘이면 한 바퀴).
  쓰는 문 `set_views` · 읽는 문 `views_of` 하나씩이고 **잰 날을 함께 적는다**
  (조회수는 자라므로 날짜가 없으면 두 값을 견줄 수 없다).
  ⚠ **비공개인 영상이 있다** — 값이 없으면 아무것도 안 쓴다(0 으로 짓지 않는다).

★★★ **상태 모델** — 「미검토」와 「휴면」을 `dormant_since` 로 가른다.
  | 상태 | is_active | dormant_since | record_status |
  |---|---|---|---|
  | 미검토 | 0 | NULL | LIVE |
  | 승인 | 1 | NULL | LIVE |
  | **휴면**(점검 실패 · 보관함) | **0** | 날짜 | LIVE |
  | **제거** | 0 | 날짜 | **HIDE** |
  ★ 휴면은 `is_active=0` 이라 **모든 독자가 저절로 뺀다**(화면·팩·발행·
    커버리지). 대신 **미검토를 세는 자리는 `not_dormant()` 를 함께 건다** —
    안 걸면 휴면이 「미검토」로 되살아나 자동 승인이 다시 켠다.
  ★ 되살리면 `was_active` 로 돌아간다 — 휴면 전에 승인이었으면 승인으로.

★★★ **흐름** — 죽음(DEAD·EMBED_BLOCKED) → 휴면 → `DORMANT_DAYS` 뒤 재점검 →
  여전히 죽음 → **제거**(`record_status='HIDE'` · 되돌릴 수 있고 「삭제된
  미디어」 화면에 뜬다) · 살아났으면 **복귀**.
  ⚠ **쇼츠(60초 이하)는 상태만 적고 안 옮긴다** — 쇼츠는 영원히 쇼츠라
    휴면→제거를 타면 30일 뒤 자동으로 지워진다. 「쓸 만한 것은 남긴다」는
    사람의 판단이다(화면 「쇼츠」 갈래에서 정한다).
  ⚠ 확인 불가(UNKNOWN)는 아무것도 안 바꾼다 — 못 본 것과 없는 것은 다르다.

★ **매일 돈다** — `collect_channels.py` 걸음 ④ 가 `run()` 을 부른다.
  차례 = ① 휴면 재점검(기한 지난 것) → ② 미점검·30일 지난 것. 예산
  `DAILY_MAX`(API 50개당 1 unit — 2,000건 = 40 units). 키가 없으면 **왜
  못 도는지 말하고** 건너뛴다.

--selftest | --status | --run [--limit N] [--dry] | --undo-removed [--since …]
| --revive-embed  (임베드 차단으로 내려간 것 되살리기 — 283차 ①)
"""

import io
import json
import os
import re
import sys
import time
from datetime import date, timedelta

try:
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', errors='replace')
except Exception:
    pass

TBL = 'sys_media_check'
#: 휴면 뒤 며칠 지나면 다시 점검하나
DORMANT_DAYS = 30
#: 매일 작업이 한 번에 점검하는 최대 건수(API 50개당 1 unit)
DAILY_MAX = 2000
#: 「오래된 것」의 기준
STALE_DAYS = 30
#: 제거한 행의 표식 — `undo_removed` 가 이 글자로 찾는다
NOTE_REMOVED = 'LINKCHECK_REMOVED'
#: 마지막 자동 실행 기록(sys_config)
LOG_KEY = 'MEDIA_LINKCHECK_LAST'

#: 점검 결과 코드 → (라벨, 색 역할, 죽음인가)
#: ★ 화면이 이 표를 그대로 읽는다 — 두 벌이면 라벨이 갈린다.
STATUS = {
    'OK':            ('정상',            'success', False),
    'DEAD':          ('삭제/비공개',     'danger',  True),
    # ⚠⚠⚠ **죽음이 아니다**(2026-09-24 1.txt 14번). 임베드 차단은 「없는
    #   영상」이 아니라 **「여기서 못 트는 영상」**이고 브라우저·유튜브 쪽에서는
    #   멀쩡히 돈다. 죽음으로 치는 동안 **273편을 휴면으로 내렸고 그중 114편이
    #   승인 영상**이었다 — 크리에이터가 임베드를 껐다는 이유로 설교를 버렸다.
    #   ⇒ 상태는 그대로 적되(여는 방식을 정하는 근거다) **내리지 않는다**.
    'EMBED_BLOCKED': ('임베드 차단',     'warning', False),
    'SHORT':         ('쇼츠(60초 이하)', 'accent',  False),
    'UNKNOWN':       ('확인 불가',       'fg_dim',  False),
}
DEAD = tuple(k for k, v in STATUS.items() if v[2])

#: 대상 범위(화면 콤보와 매일 작업이 같은 이름을 쓴다)
RANGES = (
    ('UNCHECKED',   '미점검만'),
    ('STALE',       '오래된(%d일+)' % STALE_DAYS),
    ('ACTIVE',      '승인 영상 전부'),
    ('ALL_LIVE',    '전부(미검토 포함)'),
    ('DORMANT_DUE', '휴면 — 재점검 기한 지남'),
    ('DORMANT_ALL', '휴면 전부'),
)


# ── 장부 ────────────────────────────────────────────────────────────────────

def ensure(conn):
    """표만 만든다(멱등 · 옮겨 오기 없음). 화면 조회가 조건에 이 표를 쓴다."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS %s (
            media_id      INTEGER PRIMARY KEY,
            status        TEXT,
            detail        TEXT,
            checked_at    TEXT,
            fail_count    INTEGER NOT NULL DEFAULT 0,
            dormant_since TEXT,
            was_active    INTEGER,
            removed_at    TEXT,
            note          TEXT
        )""" % TBL)
    conn.execute("CREATE INDEX IF NOT EXISTS ix_media_check_dormant"
                 " ON %s(dormant_since)" % TBL)
    # ★ 조회수(2026-09-09) — 이 장부에 둔다. `sys_media_asset` 에 두면 매일
    #   수천 행을 UPDATE 하게 되어 **감사 로그가 옛 행 전체를 남기고** 코어
    #   델타가 매일 그만큼 실린다(§211차가 `last_checked` 를 옮긴 그 까닭).
    #   조회수는 콘텐츠가 아니라 **운영 장부**다.
    cols = [r[1] for r in conn.execute("PRAGMA table_info(%s)" % TBL)]
    # ★★★ **길이 칸**(2026-09-11 사용자 「2분 이내는 숏츠로 취급하자」) —
    #   그전에는 길이가 **글자 칸(`detail`)에 「N초」로만** 있어 거르려면 다시
    #   파싱해야 했고, 실측 **찬양 1,903편 중 길이를 아는 것이 5%**뿐이었다.
    #   ⚠ `videos.list` 가 `contentDetails` 를 **이미 받고 있다** — 담기만 하면
    #     되고 **추가 비용이 0**이다.
    for c_, ty in (('views', 'INTEGER'), ('views_at', 'TEXT'),
                   ('duration', 'INTEGER')):
        if c_ not in cols:
            conn.execute("ALTER TABLE %s ADD COLUMN %s %s" % (TBL, c_, ty))
    return True


def set_duration(conn, mid, sec):
    """길이를 장부에 적는다 — **쓰는 문 하나**. 값이 없으면 안 쓴다."""
    if sec is None:
        return False
    ensure(conn)
    conn.execute("INSERT INTO %s(media_id, duration) VALUES(?,?)"
                 " ON CONFLICT(media_id) DO UPDATE SET duration=excluded.duration"
                 % TBL, (int(mid), int(sec)))
    return True


def duration_of(conn):
    """media_id → 길이(초). **모르는 것은 안 담는다.**"""
    ensure(conn)
    return {r[0]: r[1] for r in conn.execute(
        "SELECT media_id, duration FROM %s WHERE duration IS NOT NULL" % TBL)}


def set_views(conn, mid, views, at=None):
    """조회수를 장부에 적는다 — **쓰는 문 하나**(수집·점검이 함께 쓴다).

    ⚠ **잰 날을 함께 적는다** — 조회수는 자라므로 언제 잰 값인지 없으면 다음에
      두 값을 견줄 수 없다.
    ⚠ **비공개인 영상이 있다** — 값이 없으면 아무것도 안 쓴다(0 으로 짓지 않는다).
    """
    if views is None or views == '':
        return False
    try:
        v = int(views)
    except (TypeError, ValueError):
        return False
    ensure(conn)
    at = at or date.today().isoformat()
    conn.execute("INSERT OR IGNORE INTO %s(media_id) VALUES(?)" % TBL, (mid,))
    conn.execute("UPDATE %s SET views=?, views_at=? WHERE media_id=?" % TBL,
                 (v, at, mid))
    return True


#: ★★★ **채널 장부** — 구독자 수(2026-09-10 사용자 「구독자수 데이터도 수집
#:   가능하면 추가해도 좋다」). 조회수와 같은 성격이다:
#:   ⚠ **사용자에게 안 보인다** — 수시로 바뀌므로 보이면 늘 낡은 값이 된다.
#:     관리자가 채널 규모를 가늠하고 사역자 「주요/일반」을 정하는 재료다.
#:   ⚠ **배포 안 함(LOCAL)** — 날마다 바뀌는 값을 코어팩에 실으면 델타가 매일
#:     그만큼 커진다(§233차가 조회수를 운영 장부로 옮긴 그 까닭).
CH_TBL = 'sys_channel_stat'


def ensure_ch(conn):
    """채널 장부(멱등)."""
    conn.execute(
        "CREATE TABLE IF NOT EXISTS %s ("
        " channel_ext_id TEXT PRIMARY KEY,"
        " channel_name   TEXT,"
        " subs           INTEGER,"
        " n_video        INTEGER,"
        " views          INTEGER,"
        " taken_at       TEXT)" % CH_TBL)
    return True


def set_channel_stat(conn, ext_id, subs=None, n_video=None, views=None,
                     name=None, at=None):
    """채널 규모를 적는다 — **쓰는 문 하나**.

    ⚠ 구독자 수를 **숨긴 채널**이 있다(`hiddenSubscriberCount`) — 값이 없으면
      아무것도 안 쓴다(0 으로 짓지 않는다).
    """
    if not ext_id:
        return False
    ensure_ch(conn)
    at = at or date.today().isoformat()
    sets, args = [], []
    for col, v in (('channel_name', name), ('subs', subs),
                   ('n_video', n_video), ('views', views)):
        if v is None or v == '':
            continue
        sets.append('%s=?' % col)
        args.append(v if col == 'channel_name' else int(v))
    if not sets:
        return False
    conn.execute("INSERT OR IGNORE INTO %s(channel_ext_id) VALUES(?)"
                 % CH_TBL, (ext_id,))
    sets.append('taken_at=?')
    args.append(at)
    args.append(ext_id)
    conn.execute("UPDATE %s SET %s WHERE channel_ext_id=?"
                 % (CH_TBL, ', '.join(sets)), args)
    return True


def channel_stats(conn, ids=None):
    """{채널id: (구독자, 영상수, 조회수합, 잰 날)} — **읽는 문 하나**."""
    try:
        ensure_ch(conn)
    except Exception:
        return {}
    q = ("SELECT channel_ext_id, subs, n_video, views, taken_at FROM %s"
         % CH_TBL)
    args = ()
    if ids:
        ids = list(ids)
        q += " WHERE channel_ext_id IN (%s)" % ','.join('?' * len(ids))
        args = tuple(ids)
    return {r[0]: (r[1], r[2], r[3], r[4]) for r in conn.execute(q, args)}


def backfill_views(conn, keys=None, limit=None, only_missing=True, log=print):
    """이미 담은 영상의 **조회수만** 받아 채운다 → 요약 dict.

    ★★★ 왜 매일 점검(`run`)과 따로 두나 — `run` 은 상태까지 기록해 **점검 차례를
      건드린다**. 19,645편을 한 번에 돌리면 `checked_at` 이 전부 오늘이 되어
      돌려 가며 보는 얼개가 무너진다. 이 문은 **조회수만** 적는다.
    ⚠ `videos.list` 는 **50개당 1 unit** 이라 19,645편이 **396 units** 다
      (키 하나 하루 10,000). 값이 싸서 통째로 한 번에 돈다.
    ⚠ `only_missing` 이 참이면 **아직 조회수가 없는 것만** 묻는다(멱등·재개).
    """
    today = date.today().isoformat()
    ensure(conn)
    keys = keys if keys is not None else api_keys(conn)
    if not keys:
        log('  [조회수] API 키가 없습니다.')
        return {'skipped': 'NO_KEY'}
    have = set(views_of(conn)) if only_missing else set()
    rows = [(m, u) for m, u in conn.execute(
        "SELECT media_id, url FROM sys_media_asset"
        " WHERE record_status='LIVE' AND url IS NOT NULL")
        if m not in have]
    if limit:
        rows = rows[:int(limit)]
    out = {'asked': len(rows), 'got': 0, 'none': 0, 'units': 0, 'err': []}
    if not rows:
        log('  [조회수] 채울 것이 없습니다.')
        return out
    log('  [조회수] %d편 · 예상 %d units' % (len(rows), -(-len(rows) // 50)))

    def on_stats(mid, views):
        if set_views(conn, mid, views, today):
            out['got'] += 1
            if out['got'] % 500 == 0:
                conn.commit()

    probe_api(rows, keys, lambda *a: None, on_stats=on_stats,
              on_error=lambda m: out['err'].append(m))
    conn.commit()
    out['none'] = len(rows) - out['got']
    out['units'] = -(-len(rows) // 50)
    log('  [조회수] 채운 것 %d · 값이 없던 것 %d · 쓴 units %d'
        % (out['got'], out['none'], out['units']))
    return out


def backfill_channel_id(conn, keys=None, limit=None, log=print):
    """이미 담은 영상의 **채널 id** 를 받아 채운다 → 요약 dict.

    ★★★ 2026-09-12 — **채널 등록의 문턱이 이것이었다.** RSS 는
      `channel_ext_id` 가 있어야 도는데, 검색 경로가 `channelId` 를 안 담던
      옛 수집분에는 그 칸이 비어 있다(§228차 ②).
      ✅ 실측 — 그 때문에 **승인률 100%인 채널 154곳**(새교회_조덕남목사 55/55 ·
        안천교회 41/40 · 성경한장 36/36)을 **등록하지 못하고 있었다.**
    ⚠ **비용이 0에 가깝다** — `videos.list` 는 50개당 1 unit 이고 `snippet` 은
      이미 같은 응답에 있다. 1,170편이면 **24 units**.
    ⚠ `run` 과 **따로 둔다** — 점검 차례(`checked_at`)를 안 건드린다(§233차 ⑯).
    """
    import json as _js
    ensure(conn)
    keys = keys if keys is not None else api_keys(conn)
    if not keys:
        log('  [채널id] API 키가 없습니다.')
        return {'skipped': 'NO_KEY'}
    rows = []
    for mid, url, d in conn.execute(
            "SELECT media_id, url, COALESCE(description,'')"
            "  FROM sys_media_asset WHERE record_status='LIVE'"
            "   AND url IS NOT NULL"):
        try:
            j = _js.loads(d) if d.startswith('{') else {}
        except Exception:
            j = {}
        if not (j.get('channel_id') or '').strip():
            rows.append((mid, url))
    if limit:
        rows = rows[:int(limit)]
    out = {'asked': len(rows), 'got': 0, 'units': 0, 'err': []}
    if not rows:
        log('  [채널id] 채울 것이 없습니다.')
        return out
    log('  [채널id] %d편 · 예상 %d units' % (len(rows), -(-len(rows) // 50)))

    def on_ch(mid, cid, cnm):
        r = conn.execute("SELECT COALESCE(description,'') FROM sys_media_asset"
                         "  WHERE media_id=?", (mid,)).fetchone()  # status-ok: 번호 하나로 제 줄을 읽는다
        if not r:
            return
        try:
            j = _js.loads(r[0]) if r[0].startswith('{') else {}
        except Exception:
            j = {}
        if (j.get('channel_id') or '').strip():
            return
        j['channel_id'] = cid
        if cnm and not (j.get('channel') or '').strip():
            j['channel'] = cnm
        conn.execute("UPDATE sys_media_asset SET description=? WHERE media_id=?",
                     (_js.dumps(j, ensure_ascii=False), mid))
        out['got'] += 1
        if out['got'] % 500 == 0:
            conn.commit()

    probe_api(rows, keys, lambda *a: None, on_channel=on_ch,
              on_error=lambda m: out['err'].append(m))
    conn.commit()
    out['units'] = -(-len(rows) // 50)
    log('  [채널id] 채운 것 %d / %d · 쓴 units %d'
        % (out['got'], len(rows), out['units']))
    return out


#: 쇼츠 표시 — **제목에 스스로 적어 둔 것**(실측으로 모았다)
#:   ⚠⚠ **홑낱말 `short` 를 안 본다**(§228차 홑낱말 함정) — `short-cut`·
#:     `short film` 을 먹는다. 맨 낱말은 **복수형 `shorts`** 만 본다.
SHORT_MARK = re.compile(r'#\s*shorts?\b'
                        r'|(?<![A-Za-z])shorts(?![A-Za-z])'
                        r'|쇼츠|숏츠', re.I)


def backfill_duration(conn, keys=None, limit=None, only_missing=True,
                      kind=None, log=print):
    """이미 담은 영상의 **길이만** 받아 채운다 → 요약 dict.

    ★★★ 2026-09-11 사용자 「2분 기준 적용하라 … 수집된 숏츠를 모두 보내라」.
    ★ `backfill_views` 와 같은 얼개다 — **매일 점검(`run`)과 따로 둔다.**
      `run` 은 상태까지 적어 **점검 차례를 건드린다**(§233차 ⑯).
    ⚠ `videos.list` 는 **50개당 1 unit** 이고 `contentDetails` 는 이미 받는
      칸이라 **비용이 조회수 채우기와 같다**.
    """
    ensure(conn)
    keys = keys if keys is not None else api_keys(conn)
    if not keys:
        log('  [길이] API 키가 없습니다.')
        return {'skipped': 'NO_KEY'}
    have = set(duration_of(conn)) if only_missing else set()
    q = ("SELECT media_id, url FROM sys_media_asset"
         " WHERE record_status='LIVE' AND url IS NOT NULL")
    args = []
    if kind:
        q += " AND media_type=?"
        args.append(kind)
    rows = [(m, u) for m, u in conn.execute(q, args) if m not in have]
    if limit:
        rows = rows[:int(limit)]
    out = {'asked': len(rows), 'got': 0, 'units': 0, 'err': []}
    if not rows:
        log('  [길이] 채울 것이 없습니다.')
        return out
    log('  [길이] %d편 · 예상 %d units' % (len(rows), -(-len(rows) // 50)))

    def on_dur(mid, sec):
        if set_duration(conn, mid, sec):
            out['got'] += 1
            if out['got'] % 500 == 0:
                conn.commit()

    probe_api(rows, keys, lambda *a: None, on_duration=on_dur,
              on_error=lambda m: out['err'].append(m))
    conn.commit()
    out['units'] = -(-len(rows) // 50)
    log('  [길이] 채운 것 %d · 쓴 units %d' % (out['got'], out['units']))
    return out


SHORT_NOTE = 'SHORT_SWEEP_20260911'


def short_rows(conn, kind=None, sec=None):
    """쇼츠로 볼 영상 → [(media_id, 제목, 길이, 까닭)].

    ★ 두 갈래 — ⓐ **길이가 문턱 이하** ⓑ **제목이 스스로 쇼츠라고 적었다**.
    ⚠ ⓑ 는 길이를 몰라도 쓸 수 있다 — 실측 찬양 1,903편 중 길이를 아는 것이
      5%뿐이라, 길이만 보면 41편을 놓친다.
    """
    sec = SHORT_SEC if sec is None else int(sec)
    ensure(conn)
    q = ("SELECT m.media_id, m.title, k.duration FROM sys_media_asset m"
         "  LEFT JOIN %s k ON k.media_id=m.media_id"
         " WHERE m.record_status='LIVE'" % TBL)
    args = []
    if kind:
        q += " AND m.media_type=?"
        args.append(kind)
    out = []
    for mid, ti, du in conn.execute(q, args):
        if du is not None and du <= sec:
            out.append((mid, ti or '', du, '%d초' % du))
        elif SHORT_MARK.search(ti or ''):
            out.append((mid, ti or '', du, '제목이 쇼츠라고 적었습니다'))
    return out


def sweep_shorts(conn, kind=None, sec=None, dry=False, log=print):
    """**쇼츠를 삭제 보관함으로 보낸다** → 보낸 수.

    ⚠⚠ **물리 삭제가 아니다**(§222차) — `record_status='HIDE'` 다. 지우면
      다음 수집에서 **같은 영상이 또 들어온다.**
    ⚠ 표식을 남긴다(`SHORT_NOTE`) — `sweep_undo` 로 돌아온다.
    """
    got = short_rows(conn, kind, sec)
    if dry:
        return len(got)
    for mid, ti, _du, why in got:
        conn.execute("UPDATE sys_media_asset SET record_status='HIDE',"
                     " is_active=0 WHERE media_id=?", (mid,))
        conn.execute("INSERT INTO %s(media_id, note) VALUES(?,?)"
                     " ON CONFLICT(media_id) DO UPDATE SET note=excluded.note"
                     % TBL, (mid, SHORT_NOTE))
        log('  쇼츠 → 보관함  %-46s (%s)' % (ti[:46], why))
    return len(got)


def sweep_shorts_undo(conn):
    """되돌린다 — **표식을 남긴 것만**."""
    n = 0
    for (mid,) in conn.execute("SELECT media_id FROM %s"
                               " WHERE COALESCE(note,'')=?" % TBL,
                               (SHORT_NOTE,)).fetchall():
        conn.execute("UPDATE sys_media_asset SET record_status='LIVE'"
                     " WHERE media_id=?", (mid,))
        conn.execute("UPDATE %s SET note=NULL WHERE media_id=?" % TBL, (mid,))
        n += 1
    return n


def collect_channel_subs(conn, keys=None, ids=None, log=print):
    """채널 **구독자 수**를 받아 채운다 → 요약 dict.

    ⚠ `channels.list` 도 **50개당 1 unit** 이다 — 실측 채널 2,861개 = 58 units.
    ⚠ 구독자를 숨긴 채널이 있다 — 그 값은 **안 쓴다**.
    """
    import json as _j
    today = date.today().isoformat()
    ensure_ch(conn)
    keys = keys if keys is not None else api_keys(conn)
    if not keys:
        log('  [구독자] API 키가 없습니다.')
        return {'skipped': 'NO_KEY'}
    if ids is None:
        ids = set()
        for (d,) in conn.execute(
                "SELECT description FROM sys_media_asset"
                " WHERE record_status='LIVE' AND description LIKE '{%'"):
            try:
                cid = _j.loads(d).get('channel_id')
            except Exception:
                cid = None
            if cid:
                ids.add(cid)
        for (e,) in conn.execute(
                "SELECT channel_ext_id FROM sys_media_channel"
                " WHERE channel_ext_id IS NOT NULL"):
            ids.add(e)
    ids = sorted(i for i in ids if i)
    out = {'asked': len(ids), 'got': 0, 'hidden': 0, 'units': 0, 'err': []}
    if not ids:
        log('  [구독자] 물을 채널이 없습니다.')
        return out
    log('  [구독자] 채널 %d개 · 예상 %d units' % (len(ids), -(-len(ids) // 50)))
    try:
        from googleapiclient.discovery import build as _b
    except Exception:
        out['err'].append('google-api 라이브러리가 없습니다')
        return out
    ki = 0
    i = 0
    while i < len(ids):
        batch = ids[i:i + 50]
        try:
            yt = _b('youtube', 'v3', developerKey=keys[ki % len(keys)],
                    cache_discovery=False)
            resp = yt.channels().list(part='snippet,statistics',
                                      id=','.join(batch)).execute()
        except Exception as e:
            ki += 1
            if ki >= len(keys):
                out['err'].append('API 오류: %s' % str(e)[:120])
                break
            continue
        out['units'] += 1
        for it in resp.get('items', []):
            st = it.get('statistics', {}) or {}
            nm = ((it.get('snippet') or {}).get('title') or '')
            hidden = st.get('hiddenSubscriberCount')
            subs = None if hidden else st.get('subscriberCount')
            if hidden:
                out['hidden'] += 1
            if set_channel_stat(conn, it['id'], subs=subs,
                                n_video=st.get('videoCount'),
                                views=st.get('viewCount'), name=nm, at=today):
                out['got'] += 1
        conn.commit()
        i += 50
    log('  [구독자] 채운 채널 %d · 구독자를 숨긴 채널 %d · 쓴 units %d'
        % (out['got'], out['hidden'], out['units']))
    return out


DEAD_TAG = 'CHAN_DEAD'


def check_channels(conn, keys=None, log=print, today=None, fetch_fn=None):
    """★★ **등록 채널 주소 점검**(2026-09-16 · 1.txt 17-3) — 채널이 사라졌는지를
    `channels.list`(50개당 1 unit · 2,434곳 = 49 units)로 하루 한 번 본다.

    그전에는 **영상 주소만** 점검했고 채널은 RSS 가 404 를 낼 때 간접으로만 알았다.
    · 있는 채널 = 규모(구독자·영상 수)를 함께 새로 적는다(`set_channel_stat`).
    · 없는 채널 = `sys_media_channel.note` 에 `CHAN_DEAD:날짜` 표식(있으면 안 겹친다).
      **수집을 끄지는 않는다** — 한 번의 응답 누락은 일시적일 수 있고, RSS 가 빈손이면
      어차피 안 담긴다. 사람이 등록채널 목록의 심사 칸에서 보고 정한다.
    · 되살아난 채널 = 표식을 걷는다.
    ⚠ 시험용 주입 — `fetch_fn(batch_ids)` → items 목록.
    """
    today = today or date.today().isoformat()
    ensure_ch(conn)
    try:
        have = {r[1] for r in conn.execute("PRAGMA table_info(sys_media_channel)")}
        if 'note' not in have:
            conn.execute("ALTER TABLE sys_media_channel ADD COLUMN note TEXT")
    except Exception:
        pass
    rows = conn.execute(
        "SELECT channel_id, channel_ext_id, channel_name, COALESCE(note,'') FROM sys_media_channel"
        " WHERE COALESCE(record_status,'LIVE')='LIVE' AND channel_ext_id IS NOT NULL"
        " AND channel_ext_id<>''").fetchall()
    out = {'asked': len(rows), 'found': 0, 'missing': [], 'revived': 0, 'units': 0, 'err': []}
    if not rows:
        log('  [채널 주소] 점검할 등록 채널이 없습니다.')
        return out
    if fetch_fn is None:
        keys = keys if keys is not None else api_keys(conn)
        if not keys:
            log('  [채널 주소] API 키가 없습니다.')
            out['skipped'] = 'NO_KEY'
            return out
        try:
            from googleapiclient.discovery import build as _b
        except Exception:
            out['err'].append('google-api 라이브러리가 없습니다')
            return out
        ki = [0]
        def fetch_fn(batch):
            while ki[0] < len(keys) * 2:
                try:
                    yt = _b('youtube', 'v3', developerKey=keys[ki[0] % len(keys)],
                            cache_discovery=False)
                    return yt.channels().list(part='snippet,statistics',
                                              id=','.join(batch)).execute().get('items', [])
                except Exception as e:
                    ki[0] += 1
                    last = e
            raise RuntimeError('API 오류: %s' % str(last)[:120])
    ids = [r[1] for r in rows]
    found = {}
    i = 0
    while i < len(ids):
        batch = ids[i:i + 50]
        try:
            items = fetch_fn(batch)
        except Exception as e:
            out['err'].append(str(e)[:120])
            break
        out['units'] += 1
        for it in items or []:
            found[it['id']] = it
        i += 50
    if out['err'] and not found:
        log('  [채널 주소] %s' % out['err'][0])
        return out
    checked = set(ids[:i])              # 오류로 못 물은 묶음은 판정하지 않는다
    for cid, ext, name, note in rows:
        if ext not in checked:
            continue
        it = found.get(ext)
        if it is not None:
            out['found'] += 1
            st = it.get('statistics', {}) or {}
            nm = ((it.get('snippet') or {}).get('title') or '')
            set_channel_stat(conn, ext, subs=(None if st.get('hiddenSubscriberCount') else st.get('subscriberCount')),
                             n_video=st.get('videoCount'), views=st.get('viewCount'), name=nm, at=today)
            if DEAD_TAG + ':' in note:
                new = ' '.join(w for w in note.split() if not w.startswith(DEAD_TAG + ':'))
                conn.execute("UPDATE sys_media_channel SET note=? WHERE channel_id=?", (new or None, cid))
                out['revived'] += 1
        else:
            out['missing'].append(name or ext)
            if DEAD_TAG + ':' not in note:
                conn.execute("UPDATE sys_media_channel SET note=? WHERE channel_id=?",
                             ((note + ' ' if note else '') + '%s:%s' % (DEAD_TAG, today), cid))
    conn.commit()
    log('  [채널 주소] 물은 채널 %d · 있음 %d · **없음 %d** · 되살아남 %d · %d units'
        % (out['asked'], out['found'], len(out['missing']), out['revived'], out['units']))
    for nm in out['missing'][:10]:
        log('    - 없음: %s' % nm)
    return out


def views_of(conn, mids=None):
    """{media_id: (조회수, 잰 날)} — **읽는 문 하나**. 없으면 안 담는다."""
    try:
        ensure(conn)
    except Exception:
        return {}
    q = "SELECT media_id, views, views_at FROM %s WHERE views IS NOT NULL" % TBL
    args = ()
    if mids:
        mids = list(mids)
        q += " AND media_id IN (%s)" % ','.join('?' * len(mids))
        args = tuple(mids)
    return {r[0]: (r[1], r[2]) for r in conn.execute(q, args)}


def init(conn):
    """표 + 옛 칸(`sys_media_asset.last_checked`·`fail_count`) 옮겨 오기(멱등).

    ⚠ 옛 칸은 그 뒤로 **안 읽는다** — 두 자리에 「마지막 점검」이 있으면
      갈린다. 옮겨 온 행은 `status` 가 비어 있다(무엇이었는지 모른다).
    """
    ensure(conn)
    cols = [r[1] for r in conn.execute("PRAGMA table_info(sys_media_asset)")]
    if 'last_checked' in cols:
        fc = 'COALESCE(fail_count,0)' if 'fail_count' in cols else '0'
        conn.execute(
            "INSERT OR IGNORE INTO %s(media_id, checked_at, fail_count)"
            " SELECT media_id, last_checked, %s FROM sys_media_asset"
            "  WHERE last_checked IS NOT NULL" % (TBL, fc))
    conn.commit()
    return True


def not_dormant(alias='a'):
    """미검토를 세는 조회에 **함께 거는** 조건 — 휴면은 미검토가 아니다.

    ⚠ 이 표가 없는 DB 에서는 터진다 — 부르는 쪽이 `ensure(conn)` 을 먼저 한다.
    """
    return ("NOT EXISTS(SELECT 1 FROM %s k WHERE k.media_id=%s.media_id"
            " AND k.dormant_since IS NOT NULL)" % (TBL, alias))


# ── 유튜브 ──────────────────────────────────────────────────────────────────

def yt_id(url):
    m = re.search(r'(?:v=|youtu\.be/|/embed/|/shorts/)([\w-]{6,})', url or '')
    return m.group(1) if m else None


def dur_sec(iso):
    """ISO8601 PT#H#M#S → 초. 못 읽으면 None."""
    m = re.match(r'PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?', iso or '')
    if not m:
        return None
    h, mn, s = (int(x) if x else 0 for x in m.groups())
    return h * 3600 + mn * 60 + s


#: ★★★ **쇼츠 문턱 — 2분**(2026-09-11 사용자 「**2분 이내는 숏츠로
#:   취급하자**」). 그전에는 60초였다.
#:   ⚠ 유튜브의 공식 쇼츠 길이는 늘어 왔고(15초 → 60초 → 3분), 제목에
#:     「쇼츠」라 적어 놓고 1~2분인 것이 실측으로 많다. **화면에 쓸 수 있는가**가
#:     잣대이지 유튜브의 규격이 잣대가 아니다.
SHORT_SEC = 120


def judge(item, embeddable_default=True):
    """`videos.list` 항목 하나 → (status, detail). 항목이 없으면 DEAD."""
    if item is None:
        return 'DEAD', '응답 없음'
    emb = (item.get('status') or {}).get('embeddable', embeddable_default)
    dur = dur_sec((item.get('contentDetails') or {}).get('duration', ''))
    if not emb:
        return 'EMBED_BLOCKED', '임베드 불가'
    if dur is not None and dur <= SHORT_SEC:
        return 'SHORT', '%d초' % dur
    return 'OK', ('%d초' % dur if dur else '')


def api_keys(conn):
    try:
        r = __import__('secret_store').row('YOUTUBE_API_KEYS')  # 열쇠는 배포 DB 밖(2026-10-11)
        return [k.strip() for k in (r[0] if r and r[0] else '').split(',')
                if k.strip()]
    except Exception:
        return []


def probe_api(rows, keys, on_result, on_error=None, on_stats=None,
              on_caption=None, on_duration=None, on_channel=None):
    """`videos.list` 로 50개씩 묻는다 → 점검한 수.

    ⚠ **Tk 를 모른다** — 데몬 실에서 불러도 된다(§208차 ⑤). 결과는
      `on_result(mid, status, detail)` 로 낸다.
    ⚠ 키가 막히면 다음 키로 넘어간다(`collect_channels` 와 같은 규칙).
    """
    try:
        from googleapiclient.discovery import build as yt_build
    except Exception:
        if on_error:
            on_error('google-api 라이브러리가 없습니다')
        return 0
    if not keys:
        if on_error:
            on_error('API 키가 없습니다')
        return 0
    vid_map = {}
    done = 0
    for mid, url in rows:
        v = yt_id(url)
        if v:
            vid_map.setdefault(v, []).append(mid)
        else:
            on_result(mid, 'UNKNOWN', 'video_id 없음')
            done += 1
    vids = list(vid_map)
    ki = 0
    i = 0
    while i < len(vids):
        batch = vids[i:i + 50]
        try:
            yt = yt_build('youtube', 'v3', developerKey=keys[ki % len(keys)],
                          cache_discovery=False)
            # ★ `statistics` 를 함께 받는다 — `videos.list` 는 **50개당 1 unit**
            #   이라 칸을 더해도 **비용이 0**이다(2026-09-09).
            # ★★★ **`snippet` 을 함께 받는다**(2026-09-12) — 거기에
            #   `channelId` 가 있고, **50개당 1 unit 이라 비용이 0**이다.
            #   ✅ 실측 옛 수집분은 검색 경로가 id 를 안 담아 **채널 id 가 없는
            #     채널이 154곳**이었고, 그 때문에 **RSS 등록을 못 했다**
            #     (§228차 ② 그 자리). 1,170편이면 **24 units** 로 다 푼다.
            resp = yt.videos().list(
                part='status,contentDetails,statistics,snippet',
                id=','.join(batch)).execute()
        except Exception as e:
            ki += 1
            if ki >= len(keys):
                if on_error:
                    on_error('API 오류: %s' % str(e)[:120])
                break
            continue
        found = {it['id']: it for it in resp.get('items', [])}
        for v in batch:
            it = found.get(v)
            st, det = judge(it)
            vc = ((it or {}).get('statistics', {}) or {}).get('viewCount')
            # ★★★ **자막 유무는 이미 받고 있었다**(2026-09-10) —
            #   `contentDetails.caption` 이 그 응답 안에 있는데 버리고 있었다.
            #   그래서 「자막이 있나」를 재는 데 **쿼터가 0**이다.
            cap = ((it or {}).get('contentDetails', {}) or {}).get('caption')
            # ★★★ **길이도 같은 응답에 있다**(2026-09-11) — 담기만 하면 되고
            #   추가 비용이 0이다.
            _du = dur_sec(((it or {}).get('contentDetails', {}) or {}
                           ).get('duration', ''))
            _sn = (it or {}).get('snippet', {}) or {}
            _cid = _sn.get('channelId')
            _cnm = _sn.get('channelTitle')
            for mid in vid_map[v]:
                on_result(mid, st, det)
                if on_stats and vc not in (None, ''):
                    on_stats(mid, vc)
                if on_caption and cap not in (None, ''):
                    on_caption(mid, str(cap).lower() == 'true')
                if on_duration and _du is not None:
                    on_duration(mid, _du)
                if on_channel and _cid:
                    on_channel(mid, _cid, _cnm or '')
                done += 1
        i += 50
    return done


def probe_oembed(rows, on_result, on_progress=None):
    """oEmbed(무쿼터) — 존재·임베드만 안다(길이 불가). **화면에서만** 쓴다.

    ⚠ 매일 작업은 이것을 안 쓴다 — 몰아치면 IP 가 막힌다.
    """
    import urllib.request
    import urllib.error
    done = 0
    for mid, url in rows:
        v = yt_id(url)
        if not v:
            on_result(mid, 'UNKNOWN', 'video_id 없음')
        else:
            try:
                req = urllib.request.Request(
                    'https://www.youtube.com/oembed?url='
                    'https://www.youtube.com/watch?v=%s&format=json' % v,
                    headers={'User-Agent': 'Mozilla/5.0'})
                urllib.request.urlopen(req, timeout=8)
                on_result(mid, 'OK', 'oEmbed 200')
            except urllib.error.HTTPError as he:
                if he.code in (401, 403):
                    on_result(mid, 'EMBED_BLOCKED', 'HTTP %d' % he.code)
                elif he.code == 404:
                    on_result(mid, 'DEAD', 'HTTP 404')
                else:
                    on_result(mid, 'UNKNOWN', 'HTTP %d' % he.code)
            except Exception as e:
                on_result(mid, 'UNKNOWN', str(e)[:20])
        done += 1
        if on_progress:
            on_progress(done)
    return done


# ── 전이 ────────────────────────────────────────────────────────────────────

def _row(conn, mid):
    return conn.execute(
        "SELECT status, fail_count, dormant_since, was_active, removed_at"
        " FROM %s WHERE media_id=?" % TBL, (mid,)).fetchone()


#: 임베드 가능 여부를 **배포되는 표**에 적는 칸.
#: ⚠⚠ `sys_media_check` 는 LOCAL(배포 안 함)이라 사용자 앱이 못 읽는다 —
#:   그 사실을 알아야 **막힌 영상만 다른 방식으로 열** 수 있으므로
#:   코어팩에 실리는 `sys_media_asset` 으로 옮긴다.
#: 값 = `NULL` 모름 · `1` 된다 · `0` 막혔다.
EMBED_COL = 'embed_ok'


def init_embed_col(conn):
    """`sys_media_asset.embed_ok` 칸(멱등)."""
    cols = [r[1] for r in conn.execute("PRAGMA table_info(sys_media_asset)")]
    if EMBED_COL not in cols:
        conn.execute("ALTER TABLE sys_media_asset ADD COLUMN %s INTEGER"
                     % EMBED_COL)
        conn.commit()
    return True


def set_embed_ok(conn, mid, ok):
    """그 영상의 임베드 가능 여부를 적는다(`None` 이면 안 건드린다)."""
    if ok is None:
        return False
    init_embed_col(conn)
    conn.execute("UPDATE sys_media_asset SET %s=? WHERE media_id=?"
                 % EMBED_COL, (1 if ok else 0, mid))
    return True


def revive_embed(conn, today=None):
    """**임베드 차단으로 내려간 것을 되살린다** → `{'revived': n, 'marked': n}`.

    ⚠ 옛 규칙(죽음)으로 휴면·제거된 것이 남아 있다 — 규칙만 고치면 그것들은
      영영 안 돌아온다(§0-1 조용한 손실). 되살리면서 **표식은 남긴다**.
    ⚠ `was_active` 가 곧 되돌릴 값이다(그 칸이 있어서 되살릴 수 있다).
    """
    init_embed_col(conn)
    rows = conn.execute(
        "SELECT media_id, was_active, removed_at FROM %s"
        " WHERE status='EMBED_BLOCKED'"
        "   AND (COALESCE(dormant_since,'')<>'' OR COALESCE(removed_at,'')<>'')"
        % TBL).fetchall()
    n = 0
    for mid, was, removed in rows:
        conn.execute("UPDATE sys_media_asset SET is_active=?"
                     "%s WHERE media_id=?"
                     % (", record_status='LIVE'" if removed else ''),
                     (int(was or 0), mid))
        conn.execute("UPDATE %s SET dormant_since=NULL, was_active=NULL,"
                     " removed_at=NULL, fail_count=0 WHERE media_id=?"
                     % TBL, (mid,))
        n += 1
    m = conn.execute("UPDATE sys_media_asset SET %s=0 WHERE media_id IN"
                     " (SELECT media_id FROM %s WHERE status='EMBED_BLOCKED')"
                     % (EMBED_COL, TBL)).rowcount or 0
    conn.commit()
    return {'revived': n, 'marked': m}


def record(conn, mid, status, detail='', today=None):
    """결과 하나를 적고 상태를 옮긴다 → 일어난 일
    (None | 'DORMANT' | 'REVIVED' | 'REMOVED').

    ★ 이 한 문이 전이의 단일 소스다 — 화면도 매일 작업도 이것을 부른다.
    """
    today = today or date.today().isoformat()
    ensure(conn)
    cur = _row(conn, mid)
    fail = (cur[1] if cur else 0) or 0
    dormant = cur[2] if cur else None
    was = cur[3] if cur else None
    removed = cur[4] if cur else None
    asset = conn.execute("SELECT is_active, record_status FROM sys_media_asset"
                         " WHERE media_id=?", (mid,)).fetchone()
    if asset is None:
        return None
    is_active = int(asset[0] or 0)
    event = None
    dead = status in DEAD
    # ★ 임베드 가능 여부는 **배포되는 칸**에 함께 적는다 — 사용자 앱이
    #   그 영상만 다른 방식으로 연다(`video_open.mode_for`).
    if status in ('OK', 'SHORT'):
        set_embed_ok(conn, mid, True)
    elif status == 'EMBED_BLOCKED':
        set_embed_ok(conn, mid, False)
    if status == 'OK':
        fail = 0
        if dormant and not removed:
            # 살아났다 — 휴면 전 상태로
            conn.execute("UPDATE sys_media_asset SET is_active=? WHERE media_id=?",
                         (int(was or 0), mid))
            dormant, was = None, None
            event = 'REVIVED'
    elif dead:
        fail += 1
        if not dormant:
            was = is_active
            dormant = today
            conn.execute("UPDATE sys_media_asset SET is_active=0"
                         " WHERE media_id=?", (mid,))
            event = 'DORMANT'
        elif not removed and dormant <= _minus_days(today, DORMANT_DAYS):
            # 휴면 기한이 지났는데도 죽어 있다 → 제거
            conn.execute("UPDATE sys_media_asset SET record_status='HIDE'"
                         " WHERE media_id=?", (mid,))
            removed = today
            event = 'REMOVED'
    # SHORT · UNKNOWN — 상태만 적는다
    conn.execute(
        "INSERT INTO %s(media_id, status, detail, checked_at, fail_count,"
        " dormant_since, was_active, removed_at, note)"
        " VALUES(?,?,?,?,?,?,?,?,?)"
        " ON CONFLICT(media_id) DO UPDATE SET status=excluded.status,"
        " detail=excluded.detail, checked_at=excluded.checked_at,"
        " fail_count=excluded.fail_count, dormant_since=excluded.dormant_since,"
        " was_active=excluded.was_active, removed_at=excluded.removed_at,"
        " note=excluded.note" % TBL,
        (mid, status, detail, today, fail, dormant, was, removed,
         (NOTE_REMOVED + '_' + today) if event == 'REMOVED'
         else (cur and conn.execute("SELECT note FROM %s WHERE media_id=?"
                                    % TBL, (mid,)).fetchone()[0])))
    return event


def _minus_days(iso, n):
    y, m, d = (int(x) for x in iso.split('-'))
    return (date(y, m, d) - timedelta(days=n)).isoformat()


def revive(conn, mids):
    """휴면에서 되살린다(휴면 전 상태로). → 건수. 제거된 것은 먼저 되돌려야 한다."""
    n = 0
    for mid in mids:
        cur = _row(conn, mid)
        if not cur or not cur[2] or cur[4]:
            continue
        conn.execute("UPDATE sys_media_asset SET is_active=? WHERE media_id=?"
                     " AND record_status='LIVE'", (int(cur[3] or 0), mid))
        conn.execute("UPDATE %s SET dormant_since=NULL, was_active=NULL,"
                     " fail_count=0 WHERE media_id=?" % TBL, (mid,))
        n += 1
    conn.commit()
    return n


def remove(conn, mids, today=None):
    """사람이 제거한다(HIDE · 되돌릴 수 있다). → 건수."""
    today = today or date.today().isoformat()
    ensure(conn)
    n = 0
    for mid in mids:
        a = conn.execute("SELECT is_active FROM sys_media_asset"
                         " WHERE media_id=? AND record_status='LIVE'",
                         (mid,)).fetchone()
        if a is None:
            continue
        cur = _row(conn, mid)
        conn.execute(
            "INSERT INTO %s(media_id, dormant_since, was_active, removed_at, note)"
            " VALUES(?,?,?,?,?)"
            " ON CONFLICT(media_id) DO UPDATE SET"
            " dormant_since=COALESCE(%s.dormant_since, excluded.dormant_since),"
            " was_active=COALESCE(%s.was_active, excluded.was_active),"
            " removed_at=excluded.removed_at, note=excluded.note"
            % (TBL, TBL, TBL),
            (mid, today, int(a[0] or 0), today, NOTE_REMOVED + '_' + today))
        conn.execute("UPDATE sys_media_asset SET is_active=0,"
                     " record_status='HIDE' WHERE media_id=?", (mid,))
        n += 1
    conn.commit()
    return n


def undo_removed(conn, mids=None, since=None):
    """제거를 되돌린다 → **휴면으로**(그 자리에서 다시 점검·되살리기). → 건수.

    `mids` 를 주면 그것만, `since` 를 주면 그 날 이후 제거분 전부.
    """
    ensure(conn)
    q = ("SELECT media_id FROM %s WHERE removed_at IS NOT NULL"
         " AND COALESCE(note,'') LIKE ?" % TBL)
    p = [NOTE_REMOVED + '%']
    if mids:
        q += " AND media_id IN (%s)" % ','.join('?' * len(mids))
        p += list(mids)
    if since:
        q += " AND removed_at >= ?"
        p.append(since)
    ids = [r[0] for r in conn.execute(q, p)]
    for mid in ids:
        conn.execute("UPDATE sys_media_asset SET record_status='LIVE',"
                     " is_active=0 WHERE media_id=?", (mid,))
        conn.execute("UPDATE %s SET removed_at=NULL, note=NULL,"
                     " dormant_since=COALESCE(dormant_since, checked_at, date('now'))"
                     " WHERE media_id=?" % TBL, (mid,))
    conn.commit()
    return len(ids)


# ── 대상·현황 ─────────────────────────────────────────────────────────────────

_TARGET_LABEL = (
    "COALESCE((SELECT contents FROM sys_text_asset t"
    "  JOIN sys_link_asset le ON le.target_id=t.clicked_id"
    "   AND le.link_type='MEDI_ENTI' AND le.clicked_id=a.media_id"
    "   AND COALESCE(le.record_status,'LIVE')='LIVE'"
    " WHERE t.text_type='ENTITY_NAME' AND t.lang_code='KO' LIMIT 1),"
    " (SELECT bn.short_name || bi.chapter || ':' || bi.verse"
    "    FROM sys_link_asset lv JOIN bible_index bi ON bi.verse_id=lv.target_id"
    "    JOIN book_names bn ON bn.book_code=bi.bcode AND bn.lang_code='KO'"
    "   WHERE lv.link_type='MEDI_VERS' AND lv.clicked_id=a.media_id"
    "     AND COALESCE(lv.record_status,'LIVE')='LIVE' LIMIT 1),"
    " '(연결 없음)')")


def targets(conn, rng, limit, today=None, with_label=True):
    """점검 대상 → [(media_id, title, url, 대상, is_active, dormant_since)].

    ★ **오래 안 본 것부터** — 어느 범위든 `checked_at` 이 빈 것·오래된 것이
      앞에 선다. 여러 번 나눠 돌리면 전체가 돈다.
    """
    today = today or date.today().isoformat()
    ensure(conn)
    stale = _minus_days(today, STALE_DAYS)
    due = _minus_days(today, DORMANT_DAYS)
    lbl = _TARGET_LABEL if with_label else "''"
    base = ("SELECT a.media_id, a.title, a.url, %s, a.is_active, k.dormant_since"
            "  FROM sys_media_asset a LEFT JOIN %s k ON k.media_id=a.media_id"
            " WHERE a.record_status='LIVE' AND a.url LIKE '%%youtu%%'"
            % (lbl, TBL))
    if rng == 'UNCHECKED':
        w = " AND k.checked_at IS NULL AND k.dormant_since IS NULL"
    elif rng == 'STALE':
        w = (" AND (k.checked_at IS NULL OR k.checked_at < '%s')"
             " AND k.dormant_since IS NULL" % stale)
    elif rng == 'ACTIVE':
        w = " AND a.is_active=1"
    elif rng == 'ALL_LIVE':
        w = " AND k.dormant_since IS NULL"
    elif rng == 'DORMANT_DUE':
        w = (" AND k.dormant_since IS NOT NULL AND k.dormant_since <= '%s'"
             " AND COALESCE(k.checked_at,'') < '%s'" % (due, today))
    elif rng == 'DORMANT_ALL':
        w = " AND k.dormant_since IS NOT NULL"
    else:
        raise ValueError('모르는 범위: %r' % rng)
    q = base + w + " ORDER BY k.checked_at ASC, a.media_id LIMIT ?"
    return conn.execute(q, (int(limit),)).fetchall()


def listing(conn, kind, limit=2000):
    """화면 갈래 목록 → [(media_id, status, 대상, title, detail, 날짜, was_active)].
    kind = 'DORMANT' | 'SHORT' | 'REMOVED' | 'DEAD'
    """
    ensure(conn)
    if kind == 'DORMANT':
        w = ("a.record_status='LIVE' AND k.dormant_since IS NOT NULL"
             " AND k.removed_at IS NULL")
        d = 'k.dormant_since'
    elif kind == 'SHORT':
        w = "a.record_status='LIVE' AND k.status='SHORT' AND k.dormant_since IS NULL"
        d = 'k.checked_at'
    elif kind == 'REMOVED':
        w = "k.removed_at IS NOT NULL AND a.record_status='HIDE'"
        d = 'k.removed_at'
    elif kind == 'DEAD':
        w = ("a.record_status='LIVE' AND k.status IN (%s)"
             % ','.join("'%s'" % x for x in DEAD))
        d = 'k.checked_at'
    else:
        raise ValueError(kind)
    return conn.execute(
        "SELECT a.media_id, k.status, %s, a.title, COALESCE(k.detail,''), %s,"
        " k.was_active FROM %s k JOIN sys_media_asset a ON a.media_id=k.media_id"
        " WHERE %s ORDER BY %s DESC, a.media_id LIMIT ?"
        % (_TARGET_LABEL, d, TBL, w, d), (int(limit),)).fetchall()


def health(conn, today=None):
    """현황 한 줄의 재료. 화면·매일 작업이 같은 문을 쓴다."""
    today = today or date.today().isoformat()
    ensure(conn)
    stale = _minus_days(today, STALE_DAYS)
    due = _minus_days(today, DORMANT_DAYS)
    one = lambda q, p=(): conn.execute(q, p).fetchone()[0]
    live = one("SELECT COUNT(*) FROM sys_media_asset WHERE record_status='LIVE'"
               " AND url LIKE '%youtu%'")
    h = {
        'live': live,
        'checked': one("SELECT COUNT(*) FROM sys_media_asset a JOIN %s k"
                       " ON k.media_id=a.media_id WHERE a.record_status='LIVE'"
                       " AND k.checked_at IS NOT NULL" % TBL),
        'stale': one("SELECT COUNT(*) FROM sys_media_asset a LEFT JOIN %s k"
                     " ON k.media_id=a.media_id WHERE a.record_status='LIVE'"
                     " AND a.url LIKE '%%youtu%%' AND k.dormant_since IS NULL"
                     " AND (k.checked_at IS NULL OR k.checked_at<?)" % TBL,
                     (stale,)),
        'dormant': one("SELECT COUNT(*) FROM %s k JOIN sys_media_asset a"
                       " ON a.media_id=k.media_id WHERE k.dormant_since IS NOT NULL"
                       " AND k.removed_at IS NULL AND a.record_status='LIVE'" % TBL),
        'dormant_due': one("SELECT COUNT(*) FROM %s k JOIN sys_media_asset a"
                           " ON a.media_id=k.media_id WHERE k.dormant_since IS NOT NULL"
                           " AND k.removed_at IS NULL AND a.record_status='LIVE'"
                           " AND k.dormant_since<=?" % TBL, (due,)),
        'short': one("SELECT COUNT(*) FROM %s k JOIN sys_media_asset a"
                     " ON a.media_id=k.media_id WHERE k.status='SHORT'"
                     " AND a.record_status='LIVE' AND k.dormant_since IS NULL" % TBL),
        'removed': one("SELECT COUNT(*) FROM %s WHERE removed_at IS NOT NULL" % TBL),
    }
    try:
        r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                         (LOG_KEY,)).fetchone()
        h['last'] = json.loads(r[0]) if r and r[0] else None
    except Exception:
        h['last'] = None
    return h


def health_line(h):
    pct = (h['checked'] * 100.0 / h['live']) if h['live'] else 0.0
    f = lambda k: '{:,}'.format(h[k])
    s = ('영상 %s · 점검됨 %s(%.0f%%) · 미점검·오래됨 %s · 휴면 %s(기한 지남 %s)'
         ' · 쇼츠 %s · 제거됨 %s'
         % (f('live'), f('checked'), pct, f('stale'), f('dormant'),
            f('dormant_due'), f('short'), f('removed')))
    last = h.get('last') or {}
    if last:
        s += ' · 마지막 자동 점검 %s (%s건)' % (last.get('when', '?'),
                                            last.get('n', '?'))
    else:
        s += ' · 자동 점검 기록 없음'
    return s


# ── 매일 실행 ─────────────────────────────────────────────────────────────────

def run(conn, limit=DAILY_MAX, dry=False, log=print, today=None, keys=None):
    """매일 작업 걸음 ④ → (점검 수, 요약 dict). 키가 없으면 0 을 내고 말한다.

    차례 = ① 휴면 재점검(기한 지난 것) → ② 미점검·오래된 것.
    ⚠ 여기서 터져도 부르는 쪽(수집)을 실패로 만들지 않는다 — 호출부가 감싼다.
    """
    today = today or date.today().isoformat()
    init(conn)
    keys = keys if keys is not None else api_keys(conn)
    if not keys:
        log('  [링크 점검] API 키가 없어 건너뜁니다 — [API 키 관리]에서 넣으세요.')
        return 0, {'skipped': 'NO_KEY'}
    due = targets(conn, 'DORMANT_DUE', limit, today, with_label=False)
    rest = targets(conn, 'STALE', max(0, limit - len(due)), today, with_label=False)
    rows = [(r[0], r[2]) for r in due] + [(r[0], r[2]) for r in rest]
    log('  [링크 점검] 대상 %d건 (휴면 재점검 %d · 미점검·오래됨 %d)'
        % (len(rows), len(due), len(rest)))
    if dry or not rows:
        return 0, {'due': len(due), 'rest': len(rest), 'dry': dry}
    summary = {'n': 0, 'OK': 0, 'DEAD': 0, 'EMBED_BLOCKED': 0, 'SHORT': 0,
               'UNKNOWN': 0, 'DORMANT': 0, 'REVIVED': 0, 'REMOVED': 0,
               'due': len(due), 'rest': len(rest), 'err': []}

    def on_result(mid, st, det):
        ev = record(conn, mid, st, det, today)
        summary['n'] += 1
        summary[st] = summary.get(st, 0) + 1
        if ev:
            summary[ev] += 1
        if summary['n'] % 500 == 0:
            conn.commit()

    def on_stats(mid, views):
        if set_views(conn, mid, views, today):
            summary['views'] = summary.get('views', 0) + 1

    probe_api(rows, keys, on_result, on_stats=on_stats,
              on_error=lambda m: summary['err'].append(m))
    conn.commit()
    summary['when'] = time.strftime('%Y-%m-%d %H:%M')
    conn.execute("INSERT OR REPLACE INTO sys_config(config_key, config_val)"
                 " VALUES(?,?)", (LOG_KEY, json.dumps(summary, ensure_ascii=False)))
    conn.commit()
    log('  [링크 점검] %d건 — 정상 %d · 삭제/비공개 %d · 임베드차단 %d · 쇼츠 %d'
        ' · 확인불가 %d' % (summary['n'], summary['OK'], summary['DEAD'],
                          summary['EMBED_BLOCKED'], summary['SHORT'],
                          summary['UNKNOWN']))
    log('  [링크 점검] 휴면으로 %d · 되살아남 %d · **제거 %d**'
        % (summary['DORMANT'], summary['REVIVED'], summary['REMOVED']))
    if summary.get('views'):
        log('  [링크 점검] 조회수 %d건 적음(같은 응답 — 비용 0)' % summary['views'])
    for m in summary['err'][:3]:
        log('    ⚠ %s' % m)
    return summary['n'], summary


# ── selftest ─────────────────────────────────────────────────────────────────

def _mem():
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY, title TEXT,
        url TEXT, is_active INT, record_status TEXT, last_checked TEXT,
        fail_count INT);
      CREATE TABLE sys_config(config_key TEXT PRIMARY KEY, config_val TEXT);
      CREATE TABLE sys_text_asset(clicked_id INT, text_type TEXT, lang_code TEXT,
        contents TEXT);
      CREATE TABLE sys_link_asset(link_type TEXT, clicked_id INT, target_id INT,
        record_status TEXT);
      CREATE TABLE bible_index(verse_id INT, bcode INT, chapter INT, verse INT);
      CREATE TABLE book_names(book_code INT, lang_code TEXT, short_name TEXT);
    """)
    for i, (act, lc) in enumerate([(1, None), (0, None), (1, '2026-01-01'),
                                  (0, None), (1, None)], start=1):
        c.execute("INSERT INTO sys_media_asset VALUES(?,?,?,?,?,?,?)",
                  (i, 'v%d' % i, 'https://www.youtube.com/watch?v=id%d' % i,
                   act, 'LIVE', lc, 0))
    return c


def selftest():
    ok = [0, 0]

    def t(nm, cond, extra=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, extra))

    c = _mem()
    init(c)
    init(c)
    # ★★ 채널 주소 점검(2026-09-16) — 응답을 주입해 쿼터 0
    c.executescript("""CREATE TABLE sys_media_channel(channel_id INTEGER PRIMARY KEY, channel_ext_id TEXT,
        channel_name TEXT, record_status TEXT DEFAULT 'LIVE', enabled INT DEFAULT 1);
        INSERT INTO sys_media_channel(channel_ext_id, channel_name) VALUES('UCA','살아있음'),('UCB','사라짐');""")
    _fake = lambda batch: [{'id': 'UCA', 'snippet': {'title': '살아있음'},
                            'statistics': {'subscriberCount': '120', 'videoCount': '3'}}]
    r = check_channels(c, log=lambda *_a: None, today='2026-09-16', fetch_fn=_fake)
    t('★ 채널 주소 — 있음 1 · 없음 1 · 없는 것에 CHAN_DEAD 표식 · 있는 것 규모 적음',
      (r['asked'], r['found'], r['missing'], r['units']) == (2, 1, ['사라짐'], 1)
      and c.execute("SELECT note FROM sys_media_channel WHERE channel_ext_id='UCB'").fetchone()[0] == 'CHAN_DEAD:2026-09-16'
      and c.execute("SELECT subs FROM %s WHERE channel_ext_id='UCA'" % CH_TBL).fetchone()[0] == 120, r)
    t('  수집은 안 끈다(사람이 정한다)', c.execute("SELECT enabled FROM sys_media_channel WHERE channel_ext_id='UCB'").fetchone()[0] == 1)
    r2 = check_channels(c, log=lambda *_a: None, today='2026-09-17', fetch_fn=_fake)
    t('  두 번 돌려도 표식이 안 겹친다', c.execute("SELECT note FROM sys_media_channel WHERE channel_ext_id='UCB'").fetchone()[0] == 'CHAN_DEAD:2026-09-16')
    r3 = check_channels(c, log=lambda *_a: None, today='2026-09-18',
                        fetch_fn=lambda b: [{'id': 'UCA', 'statistics': {}}, {'id': 'UCB', 'statistics': {}}])
    t('  되살아나면 표식을 걷는다', r3['revived'] == 1 and c.execute(
        "SELECT note FROM sys_media_channel WHERE channel_ext_id='UCB'").fetchone()[0] is None)
    def _boom(b):
        raise RuntimeError('quota')
    r4 = check_channels(c, log=lambda *_a: None, fetch_fn=_boom)
    t('  API 가 막히면 아무것도 판정하지 않는다(없음 0 · 오류 기록)', r4['missing'] == [] and r4['err'])
    t('★ 옛 칸을 장부로 옮겨 온다(멱등)',
      c.execute("SELECT COUNT(*) FROM %s" % TBL).fetchone()[0] == 1)
    # 판정
    # ★ 조회수 — 장부가 집이다(2026-09-09)
    t('★ 장부에 조회수 칸이 있다',
      {'views', 'views_at'} <= {r[1] for r in c.execute("PRAGMA table_info(%s)" % TBL)})
    t('★ 조회수를 적는다', set_views(c, 1, '1234', '2026-09-09')
      and views_of(c).get(1) == (1234, '2026-09-09'))
    t('  다시 적으면 덮는다(멱등)',
      set_views(c, 1, 2000, '2026-09-10') and views_of(c)[1] == (2000, '2026-09-10'))
    t('★ 비공개(값 없음)는 0 으로 안 짓는다',
      not set_views(c, 2, None) and 2 not in views_of(c))
    t('  숫자가 아니면 안 적는다', not set_views(c, 2, 'private') and 2 not in views_of(c))
    t('  없던 행도 만든다(점검 전 수집분)',
      c.execute("SELECT COUNT(*) FROM %s WHERE media_id=1" % TBL).fetchone()[0] == 1)
    t('★ 조회수가 점검 상태를 안 지운다',
      (record(c, 1, 'OK', '', '2026-09-11') is not None or True)
      and views_of(c)[1][0] == 2000)
    # ⚠ 함수 안에서 `dir()` 은 지역 이름만 낸다 — `__file__` 을 그렇게 찾으면
    #   늘 빈손이라 검사가 조용히 헛돈다(실측으로 잡았다). 파일 이름으로 읽는다.
    _src = io.open('db_media_linkcheck.py', encoding='utf-8').read()
    t('★ 같은 응답에서 받는다 — API 비용 0',
      "part='status,contentDetails,statistics'" in _src)
    _mi = io.open('media_intake.py', encoding='utf-8').read()
    t('★ 수집은 장부 문으로 적는다(설명문에 안 담는다)',
      'set_views' in _mi and "d['views']" not in _mi)
    t('판정 — 없으면 DEAD', judge(None)[0] == 'DEAD')
    t('판정 — 임베드 불가', judge({'status': {'embeddable': False},
                                   'contentDetails': {'duration': 'PT10M'}})[0]
      == 'EMBED_BLOCKED')
    t('★★★ 판정 — **2분 이하는 쇼츠**(2026-09-11 사용자)',
      judge({'status': {}, 'contentDetails':
             {'duration': 'PT45S'}})[0] == 'SHORT'
      and judge({'status': {}, 'contentDetails':
                 {'duration': 'PT1M55S'}})[0] == 'SHORT'
      and judge({'status': {}, 'contentDetails':
                 {'duration': 'PT2M30S'}})[0] == 'OK'
      and SHORT_SEC == 120)
    t('★★ **제목이 스스로 쇼츠라고 적은 것**을 알아본다',
      all(SHORT_MARK.search(x) for x in
          ('#shorts 하나님(GOD)_이승희', '… | 쇼츠버전',
           '주님 🙏 … #ccm #찬양쇼츠', 'Shorts')))
    t('★★ **낱말 가운데는 안 먹는다**',
      not SHORT_MARK.search('Shortsighted')
      and not SHORT_MARK.search('short-cut')
      and not SHORT_MARK.search('Short film'))
    t('판정 — 정상', judge({'status': {}, 'contentDetails':
                            {'duration': 'PT1H2M'}}) == ('OK', '3720초'))
    t('yt_id', yt_id('https://youtu.be/abc123XYZ') == 'abc123XYZ')

    # 전이 — 승인 영상이 죽는다 → 휴면
    ev = record(c, 1, 'DEAD', '응답 없음', '2026-09-01')
    r = _row(c, 1)
    a = c.execute("SELECT is_active FROM sys_media_asset WHERE media_id=1").fetchone()[0]
    t('★ 죽음 → 휴면(is_active 0 · was_active 1 · 날짜)',
      ev == 'DORMANT' and a == 0 and r[2] == '2026-09-01' and r[3] == 1, (ev, r))
    # 휴면은 미검토가 아니다
    n = c.execute("SELECT COUNT(*) FROM sys_media_asset a WHERE a.is_active=0"
                  " AND a.record_status='LIVE' AND " + not_dormant('a')).fetchone()[0]
    t('★★ not_dormant — 휴면이 미검토 셈에서 빠진다', n == 2, n)
    # 기한 전 재점검 실패 → 그대로 휴면
    ev = record(c, 1, 'DEAD', '', '2026-09-15')
    t('기한 전 실패는 제거하지 않는다',
      ev is None and _row(c, 1)[4] is None and _row(c, 1)[1] == 2)
    # 살아나면 승인으로 복귀
    ev = record(c, 1, 'OK', '', '2026-09-16')
    a = c.execute("SELECT is_active FROM sys_media_asset WHERE media_id=1").fetchone()[0]
    t('★ 살아나면 휴면 전 상태(승인)로', ev == 'REVIVED' and a == 1
      and _row(c, 1)[2] is None and _row(c, 1)[1] == 0)
    # 기한 뒤 실패 → 제거
    record(c, 2, 'DEAD', '', '2026-08-01')
    ev = record(c, 2, 'DEAD', '', '2026-09-01')
    rs = c.execute("SELECT record_status, is_active FROM sys_media_asset"
                   " WHERE media_id=2").fetchone()
    t('★★ %d일 뒤에도 죽어 있으면 제거(HIDE)' % DORMANT_DAYS,
      ev == 'REMOVED' and rs == ('HIDE', 0) and _row(c, 2)[4] == '2026-09-01')
    t('  제거 표식이 남는다',
      (c.execute("SELECT note FROM %s WHERE media_id=2" % TBL).fetchone()[0]
       or '').startswith(NOTE_REMOVED))
    t('  제거된 것은 「제거됨」 갈래에 뜬다',
      [x[0] for x in listing(c, 'REMOVED')] == [2])
    # 되돌리기 → 휴면으로(LIVE)
    n = undo_removed(c, mids=[2])
    rs = c.execute("SELECT record_status, is_active FROM sys_media_asset"
                   " WHERE media_id=2").fetchone()
    t('★ 되돌리면 휴면으로 돌아온다(LIVE · 미승인 유지)',
      n == 1 and rs == ('LIVE', 0) and _row(c, 2)[2] is not None
      and _row(c, 2)[4] is None)
    t('  되돌린 것이 휴면 갈래에 뜬다',
      [x[0] for x in listing(c, 'DORMANT')] == [2])
    # 되살리기(사람) — 휴면 전 미검토였으므로 미검토로
    t('되살리기 → 휴면 전 상태(미검토)', revive(c, [2]) == 1
      and _row(c, 2)[2] is None and c.execute(
          "SELECT is_active FROM sys_media_asset WHERE media_id=2").fetchone()[0] == 0)
    # 쇼츠는 안 옮긴다
    set_duration(c, 5, 95)
    t('★★★ **길이를 칸에 담는다**(글자 칸을 다시 파싱하지 않는다)',
      duration_of(c).get(5) == 95)
    t('★★ 값이 없으면 안 쓴다', not set_duration(c, 6, None))
    ev = record(c, 5, 'SHORT', '30초', '2026-09-01')
    a = c.execute("SELECT is_active FROM sys_media_asset WHERE media_id=5").fetchone()[0]
    t('★ 쇼츠는 상태만 적고 안 옮긴다', ev is None and a == 1
      and _row(c, 5)[2] is None and [x[0] for x in listing(c, 'SHORT')] == [5])
    # 확인 불가는 아무것도 안 바꾼다
    record(c, 4, 'UNKNOWN', 'HTTP 500', '2026-09-01')
    t('확인 불가는 상태를 안 바꾼다', _row(c, 4)[1] == 0 and _row(c, 4)[2] is None)
    # 사람이 제거 · 되돌리기
    t('사람이 제거하면 HIDE + 표식', remove(c, [5]) == 1 and c.execute(
        "SELECT record_status FROM sys_media_asset WHERE media_id=5").fetchone()[0]
      == 'HIDE' and _row(c, 5)[3] == 1)
    t('  되돌리면 휴면(LIVE) · 되살리면 승인으로',
      undo_removed(c, mids=[5]) == 1 and revive(c, [5]) == 1 and c.execute(
          "SELECT is_active, record_status FROM sys_media_asset WHERE media_id=5"
      ).fetchone() == (1, 'LIVE'))
    # 대상 고르기
    tg = targets(c, 'UNCHECKED', 10, '2026-09-20', with_label=False)
    t('미점검 = 장부에 없는 것만', [x[0] for x in tg] == [4] or
      set(x[0] for x in tg) <= {3, 4}, [x[0] for x in tg])
    record(c, 3, 'DEAD', '', '2026-07-01')
    due = targets(c, 'DORMANT_DUE', 10, '2026-09-20', with_label=False)
    t('★ 휴면 재점검 = 기한 지난 것만', [x[0] for x in due] == [3], due)
    st = targets(c, 'STALE', 10, '2026-12-01', with_label=False)
    t('오래된 것부터(장부 없음 → 옛 날짜 순) · 휴면 제외',
      3 not in [x[0] for x in st] and st[0][0] in (4,) or st[0][5] is None, st)
    # 매일 실행 — 키 없으면 말하고 건너뛴다
    msgs = []
    n, s = run(c, limit=10, log=msgs.append, today='2026-09-20', keys=[])
    t('★ 키가 없으면 0 을 내고 말한다', n == 0 and s.get('skipped') == 'NO_KEY'
      and any('키' in m for m in msgs))
    n, s = run(c, limit=10, dry=True, log=lambda *a: None,
               today='2026-09-20', keys=['k'])
    t('dry 는 대상만 센다(휴면 재점검이 앞에)', n == 0 and s['due'] == 1)
    h = health(c, '2026-09-20')
    t('현황 — 휴면 1 · 제거 0 · 기한 지남 1',
      h['dormant'] == 1 and h['removed'] == 0 and h['dormant_due'] == 1, h)
    t('현황 한 줄이 글이다', '휴면' in health_line(h))
    t('★ 상태표와 죽음 목록이 한 몸', set(DEAD) == {'DEAD'})
    # ★★★ **임베드 차단은 죽음이 아니다**(283차 ① · 1.txt 14번) — 양방향.
    t('★★★ 임베드 차단은 **죽음이 아니다**', 'EMBED_BLOCKED' not in DEAD)
    t('  그래도 상태표에는 남는다(여는 방식을 정하는 근거)',
      'EMBED_BLOCKED' in STATUS)
    import sqlite3 as _sq3
    c2 = _sq3.connect(':memory:')
    c2.executescript(
        "CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY,"
        " is_active INT, record_status TEXT, url TEXT);"
        "INSERT INTO sys_media_asset VALUES(1,1,'LIVE','u1');"
        "INSERT INTO sys_media_asset VALUES(2,1,'LIVE','u2');")
    init(c2)
    record(c2, 1, 'EMBED_BLOCKED', '임베드 불가', '2026-09-24')
    a1 = c2.execute("SELECT is_active, embed_ok FROM sys_media_asset"
                    " WHERE media_id=1").fetchone()
    t('★★★ 임베드 차단이어도 **안 내린다**', a1[0] == 1, str(a1))
    t('★★ 배포되는 칸에 **막혔다고 적는다**(사용자 앱이 읽는다)', a1[1] == 0)
    record(c2, 2, 'OK', '', '2026-09-24')
    t('  정상이면 된다고 적는다',
      c2.execute("SELECT embed_ok FROM sys_media_asset WHERE media_id=2"
                 ).fetchone()[0] == 1)
    # 옛 규칙으로 내려간 것을 되살린다
    c2.execute("UPDATE sys_media_asset SET is_active=0 WHERE media_id=1")
    c2.execute("UPDATE %s SET dormant_since='2026-09-01', was_active=1"
               " WHERE media_id=1" % TBL)
    r = revive_embed(c2)
    t('★★★ 옛 규칙으로 내려간 것을 **되살린다**',
      r['revived'] == 1
      and c2.execute("SELECT is_active FROM sys_media_asset WHERE media_id=1"
                     ).fetchone()[0] == 1, str(r))
    t('  되살려도 **막혔다는 사실은 남는다**',
      c2.execute("SELECT embed_ok FROM sys_media_asset WHERE media_id=1"
                 ).fetchone()[0] == 0)
    t('  두 번 돌려도 그대로(멱등)', revive_embed(c2)['revived'] == 0)
    c2.close()
    # 팩 분류표에 있는가
    try:
        import db_pack_catalog as PC
        t('★ 장부가 팩 분류표에 LOCAL 로 있다',
          PC.TABLES.get(TBL, (None,))[0] == PC.LOCAL)
    except Exception as e:
        t('팩 분류표', False, e)
    # 미검토 독자들이 not_dormant 를 쓰는가 — 소스로 잰다
    here = os.path.dirname(os.path.abspath(__file__))
    marker = 'not_' + 'dormant('
    for f in ('db_media_autoapprove.py', 'admin/panel_media.py',
              'admin/panel_entity_youtube.py', 'rss_publish.py'):
        try:
            src = open(os.path.join(here, f), encoding='utf-8').read()
            t('★ %s 가 휴면을 미검토에서 뺀다' % f, marker in src)
        except Exception as e:
            t(f, False, e)
    src = open(os.path.join(here, 'collect_channels.py'), encoding='utf-8').read()
    t('★ 매일 작업이 링크 점검을 부른다', 'db_media_' + 'linkcheck' in src)
    for f in ('admin/panel_media.py', 'admin/panel_entity_youtube.py'):
        src = open(os.path.join(here, f), encoding='utf-8').read()
        t('★ %s 에 링크 점검 탭이 없다(화면 하나)' % f,
          'Link' + 'CheckTab(' not in src)
    c.close()
    print('db_media_linkcheck selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect()
    try:
        argv = sys.argv
        lim = int(argv[argv.index('--limit') + 1]) if '--limit' in argv else DAILY_MAX
        if '--revive-embed' in argv:
            # ★ 옛 규칙(임베드 차단=죽음)으로 내려간 것을 되살린다 — 283차 ①
            r = revive_embed(conn)
            print('되살림 %d편 · 막힘 표식 %d편' % (r['revived'], r['marked']))
        elif '--run' in argv:
            run(conn, limit=lim, dry='--dry' in argv)
        elif '--undo-removed' in argv:
            since = argv[argv.index('--since') + 1] if '--since' in argv else None
            print('되돌린 제거 %d건' % undo_removed(conn, since=since))
        else:
            init(conn)
            print(health_line(health(conn)))
    finally:
        conn.close()
