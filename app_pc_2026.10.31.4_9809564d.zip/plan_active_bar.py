# plan_active_bar.py
"""묵상플랜 4개 서브탭 상단 띠의 **「◉ 진행중」 콤보 + Font 단추** — 단일 소스.

★ 왜 따로 뺐나 (2026-08-14 사용자 지적).
  「4개 서브탭에 배치된 진행중플랜 콤보상자에서 **표시되는 원리가 서로 다르다**.」
  실제로 그랬다 — 세 탭은 `PlanMainView` 안에서 각자 목록을 만들면서 **자기 묶음만
  꼬리표를 떼고** 있었고, 렌즈묵상은 `PlanMainView` 가 아니라서 **콤보가 아예 없었다.**
  ⇒ 목록을 만드는 곳을 **한 함수**로, 띠를 그리는 곳을 **한 클래스**로 모았다.
    앞으로 서브탭이 늘어도 이 파일만 부르면 같은 모양·같은 원리가 된다.

⚠ **묶음로 걸러내지 않는다.** 그렇게 했더니 콤보가 거의 비어 「의미없다」는 지적을
  받았다(2026-08-14). 전부 올리고, 다른 묶음를 고르면 **그 탭으로 옮겨 준다.**
⚠ **꼬리표는 늘 붙인다.** 「자기 묶음면 뗀다」가 곧 탭마다 목록이 달라지는 원인이었다.
"""
import tkinter as tk
from tkinter import ttk

import appdb
import i18n

SCOPE_NAME = {'BIBLE': '전체/주제', 'DIAG': '자가진단',
              'BOOK': '도서', 'LENS': '렌즈'}

_DUR_CODE = {365: '1Y', 364: '1Y', 730: '2Y', 1095: '3Y'}


def _plan_any(conn, lang, pid, uid):
    """묶음를 가리지 않고 그 플랜의 제목·묶음를 찾는다.

    ★ 사용자 플랜이면 **기원 sys 플랜의 제목**을 `origin` 으로 함께 준다
      (2026-08-16 서브트리). 트리에서 그 마디 아래에 놓이므로 콤보도 같은 이름을
      위에 붙여야 짝이 맞는다 — 사용자 플랜 이름은 이제 「전체」처럼 짧아서
      **혼자서는 무엇인지 알 수 없다.**
    """
    try:
        if uid:
            r = conn.execute(
                "SELECT u.plan_code, c.scope, COALESCE(("
                "  SELECT contents FROM sys_text_asset WHERE text_type='PLAN_TITLE'"
                "   AND clicked_id=p.plan_id AND UPPER(lang_code)=UPPER(?) "
                "   AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1), p.plan_code) "
                "FROM user_bible_plan u "
                "LEFT JOIN sys_bible_plan p ON p.plan_id=u.origin_plan_id "
                "LEFT JOIN sys_plan_category c ON c.cat_id=p.cat_id "
                "WHERE u.user_plan_id=?", (lang, uid)).fetchone()
            if r:
                return {'title': r[0], 'scope': r[1], 'origin': r[2]}
            return None
        r = conn.execute(
            "SELECT COALESCE(("
            "  SELECT contents FROM sys_text_asset WHERE text_type='PLAN_TITLE'"
            "   AND clicked_id=p.plan_id AND lang_code=? "
            "   AND record_status='LIVE' LIMIT 1), p.plan_code), c.scope "
            "FROM sys_bible_plan p "
            "LEFT JOIN sys_plan_category c ON c.cat_id=p.cat_id "
            "WHERE p.plan_id=?", (lang, pid)).fetchone()
        if r:
            return {'title': r[0], 'scope': r[1], 'origin': None}
    except Exception:
        pass
    return None


def active_enrollments(db_path, lang='KO'):
    """**진행중(ACTIVE)** 등록을 한 목록으로. 서브탭들이 이 함수 하나를 쓴다.

    돌려주는 각 항목: `enrollment_id · plan_id · user_plan_id · current_day ·
    enrollment_status · start_date · ptype · scope · label · combo_label`
    """
    out = []
    conn = None
    try:
        conn = appdb.connect(db_path)
        rows = conn.execute(
            "SELECT e.enrollment_id, e.plan_id, e.user_plan_id, e.current_day, "
            "       e.enrollment_status, e.start_date, "
            "       CASE WHEN e.user_plan_id IS NOT NULL "
            "            THEN u.duration_days ELSE p.duration_days END, "
            "       CASE WHEN e.user_plan_id IS NOT NULL "
            "            THEN u.plan_type ELSE p.plan_type END "
            "FROM user_plan_enrollment e "
            "LEFT JOIN sys_bible_plan p ON p.plan_id = e.plan_id "
            "LEFT JOIN user_bible_plan u ON u.user_plan_id = e.user_plan_id "
            # ★ **완료(COMPLETED)는 올리지 않는다** (2026-08-17 사용자 지시 —
            #   「완료했다면 더더구나 콤보상자에 표시되면 안 된다」). 이 콤보는
            #   「진행중」이다. 완료 기록은 플랜 상세의 완료 이력 줄(_sync_history)이
            #   보여 주고, 렌즈 트리 ✓ 마커도 따로 산다(둘 다 직접 조회라 무관).
            "WHERE e.record_status='LIVE' "
            "  AND e.enrollment_status = 'ACTIVE' "
            "  AND (p.plan_id IS NOT NULL OR u.user_plan_id IS NOT NULL) "
            "ORDER BY e.enrollment_id").fetchall()
        # ★ **겹치는 제목만** 위 묶음 이름과 묶는다 (2026-08-16 「묶음 이름 싫다」).
        #   먼저 제목을 다 모아 두 번 이상 나오는 것을 가려낸다.
        import plan_label
        # ⚠ **등록된 것이 아니라 전체 목록**을 기준으로 센다. 「1년」이 하나만
        #   등록돼 있어도 목록에는 정경순서 1년과 연대기 1년이 함께 있으므로
        #   그냥 「1년」이라고 쓰면 어느 쪽인지 알 수 없다(실측으로 잡았다).
        # ⚠ **플랜 단위로 센다**(`DISTINCT p.plan_id`). 한 플랜에 제목 행이 두 벌
        #   있으면 제 이름과 겹친 것으로 잡혀 엉뚱하게 앞 이름이 붙는다(실측).
        _titles = [r[0] for r in conn.execute(
            "SELECT t.contents FROM sys_bible_plan p "
            "JOIN sys_text_asset t ON t.clicked_id=p.plan_id "
            "     AND t.text_type='PLAN_TITLE' "
            "     AND COALESCE(t.record_status,'LIVE')='LIVE' "
            "WHERE COALESCE(p.record_status,'LIVE')='LIVE' "
            "  AND UPPER(t.lang_code)=UPPER(?) "
            "GROUP BY p.plan_id, t.contents", (lang,)).fetchall()]
        _dup = plan_label.mark_ambiguous(_titles)
        # ★ 묶음 이름은 **카테고리 표**에서 — 트리와 같은 곳을 본다 (2026-08-16).
        _cat_of = {r[0]: r[1] for r in conn.execute(
            "SELECT plan_id, cat_id FROM sys_bible_plan WHERE cat_id IS NOT NULL")}
        _catname = {r[0]: r[1] for r in conn.execute(
            "SELECT clicked_id, contents FROM sys_text_asset "
            "WHERE text_type='PLAN_CAT_NAME' AND UPPER(lang_code)=UPPER(?) "
            "  AND COALESCE(record_status,'LIVE')='LIVE'", (lang,))}
        # ★ **탭을 가르는 축이 `scope` → 카테고리로 바뀌었다** (2026-08-16 서브탭 6개).
        #   전체읽기·주제읽기·골라담기가 전부 `scope='BIBLE'` 이라 scope 로는 더 못
        #   가른다. 어느 탭으로 옮길지는 **카테고리**가 정한다.
        _parent = {r[0]: r[1] for r in conn.execute(
            "SELECT cat_id, parent_id FROM sys_plan_category "
            "WHERE COALESCE(record_status,'LIVE')='LIVE'")}

        def _root(cid, guard=0):
            while cid is not None and _parent.get(cid) is not None and guard < 12:
                cid, guard = _parent[cid], guard + 1
            return cid

        for enr_id, pid, uid, cur_day, status, start, dur, ptype in rows:
            d = _plan_any(conn, lang, pid, uid) or {}
            title = d.get('title') or str(pid)
            dur_code = _DUR_CODE.get(dur, '%sd' % dur)
            year2 = (start or '')[:4][2:] or '??'
            is_done = (status == 'COMPLETED')
            # ★ **이름은 `plan_label` 이 정한다** (2026-08-16 사용자 지시).
            #   예전 형식 `제목 - 7d · '26  [1/7일]` 은 **기간이 두 번** 들어가고
            #   정작 매일 바뀌는 진행이 맨 뒤라 **먼저 잘렸다**(34자).
            #   ⚠ 분류 꼬리표 `[도서]` 도 뺐다 — `full()` 의 묶음 이름이 그 몫을 한다.
            #     짧은 제목(「1년」)은 묶음와 묶이지 않으면 정경순서인지 연대기인지
            #     알 수 없다(사용자 지적).
            # ★ 사용자 플랜은 **늘** 기원 플랜 이름과 묶는다 (2026-08-16 서브트리).
            #   이름이 「전체」·「왕 소명」처럼 조건만 남아 혼자서는 못 알아본다.
            #   sys 플랜은 종전대로 **겹칠 때만** 묶음 이름을 붙인다(「묶음 이름 싫다」).
            if uid:
                grp, amb = d.get('origin'), True
            else:
                grp, amb = _catname.get(_cat_of.get(pid)), (title in _dup)
            label = plan_label.combo(ptype, title, cur_day, dur, is_done,
                                     ambiguous=amb, group=grp)
            sc = d.get('scope')
            cid = _cat_of.get(pid)
            tag = ''
            out.append(dict(enrollment_id=enr_id, plan_id=pid, user_plan_id=uid,
                            current_day=cur_day, enrollment_status=status,
                            start_date=start, ptype=ptype, scope=sc,
                            cat_id=cid, root_cat=_root(cid),
                            label=label,
                            combo_label=("✓ " if is_done else "") + tag + label))
    except Exception as e:
        print('[active_enrollments] %s' % e)
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
    return out


class ActivePlanBar:
    """「◉ 진행중 [ 콤보 ]        [Font]」 — 네 서브탭이 같은 모양으로 쓴다.

    `on_pick(enr)` 은 고른 항목 dict 를 받는다. `on_font()` 는 없으면 단추를 안 만든다.
    """

    LABEL_BG = '#EAF2FB'

    def __init__(self, bar, db_path, lang_getter=None,
                 on_pick=None, on_font=None):
        self.bar = bar
        self.db_path = db_path
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.on_pick = on_pick
        self.rows = []
        self.placeholder = ''

        try:
            _bg = bar.cget('bg')
        except Exception:
            _bg = self.LABEL_BG
        self.title_lbl = tk.Label(bar, text=i18n.t('PMV_ACTIVE', '진행중'),
                                  bg=_bg, fg='#1A5276',
                                  font=('', 9, 'bold'))
        # ★ 2026-10-15 88-2 「"진행중" 라벨 제거 — 이미 콤보상자 첫 화면이 표시하고 있다」 — 만들되 안 놓는다
        #   (부르는 쪽이 `title_lbl` 을 읽는다). 콤보 왼쪽 여백만 남긴다.

        self.var = tk.StringVar()
        # ★ 글꼴을 박지 않는다 (2026-08-19 0.txt ④) — 9pt 고정이 콤보를 낮고
        #   좁게 눌렀고, 펼침 목록(TkDefaultFont)과 표시부 글자 크기가 어긋났다.
        self.combo = ttk.Combobox(bar, textvariable=self.var, state='readonly',
                                  width=34)
        self.combo.pack(side='left', padx=(6, 6), pady=3)
        self.combo.bind('<<ComboboxSelected>>', self._on_select)

        # ⚠ **묵상후보는 이 띠에 두지 않는다** (2026-08-16 사용자 재지시 —
        #   「묵상후보 표시화면을 묵상플랜 자체 내에서 해결하는 방법을 생각하라」).
        #   ⇒ 왼쪽 플랜 **트리 안**에 「☆ 묵상후보」 마디로 넣었다
        #     (`plan_main_view._render_wish_node`). 띠에 콤보가 둘이면 무엇이
        #     지금 하는 것이고 무엇이 나중 것인지 오히려 흐려진다.
        # ⚠ 콤보에 **붙여 두면 잘못 누른다**(2026-08-14 사용자 지적) — 간격을 벌린다.
        if callable(on_font):
            # ★ 모양은 `ui_theme.flat_btn` 하나가 정한다 (2026-08-30 사용자
            #   지시 「모든 Font 버튼은 디자인을 통일」). 열쇠도 P1 과 같은
            #   `RS_BTN` 으로 — 이름을 바꾸면 두 자리가 함께 따라온다.
            import ui_theme as _uthf
            self.font_btn = tk.Button(bar, text=i18n.t('RS_BTN', 'Font'),
                                      command=on_font, **_uthf.flat_btn())
            self.font_btn.pack(side='left', padx=(28, 6), pady=3)
        else:
            self.font_btn = None

    # ── 목록 ────────────────────────────────────────────────────────────────
    def refresh(self):
        self.rows = active_enrollments(self.db_path, self.lang_getter())
        self.placeholder = (i18n.t('PMV_PICK_ACTIVE', '진행중 플랜 선택…')
                            if self.rows
                            else i18n.t('PMV_NO_ENROLLED', '(등록된 플랜 없음)').strip())
        self.combo['values'] = [self.placeholder] + [r['combo_label']
                                                    for r in self.rows]
        self.combo.set(self.placeholder)
        self.combo.config(state='readonly' if self.rows else 'disabled')
        return self.rows

    def clear(self):
        if self.placeholder:
            self.combo.set(self.placeholder)

    def select(self, enr_id):
        r = next((x for x in self.rows if x['enrollment_id'] == enr_id), None)
        if r:
            self.combo.set(r['combo_label'])

    def current(self):
        idx = self.combo.current()          # 0 = 프롬프트
        if idx <= 0 or not self.rows:
            return None
        return self.rows[idx - 1]

    def _on_select(self, event=None):
        r = self.current()
        if r is None:
            return
        if r.get('enrollment_status') == 'COMPLETED':
            return
        if callable(self.on_pick):
            self.on_pick(r)


class ModeCombo:
    """묵상플랜·렌즈 띠의 **사용자 모드 콤보** — M 단추 바로 왼쪽 (2026-10-15 88-4).

    사용자 「사용자모드 사용할 가능성이 높지 않은데 버튼 방식은 시각적으로 불편하다 · M 버튼 왼쪽에 콤보상자」.
    ⇒ 수정하기·가져오기·내보내기·삭제(렌즈는 + 나의 렌즈 만들기)를 **고르는 순간 실행**하고 콤보는 이름으로 돌아온다.
    원본 가리기/표시하기는 상태라 콤보에 넣지 않고 그 왼쪽 단추로 둔다(배포 것을 수정한 사본일 때만).

    `acts` = {열쇠: Act} — 화면이 `acts[k].config(command=…)` 로 일을 심는다(단추였던 때와 같은 말).
    `place(keys)` = 지금 보일 항목. 늘 「가져오기」가 들어간다(아무것도 안 골라도 할 수 있다)."""

    ORDER = ('new', 'edit', 'import', 'export', 'delete')
    NAMES = {'new': ('LENS_NEW_MINE', '나의 렌즈 만들기'), 'edit': ('PMV_B_EDIT', '수정하기'),
             'import': ('PMV_B_IMPORT', '가져오기'), 'export': ('PMV_B_EXPORT', '내보내기'),
             'delete': ('PMV_B_DELETE', '삭제')}

    class Act:
        """콤보 항목 하나 — 단추처럼 `config(command=)` 를 받는다."""
        def __init__(self):
            self.command = None

        def config(self, **kw):
            if 'command' in kw:
                self.command = kw['command']
        configure = config

        def invoke(self):
            if callable(self.command):
                self.command()

        def pack_forget(self):
            pass

    def __init__(self, bar, extra=('hide', 'show'), always=('import',)):
        import ui_theme as _ut
        self.bar, self.always = bar, tuple(always)
        self.var = tk.StringVar()
        self.placeholder = i18n.t('PMV_MODE', '사용자 모드')
        self.combo = ttk.Combobox(bar, textvariable=self.var, state='readonly', width=12)
        self.combo.bind('<<ComboboxSelected>>', self._pick)
        self.acts = {k: self.Act() for k in self.ORDER}
        self.btns = {}
        for k, key, ko in (('hide', 'CO_HIDE', '원본 가리기'), ('show', 'CO_SHOW', '원본 표시하기')):
            if k in extra:
                self.btns[k] = tk.Button(bar, text=i18n.t(key, ko), **_ut.flat_btn())
                self.acts[k] = self.btns[k]
        self._labels = {}
        self.keys = ()
        self.place(())

    def pack(self):
        """M 이 이미 오른쪽에 있다 — 콤보를 그 왼쪽에, 원본 단추를 다시 그 왼쪽에."""
        self.combo.pack(side='right', padx=(16, 8), pady=3)

    def place(self, keys):
        keys = tuple(keys)
        items = [k for k in self.ORDER if k in keys or k in self.always]
        self.keys = tuple(items)
        self._labels = {i18n.t(*self.NAMES[k]): k for k in items}
        self.combo.config(values=list(self._labels))
        longest = max([len(x) for x in self._labels] + [len(self.placeholder)])
        self.combo.config(width=max(8, min(22, longest + 2)))
        self.var.set(self.placeholder)
        for k, b in self.btns.items():
            b.pack_forget()
        for k in ('show', 'hide'):           # 오른쪽부터 붙이므로 거꾸로
            if k in keys and k in self.btns:
                self.btns[k].pack(side='right', padx=(0, 4), pady=3)

    def _pick(self, _e=None):
        k = self._labels.get(self.var.get())
        self.var.set(self.placeholder)
        try:
            self.combo.selection_clear()
        except Exception:
            pass
        if k:
            self.acts[k].invoke()

    def choose(self, k):
        """시험·코드용 — 그 항목을 고른 것과 같다."""
        if k in self.keys:
            self.acts[k].invoke()


def _selftest():
    """Tk 없이 되는 것만 — 꼬리표 규칙과 라벨 조립."""
    bad = []
    if set(SCOPE_NAME) != {'BIBLE', 'DIAG', 'BOOK', 'LENS'}:
        bad.append('묶음 이름표가 4개가 아니다')
    # 꼬리표는 묶음가 있으면 늘 붙는다 (탭마다 목록이 갈리지 않게)
    for sc in SCOPE_NAME:
        if not ('[%s] ' % SCOPE_NAME[sc]):
            bad.append('꼬리표가 비었다: %s' % sc)
    if _DUR_CODE.get(365) != '1Y' or _DUR_CODE.get(730) != '2Y':
        bad.append('기간 코드가 어긋났다')
    # 실제 DB 로 목록을 만들어 본다 — 이름·진행이 제대로 붙는가
    #
    # ⚠ **예전 검사는 「꼬리표 `[갈래]` 가 늘 있는가」였다.** 2026-08-16 에 사용자
    #   지시로 꼬리표를 없앴는데 검사만 남아 계속 FAIL 했다.
    #   ⇒ 규칙을 바꾸면 그 규칙을 지키던 검사도 함께 고친다.
    import os
    db = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                      'bible_master.db')
    if os.path.exists(db):
        rows = active_enrollments(db, 'KO')
        for r in rows:
            lb = r['combo_label']
            if '[' in lb:
                bad.append('옛 꼬리표가 남았다: %s' % lb)
            # ⚠ **완료된 플랜은 날짜 대신 `✓ 완료`** 다 — 그것을 「진행 표시가 없다」로
            #   잡고 있었다(2026-08-16). 그리고 「일」로 재면 **한국어에서만** 통한다:
            #   진행 표시는 이제 다국어(`PL_PROGRESS`)라 EN 은 `Day 4/365` 다.
            #   ⇒ **그 날짜 숫자가 들어 있는가**로 잰다.
            if (r.get('current_day') and r.get('enrollment_status') != 'COMPLETED'
                    and str(r['current_day']) not in lb):
                bad.append('진행 표시가 없다: %s' % lb)
            # ★ 완료는 콤보에 오르지 않는다 (2026-08-17 사용자 지시)
            if r.get('enrollment_status') == 'COMPLETED':
                bad.append('완료가 콤보에 남았다: %s' % lb)
            if len(lb) > 34:
                bad.append('예전(34자)보다 길다: %d자 %s' % (len(lb), lb))
            if r['enrollment_id'] is None:
                bad.append('enrollment_id 가 없다')
        print('   (실측) 등록 플랜 %d개' % len(rows))
        for r in rows:
            print('     %s' % r['combo_label'])
    print('plan_active_bar selftest:', 'OK' if not bad else 'FAIL')
    for b in bad:
        print('  X', b)
    return not bad


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if _selftest() else 1)
    print(__doc__)
