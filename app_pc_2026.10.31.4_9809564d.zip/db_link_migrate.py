# -*- coding: utf-8 -*-
"""db_link_migrate.py — 흩어진 연결 표를 통합 표로 **한 표씩** 옮긴다 (영구 도구).

**받는 그릇은 `db_link_unify.py` 가 먼저 넓혀 둔다**(0단계). 이 도구는 옮기기만 한다.

★ **원칙 넷** (사용자 지시 「이미 연결된 것들이 끊어지지 않도록 … 각 단계마다 점검」)
  ① **옛 표를 지우지 않는다.** 옮긴 뒤에도 그대로 남는다 — 되돌릴 수 있게.
  ② **한 표씩.** 옮기고 · 화면을 고치고 · 확인하고 · 다음 표로.
  ③ **멱등.** 두 번 돌려도 안 늘어난다(`INSERT OR IGNORE` + 이력 대조).
  ④ **되돌릴 수 있다.** `sys_linkmig_log` 가 「어느 표의 몇 번이 어디로 갔나」를
    남기므로 `--restore` 가 **그 행만** 지운다(다른 연결을 안 건드린다).

⚠⚠ **`link_type` 이 A·B의 종류를 말한다** — 사용자 설계 그대로. `a_scope` 같은
  칸을 만들지 않았고, 번호가 겹치는 사용자 자산은 **코드를 가른다**(`TAG_UREF`).

⚠⚠ **문자열 열쇠를 쓰는 넷은 안 옮긴다**(사용자 승인 2026-08-24):
  `sys_chain_route`(chain_code) · `sys_tag_source_map`(src_key) ·
  `sys_book_unit_tag`·`sys_book_asset_tag`(tag_value).
  숫자 칸에 글자를 넣으면 **조용히 0 이 되거나 엉뚱한 자산을 가리킨다.**

⚠ 실측으로 잡은 제약 셋:
  · `trg_*_vers_check` — **`VERS_VERS` 만** clicked_id < target_id 를 강제한다.
  · **감사 트리거 3개**가 걸려 있다 — 큰 표는 `db_audit_triggers.py --off` 로 끄고 옮긴다.
  · **UNIQUE 가 sys 와 user 가 다르다** — sys 는 `(…, rel_code)` 까지, user 는 없다.
    ⇒ user 쪽은 같은 짝에 rel_code 여러 개를 못 담는다.

사용:
    python db_link_migrate.py --selftest        (의무)
    python db_link_migrate.py --status
    python db_link_migrate.py --check  <표…|all>
    python db_link_migrate.py --apply  <표…>
    python db_link_migrate.py --restore <표…>
"""
import sys

import appdb

LOG = 'sys_linkmig_log'

LOG_DDL = """CREATE TABLE IF NOT EXISTS main.%s (
    mig_id     INTEGER PRIMARY KEY AUTOINCREMENT,
    src_table  TEXT NOT NULL,      -- 어느 표에서 왔나
    src_id     INTEGER NOT NULL,   -- 그 표의 PK
    dst_schema TEXT NOT NULL,      -- 'main' | 'userdb'
    dst_id     INTEGER NOT NULL,   -- 통합 표의 PK
    moved_at   TEXT NOT NULL,
    UNIQUE(src_table, src_id))""" % LOG

DESC_LOG = 'sys_linkmig_desc'

#: ⚠⚠ 딸린 설명문의 **닻을 옮긴 기록**. 이것이 없으면 되돌릴 수 없다.
DESC_DDL = """CREATE TABLE IF NOT EXISTS main.%s (
    d_id        INTEGER PRIMARY KEY AUTOINCREMENT,
    src_table   TEXT NOT NULL,
    text_type   TEXT NOT NULL,
    sys_text_id INTEGER NOT NULL,
    old_clicked INTEGER NOT NULL,
    new_clicked INTEGER NOT NULL,
    UNIQUE(sys_text_id, text_type))""" % DESC_LOG

DST = {'main': ('main', 'sys_link_asset', 'sys_link_id'),
       'userdb': ('userdb', 'user_link_asset', 'user_link_id')}

#: 통합 표에 넣을 수 있는 칸 (곁다리 여섯 포함)
FIELDS = ('link_type', 'clicked_id', 'target_id', 'end_id', 'rel_code',
          'chain_code', 'sort_order', 'record_status', 'origin_id',
          'note', 'milestone_type', 'importance', 'is_key', 'source',
          'confidence', 'lemma_id', 'is_directed', 'relation_cat')


class Spec:
    """한 표를 어떻게 옮기나.

    `rows(conn)` 가 `[(옛 PK, {칸: 값}), …]` 를 준다. **SQL 을 문자열로 짜
    맞추지 않고 파이썬으로 만든다** — 유형마다 갈래가 달라서(같은 표가
    `TAG_BUNT`·`TAG_CONT`·`TAG_BOOK` 셋으로 갈린다) SQL 하나로는 안 된다.

    ⚠⚠ **`desc` 가 핵심이다.** 그 표의 PK 를 **닻으로 삼는 설명문**이 있으면
      여기 적는다. 안 적으면 옮기는 순간 **설명문이 미아가 된다** — 실측으로
      1,741편이 그렇다(`ENTITY_PERI_DESC` 1,723 · `ENTITY_COMPARE_DESC` 16 ·
      `ENTITY_VERSE_DESC` 2). 오류도 안 나고 화면에서 조용히 사라진다.
    """

    def __init__(self, key, sch, tbl, pk, dst, rows, why, desc=()):
        self.key, self.sch, self.tbl, self.pk = key, sch, tbl, pk
        self.dst, self.rows, self.why = dst, rows, why
        self.desc = tuple(desc)     # 그 PK 를 닻으로 쓰는 sys_text_asset 유형


# ── 표마다 옮기는 법 ─────────────────────────────────────────────────────────

def _q(conn, sql, args=()):
    return list(conn.execute(sql, args))


def _live(v):
    """`record_status` 는 비어 있으면 LIVE 다(§10). 그대로 옮긴다."""
    return v or 'LIVE'


def _entity_compare(conn):
    """헷갈리는 이웃 낱말 — 용어 ↔ 용어.

    ⚠ **한 짝이 한 행이고 양쪽에서 다 보인다**(entity.md ①). 방향마다 행을
      두면 한쪽만 고쳐져 어긋난다 — 옮길 때도 그 성질을 지킨다.
    """
    out = []
    for cid, a, b, so, rs in _q(conn,
            "SELECT compare_id, entity_id, other_id, sort_order, record_status "
            "  FROM sys_entity_compare"):
        out.append((cid, dict(link_type='ENTI_ENTI', clicked_id=a, target_id=b,
                              sort_order=so, record_status=_live(rs))))
    return out


def _book_unit_verse(conn):
    """도서 편 ↔ 구절. `verse_role`(QUOTED/SUPPORT/CONTEXT) 는 `rel_code` 로."""
    out = []
    for uv, uid, vid, role, so, rs in _q(conn,
            "SELECT uv_id, unit_id, verse_id, verse_role, sort_order, record_status "
            "  FROM sys_book_unit_verse"):
        out.append((uv, dict(link_type='BUNT_VERS', clicked_id=uid, target_id=vid,
                             rel_code=role, sort_order=so, record_status=_live(rs))))
    return out


def _ref_book_link(conn):
    """자료집 글 ↔ 도서 편. 지금 0행이지만 규칙은 둔다(관리자 화면이 쓴다)."""
    out = []
    for lid, ru, uid, so, rs in _q(conn,
            "SELECT link_id, ref_unit_id, unit_id, sort_order, record_status "
            "  FROM sys_ref_book_link"):
        out.append((lid, dict(link_type='REFU_BUNT', clicked_id=ru, target_id=uid,
                              sort_order=so, record_status=_live(rs))))
    return out


def _unit_tag_link(conn):
    """도서 편 ↔ 태그 (빈 표). ⚠ A는 태그다 — 태그가 여럿에 걸리므로 `TAG_` 로 시작."""
    out = []
    for lid, uid, tid, rs in _q(conn,
            "SELECT link_id, unit_id, sys_tag_id, record_status FROM sys_unit_tag_link"):
        out.append((lid, dict(link_type='TAG_BUNT', clicked_id=tid, target_id=uid,
                              record_status=_live(rs))))
    return out


def _book_tag_link(conn):
    """도서 ↔ 태그 (빈 표)."""
    out = []
    for lid, bid, tid, rs in _q(conn,
            "SELECT link_id, book_id, sys_tag_id, record_status FROM sys_book_tag_link"):
        out.append((lid, dict(link_type='TAG_BOOK', clicked_id=tid, target_id=bid,
                              record_status=_live(rs))))
    return out


def _ref_entity_link(conn):
    """자료집 글 ↔ 용어. `link_role` 은 `rel_code` 로."""
    out = []
    for lid, ru, eid, role, rs in _q(conn,
            "SELECT link_id, ref_unit_id, entity_id, link_role, record_status "
            "  FROM sys_ref_entity_link"):
        out.append((lid, dict(link_type='REFU_ENTI', clicked_id=ru, target_id=eid,
                              rel_code=role, record_status=_live(rs))))
    return out


def _book_unit_entity(conn):
    """도서 편 ↔ 용어. `link_role`→`rel_code` · `source` 는 곁다리 그대로."""
    out = []
    for lid, uid, eid, role, src, rs in _q(conn,
            "SELECT link_id, unit_id, entity_id, link_role, source, record_status "
            "  FROM sys_book_unit_entity"):
        out.append((lid, dict(link_type='BUNT_ENTI', clicked_id=uid, target_id=eid,
                              rel_code=role, source=src, record_status=_live(rs))))
    return out


#: `sys_ref_asset_link.link_kind` · `user_ref_asset_link.link_kind` → 상대 종류
_REF_KIND = {'VERSE': 'VERS', 'ENTITY': 'ENTI', 'PERICOPE': 'PERI',
             'BOOK_UNIT': 'BUNT'}


def _ref_asset_link(conn):
    """수집 자료 ↔ 여러. ⚠ `end_id` 가 구절 범위의 끝이다(§21-2a)."""
    out = []
    for lid, rid, kind, tgt, end, rs in _q(conn,
            "SELECT link_id, ref_id, link_kind, target_id, end_id, record_status "
            "  FROM sys_ref_asset_link"):
        k = _REF_KIND.get(kind)
        if not k:
            continue          # 모르는 갈래는 건너뛴다 — `check` 가 세어 알린다
        out.append((lid, dict(link_type='RSSA_' + k, clicked_id=rid, target_id=tgt,
                              end_id=end, record_status=_live(rs))))
    return out


#: 묵상경로 kind → 자산 코드. ⚠ 렌즈는 `sys_unit_asset`(CONTAINER) 이라 `CONT`.
_ROUTE_KIND = {'PLAN': 'PLAN', 'LENS': 'CONT', 'BOOK': 'BOOK', 'REF': 'REFS'}


def _plan_route(conn):
    """묵상경로 — 「다음 걸음」. **방향이 있다**(from → to) ⇒ `rel_code='NEXT'`.

    ⚠ 다른 연결은 방향이 없는데 이것만 있다. 그래서 A·B를 정렬하지 않고
      **from 을 그대로 A** 로 둔다.
    """
    out = []
    for rid, fk, fi, tk, ti, note, so, rs in _q(conn,
            "SELECT route_id, from_kind, from_id, to_kind, to_id, note, "
            "       sort_order, record_status FROM sys_plan_route"):
        a, b = _ROUTE_KIND.get(fk), _ROUTE_KIND.get(tk)
        if not (a and b):
            continue
        out.append((rid, dict(link_type='%s_%s' % (a, b), clicked_id=fi, target_id=ti,
                              rel_code='NEXT', note=note, sort_order=so,
                              record_status=_live(rs))))
    return out


#: `sys_tag_link.target_type` → 자산 코드
_TAG_TGT = {'BOOK_UNIT': 'BUNT', 'LENS': 'CONT', 'BOOK': 'BOOK',
            'NODE': 'NODE', 'PLAN': 'PLAN', 'REF_UNIT': 'REFU',
            'USER_REF': 'UREF', 'UPLAN': 'UPLN', 'ULENS': 'UCNT',
            'UNODE': 'UNOD'}


def _tag_link(conn):
    """태그 ↔ 여러. **A는 늘 태그**다."""
    out = []
    for lid, tid, tt, tgt, rs in _q(conn,
            "SELECT link_id, sys_tag_id, target_type, target_id, record_status "
            "  FROM sys_tag_link"):
        k = _TAG_TGT.get(tt)
        if not k:
            continue
        out.append((lid, dict(link_type='TAG_' + k, clicked_id=tid, target_id=tgt,
                              record_status=_live(rs))))
    return out


def _entity_pericope(conn):
    """용어 ↔ 단락. `role_in_peri`→`rel_code` · 국면·중요도는 곁다리.

    ⚠ **`is_milestone` 은 안 옮긴다** — `milestone_type IS NOT NULL` 과
      **양방향 0건 어긋남**(1,622행 실측). 중복 칸이다.
    """
    out = []
    for ep, eid, pid, mt, role, imp, rs in _q(conn,
            "SELECT ep_id, entity_id, pericope_id, milestone_type, role_in_peri, "
            "       importance, record_status FROM sys_entity_pericope"):
        out.append((ep, dict(link_type='ENTI_PERI', clicked_id=eid, target_id=pid,
                             rel_code=role, milestone_type=mt, importance=imp,
                             record_status=_live(rs))))
    return out


def _ref_verse_link(conn):
    """자료집 글 ↔ 구절(범위). `link_role`→`rel_code` · `end_vid`→`end_id`.

    ⚠ `pericope_id` 칸이 있지만 **실측 0건**이라 안 옮긴다(빈 칸을 옮기면
      「단락도 가리킨다」는 잘못된 인상을 준다).
    """
    out = []
    # ⚠⚠ **`end_vid` 를 그대로 옮긴다.** 「끝이 시작과 같으면 비운다」로 다듬고
    #   싶었지만 실측하니 **NULL 3,112 ↔ 같음 73 ↔ 구간 379** 로 두 가지가
    #   실제로 섞여 있다. 읽는 쪽이 그 둘을 다르게 볼 수 있으므로(단일 절 표기)
    #   **값을 손대지 않는 것이 옳다** — 되돌리기도 완전해진다.
    for lid, ru, sv, ev, role, so, rs in _q(conn,
            "SELECT link_id, ref_unit_id, start_vid, end_vid, link_role, "
            "       sort_order, record_status FROM sys_ref_verse_link"):
        out.append((lid, dict(link_type='REFU_VERS', clicked_id=ru, target_id=sv,
                              end_id=ev, rel_code=role, sort_order=so,
                              record_status=_live(rs))))
    return out


def _entity_verse(conn):
    """용어 ↔ 구절. `link_kind`(LEXICAL/THEMATIC)→`rel_code` · `is_key` 곁다리.

    ⚠ `lemma_id` 를 처음엔 **안 옮기려 했다**(「연결의 성격이 아니라 참조다」).
      **실측이 뒤집었다** — 18,868행 중 **18,867행**이 갖고 있고
      `db_term_load --show/--list` 가 그것으로 「그 원어 낱말이 몇 절에
      나오나」를 센다. 빼면 그 셈이 통째로 사라진다.
    """
    out = []
    for ev, eid, vid, kind, key, lem, so, rs in _q(conn,
            "SELECT ev_id, entity_id, verse_id, link_kind, is_key, lemma_id, "
            "       sort_order, record_status FROM sys_entity_verse"):
        out.append((ev, dict(link_type='ENTI_VERS', clicked_id=eid, target_id=vid,
                             rel_code=kind, is_key=key, lemma_id=lem, sort_order=so,
                             record_status=_live(rs))))
    return out


def _person_relation(conn):
    """인물 ↔ 인물. 양 끝이 **엔티티 번호**다(2026-08-25 이름 대조로 확인 —
    사울→요나단 FATHER · 이새→다윗 · 다윗→솔로몬 전부 말이 된다).

    ⚠ **번호가 그 표에 있느냐로 판정하면 안 된다** — `sys_genealogy_person` 과
      번호대가 겹쳐 **양쪽 다 100%** 가 나온다(세 번 당했다). 이름을 맞춰야 한다.
    ⚠ `relation_cat`·`is_directed` 는 `rel_code` 로 못 접는다(§db_link_unify).
    """
    out = []
    for rid, a, b, cat, typ, dirq, rs in _q(conn,
            "SELECT relation_id, from_person_id, to_person_id, relation_cat, "
            "       relation_type, is_directed, record_status "
            "FROM sys_person_relation"):
        if a is None or b is None:
            continue
        out.append((rid, dict(link_type='ENTI_ENTI', clicked_id=a, target_id=b,
                              rel_code=typ, relation_cat=cat,
                              is_directed=dirq, record_status=_live(rs))))
    return out


def _idol_person(conn):
    """우상 ↔ 인물. 둘 다 엔티티다(우상은 `entity_type='IDOL'`).

    ⚠ 관계 이름이 인물 관계와 **하나도 안 겹친다**(실측) — 같은 `ENTI_ENTI`
      안에 있어도 `rel_code` 로 갈린다.
    """
    out = []
    for rid, a, b, typ, note, rs in _q(conn,
            "SELECT idol_rel_id, idol_id, person_id, relation_type, note, "
            "       record_status FROM sys_idol_person_relation"):
        if a is None or b is None:
            continue
        out.append((rid, dict(link_type='ENTI_ENTI', clicked_id=a, target_id=b,
                              rel_code=typ, note=note,
                              record_status=_live(rs))))
    return out


_MEDIA_SCOPE = {'ENTITY': 'ENTI', 'PERICOPE': 'PERI', 'VERSE': 'VERS'}


def _media_link(conn):
    """영상 ↔ 대상. ⚠ `scope_key` 가 TEXT 지만 **16,264행 전부 숫자꼴**이다(실측).

    그래도 **하나씩 확인하고 넣는다** — 나중에 글자가 섞이면 그 행만 건너뛰고
    `check` 가 세어 알린다(조용히 0 이 되지 않게).
    """
    out = []
    for lid, mid, sc, key, conf, rs in _q(conn,
            "SELECT link_id, media_id, scope, scope_key, link_confidence, "
            "       record_status FROM sys_media_link"):
        k = _MEDIA_SCOPE.get(sc)
        if not k:
            continue
        try:
            tgt = int(str(key).strip())
        except (TypeError, ValueError):
            continue          # 숫자가 아니면 안 옮긴다
        out.append((lid, dict(link_type='MEDI_' + k, clicked_id=mid, target_id=tgt,
                              confidence=conf, record_status=_live(rs))))
    return out


# ── 개인 쪽 ────────────────────────────────────────────────────────────────

#: ⚠⚠ **`link_picker.CODE` 와 같아야 한다** — 어긋나면 이전한 행을 화면이
#   못 찾는다. `link_picker` selftest 가 이 표를 대조한다(실제로 `ULENS`·
#   `UNODE` 가 빠져 있던 것을 그 검사가 잡았다).
#   ⚠ **내 렌즈·내 노드는 따로 센다** — `user_unit_asset` 과 `sys_unit_asset` 은
#     번호가 겹친다(태그가 이미 그렇게 갈라 두었다).
_USER_KIND = {'VERSE': 'VERS', 'ENTITY': 'ENTI', 'PERICOPE': 'PERI',
              'BOOK_UNIT': 'BUNT', 'BOOK': 'BOOK', 'REF_UNIT': 'REFU',
              'USER_REF': 'UREF', 'LENS': 'CONT', 'NODE': 'NODE',
              'ULENS': 'UCNT', 'UNODE': 'UNOD'}


def _user_ref_asset_link(conn):
    """내 자료 ↔ 여러. **A는 늘 내 자료**(UREF)."""
    out = []
    for lid, rid, kind, tgt, end, so, rs in _q(conn,
            "SELECT link_id, ref_id, link_kind, target_id, end_id, sort_order, "
            "       record_status FROM userdb.user_ref_asset_link"):
        k = _USER_KIND.get(kind)
        if not k:
            continue
        out.append((lid, dict(link_type='UREF_' + k, clicked_id=rid, target_id=tgt,
                              end_id=end, sort_order=so, record_status=_live(rs))))
    return out


def _user_link(conn):
    """무엇이든 ↔ 무엇이든 (연결하기 창이 쓰는 표).

    ⚠ **`a_end` 는 실측 전부 비어 있다** — `b_end` 만 `end_id` 로 옮긴다.
    ⚠ **`user_ref_asset_link` 와 같은 짝이 있다**(UREF_VERS 326 ↔ 321).
      UNIQUE 가 접어 주므로 **먼저 옮긴 쪽이 남는다** — 그것이 통합의 이유다.
    """
    out = []
    for lid, ak, ai, ae, bk, bi, be, note, rs in _q(conn,
            "SELECT link_id, a_kind, a_id, a_end, b_kind, b_id, b_end, note, "
            "       record_status FROM userdb.user_link"):
        a, b = _USER_KIND.get(ak), _USER_KIND.get(bk)
        if not (a and b):
            continue
        if ae is not None:
            # 실측 0건이지만 생기면 알아야 한다 — 조용히 버리지 않는다
            continue
        out.append((lid, dict(link_type='%s_%s' % (a, b), clicked_id=ai,
                              target_id=bi, end_id=be, note=note,
                              record_status=_live(rs))))
    return out


def _user_tag_link(conn):
    """태그 ↔ 여러 (개인). ⚠ `tag_source` 가 SYS/USER 를 가른다 — 번호가 겹친다."""
    out = []
    for lid, tsrc, tid, tt, tgt, rs in _q(conn,
            "SELECT link_id, tag_source, tag_id, target_type, target_id, "
            "       record_status FROM userdb.user_tag_link"):
        k = _USER_KIND.get(tt) or _TAG_TGT.get(tt)
        if not k:
            continue
        head = 'UTAG' if (tsrc or '').upper() == 'USER' else 'TAG'
        out.append((lid, dict(link_type='%s_%s' % (head, k), clicked_id=tid,
                              target_id=tgt, record_status=_live(rs))))
    return out


# ── 등록부 ──────────────────────────────────────────────────────────────────
#  차례 = 작은 것부터. 한 표를 옮기고 화면을 고친 뒤 다음으로.
SPECS = [
    Spec('sys_ref_book_link', 'main', 'sys_ref_book_link', 'link_id',
         'main', _ref_book_link, '자료집 글 ↔ 도서 편 (빈 표)'),
    Spec('sys_unit_tag_link', 'main', 'sys_unit_tag_link', 'link_id',
         'main', _unit_tag_link, '도서 편 ↔ 태그 (빈 표 · 중복)'),
    Spec('sys_book_tag_link', 'main', 'sys_book_tag_link', 'link_id',
         'main', _book_tag_link, '도서 ↔ 태그 (빈 표 · 중복)'),
    Spec('sys_entity_compare', 'main', 'sys_entity_compare', 'compare_id',
         'main', _entity_compare, '헷갈리는 이웃 낱말',
         desc=('ENTITY_COMPARE_DESC',)),
    Spec('sys_book_unit_verse', 'main', 'sys_book_unit_verse', 'uv_id',
         'main', _book_unit_verse, '도서 편 ↔ 구절'),
    Spec('sys_plan_route', 'main', 'sys_plan_route', 'route_id',
         'main', _plan_route, '묵상경로 — 다음 걸음'),
    Spec('sys_ref_asset_link', 'main', 'sys_ref_asset_link', 'link_id',
         'main', _ref_asset_link, '수집 자료 ↔ 여러'),
    Spec('sys_book_unit_entity', 'main', 'sys_book_unit_entity', 'link_id',
         'main', _book_unit_entity, '도서 편 ↔ 용어'),
    Spec('sys_tag_link', 'main', 'sys_tag_link', 'link_id',
         'main', _tag_link, '태그 ↔ 여러'),
    Spec('sys_ref_entity_link', 'main', 'sys_ref_entity_link', 'link_id',
         'main', _ref_entity_link, '자료집 글 ↔ 용어'),
    Spec('user_tag_link', 'userdb', 'user_tag_link', 'link_id',
         'userdb', _user_tag_link, '태그 ↔ 여러 (개인)'),
    Spec('user_ref_asset_link', 'userdb', 'user_ref_asset_link', 'link_id',
         'userdb', _user_ref_asset_link, '내 자료 ↔ 여러'),
    Spec('user_link', 'userdb', 'user_link', 'link_id',
         'userdb', _user_link, '무엇이든 ↔ 무엇이든'),
    Spec('sys_entity_pericope', 'main', 'sys_entity_pericope', 'ep_id',
         'main', _entity_pericope, '용어 ↔ 단락',
         desc=('ENTITY_PERI_DESC',)),
    Spec('sys_ref_verse_link', 'main', 'sys_ref_verse_link', 'link_id',
         'main', _ref_verse_link, '자료집 글 ↔ 구절(범위)'),
    Spec('sys_media_link', 'main', 'sys_media_link', 'link_id',
         'main', _media_link, '영상 ↔ 대상'),
    Spec('sys_entity_verse', 'main', 'sys_entity_verse', 'ev_id',
         'main', _entity_verse, '용어 ↔ 구절',
         desc=('ENTITY_VERSE_DESC',)),
    # ⚠⚠ `RELATION_DESC` 5편이 **이 표의 PK 를 닻으로 삼는다**(실측으로 확인 —
    #   다윗과 요나단 FRIEND · 바울과 디모데 SPIRITUAL_LEGACY … 글 내용이
    #   `sys_person_relation` 행과 정확히 맞는다). 안 적으면 미아가 된다.
    Spec('sys_person_relation', 'main', 'sys_person_relation', 'relation_id',
         'main', _person_relation, '인물 ↔ 인물',
         desc=('RELATION_DESC',)),
    Spec('sys_idol_person_relation', 'main', 'sys_idol_person_relation',
         'idol_rel_id', 'main', _idol_person, '우상 ↔ 인물'),
]
BY_KEY = {s.key: s for s in SPECS}

#: 옮기지 **않는** 표 — 이유를 남긴다(§3 · 사용자 승인 2026-08-24)
SKIP = {
    'sys_chain_route': '흐름 열쇠가 글자다(chain_code) — 먼저 번호를 붙여야 한다',
    'sys_tag_source_map': '파생 규칙이다 — src_key 가 `10213-10219` 같은 구간 글자',
    'sys_book_unit_tag': '옛 분류 코드다(tag_value) — 승격된 태그는 sys_tag_link 에 있다',
    'sys_book_asset_tag': '위와 같음',
    'sys_place_route_stop': '경로의 마디다 — 순서·좌표를 갖는다',
    'sys_entity_lemma': '엔티티의 자산이다 — 원어 낱말 정보',
    # ⚠⚠ 2026-08-25 — **양 끝이 엔티티가 아니다.** 이름을 맞춰 보면
    #   아담→가인·셋→에노스·에노스→게난(창세기 5장 계보)으로 **가계도 인물
    #   번호(gp_id)** 이고, 같은 번호를 엔티티로 읽으면 「다윗의 아버지가
    #   아브라함」 같은 헛소리가 된다. `sys_chain_route` 를 뺀 것과 같은 이유 —
    #   먼저 가계도 인물에 엔티티 번호를 붙여야 옮길 수 있다(지금 90/244).
    'sys_genealogy_relation': '양 끝이 가계도 인물 번호(gp_id)다 — 엔티티가 아니다',
    # ⚠ 「연결처럼 보이는데 연결이 아닌 것」 — 전수 훑기에서 ❓ 로 떠서 적어 둔다.
    #   사이트 × 구절 → **주소**다(규칙으로 조립한 결과). 옮기면 규칙이 만들던
    #   것을 데이터로 베껴 두고 손으로 관리하게 된다(§21-2b · ENTITY_WIKI 와 같음).
    'sys_ref_verse_map': '외부 사이트 주소다 — 규칙으로 조립한 결과(37만 행)',
}


# ── 살펴보기 ────────────────────────────────────────────────────────────────

def ensure_log(conn):
    conn.execute(LOG_DDL)
    conn.execute(DESC_DDL)
    conn.commit()


def _move_desc(conn, s, pairs, verbose=True):
    """딸린 설명문의 **닻을 새 번호로 옮긴다**.

    ⚠⚠ 안 하면 옮기는 순간 **설명문이 미아가 된다** — 오류도 안 나고 화면에서
      조용히 사라진다. 실측 1,741편이 옛 표 PK 를 닻으로 쓴다.
    ⚠ 옮기기 **전에** 옛 값을 이력에 남긴다(되돌릴 수 있게).

    `pairs` = [(옛 PK, 새 PK), …]
    """
    if not s.desc or not pairs:
        return 0
    # ⚠⚠⚠ **한 번 옮긴 글을 두 번 옮기지 않는다.** 옛 번호대와 새 번호대가
    #   겹치면 **연쇄 이동**이 일어난다 — `(1→2)` 로 옮긴 글이 다음 `(2→3)` 에
    #   다시 딸려 가고, 그렇게 끝까지 밀려 **설명문이 통째로 엉뚱한 짝에 붙는다.**
    #   selftest 가 실제로 이것을 잡았다(2026-08-24). `sys_text_id` 는 전역
    #   고유하므로 **표를 가리지 않고** 전체 이력을 본다.
    done_ids = {r[0] for r in conn.execute(
        "SELECT sys_text_id FROM %s" % DESC_LOG)}
    n = 0
    for tt in s.desc:
        for old_id, new_id in pairs:
            rows = list(conn.execute(
                "SELECT sys_text_id FROM sys_text_asset "
                " WHERE text_type=? AND clicked_id=?", (tt, old_id)))
            for (tid,) in rows:
                if tid in done_ids:
                    continue          # 이미 옮겼다 — 연쇄 이동 차단
                conn.execute(
                    "INSERT OR IGNORE INTO %s (src_table, text_type, sys_text_id, "
                    "old_clicked, new_clicked) VALUES (?,?,?,?,?)" % DESC_LOG,
                    (s.key, tt, tid, old_id, new_id))
                conn.execute("UPDATE sys_text_asset SET clicked_id=? "
                             " WHERE sys_text_id=?", (new_id, tid))
                done_ids.add(tid)
                n += 1
    if verbose and n:
        print('     ↳ 딸린 설명문 %s편의 닻도 함께 옮겼다 (%s)'
              % ('{:,}'.format(n), ' · '.join(s.desc)))
    return n


def _restore_desc(conn, key, verbose=True):
    """설명문 닻을 옛 번호로 되돌린다."""
    rows = list(conn.execute(
        "SELECT sys_text_id, old_clicked FROM %s WHERE src_table=?" % DESC_LOG, (key,)))
    for tid, old in rows:
        conn.execute("UPDATE sys_text_asset SET clicked_id=? WHERE sys_text_id=?",
                     (old, tid))
    conn.execute("DELETE FROM %s WHERE src_table=?" % DESC_LOG, (key,))
    if verbose and rows:
        print('     ↳ 설명문 %s편의 닻도 되돌렸다' % '{:,}'.format(len(rows)))
    return len(rows)


def orphan_desc(conn, key):
    """설명문이 **제 짝에 붙어 있는가**. 0 이어야 한다.

    ⚠⚠ 「어디에라도 붙어 있나」로 재면 **안 된다** — 옛 번호대와 새 번호대가
      겹칠 때 글이 엉뚱한 짝으로 밀려도 「어딘가에는 붙어 있으니」 0 이 나온다.
      그래서 실제로 뭉개진 데이터를 통과시켰다(2026-08-24 selftest 가 잡음).
      ⇒ **이력이 적어 둔 자리에 실제로 있는가**로 잰다.

    돌려주는 것 = (자리 어긋난 편수, 아직 안 옮긴 편수)
    """
    s = BY_KEY[key]
    if not s.desc:
        return 0
    # ① 옮겼다고 기록된 글이 정말 그 자리에 있는가
    wrong = conn.execute(
        "SELECT COUNT(*) FROM %s g JOIN sys_text_asset t "
        "  ON t.sys_text_id = g.sys_text_id "
        " WHERE g.src_table=? AND t.clicked_id <> g.new_clicked" % DESC_LOG,
        (key,)).fetchone()[0]
    # ② 옛 표에도 통합 표에도 닻이 없는 진짜 미아
    dsch, dtbl, dpk = DST[s.dst]
    lost = 0
    for tt in s.desc:
        lost += conn.execute(
            "SELECT COUNT(*) FROM sys_text_asset t "
            " WHERE t.text_type=? "
            "   AND NOT EXISTS (SELECT 1 FROM %s.%s x WHERE x.%s = t.clicked_id) "
            "   AND NOT EXISTS (SELECT 1 FROM %s.%s y WHERE y.%s = t.clicked_id)"
            % (s.sch, s.tbl, s.pk, dsch, dtbl, dpk), (tt,)).fetchone()[0]
    return wrong + lost


def _has(conn, sch, tbl):
    return bool(list(conn.execute(
        "SELECT 1 FROM %s.sqlite_master WHERE type='table' AND name=?" % sch, (tbl,))))


def _moved(conn, key):
    """이미 옮긴 옛 PK 집합."""
    return {r[0] for r in conn.execute(
        "SELECT src_id FROM %s WHERE src_table=?" % LOG, (key,))}


def check(conn, key, verbose=True):
    """돌려주는 것 = (옮길 것, 이미 옮긴 것, 못 옮기는 것, link_type 분포)"""
    s = BY_KEY[key]
    if not _has(conn, s.sch, s.tbl):
        if verbose:
            print('  (건너뜀) %s.%s 표가 없다' % (s.sch, s.tbl))
        return [], set(), 0, {}
    ensure_log(conn)
    raw = conn.execute('SELECT COUNT(*) FROM %s.%s' % (s.sch, s.tbl)).fetchone()[0]
    rows = s.rows(conn)
    done = _moved(conn, key)
    todo = [(i, d) for i, d in rows if i not in done]
    lost = raw - len(rows)          # 규칙이 못 읽은 것
    dist = {}
    for _i, d in rows:
        dist[d['link_type']] = dist.get(d['link_type'], 0) + 1
    if verbose:
        print('\n  ── %-24s %s' % (key, s.why))
        print('     옛 표 %s행 · 옮길 것 **%s** · 이미 옮김 %s · **못 옮김 %s**'
              % ('{:,}'.format(raw), '{:,}'.format(len(todo)),
                 '{:,}'.format(len(done)), '{:,}'.format(lost)))
        if dist:
            print('     link_type: %s' % ' · '.join(
                '%s %s' % (k, '{:,}'.format(v))
                for k, v in sorted(dist.items(), key=lambda x: -x[1])))
        if lost:
            print('     ⚠ %d행은 규칙이 못 읽었다 — 갈래 표를 넓혀야 한다' % lost)
        if s.desc:
            nd = sum(conn.execute(
                "SELECT COUNT(*) FROM sys_text_asset WHERE text_type=?",
                (tt,)).fetchone()[0] for tt in s.desc)
            print('     ↳ **딸린 설명문 %s편**(%s) — 닻도 함께 옮긴다'
                  % ('{:,}'.format(nd), ' · '.join(s.desc)))
    return todo, done, lost, dist


def apply(conn, key, verbose=True):
    """옮긴다. 멱등 — 이미 옮긴 것은 건너뛴다."""
    s = BY_KEY[key]
    todo, done, lost, _d = check(conn, key, verbose=False)
    if not todo:
        if verbose:
            print('  %-24s 옮길 것이 없다(이미 %d행)' % (key, len(done)))
        return 0, 0
    dsch, dtbl, dpk = DST[s.dst]
    # ⚠⚠ **받는 표에 실제로 있는 칸만 쓴다.** 두 표의 모양이 어긋나 있으면
    #   `no column named …` 로 터진다(2026-08-24 `user_link_asset.chain_code`).
    #   ⚠ 그렇다고 **조용히 버리지 않는다** — 버려질 값이 있으면 알린다.
    have = {r[1] for r in conn.execute('PRAGMA %s.table_info(%s)' % (dsch, dtbl))}
    cols = [c for c in FIELDS if c in have]
    gone = [c for c in FIELDS if c not in have]
    if gone:
        used = sorted({c for _i, dd in todo for c, v in dd.items()
                       if c in gone and v is not None})
        if used:
            print('  ⚠⚠ %s.%s 에 칸이 없어 **값이 버려진다**: %s'
                  % (dsch, dtbl, ', '.join(used)))
            return 0, 0          # 버리느니 멈춘다 — 칸을 먼저 만든다
        if verbose:
            print('     (%s.%s 에 없는 칸 %s — 값이 없으므로 그냥 넘어간다)'
                  % (dsch, dtbl, ', '.join(gone)))
    ph = ','.join('?' * len(cols))
    ins = 0
    skip = 0
    pairs = []          # (옛 PK, 새 PK) — 딸린 설명문의 닻을 옮길 때 쓴다
    now = conn.execute("SELECT datetime('now','localtime')").fetchone()[0]
    for old_id, d in todo:
        vals = [d.get(c) for c in cols]
        cur = conn.execute(
            'INSERT OR IGNORE INTO %s.%s (%s) VALUES (%s)'
            % (dsch, dtbl, ','.join(cols), ph), vals)
        if cur.rowcount:
            new_id = cur.lastrowid
            ins += 1
        else:
            # 이미 같은 짝이 있다 — 그것을 가리키게 이력만 남긴다(중복을 접는다)
            w = ('link_type=? AND clicked_id IS ? AND target_id IS ?'
                 + (' AND rel_code IS ?' if dsch == 'main' else ''))
            a = [d.get('link_type'), d.get('clicked_id'), d.get('target_id')]
            if dsch == 'main':
                a.append(d.get('rel_code'))
            got = conn.execute('SELECT %s FROM %s.%s WHERE %s LIMIT 1'
                               % (dpk, dsch, dtbl, w), a).fetchone()
            if not got:
                continue
            new_id = got[0]
            skip += 1
        conn.execute('INSERT OR IGNORE INTO %s (src_table, src_id, dst_schema, '
                     'dst_id, moved_at) VALUES (?,?,?,?,?)' % LOG,
                     (key, old_id, dsch, new_id, now))
        pairs.append((old_id, new_id))
    # ⚠⚠ 이것을 빠뜨리면 설명문이 미아가 된다 — 오류 없이 화면에서 사라진다
    _move_desc(conn, s, pairs, verbose=verbose)
    conn.commit()
    if verbose:
        print('  %-24s 새로 %s · 접음(이미 같은 짝) %s%s'
              % (key, '{:,}'.format(ins), '{:,}'.format(skip),
                 ' · **못 옮김 %d**' % lost if lost else ''))
        if s.desc:
            o = orphan_desc(conn, key)
            print('     ↳ 설명문 미아 %d편%s' % (o, ' ⚠' if o else ' (0이어야 한다)'))
    return ins, skip


def restore(conn, key, verbose=True):
    """되돌린다 — **이 표에서 온 행만** 지운다.

    ⚠ 중복이라 접힌 행(옛 표 둘이 같은 짝을 가리키는 것)은 **다른 표도
      가리키고 있으면 안 지운다.** 안 그러면 남의 연결이 끊어진다.
    """
    ensure_log(conn)
    rows = list(conn.execute(
        "SELECT dst_schema, dst_id FROM %s WHERE src_table=?" % LOG, (key,)))
    if not rows:
        if verbose:
            print('  %-24s 되돌릴 것이 없다' % key)
        return 0
    # ⚠ **설명문 닻을 먼저 되돌린다** — 행을 지운 뒤에는 새 번호가 사라져
    #   어느 설명문이 그 행에 붙어 있었는지 알 수 없다
    _restore_desc(conn, key, verbose=verbose)
    gone = 0
    for dsch, did in rows:
        others = conn.execute(
            "SELECT COUNT(*) FROM %s WHERE dst_schema=? AND dst_id=? AND src_table<>?"
            % LOG, (dsch, did, key)).fetchone()[0]
        if others:
            continue          # 다른 표도 이 행을 가리킨다 — 남긴다
        _s, dtbl, dpk = DST[dsch]
        conn.execute('DELETE FROM %s.%s WHERE %s=?' % (dsch, dtbl, dpk), (did,))
        gone += 1
    conn.execute("DELETE FROM %s WHERE src_table=?" % LOG, (key,))
    conn.commit()
    if verbose:
        print('  %-24s 되돌림 — 지운 행 %s (남긴 행 %s)'
              % (key, '{:,}'.format(gone), '{:,}'.format(len(rows) - gone)))
    return gone


def status(conn):
    ensure_log(conn)
    print('\n이전 진행 — 통합 표로 옮기기')
    print('  %-24s %8s %8s %8s  %s' % ('표', '옛 표', '옮김', '남음', '무엇'))
    tot_o = tot_d = 0
    for s in SPECS:
        if not _has(conn, s.sch, s.tbl):
            print('  %-24s %8s' % (s.key, '(없음)'))
            continue
        raw = conn.execute('SELECT COUNT(*) FROM %s.%s' % (s.sch, s.tbl)).fetchone()[0]
        dn = len(_moved(conn, s.key))
        tot_o += raw; tot_d += dn
        mark = '✅' if raw and dn >= raw else ('…' if dn else '  ')
        print('  %s %-22s %8s %8s %8s  %s'
              % (mark, s.key, '{:,}'.format(raw), '{:,}'.format(dn),
                 '{:,}'.format(max(0, raw - dn)), s.why))
    print('  %-26s %8s %8s' % ('합계', '{:,}'.format(tot_o), '{:,}'.format(tot_d)))
    print('\n옮기지 않는 표 — 제자리에 둔다(지우지 않는다)')
    for k, why in SKIP.items():
        try:
            n = conn.execute('SELECT COUNT(*) FROM %s' % k).fetchone()[0]
        except Exception:
            n = '?'
        print('  %-24s %8s  %s' % (k, n, why))
    print('\n받는 그릇')
    for dsch, dtbl, _pk in DST.values():
        try:
            n = conn.execute('SELECT COUNT(*) FROM %s.%s' % (dsch, dtbl)).fetchone()[0]
            print('  %-24s %8s행' % (dtbl, '{:,}'.format(n)))
        except Exception:
            pass


# ── 자가 검증 ────────────────────────────────────────────────────────────────

def selftest():
    """⚠ **진짜 DB 를 안 건드린다** — 작은 복제본을 만들어 잰다.

    ⚠ 검사를 **데이터 상태에 걸지 않는다**(§0-5) — 「지금 몇 행 옮겼나」가
      아니라 **옮겨 보고 · 되돌려 보고 · 원래대로인가**로 잰다.
    """
    import os
    import sqlite3
    ok = fail = 0

    def t(n, c, e=''):
        nonlocal ok, fail
        if c:
            ok += 1
        else:
            fail += 1
            print('  FAIL %s  %s' % (n, e))

    tmp = os.path.join(os.environ.get('TEMP', '.'), 'linkmig_selftest.db')
    for e in ('', '-wal', '-shm'):
        if os.path.exists(tmp + e):
            os.remove(tmp + e)
    d = sqlite3.connect(tmp)
    try:
        # ⚠ **곁다리 칸을 여기 손으로 적지 않는다** — `db_link_unify.COLUMNS` 에서
        #   만든다. 손으로 적었더니 칸을 하나 더한 날 selftest 가 스키마 불일치로
        #   터졌다(2026-08-24 `lemma_id`). 단일 소스를 따르게 한다.
        import db_link_unify as U
        extra = ', '.join('%s %s' % (c, t) for c, t, _w, _y in U.COLUMNS)
        d.execute("""CREATE TABLE sys_link_asset (
          sys_link_id INTEGER PRIMARY KEY AUTOINCREMENT,
          clicked_id INTEGER, target_id INTEGER, link_type TEXT, rel_code TEXT,
          sort_order INTEGER DEFAULT 1, record_status TEXT, origin_id INTEGER,
          end_id INTEGER, %s)""" % extra)
        d.execute("CREATE UNIQUE INDEX idx_sys_link_unq ON sys_link_asset"
                  "(link_type, clicked_id, target_id, rel_code)")
        d.execute("""CREATE TABLE sys_entity_compare (
          compare_id INTEGER PRIMARY KEY, entity_id INTEGER, other_id INTEGER,
          sort_order INTEGER, record_status TEXT)""")
        d.executemany("INSERT INTO sys_entity_compare VALUES (?,?,?,?,?)",
                      [(1, 10, 20, 1, 'LIVE'), (2, 10, 30, 2, None),
                       (3, 40, 50, 1, 'HIDE')])
        # 남의 연결 — 되돌리기가 이것을 건드리면 안 된다
        d.execute("INSERT INTO sys_link_asset (clicked_id, target_id, link_type) "
                  "VALUES (7,8,'VERS_VERS')")
        # ⚠⚠ 설명문 — 옛 PK 를 닻으로 삼는다. 옮길 때 따라와야 한다
        d.execute("""CREATE TABLE sys_text_asset (
          sys_text_id INTEGER PRIMARY KEY AUTOINCREMENT, clicked_id INTEGER,
          text_type TEXT, contents TEXT, lang_code TEXT, record_status TEXT)""")
        d.executemany("INSERT INTO sys_text_asset (clicked_id, text_type, contents,"
                      " lang_code) VALUES (?,?,?,?)",
                      [(1, 'ENTITY_COMPARE_DESC', '첫째 짝 설명', 'KO'),
                       (1, 'ENTITY_COMPARE_DESC', 'first pair', 'EN'),
                       (2, 'ENTITY_COMPARE_DESC', '둘째 짝 설명', 'KO'),
                       # 남의 글 — 닻이 옮겨지면 안 된다
                       (1, 'VERS_DESC', '창세기 1:1 설명', 'KO')])
        d.execute(LOG_DDL.replace('main.', ''))
        d.execute(DESC_DDL.replace('main.', ''))
        d.commit()

        base = d.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
        t('처음엔 남의 연결 하나뿐', base == 1, base)

        # ① 규칙이 행을 바르게 만드나
        rows = _entity_compare(d)
        t('세 행을 읽는다', len(rows) == 3, len(rows))
        t('빈 record_status 는 LIVE 로', rows[1][1]['record_status'] == 'LIVE')
        t('HIDE 는 그대로', rows[2][1]['record_status'] == 'HIDE')
        t('link_type 이 ENTI_ENTI', all(r[1]['link_type'] == 'ENTI_ENTI' for r in rows))

        # ② 옮긴다 — 실제 apply 를 쓴다(하네스가 따로 짜면 진짜를 안 잰다)
        ins, skip = apply(d, 'sys_entity_compare', verbose=False)
        t('세 행을 새로 넣었다', ins == 3, (ins, skip))
        n = d.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
        t('통합 표가 1 → 4', n == 4, n)
        got = d.execute("SELECT clicked_id, target_id, sort_order, record_status "
                        "FROM sys_link_asset WHERE link_type='ENTI_ENTI' "
                        "ORDER BY clicked_id, target_id").fetchall()
        t('값이 그대로 옮겨졌다',
          got == [(10, 20, 1, 'LIVE'), (10, 30, 2, 'LIVE'), (40, 50, 1, 'HIDE')], got)

        # ②-2 ★★ **설명문의 닻이 따라왔는가** — 빠뜨리면 조용히 미아가 된다
        new1 = d.execute("SELECT dst_id FROM %s WHERE src_table='sys_entity_compare' "
                         "AND src_id=1" % LOG).fetchone()[0]
        moved = d.execute("SELECT COUNT(*) FROM sys_text_asset "
                          "WHERE text_type='ENTITY_COMPARE_DESC' AND clicked_id=?",
                          (new1,)).fetchone()[0]
        t('설명문 두 편(KO·EN)이 새 닻으로 갔다', moved == 2, moved)
        t('옛 닻에는 안 남았다',
          d.execute("SELECT COUNT(*) FROM sys_text_asset WHERE "
                    "text_type='ENTITY_COMPARE_DESC' AND clicked_id=1").fetchone()[0] == 0)
        t('**남의 글은 안 건드렸다**',
          d.execute("SELECT clicked_id FROM sys_text_asset "
                    "WHERE text_type='VERS_DESC'").fetchone()[0] == 1)
        t('설명문 미아 0', orphan_desc(d, 'sys_entity_compare') == 0,
          orphan_desc(d, 'sys_entity_compare'))
        t('닻 이력이 세 편', d.execute("SELECT COUNT(*) FROM %s" % DESC_LOG)
          .fetchone()[0] == 3)

        # ③ 멱등 — 두 번 돌려도 안 는다
        ins2, _s = apply(d, 'sys_entity_compare', verbose=False)
        n2 = d.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
        t('두 번째는 새로 넣지 않는다', ins2 == 0, ins2)
        t('행 수가 안 는다', n2 == 4, n2)

        # ④ 되돌리기 — **남의 연결은 안 건드린다**
        gone = restore(d, 'sys_entity_compare', verbose=False)
        n3 = d.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
        t('세 행을 지웠다', gone == 3, gone)
        t('원래대로 하나 남았다', n3 == 1, n3)
        t('남은 것이 남의 연결이다',
          d.execute("SELECT clicked_id, target_id FROM sys_link_asset").fetchone()
          == (7, 8))
        t('이력도 비었다',
          d.execute("SELECT COUNT(*) FROM %s" % LOG).fetchone()[0] == 0)
        t('옛 표는 그대로 있다',
          d.execute("SELECT COUNT(*) FROM sys_entity_compare").fetchone()[0] == 3)
        # ★ 설명문도 옛 닻으로 돌아왔는가
        t('설명문 닻이 옛 번호로 돌아왔다',
          d.execute("SELECT COUNT(*) FROM sys_text_asset WHERE "
                    "text_type='ENTITY_COMPARE_DESC' AND clicked_id=1").fetchone()[0] == 2)
        t('닻 이력도 비었다',
          d.execute("SELECT COUNT(*) FROM %s" % DESC_LOG).fetchone()[0] == 0)
        t('되돌린 뒤에도 남의 글 그대로',
          d.execute("SELECT clicked_id FROM sys_text_asset "
                    "WHERE text_type='VERS_DESC'").fetchone()[0] == 1)

        # ⑤ 되돌리기 탐지력 — 이력이 없으면 아무것도 안 지운다
        gone2 = restore(d, 'sys_entity_compare', verbose=False)
        t('빈 이력으로는 안 지운다', gone2 == 0
          and d.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0] == 1)

        # ⑥ 중복 접기 — 같은 짝을 두 표가 가리키면 한 행만 남는다
        apply(d, 'sys_entity_compare', verbose=False)
        before = d.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
        d.execute("INSERT INTO %s (src_table, src_id, dst_schema, dst_id, moved_at) "
                  "SELECT 'other_table', 99, 'main', dst_id, 'x' FROM %s "
                  "WHERE src_table='sys_entity_compare' LIMIT 1" % (LOG, LOG))
        g3 = restore(d, 'sys_entity_compare', verbose=False)
        after = d.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
        t('남이 가리키는 행은 안 지운다', g3 == 2 and after == before - 2, (g3, before, after))

        # ⑦ 갈래 표에 없는 값은 조용히 사라지지 않는다 — `check` 가 센다
        d.execute("""CREATE TABLE sys_tag_link (
          link_id INTEGER PRIMARY KEY, sys_tag_id INTEGER, target_type TEXT,
          target_id INTEGER, record_status TEXT)""")
        d.executemany("INSERT INTO sys_tag_link VALUES (?,?,?,?,?)",
                      [(1, 5, 'BOOK_UNIT', 100, 'LIVE'),
                       (2, 5, '모르는것', 200, 'LIVE')])
        d.commit()
        got = _tag_link(d)
        t('모르는 갈래는 안 옮긴다', len(got) == 1, len(got))
        t('옮기는 것은 TAG_BUNT', got[0][1]['link_type'] == 'TAG_BUNT')
    finally:
        d.close()
        for e in ('', '-wal', '-shm'):
            if os.path.exists(tmp + e):
                os.remove(tmp + e)

    # ⑧ 진짜 DB — `check` 는 아무것도 안 만든다
    conn = appdb.connect()
    try:
        ensure_log(conn)
        n0 = conn.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
        l0 = conn.execute("SELECT COUNT(*) FROM %s" % LOG).fetchone()[0]
        for s in SPECS[:6]:
            check(conn, s.key, verbose=False)
        n1 = conn.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
        l1 = conn.execute("SELECT COUNT(*) FROM %s" % LOG).fetchone()[0]
        t('check 는 통합 표를 안 건드린다', n0 == n1, (n0, n1))
        t('check 는 이력을 안 건드린다', l0 == l1, (l0, l1))
        t('옮기지 않는 표가 등록부에 없다',
          not (set(SKIP) & set(BY_KEY)), sorted(set(SKIP) & set(BY_KEY)))
    finally:
        conn.close()

    print('selftest %d/%d' % (ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a or not a:
        sys.exit(0 if selftest() else 1)
    names = [x for x in a if not x.startswith('--')]
    c = appdb.connect()
    try:
        if '--status' in a:
            status(c)
        elif '--check' in a:
            keys = [s.key for s in SPECS] if (not names or 'all' in names) else names
            for k in keys:
                if k in BY_KEY:
                    check(c, k)
                else:
                    print('  ⚠ 모르는 표: %s' % k)
        elif '--apply' in a:
            if not names:
                print('어느 표를 옮길지 적어라 (--status 로 목록)'); sys.exit(1)
            for k in names:
                if k in BY_KEY:
                    check(c, k); apply(c, k)
                else:
                    print('  ⚠ 모르는 표: %s (%s)' % (k, SKIP.get(k, '등록부에 없다')))
            status(c)
        elif '--restore' in a:
            for k in names:
                restore(c, k)
            status(c)
        else:
            status(c)
    finally:
        c.close()
