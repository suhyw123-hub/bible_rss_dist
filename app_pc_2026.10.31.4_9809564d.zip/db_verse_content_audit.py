# -*- coding: utf-8 -*-
"""역본 간 '같은 약명 다른 내용' 전수 탐지기 (영구 도구).

문제(사용자 제기 2026-07-27): 이 DB 는 모든 역본이 **같은 verse_id 슬롯**을 공유한다.
  그래서 절체계가 어긋나도 구조적 갭으로 드러나지 않고 **내용 불일치**로만 나타난다.
  대상 5:4 를 클릭했을 때 역본마다 다른 내용이 뜨면, 그 절에 붙인 설명문이 통째로 무의미해진다.

탐지 원리 — 고유명사 지문(fingerprint):
  같은 언어(영어) 역본들은 철자가 달라도(Reaia/Reaiah, Tilgath-pilneser/Tiglath-pileser)
  **같은 인물·지명을 가리킨다**. 이름을 정규화(소문자·비문자 제거·앞 4글자)해 집합으로 만들고
  역본 간 자카드 유사도를 재면, 내용이 밀린 절은 지문이 급격히 어긋난다.
  족보·인구조사처럼 고유명사가 빽빽한 구간에서 특히 민감하다 — 사용자가 지목한 위험 구간과 일치.

판정 기준(실측으로 조정):
  - 이름 **3개 이상** 보유 절만 대상. 2개짜리는 한 역본이 대명사를 쓰면 자카드가 0.33 으로 떨어져
    대량 오탐이 난다(출18:5·민16:43·삼상17:33 등 전부 정렬돼 있는데 걸렸다).
  - 같은 자리 자카드 < 0.20 **이면서** 이웃 자리 >= 0.60 이고 차이가 0.40 이상일 때만 보고.
  - 역대상(족보 최다 구간) 오탐 0 을 기준선으로 삼아 조정했다.

한계(정직하게):
  - 고유명사가 없는 절(교리 서술·시가)은 이 방법으로 판별되지 않는다. 그 구간은 절길이 상관으로 별도 점검.
  - 영어권 4역본 사이만 직접 비교 가능. 한국어·중국어 등은 음역이라 문자 공유가 없어
    이 지문법이 안 통한다(별도 레이어 필요 — --lenprof 참조).

용법:
  python -X utf8 db_verse_content_audit.py                 # 전권 스캔(영어 4역본)
  python -X utf8 db_verse_content_audit.py --book 13       # 특정 책만
  python -X utf8 db_verse_content_audit.py --th 0.5        # 임계 조정
  python -X utf8 db_verse_content_audit.py --lenprof       # 절길이 프로파일 이상치(전 역본)
"""
import os, re, sqlite3, statistics, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(ROOT, 'bible_master.db')

EN_VERSIONS = ['KJV', 'ASV', 'WEB', 'BSB']

# 문장 첫 단어·일반 대문자어를 걸러내기 위한 불용어
STOP = set('''the and of a an in on at to for with from by but or nor so yet
now then when where who whom whose which that this these those there here
he she it they we you i his her its their our your my me him them us
was were is are be been being am do does did done have has had
not no all any some many much more most other another same such own
lord god israel jesus christ spirit son sons father mother king kings
behold thus therefore because also even indeed surely verily
yahweh jehovah yah adonai almighty most high holy one
shall should will would may might can could must let let's
oh ah woe alas yes amen selah how why what
sir madam teacher master rabbi lord's god's'''.split())
# 앞 4글자 절단 후 형태로도 걸러야 하는 것들(신명 표기 변이·인용 뒤 첫 단어)
STOP4 = set('''yahw jeho adon almi shal shou will woul must lets sela
don wont cant isnt arent wasnt werent didnt doesnt hasnt havent
behold surely truly indeed there here'''.split())

WORD = re.compile(r"[A-Za-z][A-Za-z'\-]*")


def names(txt):
    """고유명사 지문 집합. 대문자로 시작하되 문장 첫 단어/불용어 제외, 앞 4글자로 정규화."""
    out = set()
    if not txt:
        return out
    # 문장 경계 뒤 첫 단어는 대문자여도 고유명사가 아닐 수 있으므로 표시
    # 인용부호·괄호도 문장 경계로 취급(따옴표 뒤 첫 단어가 대문자라 오탐을 만든다)
    for sent in re.split(r'(?<=[.;:!?])\s+|[“”‘’"()]', txt):
        toks = WORD.findall(sent)
        for i, w in enumerate(toks):
            if not w[0].isupper():
                continue
            low = re.sub(r"[^a-z]", '', w.lower())
            if len(low) < 3 or low in STOP:
                continue
            if low[:4] in STOP4:
                continue
            if i == 0 and len(toks) > 1:
                continue          # 문장 첫 단어는 버린다
            out.add(low[:4])
    return out


def jaccard(a, b):
    if not a and not b:
        return 1.0
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def arg(name, default=None, cast=str):
    if name in sys.argv:
        i = sys.argv.index(name)
        if i + 1 < len(sys.argv):
            return cast(sys.argv[i + 1])
    return default


def scan_names(c, book=None, th=0.20, minimum=3):
    """역본 간 **절 밀림** 탐지.

    핵심: 같은 슬롯에서 지문이 안 맞는 것만으로는 부족하다(Jehovah/Yahweh, Zidon/Sidon 같은
    번역 변이가 대량 오탐을 만든다). 진짜 밀림의 지문은 따로 있다 —
      **A 역본 N 절의 이름이 B 역본의 N±1 절에 있다.**
    같은 자리에서 안 맞으면서 이웃 자리와는 맞으면, 그 역본은 그 지점에서 한 칸 밀려 있다.
    번역 변이는 이웃과도 안 맞으므로 자동으로 걸러진다.
    """
    where = 'WHERE b.bcode=?' if book else ''
    params = (book,) if book else ()
    rows = c.execute(f"""SELECT b.verse_id, b.bcode, b.chapter, b.verse
                         FROM bible_index b {where} ORDER BY b.verse_id""", params).fetchall()

    # 절 지문을 한 번에 적재(이웃 조회를 위해)
    fp = {}
    for vid, bc, ch, vs in rows:
        d = {}
        for vc, t in c.execute(
                "SELECT version_code, verse_text FROM bible_content "
                "WHERE verse_id=? AND version_code IN ('KJV','ASV','WEB','BSB')", (vid,)):
            d[vc] = names(t)
        fp[vid] = d
    order = [r[0] for r in rows]
    idx = {v: i for i, v in enumerate(order)}
    meta = {r[0]: (r[1], r[2], r[3]) for r in rows}

    hits = []
    for vid in order:
        d = fp[vid]
        rich = {vc: s2 for vc, s2 in d.items() if len(s2) >= minimum}
        if len(rich) < 2:
            continue
        i = idx[vid]
        for a in sorted(rich):
            for b in sorted(rich):
                if a >= b:
                    continue
                same = jaccard(rich[a], rich[b])
                if same >= th:
                    continue
                # 이웃 검사: a 의 지문이 b 의 앞/뒤 절과 더 잘 맞는가
                best = 0.0; off = 0
                for k in (-2, -1, 1, 2):
                    j = i + k
                    if j < 0 or j >= len(order):
                        continue
                    nb = fp[order[j]].get(b)
                    if not nb or len(nb) < minimum:
                        continue
                    # 같은 장 안에서만(장 경계를 넘는 이동은 별도 사안)
                    if meta[order[j]][0] != meta[vid][0]:
                        continue
                    r = jaccard(rich[a], nb)
                    if r > best:
                        best = r; off = k
                if best >= 0.60 and best > same + 0.40:
                    hits.append((vid, meta[vid][0], meta[vid][1], meta[vid][2],
                                 a, b, same, best, off, rich[a], rich[b]))
    return hits


def scan_lenprof(c, book=None, z=3.0):
    """절길이 프로파일 이상치 — 고유명사가 없는 구간용 보조 레이어.

    같은 절 슬롯에서 각 역본의 (그 역본 전체 평균 대비) 상대 길이를 구해,
    한 역본만 크게 벗어나면 그 역본이 그 자리에서 다른 내용을 담고 있을 수 있다.
    """
    vers = [r[0] for r in c.execute(
        "SELECT version_code FROM bible_content GROUP BY version_code HAVING COUNT(*)>30000")]
    mean = {}
    for v in vers:
        mean[v] = c.execute("SELECT AVG(LENGTH(verse_text)) FROM bible_content WHERE version_code=?", (v,)).fetchone()[0]
    where = 'WHERE b.bcode=?' if book else ''
    params = (book,) if book else ()
    rows = c.execute(f"SELECT b.verse_id,b.bcode,b.chapter,b.verse FROM bible_index b {where} ORDER BY b.verse_id", params).fetchall()
    hits = []
    for vid, bc, ch, vs in rows:
        rel = {}
        for v, t in c.execute("SELECT version_code, verse_text FROM bible_content WHERE verse_id=?", (vid,)):
            if v in mean and t and len(t) > 3:
                rel[v] = len(t) / mean[v]
        if len(rel) < 6:
            continue
        vals = list(rel.values())
        med = statistics.median(vals)
        if med <= 0:
            continue
        out = [(v, r / med) for v, r in rel.items() if r / med > z or r / med < 1 / z]
        if out:
            hits.append((vid, bc, ch, vs, med, out))
    return hits


def main():
    try: sys.stdout.reconfigure(encoding='utf-8')
    except Exception: pass
    conn = sqlite3.connect(DB, timeout=60); c = conn.cursor()
    book = arg('--book', None, int)
    th = arg('--th', 0.20, float)

    bn = {b: n for b, n in c.execute("SELECT book_code, short_name FROM book_names WHERE lang_code='KO'")}

    if '--lenprof' in sys.argv:
        hits = scan_lenprof(c, book)
        print(f'절길이 프로파일 이상치 {len(hits)}건 (한 역본만 중앙값 대비 3배 이상 벗어남)')
        for vid, bc, ch, vs, med, out in hits[:60]:
            o = ', '.join(f'{v}={r:.1f}x' for v, r in out)
            print(f'  {bn.get(bc,bc)} {ch}:{vs} (vid {vid})  {o}')
        return 0

    hits = scan_names(c, book, th)
    print(f'★ 절 밀림 의심 {len(hits)}건 (같은 자리 불일치 + 이웃 자리 일치)')
    from collections import Counter
    per = Counter(bn.get(h[1], h[1]) for h in hits)
    for b, n in per.most_common(25):
        print(f'  {b}: {n}건')
    print()
    for vid, bc, ch, vs, a, b, same, best, off, na, nb in sorted(hits, key=lambda x: -x[7])[:60]:
        print(f'  {bn.get(bc,bc)} {ch}:{vs} (vid {vid})  {a} vs {b}: 같은자리 {same:.2f} / {off:+d}칸 {best:.2f}')
        print(f'      {a}: {sorted(na)}')
        print(f'      {b}: {sorted(nb)}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
