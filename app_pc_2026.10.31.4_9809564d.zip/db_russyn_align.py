# -*- coding: utf-8 -*-
"""db_russyn_align.py — RusSyn(시노드역 1876) 절체계 재정렬 (영구 도구)

★★★ 무엇을 고치나
  담을 때 **시노드 번호를 우리 마소라 슬롯에 그대로 부었다.** 시편은 번호
  체계가 슬라브-70인역이라 **106편이 다른 편 내용을 보이고**, 슬롯보다 긴 편은
  **뒤가 잘려 786절이 사라졌다**. 원본을 다시 받아 **대응표대로 옮겨 담는다**.

★★★ 왜 확률이 아니라 확정인가 — 잣대 넷이 모두 통과해야 쓴다
  ① **원본 동일성** — 지금 담긴 30,319절이 받은 원본과 **글자 그대로 같다**
     (실측 100.00%). 같은 판이고 우리 파이프라인도 옳았다.
  ② **산술** — 시노드 S편 절 수 = 그 편이 담은 마소라 절 수 + 표제 절 수(0~2).
     0~2 밖이면 안쪽에 병합·분할이 있다는 뜻이라 **손대지 않는다**.
  ③ **표제 두 신호** — 표제라 주장하는 첫 줄에 시노드 표제 상투어가 있고,
     **개역한글 그 편 1절에 `{…}` 표제**가 있어야 한다.
  ④ **이름 닻** — 고유명사는 번역되지 않고 **음역**된다(Сион↔Zion). 정한
     자리의 러시아어 이름이 같은 자리 영어에도 있어야 한다.
     ⚠ **어긋남은 「이웃 절(±1,±2)에는 있는데 제자리에만 없을 때」만**이다 —
       아무 데도 없으면 70인역↔마소라 번역 차이지 밀림이 아니다.
     ⚠⚠ **길이 상관은 잣대에서 뺐다** — 시가에서는 안 듣는다(시136 은 후렴이라
       모든 절 길이가 같다). 실측 다섯 편이 **내용은 완벽한데** 상관만 낮아
       거짓 반려됐다. 이름이 없는 편에서만 **보조**로 쓴다(으뜸인가만 본다).
  ⑤ **글자 확인** — 이름도 없고 상관 으뜸도 아닌 편은 사람이 본문을 읽어
     확인한 것만 `PSA_VERIFIED` 에 적고 그 편만 통과시킨다.
  ⇒ 하나라도 못 넘으면 **그 편은 건너뛰고 까닭과 함께 보고**한다.

★ 시편 밖은 **닻 구간**으로 푼다 — 이미 글자까지 맞는 장은 움직일 수 없는
  못이고, 못과 못 사이에서 **슬롯 수 == 원본 절 수**이면 읽기 순서 1:1 밖에
  다른 답이 없다(§18-8 이 FreLSG 에서 증명한 방법).

★ **절 수가 진짜로 다른 15장은 `CHAP_FIX` 표**로 푼다 — 원본과 KJV 를 **나란히
  읽어 확정한 것**이고 근거를 표 옆에 적었다. 짐작으로 채운 자리는 하나도 없다.
  차이는 네 가지뿐이었다 — ⓐ 시노드가 두 절을 합쳤다 ⓑ 한 절을 둘로 쪼갰다
  ⓒ **70인역 추가절**(대괄호 · 마소라에 자리가 없다) ⓓ **장 경계가 다르다**.
⚠ 표에 없는 장은 여전히 안 건드린다 — 짐작은 이 도구가 하지 않는다.

쓰는 법
  python -X utf8 db_russyn_align.py --selftest
  python -X utf8 db_russyn_align.py --check      # 계획과 잣대만 (DB 무변경)
  python -X utf8 db_russyn_align.py --apply
  python -X utf8 db_russyn_align.py --undo
"""
import json
import os
import re
import sys
import unicodedata as ud

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import appdb                                                   # noqa: E402

VER = 'RusSyn'
PSA = 19
RAW = os.path.join(HERE, '_russyn_raw', 'synodal.json')
SRC_URL = 'https://api.getbible.net/v2/synodal.json'
BAK = 'temp_russyn_align_backup'
#: ⚠⚠⚠ **이 역본은 `versification_system='MANUAL'` 이라 `--all` 전수 검사에서
#:   통째로 빠져 있었다**(검사기가 `='MT'` 인 것만 돈다). 시편이 106편 어긋난 채
#:   오래 안 잡힌 구조적 까닭 하나가 이것이다. 정렬을 끝냈으므로 **MT 로 적는다**
#:   — 담긴 글이 실제로 마소라 자리에 있으니 사실이기도 하다.
#:   ⚠ 백업 표에 옛 값을 함께 두어 `--undo` 가 되돌린다(자리표 verse_id).
VSYS_ROW = -1

#: 시노드 표제 상투어 — 그 줄이 표제인지 재는 **독립 신호**
TITLE_RX = re.compile(
    r'Начальник|Псалом|Песнь|Учение|Молитва|Давид|Асаф|Кореев|Соломон|Моисе|'
    r'Аллилуия|восхождения|Плач|Хвала|столпописание|Идифум|хора', re.I)

#: 절이 이보다 적으면 상관을 못 잰다(짧은 편)
CORR_MIN_N = 6
#: 이름이 없는 편의 보조 잣대 — 견줄 역본 다섯 가운데 몇에서 제자리가 으뜸이어야 하나
CORR_WINS = 3
#: 견주는 역본 — 한 역본만 보면 그 역본의 번역 습관에 끌린다
REF_VERSIONS = ('KJV', 'KRV', 'BSB', 'GerElb', 'PorBL')

#: 러시아어 어간 → 영어 어간. **손으로 고른 표**다(자동 추출은 러시아어 존칭
#:  대문자(Господа·Его·Тебе)와 문장 첫 낱말이 쏟아져 4맞음/28안맞음이었다).
#:  ⚠ 짧아서 헷갈리는 이름(Ог·Хам)은 **일부러 뺐다**.
NAMES = (
    ('Сион', 'Zion'), ('Иаков', 'Jacob'), ('Израил', 'Israel'),
    ('Иерусалим', 'Jerusalem'), ('Иуд', 'Jud'), ('Ефрем', 'Ephraim'),
    ('Манасси', 'Manasseh'), ('Вениамин', 'Benjamin'), ('Завулон', 'Zebulun'),
    ('Неффалим', 'Naphtali'), ('Моав', 'Moab'), ('Едом', 'Edom'),
    ('Египт', 'Egypt'), ('Вавилон', 'Babylon'), ('Давид', 'David'),
    ('Аарон', 'Aaron'), ('Моисе', 'Moses'), ('Соломон', 'Solomon'),
    ('Ливан', 'Lebanon'), ('Иордан', 'Jordan'), ('Синай', 'Sinai'),
    ('Васан', 'Bashan'), ('Филистим', 'Philist'), ('Авраам', 'Abraham'),
    ('Исаак', 'Isaac'), ('Ханаан', 'Canaan'), ('Асаф', 'Asaph'),
    ('Коре', 'Korah'), ('Мелхиседек', 'Melchizedek'), ('Иосиф', 'Joseph'),
    ('Ассур', 'Assur'), ('Амалик', 'Amalek'), ('Аммон', 'Ammon'),
    ('Агарян', 'Hagar'), ('Гевал', 'Gebal'), ('Сигон', 'Sihon'),
    ('Мадиам', 'Midian'), ('Сисар', 'Sisera'), ('Иавин', 'Jabin'),
    ('Аендор', 'Endor'), ('Орив', 'Oreb'), ('Зив', 'Zeeb'),
    ('Зеве', 'Zebah'), ('Салман', 'Zalmunna'), ('Раав', 'Rahab'),
    ('Ефрафа', 'Ephratah'), ('Ермон', 'Hermon'), ('Кармил', 'Carmel'),
    ('Иессе', 'Jesse'), ('Самуил', 'Samuel'), ('Саул', 'Saul'),
    ('Авессалом', 'Absalom'), ('Сихем', 'Shechem'), ('Сокхоф', 'Succoth'),
    ('Галаад', 'Gilead'), ('Силом', 'Shiloh'), ('Мерив', 'Meribah'),
    ('Масс', 'Massah'), ('Ной', 'Noah'), ('Левиафан', 'leviathan'),
    ('Ефиоп', 'Ethiopia'), ('Цоан', 'Zoan'), ('Кедар', 'Kedar'),
    ('Мосох', 'Mesech'), ('Иеровоам', 'Jeroboam'), ('Есевон', 'Heshbon'),
    ('Аморре', 'Amorite'), ('Хеврон', 'Hebron'), ('Гоморр', 'Gomorrah'),
    ('Содом', 'Sodom'), ('Ассири', 'Assyria'), ('Финее', 'Phinehas'),
    ('Дафан', 'Dathan'), ('Авирон', 'Abiram'), ('Хорив', 'Horeb'),
)

#: 영어 쪽 철자 변이 — KJV 가 다른 이름을 쓰는 자리
EN_ALT = {'zion': ('sion',), 'jud': ('juda',), 'meribah': ('strife',),
          'massah': ('temptation',)}

#: ⑤ **사람이 본문을 읽어 확인한 편** — 이름도 없고 상관 으뜸도 아니라
#:   기계 잣대로는 못 받치는 자리다. 짐작이 아니라 **첫 절을 나란히 읽은 것**이다.
#:   ⚠ 여기에 편을 더할 때는 **반드시 본문을 눈으로 보고** 근거를 함께 적는다.
PSA_VERIFIED = {
    14: '15:1 «кто может пребывать в жилище Твоем» = who shall abide in thy tabernacle',
    42: '43:1 «Суди меня, Боже» = Judge me, O God',
    57: '58:1 «Подлинно ли правду говорите вы» = Do ye indeed speak righteousness',
    69: '70:1 «Поспеши, Боже, избавить меня» = Make haste, O God, to deliver me',
    92: '93:1 «Господь царствует; Он облечен величием» = The LORD reigneth, clothed with majesty',
    99: '100:1 «Воскликните Господу, вся земля» = Make a joyful noise unto the LORD, all ye lands',
    114: '116:1 «Я радуюсь, что Господь услышал голос мой» = I love the LORD, because he hath heard my voice',
    116: '117:1 «Хвалите Господа, все народы» = O praise the LORD, all ye nations',
    122: '123:1 «К Тебе возвожу очи мои» = Unto thee lift I up mine eyes',
    126: '127:1 «Если Господь не созиждет дома» = Except the LORD build the house',
}


# ── 고르기 ────────────────────────────────────────────────────────────
def norm(s):
    """대조용 — 공백과 강세 기호만 접는다(글자는 안 건드린다)."""
    s = ud.normalize('NFC', s or '').replace('́', '')
    return re.sub(r'\s+', ' ', s).strip()


def corr(a, b):
    n = min(len(a), len(b))
    if n < CORR_MIN_N:
        return None
    a, b = a[:n], b[:n]
    ma, mb = sum(a) / n, sum(b) / n
    num = sum((a[i] - ma) * (b[i] - mb) for i in range(n))
    da = sum((x - ma) ** 2 for x in a) ** .5
    db = sum((x - mb) ** 2 for x in b) ** .5
    return num / (da * db) if da and db else None


def ru_hits(t):
    """러시아어 글에 들어 있는 고유명사 → 영어 어간 집합."""
    t = t or ''
    return {en for ru, en in NAMES if ru in t}


def en_has(t, en):
    """영어 쪽에 그 이름이 있는가 — 대시·아포스트로피·철자 변이를 접는다.

    ⚠ KJV 는 `En–dor`(en대시)처럼 적는 자리가 있어 접지 않으면 거짓 어긋남이 난다.
    """
    x = (t or '').lower()
    for ch in ('\u2013', '\u2014', '-', '\u2019', "'"):
        x = x.replace(ch, '')
    e = en.lower().replace('-', '')
    if e in x:
        return True
    return any(a in x for a in EN_ALT.get(e, ()))


def name_clashes(rows, kjv):
    """`rows` 배치에서 **이름이 어긋난 자리** 목록과 닻 개수.

    ★★★ 판정 규칙 — **이웃 절(±1,±2)에는 있는데 제자리에만 없을 때만** 어긋남이다.
      아무 데도 없으면 70인역↔마소라 번역 차이거나 KJV 가 표제를 절 본문에
      안 넣은 것이라 **밀림의 증거가 아니다**(이 규칙으로 216/216 이 맞았다).
    """
    bad, n = [], 0
    for (ch, vs), t in rows:
        for h in ru_hits(t):
            n += 1
            if en_has(kjv.get((ch, vs), ''), h):
                continue
            if any(en_has(kjv.get((ch, vs + d), ''), h)
                   for d in (-2, -1, 1, 2)):
                bad.append('%d:%d %s' % (ch, vs, h))
    return bad, n


# ── 원본 ──────────────────────────────────────────────────────────────
def load_src(path=None):
    """받아 둔 시노드 원본 → `{bcode: {chapter: [글, …]}}`(정경 66권만)."""
    p = path or RAW
    if not os.path.exists(p):
        raise SystemExit(
            '원본이 없다 — 먼저 받는다(§0-1b ⓪ 링크를 보이고 확인받은 뒤):\n'
            '  %s  →  %s' % (SRC_URL, p))
    d = json.load(open(p, encoding='utf-8'))
    out = {}
    for b in d['books']:
        nr = int(b['nr'])
        if nr > 66:
            continue                      # 외경은 담지 않는다
        out[nr] = {int(x['chapter']): [v['text'] for v in x['verses']]
                   for x in b['chapters']}
    return out


# ── 시편 편 대응 ──────────────────────────────────────────────────────
def syn_to_mt(s, mtlen):
    """시노드 S편 → 마소라 `[(장, 시작절, 끝절)]`. 표준 슬라브-70인역 대응.

    ⚠ 시노드 114/115 의 가르는 자리는 **이 판을 실제로 읽고** 정했다 —
      S114 8절 · S115 10절이고 S114 마지막이 마소라 116:8+9 를 함께 담는다.
    """
    if s <= 8 or s >= 148:
        return [(s, 1, mtlen[s])]
    if s == 9:
        return [(9, 1, mtlen[9]), (10, 1, mtlen[10])]
    if 10 <= s <= 112:
        return [(s + 1, 1, mtlen[s + 1])]
    if s == 113:
        return [(114, 1, mtlen[114]), (115, 1, mtlen[115])]
    if s == 114:
        return [(116, 1, 9)]
    if s == 115:
        return [(116, 10, mtlen[116])]
    if 116 <= s <= 145:
        return [(s + 1, 1, mtlen[s + 1])]
    if s == 146:
        return [(147, 1, 11)]
    return [(147, 12, mtlen[147])]        # 147


#: 안쪽 병합을 **글자로 확인해** 못 박은 자리 — (시노드 편, 원본 절) → 합쳐진 마소라 절
#:  ⚠ 지어낸 것이 아니라 본문을 읽고 확정한 것이다(S114 마지막 줄이
#:    「…от преткновения. Буду ходить пред лицем Господним…」로 116:8+9 를 함께 담는다).
PSA_MERGE = {(114, 8): (116, 8, 9)}


#: 슬롯에 그 역본의 절이 **아예 없을 때** 적는 표식 — `verse_text` 가 ABSENT 로 읽는다
ABSENT_MARK = '<없음>'
#: `<병합 N:M>` 표식 — `verse_text._RX_MERGE_TAG` 와 같은 꼴
_RX_MERGE = re.compile(r'^<병합\s*\d+:\d+\s*>\s*')

#: ★★★ 절체계가 진짜로 다른 15장 — **원본과 KJV 를 나란히 읽어 확정한 대응표**
#:   갈래 넷 —
#:     SEQ  원본 a~z 를 그 슬롯부터 차례대로
#:     M2   원본 한 절 = 슬롯 두 칸(시노드가 **합쳤다**) — 뒤 칸에 `<병합>` 표기
#:     J2   원본 두 절 = 슬롯 한 칸(시노드가 **쪼갰다**) — 이어 붙인다
#:     DROP **70인역 추가절** — 마소라에 자리가 없다(대괄호로 표시된 줄들)
#:     NONE 슬롯은 있는데 이 역본에 그 절이 없다 — 「이 역본에 없음」으로 적는다
#:   ⚠ **여기에 줄을 더할 때는 반드시 본문을 읽고** 근거를 주석으로 남긴다.
CHAP_FIX = {
    # 레14 — RU55 가 KJV 55(옷과 집의 문둥병)+56(부은 것·피부병·색점)을 함께 담는다
    (3, 14): [(1, 54, 'SEQ', (14, 1)), (55, 55, 'M2', (14, 55)),
              (56, 56, 'SEQ', (14, 57))],
    # 수24 — RU33 = KJV 24:33(엘르아살의 죽음). RU34~36 은 대괄호 70인역 추가
    (6, 24): [(1, 33, 'SEQ', (24, 1)), (34, 36, 'DROP', None)],
    # 삼상20 — KJV 20:42 뒷부분(「And he arose and departed…」)이 RU43 이다
    (9, 20): [(1, 41, 'SEQ', (20, 1)), (42, 43, 'J2', (20, 42))],
    # 잠4 — RU28·29 는 대괄호 70인역 추가(「пути правые наблюдает Господь…」)
    (20, 4): [(1, 27, 'SEQ', (4, 1)), (28, 29, 'DROP', None)],
    # 잠13 — RU14 가 대괄호 추가절(「У сына лукавого ничего нет доброго…」)
    (20, 13): [(1, 13, 'SEQ', (13, 1)), (14, 14, 'DROP', None),
               (15, 26, 'SEQ', (13, 14))],
    # 잠18 — RU8 이 대괄호 추가절(「Ленивого низлагает страх…」)
    (20, 18): [(1, 7, 'SEQ', (18, 1)), (8, 8, 'DROP', None),
               (9, 25, 'SEQ', (18, 8))],
    # 아1 — RU1 이 KJV 1:2(「Да лобзает он меня」=Let him kiss me)다.
    #        표제(KJV 1:1)는 이 판에서 절 번호를 갖지 않는다
    (22, 1): [(1, 16, 'SEQ', (1, 2)), (0, 0, 'NONE', (1, 1))],
    # 아6~7 — **장 경계가 다르다**. 시노드 6장은 12절로 끝나고 KJV 6:13 이
    #          시노드 7:1 이다. 슬롯 6:14 는 개역한글 전용 이형이라 비운다
    (22, 6): [(1, 12, 'SEQ', (6, 1)), (0, 0, 'NONE', (6, 14))],
    (22, 7): [(1, 1, 'SEQ', (6, 13)), (2, 14, 'SEQ', (7, 1))],
    # 사3 — RU19 가 KJV 19(사슬·팔찌·목걸이)+20(관·발목 사슬·띠·향합)을 함께 담는다
    (23, 3): [(1, 18, 'SEQ', (3, 1)), (19, 19, 'M2', (3, 19)),
              (20, 25, 'SEQ', (3, 21))],
    # 단3 — RU 3:24~90 은 **아사랴의 기도와 세 청년의 노래**(70인역 추가 67절).
    #        RU 3:91 = KJV 3:24 · RU 3:98~100 = KJV 4:1~3(느부갓네살의 조서)
    (27, 3): [(1, 23, 'SEQ', (3, 1)), (24, 90, 'DROP', None),
              (91, 97, 'SEQ', (3, 24)), (98, 100, 'SEQ', (4, 1))],
    # 단4 — RU 4:1(「Я, Навуходоносор, спокоен был」) = KJV 4:4
    (27, 4): [(1, 34, 'SEQ', (4, 4))],
    # 행19 — RU40 끝의 「Сказав это, он распустил собрание」이 KJV 19:41 이다
    (44, 19): [(1, 39, 'SEQ', (19, 1)), (40, 40, 'M2', (19, 40))],
    # 롬14 — RU 14:24~26 이 **송영**(KJV 16:25~27). 비잔틴 사본이 14장 끝에 둔다
    (45, 14): [(1, 23, 'SEQ', (14, 1)), (24, 26, 'SEQ', (16, 25))],
    (45, 16): [(1, 24, 'SEQ', (16, 1))],
    # 고후11 — RU32 끝의 「и я в корзине был спущен」이 KJV 11:33 이다
    (47, 11): [(1, 31, 'SEQ', (11, 1)), (32, 32, 'M2', (11, 32))],
    # 고후13 — RU12 가 KJV 12(거룩한 입맞춤)+13(모든 성도의 문안)을 함께 담는다
    (47, 13): [(1, 11, 'SEQ', (13, 1)), (12, 12, 'M2', (13, 12)),
               (13, 13, 'SEQ', (13, 14))],
}


def plan_chapters(conn, src):
    """`CHAP_FIX` 표대로 채운다 → `(plan, info, bad)`.

    ⚠ **원본 절을 하나도 남기지 않았는가**를 장마다 센다 — 표를 잘못 적으면
      조용히 몇 절이 사라지므로 그것을 흠으로 낸다.
    """
    plan, info, bad = {}, [], []
    for (b, ch), ops in sorted(CHAP_FIX.items()):
        sv = src.get(b, {}).get(ch) or []
        used = 0
        for a, z, kind, tgt in ops:
            if kind == 'NONE':
                plan[(b, tgt[0], tgt[1])] = ABSENT_MARK
                continue
            if z > len(sv):
                bad.append((b, ch, '표가 원본보다 길다(%d > %d)' % (z, len(sv))))
                break
            if kind == 'DROP':
                used += z - a + 1
                continue
            if kind == 'M2':
                t = sv[a - 1]
                plan[(b, tgt[0], tgt[1])] = t
                plan[(b, tgt[0], tgt[1] + 1)] = ('<병합 %d:%d> %s'
                                                % (tgt[0], tgt[1], t))
                used += 1
                continue
            if kind == 'J2':
                plan[(b, tgt[0], tgt[1])] = '%s %s' % (sv[a - 1].strip(),
                                                      sv[z - 1].strip())
                used += z - a + 1
                continue
            c0, v0 = tgt
            for i in range(a, z + 1):
                plan[(b, c0, v0 + i - a)] = sv[i - 1]
            used += z - a + 1
        if used != len(sv):
            bad.append((b, ch, '원본 절을 다 쓰지 못했다(%d / %d)'
                        % (used, len(sv))))
        info.append((b, ch, len(sv), used))
    return plan, info, bad


def slots_of(tgt):
    """`[(장,시작,끝)]` → `[(장, 절), …]` 납작하게."""
    out = []
    for ch, a, z in tgt:
        out += [(ch, v) for v in range(a, z + 1)]
    return out


# ── 시편 계획 ─────────────────────────────────────────────────────────
def plan_psalms(conn, src, log=None):
    """시편 재정렬 계획 → `(plan, okinfo, skipped)`.

    `plan` = `{(bcode, ch, vs): 글}` · `skipped` = `[(편, 까닭)]`
    """
    log = log or (lambda *a: None)
    mtlen = {ch: conn.execute(
        'SELECT COUNT(*) FROM bible_index WHERE bcode=? AND chapter=?',
        (PSA, ch)).fetchone()[0] for ch in range(1, 151)}
    krv1 = {}
    for ch, tx in conn.execute(
            '''SELECT bi.chapter, bc.verse_text FROM bible_index bi
               JOIN bible_content bc ON bc.verse_id=bi.verse_id
                 AND bc.version_code='KRV'
               WHERE bi.bcode=? AND bi.verse=1''', (PSA,)):
        krv1[ch] = tx or ''
    kjv = {}
    for ch, vs, tx in conn.execute(
            '''SELECT bi.chapter, bi.verse, bc.verse_text FROM bible_index bi
               JOIN bible_content bc ON bc.verse_id=bi.verse_id
                 AND bc.version_code='KJV' WHERE bi.bcode=?''', (PSA,)):
        kjv[(ch, vs)] = tx or ''
    reflen = {}
    for v in REF_VERSIONS:
        for ch, vs, tx in conn.execute(
                '''SELECT bi.chapter, bi.verse, bc.verse_text FROM bible_index bi
                   JOIN bible_content bc ON bc.verse_id=bi.verse_id
                     AND bc.version_code=? WHERE bi.bcode=?''', (v, PSA)):
            reflen[(v, ch, vs)] = len(tx or '')

    plan, info, skip = {}, [], []
    for s in range(1, 151):
        sv = src[PSA].get(s) or []
        tgt = syn_to_mt(s, mtlen)
        slots = slots_of(tgt)
        merges = {i: m for (ss, i), m in PSA_MERGE.items() if ss == s}
        need = len(slots) - sum(len(m) - 2 for m in merges.values())
        k = len(sv) - need
        # ② 산술
        if k < 0 or k > 2:
            skip.append((s, '산술이 0~2 밖 — 안쪽 병합·분할 (원본 %d · 슬롯 %d)'
                         % (len(sv), need)))
            continue
        # ③ 표제 두 신호
        if k >= 1:
            if not TITLE_RX.search(sv[0] or ''):
                skip.append((s, '표제라 주장한 첫 줄에 상투어가 없다'))
                continue
            if not (krv1.get(tgt[0][0], '').lstrip().startswith('{')):
                skip.append((s, '개역한글 1절에 {표제}가 없는데 표제 절이 있다 함'))
                continue
        # 자리 배치
        rows, si = [], k
        for (ch, vs) in slots:
            m = merges.get(si + 1)
            if m and m[1] == vs:                       # 합쳐진 앞 절
                rows.append(((ch, vs), sv[si]))
                continue
            if m and m[2] == vs:                       # 합쳐진 뒤 절
                rows.append(((ch, vs), '<병합 %d:%d> %s' % (ch, m[1], sv[si])))
                si += 1
                continue
            rows.append(((ch, vs), sv[si]))
            si += 1
        if si != len(sv):
            skip.append((s, '원본 절을 다 쓰지 못했다(%d / %d)' % (si, len(sv))))
            continue
        # ④ 이름 닻 → (없으면) 상관 으뜸 → (그도 아니면) 글자 확인
        bad, anc = name_clashes(rows, kjv)
        if bad:
            skip.append((s, '이름이 어긋난다 — %s' % ' · '.join(bad[:3])))
            continue
        if anc:
            note = '이름 닻 %d' % anc
        else:
            vl = [len(norm(t)) for _, t in rows]
            wins = 0
            for v in REF_VERSIONS:
                kl = [reflen.get((v, p[0], p[1]), 0) for p, _ in rows]
                c0 = corr(vl, kl)
                if c0 is None:
                    continue
                rivals = [x for x in (corr(vl[1:], kl[:-1]),
                                      corr(vl[:-1], kl[1:]))
                          if x is not None]
                if not rivals or c0 >= max(rivals):
                    wins += 1
            if wins >= CORR_WINS:
                note = '상관 으뜸 %d/%d' % (wins, len(REF_VERSIONS))
            elif s in PSA_VERIFIED:
                note = '글자 확인'
            else:
                skip.append((s, '이름 닻도 없고 상관 으뜸도 아니다(%d/%d) —'
                             ' 본문을 읽어 확인한 뒤 PSA_VERIFIED 에 적는다'
                             % (wins, len(REF_VERSIONS))))
                continue
        for p, t in rows:
            plan[(PSA, p[0], p[1])] = t
        info.append((s, k, len(rows), note))
        log('  시노드 %3d편 → %s · 표제 %d · %d절 %s'
            % (s, ' '.join('%d:%d-%d' % x for x in tgt), k, len(rows), note))
    return plan, info, skip


# ── 시편 밖: 닻 구간 ──────────────────────────────────────────────────
def plan_others(conn, src):
    """시편 밖 → `(plan, runs_ok, runs_bad)`.

    닻 = 절 수도 글자도 맞는 장(움직일 수 없다). 닻 사이 구간에서
    **슬롯 수 == 원본 절 수**이면 읽기 순서 1:1 로 결정된다.
    """
    slot, have = {}, {}
    for b, ch, vs in conn.execute(
            'SELECT bcode, chapter, verse FROM bible_index'
            ' ORDER BY bcode, chapter, verse'):
        slot.setdefault(b, {}).setdefault(ch, []).append(vs)
    for b, ch, vs, tx in conn.execute(
            '''SELECT bi.bcode, bi.chapter, bi.verse, bc.verse_text
               FROM bible_index bi JOIN bible_content bc
                 ON bc.verse_id=bi.verse_id AND bc.version_code=?''', (VER,)):
        have[(b, ch, vs)] = tx

    plan, good, bad = {}, [], []
    for b in range(1, 67):
        if b == PSA:
            continue
        chs = sorted(slot.get(b, {}))

        def anchored(ch):
            sv = src.get(b, {}).get(ch, [])
            ours = slot[b][ch]
            if len(sv) != len(ours):
                return False
            return all(norm(have.get((b, ch, v), '')) == norm(t)
                       for t, v in zip(sv, ours))

        flag = {ch: anchored(ch) for ch in chs}
        i = 0
        while i < len(chs):
            if flag[chs[i]]:
                i += 1
                continue
            j = i
            while j < len(chs) and not flag[chs[j]]:
                j += 1
            run = chs[i:j]
            ks = [(b, ch, v) for ch in run for v in slot[b][ch]]
            ts = [t for ch in run for t in src.get(b, {}).get(ch, [])]
            if len(ks) == len(ts):
                for k2, t in zip(ks, ts):
                    plan[k2] = t
                good.append((b, run[0], run[-1], len(ks)))
            else:
                bad.append((b, run[0], run[-1], len(ks), len(ts)))
            i = j
    return plan, good, bad


# ── 적용 ──────────────────────────────────────────────────────────────
def _vids(conn):
    return {(b, c2, v): i for i, b, c2, v in conn.execute(
        'SELECT verse_id, bcode, chapter, verse FROM bible_index')}


def apply(conn, plan):
    """계획을 쓴다 — **되돌릴 수 있게 옛 값을 먼저 뜬다**."""
    conn.execute('CREATE TABLE IF NOT EXISTS %s('
                 'verse_id INTEGER PRIMARY KEY, old_text TEXT)' % BAK)
    old_sys = conn.execute('SELECT versification_system FROM bible_version'
                           ' WHERE version_code=?', (VER,)).fetchone()
    if old_sys:
        conn.execute('INSERT OR IGNORE INTO %s(verse_id, old_text) VALUES(?,?)'
                     % BAK, (VSYS_ROW, old_sys[0]))
        conn.execute("UPDATE bible_version SET versification_system='MT'"
                     ' WHERE version_code=?', (VER,))
    vid = _vids(conn)
    n_new = n_upd = 0
    for (b, ch, vs), tx in plan.items():
        i = vid.get((b, ch, vs))
        if i is None:
            continue
        r = conn.execute('SELECT verse_text FROM bible_content'
                         ' WHERE verse_id=? AND version_code=?',
                         (i, VER)).fetchone()
        conn.execute('INSERT OR IGNORE INTO %s(verse_id, old_text) VALUES(?,?)'
                     % BAK, (i, r[0] if r else None))
        if r is None:
            conn.execute('INSERT INTO bible_content(verse_id, version_code,'
                         ' verse_text) VALUES(?,?,?)', (i, VER, tx))
            n_new += 1
        elif norm(r[0]) != norm(tx):
            conn.execute('UPDATE bible_content SET verse_text=?'
                         ' WHERE verse_id=? AND version_code=?', (tx, i, VER))
            n_upd += 1
    conn.commit()
    return n_new, n_upd


def undo(conn):
    """백업으로 되돌린다 — 없던 줄은 지우고 있던 줄은 옛 글로."""
    try:
        rows = conn.execute('SELECT verse_id, old_text FROM %s' % BAK).fetchall()
    except Exception:                                          # noqa: BLE001
        return 0
    n = 0
    for i, old in rows:
        if i == VSYS_ROW:                         # 절이 아니라 정렬 표시다
            conn.execute('UPDATE bible_version SET versification_system=?'
                         ' WHERE version_code=?', (old, VER))
            continue
        if old is None:
            conn.execute('DELETE FROM bible_content'
                         ' WHERE verse_id=? AND version_code=?', (i, VER))
        else:
            conn.execute('UPDATE bible_content SET verse_text=?'
                         ' WHERE verse_id=? AND version_code=?', (old, i, VER))
        n += 1
    conn.execute('DROP TABLE %s' % BAK)
    conn.commit()
    return n


# ── 원본 동일성(잣대 ①) ───────────────────────────────────────────────
def source_identity(conn, src):
    """지금 담긴 글이 원본과 **글자 그대로 같은가** → `(같음, 다름)`.

    ⚠⚠⚠ **번호 자리로 견주면 안 된다** — 재정렬을 하고 나면 같은 판인데도
      「다르다」가 쏟아진다(실측 1,843줄. 옛 판정이 그랬고 거짓 경보였다).
      묻는 것은 「**같은 판인가**」이지 「같은 번호인가」가 아니다.
    ⇒ 그 책 원본 글 전체를 한 자루에 담아 놓고 **들어 있는가**만 본다.
    ⚠ 우리가 얹은 표식은 걷고 본다 — `<병합 N:M>` 은 떼고, `<없음>` 은 세지
      않는다(원본에 없는 것이 맞다). 쪼갠 절을 이어 붙인 자리(J2)는
      **이웃한 두 절을 이은 것**과 견준다.
    """
    same = diff = 0
    bag, pair = {}, {}
    for b, chs in src.items():
        g, p = set(), set()
        for lst in chs.values():
            for i, t in enumerate(lst):
                g.add(norm(t))
                if i + 1 < len(lst):
                    p.add(norm('%s %s' % (t.strip(), lst[i + 1].strip())))
        bag[b], pair[b] = g, p
    for b, tx in conn.execute(
            '''SELECT bi.bcode, bc.verse_text FROM bible_index bi
               JOIN bible_content bc ON bc.verse_id=bi.verse_id
                 AND bc.version_code=?''', (VER,)):
        t = (tx or '').strip()
        if not t or t == ABSENT_MARK:
            continue
        m = _RX_MERGE.match(t)
        if m:
            t = t[m.end():]
        t = norm(t)
        if t in bag.get(b, ()) or t in pair.get(b, ()):
            same += 1
        else:
            diff += 1
    return same, diff


# ── 자가 검증 ─────────────────────────────────────────────────────────
def _selftest():
    ok = [0]
    bad = []

    def chk(name, cond, extra=''):
        if cond:
            ok[0] += 1
            print('  OK   ', name)
        else:
            bad.append(name)
            print('  FAIL ', name, extra)

    mtl = {i: 10 for i in range(1, 152)}
    mtl[9], mtl[10], mtl[116], mtl[147] = 20, 18, 19, 20
    chk('편 대응 — 1~8편은 제자리', syn_to_mt(3, mtl) == [(3, 1, 10)])
    chk('편 대응 — 시노드 9 = 마소라 9+10',
        syn_to_mt(9, mtl) == [(9, 1, 20), (10, 1, 18)])
    chk('편 대응 — 시노드 118 = 마소라 119', syn_to_mt(118, mtl) == [(119, 1, 10)])
    chk('편 대응 — 시노드 116 을 쪼갠다',
        syn_to_mt(114, mtl) == [(116, 1, 9)] and
        syn_to_mt(115, mtl) == [(116, 10, 19)])
    chk('편 대응 — 148~150 은 제자리', syn_to_mt(150, mtl) == [(150, 1, 10)])
    chk('납작하게 — 두 편이 이어 붙는다',
        slots_of([(9, 1, 2), (10, 1, 2)]) == [(9, 1), (9, 2), (10, 1), (10, 2)])
    chk('표제 상투어를 알아본다',
        bool(TITLE_RX.search('Начальнику хора. Псалом Давида.')))
    chk('표제 상투어 — 본문은 아니다',
        not TITLE_RX.search('Блажен муж, который не ходит на совет нечестивых'))
    chk('선택하기 — 공백과 강세만 접는다',
        norm(' а́ б  в ') == 'а б в')
    chk('상관 — 짧으면 못 잰다', corr([1, 2, 3], [1, 2, 3]) is None)
    chk('상관 — 같은 무늬면 1.0',
        abs(corr([1, 5, 2, 9, 3, 7], [2, 10, 4, 18, 6, 14]) - 1.0) < 1e-9)

    # 이름 닻 — 216/216 을 낸 그 규칙이 실제로 도는가
    chk('이름 표 — 겹치는 러시아어 어간이 없다',
        len({r for r, _ in NAMES}) == len(NAMES))
    chk('이름 닻 — 러시아어에서 찾는다',
        ru_hits('на Сионе, горе святой Его') == {'Zion'})
    chk('이름 닻 — 없으면 빈손', ru_hits('Блажен муж') == set())
    chk('영어 대조 — en대시를 접는다', en_has('the witch of En\u2013dor', 'Endor'))
    chk('영어 대조 — 철자 변이(Zion/Sion)', en_has('in Sion', 'Zion'))
    chk('영어 대조 — 없으면 거짓', en_has('in Egypt', 'Zion') is False)
    _kj = {(1, 1): 'of Zion', (1, 2): 'the hill', (1, 3): 'a psalm'}
    chk('어긋남 — 제자리에 있으면 통과',
        name_clashes([((1, 1), 'на Сионе')], _kj) == ([], 1))
    chk('★ 어긋남 — 이웃에는 있는데 제자리에 없으면 잡는다',
        name_clashes([((1, 2), 'на Сионе')], _kj)[0] == ['1:2 Zion'])
    chk('★ 어긋남 — 아무 데도 없으면 잡지 않는다(번역 차이다)',
        name_clashes([((1, 3), 'в Египте')], _kj) == ([], 1))
    chk('글자 확인 목록 — 편 번호가 1~150 안',
        all(1 <= k <= 150 for k in PSA_VERIFIED))
    chk('글자 확인 목록 — 근거를 빈칸으로 두지 않는다',
        all(len(v) > 20 for v in PSA_VERIFIED.values()))
    chk('견주는 역본이 여럿 — 한 역본에 끌리지 않는다',
        len(REF_VERSIONS) >= 3 and CORR_WINS >= 2)

    # 절체계가 다른 15장 표 — 스스로 앞뒤가 맞는가
    _kinds, _gap, _dup = set(), [], []
    for (_b, _ch), _ops in CHAP_FIX.items():
        _nxt, _seen = 1, set()
        for _a, _z, _k, _t in _ops:
            _kinds.add(_k)
            if _k != 'NONE':
                if _a != _nxt:
                    _gap.append((_b, _ch, _a, _nxt))
                _nxt = _z + 1
            if _k in ('SEQ', 'M2', 'J2', 'NONE'):
                _n = 2 if _k == 'M2' else (
                    1 if _k in ('J2', 'NONE') else _z - _a + 1)
                for _i in range(_n):
                    _p = (_t[0], _t[1] + _i)
                    if _p in _seen:
                        _dup.append((_b, _ch, _p))
                    _seen.add(_p)
    chk('표 — 원본 절이 1부터 빈틈없이 이어진다', not _gap, _gap)
    chk('표 — 한 슬롯을 두 번 채우지 않는다', not _dup, _dup)
    chk('표 — 갈래는 다섯뿐',
        _kinds <= {'SEQ', 'M2', 'J2', 'DROP', 'NONE'}, _kinds)
    chk('표 — 15장이 들어 있다', len(CHAP_FIX) == 17, len(CHAP_FIX))
    try:
        import verse_text as _vt
        chk('없음 표식을 verse_text 가 알아본다',
            _vt.classify(ABSENT_MARK, True)[0] == _vt.ABSENT)
    except Exception as e:                                 # noqa: BLE001
        chk('없음 표식을 verse_text 가 알아본다', False, e)

    # 계획·적용·되돌리기를 **메모리 DB** 로 왕복
    import sqlite3
    m = sqlite3.connect(':memory:')
    m.execute('CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY, bcode INT,'
              ' chapter INT, verse INT, sort_order INT)')
    m.execute('CREATE TABLE bible_content(verse_id INT, version_code TEXT,'
              ' verse_text TEXT)')
    m.execute('CREATE TABLE bible_version(version_code TEXT,'
              ' versification_system TEXT)')
    m.execute("INSERT INTO bible_version VALUES('RusSyn','MANUAL')")
    vid = 1
    for ch in (1, 2):
        for v in range(1, 7):
            m.execute('INSERT INTO bible_index VALUES(?,?,?,?,?)',
                      (vid, 40, ch, v, vid * 10))
            vid += 1
    m.execute("INSERT INTO bible_content VALUES(1,'RusSyn','옛글')")
    pl = {(40, 1, 1): '새글', (40, 1, 2): '둘'}
    n_new, n_upd = apply(m, pl)
    chk('적용 — 새로 넣고 고친다', (n_new, n_upd) == (1, 1), (n_new, n_upd))
    got = dict(m.execute("SELECT verse_id, verse_text FROM bible_content"
                         " WHERE version_code='RusSyn'").fetchall())
    chk('적용 — 값이 들어갔다', got.get(1) == '새글' and got.get(2) == '둘', got)
    chk('★ 적용 — 정렬 표시가 MT 가 된다(전수 검사에 들어온다)',
        m.execute('SELECT versification_system FROM bible_version'
                  " WHERE version_code='RusSyn'").fetchone()[0] == 'MT')
    chk('되돌리기 — 절 두 줄(정렬 표시는 절이 아니라 안 센다)', undo(m) == 2)
    chk('★ 되돌리기 — 정렬 표시도 옛 값으로',
        m.execute('SELECT versification_system FROM bible_version'
                  " WHERE version_code='RusSyn'").fetchone()[0] == 'MANUAL')
    got = dict(m.execute("SELECT verse_id, verse_text FROM bible_content"
                         " WHERE version_code='RusSyn'").fetchall())
    chk('되돌리기 — 옛 글로 · 없던 줄은 사라진다',
        got == {1: '옛글'}, got)

    # 병합 표기가 verse_text 규약과 맞는가
    try:
        import verse_text as vt
        kind, body, mv = vt.classify('<병합 116:8> Ты избавил', True)
        chk('병합 표기를 verse_text 가 알아본다',
            kind == vt.MERGED and mv == 8 and body.startswith('Ты'),
            (kind, mv, body[:12]))
    except Exception as e:                                     # noqa: BLE001
        chk('병합 표기를 verse_text 가 알아본다', False, e)

    print('db_russyn_align selftest %d/%d' % (ok[0], ok[0] + len(bad)))
    return not bad


# ── CLI ───────────────────────────────────────────────────────────────
def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        return 0 if _selftest() else 1
    conn = appdb.connect()
    if '--undo' in a:
        print('되돌린 줄 %d' % undo(conn))
        return 0
    src = load_src()

    same, diff = source_identity(conn, src)
    print('① 원본 동일성 — 같음 %d · 다름 %d  (%.2f%%)'
          % (same, diff, 100.0 * same / max(1, same + diff)))
    if diff:
        print('   ⚠ 다른 줄이 있다 — 같은 판이 아닐 수 있다. 멈춘다.')
        return 1

    print()
    print('② 시편')
    pp, pinfo, pskip = plan_psalms(conn, src, log=lambda *x: None)
    print('   확정 %d편 · 건너뜀 %d편 · 채울 절 %d' % (len(pinfo), len(pskip), len(pp)))
    for s, why in pskip:
        print('     ⚠ 시노드 %3d편 — %s' % (s, why))
    print()
    print('③ 시편 밖 — 닻 구간')
    op, good, bad = plan_others(conn, src)
    print('   결정된 구간 %d(절 %d) · 결정 못 한 구간 %d' % (len(good), len(op), len(bad)))
    nm = {r[0]: r[1] for r in conn.execute(
        "SELECT book_code, short_name FROM book_names WHERE lang_code='KO'")}
    for b, x, y, ns, nv in bad:
        fixed = all((b, ch) in CHAP_FIX for ch in range(x, y + 1))
        print('     %s %-6s %s~%s장  슬롯 %3d · 원본 %3d (차 %+d)%s'
              % ('★' if fixed else '⚠', nm.get(b, b), x, y, ns, nv,
                 nv - ns, '  — 표로 확정' if fixed else ''))

    print()
    print('④ 절체계가 다른 장 — 읽어서 확정한 표')
    cp, cinfo, cbad = plan_chapters(conn, src)
    print('   표로 채우는 장 %d · 절 %d' % (len(cinfo), len(cp)))
    for b, ch, why in cbad:
        print('     ⚠ bcode %d %d장 — %s' % (b, ch, why))
    if cbad:
        print('   ⚠ 표가 맞지 않는다 — 멈춘다.')
        return 1

    plan = dict(op)
    plan.update(pp)
    plan.update(cp)
    cur = {}
    for b, ch, vs, tx in conn.execute(
            '''SELECT bi.bcode, bi.chapter, bi.verse, bc.verse_text
               FROM bible_index bi JOIN bible_content bc
                 ON bc.verse_id=bi.verse_id AND bc.version_code=?''', (VER,)):
        cur[(b, ch, vs)] = tx
    chg = sum(1 for k, t in plan.items() if norm(cur.get(k, '')) != norm(t))
    new = sum(1 for k in plan if k not in cur)
    print()
    print('계획 — 쓸 절 %d (새로 채움 %d · 글이 바뀜 %d · 그대로 %d)'
          % (len(plan), new, chg - new, len(plan) - chg))

    if '--apply' in a:
        n1, n2 = apply(conn, plan)
        print('적용 — 새로 %d · 고침 %d · 백업 %s' % (n1, n2, BAK))
        left = conn.execute(
            '''SELECT COUNT(*) FROM bible_index bi LEFT JOIN bible_content bc
               ON bc.verse_id=bi.verse_id AND bc.version_code=?
               WHERE bc.verse_id IS NULL''', (VER,)).fetchone()[0]
        print('남은 빈 슬롯 %d' % left)
    else:
        print('(DB 무변경 — 쓰려면 --apply)')
    return 0


if __name__ == '__main__':
    sys.exit(main())
