"""
license_info.py — 데이터 출처 및 라이선스 고지 모달 (다국어)
-----------------------------------------------------------
본 앱이 사용하는 외부 데이터·소프트웨어의 출처·라이선스를 고지한다.
OpenBible.info(CC-BY 4.0)/OpenStreetMap(ODbL) 의무 충족용.
show_license(parent, lang='KO') 로 호출.

다국어(§0-3): 설명 텍스트는 lang 별 dict(KO/EN, EN 폴백). 소스명·라이선스코드·URL 은
언어 중립(전 언어 동일). 나머지 8개 언어는 _T/_L 에 행 추가로 확장.
"""
import webbrowser
import tkinter as tk
from tkinter import ttk


def _C(role, fallback):
    try:
        import ui_theme
        return ui_theme.C(role) or fallback
    except Exception:
        return fallback

# UI 라벨 (lang → {key: text})
_T = {
    'KO': {'title': 'ⓘ 데이터 출처 및 라이선스', 'close': '닫기',
           'sec_map': '지도 · 지리 데이터 (성지순례)',
           'sec_text': '성경 본문 · 주석 · 도서',
           'sec_pg': 'Project Gutenberg 전자책',
           'sec_ccel': 'Christian Classics Ethereal Library',
           'sec_ia': 'Internet Archive 스캔본',
           'sec_sw': '소프트웨어', 'sec_vid': '영상 콘텐츠',
           'sec_ver': '성경 역본',
           'sec_ver_pd': '저작권이 만료된 역본 (퍼블릭 도메인)',
           'sec_ver_ok': '발행처가 자유 이용을 허락한 역본',
           'sec_ver_chk': '⚠ 출처·라이선스를 아직 확인하지 못한 역본',
           'sec_copy': '저작권 신고',
           'sec_app': '이 앱의 프로그램',
           'sec_ours': '우리가 쓴 글',
           'sec_trans': '우리가 옮긴 글 (번역)',
           'lic': '라이선스', 'use': '용도'},
    'EN': {'title': 'ⓘ Data Sources & Licenses', 'close': 'Close',
           'sec_map': 'Map & Geographic Data (Holy-Land Tour)',
           'sec_text': 'Bible Text · Commentary · Books',
           'sec_pg': 'Project Gutenberg eBooks',
           'sec_ccel': 'Christian Classics Ethereal Library',
           'sec_ia': 'Internet Archive scans',
           'sec_sw': 'Software', 'sec_vid': 'Video Content',
           'sec_ver': 'Bible Versions',
           'sec_ver_pd': 'Public Domain (copyright expired)',
           'sec_ver_ok': 'Freely licensed by the publisher',
           'sec_ver_chk': '⚠ Source / license not yet verified',
           'sec_copy': 'Copyright Complaints',
           'sec_app': 'This Application',
           'sec_ours': 'Text We Wrote',
           'sec_trans': 'Text We Translated',
           'lic': 'License', 'use': 'Use'},
}

# 설명 본문 (lang → 리스트). 각 줄 신뢰도: 소스명/라이선스코드/URL 은 그대로.
_L = {
    'KO': {
        'ob_use': '성경 장소 좌표·현대 지명 식별. 본 앱 형식으로 가공·발췌(변경 명시).',
        'osm_use': '지도 데이터 일부가 OpenStreetMap 을 기반으로 할 경우 적용.',
        'ne_use': '퍼블릭 도메인 (Public Domain) — 현대 국가 경계·해안선',
        'esri_use': '위성 영상 — 도시 포커스(고배율) 배경. 온라인 타일, 출처표시 조건.',
        'sh_use': '퍼블릭 도메인 (1928년 이전 발행) — 고대 지도 배경',
        'mb_use': '퍼블릭 도메인 (1843, Wikimedia Commons) — 고대 지도 배경(근사 정합)',
        'text_intro': '성경 역본·주석·고전 도서는 대부분 퍼블릭 도메인(저작권 만료) 자료입니다:',
        'text_b1': '성경 역본 — 역본마다 다릅니다. 「성경 역본」 탭에 하나하나 적었습니다.',
        'text_b2': '주석: JFB·Matthew Henry·Barnes·Adam Clarke·Pulpit — PD',
        'text_b3': '도서: Spurgeon·Murray·Bunyan·Kempis·Bounds 등 — PD(본문 말미 출처 표기)',
        'text_b4': '교리문답·사전: Heidelberg·Westminster·Easton·Smith — PD',
        'pg_intro': ('아래 도서는 Project Gutenberg 에서 받은 전자책입니다. '
                     'PG 라이선스 §1.E.1 은 「Project Gutenberg」 이름을 밝히는 곳에서는 '
                     '다음 고지와 라이선스 전문 링크를 함께 보이도록 요구합니다.'),
        'pg_thanks': ('이 책들은 자원봉사자들이 원본을 스캔하고 손으로 교정한 것입니다. '
                      'Project Gutenberg 와 Online Distributed Proofreading Team '
                      '(pgdp.net), 그리고 원본 이미지를 제공한 Internet Archive 에 '
                      '감사드립니다.'),
        'pg_books': '이 앱에 담긴 Project Gutenberg 자료',
        'ccel_intro': ('아래 도서·주석은 Calvin College 의 Christian Classics Ethereal '
                       'Library 에서 받았습니다. CCEL 은 자료마다 다음 한 줄을 함께 '
                       '표시하도록 정해 두었습니다.'),
        'ccel_books': '이 앱에 담긴 CCEL 자료',
        'ia_intro': ('아래 도서는 Internet Archive 가 공개한 옛 인쇄본 스캔에서'
                     ' 왔습니다. 저작권이 만료된 저작물이며, 스캔과 글자 옮김은'
                     ' Internet Archive 와 그 협력 도서관들이 했습니다.'),
        'ia_books': '이 앱에 담긴 Internet Archive 자료',
        'src_none': '(해당 자료 없음)',
        'sw_b1': 'Python 3 · Tkinter (표준 라이브러리)',
        'sw_b2': 'PyQt6 / Qt WebEngine — 인라인 영상 재생(별도 프로세스). Qt 라이선스 적용',
        'vid1': 'YouTube 영상은 링크/임베드로만 제공되며 원저작자에게 저작권이 있습니다.',
        'vid2': '본 앱은 영상을 저장·재배포하지 않습니다(스트리밍 임베드).',
        # ── 이 앱 쪽 (2026-09-06 사용자 0.txt 8-3) ──
        'app_intro': ('앞 탭의 자료는 밖에서 가져온 것이고, 아래는 이 앱을 위해 '
                      '새로 만든 것입니다. 바탕이 된 자료가 퍼블릭 도메인이라도 '
                      '새로 쓴 글과 번역에는 저작권이 있습니다.'),
        'app_prog': '프로그램 — 화면·검색·연결·묵상플랜 등 앱의 모든 기능',
        'app_prog2': '표준 라이브러리(Python·Tkinter)와 아래 소프트웨어 위에서 돕니다.',
        'ours_intro': ('성경 본문·주석·도서는 밖에서 왔지만, 아래 글은 이 앱을 위해 '
                       '직접 썼습니다. 실제 분량은 이 앱의 데이터에서 세었습니다.'),
        'ours_note': ('교단에 치우치지 않게 씁니다 — 견해가 갈리는 주제는 어느 한 '
                      '전통의 이름을 붙이지 않고, 여러 교회가 함께 고백해 온 말로 '
                      '적습니다.'),
        'trans_intro': ('옛 영어로 쓰인 도서·주석을 오늘의 말로 옮겼습니다. '
                        '번역과 현대어 고침은 우리가 한 일이라 원문과 저작권이 '
                        '다릅니다.'),
        'trans_style': ('번역 방침 — 오늘 묵상에 쓰기 좋게 옮깁니다. '
                        '뜻을 줄이거나 더하지 않고, 긴 문장은 끊고, 옛 어투'
                        '(thee·thou 같은)는 지금 말로 바꿉니다. 문단을 다시 '
                        '짜거나 요약하지 않으며, 뺀 대목이 있으면 밝힙니다. '
                        '원문은 그대로 함께 담아 두어 언제든 견주어 볼 수 '
                        '있습니다.'),
        'trans_v_o': '원문 — 저자의 글 그대로 (퍼블릭 도메인)',
        'trans_v_m': '현대 영어 — 옛 영어를 오늘의 영어로',
        'trans_v_t': '번역 — 사용자 언어로 옮긴 글',
        'trans_v_s': '요약 — 긴 글의 줄거리',
        'cnt_unit': '건',
        'cnt_char': '자',
        # ── 성경 역본 탭 (2026-09-06) ──
        'ver_intro': ('이 앱에 **본문이 실려 있는** 성경 역본입니다. 목록은 '
                      '앱의 데이터에서 직접 읽어 만들므로 역본을 더하면 '
                      '여기에도 저절로 나타납니다.'),
        'ver_verses': '절',
        'ver_chk': ('아래 역본은 원 자료의 출처와 라이선스를 아직 확인하지 '
                    '못했습니다. 확인될 때까지 배포에서 뺄 수 있습니다.'),
        'ver_none': '(해당하는 역본이 없습니다)',
        # ── 저작권 신고 (2026-09-08 사용자 지시 「저작권 신고 주소 추가하라」) ──
        #   ★ DMCA Safe Harbor 는 **신고받을 주소를 앱 안에 밝히는 것**을
        #     요건으로 든다(`정책자료/DMCA정책표시.txt`). 그 자리가 여기다.
        'cr_intro': ('이 앱에 실린 자료는 저작권이 만료되었거나 발행처가 자유 '
                     '이용을 허락한 것만 담았습니다. 그래도 저작권에 문제가 '
                     '있다고 보시면 아래 주소로 알려 주십시오.'),
        'cr_addr': '저작권 신고 주소',
        'cr_need': ('신고하실 때 다음을 적어 주시면 빠르게 처리할 수 있습니다.\n'
                    '· 문제가 되는 자료가 이 앱의 어디에 있는지 (화면·자료 이름)\n'
                    '· 침해되었다고 보시는 원 저작물이 무엇인지\n'
                    '· 신고하시는 분의 이름과 연락처\n'
                    '· 저작권자 본인이시거나 대리할 권한이 있다는 사실'),
        'cr_do': ('알려 주시면 사실을 확인하고, 문제가 있다고 판단되면 해당 '
                  '자료를 배포에서 곧바로 뺍니다. 처리 결과는 알려 드립니다.'),
        'cr_user': ('사용자가 스스로 만든 방(공동체 묵상)에 올린 자료는 그 방을 '
                    '연 분의 책임이며, 이 앱을 만든 사람은 그 자료를 만들지도 '
                    '보관하지도 않습니다. 그런 경우에도 알려 주시면 그 방을 연 '
                    '분에게 전달하고 필요한 조치를 취합니다.'),
    },
    'EN': {
        'ob_use': 'Bible place coordinates / modern-name identification. Adapted & excerpted for this app (modified).',
        'osm_use': 'Applies where map data is derived from OpenStreetMap.',
        'ne_use': 'Public Domain — modern country borders & coastlines',
        'esri_use': 'Satellite imagery — city-focus (high-zoom) background. Online tiles, attribution required.',
        'sh_use': 'Public Domain (published before 1928) — ancient map background',
        'mb_use': 'Public Domain (1843, Wikimedia Commons) — ancient map background (approx. georeferenced)',
        'text_intro': 'Bible versions, commentaries and classic books are mostly Public Domain (expired):',
        'text_b1': 'Bible versions — each differs. Listed one by one in the "Bible Versions" tab.',
        'text_b2': 'Commentaries: JFB · Matthew Henry · Barnes · Adam Clarke · Pulpit — PD',
        'text_b3': 'Books: Spurgeon · Murray · Bunyan · Kempis · Bounds — PD (credited in text)',
        'text_b4': 'Catechisms/Dictionaries: Heidelberg · Westminster · Easton · Smith — PD',
        'pg_intro': ('The books below are eBooks obtained from Project Gutenberg. '
                     'Section 1.E.1 of the PG License requires that wherever the '
                     'phrase "Project Gutenberg" is associated with a work, the '
                     'following notice appear prominently together with a link to '
                     'the full license.'),
        'pg_thanks': ('These texts were scanned and hand-proofread by volunteers. '
                      'Our thanks to Project Gutenberg, the Online Distributed '
                      'Proofreading Team (pgdp.net), and the Internet Archive, which '
                      'supplied the source page images.'),
        'pg_books': 'Project Gutenberg material included in this app',
        'ccel_intro': ('The books and commentaries below come from the Christian '
                       'Classics Ethereal Library at Calvin College. CCEL asks that '
                       'the following line accompany each document.'),
        'ccel_books': 'CCEL material included in this app',
        'ia_intro': ('The books below come from scans of old printings made'
                     ' available by the Internet Archive. The works are out of'
                     ' copyright; the scanning and text capture were done by the'
                     ' Internet Archive and its partner libraries.'),
        'ia_books': 'Internet Archive material included in this app',
        'src_none': '(none)',
        'sw_b1': 'Python 3 · Tkinter (standard library)',
        'sw_b2': 'PyQt6 / Qt WebEngine — inline video (separate process). Qt license applies',
        'vid1': 'YouTube videos are provided by link/embed only; copyright remains with creators.',
        'vid2': 'This app does not store or redistribute videos (streaming embed).',
        'app_intro': ('The previous tab lists material brought in from outside. '
                      'What follows was made for this app. Even where the source '
                      'is public domain, the newly written text and the '
                      'translations are copyrighted.'),
        'app_prog': 'Program — screens, search, links, reading plans',
        'app_prog2': 'Runs on the standard library (Python·Tkinter) and the software below.',
        'ours_intro': ('Bible text, commentary and books come from outside, but the '
                       'text below was written for this app. The figures are counted '
                       'from this app’s own data.'),
        'ours_note': ('Written without denominational bias — where views differ we '
                      'avoid attaching one tradition’s name and use wording the '
                      'churches have long confessed together.'),
        'trans_intro': ('Books and commentaries written in older English were put '
                        'into today’s language. The translation and modernisation '
                        'are our work, so their copyright differs from the original.'),
        'trans_style': ('Policy — rendered for devotional reading today. Nothing '
                        'is added or dropped in meaning; long sentences are broken '
                        'up; archaic forms (thee, thou) become modern words. We do '
                        'not restructure paragraphs or summarise, and anything left '
                        'out is stated. The original is kept alongside so it can '
                        'always be compared.'),
        'trans_v_o': 'Original — the author’s own words (public domain)',
        'trans_v_m': 'Modern English — older English put into today’s English',
        'trans_v_t': 'Translated — rendered into the user’s language',
        'trans_v_s': 'Summary — the gist of a long piece',
        'cnt_unit': ' items',
        'cnt_char': ' chars',
        # ── Bible versions tab (2026-09-06) ──
        'ver_intro': ('Bible versions whose **text is included** in this app. '
                      'The list is read from the app data, so adding a version '
                      'makes it appear here automatically.'),
        'ver_verses': ' verses',
        'ver_chk': ('The source and license of the versions below have not yet '
                    'been verified. They may be excluded from distribution '
                    'until they are.'),
        'ver_none': '(no versions in this group)',
        'cr_intro': ('This app contains only material that is in the public '
                     'domain or licensed by its publisher for free use. If you '
                     'believe there is a copyright problem, please contact us '
                     'at the address below.'),
        'cr_addr': 'Copyright complaints',
        'cr_need': ('Please include the following so we can act quickly:\n'
                    '- Where the material appears in this app (screen, title)\n'
                    '- What original work you believe is infringed\n'
                    '- Your name and contact information\n'
                    '- A statement that you are the copyright owner or '
                    'authorised to act on the owner\'s behalf'),
        'cr_do': ('We will verify the report and, if the claim is valid, remove '
                  'the material from distribution promptly. We will tell you '
                  'the outcome.'),
        'cr_user': ('Material posted in a user-created room (community '
                    'devotion) is the responsibility of the person who opened '
                    'that room; the app author neither creates nor stores it. '
                    'Even so, if you report it we will pass the notice on to '
                    'that person and take the necessary steps.'),
    },
}

_LINK_CCBY = 'https://creativecommons.org/licenses/by/4.0/'
_LINK_PG_LICENSE = 'https://www.gutenberg.org/policy/license.html'
_LINK_PG = 'https://www.gutenberg.org'
_LINK_CCEL = 'http://www.ccel.org'

# ★ 이 두 문장은 **번역하지 않는다.** 기관이 정한 문구 그대로 실어야 고지가 된다.
#   PG §1.E.1 이 요구하는 문장 · CCEL 이 자기 파일 끝에 붙이는 문장.
PG_NOTICE = (
    'This eBook is for the use of anyone anywhere in the United States and '
    'most other parts of the world at no cost and with almost no restrictions '
    'whatsoever. You may copy it, give it away or re-use it under the terms of '
    'the Project Gutenberg License included with this eBook or online at '
    'www.gutenberg.org. If you are not located in the United States, you will '
    'have to check the laws of the country where you are located before using '
    'this eBook.')
CCEL_NOTICE = (
    'This document is from the Christian Classics Ethereal Library at Calvin '
    'College, http://www.ccel.org, generated on demand from ThML source.')


#: ★★★ **저작권 신고 주소** (2026-09-08 사용자 지시 「저작권 신고 주소
#:   추가하라」). DMCA Safe Harbor 는 **신고받을 주소를 앱 안에 밝히는 것**을
#:   요건으로 든다(`정책자료/DMCA정책표시.txt`).
#: ⚠ **DB(`sys_config.COPYRIGHT_CONTACT`)를 먼저 본다** — 주소가 바뀌어도
#:   앱 판올림 없이 코어팩으로 고칠 수 있다. 못 읽으면 아래 값으로 물러선다
#:   (§0-3 — DB 만 고치면 읽기 실패 때 빈칸이 나온다).
COPYRIGHT_CONTACT_DEFAULT = 'suhyw123@gmail.com'


def copyright_contact(db_path='bible_master.db'):
    """저작권 신선택할 받을 주소 — DB 우선, 없으면 코드 기본값."""
    try:
        import appdb
        with appdb.connect(db_path) as c:
            r = c.execute("SELECT config_val FROM sys_config "
                          "WHERE config_key='COPYRIGHT_CONTACT'").fetchone()
            if r and (r[0] or '').strip():
                return r[0].strip()
    except Exception:
        pass
    return COPYRIGHT_CONTACT_DEFAULT


def source_books(host, lang='KO', db_path='bible_master.db'):
    """`host` 가 출처인 도서 제목 목록 — DB 를 물어 만든다.

    ★ 손으로 적어 두면 책을 더할 때마다 어긋난다. 목록은 늘 지금 DB 다.
    """
    out = []
    try:
        import appdb
        with appdb.connect(db_path) as conn:
            rows = conn.execute("""
                SELECT COALESCE(bat.title, ba.title), ba.source_url
                  FROM sys_book_asset ba
                  LEFT JOIN sys_book_asset_text bat
                         ON bat.book_id = ba.book_id
                        AND UPPER(bat.lang_code) = ?
                        AND COALESCE(bat.record_status,'LIVE') = 'LIVE'
                 WHERE COALESCE(ba.record_status,'LIVE') = 'LIVE'
                   AND ba.source_url LIKE ?
                 ORDER BY 1""", ((lang or 'KO').upper(), '%' + host + '%')
                                ).fetchall()
        for title, url in rows:
            out.append((title or '', url or ''))
    except Exception:
        pass
    return out


def _tr(lang, table, key):
    d = table.get(lang) or table.get('EN', {})
    return d.get(key) or table.get('EN', {}).get(key, key)


def show_license(parent, lang='KO', section=None):
    """`section='PG'|'CCEL'` 이면 그 고지가 맨 위에 오게 열린다."""
    lang = (lang or 'KO').upper()
    if lang not in _T:
        lang = 'EN'
    T = lambda k: _tr(lang, _T, k)
    L = lambda k: _tr(lang, _L, k)

    win = tk.Toplevel(parent)
    win.title(T('title'))
    win.geometry('680x600')
    win.transient(parent)
    try:
        win.grab_set()
    except Exception:
        pass

    head = tk.Frame(win, bg=_C('dark_bg', '#1A5276'))
    head.pack(fill='x')
    tk.Label(head, text=T('title'), bg=_C('dark_bg', '#1A5276'),
             fg=_C('fg_on_dark', 'white'),
             font=('', 12, 'bold')).pack(side='left', padx=12, pady=8)

    # ⚠ 바닥 띠를 **먼저** 자리 잡는다 — expand 자식 뒤에 pack 하면 높이 1px
    #   (문서에 다섯 번 걸린 함정. 실제로 [닫기]가 안 보이던 자리다).
    btnf = tk.Frame(win, bg=_C('bg', 'white'))
    btnf.pack(side='bottom', fill='x')
    ttk.Button(btnf, text=T('close'), command=win.destroy, width=10
               ).pack(side='right', padx=12, pady=8)

    build_license_body(win, lang, section).pack(fill='both', expand=True)

    # 표준 서식(§36) — 다 지은 **뒤** 한 번. 먼저 부르면 뒤 위젯이 안 칠해진다.
    try:
        import ui_theme
        ui_theme.adopt(win)
    except Exception:
        pass


def our_text_stats(lang='KO'):
    """우리가 쓴 글의 실제 분량 → [(이름, 건수, 글자수)]. 못 읽으면 [].

    ★ **여기서 세지 않는다** — `app_facts` 한 문에 맡긴다. 앱소개 화면도 같은
      문을 쓰므로 두 숫자가 갈릴 수 없다(§0-1b 「손으로 적으면 거짓이 된다」).
    """
    try:
        import app_facts
        return app_facts.our_text()
    except Exception:
        return []


def version_rows(db_path='bible_master.db'):
    """성경 역본의 라이선스 → [(코드, 이름, 언어, 갈래, 설명, 주소, 행수)].

    ★★ **DB 를 물어 만든다 — 손으로 적지 않는다**(2026-09-06). 역본을 더하면
      고지가 저절로 늘고, 안 그러면 **늘리는 날 고지가 거짓이 된다**
      (§0-1b 「목록을 손으로 적으면 책을 더할 때 어긋난다」).
    ⚠ **본문이 실린 것만** 낸다 — 등록만 되고 0행인 역본(JLV·TRC)은 배포물에
      없으므로 고지에 적으면 그 자체가 틀린 말이다.
    """
    try:
        import appdb
        with appdb.connect(db_path) as c:
            return c.execute("""
                SELECT v.version_code, v.version_name, v.lang_code,
                       COALESCE(v.copyright_type, 'UNVERIFIED'),
                       COALESCE(v.license_note, ''),
                       COALESCE(v.source_url, ''),
                       (SELECT COUNT(*) FROM bible_content b
                         WHERE b.version_code = v.version_code)
                  FROM bible_version v
                 ORDER BY v.lang_code, v.version_code""").fetchall()
    except Exception:
        return []


def build_license_body(parent, lang='KO', section=None, scope='CONTENT'):
    """고지 본문만 만들어 돌려준다 — 모달과 '라이선스정보' 탭이 공용.

    ★ 진입점이 배너 구석 7pt 버튼 하나뿐이라 아무도 못 찾았다(2026-08-10).
      지원/설정의 '정보' 탭에서 같은 내용을 그대로 쓴다. **본문은 한 곳에만 둔다.**

    ★★ **`scope` 로 둘을 가른다** (2026-09-06 사용자 0.txt 8-3 「수록된
      컨텐츠 라이센서와 **이 앱의 라이센스를 구별**하여 표시하자. **두 탭으로
      나누어라**」):
        · `CONTENT` — **담긴 것**. 밖에서 가져온 자료(지도·본문·주석·도서·영상)
        · `APP`     — **담는 것**. 이 앱의 프로그램 · 우리가 쓴 글 · 우리 번역
      ⚠ 소프트웨어(Qt·Python)는 **APP 쪽**이다 — 「수록된 컨텐츠」가 아니라
        앱을 이루는 것이다.
    """
    lang = (lang or 'KO').upper()
    if lang not in _T:
        lang = 'EN'
    T = lambda k: _tr(lang, _T, k)
    L = lambda k: _tr(lang, _L, k)

    body = tk.Frame(parent, bg=_C('bg', 'white'))
    txt = tk.Text(body, wrap='word', bg=_C('panel', 'white'),
                  fg=_C('fg', '#222'),
                  relief='flat', padx=14, pady=10, cursor='arrow')
    try:
        import theme_font
        theme_font.register(txt, 'bible_master.db', 'prose')
    except Exception:
        pass
    sb = ttk.Scrollbar(body, command=txt.yview)
    txt.configure(yscrollcommand=sb.set)
    sb.pack(side='right', fill='y')
    txt.pack(side='left', fill='both', expand=True)

    # 태그 색 = 만드는 시점 역할 (§36-5b — 이 본문은 만들 때마다 새로 그린다)
    txt.tag_configure('h', font=('', 11, 'bold'),
                      foreground=_C('fg_title', '#1A5276'),
                      spacing1=10, spacing3=4)
    txt.tag_configure('b', font=('', 10, 'bold'), foreground=_C('fg', '#333'))
    txt.tag_configure('t', foreground=_C('fg', '#444'))
    txt.tag_configure('link', foreground=_C('accent', '#1565C0'), underline=True)

    link_n = [0]

    def H(text):
        txt.insert('end', text + '\n', 'h')

    def B(text):
        txt.insert('end', '• ' + text + '\n', 'b')

    def P(text):
        txt.insert('end', '   ' + text + '\n', 't')

    def LK(url):
        # ⚠⚠ **밑줄 밖을 눌러도 열리던 것을 고쳤다** (2026-09-06 사용자 신고
        #   0.txt 8-3 「URL 링크 **밑줄이 없는 공간까지 클릭하면 새화면이
        #   열린다**. 밑줄 부분에만 링크 기능을 걸어라」).
        #   정체 — 앞 들여쓰기와 **줄끝 개행까지 태그 안**에 넣고 있었다.
        #   Text 위젯은 줄 오른쪽 빈 자리를 그 줄의 개행 문자로 치므로,
        #   글자가 없는 곳을 눌러도 링크가 눌린 것이 된다.
        #   ⇒ 들여쓰기·개행은 **태그 밖**에 넣는다.
        tag = f'lnk{link_n[0]}'; link_n[0] += 1
        txt.insert('end', '   ')
        txt.insert('end', url, ('link', tag))
        txt.insert('end', '\n')
        txt.tag_bind(tag, '<Button-1>', lambda e, u=url: webbrowser.open(u))
        txt.tag_bind(tag, '<Enter>', lambda e: txt.config(cursor='hand2'))
        txt.tag_bind(tag, '<Leave>', lambda e: txt.config(cursor='arrow'))

    def SP():
        txt.insert('end', '\n')

    # ── 「성경 역본」 탭 — 역본마다 라이선스가 다르다 ─────────────────
    #   ★★ 왜 갈랐나 — 역본은 **하나하나 라이선스가 다르고**(PD·자유허락·
    #     미확인) 앞으로 유료 역본이 들어올 자리다(§18-3). 「본문·주석·도서」
    #     한 줄에 「KJV / WEB / Berean 등」으로 뭉뚱그리면 어느 역본이 어느
    #     조건인지 말할 수 없고, 역본을 더하는 날 그 줄이 곧 거짓이 된다.
    if str(scope).upper() == 'VERSION':
        rows = [r for r in version_rows() if (r[6] or 0) > 0]
        P(L('ver_intro'))
        SP()
        groups = [('sec_ver_pd', ('PUBLIC_DOMAIN',)),
                  ('sec_ver_ok', ('PERMISSIVE', 'FREE', 'OPEN')),
                  ('sec_ver_chk', None)]        # None = 나머지 전부
        done = set()
        for title, kinds in groups:
            if kinds is None:
                sel = [r for r in rows if r[0] not in done]
            else:
                sel = [r for r in rows if str(r[3]).upper() in kinds]
                done.update(r[0] for r in sel)
            if not sel:
                continue
            H(T(title))
            if kinds is None:
                P(L('ver_chk'))
                SP()
            for code, name, lg, kind, note, url, n in sel:
                B('%s (%s) — %s' % (name, lg, code))
                if note:
                    P(note)
                P('%s%s' % (format(n, ',d'), L('ver_verses')))
                if url:
                    LK(url)
            SP()
        if not rows:
            P(L('ver_none'))
        txt.config(state='disabled')
        return body

    # ── 「이 앱」 탭 — 담는 것 ────────────────────────────────────────
    if str(scope).upper() == 'APP':
        P(L('app_intro'))
        SP()
        H(T('sec_app'))
        B(L('app_prog'))
        P(L('app_prog2'))
        SP()
        H(T('sec_sw'))
        B(L('sw_b1')); B(L('sw_b2'))
        LK('https://www.qt.io/licensing')
        SP()
        H(T('sec_ours'))
        P(L('ours_intro'))
        SP()
        for name, n, chars in our_text_stats(lang):
            B('%s — %s%s · %s%s'
              % (name, format(n, ',d'), L('cnt_unit'),
                 format(chars, ',d'), L('cnt_char')))
        SP()
        P(L('ours_note'))
        SP()
        H(T('sec_trans'))
        P(L('trans_intro'))
        SP()
        B(L('trans_v_o')); B(L('trans_v_m'))
        B(L('trans_v_t')); B(L('trans_v_s'))
        SP()
        P(L('trans_style'))
        txt.config(state='disabled')
        return body

    # ── 지도·지리 ──
    H(T('sec_map'))
    B('OpenBible.info — Bible Geocoding Data')
    P(f"{T('lic')}: Creative Commons Attribution 4.0 (CC-BY 4.0)")
    P(f"{T('use')}: {L('ob_use')}")
    LK('https://www.openbible.info/geo/')
    LK(_LINK_CCBY)
    SP()
    B('OpenStreetMap contributors')
    P(f"{T('lic')}: Open Database License (ODbL 1.0)")
    P(L('osm_use'))
    LK('https://www.openstreetmap.org/copyright')
    SP()
    B('Natural Earth')
    P(f"{T('lic')}: {L('ne_use')}")
    LK('https://www.naturalearthdata.com/')
    SP()
    B('Esri World Imagery')
    P(f"{T('lic')}: Esri (attribution / 출처표시)")
    P(L('esri_use'))
    P('Source: Esri, Maxar, Earthstar Geographics, and the GIS User Community')
    LK('https://www.esri.com/en-us/legal/terms/full-master-agreement')
    SP()
    # ── 본문·주석·도서 ──
    H(T('sec_text'))
    P(L('text_intro'))
    B(L('text_b1')); B(L('text_b2')); B(L('text_b3')); B(L('text_b4'))
    SP()
    # 주요용어의 「낱말이 있는 구절」 목록은 이 자료의 낱말층에서 뽑았다.
    # ⚠⚠ **2026-09-12 부터 스트롱 번호 자체가 배포된다** — `sys_verse_lemma`
    #   가 절마다 「H835 H376 …」을 담는다(`db_lex_link`). 그전에는 절 목록만
    #   나가서 「낱말층은 안 나간다」고 적어 두었는데 이제 사실이 아니다.
    #   ★ CC BY 4.0 은 배포를 **허용**한다 — 조건은 출처 표기뿐이고 그것이
    #     아래 줄이다. **히브리 본문 글자는 여전히 안 싣는다**(번호만).
    B('Open Scriptures Hebrew Bible (OSHB)')
    P(f"{T('lic')}: Creative Commons Attribution 4.0 (CC BY 4.0)")
    P('Morphology and lemma data used to derive word-occurrence verse lists '
      'and the per-verse Strong number index.')
    LK('https://github.com/openscriptures/morphhb')
    SP()
    # 낱말 마스터(sys_lemma_master)의 원자료 — 스트롱 사전 본문(1890)은
    # 퍼블릭 도메인이고, 히브리 XML 파일(교정·정리)이 CC BY 4.0 이다
    # (저장소 readme 명기 — 표기 대상 = Open Scriptures Hebrew Bible Project).
    B("Strong's Hebrew Dictionary XML (Open Scriptures Hebrew Lexicon)")
    P(f"{T('lic')}: text public domain (1890); XML files CC BY 4.0")
    P("Source of the word master table"
      " (Strong's numbers, glosses, parts of speech).")
    LK('https://github.com/openscriptures/HebrewLexicon')
    SP()
    # 히브리 [사전] 층(BDB 갈래) — 188차에 OSHB 개요를 무삭제 전문으로 교체.
    # readme 가 「License: Public domain document」 명기 · 정리 = Eliran Wong.
    B("Brown-Driver-Briggs Hebrew and English Lexicon (1906, unabridged)")
    P(f"{T('lic')}: public domain; digital formatting by Eliran Wong"
      ' (marvel.bible)')
    P('Source of the Hebrew lexicon entries (BDB) for term anchors.')
    LK('https://github.com/eliranwong/unabridged-BDB-Hebrew-lexicon')
    SP()
    # 헬라어 [사전] 층(A-S 갈래) — 저장소 readme 가 퍼블릭 도메인을 명기
    # (마크업 포함). 표기 의무는 없으나 출처를 남긴다 (2026-09-03 186차).
    # 헬라어 [사전] 3층 — NOTICE 가 PUBLIC DOMAIN + 마크업 CC0 명기
    B("Thayer, 'Greek-English Lexicon of the New Testament' (1889)")
    P(f"{T('lic')}: public domain; digital edition dedicated under CC0 1.0")
    P('Source of the in-depth Greek lexicon entries (Thayer) for term anchors.')
    LK('https://github.com/EveryPromiseBible/Every-Promise-Thayers')
    SP()
    B("Abbott-Smith, 'A Manual Greek Lexicon of the New Testament' (1922)")
    P(f"{T('lic')}: public domain (TEI transcription included)")
    P('Source of the Greek lexicon entries (A-S) for term anchors.')
    LK('https://github.com/translatable-exegetical-tools/Abbott-Smith')
    SP()
    B('STEPBible Data — TAGNT / TBESG (Tyndale House Cambridge)')
    P(f"{T('lic')}: Creative Commons Attribution 4.0 (CC BY 4.0)")
    P('Greek New Testament word tagging used to derive word-occurrence verse '
      'lists and the per-verse Strong number index.')
    LK('https://github.com/STEPBible/STEPBible-Data')
    SP()
    B('MACULA Greek / Hebrew Linguistic Datasets (Biblica, Inc.)')
    P(f"{T('lic')}: Creative Commons Attribution 4.0 (CC BY 4.0)")
    P('Septuagint word correspondences and semantic domains used to select term anchors.')
    LK('https://github.com/Clear-Bible/macula-greek')
    SP()
    # ── Project Gutenberg (§1.E.1 이 요구하는 고지) ──
    txt.mark_set('PG', 'end-1c')
    txt.mark_gravity('PG', 'left')
    H(T('sec_pg'))
    P(L('pg_intro'))
    SP()
    txt.insert('end', '   ' + PG_NOTICE + '\n', 'b')
    LK(_LINK_PG_LICENSE)
    LK(_LINK_PG)
    SP()
    P(L('pg_thanks'))
    SP()
    B(L('pg_books'))
    _books = source_books('gutenberg.org', lang)
    if _books:
        for _t, _u in _books:
            P('· ' + _t)
    else:
        P(L('src_none'))
    SP()
    # ── CCEL (자료마다 붙이도록 정해 둔 한 줄) ──
    txt.mark_set('CCEL', 'end-1c')
    txt.mark_gravity('CCEL', 'left')
    H(T('sec_ccel'))
    P(L('ccel_intro'))
    SP()
    txt.insert('end', '   ' + CCEL_NOTICE + '\n', 'b')
    LK(_LINK_CCEL)
    SP()
    B(L('ccel_books'))
    _books = source_books('ccel.org', lang)
    if _books:
        for _t, _u in _books:
            P('· ' + _t)
    else:
        P(L('src_none'))
    SP()
    # ── Internet Archive ──
    txt.mark_set('IA', 'end-1c')
    txt.mark_gravity('IA', 'left')
    H(T('sec_ia'))
    P(L('ia_intro'))
    LK('https://archive.org')
    SP()
    B(L('ia_books'))
    _books = source_books('archive.org', lang)
    if _books:
        for _t, _u in _books:
            P('· ' + _t)
    else:
        P(L('src_none'))
    SP()
    # ── 영상 ──
    H(T('sec_vid'))
    P(L('vid1')); P(L('vid2'))
    SP()
    # ── ★★★ 저작권 신고 (2026-09-08 사용자 지시) ──────────────────────
    #   ⚠ **맨 끝에 둔다** — 자료 목록을 다 읽고 나서 「이건 내 건데?」 할 때
    #     그 자리에서 신고할 수 있어야 한다.
    #   ★ DMCA Safe Harbor 는 **신고받을 주소를 앱 안에 밝히는 것**을 요건으로
    #     든다(`정책자료/DMCA정책표시.txt`). 주소는 `copyright_contact()` 한 문이
    #     낸다 — DB 우선이라 판올림 없이 고칠 수 있다.
    H(T('sec_copy'))
    P(L('cr_intro'))
    B('%s: %s' % (L('cr_addr'), copyright_contact()))
    SP()
    P(L('cr_need'))
    SP()
    P(L('cr_do'))
    P(L('cr_user'))

    txt.config(state='disabled')
    # 부른 쪽이 짚어 준 자리로 데려간다 — 없는 이름은 조용히 무시(맨 위 그대로).
    if section:
        # ⚠ `see` 는 「화면 안에 들어오게」일 뿐이라 아래쪽 절은 바닥에 걸린다.
        #   `yview(mark)` 라야 그 줄이 **맨 위**로 온다.
        try:
            txt.yview(str(section).upper())
        except Exception:
            pass
    return body
