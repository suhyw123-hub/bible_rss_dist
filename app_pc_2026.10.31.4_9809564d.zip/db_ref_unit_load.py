# -*- coding: utf-8 -*-
"""db_ref_unit_load.py — 내부자료 게시판 글 적재 (영구 도구)

무엇을 넣나
    `sys_ref_source`(자료집) → `sys_ref_unit`(글 한 편)
      → `sys_ref_text`(언어별 본문) + `sys_ref_verse_link`(글 ↔ 구절 범위 N개)

    이 네 표는 이미 교리문답·사전·에더샤임을 담고 있던 것이다. 새로 만들지 않았다.
    **글 하나에 본문이 언어마다 따로 붙는 구조**라 다국어가 컬럼 추가 없이 된다
    (`user_ref_asset.lang_code` 만으로는 한국어 글과 영어 글이 서로 남남이 된다).

쓰는 법
    python db_ref_unit_load.py --check   <draft.json>
    python db_ref_unit_load.py --apply   <draft.json>
    python db_ref_unit_load.py --list
    python db_ref_unit_load.py --selftest      ← 탐지력 확인. 결과 보고 전 의무.

초안 형식
    {
      "source": {"src_code": "...", "src_type": "STUDY", "title": "...", "title_ko": "..."},
      "units": [{
         "unit_code": "...", "unit_label": "...", "sequence": 1,
         "texts": {"KO": "본문", "EN": "..."},
         "links":    [{"ref": "창 2:7", "role": "MAIN"}, ...],
         "entities": [{"code": "OBJ_EPHOD", "role": "SUBJECT"}, ...]   ← 선택
      }]
    }

    구절과 엔티티가 **둘 다 여럿**이라 한 글에 두 갈래로 닿는다.
      구절을 눌러도 (P2 내부자료) · 엔티티를 눌러도 (P4 주요용어) 같은 글로 온다.

⚠ `--apply` 는 DB 를 쓴다. 워크트리에서 실행하지 말 것(CLAUDE.md §1).
"""
from __future__ import annotations
import argparse, json, io, os, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb
import scripture_ref_kr as SR

DB = 'bible_master.db'

# 글 ↔ 구절 연결의 성격. 기존 데이터는 PROOF_TEXT 만 쓰고 있었다.
LINK_ROLES = ('MAIN', 'FLOW', 'PROOF_TEXT', 'QUESTION_REF')
# 글 ↔ 엔티티. 사전(Easton·Smith) 289행이 이미 SUBJECT 로 쓰고 있다.
ENTITY_ROLES = ('SUBJECT', 'MENTIONED', 'BACKGROUND')
MIN_BODY   = 200          # 이보다 짧으면 글이 아니라 메모다


# ── 제목 다국어 (2026-08-10) ──────────────────────────────────────────
# `sys_ref_unit.unit_label` 은 칸이 하나라 언어를 못 담는다. 그래서 EN 본문을 넣어도
# 제목만 한국어로 남았다. **`sys_ref_text` 에 `title` 을 더한다** — 그 표가 이미
# 「글 한 편의 언어별 판」이라 본문과 제목이 한 행에 함께 있는 것이 맞고,
# 화면이 고른 본문 행에서 제목을 그대로 꺼내면 본문과 제목의 언어가 절대 어긋나지 않는다.
# (§0-3 규칙1 「병렬 *_text 테이블에 lang_code 행 추가」의 자리다.)
# ⚠ `unit_label` 은 지우지 않는다 — 폴백이고, 관리자 목록이 아직 그것을 읽는다.
def ensure_title_col(conn):
    """멱등. 이미 있으면 아무 일도 하지 않는다.

    ★ **첨부파일도 언어마다다** (2026-08-14 사용자 지시 「첨부파일 (언어별)」).
      한국어 PDF 와 영어 PDF 는 다른 파일이다 — 글(`sys_ref_unit`)이 아니라
      **그 언어 행**에 붙어야 짝이 맞는다.
    ⚠ 이 칸들이 없는 DB 로 열면 조회 SQL 이 통째로 터진다. 화면이 적재 도구보다
      먼저 열릴 수 있으므로 **화면 쪽에서도 이 함수를 부른다**(`panel_*`).
    """
    cols = [r[1] for r in conn.execute('PRAGMA table_info(sys_ref_text)')]
    for col, ddl in (('title', 'TEXT'), ('file_path', 'TEXT')):
        if col not in cols:
            conn.execute('ALTER TABLE sys_ref_text ADD COLUMN %s %s' % (col, ddl))
    conn.commit()
    got = [r[1] for r in conn.execute('PRAGMA table_info(sys_ref_text)')]
    return 'title' in got and 'file_path' in got


def backfill_titles(conn):
    """옛 글의 제목을 **그 자료집의 언어 행에만** 옮겨 적는다.

    ⚠ 모든 언어 행에 같은 제목을 박으면 안 된다 — 사전(EN)은 표제어가 영어고
      우리 연구 글(KO)은 한국어인데, 언어를 가리지 않고 채우면 번역이 다 된 것처럼
      보이면서 영영 안 고쳐진다. 빈 칸으로 두어야 「아직 없다」가 보인다.
    """
    cur = conn.execute('''UPDATE sys_ref_text SET title = (
             SELECT u.unit_label FROM sys_ref_unit u
              WHERE u.ref_unit_id = sys_ref_text.ref_unit_id)
           WHERE (title IS NULL OR title = '')
             AND UPPER(lang_code) = (
             SELECT UPPER(COALESCE(s.lang_code,'EN')) FROM sys_ref_unit u
               JOIN sys_ref_source s ON s.ref_src_id = u.ref_src_id
              WHERE u.ref_unit_id = sys_ref_text.ref_unit_id)''')
    conn.commit()
    return cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0


# ── 검사 ──────────────────────────────────────────────────────────────
def check(conn, draft):
    """반환: (오류 목록, 경고 목록, 해석된 links). 오류가 있으면 적재하지 않는다."""
    err, warn, resolved = [], [], {}

    src = draft.get('source') or {}
    if not src.get('src_code'):
        err.append('source.src_code 가 없다')
    units = draft.get('units') or []
    if not units:
        err.append('units 가 비었다')

    seen_code = set()
    for i, u in enumerate(units):
        tag = f"units[{i}] {u.get('unit_code') or '(코드없음)'}"

        code = (u.get('unit_code') or '').strip()
        if not code:
            err.append(f'{tag}: unit_code 가 없다')
        elif code in seen_code:
            err.append(f'{tag}: unit_code 가 이 초안 안에서 중복이다')
        seen_code.add(code)

        if not (u.get('unit_label') or '').strip():
            err.append(f'{tag}: unit_label 이 없다')

        texts = u.get('texts') or {}
        if not texts:
            err.append(f'{tag}: texts 가 없다')
        for lang, body in texts.items():
            if lang != lang.upper():
                err.append(f'{tag}: lang_code 는 대문자로 — {lang}')
            body = (body or '').strip()
            if not body:
                err.append(f'{tag}[{lang}]: 본문이 비었다')
            elif len(body) < MIN_BODY:
                warn.append(f'{tag}[{lang}]: 본문 {len(body)}자 — {MIN_BODY}자 미만이면 글보다 메모에 가깝다')

        # 제목 다국어 — 본문이 있는 언어에는 제목도 있어야 자연스럽다(2026-08-10)
        titles = u.get('titles') or {}
        for lang in titles:
            if lang != lang.upper():
                err.append(f'{tag}: titles 의 lang_code 는 대문자로 — {lang}')
            elif lang.upper() not in {k.upper() for k in texts}:
                err.append(f'{tag}: 본문 없는 언어에 제목만 있다 — {lang}')
        for lang in texts:
            if not (titles.get(lang) or '').strip():
                warn.append(f'{tag}[{lang}]: 제목이 없다 — 목록에 unit_label 이 그대로 나온다')

        links = u.get('links') or []
        if not links:
            warn.append(f'{tag}: 연결된 구절이 없다 — 어느 구절에서도 이 글이 뜨지 않는다')
        got = []
        for ln in links:
            ref  = (ln.get('ref') or '').strip()
            role = (ln.get('role') or 'PROOF_TEXT').upper()
            if role not in LINK_ROLES:
                err.append(f'{tag}: 모르는 role "{role}" (쓸 수 있는 것: {", ".join(LINK_ROLES)})')
            # ⚠ scripture_ref_kr.resolve 는 실패해도 None 이 아니라 **(None, None)** 을 준다.
            #   튜플이라 `if not rng` 로는 안 걸린다(2026-08-03 자가 검사가 잡음).
            rng = SR.resolve(conn, ref) if ref else (None, None)
            if rng[0] is None:
                err.append(f'{tag}: 구절 참조를 풀 수 없다 — "{ref}"')
            else:
                got.append((rng[0], rng[1], role))
        resolved[code] = got

        # 엔티티 연결(선택). 있으면 코드가 실재하는지 본다 — 없는 코드는 적재 때
        # 조용히 터진다(2026-08-08 신설).
        seen_ent = set()
        for e in (u.get('entities') or []):
            ecode = (e.get('code') or '').strip()
            erole = (e.get('role') or 'SUBJECT').upper()
            if erole not in ENTITY_ROLES:
                err.append(f'{tag}: 모르는 엔티티 role "{erole}" '
                           f'(쓸 수 있는 것: {", ".join(ENTITY_ROLES)})')
            if not ecode:
                err.append(f'{tag}: entities 에 code 가 없다')
                continue
            if ecode in seen_ent:
                err.append(f'{tag}: 엔티티 코드가 이 글 안에서 중복이다 — {ecode}')
            seen_ent.add(ecode)
            if not conn.execute('SELECT 1 FROM sys_entity_master WHERE entity_code=? '
                                "AND COALESCE(record_status,'LIVE')='LIVE'",
                                (ecode,)).fetchone():
                err.append(f'{tag}: 그런 엔티티가 없다 — "{ecode}"')

    return err, warn, resolved


# ── 적재 ──────────────────────────────────────────────────────────────
def apply(conn, draft, resolved):
    ensure_title_col(conn)
    src = draft['source']
    row = conn.execute('SELECT ref_src_id FROM sys_ref_source WHERE src_code=?',
                       (src['src_code'],)).fetchone()
    if row:
        sid = row[0]
        conn.execute('''UPDATE sys_ref_source SET title=COALESCE(?,title),
                          title_ko=COALESCE(?,title_ko), description_ko=COALESCE(?,description_ko)
                        WHERE ref_src_id=?''',
                     (src.get('title'), src.get('title_ko'), src.get('description_ko'), sid))
        print(f"  자료집 기존 것 사용 — {src['src_code']} (id {sid})")
    else:
        cur = conn.execute('''INSERT INTO sys_ref_source
              (src_code, src_type, mapping_type, title, title_ko, lang_code,
               copyright_type, description_ko, record_status)
              VALUES (?,?,?,?,?,?,?,?,'LIVE')''',
              (src['src_code'], src.get('src_type', 'STUDY'),
               src.get('mapping_type', 'VERSE_PERICOPE'),
               src.get('title', src['src_code']), src.get('title_ko'),
               src.get('lang_code', 'KO'), src.get('copyright_type', 'OWN'),
               src.get('description_ko')))
        sid = cur.lastrowid
        print(f"  자료집 신설 — {src['src_code']} (id {sid})")

    n_u = n_t = n_l = n_e = 0
    for u in draft['units']:
        code = u['unit_code'].strip()
        row = conn.execute('SELECT ref_unit_id FROM sys_ref_unit WHERE ref_src_id=? AND unit_code=?',
                           (sid, code)).fetchone()
        if row:
            uid = row[0]
            conn.execute('''UPDATE sys_ref_unit SET unit_label=?, sequence=?, section_code=?,
                              unit_type=?, record_status='LIVE' WHERE ref_unit_id=?''',
                         (u['unit_label'], u.get('sequence', 0), u.get('section_code'),
                          u.get('unit_type', 'ARTICLE'), uid))
        else:
            cur = conn.execute('''INSERT INTO sys_ref_unit
                  (ref_src_id, unit_code, sequence, unit_type, unit_label, section_code, record_status)
                  VALUES (?,?,?,?,?,?,'LIVE')''',
                  (sid, code, u.get('sequence', 0), u.get('unit_type', 'ARTICLE'),
                   u['unit_label'], u.get('section_code')))
            uid = cur.lastrowid
        n_u += 1

        # 본문 — 언어마다 한 행. 다시 적재하면 갈아 끼운다.
        # 제목도 같은 행에 넣는다(`titles`). 없으면 그 언어의 제목은 비고, 화면이
        # `unit_label` 로 폴백한다 — 없는 번역을 있는 척하지 않는다.
        titles = {k.upper(): (v or '').strip()
                  for k, v in (u.get('titles') or {}).items()}
        for lang, body in (u.get('texts') or {}).items():
            conn.execute('''DELETE FROM sys_ref_text WHERE ref_unit_id=? AND lang_code=?
                              AND text_variant=?''', (uid, lang, 'ORIGINAL'))
            conn.execute('''INSERT INTO sys_ref_text
                  (ref_unit_id, text_variant, lang_code, body_text, title, record_status)
                  VALUES (?,?,?,?,?,'LIVE')''',
                  (uid, 'ORIGINAL', lang, body.strip(),
                   titles.get(lang.upper()) or None))
            n_t += 1

        # 구절 연결 — 통째로 다시 깐다(부분 갱신은 유령 링크를 남긴다)
        # ★ 2026-08-24 통합 표(`REFU_VERS`). ⚠ link_type 을 걸어야 그 글의
        #   **구절 연결만** 지운다(용어·도서 연결까지 지우면 안 된다).
        conn.execute("DELETE FROM sys_link_asset "
                     " WHERE link_type='REFU_VERS' AND clicked_id=?", (uid,))
        for order, (sv, ev, role) in enumerate(resolved[code]):
            conn.execute("INSERT OR IGNORE INTO sys_link_asset"
                         " (link_type, clicked_id, target_id, end_id, rel_code,"
                         "  sort_order, record_status)"
                         " VALUES ('REFU_VERS',?,?,?,?,?,'LIVE')",
                         (uid, sv, ev, role, order))
            n_l += 1

        # 엔티티 연결 — 구절과 같은 방식으로 통째로 다시 깐다.
        # ★ 2026-08-24 — 통합 표 `sys_link_asset(link_type='REFU_ENTI')` 로 옮겼다.
        #   ⚠ 지우는 범위를 `link_type` 으로 못 박는다. 안 그러면 이 글에 걸린
        #     **구절 연결까지** 함께 지운다.
        ents = u.get('entities') or []
        if ents:
            conn.execute("DELETE FROM sys_link_asset "
                         " WHERE link_type='REFU_ENTI' AND clicked_id=?", (uid,))
        for e in ents:
            r = conn.execute('SELECT entity_id FROM sys_entity_master WHERE entity_code=?',
                             (e['code'],)).fetchone()
            conn.execute("INSERT OR IGNORE INTO sys_link_asset"
                         " (link_type, clicked_id, target_id, rel_code, record_status)"
                         " VALUES ('REFU_ENTI',?,?,?,'LIVE')",
                         (uid, r[0], (e.get('role') or 'SUBJECT').upper()))
            n_e += 1

    conn.commit()
    print(f'  글 {n_u}편 · 본문 {n_t}행 · 구절 연결 {n_l}개 · 엔티티 연결 {n_e}개')


# ── 자가 검사 ─────────────────────────────────────────────────────────
def selftest(conn):
    """일부러 흠집 낸 초안에서 검사가 실제로 잡아내는지 본다.
    가드가 없으면 검사기가 조용히 전부 통과시키는 일이 실제로 있었다(§18-9)."""
    good_body = '가' * (MIN_BODY + 10)
    cases = [
        ('정상',              {'source': {'src_code': 'T'}, 'units': [
            {'unit_code': 'A', 'unit_label': 'ㄱ', 'texts': {'KO': good_body},
             'links': [{'ref': '창 2:7', 'role': 'MAIN'}]}]}, 0),
        ('본문 빈 것',        {'source': {'src_code': 'T'}, 'units': [
            {'unit_code': 'A', 'unit_label': 'ㄱ', 'texts': {'KO': '  '},
             'links': [{'ref': '창 2:7'}]}]}, 1),
        ('풀리지 않는 구절',  {'source': {'src_code': 'T'}, 'units': [
            {'unit_code': 'A', 'unit_label': 'ㄱ', 'texts': {'KO': good_body},
             'links': [{'ref': '없는책 9:9'}]}]}, 1),
        ('모르는 role',       {'source': {'src_code': 'T'}, 'units': [
            {'unit_code': 'A', 'unit_label': 'ㄱ', 'texts': {'KO': good_body},
             'links': [{'ref': '창 2:7', 'role': 'WHATEVER'}]}]}, 1),
        ('unit_code 중복',    {'source': {'src_code': 'T'}, 'units': [
            {'unit_code': 'A', 'unit_label': 'ㄱ', 'texts': {'KO': good_body},
             'links': [{'ref': '창 2:7'}]},
            {'unit_code': 'A', 'unit_label': 'ㄴ', 'texts': {'KO': good_body},
             'links': [{'ref': '창 2:9'}]}]}, 1),
        ('소문자 lang_code',  {'source': {'src_code': 'T'}, 'units': [
            {'unit_code': 'A', 'unit_label': 'ㄱ', 'texts': {'ko': good_body},
             'links': [{'ref': '창 2:7'}]}]}, 1),
        ('src_code 없음',     {'source': {}, 'units': [
            {'unit_code': 'A', 'unit_label': 'ㄱ', 'texts': {'KO': good_body},
             'links': [{'ref': '창 2:7'}]}]}, 1),
        ('unit_label 없음',   {'source': {'src_code': 'T'}, 'units': [
            {'unit_code': 'A', 'unit_label': '', 'texts': {'KO': good_body},
             'links': [{'ref': '창 2:7'}]}]}, 1),
        # 엔티티 연결 (2026-08-08) — 없는 코드를 그냥 두면 적재 때 조용히 터진다
        ('엔티티 정상',       {'source': {'src_code': 'T'}, 'units': [
            {'unit_code': 'A', 'unit_label': 'ㄱ', 'texts': {'KO': good_body},
             'links': [{'ref': '창 2:7'}],
             'entities': [{'code': 'OBJ_ARK', 'role': 'SUBJECT'}]}]}, 0),
        ('없는 엔티티 코드',  {'source': {'src_code': 'T'}, 'units': [
            {'unit_code': 'A', 'unit_label': 'ㄱ', 'texts': {'KO': good_body},
             'links': [{'ref': '창 2:7'}],
             'entities': [{'code': 'OBJ_NOSUCH'}]}]}, 1),
        ('모르는 엔티티 role', {'source': {'src_code': 'T'}, 'units': [
            {'unit_code': 'A', 'unit_label': 'ㄱ', 'texts': {'KO': good_body},
             'links': [{'ref': '창 2:7'}],
             'entities': [{'code': 'OBJ_ARK', 'role': 'WHATEVER'}]}]}, 1),
        ('엔티티 코드 중복',  {'source': {'src_code': 'T'}, 'units': [
            {'unit_code': 'A', 'unit_label': 'ㄱ', 'texts': {'KO': good_body},
             'links': [{'ref': '창 2:7'}],
             'entities': [{'code': 'OBJ_ARK'}, {'code': 'OBJ_ARK'}]}]}, 1),
        # 제목 다국어 (2026-08-10) — 본문 없는 언어에 제목만 두면 목록과 본문이 어긋난다
        ('제목 정상',         {'source': {'src_code': 'T'}, 'units': [
            {'unit_code': 'A', 'unit_label': 'ㄱ', 'texts': {'KO': good_body},
             'titles': {'KO': '한글 제목'}, 'links': [{'ref': '창 2:7'}]}]}, 0),
        ('본문 없는 언어 제목', {'source': {'src_code': 'T'}, 'units': [
            {'unit_code': 'A', 'unit_label': 'ㄱ', 'texts': {'KO': good_body},
             'titles': {'EN': 'Title'}, 'links': [{'ref': '창 2:7'}]}]}, 1),
        ('소문자 titles lang', {'source': {'src_code': 'T'}, 'units': [
            {'unit_code': 'A', 'unit_label': 'ㄱ', 'texts': {'KO': good_body},
             'titles': {'ko': '한글 제목'}, 'links': [{'ref': '창 2:7'}]}]}, 1),
    ]
    ok = True
    for name, draft, want in cases:
        err, warn, _ = check(conn, draft)
        hit = 1 if err else 0
        mark = 'OK ' if hit == want else 'X  '
        if hit != want:
            ok = False
        print(f'  {mark}{name:<16} 오류 {len(err)}건 {("· " + err[0]) if err else ""}')
    # 경고 두 갈래가 각각 살아 있나 — ⚠ 「warn 이 비지 않았다」로 보면 안 된다.
    #   제목 경고가 늘 붙으므로 그것만으로 구절 경고가 살아 있는 줄 착각하게 된다.
    _, warn, _ = check(conn, {'source': {'src_code': 'T'}, 'units': [
        {'unit_code': 'A', 'unit_label': 'ㄱ', 'texts': {'KO': good_body}, 'links': []}]})
    for want, label in (('연결된 구절이 없다', '구절 연결 없음 경고'),
                        ('제목이 없다', '제목 없음 경고')):
        hit = next((w for w in warn if want in w), None)
        if hit:
            print(f'  OK {label:<16} · {hit}')
        else:
            print(f'  X  {label} 가 없다'); ok = False
    print('\n  자가 검사 PASS' if ok else '\n  자가 검사 FAIL')
    return ok


# ── CLI ───────────────────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--check');  ap.add_argument('--apply')
    ap.add_argument('--list', action='store_true')
    ap.add_argument('--titles-init', action='store_true',
                    help='sys_ref_text.title 칸을 만들고 옛 제목을 그 언어 행에 옮겨 적는다(멱등)')
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--db', default=DB)
    a = ap.parse_args()
    conn = appdb.connect(a.db)

    if a.selftest:
        sys.exit(0 if selftest(conn) else 1)

    if getattr(a, 'titles_init', False):
        ensure_title_col(conn)
        print('sys_ref_text.title 준비 · 옛 제목 %d행 옮겨 적음' % backfill_titles(conn))
        got = conn.execute("SELECT COUNT(*) FROM sys_ref_text"
                           " WHERE title IS NOT NULL AND title<>''").fetchone()[0]
        tot = conn.execute('SELECT COUNT(*) FROM sys_ref_text').fetchone()[0]
        print('제목 있는 행 %d / %d' % (got, tot))
        return

    if a.list:
        print('자료집 (sys_ref_source)')
        for r in conn.execute('''SELECT s.ref_src_id, s.src_code, COALESCE(s.title_ko,s.title),
                 (SELECT COUNT(*) FROM sys_ref_unit u WHERE u.ref_src_id=s.ref_src_id
                    AND u.record_status='LIVE')
               FROM sys_ref_source s WHERE s.record_status='LIVE' ORDER BY s.ref_src_id'''):
            print('  %3d  %-18s %-34s 글 %d편' % r)
        return

    path = a.check or a.apply
    if not path:
        ap.print_help(); return
    draft = json.load(io.open(path, encoding='utf-8'))

    err, warn, resolved = check(conn, draft)
    for w in warn:
        print('  ! ' + w)
    for e in err:
        print('  X ' + e)
    if err:
        print(f'\n검증 FAIL — 오류 {len(err)}건'); sys.exit(1)
    print(f'검증 PASS — 글 {len(draft["units"])}편')
    for u in draft['units']:
        n = len(resolved[u['unit_code']])
        langs = ','.join(sorted((u.get('texts') or {}).keys()))
        tl = ','.join(sorted((u.get('titles') or {}).keys())) or '-'
        print(f'  {u["unit_code"]:<14} {u["unit_label"][:30]:<32} '
              f'본문[{langs}] · 제목[{tl}] · 구절 {n}개')

    if a.apply:
        print()
        apply(conn, draft, resolved)
        print('\n적재 완료.')


if __name__ == '__main__':
    main()
