# -*- coding: utf-8 -*-
"""db_term_pipeline.py — 용어를 담은 뒤 도는 후속작업 한 걸음 (영구, 2026-09-07).

사용자 지시: 「**용어 추출의 후속작업을 한 프로세스로 결합하는 것은 매우 좋은
제안이다**」. 그 앞의 물음이 계기다 — 「지금 연결하는 것이 효율적인가 나중에
한꺼번에 하는 것이 효율적인가」.

★★★ **실측이 답을 정했다**(2026-09-07):
    스캔 0.4초                       ← 기계 비용은 사실상 0
    후보가 하나뿐인 편 544 / 771 = 71%  ← 몰아서 아낄 것이 거의 없다
  ⇒ **몰아서 하는 이득이 없고 미루는 손해만 있다.** 그렇다면 남는 문제는
    「할 때마다 무엇무엇을 도는지 기억하는 것」이고, **기억에 의존하는 절차는
    반드시 빠진다**(§205차 C 가 적어 둔 그 자리). 그래서 절차를 코드로 못 박는다.

★★ **이 파일이 「용어를 담은 뒤 무엇을 도는가」의 단일 소스다.**
  걸음을 늘리려면 `STEPS` 에 한 줄 더한다 — 문서에만 적으면 다음에 빠진다.

걸음 (차례가 뜻이 있다):
  ① 축          `db_term_axis --apply`        새 용어에 축을 준다
  ② 관문        `db_gateway_link --apply`     관문에 소속을 잇는다
  ③ 흐름        `db_word_chain --apply`       낱말 ↔ 구속사 흐름
  ④ 재추출      `db_media_range --resweep`    보관함에서 새 용어로 풀리는 것
  ⑤ 도서 후보    (세기만 한다)                  사람이 채택할 목록의 크기
  ⑥ 점검        무결성·이름의 뜻·비어 있는 칸

⚠ **④는 새 용어가 늘면 값이 달라진다** — 보관함에 「제목에 그 용어가 있는데
  이을 데가 없어」 남아 있던 것이 풀린다. 그래서 ①②③ 뒤에 온다.
⚠ **⑤는 잇지 않는다** — 도서 연결은 「그 유닛의 주제인가」를 사람이 본다
  (§205차 · `db_book_entity_link.adopt` 가 채택 칸이 빈 줄을 건너뛴다).
  이 걸음은 **크기를 알려 줄 뿐**이다.
⚠ **막히면 멈추지 않고 다음 걸음으로 간다** — 한 도구가 실패해도 나머지는
  돌아야 한다. 실패는 끝에 모아서 말한다(§0-1 조용한 실패 금지).

사용:  python db_term_pipeline.py --selftest | --dry | --run
"""
import sys

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

#: **걸음 표 — 단일 소스.** (이름, 함수 이름, 설명)
#: ⚠ 함수는 `(conn, dry) -> str` 를 지킨다. 돌려주는 글이 곧 보고다.
STEPS = (
    ('축',      '_step_axis',    '새 용어에 축을 준다'),
    ('관문',    '_step_gate',    '관문(하나님의 속성 등)에 소속을 잇는다'),
    ('흐름',    '_step_chain',   '낱말 ↔ 구속사 흐름'),
    ('재추출',  '_step_resweep', '보관함에서 새 용어로 풀리는 것'),
    ('도서후보', '_step_book',    '사람이 채택할 도서 연결 후보의 크기'),
    ('점검',    '_step_audit',   '비어 있는 칸을 센다'),
)


def _step_axis(conn, dry):
    import db_term_axis as TA
    todo, miss, _same = TA.check(conn)
    if dry:
        return '축 없는 용어 %d · 초안 밖 %d' % (len(todo), len(miss))
    n = TA.apply_draft(conn)
    return '축을 담은 것 %d (남은 것 %d — 초안에 안 적힌 용어)' % (n, len(miss))


def _step_gate(conn, dry):
    import db_gateway_link as GW
    bad, todo, have = GW.check(conn)
    if bad:
        return '문제 %d — %s' % (len(bad), bad[0])
    if dry:
        return '이을 것 %d · 이미 있는 것 %d' % (len(todo), len(have))
    n = GW.apply(conn)
    return '이은 것 %d · 이미 있던 것 %d' % (n, len(have))


def _step_chain(conn, dry):
    import db_word_chain as WC
    auto, review = WC.candidates(conn)
    if dry:
        return '자동 %d · 검토 %d' % (len(auto), len(review))
    n = WC.apply(conn)
    return '이은 것 %d · 검토 %d (사람이 MANUAL 에 적는다)' % (n, len(review))


def _step_resweep(conn, dry):
    import db_media_range as MR
    if dry:
        n = conn.execute("SELECT COUNT(*) FROM sys_media_pending WHERE "
                         "COALESCE(record_status,'LIVE')='LIVE'").fetchone()[0]
        return '보관함 %d건 (돌려야 몇 건이 풀리는지 안다)' % n
    try:
        r = MR.resweep(conn)
    except TypeError:
        r = MR.resweep()
    return '풀린 것 %s' % (r if r is not None else '?')


def _step_book(conn, dry):
    """대표 구절을 다리로 놓은 도서 연결 후보의 크기 — **잇지 않는다.**"""
    import db_term_load as TL
    keyv = {}
    for (eid,) in conn.execute(
            "SELECT entity_id FROM sys_entity_master WHERE entity_type='TERM'"
            " AND record_status='LIVE' AND COALESCE(json_extract("
            "json_detail,'$.subtype'),'')<>'LEX'"):
        k = {v[0] for v in TL.fetch_verses(conn, eid) if v[2]}
        if k:
            keyv[eid] = k
    units = list(conn.execute(
        "SELECT unit_id, start_vid, end_vid FROM sys_book_unit "
        "WHERE start_vid IS NOT NULL AND start_vid>0"))
    pairs = set()
    for eid, ks in keyv.items():
        for uid, s, e in units:
            e = e or s
            if any(s <= v <= e for v in ks):
                pairs.add((uid, eid))
    cur = {(r[0], r[1]) for r in conn.execute(
        "SELECT clicked_id, target_id FROM sys_link_asset WHERE "
        "link_type='BUNT_ENTI' AND COALESCE(record_status,'LIVE')='LIVE'")}
    return ('후보 %d짝 · 이미 이은 것 %d · 합치면 %d '
            '(사람이 채택한다 — db_book_entity_link)'
            % (len(pairs), len(cur), len(pairs | cur)))


def _step_audit(conn, dry):
    """비어 있는 칸 — **채우라는 뜻이지 오류가 아니다.**"""
    import db_term_load as TL
    import db_term_axis as TA
    n = miss_desc = miss_anchor = miss_key = miss_axis = 0
    for eid, _code in conn.execute(
            "SELECT entity_id, entity_code FROM sys_entity_master WHERE "
            "entity_type='TERM' AND record_status='LIVE' AND COALESCE("
            "json_extract(json_detail,'$.subtype'),'')<>'LEX'"):
        n += 1
        for lg in ('KO', 'EN'):
            if not conn.execute(
                    "SELECT 1 FROM sys_text_asset WHERE text_type="
                    "'ENTITY_DESC' AND clicked_id=? AND lang_code=? LIMIT 1",
                    (eid, lg)).fetchone():
                miss_desc += 1
                break
        if not conn.execute("SELECT 1 FROM sys_entity_lemma WHERE entity_id=?"
                            " LIMIT 1", (eid,)).fetchone():
            miss_anchor += 1
        if not any(v[2] for v in TL.fetch_verses(conn, eid)):
            miss_key += 1
        if not TA.axis_of(conn, eid):
            miss_axis += 1
    return ('용어 %d — 설명 없음 %d · 앵커 없음 %d · 대표 없음 %d · 축 없음 %d'
            % (n, miss_desc, miss_anchor, miss_key, miss_axis))


def run(conn, dry=False):
    """걸음을 차례로 돈다 → (보고 줄들, 실패 목록)."""
    lines, bad = [], []
    for name, fn, _why in STEPS:
        f = globals().get(fn)
        if f is None:
            bad.append('%s — 함수 %s 없음' % (name, fn))
            continue
        try:
            lines.append('%-8s %s' % (name, f(conn, dry)))
        except Exception as e:
            # ⚠ **막혀도 멈추지 않는다** — 한 걸음이 실패해도 나머지는 돈다.
            bad.append('%s — %s' % (name, e))
            lines.append('%-8s ✕ %s' % (name, e))
    return lines, bad


# ── 자가 검증 ───────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    t('★ 걸음 표가 단일 소스', len(STEPS) >= 5, len(STEPS))
    t('  걸음마다 함수가 있다',
      all(callable(globals().get(f)) for _n, f, _w in STEPS),
      [f for _n, f, _w in STEPS if not callable(globals().get(f))])
    t('  이름이 안 겹친다',
      len({n for n, _f, _w in STEPS}) == len(STEPS))
    t('★ 걸음마다 왜 도는지 적혀 있다',
      all(len(w) > 5 for _n, _f, w in STEPS))
    # 차례 — 재추출은 잇는 걸음 뒤에 온다
    order = [n for n, _f, _w in STEPS]
    t('★ 재추출이 잇는 걸음 뒤다',
      order.index('재추출') > max(order.index('축'), order.index('관문'),
                                  order.index('흐름')), order)
    t('  점검이 맨 뒤', order[-1] == '점검', order[-1])

    # ⚠ **막혀도 멈추지 않는가** — 걸음 하나를 일부러 터뜨려 잰다
    def _boom(conn, dry):
        raise RuntimeError('시험용')
    globals()['_step_boom'] = _boom
    old = globals()['STEPS']
    try:
        globals()['STEPS'] = (('폭탄', '_step_boom', '시험'),
                              ('뒤', '_step_book', '시험'))
        lines, bad = run(None, dry=True)
        t('★ 한 걸음이 터져도 다음 걸음이 돈다', len(lines) == 2, len(lines))
        # ⚠ 뒤 걸음도 `conn=None` 이라 함께 실패한다 — **터진 걸음이 목록에
        #   들어 있는가**를 잰다(개수를 못 박으면 시험이 헛돈다).
        t('  실패를 조용히 넘기지 않는다',
          any('폭탄' in x for x in bad), bad)
    finally:
        globals()['STEPS'] = old
        globals().pop('_step_boom', None)

    # ⚠ `--dry` 는 한 글자도 안 쓴다
    src = open(__file__, encoding='utf-8').read()
    t('★ dry 에서는 apply 를 안 부른다',
      src.count('if dry:') >= 4, src.count('if dry:'))
    # ⚠⚠ **찾는 글자를 검사 코드에 그대로 적으면 자기가 걸린다**(§199차) —
    #   조립해서 만든다.
    _ins = 'INS' + 'ERT'
    t('  도서 걸음은 잇지 않는다',
      ('ado' + 'pt(') not in src and _ins not in src.upper(),
      src.upper().count(_ins))

    print('db_term_pipeline selftest: %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect()
    dry = '--run' not in a
    print('■ 용어 후속작업 %s' % ('(재 보기만 — 넣으려면 --run)' if dry else ''))
    lines, bad = run(conn, dry=dry)
    for ln in lines:
        print('  ' + ln)
    if not dry:
        conn.commit()
    if bad:
        print('\n막힌 걸음 %d:' % len(bad))
        for b in bad:
            print('  ✕ %s' % b)
        sys.exit(1)
