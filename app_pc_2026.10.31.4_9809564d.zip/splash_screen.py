# -*- coding: utf-8 -*-
"""splash_screen.py — 실행 즉시(1초 이내) 뜨는 첫 화면.
배경 사진(런타임은 PNG만, PIL 불필요) + 오늘의 구절을 덧입혀 표시하고,
그 사이에 본체 앱 위젯을 만든다. 무거운 import보다 '먼저' 호출돼야 효과 있음.

런타임 의존성: 표준 tkinter/json/os 뿐 (PIL·외부 라이브러리 없음).
사진은 미리 PNG로 스케일된 것을 쓴다(원본 폰 사진은 오프라인에서 다운스케일 — splash_prep 참조).
"""
import os, json
import tkinter as tk

# 설치 경로 독립(2026-07-30): 캐시 파일을 상대명으로 두면 CWD 기준이라
# 바로가기 '시작 위치'가 다르면 사진·구절 캐시를 못 찾고 매번 폴백이 뜬다.
# appdb 를 import 하지 않는다 — 이 모듈은 '가장 먼저·가장 가볍게' 떠야 한다(표준 lib 만).
_APP_DIR = os.path.dirname(os.path.abspath(__file__))


def _app(*parts):
    """앱 폴더 기준 절대경로."""
    return os.path.join(_APP_DIR, *parts)


# 캐시된 오늘의 구절이 없을 때 폴백(첫 실행 등)
DEFAULT_REF = '잠언 3:5'
DEFAULT_TEXT = '너는 마음을 다하여 여호와를 신뢰하고\n네 명철을 의지하지 말라'


def _load_verse(path):
    try:
        with open(path, encoding='utf-8') as f:
            d = json.load(f)
        return (d.get('ref') or ''), (d.get('text') or '')
    except Exception:
        return '', ''


def _load_btn_words(path=None):
    """단추 두 글자 `(준비 중, 바로 시작)` — 캐시에 없으면 한국어 기본."""
    try:
        with open(path or _app('splash_verse.json'), encoding='utf-8') as f:
            d = json.load(f)
        return ((d.get('wait') or GO_WAIT), (d.get('go') or GO_READY))
    except Exception:
        return GO_WAIT, GO_READY


# ★★★ **라벨은 사진을 덮지 않는다** (2026-09-05 사용자 지시 — 「사진을 전혀
#   덮지 않고 **외부에 표시**하는 방식이어야 한다」).
#   ⇒ 사진은 사진대로 온전히 보이고, 글은 그 **위 또는 아래 띠**에 앉는다.
#   ⚠ 그래서 `pos` 가 **top/bottom 둘**로 줄었다 — `center` 는 사진 한가운데를
#     덮는 자리라 이 원칙과 함께 설 수 없다(옛 저장값은 bottom 으로 읽는다).
# ★★ **띠 색은 사진과 다투지 않는 중립 하나**(사용자 — 「강/바다/광야/밤하늘에
#   따라 느낌이 완전히 달라진다. 여러 상황에서 가장 무난한 디자인」).
#   어떤 사진 옆에 놓여도 사진이 주인공으로 남는 짙은 회색이다.
BAR_BG = '#1C1C1E'
BAR_FG = '#F2F2F2'
BAR_DIM = '#9A9A9E'
BAR_H = 84                     # 띠 기본 높이 — 사진 높이에 **더한다**(안 깎는다)
BAR_H_MAX = 180                # 긴 구절일 때 늘어나는 한계

# ★★ **시작화면을 아예 안 볼 수도 있다** (2026-09-05 사용자 지시 —
#   「시작화면 표시여부: 표시/표시안함(SKIP을 선택하면 시작화면 없이 곧장 앱
#    실행)」). ⚠ 스플래시는 **앱보다 먼저** 뜨므로 DB 를 못 연다(§34) —
#   그래서 이 값도 파일 캐시(`splash_style.json`)에 담는다.
# ★ 사용자가 정하는 값 — **띠 배경색과 설명 글꼴 크기도 포함**
#   (2026-09-05 지시 「구절라벨 **배경색도 선택**하도록」·「**설명문의 폰트를
#    사용자가 조절**해야 한다」).
# ⚠⚠ **여기 키를 안 넣으면 파일에 저장돼도 안 읽힌다** — `load_style` 이
#   `for k in _STYLE_DEFAULT` 로 도므로 **이 표에 없는 키는 통째로 무시**된다.
#   실측으로 잡았다(색은 먹는데 bg·desc_size 만 안 먹었다).
_STYLE_DEFAULT = {'pos': 'bottom', 'color': BAR_FG, 'size': 18,
                  'font': 'Malgun Gothic', 'show': 1,
                  'bg': BAR_BG, 'desc_size': 10}


def load_style(path=None):
    """구절 표시 스타일(위치·색·크기·폰트). 사용자가 환경설정에서 수정 → 다음 실행 반영."""
    path = path or _app('splash_style.json')
    st = dict(_STYLE_DEFAULT)
    try:
        with open(path, encoding='utf-8') as f:
            d = json.load(f)
        for k in st:
            if d.get(k) not in (None, ''):
                st[k] = d[k]
        st['size'] = int(st['size'])
        st['show'] = 1 if int(st.get('show', 1)) else 0
        st['desc_size'] = int(st.get('desc_size', 10))
    except Exception:
        pass
    if st.get('show') not in (0, 1):
        st['show'] = 1
    # ⚠ 옛 저장값 `center` 는 **사진을 덮는 자리**라 폐기했다 — 아래로 읽는다.
    if st['pos'] not in ('top', 'bottom'):
        st['pos'] = 'bottom'
    if not str(st.get('bg') or '').startswith('#'):
        st['bg'] = BAR_BG
    try:
        if not (7 <= int(st.get('desc_size') or 10) <= 28):
            st['desc_size'] = 10
    except Exception:
        st['desc_size'] = 10
    return st


def save_style(pos=None, color=None, size=None, font=None, path=None,
               show=None, bg=None, desc_size=None):
    path = path or _app('splash_style.json')
    st = load_style(path)
    if pos:   st['pos'] = pos
    if color: st['color'] = color
    if size:  st['size'] = int(size)
    if font:  st['font'] = font
    if bg:    st['bg'] = bg
    if desc_size: st['desc_size'] = int(desc_size)
    # ⚠ `show` 는 0 이 뜻 있는 값이라 `if show:` 로 걸면 **끄기가 저장 안 된다**.
    if show is not None:
        st['show'] = 1 if int(show) else 0
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(st, f, ensure_ascii=False)
    except Exception:
        pass
    return st


# ★ 단추 두 상태 — **이름이 곧 상태다**(잠긴 회색 단추에 「시작」이라 쓰지 않는다)
GO_WAIT = '준비 중…'
GO_READY = '바로 시작 ▸'


def _photo_path(path=None):
    return path or _app('splash_photo.json')


def save_photo_caption(title='', desc='', path=None):
    """사진의 **제목과 설명**을 캐시에 적는다 — 다음 실행의 띠가 읽는다.

    ⚠ **비면 파일을 지운다** — 낡은 설명이 딴 사진에 붙으면 거짓말이 된다.
    ⚠ 나라·대륙은 여기 안 담는다 — 그 칸들은 **거르는 값**이고, 사용자가
      읽을 말은 제목·설명이 다국어로 담는다(사용자 지시).
    """
    p = _photo_path(path)
    parts = [x for x in (title, desc) if (x or '').strip()]
    try:
        if not parts:
            if os.path.exists(p):
                os.remove(p)
            return True
        with open(p, 'w', encoding='utf-8') as f:
            json.dump({'title': title or '', 'desc': desc or ''},
                      f, ensure_ascii=False)
        return True
    except Exception:
        return False


def _load_photo_caption(path=None):
    """`제목 · 설명` 한 줄. 없으면 빈 문자열(줄을 안 만든다)."""
    try:
        with open(_photo_path(path), encoding='utf-8') as f:
            d = json.load(f)
        # ⚠ 옛 캐시(`name`)도 읽는다 — 판을 올렸다고 설명이 사라지면 안 된다.
        parts = [str(d.get(k) or '').strip()
                 for k in ('title', 'name', 'desc')]
        seen, out = set(), []
        for x in parts:
            if x and x not in seen:
                seen.add(x)
                out.append(x)
        return ' · '.join(out)
    except Exception:
        return ''


def _fit_one_line(lbl, text, px):
    """라벨을 **한 줄**로 맞춘다 — 넘치면 뒤를 잘라 `…` 를 붙인다.

    ⚠ Tk 라벨에는 자동 줄임이 없다. `wraplength` 를 주면 두 줄이 되므로
      **글자를 직접 줄인다**(사용자 지시 「딱 한 줄만」).
    """
    try:
        import tkinter.font as _tkf
        fo = _tkf.Font(font=lbl.cget('font'))
        if fo.measure(text) <= px:
            return
        lo, hi = 0, len(text)
        while lo < hi:
            mid = (lo + hi) // 2
            if fo.measure(text[:mid] + '…') <= px:
                lo = mid + 1
            else:
                hi = mid
        lbl.configure(text=(text[:max(1, lo - 1)] + '…'))
    except Exception:
        pass


# ── 시작화면 홍보 배너 — **파일 캐시만 읽는다**(§34) ─────────────
#: 띄 높이 — 한 줄이다. 사진을 밀어내지 않을 만큼만 받는다.
BANNER_H = 52
#: 그림 높이 상한(미리 줄여 둔다 — 스플래시가 리사이즈하지 않는다)
BANNER_IMG_H = 36


def _banner_path(path=None):
    return path or _app('splash_banner.json')


def load_banner(path=None):
    """다음 실행에 보일 배너 한 개 → dict 또는 None.

    ⚠ **글도 그림도 없으면 None** — 부르는 쪽이 「띄를 안 만든다」로
      읽을 수 있게 한다(빈 띄를 그리면 사진만 낮아진다).
    ⚠ 그림 파일이 사라졌으면 **글만** 낸다(지어내지 않는다).
    """
    try:
        with open(_banner_path(path), encoding='utf-8') as f:
            d = json.load(f)
    except Exception:
        return None
    if not isinstance(d, dict):
        return None
    text = (d.get('text') or '').strip()
    img = (d.get('img') or '').strip()
    if img and not os.path.exists(img):
        img = ''
    if not text and not img:
        return None
    return {'text': text, 'img': img,
            'click': (d.get('click') or '').strip(),
            'note': (d.get('note') or '').strip()}


def save_banner(text='', click='', img='', note='', path=None):
    """배너 캐시를 적는다. 비우려면 인자 없이 부른다(파일을 지운다)."""
    p = _banner_path(path)
    if not (text or '').strip() and not (img or '').strip():
        try:
            os.remove(p)
        except Exception:
            pass
        return True
    try:
        with open(p, 'w', encoding='utf-8') as f:
            json.dump({'text': text, 'click': click, 'img': img,
                       'note': note}, f, ensure_ascii=False)
        return True
    except Exception:
        return False


def refresh_banner_cache(db, lang='KO', out_img=None, path=None):
    """본체 앱이 부른다 — `ad-config` 의 `splash` 슬롯에서 한 개를 선택해
    **다음 실행**의 시작화면이 읽을 캐시를 적는다.

    ★ 고르는 문은 `ads.pick_creatives` **하나**다 — 슬롯 스위치·게재
      기간·언어·국가를 다시 적지 않는다(두 벌이 되면 반드시 갈린다).
    ⚠ 고를 것이 없으면 **캐시를 지운다** — 어제 끝난 행사가 내일까지
      뜨면 안 된다.
    ⚠ 그림은 **여기서 미리 받아 PNG 로 줄여 둔다** — 스플래시는 망도
      PIL 도 안 쓴다(§34). PIL 이 없거나 받기가 실패하면 **글만** 적는다.
    """
    out_img = out_img or _app('splash', 'banner.png')
    try:
        import ads
        picks = ads.pick_creatives(db, 'splash', lang, ads.get_country(db))
    except Exception:
        picks = []
    if not picks:
        save_banner(path=path)
        try:
            os.remove(out_img)
        except Exception:
            pass
        return False
    c = picks[0]
    text = (c.get('desc') or '').strip()
    img_path = ''
    url = (c.get('image') or '').strip()
    if url:
        try:
            import ads as _ads
            im = _ads._fetch_image(url)      # PIL.Image 또는 None
            if im is not None:
                w, h = im.size
                if h > BANNER_IMG_H:
                    im = im.resize((max(1, int(w * BANNER_IMG_H / h)),
                                    BANNER_IMG_H))
                os.makedirs(os.path.dirname(out_img) or '.', exist_ok=True)
                im.save(out_img, 'PNG')
                img_path = out_img
        except Exception:
            img_path = ''
    if not text and not img_path:
        save_banner(path=path)
        return False
    return save_banner(text=text, click=(c.get('click') or '').strip(),
                       img=img_path, note=(c.get('id') or ''), path=path)


def _build_banner(win, bn, width, bg):
    """배너 띄 하나를 지어 돌려준다(패킹은 부르는 쪽이 한다)."""
    fr = tk.Frame(win, bg=bg, height=BANNER_H)
    fr.pack_propagate(False)
    inner = tk.Frame(fr, bg=bg)
    inner.pack(expand=True)
    if bn['img']:
        try:
            ph = tk.PhotoImage(file=bn['img'])
            lbl = tk.Label(inner, image=ph, bg=bg, bd=0)
            lbl.image = ph            # GC 방지 — 참조를 놓치면 빈 칸이 된다
            lbl.pack(side='left', padx=(0, 10))
        except Exception:
            pass
    if bn['text']:
        tk.Label(inner, text=bn['text'], bg=bg, fg=BAR_FG,
                 font=('Malgun Gothic', 10)).pack(side='left')
    if bn['click']:
        def _open(_e=None):
            try:
                import webbrowser
                webbrowser.open(bn['click'])
            except Exception:
                pass
        for w in (fr, inner) + tuple(inner.winfo_children()):
            try:
                w.configure(cursor='hand2')
                w.bind('<Button-1>', _open)
            except Exception:
                pass
    return fr


def splash_enabled(path=None):
    """시작화면을 보일까 — `run.py` 가 띄우기 **전에** 묻는다."""
    return bool(load_style(path).get('show', 1))


def _bar_height(win, st, text, ref, width):
    """구절이 몇 줄이 되는지 재서 띠 높이를 정한다 → `BAR_H` ~ `BAR_H_MAX`.

    ⚠ **화면에 그리기 전에** 잰다 — 숨긴 라벨의 `winfo_reqheight()` 는
      `update()` 없이도 나온다(첫 페인트를 안 늦춘다).
    """
    try:
        line = (text or '') + (('   (' + ref + ')') if ref else '')
        probe = tk.Label(win, text=line, justify='left',
                         wraplength=max(200, width - 220),
                         font=(st['font'], st['size'], 'bold'))
        need = probe.winfo_reqheight()
        probe.destroy()
        # 구절 + 위아래 여백 (사진 설명은 2026-10-11 부터 사진 왼쪽 아래에 얹는다)
        want = need + 26
        return max(BAR_H, min(BAR_H_MAX, want))
    except Exception:
        return BAR_H


def show_splash(root=None, image_path=None,
                verse_path=None, width=960, height=600):
    """스플래시 창을 만들어 즉시 화면에 그린 뒤 그 창을 반환한다.
    root=None 이면 자체 Tk() 생성(독립 실행/측정용). 통합 시엔 기존 root 전달.
    """
    image_path = image_path or _app('splash', 'bg.png')
    verse_path = verse_path or _app('splash_verse.json')
    own = root is None
    win = tk.Tk() if own else tk.Toplevel(root)
    try:
        win.overrideredirect(True)        # 테두리 없는 깔끔한 첫 화면
        win.attributes('-topmost', True)
    except Exception:
        pass
    st = load_style()   # 사용자 지정: 자리(top/bottom)·색·크기·폰트
    # ⚠ 구절을 **먼저** 읽는다 — 띠 높이가 그 길이로 정해진다.
    ref, text = _load_verse(verse_path)
    if not text:
        ref, text = DEFAULT_REF, DEFAULT_TEXT

    # ★★★ **긴 구절이면 띠가 늘어난다** (2026-09-05 사용자 우려 「성경구절이
    #   길면 표시되지 않을 것」 — **실측으로 확인됐다**: 248자 구절에서 구절이
    #   68px 를 먹어 **설명 줄이 1px 로 찌그러졌다**).
    #   ⚠ 구절을 자르지 않는다 — 읽으라고 띄운 것이다. **띠를 키운다.**
    #   ⚠ 사진은 그대로 600 — 사진을 덮지 않는다는 원칙은 그대로다.
    bar_h = _bar_height(win, st, text, ref, width)
    # ★ 홍보 배너 — **있을 때만** 높이를 더한다(없으면 빈 공간 0).
    bn = load_banner()
    total_h = height + bar_h + (BANNER_H if bn else 0)
    sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
    x, y = max(0, (sw - width) // 2), max(0, (sh - total_h) // 2)
    win.geometry(f"{width}x{total_h}+{x}+{y}")

    # ── 띠와 사진 — **띠가 사진 밖에 있다** (사진을 한 픽셀도 안 덮는다) ──
    # ★ 띠 배경은 **사용자가 고른 색**(2026-09-05 지시). 기본은 중립 회색.
    _BG = st.get('bg') or BAR_BG
    bar = tk.Frame(win, bg=_BG, height=bar_h)
    bar.pack_propagate(False)
    cv = tk.Canvas(win, width=width, height=height,
                   highlightthickness=0, bg='#15212e')
    # ★★ **배너는 구절 띄의 반대편**(사용자 지시) — 자리를 못 박지
    #   않는다. 구절을 위로 올리면 배너가 저절로 아래로 내려간다.
    win._banner = _build_banner(win, bn, width, _BG) if bn else None
    if st['pos'] == 'top':
        bar.pack(side='top', fill='x')
        if win._banner is not None:
            win._banner.pack(side='bottom', fill='x')
        cv.pack(side='top', fill='both', expand=True)
    else:
        if win._banner is not None:
            win._banner.pack(side='top', fill='x')
        cv.pack(side='top', fill='both', expand=True)
        bar.pack(side='bottom', fill='x')
    win._bar = bar

    img = None
    if image_path and os.path.exists(image_path):
        try:
            img = tk.PhotoImage(file=image_path)   # PNG/GIF 네이티브 (PIL 불필요)
            cv.create_image(width // 2, height // 2, image=img)
            # (그라데이션 어두운 막 제거 — 사진을 그대로 선명히. 가독성은 글자 그림자로 확보.)
            # ★ 출처 「Hagah Dabar」 — 사진 오른쪽 아래(2026-10-11 사용자 지시 · 시작화면·카드 둘 다).
            #   모양 값은 photo_prep.CREDIT 와 같은 뜻(폭 대비 크기·여백) — 여기서는 PIL 없이 글자로 그린다.
            # ★ 사진 설명(찍은 곳 등) — 사진 **왼쪽 아래**(2026-10-11 사용자 지시 「시작화면·말씀카드 모두
            #   왼쪽 아래 · 사진 위에 표시하는 방식으로 통일」). 옛 띠 아래 줄은 걷었다.
            #   출처와 같은 높이 · 한 줄 · 넘치면 `…` · 없으면 안 그린다.
            try:
                import tkinter.font as _tkf
                ch = int(float(cv.cget('height')))
                fs = max(10, int(width * 0.017))
                m, yb = int(width * 0.03), ch - int(width * 0.025)
                credit = 'Hagah Dabar'
                try:                                     # 관리자가 정한 문구(캐시) · 비면 안 그린다
                    with open(_app('splash_credit.json'), encoding='utf-8') as _f:
                        credit = (json.load(_f).get('text') or '').strip()
                except Exception:
                    pass
                cw = 0
                if credit:
                    cf = ('Georgia', fs)
                    cw = _tkf.Font(font=cf).measure(credit)
                    cv.create_text(width - m + 1, yb + 1, text=credit, anchor='se', fill='#000000', font=cf)
                    cv.create_text(width - m, yb, text=credit, anchor='se', fill='#F2F2F2', font=cf)
                cap = _load_photo_caption()
                if cap:
                    pf = (st['font'], fs)
                    fo = _tkf.Font(font=pf)
                    room = width - 2 * m - cw - (int(width * 0.03) if cw else 0)
                    if fo.measure(cap) > room:
                        lo, hi = 0, len(cap)
                        while lo < hi:
                            mid = (lo + hi) // 2
                            if fo.measure(cap[:mid] + '…') <= room:
                                lo = mid + 1
                            else:
                                hi = mid
                        cap = cap[:max(1, lo - 1)] + '…'
                    cv.create_text(m + 1, yb + 1, text=cap, anchor='sw', fill='#000000', font=pf)
                    cv.create_text(m, yb, text=cap, anchor='sw', fill='#F2F2F2', font=pf)
            except Exception:
                pass
        except Exception:
            img = None

    # ── 띠 안쪽 ─────────────────────────────────────────────────────
    # ★★ **오른쪽 끝에 「바로 시작 ▸」** (사용자 물음 「라벨의 오른쪽 끝에
    #   실행 버튼을 명확히 배치하는 것에 대한 의견」 — 찬성이다. 글은 왼쪽에서
    #   읽고 손은 오른쪽 끝으로 간다. 사진 위에 있으면 어느 사진에서는 안 보인다).
    #   ⚠ **처음에는 잠겨 있다** — 본체가 다 뜬 뒤 `arm_dismiss` 가 살린다.
    #     누를 수 없는 것을 누를 수 있는 척하지 않는다(§0-1).
    right = tk.Frame(bar, bg=_BG)
    right.pack(side='right', fill='y', padx=(8, 14))
    _wait_w, _go_w = _load_btn_words(verse_path)
    win._go_word = _go_w
    # ⚠⚠ **「준비 중…」을 보이지 않는다** (2026-09-05 사용자 — 「라벨의 진행중
    #   표시가 **오래 지속된다. 1초 정도.** 그리고 나서야 바로시작 표시가
    #   나온다」). 잠긴 회색 글자는 결국 **진행 표시**이고, 사용자는 그것을
    #   일부러 없애라고 했다(§197차 「skip만 허용하고 점, 문자 등 하지 마라」).
    #   ⇒ **빈 자리로 두었다가 준비되면 「바로 시작 ▸」이 나타난다.**
    #     누를 수 없는 것을 누를 수 있는 척하지 않는다는 §0-1 도 지켜진다.
    win._go_btn = tk.Label(right, text='', bg=_BG, fg=BAR_DIM,
                           font=('Malgun Gothic', 11, 'bold'),
                           padx=12, pady=6)
    win._go_btn.pack(expand=True)

    left = tk.Frame(bar, bg=_BG)
    left.pack(side='left', fill='both', expand=True, padx=(16, 0), pady=8)
    # ★★ **구절이 먼저, 사진 설명이 그 아래 한 줄** (2026-09-05 사용자 지시
    #   「설명문은 **딱 한 줄**만 표시하면 된다. **배너 라벨 바로 아래**에
    #    배치하는 것이 최선」).
    line = (text or '') + (('   (' + ref + ')') if ref else '')
    win._verse_lbl = tk.Label(
        left, text=line, bg=_BG, fg=st['color'], anchor='w',
        justify='left', wraplength=max(200, width - 220),
        font=(st['font'], st['size'], 'bold'))
    win._verse_lbl.pack(fill='x')
    # ⚠ **없으면 줄을 안 만든다**(빈 자리 금지) · **넘치면 자른다**(한 줄 고정
    #   이라 `wraplength` 를 주지 않는다 — 주면 두 줄이 된다).
    # ★★ **첫 페인트 뒤로 미룬다**(2026-09-05 사용자 「시작화면이 분명히 더
    #   느려졌다」) — 실측 라벨 생성 + 글자 자르기가 **약 12ms**다. 구절이
    #   먼저 뜨는 것이 중요하고 사진 설명은 한 박자 뒤에 나와도 된다.
    win._cap_lbl = None

    def _add_cap():
        # ⚠⚠ **창이 이미 닫혔으면 아무것도 안 한다** — `after_idle` 로 미룬
        #   콜백은 파괴 뒤에도 발화해 `invalid command name` 을 낸다
        #   (§129차와 같은 자리 — 실측으로 잡았다).
        try:
            if not win.winfo_exists():
                return
        except Exception:
            return
        cap = _load_photo_caption()
        if not cap:
            return
        try:
            win._cap_lbl = tk.Label(
                left, text=cap, bg=_BG, fg=BAR_DIM, anchor='w',
                font=(st['font'], int(st.get('desc_size') or 10)))
            win._cap_lbl.pack(fill='x', pady=(2, 0))
            _fit_one_line(win._cap_lbl, cap, max(120, width - 240))
            # 이미 무장했으면 이 줄도 눌러서 들어가게 한다
            if getattr(win, '_on_click', None):
                win._cap_lbl.bind('<Button-1>', win._on_click)
        except Exception:
            pass
    win._add_cap = _add_cap

    win._canvas = cv
    win._hint_item = None       # 옛 캔버스 안내문은 폐기 — 띠가 말한다

    win.update()                  # 즉시 paint → 이 시점에 화면에 보임
    # 설명 줄은 그 뒤에(첫 페인트를 안 늦춘다) — 닫을 때 취소한다.
    win._cap_job = None    # 설명 줄은 사진 위로 옮겼다(2026-10-11) — 띠에는 안 만든다
    win._splash_img = img         # GC 방지(참조 유지)
    return win


def arm_dismiss(win, on_click, hint=None):
    """본체 앱 빌드가 끝난 뒤 호출: 오른쪽 끝 단추를 **「바로 시작 ▸」로 살리고**
    아무 곳이나 눌러도 들어가게 한다.

    ⚠ **여기 오기 전에는 단추가 잠겨 있다**(`GO_WAIT`) — 아직 본체가 없는데
      누를 수 있는 척하면 눌러도 아무 일이 없다(§0-1).
    ⚠ 진행 표시(점·글자)는 **일부러 없다**(사용자 지시 「skip만 허용하고 점,
      문자 등 하지 마라」).
    """
    try:
        btn = getattr(win, '_go_btn', None)
        if btn is not None:
            btn.configure(text=(hint or getattr(win, '_go_word', None)
                                or GO_READY), fg=BAR_FG, cursor='hand2')
            btn.bind('<Button-1>', on_click)
            for w in (btn.master, getattr(win, '_bar', None)):
                if w is not None:
                    w.bind('<Button-1>', on_click)
            win._on_click = on_click      # 늦게 생기는 설명 줄이 쓴다
            for nm in ('_cap_lbl', '_verse_lbl'):
                w = getattr(win, nm, None)
                if w is not None:
                    w.bind('<Button-1>', on_click)
        if getattr(win, '_hint_item', None) is not None:
            win._canvas.itemconfig(win._hint_item, text=(hint or GO_READY),
                                   fill='#FFFFFF')
        win.bind('<Button-1>', on_click)
        win.bind('<Key>', on_click)
        if getattr(win, '_canvas', None) is not None:
            win._canvas.bind('<Button-1>', on_click)
        try:
            win.focus_force()
        except Exception:
            pass
        win.update()
    except Exception:
        pass


def save_today_verse(ref, text, path=None, wait_text=None, go_text=None):
    """본체 앱이 배너 구절을 정한 뒤 호출 → 다음 실행 스플래시가 즉시 읽음.

    ★★ **단추 글자도 함께 담는다** — 스플래시는 앱이 뜨기 전에 그려지므로
      **i18n(DB)을 열 수 없다**(§34 — 파일 캐시만 읽는 것이 이 모듈의 설계다).
      ⇒ 지금 실행의 언어로 다음 실행의 글자를 적어 둔다.
    ⚠ 안 주면 옛 값을 지키고, 그것도 없으면 한국어 기본이 나온다.
    """
    path = path or _app('splash_verse.json')
    old = {}
    try:
        with open(path, encoding='utf-8') as f:
            old = json.load(f) or {}
    except Exception:
        old = {}
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump({'ref': ref, 'text': text,
                       'wait': wait_text or old.get('wait') or '',
                       'go': go_text or old.get('go') or ''},
                      f, ensure_ascii=False)
    except Exception:
        pass


def ensure_schema(conn):
    """splash 테이블 보장(신규 설치/빈 user_data.db 대비). 멱등·조용함.
    관리자 패널·환경설정 '시작 화면' 탭이 열릴 때 호출."""
    stmts = [
        "CREATE TABLE IF NOT EXISTS sys_splash_image (img_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " png_blob BLOB NOT NULL, name TEXT, width INTEGER, height INTEGER, attribution TEXT,"
        " license TEXT, is_active INTEGER NOT NULL DEFAULT 1, sort_order INTEGER NOT NULL DEFAULT 0,"
        " created_at TEXT)",
        "CREATE TABLE IF NOT EXISTS userdb.user_splash_image (img_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " png_blob BLOB NOT NULL, name TEXT, width INTEGER, height INTEGER, label TEXT,"
        " is_active INTEGER NOT NULL DEFAULT 1, created_at TEXT)",
        "CREATE TABLE IF NOT EXISTS userdb.user_splash_hidden (sys_img_id INTEGER PRIMARY KEY, hidden_at TEXT)",
    ]
    for s in stmts:
        try:
            conn.execute(s)
        except Exception:
            pass
    try:
        conn.commit()
    except Exception:
        pass


def refresh_photo_cache(conn, out_img=None, verse_id=None, lang='KO'):
    """본체 앱이 시작 시 호출(appdb 연결 전달): DB에서 활성 사진 1장을
    사용자 사진 우선·랜덤으로 골라 캐시 PNG로 써둔다 → 다음 실행 스플래시가 즉시 읽음.
    PIL 불필요(BLOB 바이트 그대로 기록). 사진이 없으면 기존 캐시 유지(False)."""
    out_img = out_img or _app('splash', 'bg.png')
    blob = None
    # ★★★ **구절이 먼저다** (사용자 확정 — 「핵심 출발은 사진이 아니라 구절」).
    #   그 구절에 이어진 장면을 찾고, 그 장면의 사진 중에서 무작위로 고른다.
    #   ⚠ 장면이 없거나 그 장면의 사진이 없으면 **옛 길(전체 무작위)로 물러선다**
    #     — 매핑이 덜 찼다고 시작화면이 비면 안 된다.
    cap = ('', '')
    if verse_id:
        try:
            import db_splash_scene as _sc
            got = _sc.pick_for_verse(conn, int(verse_id))
            if not got:
                # ★ 2026-10-11 — 장면이 없거나 그 장면 사진이 없으면 photo_pack 의 추천 차례
                #   (같은 묶음 → 책 갈래 → 기본)로 고른다(폰 카드와 같은 규칙).
                try:
                    import photo_pack as _pp
                    pid = _pp.pick_today(conn, int(verse_id))
                    got = {'src': 'SYS', 'img_id': pid} if pid else None
                except Exception:
                    got = None
            if got:
                # ⚠ `pick_for_verse` 는 **어느 사진인지만** 알려 준다
                #   (`src`+`img_id`) — 본문은 여기서 읽는다.
                tbl = ('sys_splash_image' if got['src'] == 'SYS'
                       else 'user_splash_image')
                r = conn.execute(
                    "SELECT png_blob, COALESCE(name,''),"
                    " COALESCE(country,''), COALESCE(continent,'')"
                    " FROM %s WHERE img_id=?" % tbl,
                    (got['img_id'],)).fetchone()
                if r and r[0]:
                    blob = r[0]
                    # ★★ **사용자 언어의 제목·설명이 이긴다** — 없으면 옛
                    #   `name`(영문)으로 물러선다(빈 줄을 만들지 않는다).
                    title, desc = _sc.photo_text(conn, got['img_id'], lang,
                                                 got['src'])
                    # ⚠ **나라·대륙을 띠에 안 적는다**(사용자 지시 — 「사진속의
                    #   장소, 건물, **나라 등을 제목에 입력**한다」). 그 칸들은
                    #   **고르고 거르는 데** 쓰는 값이지 읽을 글이 아니다.
                    #   섞어 붙이면 영문 나라 이름이 번역된 제목 옆에 남는다.
                    cap = (title or r[1], desc)
        except Exception:
            blob = None
    # ⚠⚠⚠ **폴백 경로도 설명을 읽어야 한다** (2026-09-05 사용자 신고 —
    #   「설명문을 입력했는데 표시되지 않는다」). 장면으로 고른 길에서만
    #   `photo_text` 를 부르고 **무작위로 물러선 길에서는 안 불렀다** —
    #   매핑이 안 걸린 구절에서는 설명이 영영 안 뜬다.
    #   ⇒ 여기서도 **어느 사진인지**(src·img_id)를 받아 글을 읽는다.
    for sql in () if blob is not None else (
        # 결합 뷰모델: (가리지 않은 활성 관리자 사진) ∪ (활성 사용자 사진) 중 랜덤 1장
        # ⚠⚠ **UNION 을 서브쿼리로 감싼다** — 안 그러면 `ORDER BY RANDOM()`
        #   이 마지막 SELECT 에만 걸려 「1st ORDER BY term does not match」로
        #   **통째로 실패**하고, 가림을 안 보는 아래 폴백으로 떨어진다
        #   (실측 — 가린 사진이 실제로 떴다).
        "SELECT png_blob, src, img_id, nm FROM ("
        "  SELECT png_blob, 'SYS' src, img_id, COALESCE(name,'') nm"
        "    FROM sys_splash_image WHERE is_active=1"
        "     AND img_id NOT IN (SELECT sys_img_id FROM user_splash_hidden)"
        "  UNION ALL"
        "  SELECT png_blob, 'USER', img_id, COALESCE(name,'')"
        "    FROM user_splash_image WHERE is_active=1"
        ") ORDER BY RANDOM() LIMIT 1",
        # 폴백: userdb 미연결 등 → 관리자 사진만
        "SELECT png_blob, 'SYS', img_id, COALESCE(name,'')"
        " FROM sys_splash_image WHERE is_active=1 ORDER BY RANDOM() LIMIT 1",
    ):
        try:
            row = conn.execute(sql).fetchone()
            if row and row[0]:
                blob = row[0]
                try:
                    import db_splash_scene as _sc2
                    ti, de = _sc2.photo_text(conn, row[2], lang, row[1])
                    cap = (ti or row[3], de)
                except Exception:
                    cap = (row[3], '')
                break
        except Exception:
            continue
    if blob is None:
        return False
    # ★ 2026-10-11 — 사진은 이제 JPEG(1920×1200)로 온다. 시작화면은 Tk 가 PNG 만 읽고 크기를 못 바꾸므로
    #   여기서(본체 앱 · PIL 있음) 창 크기로 줄여 PNG 로 쓴다. 옛 PNG 는 그대로 쓴다.
    if blob[:3] == bytes((0xFF, 0xD8, 0xFF)):
        try:
            import io as _io
            from PIL import Image as _Im
            im = _Im.open(_io.BytesIO(blob)).convert('RGB').resize((960, 600), _Im.LANCZOS)
            buf = _io.BytesIO()
            im.save(buf, 'PNG', optimize=True)
            blob = buf.getvalue()
        except Exception:
            return False
    try:
        os.makedirs(os.path.dirname(out_img) or '.', exist_ok=True)
        with open(out_img, 'wb') as f:
            f.write(blob)
        save_photo_caption(*cap)     # 사진이 바뀌면 설명도 함께 바뀐다
        try:                          # ★ 출처 문구(관리자 설정 · 2026-10-11)
            import photo_prep as _pp
            with open(_app('splash_credit.json'), 'w', encoding='utf-8') as _f:
                json.dump({'text': _pp.credit_text(conn)}, _f, ensure_ascii=False)
        except Exception:
            pass
        return True
    except Exception:
        return False
