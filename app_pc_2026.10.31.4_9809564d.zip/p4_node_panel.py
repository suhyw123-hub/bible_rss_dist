"""
p4_node_panel.py
----------------
P4 캔버스/트리뷰 오른쪽 통합 패널 — **P2 와 같은 열쇠·이름·차례**의 갈래 단추.

갈래 (2026-09-15 `1.txt` 6·4번 — P2 와 같은 얼개 `branch_tabs.SplitTabs`):
  윗줄     DESC 설명 · COMM 주석 · NOTE 묵상노트 · PERI 구절단락 · 「더보기」
  더보기 안 FLOW 말씀흐름 · REFR 연구자료 · NAV 내부연결 · VIDEO 영상 · TEXT 텍스트
           (더보기를 눌렀을 때만 보이는 줄)
  ★ 윗줄 목록은 설정값 `user_config['P4_NODE_MAIN_TABS']`(쉼표 열쇠) — 기본
    `DESC,COMM,NOTE,PERI`. 사용자 「늘 두 줄은 절대로 안 된다」(2026-09-15).
  ★ 기본 폭 420 → **480** — 더보기 안 다섯 갈래(배지까지)에 My Edit 이 붙으면
    KO 438px 다. 420 은 설명 갈래의 제 줄(667px)도 못 담던 폭이었다.
  ★ 묵상노트·연구자료·내부연결 갈래 줄 오른쪽에 **[My Edit]** — P2 와 같은
    의도 규칙(단추만 → 새 글 · 노트 고르고 → 수정) · 2026-09-15 사용자
    「동일하게 배치하라」.
  ⚠ `ttk.Notebook` 은 탭을 줄바꿈하지 않고 눌러 담아 글자를 자른다(실측).

API:
  panel.show_node(view_id, parent_view_id)   # 노드 클릭 → 모든 탭 갱신, DESC 선택
  panel.show_peri(view_id)                   # P 마커 → 페리코프 탭 선택
  panel.show_chain(vid, [chain_codes])       # C 마커 → 연쇄 탭 선택
  panel.hide()                                # X 버튼

코드 공유: P2 패널 클래스를 그대로 임포트해 새 인스턴스로 사용.
"""

import tkinter as tk
import i18n
from tkinter import ttk, scrolledtext
import sqlite3
import appdb

from commentary_panel import CommentaryPanel
from refr_unified_panel import RefUnifiedPanel
from links_panel import LinksPanel
from note_refr_panel import NoteRefrPanel
from p4_chain_slide import ChainSlidePanel
from pericope_verse_view import PericopeVerseView


def pure_vid_from_view(view_id):
    try:
        return int(str(view_id).split('@')[0].split(':')[-1])
    except (ValueError, AttributeError, TypeError):
        return None


# ★ 탭 배지 대상 (2026-08-19 사용자 확정) — **내부자료·링크·묵상노트**(+구속사
#   연결)만, 0 도 (0) 으로. 설명·주석·구절단락은 거의 항상 있으므로 비운다
#   (빈칸 = 있음). P2(user_main)와 이 패널이 같은 4탭·같은 규칙 — 셈은 여기 하나.


#: 배지에 정확한 수를 적는 상한 — 넘으면 「9+」 (2026-09-09 사용자 확정)
BADGE_MAX = 9


def badge(n):
    """배지 글자 — `None`→빈 글자 · 0~9→그 수 · 10 이상→**`9+`**.

    ★ 사용자 확정 — 「**없을 때 눌렀다가 기분나쁘지 않게 하는 것**이기 때문에
      **있다는 것만 알리면 된다**」. 많을 때 정확한 수는 정보가 아니다.
    ⚠ **`N` 같은 글자를 쓰지 않는다** — 라틴 글자는 11개 언어에서 뜻이 안
      통한다(아랍어·러시아어 사용자에게 `N` 은 아무 뜻이 없다). 숫자와 `+`
      는 문자가 아니라 어디서나 읽힌다.
    ⚠ **9까지는 그대로** — 적을 때는 수가 곧 정보다.
    """
    if n is None:
        return None
    try:
        n = int(n)
    except (TypeError, ValueError):
        return None
    return str(n) if n <= BADGE_MAX else '%d+' % BADGE_MAX


def tab_counts(db_path, vid, lang='KO'):
    """한 번의 구절 선택 안에서는 한 번만 센다(`appdb.memo` — P2 배지·P4 배지가 같은 수를 세 번 셌다)."""
    import appdb as _adb
    return dict(_adb.memo(('tab_counts', str(db_path), vid, lang), lambda: _tab_counts(db_path, vid, lang)))


def _tab_counts(db_path, vid, lang='KO'):
    """배지 대상 개수 {'mine'|'nav'|'links'|'note': N} — **세는 곳은 여기 하나**.

    각 값은 그 탭 모듈의 count 함수(패널 조회 코드 재사용 — 드리프트 0).
    'mine'/'nav' = 자료·노트 탭의 연구자료/내부연결 갈래 (2026-08-19 3갈래).
    실패한 항목만 없음(빈칸) — 0 은 정직하게 0 이다.
    (구속사연결 수는 chains_for 로 따로 센다 — 자동 로드가 어차피 조회한다.)
    """
    counts = {}
    if vid is None:
        return counts
    import refr_unified_panel, links_panel, note_refr_panel
    # ★★ 갈래마다 **그 화면 언어 콤보가 고른 언어**로 센다(2026-10-09 1.txt 59-1
    #   사용자 「하나의 언어콤보를 선택하면 그 언어에 해당하는 레코드 숫자만
    #   카운트 … 지금은 다국어 모두 합산」). 고른 적 없으면 환경설정 언어 —
    #   콤보가 처음 뜰 때와 같은 차례다. 「전체」를 고르면 그때만 합산한다.
    import lang_combo as _LC
    l_refr = _LC.chosen_lang('LANGSEL_REFR', lang) or lang
    l_vid = _LC.chosen_lang('LANGSEL_LINKS_VIDEO', lang)
    l_txt = _LC.chosen_lang('LANGSEL_LINKS_TEXT', lang)
    try:
        counts.update(refr_unified_panel.counts_for(db_path, vid, l_refr))
    except Exception:
        pass
    # ★ 배지는 **설정 언어 기준**으로 센다 (2026-09-09 0.txt 1-3 · 공통 원칙).
    #   ⚠ **주석은 언어를 안 본다** — 원문(EN) 하나뿐이라 언어로 세면 늘 0이
    #     된다(실측 창1:1 주석 4 · 한국어 본문 0). 언어별 행이 실제로 있는
    #     자산만 언어로 센다.
    for key, fn in (('links', lambda: links_panel.count_for(db_path, vid, lang)),
                    ('note', lambda: note_refr_panel.count_for(db_path, vid))):
        try:
            counts[key] = fn()
        except Exception:
            pass
    # 주석/링크 3갈래 배지 (2026-08-26 2안) — 주석 entry 수 + 영상/텍스트 분리
    try:
        import commentary_panel
        counts['comm'] = commentary_panel.count_for(db_path, vid)
    except Exception:
        pass
    try:
        counts['lvideo'] = links_panel.count_split(
            db_path, vid, l_vid, ui_lang=lang)['lvideo']
        counts['ltext'] = links_panel.count_split(
            db_path, vid, l_txt, ui_lang=lang)['ltext']
    except Exception:
        pass
    # ★ 찬양 — 그 구절의 **곡** 수(영상 수가 아니다). 곡 19개에 영상 306편이라
    #   영상으로 세면 배지가 「306」이 되고 그것은 사람이 못 읽는다.
    try:
        import appdb, db_song as _S
        _c = appdb.connect(db_path)
        counts['song'] = len(_S.songs_of_verse(_c, vid, lang))
        _c.close()
    except Exception:
        pass
    # ★ 원어 낱말 — 그 절의 **낱말 수**(2026-09-12). 시1:1 이 11개다.
    #   ⚠ 조사·고유명사가 빠진 수라 「이 절에서 볼 만한 낱말」과 같다.
    try:
        import appdb, db_lex_link as _LL
        _c = appdb.connect(db_path)
        # ⚠ 2026-10-13 80-4 — 목록(`entity_browser.show_lexicon`)과 같은 잣대: 뜻풀이가 있는 낱말만
        counts['lex'] = sum(1 for _st in _LL.lemmas_of(_c, vid) if _LL.word_info(_c, _st))
        _c.close()
    except Exception:
        pass
    return counts


class NodePanel(tk.Frame):
    WIDTH = 480

    def __init__(self, parent, db_path,
                 lang_provider=None, ver_provider=None,
                 fetch_desc_fn=None,
                 fetch_links_fn=None,      # 접힘줄 — 이웃 목록 (2026-08-21)
                 fetch_link_desc_fn=None,  # 접힘줄 — 연결 하나의 설명문
                 on_link_ai=None,          # 접힘줄 — 연결 하나 [AI 분석] (2026-10-14)
                 on_verse_click=None,
                 on_sermon_select=None,
                 on_doctrine_select=None,
                 on_article_open=None,    # 연구 글 → P4 자료 탭 (2026-08-03)
                 on_user_open=None,       # 내 자료 → P4 자료 탭
                 on_user_new=None,        # 새로 쓰기 → P4 자료 탭
                 on_chain_detail=None,    # 구속사연결 → P4 구속사 연결 설명 (2026-08-19)
                 on_video_open=None,      # 링크 탭 영상 → P4 온라인 영상 (2026-08-19)
                 **kwargs):
        kwargs.setdefault('width', self.WIDTH)
        super().__init__(parent, bg='#FAFAFA', bd=1, relief='solid', **kwargs)
        self.pack_propagate(False)

        self.db_path = db_path
        self.lang_provider = lang_provider or (lambda: 'KO')
        self.ver_provider = ver_provider or (lambda: 'KRV')
        self.fetch_desc_fn = fetch_desc_fn or (lambda vid: '')
        # 접힘줄 (2026-08-21 `0.txt` 4번) — 없으면 줄 자체를 그리지 않는다.
        self.fetch_links_fn = fetch_links_fn
        self.fetch_link_desc_fn = fetch_link_desc_fn
        self.on_link_ai = on_link_ai
        self._desc_base = ''
        self._fold_open = False        # 접힘줄 자체 (세션 동안 유지)
        self._fold_kids = set()        # 펼친 이웃 — 노드를 바꾸면 접는다
        self._fold_extra = 0           # 「더 보기」로 더 본 개수
        self.on_verse_click = on_verse_click
        self.on_sermon_select = on_sermon_select
        self.on_doctrine_select = on_doctrine_select
        self.on_article_open = on_article_open
        self.on_user_open = on_user_open
        self.on_user_new = on_user_new
        self.on_chain_detail = on_chain_detail
        self.on_video_open = on_video_open
        self._pw_anchor = None
        self._curr_view_id = None
        self._curr_vid = None
        self._last_w = 0                 # 실제로 그려진 폭(sash 드래그 반영)
        self._w_job = None               # 폭 저장 디바운스 핸들
        self.bind('<Configure>', self._on_resize)
        # 어느 화면이 이 패널을 쓰고 있나 (CANVAS / TREE). 탭 선택을 화면마다 따로 기억한다.
        self._view_key = 'CANVAS'

        self._build_header()
        self._build_notebook()
        # 탭을 손으로 바꾸면 그때 저장한다(BranchTabs on_change → _on_tab_changed)
        # — 노드를 누를 때마다 저장하면 아래 복원이 자기가 방금 쓴 값을 다시
        # 읽는 꼴이 된다.

    # ───────── 탭 기억 (2026-08-12) ─────────
    # 사용자 지적: 「캔버스/트리뷰가 각각 직전값 저장이 안 되고 상호의존적으로 작동함」
    #   원인 둘 — ① show_node 가 늘 설명 탭을 강제했다 ② 화면 구분이 없었다.
    # 저장은 폭(`P4_NODE_PANEL_WIDTH`)과 같은 방식으로 user_config 에 한다.
    _TAB_KEY = 'P4_NODE_TAB_'          # + CANVAS / TREE

    def set_view_key(self, key):
        """쓰는 화면이 바뀌었다고 알린다. **떠나는 화면의 탭을 먼저 갈무리**하고
        새 화면이 마지막에 보던 탭으로 돌려놓는다."""
        key = 'TREE' if str(key).upper() == 'TREE' else 'CANVAS'
        if key == self._view_key:
            return
        self._save_tab()          # 이벤트에 기대지 않고 여기서 확실히 남긴다
        self._view_key = key
        self._restore_tab()

    def _current_tab_name(self):
        """지금 탭의 **그룹 열쇠**('DESC'…'FLOW').

        ⚠ 표시 글자로 저장하면 안 된다 (2026-08-19 4탭 개편에서 교정) —
          라벨에 개수 (N) 가 붙으면서 글자가 절마다 달라져 복원 대조가
          영영 실패한다(조용히 설명 탭 폴백).
        """
        try:
            return self.tabs.current()
        except Exception:
            return None

    def _save_tab(self, name=None):
        name = name or self._current_tab_name()
        if not name:
            return
        try:
            with appdb.connect(self.db_path) as c:
                c.execute("INSERT INTO user_config (config_key, config_val) VALUES (?,?) "
                          "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                          (self._TAB_KEY + self._view_key, name))
                c.commit()
        except Exception:
            pass

    # ── 찬양 갈래 콜백 (2026-09-17 · 1.txt 4) ────────────────────────
    #   ⚠ 호스트가 안 주면 **아무 일도 안 하는 것이 아니라** 브라우저로 연다
    #     (조용한 실패 금지 §0-1).
    def on_song_open(self, song_id):
        fn = getattr(self, 'on_song_select', None)
        if callable(fn):
            return fn(song_id)

    def on_song_play(self, url, title=''):
        fn = getattr(self, 'on_video_open', None)
        if callable(fn):
            try:
                import video_open as _VO
                return fn(_VO._vid_of(url) or url, title)
            except Exception:
                pass
        import webbrowser
        if url:
            webbrowser.open(url)

    def _sync_tools(self, key):
        """[My Edit] — 묵상노트일 때만(윗줄 오른쪽 끝).

        ⚠ 연구자료·내부연결은 **패널이 제 줄에 [My Edit] 을 이미 그린다**
          (`RefUnifiedPanel` · ext_bar 없음) — 여기 또 두면 둘이다(실측)."""
        try:
            home = self.tabs.bar() if key == 'NOTE' else None
            for bar, slot in self._me_tools.items():
                if bar is home:
                    if not slot.winfo_manager():
                        slot.pack(side='right', padx=(0, 2))
                else:
                    slot.pack_forget()
            self.tabs.refit_later()   # 도구 폭이 바뀌면 여백을 다시 맞춘다(기하가 가라앉은 뒤)
        except Exception as e:
            print('[node tools] %s' % e)

    def _note_my_edit(self):
        """묵상노트·연구자료·내부연결 [My Edit] — P2 `_p2_note_my_edit` 와 같은
        의도 규칙(2026-08-31 사용자 확정): 노트를 고르고 눌렀다 → 그 노트가
        출발지·수정화면 / 그냥 눌렀다 → 구절이 출발지·재고 「묵상노트」·빈 입력."""
        vid = self._curr_vid
        if not vid:
            return
        try:
            import my_edit
            key = self.tabs.current()
            done = lambda _w=None: self._reload_after_edit()
            if key == 'NOTE':
                nid = getattr(self.note, 'current_record_id', None)
                if nid:
                    my_edit.open(self, kind='NOTE', asset_id=int(nid),
                                 intent=my_edit.INTENT_EDIT, on_changed=done)
                else:
                    my_edit.open(self, kind='VERSE', asset_id=vid,
                                 intent=my_edit.INTENT_NEW, pick_kind='NOTE',
                                 pick_label=i18n.t('LP_B_NOTE', '묵상노트'),
                                 on_changed=done)
                return
            my_edit.open(self, kind='VERSE', asset_id=vid,
                         intent=(my_edit.INTENT_NEW if key == 'REFR' else None),
                         pick_kind=('USER_REF' if key == 'REFR' else None),
                         on_changed=done)
        except Exception as e:
            print('[node my edit] %s' % e)

    def _reload_after_edit(self):
        """My Edit 저장 뒤 — 노트·연구자료를 다시 읽고 배지를 맞춘다."""
        vid = self._curr_vid
        if not vid:
            return
        for panel in (self.note, self.refr):
            try:
                panel.load(vid)
            except Exception:
                pass
        try:
            self._update_tab_counts(vid, getattr(self, '_chain_n', None))
        except Exception:
            pass

    def _on_tab_changed(self, _key=None):
        """손으로 탭을 바꾼 것만 저장한다.

        (2026-09-15) BranchTabs 의 on_change 는 `select()` 안에서 **바로**
        불린다 — 옛 `<<NotebookTabChanged>>` 처럼 큐에 들어가지 않으므로
        복원 플래그를 `select` 앞뒤로 세우고 내리면 된다.
        도구·scope 동기는 복원 때도 해야 하므로 빗장 앞에서 한다.
        """
        self._sync_tools(_key)
        self._on_note_branch(_key)
        if getattr(self, '_restoring_tab', False):
            return
        # ⚠ 종료 중 파괴 연쇄가 미는 탭 이동은 저장하지 않는다 (0.txt 1번 —
        #   앱의 `_closing` 빗장과 같은 원리. 탭이 하나씩 파괴되면서 선택이
        #   남은 탭으로 밀리고 이 이벤트가 발화한다).
        try:
            if getattr(self.winfo_toplevel(), '_closing', False):
                return
        except Exception:
            return
        self._save_tab()

    def _restore_tab(self):
        """저장된 탭으로 돌아간다. 없거나 못 찾으면 설명 탭."""
        want = None
        try:
            with appdb.connect(self.db_path) as c:
                r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                              (self._TAB_KEY + self._view_key,)).fetchone()
            want = r[0] if r and r[0] else None
        except Exception:
            pass
        self._restoring_tab = True
        try:
            # 옛 그룹 열쇠(4탭 시절) → 열 갈래 열쇠. 모르는 값은 설명.
            key = {'LINKS': 'COMM'}.get(want, want)
            if key not in self._tab_keys():
                key = 'DESC'
            self.tabs.select(key, save=False)
        except Exception:
            pass
        finally:
            self._restoring_tab = False     # on_change 는 동기라 여기서 내려도 된다

    # ───────── 외부 API ─────────

    def show_node(self, view_id, parent_view_id=None):
        self._curr_view_id = view_id
        self._curr_vid = pure_vid_from_view(view_id)
        self._update_title()
        self._refresh_desc(view_id)
        self._reload_p2_panels(self._curr_vid)
        # 페리코프 탭도 자동 로드 (LINK 페리코프 폐기 → P 마커 없음. 노드 클릭 시 BODY 자동 표시)
        try:
            self.peri_view.show_for_vid(self._curr_vid)
        except Exception as e:
            print(f'[NodePanel peri_view] {e}')
        # ⚠ 예전에는 여기서 **늘 설명 탭을 강제**했다 — 주석을 보다 다른 노드를 누르면
        #   설명으로 튀었다(2026-08-12 사용자 지적). 이제 그 화면이 보던 탭으로 돌아간다.
        self._restore_tab()
        self._attach_if_hidden()

    def show_chain(self, vid, chain_codes):
        self._curr_vid = int(vid) if vid is not None else None
        self._update_title()
        if self._curr_view_id:
            self._refresh_desc(self._curr_view_id)
        self._reload_p2_panels(self._curr_vid)
        if self._curr_vid is not None:
            try:
                self.chain.show_for(self._curr_vid, chain_codes)
            except Exception as e:
                print(f'[NodePanel chain] {e}')
        self.tabs.select('FLOW')
        self._attach_if_hidden()

    def hide(self):
        if not self.winfo_ismapped():
            return
        self._save_width()          # 닫기 직전 폭 보존 — 다음에 열 때 복원
        pw = self.master
        if isinstance(pw, tk.PanedWindow):
            try:
                pw.forget(self)
            except Exception:
                pass
        else:
            self.pack_forget()

    def set_pw_anchor(self, sibling_widget):
        self._pw_anchor = sibling_widget

    # ───────── 패널 폭 기억 (2026-07-30, 91.txt ②) ─────────
    # sash 로 넓혀도 닫았다 열면 매번 WIDTH(420)로 초기화되던 문제를 없앤다.
    # 저장: user_config['P4_NODE_PANEL_WIDTH']

    _WIDTH_KEY = 'P4_NODE_PANEL_WIDTH'
    _WIDTH_MIN, _WIDTH_MAX = 260, 1400

    def _load_width(self):
        try:
            with appdb.connect(self.db_path) as c:
                r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                              (self._WIDTH_KEY,)).fetchone()
            if r and r[0]:
                return self._fit_w(int(r[0]))
        except Exception:
            pass
        return self.WIDTH

    def _fit_w(self, v):
        """화면에 견주어 조인다 — 작은 노트북에서 옆 칸을 삼키지 않게.

        ⚠ 저장값은 안 고친다(큰 화면으로 돌아가면 되살아난다).
        """
        v = max(self._WIDTH_MIN, min(self._WIDTH_MAX, int(v)))
        try:
            return min(v, int(self.winfo_screenwidth() * 0.55))
        except Exception:
            return v

    def _on_resize(self, _ev=None):
        """실제로 그려진 폭을 기억한다 — sash 드래그로 넓힌 값이 여기 담긴다.

        winfo_width() 는 위젯이 mapped 되기 전에는 1 을 돌려주므로, 닫는 시점에만
        읽으면 P4 가 아직 안 그려진 상황에서 엉뚱한 값을 저장할 수 있다. mapped 상태의
        Configure 이벤트에서만 값을 갱신해 그 위험을 없앤다.
        """
        try:
            if self.winfo_ismapped():
                w = int(self.winfo_width())
                if w >= self._WIDTH_MIN:
                    self._last_w = w
                    # 디바운스 저장(2026-07-31) — hide() 때만 저장하면 패널을 X 로 닫지 않고
                    # 앱을 종료했을 때 리사이즈한 폭이 통째로 유실된다.
                    if self._w_job is not None:
                        try:
                            self.after_cancel(self._w_job)
                        except Exception:
                            pass
                    self._w_job = self.after(700, self._save_width)
        except Exception:
            pass

    def _save_width(self):
        w = getattr(self, '_last_w', 0)      # Configure 로 잡아둔 실제 폭 우선
        if not w:
            try:
                w = int(self.winfo_width())
            except Exception:
                return
        if w <= 1:                  # 실폭을 모르면 기존 저장값을 건드리지 않는다
            return
        w = max(self._WIDTH_MIN, min(self._WIDTH_MAX, w))
        try:
            with appdb.connect(self.db_path) as c:
                cur = c.execute("UPDATE user_config SET config_val=? WHERE config_key=?",
                                (str(w), self._WIDTH_KEY))
                if cur.rowcount == 0:
                    c.execute("INSERT INTO user_config(config_key, config_val) VALUES(?, ?)",
                              (self._WIDTH_KEY, str(w)))
                c.commit()
        except Exception:
            pass

    # ───────── 빌드 ─────────

    def _build_header(self):
        head = tk.Frame(self, bg='#E0E0E0', height=32)
        head.pack(fill='x', side='top')
        head.pack_propagate(False)
        self._title_lbl = tk.Label(head, text='', bg='#E0E0E0',
                                    font=('Malgun Gothic', 10, 'bold'),
                                    anchor='w', padx=8)
        self._title_lbl.pack(side='left', fill='x', expand=True)
        tk.Button(head, text='✕', bg='#E0E0E0', bd=0,
                  font=('Arial', 11, 'bold'),
                  cursor='hand2', command=self.hide).pack(side='right', padx=6)

    # ★ 주 탭 + 더보기 (2026-09-15 `1.txt` 6·4번) — 옛 4그룹 탭(2026-08-19)을
    #   걷었다. 열쇠 이름은 옛 P2 갈래와 같다(여기는 구절단락이 더 있고
    #   찬양·원어는 없다). 차례 = 주 탭 안에서도 더보기 안에서도 이 차례.
    # ★ 찬양을 더했다(2026-09-17 · 1.txt 4 사용자 「캔버스 / 트리뷰 슬라이드
    #   화면에서도 찬양 탭 추가」) — P2 와 **같은 부품·같은 규칙**이다.
    #   ⚠ 곡이 0 이면 갈래가 사라진다(§0-1) — `_update_tab_counts` 가 건다.
    TAB_ORDER = ('DESC', 'COMM', 'NOTE', 'PERI',
                 'FLOW', 'REFR', 'NAV', 'VIDEO', 'TEXT', 'SONG')
    # ⚠ 구절단락은 윗줄 — 더보기 안에 여섯을 두면 기본 폭에서 한 줄에 안 든다
    #   (실측 KO 더보기 안 여섯 = 508px). 다섯이면 438px.
    MAIN_DEFAULT = ('DESC', 'COMM', 'NOTE', 'PERI')
    MAIN_KEY = 'P4_NODE_MAIN_TABS'
    MORE_KEY = 'P4_NODE_MORE_MODE'
    GROUP_ORDER = TAB_ORDER          # 옛 이름 — 읽는 곳이 있을 때를 위해

    def _tab_keys(self):
        """단추를 만들 갈래 — **언제나 전부 + 「더보기」 하나**(P2 와 같은 규칙).

        ★ 표시방식(서브탭/통합탭)은 **보임/숨김**으로 가른다 — 갈래를 아예 안
          만들면 설정을 되돌릴 때 앱을 다시 켜야 한다."""
        return list(self.TAB_ORDER) + ['ONE']

    def _one_mode(self):
        """더보기를 **한 목록**으로 볼 것인가 — `user_config['P4_NODE_MORE_MODE']`."""
        import p2_tab_settings as _ts
        return _ts.read_more(self.db_path, self.MORE_KEY) == 'ONE'

    def _main_keys(self):
        """윗줄 갈래 — 설정값 또는 기본. 연구자료/내부연결은 짝이라 함께 간다."""
        raw = None
        try:
            with appdb.connect(self.db_path) as c:
                r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                              (self.MAIN_KEY,)).fetchone()
            raw = r[0] if r else None
        except Exception:
            pass
        keys = [k.strip().upper() for k in (raw or '').split(',') if k.strip()]
        keys = [k for k in keys if k in self.TAB_ORDER] or list(self.MAIN_DEFAULT)
        if ('REFR' in keys) != ('NAV' in keys):
            keys += [k for k in ('REFR', 'NAV') if k not in keys]
        return [k for k in self.TAB_ORDER if k in keys]

    def _build_notebook(self):
        """주 탭 + 더보기 (2026-09-15) — 위 머리말."""
        from branch_tabs import SplitTabs
        # ★★★ 통합탭이면 **전부 윗줄**이다 — 안 그러면 「더보기」 단추가 둘이 된다
        #   (`SplitTabs._ensure_more_btn` 은 안 층이 하나라도 있으면 제 단추를
        #    만든다). 안 보일 갈래는 아래에서 `set_visible(False)` 로 감춘다.
        _one0 = self._one_mode()
        _main0 = (list(self.TAB_ORDER) + ['ONE']) if _one0 else self._main_keys()
        self.tabs = SplitTabs(self, db_path=self.db_path,
                              main=_main0,
                              on_change=self._on_tab_changed)
        self.tabs.pack(fill='both', expand=True)
        T = self.tabs
        self._tab_ids = {k: k for k in self.TAB_ORDER}   # 옛 이름 — 항등표
        self._branch = {}

        # ── 설명 — 5갈래 한 줄 (2026-08-26 2안) + 언어콤보. 그대로 ──
        g = T.frame_for('DESC')
        from desc_comm_group import DescCommGroup
        dg = DescCommGroup(
            g, self.db_path,
            refresh_desc=lambda: self._refresh_desc(
                getattr(self, '_curr_view_id', None)),
            make_comm=self._make_comm,
            state_key='P4_NODE_DG',
            on_edit=self._open_overlay_editor)
        dg.pack(fill='both', expand=True)
        self._descgrp = dg

        f = dg.desc_frame()
        self.desc_txt = scrolledtext.ScrolledText(
            f, font=('Malgun Gothic', 10), wrap='word', bd=0, state='disabled')
        self.desc_txt.pack(fill='both', expand=True)
        try:
            import theme_font
            theme_font.register(self.desc_txt, self.db_path, 'desc')   # 읽는 본문
        except Exception:
            pass
        try:
            from reading_pane import enable_copy
            enable_copy(self.desc_txt)      # 드래그 선택 + Ctrl+C (2026-08-17)
        except Exception:
            pass
        self.commentary = None       # 첫 주석 갈래 진입 때 지연 생성(_make_comm)
        dg.finish()


        # ── 구절단락 · 말씀흐름 ──
        f = T.frame_for('PERI')
        # ⚠ 제 머리 줄(제목 · +5/−5)을 스스로 만든다 — 갈래 줄이 두 줄이라
        #   거기에 얹으면 어느 줄인지 갈린다(옛 `ext_bar` 는 그룹 줄이었다).
        self.peri_view = PericopeVerseView(
            f, self.db_path,
            lang_getter=self.lang_provider,
            ver_getter=self.ver_provider)
        self.peri_view.pack(fill='both', expand=True)
        f = T.frame_for('FLOW')
        self.chain = ChainSlidePanel(
            f, self.db_path,
            lang_provider=self.lang_provider,
            on_verse_click=self.on_verse_click,
            on_detail=self.on_chain_detail,
            show_header=False)
        self.chain.pack(fill='both', expand=True)

        # ── 묵상노트 · 연구자료/내부연결(패널 하나 · scope 전환) ──
        f = T.frame_for('NOTE')
        self.note = NoteRefrPanel(
            f, self.db_path, 'VERS_NOTE', self.lang_provider)
        # 글을 쓰거나 지우면 배지도 따라온다(개수 = 목록) — 2026-09-15
        self.note.on_changed = lambda: self._update_tab_counts(
            self._curr_vid, getattr(self, '_chain_n', None))
        self.note.pack(fill='both', expand=True)
        f = T.frame_for('REFR')
        self.refr = RefUnifiedPanel(
            f, self.db_path,
            on_sermon_select=self.on_sermon_select,
            on_doctrine_select=self.on_doctrine_select,
            on_article_open=self.on_article_open,
            on_user_open=self.on_user_open,
            on_user_new=self.on_user_new,
            external_scope=True)
        self.refr.pack(fill='both', expand=True)

        # ── 주석 · 영상 · 텍스트 ──
        f = T.frame_for('COMM')
        self.commentary = self._make_comm(f)     # 자기 언어 콤보(ext_lang 없음)
        f = T.frame_for('VIDEO')
        self.links = LinksPanel(
            f, self.db_path, lang_getter=self.lang_provider,
            on_video_open=self.on_video_open, mode='VIDEO')
        self.links.pack(fill='both', expand=True)
        f = T.frame_for('TEXT')
        self.links_text = LinksPanel(
            f, self.db_path, lang_getter=self.lang_provider,
            on_video_open=self.on_video_open, mode='TEXT')
        self.links_text.pack(fill='both', expand=True)
        # ── 찬양 — 곡 ▸ 판 ▸ 영상(부품 하나를 P2 와 함께 쓴다) ──
        f = T.frame_for('SONG')
        try:
            import song_panel as _sp
            self.song = _sp.SongPanel(
                f, self.db_path, lang_getter=self.lang_provider,
                on_song=self.on_song_open, on_play=self.on_song_play)
            self.song.pack(fill='both', expand=True)
        except Exception as _e:
            self.song = None
            print('[node song] %s' % _e)

        # ── 더보기 통합 목록 — **P2 와 같은 부품**(2026-09-17) ──────────────
        #   ⚠⚠⚠ 이것이 없어서 「통합탭」을 고르면 여섯 갈래가 숨기만 하고
        #     **닿을 길이 0** 이었다(§0-1). 여기도 구절 축이라 P2 의 조회
        #     (`p2_one_list.rows`)를 그대로 쓴다 — 두 벌이면 배지와 목록이 갈린다.
        self.one = None
        try:
            import p2_one_list as _OL
            _rest0 = [k for k in _OL.ORDER if k not in set(self._main_keys())]
            self.one = _OL.OneList(
                T.frame_for('ONE'), self.db_path,
                lang_getter=self.lang_provider,
                keys=_rest0, on_open=self._one_open)
            self.one.pack(fill='both', expand=True)
        except Exception as _e:
            print('[node one] %s' % _e)

        # 단추 — 열쇠·이름(P2T_*)·차례가 P2 와 같다(TAB_ORDER 차례).
        _labels = {'DESC': ('P2T_DESC', '설명'), 'COMM': ('P2T_COMM', '주석'),
                   'NOTE': ('P2T_NOTE', '묵상노트'), 'PERI': ('P2T_PERI', '구절단락'),
                   'FLOW': ('P2T_FLOW', '말씀흐름'), 'REFR': ('P2T_REFR', '연구자료'),
                   'NAV': ('P2T_NAV', '내부연결'), 'VIDEO': ('P2T_VIDEO', '영상'),
                   'TEXT': ('P2T_TEXT', '텍스트'),
                   'SONG': ('P2T_SONG', '찬양'),
                   # ★ 통합탭일 때만 쓰는 갈래 — 더보기 여섯을 한 목록으로
                   'ONE': ('P2T_MORE', '더보기')}
        for key in self._tab_keys():
            T.add(key, _labels[key][0], _labels[key][1],
                  share_with=('REFR' if key == 'NAV' else None))
        _mainset0 = set(self._main_keys())
        for key in self.TAB_ORDER:
            if key not in _mainset0:
                T.set_visible(key, not _one0)
        T.set_visible('ONE', _one0)
        # ★ [My Edit] — 묵상노트·연구자료·내부연결 (2026-09-15 사용자 「동일하게
        #   배치하라」). **윗줄 오른쪽 끝 한 벌** — 더보기 안 줄에 두면 다섯 갈래
        #   (배지까지 KO 439px)에 70px 가 더해져 기본 폭을 넘친다. 그 갈래일 때만
        #   보인다. 칸째 붙였다 뗀다(빈 프레임 크기 잔재 함정 — user_main 참조).
        try:
            import ui_theme as _ut
            _fk = _ut.flat_btn()
        except Exception:
            _fk = dict(bd=0, padx=8, cursor='hand2')
        self._me_tools = {}
        for _bar in (T.bar(),):
            _slot = tk.Frame(_bar)
            _btn = tk.Button(_slot, text=i18n.t('OE_BTN', 'My Edit'),
                             command=self._note_my_edit, **_fk)
            _btn.pack(side='right', padx=(4, 2), pady=2)
            self._me_tools[_bar] = _slot
        T.finish()
        # ★★★ 2026-10-07 (docs/1.txt 51-4(4) 나) — 캔버스·트리뷰 오른쪽 패널도 **설명·묵상노트만**.
        #   주석·연구노트·영상 등은 오른쪽 탭모음이 아니라 **P4 탭이 직접** 보인다(P4 에서 누른
        #   구절을 그 탭들이 따라온다 — user_main `_p4_verse_follow`). 갈래는 지우지 않고 잠근다.
        # ★ 2026-10-13 (docs/1.txt 76-1 · 사용자 「P4 구절 클릭하면 앞뒤 맥락을 이해하기 쉽게 배치했었다 … 복구」) —
        #   **구절단락** 을 되살린다(잠글 때 함께 숨었을 뿐 화면·노드 클릭 때 채우기는 살아 있었다).
        T.lock_to(('DESC', 'NOTE', 'PERI'))
        self._on_note_branch(T.current())       # 연구자료/내부연결 scope 반영
        self._sync_tools(T.current())

    # ★★★ **길은 나중에 심긴다 — 그래서 값으로 받지 않고 문으로 받는다**
    #   (2026-09-25). 주석 패널은 이 패널을 **짓는 동안** 만들어지는데
    #   `user_main` 은 다 지어진 뒤에 길을 심는다. 값으로 두면 그 사이에
    #   만들어진 주석 패널이 영영 `None` 을 들고 있어 **단추가 안 뜬다**
    #   (오류도 안 난다 — 실측으로 잡았다).
    _dl_jump = None

    @property
    def on_download_jump(self):
        return self._dl_jump

    @on_download_jump.setter
    def on_download_jump(self, fn):
        self._dl_jump = fn
        cp = getattr(self, 'commentary', None)
        if cp is not None:
            cp.on_download_jump = fn

    def _make_comm(self, parent):
        """주석 패널 — 주석/링크 탭 [주석본문] 갈래 (2026-08-26 2안 이사).

        ⚠ ext_lang 을 안 준다 — 옛 설명 탭의 공유 콤보는 다른 탭이라
          보이지 않는다. 자기 콤보(LANGSEL_COMMENTARY)를 쓴다."""
        self.commentary = CommentaryPanel(
            parent, self.db_path, external_nav=True)
        # ★ 「아직 안 받았습니다」 → 다운로드 탭(1.txt 16-3 ⑤)
        self.commentary.on_download_jump = self._dl_jump
        self.commentary.pack(fill='both', expand=True)
        if self._curr_vid:
            try:
                self.commentary.load(self._curr_vid)
            except Exception:
                pass
        return self.commentary

    def apply_more_mode(self):
        """더보기 표시방식을 화면에 반영한다 — 설정 팝업 [적용] 이 부른다.

        차례(옛 P2 와 같았다 — P2 는 2026-10-13 두 탭으로 고정):
        `set_main` 을 먼저(단추를 부수고 다시 짓되 `visible` 표식은 지킨다) ·
        그다음에 보임/숨김 · 마지막에 찬양 같은 0건 규칙을 다시 건다."""
        T = getattr(self, 'tabs', None)
        if T is None:
            return
        one = self._one_mode()
        main = list(self._main_keys())
        rest = [k for k in self.TAB_ORDER if k not in set(main)]
        T.set_main((list(self.TAB_ORDER) + ['ONE']) if one else main)
        for k in self.TAB_ORDER:
            T.set_visible(k, True if k in set(main) else (not one))
        T.set_visible('ONE', one)
        cur = T.current()
        if cur in set(rest) and one:
            T.select('ONE')
        elif cur == 'ONE' and not one:
            T.select(main[0] if main else 'DESC')
        if self._curr_vid:
            try:
                self._update_tab_counts(self._curr_vid,
                                        getattr(self, '_chain_n', None))
            except Exception:
                pass
        if one and getattr(self, 'one', None) is not None:
            import p2_one_list as _pol
            self.one.set_keys([k for k in _pol.ORDER if k in set(rest)])
            if self._curr_vid:
                self.one.load(self._curr_vid)

    def _one_open(self, kind, ident, extra=''):
        """통합 목록에서 줄을 열었다 — 갈래마다 **원래 가던 곳**으로.

        ⚠ 여기서 새 동작을 만들지 않는다 — 이 패널이 이미 들고 있는 콜백을 쓴다.
          새로 쓰면 서브탭에서 누른 것과 통합탭에서 누른 것이 달라진다."""
        try:
            if kind == 'VIDEO':
                import video_open as VO
                fn = getattr(self, 'on_video_open', None)
                if fn:
                    fn(VO._vid_of(extra) or extra)
            elif kind == 'TEXT':
                if extra:
                    import webbrowser
                    webbrowser.open(extra)
            elif kind == 'SONG':
                self.on_song_open(int(ident))
            elif kind == 'USER':
                if self.on_user_open:
                    self.on_user_open(int(ident))
            elif kind == 'REFR':
                if self.on_article_open:
                    self.on_article_open(int(ident))
            elif kind == 'NAV':
                # ⚠ 갈래 판정은 P2 통합 목록과 **같은 규칙**이다(도서·설교는 P1,
                #   문답·사전은 교리 화면). 다르면 같은 줄이 두 곳에서 다른 데로 간다.
                nt = (extra or '').upper()
                if nt in ('SERMON', 'BOOK'):
                    if self.on_sermon_select:
                        self.on_sermon_select(int(ident))
                elif nt == 'REF':
                    if self.on_doctrine_select:
                        self.on_doctrine_select(int(ident))
                else:
                    print('[node one] 모르는 내부연결 갈래: %s' % nt)
            elif kind == 'FLOW':
                # ⚠ 통합탭에서는 말씀흐름 갈래가 숨어 있다 — 제 집인 P4
                #   「구속사 연결 설명」으로 보낸다(서브탭 [자세히 읽기] 와 같다).
                if self.on_chain_detail:
                    self.on_chain_detail(ident, self._curr_vid)
        except Exception as e:
            print('[node one open] %s' % e)

    def _on_note_branch(self, key):
        """연구자료/내부연결 — 같은 패널의 scope 전환(열쇠는 열 갈래 것)."""
        try:
            from refr_unified_panel import SCOPE_MINE, SCOPE_NAV
            if key == 'REFR':
                self.refr.set_scope(SCOPE_MINE)
            elif key == 'NAV':
                self.refr.set_scope(SCOPE_NAV)
        except Exception:
            pass

    # ───────── 내부 로더 ─────────

    def _open_overlay_editor(self):
        """설명·주석 탭 「내 설명」 — 덮개 편집 팝업 (2026-08-26).

        앵커가 구절이면 절 자산, 렌즈 노드/컨테이너면 렌즈 글(이름 열쇠)이다 —
        overlay_edit 가 가른다. 내 렌즈(sys 에 없는 유닛)는 안내만 한다."""
        vid_s = str(getattr(self, '_curr_view_id', '') or '')
        if ':' not in vid_s:
            return
        t, n = vid_s.split(':', 1)
        try:
            n = int(str(n).split('@')[0].split('_')[0])
        except Exception:
            return
        import overlay_edit
        import verse_tier
        import appdb
        try:
            with appdb.connect(self.db_path) as conn:
                lang = verse_tier.get_desc_lang(conn)
                mode = verse_tier.get_desc_mode(conn)
        except Exception:
            lang, mode = 'KO', 'LAY'
        overlay_edit.open_editor(
            self, self.db_path, t, n, lang, mode=mode,
            on_saved=lambda: self._refresh_desc(
                getattr(self, '_curr_view_id', None)))

    def _refresh_desc(self, view_id):
        # 같은 부품을 쓰므로 여기도 약명을 적는다(P2 와 한 모양).
        try:
            self._descgrp.set_ref(pure_vid_from_view(view_id))
        except Exception:
            pass
        text = ''
        try:
            text = self.fetch_desc_fn(view_id) if view_id else ''
        except Exception as e:
            text = f'(설명문 로드 오류: {e})'
        if not text:
            text = i18n.t('COMMON_NODESC','(설명문이 없습니다.)')
        self._desc_base = text
        # 노드가 바뀌면 **속 접힘은 닫는다** — 앞 구절에서 펼쳐 둔 이웃이
        # 다음 구절에도 열려 있으면 어느 절의 것인지 헷갈린다. 겉줄(열림/닫힘)은
        # 그대로 둔다(렌즈 「이 마디의 흐름 연결」과 같은 규칙).
        self._fold_kids = set()
        self._fold_extra = 0
        self._render_desc()

    # ── 「이 구절의 연결」 접힘줄 (2026-08-21 `0.txt` 4번) ────────────────
    #  > 「부모구절 클릭하고 설명 탭에서 연결설명 접힘 줄 클릭하면 자녀들과
    #  >  연결설명문을 열거하는 기능 … 너무 많으면 더보기 기능으로」 (사용자)
    #
    #  ★ **두 겹 접힘** — 겉줄을 열면 **약명만** 늘어서고, 그 줄을 눌러야
    #    설명문이 열린다. 한 번에 다 펴면 수십 개 글이 쏟아져 「아직 자녀
    #    구절 본문이 무엇인지도 모르는 채」가 된다(사용자 우려 그대로).
    #  ★ **P4 에만** 있다 — P2 는 한 구절을 읽는 자리고, 연결은 P4 의 일이다.
    #  ⚠ 색은 그릴 때마다 역할로 다시 입힌다(§36-5b) — Text 태그 색은
    #    `ui_theme.paint` 가 못 본다.
    FOLD_PAGE = 20

    def _fold_c(self, role, dflt):
        try:
            import ui_theme
            return ui_theme.C(role) or dflt
        except Exception:
            return dflt

    FOLD_MARK = '\x00FOLD\x00'

    def _render_desc(self):
        """설명문을 그린다. **접힘줄은 자리표가 있으면 그 자리에**, 없으면 맨 끝.

        ★ 사용자가 0.txt 7-2 에 적은 순서 — 「부모와의 연결설명문 → **자녀와의
          연결설명문** → 아래에 구절설명문/묵상질문/묵상기도」.
        ⚠ 예전에는 **무조건 맨 끝**이라, 설명문이 길면 접힘줄이 화면 밖으로
          밀려 **없는 것처럼 보였다**(실측 `bbox=None`·`yview 0.00~0.57`).
          사용자 신고 「자녀와의 설명문 접힘줄은 없다」의 정체가 이것이다.
        """
        t = self.desc_txt
        t.config(state='normal')
        t.delete('1.0', 'end')
        base = self._desc_base or ''
        head, sep, tail = base.partition(self.FOLD_MARK)
        # ⚠ 자리표 앞뒤의 빈 줄을 눌러 둔다 — `_render_fold` 가 스스로 앞에
        #   빈 줄을 넣으므로 그대로 두면 **넉 줄이 빈다**(실측).
        t.insert('1.0', head.rstrip('\n') if sep else head)
        try:
            self._render_fold(t)
        except Exception as e:
            print('[fold] %s' % e)
        if sep:
            # 자리표 뒤(구절설명문·묵상질문·묵상기도)를 이어 붙인다.
            # ⚠ 자리표 줄 자체는 버린다 — 그 자리를 접힘줄이 대신한다.
            t.insert('end', '\n' + tail.lstrip('\n'))
        t.config(state='disabled')
        # ★ 2026-10-21 설명 칸마다 [AI 분석](P2 와 같은 문 · user_main 이 심는다)
        cb = getattr(self, 'on_desc_marks', None)
        if callable(cb) and self._curr_view_id:
            try:
                cb(t, pure_vid_from_view(self._curr_view_id))
            except Exception as e:
                print('[desc marks] %s' % e)

    def _render_fold(self, t):
        if self.fetch_links_fn is None or not self._curr_view_id:
            return
        items = self.fetch_links_fn(self._curr_view_id) or []
        if not items:
            return
        acc = self._fold_c('accent', '#1A5276')
        dim = self._fold_c('fg_dim', '#7F8C8D')
        t.tag_config('fold_h', foreground=acc, spacing1=8)
        t.tag_config('fold_k', foreground=acc)
        t.tag_config('fold_r', foreground=dim)
        t.tag_config('fold_d', lmargin1=28, lmargin2=28, spacing3=4)
        t.tag_config('fold_more', foreground=dim)

        def hand(tag):
            t.tag_bind(tag, '<Enter>', lambda _e: t.config(cursor='hand2'))
            t.tag_bind(tag, '<Leave>', lambda _e: t.config(cursor=''))

        # ⚠ 앞이 비어 있으면 빈 줄을 넣지 않는다 — 루트 노드는 위에 아무것도
        #   없어 창 맨 위가 두 줄 비었다(2026-08-23 실측).
        if t.get('1.0', 'end-1c').strip():
            t.insert('end', '\n\n')
        t.insert('end', '%s %s (%d)\n' % (
            '▾' if self._fold_open else '▸',
            i18n.t('P4_FOLD_LINKS', '이 구절의 연결'), len(items)), 'fold_h')
        t.tag_bind('fold_h', '<Button-1>', lambda _e: self._fold_toggle())
        hand('fold_h')
        if not self._fold_open:
            return
        show = items[:self.FOLD_PAGE + self._fold_extra]
        for it in show:
            key = it['key']
            tag = 'fk_' + key.replace(':', '_')
            opened = key in self._fold_kids
            t.insert('end', '   %s %s' % ('▾' if opened else '▸', it['label']),
                     ('fold_k', tag))
            if it.get('rel'):
                t.insert('end', '  %s' % it['rel'], ('fold_r', tag))
            t.insert('end', '\n')
            t.tag_bind(tag, '<Button-1>',
                       lambda _e, k=key: self._fold_toggle_kid(k))
            hand(tag)
            if opened:
                d = ''
                if self.fetch_link_desc_fn is not None:
                    d = self.fetch_link_desc_fn(self._curr_view_id, key) or ''
                if not d:
                    d = i18n.t('P4_FOLD_NODESC', '(연결설명문이 없습니다.)')
                t.insert('end', d + '\n', 'fold_d')
                if self.on_link_ai is not None and key.startswith('BIBLE:'):
                    atag = 'fa_' + key.replace(':', '_')
                    t.tag_config(atag, foreground=acc, underline=True, lmargin1=28)
                    t.insert('end', i18n.t('M_AI_ANALYZE', 'AI 분석') + '\n', atag)
                    t.tag_bind(atag, '<Button-1>',
                               lambda _e, k=key, v=self._curr_view_id: self.on_link_ai(v, k))
                    hand(atag)
        # ⚠ 잘랐으면 **알린다** — 조용히 자르면 「왜 없지?」가 된다(§0)
        if len(items) > len(show):
            t.insert('end', '   … %s (%d)\n' % (
                i18n.t('COMMON_MORE', '더 보기'), len(items) - len(show)),
                'fold_more')
            t.tag_bind('fold_more', '<Button-1>', lambda _e: self._fold_more())
            hand('fold_more')

    def _fold_toggle(self):
        self._fold_open = not self._fold_open
        self._render_desc()

    def _fold_toggle_kid(self, key):
        if key in self._fold_kids:
            self._fold_kids.discard(key)
        else:
            self._fold_kids.add(key)
        self._render_desc()

    def _fold_more(self):
        self._fold_extra += self.FOLD_PAGE
        self._render_desc()

    def _reload_p2_panels(self, vid):
        if vid is None:
            return
        for panel in (self.note, self.refr, self.commentary, self.links,
                      getattr(self, 'links_text', None),
                      getattr(self, 'song', None)):
            if panel is None:
                continue
            try:
                panel.load(vid)
            except Exception as e:
                print(f'[NodePanel reload {panel.__class__.__name__}] {e}')
        # ★ 구속사연결(옛 연쇄) 자동 로드 (2026-08-19 사용자 승인 — C 마커 폐기
        #   대체). 구절단락처럼 노드 클릭이면 늘 채워진다.
        #   탭 선택은 강제하지 않는다(§3 — 보던 탭 유지).
        chain_n = None
        try:
            from p4_chain_slide import chains_for
            codes = chains_for(self.db_path, vid)
            self.chain.show_for(vid, codes)
            chain_n = len(codes)
        except Exception as e:
            print(f'[NodePanel chain autoload] {e}')
        self._chain_n = chain_n
        # ★ 통합 목록은 **그 방식일 때만** 읽는다 — 서브탭인데 읽으면 갈래 여섯을
        #   한 번 더 훑는 헛일이다(절마다 난다).
        if self.one is not None and self._one_mode():
            try:
                self.one.load(vid)
            except Exception as e:
                print('[node one load] %s' % e)
        self._update_tab_counts(vid, chain_n)

    def _update_tab_counts(self, vid, chain_n=None):
        """개수 배지 — 열 갈래(2026-09-15): 갈래마다 제 수, 0 도 (0).
        설명·구절단락·주석은 늘 있으므로 빈칸(빈칸 = 있음)."""
        try:
            lang = (self.lang_provider() or 'KO') if self.lang_provider else 'KO'
        except Exception:
            lang = 'KO'
        c = tab_counts(self.db_path, vid, lang)
        mine_n, nav_n = c.get('mine'), c.get('nav')
        links_n, note_n = c.get('links'), c.get('note')
        comm_n = c.get('comm')
        lv_n, lt_n = c.get('lvideo'), c.get('ltext')

        # 열 갈래(2026-09-15) — 갈래마다 제 수. 설명·구절단락·주석은 빈칸(있음).
        T = self.tabs
        import p2_tab_settings as _ts
        cnt = {'NOTE': note_n, 'REFR': mine_n, 'NAV': nav_n, 'FLOW': chain_n,
               'COMM': comm_n, 'VIDEO': lv_n, 'TEXT': lt_n,
               'SONG': c.get('song')}
        try:
            for k, n in cnt.items():
                T.set_count(k, n)
            # ★★ 빈 갈래 감추기 — P2 와 **같은 문**(1.txt 3-2)
            hide = _ts.read_hide_empty(self.db_path, 'P4_NODE_HIDE_EMPTY')
            one = self._one_mode()
            main = set(self._main_keys())
            # ⚠ 화면별 목록을 쓴다 — 전역 `HIDEABLE` 을 쓰면 표가 갈리는 날
            #   이 화면만 조용히 옛 규칙을 따른다.
            for k in _ts.hideable_of(self.MAIN_KEY):
                base = (k in main) if one else True
                T.set_visible(k, _ts.visible_with(k, cnt.get(k), base, hide))
            # ★ 통합 갈래의 수 = 더보기로 간 갈래들의 합(P2 와 같은 셈)
            import p2_one_list as _pol
            _rest = [k for k in _pol.ORDER if k not in main]
            _ns = [cnt.get(k) for k in _rest if cnt.get(k) is not None]
            T.set_count('ONE', sum(_ns) if _ns else None)
            T.set_visible('ONE', one)
        except Exception as e:
            print('[node counts] %s' % e)

    def _update_title(self):
        if self._curr_vid is None:
            self._title_lbl.config(text='')
            return
        try:
            lang = self.lang_provider() or 'KO'
            with appdb.connect(self.db_path) as c:
                row = c.execute(
                    "SELECT bn.short_name, bi.chapter, bi.verse "
                    "  FROM bible_index bi "
                    "  LEFT JOIN book_names bn ON bn.book_code=bi.bcode "
                    "                         AND bn.lang_code=? "
                    " WHERE bi.verse_id=?",
                    (lang, self._curr_vid)).fetchone()
            if row:
                self._title_lbl.config(text=f'{row[0] or ""} {row[1]}:{row[2]}')
            else:
                self._title_lbl.config(text=f'vid {self._curr_vid}')
        except Exception:
            self._title_lbl.config(text=f'vid {self._curr_vid}')

    def _attach_if_hidden(self):
        """패널을 캔버스 **오른쪽**에 붙인다 (2026-07-30, 91.txt ①).

        이전에는 `before=anchor` 로 캔버스 **왼쪽**에 끼워 넣었다. 그러면 캔버스 프레임의
        시작점이 패널 폭만큼 오른쪽으로 밀려, 방금 클릭한 노드를 포함해 화면 전체가
        훅 이동했다. `after=` 로 바꾸면 캔버스 원점이 그대로라 클릭한 노드가 제자리에
        남고, 잘리는 것은 오른쪽 끝뿐이다. P2 탭 모음 배치와도 일관된다.

        오버레이가 아니라 PanedWindow 의 한 칸이므로, 캔버스를 아무리 오른쪽으로
        드래그해도 패널이 가려지지 않는다(캔버스의 '무한 확장'은 스크롤 좌표 공간일 뿐).

        ★ **잠금 모드면 스스로 열리지 않는다** (2026-08-20 — [설명접기]가 ✕ 와
          같아서는 안 된다는 사용자 지시. 접기 = 노드를 눌러도 안 열림).
          잠금은 [설명펴기]로만 풀린다.
        """
        if self.winfo_ismapped():
            return
        try:
            if getattr(self.winfo_toplevel(), '_link_panel_locked', False):
                return
        except Exception:
            pass
        pw = self.master
        w = self._load_width()
        if isinstance(pw, tk.PanedWindow):
            try:
                if self._pw_anchor is not None:
                    pw.add(self, after=self._pw_anchor,
                           width=w, minsize=self._WIDTH_MIN)
                else:
                    pw.add(self, width=w, minsize=self._WIDTH_MIN)
                # ★ stretch 교정 (2026-07-31) — PanedWindow 기본값은 stretch='last' 라
                # **마지막 pane 이 남는 공간을 전부 흡수**한다. 패널을 캔버스 오른쪽으로
                # 옮기면서 패널이 마지막 pane 이 됐고, 그 결과 위에서 지정한 width(저장 폭)가
                # 무시되고 패널이 늘어났다(왼쪽에 있을 땐 캔버스가 마지막이라 문제없었다).
                # 캔버스가 창 크기 변화를 흡수하고 패널은 제 폭을 지키게 한다.
                pw.paneconfigure(self, stretch='never')
                if self._pw_anchor is not None:
                    pw.paneconfigure(self._pw_anchor, stretch='always')
            except Exception as e:
                print(f'[NodePanel attach] {e}')
                self.pack(side='right', fill='y')
        else:
            self.pack(side='right', fill='y')
