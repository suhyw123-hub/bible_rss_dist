# -*- coding: utf-8 -*-
"""db_word_register.py — 스트롱 일반 낱말 전수를 용어사전(엔티티 층)에 등록 (영구).

2026-09-02 (181차) 사용자 지시: 「스트롱 사전 자체를 용어사전이 담는 작업을
먼저 진행해야 할 것 같다. … 지금 용어사전은 여전히 500개가 안 된다. 이 상태로
유닛과 용어를 연결해 봐야 스트롱 단어를 추가한 다음에 또 작업해야 할 것이다」.

무엇을 하나:
  `sys_lemma_master` 의 **일반 낱말(GENERAL)** 전부를 TERM 엔티티로 등록한다.
  · 코드 = `W_` + 스트롱 (W_H2403 꼴) · importance 1 · json_detail.subtype='LEX'
  · 이름 = EN 「음역 (짧은 뜻)」 — KO 이름은 안 짓는다(화면이 EN 폴백.
    한글 음역 기계 생성은 품질이 안 서서, 승격 때 사람이 짓는다)
  · 낱말 앵커(sys_entity_lemma) 1행 — 검색·[Strong] 갈래·연결이 이것으로 산다
  · **설명문 없음** — [Strong] 갈래(1890 사전 본문)가 내용을 맡는다
채택 기준 (0.txt 1번 — 「유형별로 검토하고 필요한 것만 채택」):
  · GENERAL(일반 낱말)만 — 기능어(FUNCTION)는 제외(사용자 지시 그대로),
    고유명사(PROPER)는 기존 인물·장소 체계와 겹쳐 별도 판단으로 보류.
  · **이미 어느 엔티티가 안은 스트롱은 건너뛴다** — 하타트가 안은 H2403 을
    또 만들면 동일인 두 항목이 된다.

⚠⚠ **낱말연결(LEXICAL)은 만들지 않는다.** 일반 낱말 1.1만 개의 출현 28만 절을
  전부 벌리면 P1 티커가 **절의 모든 낱말 칩으로 뒤덮인다**(절당 10~15개).
  절 목록은 승격(정성 등록) 때 relink 로 연다. 낱말 항목의 내용은 [Strong]
  갈래·출현 수(마스터)가 맡는다.

사용:
  python db_word_register.py --selftest   (의무 — 메모리 DB)
  python db_word_register.py --register   (멱등)
  python db_word_register.py --status
  python db_word_register.py --undo       (W_ 등록분 전부 걷기)
"""
import io
import re
import sys

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

NL = chr(10)


def _gloss_short(g, cap=42):
    """마스터 정의에서 이름 괄호용 짧은 뜻 — 첫 갈래만, 길면 자른다."""
    g = re.split(r'[;]', (g or '').strip())[0].strip().rstrip('.,')
    g = re.sub(r'\s+', ' ', g)
    return (g[:cap - 1] + '…') if len(g) > cap else g


def _name_en(translit, gloss):
    g = _gloss_short(gloss)
    return '%s (%s)' % (translit, g) if g else (translit or '')


def _enti_links(conn, ids):
    """엔티티가 서는 자리의 연결 수 — 번호 충돌 함정을 피한다(§97차:
    번호가 같아도 유형이 다르면 딴 자산. ENTI_VERS 의 target 은 절 번호라
    전체 표를 번호로 뒤지면 남의 행이 걸린다 — 2026-09-02 실측 180건 오탐)."""
    q = ','.join('?' * len(ids))
    sql = ("SELECT COUNT(*) FROM sys_link_asset WHERE"
           " (link_type LIKE ? AND clicked_id IN (" + q + "))"
           " OR (link_type LIKE ? AND target_id IN (" + q + "))")
    return conn.execute(sql, ['ENTI%'] + list(ids) + ['%_ENTI'] + list(ids)
                        ).fetchone()[0]


def targets(conn):
    """등록 대상 — GENERAL·LIVE·미소유 스트롱."""
    owned = {r[0] for r in conn.execute('SELECT strong FROM sys_entity_lemma')}
    out = []
    for st, lang, tr, gl in conn.execute(
            "SELECT strong, lang_code, COALESCE(translit,''), COALESCE(gloss,'')"
            " FROM sys_lemma_master WHERE wtype='GENERAL'"
            " AND record_status='LIVE' ORDER BY strong"):
        if st in owned:
            continue
        # ⚠ 스트롱 번호 체계의 결번(G2717·G3203~G3302)은 낱말이 아니다 —
        #   음역도 뜻도 없는 행을 만들면 이름 없는 항목이 된다(실측 ~101개).
        if not tr.strip() and not gl.strip():
            continue
        out.append((st, lang, tr, gl))
    return out


def register(conn):
    """멱등 — 있는 W_ 코드는 건너뛴다. 결번 잔재는 걷는다."""
    # 결번으로 이미 만들어진 빈 항목 청소 (연결 없는 것만 — 안전)
    empt = [r[0] for r in conn.execute(
        "SELECT m.entity_id FROM sys_entity_master m"
        " JOIN sys_lemma_master lm ON 'W_'||lm.strong = m.entity_code"
        " WHERE m.entity_code LIKE 'W\\_%' ESCAPE '\\'"
        " AND TRIM(COALESCE(lm.translit,''))='' AND TRIM(COALESCE(lm.gloss,''))=''")]
    if empt:
        q = ','.join('?' * len(empt))
        used = _enti_links(conn, empt)
        if not used:
            conn.execute("DELETE FROM sys_entity_lemma WHERE entity_id IN (%s)" % q, empt)
            conn.execute("DELETE FROM sys_text_asset WHERE clicked_id IN (%s)"
                         " AND text_type='ENTITY_NAME'" % q, empt)
            conn.execute("DELETE FROM sys_entity_master WHERE entity_id IN (%s)" % q, empt)
            print('결번 빈 항목 %d 걷음' % len(empt))
    rows = targets(conn)
    have = {r[0] for r in conn.execute(
        "SELECT entity_code FROM sys_entity_master WHERE entity_code LIKE 'W\\_%' ESCAPE '\\'")}
    n_ent = 0
    for st, lang, tr, gl in rows:
        code = 'W_' + st
        if code in have:
            continue
        cur = conn.execute(
            "INSERT INTO sys_entity_master(entity_code,entity_type,importance,"
            "json_detail,record_status)"
            " VALUES(?, 'TERM', 1, '{\"subtype\": \"LEX\"}', 'LIVE')", (code,))
        eid = cur.lastrowid
        conn.execute(
            "INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,contents,"
            "record_status) VALUES(?,'ENTITY_NAME','EN',?,'LIVE')",
            (eid, _name_en(tr, gl)))
        conn.execute(
            "INSERT INTO sys_entity_lemma(entity_id,lang_code,strong,translit,"
            "gloss,sort_order,record_status) VALUES(?,?,?,?,?,1,'LIVE')",
            (eid, lang, st, tr, _gloss_short(gl, 60)))
        n_ent += 1
    conn.commit()
    print('등록 %d (건너뜀 %d — 이미 있음/소유됨)' % (n_ent, len(rows) - n_ent))


def status(conn):
    n = conn.execute(
        "SELECT COUNT(*) FROM sys_entity_master WHERE entity_code LIKE 'W\\_%'"
        " ESCAPE '\\' AND COALESCE(record_status,'LIVE')='LIVE'").fetchone()[0]
    t = conn.execute(
        "SELECT COUNT(*) FROM sys_entity_master"
        " WHERE COALESCE(record_status,'LIVE')='LIVE'").fetchone()[0]
    print('낱말(W_) %d · 전체 엔티티 %d' % (n, t))


def undo(conn):
    """W_ 등록분 전부 걷기 — 이 도구만 W_ 코드를 만든다."""
    ids = [r[0] for r in conn.execute(
        "SELECT entity_id FROM sys_entity_master WHERE entity_code LIKE 'W\\_%'"
        " ESCAPE '\\'")]
    if not ids:
        print('걷을 것 없음')
        return
    q = ','.join('?' * len(ids))
    # 연결이 붙었으면 걷지 않는다 — 데이터를 잃는다
    used = _enti_links(conn, ids)
    if used:
        raise SystemExit('연결 %d건이 붙어 있다 — undo 를 거부한다(잃는다)' % used)
    conn.execute("DELETE FROM sys_entity_lemma WHERE entity_id IN (%s)" % q, ids)
    conn.execute("DELETE FROM sys_text_asset WHERE clicked_id IN (%s)"
                 " AND text_type='ENTITY_NAME'" % q, ids)
    conn.execute("DELETE FROM sys_entity_master WHERE entity_id IN (%s)" % q, ids)
    conn.commit()
    print('걷음 %d' % len(ids))


def selftest():
    import sqlite3
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    conn = sqlite3.connect(':memory:')
    conn.execute("CREATE TABLE sys_lemma_master(strong TEXT PRIMARY KEY,"
                 " lang_code TEXT, translit TEXT, gloss TEXT, wtype TEXT,"
                 " record_status TEXT)")
    conn.execute("CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY,"
                 " entity_code TEXT UNIQUE, entity_type TEXT, importance INT,"
                 " json_detail TEXT, record_status TEXT)")
    conn.execute("CREATE TABLE sys_entity_lemma(lemma_id INTEGER PRIMARY KEY,"
                 " entity_id INT, lang_code TEXT, strong TEXT, translit TEXT,"
                 " gloss TEXT, sort_order INT, record_status TEXT)")
    conn.execute("CREATE TABLE sys_text_asset(sys_text_id INTEGER PRIMARY KEY,"
                 " clicked_id INT, text_type TEXT, lang_code TEXT,"
                 " contents TEXT, record_status TEXT)")
    conn.execute("CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY,"
                 " link_type TEXT, clicked_id INT, target_id INT)")
    rows = [('H1', 'HE', 'ab', 'father; chief', 'GENERAL', 'LIVE'),
            ('H2', 'HE', 'ab2', 'x', 'PROPER', 'LIVE'),      # 고유 — 제외
            ('H3', 'HE', 'al', 'not', 'FUNCTION', 'HIDE'),   # 기능어 — 제외
            ('H4', 'HE', 'owned', 'y', 'GENERAL', 'LIVE')]   # 소유됨 — 제외
    conn.executemany("INSERT INTO sys_lemma_master VALUES(?,?,?,?,?,?)", rows)
    conn.execute("INSERT INTO sys_entity_master VALUES(1,'T_X','TERM',5,NULL,'LIVE')")
    conn.execute("INSERT INTO sys_entity_lemma VALUES(1,1,'HE','H4','o','y',1,'LIVE')")
    register(conn)
    t('GENERAL 미소유만 등록(1)', conn.execute(
        "SELECT COUNT(*) FROM sys_entity_master WHERE entity_code LIKE 'W\\_%'"
        " ESCAPE '\\'").fetchone()[0] == 1)
    t('이름 = 음역 (짧은 뜻)', conn.execute(
        "SELECT contents FROM sys_text_asset").fetchone()[0] == 'ab (father)')
    t('앵커 생성', conn.execute(
        "SELECT COUNT(*) FROM sys_entity_lemma WHERE strong='H1'").fetchone()[0] == 1)
    register(conn)
    t('멱등', conn.execute(
        "SELECT COUNT(*) FROM sys_entity_master").fetchone()[0] == 2)
    undo(conn)
    t('undo — W_ 걷힘', conn.execute(
        "SELECT COUNT(*) FROM sys_entity_master").fetchone()[0] == 1)
    # 탐지력 — 연결이 붙어 있으면 undo 거부
    register(conn)
    wid = conn.execute("SELECT entity_id FROM sys_entity_master"
                       " WHERE entity_code='W_H1'").fetchone()[0]
    conn.execute("INSERT INTO sys_link_asset(link_type,clicked_id,target_id)"
                 " VALUES('BUNT_ENTI', 9, ?)", (wid,))
    try:
        undo(conn)
        t('탐지력 — 연결 붙은 undo 거부', False)
    except SystemExit:
        t('탐지력 — 연결 붙은 undo 거부', True)
    conn.close()
    print('db_word_register selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect('bible_master.db')
    try:
        if '--register' in sys.argv:
            register(conn)
        elif '--undo' in sys.argv:
            undo(conn)
        else:
            status(conn)
    finally:
        conn.close()
