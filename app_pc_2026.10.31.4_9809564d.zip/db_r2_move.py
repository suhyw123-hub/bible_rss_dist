"""db_r2_move.py — 배포 저장소를 Cloudflare R2 로 옮기는 도구 (2026-10-29 신설·영구)

차례(사용자가 Cloudflare 화면에서 버킷·열쇠를 만든 뒤):
  1) --import <파일>        열쇠 셋을 secret_store 로 담는다(값은 화면에 안 찍는다)
  2) --test <버킷>          접속만 확인(쓰지 않는다)
  3) --copy <버킷> [--dry]  지금 GitHub 배포 저장소의 파일을 R2 로 그대로 옮긴다
  4) --add <버킷> <공개주소> 관리자 업로드 대상에 R2 를 **더한다**(GitHub 는 그대로 — 두 곳에 함께 올린다)
  --status                  열쇠 · 대상 목록

★ 열쇠 파일 꼴(한 줄에 하나 · 순서 무관):
    R2_ACCOUNT_ID=…
    R2_ACCESS_KEY_ID=…
    R2_SECRET_ACCESS_KEY=…
  ⚠ 담은 뒤 그 파일은 지운다(--import 가 지울지 묻지 않고 **지운다** — 평문 열쇠를 남기지 않는다).
⚠ 서버에 실제로 올리는 것(--copy · 대상 추가 뒤의 발행)은 **사용자가** 돌린다.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import rss_transport as RT  # noqa: E402

KEYS = RT.R2_SECRET_NAMES


def parse_keyfile(text):
    out = {}
    for line in (text or '').splitlines():
        line = line.strip().lstrip('﻿')
        if not line or line.startswith('#') or '=' not in line:
            continue
        k, v = line.split('=', 1)
        k, v = k.strip().upper(), v.strip().strip('"').strip("'")
        v = v.strip('()（） ')                 # 「괄호 안에」 적은 꼴도 받는다
        if k == 'R2_ACCOUNT_ID':              # S3 API 주소를 통째로 적어도 32자리만 뽑는다
            import re as _re
            m = _re.search(r'[0-9a-f]{32}', v)
            v = m.group(0) if m else v
        if k in KEYS and v:
            out[k] = v
    return out


def do_import(path):
    import secret_store as SS
    with open(path, encoding='utf-8') as f:
        got = parse_keyfile(f.read())
    miss = [k for k in KEYS if k not in got]
    if miss:
        print('빠진 열쇠:', ', '.join(miss), '— 아무것도 담지 않았습니다')
        return False
    for k in KEYS:
        SS.put(k, got[k])
    try:
        os.remove(path)
        gone = '열쇠 파일을 지웠습니다'
    except Exception as e:                                        # noqa: BLE001
        gone = '⚠ 열쇠 파일을 못 지웠습니다(%s) — 손으로 지우세요' % e
    print('담음:', ', '.join('%s(%d자)' % (k, len(got[k])) for k in KEYS), '·', gone)
    return True


def src_dir():
    g = RT.GitTransport(RT.GH_SSH)
    g._ensure()
    g._git('pull', '--ff-only')
    return g.work


def do_copy(bucket, dry=False):
    t = RT.R2Transport(bucket)
    ok, msg = t.test()
    print(msg)
    if not ok:
        return False
    work = src_dir()
    names = sorted(n for n in os.listdir(work)
                   if n != '.git' and os.path.isfile(os.path.join(work, n)))
    have = set(t.listdir())
    todo = [n for n in names if not (n in have and RT._IMMUTABLE_RE.search(n))]
    size = sum(os.path.getsize(os.path.join(work, n)) for n in todo)
    print('원본 %d개 · R2 에 이미 %d개 · 옮길 것 %d개 (%.1f MB)'
          % (len(names), len(have), len(todo), size / 1e6))
    if dry:
        return True
    bad = 0
    for i, n in enumerate(todo, 1):
        with open(os.path.join(work, n), 'rb') as f:
            okp, m = t.put_bytes(n, f.read())
        if not okp:
            bad += 1
            print('  실패', m)
        elif i % 50 == 0:
            print('  …%d/%d' % (i, len(todo)))
    print('끝 — 실패 %d' % bad)
    return bad == 0


def do_add(bucket, public):
    import rss_publish as RP
    ss = RP.get_servers()
    ss = [s for s in ss if s.get('transport') != 'R2']
    ss.append({'label': 'Cloudflare R2', 'role': 'PRIMARY', 'transport': 'R2',
               'location': bucket, 'public': public.rstrip('/'), 'enabled': True})
    RP.set_servers(ss)
    print('대상:', ' · '.join('%s(%s)' % (s.get('label'), s.get('transport')) for s in ss))


def status():
    c = RT.r2_creds()
    print('R2 열쇠:', '있음' if c else '없음')
    try:
        import rss_publish as RP
        for s in RP.get_servers():
            print(' -', s.get('label'), s.get('transport'), s.get('location'),
                  '켬' if s.get('enabled', True) else '끔')
    except Exception as e:                                        # noqa: BLE001
        print('대상 목록 못 읽음:', e)


def selftest():
    ok = 0
    r = parse_keyfile('﻿R2_ACCOUNT_ID=abc\n# x\nr2_access_key_id = "k1"\nR2_SECRET_ACCESS_KEY=s=2\nOTHER=1')
    ok += r == {'R2_ACCOUNT_ID': 'abc', 'R2_ACCESS_KEY_ID': 'k1', 'R2_SECRET_ACCESS_KEY': 's=2'}
    ok += parse_keyfile('R2_ACCOUNT_ID=') == {}
    r = parse_keyfile('R2_ACCOUNT_ID=(https://' + 'a' * 32 + '.r2.cloudflarestorage.com)\nR2_ACCESS_KEY_ID=(k)')
    ok += r == {'R2_ACCOUNT_ID': 'a' * 32, 'R2_ACCESS_KEY_ID': 'k'}
    print('db_r2_move %d/3 %s' % (ok, 'PASS' if ok == 3 else 'FAIL'))
    return ok == 3


if __name__ == '__main__':
    a = sys.argv[1:]
    if not a or '--status' in a:
        status()
    elif '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    elif a[0] == '--import' and len(a) > 1:
        do_import(a[1])
    elif a[0] == '--test' and len(a) > 1:
        print(RT.R2Transport(a[1]).test())
    elif a[0] == '--copy' and len(a) > 1:
        do_copy(a[1], dry='--dry' in a)
    elif a[0] == '--add' and len(a) > 2:
        do_add(a[1], a[2])
    else:
        print(__doc__)
