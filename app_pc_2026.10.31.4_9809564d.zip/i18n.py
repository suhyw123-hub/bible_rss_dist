# i18n.py
"""
i18n.py — UI 문자열 다국어 지원 모듈.

ui_strings 테이블을 앱 시작 시 메모리에 전량 로드 → O(1) 조회.
언어 전환은 set_lang() 한 줄로 완료 (재로드 불필요).

사용:
    from i18n import load, t, set_lang, get_lang

    load('bible_master.db', 'KO')       # 앱 시작 시 (또는 DB 변경 후)
    set_lang('JA')                      # 언어 전환
    label = t('UI_PLAN_STAGE_EVENT')    # 현재 언어로 조회
    label = t('UI_PLAN_STAGE_EVENT', '?')  # 키 없을 때 fallback
"""

_cache: dict[tuple[str, str], str] = {}
_lang: str = 'KO'


def load(db_path: str, lang_code: str = 'KO') -> None:
    """ui_strings 전체를 메모리 캐시에 로드. 앱 시작 시 또는 DB 변경 후 호출."""
    global _cache, _lang
    _lang = lang_code
    try:
        import sqlite3
        import appdb
        with appdb.connect(db_path) as conn:
            rows = conn.execute(
                "SELECT string_id, lang_code, string_value FROM ui_strings"
            ).fetchall()
        _cache = {(sid, lc): sv for sid, lc, sv in rows}
    except Exception:
        _cache = {}


def set_lang(lang_code: str) -> None:
    """활성 언어 전환. 재로드 불필요 — 전 언어 데이터가 이미 캐시에 있음."""
    global _lang
    _lang = lang_code


def get_lang() -> str:
    return _lang


def t(key: str, fallback: str = '') -> str:
    """현재 언어로 string_id 조회.
    조회 순서: 현재 언어 → EN → KO → fallback 인자 → key 자체.
    번역 누락 시 KO보다 EN을 먼저 표시 — 비한국어 사용자가 이해할 수 있도록(범용성).
    (현재 언어가 EN/KO이면 첫 조회에서 바로 반환되므로 추가 비용 없음.)"""
    v = _cache.get((key, _lang))
    if v:
        return v
    v = _cache.get((key, 'EN'))
    if v:
        return v
    v = _cache.get((key, 'KO'))
    if v:
        return v
    return fallback if fallback else key
