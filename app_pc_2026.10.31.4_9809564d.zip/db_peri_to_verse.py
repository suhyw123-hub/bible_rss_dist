# -*- coding: utf-8 -*-
"""교리 단락연결 → **구절구간 연결** 이관 + 설명문 소급 재작성 (영구 도구 · 2026-09-01).

★★★ 왜 — 사용자 확정 두 개가 만나는 자리다.
  · 147차 「고정된 단락 단위로 연결하기 보다는 각 용어의 성격에 따라
    **구절구간을 연결**하는 것이 유연할 것이다 … 페리코프 단위로 연결했다가는
    아무 의미도 없는 단락의 구절들을 다 읽어야 한다」
  · 148차 「구절 내용을 그대로 반복하는 것은 결코 설명문이 아니다. 명확하게
    의미연결이라고 판단할 수 있는 **근거를 밝혀야 비로소 설명문**이다」
  기존 = 교리 822건이 **단락**에 걸려 있고 설명문 876편의 **96%가 색인체**다.
  ⇒ 한 건씩: **근거가 되는 구절구간**으로 옮기고, 설명문을 근거 산문으로 다시 쓴다.

★★ 세 가지 길 (초안 항목마다 하나):
  · `verse`(+`end`) — 구간 의미연결(THEMATIC)을 새로 만들고 설명문을 단다
  · `lex`           — **낱말이 이미 그 절에 있다**(낱말연결 존재). THEMATIC 을
                      만들면 한 목록에 같은 절이 두 번 뜨므로(§db_term_load 게이트)
                      **그 낱말연결 행에 설명문만 단다**
  · `drop`          — 연결만 걷는다(`why` 필수 — 왜 걷는지 남긴다)
  세 길 모두 **옛 단락연결과 그 설명문을 지운다**(관리자 = 물리삭제 · §10-1
  감사 로그 + 자체 백업표 `temp_entiperi_backup` 이 복구를 맡는다).

⚠⚠ 넣는 문은 `link_picker.add` (§135차) — INSERT 를 또 쓰지 않는다.
⚠⚠ selftest 는 **데이터 상태를 전제하지 않는다**(§0-5) — 시험용 단락연결을
  스스로 만들어 이관·복원까지 왕복하고 잔재 0 을 잰다.

사용법
  python db_peri_to_verse.py --selftest
  python db_peri_to_verse.py --status
  python db_peri_to_verse.py --check <초안.json>
  python db_peri_to_verse.py --apply <초안.json>     # 멱등
  python db_peri_to_verse.py --undo  <초안.json>     # 백업표에서 원복
"""
import io
import json
import os
import sys

import appdb
import link_picker as LP

BK = 'temp_entiperi_backup'
DESC_OLD, DESC_NEW = 'ENTITY_PERI_DESC', 'ENTITY_VERSE_DESC'

#: 문체 게이트 — §28-11 교단 귀속어 + §144차 옛말
BANNED = ('칼뱅', '칼빈', '개혁주의', '개혁파', '알미니안', '루터파', '장로교',
          '화체설', 'Calvin', 'Reformed', 'Lutheran', 'Arminian')
ARCHAIC = ('아뢰', '하옵', '나이다', '송축', '영영히')
CIRCLED = tuple(chr(x) for x in range(0x2460, 0x2474))


def _ensure_backup(conn):
    conn.execute(
        "CREATE TABLE IF NOT EXISTS %s ("
        " sys_link_id INTEGER, link_type TEXT, clicked_id INTEGER,"
        " target_id INTEGER, end_id INTEGER, rel_code TEXT, note TEXT,"
        " sort_order INTEGER, record_status TEXT,"
        " desc_json TEXT)" % BK)


def _entity(conn, code):
    r = conn.execute("SELECT entity_id FROM sys_entity_master"
                     " WHERE entity_code=?", (code,)).fetchone()
    return r and r[0]


def _peri(conn, pcode):
    return conn.execute(
        "SELECT pericope_id, start_vid, end_vid FROM sys_pericope_asset"
        " WHERE peri_code=?", (pcode,)).fetchone()


def _old_link(conn, eid, pid):
    return conn.execute(
        "SELECT sys_link_id, rel_code FROM sys_link_asset"
        " WHERE link_type='ENTI_PERI' AND clicked_id=? AND target_id=?"
        "   AND COALESCE(record_status,'LIVE')='LIVE'", (eid, pid)).fetchone()


def _vid(conn, bcode, ref):
    try:
        ch, vs = str(ref).split(':')
        r = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=?"
                         " AND chapter=? AND verse=?",
                         (int(bcode), int(ch), int(vs))).fetchone()
        return r and r[0]
    except Exception:
        return None


def _style(txt, en=False):
    """설명문 문체 검사 → [흠]. 근거의 유무는 사람이 본다 — 여기는 모양만."""
    import re
    bad = []
    t = (txt or '').strip()
    if not t:
        return ['비었다']
    if chr(10) in t:
        bad.append('개행 금지')
    if '—' in t:
        bad.append('「—」 금지 (색인체)')
    for w in BANNED:
        if w in t:
            bad.append('교단 귀속어 「%s」' % w)
    # ⚠ **「」 안 인용은 옛말 검사에서 뺀다** — §28-6 「인용은 개역한글 표기」.
    #   개역한글 본문에는 「있나이다」 같은 옛 어미가 그대로 있고 그것이 맞다.
    #   막는 것은 **우리 산문**에 스민 옛말이다(§144차).
    t_noq = re.sub(r'「[^「」]*」', '', t)
    for w in ARCHAIC:
        if w in t_noq:
            bad.append('옛말 「%s」 (인용 밖)' % w)
    for w in CIRCLED:
        if w in t:
            bad.append('동그라미 번호 금지')
    # ⚠ **길이 상한 없음** (2026-09-01 중간평가 — 「계량적 제한을 제거하라.
    #   제대로 이해하려면 때로는 1페이지도 좋다」). 하한만 — 빈 글 방지.
    if en:
        if len(t) < 40:
            bad.append('EN 너무 짧다 %d' % len(t))
        if not t.endswith(('.', '?')):
            bad.append('EN 끝맺음')
    else:
        if len(t) < 40:
            bad.append('KO 너무 짧다 %d' % len(t))
        # ★ 중간평가 지적 — 구조 지적·자기 평가 문장 금지(내용을 직접 설명한다)
        for w in ('이 짜임이', '이 이음새가', '정리한 본문이 없'):
            if w in t:
                bad.append('구조 지적·평가 문장 「%s」' % w)
        # 닫는 인용부호와 **끝의 괄호 참조**를 벗기고 끝을 본다 —
        # 「…부릅니다(고전 5:7).」 는 자연스러운 산문이다(§144차 _CLOSERS).
        t2 = re.sub(r'\([^()]*\)', '', t).strip()
        t2 = t2.rstrip('」』"\'’”)')
        if not t2.endswith(('니다.', '니까?', '입니다.', '집니다.')):
            if not t2.endswith(('다.', '까?')):
                bad.append('합니다체로 끝나지 않는다')
    return bad


def _resolve(conn, it):
    """초안 한 항목 → dict(전부 풀린 값) 또는 (None, 흠)."""
    code, pc = str(it.get('entity') or ''), str(it.get('peri') or '')
    eid = _entity(conn, code)
    if not eid:
        return None, '없는 용어 %s' % code
    p = _peri(conn, pc)
    if not p:
        return None, '없는 단락 %s' % pc
    pid, psv, pev = p
    bcode = conn.execute("SELECT bcode FROM bible_index WHERE verse_id=?",
                         (psv,)).fetchone()[0]
    out = dict(eid=eid, code=code, pid=pid, pc=pc, psv=psv, pev=pev,
               bcode=bcode, mode=None, sv=None, ev=None)
    if it.get('drop'):
        out['mode'] = 'drop'
        return out, None
    if it.get('lex'):
        out['mode'] = 'lex'
        out['sv'] = _vid(conn, bcode, it['lex'])
        if not out['sv']:
            return None, '%s — lex 구절을 못 찾았다 (%s)' % (code, it['lex'])
        return out, None
    out['mode'] = 'them'
    out['sv'] = _vid(conn, bcode, it.get('verse'))
    if not out['sv']:
        return None, '%s — verse 를 못 찾았다 (%s)' % (code, it.get('verse'))
    if it.get('end'):
        out['ev'] = _vid(conn, bcode, it['end'])
        if not out['ev']:
            return None, '%s — end 를 못 찾았다 (%s)' % (code, it['end'])
        if out['ev'] < out['sv']:
            return None, '%s — 끝이 시작보다 앞이다' % code
    return out, None


def check(draft, conn):
    """게이트 → [흠]. 빈 목록이면 넣어도 된다."""
    bad, seen = [], set()
    for i, it in enumerate(draft.get('items') or []):
        tag = '#%d %s@%s' % (i + 1, it.get('entity'), it.get('peri'))
        rs, err = _resolve(conn, it)
        if err:
            bad.append('%s — %s' % (tag, err))
            continue
        key = (rs['eid'], rs['pid'])
        if key in seen:
            bad.append('%s — 초안 안에 같은 짝이 두 번' % tag)
            continue
        seen.add(key)
        old = _old_link(conn, rs['eid'], rs['pid'])
        if not old and not _migrated(conn, rs, it):
            bad.append('%s — 단락연결이 없다(이미 이관됐거나 짝이 틀렸다)' % tag)
            continue
        if rs['mode'] == 'drop':
            if len(str(it.get('why') or '').strip()) < 10:
                bad.append('%s — drop 에는 `why` 를 적는다' % tag)
            continue
        # 설명문 문체
        for lg, en in (('desc_KO', False), ('desc_EN', True)):
            for b in _style(it.get(lg), en):
                bad.append('%s — %s: %s' % (tag, lg, b))
        if rs['mode'] == 'lex':
            r = conn.execute(
                "SELECT sys_link_id FROM sys_link_asset"
                " WHERE link_type='ENTI_VERS' AND clicked_id=? AND rel_code="
                "'LEXICAL' AND target_id=? AND COALESCE(record_status,'LIVE')"
                "='LIVE'", (rs['eid'], rs['sv'])).fetchone()
            if not r:
                bad.append('%s — 그 절에 이 용어의 낱말연결이 없다.'
                           ' `verse` 로 쓸 자리다' % tag)
            continue
        # them — 구간 검증
        sv, ev = rs['sv'], rs['ev'] or rs['sv']
        b2 = conn.execute("SELECT bcode FROM bible_index WHERE verse_id=?",
                          (ev,)).fetchone()[0]
        if b2 != rs['bcode']:
            bad.append('%s — 구간이 책을 넘는다' % tag)
            continue
        if ev < rs['psv'] or sv > rs['pev']:
            bad.append('%s — 구간이 옛 단락과 전혀 안 겹친다.'
                       ' 짝을 다시 본다' % tag)
        # 낱말연결과 겹치면 같은 절이 두 번 뜬다 → lex 로 보낸다
        n = conn.execute(
            "SELECT COUNT(*) FROM sys_link_asset WHERE link_type='ENTI_VERS'"
            " AND clicked_id=? AND rel_code='LEXICAL'"
            " AND target_id BETWEEN ? AND ?"
            " AND COALESCE(record_status,'LIVE')='LIVE'",
            (rs['eid'], sv, ev)).fetchone()[0]
        if n:
            bad.append('%s — 구간 안에 낱말연결 %d개.'
                       ' THEMATIC 이면 같은 절이 두 번 뜬다 — `lex` 로'
                       % (tag, n))
        # 이미 다른 THEMATIC 이 덮는 구간인가 (이관분 제외)
        r = conn.execute(
            "SELECT sys_link_id FROM sys_link_asset WHERE link_type="
            "'ENTI_VERS' AND clicked_id=? AND rel_code='THEMATIC'"
            " AND COALESCE(record_status,'LIVE')='LIVE'"
            " AND NOT (COALESCE(end_id,target_id)<? OR target_id>?)"
            " AND NOT (target_id=? AND COALESCE(end_id,-1)=?)",
            (rs['eid'], sv, ev, sv,
             rs['ev'] if rs['ev'] else -1)).fetchone()
        if r:
            bad.append('%s — 그 용어의 다른 의미연결이 이미 그 구간을'
                       ' 덮는다 (link %s)' % (tag, r[0]))
    return bad


def _migrated(conn, rs, it):
    """이미 이관됐나 — 멱등의 눈."""
    if rs['mode'] == 'them':
        return conn.execute(
            "SELECT 1 FROM sys_link_asset WHERE link_type='ENTI_VERS'"
            " AND clicked_id=? AND rel_code='THEMATIC' AND target_id=?"
            " AND COALESCE(end_id,-1)=? AND COALESCE(record_status,'LIVE')"
            "='LIVE'", (rs['eid'], rs['sv'],
                        rs['ev'] if rs['ev'] else -1)).fetchone() is not None
    if rs['mode'] == 'lex':
        return conn.execute(
            "SELECT 1 FROM sys_link_asset l JOIN sys_text_asset t"
            " ON t.text_type=? AND t.clicked_id=l.sys_link_id"
            " WHERE l.link_type='ENTI_VERS' AND l.clicked_id=?"
            " AND l.rel_code='LEXICAL' AND l.target_id=?",
            (DESC_NEW, rs['eid'], rs['sv'])).fetchone() is not None
    return _old_link(conn, rs['eid'], rs['pid']) is None


def _backup_old(conn, lid):
    _ensure_backup(conn)
    if conn.execute("SELECT 1 FROM %s WHERE sys_link_id=?" % BK,
                    (lid,)).fetchone():
        return
    row = conn.execute(
        "SELECT sys_link_id, link_type, clicked_id, target_id, end_id,"
        " rel_code, note, sort_order, record_status FROM sys_link_asset"
        " WHERE sys_link_id=?", (lid,)).fetchone()
    descs = [dict(zip(('lang_code', 'contents', 'title', 'text_variant'), r))
             for r in conn.execute(
                 "SELECT lang_code, contents, title, text_variant"
                 " FROM sys_text_asset WHERE text_type=? AND clicked_id=?",
                 (DESC_OLD, lid))]
    conn.execute("INSERT INTO %s VALUES(?,?,?,?,?,?,?,?,?,?)" % BK,
                 tuple(row) + (json.dumps(descs, ensure_ascii=False),))


def _drop_old(conn, lid):
    conn.execute("DELETE FROM sys_text_asset WHERE text_type=?"
                 " AND clicked_id=?", (DESC_OLD, lid))
    conn.execute("DELETE FROM sys_link_asset WHERE sys_link_id=?", (lid,))


def _put_desc(conn, lid, lang, text):
    n = conn.execute(
        "UPDATE sys_text_asset SET contents=?, record_status='LIVE'"
        " WHERE text_type=? AND clicked_id=? AND UPPER(lang_code)=?",
        (text, DESC_NEW, lid, lang)).rowcount
    if not n:
        conn.execute(
            "INSERT INTO sys_text_asset(text_type,clicked_id,contents,"
            "lang_code,record_status) VALUES(?,?,?,?,'LIVE')",
            (DESC_NEW, lid, text, lang))


def apply_draft(conn, path):
    draft = json.load(io.open(path, encoding='utf-8'))
    bad = check(draft, conn)
    if bad:
        for b in bad:
            print('  X %s' % b)
        raise SystemExit('게이트 위반 %d — 넣지 않았다' % len(bad))
    n = 0
    for it in draft.get('items') or []:
        rs, _ = _resolve(conn, it)
        old = _old_link(conn, rs['eid'], rs['pid'])
        lab = '%s@%s' % (rs['code'], rs['pc'])
        if not old and _migrated(conn, rs, it):
            print('  = %-40s 이미 이관됨' % lab)
            continue
        _backup_old(conn, old[0])
        if rs['mode'] == 'drop':
            _drop_old(conn, old[0])
            print('  - %-40s 연결 걷음 (%s)' % (lab, it.get('why', '')[:30]))
        elif rs['mode'] == 'lex':
            tgt = conn.execute(
                "SELECT sys_link_id FROM sys_link_asset WHERE link_type="
                "'ENTI_VERS' AND clicked_id=? AND rel_code='LEXICAL'"
                " AND target_id=? AND COALESCE(record_status,'LIVE')='LIVE'",
                (rs['eid'], rs['sv'])).fetchone()[0]
            _put_desc(conn, tgt, 'KO', it['desc_KO'].strip())
            if it.get('desc_EN'):
                _put_desc(conn, tgt, 'EN', it['desc_EN'].strip())
            _drop_old(conn, old[0])
            print('  ~ %-40s 낱말연결에 설명문 (%s)'
                  % (lab, LP.scope_label(conn, rs['sv'], rs['sv'], 'KO')
                     or '한 절'))
        else:
            LP.add(conn, ('ENTITY', rs['eid']),
                   ('VERSE', rs['sv'], rs['ev']), scope='SYS',
                   rel='THEMATIC')
            new = conn.execute(
                "SELECT sys_link_id FROM sys_link_asset WHERE link_type="
                "'ENTI_VERS' AND clicked_id=? AND rel_code='THEMATIC'"
                " AND target_id=? AND COALESCE(end_id,-1)=?",
                (rs['eid'], rs['sv'],
                 rs['ev'] if rs['ev'] else -1)).fetchone()[0]
            _put_desc(conn, new, 'KO', it['desc_KO'].strip())
            if it.get('desc_EN'):
                _put_desc(conn, new, 'EN', it['desc_EN'].strip())
            _drop_old(conn, old[0])
            print('  + %-40s → %s' % (lab, LP.scope_label(
                conn, rs['sv'], rs['ev'] or rs['sv'], 'KO') or '한 절'))
        n += 1
    conn.commit()
    print('이관 %d건 처리' % n)
    return n


def undo_draft(conn, path):
    """백업표에서 원복 — **같은 PK 로** 링크·설명문을 되살리고 새 것을 걷는다."""
    draft = json.load(io.open(path, encoding='utf-8'))
    _ensure_backup(conn)
    n = 0
    for it in draft.get('items') or []:
        rs, err = _resolve(conn, it)
        if err:
            continue
        row = conn.execute(
            "SELECT * FROM %s WHERE clicked_id=? AND target_id=?" % BK,
            (rs['eid'], rs['pid'])).fetchone()
        if not row:
            continue
        # 새로 만든 것 걷기
        if rs['mode'] == 'them':
            r = conn.execute(
                "SELECT sys_link_id FROM sys_link_asset WHERE link_type="
                "'ENTI_VERS' AND clicked_id=? AND rel_code='THEMATIC'"
                " AND target_id=? AND COALESCE(end_id,-1)=?",
                (rs['eid'], rs['sv'],
                 rs['ev'] if rs['ev'] else -1)).fetchone()
            if r:
                conn.execute("DELETE FROM sys_text_asset WHERE text_type=?"
                             " AND clicked_id=?", (DESC_NEW, r[0]))
                conn.execute("DELETE FROM sys_link_asset WHERE sys_link_id=?",
                             (r[0],))
        elif rs['mode'] == 'lex':
            r = conn.execute(
                "SELECT sys_link_id FROM sys_link_asset WHERE link_type="
                "'ENTI_VERS' AND clicked_id=? AND rel_code='LEXICAL'"
                " AND target_id=?", (rs['eid'], rs['sv'])).fetchone()
            if r:
                conn.execute("DELETE FROM sys_text_asset WHERE text_type=?"
                             " AND clicked_id=?", (DESC_NEW, r[0]))
        # 옛 링크 원복 (같은 PK)
        if not conn.execute("SELECT 1 FROM sys_link_asset WHERE sys_link_id=?",
                            (row[0],)).fetchone():
            conn.execute(
                "INSERT INTO sys_link_asset(sys_link_id,link_type,clicked_id,"
                "target_id,end_id,rel_code,note,sort_order,record_status)"
                " VALUES(?,?,?,?,?,?,?,?,?)", tuple(row[:9]))
        for d in json.loads(row[9] or '[]'):
            if not conn.execute(
                    "SELECT 1 FROM sys_text_asset WHERE text_type=?"
                    " AND clicked_id=? AND UPPER(lang_code)=?",
                    (DESC_OLD, row[0], (d['lang_code'] or '').upper())
                    ).fetchone():
                conn.execute(
                    "INSERT INTO sys_text_asset(text_type,clicked_id,title,"
                    "contents,lang_code,text_variant,record_status)"
                    " VALUES(?,?,?,?,?,?,'LIVE')",
                    (DESC_OLD, row[0], d.get('title'), d.get('contents'),
                     d.get('lang_code'), d.get('text_variant')))
        conn.execute("DELETE FROM %s WHERE sys_link_id=?" % BK, (row[0],))
        n += 1
    conn.commit()
    print('원복 %d건' % n)
    return n


def status(conn):
    for et, tot, wd in conn.execute(
            "SELECT em.entity_type, COUNT(*), SUM(CASE WHEN EXISTS("
            "SELECT 1 FROM sys_text_asset t WHERE t.text_type=? AND"
            " t.clicked_id=l.sys_link_id) THEN 1 ELSE 0 END)"
            " FROM sys_link_asset l JOIN sys_entity_master em"
            " ON em.entity_id=l.clicked_id WHERE l.link_type='ENTI_PERI'"
            " AND COALESCE(l.record_status,'LIVE')='LIVE'"
            " GROUP BY 1 ORDER BY 2 DESC", (DESC_OLD,)):
        print('  %-10s 단락연결 %4d (설명문 %s)' % (et, tot, wd))
    print('  구간 의미연결(THEMATIC):',
          conn.execute("SELECT COUNT(*) FROM sys_link_asset WHERE link_type="
                       "'ENTI_VERS' AND rel_code='THEMATIC'").fetchone()[0])


def _selftest():
    ok = [0, 0]

    def chk(name, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('PASS' if cond else 'FAIL', name, got))

    conn = appdb.connect('bible_master.db')
    # ⚠ 데이터 상태를 전제하지 않는다 — 시험용 단락연결을 **스스로 만든다.**
    eid = conn.execute("SELECT entity_id FROM sys_entity_master WHERE"
                       " entity_type='DOCTRINE' AND COALESCE(record_status,"
                       "'LIVE')='LIVE' LIMIT 1").fetchone()[0]
    code = conn.execute("SELECT entity_code FROM sys_entity_master WHERE"
                        " entity_id=?", (eid,)).fetchone()[0]
    # 이 용어와 아직 안 이어진 단락 하나.
    # ⚠ **그 용어의 의미연결이 이미 덮는 절은 피한다** (2026-09-01 — 실제
    #   이관을 시작하자 첫 단락이 덮여 selftest 가 깨졌다. 데이터가 찰수록
    #   깨지는 검사는 §0-5 의 그 함정이다).
    pid, pc, psv, pev = conn.execute(
        "SELECT pericope_id, peri_code, start_vid, end_vid FROM"
        " sys_pericope_asset pa WHERE peri_type='BODY' AND NOT EXISTS("
        "SELECT 1 FROM sys_link_asset l WHERE l.link_type='ENTI_PERI'"
        " AND l.clicked_id=? AND l.target_id=pa.pericope_id)"
        " AND NOT EXISTS(SELECT 1 FROM sys_link_asset v WHERE"
        " v.link_type='ENTI_VERS' AND v.clicked_id=?"
        " AND pa.start_vid BETWEEN v.target_id"
        " AND COALESCE(v.end_id, v.target_id))"
        " ORDER BY pericope_id LIMIT 1", (eid, eid)).fetchone()
    b, ch, vs = conn.execute("SELECT bcode, chapter, verse FROM bible_index"
                             " WHERE verse_id=?", (psv,)).fetchone()
    ref = '%d:%d' % (ch, vs)
    n0 = conn.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
    t0 = conn.execute("SELECT COUNT(*) FROM sys_text_asset").fetchone()[0]
    KO = '시험 글입니다. 길이를 채우려고 마흔 자를 넘겨 적어 둡니다. 근거는 여기에 적습니다.'
    EN = 'This is a self-test description long enough to pass the gate check.'
    try:
        conn.execute("INSERT INTO sys_link_asset(link_type,clicked_id,"
                     "target_id,rel_code,record_status)"
                     " VALUES('ENTI_PERI',?,?,'ILLUSTRATION','LIVE')",
                     (eid, pid))
        conn.execute("INSERT INTO sys_text_asset(text_type,clicked_id,"
                     "contents,lang_code,record_status)"
                     " VALUES(?,?,'옛 색인체 — 시험','KO','LIVE')",
                     (DESC_OLD,
                      conn.execute("SELECT sys_link_id FROM sys_link_asset"
                                   " WHERE link_type='ENTI_PERI' AND"
                                   " clicked_id=? AND target_id=?",
                                   (eid, pid)).fetchone()[0]))
        conn.commit()
        good = {'items': [{'entity': code, 'peri': pc, 'verse': ref,
                           'desc_KO': KO, 'desc_EN': EN}]}
        chk('★ 온전한 초안 통과', check(good, conn) == [], check(good, conn))

        def one(**kw):
            d = json.loads(json.dumps(good))
            d['items'][0].update(kw)
            return d
        chk('  색인체(—)를 잡는다', check(one(desc_KO=KO[:20] + ' — 색인. ' + KO), conn))
        chk('  짧은 글을 잡는다', check(one(desc_KO='짧다.'), conn))
        chk('  합니다체 아닌 끝을 잡는다',
            check(one(desc_KO=KO[:-14] + '근거는 여기 있음'), conn))
        chk('  교단 귀속어를 잡는다', check(one(desc_KO=KO + ' 개혁주의입니다.'), conn))
        chk('  개행을 잡는다', check(one(desc_KO=KO + chr(10) + '둘째 줄입니다.'), conn))
        chk('  없는 용어를 잡는다', check(one(entity='D_NO_SUCH'), conn))
        chk('  없는 단락을 잡는다', check(one(peri='XXX_00'), conn))
        chk('  안 겹치는 구간을 잡는다',
            any('겹치' in x for x in check(one(verse='1:1' if b != 1 else '50:1'),
                                        conn)) or b == 1)
        chk('  drop 에 why 없으면 잡는다', check(one(drop=True, why=''), conn))
        # 이관 왕복
        import io as _io
        p = '_term_prep/_selftest_p2v.json'
        _io.open(p, 'w', encoding='utf-8').write(
            json.dumps(good, ensure_ascii=False))
        apply_draft(conn, p)
        chk('★ 이관 — 단락연결이 걷혔다',
            _old_link(conn, eid, pid) is None)
        nl = conn.execute(
            "SELECT sys_link_id, end_id FROM sys_link_asset WHERE link_type="
            "'ENTI_VERS' AND clicked_id=? AND rel_code='THEMATIC'"
            " AND target_id=?", (eid, psv)).fetchone()
        chk('★ 구간 의미연결이 생겼다', nl is not None)
        chk('★ 설명문 KO·EN 이 실렸다',
            conn.execute("SELECT COUNT(*) FROM sys_text_asset WHERE"
                         " text_type=? AND clicked_id=?",
                         (DESC_NEW, nl[0])).fetchone()[0] == 2)
        apply_draft(conn, p)
        chk('★ 멱등 — 두 번 돌려도 그대로',
            conn.execute("SELECT COUNT(*) FROM sys_link_asset WHERE"
                         " link_type='ENTI_VERS' AND clicked_id=? AND"
                         " target_id=?", (eid, psv)).fetchone()[0] == 1)
        undo_draft(conn, p)
        chk('★ 원복 — 단락연결이 돌아왔다',
            _old_link(conn, eid, pid) is not None)
        os.remove(p)
    finally:
        # 시험용 행 걷기 — **시험이 만든 것만** 지목한다
        r = conn.execute("SELECT sys_link_id FROM sys_link_asset WHERE"
                         " link_type='ENTI_PERI' AND clicked_id=? AND"
                         " target_id=?", (eid, pid)).fetchone()
        if r:
            conn.execute("DELETE FROM sys_text_asset WHERE text_type=?"
                         " AND clicked_id=?", (DESC_OLD, r[0]))
            conn.execute("DELETE FROM sys_link_asset WHERE sys_link_id=?",
                         (r[0],))
        conn.execute("DELETE FROM sys_link_asset WHERE link_type='ENTI_VERS'"
                     " AND clicked_id=? AND rel_code='THEMATIC' AND"
                     " target_id=? AND NOT EXISTS(SELECT 1 FROM"
                     " sys_text_asset t WHERE t.text_type=? AND"
                     " t.clicked_id=sys_link_asset.sys_link_id)",
                     (eid, psv, DESC_NEW))
        conn.execute("DELETE FROM %s WHERE clicked_id=? AND target_id=?"
                     % BK, (eid, pid))
        conn.commit()
    n1 = conn.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
    t1 = conn.execute("SELECT COUNT(*) FROM sys_text_asset").fetchone()[0]
    chk('★ 잔재 0 (링크)', n1 == n0, '%d/%d' % (n0, n1))
    chk('★ 잔재 0 (글)', t1 == t0, '%d/%d' % (t0, t1))
    print('%s  %d/%d' % ('PASS' if ok[0] == ok[1] else 'FAIL', ok[0], ok[1]))
    if ok[0] != ok[1]:
        raise SystemExit(1)


def main():
    a = sys.argv[1:]
    conn = appdb.connect('bible_master.db')
    if '--selftest' in a:
        return _selftest()
    if '--status' in a:
        return status(conn)
    for flag, fn in (('--check', None), ('--apply', apply_draft),
                     ('--undo', undo_draft)):
        if flag in a:
            p = a[a.index(flag) + 1]
            if fn is None:
                d = json.load(io.open(p, encoding='utf-8'))
                bad = check(d, conn)
                print('초안 %d건 · 게이트 위반 %d'
                      % (len(d.get('items') or []), len(bad)))
                for b in bad:
                    print('  X %s' % b)
                return
            return fn(conn, p)
    print(__doc__)


if __name__ == '__main__':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    main()
