# -*- coding: utf-8 -*-
"""db_term_promote.py — 낱말을 주요용어로 **승격/원복** (영구 · 2026-09-15 항목 ②).

사용자 지시(`1.txt` 3번 (6)) — 「Lexicon 으로 관리하던 단어에 대해서, 엔티티
라벨로 승격하면 접근경로가 자동으로 바뀌어야 한다. 따라서, 관리자 화면에서
승격 조치를 해야 경로가 자동으로 바뀔 수 있도록 해야 한다. 즉, 엔티티 승격의
의미는 접근경로를 Lexicon 버튼에서 엔티티 라벨로 바꾼다는 의미를 갖는다.」

★★★ **승격의 잣대 = 사람 용어의 앵커**(`sys_entity_lemma` 가 가리키는 엔티티가
  기계 낱말이 아닌 것). 실측(2026-09-15) 앵커 스트롱 11,068 중 사람 용어의 것은
  **227**뿐이고 나머지 10,892 는 기계 등록 낱말(`W_` · `json_detail.subtype=LEX` ·
  `db_word_register`)이다. 화면 세 자리(P1 엔티티 bar · 원어 목록의 「용어」 칸 ·
  P4 탭 잠금)가 이 잣대를 읽으므로 **여기서 승격하면 경로가 저절로 바뀐다.**

승격이 하는 일(한 트랜잭션):
  ① 기계 낱말(W_)이 있으면 **그 행을 올린다**(중복을 안 만든다) — 코드 `W_H4723`
     → `T_H4723`, `subtype` 표식 걷기, importance 1 → 5. 없으면 새로 만든다.
     ⚠ 코드를 바꾸는 까닭 — 여러 곳이 `entity_code` 앞 두 글자 `W_` 로 기계
       낱말을 거른다(`db_alias_head`·`db_worship_topic`). 코드가 그대로면 승격해도
       거기서 계속 빠진다.
  ② 이름 — **한국어는 사람이 적는다**(기계로 짓지 않는다 · 254차 ①). 영어는
     기계 낱말의 것을 살리고 없으면 「음역 (짧은 뜻)」.
  ③ 앵커 — 없으면 1행. 스트롱 번호는 낱말 마스터가 정본이라 복사하는 값이 없다.
  ④ 절 연결(LEXICAL) — `db_term_load.relink` 로 그 용어만. 재료는 **배포 DB 의
     `sys_verse_lemma` 와 로컬 검증 DB 의 합집합**(`strong_verses(strong, conn)`).
  ⚠ **한 스트롱이 두 사람 용어에 걸리지 않는다** — 이미 어느 용어의 앵커면 거부.

원복이 하는 일: 코드 `T_<스트롱>` → `W_<스트롱>`(그 꼴일 때만) · subtype LEX ·
  importance 1 · **LEXICAL 연결만 걷는다**(기계로 다시 만들 수 있다). 이름·설명·
  THEMATIC·연구자료 연결은 그대로(사용자 「지우지 않는다」).

사용:
  python db_term_promote.py --selftest          (의무 · 메모리 DB)
  python db_term_promote.py --list [검색어]     승격 후보(절 수 순)
  python db_term_promote.py --promote H4723 --ko 물웅덩이
  python db_term_promote.py --demote T_H4723
"""
import io
import json
import re
import sys

import appdb

NL = chr(10)


def _lex_flag(jd):
    try:
        return (json.loads(jd or '{}') or {}).get('subtype') == 'LEX'
    except Exception:
        return '"subtype": "LEX"' in (jd or '')


def state_of(conn, strong):
    """그 스트롱이 어디에 서 있나 → dict(kind, entity_id, code) 또는 None.
    kind = 'TERM'(사람 용어의 앵커) | 'W'(기계 낱말) | None(엔티티 없음)."""
    st = (strong or '').strip().upper()
    rows = conn.execute(
        "SELECT m.entity_id, m.entity_code, m.json_detail FROM sys_entity_lemma l"
        " JOIN sys_entity_master m ON m.entity_id=l.entity_id"
        " WHERE l.strong=? AND COALESCE(l.record_status,'LIVE')='LIVE'"
        "   AND m.record_status='LIVE' ORDER BY l.lemma_id", (st,)).fetchall()
    term = next(((e, c) for e, c, jd in rows if not _lex_flag(jd)), None)
    if term:
        return {'kind': 'TERM', 'entity_id': term[0], 'code': term[1]}
    w = next(((e, c) for e, c, jd in rows if _lex_flag(jd)), None)
    if w:
        return {'kind': 'W', 'entity_id': w[0], 'code': w[1]}
    return None


def candidates(conn, q='', limit=300, only_unpromoted=True,
               only_promoted=False):
    """승격 후보 — 낱말 마스터(LIVE · 절 연결 있음)에서 절 수 순.
    → [(strong, form, translit, gloss, n_verse, kind, entity_id, code, ko)].

    `q` 는 스트롱·음역·뜻·원어 글자 **그리고 한국어 이름**에 부분 일치.
    `only_promoted` — **이미 승격된 것만**.

    ★★★ 2026-09-22 (1.txt 9-5) — 사용자 물음 「승격하고 나면 **목록표시에서
      사라지는가**? 그렇다면 **원복 버튼을 누를 일이 없는 것 아닌가**?」 맞다.
      그전에는 `only_unpromoted` 하나뿐이라 **원복할 것을 화면에서 고를 길이
      없었다**. 그리고 목록에 **한국어 이름 칸이 아예 없어** 한국어로 찾을
      수도 없었다.
    ⚠⚠ **`state_of` 를 줄마다 부르지 않는다** — 낱말이 14,000개가 넘어
      그만큼 조회가 는다(옛 판은 그랬고, 한국어 거르기를 얹으면 그대로
      멈춘다). **한 조회로** 앵커와 이름까지 가져온다.
    """
    q = (q or '').strip()
    ql = q.lower()
    like = '%' + q + '%'
    # ⚠ 한 스트롱에 엔티티가 여럿일 수 있다(기계 낱말 + 사람 용어) —
    #   `state_of` 와 **같은 규칙**으로 사람 용어를 먼저 친다.
    anc = {}
    for st, eid, code, jd, ko in conn.execute(
            "SELECT l.strong, m.entity_id, m.entity_code, m.json_detail,"
            "       (SELECT t.contents FROM sys_text_asset t"
            "         WHERE t.clicked_id=m.entity_id"
            "           AND t.text_type='ENTITY_NAME'"
            "           AND UPPER(t.lang_code)='KO'"
            "           AND COALESCE(t.record_status,'LIVE')='LIVE' LIMIT 1)"
            "  FROM sys_entity_lemma l"
            "  JOIN sys_entity_master m ON m.entity_id=l.entity_id"
            " WHERE COALESCE(l.record_status,'LIVE')='LIVE'"
            "   AND m.record_status='LIVE'"
            " ORDER BY l.lemma_id"):
        cur = anc.get(st)
        kind = 'W' if _lex_flag(jd) else 'TERM'
        if cur is None or (cur[0] == 'W' and kind == 'TERM'):
            anc[st] = (kind, eid, code, ko or '')

    rows = conn.execute(
        "SELECT strong, COALESCE(form,''), COALESCE(translit,''),"
        "       COALESCE(gloss,''), COALESCE(n_verse,0) FROM sys_lemma_master"
        " WHERE COALESCE(record_status,'LIVE')='LIVE' AND COALESCE(n_verse,0)>0"
        " ORDER BY n_verse DESC, strong").fetchall()
    out = []
    for st, form, tr, gl, n in rows:
        kind, eid, code, ko = anc.get(st, (None, None, None, ''))
        if only_promoted:
            if kind != 'TERM':
                continue
        elif only_unpromoted and kind == 'TERM':
            continue
        if q and ql not in ' '.join((st, tr, gl, form, ko)).lower():
            continue
        out.append((st, form, tr, gl, n, kind, eid, code, ko))
        if len(out) >= limit:
            break
    return out


def promote(conn, strong, name_ko, name_en=None, importance=5, relink=True):
    """낱말 → 사람 용어. 되돌려 주는 것 = entity_id. 거부는 ValueError."""
    st = (strong or '').strip().upper()
    if not st or st[0] not in 'HG' or not st[1:].isdigit():
        raise ValueError('스트롱 번호가 아니다: %r' % (strong,))
    if not (name_ko or '').strip():
        raise ValueError('한국어 이름을 적어야 한다 — 기계로 짓지 않는다')
    lm = conn.execute(
        "SELECT lang_code, COALESCE(translit,''), COALESCE(gloss,'')"
        "  FROM sys_lemma_master WHERE strong=? AND COALESCE(record_status,'LIVE')='LIVE'",
        (st,)).fetchone()
    if not lm:
        raise ValueError('낱말 마스터에 없는 번호다: %s' % st)
    lang, tr, gl = lm
    s = state_of(conn, st)
    if s and s['kind'] == 'TERM':
        raise ValueError('이미 용어 %s 의 앵커다 — 한 스트롱은 한 용어에만' % s['code'])
    new_code = 'T_' + st
    cur = conn.cursor()
    # ⚠ 관리자 앱이 함께 돌며 수집 중이면 잠금이 걸린다(§219차 · 실측 `database is
    #   locked`) — 기다렸다가 **쓰기 잠금을 먼저** 잡는다(BEGIN IMMEDIATE).
    try:
        conn.execute('PRAGMA busy_timeout=30000')
    except Exception:
        pass
    if not conn.in_transaction:      # 부르는 쪽이 이미 열었을 수 있다
        cur.execute('BEGIN IMMEDIATE')
    try:
        if s and s['kind'] == 'W':
            eid = s['entity_id']
            jd_raw = cur.execute("SELECT json_detail FROM sys_entity_master"
                                 " WHERE entity_id=?", (eid,)).fetchone()[0]
            try:
                jd = json.loads(jd_raw or '{}') or {}
            except Exception:
                jd = {}
            jd.pop('subtype', None)
            jd['promoted_from'] = s['code']          # 원복이 이것을 본다
            if cur.execute("SELECT 1 FROM sys_entity_master WHERE entity_code=?"
                           " AND entity_id<>?", (new_code, eid)).fetchone():
                new_code = s['code']                  # 코드 충돌이면 그대로 둔다
            cur.execute("UPDATE sys_entity_master SET entity_code=?, importance=?,"
                        " json_detail=?, record_status='LIVE' WHERE entity_id=?",
                        (new_code, int(importance), json.dumps(jd, ensure_ascii=False), eid))
        else:
            if cur.execute("SELECT 1 FROM sys_entity_master WHERE entity_code=?",
                           (new_code,)).fetchone():
                raise ValueError('코드 %s 가 이미 있다' % new_code)
            cur.execute("INSERT INTO sys_entity_master(entity_code,entity_type,importance,"
                        "json_detail,record_status) VALUES(?,'TERM',?,?,'LIVE')",
                        (new_code, int(importance),
                         json.dumps({'promoted_from': None}, ensure_ascii=False)))
            eid = cur.lastrowid
        # 이름 — KO 는 사람 것 · EN 은 있으면 살린다
        _upsert(cur, eid, 'ENTITY_NAME', 'KO', name_ko.strip())
        has_en = cur.execute(
            "SELECT 1 FROM sys_text_asset WHERE clicked_id=? AND text_type='ENTITY_NAME'"
            " AND lang_code='EN' AND COALESCE(record_status,'LIVE')='LIVE'"
            " AND COALESCE(contents,'')<>''", (eid,)).fetchone()
        if name_en and name_en.strip():
            _upsert(cur, eid, 'ENTITY_NAME', 'EN', name_en.strip())
        elif not has_en:
            import db_word_register as _W
            _upsert(cur, eid, 'ENTITY_NAME', 'EN', _W._name_en(tr, gl))
        # 앵커 — 없으면 1행
        if not cur.execute("SELECT 1 FROM sys_entity_lemma WHERE entity_id=? AND strong=?",
                           (eid, st)).fetchone():
            cur.execute("INSERT INTO sys_entity_lemma(entity_id,lang_code,strong,translit,"
                        "gloss,sort_order,record_status) VALUES(?,?,?,?,?,10,'LIVE')",
                        (eid, lang, st, tr, gl[:60]))
        cur.execute("UPDATE sys_entity_lemma SET record_status='LIVE'"
                    " WHERE entity_id=? AND strong=?", (eid, st))
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    if relink:
        import db_term_load as T
        T.relink(conn, [new_code], quiet=True)
    return eid


def demote(conn, entity_id):
    """사람 용어 → 기계 낱말. LEXICAL 연결만 걷는다(다시 만들 수 있다)."""
    r = conn.execute("SELECT entity_code, json_detail FROM sys_entity_master"
                     " WHERE entity_id=? AND record_status='LIVE'", (entity_id,)).fetchone()
    if not r:
        raise ValueError('없는 엔티티: %s' % entity_id)
    code, jd_raw = r
    try:
        jd = json.loads(jd_raw or '{}') or {}
    except Exception:
        jd = {}
    if _lex_flag(jd_raw):
        raise ValueError('%s 는 이미 기계 낱말이다' % code)
    sts = [x[0] for x in conn.execute(
        "SELECT strong FROM sys_entity_lemma WHERE entity_id=?"
        " AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY sort_order", (entity_id,))]
    if not sts:
        raise ValueError('%s 에는 앵커가 없다 — 낱말로 돌릴 것이 없다' % code)
    back = jd.get('promoted_from') or ('W_' + sts[0])
    if len(sts) > 1:
        raise ValueError('%s 는 앵커가 %d개다 — 손으로 만든 용어라 원복 대상이 아니다'
                         % (code, len(sts)))
    cur = conn.cursor()
    # ⚠ 관리자 앱이 함께 돌며 수집 중이면 잠금이 걸린다(§219차 · 실측 `database is
    #   locked`) — 기다렸다가 **쓰기 잠금을 먼저** 잡는다(BEGIN IMMEDIATE).
    try:
        conn.execute('PRAGMA busy_timeout=30000')
    except Exception:
        pass
    if not conn.in_transaction:      # 부르는 쪽이 이미 열었을 수 있다
        cur.execute('BEGIN IMMEDIATE')
    try:
        jd['subtype'] = 'LEX'
        jd.pop('promoted_from', None)
        if cur.execute("SELECT 1 FROM sys_entity_master WHERE entity_code=? AND entity_id<>?",
                       (back, entity_id)).fetchone():
            back = code
        cur.execute("UPDATE sys_entity_master SET entity_code=?, importance=1, json_detail=?"
                    " WHERE entity_id=?", (back, json.dumps(jd, ensure_ascii=False), entity_id))
        import db_term_load as T
        cur.execute("DELETE FROM %s WHERE %s AND %s=? AND rel_code='LEXICAL'"
                    % (T.EV_TABLE, T.EV_WHERE, T.EV_A), (entity_id,))
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    return back


# ══════════════════════════════════════════════════════════════════════════
# ★★★ 317차-5 — **승격 추천**(docs/1.txt 4 「Lexicon → 주요용어」)
#   사용자 「신학자료, 설교, 묵상 등에 자주 등장하는 단어를 네가 판단하여 나에게 추천하고,
#   내가 승인하면, 네가 자동 승격」.
#   ★★★ 잣대 = **우리가 쓴 설명문이 원어를 짚은 횟수**. 전문 설명이 핵심 낱말을
#     「정죄(카타크리마)」 꼴로 짚는다 — 그 한글 음역을 **그 절의 스트롱 낱말** 음역과
#     자음 뼈대로 맞추면 어느 낱말인지 안다. 짚은 횟수가 곧 「자주 등장」이고
#     **괄호 앞 한국어가 곧 이름 후보**다(사람이 쓴 글에서 온 이름).
#   ⚠ 영어 주석의 낱말 빈도로 재 보았으나 **헛것**이었다(실측 — gínomai 가 「god」으로
#     1위). 우리 글이 짚은 것이 더 정확하다.
#   ⚠ 한국어 이름은 **제안**이다 — 사람이 고쳐 승인한다(기계로 짓지 않는다 규칙 그대로).
# ══════════════════════════════════════════════════════════════════════════
#: 품사를 알리는 뜻 풀이 낱말 — 이런 낱말은 용어가 아니다(전치사·접속사·불변화사 …)
FUNC_MARKS = ('particle', 'preposition', 'conjunction', 'adverb', 'pronoun', 'article', 'interjection')
CITE_PAT = re.compile('([\uac00-\ud7a3]{1,8})\\(([\uac00-\ud7a3]{2,12})\\)')
MATCH_MIN = 0.75
_CHO = 'ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ'
_JONG = ['', 'ㄱ', 'ㄲ', 'ㄳ', 'ㄴ', 'ㄵ', 'ㄶ', 'ㄷ', 'ㄹ', 'ㄺ', 'ㄻ', 'ㄼ', 'ㄽ', 'ㄾ', 'ㄿ', 'ㅀ',
         'ㅁ', 'ㅂ', 'ㅄ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ']
_JM = {'ㄱ': 'K', 'ㄲ': 'K', 'ㅋ': 'K', 'ㄴ': 'N', 'ㄷ': 'T', 'ㄸ': 'T', 'ㅌ': 'T', 'ㄹ': 'L', 'ㅁ': 'M',
       'ㅂ': 'P', 'ㅃ': 'P', 'ㅍ': 'P', 'ㅅ': 'S', 'ㅆ': 'S', 'ㅈ': 'S', 'ㅉ': 'S', 'ㅊ': 'S', 'ㅎ': 'H'}


def hangul_skel(s):
    """한글 음역 → 자음 뼈대(「카타크리마」 → KTKLM)."""
    o = ''
    for ch in s or '':
        n = ord(ch) - 0xAC00
        if 0 <= n < 11172:
            o += _JM.get(_CHO[n // 588], '')
            j = _JONG[n % 28]
            if j == 'ㅇ':
                o += 'N'
            elif j:
                o += _JM.get(j[0], '')
    return o


def latin_skel(t):
    """로마자 음역 → 자음 뼈대(「katákrima」 → KTKLM)."""
    import unicodedata as _u
    t = _u.normalize('NFD', (t or '').lower())
    t = re.sub('[^a-z]', '', ''.join(ch for ch in t if not _u.combining(ch)))
    for a, b in (('ph', 'P'), ('th', 'T'), ('kh', 'K'), ('ch', 'K'), ('sh', 'S'), ('ts', 'S'),
                 ('tz', 'S'), ('ps', 'PS'), ('x', 'KS')):
        t = t.replace(a, b)
    m = {'k': 'K', 'g': 'K', 'c': 'K', 'q': 'K', 't': 'T', 'd': 'T', 'p': 'P', 'b': 'P', 'f': 'P',
         'v': 'P', 's': 'S', 'z': 'S', 'm': 'M', 'n': 'N', 'l': 'L', 'r': 'L', 'h': 'H'}
    return ''.join(m.get(ch, ch if ch in 'KTPSMNLH' else '') for ch in t)


def cited_words(conn):
    """우리 설명문이 짚은 원어 — `{strong: (짚은 횟수, Counter(괄호 앞 한국어))}`."""
    import difflib
    from collections import Counter
    tr, func = {}, set()
    for st, t, pos, de in conn.execute(
            "SELECT strong, COALESCE(translit,''), COALESCE(pos,''),"
            " LOWER(COALESCE(def_en,'')||' '||COALESCE(gloss,'')) FROM sys_lemma_master"
            " WHERE wtype='GENERAL'"):
        tr[st] = latin_skel(t)
        if (pos and pos[:1] not in ('n', 'a', 'v')) or any(m_ in de[:80] for m_ in FUNC_MARKS):
            func.add(st)
    vl = {v: (x or '').split() for v, x in conn.execute("SELECT verse_id, strongs FROM sys_verse_lemma")}
    out = {}
    for vid, txt in conn.execute(
            "SELECT clicked_id, contents FROM sys_text_asset WHERE text_type IN ('VERS_DESC','VERS_QUESTION')"
            " AND UPPER(lang_code)='KO' AND record_status='LIVE'"):
        for nm, h in CITE_PAT.findall(txt or ''):
            hs = hangul_skel(h)
            best, bs = None, 0.0
            for st in vl.get(vid, ()):
                if st in func or st not in tr:
                    continue
                r = difflib.SequenceMatcher(None, hs, tr[st]).ratio()
                if r > bs:
                    best, bs = st, r
            if best and bs >= MATCH_MIN:
                n, names = out.get(best, (0, Counter()))
                names[nm] += 1
                out[best] = (n + 1, names)
    return out


def recommend(conn, limit=200, min_cite=3, cited=None):
    """승격 추천 — `[(strong, form, translit, gloss, n_verse, 짚은 횟수, 이름 후보, 다른 이름들)]`.

    이미 사람 용어인 것은 뺀다(`candidates(only_unpromoted)`). 짚은 횟수 순.
    """
    cited = cited if cited is not None else cited_words(conn)
    out = []
    for st, form, tr, gl, n, kind, _eid, _code, ko in candidates(conn, limit=100000):
        c_ = cited.get(st)
        if not c_ or c_[0] < min_cite:
            continue
        names = [x for x, _k in c_[1].most_common(4)]
        out.append((st, form, tr, gl, n, c_[0], ko or (names[0] if names else ''), ' · '.join(names[1:])))
    out.sort(key=lambda r: (-r[5], -r[4]))
    return out[:limit]


def suggest_names(conn, rows, call=None, model=None):
    """AI 에게 **한국어 이름을 제안**받는다 — `{strong: 이름}`(못 받으면 빈 dict).

    `rows` = `[(strong, translit, gloss, 뜻말)]`. 개역한글이 그 낱말을 가장 흔히 옮긴 말을 묻는다.
    ⚠ 한글만 · 1~10자만 받는다(설명을 덧붙인 답은 버린다). 이름은 **제안**이다 — 사람이 고친다.
    """
    import re as _re
    if not rows:
        return {}
    if call is None:
        import ai_client as AC
        call = AC.call
    lines = ['아래 성경 원어 낱말마다 **개역한글 성경이 가장 흔히 옮긴 한국어 낱말 하나**를 적으세요.',
             '줄마다 「스트롱 · 한국어 이름」 꼴로만 — 설명·괄호·다른 말 없이.', '']
    for st, tr, gl, hw in rows:
        lines.append('%s · %s · %s · %s' % (st, tr, (gl or '')[:60], hw))
    res = call(chr(10).join(lines), model=model, conn=conn)
    if not res.get('ok'):
        return {}
    out = {}
    for raw in (res.get('text') or '').splitlines():
        m = _re.match(r'^\s*([HG]\d{1,5})\s*[·|:,\-]\s*([가-힣 ]{1,10})\s*$', raw.strip())
        if m:
            out[m.group(1)] = m.group(2).strip()
    return out


def promote_many(conn, pairs):
    """`[(strong, 한국어 이름)]` 를 차례로 승격 — `[(strong, entity_id|None, 까닭)]`."""
    out = []
    for st, ko in pairs:
        try:
            out.append((st, promote(conn, st, ko), ''))
        except Exception as e:                            # noqa: BLE001
            out.append((st, None, str(e)))
    return out


def _upsert(cur, eid, ttype, lang, text):
    r = cur.execute("SELECT sys_text_id FROM sys_text_asset WHERE clicked_id=?"
                    " AND text_type=? AND lang_code=?", (eid, ttype, lang)).fetchone()
    if r:
        cur.execute("UPDATE sys_text_asset SET contents=?, record_status='LIVE'"
                    " WHERE sys_text_id=?", (text, r[0]))
    else:
        cur.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,contents,"
                    "record_status) VALUES(?,?,?,?,'LIVE')", (eid, ttype, lang, text))


# ── 자가검증 ──────────────────────────────────────────────────────────────
def _mem():
    import sqlite3
    import db_lex_link as LL
    c = sqlite3.connect(':memory:')
    c.executescript("""
    CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY AUTOINCREMENT,
        entity_code TEXT UNIQUE NOT NULL, entity_type TEXT NOT NULL, importance INTEGER,
        json_detail TEXT, record_status TEXT DEFAULT 'LIVE');
    CREATE TABLE sys_entity_lemma(lemma_id INTEGER PRIMARY KEY AUTOINCREMENT,
        entity_id INTEGER NOT NULL, lang_code TEXT NOT NULL, strong TEXT NOT NULL,
        translit TEXT, gloss TEXT, sort_order INTEGER DEFAULT 0, record_status TEXT DEFAULT 'LIVE');
    CREATE TABLE sys_text_asset(sys_text_id INTEGER PRIMARY KEY AUTOINCREMENT,
        clicked_id INTEGER, target_id INTEGER, text_type TEXT, title TEXT, contents TEXT,
        lang_code TEXT, record_status TEXT, origin_id INTEGER, created_at TEXT, text_variant TEXT);
    CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY AUTOINCREMENT,
        clicked_id INTEGER, target_id INTEGER, link_type TEXT, rel_code TEXT,
        sort_order INTEGER, record_status TEXT, origin_id INTEGER, chain_code TEXT,
        end_id INTEGER, note TEXT, milestone_type TEXT, importance INTEGER, is_key INTEGER,
        source TEXT, confidence TEXT, lemma_id INTEGER, is_directed INTEGER,
        relation_cat TEXT, rank_score REAL);
    CREATE TABLE sys_lemma_master(strong TEXT PRIMARY KEY, lang_code TEXT NOT NULL,
        form TEXT, translit TEXT, pron TEXT, pos TEXT, wtype TEXT NOT NULL, gloss TEXT,
        deriv TEXT, def_en TEXT, kjv_def TEXT, occurrences INTEGER DEFAULT 0,
        record_status TEXT DEFAULT 'LIVE', n_verse INTEGER, verse_ids BLOB);
    CREATE TABLE sys_verse_lemma(verse_id INTEGER PRIMARY KEY, strongs TEXT);
    """)
    c.execute("INSERT INTO sys_lemma_master(strong,lang_code,form,translit,wtype,gloss,n_verse,verse_ids)"
              " VALUES('H4723','HE','מִקְוֶה','miqveh','GENERAL','something waited for',3,?)",
              (LL.pack([10, 20, 30]),))
    c.execute("INSERT INTO sys_lemma_master(strong,lang_code,form,translit,wtype,gloss,n_verse,verse_ids)"
              " VALUES('G907','EL','βαπτίζω','baptizo','GENERAL','to immerse',2,?)",
              (LL.pack([100, 200]),))
    c.execute("INSERT INTO sys_lemma_master(strong,lang_code,form,translit,wtype,gloss,n_verse)"
              " VALUES('H99','HE','x','x','GENERAL','x',0)")
    for v, s in ((10, 'H4723 H430'), (20, 'H4723'), (30, 'H4723'), (100, 'G907'), (200, 'G907')):
        c.execute("INSERT INTO sys_verse_lemma VALUES(?,?)", (v, s))
    # 기계 낱말 W_H4723 · 사람 용어 T_BAPT(G907)
    c.execute("INSERT INTO sys_entity_master(entity_code,entity_type,importance,json_detail)"
              " VALUES('W_H4723','TERM',1,'{\"subtype\": \"LEX\"}')")
    c.execute("INSERT INTO sys_entity_lemma(entity_id,lang_code,strong,translit,gloss,sort_order)"
              " VALUES(1,'HE','H4723','miqveh','something waited for',1)")
    c.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,contents,record_status)"
              " VALUES(1,'ENTITY_NAME','EN','miqveh (something waited for)','LIVE')")
    c.execute("INSERT INTO sys_entity_master(entity_code,entity_type,importance,json_detail)"
              " VALUES('T_BAPT','TERM',5,'{}')")
    c.execute("INSERT INTO sys_entity_lemma(entity_id,lang_code,strong,translit,gloss,sort_order)"
              " VALUES(2,'EL','G907','밥티조','침례',1)")
    c.commit()
    return c


def selftest():
    import db_term_load as T
    ok = fail = 0

    def t(name, cond, got=None):
        nonlocal ok, fail
        if cond:
            ok += 1
            print('  OK   ' + name)
        else:
            fail += 1
            print('  FAIL %s %r' % (name, got))

    def raises(fn):
        try:
            fn()
            return False
        except ValueError:
            return True

    c = _mem()
    # ⚠ 이 PC 에 검증 DB 가 있으면 합집합에 실제 절이 섞인다 — 시험 동안 치운다
    _vdb = dict(T.VERIFY_DB)
    T.VERIFY_DB = {'HE': '__none_he__.db', 'EL': '__none_el__.db'}
    t('상태 — 기계 낱말은 W', state_of(c, 'H4723')['kind'] == 'W')
    t('상태 — 사람 용어의 앵커는 TERM', state_of(c, 'G907')['kind'] == 'TERM')
    t('상태 — 엔티티 없으면 None', state_of(c, 'H99') is None)
    cs = candidates(c)
    t('후보 — 절 연결 있는 낱말만 · 사람 용어 앵커는 뺀다 · 절 수 순',
      [x[0] for x in cs] == ['H4723'] and cs[0][5] == 'W', cs)
    t('후보 — 검색어(음역)로 거른다', [x[0] for x in candidates(c, 'miq')] == ['H4723'])
    t('★ 한국어 이름 없이는 승격 못 한다', raises(lambda: promote(c, 'H4723', '')))
    t('★ 이미 사람 용어의 앵커면 거부', raises(lambda: promote(c, 'G907', '침례')))
    t('낱말 마스터에 없는 번호는 거부', raises(lambda: promote(c, 'H12345', 'x')))
    # 검증 DB 없는 메모리 — strong_verses 는 배포 표(sys_verse_lemma)를 쓴다
    eid = promote(c, 'H4723', '물웅덩이')
    row = c.execute("SELECT entity_code, importance, json_detail FROM sys_entity_master"
                    " WHERE entity_id=?", (eid,)).fetchone()
    t('★★★ 기계 낱말을 올린다 — 같은 행(중복 없음) · 코드 W_→T_ · 표식 걷음',
      eid == 1 and row[0] == 'T_H4723' and row[1] == 5 and not _lex_flag(row[2])
      and c.execute("SELECT COUNT(*) FROM sys_entity_master").fetchone()[0] == 2, row)
    t('  상태가 TERM 으로 바뀐다', state_of(c, 'H4723')['kind'] == 'TERM')
    names = dict(c.execute("SELECT lang_code, contents FROM sys_text_asset WHERE clicked_id=?"
                           " AND text_type='ENTITY_NAME'", (eid,)).fetchall())
    t('  이름 — KO 는 사람 것 · EN 은 기계 낱말 것을 살린다',
      names.get('KO') == '물웅덩이' and names.get('EN', '').startswith('miqveh'), names)
    links = sorted(r[0] for r in c.execute(
        "SELECT target_id FROM sys_link_asset WHERE link_type='ENTI_VERS' AND clicked_id=?"
        " AND rel_code='LEXICAL'", (eid,)))
    t('★ 절 연결이 배포 표(sys_verse_lemma)에서 만들어진다 — 3절', links == [10, 20, 30], links)
    t('  앵커는 그대로 1행', c.execute("SELECT COUNT(*) FROM sys_entity_lemma WHERE entity_id=?",
                                   (eid,)).fetchone()[0] == 1)
    t('  두 번 승격하면 거부(이미 용어)', raises(lambda: promote(c, 'H4723', '물웅덩이')))
    # 원복
    back = demote(c, eid)
    row = c.execute("SELECT entity_code, importance, json_detail FROM sys_entity_master"
                    " WHERE entity_id=?", (eid,)).fetchone()
    t('★★ 원복 — 코드 W_ 로 · 표식 · importance 1', back == 'W_H4723' and row[0] == 'W_H4723'
      and row[1] == 1 and _lex_flag(row[2]), row)
    t('  LEXICAL 만 걷고 이름은 남긴다',
      c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE clicked_id=?", (eid,)).fetchone()[0] == 0
      and c.execute("SELECT COUNT(*) FROM sys_text_asset WHERE clicked_id=? AND text_type='ENTITY_NAME'",
                    (eid,)).fetchone()[0] == 2)
    t('  상태가 W 로 돌아온다', state_of(c, 'H4723')['kind'] == 'W')
    t('  기계 낱말을 또 원복하면 거부', raises(lambda: demote(c, eid)))
    t('  손으로 만든 용어(앵커 둘)는 원복 거부',
      (c.execute("INSERT INTO sys_entity_lemma(entity_id,lang_code,strong,sort_order) VALUES(2,'HE','H4723',2)"),
       raises(lambda: demote(c, 2)))[1])
    c.execute("DELETE FROM sys_entity_lemma WHERE entity_id=2 AND strong='H4723'")
    # 엔티티가 아예 없는 낱말 — 새로 만든다
    c.execute("INSERT INTO sys_lemma_master(strong,lang_code,form,translit,wtype,gloss,n_verse,verse_ids)"
              " VALUES('H430','HE','אֱלֹהִים','elohim','GENERAL','God',1,?)", (__import__('db_lex_link').pack([10]),))
    eid2 = promote(c, 'H430', '하나님', name_en='God')
    t('엔티티 없는 낱말은 새로 만든다 — T_ 코드 · 앵커 1 · 절 1',
      c.execute("SELECT entity_code FROM sys_entity_master WHERE entity_id=?", (eid2,)).fetchone()[0] == 'T_H430'
      and c.execute("SELECT COUNT(*) FROM sys_entity_lemma WHERE entity_id=?", (eid2,)).fetchone()[0] == 1
      and c.execute("SELECT COUNT(*) FROM sys_link_asset WHERE clicked_id=? AND rel_code='LEXICAL'",
                    (eid2,)).fetchone()[0] == 1)
    # 합집합 — 검증 DB 가 없어도 배포 표로 · 둘 다 없으면 None
    t('strong_verses — 검증 DB 없고 배포 표만 있어도 절이 나온다',
      T.strong_verses('G907', c) == [100, 200], T.strong_verses('G907', c))
    t('strong_verses — 둘 다 없으면 None(0건과 구별)',
      T.strong_verses('G99999', None) is None or T.strong_verses('G99999', c) == [])
    # ★ 317차-5 — 추천 · 이름 제안 · 일괄 승격
    t('뼈대 — 한글 음역과 로마자 음역이 같은 뼈대', hangul_skel('카타크리마') == latin_skel('katákrima') == 'KTKLM',
      (hangul_skel('카타크리마'), latin_skel('katákrima')))
    c.execute("INSERT INTO sys_lemma_master(strong,lang_code,form,translit,wtype,gloss,n_verse)"
              " VALUES('H4671','HE','x','môts','GENERAL','chaff',8)")
    c.execute("UPDATE sys_verse_lemma SET strongs='H4723 H4671' WHERE verse_id=20")
    for _i in range(3):
        c.execute("INSERT INTO sys_text_asset(clicked_id,text_type,lang_code,contents,record_status)"
                  " VALUES(20,'VERS_DESC','KO','바람에 나는 겨(모츠)와 같습니다.','LIVE')")
    rec = recommend(c, min_cite=1)
    t('★ 추천 — 우리 설명문이 짚은 원어 · 괄호 앞 한국어가 이름 후보',
      rec and rec[0][0] == 'H4671' and rec[0][5] == 3 and rec[0][6] == '겨', rec)
    fake = lambda prompt, model=None, conn=None: {'ok': True, 'text': 'H430 · 겨' + chr(10) + 'H1 · 설명이 붙은 긴 답입니다 정말'}
    t('★ 이름 제안 — 한글 짧은 이름만 받는다',
      suggest_names(c, [('H430', 'x', 'chaff', 'chaff')], call=fake) == {'H430': '겨'})
    t('일괄 승격 — 이미 용어면 까닭을 적고 넘어간다',
      [r[2] != '' for r in promote_many(c, [('H430', '겨')])] == [True])
    T.VERIFY_DB = _vdb
    print('db_term_promote selftest %d/%d' % (ok, ok + fail))
    return fail == 0


def main(argv):
    a = argv
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect()
    if '--list' in a:
        i = a.index('--list')
        q = a[i + 1] if i + 1 < len(a) and not a[i + 1].startswith('--') else ''
        # ⚠ `candidates` 는 **아홉 칸**이다(2026-09-22 에 `ko` 가 늘었다) —
        #   여덟으로 풀다 `--list` 가 그 자리에서 터지고 있었다(288차 실측).
        #   ⇒ 칸 수를 못 박지 않는다.
        lim = 60
        if '--limit' in a:
            lim = int(a[a.index('--limit') + 1])
        for row in candidates(conn, q, limit=lim):
            st, form, tr, gl, n, kind, _eid, _code, ko = row[:9]
            print('%-7s %-14s %-16s %5d  %-4s %-10s %s'
                  % (st, form, tr, n, kind or '-', ko or '', (gl or '')[:36]))
    elif '--promote' in a:
        st = a[a.index('--promote') + 1]
        ko = a[a.index('--ko') + 1] if '--ko' in a else ''
        eid = promote(conn, st, ko)
        print('승격 → entity_id %d' % eid)
    elif '--demote' in a:
        code = a[a.index('--demote') + 1]
        r = conn.execute("SELECT entity_id FROM sys_entity_master WHERE entity_code=?",
                         (code,)).fetchone()
        if not r:
            sys.exit('없는 코드: %s' % code)
        print('원복 → %s' % demote(conn, r[0]))
    else:
        print(__doc__)
    conn.close()


if __name__ == '__main__':
    main(sys.argv[1:])
