# -*- coding: utf-8 -*-
"""Journey map 읽기 어댑터 (2026-08-20 신설·영구, §0-5 KEEP).

user_saved_maps 한 행(캔버스 스냅샷)을 **작성툴이 쓰는 모양**으로 풀어 준다:
구절 목록(이동 순서), 연결관계(부모↔자식 + 관점 라벨), 노드 원본.

★ 이 모듈은 **읽기 전용**이다 — 맵 포맷은 여기서도 바꾸지 않는다(2026-08-20
  사용자 확정: 「포맷 불변, 고칠 것은 읽는 쪽」). 쓰는 쪽은 user_main
  (`_write_manual_map` · `_safe_auto_save_workbench`)뿐이다.
★ 값(본문·설명문)은 싣지 않는다 — 참조(id)만. 알맹이는 소비자가 DB 원본에서
  실시간으로 가져온다(Live-Sync 원칙). 값이 굳는 순간은 연구자료 저장 시점뿐.

사용처: 연구자료 작성툴 접근루트 ①(저장맵/현재 캔버스) · 리포트→초안 생성.
`--selftest` 의무.
"""
import json


def parse_struct(full_structure, path_string=''):
    """스냅샷 JSON + 여정 문자열 → 표준 dict. 순수 함수(DB 무접촉).

    반환: {'nodes': {view_id: {node_id,p_id,x,y,rel_label}},
           'journey': [view_id...],
           'verses': [pure_vid...]   ← 여정 순서 먼저, 나머지는 (x,y) 순
           'direct': [pure_vid...]   ← **실제 지나온 경로**(journey)의 구절만
           'links': [(p_node_id, node_id, rel_label)...]}
    깨진 JSON 은 None.

    ★ direct(직계) vs 나머지(방계) — 맵은 「펼쳐만 놓고 들어가지 않은」 노드도
      함께 담는다(2026-08-20 사용자 지시로 구분). 여정이 비어 있으면 판단할
      근거가 없으므로 **전부 직계**로 본다(옛 맵 호환).
    """
    try:
        struct = json.loads(full_structure) if isinstance(full_structure, str) \
            else dict(full_structure or {})
    except Exception:
        return None
    if not isinstance(struct, dict):
        return None

    nodes = {}
    for vid, info in struct.items():
        if not isinstance(info, dict) or not info.get('node_id'):
            continue
        nodes[vid] = {
            'node_id': str(info['node_id']),
            'p_id': info.get('p_id') or None,
            'x': float(info.get('x') or 0), 'y': float(info.get('y') or 0),
            'rel_label': str(info.get('rel_label') or ''),
        }

    journey = [v for v in (path_string or '').split('|') if v]

    def _pure(node_id):
        try:
            kind, num = node_id.split(':', 1)
            return kind, int(str(num).split('@')[0])
        except Exception:
            return None, None

    # 구절 목록 — 여정 순서 먼저(중복 제거), 나머지 BIBLE 노드는 좌표순
    verses, seen, direct = [], set(), []
    def _add_verse(view_id, is_direct=False):
        info = nodes.get(view_id)
        if not info:
            return
        kind, num = _pure(info['node_id'])
        if kind == 'BIBLE' and num and num not in seen:
            seen.add(num)
            verses.append(num)
            if is_direct:
                direct.append(num)
    for v in journey:
        _add_verse(v, True)
    for v, info in sorted(nodes.items(),
                          key=lambda kv: (kv[1]['x'], kv[1]['y'])):
        _add_verse(v)
    if not direct:                 # 여정 기록이 없는 맵 — 전부 직계로 본다
        direct = list(verses)

    # 연결관계 — 스냅샷의 부모 관계 그대로 (관점 라벨 포함)
    links = []
    for vid, info in nodes.items():
        p = info['p_id']
        if p and p in nodes:
            links.append((nodes[p]['node_id'], info['node_id'],
                          info['rel_label']))
    return {'nodes': nodes, 'journey': journey,
            'verses': verses, 'direct': direct, 'links': links}


def _conn(db_path, conn):
    if conn is not None:
        return conn, False
    import appdb
    return appdb.connect(db_path or 'bible_master.db'), True


def list_maps(db_path=None, root_id=None, include_auto=True,
              include_pin=False, conn=None):
    """맵 목록 — [{'root_id','save_type','map_name','updated_at'}] 최신순.

    ⚑핀 스냅샷(PIN_ 접두)은 기본 제외 — 칩이 관리하는 슬롯이다."""
    c, own = _conn(db_path, conn)
    try:
        wc, args = [], []
        if root_id is not None:
            wc.append('root_id=?'); args.append(root_id)
        if not include_auto:
            wc.append("save_type != 'AUTO'")
        if not include_pin:
            wc.append("map_name NOT LIKE 'PIN\\_%' ESCAPE '\\'")
        sql = ("SELECT root_id, save_type, map_name, updated_at FROM user_saved_maps"
               + ((' WHERE ' + ' AND '.join(wc)) if wc else '')
               + ' ORDER BY updated_at DESC')
        return [{'root_id': r[0], 'save_type': r[1],
                 'map_name': r[2], 'updated_at': r[3]}
                for r in c.execute(sql, args)]
    finally:
        if own:
            c.close()


def load_map(db_path=None, root_id=None, map_name=None, conn=None):
    """맵 한 장을 표준 dict 로. map_name 을 안 주면 그 구절의 **AUTO 슬롯**.

    없으면 None. 반환 dict 에 'root_id'/'map_name'/'save_type' 이 더 붙는다."""
    if root_id is None:
        return None
    c, own = _conn(db_path, conn)
    try:
        if map_name:
            row = c.execute(
                "SELECT save_type, map_name, path_string, full_structure "
                "FROM user_saved_maps WHERE root_id=? AND map_name=?",
                (root_id, map_name)).fetchone()
        else:
            row = c.execute(
                "SELECT save_type, map_name, path_string, full_structure "
                "FROM user_saved_maps WHERE root_id=? AND save_type='AUTO' "
                "ORDER BY updated_at DESC LIMIT 1", (root_id,)).fetchone()
        if not row or not row[3]:
            return None
        out = parse_struct(row[3], row[2] or '')
        if out is None:
            return None
        out.update({'root_id': root_id, 'save_type': row[0],
                    'map_name': row[1]})
        return out
    finally:
        if own:
            c.close()


# ── 자가 검증 ────────────────────────────────────────────────────────────

def _selftest():
    import sqlite3
    ok = []

    # 실 저장 포맷 그대로의 표본 (루트 + 구절 자식 2 + NODE 자식 1)
    struct = {
        'BIBLE:1@R':   {'node_id': 'BIBLE:1',  'p_id': None,
                        'x': 300.0, 'y': 0.0,  'rel_label': ''},
        'BIBLE:70@a':  {'node_id': 'BIBLE:70', 'p_id': 'BIBLE:1@R',
                        'x': 650.0, 'y': -100.0,
                        'rel_label': '예표-성취·점진 계시'},
        'BIBLE:99@b':  {'node_id': 'BIBLE:99', 'p_id': 'BIBLE:1@R',
                        'x': 650.0, 'y': 100.0, 'rel_label': '언약 관계'},
        'NODE:5@c':    {'node_id': 'NODE:5',   'p_id': 'BIBLE:70@a',
                        'x': 1000.0, 'y': -100.0, 'rel_label': ''},
    }
    path = 'BIBLE:1@R|BIBLE:99@b'

    out = parse_struct(json.dumps(struct), path)
    ok.append(('파싱', out is not None and len(out['nodes']) == 4))
    # 여정 순서 먼저(1, 99), 남은 구절(70)은 좌표순으로 뒤에. NODE 는 제외
    ok.append(('구절 순서 = 여정 우선', out['verses'] == [1, 99, 70]))
    # 직계 = 여정에 있는 구절만(1, 99). 70 은 펼쳐만 둔 방계
    ok.append(('직계 = 여정 구절', out['direct'] == [1, 99]))
    ok.append(('방계는 direct 밖', 70 in out['verses'] and 70 not in out['direct']))
    out_nj = parse_struct(json.dumps(struct), '')
    ok.append(('여정 없으면 전부 직계',
               sorted(out_nj['direct']) == sorted(out_nj['verses'])))
    ok.append(('링크 3개(부모 있는 노드 수)', len(out['links']) == 3))
    ok.append(('관점 라벨 보존(병합형 그대로)',
               ('BIBLE:1', 'BIBLE:70', '예표-성취·점진 계시') in out['links']))
    ok.append(('깨진 JSON → None', parse_struct('{잘림') is None))
    ok.append(('빈 여정 허용', parse_struct(json.dumps(struct), '')['verses'][0] in (1, 70, 99)))

    # DB 갈래 — 임시 메모리 DB 에 실 스키마 재현
    c = sqlite3.connect(':memory:')
    c.execute("""CREATE TABLE user_saved_maps (
        root_id INTEGER, save_type TEXT CHECK(save_type IN ('AUTO','MANUAL')),
        map_name TEXT, path_string TEXT, tag_list TEXT,
        updated_at DATETIME DEFAULT (datetime('now','localtime')),
        full_structure TEXT, description TEXT,
        PRIMARY KEY (root_id, save_type, map_name))""")
    js = json.dumps(struct)
    c.execute("INSERT INTO user_saved_maps(root_id,save_type,map_name,path_string,full_structure,updated_at) "
              "VALUES (1,'AUTO','AUTO_1',?,?,datetime('now','-1 hour'))", (path, js))
    c.execute("INSERT INTO user_saved_maps(root_id,save_type,map_name,path_string,full_structure) "
              "VALUES (1,'MANUAL','창1:1_빛',?,?)", (path, js))
    c.execute("INSERT INTO user_saved_maps(root_id,save_type,map_name,path_string,full_structure) "
              "VALUES (1,'MANUAL','PIN_1',?,?)", (path, js))

    rows = list_maps(conn=c, root_id=1)
    ok.append(('목록 — PIN 기본 제외', len(rows) == 2
               and all(not r['map_name'].startswith('PIN_') for r in rows)))
    rows2 = list_maps(conn=c, root_id=1, include_auto=False)
    ok.append(('목록 — AUTO 제외', len(rows2) == 1
               and rows2[0]['map_name'] == '창1:1_빛'))
    m = load_map(conn=c, root_id=1)                 # 이름 없음 = AUTO 슬롯
    ok.append(('AUTO 슬롯 기본', m and m['map_name'] == 'AUTO_1'))
    m2 = load_map(conn=c, root_id=1, map_name='창1:1_빛')
    ok.append(('이름 지정 열기', m2 and m2['save_type'] == 'MANUAL'
               and m2['verses'] == [1, 99, 70]))
    ok.append(('없는 맵 → None', load_map(conn=c, root_id=777) is None))
    c.close()

    bad = [n for n, p in ok if not p]
    for n, p in ok:
        print(('PASS' if p else 'FAIL'), n)
    print('=== %d/%d ===' % (len(ok) - len(bad), len(ok)))
    return not bad


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if _selftest() else 1)
    print(__doc__)
