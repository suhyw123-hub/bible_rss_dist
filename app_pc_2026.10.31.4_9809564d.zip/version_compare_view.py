# -*- coding: utf-8 -*-
"""P4 역본 비교 탭 (VersionCompareView).

- 구절 비교: 현재 구절을 비교 버전 전부로 세로 나열. verse_id 공유라 ~99% 1:1.
- 장 비교: 좌우 컬럼 스크롤 대조. 단 자동 전부 표시가 아니라, 바의 [▾ 역본 선택] 팝업에서
          사용자가 고른 역본만 컬럼으로 표시(좁으면 소수만 고르면 됨).
- 상단 ◀▶ 로 앞절/뒷절 이동. 비교 버전 집합 = user_config['PREFERRED_VERSIONS'](환경설정의 '비교 버전').
"""
import json
import sqlite3
import appdb
import verse_text as _vt   # ★ 절 본문은 이 문 하나로(합쳐짐·없는절 보완 §verse_text)


def _lang_of(conn, code):
    """그 역본의 언어 — **빌려 올 역본을 선택하는 데** 쓴다."""
    try:
        r = conn.execute('SELECT lang_code FROM bible_version'
                         ' WHERE version_code=?', (code,)).fetchone()
        return (r[0] or 'EN').upper() if r else 'EN'
    except Exception:                                         # noqa: BLE001
        return 'EN'

import tkinter as tk
from tkinter import ttk
from tkinter.scrolledtext import ScrolledText

import i18n
import bidi



def in_scope(conn, code, bcode):
    """그 역본이 그 책을 담는가 — 구약만·신약만 있는 역본을 가른다."""
    sc = _vt._scope(conn, code)
    if sc == 'NT_ONLY':
        return int(bcode) >= 40
    if sc == 'OT_ONLY':
        return int(bcode) < 40
    return True


def _tf(w, db):
    """성경 구절 위젯에 「성경」 역할 글꼴을 입힌다 (font.md §22).

    ⚠ 그릴 때마다 새로 만드는 위젯이라 `register` 하지 않는다 —
      곧 사라지는데 등록 목록만 쌓인다. 그 자리에서 입히고 만다.
    """
    try:
        import theme_font
        theme_font.apply(w, db, 'bible')
    except Exception:
        pass


def _C(role, fb):
    """역할색 (§36). ★ 이 화면은 구절 클릭마다 본문 위젯을 **새로 만든다** —
    색을 리터럴로 적으면 탭 paint 가 지나간 뒤라 흰 바탕으로 돌아온다
    (2026-08-20 사용자 신고 「다른 구절을 클릭하면 하얀 배경, 탭 헤더를
    클릭하면 정상화」의 원인). 그리는 시점에 역할로 읽어야 한다."""
    try:
        import ui_theme
        return ui_theme.C(role) or fb
    except Exception:
        return fb

class VersionCompareView(ttk.Frame):
    def __init__(self, parent, db_path, lang_getter, verse_getter, ver_getter=None):
        super().__init__(parent)
        self.db = db_path
        self.lang_getter = lang_getter
        self.verse_getter = verse_getter
        self.ver_getter = ver_getter   # 현재 P1 읽는 버전 (맨 왼쪽 고정)
        self._vid = None
        self._mode = 'verse'
        self._chap_sel = None      # 장 비교에서 표시할 역본 코드 목록(사용자 선택)
        self._picker = None
        self._build()

    def _lang(self):
        return (self.lang_getter() if callable(self.lang_getter) else 'KO') or 'KO'

    def _compare_versions(self):
        """비교 버전 코드 + 표시명. PREFERRED_VERSIONS → 기본세트."""
        with appdb.connect(self.db) as c:
            allset = {r[0] for r in c.execute("SELECT version_code FROM bible_version")}
            dn = {r[0]: (r[1] or r[2] or r[0]) for r in c.execute(
                "SELECT version_code, display_name, version_name FROM bible_version")}
            r = c.execute("SELECT config_val FROM user_config WHERE config_key='PREFERRED_VERSIONS'").fetchone()
            codes = []
            if r and r[0]:
                try:
                    codes = [x for x in json.loads(r[0]) if x in allset]
                except Exception:
                    codes = []
            if not codes:
                dv = c.execute("SELECT config_val FROM user_config WHERE config_key='v1_code'").fetchone()
                dv = dv[0] if dv else 'KRV'
                lv = [r2[0] for r2 in c.execute(
                    "SELECT version_code FROM bible_version WHERE lang_code=? ORDER BY version_code",
                    (self._lang(),))]
                for x in [dv] + lv + ['BSB', 'KJV']:
                    if x in allset and x not in codes:
                        codes.append(x)
        # 현재 P1에서 읽는 버전을 항상 맨 앞(왼쪽)에 — 비교목록에 없어도 포함
        cur = (self.ver_getter() if callable(self.ver_getter) else None)
        if cur and cur in allset:
            codes = [cur] + [x for x in codes if x != cur]
        # ★ 2026-10-11 (docs/1.txt 3) — 이 책을 담지 않는 역본은 **목록에서 뺀다**
        #   (신약만 있는 콥트어 역본을 구약 절에서 BSB 로 빌려 보이던 자리).
        #   절 비교 · 장 비교 · 장 비교 역본 고르기가 모두 이 문을 지난다.
        if self._vid:
            with appdb.connect(self.db) as c:
                bi = c.execute('SELECT bcode FROM bible_index WHERE verse_id=?',
                               (self._vid,)).fetchone()
                if bi:
                    codes = [x for x in codes if in_scope(c, x, bi[0])]
        return codes, dn

    def _build(self):
        bar = tk.Frame(self, bg=_C('panel', '#EBF5FB')); bar.pack(fill='x')
        nav = dict(font=('', 10, 'bold'), bd=0, padx=8, pady=1,
                   bg=_C('accent_bg', '#D6EAF8'),
                   activebackground=_C('accent_bg', '#AED6F1'),
                   relief='flat', cursor='hand2')
        tk.Button(bar, text='◀', command=lambda: self._step(-1), **nav).pack(side='left', padx=(6, 1), pady=3)
        self._ref_lbl = tk.Label(bar, text='', font=('', 11, 'bold'),
                                 bg=_C('panel', '#EBF5FB'), fg=_C('accent', '#1A5276'))
        self._ref_lbl.pack(side='left', padx=8)
        tk.Button(bar, text='▶', command=lambda: self._step(1), **nav).pack(side='left', padx=(1, 6), pady=3)

        # ★★★ **원문대조는 여기가 집이다**(2026-09-12 사용자 1.txt 2-3 —
        #   「원문대조는 성격상 원래 주석링크와 관계없는 항목이지만, 구절과
        #    연결되어 있으므로 … **역본비교 탭 상단**에 배치된 `◀ 시1:1 ▶`
        #    **오른쪽에 여백을 두고** BibleHub Interlinear, STEP Bible 버튼」).
        #   ⚠ 그전에는 P2 「주석링크」 갈래에 있었다 — **주석과 성질이 다른데**
        #     한 줄에 섞여 있었다. 여기는 역본을 나란히 놓는 화면이라 제자리다.
        #   ⚠ **주소를 여기서 만들지 않는다** — `sys_ref_verse_map` 이 이미 절
        #     마다 갖고 있다(그 문 하나를 쓴다).
        # ★ 차례 (2026-09-16 · 1.txt 11번 사용자 「< 창18:7 >, (공백), 장비교 버튼,
        #   (공백), 외부 사이트 연결 버튼」) — 왼쪽부터 순서대로 쌓는다.
        self._mode_btn = tk.Button(bar, text=i18n.t('VC_CHAP', '장 비교'),
                                   font=('', 9, 'bold'), bd=0, padx=10, pady=2,
                                   bg=_C('dark_bg', '#1A5276'),
                                   fg=_C('fg_on_dark', 'white'),
                                   cursor='hand2', command=self._toggle_mode)
        self._mode_btn.pack(side='left', padx=(24, 0), pady=3)
        # 장 비교 전용: 표시 역본 선택 팝업 버튼 (좁은 바 → 떠있는 체크리스트)
        #   — 장 비교 단추 **바로 오른쪽**에 붙는다(`_render`).
        self._pick_btn = tk.Button(bar, text='▾ ' + i18n.t('VC_PICK_VER', '역본 선택'),
                                   font=('', 9), bd=0, padx=8, pady=2,
                                   bg=_C('accent_bg', '#D4E6F1'), fg=_C('fg', '#2C3E50'),
                                   cursor='hand2', command=self._open_chap_picker)
        self._il_bar = tk.Frame(bar, bg=_C('panel', '#EBF5FB'))
        self._il_bar.pack(side='left', padx=(24, 0))
        self._il_btns = {}
        self._flag_lbl = tk.Label(bar, text='', bg=_C('panel', '#EBF5FB'),
                                  fg=_C('danger', '#C0392B'),
                                  font=('', 8, 'bold'))
        self._flag_lbl.pack(side='right', padx=6)

        self._body = tk.Frame(self, bg=_C('panel', 'white'))
        self._body.pack(fill='both', expand=True)

    #: 원문대조 사이트 — 갈래는 `sys_ref_site.media_type` 이 정한다.
    IL_TYPE = 'INTERLINEAR'

    def _fill_interlinear(self):
        """이 절의 원문대조 단추를 다시 그린다.

        ⚠ **없으면 안 그린다**(§0-1 빈 서랍 금지) — 절이 없거나 사이트가
          내려갔으면 띠째 비운다.
        """
        try:
            for w in self._il_bar.winfo_children():
                w.destroy()
            self._il_btns = {}
            if not self._vid:
                return
            import sqlite3 as _sq
            with appdb.connect(self.db) as conn:
                conn.row_factory = _sq.Row
                rows = conn.execute(
                    "SELECT m.url, s.site_name"
                    "  FROM sys_ref_verse_map m"
                    "  JOIN sys_ref_site s ON s.site_id=m.site_id"
                    " WHERE s.scope='VERSE' AND s.media_type=?"
                    "   AND m.verse_id=? AND m.map_status<>'EXCLUDED'"
                    "   AND s.is_active=1 AND s.record_status='LIVE'"
                    " ORDER BY s.sort_order", (self.IL_TYPE, self._vid)).fetchall()
            import webbrowser
            for r in rows:
                b = tk.Button(
                    self._il_bar, text=r['site_name'], font=('', 9), bd=0,
                    padx=8, pady=2, cursor='hand2',
                    bg=_C('accent_bg', '#D4E6F1'), fg=_C('fg', '#2C3E50'),
                    command=lambda u=r['url']: webbrowser.open(u))
                b.pack(side='left', padx=(0, 4))
                self._il_btns[r['site_name']] = b
        except Exception:
            pass

    # ── 외부 API ──
    def load(self, vid, mode=None):
        """구절을 싣는다. `mode='chapter'` 면 **장 비교로 바로** 연다.

        ★ 2026-08-22 사용자 지시 — 도서 화면의 [⇄ 장 비교] 가 「장 비교 단추를
          누른 것과 똑같은 효과」를 내야 한다. 모드만 밖에서 정할 수 있으면
          되므로 `_toggle_mode` 와 같은 자리를 쓴다(라벨도 함께 맞춘다).
        """
        self._vid = vid
        self._fill_interlinear()      # ★ 절이 바뀌면 원문대조 주소도 바뀐다
        if mode in ('verse', 'chapter') and mode != self._mode:
            self._mode = mode
            self._mode_btn.config(
                text=i18n.t('VC_VERSE', '구절 비교') if mode == 'chapter'
                else i18n.t('VC_CHAP', '장 비교'))
        self._render()

    def refresh(self):
        v = self.verse_getter() if callable(self.verse_getter) else None
        if v:
            self._vid = v
        self._render()

    # ── 내비/모드 ──
    def _step(self, d):
        if not self._vid:
            return
        with appdb.connect(self.db) as c:
            if d < 0:
                r = c.execute("SELECT MAX(verse_id) FROM bible_index WHERE verse_id<?", (self._vid,)).fetchone()
            else:
                r = c.execute("SELECT MIN(verse_id) FROM bible_index WHERE verse_id>?", (self._vid,)).fetchone()
        if r and r[0]:
            self._vid = r[0]
            self._fill_interlinear()   # ◀▶ 로 옮겨도 주소가 따라온다
            self._render()

    def _toggle_mode(self):
        self._mode = 'chapter' if self._mode == 'verse' else 'verse'
        self._mode_btn.config(text=i18n.t('VC_VERSE', '구절 비교') if self._mode == 'chapter'
                              else i18n.t('VC_CHAP', '장 비교'))
        self._render()

    def _clear(self):
        if self._picker and self._picker.winfo_exists():
            self._picker.destroy()
        self._picker = None
        for w in self._body.winfo_children():
            w.destroy()

    # ── 장 비교 역본 선택 팝업 ──
    def _open_chap_picker(self):
        if self._picker and self._picker.winfo_exists():
            self._picker.destroy(); self._picker = None; return
        codes, dn = self._compare_versions()
        if self._chap_sel is None:
            self._chap_sel = codes[:2]
        pop = tk.Toplevel(self); pop.wm_overrideredirect(True); self._picker = pop
        x = self._pick_btn.winfo_rootx()
        y = self._pick_btn.winfo_rooty() + self._pick_btn.winfo_height()
        pop.wm_geometry(f'+{x}+{y}')
        _pnl = _C('panel', 'white')
        frm = tk.Frame(pop, bg=_pnl, bd=1, relief='solid'); frm.pack()
        tk.Label(frm, text=i18n.t('VC_PICK_VER', '역본 선택'),
                 bg=_C('dark_bg', '#1A5276'), fg=_C('fg_on_dark', 'white'),
                 font=('', 8, 'bold')).pack(fill='x')
        self._chap_vars = {}
        for code in codes:
            v = tk.IntVar(value=1 if code in self._chap_sel else 0)
            self._chap_vars[code] = v
            tk.Checkbutton(frm, text=dn.get(code, code), variable=v,
                           bg=_pnl, fg=_C('fg', '#2C3E50'), selectcolor=_pnl,
                           anchor='w',
                           font=('', 9), command=self._apply_chap_pick).pack(fill='x', anchor='w')
        tk.Button(frm, text=i18n.t('COMMON_CLOSE', '닫기'), font=('', 8),
                  bg=_C('panel_alt', '#F4F6F7'), fg=_C('fg', '#2C3E50'),
                  command=lambda: (pop.destroy(), setattr(self, '_picker', None))).pack(fill='x')

    def _apply_chap_pick(self):
        self._chap_sel = [c for c, v in self._chap_vars.items() if v.get()]
        # 컬럼만 다시 그림 (팝업 유지)
        for w in self._body.winfo_children():
            w.destroy()
        with appdb.connect(self.db) as c:
            bi = c.execute("SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?", (self._vid,)).fetchone()
            if bi:
                _, dn = self._compare_versions()
                self._render_chapter(c, dn, bi[0], bi[1])

    # ── 렌더 ──
    def _render(self):
        self._clear(); self._flag_lbl.config(text='')
        # 모드별 역본선택 버튼 표시
        if self._mode == 'chapter':
            self._pick_btn.pack(side='left', padx=(6, 0), pady=3, after=self._mode_btn)
        else:
            self._pick_btn.pack_forget()
        # ★ 이 아래는 구절 클릭마다 새로 만드는 위젯 — 색은 반드시 _C(역할)로
        #   (탭 paint 는 이미 지나갔다. 리터럴을 적으면 다크에서 흰 바탕 재발)
        self._body.config(bg=_C('panel', 'white'))
        if not self._vid:
            tk.Label(self._body, text=i18n.t('VC_PICK', '비교할 구절을 먼저 선택하세요.'),
                     bg=_C('panel', 'white'), fg=_C('fg_dim', '#888'),
                     font=('', 10)).pack(pady=30)
            self._ref_lbl.config(text='')
            return
        lang = self._lang(); codes, dn = self._compare_versions()
        with appdb.connect(self.db) as c:
            bi = c.execute("SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?", (self._vid,)).fetchone()
            if not bi:
                return
            bk = c.execute(
                "SELECT short_name FROM book_names WHERE book_code=? AND lang_code IN (?,'EN','KO') "
                "ORDER BY CASE lang_code WHEN ? THEN 0 WHEN 'EN' THEN 1 ELSE 2 END LIMIT 1",
                (bi[0], lang, lang)).fetchone()
            self._ref_lbl.config(text=f'{(bk[0] if bk else bi[0])} {bi[1]}:{bi[2]}')
            if self._mode == 'verse':
                self._render_verse(c, codes, dn)
            else:
                if self._chap_sel is None:
                    self._chap_sel = codes[:2]
                self._render_chapter(c, dn, bi[0], bi[1])

    def _render_verse(self, c, codes, dn):
        txt = ScrolledText(self._body, wrap='word', font=('', 11),
                           bg=_C('panel', 'white'), fg=_C('fg', '#2C3E50'),
                           relief='flat', padx=10, pady=8)
        txt.pack(fill='both', expand=True)
        _tf(txt, self.db)
        txt.tag_configure('ver', font=('', 9, 'bold'),
                          foreground=_C('accent', '#1A5276'),
                          spacing1=8, spacing3=2)
        txt.tag_configure('miss', foreground=_C('danger', '#C0392B'))
        # 오른쪽에서 왼쪽으로 읽는 역본은 **그 문화의 방식대로** 오른쪽에 붙인다
        # (2026-08-13 사용자 지시: 「절비교까지도 그 사람들의 문화에 맞게 바꾸자」).
        # ★ **역본비교에서는 오른쪽 정렬을 하지 않는다** (2026-08-14 사용자 지적).
        #   아랍어만 오른쪽 끝에 붙으니 창 1:1 처럼 짧은 절에서는 화면 반대편에 홀로
        #   떨어져 **「이 역본은 본문이 없다」로 보였다**(실제로 그렇게 착각하셨다).
        #   ⚠ 여기는 **비교하는 화면**이다. 여러 역본을 눈으로 훑으려면
        #     **모두 같은 왼쪽 선에서 시작**해야 한다. 읽는 차례는 `bidi` 가 이미
        #     맞춰 두었으므로, 정렬까지 뒤집을 필요가 없다.
        #   (P1 본문처럼 **읽는** 화면은 오른쪽 정렬이 맞다 — 화면 성격이 다르다.)
        txt.tag_configure('rtl', justify='left')
        txt.tag_configure('ver_rtl', font=('', 9, 'bold'),
                          foreground=_C('accent', '#1A5276'),
                          spacing1=8, spacing3=2, justify='left')
        missing = 0
        for code in codes:
            # ★★ 역본을 나란히 놓는 자리라 **차이가 그대로 보인다**.
            #   합쳐짐·없는절·못구함을 설명문과 함께 낸다(§verse_text).
            _d = _vt.resolve(c, self._vid, code, _lang_of(c, code), borrow=False)
            # ★ 2026-10-11 (docs/1.txt 3) — 본문을 구하지 못한 역본은 **목록에서 뺀다**.
            #   읽는 화면은 다른 역본을 ( ) 로 빌려 보이지만, 비교 화면에서 빌린 글은
            #   비교할 정보가 아니라 잡음이다. 그 역본이 **일부러 뺀 절·합친 절**은
            #   역본 사이의 진짜 차이라 남긴다.
            if _d['kind'] in (_vt.MISSING, _vt.GARBAGE):
                continue
            body = _d['text']
            # ★ 역본의 언어가 정한다(2026-09-23) — `_lang_of` 가 이미 있다
            rtl = bidi.rtl_align(body, _lang_of(c, code))
            # ⚠ 역본 **이름**도 되돌려야 한다 — 그러지 않으면 아랍어 이름이 뒤집혀 보인다
            _nm = dn.get(code, code)
            txt.insert('end', bidi.for_display(_nm) + '\n',
                       'ver_rtl' if bidi.is_rtl_text(_nm) else 'ver')
            if body:
                # ⚠ Tk 는 히브리·아랍을 왼쪽부터 그린다 — 넣기 직전에 되돌린다(font.md §8)
                txt.insert('end', bidi.for_display(body) + '\n', ('rtl',) if rtl else ())
            else:
                txt.insert('end', i18n.t('VC_MISSING', '(이 역본에 없음 · versification 차이)') + '\n', 'miss')
                missing += 1
        txt.config(state='disabled')
        if missing:
            self._flag_lbl.config(text='' + i18n.t('VC_FLAG', '일부 역본에 없음 — 장 비교 권장'))

    def _render_chapter(self, c, dn, bcode, chap):
        codes_all, _ = self._compare_versions()   # 기본버전 우선 정렬됨
        chosen = set(self._chap_sel or [])
        sel = [x for x in codes_all if x in chosen] or codes_all[:1]   # 컬럼도 기본버전 먼저
        for code in sel:
            col = tk.Frame(self._body, bg=_C('panel', 'white'), bd=1, relief='solid')
            col.pack(side='left', fill='both', expand=True, padx=1)
            _nm = dn.get(code, code)
            tk.Label(col, text=bidi.for_display(_nm),
                     bg=_C('dark_bg', '#1A5276'), fg=_C('fg_on_dark', 'white'),
                     anchor='e' if bidi.is_rtl_text(_nm) else 'center',
                     font=('', 9, 'bold')).pack(fill='x')
            st = ScrolledText(col, wrap='word', font=('', 10),
                              bg=_C('panel', 'white'), fg=_C('fg', '#2C3E50'),
                              relief='flat', padx=6, pady=4, width=24)
            st.pack(fill='both', expand=True)
            _tf(st, self.db)
            st.tag_configure('vn', font=('', 8, 'bold'), foreground=_C('fg_dim', '#888'))
            st.tag_configure('miss', foreground=_C('danger', '#C0392B'))
            # ★ 절 비교와 같은 이유로 **왼쪽 정렬**이다 (2026-08-14).
            #   컬럼 안에서 아랍어만 오른쪽에 붙으면 짧은 절이 이웃 컬럼과 멀어져
            #   같은 절인데도 나란히 안 보인다.
            st.tag_configure('rtl', justify='left')
            rows = c.execute(
                "SELECT bi.verse, bc.verse_text FROM bible_index bi "
                "JOIN bible_content bc ON bc.verse_id=bi.verse_id AND bc.version_code=? "
                "WHERE bi.bcode=? AND bi.chapter=? ORDER BY bi.verse", (code, bcode, chap)).fetchall()
            if rows:
                for vn, vt in rows:
                    # ⚠ RTL 역본은 **절 번호도 줄이 시작하는 오른쪽 끝**에 온다
                    #   (P1 본문과 같은 규칙 — 실제 히브리 성경의 모습).
                    #   ⚠ **컬럼 차례는 그대로 둔다** — 비교가 목적이라 좌우가 흔들리면
                    #     눈이 따라가지 못한다(사용자: 「왼쪽 기준 정렬이 비교하기 쉽다」).
                    if bidi.is_rtl_text(vt):
                        st.insert('end', bidi.for_display(vt) + '  ', 'rtl')
                        st.insert('end', f'{vn}\n', ('vn', 'rtl'))
                    else:
                        st.insert('end', f'{vn} ', 'vn')
                        st.insert('end', f'{vt}\n')
            else:
                st.insert('end', i18n.t('VC_MISSING', '(이 역본에 없음 · versification 차이)'), 'miss')
            st.config(state='disabled')
