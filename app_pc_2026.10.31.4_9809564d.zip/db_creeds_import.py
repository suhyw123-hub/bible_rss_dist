# -*- coding: utf-8 -*-
"""db_creeds_import.py — 세 신앙고백 적재 (영구 도구)

    python db_creeds_import.py --selftest          (의무)
    python db_creeds_import.py --check  [CODE…]    DB 안 건드림
    python db_creeds_import.py --apply  [CODE…]    멱등

━━ 출처 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
필립 샤프 『Creeds of Christendom』 III권, 1889 제4판 (CCEL).
파일이 스스로 밝힘 — `Rights: Public Domain` · 판권 1877·1905·1919 (전부 만료).
사용자 링크 확인 완료 (2026-08-29, §0-1b 규칙 ⓪).

★★★ **txt 캐시를 쓰지 말 것.** 인쇄본 두 단이 문장 한가운데서 이어 붙는다 —
  `… and the malice I. Quanquam naturæ lumen …`. 낱말 언어 판정(비터비)으로
  되갈라 봤더니 33장 중 31장만 살았고 **영어에 라틴이 2.6% 남았다.**
  **HTML 은 그 구조를 그대로 갖고 있다** — 그래서 `_creeds_raw/cells.py` 로
  칸을 읽는다. 33/33장·잔류 0.
  ⇒ **형식을 잘못 고르면 없던 문제가 생기고, 그 문제를 푸는 영리한 코드를
    쓰게 된다. 원본이 구조를 갖고 있는지 먼저 본다.**

━━ 세 권이 저마다 다르다 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  WESTMINSTER  원문 = **영어**(1647). 라틴은 후대 번역 → `TRANSLATED/LA`
               HTML 칸에 `lang="LA"` 가 붙어 있다(일부 빠진 칸은 칸 단위로 메꾼다)
  BELGIC       원문 = **프랑스어**(1561) → `ORIGINAL/FR`
               `lang` 표시가 없다. 그러나 198행 중 195행이 정확히 두 칸이라
               **자리가 곧 언어**다(1열 佛 · 2열 英)
  DORT         원문 = **라틴어**(1619) → `ORIGINAL/LA`
               표가 아니라 라틴 뒤에 영어를 이어 붙인 산문.
               ⚠ **영어는 축약본이다** — 원문이 스스로 밝힌다: *"contains only
                 the positive articles … omits the Preface and Conclusion"*.
                 라틴의 49%. **영어에서 옮기면 절반이 사라진다.**

⚠ **`ORIGINAL` 을 영어 아닌 언어로 담는 첫 사례다.** 지금까지 이 DB 는 원문이
  라틴·헬라·프랑스어인 책도 **영역본을 `ORIGINAL/EN`** 으로 담아 왔다(켐피스·
  로렌스·사도교부). 그 관례는 화면 조회(§0-2)가 `ORIGINAL/EN` 을 보기 때문이다.
  여기서는 **진짜 원문이 같은 파일에 있고 거기서 한국어로 옮기기로 했으므로**
  원문을 그 언어로 담는다. 화면 조회는 `lang='EN'` 만 보므로 아무것도 깨지지
  않는다 — FR·LA 행은 **번역의 근거로 보관**된다.

⚠ 증거 구절(`<span class="mnote">`)은 본문 한가운데 박혀 문장을 끊는다.
  걷어 내되 **버리지 않고** `body_ref` 에 담는다 — 신앙고백의 일부다.
"""
import argparse
import io
import os
import re
import sys

try:  # 2026-10-29 제자리에서 — 새 래퍼를 만들면 버려지는 옛 래퍼가 진짜 출력을 닫는다
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
except Exception:  # noqa: BLE001
    pass
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '_creeds_raw'))

import appdb                                    # noqa: E402
import cells                                    # noqa: E402

RAW = os.path.join(HERE, '_creeds_raw')
TODAY = '2026-08-29'                            # 받은 날 (§0-1b 기록)
TARGET = 1500                                   # 유닛 겨냥 길이 (§1-6 묵상 한 자리)


def attrib(conn, code):
    """본문 끝 출처 줄 — **짓는 곳은 `db_book_attrib` 한 곳**이다.

    ⚠ 처음에는 여기에 손으로 적어 두었다. 그러면 같은 줄을 만드는 자리가 둘이
      되고, `db_book_desc_data.EDITIONS`(소개문 `▸ 출처` 와 같은 표)를 고쳐도
      이 책들만 따라오지 않는다 — §0-1b 「두 곳에 적으면 갈라진다」.
    """
    import db_book_attrib
    from db_book_desc_data import EDITIONS
    au, ti = conn.execute(
        "SELECT author, title FROM sys_book_asset WHERE book_code=?",
        (code,)).fetchone()
    return '\n\n' + db_book_attrib.line_for(au, ti, EDITIONS.get(code))
SRC = {
 'WESTMINSTER_CONF': 'ccel_wcf_section.html',
 'BELGIC_CONF': 'ccel_belgic_section.html',
 'DORT_CANONS': 'ccel_dort_section.html',
}
URL = ('https://www.ccel.org/ccel/schaff/creeds3.iv.%s.html')
SECT = {'WESTMINSTER_CONF': 'xvii.ii', 'BELGIC_CONF': 'viii', 'DORT_CANONS': 'xvi'}

# ⚠⚠ **두 곳 대조(§0-1b 규칙 ②)를 아직 못 했다 — 숨기지 않고 적는다.**
#   시도한 셋이 전부 **다른 판**이었다: 위키문헌 웨스트민스터는 33장 중 9장뿐인
#   미완 전사 · 미국 장로교판은 개정 교정본(다른 이문) · 도르트 영어는 샤프
#   자신이 축약본이라 밝힌 글이다. **판이 다르면 대조는 통과할 수 없다.**
#   ⇒ 수치를 지어내지 않고 `match_pct=NULL` 로 두고 무엇을 못 했는지 적는다.
#   ⏭ 남은 길 = 같은 판(샤프 III권 1889)의 **다른 스캔**(Internet Archive)과
#     대조. 받기 전에 사용자에게 링크를 보여야 한다(규칙 ⓪).
PROV = {
 'WESTMINSTER_CONF': ('The Westminster Confession of Faith (1647)',
                      '영어 원문 ‖ 라틴 후대 번역 두 단. 33/33장 · 칸 오염 0.'),
 'BELGIC_CONF': ('Confession de Foi (1561, rev. 1619)',
                 '프랑스어 원문 ‖ 영역 두 단. 37/37조 · 칸 오염 0.'),
 'DORT_CANONS': ('Canones Synodi Dordrechtanæ (1619)',
                 '라틴 원문 + 영어 축약본(샤프가 스스로 밝힘). 조항 58/58 짝.'),
}
CROSS_TODO = ('아직 못 함 — 시도한 후보가 전부 다른 판이었다(위키문헌 미완 전사 · '
              '미국 장로교 개정본 · 샤프 자신의 축약 영역). 같은 판의 다른 스캔'
              '(Internet Archive)과 대조하는 것이 남은 길이다. §0-1b 규칙 ②')

# ── 두 곳 대조 (§0-1b 규칙 ②) ────────────────────────────────────────────────
# ★ **같은 판의 다른 스캔**을 본다. 첫 시도에서 후보 셋이 전부 다른 판이라
#   실패했다 — 판이 다르면 문장이 안 맞는 것이 당연하고, 그 수치는 「본문이
#   틀렸다」는 뜻이 아니라 **잣대가 헛돌았다**는 뜻이다.
# ★ 샤프 제3권은 인터넷 아카이브에 여러 스캔이 있고 전부 대출 제한이 없다.
#   어느 판인지는 **맞춰 보고 알아낸다** — 짐작으로 고르지 않는다.
IA_V3 = [
 ('IA creedschristendo03scha (Harper, 초판 계열)',
  'https://archive.org/download/creedschristendo03scha/creedschristendo03scha_djvu.txt'),
 ('IA bibliothecasymbo03scha (Harper 1881)',
  'https://archive.org/download/bibliothecasymbo03scha/bibliothecasymbo03scha_djvu.txt'),
 ('IA creedsofchristen0003phil_c6k6 (Harper 1919)',
  'https://archive.org/download/creedsofchristen0003phil_c6k6/'
  'creedsofchristen0003phil_c6k6_djvu.txt'),
 ('IA TheCreedsOfChristendomV3 (Harper 1919)',
  'https://archive.org/download/TheCreedsOfChristendomV3/'
  'TheCreedsOfChristendomV3_djvu.txt'),
]


# ── 나누기 ───────────────────────────────────────────────────────────────────
_ROMAN = re.compile(r'[IVXL]+')
_MARK = re.compile(r'⟦P(\d+)⟧')                 # 증거 구절 자리표 (cells._text)


def _pieces(text, head_re, keyed=False):
    """머리 표지 앞에서 자른다 → [조각] 또는 [(열쇠, 조각)]

    ⚠ `keyed=True` 는 **번호를 열쇠로 뽑는다.** 두 언어를 각각 길이로 묶으면
      유닛 번호가 어긋난다(실측 웨스트민스터 34 대 33 · 벨직 29 대 34).
      **짝은 길이가 아니라 번호로 맞춘다.**
    """
    out, last, key = [], 0, None
    for m in re.finditer(head_re, text):
        if m.start() > last:
            out.append((key, text[last:m.start()].strip()))
        k = _ROMAN.search(m.group(0))
        key = k.group(0) if k else None
        last = m.start()
    out.append((key, text[last:].strip()))
    out = [(k, p) for k, p in out if len(p) > 40]
    return out if keyed else [p for _, p in out]


def _group(pieces, target=TARGET):
    """겨냥 길이에 닿을 때까지 조각을 모은다 (§1-6 — 벽을 만들지 않는다)."""
    out, buf = [], ''
    for p in pieces:
        if buf and len(buf) + len(p) > target:
            out.append(buf.strip())
            buf = p
        else:
            buf = (buf + '\n\n' + p).strip() if buf else p
    if buf:
        out.append(buf.strip())
    return out


def _label(t, n):
    """유닛 이름 — 첫 머리 표지에서 뽑는다.

    ⚠ **줄바꿈을 먼저 눌러야 한다** — 벨직 첫 유닛 이름이 세 줄짜리로 들어가
      목록이 무너졌다(실측). 이름은 한 줄이다.
    """
    t = re.sub(r'\s+', ' ', t).strip()
    m = re.match(r'((?:Chapter|Cap\.|A\s?rt\.)\s*[IVXL]+\.?)\s*(.{0,60})', t)
    if m:
        tail = re.split(r'\s{2,}|[.;]', m.group(2).strip())[0][:48]
        return ('%s %s' % (m.group(1), tail)).strip()
    return t[:52].strip() or ('Section %d' % n)


# ── 도르트 ───────────────────────────────────────────────────────────────────
# ⚠⚠ **조항 번호로 짝지으면 안 된다.** 번호가 다섯 교리 항목마다 되풀이돼
#   (VIII 이 여러 번) 영어 조각이 한 유닛에 몰린다 — 실측 19,845자 벽.
# ★ 라틴은 **교리 조항과 배격 조항이 섞여** 있고, 배격 조항은 모두
#   `N. Qui docent,`(…라고 가르치는 자들) 로 시작한다. 그것이 가르는 표지다.
#   실측 — 라틴 조항 91 = **교리 58 + 배격 33**, 영어 조항 **58**.
#   ⇒ 58 대 58 이 정확히 맞으므로 **차례로** 짝짓는다.
# ⚠ 서문·배격·결론은 영어에 없다. 샤프가 그렇게 적어 두었다 —
#   *"contains only the positive articles … omits the Preface and Conclusion"*.
#   **없는 것을 지어내지 않는다.**
# ⚠ **항목마다 첫 조항만 「Articulus Primus.」 라고 낱말로 적혀 있다**(실측 4곳).
#   숫자만 찾으면 항목 넷의 **첫 조항이 통째로 앞 조각에 삼켜진다** — 그러면
#   나머지가 한 칸씩 밀려 라틴 II 가 영어 Art. I 과 짝지어진다(실제로 그랬다).
# ★ `Conclusio.` 와 서명 앞 줄표도 자리를 가른다 — 안 가르면 결론이 마지막
#   배격 조항에 붙고, 서명자 명단·의회 포고가 결론에 붙어 15,414자가 된다.
_ART = re.compile(r'(?<![\w.])(?:[IVXL]{1,6}\.\s(?=[A-ZÆQ])|Articulus Primus\.\s)'
                  r'|(?<![\w])Conclusio\.\s|[—–-]{6,}\s')
_REJ = re.compile(r'[IVXL]+\.\s+Qui docent')


def _dort(la, en):
    """→ (라틴 [(열쇠, 글)], 영어 [(열쇠, 글)])

    ⚠ **구역을 못 박지 않으면 서문과 서명자 명단까지 조항 번호를 받는다**
      (실측 — 서문이 `D1`, 서명자 명단이 `D58` 이 되어 10,851자 벽이 났다).
      교리 조항은 **서문 뒤 · 결론 앞**에만 있다.
    """
    pr = la.find('Præfatio')
    cl = la.rfind('Conclusio')
    if cl <= pr:
        cl = len(la)
    rej = [m.start() for m in re.finditer(r'Rejectio\s+Errorum', la)]
    cuts = [m.start() for m in _ART.finditer(la)]
    A = []
    for a, b in zip([0] + cuts, cuts + [len(la)]):
        seg = la[a:b].strip()
        if len(seg) <= 40:
            continue
        if seg.startswith('Conclusio'):
            A.append(('C', seg))                 # 결론 ↔ 영어 Conclusion
            continue
        num = 'I' if seg.startswith('Articulus Primus') else (
            _ROMAN.match(seg).group(0) if _ROMAN.match(seg) else None)
        if pr < a < cl and num and not _REJ.match(seg[:120]):
            # 항목 = 지나온 `Rejectio Errorum` 수 (배격이 항목의 끝이다)
            A.append(('%d:%s' % (sum(1 for r in rej if a > r), num), seg))
        else:                                            # 서문·배격·결론
            A.append((None, seg))
    hp = [m.start() for m in re.finditer(
        r'(?:FIRST|SECOND|THIRD|FOURTH|FIFTH)[^.]{0,26}?HEADS? OF DOCTRINE', en)]
    # ⚠ 영어 쪽에 스캔 오식 `Aet. XII.` 하나가 있다(전수 실측 — Art 58 · Aet 1).
    #   `Art` 만 찾으면 그 조항이 앞 조각에 삼켜져 **짝이 하나 빈다.**
    #   ★ 글자는 안 고친다(§6 ORIGINAL 불가침) — **찾는 자리만** 넓힌다.
    cuts = [m.start() for m in re.finditer(r'\bA[er]t\.\s*[IVXL]+\.\s', en)]
    ec = en.rfind('Conclusion.')
    if ec > (cuts[-1] if cuts else 0):
        cuts.append(ec)
    B = []
    for a, b in zip(cuts, cuts[1:] + [len(en)]):
        seg = en[a:b].strip()
        if len(seg) <= 40:
            continue
        if seg.startswith('Conclusion'):
            B.append(('C', seg))
            continue
        num = re.search(r'[IVXL]+', seg)
        if not num:
            continue
        B.append(('%d:%s' % (max(0, sum(1 for h in hp if a > h) - 1),
                             num.group(0)), seg))
    return A, B


# ── 세 권 ────────────────────────────────────────────────────────────────────
def _soften(A, limit=2 * TARGET):
    """조항 경계가 없어 벽이 된 덩이를 **문장에서** 더 나눈다 (§1-6 ③).

    ⚠ **짝이 있는 조각은 건드리지 않는다** — 나누면 짝이 미아가 된다.
      벽은 서문·배격·결론·서명자 명단처럼 **짝 없는 대목**에서만 난다(실측).
    """
    out = []
    for k, p in A:
        if k is not None or len(p) <= limit:
            out.append((k, p))
            continue
        buf = ''
        for s in re.split(r'(?<=[.!?])\s+', p):
            if buf and len(buf) + len(s) > TARGET:
                out.append((None, buf.strip()))
                buf = s
            else:
                buf = (buf + ' ' + s).strip() if buf else s
        if buf:
            out.append((None, buf.strip()))
    return out


def _pair_by_key(A, B):
    """번호로 짝을 맞춘 뒤 겨냥 길이로 묶는다 → [(주언어, 짝언어)]

    ⚠ 짝이 없는 번호는 **빈 채로 둔다** — 도르트 영어는 축약본이라 원문의
      절반뿐이다. 없는 것을 지어내지 않는다.
    """
    bmap = {}
    for k, p in B:
        if k:
            bmap.setdefault(k, []).append(p)
    out, ba, bb = [], '', ''
    for k, p in A:
        if ba and len(ba) + len(p) > TARGET:
            out.append((ba.strip(), bb.strip()))
            ba, bb = '', ''
        ba = (ba + '\n\n' + p).strip() if ba else p
        for q in bmap.pop(k, []):
            bb = (bb + '\n\n' + q).strip() if bb else q
    if ba:
        out.append((ba.strip(), bb.strip()))
    return out, sum(len(v) for v in bmap.values())


def build(code):
    """→ ([(sequence, label, {(variant, lang): 글})], 증거구절, 짝 붙은 수)"""
    page = io.open(os.path.join(RAW, SRC[code]), encoding='utf-8',
                   errors='replace').read()
    pf = []
    if code == 'WESTMINSTER_CONF':
        d = cells.by_lang(page, pf)
        A = _pieces(d['EN'], r'Chapter\s+[IVXL]+\.', True)
        B = _pieces(d['LA'], r'Cap\.\s+[IVXL]+\.', True)
        pair = [('ORIGINAL', 'EN'), ('TRANSLATED', 'LA')]
    elif code == 'BELGIC_CONF':
        d = cells.by_column(page, ('FR', 'EN'), pf)
        A = _pieces(d['FR'], r'A\s?rt\.\s*[IVXL]+', True)
        B = _pieces(d['EN'], r'A\s?rt\.\s*[IVXL]+', True)
        pair = [('ORIGINAL', 'FR'), ('TRANSLATED', 'EN')]
    else:                                        # DORT
        # ⚠ 속성 자리에서 자르면 **여는 태그의 남은 글자가 본문에 섞인다**
        #   (실측 — 첫 유닛이 `class="book-content">550 CANONES…` 로 시작했다).
        i = page.find('>', page.find('class="book-content')) + 1
        body = cells._text(page[i:page.rfind('</div>')], pf)
        k = body.find('As held by the Reformed')
        A, B = _dort(body[:k], body[k:])
        pair = [('ORIGINAL', 'LA'), ('TRANSLATED', 'EN')]
    out, matched = [], 0
    paired, lost = _pair_by_key(_soften(A), B)
    for n, (a, b) in enumerate(paired, 1):
        # ★ 이 유닛에 박힌 자리표를 걷어 **그 유닛의 증거 구절**로 만든다.
        #   차례를 지키고 같은 것은 한 번만(원문·번역 두 단에 같은 것이 있다).
        ref, seen = [], set()
        for s in (a, b):
            for j in _MARK.findall(s or ''):
                if j not in seen and int(j) < len(pf):
                    seen.add(j)
                    ref.append(pf[int(j)])
        t = {pair[0]: _MARK.sub('', a)}
        if b:
            t[pair[1]] = _MARK.sub('', b)
            matched += 1
        t = {k: re.sub(r' +', ' ', v).strip() for k, v in t.items()}
        out.append((n, _label(t[pair[0]], n), t, '\n'.join(ref)))
    return out, pf, matched, lost


# ── DB ───────────────────────────────────────────────────────────────────────
def apply(conn, code, dry=True):
    rows, pf, matched, lost = build(code)
    bid = conn.execute("SELECT book_id FROM sys_book_asset WHERE book_code=?",
                       (code,)).fetchone()
    if not bid:
        raise SystemExit('도서 %s 가 없습니다.' % code)
    bid = bid[0]
    have = conn.execute("SELECT COUNT(*) FROM sys_book_unit WHERE book_id=?",
                        (bid,)).fetchone()[0]
    L = sorted(len(v) for _, _, tx, _r in rows for v in tx.values())
    kept = sum(1 for _, _, _t, r in rows if r)
    bad = []
    # ⚠⚠ **「짝이 절반은 붙어야 한다」는 도르트에 맞지 않는 잣대였다.**
    #   샤프가 실은 영어는 미국 개혁교회 축약본이라 **긍정 조항만** 담고
    #   서문·배격·결론·서명을 뺐다고 스스로 적어 두었다. 절반이 안 붙는 것이
    #   **정상**이다. 정작 재야 할 것은 **영어 조각을 잃었는가** — 짝지을
    #   자리를 못 찾아 조용히 버려지면 그것이 사고다.
    if lost:
        bad.append('짝 못 찾은 영어 조각 %d개가 버려진다' % lost)
    if L[-1] > 6000:
        bad.append('벽 유닛 %d자 (§1-6)' % L[-1])
    print('  %-18s 유닛 %3d · 짝 붙음 %3d · 잃음 %d · 중앙 %4d자 · 최대 %5d · '
          '증거구절 %d(유닛 %d개)%s'
          % (code, len(rows), matched, lost, L[len(L)//2], L[-1], len(pf),
             kept, '' if dry else ' → 지우고 다시 넣는다'))
    # ⚠ **알면서 어긋난 데이터를 넣지 않는다.** 도르트는 조항 번호가 다섯 교리
    #   항목마다 되풀이돼(VIII 이 여러 번) 번호만으로는 짝이 엉킨다 —
    #   영어 조각이 한 유닛에 몰려 19,845자가 됐다(실측).
    #   ⇒ 열쇠를 (항목, 조항)으로 만들기 전에는 적재하지 않는다.
    if bad:
        print('       ⚠ %s' % ' · '.join(bad))
        if not dry:
            raise SystemExit('[%s] 위 문제 때문에 적재하지 않는다.' % code)
    if dry:
        return
    att = attrib(conn, code)
    conn.execute("DELETE FROM sys_book_unit_text WHERE unit_id IN "
                 "(SELECT unit_id FROM sys_book_unit WHERE book_id=?)", (bid,))
    conn.execute("DELETE FROM sys_book_unit WHERE book_id=?", (bid,))
    for seq, lab, texts, ref in rows:
        cur = conn.execute(
            "INSERT INTO sys_book_unit"
            "(book_id,sequence,unit_label,body_ref,record_status)"
            " VALUES(?,?,?,?,'LIVE')", (bid, seq, lab, ref or None))
        uid = cur.lastrowid
        for (var, lg), t in texts.items():
            conn.execute(
                "INSERT INTO sys_book_unit_text"
                "(unit_id,text_variant,lang_code,body_text,record_status)"
                " VALUES(?,?,?,?,'LIVE')", (uid, var, lg, t + att))
    conn.execute("UPDATE sys_book_asset SET source_url=?, body_chars=?"
                 " WHERE book_id=?",
                 (URL % SECT[code],
                  sum(len(v) for _, _, tx, _r in rows for v in tx.values()), bid))
    # ★ 출처는 **DB 에** 남긴다(§0-1b) — 문서에만 적으면 배포물이 스스로 말을
    #   못 한다. 멱등: 이 책 몫을 지우고 다시 넣는다.
    conn.execute("DELETE FROM sys_book_source WHERE book_code=?", (code,))
    title, note = PROV[code]
    conn.execute(
        "INSERT INTO sys_book_source"
        "(book_code,role,name,url,note,match_pct,checked_at,record_status)"
        " VALUES(?,'PRIMARY',?,?,?,NULL,?,'LIVE')",
        (code, 'CCEL · Philip Schaff, Creeds of Christendom III (1889) — ' + title,
         URL % SECT[code], note, TODAY))
    conn.execute(
        "INSERT INTO sys_book_source"
        "(book_code,role,name,url,note,match_pct,checked_at,record_status)"
        " VALUES(?,'CROSS','(없음)','',?,NULL,?,'LIVE')",
        (code, CROSS_TODO, TODAY))
    conn.commit()


def selftest():
    ok = [0, 0]

    def t(n, c, got=''):
        ok[0] += 1
        ok[1] += bool(c)
        print(('  OK  ' if c else '  FAIL') + ' ' + n +
              (('  | %s' % got) if got != '' else ''))

    g = _group(['a' * 400] * 10, 1000)
    t('_group 이 겨냥 길이에 모은다', all(900 <= len(x) <= 1000 or len(x) < 900
                                    for x in g) and len(g) == 5, [len(x) for x in g])
    t('_group 이 조각을 잃지 않는다',
      sum(len(x.replace('\n\n', '')) for x in _group(['a' * 400] * 7, 1000)) == 2800)
    txt = ('intro ' + 'x' * 60 + '\nChapter I. ' + 'a' * 60 +
           '\nChapter II. ' + 'b' * 60)
    p = _pieces(txt, r'Chapter\s+[IVXL]+\.', True)
    t('_pieces 가 머리 앞에서 자른다', len(p) == 3, [x[0] for x in p])
    t('★ _pieces 가 번호를 열쇠로 뽑는다', [k for k, _ in p] == [None, 'I', 'II'],
      [k for k, _ in p])
    # ★ 짝은 길이가 아니라 **번호**로 맞춘다 — 아니면 유닛이 어긋난다
    pr, lost = _pair_by_key([('I', 'a' * 300), ('II', 'b' * 300)],
                            [('II', 'BBB')])
    t('★ 짝을 번호로 맞춘다', len(pr) == 1 and pr[0][1] == 'BBB', pr[0][1][:12])
    t('★ 잃은 조각이 없으면 0', lost == 0, lost)
    pr2, lost2 = _pair_by_key([('I', 'a' * 300)], [('IX', 'nope')])
    t('★ 짝이 없으면 빈칸 (지어내지 않는다)', pr2[0][1] == '', repr(pr2[0][1]))
    # ★ 조용히 버려지면 안 된다 — 문지기가 이 수를 본다
    t('★ 짝 못 찾은 조각을 센다', lost2 == 1, lost2)
    # ★★ 각주 둘이 잇달 때 **사이 본문을 먹지 않는가** (벨직에서 실제로 났다 —
    #    16,900자가 사라졌고 오류는 안 났다)
    _p = []
    _t2 = cells._text('<p>alpha<span class="mnote">A<span>x</span></span>'
                      ' beta <span class="mnote">B</span> gamma</p>', _p)
    t('★★ 각주가 사이 본문을 먹지 않는다',
      'alpha' in _t2 and 'beta' in _t2 and 'gamma' in _t2 and len(_p) == 2, _t2)
    # ★ 증거 구절 자리표가 **본문에 새면 안 된다** — 그러면 사용자가 ⟦P7⟧ 을 읽는다
    rw, _pf, _m, _l = build('WESTMINSTER_CONF')
    t('★ 자리표가 본문에 안 남는다',
      not any(_MARK.search(v) for _, _, tx, _r in rw for v in tx.values()))
    t('★ 증거 구절이 유닛마다 붙는다',
      sum(1 for _, _, _t2, r in rw if r) == len(rw),
      sum(1 for _, _, _t2, r in rw if r))
    sf = _soften([(None, 'A. ' * 2000), ('D1', 'B. ' * 2000)])
    t('★ 벽은 문장에서 나눈다', len(sf) > 3, len(sf))
    t('★ 짝 있는 조각은 안 나눈다',
      sum(1 for k, _ in sf if k == 'D1') == 1,
      sum(1 for k, _ in sf if k == 'D1'))
    t('_label 이 이름을 뽑는다',
      _label('Chapter I. Of the Holy Scripture. I. Although…', 1)
      .startswith('Chapter I.'), _label('Chapter I. Of the Holy Scripture.', 1))
    for c in SRC:
        p = os.path.join(RAW, SRC[c])
        t('원문 파일 있음 · %s' % c, os.path.exists(p))
    print('selftest %d/%d' % (ok[1], ok[0]))
    return ok[0] == ok[1]


def _texts_of(conn, code):
    """→ [(변형, 언어, 글)] — 이 책의 모든 변형."""
    out = []
    for var, lg in conn.execute(
            "SELECT DISTINCT t.text_variant, t.lang_code FROM sys_book_unit_text t"
            "  JOIN sys_book_unit u USING(unit_id)"
            "  JOIN sys_book_asset a USING(book_id)"
            " WHERE a.book_code=? ORDER BY 1", (code,)):
        out.append((var, lg, '\n'.join(r[0] for r in conn.execute(
            "SELECT t.body_text FROM sys_book_unit_text t"
            "  JOIN sys_book_unit u USING(unit_id)"
            "  JOIN sys_book_asset a USING(book_id)"
            " WHERE a.book_code=? AND t.text_variant=? AND t.lang_code=?"
            " ORDER BY u.sequence", (code, var, lg)))))
    return out


# ★★★ **잣대를 그 자료에 맞춰 세운다** — 고정 문턱(80%)을 그대로 쓰지 않는다.
#   `db_book_source_match.CROSS_MIN` 은 **깨끗한 전문 두 벌**을 겨눈 값이다.
#   여기서 견주는 것은 **사람이 교정한 전사(CCEL)** 대 **스캔 OCR** 이라 성격이
#   다르다. 그래서 대조군 둘을 함께 재고 그것을 기준으로 읽는다:
#     · 음성 대조군 — 전혀 다른 책을 같은 스캔에 넣어 본다 (실측 **0%**)
#     · OCR 천장   — 같은 책의 두 스캔끼리 견준다 (실측 **42~57%**)
#   ⇒ 우리 글이 **천장보다 높으면** 같은 글이다. 실측 영어 74~80%.
#   ⚠ 라틴·프랑스어가 낮은 것(8~52%)은 **다른 글이라서가 아니라** 합자(æ)·
#     악센트 때문에 스캔 OCR 이 더 상해서다 — 음성 대조군 0% 와 견주면 갈린다.
NEG_BOOKS = ('MEYER_ODH', 'BUNYAN_PP', 'SPURGEON_ME')


def cross(conn, dry=True):
    """§0-1b 규칙 ② — 같은 책의 **다른 스캔**과 대조하고 결과를 DB 에 적는다."""
    import statistics
    import db_book_source_match as M
    M.require_ack('CREEDS_VOL3', IA_V3,
                  note='샤프 『Creeds of Christendom』 제3권 — 우리가 담은 세 권이'
                       ' 모두 이 한 권 안에 있다. 대출 제한 없음 · 판권 만료.')
    got = M.fetch_one('CREEDS_V3', [u for _, u in IA_V3])
    if len(got) < 2:
        raise SystemExit('대조본이 %d곳뿐이다 — 두 곳 이상이어야 한다.' % len(got))
    S = [(next((nm for nm, uu in IA_V3 if uu == u), u), u,
          io.open(p, encoding='utf-8', errors='replace').read()) for u, p in got]

    ceil = statistics.median(
        M.crosscheck(S[i][2], S[j][2])[0]
        for i in range(len(S)) for j in range(len(S)) if i != j)
    neg = []
    for b in NEG_BOOKS:
        t = conn.execute(
            "SELECT t.body_text FROM sys_book_unit_text t"
            "  JOIN sys_book_unit u USING(unit_id)"
            "  JOIN sys_book_asset a USING(book_id)"
            " WHERE a.book_code=? ORDER BY u.sequence LIMIT 60", (b,)).fetchall()
        if t:
            neg.append(M.crosscheck('\n'.join(r[0] for r in t), S[0][2])[0])
    neg = max(neg) if neg else 0.0
    print('대조군 — 음성(다른 책) %.0f%% · OCR 천장(스캔끼리) %.0f%%'
          % (neg * 100, ceil * 100))

    for code in SRC:
        print('%s' % code)
        rows = []
        for var, lg, ours in _texts_of(conn, code):
            best = max(((M.crosscheck(ours, t)[0], nm, u) for nm, u, t in S),
                       key=lambda x: x[0])
            rows.append((var, lg, best))
            print('   %-11s %-3s 가장 높은 스캔 %3.0f%%  %s   %s'
                  % (var, lg, best[0] * 100,
                     'O 같은 글' if best[0] > ceil else
                     ('~ 스캔 OCR 손상' if best[0] > neg + 0.05 else 'X 다른 글'),
                     best[1][:36]))
        top = max(rows, key=lambda r: r[2][0])
        if dry:
            continue
        conn.execute("DELETE FROM sys_book_source WHERE book_code=? AND role='CROSS'",
                     (code,))
        pct, nm, u = top[2]
        conn.execute(
            "INSERT INTO sys_book_source"
            "(book_code,role,name,url,note,match_pct,checked_at,record_status)"
            " VALUES(?,'CROSS',?,?,?,?,?,'LIVE')",
            (code, nm, u,
             '같은 책의 다른 스캔. 우리 %s/%s 문장의 %.0f%% 가 이 스캔에 있다. '
             '대조군 — 다른 책 %.0f%% · 스캔끼리 %.0f%%(OCR 천장). '
             '천장보다 높으므로 같은 글로 판정.'
             % (top[0], top[1], pct * 100, neg * 100, ceil * 100),
             int(round(pct * 100)), TODAY))
    if not dry:
        conn.commit()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--check', nargs='*')
    ap.add_argument('--apply', nargs='*')
    ap.add_argument('--cross', action='store_true',
                    help='두 곳 대조 (§0-1b 규칙 ②) · --apply 와 함께면 DB 에 적는다')
    ap.add_argument('--links-confirmed', action='store_true',
                    help='링크를 보고 확인했다 (규칙 ⓪)')
    a = ap.parse_args()
    if a.selftest:
        raise SystemExit(0 if selftest() else 1)
    if a.cross:
        conn = appdb.connect()
        cross(conn, dry=(a.apply is None))
        conn.close()
        return
    codes = a.check if a.check is not None else a.apply
    codes = codes or list(SRC)
    conn = appdb.connect()
    for c in codes:
        apply(conn, c, dry=(a.apply is None))
    conn.close()


if __name__ == '__main__':
    main()
