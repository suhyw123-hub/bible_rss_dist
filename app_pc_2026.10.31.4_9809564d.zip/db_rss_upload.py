# -*- coding: utf-8 -*-
"""
db_rss_upload.py — RSS 배포 자동 발행 CLI (영구 도구, OS 작업 스케줄러용)

관리자 DB(bible_master.db)에서 선택한 종류를 표준 파일로 만들어 서버(GitHub)에 발행.
**변경 시에만 발행**(기본) — 내용 같으면 skip(전 사용자 재다운로드 낭비 방지).

종류:
  --feeds      피드 주소록(sys_rss_feed)
  --items      최신뉴스(각 피드 실시간 fetch — 느림, 매일 갱신 가치 큼)
  --youtube    최신유튜브(sys_media_asset)
  --announce   공지사항(sys_announcement)
  --links      영상 연결 팩 델타(2026-09-29 293차 — db_linkpack_build.publish)
  --all        5종 전부 (플래그 없으면 기본 = --all)
  --force      변경 없어도 강제 발행

★★★ 매일 자동(2026-09-29 293차) — `collect_channels.py`(작업 스케줄러
  BibleMatrix_ChannelCollect)가 끝날 때 **자동 업로드 스위치가 켜져 있으면**
  `run(kinds=KINDS_ALL)` 을 부른다. 그전에는 이 스크립트를 부르는 작업이
  **하나도 등록돼 있지 않아** 「매일 자동 전송」이 실제로는 없었다(실측).
  ⚠ 영상 연결은 `rss_publish.publish_kind` 가 아니라 `db_linkpack_build.publish`
    다 — 시퀀스·델타·묘비 문법이 달라 한 문으로 못 묶는다.

사용:
  python db_rss_upload.py --items           # 매일: 최신뉴스만
  python db_rss_upload.py --all             # 4종 전부(변경분만)
  pythonw db_rss_upload.py --items          # 콘솔 없이(작업 스케줄러)

Windows 작업 스케줄러:
  - 동작: 'pythonw'  인수: '<앱 폴더>/db_rss_upload.py --items'  (시작 위치: <앱 폴더>)
  - 트리거: 매일 1회(원하는 시각). 주기는 스케줄러가 제어(앱 아님).
  - items 는 모든 피드를 실시간 fetch하므로 수십 초 소요 — 정상.
"""
import sys
import argparse
from datetime import datetime

import appdb
import rss_publish as P


#: 영상 연결은 종류 목록의 다섯째 — `rss_publish.KIND_ALL` 에는 없다(문법이 다르다)
KIND_LINKS = "links"
KINDS_ALL = list(P.KIND_ALL) + [KIND_LINKS]


def run(kinds=None, force=False, log=print):
    """종류들을 발행한다 → 종료 코드(0 성공/변경없음 · 1 서버 없음 · 2 실패).

    ★ `main()`(CLI)과 `collect_channels._auto_publish`(매일 자동)가 **같은 문**을
      부른다 — 둘로 쓰면 하나만 고쳐진다.
    """
    kinds = list(kinds or KINDS_ALL)
    servers = P.get_servers()
    if not [s for s in servers if s.get("enabled", True)]:
        log("[rss_upload] 등록된(사용) 서버 없음 — 관리자 앱 배포 ▸ 배포 센터 ▸ 서버 관리에서 서버 등록 필요.")
        return 1

    pub = datetime.now().isoformat(sep=" ", timespec="seconds")
    skip = not force
    log(f"[rss_upload] {pub}  종류={kinds}  변경시만={skip}")
    conn = appdb.connect("bible_master.db")
    any_ok = any_fail = False
    try:
        for kind in kinds:
            if kind == KIND_LINKS:
                # ★★★ 영상 연결 — 델타를 만들고 안 올린 것을 올린다(한 문)
                try:
                    import db_linkpack_build as LB
                    r = LB.publish(conn, servers, full=False)
                except Exception as e:                       # noqa: BLE001
                    log(f"  {kind:9s} ERROR  {str(e)[:80]}")
                    any_fail = True
                    continue
                if not r['uploaded']:
                    log(f"  {kind:9s} SKIP  {r.get('msg') or '바뀐 것 없음'}")
                    continue
                oks = [x for x in r['results'] if x['status'] == 'OK']
                st = r.get('stats') or {}
                log(f"  {kind:9s} {'OK' if oks else 'FAIL':5s} seq={r.get('seq')}"
                    f" files={len(r['uploaded'])}"
                    f" +{st.get('add', 0)} ~{st.get('mod', 0)} -{st.get('del', 0)}")
                if oks:
                    any_ok = True
                else:
                    any_fail = True
                continue
            try:
                r = P.publish_kind(conn, servers, kind, pub, skip_unchanged=skip)
            except Exception as e:
                log(f"  {kind:9s} ERROR  {str(e)[:80]}")
                any_fail = True
                continue
            log(f"  {kind:9s} {r['status']:5s} rows={r.get('rows', 0)}  {r.get('message', '')}")
            if r["status"] == "OK":
                any_ok = True
            elif r["status"] == "FAIL":
                any_fail = True
    finally:
        conn.close()
    return 0 if (any_ok or not any_fail) else 2


def main():
    ap = argparse.ArgumentParser(description="RSS 배포 자동 발행")
    ap.add_argument("--feeds", action="store_true")
    ap.add_argument("--items", action="store_true")
    ap.add_argument("--youtube", action="store_true")
    ap.add_argument("--announce", action="store_true")
    #: ⚠ 인자 이름이 **종류 이름과 글자 그대로 같아야** 한다(아래 `getattr(a, k)`)
    ap.add_argument("--aimodels", action="store_true", help="AI 모델 목록")
    ap.add_argument("--appinfo", action="store_true", help="앱 소개 글")
    ap.add_argument("--links", action="store_true", help="영상 연결 팩 델타")
    ap.add_argument("--shop", action="store_true", help="추천몰(쇼핑몰·카테고리·상품 + 썸네일)")
    ap.add_argument("--appch", action="store_true", help="앱이 받는 유튜브 채널 번호(2026-10-24)")
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--force", action="store_true", help="변경 없어도 발행")
    a = ap.parse_args()

    if a.all or not any(getattr(a, k, False) for k in KINDS_ALL):
        kinds = list(KINDS_ALL)             # 플래그 없으면 전부
    else:
        kinds = [k for k in KINDS_ALL if getattr(a, k, False)]   # attr명 = kind명 일치(⚠ 새 종류에 인자가 없어도 안 죽는다)
    return run(kinds, force=a.force)


if __name__ == "__main__":
    sys.exit(main())
