"""plan_label.py — 묵상플랜 이름의 **단일 소스** (영구 모듈).

2026-08-16 사용자 지시 — 「여러 묵상플랜이 표시되는 제목에 일관성이 없고 혼란스럽다.
복음서조화, 복음서 연대순 ??? 성경의 기적, 성경에 기록된 기적 ?? 짧고 명확하게
표준화하자.」

★ **어긋난 원인이 셋이었다** (2026-08-16 실측).

  ① **트리는 묶음 이름, 상세는 플랜 제목** — 서로 다른 표에서 나와 따로 지어졌다.
     트리 「복음서 조화」 ↔ 상세 「사복음서 공생애 연대기 묵상 플랜」
  ② **같은 행의 다른 칸을 읽었다.** 화면 6곳 중 다섯이 `sys_text_asset.contents` 를,
     `plan_focus_view` 한 곳만 `title` 을 읽는다. 두 칸의 값이 달랐다:
         title 「PLAN_TITLE_30」  ↔  contents 「성경에_기록된_기적」
  ③ **제목 자리에 코드가 그대로** — LIVE 32개 중 13개(`WORSHIP_CONTRAST`·`LENS_1`…).

★ **이름 규칙 넷**
  ① 기간을 제목에 넣지 않는다 (`(183일)`·`13주`·`— 7일` 이 형식을 셋으로 갈랐다)
  ② `_` `—` `-` 를 쓰지 않는다. 공백 하나.
  ③ **묶음 이름을 되풀이하지 않는다** — 묶음에 플랜이 하나뿐이면 제목 = 묶음 이름,
     여럿이면 **구별되는 것만**(「1년」·「2년」·「3년」)
  ④ 10자 이내

⚠ **그런데 짧은 제목만으로는 문맥 없는 곳에서 못 알아본다** (사용자 지적:
  「1 2 3년이 중복된다 묶음 이름과 결합하는가」). 실제로 「1년」은 정경순서인지
  연대기인지 알 수 없다. ⇒ **쓰는 자리에 따라 조립한다:**

      트리 안        묶음 이름이 위에 보인다        → `short()`   「1년」
      콤보·목록      문맥이 없다               → `full()`    「순서대로 통독 · 1년」

  `full()` 은 제목이 이미 묶음 이름이면 되풀이하지 않는다(「교회력 묵상」).

사용:
    python plan_label.py --selftest     (의무)
    python plan_label.py --list         지금 이름 훑어보기
"""
import sys

SEP = ' · '          # 묶음 이름과 제목 사이
MAX_LEN = 10         # 제목 길이 권장 상한 (검사용)


def group_name(ptype, dflt=None):
    """묶음 이름. `ui_strings.PLANTYPE_*` 이 단일 소스다."""
    if not ptype:
        return dflt or ''
    try:
        import i18n
        return i18n.t('PLANTYPE_' + str(ptype), dflt or str(ptype))
    except Exception:
        return dflt or str(ptype)


def full(ptype, title, dflt=None, ambiguous=False, group=None):
    """문맥이 없는 자리(콤보·진행중 목록)의 이름.

    ★ **위 묶음 이름은 겹칠 때만 붙인다** (2026-08-16 사용자: 「묶음 이름 싫다」).
      「스펄전 아침과 저녁」은 그것만으로 안다 — 앞에 「도서기반 묵상 ·」을 붙이면
      27자가 되어 콤보에서 잘린다.
      「1년」은 정경순서인지 연대기인지 모른다 — **그때만** 붙인다(`ambiguous=True`).

    ⚠ 제목이 위 묶음 이름과 같으면 되풀이하지 않는다.
    ⚠ 제목이 비면 묶음 이름만 — 코드(`LENS_1`)를 보이지 않는다.
    """
    # ★ 부르는 쪽이 묶음 이름을 알면 그것을 쓴다 (2026-08-16).
    #   트리는 `sys_plan_category`, 콤보는 `PLANTYPE_*` 이라 **같은 플랜에 두 이름**이
    #   나오던 것을 없앤다. 못 받으면 종전대로 `PLANTYPE_*`.
    g = (group or '').strip() or group_name(ptype, dflt)
    t = (title or '').strip()
    if not t:
        return g
    if not ambiguous:
        return t
    if not g or t == g:
        return t
    return g + SEP + t


def mark_ambiguous(titles):
    """두 번 이상 나오는 제목의 집합. 그 제목에만 위 묶음 이름을 붙인다."""
    seen, dup = set(), set()
    for t in titles:
        t = (t or '').strip()
        if not t:
            continue
        if t in seen:
            dup.add(t)
        seen.add(t)
    return dup


def _t(key, dflt):
    """`i18n` 이 없어도 죽지 않는다 — 이 모듈은 홀로도 돌아간다(`--selftest`)."""
    try:
        import i18n
        return i18n.t(key, dflt)
    except Exception:
        return dflt


def progress(current_day, duration_days, done=False):
    """`4/365일` · `Day 4/365`. **매일 바뀌는 유일한 값**이라 잘리면 안 된다.

    ⚠ 「일」이 **코드에 박혀 있었다** (2026-08-16 실측). 제목은 11개 언어로 채웠는데
      꼬리만 한국어라 EN 모드에서 `Spurgeon Morning and Evening  4/365일` 이 나왔다.
      ⇒ 열쇠 셋으로 뺐다. `{cur}`·`{dur}` 자리는 언어마다 앞뒤가 바뀐다
        (`4/365일` vs `Day 4/365` vs `第4/365天`).
    """
    if done:
        return _t('PL_DONE', '✓ 완료')
    try:
        cur = int(current_day or 0)
        dur = int(duration_days or 0)
    except (TypeError, ValueError):
        return ''
    if not cur and not dur:
        return ''            # ⚠ 아무 값도 없으면 「0일째」가 아니라 빈칸이다
    if dur:
        return _t('PL_PROGRESS', '{cur}/{dur}일').format(cur=cur, dur=dur)
    return _t('PL_DAY_N', '{cur}일째').format(cur=cur)


def combo(ptype, title, current_day, duration_days, done=False, dflt=None,
          ambiguous=False, group=None):
    """진행중 콤보 한 줄.

    ⚠ 예전 형식은 **기간이 두 번** 들어가고 정작 진행이 맨 뒤라 먼저 잘렸다:
          `[도서] 로렌스 하나님의 임재 연습 — 7일 - 7d · '26  [1/7일]`   34자
      분류 꼬리표(`[도서]`)는 사용자 지시로 뺐다 — `full()` 의 묶음 이름이 그 몫을 한다.
    """
    p = progress(current_day, duration_days, done)
    name = full(ptype, title, dflt, ambiguous, group)
    return ('%s  %s' % (name, p)) if p else name


def clean(s):
    """수입한 이름에서 코드 냄새를 걷는다 — `_` → 공백, 겹공백 정리."""
    s = (s or '').replace('_', ' ').replace('—', ' ').replace('–', ' ')
    return ' '.join(s.split())


# ── 자가검증 ──────────────────────────────────────────────────────────────

def selftest():
    ok = True

    # ① 묶음 되풀이 금지
    if full('LITURGICAL', '교회력 묵상', '교회력 묵상') != '교회력 묵상':
        print('FAIL 묶음와 제목이 같은데 되풀이한다'); ok = False

    # ② 겹치는 제목은 위 묶음 이름과 묶인다 — 사용자 지적의 핵심
    a = full('SEQUENTIAL', '1년', '순서대로 통독', ambiguous=True)
    b = full('CHRONOLOGICAL', '1년', '연대기 통독', ambiguous=True)
    if a == b:
        print('FAIL 「1년」이 안 묶여 구별이 안 된다:', a); ok = False
    if '1년' not in a or '순서대로' not in a:
        print('FAIL 조립이 잘못됐다:', a); ok = False

    # ③ **안 겹치면 붙이지 않는다** (「묶음 이름 싫다」)
    c2 = full('BOOK_BASED', '스펄전 아침과 저녁', '도서기반 묵상')
    if c2 != '스펄전 아침과 저녁':
        print('FAIL 안 겹치는데 앞 이름을 붙였다:', c2); ok = False

    d2 = mark_ambiguous(['1년', '2년', '1년', '스펄전 아침과 저녁'])
    if d2 != {'1년'}:
        print('FAIL 겹침 판정이 틀렸다:', d2); ok = False

    # ④ 부르는 쪽이 넘긴 묶음 이름이 이긴다 — 트리와 콤보가 같아야 한다
    e2 = full('SEQUENTIAL', '1년', '순서대로 통독', ambiguous=True, group='정경순서통독')
    if '정경순서통독' not in e2:
        print('FAIL 넘긴 묶음 이름을 안 쓴다:', e2); ok = False

    # ③ 제목이 비어도 코드를 보이지 않는다
    if full('LENS', '', '렌즈 묵상') != '렌즈 묵상':
        print('FAIL 제목이 비면 묶음 이름만 보여야 한다'); ok = False
    if full('LENS', None, '렌즈 묵상') != '렌즈 묵상':
        print('FAIL None 을 못 견딘다'); ok = False

    # ④ 진행 표시 — **글자를 맞추지 않고 짜임새를 본다**(언어에 따라 달라진다)
    p = progress(4, 365)
    if '4' not in p or '365' not in p:
        print('FAIL 진행 표시에 숫자가 없다:', p); ok = False
    q = progress(3, 0)
    if '3' not in q or '365' in q:
        print('FAIL 기간이 없을 때:', q); ok = False
    if not progress(7, 7, True):
        print('FAIL 완료 표시가 없다'); ok = False
    if progress(None, None) != '':
        print('FAIL 값이 없으면 빈 문자열이어야 한다'); ok = False

    # ⑤ 「일」을 코드에 박지 않았는가 — 2026-08-16 실제로 새던 자리
    #    i18n 이 없으면 한국어 기본값이 나오는 것이 맞다. 검사는 **자리표**를 본다.
    for key, dflt, need in (('PL_PROGRESS', '{cur}/{dur}일', ('{cur}', '{dur}')),
                            ('PL_DAY_N', '{cur}일째', ('{cur}',))):
        for ph in need:
            if ph not in dflt:
                print('FAIL %s 기본값에 %s 자리가 없다' % (key, ph)); ok = False
    try:
        '{cur}/{dur}일'.format(cur=1, dur=2)
    except Exception as e:
        print('FAIL 자리표가 깨졌다:', e); ok = False

    # ⑤ 콤보 — 기간이 **한 번만** 나온다
    c = combo('BOOK_BASED', '스펄전 아침과 저녁', 1, 7, dflt='도서기반 묵상')
    if c.count('7') != 1:
        print('FAIL 콤보에 기간이 두 번 나온다:', c); ok = False
    if '[' in c:
        print('FAIL 콤보에 꼬리표가 남았다:', c); ok = False
    if len(c) > 26:
        print('FAIL 콤보가 너무 길다: %d자 %s' % (len(c), c)); ok = False

    # ⑥ 코드 냄새 걷기
    if clean('성경에_기록된_기적') != '성경에 기록된 기적':
        print('FAIL 밑줄을 안 걷는다'); ok = False
    if clean('스펄전 아침과 저녁 — 7일') != '스펄전 아침과 저녁 7일':
        print('FAIL 긴 붙임표를 안 걷는다:', clean('스펄전 아침과 저녁 — 7일')); ok = False

    print('plan_label selftest', 'OK' if ok else 'FAIL')
    return ok


def titles_of(conn, plan_ids, lang='KO'):
    """플랜 번호 → 제목 (그 언어 · 없으면 `plan_code`).

    ★★ **이름을 읽는 자리는 여기 하나다** (2026-08-30). 화면이 `sys_text_asset`
      을 직접 읽으면 `db_overlay_audit` 의 눈금이 오르고, 무엇보다 이름 규칙이
      화면마다 갈린다 — 이 모듈이 이미 **이름을 짓는** 곳이므로 **읽는 것도**
      여기서 한다.
    """
    ids = [int(x) for x in (plan_ids or [])]
    if not ids:
        return {}
    ph = ','.join('?' * len(ids))
    out = {}
    try:
        for pid, code in conn.execute(
                "SELECT plan_id, plan_code FROM sys_bible_plan"
                "  WHERE plan_id IN (%s)" % ph, ids):
            out[pid] = code
        for pid, txt in conn.execute(
                "SELECT clicked_id, contents FROM sys_text_asset"
                "  WHERE text_type='PLAN_TITLE' AND clicked_id IN (%s)"
                "    AND UPPER(lang_code)=UPPER(?)"
                "    AND COALESCE(record_status,'LIVE')='LIVE'" % ph,
                ids + [lang or 'KO']):
            if txt:
                out[pid] = txt
    except Exception as e:
        print('[plan titles] %s' % e)
    return out


def _list():
    import appdb
    conn = appdb.connect()
    rows = conn.execute("""
        SELECT p.plan_id, p.plan_type, p.duration_days,
               (SELECT contents FROM sys_text_asset
                 WHERE clicked_id=p.plan_id AND text_type='PLAN_TITLE'
                   AND lang_code='KO' AND COALESCE(record_status,'LIVE')='LIVE'
                 LIMIT 1)
        FROM sys_bible_plan p
        WHERE COALESCE(p.record_status,'LIVE')='LIVE'
        ORDER BY p.plan_type, p.plan_id""").fetchall()
    print('%-4s %-16s %-14s %s' % ('id', '묶음', '제목', '콤보에 보일 모습'))
    for pid, pt, dur, ti in rows:
        print('%-4d %-16s %-14s %s'
              % (pid, pt or '', (ti or '')[:14], combo(pt, ti, 1, dur)))
    conn.close()


if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == '--selftest':
        sys.exit(0 if selftest() else 1)
    if len(sys.argv) > 1 and sys.argv[1] == '--list':
        _list()
    else:
        print(__doc__.split('\n')[0])
