# -*- coding: utf-8 -*-
"""listen — 「즐겨듣기」 (2026-10-11 · 영구 · --selftest 의무).

사용자 결정: 「수시로 듣고자 하는 것을 저장하는 것들만 즐겨듣기 목록 · 어떤 영상에서든지 설정 · 하트 하나 ·
해제도 · 연속재생은 즐겨듣기에 넣은 것만」. 북마크·재생목록·공유로 담은 영상은 「저장」일 뿐 저절로 들어오지 않는다.

★ 열쇠 = **유튜브 영상 번호(11자)** — 관리자가 모은 영상이든 내가 담은 영상이든 폰에서 공유한 영상이든 같은 영상이면
  같은 하트다. 저장 = user_favorite(fav_type='LISTEN', label=영상 번호, note=제목) — 이미 PC↔폰으로 오가는 표다
  (mobile_sync 사본 · 폰 사건 FAV_SET).
★ 차례 = 넣은 차례(created_at). 해제 = HIDE(지우지 않는다 — 다시 누르면 되살린다).
★ 2026-10-12 갈래 — 사용자 「즐겨듣기 하나만 만들면 안된다 · 설교/기도/찬양마다 하트한 것만 이어듣기」.
  source_code 칸(옛 값 'YT')에 갈래 `SERMON`·`PRAYER`·`WORSHIP` 을 적는다(`bucket` — 내용유형을 셋으로 접는다).
  폰이 갈래를 보내면 그것을, 안 보내면 PC 영상 표에서 찾는다(`kind_of`) · 모르면 'YT'(폰이 설교로 본다).
"""
import re
import time

KIND = 'LISTEN'
_VID = re.compile(r'(?:v=|youtu\.be/|/shorts/|/live/|/embed/)([A-Za-z0-9_-]{11})')


def vid_of(url_or_id):
    s = (url_or_id or '').strip()
    if re.fullmatch(r'[A-Za-z0-9_-]{11}', s):
        return s
    m = _VID.search(s)
    return m.group(1) if m else None


def _now():
    return time.strftime('%Y-%m-%d %H:%M:%S')


#: 내용유형 → 하트 갈래 셋. 찬양·기도 밖은 전부 「설교」(말씀) 쪽이다(성경공부·성경듣기·영화 …).
BUCKETS = ('SERMON', 'PRAYER', 'WORSHIP')


def bucket(media_type):
    t = (media_type or '').upper()
    if t in ('WORSHIP', 'SONG'):
        return 'WORSHIP'
    if t == 'PRAYER':
        return 'PRAYER'
    return 'SERMON' if t else ''


def kind_of(conn, vid):
    """영상 번호 → 하트 갈래(모르면 '')."""
    for q in ("SELECT media_type FROM sys_media_asset WHERE url LIKE ? ORDER BY is_active DESC LIMIT 1",
              "SELECT media_type FROM linkpack.pack_media WHERE url LIKE ? LIMIT 1"):
        try:
            r = conn.execute(q, ('%' + vid + '%',)).fetchone()
        except Exception:
            r = None
        if r and r[0]:
            return bucket(r[0])
    return ''


def fill_kinds(conn):
    """갈래가 안 적힌 하트(옛 'YT')를 PC 영상 표로 채운다 → 채운 수(멱등)."""
    n = 0
    for fid, v in conn.execute("SELECT fav_id, label FROM user_favorite WHERE fav_type=? AND"
                               " COALESCE(source_code,'') NOT IN ('SERMON','PRAYER','WORSHIP')", (KIND,)).fetchall():
        k = kind_of(conn, v or '')
        if k:
            conn.execute('UPDATE user_favorite SET source_code=? WHERE fav_id=?', (k, fid))
            n += 1
    conn.commit()
    return n


def is_on(conn, vid):
    r = conn.execute("SELECT 1 FROM user_favorite WHERE fav_type=? AND label=? AND record_status='LIVE'",
                     (KIND, vid)).fetchone()
    return r is not None


def set_on(conn, vid, title='', on=True, at=None, kind=''):
    """하트 켜기/끄기 → 'ADDED'|'REVIVED'|'REMOVED'|'SAME'. 커밋까지 한다."""
    vid = vid_of(vid)
    if not vid:
        return 'FAIL:NOT_A_VIDEO'
    kind = (kind or '').upper()
    if kind not in BUCKETS:
        kind = kind_of(conn, vid) if on else ''
    live = conn.execute("SELECT fav_id FROM user_favorite WHERE fav_type=? AND label=? AND record_status='LIVE'",
                        (KIND, vid)).fetchone()
    res = 'SAME'
    if on:
        if not live:
            hid = conn.execute("SELECT fav_id FROM user_favorite WHERE fav_type=? AND label=? ORDER BY fav_id DESC",
                               (KIND, vid)).fetchone()
            if hid:
                conn.execute("UPDATE user_favorite SET record_status='LIVE', created_at=?, note=COALESCE(NULLIF(?,''),note),"
                             " source_code=COALESCE(NULLIF(?,''),source_code) WHERE fav_id=?",
                             (at or _now(), title or '', kind, hid[0]))
                res = 'REVIVED'
            else:
                conn.execute("INSERT INTO user_favorite(fav_type, target_id, verse_id, source_code, label, note,"
                             " created_at, record_status) VALUES(?,NULL,NULL,?,?,?,?,'LIVE')",
                             (KIND, kind or 'YT', vid, title or '', at or _now()))
                res = 'ADDED'
    elif live:
        conn.execute("UPDATE user_favorite SET record_status='HIDE' WHERE fav_id=?", (live[0],))
        res = 'REMOVED'
    conn.commit()
    return res


def toggle(conn, vid, title=''):
    """→ 새 상태(True = 켜짐)."""
    on = not is_on(conn, vid_of(vid) or '')
    set_on(conn, vid, title, on)
    return on


#: 화면 조회에 붙이는 조각 — 영상 행(별칭)의 주소에서 영상 번호를 떼어 하트를 잇는다.
#: ⚠ 주소는 모두 `https://www.youtube.com/watch?v=` + 11자다(실측 88,025/88,056 · 나머지는 유튜브 아님)
#:   → 33번째 글자부터 11자. `f.fav_id IS NOT NULL` 이 곧 「하트 켜짐」.
def join_sql(alias):
    return ("LEFT JOIN userdb.user_favorite f ON f.fav_type='LISTEN' AND f.record_status='LIVE'"
            " AND f.label=substr(%s.url,33,11)" % alias)


def vids(conn):
    """켜진 영상 번호 묶음."""
    return {r[0] for r in conn.execute(
        "SELECT label FROM user_favorite WHERE fav_type=? AND record_status='LIVE'", (KIND,))}


def toggle_media(conn, media_id):
    """sys 영상 번호(media_id)로 하트를 뒤집는다 → 새 상태 · 영상을 못 찾으면 None."""
    r = None
    for q in ('SELECT url, title FROM sys_media_asset WHERE media_id=?',
              'SELECT url, title FROM linkpack.pack_media WHERE media_id=?'):
        try:
            r = conn.execute(q, (int(media_id),)).fetchone()
        except Exception:
            r = None
        if r:
            break
    if not r or not vid_of(r[0] or ''):
        return None
    return toggle(conn, r[0], r[1] or '')


def migrate_media_fav(conn):
    """옛 영상 별(user_media_fav)을 하트로 옮긴다 → 옮긴 수(멱등 · 옛 표는 지우지 않는다)."""
    try:
        rows = conn.execute('SELECT f.media_id, a.url, a.title, f.created_at FROM userdb.user_media_fav f '
                            'JOIN sys_media_asset a ON a.media_id=f.media_id').fetchall()
    except Exception:
        return 0
    n = 0
    for _mid, url, title, at in rows:
        v = vid_of(url or '')
        if v and not is_on(conn, v):
            set_on(conn, v, title or '', True, at)
            n += 1
    return n


def items(conn):
    """→ [(영상 번호, 제목)] 넣은 차례."""
    return [(r[0], r[1] or '') for r in conn.execute(
        "SELECT label, note FROM user_favorite WHERE fav_type=? AND record_status='LIVE' ORDER BY created_at, fav_id",
        (KIND,))]


def selftest():
    import sqlite3
    ok, tot = 0, 0

    def t(nm, cond, got=''):
        nonlocal ok, tot
        tot += 1
        ok += bool(cond)
        print(('PASS ' if cond else 'FAIL ') + nm + ('' if cond else '  ' + str(got)))
    c = sqlite3.connect(':memory:')
    c.execute('CREATE TABLE user_favorite(fav_id INTEGER PRIMARY KEY, fav_type TEXT, target_id INTEGER, verse_id INTEGER,'
              ' source_code TEXT, label TEXT, note TEXT, created_at TEXT, record_status TEXT)')
    t('주소 → 번호', vid_of('https://youtu.be/dQw4w9WgXcQ?si=x') == 'dQw4w9WgXcQ'
      and vid_of('https://www.youtube.com/watch?v=dQw4w9WgXcQ&t=3') == 'dQw4w9WgXcQ' and vid_of('그냥') is None)
    t('켠다', set_on(c, 'https://youtu.be/dQw4w9WgXcQ', '곡 A', True, '2026-01-01 00:00:00') == 'ADDED' and is_on(c, 'dQw4w9WgXcQ'))
    t('같은 영상 다른 주소 — 같은 하트', set_on(c, 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', '', True) == 'SAME')
    set_on(c, 'AAAAAAAAAAA', '곡 B', True, '2026-01-02 00:00:00')
    t('넣은 차례', [v for v, _ in items(c)] == ['dQw4w9WgXcQ', 'AAAAAAAAAAA'])
    t('해제', set_on(c, 'dQw4w9WgXcQ', on=False) == 'REMOVED' and not is_on(c, 'dQw4w9WgXcQ')
      and [v for v, _ in items(c)] == ['AAAAAAAAAAA'])
    t('다시 켜면 되살린다(줄이 늘지 않는다)', toggle(c, 'dQw4w9WgXcQ') is True
      and c.execute("SELECT COUNT(*) FROM user_favorite").fetchone()[0] == 2)
    t('되살린 것은 맨 뒤(다시 넣은 차례)', [v for v, _ in items(c)][-1] == 'dQw4w9WgXcQ')
    t('제목을 지킨다', dict(items(c))['dQw4w9WgXcQ'] == '곡 A')
    set_on(c, 'BBBBBBBBBBB', '기도 C', True, kind='PRAYER')
    t('갈래를 적는다', c.execute("SELECT source_code FROM user_favorite WHERE label='BBBBBBBBBBB'").fetchone()[0] == 'PRAYER')
    t('갈래 접기', bucket('WORSHIP') == 'WORSHIP' and bucket('PRAYER') == 'PRAYER' and bucket('STUDY') == 'SERMON'
      and bucket('') == '')
    t('모르는 갈래는 옛 값(YT)', c.execute("SELECT source_code FROM user_favorite WHERE label='AAAAAAAAAAA'").fetchone()[0] == 'YT')
    print('%d/%d' % (ok, tot))
    return ok == tot


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
