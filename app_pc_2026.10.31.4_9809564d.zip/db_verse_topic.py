# -*- coding: utf-8 -*-
"""때에 맞는 말씀 — 상황·예식·절기·암송별 구절 모음(2026-10-29 · docs/1.txt 3 · 사용자 「때에 맞는 말씀 좋다 · 같은 기반으로」).

★ 이름 — 잠언 25:11 「경우에 합당한 말은 아로새긴 은 쟁반에 금 사과니라」.
★ 같은 기반 — 구절은 말씀카드와 **한 표**(`sys_card_verse` · 세부 열쇠에 매인 구절 · db_card_verse)다.
  말씀카드 세부(CC_1 생일 …)는 그대로 이 화면의 주제가 되고, 카드에 없는 주제(장례 예배·성찬 …)만 새 열쇠 TS_* 로 더한다.
  두 벌을 두면 같은 「생일」 구절이 두 곳에서 갈린다.
★ 이 파일이 더하는 것 = 주제 목록(큰 갈래 넷 · 차례 · 이름 언어마다) + 사용자 덮개.

표
  sys_verse_topic            topic_key PK · grp · sort_order · names(JSON 언어마다) · record_status      (CORE · 폰 공통팩)
  userdb.user_verse_topic    topic_key PK · grp · name · sort_order · state(LIVE|HIDE) · updated_at
                             — 앱 주제를 가리거나 이름을 바꾼 줄(열쇠 = 앱 열쇠) · 사용자가 만든 주제(열쇠 = U…)
  userdb.user_verse_topic_item  item_id PK · topic_key · ref · note · sort_order · state · sys_cv_id · created_at
                             — 사용자가 더한 구절 · 앱 구절을 가린 줄(sys_cv_id · state HIDE)

★ 앱 자료는 지우지 않는다 — 사용자의 「지우기」는 개인 DB 의 가림 줄이다(배포로 덮여도 남는다).
★ 큰 갈래 넷 = BLESS 일상의 축복 · COMFORT 위로와 애도 · CHURCH 교회 예식·절기 · MEMO 암송(사용자 목록).

  python db_verse_topic.py --selftest | --seed [--force] | --list
"""
import json
import re
import secrets
import sys
import time

import db_card_verse as CV

GROUPS = [('BLESS', '일상의 축복', 'Everyday blessings'),
          ('COMFORT', '위로와 애도', 'Comfort and grief'),
          ('CHURCH', '교회 예식·절기', 'Church rites and seasons'),
          ('MEMO', '암송', 'Memory verses')]
GROUP_KEYS = [g for g, _k, _e in GROUPS]

#: 주제 — (열쇠, 큰 갈래, 한국어, 영어) · 차례 = 이 표의 차례 · CC_/CO_/CH_/CT_/CP_/CF_ = 말씀카드 세부(구절을 함께 쓴다)
TOPICS = [
    ('CC_1', 'BLESS', '생일', 'Birthday'),
    ('CC_2', 'BLESS', '결혼', 'Wedding'),
    ('CC_3', 'BLESS', '출산', 'New baby'),
    ('CC_4', 'BLESS', '입학·졸업', 'School'),
    ('CC_5', 'BLESS', '새 일', 'New work'),
    ('CH_1', 'BLESS', '도전', 'Challenge'),
    ('CH_2', 'BLESS', '새 출발', 'New start'),
    ('CH_3', 'BLESS', '봉사', 'Ministry'),
    ('CH_4', 'BLESS', '지친 이', 'Weary'),
    ('CT_1', 'BLESS', '감사', 'Thanks'),
    ('CT_2', 'BLESS', '스승·부모', 'Parents'),
    ('CT_3', 'BLESS', '섬김 감사', 'For serving'),
    ('CP_1', 'BLESS', '기도해요', 'Praying'),
    ('CP_3', 'BLESS', '평안', 'Peace'),
    ('CO_1', 'COMFORT', '병중', 'Illness'),
    ('CP_2', 'COMFORT', '쾌유', 'Get well'),
    ('TS_SURG', 'COMFORT', '수술 앞', 'Surgery'),
    ('CO_3', 'COMFORT', '어려움', 'Hard times'),
    ('CO_4', 'COMFORT', '이별', 'Farewell'),
    ('TS_DYING', 'COMFORT', '임종', 'Deathbed'),
    ('CO_2', 'COMFORT', '슬픔', 'Grief'),
    ('TS_FUNERAL', 'COMFORT', '장례', 'Funeral'),
    ('TS_BURIAL', 'COMFORT', '하관', 'Committal'),
    ('TS_MEMORIAL', 'COMFORT', '추모', 'Memorial'),
    ('CC_6', 'CHURCH', '세례', 'Baptism'),
    ('TS_LORD', 'CHURCH', '성찬', "Lord's Supper"),
    ('TS_ORDAIN', 'CHURCH', '임직', 'Ordination'),
    ('TS_DEDIC', 'CHURCH', '헌당·창립', 'Dedication'),
    ('CF_1', 'CHURCH', '새해', 'New Year'),
    ('TS_PASSION', 'CHURCH', '고난주간', 'Holy Week'),
    ('CF_2', 'CHURCH', '부활절', 'Easter'),
    ('TS_PENTE', 'CHURCH', '성령강림절', 'Pentecost'),
    ('CF_3', 'CHURCH', '추수감사절', 'Thanksgiving'),
    ('CF_4', 'CHURCH', '성탄절', 'Christmas'),
    # ★ 2026-10-29 암송 10 주제(교리·심리 60여 갈래를 묶음 · 사용자 「10개 분류 좋다 · 관리자가 기본 5개 구절」)
    ('TS_M01', 'MEMO', '하나님은 어떤 분인가', 'Who God is'),
    ('TS_M02', 'MEMO', '예수 그리스도와 복음', 'Jesus Christ and the gospel'),
    ('TS_M03', 'MEMO', '성령과 새 삶', 'The Spirit and new life'),
    ('TS_M04', 'MEMO', '말씀과 기도', 'The Word and prayer'),
    ('TS_M05', 'MEMO', '사랑과 관계', 'Love and relationships'),
    ('TS_M06', 'MEMO', '두려움과 염려 앞에서', 'When afraid or anxious'),
    ('TS_M07', 'MEMO', '슬픔과 낙심 속에서', 'In sorrow and discouragement'),
    ('TS_M08', 'MEMO', '시험과 유혹 앞에서', 'Facing trials and temptation'),
    ('TS_M09', 'MEMO', '부르심과 섬김', 'Calling and service'),
    ('TS_M10', 'MEMO', '영원한 소망', 'Eternal hope'),
]

#: 말씀카드에 없는 주제의 구절 — (좌표, 한 줄 설명) · 장례·예식에서 읽는 구절이라 구간도 둔다
SEED = {
    'TS_SURG': [('19:46:1', '환난 중에 만날 큰 도움이신 하나님'),
                ('23:41:10', '두려워 말라, 내가 너와 함께 함이라'),
                ('19:121:1-2', '천지를 지으신 여호와에게서 오는 도움'),
                ('50:4:6-7', '염려 대신 기도 — 지각에 뛰어난 평강'),
                ('19:4:8', '평안히 눕고 자기도 하리니')],
    'TS_DYING': [('19:23:4', '사망의 음침한 골짜기에서도 함께하심'),
                 ('43:14:1-3', '내 아버지 집에 거할 곳이 많다'),
                 ('45:8:38-39', '사망도 하나님의 사랑에서 끊을 수 없음'),
                 ('19:116:15', '성도의 죽는 것을 귀중히 보심'),
                 ('55:4:7-8', '선한 싸움을 싸우고 달려갈 길을 마침')],
    'TS_FUNERAL': [('43:11:25-26', '나는 부활이요 생명이니'),
                   ('46:15:55-57', '사망아 너의 이기는 것이 어디 있느냐'),
                   ('66:21:4', '다시 사망이 없고 애통하는 것이 없으리니'),
                   ('52:4:13-14', '소망 없는 다른 이와 같이 슬퍼하지 말라'),
                   ('19:90:12', '우리 날 계수함을 가르치소서')],
    'TS_BURIAL': [('1:3:19', '흙이니 흙으로 돌아갈 것'),
                  ('21:12:7', '흙은 땅으로, 신은 하나님께로'),
                  ('46:15:42-44', '썩을 것으로 심고 썩지 아니할 것으로 다시 삶'),
                  ('18:19:25-26', '나의 구속자가 살아 계시니'),
                  ('50:3:20-21', '우리의 시민권은 하늘에 있다')],
    'TS_MEMORIAL': [('19:103:15-17', '사람의 날은 풀과 같으나 여호와의 인자하심은 영원함'),
                    ('66:14:13', '주 안에서 죽는 자들은 복이 있도다'),
                    ('58:12:1', '구름같이 둘러싼 허다한 증인들'),
                    ('20:10:7', '의인을 기념할 때에는 칭찬하거니와'),
                    ('19:116:15', '성도의 죽는 것을 귀중히 보심')],
    'TS_LORD': [('46:11:23-26', '나를 기념하여 이를 행하라'),
                ('42:22:19-20', '너희를 위하여 주는 내 몸 · 새 언약의 피'),
                ('43:6:35', '나는 생명의 떡이니'),
                ('46:10:16-17', '그리스도의 피와 몸에 참예함'),
                ('46:11:28', '자기를 살피고 그 후에 먹고 마실지니')],
    'TS_ORDAIN': [('41:10:45', '섬김을 받으려 함이 아니라 섬기려 함'),
                  ('46:4:2', '맡은 자들에게 구할 것은 충성'),
                  ('60:5:2-4', '하나님의 양 무리를 치되 본이 되라'),
                  ('55:2:15', '부끄러울 것이 없는 일꾼'),
                  ('44:6:3', '성령과 지혜가 충만하여 칭찬 듣는 사람')],
    'TS_DEDIC': [('11:8:27-29', '이 전을 향하여 주의 눈을 여소서'),
                 ('19:127:1', '여호와께서 집을 세우지 아니하시면'),
                 ('40:16:18', '내가 내 교회를 이 반석 위에 세우리니'),
                 ('49:2:20-22', '그리스도 예수께서 친히 모퉁이 돌이 되심'),
                 ('19:84:1-2', '주의 장막이 어찌 그리 사랑스러운지요')],
    'TS_PASSION': [('38:9:9', '겸손하여서 나귀를 타시나니'),
                   ('40:21:9', '호산나 다윗의 자손이여'),
                   ('23:53:5', '그가 찔림은 우리의 허물을 인함이요'),
                   ('50:2:8', '죽기까지 복종하셨으니 곧 십자가에 죽으심'),
                   ('60:2:24', '친히 나무에 달려 그 몸으로 우리 죄를 담당하심')],
    'TS_PENTE': [('44:2:1-4', '오순절에 임하신 성령'),
                 ('29:2:28', '내 신을 만민에게 부어 주리니'),
                 ('44:1:8', '성령이 임하시면 권능을 받고'),
                 ('43:14:16-17', '또 다른 보혜사, 진리의 영'),
                 ('48:5:22-23', '성령의 열매')],
    # ── 암송(관리자 기본 다섯) ──
    'TS_M01': [('1:1:1', '태초에 하나님이 천지를 창조하심'),
               ('19:90:2', '영원부터 영원까지 하나님'),
               ('23:40:28', '피곤하지 않으시는 영원하신 창조주'),
               ('62:4:8', '하나님은 사랑이시라'),
               ('19:103:8', '자비롭고 은혜로우시며 노하기를 더디 하심')],
    'TS_M02': [('43:3:16', '독생자를 주신 하나님의 사랑'),
               ('45:5:8', '죄인 되었을 때에 우리를 위하여 죽으심'),
               ('49:2:8-9', '은혜로 믿음으로 말미암아 구원을 받음'),
               ('46:15:3-4', '죽으시고 장사 지낸 바 되시고 다시 살아나심'),
               ('43:14:6', '나는 길이요 진리요 생명이니')],
    'TS_M03': [('47:5:17', '그리스도 안에서 새로운 피조물'),
               ('48:5:22-23', '성령의 열매'),
               ('43:3:5', '물과 성령으로 나지 아니하면'),
               ('45:8:14', '하나님의 영으로 인도함을 받는 하나님의 아들'),
               ('48:2:20', '그리스도께서 내 안에 사심')],
    'TS_M04': [('19:119:105', '주의 말씀은 내 발에 등이요'),
               ('55:3:16', '모든 성경은 하나님의 감동으로 된 것'),
               ('6:1:8', '율법책을 주야로 묵상하라'),
               ('52:5:16-18', '항상 기뻐하라 쉬지 말고 기도하라'),
               ('40:7:7', '구하라 그리하면 너희에게 주실 것이요')],
    'TS_M05': [('43:13:34', '서로 사랑하라는 새 계명'),
               ('46:13:4-7', '사랑은 오래 참고'),
               ('49:4:32', '서로 인자하게 하며 서로 용서하기를'),
               ('40:22:37-39', '하나님 사랑과 이웃 사랑'),
               ('45:12:10', '형제를 사랑하여 서로 우애하고')],
    'TS_M06': [('23:41:10', '두려워 말라 내가 너와 함께 함이라'),
               ('50:4:6-7', '아무것도 염려하지 말고 기도와 간구로'),
               ('60:5:7', '너희 염려를 다 주께 맡겨 버리라'),
               ('19:56:3', '내가 두려워하는 날에는 주를 의지하리이다'),
               ('40:6:34', '내일 일을 위하여 염려하지 말라')],
    'TS_M07': [('19:34:18', '마음이 상한 자를 가까이 하심'),
               ('40:11:28', '수고하고 무거운 짐 진 자들아 다 내게로 오라'),
               ('19:42:5', '내 영혼아 네가 어찌하여 낙망하느냐'),
               ('47:4:16-18', '겉사람은 후패하나 속은 날로 새롭도다'),
               ('45:8:28', '모든 것이 합력하여 선을 이룸')],
    'TS_M08': [('46:10:13', '감당치 못할 시험 당함을 허락지 아니하심'),
               ('59:1:12', '시험을 참는 자는 복이 있나니'),
               ('62:1:9', '우리 죄를 자백하면 사하여 주심'),
               ('19:119:11', '주의 말씀을 마음에 두어 범죄치 않게'),
               ('58:4:15-16', '우리 연약함을 체휼하시는 대제사장')],
    'TS_M09': [('40:28:19-20', '가서 모든 족속으로 제자를 삼으라'),
               ('45:12:1', '너희 몸을 산 제사로 드리라'),
               ('49:2:10', '선한 일을 위하여 지으심을 받은 자'),
               ('51:3:23', '무슨 일을 하든지 주께 하듯 하라'),
               ('60:4:10', '받은 은사대로 서로 봉사하라')],
    'TS_M10': [('43:14:2-3', '내 아버지 집에 거할 곳이 많도다'),
               ('52:4:16-17', '주께서 강림하시고 우리가 항상 주와 함께'),
               ('66:21:4', '다시 사망이 없고 애통하는 것이 없으리니'),
               ('50:3:20', '우리의 시민권은 하늘에 있다'),
               ('46:15:51-52', '마지막 나팔에 순식간에 변화되리니')],
}

DDL = [
    """CREATE TABLE IF NOT EXISTS sys_verse_topic(
        topic_key TEXT PRIMARY KEY, grp TEXT NOT NULL, sort_order INTEGER DEFAULT 0,
        names TEXT DEFAULT '{}', record_status TEXT DEFAULT 'LIVE')""",
]
USER_DDL = [
    """CREATE TABLE IF NOT EXISTS userdb.user_verse_topic(
        topic_key TEXT PRIMARY KEY, grp TEXT DEFAULT '', name TEXT DEFAULT '', sort_order INTEGER DEFAULT 0,
        state TEXT DEFAULT 'LIVE', updated_at TEXT)""",
    """CREATE TABLE IF NOT EXISTS userdb.user_verse_topic_item(
        item_id INTEGER PRIMARY KEY AUTOINCREMENT, topic_key TEXT NOT NULL, ref TEXT DEFAULT '', note TEXT DEFAULT '',
        sort_order INTEGER DEFAULT 0, state TEXT DEFAULT 'LIVE', sys_cv_id INTEGER, created_at TEXT)""",
]


def _now():
    return time.strftime('%Y-%m-%d %H:%M:%S')


def _has_userdb(conn):
    try:
        return any(r[1] == 'userdb' for r in conn.execute('PRAGMA database_list'))
    except Exception:
        return False


def ensure(conn):
    for d in DDL:
        conn.execute(d)
    CV.init(conn)
    pre = '' if not _has_userdb(conn) else None
    for d in USER_DDL:
        conn.execute(d if pre is None else d.replace('userdb.', ''))


def _ut(conn, t):
    """개인 표 이름 — userdb 가 붙어 있으면 그쪽(시험 DB 는 한 파일)."""
    return ('userdb.' + t) if _has_userdb(conn) else t


def seed(conn, force=False):
    """주제 목록과 새 주제의 구절을 심는다 — 이미 있는 주제·구절은 안 덮는다(관리자가 고친 것) · force 면 갈아 끼움."""
    ensure(conn)
    n_t = n_v = 0
    for i, (k, g, ko, en) in enumerate(TOPICS):
        names = json.dumps({'KO': ko, 'EN': en}, ensure_ascii=False)
        if force:
            conn.execute('INSERT OR REPLACE INTO sys_verse_topic(topic_key,grp,sort_order,names) VALUES(?,?,?,?)',
                         (k, g, (i + 1) * 10, names))
            n_t += 1
        else:
            cur = conn.execute('INSERT OR IGNORE INTO sys_verse_topic(topic_key,grp,sort_order,names) VALUES(?,?,?,?)',
                               (k, g, (i + 1) * 10, names))
            n_t += cur.rowcount
    for sub, rows in SEED.items():
        have = conn.execute('SELECT COUNT(*) FROM sys_card_verse WHERE sub_key=?', (sub,)).fetchone()[0]
        if have and not force:
            continue
        if have:
            conn.execute('DELETE FROM sys_card_verse_text WHERE cv_id IN (SELECT cv_id FROM sys_card_verse WHERE sub_key=?)', (sub,))
            conn.execute('DELETE FROM sys_card_verse WHERE sub_key=?', (sub,))
        for j, (ref, note) in enumerate(rows):
            if not CV.parse(ref):
                raise ValueError('좌표 꼴: %s' % ref)
            cur = conn.execute('INSERT INTO sys_card_verse(sub_key, sort_order, ref) VALUES(?,?,?)', (sub, (j + 1) * 10, ref))
            conn.execute("INSERT INTO sys_card_verse_text(cv_id, lang_code, note) VALUES(?, 'KO', ?)", (cur.lastrowid, note))
            n_v += 1
    conn.commit()
    return n_t, n_v


def _name(names, lang):
    try:
        d = json.loads(names or '{}')
    except Exception:
        d = {}
    for k in (lang.upper(), 'EN', 'KO'):
        if (d.get(k) or '').strip():
            return d[k].strip()
    return ''


# ── 읽기(앱 + 덮개) ──────────────────────────────────────────────────
def topics(conn, lang='KO', grp=None, with_hidden=False):
    """주제 목록 → [{key, grp, name, mine(사용자가 만든 것), hidden, renamed}] · 차례 = 앱 차례 → 사용자 주제(만든 차례)."""
    ensure(conn)
    ut = _ut(conn, 'user_verse_topic')
    over = {r[0]: r for r in conn.execute('SELECT topic_key, grp, name, sort_order, state FROM %s' % ut)}
    out = []
    for k, g, so, names in conn.execute("SELECT topic_key, grp, sort_order, names FROM sys_verse_topic"
                                        " WHERE COALESCE(record_status,'LIVE')='LIVE' ORDER BY sort_order, topic_key"):
        o = over.get(k)
        hidden = bool(o and o[4] == 'HIDE')
        if hidden and not with_hidden:
            continue
        nm = (o[2] or '').strip() if o else ''
        out.append({'key': k, 'grp': g, 'name': nm or _name(names, lang), 'mine': False, 'hidden': hidden,
                    'renamed': bool(nm)})
    for k, o in sorted(over.items(), key=lambda kv: (kv[1][3] or 0, kv[0])):
        if not k.startswith('U') or (o[4] == 'HIDE' and not with_hidden):
            continue
        out.append({'key': k, 'grp': o[1] or 'MEMO', 'name': o[2] or k, 'mine': True, 'hidden': o[4] == 'HIDE',
                    'renamed': False})
    if grp:
        out = [t for t in out if t['grp'] == grp]
    return out


def verses(conn, key, lang='KO'):
    """그 주제의 구절 → [{id, ref, note, mine}] · id = 'S<cv_id>'(앱) / 'U<item_id>'(사용자) · 앱 구절 → 사용자 구절."""
    ensure(conn)
    it = _ut(conn, 'user_verse_topic_item')
    hid = {r[0] for r in conn.execute("SELECT sys_cv_id FROM %s WHERE topic_key=? AND state='HIDE' AND sys_cv_id IS NOT NULL" % it,
                                      (key,))}
    out = [{'id': 'S%d' % cv, 'ref': ref, 'note': note, 'mine': False}
           for cv, ref, note in CV.rows(conn, key, lang) if cv not in hid]
    for iid, ref, note in conn.execute("SELECT item_id, ref, note FROM %s WHERE topic_key=? AND state='LIVE'"
                                       " AND sys_cv_id IS NULL ORDER BY sort_order, item_id" % it, (key,)):
        out.append({'id': 'U%d' % iid, 'ref': ref, 'note': note or '', 'mine': True})
    return out


# ── 사용자 고치기(개인 DB 만) ────────────────────────────────────────
def add_topic(conn, name, grp='MEMO', key=None, commit=True):
    ensure(conn)
    k = key if (key or '').startswith('U') else 'U' + secrets.token_hex(4)
    if conn.execute('SELECT 1 FROM %s WHERE topic_key=?' % _ut(conn, 'user_verse_topic'), (k,)).fetchone():
        return k                                          # 폰이 지은 열쇠로 두 번 와도 한 줄
    ut = _ut(conn, 'user_verse_topic')
    mx = conn.execute('SELECT COALESCE(MAX(sort_order),0) FROM %s' % ut).fetchone()[0]
    conn.execute('INSERT INTO %s(topic_key,grp,name,sort_order,state,updated_at) VALUES(?,?,?,?,?,?)' % ut,
                 (k, grp if grp in GROUP_KEYS else 'MEMO', (name or '').strip() or '새 주제', mx + 10, 'LIVE', _now()))
    if commit:
        conn.commit()
    return k


def rename_topic(conn, key, name, grp='', commit=True):
    """앱 주제면 덮개 줄(이름) · 사용자 주제면 그 줄 · 빈 이름 = 앱 이름으로 되돌림."""
    ensure(conn)
    ut = _ut(conn, 'user_verse_topic')
    r = conn.execute('SELECT state, grp FROM %s WHERE topic_key=?' % ut, (key,)).fetchone()
    if r:
        conn.execute('UPDATE %s SET name=?, updated_at=? WHERE topic_key=?' % ut, ((name or '').strip(), _now(), key))
    else:
        conn.execute('INSERT INTO %s(topic_key,grp,name,state,updated_at) VALUES(?,?,?,?,?)' % ut,
                     (key, grp, (name or '').strip(), 'LIVE', _now()))
    if commit:
        conn.commit()


def hide_topic(conn, key, on=True, commit=True):
    """「지우기」 = 가림(앱 주제는 덮개 · 사용자 주제는 그 줄) · on=False 면 되살림."""
    ensure(conn)
    ut = _ut(conn, 'user_verse_topic')
    st = 'HIDE' if on else 'LIVE'
    if conn.execute('SELECT 1 FROM %s WHERE topic_key=?' % ut, (key,)).fetchone():
        conn.execute('UPDATE %s SET state=?, updated_at=? WHERE topic_key=?' % ut, (st, _now(), key))
    else:
        conn.execute('INSERT INTO %s(topic_key,state,updated_at) VALUES(?,?,?)' % ut, (key, st, _now()))
    if commit:
        conn.commit()


def add_verse(conn, key, ref, note='', commit=True):
    if not CV.parse(ref):
        raise ValueError('구절 좌표 꼴이 틀렸습니다: %s' % ref)
    ensure(conn)
    it = _ut(conn, 'user_verse_topic_item')
    if any(v['ref'] == ref for v in verses(conn, key)):
        return None                                      # 같은 구절은 한 번만
    mx = conn.execute('SELECT COALESCE(MAX(sort_order),0) FROM %s WHERE topic_key=?' % it, (key,)).fetchone()[0]
    cur = conn.execute('INSERT INTO %s(topic_key,ref,note,sort_order,state,created_at) VALUES(?,?,?,?,?,?)' % it,
                       (key, ref, (note or '').strip(), mx + 10, 'LIVE', _now()))
    if commit:
        conn.commit()
    return cur.lastrowid


def remove_verse(conn, key, vid=None, ref=None, commit=True):
    """빼기 — vid('S<cv_id>' 앱 구절 → 가림 줄 · 'U<item_id>' 사용자 구절 → HIDE) 또는 ref(좌표 · 폰이 보낸 것)."""
    ensure(conn)
    it = _ut(conn, 'user_verse_topic_item')
    if not vid and ref:
        vid = next((v['id'] for v in verses(conn, key) if v['ref'] == ref), None)
    if not vid:
        return False
    if vid.startswith('S'):
        conn.execute('INSERT INTO %s(topic_key,state,sys_cv_id,created_at) VALUES(?,?,?,?)' % it,
                     (key, 'HIDE', int(vid[1:]), _now()))
    else:
        conn.execute("UPDATE %s SET state='HIDE' WHERE item_id=?" % it, (int(vid[1:]),))
    if commit:
        conn.commit()
    return True


def apply_event(conn, d):
    """폰이 보낸 고치기 하나(보낼 함 VERSE_TOPIC) → 결과 글자 · 커밋은 부르는 쪽(mobile_sync).
    op = ADD_TOPIC(key·name·grp) · RENAME(key·name) · HIDE / UNHIDE(key) · ADD_VERSE(key·ref·note) · DEL_VERSE(key·ref) · RESTORE(key)."""
    op, key = (d.get('op') or '').upper(), d.get('key') or ''
    if not key:
        return 'NOKEY'
    if op == 'ADD_TOPIC':
        return 'TOPIC:' + add_topic(conn, d.get('name') or '', d.get('grp') or 'MEMO', key=key, commit=False)
    if op == 'RENAME':
        rename_topic(conn, key, d.get('name') or '', commit=False)
    elif op in ('HIDE', 'UNHIDE'):
        hide_topic(conn, key, op == 'HIDE', commit=False)
    elif op == 'ADD_VERSE':
        try:
            return 'ADD:%s' % (add_verse(conn, key, d.get('ref') or '', d.get('note') or '', commit=False) or 'SAME')
        except ValueError:
            return 'BADREF'
    elif op == 'DEL_VERSE':
        return 'DEL:%s' % ('OK' if remove_verse(conn, key, ref=d.get('ref'), commit=False) else 'NONE')
    elif op == 'RESTORE':
        restore_verses(conn, key, commit=False)
    else:
        return 'BADOP'
    return op


def restore_verses(conn, key, commit=True):
    """그 주제에서 가린 앱 구절을 되살린다."""
    ensure(conn)
    conn.execute("DELETE FROM %s WHERE topic_key=? AND sys_cv_id IS NOT NULL" % _ut(conn, 'user_verse_topic_item'), (key,))
    if commit:
        conn.commit()


def share_text(conn, rows, title='', version='KRV'):
    """고른 구절을 글로 — 「약명 장:절」 + 본문 · 맨 위 주제 이름(말씀카드 없이 글만)."""
    out = [title] if title else []
    for ref in rows:
        b = re.sub(r'\{[^}]*\}\s*', '', CV.body(conn, ref, version) or '').strip()   # 시편 표제({…})는 뺀다
        out.append('%s\n%s' % (CV.label(conn, ref), b))
    return '\n\n'.join(out).strip()


# ── 자가 검증 ────────────────────────────────────────────────────────
def selftest():
    import sqlite3
    ok, bad = [0], [0]

    def ck(c, m, got=''):
        (ok if c else bad)[0] += 1
        print('  %s %s%s' % ('OK  ' if c else 'FAIL', m, '' if c else '  ← %s' % (got,)))
    c = sqlite3.connect(':memory:')
    ensure(c)
    nt, nv = seed(c)
    ck(nt == len(TOPICS), '주제 심기', nt)
    ck(nv == sum(len(v) for v in SEED.values()), '새 주제 구절 심기', nv)
    ck(seed(c) == (0, 0), '두 번 심어도 안 늘어남(멱등)')
    ck(all(CV.parse(r) for rows in SEED.values() for r, _n in rows), '좌표 꼴 전부 맞음')
    ck(set(SEED) <= {k for k, *_ in TOPICS}, '씨앗 구절의 주제가 목록에 있다')
    ck({g for _k, g, *_ in TOPICS} <= set(GROUP_KEYS), '큰 갈래 넷 안')
    keys = [t['key'] for t in topics(c)]
    ck(keys[:2] == ['CC_1', 'CC_2'], '차례 = 표 차례', keys[:3])
    ck(topics(c, 'EN', 'CHURCH')[1]['name'] == "Lord's Supper", '이름 언어마다')
    k = add_topic(c, '이번 달 암송')
    ck(any(t['key'] == k and t['mine'] and t['grp'] == 'MEMO' for t in topics(c)), '사용자 주제 = 암송 갈래')
    ck(add_verse(c, k, '43:3:16', '복음의 요약') and len(verses(c, k)) == 1, '사용자 구절 더하기')
    ck(add_verse(c, k, '43:3:16') is None, '같은 구절은 한 번만')
    v0 = verses(c, 'TS_LORD')
    remove_verse(c, 'TS_LORD', v0[0]['id'])
    ck(len(verses(c, 'TS_LORD')) == len(v0) - 1, '앱 구절 가리기')
    ck(c.execute('SELECT COUNT(*) FROM sys_card_verse WHERE sub_key=?', ('TS_LORD',)).fetchone()[0] == len(v0),
       '앱 자료는 그대로(가림 줄만)')
    restore_verses(c, 'TS_LORD')
    ck(len(verses(c, 'TS_LORD')) == len(v0), '가린 구절 되살리기')
    rename_topic(c, 'CC_1', '생일 축하')
    ck(next(t for t in topics(c) if t['key'] == 'CC_1')['name'] == '생일 축하', '앱 주제 이름 바꾸기(덮개)')
    hide_topic(c, 'CC_1')
    ck(all(t['key'] != 'CC_1' for t in topics(c)), '앱 주제 가리기')
    ck(any(t['key'] == 'CC_1' and t['hidden'] for t in topics(c, with_hidden=True)), '가린 것도 목록에서 찾는다')
    hide_topic(c, 'CC_1', False)
    ck(any(t['key'] == 'CC_1' for t in topics(c)), '되살리기')
    ck(apply_event(c, {'op': 'ADD_TOPIC', 'key': 'Uphone01', 'name': '아이 암송'}) == 'TOPIC:Uphone01', '폰 열쇠 그대로')
    ck(apply_event(c, {'op': 'ADD_TOPIC', 'key': 'Uphone01', 'name': '아이 암송'}) == 'TOPIC:Uphone01' and
       sum(1 for t in topics(c) if t['key'] == 'Uphone01') == 1, '두 번 와도 한 줄')
    apply_event(c, {'op': 'ADD_VERSE', 'key': 'Uphone01', 'ref': '19:23:1'})
    ck([v['ref'] for v in verses(c, 'Uphone01')] == ['19:23:1'], '폰 구절 더하기')
    r0 = verses(c, 'TS_PENTE')[0]['ref']
    ck(apply_event(c, {'op': 'DEL_VERSE', 'key': 'TS_PENTE', 'ref': r0}) == 'DEL:OK' and
       all(v['ref'] != r0 for v in verses(c, 'TS_PENTE')), '폰 빼기 = 좌표로(앱 구절)')
    ck(apply_event(c, {'op': 'ADD_VERSE', 'key': 'X', 'ref': 'bad'}) == 'BADREF', '틀린 좌표는 안 담는다')
    print('\ndb_verse_topic selftest %d/%d' % (ok[0], ok[0] + bad[0]))
    return bad[0] == 0


def main(argv):
    if '--selftest' in argv:
        return 0 if selftest() else 1
    import appdb
    c = appdb.connect()
    if '--seed' in argv:
        print('주제 %d · 구절 %d 심음' % seed(c, force='--force' in argv))
    if '--list' in argv:
        for g, ko, _en in GROUPS:
            print('[%s]' % ko)
            for t in topics(c, 'KO', g):
                print('   %s %s (%d)' % (t['key'], t['name'], len(verses(c, t['key']))))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
