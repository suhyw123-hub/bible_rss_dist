# refr_unified_panel.py
"""
Internal 탭 — 구절 연결 자료 + 사용자 내자료

상단: 연결 자료 (설교집/도서/교리자료) — 클릭 시 P1 탭 이동
하단: 내 자료 (user_ref_asset) — 좌(목록)+우(폼) 분할, 유형 콤보 필터

공개 API:
  load(verse_id) — 구절 변경 시 외부에서 호출
"""
import i18n
import sqlite3
# ★★ 구간 판정은 **한 문**이다(§verse_range) — `verse_id` 는 신원이고
#   차례는 `sort_order` 다. 번호로 재면 아6:1~6:14 가 13,488절을 먹는다.
import verse_range as _vr
import book_link as _BL             # 도서 편이 어느 절에 걸리나(원본마다)
import appdb
import verse_ref
import link_picker                         # 자산 연결 (§자산간 연결)
import tkinter as tk
from tkinter import ttk, messagebox

def _flat(**over):
    """My Edit·Recent 류 **테두리 없는 단추** — 모양의 단일 소스는 `ui_theme`.

    ⚠ 화면마다 손으로 적으면 갈라진다(실측 7곳이 bd·padx·글꼴이 제각각이었다 —
      2026-08-30 사용자 지시 「My Edit 버튼의 디자인을 통일하라. Recent 버튼과
      동일하게」).
    """
    try:
        import ui_theme
        return ui_theme.flat_btn(**over)
    except Exception:
        return dict(bd=1, padx=6, pady=2, cursor='hand2', **over)




def _ref_lang():
    """구절약명에 쓸 언어 — **성경 역본**을 따른다(표시언어 콤보가 아니다).

    2026-08-15 사용자 지시: 「구절약명은 버전을 바꿀 때에만 바뀌어야 한다」.
    ⚠ `book_names` 에 EL·HE·COP 가 없어 원문 역본(GNT·WLC·COP*)은 **영어**로 떨어진다.
    """
    try:
        import lang_config
        return lang_config.ref_lang()
    except Exception:
        return 'EN'

def _src_word(ntype):
    """출처 종류를 사용자 언어의 짧은 단어로 (암호 약자 금지, 런타임 i18n)."""
    return {
        'SERMON': i18n.t('REFR_SRC_SERMON', '설교'),
        'BOOK':   i18n.t('REFR_SRC_BOOK', '도서'),
        'REF':    i18n.t('REFR_SRC_DOCTRINE', '교리자료'),
    }.get(ntype, ntype)

_SRC_ABBR = {
    'HEIDELBERG':     'HC',
    'WESTMINSTER_SC': 'WSC',
    'LUTHER_SC':      'LC',
    'TORREY_WBT':     'Torrey',
    'EASTON_DICT':    'Easton',
    'SMITH_DICT':     'Smith',
    'MEYER_BC':       'Meyer',
    'EDERSHEIM_LT':   'Edersheim',
    'EDERSHEIM_TMP':  'Edersheim',
    'EDERSHEIM_JSL':  'Edersheim',
}

# ★ 2026-10-16 (docs/1.txt 2-2) — 유형은 내용 셋뿐(연구·설교·참고자료) · 옛 유형은 `ref_kinds.normalize` 가 접는다
_REF_TYPE_LABELS = {'STUDY': '연구', 'SERMON': '설교', 'REFERENCE': '참고자료'}
_OLD_REF_TYPE_LABELS = {
    'NOTE':       '노트',
    'ARTICLE':    '기사',
    'BLOG':       '블로그',
    'WEB':        '웹 글',        # 2026-10-11 — 확장 프로그램·북마크로 저장한 웹 쪽(제목·주소만)
    'YOUTUBE':    'YouTube',
    'BOOK':       '도서',
    'SERMON':     '설교',
    'COMMENTARY': '주석',
    'STUDY':      '연구',
    'AI':         'AI 대화',      # 298차 — AI 도우미에서 합쳐 담은 글(사람 글과 가른다)
    'OTHER':      '기타',
}
_REF_TYPES = list(_REF_TYPE_LABELS.keys())


def _reftype_label(k):
    """유형 코드 → 표시 라벨 — `ref_kinds` 한 문(옛 유형도 셋 가운데 하나로)."""
    try:
        import ref_kinds
        return ref_kinds.kind_label(k)
    except Exception:                                       # noqa: BLE001
        return i18n.t('REFRT_' + str(k), _REF_TYPE_LABELS.get(k, k))


# ── 내부 연결(앱 안 다른 화면으로 이어지는 줄) ────────────────────────
# ▸ 를 앞에 붙여 "이 줄을 누르면 다른 화면이 열린다"를 표시한다.
# 컬러 이모지 금지(CLAUDE.md §29) — 단색 기하기호만 쓴다.
_NAV_MARK = '▸'

# ⚠ `sys_ref_unit` 한 표에 교리문답·주제색인·사전·우리가 쓴 연구 글이 **함께** 들어 있다.
#   전부 '교리자료' 라 부르면 연구 글도 교리자료가 된다(2026-08-03 실제로 그랬다).
#   그래서 표시 이름은 `sys_ref_source.src_type` 에서 끌어온다.
_SRCTYPE_KIND = {
    'CATECHISM':      ('CATECHISM', 'REFR_KIND_QA',    '문답'),
    'TOPICAL':        ('TOPICAL',   'REFR_KIND_TOPIC', '주제'),
    'STUDY':          ('STUDY',     'REFR_KIND_STUDY', '연구'),
    'DICTIONARY':     ('DICT',      'REFR_KIND_DICT',  '사전'),
}
_SRCTYPE_ETC = ('REFETC', 'REFR_KIND_ETC', '자료')

# (표시코드, i18n키, KO폴백) — 목록·필터 콤보가 함께 쓴다
_NAV_KIND_DEFS = (
    ('SERMON', 'REFR_SRC_SERMON', '설교'),
    ('BOOK',   'REFR_SRC_BOOK',   '도서'),
) + tuple(_SRCTYPE_KIND.values()) + (_SRCTYPE_ETC,)
_NAV_KINDS = tuple(d[0] for d in _NAV_KIND_DEFS)
_NAV_KIND_I18N = {d[0]: (d[1], d[2]) for d in _NAV_KIND_DEFS}


def _kind_of_srctype(src_type):
    """자료집 종류(src_type) → 목록에 쓸 표시 코드."""
    return _SRCTYPE_KIND.get((src_type or '').upper(), _SRCTYPE_ETC)[0]


def _navkind_label(k):
    """내부 연결 종류 → ▸ 가 붙은 표시 라벨."""
    key, ko = _NAV_KIND_I18N.get(k, ('REFR_SRC_' + str(k), str(k)))
    return _NAV_MARK + i18n.t(key, ko)


# ── 갈래 (2026-08-08) ────────────────────────────────────────────────
# 한 목록에 다 섞여 있으면 "이 글이 어디에 걸려 있나"를 볼 수가 없다.
# 위쪽 버튼 둘로 먼저 가른 뒤, 기존 유형 콤보가 그 안에서 다시 거른다.
#   MINE — 우리가 쓴 연구 글(src_type='STUDY') + 내 자료(user_ref_asset)
#   NAV  — 그 밖의 것(설교·도서·문답·주제·사전). 앱 안 다른 화면으로 이어진다
SCOPE_MINE, SCOPE_NAV = 'MINE', 'NAV'
_MINE_KIND = 'STUDY'          # _SRCTYPE_KIND['STUDY'] 의 표시 코드


def _ref_label(conn, sv, ev, lang='KO'):
    """verse_id 범위 → 사람이 읽는 약명. p4_ref_view._ref_label 과 같은 방식."""
    r = conn.execute(
        "SELECT COALESCE(bn.short_name, bn2.short_name, bi.bcode), bi.chapter, bi.verse "
        "FROM bible_index bi "
        "LEFT JOIN book_names bn  ON bn.book_code=bi.bcode AND UPPER(bn.lang_code)=? "
        "LEFT JOIN book_names bn2 ON bn2.book_code=bi.bcode AND bn2.lang_code='EN' "
        "WHERE bi.verse_id=?", (_ref_lang(), sv)).fetchone()
    if not r:
        return str(sv)
    e = None
    if ev and ev != sv:
        e = conn.execute("SELECT chapter, verse FROM bible_index WHERE verse_id=?",
                         (ev,)).fetchone()
    # ★ 형식은 `verse_ref` 가 정한다 — 전에는 여기만 붙임표(`-`)를 썼다
    return verse_ref.range_label(r[0], r[1], r[2],
                                 e[0] if e else None, e[1] if e else None)


class RefUnifiedPanel(ttk.Frame):

    def __init__(self, parent, db_path,
                 on_sermon_select=None,    # 설교/도서 unit_id → P1 jump_to_unit
                 on_doctrine_select=None,  # 수입 문답·사전 ref_unit_id → P1 jump_to_doctrine_unit
                 on_article_open=None,     # 우리가 쓴 연구 글 ref_unit_id → P4 자료 탭
                 on_user_open=None,        # 내 자료 ref_id            → P4 자료 탭
                 on_user_new=None,         # 새로 쓰기(verse_id)        → P4 자료 탭
                 external_scope=False,     # 갈래 단추를 밖(branch_tabs)이 맡는다 (2026-08-19 3갈래)
                 ext_bar=None,             # 언어콤보·My Edit 을 심을 **밖의 줄** (2026-08-30)
                 **kwargs):
        """`ext_bar` — 주면 **언어콤보·[My Edit] 을 그 줄에** 심는다
        (2026-08-30 사용자 지시 0.txt 1-1 「언어콤보 / My Edit 버튼 배치장소
        변경 : **내부연결 버튼과 M 버튼 사이에 배치**하라. 현재의 언어콤보
        배치된 공간을 제거하라」).

        ⚠⚠ 그전에는 이 패널 안에 **위젯 둘뿐인 28px 짜리 줄**이 따로 있었고,
          바로 위 갈래 줄은 **250px 가 비어 있었다**(실측). 줄 하나를 통째로
          목록에 돌려준다.
        ⚠ 자리를 잡는 규칙은 `desc_comm_group` 과 같다 — 밖의 줄은 [M] 자리를
          미리 못 박아 두었으므로 여기서는 그냥 `side='right'` 로 붙이면
          **M 왼쪽**에 놓인다."""
        super().__init__(parent, **kwargs)
        self._db = db_path
        self._external_scope = bool(external_scope)
        self._ext_bar = ext_bar
        self._on_unit_select    = on_sermon_select
        self._on_doctrine_select = on_doctrine_select
        self._on_article_open   = on_article_open
        self._on_user_open      = on_user_open
        self._on_user_new       = on_user_new
        self._verse_id  = None
        self._peri_ids  = []
        self._nav_rows  = []
        self._user_rows = []
        self._scope     = SCOPE_MINE
        self._ref_cache = {}      # (갈래키, id) → [(start_vid, end_vid), …]
        self._build()

    # ── UI 구성 ────────────────────────────────────────────────────

    def _build(self):
        # ─ 상단: 헤더 + 필터 ─────────────────────────────────────
        # ★ 2026-08-03 통합 — 예전에는 '연결 자료'(도서·설교·문답) 트리가 위에,
        #   '내 자료' 목록이 아래에 따로 있었다. 신약 1,500절 실측 결과
        #   **65%의 구절이 연결 자료 0건**(평균 0.69건)이라, 둘로 나눠 두면
        #   대부분의 구절에서 빈 칸 하나를 늘 보게 된다. 그래서 한 목록으로 합치고
        #   대신 **유형 칸의 ▸ 표시**로 "앱 안 다른 화면으로 이어지는 줄"임을 알린다.
        # ⚠ 제목 줄(「내부자료 (0)건」)을 없앴다(2026-08-10 사용자 지시). 탭 이름이 이미
        #   「내부자료」라 같은 말을 두 번 하고 있었고, 건수는 갈래 버튼이 각자 달고 있다.
        #   버튼은 아래 갈래 버튼 줄로 내렸다.
        self._user_count = ttk.Label(self, text='')      # 옛 호출부 호환(안 그린다)

        # ─ 갈래 버튼 (버튼은 항상 상단 — CLAUDE.md §0) ────────────
        # ★ 밖의 줄을 받았으면 **여기에 줄을 만들지 않는다** — 빈 28px 를
        #   남기면 목록이 그만큼 줄어든다(2026-08-30).
        if self._ext_bar is not None:
            scope_bar = self._ext_bar
        else:
            scope_bar = ttk.Frame(self)
            scope_bar.pack(fill='x', padx=4, pady=(4, 2))
        self._scope_btns = {}
        # ★ 2026-08-19 3갈래 개편 — 자료·노트 탭이 [묵상노트/연구자료/내부연결]
        #   갈래 단추(branch_tabs)를 갖게 되면서, 이 안쪽 갈래 버튼은 밖이
        #   맡는다(external_scope=True — 같은 패널 하나가 갈래에 따라 scope 만
        #   바꾼다). 유형·언어 콤보와 [+ 추가하기]는 이 줄에 그대로 남는다
        #   (「서브탭 아래에 유형콤보·언어콤보·추가하기」 — 사용자 지시).
        if not self._external_scope:
            for code, key, ko in ((SCOPE_MINE, 'REFR_SCOPE_MINE', '연구자료'),
                                  (SCOPE_NAV,  'REFR_SCOPE_NAV',  '내부연결')):
                b = tk.Button(scope_bar, text=i18n.t(key, ko),
                              font=('Malgun Gothic', 8, 'bold'), bd=1, padx=8, pady=2,
                              command=lambda c=code: self._set_scope(c))
                b.pack(side='left', padx=(0, 4))
                self._scope_btns[code] = b
        # ⚠ 이 버튼은 **작성자료 갈래에서만** 보인다(2026-08-10 사용자 지시).
        #   내부연결은 이미 있는 도서·설교·연구 글로 가는 길이라 새로 쓸 것이 없다.
        # ★★ **[+ 추가하기] → [My Edit]** (2026-08-30 사용자 지시 — P2 다섯
        #   자리 통합. 0.txt 2)P2 「처음부터 p2에 배치한 +추가하기 버튼을
        #   유지해야 하는가 아니면 My Edit 버튼으로 통합하면서 팝업 화면에서
        #   입력하도록 해야 하는가?」).
        #   ⇒ **통합.** 그전에는 같은 일에 화면이 둘이었다 — [+ 추가하기]는
        #     **P4 로 이동**시키고 My Edit 은 **팝업 안에서** 입력받았다.
        #   ★ **두 갈래 모두에서 보인다** — 「내부연결」에서도 이 구절에 자료를
        #     더 이을 수 있어야 한다(사용자 물음 「내부연결 탭: My Edit 버튼을
        #     배치해야 하는가?」의 답).
        # ★★★ **밖의 줄을 받았으면 [My Edit] 을 여기서 만들지 않는다**
        #   (2026-08-30 사용자 확정 — 「자료/노트 탭 아래의 **서브탭 3개에 모두
        #   My Edit 가 적용**된다면 …」). 그 단추는 **세 갈래가 함께 쓰는 것**이라
        #   갈래 하나(연구자료)의 패널이 가질 것이 아니다 — 호스트가 만들고
        #   지금 갈래에 맞는 출발지로 연다.
        #   ⚠ 밖의 줄이 없는 자리(NodePanel)는 종전대로 제가 만든다.
        self._add_btn = None
        if self._ext_bar is None:
            self._add_btn = tk.Button(scope_bar,
                                      text=i18n.t('OE_BTN', 'My Edit'),
                                      command=self._start_new, **_flat())
        # ★ **표시 언어 — 갈래 버튼 오른쪽에 한 뼘 띄워** (2026-08-14 사용자 지시
        #   「언어콤보는 두가지 버튼 모두 적용되도록 하라. 즉, 내부연결 버튼 오른쪽에
        #    여백을 두고 배치하라」).
        #   ⚠ 이 화면에는 언어 콤보가 **아예 없었다.** 목록 제목이 앱 언어에 묶여
        #     있어서, 영어로 읽는 사람이 한국어 제목 목록을 보고 있었다.
        #   작성자료·내부연결 **두 갈래 모두**에 걸린다(`_query_user`·`_query_nav`).
        import lang_combo
        self._lang = lang_combo.LangCombo(
            scope_bar, db_path=self._db,
            on_change=lambda _c: self._reload(),
            # ⚠ 밖의 줄(P2 갈래 줄)에서는 한 칸 좁게 — 열한 언어 이름이 다 9자
            #   안이고(Português) 그 줄은 예산이 빠듯하다(2026-09-15 실측).
            width=(10 if self._ext_bar is not None else 13),   # 2026-09-16 한 칸 더(P2 윗줄 예산)
            gap=lang_combo.GAP, pady=0,
            side=('right' if self._ext_bar is not None else 'left'),
            default_lang=(i18n.get_lang() or 'KO').upper(),
            key='LANGSEL_REFR')
        self._lang.set_items(lang_combo.lang_items())

        # ─ 연결된 구절 띠 ─────────────────────────────────────────
        # ★ **목록 아래에 둔다** (2026-08-14 사용자 지적 「아직 목록을 클릭하지도
        #   않았는데 위에서 표시되는 것은 부적절하다」). 이것은 **고른 줄에 딸린 것**이라
        #   목록보다 위에 있으면 무엇에 대한 설명인지 알 수 없다.
        #   ⚠ `pack` 은 부른 차례로 자리를 잡는다 — `side='bottom'` 으로 **먼저** 잡아
        #     두어야 그 뒤에 오는 목록이 남은 자리를 채운다.
        # ⚠ 용어 줄이 함께 들어오므로 두 줄로는 잘린다 (2026-08-14).
        self._verse_strip = tk.Text(self, height=3, wrap='word', bd=1, relief='solid',
                                    bg='#F4F8FB', fg='#1A5276', state='disabled',
                                    font=('Malgun Gothic', 8), cursor='arrow')
        self._verse_strip.pack(side='bottom', fill='x', padx=4, pady=(2, 4))

        # ★ 유형 콤보 폐지 (2026-08-19 사용자 — 「구절과 연결된 갯수가 많지
        #   않다」). 언어콤보 + [+ 추가하기]만 남아 **한 줄** 구성이 된다.
        #   _type_var 는 필터 로직 호환용으로 「전체」 고정값만 남긴다.
        self._type_var = tk.StringVar(value=i18n.t('COMMON_ALL','전체'))
        self._type_cb = None
        self._sync_type_values()

        # ─ 목록만 ────────────────────────────────────────────────
        # ★ **오른쪽 본문·폼 칸을 없앴다** (2026-08-14 사용자 지시
        #   「지금 목록 + 본문표시화면 ⇒ 수정후 목록만 표시」).
        #   ⚠ 읽기도 쓰기도 **P4 「연구자료」 탭이 자체 완결**한다(2026-08-10 사용자
        #     지시, CLAUDE.md §3 탭10). 여기 폼은 그때부터 아무도 안 쓰는 갈래길이었다
        #     — `_on_select`·`_start_new` 가 콜백이 있으면 곧장 `return` 한다.
        #   ⇒ 좁은 P2 패널에서 목록이 온전히 넓어진다.
        list_f = ttk.Frame(self)
        list_f.pack(fill='both', expand=True, padx=4, pady=(0, 2))
        # ★★★ **맨 왼쪽 「범위」 칸** (2026-08-30 사용자 확정) — 묶음(별도
        #   레코드) 대신 **줄마다 제 범위**를 적는다: `창1:20~23` · `창1장` ·
        #   `창세기`. 한 절짜리는 **빈 칸**(그것이 기본이다).
        cols = ('scope', 'type', 'title')
        # ★★ **`tree headings`** — 3단 묶음을 쓰기 위해 #0 칸을 연다
        #   (2026-08-30 사용자 지적 「자료/노트도 **단락/장/책 단위 연결
        #   이슈**가 있다」). ① 현황과 같은 문법이다.
        #   ⚠ 묶음이 없을 때는 #0 폭을 0 으로 접어 **지금과 똑같이** 보인다.
        tv = ttk.Treeview(list_f, columns=cols, show='headings',
                          selectmode='browse')
        tv.heading('scope', text=i18n.t('LP_C_SCOPE', '범위'))
        tv.column('scope', width=92, minwidth=60, stretch=False, anchor='w')
        tv.heading('type',  text=i18n.t('COMMON_TYPE','유형'))
        tv.heading('title', text=i18n.t('COMMON_TITLE','제목'))
        # ▸교리자료 = 5글자. 62px 로는 잘린다(2026-08-03 실측).
        tv.column('type',  width=78, minwidth=68, stretch=False, anchor='center')
        tv.column('title', width=220, minwidth=80)
        # 갈래별 색 폐기(2026-08-18 목록 표준 전수 정리) — 갈래는 「유형」
        #   칸(▸문답 등)이 이미 말한다. 항목은 기본색, 빈 줄만 회색.
        tv.tag_configure('empty',  foreground='#95A5A6')
        vsb = ttk.Scrollbar(list_f, orient='vertical', command=tv.yview)
        tv.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        tv.pack(fill='both', expand=True)
        tv.bind('<<TreeviewSelect>>', self._on_select)
        self._tv = tv

    def _lang_code(self):
        """이 화면의 표시 언어. 갈래 버튼 오른쪽 콤보가 정한다 (2026-08-14).

        ⚠ 예전에는 `i18n.get_lang()`(앱 언어)에 묶여 있었다 — 영어로 읽는 사람이
          한국어 제목 목록을 보고 있었다.
        """
        lc = getattr(self, '_lang', None)
        if lc is not None:
            return lc.lang()
        try:
            return (i18n.get_lang() or 'KO').upper()
        except Exception:
            return 'KO'

    # ── 외부 API ──────────────────────────────────────────────────

    def load(self, verse_id):
        self._verse_id = int(verse_id) if verse_id else None
        self._peri_ids = self._find_pericopes(self._verse_id)
        self._nav_rows  = self._query_nav()
        self._user_rows = self._query_user()
        self._ref_cache = {}
        # 고른 갈래가 비었고 다른 쪽에 자료가 있으면 그쪽으로 넘어간다.
        # 빈 칸만 보여 주고 "없다"고 오해하게 두지 않는다.
        # ⚠ **외부 갈래 모드에서는 절대 안 넘어간다** (2026-08-19 사용자 신고 —
        #   「연구자료 (0)에서 다른 구절을 클릭하면 내부연결 레코드가 나온다」.
        #   갈래 단추는 「연구자료」인 채 내용만 몰래 내부연결로 바뀌고 있었다.
        #   갈래의 단일 소스는 밖의 단추다 — 빈 갈래는 빈 채로 정직하게 보인다).
        if not self._external_scope and not self._rows_of(self._scope):
            other = SCOPE_NAV if self._scope == SCOPE_MINE else SCOPE_MINE
            if self._rows_of(other):
                self._scope = other
        self._sync_type_values()
        self._apply_filter()

    def _reload(self):
        """언어가 바뀌면 **다시 읽는다.**

        ⚠ `_apply_filter` 는 이미 읽어 둔 줄을 거를 뿐이라, 언어를 바꿔도 목록이
          꿈쩍하지 않았다(2026-08-14 사용자 지적). 언어는 **표기만이 아니라 내용에도**
          관여한다 — 그 언어로 없는 글은 목록에서 빠진다.
        """
        if self._verse_id:
            self.load(self._verse_id)

    # ── 갈래 ──────────────────────────────────────────────────────

    def _rows_of(self, scope):
        """그 갈래에 속한 줄만 (필터 이전의 전체)."""
        if scope == SCOPE_MINE:
            return ([r for r in self._nav_rows
                     if (r.get('kind') or r['nav_type']) == _MINE_KIND]
                    + list(self._user_rows))
        return [r for r in self._nav_rows
                if (r.get('kind') or r['nav_type']) != _MINE_KIND]

    def set_scope(self, scope):
        """밖(갈래 단추)에서 갈래를 정한다 — external_scope 모드의 진입점."""
        self._set_scope(scope)

    def branch_counts(self):
        """(연구자료 수, 내부연결 수) — 갈래 단추 배지용."""
        return (len(self._rows_of(SCOPE_MINE)), len(self._rows_of(SCOPE_NAV)))

    def _set_scope(self, scope):
        if scope == self._scope:
            return
        self._scope = scope
        self._type_var.set(i18n.t('COMMON_ALL', '전체'))
        self._sync_type_values()
        self._apply_filter()

    def _sync_type_values(self):
        """갈래 전환에 따른 버튼·추가하기 상태 (유형 콤보는 2026-08-19 폐지)."""
        allv = i18n.t('COMMON_ALL', '전체')
        if self._type_cb is not None:
            if self._scope == SCOPE_MINE:
                vals = [allv, _navkind_label(_MINE_KIND)] + [_reftype_label(k) for k in _REF_TYPES]
            else:
                vals = [allv] + [_navkind_label(k) for k in _NAV_KINDS if k != _MINE_KIND]
            self._type_cb.configure(values=vals)
            if self._type_var.get() not in vals:
                self._type_var.set(allv)
        else:
            self._type_var.set(allv)
        for code, b in self._scope_btns.items():
            on = (code == self._scope)
            b.configure(bg='#2E86C1' if on else '#ECF0F1',
                        fg='white' if on else '#566573',
                        relief='sunken' if on else 'raised')
        # ★ **두 갈래 모두에서 보인다** (2026-08-30) — 그전에는 「작성자료」
        #   에서만 떴다. My Edit 은 「새로 쓰기」가 아니라 **잇고 고치는 자리**라
        #   내부연결에서도 뜻이 있다.
        add = getattr(self, '_add_btn', None)
        if add is not None and not add.winfo_manager():
            add.pack(side='right')
        self._refresh_scope_labels()

    def _refresh_scope_labels(self):
        """버튼에 그 갈래의 자료 수를 달아 둔다 — 작성자료(3) 내부연결(2)."""
        for code, key, ko in ((SCOPE_MINE, 'REFR_SCOPE_MINE', '연구자료'),
                              (SCOPE_NAV,  'REFR_SCOPE_NAV',  '내부연결')):
            btn = self._scope_btns.get(code)
            if btn is not None:
                btn.configure(text=f'{i18n.t(key, ko)}({len(self._rows_of(code))})')

    # ── 연결된 구절 ───────────────────────────────────────────────

    def _refs_of(self, row):
        """한 줄이 걸려 있는 구절 범위 [(start_vid, end_vid), …]."""
        if 'ref_type' in row:                       # 내 자료
            key = ('U', row['id'])
        else:
            key = (row['nav_type'], row['id'])
        if key in self._ref_cache:
            return self._ref_cache[key]
        out = []
        try:
            with appdb.connect(self._db) as conn:
                if key[0] == 'REF':
                    out = [(r[0], r[1]) for r in conn.execute(
                        # ★ 2026-08-24 통합 표(`REFU_VERS`)
                        "SELECT target_id, end_id FROM sys_link_asset "
                        "WHERE link_type='REFU_VERS' AND clicked_id=? "
                        "  AND COALESCE(record_status,'LIVE')='LIVE' "
                        "ORDER BY sort_order, target_id", (row['id'],))]
                elif key[0] in ('SERMON', 'BOOK'):
                    out = [(r[0], r[1]) for r in conn.execute(
                        "SELECT " + _BL.anchor_sql('bu', 'ba') + " FROM sys_book_unit bu "
                        "JOIN sys_book_asset ba ON ba.book_id=bu.book_id "
                        "WHERE bu.unit_id=? AND bu.start_vid IS NOT NULL", (row['id'],))]
                else:                               # 내 자료
                    # ★ **연결 표를 읽는다** (2026-08-14 사용자 지적 「p2 연구자료에서
                    #   표시되지 않는다」).
                    #   ⚠ 여기는 옛 단일 칸(`user_ref_asset.verse_id`) 하나만 보고
                    #     있었다. 그래서 ① 구간(`end_id`)이 안 보이고 ② 여러 구절이
                    #     하나로 줄고 ③ **용어는 아예 안 보였다.**
                    out = [(r[0], r[1] or r[0]) for r in conn.execute(
                        # ★ 2026-08-24 통합 표(`UREF_VERS`)
                        "SELECT target_id, end_id FROM userdb.user_link_asset "
                        "WHERE clicked_id=? AND link_type='UREF_VERS' "
                        "  AND COALESCE(record_status,'LIVE')='LIVE' "
                        "ORDER BY sort_order, target_id", (row['id'],))]
                    out += [(r[0], r[1]) for r in conn.execute(
                        "SELECT p.start_vid, p.end_vid FROM userdb.user_link_asset l "
                        "JOIN sys_pericope_asset p ON p.pericope_id=l.target_id "
                        "WHERE l.clicked_id=? AND l.link_type='UREF_PERI' "
                        "  AND COALESCE(l.record_status,'LIVE')='LIVE'", (row['id'],))]
                    # ★ 새 연결 표(`user_link`) — 2026-08-21 이후 붙인 것은
                    #   전부 여기에 있다. 옛 표와 겹치면 접는다.
                    seen = set(out)
                    for s, e in conn.execute(link_picker.SQL_VERSES_OF_REF,
                                             (row['id'], row['id'])):
                        pair = (s, e or s)
                        if pair not in seen:
                            seen.add(pair)
                            out.append(pair)
                    if not out:                     # 연결 표로 옮기기 전의 옛 글
                        out = [(r[0], r[0]) for r in conn.execute(
                            "SELECT verse_id FROM user_ref_asset "
                            "WHERE ref_id=? AND verse_id IS NOT NULL", (row['id'],))]
        except Exception:
            out = []
        self._ref_cache[key] = out
        return out

    def _ents_of(self, row):
        """한 줄에 걸린 용어 이름 [str]. (2026-08-14 신설 — 띠에 함께 보인다)"""
        if 'ref_type' in row:
            # ★★ **뒤집힌 이름도 본다** (2026-08-27) — `link_picker` 는 정렬해서
            #   `ENTI_UREF` 로 쓰는데 여기가 `UREF_ENTI` 만 보고 있었다.
            #   실측 두 집합의 겹침 0 — 한쪽이 통째로 안 보였다.
            sql = ("SELECT l.target_id FROM userdb.user_link_asset l "
                   "WHERE l.clicked_id=? AND l.link_type='UREF_ENTI' "
                   "  AND COALESCE(l.record_status,'LIVE')='LIVE' "
                   "UNION "
                   "SELECT l.clicked_id FROM userdb.user_link_asset l "
                   "WHERE l.target_id=? AND l.link_type='ENTI_UREF' "
                   "  AND COALESCE(l.record_status,'LIVE')='LIVE'")
        elif row.get('nav_type') == 'REF':
            # ★ 2026-08-24 통합 표(`REFU_ENTI`)
            sql = ("SELECT el.target_id FROM sys_link_asset el "
                   "WHERE el.link_type='REFU_ENTI' AND el.clicked_id=? "
                   "  AND COALESCE(el.record_status,'LIVE')='LIVE'")
        else:
            return []
        lang = self._lang_code()
        out = []
        # ⚠ 갈래마다 `?` 개수가 다르다 — 글자를 세어 인자를 맞춘다
        args = (row['id'],) * sql.count('?')
        try:
            with appdb.connect(self._db) as conn:
                for (eid,) in conn.execute(sql, args).fetchall():
                    r = conn.execute(
                        "SELECT contents FROM sys_text_asset "
                        "WHERE clicked_id=? AND text_type='ENTITY_NAME' "
                        "  AND UPPER(lang_code) IN (?,'EN') "
                        "  AND COALESCE(record_status,'LIVE')='LIVE' "
                        "ORDER BY CASE UPPER(lang_code) WHEN ? THEN 0 ELSE 1 END "
                        "LIMIT 1", (eid, lang, lang)).fetchone()
                    out.append(r[0] if r else str(eid))
        except Exception:
            return []
        return out

    def _update_verse_strip(self, rows, header=None):
        """연결자료 띠 — 선택한 것 하나의 연결을 **한 줄로** 보인다.

        ★★ **갈래마다 줄을 나누지 않는다** (2026-08-30 사용자 지시 0.txt 1-3
          「"연결구절(17)"이라고 표시하는 것을 "연결자료(17)"이라고 수정할 것.
          연결된 구절, 연결된 용어…. 따로 구분하면 공간이 좁아짐」).
          띠 높이가 3줄인데 구절·용어·태그를 갈래마다 줄로 뽑으면 세 줄을
          통째로 먹는다. **한 이름 · 한 셈 · 한 줄**로 이어 붙인다.
        ⚠ 이름은 **이미 있는 `REFR_LINKED`**(11개 언어)를 쓴다 — 새 열쇠를
          만들면 언어가 또 하나 밀린다.
        """
        items = []
        seen = set()
        for r in rows:
            for sv, ev in self._refs_of(r):
                if sv and ('V', sv, ev) not in seen:
                    seen.add(('V', sv, ev))
                    items.append(('V', sv, ev))
        # 구절은 번호순으로 (용어·태그는 들어온 차례)
        items.sort(key=lambda x: x[1])
        labels = []
        if items:
            lang = self._lang_code()
            try:
                with appdb.connect(self._db) as conn:
                    labels = [_ref_label(conn, sv, ev, lang)
                              for _k, sv, ev in items]
            except Exception:
                labels = []
        # ★ 용어도 함께 (2026-08-14) — P4 「연구자료」 의 연결 칸과 같은 얼개다.
        for r in rows:
            for nm in self._ents_of(r):
                if nm and ('E', nm) not in seen:
                    seen.add(('E', nm))
                    labels.append(nm)
        if labels:
            head = header or i18n.t('REFR_LINKED', '연결 자료')
            text = '%s (%d) · %s' % (head, len(labels), ' · '.join(labels))
        else:
            text = i18n.t('REFR_NO_LINKED_VERSES', '연결된 구절 정보가 없습니다')
        self._set_strip(text)

    def _set_strip(self, text):
        self._verse_strip.configure(state='normal')
        self._verse_strip.delete('1.0', 'end')
        self._verse_strip.insert('1.0', text or '')
        self._verse_strip.configure(state='disabled')

    def _clear_strip(self):
        """목록을 다시 그릴 때 **띠를 비운다** (2026-08-30 사용자 신고 0.txt 1-3
        「탭 화면에 들어가자마자 **이전의** 연결자료 목록을 표시하고 있음.
        목록을 클릭하면 그때 표시되어야 함」).

        ⚠⚠ 그전에는 목록을 다 그린 뒤 `_update_verse_strip(drawn)` 를 **무조건**
          불러, 아무것도 고르지 않았는데 **직전에 보던 것의 연결**이 남아 있었다.
          틀린 것을 보여 주는 쪽이 비어 있는 것보다 나쁘다."""
        self._set_strip(i18n.t('REFR_STRIP_HINT',
                               '목록에서 하나를 선택하면 그 자료의 연결이 여기 보입니다.'))

    # ── DB 조회 ───────────────────────────────────────────────────

    def _find_pericopes(self, verse_id):
        if not verse_id:
            return []
        try:
            with appdb.connect(self._db) as conn:
                rows = conn.execute(
                    "SELECT pericope_id FROM sys_pericope_asset p "
                    "WHERE p.peri_type='BODY' AND p.record_status='LIVE' "
                    "  AND " + _vr.covers_sql('p', 'start_vid', 'end_vid'),
                    _vr.covers_args(verse_id)).fetchall()
            return [r[0] for r in rows]
        except Exception:
            return []

    def _query_nav(self):
        if not self._verse_id:
            return []
        vid = self._verse_id
        results = []

        # 설교집 + 도서
        try:
            with appdb.connect(self._db) as conn:
                # ⚠⚠ **`verse_id` 는 차례가 아니다** — 아6:14 는 vid **31113**
                #   (개역한글 절체계 이형, §4-6)이라 번호로 재면 **아가서 한 편이
                #   13,488절을 덮고**, 책 가드만 두면 **같은 책 아7·8장은 그대로
                #   샌다**(실측 27절). ⇒ 판정은 `verse_range` 한 문이다.
                for row in conn.execute(
                    # ★ 2026-10-13 — 어느 절에 거나는 **원본이 정한다**(`book_link` · docs/1.txt 72-2):
                    #   마이어 묵상은 주제 구절 한 절에만, 강해는 범위 그대로.
                    "SELECT bu.unit_id, bu.unit_label, ba.title, ba.book_category, "
                    + _BL.anchor_sql('bu', 'ba') + " "
                    "FROM sys_book_unit bu "
                    "JOIN sys_book_asset ba ON bu.book_id=ba.book_id "
                    "WHERE bu.record_status='LIVE' AND ba.record_status='LIVE' "
                    "  AND bu.start_vid IS NOT NULL "
                    "  AND " + _BL.hit_sql('bu', 'ba') + " "
                    "ORDER BY ba.book_category, ba.book_id, bu.unit_id",
                    _BL.hit_args(vid)).fetchall():
                    ntype = 'SERMON' if row[3] == 'SERMON' else 'BOOK'
                    label = f"{row[2]} — {row[1] or ''}"
                    # ★ 층(2026-08-30) — 이 절 하나인지, 더 넓은 범위인지.
                    #   사용자 지적 「자료/노트도 **단락/장/책 단위 연결 이슈**가
                    #   있다」. 범위가 이 절을 넘으면 **넓은 범위**다.
                    _wide = (row[4] != row[5])
                    results.append({'nav_type': ntype, 'kind': ntype,
                                    'id': row[0], 'line': label[:90],
                                    'via': ('WIDE' if _wide else 'VERSE'),
                                    'via_a': row[4], 'via_b': row[5]})
        except Exception:
            pass

        # 교리자료
        try:
            with appdb.connect(self._db) as conn:
                for row in conn.execute(
                    # ★ 제목은 **고른 표시 언어**로 (2026-08-14). 그 언어에 없으면
                    #   영어, 그것도 없으면 언어 없는 옛 칸(`unit_label`).
                    "SELECT u.ref_unit_id, "
                    "  COALESCE((SELECT t.title FROM sys_ref_text t "
                    "             WHERE t.ref_unit_id=u.ref_unit_id "
                    "               AND UPPER(t.lang_code)=? AND t.record_status='LIVE' "
                    "               AND t.title IS NOT NULL AND t.title<>'' LIMIT 1), "
                    "           (SELECT t.title FROM sys_ref_text t "
                    "             WHERE t.ref_unit_id=u.ref_unit_id "
                    "               AND UPPER(t.lang_code)='EN' AND t.record_status='LIVE' "
                    "               AND t.title IS NOT NULL AND t.title<>'' LIMIT 1), "
                    "           u.unit_label), "
                    "  u.unit_question, s.src_code, s.src_type, "
                    "  vl.target_id, COALESCE(vl.end_id, vl.target_id) "
                    # ★ 2026-08-24 통합 표(`REFU_VERS`)
                    "FROM sys_link_asset vl "
                    "JOIN sys_ref_unit u  ON vl.clicked_id=u.ref_unit_id "
                    "JOIN sys_ref_source s ON u.ref_src_id=s.ref_src_id "
                    "WHERE vl.link_type='REFU_VERS' "
                    "  AND COALESCE(vl.record_status,'LIVE')='LIVE' "
                    "  AND u.record_status='LIVE' "
                    "  AND (vl.target_id=? OR (vl.end_id IS NOT NULL AND "
                    + _vr.covers_sql('vl', 'target_id', 'end_id') + ")) "
                    # ★ **그 언어로 있는 글만** (2026-08-14 사용자 지시 「EN 으로
                    #   수정하면 EN 목록만 표시되어야 한다」).
                    #   ⚠ 옛 글은 `sys_ref_text` 에 아직 안 옮겨져 본문 행이 없다 —
                    #     그런 글까지 빼면 사용자가 자기 자료에 닿을 길이 없어진다.
                    "  AND (NOT EXISTS (SELECT 1 FROM sys_ref_text t0 "
                    "                    WHERE t0.ref_unit_id=u.ref_unit_id "
                    "                      AND t0.record_status='LIVE') "
                    "       OR EXISTS (SELECT 1 FROM sys_ref_text t1 "
                    "                   WHERE t1.ref_unit_id=u.ref_unit_id "
                    "                     AND UPPER(t1.lang_code)=? "
                    "                     AND t1.record_status='LIVE' "
                    "                     AND t1.body_text IS NOT NULL "
                    "                     AND t1.body_text<>'')) "
                    "ORDER BY s.ref_src_id, u.sequence",
                    [self._lang_code(), vid] + _vr.covers_args(vid)
                    + [self._lang_code()]).fetchall():
                    # 수입한 자료집만 약자를 둔다. 우리가 쓴 글은 코드를 노출하지 않고
                    # 제목만 보인다 (STUDY_NOTES 같은 원시 코드가 그대로 뜨던 것 교정)
                    abbr  = _SRC_ABBR.get(row[3], '')
                    title = row[1] or row[2] or row[3]
                    label = f"{abbr} — {title}" if abbr else str(title)
                    # ★ 층(2026-08-30) — 자료집 글도 **구간으로** 걸린다
                    #   (실측 `REFU_VERS` 구간 379건). 한 절이 아니면 넓은 범위다.
                    _w = (row[5] != row[6])
                    results.append({'nav_type': 'REF',                 # 이동 경로용(고정)
                                    'kind': _kind_of_srctype(row[4]),  # 표시용(자료집 종류)
                                    'id': row[0], 'line': label[:90],
                                    'via': ('WIDE' if _w else 'VERSE'),
                                    'via_a': row[5], 'via_b': row[6]})
        except Exception:
            pass

        # ★ 2026-10-13 docs/1.txt 83 — 내 연구노트로 가져와 「원본 가리기」를 고른 원본은 뺀다
        #   (사본이 내 자료 쪽에서 대신 보인다 · 배지·P4 거르개도 이 문을 셔틀로 쓴다)
        try:
            import copy_own
            with appdb.connect(self._db) as _c:
                _hid = copy_own.hidden_sys_ids(_c, 'REF')
            if _hid:
                results = [r for r in results
                           if not (r.get('nav_type') == 'REF' and r.get('id') in _hid)]
        except Exception:
            pass
        # (RSS 수집 자료[sys_ref_asset]는 외부 자료 → Links 탭에서 표시. 여기[내부자료]에는 넣지 않는다.)
        return results

    def _query_user(self):
        if not self._verse_id:
            return []
        vid  = self._verse_id
        pids = self._peri_ids
        peri_clause = (f"OR pericope_id IN ({','.join('?'*len(pids))})" if pids else '')
        try:
            with appdb.connect(self._db) as conn:
                rows = conn.execute(
                    f"SELECT ref_id, ref_type, title, author, source_name, "
                    f"       url, summary, lang_code, file_path "
                    f"FROM user_ref_asset "
                    f"WHERE record_status='LIVE' AND (verse_id=? {peri_clause} "
                    # ★ 2026-08-19 수리 — P4 연결 칸으로 붙인 구절은
                    #   `user_ref_asset_link`(VERSE, 구간 포함)에 있다. 대표 칸
                    #   (verse_id)만 보면 **사용자가 방금 건 구절이 P2 에 안
                    #   뜬다**(실제 신고). 커버 조회로 함께 잡는다.
                    # ★ 2026-08-24 통합 표(`UREF_VERS`)
                    f"  OR ref_id IN (SELECT clicked_id FROM userdb.user_link_asset "
                    f"       WHERE link_type='UREF_VERS' "
                    f"         AND COALESCE(record_status,'LIVE')='LIVE' "
                    f"         AND {_vr.covers_sql('user_link_asset', 'target_id', 'end_id')}) "
                    # ★ 새 연결 표 — 2026-08-21 이후 붙인 것은 여기에 있다.
                    f"  OR ref_id IN ({link_picker.refs_covering_sql()})) "
                    # ★ 그 언어의 것만 (2026-08-14)
                    f"  AND UPPER(COALESCE(NULLIF(lang_code,''), ?))=? "
                    f"ORDER BY ref_id",
                    [vid] + pids + _vr.covers_args(vid)
                    + link_picker.refs_covering_args(vid)
                    + [(i18n.get_lang() or 'KO').upper(),
                       self._lang_code()]).fetchall()
            return [{'id': r[0], 'ref_type': r[1] or 'STUDY',
                     'title': r[2] or '', 'author': r[3] or '',
                     'source_name': r[4] or '', 'url': r[5] or '',
                     'summary': r[6] or '', 'lang_code': r[7] or 'KO',
                     'file_path': r[8] or ''}
                    for r in rows]
        except Exception:
            return []

    # ── 목록 렌더링 ───────────────────────────────────────────────

    def _apply_filter(self):
        """내부 연결(도서·설교·문답)과 내 자료를 **한 목록**에 함께 그린다.

        ⚠ iid 규칙 — 두 갈래가 한 트리에 섞이므로 접두어로 구분한다.
             내부 연결  `N|<종류>|<id>`      내 자료  `U|<ref_id>`
           접두어가 없으면 도서 unit_id 와 user ref_id 가 충돌한다.
        """
        type_label = self._type_var.get()
        all_label  = i18n.t('COMMON_ALL', '전체')
        nav_key = ref_key = None
        if type_label != all_label:
            for k in _NAV_KINDS:
                if _navkind_label(k) == type_label:
                    nav_key = k
                    break
            else:
                for k in _REF_TYPES:
                    if _reftype_label(k) == type_label:
                        ref_key = k
                        break

        self._tv.delete(*self._tv.get_children())
        shown  = 0
        drawn  = []           # 지금 그린 줄 — 구절 띠가 이것을 쓴다
        scoped = self._rows_of(self._scope)

        # ① 내부 연결 — 앱 안 다른 화면으로 이어지는 줄
        # ★★★ **넓은 범위(책·장)에 걸린 것은 따로 묶는다** (2026-08-30) —
        #   강해설교 한 편이 장 전체를 덮으면 그것은 「이 절의 자료」가 아니다.
        #   묶음 머리에 **범위와 절 수**를 적어 두면, 나중에 그것을 숨길 때
        #   무엇이 함께 사라지는지 이미 읽고 있다.
        #   ⚠ 해당 줄이 없으면 묶음을 안 만든다(사용자 지시).
        seen = set()          # 같은 (종류,id) 중복 삽입 방지 (TclError 'already exists')
        # ★ 범위를 한 번에 지어 둔다 — 줄마다 DB 를 묻지 않는다.
        _sc = {}
        _self_sc = ''
        try:
            import link_picker as _lp
            with appdb.connect(self._db) as _c:
                # ★ 절 직접 줄·내 자료도 **그 절 약명**을 적는다(2026-08-30).
                _self_sc = _lp.scope_label(_c, self._verse_id, self._verse_id,
                                           self._lang_code())
                for r in scoped:
                    a_, b_ = r.get('via_a'), r.get('via_b')
                    if a_ and (a_, b_) not in _sc:
                        _sc[(a_, b_)] = _lp.scope_label(_c, a_, b_,
                                                        self._lang_code())
        except Exception as e:
            print('[refr scope] %s' % e)
        # ★ 2026-10-11 (docs/1.txt 7) — 읽은 연구자료(여러 절에 걸친 것)에 흐린 ✓
        try:
            import db_read_state as _rs
            with appdb.connect(self._db) as _c:
                _readm = _rs.ref_marks(_c)
        except Exception:                                   # noqa: BLE001
            _readm = set()
        for r in scoped:
            if 'ref_type' in r:                     # 내 자료는 ② 에서
                continue
            kind = r.get('kind') or r['nav_type']
            if ref_key or (nav_key and kind != nav_key):
                continue
            iid = f"N|{r['nav_type']}|{r['id']}"
            if iid in seen:
                continue
            seen.add(iid)
            self._tv.insert('', 'end', iid=iid,
                            values=(_sc.get((r.get('via_a'), r.get('via_b')),
                                            _self_sc),
                                    _navkind_label(kind),
                                    ('✓ ' + r['line']) if (kind == 'STUDY'
                                                           and r['id'] in _readm)
                                    else r['line']),
                            tags=(r['nav_type'].lower(),))
            drawn.append(r)
            shown += 1

        # ② 내 자료
        for r in scoped:
            if 'ref_type' not in r:
                continue
            if nav_key or (ref_key and __import__('ref_kinds').normalize(r['ref_type'])[0] != ref_key):
                continue
            title = r['title'] if r['title'] else i18n.t('REFR_NOTITLE', '(제목없음)')
            # ⚠ 내 자료는 층 정보가 없다(구절에 직접 쓴 글이다) — 묶음이 있으면
            #   「구절과 연결」 밑으로 간다.
            # ★ 내 자료는 그 절에 직접 쓴 글이다 — 그 절 약명을 적는다.
            self._tv.insert('', 'end', iid=f"U|{r['id']}",
                            values=(_self_sc, _reftype_label(r['ref_type']),
                                    title),
                            tags=('user',))
            drawn.append(r)
            shown += 1

        if shown == 0:
            # 65% 의 구절이 여기에 해당한다. 빈 표를 그냥 두면 고장으로 보인다.
            self._tv.insert('', 'end', iid='EMPTY',
                            values=('', '',
                                    i18n.t('REFR_EMPTY', '연결된 자료가 없습니다')),
                            tags=('empty',))

        total = len(scoped)
        self._user_count.config(
            text=(i18n.t('REFR_COUNT_N', '({n}건)').format(n=shown) if shown == total
                  else i18n.t('REFR_COUNT_MN', '({m}/{n}건)').format(m=shown, n=total)))
        self._refresh_scope_labels()
        self._clear_strip()      # ⚠ 목록만 그린다 — 띠는 고를 때 채운다(위 설명)

    def _start_new(self):
        """새 자료 쓰기 — **P4 「연구자료」 탭**이 넓은 화면에서 받는다.

        ⚠ 이 화면에는 폼이 없다(2026-08-14 목록만 남김). 콜백이 없으면 쓸 자리가
          아예 없으므로 **조용히 넘기지 않고 알린다.**
        """
        if not self._verse_id:
            messagebox.showwarning(i18n.t('MSG_T_NEWMINE', '새 내자료'),
                                   i18n.t('MSG_SELECT_VERSE_FIRST',
                                          '먼저 구절을 선택하세요.'), parent=self)
            return
        self._tv.selection_remove(*self._tv.selection())
        # ★★ **통합 연결팝업으로 연다** — 구절이 출발지, 재고창고에서 「연구자료」
        #   갈래가 눌린 채. 이어 둔 다른 자산을 함께 보면서 새 글도 쓴다.
        #   ⚠ 옛 길(`_on_user_new` → P4 이동)은 **폴백으로 남긴다** — 팝업이
        #     안 뜨는 자리에서 조용히 아무 일도 안 하면 그것이 더 나쁘다.
        try:
            # ★ 창은 **P4 와 같은 것**(My Edit) — 2026-08-30 통일 지시
            import my_edit
            my_edit.open(self, 'VERSE', self._verse_id,
                         on_changed=lambda *_a: self._reload(),
                         pick_kind='USER_REF')
            return
        except Exception as e:
            print('[refr my edit] %s' % e)
        if not self._on_user_new:
            messagebox.showinfo(i18n.t('MSG_T_NEWMINE', '새 내자료'),
                                i18n.t('REFR_NEED_REFTAB',
                                       '자료 화면을 열 수 없습니다.'), parent=self)
            return
        self._on_user_new(self._verse_id)

    # ── 이벤트 핸들러 ─────────────────────────────────────────────

    def _on_select(self, _):
        """한 목록이므로 iid 접두어로 갈라 보낸다."""
        sel = self._tv.selection()
        if not sel or sel[0] == 'EMPTY':
            return
        head, _, rest = sel[0].partition('|')

        if head == 'N':                       # 내부 연결 → 그 자료의 제 화면으로
            ntype, _, id_str = rest.partition('|')
            try:
                item_id = int(id_str)
            except ValueError:
                return
            nrow = next((r for r in self._nav_rows
                         if r['nav_type'] == ntype and r['id'] == item_id), None)
            if nrow:                          # 고른 것 하나의 연결 구절만 띠에 보인다
                self._update_verse_strip([nrow])
            if ntype in ('SERMON', 'BOOK') and self._on_unit_select:
                self._on_unit_select(item_id)       # 도서·설교는 P1 읽기 화면이 제 집
            elif ntype == 'REF':
                # 우리가 쓴 연구 글은 P4 자료 탭에서 넓게, 수입한 문답·사전은
                # 원래 있던 P1 교리·자료 화면에서 본다.
                row = next((r for r in self._nav_rows
                            if r['nav_type'] == 'REF' and r['id'] == item_id), None)
                kind = (row or {}).get('kind')
                if kind == 'STUDY' and self._on_article_open:
                    self._on_article_open(item_id)
                elif self._on_doctrine_select:
                    self._on_doctrine_select(item_id)
            return

        if head == 'U':                       # 내 자료
            try:
                ref_id = int(rest)
            except ValueError:
                return
            urow = next((r for r in self._user_rows if r['id'] == ref_id), None)
            if urow:
                self._update_verse_strip([urow])
            # 읽기·쓰기는 **P4 「연구자료」 탭**이 한다 (2026-08-14 — 이 화면은 목록만)
            if self._on_user_open:
                self._on_user_open(ref_id)


def count_for(db_path, verse_id, lang='KO'):
    """P2 탭 배지용 개수 (2026-08-19 0.txt ①) — 내부 연결 + 내 자료.

    ★ 패널의 `_find_pericopes`·`_query_nav`·`_query_user` **그 코드를** 셔틀
      객체로 재사용한다(드리프트 0). 언어 필터까지 목록과 같은 기준으로 센다."""
    if not verse_id:
        return 0
    try:
        from types import SimpleNamespace
        s = SimpleNamespace(_db=db_path, _verse_id=int(verse_id), _peri_ids=[])
        s._lang_code = lambda: (lang or 'KO').upper()
        try:
            s._peri_ids = RefUnifiedPanel._find_pericopes(s, s._verse_id)
        except Exception:
            s._peri_ids = []
        nav = RefUnifiedPanel._query_nav(s) or []
        usr = RefUnifiedPanel._query_user(s) or []
        return len(nav) + len(usr)
    except Exception:
        return 0


def nav_rows(db_path, verse_id, lang='KO'):
    """「이 구절이 나오는 곳」 — 도서·설교·문답 편(연구자료는 뺀다) · P1 한 줄이 쓴다
    (2026-10-11 docs/1.txt 4-2). 패널의 `_query_nav` **그 코드를** 셔틀로 쓴다(`count_for` 와 같은 길)."""
    if not verse_id:
        return []
    try:
        from types import SimpleNamespace
        s = SimpleNamespace(_db=db_path, _verse_id=int(verse_id), _peri_ids=[])
        s._lang_code = lambda: (lang or 'KO').upper()
        try:
            s._peri_ids = RefUnifiedPanel._find_pericopes(s, s._verse_id)
        except Exception:
            s._peri_ids = []
        nav = RefUnifiedPanel._query_nav(s) or []
        return [r for r in nav if (r.get('kind') or r.get('nav_type')) != _MINE_KIND]
    except Exception:
        return []


def counts_for(db_path, verse_id, lang='KO'):
    """갈래별 개수 {'mine': 연구자료, 'nav': 내부연결} — 3갈래 배지용
    (2026-08-19). 나누는 기준은 패널의 `_rows_of` 와 같다(STUDY = 연구자료)."""
    out = {'mine': 0, 'nav': 0}
    if not verse_id:
        return out
    try:
        from types import SimpleNamespace
        s = SimpleNamespace(_db=db_path, _verse_id=int(verse_id), _peri_ids=[])
        s._lang_code = lambda: (lang or 'KO').upper()
        try:
            s._peri_ids = RefUnifiedPanel._find_pericopes(s, s._verse_id)
        except Exception:
            s._peri_ids = []
        nav = RefUnifiedPanel._query_nav(s) or []
        usr = RefUnifiedPanel._query_user(s) or []
        mine_nav = [r for r in nav if (r.get('kind') or r.get('nav_type')) == _MINE_KIND]
        out['mine'] = len(mine_nav) + len(usr)
        out['nav'] = len(nav) - len(mine_nav)
    except Exception:
        pass
    return out


def verse_ref_ids(db_path, verse_id, lang='KO'):
    """그 구절에 연결된 연구/설교노트 번호 — (sys 연구 글 ref_unit_id 집합, 내 글 ref_id 집합).

    ★ 2026-10-07 (docs/1.txt 51-3·4(5)) — P4 연구/설교노트 목록이 「이 구절과 연결된 것만」을
      보일 때 쓴다. **P2 가 세는 그 코드를 셔틀로 재사용한다**(`count_for` 와 같은 길 —
      두 벌이면 P2 배지와 P4 목록이 갈린다)."""
    if not verse_id:
        return set(), set()
    try:
        from types import SimpleNamespace
        s = SimpleNamespace(_db=db_path, _verse_id=int(verse_id), _peri_ids=[])
        s._lang_code = lambda: (lang or 'KO').upper()
        try:
            s._peri_ids = RefUnifiedPanel._find_pericopes(s, s._verse_id)
        except Exception:
            s._peri_ids = []
        nav = RefUnifiedPanel._query_nav(s) or []
        usr = RefUnifiedPanel._query_user(s) or []
        sys_ids = {int(r['id']) for r in nav
                   if r.get('nav_type') == 'REF'
                   and (r.get('kind') or r.get('nav_type')) == _MINE_KIND}
        return sys_ids, {int(r['id']) for r in usr}
    except Exception:
        return set(), set()
