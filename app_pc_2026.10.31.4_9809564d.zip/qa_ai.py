# -*- coding: utf-8 -*-
"""Q&A AI 작업 흐름 (2026-10-08 · docs/1.txt 57 · 사용자 「모두 채택한다」).

정해진 차례로 걸음마다 좁은 물음 하나씩 AI 에 맡긴다(스스로 판단하는 에이전트가 아니다):
  ① 질문 번역·분류      translate_question  — 한국어 번역 · 유형 · 급한 정도 · 요지
  ② 비슷한 지난 질문     similar(로컬) → judge_similar(AI · 후보 안에서만)
  ③ 답변 번역           translate_answer    — 화면 이름은 그 언어의 실제 화면 글자(용어집)
  ④ 역번역(확인용)       back_translate      — **다른 엔진**(구글 클라우드 번역)으로 한국어로 되돌린다
  ⑤ 차이 짚기           check               — 낱말 차이 + 빠진·바뀐·덧붙은 뜻 목록
  ⑥ 전송 문             can_send            — 지금 번역문이 ④⑤를 거쳤을 때만 참

★ 지난 문의를 외부 AI 에 통째로 보내지 않는다 — 찾기(②)는 **이 PC 에서** 한국어 번역문끼리 견준다.
  AI 에는 새 질문 + 고른 후보 다섯만 간다. 모든 질문은 ①에서 한국어로 바뀌어 저장되므로,
  언어가 달라도 한국어끼리 견주면 된다(임베딩 API 를 따로 쓰지 않는다 · 보내는 글이 늘지 않는다).
★ 보내기 전에 이메일·전화번호를 가린다(`scrub`).
★ 모든 걸음의 결과를 `admin_comm.db` 의 `qa_ai` 에 남긴다 — 무엇이 나갔나를 되짚는다.
"""
import difflib
import hashlib
import json
import math
import os
import re
import sqlite3
import sys
from collections import Counter
from datetime import datetime

APP = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(APP, 'admin_comm.db')

TYPES = ('BUG', 'FEATURE', 'QUESTION', 'OTHER')
LANG_NAME = {'KO': '한국어', 'EN': 'English', 'ZH': '简体中文', 'ZHT': '繁體中文', 'JA': '日本語',
             'DE': 'Deutsch', 'FR': 'Français', 'ES': 'Español', 'PT': 'Português',
             'RU': 'Русский', 'AR': 'العربية'}


# ── 표 ─────────────────────────────────────────────────────────────────────
def conn(path=None):
    c = sqlite3.connect(path or DB_PATH)
    c.execute("""CREATE TABLE IF NOT EXISTS qa (
        msg_id TEXT PRIMARY KEY, uuid TEXT, lang TEXT, version TEXT,
        kind TEXT, q_type TEXT, question TEXT, email TEXT, attachments TEXT,
        reply TEXT, replied_at TEXT, ts TEXT, absorbed_at TEXT)""")
    c.execute("""CREATE TABLE IF NOT EXISTS qa_ai (
        msg_id TEXT PRIMARY KEY, q_ko TEXT, ai_type TEXT, urgency TEXT, summary TEXT,
        sim_json TEXT, reply_ko TEXT, out_lang TEXT, out_text TEXT, glossary_json TEXT,
        back_ko TEXT, back_engine TEXT, check_json TEXT, checked_hash TEXT,
        sent_text TEXT, sent_at TEXT, updated_at TEXT)""")
    return c


def _now():
    return datetime.now().isoformat(timespec='seconds')


def _put(c, msg_id, **kw):
    c.execute('INSERT OR IGNORE INTO qa_ai(msg_id) VALUES(?)', (msg_id,))
    kw['updated_at'] = _now()
    c.execute('UPDATE qa_ai SET %s WHERE msg_id=?' % ','.join('%s=?' % k for k in kw),
              list(kw.values()) + [msg_id])
    c.commit()


def row(c, msg_id):
    q = c.execute('SELECT msg_id, lang, question, reply, q_type FROM qa WHERE msg_id=?', (msg_id,)).fetchone()
    if not q:
        return None
    a = c.execute('SELECT * FROM qa_ai WHERE msg_id=?', (msg_id,)).fetchone()
    cols = [d[0] for d in c.execute('SELECT * FROM qa_ai LIMIT 0').description]
    out = {'msg_id': q[0], 'lang': (q[1] or 'KO').upper(), 'question': q[2] or '',
           'reply': q[3] or '', 'q_type': q[4] or ''}
    out.update({k: v for k, v in zip(cols, a or [None] * len(cols)) if k != 'msg_id'})
    return out


# ── 개인정보 가리기 ───────────────────────────────────────────────────────
_EMAIL = re.compile(r'[\w.+-]+@[\w-]+\.[\w.-]+')
_PHONE = re.compile(r'(?<!\d)(?:\+?\d[\d\- ]{7,}\d)(?!\d)')


def scrub(text):
    return _PHONE.sub('[전화번호]', _EMAIL.sub('[이메일]', text or ''))


# ── AI 부르기(바꿔 끼울 수 있다 — 시험은 가짜를 쓴다) ─────────────────────
def _ai(prompt, call=None, model=None):
    if call:
        return call(prompt, model)
    import ai_client
    r = ai_client.call(prompt, model=model)
    return r.get('text', '') if r.get('ok') else ('\x00' + (r.get('why') or 'AI 실패'))


def _json(txt):
    s = re.sub(r'^```(?:json)?\s*|\s*```$', '', (txt or '').strip())
    try:
        return json.loads(s)
    except Exception:
        m = re.search(r'\{.*\}', s, re.S)
        try:
            return json.loads(m.group(0)) if m else None
        except Exception:
            return None


def _fail(txt):
    return isinstance(txt, str) and txt.startswith('\x00')


# ── ① 질문 번역·분류 ──────────────────────────────────────────────────────
P_QUESTION = '''너는 성경 앱 「하가」의 사용자 문의를 관리자에게 전하는 번역·분류 담당이다.
아래 문의를 한국어로 충실히 옮기고(뜻을 더하거나 빼지 않는다) 분류한다.
- type: BUG(오류) · FEATURE(기능 요청) · QUESTION(사용법·내용 질문) · OTHER
- urgency: HIGH(앱을 못 쓰거나 자료가 사라짐) · NORMAL · LOW
- summary: 한국어 한 줄 요지
JSON 만: {{"ko":"","type":"","urgency":"","summary":""}}

[문의 언어] {lang}
[문의]
{text}'''


def translate_question(c, msg_id, call=None):
    r = row(c, msg_id)
    if not r:
        return {'ok': False, 'why': '문의가 없습니다'}
    txt = _ai(P_QUESTION.format(lang=LANG_NAME.get(r['lang'], r['lang']), text=scrub(r['question'])), call)
    if _fail(txt):
        return {'ok': False, 'why': txt[1:]}
    d = _json(txt) or {}
    ko = (d.get('ko') or '').strip() or (r['question'] if r['lang'] == 'KO' else '')
    if not ko:
        return {'ok': False, 'why': '번역을 읽지 못했습니다'}
    t = (d.get('type') or '').upper()
    _put(c, msg_id, q_ko=ko, ai_type=t if t in TYPES else 'OTHER',
         urgency=(d.get('urgency') or 'NORMAL').upper(), summary=(d.get('summary') or '')[:200])
    return {'ok': True, 'ko': ko, 'type': t, 'urgency': d.get('urgency'), 'summary': d.get('summary')}


# ── ② 비슷한 지난 질문 — 로컬에서 찾고 AI 는 후보 안에서만 판정 ──────────
def _grams(s):
    s = re.sub(r'[\s\W_]+', '', (s or '').lower())
    return Counter(s[i:i + 2] for i in range(len(s) - 1)) if len(s) > 1 else Counter(s)


def _cos(a, b):
    if not a or not b:
        return 0.0
    dot = sum(v * b.get(k, 0) for k, v in a.items())
    return dot / (math.sqrt(sum(v * v for v in a.values())) * math.sqrt(sum(v * v for v in b.values())))


def _faq_rows():
    try:
        import appdb
        bc = appdb.connect(os.path.join(APP, 'bible_master.db'))
        try:
            return bc.execute("SELECT t.faq_id, t.question, t.answer FROM sys_faq_text t JOIN sys_faq f"
                              " ON f.faq_id=t.faq_id WHERE t.lang_code='KO'"
                              " AND COALESCE(f.record_status,'LIVE')='LIVE'"
                              " AND COALESCE(t.record_status,'LIVE')='LIVE'").fetchall()
        finally:
            bc.close()
    except Exception:
        return []


def similar(c, msg_id, k=5, faq=None):
    """새 질문과 뜻이 가까운 지난 Q&A·FAQ → [{kind,id,score,q,a}] (이 PC 에서만 계산)."""
    r = row(c, msg_id)
    base = (r or {}).get('q_ko') or ((r or {}).get('question') if (r or {}).get('lang') == 'KO' else '')
    if not base:
        return []
    g0 = _grams(base)
    cand = []
    for mid, lang, q, rep, qko in c.execute(
            'SELECT q.msg_id, q.lang, q.question, q.reply, a.q_ko FROM qa q LEFT JOIN qa_ai a'
            ' ON a.msg_id=q.msg_id WHERE q.msg_id<>?', (msg_id,)):
        text = qko or (q if (lang or 'KO').upper() == 'KO' else '')
        if text:
            cand.append({'kind': 'QA', 'id': mid, 'q': text, 'a': rep or '', 'score': _cos(g0, _grams(text))})
    for fid, q, a in (faq if faq is not None else _faq_rows()):
        cand.append({'kind': 'FAQ', 'id': fid, 'q': q or '', 'a': a or '', 'score': _cos(g0, _grams(q))})
    cand.sort(key=lambda x: -x['score'])
    return [x for x in cand[:k] if x['score'] > 0.15]


P_SIMILAR = '''새 문의와 지난 문의·FAQ 후보를 견준다. 후보마다 판정한다.
- SAME 같은 물음 · RELATED 비슷하지만 다른 물음 · NONE 무관
- reuse: SAME 일 때 그 답을 그대로 써도 되면 true(앱이 바뀌어 낡았을 수 있으면 false)
JSON 만: {{"items":[{{"n":번호,"v":"SAME|RELATED|NONE","reuse":true,"why":""}}]}}

[새 문의] {q}
[후보]
{cands}'''


def judge_similar(c, msg_id, call=None, k=5, faq=None):
    r = row(c, msg_id)
    cands = similar(c, msg_id, k, faq)
    if not cands:
        _put(c, msg_id, sim_json='[]')
        return {'ok': True, 'items': []}
    lines = '\n'.join('%d. [%s] 물음: %s\n   답: %s' % (i + 1, x['kind'], scrub(x['q'])[:400],
                                                    scrub(x['a'])[:400] or '(답 없음)')
                      for i, x in enumerate(cands))
    txt = _ai(P_SIMILAR.format(q=scrub(r.get('q_ko') or r['question']), cands=lines), call)
    if _fail(txt):
        return {'ok': False, 'why': txt[1:]}
    got = {int(x.get('n', 0)): x for x in ((_json(txt) or {}).get('items') or []) if str(x.get('n', '')).isdigit()}
    for i, x in enumerate(cands):
        j = got.get(i + 1, {})
        x['v'] = str(j.get('v', 'NONE')).upper()
        x['reuse'] = bool(j.get('reuse')) and x['v'] == 'SAME'
        x['why'] = str(j.get('why', ''))[:200]
    _put(c, msg_id, sim_json=json.dumps(cands, ensure_ascii=False))
    return {'ok': True, 'items': cands}


# ── ③ 화면 이름 용어집 · 답변 번역 ────────────────────────────────────────
_UI = {}


def ui_glossary(reply_ko, lang, ui_rows=None):
    """답변에 든 앱 화면 글자(KO) → 그 언어의 실제 화면 글자. 긴 것부터 · 3자 이상만."""
    if (lang or 'KO').upper() == 'KO':
        return []
    if ui_rows is None:
        key = lang.upper()
        if key not in _UI:
            import appdb
            bc = appdb.connect(os.path.join(APP, 'bible_master.db'))
            try:
                ko = dict(bc.execute("SELECT string_id, string_value FROM ui_strings WHERE lang_code='KO'"))
                tg = dict(bc.execute("SELECT string_id, string_value FROM ui_strings WHERE lang_code=?", (key,)))
            finally:
                bc.close()
            # ★ 같은 한국어 이름이 열쇠마다 다르게 옮겨진 곳이 있다(「설정」 → PC 탭 Configurações ·
            #   폰 Definições). 고를 차례 = PC 탭 이름(TAB_) → 그 밖 → 폰 화면(M_).
            def _rank(sid):
                return 0 if sid.startswith('TAB_') else (2 if sid.startswith('M_') else 1)
            best = {}
            for s, v in ko.items():
                v = (v or '').strip()
                if s in tg and v and (tg[s] or '').strip() and 2 <= len(v) <= 30 and '%' not in v and '\n' not in v:
                    if v not in best or _rank(s) < best[v][0]:
                        best[v] = (_rank(s), tg[s].strip())
            _UI[key] = [(v, t) for v, (_r, t) in best.items()]
        ui_rows = _UI[key]
    out, used = [], ''
    for k_, v in sorted(ui_rows, key=lambda x: -len(x[0])):
        if len(k_) < 3 and not re.search(r'(^|[\s▸\[\(「])' + re.escape(k_) + r'($|[\s▸\]\)」에의을를])', reply_ko):
            continue          # 두 글자 이름은 낱말로 홀로 설 때만(「설정 ▸」 · 「[설정]」)
        if k_ in reply_ko and k_ not in used:
            out.append((k_, v))
            used += '\x01' + k_
    return out[:40]


P_ANSWER = '''너는 성경 앱 「하가」 관리자의 답변을 사용자의 언어로 옮긴다.
- 뜻을 더하거나 빼지 않는다. 존댓말·정중한 말투로 그 언어에서 자연스럽게.
- [화면 이름 용어집]에 있는 한국어 화면 이름은 **반드시 오른쪽 글자 그대로** 쓴다(사용자 앱에 보이는 이름이다).
- 성경 구절을 인용하면 그 언어의 흔한 역본 표현을 쓰되 장·절 숫자는 그대로.
- 옮긴 글만 낸다(머리말·설명 없이).

[옮길 언어] {lang}
[화면 이름 용어집]
{gloss}
[답변(한국어)]
{text}'''


def translate_answer(c, msg_id, reply_ko, call=None, ui_rows=None):
    r = row(c, msg_id)
    lang = r['lang']
    gl = ui_glossary(reply_ko, lang, ui_rows)
    if lang == 'KO':
        out = reply_ko
    else:
        out = _ai(P_ANSWER.format(lang='%s · %s' % (lang, LANG_NAME.get(lang, lang)),
                                  gloss='\n'.join('%s → %s' % g for g in gl) or '(없음)',
                                  text=scrub(reply_ko)), call)
        if _fail(out):
            return {'ok': False, 'why': out[1:]}
        out = out.strip()
    _put(c, msg_id, reply_ko=reply_ko, out_lang=lang, out_text=out,
         glossary_json=json.dumps(gl, ensure_ascii=False),
         back_ko=None, back_engine=None, check_json=None, checked_hash=None)
    miss = [g for g in gl if g[1] not in out]
    return {'ok': True, 'text': out, 'glossary': gl, 'glossary_missing': miss}


# ── ④ 역번역(확인용) — 다른 엔진 ─────────────────────────────────────────
def _gct_key():
    try:
        try:
            from admin import admin_state as A
        except ImportError:
            import admin_state as A
        import cloud_translate as _CT
        return _CT.get_key()
    except Exception:
        return ''


def back_translate(c, msg_id, call=None, gct=None):
    """번역문 → 한국어. 구글 클라우드 번역을 먼저 쓰고, 키가 없을 때만 AI 로(같은 엔진임을 적는다)."""
    r = row(c, msg_id)
    out = r.get('out_text') or ''
    if not out:
        return {'ok': False, 'why': '번역문이 없습니다'}
    if r['lang'] == 'KO':
        back, eng = out, 'SAME_LANG'
    else:
        back, eng = None, ''
        key = _gct_key() if gct is None else None
        if gct or key:
            try:
                back = (gct(out) if gct else __import__('cloud_translate').translate_batch([out], 'KO', key)[0])
                eng = 'GOOGLE_TRANSLATE'
            except Exception as e:                        # noqa: BLE001
                back, eng = None, 'GCT_FAIL:%s' % str(e)[:60]
        if back is None:
            t = _ai('다음 글을 한국어로 충실히 옮겨라. 옮긴 글만 낸다.\n\n' + out, call)
            if _fail(t):
                return {'ok': False, 'why': t[1:]}
            back, eng = t.strip(), 'AI_SAME_ENGINE' + ((' · ' + eng) if eng else '')
    _put(c, msg_id, back_ko=back, back_engine=eng, check_json=None, checked_hash=None)
    return {'ok': True, 'back': back, 'engine': eng}


# ── ⑤ 차이 짚기 ──────────────────────────────────────────────────────────
def word_diff(a, b):
    """한국어 답변 ↔ 역번역 — 낱말 단위 차이 [(op, a조각, b조각)]."""
    ta, tb = (a or '').split(), (b or '').split()
    out = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, ta, tb).get_opcodes():
        if op != 'equal':
            out.append((op, ' '.join(ta[i1:i2]), ' '.join(tb[j1:j2])))
    return out


P_CHECK = '''관리자가 쓴 한국어 답변과, 그것을 사용자 언어로 옮긴 뒤 다른 번역기로 다시 한국어로 되돌린 글(역번역)을 견준다.
말투·어순 차이는 무시하고 **뜻**만 본다.
- missing: 원래 답변에 있는데 역번역에 없는 뜻
- changed: 뜻이 달라진 곳
- added: 원래 답변에 없는데 덧붙은 뜻
- ok: 셋이 모두 비었으면 true
JSON 만: {{"ok":true,"missing":[],"changed":[],"added":[]}}

[원래 답변]
{a}
[역번역]
{b}'''


def _h(s):
    return hashlib.sha1((s or '').encode('utf-8')).hexdigest()[:16]


def check(c, msg_id, call=None):
    r = row(c, msg_id)
    a, b = r.get('reply_ko') or '', r.get('back_ko') or ''
    if not (a and b):
        return {'ok': False, 'why': '답변이나 역번역이 없습니다'}
    diff = word_diff(a, b)
    if r['lang'] == 'KO':
        res = {'ok': True, 'missing': [], 'changed': [], 'added': []}
    else:
        t = _ai(P_CHECK.format(a=scrub(a), b=scrub(b)), call)
        if _fail(t):
            return {'ok': False, 'why': t[1:]}
        res = _json(t) or {'ok': False, 'missing': ['(판정을 읽지 못함)'], 'changed': [], 'added': []}
    res['diff'] = diff
    res['same_engine'] = str(r.get('back_engine') or '').startswith('AI_SAME_ENGINE')
    _put(c, msg_id, check_json=json.dumps(res, ensure_ascii=False), checked_hash=_h(r.get('out_text')))
    return dict(res, ok_call=True)


# ── ⑥ 전송 문 ────────────────────────────────────────────────────────────
def can_send(c, msg_id, text=None):
    """지금 보낼 글이 역번역·차이 짚기를 거쳤나 → (참/거짓, 까닭)."""
    r = row(c, msg_id)
    if not r or not r.get('out_text'):
        return False, '번역문이 없습니다 — [답변 번역]부터'
    if text is not None and _h(text) != _h(r['out_text']):
        return False, '번역문을 고쳤습니다 — 역번역·검증을 다시 하세요'
    if not r.get('checked_hash') or r['checked_hash'] != _h(r['out_text']):
        return False, '역번역(확인용)·검증을 거치지 않았습니다'
    return True, ''


def mark_sent(c, msg_id):
    r = row(c, msg_id)
    _put(c, msg_id, sent_text=r.get('out_text'), sent_at=_now())


# ── 자가검증 ──────────────────────────────────────────────────────────────
def selftest():
    import tempfile
    n = [0, 0]

    def ck(cond, m):
        n[0] += 1
        n[1] += bool(cond)
        if not cond:
            print('  FAIL', m)
    d = tempfile.mkdtemp()
    c = conn(os.path.join(d, 't.db'))
    c.executemany('INSERT INTO qa(msg_id,lang,question,reply,ts) VALUES(?,?,?,?,?)', [
        ('m1', 'PT', 'Como faço para conectar o celular ao PC? meu email a@b.com', '', '2026-10-08'),
        ('m2', 'KO', '휴대폰을 PC 와 연결하는 방법을 알려주세요', '설정 ▸ 모바일 연결에서 [폰 연결하기]를 누르세요', '2026-10-01'),
        ('m3', 'KO', '글자 크기를 키우고 싶어요', '설정에서 글꼴 크기를 바꾸세요', '2026-09-01')])
    c.commit()
    seen = []

    def fake(prompt, model=None):
        seen.append(prompt)
        if '분류한다' in prompt:
            return '{"ko":"휴대폰을 PC 에 어떻게 연결하나요?","type":"QUESTION","urgency":"NORMAL","summary":"폰 연결 방법"}'
        if '후보마다 판정' in prompt:
            return '{"items":[{"n":1,"v":"SAME","reuse":true,"why":"같은 물음"}]}'
        if '옮길 언어' in prompt:
            return 'Vá em Configurações ▸ Conexão móvel e toque em [Conectar telefone].'
        if '뜻만 본다' in prompt:
            return '{"ok":true,"missing":[],"changed":[],"added":[]}'
        return '번역'
    ck(scrub('메일 a@b.com 전화 010-1234-5678') == '메일 [이메일] 전화 [전화번호]', '개인정보 가림')
    r = translate_question(c, 'm1', call=fake)
    ck(r['ok'] and r['type'] == 'QUESTION', '질문 번역·분류')
    ck('a@b.com' not in seen[-1], '이메일을 안 보낸다')
    s = similar(c, 'm1', faq=[(9, '글꼴 바꾸기', '설정')])
    ck(s and s[0]['id'] == 'm2', '비슷한 지난 질문이 맨 위(언어가 달라도 한국어 번역끼리)')
    j = judge_similar(c, 'm1', call=fake, faq=[])
    ck(j['ok'] and j['items'][0]['v'] == 'SAME' and j['items'][0]['reuse'], '후보 판정')
    ui = [('모바일 연결', 'Conexão móvel'), ('폰 연결하기', 'Conectar telefone'), ('설정', 'Configurações')]
    g = ui_glossary('설정 ▸ 모바일 연결에서 [폰 연결하기]', 'PT', ui)
    ck(('모바일 연결', 'Conexão móvel') in g and len(g) == 3, '화면 이름 용어집')
    t = translate_answer(c, 'm1', '설정 ▸ 모바일 연결에서 [폰 연결하기]를 누르세요', call=fake, ui_rows=ui)
    ck(t['ok'] and not t['glossary_missing'], '답변 번역 — 화면 이름이 그대로')
    ck(not can_send(c, 'm1')[0], '검증 전에는 못 보낸다')
    b = back_translate(c, 'm1', call=fake, gct=lambda s: '설정 ▸ 모바일 연결로 가서 [전화 연결]을 누르세요.')
    ck(b['ok'] and b['engine'] == 'GOOGLE_TRANSLATE', '역번역은 다른 엔진')
    k = check(c, 'm1', call=fake)
    ck(k.get('ok_call') and k['diff'], '차이 짚기 — 낱말 차이')
    ck(can_send(c, 'm1')[0], '검증 뒤에는 보낼 수 있다')
    ck(not can_send(c, 'm1', text='고친 글')[0], '번역문을 고치면 다시 막힌다')
    b2 = back_translate(c, 'm1', call=fake, gct=lambda s: (_ for _ in ()).throw(RuntimeError('x')))
    ck(b2['engine'].startswith('AI_SAME_ENGINE'), '다른 엔진이 안 되면 같은 엔진임을 적는다')
    ck(not can_send(c, 'm1')[0], '역번역을 다시 하면 검증도 다시')
    mark_sent(c, 'm1')
    ck(row(c, 'm1')['sent_at'], '보낸 기록')
    c.close()
    print('qa_ai selftest %d/%d' % (n[1], n[0]))
    return n[0] == n[1]


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)
