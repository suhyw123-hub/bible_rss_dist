# -*- coding: utf-8 -*-
"""db_absmith_import.py — Abbott-Smith 헬라어 사전 층 적재 (영구).

2026-09-03 (186차) — 헬라어 쪽 [사전] 층. BDB(히브리 쪽)의 짝.
Trench 가 OCR 헬라어 전멸로 보류된 자리에 **사람이 마크업한 TEI 전사본**을
확보(185차)해 다음 책으로 확정.

원자료 (2026-09-03 수령·검증 — _lexicon_raw/, 규칙 ③ 저장소 readme 확인):
  · absmith.xml — Abbott-Smith 『A Manual Greek Lexicon of the New Testament』
    (1922) TEI 전사. github.com/translatable-exegetical-tools/Abbott-Smith.
    readme 가 public domain 을 명기. OCR 아님 — 헬라어 온전(실측).
  · 항목 5,896 · n="표제어|G번호" 꼴 — **스트롱 다리가 열쇠에 내장**
    (BDB 는 색인 파일이 따로 필요했다). G 없는 455 항목은 다리 없이 싣고,
    복수 G(εἰμί 등 굴절형 번호 나열 15항목)는 번호마다 다리를 만든다.

저장 (원본 재유도가 멱등의 정본 — §174차):
  sys_absmith_entry(as_id PK = n= 값(유일 실측) · grk · occurs · body)
  sys_absmith_map(strong · as_id)
  ⚠ body 는 <note type="occurrencesNT"> 를 뺀 전체 글 — BDB 의 <status> 함정과
    같은 자리(제외 순회). sense 번호는 **n= 속성에만** 있으므로 본문에 도로
    박아 준다(안 하면 뜻 갈래 번호가 통째로 사라진다 — 실측).

사용:
  python db_absmith_import.py --selftest   (의무)
  python db_absmith_import.py --load      (멱등 — 전체 재유도)
  python db_absmith_import.py --status
"""
import io
import os
import re
import sys
import xml.etree.ElementTree as ET

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

NS = '{http://www.crosswire.org/2013/TEIOSIS/namespace}'
RAW = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_lexicon_raw')

DDL_E = ("CREATE TABLE IF NOT EXISTS sys_absmith_entry("
         "as_id TEXT PRIMARY KEY, grk TEXT, occurs INTEGER, body TEXT)")
DDL_M = ("CREATE TABLE IF NOT EXISTS sys_absmith_map("
         "strong TEXT, as_id TEXT, PRIMARY KEY(strong, as_id))")


def _body(entry):
    """항목 본문 — occurrencesNT 노트를 빼고, sense 번호(n=)를 글에 박는다."""
    parts = []

    def walk(node):
        tag = node.tag
        if tag == NS + 'note' and node.get('type') == 'occurrencesNT':
            if node.tail:
                parts.append(node.tail)
            return
        if tag == NS + 'sense':
            n = node.get('n')
            if n:
                parts.append('\n%s ' % n)
        if node.text:
            parts.append(node.text)
        for ch in list(node):
            walk(ch)
        if node.tail:
            parts.append(node.tail)

    for ch in list(entry):
        walk(ch)
    txt = ''.join(parts)
    txt = re.sub(r'[ \t]+', ' ', txt)
    txt = re.sub(r' ?\n ?', '\n', txt)
    txt = re.sub(r'\n{2,}', '\n', txt)
    return txt.strip()


def parse_absmith(path=None):
    """→ [(as_id, grk, occurs, body)], [(strong 'G266', as_id)]."""
    tree = ET.parse(path or os.path.join(RAW, 'absmith.xml'))
    entries, maps = [], []
    for e in tree.getroot().iter(NS + 'entry'):
        key = e.get('n')
        if not key:
            continue
        orth = e.find('.//' + NS + 'orth')
        grk = ''.join(orth.itertext()).strip() if orth is not None \
            else key.split('|')[0]
        occ = None
        note = e.find(NS + 'note')
        if note is not None and note.get('type') == 'occurrencesNT':
            try:
                occ = int((note.text or '').strip())
            except ValueError:
                pass
        body = _body(e)
        if len(body) < 10:
            continue
        entries.append((key, grk, occ, body))
        for part in key.split('|')[1:]:
            if re.fullmatch(r'G\d+', part):
                maps.append((part, key))
    return entries, maps


def load(conn, entries=None, maps=None):
    if entries is None:
        entries, maps = parse_absmith()
    conn.execute(DDL_E)
    conn.execute(DDL_M)
    conn.execute('DELETE FROM sys_absmith_entry')
    conn.execute('DELETE FROM sys_absmith_map')
    conn.executemany('INSERT OR REPLACE INTO sys_absmith_entry VALUES(?,?,?,?)',
                     entries)
    conn.executemany('INSERT OR REPLACE INTO sys_absmith_map VALUES(?,?)',
                     sorted(set(maps or [])))
    conn.commit()
    print('Abbott-Smith 항목 %d · 스트롱 다리 %d'
          % (len(entries), len(set(maps or []))))


def status(conn):
    try:
        n = conn.execute('SELECT COUNT(*) FROM sys_absmith_entry').fetchone()[0]
        m = conn.execute('SELECT COUNT(*) FROM sys_absmith_map').fetchone()[0]
        j = conn.execute(
            "SELECT COUNT(DISTINCT m.strong) FROM sys_absmith_map m"
            " JOIN sys_lemma_master lm ON lm.strong=m.strong").fetchone()[0]
        print('항목 %d · 다리 %d · 마스터와 겹치는 스트롱 %d' % (n, m, j))
    except Exception as e:
        print('미적재 (%s)' % e)


def selftest():
    import sqlite3
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    entries, maps = parse_absmith()
    t('항목 5,000~6,500', 5000 <= len(entries) <= 6500, len(entries))
    t('다리 5,000+', len(set(maps)) >= 5000, len(set(maps)))
    keys = [e[0] for e in entries]
    t('as_id(n=) 유일', len(keys) == len(set(keys)))
    by = {k: e for k, e in zip(keys, entries)}
    m = {}
    for st, k in maps:
        m.setdefault(st, k)
    ham = by.get(m.get('G266', ''), None)
    t('하마르티아 실재·missing the mark 포함',
      bool(ham and 'missing the mark' in ham[3]),
      (ham[3][:40] if ham else ''))
    t('하마르티아 출현 수 173', bool(ham and ham[2] == 173))
    t('sense 번호가 본문에 박힌다', bool(ham and '\n1. ' in ham[3]))
    t('occurrencesNT 글자가 본문에 안 샌다',
      bool(ham and not ham[3].startswith('173')))
    t('복수 G 다리 — εἰμί G2076', 'G2076' in dict(maps))
    # 메모리 적재 왕복 — 멱등
    conn = sqlite3.connect(':memory:')
    load(conn, entries[:50], maps[:50])
    c0 = conn.execute('SELECT COUNT(*) FROM sys_absmith_entry').fetchone()[0]
    load(conn, entries[:50], maps[:50])
    c1 = conn.execute('SELECT COUNT(*) FROM sys_absmith_entry').fetchone()[0]
    t('멱등', c0 == c1 == 50)
    conn.close()
    print('db_absmith_import selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect('bible_master.db')
    try:
        if '--load' in sys.argv:
            load(conn)
        else:
            status(conn)
    finally:
        conn.close()
