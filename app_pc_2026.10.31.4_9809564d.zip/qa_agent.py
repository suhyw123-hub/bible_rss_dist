# -*- coding: utf-8 -*-
"""Q&A 비슷한 지난 질문 찾기 — **Claude Code 에이전트**에게 맡긴다 (2026-10-08 · docs/1.txt 57 ·
사용자 「유사한 기존 질문 db 를 조사할 db 를 claude code 로 지정하라 · agent 모델 방식 · 번역은 제미나이 등에게」).

  python qa_agent.py --selftest
  python qa_agent.py --find 문의번호          실제 문의에 대해 찾는다(admin_comm.db)
  python qa_agent.py --eval [--n N] [--model M]   시험 문의(qa_eval_fixture.json)로 정확도 — 글자 견주기와 나란히

★ 에이전트에게 주는 손 = `qa_search_tool.py` 의 **읽기 전용 명령 다섯**뿐(`--tools Bash` + 그 파일만 허용 ·
  `--permission-mode dontAsk` 로 나머지는 묻지 않고 막는다). 쓰기는 이 파일이 결과를 받아 `qa_ai` 표에 한다.
★ 에이전트는 **빈 작업 폴더**에서 돈다 — 앱 폴더에서 부르면 CLAUDE.md(수백 KB)를 통째로 읽어 느리고 비싸다.
★ 결과는 JSON 스키마로 못 박는다(`--json-schema`) · 꼴이 틀리면 실패로 돌려준다(지어내지 않는다).
⚠ 이 PC 에 Claude Code 가 깔리고 로그인돼 있어야 한다 — 관리자 PC 전용.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

APP = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, APP)
import qa_ai  # noqa: E402

MODEL = 'claude-sonnet-5-5'
BUDGET_USD = '1.00'
TIMEOUT = 300
WORK = os.path.join(tempfile.gettempdir(), 'hagah_claude_work', 'qa')

SCHEMA = {
    'type': 'object',
    'properties': {
        'items': {'type': 'array', 'items': {
            'type': 'object',
            'properties': {'kind': {'type': 'string', 'enum': ['QA', 'FAQ']},
                           'id': {'type': 'string'},
                           'v': {'type': 'string', 'enum': ['SAME', 'RELATED']},
                           'reuse': {'type': 'boolean'},
                           'why': {'type': 'string'}},
            'required': ['kind', 'id', 'v', 'reuse', 'why']}},
        'searched': {'type': 'array', 'items': {'type': 'string'}}},
    'required': ['items', 'searched']}

PROMPT = '''너는 성경 앱 「하가」의 관리자가 사용자 문의에 답하는 것을 돕는다.
새 문의와 **같은 물음**이거나 **답에 도움이 될** 지난 문의·FAQ 를 찾아라.

[쓸 수 있는 명령 — 이 폴더에서 Bash 로만, 다른 명령은 막혀 있다]
  python qa_tool.py search 낱말 [낱말 …]     지난 문의에서 찾기(낱말 하나라도 맞으면 나온다)
  python qa_tool.py get 문의번호              그 문의 전문(원문·한국어 번역·답)
  python qa_tool.py faq_search 낱말 [낱말 …]  FAQ 찾기
  python qa_tool.py faq_get FAQ번호           FAQ 전문
  python qa_tool.py list [개수]               최근 문의 요지

[하는 법]
1. 새 문의의 뜻을 풀어 **검색어를 여러 갈래로** 만든다 — 같은 뜻의 다른 낱말(휴대폰·핸드폰·폰 / 컴퓨터·PC /
   연결·잇다), 앱의 화면 이름(설정·모바일 연결·묵상노트·묵상플랜·글꼴·화면 색…). 최소 세 번 찾는다.
2. 걸린 후보는 반드시 get / faq_get 으로 **전문을 읽고** 판정한다. 요지만 보고 판정하지 않는다.
3. 판정 — SAME: 같은 물음(말이 달라도 묻는 것이 같다) · RELATED: 다른 물음이지만 그 답이 이번 답에 도움이 된다.
   그 밖은 버린다. 많아야 다섯.
4. reuse — SAME 이고 그 답을 그대로 보내도 될 때만 true. 답이 없거나, 앱이 바뀌어 낡았을 수 있거나, 다른
   사정을 전제한 답이면 false 로 하고 why 에 까닭을 적는다.
5. 찾지 못했으면 items 를 비운다. **지어내지 않는다.** id 는 도구가 보여 준 번호 그대로(FAQ 는 숫자만).
6. searched 에 실제로 쓴 검색어를 모두 적는다.

[새 문의]
언어: {lang}
원문: {orig}
한국어 번역: {ko}'''

STUB = '''import os, runpy, sys
APP = {app!r}
sys.path.insert(0, APP)
sys.argv = [os.path.join(APP, 'qa_search_tool.py')] + sys.argv[1:]
runpy.run_path(sys.argv[0], run_name='__main__')
'''


def claude_bin():
    return shutil.which('claude') or shutil.which('claude.cmd') or shutil.which('claude.exe')


def _workdir():
    os.makedirs(WORK, exist_ok=True)
    with open(os.path.join(WORK, 'qa_tool.py'), 'w', encoding='utf-8') as f:
        f.write(STUB.format(app=APP))
    return WORK


def run_agent(lang, orig, ko, exclude='', qa_db=None, faq_db=None, model=None, runner=None):
    """에이전트 한 번 → {'ok', 'items', 'searched', 'sec', 'cost', 'why'} — 부르기는 `claude_run` 한 문."""
    import claude_run
    prompt = PROMPT.format(lang=lang, orig=qa_ai.scrub(orig), ko=qa_ai.scrub(ko or orig))
    env = {'QA_EXCLUDE': exclude or ''}
    if qa_db:
        env['QA_DB'] = qa_db
    if faq_db:
        env['QA_FAQ_DB'] = faq_db
    res = claude_run.run('QA_SIMILAR', prompt, SCHEMA, tools='Bash', allowed=['Bash(python qa_tool.py:*)'],
                         env=env, cwd=_workdir(), model=model or MODEL, budget=BUDGET_USD,
                         timeout=TIMEOUT, runner=runner)
    return dict(_items(res), sec=res.get('sec'))


def _items(res):
    if not res.get('ok'):
        return {'ok': False, 'why': res.get('why', ''), 'cost': res.get('cost')}
    so = res.get('data') or {}
    if not isinstance(so.get('items'), list):
        return {'ok': False, 'why': '정해진 꼴이 아닙니다', 'cost': res.get('cost')}
    items = []
    for x in so['items'][:5]:
        if x.get('kind') in ('QA', 'FAQ') and x.get('v') in ('SAME', 'RELATED') and str(x.get('id', '')).strip():
            items.append({'kind': x['kind'], 'id': str(x['id']).strip(), 'v': x['v'],
                          'reuse': bool(x.get('reuse')) and x['v'] == 'SAME', 'why': str(x.get('why', ''))[:300]})
    return {'ok': True, 'items': items, 'searched': so.get('searched') or [],
            'cost': res.get('cost'), 'turns': res.get('turns')}


def parse_out(out):
    import claude_run
    return _items(claude_run.parse(out))


def find(msg_id, model=None):
    """실제 문의 — 결과를 `qa_ai.sim_json` 에 담는다(앱이 쓴다 · 에이전트는 못 쓴다)."""
    c = qa_ai.conn()
    try:
        r = qa_ai.row(c, msg_id)
        if not r:
            return {'ok': False, 'why': '문의가 없습니다'}
        res = run_agent(r['lang'], r['question'], r.get('q_ko'), exclude=msg_id, model=model)
        if res.get('ok'):
            qa_ai._put(c, msg_id, sim_json=json.dumps(dict(res, by='CLAUDE_AGENT'), ensure_ascii=False))
        return res
    finally:
        c.close()


# ── 시험 ──────────────────────────────────────────────────────────────────
def build_eval_db(path, fx):
    if os.path.exists(path):
        os.remove(path)
    c = qa_ai.conn(path)
    for i, (mid, lang, q, rep, qko) in enumerate(fx['past']):
        c.execute('INSERT INTO qa(msg_id,lang,question,reply,ts) VALUES(?,?,?,?,?)',
                  (mid, lang, q, rep, '2026-09-%02d' % (1 + i % 28)))
        if qko:
            c.execute('INSERT INTO qa_ai(msg_id,q_ko) VALUES(?,?)', (mid, qko))
    c.execute("CREATE TABLE sys_faq_text(faq_id INTEGER, lang_code TEXT, question TEXT, answer TEXT,"
              " record_status TEXT DEFAULT 'LIVE')")
    c.executemany("INSERT INTO sys_faq_text(faq_id,lang_code,question,answer) VALUES(?,'KO',?,?)", fx['faq'])
    c.commit()
    c.close()


def _score(want, got):
    want, got = set(want), set(got)
    return len(want & got), len(want), len(got - want)


def evaluate(n=None, model=None, log=print):
    fx = json.load(open(os.path.join(APP, 'qa_eval_fixture.json'), encoding='utf-8'))
    db = os.path.join(_workdir(), 'eval_qa.db')
    build_eval_db(db, fx)
    qs = fx['queries'][:n] if n else fx['queries']
    tot = {'agent': [0, 0, 0], 'gram': [0, 0, 0]}
    lines, cost, sec = [], 0.0, 0.0
    faq_rows = [(f, q, a) for f, q, a in fx['faq']]
    for qid, lang, orig, ko, want in qs:
        # 글자 견주기(비교 잣대) — 새 질문을 잠깐 넣어 qa_ai.similar 로 잰다
        c = qa_ai.conn(db)
        c.execute('INSERT OR REPLACE INTO qa(msg_id,lang,question,ts) VALUES(?,?,?,?)', (qid, lang, orig, '2026-10-08'))
        c.execute('INSERT OR REPLACE INTO qa_ai(msg_id,q_ko) VALUES(?,?)', (qid, ko))
        c.commit()
        gram = [('F%s' % x['id']) if x['kind'] == 'FAQ' else x['id'] for x in qa_ai.similar(c, qid, 5, faq_rows)]
        c.execute('DELETE FROM qa WHERE msg_id=?', (qid,))
        c.execute('DELETE FROM qa_ai WHERE msg_id=?', (qid,))
        c.commit()
        c.close()
        res = run_agent(lang, orig, ko, exclude=qid, qa_db=db, faq_db=db, model=model)
        agent = [('F%s' % x['id']) if x['kind'] == 'FAQ' else x['id'] for x in res.get('items', [])
                 if x['v'] == 'SAME'] if res.get('ok') else []
        for k, got in (('agent', agent), ('gram', gram)):
            h, w, extra = _score(want, got)
            tot[k][0] += h
            tot[k][1] += w
            tot[k][2] += extra if k == 'agent' else 0
        cost += res.get('cost') or 0
        sec += res.get('sec') or 0
        line = '%s 정답 %s | 에이전트 SAME %s %s| 글자견주기 %s | %s초 · 검색어 %s' % (
            qid, want or '[]', agent, '' if res.get('ok') else '(실패: %s) ' % res.get('why', '')[:80],
            gram, res.get('sec'), ', '.join(res.get('searched') or [])[:120])
        lines.append(line)
        log(line)
    summ = ('정답 찾은 수 — 에이전트 %d/%d · 글자 견주기(다섯 안) %d/%d · 에이전트가 정답 밖 SAME 으로 낸 것 %d · '
            '비용 $%.2f · 평균 %.0f초' % (tot['agent'][0], tot['agent'][1], tot['gram'][0], tot['gram'][1],
                                     tot['agent'][2], cost, sec / max(1, len(qs))))
    lines.append(summ)
    with open(os.path.join(APP, '_qa_agent_eval.txt'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))
    log(summ)
    return tot


def selftest():
    n = [0, 0]

    def ck(c, m):
        n[0] += 1
        n[1] += bool(c)
        if not c:
            print('  FAIL', m)
    good = json.dumps({'is_error': False, 'total_cost_usd': 0.05, 'num_turns': 6, 'structured_output': {
        'items': [{'kind': 'QA', 'id': 'p01', 'v': 'SAME', 'reuse': True, 'why': '같은 물음'},
                  {'kind': 'FAQ', 'id': '901', 'v': 'RELATED', 'reuse': True, 'why': 'x'},
                  {'kind': 'QA', 'id': 'zz', 'v': 'NONE', 'reuse': False, 'why': ''}],
        'searched': ['휴대폰', 'PC']}})
    r = parse_out(good)
    ck(r['ok'] and len(r['items']) == 2, '정해진 꼴을 읽는다 · 모르는 판정은 버린다')
    ck(r['items'][1]['reuse'] is False, 'RELATED 는 그대로 보내기(reuse) 안 됨')
    ck(not parse_out('엉망')['ok'], '못 읽으면 실패')
    ck(not parse_out(json.dumps({'is_error': True, 'result': 'budget'}))['ok'], '에이전트 실패를 알린다')
    seen = {}

    def fake_runner(cmd, env):
        seen['cmd'], seen['env'] = cmd, env
        return good
    res = run_agent('PT', 'Como conecto? a@b.com', '연결은?', exclude='q1', runner=fake_runner)
    ck(res['ok'], '가짜 실행기로 한 바퀴')
    cmd = seen['cmd']
    ck(cmd[cmd.index('--allowedTools') + 1] == 'Bash(python qa_tool.py:*)', '허용 도구 = 읽기 도구 하나')
    ck(cmd[cmd.index('--permission-mode') + 1] == 'dontAsk', '나머지는 묻지 않고 막는다')
    ck('a@b.com' not in cmd[cmd.index('-p') + 1], '이메일은 가려서 보낸다')
    ck(seen['env']['QA_EXCLUDE'] == 'q1', '새 문의 자신은 찾지 않는다')
    ck('{lang}' not in cmd[cmd.index('-p') + 1], '프롬프트가 채워졌다')
    stub = open(os.path.join(_workdir(), 'qa_tool.py'), encoding='utf-8').read()
    ck('qa_search_tool.py' in stub and 'runpy' in stub, '작업 폴더의 도구 껍데기')
    ck(not os.path.exists(os.path.join(WORK, 'CLAUDE.md')), '작업 폴더에 CLAUDE.md 없음')
    print('qa_agent selftest %d/%d' % (n[1], n[0]))
    return n[0] == n[1]


def main(argv):
    if '--selftest' in argv:
        return 0 if selftest() else 1
    model = argv[argv.index('--model') + 1] if '--model' in argv else None
    if '--find' in argv:
        print(json.dumps(find(argv[argv.index('--find') + 1], model), ensure_ascii=False, indent=1))
    elif '--eval' in argv:
        k = int(argv[argv.index('--n') + 1]) if '--n' in argv else None
        evaluate(k, model)
    else:
        print(__doc__)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
