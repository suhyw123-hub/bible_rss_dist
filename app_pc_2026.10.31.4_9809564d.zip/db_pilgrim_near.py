# -*- coding: utf-8 -*-
"""성지순례 **장소 ↔ 장소 실제 도로 거리**(2026-10-29 신설 · 영구 · 사용자 「헐몬산을 누르면 반경 xkm 의 유적지 ·
구석에 있는 것을 누르면 그것을 중심으로 펼쳐진다 · 실제 이동거리 계산된 것을 기준으로 판단하자」).

★ 대상 = 성경 장소(P · 순례 지역 98) + 순례 장소(S · 승인 · 성경 장소와 같은 곳은 뺀다) · 직선 MAX_KM 안의 모든 쌍.
★ 이 PC 의 도로 엔진(GraphHopper · localhost:8989)으로 잰다 — 거리·시간만 담는다(선 모양은 안 담는다 · 폰 팩을 키우지 않게).
★ 쌍은 한 번만 — (a, b) 는 열쇠 글자 차례(a < b · 'P12' < 'S5').
  길에서 먼 점(산꼭대기·광야)은 엔진이 거절한다 → 가장 가까운 길로 옮겨 다시(db_place_road.snap · 거점 둘레와 같은 문).

표(CORE · 폰 공통팩)
  sys_pilgrim_near  a_key TEXT · b_key TEXT · km REAL · minutes REAL · PRIMARY KEY(a_key, b_key)
                    열쇠 = 'P<용어 번호>' | 'S<sys_pilgrim_site.site_id>'

  python db_pilgrim_near.py --selftest | --run [--redo] | --status
"""
import sys
import urllib.error

import appdb
import db_place_road as R

MAX_KM = 32.0      # 직선 — 폰이 고르는 반경(도로 10·20·30km)을 다 덮는다(도로는 직선보다 길다)

DDL = """CREATE TABLE IF NOT EXISTS sys_pilgrim_near(
    a_key TEXT NOT NULL, b_key TEXT NOT NULL, km REAL, minutes REAL, PRIMARY KEY(a_key, b_key))"""


def ensure(conn):
    conn.execute(DDL)


def points(conn):
    """[(열쇠, 위도, 경도)]"""
    out = [('P%d' % p[0], p[1], p[2]) for p in R.places(conn, 'ALL')]
    try:
        out += [('S%d' % r[0], r[1], r[2]) for r in conn.execute(
            "SELECT site_id, lat, lng FROM sys_pilgrim_site WHERE status='LIVE'"
            " AND CAST(COALESCE(same_place,0) AS INTEGER)=0 AND lat IS NOT NULL")]
    except Exception:                                   # noqa: BLE001
        pass
    return out


def pairs(pts, max_km=MAX_KM):
    out = []
    for i in range(len(pts)):
        for j in range(i + 1, len(pts)):
            a, b = pts[i], pts[j]
            if R.km(a, b) <= max_km:
                out.append((a, b) if a[0] < b[0] else (b, a))
    return out


def run(conn, redo=False, base=None, say=print):
    ensure(conn)
    have = set() if redo else {(r[0], r[1]) for r in conn.execute('SELECT a_key, b_key FROM sys_pilgrim_near')}
    todo = [p for p in pairs(points(conn)) if (p[0][0], p[1][0]) not in have]
    ok = fail = 0
    for n, (a, b) in enumerate(todo, 1):
        eng = base or R.engine_of(a[1], a[2])          # ★ 그 권역 엔진(튀르키예·그리스 = GH2)
        try:
            try:
                path = R._gh_path(eng, a, b, False)
            except urllib.error.HTTPError as e:
                if e.code != 400:
                    raise
                path = R._gh_path(eng, R.snap(a), R.snap(b), False)
            if path:
                conn.execute('INSERT OR REPLACE INTO sys_pilgrim_near VALUES(?,?,?,?)',
                             (a[0], b[0], round(path['distance'] / 1000.0, 2), round(path['time'] / 60000.0, 1)))
                ok += 1
            else:
                fail += 1
        except Exception:                               # noqa: BLE001
            fail += 1
            conn.execute('DELETE FROM sys_pilgrim_near WHERE a_key=? AND b_key=?', (a[0], b[0]))
        if n % 200 == 0:
            conn.commit()                               # ⚠ 쉬는 동안 잠금을 쥐지 않게(db_place_road 함정)
        if n % 1000 == 0:
            say('  %d/%d (받음 %d · 실패 %d)' % (n, len(todo), ok, fail))
    conn.commit()
    return len(todo), ok, fail


def status(conn):
    ensure(conn)
    pts = points(conn)
    n = conn.execute('SELECT COUNT(*) FROM sys_pilgrim_near').fetchone()[0]
    print('점 %d · 잴 쌍 %d · 잰 쌍 %d' % (len(pts), len(pairs(pts)), n))
    for r in (10, 20, 30):
        m = conn.execute('SELECT COUNT(*) FROM sys_pilgrim_near WHERE km<=?', (r,)).fetchone()[0]
        print('  도로 %dkm 안 쌍 %d' % (r, m))


def selftest():
    import sqlite3
    ok, bad = [0], [0]

    def ck(c, m, got=''):
        (ok if c else bad)[0] += 1
        print('  %s %s%s' % ('OK  ' if c else 'FAIL', m, '' if c else '  ← %s' % (got,)))
    pts = [('P1', 31.77, 35.23), ('S9', 31.705, 35.20), ('P2', 32.80, 35.53), ('S10', 31.78, 35.24)]
    ps = pairs(pts)
    keys = {(a[0], b[0]) for a, b in ps}
    ck(('P1', 'S9') in keys and ('P1', 'S10') in keys, '가까운 쌍', keys)
    ck(not any('P2' in k for k in keys), '먼 곳(갈릴리)은 안 잰다', keys)
    ck(all(a < b for a, b in keys), '쌍은 한 번 · 열쇠 차례', keys)
    c = sqlite3.connect(':memory:')
    ensure(c)
    c.execute("INSERT INTO sys_pilgrim_near VALUES('P1','S9',11.2,18.0)")
    ensure(c)
    ck(c.execute('SELECT COUNT(*) FROM sys_pilgrim_near').fetchone()[0] == 1, '두 번 만들어도 그대로')
    print('\ndb_pilgrim_near selftest %d/%d' % (ok[0], ok[0] + bad[0]))
    return bad[0] == 0


def main(a):
    if '--selftest' in a:
        return 0 if selftest() else 1
    conn = appdb.connect()
    if '--run' in a:
        print('잴 것 %d · 받음 %d · 실패 %d' % run(conn, redo='--redo' in a))
    status(conn)
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
