"""
plan_builder.py
Kingdom Mediators & Oppressors — 인물묵상 플랜 빌더

필터 선택 → 유닛 미리보기 → **user_bible_plan + user_plan_schedule** 생성. 블록(`unit_pool`)은 sys 에서 읽고 **조립 결과만** user 에 쓴다 — `sys_*` 는 배포용이라 콘텐츠 교체 때 사라진다(§0-6 C-2).
데이터 원본: unit_pool / figure_pool 테이블 (별도 import 스크립트로 구축).

사용:
    python plan_builder.py        # 독립 실행
    from plan_builder import PlanBuilderDialog  # plan_panel 등에서 호출
"""

import re
import sqlite3
import appdb
import i18n
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime

DB_PATH = "bible_master.db"

# ────────────────────────────────────────────────────────────────────
# 마스터 상수
# ────────────────────────────────────────────────────────────────────

OFFICES = ['왕', '제사장', '선지자', '족장', '제자', '이방인']
OFFICE_SH = {
    '왕': '왕', '제사장': '제', '선지자': '선', '족장': '족',
    '제자': '제자', '이방인': '이방',
}

ERAS = [
    '족장기', '출애굽·정복', '사사', '통일왕국', '분열왕국',
    '포로·귀환', '공생애', '초대교회',
]
ERA_SH = {
    '족장기':     '족장',
    '출애굽·정복': '출애굽',
    '사사':       '사사',
    '통일왕국':    '통일왕',
    '분열왕국':    '분열',
    '포로·귀환':   '포로기',
    '공생애':     '공생애',
    '초대교회':    '초대',
}
OT_ERAS = {'족장기', '출애굽·정복', '사사', '통일왕국', '분열왕국', '포로·귀환'}
NT_ERAS = {'공생애', '초대교회'}

PHASES = ['ORIGIN', 'CALL', 'TRAIN', 'ENCOUNTER', 'PEAK',
          'CRISIS', 'FALL', 'TURN', 'LEGACY']
PHASE_KO = {
    'ORIGIN': '기원', 'CALL': '소명',    'TRAIN': '훈련',
    'ENCOUNTER': '만남', 'PEAK': '전성', 'CRISIS': '위기',
    'FALL': '실패',   'TURN': '회복',   'LEGACY': '유산',
}

TYPOLOGIES = ['TYPE', 'ANTI', 'SHADOW']
TYPO_KO = {'TYPE': '예표', 'ANTI': '대조', 'SHADOW': '그림자'}
TYPO_COMBO = {
    frozenset(['TYPE']):           '예표',
    frozenset(['ANTI']):           '대조',
    frozenset(['SHADOW']):         '그림자',
    frozenset(['TYPE', 'ANTI']):   '예표+대조',
    frozenset(['TYPE', 'SHADOW']): '예표+그림자',
    frozenset(['ANTI', 'SHADOW']): '대조+그림자',
}

ALL_OFFICES = set(OFFICES)
ALL_ERAS    = set(ERAS)
ALL_PHASES  = set(PHASES)
ALL_TYPOS   = set(TYPOLOGIES)


# ────────────────────────────────────────────────────────────────────
# 플랜명 자동 생성
# ────────────────────────────────────────────────────────────────────


def _readable(name, dflt):
    """사용자가 만든 플랜 이름을 사람이 읽는 말로 (2026-08-16).

    ⚠ 자동 이름이 `기적_3수행자_4유형_쌍순_26` 처럼 **코드**였다.
      밑줄을 공백으로, 끝의 두 자리 연도를 뗀다. 비면 기본 이름.
    """
    import re
    s = (name or '').replace('_', ' ')
    s = re.sub(r"\s*'?\d{2}\s*$", '', s)      # 끝의 `_26` · `'26`
    s = ' '.join(s.split())
    return s or dflt


# 이름에 못 쓰는 글자 — **줄바꿈·탭 같은 제어문자뿐**이다.
_NAME_BAD  = re.compile(r'[\x00-\x1f\x7f]')
NAME_MAX   = 40


def check_plan_name(name, parent):
    """플랜 이름 검사. 성사되면 다듬은 이름을, 아니면 알리고 `None`.

    ★ **이름은 코드가 아니라 제목이다** (2026-08-16 사용자 지적).
      옛 검사는 「공백·특수문자 금지」였는데, 바로 앞줄의 `_readable()` 이
      밑줄을 **공백으로 바꾼 뒤**라 **시스템이 지어 준 이름이 자기 검사에 걸렸다**
      (`기적 3수행자 4유형 쌍순` → 「공백을 쓸 수 없습니다」). 자동 이름은
      `·` 도 쓴다(`치유·부활`). 사용자는 손댄 적이 없는데 거부당했다.
      ⇒ **읽으라고 만든 이름에 공백을 금지하는 규칙 자체가 틀렸다.** 없앤다.

    ⚠ 이 값이 들어가는 `plan_code` 는 **화면에 보이는 제목**이지 식별자가 아니다
      (식별자는 `user_plan_id`). SQL 은 전부 자리표(`?`)라 따옴표도 안전하다.
    ⚠ **줄바꿈·탭은 거부하지 않고 공백 한 칸으로 누른다** — `split()` 이 먼저
      처리하므로 사용자는 아무 방해도 받지 않는다. 콤보·트리 한 줄이 깨지는 것만
      막으면 되고, 그건 눌러 주면 끝난다. 아래 검사에 걸리는 것은 `\\x00` 같은
      **공백이 아닌 제어문자**뿐이다(붙여넣기 사고).
    """
    s = ' '.join((name or '').split())
    if not s:
        messagebox.showwarning(i18n.t('COMMON_WARNING', '경고'),
                               i18n.t('MSG_ENTER_PLANNAME', '플랜명을 입력하세요.'),
                               parent=parent)
        return None
    if _NAME_BAD.search(s):
        messagebox.showwarning(
            i18n.t('COMMON_WARNING', '경고'),
            i18n.t('MSG_PLANNAME_CTRL', '플랜명에 쓸 수 없는 글자가 있습니다.'),
            parent=parent)
        return None
    if len(s) > NAME_MAX:
        messagebox.showwarning(
            i18n.t('COMMON_WARNING', '경고'),
            i18n.t('MSG_PLANNAME_LONG',
                   '플랜명은 {n}자 이내로 입력하세요.').format(n=NAME_MAX),
            parent=parent)
        return None
    return s


def unique_sibling_name(conn, base, origin_plan_id):
    """같은 기원 아래에서만 겹치지 않게 한다 (2026-08-16 서브트리).

    ★ 예전에는 `user_bible_plan` **전체**에서 겹침을 봤다. 그런데 서브트리를 넣고
      이름에서 갈래말을 떼자 인물 쪽 「전체」와 기적 쪽 「전체」가 부딪혀
      **두 번째가 `전체 (1)` 이 됐다.** 트리에서는 부모가 달라 헷갈릴 일이 없는데
      쓸데없는 꼬리표가 붙은 것이다 — 서브트리로 없애려던 바로 그 잡음이다.
      ⇒ **형제끼리만** 본다.

    ⚠ `plan_code` 에 UNIQUE 제약이 없다(실측). 겹쳐도 DB 는 받지만 화면에서
      두 줄이 같아 보이므로 여기서 막는다.
    """
    name, n = base, 1
    while conn.execute(
            "SELECT 1 FROM user_bible_plan WHERE plan_code=? AND origin_plan_id=? "
            "AND COALESCE(record_status,'LIVE')='LIVE'", (name, origin_plan_id)).fetchone():
        # ⚠ `_2` 로 붙이면 제목에 밑줄이 되돌아온다(이름 규칙 ②).
        name = '%s (%d)' % (base, n)
        n += 1
    return name


def generate_plan_name(
    figures:    list[str],
    offices:    list[str],
    eras:       list[str],
    typologies: list[str],
    phases:     list[str],
) -> str:
    """
    필터 선택 조합 → 간결한 플랜명.
    - '전체' 선택 차원은 생략.
    - 인물 직접 선택 시 인물명 우선, 직분·시대 생략.
    - 구분자: 차원 간 '_', 다중값 내 '·'.
    - 연도 접미사: '_26' 형식 (특수문자 없음).
    """
    parts: list[str] = []
    yr = str(datetime.now().year)[-2:]

    s_off = set(offices)
    s_era = set(eras)
    s_typ = set(typologies)
    s_pha = set(phases)

    if figures:
        if len(figures) == 1:
            parts.append(figures[0])
        elif len(figures) == 2:
            parts.append('·'.join(figures))
        else:
            parts.append(f'{len(figures)}인물')
    else:
        if s_off != ALL_OFFICES:
            if len(offices) == 1:
                parts.append(offices[0])
            elif len(offices) <= 3:
                parts.append('·'.join(OFFICE_SH[o] for o in offices))
            else:
                parts.append(f'{len(offices)}직분')

        if s_era != ALL_ERAS:
            ot_sel = s_era & OT_ERAS
            nt_sel = s_era & NT_ERAS
            if ot_sel == OT_ERAS and not nt_sel:
                parts.append('구약')
            elif nt_sel == NT_ERAS and not ot_sel:
                parts.append('신약')
            elif len(eras) == 1:
                parts.append(ERA_SH[eras[0]])
            elif len(eras) == 2:
                parts.append('·'.join(ERA_SH[e] for e in eras))
            else:
                parts.append(f'{len(eras)}시대')

    if s_typ != ALL_TYPOS:
        parts.append(TYPO_COMBO.get(
            frozenset(typologies),
            '+'.join(TYPO_KO[t] for t in typologies)
        ))

    if s_pha != ALL_PHASES:
        if len(phases) == 1:
            parts.append(PHASE_KO[phases[0]])
        elif len(phases) == 2:
            parts.append('·'.join(PHASE_KO[p] for p in phases))
        else:
            parts.append(f'{len(phases)}국면')

    #  ★ 아무것도 안 걸렀으면 그냥 **「전체」** 다 (2026-08-16 서브트리 도입).
    #    트리에서 이 플랜은 「인물 묵상」 마디 아래에 놓이므로 「전체묵상」이라고
    #    되풀이할 필요가 없다.
    base = '_'.join(parts) if parts else '전체'
    return f"{base}_{yr}"


# ────────────────────────────────────────────────────────────────────
# FilterRow — 한 차원을 **한 줄**로 (2026-08-16 사용자 지시)
# ────────────────────────────────────────────────────────────────────

class FilterRow:
    """한 필터 차원 = 한 줄. 「좌에서 우로 열거하여 한눈에 줄줄이」.

    ⚠ **위젯이 아니라 배치기다.** 자기 프레임을 만들지 않고 **부모의 grid 에 직접**
      라벨·전체·구분선·항목칸을 놓는다. 그래야 여러 줄을 쌓았을 때 **라벨 열이
      저절로 정렬**된다. 각 줄을 LabelFrame 으로 감싸면 줄마다 폭이 따로 놀아
      「줄줄이」가 되지 않는다.

    ⚠ 항목은 한 줄에 다 들어가야 한다 — 두 줄로 접히면 아래 줄과 뒤섞여
      어느 차원의 항목인지 알 수 없다. 넣기 전에 `python plan_builder.py --measure`
      로 실제 폰트에서 재 본다.

    바깥에서 쓰는 것은 `get_selected()` · `is_all()` 셋뿐(옛 FilterGroup 과 같다).
    """

    def __init__(self, parent, row: int, label: str, items: list[str],
                 display: dict | None = None, on_change=None):
        self._items     = list(items)
        self._display   = display or {}
        self._on_change = on_change
        self._vars: dict[str, tk.BooleanVar] = {}
        self._all_var   = tk.BooleanVar(value=True)
        self._lock      = False

        ttk.Label(parent, text=label).grid(
            row=row, column=0, sticky='w', padx=(2, 8), pady=2)
        ttk.Checkbutton(parent, text=i18n.t('COMMON_ALL', '전체'),
                        variable=self._all_var, command=self._on_all).grid(
            row=row, column=1, sticky='w')
        ttk.Separator(parent, orient='vertical').grid(
            row=row, column=2, sticky='ns', padx=6, pady=1)

        box = ttk.Frame(parent)
        box.grid(row=row, column=3, sticky='w')
        for item in self._items:
            var = tk.BooleanVar(value=True)
            self._vars[item] = var
            ttk.Checkbutton(box, text=self._display.get(item, item),
                            variable=var, command=self._on_item).pack(
                side='left', padx=(0, 8))

    def _on_all(self):
        if self._lock:
            return
        self._lock = True
        state = self._all_var.get()
        for v in self._vars.values():
            v.set(state)
        self._lock = False
        if self._on_change:
            self._on_change()

    def _on_item(self):
        if self._lock:
            return
        self._lock = True
        all_checked = bool(self._vars) and all(v.get() for v in self._vars.values())
        self._all_var.set(all_checked)
        self._lock = False
        if self._on_change:
            self._on_change()

    def get_selected(self) -> list[str]:
        if self._all_var.get():
            return list(self._items)
        return [k for k, v in self._vars.items() if v.get()]

    def is_all(self) -> bool:
        return self._all_var.get()

    # ⚠ 옛 `FilterGroup.set_items` 는 두지 않았다 — 부르는 곳이 한 곳도 없었고,
    #   이 배치기는 부모 grid 에 직접 놓으므로 「자기 안을 다시 그리기」가 성립하지
    #   않는다. 항목이 바뀌는 차원이 생기면 그때 줄 전체를 다시 만든다.


# ────────────────────────────────────────────────────────────────────
# ScrollableFigureList — 스크롤 가능한 인물 체크리스트
# ────────────────────────────────────────────────────────────────────

class ScrollableFigureList(ttk.LabelFrame):
    """
    50명 이상 인물을 수직 스크롤로 표시하는 체크리스트.
    '전체' 토글이 스크롤 영역 바깥 고정 위치에 있어 항상 보임.
    """

    def __init__(self, parent, on_change=None, **kw):
        super().__init__(parent, text=i18n.t('COMMON_PERSON','인물'), padding=(4, 2), **kw)
        self._on_change = on_change
        self._vars: dict[str, tk.BooleanVar] = {}
        self._items: list[str] = []
        self._all_var = tk.BooleanVar(value=True)
        self._lock    = False

        # 전체 토글 (스크롤 밖, 고정)
        top_f = ttk.Frame(self)
        top_f.pack(fill='x')
        ttk.Checkbutton(top_f, text=i18n.t('COMMON_ALL','전체'), variable=self._all_var,
                        command=self._on_all).pack(side='left')
        ttk.Separator(self, orient='horizontal').pack(fill='x', pady=1)

        # 스크롤 가능 영역
        scroll_f = ttk.Frame(self)
        scroll_f.pack(fill='both', expand=True)

        self._canvas = tk.Canvas(scroll_f, highlightthickness=0)
        vsb = ttk.Scrollbar(scroll_f, orient='vertical',
                             command=self._canvas.yview)
        self._canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side='right', fill='y')
        self._canvas.pack(side='left', fill='both', expand=True)

        self._inner = ttk.Frame(self._canvas)
        self._win_id = self._canvas.create_window(
            (0, 0), window=self._inner, anchor='nw')

        self._inner.bind(
            '<Configure>',
            lambda e: self._canvas.configure(
                scrollregion=self._canvas.bbox('all')))
        self._canvas.bind(
            '<Configure>',
            lambda e: self._canvas.itemconfig(self._win_id, width=e.width))
        self._canvas.bind(
            '<MouseWheel>',
            lambda e: self._canvas.yview_scroll(-1 * (e.delta // 120), 'units'))

    # ── 이벤트 ──────────────────────────────────────────────────────

    def _on_all(self):
        if self._lock:
            return
        self._lock = True
        state = self._all_var.get()
        for v in self._vars.values():
            v.set(state)
        self._lock = False
        if self._on_change:
            self._on_change()

    def _on_item(self):
        if self._lock:
            return
        self._lock = True
        all_checked = (bool(self._vars) and
                       all(v.get() for v in self._vars.values()))
        self._all_var.set(all_checked)
        self._lock = False
        if self._on_change:
            self._on_change()

    # ── 공개 API ────────────────────────────────────────────────────

    def set_items(self, items: list[str]):
        self._items = list(items)
        for w in self._inner.winfo_children():
            w.destroy()
        self._vars = {}
        for item in self._items:
            var = tk.BooleanVar(value=True)
            self._vars[item] = var
            ttk.Checkbutton(self._inner, text=item, variable=var,
                            command=self._on_item).pack(anchor='w', padx=2)
        self._canvas.update_idletasks()
        self._canvas.configure(scrollregion=self._canvas.bbox('all'))

    def restore_selection(self, prev_all: bool, prev_sel: set):
        """set_items() 후 이전 선택 상태 복원 (전체 해제 상태 포함)."""
        if not prev_all:
            self._lock = True
            for item, var in self._vars.items():
                var.set(item in prev_sel)
            all_checked = (bool(self._vars) and
                           all(v.get() for v in self._vars.values()))
            self._all_var.set(all_checked)
            self._lock = False

    def get_selected(self) -> list[str]:
        if self._all_var.get():
            return list(self._items)
        return [k for k, v in self._vars.items() if v.get()]

    def is_all(self) -> bool:
        return self._all_var.get()


# ────────────────────────────────────────────────────────────────────
# PlanBuilderDialog
# ────────────────────────────────────────────────────────────────────

class PlanBuilderDialog(tk.Toplevel):
    """
    Kingdom Mediators 인물묵상 플랜 빌더.

    좌1) 시대·직분 필터 (수직, 스크롤)
    좌2) 인물 목록 (스크롤 체크리스트)
    우상) 국면·예표구분 (수평 그리드)
    우중) 플랜명·버튼·유닛수 (컨트롤)
    우하) 매칭 유닛 목록 (트리뷰)
    """

    def __init__(self, parent, db_path: str = DB_PATH):
        super().__init__(parent)
        self.db_path = db_path
        self.title(i18n.t('WIN_BIO_PLAN', '인물묵상 플랜 만들기'))
        self.geometry('980x680')
        self.resizable(True, True)
        self.minsize(820, 520)

        self._all_units: list[dict] = []
        self._filtered:  list[dict] = []

        self._build_ui()
        self._load_units()
        self._refresh()
        self.grab_set()

    # ── UI 구성 ──────────────────────────────────────────────────────

    def _build_ui(self):
        """상단 필터 한 줄 · 왼쪽 인물명단 · 오른쪽 설정+목록 (2026-08-16 사용자 지시).

        ⚠ **인물이 늘어날 것**이라 왼쪽 기둥을 통째로 인물에게 준다. 필터를 옆에 두면
          인물이 30명이 됐을 때 스크롤이 두 겹이 된다.
        """
        cb = self._refresh
        # ★ 2026-10-20 docs/1.txt 5-2 — 세 창 공통 틀(`builder_shell`): 맨 위 플랜 이름·단추 ·
        #   가운데 체크 줄 | 오른쪽 큰 수(유닛 · 묵상기간) · 아래 목록. 옛 「플랜 설정」 칸은 걷었다.
        import builder_shell
        self._shell = builder_shell.Shell(self, self._create_plan)
        self._name_var = self._shell.name_var
        self._name_entry = self._shell.name_entry
        top = self._shell.filters
        self._fg_era    = FilterRow(top, 0, i18n.t('PB_ERA', '시대'),   ERAS,
                                    on_change=cb)
        self._fg_office = FilterRow(top, 1, i18n.t('PB_OFFICE', '직분'), OFFICES,
                                    on_change=cb)
        self._fg_phase  = FilterRow(top, 2, i18n.t('PB_PHASE', '국면'),  PHASES,
                                    display=PHASE_KO, on_change=cb)
        self._fg_typo   = FilterRow(top, 3, i18n.t('PB_TYPO', '예표'),   TYPOLOGIES,
                                    display=TYPO_KO, on_change=cb)

        # ── 아래: 좌 인물명단 | 우 목록 ──────────────────────────────
        outer = ttk.PanedWindow(self._shell.body, orient='horizontal')
        outer.pack(fill='both', expand=True)

        left_f = ttk.Frame(outer, width=190)
        left_f.pack_propagate(False)
        outer.add(left_f, weight=0)
        self._fig_list = ScrollableFigureList(left_f, on_change=cb)
        self._fig_list.pack(fill='both', expand=True)

        right_f = ttk.Frame(outer, padding=(6, 0, 0, 0))
        outer.add(right_f, weight=1)
        right_f.grid_columnconfigure(0, weight=1)
        right_f.grid_rowconfigure(1, weight=1)

        # 우하 — 매칭 유닛 목록
        # 우하 — 매칭 유닛 목록
        tree_f = ttk.LabelFrame(right_f, text=i18n.t('PB_MATCHUNITS',' 매칭 유닛 목록 '), padding=4)
        tree_f.grid(row=1, column=0, sticky='nsew')
        tree_f.grid_rowconfigure(0, weight=1)
        tree_f.grid_columnconfigure(0, weight=1)

        cols = ('figure', 'era', 'phase', 'typology', 'title')
        hdrs = [('figure', '인물', 68), ('era', '시대', 74),
                ('phase', '국면', 50), ('typology', '예표구분', 62),
                ('title', '유닛 제목', 0)]
        self._tree = ttk.Treeview(tree_f, columns=cols,
                                   show='headings', selectmode='browse')
        for cid, hd, w in hdrs:
            self._tree.heading(cid, text=hd)
            self._tree.column(cid, width=w, anchor='w', stretch=(cid == 'title'))
        tree_vsb = ttk.Scrollbar(tree_f, orient='vertical',
                                  command=self._tree.yview)
        self._tree.configure(yscrollcommand=tree_vsb.set)
        tree_vsb.grid(row=0, column=1, sticky='ns')
        self._tree.grid(row=0, column=0, sticky='nsew')

    # ── DB 로드 ──────────────────────────────────────────────────────

    def _load_units(self):
        try:
            with appdb.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                self._all_units = [dict(r) for r in conn.execute("""
                    SELECT
                        u.unit_id, u.sequence, u.phase,
                        u.unit_typology_role, u.typology_aspect,
                        u.unit_title,
                        u.start_vid, u.end_vid,
                        u.nt_start_vid, u.nt_end_vid,
                        u.psa_intro_svid, u.psa_intro_evid,
                        u.psa_intro_comment,
                        u.psa_outro_svid, u.psa_outro_evid,
                        u.psa_outro_comment,
                        u.key_question,
                        f.figure_id, f.figure_name,
                        f.offices, f.era, f.testament,
                        COALESCE(f.chrono_order, 9999) AS chrono_order
                    FROM unit_pool  u
                    JOIN figure_pool f USING (figure_id)
                    WHERE f.record_status = 'LIVE'
                    ORDER BY COALESCE(f.chrono_order, 9999), u.figure_id, u.sequence
                """).fetchall()]
        except sqlite3.OperationalError:
            self._all_units = []

    # ── 필터 적용 + 미리보기 갱신 ────────────────────────────────────

    def _refresh(self):
        sel_off = set(self._fg_office.get_selected())
        sel_era = set(self._fg_era.get_selected())
        sel_typ = set(self._fg_typo.get_selected())
        sel_pha = set(self._fg_phase.get_selected())

        def office_match(u: dict) -> bool:
            return bool(set(u.get('offices', '').split(',')) & sel_off)

        mid = [
            u for u in self._all_units
            if office_match(u)
            and u.get('era') in sel_era
            and u.get('unit_typology_role') in sel_typ
            and u.get('phase') in sel_pha
        ]

        # 인물 목록 갱신 + 이전 선택 복원
        fig_names = sorted({u['figure_name'] for u in mid})
        prev_all  = self._fig_list.is_all()
        prev_sel  = set(self._fig_list.get_selected())
        self._fig_list.set_items(fig_names)
        self._fig_list.restore_selection(prev_all, prev_sel)

        # 인물 필터 최종 적용
        sel_fig = set(self._fig_list.get_selected())
        self._filtered = [u for u in mid if u['figure_name'] in sel_fig]

        self._update_tree()
        self._auto_name()

    def _update_tree(self):
        self._tree.delete(*self._tree.get_children())
        for u in self._filtered:
            self._tree.insert('', 'end', values=(
                u.get('figure_name', ''),
                u.get('era', ''),
                i18n.t('PB_PHASE_'+str(u.get('phase','')), PHASE_KO.get(u.get('phase', ''), u.get('phase', ''))),
                i18n.t('PB_TYPO_'+str(u.get('unit_typology_role','')), TYPO_KO.get(u.get('unit_typology_role', ''), '')),
                u.get('unit_title', ''),
            ))
        n = len(self._filtered)
        self._shell.set_count(n, n)

    # ── 플랜명 자동생성 ──────────────────────────────────────────────

    def _auto_name(self):
        figures = [] if self._fig_list.is_all() else self._fig_list.get_selected()
        name = generate_plan_name(
            figures,
            self._fg_office.get_selected(),
            self._fg_era.get_selected(),
            self._fg_typo.get_selected(),
            self._fg_phase.get_selected(),
        )
        self._name_var.set(name)

    # ── 플랜 생성 ────────────────────────────────────────────────────

    def _create_plan(self):
        if not self._filtered:
            messagebox.showwarning(i18n.t('COMMON_WARNING', '경고'), i18n.t('MSG_NO_UNIT_SELECTED', '선택된 유닛이 없습니다.'), parent=self)
            return
        # ⚠ 자동 이름이 코드였다 — `5직분_7시대_26`(2026-08-16 사용자 지적).
        plan_code = _readable(self._name_var.get().strip(), '내 인물 묵상')
        plan_code = check_plan_name(plan_code, self)
        if plan_code is None:
            return

        try:
            with appdb.connect(self.db_path) as conn:
                # ★ **사용자가 조립한 플랜은 `user_*` 에 담는다** (2026-08-16).
                #   예전에는 `sys_bible_plan`·`sys_plan_schedule` 에 썼다 — 그건
                #   **배포용 DB** 라 콘텐츠 교체(연 2회 full-replace) 때 사라지고,
                #   그것을 가리키던 `user_plan_enrollment` 가 없는 플랜을 가리키게 된다.
                #   블록(`unit_pool`)은 sys 에서 읽고 **조립 결과만** user 에 쓴다 —
                #   `miracle_builder` 가 이미 그렇게 한다(§8 · §0-6 C-2).
                # ⚠ `user_plan_enrollment.plan_id` 가 NOT NULL 이라 **기원 sys 플랜**이
                #   있어야 한다. 기적묵상이 `origin_plan_id=30` 을 쓰는 자리와 같다.
                anchor = conn.execute(
                    "SELECT plan_id FROM sys_bible_plan "
                    "WHERE plan_type='BIOGRAPHICAL' "
                    "  AND COALESCE(record_status,'LIVE')='LIVE' "
                    "ORDER BY plan_id LIMIT 1").fetchone()
                if not anchor:
                    messagebox.showerror(
                        i18n.t('COMMON_ERROR', '오류'),
                        i18n.t('PB_NO_ANCHOR',
                               '인물묵상 기준 플랜이 없습니다. 관리자에게 알려 주세요.'),
                        parent=self)
                    return
                origin_id = anchor[0]

                # ★ 겹침은 **형제끼리만** 본다 — 앵커를 안 뒤라야 셀 수 있다.
                plan_code = unique_sibling_name(conn, plan_code, origin_id)
                self._name_var.set(plan_code)

                cur = conn.execute(
                    "INSERT INTO user_bible_plan "
                    "(origin_plan_id, plan_code, plan_type, plan_category, "
                    " duration_days, track_count) "
                    "VALUES (?, ?, 'BIOGRAPHICAL', 'THEMATIC', ?, 1)",
                    (origin_id, plan_code, len(self._filtered)),
                )
                plan_id = cur.lastrowid

                for lc in ('KO', 'EN'):
                    conn.execute(
                        "INSERT INTO user_text_asset "
                        "(clicked_id, target_id, text_type, title, lang_code, "
                        " record_status, created_at, updated_at) "
                        "VALUES (?, 0, 'PLAN_TITLE', ?, ?, 'NEW', "
                        "        DATETIME('now','localtime'), "
                        "        DATETIME('now','localtime'))",
                        (plan_id, plan_code, lc),
                    )

                for day, u in enumerate(self._filtered, start=1):
                    week = (day - 1) // 7 + 1
                    uid  = u['unit_id']

                    if u.get('psa_intro_svid'):
                        conn.execute(
                            "INSERT INTO user_plan_schedule "
                            "(user_plan_id,week,day,start_vid,end_vid,stage_type,"
                            "connection_level,sort_order,meditation_focus,unit_key) "
                            "VALUES (?,?,?,?,?,'PSA','EXPANSION',5,?,?)",
                            (plan_id, week, day,
                             u['psa_intro_svid'], u['psa_intro_evid'],
                             u.get('psa_intro_comment', ''),
                             f"{uid}_PSA_INTRO"),
                        )

                    if u.get('start_vid') and u.get('end_vid'):
                        conn.execute(
                            "INSERT INTO user_plan_schedule "
                            "(user_plan_id,week,day,start_vid,end_vid,stage_type,"
                            "connection_level,sort_order,unit_key) "
                            "VALUES (?,?,?,?,?,'BIO','CORE',10,?)",
                            (plan_id, week, day,
                             u['start_vid'], u['end_vid'],
                             f"{uid}_CORE"),
                        )

                    if u.get('nt_start_vid') and u.get('nt_end_vid'):
                        conn.execute(
                            "INSERT INTO user_plan_schedule "
                            "(user_plan_id,week,day,start_vid,end_vid,stage_type,"
                            "connection_level,sort_order,unit_key) "
                            "VALUES (?,?,?,?,?,'NT','EXPANSION',20,?)",
                            (plan_id, week, day,
                             u['nt_start_vid'], u['nt_end_vid'],
                             f"{uid}_NT"),
                        )

                    if u.get('psa_outro_svid'):
                        conn.execute(
                            "INSERT INTO user_plan_schedule "
                            "(user_plan_id,week,day,start_vid,end_vid,stage_type,"
                            "connection_level,sort_order,meditation_focus,unit_key) "
                            "VALUES (?,?,?,?,?,'PSA','EXPANSION',50,?,?)",
                            (plan_id, week, day,
                             u['psa_outro_svid'], u['psa_outro_evid'],
                             u.get('psa_outro_comment', ''),
                             f"{uid}_PSA_OUTRO"),
                        )

            self.created_user_plan_id = plan_id
            self.created_plan_id = plan_id   # 옛 이름 — 호출부 호환
            # ★ 「'등록하기' 버튼을 눌러 시작하세요」 → **여기서 묻는다** (2026-08-16).
            #   ⚠ 팝업이 직접 등록하지 않는다 — 등록은 플랜 화면의 몫이다(§0-6 C-2).
            #     `enroll_now` 에 답만 남기고, `_start_clicked` 가 그것을 보고 등록한다.
            self.enroll_now = messagebox.askyesno(
                i18n.t('COMMON_DONE', '완료'),
                i18n.t('MSG_PLAN_CREATED_ASK',
                       "플랜을 만들었습니다 — {code} ({days}일)\n\n지금 등록할까요?"
                       ).format(code=plan_code, days=len(self._filtered)),
                parent=self,
            )
            self.destroy()

        except Exception as e:
            messagebox.showerror(i18n.t('COMMON_ERROR', '오류'), str(e), parent=self)


# ────────────────────────────────────────────────────────────────────
# 독립 실행
# ────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    root = tk.Tk()
    root.withdraw()
    dlg = PlanBuilderDialog(root)
    root.wait_window(dlg)
    root.destroy()
