"""
chain_tool.py
-------------
VERS_VERS 흐름 link (PRG·DEP·INC·REV 등) 일괄 정의·INSERT 도구.

핵심 함수:
  vid(bcode, ch, vs)                              → verse_id 조회
  define_chain(name, verses, rel_code, ...)        → chain N절 → (N-1) 인접 link
  define_pair(src, tgt, rel_code, desc)            → 단일 쌍 link
  flush(apply=False)                              → 일괄 INSERT·검증

사용 예 (DEP 산상수훈):
  from chain_tool import vid, define_pair, flush
  define_pair(
      (40, 5, 28), (2, 20, 14),
      'DEP',
      '마5:28 "음욕을 품는 자마다 마음에 이미 간음" — 출20:14 "간음하지 말라"의 영적 심화.'
  )
  flush(apply=True)

VERS_VERS 트리거 자동 sorted([a, b]) 적용.
멱등 안전 (UNIQUE 충돌 시 skip).
"""

import os
import sqlite3
import appdb
import sys

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')

# pending list — [(src_vid, tgt_vid, rel_code, desc, label, chain_code), ...]
_PENDING: list = []


def _conn():
    return appdb.connect(DB)


def vid(bcode: int, ch: int, vs: int) -> int | None:
    """(bcode, ch, vs) → verse_id. 없으면 None."""
    with _conn() as c:
        r = c.execute(
            "SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? AND verse=?",
            (bcode, ch, vs)).fetchone()
    return r[0] if r else None


def _resolve(loc):
    """loc: (bcode, ch, vs) 또는 verse_id(int) → verse_id."""
    if isinstance(loc, int):
        return loc
    if isinstance(loc, (tuple, list)) and len(loc) == 3:
        return vid(*loc)
    raise ValueError(f'invalid loc: {loc}')


def define_pair(src, tgt, rel_code: str, desc: str, label: str = '',
                 chain_code: str | None = None):
    """단일 쌍 link 정의 (pending에 추가).
    src/tgt: verse_id(int) 또는 (bcode, ch, vs) 튜플.
    label: 선택적 로그용 라벨.
    chain_code: 흐름 그룹 식별자 (예: 'DEP-MT5'). NULL = 단발 pair."""
    src_vid = _resolve(src)
    tgt_vid = _resolve(tgt)
    if not src_vid or not tgt_vid:
        print(f'  [MISS] {rel_code}: src={src} tgt={tgt}')
        return
    if src_vid == tgt_vid:
        print(f'  [SKIP] {rel_code}: self-ref vid={src_vid}')
        return
    _PENDING.append((src_vid, tgt_vid, rel_code, desc, label, chain_code))


def define_chain(name: str, verses: list, rel_code: str,
                  chain_desc: str = '', link_descs: list | None = None,
                  chain_code: str | None = None):
    """N절 chain → (N-1) 인접 link 자동 생성.
    verses: [(bcode, ch, vs), ...] 또는 [verse_id, ...]
    chain_desc: 전체 chain 설명 (각 link에 자동 prepend)
    link_descs: 각 인접 쌍별 사용자 정의 desc. 없으면 자동 생성.
    chain_code: 흐름 그룹 식별자 (예: 'PRG-LIGHT'). 명시 권장.
                미명시 시 자동 생성: f'{rel_code}-{name.upper()}'.
    """
    vids = [_resolve(v) for v in verses]
    if any(v is None for v in vids):
        print(f'  [MISS chain "{name}"] 일부 vid 조회 실패')
        return

    if chain_code is None:
        chain_code = f'{rel_code}-{name.upper()}'

    n_pairs = len(vids) - 1
    if link_descs and len(link_descs) != n_pairs:
        print(f'  [WARN] "{name}" link_descs 개수 불일치 (제공 {len(link_descs)}, 필요 {n_pairs})')

    for i in range(n_pairs):
        src_vid, tgt_vid = vids[i], vids[i + 1]
        if link_descs and i < len(link_descs):
            desc = link_descs[i]
        else:
            desc = f'[{name} chain {i+1}/{n_pairs}] vid={src_vid} → vid={tgt_vid}'
            if chain_desc:
                desc += f' — {chain_desc}'
        label = f'{name}#{i+1}'
        _PENDING.append((src_vid, tgt_vid, rel_code, desc, label, chain_code))


def flush(apply: bool = False, verbose: bool = True):
    """pending 일괄 INSERT.
    apply=False: dry-run.
    VERS_VERS 트리거 sorted([a,b]) 자동 적용.
    UNIQUE (rel_code, lang_code) 중복 skip.
    """
    global _PENDING
    if not _PENDING:
        print('flush: pending empty')
        return

    conn = _conn()
    cur = conn.cursor()
    inserted = skipped = 0
    desc_lens = []

    for src, tgt, rel, desc, label, chain_code in _PENDING:
        a, b = sorted([src, tgt])
        row = cur.execute(
            "SELECT sys_link_id FROM sys_link_asset "
            "WHERE link_type='VERS_VERS' AND clicked_id=? AND target_id=? AND rel_code=?",
            (a, b, rel)).fetchone()
        if row:
            if verbose:
                print(f'  [skip] {label or rel} ({src}↔{tgt})')
            skipped += 1
            continue
        desc_lens.append(len(desc))
        if apply:
            cur.execute(
                "INSERT INTO sys_link_asset "
                "(link_type, clicked_id, target_id, rel_code, chain_code, sort_order, record_status) "
                "VALUES ('VERS_VERS', ?, ?, ?, ?, 1, 'LIVE')",
                (a, b, rel, chain_code))
            lid = cur.lastrowid
            cur.execute(
                "INSERT INTO sys_text_asset "
                "(clicked_id, text_type, contents, lang_code, record_status) "
                "VALUES (?, 'VERS_VERS_DESC', ?, 'KO', 'LIVE')",
                (lid, desc))
            if verbose:
                cc = f' [{chain_code}]' if chain_code else ''
                print(f'  [new] {label or rel} ({src}↔{tgt}) link={lid} {len(desc)}자{cc}')
        else:
            if verbose:
                cc = f' [{chain_code}]' if chain_code else ''
                print(f'  [new] {label or rel} ({src}↔{tgt}) {len(desc)}자{cc}')
        inserted += 1

    if apply:
        conn.commit()
    conn.close()

    print(f'\nflush: inserted={inserted}, skipped={skipped}')
    if desc_lens:
        avg = sum(desc_lens) / len(desc_lens)
        print(f'        desc 평균: {avg:.0f}자')

    _PENDING = []


def clear_pending():
    """pending 비우기 (테스트용)."""
    global _PENDING
    _PENDING = []
