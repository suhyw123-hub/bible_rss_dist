# -*- coding: utf-8 -*-
"""mobile_view.py — 설정 ▸ 「모바일 연결」 화면 (2026-10-06 317차 신설 · 2026-10-10 단계 화면으로 다시 짰다).

알맹이는 `mobile_sync`·`db_mobile_core` 다 — 이 화면은 그것을 부르기만 한다.

★★★ 2026-10-10 1.txt 54 — 「작업순서가 한눈에 보이도록 · 단계별 절차·설명·조치 버튼 · 방향성을
  명확하게(준비작업 · 동기화 · PC ⇒ 모바일 · 모바일 ⇒ PC)」. 위 띠가 다섯 단계이고 고른 단계의
  설명·단추·목록만 아래에 보인다:

    ① 연결 → ② 동기화(주고받기) → ③ PC 자료 최신화 → ④ PC ⇒ 폰 보낼 자료 → ⑤ 폰 ⇒ PC 받은 글

  · ② 동기화 = 두 기기가 **바뀐 것을 주고받는 한 번의 일**이다(내용을 일치시키는 것이 아니다 —
    PC 가 정본이고 폰의 글은 ⑤ 에서 사람이 PC 에 들인다).
  · ③ = 동기화가 폰에 줄 **PC 쪽 재료를 서버 최신판으로** 받아 두는 일(서버 · 이 PC · 폰 판을 견준다).
  · ⑤ 이름 — 「새 초안 · 채택함 · 버린 것」 → **다운로드 대기 · PC에 다운로드 · 다운로드 안함**
    (사용자 「직설적으로 표현하라」) · 다운로드 안함이면 **폰의 글을 지울지 고른다(기본 = 안 지움)**.
  · 「짝 끊기」 → **연결 해제**.
⚠ 망을 쓰는 일은 일꾼 스레드 + 큐 + after(§279차 ⑭) · 단추는 단계 맨 위(§0) · 팝업 없음.
"""
import json
import os
import queue
import threading
import time
import tkinter as tk
import tkinter.font as tkfont
from tkinter import ttk

import appdb
import mobile_sync as MS

try:
    import i18n
    _t = i18n.t
except Exception:
    def _t(k, d=''):
        return d

try:
    import ui_theme

    def _C(role, fb):
        try:
            return ui_theme.C(role) or fb
        except Exception:
            return fb
except Exception:
    def _C(role, fb):
        return fb


def _tfr(w, db, scope='ui', delta=0):
    try:
        import theme_font
        theme_font.register(w, db, scope, size_delta=delta)
    except Exception:
        pass


KIND_KEY = {'NOTE': ('MOB_K_NOTE', '묵상노트'),
            'NOTE_ADD': ('MOB_K_NOTE_ADD', '노트 덧붙이기'),
            'NOTE_EDIT': ('MOB_K_NOTE_EDIT', '노트 고치기'),
            'NOTE_DEL': ('MOB_K_NOTE_DEL', '노트 지우기'),
            'DESC': ('MOB_K_DESC', '설명문 수정'),
            'REF': ('MOB_K_REF', '연구자료'),
            'AI': ('MOB_K_AI', 'AI 대화')}
DESC_NAME = {'VERS_DESC': ('MOB_D_VERS', '구절 설명'),
             'VERS_QUESTION': ('MOB_D_QUES', '질문'),
             'VERS_PRAYER': ('MOB_D_PRAY', '묵상기도'),
             'CHAP_DESC': ('MOB_D_CHAP', '장 설명'),
             'PERI_DESC': ('MOB_D_PERI', '단락 설명'),
             'BOOK_DESC': ('MOB_D_BOOK', '책 설명'),
             'ENTITY_DESC': ('MOB_D_ENT', '용어 설명')}
# ⑤ 받은 글의 상태 — 값(NEW·ADOPTED·DISCARDED)은 그대로 · 이름만 직설적으로
STATES = (('NEW', 'MOB_ST_WAIT', '다운로드 대기'), ('ADOPTED', 'MOB_ST_DOWN', 'PC에 다운로드'),
          ('DISCARDED', 'MOB_ST_SKIP', '다운로드 안함'))
STEPS = (('CONN', 'MOB_STEP_CONN', '① 연결'),
         ('SYNC', 'MOB_STEP_SYNC', '② 동기화'),
         ('PREP', 'MOB_STEP_PREP', '③ PC 자료 최신화'),
         ('SEND', 'MOB_STEP_SEND', '④ PC ⇒ 폰 보낼 자료'),
         ('RECV', 'MOB_STEP_RECV', '⑤ 폰 ⇒ PC 받은 글'),
         ('CHECK', 'MOB_STEP_CHECK', '⑥ 받은 글 점검'))
# ⑥ 거르개 — 갈래(NOTE 는 노트 덧붙이기를 함께 본다)
CK_KINDS = (('', 'MOB_CK_ALL', '전체'), ('NOTE', 'MOB_K_NOTE', '묵상노트'), ('DESC', 'MOB_K_DESC', '설명문 수정'),
            ('REF', 'MOB_K_REF', '연구자료'), ('AI', 'MOB_K_AI', 'AI 대화'))
CK_STATES = (('TODO', 'MOB_CK_TODO', '점검 남음'), ('DONE', 'MOB_CK_DONE', '점검 끝'), ('ALL', 'MOB_CK_ALL', '전체'))


class _Center(object):
    """설명문 구획 부품(`overlay_center._SectionsPanel`)이 바라는 것만 — 그 부품을 그대로 심으려고."""
    def __init__(self, db_path, lang):
        self.db_path = db_path
        self.lang = lang

    def changed(self, *_a, **_k):
        pass

REF_SAID = {'NOTE': ('MOB_R_NOTE', '묵상노트로 저장했습니다'),
            'DESC': ('MOB_R_DESC', '내 설명문(덮개)으로 저장했습니다'),
            'REF': ('MOB_R_REF', '연구자료로 저장했습니다'),
            'AI': ('MOB_R_AI', 'AI 도우미 대화목록에 넣었습니다')}
CMP_SAID = {'SAME': ('MOB_CMP_SAME', '같음 — 다시 안 보냄'),
            'PC_OLD': ('MOB_CMP_PCOLD', '서버에 새 판 — [모자란 것 받기]'),
            'PHONE_OLD': ('MOB_CMP_PHOLD', '폰에 보낼 차례 — 다음 동기화 때 갑니다'),
            'NO_PC': ('MOB_CMP_NOPC', '이 PC 에 없음 — [모자란 것 받기]')}


def ref_label(ref):
    """채택 결과(`NOTE:12` · `AI:3 · REF:5`)를 사람 말로 — 화면에 코드를 안 쓴다."""
    out = []
    for part in (ref or '').split(' · '):
        key, dflt = REF_SAID.get(part.split(':')[0], ('', ''))
        if key:
            out.append(_t(key, dflt))
    return ' · '.join(out) or _t('MOB_ADOPTED', 'PC 에 받았습니다')


def _ai_name(m, d):
    try:
        import user_ai
        return user_ai.short_name({'provider': m.get('provider') or d.get('provider') or '',
                                   'model': m.get('model') or d.get('model') or ''}) or 'AI'
    except Exception:
        return 'AI'


def ai_tag(d):
    """목록 줄 앞머리 — 이 AI 대화가 무엇을 가졌나(최종 정리본 · AI 몇 곳)."""
    tags = []
    if (d.get('final') or '').strip():
        tags.append(_t('MOB_AI_HAS_FINAL', '최종 정리본'))
    n = len(d.get('ais') or [])
    if n > 1:
        tags.append(_t('MOB_AI_N', 'AI %d곳') % n)
    return ('[%s] ' % ' · '.join(tags)) if tags else ''


def ai_preview(d):
    """폰에서 온 AI 대화를 PC 에서 읽는 글 — ★ 최종 정리본을 맨 위에 따로 · 대화는 말마다 누가 쓴 글인지
    (나 · AI 이름 · 차례 통합본 · 그 AI 정리) 머리를 붙인다(2026-10-10 「어떤 글이 통합된 결과물인지 식별」)."""
    out = []
    fin = (d.get('final') or '').strip()
    if fin:
        head = (_t('MOB_AI_FINAL_MULTI', '최종 정리본 — AI %d곳 대화를 한 글로') % len(d.get('ais') or [])
                if d.get('final_multi') else _t('MOB_AI_FINAL_ONE', '최종 정리본 — 대화를 한 글로'))
        out += ['【%s】' % head, fin, '', '─' * 30, _t('MOB_AI_TALK', '대화'), '']
    for m in d.get('msgs') or []:
        if m.get('role') == 'user':
            who = _t('MOB_ME', '나')
        elif m.get('mkind') == 'INTEG' and m.get('target') == 'FINAL':
            continue                                  # 맨 위에 이미 있다
        elif m.get('mkind') == 'INTEG':
            who = _t('MOB_AI_ROUND_INTEG', '통합본(AI 답을 묶음)')
        elif m.get('mkind') == 'SELF':
            who = _t('MOB_AI_SELF', '%s 정리') % _ai_name(m, d)
        else:
            who = _ai_name(m, d)
        # 내 말은 폰 화면에 보이던 물음으로(보낸 글 전문은 PC 대화목록에 그대로 들어간다)
        txt = (m.get('shown') if m.get('role') == 'user' and m.get('shown') else m.get('body')) or ''
        out.append('[%s]' % who + '\n' + txt.strip() + '\n')
    return '\n'.join(out)


def kind_label(k):
    key, d = KIND_KEY.get(k, ('', k))
    return _t(key, d) if key else d


def _lang_names():
    try:
        import lang_config
        return [(c, lang_config.lang_name(c)) for c in lang_config.ui_langs()]
    except Exception:
        return [('KO', '한국어'), ('EN', 'English')]


class MobileSyncView(ttk.Frame):
    """설정 ▸ 모바일 연결 — 다섯 단계."""

    def __init__(self, master, db_path, lang_getter=None, targets=None):
        super().__init__(master)
        self.db_path = db_path
        self.targets = targets          # 시험용 — 방송할 곳(없으면 이 PC 의 와이파이)
        self.lang_getter = lang_getter or (lambda: 'KO')
        self._q = queue.Queue()
        self._busy = False
        self._devs = []
        self._cur = None
        self._found = []
        self._stop = False
        self._server = None             # 서버 목록(③ — 확인했을 때만)
        self._core_rows = None
        self._send_lang = 'KO'
        self._build()
        self.after_idle(self.reload)

    # ══════════════════════════════════════════════════════════════════
    #  틀 — 단계 띠 · 상태 줄 · 단계 몸통
    # ══════════════════════════════════════════════════════════════════
    def _build(self):
        pad = 10
        self._pad = pad
        intro = tk.Label(self, anchor='w', justify='left', wraplength=980, fg=_C('fg_dim', '#666'),
                         text=_t('MOB_INTRO2', '이 PC 가 정본입니다. 차례대로 하세요 — ① 폰과 연결 → '
                                 '② 동기화(두 기기가 바뀐 것을 주고받기) → ③ 폰에 줄 PC 자료를 서버 '
                                 '최신판으로 → ④ 폰에 보낼 자료 선택하기 → ⑤ 폰에서 쓴 글을 PC 에 받기.'))
        intro.pack(fill='x', padx=pad, pady=(pad, 4))
        _tfr(intro, self.db_path, 'ui', -1)

        bar = ttk.Frame(self)            # 단계 띠
        bar.pack(fill='x', padx=pad, pady=(0, 4))
        self._step_var = tk.StringVar(value='CONN')
        self._step_btn = {}
        self._step_done = {}
        for i, (code, key, dflt) in enumerate(STEPS):
            if i:
                tk.Label(bar, text='→', fg=_C('fg_dim', '#888')).pack(side='left', padx=2)
            b = tk.Button(bar, text=_t(key, dflt), relief='flat', bd=1, padx=10, pady=3, cursor='hand2',
                          command=lambda c=code: self._show_step(c))
            b.pack(side='left')
            _tfr(b, self.db_path)
            self._step_btn[code] = (b, key, dflt)
        try:
            from manual_widget import attach_manual_icon
            attach_manual_icon(bar, 'U_SET_MOBILE',
                               lang_provider=lambda: (self.lang_getter() or 'KO')
                               ).pack(side='right', padx=(4, 0))
        except Exception:
            pass

        self._status = tk.Label(self, anchor='w', justify='left',
                                fg=_C('accent', '#2E86C1'), wraplength=980)
        self._status.pack(fill='x', padx=pad, pady=(0, 4))
        _tfr(self._status, self.db_path)
        ttk.Separator(self).pack(fill='x', padx=pad)

        self._body = ttk.Frame(self)
        self._body.pack(fill='both', expand=True, padx=pad, pady=(6, pad))
        self._steps = {}
        for code, builder in (('CONN', self._build_conn), ('SYNC', self._build_sync),
                              ('PREP', self._build_prep), ('SEND', self._build_send_step),
                              ('RECV', self._build_recv), ('CHECK', self._build_check)):
            f = ttk.Frame(self._body)
            builder(f)
            self._steps[code] = f
        self._show_empty()

    def _desc(self, f, key, dflt, warn=False):
        lb = tk.Label(f, anchor='w', justify='left', wraplength=960, text=_t(key, dflt),
                      fg=_C('danger', '#C0392B') if warn else _C('fg', '#333'))
        lb.pack(fill='x', pady=(0, 6))
        _tfr(lb, self.db_path, 'ui', -1)
        return lb

    def _paint_steps(self):
        """지금 단계 = 진한 강조색 바탕 + 흰 굵은 글자 · 끝난 단계 = ✓ + 연한 바탕(1.txt 54 「배경색을 명확하게」)."""
        cur = self._step_var.get()
        for code, (b, key, dflt) in self._step_btn.items():
            done = self._step_done.get(code)
            txt = _t(key, dflt) + (' ✓' if done else '')
            extra = getattr(self, '_step_extra', {}).get(code, '')
            b.configure(text=txt + extra)
            if code == cur:
                b.configure(bg=_C('accent', '#2E86C1'), fg='#FFFFFF', activebackground=_C('accent', '#2E86C1'),
                            activeforeground='#FFFFFF', relief='solid')
            elif done:
                b.configure(bg=_C('success_bg', '#E9F7EF'), fg=_C('fg', '#222'), relief='flat',
                            activebackground=_C('success_bg', '#E9F7EF'))
            else:
                b.configure(bg=_C('bg', '#F4F6F7'), fg=_C('fg', '#222'), relief='flat',
                            activebackground=_C('panel_alt', '#EAECEE'))
            try:
                f = tkfont.Font(font=b.cget('font'))
                f.configure(weight='bold' if code == cur else 'normal')
                b.configure(font=f)
            except Exception:
                pass

    def _show_step(self, code=None):
        if code:
            self._step_var.set(code)
        code = self._step_var.get()
        self._paint_steps()
        for c, f in self._steps.items():
            if c == code:
                f.pack(fill='both', expand=True)
            else:
                f.pack_forget()
        if code == 'PREP':
            self._prep_fill()
        elif code == 'SEND':
            self._send_fill()
        elif code == 'RECV':
            self._fill()
        elif code == 'CHECK':
            self._ck_fill()
        elif code == 'SYNC':
            self._sync_fill()

    # ── ① 연결 ────────────────────────────────────────────────────────
    def _build_conn(self, f):
        self._desc(f, 'MOB_D_CONN2',
                   '모바일 기기 : 오른쪽 위에 있는 「설정」 버튼을 클릭하고 「PC 연결」을 선택하세요.\n'
                   'PC : 설정 - 모바일 연결 화면의 ①연결 화면에서 「같은 와이파이를 사용하는 폰 찾기」 버튼을 '
                   '클릭하세요. PC와 연결된 모바일 기기의 목록이 표시됩니다. 연결할 모바일 기기를 선택하고 '
                   '「선택한 모바일 기기와 연결」 버튼을 누르세요. 모바일 기기와 PC의 숫자가 같으면 모바일 '
                   '기기에서 「허용」 버튼을 클릭하면 연결됩니다.\n'
                   '모바일기기를 찾지 못하는 경우에는, 모바일 기기의 「PC연결」 화면에 표시된 주소(예: '
                   '999.999.9.99 형식)를 입력하고 연결하세요.')
        row = ttk.Frame(f)
        row.pack(fill='x', pady=(0, 4))
        ttk.Label(row, text=_t('MOB_PHONE', '폰')).pack(side='left')
        self._dev_var = tk.StringVar()
        self._dev_cb = ttk.Combobox(row, textvariable=self._dev_var, width=26, state='readonly')
        self._dev_cb.pack(side='left', padx=(4, 6))
        self._dev_cb.bind('<<ComboboxSelected>>', lambda _e: self._on_dev())
        self._b_conn = ttk.Button(row, text=_t('MOB_BTN_FIND', '같은 와이파이를 사용하는 폰 찾기'),
                                  command=self._connect)
        self._b_conn.pack(side='left')
        self._b_stop = ttk.Button(row, text=_t('MOB_BTN_STOP', '그만두기'), command=self._stop_now)
        self._b_unpair = ttk.Button(row, text=_t('MOB_BTN_DISCONNECT', '연결 해제'), command=self._unpair)
        self._b_unpair.pack(side='right')        # 되돌리기 어려운 쪽은 떼어 둔다(§241차 ㉜)
        self._conn_row = row

        self._cf = ttk.Frame(f)               # 연결하기 칸 — [폰 연결하기]를 눌렀을 때만
        lf0 = ttk.Frame(self._cf)
        lf0.pack(side='left', fill='y')
        self._found_lbl = tk.Label(lf0, anchor='w', fg=_C('fg_dim', '#666'),
                                   text=_t('MOB_FOUND', '찾은 폰 — 연결할 폰을 선택하세요'))
        self._found_lbl.pack(fill='x')
        _tfr(self._found_lbl, self.db_path, 'ui', -1)
        self._found_lb = tk.Listbox(lf0, height=4, width=34, exportselection=False)
        self._found_lb.pack(fill='x')
        _tfr(self._found_lb, self.db_path)
        self._b_this = ttk.Button(lf0, text=_t('MOB_BTN_THIS2', '선택한 모바일 기기와 연결'),
                                  command=self._pick_phone)
        self._b_this.pack(anchor='w', pady=(4, 0))
        rf0 = ttk.Frame(self._cf)
        rf0.pack(side='left', fill='both', expand=True, padx=(16, 0))
        self._code_say = tk.Label(rf0, anchor='w', justify='left', wraplength=520, fg=_C('fg', '#222'))
        self._code_say.pack(fill='x')
        _tfr(self._code_say, self.db_path)
        self._code_lbl = tk.Label(rf0, anchor='w', text='', fg=_C('accent', '#2E86C1'))
        self._code_lbl.pack(anchor='w', pady=(4, 0))
        _tfr(self._code_lbl, self.db_path, 'ui', 12)      # 멀리서도 읽히게 크게
        # 주소로 연결 — 늘 보인다(1.txt 54 「모바일기기 주소 입력창 배치」)
        self._man = ttk.Frame(f)
        self._man.pack(fill='x', pady=(2, 4), after=row)
        ttk.Label(self._man, text=_t('MOB_MANUAL2', '모바일 기기 주소')).pack(side='left')
        self._man_var = tk.StringVar()
        ttk.Entry(self._man, textvariable=self._man_var, width=22).pack(side='left', padx=(6, 6))
        ttk.Button(self._man, text=_t('MOB_BTN_THISADDR2', '이 주소로 연결'),
                   command=self._pick_manual).pack(side='left')

    # ── ② 동기화 ──────────────────────────────────────────────────────
    def _build_sync(self, f):
        self._desc(f, 'MOB_D_SYNC', '동기화는 두 기기가 바뀐 것을 한 번 주고받는 일입니다. 내용을 똑같이 '
                   '맞추는 것이 아니라 — 이 PC 가 정본입니다.\n'
                   '폰 ⇒ PC : 즐겨찾기·플랜 진행·읽던 곳은 바로 저장합니다. 폰에서 쓴 노트·설명문·연구자료·'
                   'AI 대화는 ⑤ 「다운로드 대기」로 들어옵니다.\n'
                   'PC ⇒ 폰 : 내 글의 사본(바뀐 것만) · 공지 · ④ 에서 선택한 자료(코어팩·책 — 폰에 같은 것이 '
                   '있으면 다시 안 보냅니다).')
        self._desc(f, 'MOB_SYNC_WARN', '⚠ 동기화하는 동안 폰 앱의 「PC 연결」 화면을 떠나거나 앱을 닫으면 '
                   '중단됩니다. 끝났다는 글이 뜰 때까지 폰 화면을 그대로 두세요.', warn=True)
        row = ttk.Frame(f)
        row.pack(fill='x', pady=(0, 6))
        self._b_sync = ttk.Button(row, text=_t('MOB_BTN_SYNC', '동기화'), command=self._sync)
        self._b_sync.pack(side='left')
        self._keys_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(row, variable=self._keys_var,
                        text=_t('MOB_SEND_KEYS', 'AI 키도 폰에 보낸다')).pack(side='left', padx=(14, 0))
        self._sync_row = row
        self._last_lbl = tk.Label(f, anchor='w', justify='left', wraplength=960, fg=_C('fg', '#333'))
        self._last_lbl.pack(fill='x')
        _tfr(self._last_lbl, self.db_path)

    def _sync_fill(self):
        d = self._dev()
        if not d:
            self._last_lbl.configure(text=_t('MOB_NO_PHONE2', '연결한 폰이 없습니다 — ① 연결부터 하세요.'))
            return
        self._last_lbl.configure(text=(_t('MOB_LAST', '마지막 동기화') + ': %s\n%s')
                                 % (d['last_sync'] or '-', d['last_result'] or '-'))

    # ── ③ PC 자료 최신화 ──────────────────────────────────────────────
    def _build_prep(self, f):
        self._desc(f, 'MOB_D_PREP', '폰에 줄 자료를 이 PC 에 서버 최신판으로 받아 둡니다 — PC 코어팩과 '
                   '모바일 코어팩(공통 + 폰 언어팩). [서버 판 확인]으로 서버 · 이 PC · 폰의 판을 견주고, '
                   '다르면 [모자란 것 받기]. 폰 칸은 마지막 동기화 때 폰이 알려 준 판입니다.')
        row = ttk.Frame(f)
        row.pack(fill='x', pady=(0, 6))
        self._b_check = ttk.Button(row, text=_t('MOB_BTN_CHECK', '서버 판 확인'), command=self._prep_check)
        self._b_check.pack(side='left')
        self._b_core = ttk.Button(row, text=_t('MOB_BTN_FETCH_ALL', '모자란 것 받기'), command=self._core_get)
        self._b_core.pack(side='left', padx=(6, 0))
        cols = ('what', 'srv', 'pc', 'ph', 'st')
        tv = ttk.Treeview(f, columns=cols, show='headings', selectmode='none', height=8)
        for cid, key, dflt, w, st in (('what', 'MOB_COL_PACK', '자료', 260, True),
                                      ('srv', 'MOB_COL_SRV', '서버', 130, False),
                                      ('pc', 'MOB_COL_PC', '이 PC', 230, False),
                                      ('ph', 'MOB_COL_PH', '폰', 130, False),
                                      ('st', 'MOB_COL_STATE', '상태', 280, True)):
            tv.heading(cid, text=_t(key, dflt))
            tv.column(cid, width=w, stretch=st, anchor='w')
        tv.pack(fill='both', expand=True)
        self._prep_tv = tv
        try:
            import theme_font
            theme_font.list_style('Mobile.Treeview', self.db_path)
            tv.configure(style='Mobile.Treeview')
        except Exception:
            pass

    def _prep_fill(self):
        import db_mobile_core as MC
        tv = self._prep_tv
        tv.delete(*tv.get_children())
        try:
            with appdb.connect(self.db_path) as conn:
                MS.ensure(conn)
                lang = MS.phone_lang(conn, (self.lang_getter() or 'KO'))
                ph = MS.phone_packs(conn)
        except Exception as e:                            # noqa: BLE001
            self._say(str(e)[:120], err=True)
            return
        self._send_lang = lang
        for r in (self._core_rows or []):                 # PC 코어팩 — 확인했을 때만
            st = _t('MOB_CMP_SAME2', '같음') if r['have'] else _t('MOB_CMP_PCOLD', '서버에 새 판 — [모자란 것 받기]')
            tv.insert('', 'end', values=(_t('MOB_PC_CORE', 'PC 코어팩') + ' · ' + r['cycle'],
                                         '%s %d' % (_t('MOB_REL', '판'), r['release']),
                                         _t('MOB_HAVE', '받음') if r['have'] else _t('MOB_NOT_HAVE', '옛 판·없음'),
                                         '—', st))
        names = {MC.COMMON_FILE: _t('MOB_PACK_COMMON', '모바일 공통 코어팩'),
                 MC.file_name(lang): _t('MOB_PACK_LANG', '모바일 언어팩') + ' (%s)' % lang}
        for c in MC.compare(lang, ph, self._server):
            key, dflt = CMP_SAID.get(c['state'], ('', c['state']))
            srv = (c['server'] or '—') if c['server'] is not None else _t('MOB_NOT_CHECKED', '(확인 전)')
            pc = ('%s · %s · %.1f MB' % (c['pc'][:7], c['pc_made'], c['pc_mb'])) if c['pc'] else '—'
            tv.insert('', 'end', values=(names.get(c['name'], c['name']), srv[:7] if c['server'] else srv,
                                         pc, (c['phone'] or '—')[:7], _t(key, dflt) if key else dflt))

    def _prep_check(self):
        lang = self._send_lang

        def fn():
            import pack_status as PS
            import db_mobile_core as MC
            man = PS.manifest()
            return PS.core_plan(self.db_path, man), MC.fetch_index()

        def done(kind, val):
            if kind == 'err':
                self._say(str(val), err=True)
                return
            self._core_rows, idx = val
            self._server = idx if idx is not None else {}
            self._say(_t('MOB_CHECKED', '서버 판을 확인했습니다.') if idx is not None else
                      _t('MOB_NO_INDEX', '서버에서 모바일 팩 목록을 못 받았습니다 — 아직 안 올렸거나 망이 없습니다.'),
                      err=idx is None)
            self._prep_fill()
        self._say(_t('MOB_CHECKING', '서버 판을 확인하는 중…'))
        self._run(fn, done)

    def _core_get(self):
        lang = self._send_lang
        q = self._q

        def fn():
            import pack_status as PS
            got = []
            if self._core_rows and any(not r['have'] for r in self._core_rows):
                q.put(('log', _t('MOB_S_PCCORE', 'PC 코어팩을 받는 중…')))
                PS.fetch_core(self.db_path)
                got.append('PC')
            q.put(('log', _t('MOB_S_FETCH_CORE', '모바일 코어팩을 받는 중…')))
            got += MS.refresh_core(lang, force=True)
            return got

        def done(kind, val):
            if kind == 'ok' and val:
                self._say(_t('MOB_CORE_GOT2', '받았습니다 — 폰에는 다음 동기화 때 갑니다.'))
            else:
                self._say(_t('MOB_CORE_FAIL', '받지 못했습니다 — 망을 보세요.'), err=True)
            self._prep_fill()
        self._run(fn, done)

    # ── ④ PC ⇒ 폰 보낼 자료 ──────────────────────────────────────────
    def _build_send_step(self, f):
        self._desc(f, 'MOB_D_SEND', '폰에 보낼 자료를 선택합니다. 왼쪽 「PC 보관함」에서 책을 누르면 소개가 뜨고 '
                   '[폰에 담기]로 오른쪽 「폰 보관함」으로 옮깁니다. 담은 것은 다음 동기화 때 폰 언어로 가고, '
                   '폰 보관함에서 [폰에서 빼기]한 것은 폰에서 걷습니다. 폰에 같은 것이 있으면 다시 안 보냅니다.')
        row = ttk.Frame(f)
        row.pack(fill='x', pady=(0, 4))
        self._core_var = tk.BooleanVar(value=False)
        # ★ 2026-10-12 기본은 끔 — 폰은 콘텐츠를 「자료 받기」(스토어·서버)에서 직접 받고 PC 와는 내 글만 주고받는다.
        ttk.Checkbutton(row, variable=self._core_var, command=self._send_save,
                        text=_t('MOB_SEND_CORE3', '콘텐츠 팩(공통·언어팩·유튜브)도 PC에서 보낸다 — 통신비 절약용 · 보통은 끔'
                                '(폰은 「자료 받기」에서 직접 받습니다)')).pack(side='left')
        self._b_send_now = ttk.Button(row, text=_t('MOB_BTN_SEND_NOW', '지금 폰에 보내기(동기화)'),
                                      command=self._sync)
        self._b_send_now.pack(side='right')
        self._core_lbl = tk.Label(f, anchor='w', justify='left', wraplength=960, fg=_C('fg_dim', '#666'))
        self._core_lbl.pack(fill='x', pady=(0, 4))
        _tfr(self._core_lbl, self.db_path, 'ui', -1)

        pw = ttk.PanedWindow(f, orient='horizontal')
        pw.pack(fill='both', expand=True)
        # 왼쪽 — PC 보관함
        lf = ttk.Frame(pw)
        pw.add(lf, weight=3)
        hd = ttk.Frame(lf)
        hd.pack(fill='x')
        tk.Label(hd, text=_t('MOB_PC_SHELF', 'PC 보관함'), font=None).pack(side='left')
        self._pc_lang = tk.StringVar()
        self._pc_lang_cb = ttk.Combobox(hd, textvariable=self._pc_lang, width=14, state='readonly')
        self._pc_lang_cb.pack(side='right')
        self._pc_lang_cb.bind('<<ComboboxSelected>>', lambda _e: self._send_fill())
        # ★ 2026-10-27 (docs/1.txt 1) 갈래 거르개 — 전체 · 도서 · 설교집 · 녹음(녹음만 골라 보기)
        self._pc_kinds = [('', _t('MOB_KIND_ALL', '전체')), ('BOOK', _t('MOB_BK_BOOK', '도서')),
                          ('SERMON', _t('MOB_BK_SERMON', '설교집')), ('VOICE', _t('MOB_BK_VOICE', '녹음'))]
        self._pc_kind = tk.StringVar(value=self._pc_kinds[0][1])
        kc = ttk.Combobox(hd, textvariable=self._pc_kind, width=8, state='readonly',
                          values=[n for _k, n in self._pc_kinds])
        kc.pack(side='right', padx=(0, 6))
        kc.bind('<<ComboboxSelected>>', lambda _e: self._send_fill())
        tv = ttk.Treeview(lf, columns=('title', 'kind', 'units', 'mb', 'st'), show='headings',
                          selectmode='browse')
        for cid, key, dflt, w, st, an in (('title', 'MOB_COL_BOOK', '책', 240, True, 'w'),
                                          ('kind', 'MOB_COL_BKIND', '갈래', 60, False, 'w'),
                                          ('units', 'MOB_COL_UNITS', '편', 45, False, 'e'),
                                          ('mb', 'MOB_COL_MB', '크기(약 MB)', 80, False, 'e'),
                                          ('st', 'MOB_COL_HIST', '이력', 150, False, 'w')):
            tv.heading(cid, text=_t(key, dflt))
            tv.column(cid, width=w, stretch=st, anchor=an)
        sb = ttk.Scrollbar(lf, command=tv.yview)
        tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        tv.pack(fill='both', expand=True)
        tv.bind('<<TreeviewSelect>>', lambda _e: self._bk_pick('PC'))
        self._bk_tv = tv
        # 가운데 — 책 소개 + 담기 단추(맨 위)
        mf = ttk.Frame(pw)
        pw.add(mf, weight=2)
        ab = ttk.Frame(mf)
        ab.pack(fill='x')
        self._b_put = ttk.Button(ab, text=_t('MOB_BTN_PUT', '폰에 담기 ⇒'), command=lambda: self._bk_move(True))
        self._b_put.pack(side='left')
        self._b_take = ttk.Button(ab, text=_t('MOB_BTN_TAKE', '⇐ 폰에서 빼기'),
                                  command=lambda: self._bk_move(False))
        self._b_take.pack(side='left', padx=(6, 0))
        self._intro = tk.Text(mf, height=10, wrap='word', width=24, relief='flat',
                              bg=_C('panel_alt', '#F4F6F7'), fg=_C('fg', '#222'), padx=8, pady=6)
        self._intro.pack(fill='both', expand=True, pady=(4, 0))
        _tfr(self._intro, self.db_path, 'ui', 0)
        # 오른쪽 — 폰 보관함
        rf = ttk.Frame(pw)
        pw.add(rf, weight=3)
        hd2 = ttk.Frame(rf)
        hd2.pack(fill='x')
        tk.Label(hd2, text=_t('MOB_PH_SHELF', '폰 보관함')).pack(side='left')
        self._ph_lang = tk.StringVar()
        self._ph_lang_cb = ttk.Combobox(hd2, textvariable=self._ph_lang, width=14, state='readonly')
        self._ph_lang_cb.pack(side='right')
        self._ph_lang_cb.bind('<<ComboboxSelected>>', lambda _e: self._send_fill())
        tv2 = ttk.Treeview(rf, columns=('title', 'lang', 'st'), show='headings', selectmode='browse')
        for cid, key, dflt, w, st, an in (('title', 'MOB_COL_BOOK', '책', 220, True, 'w'),
                                          ('lang', 'MOB_COL_LANG', '언어', 50, False, 'center'),
                                          ('st', 'MOB_COL_STATE', '상태', 170, False, 'w')):
            tv2.heading(cid, text=_t(key, dflt))
            tv2.column(cid, width=w, stretch=st, anchor=an)
        sb2 = ttk.Scrollbar(rf, command=tv2.yview)
        tv2.configure(yscrollcommand=sb2.set)
        sb2.pack(side='right', fill='y')
        tv2.pack(fill='both', expand=True)
        tv2.bind('<<TreeviewSelect>>', lambda _e: self._bk_pick('PH'))
        self._ph_tv = tv2
        for t in (tv, tv2):
            try:
                t.configure(style='Mobile.Treeview')
            except Exception:
                pass
        self._bk_sum = tk.Label(f, anchor='w', fg=_C('accent', '#2E86C1'))
        self._bk_sum.pack(fill='x', pady=(4, 0))
        _tfr(self._bk_sum, self.db_path, 'ui', -1)
        self._bk_sel = None
        self._send_f = f

    BIG_MB = 20.0          # 이보다 크면 폰 용량을 많이 쓴다고 알린다

    def _lang_values(self):
        vals = [_t('MOB_ALL_LANGS', '전체 언어')] + ['%s · %s' % (c, n) for c, n in _lang_names()]
        return vals

    def _picked_lang(self, var):
        v = var.get()
        return None if (not v or v == _t('MOB_ALL_LANGS', '전체 언어')) else v.split(' · ')[0]

    def _send_fill(self):
        """④ — 줄 하나 = (책, 언어). 제목은 그 언어로(없으면 책 줄의 원제목) · 1.txt 54."""
        import db_mobile_core as MC
        try:
            with appdb.connect(self.db_path) as conn:
                MS.ensure(conn)
                lang = MS.phone_lang(conn, (self.lang_getter() or 'KO'))
                want = MS.get_send(conn)
                pl = self._picked_lang(self._pc_lang) or lang
                books = MC.books_on_pc(conn, pl)
                ph = MS.phone_packs(conn)
                hist = MS.sent_history(conn, self._cur) if self._cur else []
                on = [MS.book_entry(e, lang) for e in want['books']]          # [(코드, 언어)]
                on_phone = [MC.book_code_of(x.get('name') or '') for x in ph]
                on_phone = [x for x in on_phone if x]
                need = {lg for _c, lg in on + on_phone}
                by_lang = {pl: {b['code']: b for b in books}}
                for lg in need - {pl}:
                    by_lang[lg] = {b['code']: b for b in MC.books_on_pc(conn, lg)}
        except Exception as e:                            # noqa: BLE001
            self._bk_sum.configure(text=str(e)[:120])
            return
        self._send_lang = lang
        self._core_var.set(want['core'])
        self._books_by = by_lang
        self._books = by_lang.get(lang) or by_lang[pl]
        langs = self._lang_values()
        for cb, var in ((self._pc_lang_cb, self._pc_lang), (self._ph_lang_cb, self._ph_lang)):
            cb.configure(values=langs)
            if not var.get():
                var.set(langs[0] if cb is self._ph_lang_cb else next(
                    (v for v in langs if v.startswith(lang + ' ')), langs[0]))
        last = {}                                  # (책, 언어) → 마지막 이력
        for h in hist:
            bc = MC.book_code_of(h['name'])
            if bc and bc not in last:
                last[bc] = h
        on_set, ph_set = set(on), set(on_phone)
        tv = self._bk_tv
        tv.delete(*tv.get_children())
        tv.tag_configure('big', foreground=_C('warning', '#B9770E'))
        for b in books:
            key = (b['code'], pl)
            if key in on_set or key in ph_set:
                continue                            # 폰 쪽 목록으로 옮겨 갔다
            kf = self._kind_pick()
            if kf == 'VOICE' or (kf and kf != ('SERMON' if b['kind'] == 'SERMON' else 'BOOK')):
                continue
            if self._picked_lang(self._pc_lang) and pl not in b['langs'] and pl not in ('EN',):
                continue
            mb = b['chars'] * 0.42 / 1e6          # 실측 gzip ≈ 글자당 0.42 바이트
            h = last.get(key)
            hs = ''
            if h and h.get('gone_at'):
                hs = _t('MOB_HIST_GONE', '예전에 보냄 · %s 에 뺌') % (h['gone_at'] or '')[:10]
            tv.insert('', 'end', iid='%s|%s' % key, tags=('big',) if mb > self.BIG_MB else (),
                      values=(b['title'], self._bk_kind(b['kind']), b['units'], '%.1f' % mb, hs))
        phl = self._picked_lang(self._ph_lang)
        tv2 = self._ph_tv
        tv2.delete(*tv2.get_children())
        tv2.tag_configure('wait', foreground=_C('accent', '#2E86C1'))
        tv2.tag_configure('out', foreground=_C('warning', '#B9770E'))
        tot, n = 0.0, 0

        def title_of(code, lg):
            b = (by_lang.get(lg) or {}).get(code) or {}
            return b.get('title') or code, b

        for key in sorted(on_set | ph_set, key=lambda k: (title_of(*k)[0], k[1])):
            code, lg = key
            if phl and phl != lg:
                continue
            ttl, b = title_of(code, lg)
            if key in on_set and key in ph_set:
                st, tag = _t('MOB_PH_HAVE', '폰에 있음'), ()
            elif key in on_set:
                st, tag = _t('MOB_PH_WAIT', '보낼 차례 — 다음 동기화'), ('wait',)
            else:
                st, tag = _t('MOB_PH_OUT', '뺄 차례 — 다음 동기화'), ('out',)
            tv2.insert('', 'end', iid='%s|%s' % key, tags=tag, values=(ttl, lg, st))
            if key in on_set:
                tot += b.get('chars', 0) * 0.42 / 1e6
                n += 1
        # ★ 2026-10-14 87 — 녹음(목소리 · 역본 · 책 한 줄 · Opus 로 보낸다)
        vn, vmb = self._voice_rows(tv, tv2, lang)
        tot += vmb
        self._bk_sum.configure(text=_t('MOB_SEND_SUM2', '폰 언어 %s · 폰 보관함 %d권 · 약 %.1f MB')
                               % (lang, n + vn, tot))
        self._bk_show(self._bk_sel)
        self._step_marks()

    def _voice_rows(self, tv, tv2, lang):
        """④ 녹음 줄 — PC 보관함(안 고른 것) · 폰 보관함(고른 것) → (고른 수, 약 MB)."""
        import voice_sync as VS
        try:
            with appdb.connect(self.db_path) as conn:
                rows = VS.shelf(conn)
                want = set(VS.get_send(conn))
                names = dict(conn.execute("SELECT book_code, full_name FROM book_names WHERE lang_code=?",
                                          ((self.lang_getter() or 'KO').upper(),)).fetchall())
        except Exception:                                 # noqa: BLE001
            return 0, 0.0
        self._voices = {r['id']: r for r in rows}
        n, mb = 0, 0.0
        for r in rows:
            title = '%s · %s · %s' % (names.get(r['bcode'], str(r['bcode'])), r['owner'], r['version'])
            m = r['bytes'] / 1e6
            if r['id'] in want:
                if not self._picked_lang(self._ph_lang):
                    tv2.insert('', 'end', iid='V|' + r['id'], tags=('wait',),
                               values=(title, '♪', _t('MOB_V_SEND', '녹음 %d절 — 동기화 때 보냄') % r['files']))
                n += 1
                mb += m
            elif self._kind_pick() in ('', 'VOICE'):
                tv.insert('', 'end', iid='V|' + r['id'],
                          values=(title, _t('MOB_BK_VOICE', '녹음'), r['n'], '%.1f' % m, ''))
        return n, mb

    def _kind_pick(self):
        v = self._pc_kind.get() if hasattr(self, '_pc_kind') else ''
        return next((k for k, n in self._pc_kinds if n == v), '') if v else ''

    def _bk_kind(self, cat):
        return _t('MOB_BK_SERMON', '설교집') if cat == 'SERMON' else _t('MOB_BK_BOOK', '도서')

    def _bk_pick(self, side):
        tv = self._bk_tv if side == 'PC' else self._ph_tv
        sel = tv.selection()
        if not sel:
            return
        other = self._ph_tv if side == 'PC' else self._bk_tv
        if other.selection():
            other.selection_remove(other.selection())
        self._bk_sel = (side, sel[0])
        self._bk_show(self._bk_sel)

    def _bk_show(self, sel):
        import db_mobile_core as MC
        t = self._intro
        t.configure(state='normal')
        t.delete('1.0', 'end')
        self._b_put.configure(state='disabled')
        self._b_take.configure(state='disabled')
        if not sel:
            t.insert('1.0', _t('MOB_BK_PICK', '책을 누르면 소개가 여기 뜹니다.'))
            t.configure(state='disabled')
            return
        side, iid = sel
        if iid.startswith('V|'):
            r = (getattr(self, '_voices', {}) or {}).get(iid[2:]) or {}
            t.insert('end', _t('MOB_V_INTRO', '녹음 — %s · %s\n녹음한 절 %d · 이 PC 에 파일 %d\n'
                                             '폰에는 Opus(말소리 압축 · 약 %.1f MB)로 바꿔 보냅니다. '
                                             '폰에서 녹음한 것은 그대로 두고, 여기서 빼면 PC 가 보낸 사본만 폰에서 걷습니다.')
                     % (r.get('owner', ''), r.get('version', ''), r.get('n', 0), r.get('files', 0),
                        r.get('bytes', 0) / 1e6))
            t.configure(state='disabled')
            (self._b_put if side == 'PC' else self._b_take).configure(state='normal')
            return
        code, lg = MS.book_entry(iid, self._send_lang)
        try:
            with appdb.connect(self.db_path) as conn:
                title, author, desc = MC.book_intro(conn, code, lg)
        except Exception:                                 # noqa: BLE001
            title, author, desc = code, '', ''
        b = ((getattr(self, '_books_by', {}) or {}).get(lg) or {}).get(code) or {}
        t.insert('end', title + '\n')
        if author:
            t.insert('end', author + '\n')
        if b:
            t.insert('end', '%s · %d%s · %.1f MB\n' % (self._bk_kind(b.get('kind')), b.get('units', 0),
                                                       _t('MOB_UNIT_SUF', '편'), b.get('chars', 0) * 0.42 / 1e6))
        t.insert('end', '\n' + (desc or _t('MOB_BK_NODESC', '(소개문이 없습니다)')))
        t.configure(state='disabled')
        (self._b_put if side == 'PC' else self._b_take).configure(state='normal')

    def _bk_move(self, put):
        if not self._bk_sel:
            return
        iid = self._bk_sel[1]
        if iid.startswith('V|'):
            import voice_sync as VS
            with appdb.connect(self.db_path) as conn:
                cur = set(VS.get_send(conn))
                (cur.add if put else cur.discard)(iid[2:])
                VS.set_send(conn, cur)
                conn.commit()
            self._bk_sel = ('PH' if put else 'PC', iid)
            self._send_fill()
            tv = self._ph_tv if put else self._bk_tv
            if tv.exists(iid):
                tv.selection_set(iid)
                tv.see(iid)
            return
        code, lg = MS.book_entry(iid, self._send_lang)
        with appdb.connect(self.db_path) as conn:
            # 옛 값(코드만 = 폰 언어)은 새 꼴로 옮겨 적는다
            books = {'%s|%s' % MS.book_entry(e, self._send_lang) for e in MS.get_send(conn)['books']}
            if put:
                books.add('%s|%s' % (code, lg))
            else:
                books.discard('%s|%s' % (code, lg))
            MS.set_send(conn, books=sorted(books))
        code = '%s|%s' % (code, lg)
        self._bk_sel = ('PH' if put else 'PC', code)
        self._send_fill()
        tv = self._ph_tv if put else self._bk_tv
        if tv.exists(code):
            tv.selection_set(code)
            tv.see(code)

    def _send_toggle(self, e):
        """(옛 문 — 시험용) 줄을 누르면 담고 뺀다."""
        iid = self._bk_tv.identify_row(e.y)
        if not iid:
            return
        with appdb.connect(self.db_path) as conn:
            books = set(MS.get_send(conn)['books']) ^ {iid}
            MS.set_send(conn, books=sorted(books))
        self._send_fill()

    def _send_save(self):
        with appdb.connect(self.db_path) as conn:
            MS.set_send(conn, core=bool(self._core_var.get()))

    # ── ⑤ 폰 ⇒ PC 받은 글 ────────────────────────────────────────────
    def _build_recv(self, f):
        self._desc(f, 'MOB_D_RECV', '폰에서 쓴 노트·설명문 수정·연구자료·AI 대화입니다. 확정본일 수도 있습니다. '
                   '[PC에 다운로드]하면 이 PC 의 글이 되고(다듬어 받을 수 있습니다) 다음 동기화 때 폰도 PC 판을 '
                   '받습니다. [다운로드 안함]이면 PC 에 들이지 않습니다 — 폰의 글은 그대로 두고, 「폰에서도 '
                   '지우기」를 선택한 것만 다음 동기화 때 폰에서 지웁니다.')
        sf = ttk.Frame(f)
        sf.pack(fill='x')
        self._st_var = tk.StringVar(value='NEW')
        self._st_btn = {}
        for code, key, dflt in STATES:
            b = ttk.Radiobutton(sf, text=_t(key, dflt), value=code, variable=self._st_var, command=self._fill)
            b.pack(side='left', padx=(0, 10))
            self._st_btn[code] = (b, key, dflt)
        pw = ttk.PanedWindow(f, orient='horizontal')
        pw.pack(fill='both', expand=True, pady=(4, 0))
        self._pw = pw
        lf = ttk.Frame(pw)
        pw.add(lf, weight=1)
        self._tv = ttk.Treeview(lf, columns=('kind', 'what', 'when'), show='headings', selectmode='browse')
        for cid, key, dflt, w, st in (('kind', 'MOB_COL_KIND', '구분', 110, False),
                                      ('what', 'MOB_COL_WHAT', '내용', 260, True),
                                      ('when', 'MOB_COL_WHEN', '폰에서 쓴 때', 130, False)):
            self._tv.heading(cid, text=_t(key, dflt))
            self._tv.column(cid, width=w, stretch=st, anchor='w')
        sb = ttk.Scrollbar(lf, command=self._tv.yview)
        self._tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._tv.pack(side='left', fill='both', expand=True)
        self._tv.bind('<<TreeviewSelect>>', lambda _e: self._on_pick())
        try:
            self._tv.configure(style='Mobile.Treeview')
        except Exception:
            pass
        rf = ttk.Frame(pw)
        pw.add(rf, weight=2)
        ab = ttk.Frame(rf)                 # 값을 바꾸는 단추 — 맨 위(§0)
        ab.pack(fill='x')
        self._b_adopt = ttk.Button(ab, text=_t('MOB_BTN_DOWN', 'PC에 다운로드'), command=self._adopt)
        self._b_adopt.pack(side='left')
        self._b_save = ttk.Button(ab, text=_t('MOB_BTN_KEEP', '다듬은 글 저장'), command=self._keep)
        self._b_save.pack(side='left', padx=(6, 0))
        # ★ 첫 이주(2026-10-12 · 폰이 먼저) — 폰을 오래 쓰다 PC 를 처음 이으면 대기 글이 많다 → 한 번에
        self._b_all = ttk.Button(ab, text=_t('MOB_BTN_DOWN_ALL', '모두 PC에 다운로드'), command=self._adopt_all)
        self._b_all.pack(side='left', padx=(6, 0))
        self._asref_var = tk.BooleanVar(value=False)
        self._asref = ttk.Checkbutton(ab, variable=self._asref_var,
                                      text=_t('MOB_AI_ASREF', '연구자료로도 저장'))
        self._b_disc = ttk.Button(ab, text=_t('MOB_BTN_SKIP', '다운로드 안함'), command=self._discard)
        self._b_disc.pack(side='right')       # 되돌리기 어려운 쪽은 떼어 둔다
        self._drop_var = tk.BooleanVar(value=False)          # 기본 = 폰의 글은 안 지움
        self._drop_cb = ttk.Checkbutton(ab, variable=self._drop_var,
                                        text=_t('MOB_DROP_PHONE', '폰에서도 지우기'))
        self._drop_cb.pack(side='right', padx=(0, 6))
        self._head = tk.Label(rf, anchor='w', justify='left', fg=_C('fg', '#222'), wraplength=560)
        self._head.pack(fill='x', pady=(6, 2))
        _tfr(self._head, self.db_path, 'ui', 0)
        tf = ttk.Frame(rf)
        tf.pack(fill='x')
        self._title_lbl = ttk.Label(tf, text=_t('MOB_TITLE', '제목'))
        self._title_var = tk.StringVar()
        self._title_ent = ttk.Entry(tf, textvariable=self._title_var)
        self._pc_lbl = tk.Label(rf, anchor='w', fg=_C('fg_dim', '#666'), text=_t('MOB_NOW_PC', '지금 PC 의 글'))
        self._pc_txt = tk.Text(rf, height=6, wrap='word', width=20, bg=_C('panel_alt', '#F4F6F7'))
        self._mine_lbl = tk.Label(rf, anchor='w', fg=_C('fg_dim', '#666'),
                                  text=_t('MOB_FROM_PHONE2', '폰에서 온 글 — 고쳐서 받을 수 있습니다'))
        self._mine_txt = tk.Text(rf, height=10, wrap='word', width=20, undo=True)
        for w in (self._pc_txt, self._mine_txt, self._pc_lbl, self._mine_lbl):
            _tfr(w, self.db_path, 'prose' if isinstance(w, tk.Text) else 'ui',
                 0 if isinstance(w, tk.Text) else -1)
        self._sel = None


    # ── ⑥ 받은 글 최종 점검 ──────────────────────────────────────────
    # ★ 사용자 결정(2026-10-10) — **그 자리에서 고친다, 편집기는 새로 만들지 않는다**:
    #   오른쪽 칸에 PC 에 이미 있는 고치는 부품을 그대로 심는다(묵상노트 = P2 묵상노트 부품 ·
    #   설명문 = My Edit 「글」 구획 부품 · 연구/설교노트 = P4 연구노트 화면(목록 끔)).
    #   AI 대화는 고칠 글이 아니라 읽고 연구자료로 담는다. 「점검 끝」은 표시일 뿐 받은 것을 되돌리지 않는다.
    def _build_check(self, f):
        self._desc(f, 'MOB_D_CHECK', '폰에서 받아 PC 에 들인 글입니다. 글이 지금 PC 의 어디에 있는지 보이고, '
                   '오른쪽에서 바로 고칠 수 있습니다(PC 의 그 화면과 같은 부품입니다). 다 봤으면 [점검 끝]을 누르세요.')
        top = ttk.Frame(f)
        top.pack(fill='x')
        self._ck_kind = tk.StringVar(value='')
        for code, key, dflt in CK_KINDS:
            ttk.Radiobutton(top, text=_t(key, dflt), value=code, variable=self._ck_kind,
                            command=self._ck_fill).pack(side='left', padx=(0, 8))
        ttk.Separator(top, orient='vertical').pack(side='left', fill='y', padx=6)
        self._ck_state = tk.StringVar(value='TODO')
        self._ck_st_btn = {}
        for code, key, dflt in CK_STATES:
            b = ttk.Radiobutton(top, text=_t(key, dflt), value=code, variable=self._ck_state,
                                command=self._ck_fill)
            b.pack(side='left', padx=(0, 8))
            self._ck_st_btn[code] = (b, key, dflt)
        self._ck_old_btn = ttk.Button(top, command=self._ck_old)
        pw = ttk.PanedWindow(f, orient='horizontal')
        pw.pack(fill='both', expand=True, pady=(4, 0))
        lf = ttk.Frame(pw)
        pw.add(lf, weight=1)
        self._ck_tv = ttk.Treeview(lf, columns=('kind', 'what', 'when'), show='headings', selectmode='browse')
        for cid, key, dflt, w, st in (('kind', 'MOB_COL_KIND', '구분', 100, False),
                                      ('what', 'MOB_COL_WHAT', '내용', 240, True),
                                      ('when', 'MOB_CK_COL_WHEN', 'PC 에 받은 때', 120, False)):
            self._ck_tv.heading(cid, text=_t(key, dflt))
            self._ck_tv.column(cid, width=w, stretch=st, anchor='w')
        sb = ttk.Scrollbar(lf, command=self._ck_tv.yview)
        self._ck_tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._ck_tv.pack(side='left', fill='both', expand=True)
        self._ck_tv.bind('<<TreeviewSelect>>', lambda _e: self._ck_pick())
        try:
            self._ck_tv.configure(style='Mobile.Treeview')
        except Exception:
            pass
        rf = ttk.Frame(pw)
        pw.add(rf, weight=3)
        ab = ttk.Frame(rf)                 # 값을 바꾸는 단추 — 맨 위(§0)
        ab.pack(fill='x')
        self._ck_btn = ttk.Button(ab, text=_t('MOB_CK_BTN_DONE', '점검 끝'), command=self._ck_toggle,
                                  state='disabled')
        self._ck_btn.pack(side='left')
        self._ck_asref = ttk.Button(ab, command=self._ck_save_ref)
        self._ck_where = tk.Label(rf, anchor='w', justify='left', fg=_C('accent', '#2E86C1'), wraplength=720)
        self._ck_where.pack(fill='x', pady=(6, 0))
        _tfr(self._ck_where, self.db_path, 'ui', 0)
        self._ck_hint = tk.Label(rf, anchor='w', justify='left', fg=_C('fg_dim', '#666'), wraplength=720)
        self._ck_hint.pack(fill='x', pady=(0, 4))
        _tfr(self._ck_hint, self.db_path, 'ui', -1)
        self._ck_host = ttk.Frame(rf)
        self._ck_host.pack(fill='both', expand=True)
        self._ck_rows = {}
        self._ck_sel = None
        self._ck_part = None

    def _ck_fill(self):
        try:
            with appdb.connect(self.db_path) as conn:
                rows = MS.review(conn, self._ck_state.get())
                counts = {c: len(MS.review(conn, c)) for c, _k, _d in CK_STATES}
                old = MS.old_unchecked(conn)
        except Exception:
            rows, counts, old = [], {}, []
        for c, (b, key, dflt) in self._ck_st_btn.items():
            n = counts.get(c, 0)
            b.configure(text=('%s (%d)' % (_t(key, dflt), n)) if n else _t(key, dflt))
        if old:
            self._ck_old_btn.configure(text=_t('MOB_CK_OLD', '예전에 받은 글 %d개 — 모두 점검 끝으로') % len(old))
            self._ck_old_btn.pack(side='right')
        else:
            self._ck_old_btn.pack_forget()
        k = self._ck_kind.get()
        if k:
            rows = [r for r in rows if r['kind'] == k or (k == 'NOTE' and r['kind'] in ('NOTE_ADD', 'NOTE_EDIT', 'NOTE_DEL'))]
        self._ck_rows = {str(r['inbox_id']): r for r in rows}
        self._ck_tv.delete(*self._ck_tv.get_children())
        for r in rows:
            mark = '✓ ' if r.get('checked_at') else ''
            self._ck_tv.insert('', 'end', iid=str(r['inbox_id']),
                               values=(mark + kind_label(r['kind']), self._what(r), (r['received_at'] or '')[:16]))
        if not rows:
            self._ck_tv.insert('', 'end', iid='EMPTY',
                               values=('', _t('MOB_CK_EMPTY', '점검할 글이 없습니다'), ''))
        self._step_marks()
        self._ck_clear()

    def _ck_old(self):
        with appdb.connect(self.db_path) as conn:
            MS.check_all(conn, MS.old_unchecked(conn))
        self._ck_fill()

    def _ck_clear(self):
        self._ck_leave()
        self._ck_sel = None
        for w in self._ck_host.winfo_children():
            w.destroy()
        self._ck_where.configure(text=_t('MOB_PICK2', '왼쪽에서 글을 선택하세요.'))
        self._ck_hint.configure(text='')
        self._ck_btn.configure(state='disabled', text=_t('MOB_CK_BTN_DONE', '점검 끝'))
        self._ck_asref.pack_forget()

    def _ck_leave(self):
        """다른 글로 옮기기 전 — 심어 둔 부품이 쓰던 글을 놓치지 않게(그 부품의 저장 규칙 그대로)."""
        part, self._ck_part = self._ck_part, None
        if part is None:
            return
        for meth in ('_autosave', 'save_changed'):
            fn = getattr(part, meth, None)
            if callable(fn):
                try:
                    fn() if meth == '_autosave' else fn(silent=True)
                except TypeError:
                    try:
                        fn()
                    except Exception:
                        pass
                except Exception:
                    pass

    def _ck_pick(self):
        sel = self._ck_tv.selection()
        r = self._ck_rows.get(sel[0]) if sel else None
        self._ck_clear()
        if not r:
            return
        self._ck_sel = r
        lang = (self.lang_getter() or 'KO')
        with appdb.connect(self.db_path) as conn:
            w = MS.where_is(conn, r)
        self._ck_btn.configure(state='normal', text=_t('MOB_CK_BTN_UNDO', '다시 점검') if r.get('checked_at')
                               else _t('MOB_CK_BTN_DONE', '점검 끝'))
        k = r['kind']
        if not w.get('alive'):
            self._ck_where.configure(text=_t('MOB_CK_GONE', '받은 뒤 PC 에서 지웠습니다 — 그 자리에 이제 없습니다.'))
            return
        import medi_note
        if k in ('NOTE', 'NOTE_ADD', 'NOTE_EDIT', 'NOTE_DEL') and w.get('vid'):
            self._ck_where.configure(text=_t('MOB_CK_AT', '지금 있는 곳: %s') % ('「%s」 · %s' % (
                _t('P2T_NOTE', '묵상노트'), medi_note.verse_label(self.db_path, w['vid'], w.get('end_vid'), lang))))
            self._ck_hint.configure(text=_t('MOB_CK_H_NOTE', '붙은 구절이 맞는지, 같은 구절에 비슷한 노트가 이미 있는지 '
                                                             '보세요 — 아래가 그 구절의 노트 전부입니다(받은 글이 펼쳐져 있습니다).'))
            from note_refr_panel import NoteRefrPanel
            part = NoteRefrPanel(self._ck_host, self.db_path, 'VERS_NOTE', self.lang_getter)
            part.pack(fill='both', expand=True)
            part.load(w['vid'])
            for i, rec in enumerate(getattr(part, '_records', [])):
                if rec.get('id') == w.get('note_id'):
                    part._open_card(i)
                    break
            self._ck_part = part
        elif k in ('NOTE', 'NOTE_ADD', 'NOTE_EDIT', 'NOTE_DEL'):
            self._ck_where.configure(text=_t('MOB_CK_AT', '지금 있는 곳: %s') % _t(
                'MOB_CK_AT_UNIT', '도서/설교집 · 그 편의 [도서묵상노트]'))
            self._ck_hint.configure(text=_t('MOB_CK_H_UNIT', '도서 편에 붙은 노트입니다 — 수정하려면 그 편을 열어 [도서묵상노트]에서 수정하세요.'))
            t = tk.Text(self._ck_host, wrap='word', height=12, width=20)
            t.insert('1.0', r['data'].get('body') or '')
            t.configure(state='disabled')
            t.pack(fill='both', expand=True)
            _tfr(t, self.db_path, 'prose', 0)
        elif k == 'DESC':
            tt = w.get('text_type') or ''
            key, dflt = DESC_NAME.get(tt, ('', tt))
            nm = _t(key, dflt) if key else dflt
            place = '「%s」 · %s' % (_t('P2T_DESC', '설명'), nm)
            if w.get('vid'):
                place += ' · ' + medi_note.verse_label(self.db_path, w['vid'], None, lang)
            self._ck_where.configure(text=_t('MOB_CK_AT', '지금 있는 곳: %s') % place
                                     + _t('MOB_CK_AT_MINE', '  (내 설명문 — 배포된 원래 글은 그대로 있습니다)'))
            if w.get('vid'):
                self._ck_hint.configure(text=_t('MOB_CK_H_DESC', '그 구절의 글 구획 전부입니다. 받은 글이 든 구획을 '
                                                                 '[비교·되돌리기]로 원래 글과 견주어 보세요. 고친 뒤 [바뀐 것 저장].'))
                import overlay_center as OC
                part = OC._SectionsPanel(self._ck_host, _Center(self.db_path, lang.upper()))
                part.pack(fill='both', expand=True)
                part.load_verse(int(w['vid']))
                self._ck_part = part
            else:
                self._ck_hint.configure(text=_t('MOB_CK_H_ENT', '용어 설명입니다 — 원래 글과 내 글을 견주어 보고, 수정하려면 '
                                                                '주요용어 화면의 My Edit 에서 고치세요.'))
                self._ck_pair(tt, w.get('clicked_id'), lang)
        elif k == 'REF':
            self._ck_where.configure(text=_t('MOB_CK_AT', '지금 있는 곳: %s') % ('「%s」 · %s' % (
                _t('P2T_REFR', '연구/설교노트'), w.get('title') or '')))
            self._ck_hint.configure(text=_t('MOB_CK_H_REF', '제목과 「연결」 칸의 구절(글 속 약명을 읽어 저절로 걸린 것)이 '
                                                            '맞는지 보세요. 틀린 연결은 그 칸에서 뗍니다.'))
            from p4_ref_view import RefDetailView
            part = RefDetailView(self._ck_host, self.db_path, lang_getter=self.lang_getter, show_list=False)
            part.pack(fill='both', expand=True)
            part.show_user(int(w['ref_id']))
            self._ck_part = part
        elif k == 'AI':
            self._ck_where.configure(text=_t('MOB_CK_AT', '지금 있는 곳: %s') % ('「%s」 · %s · %s' % (
                _t('P4T_AI', 'AI 도우미'), _t('MOB_CK_CHATLIST', '대화목록'), w.get('title') or '')))
            fin = (r['data'].get('final') or '').strip()
            if w.get('ref_id'):
                hint = _t('MOB_CK_H_AI_SAVED', '연구자료로 이미 담았습니다 — 다시 누르면 그 글을 이 글로 새로 고칩니다.')
            elif fin:
                hint = _t('MOB_CK_H_AI_FIN', '최종 정리본을 읽고, 남길 글이면 [최종 정리본을 연구자료로 저장]을 누르세요. '
                                             '대화는 AI 도우미 대화목록에서 이어 쓸 수 있습니다.')
            else:
                hint = _t('MOB_CK_H_AI', '최종 정리본 없이 받은 대화입니다. 남길 글이면 [대화를 연구자료로 저장]을 '
                                         '누르세요(폰에서 「한 글로」를 먼저 하면 정리본이 함께 옵니다).')
            self._ck_hint.configure(text=hint)
            self._ck_asref.configure(text=_t('MOB_CK_AI_SAVE_FIN', '최종 정리본을 연구자료로 저장') if fin
                                     else _t('MOB_CK_AI_SAVE_ALL', '대화를 연구자료로 저장'))
            self._ck_asref.pack(side='left', padx=(8, 0))
            t = tk.Text(self._ck_host, wrap='word', height=14, width=20)
            sb = ttk.Scrollbar(self._ck_host, command=t.yview)
            t.configure(yscrollcommand=sb.set)
            sb.pack(side='right', fill='y')
            t.pack(fill='both', expand=True)
            t.insert('1.0', ai_preview(r['data']))
            t.configure(state='disabled')
            _tfr(t, self.db_path, 'prose', 0)

    def _ck_pair(self, tt, cid, lang):
        """용어 설명 — 원래 글 ↔ 내 글(읽기)."""
        try:
            import overlay_edit as OE
            with appdb.connect(self.db_path) as conn:
                _v, _st, sys_t, mine = OE.pair_state(conn, tt, int(cid), lang.upper(), 'LAY')
        except Exception:
            sys_t, mine = '', ''
        for lab, body in ((_t('MOB_CK_ORIG', '원래 글'), sys_t), (_t('MOB_CK_MINE', '내 글'), mine)):
            tk.Label(self._ck_host, text=lab, anchor='w', fg=_C('fg_dim', '#666')).pack(fill='x')
            t = tk.Text(self._ck_host, wrap='word', height=7, width=20)
            t.insert('1.0', body or '')
            t.configure(state='disabled')
            t.pack(fill='both', expand=True, pady=(0, 6))
            _tfr(t, self.db_path, 'prose', 0)

    def _ck_toggle(self):
        r = self._ck_sel
        if not r:
            return
        self._ck_leave()
        with appdb.connect(self.db_path) as conn:
            MS.set_checked(conn, r['inbox_id'], on=not r.get('checked_at'))
        self._ck_fill()

    def _ck_save_ref(self):
        r = self._ck_sel
        if not r:
            return
        try:
            import user_ai
            with appdb.connect(self.db_path) as conn:
                w = MS.where_is(conn, r)
                fin = (r['data'].get('final') or '').strip() or None
                rid = user_ai.save_as_ref(conn, int(w['chat_id']), text=fin)
        except Exception as e:                            # noqa: BLE001
            self._say(str(e), err=True)
            return
        self._say(_t('MOB_CK_SAVED_REF', '연구자료로 저장했습니다 — 「연구/설교노트」 탭에서 볼 수 있습니다.') if rid
                  else _t('MOB_CK_SAVE_FAIL', '저장하지 못했습니다.'), err=not rid)
        keep = str(r['inbox_id'])
        self._ck_fill()
        if keep in self._ck_rows:
            self._ck_tv.selection_set(keep)

    # ══════════════════════════════════════════════════════════════════
    #  기기
    # ══════════════════════════════════════════════════════════════════
    def _dev(self):
        for d in self._devs:
            if d['device_id'] == self._cur:
                return d
        return None

    def reload(self):
        try:
            with appdb.connect(self.db_path) as conn:
                MS.ensure(conn)
                self._devs = MS.devices(conn)
                n_new = len(MS.inbox(conn, 'NEW'))
        except Exception as e:
            self._say(_t('MOB_LOAD_FAIL', '모바일 연결 정보를 못 읽었습니다: ') + str(e), err=True)
            self._devs, n_new = [], 0
        names = ['%s  (%s:%s)' % (d['name'] or d['device_id'], d['host'], d['port']) for d in self._devs]
        self._dev_cb.configure(values=names)
        if self._devs:
            ids = [d['device_id'] for d in self._devs]
            i = ids.index(self._cur) if self._cur in ids else 0
            self._dev_cb.current(i)
            self._cur = ids[i]
        else:
            self._dev_var.set('')
            self._cur = None
        self._on_dev()
        self._step_marks(n_new)
        if not getattr(self, '_opened', False):         # 처음 열 때 — 할 차례인 단계로
            self._opened = True
            try:
                with appdb.connect(self.db_path) as conn:
                    n_ck = len(MS.review(conn, 'TODO'))
            except Exception:
                n_ck = 0
            self._step_var.set('CONN' if not self._devs else
                               ('RECV' if n_new else ('CHECK' if n_ck else 'SYNC')))
        self._show_step()

    def _send_pending(self, conn, lang):
        """④ 아직 남은 일 수 — 담았는데 폰에 없는 책 + 뺐는데 폰에 남은 책 + 폰 판과 다른 코어팩."""
        import db_mobile_core as MC
        want = MS.get_send(conn)
        names = {x.get('name'): x.get('sha') for x in MS.phone_packs(conn)}
        on = {MC.book_file_name(*MS.book_entry(e, lang)) for e in want['books']}
        on_ph = {n for n in names if n and n.startswith('mobile_book_')}
        n = len(on ^ on_ph)
        if want['core']:
            n += sum(1 for c in MC.compare(lang, MS.phone_packs(conn), None) if c['state'] != 'SAME')
        return n

    def _step_marks(self, n_new=None):
        """단계마다 끝났는가(✓) — 1.txt 54 「2~5단계도 V 체크가 없어 진행오류처럼 보인다」.

        ① 연결된 폰이 있다 · ② 그 폰과 동기화가 성공한 적이 있다 · ③ PC 와 폰의 코어팩 판이 같다 ·
        ④ 보낼 차례·뺄 차례가 없다 · ⑤ 다운로드 대기가 없다."""
        done = {}
        extra = {}
        try:
            with appdb.connect(self.db_path) as conn:
                MS.ensure(conn)
                if n_new is None:
                    n_new = len(MS.inbox(conn, 'NEW'))
                d = self._dev()
                lang = MS.phone_lang(conn, (self.lang_getter() or 'KO'))
                if d:
                    import db_mobile_core as MC
                    done['CONN'] = True
                    res = str(d.get('last_result') or '')
                    done['SYNC'] = bool(d.get('last_sync')) and not any(
                        w in res for w in ('실패', 'fail', 'Error', 'error', '오류'))
                    cmp = MC.compare(lang, MS.phone_packs(conn), None)
                    done['PREP'] = bool(cmp) and all(c['state'] == 'SAME' for c in cmp)
                    done['SEND'] = done['SYNC'] and self._send_pending(conn, lang) == 0
                    done['RECV'] = done['SYNC'] and not n_new
                n_ck = len(MS.review(conn, 'TODO'))
                done['CHECK'] = bool(done.get('RECV')) and not n_ck
                if n_ck:
                    extra['CHECK'] = ' (%d)' % n_ck
        except Exception:                                 # noqa: BLE001
            n_new = n_new or 0
        if n_new:
            extra['RECV'] = ' (%d)' % n_new
        self._step_done = done
        self._step_extra = extra
        self._paint_steps()

    def _on_dev(self):
        i = self._dev_cb.current()
        d = self._devs[i] if 0 <= i < len(self._devs) else None
        self._cur = d['device_id'] if d else None
        have = d is not None and not self._busy
        for b in (self._b_sync, self._b_unpair, self._b_send_now):
            b.configure(state='normal' if have else 'disabled')
        if d:
            self._say((_t('MOB_LAST', '마지막 동기화') + ': %s · %s') % (d['last_sync'] or '-', d['last_result'] or '-'))
        else:
            self._say(_t('MOB_NO_PHONE3', '연결한 폰이 없습니다 — 폰에서 「설정 ▸ PC 연결」 화면을 열고 '
                         '「같은 와이파이를 사용하는 폰 찾기」를 누르세요.'))

    def _say(self, text, err=False):
        self._status.configure(text=text, fg=_C('danger', '#C0392B') if err else _C('accent', '#2E86C1'))

    # ── 망 쓰는 일 — 일꾼 스레드 ─────────────────────────────────────
    def _run(self, fn, done):
        if self._busy:
            return
        self._busy = True
        self._stop = False
        for b in (self._b_sync, self._b_conn, self._b_unpair, self._b_this, self._b_send_now,
                  self._b_check, self._b_core):
            b.configure(state='disabled')
        self._b_stop.pack(side='left', padx=(6, 0), after=self._b_conn)

        def work():
            try:
                self._q.put(('ok', fn()))
            except Exception as e:                        # noqa: BLE001
                self._q.put(('err', e))
        threading.Thread(target=work, daemon=True).start()
        self._pump(done)

    def _pump(self, done):
        try:
            while True:
                kind, val = self._q.get_nowait()
                if kind == 'log':
                    self._say(val)
                    continue
                if kind == 'code':
                    self._show_code(val)
                    continue
                self._busy = False
                self._b_stop.pack_forget()
                for b in (self._b_conn, self._b_this, self._b_check, self._b_core):
                    b.configure(state='normal')
                self._on_dev()
                done(kind, val)
                return
        except queue.Empty:
            pass
        if self.winfo_exists():
            self.after(120, lambda: self._pump(done))

    def _stop_now(self):
        self._stop = True

    # ── 연결하기 ─────────────────────────────────────────────────────
    def _open_cf(self, on):
        if on:
            self._cf.pack(fill='x', pady=(4, 6), after=self._conn_row)
        else:
            self._cf.pack_forget()

    def _show_code(self, code):
        self._code_say.configure(text=_t('MOB_CODE_SAY', '두 화면의 숫자가 같으면 폰에서 [허용]을 누르세요.'))
        self._code_lbl.configure(text=' '.join(code))

    def _connect(self):
        self._show_step('CONN')
        self._found = []
        self._found_lb.delete(0, 'end')
        self._code_say.configure(text='')
        self._code_lbl.configure(text='')
        self._open_cf(True)
        self._say(_t('MOB_SCANNING', '같은 와이파이에서 폰을 찾는 중…'))
        tg = self.targets

        def fn():
            return MS.scan_phones(tg, wait=4.0, should_stop=lambda: self._stop)

        def done(kind, val):
            if kind == 'err':
                self._say(str(val), err=True)
                return
            self._found = val
            for p in val:
                self._found_lb.insert('end', p['name'] or p['device_id'])
            if val:
                self._found_lb.selection_set(0)
                self._say(_t('MOB_FOUND', '찾은 폰 — 연결할 폰을 선택하세요'))
            else:
                self._say(_t('MOB_NOT_FOUND2', '폰을 못 찾았습니다 — 폰에서 「설정 ▸ PC 연결」 화면을 열었는지, 같은 '
                             '와이파이인지 보세요. 그래도 안 되면 폰 화면의 주소를 「모바일 기기 주소」 칸에 넣으세요.'),
                          err=True)
        self._run(fn, done)

    def _pick_phone(self):
        sel = self._found_lb.curselection()
        if not sel or sel[0] >= len(self._found):
            return
        self._pair(self._found[sel[0]])

    def _pick_manual(self):
        s = self._man_var.get().strip()
        if not s:
            return
        host, _c, port = s.partition(':')
        try:
            port = int(port) if port else MS.PORT_DEFAULT
        except ValueError:
            port = MS.PORT_DEFAULT
        self._pair({'host': host.strip(), 'port': port, 'name': host.strip(), 'device_id': ''})

    def _pair(self, phone):
        q = self._q
        self._code_say.configure(text='')
        self._code_lbl.configure(text='')

        def fn():
            return MS.pair_with(self.db_path, phone, log=lambda s: q.put(('log', s)),
                                should_stop=lambda: self._stop, on_code=lambda c: q.put(('code', c)))

        def done(kind, val):
            if kind == 'err':
                self._say(str(val), err=True)
                return
            self._cur = val['device_id']
            self._open_cf(False)
            self.reload()
            self._show_step('SYNC')
            self._say((_t('MOB_PAIRED', '연결했습니다') + ': %s — ' + _t('MOB_NEXT_SYNC', '이제 ② 동기화를 하세요.'))
                      % (val['name'] or val['device_id']))
        self._run(fn, done)

    def _sync(self):
        if not self._cur:
            return
        did, keys, tg = self._cur, self._keys_var.get(), self.targets
        q = self._q

        def fn():
            return MS.sync_once(self.db_path, did, with_ai_keys=keys, log=lambda s: q.put(('log', s)), targets=tg)

        def done(kind, val):
            if kind == 'err':
                self._say(str(val), err=True)
                return
            self.reload()
            self._st_var.set('NEW')
            if val.get('drafts'):
                self._show_step('RECV')
            self._say(MS.summary(val))
        self._run(fn, done)

    def _unpair(self):
        if not self._cur:
            return
        with appdb.connect(self.db_path) as conn:
            MS.unpair(conn, self._cur)
        self._cur = None
        self.reload()
        self._say(_t('MOB_DISCONNECTED', '연결을 해제했습니다 — 다시 쓰려면 ① 에서 다시 연결하세요.'))

    # ══════════════════════════════════════════════════════════════════
    #  ⑤ 받은 글
    # ══════════════════════════════════════════════════════════════════
    def _fill(self):
        st = self._st_var.get()
        try:
            with appdb.connect(self.db_path) as conn:
                MS.ensure(conn)
                rows = MS.inbox(conn, st)
                counts = {c: len(MS.inbox(conn, c)) for c, _k, _d in STATES}
        except Exception:
            rows, counts = [], {}
        for c, (b, key, dflt) in self._st_btn.items():
            n = counts.get(c, 0)
            b.configure(text=('%s (%d)' % (_t(key, dflt), n)) if n else _t(key, dflt))
        self._step_marks(counts.get('NEW', 0))
        self._rows = {str(r['inbox_id']): r for r in rows}
        self._tv.delete(*self._tv.get_children())
        for r in rows:
            self._tv.insert('', 'end', iid=str(r['inbox_id']),
                            values=(kind_label(r['kind']), self._what(r), (r['made_at'] or '')[:16]))
        if not rows:
            self._tv.insert('', 'end', iid='EMPTY', values=('', _t('MOB_EMPTY2', '받을 글이 없습니다'), ''))
        self._show_empty()

    def _what(self, r):
        d = r['data']
        anc = self._anchor(r)
        text = (d.get('title') or d.get('body') or d.get('contents') or
                ((d.get('msgs') or [{}])[0].get('body') or ''))
        text = ' '.join((text or '').split())[:60]
        if r['kind'] == 'AI':
            text = ai_tag(d) + text
        return ('%s · %s' % (anc, text)) if anc else text

    def _anchor(self, r):
        d = r['data']
        lang = (self.lang_getter() or 'KO')
        try:
            import medi_note
            if r['kind'] == 'DESC':
                key, dflt = DESC_NAME.get(d.get('text_type'), ('', d.get('text_type')))
                nm = _t(key, dflt) if key else dflt
                if (d.get('text_type') or '').startswith('VERS_'):
                    nm += ' · ' + medi_note.verse_label(self.db_path, int(d['clicked_id']), None, lang)
                return nm
            if d.get('start_vid'):
                return medi_note.verse_label(self.db_path, int(d['start_vid']), d.get('end_vid'), lang)
        except Exception:
            pass
        return ''

    def _show_empty(self):
        self._sel = None
        for w in (self._title_lbl, self._title_ent, self._pc_lbl, self._pc_txt,
                  self._mine_lbl, self._mine_txt, self._asref):
            w.pack_forget()
        self._head.configure(text=_t('MOB_PICK2', '왼쪽에서 글을 선택하세요.'))
        for b in (self._b_adopt, self._b_save, self._b_disc):
            b.configure(state='disabled')
        self._drop_var.set(False)

    def _set_text(self, w, s, ro=False):
        w.configure(state='normal')
        w.delete('1.0', 'end')
        w.insert('1.0', s or '')
        if ro:
            w.configure(state='disabled')

    def _on_pick(self):
        sel = self._tv.selection()
        r = self._rows.get(sel[0]) if sel else None
        self._show_empty()
        if not r:
            return
        self._sel = r
        d, k = r['data'], r['kind']
        self._head.configure(text='%s  ·  %s' % (kind_label(k), self._anchor(r)))
        new = r['state'] == 'NEW'
        if k in ('NOTE', 'REF', 'AI'):
            self._title_lbl.pack(side='left')
            self._title_ent.pack(side='left', fill='x', expand=True, padx=(6, 0))
            self._title_var.set(d.get('title') or '')
            self._title_ent.configure(state='normal' if new else 'disabled')
        # ★ 2026-10-25 (3단계) 폰이 PC 의 내 연구/설교노트를 고친 것도 지금 PC 글과 견준다
        if k in ('DESC', 'NOTE_ADD', 'NOTE_EDIT', 'NOTE_DEL') or (k == 'REF' and d.get('ref_id')):
            try:
                with appdb.connect(self.db_path) as conn:
                    cur = MS.current_for(conn, r)
            except Exception:
                cur = ''
            self._pc_lbl.pack(fill='x', pady=(6, 0))
            self._pc_txt.pack(fill='x')
            self._set_text(self._pc_txt, cur or _t('MOB_NONE_PC', '(PC 에 아직 글이 없습니다)'), ro=True)
        self._mine_lbl.pack(fill='x', pady=(6, 0))
        self._mine_txt.pack(fill='both', expand=True)
        if k == 'AI':
            self._set_text(self._mine_txt, ai_preview(d), ro=True)   # 대화는 PC 대화목록에서 이어 쓴다
            if new:
                self._asref.pack(side='left', padx=(12, 0))
        else:
            self._set_text(self._mine_txt, d.get('body') or d.get('contents') or '', ro=not new)
        if new:
            self._b_adopt.configure(state='normal')
            self._b_disc.configure(state='normal')
            if k != 'AI':
                self._b_save.configure(state='normal')
        elif r.get('adopted_ref'):
            self._head.configure(text=self._head.cget('text') + '  —  ' + ref_label(r['adopted_ref']))

    def _edited_data(self):
        r = self._sel
        d = dict(r['data'])
        if r['kind'] in ('NOTE', 'REF', 'AI'):
            d['title'] = self._title_var.get().strip()
        if r['kind'] != 'AI':
            body = self._mine_txt.get('1.0', 'end-1c')
            if r['kind'] == 'DESC':
                d['contents'] = body
            else:
                d['body'] = body
        return d

    def _keep(self):
        if not self._sel:
            return
        with appdb.connect(self.db_path) as conn:
            MS.update_draft(conn, self._sel['inbox_id'], self._edited_data())
        self._say(_t('MOB_KEPT2', '다듬은 글을 적어 두었습니다(아직 PC 에 받기 전).'))
        keep = str(self._sel['inbox_id'])
        self._fill()
        if self._tv.exists(keep):
            self._tv.selection_set(keep)

    def _adopt(self):
        if not self._sel:
            return
        r = self._sel
        try:
            with appdb.connect(self.db_path) as conn:
                MS.update_draft(conn, r['inbox_id'], self._edited_data())
            ref = MS.adopt(self.db_path, r['inbox_id'])
            if r['kind'] == 'AI' and self._asref_var.get():
                import user_ai
                with appdb.connect(self.db_path) as conn:
                    # ★ 최종 정리본이 있으면 그 글을 담는다 — 대화 전체를 이어 붙이지 않는다
                    fin = (r['data'].get('final') or '').strip() or None
                    rid = user_ai.save_as_ref(conn, int(ref.split(':')[1]), text=fin)
                ref += ' · REF:%s' % rid
        except Exception as e:                            # noqa: BLE001
            self._say(str(e), err=True)
            return
        self._say(ref_label(ref) + _t('MOB_CK_GO', ' — 「⑥ 받은 글 점검」에서 마지막으로 확인하세요.'))
        self._fill()

    def _adopt_all(self):
        with appdb.connect(self.db_path) as conn:
            n0 = len(MS.inbox(conn, 'NEW'))
        if not n0:
            self._say(_t('MOB_ALL_NONE', '다운로드 대기 글이 없습니다.'))
            return
        n, bad = MS.adopt_all(self.db_path)
        msg = _t('MOB_ALL_DONE', '%d개를 PC 에 들였습니다 — 「⑥ 받은 글 점검」에서 하나씩 확인할 수 있습니다.') % n
        if bad:
            msg += ' ' + _t('MOB_ALL_BAD', '못 들인 것 %d개는 대기에 남았습니다.') % len(bad)
        self._say(msg, err=bool(bad))
        self._fill()

    def _discard(self):
        if not self._sel:
            return
        drop = bool(self._drop_var.get())
        with appdb.connect(self.db_path) as conn:
            MS.discard(conn, self._sel['inbox_id'], phone_drop=drop)
        self._say(_t('MOB_SKIPPED_DROP', '다운로드 안함 — 다음 동기화 때 폰에서도 지웁니다.') if drop else
                  _t('MOB_SKIPPED', '다운로드 안함 — 폰의 글은 그대로 둡니다. 「다운로드 안함」에서 다시 볼 수 있습니다.'))
        self._fill()
