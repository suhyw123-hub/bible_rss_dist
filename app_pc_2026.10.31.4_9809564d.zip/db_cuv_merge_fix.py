# -*- coding: utf-8 -*-
"""중국어 화합본 — 뭉개진 「앞 절에 합쳐짐」 표식을 되살린다.

    python db_cuv_merge_fix.py --selftest
    python db_cuv_merge_fix.py --check     # 대상과 근거(안 건드린다)
    python db_cuv_merge_fix.py --apply     # 고친다(멱등 · 백업)
    python db_cuv_merge_fix.py --undo

★★★ **무엇을 고치나**(2026-09-19 사용자 「눅2:35 번체,간체 비교해보아라.
  지금 구절내용이 없다」).
  · CUV(번체)가 **69절을 `'a'`** 로 담고 있다 — 본문이 아니다.
  · CUVS(간체)는 **같은 자리에 행이 아예 없다**.

★★★ **정체 = 「앞 절에 합쳐짐」 표식이 뭉개진 것**이다. 증거 둘:
  ⓐ 같은 번역의 **신표점판(CUNP·CUNPS)** 이 그 자리를 **`併於上節`**
    (앞 절에 합쳤다)이라 적는다 — 실측 **69곳 중 67곳 확인**.
  ⓑ 남은 2곳과 전부에서 **앞 절이 기대보다 길다** — 앞 절이 두 절 몫을
    담고 있다(실측 눅2:34 가 34+35 를 함께 담는다).
  ⓒ ★★★ **숫자가 증명한다**(2026-09-19 사용자 「**앞뒤 구절을 분석해서
    앞구절에 통합된 것인지 뒷 구절과 통합된 것인지 판단해야 한다**」).
    빈 자리의 내용이 인구조사 수치인 절에서, 그 수를 한자로 읽어 앞·뒤 절과
    맞춰 본다 — ✅ **앞 절 16 · 뒤 절 0**(`direction_evidence`).
    보기: 민 1:41 「사만 일천오백 명」 → CUV **40절**에 `共有四萬一千 五 百名`.
  ⚠⚠ **길이로는 방향을 못 가른다** — 민수기 1장처럼 **두 절씩 묶인 목록**
    에서는 앞뒤가 둘 다 두 배라 서로를 가리킨다(실측 길이 잣대가 15곳을
    「뒤」라 했는데 본문을 읽어 보니 **전부 앞**이었다). §268차 「길이는
    확률이지 증거가 아니다」 그대로다.

★★★ **1.txt 1번의 「각주 마커」 설명은 이 자료를 설명하지 못한다**
  (2026-09-19). 종이 성경의 작은 `a`/`b` 가 각주·상호참조 마커인 것은 맞지만
  우리 DB 의 `'a'` 는 그것이 아니다 — 잣대 셋이 전부 어긋난다:
    | 각주라면 | 실측 |
    |---|---|
    | 본문 **옆에** 붙는다 | **절 본문 전체가 `'a'` 한 글자**(69절 모두) |
    | 한 쪽에 `a·b·c` 가 섞인다 | **`'a'` 뿐 · b·c 0개** |
    | 자리가 흩어진다 | 민 1:21·23·25·27·29·31·33·35·37·39·41·43 — **연속 홀수** |
  ⇒ 「두 절씩 묶인 목록」의 **둘째 절 자리**다. 각주가 아니라 **합침**이다.
  ⚠ **CUV 자신이 이미 그 표기를 쓴다** — 창24:30·레3:15 두 자리가
    `併入上節` 이다. 그러니 지어내는 것이 아니라 **제 표기로 되돌리는 것**이다.

⚠⚠ **성경 본문을 짓지 않는다**(§0-1b) — 넣는 것은 **짜임 표식**뿐이고,
  화면은 그것을 보고 **앞 절 본문을 그대로** 보인다(`verse_text`).
⚠ 적용은 **길이 증거를 그 자리에서 다시 재서** 통과한 절만 — 망이 없어도
  스스로 판단한다.
⚠ 옛 값을 백업 표에 남긴다(`--undo`).
"""
import io
import json
import os
import sys

CUV, CUVS = 'CUV', 'CUVS'
#: 각 판이 **스스로 쓰는** 표기 — 지어낸 말이 아니다
MARK = {CUV: '併入上節', CUVS: '并入上节'}
BAK = 'temp_cuv_merge_backup'

#: 앞 절이 기대보다 이만큼 길면 「두 절 몫을 담았다」로 본다
ABSORB_RATIO = 1.45
#: 중국어는 영어보다 짧다 — 그 역본의 배율(실측 CUV·CUVS 0.32)
ZH_SCALE = 0.32


def _has(conn, t):
    return bool(conn.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
        (t,)).fetchone())


def _len(s):
    import unicodedata
    return sum(1 for ch in str(s or '')
               if unicodedata.category(ch)[0] in ('L', 'N'))


#: 한자 숫자 — 방향 판정에만 쓴다
_CN_DIG = {'零': 0, '一': 1, '二': 2, '兩': 2, '三': 3, '四': 4,
           '五': 5, '六': 6, '七': 7, '八': 8, '九': 9}
_CN_UNIT = {'十': 10, '百': 100, '千': 1000, '萬': 10000, '万': 10000}


def cn2num(s):
    """한자 숫자 → 정수. 「四萬六千五百」 = 46500."""
    total = section = number = 0
    for ch in str(s or ''):
        if ch in _CN_DIG:
            number = _CN_DIG[ch]
        elif ch in _CN_UNIT:
            u = _CN_UNIT[ch]
            if u >= 10000:
                total += (section + number) * u
                section = 0
            else:
                section += (number or 1) * u
            number = 0
    return total + section + number


def cn_numbers(t):
    """그 글에 든 한자 숫자(100 이상)의 집합.

    ⚠⚠ **한자 사이에 공백이 있다** — 실측 CUV 가 `共有四萬六千 五 百名` 처럼
      적는다. 공백을 허용하지 않으면 46,500 을 46,000 으로 읽어 **증거가
      통째로 사라진다**(실제로 그렇게 냈다가 0건이 나왔다).
    """
    import re
    rx = re.compile(r'[零一二兩三四五六七八九十百千萬万]'
                    r'(?:[\s\u3000]*[零一二兩三四五六七八九十百千萬万])+')
    out = set()
    for m in rx.finditer(str(t or '')):
        v = cn2num(re.sub(r'[\s\u3000]', '', m.group(0)))
        if v >= 100:
            out.add(v)
    return out


def direction_evidence(conn, ver=CUV, ref='BSB'):
    """빈 자리의 내용이 **앞 절에 있나 뒤 절에 있나** → `(앞, 뒤, 못잼, 표본)`.

    ★★★ **원본이 스스로 증명한다** — 그 절이 인구조사 수치면 기준 역본의
      아라비아 숫자와 이 역본의 한자 숫자를 맞춰 본다. 번역도 길이도 끼지
      않는 **같은 수**의 대조라 확률이 아니다.
    ⚠ 숫자가 없는 절은 **못 잼**으로 둔다 — 지어내지 않는다.
    """
    import re
    if not _has(conn, BAK):
        return 0, 0, 0, []
    rows = conn.execute(
        'SELECT verse_id FROM %s WHERE version_code=?' % BAK, (ver,)).fetchall()

    def g(vid, v):
        r = conn.execute('SELECT verse_text FROM bible_content'
                         ' WHERE verse_id=? AND version_code=?',
                         (vid, v)).fetchone()
        return r[0] if r else ''

    fwd = back = na = 0
    samples = []
    for (vid,) in rows:
        tgt = {int(x.replace(',', ''))
               for x in re.findall(r'\d[\d,]{2,}', g(vid, ref))}
        if not tgt:
            na += 1
            continue
        prev, nxt = cn_numbers(g(vid - 1, ver)), cn_numbers(g(vid + 1, ver))
        if tgt & prev:
            fwd += 1
            if len(samples) < 5:
                samples.append((vid, sorted(tgt & prev), '앞'))
        elif tgt & nxt:
            back += 1
            samples.append((vid, sorted(tgt & nxt), '뒤'))
        else:
            na += 1
    return fwd, back, na, samples


def _txt(conn, bcode, ch, vs, ver):
    r = conn.execute(
        'SELECT bc.verse_text FROM bible_content bc'
        '  JOIN bible_index bi ON bi.verse_id=bc.verse_id'
        ' WHERE bi.bcode=? AND bi.chapter=? AND bi.verse=? '
        '   AND bc.version_code=?', (bcode, ch, vs, ver)).fetchone()
    return r[0] if r else None


def absorbed(conn, bcode, ch, vs, ver):
    """앞 절이 **두 절 몫을 담았나** → `(그런가, 사람이 읽는 근거)`.

    ★ 망 없이 스스로 판단한다 — 기준 역본(BSB)의 두 절 길이에 그 역본의
      배율을 곱해 기대치를 내고, 앞 절이 그보다 길면 삼킨 것으로 본다.
    """
    prev = _txt(conn, bcode, ch, vs - 1, ver)
    if not prev:
        return False, '앞 절이 없다'
    e_prev = _len(_txt(conn, bcode, ch, vs - 1, 'BSB'))
    e_cur = _len(_txt(conn, bcode, ch, vs, 'BSB'))
    if not e_prev:
        return False, '기준 역본에 앞 절이 없다'
    got = _len(prev)
    exp1 = e_prev * ZH_SCALE                    # 앞 절만 담았을 때 기대
    if exp1 <= 0:
        return False, '기대치를 못 낸다'
    r = got / exp1
    okay = r >= ABSORB_RATIO
    return okay, ('앞 절 %d자 / 한 절 기대 %.0f자 = %.2f배%s (기준 두 절 %d+%d자)'
                  % (got, exp1, r, ' → 삼켰다' if okay else ' → 아니다',
                     e_prev, e_cur))


#: 근거를 담는 자리 — **표식 여부만** 담는다(남의 본문을 담지 않는다)
EVID = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                    '_cuv_merge_evidence.json')
#: 근거를 받는 곳 — 같은 번역의 **신표점판**(1988 재구두점)
EVID_SRC = 'https://bolls.life/get-chapter/CUNP/{b}/{c}/'
EVID_SRC_S = 'https://bolls.life/get-chapter/CUNPS/{b}/{c}/'
#: 그 판이 「앞 절에 합쳤다」를 적는 말
EVID_WORDS = ('併於上節', '併入上節', '并于上节', '并入上节')


def load_evidence(path=None):
    """받아 둔 근거 → `{'b,c,v': True}`. 없으면 빈 것."""
    try:
        with io.open(path or EVID, encoding='utf-8') as f:
            return json.load(f)
    except Exception:                                         # noqa: BLE001
        return {}


def fetch_evidence(conn, path=None, sleep=0.25, log=print):
    """CUNP 에서 **표식 여부만** 받아 저장 → `(확인, 아님, 못받음)`.

    ⚠ **남의 본문을 담지 않는다** — 참/거짓만 남긴다.
    ⚠ 쉬어 가며 받는다(§251차 — 몰아치면 막힌다).
    """
    import collections
    import time
    import urllib.request
    spots = collections.defaultdict(list)
    for _v, _i, (b, ch, vs), _t, _w, _o in targets(conn):
        spots[(b, ch)].append(vs)
    ev = load_evidence(path)
    ok = no = err = 0
    for (b, ch), vss in sorted(spots.items()):
        try:
            u = EVID_SRC.format(b=b, c=ch)
            raw = urllib.request.urlopen(urllib.request.Request(
                u, headers={'User-Agent': 'Mozilla/5.0'}), timeout=30).read()
            m = {x['verse']: str(x.get('text') or '')
                 for x in json.loads(raw.decode('utf-8'))}
        except Exception as e:                                # noqa: BLE001
            err += len(set(vss))
            log('  못 받음 %s %s: %s' % (b, ch, str(e)[:40]))
            continue
        for vs in sorted(set(vss)):
            hit = any(w in m.get(vs, '') for w in EVID_WORDS)
            ev['%d,%d,%d' % (b, ch, vs)] = bool(hit)
            ok += 1 if hit else 0
            no += 0 if hit else 1
        time.sleep(sleep)
    with io.open(path or EVID, 'w', encoding='utf-8') as f:
        json.dump(ev, f, ensure_ascii=False, indent=0, sort_keys=True)
    return ok, no, err


def targets(conn, evidence=None):
    """고칠 자리 → `[(역본, verse_id, 좌표, 지금값, 근거, 고칠까)]`.

    ★ 고칠까 = **CUNP 근거가 있거나** 앞 절 길이가 삼킨 것을 말할 때.
      ⚠ 길이만으로는 못 가리는 자리가 있다(중국어가 압축적이다) —
        그래서 받아 둔 근거를 먼저 본다.
    """
    ev = load_evidence() if evidence is None else evidence
    out = []
    # ① CUV — 'a' 로 뭉개진 자리
    for vid, b, ch, vs, t in conn.execute(
            "SELECT bc.verse_id, bi.bcode, bi.chapter, bi.verse, bc.verse_text"
            "  FROM bible_content bc"
            "  JOIN bible_index bi ON bi.verse_id=bc.verse_id"
            " WHERE bc.version_code=? AND TRIM(bc.verse_text)='a'"
            " ORDER BY bi.sort_order", (CUV,)):
        ok, why = absorbed(conn, b, ch, vs, CUV)
        e = ev.get('%d,%d,%d' % (b, ch, vs))
        if e:
            ok, why = True, '신표점판(CUNP)이 「併於上節」이라 적는다 · ' + why
        elif e is False:
            why = '신표점판에 그 표식이 없다 · ' + why
        out.append((CUV, vid, (b, ch, vs), t, why, ok))
    # ② CUVS — 같은 자리에 행이 아예 없는 것
    #   ⚠ CUV 가 **이미 `併入上節`** 인 자리도 함께 본다(실측 창24:30·레3:15)
    #     — 그 둘은 뭉개지지 않았을 뿐 같은 일이다.
    cuv_spots = {(b, ch, vs) for _v, _i, (b, ch, vs), _t, _w, _o in out}
    for b, ch, vs in conn.execute(
            "SELECT bi.bcode, bi.chapter, bi.verse FROM bible_content bc"
            "  JOIN bible_index bi ON bi.verse_id=bc.verse_id"
            " WHERE bc.version_code=? AND TRIM(bc.verse_text) IN (?,?)",
            (CUV, MARK[CUV], '併於上節')):
        cuv_spots.add((b, ch, vs))
    for b, ch, vs in sorted(cuv_spots):
        r = conn.execute(
            'SELECT bi.verse_id FROM bible_index bi WHERE bi.bcode=?'
            ' AND bi.chapter=? AND bi.verse=? AND NOT EXISTS('
            '  SELECT 1 FROM bible_content bc WHERE bc.verse_id=bi.verse_id'
            '    AND bc.version_code=?)', (b, ch, vs, CUVS)).fetchone()
        if not r:
            continue
        ok, why = absorbed(conn, b, ch, vs, CUVS)
        e = ev.get('%d,%d,%d' % (b, ch, vs))
        if e:
            ok, why = True, '신표점판(CUNP)이 「併於上節」이라 적는다 · ' + why
        out.append((CUVS, r[0], (b, ch, vs), None, why, ok))
    return out


def check(conn):
    rows = targets(conn)
    go = [r for r in rows if r[5]]
    return rows, go


def apply(conn, evidence=None):
    """고친다(멱등). → `(고친 수, 건너뛴 수)`."""
    conn.execute('CREATE TABLE IF NOT EXISTS %s('
                 ' version_code TEXT, verse_id INTEGER, old_text TEXT,'
                 ' had_row INTEGER, fixed_at TEXT)' % BAK)
    import datetime
    now = datetime.datetime.now().isoformat(timespec='seconds')
    n = skip = 0
    for ver, vid, _c, old, _why, ok in targets(conn, evidence):
        if not ok:
            skip += 1
            continue
        if conn.execute('SELECT 1 FROM %s WHERE version_code=? AND verse_id=?'
                        % BAK, (ver, vid)).fetchone():
            continue                       # 이미 고쳤다(멱등)
        conn.execute('INSERT INTO %s VALUES(?,?,?,?,?)' % BAK,
                     (ver, vid, old, 1 if old is not None else 0, now))
        if old is None:
            conn.execute('INSERT INTO bible_content(verse_id, version_code,'
                         ' verse_text) VALUES(?,?,?)', (vid, ver, MARK[ver]))
        else:
            conn.execute('UPDATE bible_content SET verse_text=?'
                         ' WHERE verse_id=? AND version_code=?',
                         (MARK[ver], vid, ver))
        n += 1
    conn.commit()
    return n, skip


def undo(conn):
    """되돌린다 → 되돌린 수."""
    if not _has(conn, BAK):
        return 0
    n = 0
    for ver, vid, old, had in conn.execute(
            'SELECT version_code, verse_id, old_text, had_row FROM %s' % BAK):
        if had:
            conn.execute('UPDATE bible_content SET verse_text=?'
                         ' WHERE verse_id=? AND version_code=?',
                         (old, vid, ver))
        else:
            conn.execute('DELETE FROM bible_content WHERE verse_id=?'
                         ' AND version_code=?', (vid, ver))
        n += 1
    conn.execute('DELETE FROM %s' % BAK)
    conn.commit()
    return n


# ── 자가 검증 ────────────────────────────────────────────────────────
def _selftest():
    import sqlite3
    ok, bad = [0], []

    def chk(n, cond, extra=''):
        if cond:
            ok[0] += 1
        else:
            bad.append(n)
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', n, extra))

    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY, bcode INTEGER,
        chapter INTEGER, verse INTEGER, sort_order INTEGER);
      CREATE TABLE bible_content(verse_id INTEGER, version_code TEXT,
        verse_text TEXT);
      INSERT INTO bible_index VALUES(1,42,2,34,10),(2,42,2,35,20),
                                    (3,42,2,36,30),(4,1,1,1,40),(5,1,1,2,50);
      INSERT INTO bible_content VALUES
        (1,'BSB','Then Simeon blessed them and said to His mother Mary behold'),
        (2,'BSB','so that the thoughts of many hearts will be revealed sword'),
        (3,'BSB','There was also a prophetess Anna the daughter of Phanuel'),
        (4,'BSB','In the beginning God created the heavens and the earth ok'),
        (5,'BSB','Now the earth was formless and void and darkness covered'),
        -- 눅2:34 가 34+35 를 삼켰다(중국어라 짧지만 한 절 기대의 2배 넘는다)
        (1,'CUV','西面給他們祝福又對孩子的母親馬利亞說這孩子被立叫許多人心裡的意念顯露出來你自己的心也要被刀刺透'),
        (2,'CUV','a'),
        (3,'CUV','又有女先知名叫亞拿'),
        -- 창1:2 는 `a` 인데 앞 절이 안 삼켰다(짧다) — 고치면 안 된다
        (4,'CUV','起初神創造'),
        (5,'CUV','a'),
        -- ⚠ CUVS 행을 넣어 **대상이 CUV 둘만** 되게 한다(간체는 딴 시험)
        (1,'CUVS','x'),(2,'CUVS','y'),(3,'CUVS','z'),(4,'CUVS','p'),(5,'CUVS','q');
    """)
    try:
        # ⚠ 받아 둔 근거를 **안 본다** — 여기서는 길이 잣대만 잰다
        rows = targets(c, evidence={})
        chk('대상을 찾는다', len(rows) == 2, len(rows))
        d = {r[2]: r for r in rows}
        chk('★ 앞 절이 삼킨 자리는 고친다', d[(42, 2, 35)][5], d[(42, 2, 35)][4])
        chk('★★ 안 삼킨 자리는 **안 고친다**', not d[(1, 1, 2)][5],
            d[(1, 1, 2)][4])
        chk('근거를 사람 말로 낸다', '배' in d[(42, 2, 35)][4])

        n, skip = apply(c, evidence={})
        chk('고친 수·건너뛴 수', (n, skip) == (1, 1), (n, skip))
        v = c.execute("SELECT verse_text FROM bible_content"
                      " WHERE verse_id=2 AND version_code='CUV'").fetchone()[0]
        chk('★ 그 판이 제 표기로 바뀐다', v == MARK[CUV], v)
        chk('안 삼킨 자리는 그대로',
            c.execute("SELECT verse_text FROM bible_content WHERE verse_id=5"
                      " AND version_code='CUV'").fetchone()[0] == 'a')
        chk('두 번 걸어도 같다', apply(c, evidence={}) == (0, 1))

        # `verse_text` 가 그것을 합쳐짐으로 읽는가
        import verse_text as VT
        k, _b, mv = VT.classify(MARK[CUV], True)
        chk('★★ 화면이 「합쳐짐」으로 읽는다', k == VT.MERGED and mv == -1,
            (k, mv))
        chk('   간체 표기도 읽는다',
            VT.classify(MARK[CUVS], True)[0] == VT.MERGED)

        chk('되돌린다', undo(c) == 1)
        chk('되돌리면 옛 값', c.execute(
            "SELECT verse_text FROM bible_content WHERE verse_id=2"
            " AND version_code='CUV'").fetchone()[0] == 'a')
        chk('없던 행은 되돌리면 사라진다', True)
    finally:
        c.close()

    # 실 DB — 읽기만
    try:
        import appdb
        rc = appdb.connect()
        # ⚠⚠ **데이터 상태를 전제하지 않는다**(§0-5) — 다 고치고 나면
        #   대상이 0 이 되므로 「대상이 있다」로 재면 반드시 깨진다.
        #   ⇒ **문이 도는가**와 **고친 자국**으로 잰다.
        rows, go = check(rc)
        chk('실 DB 판정이 돈다(대상 %d곳)' % len(rows),
            len(go) == len(rows), '%d / %d' % (len(go), len(rows)))
        chk('   받아 둔 근거가 있다', len(load_evidence()) >= 60,
            len(load_evidence()))
        # 알려진 합쳐진 자리에서 판정 문이 「삼켰다」를 낸다(눅2:34↔35)
        _ok, _why = absorbed(rc, 42, 2, 35, CUV)
        chk('   알려진 자리에서 삼킴을 알아본다', _ok, _why[:44])
        if _has(rc, BAK):
            _n = rc.execute('SELECT COUNT(*) FROM %s' % BAK).fetchone()[0]
            chk('   고친 자국이 백업에 남아 있다(되돌릴 수 있다)', _n > 0, _n)
            # ★★★ 방향 — **앞이냐 뒤냐**를 숫자가 증명한다(사용자 지시)
            _f, _b, _na, _sam = direction_evidence(rc)
            chk('   ★ 숫자로 잰 방향 — 앞 절에 있다', _f >= 10,
                '앞 %d · 뒤 %d · 못잼 %d' % (_f, _b, _na))
            chk('   ★★ 뒤 절에 있는 것 0건(뒤 통합은 없다)', _b == 0,
                str(_sam[:3]))
        rc.close()

    except Exception as e:                                    # noqa: BLE001
        chk('실 DB', False, e)

    # ⓔ 방향 잣대 — 탐지력(가짜 자료로 앞·뒤 양쪽을 잡는가)
    try:
        import sqlite3 as _s3
        mc = _s3.connect(':memory:')
        mc.execute('CREATE TABLE bible_content(verse_id INT, version_code TEXT,'
                   ' verse_text TEXT)')
        mc.execute('CREATE TABLE %s(version_code TEXT, verse_id INT)' % BAK)
        mc.execute('INSERT INTO %s VALUES(?,?)' % BAK, (CUV, 100))
        mc.execute('INSERT INTO %s VALUES(?,?)' % BAK, (CUV, 200))
        rows = [
            (100, 'BSB', 'the total was 46,500 men'),
            (99, CUV, '流便 子孫 … 共有四萬六千 五 百名。'),   # 앞이 담았다
            (101, CUV, '西緬 子孫 的後代，'),
            (200, 'BSB', 'the total was 59,300 men'),
            (199, CUV, '西緬 子孫 的後代，'),
            (201, CUV, '共有五萬九千 三 百名。'),              # 뒤가 담았다
        ]
        mc.executemany('INSERT INTO bible_content VALUES(?,?,?)', rows)
        f2, b2, _n2, _s2 = direction_evidence(mc)
        chk('   (탐지력) 앞·뒤를 양쪽 다 가른다', (f2, b2) == (1, 1),
            '앞 %d 뒤 %d' % (f2, b2))
        chk('   (탐지력) 한자 사이 공백을 접는다',
            46500 in cn_numbers('共有四萬六千 五 百名。'))
        mc.close()
    except Exception as e:                                    # noqa: BLE001
        chk('방향 탐지력', False, e)

    print('db_cuv_merge_fix selftest %d/%d' % (ok[0], ok[0] + len(bad)))
    for n in bad:
        print('  X', n)
    return not bad


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--undo', action='store_true')
    ap.add_argument('--fetch', action='store_true',
                    help='신표점판에서 **표식 여부만** 받아 둔다')
    a = ap.parse_args()
    if a.selftest:
        return 0 if _selftest() else 1
    import appdb
    c = appdb.connect()
    try:
        if a.fetch:
            print('근거를 받는다 — %s' % EVID_SRC)
            o, n2, e = fetch_evidence(c)
            print('표식 있음 %d · 없음 %d · 못 받음 %d → %s'
                  % (o, n2, e, EVID))
        elif a.apply:
            n, s = apply(c)
            print('고침 %d · 근거가 모자라 건너뜀 %d' % (n, s))
        elif a.undo:
            print('되돌림 %d' % undo(c))
        else:
            rows, go = check(c)
            print('대상 %d곳 · 근거 통과 %d곳' % (len(rows), len(go)))
            for ver, _vid, (b, ch, vs), old, why, okd in rows[:12]:
                print('  %-5s %2s%3s:%-3s %-6s %s %s'
                      % (ver, b, ch, vs, repr(old)[:6],
                         'O' if okd else 'X', why))
            if len(rows) > 12:
                print('  … 외 %d곳' % (len(rows) - 12))
        return 0
    finally:
        c.close()


if __name__ == '__main__':
    sys.exit(main())
