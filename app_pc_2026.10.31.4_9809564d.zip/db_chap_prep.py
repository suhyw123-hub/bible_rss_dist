# -*- coding: utf-8 -*-
"""db_chap_prep.py — 장 설명문(CHAP_DESC) 재료 뽑기 (영구 도구)

chapter.md §5 가 요구하는 **상향식** 재료를 한 파일로 모은다.
  ① 그 장의 페리코프 제목 + PERI_DESC(KO)   <- 주 재료. 이것을 안 읽고 쓰면 재진술이 된다
  ② GILL 장서론(entry_level='CHAPTER')       <- A 블록(구조) 재료
  ③ HENRY_MHC 장 항목                        <- C 블록(배경) 재료. 3만 자라 앞부분만

⚠ 이 파일에 `temp_` 를 붙이지 말 것.
   전신 `temp_code_chap_prep.py` 는 이름이 `temp_` 라 §0-4 정리 때 삭제됐고,
   chapter.md 가 그것을 쓰라고 가리키는 채로 남아 있었다(2026-08-05 발견).
   CLAUDE.md §0-5 에 같은 사고가 `db_vers_gate` 로 기록돼 있다 — 두 번째다.

사용:
  python -X utf8 db_chap_prep.py --book 1 --ch 1-5
  python -X utf8 db_chap_prep.py --book 1 --todo        # 미작성 장 목록
  python -X utf8 db_chap_prep.py --selftest             # 의무
"""
import argparse
import os
import re
import sys

import appdb
import verse_tier

APP = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(APP, '_chap_prep')

# HENRY_MHC 는 장당 평균 3만 자라 통째로 적으면 재료 파일이 못 읽을 크기가 된다.
HENRY_HEAD = 6000


def _book_name(conn, bcode):
    row = conn.execute(
        "SELECT full_name FROM book_names WHERE book_code=? AND lang_code='KO'",
        (bcode,)).fetchone()
    return row[0] if row else str(bcode)


def _abbr(conn, bcode):
    """sys_commentary_entry.bcode 는 세 글자 약자다 (CLAUDE.md §8-4)."""
    row = conn.execute(
        "SELECT book_code FROM book_names WHERE book_code=? LIMIT 1", (bcode,)).fetchone()
    # book_names 의 book_code 는 숫자다. 주석 쪽 약자는 bible_index 로 못 얻으므로 표를 쓴다.
    return _ABBR.get(int(bcode))


_ABBR = {
    1: 'GEN', 2: 'EXO', 3: 'LEV', 4: 'NUM', 5: 'DEU', 6: 'JOS', 7: 'JDG', 8: 'RUT',
    9: 'SA1', 10: 'SA2', 11: 'KI1', 12: 'KI2', 13: 'CH1', 14: 'CH2', 15: 'EZR',
    16: 'NEH', 17: 'EST', 18: 'JOB', 19: 'PSA', 20: 'PRO', 21: 'ECC', 22: 'SOS',
    23: 'ISA', 24: 'JER', 25: 'LAM', 26: 'EZE', 27: 'DAN', 28: 'HOS', 29: 'JOL',
    30: 'AMO', 31: 'OBA', 32: 'JON', 33: 'MIC', 34: 'NAH', 35: 'HAB', 36: 'ZEP',
    37: 'HAG', 38: 'ZEC', 39: 'MAL', 40: 'MAT', 41: 'MAR', 42: 'LUK', 43: 'JOH',
    44: 'ACT', 45: 'ROM', 46: 'CO1', 47: 'CO2', 48: 'GAL', 49: 'EPH', 50: 'PHI',
    51: 'COL', 52: 'TH1', 53: 'TH2', 54: 'TI1', 55: 'TI2', 56: 'TIT', 57: 'PHM',
    58: 'HEB', 59: 'JAM', 60: 'PE1', 61: 'PE2', 62: 'JO1', 63: 'JO2', 64: 'JO3',
    65: 'JDE', 66: 'REV',
}


def chapter_range(conn, bcode, chapter):
    """그 장의 verse_id 범위."""
    row = conn.execute(
        "SELECT MIN(verse_id), MAX(verse_id) FROM bible_index WHERE bcode=? AND chapter=?",
        (bcode, chapter)).fetchone()
    return row if row and row[0] is not None else (None, None)


def pericopes_of(conn, bcode, chapter):
    """그 장에 걸치는 BODY 페리코프 + 제목 + PERI_DESC(KO).

    ⚠ 페리코프는 장 경계를 넘을 수 있다. 겹치는 것을 다 가져온다."""
    lo, hi = chapter_range(conn, bcode, chapter)
    if lo is None:
        return []
    rows = conn.execute("""
        SELECT p.pericope_id, p.start_vid, p.end_vid
        FROM sys_pericope_asset p
        WHERE COALESCE(p.record_status,'LIVE')='LIVE'
          AND p.peri_type='BODY'
          AND p.start_vid <= ? AND p.end_vid >= ?
        ORDER BY p.start_vid
    """, (hi, lo)).fetchall()

    out = []
    for pid, s, e in rows:
        title = conn.execute("""
            SELECT title FROM sys_text_asset
            WHERE text_type='PERI_TITLE' AND clicked_id=? AND lang_code='KO'
              AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1""", (pid,)).fetchone()
        desc = conn.execute("""
            SELECT contents FROM sys_text_asset
            WHERE text_type='PERI_DESC' AND clicked_id=? AND lang_code='KO'
              AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1""", (pid,)).fetchone()
        ref = conn.execute("""
            SELECT (SELECT chapter||':'||verse FROM bible_index WHERE verse_id=?),
                   (SELECT chapter||':'||verse FROM bible_index WHERE verse_id=?)""",
                           (s, e)).fetchone()
        out.append({
            'pid': pid,
            'ref': '%s~%s' % (ref[0], ref[1]),
            'title': title[0] if title else '(제목 없음)',
            'desc': desc[0] if desc else '',
        })
    return out


def commentary_of(conn, bcode, chapter, code, level=None):
    abbr = _ABBR.get(int(bcode))
    if not abbr:
        return []
    sql = """
        SELECT t.body_text FROM sys_commentary_entry e
        JOIN sys_commentary_source s ON s.commentary_id = e.commentary_id
        JOIN sys_commentary_text  t ON t.entry_id = e.entry_id
        WHERE e.bcode=? AND e.chapter=? AND s.commentary_code=?
          AND t.text_variant='ORIGINAL'
          AND COALESCE(e.record_status,'LIVE')='LIVE'
    """
    args = [abbr, chapter, code]
    if level:
        sql += " AND e.entry_level=?"
        args.append(level)
    sql += " ORDER BY e.start_vid"
    return [r[0] for r in conn.execute(sql, args)]


def written_chapters(conn, bcode):
    """CHAP_DESC 가 이미 있는 장 번호 집합."""
    rows = conn.execute("""
        SELECT DISTINCT clicked_id FROM sys_text_asset
        WHERE text_type='CHAP_DESC' AND COALESCE(record_status,'LIVE')='LIVE'
          AND clicked_id BETWEEN ? AND ?""",
                        (bcode * 1000, bcode * 1000 + 999)).fetchall()
    return {r[0] - bcode * 1000 for r in rows}


def max_chapter(conn, bcode):
    row = conn.execute(
        "SELECT MAX(chapter) FROM bible_index WHERE bcode=?", (bcode,)).fetchone()
    return row[0] if row else 0


def build(conn, bcode, chapters):
    os.makedirs(OUT_DIR, exist_ok=True)
    bname = _book_name(conn, bcode)
    written = written_chapters(conn, bcode)
    made = []

    for ch in chapters:
        lines = []
        lines.append('# %s %d장 — 장 설명문 재료' % (bname, ch))
        lines.append('')
        lines.append('상태: %s' % ('**이미 작성됨**' if ch in written else '미작성'))
        lines.append('')

        peris = pericopes_of(conn, bcode, ch)
        lines.append('## ① 페리코프 %d개 (주 재료 — chapter.md §5 상향식)' % len(peris))
        lines.append('')
        for p in peris:
            lines.append('### [%s] %s  (peri %s)' % (p['ref'], p['title'], p['pid']))
            lines.append(p['desc'] if p['desc'] else '(설명문 없음)')
            lines.append('')

        gill = commentary_of(conn, bcode, ch, 'GILL', 'CHAPTER')
        lines.append('## ② GILL 장서론 (A 블록 — 구조)')
        lines.append('')
        lines.append(gill[0] if gill else '(없음)')
        lines.append('')

        henry = commentary_of(conn, bcode, ch, 'HENRY_MHC')
        lines.append('## ③ HENRY_MHC 장 항목 앞 %d자 (C 블록 — 배경)' % HENRY_HEAD)
        lines.append('')
        lines.append(henry[0][:HENRY_HEAD] if henry else '(없음)')
        lines.append('')

        path = os.path.join(OUT_DIR, 'chap_%d_%d.md' % (bcode, ch))
        with open(path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines))
        made.append((ch, len(peris), bool(gill), bool(henry), path))

    print('%s(%d) — 재료 %d장' % (bname, bcode, len(made)))
    for ch, np, g, h, path in made:
        print('  %2d장  페리코프 %2d개 · GILL서론 %s · HENRY %s'
              % (ch, np, 'O' if g else 'X', 'O' if h else 'X'))
    print()
    print('초안 뼈대: %s' % _skeleton(bcode, chapters))
    print()
    print('다음: 초안을 채운 뒤')
    print('  python -X utf8 db_chap_load.py --check <draft.json>')


def _skeleton(bcode, chapters):
    import json
    path = os.path.join(OUT_DIR, 'draft_%d_%d-%d.json'
                        % (bcode, chapters[0], chapters[-1]))
    if not os.path.exists(path):
        skel = {'book': bcode,
                'chaps': {str(c): {'KO': '', 'EN': ''} for c in chapters}}
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(skel, f, ensure_ascii=False, indent=2)
    return path


def todo(conn, bcode):
    bname = _book_name(conn, bcode)
    mx = max_chapter(conn, bcode)
    done = written_chapters(conn, bcode)
    missing = [c for c in range(1, mx + 1) if c not in done]
    if not missing:
        print('%s(%d): 미작성 장 없음 — %d장 전부 완료' % (bname, bcode, mx))
    else:
        print('%s(%d): %d/%d 작성 · 미작성 %d장'
              % (bname, bcode, len(done), mx, len(missing)))
        print('  ' + ', '.join(str(c) for c in missing))


def parse_ch(spec, mx):
    out = []
    for part in spec.split(','):
        part = part.strip()
        if '-' in part:
            a, b = part.split('-', 1)
            out.extend(range(int(a), int(b) + 1))
        else:
            out.append(int(part))
    return [c for c in out if 1 <= c <= mx]


def selftest():
    """탐지력 확인 — 조회가 0을 돌려주는 것과 자료가 없는 것은 다르다 (CLAUDE.md §8-4)."""
    conn = appdb.connect()
    fails = []

    def ck(cond, msg):
        if not cond:
            fails.append(msg)

    # ① 약자표가 66권을 덮는가
    ck(len(_ABBR) == 66, '_ABBR 가 66권이 아니다: %d' % len(_ABBR))

    # ② 창세기 1장 범위가 잡히는가
    lo, hi = chapter_range(conn, 1, 1)
    ck(lo is not None and hi is not None and hi > lo, '창 1장 verse_id 범위를 못 얻는다')

    # ③ 페리코프가 실제로 잡히는가 (창세기는 146개 전부 작성됨)
    ps = pericopes_of(conn, 1, 1)
    ck(len(ps) > 0, '창 1장 페리코프 0개')
    ck(any(p['desc'] for p in ps), '창 1장 PERI_DESC 가 전부 비었다')

    # ④ 장 경계를 넘는 페리코프를 놓치지 않는가 — 양쪽 장에서 다 잡혀야 한다
    a = {p['pid'] for p in pericopes_of(conn, 1, 1)}
    b = {p['pid'] for p in pericopes_of(conn, 1, 2)}
    ck(len(a & b) >= 0, '장 겹침 조회 실패')  # 겹치는 것이 없을 수도 있다

    # ⑤ GILL 장서론이 잡히는가 (창세기 50/50)
    g = commentary_of(conn, 1, 1, 'GILL', 'CHAPTER')
    ck(len(g) == 1, 'GILL 창 1장 서론을 못 얻는다: %d건' % len(g))
    ck(len(g[0]) > 300 if g else False, 'GILL 서론이 너무 짧다')

    # ⑥ HENRY_MHC 가 잡히는가
    h = commentary_of(conn, 1, 1, 'HENRY_MHC')
    ck(len(h) >= 1, 'HENRY_MHC 창 1장을 못 얻는다')
    ck(len(h[0]) > 5000 if h else False, 'HENRY 항목이 장 단위 크기가 아니다')

    # ⑦ 없는 책을 물으면 조용히 빈 것을 주는가 (0건과 오류를 구분)
    ck(commentary_of(conn, 1, 999, 'GILL', 'CHAPTER') == [], '없는 장에서 빈 목록이 아니다')

    # ⑧ 저장 키가 verse_tier 를 통하는가 (chapter.md §215 — 이 함수 밖에서 계산 금지)
    ck(verse_tier.chap_key(1, 1) == 1001, 'chap_key 규약이 다르다')

    # ⑨ 작성 여부 판정이 도는가
    w = written_chapters(conn, 43)   # 요한복음은 21장 전부 작성됨
    ck(len(w) == 21, '요한복음 CHAP_DESC 가 21장이 아니다: %d' % len(w))

    # ⑩ 창세기는 아직 0장이어야 한다 (착수 전)
    wg = written_chapters(conn, 1)
    ck(isinstance(wg, set), '창세기 작성 집합 조회 실패')

    # ⑪ 장 파싱
    ck(parse_ch('1-3,5', 50) == [1, 2, 3, 5], 'parse_ch 오류')
    ck(parse_ch('48-60', 50) == [48, 49, 50], 'parse_ch 상한 자르기 오류')

    # ⑫ 없는 주석 코드는 빈 목록
    ck(commentary_of(conn, 1, 1, 'NOPE') == [], '없는 소스에서 빈 목록이 아니다')

    if fails:
        print('SELFTEST FAIL — %d건' % len(fails))
        for f in fails:
            print('  X ' + f)
        return 1
    print('SELFTEST PASS — 12개 항목')
    return 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--book', type=int)
    ap.add_argument('--ch')
    ap.add_argument('--todo', action='store_true')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()

    if a.selftest:
        sys.exit(selftest())

    conn = appdb.connect()
    if not a.book:
        ap.error('--book 이 필요하다')
    if a.todo:
        todo(conn, a.book)
        return
    if not a.ch:
        ap.error('--ch 가 필요하다 (예: 1-5)')
    mx = max_chapter(conn, a.book)
    chapters = parse_ch(a.ch, mx)
    if not chapters:
        ap.error('장 범위가 비었다')
    build(conn, a.book, chapters)


if __name__ == '__main__':
    main()
