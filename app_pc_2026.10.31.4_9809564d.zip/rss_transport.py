"""
rss_transport.py
----------------
RSS 배포 파일 전송 어댑터 (관리자 업로드 put / 사용자 다운로드 get 공용).
교체 가능한 transport — 서버 미확정 단계에서는 LOCAL_DIR 로 테스트, 확정 후 HTTP 추가.

server_cfg dict:
  { "label": "주 서버", "role": "PRIMARY"|"BACKUP",
    "transport": "LOCAL_DIR"|"HTTP"|"GIT"|"R2",
    "location": <dir 경로 또는 base_url>,
    "enabled": True }

Transport API:
  get(name)        -> 텍스트 or None   (실패 시 None — 클라 A→B 절체 판단용)
  put(name, text)  -> (ok: bool, msg: str)
"""

import os
import sys
import subprocess
# ⚠ **git 출력도 콘솔 코드페이지다**(한국어 Windows = CP949). `text=True`
#   만 주면 한글 메시지에서 `UnicodeDecodeError` 로 죽는다 —
#   배포 도중 터지면 무엇이 올라갔는지 모르게 된다(2026-09-04 같은 사고를
#   `schtasks` 에서 실제로 겪었다).
# ⚠⚠ `locale.getpreferredencoding()` 는 **못 쓴다** — Python UTF-8 모드에서
#   `utf-8` 을 돌려주는데 콘솔은 여전히 **OEM 코드페이지**(CP949)로 찍는다
#   (실측 — 그 값으로 읽으면 `오류:` 가 `□□□□:` 로 깨진다).
#   ⇒ Windows 는 `'oem'` 코덱, 그 밖은 로케일 기본.
_OEM = 'oem' if sys.platform == 'win32' else (
    __import__('locale').getpreferredencoding(False) or 'utf-8')
from urllib.request import Request, urlopen

_UA = "BibleMatrix-RSS/1.0"

# 배포 저장소 좌표 (GitHub + jsDelivr) — 확정/변경 시 여기만 수정
GH_OWNER = "suhyw123-hub"
GH_REPO = "bible_rss_dist"
GH_BRANCH = "main"
GH_SSH = f"git@github.com:{GH_OWNER}/{GH_REPO}.git"
# 배포 repo 커밋 신원(global git 미설정 시 클론에 로컬 설정) — 본인 repo 귀속용
GIT_COMMIT_NAME = GH_OWNER
GIT_COMMIT_EMAIL = "suhyw123@gmail.com"
JSDELIVR_BASE = f"https://cdn.jsdelivr.net/gh/{GH_OWNER}/{GH_REPO}@{GH_BRANCH}"
RAW_BASE = f"https://raw.githubusercontent.com/{GH_OWNER}/{GH_REPO}/{GH_BRANCH}"

# ★ 2026-10-30 Cloudflare R2 공개 주소 — 받는 쪽의 첫째(캐시 비우기 막힘·20 MB 한도가 없다 · 올린 즉시 새것)
R2_PUBLIC = "https://dist.hagahtorah.com"

# 사용자 앱이 다운로드할 미러(비밀값 없음) — 주=R2 · 예비=jsDelivr CDN · raw. 올리기는 GitHub + R2 두 곳이라 어느 쪽이든 같은 파일.
DEFAULT_SERVERS = [
    {"label": "Cloudflare R2", "role": "PRIMARY", "transport": "HTTP",
     "location": R2_PUBLIC, "enabled": True},
    {"label": "jsDelivr CDN", "role": "BACKUP", "transport": "HTTP",
     "location": JSDELIVR_BASE, "enabled": True},
    {"label": "GitHub raw", "role": "BACKUP", "transport": "HTTP",
     "location": RAW_BASE, "enabled": True},
]


def client_servers():
    """사용자 앱이 다운로드할 미러 목록(비밀값 없음). 저장소 변경 시 위 좌표만 수정."""
    return [dict(s) for s in DEFAULT_SERVERS]



def _leak(name, data):
    """올리기 전 마지막 문 — 비밀 열쇠가 들어 있으면 그 까닭(글) · 깨끗하면 ''."""
    try:
        import secret_store as _SS
        b = data if isinstance(data, (bytes, bytearray)) else str(data).encode('utf-8', 'replace')
        if b[:2] == bytes((0x1F, 0x8B)):
            import gzip
            try:
                b = gzip.decompress(b)
            except Exception:
                pass
        h = _SS.find_leaks(b, _SS.blob_free(b))
        return ('⚠ 비밀 열쇠가 들어 있어 올리지 않습니다 — %s' % name) if h else ''
    except Exception:
        return ''

class LocalDirTransport:
    """로컬 폴더(또는 공유 폴더) = 서버 시뮬레이션. 지금 테스트용."""

    def __init__(self, location):
        self.dir = location

    def _path(self, name):
        return os.path.join(self.dir, name)

    def get(self, name):
        try:
            with open(self._path(name), "r", encoding="utf-8") as f:
                return f.read()
        except Exception:
            return None

    def put_bytes(self, name, data):
        _bad = _leak(name, data)          # ★ 2026-10-11 — 열쇠가 섞인 것은 서버에 안 올린다(secret_store ③)
        if _bad:
            return False, _bad
        """⚠ **gzip 팩은 글자가 아니다** — 텍스트로 쓰면 깨진다(2026-09-04 ⑫)."""
        try:
            os.makedirs(self.dir, exist_ok=True)
            with open(self._path(name), "wb") as f:
                f.write(data)
            return True, f"saved {self._path(name)}"
        except Exception as e:
            return False, f"local put error: {e}"

    def put(self, name, text):
        _bad = _leak(name, text)          # ★ 2026-10-11 — 열쇠가 섞인 것은 서버에 안 올린다(secret_store ③)
        if _bad:
            return False, _bad
        try:
            os.makedirs(self.dir, exist_ok=True)
            with open(self._path(name), "w", encoding="utf-8") as f:
                f.write(text)
            return True, f"saved {self._path(name)}"
        except Exception as e:
            return False, f"local put error: {e}"

    def listdir(self):
        """이 서버에 지금 있는 파일 이름 — 옛 판 걷기가 캐시된 목록 대신 이것을 본다(2026-10-29)."""
        try:
            return sorted(os.listdir(self.dir))
        except Exception:                                     # noqa: BLE001
            return []

    def remove(self, name):
        """옛 지문 파일을 지운다. 없으면 조용히 넘어간다."""
        try:
            p = self._path(name)
            if os.path.exists(p):
                os.remove(p)
                return True, f"removed {p}"
            return True, "없음"
        except Exception as e:                                # noqa: BLE001
            return False, f"local rm error: {e}"


class HttpTransport:
    """확정 서버용. GET 은 지금도 동작(클라 읽기). PUT 은 인증 필요 — 추후 구현."""

    def __init__(self, location):
        self.base = location.rstrip("/")

    def get(self, name):
        try:
            req = Request(f"{self.base}/{name}", headers={"User-Agent": _UA})
            with urlopen(req, timeout=12) as r:
                if 200 <= getattr(r, "status", 200) < 300:
                    return r.read().decode("utf-8", "replace")
        except Exception:
            return None
        return None

    def put(self, name, text):
        _bad = _leak(name, text)          # ★ 2026-10-11 — 열쇠가 섞인 것은 서버에 안 올린다(secret_store ③)
        if _bad:
            return False, _bad
        # 실제 서버 확정 후 HTTP PUT/POST + 인증(관리자 로컬 비밀값) 구현
        return False, "HTTP put 미구현 — 서버 확정 후 추가 (지금은 LOCAL_DIR 사용)"


class GitTransport:
    """관리자 업로드용 — 배포 저장소(GitHub)에 파일 commit+push. (인증=관리자 PC의 git/SSH 키, 코드에 비밀값 없음.)
    put 은 로컬 작업복사본에 파일 기록(staging)만 하고, flush() 에서 한 번에 add/commit/push."""

    def __init__(self, location, work_dir=None, branch=GH_BRANCH):
        self.url = location or GH_SSH
        self.branch = branch or "main"
        # ★ 2026-10-21 앱 폴더 기준 절대 경로 — 옛 상대 경로("rss_dist/_repo")는 관리자 앱을 켠 자리(바로가기면
        #   C:\Windows\System32 등)에 저장소를 만들려다 [WinError 5] 접근 거부로 발행이 막혔다(사용자 신고).
        self.work = work_dir or os.path.join(os.path.dirname(os.path.abspath(__file__)), "rss_dist", "_repo")
        self._dirty = False

    def _git(self, *args, cwd=None):
        return subprocess.run(["git", *args], cwd=cwd or self.work,
                              capture_output=True, text=True, encoding=_OEM, errors='replace')

    def _ensure(self):
        if os.path.isdir(os.path.join(self.work, ".git")):
            return True, "ok"
        parent = os.path.dirname(self.work) or "."
        os.makedirs(parent, exist_ok=True)
        r = subprocess.run(["git", "clone", self.url, self.work],
                           capture_output=True, text=True, encoding=_OEM, errors='replace')
        if os.path.isdir(os.path.join(self.work, ".git")):
            return True, "cloned"          # 빈 저장소도 .git 생성됨(경고만)
        # clone 실패 → init 후 remote 연결
        os.makedirs(self.work, exist_ok=True)
        self._git("init")
        self._git("remote", "add", "origin", self.url)
        return True, f"init ({(r.stderr or r.stdout)[:60]})"

    def test(self):
        """비파괴 연결 확인 — git ls-remote (push/commit 없음)."""
        r = subprocess.run(["git", "ls-remote", self.url],
                           capture_output=True, text=True, encoding=_OEM, errors='replace', timeout=30)
        if r.returncode == 0:
            return True, "원격 접속 OK (ls-remote)"
        return False, f"접속 실패: {(r.stderr or r.stdout)[:120]}"

    def get(self, name):
        try:
            with open(os.path.join(self.work, name), "r", encoding="utf-8") as f:
                return f.read()
        except Exception:
            return None

    def put_bytes(self, name, data):
        _bad = _leak(name, data)          # ★ 2026-10-11 — 열쇠가 섞인 것은 서버에 안 올린다(secret_store ③)
        if _bad:
            return False, _bad
        """⚠ **gzip 팩은 글자가 아니다** — 텍스트로 쓰면 깨진다(2026-09-04 ⑫).
        본문팩·코어팩이 이 문을 쓴다. 커밋은 `flush` 가 한 번에 한다."""
        self._ensure()
        try:
            with open(os.path.join(self.work, name), "wb") as f:
                f.write(data)
            self._dirty = True
            return True, f"staged {name}"
        except Exception as e:
            return False, f"git put error: {e}"

    def put(self, name, text):
        _bad = _leak(name, text)          # ★ 2026-10-11 — 열쇠가 섞인 것은 서버에 안 올린다(secret_store ③)
        if _bad:
            return False, _bad
        self._ensure()
        try:
            with open(os.path.join(self.work, name), "w", encoding="utf-8") as f:
                f.write(text)
            self._dirty = True
            return True, f"staged {name}"
        except Exception as e:
            return False, f"git put error: {e}"

    def listdir(self):
        """작업복사본에 지금 있는 파일 이름 — 옛 판 걷기가 캐시된 목록 대신 이것을 본다(2026-10-29)."""
        self._ensure()
        try:
            return sorted(n for n in os.listdir(self.work) if n != '.git')
        except Exception:                                     # noqa: BLE001
            return []

    def remove(self, name):
        """옛 지문 파일을 작업복사본에서 지운다(커밋은 `flush` 가 한다).

        ⚠ `git add -A` 라 **지운 것도 커밋된다**. 없는 파일이면 조용히 넘어간다.
        """
        self._ensure()
        p = os.path.join(self.work, name)
        try:
            if os.path.exists(p):
                os.remove(p)
                self._dirty = True
                return True, f"staged rm {name}"
            return True, "없음"
        except Exception as e:                                # noqa: BLE001
            return False, f"git rm error: {e}"

    def flush(self):
        """staging 된 변경을 add/commit/push (1회)."""
        if not self._dirty:
            return True, "변경 없음"
        # 커밋 신원 보장(global 미설정 클론 대비) — 비어 있을 때만 로컬 설정
        if not (self._git("config", "user.email").stdout or "").strip():
            self._git("config", "user.email", GIT_COMMIT_EMAIL)
            self._git("config", "user.name", GIT_COMMIT_NAME)
        # 빈 저장소(커밋 없음)면 첫 커밋이 main 에 올라가도록 브랜치 보장
        if self._git("rev-parse", "--verify", "HEAD").returncode != 0:
            self._git("checkout", "-B", self.branch)
        self._git("add", "-A")
        cm = self._git("commit", "-m", "rss dist publish")   # 변경 없으면 실패해도 무시
        if cm.returncode != 0 and "nothing to commit" not in (cm.stdout + cm.stderr):
            return False, f"commit 실패: {(cm.stderr or cm.stdout)[:140]}"
        # ★ 2026-10-23 사진 팩이 50 MB 를 넘자 HTTPS push 가 HTTP 408 로 끊겼다 — 보내는 버퍼를 넓힌다
        self._git("config", "http.postBuffer", "524288000")
        self._git("config", "http.lowSpeedTime", "600")
        p = self._git("push", "-u", "origin", self.branch)
        self._dirty = False
        if p.returncode != 0:
            return False, f"push 실패: {(p.stderr or p.stdout)[:140]}"
        return True, "push 완료"


def purge_jsdelivr(files):
    """jsDelivr 브랜치(@main) 캐시 무효화 — 발행 직후 즉시 반영(미적용 시 최대 12h 지연).
    files: 파일명 리스트. → {파일: 상태} (best-effort, 실패해도 무해: 시간 지나면 자동 갱신)."""
    out = {}
    for name in files or []:
        url = f"https://purge.jsdelivr.net/gh/{GH_OWNER}/{GH_REPO}@{GH_BRANCH}/{name}"
        try:
            with urlopen(Request(url, headers={"User-Agent": _UA}), timeout=20) as r:
                st = getattr(r, "status", 200)
                body = r.read()
            # ★ 2026-10-29 HTTP 200 이어도 막힌 것일 수 있다 — 답의 "throttled" 를 본다(실측: 언어팩을 하나씩 올리며
            #   목록을 거듭 비우자 jsDelivr 가 30분 막았고, 200 만 보고 「비움」이라 적는 동안 폰은 옛 목록을 받았다).
            try:
                import json as _json
                paths = (_json.loads(body.decode("utf-8")) or {}).get("paths") or {}
                th = [v for v in paths.values() if isinstance(v, dict) and v.get("throttled")]
                if th:
                    st = "THROTTLED %d분" % max(1, int(th[0].get("throttlingReset") or 0) // 60)
            except Exception:
                pass
            out[name] = st
        except Exception as e:
            out[name] = str(e)[:40]
    return out


# ════════════════════════════════════════════════════════════════════════
#  Cloudflare R2 (2026-10-29 신설) — GitHub 저장소 + jsDelivr 를 대신할 파일 저장소
# ════════════════════════════════════════════════════════════════════════
# ★ 왜 옮기나 — jsDelivr 는 ⓐ 20 MB 넘는 파일을 403 으로 막고 ⓑ 캐시 비우기를
#   30분씩 막으며(317차-176) ⓒ git 저장소는 올린 판이 이력에 영영 쌓인다.
#   R2 는 파일 크기 제한이 없고 **올린 즉시 그 주소가 새것**이다(캐시 비우기 불필요).
# ★ 표준 라이브러리만 — R2 는 S3 호환 API 라 서명(SigV4)을 hmac·hashlib 으로 짓는다
#   (boto3·wrangler 를 깔지 않는다 · 배포 꾸러미가 그대로).
# ★ 열쇠 셋은 `secret_store`(admin_secrets.db)에만 — 서버 설정(location)에는
#   **버킷 이름만** 적는다. 열쇠가 없으면 아무것도 안 올리고 그렇다고 말한다.
# ★ 캐시 머리글 — 지문 이름(`이름.<16진>.확장자`)은 내용이 바뀌면 이름이 바뀌므로
#   1년 · 그 밖(mobile_index.json · manifest.tsv …)은 **5분**.
import hashlib as _hl
import hmac as _hmac
import re as _re
from datetime import datetime as _dt, timezone as _tz
from urllib.parse import quote as _q
from urllib.error import HTTPError as _HTTPError

R2_REGION = "auto"
R2_SERVICE = "s3"
R2_SECRET_NAMES = ("R2_ACCOUNT_ID", "R2_ACCESS_KEY_ID", "R2_SECRET_ACCESS_KEY")
_IMMUTABLE_RE = _re.compile(r"\.[0-9a-f]{8,}\.[A-Za-z0-9]")
_CTYPES = (('.json.gz', 'application/gzip'), ('.gz', 'application/gzip'),
           ('.json', 'application/json; charset=utf-8'),
           ('.tsv', 'text/tab-separated-values; charset=utf-8'),
           ('.txt', 'text/plain; charset=utf-8'), ('.xml', 'application/xml; charset=utf-8'),
           ('.jpg', 'image/jpeg'), ('.jpeg', 'image/jpeg'), ('.png', 'image/png'),
           ('.zip', 'application/zip'), ('.apk', 'application/vnd.android.package-archive'))


def r2_cache_control(name):
    return ("public, max-age=31536000, immutable" if _IMMUTABLE_RE.search(name or "")
            else "public, max-age=300")


def r2_content_type(name):
    low = (name or "").lower()
    for ext, ct in _CTYPES:
        if low.endswith(ext):
            return ct
    return "application/octet-stream"


def _sha256_hex(b):
    return _hl.sha256(b).hexdigest()


def _hsign(key, msg):
    return _hmac.new(key, msg.encode("utf-8"), _hl.sha256).digest()


def _qs(query):
    return "&".join("%s=%s" % (_q(str(k), safe="-_.~"), _q(str(v), safe="-_.~"))
                    for k, v in sorted((query or {}).items()))


def sigv4_headers(method, host, path, query, headers, body, access_key, secret_key,
                  region=R2_REGION, service=R2_SERVICE, amz_date=None):
    """AWS 서명 4판 — 보낼 머리글(Authorization 포함)을 돌려준다.

    path = 이미 퍼센트 부호로 쓴 경로 · query = {이름: 값}(값은 부호화 전).
    ⚠ selftest 가 AWS 공식 시험 벡터(get-vanilla)로 잰다 — 고치면 그 자리에서 잡힌다.
    """
    amz_date = amz_date or _dt.now(_tz.utc).strftime("%Y%m%dT%H%M%SZ")
    day = amz_date[:8]
    payload = _sha256_hex(body or b"")
    h = {k.lower(): str(v).strip() for k, v in (headers or {}).items()}
    h["host"] = host
    h["x-amz-date"] = amz_date
    if service == "s3":
        h["x-amz-content-sha256"] = payload
    names = sorted(h)
    canon_h = "".join("%s:%s\n" % (n, h[n]) for n in names)
    signed = ";".join(names)
    creq = "\n".join([method, path or "/", _qs(query), canon_h, signed, payload])
    scope = "%s/%s/%s/aws4_request" % (day, region, service)
    sts = "\n".join(["AWS4-HMAC-SHA256", amz_date, scope, _sha256_hex(creq.encode("utf-8"))])
    k = _hsign(("AWS4" + secret_key).encode("utf-8"), day)
    k = _hsign(k, region)
    k = _hsign(k, service)
    k = _hsign(k, "aws4_request")
    sig = _hmac.new(k, sts.encode("utf-8"), _hl.sha256).hexdigest()
    h["authorization"] = ("AWS4-HMAC-SHA256 Credential=%s/%s, SignedHeaders=%s, Signature=%s"
                          % (access_key, scope, signed, sig))
    return h


def r2_creds():
    """(계정, 열쇠 번호, 비밀) — 하나라도 없으면 None."""
    try:
        import secret_store as _SS
        vals = tuple((_SS.get(n) or "").strip() for n in R2_SECRET_NAMES)
    except Exception:
        return None
    return vals if all(vals) else None


class R2Transport:
    """관리자 업로드용 — Cloudflare R2 버킷에 곧바로 올린다(지연 커밋 없음).

    location = 버킷 이름 · public = 사용자 앱이 받을 공개 주소(선택 — get 이 먼저 본다).
    """

    def __init__(self, location, public="", endpoint=None, creds=None):
        self.bucket = (location or "").strip().strip("/")
        self.public = (public or "").rstrip("/")
        self._creds = creds
        self._endpoint = endpoint          # 시험용 — "http://127.0.0.1:port"

    def _ready(self):
        c = self._creds or r2_creds()
        if not c:
            return None, ("R2 열쇠가 없습니다 — secret_store 에 "
                          "R2_ACCOUNT_ID · R2_ACCESS_KEY_ID · R2_SECRET_ACCESS_KEY")
        if not self.bucket:
            return None, "R2 버킷 이름(location)이 비었습니다"
        return c, ""

    def _call(self, method, key="", query=None, body=b"", headers=None, timeout=120):
        c, why = self._ready()
        if not c:
            return None, why, b""
        acct, ak, sk = c
        base = self._endpoint or ("https://%s.r2.cloudflarestorage.com" % acct)
        host = base.split("://", 1)[1].split("/", 1)[0]
        path = "/" + _q(self.bucket, safe="-_.~") + ("/" + _q(key, safe="-_.~/") if key else "")
        hdr = sigv4_headers(method, host, path, query, headers, body, ak, sk)
        qs = _qs(query)
        url = base + path + ("?" + qs if qs else "")
        hdr.pop("host", None)
        hdr["user-agent"] = _UA
        req = Request(url, data=(body if method in ("PUT", "POST") else None),
                      method=method, headers=hdr)
        try:
            with urlopen(req, timeout=timeout) as r:
                return getattr(r, "status", 200), "", r.read()
        except _HTTPError as e:
            try:
                txt = e.read()[:300].decode("utf-8", "replace")
            except Exception:
                txt = ""
            m = _re.search(r"<Code>([^<]+)</Code>", txt)
            return e.code, (m.group(1) if m else txt[:80]), b""
        except Exception as e:                                       # noqa: BLE001
            return None, str(e)[:120], b""

    def test(self):
        st, why, _ = self._call("GET", query={"list-type": "2", "max-keys": "1"}, timeout=30)
        if st and 200 <= st < 300:
            return True, "R2 접속 OK (버킷 %s)" % self.bucket
        return False, "R2 접속 실패: %s %s" % (st or "", why)

    def get(self, name):
        if self.public:
            g = HttpTransport(self.public).get(name)
            if g is not None:
                return g
        st, _why, data = self._call("GET", key=name, timeout=30)
        if st and 200 <= st < 300:
            return data.decode("utf-8", "replace")
        return None

    def put_bytes(self, name, data):
        _bad = _leak(name, data)          # 열쇠가 섞인 것은 안 올린다(secret_store ③)
        if _bad:
            return False, _bad
        data = bytes(data or b"")
        st, why, _ = self._call("PUT", key=name, body=data, headers={
            "content-type": r2_content_type(name),
            "cache-control": r2_cache_control(name)})
        if st and 200 <= st < 300:
            return True, "R2 올림 %s (%d B)" % (name, len(data))
        return False, "R2 올리기 실패 %s: %s %s" % (name, st or "", why)

    def put(self, name, text):
        _bad = _leak(name, text)
        if _bad:
            return False, _bad
        return self.put_bytes(name, str(text).encode("utf-8"))

    def listdir(self):
        import html as _html
        out, token = [], None
        for _ in range(200):                        # 1,000개씩 — 20만 개까지
            q = {"list-type": "2", "max-keys": "1000"}
            if token:
                q["continuation-token"] = token
            st, _why, data = self._call("GET", query=q, timeout=60)
            if not (st and 200 <= st < 300):
                break
            txt = data.decode("utf-8", "replace")
            out += [k for k in _re.findall(r"<Key>([^<]*)</Key>", txt) if "/" not in k]
            m = _re.search(r"<NextContinuationToken>([^<]+)</NextContinuationToken>", txt)
            if "<IsTruncated>true</IsTruncated>" not in txt or not m:
                break
            token = _html.unescape(m.group(1))
        return sorted(_html.unescape(k) for k in out)

    def remove(self, name):
        st, why, _ = self._call("DELETE", key=name, timeout=30)
        if st in (200, 204, 404):
            return True, "R2 지움 %s" % name
        return False, "R2 지우기 실패 %s: %s %s" % (name, st or "", why)

    def flush(self):
        return True, "R2 — 올린 즉시 반영"


def _selftest_r2():
    ok, bad = 0, []

    def ck(c, m):
        nonlocal ok
        if c:
            ok += 1
        else:
            bad.append(m)
    # ① AWS 공식 시험 벡터 get-vanilla(aws-sig-v4-test-suite)
    h = sigv4_headers("GET", "example.amazonaws.com", "/", {}, {}, b"",
                      "AKIDEXAMPLE", "wJalrXUtnFEMI/K7MDENG+bPxRfiCYEXAMPLEKEY",
                      region="us-east-1", service="service", amz_date="20150830T123600Z")
    ck(h["authorization"].endswith(
        "Signature=5fa00fa31553b73ebf1942676e86291e8372ff2a2260956d9b8aae1d763fbf31"),
       "SigV4 get-vanilla 서명")
    ck("SignedHeaders=host;x-amz-date," in h["authorization"], "서명 머리글 목록")
    # ② 캐시 · 형식
    ck(r2_cache_control("mobile_lang_KO.0123456789abcdef.json.gz").endswith("immutable"), "지문 = 1년")
    ck(r2_cache_control("mobile_index.json") == "public, max-age=300", "목록 = 5분")
    ck(r2_cache_control("manifest.tsv") == "public, max-age=300", "manifest = 5분")
    ck(r2_content_type("a.json.gz") == "application/gzip", "gzip 형식")
    # ③ 열쇠 없으면 안 올리고 말한다
    import secret_store as _SS
    _old = _SS.get
    _SS.get = lambda n, d='': ''
    try:
        okp, msg = R2Transport("hagah-dist").put("x.txt", "hello")
    finally:
        _SS.get = _old
    ck((not okp) and "열쇠" in msg, "열쇠 없음 → 안 올림")
    # ④ 가짜 S3 서버로 왕복
    import threading
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    store, seen = {}, []

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _key(self):
            parts = self.path.split("?", 1)[0].split("/", 2)
            return parts[2] if len(parts) > 2 else ""

        def do_PUT(self):
            seen.append((self.headers.get("Authorization") or "",
                         self.headers.get("Cache-Control") or ""))
            n = int(self.headers.get("Content-Length") or 0)
            store[self._key()] = self.rfile.read(n)
            self.send_response(200)
            self.end_headers()

        def do_GET(self):
            k = self._key()
            if not k:
                body = ("<ListBucketResult>%s<IsTruncated>false</IsTruncated></ListBucketResult>"
                        % "".join("<Contents><Key>%s</Key></Contents>" % x for x in store)).encode()
            elif k in store:
                body = store[k]
            else:
                self.send_response(404)
                self.end_headers()
                return
            self.send_response(200)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_DELETE(self):
            store.pop(self._key(), None)
            self.send_response(204)
            self.end_headers()
    srv = ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        ep = "http://127.0.0.1:%d" % srv.server_address[1]
        t = R2Transport("hagah-dist", endpoint=ep, creds=("acct", "AKTEST", "SKTEST"))
        ck(t.put("mobile_index.json", '{"a":1}')[0], "PUT 글")
        ck(t.put_bytes("p.0123456789abcdef.json.gz", b"\x1f\x8b\x08\x00zz")[0], "PUT 바이트")
        ck(bool(seen) and seen[0][0].startswith("AWS4-HMAC-SHA256 Credential=AKTEST/"), "Authorization 실림")
        ck(bool(seen) and seen[0][1] == "public, max-age=300", "목록 캐시 머리글")
        ck(t.get("mobile_index.json") == '{"a":1}', "GET 되읽기")
        ck(t.listdir() == ["mobile_index.json", "p.0123456789abcdef.json.gz"], "LIST")
        ck(t.remove("mobile_index.json")[0] and t.listdir() == ["p.0123456789abcdef.json.gz"], "DELETE")
        ck(t.get("없는것.txt") is None, "없으면 None")
        ck(t.test()[0], "test()")
        ck(make_transport({"transport": "R2", "location": "b"}).__class__.__name__ == "R2Transport",
           "make_transport R2")
    finally:
        srv.shutdown()
    return ok, bad


def make_transport(server_cfg):
    t = (server_cfg or {}).get("transport", "LOCAL_DIR")
    loc = (server_cfg or {}).get("location", "")
    if t == "HTTP":
        return HttpTransport(loc)
    if t == "GIT":
        return GitTransport(loc, work_dir=(server_cfg or {}).get("work_dir"))
    if t == "R2":
        return R2Transport(loc, public=(server_cfg or {}).get("public", ""))
    return LocalDirTransport(loc)


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        _ok, _bad = _selftest_r2()
        for _m in _bad:
            print("FAIL", _m)
        print("rss_transport R2 %d/%d %s" % (_ok, _ok + len(_bad), "PASS" if not _bad else "FAIL"))
        sys.exit(1 if _bad else 0)
    if "--r2-test" in sys.argv:
        _i = sys.argv.index("--r2-test")
        _b = sys.argv[_i + 1] if len(sys.argv) > _i + 1 else ""
        print(R2Transport(_b).test())
