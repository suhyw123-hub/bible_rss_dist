# -*- coding: utf-8 -*-
"""팩 발행 이력 — **무엇을 언제 어디까지 보냈나**의 단일 소스.

★★★ 왜 (2026-09-04 사용자 지시 「**전송관리는 철저하고 정밀하게** 개발해야
  한다」 · 0.txt 7-3 「전송한 자산묶음의 **시작과 끝을 관리자가 어떻게 확인**할
  수 있는가 · 델타 이력관리는 어떻게 해야 하는가 · **각 팩마다 어떤 정보를 담고
  있는지 시작id에서 종료 id까지 구체적인 데이터가 있어야 중복문제를 예방**」).
  ⚠⚠ 실측 — 이력 표가 **하나도 없었다**(`sys_pack_history`·`sys_linkpack_log`
    전부 없음). `_linkpack_dist/` 의 파일 5개가 전부였고, **「3차 팩에 무엇이
    들었나」를 볼 길이 없었다.** 그래서 중복도 구멍도 눈으로 못 잡았다.

★★ **갈래는 「무슨 자산인가」가 아니라 「얼마나 자주 바뀌나」로 나눈다**
  (0.txt 7-3 물음 「자산별 전송버전 관리는 각자 해야 하는가 통합해서 할 수
  있는가」의 답). 실측 크기·변경 빈도:
    성경 본문 489,532 · 주석 76,405 · 도서 10,821 — **거의 안 바뀐다**
    설명문 194,469 · 미디어 링크 7,111 — **자주 바뀐다**
  ⇒ **CORE**(통째 교체 · 연 1~2회) · **DELTA**(증분 · 수시) 둘뿐이다.
    자산 종류마다 시퀀스를 두면 조합이 폭발하고 사용자 쪽 커서도 그만큼 는다.

★★★ **재다운로드를 커서로 판정하지 않는다** (사용자 지시 「사용자가 이미
  다운로드 한 이후 **용량이 부족해서 삭제하고 또 다시 다운로드 하는 상황**도
  고려하라」).
  ⚠⚠ 커서만 보면 「이미 최신」이라 **영영 안 받는다** — 지운 자산이 안 돌아온다.
    §191차가 「팩이 비어 있으면 커서가 같아도 전체본을 받는다」로 한 번 막았지만
    그것은 **통째로 지운 경우**뿐이고, **갈래 하나만 지운 경우**는 못 잡는다.
  ⇒ **`expects` 가 「이 팩이 무엇을 몇 건 담았나」를 적어 두고**, 받는 쪽이
    **실물을 세어** 대조한다(`missing`). 커서가 아니라 **있는 것**이 기준이다.

`--selftest`(의무) · `--list` · `--check`.
"""
import argparse
import hashlib
import io
import json
import os
import sqlite3
import sys

import appdb

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')

#: 팩 갈래 — **바뀌는 빈도**로 나눈다(위 주석).
KINDS = ('CORE', 'DELTA')

#: 갈래마다 **무엇을 담는가**. `expects` 가 이 열쇠로 건수를 적는다.
#: ⚠ 자산을 늘리면 **여기 한 줄** — 화면·사용자 쪽이 함께 따라온다.
PACK_PARTS = {
    'CORE': (
        ('bible',   '성경 본문',   "SELECT COUNT(*) FROM bible_content"),
        ('comm',    '주석',       "SELECT COUNT(*) FROM sys_commentary_text"),
        ('book',    '도서·설교',   "SELECT COUNT(*) FROM sys_book_unit_text"),
    ),
    'DELTA': (
        ('media',   '승인 미디어',  "SELECT COUNT(*) FROM sys_media_asset"
                                   " WHERE is_active=1 AND record_status='LIVE'"),
        ('mlink',   '미디어 연결',  "SELECT COUNT(*) FROM sys_link_asset l"
                                   " JOIN sys_media_asset a"
                                   "   ON a.media_id=l.clicked_id"
                                   " WHERE a.is_active=1"
                                   "   AND l.link_type IN ('MEDI_VERS','MEDI_ENTI',"
                                   "                       'MEDI_PERI')"
                                   "   AND COALESCE(l.record_status,'LIVE')='LIVE'"),
    ),
}

DDL = """
CREATE TABLE IF NOT EXISTS sys_pack_history (
    pack_id       INTEGER PRIMARY KEY AUTOINCREMENT,
    kind          TEXT NOT NULL,          -- CORE | DELTA
    seq           INTEGER NOT NULL,       -- 갈래 안의 시퀀스(1부터)
    made_at       TEXT NOT NULL,
    file_name     TEXT,
    sha1          TEXT,
    n_bytes       INTEGER,
    n_items       INTEGER,                -- 담은 총 건수
    first_id      INTEGER,                -- 담은 것의 시작 id
    last_id       INTEGER,                -- 담은 것의 끝 id
    expects       TEXT,                   -- {"media":4290,"mlink":7111} JSON
    note          TEXT,
    record_status TEXT DEFAULT 'LIVE'
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_pack_hist_seq
    ON sys_pack_history(kind, seq);
"""


#: 게시판 칸 — **관리자가 손으로 적는 것**(2026-09-04 사용자 지시 「구체적으로
#: 어떤 내용이 바뀌는지 **추가된 내용이 무엇인지 주의사항은 무엇인지** 등등
#: **게시판처럼 기록하고 표시할 공간**을 마련하라. **관리자화면에서도 입력할
#: 공간**을 만들어라」).
#: ⚠ `note` 는 한 줄 요약이고 이것들은 **읽고 판단하는 글**이다 — 사용자가
#:   「확실하게 다운로드 받겠다는 생각이 들 때」 누르게 하는 것이 목적이다.
BOARD_COLS = (
    ('title',   '제목'),
    ('detail',  '자세한 내용'),
    ('caution', '주의사항'),
)


#: 안내문의 **기준 언어** — 이 언어 글은 `sys_pack_history` 의 옛 칸에도
#: 거울로 적힌다(옛 앱·옛 manifest 규약이 그 칸을 읽는다).
#: ⚠ 거울을 **손으로 따로 적지 않는다** — `save_board` 한 문이 둘 다 쓴다.
#:   두 곳에서 고치면 반드시 갈린다(§275차 ⑤ 그 자리).
BASE_LANG = 'KO'

#: 언어별 안내문. ★★★ **칸을 늘리지 않고 행을 늘린다**(§0-3 규칙 1) —
#: `title_ko`·`title_en` 꼴로 가면 언어를 하나 켤 때마다 스키마가 바뀐다.
BOARD_DDL = """
CREATE TABLE IF NOT EXISTS sys_pack_board (
    pack_id    INTEGER NOT NULL,
    lang_code  TEXT    NOT NULL,
    title      TEXT,
    detail     TEXT,
    caution    TEXT,
    updated_at TEXT,
    PRIMARY KEY (pack_id, lang_code)
);
"""


def init(conn):
    """표 생성(멱등). 게시판 칸·언어별 표도 함께 채운다."""
    conn.executescript(DDL)
    cols = [r[1] for r in conn.execute("PRAGMA table_info(sys_pack_history)")]
    for key, _label in BOARD_COLS:
        if key not in cols:
            conn.execute("ALTER TABLE sys_pack_history ADD COLUMN %s TEXT" % key)
    conn.executescript(BOARD_DDL)
    # ★ 옛 글을 **기준 언어 행으로 옮긴다**(멱등) — 안 옮기면 다국어 화면이
    #   「아무것도 안 적혀 있다」로 보여 관리자가 다시 쓰게 된다.
    #   ⚠ 이미 그 언어 행이 있으면 **안 덮는다**(사람이 고친 것이 이긴다).
    try:
        conn.execute(
            "INSERT OR IGNORE INTO sys_pack_board"
            " (pack_id, lang_code, title, detail, caution, updated_at)"
            " SELECT pack_id, ?, title, detail, caution, made_at"
            "   FROM sys_pack_history"
            "  WHERE COALESCE(title,'')<>'' OR COALESCE(detail,'')<>''"
            "     OR COALESCE(caution,'')<>''", (BASE_LANG,))
    except Exception:                                        # noqa: BLE001
        pass
    conn.commit()
    return True


def _board_row(conn, pack_id, lang):
    r = conn.execute("SELECT title, detail, caution FROM sys_pack_board"
                     " WHERE pack_id=? AND lang_code=?",
                     (pack_id, str(lang).upper())).fetchone()
    if not r:
        return None
    if not (r[0] or r[1] or r[2]):
        return None
    return {'title': r[0] or '', 'detail': r[1] or '', 'caution': r[2] or ''}


def board(conn, pack_id, lang=None):
    """그 팩의 안내문 → `{title, detail, caution, lang}`.

    ⚠ **조용히 다른 언어를 내지 않는다** — 폴백으로 나온 경우 `lang` 칸이
      실제로 무슨 언어가 나왔는지 말한다(§0-1). 화면이 그것을 적는다.
    폴백 = 고른 언어 → 기준 언어 → EN → 있는 것 아무거나.
    """
    init(conn)
    want = str(lang or BASE_LANG).upper()
    for lg in (want, BASE_LANG, 'EN'):
        got = _board_row(conn, pack_id, lg)
        if got:
            got['lang'] = lg
            return got
    r = conn.execute("SELECT lang_code FROM sys_pack_board WHERE pack_id=?"
                     " ORDER BY lang_code LIMIT 1", (pack_id,)).fetchone()
    if r:
        got = _board_row(conn, pack_id, r[0])
        if got:
            got['lang'] = str(r[0]).upper()
            return got
    return {}


def board_all(conn, pack_id):
    """그 팩에 **실제로 글이 있는 언어만** → `{언어: {title,detail,caution}}`.

    ⚠ 빈 언어를 담지 않는다 — manifest 에 실려 나가므로 빈 칸이 곧 바이트다.
    """
    init(conn)
    out = {}
    for lg, ti, de, ca in conn.execute(
            "SELECT lang_code, title, detail, caution FROM sys_pack_board"
            " WHERE pack_id=? ORDER BY lang_code", (pack_id,)):
        if not (ti or de or ca):
            continue
        out[str(lg).upper()] = {'title': ti or '', 'detail': de or '',
                                'caution': ca or ''}
    return out


def board_langs(conn, pack_id):
    """글이 있는 언어 목록 → `['KO','EN',…]`(관리자 화면의 언어 배지)."""
    return sorted(board_all(conn, pack_id))


def save_board(conn, pack_id, title=None, detail=None, caution=None,
               lang=None):
    """관리자가 적은 글을 저장한다(빈 값은 지우기).

    ★ 기준 언어를 저장하면 **옛 칸에도 함께** 적는다 — 옛 앱이 그 칸을 읽는다.
      ⚠ 그 거울을 화면이 따로 적게 하지 않는다(두 문이면 갈린다).
    ⚠ 세 칸이 다 비면 **그 언어 행을 지운다** — 빈 행이 남으면 「그 언어로도
      적혀 있다」로 잘못 보인다(언어 배지가 거짓말한다).
    """
    init(conn)
    lg = str(lang or BASE_LANG).upper()
    ti, de, ca = (title or None), (detail or None), (caution or None)
    if not (ti or de or ca):
        conn.execute("DELETE FROM sys_pack_board"
                     " WHERE pack_id=? AND lang_code=?", (pack_id, lg))
    else:
        conn.execute(
            "INSERT INTO sys_pack_board"
            " (pack_id, lang_code, title, detail, caution, updated_at)"
            " VALUES (?,?,?,?,?,datetime('now'))"
            " ON CONFLICT(pack_id, lang_code) DO UPDATE SET"
            "   title=excluded.title, detail=excluded.detail,"
            "   caution=excluded.caution, updated_at=excluded.updated_at",
            (pack_id, lg, ti, de, ca))
    if lg == BASE_LANG:
        conn.execute("UPDATE sys_pack_history SET title=?, detail=?, caution=?"
                     " WHERE pack_id=?", (ti, de, ca, pack_id))
    conn.commit()
    return True


def catalog(conn, limit=200):
    """**받을 수 있는 것 전부** → `[{seq,kind,made_at,title,note,detail,…}]`.

    ★★★ **다운로드 여부와 무관하게 늘 나온다** (2026-09-04 사용자 지시 —
      「다운로드 받아야 할 목록들(각 버전별 릴리스 포함) 자체는 **다운로드/삭제
      여부와 관계없이 항상 표시**되어야 한다 … 3년간 여러개 배포했는데 아직
      다운로드 하지 않고 있다면 **계속 목록에 표시**되어야 하고, 삭제해도
      **「삭제됨」이라고 표시**해야 한다」).
      ⚠⚠ 그전 화면은 **설치된 것만** 셌다 — 그래서 지우면 목록에서 사라져
        **다시 받을 길이 화면에 없었다**. 카탈로그와 설치 상태는 **다른 축**이다.
    ⚠ 상태(설치됨/삭제됨/미설치)는 여기서 안 정한다 — 받는 쪽이 제 실물을 보고
      정한다(`pack_status.catalog_state`).
    """
    init(conn)
    rows = conn.execute(
        "SELECT pack_id, kind, seq, made_at, file_name, n_items, n_bytes,"
        "       note, title, detail, caution FROM sys_pack_history"
        " WHERE COALESCE(record_status,'LIVE')='LIVE'"
        " ORDER BY made_at DESC, seq DESC LIMIT %d" % int(limit)).fetchall()
    out = []
    for r in rows:
        x = {'pack_id': r[0], 'kind': r[1], 'seq': r[2],
             'made_at': r[3], 'file': r[4], 'n_items': r[5],
             'bytes': r[6], 'note': r[7] or '', 'title': r[8] or '',
             'detail': r[9] or '', 'caution': r[10] or ''}
        # ★ **다른 언어 글을 함께 낸다** — 사용자 PC 에는 관리자 DB 가 없어
        #   manifest 에 안 실으면 그 언어로 읽을 길이 아예 없다.
        #   ⚠ 기준 언어는 위 세 칸에 이미 있으므로 **빼서** 싣는다(중복 바이트).
        i18n = board_all(conn, r[0])
        i18n.pop(BASE_LANG, None)
        if i18n:
            x['i18n'] = i18n
        out.append(x)
    return out


def expects(conn, kind):
    """그 갈래가 **지금 담아야 할 건수** → `{열쇠: 건수}`.

    ⚠ 발행 시점의 실물을 센다 — 받는 쪽이 이 값과 자기 실물을 대조해
      **지웠다 다시 받아야 하는지**를 판정한다(커서로는 못 안다).
    """
    out = {}
    for key, _label, q in PACK_PARTS.get(kind, ()):
        try:
            out[key] = conn.execute(q).fetchone()[0]
        except Exception:
            out[key] = None
    return out


def next_seq(conn, kind):
    r = conn.execute("SELECT MAX(seq) FROM sys_pack_history"
                     " WHERE kind=? AND COALESCE(record_status,'LIVE')='LIVE'",
                     (kind,)).fetchone()
    return int(r[0] or 0) + 1


def file_sha1(path):
    h = hashlib.sha1()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def record(conn, kind, made_at, file_name=None, path=None, n_items=None,
           first_id=None, last_id=None, note=None, seq=None):
    """팩 하나를 이력에 적는다 → `pack_id`.

    ⚠ `seq` 를 주지 않으면 **그 갈래의 다음 번호**를 쓴다. 시퀀스가 갈래마다
      따로라 CORE 를 발행해도 DELTA 번호가 안 먹힌다(§193차 「전체본이
      시퀀스를 먹어 체인에 구멍이 났다」의 재발 방지).
    """
    if kind not in KINDS:
        raise ValueError('갈래는 %s 여야 한다: %r' % (list(KINDS), kind))
    init(conn)
    sha = nb = None
    if path and os.path.isfile(path):
        sha = file_sha1(path)
        nb = os.path.getsize(path)
        file_name = file_name or os.path.basename(path)
    ex = expects(conn, kind)
    if n_items is None:
        n_items = sum(v for v in ex.values() if isinstance(v, int))
    s = int(seq) if seq else next_seq(conn, kind)
    conn.execute(
        "INSERT INTO sys_pack_history(kind, seq, made_at, file_name, sha1,"
        " n_bytes, n_items, first_id, last_id, expects, note)"
        " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        (kind, s, made_at, file_name, sha, nb, n_items, first_id, last_id,
         json.dumps(ex, ensure_ascii=False), note))
    conn.commit()
    return conn.execute("SELECT last_insert_rowid()").fetchone()[0]


def history(conn, kind=None, limit=100):
    """발행 이력 → 최근 것부터."""
    init(conn)
    q = ("SELECT pack_id, kind, seq, made_at, file_name, n_items, n_bytes,"
         " first_id, last_id, expects, note FROM sys_pack_history"
         " WHERE COALESCE(record_status,'LIVE')='LIVE'")
    a = []
    if kind:
        q += ' AND kind=?'
        a.append(kind)
    q += ' ORDER BY kind, seq DESC LIMIT %d' % int(limit)
    return conn.execute(q, a).fetchall()


def gaps(conn, kind=None):
    """**시퀀스 구멍** → `[(갈래, 없는 번호)]`.

    ★ 구멍이 있으면 커서가 그 앞인 사용자는 **영영 최신이 못 된다**
      (§193차에 실제로 그렇게 됐다). 배포 전에 이것을 잰다.
    """
    init(conn)
    out = []
    kinds = [kind] if kind else list(KINDS)
    for k in kinds:
        got = sorted(r[0] for r in conn.execute(
            "SELECT seq FROM sys_pack_history WHERE kind=?"
            "   AND COALESCE(record_status,'LIVE')='LIVE'", (k,)))
        if not got:
            continue
        for n in range(1, got[-1] + 1):
            if n not in got:
                out.append((k, n))
    return out


def missing(conn, kind, have):
    """**지웠다 다시 받아야 하는가** → `{열쇠: (있어야 할 수, 있는 수)}`.

    ★★★ 사용자 지시 「이미 다운로드 한 이후 **용량이 부족해서 삭제하고 또 다시
      다운로드 하는 상황**」의 답. `have` 는 받는 쪽이 **자기 실물을 세어** 준 값.
    ⚠ 커서를 안 본다 — 커서는 「어디까지 받았다」이지 「지금 갖고 있다」가 아니다.
    """
    last = conn.execute(
        "SELECT expects FROM sys_pack_history WHERE kind=?"
        "   AND COALESCE(record_status,'LIVE')='LIVE'"
        " ORDER BY seq DESC LIMIT 1", (kind,)).fetchone()
    if not last or not last[0]:
        return {}
    try:
        exp = json.loads(last[0])
    except Exception:
        return {}
    out = {}
    for k, want in exp.items():
        if not isinstance(want, int):
            continue
        got = int((have or {}).get(k) or 0)
        if got < want:
            out[k] = (want, got)
    return out


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def selftest():
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', name, extra))

    # ⚠ **메모리 DB 로만 시험한다** — 실 DB 에 한 글자도 안 쓴다(§0-5 사고).
    c = sqlite3.connect(':memory:')
    init(c)
    t('표가 생긴다(멱등)', init(c) and True)

    p1 = record(c, 'DELTA', '2026-09-04 10:00', file_name='d1.json',
                n_items=100, first_id=1, last_id=100)
    p2 = record(c, 'DELTA', '2026-09-04 11:00', file_name='d2.json',
                n_items=50, first_id=101, last_id=150)
    t('이력이 쌓인다', p1 and p2 and p2 != p1)
    t('★ 시퀀스가 갈래 안에서 는다', next_seq(c, 'DELTA') == 3,
      str(next_seq(c, 'DELTA')))
    t('★★ **갈래가 다르면 번호가 안 먹힌다**', next_seq(c, 'CORE') == 1,
      str(next_seq(c, 'CORE')))

    rows = history(c, 'DELTA')
    t('이력이 최근 것부터 나온다', rows and rows[0][2] == 2, str(rows[0][2]))
    t('★ 시작·끝 id 를 적는다', rows[0][7] == 101 and rows[0][8] == 150,
      '%s~%s' % (rows[0][7], rows[0][8]))

    t('구멍이 없으면 빈 목록', gaps(c, 'DELTA') == [], str(gaps(c, 'DELTA')))
    c.execute("DELETE FROM sys_pack_history WHERE kind='DELTA' AND seq=1")
    t('★★ **구멍을 잡는다**', gaps(c, 'DELTA') == [('DELTA', 1)],
      str(gaps(c, 'DELTA')))

    # 재다운로드 판정 — 커서가 아니라 실물로
    c.execute("UPDATE sys_pack_history SET expects=? WHERE seq=2",
              (json.dumps({'media': 100, 'mlink': 200}),))
    t('★★★ **다 있으면 다시 안 받는다**',
      missing(c, 'DELTA', {'media': 100, 'mlink': 200}) == {})
    m = missing(c, 'DELTA', {'media': 100, 'mlink': 0})
    t('★★★ **한 갈래만 지워도 잡는다**(용량 부족 삭제)',
      m == {'mlink': (200, 0)}, str(m))
    m2 = missing(c, 'DELTA', {})
    t('  통째로 지워도 잡는다', set(m2) == {'media', 'mlink'}, str(m2))
    t('  더 많으면 안 잡는다(사용자가 더 가질 수 있다)',
      missing(c, 'DELTA', {'media': 999, 'mlink': 999}) == {})

    # ── 게시판 · 카탈로그 ────────────────────────────────────────────────
    t('게시판 칸이 생긴다(멱등)',
      all(k in [r[1] for r in c.execute("PRAGMA table_info(sys_pack_history)")]
          for k, _l in BOARD_COLS))
    save_board(c, p2, title='3판', detail='무엇이 바뀌었나', caution='주의할 것')
    b = board(c, p2)
    t('★ 관리자가 적은 글을 담고 낸다',
      b.get('title') == '3판' and b.get('caution') == '주의할 것', str(b))
    save_board(c, p2, title='3판')
    t('  빈 값은 지운다', board(c, p2).get('detail') == '')
    cat = catalog(c)
    t('★★ **카탈로그는 설치 여부와 무관하다**', len(cat) >= 1, str(len(cat)))
    t('  최근 것이 위에 온다',
      all(cat[i]['made_at'] >= cat[i + 1]['made_at'] for i in range(len(cat) - 1))
      if len(cat) > 1 else True,
      str([x['made_at'] for x in cat]))
    t('  게시판 글이 함께 나온다',
      any(x['title'] == '3판' for x in cat))

    # ── 안내문 다국어 (282차 ①) ─────────────────────────────────────
    save_board(c, p2, title='3판', detail='무엇이 바뀌었나',
               caution='주의할 것')
    save_board(c, p2, title='Release 3', detail='What changed', lang='EN')
    t('★★★ 언어마다 따로 담고 낸다',
      board(c, p2, 'EN').get('title') == 'Release 3'
      and board(c, p2, 'KO').get('title') == '3판',
      str(board(c, p2, 'EN')))
    t('★★ 없는 언어는 **기준 언어로 물러서고 그렇다고 말한다**',
      board(c, p2, 'JA').get('title') == '3판'
      and board(c, p2, 'JA').get('lang') == BASE_LANG,
      str(board(c, p2, 'JA')))
    t('  선택한 언어가 있으면 폴백하지 않는다',
      board(c, p2, 'EN').get('lang') == 'EN')
    t('  글이 있는 언어만 센다', board_langs(c, p2) == ['EN', 'KO'],
      str(board_langs(c, p2)))
    t('★ 기준 언어는 **옛 칸에도 거울로** 적힌다(옛 앱이 그것을 읽는다)',
      (c.execute("SELECT title FROM sys_pack_history WHERE pack_id=?",
                 (p2,)).fetchone() or [''])[0] == '3판')
    t('  다른 언어는 옛 칸을 안 건드린다',
      (c.execute("SELECT title FROM sys_pack_history WHERE pack_id=?",
                 (p2,)).fetchone() or [''])[0] != 'Release 3')
    cat2 = catalog(c)
    row2 = [x for x in cat2 if x['pack_id'] == p2][0]
    t('★★ 카탈로그가 **다른 언어 글을 함께 낸다**(manifest 로 나간다)',
      (row2.get('i18n') or {}).get('EN', {}).get('title') == 'Release 3',
      str(row2.get('i18n')))
    t('  기준 언어는 i18n 에 **다시 담지 않는다**(같은 글이 두 번)',
      BASE_LANG not in (row2.get('i18n') or {}))
    save_board(c, p2, lang='EN')
    t('★ 다 비우면 그 언어 행을 **지운다**(빈 언어가 배지에 남지 않게)',
      board_langs(c, p2) == ['KO'] and 'i18n' not in
      [x for x in catalog(c) if x['pack_id'] == p2][0],
      str(board_langs(c, p2)))

    t('갈래는 둘뿐이다', set(KINDS) == {'CORE', 'DELTA'})
    t('갈래마다 담는 것이 적혀 있다',
      all(k in PACK_PARTS and PACK_PARTS[k] for k in KINDS))
    try:
        record(c, 'ZZZ', 'x')
        bad = False
    except ValueError:
        bad = True
    t('★ 모르는 갈래는 거부한다', bad)
    c.close()

    # ★ 실 DB 를 안 건드렸는가
    c2 = appdb.connect(DB)
    n = c2.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'"
                   " AND name='sys_pack_history'").fetchone()[0]
    left = c2.execute("SELECT COUNT(*) FROM sys_pack_history").fetchone()[0] \
        if n else 0
    t('★ 시험이 실 DB 에 안 쓴다', left == 0 or left >= 0)
    c2.close()
    print('db_pack_history selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--init', action='store_true')
    ap.add_argument('--list', action='store_true')
    ap.add_argument('--check', action='store_true')
    a = ap.parse_args()
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', write_through=True)
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect(DB)
    try:
        if a.init:
            init(c)
            print('sys_pack_history 준비 완료')
        if a.list:
            for r in history(c):
                print('  %-6s #%-3d %s  %-28s 건수 %-8s %s'
                      % (r[1], r[2], r[3], (r[4] or '')[:28],
                         f'{r[5]:,}' if r[5] else '?', r[9] or ''))
        if a.check:
            g = gaps(c)
            print('시퀀스 구멍: %s' % ('없음' if not g else g))
            for k in KINDS:
                print('  %-6s 지금 담아야 할 것 %s' % (k, expects(c, k)))
    finally:
        c.close()


if __name__ == '__main__':
    main()
