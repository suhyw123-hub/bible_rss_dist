# -*- coding: utf-8 -*-
"""언어 단일 소스 — sys_language 테이블을 읽어 앱 전역 언어 목록/속성 제공.

언어 추가/편집은 관리자 '언어 관리' 화면(또는 sys_language 직접) **한 곳**에서만 한다.
모든 패널은 하드코딩 리스트(`_LANG_CODES=[...]`) 대신 이 모듈을 import 한다.
→ 새 언어가 일부 화면에서 누락되는 조용한 버그를 구조적으로 차단(§0-3).

API:
  ui_langs()       UI/번역 대상 언어 코드 리스트 (is_ui=1, sort_order 순)
  all_langs()      전체 언어 코드 (원문 HE/EL/COP 포함, sort_order 순)
  lang_query(code) YouTube 검색 접미('{이름} {접미}'); 없으면 'Bible'
  lang_name(code)  표시 이름(현지어 우선, EN 폴백)
  reload()         캐시 무효화 (관리자 편집 후 호출 — 단, 이미 빌드된 콤보는 재오픈 필요)

캐시: 프로세스 1회 로드. 관리자가 언어를 추가하면 관리자 앱 재시작(또는 reload()+패널 재오픈)으로 반영.
DB 미마이그레이션/오류 시 §0-3 표준 10개로 폴백.
"""
import os
import sqlite3
import appdb

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')

# 폴백(§0-3 표준 10개) — sys_language 조회 실패 시
_FALLBACK = ['EN', 'KO', 'ZH', 'JA', 'DE', 'FR', 'ES', 'AR', 'RU', 'PT']

_cache = None   # [(code, name_en, name_local, is_ui, sort_order, yt_query), ...]


def _load():
    global _cache
    if _cache is not None:
        return _cache
    rows = []
    try:
        conn = appdb.connect(DB, timeout=30)
        cols = {r[1] for r in conn.execute('PRAGMA table_info(sys_language)')}
        if {'is_ui', 'sort_order', 'yt_query'} <= cols:
            # ★ `is_content` 는 **뒤에 붙은 칸**이라 없을 수 있다 — 없으면
            #   UI 축을 그대로 쓴다(옛 DB 에서도 돌아야 한다).
            _ic = ('COALESCE(is_content, is_ui, 1)' if 'is_content' in cols
                   else 'COALESCE(is_ui,1)')
            rows = conn.execute(
                "SELECT lang_code, lang_name_en, lang_name_local, "
                "COALESCE(is_ui,1), COALESCE(sort_order,100), yt_query, "
                + _ic +
                " FROM sys_language ORDER BY COALESCE(sort_order,100), lang_code"
            ).fetchall()
        else:   # 구 스키마(컬럼 없음) — 전부 UI 로 간주
            rows = [(r[0], r[1], r[2], 1, 100 + i, None, 1)
                    for i, r in enumerate(conn.execute(
                        "SELECT lang_code, lang_name_en, lang_name_local "
                        "FROM sys_language"))]
        conn.close()
    except Exception:
        rows = []
    if not rows:
        rows = [(c, c, c, 1, i, None, 1) for i, c in enumerate(_FALLBACK)]
    _cache = rows
    return _cache


def reload():
    global _cache
    _cache = None
    return _load()


def ui_langs():
    """UI/번역 대상 언어 코드 (sort_order 순)."""
    return [r[0] for r in _load() if r[3]]


def content_langs():
    """**자료를 쓸 수 있는 언어** (sort_order 순) — UI 언어와 **다른 축**이다.

    ★★★ 2026-09-22 (1.txt 8-3 사용자 「히브리어는 연구자료와 같은 것들을
      표시할 방법이 없다. **추가 활성화해야 한다**」).
      ⚠⚠ `is_ui=1` 로 켜면 **앱 표시 언어 콤보에도** 뜬다. `ui_strings` 에
        HE 가 한 줄도 없어 화면이 통째로 영어로 떨어진다 — 「고를 수 있는데
        안 나오는」 거짓 기능이 된다(§0-1). ⇒ **축을 갈랐다.**
    ⚠ 옛 DB 에 칸이 없으면 UI 축 그대로다(조용히 줄지 않는다).
    """
    return [r[0] for r in _load() if (r[6] if len(r) > 6 else r[3])]


def all_langs():
    """전체 언어 코드 (원문 포함, sort_order 순)."""
    return [r[0] for r in _load()]


def lang_query(code):
    """YouTube 검색 접미 (없으면 'Bible')."""
    for r in _load():
        if r[0] == code:
            return r[5] or 'Bible'
    return 'Bible'


def lang_name_en(code):
    """**영어 이름** — `sys_language.lang_name_en`(2026-09-18 신설).

    ★ 관리자 화면의 언어 콤보·라벨은 이것을 쓴다(사용자 지시 「관리자화면에
      등장하는 모든 언어콤보를 **영어로 통일**」). `lang_name` 은 현지어를
      먼저 내므로 관리자 콤보에서 **영어와 현지어가 섞인다** — 실제로 섞였다.
    ⚠ 이름을 여기서 짓지 않는다 — DB 가 이미 `Chinese (Simplified)` ·
      `Chinese (Traditional)` 을 갖고 있다.
    """
    for r in _load():
        if r[0] == code:
            return r[1] or r[2] or code
    return code


def lang_name(code):
    """표시 이름 — 현지어명 우선, 없으면 영문명, 없으면 코드."""
    for r in _load():
        if r[0] == code:
            return r[2] or r[1] or code
    return code


# 내부 언어코드 → YouTube API relevanceLanguage 코드.
# YouTube 는 ISO-639-1(2글자) 또는 zh-Hans/zh-Hant 만 허용 — 'zht' 같은 자체코드는 400 에러.
_RELEVANCE_LANG = {
    'EN': 'en', 'KO': 'ko', 'ZH': 'zh-Hans', 'ZHT': 'zh-Hant', 'JA': 'ja',
    'DE': 'de', 'FR': 'fr', 'ES': 'es', 'PT': 'pt', 'RU': 'ru', 'AR': 'ar',
}


def relevance_lang(code):
    """YouTube search relevanceLanguage 인자용 유효 코드. 미등록은 앞 2글자 폴백."""
    return _RELEVANCE_LANG.get(code, (code or 'en')[:2].lower())


def std_code(code):
    """화면 표시용 국제 표준(BCP-47/ISO-639) 코드. ZH→zh-Hans·ZHT→zh-Hant·기타 소문자 2글자.
    내부 lang_code(ZHT 등)는 불변 — 표시만 표준화(_RELEVANCE_LANG 가 곧 BCP-47 표준값)."""
    return _RELEVANCE_LANG.get(code, (code or '').lower())

# ── 구절약명의 언어 ────────────────────────────────────────────────────────
#
# ★ **구절약명은 표시언어 콤보가 아니라 성경 역본을 따른다** (2026-08-15 사용자 지시).
#   예전에는 화면들이 표시언어를 `book_names.lang_code` 에 그대로 넘겨서,
#   콤보를 English 로 바꾸면 개역한글을 읽고 있어도 `창 1:3` 이 `Gen 1:3` 이 됐다.
#   역본을 바꾸지 않았는데 약명이 바뀌면 어느 성경을 보고 있는지 알 수 없다.
#
# ⚠ `book_names` 가 가진 언어는 11개(AR·DE·EN·ES·FR·JA·KO·PT·RU·ZH·ZHT)뿐이고
#   **EL(헬라어)·HE(히브리어)·COP(콥트어)는 0행**이다. 원문 역본(GNT·WLC·COP*)을
#   고르면 약명을 찾을 수 없다.
#   ⇒ **영어로 떨어뜨린다**(사용자 결정 2026-08-15). 라틴문자 약어는 학술 인용의
#     국제 표준이고, 원문 역본은 다른 언어 본문과 나란히 놓고 보는 것이라
#     약명만 히브리 문자면 오히려 못 맞춘다.
#   ⚠ 히브리어·헬라어 책 이름을 진짜로 넣고 싶으면 `book_names` 에 `HE`·`EL` 행을
#     더한다 — **검증된 출처에서 받아야 한다.** 그러면 이 함수가 자동으로 쓴다.

REF_FALLBACK = 'EN'
_REF_LANG_CACHE = {}


def clear_ref_cache():
    """역본을 바꾸면 부른다."""
    _REF_LANG_CACHE.clear()


def current_version(db_path=None):
    """지금 선택한 성경 역본. **단일 소스 = `user_config['v1_code']`**.

    ⚠ 화면마다 `version_getter` 를 새로 배선하지 않는다 — 역본은 앱 전체에 하나이고
      이미 한 곳에 저장돼 있다. 배선을 늘리면 그중 하나가 반드시 어긋난다.
    """
    try:
        import appdb
        conn = appdb.connect(db_path) if db_path else appdb.connect()
        try:
            r = conn.execute("SELECT config_val FROM user_config "
                             "WHERE config_key='v1_code'").fetchone()
            return (r[0] or '').strip() if r else ''
        finally:
            conn.close()
    except Exception:
        return ''


def ref_lang(version_code=None, db_path=None):
    """그 역본으로 구절약명을 적을 때 쓸 언어. 모르면 영어.

    인자를 안 주면 **지금 고른 역본**을 스스로 찾는다.
    """
    if not version_code:
        version_code = current_version(db_path)
    if not version_code:
        return REF_FALLBACK
    key = str(version_code)
    if key in _REF_LANG_CACHE:
        return _REF_LANG_CACHE[key]
    lang = REF_FALLBACK
    try:
        import appdb
        conn = appdb.connect(db_path) if db_path else appdb.connect()
        try:
            r = conn.execute("SELECT lang_code FROM bible_version WHERE version_code=?",
                             (key,)).fetchone()
            cand = (r[0] or '').upper() if r else ''
            if cand:
                have = conn.execute(
                    "SELECT 1 FROM book_names WHERE UPPER(lang_code)=? LIMIT 1",
                    (cand,)).fetchone()
                if have:
                    lang = cand
        finally:
            conn.close()
    except Exception:
        pass
    _REF_LANG_CACHE[key] = lang
    return lang
