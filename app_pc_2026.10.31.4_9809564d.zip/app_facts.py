# -*- coding: utf-8 -*-
"""app_facts.py — **이 앱에 담긴 것을 센다** (2026-09-06 신설·영구).

★★★ 왜 따로 있나 (0.txt 8-2·8-3 을 만들다 나온 자리):
  「앱소개」와 「이 앱의 라이선스」가 둘 다 **우리가 담은 양**을 말해야 하는데,
  화면마다 세면 두 숫자가 갈린다. 그리고 **손으로 적으면 자라는 앱에서 곧
  거짓이 된다**(§0-1b).

⚠⚠ **덮개(사용자 수정)를 타지 않는다 — 그것이 옳다.**
  여기서 세는 것은 「배포물에 담긴 양」이고 고지·소개의 근거다. 사용자가 제
  화면에서 고치거나 가린 것을 우리 저작량으로 세면 **거짓 고지**가 된다.
  ⇒ `sys_*` 를 직접 읽는 것이 맞고, 그래서 `db_overlay_audit.ALLOWED` 에
    선언한다. **위젯이 하나도 없다**(화면이 아니다).

    python app_facts.py --selftest   (의무)
"""
import io
import sys

DB = 'bible_master.db'

#: 우리가 쓴 글 — (text_type, 사람이 읽을 이름)
#  ⚠ 글의 갈래를 늘리면 여기 한 줄. 화면은 안 고친다.
OUR_TEXT = (('VERS_DESC', '구절 설명문'), ('VERS_QUESTION', '묵상·연구 질문'),
            ('VERS_PRAYER', '묵상 기도'), ('PERI_DESC', '단락 설명문'),
            ('CHAP_DESC', '장 설명문'), ('BOOK_DESC', '책 개요'),
            ('ENTITY_DESC', '주요용어 설명문'),
            ('ENTITY_VERSE_DESC', '용어-구절 연결설명문'),
            ('VERS_VERS_DESC', '구절 연결설명문'),
            ('NODE_DESC', '렌즈묵상 글'))


def _one(conn, q):
    try:
        return conn.execute(q).fetchone()[0] or 0
    except Exception:
        return 0


def our_text(db=DB):
    """우리가 쓴 글 → [(이름, 건수, 글자수)]. 못 읽으면 []."""
    out = []
    try:
        import appdb
        with appdb.connect(db) as conn:
            for tt, name in OUR_TEXT:
                r = conn.execute(
                    "SELECT COUNT(*), COALESCE(SUM(LENGTH(contents)),0)"
                    " FROM sys_text_asset WHERE text_type=?"
                    "   AND COALESCE(record_status,'LIVE')='LIVE'",
                    (tt,)).fetchone()
                if r and r[0]:
                    out.append((name, r[0], r[1]))
    except Exception:
        return []
    return out


def library(db=DB):
    """앱에 담긴 것 → {versions, books, commentaries, verse_notes, plans}."""
    try:
        import appdb
        with appdb.connect(db) as conn:
            return {
                # ⚠ `bible_version` 에는 `record_status` 칸이 없다(실측)
                'versions': _one(conn, "SELECT COUNT(*) FROM bible_version"),
                'books': _one(conn, "SELECT COUNT(*) FROM sys_book_asset"
                                    " WHERE COALESCE(record_status,'LIVE')='LIVE'"),
                'commentaries': _one(conn, "SELECT COUNT(*) FROM sys_commentary_source"),
                'verse_notes': _one(conn, "SELECT COUNT(*) FROM sys_text_asset"
                                          " WHERE text_type='VERS_DESC'"
                                          "   AND COALESCE(record_status,'LIVE')='LIVE'"),
                'plans': _one(conn, "SELECT COUNT(*) FROM sys_bible_plan"
                                    " WHERE COALESCE(record_status,'LIVE')='LIVE'"),
            }
    except Exception:
        return {'versions': 0, 'books': 0, 'commentaries': 0,
                'verse_notes': 0, 'plans': 0}


def selftest():
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', errors='replace')
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    # ★ 위젯을 **import 로** 잰다 — 글자로 세면 이 검사 코드 자신이 걸린다
    #   (실측으로 잡았다. §199차 트레이 클래스 이름과 같은 함정).
    import ast
    src = open(__file__, encoding='utf-8').read()
    mods = set()
    for nd in ast.walk(ast.parse(src)):
        if isinstance(nd, ast.Import):
            mods |= {a.name.split('.')[0] for a in nd.names}
        elif isinstance(nd, ast.ImportFrom) and nd.module:
            mods.add(nd.module.split('.')[0])
    t('★ 화면이 아니다(위젯 0)', 'tkinter' not in mods, sorted(mods))
    rows = our_text()
    t('우리 글을 센다', len(rows) >= 5, len(rows))
    t('건수·글자수가 양수', all(n > 0 and c > 0 for _n, n, c in rows))
    lib = library()
    t('담긴 것 다섯 칸', sorted(lib) == ['books', 'commentaries', 'plans',
                                      'verse_notes', 'versions'])
    t('역본이 있다', lib['versions'] > 0, lib['versions'])
    t('도서가 있다', lib['books'] > 0, lib['books'])
    # ★ 두 문이 같은 것을 세는가 — 갈리면 소개와 고지가 어긋난다
    vd = [c for n, c, _x in rows if n == '구절 설명문']
    t('★ 구절 설명문 건수가 두 문에서 같다',
      not vd or vd[0] == lib['verse_notes'], (vd, lib['verse_notes']))
    # 못 읽어도 안 죽는다
    t('DB 가 없어도 안 죽는다',
      our_text('없는파일.db') == [] and library('없는파일.db')['books'] == 0)
    print('app_facts selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', errors='replace')
    print(library())
    for r in our_text():
        print('  %-22s %8s건 %12s자' % (r[0], format(r[1], ',d'),
                                      format(r[2], ',d')))
