# -*- coding: utf-8 -*-
"""사용자 쪽 「자료 받기」의 **데이터 층** — 무엇을 갖고 있고 무엇이 빠졌나.

★★★ 왜 (2026-09-04 사용자 지시 「**사용자의 설정/다운로드 화면을 고려해서
  개발하라**」 · 「사용자가 이미 다운로드 한 이후 **용량이 부족해서 삭제하고 또
  다시 다운로드 하는 상황**도 고려하라」).
  ⚠⚠ 실측 — 사용자 설정에 **다운로드 탭이 아예 없었다**(7탭: 화면 색·라이선스·
    시작/종료·개인정보·언어·성경 버전·폰트). 무엇을 받았는지, 용량이 얼마인지,
    지우고 다시 받을 길이 **화면에 하나도 없었다.**

★★★ **판정은 커서가 아니라 실물이다.**
  ⚠⚠ 커서(`pack_meta.cursor`)는 「**어디까지 받았다**」이지 「**지금 갖고
    있다**」가 아니다. 용량이 부족해 팩을 지우면 커서만 남아 「이미 최신」이
    되고 **영영 다시 안 받는다**. ⇒ 여기서는 **파일을 열어 실제로 센다**.
  · `have()` — 지금 갖고 있는 것(갈래별 건수 · 파일 크기)
  · `needed()` — 서버가 담았다는 수(`sys_pack_history.expects`)와 견줘 모자란 것
  · `clear()` — 용량 확보용 지우기. **지우면 다시 받을 수 있다**는 것이 요점이라
    커서까지 함께 지운다(커서만 남으면 위 함정에 빠진다).

⚠ 이 모듈은 **읽고 지우는 일만** 한다 — 받는 것은 `tray_agent.fetch_pack_deltas`
  가 이미 하고, 여기서 다시 만들면 두 벌이 된다.
`--selftest`(의무).
"""
import io
import os
import sqlite3
import sys

import link_pack

#: 사용자가 보는 갈래 — `db_pack_history.PACK_PARTS['DELTA']` 와 **짝이다**.
#: ⚠ 갈래를 늘리면 **두 곳**(거기와 여기)을 함께 고친다. 어긋나면 「받아야 할
#:   것」 판정이 조용히 빠진다.
PARTS = (
    ('media', '영상·링크', "SELECT COUNT(*) FROM pack_media"
                          " WHERE COALESCE(record_status,'LIVE')='LIVE'"),
    ('mlink', '구절·용어 연결', "SELECT COUNT(*) FROM pack_link"
                             " WHERE COALESCE(record_status,'LIVE')='LIVE'"),
)


def pack_file(path=None):
    return path or link_pack.pack_path()


def have(path=None):
    """지금 갖고 있는 것 → `{'exists','bytes','cursor','counts':{열쇠:건수}}`.

    ⚠ **파일을 열어 센다** — 커서를 믿지 않는다(위 주석).
    """
    p = pack_file(path)
    out = {'path': p, 'exists': os.path.exists(p), 'bytes': 0,
           'cursor': 0, 'counts': {}}
    if not out['exists']:
        return out
    out['bytes'] = os.path.getsize(p)
    conn = sqlite3.connect(p)
    try:
        for key, _label, q in PARTS:
            try:
                out['counts'][key] = conn.execute(q).fetchone()[0]
            except Exception:
                out['counts'][key] = 0
        try:
            r = conn.execute("SELECT v FROM pack_meta WHERE k='cursor'").fetchone()
            out['cursor'] = int(r[0]) if r and str(r[0]).isdigit() else 0
        except Exception:
            out['cursor'] = 0
    finally:
        conn.close()
    return out


def needed(conn_main, path=None, kind='DELTA'):
    """**받아야 할 것** → `{열쇠: (있어야 할 수, 있는 수)}`. 없으면 빈 dict.

    ★ 판정은 `db_pack_history.missing` 에 위임한다 — 발행 쪽과 받는 쪽이 서로
      다른 규칙을 쓰면 「받았다는데 없다」가 난다.
    ⚠ 관리자 DB(`sys_pack_history`)가 없는 사용자 PC 에서는 잴 수 없다 —
      그때는 **빈 dict**를 돌려주고 화면이 「확인할 수 없음」이라 말한다.
      (서버 manifest 로 재는 길은 다음 걸음이다.)
    """
    try:
        import db_pack_history as PH
    except Exception:
        return {}
    h = have(path)
    if not h['exists']:
        return {}
    try:
        return PH.missing(conn_main, kind, h['counts'])
    except Exception:
        return {}


def releases(timeout=20):
    """서버 manifest 에서 **버전·게시일·달라진 내용** → `(latest, [릴리스…])`.

    ★★★ 사용자 지시 「다운로드 받을 때 **버전, 게시일, 달라진 내용** 등을 알 수
      있게 표시」의 답. 사용자 PC 에는 `sys_pack_history`(관리자 DB)가 **없으므로**
      발행 쪽이 manifest 에 실어 보낸 것을 읽는다(`db_linkpack_build.manifest_body`).
    ⚠ 못 받아도 **죽지 않는다** — 네트워크가 없을 수 있다. `(0, [])` 를 돌려주고
      화면이 「확인할 수 없음」이라 말한다.
    ⚠ 옛 manifest 에는 `releases` 가 없다 — 그때는 버전만 보인다.
    """
    m = manifest(timeout)
    if not m:
        return (0, [])
    return (int(m.get('latest') or 0), list(m.get('releases') or []))


def manifest(timeout=20):
    """서버 manifest 통째로 → dict. 못 받으면 빈 dict.

    ★ `releases`·`core`·`items` 를 읽는 문들이 **이 한 문**을 쓴다 —
      화면마다 따로 받으면 같은 파일을 여러 번 내려받는다.
    """
    try:
        import rss_transport as RT
        import tray_agent as TA
        import db_linkpack_sync as SY
        txt = TA._download(RT.client_servers(), SY.MANIFEST_NAME)
        if not txt:
            return {}
        import json
        return json.loads(txt) or {}
    except Exception:
        return {}


def core_plan(db_path='bible_master.db', man=None):
    """**코어를 어떤 차례로 받아야 하나** → `[{cycle,file,release,bytes,have}]`.

    ★★★ 왜 (2026-09-05 릴리스 패킹) — 코어가 주기별 파일로 갈렸다. 받는 쪽이
      **파일 이름을 짐작하면 안 된다**(주기 배정이 바뀌면 그 순간 어긋난다)
      ⇒ 서버가 manifest 에 실어 보낸 목록을 그대로 읽는다.
    ★★ **차례가 곧 안전장치다** — manifest 의 `core` 는 발행 쪽이
      `db_pack_stat.apply_order`(느린 것부터)로 담았다. 껍데기가 먼저,
      연결이 나중이다. 여기서 다시 정렬하지 않는다.
    ⚠ `have` = 그 주기를 **그 판으로** 이미 받았나. 하나라도 빠지면 코어가
      불완전하다 — 화면이 그것을 말한다(§0-1).
    ⚠ manifest 에 `core` 가 없으면(옛 서버·정비 중) **빈 목록**이다.
      그때는 옛 경로가 그대로 돈다.
    """
    m = man if man is not None else manifest()
    rows = list(m.get('core') or [])
    if not rows:
        return []
    mine = {}
    try:
        c = _cfg(db_path)
        try:
            for k, r in c.execute(
                    "SELECT key, COALESCE(release,0) FROM sys_pack_applied"
                    " WHERE UPPER(kind)='CORE'"):
                mine[str(k).upper()] = int(r or 0)
        finally:
            c.close()
    except Exception:
        mine = {}
    out = []
    for r in rows:
        cy = str(r.get('cycle') or '').upper()
        rel = int(r.get('release') or 0)
        out.append({'cycle': cy, 'file': r.get('file'), 'release': rel,
                    'bytes': int(r.get('bytes') or 0),
                    'have': mine.get(cy, -1) >= rel and cy in mine})
    return out


def core_missing(db_path='bible_master.db', man=None):
    """아직 안 받은 코어 → 같은 모양의 목록(**받을 차례 그대로**)."""
    return [r for r in core_plan(db_path, man) if not r['have']]


def fetch_core(db_path='bible_master.db', man=None, on_step=None):
    """모자란 코어를 **차례대로** 받아 넣는다.

    → `{'ok', 'got':[파일…], 'rows', 'why'}`

    ★★★ 왜 (2026-09-05 6단계) — 코어를 주기별 파일로 갈랐는데 **받는 문이
      없었다**(`fetch_asset` 은 본문팩 하나만 받는다). 만들어 두고 화면이
      안 부르면 없는 것과 같다(§unwired).
    ★★ **순서가 곧 안전장치다** — 껍데기(느린 주기)가 먼저, 연결(빠른 주기)이
      나중이다. `core_plan` 이 이미 그 차례로 주고 `apply_many` 가 한 번 더
      정렬한다(이중으로 막는다).
    ⚠ **하나가 실패해도 나머지는 넣는다** — 하나 때문에 전부 못 받는 것이 더
      나쁘다. 무엇이 실패했는지는 `why` 에 남는다(§0-1 조용한 실패 금지).
    ⚠ 서버에 코어 목록이 없으면(정비 중·옛 서버) **아무 일도 안 한다** —
      `why='NO_CORE_LIST'`. 화면이 그대로 말한다.
    """
    import os as _os
    import tempfile as _tf
    need = core_missing(db_path, man)
    if not need:
        # 목록 자체가 없나, 다 받았나를 가른다 — 사용자에게 뜻이 다르다
        return {'ok': True, 'got': [], 'rows': 0,
                'why': ('' if core_plan(db_path, man) else 'NO_CORE_LIST')}
    try:
        import rss_transport as RT
        import tray_agent as TA
        import db_pack_apply as AP
    except Exception as e:                                    # noqa: BLE001
        return {'ok': False, 'got': [], 'rows': 0, 'why': str(e)[:80]}
    paths, bad = [], []
    tmpd = _tf.mkdtemp(prefix='corepack_')
    try:
        for r in need:                       # ★ 목록이 준 차례 그대로 받는다
            if on_step:
                on_step(r)
            try:
                raw = TA.download_bytes(RT.client_servers(), r['file'])
            except Exception as e:                            # noqa: BLE001
                bad.append('%s: %s' % (r['file'], str(e)[:40]))
                continue
            if not raw:
                bad.append('%s: 서버에 없습니다' % r['file'])
                continue
            p = _os.path.join(tmpd, r['file'])
            with open(p, 'wb') as f:
                f.write(raw)
            paths.append(p)
        rows = 0
        got = []
        for p, res in AP.apply_many(paths, db_path):
            if isinstance(res, str):
                bad.append('%s: %s' % (_os.path.basename(p), res[:50]))
                continue
            got.append(_os.path.basename(p))
            rows += int((res or {}).get('rows') or 0)
    finally:
        try:
            import shutil as _sh
            _sh.rmtree(tmpd, ignore_errors=True)
        except Exception:
            pass
    if got:
        # ★ 짝 맺은 폰이 있으면 그 언어 모바일 코어팩도 함께(mobile_sync.follow_pc_download · 실패해도 PC 팩은 그대로)
        try:
            import mobile_sync
            mobile_sync.follow_pc_download(db_path)
        except Exception:                                     # noqa: BLE001
            pass
    return {'ok': (not bad), 'got': got, 'rows': rows,
            'why': '; '.join(bad[:3])}


def pack_thumbs(pack, cache={}):
    """그 사진 팩의 **샘플 썸네일** → `[{img_id,name,scene,png(bytes)}]`.

    ★★★ 왜 (2026-09-05 사용자 지시 「선택한 팩 내부의 **샘플사진의 썸네일**을
      볼 수 있도록」) — 팩을 **받기 전에** 무엇이 들었는지 봐야 고를 수 있다.
    ⚠ **manifest 와 따로** 받는다(`splash_thumbs.json`) — 사진 팩 갈래를
      눌렀을 때만 받으므로 다른 화면이 느려지지 않는다.
    ⚠ 한 번 받으면 **캐시**한다(같은 파일을 갈래를 누를 때마다 받지 않는다).
    ⚠ 못 받으면 **빈 목록** — 화면이 「미리보기를 받을 수 없습니다」라 말한다.
    """
    import base64
    if 'body' not in cache:
        try:
            import rss_transport as RT
            import tray_agent as TA
            import db_splash_scene as SC
            txt = TA._download(RT.client_servers(), SC.THUMBS_NAME)
            import json
            cache['body'] = json.loads(txt) if txt else {}
        except Exception:
            cache['body'] = {}
    rows = ((cache.get('body') or {}).get('packs') or {}).get(pack) or []
    out = []
    for r in rows:
        try:
            out.append({'img_id': r.get('img_id'), 'name': r.get('name') or '',
                        'scene': r.get('scene') or '',
                        'png': base64.b64decode(r.get('png') or '')})
        except Exception:
            continue
    if out:
        return out
    # ★★ **서버를 못 읽으면 내 DB 에서 본다** — 이미 받은 팩(또는 관리자 PC)
    #   에는 썸네일이 그대로 있다. 있는 것을 두고 「없습니다」라고 하지 않는다.
    try:
        import appdb
        import db_splash_scene as SC
        c = appdb.connect('bible_master.db')
        try:
            b = SC.thumbs_body(c)
        finally:
            c.close()
        for r in (b.get('packs') or {}).get(pack) or []:
            out.append({'img_id': r.get('img_id'), 'name': r.get('name') or '',
                        'scene': r.get('scene') or '', 'local': True,
                        'png': base64.b64decode(r.get('png') or '')})
    except Exception:
        pass
    return out


#: 항목 상태 — 사용자 지시 「**설치됨/삭제됨/미설치**로 구분하자」.
ST_INSTALLED, ST_REMOVED, ST_NEW = 'INSTALLED', 'REMOVED', 'NEW'

# ── 판 표기 — 앱 전체가 이 한 문만 쓴다 ────────────────────────────────
# 2026-09-07 사용자 지시: 「버전표시방법 통일 : 앱의 모든 화면/목록 등에서
#   **한 가지 방식으로 통일**한다. **예외적으로 편리를 위해 다국어 모드를
#   제거하자.** 예) 1판, Ver 1 ... **금지한다**」
#
# ★ 축이 둘이라 **글자로 가른다** — 섞으면 「4판인데 2판」이라는 말이 된다:
#     R-4   릴리스(Release) — 코어와 함께 오르는 앱 전체의 판
#     A-2   자산(Asset)     — 그 자산 하나의 판
# ★ **다국어를 안 태운다**(사용자 지시) — 어느 언어에서나 같은 글자라야
#   사용자·관리자·화면이 같은 것을 말한다.
# ⚠ **릴리스 번호를 자산 표기에 넣지 않는다** — 릴리스가 올라도 그 자산이
#   안 바뀌었으면 이름이 바뀌면 안 된다(`A-4-2` 꼴을 버린 까닭).
VER_A, VER_R = 'A', 'R'


def ver_label(n, kind=VER_A):
    """판 하나를 적는다 — `A-2` · `R-4`. 모르면 빈 글자(**지어내지 않는다**)."""
    try:
        n = int(n or 0)
    except (TypeError, ValueError):
        return ''
    return ('%s-%d' % (kind, n)) if n > 0 else ''


def ver_arrow(mine, new, kind=VER_A):
    """내 판 → 최신 판. 같거나 모르면 하나만 적는다."""
    a, b = ver_label(mine, kind), ver_label(new, kind)
    if a and b and a != b:
        return '%s → %s' % (a, b)
    return b or a


# ── 5분류 — 「받을 필요가 있나」를 한 낱말로 ───────────────────────────
# 2026-09-07 사용자 지시(0.txt 1·2-1): 라디오 배치
#   전체 / 최신판 / 업그레이드 가능 / 다운로드 가능 / 미발행  (+ 삭제됨)
CL_LATEST = 'LATEST'      # 받았고 최신
CL_UPGRADE = 'UPGRADE'    # 받았는데 옛 판 — 받을 것이 있다
CL_AVAIL = 'AVAIL'        # 안 받음 · 서버에 있다
CL_UNPUB = 'UNPUB'        # 아직 발행 안 됨 — 받을 수 없다
CL_REMOVED = 'REMOVED'    # 받았다 지웠다
CLASSES = (CL_LATEST, CL_UPGRADE, CL_AVAIL, CL_UNPUB, CL_REMOVED)


def item_class(item, state=None):
    """자산 하나를 다섯 갈래로 가른다.

    ★ **「삭제됨」을 따로 둔다**(2026-09-07 사용자 「읽고 난 후에 삭제했다면
      의미가 크다」) — 「한 번도 안 받은 것」과 뜻이 전혀 다르다.
    ⚠ **판을 모르면 「미발행」이다** — 서버 목록에 판이 없으면 받을 길이 없다.
      0 을 「1판」으로 지어내면 눌러도 아무 일이 없는 단추가 된다(§0-1).
    """
    it = item or {}
    st = state or it.get('state')
    new = int(it.get('version') or it.get('own_version') or 0)
    mine = int(it.get('mine') or 0)
    if st == ST_REMOVED:
        return CL_REMOVED
    if st == ST_INSTALLED:
        # ⚠ 서버 판을 모르면 최신인지 알 수 없다 — 갖고 있으니 최신으로 본다
        return CL_UPGRADE if (new and mine and mine < new) else CL_LATEST
    return CL_AVAIL if new > 0 else CL_UNPUB

#: 「지웠다」를 적어 두는 자리. ⚠ 파일이 없어진 것만으로는 **한 번도 안 받은
#:  것**과 **받았다 지운 것**을 가릴 수 없다 — 사용자에게는 전혀 다른 뜻이다.
SEEN_KEY = 'PACK_SEEN_MAX'


def _cfg(db_path='bible_master.db'):
    import appdb
    return appdb.connect(db_path)


def seen_max(db_path='bible_master.db'):
    """**한 번이라도 받아 본 가장 높은 판**. 지워도 남는다."""
    try:
        c = _cfg(db_path)
        try:
            r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                          (SEEN_KEY,)).fetchone()
        finally:
            c.close()
        return int(r[0]) if r and str(r[0]).isdigit() else 0
    except Exception:
        return 0


def note_seen(seq, db_path='bible_master.db'):
    """받은 판을 기록한다(내려가지 않는다)."""
    try:
        cur = seen_max(db_path)
        if int(seq or 0) <= cur:
            return cur
        c = _cfg(db_path)
        try:
            c.execute("INSERT OR REPLACE INTO user_config(config_key, config_val)"
                      " VALUES(?,?)", (SEEN_KEY, str(int(seq))))
            c.commit()
        finally:
            c.close()
        return int(seq)
    except Exception:
        return seen_max(db_path)


#: 마지막으로 받은 때·그때 건수. ⚠ 「오늘 새로 받은 것」을 세려면 **어제 값을
#:  기억해야** 한다 — 지금 건수만으로는 오늘 얼마나 늘었는지 알 수 없다.
GET_KEY = 'PACK_LAST_GET'


def note_get(counts, db_path='bible_master.db'):
    """받은 때와 그때 건수를 적는다 → `{'at','counts'}`."""
    import json
    import time
    rec = {'at': time.strftime('%Y-%m-%d %H:%M'),
           'day': time.strftime('%Y-%m-%d'),
           'counts': dict(counts or {})}
    prev = _get_json(GET_KEY, db_path) or {}
    # ★ 하루가 바뀌면 **그날 시작 건수**를 새로 박는다(오늘 증가분의 기준)
    if prev.get('day') != rec['day']:
        rec['day_base'] = dict(prev.get('counts') or {})
    else:
        rec['day_base'] = dict(prev.get('day_base') or prev.get('counts') or {})
    try:
        c = _cfg(db_path)
        try:
            c.execute("INSERT OR REPLACE INTO user_config(config_key, config_val)"
                      " VALUES(?,?)", (GET_KEY, json.dumps(rec, ensure_ascii=False)))
            c.commit()
        finally:
            c.close()
    except Exception:
        pass
    return rec


def _get_json(key, db_path='bible_master.db'):
    import json
    try:
        c = _cfg(db_path)
        try:
            r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                          (key,)).fetchone()
        finally:
            c.close()
        return json.loads(r[0]) if r and r[0] else None
    except Exception:
        return None


def last_get(db_path='bible_master.db'):
    """마지막으로 받은 때(글자) 또는 None."""
    r = _get_json(GET_KEY, db_path) or {}
    return r.get('at')


def today_added(db_path='bible_master.db', path=None):
    """**오늘 새로 받은 건수** 또는 None(오늘 받은 적이 없으면).

    ⚠ 지금 건수 − 오늘 시작 건수. 기록이 없으면 **지어내지 않고 None**.
    """
    import time
    r = _get_json(GET_KEY, db_path) or {}
    if r.get('day') != time.strftime('%Y-%m-%d'):
        return None
    base = r.get('day_base') or {}
    now = have(path)['counts']
    tot = 0
    for k in set(list(base) + list(now)):
        tot += int(now.get(k) or 0) - int(base.get(k) or 0)
    return max(0, tot)


def schedule_label(db_path='bible_master.db'):
    """받는 주기·시각 → `(주기 글자, 시각 글자|None)`.

    ⚠ 설정을 못 읽어도 죽지 않는다 — 기본값(하루 한 번)을 말한다.
    """
    try:
        import sync_schedule as SS
        c = _cfg(db_path)
        try:
            per = SS.period(c)
            win = SS.window(c)
            sec = SS.slot_sec(SS.seed(c), win)
        finally:
            c.close()
        pl = {'DAILY': None}.get(per)
        return (per, '%02d:%02d' % (sec // 3600, (sec % 3600) // 60))
    except Exception:
        return (None, None)


def _pick_pack(kind, key, lang=None, variant=None,
               db_path='bible_master.db'):
    """받을 수 있는 **(언어, 변형)** 짝을 선택한다 → `(언어, 변형, 바꿨나)`.

    ★★★ 왜 (2026-09-04 ⑪ 실측으로 두 번 잡았다):
      ① 폴백 화면은 **표시 언어**(KO)를 넘기는데 그 자산은 EN 팩뿐일 수 있다.
      ② 도서 팩 이름은 `pack_BOOK_X_KO_TRANSLATED` 라 **변형까지** 맞아야
         찾는다 — `'-'` 로 고정하면 도서를 **영영 못 받는다**.
      ⇒ 목록(`assets`)이 정한다. 요청과 다르면 **바꿔 받았다고 알린다**.
    ⚠ 고르는 차례 — ⓐ 요청 (언어,변형) ⓑ 요청 언어의 아무 변형
      ⓒ 있는 것 아무거나. ⓑ·ⓒ 는 `sub=True` 로 알린다.
    ⚠ 목록을 못 읽으면 **요청 그대로**(지금까지의 동작 — 안 깨진다).
    """
    dash = lambda v: '-' if (v or '-') == '-' else v          # noqa: E731
    try:
        k = (kind or '').upper()
        cand = [x for x in assets(db_path)
                if (x.get('kind') or '').upper() == k
                and str(x.get('key') or '') == str(key)]
    except Exception:
        cand = []
    if not cand:
        return dash(lang), dash(variant), False
    wl, wv = (lang or '-').upper(), (variant or '-').upper()
    pairs = [((x.get('lang') or '-'), (x.get('variant') or '-'))
             for x in cand]
    for l, v in pairs:                                  # ⓐ 그대로
        if (l or '-').upper() == wl and (v or '-').upper() == wv:
            return l, v, False
    for l, v in pairs:                                  # ⓑ 그 언어의 아무 변형
        if (l or '-').upper() == wl:
            return l, v, variant is not None and wv != (v or '-').upper()
    return pairs[0][0], pairs[0][1], True               # ⓒ 있는 것


def fetch_asset(kind, key, lang=None, db_path='bible_master.db',
                variant=None):
    """자산 하나를 서버에서 받아 붙인다 → `{'ok','rows','why'}`.

    ★★★ **받는 문은 하나다**(2026-09-04 ⑪) — 다운로드 화면과 폴백 화면이
      이것을 함께 부른다. 두 곳에 쓰면 「한쪽은 표식을 떼고 한쪽은 안 떼는」
      어긋남이 난다(오늘만 두 번 겪은 「문이 둘」 문제).
    ⚠ **여기서 묻지 않는다** — 확인 상자·알림은 화면의 몫이다(데이터 층이
      `messagebox` 를 부르면 하네스에서 멈춘다).
    ⚠ **왜 안 되는지 돌려준다**(`why`) — 조용히 실패하지 않는다(§0-1).
    """
    import os
    import tempfile
    try:
        import db_pack_body as PB
        import db_pack_apply as AP
        import rss_transport as RT
        import tray_agent as TA
    except Exception as e:                                    # noqa: BLE001
        return {'ok': False, 'rows': 0, 'why': str(e)[:80]}
    # ★★★ **어느 언어 팩을 받을지 목록이 정한다**(2026-09-04 ⑪ 실측으로 잡음).
    #   ⚠⚠ 폴백 화면은 **표시 언어**(KO)를 넘기는데 그 자산은 EN 팩뿐일 수
    #     있다 — 그대로 받으러 가면 **늘 「서버에 없다」**가 된다. 실제로 그랬다.
    #   ⇒ 요청 언어가 목록에 있으면 그것을, 없으면 **있는 것**을 받고
    #     **바꿔 받았다고 알린다**(`sub=True`). 조용히 바꾸지 않는다.
    lg, vr, sub = _pick_pack(kind, key, lang, variant, db_path)
    fn = PB.pack_name(kind, key, lg, vr)
    try:
        raw = TA.download_bytes(RT.client_servers(), fn)
    except Exception as e:                                    # noqa: BLE001
        return {'ok': False, 'rows': 0, 'why': str(e)[:80]}
    if not raw:
        return {'ok': False, 'rows': 0, 'why': 'NOT_ON_SERVER',
                'lang': lg, 'variant': vr}
    tmp = os.path.join(tempfile.gettempdir(), fn)
    try:
        with open(tmp, 'wb') as f:
            f.write(raw)
        r = AP.apply_pack(tmp, db_path)
    except Exception as e:                                    # noqa: BLE001
        return {'ok': False, 'rows': 0, 'why': str(e)[:80]}
    finally:
        try:
            os.remove(tmp)
        except Exception:
            pass
    try:
        mark_removed(kind, key, lang, on=False, db_path=db_path)
    except Exception:
        pass
    n = r.get('rows') if isinstance(r, dict) else r
    return {'ok': True, 'rows': int(n or 0), 'why': '',
            'lang': lg, 'variant': vr, 'sub': sub}


RM_KEY = 'PACK_REMOVED'


def _rm_load(db_path='bible_master.db'):
    """지운 자산 목록 → `set('KIND|KEY|LANG')`."""
    import json
    try:
        c = _cfg(db_path)
        try:
            r = c.execute("SELECT config_val FROM user_config"
                          " WHERE config_key=?", (RM_KEY,)).fetchone()
        finally:
            c.close()
        return set(json.loads(r[0])) if r and r[0] else set()
    except Exception:
        return set()


def _rm_save(items, db_path='bible_master.db'):
    import json
    try:
        c = _cfg(db_path)
        try:
            c.execute("INSERT OR REPLACE INTO user_config(config_key,"
                      " config_val) VALUES(?,?)",
                      (RM_KEY, json.dumps(sorted(items))))
            c.commit()
        finally:
            c.close()
    except Exception:
        pass


def rm_key(kind, key, lang=None):
    return '%s|%s|%s' % ((kind or '').upper(), key or '-',
                         (lang or '-').upper())


def mark_removed(kind, key, lang=None, on=True,
                 db_path='bible_master.db'):
    """지웠다/되받았다를 기록한다.

    ★★★ 왜 (2026-09-04 사용자 지시 「**삭제해도 "삭제됨"이라고 표시**해야
      한다. **설치됨/삭제됨/미설치로 구분**하자」).
      ⚠⚠ **실물만 봐서는 「한 번도 안 받았다」와 「받았다 지웠다」를 못 가른다**
        — 둘 다 행이 0 이다. 그 둘은 사용자에게 전혀 다른 뜻이라
        (하나는 새것, 하나는 내가 지운 것) **기록이 있어야** 갈린다.
    ⚠ 되받으면 **표식을 뗀다** — 안 떼면 갖고 있는데 「삭제됨」이라 말한다.
    """
    st = _rm_load(db_path)
    k = rm_key(kind, key, lang)
    if on:
        st.add(k)
    else:
        st.discard(k)
    _rm_save(st, db_path)
    return len(st)


def assets(db_path='bible_master.db', man=None):
    """**받을 수 있는 자산 + 내 상태** → `[{kind,key,lang,…,'state'}]`.

    ⚠ `man` 을 주면 **서버를 다시 안 읽는다** — 한 화면에서 이 문과
      `core_missing` 을 함께 부르면 manifest 를 **두 번** 받는다(실측
      1,845ms 중 대부분이 그것이다).

    ★★★ 왜 (2026-09-04 ⑩) — 그전 화면은 **내가 이미 가진 것만** 보였다.
      무엇을 더 받을 수 있는지 알 길이 없었다. 서버 manifest 의 `items` 가
      「받을 수 있는 것」이고 여기서 **내 실물과 대조**해 상태를 붙인다.
    ⚠ 상태 판정은 **`pack_fallback.state` 한 문**에 맡긴다 — 폴백 화면과 다른
      규칙을 쓰면 「목록엔 설치됨인데 본문은 안 받았다고 나오는」 어긋남이 난다.
    ⚠ 서버를 못 읽으면 **빈 목록** — 화면이 「확인할 수 없음」이라 말한다.
    """
    if man is not None:
        items = list((man or {}).get('items') or [])
    else:
        try:
            import rss_transport as RT
            import tray_agent as TA
            import db_linkpack_sync as SY
            import json
            txt = TA._download(RT.client_servers(), SY.MANIFEST_NAME)
            items = list((json.loads(txt) if txt else {}).get('items') or [])
        except Exception:
            items = []
    if not items:
        # 관리자 PC 라면 원본이 있다(사용자 PC 에는 없어 그냥 빈 목록)
        try:
            import db_pack_item as PI
            c = _cfg(db_path)
            try:
                # ⚠ **독자판만 오른 자산도 목록에 낸다**(2026-09-05) —
                #   본문만 있는 자산(사진 팩)은 `own_version` 만 오른다.
                items = [x for x in PI.items(c)
                         if x.get('version') or x.get('own_version')]
            finally:
                c.close()
        except Exception:
            items = []
    if not items:
        return []
    # ⚠ 관리자 폴백은 `sqlite3.Row`(또는 튜플)를 낼 수 있다 — `.get()` 이
    #   없어 그대로 쓰면 조용히 죽는다(실측으로 잡았다). **dict 로 맞춘다.**
    items = [x if isinstance(x, dict) else dict(x) for x in items]
    try:
        import pack_fallback as FB
        c = _cfg(db_path)
        try:
            for it in items:
                lang = it.get('lang')
                # ⚠ **목록은 엄격 잣대**(`strict`) — 「팩 본문을 받았나」다.
                #   관대하게 재면 지운 것을 「설치됨」이라 말한다.
                it['state'] = FB.state(c, it.get('kind'), it.get('key'),
                                       None if lang in (None, '-') else lang,
                                       strict=True)
        finally:
            c.close()
    except Exception:
        for it in items:
            it['state'] = ''
    # ★ **지운 것은 「삭제됨」으로** — 실물이 없다는 점은 미설치와 같지만
    #   사용자에게는 다른 뜻이다(내가 지운 것 ↔ 아직 안 받은 것).
    rm = _rm_load(db_path)
    if rm:
        for it in items:
            if it.get('state') != 'OK' and rm_key(
                    it.get('kind'), it.get('key'), it.get('lang')) in rm:
                it['removed'] = True
    # ★★★ **내 판을 함께 낸다** (2026-09-06 사용자 지시 「**항목별 버전상태
    #   표시하지 않으면 다운로드 필요성을 모른다.** 표시하라」).
    #   ⚠ 그전에는 `version`(서버 최신)만 냈다 — **갖고 있는 것과 같은지**를
    #     화면이 말할 수 없어 「받을 필요가 있나」를 판단할 수 없었다.
    mine = mine_versions(db_path)
    for it in items:
        lg = (it.get('lang') or '')
        it['mine'] = mine.get((str(it.get('kind') or '').upper(),
                               str(it.get('key') or ''),
                               '' if lg in ('-', None) else lg.upper()))
    return items


def mine_versions(db_path='bible_master.db'):
    """**내가 받은 판** → `{(유형, 열쇠, 언어): 판}`.

    ★ 근거는 `sys_pack_applied` — 적재기가 남기는 기록이다.
    ⚠ **판 칸이 없으면 아무것도 안 낸다**(빈 dict). 옛 DB 에는 그 칸이 없고,
      **모르는 것을 0 으로 내면 「받았는데 0 판」이라는 거짓말**이 된다.
      화면은 판을 모를 때 「받음」만 적는다(§0-1b 지어내지 않는다).
    ⚠ 언어가 `-` 인 자산(성경·주석)은 빈 글자로 맞춘다 — `assets` 의 열쇠와
      같은 규칙이라야 짝이 맞는다.
    """
    out = {}
    try:
        c = _cfg(db_path)
        try:
            cols = [r[1] for r in c.execute(
                'PRAGMA table_info(sys_pack_applied)')]
            if 'version' not in cols:
                return {}
            for k, key, lg, v in c.execute(
                    "SELECT kind, key, COALESCE(lang,''),"
                    " COALESCE(version,0) FROM sys_pack_applied"):
                if not v:
                    continue
                out[(str(k).upper(), str(key),
                     '' if lg == '-' else str(lg).upper())] = int(v)
        finally:
            c.close()
    except Exception:
        return {}
    return out


def _board_lang(r):
    """그 판의 안내문을 **사용자 언어로** 선택한다 → `{title,detail,caution}`.

    ★ manifest 의 `title/detail/caution` 은 **기준 언어**이고 다른 언어는
      `i18n` 에 담겨 온다(282차 ①).
    ⚠ 그 언어가 없으면 **기준 언어를 그대로 쓴다** — 빈 화면을 내지 않는다.
    ⚠ 옛 manifest 에는 `i18n` 이 없다 — 그때는 지금까지와 똑같이 돈다.
    """
    base = {'title': r.get('title') or '', 'detail': r.get('detail') or '',
            'caution': r.get('caution') or ''}
    box = r.get('i18n') or {}
    if not isinstance(box, dict) or not box:
        return base
    try:
        import i18n as _I
        lg = str(_I.get_lang() or '').upper()
    except Exception:                                        # noqa: BLE001
        lg = ''
    got = box.get(lg)
    if not isinstance(got, dict):
        return base
    # ⚠ **칸마다 따로 물러선다** — 제목만 옮긴 판에서 본문까지 비우면 안 된다.
    return {k: (got.get(k) or base[k]) for k in base}


def catalog(db_path='bible_master.db', path=None):
    """**받을 수 있는 것 전부 + 내 상태** → `[{…, 'state': …}]`.

    ★★★ **다운로드/삭제와 무관하게 늘 나온다** (2026-09-04 사용자 지시 —
      「지금은 다운로드 받고 삭제하면 목록이 사라진다. 그러면 **다음에 어떻게
      다시 다운로드 받는가**? … 삭제해도 **「삭제됨」이라고 표시**해야 한다」).
    ★ 상태 셋 — `INSTALLED`(지금 갖고 있다) · `REMOVED`(받았다 지웠다) ·
      `NEW`(아직 안 받았다). **파일 유무만으로는 뒤 둘을 못 가린다** ⇒
      「한 번이라도 받아 본 판」(`seen_max`)을 따로 적어 둔다.
    ⚠ 서버가 안 되면 **관리자 DB 라도 읽는다** — 관리자 PC 에서는 그것이 원본이고,
      사용자 PC 에는 그 표가 없어 그냥 빈 목록이 된다(죽지 않는다).
    """
    items = []
    _lat, rel = releases()
    for r in rel:
        b = _board_lang(r)
        items.append({'seq': r.get('seq') or 0, 'made_at': r.get('made_at') or '',
                      'note': r.get('note') or '', 'title': b['title'],
                      'detail': b['detail'],
                      'caution': b['caution'],
                      'n_items': r.get('n_items'), 'bytes': r.get('bytes'),
                      'kind': r.get('kind') or 'DELTA'})
    if not items:
        try:
            import db_pack_history as PH
            c = _cfg(db_path)
            try:
                items = PH.catalog(c)
            finally:
                c.close()
        except Exception:
            items = []
    h = have(path)
    cur = h['cursor'] if h['exists'] else 0
    seen = max(seen_max(db_path), cur)
    for it in items:
        s = int(it.get('seq') or 0)
        if h['exists'] and s <= cur:
            it['state'] = ST_INSTALLED
        elif s <= seen:
            it['state'] = ST_REMOVED
        else:
            it['state'] = ST_NEW
    items.sort(key=lambda x: (x.get('made_at') or '', x.get('seq') or 0),
               reverse=True)
    return items


def clear(path=None):
    """받은 자료를 **지운다**(용량 확보) → 지운 바이트.

    ★★★ **커서까지 함께 지운다** — 커서만 남으면 「이미 최신」으로 판정돼
      **영영 다시 안 받는다**(사용자가 겪을 그 상황).
    ⚠ **본체(`bible_master.db`)와 내 자료(`user_data.db`)는 안 건드린다** —
      이 파일은 배포로 받은 것뿐이라 지워도 다시 받으면 그대로 돌아온다.
    ⚠ 앱이 팩을 붙여 둔 채면 파일이 잠긴다 — 부르는 쪽이 `detach` 를 먼저 한다.
    """
    p = pack_file(path)
    if not os.path.exists(p):
        return 0
    n = os.path.getsize(p)
    for suffix in ('-wal', '-shm', ''):
        f = p + suffix
        try:
            if os.path.exists(f):
                os.remove(f)
        except Exception:
            pass
    return 0 if os.path.exists(p) else n


def human(nbytes):
    """사람이 읽는 용량. ⚠ 0 은 「0 B」 — 빈 글자를 돌려주면 화면이 빈다."""
    n = float(nbytes or 0)
    for unit in ('B', 'KB', 'MB', 'GB'):
        if n < 1024 or unit == 'GB':
            return '%.0f %s' % (n, unit) if unit == 'B' else '%.1f %s' % (n, unit)
        n /= 1024
    return '%.1f GB' % n


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def selftest():
    import tempfile
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', name, extra))

    d = tempfile.mkdtemp()
    p = os.path.join(d, 'test_pack.db')

    h = have(p)
    t('★ 팩이 없으면 없다고 한다', h['exists'] is False and h['bytes'] == 0)
    t('  없어도 안 죽는다', h['counts'] == {} and h['cursor'] == 0)
    t('  없는 것을 지워도 안 죽는다', clear(p) == 0)

    c = sqlite3.connect(p)
    c.executescript("""
      CREATE TABLE pack_media(media_id INTEGER, record_status TEXT);
      CREATE TABLE pack_link(link_type TEXT, record_status TEXT);
      CREATE TABLE pack_meta(k TEXT, v TEXT);
      INSERT INTO pack_media VALUES(1,'LIVE'),(2,'LIVE'),(3,'DELETED');
      INSERT INTO pack_link VALUES('MEDI_VERS','LIVE'),('MEDI_ENTI','LIVE');
      INSERT INTO pack_meta VALUES('cursor','3');
    """)
    c.commit()
    c.close()

    h = have(p)
    t('갖고 있는 것을 센다', h['exists'] and h['bytes'] > 0)
    t('★ 묘비는 안 센다', h['counts'].get('media') == 2,
      str(h['counts'].get('media')))
    t('  링크도 센다', h['counts'].get('mlink') == 2)
    t('  커서를 읽는다', h['cursor'] == 3, str(h['cursor']))

    # 받아야 할 것 — 발행 쪽 기록과 견준다
    m = sqlite3.connect(':memory:')
    import db_pack_history as PH
    PH.init(m)
    import json as _j
    PH.record(m, 'DELTA', '2026-09-04', n_items=2)
    m.execute("UPDATE sys_pack_history SET expects=? WHERE seq=1",
              (_j.dumps({'media': 2, 'mlink': 2}),))
    m.commit()
    t('★★ 다 있으면 받을 것이 없다', needed(m, p) == {}, str(needed(m, p)))
    m.execute("UPDATE sys_pack_history SET expects=? WHERE seq=1",
              (_j.dumps({'media': 2, 'mlink': 99}),))
    m.commit()
    nd = needed(m, p)
    t('★★★ **한 갈래만 지워도 잡는다**(용량 부족 삭제)',
      nd == {'mlink': (99, 2)}, str(nd))

    # 지우기 — 커서까지 사라져야 다시 받는다
    n = clear(p)
    t('★ 지우면 용량을 돌려준다', n > 0, human(n))
    t('★★★ **지운 뒤엔 커서도 없다**(다시 받을 수 있다)',
      have(p)['cursor'] == 0 and not have(p)['exists'])
    t('  지운 뒤 판정은 「모름」', needed(m, p) == {})
    m.close()

    # ── 카탈로그 · 상태 셋 ───────────────────────────────────────────────
    # ⚠ **실 DB 에 안 쓴다** — `user_config` 를 건드리지 않도록 함수를 갈아 끼운다
    import json as _js
    import time as _tm
    store = {}
    _orig_get, _orig_seen, _orig_note = _get_json, seen_max, note_seen
    globals()['_get_json'] = lambda k, d='x': store.get(k)
    globals()['seen_max'] = lambda d='x': int(store.get(SEEN_KEY) or 0)
    globals()['note_seen'] = lambda s, d='x': store.__setitem__(SEEN_KEY, int(s))
    globals()['releases'] = lambda timeout=20: (3, [
        {'seq': 1, 'made_at': '2026-09-01', 'note': 'a', 'kind': 'DELTA'},
        {'seq': 2, 'made_at': '2026-09-02', 'note': 'b', 'kind': 'DELTA'},
        {'seq': 3, 'made_at': '2026-09-03', 'note': 'c', 'kind': 'DELTA'}])
    try:
        cat = catalog(path=p)          # 팩이 지워진 상태 · 본 적도 없다
        t('★ 카탈로그는 **팩이 없어도 나온다**', len(cat) == 3, str(len(cat)))
        t('★★ 날짜순 **최근이 위**',
          [x['seq'] for x in cat] == [3, 2, 1], str([x['seq'] for x in cat]))
        t('  한 번도 안 받았으면 미설치',
          all(x['state'] == ST_NEW for x in cat))
        store[SEEN_KEY] = 3
        cat = catalog(path=p)
        t('★★★ **받았다 지우면 「삭제됨」**(미설치와 다르다)',
          all(x['state'] == ST_REMOVED for x in cat),
          str([x['state'] for x in cat]))
        # 팩을 되살리면 설치됨
        c3 = sqlite3.connect(p)
        c3.executescript("""
          CREATE TABLE pack_media(media_id INTEGER, record_status TEXT);
          CREATE TABLE pack_link(link_type TEXT, record_status TEXT);
          CREATE TABLE pack_meta(k TEXT, v TEXT);
          INSERT INTO pack_media VALUES(1,'LIVE');
          INSERT INTO pack_link VALUES('MEDI_VERS','LIVE');
          INSERT INTO pack_meta VALUES('cursor','2');
        """)
        c3.commit()
        c3.close()
        # ⚠ **`seen` 을 함께 낮춘다** — 3판을 본 적이 있으면 그것은 「삭제됨」이
        #   맞다(코드가 옳다). 「아직 안 받은 새 판」을 재려면 본 적이 없어야 한다.
        store[SEEN_KEY] = 2
        cat = catalog(path=p)
        got = {x['seq']: x['state'] for x in cat}
        t('★★ **커서까지는 설치됨, 안 받은 새 판은 미설치**',
          got[1] == ST_INSTALLED and got[2] == ST_INSTALLED
          and got[3] == ST_NEW, str(got))
        store[SEEN_KEY] = 3
        t('★ 본 적 있는 판은 커서를 넘어도 「삭제됨」',
          {x['seq']: x['state'] for x in catalog(path=p)}[3] == ST_REMOVED)
        # 오늘 새로 받은 것
        store[GET_KEY] = {'at': '2026-09-04 10:00',
                          'day': _tm.strftime('%Y-%m-%d'),
                          'counts': {'media': 1, 'mlink': 1},
                          'day_base': {'media': 0, 'mlink': 0}}
        t('★ 오늘 받은 것을 센다', today_added(path=p) == 2,
          str(today_added(path=p)))
        t('  마지막으로 받은 때를 낸다', last_get() == '2026-09-04 10:00')
        store[GET_KEY] = dict(store[GET_KEY], day='2000-01-01')
        t('★ 어제 것이면 **오늘은 없다고 한다**(지어내지 않는다)',
          today_added(path=p) is None)
        os.remove(p)
    finally:
        globals()['_get_json'] = _orig_get
        globals()['seen_max'] = _orig_seen
        globals()['note_seen'] = _orig_note
        globals()['releases'] = releases

    t('용량 표기 — 0 도 글자가 있다', human(0) == '0 B', human(0))
    t('  KB·MB 로 접는다',
      human(2048) == '2.0 KB' and human(3 * 1024 * 1024) == '3.0 MB',
      '%s / %s' % (human(2048), human(3 * 1024 * 1024)))

    # ★ 발행 쪽과 갈래가 어긋나면 판정이 조용히 샌다
    parts_here = {k for k, _l, _q in PARTS}
    parts_there = {k for k, _l, _q in PH.PACK_PARTS['DELTA']}
    t('★★ 발행 쪽과 갈래 열쇠가 같다', parts_here == parts_there,
      '%s / %s' % (sorted(parts_here), sorted(parts_there)))

    try:
        os.rmdir(d)
    except Exception:
        pass
    # ── 코어 주기 목록(2026-09-05 릴리스 패킹) ───────────────────────
    MAN = {'core': [
        {'cycle': 'BIANNUAL', 'file': 'corepack_BIANNUAL.json.gz',
         'release': 4, 'bytes': 100},
        {'cycle': 'DAILY', 'file': 'corepack_DAILY.json.gz',
         'release': 4, 'bytes': 10}]}
    pl = core_plan(man=MAN)
    t('★★★ **코어를 주기별로 받는다**', len(pl) == 2, str([x['cycle'] for x in pl]))
    t('★★★ **차례는 서버가 정한 그대로**(느린 것부터 · 여기서 다시 정렬 안 한다)',
      [x['cycle'] for x in pl] == ['BIANNUAL', 'DAILY'])
    t('★★ **파일 이름을 짐작하지 않는다**(목록이 짓는다)',
      pl[0]['file'] == 'corepack_BIANNUAL.json.gz')
    t('★★★ **안 받은 것은 안 받았다고 한다**',
      len(core_missing(man=MAN)) == 2, '%d개' % len(core_missing(man=MAN)))
    t('  옛 서버(core 없음)면 빈 목록 — 옛 경로가 그대로 돈다',
      core_plan(man={}) == [])
    t('★★ **manifest 를 못 받아도 안 죽는다**', isinstance(manifest(0), dict))

    # 코어 받기 — 목록이 없으면 아무 일도 안 한다
    r0 = fetch_core(man={})
    t('★★★ **서버에 코어 목록이 없으면 아무 일도 안 한다**',
      r0['ok'] and r0['why'] == 'NO_CORE_LIST' and not r0['got'], str(r0))
    r1 = fetch_core(man=MAN)
    t('★★ **없는 파일은 조용히 넘기지 않는다**(무엇이 안 됐는지 말한다)',
      (not r1['ok']) and r1['why'], r1['why'][:56])
    t('  받은 것이 없으면 0행', r1['rows'] == 0)

    # ── 내 판 (2026-09-06 사용자 「항목별 버전상태 표시하라」) ───────
    import sqlite3 as _sq
    _d2 = tempfile.mkdtemp()          # ⚠ 위 `d` 는 이미 지워졌을 수 있다
    mp = os.path.join(_d2, 'mine.db')
    _c = _sq.connect(mp)
    _c.execute("CREATE TABLE sys_pack_applied(id INTEGER PRIMARY KEY,"
               " kind TEXT, key TEXT, lang TEXT, variant TEXT)")
    _c.execute("INSERT INTO sys_pack_applied(kind,key,lang) VALUES('BOOK','X','KO')")
    _c.commit(); _c.close()
    #   ⚠ **판 칸이 없으면 아무것도 안 낸다** — 모르는 것을 0 으로 내면
    #     「받았는데 0 판」이라는 거짓말이 된다.
    t('★★★ 판 칸이 없으면 빈손(0 으로 지어내지 않는다)', mine_versions(mp) == {})
    _c = _sq.connect(mp)
    _c.execute("ALTER TABLE sys_pack_applied ADD COLUMN version INTEGER DEFAULT 0")
    _c.execute("UPDATE sys_pack_applied SET version=2")
    _c.execute("INSERT INTO sys_pack_applied(kind,key,lang,version)"
               " VALUES('BIBLE','KRV','-',0)")
    _c.execute("INSERT INTO sys_pack_applied(kind,key,lang,version)"
               " VALUES('COMM','JFB','EN',5)")
    _c.commit(); _c.close()
    mv = mine_versions(mp)
    t('★★ 판을 낸다', mv.get(('BOOK', 'X', 'KO')) == 2, mv)
    t('★★ 판 0 은 「모름」이라 안 낸다', ('BIBLE', 'KRV', '') not in mv)
    t("★ 언어 '-' 는 빈 글자로 맞춘다(assets 열쇠와 같은 규칙)",
      ('COMM', 'JFB', 'EN') in mv)
    import shutil as _sh
    _sh.rmtree(_d2, ignore_errors=True)

    # ── 판 표기 통일 (2026-09-07 사용자 지시) ─────────────────────────
    t('★ 판 표기는 A-2 꼴', ver_label(2) == 'A-2', ver_label(2))
    t('  릴리스는 R-4 꼴', ver_label(4, VER_R) == 'R-4')
    t('★ 「판」·「Ver」 라는 글자를 안 쓴다',
      '판' not in ver_label(2) and 'Ver' not in ver_label(2))
    t('  0/모름이면 빈 글자(지어내지 않는다)',
      ver_label(0) == '' and ver_label(None) == '' and ver_label('x') == '')
    t('★ 비교는 화살표 하나', ver_arrow(1, 3) == 'A-1 → A-3', ver_arrow(1, 3))
    t('  같으면 하나만', ver_arrow(3, 3) == 'A-3')
    t('  내 판을 모르면 최신만', ver_arrow(0, 3) == 'A-3')

    # ── 5분류 ────────────────────────────────────────────────────────
    t('★ 받았고 최신 = 최신판',
      item_class({'version': 3, 'mine': 3}, ST_INSTALLED) == CL_LATEST)
    t('★ 받았는데 옛 판 = 업그레이드 가능',
      item_class({'version': 3, 'mine': 1}, ST_INSTALLED) == CL_UPGRADE)
    t('★ 안 받았고 서버에 있다 = 다운로드 가능',
      item_class({'version': 3}, ST_NEW) == CL_AVAIL)
    t('★ 판이 없다 = 미발행',
      item_class({'version': 0}, ST_NEW) == CL_UNPUB)
    t('★ 받았다 지웠다 = 삭제됨 (「한 번도 안 받은 것」과 다르다)',
      item_class({'version': 3}, ST_REMOVED) == CL_REMOVED)
    t('  own_version 만 있어도 발행된 것으로 본다',
      item_class({'version': 0, 'own_version': 2}, ST_NEW) == CL_AVAIL)
    t('  서버 판을 모르면 갖고 있는 것을 최신으로 본다',
      item_class({'version': 0, 'mine': 1}, ST_INSTALLED) == CL_LATEST)
    t('  state 는 dict 에서도 읽는다',
      item_class({'version': 3, 'mine': 1, 'state': ST_INSTALLED}) == CL_UPGRADE)
    t('  다섯 갈래가 전부 CLASSES 에 있다',
      set(CLASSES) == {CL_LATEST, CL_UPGRADE, CL_AVAIL, CL_UNPUB, CL_REMOVED})

    # ── 본문팩 자동 갱신 (2026-09-07) ────────────────────────────
    import tempfile as _tf3
    _d3 = _tf3.mkdtemp()
    _p3 = os.path.join(_d3, 'auto.db')
    _c3 = sqlite3.connect(_p3)
    _c3.executescript("""
      CREATE TABLE sys_pack_applied(kind TEXT, key TEXT, lang TEXT,
        variant TEXT, version INTEGER, release INTEGER);
      CREATE TABLE sys_pack_item(kind TEXT, key TEXT, lang TEXT, variant TEXT,
        version INTEGER, own_version INTEGER, title TEXT,
        record_status TEXT DEFAULT 'LIVE');
      CREATE TABLE user_config(config_key TEXT PRIMARY KEY, config_val TEXT);
    """)
    # 내가 받은 것: 도서 KO 1판 · 성경 2판
    _c3.execute("INSERT INTO sys_pack_applied VALUES ('BOOK','B1','KO','-',1,1)")
    _c3.execute("INSERT INTO sys_pack_applied VALUES ('BIBLE','KRV','','-',2,1)")
    _c3.commit()
    _c3.close()
    # 서버 목록(직접 넘긴다 — 네트워크를 안 탄다)
    _man = {'items': [
        {'kind': 'BOOK', 'key': 'B1', 'lang': 'KO', 'variant': 'TRANSLATED',
         'version': 3, 'title': '밀린 도서'},
        {'kind': 'BIBLE', 'key': 'KRV', 'lang': '-', 'variant': '-',
         'version': 2, 'title': '최신 성경'},
        {'kind': 'BOOK', 'key': 'B9', 'lang': 'KO', 'variant': '-',
         'version': 5, 'title': '안 받은 도서'},
    ]}
    _pu = pending_updates(_p3, man=_man)
    t('★ 밀린 것만 낸다', [x['key'] for x in _pu] == ['B1'],
      [x['key'] for x in _pu])
    t('  최신인 것은 안 낸다', all(x['key'] != 'KRV' for x in _pu))
    t('★★ **안 받은 자산은 안 낸다**(새것은 사람이 선택한다)',
      all(x['key'] != 'B9' for x in _pu))
    t('  판 둘을 함께 낸다', _pu and _pu[0]['mine'] == 1 and _pu[0]['new'] == 3)
    t('  variant 를 싣는다(받는 문이 쓴다)',
      _pu and _pu[0]['variant'] == 'TRANSLATED', _pu[0]['variant'] if _pu else '')
    t('★ 언어를 가린다', pending_updates(_p3, ['EN'], man=_man) == [])
    t('  그 언어면 나온다',
      [x['key'] for x in pending_updates(_p3, ['KO'], man=_man)] == ['B1'])

    # ⚠ 판 기록이 없으면 **아무것도 안 한다** — 모르는 것을 밀렸다고 보면
    #   전량을 다시 받는다.
    _p4 = os.path.join(_d3, 'norec.db')
    _c4 = sqlite3.connect(_p4)
    _c4.execute("CREATE TABLE sys_pack_applied(kind TEXT, key TEXT, lang TEXT)")
    _c4.commit()
    _c4.close()
    t('★★ 판 기록이 없으면 대상 0', pending_updates(_p4, man=_man) == [])
    _r4 = fetch_asset_updates(_p4, man=_man, max_items=0)
    t('★ 왜 0건인지 말한다', _r4['why'] == 'NO_VERSION_RECORD', _r4['why'])
    _r5 = fetch_asset_updates(_p3, man={'items': []}, max_items=0)
    t('  서버 목록이 없으면 그렇게 말한다',
      _r5['why'] == 'NO_ITEM_LIST', _r5['why'])
    _r6 = fetch_asset_updates(_p3, langs=['KO'], man=_man, max_items=0)
    t('  상한 0이면 안 받고 남은 수를 낸다',
      _r6['got'] == [] and _r6['left'] == 1, (_r6['got'], _r6['left']))
    # ⚠ 밀린 것이 있는데 **고른 언어가 아니어서** 0건인 것을 가려 말한다
    _r7 = fetch_asset_updates(_p3, langs=['FR'], man=_man, max_items=0)
    t('★ 언어가 안 맞아 0건인 것을 가려 말한다',
      _r7['why'] == 'NO_LANG_MATCH', _r7['why'])
    t('★ 한 번에 받을 수에 상한이 있다', AUTO_MAX_ITEMS == 3)
    _sh.rmtree(_d3, ignore_errors=True)

    print('pack_status selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]



# ── 본문팩 자동 갱신 (2026-09-07) ──────────────────────────────────────
#: 한 번에 받을 자산 수 — 하루 한 번 도므로 며칠에 걸쳐 따라잡는다.
#: ⚠ **큰 것을 건너뛰지 않는다** — 건너뛰면 스펄전(12MB)처럼 큰 자산은
#:   영영 안 받는다. 개수만 막는다.
AUTO_MAX_ITEMS = 3


def pending_updates(db_path='bible_master.db', langs=None, man=None):
    """**이미 받은 자산 중 밀린 것** → `[{kind,key,lang,variant,mine,new}]`.

    ★★★ **새 자산은 안 받는다 — 갱신만 한다**(2026-09-07 설계).
      「자동 최신화」의 뜻은 **갖고 있는 것을 최신으로**다. 새 자산까지 받으면
      전량 157MB 가 묻지도 않고 내려온다. 새것은 사람이 [항목별]에서 고른다.
      ⇒ 이것이 자동설정 동의문의 「바뀐 것만」과 같은 말이다.
    ⚠ **판을 모르면 대상이 아니다** — 옛 DB 에는 판 칸이 없어 `mine_versions`
      가 빈손이다. 모르는 것을 「밀렸다」고 보면 전량을 다시 받는다.
    ⚠ 언어 목록(`langs`)이 있으면 그 언어만. 언어를 안 가리는 자산(코어·
      원어 사전·사진)은 **늘 대상**이다(`lang_ok`).
    """
    mine = mine_versions(db_path)
    if not mine:
        return []
    out = []
    for it in (assets(db_path, man=man) or []):
        k = (it.get('kind') or '').upper()
        key = str(it.get('key') or '')
        lg = it.get('lang') or ''
        if lg == '-':
            lg = ''
        cur = mine.get((k, key, lg))
        if not cur:
            continue                      # 안 받은 자산 — 사람이 고른다
        new = int(it.get('version') or it.get('own_version') or 0)
        if not new or int(cur) >= new:
            continue
        if langs and not any(lang_ok(it, x) for x in langs):
            continue
        out.append({'kind': k, 'key': key, 'lang': (it.get('lang') or '-'),
                    'variant': it.get('variant') or '-',
                    'mine': int(cur), 'new': new,
                    'title': it.get('title') or key})
    # 밀린 정도가 큰 것부터 — 오래 뒤처진 것을 먼저 따라잡는다
    out.sort(key=lambda r: (-(r['new'] - r['mine']), r['kind'], r['key']))
    return out


def fetch_asset_updates(db_path='bible_master.db', langs=None,
                        max_items=None, man=None, on_step=None):
    """밀린 본문팩을 받는다 → `{'ok','got':[…],'rows','left','why'}`.

    ⚠ **하나가 실패해도 나머지는 받는다**(`fetch_core` 와 같은 규칙).
    ⚠ **왜 0건인지 말한다**(§0-1) — 「판 기록 없음」·「서버 목록 없음」·
      「이미 최신」은 사용자에게 뜻이 전혀 다르다.
    """
    if langs is None:
        langs = dl_langs(db_path) or None
    todo = pending_updates(db_path, langs, man=man)
    if not todo:
        # ⚠ **0건의 까닭을 가른다** — 사용자에게 뜻이 전혀 다르다(§0-1)
        why = ''
        if not mine_versions(db_path):
            why = 'NO_VERSION_RECORD'     # 판 기록이 없다(옛 DB · 미적재)
        elif not (assets(db_path, man=man) or []):
            why = 'NO_ITEM_LIST'          # 서버가 자산 목록을 안 낸다(정비 중)
        elif langs and pending_updates(db_path, None, man=man):
            why = 'NO_LANG_MATCH'         # 밀린 것이 있는데 선택한 언어가 아니다
        return {'ok': True, 'got': [], 'rows': 0, 'left': 0, 'why': why}
    cap = AUTO_MAX_ITEMS if max_items is None else max_items
    got, rows, fails = [], 0, []
    for r in todo[:cap]:
        if callable(on_step):
            try:
                on_step(r)
            except Exception:
                pass
        res = fetch_asset(r['kind'], r['key'], r['lang'], db_path, r['variant'])
        if res.get('ok'):
            got.append(r)
            rows += int(res.get('rows') or 0)
        else:
            fails.append('%s/%s: %s' % (r['kind'], r['key'], res.get('why')))
    return {'ok': not fails, 'got': got, 'rows': rows,
            'left': max(0, len(todo) - len(got)),
            'why': (' · '.join(fails[:3]) if fails else '')}




# ── 다운로드 언어 ───────────────────────────────────────────────────
#: 언어를 안 가리는 자산의 표시값(`sys_pack_item.lang`).
NO_LANG = ('-', '', None)

DL_LANG_KEY = 'DL_LANG'      # 단일 — 최신버전 점검 · 항목별 다운로드
DL_LANGS_KEY = 'DL_LANGS'    # 복수 — 자동설정
ALL_LANG = '*'               # 「전체 언어」


def _cfg_get(db_path, key, dflt=''):
    # ⚠⚠ **`appdb` 를 함수 안에서 import 한다** — 이 파일은 모듈 레벨에
    #   `import appdb` 가 **없다**(전부 지역 import). 전역으로 쓰면
    #   `NameError` 가 나고 `except` 가 삼켜 **조용히 기본값**이 된다
    #   (실측으로 잡았다 — `user_lang` 이 'KO' 인데 'EN' 을 냈다).
    try:
        import appdb
        c = appdb.connect(db_path)
        try:
            r = c.execute("SELECT config_val FROM user_config WHERE config_key=?",
                          (key,)).fetchone()
            return (r[0] if r and r[0] is not None else dflt)
        finally:
            c.close()
    except Exception:
        return dflt


def _cfg_set(db_path, key, val):
    try:
        import appdb
        c = appdb.connect(db_path)
        try:
            c.execute("INSERT INTO user_config(config_key, config_val) VALUES(?,?) "
                      "ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val",
                      (key, str(val)))
            c.commit()
        finally:
            c.close()
    except Exception:
        pass


def ui_lang(db_path='bible_master.db'):
    """지금 앱 언어. 못 읽으면 `EN`."""
    v = (_cfg_get(db_path, 'user_lang', '') or '').upper()
    return v or 'EN'


def dl_lang(db_path='bible_master.db'):
    """**점검·항목별**이 쓰는 언어 하나. 기본 = 앱 언어.

    ★ 팩은 **언어별로 따로**다(`sys_pack_item` 열쇠에 `lang` 이 있다) —
      곧 「한국어로 받고 영어를 더 받는다」가 원래 되는 구조인데, 화면이
      언어를 안 보여서 **고를 수 없었다**(실측 같은 제목 17종이 40줄).
    """
    v = (_cfg_get(db_path, DL_LANG_KEY, '') or '').upper()
    return v or ui_lang(db_path)


def set_dl_lang(lang, db_path='bible_master.db'):
    _cfg_set(db_path, DL_LANG_KEY, (lang or '').upper())


def dl_langs(db_path='bible_master.db'):
    """**자동설정**이 쓰는 언어 목록. 기본 = 앱 언어 하나.

    ⚠ 빈 목록을 돌려주지 않는다 — 빈 채로 자동을 켜면 **아무것도 안 받는데
      켜져 있는** 상태가 된다(§0-1).
    """
    raw = _cfg_get(db_path, DL_LANGS_KEY, '')
    out = [x.strip().upper() for x in str(raw).split(',') if x.strip()]
    return out or [ui_lang(db_path)]


def set_dl_langs(langs, db_path='bible_master.db'):
    seen, out = set(), []
    for x in (langs or []):
        u = str(x).strip().upper()
        if u and u not in seen:
            seen.add(u)
            out.append(u)
    _cfg_set(db_path, DL_LANGS_KEY, ','.join(out))


def lang_ok(item, lang):
    """이 자산이 그 언어에 걸리나.

    ★ **언어를 안 가리는 자산은 언제나 걸린다**(`-`) — 코어·원어 사전·
      시작화면 사진이 그렇다. 언어로 걸러 없애면 받을 길이 사라진다.
    ⚠ `lang` 이 `ALL_LANG` 이거나 비면 전부 통과.
    """
    if not lang or lang == ALL_LANG:
        return True
    lg = (item or {}).get('lang')
    if lg in NO_LANG:
        return True
    return str(lg).upper() == str(lang).upper()


def item_langs(db_path='bible_master.db', man=None):
    """자산이 실제로 가진 언어들 — 콤보·체크 목록에 쓸 목록.

    ⚠⚠ **`assets()` 를 부르지 않는다** — 그 문은 자산마다 본문 유무를 재고
      서버 manifest 까지 받아 **실측 1,849ms** 다(자동설정 화면이 느렸던
      정체다). 여기서 묻는 것은 「어떤 언어가 있나」 하나뿐이라 **목록 표
      한 번**이면 된다(실측 3ms).
    ⚠ 언어를 안 가리는 자산(`-`)은 세지 않는다.
    """
    out = {}
    try:
        import appdb
        c = appdb.connect(db_path)
        try:
            for lg, n in c.execute(
                    "SELECT lang, COUNT(*) FROM sys_pack_item "
                    "WHERE COALESCE(record_status,'LIVE')='LIVE' "
                    "  AND COALESCE(lang,'') NOT IN ('', '-') "
                    "GROUP BY lang"):
                out[str(lg).upper()] = int(n or 0)
        finally:
            c.close()
    except Exception:
        pass
    # ★ 서버 목록이 있으면 **거기 있는 언어도 더한다** — 아직 안 받은 언어를
    #   고를 수 있어야 한다(내 DB 에 없다고 못 고르면 새 언어를 영영 못 받는다).
    try:
        for it in list((man or {}).get('items') or []):
            lg = (it.get('lang') if isinstance(it, dict) else None)
            if lg and str(lg) not in ('-', ''):
                k = str(lg).upper()
                out[k] = out.get(k, 0)
    except Exception:
        pass
    return sorted(out.items(), key=lambda kv: (-kv[1], kv[0]))

if __name__ == '__main__':
    sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                                  encoding='utf-8', write_through=True)
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    h = have()
    print('팩: %s' % h['path'])
    print('  %s · %s · 커서 %d'
          % ('있음' if h['exists'] else '없음', human(h['bytes']), h['cursor']))
    for key, label, _q in PARTS:
        print('  %-14s %s' % (label, f"{h['counts'].get(key, 0):,}"))
