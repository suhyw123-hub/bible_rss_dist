# -*- coding: utf-8 -*-
"""db_user_ref_schema.py — 사용자 자료의 연결 표 (영구 도구, §0-5 KEEP).

`user_ref_asset` 은 글 하나에 **구절 하나 · 페리코프 하나 · 엔티티 하나**만 붙일 수 있다
(`verse_id`·`pericope_id`·`entity_id` 단일 칸). 그래서 「이 글은 창 1:26~27 과 롬 8:29 를
다루고, 하나님의 형상·예정 두 용어에 걸린다」를 적을 수가 없었다.

이 표가 **여럿 붙이기**를 연다. `sys_ref_asset_link` 와 같은 모양이라 화면 코드가 그대로 산다.

    python -X utf8 db_user_ref_schema.py --init
    python -X utf8 db_user_ref_schema.py --status
    python -X utf8 db_user_ref_schema.py --selftest

⚠ **자리는 `userdb` 다.** 사용자가 쓴 글은 `user_data.db` 에 있어야 배포판을 갱신해도
  살아남는다. `user_ref_asset` 이 이미 거기 있으므로 링크도 같은 DB 에 둔다 —
  두 DB 에 걸치면 외래키도 백업도 반쪽이 된다.
  ⚠ `appdb.connect` 가 `user_data.db` 를 `userdb` 로 ATTACH 한다. 이름이 안 겹치므로
    `FROM user_ref_asset_link` 처럼 **정규화 없이** 써도 해석된다. 다만 **만들 때는**
    `userdb.` 를 반드시 붙인다 — 안 붙이면 main(bible_master.db)에 생긴다.
"""
import argparse
import sys

import appdb

TABLE = 'user_ref_asset_link'
# ★ **언어별 본문** (2026-08-14 사용자 결정 — `sys_ref_text` 와 같은 모양).
#   ⚠ 그전에는 `user_ref_asset.lang_code` 한 칸뿐이라 **한국어 글과 그 영어 번역이
#     서로 남남인 두 행**이 됐다. 그러면 ① 엔티티·구절을 **두 번** 붙여야 하고
#     ② 앱이 「이것이 저것의 다른 언어판」임을 알 방법이 없다.
#   `CLAUDE.md` §21-4 가 sys 쪽을 그렇게 만든 이유가 그대로 여기에도 적용된다 —
#   그 결론이 user 쪽에만 빠져 있었다.
#   ⇒ 연결(`user_ref_asset_link`)은 **글에 붙으므로 언어와 무관**하다. 한 번만 붙인다.
TEXT_TABLE = 'user_ref_text'
# BOOK_UNIT = 도서/설교 유닛 연결 (2026-08-19 사용자 — 「연구자료를 설교 3개와
# 연결」. 사용자 화면의 연결은 전부 user db 인 이 표에 담는다 — sys/user 경계)
# ★ 2026-10-25 LEMMA = 승격 안 된 원어 낱말(target = `orig_ref.lemma_key` · H→1000000+n · G→2000000+n).
#   승격된 원어는 그 주요용어(ENTITY)로 잇는다 — 읽는 문은 `orig_ref.find` 하나다.
KINDS = ('VERSE', 'PERICOPE', 'ENTITY', 'BOOK_UNIT', 'LEMMA')

#: ★★ 2026-08-24 — **연결을 통합 표로 옮겼다**(`db_link_migrate.py`).
#   `userdb.user_link_asset(link_type='UREF_<상대>')` 한 행이 한 연결이다.
#   옛 표 `user_ref_asset_link` 는 되돌릴 수 있게 남아 있지만 **읽지 않는다.**
#   ⚠ `link_picker.CODE` 와 **같은 코드**를 써야 한다 — 어긋나면 한쪽이 넣은
#     연결을 다른 쪽이 못 찾는다(양쪽 selftest 가 지킨다).
LINK_TBL = 'userdb.user_link_asset'
LT = {'VERSE': 'UREF_VERS', 'PERICOPE': 'UREF_PERI',
      'ENTITY': 'UREF_ENTI', 'BOOK_UNIT': 'UREF_BUNT', 'LEMMA': 'UREF_LEMM'}
KIND_OF_LT = {v: k for k, v in LT.items()}

# ★★ **뒤집힌 이름도 함께 본다** (2026-08-27 사용자 지적 「팝업에서 연결했는데
#   서브탭은 (0) 이다. **통합 로직이 필요하다**」).
#   ⚠⚠ 쓰는 곳이 둘인데 이름 규칙이 달랐다 — `link_picker.pair()` 는 **정렬**해
#     `ENTI_UREF`·`BUNT_UREF` 를 만들고 여기는 **고정**으로 `UREF_ENTI`·
#     `UREF_BUNT` 를 쓴다. 그래서 **서로가 넣은 것을 못 봤다**(실측
#     `ENTI_UREF` 2 · `UREF_ENTI` 15 · 겹침 0).
#   ⇒ 읽을 때도 지울 때도 **두 이름을 다 본다.** 새로 넣는 것은 옛 이름
#     (`UREF_*`)을 그대로 쓴다 — 여기 쌓인 372행이 그 이름이라, 바꾸면
#     그 행들이 이 화면의 「지우는 범위」 밖으로 나간다.
LT_REV = {k: '%s_UREF' % v.split('_')[1] for k, v in LT.items()}
KIND_OF_LT.update({v: k for k, v in LT_REV.items()})
_ALL_LT = tuple(LT.values()) + tuple(LT_REV.values())
DDL = [
    """CREATE TABLE IF NOT EXISTS userdb.user_ref_asset_link (
           link_id       INTEGER PRIMARY KEY AUTOINCREMENT,
           ref_id        INTEGER NOT NULL,
           link_kind     TEXT NOT NULL,          -- VERSE | PERICOPE | ENTITY
           target_id     INTEGER NOT NULL,       -- verse_id / pericope_id / entity_id
           end_id        INTEGER,                -- VERSE 범위의 끝. 한 절이면 NULL
           sort_order    INTEGER DEFAULT 0,
           record_status TEXT DEFAULT 'LIVE'
       )""",
    "CREATE UNIQUE INDEX IF NOT EXISTS userdb.ix_ural_uniq"
    " ON user_ref_asset_link(ref_id, link_kind, target_id, COALESCE(end_id, target_id))",
    "CREATE INDEX IF NOT EXISTS userdb.ix_ural_ref ON user_ref_asset_link(ref_id)",
    "CREATE INDEX IF NOT EXISTS userdb.ix_ural_tgt ON user_ref_asset_link(link_kind, target_id)",
    """CREATE TABLE IF NOT EXISTS userdb.user_ref_text (
           text_id       INTEGER PRIMARY KEY AUTOINCREMENT,
           ref_id        INTEGER NOT NULL,
           lang_code     TEXT NOT NULL,
           title         TEXT,
           body_text     TEXT,
           record_status TEXT DEFAULT 'LIVE'
       )""",
    "CREATE UNIQUE INDEX IF NOT EXISTS userdb.ix_urt_uniq"
    " ON user_ref_text(ref_id, lang_code)",
    # ★ 작성도구의 **블록 구조** (2026-08-20 사용자 — 「저장한 초안을 구조화된
    #   형태로 다시 불러와 수정할 방법이 없다」). 글 자체는 평문으로 확정되고
    #   (그 결정은 유지), 그 평문을 만든 발췌/내 글 블록을 여기 따로 보관해
    #   작성도구에서만 되살린다. 이 표가 없거나 비어도 글은 온전하다.
    """CREATE TABLE IF NOT EXISTS userdb.user_ref_compose (
           ref_id     INTEGER PRIMARY KEY,
           doc_lang   TEXT,
           blocks     TEXT,
           updated_at TEXT
       )""",
]


def _has_userdb(conn):
    return any(r[1] == 'userdb' for r in conn.execute('PRAGMA database_list'))


def init(conn):
    if not _has_userdb(conn):
        raise RuntimeError('userdb 가 ATTACH 되지 않았다 — user_data.db 를 찾을 수 없다')
    for s in DDL:
        conn.execute(s)
    # 뒤에 늘어난 칸 — 먼저 만든 DB 도 따라오게 (CREATE IF NOT EXISTS 는 칸을 안 더한다)
    try:                                   # ★ 2026-10-16 유형·출처(ref_kinds — 출처 · AI 수정함)
        import ref_kinds
        ref_kinds.ensure(conn)
    except Exception as e:                 # noqa: BLE001
        print(f'[user_ref schema origin] {e}')
    try:
        cols = {r[1] for r in conn.execute(
            'PRAGMA userdb.table_info(user_ref_compose)')}
        if cols and 'tree' not in cols:
            conn.execute('ALTER TABLE userdb.user_ref_compose ADD COLUMN tree TEXT')
    except Exception as e:
        print(f'[user_ref schema tree] {e}')
    conn.commit()
    # ⚠ 세는 것은 **통합 표의 내 자료 연결**이다(옛 표는 백업으로만 남는다)
    ph = ','.join('?' * len(LT))
    try:
        return conn.execute('SELECT COUNT(*) FROM %s WHERE link_type IN (%s)'
                            % (LINK_TBL, ph), tuple(LT.values())).fetchone()[0]
    except Exception:
        return 0


def backfill(conn):
    """단일 칸(verse_id·pericope_id·entity_id)에 있던 것을 링크 표로 옮겨 적는다.

    ⚠ 원본 칸은 **지우지 않는다.** 기존 화면이 아직 그 칸을 읽는다(`_user_links`).
      링크 표가 화면에 붙은 뒤에 지울지 정한다.
    """
    n = 0
    for col, kind in (('verse_id', 'VERSE'), ('pericope_id', 'PERICOPE'),
                      ('entity_id', 'ENTITY')):
        cur = conn.execute(
            'INSERT OR IGNORE INTO %s(ref_id, link_kind, target_id)'
            ' SELECT ref_id, ?, %s FROM user_ref_asset'
            "  WHERE %s IS NOT NULL AND COALESCE(record_status,'LIVE')='LIVE'"
            % (TABLE, col, col), (kind,))
        n += cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0
    conn.commit()
    return n


def backfill_text(conn):
    """`user_ref_asset.title`·`summary` 를 **그 글의 `lang_code` 행**으로 옮겨 적는다.

    ⚠ 원본 칸은 **지우지 않는다.** 아직 그 칸을 읽는 화면이 있다(목록 제목 등).
      언어별 본문이 화면에 붙은 뒤에 은퇴시킬지 정한다.
    """
    cur = conn.execute(
        'INSERT OR IGNORE INTO %s(ref_id, lang_code, title, body_text)'
        " SELECT ref_id, UPPER(COALESCE(NULLIF(lang_code,''),'KO')), title, summary"
        '  FROM user_ref_asset'
        "  WHERE COALESCE(record_status,'LIVE')='LIVE'" % TEXT_TABLE)
    conn.commit()
    return cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0


def fetch_text(conn, ref_id, lang, fallback='EN'):
    """그 언어의 `(title, body)`. 없으면 영어, 그것도 없으면 `(None, None)`.

    ⚠ **폴백은 언제나 영어**(2026-08-14 설계 확정). 폴백으로 보이는 중인지
      알아야 하므로 **어느 언어를 보이는지도 함께** 돌려준다.
    """
    for lg in (str(lang or '').upper(), str(fallback or '').upper()):
        if not lg:
            continue
        r = conn.execute(
            'SELECT title, body_text FROM %s'
            " WHERE ref_id=? AND UPPER(lang_code)=? AND COALESCE(record_status,'LIVE')='LIVE'"
            % TEXT_TABLE, (ref_id, lg)).fetchone()
        if r and ((r[0] or '').strip() or (r[1] or '').strip()):
            return (r[0], r[1], lg)
    return (None, None, None)


def set_text(conn, ref_id, lang, title, body):
    """그 언어의 제목·본문을 넣거나 고친다."""
    lg = str(lang or 'KO').upper()
    cur = conn.execute(
        "UPDATE %s SET title=?, body_text=?, record_status='LIVE'"
        ' WHERE ref_id=? AND UPPER(lang_code)=?' % TEXT_TABLE,
        (title, body, ref_id, lg))
    if cur.rowcount == 0:
        conn.execute(
            'INSERT INTO %s(ref_id, lang_code, title, body_text, record_status)'
            " VALUES(?,?,?,?,'LIVE')" % TEXT_TABLE, (ref_id, lg, title, body))
    conn.commit()


def text_langs(conn, ref_id):
    """그 글이 실제로 갖고 있는 언어들 — 화면이 「번역이 있다」를 보일 때 쓴다."""
    try:
        return [r[0] for r in conn.execute(
            'SELECT UPPER(lang_code) FROM %s'
            " WHERE ref_id=? AND COALESCE(record_status,'LIVE')='LIVE'"
            "   AND (COALESCE(TRIM(title),'')<>'' OR COALESCE(TRIM(body_text),'')<>'')"
            ' ORDER BY lang_code' % TEXT_TABLE, (ref_id,)).fetchall()]
    except Exception:
        return []


# ── 화면용 ──────────────────────────────────────────────────────────────────
def fetch_links(conn, ref_id):
    """[(link_kind, target_id, end_id)] — 그 글에 걸린 연결 전부.

    ★ 통합 표에서 읽되 **돌려주는 모양은 그대로**다(화면 코드를 안 건드린다).
    ★★ **뒤집힌 이름도 함께 읽는다** — 내가 A 인 행(`UREF_*`)과 내가 B 인 행
      (`*_UREF`)을 모아 하나로. 안 그러면 다른 화면이 넣은 연결이 통째로 빠진다.
    ⚠ 같은 짝이 두 이름으로 있으면(실측 8짝) **한 번만** 낸다.
    """
    # ⚠ **자리를 갈래마다 못 박는다**(위 `set_links` 와 같은 이유 — 번호 겹침).
    f_ph = ','.join('?' * len(LT))
    r_ph = ','.join('?' * len(LT_REV))
    try:
        rows = conn.execute(
            'SELECT link_type, clicked_id, target_id, end_id FROM %(T)s'
            ' WHERE link_type IN (%(F)s) AND clicked_id=?'
            "   AND COALESCE(record_status,'LIVE')='LIVE'"
            ' UNION ALL '
            'SELECT link_type, clicked_id, target_id, end_id FROM %(T)s'
            ' WHERE link_type IN (%(R)s) AND target_id=?'
            "   AND COALESCE(record_status,'LIVE')='LIVE'"
            % {'T': LINK_TBL, 'F': f_ph, 'R': r_ph},
            tuple(LT.values()) + (ref_id,) + tuple(LT_REV.values()) + (ref_id,)
        ).fetchall()
        out, seen = [], set()
        for lt, a_i, b_i, e in rows:
            fwd = lt.startswith('UREF_')
            tid, end = (b_i, e) if fwd else (a_i, None)
            key = (KIND_OF_LT.get(lt, lt), tid, end)
            if key in seen:
                continue
            seen.add(key)
            out.append(key)
        return out
    except Exception:
        return []


def set_links(conn, ref_id, links):
    """그 글의 연결을 통째로 갈아 끼운다. links = [(kind, target_id, end_id)].

    ⚠ **`ON CONFLICT(칸…)` 을 안 쓴다** — 통합 표의 유일 열쇠는 `COALESCE` 를
      쓰는 부분 인덱스라 칸 목록으로 못 가리킨다. **먼저 고쳐 보고 없으면
      넣는다** — 인덱스 모양이 바뀌어도 안 깨진다.
    ⚠ 지우는 범위를 내 자료 연결 갈래로 못 박는다. 안 그러면 그 번호의 다른
      연결까지 숨긴다.
    ⚠⚠ **뒤집힌 이름까지 숨긴다** — 안 숨기면 뗀 연결이 다른 이름으로 살아남아
      **숨겼는데 안 숨는다**(실측 1짝이 실제로 그 상태였다: `UREF_BUNT` LIVE ↔
      `BUNT_UREF` HIDE). 새로 넣는 것은 `UREF_*` 하나로만 만든다.
    """
    # ⚠ **자리를 갈래마다 못 박는다** — `(clicked_id=? OR target_id=?)` 로 한 번에
    #   쓸면 `BUNT_UREF` 의 clicked_id(도서 편 번호)가 우연히 ref_id 와 같은
    #   **남의 행**을 숨긴다(번호대가 겹친다 — §81 함정).
    fwd = ','.join('?' * len(LT))
    rev = ','.join('?' * len(LT_REV))
    conn.execute("UPDATE %s SET record_status='HIDE' "
                 " WHERE link_type IN (%s) AND clicked_id=?" % (LINK_TBL, fwd),
                 tuple(LT.values()) + (ref_id,))
    conn.execute("UPDATE %s SET record_status='HIDE' "
                 " WHERE link_type IN (%s) AND target_id=?" % (LINK_TBL, rev),
                 tuple(LT_REV.values()) + (ref_id,))
    for i, (kind, tid, end) in enumerate(links):
        if kind not in KINDS:
            continue
        lt, tid = LT[kind], int(tid)
        cur = conn.execute(
            "UPDATE %s SET record_status='LIVE', sort_order=?"
            " WHERE link_type=? AND clicked_id=? AND target_id=?"
            "   AND COALESCE(end_id, target_id)=COALESCE(?, target_id)" % LINK_TBL,
            (i, lt, ref_id, tid, end))
        if not cur.rowcount:
            conn.execute(
                'INSERT INTO %s(link_type, clicked_id, target_id, end_id,'
                " sort_order, record_status) VALUES(?,?,?,?,?, 'LIVE')" % LINK_TBL,
                (lt, ref_id, tid, end, i))
    conn.commit()


def add_links(conn, ref_id, links, src=None):
    """연결을 **보탠다** — 있는 것은 건드리지 않는다. 돌려주는 값 = 보탠 수.

    `links = [(kind, target_id, end_id)]` · `src` = `source` 칸에 적을 표식.

    ⚠⚠⚠ **`src` 를 안 주면 그 연결은 「사람이 이은 것」이 된다** — 다음
      `sync_links` 가 건드리지 않아 **글에서 약명을 지워도 남는다**(실측으로
      당했다: 화면 한 쪽만 표식을 적어 두 화면이 갈렸다). 자동 추천에서 걸 때는
      **반드시 `AUTO_SRC` 를 준다.**

    ★★★ **`set_links` 와 몫이 다르다** — 그 문은 통째로 갈아 끼우고(사람이
      화면에서 목록을 고쳤을 때) 이 문은 **더하기만** 한다(자동 추천이 걸 때).
      자동 연결에 `set_links` 를 쓰면 **사람이 손으로 이은 것이 사라진다.**
    ⚠⚠⚠ **사용자가 지운 연결(HIDE)은 되살리지 않는다** — 실측 `UREF_VERS` 에
      HIDE 12건이 있다. LIVE 만 보고 「없다」고 판정하면 그 열두 건이 다시
      살아나 **사용자가 뗀 판단을 없던 일로 만든다.**
    ⚠ 뒤집힌 이름(`VERS_UREF`)도 「있는 것」으로 센다 — 못 보면 같은 짝이 두
      이름으로 쌓인다.
    ⚠ **멱등** — 두 번 불러도 한 번만 들어간다.
    """
    init(conn)
    fwd = ','.join('?' * len(LT))
    rev = ','.join('?' * len(LT_REV))
    #  ── 지금 있는 것(상태를 가리지 않는다) ──────────────────────────
    have = set()
    try:
        for lt, a_i, b_i, e in conn.execute(
                'SELECT link_type, clicked_id, target_id, end_id FROM %(T)s'
                ' WHERE link_type IN (%(F)s) AND clicked_id=?'
                ' UNION ALL '
                'SELECT link_type, clicked_id, target_id, end_id FROM %(T)s'
                ' WHERE link_type IN (%(R)s) AND target_id=?'
                % {'T': LINK_TBL, 'F': fwd, 'R': rev},
                tuple(LT.values()) + (ref_id,)
                + tuple(LT_REV.values()) + (ref_id,)).fetchall():
            k = KIND_OF_LT.get(lt, lt)
            tid = b_i if lt.startswith('UREF_') else a_i
            have.add((k, int(tid), int(e) if e else None))
    except Exception:                                     # noqa: BLE001
        return 0
    #  ── 차례는 뒤에 붙인다 ────────────────────────────────────────
    try:
        nxt = (conn.execute(
            'SELECT COALESCE(MAX(sort_order),0) FROM %s'
            ' WHERE link_type IN (%s) AND clicked_id=?' % (LINK_TBL, fwd),
            tuple(LT.values()) + (ref_id,)).fetchone()[0] or 0) + 1
    except Exception:                                     # noqa: BLE001
        nxt = 1
    n = 0
    for kind, tid, end in links or ():
        if kind not in KINDS:
            continue
        tid = int(tid)
        end = int(end) if end and int(end) != tid else None
        if (kind, tid, end) in have:
            continue
        conn.execute(
            'INSERT INTO %s(link_type, clicked_id, target_id, end_id,'
            " sort_order, record_status, source) VALUES(?,?,?,?,?, 'LIVE',?)"
            % LINK_TBL, (LT[kind], ref_id, tid, end, nxt + n, src))
        have.add((kind, tid, end))
        n += 1
    if n:
        conn.commit()
    return n


#: 자동으로 걸린 연결의 표식 — 사람이 이은 것과 가른다(사용자 지시 315차).
#: ⚠ 이 글자를 바꾸면 **이미 걸린 것이 사람 연결로 보인다** — 바꾸지 말 것.
AUTO_SRC = 'CITE_AUTO'


#: ★ 2026-10-13 docs/1.txt 84-2 — [남은 추천 모두 지우기]가 남기는 표식. **HIDE 행**이라 화면에 안 보이고
#:   `add_links`·`sync_links` 가 「있는 것」으로 보아 되살리지 않으며 추천 줄도 다시 안 낸다.
DISMISS_SRC = 'CITE_DISMISS'


def dismiss(conn, ref_id, links):
    """추천을 지운다(연결은 안 한다) — 같은 좌표가 다시 추천되지 않게 HIDE 행으로 적는다 → 적은 수."""
    init(conn)
    n = 0
    for kind, tid, end in links or ():
        if kind not in KINDS:
            continue
        tid = int(tid)
        end = int(end) if end and int(end) != tid else None
        hit = conn.execute(
            'SELECT 1 FROM %s WHERE link_type=? AND clicked_id=? AND target_id=?'
            ' AND COALESCE(end_id, 0)=COALESCE(?, 0)' % LINK_TBL,
            (LT[kind], ref_id, tid, end)).fetchone()
        if hit:
            continue
        conn.execute(
            'INSERT INTO %s(link_type, clicked_id, target_id, end_id, sort_order, record_status, source)'
            " VALUES(?,?,?,?,0,'HIDE',?)" % LINK_TBL, (LT[kind], ref_id, tid, end, DISMISS_SRC))
        n += 1
    conn.commit()
    return n


def all_coords(conn, ref_id, kind='VERSE'):
    """그 글에 적힌 좌표 전부 — LIVE·HIDE(사람이 뗀 것·추천을 지운 것) 함께 → {(start, end)}.
    추천 줄이 「이미 다룬 것」을 빼는 데 쓴다."""
    try:
        rows = conn.execute(
            'SELECT target_id, end_id FROM %s WHERE link_type=? AND clicked_id=?' % LINK_TBL,
            (LT[kind], ref_id)).fetchall()
    except Exception:                                     # noqa: BLE001
        return set()
    return {(int(a), int(e) if e else int(a)) for a, e in rows}


def sync_links(conn, ref_id, links, src=AUTO_SRC, add=True, kinds=('VERSE',)):
    """자동으로 걸린 연결을 **글과 맞춘다** → `(넣은 수, 지운 수)`.

    ★★★ 사용자 지시(315차) — 「**구절약명이 수정되면 구절연결도 수정되어야
      한다. 구절이 추가로 연결되면 안된다**」. 글을 고쳐 다시 저장하면 없어진
      약명의 연결은 **사라져야** 한다.
      ⚠ `add_links`(보태기만)로는 그 지시를 지킬 수 없다 — 옛 좌표가 쌓인다.
    ★★★ **`source` 와 상태가 가른다** — 규칙 셋이 어긋나지 않게 섰다:
      | DB 모습 | 뜻 | 여기서 |
      |---|---|---|
      | LIVE · `src` | 자동으로 걸린 것 | **글과 맞춘다** |
      | LIVE · 다른 `source` | 사람이 손으로 이은 것 | 안 건드린다 |
      | **HIDE** | **사람이 화면에서 지운 것** | **되살리지 않는다** |
    ⚠⚠⚠ **없어진 약명의 연결은 HIDE 가 아니라 실제로 지운다.** 숨기면 그 행이
      「사람이 지운 것」과 **같은 모습**이 되어 약명을 다시 적어도 안 돌아온다
      (검사가 그 자리에서 잡았다). **자동 생성물은 글이 정본이고 되돌릴 자리가
      바로 그 글**이므로 흔적을 남길 값이 없다.
      ★ 「지우지 않고 HIDE」(§222차)는 **사람이 만든 것**의 관례다.
    """
    init(conn)
    fwd = ','.join('?' * len(LT))
    rev = ','.join('?' * len(LT_REV))
    want = set()
    for kind, tid, end in links or ():
        if kind not in KINDS:
            continue
        tid = int(tid)
        end = int(end) if end and int(end) != tid else None
        want.add((kind, tid, end))
    #  ── 지금 걸린 것 ──────────────────────────────────────────────
    mine, other = {}, set()
    try:
        rows = conn.execute(
            'SELECT link_type, clicked_id, target_id, end_id,'
            " COALESCE(source,''), COALESCE(record_status,'LIVE'), user_link_id"
            ' FROM %(T)s WHERE link_type IN (%(F)s) AND clicked_id=?'
            ' UNION ALL '
            'SELECT link_type, clicked_id, target_id, end_id,'
            " COALESCE(source,''), COALESCE(record_status,'LIVE'), user_link_id"
            ' FROM %(T)s WHERE link_type IN (%(R)s) AND target_id=?'
            % {'T': LINK_TBL, 'F': fwd, 'R': rev},
            tuple(LT.values()) + (ref_id,)
            + tuple(LT_REV.values()) + (ref_id,)).fetchall()
    except Exception:                                     # noqa: BLE001
        return (0, 0)
    for lt, a_i, b_i, e, so, st, lid in rows:
        k = KIND_OF_LT.get(lt, lt)
        tid = b_i if lt.startswith('UREF_') else a_i
        key = (k, int(tid), int(e) if e else None)
        if k not in kinds:
            continue                # ★ 2026-10-25 — 맞추는 갈래만(구절을 맞추다 원어 연결을 지우지 않는다)
        if so == src and st.upper() == 'LIVE':
            mine[key] = lid
        else:
            other.add(key)          # 사람이 이은 것 · 사용자가 지운 것
    #  ── 없어진 약명의 연결을 **지운다**(위 머리글 ⚠⚠⚠) ─────────────
    gone = 0
    for key, lid in mine.items():
        if key not in want:
            conn.execute('DELETE FROM %s WHERE user_link_id=?' % LINK_TBL,
                         (lid,))
            gone += 1
    #  ── 새 약명을 넣는다 ─────────────────────────────────────────
    try:
        nxt = (conn.execute(
            'SELECT COALESCE(MAX(sort_order),0) FROM %s'
            ' WHERE link_type IN (%s) AND clicked_id=?' % (LINK_TBL, fwd),
            tuple(LT.values()) + (ref_id,)).fetchone()[0] or 0) + 1
    except Exception:                                     # noqa: BLE001
        nxt = 1
    if not add:                         # ★ 84-2 — 저장할 때의 다시 보기: 없어진 것만 걷는다(새로 걸지 않는다)
        if gone:
            conn.commit()
        return (0, gone)
    add = 0
    for kind, tid, end in sorted(want):
        key = (kind, tid, end)
        if key in mine or key in other:
            continue
        conn.execute(
            'INSERT INTO %s(link_type, clicked_id, target_id, end_id,'
            " sort_order, record_status, source) VALUES(?,?,?,?,?, 'LIVE',?)"
            % LINK_TBL, (LT[kind], ref_id, tid, end, nxt + add, src))
        add += 1
    if add or gone:
        conn.commit()
    return (add, gone)


def save_compose(conn, ref_id, doc_lang, blocks, tree=None):
    """작성도구의 블록 + **작업대 상태(tree)** 를 그 글에 붙여 둔다(재편집용).

    tree = {'materials':[…], 'checks':[…], 'opened':[…], 'scope':…}
    ★ 후보(자식)는 담지 않는다 — DB 연결에서 다시 계산되는 것이라 저장하면
      낡은 사본이 된다(Live-Sync 원칙). 재료만 있으면 트리가 재생된다."""
    import json as _j
    conn.execute(
        "INSERT INTO userdb.user_ref_compose(ref_id, doc_lang, blocks, tree, updated_at)"
        " VALUES(?,?,?,?, datetime('now'))"
        " ON CONFLICT(ref_id) DO UPDATE SET doc_lang=excluded.doc_lang,"
        " blocks=excluded.blocks, tree=excluded.tree, updated_at=excluded.updated_at",
        (ref_id, (doc_lang or 'KO').upper(),
         _j.dumps(blocks, ensure_ascii=False),
         (_j.dumps(tree, ensure_ascii=False) if tree else None)))
    conn.commit()


def load_compose(conn, ref_id):
    """{'doc_lang','blocks','tree'} 또는 None(작성도구로 쓴 글이 아님)."""
    import json as _j
    try:
        r = conn.execute("SELECT doc_lang, blocks, tree FROM userdb.user_ref_compose"
                         " WHERE ref_id=?", (ref_id,)).fetchone()
    except Exception:
        return None
    if not r or not r[1]:
        return None
    try:
        tree = None
        if len(r) > 2 and r[2]:
            try:
                tree = _j.loads(r[2])
            except Exception:
                tree = None
        return {'doc_lang': r[0] or 'KO', 'blocks': _j.loads(r[1]), 'tree': tree}
    except Exception:
        return None


def compose_list(conn, limit=50):
    """작성도구로 쓴 글 목록 — [(ref_id, 제목, updated_at, 대표 verse_id)] 최신순.

    대표 구절 = 그 글의 첫 구절 연결(= 재료의 첫 구절). 목록에서 제목만으로는
    무슨 글인지 떠오르지 않아 약명을 함께 보인다(2026-08-20 사용자 지시)."""
    try:
        return conn.execute(
            "SELECT c.ref_id, COALESCE(a.title,'(제목 없음)'), c.updated_at,"
            "       COALESCE(a.verse_id,"
            # ★ 2026-08-24 통합 표(`UREF_VERS`)
            "         (SELECT MIN(l.target_id) FROM userdb.user_link_asset l"
            "           WHERE l.clicked_id=c.ref_id AND l.link_type='UREF_VERS'"
            "             AND COALESCE(l.record_status,'LIVE')='LIVE'))"
            " FROM userdb.user_ref_compose c"
            " JOIN user_ref_asset a ON a.ref_id=c.ref_id"
            "  AND COALESCE(a.record_status,'LIVE')='LIVE'"
            " ORDER BY c.updated_at DESC LIMIT ?", (limit,)).fetchall()
    except Exception:
        return []


def status(conn):
    ph = ','.join('?' * len(LT))
    try:
        n = conn.execute('SELECT COUNT(*) FROM %s WHERE link_type IN (%s)'
                         % (LINK_TBL, ph), tuple(LT.values())).fetchone()[0]
    except Exception:
        return '표가 없다 — 먼저 db_link_unify --apply'
    d = dict(conn.execute('SELECT link_type, COUNT(*) FROM %s'
                          " WHERE link_type IN (%s)"
                          "   AND COALESCE(record_status,'LIVE')='LIVE'"
                          ' GROUP BY 1' % (LINK_TBL, ph),
                          tuple(LT.values())).fetchall())
    # ⚠ **자리 검사는 그대로 산다** — 통합 표가 main 에 생기면 사용자 연결이
    #   배포판 갱신 때 통째로 사라진다(이 selftest 의 존재 이유).
    where = conn.execute("SELECT name FROM userdb.sqlite_master WHERE name=?",
                         ('user_link_asset',)).fetchone()
    return '연결 %d건 %s · 자리 %s' % (n, d or '', 'userdb ✔' if where else '⚠ main 에 생겼다')


def selftest():
    """★ 의무. 여기서 막아야 하는 것은 **표가 main 에 생기는 것**이다 —
    그러면 배포판을 갱신할 때 사용자 글의 연결이 통째로 사라진다."""
    print('db_user_ref_schema 자가 검증')
    bad = []
    conn = appdb.connect()
    if not _has_userdb(conn):
        print('SELFTEST FAIL — userdb 가 없다')
        return 1
    init(conn)

    # ① 표가 userdb 에 있어야 한다
    if not conn.execute("SELECT 1 FROM userdb.sqlite_master WHERE name=?", (TABLE,)).fetchone():
        bad.append('표가 userdb 에 없다')
    if conn.execute("SELECT 1 FROM main.sqlite_master WHERE name=?", (TABLE,)).fetchone():
        bad.append('표가 main 에도 생겼다 — 배포판 갱신에 사용자 글이 날아간다')

    # ② 같은 짝을 두 번 넣어도 하나
    RID = -9999
    set_links(conn, RID, [('VERSE', 1, None), ('VERSE', 1, None), ('ENTITY', 423, None)])
    got = fetch_links(conn, RID)
    if len(got) != 2:
        bad.append('멱등이 아니다 — %d건' % len(got))

    # ③ 다시 세우면 옛 연결이 남지 않는다
    set_links(conn, RID, [('ENTITY', 423, None)])
    if len(fetch_links(conn, RID)) != 1:
        bad.append('갈아 끼운 뒤 옛 연결이 남는다')

    # ④ 모르는 갈래는 넣지 않는다
    set_links(conn, RID, [('BOGUS', 5, None)])
    if fetch_links(conn, RID):
        bad.append('모르는 link_kind 를 넣는다')

    # ⑤ **언어별 본문** — 같은 글의 다른 언어판이 서로를 밀어내지 않는다
    if not conn.execute("SELECT 1 FROM userdb.sqlite_master WHERE name=?",
                        (TEXT_TABLE,)).fetchone():
        bad.append('본문 표가 userdb 에 없다')
    if conn.execute("SELECT 1 FROM main.sqlite_master WHERE name=?",
                    (TEXT_TABLE,)).fetchone():
        bad.append('본문 표가 main 에도 생겼다')
    set_text(conn, RID, 'KO', '에봇', '한국어 본문')
    set_text(conn, RID, 'EN', 'Ephod', 'English body')
    if sorted(text_langs(conn, RID)) != ['EN', 'KO']:
        bad.append('두 언어가 함께 살지 못한다: %s' % text_langs(conn, RID))
    if fetch_text(conn, RID, 'KO')[:2] != ('에봇', '한국어 본문'):
        bad.append('KO 를 못 꺼낸다')
    if fetch_text(conn, RID, 'EN')[:2] != ('Ephod', 'English body'):
        bad.append('EN 을 못 꺼낸다')
    # ⑥ **폴백은 언제나 영어** — 없는 언어를 물으면 영어를 주고 그 사실을 알린다
    t, b, used = fetch_text(conn, RID, 'JA')
    if used != 'EN' or t != 'Ephod':
        bad.append('폴백이 영어가 아니다: %s / %s' % (used, t))
    # ⑦ 같은 언어를 다시 넣으면 **덮어쓴다**(행이 늘지 않는다)
    set_text(conn, RID, 'KO', '에봇2', '고친 본문')
    if len(text_langs(conn, RID)) != 2 or fetch_text(conn, RID, 'KO')[0] != '에봇2':
        bad.append('같은 언어를 두 번 넣으면 행이 는다')
    # ⑧ ★ **연결은 언어와 무관하다** — 언어를 더해도 연결이 그대로여야 한다
    set_links(conn, RID, [('ENTITY', 423, None)])
    set_text(conn, RID, 'ZH', '以弗得', '中文')
    if len(fetch_links(conn, RID)) != 1:
        bad.append('언어를 더했더니 연결이 흔들린다')

    # ⑨ ★★ **뒤집힌 이름으로 넣은 연결도 보인다** (2026-08-27) —
    #    `link_picker` 는 정렬해서 `ENTI_UREF` 로 쓰는데 여기는 `UREF_ENTI` 다.
    #    이 검사가 없으면 「저장은 되는데 목록이 (0)」이 다시 난다.
    set_links(conn, RID, [('ENTITY', 423, None)])
    conn.execute(
        'INSERT INTO %s(link_type, clicked_id, target_id, record_status)'
        " VALUES('ENTI_UREF', 777, ?, 'LIVE')" % LINK_TBL, (RID,))
    conn.commit()
    got = fetch_links(conn, RID)
    if ('ENTITY', 777, None) not in got:
        bad.append('★ 뒤집힌 이름(ENTI_UREF)으로 넣은 연결을 못 본다: %s' % got)
    if len(got) != 2:
        bad.append('뒤집힌 이름을 읽으면서 건수가 어긋난다: %s' % got)
    # ⑩ ★ **같은 짝이 두 이름으로 있어도 한 번만** 낸다
    conn.execute(
        'INSERT INTO %s(link_type, clicked_id, target_id, record_status)'
        " VALUES('ENTI_UREF', 423, ?, 'LIVE')" % LINK_TBL, (RID,))
    conn.commit()
    got = fetch_links(conn, RID)
    if len([g for g in got if g == ('ENTITY', 423, None)]) != 1:
        bad.append('★ 같은 짝이 두 이름으로 있으면 두 번 나온다: %s' % got)
    # ⑪ ★★ **뗄 때 뒤집힌 이름도 함께 숨는다** — 안 그러면 「숨겼는데 안 숨는다」
    set_links(conn, RID, [])
    got = fetch_links(conn, RID)
    if got:
        bad.append('★ 뗐는데 뒤집힌 이름이 살아남는다: %s' % got)
    # ⑫ ★ 탐지력 — 번호만 같은 **남의 행**을 건드리지 않는다
    conn.execute(
        'INSERT INTO %s(link_type, clicked_id, target_id, record_status)'
        " VALUES('BUNT_UREF', ?, -8888, 'LIVE')" % LINK_TBL, (RID,))
    conn.commit()
    set_links(conn, RID, [('VERSE', 1, None)])
    keep = conn.execute(
        'SELECT record_status FROM %s '
        " WHERE link_type='BUNT_UREF' AND clicked_id=? AND target_id=-8888"
        % LINK_TBL, (RID,)).fetchone()
    if not keep or (keep[0] or 'LIVE').upper() != 'LIVE':
        bad.append('★ 번호만 같은 남의 행을 숨겼다')

    # ⑬ ★★★ **`add_links` — 보태기만 한다**(314차 · 구절 자동 연결)
    set_links(conn, RID, [])
    conn.execute('DELETE FROM %s WHERE clicked_id=? OR target_id=?'
                 % LINK_TBL, (RID, RID))
    conn.commit()
    n = add_links(conn, RID, [('VERSE', 11, None), ('VERSE', 12, 15)])
    if n != 2 or len(fetch_links(conn, RID)) != 2:
        bad.append('★ add_links 가 보태지 못한다 — %s건' % n)
    #   ⓐ 멱등 — 두 번 불러도 한 번만
    if add_links(conn, RID, [('VERSE', 11, None)]) != 0:
        bad.append('★ add_links 가 멱등이 아니다')
    #   ⓑ **사람이 이어 둔 것을 안 지운다**(`set_links` 와 다른 몫)
    if len(fetch_links(conn, RID)) != 2:
        bad.append('★ add_links 가 있던 연결을 건드렸다')
    #   ⓒ ★★★ **사용자가 지운 것(HIDE)을 되살리지 않는다**
    conn.execute("UPDATE %s SET record_status='HIDE' WHERE link_type='UREF_VERS'"
                 ' AND clicked_id=? AND target_id=11' % LINK_TBL, (RID,))
    conn.commit()
    if add_links(conn, RID, [('VERSE', 11, None)]) != 0:
        bad.append('★★★ 사용자가 지운 연결을 되살렸다 — 그 판단을 없던 일로 '
                   '만든다')
    st = conn.execute(
        "SELECT record_status FROM %s WHERE link_type='UREF_VERS'"
        ' AND clicked_id=? AND target_id=11' % LINK_TBL, (RID,)).fetchone()
    if not st or (st[0] or 'LIVE').upper() != 'HIDE':
        bad.append('★ 지운 연결의 상태가 바뀌었다: %s' % (st,))
    #   ⓓ 뒤집힌 이름도 「있는 것」으로 센다
    conn.execute(
        'INSERT INTO %s(link_type, clicked_id, target_id, record_status)'
        " VALUES('VERS_UREF', 77, ?, 'LIVE')" % LINK_TBL, (RID,))
    conn.commit()
    if add_links(conn, RID, [('VERSE', 77, None)]) != 0:
        bad.append('★ 뒤집힌 이름을 못 보고 같은 짝을 또 넣는다')
    #   ⓔ 모르는 갈래·빈 목록
    if add_links(conn, RID, [('BOGUS', 5, None)]) != 0:
        bad.append('모르는 갈래를 보탠다')
    if add_links(conn, RID, []) != 0 or add_links(conn, RID, None) != 0:
        bad.append('빈 목록에서 보탠다')
    #   ⓕ ★★ **표식을 주면 적는다** — 안 적으면 동기화 밖으로 나간다
    add_links(conn, RID, [('VERSE', 31, None)], src=AUTO_SRC)
    so = conn.execute(
        "SELECT COALESCE(source,'') FROM %s WHERE link_type='UREF_VERS'"
        ' AND clicked_id=? AND target_id=31' % LINK_TBL, (RID,)).fetchone()
    if not so or so[0] != AUTO_SRC:
        bad.append('★★ add_links 가 표식(src)을 안 적는다: %s' % (so,))
    #   ⓖ 끝 절이 시작과 같으면 `end_id` 는 비운다(한 절 규약)
    add_links(conn, RID, [('VERSE', 21, 21)])
    e = conn.execute(
        "SELECT end_id FROM %s WHERE link_type='UREF_VERS'"
        ' AND clicked_id=? AND target_id=21' % LINK_TBL, (RID,)).fetchone()
    if not e or e[0] is not None:
        bad.append('한 절인데 end_id 가 찼다: %s' % (e,))

    # ⑭ ★★★ **`sync_links` — 글과 맞춘다**(315차 사용자 지시)
    conn.execute('DELETE FROM %s WHERE clicked_id=? OR target_id=?'
                 % LINK_TBL, (RID, RID))
    conn.commit()
    a, g = sync_links(conn, RID, [('VERSE', 11, None), ('VERSE', 12, None)])
    if (a, g) != (2, 0) or len(fetch_links(conn, RID)) != 2:
        bad.append('★ sync_links 가 처음에 둘을 못 넣는다 — %s' % ((a, g),))
    #   ⓐ 멱등
    if sync_links(conn, RID, [('VERSE', 11, None), ('VERSE', 12, None)]) != (0, 0):
        bad.append('★ sync_links 가 멱등이 아니다')
    #   ⓑ ★★★ **글에서 빠진 좌표는 사라진다**(이번 지시의 알맹이)
    a2, g2 = sync_links(conn, RID, [('VERSE', 11, None)])
    if (a2, g2) != (0, 1) or len(fetch_links(conn, RID)) != 1:
        bad.append('★★★ 글에서 빠진 좌표가 남는다 — %s' % ((a2, g2),))
    #   ⓒ 다시 적으면 돌아온다(실제로 지웠으니 되살아난다)
    a3, _ = sync_links(conn, RID, [('VERSE', 11, None), ('VERSE', 12, None)])
    if a3 != 1:
        bad.append('★ 좌표를 다시 적었는데 안 돌아온다 — %s' % a3)
    #   ⓓ ★★ **사람이 손으로 이은 것은 안 건드린다**(source 빈칸)
    conn.execute(
        'INSERT INTO %s(link_type, clicked_id, target_id, record_status)'
        " VALUES('UREF_VERS',?,13,'LIVE')" % LINK_TBL, (RID,))
    conn.commit()
    sync_links(conn, RID, [('VERSE', 11, None)])
    st = conn.execute(
        "SELECT COALESCE(record_status,'LIVE') FROM %s"
        " WHERE link_type='UREF_VERS' AND clicked_id=? AND target_id=13"
        % LINK_TBL, (RID,)).fetchone()
    if not st or st[0].upper() != 'LIVE':
        bad.append('★★ 사람이 이은 연결을 동기화가 지웠다: %s' % (st,))
    #   ⓔ ★★ **사람이 화면에서 지운 것(HIDE)은 되살리지 않는다**
    conn.execute(
        'INSERT INTO %s(link_type, clicked_id, target_id, record_status, source)'
        " VALUES('UREF_VERS',?,14,'HIDE',?)" % LINK_TBL, (RID, AUTO_SRC))
    conn.commit()
    sync_links(conn, RID, [('VERSE', 11, None), ('VERSE', 14, None)])
    st2 = conn.execute(
        "SELECT COALESCE(record_status,'LIVE') FROM %s"
        " WHERE link_type='UREF_VERS' AND clicked_id=? AND target_id=14"
        % LINK_TBL, (RID,)).fetchone()
    if not st2 or st2[0].upper() != 'HIDE':
        bad.append('★★ 사람이 지운 연결을 동기화가 되살렸다: %s' % (st2,))
    #   ⓕ 표식을 적는가 — 적지 않으면 다음 동기화가 사람 연결로 본다
    src = conn.execute(
        "SELECT COALESCE(source,'') FROM %s WHERE link_type='UREF_VERS'"
        ' AND clicked_id=? AND target_id=11' % LINK_TBL, (RID,)).fetchone()
    if not src or src[0] != AUTO_SRC:
        bad.append('★ 자동 연결에 표식(%s)을 안 적었다: %s' % (AUTO_SRC, src))
    #   ⓖ ★ 2026-10-25 원어 — 구절을 맞춰도 원어 연결은 그대로 · 원어는 원어 갈래로 맞춘다
    add_links(conn, RID, [('LEMMA', 2005485, None)], src=AUTO_SRC)
    sync_links(conn, RID, [('VERSE', 11, None)])
    if ('LEMMA', 2005485, None) not in fetch_links(conn, RID):
        bad.append('★★ 구절 동기화가 원어 연결을 지웠다')
    sync_links(conn, RID, [], add=False, kinds=('ENTITY', 'LEMMA'))
    if ('LEMMA', 2005485, None) in fetch_links(conn, RID):
        bad.append('★ 글에서 사라진 자동 원어 연결이 안 걷혔다')
    if ('VERSE', 11, None) not in fetch_links(conn, RID):
        bad.append('★★ 원어 동기화가 구절 연결을 지웠다')

    conn.execute('DELETE FROM %s WHERE clicked_id=? OR target_id=?'
                 % LINK_TBL, (RID, RID))
    conn.execute('DELETE FROM %s WHERE target_id=-8888' % LINK_TBL)
    conn.execute('DELETE FROM %s WHERE ref_id=?' % TEXT_TABLE, (RID,))
    conn.commit()
    conn.close()

    if bad:
        print('SELFTEST FAIL — %d건' % len(bad))
        for m in bad:
            print('  X ' + m)
        return 1
    print('SELFTEST PASS — 17개 항목')
    return 0


def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('--init', action='store_true')
    ap.add_argument('--backfill', action='store_true')
    ap.add_argument('--status', action='store_true')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    conn = appdb.connect()
    if a.init:
        print('%s 준비 · 현재 %d행' % (TABLE, init(conn)))
    if a.backfill:
        init(conn)
        print('단일 칸 → 링크 표 %d건 옮겨 적음' % backfill(conn))
        print('제목·본문 → 언어별 본문 %d건 옮겨 적음' % backfill_text(conn))
    print(status(conn))
    conn.close()
    return 0


if __name__ == '__main__':
    sys.exit(main())
