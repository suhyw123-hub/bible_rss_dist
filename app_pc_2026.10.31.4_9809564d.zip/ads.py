# -*- coding: utf-8 -*-
"""ads.py — 자체서빙 배너(후원/제휴/하우스). MVP: 로컬 config, 국가/언어 타겟, 추적 없음.

원칙(§ ad-config 설계):
  - **IP·SDK·추적 0.** 타겟은 로컬 user_country/user_lang 만.
  - config는 우선 로컬 기본(`_LOCAL_CONFIG`), 나중에 서버 fetch 캐시(`AD_CONFIG_CACHE`)로 대체.
  - 클릭 = 외부 브라우저(OneLink/쿠팡 등 현지화는 클릭 후 그쪽이 담당).
  - 오프라인 graceful: 캐시 없으면 로컬 기본(하우스광고)만.
"""
import io
import json
import locale
import time
import threading
import urllib.request
from urllib.parse import urlparse
import webbrowser
import tkinter as tk

import appdb

# 서버 ad-config 라우트 (usage_stats 와 동일 호스트 — Cloudflare Worker). 미배포 시 graceful.
AD_ENDPOINT = "https://api.hagahtorah.com/v1/ad-config"
_AD_UA = "GeminiBibleApp/1.0 (+ad-config)"   # Cloudflare 봇보호 403 회피용 명시 UA
_AD_TIMEOUT = 6


# ── user_config 헬퍼 ───────────────────────────────────────────────
def _cfg_get(db, key, default=None):
    try:
        with appdb.connect(db) as c:
            r = c.execute("SELECT config_val FROM user_config WHERE config_key=?", (key,)).fetchone()
        return r[0] if r and r[0] is not None else default
    except Exception:
        return default


def _cfg_set(db, key, val):
    with appdb.connect(db) as c:
        if c.execute("SELECT 1 FROM user_config WHERE config_key=?", (key,)).fetchone():
            c.execute("UPDATE user_config SET config_val=? WHERE config_key=?", (val, key))
        else:
            c.execute("INSERT INTO user_config(config_key,config_val) VALUES(?,?)", (key, val))
        c.commit()


# ── 국가/지역 ─────────────────────────────────────────────────────
# 광고/제휴 타겟용 큐레이션 목록(11 UI 언어 주요국 + 기타). 코드=ISO-3166-1 alpha-2.
COUNTRIES = [
    ('KR', '대한민국 (KR)'), ('US', 'United States (US)'), ('GB', 'United Kingdom (GB)'),
    ('JP', '日本 (JP)'), ('CN', '中国 (CN)'), ('TW', '臺灣 (TW)'), ('HK', '香港 (HK)'),
    ('DE', 'Deutschland (DE)'), ('AT', 'Österreich (AT)'), ('CH', 'Schweiz (CH)'),
    ('FR', 'France (FR)'), ('ES', 'España (ES)'), ('MX', 'México (MX)'),
    ('BR', 'Brasil (BR)'), ('PT', 'Portugal (PT)'), ('RU', 'Россия (RU)'),
    ('SA', 'السعودية (SA)'), ('AE', 'الإمارات (AE)'), ('CA', 'Canada (CA)'),
    ('AU', 'Australia (AU)'), ('OTHER', '기타 / Other'),
]
_CODE2NAME = {c: n for c, n in COUNTRIES}
_VALID = {c for c, _ in COUNTRIES}


def default_country():
    """OS 로캘에서 국가코드 추정(로컬에서만 읽음 — 전송·수집 없음)."""
    try:
        loc = (locale.getdefaultlocale()[0] or '')   # 예: 'ko_KR'
        if '_' in loc:
            cc = loc.split('_')[1].upper()
            return cc if cc in _VALID else 'OTHER'
    except Exception:
        pass
    return ''


def get_country(db):
    return _cfg_get(db, 'user_country', '') or default_country()


def set_country(db, code):
    _cfg_set(db, 'user_country', (code or '').upper())


def country_name(code):
    return _CODE2NAME.get((code or '').upper(), code or '')


# ── 광고 config (MVP = 로컬. 서버 fetch는 2차에서 AD_CONFIG_CACHE로 주입) ──
_LOCAL_CONFIG = {
    'kill_switch': False,
    'slots': {
        'p1_latest': {'enabled': True, 'max': 3},
        # ★ 쇼핑몰 — **기본이 꺼짐**이다. 상품을 담아 두고 서버 config 에서
        #   켜거나, 상품마다 `active_from` 을 적어 그날부터 보이게 한다.
        'shop': {'enabled': False, 'max': 10},
        # ★ 시작화면 띄 — 교회·단체 행사 홍보(1.txt 20번 6). **한 개만** 둔다 —
        #   사진 밖의 좁은 띄라 둘을 놓으면 글이 서로를 밀어낸다.
        'splash': {'enabled': False, 'max': 1},
    },
    # 자동 배치 기본 텍스트 없음 — 서버 config가 비어있으면 배너 영역은 비워둔다(공간 0).
    'creatives': [],
}


def _validate(cfg):
    return (isinstance(cfg, dict)
            and isinstance(cfg.get('creatives'), list)
            and isinstance(cfg.get('slots'), dict))


def load_config(db):
    """서버 캐시(AD_CONFIG_CACHE) 우선(검증 통과 시), 없으면 로컬 기본."""
    raw = _cfg_get(db, 'AD_CONFIG_CACHE', None)
    if raw:
        try:
            cfg = json.loads(raw)
            if _validate(cfg):
                return cfg
        except Exception:
            pass
    return _LOCAL_CONFIG


# ── 서버 fetch + 캐시 (원격제어 — 앱 업데이트 없이 관리자가 서버 config만 바꾸면 반영) ──
def fetch_config_blocking(db, app_ver=''):
    """GET ad-config → 검증 → user_config 캐시. 실패(오프라인/404/오류)면 조용히 무시(기존 유지)."""
    try:
        req = urllib.request.Request(AD_ENDPOINT, headers={'User-Agent': _AD_UA})
        with urllib.request.urlopen(req, timeout=_AD_TIMEOUT) as resp:
            cfg = json.loads(resp.read().decode('utf-8'))
        if not _validate(cfg):
            return False
        _cfg_set(db, 'AD_CONFIG_CACHE', json.dumps(cfg, ensure_ascii=False))
        _cfg_set(db, 'AD_CONFIG_FETCHED_AT', str(int(time.time())))
        return True
    except Exception:
        return False


def maybe_fetch(db, app_ver='', force=False):
    """throttle(config.refresh_hours, 기본 24h) 후 백그라운드 fetch. 시작 시 1회 호출."""
    try:
        if not force:
            last = int(_cfg_get(db, 'AD_CONFIG_FETCHED_AT', '0') or '0')
            hrs = int(load_config(db).get('refresh_hours', 24) or 24)
            if last and (int(time.time()) - last) < hrs * 3600:
                return
        threading.Thread(target=fetch_config_blocking, args=(db, app_ver), daemon=True).start()
    except Exception:
        pass


def in_window(c, today=None):
    """게재 기간 안인가 — `active_from` ≤ 오늘 ≤ `active_to`.

    ★ **「지금 만들어 두고 나중에 보인다」가 이 함수다.** 관리자가 날짜를
      적어 두면 그날이 되어야 사용자 화면에 나온다.
    ⚠ **비면 제한 없음**(관리자 도움말이 그렇게 적어 두었다) · 꼴이 이상하면
      **막지 않는다** — 오타 하나로 멀쩡한 배너가 통째로 사라지면 안 된다.
    ⚠ 날짜는 **그 PC 의 날짜**다(서버 시각을 안 묻는다) — 추적 0 원칙 그대로.
    """
    d = today or time.strftime('%Y-%m-%d')
    for key, ok in (('active_from', lambda a: a <= d),
                    ('active_to', lambda a: d <= a)):
        v = (c.get(key) or '').strip()
        if len(v) == 10 and v[4] == '-' and v[7] == '-' and not ok(v):
            return False
    return True


def pick_creatives(db, screen, lang, country, today=None):
    """화면+언어+국가+게재기간에 맞는 creative 목록(slot.max 까지). 추적 없음."""
    cfg = load_config(db)
    if cfg.get('kill_switch'):
        return []
    slot = (cfg.get('slots') or {}).get(screen)
    if not slot or not slot.get('enabled'):
        return []
    lang = (lang or '').upper()
    country = (country or '').upper()
    out = []
    for c in cfg.get('creatives', []):
        if screen not in (c.get('screens') or []):
            continue
        langs = [x.upper() for x in (c.get('langs') or [])]
        countries = [x.upper() for x in (c.get('countries') or [])]
        if langs and lang not in langs:
            continue
        if countries and country not in countries:
            continue
        if not in_window(c, today):
            continue          # ⚠ 게재 기간 밖 — 만들어는 두되 아직 안 보인다
        out.append(c)
    out.sort(key=lambda c: -int(c.get('weight', 1)))
    return out[: int(slot.get('max', 1))]


# ── 배너 이미지 다운로드/캐시 (선택적 — 외부 URL 또는 내 서버 URL 무엇이든) ──
# 원칙: 이미지 자동 로딩은 그 이미지 호스트에 IP가 보일 수 있음(외부 URL일 때). 클릭 시 노출과
# 같은 종류의 노출이며, 우리는 여전히 아무것도 수집하지 않음. 후원 이미지는 외부 URL 그대로,
# 이미지가 없으면 내 Cloudflare에 올린 URL을 넣어 혼용한다(코드는 동일).
_IMG_CACHE = {}        # url -> 리사이즈된 PIL.Image (성공한 것만; 세션 캐시·재다운로드 방지)
_IMG_TRIED = set()     # 다운로드 시도가 끝난 url(성공/실패 모두) — 폴링 종료 판단용
_IMG_MAX = (240, 160)  # 배너 썸네일 최대 크기(좌/중/우 3단 배치에 맞춤·비율 유지 축소)


def _fetch_image(url):
    """URL에서 이미지 받아 PIL.Image(리사이즈)로 캐시. 순수 데이터 작업(Tk 호출 없음 → 스레드 안전).
    성공이면 PIL.Image, 실패/ PIL 없음이면 None. 끝나면 _IMG_TRIED에 표시."""
    if url in _IMG_CACHE:
        return _IMG_CACHE[url]
    img = None
    try:
        from PIL import Image   # 스플래시/지도와 동일한 허용 예외 의존성
        req = urllib.request.Request(url, headers={'User-Agent': _AD_UA})
        with urllib.request.urlopen(req, timeout=_AD_TIMEOUT) as resp:
            data = resp.read()
        im = Image.open(io.BytesIO(data))
        im.load()
        if im.mode not in ('RGB', 'RGBA'):
            im = im.convert('RGB')
        im.thumbnail(_IMG_MAX)
        _IMG_CACHE[url] = im
        img = im
    except Exception:
        img = None
    finally:
        _IMG_TRIED.add(url)
    return img


# ── 배너 위젯 ──────────────────────────────────────────────────────
class AdBanner(tk.Frame):
    """배너 슬롯. 추적 없음. 클릭=외부 브라우저(또는 app: 콜백).
    slot.max 까지 여러 배너를 쌓아 표시. 이미지 있으면 이미지(백그라운드 다운로드·graceful),
    없으면 글자. 둘 다 없으면 그 배너는 건너뜀(빈 ※ 안 띄움). picks 0이면 빈 프레임(공간 0)."""

    def __init__(self, parent, db_path, screen, lang_getter=None,
                 app_action=None, i18n_t=None, cols=0, card_w=0, **kw):
        super().__init__(parent, **kw)
        self.db = db_path
        self.screen = screen
        # ★ cols>0 이면 **격자**(쇼핑몰) · 0 이면 지금처럼 가로 한 줄(배너).
        #   ⚠ 기존 호출부는 인자를 안 주므로 **한 줄도 안 바뀐다**.
        self.cols = int(cols or 0)
        if card_w:
            self._CARD_W = int(card_w)
        self.lang_getter = lang_getter or (lambda: 'KO')
        self.app_action = app_action          # 'app:xxx' click 처리 콜백(선택)
        self._t = i18n_t or (lambda k, d: d)   # i18n.t 주입(선택)
        self._photos = []   # ImageTk.PhotoImage 참조 보관(GC 방지)
        self.refresh()
        # config 서버 fetch는 앱 시작 ~3초 뒤 끝남. 패널이 먼저 만들어졌으면 옛/빈 설정을 잡으므로,
        # 한 번 늦게 다시 그려 갓 받은 최신 설정을 반영(이후 세션 내 변동은 다음 실행에 반영).
        try:
            self.after(6000, self._safe_refresh)
        except Exception:
            pass

    def _safe_refresh(self):
        try:
            if self.winfo_exists():
                self.refresh()
        except Exception:
            pass

    def refresh(self):
        for w in self.winfo_children():
            w.destroy()
        self._photos.clear()
        try:
            picks = pick_creatives(self.db, self.screen,
                                   self.lang_getter(), get_country(self.db))
        except Exception:
            picks = []
        if self.cols:
            # 격자 — 열 폭을 고르게(안 그러면 카드 너비가 들쭉날쭉하다)
            for i in range(self.cols):
                self.grid_columnconfigure(i, weight=1, uniform='shopcol')
        self._n = 0
        for c in picks:
            self._render_one(c)

    # 카드 = SNS 공유 미리보기 스타일(썸네일 + 설명문 + 링크). 테두리 없음. 좌/중/우 가로 배치.
    _CARD_BG = '#FFFFFF'
    _CARD_W = 240   # 카드 폭(설명문 줄바꿈 기준)

    def _render_one(self, c):
        # 설명문 = desc 우선(신규 단일언어 필드), 없으면 text_default/text_key(구버전 호환)
        desc = (c.get('desc') or '').strip() or (
            self._t(c.get('text_key', ''), c.get('text_default', ''))
            if c.get('text_key') else (c.get('text_default') or '').strip())
        img_url = (c.get('image') or '').strip()
        click = (c.get('click') or '').strip()
        if not desc and not img_url:
            return   # 보여줄 내용 없음 → 건너뜀

        # 카드(테두리 없음) — 좌/중/우 가로 배치
        card = tk.Frame(self, bg=self._CARD_BG, bd=0, highlightthickness=0)
        if self.cols:
            card.grid(row=self._n // self.cols, column=self._n % self.cols,
                      sticky='new', padx=6, pady=6)
            self._n += 1
        else:
            card.pack(side='left', anchor='n', fill='y', padx=8, pady=8)
        kids = [card]
        _nb = dict(bd=0, highlightthickness=0, bg=self._CARD_BG)   # 테두리선 0 공통

        # 썸네일(있으면) — 로딩 전엔 빈 자리, 비동기로 채움
        img_lbl = None
        if img_url:
            img_lbl = tk.Label(card, cursor='hand2',
                               width=self._CARD_W // 8, **_nb)   # 로딩 중 대략 폭 확보
            img_lbl.pack(fill='x')
            kids.append(img_lbl)

        # 설명문(있으면) — 썸네일 아래, 단일언어(타겟 언어로 입력)
        if desc:
            d = tk.Label(card, text=desc, fg='#2C3E50',
                         font=('Malgun Gothic', 9), wraplength=self._CARD_W,
                         justify='left', anchor='w', cursor='hand2', **_nb)
            d.pack(fill='x', pady=(4, 0))
            kids.append(d)

        # 링크 줄(클릭주소 있으면) — 공유카드처럼 도메인 표시
        if click and click.startswith('http'):
            host = ''
            try:
                host = urlparse(click).netloc.replace('www.', '')
            except Exception:
                host = ''
            ln = tk.Label(card, text='🔗 ' + (host or self._t('AD_OPEN', '원본 열기')),
                          fg='#2980B9', cursor='hand2',
                          font=('Malgun Gothic', 8), anchor='w', **_nb)
            ln.pack(fill='x')
            kids.append(ln)

        # 제휴 대가성 고지
        if c.get('type') == 'AFFILIATE':
            nt = tk.Label(card, text=self._t('AD_AFFILIATE_NOTICE',
                          '제휴 링크 — 구매 시 수수료를 받을 수 있습니다'),
                          fg='#AAB7B8', font=('Malgun Gothic', 7),
                          wraplength=self._CARD_W, anchor='w', justify='left', **_nb)
            nt.pack(fill='x')
            kids.append(nt)

        # 카드 전체 클릭 → 링크(없으면 무동작 = 배경/말씀카드)
        for w in kids:
            w.bind('<Button-1>', lambda _e, cc=c: self._on_click(cc))

        if img_url:
            self._load_image_async(img_url, img_lbl, card, bool(desc))

    def _load_image_async(self, url, lbl, holder, has_text):
        # 다운로드는 스레드(순수 데이터·Tk 호출 없음), Tk 적용은 메인스레드 폴링으로 — 스레드안전.
        threading.Thread(target=_fetch_image, args=(url,), daemon=True).start()
        self._poll_image(url, lbl, holder, has_text, 0)

    def _poll_image(self, url, lbl, holder, has_text, tries):
        try:
            if not lbl.winfo_exists():
                return
        except Exception:
            return
        if url in _IMG_TRIED:
            self._apply_image(_IMG_CACHE.get(url), lbl, holder, has_text)
            return
        if tries >= 80:   # ~12초 후 포기
            self._apply_image(None, lbl, holder, has_text)
            return
        self.after(150, lambda: self._poll_image(url, lbl, holder, has_text, tries + 1))

    def _apply_image(self, pil, lbl, holder, has_text):
        try:
            if not lbl.winfo_exists():
                return
        except Exception:
            return
        if pil is None:
            # 이미지 실패 → 설명문 있으면 썸네일 칸만 제거, 없으면 카드 통째 제거(빈칸 안 남김)
            try:
                (lbl if has_text else holder).destroy()
            except Exception:
                pass
            return
        try:
            from PIL import ImageTk
            photo = ImageTk.PhotoImage(pil)
        except Exception:
            try:
                (lbl if has_text else holder).destroy()
            except Exception:
                pass
            return
        self._photos.append(photo)   # 참조 유지
        lbl.config(image=photo, text='', width=0)

    def _on_click(self, c):
        url = c.get('click') or ''
        if url.startswith('app:') and callable(self.app_action):
            try:
                self.app_action(url[4:])
            except Exception:
                pass
        elif url.startswith('http'):
            try:
                webbrowser.open(url)
            except Exception:
                pass


# ── 자가 검증 ────────────────────────────────────────────────────────
def _selftest():
    """순수 판정만 잰다(Tk 없음). 양방향 — 막을 것을 막고 멀쩡한 것은 놓아 준다."""
    ok = [0]
    bad = [0]

    def t(name, cond, got=''):
        if cond:
            ok[0] += 1
            print('  OK   ' + name)
        else:
            bad[0] += 1
            print('  FAIL ' + name + ('   ' + repr(got) if got != '' else ''))

    D = '2026-09-26'
    # ⓐ 게재 기간 — 이 다섯이 이 기능의 전부다
    t('기간을 안 적으면 보인다', in_window({}, D))
    t('시작 전이면 안 보인다', not in_window({'active_from': '2026-12-01'}, D))
    t('시작했으면 보인다', in_window({'active_from': '2026-01-01'}, D))
    t('끝났으면 안 보인다', not in_window({'active_to': '2026-01-01'}, D))
    t('기간 안이면 보인다',
      in_window({'active_from': '2026-09-01', 'active_to': '2026-12-31'}, D))
    t('첫날·마지막날도 보인다(경계 포함)',
      in_window({'active_from': D, 'active_to': D}, D))
    # ⚠ 오타 하나로 멀쩡한 배너가 사라지면 안 된다
    t('날짜 꼴이 아니면 안 막는다', in_window({'active_from': '내일'}, D))
    t('빈칸·공백도 안 막는다', in_window({'active_from': '  ', 'active_to': ''}, D))

    # ⓑ pick_creatives — 슬롯·화면·언어·나라·기간이 함께 걸린다
    class _DB(object):
        pass

    cfg = {
        'kill_switch': False,
        'slots': {'shop': {'enabled': True, 'max': 10},
                  'off': {'enabled': False, 'max': 5}},
        'creatives': [
            {'id': 'now', 'screens': ['shop'], 'desc': 'a'},
            {'id': 'later', 'screens': ['shop'], 'desc': 'b',
             'active_from': '2026-12-01'},
            {'id': 'gone', 'screens': ['shop'], 'desc': 'c',
             'active_to': '2026-01-01'},
            {'id': 'ko', 'screens': ['shop'], 'desc': 'd', 'langs': ['KO']},
            {'id': 'other', 'screens': ['p1_latest'], 'desc': 'e'},
        ],
    }
    import json as _j
    saved = globals().get('load_config')
    globals()['load_config'] = lambda _db: _j.loads(_j.dumps(cfg))
    try:
        ids = [c['id'] for c in pick_creatives(None, 'shop', 'KO', 'KR', D)]
        t('기간 안인 것만 선택한다', ids == ['now', 'ko'], ids)
        t('다른 화면 것은 안 섞인다', 'other' not in ids)
        t('언어가 다르면 뺀다',
          'ko' not in [c['id'] for c in pick_creatives(None, 'shop', 'EN', 'KR', D)])
        t('슬롯이 꺼져 있으면 0개',
          pick_creatives(None, 'off', 'KO', 'KR', D) == [])
        t('없는 슬롯이면 0개',
          pick_creatives(None, 'nosuch', 'KO', 'KR', D) == [])
        cfg['kill_switch'] = True
        t('킬 스위치가 전부 끈다',
          pick_creatives(None, 'shop', 'KO', 'KR', D) == [])
        cfg['kill_switch'] = False
        # ★ 상한 — 관리자가 12개로 늘려도 코드가 안 바뀌어야 한다
        cfg['slots']['shop']['max'] = 1
        t('slot.max 를 지킨다',
          len(pick_creatives(None, 'shop', 'KO', 'KR', D)) == 1)
    finally:
        if saved:
            globals()['load_config'] = saved

    # ⓒ 기본 설정 — 쇼핑몰은 **꺼진 채로** 태어난다(§0-1 빈 서랍 금지)
    t('shop 슬롯이 있다', 'shop' in _LOCAL_CONFIG['slots'])
    t('shop 은 기본이 꺼짐', not _LOCAL_CONFIG['slots']['shop']['enabled'])
    t('기본 creatives 는 비어 있다', _LOCAL_CONFIG['creatives'] == [])

    print('')
    print('ads selftest %d/%d' % (ok[0], ok[0] + bad[0]))
    return 0 if not bad[0] else 1


if __name__ == '__main__':
    import sys as _sys
    if '--selftest' in _sys.argv:
        _sys.exit(_selftest())
    print('ads.py — 자체서빙 배너. 점검은 --selftest')
