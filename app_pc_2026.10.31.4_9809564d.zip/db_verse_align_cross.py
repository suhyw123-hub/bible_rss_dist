# -*- coding: utf-8 -*-
"""언어 간 절 정렬 검증기 (영구 도구) — 음역·문자체계가 달라도 통한다.

배경(사용자 제기 2026-07-27, 1.txt):
  "개역한글·BSB·ASV·WEB·KJV 등 여러 버전 사이에 같은 약명인데 다른 내용이 뜨는 구절을
   정확하게 찾아낼 수 있는가?"
  이 DB 는 17역본이 **같은 verse_id 슬롯**을 공유하므로, 절체계가 어긋나도 구조적 갭이
  안 생기고 **같은 자리 다른 내용**으로만 나타난다. 절별 설명문은 그 자리에 붙으므로
  한 절이라도 밀려 있으면 그 설명문은 통째로 엉뚱한 본문을 가리킨다.

db_verse_content_audit.py 는 영어 4역본 전용이다(철자를 공유해야 지문이 통한다).
이 도구는 **음역 언어**까지 덮는다. 스마야 ↔ Shemaiah, 雅各 ↔ Jacob 은 공유 문자가 없다.

원리 — 대응표를 데이터에서 스스로 만든다:
  1) 전권에서 (대상역본 토큰, KJV 고유명사) 가 같은 절에 함께 나온 횟수를 센다.
  2) 한 토큰이 특정 영어 이름과 압도적 비율로 공기하면 번역쌍으로 채택한다.
     밀림은 국소적이고 통계는 전권이므로 순환 논리가 아니다.
  3) 그 표로 절마다 지문을 영어로 환산해 **같은 자리 / 이웃 자리** 일치를 비교한다.
     같은 자리에서 어긋나면서 이웃 자리와 맞으면 그 역본은 거기서 밀려 있다.
     번역 변이(Jehovah/Yahweh)는 이웃과도 안 맞으므로 자동으로 걸러진다.

★ 0건 보고 전에 반드시 --selftest 로 탐지력을 확인한다.
  (2026-07-27 temp_code_greek_check.py 가 어휘집이 빈 채 수십 번 PASS 를 찍은 전례.)

용법:
  python -X utf8 db_verse_align_cross.py --version KRV --build   # 대응표 생성
  python -X utf8 db_verse_align_cross.py --version KRV           # 전권 검증
  python -X utf8 db_verse_align_cross.py --version KRV --selftest # 탐지력 확인
  python -X utf8 db_verse_align_cross.py --all                   # 전 역본 일괄
"""
import collections, importlib.util, json, os, re, sqlite3, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(ROOT, 'bible_master.db')
CACHE_DIR = os.path.join(ROOT, 'source_texts')

_spec = importlib.util.spec_from_file_location('aud', os.path.join(ROOT, 'db_verse_content_audit.py'))
AUD = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(AUD)

PIVOT = 'KJV'            # 대응표의 기준 역본
REF = ['KJV', 'ASV', 'BSB']   # 지문 비교 상대(합집합)

# ── 문자체계별 토큰화 ─────────────────────────────────────────────
KO_PARTICLE = ('이니라', '이요', '이라', '에게', '에서', '으로', '까지', '부터', '와', '과', '은', '는',
               '이', '가', '을', '를', '의', '도', '만', '요', '니', '라', '에', '로', '아', '야')
KO_RUN = re.compile(r'[가-힣]{2,7}')
KO_STOP = set('''하나님 여호와 이스라엘 예수 그리스도 아들 아들들 사람 사람들 자손 지파 족속 형제
아버지 어머니 아내 자녀 백성 왕이 왕은 왕의 제사장 선지자 이르되 가로되 말씀 그때 그러나 그리고
저희 우리 너희 자기 모든 이러 이와 같이 그가 그를 그의 것이 것을 하고 하며 하니 하여
장자 두목 방백 군대 성읍 땅에 땅을 마음 눈에 손에'''.split())

CJK_RUN = re.compile(r'[一-鿿]{2,4}')
CJK_STOP = set('''耶和華 上帝 神的 以色列 耶穌 基督 兒子 兒女 他們 我們 你們 這樣 因為 所以 就是
說話 甚麼 一切 眾人 百姓 祭司 先知 那時 於是 但是 如此 自己 他的 我的 你的'''.split())

LATIN_WORD = re.compile(r"[A-ZÀ-ÞА-Я][A-Za-zÀ-ÿА-я'\-]{2,}")
ARAB_WORD = re.compile(r'[ؠ-ي]{3,}')


def tok_ko(txt):
    out = set()
    for w in KO_RUN.findall(txt or ''):
        if w in KO_STOP:
            continue
        s = w
        for p in KO_PARTICLE:
            if len(s) > len(p) + 1 and s.endswith(p):
                s = s[:-len(p)]; break
        if 2 <= len(s) <= 5 and s not in KO_STOP:
            out.add(s)
    return out


def tok_cjk(txt):
    out = set()
    for w in CJK_RUN.findall(txt or ''):
        if w not in CJK_STOP:
            out.add(w)
    return out


def tok_latin(txt):
    """대문자로 시작하는 낱말(문장 첫 낱말 제외) — 독·불·서·포·러 공용."""
    out = set()
    for sent in re.split(r'(?<=[.;:!?])\s+|[“”‘’"()«»]', txt or ''):
        toks = re.findall(r"[A-Za-zÀ-ÿА-я'\-]+", sent)
        for i, w in enumerate(toks):
            if i == 0 and len(toks) > 1:
                continue
            if LATIN_WORD.fullmatch(w):
                out.add(w.lower()[:4])
    return out


def tok_arab(txt):
    return {w[:4] for w in ARAB_WORD.findall(txt or '')}


TOKENIZER = {'KRV': tok_ko, 'CUV': tok_cjk, 'CUVS': tok_cjk, 'ARB': tok_arab}


def tokenize(ver, txt):
    return TOKENIZER.get(ver, tok_latin)(txt)


# ── 대응표 ────────────────────────────────────────────────────────
def build_map(c, ver, min_count=6, min_ratio=0.45):
    pair = collections.Counter(); tot = collections.Counter()
    # fetchall 필수 — 같은 커서로 안쪽 쿼리를 돌리면 바깥 순회가 덮어써져 0개가 나온다.
    for (vid,) in c.execute("SELECT verse_id FROM bible_index ORDER BY verse_id").fetchall():
        d = dict(c.execute(
            "SELECT version_code, verse_text FROM bible_content "
            f"WHERE verse_id=? AND version_code IN (?,?)", (vid, ver, PIVOT)))
        src = tokenize(ver, d.get(ver)); en = AUD.names(d.get(PIVOT))
        if not src or not en:
            continue
        for k in src:
            tot[k] += 1
            for e in en:
                pair[(k, e)] += 1
    m = {}
    for (k, e), n in pair.items():
        if n >= min_count and n / tot[k] >= min_ratio:
            m.setdefault(k, set()).add(e)
    return {k: sorted(v) for k, v in m.items()}


def load_map(c, ver, rebuild=False):
    path = os.path.join(CACHE_DIR, f'_align_map_{ver}.json')
    if os.path.exists(path) and not rebuild:
        return json.load(open(path, encoding='utf-8'))
    m = build_map(c, ver)
    os.makedirs(CACHE_DIR, exist_ok=True)
    json.dump(m, open(path, 'w', encoding='utf-8'), ensure_ascii=False)
    return m


def fp(ver, txt, m):
    out = set()
    for k in tokenize(ver, txt):
        for e in m.get(k, ()):
            out.add(e)
    return out


# ── 검증 ──────────────────────────────────────────────────────────
def check(c, ver, m, book=None, minimum=3, th=0.20, nb_th=0.60, gap=0.40, store=None):
    where = 'WHERE bcode=?' if book else ''
    params = (book,) if book else ()
    rows = c.execute(f"SELECT verse_id,bcode,chapter,verse FROM bible_index {where} "
                     "ORDER BY verse_id", params).fetchall()
    order = [r[0] for r in rows]
    meta = {r[0]: (r[1], r[2], r[3]) for r in rows}
    inq = ','.join('?' * (len(REF) + 1))
    SRC = {}; EN = {}
    for vid in order:
        if store is not None:
            d = store[vid]
        else:
            d = dict(c.execute(
                "SELECT version_code, verse_text FROM bible_content "
                f"WHERE verse_id=? AND version_code IN ({inq})", (vid, ver, *REF)))
        SRC[vid] = fp(ver, d.get(ver), m)
        e = set()
        for r in REF:
            e |= AUD.names(d.get(r))
        EN[vid] = e
    hits = []
    for i, vid in enumerate(order):
        s, e = SRC[vid], EN[vid]
        if len(s) < minimum or len(e) < minimum:
            continue
        same = AUD.jaccard(s, e)
        if same >= th:
            continue
        best = 0.0; off = 0
        for k in (-2, -1, 1, 2):
            j = i + k
            if 0 <= j < len(order) and meta[order[j]][0] == meta[vid][0]:
                ne = EN[order[j]]
                if len(ne) >= minimum:
                    r = AUD.jaccard(s, ne)
                    if r > best:
                        best, off = r, k
        if best >= nb_th and best > same + gap:
            hits.append((vid, meta[vid], same, best, off, sorted(s), sorted(e)))
    return hits


def selftest(c, ver, m, book=13):
    rows = c.execute("SELECT verse_id FROM bible_index WHERE bcode=? ORDER BY verse_id",
                     (book,)).fetchall()
    order = [r[0] for r in rows]
    inq = ','.join('?' * (len(REF) + 1))
    base = {vid: dict(c.execute(
        "SELECT version_code, verse_text FROM bible_content "
        f"WHERE verse_id=? AND version_code IN ({inq})", (vid, ver, *REF))) for (vid,) in rows}
    sh = {}
    for i, vid in enumerate(order):
        d = dict(base[vid])
        if i + 1 < len(order) and ver in base[order[i + 1]]:
            d[ver] = base[order[i + 1]][ver]
        sh[vid] = d
    return len(check(c, ver, m, book, store=base)), len(check(c, ver, m, book, store=sh))


def lenshift(c, vers, book=None, min_v=8, edge=0.12):
    """언어 무관 레이어 — 절길이 프로파일 상관으로 **장 단위 밀림**을 잡는다.

    지문법(고유명사)은 두 곳에서 약하다: ① 이름 없는 절(시가·교리·율법) ② 아랍어처럼
    토큰화가 어려운 문자체계. 절 길이는 언어와 무관하게 보존된다 — 같은 내용이면
    그 역본 안에서의 상대 길이가 비슷하다.

    각 (역본, 장) 마다 그 역본의 상대 길이열을 **합의 프로파일**(다른 역본들의 중앙값)과
    offset -1 / 0 / +1 로 맞춰 보고, ±1 이 0 보다 뚜렷이 잘 맞으면 그 장은 밀려 있다.
    """
    where = 'WHERE bcode=?' if book else ''
    params = (book,) if book else ()
    idx = c.execute(f"SELECT verse_id,bcode,chapter,verse FROM bible_index {where} "
                    "ORDER BY verse_id", params).fetchall()
    mean = {v: c.execute("SELECT AVG(LENGTH(verse_text)) FROM bible_content "
                         "WHERE version_code=? AND verse_text<>''", (v,)).fetchone()[0] or 1
            for v in vers}
    L = collections.defaultdict(dict)
    ids = {r[0] for r in idx}
    for vid, vc, t in c.execute("SELECT verse_id,version_code,verse_text FROM bible_content").fetchall():
        if vid in ids and vc in mean and t:
            L[vid][vc] = len(t) / mean[vc]

    chapters = collections.defaultdict(list)
    for vid, bc, ch, vs in idx:
        chapters[(bc, ch)].append(vid)

    def corr(a, b):
        n = len(a)
        if n < 4: return -1.0
        ma, mb = sum(a) / n, sum(b) / n
        va = sum((x - ma) ** 2 for x in a); vb = sum((x - mb) ** 2 for x in b)
        if va <= 0 or vb <= 0: return -1.0
        return sum((a[i] - ma) * (b[i] - mb) for i in range(n)) / (va * vb) ** 0.5

    hits = []
    for (bc, ch), vids in sorted(chapters.items()):
        if len(vids) < min_v: continue
        cons = []
        for vid in vids:
            vals = sorted(L[vid].values())
            cons.append(vals[len(vals) // 2] if vals else 0.0)
        for v in vers:
            seq = [L[vid].get(v, 0.0) for vid in vids]
            if sum(1 for x in seq if x > 0) < min_v: continue
            sc = {}
            for off in (-1, 0, 1):
                a, b = [], []
                for i in range(len(vids)):
                    j = i + off
                    if 0 <= j < len(vids) and seq[i] > 0 and cons[j] > 0:
                        a.append(seq[i]); b.append(cons[j])
                sc[off] = corr(a, b)
            best = max(sc, key=sc.get)
            if best != 0 and sc[best] > sc[0] + edge and sc[best] > 0.5:
                hits.append((bc, ch, v, best, sc[0], sc[best]))
    return hits


def content_versions(c):
    return [r[0] for r in c.execute(
        "SELECT version_code FROM bible_content WHERE verse_text IS NOT NULL AND verse_text<>'' "
        "GROUP BY version_code HAVING COUNT(*)>20000 ORDER BY version_code")]


def main():
    try: sys.stdout.reconfigure(encoding='utf-8')
    except Exception: pass
    conn = sqlite3.connect(DB, timeout=120); c = conn.cursor()
    bn = {b: n for b, n in c.execute("SELECT book_code, short_name FROM book_names WHERE lang_code='KO'")}
    book = AUD.arg('--book', None, int)
    rebuild = '--build' in sys.argv

    if '--lenshift' in sys.argv:
        allv = content_versions(c)
        hits = lenshift(c, allv, book)
        print(f'★ 장 단위 밀림 의심 {len(hits)}건 (절길이 프로파일, 언어 무관)')
        per = collections.Counter(h[2] for h in hits)
        for v, n in per.most_common():
            print(f'  {v}: {n}장')
        print()
        # 등급 — 실측상 진짜 밀림은 0.80 이상, 오탐(표제 생략·CJK 띄어쓰기)은 0.5~0.78 에 몰린다.
        for bc, ch, v, off, s0, sb in sorted(hits, key=lambda x: (-x[5], x[2])):
            g = '확실' if sb >= 0.80 else ('의심' if sb >= 0.65 else '약함')
            print(f'  [{g}] {v:7s} {bn.get(bc,bc):5s} {ch:3d}장  offset {off:+d}  '
                  f'(정렬 {s0:.2f} -> 이동 {sb:.2f})')
        print('\n  ※ 0.80 미만은 표제 생략·CJK 띄어쓰기 등 길이 잡음일 가능성이 높다. 반드시 본문 대조.')
        return 0

    vers = content_versions(c) if '--all' in sys.argv else [AUD.arg('--version', 'KRV')]
    vers = [v for v in vers if v not in REF]

    for ver in vers:
        m = load_map(c, ver, rebuild)
        print(f'\n=== {ver} ===  대응표 {len(m)}개')
        if len(m) < 50:
            print('  ⚠ 대응표가 너무 작다 — 이 역본은 지문법으로 판정 불가(수집 갭 또는 토큰화 실패)')
            continue
        base, shifted = selftest(c, ver, m, book or 13)
        print(f'  탐지력 확인: 원본 {base}건 / 인위 1칸 밀림 {shifted}건', end='')
        if shifted < 10:
            print('  ⚠ 탐지력 부족 — 아래 결과를 신뢰하지 마라')
        else:
            print('  ✅')
        hits = check(c, ver, m, book)
        print(f'  ★ 절 밀림 의심 {len(hits)}건')
        per = collections.Counter(bn.get(h[1][0], h[1][0]) for h in hits)
        for b, n in per.most_common(12):
            print(f'     {b}: {n}건')
        for vid, (bc, ch, vs), same, best, off, s, e in sorted(hits, key=lambda x: -x[3])[:15]:
            print(f'     {bn.get(bc,bc)} {ch}:{vs} (vid {vid})  같은자리 {same:.2f} / {off:+d}칸 {best:.2f}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
