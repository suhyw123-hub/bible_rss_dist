# -*- coding: utf-8 -*-
"""cite_format — 구절 인용·원어 표시 **포맷**의 단일 소스 (317차-18 ⑨⑩ · data.md Z-2v · docs/1.txt 41).

사용자 「표시형식을 몇가지 포맷으로 제시하고 그 중에서 관리자/사용자가 선택하도록 · 다국어 사례를 모아서 추천」.

인용 포맷(`CITE`) — 따옴표·괄호는 **언어가 정한다**(`QUOTES`·`PARENS`) · 장절 구분은 `:` 고정(자동 연결과 안 부딪힌다)
  Q_REF      ① 본문 (약명)            “태초에 …” (창1:1)          · 기본(사용자 요청 꼴)
  REF_Q      ② 약명 본문              창1:1 “태초에 …”
  Q_REF_VER  ③ 본문 (약명, 역본)      “태초에 …” (창1:1, 개역한글)
  BLOCK      ④ 줄 인용               본문 한 줄 + 다음 줄 (창1:1)   ⚠ 대시로 시작하면 게이트가 기호로 막는다
원어 포맷(`ORIG`) — 음독은 **한국어만** 우리 DB 에 있다(`sys_entity_lemma`) · 다른 언어는 라틴 음역(악센트 뺌)
  M_T    ① 뜻(음독)            은혜(카리스)        · 사용자 글 기본(설명문 규칙과 같다)
  M_T_O  ② 뜻(음독, 원어)      은혜(카리스, χάρις)  · 관리자 연구자료 기본
  M_T_L  ③ 뜻(음독, 라틴)      은혜(카리스, charis)
  T_O    ④ 음독(원어)          카리스(χάρις)       · 옛 연구자료 게이트 꼴
  M_O_N  ⑤ 뜻(원어, 번호)      은혜(χάρις, G5485)
  M_T_N  ⑥ 뜻(음독, 번호)      은혜(카리스, G5485)  ← 2026-10-25 · 한글 글에서 읽기 쉽고 번호로 원어 연결이 확실하다
⚠ 고른 값은 사용자 = `user_config['CITE_FMT'/'ORIG_FMT']` · 관리자 = `sys_config` 같은 열쇠(AI 재료에 한 줄).
"""
import sys
import unicodedata

CITE = ['Q_REF', 'REF_Q', 'Q_REF_VER', 'BLOCK']
ORIG = ['M_T', 'M_T_O', 'M_T_L', 'T_O', 'M_O_N', 'M_T_N']
CITE_DEFAULT = {'USER': 'Q_REF', 'SYS': 'Q_REF'}
ORIG_DEFAULT = {'USER': 'M_T', 'SYS': 'M_T_O'}
CITE_LABEL = {'Q_REF': '본문 (약명)', 'REF_Q': '약명 본문', 'Q_REF_VER': '본문 (약명, 역본)', 'BLOCK': '줄 인용'}
ORIG_LABEL = {'M_T': '뜻(음독)', 'M_T_O': '뜻(음독, 원어)', 'M_T_L': '뜻(음독, 라틴)', 'T_O': '음독(원어)',
              'M_O_N': '뜻(원어, 번호)', 'M_T_N': '뜻(음독, 번호)'}
QUOTES = {'KO': ('“', '”'), 'EN': ('“', '”'), 'ZH': ('“', '”'), 'ZHT': ('「', '」'), 'JA': ('「', '」'),
          'DE': ('„', '“'), 'FR': ('« ', ' »'), 'ES': ('«', '»'), 'PT': ('“', '”'), 'RU': ('«', '»'),
          'AR': ('«', '»')}
PARENS = {'JA': ('（', '）'), 'ZH': ('（', '）'), 'ZHT': ('（', '）')}
CJK = ('KO', 'JA', 'ZH', 'ZHT')                          # 약명과 장절을 붙여 쓴다(창1:1)


def _cfg(conn, side, key, default):
    try:
        if side == 'SYS':
            r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?", (key,)).fetchone()
        else:
            r = conn.execute("SELECT config_val FROM user_config WHERE config_key=?", (key,)).fetchone()
        return (r[0] if r else '') or default
    except Exception:                                     # noqa: BLE001
        return default


def get_fmt(conn, side='USER'):
    """(인용 포맷, 원어 포맷) — 선택한 것이 없거나 모르는 값이면 기본."""
    c = _cfg(conn, side, 'CITE_FMT', CITE_DEFAULT[side])
    o = _cfg(conn, side, 'ORIG_FMT', ORIG_DEFAULT[side])
    return (c if c in CITE else CITE_DEFAULT[side]), (o if o in ORIG else ORIG_DEFAULT[side])


def set_fmt(conn, side='USER', cite=None, orig=None):
    for k, v, ok in (('CITE_FMT', cite, CITE), ('ORIG_FMT', orig, ORIG)):
        if v not in ok:
            continue
        if side == 'SYS':
            if conn.execute("UPDATE sys_config SET config_val=? WHERE config_key=?", (v, k)).rowcount == 0:
                conn.execute("INSERT INTO sys_config(config_key, config_val) VALUES(?,?)", (k, v))
        else:
            if conn.execute("UPDATE user_config SET config_val=? WHERE config_key=?", (v, k)).rowcount == 0:
                conn.execute("INSERT INTO user_config(config_key, config_val) VALUES(?,?)", (k, v))
    conn.commit()


# ══════════════════════════════════════════════════════════════════
#  구절
# ══════════════════════════════════════════════════════════════════
def abbr(conn, vid, end_vid=None, lang='KO'):
    """그 언어 약명 — 「창1:1」 · 「Gen 1:1-3」 · 장을 넘으면 「창1:30-2:3」."""
    lg = (lang or 'KO').upper()
    a = conn.execute("SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?", (vid,)).fetchone()
    if not a:
        return ''
    r = conn.execute("SELECT short_name FROM book_names WHERE book_code=? AND lang_code=?", (a[0], lg)).fetchone() \
        or conn.execute("SELECT short_name FROM book_names WHERE book_code=? AND lang_code='EN'", (a[0],)).fetchone()
    nm = (r[0] if r else str(a[0])) or ''
    s = '%s%s%d:%d' % (nm, '' if lg in CJK else ' ', a[1], a[2])
    if end_vid and int(end_vid) != int(vid):
        b = conn.execute("SELECT bcode, chapter, verse FROM bible_index WHERE verse_id=?", (end_vid,)).fetchone()
        if b:
            s += '-%d' % b[2] if b[1] == a[1] else '-%d:%d' % (b[1], b[2])
    return s


def version_for(conn, lang):
    """그 언어 기준 역본 — 본문이 실제로 있는 것만(일본어는 없다)."""
    try:
        import db_cite_gate as CG
        v = CG.version_for(lang)
    except Exception:                                     # noqa: BLE001
        v = None
    if v and conn.execute("SELECT 1 FROM bible_content WHERE version_code=? LIMIT 1", (v,)).fetchone():
        return v
    return None


def verse_text(conn, vid, end_vid=None, version='KRV'):
    """본문 — 여러 절이면 한 칸 띄워 잇는다(절 번호는 안 넣는다)."""
    e = int(end_vid or vid)
    rows = conn.execute("SELECT c.verse_text FROM bible_content c WHERE c.version_code=?"
                        " AND c.verse_id BETWEEN ? AND ? ORDER BY c.verse_id", (version, int(vid), e)).fetchall()
    return ' '.join((r[0] or '').strip() for r in rows if (r[0] or '').strip())


def version_label(conn, version, lang='KO'):
    if (lang or 'KO').upper() == 'KO' and version == 'KRV':
        return '개역한글'
    r = conn.execute("SELECT version_name FROM bible_version WHERE version_code=?", (version,)).fetchone()
    return (r[0] if r else version) or version


def render_cite(fmt, text, ref, lang='KO', vlabel=''):
    """포맷대로 한 덩어리 글."""
    lg = (lang or 'KO').upper()
    q1, q2 = QUOTES.get(lg, ('“', '”'))
    p1, p2 = PARENS.get(lg, ('(', ')'))
    sp = '' if lg in ('JA', 'ZH', 'ZHT') else ' '
    quoted = q1 + (text or '').strip() + q2
    if fmt == 'REF_Q':
        return '%s %s' % (ref, quoted)
    if fmt == 'Q_REF_VER':
        return '%s%s%s%s, %s%s' % (quoted, sp, p1, ref, vlabel, p2)
    if fmt == 'BLOCK':
        return '%s\n%s%s%s' % (quoted, p1, ref, p2)
    return '%s%s%s%s%s' % (quoted, sp, p1, ref, p2)


# ══════════════════════════════════════════════════════════════════
#  원어
# ══════════════════════════════════════════════════════════════════
def latin(s):
    """악센트를 뺀 라틴 음역(cháris → charis)."""
    return ''.join(ch for ch in unicodedata.normalize('NFD', s or '') if not unicodedata.combining(ch))


def lemma_candidates(conn, word, lang='KO', limit=30):
    """낱말 → 원어 후보 [(strong, 원어, 음독(그 언어 · 없으면 라틴), 라틴, 뜻, 출현)].

    ★ 2026-10-25 사용자 「헤세드를 입력했는데 표시되지 않는다 · 자기가 설정한 언어로 검색하는 것이 기본이고
      이차적으로는 영어 음독 · 히브리어·헬라어는 입력하지 않는다」 — 그전에는 주요용어 **이름**과 영어 **뜻**만 찾았다.
    차례 = ① 스트롱 번호 ② 원어 글자 ③ 음독(한국어 음독 = 주요용어 앵커 · 라틴 음역은 느슨하게 — hesed = cheçed)
           ④ 주요용어 이름(그 언어) ⑤ 한국어 음독 앞부분 ⑥ 영어 뜻 ⑦ 비슷한 라틴 음역(한두 글자 차이 · 앞에서 적게 찾았을 때만).
    ⚠ 승격 안 된 원어는 한국어 음독·뜻이 데이터에 없다 — 영어 음독·영어 뜻·번호로만 찾힌다.
    """
    import orig_ref as OR
    w = (word or '').strip()
    if not w:
        return []
    L = (lang or 'KO').upper()
    out, seen = [], set()
    occ_of = {}

    def push(st):
        st = (st or '').upper()
        if not st or st in seen or len(out) >= limit:
            return
        m = conn.execute("SELECT form, translit, occurrences, gloss FROM sys_lemma_master WHERE strong=?",
                         (st,)).fetchone()
        if not m:
            return
        seen.add(st)
        e = conn.execute("SELECT translit, gloss FROM sys_entity_lemma WHERE strong=?"
                         " AND COALESCE(record_status,'LIVE')='LIVE' ORDER BY sort_order LIMIT 1", (st,)).fetchone()
        lat = latin(m[1])
        tr = e[0] if (L == 'KO' and e and e[0]) else lat
        gl = (e[1] if (L == 'KO' and e and e[1]) else '') or (m[3] or '')
        out.append((st, m[0], tr, lat, gl[:60], m[2] or 0))

    def push_all(sts):
        form_, tr_, ent_, _g = OR._index(conn)
        occ = OR._EXTRA.get(id(conn), ({}, {}))[1]
        for st in sorted(set(sts), key=lambda x: (x not in ent_, -occ.get(x, 0), x)):
            push(st)

    form, tr, ent, _g = OR._index(conn)
    exact = OR._EXTRA.get(id(conn), ({}, {}))[0]
    if OR.STRONG.match(w):                                # ① 번호
        push(w)
    if OR._HEB_GRK.search(w):                             # ② 원어 글자
        push_all(exact.get(OR.exact_form(w)) or form.get(OR.norm_form(w)) or ())
    push_all(tr.get(OR.norm_tr(w)) or ())                 # ③ 음독 그대로(헤세드 · cháris)
    lk = OR.loose_tr(w)
    if len(lk) >= 3:
        push_all(OR._loose_index(conn).get(lk) or ())      # ③ 영어 음독 느슨하게(hesed · shalom)
    rows = conn.execute(                                  # ④ 주요용어 이름
        "SELECT l.strong FROM sys_entity_lemma l"
        " JOIN sys_text_asset t ON t.clicked_id=l.entity_id AND t.text_type='ENTITY_NAME'"
        " WHERE COALESCE(l.record_status,'LIVE')='LIVE' AND (t.contents=? OR t.contents LIKE ?)"
        " ORDER BY (t.contents=?) DESC, (UPPER(t.lang_code)=?) DESC, l.sort_order LIMIT ?",
        (w, w + ' %', w, L, limit)).fetchall()
    push_all([r[0] for r in rows])
    if len(w) >= 2 and not lk:                            # ⑤ 한국어 음독 앞부분(헤세 → 헤세드)
        push_all([r[0] for r in conn.execute(
            "SELECT DISTINCT strong FROM sys_entity_lemma WHERE translit LIKE ?"
            " AND COALESCE(record_status,'LIVE')='LIVE' LIMIT ?", (w + '%', limit)).fetchall()])
    if lk or not out:                                     # ⑥ 영어 뜻
        for (st,) in conn.execute(
                "SELECT strong FROM sys_lemma_master WHERE (gloss LIKE ? OR kjv_def LIKE ?)"
                " ORDER BY occurrences DESC LIMIT ?", ('%' + w + '%', '%' + w + '%', limit)).fetchall():
            push(st)
    if len(lk) >= 4 and len(out) < 8:                     # ⑦ 비슷한 라틴 음역(한 글자 · 긴 낱말은 두 글자 차이)
        near = []
        cap = 1 if len(lk) < 7 else 2
        for k2, sts in OR._loose_index(conn).items():
            if abs(len(k2) - len(lk)) <= cap and _within(lk, k2, cap):
                near.extend(sts)
        push_all(near)
    return out[:limit]


def _within(a, b, cap):
    """편집 거리 ≤ cap 인가(짧은 낱말용 · 넘으면 바로 그만둔다)."""
    if a == b:
        return True
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i] + [0] * len(b)
        for j, cb in enumerate(b, 1):
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb))
        if min(cur) > cap:
            return False
        prev = cur
    return prev[-1] <= cap


def render_orig(fmt, meaning, translit, form, lat, strong):
    m = (meaning or '').strip()
    if fmt == 'M_T_O':
        return '%s(%s, %s)' % (m, translit, form)
    if fmt == 'M_T_L':
        return '%s(%s, %s)' % (m, translit, lat)
    if fmt == 'T_O':
        return '%s(%s)' % (translit, form)
    if fmt == 'M_T_N':
        return '%s(%s, %s)' % (m, translit, strong)
    if fmt == 'M_O_N':
        return '%s(%s, %s)' % (m, form, strong)
    return '%s(%s)' % (m, translit)


def chosen(conn, side='SYS'):
    """사람이 실제로 선택한 적이 있는가 — 없으면 프롬프트의 옛 규칙을 그대로 둔다."""
    tbl = 'sys_config' if side == 'SYS' else 'user_config'
    try:
        return bool(conn.execute("SELECT 1 FROM %s WHERE config_key IN ('CITE_FMT','ORIG_FMT')"
                                 " AND COALESCE(config_val,'')<>''" % tbl).fetchone())
    except Exception:                                     # noqa: BLE001
        return False


def prompt_line(conn, side='SYS', lang='KO'):
    """AI 재료에 실을 한 줄 — 선택한 포맷의 **그 언어 보기**(사실 한 줄 · 규칙을 늘리지 않는다).

    보기 = 창 1:3 을 그 언어 기준 역본으로(없으면 영어 BSB) · 원어 = 은혜(카리스).
    """
    lg = (lang or 'KO').upper()
    c, o = get_fmt(conn, side)
    vid = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=1 AND chapter=1 AND verse=3").fetchone()
    ver, vlg = version_for(conn, lg), lg
    if not ver:
        ver, vlg = 'BSB', 'EN'
    txt = verse_text(conn, vid[0], None, ver) if vid else ''
    ref = abbr(conn, vid[0], None, vlg) if vid else 'Gen 1:3'
    ex_c = render_cite(c, txt, ref, vlg, version_label(conn, ver, vlg))
    if lg == 'KO':
        ex_o = render_orig(o, '은혜', '카리스', 'χάρις', 'charis', 'G5485')
    else:
        ex_o = render_orig(o, 'grace', 'charis', 'χάρις', 'charis', 'G5485')
    return '%s / %s' % (ex_c.replace('\n', ' / '), ex_o)


def selftest():
    import appdb
    ok = fail = 0

    def ck(c, m, got=''):
        nonlocal ok, fail
        if c:
            ok += 1
            print('  OK  ', m)
        else:
            fail += 1
            print('  FAIL', m, '|', got)
    c = appdb.connect()
    v = c.execute("SELECT verse_id FROM bible_index WHERE bcode=1 AND chapter=1 AND verse=1").fetchone()[0]
    ck(abbr(c, v, None, 'KO') == '창1:1' and abbr(c, v, v + 2, 'EN') == 'Gen 1:1-3', '약명 — 한국어 붙임 · 영어 띄움 · 구간',
       (abbr(c, v, None, 'KO'), abbr(c, v, v + 2, 'EN')))
    t = verse_text(c, v, None, 'KRV')
    ck(t.startswith('태초에'), '본문', t[:20])
    ck(render_cite('Q_REF', '태초에', '창1:1', 'KO') == '“태초에” (창1:1)', '① 본문 (약명)')
    ck(render_cite('REF_Q', 'Im Anfang', '1Mo 1:1', 'DE') == '1Mo 1:1 „Im Anfang“', '② 독일어 따옴표')
    ck(render_cite('Q_REF_VER', '初めに', '創1:1', 'JA', 'X') == '「初めに」（創1:1, X）', '③ 일본어 괄호·따옴표')
    ck(render_cite('BLOCK', 'a', 'Gen 1:1', 'EN') == '“a”' + chr(10) + '(Gen 1:1)', '④ 줄 인용 — 다음 줄 (약명)')
    ck(version_for(c, 'JA') is None and version_for(c, 'KO') == 'KRV', '일본어는 기준 역본 없음(본문 0행)')
    _pl = prompt_line(c, 'SYS', 'KO')
    ck('창1:3' in _pl and '은혜(' in _pl, '재료 한 줄 — 한국어 보기', _pl[:60])
    _pj = prompt_line(c, 'SYS', 'JA')
    ck('Gen 1:3' in _pj and 'grace(' in _pj, '재료 한 줄 — 본문 없는 언어는 영어 보기로', _pj[:60])
    cand = lemma_candidates(c, '은혜', 'KO')
    ck(cand and cand[0][0] == 'G5485' and cand[0][2] == '카리스' and cand[0][3] == 'charis', '★ 「은혜」 → 카리스 G5485',
       cand[:2])
    ck(render_orig('M_T_L', '은혜', '카리스', 'χάρις', 'charis', 'G5485') == '은혜(카리스, charis)', '원어 ③(사용자 예)')
    ck(lemma_candidates(c, 'grace', 'EN'), '영어 낱말은 사전 뜻에서 찾는다')
    # 게이트가 네 인용 꼴을 다 받는가
    import db_study_gate as SG
    for f in CITE:
        body = '제목' + chr(10) + ('본문 문장입니다. ' * 70) + chr(10) + render_cite(f, '태초에 하나님이', '창1:1', 'KO', '개역한글')
        bad = [x for x in SG.check(body) if not x.startswith('(')]
        ck(not bad, '★ 연구자료 게이트가 인용 포맷 %s 를 받는다' % f, bad)
    print('cite_format selftest: %s (%d/%d)' % ('OK' if not fail else 'FAIL', ok, ok + fail))
    return fail == 0


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print(__doc__)
