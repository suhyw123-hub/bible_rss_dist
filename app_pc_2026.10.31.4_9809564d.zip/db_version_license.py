# -*- coding: utf-8 -*-
"""성경 역본의 출처·라이선스 — 스키마 + 시드 + 배포 전 점검 (영구 도구, §0-5 KEEP)

**왜 컬럼으로 만드나.** 역본 설명(`bible_version_text`)에 서술문으로 묻어 두면 **셀 수 없다.**
§18-3 이 이미 유료 역본 온보딩(ESV·NIV·개역개정)을 논의하고 있는데, 그때 필요한 것은
「지금 배포물에 라이선스 미확인 역본이 몇 개인가」에 대한 **기계가 답하는 수**다.
사람이 서술문을 읽어 세는 방식은 §0-1(샘플 검수)이 막으려는 바로 그것이다.

    copyright_type   PUBLIC_DOMAIN | PERMISSIVE | COPYRIGHTED | UNVERIFIED
    license_note     판정 근거 (사용자 화면에 그대로 보인다 — 그래서 근거를 적는다)
    source_url       받아 온 곳

★ **판정을 지어내지 않는다.** 확인 못 한 것은 `UNVERIFIED` 로 둔다. 그것이 이 컬럼의 값어치다 —
  「모른다」를 셀 수 있어야 배포 전에 막을 수 있다.

  --selftest   (의무)
  --init       컬럼 추가 + 시드 (멱등)
  --check      배포 전 점검 — 본문이 있는데 미확인·유료인 역본을 센다
  --list       전체 목록
"""
import os, sys
import appdb

# 판정 근거를 함께 적는다. 근거 없는 판정은 넣지 않는다.
PD = 'PUBLIC_DOMAIN'
PERM = 'PERMISSIVE'
COPY = 'COPYRIGHTED'
UNK = 'UNVERIFIED'

SEED = {
    # ── 저작권 소멸 (발행 연도로 판단) ──
    'KJV':    (PD, '1769년 판. 발행 연도로 저작권 소멸. ⚠ 영국 내에서는 Crown copyright 가 남아 있다',
               'https://ebible.org/'),
    'ASV':    (PD, '1901년 발행. 저작권 소멸', 'https://ebible.org/'),
    'CUV':    (PD, '和合本 1919년 발행. 저작권 소멸', 'https://api.getbible.net/'),
    'CUVS':   (PD, '和合本(1919) 간체자 판. 저작권 소멸', 'https://api.getbible.net/'),
    'ARB':    (PD, 'Van Dyke 1865년 발행. 저작권 소멸', 'https://api.getbible.net/'),
    'SpaRV':  (PD, 'Reina-Valera 1909년 판. 저작권 소멸 (1960년판은 별개로 저작권 있음)',
               'https://api.getbible.net/'),
    'FreJND': (PD, 'Darby 역(1890년대). 저작권 소멸', 'https://api.getbible.net/'),
    'FreLSG': (PD, 'Louis Segond 1910년 발행. 저작권 소멸', 'https://api.getbible.net/'),
    'GerElb': (PD, 'Elberfelder 1905년 판. 저작권 소멸', 'https://api.getbible.net/'),
    'RusSyn': (PD, 'Синодальный перевод 1876년 발행. 저작권 소멸', 'https://api.getbible.net/'),
    'WLC':    (PD, 'Westminster Leningrad Codex — 본문은 저작권 소멸. '
                   '낱말층(Strong)은 CC BY 4.0 이며 배포물에 넣지 않는다(§18-10)', ''),
    'KRV':    (PD, '개역한글 1961년 발행. 구 저작권법의 단체명의 저작물 보호기간 50년이 2011년에 '
                   '끝났고, 2013년 70년 연장은 이미 만료된 것에 소급하지 않는다. '
                   '⚠ 상업 배포 전에 법률 확인을 권한다', 'https://www.bskorea.or.kr/'),
    # ── 자유 이용을 명시한 것 ──
    'WEB':    (PERM, 'World English Bible — 발행처가 퍼블릭 도메인으로 내놓았다',
               'https://ebible.org/'),
    'BSB':    (PERM, 'Berean Standard Bible — 발행처가 자유 이용을 허용한다',
               'https://berean.bible/'),
    'PorBL':  (PERM, 'Bíblia Livre — 자유 배포를 목적으로 만들어진 역본',
               'https://api.getbible.net/'),
    # ── 저작권 있음 ──
    'JLV':    (COPY, 'Japanese Living Bible — Tyndale House Publishers 저작권. '
                     '본문 미적재(0행). 적재하려면 라이선스 계약이 필요하다', ''),
    # ── 확인 못 한 것 — 지어내지 않는다 ──
    'TRC':    (UNK, 'Textus Receptus 본문(1550/1894)은 저작권이 소멸했으나, 흔히 유통되는 '
                    '파싱 모듈은 CC BY-NC-SA 를 선언한다(§18-11). 본문 미적재(0행). '
                    '어느 자료로 넣을지 정한 뒤 다시 판정할 것', ''),
    'COPBHC': (UNK, '콥트어 보하이라 신약 — 원 자료 출처·라이선스 미확인', ''),
    'COPSHC': (UNK, '콥트어 사히드 신약 — 원 자료 출처·라이선스 미확인', ''),
    'COPCNT': (UNK, '콥트어 신약 — 원 자료 출처·라이선스 미확인', ''),
}

COLS = (('copyright_type', "TEXT DEFAULT 'UNVERIFIED'"),
        ('license_note', 'TEXT'),
        ('source_url', 'TEXT'))


def init(conn):
    have = {r[1] for r in conn.execute('PRAGMA table_info(bible_version)')}
    for name, decl in COLS:
        if name not in have:
            conn.execute('ALTER TABLE bible_version ADD COLUMN %s %s' % (name, decl))
            print('  컬럼 추가 %s' % name)
    n = 0
    for code, (ct, note, url) in SEED.items():
        r = conn.execute('SELECT 1 FROM bible_version WHERE version_code=?', (code,)).fetchone()
        if not r:
            print('  ! 없는 역본 코드 — 건너뜀: %s' % code)
            continue
        conn.execute('UPDATE bible_version SET copyright_type=?, license_note=?, source_url=?'
                     ' WHERE version_code=?', (ct, note, url, code))
        n += 1
    conn.commit()
    print('  %d개 역본에 라이선스 기록' % n)
    miss = [r[0] for r in conn.execute(
        "SELECT version_code FROM bible_version WHERE copyright_type IS NULL"
        " OR copyright_type='' OR copyright_type='UNVERIFIED'")]
    if miss:
        print('  미확인으로 남은 역본 %d개: %s' % (len(miss), ' '.join(miss)))


def rows(conn):
    return conn.execute(
        'SELECT v.version_code, v.version_name, v.lang_code,'
        "  COALESCE(v.copyright_type,'UNVERIFIED'), COALESCE(v.license_note,''),"
        '  (SELECT COUNT(*) FROM bible_content bc WHERE bc.version_code=v.version_code)'
        ' FROM bible_version v ORDER BY 6 DESC, 1').fetchall()


def check(conn):
    """★ 배포 전 점검 — **본문이 있는데** 미확인이거나 저작권이 있는 역본을 센다.

    본문이 0행인 역본은 배포물에 없으므로 세지 않는다(TRC·JLV·WLC 가 그렇다).
    """
    bad = []
    for code, nm, lc, ct, note, n in rows(conn):
        if n > 0 and ct in (UNK, COPY):
            bad.append((code, nm, ct, n))
    print('배포 점검 — 본문이 실린 역본 중 문제')
    if not bad:
        print('  없음. 배포 가능')
    for code, nm, ct, n in bad:
        print('  <<< %-8s %-34s %-12s %d행' % (code, (nm or '')[:34], ct, n))
    return not bad


def listing(conn):
    print('%-8s %-4s %-13s %7s  %s' % ('code', 'lang', '판정', '행수', '근거'))
    for code, nm, lc, ct, note, n in rows(conn):
        print('%-8s %-4s %-13s %7d  %s' % (code, lc, ct, n, note[:66]))


def selftest():
    ok = True

    def chk(label, got, want=True):
        nonlocal ok
        good = bool(got) == bool(want)
        ok &= good
        print('  [%s] %s' % ('PASS' if good else 'FAIL', label))

    vals = {v[0] for v in SEED.values()}
    chk('판정값이 넷 안에 있다', vals <= {PD, PERM, COPY, UNK})
    chk('모든 시드에 근거가 있다', all(v[1].strip() for v in SEED.values()))
    chk('미확인을 실제로 남겨 뒀다 (지어내지 않았다)', UNK in vals)
    chk('저작권 있는 것도 있다', COPY in vals)
    # ★ 탐지력 — 본문이 실린 미확인 역본을 **잡아야** 한다.
    #   이것이 죽으면 「없음. 배포 가능」만 찍는 껍데기가 된다.
    import sqlite3
    m = sqlite3.connect(':memory:')
    m.execute('CREATE TABLE bible_version (version_code TEXT, version_name TEXT, lang_code TEXT,'
              ' copyright_type TEXT, license_note TEXT, source_url TEXT)')
    m.execute('CREATE TABLE bible_content (version_code TEXT)')
    m.execute("INSERT INTO bible_version VALUES('X','시험','EN','UNVERIFIED','','')")
    m.execute("INSERT INTO bible_content VALUES('X')")
    chk('본문 있는 미확인 역본을 잡는다', not check(m))
    m.execute("UPDATE bible_version SET copyright_type='PUBLIC_DOMAIN'")
    chk('확인된 역본은 통과시킨다', check(m))
    m.execute("UPDATE bible_version SET copyright_type='COPYRIGHTED'")
    chk('저작권 있는 역본도 잡는다', not check(m))
    m.execute('DELETE FROM bible_content')
    chk('본문 0행이면 배포물에 없으므로 세지 않는다', check(m))
    print('selftest', 'PASS' if ok else 'FAIL')
    return ok


if __name__ == '__main__':
    a = sys.argv
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect()
    if '--init' in a:
        init(conn)
    if '--check' in a:
        check(conn)
    if '--list' in a:
        listing(conn)
