# -*- coding: utf-8 -*-
"""RSS 자동 수집 CLI (영구 도구) — OS 스케줄러(Windows 작업 스케줄러)용.

사용:
  python db_rss_collect.py            # 묵상 채널 — 기한 도래(check_interval_days)만 (매일 05:00 작업)
  python db_rss_collect.py --news     # 뉴스 채널 — 그 사이트 시각 12·17·22시 회차(rss_slots · 매시 작업)
  python db_rss_collect.py --all      # 활성 피드 전체 수집(기한 무시)
  python db_rss_collect.py --report   # 회차 기록 — 받은 수 · 새 글 · 이미 있던 글 · 넘침 · 게시 시각

Windows 작업 스케줄러 등록 예:
  프로그램: pythonw.exe
  인수:    "<앱 폴더>/db_rss_collect.py"
  트리거:  매일 새벽 등 (피드별 주기는 DB check_interval_days로 제어)

수집 결과는 sys_ref_asset(is_active=0, relevance 플래그)에 저장 → 관리자 검토 탭에서 검토.
관련성은 본문 기준 소프트 플래그(하드 폐기 없음, §19-5). 유튜브 링크만 제외.
"""
import io
import os
import sys
# ★ 2026-10-24 작업 스케줄러는 pythonw(창 없음)로 부른다 — 그때 sys.stdout 이 None 이라 감싸다 죽었다
#   (작업 결과 1 · 자동 수집이 한 번도 안 돌았다 · 손으로 돌리면 화면이 있어 멀쩡했다). 창이 없으면 기록 파일로 쓴다.
if sys.stdout is None or not hasattr(sys.stdout, 'buffer'):
    sys.stdout = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), '_rss_collect.log'), 'a', encoding='utf-8')
    sys.stderr = sys.stdout
else:
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:  # noqa: BLE001
        pass
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'admin'))

import appdb
import panel_ref_collector as P   # collect_one_feed / due_feed_ids 재사용

DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bible_master.db')


def main():
    import rss_slots
    all_mode = '--all' in sys.argv
    news_mode = '--news' in sys.argv
    now = datetime.now().isoformat(timespec='seconds')
    conn = appdb.connect(DB, timeout=30)
    rss_slots.ensure(conn)
    if '--report' in sys.argv:
        print(rss_slots.report(conn))
        return
    slot_of = {}
    if all_mode:
        ids = [r[0] for r in conn.execute(
            "SELECT feed_id FROM sys_rss_feed WHERE record_status='LIVE' AND enabled=1 ORDER BY feed_id")]
    elif news_mode:
        slot_of = dict(rss_slots.news_due(conn))
        ids = list(slot_of)
    else:
        ids = P.due_feed_ids(conn, now, kinds=('DEVOTIONAL',))

    print(f"[{now}] 자동 수집 시작 — 대상 피드 {len(ids)}개 "
          f"({'전체' if all_mode else '뉴스 회차' if news_mode else '묵상 기한 도래'})")
    total_new = total_low = 0
    for fid in ids:
        row = conn.execute(
            "SELECT feed_id, feed_url, entity_id, lang_code, site_name, max_results "
            "FROM sys_rss_feed WHERE feed_id=?", (fid,)).fetchone()
        if not row:
            continue
        sid, feed_url, entity_id, lang_code, sname, maxres = row
        print(f"\n[ {sname} ]")
        try:
            new_c, low, recv = P.collect_one_feed(
                conn, sid, feed_url, entity_id, lang_code, sname, maxres, now,
                log=lambda m: print(m, end=''), slot=slot_of.get(sid, 'ALL' if all_mode else 'DAILY'))
            total_new += new_c
            total_low += low
            print(f"  → 신규 {new_c}건 (저관련 {low}건)")
        except Exception as e:
            print(f"  [오류] {type(e).__name__}: {str(e)[:80]}")
            try:   # 실패도 회차로 적는다 — 그 사이트가 자주 막히는지 보인다
                conn.execute("UPDATE sys_rss_feed SET last_checked=? WHERE feed_id=?", (now, sid))
                rss_slots.log(conn, sid, slot_of.get(sid, 'DAILY'), 0, 0, 0, [], err=f"{type(e).__name__}: {e}")
                conn.commit()
            except Exception:
                pass
    conn.close()
    print(f"\n[완료] 총 신규 {total_new}건 (저관련 {total_low}건) — 관리자 검토 탭에서 검토하세요.")


if __name__ == '__main__':
    main()
