# -*- coding: utf-8 -*-
"""오른쪽에서 왼쪽으로 읽는 글자를 화면에 놓는다 — **정렬만** 한다 (2026-09-16 개정).

★★★ 2026-09-16 실측 — **Tk 는 히브리어·아랍어를 제대로 그린다.** 뒤집으면 거꾸로 된다.
    사용자 지적(1.txt 7번 · 「원어 탭의 히브리어가 일반 표시와 정반대다. 원래 데이터가
    그런가, 네가 방향을 전환시킨 것인가」) — **내가 뒤집은 것이었다.**
    같은 글자를 `tk.Label` · `ttk.Treeview` 칸 · `tk.Text` 에 **원문 그대로**와 **뒤집어서**
    나란히 그려 화면을 찍어 견주었다(`_hebrew.png` · `_hebrew2.png`):
      · אֱלֹהִים 원문 그대로 → 알레프가 오른쪽, 멤 소핏이 왼쪽 — **맞다.**
      · 뒤집은 것 → 거울처럼 — **틀리다.**
      · 「카보드(כָּבוֹד)는 무겁다는 뜻 · אֵל־שַׁדַּי 12장」 같은 **섞인 줄**도 원문 그대로가 맞다.
      · 아랍어 창 1:1(ARB) — 연결(shaping)과 방향 둘 다 **원문 그대로**가 맞고, 뒤집으면
        연결이 풀리고 낱말 차례도 거꾸로다.
    Windows 의 글자 그리기(Uniscribe/DirectWrite)가 줄 안의 양방향 배치를 이미 하고,
    Tk 8.6.15 는 그것을 그대로 쓴다. 2026-08-13 의 「첫 글자 x=2, 끝 글자 x=109」는
    **글자 폭 계산**(`font.measure`)이었지 그려진 화면이 아니었다 — 화면을 찍어 보지 않고
    결론을 냈고, 그 뒤로 한 달 동안 히브리어가 **전부 거꾸로** 나갔다(lex_panel · 주요용어 ·
    역본비교 · 도서 인용 · 가계도 · 여정). ⇒ **화면에 관한 결론은 화면을 찍어서 낸다.**

★★★ 2026-09-23 개정 — **정렬은 언어 코드가 정한다.**
    사용자 신고 「연구자료 : **여호와여 일어나소서, 에봇**... 아랍어처럼 오른쪽으로
    정렬되어 버렸다」 → 「**언어코드에 따라 달라져야 한다**」.
    ⚠⚠⚠ 범인은 **`has_rtl` 을 정렬 판정에 쓴 것**이었다. 그 함수는 「하나라도
      있는가」를 묻는데, 원어를 한 낱말 인용한 한국어 글도 참이 된다:
      | 글 | 히브리 글자 | 전체 |
      |---|---|---|
      | 여호와여 일어나소서 | **4** (קוּם) | 2,116 |
      | 에봇 | **46** | 21,204 (0.2%) |
    ⇒ **`rtl_align(글, lang)` 하나로 정한다** — 언어 코드가 있으면 그것이 이기고,
      없으면 **주된 글자**로 짐작한다(「하나라도」가 아니다).
    ⚠ `has_rtl` 은 **뜻이 다르므로 안 바꿨다** — 「원어가 섞였나」를 묻는 자리가
      따로 있다. **정렬에 그것을 쓰지 말 것.**

무엇을 하나
    `for_display(s)` — **아무것도 바꾸지 않는다**(항등). 부르는 곳 30여 자리를 안 고치려고
    이름을 남겼다. 새 코드는 부르지 않아도 된다.
    **`rtl_align(s, lang)`** — **오른쪽에 붙일 것인가**. 정렬은 이 문 하나로 정한다.
    `is_rtl_lang(code)` — 그 언어가 오른쪽에서 왼쪽으로 쓰는가(`RTL_LANGS` 단일 소스).
    `is_rtl_text(s)` — 언어를 모를 때의 되받이. **주된 글자**로 짐작한다.
    `has_rtl(s)` — 오른쪽 글자가 **하나라도 있는가**. ⚠ **정렬용이 아니다.**
    `insert(widget, s, tags, lang=…)` — `tk.Text` 에 넣되 RTL 이면 **오른쪽 정렬 태그**.
    `label(s, lang=…)` — `tk.Label` 용 `(글, 정렬옵션)`. RTL 이면 `anchor='e'`.

⚠ **저장·검색·비교는 논리 순서 원문으로 한다**(CLAUDE.md §0-3) — 이제 화면도 원문 그대로다.
⚠ 정렬은 남긴다 — 순수 RTL 줄을 왼쪽에 붙이면 문장 끝 마침표가 왼쪽 끝에 와 보기 흉하다
  (실측 아랍어 창 1:1). 오른쪽에 붙이면 자연스럽다.
"""

# RTL 문자 구간 — 히브리 · 아랍 · 시리아 · 히브리/아랍 표현형
_RTL_RANGES = (
    (0x0590, 0x05FF),   # 히브리 (자음 · 니쿠드 · 악센트)
    (0x0600, 0x06FF),   # 아랍
    (0x0700, 0x074F),   # 시리아
    (0x0750, 0x077F),   # 아랍 보충
    (0x08A0, 0x08FF),   # 아랍 확장 A
    (0xFB1D, 0xFB4F),   # 히브리 표현형
    (0xFB50, 0xFDFF),   # 아랍 표현형 A
    (0xFE70, 0xFEFF),   # 아랍 표현형 B
)


def is_rtl_char(ch):
    o = ord(ch)
    return any(a <= o <= b for a, b in _RTL_RANGES)


def has_rtl(s):
    return bool(s) and any(is_rtl_char(ch) for ch in s)


# ★★★ **오른쪽에서 왼쪽으로 쓰는 언어** (2026-09-23 사용자 「**언어코드에
#   따라 달라져야 한다**」). 지금 이 앱에 있는 것은 AR·HE 둘이고
#   (`sys_language`), 나머지는 나중에 들어와도 저절로 맞게 두었다.
#   ⚠ **여기에만 적는다** — 화면마다 `code == 'AR'` 을 적으면 히브리어를
#     넣는 날 한 곳이 반드시 빠진다.
RTL_LANGS = frozenset({
    'AR',    # 아랍어
    'HE',    # 히브리어
    'FA',    # 페르시아어
    'UR',    # 우르두어
    'SYR',   # 시리아어
    'ARC',   # 아람어
    'YI',    # 이디시어
    'DV',    # 디베히어
    'PS',    # 파슈토어
    'CKB',   # 중앙 쿠르드어
})


def is_rtl_lang(code):
    """이 언어 코드는 오른쪽에서 왼쪽으로 쓰는가.

    ⚠ `ar-SA`·`he_IL` 같은 꼬리가 붙어 와도 알아본다 — 우리 DB 는 `AR` 로
      적지만 밖에서 온 값이 섞일 자리가 있다.
    """
    if not code:
        return False
    head = str(code).strip().upper().replace('_', '-').split('-')[0]
    return head in RTL_LANGS


def rtl_letters(s):
    """(오른쪽글자 수, 왼쪽글자 수) — **센 글자만** 센다.

    ⚠ 모음기호·악센트(`Mn`)는 빼고 센다 — 히브리어는 한 낱말에 니쿠드가
      글자만큼 붙어 있어 함께 세면 그 몇 낱말이 문단 전체를 이긴다.
    ⚠ 숫자·문장부호·빈칸은 **어느 쪽도 아니다**(유니코드가 중립이라 부른다) —
      세면 라틴 구두점이 많은 아랍어 글이 LTR 로 뒤집힌다.
    """
    import unicodedata
    r = l = 0
    for ch in s or '':
        if unicodedata.category(ch) == 'Mn':
            continue
        if is_rtl_char(ch):
            r += 1
        elif ch.isalpha():
            l += 1
    return r, l


def is_rtl_text(s):
    """**글자로 짐작한다** — 언어 코드를 모르는 자리의 되받이.

    센 글자를 세어 오른쪽이 더 많을 때만 참. 「하나라도 있으면」이 아니다.
    """
    r, l = rtl_letters(s)
    return r > l


def rtl_align(s='', lang=None):
    """**이 글을 오른쪽에 붙일 것인가** — 정렬은 이 문 하나로 정한다.

    ★★★ 2026-09-23 사용자 지시 — 「**언어코드에 따라 달라져야 한다**」.
      그전에는 `has_rtl`(하나라도 있으면)로 정해서, 원어를 네 글자 인용한
      **한국어 연구자료**가 통째로 오른쪽에 붙었다(「여호와여 일어나소서」
      2,116자 중 히브리 4자 · 「에봇」 21,204자 중 46자 — 실측).
    · `lang` 을 주면 **그것이 이긴다**(사실).
    · 없으면 글자로 짐작한다(`is_rtl_text`).
    ⚠ 부르는 쪽이 언어를 아는데도 안 넘기면 짐작으로 떨어진다 — **아는
      자리는 반드시 넘긴다.**
    """
    if lang:
        return is_rtl_lang(lang)
    return is_rtl_text(s)


def for_display(s, base=None):
    """화면에 그릴 문자열 — **원문 그대로**(2026-09-16). `base` 는 옛 호출부 호환용."""
    return s


TAG = 'bidi_rtl'          # 오른쪽 정렬 태그 이름 — 화면마다 새로 짓지 않는다


def insert(widget, s, tags=(), tag=TAG, at='end', lang=None):
    """`tk.Text` 에 넣는다. RTL 글이면 **오른쪽 정렬 태그**를 얹는다(글자는 안 건드린다).

        bidi.insert(txt, body, ('verse',))

    ⚠ 태그는 **쓰는 순간 만든다.** Tk 는 나중에 만든 태그를 더 세게 치므로,
      화면이 미리 만들어 둔 `'verse'` 같은 태그의 정렬을 이것이 이긴다.
    ⚠ tkinter 를 부르지 않는다 — 위젯이 `insert`·`tag_configure` 만 가지면 된다.
    돌려주는 값 — RTL 이었는가."""
    s = s or ''
    tags = tuple(tags)
    # ⚠ **`has_rtl` 이 아니라 `rtl_align`** — 언어 코드가 있으면 그것이 정하고,
    #   없으면 주된 글자로 짐작한다(2026-09-23 사용자 지시).
    if not rtl_align(s, lang):
        widget.insert(at, s, tags)
        return False
    try:
        widget.tag_configure(tag, justify='right')
        widget.tag_raise(tag)
    except Exception:
        pass
    widget.insert(at, s, tags + (tag,))
    return True


def label(s, lang=None):
    """`tk.Label` 에 넘길 것 — `(글, 정렬옵션)`. RTL 이면 오른쪽 붙임, 아니면 옵션 없음.

    `lang` 을 주면 **언어 코드가 정한다**(2026-09-23).
    """
    s = s or ''
    if not rtl_align(s, lang):
        return s, {}
    return s, {'justify': 'right', 'anchor': 'e'}


# ── 자가 검증 ────────────────────────────────────────────────────────────────

def _selftest():
    bad = []
    he = 'בְּרֵאשִׁ֖ית בָּרָ֣א אֱלֹהִ֑ים'
    ar = 'فِي ٱلْبَدْءِ خَلَقَ ٱللَّهُ'
    mix = '카보드(כָּבוֹד)는 무겁다 · אֵל־שַׁדַּי 12장 · Bible (x)'
    # ① 어떤 글도 바꾸지 않는다 — 2026-09-16 실측: Tk 가 스스로 바로 그린다
    for s in ('In the beginning', '태초에 하나님이', '창 1:1', '', he, ar, mix, 'ב (ר)'):
        if for_display(s) != s:
            bad.append(f'글자를 건드렸다: {s!r}')
    if for_display(None) is not None:
        bad.append('None 을 바꿨다')
    # ② RTL 판정
    if not has_rtl(he) or not has_rtl(ar) or not has_rtl(mix):
        bad.append('RTL 을 못 알아본다')
    if has_rtl('abc 123') or has_rtl('태초에') or has_rtl(''):
        bad.append('RTL 이 없는 글을 RTL 이라 한다')

    # ②-2 **언어 코드가 잣대다** (2026-09-23 사용자 「언어코드에 따라
    #   달라져야 한다」 · 연구자료가 아랍어처럼 오른쪽으로 갔다는 신고)
    for code in ('AR', 'ar', 'HE', 'he-IL', 'ar_SA'):
        if not is_rtl_lang(code):
            bad.append('RTL 언어를 못 알아본다: %r' % code)
    for code in ('KO', 'EN', 'ZHT', 'RU', '', None):
        if is_rtl_lang(code):
            bad.append('LTR 언어를 RTL 이라 한다: %r' % code)
    # ★ **언어 코드가 글자를 이긴다** — 이것이 이 고침의 알맹이다
    ko_quote = '다윗은 ' + ('여호와여 일어나소서 하고 외쳤습니다. ' * 40) \
        + '이 말의 원어는 קוּם 입니다.'
    if rtl_align(ko_quote, 'KO'):
        bad.append('원어를 인용한 KO 글을 오른쪽에 붙인다')
    if not rtl_align('(본문 준비 중)', 'AR'):
        bad.append('AR 인데 글자가 라틴이라고 왼쪽에 붙인다')
    # ②-3 언어를 모르면 **주된 글자**로 짐작한다 (「하나라도」가 아니다)
    if rtl_align(ko_quote):
        bad.append('원어를 인용한 한국어 글을 오른쪽에 붙인다(짐작)')
    if not has_rtl(ko_quote):
        bad.append('원어가 섞인 것은 has_rtl 이 여전히 참이어야 한다')
    if not rtl_align(he) or not rtl_align(ar):
        bad.append('순수 RTL 글을 왼쪽에 붙인다')
    if rtl_align(mix) or rtl_align('태초에') or rtl_align(''):
        bad.append('LTR 이 주된 글을 오른쪽에 붙인다')
    if not rtl_align('فِي ٱلْبَدْءِ, (1:1) -- "خَلَقَ".'):
        bad.append('문장부호가 많은 아랍어를 LTR 이라 한다')
    if rtl_letters('אֱלֹהִים')[0] != 5:
        bad.append('모음기호를 글자로 센다: %r' % (rtl_letters('אֱלֹהִים'),))

    # ③ insert — 글자는 그대로, RTL 줄에만 정렬 태그
    class _W:
        def __init__(self):
            self.rows, self.tags = [], {}

        def insert(self, at, s, tags=()):
            self.rows.append((s, tuple(tags)))

        def tag_configure(self, name, **kw):
            self.tags[name] = kw

        def tag_raise(self, name):
            pass

    w = _W()
    r1 = insert(w, '태초에 하나님이', ('verse',))
    r2 = insert(w, he, ('verse',))
    # 언어 코드를 주면 그것이 이긴다 — 히브리 인용이 든 KO 글은 왼쪽
    if insert(_W(), he, lang='KO'):
        bad.append('lang=KO 인데 오른쪽에 붙인다')
    if not insert(_W(), '(준비 중)', lang='AR'):
        bad.append('lang=AR 인데 왼쪽에 붙인다')
    if label(he, lang='KO')[1]:
        bad.append('lang=KO 라벨을 오른쪽에 붙인다')
    if label('(준비 중)', lang='AR')[1].get('anchor') != 'e':
        bad.append('lang=AR 라벨을 오른쪽에 안 붙인다')
    if r1 or w.rows[0] != ('태초에 하나님이', ('verse',)):
        bad.append('LTR 줄을 건드렸다')
    if not r2 or w.rows[1][0] != he or TAG not in w.rows[1][1] \
            or w.tags.get(TAG, {}).get('justify') != 'right':
        bad.append('RTL 줄에 오른쪽 정렬 태그가 안 붙거나 글자가 바뀌었다')
    # ④ label
    t, opt = label('태초에 하나님이')
    if t != '태초에 하나님이' or opt:
        bad.append('LTR 라벨을 건드렸다')
    t, opt = label(he)
    if t != he or opt.get('anchor') != 'e':
        bad.append('RTL 라벨이 원문 그대로 오른쪽 붙임이 아니다')
    for b in bad:
        print('  FAIL ' + b)
    print('bidi selftest: ' + ('OK' if not bad else 'FAIL') + ' (6항목)')
    return 0 if not bad else 1


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(_selftest())
    print(__doc__)
