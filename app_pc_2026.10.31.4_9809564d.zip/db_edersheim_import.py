# -*- coding: utf-8 -*-
"""db_edersheim_import.py — 에더샤임 3권을 도서(sys_book_*)로 적재 (영구 도구).

2026-08-18 사용자 승인(「진행하라 — 먼저 다운로드 파일 정합성 재검사」).
원문 = `_edersheim_raw/`(CCEL 1순위 교정 텍스트 — 재다운로드 바이트 일치·
깨진 글자 0 확인). 새 도서 분류 `HISTORY`(역사 배경).

  python db_edersheim_import.py --selftest          # 의무
  python db_edersheim_import.py --check             # 3권 파싱·게이트
  python db_edersheim_import.py --preview LT 1 50 98
  python db_edersheim_import.py --apply LT [seq…]   # 멱등((book_id,sequence))

함정(전부 실측):
  · CCEL `.txt` 직링크는 WorkInfo HTML 껍데기(28KB) — 진짜 본문은
    `/ccel/e/edersheim/<work>/cache/<work>.txt`.
  · 꼬리 = 「References」 + `n. file:///…` 링크 목록 — References 에서 자른다.
  · 본장 뒤 부속(APPENDICES · Indexes)은 1차 적재 제외 — 거기서 몸통을 끊는다.
  · Life and Times 는 2권 합본이라 **`Book III` 머리가 두 번**(2권 재시작) —
    권 머리 사이 제사(題詞)·「- continued」 표제·각주 덤프는 본문이 아니다.
    1권 끝에는 `THE END OF THE FIRST VOLUME.` + 정오표가 장 몸통에 붙어
    있다 — 그 줄에서 장을 끝낸다.
  · 각주: 블록(`[n] …`, 빈 줄 앞에서 시작)과 본문 속 각주표 `[n]` 을 걷는다
    (매클라렌 선례 — 학술 인용부. 원문은 raw 에 그대로 남는다).
    ⚠ 하드랩 때문에 본문 줄이 `[n]` 으로 **시작할 수 있다** — 앞줄이
      빈 줄일 때만 각주 블록으로 본다.
  · 하드랩 ~75자 — 빈 줄 문단 경계로 되붙인다(문단 사이 `\n` 하나 —
    db_sw_grace_import 와 같은 규약). 깊은 들여쓰기 덩어리(운문)는 줄 보존.
  · 서문·약어표 등 앞부속(front matter)도 1차 제외 — 장 본문은 전량이다.
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, '_edersheim_raw')
DB = os.path.join(HERE, 'bible_master.db')
sys.path.insert(0, HERE)

CATEGORY = 'HISTORY'

WORKS = {
    'LT': dict(
        file='lifetimes.txt', code='EDERSHEIM_LT', style='LT',
        title='The Life and Times of Jesus the Messiah', year=1883,
        chapters=98, books=['I', 'II', 'III', 'III', 'IV', 'V'],
        per_book=[8, 12, 37, 24, 17],
        src='https://www.ccel.org/ccel/edersheim/lifetimes.html',
        desc='예수님의 생애와 시대 — 1세기 유대 세계·랍비 문헌 배경의 복음서 '
             '역사 서술(2권 합본, 5부 98장). 부록·색인은 미적재.',
        attrib='— Alfred Edersheim, The Life and Times of Jesus the Messiah '
               '(1883)'),
    'TMP': dict(
        file='temple.txt', code='EDERSHEIM_TMP', style='NUM',
        title='The Temple: Its Ministry and Services', year=1874,
        chapters=19,
        src='https://www.ccel.org/ccel/edersheim/temple.html',
        desc='예수님 당시 성전의 구조·직무·의식과 절기 — 레위기 제사와 절기 '
             '본문의 배경(19장). 색인은 미적재.',
        attrib='— Alfred Edersheim, The Temple: Its Ministry and Services '
               '(1874)'),
    'JSL': dict(
        file='sketches.txt', code='EDERSHEIM_JSL', style='NUM',
        title='Sketches of Jewish Social Life', year=1876,
        chapters=18,
        src='https://www.ccel.org/ccel/edersheim/sketches.html',
        desc='1세기 유대인의 일상·가정·회당·교육 — 복음서 생활 배경(18장). '
             '색인은 미적재.',
        attrib='— Alfred Edersheim, Sketches of Jewish Social Life (1876)'),
}

_SEP = re.compile(r'^\s*_{10,}\s*$')
_TAIL = re.compile(r'^\s*\d+\. file:///')
_FN_HEAD = re.compile(r'^\s*\[\d+\]')
_INLINE_FN = re.compile(r'\s*\[\d+\]')
_CH_LT = re.compile(r'^\s*CHAPTER ([IVXLC]+)\.\s*$')
_BOOK_LT = re.compile(r'^\s*Book ([IVXLC]+)\.?\s*$')
_CH_NUM = re.compile(r'^\s*Chapter (\d+)\s*$')
_BACK = re.compile(r'^\s*(APPENDICES|Indexes)\s*$')
_VOLEND = re.compile(r'^\s*THE END OF THE \w+ VOLUME\.?\s*$')
_POEM_INDENT = 10


def _read(work):
    p = os.path.join(RAW, WORKS[work]['file'])
    with open(p, encoding='utf-8') as f:
        return f.read()


def cut_tail(lines):
    """꼬리(References + file:/// 목록)와 본장 뒤 부속(부록·색인)을 자른다."""
    end = len(lines)
    for i, l in enumerate(lines):
        if _TAIL.match(l):
            j = i - 1
            while j >= 0 and not lines[j].strip():
                j -= 1
            end = j if (j >= 0 and lines[j].strip() == 'References') else i
            break
    for i in range(end):
        if _BACK.match(lines[i]):
            end = i
            break
    return lines[:end]


def strip_footnotes(lines):
    """각주 블록 제거 — **빈 줄 뒤에서 `[n]` 으로 시작**하는 연속 문단들.

    본문 하드랩이 `[n]` 을 줄 머리로 밀 수 있어(문단 한가운데) 앞줄
    검사 없이 지우면 문단 반쪽이 사라진다 — 실측으로 확인한 함정.
    """
    out = []
    i, n = 0, len(lines)
    prev_blank = True
    while i < n:
        l = lines[i]
        if _FN_HEAD.match(l) and prev_blank:
            while i < n:
                while i < n and lines[i].strip():          # 각주 문단 소비
                    i += 1
                while i < n and not lines[i].strip():      # 사이 빈 줄
                    i += 1
                if not (i < n and _FN_HEAD.match(lines[i])):
                    break
            out.append('')
            prev_blank = True
            continue
        out.append(l)
        prev_blank = not l.strip()
        i += 1
    return out


def _paras(lines):
    """빈 줄 경계 문단 되붙이기. 깊은 들여쓰기 덩어리(운문·인용시)는 줄 보존."""
    paras, cur = [], []

    def flush():
        if not cur:
            return
        deep = sum(1 for x in cur
                   if len(x) - len(x.lstrip()) >= _POEM_INDENT)
        if deep >= max(2, len(cur) // 2):
            paras.append('\n'.join(x.strip() for x in cur))
        else:
            paras.append(' '.join(' '.join(x.split()) for x in cur))
        del cur[:]

    for l in lines:
        if l.strip() and not _SEP.match(l):
            cur.append(l)
        else:
            flush()
    flush()
    return paras


def _body(chapter_lines):
    paras = _paras(strip_footnotes(chapter_lines))
    paras = [_INLINE_FN.sub('', p).strip() for p in paras]
    return '\n'.join(p for p in paras if p)


def parse_lt(lines):
    """Life and Times — Book I~V 안에서 CHAPTER 로마숫자가 다시 I 부터.

    권 머리와 첫 장 사이(제사·「continued」 표제·각주 덤프)는 버린다.
    반환 = (chapters, books_seen, discarded) — 뒤 둘은 --check 게이트용.
    """
    chapters, books_seen, discarded = [], [], []
    book, cur, pend = None, None, 0
    seq = 0
    for l in lines:
        mb = _BOOK_LT.match(l)
        if mb:
            book = mb.group(1)
            books_seen.append(book)
            if cur:
                chapters.append(cur)
                cur = None
            pend = 0
            continue
        mc = _CH_LT.match(l)
        if mc and book:
            if cur:
                chapters.append(cur)
            if pend:
                discarded.append(pend)
                pend = 0
            seq += 1
            cur = dict(seq=seq, book=book, ch=mc.group(1),
                       title=[], lines=[], in_title=True)
            continue
        if _VOLEND.match(l):        # 1권 끝 — 정오표가 이어지므로 장을 닫는다
            if cur:
                chapters.append(cur)
                cur = None
            continue
        if cur is None:
            if book:
                pend += 1           # 권 머리 뒤 버려지는 줄 수(감사용)
            continue
        if cur['in_title']:
            if l.strip():
                cur['title'].append(l.strip())
            elif cur['title']:
                cur['in_title'] = False
            continue
        cur['lines'].append(l)
    if cur:
        chapters.append(cur)
    out = []
    for c in chapters:
        label = 'Book %s · Ch. %s — %s' % (c['book'], c['ch'],
                                           ' '.join(c['title']))
        out.append((c['seq'], label, _body(c['lines'])))
    return out, books_seen, discarded


def parse_num(lines):
    """Temple · Sketches — `Chapter N` + 다음 줄 제목."""
    chapters, cur = [], None
    seq = 0
    for l in lines:
        m = _CH_NUM.match(l)
        if m:
            if cur:
                chapters.append(cur)
            seq += 1
            cur = dict(seq=seq, n=int(m.group(1)),
                       title=[], lines=[], in_title=True)
            continue
        if cur is None:
            continue
        if cur['in_title']:
            if l.strip():
                cur['title'].append(l.strip())
            elif cur['title']:
                cur['in_title'] = False
            continue
        cur['lines'].append(l)
    if cur:
        chapters.append(cur)
    return [(c['seq'], 'Ch. %d — %s' % (c['n'], ' '.join(c['title'])),
             _body(c['lines'])) for c in chapters]


def parse(work):
    lines = cut_tail(_read(work).split('\n'))
    if WORKS[work]['style'] == 'LT':
        return parse_lt(lines)
    return parse_num(lines), None, None


_RESIDUE = (
    ('HTML 태그', re.compile(r'<[a-zA-Z/][^>]{0,40}>')),
    ('각주표 [n]', re.compile(r'\[\d+\]')),
    ('file:/// 링크', re.compile(r'file:///')),
    ('구분선 ____', re.compile(r'_{10,}')),
)


def check(verbose=True):
    bad = 0
    for work, w in WORKS.items():
        chapters, books_seen, discarded = parse(work)
        msgs = []
        if len(chapters) != w['chapters']:
            msgs.append('장 수 %d ≠ 기대 %d' % (len(chapters), w['chapters']))
        if w['style'] == 'LT':
            if books_seen != w['books']:
                msgs.append('권 머리 수열 %s ≠ 기대 %s'
                            % (books_seen, w['books']))
            counts, prev, k = [], None, 0
            for _s, label, _b in chapters:
                bk = label.split(' · ')[0]
                if bk != prev:
                    if prev is not None:
                        counts.append(k)
                    prev, k = bk, 0
                k += 1
            counts.append(k)
            if counts != w['per_book']:
                msgs.append('권별 장 수 %s ≠ 기대 %s'
                            % (counts, w['per_book']))
            big = [d for d in discarded if d > 400]
            if big:
                msgs.append('권 머리 뒤 버린 구간이 너무 크다 %s줄' % big)
        seqs = [s for s, _l, _b in chapters]
        if seqs != list(range(1, len(chapters) + 1)):
            msgs.append('sequence 불연속')
        for s, label, body in chapters:
            if not label.split('— ', 1)[-1].strip():
                msgs.append('%d장 제목 없음' % s)
            if len(body) < 1500:
                msgs.append('%d장 본문이 너무 짧다(%d자)' % (s, len(body)))
            for name, rx in _RESIDUE:
                m = rx.search(body)
                if m:
                    msgs.append('%d장 %s 잔재: %r' % (s, name, m.group(0)))
        if verbose:
            total = sum(len(b) for _s, _l, b in chapters)
            print('%s %-13s 장 %d · 본문 %.2fMB%s'
                  % ('✗' if msgs else '✓', w['code'], len(chapters),
                     total / 1e6, '' if not msgs else ' — ' + msgs[0]))
            for m in msgs[1:6]:
                print('    ', m)
        bad += len(msgs)
    return bad


def preview(work, seqs):
    chapters = parse(work)[0]
    for s, label, body in chapters:
        if s in seqs:
            print('=' * 70)
            print('[%d] %s' % (s, label))
            print(body[:500])
            print('… (%d자 · 문단 %d)' % (len(body), body.count('\n') + 1))


def _ensure_book(conn, w):
    row = conn.execute('SELECT book_id FROM sys_book_asset WHERE book_code=?',
                       (w['code'],)).fetchone()
    if row:
        return row[0]
    conn.execute(
        """INSERT INTO sys_book_asset
           (book_code, title, author, lang_code, copyright_type, source_url,
            pub_year, description, record_status, book_category)
           VALUES (?,?,?,?,?,?,?,?,'LIVE',?)""",
        (w['code'], w['title'], 'Alfred Edersheim', 'EN', 'PUBLIC_DOMAIN',
         w['src'], w['year'], w['desc'], CATEGORY))
    return conn.execute('SELECT book_id FROM sys_book_asset WHERE '
                        'book_code=?', (w['code'],)).fetchone()[0]


def _ensure_cat_i18n(conn):
    """RVCAT_HISTORY — KO·EN 시드(나머지 언어는 §0-3 브리지). 멱등."""
    for lang, val in (('KO', '역사 배경'), ('EN', 'Historical background')):
        if not conn.execute(
                "SELECT 1 FROM ui_strings WHERE string_id='RVCAT_HISTORY' "
                "AND lang_code=?", (lang,)).fetchone():
            conn.execute("INSERT INTO ui_strings (string_id, lang_code, "
                         "string_value) VALUES ('RVCAT_HISTORY',?,?)",
                         (lang, val))


def _upsert_unit(conn, book_id, seq, label, body):
    """(book_id, sequence) 멱등 — 재적재해도 unit_id 불변(SW/AOG 규약)."""
    row = conn.execute(
        'SELECT unit_id FROM sys_book_unit WHERE book_id=? AND sequence=?',
        (book_id, seq)).fetchone()
    if row:
        uid = row[0]
        conn.execute("UPDATE sys_book_unit SET unit_label=?, "
                     "session_type='CHAPTER', record_status='LIVE' "
                     "WHERE unit_id=?", (label, uid))
    else:
        conn.execute(
            """INSERT INTO sys_book_unit
               (book_id, sequence, session_type, unit_label, record_status)
               VALUES (?,?,'CHAPTER',?,'LIVE')""", (book_id, seq, label))
        uid = conn.execute(
            'SELECT unit_id FROM sys_book_unit WHERE book_id=? AND '
            'sequence=?', (book_id, seq)).fetchone()[0]
    conn.execute("DELETE FROM sys_book_unit_text WHERE unit_id=? AND "
                 "text_variant='ORIGINAL' AND UPPER(lang_code)='EN'", (uid,))
    conn.execute(
        """INSERT INTO sys_book_unit_text
           (unit_id, text_variant, lang_code, body_text, record_status)
           VALUES (?,'ORIGINAL','EN',?,'LIVE')""", (uid, body))
    return uid


def apply(work, seqs=None):
    if check(verbose=False):
        print('검사 실패 — --check 먼저')
        return False
    w = WORKS[work]
    chapters = parse(work)[0]
    if seqs:
        chapters = [c for c in chapters if c[0] in seqs]
    import appdb
    conn = appdb.connect(DB)
    try:
        book_id = _ensure_book(conn, w)
        _ensure_cat_i18n(conn)
        for seq, label, body in chapters:
            _upsert_unit(conn, book_id, seq, label,
                         body + '\n' + w['attrib'])
            print('%s %3d — %s' % (work, seq, label[:64]))
        conn.commit()
        print('적재 — %s(book_id %d) 유닛 %d' % (w['code'], book_id,
                                                 len(chapters)))
    finally:
        conn.close()
    return True


# ── selftest ──────────────────────────────────────────────────────────────

_FIX_LT = """\
      Title: fixture
   __________________________________________________________________

   Book I

      'Epigraph poem line one,
      epigraph attribution' - Hymn
   __________________________________________________________________

CHAPTER I.

   THE FIRST CHAPTER TITLE -
   SPANNING TWO LINES

      Body paragraph one is long enough to demonstrate the joining of
      hard wrapped lines into a single paragraph of text. %s

      Mid-sentence marker [12] stays inline, and a wrap can push
      [13] to the line head without being a footnote block at all.

           Deep indented poem line one
           Deep indented poem line two

      [14] A real footnote block after a blank line, which must be
      removed entirely from the resulting body text.

      [15] Second footnote paragraph in the same block.

      Closing paragraph of chapter one after the footnotes block.

   THE END OF THE FIRST VOLUME.

      Page 1, read errata line that must not leak into any chapter.

   Book I

   THE TITLE: continued
   __________________________________________________________________

      [16] Footnote dump after the volume-two title page.

CHAPTER II.

   SECOND CHAPTER TITLE

      Body of chapter two long enough to pass through the paragraph
      assembly stage without touching any gate at all.

   APPENDICES

      Appendix content that must be cut away from the last chapter.

   References

   1. file:///ccel/fixture#a
""" % ('x' * 40)

_FIX_NUM = """\
      Title: fixture

Chapter 1

   First Title Here

      Alpha paragraph body text joined from wrapped lines with some
      more words to make it plausible.

Chapter 2

   Second Title Here

      Beta paragraph body text also joined from wrapped lines here.

   Indexes

   Index of Scripture References

   References

   1. file:///ccel/fixture#b
"""


def selftest():
    ok = True

    def t(name, cond):
        nonlocal ok
        print('%s %s' % ('✓' if cond else '✗', name))
        ok = ok and cond

    lines = cut_tail(_FIX_LT.split('\n'))
    t('꼬리 절단 — References·file 링크 제거',
      not any('file:///' in l or l.strip() == 'References' for l in lines))
    t('부속 절단 — APPENDICES 이후 제거',
      not any('Appendix content' in l for l in lines))
    chs, books, disc = parse_lt(lines)
    t('LT 장 2개·권 수열 [I, I]', len(chs) == 2 and books == ['I', 'I'])
    s1, label1, body1 = chs[0]
    t('제목 두 줄 결합', 'SPANNING TWO LINES' in label1
      and label1.startswith('Book I · Ch. I — THE FIRST'))
    t('하드랩 되붙임', 'demonstrate the joining of hard wrapped' in body1)
    t('본문 속 각주표 제거(줄 머리 [13] 포함)',
      '[12]' not in body1 and '[13]' not in body1
      and 'stays inline, and a wrap' in body1)
    t('각주 블록 제거·뒤 문단 생존',
      'A real footnote block' not in body1
      and 'Second footnote paragraph' not in body1
      and 'Closing paragraph of chapter one' in body1)
    t('운문 줄 보존', 'poem line one\nDeep indented poem line two' in body1)
    t('정오표 미누출', 'errata' not in body1.lower())
    t('제사(epigraph) 제외', 'Epigraph poem' not in body1)
    _s2, _l2, body2 = chs[1]
    t('2권 표제·각주 덤프 제외',
      'continued' not in body2 and '[16]' not in body2
      and 'Body of chapter two' in body2)
    chs2 = parse_num(cut_tail(_FIX_NUM.split('\n')))
    t('NUM 장 2개·제목', len(chs2) == 2
      and chs2[0][1] == 'Ch. 1 — First Title Here'
      and 'Alpha paragraph' in chs2[0][2])
    t('NUM 색인 제외', 'Scripture References' not in chs2[1][2])
    # 게이트가 실제로 잡는지 — 양방향
    t('잔재 게이트 탐지력', any(rx.search('bad <i>tag</i> here')
                             for _n, rx in _RESIDUE))
    # 실제 파일 (있을 때만)
    if os.path.exists(os.path.join(RAW, 'lifetimes.txt')):
        n_bad = check(verbose=False)
        t('실제 3권 게이트 통과(위반 0)', n_bad == 0)
    else:
        print('· 실제 원문 없음 — 파일 검사 생략')
    print('selftest', 'OK' if ok else 'FAIL')
    return ok


if __name__ == '__main__':
    a = sys.argv[1:]
    if not a or a[0] == '--selftest':
        sys.exit(0 if selftest() else 1)
    if a[0] == '--check':
        sys.exit(1 if check() else 0)
    if a[0] == '--preview' and len(a) >= 3:
        preview(a[1].upper(), {int(x) for x in a[2:]})
        sys.exit(0)
    if a[0] == '--apply' and len(a) >= 2:
        sys.exit(0 if apply(a[1].upper(),
                            {int(x) for x in a[2:]} or None) else 1)
    print(__doc__)
