# -*- coding: utf-8 -*-
"""asset_pick.py — **출발지 선택기** (2026-08-27 신설·영구).

★ 사용자 확정 — 「최상단에 배경색을 가진 출발지 선택공간. 구절, 도서, 용어…
  탐색/검색·선택 기능도 필요하다」·「A와 B를 연결했는데 다시 B를 출발지로
  해서 다른 자산들을 연결해야 할 상황」.

선택 방법은 **자산 규모가 정한다** (2026-08-27 실측)
  | 구절 31,104 | 책·장·절 콤보 + [지금 보는 절로] |
  | 외부연결 11,753 · 도서유닛 6,679 · 단락 3,413 | 검색 |
  | 자료집 595 · 태그 509 · 용어 451 | 검색 |
  | 렌즈 52 · 노드 364 · 흐름 81 · 내 자료 20 | 목록 그대로 |

공통 장치 둘
  · **[최근 ▾]** — 최근 잡은 출발지 10개(자산 종류 섞어서). 창을 옮겨 다니는
    일이 잦아 이것이 없으면 매번 다시 찾는다.
  · **[⇄ 방금 연결한 것으로]** — A→B 를 이은 직후 **B 로 갈아탄다**(사용자가
    말한 그 상황). 연결 저장 때 기록해 둔 마지막 상대를 그대로 잡는다.

`my_edit.MyEditWin` 이 `build(host, win, kind)` 하나만 부른다.
    python asset_pick.py --selftest    (의무)
"""
import sys
import tkinter as tk
from tkinter import ttk

import appdb
import i18n

RECENT_KEY = 'ME_RECENT'          # user_config — "KIND:id|KIND:id|…"
LAST_LINK_KEY = 'ME_LAST_LINK'    # 방금 이은 상대 "KIND:id"
#: ★★ **20** (2026-08-29 사용자 확정 — 「얼마나 저장해야 하는가? 표시될
#   정도면 충분하다. 앞뒤로 더보기 버튼 눌러서 보게 하라. 20개 정도」).
_MAX_RECENT = 20
#: 띠에 한 번에 보이는 칸 수 — 나머지는 [◀][▶] 로 넘긴다.
_TRAIL_SHOW = 6


# ══════════════════════════════════════════════════════════════════
#  데이터 — 최근·방금
# ══════════════════════════════════════════════════════════════════
def _cfg_get(conn, key):
    try:
        r = conn.execute('SELECT config_val FROM user_config '
                         'WHERE config_key=?', (key,)).fetchone()
        return (r and r[0]) or ''
    except Exception:
        return ''


def _cfg_set(conn, key, val):
    cur = conn.execute('UPDATE user_config SET config_val=? '
                       'WHERE config_key=?', (val, key))
    if cur.rowcount == 0:
        conn.execute('INSERT INTO user_config(config_key, config_val) '
                     'VALUES(?,?)', (key, val))
    conn.commit()


def recent(conn):
    """최근 출발지 → [(kind, id)] (새 것이 앞)."""
    out = []
    for part in _cfg_get(conn, RECENT_KEY).split('|'):
        if ':' not in part:
            continue
        k, _, i = part.partition(':')
        try:
            out.append((k, int(i)))
        except Exception:
            pass
    return out


def push_recent(conn, kind, asset_id):
    """출발지를 잡을 때마다 기록.

    ⚠⚠ **이미 있는 것은 자리를 옮기지 않는다** (2026-08-29 사용자 확정 —
      「앞쪽 출발지를 클릭해도 **뒤쪽 출발지 경로는 살려두어라**」).
      그전에는 맨 앞으로 끌어올리는 MRU 였는데, 그러면 지나온 자리를 눌러
      돌아갈 때마다 **순서가 뒤바뀌어** 「지나온 길」이 사라진다.
    ⚠ 이 목록은 **경로가 아니다**(사용자 — 「Journey map 과 같은 개념이
      아니다 … 체계적 연결성은 전혀 없다」). 창1:1 에서 용어를 잇다가 새
      용어를 만들고, 거기서 연구자료를 만들고… 그렇게 **지나온 자리**를
      다시 잡아 연결·수정 상태를 점검하려는 것뿐이다.
    """
    if not asset_id:
        return
    cur = recent(conn)
    if (str(kind), int(asset_id)) in cur:
        return                       # 이미 있다 — 자리를 지킨다
    cur.insert(0, (str(kind), int(asset_id)))
    _cfg_set(conn, RECENT_KEY,
             '|'.join('%s:%d' % (k, i) for k, i in cur[:_MAX_RECENT]))


def build_trail(host, win, show=_TRAIL_SHOW):
    """★★★ **출발지 띠** — 지나온 출발지를 눌러 되돌아가는 줄 (2026-08-29).

    사용자 확정: 「**My Edit 때문에 띠를 만든 것이다.** 지난 경로를 다시
    기준점으로 잡으려면 반드시 필요하다.」

    · **누르면 그것이 곧 출발지**다 — 따로 「출발지로 지정」 단추를 두지 않는다
      (사용자 — 「경로를 클릭하면 그 자체로 출발지로 지정되는 것 아닌가?」).
    · **자르지 않는다** — 앞쪽을 눌러도 뒤쪽 칸이 그대로 남는다.
    · **호스트가 바뀌어도 안 지운다** — 지나온 기록이지 지금 위치의 경로가 아니다.
    · 최대 20칸 · 한 번에 `show` 칸 · 나머지는 [◀][▶].

    `win` 은 `db_path`·`lang`·`kind`·`asset_id`·`set_anchor` 를 가진 것이면 된다.
    """
    _t = i18n.t
    bg = host.cget('bg')
    st = {'off': 0}

    def draw():
        for w in host.winfo_children():
            w.destroy()
        with appdb.connect(win.db_path) as conn:
            rec = recent(conn)
        rec = list(reversed(rec))          # 오래된 것 왼쪽 · 지금 오른쪽
        tk.Label(host, text=_t('ME_TRAIL', '지나온 출발지'), bg=bg,
                 font=('', 9, 'bold')).pack(side='left', padx=(0, 6))
        if not rec:
            tk.Label(host, text=_t('ME_TRAIL_EMPTY', '(아직 없습니다)'),
                     bg=bg).pack(side='left')
            return
        n = len(rec)
        st['off'] = max(0, min(st['off'], max(0, n - show)))
        if n > show:
            b = tk.Button(host, text='◀', bd=0, padx=4, cursor='hand2',
                          relief='flat', bg=bg, highlightthickness=0,
                          command=lambda: (st.__setitem__(
                              'off', max(0, st['off'] - 1)), draw()))
            b.pack(side='left', padx=(0, 4))
            if st['off'] <= 0:
                b.config(state='disabled')
        lo = st['off']
        # ★★ **단추가 아니라 밑줄 텍스트** (2026-08-29 사용자 지시 — 「지나온
        #   출발지를 버튼으로 하지 말고 **밑줄 텍스트 라벨**처럼 표시하라.
        #   버튼 느낌이 사라지게 하라」).
        #   ⚠ 단추로 두면 이 줄이 **명령 줄**로 읽힌다 — 여기는 지나온 자리를
        #     되짚는 곳이지 무엇을 실행하는 곳이 아니다.
        #   ⚠ 색은 역할로(§0 하드코딩 금지) — 링크는 `accent`, 지금 자리는 `fg`.
        try:
            import ui_theme
            c_link = ui_theme.C('accent') or '#2E6DA4'
            c_here = ui_theme.C('fg') or '#000000'
        except Exception:
            c_link, c_here = '#2E6DA4', '#000000'
        with appdb.connect(win.db_path) as conn:
            import link_picker as LP
            for n_, (kk, ii) in enumerate(rec[lo:lo + show]):
                try:
                    nm = LP.label_of(conn, kk, ii, None, win.lang) or '#%d' % ii
                except Exception:
                    nm = '#%d' % ii
                here = (kk == getattr(win, 'kind', None)
                        and ii == getattr(win, 'asset_id', None))
                if n_:
                    tk.Label(host, text='·', bg=bg,
                             fg=c_link).pack(side='left', padx=2)
                lb = tk.Label(
                    host, text=(nm[:18] or '#%d' % ii), bg=bg,
                    fg=(c_here if here else c_link),
                    cursor=('' if here else 'hand2'),
                    font=('', 9, 'bold') if here else ('', 9, 'underline'))
                lb.pack(side='left')
                if not here:
                    lb.bind('<Button-1>',
                            lambda _e, k2=kk, i2=ii: win.set_anchor(k2, i2))
        if n > show:
            b2 = tk.Button(host, text='▶', bd=0, padx=4, cursor='hand2',
                           relief='flat', bg=bg, highlightthickness=0,
                           command=lambda: (st.__setitem__(
                               'off', min(n - show, st['off'] + 1)), draw()))
            b2.pack(side='left', padx=(4, 0))
            if st['off'] >= n - show:
                b2.config(state='disabled')
            tk.Label(host, text=' %d/%d' % (lo + show, n), bg=bg).pack(
                side='left', padx=(4, 0))

    draw()
    return draw


def note_last_link(conn, kind, asset_id):
    """연결을 이은 직후 **상대**를 적어 둔다 — [⇄ 방금 연결한 것으로] 용."""
    if kind and asset_id:
        _cfg_set(conn, LAST_LINK_KEY, '%s:%d' % (kind, int(asset_id)))


def last_link(conn):
    v = _cfg_get(conn, LAST_LINK_KEY)
    if ':' not in v:
        return None
    k, _, i = v.partition(':')
    try:
        return (k, int(i))
    except Exception:
        return None


# ══════════════════════════════════════════════════════════════════
#  목록·검색 — 자산별 후보 (link_picker 의 단일 소스를 쓴다)
# ══════════════════════════════════════════════════════════════════
def candidates(conn, kind, q='', lang='KO', limit=200):
    """[(id, 이름)] — 검색어가 비면 앞에서부터.

    ⚠ 후보 SQL 을 여기서 새로 쓰지 않는다 — `link_picker._candidates` 가
      전 자산의 단일 소스다(검사기도 그 규칙을 지킨다).
    """
    import link_picker as LP
    # ⚠ `_candidates` 는 **LIKE 문자열**을 받는다 — 빈 검색어를 그대로 주면
    #   `LIKE ''` 라 0건이다(실측으로 잡았다). 전체는 `%%`.
    like = '%%%s%%' % (q or '').strip()
    try:
        rows = LP._candidates(conn, kind, like, lang, limit)
    except Exception as e:
        print('[asset_pick] candidates(%s): %s' % (kind, e))
        return []
    out = []
    for r in rows:
        try:
            # ⚠ 반환은 **(갈래, 번호, 이름)** 3칸이다(실측). 2칸으로 읽으면
            #   이름 자리에 번호가 들어간다.
            if len(r) >= 3:
                out.append((r[1], r[2]))
            else:
                out.append((r[0], r[1]))
        except Exception:
            pass
    return out


# ══════════════════════════════════════════════════════════════════
#  화면
# ══════════════════════════════════════════════════════════════════
def build(host, win, kind):
    """출발지 선택기를 host 에 짓는다. `win` = MyEditWin."""
    _t = i18n.t
    bg = host.cget('bg')
    cap = None
    try:
        import my_edit
        cap = my_edit.ASSET_CAPS.get(str(kind).upper())
    except Exception:
        pass
    mode = (cap or {}).get('pick', 'SEARCH')

    # ── 공통 — [최근 ▾] · [⇄ 방금 연결한 것으로] ──
    def _jump(k, i):
        win.set_anchor(k, i)

    with appdb.connect(win.db_path) as conn:
        rec = recent(conn)
        lastl = last_link(conn)

    # ⚠ 선택기가 **왼쪽 묶음**이 됐다(2026-08-28) — 공통 단추도 같은 줄에서
    #   왼쪽에 이어 붙인다. 오른쪽에 남겨 두면 선택기와 갈라져 보인다.
    #   먼저 자산별 선택기를 짓고, 그 뒤에 이 둘을 붙인다(차례가 곧 자리).
    def _extras():
        if rec:
            mb = ttk.Menubutton(host, text=_t('ME_RECENT_BTN', '최근 ▾'))
            _fill_recent(mb, win, rec, _jump)
            mb.pack(side='left', padx=(8, 0))
        if lastl:
            tk.Button(host, text=_t('ME_TO_LAST', '⇄ 방금 연결한 것으로'),
                      bd=1, padx=6, cursor='hand2',
                      command=lambda: _jump(*lastl)).pack(side='left',
                                                          padx=(6, 0))

    # ── 자산별 ──
    if mode == 'BIBLE':
        _build_bible(host, win, bg)
    elif mode == 'BOOK':
        _build_book(host, win, bg)
    else:
        _build_search(host, win, kind, bg, listing=(mode == 'LIST'))
    _extras()


def _fill_recent(mb, win, rec, jump):
    menu = tk.Menu(mb, tearoff=0)
    with appdb.connect(win.db_path) as conn:
        import link_picker as LP
        for k, i in rec[:_MAX_RECENT]:
            try:
                nm = LP.label_of(conn, k, i, None, win.lang) or '#%d' % i
            except Exception:
                nm = '#%d' % i
            menu.add_command(label='%s · %s' % (my_edit_kind_name(k), nm),
                             command=lambda kk=k, ii=i: jump(kk, ii))
    mb['menu'] = menu


def my_edit_kind_name(k):
    try:
        import my_edit
        return my_edit.kind_name(k)
    except Exception:
        return k


def _build_bible(host, win, bg):
    """구절 — 책·장·절 콤보 + [지금 보는 절로]."""
    _t = i18n.t
    with appdb.connect(win.db_path) as conn:
        books = conn.execute(
            'SELECT bn.book_code, bn.full_name FROM book_names bn '
            'WHERE UPPER(bn.lang_code)=? AND bn.book_code IN '
            '(SELECT DISTINCT bcode FROM bible_index) ORDER BY bn.book_code',
            ((win.lang or 'KO').upper(),)).fetchall()
    cb_b = ttk.Combobox(host, state='readonly', width=11,
                        values=[b[1] for b in books])
    cb_c = ttk.Combobox(host, state='readonly', width=4)
    cb_v = ttk.Combobox(host, state='readonly', width=4)
    for w in (cb_b, cb_c, cb_v):
        w.pack(side='left', padx=2)

    def fill(level):
        i = cb_b.current()
        if i < 0:
            return
        with appdb.connect(win.db_path) as conn:
            if level <= 1:
                chs = [str(r[0]) for r in conn.execute(
                    'SELECT DISTINCT chapter FROM bible_index WHERE bcode=? '
                    'ORDER BY chapter', (books[i][0],))]
                cb_c.config(values=chs)
                if chs and not cb_c.get():
                    cb_c.current(0)
            if not cb_c.get():
                return
            vs = [str(r[0]) for r in conn.execute(
                'SELECT verse FROM bible_index WHERE bcode=? AND chapter=? '
                'ORDER BY verse', (books[i][0], int(cb_c.get())))]
        cb_v.config(values=vs)
        if vs and not cb_v.get():
            cb_v.current(0)

    def go(_e=None):
        i = cb_b.current()
        if i < 0 or not cb_c.get() or not cb_v.get():
            return
        with appdb.connect(win.db_path) as conn:
            r = conn.execute('SELECT verse_id FROM bible_index WHERE bcode=? '
                             'AND chapter=? AND verse=?',
                             (books[i][0], int(cb_c.get()),
                              int(cb_v.get()))).fetchone()
        if r:
            win.set_anchor('VERSE', r[0])
    cb_b.bind('<<ComboboxSelected>>', lambda _e: fill(1))
    cb_c.bind('<<ComboboxSelected>>', lambda _e: fill(2))
    cb_v.bind('<<ComboboxSelected>>', go)
    tk.Button(host, text=_t('OC_TO_CURRENT', '지금 보는 절로'), bd=1, padx=6,
              cursor='hand2',
              command=lambda: _to_current(win)).pack(side='left', padx=(6, 0))
    # 지금 값 채우기
    if win.asset_id and win.kind == 'VERSE':
        with appdb.connect(win.db_path) as conn:
            r = conn.execute('SELECT bcode, chapter, verse FROM bible_index '
                             'WHERE verse_id=?', (win.asset_id,)).fetchone()
        if r:
            codes = [b[0] for b in books]
            if r[0] in codes:
                cb_b.current(codes.index(r[0]))
            fill(1)
            cb_c.set(str(r[1]))
            fill(2)
            cb_v.set(str(r[2]))


def _to_current(win):
    root = win.master
    cur = (getattr(root, 'active_node_id', None)
           or getattr(root, '_p1_verse_id', None))
    if cur:
        try:
            win.set_anchor('VERSE',
                           int(str(cur).split(':')[-1].split('_')[0]))
        except Exception:
            pass


def _build_book(host, win, bg):
    """도서 유닛 — 도서 콤보 → 유닛 검색."""
    _build_search(host, win, 'BOOK_UNIT', bg, listing=False)


def _build_search(host, win, kind, bg, listing=False):
    """검색(또는 적은 자산은 목록) → 선택하면 그 자산으로."""
    _t = i18n.t
    ent = None
    if not listing:
        ent = tk.Entry(host, width=16)
        ent.pack(side='left', padx=(0, 3))
    cb = ttk.Combobox(host, state='readonly', width=26)
    cb.pack(side='left')
    box = {'ids': []}

    def find(_e=None):
        q = ent.get() if ent is not None else ''
        with appdb.connect(win.db_path) as conn:
            got = candidates(conn, kind, q, win.lang, 200)
        box['ids'] = [g[0] for g in got]
        cb.config(values=[str(g[1]) for g in got])
        if got:
            cb.current(0)
        else:
            cb.set(_t('ME_NOHIT', '(없음)'))

    def pick(_e=None):
        i = cb.current()
        if 0 <= i < len(box['ids']):
            win.set_anchor(kind, box['ids'][i])
    cb.bind('<<ComboboxSelected>>', pick)
    if ent is not None:
        ent.bind('<Return>', find)
        tk.Button(host, text=_t('BTN_FIND', '찾기'), bd=1, padx=6,
                  cursor='hand2', command=find).pack(side='left', padx=(3, 0))
    find()


# ══════════════════════════════════════════════════════════════════
#  자가 검증
# ══════════════════════════════════════════════════════════════════
def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    conn = appdb.connect()
    keep_r = _cfg_get(conn, RECENT_KEY)
    keep_l = _cfg_get(conn, LAST_LINK_KEY)
    try:
        # 지나온 출발지 — 새 것이 앞 · **다시 잡아도 자리를 안 옮긴다** · 20개 상한
        _cfg_set(conn, RECENT_KEY, '')
        push_recent(conn, 'VERSE', 3)
        push_recent(conn, 'ENTITY', 59)
        push_recent(conn, 'VERSE', 3)
        r = recent(conn)
        # ⚠⚠ 2026-08-29 사용자 확정 — 「앞쪽 출발지를 클릭해도 **뒤쪽 출발지
        #   경로는 살려두어라**」. MRU 로 끌어올리면 지나온 길이 뒤바뀐다.
        t('★ 다시 잡아도 자리를 안 옮긴다(지나온 길 보존)',
          r == [('ENTITY', 59), ('VERSE', 3)], r)
        for i in range(25):
            push_recent(conn, 'VERSE', 100 + i)
        t('   20개 상한', len(recent(conn)) == _MAX_RECENT == 20,
          len(recent(conn)))
        # ★ 상한을 넘으면 **가장 오래된 것**이 밀려난다
        t('   밀려나는 것은 가장 오래된 것',
          ('VERSE', 3) not in recent(conn)
          and ('VERSE', 124) in recent(conn), recent(conn)[:3])
        # 방금 연결한 것
        note_last_link(conn, 'ENTITY', 59)
        t('★ [⇄ 방금 연결한 것으로]', last_link(conn) == ('ENTITY', 59))
        # 후보 — 자산별로 실제로 나오나(단일 소스 위임)
        # ⚠ VERSE 는 후보 SQL 이 **없다** — 31,104개라 검색 목록이 아니라
        #   책·장·절 콤보로 고른다(선택기 BIBLE). 0건이 정상이다.
        # ⚠ TAG 는 2026-09-01 통합 수술로 배포 태그가 0 이다(`db_tag_unify` —
        #   용어로 흡수). 내 태그만 남으므로 0건도 정상.
        for kind, need in (('VERSE', 0), ('ENTITY', 1), ('TAG', 0),
                           ('LENS', 1), ('BOOK_UNIT', 1), ('REF_UNIT', 1),
                           ('MEDIA', 1), ('PERICOPE', 0), ('CHAIN', 0),
                           ('NODE', 0), ('USER_REF', 0)):
            got = candidates(conn, kind, '', 'KO', 5)
            t('후보 %s (%d개)' % (kind, len(got)), len(got) >= need,
              got[:1])
        # 검색어가 걸리는지 — 이름 조각으로 좁혀 본다
        few = candidates(conn, 'ENTITY', '다윗', 'KO', 20)
        t('★ 검색이 좁힌다(용어 「다윗」 %d건)' % len(few),
          0 < len(few) < 60, few[:2])
    finally:
        _cfg_set(conn, RECENT_KEY, keep_r)
        _cfg_set(conn, LAST_LINK_KEY, keep_l)
        t('설정 원복', _cfg_get(conn, RECENT_KEY) == keep_r
          and _cfg_get(conn, LAST_LINK_KEY) == keep_l)
        conn.close()
    print('asset_pick selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)
