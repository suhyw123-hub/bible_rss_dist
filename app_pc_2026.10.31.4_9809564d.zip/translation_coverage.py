# -*- coding: utf-8 -*-
"""번역 대상 레지스트리 + 언어별 커버리지 계산.

신규 언어 추가 시 채워야 할 모든 다국어 저장소를 한 곳에 정의하고(REGISTRY),
선택 언어 기준 진척(번역됨/전체/%)을 계산한다. 관리자 '언어 관리 > 번역 커버리지' 탭이 사용.

원칙: 이 모듈은 "무엇을/얼마나" 만 계산(관제탑). 실제 번역 편집은 각 도메인 화면에서.
새 다국어 저장소가 생기면 아래 표/함수에 한 줄 추가하면 대시보드에 자동 반영.
"""
import os
import json
import sqlite3
import appdb

DB = os.path.join(os.path.dirname(__file__), 'bible_master.db')

# ── 사용자 노출 sys_text_asset text_type: (text_type, 라벨, 편집 위치) ──
TEXT_ASSET_TYPES = [
    ('ENTITY_NAME',      '엔티티 이름',         '콘텐츠관리 > 엔티티 관리'),
    ('ENTITY_DESC',      '엔티티 설명',         '콘텐츠관리 > 엔티티 관리'),
    ('ENTITY_PERI_DESC', '엔티티-페리코프 설명', '콘텐츠관리 > 엔티티 관리'),
    ('PERI_TITLE',       '페리코프 제목',       '데이터관리 > 페리코프 편집기'),
    # 2026-08-26 — 장 설명문 편집이 화면(구절설명문 편집기)에 생기면서 추적 시작.
    #   ⚠ 여기 안 넣으면 미번역이 커버리지·대시보드에 영영 안 보인다.
    ('CHAP_DESC',        '장 설명문',           '성경 > 성경구절관리'),
    # 2026-08-26 — BOOK_DESC 신설(성경구절관리 「책 개요」 탭, clicked_id=bcode)
    ('BOOK_DESC',        '책 개요',             '성경 > 성경구절관리'),
    # 2026-08-27 — 자료집 글의 목록 요약(한두 단어 · db_refunit_short).
    #   ⚠ 여기 안 넣으면 미번역이 커버리지·대시보드에 영영 안 보인다.
    ('REF_UNIT_SHORT',   '자료집 글 목록 요약',  '서고 > 교리문답 관리'),
    # 2026-09-15 — 스트롱 사전 정의문 번역(clicked_id=db_lex_link.lemma_key(strong)).
    #   영어 원문은 sys_lemma_master 가 정본이라 여기엔 번역 행만 쌓인다.
    #   ⚠ 여기 안 넣으면 미번역이 커버리지·대시보드에 영영 안 보인다.
    ('LEMMA_DEF',        '스트롱 사전 정의문',   '(번역 도구 · 낱말 마스터)'),
    # 2026-09-05 — 시작화면 사진의 제목·설명(clicked_id=img_id).
    #   ⚠ 여기 안 넣으면 미번역이 커버리지·대시보드에 영영 안 보인다.
    ('SPLASH_TITLE',     '시작화면 사진 제목',   '소통 > 시작화면 사진'),
    ('SPLASH_DESC',      '시작화면 사진 설명',   '소통 > 시작화면 사진'),
    ('PLAN_TITLE',       '플랜 제목',           '묵상플랜관리 > 플랜 관리'),
    ('PLAN_DESC',        '플랜 설명',           '묵상플랜관리 > 플랜 관리'),
    ('PLAN_FOCUS',       '플랜 묵상포커스',     '묵상플랜관리 > 플랜 관리'),
    ('PLAN_QUESTION',    '묵상 질문',           '묵상플랜관리 > 묵상질문 편집기'),
    ('PLAN_CAT_NAME',    '플랜 카테고리명',     '묵상플랜관리 > 렌즈묵상 관리'),
    # ★ 이름 둘은 **KO 가 `unit_name_sid`**(멱등 열쇠)이고 타 언어만
    #   여기 행으로 얹힌다 — 그래서 KO 는 늘 0건으로 보인다(정상).
    ('CONT_NAME',        '렌즈 이름',           '묵상플랜관리 > 렌즈묵상 관리'),
    ('NODE_NAME',        '노드 이름',           '묵상플랜관리 > 렌즈묵상 관리'),
    ('CONT_DESC',        '컨테이너(렌즈) 설명', '묵상플랜관리 > 렌즈묵상 관리'),
    ('NODE_DESC',        '노드 설명',           '묵상플랜관리 > 렌즈묵상 관리'),
    ('NODE_VERS_DESC',   '노드-구절 설명',      '묵상플랜관리 > 렌즈묵상 관리'),
    ('NODE_QUESTION',    '노드 묵상질문',        '묵상플랜관리 > 렌즈묵상 관리'),
    ('NODE_PRAYER',      '노드 묵상기도',        '묵상플랜관리 > 렌즈묵상 관리'),
    ('VERS_DESC',        '구절 설명',           '렌즈묵상 관리 / 구절연결관리'),
    ('VERS_QUESTION',    '구절 묵상질문',       '렌즈묵상 관리'),
    ('VERS_PRAYER',      '구절 묵상기도',       '렌즈묵상 관리'),
    ('VERS_VERS_DESC',   '구절연결 설명',       '데이터관리 > 구절 개별연결관리'),
    ('RELATION_DESC',    '인물 관계 설명',      '(엔티티 관계)'),
    ('ROUTE_THEME_NAME', '여정 테마명',         '(시드 스크립트)'),
    ('ROUTE_VARIANT_NAME', '여정 경로명',       '(시드 스크립트)'),
    ('ROUTE_STOP_DESC',  '여정 정류장 설명',    '(시드 스크립트)'),
]

# ── json_detail 번역 대상(③ 짧은 번역텍스트·음역) — 코드·원어·구조 제외 ──
JSON_TRANS_KEYS = {
    'meaning', 'material', 'region', 'alt_name', 'hometown', 'birth_place',
    'death_place', 'occupation', 'father', 'mother', 'made_by', 'modern_name',
    'origin', 'nationality', 'symbol', 'symbol_food', 'food', 'timing', 'contents',
    'location', 'significance', 'purpose', 'target', 'duties', 'territory',
    'composition', 'role', 'orig_name', 'nt_context', 'nt_fulfillment', 'sections',
    'elements', 'example',
}
# 제외(코드/원어/구조/숫자): heb_name·gk_name·geo·region_code·idol_type·subtype·
#   key_verses·map_show·aliases·related_idols·birth_order·origin_person·approx·
#   elevation_m·duration_days·idol_type·worship_category(→desc 이전) 등


# ── ui_strings 관리용 그룹 레지스트리 ─────────────────────────────────────────
# ui_strings 는 평평한 i18n 키-값 저장소(정석). 분류는 *별도 테이블이 아니라* 키
# 네임스페이스(prefix)로 한다. 아래는 prefix → 사람이 읽는 그룹명 매핑(코드 레지스트리).
# 신규 키는 DOMAIN_SUB_NAME 규약을 따르고, 새 도메인이 생기면 여기 한 줄 추가.
UI_STRING_GROUPS = {
    'UI':     'UI 공통',
    'ENTITY': '엔티티',
    'TG':     '태그(주제)',
    'RTAG':   '태그(참고)',
    'CT':     '렌즈(컨테이너)',
    'ND':     '렌즈(노드)',
    'STR':    '렌즈(노드)',
    'BOOK':   '도서',
    'DIAG':   '자가진단',
    'PLAN':   '플랜',
}


def ui_string_group(string_id):
    """ui_strings 키 → 사람이 읽는 그룹명(미등록 prefix는 prefix 그대로)."""
    pre = string_id.split('_')[0] if '_' in string_id else string_id
    return UI_STRING_GROUPS.get(pre, pre)


def _val_for(v, lang):
    """attr 값이 lang 으로 채워졌으면 반환. 중첩→lang 키, flat→KO 로 간주."""
    if isinstance(v, dict):
        s = v.get(lang)
        return s if isinstance(s, str) and s.strip() else None
    if isinstance(v, str) and v.strip():
        return v.strip() if lang == 'KO' else None
    return None


def coverage(lang, db_path=DB):
    """선택 언어의 번역 커버리지 → [{group, label, edit, translated, total, pct}] 행 목록."""
    conn = appdb.connect(db_path)
    rows = []

    def add(group, label, translated, total, edit):
        pct = (translated / total * 100) if total else 100.0
        rows.append({'group': group, 'label': label, 'edit': edit,
                     'translated': translated, 'total': total, 'pct': pct})

    # ── ui_strings ──
    try:
        total = conn.execute("SELECT COUNT(DISTINCT string_id) FROM ui_strings").fetchone()[0]
        tr = conn.execute("SELECT COUNT(DISTINCT string_id) FROM ui_strings WHERE lang_code=?",
                          (lang,)).fetchone()[0]
        add('UI 문자열', 'ui_strings (UI 라벨·메시지)', tr, total, '앱 전역 (코드/시드)')
    except Exception:
        pass

    # ── sys_text_asset (text_type 별) ──
    for tt, label, edit in TEXT_ASSET_TYPES:
        try:
            total = conn.execute(
                "SELECT COUNT(DISTINCT clicked_id) FROM sys_text_asset "
                "WHERE text_type=? AND COALESCE(record_status,'LIVE')='LIVE'", (tt,)).fetchone()[0]
            if not total:
                continue
            tr = conn.execute(
                "SELECT COUNT(DISTINCT clicked_id) FROM sys_text_asset "
                "WHERE text_type=? AND lang_code=? AND COALESCE(record_status,'LIVE')='LIVE'",
                (tt, lang)).fetchone()[0]
            add('텍스트 자산', label, tr, total, edit)
        except Exception:
            pass

    # ── json_detail 번역 대상 attr ──
    try:
        total = tr = 0
        for (jd,) in conn.execute(
                "SELECT json_detail FROM sys_entity_master "
                "WHERE record_status='LIVE' AND json_detail IS NOT NULL AND json_detail!=''"):
            try:
                d = json.loads(jd)
            except Exception:
                continue
            if not isinstance(d, dict):
                continue
            for k, v in d.items():
                if k not in JSON_TRANS_KEYS:
                    continue
                # 값 존재 여부(번역 universe)
                has_any = (isinstance(v, dict) and any(isinstance(x, str) and x.strip() for x in v.values())) \
                    or (isinstance(v, str) and v.strip())
                if not has_any:
                    continue
                total += 1
                if _val_for(v, lang):
                    tr += 1
        if total:
            add('JSON 속성', 'json_detail 번역대상 attr (meaning·material·names 등)',
                tr, total, '콘텐츠관리 > 엔티티 관리')
    except Exception:
        pass

    # ── book_names (페리코프 수집기 검색어 — 현지 책명) ──
    try:
        total = conn.execute("SELECT COUNT(DISTINCT book_code) FROM book_names").fetchone()[0]
        if total:
            tr = conn.execute(
                "SELECT COUNT(DISTINCT book_code) FROM book_names "
                "WHERE lang_code=? AND full_name IS NOT NULL AND full_name!=''",
                (lang,)).fetchone()[0]
            add('성경 책이름', 'book_names (수집 검색용·UI)', tr, total,
                '데이터관리 > 언어 관리(브리지)')
    except Exception:
        pass

    # ── YouTube 분류 키워드 (언어 버킷 작성 여부) ──
    try:
        import media_taxonomy as _tax
        _sets = _tax.load_classify_sets(conn)
        _cats = list(_tax.CLASSIFY_KW_KEYS)
        _tr = sum(1 for cat in _cats if _sets.get(cat, {}).get(lang))
        add('분류 키워드', '분류 키워드 언어 버킷(7종·COMMON 별도)', _tr, len(_cats),
            'YouTube 분류 관리 > 키워드 규칙')
    except Exception:
        pass

    # ── 가계도 카드 ──
    try:
        total = conn.execute("SELECT COUNT(DISTINCT card_key) FROM sys_genealogy_card").fetchone()[0]
        if total:
            tr = conn.execute("SELECT COUNT(DISTINCT card_key) FROM sys_genealogy_card "
                              "WHERE lang_code=?", (lang,)).fetchone()[0]
            add('가계도', '가계도 카드', tr, total, '데이터관리 > 가계도 카드 편집')
    except Exception:
        pass

    # ── 주석/참고자료/도서 (text_variant='TRANSLATED' 의 lang_code) ──
    for tbl, idcol, label, edit in [
            ('sys_commentary_text', 'entry_id', '주석 번역(TRANSLATED)', '콘텐츠관리 > 주석 관리자'),
            ('sys_ref_text', 'unit_id', '참고자료 번역(TRANSLATED)', '콘텐츠관리 > 사전 관리자 등'),
            ('sys_book_unit_text', 'unit_id', '도서 본문 번역(TRANSLATED)', '묵상플랜관리 > 도서/저자 관리')]:
        try:
            total = conn.execute(f"SELECT COUNT(DISTINCT {idcol}) FROM {tbl}").fetchone()[0]
            if not total:
                continue
            tr = conn.execute(
                f"SELECT COUNT(DISTINCT {idcol}) FROM {tbl} "
                "WHERE text_variant='TRANSLATED' AND lang_code=?", (lang,)).fetchone()[0]
            add('본문 번역', label, tr, total, edit)
        except Exception:
            pass

    conn.close()
    return rows


def summary(lang, db_path=DB):
    """전체 합계 (translated, total, pct)."""
    rows = coverage(lang, db_path)
    t = sum(r['translated'] for r in rows)
    n = sum(r['total'] for r in rows)
    return t, n, (t / n * 100 if n else 100.0)


# ── 미번역 브리지: export(미번역 열거) / import(번역 적용) ──────────────────────
# 행 스키마(CSV/JSON 공통): store, ref1, ref2, ko, en, value
#   ui_strings : ref1=string_id,  ref2=''
#   text_asset : ref1=text_type,  ref2=clicked_id
#   json_attr  : ref1=entity_id,  ref2=attr_key
EXPORT_FIELDS = ['store', 'ref1', 'ref2', 'ko', 'en', 'value']
STORE_LABELS = {'ui_strings': 'UI 문자열', 'text_asset': '텍스트 자산', 'json_attr': 'JSON 속성',
                'book_names': '성경 책이름'}


def export_rows(lang, stores, db_path=DB):
    """선택 store들의 '선택 언어 미번역' 항목 행 목록(value 칸 비움 — 채워서 import)."""
    conn = appdb.connect(db_path)
    rows = []
    try:
        if 'ui_strings' in stores:
            cache = {}
            for sid, lc, val in conn.execute(
                    'SELECT string_id, lang_code, string_value FROM ui_strings'):
                cache.setdefault(sid, {})[lc] = val
            for sid, lm in cache.items():
                if not lm.get(lang):
                    rows.append({'store': 'ui_strings', 'ref1': sid, 'ref2': '',
                                 'ko': lm.get('KO', ''), 'en': lm.get('EN', ''), 'value': ''})
        if 'text_asset' in stores:
            for tt, _label, _edit in TEXT_ASSET_TYPES:
                data = {}
                for cid, lc, c in conn.execute(
                        "SELECT clicked_id, lang_code, contents FROM sys_text_asset "
                        "WHERE text_type=? AND COALESCE(record_status,'LIVE')='LIVE'", (tt,)):
                    data.setdefault(cid, {})[lc] = c
                for cid, lm in data.items():
                    if not lm.get(lang):
                        rows.append({'store': 'text_asset', 'ref1': tt, 'ref2': str(cid),
                                     'ko': lm.get('KO', ''), 'en': lm.get('EN', ''), 'value': ''})
        if 'json_attr' in stores:
            for eid, jd in conn.execute(
                    "SELECT entity_id, json_detail FROM sys_entity_master "
                    "WHERE record_status='LIVE' AND json_detail IS NOT NULL AND json_detail!=''"):
                try:
                    d = json.loads(jd)
                except Exception:
                    continue
                if not isinstance(d, dict):
                    continue
                for k, v in d.items():
                    if k not in JSON_TRANS_KEYS:
                        continue
                    ko = v.get('KO') if isinstance(v, dict) else (v if isinstance(v, str) else None)
                    en = v.get('EN') if isinstance(v, dict) else None
                    has_any = ko or en or (isinstance(v, str) and v.strip())
                    if has_any and not _val_for(v, lang):
                        rows.append({'store': 'json_attr', 'ref1': str(eid), 'ref2': k,
                                     'ko': ko or '', 'en': en or '', 'value': ''})
        if 'book_names' in stores:
            data = {}
            for code, lc, full, short in conn.execute(
                    "SELECT book_code, lang_code, full_name, short_name FROM book_names"):
                data.setdefault(code, {})[lc] = (full or '', short or '')
            for code, lm in sorted(data.items()):
                if lang in lm and lm[lang][0]:    # 해당 언어 full_name 있음 → 번역됨
                    continue
                ko = lm.get('KO', ('', '')); en = lm.get('EN', ('', ''))
                rows.append({'store': 'book_names', 'ref1': str(code), 'ref2': 'full',
                             'ko': ko[0], 'en': en[0], 'value': ''})
                rows.append({'store': 'book_names', 'ref1': str(code), 'ref2': 'short',
                             'ko': ko[1], 'en': en[1], 'value': ''})
    finally:
        conn.close()
    return rows


def apply_rows(lang, rows, overwrite=False, dry_run=False, db_path=DB):
    """import: value 채워진 행을 store별로 UPSERT. 반환 통계 dict.
    dry_run=True 면 쓰기 없이 예측만."""
    conn = appdb.connect(db_path)
    st = {'applied': 0, 'skip_empty': 0, 'skip_exists': 0, 'errors': 0, 'detail': []}

    def err(msg):
        st['errors'] += 1
        if len(st['detail']) < 20:
            st['detail'].append(msg)

    try:
        for r in rows:
            val = (r.get('value') or '').strip()
            if not val:
                st['skip_empty'] += 1
                continue
            store, ref1, ref2 = r.get('store'), r.get('ref1'), r.get('ref2')
            try:
                if store == 'ui_strings':
                    ex = conn.execute("SELECT string_value FROM ui_strings "
                                      "WHERE string_id=? AND lang_code=?", (ref1, lang)).fetchone()
                    if ex and ex[0] and not overwrite:
                        st['skip_exists'] += 1; continue
                    if not dry_run:
                        conn.execute("INSERT OR REPLACE INTO ui_strings "
                                     "(string_id,lang_code,string_value) VALUES (?,?,?)",
                                     (ref1, lang, val))
                    st['applied'] += 1
                elif store == 'text_asset':
                    cid = int(ref2)
                    if not conn.execute("SELECT 1 FROM sys_text_asset WHERE text_type=? "
                                        "AND clicked_id=? LIMIT 1", (ref1, cid)).fetchone():
                        err(f'미존재 {ref1}/{cid}'); continue
                    ex = conn.execute(
                        "SELECT sys_text_id,contents FROM sys_text_asset WHERE text_type=? "
                        "AND clicked_id=? AND lang_code=? AND COALESCE(record_status,'LIVE')='LIVE'",
                        (ref1, cid, lang)).fetchone()
                    if ex and ex[1] and not overwrite:
                        st['skip_exists'] += 1; continue
                    if not dry_run:
                        if ex:
                            conn.execute("UPDATE sys_text_asset SET contents=? WHERE sys_text_id=?",
                                         (val, ex[0]))
                        else:
                            conn.execute("INSERT INTO sys_text_asset "
                                         "(clicked_id,text_type,contents,lang_code,record_status) "
                                         "VALUES (?,?,?,?, 'LIVE')", (cid, ref1, val, lang))
                    st['applied'] += 1
                elif store == 'json_attr':
                    eid = int(ref1); key = ref2
                    row = conn.execute("SELECT json_detail FROM sys_entity_master "
                                       "WHERE entity_id=?", (eid,)).fetchone()
                    if not row:
                        err(f'미존재 entity {eid}'); continue
                    d = json.loads(row[0]) if row[0] else {}
                    v = d.get(key)
                    if isinstance(v, dict):
                        if v.get(lang) and not overwrite:
                            st['skip_exists'] += 1; continue
                        v[lang] = val
                    elif isinstance(v, str):     # flat → nested (기존 flat은 KO 로 간주)
                        d[key] = {'KO': v} if lang != 'KO' else {}
                        d[key][lang] = val
                    else:
                        d[key] = {lang: val}
                    if not dry_run:
                        conn.execute("UPDATE sys_entity_master SET json_detail=? WHERE entity_id=?",
                                     (json.dumps(d, ensure_ascii=False), eid))
                    st['applied'] += 1
                elif store == 'book_names':
                    code = int(ref1)
                    col = 'short_name' if ref2 == 'short' else 'full_name'
                    ex = conn.execute("SELECT full_name, short_name FROM book_names "
                                      "WHERE book_code=? AND lang_code=?", (code, lang)).fetchone()
                    if ex:
                        cur_val = ex[1] if col == 'short_name' else ex[0]
                        if cur_val and not overwrite:
                            st['skip_exists'] += 1; continue
                        if not dry_run:
                            conn.execute(f"UPDATE book_names SET {col}=? "
                                         "WHERE book_code=? AND lang_code=?", (val, code, lang))
                    elif not dry_run:
                        conn.execute(
                            "INSERT INTO book_names (book_code, lang_code, full_name, short_name) "
                            "VALUES (?,?,?,?)",
                            (code, lang, val if col == 'full_name' else '',
                             val if col == 'short_name' else ''))
                    st['applied'] += 1
                else:
                    err(f'알 수 없는 store: {store}')
            except Exception as e:
                err(str(e))
        if not dry_run:
            conn.commit()
    finally:
        conn.close()
    return st


if __name__ == '__main__':
    import sys, io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    L = sys.argv[1] if len(sys.argv) > 1 else 'EN'
    print(f'=== 번역 커버리지: {L} ===')
    for r in coverage(L):
        bar = f"{r['translated']}/{r['total']}"
        print(f"  [{r['group']:8}] {r['label']:34} {bar:>12} {r['pct']:5.1f}%  → {r['edit']}")
    t, n, p = summary(L)
    print(f'  합계: {t}/{n} ({p:.1f}%)')
