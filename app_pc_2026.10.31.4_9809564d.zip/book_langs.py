"""어느 책을 이 언어 사용자에게 보이나 — 번역 없는 제목 감추기의 단일 소스(docs/통계_설계.md §9).

★ 규칙 — 그 언어 글이 있는 편이 90% 이상이거나, 이 기기에 책이 받아져 있으면 보인다. 영어는 늘 보인다.
⚠ 맛보기 조각은 안 센다 — 코어팩에 실린 조각(음수 text_id) 때문에 책이 있는 것처럼 보이면 안 된다.
⚠ 관리자 PC 는 원문이 다 있어 모두 보인다(받아 둔 책과 같은 규칙).

사용법: python book_langs.py --selftest
"""
import os
import sys

APP = os.path.dirname(os.path.abspath(__file__))
if APP not in sys.path:
    sys.path.insert(0, APP)

FULL_RATIO = 0.9


def visible(conn, lang):
    """보일 book_id 집합"""
    L = (lang or 'EN').upper()
    ids = {r[0] for r in conn.execute(
        "SELECT book_id FROM sys_book_asset WHERE COALESCE(record_status,'LIVE')='LIVE'")}
    if L == 'EN':
        return ids
    total = dict(conn.execute(
        "SELECT book_id, COUNT(*) FROM sys_book_unit WHERE COALESCE(record_status,'LIVE')='LIVE' GROUP BY 1"))
    held = {}
    here = {}
    for bid, lg, n in conn.execute(
            "SELECT u.book_id, UPPER(t.lang_code), COUNT(DISTINCT u.unit_id) FROM sys_book_unit u"
            " JOIN sys_book_unit_text t ON t.unit_id=u.unit_id"
            " WHERE COALESCE(u.record_status,'LIVE')='LIVE' AND t.text_id>0 GROUP BY 1,2"):
        held[bid] = max(held.get(bid, 0), n)
        if lg == L:
            here[bid] = n
    out = set()
    for bid in ids:
        t = total.get(bid, 0)
        if t and max(held.get(bid, 0), here.get(bid, 0)) >= t * FULL_RATIO:
            out.add(bid)
    return out


def visible_for(db_path, lang):
    """화면용 — 못 읽으면 None(거르지 않는다 · 목록이 통째로 사라지면 안 된다)"""
    import appdb
    try:
        with appdb.connect(db_path) as c:
            return visible(c, lang)
    except Exception as e:                                # noqa: BLE001
        print('[book_langs] %s' % e)
        return None


def selftest():
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.executescript("""
    CREATE TABLE sys_book_asset(book_id INTEGER, record_status TEXT);
    CREATE TABLE sys_book_unit(unit_id INTEGER, book_id INTEGER, record_status TEXT);
    CREATE TABLE sys_book_unit_text(text_id INTEGER, unit_id INTEGER, lang_code TEXT);
    INSERT INTO sys_book_asset VALUES(1,'LIVE'),(2,'LIVE'),(3,'LIVE'),(4,'HIDE');
    """)
    for b in (1, 2, 3, 4):
        for n in range(10):
            c.execute("INSERT INTO sys_book_unit VALUES(?,?,'LIVE')", (b * 100 + n, b))
    # 1 = 영어 전권 받음 · 2 = 맛보기뿐(음수) · 3 = 맛보기 + 프랑스어 9/10
    for n in range(10):
        c.execute("INSERT INTO sys_book_unit_text VALUES(?,?,'EN')", (n + 1, 100 + n))
    c.execute("INSERT INTO sys_book_unit_text VALUES(-1,200,'KO')")
    c.execute("INSERT INTO sys_book_unit_text VALUES(-2,300,'KO')")
    for n in range(9):
        c.execute("INSERT INTO sys_book_unit_text VALUES(?,?,'FR')", (50 + n, 300 + n))
    ok = True

    def ck(cond, m):
        nonlocal ok
        print(('PASS ' if cond else 'FAIL ') + m)
        ok = ok and cond
    ck(visible(c, 'EN') == {1, 2, 3}, '영어는 살아 있는 책 전부')
    ck(2 not in visible(c, 'KO'), '맛보기뿐인 책은 감춘다')
    ck(1 in visible(c, 'KO'), '받아 둔 책은 언어와 상관없이 보인다')
    ck(3 in visible(c, 'FR') and 3 in visible(c, 'KO'), '90% 있으면 보인다')
    ck(4 not in visible(c, 'FR'), '내린 책은 안 보인다')
    c.execute("DELETE FROM sys_book_unit_text WHERE text_id=50")
    ck(3 not in visible(c, 'FR'), '80% 면 감춘다')
    print('book_langs selftest: %s' % ('OK' if ok else 'FAIL'))
    return 0 if ok else 1


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(selftest())
