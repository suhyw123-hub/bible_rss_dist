# -*- coding: utf-8 -*-
"""성경 인용을 **개역한글 본문과 실제로 대조한다** — 영구 도구.

★★★ **왜 만들었나** (2026-09-25 사용자 「성경구절도 번역해버린 것 같다」 ·
  「대조 게이트 만들어라」). 도서 번역 프로필에 「성경구절을 인용할 때에는
  개역한글을 인용한다」가 **이미 적혀 있었는데도** 실측 인용 112곳 가운데
  **53곳(47%)이 개역한글과 안 맞았다**. 프롬프트만으로는 샌다.

    히 11:23  KRV 「모세가 났을 때에 그 부모가 아름다운 아이임을」
              AI  「모세가 태어났을 때, 부모는 그가 잘생긴 아이임을」
    행 7:22   KRV 「애굽 사람의 학술을 다 배워」
              AI  「이집트 사람들의 모든 지혜를 배워」(게다가 「현대인의 성경」)
    민 14:25  KRV 「광야로 **들어갈지니라**」 → AI 「광야로 **유인할지니라**」

★★★ **잣대는 글자 겹침 하나뿐이다.** 「잘 옮겼나」를 묻지 않는다. 물음은
  **「우리 역본의 글자를 그대로 가져왔나」** 이고 그것은 기계가 정확히 잰다.
⚠⚠⚠ **부분 인용을 벌하지 않는다** — 겹침은 **내가 쓴 글 기준**(내 인용이
  역본 안에 얼마나 들어 있나)이다. 한 절의 앞머리만 따오는 것은 정상이고,
  거꾸로 역본에 없는 말을 섞으면 그때 값이 떨어진다.
⚠⚠ **문턱 둘 — 막는 것과 알리는 것을 가른다**(`db_study_gate` 와 같은 문법).
  실측 표본으로 정했다: 0.60 아래는 거의 전부 재번역이고, 0.60~0.85 는
  부분 인용(계 15:3)과 재번역(히 11:23)이 섞여 있어 **사람이 봐야 한다**.
⚠ **역본 본문을 흠 줄에 함께 적는다** — 「다르다」만 알리면 어디를 고칠지
  모른다. 무엇이 다른지 나란히 보인다.

쓰는 곳 = `db_ai_run.gate_item`(도서 본문 · 연구자료).
CLI = `--selftest`(의무) · `--job N`(그 작업의 인용 분포 — 문턱을 다시 잴 때).
"""
import difflib
import re
import sys

BAD = 0.60          # 이보다 낮으면 **흠** — 다시 번역한 것이다
SOFT = 0.85         # 이보다 낮으면 **알림** — 사람이 본다
MIN_LEN = 6         # 이보다 짧은 인용은 재지 않는다(겹침이 요동친다)
MAX_LINES = 40      # 한 글에서 적을 인용 줄 상한

# ★★★ **언어마다 기준 역본이 다르다**(2026-09-25 사용자 지시) —
#   프롬프트와 게이트가 **이 표 하나**를 읽는다. 두 곳에 적으면 「프롬프트는
#   시노드역이라 했는데 게이트는 개역한글로 잰다」가 된다.
#   ✅ 실측 — 11언어 전부 역본이 있고 `book_names` 도 11언어 × 66권이 있다.
#   ⚠ 한 언어에 여럿인 곳은 **골랐다**: EN 은 우리 기준 역본 BSB(§273차),
#     FR 은 개신교 표준 Louis Segond(§18-8 「Darby 보다 평신도 사용도 높다」),
#     ZH 간체 CUVS · ZHT 번체 CUV.
#   ⚠ **모르는 언어는 안 잰다** — 지어낸 기준으로 재면 온 글이 흠이 된다.
VERSION_OF = {
    'KO': 'KRV',     'EN': 'BSB',      'RU': 'RusSyn',
    # ⚠⚠⚠ **일본어는 기준 역본이 없다**(2026-09-25 실측) — `JLV` 는
    #   역본 목록에만 있고 `bible_content` 가 **0행**이다. 이름만
    #   적어 두면 게이트가 본문을 못 찾아 **조용히 통과**한다
    #   (표본 JA 가 실제로 그러했다). 일본어 본문을 담는 날
    #   되살린다: 'JA': '<역본 코드>',
    'ZH': 'CUVS',    'ZHT': 'CUV',     'DE': 'GerElb',   'FR': 'FreLSG',
    'ES': 'SpaRV',   'PT': 'PorBL',    'AR': 'ARB',
}

VERSION = 'KRV'     # 기본(한국어)


def version_for(lang):
    """그 언어의 기준 역본 — 모르면 `None`(안 잰다)."""
    return VERSION_OF.get((lang or '').upper())

# “본문” (출처) · "본문" — 출처 · 「본문」(출처)
CITE = re.compile(
    u'[\u201c\u300c"]([^\u201d\u300d"]{%d,400})[\u201d\u300d"]'
    u'\\s*[(\uff08\u2014\u2013-]?\\s*'
    u'([\uac00-\ud7a3]{1,5}\\s?\\d{1,3}[:장]\\s?\\d{1,3}[^)\uff09\\n]{0,24})'
    u'[)\uff09]?' % MIN_LEN)

# 「(15절)」처럼 **책 이름 없이** 절 번호만 적은 자리
NOBOOK = re.compile(u'[(\uff08]\\s*\\d{1,3}\\s*(?:,\\s*\\d{1,3}\\s*)*절\\s*[)\uff09]')

# 우리 역본이 아닌 판 이름 — 적으면 그 자리에서 드러난다
OTHER_VER = ('현대인의 성경', '새번역', '공동번역', '개역개정', '쉬운성경',
             '새한글', 'NIV', 'KJV', 'ESV', 'NASB', 'NLT', 'RSV')

# 마크다운 표시 — 본문에 그대로 실려 나간다
MD = ((re.compile(r'^\s*>\s', re.M), '인용 표시(>)'),
      (re.compile(r'\*\*'), '굵게 표시(**)'),
      (re.compile(r'^#{1,6}\s', re.M), '머리글 표시(#)'))


def _norm(s):
    """한글만 남긴다 — 구두점·공백·따옴표 차이로 흔들리지 않게."""
    return re.sub(u'[^\uac00-\ud7a3]', '', s or '')


def _norm_any(s):
    """**어느 언어든** 글자·숫자만 남긴다(대소문자 접음).

    ⚠ `_norm` 은 한글만 남긴다 — 한국어 글을 잴 때는 그것이 맞지만
      러시아어·일본어를 넣으면 **빈 글**이 되어 겹침이 늘 0 이다.
    """
    import unicodedata
    out = []
    for ch in (s or ''):
        if ch.isalnum():
            out.append(unicodedata.normalize('NFKC', ch).lower())
    return ''.join(out)


def overlap_any(mine, real):
    """`overlap` 과 같은 잣대 — 다만 **언어를 안 가린다**."""
    a, b = _norm_any(mine), _norm_any(real)
    if not a or not b:
        return 0.0
    sm = difflib.SequenceMatcher(None, a, b)
    return sum(x.size for x in sm.get_matching_blocks()) / len(a)


def tidy_ref(ref):
    """출처 표기 → `(약명 장:절, 쉼표로 이은 끝절 또는 None)`.

    ⚠ 「히브리서 11장 24절」·「골 2:9, 10」·「행 7:24–25」가 다 온다.
      **꼴을 못 박는 것은 프롬프트의 일이고 여기서는 읽어 준다** — 표기가
      제멋대로라고 대조를 포기하면 정작 재야 할 것을 못 잰다.
    """
    r = (ref or '').strip()
    r = r.replace('장 ', ':').replace('장', ':')
    r = re.sub(u'절.*$', '', r)                        # 「…절」 꼬리
    r = re.sub(u'\\s*[\u2013\u2014-]\\s*\\d+\\s*$', '', r)   # 「7:24–25」의 끝절
    m = re.match(u'^([\uac00-\ud7a3]{1,5})\\s*(\\d{1,3}):(\\d{1,3})'
                 u'(?:\\s*[,\uff0c]\\s*(\\d{1,3}))?', r)
    if not m:
        return r.split(',')[0].strip(), None
    tail = int(m.group(4)) if m.group(4) else None
    return '%s %s:%s' % (m.group(1), m.group(2), m.group(3)), tail


def verse_text(conn, ref, ver=VERSION):
    """그 출처의 역본 본문. 못 풀면 `None`.

    ⚠ 「골 2:9, 10」처럼 **쉼표로 이은 두 절**은 이어 붙인다 — 안 그러면
      9절만 보고 「반쪽만 맞다」로 잡는다(실측 겹침 0.58).
    """
    import scripture_ref_kr as SR
    base, tail = tidy_ref(ref)
    a, b = SR.resolve(conn, base)
    if not a:
        return None
    if tail:
        m = re.match(u'^([\uac00-\ud7a3]{1,5})\\s*(\\d{1,3}):', base)
        if m:
            _a2, b2 = SR.resolve(conn, '%s %s:%d'
                                 % (m.group(1), m.group(2), tail))
            if b2:
                b = max(b, b2)
    rs = conn.execute(
        "SELECT verse_text FROM bible_content WHERE version_code=?"
        "  AND verse_id BETWEEN ? AND ? ORDER BY verse_id",
        (ver, a, b)).fetchall()
    t = ' '.join((x[0] or '') for x in rs).strip()
    return t or None


def overlap(mine, real):
    """**내가 쓴 글 기준** 겹침 — 부분 인용을 벌하지 않는다."""
    a, b = _norm(mine), _norm(real)
    if not a or not b:
        return 0.0
    sm = difflib.SequenceMatcher(None, a, b)
    return sum(x.size for x in sm.get_matching_blocks()) / len(a)


def cites(text):
    """`[(본문, 출처표기)]` — **출처가 붙은 인용만** 집는다.

    ⚠ 출처 없는 따옴표는 안 집는다 — 저자의 대화문·강조를 성경 인용으로
      보면 온 글이 흠투성이가 된다.
    """
    return [(m.group(1).strip(), m.group(2).strip())
            for m in CITE.finditer(text or '')]


# ── 원본을 닻으로 — 어느 언어로 옮겨도 잰다 (2026-09-25) ──────────────
#  ⚠ `check()` 는 **그 글 안의 한국어 약명**을 찾는다. 러시아어·일본어 글에는
#    그런 표기가 없어 아무것도 못 찾는다(조용한 통과). 그래서 **원본(한국어)
#    에서 출처를 찾고**, 그 절의 **그 언어 역본 본문**을 옮긴 글에서 찾는다.

PROSE = re.compile('([가-힣]{1,7})\\s*(\\d{1,3})\\s*장\\s*(\\d{1,3})\\s*절')
QUOTED = 0.50        # 원본이 그 절을 **인용했다**고 볼 겹침
RUN_MIN = 12         # 이만큼 **이어져** 같으면 그 역본을 옮겨 적은 것이다


def src_refs(text):
    """원본에서 출처 표기를 집는다 — 「…」(렘 8:20) 꼴과 「예레미야 8장 20절」 꼴.

    ⚠ 뒤엣것은 `cites()` 가 못 집는다 — 출처가 인용부호 **뒤**에 오고
      사이에 조사가 낀다(「…」는 예레미야 8장 20절로).
    """
    out = [r for _q, r in cites(text or '')]
    out += ['%s %s:%s' % m for m in PROSE.findall(text or '')]
    seen, uniq = set(), []
    for r in out:
        k = _norm(r)
        if k and k not in seen:
            seen.add(k)
            uniq.append(r)
    return uniq


def longest_run(want, out):
    """`(가장 긴 이어진 토막 길이, 그 비율)` — 언어를 안 가린다."""
    a, b = _norm_any(want), _norm_any(out)
    if not a or not b:
        return 0, 0.0
    m = difflib.SequenceMatcher(None, a, b).find_longest_match(
        0, len(a), 0, len(b))
    return m.size, m.size / float(len(a))


def check_against(conn, src, out, lang, base='KO'):
    """원본이 인용한 절을 **옮긴 글이 그 언어 역본대로 적었는가**.

    흠·알림 목록(알림은 괄호로 시작한다 — `db_ai_run._is_note` 규약).
    ⚠ 기준 역본을 모르는 언어는 **안 잰다** — 지어낸 기준으로 재면 온 글이
      흠이 된다.
    ⚠ **원본이 인용하지 않은 절은 안 잰다** — 참조만 적은 자리를 벌하지 않는다.
    """
    tv, bv = version_for(lang), version_for(base)
    if not tv or not bv or tv == bv:
        return []
    lines = []
    for ref in src_refs(src):
        want = verse_text(conn, ref, tv)
        mine = verse_text(conn, ref, bv)
        if not want or not mine or len(_norm_any(want)) < MIN_LEN:
            continue
        # ⚠ 원본(한국어)은 `overlap` 으로 — 옮긴 글은 **언어를 안 가리는** 쪽으로.
        if overlap(mine, src) < QUOTED:      # 원본이 인용하지 않았다
            continue
        # ★ **이어진 토막**으로 가른다 — 겹침만 보면 차례만 바꾼
        #   다시 번역을 놓친다(실측 겹침 0.69 · 토막 9자).
        run, rate = longest_run(want, out or '')
        need = min(RUN_MIN, int(len(_norm_any(want)) * 0.7) or 1)
        if run >= need or rate >= 0.6:
            continue
        got = overlap_any(want, out or '')
        lines.append('%s 인용이 %s 본문과 다릅니다(그대로 이어진 토막 %d자 · '
                     '겹침 %.2f) — 그 역본 글자 그대로 써야 합니다: %s'
                     % (ref, tv, run, got, want[:60]))
    return lines


QUOTE_GAP = 30      # 인용부호와 출처 표기 사이 이만큼까지는 한 인용으로 본다
_QO = ''.join(chr(x) for x in (0x201C, 0x22, 0xAB, 0x300C, 0x300E, 0x201E))   # 여는 인용부호 · ⚠ 홑따옴표는 뺀다(영어 아포스트로피)
_QC = ''.join(chr(x) for x in (0x201D, 0x22, 0xBB, 0x300D, 0x300F, 0x201C))   # 닫는 인용부호
QUOTE_ANY = re.compile('[%s]([^%s%s]{%d,800})[%s]' % (re.escape(_QO), re.escape(_QC), chr(10), MIN_LEN,
                                                    re.escape(_QC)))

def _vtext(conn, vid_a, vid_b, ver):
    rs = conn.execute(
        "SELECT verse_text FROM bible_content WHERE version_code=?"
        "  AND verse_id BETWEEN ? AND ? ORDER BY verse_id",
        (ver, vid_a, vid_b)).fetchall()
    return ' '.join((x[0] or '') for x in rs).strip()


def check_any(conn, text, lang):
    """**어느 언어로 쓴 글이든** 성경 인용을 그 언어 기준 역본과 글자로 견준다(317차-11).

    ★ 사용자 지시 「성경인용을 자동 대조하는 것을 **모든 다국어에** 적용하라」.
    · 출처를 찾는 문 = `scripture_ref.find(conn, text, lang)` — **그 언어 약명**을 읽는다
      (`check()` 는 한국어 약명만 푼다).
    · **인용부호로 묶인 글이 출처 표기 바로 앞(또는 뒤)에 있을 때만** 인용으로 본다 —
      한국어 `check()` 의 「출처가 붙은 인용만 집는다」와 같은 규칙(「(요 3:16 참고)」는 안 잰다).
    · 잣대 둘 — 겹침(`overlap_any` · 쓴 글 기준 — 부분 인용을 벌하지 않는다) +
      **이어진 토막**(쓴 글의 60% 이상이 한 토막이라야 — 차례만 바꾼 재번역을 잡는다).
    ⚠ 장만 적은 참조는 안 잰다 · 기준 역본을 모르는 언어는 **안 잰다**.
    """
    ver = version_for(lang)
    if not ver or not text:
        return []
    try:
        import scripture_ref as SR
        refs = SR.find(conn, text, lang)
    except Exception:                                     # noqa: BLE001
        return []
    quotes = [(m.start(), m.end(), m.group(1)) for m in QUOTE_ANY.finditer(text)]
    out, shown, pos = [], 0, 0
    for a, b, matched, kind in refs:
        if kind == getattr(SR, 'KIND_CHAPTER', 'CHAPTER') or (b - a) > 6 or not matched:
            continue
        at = text.find(matched, pos)
        if at < 0:
            at = text.find(matched)
        if at < 0:
            continue
        pos = at
        end = at + len(matched)
        body = None
        for qs, qe, qb in quotes:
            if 0 <= at - qe <= QUOTE_GAP or 0 <= qs - end <= QUOTE_GAP:
                body = qb
                break
        if not body or len(_norm_any(body)) < MIN_LEN:
            continue                                      # 인용이 아니라 참조만
        want = _vtext(conn, a, b, ver)
        if not want:
            continue
        c = overlap_any(body, want)
        nb = _norm_any(body)
        run = difflib.SequenceMatcher(None, nb, _norm_any(want)).find_longest_match(
            0, len(nb), 0, len(_norm_any(want))).size
        rf = run / float(len(nb) or 1)
        if c >= SOFT and rf >= 0.6:
            continue
        line = ('%s 인용이 %s 본문과 다릅니다(겹침 %.2f · 이어진 토막 %d%%) — %s: %s'
                % (matched, ver, c, int(rf * 100), ver, want[:60]))
        if shown < MAX_LINES:
            shown += 1
            out.append(line if (c < BAD or rf < 0.6) else '(' + line + ')')
    return out


def check_lang(conn, text, lang):
    """화면이 부르는 한 문 — 한국어는 `check`(인용부호·출처 꼴), 그 밖의 언어는 `check_any`."""
    if (lang or 'KO').upper() == 'KO':
        return check(conn, text, lang='KO')
    return check_any(conn, text, lang)


def check(conn, text, ver=VERSION, lang=None):
    """흠·알림 목록. 알림은 **괄호로 시작한다**(`db_ai_run._is_note` 규약).

    `lang` 을 주면 **그 언어의 기준 역본**으로 잰다(`VERSION_OF`).
    ⚠ 여기서 판정하지 않는다 — 줄만 낸다. 무엇이 흠인지는 부르는 쪽이
      괄호로 가른다. 두 곳에서 판정하면 갈린다.
    """
    if lang:
        v = version_for(lang)
        if not v:
            return []          # 기준을 모르는 언어 — **안 잰다**
        ver = v
    out = []
    t = text or ''
    for rx, name in MD:
        if rx.search(t):
            out.append('%s가 본문에 있습니다 — 그대로 실려 나갑니다.' % name)
    for v in OTHER_VER:
        if v in t:
            out.append('다른 역본 이름이 있습니다: %s '
                       '(우리는 %s 로 인용합니다)' % (v, ver))
    n = len(NOBOOK.findall(t))
    if n:
        out.append('(책 이름 없이 절 번호만 적은 자리 %d곳 — 다른 화면에서는 '
                   '어느 책인지 알 수 없습니다)' % n)

    rows = cites(t)
    if not rows:
        return out
    ok = soft = bad = unres = shown = 0
    for body, ref in rows:
        real = verse_text(conn, ref, ver)
        if real is None:
            unres += 1
            if shown < MAX_LINES:
                shown += 1
                out.append('(출처를 못 풀었습니다: %s)' % ref)
            continue
        c = overlap(body, real)
        if c >= SOFT:
            ok += 1
            continue
        line = ('%s 인용이 %s 본문과 다릅니다(겹침 %.2f)\n'
                '      쓴 글: %s\n      %s: %s'
                % (ref, ver, c, body[:70], ver, real[:70]))
        if c < BAD:
            bad += 1
            if shown < MAX_LINES:
                shown += 1
                out.append(line)
        else:
            soft += 1
            if shown < MAX_LINES:
                shown += 1
                out.append('(' + line + ')')
    out.append('(인용 %d곳 — 그대로 %d · 사람이 볼 것 %d · 다르다 %d · '
               '못 풀음 %d)' % (len(rows), ok, soft, bad, unres))
    return out


# ───────────────────────── 자가 검증 ─────────────────────────
def _selftest():
    import appdb
    bad = []
    n = [0]

    def ck(name, cond, got=''):
        n[0] += 1
        if not cond:
            bad.append('%s %s' % (name, got))

    conn = appdb.connect()
    try:
        # ⓩ **원본을 닻으로** — 어느 언어로 옮겨도 잰다(2026-09-25)
        _src = ('마지막 편은 「추수할 때가 지나고 여름이 다하였으나 우리는 '
                '구원을 얻지 못한다 하는도다」는 예레미야 8장 20절로 한 해를 닫는다.')
        ck('원본에서 출처를 못 집는다', src_refs(_src) == ['예레미야 8:20'],
           src_refs(_src))
        _ru = verse_text(conn, '예레미야 8:20', 'RusSyn') or ''
        ck('시노드역 본문을 못 읽는다', len(_ru) > 10, _ru[:40])
        ck('그대로 썼는데 흠이다',
           check_against(conn, _src, '... %s ...' % _ru, 'RU') == [],
           check_against(conn, _src, _ru, 'RU'))
        _bad = check_against(
            conn, _src,
            '«Жатва прошла, лето кончилось, а мы не спаслись»', 'RU')
        ck('구절을 다시 번역했는데 안 잡는다',
           bool(_bad) and not _bad[0].startswith('('), _bad)
        ck('부분 인용을 흠으로 잡는다',
           check_against(conn, _src, '«%s»' % _ru[:22], 'RU') == [],
           check_against(conn, _src, _ru[:22], 'RU'))
        ck('토막을 못 센다', longest_run(_ru, '... %s ...' % _ru)[1] == 1.0)
        ck('기준을 모르는 언어를 잰다',
           check_against(conn, _src, 'whatever', 'XX') == [])
        ck('같은 언어인데 잰다', check_against(conn, _src, 'x', 'KO') == [])
        ck('원본이 인용 안 한 절을 잰다',
           check_against(conn, '예레미야 8장 20절을 보라.', 'nothing', 'RU') == [])

        # ⓐ 본문을 꺼내 온다 — 약명도 정식명도
        real = verse_text(conn, '히 11:24')
        ck('히 11:24 본문을 못 읽는다', bool(real))
        ck('정식명도 읽어야 한다',
           verse_text(conn, '히브리서 11장 24절') == real)

        # ⓑ ★★★ **그대로 옮기면 통과** — 이 검사가 없으면 게이트가 늘 운다
        ls = check(conn, '제목\n\u201c%s\u201d (히 11:24)' % real)
        ck('그대로 인용했는데 흠이다',
           not [l for l in ls if not l.startswith('(')], ls[:1])

        # ⓒ **부분 인용도 통과** — 앞머리만 따오는 것은 정상이다
        ck('부분 인용을 흠으로 잡는다',
           not [l for l in check(conn, '\u201c%s\u201d (히 11:24)' % real[:14])
                if not l.startswith('(')])

        # ⓓ **다시 번역하면 잡는다**(실측 그 문장)
        ls = check(conn, '\u201c믿음으로 모세가 태어났을 때, 부모는 그가 잘생긴 '
                         '아이임을 보고 석 달 동안 숨겼고, 왕의 명령을 '
                         '두려워하지 않았습니다.\u201d (히 11:23)')
        ck('다시 번역한 인용을 못 잡는다', any('겹침' in l for l in ls), ls[:1])

        # ⓔ **뜻이 바뀐 자리**(민 14:25 들어갈지니라 → 유인할지니라)
        ck('뜻이 바뀐 인용을 통과시킨다',
           any('겹침' in l for l in check(
               conn, '\u201c내일 너희는 돌이켜 홍해 길을 따라 광야로 '
                     '유인할지니라\u201d (민수기 14:25)')))

        # ⓕ 다른 역본 이름 · 마크다운 · 책 없는 절 번호
        ck('다른 역본 이름을 못 잡는다',
           any('현대인의 성경' in l
               for l in check(conn, '그러하였다(현대인의 성경).')))
        ck('인용 표시(>)를 못 잡는다',
           any('>' in l for l in check(conn, '> 인용입니다')))
        ck('굵게 표시를 못 잡는다',
           any('굵게' in l for l in check(conn, '**굵게** 적었다')))
        ck('책 없는 절 번호를 못 잡는다',
           any('책 이름 없이' in l for l in check(conn, '그러하였다 (15절).')))

        # ⓖ ★ **깨끗한 글은 한 줄도 안 운다** — 거짓 흠은 진짜 흠을 묻는다
        ck('깨끗한 글을 이 셋으로 울린다', not check(conn, '그러한 글입니다.'))

        # ⓗ **출처 없는 따옴표는 안 집는다**(저자의 대화문)
        ck('출처 없는 따옴표를 인용으로 본다',
           not cites('\u201c내게는 할 수 없는 일이 없다.\u201d'))

        # ⓘ **쉼표로 이은 두 절**을 이어 붙인다(골 2:9, 10)
        one, two = verse_text(conn, '골 2:9'), verse_text(conn, '골 2:9, 10')
        ck('쉼표로 이은 둘째 절을 안 읽는다',
           bool(one) and bool(two) and len(two) > len(one))

        # ⓙ 못 푸는 출처는 **그렇다고 말한다**(조용히 안 넘긴다)
        ck('못 푸는 출처를 조용히 넘긴다',
           any('못 풀었' in l for l in check(
               conn, '\u201c어떤 글입니다 그러하였다\u201d (없는책 1:1)')))

        # ⓚ 겹침 셈 — 방향이 맞는가
        ck('같은 글의 겹침이 1.0 이 아니다',
           abs(overlap('가나다라마', '가나다라마') - 1.0) < 1e-9)
        ck('부분 인용 겹침이 1.0 이 아니다',
           abs(overlap('가나다', '가나다라마') - 1.0) < 1e-9)
        ck('딴 글의 겹침이 높다', overlap('하나둘셋넷', '가나다라마') < 0.5)
        ck('빈 글에서 터진다', overlap('', '가나다') == 0.0)

        # ⓛ 문턱 자체 — 막는 것과 알리는 것이 갈리는가
        ck('문턱 차례가 뒤집혔다', 0 < BAD < SOFT <= 1.0)

        # ⓜ ★★★ **언어마다 기준 역본**(2026-09-25 사용자 「러시아어 번역할 때
        #   성경구절 인용은 시노드버전으로」)
        ck('러시아어 기준이 시노드역이 아니다', version_for('RU') == 'RusSyn')
        ck('소문자 언어 코드를 못 읽는다', version_for('ru') == 'RusSyn')
        ck('모르는 언어에 기준을 지어낸다', version_for('XX') is None)
        # ⚠ **표에 적은 역본이 실제로 DB 에 있어야 한다** — 없으면 그 언어의
        #   글이 통째로 「출처를 못 풀었다」가 된다(조용한 실패).
        _have = set(r[0] for r in conn.execute(
            "SELECT DISTINCT version_code FROM bible_version"))
        # ★★★ **등록만 된 역본은 없는 것과 같다** — 본문 행수를 센다.
        _rows = dict(conn.execute(
            "SELECT version_code, COUNT(*) FROM bible_content"
            "  GROUP BY version_code"))
        _miss = [v for v in VERSION_OF.values()
                 if v not in _have or not _rows.get(v)]
        ck('표의 역본이 DB 에 없다 %s' % (_miss,), not _miss)
        # ⚠ **모르는 언어는 한 줄도 안 낸다**(지어낸 기준으로 재지 않는다)
        ck('모르는 언어를 그래도 잰다',
           check(conn, '“%s” (히 11:24)' % real, lang='XX') == [])
        # ★ 언어를 주면 **그 역본 이름**이 흠 줄에 적힌다
        _ru = check(conn, '“어떤 글입니다 '
                          '그러하였다” '
                          '(히 11:24)', lang='RU')
        ck('러시아어로 재는데 KRV 라 적는다',
           not any('KRV' in x for x in _ru), str(_ru[:1]))

        # ⚠⚠ **지금은 한국어 약명만 푼다** — `scripture_ref_kr` 이 한국어
        #   전용이다. 다른 언어로 쓴 글이 그 언어의 약명을 쓰면 「출처를 못
        #   풀었습니다」가 나온다. **그 사실을 못 박아 둔다**(조용히 0건이
        #   되지 않게) — 다국어 약명 해석은 별개 작업이다.
        # ★ 317차-11 — **어느 언어든** 그 언어 약명·역본으로 잰다(`check_any`)
        _jn = _vtext(conn, 43003016, 43003016, 'BSB')
        _vid = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=43 AND chapter=3 AND verse=16").fetchone()
        if _vid:
            _jn = _vtext(conn, _vid[0], _vid[0], 'BSB')
            ck('영어 역본 본문을 못 읽는다', len(_jn) > 20, _jn[:40])
            ck('영어 — 그대로 인용했는데 흠이다',
               check_any(conn, 'Jesus said: "%s" (John 3:16).' % _jn, 'EN') == [],
               check_any(conn, 'x "%s" (John 3:16)' % _jn, 'EN'))
            _para = ('"God loved all people so much that He sent His one and only Son, so that anyone '
                     'who trusts in Him will not die but live forever" (John 3:16).')
            _swap = '"%s" (John 3:16)' % ' '.join(reversed(_jn.split()))
            ck('영어 — 낱말 차례만 바꾼 인용을 못 잡는다', len(check_any(conn, _swap, 'EN')) == 1,
               check_any(conn, _swap, 'EN'))
            ck('영어 — 부분 인용(앞머리만 그대로)을 흠으로 잡는다',
               check_any(conn, '"%s" (John 3:16)' % _jn[:40], 'EN') == [],
               check_any(conn, '"%s" (John 3:16)' % _jn[:40], 'EN'))
            ck("영어 — 아포스트로피를 인용부호로 읽는다",
               check_any(conn, "God's love is Christ's gift (John 3:16).", 'EN') == [])
            ck('영어 — 다시 지어 쓴 인용을 못 잡는다', len(check_any(conn, _para, 'EN')) == 1,
               check_any(conn, _para, 'EN'))
            ck('영어 — 참조만 적은 자리를 흠으로 잡는다',
               check_any(conn, 'This theme recurs throughout the Gospel (see John 3:16).', 'EN') == [])
            _ru2 = _vtext(conn, _vid[0], _vid[0], 'RusSyn')
            if _ru2:
                ck('러시아어 — 그대로 인용했는데 흠이다',
                   check_any(conn, '«%s» (Ин 3:16)' % _ru2, 'RU') == [],
                   check_any(conn, '«%s» (Ин 3:16)' % _ru2, 'RU'))
            ck('한국어는 옛 문(`check`)으로 간다', check_lang(conn, '본문 없음', 'KO') == check(conn, '본문 없음', lang='KO'))
            ck('기준 역본 없는 언어를 잰다', check_any(conn, _para, 'JA') == [])
        ck('한국어 약명을 못 푼다', verse_text(conn, '히 11:24') is not None)
        ck('다국어 약명이 풀리기 시작했다면 이 검사를 고칠 것',
           verse_text(conn, 'Heb 11:24') is None)
    finally:
        try:
            conn.close()
        except Exception:                                 # noqa: BLE001
            pass

    print('[db_cite_gate] %d개 검사 · 흠 %d건' % (n[0], len(bad)))
    for b in bad:
        print('  FAIL', b)
    return 1 if bad else 0


def _job(job_id):
    """그 작업이 받은 글의 인용 분포 — 문턱을 다시 잴 때 쓴다."""
    import appdb
    conn = appdb.connect()
    t = {'ok': 0, 'soft': 0, 'bad': 0, 'unres': 0}
    for (txt,) in conn.execute(
            "SELECT out_text FROM sys_ai_item WHERE job_id=?"
            "  AND TRIM(COALESCE(out_text,''))<>''", (job_id,)):
        for body, ref in cites(txt):
            real = verse_text(conn, ref)
            if real is None:
                t['unres'] += 1
                continue
            c = overlap(body, real)
            t['ok' if c >= SOFT else ('bad' if c < BAD else 'soft')] += 1
    print('작업 %d — 그대로 %d · 사람이 볼 것 %d · 다르다 %d · 못 풀음 %d'
          % (job_id, t['ok'], t['soft'], t['bad'], t['unres']))
    return 0


def main():
    a = sys.argv[1:]
    if '--selftest' in a:
        return _selftest()
    if '--job' in a:
        return _job(int(a[a.index('--job') + 1]))
    print(__doc__)
    return 0


if __name__ == '__main__':
    sys.exit(main())
