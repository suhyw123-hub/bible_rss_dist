# -*- coding: utf-8 -*-
"""「내 수정 (E)」 — 사용자 덮개 총괄 창 (2026-08-26 사용자 확정 설계).

★★★ 왜 하나인가 — 「E 버튼 클릭할 때마다 화면 특화 팝업」 대신 **총괄 화면
  하나 + 클릭한 위치에 따라 탭 포커스**(사용자 승인). 덮개는 한 개념(내
  수정·가림·되돌림·휴지통)이라 입구마다 팝업이 다르면 규칙을 화면마다
  다시 배운다 — 엔진을 하나로 만든 것과 같은 논리.
★★ **전역 기준(출발지) 바** — 상단에 책/장/절 콤보 + 그 절 본문(사용자
  성경 버전) + [지금 보는 절로]. 기준을 바꾸면 설명문·구절연결 탭이 함께
  따라온다(「출발지를 한 번에 세팅하면 수정작업이 쉽다」). 구절연결 탭은
  이로써 **출발지·도착지가 모두 명시**된다(옛 팝업은 출발지가 암묵적).
★★ 4탭 = [설명문][구절연결][렌즈][휴지통]
  · 설명문 — 「따로따로 대신 **한눈에 모든 텍스트**를 보면서 수정」:
    장 설명문·일반·전문·묵상질문·연구질문·묵상기도 세로 나열, 구획별
    [가리기][비교·되돌리기] + 상단 [바뀐 것 저장] 하나.
  · 구절연결 — 도착지 콤보 아래 **본문 미리보기**(「추가한 것이 정상인지
    알 수가 없다」의 답) → 확인 후 [＋ 연결].
  · 렌즈 — **자체 앵커**(렌즈/노드 — 구절 축과 다르다).
  · 휴지통 — 설정에서 이곳으로 이관(「내가 손댄 것의 집」 완성).
★★ **비교 후 되돌리기** — [비교·되돌리기]가 sys 원본과 내 버전을 나란히
  띄우고 그 안에서 확정한다(「비교하지도 않고 되돌리는 사용자는 없다」).
★ 미저장 수정 중 기준 변경 → 저장/버림/취소 확인(사용자 승인 방식).
⚠ 태그·주요용어의 「만드는 입구」는 제자리(목록 문맥 필요) — 현황·해제
  탭은 후속. 저장은 전부 user db — 기본 자산은 안 바뀐다.
`--selftest` 의무(구획 표 ↔ 덮개 대상 정합).
"""
import sys
import tkinter as tk
from tkinter import ttk, messagebox

# ★★ 구간 판정은 **한 문**이다(§verse_range) — `verse_id` 는 신원이고
#   차례는 `sort_order` 다. 번호로 재면 절체계 이형 구간에서 샌다.
import verse_range as _vr
import appdb
import verse_text as _vt   # ★ 절 본문은 이 문 하나로(합쳐짐·없는절 보완 §verse_text)
import i18n
import overlay
import overlay_edit as OE
import verse_link_edit as VL


# 절 앵커 구획 — (열쇠, i18n, 기본 라벨, text_type, 변형 선호, 앵커 종류)
# ★★★ **숲 → 나무 → 잎사귀** — 책·장·단락·절 (2026-08-30 사용자 지시 0.txt 1-2
#   「창1:8을 클릭한 상태에서 My Edit 팝업 화면에서 책/장/단락은 수정하지
#   못하는가? 허용하면 문제가 있는가?」).
#   ⚠⚠ 셋 중 **장만** 있었다 — 책·단락은 P2 설명 탭에는 보이는데 고칠 길이
#     없었다. 「보이는데 못 고친다」가 사용자가 겪은 것이다.
#   ⚠⚠ **범위를 제목이 말해야 한다**(`ak` 가 그 몫도 한다). 창1:8 에서 단락
#     설명문을 가리면 **창1:6~13 전체**에서, 책 개요를 가리면 **창세기 31장
#     전체**에서 사라진다. 제목이 그냥 「단락 설명문」이면 이 절만 가린 줄 알고
#     누른다 — 그래서 `책 개요 (창세기)` · `장 설명문 (창세기 1장)` ·
#     `단락 설명문 (창1:1~2)` 로 **닿는 범위를 붙인다.**
VERSE_SECTIONS = (
    ('book', 'OE_S_BOOK', '책 개요', 'BOOK_DESC', '', 'book'),
    ('chap', 'OE_S_CHAP', '장 설명문', 'CHAP_DESC', '', 'chap'),
    ('peri', 'OC_S_PERIDESC', '단락 설명문', 'PERI_DESC', '', 'peri'),
    ('lay', 'OE_S_DESC_LAY', '일반 설명', 'VERS_DESC', 'LAY', 'vid'),
    ('exp', 'OE_S_DESC_EXP', '전문 설명', 'VERS_DESC', 'EXPERT', 'vid'),
    ('qlay', 'OE_S_Q_LAY', '묵상질문', 'VERS_QUESTION', 'LAY', 'vid'),
    ('qexp', 'OE_S_Q_EXP', '연구질문', 'VERS_QUESTION', 'EXPERT', 'vid'),
    ('pray', 'OE_S_PRAYER', '묵상기도', 'VERS_PRAYER', '', 'vid'),
)
NODE_SECTIONS = (('nd', 'OE_S_NDESC', '노드 설명', 'NODE_DESC', ''),
                 ('nq', 'OE_S_NQ', '노드 묵상질문', 'NODE_QUESTION', ''),
                 ('np', 'OE_S_NP', '노드 묵상기도', 'NODE_PRAYER', ''))
CONT_SECTIONS = (('cd', 'OE_S_CDESC', '렌즈 설명', 'CONT_DESC', ''),
                 ('cn', 'OE_S_CNAME', '렌즈 이름', 'CONT_NAME', ''))

_STATE_KEYS = {'SYS': ('OE_ST_SYS', '기본'),
               'EDIT': ('OE_ST_EDIT', '내 버전'),
               'HIDDEN': ('OE_ST_HIDDEN', 'HIDE'),
               'NEW': ('OE_ST_NEW', '내 글'),
               'NONE': ('OE_ST_NONE', '없음 — 쓰면 내 글')}


def _book_full(conn, bcode, lang):
    """책 정식명 — 요청 언어 → EN 폴백. 없으면 빈 글자."""
    for lc in (lang or 'KO', 'EN'):
        try:
            r = conn.execute('SELECT full_name FROM book_names '
                             'WHERE book_code=? AND lang_code=?',
                             (bcode, lc)).fetchone()
        except Exception:
            r = None
        if r and r[0]:
            return r[0]
    return ''


def _range_label(conn, sv, ev, lang):
    """구절 범위 표기 — `창1:1~2`.

    ⚠ **형식은 `verse_ref` 가 정한다**(2026-08-14) — 화면마다 물결·붙임표로
      갈리면 사용자는 다른 것으로 읽는다. 여기서 새로 짓지 않는다."""
    try:
        import verse_ref
        a = conn.execute('SELECT bcode, chapter, verse FROM bible_index '
                         'WHERE verse_id=?', (sv,)).fetchone()
        b = conn.execute('SELECT bcode, chapter, verse FROM bible_index '
                         'WHERE verse_id=?', (ev or sv,)).fetchone()
        if not a or not b:
            return ''

        def _short(bc):
            for lc in (lang or 'KO', 'EN'):
                r = conn.execute('SELECT short_name FROM book_names '
                                 'WHERE book_code=? AND lang_code=?',
                                 (bc, lc)).fetchone()
                if r and r[0]:
                    return r[0]
            return ''
        nm2 = _short(b[0]) if a[0] != b[0] else None
        return verse_ref.range_label(_short(a[0]), a[1], a[2], b[1], b[2], nm2)
    except Exception:
        return ''


def _user_version(conn):
    try:
        r = conn.execute("SELECT config_val FROM user_config "
                         "WHERE config_key='v1_code'").fetchone()
        return (r and r[0]) or 'KRV'
    except Exception:
        return 'KRV'


def _verse_body(conn, vid, version=None):
    if not vid:
        return ''
    v = version or _user_version(conn)
    # ★ 합쳐진 절·없는 절도 **읽을 수 있는 글**로(§verse_text) — 옛 코드는
    #   그 역본에 없으면 **아무 역본이나** 집어 와 어느 역본인지 못 밝혔다.
    return _vt.resolve(conn, vid, v)['text']


def open_center(parent, db_path, focus='ASSETS', vid=None, lens=None,
                on_changed=None, get_current_vid=None):
    """총괄 창 열기 — 이미 열려 있으면 들어 올리고 포커스·앵커만 맞춘다."""
    root = parent.winfo_toplevel()
    win = getattr(root, '_overlay_center_win', None)
    if win is not None:
        try:
            if win.winfo_exists():
                win.on_changed = on_changed or win.on_changed
                win.focus_tab(focus, vid=vid, lens=lens)
                win.lift()
                win.focus_force()
                return win
        except Exception:
            pass
    if get_current_vid is None:
        def get_current_vid():
            return (getattr(root, 'active_node_id', None)
                    or getattr(root, '_p1_verse_id', None))
    win = _CenterWin(root, db_path, on_changed, get_current_vid)
    root._overlay_center_win = win
    win.focus_tab(focus, vid=vid or get_current_vid(), lens=lens)
    return win


class _CenterWin(tk.Toplevel):
    def __init__(self, root, db_path, on_changed, get_current_vid):
        super().__init__(root)
        _t = i18n.t
        self.db_path = db_path
        self.on_changed = on_changed
        self.get_current_vid = get_current_vid
        self.vid = None
        self.lang = 'KO'
        try:
            with appdb.connect(db_path) as conn:
                import verse_tier
                self.lang = verse_tier.get_desc_lang(conn) or 'KO'
        except Exception:
            pass
        self.title(_t('OC_TITLE', 'My Edit'))
        # ★ 초기 크기 (2026-08-27 사용자 — 「폭이 좁아서 3개 화면 중 왼쪽
        #   하나밖에 보이지 않았다」). 작업대 4기둥(≈1,280px)이 다 보이게
        #   관리자 팝업과 같은 화면 맞춤으로 열고, **사용자가 조절한 크기를
        #   기억**한다(user_config OC_GEOM — 다음부터 그 크기).
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        saved = None
        try:
            with appdb.connect(db_path) as conn:
                r = conn.execute("SELECT config_val FROM user_config "
                                 "WHERE config_key='OC_GEOM'").fetchone()
                saved = r and r[0]
        except Exception:
            pass
        geom = None
        if saved:
            try:                            # 화면 밖에 저장됐으면 자리만 고친다
                size, _, pos = saved.partition('+')
                w0, h0 = (int(v) for v in size.split('x'))
                x0, y0 = (int(v) for v in pos.split('+')) if pos else (60, 40)
                x0 = max(0, min(x0, sw - 200))
                y0 = max(0, min(y0, sh - 200))
                geom = '%dx%d+%d+%d' % (w0, h0, x0, y0)
            except Exception:
                geom = None
        if not geom:
            w0 = max(1180, min(sw - 80, 1480))
            h0 = max(680, min(820, sh - 140))
            geom = '%dx%d+%d+%d' % (w0, h0, (sw - w0) // 2,
                                    max(20, (sh - h0) // 2 - 20))
        self.geometry(geom)
        self.minsize(980, 560)
        self._geom_after = None
        self.bind('<Configure>', self._save_geom_later, add='+')

        # ── 전역 기준(출발지) 바 ─────────────────────────────────
        # ★★ 관리자 연결통합 팝업과 **같은 문법** (2026-08-27 사용자 확정 —
        #   「관리자 화면의 연결통합 팝업화면과 같은 패턴으로 통합」).
        #   상단 = **기준 콤보**(앵커 종류 — 관리자 OWNERS 콤보와 같은 축.
        #   지금은 구절·용어, 도서·렌즈는 다음 조각) + 그 앵커의 선택기.
        #   첫 탭 = **연결 작업대**(기본 선택) — 열자마자 관리자와 같은 화면.
        #   덮개 고유 기능(설명문·별명·유형·휴지통 — 수정·삭제·추가)은 그
        #   뒤에 앵커 따라 탭으로 붙는다. 구절연결(VERS_VERS)은 rel·연결
        #   설명문·도착 미리보기가 독자적이라 **제 탭을 유지**한다(사용자
        #   지시 「독자적인 부분은 별도 탭으로」).
        # ★ 이 창은 **구절 전용**이다 (2026-08-27 사용자 확정 — 「기준콤보는
        #   의미없다. 제거하라」·「렌즈 관련된 것은 렌즈묵상 탭에서만」).
        #   용어의 My Edit = 주요용어 화면의 창(entity_overlay._MyWin) ·
        #   렌즈의 My Edit = 렌즈묵상의 스튜디오(my_lens_edit) — 앵커 축을
        #   한 창에 모으는 13-53 방향은 이 결정으로 **폐기**됐다. 각 앵커는
        #   제 화면에서 제 창을 연다(같은 부품을 공유하는 것은 그대로).
        bar = tk.Frame(self)
        bar.pack(fill='x', padx=10, pady=(10, 2))
        tk.Label(bar, text=_t('OC_BASIS', '기준'),
                 font=('', 9, 'bold')).pack(side='left')
        self._verse_bar = tk.Frame(bar)
        self._verse_bar.pack(side='left')
        vb = self._verse_bar
        with appdb.connect(db_path) as conn:
            self._books = conn.execute(
                'SELECT bn.book_code, bn.full_name FROM book_names bn '
                'WHERE UPPER(bn.lang_code)=? AND bn.book_code IN '
                '(SELECT DISTINCT bcode FROM bible_index) ORDER BY bn.book_code',
                ((self.lang or 'KO').upper(),)).fetchall()
        self._cb_book = ttk.Combobox(vb, state='readonly', width=12,
                                     values=[b[1] for b in self._books])
        self._cb_book.pack(side='left', padx=(6, 2))
        self._cb_chap = ttk.Combobox(vb, state='readonly', width=4)
        self._cb_chap.pack(side='left', padx=2)
        self._cb_vers = ttk.Combobox(vb, state='readonly', width=4)
        self._cb_vers.pack(side='left', padx=2)
        tk.Button(vb, text=_t('OC_TO_CURRENT', '지금 보는 절로'),
                  command=self._to_current).pack(side='left', padx=(8, 0))

        self._cb_book.bind('<<ComboboxSelected>>',
                           lambda _e: self._anchor_combo(1))
        self._cb_chap.bind('<<ComboboxSelected>>',
                           lambda _e: self._anchor_combo(2))
        self._cb_vers.bind('<<ComboboxSelected>>',
                           lambda _e: self._anchor_combo(3))
        # 기준 절 본문 — 무엇을 잡고 있는지 늘 보인다
        # ★ 기준 헤드라인 — **무엇을 잡고 고치는지 크게** (2026-08-27 사용자
        #   「기준콤보? 숨어있는 것을 찾아라는 것인가」 — 콤보만으로는 기준이
        #   안 보였다. 관리자 팝업의 19pt 기준점 띠와 같은 문법).
        # ★ 「가린 것 보기」 스위치 (2026-08-27 사용자 — 「숨기기 할 때 sys
        #   데이터를 보여주면서 가림 표시하기 옵션을 주자」). **가림을 하는
        #   자리에 둔다** — 설정 깊숙이 두면 켜고 끄는 길을 못 찾는다.
        import overlay_read as _orr
        with appdb.connect(db_path) as _c:
            self._show_hid = tk.BooleanVar(value=_orr.show_hidden(_c))
        tk.Checkbutton(bar, text=_t('OC_SHOW_HIDDEN', '숨긴 것도 보기 (HIDE 표시)'),
                       variable=self._show_hid,
                       command=self._toggle_show_hidden).pack(side='right')
        self._head_lbl = tk.Label(self, text='', anchor='w',
                                  font=('', 15, 'bold'))
        self._head_lbl.pack(fill='x', padx=12, pady=(4, 0))
        self._anchor_body = tk.Label(self, anchor='w', justify='left',
                                     wraplength=680)
        self._anchor_body.pack(fill='x', padx=12, pady=(2, 4))

        # ── 탭 ──────────────────────────────────────────────────
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill='both', expand=True, padx=8, pady=(0, 8))
        self._tab_text = _SectionsPanel(self.nb, self)
        self.nb.add(self._tab_text, text=' ' + _t('OC_T_TEXT', '설명문') + ' ')
        self._tab_link = _LinkTab(self.nb, self)
        self.nb.add(self._tab_link, text=' ' + _t('OC_T_LINK', '구절연결') + ' ')
        # ⚠ 렌즈 탭은 뺐다 (2026-08-27 사용자 — 「렌즈 관련된 것은 렌즈묵상
        #   탭에서만 처리하자. 렌즈탭 제거하라」). _LensTab 부품은
        #   my_lens_edit.open_my_lens_studio 가 그대로 심는다.
        self._tab_tagterm = _TagTermTab(self.nb, self)
        self.nb.add(self._tab_tagterm,
                    text=' ' + _t('OC_T_TAGTERM', '태그·용어') + ' ')
        trash_f = ttk.Frame(self.nb)
        self.nb.add(trash_f, text=' ' + _t('TRASH_TAB', '휴지통') + ' ')
        try:
            import trash_view
            trash_view._TrashBody(trash_f, db_path,
                                  lambda: self.lang).pack(fill='both',
                                                          expand=True)
        except Exception as e:
            print('[overlay center] trash:', e)
        # ── 자산 연결 — 연결 작업대 embed (2026-08-27 · 할일 13-53 첫 조각).
        #   「이 구절에 얹는」 자산 일반 연결(태그·용어·도서·흐름…)을 이 창
        #   안에서 — 팝업·관리 탭과 **같은 본체**(link_picker.build_workbench,
        #   USER scope)를 심는다. 앵커 축 확장(용어·도서 앵커)은 다음 조각.
        self._tab_wb_f = ttk.Frame(self.nb)
        self.nb.add(self._tab_wb_f,
                    text=' ' + _t('OC_T_ASSETS', '연결된 자료') + ' ')
        self._wb_api = None
        self.nb.bind('<<NotebookTabChanged>>', self._on_tab_wb, add='+')
        # ★ 연결 작업대를 **첫 탭·기본 선택**으로 — 관리자 팝업과 열자마자
        #   같은 화면(2026-08-27 사용자 확정 「관리자 패턴으로 통합」).
        self.nb.insert(0, self._tab_wb_f)
        self._tab_idx = {'ASSETS': 0, 'TEXT': 1, 'LINK': 2, 'TAGTERM': 3,
                         'TRASH': 4}
        self.nb.select(0)
        try:
            import ui_theme
            ui_theme.adopt(self)             # 팝업은 다 지은 뒤 한 번 (§36)
        except Exception:
            pass

    # ── 기준(출발지) ────────────────────────────────────────────
    def set_anchor(self, vid, force=False):
        """기준 절 세팅 — 설명문·구절연결 탭이 함께 따라온다.

        ⚠ 미저장 수정이 있으면 저장/버림/취소를 먼저 묻는다(사용자 승인).
        """
        if not vid:
            return False
        vid = int(vid)
        if vid == self.vid and not force:
            return True
        if self._tab_text.dirty():
            _t = i18n.t
            ans = messagebox.askyesnocancel(
                _t('OC_TITLE', 'My Edit'),
                _t('OC_UNSAVED', '저장하지 않은 수정이 있습니다. '
                   '저장할까요?\n(아니오 = 버리고 이동)'), parent=self)
            if ans is None:
                return False
            if ans:
                self._tab_text.save_changed()
        self.vid = vid
        with appdb.connect(self.db_path) as conn:
            r = conn.execute('SELECT bcode, chapter, verse FROM bible_index '
                             'WHERE verse_id=?', (vid,)).fetchone()
            body = _verse_body(conn, vid)
        if r:
            codes = [b[0] for b in self._books]
            if r[0] in codes:
                self._cb_book.current(codes.index(r[0]))
            self._fill_chap(keep=str(r[1]))
            self._fill_vers(keep=str(r[2]))
        try:
            nm = dict((b[0], b[1]) for b in self._books).get(r[0], '') if r                 else ''
            self._head_lbl.config(text='%s %d:%d' % (nm, r[1], r[2])
                                  if r else '')
        except Exception:
            pass
        self._anchor_body.config(text='  "%s"' % body[:120])
        self._tab_text.load_verse(vid)
        self._tab_link.load(vid)
        self._tab_tagterm.load(vid)
        # ★★ **연결된 자료 탭도 함께** (2026-08-27 사용자 — 「기준 구절
        #   바꿔봐야 연결된 자료 내부의 탭에는 아무런 반응이 없다. 자동
        #   새로고침이 안된다」). 작업대는 탭에 들어올 때만 짓고 있었는데,
        #   **이미 지어져 있으면 기준이 바뀐 순간 다시 세워야** 한다
        #   (link_tab 이 owner 를 캐시하므로 다른 기준이면 새로 짓는다).
        if self._wb_api is not None:
            try:
                self._wb_api.refresh()
            except Exception as e:
                print('[overlay center] wb follow:', e)
        return True

    def _to_current(self):
        try:
            cur = self.get_current_vid()
        except Exception:
            cur = None
        if cur:
            self.set_anchor(int(str(cur).split(':')[-1].split('_')[0]))

    def _toggle_show_hidden(self):
        """가린 것 보기 — 저장하고 **지금 화면부터** 다시 그린다."""
        import overlay_read as _orr
        with appdb.connect(self.db_path) as conn:
            _orr.set_show_hidden(conn, bool(self._show_hid.get()))
        if self.vid:
            self.set_anchor(self.vid, force=True)
        self.changed('TEXT')                  # 뒤 화면(P2 설명 등)도 따라온다

    # ── 창 크기 기억 (2026-08-27) ────────────────────────────────
    def _save_geom_later(self, ev=None):
        if ev is not None and ev.widget is not self:
            return                      # 자식 위젯의 Configure 는 셀 것 없다
        if self._geom_after:
            try:
                self.after_cancel(self._geom_after)
            except Exception:
                pass
        self._geom_after = self.after(800, self._save_geom)

    def _save_geom(self):
        self._geom_after = None
        try:
            g = self.geometry()
            with appdb.connect(self.db_path) as conn:
                cur = conn.execute(
                    "UPDATE user_config SET config_val=? "
                    "WHERE config_key='OC_GEOM'", (g,))
                if cur.rowcount == 0:
                    conn.execute("INSERT INTO user_config(config_key,"
                                 "config_val) VALUES('OC_GEOM',?)", (g,))
                conn.commit()
        except Exception:
            pass

    def _on_tab_wb(self, _e=None):
        """자산 연결 탭에 들어올 때만 작업대를 짓는다(지연 — §29).

        앵커가 바뀌어도 여기서 따라온다 — `link_tab` 이 owner 를 캐시해
        같으면 목록만, 다르면 작업대를 다시 세운다."""
        try:
            if self.nb.index('current') != self._tab_idx['ASSETS']:
                return
        except Exception:
            return
        if self._wb_api is None:
            try:
                from admin import panel_std
                self._wb_api = panel_std.link_tab(
                    self._tab_wb_f, self._wb_owner,
                    lang_getter=lambda: self.lang, scope='USER',
                    db_path=self.db_path,
                    on_saved=lambda: self._wb_changed())
            except Exception as e:
                print('[overlay center] workbench:', e)
                return
        try:
            self._wb_api.refresh()
        except Exception as e:
            print('[overlay center] wb refresh:', e)

    def _wb_owner(self):
        return ('VERSE', self.vid) if self.vid else None

    def _wb_changed(self):
        """작업대에서 연결을 더하거나 뺐다 — 호스트 화면(배지·목록)도 따라온다."""
        try:
            if callable(self.on_changed):
                self.on_changed('LINK')
        except Exception:
            pass

    def _fill_chap(self, keep=None):
        i = self._cb_book.current()
        if i < 0:
            return
        with appdb.connect(self.db_path) as conn:
            chs = [str(r[0]) for r in conn.execute(
                'SELECT DISTINCT chapter FROM bible_index WHERE bcode=? '
                'ORDER BY chapter', (self._books[i][0],))]
        self._cb_chap.config(values=chs)
        if keep and keep in chs:
            self._cb_chap.set(keep)
        elif chs:
            self._cb_chap.current(0)

    def _fill_vers(self, keep=None):
        i = self._cb_book.current()
        if i < 0 or not self._cb_chap.get():
            return
        with appdb.connect(self.db_path) as conn:
            vs = [str(r[0]) for r in conn.execute(
                'SELECT verse FROM bible_index WHERE bcode=? AND chapter=? '
                'ORDER BY verse', (self._books[i][0],
                                   int(self._cb_chap.get())))]
        self._cb_vers.config(values=vs)
        if keep and keep in vs:
            self._cb_vers.set(keep)
        elif vs:
            self._cb_vers.current(0)

    def _anchor_combo(self, level):
        if level == 1:
            self._fill_chap()
            self._fill_vers()
        elif level == 2:
            self._fill_vers()
        i = self._cb_book.current()
        if i < 0 or not self._cb_vers.get():
            return
        with appdb.connect(self.db_path) as conn:
            r = conn.execute('SELECT verse_id FROM bible_index WHERE bcode=? '
                             'AND chapter=? AND verse=?',
                             (self._books[i][0], int(self._cb_chap.get()),
                              int(self._cb_vers.get()))).fetchone()
        if r:
            ok = self.set_anchor(r[0])
            if not ok and self.vid:
                self.set_anchor(self.vid, force=True)   # 취소 — 콤보 되돌림

    # ── 열기 API ────────────────────────────────────────────────
    def focus_tab(self, focus, vid=None, lens=None):
        self.nb.select(self._tab_idx.get(focus, 0))
        if vid:
            self.set_anchor(vid)
        elif self.vid is None:
            try:
                cur = self.get_current_vid()
                if cur:
                    self.set_anchor(int(str(cur).split(':')[-1].split('_')[0]))
            except Exception:
                pass
        # (렌즈 갈래는 2026-08-27 제거 — 렌즈의 My Edit 는 my_lens_edit 창)

    def changed(self, kind):
        """저장·가림·되돌림 뒤 — 뒤 화면을 다시 그린다."""
        root = self.master
        hook = getattr(root, '_overlay_center_changed', None)
        if callable(hook):
            try:
                hook(kind)
            except Exception as e:
                print('[overlay center] hook:', e)
        if callable(self.on_changed):
            try:
                self.on_changed()
            except Exception:
                pass


# ══════════════════════════════════════════════════════════════════
#  비교 창 — 되돌리기 전 판단 재료 (사용자 확정)
# ══════════════════════════════════════════════════════════════════
class _CompareDlg(tk.Toplevel):
    def __init__(self, parent, title, sys_text, mine_text, state, on_confirm):
        super().__init__(parent)
        _t = i18n.t
        self.title(_t('OC_CMP_TITLE', '비교') + ' · ' + title)
        self.transient(parent)
        self.geometry('720x420')
        bar = tk.Frame(self)
        bar.pack(fill='x', padx=10, pady=(10, 4))
        btn_txt = (_t('OC_UNHIDE', '다시 보이기') if state == 'HIDDEN'
                   else _t('OE_REVERT', '원래 글로'))

        def _go():
            on_confirm()
            self.destroy()
        tk.Button(bar, text=btn_txt, command=_go).pack(side='left')
        tk.Button(bar, text=_t('COMMON_CLOSE', '닫기'),
                  command=self.destroy).pack(side='right')
        body = tk.Frame(self)
        body.pack(fill='both', expand=True, padx=10, pady=(0, 10))
        for col, (head, txt) in enumerate((
                (_t('OC_CMP_SYS', '기본 원본'), sys_text),
                (_t('OC_CMP_MINE', '내 버전'),
                 mine_text if state != 'HIDDEN'
                 else _t('OC_CMP_HIDDEN', '(가려 둔 상태 — 내 글 없음)')))):
            f = tk.Frame(body)
            f.grid(row=0, column=col, sticky='nsew',
                   padx=(0, 6) if col == 0 else 0)
            body.columnconfigure(col, weight=1)
            body.rowconfigure(0, weight=1)
            tk.Label(f, text=head, font=('', 9, 'bold'),
                     anchor='w').pack(fill='x')
            t = tk.Text(f, wrap='word', bd=1)
            t.insert('1.0', txt or '')
            t.config(state='disabled')
            t.pack(fill='both', expand=True)
            try:
                from reading_pane import enable_copy
                enable_copy(t)
            except Exception:
                pass
        try:
            import ui_theme
            ui_theme.adopt(self)
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════
#  구획 패널 — 「한눈에 모든 텍스트」 (설명문·렌즈 탭 공용)
# ══════════════════════════════════════════════════════════════════
class _SectionsPanel(ttk.Frame):
    """세로 나열 구획들: 이름·상태 + [가리기][비교·되돌리기] + 글상자.
    상단 [바뀐 것 저장] 하나 — 손댄 구획만 저장한다."""

    def __init__(self, parent, center):
        super().__init__(parent)
        _t = i18n.t
        self.center = center
        self._secs = {}                      # key → dict(위젯·상태)
        bar = tk.Frame(self)
        bar.pack(fill='x', padx=8, pady=(8, 2))
        tk.Button(bar, text=_t('OC_SAVE_CHANGED', '바뀐 것 저장'),
                  command=self.save_changed).pack(side='left')
        self._info = tk.Label(bar, text='')
        self._info.pack(side='right')
        # 스크롤 캔버스
        wrap = tk.Frame(self)
        wrap.pack(fill='both', expand=True, padx=8, pady=(2, 8))
        self._cv = tk.Canvas(wrap, highlightthickness=0)
        sb = ttk.Scrollbar(wrap, orient='vertical', command=self._cv.yview)
        self._cv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self._cv.pack(side='left', fill='both', expand=True)
        self._inner = tk.Frame(self._cv)
        self._win = self._cv.create_window((0, 0), window=self._inner,
                                           anchor='nw')
        self._inner.bind('<Configure>', lambda _e: self._cv.configure(
            scrollregion=self._cv.bbox('all')))
        self._cv.bind('<Configure>', lambda e: self._cv.itemconfigure(
            self._win, width=e.width))
        self._cv.bind_all('<MouseWheel>', self._wheel, add='+')

    def _wheel(self, e):
        try:
            if str(e.widget.winfo_toplevel()) == str(self.winfo_toplevel()) \
                    and self.winfo_ismapped():
                self._cv.yview_scroll(-int(e.delta / 120), 'units')
        except Exception:
            pass

    # ── 로드 ────────────────────────────────────────────────────
    def load_verse(self, vid):
        """절 앵커 구획들 — 책·장·단락은 **제 열쇠로 바꿔 단다**.

        열쇠 = 책 `bcode` · 장 `chap_key(bcode,chap)`(§3-1) · 단락 `pericope_id`
        (덮개는 그 안에서 `peri_code` 로 바꿔 쓴다) · 절 `vid`.
        ⚠ 제목에 **닿는 범위**를 붙인다 — 위 `VERSE_SECTIONS` 설명 참조.
        ⚠ 재료를 못 찾은 층은 **구획째 건너뛴다**(예: 어느 단락에도 안 든 절).
          빈 구획을 그리면 무엇을 고치는 칸인지 알 수 없다."""
        secs = []
        with appdb.connect(self.center.db_path) as conn:
            r = conn.execute('SELECT bcode, chapter FROM bible_index '
                             'WHERE verse_id=?', (vid,)).fetchone()
            lang = self.center.lang
            for key, ik, dflt, tt, vp, ak in VERSE_SECTIONS:
                cid, scope = vid, ''
                if ak in ('book', 'chap'):
                    if not r:
                        continue
                    nm = _book_full(conn, r[0], lang)
                    if ak == 'book':
                        cid, scope = r[0], nm
                    else:
                        import verse_tier
                        cid = verse_tier.chap_key(r[0], r[1])
                        scope = i18n.t('OE_SC_CHAP', '{book} {n}장').format(
                            book=nm, n=r[1])
                elif ak == 'peri':
                    p = conn.execute(
                        "SELECT pericope_id, start_vid, end_vid "
                        "FROM sys_pericope_asset p WHERE p.peri_type='BODY' "
                        "  AND COALESCE(p.record_status,'LIVE')='LIVE' AND "
                        + _vr.covers_sql('p', 'start_vid', 'end_vid')
                        + " ORDER BY (p.end_vid - p.start_vid) ASC LIMIT 1",
                        _vr.covers_args(vid)).fetchone()
                    if not p:
                        continue
                    cid = p[0]
                    scope = _range_label(conn, p[1], p[2], lang)
                label = i18n.t(ik, dflt)
                if scope:
                    label = '%s (%s)' % (label, scope)
                secs.append((key, label, tt, cid, vp))
        self.load(secs)

    def load(self, sections):
        for w in self._inner.winfo_children():
            w.destroy()
        self._secs = {}
        _t = i18n.t
        lang = self.center.lang
        with appdb.connect(self.center.db_path) as conn:
            for key, label, tt, cid, vp in sections:
                var, state, shown = OE.target_state(conn, tt, cid, lang, vp)
                f = tk.LabelFrame(self._inner, text='')
                f.pack(fill='x', pady=(0, 6), padx=2)
                head = tk.Frame(f)
                head.pack(fill='x', padx=6, pady=(4, 2))
                tk.Label(head, text=label, font=('', 9, 'bold'),
                         anchor='w').pack(side='left')
                sk, sd = _STATE_KEYS.get(state, _STATE_KEYS['NONE'])
                st_lbl = tk.Label(head, text='· ' + _t(sk, sd))
                st_lbl.pack(side='left', padx=(6, 0))
                b_cmp = tk.Button(head, text=_t('OC_COMPARE', '비교·되돌리기'),
                                  font=('', 8), bd=1, padx=4, pady=0,
                                  command=lambda k=key: self._compare(k))
                b_cmp.pack(side='right', padx=(4, 0))
                b_hide = tk.Button(head, text=_t('OE_HIDE', '숨기기'),
                                   font=('', 8), bd=1, padx=4, pady=0,
                                   command=lambda k=key: self._hide(k))
                b_hide.pack(side='right')
                txt = tk.Text(f, height=5, wrap='word', bd=1)
                txt.pack(fill='x', padx=6, pady=(0, 6))
                if shown:
                    txt.insert('1.0', shown)
                if state == 'HIDDEN':
                    txt.config(state='disabled')
                b_hide.config(state='normal' if state in ('SYS', 'EDIT')
                              else 'disabled')
                b_cmp.config(state='normal' if state in ('EDIT', 'NEW',
                                                         'HIDDEN')
                             else 'disabled')
                self._secs[key] = dict(label=label, tt=tt, cid=cid, vp=vp,
                                       var=var, state=state, loaded=shown,
                                       txt=txt)
        try:
            import ui_theme
            ui_theme.adopt(self._inner)      # 동적 위젯 — 다시 칠한다(§36-5b)
        except Exception:
            pass

    # ── 동작 ────────────────────────────────────────────────────
    def _get(self, key):
        s = self._secs[key]
        try:
            return s['txt'].get('1.0', 'end').strip()
        except Exception:
            return s['loaded']

    def dirty(self):
        return any(s['state'] != 'HIDDEN' and self._get(k) != (s['loaded'] or '')
                   for k, s in self._secs.items())

    def _reload(self):
        self.load([(k, s['label'], s['tt'], s['cid'], s['vp'])
                   for k, s in self._secs.items()])

    def save_changed(self):
        _t = i18n.t
        n = 0
        with appdb.connect(self.center.db_path) as conn:
            for k, s in self._secs.items():
                if s['state'] == 'HIDDEN':
                    continue
                cur = self._get(k)
                if cur == (s['loaded'] or '') or not cur:
                    continue                  # 비우기는 저장이 아니라 가리기다
                OE.save_mine(conn, s['tt'], s['cid'], self.center.lang,
                             s['var'] if s['state'] != 'NONE' else s['vp'],
                             cur)
                n += 1
        if n:
            self._info.config(text=_t('OC_SAVED_N', '{n}개 저장됨'
                                      ).format(n=n))
            self._reload()
            self.center.changed('TEXT')
        else:
            self._info.config(text=_t('OC_SAVED_0', '바뀐 것이 없습니다'))

    def _hide(self, key):
        _t = i18n.t
        s = self._secs[key]
        if not messagebox.askyesno(
                _t('OE_HIDE', '숨기기'),
                _t('OC_HIDE_Q', '「{name}」을(를) 내 화면에서 가립니다. '
                   '해제는 비교·되돌리기 또는 휴지통에서. 계속할까요?'
                   ).format(name=s['label']), parent=self):
            return
        with appdb.connect(self.center.db_path) as conn:
            OE.hide_sys(conn, s['tt'], s['cid'], self.center.lang, s['var'])
        self._reload()
        self.center.changed('TEXT')

    def _compare(self, key):
        s = self._secs[key]
        with appdb.connect(self.center.db_path) as conn:
            var, state, sys_t, mine = OE.pair_state(
                conn, s['tt'], s['cid'], self.center.lang, s['vp'])

        def _confirm():
            with appdb.connect(self.center.db_path) as conn2:
                OE.revert_mine(conn2, s['tt'], s['cid'], self.center.lang, var)
            self._reload()
            self.center.changed('TEXT')
        _CompareDlg(self, s['label'], sys_t, mine, state, _confirm)


# ══════════════════════════════════════════════════════════════════
#  구절연결 탭 — 출발지=기준 바 · 도착지 본문 미리보기
# ══════════════════════════════════════════════════════════════════
class _TagTermTab(ttk.Frame):
    """태그·용어 탭 (2026-08-27 사용자 — 「태그/용어 탭이 추가되어야 할 것
    같다」). 이 구절에 붙은 **태그**와 이어진 **주요용어**를 한눈에 —
    태그는 [태그 고르기…](tag_picker — 내 태그 만들기·용어사전 필터 포함),
    용어는 검색해 잇는다(MY 창 연결구절과 같은 데이터 문법 ENTI_VERS)."""

    def __init__(self, parent, center):
        super().__init__(parent)
        _t = i18n.t
        self.center = center
        self.vid = None
        bar = tk.Frame(self)
        bar.pack(fill='x', padx=8, pady=(8, 2))
        tk.Button(bar, text=_t('LP_TAGPICK', '태그 선택하기…'), bd=1, padx=8,
                  command=self._pick_tags).pack(side='left', padx=(0, 6))
        tk.Button(bar, text=_t('OC_TT_ADDTERM', '＋ 용어 잇기…'), bd=1, padx=8,
                  command=self._add_term).pack(side='left', padx=(0, 6))
        self._b_tdel = tk.Button(bar, text=_t('OC_TT_DELTERM', '용어 숨기기'),
                                 bd=1, padx=8, state='disabled',
                                 command=self._del_term)
        self._b_tdel.pack(side='left')

        pw = ttk.Panedwindow(self, orient='horizontal')
        pw.pack(fill='both', expand=True, padx=8, pady=(2, 8))
        lf = ttk.Frame(pw)
        pw.add(lf, weight=1)
        tk.Label(lf, text=_t('OC_TT_TAGS', '이 구절의 태그'),
                 anchor='w', font=('', 10, 'bold')).pack(fill='x')
        self._tag_tv = ttk.Treeview(lf, columns=('nm', 'ax'), show='headings',
                                    selectmode='browse')
        self._tag_tv.heading('nm', text=_t('OC_TT_C_NAME', '태그'))
        self._tag_tv.heading('ax', text=_t('OC_TT_C_AXIS', '축'))
        self._tag_tv.column('nm', width=170)
        self._tag_tv.column('ax', width=110)
        self._tag_tv.pack(fill='both', expand=True)

        rf = ttk.Frame(pw)
        pw.add(rf, weight=1)
        tk.Label(rf, text=_t('OC_TT_TERMS', '이어진 주요용어'),
                 anchor='w', font=('', 10, 'bold')).pack(fill='x')
        self._term_tv = ttk.Treeview(rf, columns=('mk', 'nm'), show='headings',
                                     selectmode='browse')
        self._term_tv.heading('mk', text=_t('EBM_C_MARK', '표시'))
        self._term_tv.heading('nm', text=_t('OC_K_TERM', '용어'))
        self._term_tv.column('mk', width=42, stretch=False, anchor='center')
        self._term_tv.column('nm', width=220)
        self._term_tv.pack(fill='both', expand=True)
        self._term_rows = {}
        self._term_tv.bind('<<TreeviewSelect>>',
                           lambda _e: self._b_tdel.config(
                               state='normal' if self._term_tv.selection()
                               else 'disabled'))

    def load(self, vid):
        self.vid = vid
        self._tag_tv.delete(*self._tag_tv.get_children())
        self._term_tv.delete(*self._term_tv.get_children())
        self._term_rows = {}
        self._b_tdel.config(state='disabled')
        if not vid:
            return
        import tag_picker
        import overlay_read
        import overlay_mark as OM
        lang = self.center.lang
        # ⚠ 태그가 0줄로 보이던 자리 (2026-08-27 사용자 신고). `tags_of` 의
        #   범위 기본값은 'USER' 라 **내가 붙인 태그만** 나온다 — 관리자가
        #   붙여 둔 태그(sys)는 SYS 범위에 있다. 사용자 화면은 **둘 다** 본다
        #   (§0-6 「사용자는 sys 태그 + user 태그 모두 사용」).
        seen = set()
        for _sc in ('USER', 'SYS'):
            for _src, _tid, nm, cat in tag_picker.tags_of(
                    self.center.db_path, 'VERSE', vid, lang, scope=_sc):
                if (_src, _tid) in seen:
                    continue
                seen.add((_src, _tid))
                self._tag_tv.insert('', 'end', values=(nm, cat or ''))
        OM.configure_tree(self._term_tv)
        with appdb.connect(self.center.db_path) as conn:
            for r in overlay_read.links(conn, 'VERSE', vid, lang):
                if str(r.get('kind', '')).upper() != 'ENTITY':
                    continue
                mk = OM.mark_of(r.get('_src'), for_reading=True)
                iid = self._term_tv.insert(
                    '', 'end', values=(mk, r.get('label') or '#%s' % r['id']),
                    tags=((OM.tag_name(mk),) if mk else ()))
                self._term_rows[iid] = r

    def _pick_tags(self):
        import tag_picker
        if not self.vid:
            return
        cur = {(s, t) for s, t, _n, _c in tag_picker.tags_of(
            self.center.db_path, 'VERSE', self.vid, self.center.lang)}
        got = tag_picker.pick(self, self.center.db_path, chosen=cur,
                              lang=self.center.lang)
        if got is None:
            return
        tag_picker.save_links(self.center.db_path, 'VERSE', self.vid, got)
        self.load(self.vid)
        self.center.changed('LINK')

    def _add_term(self):
        _t = i18n.t
        if not self.vid:
            return
        win = tk.Toplevel(self)
        win.title(_t('OC_TT_ADDTERM', '＋ 용어 잇기…'))
        win.transient(self.winfo_toplevel())
        win.grab_set()
        f = tk.Frame(win)
        f.pack(fill='both', expand=True, padx=10, pady=8)
        q = tk.Entry(f, width=22)
        q.pack(side='top', anchor='w')
        lb = tk.Listbox(f, height=10, width=34)
        lb.pack(fill='both', expand=True, pady=(4, 4))
        hits = []

        def find(_e=None):
            import overlay_read
            lb.delete(0, 'end')
            hits.clear()
            with appdb.connect(self.center.db_path) as conn:
                for eid, nm in overlay_read.entity_search(
                        conn, q.get(), self.center.lang):
                    hits.append(eid)
                    lb.insert('end', nm)
        q.bind('<Return>', find)
        bf = tk.Frame(f)
        bf.pack(fill='x')
        tk.Button(bf, text=_t('BTN_FIND', '찾기'), bd=1, padx=8,
                  command=find).pack(side='left')

        def okk(_e=None):
            sel = lb.curselection()
            if not sel:
                return
            import entity_overlay as EO
            with appdb.connect(self.center.db_path) as conn:
                EO.add_verse_link(conn, hits[sel[0]], self.vid)
            win.destroy()
            self.load(self.vid)
            self.center.changed('LINK')
        tk.Button(bf, text=_t('OC_TT_LINKIT', '잇기'), bd=1, padx=10,
                  command=okk).pack(side='left', padx=(6, 0))
        lb.bind('<Double-1>', okk)
        try:
            import ui_theme
            ui_theme.adopt(win)
        except Exception:
            pass
        q.focus_set()
        find()

    def _del_term(self):
        _t = i18n.t
        sel = self._term_tv.selection()
        if not sel:
            return
        r = self._term_rows.get(sel[0])
        if not r:
            return
        if not messagebox.askyesno(
                _t('OC_TT_DELTERM', '용어 숨기기'),
                _t('OC_TT_DEL_Q', '「{name}」 연결을 내 화면에서 뺍니다(기본 '
                   '연결은 휴지통에서 되살릴 수 있습니다). 계속할까요?'
                   ).format(name=r.get('label') or ''), parent=self):
            return
        import entity_overlay as EO
        with appdb.connect(self.center.db_path) as conn:
            EO.hide_verse_link(conn, r['id'], self.vid,
                               r.get('end') or None)
        self.load(self.vid)
        self.center.changed('LINK')


class _LinkTab(ttk.Frame):
    def __init__(self, parent, center):
        super().__init__(parent)
        _t = i18n.t
        self.center = center
        self.vid = None
        self._rows = {}
        bar = tk.Frame(self)
        bar.pack(fill='x', padx=8, pady=(8, 2))
        self._b_hide = tk.Button(bar, text=_t('VLE_HIDE', '숨기기'),
                                 command=self._hide)
        # ★ 이름을 **하는 일 그대로** (2026-08-27 사용자 — 「내것 되돌리기:
        #   이것이 완전삭제인가? 용어 바꾸어라」). 실제로 user 행을 물리
        #   삭제한다 — 「되돌리기」는 되살릴 수 있다는 오해를 준다.
        self._b_revert = tk.Button(bar, text=_t('VLE_DELMINE', '내 연결 삭제'),
                                   command=self._revert)
        self._b_hide.pack(side='left', padx=(0, 6))
        self._b_revert.pack(side='left')
        # ⚠ 안내 라벨은 **화면에서 뗐다** (2026-08-27 사용자 — 「연결된 자료
        #   버튼 아래 텍스트 라벨 2가지 치워라. 이미 기준 출발점이 표시된다」).
        #   위젯은 남긴다 — 등급 불일치 수치를 여기에 담아 두었다가 필요할 때
        #   되살린다(라벨을 지우면 그 계산까지 사라진다).
        self._hint = tk.Label(self, anchor='w', justify='left', text='')

        add_f = tk.Frame(self)
        add_f.pack(fill='x', padx=8, pady=(0, 2))
        tk.Label(add_f, text=_t('OC_LINK_TO', '도착지')).pack(side='left')
        self._cb_book = ttk.Combobox(add_f, state='readonly', width=12,
                                     values=[b[1] for b in center._books])
        self._cb_book.pack(side='left', padx=(4, 2))
        self._cb_chap = ttk.Combobox(add_f, state='readonly', width=4)
        self._cb_chap.pack(side='left', padx=2)
        self._cb_vers = ttk.Combobox(add_f, state='readonly', width=4)
        self._cb_vers.pack(side='left', padx=2)
        tk.Label(add_f, text=_t('VLE_REL', '유형')).pack(side='left',
                                                        padx=(8, 2))
        self._cb_rel = ttk.Combobox(add_f, state='readonly', width=12)
        self._cb_rel.pack(side='left', padx=2)
        self._b_add = tk.Button(add_f, text=_t('VLE_ADD', '＋ 연결 추가'),
                                command=self._add)
        self._b_add.pack(side='left', padx=(8, 0))
        self._cb_book.bind('<<ComboboxSelected>>', lambda _e: self._fill(1))
        self._cb_chap.bind('<<ComboboxSelected>>', lambda _e: self._fill(2))
        self._cb_vers.bind('<<ComboboxSelected>>', lambda _e: self._preview())

        # 도착지(또는 고른 행의 상대) 본문 미리보기 — 사용자 확정
        self._prev = tk.Text(self, height=3, wrap='word', bd=1,
                             state='disabled')
        self._prev.pack(fill='x', padx=10, pady=(2, 4))

        # ── 연결설명문 (2026-08-27 사용자 — 「연결설명문 표시하고 수정하도록,
        #   추가한 구절의 연결설명문 입력하기」). 목록에서 한 건을 고르면 그
        #   글이 여기 보이고 그 자리에서 고친다 — sys 연결은 덮개(E — 배포
        #   DB 불변·빈 저장=되돌림), 내 연결은 내 글(앵커=내 링크 PK).
        df = tk.Frame(self)
        df.pack(fill='x', padx=8, pady=(2, 0))
        tk.Label(df, text=_t('OC_LINKDESC', '연결설명문'),
                 font=('', 9, 'bold')).pack(side='left')
        self._desc_state = tk.Label(df, text='')
        self._desc_state.pack(side='left', padx=(8, 0))
        self._b_desc = tk.Button(df, text=_t('COMMON_SAVE', '저장'),
                                 state='disabled', command=self._save_desc)
        self._b_desc.pack(side='right')
        self._desc_txt = tk.Text(self, height=4, wrap='word', bd=1)
        self._desc_txt.pack(fill='x', padx=10, pady=(2, 4))
        self._desc_row = None

        # ★ **N/E/H 표식 칸을 맨 앞에** (2026-08-26 사용자 지시 — 덮개가 도는
        #   모든 화면에 부착). 뒤의 「구분」 칸은 말로 풀어 주는 자리로 남긴다 —
        #   표식만 있으면 처음 보는 사람이 뜻을 모른다.
        cols = ('mk', 'other', 'rel', 'tier', 'src')
        self._tv = ttk.Treeview(self, columns=cols, show='headings',
                                selectmode='extended',
                                style='OCLink.Treeview')
        try:
            import theme_font
            theme_font.list_style('OCLink.Treeview', center.db_path)
        except Exception:
            pass
        self._tv.heading('mk', text=_t('EBM_C_MARK', '표시'))
        self._tv.column('mk', width=38, stretch=False, anchor='center')
        self._tv.heading('other', text=_t('VLE_C_OTHER', '상대 구절'))
        self._tv.heading('rel', text=_t('VLE_C_REL', '유형'))
        self._tv.heading('tier', text=_t('VLE_C_TIER', '등급'))
        self._tv.heading('src', text=_t('VLE_C_SRC', '구분'))
        self._tv.column('other', width=110, stretch=False)
        self._tv.column('rel', width=150)
        self._tv.column('tier', width=54, stretch=False, anchor='center')
        self._tv.column('src', width=80, stretch=False)
        sb = ttk.Scrollbar(self, orient='vertical', command=self._tv.yview)
        self._tv.configure(yscrollcommand=sb.set)
        self._tv.pack(side='left', fill='both', expand=True,
                      padx=(8, 0), pady=(0, 8))
        sb.pack(side='left', fill='y', pady=(0, 8))
        self._tv.bind('<<TreeviewSelect>>', lambda _e: self._on_select())

    def load(self, vid):
        _t = i18n.t
        self.vid = vid
        try:
            from ui_theme import C as _C
            self._tv.tag_configure('mine', foreground=_C('accent'))
        except Exception:
            pass
        self._tv.delete(*self._tv.get_children())
        self._rows = {}
        with appdb.connect(self.center.db_path) as conn:
            if not self._cb_rel.cget('values'):
                self._rels = VL.rel_options(conn, self.center.lang)
                self._cb_rel.config(values=[n for _c, n in self._rels])
                if self._rels:
                    self._cb_rel.current(0)
            rows = VL.list_links(conn, vid, self.center.lang)
        # ★ 캔버스와 셈이 다른 이유를 **화면이 말한다** (2026-08-27).
        #   여기는 **전부**, 캔버스는 [설정]의 등급 필터를 태운다.
        try:
            root = self.center.master
            tv2 = getattr(root, 'link_tier_var', None)
            tier_now = (tv2.get() if tv2 is not None else 'AB') or 'AB'
        except Exception:
            tier_now = 'AB'
        n_cv = sum(1 for r in rows if (r.get('tier') or 'C') in tier_now)
        self._hint.config(text='ⓘ ' + _t(
            'OC_LINK_HINT2',
            '이 목록은 이 구절의 연결 **전부**({all}건)입니다. 캔버스는 '
            '[설정]의 등급({tier})만 그리므로 지금 캔버스에는 {shown}건이 '
            '보입니다. 도착지를 선택하면 본문이 아래에 보입니다 — 확인 후 '
            '연결하세요.').format(all=len(rows), tier=tier_now, shown=n_cv))
        srcnm = {'SYS': _t('VLE_S_SYS', '기본'),
                 'EDIT': _t('VLE_S_EDIT', '내 수정'),
                 'NEW': _t('VLE_S_NEW', '내 연결'),
                 'HIDE': _t('VLE_S_HIDE', 'HIDE')}
        import overlay_mark as OM
        OM.configure_tree(self._tv)
        for i, r in enumerate(rows):
            iid = 'r%d' % i
            # ⚠ 이 목록은 **읽는 목록**이다 — 가린 것은 엔진이 이미 뺐다.
            #   그래서 `for_reading=True`(H 가 안 나온다).
            # ★ 가린 줄은 **H 로** (옵션이 켜졌을 때만 목록에 온다) —
            #   여기서 for_reading 을 강제하면 H 가 지워진다(2026-08-27).
            mk = OM.mark_of(r['src'], for_reading=(r['src'] != 'HIDE'))
            # ★ 등급 칸 — 「캔버스 [설정]의 등급이 A 면 B·C 는 캔버스에
            #   안 그려진다」를 목록이 말해 준다(2026-08-27 불일치 신고).
            self._tv.insert('', 'end', iid=iid,
                            values=(mk, r['other_label'], r['rel_name'],
                                    r.get('tier') or '',
                                    srcnm.get(r['src'], r['src'])),
                            tags=((OM.tag_name(mk),) if mk else ()))
            self._rows[iid] = r
        self._load_desc(None)
        self._sync_btns()

    def _fill(self, level):
        if level == 1:
            i = self._cb_book.current()
            if i < 0:
                return
            with appdb.connect(self.center.db_path) as conn:
                chs = [str(r[0]) for r in conn.execute(
                    'SELECT DISTINCT chapter FROM bible_index WHERE bcode=? '
                    'ORDER BY chapter', (self.center._books[i][0],))]
            self._cb_chap.config(values=chs)
            if chs:
                self._cb_chap.current(0)
        i = self._cb_book.current()
        if i < 0 or not self._cb_chap.get():
            return
        with appdb.connect(self.center.db_path) as conn:
            vs = [str(r[0]) for r in conn.execute(
                'SELECT verse FROM bible_index WHERE bcode=? AND chapter=? '
                'ORDER BY verse', (self.center._books[i][0],
                                   int(self._cb_chap.get())))]
        self._cb_vers.config(values=vs)
        if vs:
            self._cb_vers.current(0)
        self._preview()

    def _target_vid(self):
        i = self._cb_book.current()
        if i < 0 or not self._cb_vers.get():
            return None
        with appdb.connect(self.center.db_path) as conn:
            r = conn.execute('SELECT verse_id FROM bible_index WHERE bcode=? '
                             'AND chapter=? AND verse=?',
                             (self.center._books[i][0],
                              int(self._cb_chap.get()),
                              int(self._cb_vers.get()))).fetchone()
        return r and r[0]

    def _show_preview(self, vid):
        with appdb.connect(self.center.db_path) as conn:
            body = _verse_body(conn, vid) if vid else ''
            lbl = VL._vlabel(conn, vid, self.center.lang) if vid else ''
        self._prev.config(state='normal')
        self._prev.delete('1.0', 'end')
        if body:
            self._prev.insert('1.0', '%s  %s' % (lbl, body))
        self._prev.config(state='disabled')

    def _preview(self):
        self._show_preview(self._target_vid())

    def _on_select(self):
        sel = self._sel()
        if sel:
            self._show_preview(sel[0]['other'])
        self._load_desc(sel[0] if len(sel) == 1 else None)
        self._sync_btns()

    # ── 연결설명문 (2026-08-27) ──────────────────────────────────
    def _load_desc(self, row):
        _t = i18n.t
        self._desc_row = row
        self._desc_txt.delete('1.0', 'end')
        if row is None:
            self._desc_state.config(text=_t('OC_LD_PICK',
                                            '(연결 한 건을 선택하세요)'))
            self._b_desc.config(state='disabled')
            self._desc_txt.config(state='disabled')
            return
        self._desc_txt.config(state='normal')
        with appdb.connect(self.center.db_path) as conn:
            txt, st = VL.link_desc(conn, row, self.center.lang)
        self._desc_txt.insert('1.0', txt)
        names = {'SYS': _t('VLE_S_SYS', '기본'),
                 'EDIT': _t('OC_LD_EDIT', '내 수정(E)'),
                 'NEW': _t('OC_LD_NEW', '내 글'),
                 'NONE': _t('OC_LD_NONE', '없음 — 쓰면 내 글이 됩니다')}
        self._desc_state.config(text=names.get(st, st))
        self._b_desc.config(state='normal')

    def _save_desc(self):
        row = self._desc_row
        if row is None:
            return
        with appdb.connect(self.center.db_path) as conn:
            VL.save_link_desc(conn, row, self.center.lang,
                              self._desc_txt.get('1.0', 'end'))
        self._load_desc(row)                  # 상태 라벨 갱신(E/내 글/기본)
        self.center.changed('LINK')

    def _sel(self):
        return [self._rows[i] for i in self._tv.selection() if i in self._rows]

    def _sync_btns(self):
        sel = self._sel()
        self._b_hide.config(state='normal' if sel else 'disabled')
        mine = [r for r in sel if r['src'] != 'SYS']
        self._b_revert.config(state='normal' if mine else 'disabled')

    def _add(self):
        _t = i18n.t
        tvid = self._target_vid()
        ri = self._cb_rel.current()
        if not tvid or ri < 0 or not self.vid:
            return
        with appdb.connect(self.center.db_path) as conn:
            st = VL.add_link(conn, self.vid, tvid, self._rels[ri][0])
        if st == 'SELF':
            messagebox.showinfo(_t('VLE_TITLE', '내 구절연결'),
                                _t('VLE_SELF', '같은 구절끼리는 이을 수 '
                                   '없습니다.'), parent=self)
            return
        self.load(self.vid)
        self.center.changed('LINK')
        # ★ 방금 이은 연결을 자동 선택하고 설명문 칸에 커서 — 잇자마자 글을
        #   쓰는 흐름이 손을 떼지 않고 이어진다(2026-08-27 사용자 지시.
        #   관리자 구절연결 화면과 같은 문법).
        rel = self._rels[ri][0]
        for iid, r in self._rows.items():
            if r['other'] == tvid and r.get('rel') == rel:
                self._tv.selection_set(iid)
                self._tv.see(iid)
                self._desc_txt.focus_set()
                break

    def _hide(self):
        _t = i18n.t
        rows = self._sel()
        if not rows:
            return
        if not messagebox.askyesno(
                _t('VLE_HIDE', '숨기기'),
                _t('VLE_HIDE_Q', '{n}건을 내 화면에서 숨깁니다. 기본 연결은 '
                   '설정 ▸ 휴지통에서 해제할 수 있습니다. 계속할까요?'
                   ).format(n=len(rows)), parent=self):
            return
        with appdb.connect(self.center.db_path) as conn:
            for r in rows:
                VL.hide_link(conn, r)
        self.load(self.vid)
        self.center.changed('LINK')

    def _revert(self):
        _t = i18n.t
        rows = [r for r in self._sel() if r['src'] != 'SYS']
        if not rows:
            return
        if not messagebox.askyesno(
                _t('VLE_REVERT', '내 것 되돌리기'),
                _t('VLE_REVERT_Q2', '{n}건의 내 연결을 **완전히 지웁니다** '
                   '— 휴지통에 남지 않습니다(기본 연결이 있으면 그것이 '
                   '되살아납니다). 그냥 안 보이게만 하려면 [숨기기]를 '
                   '쓰세요. 계속할까요?').format(n=len(rows)), parent=self):
            return
        with appdb.connect(self.center.db_path) as conn:
            for r in rows:
                VL.revert_link(conn, r)
        self.load(self.vid)
        self.center.changed('LINK')


# ══════════════════════════════════════════════════════════════════
#  렌즈 탭 — 자체 앵커 (구절 축과 다르다 — 사용자 승인)
# ══════════════════════════════════════════════════════════════════
class _LensTab(ttk.Frame):
    def __init__(self, parent, center):
        super().__init__(parent)
        _t = i18n.t
        self.center = center
        self._lenses = []
        self._nodes = []
        bar = tk.Frame(self)
        bar.pack(fill='x', padx=8, pady=(8, 2))
        tk.Label(bar, text='ⓘ ' + _t('OC_LENS_NOTE',
                                     '렌즈 글은 구절 기준과 무관합니다 — '
                                     '여기서 렌즈·노드를 선택합니다.'),
                 anchor='w').pack(side='left')
        sel = tk.Frame(self)
        sel.pack(fill='x', padx=8, pady=(2, 4))
        tk.Label(sel, text=_t('OC_LENS', '렌즈')).pack(side='left')
        self._cb_lens = ttk.Combobox(sel, state='readonly', width=26)
        self._cb_lens.pack(side='left', padx=(4, 8))
        tk.Label(sel, text=_t('OC_NODE', '노드')).pack(side='left')
        self._cb_node = ttk.Combobox(sel, state='readonly', width=26)
        self._cb_node.pack(side='left', padx=(4, 0))
        self._cb_lens.bind('<<ComboboxSelected>>',
                           lambda _e: self._lens_changed())
        self._cb_node.bind('<<ComboboxSelected>>',
                           lambda _e: self._load_sections())
        self.panel = _SectionsPanel(self, center)
        self.panel.pack(fill='both', expand=True)
        self._load_lenses()

    def _load_lenses(self):
        with appdb.connect(self.center.db_path) as conn:
            self._lenses = conn.execute(
                "SELECT u.sys_unit_id, u.unit_name_sid FROM sys_unit_asset u "
                "JOIN sys_plan_category pc ON pc.cat_id = u.cat_id "
                "WHERE u.unit_type='CONTAINER' AND pc.scope='LENS' "
                "AND COALESCE(u.record_status,'LIVE')='LIVE' "
                "ORDER BY u.sort_order, u.sys_unit_id").fetchall()
        self._cb_lens.config(values=[n for _i, n in self._lenses])

    def _lens_changed(self, keep_node=None):
        _t = i18n.t
        i = self._cb_lens.current()
        if i < 0:
            return
        lid = self._lenses[i][0]
        with appdb.connect(self.center.db_path) as conn:
            self._nodes = conn.execute(
                "SELECT u.sys_unit_id, u.unit_name_sid FROM sys_link_asset l "
                "JOIN sys_unit_asset u ON u.sys_unit_id = l.target_id "
                "WHERE l.link_type='CONT_NODE' AND l.clicked_id=? "
                "AND COALESCE(l.record_status,'LIVE')='LIVE' "
                "AND COALESCE(u.record_status,'LIVE')='LIVE' "
                "ORDER BY l.sort_order, u.sys_unit_id", (lid,)).fetchall()
        vals = [_t('OC_LENS_SELF', '(렌즈 자체)')] + [n for _i, n in self._nodes]
        self._cb_node.config(values=vals)
        if keep_node is not None:
            ids = [nid for nid, _n in self._nodes]
            self._cb_node.current(ids.index(keep_node) + 1
                                  if keep_node in ids else 0)
        else:
            self._cb_node.current(0)
        self._load_sections()

    def _load_sections(self):
        i = self._cb_lens.current()
        if i < 0:
            self.panel.load([])
            return
        lid = self._lenses[i][0]
        ni = self._cb_node.current()
        if ni <= 0:
            secs = [(k, i18n.t(ik, d), tt, lid, vp)
                    for k, ik, d, tt, vp in CONT_SECTIONS]
        else:
            nid = self._nodes[ni - 1][0]
            secs = [(k, i18n.t(ik, d), tt, nid, vp)
                    for k, ik, d, tt, vp in NODE_SECTIONS]
        self.panel.load(secs)

    def set_lens_anchor(self, lens):
        """('CONTAINER', id) 또는 ('NODE', id) — 열 때 포커스."""
        kind, aid = lens
        with appdb.connect(self.center.db_path) as conn:
            if kind == 'NODE':
                r = conn.execute(
                    "SELECT clicked_id FROM sys_link_asset "
                    "WHERE link_type='CONT_NODE' AND target_id=? "
                    "AND COALESCE(record_status,'LIVE')='LIVE' LIMIT 1",
                    (aid,)).fetchone()
                lid = r and r[0]
            else:
                lid = aid
        if not lid:
            return
        ids = [i for i, _n in self._lenses]
        if lid not in ids:
            return                            # 내 렌즈(파생) — 덮개 밖
        self._cb_lens.current(ids.index(lid))
        self._lens_changed(keep_node=aid if kind == 'NODE' else None)


# ══════════════════════════════════════════════════════════════════
#  자가 검증 — 구획 표 ↔ 덮개 대상 정합
# ══════════════════════════════════════════════════════════════════
def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    verse_tts = {x[3] for x in VERSE_SECTIONS}
    t('절 구획 = 안정 앵커 덮개 대상만',
      verse_tts <= set(overlay.TEXT_OVERLAY_TYPES), verse_tts)
    lens_tts = {x[3] for x in NODE_SECTIONS} | {x[3] for x in CONT_SECTIONS}
    t('렌즈 구획 = 이름 열쇠 대상만',
      lens_tts <= set(overlay.LENS_TEXT_TYPES), lens_tts)
    t('절 구획 여섯 (장·일반·전문·질문·연구·기도)',
      len(VERSE_SECTIONS) == 6)
    keys = [x[0] for x in VERSE_SECTIONS + NODE_SECTIONS + CONT_SECTIONS]
    t('구획 열쇠 중복 없음', len(keys) == len(set(keys)))
    t('PERI_DESC 는 구획에 없다(앵커 미확증)',
      'PERI_DESC' not in verse_tts | lens_tts)
    print('overlay_center selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)
