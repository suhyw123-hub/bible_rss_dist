# -*- coding: utf-8 -*-
"""읽기 설정 팝업 — 고치는 즉시 본문이 바뀌는 것을 보면서 맞춘다 (2026-08-12 사용자 지시).

    「폰트 조절하는 팝업에서 수정할 때마다 바뀌는 모습을 직접 확인하면 좋겠다」

두 겹으로 보인다
    ① **실제 P1 본문** — modal 로 잡지 않으므로(`grab_set` 없음) 뒤 화면이 살아 있고
       값을 만질 때마다 그 자리에서 다시 그려진다.
    ② **팝업 안 미리보기** — ⚠ 지금 장에 짧은 절만 있으면 P1 에서는 줄바꿈이 안 보여
       행간을 바꿔도 변화를 느낄 수 없다. 그래서 **그 장에서 가장 긴 절**을 골라 싣는다.
       지어낸 예문이 아니라 실제 본문이라야 판단이 정직하다.

⚠ 자간(letter spacing)은 넣지 않았다 — **Tk 폰트에 그 옵션이 없다**
  (`family·size·weight·slant·underline·overstrike` 여섯 개뿐, 2026-08-12 실측).
  글자 사이에 공백을 끼우는 우회는 본문을 훼손하고 복사·검색을 깨뜨린다.
  서체마다 자간이 다르므로 **글꼴 선택이 부분적인 대안**이 된다.

⚠ 저장소는 기존 `READING_FONT` 하나다. '지원/설정 ▸ 폰트' 탭과 같은 값을 만지므로
  두 곳이 어긋나지 않는다(같은 것을 두 군데서 고치게 두면 반드시 갈라진다).
"""

import tkinter as tk
from tkinter import ttk

import i18n
import theme_font

# (저장 키, i18n 키, 기본 라벨, 최소, 최대)
ITEMS = [
    ('line_gap', 'RS_LINE_GAP', '줄 간격',   0, 14),
    ('para_gap', 'RS_PARA_GAP', '절 간격',   0, 20),
    ('margin',   'RS_MARGIN',   '좌우 여백', 0, 60),
]

PREVIEW_FALLBACK = ('길르앗에 우거하는 자 중에 디셉 사람 엘리야가 아합에게 고하되 '
                    '나의 섬기는 이스라엘 하나님 여호와의 사심을 가리켜 맹세하노니 '
                    '내 말이 없으면 수년 동안 우로가 있지 아니하리라 하니라')


class ReadingSetupPopup(tk.Toplevel):

    def __init__(self, master, db_path, on_change=None,
                 sample_getter=None, anchor_widget=None):
        super().__init__(master)
        self.db_path = db_path
        self.on_change = on_change          # 값이 바뀔 때마다 부른다(실제 본문 갱신)
        self.sample_getter = sample_getter  # 미리보기에 쓸 (번호, 본문)
        self.title(i18n.t('RS_TITLE', '읽기 설정'))
        self.resizable(False, False)
        self.transient(master)

        # 되돌리기용 스냅샷 — 이것저것 만지다 원래대로 오고 싶은 것이 보통이다
        self._orig = self._load()
        self._vars = {}
        self._job = None

        self._build()
        self._place_below(anchor_widget)
        self.protocol('WM_DELETE_WINDOW', self._close)

    # ── 저장소 ────────────────────────────────────────────────────────────
    # ★ **앱이 실제로 읽는 곳에 쓴다** (2026-08-13, 사용자 지적 「재실행하면 적용 안 됨」).
    #   예전에는 이 팝업만 `reading_font`(`user_config['READING_FONT']`)에 썼는데,
    #   본문·설명문·주석은 전부 `theme_font`(`user_config['THEME']`)를 읽도록 갈아탄
    #   뒤였다. **저장은 되는데 아무도 읽지 않아** 다시 켜면 사라졌다.
    #   ⇒ 이 팝업도 `theme_font` 「본문」 구역에 쓴다. **저장소는 하나다.**
    SCOPE = 'bible'

    def _load(self):
        return theme_font.resolve(self.db_path, self.SCOPE)

    def _store(self, d):
        theme_font.save(self.db_path, self.SCOPE,
                        family=d['family'], size=d['size'],
                        line_gap=d['line_gap'], para_gap=d['para_gap'],
                        margin=d['margin'])

    # ── 화면 ──────────────────────────────────────────────────────────────
    def _build(self):
        cur = self._load()

        top = tk.Frame(self, bg='#F4F6F7')
        top.pack(fill='x', padx=12, pady=(10, 4))
        tk.Label(top, text=i18n.t('RS_HINT', '움직이면 본문이 곧바로 바뀝니다.'),
                 bg='#F4F6F7', fg='#7F8C8D', font=('Malgun Gothic', 8)).pack(side='left')

        g = tk.Frame(self); g.pack(fill='x', padx=12, pady=2)

        # 글꼴 · 크기
        tk.Label(g, text=i18n.t('SET_FONT_FAMILY', '글꼴') + ':',
                 font=('Malgun Gothic', 9)).grid(row=0, column=0, sticky='w', pady=3)
        self._fam = ttk.Combobox(g, width=20, font=('Malgun Gothic', 9),
                                 values=self._font_families())
        self._fam.set(cur['family'])
        self._fam.grid(row=0, column=1, columnspan=2, sticky='w', padx=(6, 0))
        self._fam.bind('<<ComboboxSelected>>', lambda e: self._changed())

        tk.Label(g, text=i18n.t('SET_FONT_SIZE', '크기') + ':',
                 font=('Malgun Gothic', 9)).grid(row=1, column=0, sticky='w', pady=3)
        self._size = ttk.Combobox(g, width=6, state='readonly', font=('Malgun Gothic', 9),
                                  values=[str(n) for n in range(8, 25)])
        self._size.set(str(cur['size']))
        self._size.grid(row=1, column=1, sticky='w', padx=(6, 0))
        self._size.bind('<<ComboboxSelected>>', lambda e: self._changed())

        # 간격 세 항목 — 슬라이더
        for r, (key, ikey, dflt, lo, hi) in enumerate(ITEMS, start=2):
            tk.Label(g, text=i18n.t(ikey, dflt) + ':',
                     font=('Malgun Gothic', 9)).grid(row=r, column=0, sticky='w', pady=3)
            var = tk.IntVar(value=cur.get(key, lo))
            self._vars[key] = var
            sc = tk.Scale(g, from_=lo, to=hi, orient='horizontal', variable=var,
                          showvalue=False, length=150, bg='#FAFAFA', highlightthickness=0,
                          command=lambda _v, k=key: self._changed())
            sc.grid(row=r, column=1, sticky='w', padx=(6, 4))
            lbl = tk.Label(g, textvariable=var, width=3, anchor='w',
                           font=('Consolas', 9), fg='#5D6D7E')
            lbl.grid(row=r, column=2, sticky='w')

        # 미리보기
        pv = tk.LabelFrame(self, text=i18n.t('RS_PREVIEW', '미리보기'),
                           font=('Malgun Gothic', 8, 'bold'))
        pv.pack(fill='both', expand=True, padx=12, pady=(8, 4))
        self._pv = tk.Text(pv, wrap='word', height=5, width=44, bd=0,
                           highlightthickness=0, bg='#FFFFFF', cursor='arrow')
        self._pv.pack(fill='both', expand=True, padx=4, pady=4)
        self._pv.bind('<Key>', lambda e: 'break')
        self._pv.tag_configure('num', foreground='#95A5A6')

        btn = tk.Frame(self); btn.pack(fill='x', padx=12, pady=(4, 10))
        tk.Button(btn, text=i18n.t('RS_REVERT', '되돌리기'), font=('Malgun Gothic', 9),
                  command=self._revert).pack(side='left')
        tk.Button(btn, text=i18n.t('COMMON_CLOSE', '닫기'), font=('Malgun Gothic', 9, 'bold'),
                  bg='#5D6D7E', fg='white', width=8,
                  command=self._close).pack(side='right')
        tk.Button(btn, text=i18n.t('RS_APPLY', '적용'), font=('Malgun Gothic', 9, 'bold'),
                  bg='#2E86C1', fg='white', width=8,
                  command=self._apply_save).pack(side='right', padx=(0, 6))

        self._render_preview()

    def _font_families(self):
        try:
            import tkinter.font as tkfont
            return [f for f in sorted(tkfont.families()) if not f.startswith('@')]
        except Exception:
            return ['Georgia', 'Malgun Gothic', 'Times New Roman']

    def _place_below(self, anchor):
        """⚠ P1 을 가리면 미리보기의 뜻이 없다 — 본문 **아래쪽**에 띄운다."""
        self.update_idletasks()
        try:
            m = self.master
            x = m.winfo_rootx() + m.winfo_width() - self.winfo_reqwidth() - 40
            y = m.winfo_rooty() + int(m.winfo_height() * 0.42)
            y = min(y, self.winfo_screenheight() - self.winfo_reqheight() - 60)
            self.geometry(f'+{max(0, x)}+{max(0, y)}')
        except Exception:
            pass

    # ── 값 반영 ───────────────────────────────────────────────────────────
    def _current(self):
        d = {k: v.get() for k, v in self._vars.items()}
        d['family'] = self._fam.get() or self._orig['family']
        try:
            d['size'] = int(self._size.get())
        except Exception:
            d['size'] = self._orig['size']
        return d

    def _changed(self):
        """슬라이더는 드래그 중 계속 부른다 — 마지막 값만 그리도록 살짝 미룬다."""
        if self._job is not None:
            try:
                self.after_cancel(self._job)
            except Exception:
                pass
        self._job = self.after(40, self._apply_live)

    def _apply_live(self):
        self._job = None
        # ⚠ 미리보기 중에는 **DB 에 쓰지 않는다.** 그래야 [되돌리기]가 뜻을 갖고,
        #   같은 값을 쓰는 다른 화면(도서/설교·설명문)이 확정 전에 흔들리지 않는다.
        d = self._current()
        self._render_preview(d)
        if callable(self.on_change):
            self.on_change(d)

    def _render_preview(self, d=None):
        d = d or self._current()
        num, body = ('1', PREVIEW_FALLBACK)
        if callable(self.sample_getter):
            try:
                got = self.sample_getter()
                if got:
                    num, body = got
            except Exception:
                pass
        try:
            import tkinter.font as tkfont
            f = tkfont.Font(family=d['family'], size=d['size'])
            w = max(14, f.measure('0' * len(str(num))) + int(f.measure(' ') * 1.5))
        except Exception:
            w = 22
        self._pv.config(state='normal', font=(d['family'], d['size']),
                        spacing1=d['para_gap'], spacing2=d['line_gap'],
                        spacing3=d['para_gap'], padx=d['margin'], tabs=(w,))
        self._pv.tag_configure('v', lmargin1=0, lmargin2=w)
        self._pv.delete('1.0', 'end')
        self._pv.insert('end', f'{num}\t', ('num',))
        self._pv.insert('end', body + '\n')
        self._pv.tag_add('v', '1.0', '1.end+1c')

    # ── 버튼 ──────────────────────────────────────────────────────────────
    def _apply_save(self):
        d = self._current()
        self._store(d)
        if callable(self.on_change):
            self.on_change(d)

    def _revert(self):
        o = self._orig
        self._fam.set(o['family']); self._size.set(str(o['size']))
        for k, v in self._vars.items():
            v.set(o.get(k, 0))
        self._apply_live()

    def _close(self):
        # 저장하지 않고 닫으면 원래 값으로 화면을 되돌린다 — 미리보기가 남으면 혼란스럽다
        saved = self._load()
        if callable(self.on_change):
            self.on_change(saved)
        self.destroy()
