# -*- coding: utf-8 -*-
"""url_text.py — Text 위젯 본문 속 URL 자동 링크 (영구 모듈, 2026-08-19).

0.txt ⑨ (사용자 지시): 「연구자료 본문에 하이퍼링크를 입력하면 링크 표시가 되어
외부 사이트로 이동 가능해야 함. 구절노트(묵상노트)에서도 지원」.

쓰는 법 — 내용을 넣은 뒤(또는 KeyRelease 마다) 한 줄:
    import url_text; url_text.linkify(txt)

· 본문 중 http(s)://… 를 찾아 파란 밑줄 태그를 붙이고, 클릭하면 브라우저를 연다.
· 몇 번을 다시 불러도 안전하다(태그를 지우고 다시 붙인다 · 바인딩은 위젯당 한 번).
· 기존 규약(묵상노트의 「URL 」줄 방식)과 태그가 달라 서로 건드리지 않는다.
⚠ 읽기 전용(disabled) Text 에서도 태그 클릭은 작동한다 — 클릭 판정은 태그 기준이라
  드래그 선택·복사(`enable_copy`)와 충돌하지 않는다.

    python url_text.py --selftest        (의무)
"""
import re
import webbrowser

TAG = 'auto_url'
_URL_RE = re.compile(r'https?://[^\s<>"\'　]+')
_BOUND = '_url_text_bound'


def _open(txt, event):
    idx = txt.index('@%d,%d' % (event.x, event.y))
    if TAG not in txt.tag_names(idx):
        return
    rng = txt.tag_prevrange(TAG, idx + '+1c')
    if rng:
        url = txt.get(rng[0], rng[1]).rstrip('.,);]。')
        if url:
            webbrowser.open(url)


def _motion(txt, event):
    idx = txt.index('@%d,%d' % (event.x, event.y))
    txt.config(cursor='hand2' if TAG in txt.tag_names(idx) else '')


def linkify(txt):
    """본문을 훑어 URL 에 링크 태그를 붙인다. 반환 = 찾은 URL 수."""
    try:
        content = txt.get('1.0', 'end-1c')
    except Exception:
        return 0
    txt.tag_remove(TAG, '1.0', 'end')
    n = 0
    for i, line in enumerate(content.split('\n'), start=1):
        for m in _URL_RE.finditer(line):
            txt.tag_add(TAG, '%d.%d' % (i, m.start()), '%d.%d' % (i, m.end()))
            n += 1
    if not getattr(txt, _BOUND, False):
        txt.tag_configure(TAG, foreground='#2E86C1', underline=True)
        txt.tag_bind(TAG, '<Button-1>', lambda e, w=txt: _open(w, e))
        txt.bind('<Motion>', lambda e, w=txt: _motion(w, e), add='+')
        setattr(txt, _BOUND, True)
    return n


def _selftest():
    import tkinter as tk
    ok = True

    def chk(name, cond):
        nonlocal ok
        print(('  PASS ' if cond else '  FAIL ') + name)
        ok = ok and cond

    root = tk.Tk(); root.withdraw()
    t = tk.Text(root)
    t.insert('1.0', '첫 줄에는 링크 없음\n'
                    '보라 https://example.com/a?b=1 을, 그리고 http://x.io 도.\n'
                    'https 로 시작하는 말은 링크가 아니다\n'
                    '한 줄 둘 http://a.com http://b.com')
    n = linkify(t)
    chk('URL 4개 탐지', n == 4)
    rngs = t.tag_ranges(TAG)
    chk('태그 범위 4쌍', len(rngs) == 8)
    first = t.get(rngs[0], rngs[1])
    chk('첫 URL 경계(한글 앞에서 끊김)', first == 'https://example.com/a?b=1')
    chk('낱말 https 미탐지', 'https 로' not in ' '.join(
        t.get(rngs[i], rngs[i + 1]) for i in range(0, len(rngs), 2)))
    n2 = linkify(t)
    chk('재호출 멱등', n2 == 4 and len(t.tag_ranges(TAG)) == 8)
    t.config(state='disabled')
    chk('disabled 에서도 재스캔', linkify(t) == 4)
    root.destroy()
    print('결과: ' + ('전부 통과' if ok else '실패 있음'))
    return 0 if ok else 1


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(_selftest())
    print(__doc__)
