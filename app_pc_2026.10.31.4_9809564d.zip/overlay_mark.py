# -*- coding: utf-8 -*-
"""덮개 표식 — **N / E / H** 단일 소스 (2026-08-26 신설).

★ 왜 (사용자 지시): 「사용자가 추가/수정/숨기기 한 자료 표시방법도 중요하다.
  N(New) / E(Edit) / H(Hide) 라는 문자를 배치해야 한다. **덮개 기능이 작동하는
  모든 화면에 부착**해야 한다. **이 로직은 공통 로직으로 개발하라.**」

엔진(`overlay.resolve`)이 이미 각 행에 `_src` 를 붙여 준다 —
`'SYS'`(그대로) · `'EDIT'`(내가 고침) · `'NEW'`(내가 더함). `diff()` 는 가린 것을
`hidden` 으로 낸다. **데이터는 있었는데 화면이 말하지 않던 것**이라, 여기서는
그 값을 **보이는 글자**로 옮기기만 한다.

⚠⚠ **H 는 읽는 화면에 뜨면 안 된다.** 가린 줄에 「H」를 붙여 목록에 남기면
  그것은 가린 것이 아니다. 그래서 자리를 둘로 가른다:
    · **읽는 화면**(`for_reading=True`) — N·E 만. 가린 것은 애초에 목록에 없다.
    · **관리 화면**([E] 팝업 · 휴지통) — N·E·H 셋 다.

⚠ **글자를 화면마다 적지 말 것.** `MARKS` 한 곳에서 정한다 — 나중에 다른 글자로
  바꾸거나 언어별로 가르려면 여기만 고친다.
⚠ 글리프(✎·✓)를 쓰지 않는다 — **맑은 고딕에 없어서** 폴백으로 그려진다
  (기호 사전 실측). 라틴 대문자는 어느 글꼴에서나 같다.

`--selftest` 의무.
"""
import sys

# ── 표식 정의 — 여기가 단일 소스 ────────────────────────────────────────
# ★ 2026-09-01 표시정책 확정(사용자) — **사용자 데이터는 어디서나 `[u]` 하나.**
#   글자 u 는 영어 화면에서 낱말과 섞이고, 감싼 글리프(Ⓤ)는 맑은 고딕에 없다
#   (158개 폰트 cmap 실측 6%). `[u]` 는 ASCII 라 100% 이고 「네모 속 u」로 읽힌다.
#   E(내가 고친 배포 글)·H(가림)는 관리 화면 전용이라 라틴 글자 유지.
#   ⚠ 표식이 이제 **여러 글자**일 수 있다 — `[:1]` 로 자르던 옛 전제를 걷었다.
NEW = '[u]'
EDIT = 'E'
HIDE = 'H'

#  표식 → (역할색, 설명 열쇠, 기본 설명[, 읽는 이름 열쇠, 읽는 이름])
#  ★★★ **다섯째 칸 = 「읽는 화면에서 제목 뒤에 붙일 이름」** (2026-09-22 사용자
#    「(E) 표시가 **잘 식별되지 않는다** — "(Updated)"라고 명시적으로」).
#    좁은 **목록 칸**은 글자 하나가 맞고(`prefix` · `SLOT`), 넓은 **읽는 자리**는
#    낱말이 맞다. 같은 표식이 자리에 따라 다르게 보이는 것이 아니라
#    **자리마다 쓸 말을 이 표가 함께 갖는 것**이다.
#  ⚠ 없으면 표식 글자를 그대로 쓴다 — `[u]` 는 사용자가 2026-09-01 에 확정한
#    모양이라 건드리지 않는다.
MARKS = {
    NEW:  ('success', 'OVM_NEW',  '내가 더한 것'),
    EDIT: ('accent',  'OVM_EDIT', '내가 고친 것', 'OVM_EDIT_LBL', 'Updated'),
    HIDE: ('fg_dim',  'OVM_HIDE', '내가 가린 것'),
}

# 이름 시작선을 맞추는 **고정폭 자리**(표식이 없어도 같은 폭을 차지한다).
# ★ ★●◐♥○ 표식이 이미 쓰는 문법 — 안 그러면 줄마다 이름이 들쭉날쭉하다.
# ⚠ 가장 긴 표식(`[u]` 3자) + 한 칸 = 4.
SLOT = 4


def _key(mark):
    """표식 문자열 → MARKS 열쇠. 정확히 일치할 때만 인정(글자 수 전제 없음)."""
    m = (mark or '')
    return m if m in MARKS else ''


def mark_of(src, hidden=False, for_reading=False):
    """엔진의 `_src`(+가림 여부) → 표식 글자. 없으면 `''`.

    `src` 는 `overlay.resolve` 가 붙인 `'SYS'|'EDIT'|'NEW'` 이거나
    그 행의 `record_status`(`'HIDE'`)여도 된다 — 화면마다 들고 있는 값이 다르다.
    """
    if hidden or (src or '').upper() == 'HIDE':
        return '' if for_reading else HIDE
    s = (src or '').upper()
    if s == 'EDIT':
        return EDIT
    if s == 'NEW':
        return NEW
    return ''


def prefix(text, mark):
    """목록 줄 앞에 **고정폭**으로 붙인다 — `'[u] 다윗'` / `'    다윗'`.

    ⚠ 표식이 없을 때도 같은 폭을 채운다. 안 그러면 이름 시작선이 흔들린다.
    """
    m = _key(mark)
    return ('%-*s%s' % (SLOT, m, text)) if m else (' ' * SLOT + (text or ''))


def color(mark, C=None):
    """표식의 역할색. `C` 는 `ui_theme.C` 같은 「역할 → 색」 함수."""
    role = MARKS.get(_key(mark), (None,))[0]
    if role is None:
        return None
    if C is None:
        try:
            import ui_theme
            C = ui_theme.C
        except Exception:
            return None
    try:
        return C(role)
    except Exception:
        return None


def describe(mark):
    """사람이 읽는 설명 — 범례·툴팁용. 다국어는 i18n 열쇠를 쓴다."""
    ent = MARKS.get(_key(mark))
    if not ent:
        return ''
    try:
        import i18n
        return i18n.t(ent[1], ent[2])
    except Exception:
        return ent[2]


def label(mark):
    """**읽는 화면에서 제목 뒤에 붙일 이름** — `'Updated'`. 없으면 표식 그대로.

    ⚠ 목록 칸에는 쓰지 않는다 — 거기는 `prefix()` 의 고정폭 자리다.
    """
    ent = MARKS.get(_key(mark))
    if not ent:
        return ''
    if len(ent) < 5:
        return _key(mark)
    try:
        import i18n
        return i18n.t(ent[3], ent[4])
    except Exception:
        return ent[4]


def legend(for_reading=False):
    """범례 문자열 — `'N 내가 더한 것 · E 내가 고친 것'`.

    ⚠ 표식만 있고 뜻을 어디서도 안 알려 주면 「이 N 이 뭐지」가 된다.
    """
    ks = [NEW, EDIT] if for_reading else [NEW, EDIT, HIDE]
    return ' · '.join('%s %s' % (k, describe(k)) for k in ks)


def tag_name(mark):
    """Treeview 태그 이름 — 화면마다 다른 이름을 지으면 색이 갈린다.

    ⚠ `[u]` 의 대괄호는 태그 이름에 안 넣는다 — 글자·숫자만 남긴다(`ovm_u`)."""
    m = _key(mark)
    if not m:
        return ''
    return 'ovm_' + ''.join(ch for ch in m.lower() if ch.isalnum())


def configure_tree(tv, C=None):
    """Treeview 에 표식 태그 색을 입힌다. **그릴 때마다 부른다**(§36-5b).

    ⚠ `ui_theme.paint` 는 위젯 옵션만 본다 — **태그 색은 못 본다.** 만들 때 한 번
      칠하면 테마를 바꿔도 굳는다.
    """
    for m in MARKS:
        col = color(m, C)
        if col:
            try:
                tv.tag_configure(tag_name(m), foreground=col)
            except Exception:
                pass


# ══════════════════════════════════════════════════════════════════
def selftest():
    ok = [0, 0]

    def t(label, cond, got=''):
        ok[1] += 1
        if cond:
            ok[0] += 1
        print('  %s  %s %s' % ('OK  ' if cond else 'FAIL', label, got))

    # ① 매핑
    t('SYS 는 표식 없음', mark_of('SYS') == '')
    t('EDIT → E', mark_of('EDIT') == EDIT)
    t('NEW → N', mark_of('NEW') == NEW)
    t('record_status HIDE → H', mark_of('HIDE') == HIDE)
    t('hidden 플래그로도 H', mark_of('SYS', hidden=True) == HIDE)
    t('소문자도 받는다', mark_of('edit') == EDIT)
    t('None 은 빈 값', mark_of(None) == '')

    # ② ★★ 읽는 화면에서는 H 가 안 나온다 — 이것이 이 부품의 핵심 규칙
    t('★ 읽는 화면에서 가림은 표식이 없다 (가린 것은 목록에 없어야 한다)',
      mark_of('HIDE', for_reading=True) == '')
    t('   읽는 화면에서도 N·E 는 나온다',
      mark_of('NEW', for_reading=True) == NEW
      and mark_of('EDIT', for_reading=True) == EDIT)

    # ③ 고정폭 — 표식이 있든 없든 이름 시작선이 같다
    a, b = prefix('다윗', EDIT), prefix('다윗', '')
    u = prefix('다윗', NEW)
    t('★ 표식이 없어도 같은 폭 (%r / %r)' % (a, b), len(a) == len(b), '%d==%d' % (len(a), len(b)))
    t('   [u] 도 같은 폭', len(u) == len(a), '%d==%d' % (len(u), len(a)))
    t('   표식이 맨 앞', a[0] == EDIT and u.startswith(NEW))
    #  ⚠ `strip()` 은 표식 글자를 안 뗀다 — 자리(SLOT)만큼 잘라 낸다
    t('   이름이 그대로 들어 있다', a[SLOT:] == '다윗' and b[SLOT:] == '다윗'
      and u[SLOT:] == '다윗')
    t('★ 가장 긴 표식이 자리(SLOT)에 든다',
      max(len(m) for m in MARKS) < SLOT, 'SLOT=%d' % SLOT)

    # ④ 태그 이름 — 화면마다 지어내면 색이 갈린다
    t('태그 이름이 표식마다 다르다',
      len({tag_name(m) for m in MARKS}) == len(MARKS))
    t('모르는 표식은 태그 없음', tag_name('X') == '')

    # ⑤ 범례 — 뜻을 알려 주는 자리
    lg = legend(for_reading=True)
    t('읽는 화면 범례에 H 가 없다', HIDE + ' ' not in lg, lg)
    t('관리 화면 범례에는 H 가 있다', HIDE + ' ' in legend())

    # ⑥ 색 — 역할로 나온다(팔레트를 안 박는다)
    seen = {}
    for m in MARKS:
        seen[m] = color(m, C=lambda r: 'ROLE:' + r)
    t('표식마다 다른 역할색', len(set(seen.values())) == len(MARKS), seen)
    t('모르는 표식은 색 없음', color('X', C=lambda r: 'x') is None)

    # ⑦ 탐지력 — 「전부 같은 글자」로 뭉개지지 않는가
    # ── 읽는 이름(label) — 목록 칸과 갈린다
    t('읽는 이름이 낱말이다', len(label(EDIT)) > 1, label(EDIT))
    t('읽는 이름은 표식 글자가 아니다', label(EDIT) != EDIT, label(EDIT))
    t('읽는 이름이 없으면 표식 그대로', label(NEW) == NEW, label(NEW))
    t('모르는 표식은 빈 이름', label('?') == '')
    # ⚠ **목록 칸은 안 바뀐다** — 낱말을 거기 쓰면 이름 시작선이 통째로 밀린다
    t('목록 칸은 글자 하나 그대로',
      prefix('다윗', EDIT).startswith(EDIT)
      and len(prefix('다윗', EDIT)) == SLOT + 2,
      repr(prefix('다윗', EDIT)))

    t('★ (탐지력) 세 표식이 서로 다르다',
      len({NEW, EDIT, HIDE}) == 3)

    print('overlay_mark selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)
