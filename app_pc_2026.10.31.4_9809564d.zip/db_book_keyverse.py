# -*- coding: utf-8 -*-
"""db_book_keyverse.py — **저자가 적어 둔 「이 편의 본문」을 기준 구절 칸에 채운다**
(2026-08-31 신설 · 영구 · `--selftest` 의무 · 멱등).

★★★ 왜 — `sys_book_unit` 7,228편 중 **874편**이 `key_verse_ref` 와 `start_vid`
  가 둘 다 비어 있다. 124차가 그 자리에 적어 둔 원칙 그대로다:
  **「지어내지 않는다 … 채울 것은 「본문이 성구를 인용하는데 칸이 비어 있는」
  편이다.」**

★★★ **채우는 길은 둘뿐이고, 둘 다 저자가 쓴 것을 읽는다.**
  | 길 | 무엇을 근거로 | 실측 |
  |---|---|---|
  | ⓐ **인용 대조** | 저자가 **인용문 + 약명**을 나란히 적었다. 그 인용문을 **성경 본문과 대조**해 책을 확정한다 | 3편 |
  | ⓑ **머리 약명** | 인용부호·줄표 뒤로 약명이 있다 | 26편 |
  둘 다 **머리 `HEAD_WIN`(500자) 안**일 것을 요구한다.
  실측 채운 것 = **29편**(에더샤임 성전 19 · 마이어 7 · 스펄전 2 · 번연 1).

⚠⚠ **첫 인용을 기준 구절로 삼지 않는다.** 성구를 적은 편은 279편이지만 그중
  대부분(에더샤임의 역사·로 의 논설)은 **인용일 뿐 그 편을 대표하지 않는다.**
  「묵상구절 하나를 대면 그 구절이 이 글을 대표하는가」가 잣대다(§booktrans.md).
  자리(머리·인용부호 뒤)가 그 뜻을 말해 줄 때만 채운다.

⚠⚠ **이름을 짐작하지 않고 인용문을 성경과 대조한다.** OCR 이 상한 자료가 있다 —
  MILLER 는 `—Joun i. 1`·`Marv iii. 2` 꼴이고 **`Mar*` 는 마태와 마가를 가릴 수
  없다**(실측 Marv·Marr·Mart·Marx·Martt·Marrt·Martr·Makk). 이름으로 고치려
  들면 그것이 곧 지어내는 것이다.
  ⏭ **MILLER 는 이 도구의 대상이 아니었다**(실측으로 확인) — 268편은 이미
    `start_vid` 가 있고(요 1:1 = 26046), 비어 있는 155편은 **서문·시·비성구
    글**이라 비어 있는 것이 맞다. 다만 **본문에 적힌 약명이 상해 있어 화면에서
    안 눌린다** — 그것은 `sys_book_unit_text` 를 손보는 **별개의 과제**다
    (`start_vid` 를 이미 아니까 대조로 검증할 수 있다).

⚠ **덮어쓰지 않는다** — 두 칸이 **다 비어 있는** 편만 채운다.
⚠ `sys_book_unit` 은 **감사 트리거 대상이 아니다**(§10-1 `TARGETS`).
  그래서 이 도구가 **제 백업표**(`temp_bookunit_keyverse_backup`)를 남긴다.
  `--undo` 로 되돌린다.

사용법
    python -X utf8 db_book_keyverse.py --selftest
    python -X utf8 db_book_keyverse.py --check
    python -X utf8 db_book_keyverse.py --apply
    python -X utf8 db_book_keyverse.py --undo
"""
import re
import sys

import appdb

BACKUP = 'temp_bookunit_keyverse_backup'

#: 「이 편의 본문」이라 볼 수 있는 머리 범위(글자) — 두 길이 같은 값을 쓴다.
HEAD_WIN = 500

#: 대조에 쓰는 영어 역본 — 저자마다 쓰던 판이 달라 넷을 함께 본다.
VERSIONS = ('KJV', 'ASV', 'WEB', 'BSB')

_ROMAN = {'i': 1, 'v': 5, 'x': 10, 'l': 50, 'c': 100}

#: ⓐ 인용문 + 약명 — `"…본문…" —Joun i. 1`
_RE_QUOTE = re.compile(
    r'[“"]([^“”"]{15,400})[”"]'
    r'\s*[—–\-]*\s*'
    r'([A-Za-z]{2,12})\.?\s*([ivxlc]+|\d{1,3})\.?\s*[:.]?\s*(\d{1,3})')

#: ⓑ 머리 약명 앞에 와야 하는 글자 — 인용 끝·줄표·줄바꿈
_RE_PRE = re.compile(r'[“”"’\'—–\-]\s*$|\n\s*$|^\s*$')


def _roman(s):
    s = (s or '').lower()
    if s.isdigit():
        return int(s) or None
    if not s or any(ch not in _ROMAN for ch in s):
        return None
    tot = 0
    for i, ch in enumerate(s):
        v = _ROMAN[ch]
        nxt = _ROMAN[s[i + 1]] if i + 1 < len(s) else 0
        tot += -v if v < nxt else v
    return tot or None


def _norm(s):
    """대조용 정규화 — 글자만 남긴다.

    ⚠ SQL `LIKE` 로는 못 한다 — 성경 본문에 쉼표가 있으면
      `in the beginning was the word and` 가 안 걸린다(실측으로 잡았다).
      **양쪽을 파이썬에서 똑같이 눌러서** 견준다.
    """
    return ' '.join(re.sub(r'[^a-z]+', ' ', (s or '').lower()).split())


class _Cands(object):
    """(장, 절) → [(bcode, 본문)] — 같은 장·절을 여러 번 물으므로 담아 둔다."""

    def __init__(self, conn):
        self._c = conn
        self._m = {}

    def get(self, ch, vs):
        k = (ch, vs)
        if k not in self._m:
            q = ",".join("?" * len(VERSIONS))
            self._m[k] = self._c.execute(
                "SELECT bi.bcode, bc.verse_text FROM bible_content bc"
                "  JOIN bible_index bi ON bi.verse_id=bc.verse_id"
                " WHERE bc.version_code IN (" + q + ")"
                "   AND bi.chapter=? AND bi.verse=?",
                tuple(VERSIONS) + (ch, vs)).fetchall()
        return self._m[k]


def _by_quote(cands, quote, ch, vs, words=7):
    """인용문을 성경과 대조해 **책 하나로 좁혀지면** 그 bcode. 아니면 None."""
    q = _norm(quote)
    if len(q) < 12 or not ch or not vs:
        return None
    key = ' '.join(q.split()[:words])
    got = {bc for bc, txt in cands.get(ch, vs) if key in _norm(txt)}
    return next(iter(got)) if len(got) == 1 else None


def _vid(conn, bc, ch, vs):
    r = conn.execute(
        "SELECT verse_id FROM bible_index WHERE bcode=? AND chapter=? "
        "  AND verse=?", (bc, ch, vs)).fetchone()
    return r[0] if r else None


def _label(conn, bc, ch, vs, lang='EN'):
    r = conn.execute(
        "SELECT COALESCE(full_name,'') FROM book_names"
        " WHERE book_code=? AND UPPER(lang_code)=?", (bc, lang)).fetchone()
    nm = (r[0] if r else '') or str(bc)
    return '%s %d:%d' % (nm, ch, vs)


def plan(conn, book_code=None):
    """채울 수 있는 것을 모은다 → [(unit_id, 책코드, 길, 약명, vid, 근거)]."""
    import book_refs
    tbl = book_refs.names(conn, 'KO')
    cands = _Cands(conn)
    sql = ("SELECT ba.book_code, u.unit_id, t.body_text"
           "  FROM sys_book_asset ba"
           "  JOIN sys_book_unit u ON u.book_id=ba.book_id"
           "  JOIN sys_book_unit_text t ON t.unit_id=u.unit_id"
           "   AND t.text_variant='ORIGINAL'"
           " WHERE COALESCE(u.key_verse_ref,'')='' "
           "   AND COALESCE(u.start_vid,0)=0")
    args = ()
    if book_code:
        sql += " AND ba.book_code=?"
        args = (book_code,)
    out = []
    for bc_code, uid, body in conn.execute(sql, args):
        b = (body or '').replace('\n', ' ')
        # ⓐ 인용 대조 — 가장 확실하다. 먼저 본다.
        # ⚠⚠ **머리 안에 있을 때만** — ⓑ와 같은 조건이다. 없으면 이야기
        #   한가운데 인용이 기준 구절로 올라간다. 실측이 그 선을 보였다:
        #   정당한 것은 자리 94~272, 인용일 뿐인 것은 4,007~32,649 였다
        #   (번연 『천로역정』·뮐러 일기가 그랬다).
        m = _RE_QUOTE.search(b[:HEAD_WIN])
        if m:
            ch, vs = _roman(m.group(3)), int(m.group(4))
            bk = _by_quote(cands, m.group(1), ch, vs)
            if bk:
                vid = _vid(conn, bk, ch, vs)
                if vid:
                    out.append((uid, bc_code, 'QUOTE',
                                _label(conn, bk, ch, vs), vid,
                                m.group(0)[:60]))
                    continue
        # ⓑ 머리 약명 — 자리가 「이 편의 본문」이라 말할 때만
        got = book_refs.find(body or '', tbl)
        if not got:
            continue
        st, en, bk, ch, vs = got[0]
        if st >= HEAD_WIN or not _RE_PRE.search(
                (body or '')[max(0, st - 3):st]):
            continue
        vid = _vid(conn, bk, ch, vs)
        if vid:
            out.append((uid, bc_code, 'HEAD', (body or '')[st:en], vid,
                        (body or '')[max(0, st - 30):en].replace('\n', ' ')))
    return out


def apply(conn, rows):
    """채운다(멱등) — **비어 있는 편만**. → 채운 수."""
    conn.execute(
        "CREATE TABLE IF NOT EXISTS %s ("
        "  unit_id INTEGER PRIMARY KEY, key_verse_ref TEXT, start_vid INTEGER,"
        "  saved_at TEXT DEFAULT (datetime('now')))" % BACKUP)
    n = 0
    for uid, _bc, _how, ref, vid, _ex in rows:
        cur = conn.execute(
            "SELECT COALESCE(key_verse_ref,''), COALESCE(start_vid,0)"
            "  FROM sys_book_unit WHERE unit_id=?", (uid,)).fetchone()
        if not cur or cur[0] or cur[1]:
            continue          # 이미 있다 — 덮지 않는다
        conn.execute(
            "INSERT OR IGNORE INTO %s (unit_id, key_verse_ref, start_vid)"
            " VALUES (?,?,?)" % BACKUP, (uid, cur[0] or None, cur[1] or None))
        conn.execute(
            "UPDATE sys_book_unit SET key_verse_ref=?, start_vid=?"
            " WHERE unit_id=?", (ref, vid, uid))
        n += 1
    conn.commit()
    return n


def undo(conn):
    """백업표대로 되돌린다. → 되돌린 수."""
    try:
        rows = conn.execute(
            "SELECT unit_id, key_verse_ref, start_vid FROM %s" % BACKUP
        ).fetchall()
    except Exception:
        return 0
    n = 0
    for uid, ref, vid in rows:
        conn.execute(
            "UPDATE sys_book_unit SET key_verse_ref=?, start_vid=?"
            " WHERE unit_id=?", (ref, vid, uid))
        n += 1
    conn.execute("DELETE FROM %s" % BACKUP)
    conn.commit()
    return n


def selftest(db_path='bible_master.db'):
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %-4s %s %s' % ('OK' if cond else 'FAIL', name, extra))

    conn = appdb.connect(db_path)
    cands = _Cands(conn)
    t('로마숫자 xlvii', _roman('xlvii') == 47)
    t('아라비아도 읽는다', _roman('12') == 12)
    t('★ 구두점을 눌러서 견준다',
      _norm('In the beginning was the Word, and')
      == 'in the beginning was the word and')

    # ★ 인용 대조 — 상한 이름(`Joun`)이라도 본문이 책을 정한다
    bk = _by_quote(cands, 'In the beginning was the Word, and the Word was'
                          ' with God', 1, 1)
    t('★★ 상한 이름이라도 인용문이 책을 정한다(요 1:1)', bk == 43, bk)
    # ★★ 탐지력 — 안 맞으면 **안 채운다**
    t('★★ 엉뚱한 인용은 안 정해진다',
      _by_quote(cands, 'the quick brown fox jumps over the lazy dog', 1, 1)
      is None)
    t('★★ 너무 짧은 인용은 안 정해진다',
      _by_quote(cands, 'and he said', 1, 1) is None)

    # ★ 정말로 채웠다 되돌리는가 (실제 표에 · 시험 뒤 원복)
    row = conn.execute(
        "SELECT unit_id FROM sys_book_unit"
        " WHERE COALESCE(key_verse_ref,'')='' AND COALESCE(start_vid,0)=0"
        " LIMIT 1").fetchone()
    if not row:
        t('★ 채우고 되돌린다', False, '빈 편이 없다')
    else:
        uid = row[0]
        conn.execute("CREATE TABLE IF NOT EXISTS %s (unit_id INTEGER PRIMARY"
                     " KEY, key_verse_ref TEXT, start_vid INTEGER,"
                     " saved_at TEXT)" % BACKUP)
        had = conn.execute("SELECT COUNT(*) FROM %s" % BACKUP).fetchone()[0]
        n = apply(conn, [(uid, 'X', 'QUOTE', 'John 1:1', 26050, '')])
        got = conn.execute("SELECT key_verse_ref, start_vid FROM sys_book_unit"
                           " WHERE unit_id=?", (uid,)).fetchone()
        t('★ 채운다', n == 1 and got[0] == 'John 1:1', got)
        n2 = apply(conn, [(uid, 'X', 'QUOTE', 'Mark 1:1', 24218, '')])
        got2 = conn.execute("SELECT key_verse_ref FROM sys_book_unit"
                            " WHERE unit_id=?", (uid,)).fetchone()
        t('★★ 이미 있으면 안 덮는다', n2 == 0 and got2[0] == 'John 1:1', got2)
        # ⚠⚠⚠ **여기서 `undo(conn)` 을 부르면 안 된다** — 그것은 백업표를
        #   **통째로** 되돌리는 전역 조치라, 앞서 사람이 적용해 둔 것까지
        #   쓸어 간다. 실제로 그렇게 냈다(2026-08-31, §97차 selftest 정리
        #   사고와 같은 뿌리). ⇒ **시험이 만든 한 줄만** 되돌린다.
        conn.execute("UPDATE sys_book_unit SET key_verse_ref=NULL,"
                     " start_vid=NULL WHERE unit_id=?", (uid,))
        conn.execute("DELETE FROM %s WHERE unit_id=?" % BACKUP, (uid,))
        conn.commit()
        got3 = conn.execute(
            "SELECT COALESCE(key_verse_ref,''), COALESCE(start_vid,0)"
            "  FROM sys_book_unit WHERE unit_id=?", (uid,)).fetchone()
        t('★ 되돌린다', got3 == ('', 0), got3)
        left = conn.execute("SELECT COUNT(*) FROM %s" % BACKUP).fetchone()[0]
        # ★★ **잣대** — 시험 전후로 백업표 행수가 같아야 한다. 이 한 줄이
        #   위의 사고를 잡아낸다(다음에 또 전역 조치를 부르면 여기서 걸린다).
        t('★★ 남의 백업 행을 안 건드린다', left == had, '%d → %d' % (had, left))
    conn.close()
    print('db_book_keyverse selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    c = appdb.connect('bible_master.db')
    if '--undo' in a:
        print('되돌린 편:', undo(c))
        c.close()
        sys.exit(0)
    rows = plan(c)
    agg = {}
    for uid, bc, how, ref, vid, ex in rows:
        d = agg.setdefault(bc, {'QUOTE': 0, 'HEAD': 0, 'ex': []})
        d[how] += 1
        if len(d['ex']) < 2:
            d['ex'].append('%s → %s' % (ex.strip()[:44], ref))
    print('채울 수 있는 편 **%d**' % len(rows))
    for bc, d in sorted(agg.items(), key=lambda x: -(x[1]['QUOTE'] + x[1]['HEAD'])):
        print('  %-18s 인용대조 %4d · 머리약명 %3d' % (bc, d['QUOTE'], d['HEAD']))
        for e in d['ex']:
            print('        %s' % e)
    if '--apply' in a:
        print('채운 편:', apply(c, rows))
    c.close()
