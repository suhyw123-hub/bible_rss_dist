# -*- coding: utf-8 -*-
"""찬양 AI 심사 — 미검토 찬양을 AI(Gemini Flash-Lite)가 판정하고 규칙과 견준다.

docs/1.txt 55번(2026-10-08 사용자 확정 — 「자동승인 / 미심사분 / 라이트로 진행」).

  python db_ai_worship.py --selftest
  python db_ai_worship.py --fulldesc        미검토분 설명문 전문 받기(50편당 1 unit · 배포 표 불변)
  python db_ai_worship.py --run [N]         미검토분을 AI 에 보낸다 — **한도(429)에서 멈춘다** · 멱등
  python db_ai_worship.py --report          품질 분석(_ai_worship_quality.txt)
  python db_ai_worship.py --approve         자동승인 후보 수만 센다(안 바꾼다)
  python db_ai_worship.py --approve --apply 일치분을 승인한다

★ 판정 엔진은 시험 도구 `db_ai_worship_test` 를 그대로 쓴다(프롬프트 3판 · 같은 표).
  두 벌을 두면 시험한 프롬프트와 실제 심사 프롬프트가 갈린다.
★ 「일치」 = AI 가 찬양 갈래(한 곡·이어 부르기·모음·연주)라 보았고 **규칙이 이은 곡
  또는 찬양팀을 AI 도 같은 것으로 짚었다.** 갈래만 같은 것은 일치로 치지 않는다 —
  규칙이 이은 것이 없으면 견줄 것이 없다.
⚠ 승인은 `is_active=1` + 검토중 곡·찬양팀 연결 확정 — 심사 탭 [승인]과 같은 일.
  구절·용어는 2단계 스위치를 따른다.
"""
import os
import sys

import appdb
import db_ai_worship_test as AT

MODEL = 'gemini-3.1-flash-lite'
VER = 'v3'
TAG = '%s/%s' % (MODEL, VER)
GROUPS = (('P', 10 ** 6),)
WORSHIP_KINDS = ('SINGLE', 'MEDLEY', 'PLAYLIST', 'INSTRUMENTAL')
APP = os.path.dirname(os.path.abspath(__file__))


def pending_ids(conn):
    return [m for _g, m in AT.plan(conn, GROUPS)]


def fulldesc(conn, on_log=None):
    """미검토분 가운데 전문이 아직 없는 편만 받는다."""
    AT.ensure(conn)
    have = set(r[0] for r in conn.execute('SELECT media_id FROM %s' % AT.T_DESC))
    mids = [m for m in pending_ids(conn) if m not in have]
    return AT.fetch_full(conn, mids, on_log=on_log), len(mids)


def run(conn, n=10 ** 6, pace=4.5, on_log=None):
    return AT.run(conn, n, model=MODEL, pace=pace, on_log=on_log,
                  groups=GROUPS, ver=VER)


# ── 판정 ──────────────────────────────────────────────────────────────────
def _rule(conn, mid):
    """규칙이 이은 곡(song_id)·찬양팀(artist_id) — 사람이 뗀 HIDE 는 뺀다."""
    songs = set(r[0] for r in conn.execute(
        "SELECT r.song_id FROM sys_link_asset l"
        "  JOIN sys_song_rendition r ON r.rend_id=l.target_id"
        " WHERE l.link_type='MEDI_REND' AND l.clicked_id=?"
        "   AND COALESCE(l.record_status,'LIVE')<>'HIDE'", (mid,)))
    arts = set(r[0] for r in conn.execute(
        "SELECT target_id FROM sys_link_asset WHERE link_type='MEDI_ARTI'"
        "  AND clicked_id=? AND COALESCE(record_status,'LIVE')<>'HIDE'", (mid,)))
    return songs, arts


def verdict(conn, mid, tag=TAG):
    """한 편 → dict(kind, worship, agree, rule_song, rule_arti, ai_song, ai_arti, why)."""
    r = conn.execute('SELECT kind, ok FROM %s WHERE media_id=? AND model=?'
                     % AT.T_RUN, (mid, tag)).fetchone()
    if not r or not r[1]:
        return None
    kind = (r[0] or '').upper()
    ai_song = set(); ai_arti = set(); ai_song_n = 0; ai_arti_n = 0
    for slot, eid, conf, role in conn.execute(
            'SELECT slot, entity_id, conf, lang FROM %s WHERE media_id=? AND model=?'
            % AT.T_ITEM, (mid, tag)):
        if slot == 'SONG':
            ai_song_n += 1
            if eid:
                ai_song.add(eid)
        elif slot == 'ARTI' and (role or '').upper() not in ('CHANNEL', 'LABEL'):
            ai_arti_n += 1
            if eid:
                ai_arti.add(eid)
    rs, ra = _rule(conn, mid)
    worship = kind in WORSHIP_KINDS
    s_ok = bool(rs & ai_song)
    a_ok = bool(ra & ai_arti)
    if not worship:
        cls = 'AI_NOT_WORSHIP'
    elif s_ok or a_ok:
        cls = 'AGREE'
    elif rs or ra:
        cls = 'DISAGREE'          # 규칙이 이은 것을 AI 가 다르게 짚거나 못 짚었다
    else:
        cls = 'NO_RULE'           # 규칙이 이은 곡·팀이 없다 — 견줄 것이 없다
    return {'kind': kind, 'worship': worship, 'cls': cls,
            'song_ok': s_ok, 'arti_ok': a_ok, 'rule_song': rs, 'rule_arti': ra,
            'ai_song': ai_song, 'ai_arti': ai_arti,
            'ai_song_n': ai_song_n, 'ai_arti_n': ai_arti_n}


def judged(conn, tag=TAG):
    """심사를 받은 미검토 편 → [(mid, verdict)]."""
    out = []
    for (mid,) in conn.execute(
            'SELECT t.media_id FROM %s t JOIN sys_media_asset m ON m.media_id=t.media_id'
            ' WHERE t.model=? AND t.ok=1 AND COALESCE(m.is_active,0)=0'
            "   AND COALESCE(m.record_status,'LIVE')='LIVE' AND m.media_type='WORSHIP'"
            % AT.T_RUN, (tag,)).fetchall():
        v = verdict(conn, mid, tag)
        if v:
            out.append((mid, v))
    return out


def approve(conn, apply=False, two_stage=None):
    """일치분을 승인한다 → (후보 수, 승인 수)."""
    ids = [m for m, v in judged(conn) if v['cls'] == 'AGREE']
    if not apply or not ids:
        return len(ids), 0
    if two_stage is None:
        r = conn.execute("SELECT config_val FROM sys_config WHERE config_key="
                         "'WORSHIP_2STAGE'").fetchone()
        two_stage = bool(r) and str(r[0]) == '1'
    ts = ['MEDI_REND', 'MEDI_ARTI'] + ([] if two_stage else ['MEDI_VERS', 'MEDI_ENTI'])
    for i in range(0, len(ids), 500):
        b = ids[i:i + 500]
        q = ','.join('?' * len(b))
        conn.execute('UPDATE sys_media_asset SET is_active=1 WHERE media_id IN (%s)' % q, b)
        conn.execute("UPDATE sys_link_asset SET record_status='LIVE'"
                     " WHERE record_status='PEND' AND clicked_id IN (%s)"
                     "   AND link_type IN (%s)" % (q, ','.join('?' * len(ts))), b + ts)
    conn.commit()
    return len(ids), len(ids)


# ── 품질 분석 ────────────────────────────────────────────────────────────
def report(conn, out_path=None, show=12):
    import collections
    rows = judged(conn)
    L = []
    w = L.append
    sent = conn.execute('SELECT COUNT(*), SUM(ok), SUM(tok_in), SUM(tok_out), AVG(sec)'
                        ' FROM %s WHERE model=?' % AT.T_RUN, (TAG,)).fetchone()
    w('찬양 AI 심사 품질 — 모델 %s' % TAG)
    w('보낸 것 %d · 받은 것 %d · 입력 %s · 출력 %s 토큰 · 한 편 평균 %.1f초'
      % (sent[0] or 0, sent[1] or 0, sent[2] or 0, sent[3] or 0, sent[4] or 0))
    w('미검토 전체 %d편 중 심사 받은 것 %d편' % (len(pending_ids(conn)), len(rows)))
    w('')
    cls = collections.Counter(v['cls'] for _m, v in rows)
    kinds = collections.Counter(v['kind'] or '?' for _m, v in rows)
    w('[판정 갈래]')
    for k, nm in (('AGREE', '일치 — 자동승인 후보'), ('DISAGREE', '규칙과 다름 — 사람'),
                  ('NO_RULE', '규칙이 이은 곡·팀 없음 — 사람'),
                  ('AI_NOT_WORSHIP', 'AI 가 찬양 아님이라 봄 — 사람')):
        w('  %-16s %5d  %s' % (k, cls[k], nm))
    w('[AI 갈래] ' + ' · '.join('%s %d' % kv for kv in kinds.most_common()))
    agree = [v for _m, v in rows if v['cls'] == 'AGREE']
    w('[일치 근거] 곡 %d · 찬양팀 %d · 둘 다 %d'
      % (sum(v['song_ok'] for v in agree), sum(v['arti_ok'] for v in agree),
         sum(v['song_ok'] and v['arti_ok'] for v in agree)))
    has_rs = [v for _m, v in rows if v['rule_song']]
    has_ra = [v for _m, v in rows if v['rule_arti']]
    w('[규칙 곡 연결이 있는 편 %d] AI 가 같은 곡 %d (%.0f%%) · AI 가 곡을 냈지만 우리 목록 밖 %d'
      % (len(has_rs), sum(v['song_ok'] for v in has_rs),
         100.0 * sum(v['song_ok'] for v in has_rs) / max(1, len(has_rs)),
         sum(1 for v in has_rs if not v['song_ok'] and v['ai_song_n'] and not v['ai_song'])))
    w('[규칙 찬양팀 연결이 있는 편 %d] AI 가 같은 팀 %d (%.0f%%)'
      % (len(has_ra), sum(v['arti_ok'] for v in has_ra),
         100.0 * sum(v['arti_ok'] for v in has_ra) / max(1, len(has_ra))))
    nr = [v for _m, v in rows if v['cls'] == 'NO_RULE']
    w('[규칙 없음 %d] AI 가 우리 곡을 짚음 %d · 우리 찬양팀을 짚음 %d · 곡 이름만 냄(새 곡 후보) %d'
      % (len(nr), sum(1 for v in nr if v['ai_song']), sum(1 for v in nr if v['ai_arti']),
         sum(1 for v in nr if v['ai_song_n'] and not v['ai_song'])))
    # 우리 목록 밖 곡·팀 — 등록 후보
    new_s = collections.Counter(); new_a = collections.Counter()
    for val, slot in conn.execute(
            'SELECT i.value, i.slot FROM %s i JOIN sys_media_asset m ON m.media_id=i.media_id'
            " WHERE i.model=? AND i.slot IN ('SONG','ARTI') AND i.entity_id IS NULL"
            "   AND COALESCE(m.is_active,0)=0 AND COALESCE(i.lang,'') NOT IN ('CHANNEL','LABEL')"
            % AT.T_ITEM, (TAG,)):
        (new_s if slot == 'SONG' else new_a)[(val or '').strip()] += 1
    w('[우리 목록 밖] 곡 이름 %d가지 · 찬양팀 %d가지' % (len(new_s), len(new_a)))
    w('  자주 나온 곡: ' + ' · '.join('%s(%d)' % kv for kv in new_s.most_common(15)))
    w('  자주 나온 팀: ' + ' · '.join('%s(%d)' % kv for kv in new_a.most_common(15)))
    # 구절·용어
    vr = conn.execute(
        "SELECT COUNT(*), SUM(CASE WHEN hit='RESOLVED' THEN 1 ELSE 0 END) FROM %s"
        " WHERE model=? AND slot='VERS'" % AT.T_ITEM, (TAG,)).fetchone()
    tr = conn.execute(
        "SELECT COUNT(*), SUM(CASE WHEN COALESCE(hit,'')<>'' THEN 1 ELSE 0 END) FROM %s"
        " WHERE model=? AND slot='TERM'" % AT.T_ITEM, (TAG,)).fetchone()
    w('[구절] AI 낸 것 %d · 좌표로 풀린 것 %d' % (vr[0] or 0, vr[1] or 0))
    w('[용어] AI 낸 것 %d · 우리 용어와 맞은 것 %d' % (tr[0] or 0, tr[1] or 0))
    fails = conn.execute('SELECT why, COUNT(*) FROM %s WHERE model=? AND ok=0 GROUP BY why'
                         % AT.T_RUN, (TAG,)).fetchall()
    if fails:
        w('[실패] ' + ' · '.join('%s ×%d' % ((y or '')[:60], n) for y, n in fails))
    w('')

    def title(mid):
        r = conn.execute('SELECT title FROM sys_media_asset WHERE media_id=?', (mid,)).fetchone()
        return (r[0] if r else '')[:70]

    def names(tbl, ids):
        out = []
        for i in ids:
            r = conn.execute("SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type=?"
                             " ORDER BY lang_code='KO' DESC LIMIT 1", (i, tbl)).fetchone()
            out.append(r[0] if r else str(i))
        return ', '.join(out)

    def ai_vals(mid, slot):
        return ', '.join(r[0] for r in conn.execute(
            'SELECT value FROM %s WHERE media_id=? AND model=? AND slot=?'
            % AT.T_ITEM, (mid, TAG, slot)))

    for k in ('AGREE', 'DISAGREE', 'AI_NOT_WORSHIP', 'NO_RULE'):
        sm = [(m, v) for m, v in rows if v['cls'] == k][:show]
        if not sm:
            continue
        w('── 표본: %s ──' % k)
        for m, v in sm:
            w('  %-6d [%s] %s' % (m, v['kind'], title(m)))
            w('         규칙 곡: %s | 팀: %s' % (names('SONG_TITLE', v['rule_song']) or '-',
                                              names('ARTIST_NAME', v['rule_arti']) or '-'))
            w('         AI  곡: %s | 팀: %s' % (ai_vals(m, 'SONG') or '-', ai_vals(m, 'ARTI') or '-'))
        w('')
    txt = '\n'.join(L)
    out_path = out_path or os.path.join(APP, '_ai_worship_quality.txt')
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(txt)
    return txt


# ── 자가검증 ──────────────────────────────────────────────────────────────
def selftest():
    import sqlite3
    n = [0, 0]

    def ck(c, m):
        n[0] += 1
        if c:
            n[1] += 1
        else:
            print('  FAIL', m)
    c = sqlite3.connect(':memory:')
    c.executescript(
        "CREATE TABLE sys_media_asset(media_id INTEGER, title TEXT, description TEXT,"
        " media_type TEXT, record_status TEXT, is_active INTEGER, url TEXT);"
        "CREATE TABLE sys_link_asset(link_type TEXT, clicked_id INTEGER, target_id INTEGER,"
        " record_status TEXT, source TEXT);"
        "CREATE TABLE sys_song_rendition(rend_id INTEGER, song_id INTEGER, title_key TEXT);"
        "CREATE TABLE sys_config(config_key TEXT, config_val TEXT);")
    AT.ensure(c)
    for mid in (1, 2, 3, 4, 5):
        c.execute("INSERT INTO sys_media_asset VALUES(?,?,'', 'WORSHIP','LIVE',0,'')", (mid, 't%d' % mid))
        c.execute('INSERT INTO %s(media_id,model,ok,kind) VALUES(?,?,1,?)' % AT.T_RUN,
                  (mid, TAG, 'SERMON' if mid == 4 else 'SINGLE'))
    c.execute("INSERT INTO sys_song_rendition VALUES(10,100,'')")
    c.execute("INSERT INTO sys_link_asset VALUES('MEDI_REND',1,10,'PEND','')")   # 1: 같은 곡
    c.execute("INSERT INTO sys_link_asset VALUES('MEDI_REND',2,10,'PEND','')")   # 2: 다른 곡
    c.execute("INSERT INTO sys_link_asset VALUES('MEDI_ARTI',5,7,'HIDE','')")    # 5: 사람이 뗀 팀
    c.execute("INSERT INTO sys_link_asset VALUES('MEDI_VERS',1,99,'PEND','')")
    for mid, slot, eid, role in ((1, 'SONG', 100, ''), (2, 'SONG', 200, ''), (3, 'SONG', None, ''),
                                 (5, 'ARTI', 7, 'TEAM')):
        c.execute('INSERT INTO %s(media_id,slot,value,entity_id,lang,model) VALUES(?,?,?,?,?,?)'
                  % AT.T_ITEM, (mid, slot, 'x', eid, role, TAG))
    v = {m: verdict(c, m)['cls'] for m in (1, 2, 3, 4, 5)}
    ck(v[1] == 'AGREE', '같은 곡 = 일치')
    ck(v[2] == 'DISAGREE', '다른 곡 = 다름')
    ck(v[3] == 'NO_RULE', '규칙 없음')
    ck(v[4] == 'AI_NOT_WORSHIP', '설교 = 찬양 아님')
    ck(v[5] == 'NO_RULE', '사람이 뗀 팀은 견줄 근거가 아니다')
    ck(verdict(c, 9) is None, '안 받은 편 = None')
    ck(approve(c, apply=False) == (1, 0), '센다만 — 안 바꾼다')
    ck(c.execute('SELECT is_active FROM sys_media_asset WHERE media_id=1').fetchone()[0] == 0, '센 뒤 불변')
    ck(approve(c, apply=True, two_stage=True) == (1, 1), '승인')
    ck(c.execute('SELECT is_active FROM sys_media_asset WHERE media_id=1').fetchone()[0] == 1, '승인됨')
    ck(c.execute("SELECT record_status FROM sys_link_asset WHERE link_type='MEDI_REND' AND clicked_id=1"
                 ).fetchone()[0] == 'LIVE', '곡 연결 확정')
    ck(c.execute("SELECT record_status FROM sys_link_asset WHERE link_type='MEDI_VERS'").fetchone()[0]
       == 'PEND', '2단계면 구절은 검토중 그대로')
    ck(c.execute('SELECT is_active FROM sys_media_asset WHERE media_id=2').fetchone()[0] == 0, '다름은 안 건드림')
    ck(AT._sql_of('P').endswith('COALESCE(m.is_active,0)=0'), '미검토 갈래')
    print('db_ai_worship selftest %d/%d' % (n[1], n[0]))
    return n[0] == n[1]


def main(argv):
    if '--selftest' in argv:
        return 0 if selftest() else 1
    conn = appdb.connect(os.path.join(APP, 'bible_master.db'))
    try:
        AT.ensure(conn)
        if '--fulldesc' in argv:
            got, want = fulldesc(conn, on_log=AT._log)
            print('설명문 전문 %d / %d편 (배포 표는 안 건드렸다)' % (got, want))
        elif '--run' in argv:
            i = argv.index('--run')
            n = int(argv[i + 1]) if len(argv) > i + 1 and argv[i + 1].isdigit() else 10 ** 6
            r = run(conn, n, on_log=AT._log)
            print('보냄 %d · 받음 %d · 남은 미검토 %d' % (r['sent'], r['ok'], r.get('left', -1)))
            if r['why']:
                print('멈춘 사유: %s' % r['why'][:200])
        elif '--report' in argv:
            print(report(conn))
        elif '--approve' in argv:
            a, b = approve(conn, apply='--apply' in argv)
            print('자동승인 후보 %d편 · 승인 %d편' % (a, b))
        else:
            print(__doc__)
    finally:
        conn.close()
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
