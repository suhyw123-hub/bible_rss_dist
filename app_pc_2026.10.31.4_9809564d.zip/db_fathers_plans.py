# -*- coding: utf-8 -*-
"""db_fathers_plans.py — 사도교부 도서묵상 플랜 5종 (영구 도구).

2026-08-18 사용자 지시 「이미 적재한 것들을 도서묵상 플랜으로 만들자.
본문이 짧으면 연결된 구절들을 풍성하게 확보하라」.
db_sw_aog_plans 와 같은 틀 — 하루 = BOOK_TEXT + CORE (+SUPPORT), §17-5.

  python db_fathers_plans.py --selftest      # 의무 (실 DB 트랜잭션 롤백)
  python db_fathers_plans.py --apply DIDACHE|DIOGNETUS|MARTYRS|HERMAS|CLEMENT

  · 디다케(16일)·디오그네투스 서신(12일)·순교자의 편지(9일 = 이그나티우스
    7 + 폴리캅 서신 + 순교록 — **플랜 하나가 도서 둘을 가로지른다**) ·
    헤르마스의 목자(27일) · 클레멘트 1서(66일 = 서두+65장).
  · CORE 는 그 장이 인용·강해하는 본문에서 골랐고(클레멘트는 66장 서두
    전수 대조로 검증 — 4장=신 32:15 인용, 32장=이신칭의, 47장=고전 1 등),
    짧은 장(디다케 등)은 SUPPORT 를 더해 구절을 풍성하게 했다.
  · 멱등 — 재실행 시 스케줄만 다시 깔고 plan_id·unit_id 불변.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(HERE, 'bible_master.db')
sys.path.insert(0, HERE)
import appdb
import scripture_ref_kr


def _upsert_text(c, tt, cid, lang, val):
    row = c.execute(
        "SELECT sys_text_id FROM sys_text_asset WHERE text_type=? AND "
        "clicked_id=? AND UPPER(lang_code)=?", (tt, cid, lang)).fetchone()
    if row:
        c.execute("UPDATE sys_text_asset SET contents=?, title=?, "
                  "record_status='LIVE' WHERE sys_text_id=?",
                  (val, val, row[0]))
    else:
        c.execute("INSERT INTO sys_text_asset (text_type, clicked_id, "
                  "lang_code, title, contents, record_status) "
                  "VALUES (?,?,?,?,?,'LIVE')", (tt, cid, lang, val, val))


# day = (book_code, sequence, core_ref, support_ref|None, focus)
_DID = 'DIDACHE'
_DIO = 'DIOGNETUS'
_IGN = 'IGNATIUS_LETTERS'
_POL = 'POLYCARP_PHIL'
_HER = 'HERMAS_SHEPHERD'
_CLE = 'CLEMENT_1ST'

PLANS = {
 'DIDACHE': dict(
  code='FATHERS_DIDACHE_16D',
  titles={'KO': '디다케', 'EN': 'The Didache'},
  descs={'KO': '가장 오래된 교회 생활 지침서를 하루 한 장씩, 그 장이 딛고 '
               '있는 성경 본문과 함께 읽습니다.',
         'EN': 'The earliest church manual, one chapter a day with its '
               'scriptures.'},
  days=[
   (_DID, 1, '마 22:37-39', '마 5:44-46',
    '두 길의 첫걸음은 하나님 사랑과 이웃 사랑, 원수 사랑까지입니다.'),
   (_DID, 2, '출 20:13-17', '마 19:18-19',
    '생명의 길은 십계명의 둘째 돌판을 삶으로 풀어냅니다.'),
   (_DID, 3, '마 5:5', '잠 3:34',
    '온유한 자가 땅을 기업으로 받는다는 약속이 이 장의 중심입니다.'),
   (_DID, 4, '행 4:32-35', '신 15:7-8',
    '내 것을 움켜쥐지 않는 나눔이 생명의 길의 살림살이입니다.'),
   (_DID, 5, '롬 1:28-32', '잠 6:16-19',
    '사망의 길 목록은 로마서의 죄 목록과 나란히 읽힙니다.'),
   (_DID, 6, '마 11:29-30', '고전 10:13',
    '질 수 있는 만큼 지라는 권면이 주님의 멍에로 이어집니다.'),
   (_DID, 7, '마 28:19-20', '겔 36:25-27',
    '세례 규례는 주님의 지상명령을 그대로 실행합니다.'),
   (_DID, 8, '마 6:9-13', '마 6:16-18',
    '초대교회는 이 기도를 하루 세 번 드렸습니다.'),
   (_DID, 9, '고전 10:16-17', '요 6:35',
    '흩어진 밀이 한 떡이 되듯 교회가 하나로 모이는 성찬 감사입니다.'),
   (_DID, 10, '계 22:20', '시 103:1-2',
    '식후 감사는 마라나타, 주여 오시옵소서로 끝납니다.'),
   (_DID, 11, '마 7:15-16', '요일 4:1',
    '찾아오는 교사를 열매로 시험하라는 분별의 지혜입니다.'),
   (_DID, 12, '살후 3:10', '엡 4:28',
    '일하지 않으려는 자는 분별하되 나그네는 도우라 합니다.'),
   (_DID, 13, '딤전 5:17-18', '신 26:1-2',
    '참 선지자는 삯을 받을 자격이 있습니다. 첫 소산의 원리입니다.'),
   (_DID, 14, '마 5:23-24', '말 1:11',
    '주일 예배 전에 먼저 화해하라, 말라기의 정결한 제사입니다.'),
   (_DID, 15, '딤전 3:8-10', '빌 1:1',
    '감독과 집사를 세우는 규례가 목회서신과 이어집니다.'),
   (_DID, 16, '마 24:42-44', '살전 5:2-6',
    '깨어 있으라. 마지막 장은 재림 대비로 끝납니다.'),
  ]),
 'DIOGNETUS': dict(
  code='FATHERS_DIOGNETUS_12D',
  titles={'KO': '디오그네투스 서신', 'EN': 'To Diognetus'},
  descs={'KO': '초기 기독교 변증서의 백미를 하루 한 장씩 읽습니다. 세상 속 '
               '그리스도인(5~6장)과 달콤한 교환(9장)이 기다립니다.',
         'EN': 'The gem of early Christian apologetics, one chapter a day.'},
  days=[
   (_DIO, 1, '벧전 3:15', None,
    '변증은 묻는 자에게 소망의 이유를 대답하는 데서 시작합니다.'),
   (_DIO, 2, '시 115:4-8', '사 44:9-11',
    '손으로 만든 우상은 눈이 있어도 보지 못합니다.'),
   (_DIO, 3, '사 1:11-13', '호 6:6',
    '하나님은 제물이 아니라 긍휼을 원하십니다.'),
   (_DIO, 4, '골 2:16-17', None,
    '절기와 규례는 그림자요 몸은 그리스도의 것입니다.'),
   (_DIO, 5, '요 17:14-16', '빌 3:20',
    '세상 안에 있으나 세상에 속하지 않은 사람들, 그리스도인의 초상입니다.'),
   (_DIO, 6, '마 5:13-14', '고후 6:8-10',
    '영혼이 몸에 대해 그러하듯 그리스도인은 세상의 영혼입니다.'),
   (_DIO, 7, '요 3:17', None,
    '하나님은 강압이 아니라 설득으로, 심판이 아니라 구원으로 아들을 '
    '보내셨습니다.'),
   (_DIO, 8, '마 11:27', None,
    '아들이 계시하시기 전에는 아무도 하나님을 알지 못했습니다.'),
   (_DIO, 9, '고후 5:21', '롬 5:8',
    '오 달콤한 교환이여. 한 의인의 의가 많은 죄인을 의롭게 합니다.'),
   (_DIO, 10, '요일 4:9-11', None,
    '먼저 사랑하신 하나님을 본받는 사람이 이웃에게 하나님이 어떤 분인지 '
    '보여 줍니다.'),
   (_DIO, 11, '요 1:1-4', None,
    '처음부터 계신 말씀이 오늘도 제자들의 마음에 은혜로 말씀하십니다.'),
   (_DIO, 12, '창 2:9', '고전 8:1',
    '지식과 생명이 한 동산에 심겼습니다. 사랑 없는 지식은 세우지 '
    '못합니다.'),
  ]),
 'MARTYRS': dict(
  code='FATHERS_MARTYRS_9D',
  titles={'KO': '순교자의 편지', 'EN': 'Letters of the Martyrs'},
  descs={'KO': '순교길의 이그나티우스가 남긴 일곱 편지와, 그 편지를 받았던 '
               '폴리캅의 서신과 순교 기록을 아흐레 동안 읽습니다.',
         'EN': "Ignatius' seven letters on the road to martyrdom, then "
               "Polycarp's epistle and martyrdom."},
  days=[
   (_IGN, 1, '엡 4:3-6', None,
    '에베소 교회에게, 하나 됨을 힘써 지키라는 권면입니다.'),
   (_IGN, 2, '요 17:21', None,
    '수는 적어도 참되게 하나 되라고 마그네시아에 씁니다.'),
   (_IGN, 3, '요일 4:2-3', None,
    '예수님이 참으로 오시고 참으로 죽으셨다는 고백이 이단을 가립니다.'),
   (_IGN, 4, '빌 1:21-23', None,
    '사는 것이 그리스도니 죽는 것도 유익하다는 고백의 실물입니다.'),
   (_IGN, 5, '고전 1:10', None,
    '분열 앞에서 한 마음 한 뜻을 호소합니다.'),
   (_IGN, 6, '눅 24:39', None,
    '부활하신 주님은 살과 뼈를 가지셨습니다. 서머나에 보낸 확언입니다.'),
   (_IGN, 7, '딤후 4:2-5', '벧전 5:2-3',
    '순교를 앞둔 감독이 젊은 감독에게, 때를 얻든지 못 얻든지.'),
   (_POL, 1, '벧전 1:8', None,
    '보지 못하였으나 사랑하는 믿음, 폴리캅이 가장 아낀 말씀입니다.'),
   (_POL, 2, '계 2:10', None,
    '죽도록 충성하라는 말씀은 바로 서머나 교회에 주신 것이었습니다.'),
  ]),
 'HERMAS': dict(
  code='FATHERS_HERMAS_27D',
  titles={'KO': '헤르마스의 목자', 'EN': 'The Shepherd of Hermas'},
  descs={'KO': '초대교회가 사랑한 환상과 계명과 비유를 하루 하나씩, 성경 '
               '본문으로 검증하며 읽습니다.',
         'EN': 'Visions, mandates and parables, one a day, tested by '
               'Scripture.'},
  days=[
   (_HER, 1, '시 90:8', None,
    '숨은 생각까지 아시는 하나님 앞에서 첫 환상이 시작됩니다.'),
   (_HER, 2, '욜 2:12-13', None,
    '회개의 기회가 아직 열려 있다는 소식이 두루마리에 담겼습니다.'),
   (_HER, 3, '벧전 2:4-5', None,
    '산 돌들로 세워지는 탑, 교회의 환상입니다.'),
   (_HER, 4, '시 91:1-4', None,
    '큰 짐승 앞에서도 믿음으로 지나가는 자를 하나님이 지키십니다.'),
   (_HER, 5, '시 23:1', None,
    '목자가 나타나 계명과 비유를 받아 적게 합니다.'),
   (_HER, 6, '히 11:6', None,
    '먼저 하나님이 한 분이심을 믿으라. 모든 계명의 문입니다.'),
   (_HER, 7, '약 4:11', None, '단순함을 지키고 험담을 버리라 합니다.'),
   (_HER, 8, '엡 4:25', None,
    '진실을 사랑하라. 거짓은 주님의 영과 상관이 없습니다.'),
   (_HER, 9, '마 5:27-28', None, '정결과 회개, 목자의 넷째 계명입니다.'),
   (_HER, 10, '엡 4:30-31', '갈 5:22-23',
    '성급한 분노는 내주하시는 성령을 좁은 방에 가둡니다.'),
   (_HER, 11, '요일 4:1', None,
    '두 길의 천사를 분별하라, 마음을 살피는 법입니다.'),
   (_HER, 12, '잠 9:10', None,
    '주를 경외하고 마귀는 두려워하지 말라 합니다.'),
   (_HER, 13, '딛 2:11-12', None,
    '악은 절제하고 선은 절제하지 말라, 두 방향의 절제입니다.'),
   (_HER, 14, '약 1:5-8', '막 11:24',
    '의심을 버리고 구하라. 야고보서와 같은 소리입니다.'),
   (_HER, 15, '빌 4:6-7', None,
    '근심은 기도를 어둡게 합니다. 아뢰는 자에게 평강이 옵니다.'),
   (_HER, 16, '마 7:15-20', None,
    '거짓 선지자와 참 선지자를 삶의 열매로 가립니다.'),
   (_HER, 17, '요일 5:3', None,
    '그분의 계명은 무겁지 않습니다. 지킬 수 있다고 목자가 말합니다.'),
   (_HER, 18, '히 11:13-16', None,
    '이 성이 아니라 장차 올 성을 바라보는 나그네의 비유입니다.'),
   (_HER, 19, '딤전 6:17-19', '고후 9:8-11',
    '느릅나무와 포도나무, 부자와 가난한 자가 서로를 살립니다.'),
   (_HER, 20, '마 13:29-30', None,
    '겨울나무는 겉으로 같아 보입니다. 구별은 아직 감춰져 있습니다.'),
   (_HER, 21, '말 3:18', None,
    '여름이 오면 잎으로 드러나듯 그 날에는 의인과 악인이 구별됩니다.'),
   (_HER, 22, '사 58:6-7', None,
    '참 금식은 규례가 아니라 마음과 섬김의 금식입니다.'),
   (_HER, 23, '히 12:11', None,
    '잠깐의 사치와 그 값, 징계는 회복을 위한 것입니다.'),
   (_HER, 24, '벧전 1:6-7', None,
    '잠시 여러 시험으로 근심하게 되는 까닭을 목자가 설명합니다.'),
   (_HER, 25, '요 15:5-6', None,
    '버드나무 가지를 돌려드리는 날, 푸른 가지와 마른 가지가 갈립니다.'),
   (_HER, 26, '엡 2:19-22', None,
    '열두 산의 돌들이 한 탑으로, 온 교회가 한 성전으로 지어져 갑니다.'),
   (_HER, 27, '마 7:24-25', None,
    '들은 계명을 행하는 사람이 반석 위에 집을 짓습니다.'),
  ]),
 'CLEMENT': dict(
  code='FATHERS_CLEMENT_66D',
  titles={'KO': '클레멘트 1서', 'EN': 'First Clement'},
  descs={'KO': '신약 이후 가장 이른 교회의 편지를 하루 한 장씩, 각 장이 '
               '인용하는 성경 본문과 함께 읽습니다.',
         'EN': "The church's earliest letter after the NT, one chapter a "
               'day with its scriptures.'},
  days=[
   (_CLE, 1, '고전 1:2-3', None,
    '같은 고린도 교회에 다시 은혜와 평강을 비는 인사입니다.'),
   (_CLE, 2, '롬 1:8', None,
    '너희 믿음이 온 세상에 전파되었다던 그 교회의 이야기입니다.'),
   (_CLE, 3, '행 20:35', None, '받기보다 주기를 기뻐하던 시절을 회상합니다.'),
   (_CLE, 4, '신 32:15', None,
    '풍족함이 발길질로 변한 자리를 신명기가 그대로 짚습니다.'),
   (_CLE, 5, '창 4:3-8', None, '시기가 형제 살인까지 간 첫 사례, 가인입니다.'),
   (_CLE, 6, '딤후 4:6-8', None,
    '가장 가까운 시대의 승리자들, 베드로와 바울의 순교입니다.'),
   (_CLE, 7, '히 11:36-38', None,
    '이름 없는 순교자들의 큰 무리가 함께 기억됩니다.'),
   (_CLE, 8, '욘 3:4-5', '벧후 3:9',
    '노아와 요나, 회개를 전한 이들의 계보입니다.'),
   (_CLE, 9, '겔 33:11', None,
    '악인의 죽음을 기뻐하지 않으신다는 말씀 그대로입니다.'),
   (_CLE, 10, '히 11:5-7', None,
    '순종으로 하나님을 기쁘시게 한 에녹과 노아입니다.'),
   (_CLE, 11, '창 12:1-4', None, '벗이라 불린 아브라함의 순종입니다.'),
   (_CLE, 12, '창 19:15-16', None,
    '환대와 경건으로 소돔에서 건짐받은 롯입니다.'),
   (_CLE, 13, '히 11:31', None,
    '믿음과 환대로 구원받은 라합, 붉은 줄의 표징까지 이어집니다.'),
   (_CLE, 14, '렘 9:23-24', None,
    '자랑하려거든 주를 아는 것으로 자랑하라 합니다.'),
   (_CLE, 15, '행 5:29', None,
    '교만한 무리가 아니라 하나님께 순종하는 것이 마땅합니다.'),
   (_CLE, 16, '사 29:13', None,
    '입술로는 공경하나 마음은 먼 자들을 경계합니다.'),
   (_CLE, 17, '사 53:2-6', None,
    '이사야 53장이 이 장에 통째로 인용됩니다. 그리스도의 겸손입니다.'),
   (_CLE, 18, '창 18:27', None,
    '나는 티끌과 재라던 아브라함처럼, 선지자들의 겸손입니다.'),
   (_CLE, 19, '시 51:1-4', None, '다윗의 회개 시가 그대로 인용됩니다.'),
   (_CLE, 20, '시 34:14', None,
    '악에서 떠나 선을 행하며 화평을 찾아 따르는 길입니다.'),
   (_CLE, 21, '시 19:1-4', None,
    '하늘과 낮과 밤이 화평 가운데 순종하는 창조의 질서입니다.'),
   (_CLE, 22, '잠 20:27', None,
    '사람의 영은 여호와의 등불이라, 은혜를 심판으로 바꾸지 말라 합니다.'),
   (_CLE, 23, '시 34:11-14', None,
    '자녀들아 와서 들으라, 시편 34편의 초청입니다.'),
   (_CLE, 24, '말 3:1', '합 2:3',
    '주께서 홀연히 그 전에 임하신다는 약속을 의심하지 말라 합니다.'),
   (_CLE, 25, '고전 15:36-38', None,
    '밤과 낮과 씨앗이 날마다 부활을 보여 줍니다.'),
   (_CLE, 26, '고전 15:42-44', None,
    '전설의 새마저 부활의 그림으로 읽던 초대교회입니다. 예화임을 '
    '기억하며 읽습니다.'),
   (_CLE, 27, '욥 19:25-26', None,
    '내 구속자가 살아 계시니, 부활 소망의 본문입니다.'),
   (_CLE, 28, '히 6:17-18', None,
    '거짓말하실 수 없는 하나님께 소망을 겁니다.'),
   (_CLE, 29, '시 139:7-10', None, '주의 신을 떠나 어디로 가리이까.'),
   (_CLE, 30, '딤전 2:8', None, '거룩한 손을 들고 나아가는 예배입니다.'),
   (_CLE, 31, '약 4:6', None,
    '하나님은 교만한 자를 물리치시고 겸손한 자에게 은혜를 주십니다.'),
   (_CLE, 32, '창 22:17-18', None, '순종의 자리에서 복이 이어집니다.'),
   (_CLE, 33, '롬 3:27-28', '갈 2:16',
    '우리도 행위가 아니라 믿음으로 의롭다 함을 받는다고 선언합니다.'),
   (_CLE, 34, '엡 2:10', '창 1:26-28',
    '그러니 선행을 멈추자는 말이 아닙니다. 창조부터 하나님이 일하십니다.'),
   (_CLE, 35, '고전 2:9', None,
    '눈으로 보지 못한 것을 예비하셨다는 바로 그 구절입니다.'),
   (_CLE, 36, '시 50:23', None, '감사로 제사를 드리는 자가 구원을 봅니다.'),
   (_CLE, 37, '히 1:3-4', None,
    '우리 구원의 길이신 대제사장 예수 그리스도, 히브리서 1장의 '
    '인용입니다.'),
   (_CLE, 38, '딤후 2:3-4', None,
    '군대의 질서처럼 각자 자기 자리에서 명령을 따릅니다.'),
   (_CLE, 39, '고전 12:12', None,
    '큰 지체와 작은 지체가 한 몸에서 서로를 필요로 합니다.'),
   (_CLE, 40, '욥 4:17-19', None,
    '사람이 하나님보다 의로울 수 있느냐, 욥기의 물음입니다.'),
   (_CLE, 41, '고전 14:40', None,
    '모든 것을 품위 있게 하고 질서대로 하라.'),
   (_CLE, 42, '롬 12:4-5', None,
    '각자 자기 자리에서 감사하며 정한 규례를 넘지 않습니다.'),
   (_CLE, 43, '행 14:23', None,
    '사도들이 각 교회에 감독과 집사를 세운 내력입니다.'),
   (_CLE, 44, '민 17:8', None,
    '아론의 싹 난 지팡이, 직분 시비를 끝내신 방식입니다.'),
   (_CLE, 45, '딤전 5:17', None,
    '흠 없이 섬긴 장로들을 내치는 것은 작은 죄가 아니라 합니다.'),
   (_CLE, 46, '단 6:16-22', None,
    '의인이 박해받은 것은 악인들의 손에서였습니다. 다니엘의 사자굴입니다.'),
   (_CLE, 47, '엡 4:4-6', None,
    '한 하나님, 한 그리스도, 한 성령. 그런데 왜 나뉩니까.'),
   (_CLE, 48, '고전 1:10-13', None,
    '복된 사도 바울의 편지를 다시 들라, 그때도 파당이 문제였습니다.'),
   (_CLE, 49, '시 118:19-20', None,
    '의의 문들을 열라, 사랑의 문으로 들어갑니다.'),
   (_CLE, 50, '고전 13:4-7', None,
    '사랑은 오래 참고 온유하며, 클레멘트의 사랑 찬가입니다.'),
   (_CLE, 51, '시 32:1-2', None,
    '허물의 사함을 받은 자의 복이 사랑 안에서 온전해집니다.'),
   (_CLE, 52, '잠 28:13', None,
    '죄를 숨기는 자는 형통치 못하나 자복하는 자는 긍휼을 얻습니다.'),
   (_CLE, 53, '시 69:30-31', None,
    '하나님이 원하시는 것은 소가 아니라 감사와 자백입니다.'),
   (_CLE, 54, '출 32:31-32', None,
    '주의 책에서 나를 지워 달라던 모세의 중보입니다.'),
   (_CLE, 55, '빌 2:3-4', None,
    '누가 공동체를 위해 스스로 떠나겠는가, 자기를 낮추는 사랑입니다.'),
   (_CLE, 56, '에 4:16', None,
    '죽으면 죽으리이다, 백성을 위해 자기를 건 에스더입니다.'),
   (_CLE, 57, '잠 3:11-12', None,
    '여호와의 징계를 경히 여기지 말라, 사랑하시는 자를 징계하십니다.'),
   (_CLE, 58, '벧전 5:5', None,
    '분쟁을 일으킨 이들에게, 장로들에게 순복하라 권합니다.'),
   (_CLE, 59, '신 30:19-20', None,
    '생명을 택하라, 그 이름에 순종하는 자가 삽니다.'),
   (_CLE, 60, '시 121:1-2', None,
    '편지 끝의 큰 기도가 시작됩니다. 도움이 어디서 오는가.'),
   (_CLE, 61, '시 145:8-9', None,
    '은혜롭고 긍휼이 많으신 창조주께 용서를 구하는 기도입니다.'),
   (_CLE, 62, '딤전 2:1-2', None,
    '임금들과 높은 지위에 있는 자들을 위한 기도, 그대로입니다.'),
   (_CLE, 63, '미 6:8', None,
    '여호와께서 구하시는 것, 편지 전체의 요약입니다.'),
   (_CLE, 64, '히 13:17', None,
    '너희를 인도하는 자들에게 순종하고 복종하라.'),
   (_CLE, 65, '민 6:24-26', None, '아론의 축복으로 축복하며 마칩니다.'),
   (_CLE, 66, '유 1:24-25', None,
    '사절을 보내며 영광의 송영으로 편지를 닫습니다.'),
  ]),
}


def apply(conn, which, verbose=True):
    p = PLANS[which]
    c = conn
    bm = scripture_ref_kr.book_map_ko(c)
    bids = {}

    def bid(code):
        if code not in bids:
            bids[code] = c.execute('SELECT book_id FROM sys_book_asset '
                                   'WHERE book_code=?', (code,)).fetchone()[0]
        return bids[code]

    # ① 구절 해석 + 유닛 key_verse
    rows = []           # (day, unit_id, core(a,b), support(a,b)|None, focus)
    for day, (code, seq, core, sup, focus) in enumerate(p['days'], 1):
        a, b = scripture_ref_kr.resolve(c, core, bm)
        if a is None:
            raise SystemExit('구절 해석 실패: %s' % core)
        s = None
        if sup:
            sa, sb = scripture_ref_kr.resolve(c, sup, bm)
            if sa is None:
                raise SystemExit('구절 해석 실패: %s' % sup)
            s = (sa, sb)
        uid = c.execute('SELECT unit_id FROM sys_book_unit WHERE book_id=? '
                        'AND sequence=?', (bid(code), seq)).fetchone()[0]
        c.execute('UPDATE sys_book_unit SET key_verse_ref=?, start_vid=?, '
                  'end_vid=? WHERE unit_id=?', (core, a, b, uid))
        rows.append((day, uid, (a, b), s, focus))

    # ② 카테고리(cat 4 아래, 플랜 하나 = 묶음 이름)
    row = c.execute("""SELECT t.clicked_id FROM sys_text_asset t
        JOIN sys_plan_category pc ON pc.cat_id=t.clicked_id
        WHERE t.text_type='PLAN_CAT_NAME' AND t.contents=? AND
        t.lang_code='KO' AND pc.parent_id=4 LIMIT 1""",
        (p['titles']['KO'],)).fetchone()
    if row:
        cat_id = row[0]
    else:
        cat_id = c.execute('SELECT COALESCE(MAX(cat_id),0)+1 FROM '
                           'sys_plan_category').fetchone()[0]
        so = c.execute('SELECT COALESCE(MAX(sort_order),0)+10 FROM '
                       'sys_plan_category WHERE parent_id=4').fetchone()[0]
        c.execute("INSERT INTO sys_plan_category (cat_id, parent_id, "
                  "sort_order, record_status, scope) "
                  "VALUES (?,4,?,'LIVE','BOOK')", (cat_id, so))
    for lg in ('KO', 'EN'):
        _upsert_text(c, 'PLAN_CAT_NAME', cat_id, lg, p['titles'][lg])

    # ③ 플랜
    row = c.execute('SELECT plan_id FROM sys_bible_plan WHERE plan_code=?',
                    (p['code'],)).fetchone()
    days = len(p['days'])
    if row:
        plan_id = row[0]
        c.execute("UPDATE sys_bible_plan SET plan_type='BOOK_BASED', "
                  "plan_category='THEMATIC', duration_days=?, track_count=1, "
                  "cat_id=?, record_status='LIVE' WHERE plan_id=?",
                  (days, cat_id, plan_id))
    else:
        cur = c.execute("""INSERT INTO sys_bible_plan (plan_code, plan_type,
                     duration_days, track_count, record_status,
                     plan_category, cat_id)
                     VALUES (?,'BOOK_BASED',?,1,'LIVE','THEMATIC',?)""",
                        (p['code'], days, cat_id))
        plan_id = cur.lastrowid
    for lg in ('KO', 'EN'):
        _upsert_text(c, 'PLAN_TITLE', plan_id, lg, p['titles'][lg])
        _upsert_text(c, 'PLAN_DESC', plan_id, lg, p['descs'][lg])

    # ④ 스케줄 — BOOK_TEXT(포커스) + CORE (+SUPPORT)
    c.execute('DELETE FROM sys_plan_schedule WHERE plan_id=?', (plan_id,))
    for day, uid, (a, b), s, focus in rows:
        c.execute("INSERT INTO sys_plan_schedule (plan_id, day, track, "
                  "start_vid, end_vid, stage_type, sort_order, unit_key, "
                  "meditation_focus) VALUES (?,?,1,?,?,'BOOK_TEXT',1,?,?)",
                  (plan_id, day, a, b, 'BOOK_%d' % uid, focus))
        c.execute("INSERT INTO sys_plan_schedule (plan_id, day, track, "
                  "start_vid, end_vid, stage_type, sort_order) "
                  "VALUES (?,?,1,?,?,'CORE',2)", (plan_id, day, a, b))
        if s:
            c.execute("INSERT INTO sys_plan_schedule (plan_id, day, track, "
                      "start_vid, end_vid, stage_type, sort_order) "
                      "VALUES (?,?,1,?,?,'SUPPORT',3)",
                      (plan_id, day, s[0], s[1]))
    if verbose:
        ns = c.execute('SELECT COUNT(*) FROM sys_plan_schedule WHERE '
                       'plan_id=?', (plan_id,)).fetchone()[0]
        print('플랜 %s(plan_id %d, cat %d) %d일 · 스케줄 %d행'
              % (p['code'], plan_id, cat_id, days, ns))
    return plan_id, cat_id


def selftest():
    """실 DB 트랜잭션 롤백 — 흔적 없음. 행수는 전후 비교(§0-5 상태 함정)."""
    ok = True

    def t(name, cond):
        nonlocal ok
        print('%s %s' % ('✓' if cond else '✗', name))
        ok = ok and cond

    conn = appdb.connect(DB)
    before = conn.execute('SELECT COUNT(*) FROM sys_plan_schedule').fetchone()[0]
    try:
        conn.execute('BEGIN')
        for which in PLANS:
            plan_id, cat_id = apply(conn, which, verbose=False)
            days = len(PLANS[which]['days'])
            rows = conn.execute(
                "SELECT day, stage_type, start_vid, meditation_focus, "
                "unit_key FROM sys_plan_schedule WHERE plan_id=? "
                "ORDER BY day, sort_order", (plan_id,)).fetchall()
            n_sup = sum(1 for r in rows if r[1] == 'SUPPORT')
            t('%s %d일·행 %d(=일×2+보조 %d)' % (which, days, len(rows), n_sup),
              len(rows) == days * 2 + n_sup)
            t('%s 일 연속·vid·포커스' % which,
              sorted({r[0] for r in rows}) == list(range(1, days + 1))
              and all(r[2] for r in rows)
              and all((r[3] or '').strip() and '—' not in r[3]
                      for r in rows if r[1] == 'BOOK_TEXT'))
            t('%s BOOK_TEXT 전부 unit_key' % which,
              all(r[4] for r in rows if r[1] == 'BOOK_TEXT'))
            title = conn.execute(
                "SELECT contents FROM sys_text_asset WHERE "
                "text_type='PLAN_TITLE' AND clicked_id=? AND lang_code='KO'",
                (plan_id,)).fetchone()[0]
            t('%s 제목 규칙(10자·대시 없음)' % which,
              len(title) <= 10 and '—' not in title and '-' not in title)
            p2, c2 = apply(conn, which, verbose=False)
            t('%s 멱등' % which, (p2, c2) == (plan_id, cat_id))
        # 순교자 플랜 — 두 도서를 가로지르는 unit_key 검증
        mrows = conn.execute("""SELECT s.unit_key FROM sys_plan_schedule s
            JOIN sys_bible_plan p ON p.plan_id=s.plan_id
            WHERE p.plan_code='FATHERS_MARTYRS_9D' AND s.stage_type='BOOK_TEXT'
            ORDER BY s.day""").fetchall()
        codes = set()
        for (uk,) in mrows:
            codes.add(conn.execute(
                "SELECT b.book_code FROM sys_book_unit u JOIN sys_book_asset "
                "b ON b.book_id=u.book_id WHERE u.unit_id=?",
                (int(uk[5:]),)).fetchone()[0])
        t('순교자 플랜이 두 도서를 가로지름',
          codes == {'IGNATIUS_LETTERS', 'POLYCARP_PHIL'})
    finally:
        conn.rollback()
        conn.close()
    conn = appdb.connect(DB)
    try:
        after = conn.execute('SELECT COUNT(*) FROM sys_plan_schedule').fetchone()[0]
        t('롤백 — 실 DB 무변화(%d행 유지)' % before, after == before)
    finally:
        conn.close()
    print('selftest', 'OK' if ok else 'FAIL')
    return ok


if __name__ == '__main__':
    a = sys.argv[1:]
    if not a or a[0] == '--selftest':
        sys.exit(0 if selftest() else 1)
    if a[0] == '--apply' and len(a) >= 2 and a[1].upper() in PLANS:
        conn = appdb.connect(DB)
        try:
            apply(conn, a[1].upper())
            conn.commit()
        finally:
            conn.close()
        sys.exit(0)
    print(__doc__)
