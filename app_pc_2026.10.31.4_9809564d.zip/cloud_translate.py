# -*- coding: utf-8 -*-
"""cloud_translate.py — 공식 Google Cloud Translation API(v2) 클라이언트 (관리자 전용).

방식 A: 관리자가 items.tsv 빌드 시 제목을 11개 UI 언어로 미리 번역 → 배포.
  - **키는 관리자 PC(app_state_admin.json)에만** 저장. 사용자 앱은 이 모듈을 절대 import 안 함.
  - 같은 제목은 관리자 로컬 캐시(admin_xl_cache.db)로 1회만 번역 → API 비용 최소화.
  - 'Powered by Google Translate' 고지는 사용자 화면에 표시(reading_news_view).
공식 약관 준수: 정식 v2 엔드포인트 사용(비공식 gtx 아님). 데이터는 학습에 사용되지 않음.
"""
import os
import json
import hashlib
import sqlite3
import urllib.request
import urllib.parse

API_URL = "https://translation.googleapis.com/language/translate/v2"
_TIMEOUT = 20
_BATCH = 64   # 한 요청에 보낼 제목 수(요청 수 절감)

# 11 UI 언어 → Google ISO 코드
LANG_ISO = {
    'KO': 'ko', 'EN': 'en', 'ZH': 'zh-CN', 'ZHT': 'zh-TW', 'JA': 'ja',
    'DE': 'de', 'FR': 'fr', 'ES': 'es', 'AR': 'ar', 'RU': 'ru', 'PT': 'pt',
}
UI_LANGS = list(LANG_ISO.keys())

_CACHE_PATH = os.path.join(os.path.dirname(__file__), 'admin_xl_cache.db')


# ── 관리자 로컬 번역 캐시 (배포 안 됨) ──────────────────────────────
def _cache_conn():
    c = sqlite3.connect(_CACHE_PATH)
    c.execute("CREATE TABLE IF NOT EXISTS xl ("
              " h TEXT NOT NULL, lang TEXT NOT NULL, dst TEXT,"
              " PRIMARY KEY(h, lang))")
    cols = {r[1] for r in c.execute('PRAGMA table_info(xl)')}
    if 'src' not in cols:
        c.execute("ALTER TABLE xl ADD COLUMN src TEXT")   # ★ 2026-10-22 누가 옮겼나 — GOOGLE · GEMINI(옛 줄은 빈칸 = 구글)
    # ★ 2026-10-22 번역 대기열 — 모인 제목을 차례 번호로 쌓는다. [번역하기]는 마지막으로 끝낸 번호 다음부터 모아 한 번에 보낸다.
    c.execute("CREATE TABLE IF NOT EXISTS xl_q ("
              " id INTEGER PRIMARY KEY AUTOINCREMENT, h TEXT NOT NULL UNIQUE,"
              " title TEXT NOT NULL, lang TEXT NOT NULL, added_at TEXT)")
    qcols = {r[1] for r in c.execute('PRAGMA table_info(xl_q)')}
    if 'kind' not in qcols:
        c.execute("ALTER TABLE xl_q ADD COLUMN kind TEXT")   # ★ 2026-10-22 갈래 — NEWS · DEVOTIONAL · YOUTUBE(옛 줄은 빈칸)
    return c


#: ★ 2026-10-22 번역 갈래(사용자 「각 유형별로 체크해서 번역」) — 관리자가 켠 갈래만 [번역하기]가 보낸다 · 기본 셋 다
KINDS = ('DEVOTIONAL', 'NEWS', 'YOUTUBE')
KIND_NAME = {'DEVOTIONAL': '묵상', 'NEWS': '뉴스', 'YOUTUBE': '유튜브', '': '(갈래 모름)'}


def kinds_on():
    try:
        v = _A().get('rss_transfer', 'xl_kinds', None)
        ks = [k for k in (v or []) if k in KINDS] if isinstance(v, list) else list(KINDS)
        return ks or list(KINDS)
    except Exception:
        return list(KINDS)


def set_kinds_on(ks):
    _A().set_('rss_transfer', 'xl_kinds', [k for k in KINDS if k in set(ks)])


def _h(text):
    return hashlib.sha1((text or '').encode('utf-8')).hexdigest()


def cache_get(conn, text, lang):
    r = conn.execute("SELECT dst FROM xl WHERE h=? AND lang=?", (_h(text), lang)).fetchone()
    return r[0] if r else None


def cache_src(conn, text, lang):
    """그 번역을 한 기계 — GEMINI · GOOGLE(옛 줄은 칸이 비었다 — 그때는 구글 번역만 썼다)."""
    r = conn.execute("SELECT src FROM xl WHERE h=? AND lang=?", (_h(text), lang)).fetchone()
    return ((r[0] if r else '') or 'GOOGLE').upper()


def cache_put(conn, text, lang, dst, src='GOOGLE'):
    conn.execute("INSERT OR REPLACE INTO xl(h, lang, dst, src) VALUES(?,?,?,?)", (_h(text), lang, dst, src))


# ── 공식 API 호출 ───────────────────────────────────────────────────
def translate_batch(texts, target_lang, api_key, fmt='text'):
    """texts(list[str]) → 번역 list[str]. target_lang = UI코드(KO/EN/…) 또는 ISO.
    실패 시 예외 발생(호출부에서 중단/재시도 판단)."""
    if not texts:
        return []
    import gcloud_gate as _GG                      # 구글 클라우드 일시 중단(2026-09-16) — 유료 API 다
    if _GG.paused():
        raise RuntimeError(_GG.MSG)
    tl = LANG_ISO.get(target_lang.upper(), target_lang)
    body = json.dumps({'q': list(texts), 'target': tl, 'format': fmt}).encode('utf-8')
    req = urllib.request.Request(
        API_URL + '?key=' + urllib.parse.quote(api_key),
        data=body, headers={'Content-Type': 'application/json'}, method='POST')
    with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
        data = json.loads(resp.read().decode('utf-8'))
    trs = data.get('data', {}).get('translations', [])
    return [t.get('translatedText', '') for t in trs]


def estimate_chars(rows, langs=UI_LANGS):
    """번역 필요 글자 수 추정(원본언어=대상언어 제외). 캐시 미반영 — 상한 추정."""
    n = 0
    for r in rows:
        src = (r.get('lang') or 'EN').upper()
        title = r.get('title') or ''
        for lg in langs:
            if lg != src:
                n += len(title)
    return n


def get_key():
    """Cloud Translation 키 — 비밀 보관소(admin_secrets.db · 배포 안 됨) 한 곳. 옛 자리(app_state_admin.json)에
    있으면 한 번 옮긴다. 「발행할 때 제목 번역 포함」 스위치는 따로(`key_on`)."""
    try:
        import secret_store as S
        k = (S.get('GTRANSLATE_KEY') or '').strip()
        if k:
            return k
        try:
            from admin import admin_state as A
        except ImportError:
            import admin_state as A
        old = (A.get('rss_transfer', 'gtranslate_key', '') or '').strip()
        if old:
            S.put('GTRANSLATE_KEY', old)
            A.set_('rss_transfer', 'gtranslate_key', '')
        return old
    except Exception:
        return ''


def set_key(k):
    import secret_store as S
    S.put('GTRANSLATE_KEY', (k or '').strip())


def translate_rows(rows, api_key, langs=UI_LANGS, progress=None):
    """rows(dict, 'title'/'lang' 보유)에 t_<LANG> 칼럼 채움(원본언어=대상언어면 빈값).
    캐시 우선 → 미캐시만 API 배치 호출. (translated_count, api_calls) 반환.
    ★ 2026-10-22 키가 없어도 **캐시에 있는 번역은 쓴다**(그전에는 키가 없으면 47,000건 캐시도 안 썼다) —
      키가 없으면 새 제목만 원문으로 남는다."""
    conn = _cache_conn()
    translated = api_calls = 0
    try:
        for lg in langs:
            col = 't_' + lg
            # 이 언어로 번역 필요한 행(원본≠대상, 제목 있음) 중 미캐시 수집
            todo = []   # (row, title)
            for r in rows:
                src = (r.get('lang') or 'EN').upper()
                title = (r.get('title') or '').strip()
                if not title or src == lg:
                    r.setdefault(col, '')
                    continue
                hit = cache_get(conn, title, lg)
                if hit is not None:
                    r[col] = hit
                    r['xb_' + lg] = cache_src(conn, title, lg)   # ★ 2026-10-24 누가 옮겼나(화면에 기계 이름)
                else:
                    todo.append((r, title))
            # 미캐시 배치 번역(키가 있을 때만)
            if not api_key:
                continue
            for i in range(0, len(todo), _BATCH):
                chunk = todo[i:i + _BATCH]
                texts = [t for _r, t in chunk]
                try:
                    outs = translate_batch(texts, lg, api_key)
                    api_calls += 1
                except Exception as e:
                    if progress:
                        progress(f'[{lg}] 번역 API 오류: {str(e)[:60]} — 중단')
                    raise
                for (r, title), dst in zip(chunk, outs):
                    r[col] = dst
                    cache_put(conn, title, lg, dst)
                    translated += 1
                conn.commit()
                if progress:
                    progress(f'[{lg}] {min(i + _BATCH, len(todo))}/{len(todo)} 번역')
        return translated, api_calls
    finally:
        conn.commit()
        conn.close()


# ══ 번역 대기열 · 우선순위 · [번역하기](2026-10-22) ════════════════════════════
# ★ 사용자 지시 — 「구글번역, 제미나이 번역 둘 중에 관리자가 우선순위를 정하도록 · 지금은 제미나이 1순위 ·
#   관리자가 번역 버튼을 누를 때에만 작동 · 검증하고 나서 나중에 자동진행 · 직전에 번역 완료한 레코드 번호를 기억 ·
#   수집된 제목을 모아서 한번만 호출」.
# ⇒ 발행은 **캐시만** 쓴다(돈·한도를 쓰지 않는다). 발행할 때 모인 제목은 대기열(xl_q)에 차례 번호로 쌓이고,
#   [번역하기]가 「마지막으로 끝낸 번호」(admin_state rss_transfer.xl_last_id) 다음부터 모아 엔진에 보낸다.
ENGINES = ('GEMINI', 'GOOGLE')
ENGINE_NAME = {'GEMINI': '제미나이', 'GOOGLE': '구글 번역(Cloud Translation)'}
# ★ 2026-10-24 한 번에 묶는 한도 = **200제목**(실측 — 150제목 · 빠진 칸 대부분 · 답 13,872토큰 · 39초).
#   한도를 정하는 것은 답의 길이다: 제목 하나가 열 언어를 다 비우면 답이 ≈250토큰 → 200제목 ≈ 50,000토큰으로
#   답 상한(65,536)과 시간 한도(300초) 안에 든다. 평소 한 회차 새 제목은 수십~백여 개라 **한 번 부르면 끝난다**.
GEMINI_CHUNK = 200
_LANG_EN = {'KO': 'Korean', 'EN': 'English', 'ZH': 'Simplified Chinese', 'ZHT': 'Traditional Chinese',
            'JA': 'Japanese', 'DE': 'German', 'FR': 'French', 'ES': 'Spanish', 'AR': 'Arabic',
            'RU': 'Russian', 'PT': 'Portuguese'}


def _A():
    try:
        from admin import admin_state as A
    except ImportError:
        import admin_state as A
    return A


def engine_order():
    """번역 엔진 차례 — 관리자가 정한다(기본 제미나이 먼저)."""
    try:
        v = _A().get('rss_transfer', 'xl_order', ['GEMINI', 'GOOGLE'])
        v = [x for x in (v or []) if x in ENGINES]
        return v + [x for x in ENGINES if x not in v]
    except Exception:
        return list(ENGINES)


def set_engine_order(first):
    _A().set_('rss_transfer', 'xl_order', [first] + [x for x in ENGINES if x != first])


def yt_on():
    """최신 유튜브 제목도 번역할까 — 관리자가 정한다(기본 켬 · 2026-10-22 사용자 지시)."""
    try:
        return bool(_A().get('rss_transfer', 'xl_youtube', True))
    except Exception:
        return True


def set_yt_on(v):
    _A().set_('rss_transfer', 'xl_youtube', bool(v))


def last_done():
    try:
        return int(_A().get('rss_transfer', 'xl_last_id', 0) or 0)
    except Exception:
        return 0


def _set_last_done(n):
    _A().set_('rss_transfer', 'xl_last_id', int(n))


def enqueue(rows):
    """모인 제목을 대기열에 — 처음 보는 제목만 새 번호(같은 제목은 그대로) → 새로 든 수."""
    from datetime import datetime
    conn = _cache_conn()
    n = 0
    try:
        now = datetime.now().isoformat(timespec='seconds')
        for r in rows:
            t = (r.get('title') or '').strip()
            if not t:
                continue
            kind = (r.get('feed_kind') or '').upper()
            cur = conn.execute("INSERT OR IGNORE INTO xl_q(h, title, lang, added_at, kind) VALUES(?,?,?,?,?)",
                               (_h(t), t, (r.get('lang') or 'EN').upper(), now, kind))
            n += cur.rowcount or 0
            if kind and not cur.rowcount:   # 옛 줄(갈래 빈칸)에 갈래를 채운다
                conn.execute("UPDATE xl_q SET kind=? WHERE h=? AND COALESCE(kind,'')=''", (kind, _h(t)))
        conn.commit()
        return n
    finally:
        conn.close()


def _missing(conn, h, src_lang, langs=UI_LANGS):
    have = {r[0] for r in conn.execute("SELECT lang FROM xl WHERE h=? AND COALESCE(dst,'')<>''", (h,))}
    return [lg for lg in langs if lg != src_lang and lg not in have]


def pending(conn=None, kinds=None):
    """마지막으로 끝낸 번호 다음부터, 아직 다 옮기지 못한 제목 → [(번호, 제목, 원문 언어, 빠진 언어들)].
    [kinds] 를 주면 그 갈래만(갈래 빈칸인 옛 줄은 늘 든다)."""
    own = conn is None
    conn = conn or _cache_conn()
    try:
        out = []
        for i, h, t, lg, kd in conn.execute("SELECT id, h, title, lang, COALESCE(kind,'') FROM xl_q WHERE id > ? ORDER BY id",
                                            (last_done(),)):
            if kinds is not None and kd and kd not in kinds:
                continue
            miss = _missing(conn, h, lg)
            out.append((i, t, lg, miss))
        return out
    finally:
        if own:
            conn.close()


def advance_last_done(conn):
    """★ 2026-10-22 「끝낸 번호」 = 그 번호까지 **모든 갈래**가 빠진 칸 없이 끝난 자리.
    갈래를 걸러 번역하면 안 켠 갈래 줄이 사이에 남는다 — 그 줄을 건너뛰어 번호를 올리면 영영 번역되지 않는다."""
    last = last_done()
    for i, h, _t, lg in conn.execute("SELECT id, h, title, lang FROM xl_q WHERE id > ? ORDER BY id", (last,)):
        if _missing(conn, h, lg):
            break
        last = i
    if last > last_done():
        _set_last_done(last)
    return last


def queue_view(conn=None, done_limit=150):
    """관리자 화면 목록 — 대기(빠진 칸 있음)와 최근 끝낸 것 → [dict(id, kind, lang, title, miss, ko, en)].
    ko = 한국어 번역(원문이 한국어면 빈칸) · en = 영어 번역 — 사람이 눈으로 확인하는 자리."""
    own = conn is None
    conn = conn or _cache_conn()
    try:
        out = []
        rows = conn.execute("SELECT id, h, title, lang, COALESCE(kind,'') FROM xl_q ORDER BY id DESC").fetchall()
        n_done = 0
        for i, h, t, lg, kd in rows:
            miss = _missing(conn, h, lg)
            if not miss:
                n_done += 1
                if n_done > done_limit:
                    continue
            out.append({'id': i, 'kind': kd, 'lang': lg, 'title': t, 'miss': miss,
                        'ko': '' if lg == 'KO' else (cache_get(conn, t, 'KO') or ''),
                        'en': '' if lg == 'EN' else (cache_get(conn, t, 'EN') or '')})
        out.sort(key=lambda d: (not d['miss'], -d['id']))   # 대기가 위(번호 큰 것부터) · 그 아래 끝낸 것
        return out
    finally:
        if own:
            conn.close()


def _names(conn):
    """★ 2026-10-25 번역 금지 이름표(확정된 것만 · `xl_names`) — 못 읽으면 빈 목록(번역은 그대로 돈다)."""
    try:
        import xl_names as XN
        XN.ensure(conn)
        return XN.all_rows(conn, 'OK')
    except Exception:                                    # noqa: BLE001
        return []


def _gemini_prompt(items, names=None):
    """items = [(번호, 제목, 원문 언어, [대상 언어])] → 한 번에 보낼 글(번호마다 언어별 번역을 JSON 으로).
    [names] = 확정된 번역 금지 이름 — 그 묶음 제목에 든 것만 언어마다 정확한 꼴로 붙인다."""
    block = ''
    if names:
        import xl_names as XN
        block = XN.prompt_block(names, [(t, miss) for (_i, t, _lg, miss) in items])
    lines = []
    for k, (_i, t, lg, miss) in enumerate(items, 1):
        lines.append(json.dumps({'n': k, 'from': lg, 'to': miss, 'title': t}, ensure_ascii=False))
    return ('You translate Christian news and devotional headlines.\n'
            'For each JSON line below, translate "title" into every language code listed in "to" '
            '(KO=Korean, EN=English, ZH=Simplified Chinese, ZHT=Traditional Chinese, JA=Japanese, DE=German, '
            'FR=French, ES=Spanish, AR=Arabic, RU=Russian, PT=Portuguese).\n'
            'Rules: translate only — no notes, no added words; keep names of people, churches, ministries and '
            'publications accurate; write Bible references in the target language\'s usual form.\n'
            'Answer with ONE JSON object only: {"<n>": {"<code>": "<translation>", ...}, ...} — every n, every code.\n\n'
            + block + '\n'.join(lines))


def _parse_json(text):
    t = (text or '').strip()
    if t.startswith('```'):
        t = t.strip('`')
        t = t[t.find('{'):]
    a, b = t.find('{'), t.rfind('}')
    if a < 0 or b < a:
        raise ValueError('JSON 이 아닙니다')
    try:
        return json.loads(t[a:b + 1])
    except ValueError:
        pass
    # ★ 2026-10-24 한 칸이 깨져도(번역 안의 따옴표 등) 묶음 전체를 버리지 않는다 — 실측 150제목 묶음이
    #   6,778번째 글자 하나로 통째 버려져 자동 번역이 첫 묶음에서 멈췄다. 번호마다 · 언어마다 읽을 수 있는 것만 건진다.
    import re as _re
    out = {}
    for m in _re.finditer(r'"(\d+)"\s*:\s*\{(.*?)\}', t[a:b + 1], _re.S):
        cells = {}
        # 칸 끝 따옴표 뒤에 , 나 } 가 와야 한 칸이다 — 안에 맨 따옴표가 섞인 칸은 반쪽을 담지 않고 버린다
        for c in _re.finditer(r'"([A-Z]{2,3})"\s*:\s*"((?:[^"\\\n]|\\.)*)"(?=\s*(?:,|$))', m.group(2)):
            try:
                cells[c.group(1)] = json.loads('"%s"' % c.group(2))
            except ValueError:
                continue
        if cells:
            out[m.group(1)] = cells
    if not out:
        raise ValueError('JSON 을 읽지 못했습니다')
    return out


def _run_gemini(conn, items, call=None):
    """한 묶음을 제미나이로 → 담은 칸 수. 실패면 예외."""
    if call is None:
        import ai_client as AC
        call = lambda p: AC.call(p, temperature=0, max_out=65536, timeout=300)   # noqa: E731
    res = call(_gemini_prompt(items, _names(conn)))
    if not res.get('ok'):
        raise RuntimeError('제미나이: %s' % (res.get('why') or '답 없음'))
    data = _parse_json(res.get('text'))
    n = 0
    for k, (_i, t, _lg, miss) in enumerate(items, 1):
        got = data.get(str(k)) or data.get(k) or {}
        for lg in miss:
            v = (got.get(lg) or '').strip() if isinstance(got, dict) else ''
            if v and '\n' not in v:
                cache_put(conn, t, lg, v, 'GEMINI')
                n += 1
    conn.commit()
    return n


def _run_google(conn, items, api_key):
    """한 묶음을 구글 번역으로(언어마다 한 요청) → 담은 칸 수. 실패면 예외."""
    if not api_key:
        raise RuntimeError('구글 번역 키가 없습니다')
    n = 0
    names = _names(conn)
    import xl_names as XN
    for lg in UI_LANGS:
        todo = [(i, t) for (i, t, _s, miss) in items if lg in miss]
        # ★ 2026-10-25 확정 이름이 든 제목은 그 이름을 그 언어 꼴로 바꾸고 「번역 금지」로 감싸 HTML 로 보낸다
        prot, plain = [], []
        for i, t in todo:
            h = XN.protect_html(t, names, lg) if names else None
            (prot if h else plain).append((i, t, h))
        for group, fmt in ((plain, 'text'), (prot, 'html')):
            for a in range(0, len(group), _BATCH):
                chunk = group[a:a + _BATCH]
                outs = translate_batch([h or t for _i, t, h in chunk], lg, api_key, fmt=fmt)
                for (_i, t, _h), dst in zip(chunk, outs):
                    if fmt == 'html':
                        dst = XN.unprotect_html(dst)
                    if dst:
                        cache_put(conn, t, lg, dst, 'GOOGLE')
                        n += 1
        conn.commit()
    return n


#: 이 프로세스에서 돈 번역 결과(차례대로) — `db_auto_publish` 가 바퀴마다 비우고 모아 기록한다
_RUNS = []


def translate_pending(progress=None, order=None, api_key=None, gemini_call=None, chunk=GEMINI_CHUNK, kinds=None):
    """[번역하기] — 대기열에서 마지막으로 끝낸 번호 다음부터 모아 엔진 차례대로 → 결과 dict.
    한 묶음이 끝나면(빠진 칸 없이) 그 묶음의 마지막 번호를 「끝낸 번호」로 적는다 — 실패하면 거기서 멈추고 다음에 그 자리부터.
    """
    order = order or engine_order()
    api_key = api_key if api_key is not None else get_key()
    conn = _cache_conn()
    out = {'items': 0, 'cells': 0, 'by': {}, 'last': last_done(), 'stopped': '', 'left': 0}
    try:
        kinds = kinds_on() if kinds is None else kinds
        todo = pending(conn, kinds)
        work = [x for x in todo if x[3]]
        out['items'] = len(work)
        # 이미 다 옮긴 앞부분은 번호만 넘긴다(모든 갈래 기준)
        out['last'] = advance_last_done(conn)
        for a in range(0, len(work), chunk):
            items = work[a:a + chunk]
            ok_by = None
            errs = []
            for eng in order:
                try:
                    if progress:
                        progress('%s 로 %d개 번역 중… (%d/%d)' % (ENGINE_NAME[eng], len(items), a + len(items), len(work)))
                    n = _run_gemini(conn, items, gemini_call) if eng == 'GEMINI' else _run_google(conn, items, api_key)
                    out['cells'] += n
                    out['by'][eng] = out['by'].get(eng, 0) + n
                    ok_by = eng
                    break
                except Exception as e:                    # noqa: BLE001
                    errs.append('%s: %s' % (ENGINE_NAME[eng], str(e)[:120]))
            if ok_by is None:
                out['stopped'] = ' / '.join(errs)
                break
            # 끝낸 번호는 모든 갈래 기준으로 올린다 · 번역이 비어 온 줄이 있으면 거기서 멈춘다
            out['last'] = advance_last_done(conn)
            # ★ 2026-10-24 빈 칸이 온 줄은 다음 회차에 다시 묻는다 — 그것 때문에 나머지 묶음을 멈추지 않는다
            if any(_missing(conn, _h(t), lg) for (_i, t, lg, _m) in items):
                out['stopped'] = '비어 온 칸이 있어 다음 회차에 다시 묻습니다(번호 %d 다음)' % out['last']
        out['left'] = len([x for x in pending(conn, kinds) if x[3]])
        _RUNS.append(dict(out))                 # ★ 2026-10-25 자동 배포 기록이 읽는다(이번 바퀴에 얼마나 옮겼나)
        return out
    finally:
        conn.commit()
        conn.close()


def selftest():
    """가짜 제미나이로 — 대기열 · 끝낸 번호 · 묶음 · 실패하면 멈추고 그 자리 · 차례(구글 먼저면 구글)."""
    import tempfile
    global _CACHE_PATH
    old, oldA = _CACHE_PATH, None
    store = {}

    class FakeA:
        def get(self, sec, k, d=None):
            return store.get((sec, k), d)

        def set_(self, sec, k, v):
            store[(sec, k)] = v
    fa = FakeA()
    global _A
    oldA = _A
    _A = lambda: fa                                          # noqa: E731
    _CACHE_PATH = os.path.join(tempfile.mkdtemp(), 'xl.db')
    ok = [0, 0]

    def ck(m, c):
        ok[0 if c else 1] += 1
        print(('  PASS ' if c else '  FAIL ') + m)
    try:
        ck('기본 차례 = 제미나이 먼저', engine_order() == ['GEMINI', 'GOOGLE'])
        rows = [{'title': 'Grace %d' % i, 'lang': 'EN'} for i in range(5)] + [{'title': '은혜', 'lang': 'KO'}]
        ck('대기열에 처음 보는 제목만', enqueue(rows) == 6 and enqueue(rows) == 0)
        calls = []

        def fake(p):
            calls.append(p)
            lines = [json.loads(x) for x in p.split('\n') if x.startswith('{"n"')]
            return {'ok': True, 'text': json.dumps({str(d['n']): {lg: '%s>%s' % (d['title'], lg) for lg in d['to']}
                                                     for d in lines})}
        r = translate_pending(gemini_call=fake, api_key='', chunk=4)
        ck('묶음 4 → 두 번 호출 · 6개 다 · 끝낸 번호 6', len(calls) == 2 and r['last'] == 6 and r['left'] == 0)
        c = _cache_conn()
        ck('제미나이 표시', c.execute("SELECT COUNT(*) FROM xl WHERE src='GEMINI'").fetchone()[0] == 5 * 10 + 10)
        c.close()
        rows2 = [{'title': 'Hope %d' % i, 'lang': 'EN'} for i in range(3)]
        enqueue(rows2)
        r = translate_pending(gemini_call=lambda p: {'ok': False, 'why': '한도'}, api_key='')
        ck('둘 다 실패하면 멈추고 번호 그대로', r['last'] == 6 and r['stopped'] and r['left'] == 3)
        calls.clear()
        r = translate_pending(gemini_call=fake, api_key='')
        ck('다음에 그 자리부터 · 한 번 호출 · 다 끝남', len(calls) == 1 and r['last'] > 6 and r['left'] == 0 and 'Grace' not in calls[0])
        ck('유튜브 제목 번역 기본 켬 · 끄고 켠다', yt_on() and (set_yt_on(False) or not yt_on()) and (set_yt_on(True) or yt_on()))
        set_engine_order('GOOGLE')
        ck('관리자가 차례를 바꾼다', engine_order() == ['GOOGLE', 'GEMINI'])
        # 캐시만 쓰는 발행 — 키 없이도 캐시는 실린다
        rr = [{'title': 'Grace 1', 'lang': 'EN'}]
        translate_rows(rr, None, langs=['KO'])
        ck('발행은 캐시 번역을 싣는다', rr[0].get('t_KO') == 'Grace 1>KO')
        # ★ 2026-10-25 확정된 번역 금지 이름은 그 묶음에 든 것만 언어마다 꼴로 붙는다
        import xl_names as XN
        c = _cache_conn()
        XN.ensure(c)
        XN.upsert_cand(c, 'Desiring God', 'EN', forms={'KO': '디자이어링 갓'})
        c.execute("UPDATE xl_name SET status='OK'")
        c.commit()
        set_engine_order('GEMINI')
        enqueue([{'title': 'Desiring God on hope', 'lang': 'EN'}, {'title': 'Plain', 'lang': 'EN'}])
        calls.clear()
        translate_pending(gemini_call=fake, api_key='')
        ck('제미나이 묶음에 확정 이름 꼴이 붙는다', calls and 'Desiring God(디자이어링 갓)' in calls[0])
        c.close()
    finally:
        _CACHE_PATH = old
        _A = oldA
    print('cloud_translate selftest %d/%d' % (ok[0], sum(ok)))
    return ok[1] == 0


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
