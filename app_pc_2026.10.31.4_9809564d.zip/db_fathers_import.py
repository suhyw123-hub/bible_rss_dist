# -*- coding: utf-8 -*-
"""db_fathers_import.py — 사도교부 문헌 5권 적재 (영구 도구).

2026-08-18 사용자 승인 「모두 진행하라」. 원문 = `_fathers_raw/fathers.txt`
(**Lightfoot 『The Apostolic Fathers』 1891 영역** — CCEL 1순위, 재다운로드
바이트 일치·깨진 글자 0 확인). 원저는 전부 코이네 그리스어라 출처 줄을
켐피스 선례(§0-2)대로 「— tr. J. B. Lightfoot …」 로 명기한다.

  python db_fathers_import.py --selftest        # 의무
  python db_fathers_import.py --check           # 5권 파싱·게이트
  python db_fathers_import.py --preview HERMAS 1 14 27
  python db_fathers_import.py --apply DIDACHE|CLEMENT|IGNATIUS|POLYCARP|HERMAS

구조(전부 실측):
  · 저작 경계 = 대문자 헤딩 줄(클레멘트 29 · 이그나티우스 7편 · 폴리캅
    서신/순교록 · **디다케는 순교록과 바나바 사이(4422)** — 처음에 ANF07 이
    필요하다고 봤으나 Lightfoot 단권에 `Did. 1~16` 이 다 있다).
  · 장 표식 = `Did. 5`·`IgnEph 3`·`MartPol. 9` 꼴 한 줄 — 본문에서는
    문단 번호 「5.」 로 바꾼다. 클레멘트는 표식이 아예 없다(한 유닛).
  · 헤르마스 = Vision 1~4 + **Revelation 5(=다섯째 환상)** + Mandate 1~12 +
    Parable — **1번 비유는 머리글이 없고**(Herm.Sim 구분선 직후) 2~5는
    「Another Parable」, 6~10만 「Parable N」이다.
  · 각주 블록(`[n]`, 빈 줄 뒤 시작) 제거 · `____` 구분선 제거 · 하드랩은
    빈 줄 문단으로 되붙임 · 바나바서·디오그네투스는 미등록이라 제외.
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, '_fathers_raw', 'fathers.txt')
DB = os.path.join(HERE, 'bible_master.db')
sys.path.insert(0, HERE)

ATTRIB = '— tr. J. B. Lightfoot, The Apostolic Fathers (1891)'
SRC_URL = 'https://www.ccel.org/ccel/lightfoot/fathers.html'

# 저작 경계 헤딩(정확한 줄 텍스트 — 실측)
_H_CLEM = 'THE FIRST EPISTLE OF CLEMENT TO THE CORINTHIANS'
_H_IGN = [
    ('THE EPISTLE OF IGNATIUS TO THE EPHESIANS', 'To the Ephesians'),
    ('THE EPISTLE OF IGNATIUS TO THE MAGNESIANS', 'To the Magnesians'),
    ('THE EPISTLE OF IGNATIUS TO THE TRALLIANS', 'To the Trallians'),
    ('THE EPISTLE OF IGNATIUS TO THE ROMANS', 'To the Romans'),
    ('THE EPISTLE OF IGNATIUS TO THE PHILADELPHIANS',
     'To the Philadelphians'),
    ('THE EPISTLE OF IGNATIUS TO THE SMYRNAEANS', 'To the Smyrnaeans'),
    ('THE EPISTLE OF IGNATIUS TO POLYCARP', 'To Polycarp'),
]
_H_POL = 'THE EPISTLE OF POLYCARP'
_H_MART = 'THE LETTER OF THE SMYRNAEANS OR THE MARTYRDOM OF POLYCARP'
_H_DID = 'THE TEACHING OF THE LORD'          # 두 줄 헤딩이라 접두로 찾는다
_H_BARN = 'THE EPISTLE OF BARNABAS'
_H_HERM = 'THE SHEPHERD OF HERMAS'
_H_DIOGN = 'THE EPISTLE TO DIOGNETUS'

_SEP = re.compile(r'^\s*_{10,}\s*$')
_FN_HEAD = re.compile(r'^\s*\[\d+\]')
_INLINE_FN = re.compile(r'\s*\[\d+\]')
_MARK = re.compile(r'^\s*([A-Za-z0-9]{1,10})\.? ?(\d{1,3})\s*$')
_PART = re.compile(r'^\s*Herm\.(Vis|Mand|Sim)\s*$')

BOOKS = ('DIDACHE', 'CLEMENT', 'IGNATIUS', 'POLYCARP', 'HERMAS',
         'DIOGNETUS')
CODE = {'DIDACHE': 'DIDACHE', 'CLEMENT': 'CLEMENT_1ST',
        'IGNATIUS': 'IGNATIUS_LETTERS', 'POLYCARP': 'POLYCARP_PHIL',
        'HERMAS': 'HERMAS_SHEPHERD', 'DIOGNETUS': 'DIOGNETUS'}
EXPECT = {'DIDACHE': 16, 'CLEMENT': 66, 'IGNATIUS': 7, 'POLYCARP': 2,
          'HERMAS': 27, 'DIOGNETUS': 12}
# ⚠ 클레멘트 장 표식은 「1 Clem. 5」 — **공백 포함 세 토큰**이라 다른 책의
#   표식 정규식(`IgnEph 3` 꼴)으로는 안 잡힌다. 처음에 「표식 없음 = 한
#   유닛」으로 오판했던 원인(2026-08-18 사용자 「장 단위로 나누자」로 재조사).
_CLEM_MARK = re.compile(r'^\s*1 Clem\.? ?(Prologue|\d+)\s*$')


def _lines():
    with open(RAW, encoding='utf-8') as f:
        return f.read().split('\n')


def _find(lines, head, start=0):
    for i in range(start, len(lines)):
        if lines[i].strip().startswith(head):
            return i
    raise SystemExit('헤딩을 못 찾음: %s' % head)


def _clean(seg):
    """각주 블록·구분선 제거 → 문단 되붙임 → 표식 줄은 「N.」 문단으로."""
    out, i, n = [], 0, len(seg)
    prev_blank = True
    while i < n:                        # 각주 블록 (빈 줄 뒤 [n] 머리)
        l = seg[i]
        if _FN_HEAD.match(l) and prev_blank:
            while i < n and seg[i].strip():
                i += 1
            out.append('')
            prev_blank = True
            continue
        out.append(l)
        prev_blank = not l.strip()
        i += 1
    paras, cur = [], []

    def flush():
        if cur:
            paras.append(' '.join(' '.join(x.split()) for x in cur))
            del cur[:]

    for l in out:
        if not l.strip() or _SEP.match(l):
            flush()
            continue
        m = _MARK.match(l)
        if m:                            # 장 표식 → 문단 번호
            flush()
            paras.append('%s.' % m.group(2))
            continue
        cur.append(l)
    flush()
    paras = [_INLINE_FN.sub('', p).strip() for p in paras]
    return '\n'.join(p for p in paras if p)


def parse(which):
    """반환 = [(sequence, label, body)]"""
    lines = _lines()
    if which == 'CLEMENT':
        a = _find(lines, _H_CLEM)
        # ⚠ 클레멘트 1서와 이그나티우스 사이에 **클레멘트 2서(옛 설교,
        #   무명 저자)** 가 끼어 있다 — 머리글이 「AN ANCIENT HOMILY…」라
        #   「THE …」 스캔이 놓쳐 65장 꼬리에 22KB 가 통째로 딸려 들어갔던
        #   함정(실측). 미등록 저작이라 제외하고 거기서 자른다.
        b = _find(lines, 'AN ANCIENT HOMILY', a)
        seg = lines[a:b]
        marks = [(i, _CLEM_MARK.match(l).group(1))
                 for i, l in enumerate(seg) if _CLEM_MARK.match(l)]
        out = []
        for k, (i, num) in enumerate(marks):
            j = marks[k + 1][0] if k + 1 < len(marks) else len(seg)
            label = 'Prologue' if num == 'Prologue' else 'Ch. %s' % num
            out.append((k + 1, label, _clean(seg[i + 1:j])))
        return out
    if which == 'IGNATIUS':
        idx = [_find(lines, h) for h, _l in _H_IGN] + [_find(lines, _H_POL)]
        return [(k + 1, _H_IGN[k][1], _clean(lines[idx[k] + 1:idx[k + 1]]))
                for k in range(7)]
    if which == 'POLYCARP':
        a = _find(lines, _H_POL)
        b = _find(lines, _H_MART)
        c = _find(lines, _H_DID)
        return [(1, 'Epistle to the Philippians', _clean(lines[a + 1:b])),
                (2, 'The Martyrdom of Polycarp', _clean(lines[b + 1:c]))]
    if which == 'DIDACHE':
        a = _find(lines, _H_DID)
        b = _find(lines, _H_BARN)
        seg = lines[a:b]
        marks = [i for i, l in enumerate(seg)
                 if re.match(r'^\s*Did\.? ?\d+\s*$', l)]
        out = []
        for k, i in enumerate(marks):
            j = marks[k + 1] if k + 1 < len(marks) else len(seg)
            out.append((k + 1, 'Ch. %d' % (k + 1), _clean(seg[i + 1:j])))
        return out
    if which == 'DIOGNETUS':
        # 2026-08-18 추가 등록(사용자 「디오그네투스만 진행하라」 — 바나바서는
        # 보류). 끝 경계 = CCEL 꼬리 문구(파일 마지막 저작이라 다음 헤딩이 없다).
        a = _find(lines, _H_DIOGN)
        b = _find(lines, 'This document is from', a)
        seg = lines[a:b]
        marks = [i for i, l in enumerate(seg)
                 if re.match(r'^\s*Diogn\.? ?\d+\s*$', l)]
        out = []
        for k, i in enumerate(marks):
            j = marks[k + 1] if k + 1 < len(marks) else len(seg)
            out.append((k + 1, 'Ch. %d' % (k + 1), _clean(seg[i + 1:j])))
        return out
    if which == 'HERMAS':
        a = _find(lines, _H_HERM)
        b = _find(lines, _H_DIOGN)
        seg = lines[a:b]
        # 유닛 경계 수집 — 부(Herm.Sim)는 경계이자 「비유 1」의 시작
        bounds = []                     # (줄, 라벨)
        n_sim = 0
        for i, l in enumerate(seg):
            t = l.strip()
            m = re.match(r'^(Vision|Mandate|Parable) (\d+)$', t)
            if m:
                kind, num = m.group(1), int(m.group(2))
                if kind == 'Parable':
                    n_sim = num
                bounds.append((i, '%s %d' % (kind, num)))
                continue
            if re.match(r'^Revelation 5$', t):      # 다섯째 환상
                bounds.append((i, 'Vision 5'))
                continue
            if t == 'Another Parable':
                n_sim += 1
                bounds.append((i, 'Parable %d' % n_sim))
                continue
            if _PART.match(l) and l.strip() == 'Herm.Sim':
                n_sim = 1
                bounds.append((i, 'Parable 1'))
        out = []
        for k, (i, label) in enumerate(bounds):
            j = bounds[k + 1][0] if k + 1 < len(bounds) else len(seg)
            body = _clean(seg[i + 1:j])
            if body:
                out.append((len(out) + 1, label, body))
        return out
    raise SystemExit('모르는 책: %s' % which)


_RESIDUE = (
    ('각주표 [n]', re.compile(r'\[\d+\]')),
    ('구분선', re.compile(r'_{10,}')),
    ('장 표식 잔재', re.compile(r'^(Ign\w+|MartPol|PolPhil|Did|Barn|Herm)\.? ?\d+$',
                            re.M)),
    ('HTML 태그', re.compile(r'<[a-zA-Z/][^>]{0,30}>')),
)


def check(verbose=True):
    bad = 0
    for w in BOOKS:
        units = parse(w)
        msgs = []
        if len(units) != EXPECT[w]:
            msgs.append('유닛 %d ≠ 기대 %d' % (len(units), EXPECT[w]))
        if [s for s, _l, _b in units] != list(range(1, len(units) + 1)):
            msgs.append('sequence 불연속')
        for s, label, body in units:
            if len(body) < 200:      # 클레멘트 서두(인사말) 259자가 정상 최소
                msgs.append('%d(%s) 본문 %d자 — 너무 짧다' % (s, label,
                                                          len(body)))
            for name, rx in _RESIDUE:
                m = rx.search(body)
                if m:
                    msgs.append('%d(%s) %s: %r' % (s, label, name,
                                                   m.group(0)))
        if verbose:
            total = sum(len(b) for _s, _l, b in units)
            print('%s %-9s 유닛 %2d · %6.0f자 평균%s'
                  % ('✗' if msgs else '✓', w, len(units),
                     total / max(1, len(units)),
                     '' if not msgs else ' — ' + msgs[0]))
            for m in msgs[1:5]:
                print('    ', m)
        bad += len(msgs)
    return bad


def preview(which, seqs):
    for s, label, body in parse(which):
        if s in seqs:
            print('=' * 66)
            print('[%d] %s (%d자)' % (s, label, len(body)))
            print(body[:420])


def apply(which, seqs=None):
    if check(verbose=False):
        print('검사 실패 — --check 먼저')
        return False
    import appdb
    conn = appdb.connect(DB)
    try:
        row = conn.execute('SELECT book_id FROM sys_book_asset WHERE '
                           'book_code=?', (CODE[which],)).fetchone()
        if not row:
            print('도서 미등록:', CODE[which])
            return False
        book_id = row[0]
        conn.execute('UPDATE sys_book_asset SET source_url=? WHERE '
                     'book_id=?', (SRC_URL, book_id))
        units = parse(which)
        if seqs:
            units = [u for u in units if u[0] in seqs]
        for seq, label, body in units:
            r = conn.execute('SELECT unit_id FROM sys_book_unit WHERE '
                             'book_id=? AND sequence=?',
                             (book_id, seq)).fetchone()
            if r:
                uid = r[0]
                conn.execute("UPDATE sys_book_unit SET unit_label=?, "
                             "session_type='CHAPTER', record_status='LIVE' "
                             "WHERE unit_id=?", (label, uid))
            else:
                conn.execute(
                    "INSERT INTO sys_book_unit (book_id, sequence, "
                    "session_type, unit_label, record_status) "
                    "VALUES (?,?,'CHAPTER',?,'LIVE')", (book_id, seq, label))
                uid = conn.execute(
                    'SELECT unit_id FROM sys_book_unit WHERE book_id=? AND '
                    'sequence=?', (book_id, seq)).fetchone()[0]
            conn.execute("DELETE FROM sys_book_unit_text WHERE unit_id=? "
                         "AND text_variant='ORIGINAL' AND "
                         "UPPER(lang_code)='EN'", (uid,))
            conn.execute(
                "INSERT INTO sys_book_unit_text (unit_id, text_variant, "
                "lang_code, body_text, record_status) "
                "VALUES (?,'ORIGINAL','EN',?,'LIVE')",
                (uid, body + '\n' + ATTRIB))
            print('%s %2d — %s' % (which, seq, label))
        conn.commit()
        print('적재 — %s(book_id %d) 유닛 %d' % (CODE[which], book_id,
                                                len(units)))
    finally:
        conn.close()
    return True


def selftest():
    ok = True

    def t(name, cond):
        nonlocal ok
        print('%s %s' % ('✓' if cond else '✗', name))
        ok = ok and cond

    # _clean 단위 검사
    fix = ['   Body line one wraps', '   onto line two here.', '',
           '   [1] a footnote block that must vanish', '',
           'IgnEph 5', '   After the mark comes more text.', '',
           '   __________________', '   Tail para with mark [2] inline.']
    got = _clean(fix)
    t('하드랩 되붙임', 'wraps onto line two' in got)
    t('각주 블록 제거', 'footnote block' not in got)
    t('장 표식 → 문단 번호', '\n5.\n' in '\n' + got + '\n')
    t('본문 속 [n] 제거', '[2]' not in got and 'Tail para with mark' in got)
    t('구분선 제거', '____' not in got)
    if os.path.exists(RAW):
        t('실제 5권 게이트 통과(위반 0)', check(verbose=False) == 0)
        h = parse('HERMAS')
        labels = [l for _s, l, _b in h]
        t('헤르마스 27유닛 라벨(환상5·계명12·비유10)',
          labels[:5] == ['Vision %d' % i for i in range(1, 6)]
          and labels[5:17] == ['Mandate %d' % i for i in range(1, 13)]
          and labels[17:] == ['Parable %d' % i for i in range(1, 11)])
        d = parse('DIDACHE')
        t('디다케 1장 = 두 길', 'two ways' in d[0][2][:120])
        cl = parse('CLEMENT')
        t('클레멘트 66유닛(서두+65장)',
          [l for _s, l, _b in cl] == ['Prologue']
          + ['Ch. %d' % i for i in range(1, 66)])
        p = parse('POLYCARP')
        t('순교록에 86년 고백', 'Fourscore and six years' in p[1][2])
        dg = parse('DIOGNETUS')
        t('디오그네투스 12장·9장 달콤한 교환',
          len(dg) == 12 and 'sweet exchange' in dg[8][2])
    else:
        print('· 원문 없음 — 파일 검사 생략')
    print('selftest', 'OK' if ok else 'FAIL')
    return ok


if __name__ == '__main__':
    a = sys.argv[1:]
    if not a or a[0] == '--selftest':
        sys.exit(0 if selftest() else 1)
    if a[0] == '--check':
        sys.exit(1 if check() else 0)
    if a[0] == '--preview' and len(a) >= 3:
        preview(a[1].upper(), {int(x) for x in a[2:]})
        sys.exit(0)
    if a[0] == '--apply' and len(a) >= 2 and a[1].upper() in BOOKS:
        sys.exit(0 if apply(a[1].upper(),
                            {int(x) for x in a[2:]} or None) else 1)
    print(__doc__)
