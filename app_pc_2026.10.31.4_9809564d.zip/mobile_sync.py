# -*- coding: utf-8 -*-
"""mobile_sync.py — 모바일 묵상앱 ↔ PC 동기화 엔진 (2026-10-06 317차 신설·영구).

★★★ 설계 — **PC 가 정본, 모바일은 사본 + 보낼 함** (사용자 확정 2026-10-06)
  「모바일에서 손댄 오버레이 데이터들은 PC 작업을 위한 임시 데이터와 같다 …
   양방향 싱크로를 추구할 필요가 있는가?」 · 「즐겨찾기 등을 추가/해제하는 것
   등은 PC 에서 그냥 저장해도 될 것이다. **각종 설명문, 묵상노트가 핵심 이슈**」.

      PC (정본 · 유일한 주인)
        │ ① **바뀐 것만** 보낸다(처음 한 번만 전부) — 한 방향
        ▼
      모바일 = 정본 사본(읽기) + 「보낼 함」(outbox)
        │ ② 보낼 함을 가져온다
        ▼
      PC ─┬─ 사건(EVENT) → **그 자리에서 저장**(즐겨찾기·플랜 완료·읽던 위치)
          └─ 초안(DRAFT) → **「모바일에서 온 초안」 함** → 사람이 정리해 채택
             (묵상노트·설명문·연구자료·AI 대화)

  ⇒ 양방향 동기화의 짐(충돌 규칙·모든 표의 전역 ID)이 **없다.** PC 의 일련번호가
    그대로 정본 번호이고, 주인이 하나라 겹칠 일이 없다.
  ⚠ 전제 — **PC 는 한 대**다. 두 대가 되면 주인이 둘이라 이 설계가 깨진다.

★★★ **바뀐 것만 보낸다** (사용자 지시 「달랑 몇개 수정했는데 db 통째로 다시
  전송하는 것은 전혀 비상식적이다」 — 처음 판은 통째로 보냈다).
  · 「무엇이 바뀌었나」는 **DB 트리거**가 적는다(`user_sync_change`) — 앱 코드에
    쓰기 자리가 수백 곳이라 거기서 적으면 반드시 하나가 빠진다. 지우는 것도 적힌다.
    §10-1 감사 로그와 같은 문법이지만 **표를 따로 둔다** — 감사 로그는 끄고
    지울 수 있어 믿을 수 없다.
  · ⚠ 짝 맺은 폰이 **없으면 적지 않는다**(트리거 WHEN) — 모바일을 안 쓰는 사람에게
    부담 0. 처음 짝을 맺으면 그 폰은 전부를 한 번 받는다.
  · 폰마다 「마지막으로 받은 번호」(`sent_seq`)를 기억하고, 폰도 제가 가진 번호를
    말한다(`have`). **둘이 같을 때만** 바뀐 것만 보내고 다르면 전부 보낸다(폰을
    새로 깔았거나 끊겼거나 PC 를 되돌린 경우).
  · 매번 표마다 행 수를 함께 보내 폰이 견준다 — 다르면 **그 표만** 다시 보낸다.
  · 폰이 다 받았다고 할 때까지 번호를 안 올린다(끊기면 다음에 그대로 다시 간다).

★★★ 연결 — **폰이 서버, PC 가 손님 · 입력 0** (사용자 「입력하다가 짜증나서
  버려버릴 것 같다」 · 「QR 하지 마라」 · 「숫자 없이 연결해도 좋다」)
  · PC [폰 연결하기] → 같은 와이파이에 **UDP 방송**으로 폰을 찾는다 → 폰에
    「○○ PC 가 연결하려 합니다 [허용]」 → 허용 한 번으로 끝.
  · 열쇠는 **Diffie-Hellman**(RFC 3526 2048비트 · 표준 `pow` 만)으로 그 자리에서
    만든다 — 엿듣기만 한 사람은 열쇠를 못 얻는다.
    ⚠ 숫자 확인을 뺐으므로 짝 맺는 그 순간 **같은 와이파이에서 일부러 끼어드는**
      공격은 못 막는다(사용자가 고른 편의) — 폰은 PC 이름을 보이고, 연결 요청은
      동기화 화면을 열어 둔 동안만 받는다.
  · Windows 방화벽은 **들어오는 연결**만 막는다 — PC 가 나가는 쪽이고, 방송에 대한
    답(유니캐스트)은 Windows 가 기본으로 받아 준다 ⇒ **PC 쪽 설정 0**.
  · 그 뒤로는 [동기화]가 방송으로 폰을 다시 찾는다(폰 주소가 바뀌어도 된다).

★★ 오가는 글은 전부 **암호화 + 위변조 검사**(`seal`/`unseal` · HMAC-SHA256 만 —
  배포판에 cryptography 가 없고 폰(Dart)도 HMAC 만 있으면 짠다) · 요청마다 시각 +
  일회 번호(10분 밖·이미 본 번호는 폰이 거절). 규격은 `docs/mobile_sync.md`.

★★ 이 파일의 **`PhoneRef`** 가 폰 쪽의 **참조 구현**이다. 자가 검증과 하네스가 이것을
  띄워 PC 쪽을 끝까지 잰다. ⚠ 규격이 바뀌면 **이 파일부터** 고친다.

⚠ 저장 문을 여기서 다시 짜지 않는다 — 묵상노트 `medi_note.save_new` ·
  설명문 덮개 `overlay_edit.save_mine` · 연구자료 `db_user_ref_schema.set_text`
  + `user_ai.link_verses` · AI 대화 `user_ai.new_chat/add_msg` ·
  플랜 완료 `plan_progress.mark_day` · 읽던 위치 `db_read_state` ·
  설정 `db_pref_preset.snapshot`.

사용:  python mobile_sync.py --selftest | --status
"""
import hashlib
import hmac
import json
import re
import os
import secrets
import socket
import sys
import threading
import time
import urllib.error
import urllib.request
import zlib

sys.stdout.reconfigure(encoding='utf-8', errors='replace')

try:
    import i18n
    _t = i18n.t
except Exception:                                         # noqa: BLE001
    def _t(k, d=''):
        return d

PROTO = 1
PORT_DEFAULT = 8765               # 폰의 HTTP
UDP_PORT = 8766                   # 폰을 찾는 방송
PATH = '/hagah/v1'
TS_WINDOW = 600                   # 요청 시각이 이 초 밖이면 거절
PAIR_WAIT = 120                   # 짝 맺기를 기다리는 초
# RFC 3526 그룹 14 — 2048비트 안전 소수(selftest 가 소수임을 잰다)
DH_P = int(
    'FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74'
    '020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F1437'
    '4FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7ED'
    'EE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF05'
    '98DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB'
    '9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3B'
    'E39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF695581718'
    '3995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF', 16)
DH_G = 2

# ── 갈래 — 사용자 지시 「데이터의 성격을 잘 살펴야 한다」 ─────────────
#  사건 = PC 가 그냥 저장한다(사람이 정리할 일이 아니다)
EVENT_KINDS = ('FAV_SET', 'VERSE_TOPIC', 'PLAN_ENROLL', 'PLAN_DAY_DONE', 'BOOK_POS',
               'BOOK_READ',
               # ★ 2026-10-16 도서 [읽기 시작]/[읽기 중단] — 「읽는 중」은 사람이 정한다(db_read_state.user_book_reading)
               'BOOK_START', 'BOOK_STOP',
               # ★ 2026-10-11 — 폰에서 「공유 ▸ 하가」로 담은 유튜브·웹 글. 정리할 글이 아니라 주소 하나라
               #   사건으로 그 자리에서 저장한다(유튜브 = 내 영상 · 그 밖 = 내 자료 웹 글) → 사본으로 폰에 돌아간다.
               'SAVE_LINK',
               # ★ 2026-10-12 폰에서 책을 뺐다(폰 용량 · 「대부분은 PC 에 두고 필요할 때 다시」) — PC 가 다시 밀어 넣지
               #   않게 보낼 책 목록에서 그 책을 뺀다. 다시 담는 것은 PC ④ 「폰에 담기」나 폰 「자료 받기」.
               'PACK_DROP',
               # ★ 2026-10-14 87 — 폰이 SNS 로 받은 플랜 파일(「+Hagah」). 사람이 정리할 글이 아니라 그대로 내 플랜이 된다
               #   (같은 열쇠면 안 덮는다 · `plan_share.put_plan`). 폰 사본은 지우지 않는다(사용자 「자동으로 지워지지 않도록」).
               'PLAN_IMPORT',
               # ★ 2026-10-22 폰에서 고친 최신 콘텐츠 받기 설정(news_pref) — 고친 때가 늦으면 PC 설정이 된다
               'NEWS_PREF',
               # ★ 2026-10-15 77 — 폰에서 수정한 기도 AI 프롬프트(기도 업무 T_PR_* 만 받는다 · `user_ai.put_prayer_prompt`)
               'AI_PROMPT',
               # ★ 2026-10-20 폰 「프롬프트 라이브러리」에서 고친 것(고치기 · 켜고 끄기 · 더하기 · 지우기 · ai_lib.apply_phone)
               'AI_LIB',
               # ★ 2026-10-20 폰 AI 대화 목록 — 동기화 대상(사용자 「대화목록을 PC 와의 동기화 대상으로」) · 폰 대화 번호(uid)로 덮어쓴다
               'AI_CHAT',
               # ★ 2026-10-20 (docs/1.txt 10) 폰 연결구절 ✎ — 이 연결 숨기기/다시 보이기 · 연결 추가 · 내 연결 지우기
               #   (PC 덮개 그대로 — `overlay.LinkOverlay` · sys 행은 안 건드리고 user_link_asset 에 HIDE/LIVE)
               'LINK_HIDE', 'LINK_ADD', 'LINK_DEL',
               # ★ 2026-10-15 77 — 기도 노트 **백업**. 기본은 안 보낸다 — 폰 설정 「기도 노트도 PC 에 보관(백업)」을
               #   사람이 켰을 때만 카드마다 PRAYER_SAVE 가 오고, 끄면 PRAYER_CLEAR 가 PC 보관분을 지운다.
               #   PC 는 글을 들여다보지 않고 통째로 보관만 한다(`user_prayer_backup` · 폰이 새로 깔렸을 때 되살린다).
               'PRAYER_SAVE', 'PRAYER_CLEAR',
               # ★ 2026-10-16 — 폰에서 묵상을 그만둔다(PC [중단]과 같은 일 · 기록은 남기고 상태만 ABANDONED)
               'PLAN_ABANDON',
               # ★ 2026-10-16 영상 취향 — PC 와 같은 넷(♥ 즐겨듣기는 FAV_SET LISTEN · 나머지 셋이 이것):
               #   채널 즐겨찾기 · 이 영상 숨기기 · 이 채널 숨기기(`media_pref` 표 그대로 · 사용자 「PC 와 통일」)
               'MEDIA_PREF',
               # ★ 2026-10-23 추천몰 내 쇼핑몰 ★(db_shop · 서버로는 안 간다 · PC 와 폰이 함께 쓴다)
               'SHOP_FAV',
               # ★ 2026-10-23 추천몰 쇼핑몰 숨기기(가입하지 않은 쇼핑몰 — 사용자) · 같은 꼴
               'SHOP_HIDE', 'SHOP_MINE', 'SHOP_REPEAT', 'SHOP_RECO',
               # ★ 2026-10-24 docs/4.txt — 내가 모은 채널(밖에서 담은 영상의 채널 · 채널 번호로) · 관리자에게 채널 추천
               'MY_CHANNEL', 'CH_RECO',
               # ★ 2026-10-24 내가 모은 사이트(글 RSS · 피드 주소로) · 관리자에게 사이트 추천
               'MY_SITE', 'SITE_RECO',
               # ★ 2026-10-28 공동체몰 파일 방식 — 관리자 폰이 「+Hagah」로 받은 사장님 가게 파일 → 이 PC 파일 몰의 대기
               #   (cmall_ref.Mall.take · 사람은 PC 공동체몰 관리에서 검토·게시한다)
               'CMALL_STORE')
#  초안 = 사람이 PC 에서 정리해 채택한다(핵심 이슈 — 설명문·묵상노트)
# ★ 2026-10-21 폰에서 PC 노트 고치기(NOTE_EDIT · 본문 통째)·지우기(NOTE_DEL · HIDE) — 15번 조사의 흠(폰 노트를 못 고쳤다)
DRAFT_KINDS = ('NOTE', 'NOTE_ADD', 'NOTE_EDIT', 'NOTE_DEL', 'DESC', 'REF', 'AI')
DRAFT_LABEL = {'NOTE': '묵상노트', 'NOTE_ADD': '묵상노트 덧붙이기',
               'NOTE_EDIT': '묵상노트 고치기', 'NOTE_DEL': '묵상노트 지우기',
               'DESC': '설명문 수정', 'REF': '연구자료', 'AI': 'AI 대화'}

# 정본 사본 — 폰에 보내는 개인 표(허용 목록 · 여기 적힌 것만 나간다)
#  ⚠ 공동체(`user_room*`)·감사 로그·캐시·사용량·피드백·AI 키는 안 보낸다.
MIRROR_TABLES = (
    ('user_text_asset', "COALESCE(room_id,'')=''"),   # 공동체 글은 PC 에 둔다
    ('user_ref_asset', ''),
    ('user_ref_text', ''),
    ('user_ref_table', ''),          # ★ 317차-18 — 연구/설교노트의 표(ref_doc)
    ('user_ref_table_text', ''),
    # ⚠ `user_ref_asset_link` 는 안 보낸다 — 2026-08-24 통합 때 남긴 **옛 표**다.
    #   연결의 정본은 `user_link_asset`(UREF_*)이고 아래에 실린다(314차 ㊆).
    ('user_favorite', "COALESCE(record_status,'LIVE')='LIVE'"),
    ('user_plan_enrollment', "COALESCE(record_status,'LIVE')='LIVE'"),
    ('user_plan_progress', "COALESCE(record_status,'LIVE')='LIVE'"),
    ('user_bible_plan', ''),
    ('user_plan_schedule', ''),
    ('user_unit_asset', ''),
    ('user_link_asset', ''),
    ('user_book_pos', ''),
    ('user_book_read', ''),
    ('user_book_reading', ''),       # ★ 2026-10-16 「읽는 중」(읽기 시작한 책)
    ('user_ai_chat', "COALESCE(record_status,'LIVE')='LIVE'"),
    ('user_ai_msg', "chat_id IN (SELECT chat_id FROM userdb.user_ai_chat WHERE"
                    " COALESCE(record_status,'LIVE')='LIVE')"),
    ('user_ai_prompt', ''),
    # ★ 내 영상(PC 의 간편 저장 · 재생목록 · 폰 공유로 담은 것) — 폰 「내 서재 ▸ 저장함」이 보인다(2026-10-11)
    ('user_media_asset', "COALESCE(record_status,'LIVE')='LIVE'"),
    # ★ PC 가 받은 공지 — 폰 홈 화면에 띄운다(2026-10-10 1.txt 54 · 사용자 「공지와 추천 구절도 폰으로」).
    ('user_announcement', ''),
    ('user_verse_topic', ''),        # ★ 2026-10-29 때에 맞는 말씀 — 내 주제·가림(db_verse_topic)
    ('user_verse_topic_item', ''),
    # ★ 2026-10-14 docs/1.txt 87 — 녹음 진척(파일은 따로 voice_sync 가 주고받는다). 폰이 「이 절은 녹음됨」을 안다.
    ('user_voice_asset', ''),
    # ★ 2026-10-15 77 — 기도 노트 보관분(폰이 백업을 켰을 때만 행이 있다) · 폰이 새로 깔리면 이것으로 되살린다
    ('user_prayer_backup', ''),
    # ★ 2026-10-16 영상 취향(`media_pref`) — 폰도 PC 와 같은 채널 ♥ · 영상 숨김 · 채널 숨김을 보인다
    ('user_channel_fav', ''),
    ('user_media_hide', ''),
    ('user_channel_hide', ''),
    # ★ 2026-10-23 추천몰 내 쇼핑몰 ★ — PC ↔ 폰 같은 즐겨찾기(사용자 합의 7)
    ('user_shop_fav', ''),
    ('user_shop_hide', ''),
    ('user_shop_mine', ''),
    ('user_shop_repeat', ''),
    # ★ 2026-10-24 docs/4.txt — 내가 모은 채널(최신 영상은 폰이 직접 받는다 · 그 목록은 안 보낸다)
    ('user_my_channel', ''),
    # ★ 2026-10-24 내가 모은 사이트(받은 글은 폰이 직접 받는다 · 그 목록은 안 보낸다)
    ('user_my_site', ''),
    # ★ 2026-10-28 공동체몰 파일 방식 — PC [몰 파일 만들기]의 마지막 몰 파일(몰마다 한 줄) → 관리자 폰이 카톡으로 나눈다
    ('user_cmall_outfile', ''),
)

DDL = (
    """CREATE TABLE IF NOT EXISTS userdb.user_cmall_outfile (
        file_id TEXT PRIMARY KEY,
        name    TEXT,
        ver     INTEGER,
        made    TEXT,
        data    TEXT)""",
    """CREATE TABLE IF NOT EXISTS userdb.user_my_site (
        feed_url   TEXT PRIMARY KEY,
        site_name  TEXT,
        page_url   TEXT,
        feed_kind  TEXT DEFAULT 'NEWS',
        created_at TEXT DEFAULT (datetime('now','localtime')))""",
    """CREATE TABLE IF NOT EXISTS userdb.user_my_channel (
        channel_id   TEXT PRIMARY KEY,
        channel_name TEXT,
        channel_url  TEXT,
        created_at   TEXT DEFAULT (datetime('now','localtime')))""",
    """CREATE TABLE IF NOT EXISTS userdb.user_mobile_device (
        device_id   TEXT PRIMARY KEY,
        name        TEXT,
        host        TEXT,
        port        INTEGER,
        key_hex     TEXT,          -- 짝 코드에서 지은 열쇠(코드는 안 남긴다)
        paired_at   TEXT,
        last_sync   TEXT,
        last_result TEXT,
        record_status TEXT DEFAULT 'LIVE')""",
    """CREATE TABLE IF NOT EXISTS userdb.user_mobile_inbox (
        inbox_id    INTEGER PRIMARY KEY AUTOINCREMENT,
        uuid        TEXT UNIQUE NOT NULL,   -- 폰이 지은 초안 번호(멱등 열쇠)
        device_id   TEXT,
        kind        TEXT NOT NULL,
        data        TEXT,                   -- JSON(폰이 보낸 그대로 · PC 에서 고치면 갱신)
        made_at     TEXT,                   -- 폰에서 쓴 때
        received_at TEXT,
        state       TEXT DEFAULT 'NEW',     -- NEW | ADOPTED | DISCARDED
        adopted_ref TEXT,                   -- 채택해 생긴 정본 자리
        note        TEXT)""",
    """CREATE TABLE IF NOT EXISTS userdb.user_mobile_event (
        uuid        TEXT PRIMARY KEY,       -- 같은 사건을 두 번 적지 않는다
        device_id   TEXT,
        kind        TEXT,
        data        TEXT,
        made_at     TEXT,
        applied_at  TEXT,
        result      TEXT)""",
)


SYNC_LOG_DDL = (
    """CREATE TABLE IF NOT EXISTS userdb.user_sync_change (
        seq   INTEGER PRIMARY KEY AUTOINCREMENT,
        tbl   TEXT NOT NULL,
        pk    TEXT NOT NULL,          -- 기본 열쇠 값의 JSON 배열
        op    TEXT,                   -- I | U | D
        ts    TEXT DEFAULT (datetime('now','localtime')))""",
)


def _now():
    return time.strftime('%Y-%m-%d %H:%M:%S')


def pk_cols(conn, tbl):
    return [r[1] for r in sorted(conn.execute('PRAGMA userdb.table_info(%s)' % tbl),
                                 key=lambda r: r[5]) if r[5]]


def install_triggers(conn):
    """보내는 표마다 추가·수정·삭제를 적는 트리거(멱등).

    ⚠ **짝 맺은 폰이 있을 때만** 적는다(WHEN) — 모바일을 안 쓰는 사람에게 부담 0.
    ⚠ 트리거 몸통은 **같은 DB(userdb) 표만** 가리킨다(§10-1 — 다른 스키마를 못 본다).
    """
    have = {r[0] for r in conn.execute(
        "SELECT name FROM userdb.sqlite_master WHERE type='table'")}
    live = ("EXISTS (SELECT 1 FROM user_mobile_device WHERE "
            "record_status='LIVE')")
    for tbl, _w in MIRROR_TABLES:
        if tbl not in have:
            continue
        pk = pk_cols(conn, tbl)
        if not pk:
            continue
        new = 'json_array(%s)' % ', '.join('NEW.%s' % c for c in pk)
        old = 'json_array(%s)' % ', '.join('OLD.%s' % c for c in pk)
        conn.execute(
            "CREATE TRIGGER IF NOT EXISTS userdb.trg_msync_%s_ai AFTER INSERT ON %s"
            " WHEN %s BEGIN INSERT INTO user_sync_change(tbl, pk, op)"
            " VALUES('%s', %s, 'I'); END" % (tbl, tbl, live, tbl, new))
        conn.execute(
            "CREATE TRIGGER IF NOT EXISTS userdb.trg_msync_%s_au AFTER UPDATE ON %s"
            " WHEN %s BEGIN INSERT INTO user_sync_change(tbl, pk, op)"
            " VALUES('%s', %s, 'U');"
            " INSERT INTO user_sync_change(tbl, pk, op) SELECT '%s', %s, 'D'"
            " WHERE %s <> %s; END" % (tbl, tbl, live, tbl, new, tbl, old, old, new))
        conn.execute(
            "CREATE TRIGGER IF NOT EXISTS userdb.trg_msync_%s_ad AFTER DELETE ON %s"
            " WHEN %s BEGIN INSERT INTO user_sync_change(tbl, pk, op)"
            " VALUES('%s', %s, 'D'); END" % (tbl, tbl, live, tbl, old))


def ensure(conn):
    for d in DDL + SYNC_LOG_DDL:
        conn.execute(d)
    cols = [r[1] for r in conn.execute('PRAGMA userdb.table_info(user_mobile_device)')]
    if 'sent_seq' not in cols:
        conn.execute('ALTER TABLE userdb.user_mobile_device ADD COLUMN sent_seq INTEGER')
    # ★ 2026-10-10 1.txt 54 — 「다운로드 안함」이면 폰의 글을 지울지 사람이 고른다(기본 = 안 지움)
    icols = [r[1] for r in conn.execute('PRAGMA userdb.table_info(user_mobile_inbox)')]
    if 'phone_drop' not in icols:
        conn.execute('ALTER TABLE userdb.user_mobile_inbox ADD COLUMN phone_drop INTEGER DEFAULT 0')
    if 'dropped_at' not in icols:
        conn.execute('ALTER TABLE userdb.user_mobile_inbox ADD COLUMN dropped_at TEXT')
    if 'checked_at' not in icols:
        # ⑥ 받은 글 최종 점검(2026-10-10) — 칸이 생긴 때를 적어 둔다: 그 전에 받은 글은 「예전 것」
        conn.execute('ALTER TABLE userdb.user_mobile_inbox ADD COLUMN checked_at TEXT')
        _cfg_set(conn, CHECK_SINCE_KEY, _now())
    # 폰에 보낸 자료 이력 — 보낸 때 · 걷은 때(다시 보낼지 사람이 판단하게)
    conn.execute("""CREATE TABLE IF NOT EXISTS userdb.user_mobile_sent (
        device_id TEXT, name TEXT, sha TEXT, bytes INTEGER,
        sent_at TEXT, gone_at TEXT,
        PRIMARY KEY (device_id, name, sha))""")
    try:                                   # ★ 87 — 녹음 진척 칸(표가 없으면 만든다 · 트리거가 그 표에 붙게 먼저)
        import voice_sync as _VS
        _VS.ensure(conn)
    except Exception:                      # noqa: BLE001
        pass
    try:                                   # ★ 2026-10-16 영상 취향 표 — 트리거가 붙게 먼저 만든다
        import media_pref as _MP
        _MP.init(conn)
    except Exception:                      # noqa: BLE001
        pass
    try:                                   # ★ 2026-10-23 추천몰 즐겨찾기 표 — 트리거가 붙게 먼저 만든다
        import db_shop as _SHOP
        _SHOP.ensure(conn, seed=False)
    except Exception:                      # noqa: BLE001
        pass
    try:                                   # ★ 2026-10-16 「읽는 중」 표 — 트리거가 붙게 먼저 만든다
        import db_read_state as _RS
        _RS.ensure_reading(conn)
    except Exception:                      # noqa: BLE001
        pass
    conn.execute("""CREATE TABLE IF NOT EXISTS userdb.user_prayer_backup (
        uid TEXT PRIMARY KEY, data TEXT, updated_at TEXT)""")
    install_triggers(conn)
    conn.commit()


# ══════════════════════════════════════════════════════════════════════
#  암호 — 표준 라이브러리만 (규격은 docs/mobile_sync.md)
# ══════════════════════════════════════════════════════════════════════
def _ib(n):
    return int(n).to_bytes(256, 'big')


def dh_pair():
    """(비밀 지수, 공개 값)."""
    a = secrets.randbits(320) | (1 << 319)
    return a, pow(DH_G, a, DH_P)


def session_key(secret, other_pub, pc_pub, phone_pub):
    """두 쪽이 같은 열쇠를 얻는다. 받은 공개 값이 이상하면 ValueError."""
    other_pub = int(other_pub)
    if not 1 < other_pub < DH_P - 1:
        raise ValueError('공개 값이 범위 밖이다')
    s = pow(other_pub, secret, DH_P)
    return hashlib.sha256(b'hagah-pair-v1' + _ib(s) + _ib(pc_pub) +
                          _ib(phone_pub)).digest()


def pair_id(key):
    """어느 열쇠로 잠갔나를 알리는 짧은 이름 — 열쇠 자체는 드러나지 않는다."""
    return hashlib.sha256(b'pair|' + key).hexdigest()[:16]


def _sub(key, label):
    return hmac.new(key, label, hashlib.sha256).digest()


def _stream(ekey, nonce, n):
    out = bytearray()
    ctr = 0
    while len(out) < n:
        out += hmac.new(ekey, nonce + ctr.to_bytes(8, 'big'),
                        hashlib.sha256).digest()
        ctr += 1
    return bytes(out[:n])


def seal(key, obj):
    """dict → 봉한 바이트. `HG1` + nonce(16) + 암호문 + 꼬리표(32)."""
    raw = zlib.compress(json.dumps(obj, ensure_ascii=False).encode('utf-8'), 6)
    nonce = secrets.token_bytes(16)
    ct = bytes(a ^ b for a, b in zip(raw, _stream(_sub(key, b'enc'), nonce,
                                                  len(raw))))
    tag = hmac.new(_sub(key, b'mac'), b'HG1' + nonce + ct,
                   hashlib.sha256).digest()
    return b'HG1' + nonce + ct + tag


def unseal(key, blob):
    """봉한 바이트 → dict. 꼬리표가 안 맞으면 ValueError(위변조·다른 열쇠)."""
    if not blob or blob[:3] != b'HG1' or len(blob) < 3 + 16 + 32:
        raise ValueError('봉투 꼴이 아니다')
    nonce, ct, tag = blob[3:19], blob[19:-32], blob[-32:]
    want = hmac.new(_sub(key, b'mac'), b'HG1' + nonce + ct,
                    hashlib.sha256).digest()
    if not hmac.compare_digest(tag, want):
        raise ValueError('꼬리표가 안 맞다 — 열쇠가 다르거나 고쳐진 글')
    raw = bytes(a ^ b for a, b in zip(ct, _stream(_sub(key, b'enc'), nonce,
                                                  len(ct))))
    return json.loads(zlib.decompress(raw).decode('utf-8'))


# ══════════════════════════════════════════════════════════════════════
#  PC 쪽 — 손님(client)
# ══════════════════════════════════════════════════════════════════════
class SyncError(Exception):
    pass


def _http(host, port, path, body, headers, timeout):
    req = urllib.request.Request('http://%s:%d%s' % (host, int(port), path),
                                 data=body, method='POST', headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        if e.code == 403:
            raise SyncError(_t('MOB_E_KEY', '폰이 거절했습니다 — 이 PC 와 짝을 맺은 폰이 '
                                            '아닙니다. 다시 연결하세요.'))
        raise SyncError(_t('MOB_E_HTTP', '폰이 오류를 냈습니다(HTTP %d).') % e.code)
    except Exception as e:                                # noqa: BLE001
        raise SyncError(_t('MOB_E_REACH', '폰에 닿지 못했습니다 — 같은 와이파이인지, 폰의 '
                                          '동기화 화면이 켜져 있는지 보세요. (%s)') % e)


def call_raw(host, port, key, op, data=None, timeout=20):
    """봉해서 묻고 봉한 답을 연다 → 답 dict(ok·why 를 그대로)."""
    rid = secrets.token_hex(8)
    body = seal(key, {'op': op, 'ts': int(time.time()), 'rid': rid,
                      'data': data or {}})
    blob = _http(host, port, PATH, body,
                 {'Content-Type': 'application/octet-stream',
                  'X-Hagah-Pair': pair_id(key)}, timeout)
    try:
        ans = unseal(key, blob)
    except ValueError as e:
        raise SyncError(_t('MOB_E_OPEN', '폰의 답을 열지 못했습니다(%s).') % e)
    if ans.get('rid') != rid:
        raise SyncError(_t('MOB_E_RID', '폰의 답이 이 요청의 것이 아닙니다.'))
    return ans


def call(host, port, key, op, data=None, timeout=20):
    ans = call_raw(host, port, key, op, data, timeout)
    if not ans.get('ok'):
        raise SyncError(_t('MOB_E_REFUSED', '폰이 거절했습니다: %s') % ans.get('why', ''))
    return ans.get('data') or {}


def local_targets(port=UDP_PORT):
    """방송할 곳 — 전체 방송 + 이 PC 의 /24 방송."""
    out = [('255.255.255.255', port)]
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('10.255.255.255', 1))        # 패킷은 안 나간다 — 내 주소만 알아낸다
        ip = s.getsockname()[0]
        s.close()
        out.append(('.'.join(ip.split('.')[:3] + ['255']), port))
    except Exception:                                     # noqa: BLE001
        pass
    return out


def _udp_ask(msg, want, targets=None, wait=3.0, should_stop=None, collect=False):
    """방송하고 답을 기다린다 → [(답 dict, 보낸 주소)]. collect=False 면 첫 답에서 끝."""
    targets = targets or local_targets()
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    s.bind(('', 0))
    s.settimeout(0.25)
    raw = json.dumps(msg).encode('utf-8')
    got, seen = [], set()
    end, nxt = time.time() + wait, 0
    try:
        while time.time() < end:
            if should_stop and should_stop():
                break
            if time.time() >= nxt:
                for t in targets:
                    try:
                        s.sendto(raw, t)
                    except OSError:
                        pass
                nxt = time.time() + 1.0
            try:
                data, addr = s.recvfrom(65535)
            except socket.timeout:
                continue
            except OSError:
                continue
            try:
                r = json.loads(data.decode('utf-8'))
            except Exception:                             # noqa: BLE001
                continue
            if not want(r):
                continue
            k = r.get('device_id') or addr
            if k in seen:
                continue
            seen.add(k)
            got.append((r, addr[0]))
            if not collect:
                break
    finally:
        s.close()
    return got


def scan_phones(targets=None, wait=3.0, should_stop=None):
    """연결 화면을 연 폰들 → [{device_id, name, host, port}] (이름으로 고르게)."""
    sess = secrets.token_hex(6)
    got = _udp_ask({'t': 'pair', 'v': PROTO, 's': sess, 'pc': socket.gethostname()},
                   lambda r: r.get('t') == 'offer' and r.get('s') == sess,
                   targets, wait, should_stop, collect=True)
    return [{'device_id': r.get('device_id'), 'name': r.get('name') or '',
             'host': ip, 'port': int(r.get('port') or PORT_DEFAULT)} for r, ip in got]


def confirm_code(A, B):
    """두 화면에 같이 뜨는 4자리 — 공개 값 둘에서만 나온다."""
    h = hashlib.sha256(b'hagah-confirm-v1' + _ib(A) + _ib(B)).digest()
    return '%04d' % (int.from_bytes(h[:8], 'big') % 10000)


def pair_with(db_path, phone, log=None, should_stop=None, wait=PAIR_WAIT,
              on_code=None):
    """선택한 폰과 짝을 맺는다 → device dict.

    ★ **4자리 숫자 확인**(사용자 확정 — 가족이 모두 앱을 쓰면 다른 폰과 맺을 수 있다).
      순서가 안전의 알맹이다 — **약속 → 답 → 공개**:
        ① PC 가 제 공개 값 A 의 해시만 보낸다(약속)
        ② 폰이 제 공개 값 B 를 돌려준다
        ③ PC 가 A 를 연다 — 폰은 해시가 맞는지 본다
      끼어든 사람은 B 를 보기 **전에** 제 값을 정해야 하므로 숫자를 골라 맞출 수
      없다(한 번에 1/10,000 · 틀리면 사람이 거절한다).
    """
    import appdb
    say = log or (lambda s: None)
    a, A = dh_pair()
    hdr = {'Content-Type': 'application/json'}

    def post(obj):
        blob = _http(phone['host'], phone['port'], PATH + '/pair',
                     json.dumps(obj).encode('utf-8'), hdr, 20)
        try:
            return json.loads(blob.decode('utf-8'))
        except Exception as e:                            # noqa: BLE001
            raise SyncError(_t('MOB_E_OPEN', '폰의 답을 열지 못했습니다(%s).') % e)

    r = post({'step': 1, 'v': PROTO, 'pc': socket.gethostname(),
              'c': hashlib.sha256(_ib(A)).hexdigest()})
    if int(r.get('v') or 0) != PROTO:
        raise SyncError(_t('MOB_E_PROTO', '폰 앱과 PC 앱의 동기화 판이 다릅니다(폰 %s · PC %s).')
                        % (r.get('v'), PROTO))
    if not r.get('ok'):
        raise SyncError(_t('MOB_E_REFUSED', '폰이 거절했습니다: %s') % r.get('why', ''))
    try:
        B = int(r['B'], 16)
        key = session_key(a, B, A, B)
    except Exception as e:                                # noqa: BLE001
        raise SyncError(_t('MOB_E_OPEN', '폰의 답을 열지 못했습니다(%s).') % e)
    r2 = post({'step': 2, 'sid': r.get('sid'), 'A': '%x' % A})
    if not r2.get('ok'):
        raise SyncError(_t('MOB_E_REFUSED', '폰이 거절했습니다: %s') % r2.get('why', ''))
    code = confirm_code(A, B)
    if on_code:
        on_code(code)
    say(_t('MOB_ASK_ALLOW', '「%s」 에 같은 숫자 %s 이(가) 보이면 폰에서 [허용]을 누르세요.')
        % (phone.get('name') or '', code))
    end = time.time() + wait
    while True:
        if should_stop and should_stop():
            raise SyncError(_t('MOB_E_STOPPED', '그만두었습니다.'))
        ans = call_raw(phone['host'], phone['port'], key, 'hello',
                       {'pc': socket.gethostname(), 'proto': PROTO})
        if ans.get('ok'):
            break
        if ans.get('why') == 'DENIED':
            raise SyncError(_t('MOB_E_DENIED', '폰에서 거절했습니다.'))
        if time.time() > end:
            raise SyncError(_t('MOB_E_TIMEOUT', '폰에서 [허용]을 누르지 않아 그만두었습니다.'))
        time.sleep(1.0)
    hi = ans.get('data') or {}
    did = (hi.get('device_id') or phone.get('device_id') or '').strip()
    if not did:
        raise SyncError(_t('MOB_E_NOID', '폰이 기기 번호를 안 알려 주었습니다.'))
    with appdb.connect(db_path) as conn:
        ensure(conn)
        conn.execute(
            "INSERT INTO userdb.user_mobile_device(device_id, name, host, port,"
            " key_hex, paired_at, record_status, sent_seq) VALUES(?,?,?,?,?,?,'LIVE',NULL)"
            " ON CONFLICT(device_id) DO UPDATE SET name=excluded.name,"
            " host=excluded.host, port=excluded.port, key_hex=excluded.key_hex,"
            " paired_at=excluded.paired_at, record_status='LIVE', sent_seq=NULL",
            (did, hi.get('device_name') or phone.get('name') or '', phone['host'],
             int(phone['port']), key.hex(), _now()))
        conn.commit()
        return device(conn, did)


def find_phone(dev, targets=None, wait=3.0):
    """짝 맺은 폰을 같은 와이파이에서 찾는다 → (host, port) | None.

    ★ 그 폰의 **열쇠 표식**(pair_id)으로만 묻는다 — 다른 가족의 폰은 대답하지 않는다.
    """
    pid = pair_id(dev['key'])
    got = _udp_ask({'t': 'find', 'v': PROTO, 'p': pid},
                   lambda r: r.get('t') == 'here' and r.get('p') == pid,
                   targets, wait)
    if not got:
        return None
    r, ip = got[0]
    return ip, int(r.get('port') or PORT_DEFAULT)


def devices(conn):
    ensure(conn)
    cur = conn.execute(
        "SELECT device_id, name, host, port, paired_at, last_sync, last_result, sent_seq"
        " FROM userdb.user_mobile_device WHERE record_status='LIVE'"
        " ORDER BY paired_at DESC")
    cols = [d[0] for d in cur.description]
    return [dict(zip(cols, r)) for r in cur.fetchall()]


def device(conn, device_id):
    ensure(conn)
    r = conn.execute(
        "SELECT device_id, name, host, port, key_hex, paired_at, last_sync,"
        " last_result, sent_seq FROM userdb.user_mobile_device"
        " WHERE device_id=? AND record_status='LIVE'", (device_id,)).fetchone()
    if not r:
        return None
    return {'device_id': r[0], 'name': r[1], 'host': r[2], 'port': r[3],
            'key': bytes.fromhex(r[4] or ''), 'paired_at': r[5],
            'last_sync': r[6], 'last_result': r[7], 'sent_seq': r[8]}


def set_address(conn, device_id, host, port):
    """폰 주소는 자주 바뀐다 — 열쇠는 두고 주소만 고친다."""
    conn.execute("UPDATE userdb.user_mobile_device SET host=?, port=?"
                 " WHERE device_id=?", (host, int(port), device_id))
    conn.commit()


def unpair(conn, device_id):
    conn.execute("UPDATE userdb.user_mobile_device SET record_status='HIDE',"
                 " key_hex='', sent_seq=NULL WHERE device_id=?", (device_id,))
    conn.commit()
    prune(conn)


# ── 사건 — 그 자리에서 저장 ────────────────────────────────────────
def _enr_of(conn, data):
    """사건이 가리키는 PC 등록 번호 — 폰에서 새로 등록한 것은 그 사건의 uuid 로."""
    if data.get('enrollment_id'):
        return int(data['enrollment_id'])
    eu = data.get('enroll_uuid')
    if eu:
        r = conn.execute("SELECT result FROM userdb.user_mobile_event"
                         " WHERE uuid=?", (eu,)).fetchone()
        if r and (r[0] or '').startswith('ENR:'):
            return int(r[0][4:])
    return None


MEDIA_PREF_TABLES = {'CH_FAV': ('user_channel_fav', 'channel_name'),
                     'M_HIDE': ('user_media_hide', 'media_id'),
                     'CH_HIDE': ('user_channel_hide', 'channel_name')}


def _media_pref(conn, d):
    """폰의 영상 취향 하나 → PC `media_pref` 표(켜기 = 넣기 · 끄기 = 지우기 · 멱등).

    ⚠ 뒤집기(`media_pref.toggle_*`)를 쓰지 않는다 — 같은 사건이 두 번 와도 결과가 같아야 한다.
    """
    import media_pref as _MP
    _MP.init(conn)
    t = MEDIA_PREF_TABLES.get(d.get('what') or '')
    key = d.get('key')
    if not t or key in (None, ''):
        return 'BAD'
    tbl, col = t
    if col == 'media_id':
        key = int(key)
    else:
        key = str(key).strip()
    have = conn.execute('SELECT 1 FROM userdb.%s WHERE %s=?' % (tbl, col), (key,)).fetchone()
    if d.get('on', True):
        if have:
            return 'SAME'
        conn.execute('INSERT INTO userdb.%s (%s) VALUES (?)' % (tbl, col), (key,))
        return 'ADDED'
    if not have:
        return 'SAME'
    conn.execute('DELETE FROM userdb.%s WHERE %s=?' % (tbl, col), (key,))
    return 'REMOVED'


def _shop_fav(conn, d, table='user_shop_fav', col='mall_code', field='mall'):
    """폰의 추천몰 표시들 → PC 사본 표(켜기 = 넣기 · 끄기 = 지우기 · 멱등).
    검색창 표시 `user_shop_fav` · 숨기기 `user_shop_hide` · 내 모음 `user_shop_mine` · 자주 사는 상품 `user_shop_repeat`(item)."""
    code = str(d.get(field) or '').strip()
    if col == 'mall_code':
        code = code.upper()
    if not code:
        return 'BAD'
    try:
        import db_shop
        db_shop.ensure(conn, seed=False)
    except Exception:
        pass
    have = conn.execute('SELECT 1 FROM userdb.%s WHERE %s=?' % (table, col), (code,)).fetchone()
    if d.get('on', True):
        if have:
            return 'SAME'
        conn.execute("INSERT INTO userdb.%s(%s, created_at) VALUES(?, datetime('now','localtime'))" % (table, col),
                     (code,))
        return 'ADDED'
    if not have:
        return 'SAME'
    conn.execute('DELETE FROM userdb.%s WHERE %s=?' % (table, col), (code,))
    return 'REMOVED'


def _shop_reco(conn, d):
    """폰의 「상품등록 추천하기」 → 관리자 소통 통로(kind SHOP) — 폰엔 그 통로가 없어 PC 가 대신 보낸다.
    보내지 못해도 user_feedback 이 이 PC 에 「안 보냄」으로 남긴다(사건은 끝낸다 — 폰에서 되풀이하지 않게)."""
    import db_shop
    if not str(d.get('name') or '').strip():
        return 'BAD'
    text = db_shop.recommend_text(d.get('name'), d.get('mall'), d.get('url'), d.get('memo') or '')
    try:
        import user_feedback as F
        ok, err = F.submit(conn, 'SHOP', text)
        return 'SENT' if ok else 'KEPT'
    except Exception:
        return 'KEPT'


def _my_channel(conn, d):
    """내가 모은 채널 하나 켜기/끄기(멱등 · 채널 번호 UC… 만 받는다)."""
    cid = str(d.get('id') or '').strip()
    if not re.fullmatch(r'UC[A-Za-z0-9_-]{22}', cid):
        return 'BAD'
    have = conn.execute('SELECT 1 FROM userdb.user_my_channel WHERE channel_id=?', (cid,)).fetchone()
    if d.get('on', True):
        name = str(d.get('name') or '')[:200]
        url = str(d.get('url') or '')[:300]
        if not url.startswith('https://www.youtube.com/'):
            url = ''
        if have:
            conn.execute('UPDATE userdb.user_my_channel SET channel_name=?, channel_url=? WHERE channel_id=?',
                         (name, url, cid))
            return 'SAME'
        conn.execute('INSERT INTO userdb.user_my_channel(channel_id, channel_name, channel_url) VALUES(?,?,?)',
                     (cid, name, url))
        return 'ADDED'
    if not have:
        return 'SAME'
    conn.execute('DELETE FROM userdb.user_my_channel WHERE channel_id=?', (cid,))
    return 'REMOVED'


def _my_site(conn, d):
    """내가 모은 사이트 하나 켜기/끄기(멱등 · 피드 주소 http(s) 만)."""
    import my_site as MS_
    feed = str(d.get('feed') or '').strip()
    if not MS_.ok_url(feed):
        return 'BAD'
    have = conn.execute('SELECT 1 FROM userdb.user_my_site WHERE feed_url=?', (feed,)).fetchone()
    if d.get('on', True):
        kind = str(d.get('kind') or 'NEWS')
        kind = kind if kind in MS_.KINDS else 'NEWS'
        page = str(d.get('page') or '')
        page = page if MS_.ok_url(page) else ''
        if not have:
            conn.execute('INSERT INTO userdb.user_my_site(feed_url) VALUES(?)', (feed[:500],))
        conn.execute('UPDATE userdb.user_my_site SET site_name=?, page_url=?, feed_kind=? WHERE feed_url=?',
                     (str(d.get('name') or '')[:200], page[:500], kind, feed[:500]))
        return 'SAME' if have else 'ADDED'
    if not have:
        return 'SAME'
    conn.execute('DELETE FROM userdb.user_my_site WHERE feed_url=?', (feed,))
    return 'REMOVED'


def _cmall_store(conn, d):
    """사장님 가게 파일 → 이 PC 의 그 파일 몰 대기(새 가게 · 고침 · 내리기). 그 몰이 이 PC 에 없으면 SKIP.
    ⚠ 같은 연결로 쓴다(따로 열면 동기화가 쥔 쓰기 잠금에 막힌다) · PC 화면의 몰 기억은 비운다(다시 읽게)."""
    import cmall_admin as CA_
    mid = str(d.get('mall') or '')
    m = next((x for x in CA_.load(conn) if x.get('url') == mid and CA_.is_file(x)), None)
    if m is None:
        return 'SKIP'

    class _Same:
        def __enter__(self):
            return conn

        def __exit__(self, *a):
            return False
    mall = CA_.FileMall(_Same, mid, m.get('name') or '', m.get('church') or '')
    CA_._FILE_MALLS.pop(mid, None)
    r = mall.take(d)
    return 'TAKEN' if r.get('ok') else 'BAD:%s' % r.get('err', '')


def _site_reco(conn, d):
    """폰의 「관리자에게 사이트 추천」 → 관리자 소통 통로(kind SITE) — PC 가 대신 보낸다."""
    if not str(d.get('name') or d.get('page') or '').strip():
        return 'BAD'
    try:
        import my_site as MS_
        ok, _err = MS_.recommend(conn, d.get('name') or '', d.get('page') or '', d.get('feed') or '')
        return 'SENT' if ok else 'KEPT'
    except Exception:
        return 'KEPT'


def ch_reco_text(name, url, cid='', vid=''):
    """채널 추천 글(관리자 소통 통로 kind CHANNEL) — 관리자 화면이 같은 꼴을 읽는다."""
    lines = ['[채널 추천]', '채널: %s' % (name or '').strip()]
    if url:
        lines.append('주소: %s' % url.strip())
    if cid:
        lines.append('채널 번호: %s' % cid.strip())
    if vid:
        lines.append('담은 영상: https://www.youtube.com/watch?v=%s' % vid.strip())
    return '\n'.join(lines)


def parse_ch_reco(text):
    """`ch_reco_text` 를 거꾸로 — 관리자 「추천 받은 채널」 탭이 읽는다 → {name, url, id, vid}."""
    out = {'name': '', 'url': '', 'id': '', 'vid': ''}
    keys = (('채널 번호:', 'id'), ('채널:', 'name'), ('주소:', 'url'), ('담은 영상:', 'vid'))
    for ln in (text or '').splitlines():
        ln = ln.strip()
        for head, k in keys:
            if ln.startswith(head):
                out[k] = ln[len(head):].strip()
                break
    m = re.search(r'[?&]v=([A-Za-z0-9_-]{11})', out['vid'])
    out['vid'] = m.group(1) if m else ''
    if not re.fullmatch(r'UC[A-Za-z0-9_-]{22}', out['id']):
        out['id'] = ''
    return out


def _ch_reco(conn, d):
    """폰의 「관리자에게 채널 추천」 → 관리자 소통 통로(kind CHANNEL) — PC 가 대신 보낸다."""
    if not str(d.get('name') or d.get('id') or '').strip():
        return 'BAD'
    text = ch_reco_text(d.get('name'), d.get('url') or '', d.get('id') or '', d.get('vid') or '')
    try:
        import user_feedback as F
        ok, _err = F.submit(conn, 'CHANNEL', text)
        return 'SENT' if ok else 'KEPT'
    except Exception:
        return 'KEPT'


def _phone_link(conn, kind, d):
    """폰 연결구절 ✎ → PC 덮개. LINK_HIDE {ids, on} · LINK_ADD {a, b, rel} · LINK_DEL {a, b, rel}."""
    import overlay
    ad = overlay.LinkOverlay()
    overlay.ensure_schema(conn)
    if kind == 'LINK_HIDE':
        n = 0
        for i in d.get('ids') or []:
            r = conn.execute("SELECT %s FROM sys_link_asset WHERE sys_link_id=? AND link_type='VERS_VERS'"
                             % ', '.join(ad.COLS), (int(i),)).fetchone()
            if not r:
                continue
            row = dict(zip(ad.COLS, r))
            if d.get('on', True):
                overlay.hide(conn, ad, row)
            else:
                overlay.revert(conn, ad, row)
            n += 1
        return ('HIDDEN' if d.get('on', True) else 'SHOWN') if n else 'SKIP'
    try:
        a, b = sorted((int(d['a']), int(d['b'])))
    except Exception:                                     # noqa: BLE001
        return 'SKIP'
    if a == b:
        return 'SKIP'
    rel = (d.get('rel') or 'REF').upper()
    row = {'link_type': 'VERS_VERS', 'clicked_id': a, 'target_id': b, 'rel_code': rel, 'end_id': None,
           'note': 'PHONE', 'chain_code': None, 'sort_order': None}
    if kind == 'LINK_ADD':
        r = overlay.save(conn, ad, row)
        # ★ 2026-10-20 폰이 더할 때 적은 연결설명문(또 오면 고친 글) — 내 연결이면 내 글, 앱 연결이면 덮개
        if (d.get('desc') or '').strip():
            import verse_link_edit as _VLE
            _VLE.save_link_desc(conn, row, (d.get('lang') or 'KO').upper(), d['desc'])
        return r
    if ad.sys_has(conn, ad.key_of(row)):
        return 'SKIP'                                     # 앱 연결은 지우지 않는다(숨기기만)
    overlay.revert(conn, ad, row)
    return 'DELETED'


def apply_event(conn, kind, d):
    """사건 하나를 정본에 적는다 → 결과 글자. 커밋은 부르는 쪽."""
    if kind == 'VERSE_TOPIC':                   # ★ 2026-10-29 때에 맞는 말씀 — 폰에서 고친 주제·구절
        import db_verse_topic as _VT
        return 'VT:' + _VT.apply_event(conn, d)
    if kind == 'NEWS_PREF':
        import news_pref as _NP
        return 'NEWS_PREF:%s' % ('OK' if _NP.apply_from_phone(conn, d, commit=False) else 'OLD')
    if kind == 'FAV_SET' and (d.get('fav_type') or '') == 'LISTEN':
        # ★ 2026-10-11 즐겨듣기 — 열쇠가 영상 번호(label)라 아래 일반 즐겨찾기 규칙(target_id)과 다르다
        import listen as _LS
        return _LS.set_on(conn, d.get('label') or '', d.get('note') or '', d.get('on', True), d.get('at'),
                         d.get('kind') or '')
    if kind == 'FAV_SET':
        ft = d.get('fav_type') or 'VERSE'
        tid, vid = d.get('target_id'), d.get('verse_id')
        w = ("fav_type=? AND COALESCE(target_id,-1)=COALESCE(?,-1)"
             " AND COALESCE(verse_id,-1)=COALESCE(?,-1)")
        live = conn.execute("SELECT fav_id FROM user_favorite WHERE " + w +
                            " AND record_status='LIVE'", (ft, tid, vid)).fetchone()
        if d.get('on', True):
            if live:
                return 'SAME'
            hid = conn.execute("SELECT fav_id FROM user_favorite WHERE " + w +
                               " AND record_status='HIDE' ORDER BY fav_id DESC",
                               (ft, tid, vid)).fetchone()
            if hid:
                conn.execute("UPDATE user_favorite SET record_status='LIVE'"
                             " WHERE fav_id=?", (hid[0],))
                return 'REVIVED'
            conn.execute(
                "INSERT INTO user_favorite(fav_type, target_id, verse_id,"
                " source_code, label, note, created_at, record_status)"
                " VALUES(?,?,?,?,?,?,?,'LIVE')",
                (ft, tid, vid, d.get('source_code') or 'USER',
                 d.get('label') or '', '', d.get('at') or _now()))
            return 'ADDED'
        if live:
            conn.execute("UPDATE user_favorite SET record_status='HIDE'"
                         " WHERE fav_id=?", (live[0],))
            return 'REMOVED'
        return 'SAME'
    if kind in ('LINK_HIDE', 'LINK_ADD', 'LINK_DEL'):
        return _phone_link(conn, kind, d)
    if kind == 'AI_CHAT':
        import ai_chat_sync as _ACS                    # ★ 2026-10-20 바통 규칙(내 쪽이 그사이 안 고쳤으면 바꾸고 · 둘 다면 사본)
        return _ACS.put(conn, d, 'PHONE')
    if kind == 'AI_LIB':
        import ai_lib as _AL
        return _AL.apply_phone(conn, d)
    if kind == 'AI_PROMPT':
        import user_ai as _UA
        if d.get('deleted'):                       # 폰에서 지운 내 기도 프롬프트
            return 'HIDDEN' if _UA.hide_prayer_prompt(conn, d.get('kind') or '', d.get('lang')) else 'SKIP'
        ok = _UA.put_prayer_prompt(conn, d.get('kind') or '', d.get('lang') or 'KO',
                                   title=d.get('title'), body=d.get('body'))
        return 'SAVED' if ok else 'SKIP'
    if kind == 'PRAYER_SAVE':
        uid = (d.get('uid') or '').strip()
        if not uid:
            return 'SKIP'
        if d.get('deleted'):
            conn.execute('DELETE FROM userdb.user_prayer_backup WHERE uid=?', (uid,))
            return 'REMOVED'
        data = json.dumps(d.get('data') or {}, ensure_ascii=False, sort_keys=True)
        old = conn.execute('SELECT data FROM userdb.user_prayer_backup WHERE uid=?', (uid,)).fetchone()
        if old and old[0] == data:
            return 'SAME'
        conn.execute('INSERT OR REPLACE INTO userdb.user_prayer_backup(uid, data, updated_at) VALUES(?,?,?)',
                     (uid, data, d.get('at') or _now()))
        return 'SAVED'
    if kind == 'PRAYER_CLEAR':
        conn.execute('DELETE FROM userdb.user_prayer_backup')
        return 'CLEARED'
    if kind == 'PLAN_IMPORT':
        import plan_share as PS
        st, pid, msg = PS.put_plan(conn, d.get('plan') or {})
        return 'FAIL:' + msg if st == 'BAD' else '%s:%s' % (st, pid)
    if kind == 'PLAN_ENROLL':
        pid, upid = d.get('plan_id'), d.get('user_plan_id')
        if d.get('plan_key') and not pid and not upid:
            # ★ 폰에서 받은 플랜 — 열쇠로 이 PC 의 플랜을 찾는다(PLAN_IMPORT 가 먼저 왔다)
            import plan_share as PS
            hit = PS.find(conn, d['plan_key'])
            if not hit:
                return 'FAIL:NO_PLAN'
            if hit[0] == 'SYS':
                pid = hit[1]
            else:
                upid = hit[1]
                pid = conn.execute("SELECT origin_plan_id FROM user_bible_plan WHERE user_plan_id=?",
                                   (upid,)).fetchone()[0]
        ex = conn.execute(
            "SELECT enrollment_id FROM user_plan_enrollment WHERE"
            " COALESCE(plan_id,-1)=COALESCE(?,-1) AND"
            " COALESCE(user_plan_id,-1)=COALESCE(?,-1) AND"
            " enrollment_status='ACTIVE' AND COALESCE(record_status,'LIVE')='LIVE'",
            (pid, upid)).fetchone()
        if ex:
            return 'ENR:%d' % ex[0]          # 이미 PC 에서 진행 중 — 그것을 쓴다
        cur = conn.execute(
            "INSERT INTO user_plan_enrollment(plan_id, start_date, current_day,"
            " enrollment_status, record_status, user_plan_id)"
            " VALUES(?,?,1,'ACTIVE','LIVE',?)",
            (pid, d.get('start_date') or time.strftime('%Y-%m-%d'), upid))
        return 'ENR:%d' % cur.lastrowid
    if kind == 'PLAN_ABANDON':
        eid = _enr_of(conn, d)
        if not eid:
            return 'FAIL:NO_ENROLLMENT'
        conn.execute("UPDATE user_plan_enrollment SET enrollment_status='ABANDONED'"
                     " WHERE enrollment_id=? AND enrollment_status='ACTIVE'", (eid,))
        return 'OK'
    if kind == 'PLAN_DAY_DONE':
        import plan_progress
        eid = _enr_of(conn, d)
        if not eid:
            return 'FAIL:NO_ENROLLMENT'
        r = plan_progress.mark_day(conn, eid, int(d.get('day') or 0),
                                   d.get('date'))
        return 'OK' if r['ok'] else 'FAIL:' + r['why']
    if kind in ('BOOK_POS', 'BOOK_START', 'BOOK_STOP', 'BOOK_READ') and d.get('book_id') is not None:
        import db_mobile_core as _MC              # ★ 2026-10-28 폰의 조각 책(스펄전 설교 묶음) → PC 의 원래 책
        d = dict(d, book_id=_MC.real_book_id(d['book_id']))
    if kind == 'BOOK_POS':
        import db_read_state as RS
        RS.ensure_pos(conn)
        k = d.get('kind') or 'BOOK'
        at = d.get('at') or _now()
        cur = conn.execute("SELECT updated_at FROM user_book_pos WHERE kind=?"
                           " AND book_id=?", (k, int(d['book_id']))).fetchone()
        if cur and (cur[0] or '') >= at:
            return 'OLDER'                    # PC 쪽이 더 나중에 읽었다
        RS.set_pos(conn, int(d['book_id']), int(d['unit_id']), kind=k)
        conn.execute("UPDATE user_book_pos SET updated_at=? WHERE kind=?"
                     " AND book_id=?", (at, k, int(d['book_id'])))
        return 'OK'
    if kind == 'MEDIA_PREF':
        return _media_pref(conn, d)
    if kind == 'SHOP_FAV':
        return _shop_fav(conn, d)
    if kind == 'SHOP_HIDE':
        return _shop_fav(conn, d, 'user_shop_hide')
    if kind == 'SHOP_MINE':
        return _shop_fav(conn, d, 'user_shop_mine')
    if kind == 'SHOP_REPEAT':
        return _shop_fav(conn, d, 'user_shop_repeat', 'item_key', 'item')
    if kind == 'SHOP_RECO':
        return _shop_reco(conn, d)
    if kind == 'MY_CHANNEL':
        return _my_channel(conn, d)
    if kind == 'CH_RECO':
        return _ch_reco(conn, d)
    if kind == 'MY_SITE':
        return _my_site(conn, d)
    if kind == 'CMALL_STORE':
        return _cmall_store(conn, d)
    if kind == 'SITE_RECO':
        return _site_reco(conn, d)
    if kind == 'PACK_DROP':
        name = str(d.get('name') or '')
        m = re.match(r'mobile_book_(.+)_([A-Z]+)\.json\.gz$', name)
        if not m:
            return 'SKIP'
        code, lg = m.group(1), m.group(2)
        cur = get_send(conn)
        keep = [b for b in cur['books'] if book_entry(b, lg) != (code, lg)]
        if len(keep) != len(cur['books']):
            set_send(conn, books=keep)
            return 'DROPPED'
        return 'SAME'
    if kind in ('BOOK_START', 'BOOK_STOP'):
        import db_read_state as RS
        k = d.get('kind') or 'BOOK'
        if kind == 'BOOK_START':
            RS.start_reading(conn, int(d['book_id']), kind=k, when=d.get('at'))
        else:
            RS.stop_reading(conn, int(d['book_id']), kind=k)
        return 'OK'
    if kind == 'BOOK_READ':
        import db_read_state as RS
        RS.ensure(conn)
        k = d.get('kind') or 'BOOK'
        if d.get('on', True):
            RS.mark(conn, int(d['unit_id']), d.get('book_id'),
                    d.get('at'), kind=k)
        else:
            RS.unmark(conn, int(d['unit_id']), kind=k)
        return 'OK'
    if kind == 'SAVE_LINK':
        import yt_intake as YT
        url, title = (d.get('url') or '').strip(), (d.get('title') or '').strip()
        lang = (d.get('lang') or 'KO').upper()
        if YT.parse(url):
            had = YT.find_media(conn, YT.parse(url)[1])
            # ★ 2026-10-14 — 폰은 수집기 · PC 가 갈래를 나누고 제목의 구절·용어를 잇는다(yt_intake.collect)
            uid, _n, _t = YT.collect(conn, url, title, lang)
            return ('SAME:MEDIA:%d' if had else 'ADDED:MEDIA:%d') % uid
        if YT.parse_web(url):
            had = YT.find_web(conn, YT.parse_web(url))
            rid, _n = YT.save_web(conn, url, title, (), (), lang)
            return ('SAME:WEB:%d' if had else 'ADDED:WEB:%d') % rid
        return 'FAIL:NOT_A_LINK'
    return 'FAIL:UNKNOWN_KIND'


# ── 초안 — 받아 두고 사람이 정리 ──────────────────────────────────
def check_draft(kind, d):
    """초안 문지기 — 빈 글·닻 없는 노트는 받지 않는다(미아 금지). '' = 통과."""
    if kind not in DRAFT_KINDS:
        return 'UNKNOWN_KIND'
    body = (d.get('body') or d.get('contents') or '').strip()
    if kind == 'AI':
        if not d.get('msgs'):
            return 'EMPTY'
        return ''
    if kind == 'NOTE_DEL':                                 # 지우기는 글 없이 온다
        return '' if d.get('note_id') else 'NO_TARGET'
    # ★ 2026-10-14 폰 설명 판 ⋯ — 「안 보이기(HIDE)」·「원래 글로(REVERT)」는 글 없이 온다
    if kind == 'DESC' and d.get('action') in ('HIDE', 'REVERT'):
        return '' if (d.get('text_type') and d.get('clicked_id')) else 'NO_TARGET'
    if not body:
        return 'EMPTY'
    if kind == 'NOTE' and not (d.get('start_vid') or d.get('unit')):
        return 'NO_ANCHOR'
    if kind in ('NOTE_ADD', 'NOTE_EDIT') and not d.get('note_id'):
        return 'NO_TARGET'
    if kind == 'DESC' and not (d.get('text_type') and d.get('clicked_id')):
        return 'NO_TARGET'
    return ''


def store_draft(conn, device_id, item):
    """초안을 함에 넣는다 → 'NEW' | 'DUP' | 'BAD:<까닭>'. 커밋은 부르는 쪽."""
    kind, d = item.get('kind'), item.get('data') or {}
    why = check_draft(kind, d)
    if why:
        return 'BAD:' + why
    try:
        conn.execute(
            "INSERT INTO userdb.user_mobile_inbox(uuid, device_id, kind, data,"
            " made_at, received_at, state) VALUES(?,?,?,?,?,?,'NEW')",
            (item['uuid'], device_id, kind, json.dumps(d, ensure_ascii=False),
             item.get('made_at') or '', _now()))
        return 'NEW'
    except Exception as e:                                # noqa: BLE001
        if 'UNIQUE' in str(e).upper():
            return 'DUP'
        raise


def inbox(conn, state='NEW'):
    ensure(conn)
    q = ("SELECT inbox_id, uuid, device_id, kind, data, made_at, received_at,"
         " state, adopted_ref, note FROM userdb.user_mobile_inbox")
    args = ()
    if state:
        q += " WHERE state=?"
        args = (state,)
    q += " ORDER BY made_at, inbox_id"
    out = []
    for r in conn.execute(q, args):
        out.append({'inbox_id': r[0], 'uuid': r[1], 'device_id': r[2],
                    'kind': r[3], 'data': json.loads(r[4] or '{}'),
                    'made_at': r[5], 'received_at': r[6], 'state': r[7],
                    'adopted_ref': r[8], 'note': r[9]})
    return out


def update_draft(conn, inbox_id, data):
    """PC 에서 다듬은 글을 함에 그대로 적어 둔다(채택 전 저장)."""
    conn.execute("UPDATE userdb.user_mobile_inbox SET data=? WHERE inbox_id=?",
                 (json.dumps(data, ensure_ascii=False), int(inbox_id)))
    conn.commit()


def discard(conn, inbox_id, note='', phone_drop=False):
    """「다운로드 안함」 — PC 에 들이지 않는다. phone_drop 이면 다음 동기화 때 폰의 글도 지운다
    (기본 = 안 지움 · 사용자 확정 2026-10-10)."""
    conn.execute("UPDATE userdb.user_mobile_inbox SET state='DISCARDED', note=?, phone_drop=?"
                 " WHERE inbox_id=?", (note or '', 1 if phone_drop else 0, int(inbox_id)))
    conn.commit()


# ══════════════════════════════════════════════════════════════════════
#  ⑥ 받은 글 최종 점검 — PC 에 들인 글이 지금 어디에 있고 다 봤는가
# ══════════════════════════════════════════════════════════════════════
CHECK_SINCE_KEY = 'MOBILE_CHECK_SINCE'   # checked_at 칸이 생긴 때 — 그 전에 받은 글은 「예전 것」


def adopt_all(db_path):
    """다운로드 대기 글 **전부**를 PC 에 들인다 → (들인 수, [(inbox_id, 까닭)]).

    ★ 2026-10-12 사용자 「다운로드 처음 시작은 모바일 앱」 — 폰을 오래 쓰다 PC 를 처음 이으면 초안이 수백 개라
      하나씩 고를 수 없다(첫 이주). 들인 글은 「⑥ 받은 글 점검」에 그대로 남아 나중에 본다.
    ⚠ 하나가 실패해도 나머지는 들인다 — 실패한 것은 대기에 남는다.
    """
    import appdb
    with appdb.connect(db_path) as conn:
        ids = [r['inbox_id'] for r in inbox(conn, 'NEW')]
    n, bad = 0, []
    for i in ids:
        try:
            adopt(db_path, i)
            n += 1
        except Exception as e:                            # noqa: BLE001
            bad.append((i, str(e)[:80]))
    return n, bad


def review(conn, which='TODO'):
    """PC 에 들인 글(ADOPTED) — `TODO` 점검 남음 · `DONE` 점검 끝 · `ALL`.
    「다운로드 안함」은 점검 대상이 아니다(PC 에 없다)."""
    ensure(conn)
    q = ("SELECT inbox_id, uuid, device_id, kind, data, made_at, received_at, state,"
         " adopted_ref, note, checked_at FROM userdb.user_mobile_inbox WHERE state='ADOPTED'")
    if which == 'TODO':
        q += " AND checked_at IS NULL"
    elif which == 'DONE':
        q += " AND checked_at IS NOT NULL"
    q += " ORDER BY received_at DESC, inbox_id DESC"
    return [{'inbox_id': r[0], 'uuid': r[1], 'device_id': r[2], 'kind': r[3],
             'data': json.loads(r[4] or '{}'), 'made_at': r[5], 'received_at': r[6],
             'state': r[7], 'adopted_ref': r[8], 'note': r[9], 'checked_at': r[10]}
            for r in conn.execute(q)]


def set_checked(conn, inbox_id, on=True):
    """점검 끝 / 다시 점검 — 표시일 뿐이다(받은 것을 되돌리지 않는다)."""
    conn.execute("UPDATE userdb.user_mobile_inbox SET checked_at=? WHERE inbox_id=?"
                 " AND state='ADOPTED'", (_now() if on else None, int(inbox_id)))
    conn.commit()


def old_unchecked(conn):
    """이 기능이 생기기 전에 받아 둔 글 가운데 점검 표시가 없는 것의 번호."""
    since = _cfg(conn, CHECK_SINCE_KEY, '')
    if not since:
        return []
    return [r[0] for r in conn.execute(
        "SELECT inbox_id FROM userdb.user_mobile_inbox WHERE state='ADOPTED'"
        " AND checked_at IS NULL AND COALESCE(received_at,'') < ?", (since,))]


def check_all(conn, ids):
    conn.executemany("UPDATE userdb.user_mobile_inbox SET checked_at=? WHERE inbox_id=?",
                     [(_now(), int(i)) for i in ids])
    conn.commit()


def where_is(conn, row):
    """그 글이 PC 의 어디에 있나 — 받을 때 적어 둔 자리(`adopted_ref`)를 **지금** 다시 본다.

    → `{kind, alive, vid, end_vid, note_id, unit, ref_id, chat_id, text_type, clicked_id, title}`.
    `alive=False` = 받은 뒤 그 자리에서 지워졌다(사람이 PC 에서 지웠다)."""
    ref = (row.get('adopted_ref') or '').split(' · ')[0]
    key = ref.split(':')
    out = {'kind': row['kind'], 'alive': False}
    try:
        if key[0] == 'NOTE':
            nid = int(key[1])
            r = conn.execute("SELECT text_type, clicked_id, target_id, title, record_status"
                             " FROM user_text_asset WHERE user_text_id=?", (nid,)).fetchone()
            out['note_id'] = nid
            if r:
                out['alive'] = (r[4] or 'LIVE') != 'HIDE'
                out['title'] = r[3] or ''
                if r[0] == 'VERS_NOTE':
                    out['vid'] = r[1]
                    out['end_vid'] = r[2] or r[1]
                else:
                    out['unit'] = (r[0], r[1])
        elif key[0] == 'DESC':
            out['text_type'], out['clicked_id'] = key[1], int(key[2])
            out['alive'] = True
            tt, cid = key[1], int(key[2])
            vid = None
            if tt.startswith('VERS_'):
                vid = cid
            elif tt == 'CHAP_DESC':
                r = conn.execute("SELECT MIN(verse_id) FROM bible_index WHERE bcode=? AND chapter=?",
                                 (cid // 1000, cid % 1000)).fetchone()
                vid = r[0] if r else None
            elif tt == 'PERI_DESC':
                r = conn.execute("SELECT start_vid FROM sys_pericope_asset WHERE pericope_id=?",
                                 (cid,)).fetchone()
                vid = r[0] if r else None
            elif tt == 'BOOK_DESC':
                r = conn.execute("SELECT MIN(verse_id) FROM bible_index WHERE bcode=?", (cid,)).fetchone()
                vid = r[0] if r else None
            out['vid'] = vid
        elif key[0] == 'REF':
            rid = int(key[1])
            r = conn.execute("SELECT title, record_status FROM user_ref_asset WHERE ref_id=?",
                             (rid,)).fetchone()
            out['ref_id'] = rid
            if r:
                out['alive'] = (r[1] or 'LIVE') != 'HIDE'
                out['title'] = r[0] or ''
        elif key[0] == 'AI':
            cid = int(key[1])
            r = conn.execute("SELECT title, COALESCE(record_status,'LIVE'), ref_id FROM user_ai_chat"
                             " WHERE chat_id=?", (cid,)).fetchone()
            out['chat_id'] = cid
            if r:
                out['alive'] = r[1] != 'HIDE'
                out['title'] = r[0] or ''
                rid = r[2]
                if rid and conn.execute("SELECT 1 FROM user_ref_asset WHERE ref_id=? AND"
                                        " COALESCE(record_status,'LIVE')<>'HIDE'", (rid,)).fetchone():
                    out['ref_id'] = int(rid)
    except Exception:                                     # noqa: BLE001
        pass
    return out


def drafts_to_drop(conn, device_id):
    """폰에 「이제 지워도 된다」고 알릴 초안 — PC 에 들인 것(사본이 대신한다) ·
    다운로드 안함 + 폰에서도 지우기를 고른 것."""
    return [r[0] for r in conn.execute(
        "SELECT uuid FROM userdb.user_mobile_inbox WHERE device_id=? AND dropped_at IS NULL"
        " AND (state='ADOPTED' OR (state='DISCARDED' AND COALESCE(phone_drop,0)=1))",
        (device_id,))]


def sent_history(conn, device_id):
    """폰에 보낸 자료 이력 → [{name, sha, bytes, sent_at, gone_at}] (최근 먼저)."""
    return [{'name': r[0], 'sha': r[1], 'bytes': r[2], 'sent_at': r[3], 'gone_at': r[4]}
            for r in conn.execute(
                "SELECT name, sha, bytes, sent_at, gone_at FROM userdb.user_mobile_sent"
                " WHERE device_id=? ORDER BY sent_at DESC", (device_id,))]


PHONE_PACKS_KEY = 'MOBILE_PHONE_PACKS'   # 마지막 동기화 때 폰이 말한 팩 목록(JSON) — 망 없이도 화면이 보인다


def phone_packs(conn):
    try:
        return json.loads(_cfg(conn, PHONE_PACKS_KEY, '') or '[]')
    except ValueError:
        return []


def current_for(conn, item):
    """설명문·덧붙이기 초안이 가리키는 **지금 PC 의 글** — 견주어 보라고."""
    d = item['data']
    if item['kind'] == 'DESC':
        try:
            import overlay_edit as OE
            var, state, sys_t, mine = OE.pair_state(
                conn, d['text_type'], int(d['clicked_id']),
                d.get('lang') or 'KO', d.get('variant') or '')
            return mine or sys_t or ''
        except Exception:                                 # noqa: BLE001
            return ''
    if item['kind'] in ('NOTE_ADD', 'NOTE_EDIT', 'NOTE_DEL'):
        r = conn.execute("SELECT contents FROM user_text_asset WHERE"
                         " user_text_id=?", (int(d['note_id']),)).fetchone()
        return (r[0] or '') if r else ''
    # ★ 2026-10-25 (3단계) 폰이 고친 내 연구/설교노트 — 지금 PC 글(표는 `|` 꼴로 펴서)
    if item['kind'] == 'REF' and d.get('ref_id'):
        try:
            import ref_doc as _RD
            lg = (d.get('lang') or 'KO').upper()
            r = conn.execute("SELECT title, body_text FROM user_ref_text WHERE ref_id=? AND UPPER(lang_code)=?",
                             (int(d['ref_id']), lg)).fetchone()
            if not r:
                return ''
            tb = _RD.get_tables(conn, 'USER', int(d['ref_id']), lg)
            return ((r[0] or '') + '\n\n' + _RD.expand(r[1] or '', tb, 'pipe')).strip()
        except Exception:                                 # noqa: BLE001
            return ''
    return ''


def adopt(db_path, inbox_id):
    """초안을 정본으로 들인다 → 생긴 자리(글자). 실패는 ValueError(사람 말).

    ⚠ 각 저장 문이 **제 연결로** 커밋하는 것이 있다(medi_note) — 그래서 여기서는
      db_path 를 받아 단계마다 연결을 열고 닫는다(한 연결이 쓰기 잠금을 쥔 채
      다른 연결을 기다리면 멎는다).
    """
    import appdb
    with appdb.connect(db_path) as conn:
        ensure(conn)
        rows = [x for x in inbox(conn, state=None) if x['inbox_id'] == int(inbox_id)]
    if not rows:
        raise ValueError(_t('MOB_E_NODRAFT', '그 초안이 없습니다.'))
    it = rows[0]
    if it['state'] != 'NEW':
        raise ValueError(_t('MOB_E_DONE', '이미 정리한 초안입니다.'))
    k, d = it['kind'], it['data']
    lang = (d.get('lang') or 'KO').upper()
    body = (d.get('body') or d.get('contents') or '').strip()
    ref = ''
    if k == 'NOTE':
        import medi_note
        unit = tuple(d['unit']) if d.get('unit') else None
        if unit:
            with appdb.connect(db_path) as conn:
                ok = conn.execute(
                    "SELECT 1 FROM sys_book_unit WHERE unit_id=?",
                    (int(unit[1]),)).fetchone() if unit[0] == 'BOOK' else True
            if not ok:
                raise ValueError(_t('MOB_E_UNIT', '이 노트가 붙은 도서 편이 PC 에 없습니다 — '
                                    '책을 다시 나눈 사이에 쓴 글입니다.'))
        # ★ 2026-10-14 docs/1.txt 86-4 — 폰의 플랜 하루·렌즈 노드 노트는 **PC 와 같은 출처 열쇠**를 싣고 온다
        #   (`PLAN:<코드>:<일차>` · `LENS:<렌즈>:<노드>`) — 그대로 넘겨 PC 의 그 자리 노트 목록에 들어가게 한다.
        nid = medi_note.save_new(db_path, d.get('start_vid'), d.get('end_vid'),
                                 body, lang=lang, title=d.get('title') or '',
                                 unit=unit, src_key=d.get('src_key') or '',
                                 src_label=d.get('src_label') or '',
                                 question=d.get('question') or '')
        ref = 'NOTE:%d' % nid
    elif k in ('NOTE_EDIT', 'NOTE_DEL'):
        import medi_note
        with appdb.connect(db_path) as conn:
            r = conn.execute("SELECT 1 FROM user_text_asset WHERE user_text_id=? AND"
                             " COALESCE(record_status,'LIVE')<>'HIDE'", (int(d['note_id']),)).fetchone()
        if not r:
            raise ValueError(_t('MOB_E_NONOTE2', '고칠 노트가 PC 에 없습니다(이미 지웠을 수 있습니다).'))
        if k == 'NOTE_EDIT':
            # 출처·질문 머리 줄은 그대로 · ★ 2026-10-21 도서노트는 「구절에도 연결」 켜고 끄기를 함께 싣고 온다
            medi_note.update_note(db_path, int(d['note_id']), body,
                                  start_vid=d.get('start_vid'), end_vid=d.get('end_vid'),
                                  link=d.get('link'))
        else:
            medi_note.hide_note(db_path, int(d['note_id']))             # 지우지 않고 HIDE(되돌릴 수 있다)
        ref = 'NOTE:%d' % int(d['note_id'])
    elif k == 'NOTE_ADD':
        import medi_note
        with appdb.connect(db_path) as conn:
            r = conn.execute("SELECT contents FROM user_text_asset WHERE"
                             " user_text_id=? AND COALESCE(record_status,'LIVE')"
                             "<>'HIDE'", (int(d['note_id']),)).fetchone()
        if not r:
            raise ValueError(_t('MOB_E_NONOTE', '덧붙일 노트가 PC 에 없습니다(지웠을 수 있습니다).'))
        old = medi_note.parse(r[0])['body'] if hasattr(medi_note, 'parse') else r[0]
        medi_note.update_note(db_path, int(d['note_id']),
                              (old or '').rstrip() + '\n' + body)
        ref = 'NOTE:%d' % int(d['note_id'])
    elif k == 'DESC':
        import overlay_edit as OE
        with appdb.connect(db_path) as conn:
            act = d.get('action') or ''
            if act == 'HIDE':
                OE.hide_sys(conn, d['text_type'], int(d['clicked_id']), lang, d.get('variant') or None)
                st = 'HIDE'
            elif act == 'REVERT':
                OE.revert_mine(conn, d['text_type'], int(d['clicked_id']), lang, d.get('variant') or None)
                st = 'REVERT'
            else:
                st = OE.save_mine(conn, d['text_type'], int(d['clicked_id']), lang,
                                  d.get('variant') or None, body)
            conn.commit()
        ref = 'DESC:%s:%s:%s' % (d['text_type'], d['clicked_id'], st)
    elif k == 'REF':
        import db_user_ref_schema as U
        import user_ai
        with appdb.connect(db_path) as conn:
            U.init(conn)
            # ★ 2026-10-25 (3단계) 폰에서 PC 의 내 글을 고친 것 — `ref_id` 가 오면 새 글이 아니라 **그 글을 고친다**
            edit = None
            if d.get('ref_id'):
                r0 = conn.execute("SELECT ref_id, COALESCE(ref_origin,'') FROM user_ref_asset WHERE ref_id=?"
                                  " AND COALESCE(record_status,'LIVE')<>'HIDE'", (int(d['ref_id']),)).fetchone()
                if not r0:
                    raise ValueError(_t('MOB_E_NOREF', '고칠 연구/설교노트가 PC 에 없습니다(지웠을 수 있습니다).'))
                edit = r0
            if edit:
                rid = int(edit[0])
                conn.execute("UPDATE user_ref_asset SET title=? WHERE ref_id=?", (d.get('title') or '(제목 없음)', rid))
                if d.get('ref_type'):
                    conn.execute("UPDATE user_ref_asset SET ref_type=? WHERE ref_id=?",
                                 (__import__('ref_kinds').normalize(d.get('ref_type'))[0], rid))
            else:
                cur = conn.execute(
                    "INSERT INTO user_ref_asset(verse_id, ref_type, title, author,"
                    " source_name, url, summary, file_path, lang_code, record_status)"
                    " VALUES(?,?,?,?,?,?,?,?,?,'LIVE')",
                    (d.get('start_vid') or None, __import__('ref_kinds').normalize(d.get('ref_type') or 'STUDY')[0],
                     d.get('title') or '(제목 없음)', d.get('author') or '',
                     '모바일', '', d.get('summary') or '', '', lang))
                rid = int(cur.lastrowid)
            conn.commit()
            # ★ 2026-10-25 폰 글의 표를 PC 와 같은 정본(글 + 표 구조)으로 — 그전에는 `| 가 | 나 |` 글자 그대로 담겼다.
            #   출처 = 폰이 적은 origin(AI 답 저장 = AI · 사람이 쓴 글 = MINE · 옛 초안은 AI 저장뿐이라 AI).
            #   탭 줄 덩어리는 AI 답일 때만 표로(사람이 붙여 넣은 문서의 탭은 글 그대로 — PC 연구노트 칸과 같은 규칙).
            origin = (d.get('origin') or 'AI').upper()
            try:
                import ref_doc as _RD
                body, _tb = _RD.absorb(body, tsv=(origin == 'AI'))
            except Exception:                                 # noqa: BLE001
                _tb = {}
            U.set_text(conn, rid, lang, d.get('title') or '', body)
            user_ai._sync_tables(conn, rid, _tb, lang)
            try:
                import ref_kinds
                ref_kinds.ensure(conn)
                if edit:
                    # 고친 글 — 출처는 그대로(AI 글을 사람이 고치면 「수정함」 · 외부 수집 글은 외부 수집 그대로)
                    if edit[1] == 'AI':
                        conn.execute("UPDATE user_ref_asset SET ai_edited=1 WHERE ref_id=?", (rid,))
                    elif edit[1] not in ('WEB', 'MINE'):
                        conn.execute("UPDATE user_ref_asset SET ref_origin='MINE' WHERE ref_id=?", (rid,))
                else:
                    conn.execute("UPDATE user_ref_asset SET ref_origin=?, ai_edited=0 WHERE ref_id=?",
                                 ('AI' if origin == 'AI' else 'MINE', rid))
            except Exception as e:                            # noqa: BLE001
                print('[mobile REF origin] %s' % e)
            conn.commit()
            # ★ 2026-10-20 (docs/1.txt 9-6) 폰이 저장 전에 연결 후보를 걸렀다 — 뺀 것은 「지운 추천」으로(다시 안 걸린다) ·
            #   글 속 약명은 그대로 자동 연결 · 폰에서 찾아 더한 구절·용어는 사람이 이은 것으로
            def _lk(xs):
                out = []
                for x in xs or []:
                    try:
                        k, a, e = x[0], int(x[1]), (int(x[2]) if len(x) > 2 and x[2] else None)
                    except (TypeError, ValueError, IndexError):
                        continue
                    if k in U.KINDS:
                        # ★ 2026-10-25 폰 팩에 없는 용어로 승격된 원어는 폰이 LEMMA 로 보낸다 — PC 에서 그 용어로 세운다
                        try:
                            import orig_ref as _OR
                            k, a = _OR.canon(conn, k, a)
                        except Exception:                     # noqa: BLE001
                            pass
                        out.append((k, a, e))
                return out
            if d.get('links_drop'):
                U.dismiss(conn, rid, _lk(d.get('links_drop')))
            user_ai.link_verses(conn, rid, body, lang)
            if d.get('links_add'):
                U.add_links(conn, rid, _lk(d.get('links_add')))
        ref = 'REF:%d' % rid
    elif k == 'AI':
        import user_ai
        with appdb.connect(db_path) as conn:
            cid = user_ai.new_chat(conn, d.get('start_vid'), d.get('end_vid'),
                                   lang, d.get('title') or '', d.get('kind') or 'ASK',
                                   entity_id=d.get('entity_id'))
            conn.execute("UPDATE user_ai_chat SET provider=?, model=? WHERE"
                         " chat_id=?", (d.get('provider') or '',
                                        d.get('model') or '', cid))
            # ★ 말마다 회사·모델·갈래(mkind)를 그대로 — PC AI결과 창이 AI 별 칸 · 통합본 ·
            #   그 AI 정리를 제자리에 보이게(2026-10-10 「어떤 글이 통합된 결과물인지 식별」).
            #   옛 폰 초안(말마다의 칸 없음)은 초안의 회사·모델로(그전과 같다).
            for m in d.get('msgs') or []:
                role = m.get('role') if m.get('role') in ('user', 'ai') else 'user'
                mk = (m.get('mkind') or '') if role == 'ai' else ''
                if mk not in ('', 'INTEG', 'SELF'):
                    mk = ''
                user_ai.add_msg(conn, cid, role, m.get('body') or '',
                                provider=m.get('provider') or d.get('provider') or '',
                                model=m.get('model') or d.get('model') or '',
                                target=(m.get('target') or '') if mk else '', mkind=mk)
            conn.commit()
        ref = 'AI:%d' % cid
    else:
        raise ValueError(_t('MOB_E_KIND', '이 PC 가 모르는 초안입니다: %s') % k)
    with appdb.connect(db_path) as conn:
        conn.execute("UPDATE userdb.user_mobile_inbox SET state='ADOPTED',"
                     " adopted_ref=? WHERE inbox_id=?", (ref, int(inbox_id)))
        conn.commit()
    return ref


# ── PC → 폰 : 바뀐 것만 ────────────────────────────────────────────
def _where(tbl):
    return dict(MIRROR_TABLES).get(tbl, '')


def cut_seq(conn):
    """지금까지 적힌 변경의 끝 번호(지운 기록이 있어도 줄지 않는다)."""
    r = conn.execute("SELECT seq FROM userdb.sqlite_sequence WHERE"
                     " name='user_sync_change'").fetchone()
    return int(r[0]) if r and r[0] else 0


def counts(conn):
    out = {}
    for tbl, w in MIRROR_TABLES:
        try:
            out[tbl] = conn.execute('SELECT COUNT(*) FROM userdb.%s%s'
                                    % (tbl, (' WHERE ' + w) if w else '')).fetchone()[0]
        except Exception:                                 # noqa: BLE001
            pass
    return out


def _table_full(conn, tbl):
    w = _where(tbl)
    cur = conn.execute('SELECT * FROM userdb.%s%s' % (tbl, (' WHERE ' + w) if w else ''))
    return {'cols': [x[0] for x in cur.description], 'pk': pk_cols(conn, tbl),
            'full': True, 'rows': [list(r) for r in cur], 'dels': []}


FULL_MIN = 500   # 바뀐 열쇠가 이보다 적으면 늘 하나씩(작은 표를 통째로 다시 보내지 않는다)


def build_payload(conn, mode, since=0, cut=None, tables=None, with_ai_keys=False,
                  state_path=None, lang=None):
    """폰에 보낼 것 → dict.

    mode = FULL(전부) · DELTA(since 뒤에 바뀐 행만) · FIX(고른 표만 전부).
    DELTA 의 행은 **지금 값**으로 보낸다 — 지금 없거나 보낼 조건(공동체 글·숨김)에서
    빠졌으면 **지우라**고 보낸다.
    """
    import db_pref_preset
    cut = cut_seq(conn) if cut is None else cut
    have = [t for t, _w in MIRROR_TABLES if pk_cols(conn, t)]
    out = {'proto': PROTO, 'mode': mode, 'cut': cut, 'made_at': _now(),
           'tables': {}, 'counts': counts(conn)}
    if mode in ('FULL', 'FIX'):
        for tbl in (tables or have):
            if tbl in have:
                out['tables'][tbl] = _table_full(conn, tbl)
    else:
        ch = {}
        for tbl, pk in conn.execute(
                'SELECT tbl, pk FROM userdb.user_sync_change WHERE seq>? AND seq<=?'
                ' GROUP BY tbl, pk', (int(since), int(cut))):
            ch.setdefault(tbl, []).append(pk)
        for tbl, pks in ch.items():
            if tbl not in have:
                continue
            # ★ 2026-10-16 — 바뀐 열쇠가 그 표의 지금 줄 수보다 많으면 **통째로** 보낸다(full).
            #   실측 플랜 일정(user_plan_schedule)을 고칠 때마다 다시 써서 지운 열쇠 238,801 · 지금 줄 11,116 —
            #   지운 것을 하나씩 보내니 폰이 120초 안에 못 받아 10-14 뒤로 동기화가 한 번도 안 됐다.
            try:
                live = conn.execute('SELECT COUNT(*) FROM userdb.%s' % tbl).fetchone()[0]
            except Exception:                             # noqa: BLE001
                live = None
            if live is not None and len(pks) > max(FULL_MIN, live):
                out['tables'][tbl] = _table_full(conn, tbl)
                continue
            pk = pk_cols(conn, tbl)
            w = _where(tbl)
            cur = conn.execute('SELECT * FROM userdb.%s LIMIT 0' % tbl)
            cols = [x[0] for x in cur.description]
            t = {'cols': cols, 'pk': pk, 'full': False, 'rows': [], 'dels': []}
            q = ('SELECT * FROM userdb.%s WHERE %s%s' %
                 (tbl, ' AND '.join('%s=?' % c for c in pk),
                  (' AND (%s)' % w) if w else ''))
            for pj in pks:
                vals = json.loads(pj)
                row = conn.execute(q, vals).fetchone()
                if row is None:
                    t['dels'].append(vals)
                else:
                    t['rows'].append(list(row))
            out['tables'][tbl] = t
    cfg, st = db_pref_preset.snapshot(conn, state_path)
    if with_ai_keys:
        r = conn.execute("SELECT config_val FROM userdb.user_config WHERE"
                         " config_key='AI_ACCOUNTS'").fetchone()
        if r and r[0]:
            cfg['AI_ACCOUNTS'] = r[0]
    out['config'], out['state'] = cfg, st
    # ★ 2026-10-22 최신 콘텐츠 받기 설정 — PC·폰 한 벌(news_pref · 늦게 고친 것이 이긴다)
    try:
        import news_pref as _NP
        out['news_pref'] = _NP.get(conn)
    except Exception:
        pass
    if lang:
        # ★ 폰 AI 꾸러미 — 업무마다 PC 가 지은 보낼 글(user_ai.phone_bundle · 317차-30 ④)
        try:
            import user_ai
            out['ai'] = user_ai.phone_bundle(conn, lang)
        except Exception:                                 # noqa: BLE001
            pass
        # ★ 2026-10-12 이 PC 에 있는 책(팩 파일 이름만 · sys 자료 아님) — 폰 「자료 받기」가 「PC에도 있음」을 보인다
        try:
            import db_mobile_core as _MC
            L = lang.upper()
            out['pc_have'] = sorted(_MC.book_file_name(b['code'], L if b['has_lang'] else 'EN')
                                    for b in _MC.books_on_pc(conn, L))
        except Exception:                                 # noqa: BLE001
            pass
    return out


def build_mirror(conn, with_ai_keys=False, state_path=None):
    """정본 사본 전부(처음 짝 맺은 폰·다시 깐 폰)."""
    return build_payload(conn, 'FULL', with_ai_keys=with_ai_keys, state_path=state_path)


def prune(conn):
    """모든 폰이 받은 변경은 지운다. 짝 맺은 폰이 없으면 전부 지운다."""
    rows = conn.execute("SELECT sent_seq FROM userdb.user_mobile_device"
                        " WHERE record_status='LIVE'").fetchall()
    seqs = [r[0] for r in rows if r[0] is not None]
    if not rows or not seqs:
        conn.execute('DELETE FROM userdb.user_sync_change')
    elif all(r[0] is not None for r in rows):
        conn.execute('DELETE FROM userdb.user_sync_change WHERE seq<=?', (min(seqs),))
    else:
        # 아직 한 번도 안 받은 폰은 처음에 전부 받으니 기다릴 까닭이 없다
        conn.execute('DELETE FROM userdb.user_sync_change WHERE seq<=?', (min(seqs),))
    conn.commit()


def _rows_sent(p):
    return (sum(len(t['rows']) for t in p['tables'].values()),
            sum(len(t['dels']) for t in p['tables'].values()))


# ── 한 바퀴 ───────────────────────────────────────────────────────
MIRROR_TIMEOUT = 300   # 사본을 받는 데 폰이 쓸 수 있는 시간(초) — 첫 사본·큰 사본도 견디게


def sync_once(db_path, device_id, with_ai_keys=False, log=None, targets=None,
              packs=True, work_dir=None, fetch=True):
    """폰 찾기 → … → 바뀐 것 보내기. ★ 2026-10-16 — 실패해도 그 까닭을 기기 줄(`last_result`)에 남긴다
    (그전에는 성공할 때만 적어, 10-14 뒤 실패가 어디서 났는지 아무 기록이 없었다)."""
    try:
        return _sync_once(db_path, device_id, with_ai_keys, log, targets, packs, work_dir, fetch)
    except Exception as e:
        try:
            import appdb
            with appdb.connect(db_path) as conn:
                conn.execute("UPDATE userdb.user_mobile_device SET last_result=? WHERE device_id=?",
                             ('%s %s: %s' % (_now(), _t('MOB_FAILED', '실패'), str(e)[:300]), device_id))
                conn.commit()
        except Exception:                                 # noqa: BLE001
            pass
        raise


def _sync_once(db_path, device_id, with_ai_keys=False, log=None, targets=None,
               packs=True, work_dir=None, fetch=True):
    import appdb
    say = log or (lambda s: None)
    with appdb.connect(db_path) as conn:
        ensure(conn)
        dev = device(conn, device_id)
    if not dev or not dev['key']:
        raise SyncError(_t('MOB_E_NOTPAIRED', '짝을 맺은 폰이 아닙니다.'))
    say(_t('MOB_S_FIND', '같은 와이파이에서 폰을 찾는 중…'))
    at = find_phone(dev, targets)
    h, p, key = dev['host'], dev['port'], dev['key']
    if at and (at[0], at[1]) != (h, p):
        h, p = at
        with appdb.connect(db_path) as conn:
            set_address(conn, device_id, h, p)
    rep = {'events': 0, 'event_dup': 0, 'event_fail': 0, 'drafts': 0,
           'draft_dup': 0, 'draft_bad': 0, 'unknown': 0, 'mode': '',
           'rows': 0, 'dels': 0, 'fixed': 0}
    hi = call(h, p, key, 'hello', {'pc': socket.gethostname(), 'proto': PROTO})
    have = hi.get('have')
    say(_t('MOB_S_OUTBOX', '폰이 보낼 것을 받는 중…'))
    items = call(h, p, key, 'outbox').get('items') or []
    items.sort(key=lambda x: (x.get('made_at') or '', x.get('seq') or 0))
    done = []
    with appdb.connect(db_path) as conn:
        ensure(conn)
        for it in items:
            kind, uid = it.get('kind'), it.get('uuid')
            if not uid:
                continue
            if kind in EVENT_KINDS:
                if conn.execute("SELECT 1 FROM userdb.user_mobile_event"
                                " WHERE uuid=?", (uid,)).fetchone():
                    rep['event_dup'] += 1
                    done.append(uid)
                    continue
                try:
                    res = apply_event(conn, kind, it.get('data') or {})
                except Exception as e:                    # noqa: BLE001
                    res = 'FAIL:%s' % e
                conn.execute(
                    "INSERT INTO userdb.user_mobile_event(uuid, device_id, kind,"
                    " data, made_at, applied_at, result) VALUES(?,?,?,?,?,?,?)",
                    (uid, device_id, kind,
                     json.dumps(it.get('data') or {}, ensure_ascii=False),
                     it.get('made_at') or '', _now(), res))
                rep['event_fail' if res.startswith('FAIL') else 'events'] += 1
                if kind == 'AI_CHAT' and res in ('TRASHED', 'RESTORED'):
                    # ★ 2026-10-22 폰에서 지운·되살린 AI 대화 — 결과 줄에 적는다
                    k_ = 'ai_trashed' if res == 'TRASHED' else 'ai_restored'
                    rep[k_] = rep.get(k_, 0) + 1
                done.append(uid)
            elif kind in DRAFT_KINDS:
                res = store_draft(conn, device_id, it)
                if res == 'NEW':
                    rep['drafts'] += 1
                elif res == 'DUP':
                    rep['draft_dup'] += 1
                else:
                    rep['draft_bad'] += 1
                done.append(uid)          # 못 받은 초안도 적고 폰에서 걷는다
            else:
                rep['unknown'] += 1       # 모르는 갈래 — 확인하지 않는다(폰에 남는다)
        conn.commit()
    if done:
        say(_t('MOB_S_ACK', '폰에 받았다고 알리는 중…'))
        call(h, p, key, 'ack', {'uuids': done})
    # ★ 2026-10-14 87 — 폰 녹음을 사본보다 먼저 받는다(새 진척이 이번 사본으로 폰에 돌아간다)
    import voice_sync as VS
    try:
        with appdb.connect(db_path) as conn:
            rep['voice_in'] = VS.pull(conn, lambda op, d=None: call(h, p, key, op, d, timeout=60), say=say)
    except Exception as e:                                # noqa: BLE001
        rep['voice_err'] = str(e)[:80]
    say(_t('MOB_S_MIRROR', 'PC 의 글을 폰으로 보내는 중…'))
    with appdb.connect(db_path) as conn:
        cut = cut_seq(conn)
        same = (have is not None and dev['sent_seq'] is not None
                and int(have) == int(dev['sent_seq']) and int(have) <= cut)
        mode = 'DELTA' if same else 'FULL'
        pay = build_payload(conn, mode, since=(dev['sent_seq'] or 0), cut=cut,
                            with_ai_keys=with_ai_keys, lang=(hi.get('lang') or None))
    rep['mode'] = mode
    rep['rows'], rep['dels'] = _rows_sent(pay)
    try:
        ans = call(h, p, key, 'mirror', pay, timeout=MIRROR_TIMEOUT)
    except SyncError as e:
        if 'timed out' in str(e):
            raise SyncError(_t('MOB_E_SLOW', '폰이 PC 의 글(%d행 · 지운 것 %d)을 받는 데 %d초를 넘겼습니다. '
                                              '폰 화면을 켜 둔 채 다시 동기화해 보세요.')
                            % (rep['rows'], rep['dels'], MIRROR_TIMEOUT))
        raise
    mism = list(ans.get('mismatch') or [])
    if mism:
        # ★ 행 수가 안 맞는 표만 통째로 다시 — 놓친 것이 있어도 여기서 스스로 고쳐진다
        with appdb.connect(db_path) as conn:
            fix = build_payload(conn, 'FIX', cut=cut, tables=mism,
                                with_ai_keys=with_ai_keys)
        r2, _d = _rows_sent(fix)
        rep['rows'] += r2
        rep['fixed'] = len(mism)
        ans = call(h, p, key, 'mirror', fix, timeout=MIRROR_TIMEOUT)
        if ans.get('mismatch'):
            raise SyncError(_t('MOB_E_MISMATCH', '폰의 사본이 PC 와 맞지 않습니다: %s')
                            % ', '.join(ans['mismatch']))
    # ★ 2026-10-20 함께 쓰는 AI 대화 — PC 에서 바뀐 것만 폰으로(폰이 모르는 판이면 건너뛴다)
    try:
        import ai_chat_sync as ACS
        with appdb.connect(db_path) as conn:
            docs = ACS.to_send(conn)
        if docs:
            say(_t('MOB_S_AICHAT', 'AI 대화를 폰으로 보내는 중…'))
            ar = call(h, p, key, 'ai_chats', {'docs': docs}, timeout=120)
            with appdb.connect(db_path) as conn:
                ACS.sent(conn, ar.get('ok') or [])
            okset = set(ar.get('ok') or [])
            rep['ai_chats'] = len(okset)
            rep['ai_out_trash'] = sum(1 for x in docs if x.get('uid') in okset and x.get('trashed_at'))
    except SyncError as e:
        if 'UNKNOWN_OP' not in str(e):
            rep['ai_chat_err'] = str(e)[:80]
    except Exception as e:                                # noqa: BLE001
        rep['ai_chat_err'] = str(e)[:80]
    if hi.get('drafts_keep'):
        # ★ 폰은 받은 초안을 지우지 않고 갖고 있다 — PC 에 들였거나(사본이 대신한다)
        #   「다운로드 안함 + 폰에서도 지우기」인 것만 걷게 한다(2026-10-10 1.txt 54)
        with appdb.connect(db_path) as conn:
            drop = drafts_to_drop(conn, device_id)
        if drop:
            call(h, p, key, 'drafts_done', {'uuids': drop})
            with appdb.connect(db_path) as conn:
                conn.executemany("UPDATE userdb.user_mobile_inbox SET dropped_at=? WHERE uuid=?",
                                 [(_now(), u) for u in drop])
                conn.commit()
            rep['drafts_dropped'] = len(drop)
    if packs and (hi.get('packs_ok') or hi.get('lang')):
        # ★ 팩은 사본을 다 보낸 뒤 — 끊겨도 글은 이미 갔다
        import tempfile
        lang = (hi.get('lang') or 'KO').upper()
        with appdb.connect(db_path) as conn:
            _cfg_set(conn, PHONE_LANG_KEY, lang)
        wd = work_dir or tempfile.mkdtemp(prefix='hagah_mpack_')
        try:
            with appdb.connect(db_path) as conn:
                files, why = pack_files(conn, lang, wd, fetch=fetch, say=say)
            with appdb.connect(db_path) as conn:   # ★ PC 가 보낸 적 있고 아직 안 걷은 팩만 걷을 수 있다
                ours = {x['name'] for x in sent_history(conn, device_id) if not x['gone_at']}
            pr = push_packs(h, p, key, files, say=say, ours=ours)
            with appdb.connect(db_path) as conn:
                note_packs(conn, device_id, pr, files)
                _cfg_set(conn, PHONE_PACKS_KEY, json.dumps(pr.get('now') or [], ensure_ascii=False))
                conn.commit()
            rep['packs'] = len(pr['sent'])
            rep['pack_mb'] = pr['bytes'] / 1048576.0
            rep['pack_gone'] = len(pr['gone'])
            rep['pack_why'] = why
        finally:
            if not work_dir:
                import shutil
                shutil.rmtree(wd, ignore_errors=True)
    # ★ 87 — ④ 에서 고른 PC 녹음을 Opus 로 보낸다(팩 뒤 — 끊겨도 글은 이미 갔다)
    try:
        with appdb.connect(db_path) as conn:
            rep['voice_out'] = VS.push(conn, lambda op, d=None: call(h, p, key, op, d, timeout=60), say=say)
    except Exception as e:                                # noqa: BLE001
        rep['voice_err'] = str(e)[:80]
    msg = summary(rep)
    with appdb.connect(db_path) as conn:
        conn.execute("UPDATE userdb.user_mobile_device SET last_sync=?,"
                     " last_result=?, sent_seq=? WHERE device_id=?",
                     (_now(), msg, cut, device_id))
        conn.commit()
        prune(conn)
    say(msg)
    return rep


# ══════════════════════════════════════════════════════════════════════
#  팩 보내기 — PC → 폰 (모바일 코어팩 · 고른 도서) · 2026-10-08 사용자
#  「Pc에서 다운로드 한 것 중에서 모바일로 전송 … 자동 또는 선택해서」
# ══════════════════════════════════════════════════════════════════════
PACK_CHUNK = 384 * 1024          # 조각 하나(봉투 하나) — 폰 메모리에 부담 없는 크기
BOOK_PREFIX = 'mobile_book_'     # PC 가 만든 도서 팩 — 선택한 목록에서 빠지면 폰에서도 걷는다
SEND_CORE_KEY = 'MOBILE_SEND_CORE'     # '1'(기본) | '0'
SEND_BOOKS_KEY = 'MOBILE_SEND_BOOKS'   # JSON [book_code …]
PHONE_LANG_KEY = 'MOBILE_PHONE_LANG'   # 마지막으로 이은 폰의 언어(hello) — 보낼 자료 화면이 그 언어로 센다
CORE_STALE_DAYS = 7                    # 받아 둔 모바일 코어팩이 이보다 오래되면 동기화 때 새로 받아 본다


def file_sha(path):
    h = hashlib.sha1()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''):
            h.update(b)
    return h.hexdigest()[:16]


def _cfg(conn, k, default=''):
    r = conn.execute("SELECT config_val FROM userdb.user_config WHERE config_key=?",
                     (k,)).fetchone()
    return r[0] if r and r[0] is not None else default


def _cfg_set(conn, k, v):
    if conn.execute("SELECT 1 FROM userdb.user_config WHERE config_key=?", (k,)).fetchone():
        conn.execute("UPDATE userdb.user_config SET config_val=? WHERE config_key=?", (v, k))
    else:
        conn.execute("INSERT INTO userdb.user_config(config_key, config_val) VALUES(?,?)", (k, v))
    conn.commit()


def get_send(conn):
    """→ {'core': bool, 'books': [book_code …]} — 폰에 보낼 것(사람이 선택한 것)."""
    # ★ 2026-10-12 사용자 「user 데이터들만 교환한다」 — 콘텐츠(sys) 팩은 폰이 스토어/서버에서 직접 받는다.
    #   PC 가 보내는 것은 「통신비 절약」을 원하는 사람이 켤 때만(기본 끔) — 옛 PC 에 켜져 저장된 값도 한 번 끔으로 옮긴다.
    if _cfg(conn, 'MOBILE_SEND_DEFAULT_20261012', '') == '':
        _cfg_set(conn, SEND_CORE_KEY, '0')
        _cfg_set(conn, 'MOBILE_SEND_DEFAULT_20261012', '1')
    try:
        books = [str(x) for x in json.loads(_cfg(conn, SEND_BOOKS_KEY, '[]') or '[]')]
    except ValueError:
        books = []
    return {'core': _cfg(conn, SEND_CORE_KEY, '0') == '1', 'books': books}


def set_send(conn, core=None, books=None):
    if core is not None:
        _cfg_set(conn, SEND_CORE_KEY, '1' if core else '0')
    if books is not None:
        _cfg_set(conn, SEND_BOOKS_KEY, json.dumps(sorted(set(books)), ensure_ascii=False))


def book_entry(entry, default_lang):
    """보낼 책 한 줄 → (코드, 언어). ★ 2026-10-10 1.txt 54 — 한 책을 여러 언어로 보낼 수 있게
    「코드|언어」로 적는다. 옛 값(코드만)은 폰 언어로 읽는다."""
    code, _s, lg = str(entry).partition('|')
    return code, (lg or default_lang).upper()


def phone_lang(conn, default='KO'):
    return (_cfg(conn, PHONE_LANG_KEY, '') or default).upper()


def refresh_core(lang, force=False, say=None):
    """받아 둔 **공통 코어팩 + 그 언어팩**을 새로 받는다(없거나 오래됐으면 · force 면 늘) → [경로 …].

    ★ 2026-10-10 사용자 「공통 코어팩 + 언어팩으로 나누어 진행하라」 — 한 언어의 코어 = 두 파일.
    ⚠ 못 받으면 옛 것을 그대로 쓴다 — 망이 없다고 폰에 보낼 것이 사라지면 안 된다.
    """
    import db_mobile_core as MC
    out = []
    for k in MC.set_of(lang):
        cached = os.path.join(MC.CACHE_DIR, MC.file_name(k))
        old = os.path.exists(cached) and (time.time() - os.path.getmtime(cached)) > CORE_STALE_DAYS * 86400
        got = None
        if force or not os.path.exists(cached) or old:
            if say:
                say(_t('MOB_S_FETCH_CORE', '모바일 코어팩을 받는 중…') + ' ' + MC.file_name(k))
            try:
                got = MC.fetch_core(k)
            except Exception:                             # noqa: BLE001
                got = None
        got = got or MC.core_path(k)
        if got:
            out.append(got)
    return out


def follow_pc_download(db_path='bible_master.db'):
    """PC 가 코어팩을 받은 뒤 — 짝 맺은 폰이 있고 코어를 보내기로 했으면 모바일 코어팩도 함께 받는다.

    ★ 사용자 「pc 팩 다운로드 할때 모바일 팩도 같이 자동 또는 선택해서」 — 자동 = 여기 · 선택 = 보낼 자료 화면 [지금 받기].
    """
    import appdb
    try:
        with appdb.connect(db_path) as conn:
            ensure(conn)
            if not devices(conn) or not get_send(conn)['core']:
                return None
            lang = phone_lang(conn)
        return refresh_core(lang, force=True)
    except Exception:                                     # noqa: BLE001
        return None


def pack_files(conn, lang, work_dir, fetch=True, say=None):
    """보낼 팩 파일 → ([경로 …], [못 만든 까닭 …]).

    ★ 코어 = 받아 둔 것(사용자 PC) · 없으면 서버에서 받는다 · 관리자 PC 는 만든 것.
    ★ 도서 = 이 PC 의 DB 에서 그 책 한 권을 그때 만든다(같은 책이면 같은 sha → 폰이 이미 있으면 안 보낸다).
    """
    import db_mobile_core as MC
    say = say or (lambda m: None)
    want, files, why = get_send(conn), [], []
    if want['core']:
        cps = refresh_core(lang, say=say) if fetch else MC.core_paths(lang)
        files += cps
        have = {os.path.basename(c) for c in cps}
        for k in MC.set_of(lang):
            if MC.file_name(k) not in have:
                why.append(_t('MOB_P_NO_CORE', '모바일 코어팩(%s)을 받지 못했습니다 — 망을 보세요')
                           % MC.file_name(k))
    # ★ 2026-10-11 사진(폰 홈 사진 카드 · 공유 사진 고르기) — 코어와 함께 이 PC 의 사진을 그대로 보낸다.
    if want['core']:
        try:
            files.append(MC.build_photos(conn, work_dir)[0])
        except Exception as e:                            # noqa: BLE001
            why.append('사진: %s' % str(e)[:60])
    # ★ 2026-10-12 유튜브 팩 — 설교·찬양·기도 영상 **모든 언어 하나**(사용자 「언어팩 없이 하나로」) ·
    #   이 PC 의 DB 에서 그때 만든다(같으면 같은 sha → 다시 안 간다). 옛 찬양 팩(언어마다)은 push 가 걷는다.
    if want['core']:
        try:
            files.append(MC.build_youtube(conn, work_dir)[0])
        except Exception as e:                            # noqa: BLE001
            why.append('유튜브: %s' % str(e)[:60])
    for entry in want['books']:
        code, lg = book_entry(entry, lang)
        try:
            files.append(MC.build_book(conn, code, lg, work_dir)[0])
        except Exception as e:                            # noqa: BLE001
            why.append('%s(%s): %s' % (code, lg, str(e)[:50]))
    return files, why


LEGACY_CORE = 'mobile_core_'        # 2026-10-08 판(언어마다 통째) — 새 판을 보내면 폰에서 걷는다


def push_packs(host, port, key, files, say=None, drop_prefix=BOOK_PREFIX, ours=None):
    """팩 파일을 폰에 조각으로 보낸다 → {'sent', 'same', 'gone', 'bytes'}.

    ★ 폰이 같은 sha 를 갖고 있으면 안 보낸다 · 고른 목록에서 빠진 도서 팩은 폰에서 걷는다.
    """
    import base64
    import db_mobile_core as MC
    say = say or (lambda m: None)
    have = {x.get('name'): x for x in (call(host, port, key, 'pack_list').get('packs') or [])}
    want = {os.path.basename(f) for f in files}
    rep = {'sent': [], 'same': 0, 'gone': [], 'bytes': 0}
    for fp in files:
        name, sha = os.path.basename(fp), file_sha(fp)
        if (have.get(name) or {}).get('sha') == sha:
            rep['same'] += 1
            continue
        with open(fp, 'rb') as f:
            data = f.read()
        import secret_store as _SS          # ★ 2026-10-11 — 열쇠가 섞인 팩은 폰에 보내지 않는다(③)
        _SS.assert_file_clean(fp)
        parts = max(1, -(-len(data) // PACK_CHUNK))
        for i in range(parts):
            say(_t('MOB_S_PACK', '「%s」 보내는 중 %d/%d') % (name, i + 1, parts))
            call(host, port, key, 'pack_put',
                 {'name': name, 'sha': sha, 'part': i, 'parts': parts, 'size': len(data),
                  'b64': base64.b64encode(data[i * PACK_CHUNK:(i + 1) * PACK_CHUNK]).decode('ascii')},
                 timeout=(600 if i == parts - 1 else 60))   # 마지막 조각 = 폰이 담는 시간까지
        rep['sent'].append(name)
        rep['bytes'] += len(data)
    # ★ 옛 판(언어마다 통째로 담은 `mobile_core_<언어>`)은 걷는다 — 공통 코어팩과 함께 있으면 구절이
    #   두 번씩 보인다(2026-10-10 실기기). **다른 언어팩은 안 걷는다** — 사람이 「받은 자료」에서 지운다.
    sends_core = any(w.startswith('mobile_common') for w in want)
    for name in have:
        if not name or name in want:
            continue
        # ★ 2026-10-12 폰이 먼저 — 폰이 서버에서 직접 받은 책은 PC 목록에 없어도 걷지 않는다(`ours` = PC 가 보낸 것)
        if (name.startswith(drop_prefix) and (ours is None or name in ours)) \
                or (sends_core and name.startswith(LEGACY_CORE)) \
                or (MC.YT_FILE in want and name.startswith('mobile_worship_')):
            call(host, port, key, 'pack_del', {'name': name})
            rep['gone'].append(name)
    try:
        rep['now'] = call(host, port, key, 'pack_list').get('packs') or []
    except Exception:                                     # noqa: BLE001
        rep['now'] = []
    return rep


def note_packs(conn, device_id, rep, files):
    """보낸 것 · 걷은 것을 이력에 적는다."""
    ensure(conn)
    now = _now()
    by = {os.path.basename(f): f for f in files}
    for n in rep.get('sent') or []:
        f = by.get(n)
        sha = file_sha(f) if f else ''
        conn.execute("INSERT OR REPLACE INTO userdb.user_mobile_sent(device_id, name, sha, bytes,"
                     " sent_at, gone_at) VALUES(?,?,?,?,?,NULL)",
                     (device_id, n, sha, os.path.getsize(f) if f else 0, now))
    for n in rep.get('gone') or []:
        cur = conn.execute("UPDATE userdb.user_mobile_sent SET gone_at=? WHERE device_id=? AND name=?"
                           " AND gone_at IS NULL", (now, device_id, n))
        if not cur.rowcount:          # 이력 전에 보낸 것 — 걷은 때만이라도 남긴다
            conn.execute("INSERT OR IGNORE INTO userdb.user_mobile_sent(device_id, name, sha, bytes,"
                         " sent_at, gone_at) VALUES(?,?,'',0,'',?)", (device_id, n, now))




def summary(rep):
    if rep.get('mode') == 'FULL':
        sent = _t('MOB_SUM_FULL', '처음이라 PC 의 글 %d행을 모두 보냄') % rep['rows']
    else:
        sent = _t('MOB_SUM_DELTA', '바뀐 글 %d행 · 지운 것 %d') % (rep['rows'], rep['dels'])
    s = (_t('MOB_SUM', '저장 %d건 · 새 초안 %d건') % (rep['events'], rep['drafts'])
         + ' · ' + sent)
    extra = []
    if rep.get('fixed'):
        extra.append(_t('MOB_SUM_FIX', '맞지 않던 표 %d개를 다시 보냄') % rep['fixed'])
    if rep['event_fail']:
        extra.append(_t('MOB_SUM_FAIL', '저장 못 한 것 %d') % rep['event_fail'])
    if rep['draft_bad']:
        extra.append(_t('MOB_SUM_BAD', '받지 못한 초안 %d(빈 글·구절 없음)') % rep['draft_bad'])
    if rep['unknown']:
        extra.append(_t('MOB_SUM_UNK', '이 PC 가 모르는 자료 %d — PC 앱을 새 판으로') % rep['unknown'])
    if rep.get('packs'):
        extra.append(_t('MOB_SUM_PACK', '자료 %d개(%.1f MB)를 폰에 보냄') % (rep['packs'], rep.get('pack_mb', 0)))
    if rep.get('pack_gone'):
        extra.append(_t('MOB_SUM_PACK_GONE', '선택하지 않은 책 %d권을 폰에서 걷음') % rep['pack_gone'])
    for w in rep.get('pack_why') or []:
        extra.append(w)
    vi, vo = rep.get('voice_in') or {}, rep.get('voice_out') or {}
    if vi.get('got') or vi.get('progress'):
        extra.append(_t('MOB_SUM_VIN', '폰 녹음 %d개 받음') % (vi.get('got', 0) + vi.get('progress', 0)))
    if vo.get('sent'):
        extra.append(_t('MOB_SUM_VOUT', '녹음 %d개(%.1f MB)를 폰에 보냄') % (vo['sent'], vo.get('bytes', 0) / 1048576.0))
    if rep.get('voice_err'):
        extra.append(_t('MOB_SUM_VERR', '녹음 주고받기 실패: %s') % rep['voice_err'])
    # ★ 2026-10-22 AI 대화 — 지운 것은 상대에서도 휴지통으로 들어간다는 사실을 그 자리에서 말한다
    if rep.get('ai_trashed'):
        extra.append(_t('MOB_SUM_AI_TRASH', '폰에서 지운 AI 대화 %d개를 PC 휴지통으로 옮겼습니다') % rep['ai_trashed'])
    if rep.get('ai_restored'):
        extra.append(_t('MOB_SUM_AI_REST', '폰에서 되살린 AI 대화 %d개를 PC 에서도 되살렸습니다') % rep['ai_restored'])
    if rep.get('ai_out_trash'):
        extra.append(_t('MOB_SUM_AI_OUT_TRASH', 'PC 에서 지운 AI 대화 %d개를 폰 휴지통으로 옮겼습니다') % rep['ai_out_trash'])
    if rep.get('ai_chats') and rep.get('ai_chats') > rep.get('ai_out_trash', 0):
        extra.append(_t('MOB_SUM_AI_OUT', 'AI 대화 %d개를 폰으로 보냈습니다') % (rep['ai_chats'] - rep.get('ai_out_trash', 0)))
    if rep['event_dup'] or rep['draft_dup']:
        extra.append(_t('MOB_SUM_DUP', '이미 받은 것 %d') % (rep['event_dup'] + rep['draft_dup']))
    return s + ((' · ' + ' · '.join(extra)) if extra else '')


# ══════════════════════════════════════════════════════════════════════
#  폰 쪽 참조 구현 — 시험·하네스용 (모바일 앱의 규격서이기도 하다)
# ══════════════════════════════════════════════════════════════════════
class PhoneRef(object):
    """폰 동기화 서버를 흉내 낸다. `start()` → (host, http_port, udp_port).

    · `pairing` — 「PC 와 연결」 화면을 열어 둔 상태(이때만 짝 맺기 요청을 받는다)
    · `approve()`/`deny()` — 사용자가 [허용]/[거절]을 누른 것
    · `store` — 폰이 가진 사본(`have` = 마지막으로 다 받은 변경 번호)
    """

    def __init__(self, device_id='PHONE-REF', name='시험 폰', pairing=True, lang='KO'):
        self.device_id, self.name = device_id, name
        self.lang = lang
        self.packs = {}              # name → {'sha', 'data'(gz 바이트)} — 받아 담은 팩
        self._part = {}              # name → {'sha', 'parts', 'buf': [bytes …]}
        self.pairing = pairing
        self.key = None
        self.pc = None
        self.pend = {}               # sid → {c, b, B, pc, key, code, state}
        self.outbox = []
        self.kept = []                       # 보냈지만 폰이 갖고 있는 초안
        self.store = {}              # tbl → {'cols', 'pk', 'rows': {pkjson: row}}
        self.config = None
        self.ai = None               # 폰 AI 꾸러미(PC 가 지은 업무별 보낼 글)
        self.have = None
        self.seen = {}
        self.log = []
        self.fail_mirror = 0         # 시험 — 사본 받기를 몇 번 일부러 실패할지
        self.voices = {}             # ★ 87 key → {data, sha, made_at, origin, has_file, sent}
        self._srv = self._udp = None
        self.port = self.udp_port = None

    # ── 사용자 동작 ──
    def approve(self):
        for p in self.pend.values():
            if p.get('state') == 'SHOWN':
                p['state'] = 'OK'

    def deny(self):
        for p in self.pend.values():
            if p.get('state') == 'SHOWN':
                p['state'] = 'DENIED'

    def shown_code(self):
        for p in self.pend.values():
            if p.get('state') == 'SHOWN':
                return p['code']
        return None

    def add(self, kind, data, made_at=None):
        uid = secrets.token_hex(12)
        self.outbox.append({'uuid': uid, 'kind': kind, 'seq': len(self.outbox),
                            'made_at': made_at or _now(), 'data': data})
        return uid

    def rows(self, tbl):
        return list((self.store.get(tbl) or {}).get('rows', {}).values())

    # ── 사본 적용 ──
    def apply(self, pay):
        if pay.get('mode') == 'FULL':
            self.store = {}
        for tbl, t in pay.get('tables', {}).items():
            pki = [t['cols'].index(c) for c in t['pk']]
            cur = self.store.get(tbl)
            if t.get('full') or cur is None:
                cur = {'cols': t['cols'], 'pk': t['pk'], 'rows': {}}
            for r in t['rows']:
                cur['rows'][json.dumps([r[i] for i in pki])] = r
            for d in t['dels']:
                cur['rows'].pop(json.dumps(d), None)
            self.store[tbl] = cur
        if pay.get('config') is not None:
            self.config = pay['config']
        if pay.get('ai') is not None:
            self.ai = pay['ai']
        bad = [tbl for tbl, n in (pay.get('counts') or {}).items()
               if len(self.rows(tbl)) != n]
        if not bad:
            self.have = pay.get('cut')
        return bad

    # ── 망 ──
    def _pair(self, req):
        if not self.pairing:
            return {'ok': False, 'why': 'NOT_PAIRING'}
        if req.get('step') == 1:
            b, B = dh_pair()
            sid = secrets.token_hex(8)
            self.pend[sid] = {'c': req.get('c'), 'b': b, 'B': B,
                              'pc': req.get('pc') or '', 'state': 'WAIT_A'}
            return {'ok': True, 'v': PROTO, 'sid': sid, 'B': '%x' % B,
                    'device_id': self.device_id, 'name': self.name}
        p = self.pend.get(req.get('sid'))
        if not p or p['state'] != 'WAIT_A':
            return {'ok': False, 'why': 'NO_SESSION'}
        A = int(req.get('A') or '0', 16)
        if hashlib.sha256(_ib(A)).hexdigest() != p['c']:
            p['state'] = 'BAD'
            return {'ok': False, 'why': 'COMMIT'}       # 약속과 다른 값 — 끼어든 것
        p['key'] = session_key(p['b'], A, A, p['B'])
        p['code'] = confirm_code(A, p['B'])
        p['state'] = 'SHOWN'                              # 화면에 숫자와 [허용]
        return {'ok': True}

    def _handle(self, blob, pid):
        key = self.key if (self.key and pid == pair_id(self.key)) else None
        pend = None
        if key is None:
            for p in self.pend.values():
                if p.get('key') and pair_id(p['key']) == pid:
                    pend, key = p, p['key']
        if key is None:
            return 403, b''
        try:
            req = unseal(key, blob)
        except ValueError:
            return 403, b''
        rid = req.get('rid')

        def ans(ok, data=None, why=''):
            return 200, seal(key, {'ok': ok, 'rid': rid, 'data': data or {},
                                   'why': why})
        if abs(int(time.time()) - int(req.get('ts') or 0)) > TS_WINDOW:
            return ans(False, why='STALE')
        if rid in self.seen:
            return ans(False, why='REPLAY')
        self.seen[rid] = int(time.time())
        if pend is not None:
            if pend['state'] == 'DENIED':
                return ans(False, why='DENIED')
            if pend['state'] != 'OK':
                return ans(False, why='WAIT')
            self.key, self.pc, self.pend = pend['key'], pend['pc'], {}
            self.have = None                     # 새 PC — 처음부터 받는다
        op, d = req.get('op'), req.get('data') or {}
        self.log.append(op)
        if op == 'hello':
            return ans(True, {'device_id': self.device_id, 'device_name': self.name,
                              'proto': PROTO, 'outbox': len(self.outbox),
                              'have': self.have, 'lang': self.lang, 'packs_ok': True,
                              'drafts_keep': True})
        if op == 'pack_list':
            return ans(True, {'packs': [{'name': n, 'sha': x['sha'], 'size': len(x['data'])}
                                        for n, x in self.packs.items()]})
        if op == 'pack_put':
            import base64
            n, i, parts = d.get('name') or '', int(d.get('part') or 0), int(d.get('parts') or 1)
            if not n or '/' in n or '\\' in n or not n.endswith('.json.gz'):
                return ans(False, why='BAD_NAME')
            cur = self._part.get(n)
            if i == 0 or not cur or cur['sha'] != d.get('sha'):
                cur = self._part[n] = {'sha': d.get('sha'), 'parts': parts, 'buf': []}
            if len(cur['buf']) != i:
                return ans(False, {'want': len(cur['buf'])}, 'SEQ')    # 처음부터 다시
            cur['buf'].append(base64.b64decode(d.get('b64') or ''))
            if len(cur['buf']) < parts:
                return ans(True, {'got': i + 1})
            data = b''.join(cur['buf'])
            self._part.pop(n, None)
            if hashlib.sha1(data).hexdigest()[:16] != d.get('sha'):
                return ans(False, why='SHA')
            import gzip
            body = json.loads(gzip.decompress(data).decode('utf-8'))   # 깨졌으면 여기서
            self.packs[n] = {'sha': d.get('sha'), 'data': data, 'kind': body.get('kind')}
            return ans(True, {'loaded': n, 'tables': len(body.get('tables') or {})})
        if op == 'pack_del':
            return ans(True, {'gone': self.packs.pop(d.get('name') or '', None) is not None})
        # ★ 87 녹음 — 폰 앱(lib/sync/phone_server.dart)이 같은 연산을 한다(규격 §9)
        if op == 'voice_list':
            return ans(True, {'voices': [
                {'key': k, 'sha': x.get('sha', ''), 'size': len(x.get('data') or b''),
                 'made_at': x.get('made_at', ''), 'origin': x.get('origin', 'PHONE'),
                 'has_file': x.get('has_file', 1), 'sent': x.get('sent', 0)} for k, x in self.voices.items()]})
        if op == 'voice_get':
            import base64
            x = self.voices.get(d.get('key') or '')
            if not x or not x.get('has_file'):
                return ans(False, why='NO_FILE')
            data, i = x['data'], int(d.get('part') or 0)
            parts = max(1, -(-len(data) // PACK_CHUNK))
            return ans(True, {'part': i, 'parts': parts, 'sha': x['sha'], 'size': len(data),
                              'b64': base64.b64encode(data[i * PACK_CHUNK:(i + 1) * PACK_CHUNK]).decode('ascii')})
        if op == 'voice_got':
            for k in d.get('keys') or []:
                if k in self.voices:
                    self.voices[k]['sent'] = 1
            return ans(True, {})
        if op == 'voice_put':
            import base64
            k = d.get('key') or ''
            x = self._part.setdefault('V:' + k, {'buf': []})
            if int(d.get('part') or 0) == 0:
                x['buf'] = []
            x['buf'].append(base64.b64decode(d.get('b64') or ''))
            if len(x['buf']) == int(d.get('parts') or 1):
                data = b''.join(self._part.pop('V:' + k)['buf'])
                if hashlib.sha1(data).hexdigest()[:16] != d.get('sha'):
                    return ans(False, why='SHA')
                self.voices[k] = {'data': data, 'sha': d.get('sha'), 'made_at': d.get('made_at', ''),
                                  'origin': 'PC', 'has_file': 1, 'sent': 1}
            return ans(True, {})
        if op == 'voice_del':
            x = self.voices.get(d.get('key') or '')
            if x and (d.get('all') or x.get('origin') == 'PC'):
                self.voices.pop(d.get('key'))
            return ans(True, {})
        if op == 'outbox':
            return ans(True, {'items': list(self.outbox)})
        if op == 'ack':
            gone = set(d.get('uuids') or [])
            # ★ 초안은 지우지 않고 「보냄」으로 갖고 있는다 — PC 가 drafts_done 으로 걷으라 할 때까지
            self.kept += [x for x in self.outbox if x['uuid'] in gone and x.get('kind') in DRAFT_KINDS]
            self.outbox = [x for x in self.outbox if x['uuid'] not in gone]
            return ans(True, {'left': len(self.outbox)})
        if op == 'drafts_done':
            gone = set(d.get('uuids') or [])
            self.kept = [x for x in self.kept if x['uuid'] not in gone]
            return ans(True, {'kept': len(self.kept)})
        if op == 'mirror':
            if self.fail_mirror > 0:
                self.fail_mirror -= 1
                return ans(False, why='DISK_FULL')
            return ans(True, {'mismatch': self.apply(d)})
        return ans(False, why='UNKNOWN_OP')

    def _udp_loop(self):
        while self._udp:
            try:
                data, addr = self._udp.recvfrom(65535)
                m = json.loads(data.decode('utf-8'))
            except Exception:                             # noqa: BLE001
                if not self._udp:
                    return
                continue
            out = None
            if m.get('t') == 'pair' and self.pairing:
                out = {'t': 'offer', 's': m.get('s'), 'device_id': self.device_id,
                       'name': self.name, 'port': self.port}
            elif (m.get('t') == 'find' and self.key
                  and m.get('p') == pair_id(self.key)):
                out = {'t': 'here', 'p': m.get('p'), 'device_id': self.device_id,
                       'port': self.port}
            if out:
                try:
                    self._udp.sendto(json.dumps(out).encode('utf-8'), addr)
                except OSError:
                    pass

    def start(self, host='127.0.0.1'):
        from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
        me = self

        class H(BaseHTTPRequestHandler):
            def do_POST(self):
                n = int(self.headers.get('Content-Length') or 0)
                body = self.rfile.read(n)
                if self.path == PATH + '/pair':
                    try:
                        out = json.dumps(me._pair(json.loads(body.decode('utf-8')))
                                         ).encode('utf-8')
                        code = 200
                    except Exception:                     # noqa: BLE001
                        code, out = 400, b''
                elif self.path == PATH:
                    code, out = me._handle(body, self.headers.get('X-Hagah-Pair') or '')
                else:
                    code, out = 404, b''
                self.send_response(code)
                self.send_header('Content-Length', str(len(out)))
                self.end_headers()
                self.wfile.write(out)

            def log_message(self, *a):
                pass

        self._srv = ThreadingHTTPServer((host, 0), H)
        self.port = self._srv.server_address[1]
        threading.Thread(target=self._srv.serve_forever, daemon=True).start()
        u = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        u.bind((host, 0))
        u.settimeout(0.3)
        self._udp = u
        self.udp_port = u.getsockname()[1]
        threading.Thread(target=self._udp_loop, daemon=True).start()
        return host, self.port, self.udp_port

    def stop(self):
        if self._srv:
            self._srv.shutdown()
            self._srv.server_close()
            self._srv = None
        u, self._udp = self._udp, None
        if u:
            u.close()


# ══════════════════════════════════════════════════════════════════════
#  자가 검증 — 임시 폴더의 작은 DB 에서만 돈다(실 DB 자국 0)
# ══════════════════════════════════════════════════════════════════════
SCRATCH_SYS = ('bible_index', 'book_names', 'sys_language', 'sys_bible_plan',
               'sys_plan_schedule', 'sys_book_unit', 'sys_book_asset',
               'sys_unit_asset', 'sys_entity_master', 'sys_pericope_asset',
               'sys_config', 'ui_strings',
               # ★ 2026-10-25 원어 연결(orig_ref.canon) — 승격된 원어를 그 용어로 세운다
               'sys_entity_master', 'sys_entity_lemma', 'sys_lemma_master')


def make_scratch(folder):
    """임시 폴더에 작은 `bible_master.db` + 개인 DB 사본을 만든다 → 본체 경로."""
    import sqlite3
    import appdb
    os.makedirs(folder, exist_ok=True)
    main = os.path.join(folder, 'bible_master.db')
    user = os.path.join(folder, 'user_data.db')
    for p in (main, user):
        for suf in ('', '-wal', '-shm'):
            if os.path.exists(p + suf):
                os.remove(p + suf)
    src = sqlite3.connect(appdb.resolve_db('bible_master.db'))
    dst = sqlite3.connect(main)
    dst.execute('ATTACH DATABASE ? AS src', (appdb.resolve_db('bible_master.db'),))
    for t in SCRATCH_SYS:
        try:
            sql = dst.execute("SELECT sql FROM src.sqlite_master WHERE name=?",
                              (t,)).fetchone()
            if not sql:
                continue
            dst.execute(sql[0])
            dst.execute('INSERT INTO main.%s SELECT * FROM src.%s' % (t, t))
        except Exception:                                 # noqa: BLE001
            pass
    # 설명문 덮개 시험용 — 한 절의 sys 설명문만
    sql = dst.execute("SELECT sql FROM src.sqlite_master WHERE name='sys_text_asset'"
                      ).fetchone()[0]
    dst.execute(sql)
    dst.execute("INSERT INTO main.sys_text_asset SELECT * FROM src.sys_text_asset"
                " WHERE text_type IN ('VERS_DESC','PLAN_TITLE') AND clicked_id<=40")
    dst.commit()
    dst.execute('DETACH DATABASE src')
    dst.close()
    src.close()
    u = sqlite3.connect(appdb.resolve_db('user_data.db'))
    u.execute('VACUUM INTO ?', (user,))
    u.close()
    # 시험 동기화가 진짜 모바일 코어팩(11 MB)을 보내지 않게 — 팩 보내기는 따로 잰다
    u = sqlite3.connect(user)
    u.execute("DELETE FROM user_config WHERE config_key IN (?,?)", (SEND_CORE_KEY, SEND_BOOKS_KEY))
    u.execute("INSERT INTO user_config(config_key, config_val) VALUES(?, '0')", (SEND_CORE_KEY,))
    # ⚠ 사본에는 진짜 폰이 보낸 초안이 들어 있을 수 있다 — 시험은 빈 초안함에서 시작한다
    if u.execute("SELECT 1 FROM sqlite_master WHERE name='user_mobile_inbox'").fetchone():
        u.execute("DELETE FROM user_mobile_inbox")
    u.commit()
    u.close()
    return main


def pair_in_test(db, phone, targets, approve=True):
    """시험용 — 목록에서 선택하고, 숫자를 맞춰 보고, 폰에서 [허용]/[거절]."""
    found = scan_phones(targets, wait=2.0)
    hit = [x for x in found if x['device_id'] == phone.device_id]
    if not hit:
        return None, found, None, None
    box = {}

    def run():
        try:
            box['dev'] = pair_with(db, hit[0], wait=15,
                                   on_code=lambda c: box.__setitem__('pc_code', c))
        except Exception as e:                            # noqa: BLE001
            box['err'] = e
    th = threading.Thread(target=run, daemon=True)
    th.start()
    t0 = time.time()
    while phone.shown_code() is None and time.time() - t0 < 10:
        time.sleep(0.05)
    shown = phone.shown_code()
    while 'pc_code' not in box and time.time() - t0 < 10:
        time.sleep(0.05)
    (phone.approve if approve else phone.deny)()
    th.join(20)
    return box.get('dev'), found, (box.get('pc_code'), shown), box.get('err')


def selftest():
    import shutil
    import tempfile
    import appdb
    ok = [0, 0]

    def ck(name, cond, got=''):
        ok[0 if cond else 1] += 1
        print('  %s %s%s' % ('PASS' if cond else 'FAIL', name,
                             (' — %s' % (got,)) if (got != '' and not cond) else ''))

    # ── 암호 ──
    def mr(n, k=24):
        d, r = n - 1, 0
        while d % 2 == 0:
            d //= 2
            r += 1
        for _ in range(k):
            x = pow(secrets.randbelow(n - 4) + 2, d, n)
            if x in (1, n - 1):
                continue
            for _ in range(r - 1):
                x = pow(x, 2, n)
                if x == n - 1:
                    break
            else:
                return False
        return True
    ck('DH 상수가 2048비트 안전 소수(RFC 3526)', DH_P.bit_length() == 2048
       and mr(DH_P) and mr((DH_P - 1) // 2))
    a, A = dh_pair()
    b, B = dh_pair()
    k_pc, k_ph = session_key(a, B, A, B), session_key(b, A, A, B)
    ck('두 쪽이 같은 열쇠를 얻는다', k_pc == k_ph)
    ck('두 쪽이 같은 4자리를 본다', confirm_code(A, B) == confirm_code(A, B)
       and len(confirm_code(A, B)) == 4)
    c2, C2 = dh_pair()
    ck('끼어든 값이면 숫자가 (거의) 달라진다', confirm_code(C2, B) != confirm_code(A, B)
       or confirm_code(A, C2) != confirm_code(A, B))
    try:
        session_key(a, 1, A, B); ck('이상한 공개 값은 거부', False)
    except ValueError:
        ck('이상한 공개 값은 거부', True)
    bx = seal(k_pc, {'a': '한글 본문', 'n': 3})
    ck('봉한 것을 연다', unseal(k_ph, bx) == {'a': '한글 본문', 'n': 3})
    ck('같은 글도 봉할 때마다 다르다', seal(k_pc, {'a': 1}) != seal(k_pc, {'a': 1}))
    bad = bytearray(bx); bad[25] ^= 1
    try:
        unseal(k_pc, bytes(bad)); ck('고친 글은 거절', False)
    except ValueError:
        ck('고친 글은 거절', True)
    try:
        unseal(hashlib.sha256(b'x').digest(), bx); ck('다른 열쇠는 거절', False)
    except ValueError:
        ck('다른 열쇠는 거절', True)
    ck('봉투 안에 평문이 안 보인다', '한글'.encode('utf-8') not in bx)
    ck('빈 노트는 받지 않는다', check_draft('NOTE', {'start_vid': 1, 'body': ' '}) == 'EMPTY')
    ck('사건과 초안이 안 겹친다', not set(EVENT_KINDS) & set(DRAFT_KINDS))
    ck('AI 키는 기본으로 안 보낸다',
       'AI_ACCOUNTS' not in __import__('db_dist_build').SEED_CFG)

    real_main = appdb.resolve_db('bible_master.db')
    real_user = appdb.user_db_path(real_main)
    before = (os.path.getsize(real_user), os.path.getmtime(real_user))
    tmp = tempfile.mkdtemp(prefix='hg_msync_')
    phones = []
    try:
        db = make_scratch(tmp)
        with appdb.connect(db) as conn:
            ensure(conn)
            conn.execute("DELETE FROM userdb.user_mobile_device")
            conn.commit()
            n0 = cut_seq(conn)
            conn.execute("UPDATE user_favorite SET note=note WHERE fav_id="
                         "(SELECT MIN(fav_id) FROM user_favorite)")
            conn.commit()
            ck('짝 맺은 폰이 없으면 변경을 적지 않는다', cut_seq(conn) == n0)
        # ── 가족 셋이 함께 연결 화면을 열었다 ──
        mine = PhoneRef(device_id='DAD', name='아빠 갤럭시')
        mom = PhoneRef(device_id='MOM', name='엄마 아이폰')
        kid = PhoneRef(device_id='KID', name='아이 폰', pairing=False)
        phones = [mine, mom, kid]
        tg = []
        for ph in phones:
            h, _hp, up = ph.start()
            tg.append((h, up))
        found = scan_phones(tg, wait=2.0)
        ck('연결 화면을 연 폰만 목록에 뜬다', sorted(x['device_id'] for x in found)
           == ['DAD', 'MOM'], found)
        ck('목록에 이름이 보인다', {'아빠 갤럭시', '엄마 아이폰'} ==
           {x['name'] for x in found})
        dev, _f, codes, err = pair_in_test(db, mom, tg, approve=False)
        ck('폰에서 거절하면 짝이 안 맺힌다', dev is None and err is not None, err)
        dev, _f, codes, err = pair_in_test(db, mine, tg, approve=True)
        ck('두 화면에 같은 4자리', codes and codes[0] == codes[1]
           and codes[0] is not None, codes)
        ck('허용하면 짝이 맺힌다', dev and dev['device_id'] == 'DAD', err)
        with appdb.connect(db) as conn:
            ck('짝 맺은 폰은 하나(엄마 폰은 안 들어왔다)', [d['device_id'] for d in
                                                devices(conn)] == ['DAD'])
        ck('엄마 폰은 아빠 PC 의 열쇠를 모른다', mom.key is None)
        dev_mom = {'key': hashlib.sha256(b'other').digest()}
        ck('다른 열쇠로는 아빠 폰을 못 찾는다', find_phone(dev_mom, tg, wait=1.0) is None)
        ck('짝 맺은 폰은 열쇠로 찾는다', find_phone(device(appdb.connect(db), 'DAD'),
                                         tg, wait=2.0) is not None)
        # ── 첫 동기화 = 전부 ──
        with appdb.connect(db) as conn:
            vid = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=1 AND"
                               " chapter=1 AND verse=3").fetchone()[0]
            _jn14 = conn.execute("SELECT verse_id FROM bible_index WHERE bcode=43 AND"
                                 " chapter=1 AND verse=4").fetchone()[0]
            plan = conn.execute(
                "SELECT p.plan_id FROM sys_bible_plan p WHERE p.duration_days>=3"
                " AND EXISTS(SELECT 1 FROM sys_plan_schedule s WHERE"
                " s.plan_id=p.plan_id AND s.day=1) AND NOT EXISTS(SELECT 1 FROM"
                " user_plan_enrollment e WHERE e.plan_id=p.plan_id AND"
                " e.enrollment_status='ACTIVE') ORDER BY p.plan_id LIMIT 1"
            ).fetchone()[0]
            nfav0 = conn.execute("SELECT COUNT(*) FROM user_favorite WHERE"
                                 " record_status='LIVE' AND fav_type<>'LISTEN'").fetchone()[0]
            # ★ 2026-10-28 시험 사본은 실제 개인 DB 를 베낀 것 — 그 절이 이미 즐겨찾기면 늘지 않는다(옛 흠: 늘 +1 을 기대했다)
            had_fav = conn.execute("SELECT 1 FROM user_favorite WHERE fav_type='VERSE' AND target_id=?"
                                   " AND record_status='LIVE'", (vid,)).fetchone() is not None
        e_enr = mine.add('PLAN_ENROLL', {'plan_id': plan, 'start_date': '2026-10-01'},
                         '2026-10-06 08:00:00')
        mine.add('PLAN_DAY_DONE', {'enroll_uuid': e_enr, 'day': 1, 'date': '2026-10-06'},
                 '2026-10-06 08:01:00')
        mine.add('FAV_SET', {'fav_type': 'VERSE', 'target_id': vid, 'verse_id': vid},
                 '2026-10-06 08:02:00')
        mine.add('NOTE', {'start_vid': vid, 'body': '[MSYNC] 빛이 있으라'},
                 '2026-10-06 08:03:00')
        mine.add('DESC', {'text_type': 'VERS_DESC', 'clicked_id': vid, 'lang': 'KO',
                          'variant': 'LAY', 'contents': '[MSYNC] 내가 고친 설명'},
                 '2026-10-06 08:04:00')
        # ★ 2026-10-20 저장 전 연결 거르기 — 요 1:4 후보는 뺐고(links_drop) 창 1:5 는 찾아 더했다(links_add)
        mine.add('REF', {'title': '[MSYNC] 빛', 'body': '창 1:3 과 요 1:4 를 읽고 쓴 글\n| 날 | 지으심 |\n|---|---|\n| 첫째 | 빛 |', 'lang': 'KO',
                         'origin': 'MINE',
                         'links_drop': [['VERSE', _jn14, None]],
                         # ★ 2026-10-25 폰 팩에 그 용어가 없어 원어(LEMMA)로 보낸 「은혜(카리스)」 — PC 가 용어로 세운다
                         'links_add': [['VERSE', vid + 4, None], ['LEMMA', 2005485, None]]},
                 '2026-10-06 08:05:00')
        mine.add('AI', {'start_vid': vid, 'lang': 'KO', 'title': '[MSYNC] 빛',
                        'provider': 'GEMINI', 'model': 'g',
                        'msgs': [{'role': 'user', 'body': '빛은?'},
                                 {'role': 'ai', 'body': '첫째 날의 빛'},
                                 {'role': 'ai', 'body': 'GPT 의 빛', 'provider': 'OPENAI', 'model': 'o', 'mkind': ''},
                                 {'role': 'ai', 'body': '최종 정리본', 'mkind': 'INTEG', 'target': 'FINAL'},
                                 {'role': 'ai', 'body': '모르는 갈래', 'mkind': 'BOGUS'}]},
                 '2026-10-06 08:06:00')
        # ★ 2026-10-11 — 폰 공유로 담은 주소 둘(유튜브 · 웹 글) → PC 가 그 자리에서 저장하고 사본으로 돌려준다
        mine.add('SAVE_LINK', {'url': 'https://youtu.be/MSYNCtest01', 'title': '[MSYNC] 시편 1:2 설교',
                               'lang': 'KO'}, '2026-10-06 08:06:30')
        mine.add('SAVE_LINK', {'url': 'https://example.org/msync-article', 'title': '[MSYNC] 기사',
                               'lang': 'KO'}, '2026-10-06 08:06:40')
        # ★ 즐겨듣기 하트(영상 번호가 열쇠)
        mine.add('FAV_SET', {'fav_type': 'LISTEN', 'label': 'MSYNCtest01', 'note': '[MSYNC] 시편 1편 설교',
                             'on': True}, '2026-10-06 08:06:50')
        # ★ 2026-10-16 영상 취향 셋(채널 ♥ · 영상 숨김 · 채널 숨김) — 켜고 끄고 다시 켠다(멱등)
        mine.add('MEDIA_PREF', {'what': 'CH_FAV', 'key': '[MSYNC] 채널', 'on': True}, '2026-10-06 08:06:51')
        mine.add('MEDIA_PREF', {'what': 'M_HIDE', 'key': 987654321, 'on': True}, '2026-10-06 08:06:52')
        mine.add('MEDIA_PREF', {'what': 'CH_HIDE', 'key': '[MSYNC] 숨긴 채널', 'on': True}, '2026-10-06 08:06:53')
        mine.add('MEDIA_PREF', {'what': 'CH_HIDE', 'key': '[MSYNC] 숨긴 채널', 'on': False}, '2026-10-06 08:06:54')
        # ★ 2026-10-23 추천몰 내 쇼핑몰 ★ — 켜고(둘) 하나는 끈다
        mine.add('SHOP_FAV', {'mall': 'MSYNC_MALL', 'on': True}, '2026-10-06 08:06:54')
        mine.add('SHOP_FAV', {'mall': 'MSYNC_OFF', 'on': True}, '2026-10-06 08:06:54')
        mine.add('SHOP_FAV', {'mall': 'MSYNC_OFF', 'on': False}, '2026-10-06 08:06:54')
        mine.add('SHOP_HIDE', {'mall': 'MSYNC_HID', 'on': True}, '2026-10-06 08:06:54')
        # ★ 87 — 폰에서 녹음한 것 하나(Opus) → PC 가 받아 진척을 적고 사본으로 폰에 돌려준다
        import io as _io, numpy as _np, soundfile as _sf
        _b = _io.BytesIO()
        _sf.write(_b, (_np.sin(_np.linspace(0, 500, 48000)) * 0.2).astype('float32'), 48000,
                  format='OGG', subtype='OPUS', compression_level=0.88)
        _vd = _b.getvalue()
        mine.voices['__msync__|KJV|1'] = {'data': _vd, 'sha': hashlib.sha1(_vd).hexdigest()[:16],
                                          'made_at': '2026-10-06 08:06:55', 'origin': 'PHONE',
                                          'has_file': 1, 'sent': 0}
        mine.add('NOTE', {'body': '닻 없음'}, '2026-10-06 08:07:00')
        mine.add('FUTURE_KIND', {'x': 1}, '2026-10-06 08:08:00')
        r1 = sync_once(db, 'DAD', targets=tg)
        ck('첫 동기화는 전부', r1['mode'] == 'FULL' and r1['rows'] > 0, r1)
        ck('사건 열(공유 둘 · 즐겨듣기 하나 · 영상 취향 넷 포함)은 그 자리에서 저장', r1['events'] == 14 and r1['event_fail'] == 0, r1)
        ck('★ 추천몰 ★ — 켠 것은 PC 에 · 켰다 끈 것은 없다 · 사본으로 폰에 돌아간다',
           conn.execute("SELECT 1 FROM userdb.user_shop_fav WHERE mall_code='MSYNC_MALL'").fetchone() is not None
           and conn.execute("SELECT 1 FROM userdb.user_shop_fav WHERE mall_code='MSYNC_OFF'").fetchone() is None
           and any('MSYNC_MALL' in str(r) for r in mine.rows('user_shop_fav')))
        ck('★ 추천몰 숨기기 — PC 에 들어가고 사본으로 폰에 돌아간다',
           conn.execute("SELECT 1 FROM userdb.user_shop_hide WHERE mall_code='MSYNC_HID'").fetchone() is not None
           and any('MSYNC_HID' in str(r) for r in mine.rows('user_shop_hide')))
        ck('★ 폰 즐겨듣기 하트 → PC 에 켜지고 사본으로 돌아왔다',
           any('LISTEN' in str(r) and 'MSYNCtest01' in str(r) for r in mine.rows('user_favorite')))
        ck('★ 폰 공유 유튜브 → 내 영상이 폰 사본에 돌아왔다',
           any('MSYNCtest01' in str(r) for r in mine.rows('user_media_asset')))
        ck('영상 취향 — 채널 ♥ · 영상 숨김은 PC 에 · 켰다 끈 채널 숨김은 없다',
           conn.execute("SELECT 1 FROM userdb.user_channel_fav WHERE channel_name='[MSYNC] 채널'").fetchone() is not None
           and conn.execute('SELECT 1 FROM userdb.user_media_hide WHERE media_id=987654321').fetchone() is not None
           and conn.execute("SELECT 1 FROM userdb.user_channel_hide WHERE channel_name='[MSYNC] 숨긴 채널'").fetchone() is None)
        ck('영상 취향 — 사본으로 폰에 돌아간다',
           any('[MSYNC] 채널' in str(r) for r in mine.rows('user_channel_fav'))
           and any('987654321' in str(r) for r in mine.rows('user_media_hide')))
        with appdb.connect(db) as conn:
            r_ = conn.execute("SELECT user_media_id, category FROM userdb.user_media_asset WHERE url LIKE '%MSYNCtest01%'").fetchone()
            nv = conn.execute("SELECT COUNT(*) FROM userdb.user_link_asset WHERE link_type='UMED_VERS'"
                              " AND clicked_id=? AND COALESCE(record_status,'LIVE')='LIVE'", (r_[0],)).fetchone()[0] if r_ else 0
        ck('★ 폰이 모은 영상 — PC 가 갈래(설교)를 나누고 제목의 구절(시 1:2)을 이었다',
           r_ is not None and r_[1] == 'SERMON' and nv == 1, (r_, nv))
        ck('★ 폰 공유 웹 글 → 내 자료(WEB)가 폰 사본에 돌아왔다',
           any('msync-article' in str(r) and 'WEB' in str(r) for r in mine.rows('user_ref_asset')))
        ck('★ 폰 녹음 → PC 가 받고 진척이 사본으로 폰에 돌아왔다',
           (r1.get('voice_in') or {}).get('got') == 1 and mine.voices['__msync__|KJV|1']['sent'] == 1
           and any('__msync__' in str(r) for r in mine.rows('user_voice_asset')), r1.get('voice_in'))
        try:
            import shutil as _sh, voice_bible as _VB
            _sh.rmtree(_VB.VOICES_ROOT / '__msync__', ignore_errors=True)
        except Exception:                                 # noqa: BLE001
            pass
        ck('초안 넷 · 닻 없는 것 거절', r1['drafts'] == 4 and r1['draft_bad'] == 1, r1)
        ck('모르는 갈래는 폰에 남는다', [x['kind'] for x in mine.outbox] == ['FUTURE_KIND'])
        ck('★ 보낸 초안도 폰이 갖고 있는다(PC 가 걷으라 할 때까지)',
           len([x for x in mine.kept if x['kind'] in DRAFT_KINDS]) == 5, len(mine.kept))
        with appdb.connect(db) as conn:
            cnt = counts(conn)
            ck('폰 사본의 행 수가 PC 와 같다', all(len(mine.rows(t)) == n
                                              for t, n in cnt.items()))
            ck('폰이 받은 번호를 PC 가 기억', device(conn, 'DAD')['sent_seq']
               == mine.have and mine.have is not None, (mine.have,))
            ck('다 받은 변경은 지운다', conn.execute(
                'SELECT COUNT(*) FROM userdb.user_sync_change').fetchone()[0] == 0)
            ck('즐겨찾기 저장(구절)', conn.execute("SELECT COUNT(*) FROM user_favorite WHERE"
                                         " record_status='LIVE' AND fav_type<>'LISTEN'").fetchone()[0] == nfav0 + (0 if had_fav else 1)
               and conn.execute("SELECT 1 FROM user_favorite WHERE fav_type='VERSE' AND target_id=? AND record_status='LIVE'",
                                (vid,)).fetchone() is not None)
            r = conn.execute("SELECT result FROM userdb.user_mobile_event WHERE uuid=?",
                             (e_enr,)).fetchone()
            eid = int(r[0][4:])
            ck('폰에서 등록한 플랜이 2일째로', conn.execute(
                "SELECT current_day FROM user_plan_enrollment WHERE enrollment_id=?",
                (eid,)).fetchone()[0] == 2)
            ck('사본에 공동체 표가 없다', not any(t.startswith('user_room')
                                            for t in mine.store))
            # ★ 2026-10-16 폰에서 그만둔 묵상 → PC 도 ABANDONED(폰이 막 시작한 것 · uuid 로 찾는다)
            ck('폰에서 묵상 중단', apply_event(conn, 'PLAN_ABANDON', {'enroll_uuid': e_enr}) == 'OK'
               and conn.execute("SELECT enrollment_status FROM user_plan_enrollment WHERE enrollment_id=?",
                                (eid,)).fetchone()[0] == 'ABANDONED')
            ck('없는 등록은 FAIL', apply_event(conn, 'PLAN_ABANDON', {'enrollment_id': 0}).startswith('FAIL'))
            conn.rollback()
        mine.outbox = []
        # ── 하나 고치면 그 하나만 ──
        with appdb.connect(db) as conn:
            nid = conn.execute("SELECT MIN(user_text_id) FROM user_text_asset WHERE"
                               " COALESCE(room_id,'')=''").fetchone()[0]
            conn.execute("UPDATE user_text_asset SET contents=contents||' [MS-EDIT]'"
                         " WHERE user_text_id=?", (nid,))
            conn.commit()
        r2 = sync_once(db, 'DAD', targets=tg)
        ck('하나 고치면 바뀐 것만 — 1행', r2['mode'] == 'DELTA' and r2['rows'] == 1
           and r2['dels'] == 0, r2)
        ck('폰의 그 행이 바뀌었다', any('[MS-EDIT]' in str(x)
                                       for x in mine.rows('user_text_asset')))
        r3 = sync_once(db, 'DAD', targets=tg)
        ck('안 고치면 0행', r3['mode'] == 'DELTA' and r3['rows'] == 0 and r3['dels'] == 0, r3)
        # ── 지우면 폰에서도 ──
        with appdb.connect(db) as conn:
            lid = conn.execute("SELECT MAX(user_link_id) FROM user_link_asset").fetchone()[0]
            conn.execute("DELETE FROM user_link_asset WHERE user_link_id=?", (lid,))
            fid = conn.execute("SELECT MAX(fav_id) FROM user_favorite WHERE"
                               " record_status='LIVE'").fetchone()[0]
            conn.execute("UPDATE user_favorite SET record_status='HIDE' WHERE fav_id=?",
                         (fid,))
            conn.commit()
        r4 = sync_once(db, 'DAD', targets=tg)
        ck('지운 것·숨긴 것은 폰에서 지운다', r4['dels'] == 2 and r4['rows'] == 0, r4)
        ck('폰에서 실제로 사라졌다', not any(x[0] == lid for x in mine.rows('user_link_asset'))
           and not any(x[0] == fid for x in mine.rows('user_favorite')))
        # ── 끊기면 다음에 그대로 ──
        with appdb.connect(db) as conn:
            conn.execute("UPDATE user_text_asset SET contents=contents||' [MS-2]'"
                         " WHERE user_text_id=?", (nid,))
            conn.commit()
            s_before = device(conn, 'DAD')['sent_seq']
        mine.fail_mirror = 1
        try:
            sync_once(db, 'DAD', targets=tg); ck('받다 끊기면 오류를 말한다', False)
        except SyncError:
            ck('받다 끊기면 오류를 말한다', True)
        with appdb.connect(db) as conn:
            ck('끊기면 받은 번호를 안 올린다', device(conn, 'DAD')['sent_seq'] == s_before)
        r5 = sync_once(db, 'DAD', targets=tg)
        ck('다음 동기화에 그 변경이 간다', r5['rows'] == 1 and any(
            '[MS-2]' in str(x) for x in mine.rows('user_text_asset')), r5)
        # ── 어긋나면 그 표만 ──
        k0 = next(iter(mine.store['user_ai_prompt']['rows']))
        mine.store['user_ai_prompt']['rows'].pop(k0)
        r6 = sync_once(db, 'DAD', targets=tg)
        ck('행 수가 다른 표만 다시 보낸다', r6['fixed'] == 1, r6)
        with appdb.connect(db) as conn:
            ck('고친 뒤 행 수가 맞다', len(mine.rows('user_ai_prompt')) ==
               counts(conn)['user_ai_prompt'])
        # ── 폰을 새로 깔면 전부 ──
        mine.store, mine.have = {}, None
        r7 = sync_once(db, 'DAD', targets=tg)
        ck('폰이 비었으면 다시 전부', r7['mode'] == 'FULL', r7)
        # ── 폰 주소가 바뀌어도 찾는다 ──
        with appdb.connect(db) as conn:
            set_address(conn, 'DAD', '127.0.0.1', 1)
        sync_once(db, 'DAD', targets=tg)
        with appdb.connect(db) as conn:
            ck('방송으로 새 주소를 찾아 적는다', device(conn, 'DAD')['port'] == mine.port)
        # ── 초안 채택 ──
        with appdb.connect(db) as conn:
            # ⚠ 시험 DB 는 실제 개인 DB 의 사본이라 진짜 폰의 초안이 섞여 있을 수 있다 — 이 시험 폰 것만
            byk = {x['kind']: x for x in inbox(conn) if x['device_id'] == 'DAD'}
            d_note = byk['NOTE']
            d_note['data']['body'] = '[MSYNC] 빛이 있으라 — PC 에서 다듬음'
            update_draft(conn, d_note['inbox_id'], d_note['data'])
            ck('설명문 초안은 지금 PC 글과 견줄 수 있다',
               isinstance(current_for(conn, byk['DESC']), str))
        refs = {}
        for k in ('NOTE', 'DESC', 'REF', 'AI'):
            try:
                refs[k] = adopt(db, byk[k]['inbox_id'])
            except Exception as e:                        # noqa: BLE001
                refs[k] = 'ERR:%s' % e
        ck('넷 다 채택', all(not v.startswith('ERR') for v in refs.values()), refs)
        with appdb.connect(db) as conn:
            todo = [x for x in review(conn, 'TODO') if x['device_id'] == 'DAD']
            ck('⑥ 들인 넷이 점검 남음에', len(todo) == 4, len(todo))
            w_ = where_is(conn, [x for x in todo if x['kind'] == 'REF'][0])
            ck('⑥ 연구자료 자리를 지금 다시 본다', w_.get('alive') and w_.get('ref_id'), w_)
            set_checked(conn, todo[0]['inbox_id'])
            ck('⑥ 점검 끝 → 남음에서 빠진다', len([x for x in review(conn, 'TODO')
                                                 if x['device_id'] == 'DAD']) == 3)
            set_checked(conn, todo[0]['inbox_id'], on=False)
            ck('⑥ 다시 점검 → 돌아온다', len([x for x in review(conn, 'TODO')
                                              if x['device_id'] == 'DAD']) == 4)
        with appdb.connect(db) as conn:
            nid2 = int(refs['NOTE'].split(':')[1])
            c = conn.execute("SELECT contents FROM user_text_asset WHERE"
                             " user_text_id=?", (nid2,)).fetchone()
            ck('노트 — PC 에서 다듬은 글로', c and 'PC 에서 다듬음' in c[0])
            import overlay_edit as OE
            ck('설명문 — 덮개로', '내가 고친 설명' in (
                OE.pair_state(conn, 'VERS_DESC', vid, 'KO', 'LAY')[3] or ''))
            rid = int(refs['REF'].split(':')[1])
            # ⚠ 연결의 정본은 user_link_asset(UREF_VERS) — 옛 표를 보면 0(314차 ㊆)
            ck('연구자료 — 약명으로 구절이 이어졌다', conn.execute(
                "SELECT COUNT(*) FROM user_link_asset WHERE link_type='UREF_VERS'"
                " AND clicked_id=?", (rid,)).fetchone()[0] >= 1)
            _lv = {r[0]: r[1] for r in conn.execute(
                "SELECT target_id, COALESCE(record_status,'LIVE') FROM user_link_asset WHERE link_type='UREF_VERS'"
                " AND clicked_id=?", (rid,))}
            ck('★ 폰에서 뺀 후보는 안 걸리고(HIDE) · 찾아 더한 구절은 걸린다',
               _lv.get(_jn14) == 'HIDE' and _lv.get(vid) == 'LIVE' and _lv.get(vid + 4) == 'LIVE', _lv)
            # ★ 2026-10-25 폰 글의 `|` 표 → PC 정본(자리표 + 표 구조) · 출처 = 폰이 적은 것(MINE)
            _rb = conn.execute("SELECT body_text FROM user_ref_text WHERE ref_id=?", (rid,)).fetchone()[0]
            _tn = conn.execute("SELECT n_rows, n_cols FROM user_ref_table WHERE ref_id=? AND COALESCE(record_status,'LIVE')='LIVE'",
                               (rid,)).fetchall()
            ck('★ 폰 글의 표 — 자리표 + 표 구조(2줄 2칸)', '[[T1]]' in _rb and '|' not in _rb and _tn == [(2, 2)], (_rb, _tn))
            ck('★ 출처 — 폰이 적은 「내가 작성」', conn.execute("SELECT ref_origin FROM user_ref_asset WHERE ref_id=?", (rid,)).fetchone()[0] == 'MINE')
            _ol = conn.execute("SELECT link_type, target_id FROM user_link_asset WHERE clicked_id=? AND link_type IN"
                               " ('UREF_ENTI','UREF_LEMM') AND COALESCE(record_status,'LIVE')='LIVE'", (rid,)).fetchall()
            ck('★ 폰이 원어로 보낸 승격 원어 → 그 용어로 이음', ('UREF_ENTI', 319) in _ol and not any(
                lt == 'UREF_LEMM' for lt, _t in _ol), _ol)
            # ★ 2026-10-25 (3단계) 폰에서 그 글을 고쳤다 — 새 글이 아니라 그 글이 바뀐다 · 표·구절도 따라간다
            _n0 = conn.execute("SELECT COUNT(*) FROM user_ref_asset").fetchone()[0]
            store_draft(conn, 'DAD', {'kind': 'REF', 'uuid': 'MSYNC-REF-EDIT', 'made_at': '2026-10-06 09:00:00',
                                      'data': {'ref_id': rid, 'title': '[MSYNC] 빛 고침', 'lang': 'KO', 'origin': 'MINE',
                                               'ref_type': 'SERMON',
                                               'body': '창 1:4 를 읽고 고친 글\n| 날 | 지으심 | 뜻 |\n|---|---|---|\n| 첫째 | 빛 | 시작 |',
                                               'links_drop': [], 'links_add': []}})
            conn.commit()
            _ed = [x for x in inbox(conn) if x['uuid'] == 'MSYNC-REF-EDIT'][0]
            ck('★ 고친 글은 지금 PC 글과 견줄 수 있다(표는 | 꼴로)', '| 날 | 지으심 |' in current_for(conn, _ed).replace('  ', ' ')
               or '날' in current_for(conn, _ed), current_for(conn, _ed)[:80])
        _er = adopt(db, _ed['inbox_id'])
        with appdb.connect(db) as conn:
            _rb2 = conn.execute("SELECT title, body_text FROM user_ref_text WHERE ref_id=? AND UPPER(lang_code)='KO'",
                                (rid,)).fetchone()
            _tn2 = conn.execute("SELECT n_rows, n_cols FROM user_ref_table WHERE ref_id=? AND COALESCE(record_status,'LIVE')='LIVE'",
                                (rid,)).fetchall()
            ck('★ 폰에서 고친 글 — 같은 글이 바뀐다(새 글 없음)', _er == 'REF:%d' % rid and conn.execute(
                "SELECT COUNT(*) FROM user_ref_asset").fetchone()[0] == _n0 and '고친 글' in _rb2[1]
               and _rb2[0] == '[MSYNC] 빛 고침', (_er, _rb2))
            ck('★ 고친 표 — 2줄 3칸', _tn2 == [(2, 3)], _tn2)
            ck('★ 고친 유형 — 설교', conn.execute("SELECT ref_type FROM user_ref_asset WHERE ref_id=?",
                                                 (rid,)).fetchone()[0] == 'SERMON')
            _lv2 = {r[0] for r in conn.execute(
                "SELECT target_id FROM user_link_asset WHERE link_type='UREF_VERS' AND clicked_id=?"
                " AND COALESCE(record_status,'LIVE')='LIVE'", (rid,))}
            ck('★ 고친 글의 약명(창 1:4)이 이어지고 · 사라진 약명(창 1:3)의 자동 연결은 걷힌다',
               vid + 1 in _lv2 and vid not in _lv2 and vid + 4 in _lv2, _lv2)
        with appdb.connect(db) as conn:
            cid_ = int(refs['AI'].split(':')[1])
            ck('AI 대화 — 대화목록에', conn.execute(
                "SELECT COUNT(*) FROM user_ai_msg WHERE chat_id=?", (cid_,)).fetchone()[0] == 5)
            ms_ = conn.execute("SELECT body, provider, model, COALESCE(target,''), COALESCE(mkind,'')"
                               " FROM user_ai_msg WHERE chat_id=? ORDER BY msg_id", (cid_,)).fetchall()
            ck('AI 대화 — 말마다 회사·모델(없으면 초안 것)',
               ms_[1][1:3] == ('GEMINI', 'g') and ms_[2][1:3] == ('OPENAI', 'o'), ms_)
            ck('★ AI 대화 — 최종 정리본이 PC 통합본(INTEG·FINAL)으로', ms_[3][3:] == ('FINAL', 'INTEG'), ms_[3])
            ck('AI 대화 — 모르는 갈래는 보통 답으로', ms_[4][4] == '', ms_[4])
        # ★ 2026-10-14 — 폰 AI 결과를 담는 새 갈래 셋(용어 설명문 · 연결설명문 · 원어 설명)도 같은 설명문 초안 문으로 들어온다
        with appdb.connect(db) as conn:
            _eid = conn.execute("SELECT entity_id FROM sys_entity_master LIMIT 1").fetchone()[0]
            _lid = 999999                                  # 연결설명문은 연결 번호만 열쇠다(시험 DB 에 연결 표가 없다)
            _new3 = [('ENTITY_DESC', _eid, '[MSYNC] 내 용어 설명'), ('VERS_VERS_DESC', _lid, '[MSYNC] 내 연결설명'),
                     ('LEMMA_DESC', 1002617, '[MSYNC] 내 원어 설명')]
            for _i, (tt_, cid3, tx3) in enumerate(_new3):
                store_draft(conn, 'DAD', {'uuid': 'msync-new3-%d' % _i, 'kind': 'DESC',
                                          'data': {'text_type': tt_, 'clicked_id': cid3, 'lang': 'KO',
                                                   'variant': '', 'contents': tx3}})
            conn.commit()
            ids3 = [x['inbox_id'] for x in inbox(conn) if x['uuid'].startswith('msync-new3-')]
        res3 = []
        for i3 in ids3:
            try:
                res3.append(adopt(db, i3))
            except Exception as e:                        # noqa: BLE001
                res3.append('ERR:%s' % e)
        with appdb.connect(db) as conn:
            import overlay_edit as OE
            got3 = [OE.target_state(conn, tt_, cid3, 'KO', '')[2] for tt_, cid3, _t in _new3]
            # 아래 「들인 넷」 셈을 흐리지 않게 — 이 시험이 넣은 초안은 함에서 걷는다
            conn.execute("DELETE FROM userdb.user_mobile_inbox WHERE uuid LIKE 'msync-new3-%'")
            conn.commit()
        ck('★ 용어·연결·원어 설명 초안도 덮개(내 글)로 들어간다',
           len(ids3) == 3 and not any(str(r).startswith('ERR') for r in res3)
           and got3 == [t for _a, _b, t in _new3], (res3, got3))
        # ★ 2026-10-14 폰 설명 판 ⋯ — 「원래 글로」·「안 보이기」는 글 없이 온다
        st4 = []
        for _i, act in enumerate(('REVERT', 'HIDE')):
            with appdb.connect(db) as conn:
                ok4 = store_draft(conn, 'DAD', {'uuid': 'msync-act-%d' % _i, 'kind': 'DESC',
                                                'data': {'text_type': 'VERS_DESC', 'clicked_id': vid, 'lang': 'KO',
                                                         'variant': 'LAY', 'action': act}})
                conn.commit()
                i4 = [x['inbox_id'] for x in inbox(conn) if x['uuid'] == 'msync-act-%d' % _i]
            try:
                adopt(db, i4[0])
            except Exception as e:                        # noqa: BLE001
                st4.append('ERR:%s' % e)
            with appdb.connect(db) as conn:
                import overlay_edit as OE
                st4.append((ok4, OE.target_state(conn, 'VERS_DESC', vid, 'KO', 'LAY')[1]))
                conn.execute("DELETE FROM userdb.user_mobile_inbox WHERE uuid LIKE 'msync-act-%'")
                conn.commit()
        ck('★ 원래 글로 → 내 글이 걷힌다 · 안 보이기 → 가림', st4[0][1] in ('SYS', 'NONE') and st4[1][1] == 'HIDDEN'
           and st4[0][0] == st4[1][0] == 'NEW', st4)
        try:
            adopt(db, byk['NOTE']['inbox_id']); ck('두 번 채택은 거부', False)
        except ValueError:
            ck('두 번 채택은 거부', True)
        r8 = sync_once(db, 'DAD', targets=tg)
        # 넷 + PC 에서 넣어 본 「고친 글」 초안 하나(3단계 시험) = 다섯
        ck('★ PC 에 들인 넷은 폰에서 걷힌다(사본이 대신한다)',
           r8.get('drafts_dropped') == 5 and len(mine.kept) == 1, (r8.get('drafts_dropped'), len(mine.kept)))
        ck('채택한 글이 바뀐 것으로 폰에 간다', r8['mode'] == 'DELTA' and r8['rows'] >= 4
           and any('PC 에서 다듬음' in str(x) for x in mine.rows('user_text_asset')), r8)
        mine.add('NOTE_ADD', {'note_id': nid2, 'body': '[MSYNC] 덧붙임'})
        sync_once(db, 'DAD', targets=tg)
        with appdb.connect(db) as conn:
            add = [x for x in inbox(conn) if x['kind'] == 'NOTE_ADD'][0]
            ck('덧붙이기 — 지금 PC 글을 보인다', '다듬음' in current_for(conn, add))
        adopt(db, add['inbox_id'])
        with appdb.connect(db) as conn:
            c = conn.execute("SELECT contents FROM user_text_asset WHERE"
                             " user_text_id=?", (nid2,)).fetchone()[0]
            ck('덧붙이기 — 옛 글 뒤에', '다듬음' in c and '덧붙임' in c)
        # ★ 2026-10-21 폰에서 PC 노트 고치기 · 지우기
        mine.add('NOTE_EDIT', {'note_id': nid2, 'body': '[MSYNC] 폰에서 고친 글'})
        mine.add('NOTE_DEL', {'note_id': nid2})
        sync_once(db, 'DAD', targets=tg)
        with appdb.connect(db) as conn:
            ed = [x for x in inbox(conn) if x['kind'] == 'NOTE_EDIT'][0]
            de = [x for x in inbox(conn) if x['kind'] == 'NOTE_DEL'][0]
            ck('고치기 — 지금 PC 글을 보인다', '덧붙임' in current_for(conn, ed))
        adopt(db, ed['inbox_id'])
        with appdb.connect(db) as conn:
            c = conn.execute("SELECT contents, record_status FROM user_text_asset WHERE user_text_id=?", (nid2,)).fetchone()
            ck('고치기 — 본문이 바뀐다(옛 글 없음)', '폰에서 고친 글' in c[0] and '덧붙임' not in c[0], c[0][:80])
        adopt(db, de['inbox_id'])
        with appdb.connect(db) as conn:
            st = conn.execute("SELECT record_status FROM user_text_asset WHERE user_text_id=?", (nid2,)).fetchone()[0]
            ck('지우기 — HIDE(되돌릴 수 있다)', st == 'HIDE', st)
        ck('지우기 — 글 없이 받는다', check_draft('NOTE_DEL', {'note_id': 5}) == '' and
           check_draft('NOTE_DEL', {}) == 'NO_TARGET' and check_draft('NOTE_EDIT', {'note_id': 5}) == 'EMPTY')
        # ── 폰에서 책을 빼면 PC 보낼 목록에서도 뺀다(2026-10-12) ──
        with appdb.connect(db) as conn:
            set_send(conn, books=['AAA|KO', 'BBB|KO'])
            r_pd = apply_event(conn, 'PACK_DROP', {'name': 'mobile_book_AAA_KO.json.gz'})
            ck('★ 폰에서 뺀 책은 PC 보낼 목록에서 빠진다', r_pd == 'DROPPED' and get_send(conn)['books'] == ['BBB|KO'],
               get_send(conn))
            set_send(conn, books=[])
            conn.commit()
        # ── 2026-10-28 공동체몰 파일 방식 — 관리자 폰이 받은 사장님 가게 파일 → 이 PC 파일 몰의 대기 ──
        with appdb.connect(db) as conn:
            import cmall_admin as _CA
            import cmall_ref as _CR

            class _S:
                def __enter__(self):
                    return conn

                def __exit__(self, *a):
                    return False
            _CA._FILE_MALLS.clear()
            _fm = _CA.new_file_mall(_S, '[MSYNC] 파일몰', '')
            _CA.save(conn, _CA.load(conn) + [_fm])
            _sid = _CR.new_sid()
            r_cm = apply_event(conn, 'CMALL_STORE', _CR.store_file(_fm['url'], 'new', _sid, 'k' * 24, {'name': '[MSYNC] 가게'}))
            r_cx = apply_event(conn, 'CMALL_STORE', _CR.store_file('file:0000000000000000', 'new', _sid, 'k' * 24, {'name': 'x'}))
            _CA._FILE_MALLS.clear()
            _rows = _CA.file_mall(_S, _fm)
            ck('★ 공동체몰 가게 파일 → 이 PC 파일 몰 대기 · 다른 몰은 SKIP', r_cm == 'TAKEN' and r_cx == 'SKIP' and
               any(x['id'] == _sid and x['state'] == 'PENDING' for x in _rows.d['rows']), (r_cm, r_cx))
            ck('몰 파일 표가 사본 목록에', any(t == 'user_cmall_outfile' for t, _ in MIRROR_TABLES))
            _CA.save(conn, [x for x in _CA.load(conn) if x['url'] != _fm['url']])
            conn.execute('DELETE FROM userdb.user_cmall_file WHERE file_id=?', (_fm['url'],))
            _CA._FILE_MALLS.clear()
            conn.commit()
        # ── 2026-10-20 폰 AI 대화 = 함께 쓰기(바통) — 처음 더하고 · 안 고쳤으면 바꾸고 · 지우면 휴지통 ──
        with appdb.connect(db) as conn:
            _c1 = {'uid': 'u-chat-1', 'title': '[MSYNC] 대화', 'lang': 'KO', 'edits': 2, 'by': 'PHONE', 'share': True,
                   'msgs': [{'role': 'user', 'body': '왜?'}, {'role': 'ai', 'body': '답 1', 'provider': 'GEMINI', 'model': 'g'}]}
            r1 = apply_event(conn, 'AI_CHAT', _c1)
            _c1 = dict(_c1, edits=4, msgs=_c1['msgs'] + [{'role': 'user', 'body': '더?'}, {'role': 'ai', 'body': '답 2'}])
            r2 = apply_event(conn, 'AI_CHAT', _c1)
            cids = conn.execute("SELECT chat_id FROM user_ai_chat WHERE phone_uid='u-chat-1'").fetchall()
            nm = conn.execute("SELECT COUNT(*) FROM user_ai_msg WHERE chat_id=?", (cids[0][0],)).fetchone()[0] if cids else 0
            r3 = apply_event(conn, 'AI_CHAT', dict(_c1, edits=5, trashed_at='2026-10-20 10:00:00'))
            st = conn.execute("SELECT record_status FROM user_ai_chat WHERE phone_uid='u-chat-1'").fetchone()
            ck('★ 폰 AI 대화 — 처음 더함 · 다시 오면 같은 대화를 바꿈 · 휴지통도 옮겨 온다',
               (r1, r2, r3) == ('ADDED', 'REPLACED', 'TRASHED') and len(cids) == 1 and nm == 4 and st[0] == 'TRASH',
               (r1, r2, r3, len(cids), nm, st))
            # ★ 2026-10-22 PC 에 없던 대화가 휴지통 상태로 오면 만들지 않는다
            r4 = apply_event(conn, 'AI_CHAT', {'uid': 'u-chat-2', 'title': '[MSYNC] 폰에서만', 'lang': 'KO', 'edits': 3,
                                               'by': 'PHONE', 'trashed_at': '2026-10-22 09:00:00',
                                               'msgs': [{'role': 'user', 'body': 'x'}]})
            n2 = conn.execute("SELECT COUNT(*) FROM user_ai_chat WHERE phone_uid='u-chat-2'").fetchone()[0]
            ck('★ PC 에 없던 대화가 휴지통 상태로 오면 만들지 않는다', r4 == 'SKIP' and n2 == 0, (r4, n2))
            sm = summary({'events': 1, 'drafts': 0, 'mode': 'DELTA', 'rows': 0, 'dels': 0, 'event_fail': 0,
                          'draft_bad': 0, 'unknown': 0, 'event_dup': 0, 'draft_dup': 0, 'ai_trashed': 2,
                          'ai_chats': 3, 'ai_out_trash': 1})
            ck('★ 결과 줄 — 폰에서 지운 대화가 PC 휴지통으로 · PC 에서 지운 것이 폰 휴지통으로',
               'PC 휴지통' in sm and '폰 휴지통' in sm and '2개' in sm and '2개를 폰으로' in sm, sm)
            conn.execute("DELETE FROM user_ai_msg WHERE chat_id IN (SELECT chat_id FROM user_ai_chat WHERE phone_uid='u-chat-1')")
            conn.execute("DELETE FROM user_ai_chat WHERE phone_uid='u-chat-1'")
            conn.commit()
        # ── 2026-10-20 폰 연결구절 ✎ — 숨기기·다시 보이기 · 추가 · 내 연결 지우기(덮개 · sys 불변) ──
        with appdb.connect(db) as conn:
            if not conn.execute("SELECT 1 FROM sqlite_master WHERE name='sys_link_asset'").fetchone():
                conn.execute("CREATE TABLE sys_link_asset(sys_link_id INTEGER PRIMARY KEY, link_type TEXT, clicked_id INT,"
                             " target_id INT, rel_code TEXT, end_id INT, note TEXT, chain_code TEXT, sort_order INT,"
                             " record_status TEXT DEFAULT 'LIVE')")
                conn.execute("INSERT INTO sys_link_asset(link_type, clicked_id, target_id, rel_code) VALUES('VERS_VERS', 1, 2, 'REF')")
            _ls = conn.execute("SELECT sys_link_id, clicked_id, target_id, rel_code FROM sys_link_asset"
                               " WHERE link_type='VERS_VERS' LIMIT 1").fetchone()
            _sys0 = conn.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
            if _ls:
                h1 = apply_event(conn, 'LINK_HIDE', {'ids': [_ls[0]], 'on': True})
                hs = conn.execute("SELECT record_status FROM userdb.user_link_asset WHERE link_type='VERS_VERS'"
                                  " AND clicked_id=? AND target_id=? AND COALESCE(rel_code,'')=?",
                                  (_ls[1], _ls[2], _ls[3] or '')).fetchone()
                h2 = apply_event(conn, 'LINK_HIDE', {'ids': [_ls[0]], 'on': False})
                hs2 = conn.execute("SELECT COUNT(*) FROM userdb.user_link_asset WHERE link_type='VERS_VERS'"
                                   " AND clicked_id=? AND target_id=? AND COALESCE(rel_code,'')=?",
                                   (_ls[1], _ls[2], _ls[3] or '')).fetchone()[0]
                a1 = apply_event(conn, 'LINK_ADD', {'a': 31000, 'b': 2, 'rel': 'ALL', 'desc': '[MSYNC] 내 연결 설명', 'lang': 'KO'})
                _ud = conn.execute("SELECT t.contents FROM userdb.user_text_asset t JOIN userdb.user_link_asset u"
                                   " ON t.clicked_id=u.user_link_id WHERE t.text_type='VERS_VERS_DESC'"
                                   " AND u.clicked_id=2 AND u.target_id=31000").fetchone()
                ck('★ 폰 연결 추가 + 연결설명문 → 내 연결의 내 글', _ud and _ud[0] == '[MSYNC] 내 연결 설명', _ud)
                ad1 = conn.execute("SELECT record_status FROM userdb.user_link_asset WHERE link_type='VERS_VERS'"
                                   " AND clicked_id=2 AND target_id=31000 AND rel_code='ALL'").fetchone()
                d1 = apply_event(conn, 'LINK_DEL', {'a': 2, 'b': 31000, 'rel': 'ALL'})
                ad2 = conn.execute("SELECT COUNT(*) FROM userdb.user_link_asset WHERE link_type='VERS_VERS'"
                                   " AND clicked_id=2 AND target_id=31000 AND rel_code='ALL'").fetchone()[0]
                _sys1 = conn.execute("SELECT COUNT(*) FROM sys_link_asset").fetchone()[0]
                ck('★ 폰 연결 ✎ — 숨기기 = HIDE 행 · 다시 보이기 = 지움 · 추가 = 내 연결(작은 번호 앞) · 내 연결 지우기 · sys 불변',
                   (h1, hs and hs[0], h2, hs2, a1, ad1 and ad1[0], d1, ad2, _sys0 == _sys1)
                   == ('HIDDEN', 'HIDE', 'SHOWN', 0, 'NEW', 'LIVE', 'DELETED', 0, True),
                   (h1, hs, h2, hs2, a1, ad1, d1, ad2, _sys0, _sys1))
            conn.commit()
        # ── 77 기도 — 프롬프트 교환(기도 업무만) · 백업은 보관만(켰을 때만 온다) · 끄면 PC 보관분을 지운다 ──
        with appdb.connect(db) as conn:
            r_ap = apply_event(conn, 'AI_PROMPT', {'kind': 'T_PR_VERSE', 'lang': 'KO', 'body': '[MSYNC] 기도 프롬프트'})
            r_ap2 = apply_event(conn, 'AI_PROMPT', {'kind': 'T_ASK', 'lang': 'KO', 'body': 'x'})
            import user_ai as _UA
            r_ap3 = apply_event(conn, 'AI_PROMPT', {'kind': 'T_PR_UMSYNC1', 'lang': 'KO', 'title': '내 기도 업무', 'body': '[MSYNC] 내 글'})
            _mine = [t for t in _UA.prayer_bundle(conn, 'KO')['tasks'] if t['kind'] == 'T_PR_UMSYNC1']
            r_ap4 = apply_event(conn, 'AI_PROMPT', {'kind': 'T_PR_UMSYNC1', 'lang': 'KO', 'deleted': True})
            ck('★ 폰에서 더한 기도 프롬프트가 PC 에 · 지우면 HIDE', r_ap3 == 'SAVED' and _mine and _mine[0]['title'] == '내 기도 업무'
               and _mine[0]['mine'] == 1 and r_ap4 == 'HIDDEN'
               and not [t for t in _UA.prayer_bundle(conn, 'KO')['tasks'] if t['kind'] == 'T_PR_UMSYNC1'], (r_ap3, r_ap4))
            conn.execute("DELETE FROM user_ai_prompt WHERE kind='T_PR_UMSYNC1'")
            import user_ai as _UA
            ck('★ 폰에서 수정한 기도 프롬프트가 PC 에 · 다른 업무는 안 받는다',
               r_ap == 'SAVED' and r_ap2 == 'SKIP' and _UA.task_row(conn, 'T_PR_VERSE', 'KO')[2] == '[MSYNC] 기도 프롬프트'
               and _UA.prayer_bundle(conn, 'KO')['tasks'][0]['body'] == '[MSYNC] 기도 프롬프트', (r_ap, r_ap2))
            r1 = apply_event(conn, 'PRAYER_SAVE', {'uid': 'u1', 'data': {'name': '가', 'text': '나'}})
            r2 = apply_event(conn, 'PRAYER_SAVE', {'uid': 'u1', 'data': {'text': '나', 'name': '가'}})
            apply_event(conn, 'PRAYER_SAVE', {'uid': 'u2', 'data': {'name': '다'}})
            r3 = apply_event(conn, 'PRAYER_SAVE', {'uid': 'u2', 'deleted': True})
            n_pb = conn.execute('SELECT COUNT(*) FROM userdb.user_prayer_backup').fetchone()[0]
            r4 = apply_event(conn, 'PRAYER_CLEAR', {})
            n_pb2 = conn.execute('SELECT COUNT(*) FROM userdb.user_prayer_backup').fetchone()[0]
            ck('★ 기도 백업 — 보관·같으면 안 씀·지움·끄면 비움',
               (r1, r2, r3, r4, n_pb, n_pb2) == ('SAVED', 'SAME', 'REMOVED', 'CLEARED', 1, 0),
               (r1, r2, r3, r4, n_pb, n_pb2))
            ck('기도 보관분은 폰 사본 표에 실린다(되살리기)', any(t == 'user_prayer_backup' for t, _ in MIRROR_TABLES))
            conn.commit()
        # ── 폰이 SNS 로 받은 플랜 → PC 내 플랜 · 그 플랜으로 시작(2026-10-14 87) ──
        with appdb.connect(db) as conn:
            pk = 'S-msynctest1'
            r_pi = apply_event(conn, 'PLAN_IMPORT', {'plan': {'key': pk, 'title': '[MSYNC] 받은 플랜', 'lang': 'KO',
                               'days': [{'d': 1, 'r': [{'v': [vid, vid]}]}, {'d': 2, 'r': [{'v': [vid + 1, vid + 2]}]}]}})
            r_pi2 = apply_event(conn, 'PLAN_IMPORT', {'plan': {'key': pk, 'title': 'x', 'days': [{'d': 1, 'r': [{'v': [vid, vid]}]}]}})
            ck('★ 폰이 받은 플랜이 PC 내 플랜으로 · 두 번 와도 하나', r_pi.startswith('NEW:') and r_pi2.startswith('SAME:'),
               (r_pi, r_pi2))
            r_en = apply_event(conn, 'PLAN_ENROLL', {'plan_key': pk, 'start_date': '2026-10-14'})
            upid = int(r_pi.split(':')[1])
            row = conn.execute("SELECT user_plan_id FROM user_plan_enrollment WHERE enrollment_id=?",
                               (int(r_en[4:]) if r_en.startswith('ENR:') else -1,)).fetchone()
            ck('★ 열쇠로 시작한 등록이 그 내 플랜을 가리킨다', row and row[0] == upid, (r_en, row))
            conn.rollback()
        # ── 첫 이주 — 대기 글 전부를 한 번에(폰이 먼저 · 2026-10-12) ──
        for i in range(3):
            mine.add('NOTE', {'start_vid': vid, 'body': '[MSYNC] 첫 이주 %d' % i}, '2026-10-06 08:5%d:00' % i)
        sync_once(db, 'DAD', targets=tg)
        n_all, bad_all = adopt_all(db)
        with appdb.connect(db) as conn:
            left = [x for x in inbox(conn, 'NEW') if '첫 이주' in str(x['data'].get('body'))]
        ck('★ 첫 이주 — 대기 글 전부를 한 번에 PC 에 들인다', n_all >= 3 and not bad_all and not left, (n_all, bad_all))
        # ── 다운로드 안함 — 폰의 글을 지울지(기본 = 안 지움) ──
        mine.kept = []
        mine.add('NOTE', {'start_vid': vid, 'body': '[MSYNC] 남겨 둘 글'}, '2026-10-06 09:00:00')
        mine.add('NOTE', {'start_vid': vid, 'body': '[MSYNC] 지울 글'}, '2026-10-06 09:01:00')
        sync_once(db, 'DAD', targets=tg)
        with appdb.connect(db) as conn:
            nn = {x['data']['body']: x for x in inbox(conn) if x['kind'] == 'NOTE'}
            discard(conn, nn['[MSYNC] 남겨 둘 글']['inbox_id'])
            discard(conn, nn['[MSYNC] 지울 글']['inbox_id'], phone_drop=True)
        r9 = sync_once(db, 'DAD', targets=tg)
        left = [x['data']['body'] for x in mine.kept]
        ck('★ 다운로드 안함(기본) — 폰의 글은 남는다 · 지우기를 선택한 것만 걷힌다',
           left == ['[MSYNC] 남겨 둘 글'] and r9.get('drafts_dropped') == 1, (left, r9.get('drafts_dropped')))
        r9b = sync_once(db, 'DAD', targets=tg)
        ck('  한 번 알린 것은 다시 안 알린다', not r9b.get('drafts_dropped'))
        # ── 팩 보내기(PC → 폰) ──
        import gzip as _gz
        import base64 as _b64
        pk = os.path.join(tmp, 'packs')
        os.makedirs(pk, exist_ok=True)

        def mk(n, body):
            fp = os.path.join(pk, n)
            with open(fp, 'wb') as fo:
                with _gz.GzipFile(fileobj=fo, mode='wb', mtime=0) as g:
                    g.write(json.dumps(body).encode('utf-8'))
            return fp
        f1 = mk('mobile_core_KO.json.gz', {'kind': 'MCORE', 'tables': {}})
        f2 = mk('mobile_book_A_KO.json.gz', {'kind': 'MBOOK', 'key': 'A', 'tables': {}})
        f3 = mk('mobile_book_B_KO.json.gz', {'kind': 'MBOOK', 'key': 'B', 'tables': {},
                                             'x': _b64.b64encode(os.urandom(900000)).decode()})
        with appdb.connect(db) as conn:
            dv = device(conn, 'DAD')
        h0, p0, k0 = dv['host'], dv['port'], dv['key']
        ck('hello 가 폰 언어를 말한다', call(h0, p0, k0, 'hello').get('lang') == 'KO')
        ck('★ 사본과 함께 폰 AI 꾸러미가 간다(업무마다 보낼 글)', mine.ai and mine.ai.get('lang') == 'KO'
           and mine.ai.get('tasks') and all(t['prompt'] and mine.ai['q'] in t['prompt_q']
                                             for t in mine.ai['tasks']), (mine.ai or {}).keys())
        ck('  AI 키는 켜지 않으면 안 간다', 'AI_ACCOUNTS' not in (mine.config or {}))
        r1 = push_packs(h0, p0, k0, [f1, f2, f3])
        ck('★ 팩 셋을 폰이 받아 담았다', sorted(mine.packs) == sorted(
            os.path.basename(x) for x in (f1, f2, f3)) and len(r1['sent']) == 3, r1)
        ck('  큰 팩은 조각으로 나뉘어 간다', os.path.getsize(f3) > PACK_CHUNK * 2, os.path.getsize(f3))
        ck('  받은 글자가 그대로', mine.packs['mobile_book_B_KO.json.gz']['data'] == open(f3, 'rb').read())
        r2 = push_packs(h0, p0, k0, [f1, f2, f3])
        ck('★ 폰에 같은 것이 있으면 안 보낸다', r2['sent'] == [] and r2['same'] == 3, r2)
        r3 = push_packs(h0, p0, k0, [f1, f3])
        ck('★ 선택하지 않은 책은 폰에서 걷는다(코어는 안 걷는다)',
           r3['gone'] == ['mobile_book_A_KO.json.gz'] and 'mobile_core_KO.json.gz' in mine.packs, r3)
        bad = call_raw(h0, p0, k0, 'pack_put', {'name': '../x.json.gz', 'sha': '0', 'part': 0,
                                                'parts': 1, 'b64': ''})
        ck('  이상한 이름은 거절', not bad.get('ok') and bad.get('why') == 'BAD_NAME', bad)
        bad = call_raw(h0, p0, k0, 'pack_put', {'name': 'mobile_book_C_KO.json.gz', 'sha': 'nope',
                                                'part': 0, 'parts': 1,
                                                'b64': _b64.b64encode(b'xx').decode()})
        ck('  sha 가 다르면 담지 않는다', not bad.get('ok') and 'mobile_book_C_KO.json.gz' not in mine.packs)
        # 진짜 책 한 권(이 PC 의 DB) — 고르면 동기화가 그 책을 만들어 보낸다
        import db_mobile_core as MC
        with appdb.connect(appdb.resolve_db('bible_master.db')) as rc:
            small = min(MC.books_on_pc(rc, 'KO'), key=lambda b: b['chars'])
            bp = MC.build_book(rc, small['code'], 'KO', pk)[0]
        r4 = push_packs(h0, p0, k0, [f1, bp])
        nm = os.path.basename(bp)
        ck('★ 진짜 도서 팩이 폰에 MBOOK 로 담긴다', mine.packs.get(nm, {}).get('kind') == 'MBOOK', r4)
        fc = mk('mobile_common.json.gz', {'kind': 'MCORE', 'key': 'COMMON', 'tables': {}})
        fk = mk('mobile_lang_KO.json.gz', {'kind': 'MLANG', 'lang': 'KO', 'tables': {}})
        fe = mk('mobile_lang_EN.json.gz', {'kind': 'MLANG', 'lang': 'EN', 'tables': {}})
        push_packs(h0, p0, k0, [fe, bp])
        r6 = push_packs(h0, p0, k0, [fc, fk, bp])
        ck('★ 공통 + 언어팩을 보내면 옛 통째 코어팩(mobile_core_*)은 걷는다',
           'mobile_core_KO.json.gz' in r6['gone'] and 'mobile_core_KO.json.gz' not in mine.packs, r6)
        ck('★ 다른 언어팩(EN)은 안 걷는다 — 사람이 지운다',
           'mobile_lang_EN.json.gz' in mine.packs and 'mobile_common.json.gz' in mine.packs, sorted(mine.packs))
        with appdb.connect(db) as conn:
            set_send(conn, core=False, books=['A', 'A'])
            ck('보낼 것 설정 — 겹친 책은 하나', get_send(conn) == {'core': False, 'books': ['A']})
            set_send(conn, books=[])
            # 위에서 손으로 보낸 진짜 책 = PC 가 보낸 것(이력) · 폰이 서버에서 받은 책 하나는 이력이 없다
            note_packs(conn, 'DAD', {'sent': [nm]}, [bp])
            conn.commit()
        fz = mk('mobile_book_ZZZ_KO.json.gz', {'kind': 'MBOOK', 'tables': {}})
        push_packs(h0, p0, k0, [fc, fk, fz, bp])
        r5 = sync_once(db, 'DAD', targets=tg)
        with appdb.connect(db) as conn:
            hist = sent_history(conn, 'DAD')
            ck('★ 보낸 자료 이력 — 걷은 때가 적힌다',
               any(h['gone_at'] for h in hist) and phone_packs(conn) is not None, hist[:2])
        ck('★ 동기화가 선택한 책이 없으면 PC 가 보낸 도서 팩을 걷는다',
           nm not in mine.packs and r5.get('pack_gone', 0) >= 1, r5)
        ck('★ 폰이 서버에서 직접 받은 책은 안 걷는다(폰이 먼저 · 2026-10-12)',
           'mobile_book_ZZZ_KO.json.gz' in mine.packs, sorted(mine.packs))
        # ── 재전송 · 오래된 요청 ──
        k = mine.key
        blob = seal(k, {'op': 'hello', 'ts': int(time.time()), 'rid': 'fixedrid'})
        mine._handle(blob, pair_id(k))
        ck('같은 요청을 다시 보내면 거절', unseal(k, mine._handle(blob, pair_id(k))[1])
           .get('why') == 'REPLAY')
        old = seal(k, {'op': 'hello', 'ts': int(time.time()) - 3600, 'rid': 'x2'})
        ck('오래된 요청은 거절', unseal(k, mine._handle(old, pair_id(k))[1])
           .get('why') == 'STALE')
        # ── 짝 끊기 ──
        with appdb.connect(db) as conn:
            unpair(conn, 'DAD')
            ck('짝을 끊으면 변경 기록이 비고 더 안 적는다', conn.execute(
                'SELECT COUNT(*) FROM userdb.user_sync_change').fetchone()[0] == 0)
            n1 = cut_seq(conn)
            conn.execute("UPDATE user_text_asset SET contents=contents WHERE"
                         " user_text_id=?", (nid,))
            conn.commit()
            ck('…그 뒤로는 적지 않는다', cut_seq(conn) == n1)
    finally:
        for ph in phones:
            ph.stop()
        shutil.rmtree(tmp, ignore_errors=True)
    after = (os.path.getsize(real_user), os.path.getmtime(real_user))
    ck('실제 개인 DB 자국 0', before == after, (before, after))
    print('mobile_sync selftest %d/%d' % (ok[0], sum(ok)))
    return ok[1] == 0


def status():
    import appdb
    with appdb.connect('bible_master.db') as conn:
        ensure(conn)
        for d in devices(conn):
            print('폰', d['device_id'], d['name'], '%s:%s' % (d['host'], d['port']),
                  '· 마지막', d['last_sync'] or '-', '·', d['last_result'] or '')
        for st in ('NEW', 'ADOPTED', 'DISCARDED'):
            print('초안', st, len(inbox(conn, st)))


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    if '--status' in sys.argv:
        status()
        sys.exit(0)
    print(__doc__)
