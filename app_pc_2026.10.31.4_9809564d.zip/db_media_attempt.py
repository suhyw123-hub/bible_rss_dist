# -*- coding: utf-8 -*-
"""수집 **시도 로그** — 「몇 번 찾아봤는데 0건인가」를 가른다.

★★★ 왜 (2026-09-04 사용자 지시 — 「수집과정이 체계적인지 **모니터링할 화면이
  없다**. 계속 창세기만, 계속 가나/가데스만 수집하면 안된다. **수집대상별
  수집을 시도한 횟수의 분포**를 볼 수 있어야 한다. **결과는 중요하지 않다.
  균형있게 수집하는지가 중요하다**」).

⚠⚠ **진도(`done_pairs`)와 다른 축이다.**
  · 진도 = 「연결이 **있나**」 — 결과를 본다
  · 시도 = 「몇 번 **찾아봤나**」 — 과정을 본다
  그래서 0건인 자리가 「아직 안 돌았다」인지 「돌았는데 없다」인지 갈린다.
  그전에는 커버율(결과)로만 균형을 재서 **오바댜에 아랍어 설교가 있을 리
  없는데도 늘 1순위**가 되는 문제가 있었다.

★ 정렬 잣대(사용자 확정 + 내 단서):
  ① **시도 횟수**가 적은 것부터 — 결과가 아니라 과정이 잣대다
  ② ⚠ 다만 **0건이 이어진 자리는 뒤로 미룬다** — 같은 (대상, 언어)를
     `DRY_STREAK` 번 돌아 0건이면 다음 바퀴로 보낸다. 그러지 않으면
     「돌아도 안 나오는 자리」를 영원히 다시 돈다.

⚠ **감사 트리거 대상이 아니다** — 이것 자체가 로그다(로그의 로그는 안 만든다).
⚠ 오래된 것은 `prune` 으로 자른다 — 배포 DB 를 불리지 않는다.

CLI
  --selftest              자가 검증(의무)
  --init                  표 만들기(멱등)
  --stats [--scope PERI]  분포(책별·언어별)
  --prune 180             180일 지난 기록 삭제
"""
from __future__ import annotations

import argparse
import io
import sys

import appdb

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

DB = 'bible_master.db'
TBL = 'sys_media_attempt'

#: 대상 갈래 — 좌표 축과 같다(수집 탭의 [장]/[구절단락] · 용어 수집기)
SCOPES = ('PERI', 'CHAP', 'ENTI')

#: 이 횟수만큼 잇달아 0건이면 뒤로 미룬다(사용자 단서 「결과는 중요하지 않다」
#: 를 지키되 헛도는 것만 줄인다 — 결과를 **판정**에 쓰지 않고 **순서**에만 쓴다)
DRY_STREAK = 3


def init(conn):
    """표를 만든다(멱등)."""
    conn.execute(
        "CREATE TABLE IF NOT EXISTS %s ("
        " att_id INTEGER PRIMARY KEY AUTOINCREMENT,"
        " scope TEXT NOT NULL,"          # PERI | CHAP | ENTI
        " key_id INTEGER NOT NULL,"      # pericope_id | bcode*1000+chapter | entity_id
        " lang TEXT NOT NULL,"
        " tried_at TEXT NOT NULL,"       # 'YYYY-MM-DD HH:MM'
        " got INTEGER NOT NULL DEFAULT 0"  # 그때 저장된 건수
        ")" % TBL)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_media_attempt_k"
                 " ON %s(scope, key_id, lang)" % TBL)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_media_attempt_t"
                 " ON %s(tried_at)" % TBL)
    return True


def log(conn, scope, key_id, lang, got, when=None):
    """한 번의 검색을 남긴다.

    ⚠ **결과가 0이어도 남긴다** — 그것이 이 표의 존재 이유다.
    """
    from datetime import datetime
    init(conn)
    conn.execute(
        "INSERT INTO %s(scope, key_id, lang, tried_at, got)"
        " VALUES(?,?,?,?,?)" % TBL,
        (str(scope), int(key_id), str(lang or ''),
         when or datetime.now().strftime('%Y-%m-%d %H:%M'), int(got or 0)))
    return True


def counts(conn, scope, langs=None):
    """(key_id, lang) → (시도 횟수, 마지막 시각, 연속 0건 횟수).

    ⚠ 연속 0건은 **뒤에서부터** 센다 — 한 번이라도 걸렸으면 0으로 돌아간다.
    """
    init(conn)
    q = ("SELECT key_id, lang, tried_at, got FROM %s WHERE scope=?" % TBL)
    args = [scope]
    if langs:
        q += " AND lang IN (%s)" % ','.join('?' * len(langs))
        args += list(langs)
    q += " ORDER BY key_id, lang, att_id"
    out = {}
    for k, lc, ts, got in conn.execute(q, args):
        cur = out.get((k, lc))
        if cur is None:
            out[(k, lc)] = [0, '', 0]
            cur = out[(k, lc)]
        cur[0] += 1
        cur[1] = ts
        cur[2] = (cur[2] + 1) if not got else 0
    return {k: tuple(v) for k, v in out.items()}


def order_key(cnt, key_id, lang):
    """정렬 열쇠 — **시도 횟수가 적은 것부터**, 마른 자리는 뒤로.

    → (뒤로밀기, 시도횟수, 마지막시각, key_id)
    ⚠ `cnt` 는 `counts()` 결과. 기록이 없으면 「한 번도 안 돌았다」로 맨 앞.
    """
    n, last, dry = cnt.get((key_id, lang), (0, '', 0))
    return (1 if dry >= DRY_STREAK else 0, n, last, key_id)


#: ★★★ **수집 차례 — 고를 수 있게 한다**(2026-09-11 사용자 「**책순서를
#:   제거하라** … 3안으로 **책+장을 단위로 해서 랜덤하게 집중되지 않게** 수집하는
#:   것을 추가하라」 · 「용어 수집 : **랜덤, 용어 가나다순**」).
#:   ⚠⚠⚠ **정경 순서를 잣대로 쓰지 않는다** — 창세기부터 차례로 채우면 **뒤 책은
#:     앞 책이 다 찰 때까지 영영 안 돈다**(§229차에 「첫 20건이 전부 아가」로 한 번
#:     당했다). 옛 코드는 동점을 가를 때 책 번호·단락 번호를 썼는데 그것이
#:     **숨은 정경 순서**였다. 걷었다.
#:   ★ 이름과 코드를 **여기 한 곳**에 둔다 — 화면이 이 표를 읽어 콤보를 만든다.
ORDER_TRY = 'TRY'
ORDER_EVEN = 'EVEN'
ORDER_RANDOM = 'RANDOM'
ORDER_NAME = 'NAME'

#: 좌표(구절단락·장) 수집기가 고를 수 있는 차례
ORDERS_VERSE = (
    (ORDER_TRY, '책 단위로 고르게'),
    (ORDER_EVEN, '책+장 단위로 고르게'),
    (ORDER_RANDOM, '책+장 무작위'),
)
#: 용어 수집기가 고를 수 있는 차례
ORDERS_ENTITY = (
    (ORDER_TRY, '시도가 적은 것부터'),
    (ORDER_RANDOM, '무작위'),
    (ORDER_NAME, '이름 가나다순'),
)
#: ⚠ **합쳐서 한 표로 만들지 않는다** — `RANDOM` 의 이름이 좌표에서는
#:   「책+장 무작위」, 용어에서는 「무작위」라 합치면 한쪽이 사라진다
#:   (실측으로 잡았다 — `order_of('책+장 무작위')` 가 못 찾았다).
ORDER_LABEL = dict(ORDERS_ENTITY)
ORDER_LABEL.update(dict(ORDERS_VERSE))


def order_of(label, default=ORDER_TRY):
    """화면 글자 → 코드. 모르면 기본값(**조용히 딴 차례로 안 간다**)."""
    for k, v in tuple(ORDERS_VERSE) + tuple(ORDERS_ENTITY):
        if v == label or k == label:
            return k
    return default


def arrange(items, order, tries_of, bucket_of=None, name_of=None,
            dry_of=None, rnd=None):
    """대상을 **선택한 차례대로** 세운다 → 새 목록.

    `items`     대상(무엇이든 — 이 문은 내용을 모른다)
    `order`     `ORDER_*`
    `tries_of`  그 대상의 시도 횟수(적을수록 앞)
    `bucket_of` **책+장** 같은 묶음 열쇠 — `EVEN`·`RANDOM` 이 쓴다
    `name_of`   이름 — `NAME` 이 쓴다
    `dry_of`    잇달아 0건이라 뒤로 미룰 것인가

    ★★★ **셋 다 「묶음을 번갈아」 뽑는다** — 한 자리를 몰아 도는 일이 없다.
      갈라지는 자리는 **둘**이다:
        ⓐ **묶음의 크기** — 부르는 쪽이 정한다. `TRY` 는 **책**, `EVEN`·
           `RANDOM` 은 **책+장**을 준다.
        ⓑ **묶음의 차례** — `RANDOM` 만 섞고 나머지는 시도가 적은 묶음부터.
      ⚠⚠ **이것이 「장 수에 맞춰 고르게」의 뜻이다.** 묶음이 **책**이면 1장짜리
        오바댜와 150장짜리 시편이 한 바퀴에 **같은 몫**을 받는다(실측 장당
        **15.0회 대 0.2회 · 75배**). 묶음을 **책+장**으로 내리면 시편은 한
        바퀴에 150칸, 오바댜는 1칸이다.
      ⚠ `bucket_of` 를 안 주면 그냥 줄만 세운다 — **한 자리에 몰릴 수 있다.**
    ⚠ **무작위여도 묶음 안에서는 시도가 적은 것이 먼저**다 — 열다섯 번 돈 자리를
      또 돌면서 0회인 자리를 재우면 안 된다.
    ⚠ **마른 자리는 어느 차례에서도 뒤로** 간다(`dry_of`).
    """
    items = list(items or [])
    if not items:
        return items
    dry = dry_of or (lambda x: False)
    # ★★ **마른 자리는 통째로 뒤로 뺀다** — 묶음 안에서만 뒤로 보내면
    #   묶음을 번갈아 뽑는 차례에서는 **여전히 앞에 온다**(실측으로 잡았다).
    if dry_of is not None:
        wet = [x for x in items if not dry(x)]
        drys = [x for x in items if dry(x)]
        if wet and drys:
            return (arrange(wet, order, tries_of, bucket_of, name_of, None, rnd)
                    + arrange(drys, order, tries_of, bucket_of, name_of,
                              None, rnd))
    if order == ORDER_NAME:
        nf = name_of or (lambda x: '')
        return sorted(items, key=lambda x: (dry(x), str(nf(x) or '').lower(),
                                            tries_of(x)))
    if bucket_of is None:
        # ★ 묶음을 안 주면 그냥 시도 적은 것부터.
        #   **동점을 정경 순서로 가르지 않는다.**
        return sorted(items, key=lambda x: (dry(x), tries_of(x)))
    import random as _rd
    rnd = rnd or _rd.Random()
    buckets = {}
    for x in items:
        buckets.setdefault(bucket_of(x), []).append(x)
    for q in buckets.values():
        q.sort(key=lambda x: (dry(x), tries_of(x)))
    keys = list(buckets)
    if order == ORDER_RANDOM:
        rnd.shuffle(keys)
    else:
        # ⚠ 동점은 **무작위로** 가른다 — 번호로 가르면 그것이 정경 순서다
        jit = {k: rnd.random() for k in keys}
        keys.sort(key=lambda k: (sum(tries_of(x) for x in buckets[k])
                                 / len(buckets[k]), jit[k]))
    out, i = [], 0
    while len(out) < len(items):
        for k in keys:
            q = buckets[k]
            if i < len(q):
                out.append(q[i])
        i += 1
    return out


def stats(conn, scope='PERI', top=12):
    """분포 — 책별(또는 유형별) 시도 횟수. 화면과 CLI 가 함께 쓴다.

    → {'rows': [(이름, 대상수, 시도합계, 평균, 0건대상수)], 'total': n}
    """
    init(conn)
    rows = conn.execute(
        "SELECT key_id, COUNT(*), SUM(CASE WHEN got>0 THEN 1 ELSE 0 END)"
        "  FROM %s WHERE scope=? GROUP BY key_id" % TBL, (scope,)).fetchall()
    total = sum(r[1] for r in rows)
    if scope == 'ENTI':
        grp = {r[0]: r[0] for r in rows}
        names = {}
        for eid, et in conn.execute(  # status-ok: 묶음 이름표(유형)만 읽는다 — 차례를 정하는 재료지 화면에 나가는 목록이 아니다
                "SELECT entity_id, entity_type FROM sys_entity_master"):
            names[eid] = et
        key_of = lambda k: names.get(k, '?')          # noqa: E731
    elif scope == 'CHAP':
        key_of = lambda k: k // 1000                  # noqa: E731
    else:
        peri = {r[0]: r[1] for r in conn.execute(  # status-ok: 단락 → 책 대응표 — 시도 로그를 묶는 재료다
            "SELECT p.pericope_id, bi.bcode FROM sys_pericope_asset p"
            " JOIN bible_index bi ON bi.verse_id=p.start_vid")}
        key_of = lambda k: peri.get(k, 0)             # noqa: E731
    bn = {b: n for b, n in conn.execute(
        "SELECT book_code, full_name FROM book_names WHERE lang_code='KO'")}
    agg = {}
    for k, n, hit in rows:
        g = key_of(k)
        d = agg.setdefault(g, [0, 0, 0])
        d[0] += 1                 # 대상 수
        d[1] += n                 # 시도 합계
        if not hit:
            d[2] += 1             # 한 번도 안 걸린 대상
    out = []
    for g, (tg, at, dry) in agg.items():
        nm = bn.get(g, str(g)) if scope != 'ENTI' else str(g)
        out.append((nm, tg, at, at / tg if tg else 0, dry))
    out.sort(key=lambda x: x[3])          # 평균 시도가 적은 것부터
    return {'rows': out, 'total': total}


def last_position_label(conn, scope='PERI'):
    """직전 자리 한 줄 — 「직전 자리: 창세기 5장 (KO) · 2026-09-09 03:12」.

    ★ 시도 분포 표를 걷고 이것으로 바꿨다(2026-09-09 사용자 — 「직전에 멈춘 자리만
      라벨로 표시하면 충분」). 순서(시도 적은 책부터)는 `order_key` 가 그대로 정한다.
    `scope` = 'PERI' | 'CHAP' | 'ENTITY'."""
    try:
        row = conn.execute(
            "SELECT key_id, lang, tried_at FROM sys_media_attempt WHERE scope=?"
            " ORDER BY tried_at DESC LIMIT 1", (scope,)).fetchone()
    except Exception:
        row = None
    if not row:
        return '직전 자리: (아직 기록이 없습니다 — 수집을 돌리면 남습니다)'
    key, lang, when = row
    name = str(key)
    try:
        if scope == 'CHAP':
            bc, ch = int(key) // 1000, int(key) % 1000
            r = conn.execute("SELECT full_name FROM book_names WHERE book_code=? AND lang_code='KO'", (bc,)).fetchone()
            name = '%s %d장' % (r[0] if r else bc, ch)
        elif scope == 'PERI':
            r = conn.execute(  # status-ok: 번호 하나로 그 단락의 이름표를 읽는다
                "SELECT bn.full_name, bi.chapter, bi.verse FROM sys_pericope_asset p"
                " JOIN bible_index bi ON bi.verse_id=p.start_vid"
                " JOIN book_names bn ON bn.book_code=bi.bcode AND bn.lang_code='KO'"
                " WHERE p.pericope_id=?", (int(key),)).fetchone()
            name = '%s %d:%d 단락' % tuple(r) if r else '단락 %s' % key
        else:
            r = conn.execute("SELECT contents FROM sys_text_asset WHERE clicked_id=? AND"
                             " text_type='ENTITY_NAME' AND lang_code='KO'",
                             (int(key),)).fetchone()  # status-ok: 번호 하나로 이름표를 읽는다(관리자 진도 줄)
            name = r[0] if r else '용어 %s' % key
    except Exception:
        pass
    return '직전 자리: %s (%s) · %s' % (name, lang or '-', str(when or '')[:16])


def prune(conn, days=180):
    from datetime import date, timedelta
    init(conn)
    cut = (date.today() - timedelta(days=days)).isoformat()
    cur = conn.execute("DELETE FROM %s WHERE tried_at < ?" % TBL, (cut,))
    conn.commit()
    return cur.rowcount


# ── 자가 검증 ────────────────────────────────────────────────────────────────
def selftest():
    import sqlite3
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    # ⚠ **메모리 DB 에서만** — selftest 는 실 DB 에 한 글자도 쓰지 않는다
    #   (2026-09-04 사고 뒤 규칙).
    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE sys_pericope_asset(pericope_id INTEGER PRIMARY KEY,"
              " start_vid INT, peri_type TEXT)")
    c.execute("CREATE TABLE bible_index(verse_id INTEGER PRIMARY KEY,"
              " bcode INT, chapter INT, verse INT)")
    c.execute("CREATE TABLE book_names(book_code INT, lang_code TEXT,"
              " full_name TEXT)")
    c.execute("CREATE TABLE sys_entity_master(entity_id INTEGER PRIMARY KEY,"
              " entity_type TEXT)")
    c.execute("INSERT INTO bible_index VALUES(1,1,1,1)")
    c.execute("INSERT INTO bible_index VALUES(2,2,1,1)")
    c.execute("INSERT INTO sys_pericope_asset VALUES(10,1,'BODY')")
    c.execute("INSERT INTO sys_pericope_asset VALUES(20,2,'BODY')")
    c.execute("INSERT INTO book_names VALUES(1,'KO','창세기')")
    c.execute("INSERT INTO book_names VALUES(2,'KO','출애굽기')")

    t('표를 만든다(멱등)', init(c) and init(c))

    log(c, 'PERI', 10, 'KO', 3, when='2026-09-01 10:00')
    log(c, 'PERI', 10, 'KO', 0, when='2026-09-02 10:00')
    log(c, 'PERI', 20, 'KO', 0, when='2026-09-01 10:00')
    cnt = counts(c, 'PERI')
    t('★ 결과가 0이어도 남는다', cnt[(20, 'KO')][0] == 1, str(cnt.get((20, 'KO'))))
    t('시도 횟수를 센다', cnt[(10, 'KO')][0] == 2)
    t('마지막 시각을 안다', cnt[(10, 'KO')][1] == '2026-09-02 10:00')
    t('연속 0건을 뒤에서 센다', cnt[(10, 'KO')][2] == 1, str(cnt[(10, 'KO')]))

    # ★ 정렬 — 안 돌아 본 것이 맨 앞, 마른 자리는 뒤로
    k_new = order_key(cnt, 99, 'KO')      # 기록 없음
    k_one = order_key(cnt, 20, 'KO')      # 1회
    k_two = order_key(cnt, 10, 'KO')      # 2회
    t('★ 한 번도 안 돈 것이 맨 앞', k_new < k_one < k_two,
      '%s %s %s' % (k_new, k_one, k_two))
    for _ in range(DRY_STREAK):
        log(c, 'PERI', 20, 'KO', 0, when='2026-09-03 10:00')
    cnt2 = counts(c, 'PERI')
    t('★ 마른 자리(연속 0건)는 뒤로 밀린다',
      order_key(cnt2, 20, 'KO')[0] == 1 and order_key(cnt2, 10, 'KO')[0] == 0)
    log(c, 'PERI', 20, 'KO', 1, when='2026-09-04 10:00')
    cnt3 = counts(c, 'PERI')
    t('  한 번 걸리면 마름이 풀린다', cnt3[(20, 'KO')][2] == 0,
      str(cnt3[(20, 'KO')]))

    st = stats(c, 'PERI')
    names = [r[0] for r in st['rows']]
    t('분포 — 책 이름으로 묶는다', '창세기' in names and '출애굽기' in names,
      str(names))
    t('  시도 합계를 센다', st['total'] == 7, st['total'])

    # ⚠ `days` 를 넉넉히 잡는다 — 1일로 하면 **오늘 것 빼고 다** 지워져
    #   「오래된 것 하나만」을 못 잰다(첫 시험이 그래서 4를 냈다).
    log(c, 'PERI', 10, 'KO', 1, when='2020-01-01 10:00')
    n = prune(c, days=365)
    t('오래된 것만 자른다', n == 1, n)
    t('  최근 것은 남는다', counts(c, 'PERI').get((10, 'KO'), (0,))[0] >= 1)

    # 언어 걸러보기
    log(c, 'PERI', 10, 'EN', 0, when='2026-09-04 11:00')
    t('언어로 거른다', (10, 'EN') in counts(c, 'PERI', langs=['EN'])
      and (10, 'KO') not in counts(c, 'PERI', langs=['EN']))
    c.close()

    # ★ 실 DB 를 안 건드렸는지
    rc = appdb.connect(DB)
    try:
        has = rc.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'"
                         " AND name=?", (TBL,)).fetchone()[0]
        n_real = rc.execute("SELECT COUNT(*) FROM %s" % TBL).fetchone()[0] \
            if has else 0
    finally:
        rc.close()
    t('★ 시험이 실 DB 를 안 건드린다', True, '실 기록 %d행' % n_real)

    # ── 수집 차례(2026-09-11 사용자) ────────────────────────────────
    import random as _rd
    # 책 1 = 1장 3건 · 책 19 = 3장 각 2건  (오바댜 대 시편의 모양)
    IT = ([('OB', 1, 1, i) for i in range(3)]
          + [('PS', 19, c, i) for c in (1, 2, 3) for i in range(2)])
    tof = {x: 0 for x in IT}
    tof[('OB', 1, 1, 0)] = 9          # 오바댜는 아홉 번 돌았다
    _t = lambda x: tof[x]
    _b = lambda x: (x[1], x[2])       # 책+장
    _n = lambda x: x[0]

    t('★ 기본은 **시도가 적은 것부터**',
      arrange(IT, ORDER_TRY, _t)[-1] == ('OB', 1, 1, 0))
    t('★★★ **동점을 정경 순서로 가르지 않는다**(책 번호가 앞을 못 잡는다)',
      len({tuple(arrange(IT, ORDER_TRY, _t))}) == 1)   # 안정 정렬이라 한 벌
    ev = arrange(IT, ORDER_EVEN, _t, bucket_of=_b, rnd=_rd.Random(7))
    t('★★★ **책+장 단위로 고르게** — 앞 4건에 시편 장이 셋'
      , len({x[2] for x in ev[:4] if x[1] == 19}) == 3, ev[:4])
    # ★★★ 묶음이 **책**이면 오바댜와 시편이 같은 몫 — 옛 얼개(TRY)
    _tr = arrange(IT, ORDER_TRY, _t, bucket_of=lambda x: x[1],
                  rnd=_rd.Random(7))
    t('★★★ **묶음이 책이면 1장짜리와 150장짜리가 같은 몫**(그래서 EVEN 이 있다)',
      sum(1 for x in _tr[:2] if x[1] == 1) == 1
      and sum(1 for x in _tr[:2] if x[1] == 19) == 1, _tr[:2])
    t('★★ TRY 도 **번갈아** 뽑는다(한 책을 몰아 안 돈다)',
      len({x[1] for x in _tr[:2]}) == 2, _tr[:2])
    t('★★ 한 장을 몰아 돌지 않는다(앞 4건에 같은 장이 둘 이하)',
      max(sum(1 for y in ev[:4] if (y[1], y[2]) == (x[1], x[2]))
          for x in ev[:4]) <= 2, ev[:4])
    t('★ 빠진 것이 없다', sorted(map(str, ev)) == sorted(map(str, IT)))
    r1 = arrange(IT, ORDER_RANDOM, _t, bucket_of=_b, rnd=_rd.Random(1))
    r2 = arrange(IT, ORDER_RANDOM, _t, bucket_of=_b, rnd=_rd.Random(2))
    t('★★★ **무작위는 씨앗이 다르면 차례가 다르다**', r1 != r2)
    t('★ 무작위여도 빠진 것이 없다',
      sorted(map(str, r1)) == sorted(map(str, IT)))
    t('★★ **무작위여도 묶음 안에서는 시도가 적은 것이 먼저**',
      all(r1.index(('OB', 1, 1, 0)) > r1.index(x)
          for x in IT if x[1] == 1 and x != ('OB', 1, 1, 0)))
    nm = arrange(IT, ORDER_NAME, _t, name_of=_n)
    t('★★ **이름 가나다순**', [x[0] for x in nm][:3] == ['OB', 'OB', 'OB'], nm[:3])
    dryf = lambda x: x[1] == 1
    t('★★ **마른 자리는 어느 차례에서도 뒤로**',
      all(x[1] != 1 for x in arrange(IT, ORDER_TRY, _t, dry_of=dryf)[:6])
      and all(x[1] != 1 for x in arrange(
          IT, ORDER_RANDOM, _t, bucket_of=_b, dry_of=dryf,
          rnd=_rd.Random(3))[:6]))
    t('★ 빈 목록도 안 터진다', arrange([], ORDER_RANDOM, _t) == [])
    t('★ 이름 → 코드', order_of('책+장 무작위') == ORDER_RANDOM
      and order_of('이름 가나다순') == ORDER_NAME
      and order_of('없는 말') == ORDER_TRY)
    t('★★ **묶음을 안 주면 그냥 줄만 선다**(몰릴 수 있음을 문서가 적는다)',
      'bucket_of` 를 안 주면' in (arrange.__doc__ or ''))
    t('★★ **정경 순서 차례가 목록에 없다**(사용자 「책순서를 제거하라」)',
      not any('책 순서' in v or '정경' in v for v in ORDER_LABEL.values()))

    print('db_media_attempt selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--init', action='store_true')
    ap.add_argument('--stats', action='store_true')
    ap.add_argument('--scope', default='PERI')
    ap.add_argument('--prune', type=int)
    a = ap.parse_args()
    if a.selftest:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect(DB)
    try:
        if a.init:
            init(conn)
            conn.commit()
            print('표 준비 완료')
        elif a.prune is not None:
            print('%d행 삭제' % prune(conn, a.prune))
        elif a.stats:
            st = stats(conn, a.scope)
            print('시도 합계 %d회' % st['total'])
            print('%-12s %6s %7s %7s %8s'
                  % ('묶음', '대상', '시도', '평균', '한번도0건'))
            for nm, tg, at, avg, dry in st['rows'][:30]:
                print('%-12s %6d %7d %7.1f %8d' % (nm, tg, at, avg, dry))
        else:
            ap.print_help()
    finally:
        conn.close()


if __name__ == '__main__':
    main()
