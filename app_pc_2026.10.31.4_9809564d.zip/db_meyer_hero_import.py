# -*- coding: utf-8 -*-
"""
db_meyer_hero_import.py — F. B. 메이어 **인물 중심 묵상집** 적재 (2026-09-18 신설·영구)
================================================================================
  python db_meyer_hero_import.py --selftest              — 의무
  python db_meyer_hero_import.py --links  [CODE]         — **받기 전에 링크를 보인다**
  python db_meyer_hero_import.py --fetch  [CODE] --links-confirmed
  python db_meyer_hero_import.py --check  [CODE]         — 장 나누기 · 두 곳 대조
  python db_meyer_hero_import.py --apply  [CODE]         — 적재(멱등)
  python db_meyer_hero_import.py --undo   [CODE]         — 되돌리기(HIDE)

━━ 왜 이 책인가 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
`data.md` **Z-2e** — 우리 앱에는 **인물 축**이 이미 서 있는데(`figure_pool` 10명 ·
인물묵상 플랜 · 주요용어 PERSON 181개) **채울 글이 없다.** 메이어의 「Old
Testament Heroes」 여덟 권이 바로 그 자리의 글이고, 1847~**1929 사망**이라
퍼블릭 도메인이다. 같은 저자 `MEYER_ODH` 1,373유닛이 이미 적재돼 있다.

━━ §0-1b 규칙을 코드가 지킨다 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  규칙 ⓪ **받기 전에 링크를 보인다** → `db_book_source_match.require_ack`
  규칙 ① `ORIGINAL` 은 **파일에서 읽는다** → 이 파일에 본문 글자가 없다
  규칙 ② **두 곳이 서로 일치해야 받는다** → `--check` 가 양방향 80% 문지기
  규칙 ③ **파일이 스스로 밝히는 제목·저자**를 본다 → `_meta_ok`
  규칙 ④ **저작권 표시를 파일에서 확인한다** → `COPYRIGHTED` 가 있으면 거부
  규칙 ⑤ 판본을 특정할 수 있는 쪽 → 판권 표기를 `IMPRINT` 에 적는다

━━ 이 책의 생김새(실측) ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  · 목차 28장 → 본문은 **홑 로마숫자 줄**이 장 표지다(`II.` `III.` …).
  · 그 다음 줄이 **장식체 제목**인데 OCR 이 통째로 깨뜨린다
    (`Steltiwrattr* tig Jttaitt 3fom` = Deliverance by Main Force).
    ⇒ **제목은 본문이 아니라 목차에서 가져온다.** 깨진 줄은 걷는다.
  · 그 다음이 **성구 제사**(`"By faith, Moses…" — Heb. xi. 23.`) —
    저자가 고른 구절이라 `key_verse_ref` 로 남기고 좌표까지 푼다.
  ⚠⚠ **머리글자(드롭캡)가 두 스캔 모두에서 빠진다** — `T was on a very…`
    (= It) · `HE Bible is the book…`(= The). **채워 넣지 않는다**(§0-1b —
    본문에 우리가 지어낸 글자를 넣지 않는다). 소개문이 그 사실을 적는다.
  ⚠ 스캔마다 놓치는 장 표지가 다르다(실측 Revell 26/27 · Morgan 22/27).
    ⇒ **두 스캔의 표지를 합쳐서** 자른다 — 한쪽에 없는 자리는 다른 쪽의
      첫 문장을 찾아 메운다.
"""
import io
import os
import re
import sqlite3
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb
import db_book_source_match as SM
import db_book_verify as V
import ref_verse_parser as RP

HERE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(HERE, '_meyer_raw')

GATE = 0.80          # 두 곳 대조 문지기(§0-1b 규칙 ②)
ROMAN = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI',
         'XII', 'XIII', 'XIV', 'XV', 'XVI', 'XVII', 'XVIII', 'XIX', 'XX',
         'XXI', 'XXII', 'XXIII', 'XXIV', 'XXV', 'XXVI', 'XXVII', 'XXVIII',
         'XXIX', 'XXX', 'XXXI', 'XXXII']

# ── 책 ─────────────────────────────────────────────────────────────────────
# ⚠ 주소를 **문서에 미리 박지 않는다**는 Z-2e 의 경고는 「검증 전에 박지
#   말라」는 뜻이다. 아래 둘은 2026-09-18 에 카탈로그에서 실제로 확인하고
#   받아 **양방향 96%/97%** 로 대조를 통과한 주소다(`--check` 가 다시 잰다).
IA = 'https://archive.org/download/%s/%s_djvu.txt'
IAD = 'https://archive.org/details/%s'

BOOKS = {
    'MEYER_MOSES': {
        'title': 'Moses: the Servant of God',
        'author': 'F. B. Meyer',
        'year': 1909,
        'imprint': 'Morgan & Scott, London, 1909 (Seventh Impression)'
                   ' · Fleming H. Revell, New York',
        'figure': '모세',
        'category': 'DEVOTIONAL',
        # (이름, IA 식별자, 본문이 시작하는 표지, 목차가 끝나는 표지)
        'primary': ('Fleming H. Revell (New York)', 'mosesservantofgo00meye',
                    'MOSES :  The  Servant  of  God.'),
        'cross': ('Morgan & Scott (London) 1909', 'mosestheservanto00meyeuoft',
                  'MOSES:  THE  SERVANT  OF  GOD.'),
        'chapters': 28,
    },
}
DEFAULT = 'MEYER_MOSES'

ATTRIB = '\n\n— F. B. Meyer, "%s" (%s). Public domain.'


# ── 받기 ───────────────────────────────────────────────────────────────────
def cands(code):
    b = BOOKS[code]
    out = []
    for role in ('primary', 'cross'):
        name, idf, _m = b[role]
        out.append(('%s (%s)' % (name, role), IAD % idf))
    return out


def raw_path(idf):
    return os.path.join(RAW, idf + '.txt')


def fetch(code, log=print):
    """**확인을 받지 않았으면 한 바이트도 받지 않는다**(§0-1b 규칙 ⓪)."""
    b = BOOKS[code]
    SM.require_ack(code, cands(code),
                   note='   ⚠ 두 곳 모두 대출 제한이 없는 옛 스캔이다'
                        '(access-restricted-item 없음).')
    if not os.path.isdir(RAW):
        os.makedirs(RAW)
    for role in ('primary', 'cross'):
        _n, idf, _m = b[role]
        p = raw_path(idf)
        subprocess.run(['curl', '-sL', '--max-time', '180', '-A', 'Mozilla/5.0',
                        '-o', p, IA % (idf, idf)], capture_output=True)
        log('  %-30s %s 바이트' % (idf, os.path.getsize(p) if os.path.exists(p) else '없음'))


# ── 파일이 스스로 밝히는 것 (규칙 ③·④) ────────────────────────────────────
def _meta_ok(text, code):
    """제목·저자가 맞는가 · **저작권이 살아 있다고 적혀 있지 않은가**."""
    head = text[:60000]
    flat = re.sub(r'\s+', ' ', head).upper()
    why = []
    if 'MEYER' not in flat:
        why.append('저자 이름(MEYER)이 파일 머리에 없다')
    if 'MOSES' not in flat:
        why.append('제목(MOSES)이 파일 머리에 없다')
    if 'COPYRIGHTED' in flat:
        why.append('**COPYRIGHTED 표시가 있다 — 퍼블릭 도메인이 아니다**')
    return (not why), why


# ── 목차 ───────────────────────────────────────────────────────────────────
def _toc(text, n):
    """{장번호: (제목, 쪽번호를 숫자로 읽었나)} — 목차 줄에서.

    ⚠⚠ **쪽 번호를 떼는 것이 이 함수의 어려운 자리다.** OCR 이 숫자를 글자로
      읽는다 — `11 → n` · `101 → lo` · `108 → loS` · `161 → i6i`. 그렇다고
      「짧은 꼬리는 다 뗀다」로 하면 **「Marah and Elim」의 Elim 이 잘린다.**
      ⇒ 뗀 뒤에 **숫자로 읽혔는지**를 함께 돌려주고, 두 스캔 가운데 **숫자로
        읽힌 쪽의 제목**을 쓴다(실측 Revell 이 `Rephidim lo`, Morgan 이
        `REPHIDIM 101` — 그래서 Morgan 쪽이 이긴다).
    """
    out = {}
    head = text[:12000]
    for m in re.finditer(r'(?m)^\s*([IVXL]{1,7})\.\s+(.+?)\s*$', head):
        r = m.group(1)
        if r not in ROMAN[:n] or ROMAN.index(r) + 1 in out:
            continue
        t = re.sub(r'\s+', ' ', m.group(2)).strip()
        t = re.sub(r'\s*\.\.\.+\s*', ' ', t).strip()
        mm = re.search(r'[\s.]+(\d{1,3})$', t)
        clean = bool(mm)
        if mm:
            t = t[:mm.start()].strip()
        else:
            # 숫자로 안 읽힌 꼬리 — **낱말이 둘 이상일 때만** 뗀다
            parts = t.split()
            if len(parts) >= 2 and re.fullmatch(r"[ilosgnIS0-9]{1,4}", parts[-1]):
                t = ' '.join(parts[:-1]).strip()
        t = t.strip(' .,')
        if len(t) >= 4:
            out[ROMAN.index(r) + 1] = (t, clean)
    return out


def _title_case(t):
    small = {'of', 'the', 'and', 'in', 'to', 'for', 'a', 'an', 'its', 'by',
             'with', 'under', 'at', 'from', 'it', 'him', 'our'}
    ws = t.split()
    out = []
    for i, w in enumerate(ws):
        lw = w.lower()
        out.append(lw if (i and lw.strip('"\'') in small) else
                   (lw[:1].upper() + lw[1:]))
    return ' '.join(out)


def toc_of(code):
    b = BOOKS[code]
    n = b['chapters']
    merged = {}
    for role in ('primary', 'cross'):
        _nm, idf, _m = b[role]
        p = raw_path(idf)
        if not os.path.exists(p):
            continue
        t = _toc(io.open(p, encoding='utf-8', errors='replace').read(), n)
        for k, (v, clean) in t.items():
            old = merged.get(k)
            # **쪽 번호를 숫자로 읽은 쪽**이 이긴다 — 제목이 안 잘린다
            if old is None or (clean and not old[1]):
                merged[k] = (v, clean)
    # ⚠ `isupper()` 로만 보면 「His MOTHER'S FAITH」처럼 **섞인 줄**을 놓친다
    #   (실측 2장이 그랬다). 대문자 비율로 판정한다.
    def _mostly_upper(t):
        a = [ch for ch in t if ch.isalpha()]
        return bool(a) and sum(ch.isupper() for ch in a) / len(a) >= 0.6
    return {k: (_title_case(v) if _mostly_upper(v) else v)
            for k, (v, _c) in merged.items()}


# ── 장 자르기 ──────────────────────────────────────────────────────────────
def _body(text, marker):
    i = text.find(marker)
    return text[i + len(marker):] if i >= 0 else text


def _anchors(body, n):
    """{장번호: 오프셋} — **차례를 거스르는 것은 안 받는다**(목차·색인 오탐)."""
    out, last = {}, 0
    for m in re.finditer(r'(?m)^\s*([IVXL]{1,7})\.?\s*$', body):
        g = m.group(1)
        if g not in ROMAN[:n]:
            continue
        i = ROMAN.index(g) + 1
        if i in out or i <= last:
            continue
        out[i], last = m.start(), i
    return out


def _chain(body, off, n=7):
    """그 장 첫머리의 **낱말 사슬** — 다른 스캔에서 같은 자리를 찾는 열쇠.

    ⚠⚠ 정규화한 글자를 **원문에서 그대로 찾으면 안 된다** — `V.norm` 은
      구두점과 대소문자를 걷으므로 원문과 안 맞는다(첫 판이 그래서 6장을
      못 메웠다). 스캔끼리는 **글자가 조금씩 다르고 공백이 제멋대로**이므로
      **낱말만 뽑아 사이를 헐겁게** 잇는다.
    """
    seg = body[off:off + 1200]
    seg = re.sub(r'(?m)^\s*[IVXL]{1,7}\.?\s*$', ' ', seg)
    # ⚠ **짧은 낱말을 빼면 안 된다** — 사이를 「글자 아닌 것」으로 이으므로
    #   `to`·`of` 를 건너뛰면 사슬이 그 자리에서 끊긴다(실측 6장을 못 찾았다).
    return re.findall(r"[A-Za-z][A-Za-z']*", seg)[:n]


def _find_chain(hay, words):
    """낱말 사슬이 있는 자리 → 그 **문단 머리** 오프셋. 없으면 -1."""
    if len(words) < 4:
        return -1
    rx = re.compile(r'[^A-Za-z]{1,12}'.join(re.escape(w) for w in words), re.I)
    m = rx.search(hay)
    if not m:
        return -1
    j = hay.rfind('\n\n', 0, m.start())
    return (j + 2) if j >= 0 else m.start()


def split_chapters(code):
    """[(장번호, 제목, 본문)] — **두 스캔의 표지를 합쳐서** 자른다."""
    b = BOOKS[code]
    n = b['chapters']
    _n1, pid, pm = b['primary']
    _n2, cid, cm = b['cross']
    pt = io.open(raw_path(pid), encoding='utf-8', errors='replace').read()
    ct = io.open(raw_path(cid), encoding='utf-8', errors='replace').read()
    pb, cb = _body(pt, pm), _body(ct, cm)
    pa, ca = _anchors(pb, n), _anchors(cb, n)

    pos = dict(pa)
    pos[1] = 0                                   # 1장은 표지가 없다(본문 첫머리)
    filled = []
    for i in range(2, n + 1):
        if i in pos or i not in ca:
            continue
        lo = max(pos[k] for k in pos if k < i)
        hi = min([pos[k] for k in pos if k > i] or [len(pb)])
        j = _find_chain(pb[lo:hi], _chain(cb, ca[i]))
        if j >= 0:
            pos[i] = lo + j
            filled.append(i)

    toc = toc_of(code)
    vocab = witness_vocab(code)
    order = sorted(pos)
    out, joined = [], 0
    for k, i in enumerate(order):
        end = pos[order[k + 1]] if k + 1 < len(order) else len(pb)
        body, j = join_hyphens(_clean(pb[pos[i]:end], vocab), vocab)
        joined += j
        out.append((i, toc.get(i, '(제목 없음)'), body))
    split_chapters.joined = joined
    return out, filled, sorted(set(range(1, n + 1)) - set(pos))


# ── 전사 흔적 — 쪽 머리말 ────────────────────────────────────────────────────
#: 스캔은 **쪽마다 머리말**(장 제목 + 쪽 번호)을 찍어 두고, OCR 이 그 고딕체를
#: 통째로 뭉갠다(`12 '^is ^othtx's JTattlr.` = "His Mother's Faith" 12쪽).
#: 그대로 두면 **문단 한가운데 알아볼 수 없는 줄**이 끼어든다(실측 151줄).
#: ⚠⚠ **기호만으로 가르면 본문을 지운다** — 실측 `the loom> for which the
#:   Egyptians became so famous, of` 처럼 **본문 줄에도 OCR 기호가 튄다.**
#: ⇒ 세 가지를 **함께** 본다: 짧은 줄 · 뭉개진 기호 · 그리고
#:   **쪽 번호가 붙었거나 영어 기능어가 거의 없다**(머리말은 제목이라 that·of·
#:   which 같은 말이 안 나온다. 본문 줄에는 반드시 나온다).
JUNK = re.compile(r'[\^®€¥§±~|\\{}\[\]<>@#$%&_+=]')
FUNC = frozenset((
    'the of and to in a that he was for it with as his is be not but they '
    'which from by this had have on at we you all are were their them so '
    'who would there been when will if my no him her she our us said shall '
    'up out into what more may then than upon these its one or'
).split())


HDR_RATE = 0.75


def is_header(line, vocab=None):
    """이 줄이 **쪽 머리말**인가 — 저자의 글이 아니다.

    ★★★ 가르는 잣대는 **증인 낱말 비율**이다(2026-09-18 실측). 머리말은
      고딕체라 OCR 이 통째로 뭉개므로 **다른 스캔에도 없는 낱말**뿐이고,
      본문 줄은 기호가 한둘 튀어도 낱말은 멀쩡하다:
        본문 `the loom> for which the Egyptians…`          **1.00**
        본문 `lime avenues were ^e befitting approach.`    **1.00**
        머리 `"®;ire Hcproaclj of Christ." 23`             0.50
        머리 `lo ®ur ^tantrpoittt.`                        0.67
      ⇒ 문턱 **0.75**. 사이가 넓어 흔들리지 않는다.
    ⚠⚠ **기호만으로 가르면 본문을 지운다** — 첫 판이 `lime avenues were ^e
      befitting approach.` 를 걷었다(기능어가 `were` 하나뿐이라서).
    ⚠ 증인이 없는 책에서는 **쪽 번호 + 기능어**로 물러선다 — 덜 정확하므로
      그런 책에 쓸 때는 걷은 목록을 눈으로 본다.
    """
    t = line.strip()
    if not t or len(t) >= 70:
        return False
    w = [x for x in re.findall(r"[A-Za-z][A-Za-z']*", t) if len(x) > 1]
    if vocab:
        # ⚠⚠ **기호가 있는 줄로 좁히면 절반을 놓친다** — 실측 `14 His Mothtfs
        #   JFaitlr.` 처럼 **기호 없이 깨진 머리말**이 120줄 남았다(2026-09-18).
        if not w:
            return len(t) <= 4               # 홑 글자 부스러기(`B` · `^^`)
        # ★★★ **기능어가 둘이면 본문이다 — 이것이 마지막 자물쇠.**
        #   ⚠⚠ 증인 비율만으로는 못 가른다: 두 스캔이 **같은 자리를 함께
        #     뭉갠** 본문 줄이 0.67 까지 떨어져 머리말과 겹쳤다(실측
        #     `men's consciences demand it. There is no stronger argument` ·
        #     `their arms, rattling their chains, straining their cords, and`).
        #   ★ 머리말은 **제목**이라 that·of·their 같은 말이 0~1개뿐이고,
        #     본문 줄에는 반드시 여럿 있다. 그 차이가 겹치지 않는다.
        if sum(1 for x in w if x.lower() in FUNC) >= 2:
            return False
        # ⚠⚠ 증인 스캔도 **같은 머리말을 비슷하게 뭉갠다** — 실측
        #   `®lje first Attempt. 25` 가 비율 1.00 이 나왔다(`lje` 가 저쪽에도
        #   있다). ⇒ **쪽 번호 + 뭉갠 기호 + 기능어 0** 이면 머리말로 본다.
        #   ⚠ 셋을 다 요구한다 — `Acts vii. 24, 25.`(제사 참조)는 기호가
        #     없어 살고, 기호가 튄 본문 줄은 쪽 번호가 없어 산다.
        _page = bool(re.match(r'^[0-9]{1,3}(?![0-9])', t)
                     or re.search(r'(?<![0-9])[0-9]{1,3}\.?"?$', t))
        _nofn = not any(x.lower() in FUNC for x in w)
        if _page and JUNK.search(t) and _nofn:
            return True
        # ⚠ 쪽 번호가 붙고 기능어가 없는 짧은 줄에서 **낱말이 하나라도
        #   뭉개졌으면** 머리말이다 — 실측 `" ar am tbat I am." 35` 가 비율
        #   0.75 로 문턱에 정확히 걸려 살아남았다(`tbat` = that).
        #   ⚠ **온전한 줄은 살린다** — `Acts vii. 24, 25.`(제사 참조)는
        #     비율 1.00 이라 그대로 남는다.
        if (_page and _nofn
                and sum(1 for x in w if x.lower() in vocab) < len(w)):
            return True
        rate = sum(1 for x in w if x.lower() in vocab) / len(w)
        # ⚠ 낱말이 둘 이하면 비율이 거칠다(0·0.5·1 뿐) — **아예 없을 때만**
        #   걷는다. 그래야 `unkindly lot.` 같은 짧은 본문 줄이 산다.
        return rate < HDR_RATE if len(w) >= 3 else rate == 0.0
    if not JUNK.search(t):
        return False
    page = bool(re.match(r'^\d{1,3}\b', t) or re.search(r'\b\d{1,3}\.?"?$', t))
    return page or sum(1 for x in w if x.lower() in FUNC) == 0


def strip_headers(text, vocab=None):
    """쪽 머리말 줄을 걷는다 — **걷은 수를 함께 돌려준다**(조용히 안 지운다)."""
    keep, n = [], 0
    for ln in (text or '').split('\n'):
        if is_header(ln, vocab):
            n += 1
            continue
        keep.append(ln)
    return '\n'.join(keep), n


def heal_pagebreaks(text):
    """쪽이 바뀐 자리의 **가짜 문단 경계**를 잇는다.

    ★★★ 스캔은 쪽마다 `본문 ↵↵ 머리말 ↵↵ 본문` 으로 찍혀 있다. 머리말을
      걷으면 **빈 줄 둘이 남아** 한 문단이 두 문단으로 갈린다(실측 1장
      `…which lifted` ‖ `them above ordinary men…`).
    ★ 판정은 **문장이 끝났는가**다 — 앞 덩이가 마침표·물음표·따옴표로 끝나지
      않고 뒤 덩이가 **소문자로 시작**하면 한 문장이 잘린 것이다.
    ⚠ 그 둘이 다 맞을 때만 잇는다 — 진짜 문단 경계에도 머리말은 찍힌다.
    """
    parts = re.split(r'\n[ \t]*\n+', text or '')
    out = []
    for p in parts:
        if out:
            prev = out[-1].rstrip()
            nxt = p.lstrip()
            # ⚠⚠ 뒤 덩이가 **OCR 부스러기로 시작**하면 소문자 판정이
            #   실패한다 — 실측 4장 `…Nothing short of a` ‖ `' reception of
            #   the Divine patience…` 가 한 문장인데 갈려 있었다.
            #   ⇒ 앞쪽 기호를 건너뛰고 **첫 글자**를 본다.
            head = re.sub(r'^[^A-Za-z0-9]+', '', nxt)
            if (prev and head
                    and not re.search(r'[.!?\u2014"\u201d\'\u2019]$', prev)
                    and re.match(r'[a-z]', head)):
                out[-1] = prev + '\n' + p
                continue
        out.append(p)
    return '\n\n'.join(out)


def witness_vocab(code):
    """대조 스캔의 **낱말집** — 고쳐도 되는지 물어볼 증인이다."""
    _n, cid, _m = BOOKS[code]['cross']
    p = raw_path(cid)
    if not os.path.exists(p):
        return set()
    t = io.open(p, encoding='utf-8', errors='replace').read()
    return {w.lower() for w in re.findall(r"[A-Za-z][A-Za-z']*", t)}


def join_hyphens(text, vocab):
    """줄 끝에서 끊긴 낱말을 잇는다 — **이은 낱말이 다른 스캔에 있을 때만.**

    ★★★ 이것은 **지어내는 것이 아니라 증인에게 묻는 것**이다(§0-1b 로렌스
      선례 — 「판정은 두 스캔을 합쳐서 한다」). 같은 판을 두 번 스캔했으므로
      글자가 깨지는 자리가 서로 다르다. 한쪽이 `constella- tion` 이어도
      다른 쪽에 `constellation` 이 있으면 그것이 저자의 낱말이다.
    ⚠ **증인이 없으면 안 고친다** — 실측 311곳 중 197곳만 고쳐진다.
      나머지 114곳은 그대로 둔다(둘 다 깨진 자리다).
    ⚠ 이래서 원문 대조를 **합본**으로 잰다 — 한쪽만 보면 이은 낱말이
      「원문에 없는 문장」으로 잡힌다.
    """
    if not vocab:
        return text, 0
    n = [0]

    def rep(m):
        w = m.group(1) + m.group(2)
        if w.lower() in vocab:
            n[0] += 1
            return w
        return m.group(0)
    return re.sub(r"([A-Za-z][A-Za-z']*)-\s+([a-z][A-Za-z']*)", rep, text), n[0]


def _clean(seg, vocab=None):
    """장 토막 다듬기 — 표지 줄·깨진 장식체 제목·쪽 번호를 걷는다."""
    s = seg
    s = re.sub(r'^\s*[IVXL]{1,7}\.?\s*', '', s)
    lines = s.split('\n')
    # 첫 비어 있지 않은 줄이 **성구 제사가 아니고 알파벳 비율이 낮으면**
    # 그것이 깨진 장식체 제목이다 — 걷는다.
    for i, ln in enumerate(lines[:6]):
        t = ln.strip()
        if not t:
            continue
        if t.startswith('"') or t.startswith('“'):
            break
        letters = sum(ch.isalpha() for ch in t)
        odd = sum(1 for ch in t if not (ch.isalnum() or ch.isspace()
                                        or ch in '.,;:\'"-!?()'))
        if letters and (odd / max(1, len(t)) > 0.06 or len(t) < 48):
            lines[i] = ''
        break
    s = '\n'.join(lines)
    s = re.sub(r'(?m)^\s*\d{1,3}\s*$', '', s)          # 홑 쪽 번호
    s, _hdr = strip_headers(s, vocab)                 # 깨진 쪽 머리말
    s = heal_pagebreaks(s)                            # 갈라진 문단 잇기
    _clean.headers = getattr(_clean, 'headers', 0) + _hdr
    # ★ IA 스캔은 **낱말 사이가 두 칸**이다(실측 66,282곳) — 화면에서 그대로
    #   벌어져 보인다. **공백만 손대므로** 원문 대조(§0-1b 규칙 ②)가 그대로
    #   100% 로 남는다(`db_book_verify.norm` 이 공백을 접는다).
    s = re.sub(r'[ \t]{2,}', ' ', s)
    # ⚠⚠ **줄 끝 붙임표는 안 잇는다**(실측 309곳 · `constella- tion`).
    #   이으면 글자가 바뀌어 **원문 대조가 그 문장에서 깨진다** — 출처를
    #   기계로 증명할 수 있는 것이 읽기 편한 것보다 값지다(§0-1b).
    #   읽는 쪽은 나중에 우리가 쓰는 `MODERN_EN` 이 바로잡는다.
    s = re.sub(r'\n{3,}', '\n\n', s)
    return s.strip()


# ── 성구 제사 ──────────────────────────────────────────────────────────────
# ⚠ OCR 이 약어도 흘린다 — `Num` 이 `Nom`, `Exod` 가 `ExoD`·`Exon`.
#   **재서 확인한 것만** 넣는다(짐작으로 늘리면 엉뚱한 책에 걸린다).
_ABBR_FIX = {'NUMB': 'Num', 'NUM': 'Num', 'NOM': 'Num', 'NUMBERS': 'Num',
             'EXOD': 'Exod', 'EXODUS': 'Exod', 'EXON': 'Exod',
             'DEUT': 'Deut', 'DEUTERONOMY': 'Deut',
             'HEB': 'Heb', 'HEBREWS': 'Heb', 'PSA': 'Ps', 'PSALM': 'Ps',
             'MATT': 'Matt', 'JOSH': 'Josh', 'LEVIT': 'Lev', 'LEV': 'Lev',
             'ACTS': 'Acts', 'ISA': 'Isa', 'JOHN': 'John', 'LUKE': 'Luke'}


def epigraph(body):
    """(제사 글, 성구 표기, (bcode, ch, vs)) — 못 읽으면 좌표는 None."""
    # ⚠ **대시를 요구하면 안 된다** — 이 책은 제사 끝에 대시를 붙이기도 하고
    #   (`— Heb. xi. 23.`) 안 붙이기도 한다(`EXOD. XV. 21.` · `Deut. xxxiv. 5, 6.`).
    #   실측 28장 중 대시 없는 것이 12장이었다. ⇒ **모양이 맞는 첫 것**을 쓰되
    #   **책 이름이 실제로 풀리는 것**만 받는다(잡음을 안 받는다).
    for m in re.finditer(r'([1-3]?\s*[A-Za-z]{2,12})\.?\s+'
                         r'([ivxlcdm]{1,7})\.\s*(\d{1,3})', body[:1800], re.I):
        abbr = re.sub(r'\s+', ' ', m.group(1)).strip()
        key = abbr.upper().replace(' ', '')
        abbr = _ABBR_FIX.get(key, abbr[:1].upper() + abbr[1:].lower())
        ref = '%s %s:%s' % (abbr, m.group(2).lower(), m.group(3))
        hits = RP.parse_refs(ref)
        if hits:
            return (re.sub(r'\s+', ' ', body[:m.end()]).strip(), ref,
                    (hits[0][0], hits[0][1], hits[0][2]))
    return '', '', None


def _vid(conn, bcode, ch, vs):
    r = conn.execute('SELECT verse_id FROM bible_index '
                     'WHERE bcode=? AND chapter=? AND verse=?',
                     (bcode, ch, vs)).fetchone()
    return r[0] if r else None


def app_ref(conn, co):
    """(bcode, ch, vs) → `Hebrews 11:23` — **앱이 약명으로 옮길 수 있는 꼴.**

    ⚠⚠ 이 책의 제사는 `Heb. xi. 23` 꼴이라 그대로 담으면 화면이 **로마숫자
      그대로** 보인다(`p1_reading_view._localize_ref` 가 아라비아 숫자만 읽는다).
      실측 — 그렇게 담았더니 25줄 가운데 **약명이 된 것 0개**였다.
      ⇒ **영어 정식 이름 + 아라비아 숫자**로 담는다. 그러면 11언어가 저절로
        따라온다(히11:23 · Heb 11:23 · 来11:23 …).
    """
    if not co:
        return None
    # ⚠ 칸 이름이 `bcode` 가 아니라 **`book_code`** 다(실측으로 당했다).
    r = conn.execute("SELECT full_name FROM book_names"
                     " WHERE book_code=? AND UPPER(lang_code)='EN'",
                     (co[0],)).fetchone()
    return '%s %d:%d' % (r[0], co[1], co[2]) if r and r[0] else None


# ── 두 곳 대조 (규칙 ②) ────────────────────────────────────────────────────
def cross_check(code, sample=400, log=print):
    b = BOOKS[code]
    _n1, pid, _m1 = b['primary']
    _n2, cid, _m2 = b['cross']
    A = io.open(raw_path(pid), encoding='utf-8', errors='replace').read()
    B = io.open(raw_path(cid), encoding='utf-8', errors='replace').read()
    na, nb = V.norm(A), V.norm(B)

    def pct(src, dst, tag):
        ss = V.sentences(src)
        mid = ss[len(ss) // 5: len(ss) // 5 + sample]
        hit = sum(1 for s in mid if V.found_in(s, dst))
        r = hit / max(1, len(mid))
        log('   %-30s 문장 %4d 중 %4d = %5.1f%%' % (tag, len(mid), hit, 100 * r))
        return r
    a = pct(A, nb, '%s → %s' % (pid[:14], cid[:14]))
    c = pct(B, na, '%s → %s' % (cid[:14], pid[:14]))
    return min(a, c)


def _union_pct(code, chs=None):
    """적재할 글이 **두 스캔을 합친 것** 안에 있는가 (§0-1b 로렌스 선례).

    ⚠ 한쪽만 보면 안 된다 — 붙임표를 이은 자리는 **증인 쪽에만** 온전한
      낱말이 있다. 합쳐서 재야 「우리가 지어낸 글자가 없다」를 증명한다.
    """
    b = BOOKS[code]
    if chs is None:
        chs, _f, _m = split_chapters(code)
    uni = ' '.join(
        V.norm(io.open(raw_path(b[r][1]), encoding='utf-8',
                       errors='replace').read())
        for r in ('primary', 'cross'))
    n = hit = 0
    for _i, _t, body in chs:
        for sent in V.sentences(body):
            n += 1
            hit += 1 if V.found_in(sent, uni) else 0
    return '문장 %d 중 %d = **%.1f%%**' % (n, hit, 100.0 * hit / max(1, n))


# ── 현대영어(MODERN_EN) ──────────────────────────────────────────────────────
#: booktrans.md §6 — **번역은 창작이 아니다.** 저자가 한 말을 그대로 옮기고
#: 언어만 오늘 말로 바꾼다. 그래서 게이트가 재는 것은 「잘 썼나」가 아니라
#: **「저자의 글과 같은 모양인가」**다(§10).
ARCHAIC = (
    'thee thou thy thine ye hath doth dost shalt hast havest didst unto yea '
    'fain nay saith cometh beareth goeth doeth brethren whilst hither '
    'thither wherefore betwixt ere thyself thence whence oft methinks '
    'believeth knoweth spake bade behold'
).split()
LEN_LO, LEN_HI = 0.85, 1.15
MODERN_ATTRIB = ('\u2014 Modern English adaptation \u00b7 F. B. Meyer, "%s" (%s).'
                 ' Public domain.')


#: ⚠⚠ 물음표는 **글 안의 것만** 센다 — OCR 이 뭉갠 자리에 `?` 가 섞인다
#:   (실측 5장 `Jochebed— _/?/;<?7/«/z my glory` 에 둘). 그것까지 세면
#:   번역이 맞출 수 없는 수가 되어 게이트가 헛돈다.
#:   ⇒ **앞이 글자·공백·따옴표·쉼표·마침표**인 물음표만 문장의 물음표다.
QMARK = re.compile(r'(?<=[A-Za-z0-9,;:.\'"\)\s])\?')


def _shape(text):
    """문단 수 \u00b7 물음표 수 \u2014 \u00a73 위반(재배치\u00b7쪼개기)을 잡는 잣대."""
    body = [ln for ln in (text or '').split('\n') if ln.strip()
            and not ln.strip().startswith('\u2014 ')]
    return len(body), sum(len(QMARK.findall(ln)) for ln in body)


def modern_check(code, draft, log=print):
    """적재 전 게이트 \u2014 **하나라도 걸리면 안 싣는다**(booktrans.md \u00a710).

    \u26a0 게이트는 **바닥이지 천장이 아니다** \u2014 셋 다 통과해도 논지가 뒤집혔는지는
      사람이 본다(머레이 11편이 길이비 1.00 으로 통과한 채 원문에 없는 표제
      구절을 달고 있었다).
    """
    b = BOOKS[code]
    conn = appdb.connect()
    rows = {r[0]: r[1] for r in conn.execute(
        "SELECT u.sequence, t.body_text FROM sys_book_unit u"
        "  JOIN sys_book_asset a ON a.book_id=u.book_id"
        "  JOIN sys_book_unit_text t ON t.unit_id=u.unit_id"
        " WHERE a.book_code=? AND t.text_variant='ORIGINAL'"
        "   AND t.record_status='LIVE'", (code,))}
    ok = True
    for u in draft['units']:
        seq, new = int(u['seq']), u['body']
        src = rows.get(seq)
        if not src:
            log('  %2d장 \u2717 원문이 없다' % seq)
            ok = False
            continue
        # 출처 줄은 길이\u00b7모양 셈에서 뺀다(우리가 붙이는 것이다)
        def _strip(t):
            return '\n'.join(ln for ln in t.split('\n')
                             if not ln.strip().startswith('\u2014 '))
        a, z = _strip(src), _strip(new)
        ratio = len(z) / max(1, len(a))
        p_a, q_a = _shape(src)
        p_z, q_z = _shape(new)
        arch = sorted({w for w in re.findall(r"[A-Za-z']+", z)
                       if w.lower() in ARCHAIC})
        bad = []
        if not (LEN_LO <= ratio <= LEN_HI):
            bad.append('길이비 %.2f' % ratio)
        if arch:
            bad.append('옛말 %s' % ', '.join(arch[:6]))
        # ⚠ 영어 글에 한글·한자가 섞이면 내 오타다(실측 2장 `He決`).
        cjk = sorted({ch for ch in z if '　' <= ch <= '鿿'
                      or '가' <= ch <= '힯'})
        if cjk:
            bad.append('영어 아닌 글자 %s' % ''.join(cjk[:6]))
        if p_a != p_z:
            bad.append('문단 %d\u2192%d' % (p_a, p_z))
        if q_a != q_z:
            bad.append('물음표 %d\u2192%d' % (q_a, q_z))
        log('  %2d장  길이비 %.2f  문단 %d  물음표 %d  %s'
            % (seq, ratio, p_z, q_z, ('\u2717 ' + ' \u00b7 '.join(bad)) if bad else 'OK'))
        ok = ok and not bad
    log('\n%s' % ('PASS \u2014 적재할 수 있다' if ok else '\u2717 게이트에 걸렸다 \u2014 안 싣는다'))
    return ok


def modern_apply(code, draft, log=print):
    """멱등 적재 \u2014 같은 유닛의 MODERN_EN 을 지우고 다시 넣는다."""
    b = BOOKS[code]
    conn = appdb.connect()
    cur = conn.cursor()
    bid = cur.execute('SELECT book_id FROM sys_book_asset WHERE book_code=?',
                      (code,)).fetchone()[0]
    n = 0
    for u in draft['units']:
        seq = int(u['seq'])
        r = cur.execute('SELECT unit_id FROM sys_book_unit'
                        ' WHERE book_id=? AND sequence=?', (bid, seq)).fetchone()
        if not r:
            raise SystemExit('%d장 유닛이 없다' % seq)
        uid = r[0]
        body = u['body'].rstrip()
        tail = MODERN_ATTRIB % (b['title'], b['imprint'])
        if not body.endswith('Public domain.'):
            body += '\n' + tail
        cur.execute("DELETE FROM sys_book_unit_text"
                    " WHERE unit_id=? AND text_variant='MODERN_EN'", (uid,))
        cur.execute("INSERT INTO sys_book_unit_text(unit_id,lang_code,"
                    "text_variant,body_text,record_status)"
                    " VALUES(?,'EN','MODERN_EN',?,'LIVE')", (uid, body))
        n += 1
    conn.commit()
    log('\u21d2 %s  MODERN_EN %d편 적재' % (code, n))
    return n


# ── 점검 ───────────────────────────────────────────────────────────────────
def check(code=DEFAULT, log=print):
    b = BOOKS[code]
    ok = True
    log('=== %s — %s (%s) ===' % (code, b['title'], b['imprint']))
    for role in ('primary', 'cross'):
        nm, idf, _m = b[role]
        p = raw_path(idf)
        if not os.path.exists(p):
            log('  ✗ 안 받았다 — %s  (--fetch 먼저)' % idf)
            return False
        t = io.open(p, encoding='utf-8', errors='replace').read()
        good, why = _meta_ok(t, code)
        log('  %s %-28s %8d자  %s'
            % ('OK ' if good else '✗  ', idf, len(t),
               '제목·저자 확인 · 저작권 표시 없음' if good else ' / '.join(why)))
        ok = ok and good
    log('\n  두 곳 대조(§0-1b 규칙 ②):')
    r = cross_check(code, log=log)
    log('   ⇒ 양방향 최저 %.1f%% — 문지기 %d%% %s'
        % (100 * r, GATE * 100, 'PASS' if r >= GATE else '**FAIL**'))
    ok = ok and r >= GATE

    chs, filled, missing = split_chapters(code)
    log('\n  장 나누기 — %d/%d장%s%s'
        % (len(chs), b['chapters'],
           ('  (다른 스캔으로 메운 것: %s)' % filled) if filled else '',
           ('  **못 찾은 장: %s**' % missing) if missing else ''))
    log('  줄 끝 붙임표 — **다른 스캔이 증인인 %d곳만** 이었다'
        % getattr(split_chapters, 'joined', 0))
    log('  깨진 쪽 머리말 — **%d줄 걷었다**(저자의 글이 아니다)'
        % getattr(_clean, 'headers', 0))
    log('  적재본 ↔ 합본(두 스캔) 대조: %s' % _union_pct(code, chs))
    conn = appdb.connect()
    walls = 0
    for i, t, body in chs:
        epi, ref, co = epigraph(body)
        vid = _vid(conn, *co) if co else None
        if len(body) > 20000:
            walls += 1
        log('   %2d. %-42.42s %6d자  %-12s %s'
            % (i, t, len(body), ref or '—', ('vid %s' % vid) if vid else ''))
    conn.close()
    if missing:
        ok = False
    log('\n  %s' % ('PASS — 적재할 수 있다' if ok else 'FAIL — 위 자리를 먼저 본다'))
    if walls:
        log('  ⚠ 2만 자가 넘는 장 %d개 — `db_book_split` 이 묵상 한 자리로 나눈다' % walls)
    return ok


# ── 적재 ───────────────────────────────────────────────────────────────────
DESC = """F. B. 메이어가 모세 한 사람의 일생을 스물여덟 걸음으로 따라갑니다. 갈대 상자에서 느보 산까지, 사건을 늘어놓는 것이 아니라 그 사람의 믿음이 어떻게 자랐는지를 봅니다.
메이어는 첫 장에서 자기 뜻을 밝힙니다. 미켈란젤로가 깎은 거대한 모세 상 앞에서는 따라갈 엄두가 나지 않지만, 히브리서는 그가 우리와 같은 사람이었고 그 성품이 여러 해에 걸쳐 빚어졌다고 말한다는 것입니다.
장마다 성구 하나를 앞에 두고 그 장면 하나를 묵상합니다. 어머니의 믿음, 애굽에서의 실패, 떨기나무, 홍해, 마라와 엘림, 시내 산, 성막, 므리바의 쓴 실망, 그리고 비스가에서의 마지막까지.
▸ 출처
  · Internet Archive — %s 옛 판 스캔 두 벌
  · 퍼블릭 도메인(저작권 만료 · 저자 1847~1929)
  · 본문은 옛 인쇄본을 기계로 읽은 것이라 장 첫 낱말의 장식 머리글자가 빠져 있고 더러 글자가 깨져 있습니다. 지어내지 않고 그대로 두었습니다."""


def apply(code=DEFAULT, log=print):
    if not check(code, log=lambda *_a, **_k: None):
        raise SystemExit('[%s] --check 가 통과하지 않았다 — 적재하지 않는다' % code)
    b = BOOKS[code]
    chs, _f, _m = split_chapters(code)
    conn = appdb.connect()
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    row = cur.execute('SELECT book_id FROM sys_book_asset WHERE book_code=?',
                      (code,)).fetchone()
    body_chars = sum(len(x[2]) for x in chs)
    if row:
        bid = row[0]
        cur.execute("UPDATE sys_book_asset SET title=?,author=?,pub_year=?,"
                    "description=?,source_url=?,body_chars=?,record_status='LIVE'"
                    " WHERE book_id=?",
                    (b['title'], b['author'], b['year'], DESC % b['imprint'],
                     IAD % b['primary'][1], body_chars, bid))
    else:
        cur.execute("INSERT INTO sys_book_asset(book_code,title,author,lang_code,"
                    "copyright_type,source_url,pub_year,description,record_status,"
                    "book_category,body_chars) VALUES(?,?,?,'EN','PUBLIC_DOMAIN',"
                    "?,?,?,'LIVE',?,?)",
                    (code, b['title'], b['author'], IAD % b['primary'][1],
                     b['year'], DESC % b['imprint'], b['category'], body_chars))
        bid = cur.lastrowid
    # 유닛 — 멱등(같은 차례면 덮어쓴다)
    n_new = n_up = n_vid = 0
    for i, title, body in chs:
        epi, ref, co = epigraph(body)
        vid = _vid(conn, *co) if co else None
        ref = app_ref(conn, co) or None      # 화면이 약명으로 옮길 수 있는 꼴
        if vid:
            n_vid += 1
        text = body + (ATTRIB % (b['title'], b['imprint']))
        u = cur.execute('SELECT unit_id FROM sys_book_unit '
                        'WHERE book_id=? AND sequence=?', (bid, i)).fetchone()
        if u:
            uid = u[0]
            cur.execute("UPDATE sys_book_unit SET unit_label=?,key_verse_ref=?,"
                        "start_vid=?,session_type='CHAPTER',record_status='LIVE'"
                        " WHERE unit_id=?", (title, ref or None, vid, uid))
            n_up += 1
        else:
            cur.execute("INSERT INTO sys_book_unit(book_id,sequence,session_type,"
                        "unit_label,key_verse_ref,start_vid,record_status)"
                        " VALUES(?,?,'CHAPTER',?,?,?,'LIVE')",
                        (bid, i, title, ref or None, vid))
            uid = cur.lastrowid
            n_new += 1
        t = cur.execute("SELECT text_id FROM sys_book_unit_text WHERE unit_id=?"
                        " AND text_variant='ORIGINAL' AND lang_code='EN'",
                        (uid,)).fetchone()
        if t:
            cur.execute("UPDATE sys_book_unit_text SET body_text=?,"
                        "record_status='LIVE' WHERE text_id=?", (text, t[0]))
        else:
            cur.execute("INSERT INTO sys_book_unit_text(unit_id,text_variant,"
                        "lang_code,body_text,record_status)"
                        " VALUES(?,'ORIGINAL','EN',?,'LIVE')", (uid, text))
    # 출처를 DB 에 남긴다(§0-1b)
    SM.init_source_table(conn)
    SM.record_source(conn, code, 'PRIMARY', b['primary'][0],
                     IAD % b['primary'][1], note='본문을 받은 곳')
    SM.record_source(conn, code, 'CROSS', b['cross'][0],
                     IAD % b['cross'][1], note='두 곳 대조에 쓴 곳')
    conn.commit()
    conn.close()
    log('⇒ %s  book_id=%s · 새 유닛 %d · 갱신 %d · 구절 좌표 %d/%d · 본문 %,d자'
        .replace(',d', 'd') % (code, bid, n_new, n_up, n_vid, len(chs), body_chars))
    return bid


def undo(code=DEFAULT, log=print):
    conn = appdb.connect()
    cur = conn.cursor()
    r = cur.execute('SELECT book_id FROM sys_book_asset WHERE book_code=?',
                    (code,)).fetchone()
    if not r:
        log('없다'); conn.close(); return
    bid = r[0]
    cur.execute("UPDATE sys_book_unit_text SET record_status='HIDE' WHERE unit_id IN"
                " (SELECT unit_id FROM sys_book_unit WHERE book_id=?)", (bid,))
    cur.execute("UPDATE sys_book_unit SET record_status='HIDE' WHERE book_id=?", (bid,))
    cur.execute("UPDATE sys_book_asset SET record_status='HIDE' WHERE book_id=?", (bid,))
    conn.commit(); conn.close()
    log('내렸다 — %s (지우지 않았다 · 다시 --apply 하면 살아난다)' % code)


# ── 자가검증 ───────────────────────────────────────────────────────────────
def selftest():
    n = [0, 0]

    def t(name, cond):
        n[1] += 1
        n[0] += 1 if cond else 0
        print('  %s %s' % ('OK  ' if cond else 'FAIL', name))

    t('① 이 파일에 본문 글자가 없다(규칙 ①)',
      len([l for l in io.open(__file__, encoding='utf-8').read().split('\n')
           if l.count('"') > 6 and len(l) > 300]) == 0)
    t('② 받기 전에 확인을 받는다(규칙 ⓪)',
      'require_ack' in io.open(__file__, encoding='utf-8').read())
    ok, why = _meta_ok('MOSES  the servant of God  by F. B. MEYER', 'MEYER_MOSES')
    t('③ 파일이 스스로 밝히는 제목·저자를 본다', ok)
    ok2, why2 = _meta_ok('MOSES by MEYER ** This is a COPYRIGHTED text **', 'MEYER_MOSES')
    t('④ COPYRIGHTED 가 있으면 거부한다(규칙 ④)',
      (not ok2) and any('COPYRIGHTED' in w for w in why2))
    t('⑤ 저자가 아니면 거부한다', not _meta_ok('MOSES by somebody else', 'MEYER_MOSES')[0])

    b = '\nII.\n\nSteltiwrattr* tig Jttaitt 3fom\n\n"By faith." — Heb. xi. 23.\n\nT was on a world.\n'
    epi, ref, co = epigraph(b)
    t('⑥ 성구 제사를 읽는다 — Heb xi.23', ref == 'Heb xi:23' and co == (58, 11, 23))
    t('⑦ 깨진 장식체 제목 줄을 걷는다', 'Steltiwrattr' not in _clean(b))
    t('⑩ 게이트 — 모양 재기는 출처 줄을 빼고 센다',
      _shape('a?\nb\n— F. B. Meyer, "x". Public domain.') == (2, 1))
    t('⑪ 쪽이 바뀐 자리의 가짜 문단 경계를 잇는다',
      heal_pagebreaks('which lifted\n\nthem above men')
      == 'which lifted\nthem above men')
    t('⑪-2 **진짜 문단 경계는 안 잇는다**(문장이 끝났다)',
      heal_pagebreaks('converged.\n\nPast that home')
      == 'converged.\n\nPast that home')
    t('⑪-3 뒤가 대문자면 안 잇는다(새 문장이다)',
      heal_pagebreaks('and\n\nThe next point')
      == 'and\n\nThe next point')
    t('⑩-2 옛말 목록에 KJV 어투가 들어 있다',
      'thou' in ARCHAIC and 'hath' in ARCHAIC and 'unto' in ARCHAIC)
    t('⑩-3 길이비 대역은 0.85~1.15(booktrans §3)',
      (LEN_LO, LEN_HI) == (0.85, 1.15))
    t('⑲ 쪽번호+기호+기능어0 이면 머리말(증인 비율이 높아도)',
      is_header('®lje first Attempt. 25', {'lje', 'first', 'attempt'}))
    t('⑲-3 쪽번호+뭉갠 낱말이면 머리말(문턱에 걸려도)',
      is_header('" ar am tbat I am." 35', {'am', 'that', 'ar'}))
    t('⑲-2 **제사 참조 줄은 안 걷는다**(기호가 없다)',
      not is_header('Acts vii. 24, 25.', {'acts', 'vii'}))
    t('⑧ 성구 제사는 남긴다(저자가 선택한 구절이다)', 'By faith' in _clean(b))
    t('⑨ 드롭캡을 채워 넣지 않는다(지어내지 않는다)',
      _clean(b).rstrip().endswith('T was on a world.'))

    a = _anchors('\nII.\n x \nIII.\n y \nII.\n z \n', 28)
    t('⑩ 차례를 거스르는 표지는 안 받는다(색인 오탐)', sorted(a) == [2, 3])
    t('⑪ 목차 쪽 번호를 뗀다',
      _toc('\nIV.  Deliverance  by  Main  Force  24 \n', 28).get(4)
      == ('Deliverance by Main Force', True))
    t('⑪-2 숫자로 안 읽힌 쪽 번호도 뗀다(11 → n)',
      _toc('\nII.  His  Mother  Faith  n \n', 28).get(2)
      == ('His Mother Faith', False))
    t('⑪-3 **진짜 낱말은 안 뗀다**(Marah and Elim 의 Elim)',
      _toc('\nXIII.  Marah  and  Elim \n', 28).get(13)
      == ('Marah and Elim', False))
    t('⑪-4 대시 없는 성구 제사도 읽는다(실측 28장 중 12장이 그렇다)',
      epigraph('"Sing ye to the Lord." EXOD. XV. 21.')[1] == 'Exod xv:21')
    t('⑪-5 책 이름이 안 풀리면 안 받는다(잡음)',
      epigraph('"a quote." Zzz. xv. 21.')[2] is None)
    t('⑪-6 낱말 사슬은 짧은 낱말도 담는다(빼면 사슬이 끊긴다)',
      _chain('And Moses returned to the land of Egypt', 0, 7)
      == ['And', 'Moses', 'returned', 'to', 'the', 'land', 'of'])
    t('⑪-7 낱말 사슬로 다른 스캔의 같은 자리를 찾는다',
      _find_chain('And  Moses   returned  to  the \nland  of  Egypt',
                  ['And', 'Moses', 'returned', 'to', 'the', 'land']) == 0)
    t('⑫ 목차 대문자는 Title Case 로', _title_case('THE DEATH OF MOSES')
      == 'The Death of Moses')
    t('⑬ 문지기가 80%%다(규칙 ②)', GATE == 0.80)
    t('⑬-2 두 칸 공백을 접는다(IA 스캔)',
      '  ' not in _clean('"q." — Heb. xi. 23.\n\nthe  quick  brown  fox'))
    t('⑬-4 붙임표는 **증인이 있을 때만** 잇는다',
      join_hyphens('constella- tion and so- called', {'constellation'})
      == ('constellation and so- called', 1))
    t('⑬-5 증인이 없으면 안 고친다(지어내지 않는다)',
      join_hyphens('constella- tion', set()) == ('constella- tion', 0))
    t('⑬-6 대조는 **합본**으로 잰다(한쪽만 보면 이은 낱말이 튄다)',
      '_union_pct' in io.open(__file__, encoding='utf-8').read())
    t('⑬-3 **공백만** 손댄다 — 낱말은 그대로(원문 대조가 안 깨진다)',
      _clean('"q." — Heb. xi. 23.\n\nconstella-  tion  here').split()
      == ['"q."', '—', 'Heb.', 'xi.', '23.', 'constella-', 'tion', 'here'])
    t('⑭ 되돌리기는 지우지 않는다(HIDE)',
      "record_status='HIDE'" in io.open(__file__, encoding='utf-8').read())
    t('⑮ 출처를 DB 에 남긴다', 'record_source' in io.open(__file__, encoding='utf-8').read())

    # ⑯ 구절약명 — **화면이 약명으로 옮길 수 있는 꼴**이라야 한다.
    #   ⚠ 이 책의 제사는 `Heb. xi. 23` 꼴이고, 그대로 담았더니 실측
    #     25줄 가운데 약명이 된 것이 **0개**였다(`_localize_ref` 가
    #     아라비아 숫자만 읽는다). 되돌아가지 못하게 잠근다.
    import sqlite3 as _s3
    _c = _s3.connect(':memory:')
    _c.execute('CREATE TABLE book_names(book_code INT, lang_code TEXT,'
               ' full_name TEXT)')
    _c.execute("INSERT INTO book_names VALUES(58,'EN','Hebrews')")
    t('⑯ 약명은 영어 정식 이름 + **아라비아 숫자**(로마숫자면 화면이 못 옮긴다)',
      app_ref(_c, (58, 11, 23)) == 'Hebrews 11:23')
    t('⑯-2 좌표가 없으면 안 지어낸다', app_ref(_c, None) is None)
    t('⑰ 깨진 쪽 머리말을 걷는다(쪽 번호가 붙은 것)',
      is_header("12 '^is ^othtx's JTattlr."))
    t('⑰-2 쪽 번호가 없어도 기능어가 없으면 머리말이다',
      is_header('lo ®ur ^tantrpoittt.'))
    t('⑰-3 **본문 줄은 안 걷는다** — 기호가 튀어도 기능어가 있다',
      not is_header('the loom> for which the Egyptians became so famous, of'))
    t('⑰-4 본문 줄은 안 걷는다(2) — 끝에 기호가 붙은 자리',
      not is_header('manding features of mind and body, and have been versed in^'))
    _v = {'lime', 'avenues', 'were', 'befitting', 'approach', 'our'}
    t('⑰-7 증인이 있으면 **낱말 비율**로 가른다 — 본문은 남는다',
      not is_header('lime avenues were ^e befitting approach.', _v))
    t('⑰-8 증인이 있으면 뭉개진 머리말은 걷는다',
      is_header("dob's ^vtzmtt our Hist.", _v))
    t('⑰-9 **기호가 없어도** 뭉개진 머리말은 걷는다',
      is_header('14 His Mothtfs JFaitlr.', {'his', 'faith', 'mother'}))
    t('⑰-11 **기능어 둘이면 본문이다** — 두 스캔이 함께 뭉갠 자리를 지킨다',
      not is_header('their arms, rattling their chains, straining their'
                    ' cords, and', {'their', 'arms', 'chains'}))
    t('⑰-12 기능어가 하나뿐인 머리말은 그대로 걷는다',
      is_header('^t iht foot of ^itiax.', {'foot', 'of'}))
    t('⑰-10 낱말이 둘뿐이면 **아예 없을 때만** 걷는다(짧은 본문 줄을 지킨다)',
      not is_header('unkindly lot.', {'unkindly', 'lot'})
      and is_header('8 (bm Staniipoint.', {'our', 'standpoint'}))
    t('⑰-5 성구 제사는 안 걷는다(기호가 없다)',
      not is_header('"By faith, Moses. . ." — Heb. xi. 24.'))
    t('⑰-6 걷은 수를 함께 돌려준다(조용히 안 지운다)',
      strip_headers("a\n12 '^is ^othtx's JTattlr.\nb") == ('a\nb', 1))
    t('⑯-3 책 이름이 표에 없으면 비운다(짐작하지 않는다)',
      app_ref(_c, (99, 1, 1)) is None)

    print('\ndb_meyer_hero_import selftest %d/%d' % (n[0], n[1]))
    return n[0] == n[1]


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--modern-check', metavar='JSON')
    ap.add_argument('--modern', metavar='JSON')
    ap.add_argument('--links', nargs='?', const=DEFAULT)
    ap.add_argument('--fetch', nargs='?', const=DEFAULT)
    ap.add_argument('--check', nargs='?', const=DEFAULT)
    ap.add_argument('--apply', nargs='?', const=DEFAULT)
    ap.add_argument('--undo', nargs='?', const=DEFAULT)
    ap.add_argument(SM._ACK_FLAG, action='store_true',
                    dest='ack', help='링크를 확인했다')
    a = ap.parse_args()
    if a.modern_check or a.modern:
        import json
        path = a.modern_check or a.modern
        d = json.load(io.open(path, encoding='utf-8'))
        code = d.get('code', DEFAULT)
        if not modern_check(code, d):
            raise SystemExit(1)
        if a.modern:
            modern_apply(code, d)
        return
    if a.selftest:
        raise SystemExit(0 if selftest() else 1)
    if a.links:
        SM.show_links(a.links, cands(a.links))
    elif a.fetch:
        fetch(a.fetch)
    elif a.check:
        raise SystemExit(0 if check(a.check) else 1)
    elif a.apply:
        apply(a.apply)
    elif a.undo:
        undo(a.undo)
    else:
        ap.print_help()


if __name__ == '__main__':
    main()
