"""최신 콘텐츠(뉴스·묵상·유튜브) 받기 설정 — PC 와 폰이 함께 쓰는 **한 벌**(2026-10-22 신설·영구).

★ 사용자 지시(docs/1.txt 5-1 · 2026-10-22) — 「폰/PC 에서 수집여부, 수집주기, 수집시간을 설정하는 기능 ·
  PC/폰 양쪽에 설정하면 중복이다. 한쪽에서만 설정하고 동기화하는 것이 좋다」.
  ⇒ 설정은 이 한 벌(`user_config['NEWS_PREF']` JSON)이다. 어느 쪽에서 고쳐도 **고친 때(`at`)가 늦은 것이 이긴다**.
    PC → 폰 = 동기화 꾸러미의 `news_pref` · 폰 → PC = 사건 `NEWS_PREF`(mobile_sync).

  on      받을까(끄면 자동으로 안 받는다 · [새로고침]처럼 사람이 누르는 것은 그대로)
  period  DAILY(하루 한 번) · H12 · H6 · MANUAL(누를 때만)
  window  ANY · MORNING · NOON · EVENING · NIGHT — 폰이 백그라운드로 받을 시간대(PC 는 탭을 열 때 받는다)
  at      고친 때(ISO) — 동기화에서 늦은 것이 이긴다

    python news_pref.py --selftest
"""
import json
import sys
from datetime import datetime

KEY = 'NEWS_PREF'
PERIOD_HOURS = {'DAILY': 24, 'H12': 12, 'H6': 6, 'MANUAL': 0}
WINDOWS = ('ANY', 'MORNING', 'NOON', 'EVENING', 'NIGHT')
DEFAULT = {'on': 1, 'period': 'DAILY', 'window': 'ANY', 'at': ''}


def _clean(d):
    out = dict(DEFAULT)
    if isinstance(d, dict):
        out['on'] = 1 if d.get('on', 1) not in (0, '0', False, 'false') else 0
        if d.get('period') in PERIOD_HOURS:
            out['period'] = d['period']
        if d.get('window') in WINDOWS:
            out['window'] = d['window']
        out['at'] = str(d.get('at') or '')
    return out


def get(conn):
    try:
        r = conn.execute("SELECT config_val FROM user_config WHERE config_key=?", (KEY,)).fetchone()
        return _clean(json.loads(r[0])) if r and r[0] else dict(DEFAULT)
    except Exception:
        return dict(DEFAULT)


def _write(conn, d, commit=True):
    v = json.dumps(_clean(d), ensure_ascii=False, sort_keys=True)
    cur = conn.execute("UPDATE user_config SET config_val=? WHERE config_key=?", (v, KEY))
    if not cur.rowcount:
        conn.execute("INSERT INTO user_config(config_key, config_val) VALUES(?,?)", (KEY, v))
    if commit:
        conn.commit()


def set_pref(conn, **kw):
    """PC 화면이 고친다 — 고친 때를 지금으로."""
    d = get(conn)
    d.update({k: v for k, v in kw.items() if k in ('on', 'period', 'window')})
    d['at'] = datetime.now().isoformat(timespec='seconds')
    _write(conn, d)
    return get(conn)


def apply_from_phone(conn, d, commit=True):
    """폰이 보낸 설정 — 고친 때가 PC 것보다 늦을 때만 받는다 → 받았나."""
    new = _clean(d)
    cur = get(conn)
    if new['at'] and new['at'] > (cur['at'] or ''):
        _write(conn, new, commit)
        return True
    return False


def min_hours(conn):
    """PC 자동 받기 간격(시간) — 꺼짐이나 MANUAL 이면 None(자동으로 안 받는다)."""
    d = get(conn)
    if not d['on']:
        return None
    h = PERIOD_HOURS.get(d['period'], 24)
    return h or None


def selftest():
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.execute('CREATE TABLE user_config (config_key TEXT PRIMARY KEY, config_val TEXT)')
    n = [0, 0]

    def ck(name, ok):
        n[0 if ok else 1] += 1
        print(('  PASS ' if ok else '  FAIL ') + name)

    ck('기본 = 켬 · 하루 한 번', get(c)['on'] == 1 and get(c)['period'] == 'DAILY' and min_hours(c) == 24)
    set_pref(c, period='H6')
    ck('PC 가 고치면 6시간 · 고친 때가 남는다', min_hours(c) == 6 and get(c)['at'])
    at = get(c)['at']
    ck('폰이 옛 설정을 보내면 안 받는다', not apply_from_phone(c, {'on': 0, 'period': 'DAILY', 'at': '2000-01-01T00:00:00'}))
    ck('폰이 더 늦게 고친 것은 받는다', apply_from_phone(c, {'on': 0, 'period': 'DAILY', 'window': 'MORNING', 'at': at + 'Z'}))
    ck('끄면 자동으로 안 받는다', min_hours(c) is None and get(c)['window'] == 'MORNING')
    set_pref(c, on=1, period='MANUAL')
    ck('누를 때만 = 자동 없음', min_hours(c) is None)
    ck('모르는 값은 기본으로', _clean({'period': 'XX', 'window': 'YY'})['period'] == 'DAILY')
    print('news_pref selftest %d/%d' % (n[0], sum(n)))
    return n[1] == 0


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    print(__doc__)
