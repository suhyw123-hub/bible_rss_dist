# -*- coding: utf-8 -*-
"""search_row — P4 목록 화면 공통 검색 줄 [입력창][검색][X] (2026-10-07 · docs/1.txt 51-4(6)).

사용자 「검색창 : 온라인영상, 연구/설교노트, 주요용어 탭화면의 "입력창, 찾기, X버튼"을 모두 통일」.
★ 세 화면이 **이 한 부품**을 심는다 — 화면마다 짓으면 단추 이름·자리·X 의 뜻이 갈린다
  (연구노트는 X 가 검색 중에만 보였고 · 온라인영상은 [검색] 단추가 없었다).
★ 모양은 주요용어의 것(사용자가 모범사례로 든 화면) — 입력창이 남는 폭을 쓰고 [검색]·[X] 는 늘 보인다.
  · Enter = 검색 · Esc = X · 입력창을 비우면 곧바로 X 와 같다(갇힌 느낌을 없앤다).
"""
import tkinter as tk

import i18n


def _font(w, db_path):
    if not db_path:
        return
    try:
        import theme_font
        theme_font.register(w, db_path, 'ui')
    except Exception:
        pass


def build(parent, q_var, on_search, on_clear, db_path=None, width=14,
          side='left', expand=True):
    """parent 안에 [입력창][검색][X] 를 담는다 → {'entry','search','clear'}."""
    ent = tk.Entry(parent, textvariable=q_var, width=width)
    _font(ent, db_path)
    ent.pack(side=side, fill='x', expand=expand, padx=(2, 2), pady=2)
    ent.bind('<Return>', lambda _e: on_search())
    ent.bind('<Escape>', lambda _e: on_clear())
    ent.bind('<KeyRelease>',
             lambda _e: on_clear() if not (q_var.get() or '').strip() and
             getattr(ent, '_had_text', False) else None, add='+')

    def _mark(_e=None):
        ent._had_text = bool((q_var.get() or '').strip())
    ent.bind('<KeyPress>', _mark, add='+')

    sb = tk.Button(parent, text=i18n.t('COMMON_SEARCH', '검색'),
                   command=on_search, cursor='hand2', bd=1, padx=6)
    _font(sb, db_path)
    sb.pack(side='left', padx=(0, 2), pady=2)
    xb = tk.Button(parent, text='X', command=on_clear, cursor='hand2', bd=1, padx=6)
    _font(xb, db_path)
    xb.pack(side='left', padx=(0, 2), pady=2)
    return {'entry': ent, 'search': sb, 'clear': xb}


def selftest():
    ok = []
    root = tk.Tk()
    root.withdraw()
    v = tk.StringVar()
    hits = []
    w = build(root, v, lambda: hits.append('S'), lambda: hits.append('X'))
    ok.append(w['search'].cget('text') and w['clear'].cget('text') == 'X')
    w['search'].invoke(); w['clear'].invoke()
    ok.append(hits == ['S', 'X'])
    root.destroy()
    print('search_row selftest %d/%d' % (sum(map(bool, ok)), len(ok)))
    return all(ok)


if __name__ == '__main__':
    import sys
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
