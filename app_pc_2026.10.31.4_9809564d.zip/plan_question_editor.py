"""
plan_question_editor.py
묵상질문 통합 편집기.

  LITURGICAL 플랜     : PLAN_QUESTION  (schedule_id 기반, 단계 문맥 유지)
  그 외 모든 플랜유형  : PERI_QUESTION  (pericope_id 기반, 1Y/2Y/3Y/커스텀 공유)

P2 '플랜 편집기' 탭에 마운트된다.
"""
import sqlite3
import verse_ref
import appdb
import lang_ui as _lu   # 언어 콤보 = 영어 이름(값은 코드)
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox

_STAGE_LABEL = {
    'EVENT': '사건', 'LAW': '율법', 'EXPANSION': '확장',
    'FULFILLMENT': '성취', 'APPLICATION': '적용', 'READ': '읽기',
}
import lang_config                       # 언어 단일 소스(sys_language)
_LANGS = lang_config.ui_langs()

_TYPE_GROUP_LABEL = {
    'SEQUENTIAL':    '정경 순서 통독',
    'CHRONOLOGICAL': '연대기 순서 통독',
    'LITURGICAL':    '절기 묵상',
    'THEMATIC':      '주제별 묵상',
    'HYBRID':        '혼합형',
}

_MODE_LITURGICAL = 'LITURGICAL'
_MODE_PERICOPE   = 'PERICOPE'


class PlanQuestionEditor(tk.Frame):

    def __init__(self, parent, db_path, lang_getter):
        super().__init__(parent, bg='#F4F6F7')
        self.db_path     = db_path
        self.lang_getter = lang_getter

        self._mode       = _MODE_PERICOPE
        self._ptype      = None
        self._plan_id    = None
        self._sched_rows = []
        self._peri_rows  = []
        self._sel_sched  = None
        self._sel_peri   = None
        self._vid_cache  = {}
        self._target_map = {}   # display label -> ptype
        self._liturg_map = {}   # display label -> plan_id
        self._book_map   = {}   # display label -> bcode

        self._build()
        self.after(100, self._load_initial)

    # ── UI 구성 ────────────────────────────────────────────────────────────────

    def _build(self):
        # ── 헤더 바 ──────────────────────────────────────────────────────────
        hdr = tk.Frame(self, bg='#2C3E50', pady=4)
        hdr.pack(fill='x')

        tk.Label(hdr, text='편집 대상:', bg='#2C3E50', fg='white',
                 font=('Malgun Gothic', 9)).pack(side='left', padx=(8, 2))
        self.target_var = tk.StringVar()
        self.target_cb  = ttk.Combobox(hdr, textvariable=self.target_var,
                                        state='readonly', width=20)
        self.target_cb.pack(side='left', padx=(2, 0))
        self.target_cb.bind('<<ComboboxSelected>>', lambda e: self._on_target_changed())

        # LITURGICAL 전용 서브 컨트롤 (pack/forget으로 전환)
        self._liturg_hdr = tk.Frame(hdr, bg='#2C3E50')
        tk.Label(self._liturg_hdr, text='플랜:', bg='#2C3E50', fg='white',
                 font=('Malgun Gothic', 9)).pack(side='left', padx=(10, 2))
        self.liturg_var = tk.StringVar()
        self.liturg_cb  = ttk.Combobox(self._liturg_hdr, textvariable=self.liturg_var,
                                        state='readonly', width=18)
        self.liturg_cb.pack(side='left', padx=2)
        self.liturg_cb.bind('<<ComboboxSelected>>', lambda e: self._on_liturg_changed())
        tk.Label(self._liturg_hdr, text='Day:', bg='#2C3E50', fg='white',
                 font=('Malgun Gothic', 9)).pack(side='left', padx=(8, 2))
        self.day_var = tk.IntVar(value=1)
        _nb = dict(font=('Malgun Gothic', 9, 'bold'), bd=0,
                   padx=6, pady=1, bg='#3D566E', fg='white')
        tk.Button(self._liturg_hdr, text='◀', command=self._day_prev,
                  **_nb).pack(side='left', padx=(0, 1))
        self.day_entry = tk.Entry(self._liturg_hdr, textvariable=self.day_var,
                                  width=4, font=('Malgun Gothic', 9),
                                  justify='center')
        self.day_entry.pack(side='left', padx=1)
        self.day_entry.bind('<Return>',   lambda e: self._load_day())
        self.day_entry.bind('<FocusOut>', lambda e: self._load_day())
        tk.Button(self._liturg_hdr, text='▶', command=self._day_next,
                  **_nb).pack(side='left', padx=(1, 0))
        self.lbl_week = tk.Label(self._liturg_hdr, text='', bg='#2C3E50', fg='#AED6F1',
                                 font=('Malgun Gothic', 9))
        self.lbl_week.pack(side='left', padx=8)
        tk.Button(self._liturg_hdr, text='주차 정보',
                  command=self._open_week_editor,
                  bg='#3D566E', fg='#F7DC6F',
                  font=('Malgun Gothic', 8, 'bold'),
                  bd=0, padx=8, pady=2).pack(side='left', padx=4)

        # PERICOPE 모드: 책 + 정렬 필터 (pack/forget으로 전환)
        self._peri_hdr = tk.Frame(hdr, bg='#2C3E50')
        tk.Label(self._peri_hdr, text='책:', bg='#2C3E50', fg='white',
                 font=('Malgun Gothic', 9)).pack(side='left', padx=(10, 2))
        self.book_var = tk.StringVar()
        self.book_cb  = ttk.Combobox(self._peri_hdr, textvariable=self.book_var,
                                      state='readonly', width=10)
        self.book_cb.pack(side='left', padx=2)
        self.book_cb.bind('<<ComboboxSelected>>', lambda e: self._load_pericopes())
        tk.Label(self._peri_hdr, text='정렬:', bg='#2C3E50', fg='white',
                 font=('Malgun Gothic', 9)).pack(side='left', padx=(10, 2))
        self.sort_var = tk.StringVar(value='정경 순서')
        self.sort_cb  = ttk.Combobox(self._peri_hdr, textvariable=self.sort_var,
                                      values=['정경 순서', '연대기 순서'],
                                      state='readonly', width=10)
        self.sort_cb.pack(side='left', padx=2)
        self.sort_cb.bind('<<ComboboxSelected>>', lambda e: self._load_pericopes())

        # Lang 선택 (항상 우측)
        tk.Label(hdr, text='Lang:', bg='#2C3E50', fg='white',
                 font=('Malgun Gothic', 9)).pack(side='right', padx=(0, 4))
        self.lang_var = tk.StringVar(value='EN')
        lang_cb = ttk.Combobox(hdr, textvariable=self.lang_var,
                               values=_LANGS, state='readonly', width=5)
        _lu.retrofit(lang_cb)   # 언어 콤보 = 영어 이름(값은 코드 그대로)
        lang_cb.pack(side='right', padx=(0, 8))
        lang_cb.bind('<<ComboboxSelected>>', lambda e: self._on_lang_changed())

        # ── 메인 PanedWindow ─────────────────────────────────────────────────
        pw = tk.PanedWindow(self, orient='horizontal', sashwidth=4, bg='#BDC3C7')
        pw.pack(expand=True, fill='both')

        # ── 좌측: 목록 패널 ───────────────────────────────────────────────────
        left = tk.Frame(pw, bg='#F4F6F7')
        pw.add(left, width=450)

        self.list_label = tk.Label(left, text='', bg='#2C3E50', fg='white',
                                   font=('Malgun Gothic', 9, 'bold'), pady=3)
        self.list_label.pack(fill='x')

        # LITURGICAL 모드: schedule 트리 컨테이너
        self._sched_box = tk.Frame(left, bg='#F4F6F7')
        sched_vsb = ttk.Scrollbar(self._sched_box, orient='vertical')
        sched_vsb.pack(side='right', fill='y')
        sched_cols = ('stage', 'passage', 'focus', 'has_q')
        self.sched_tree = ttk.Treeview(self._sched_box, columns=sched_cols,
                                        show='headings', height=20,
                                        yscrollcommand=sched_vsb.set)
        sched_vsb.config(command=self.sched_tree.yview)
        self.sched_tree.heading('stage',   text='단계')
        self.sched_tree.heading('passage', text='본문 범위')
        self.sched_tree.heading('focus',   text='묵상 주제')
        self.sched_tree.heading('has_q',   text='질문')
        self.sched_tree.column('stage',   width=65,  anchor='center')
        self.sched_tree.column('passage', width=115, anchor='center')
        self.sched_tree.column('focus',   width=210, anchor='w')
        self.sched_tree.column('has_q',   width=40,  anchor='center')
        self.sched_tree.pack(expand=True, fill='both')
        self.sched_tree.bind('<<TreeviewSelect>>', self._on_sched_select)

        # PERICOPE 모드: pericope 트리 컨테이너
        self._peri_box = tk.Frame(left, bg='#F4F6F7')
        peri_vsb = ttk.Scrollbar(self._peri_box, orient='vertical')
        peri_vsb.pack(side='right', fill='y')
        peri_cols = ('seq', 'passage', 'title', 'has_q')
        self.peri_tree = ttk.Treeview(self._peri_box, columns=peri_cols,
                                       show='headings', height=20,
                                       yscrollcommand=peri_vsb.set)
        peri_vsb.config(command=self.peri_tree.yview)
        self.peri_tree.heading('seq',     text='#')
        self.peri_tree.heading('passage', text='본문 범위')
        self.peri_tree.heading('title',   text='페리코프 제목')
        self.peri_tree.heading('has_q',   text='질문')
        self.peri_tree.column('seq',     width=40,  anchor='center')
        self.peri_tree.column('passage', width=125, anchor='center')
        self.peri_tree.column('title',   width=235, anchor='w')
        self.peri_tree.column('has_q',   width=40,  anchor='center')
        self.peri_tree.pack(expand=True, fill='both')
        self.peri_tree.bind('<<TreeviewSelect>>', self._on_peri_select)

        # ── 우측: 편집 폼 ────────────────────────────────────────────────────
        right = tk.Frame(pw, bg='#FDFEFE', padx=10, pady=8)
        pw.add(right)

        self.lbl_form_title = tk.Label(right, text='질문 수정',
                                        bg='#1A5276', fg='white',
                                        font=('Malgun Gothic', 10, 'bold'), pady=4)
        self.lbl_form_title.pack(fill='x', pady=(0, 8))

        self.lbl_context = tk.Label(right, text='← 항목을 선택하세요',
                                     bg='#FDFEFE', fg='#7F8C8D',
                                     font=('Malgun Gothic', 9),
                                     wraplength=380, justify='left')
        self.lbl_context.pack(anchor='w', pady=(0, 8))

        tk.Label(right, text='제목 (title)', bg='#FDFEFE', fg='#2C3E50',
                 font=('Malgun Gothic', 9, 'bold')).pack(anchor='w')
        self.title_var = tk.StringVar()
        tk.Entry(right, textvariable=self.title_var,
                 font=('Malgun Gothic', 10), width=45).pack(fill='x', pady=(2, 8))

        # ★★ **맨 위로 올렸다**(§0 · 2026-09-22) — `side='bottom'` 이라
        #   [저장]·[삭제] 가 y=859/900 에 있었다. 사용자 지시 「하단 배치는
        #   패널 크기·창 작음에 따라 잘리거나 안 보여 사용자가 못 찾는다」.
        btn_row = tk.Frame(right, bg='#FDFEFE')
        btn_row.pack(side='top', fill='x', pady=(0, 6),
                     before=right.winfo_children()[0]
                     if right.winfo_children() else None)
        tk.Button(btn_row, text='저장', command=self._save,
                  bg='#1A5276', fg='white',
                  font=('Malgun Gothic', 10, 'bold'),
                  bd=0, padx=16, pady=4).pack(side='left')
        tk.Button(btn_row, text='삭제', command=self._delete,
                  bg='#922B21', fg='white',
                  font=('Malgun Gothic', 9),
                  bd=0, padx=12, pady=4).pack(side='left', padx=8)
        self.lbl_status = tk.Label(btn_row, text='', bg='#FDFEFE', fg='#27AE60',
                                    font=('Malgun Gothic', 9))
        self.lbl_status.pack(side='left', padx=8)

        tk.Label(right, text='내용 (contents)', bg='#FDFEFE', fg='#2C3E50',
                 font=('Malgun Gothic', 9, 'bold')).pack(anchor='w')
        self.body_txt = scrolledtext.ScrolledText(
            right, font=('Malgun Gothic', 10), height=10, wrap='word')
        self.body_txt.pack(expand=True, fill='both', pady=(2, 4))

    # ── 초기 로드 ─────────────────────────────────────────────────────────────

    def _load_initial(self):
        nav_lang = self.lang_getter() if self.lang_getter else 'KO'
        try:
            with appdb.connect(self.db_path) as conn:
                ptypes = conn.execute(
                    "SELECT DISTINCT plan_type FROM sys_bible_plan "
                    "WHERE record_status='LIVE' ORDER BY plan_type"
                ).fetchall()
                liturg_plans = conn.execute(
                    "SELECT plan_id, plan_code FROM sys_bible_plan "
                    "WHERE plan_type='LITURGICAL' AND record_status='LIVE' ORDER BY plan_id"
                ).fetchall()
                # 고르는 콤보는 정식명(full_name) — 관리자 전 화면 공통 원칙(0.txt 4-2)
                book_rows = conn.execute(
                    "SELECT book_code, COALESCE(full_name, short_name) FROM book_names "
                    "WHERE lang_code=? ORDER BY book_code", (nav_lang,)
                ).fetchall()
                if not book_rows:
                    book_rows = conn.execute(
                        "SELECT book_code, COALESCE(full_name, short_name) FROM book_names "
                        "WHERE lang_code='EN' ORDER BY book_code"
                    ).fetchall()
        except Exception as e:
            print(f'[PlanQuestionEditor] init error: {e}')
            return

        self._target_map = {}
        targets = []
        todeok_added = False
        for (pt,) in ptypes:
            if pt in ('SEQUENTIAL', 'CHRONOLOGICAL'):
                if not todeok_added:
                    self._target_map['통독'] = 'TODEOK'
                    targets.append('통독')
                    todeok_added = True
            else:
                label = _TYPE_GROUP_LABEL.get(pt, pt)
                self._target_map[label] = pt
                targets.append(label)
        self.target_cb['values'] = targets

        self._liturg_map = {f"{r[1]} (id={r[0]})": r[0] for r in liturg_plans}
        self.liturg_cb['values'] = list(self._liturg_map.keys())
        if self._liturg_map:
            self.liturg_cb.current(0)
            self._plan_id = next(iter(self._liturg_map.values()))

        self._book_map = {row[1]: row[0] for row in book_rows}
        self.book_cb['values'] = list(self._book_map.keys())
        if self._book_map:
            self.book_cb.current(0)

        if targets:
            self.target_cb.current(0)
            self._on_target_changed()

    # ── 모드 전환 ─────────────────────────────────────────────────────────────

    def _on_target_changed(self):
        label  = self.target_var.get()
        target = self._target_map.get(label, '')
        self._ptype = target
        self._mode  = _MODE_LITURGICAL if target == 'LITURGICAL' else _MODE_PERICOPE
        if self._mode == _MODE_LITURGICAL:
            key = self.liturg_var.get()
            self._plan_id = self._liturg_map.get(key)
        else:
            self._plan_id = None
        self._apply_mode_ui()
        self._clear_form()
        if self._mode == _MODE_LITURGICAL:
            self._load_day()
        else:
            self._load_pericopes()

    def _on_liturg_changed(self):
        key = self.liturg_var.get()
        self._plan_id = self._liturg_map.get(key)
        self._load_day()

    def _on_lang_changed(self):
        if self._mode == _MODE_LITURGICAL:
            self._load_day()
        else:
            self._load_pericopes()

    def _apply_mode_ui(self):
        if self._mode == _MODE_LITURGICAL:
            self._peri_hdr.pack_forget()
            self._liturg_hdr.pack(side='left')
            self._peri_box.pack_forget()
            self._sched_box.pack(expand=True, fill='both')
            self.list_label.config(text='오늘의 묵상 단계  (PLAN_QUESTION)')
            self.lbl_form_title.config(text='PLAN_QUESTION 수정  ·  schedule_id 기반')
        else:
            self._liturg_hdr.pack_forget()
            self._peri_hdr.pack(side='left')
            self._sched_box.pack_forget()
            self._peri_box.pack(expand=True, fill='both')
            self.list_label.config(text='페리코프 목록  (PERI_QUESTION  ·  1Y/2Y/3Y/커스텀 공유)')
            self.lbl_form_title.config(
                text='PERI_QUESTION 편집  ·  pericope_id 기반  ·  모든 기간 공유')

    # ── LITURGICAL: Day 로드 ──────────────────────────────────────────────────

    def _day_prev(self):
        v = self.day_var.get()
        if v > 1:
            self.day_var.set(v - 1)
            self._load_day()

    def _day_next(self):
        self.day_var.set(self.day_var.get() + 1)
        self._load_day()

    def _load_day(self):
        if not self._plan_id:
            return
        try:
            day = int(self.day_var.get())
        except ValueError:
            return
        week   = (day - 1) // 7 + 1
        day_in = (day - 1) % 7 + 1
        self.lbl_week.config(text=f'Week {week} / Day {day_in}')
        lang = self.lang_var.get()
        try:
            with appdb.connect(self.db_path) as conn:
                self._sched_rows = conn.execute(
                    """
                    SELECT ps.schedule_id, ps.sort_order, ps.stage_type,
                           ps.start_vid, ps.end_vid,
                           COALESCE(pf.title, ps.meditation_focus) AS focus,
                           pq.sys_text_id
                    FROM sys_plan_schedule ps
                    LEFT JOIN sys_text_asset pf
                           ON pf.clicked_id = ps.schedule_id
                          AND pf.text_type  = 'PLAN_FOCUS'
                          AND pf.lang_code  = ? AND pf.record_status = 'LIVE'
                    LEFT JOIN sys_text_asset pq
                           ON pq.clicked_id = ps.schedule_id
                          AND pq.text_type  = 'PLAN_QUESTION'
                          AND pq.lang_code  = ? AND pq.record_status = 'LIVE'
                    WHERE ps.plan_id = ? AND ps.day = ?
                    ORDER BY ps.sort_order
                    """,
                    (lang, lang, self._plan_id, day)
                ).fetchall()
                self._build_vid_cache(conn, lang,
                                      [(r[3], r[4]) for r in self._sched_rows])
        except Exception as e:
            print(f'[PlanQuestionEditor] day load error: {e}')
            self._sched_rows = []
        self._populate_sched_tree()
        self._clear_form()

    def _populate_sched_tree(self):
        for item in self.sched_tree.get_children():
            self.sched_tree.delete(item)
        for r in self._sched_rows:
            sched_id, sort_ord, stage, svid, evid, focus, q_id = r
            self.sched_tree.insert(
                '', 'end', iid=str(sched_id),
                values=(
                    _STAGE_LABEL.get(stage, stage or '—'),
                    self._passage_label(svid, evid),
                    (focus or '')[:40],
                    '✓' if q_id else ''
                )
            )

    def _on_sched_select(self, event):
        sel = self.sched_tree.selection()
        if not sel:
            return
        self._sel_sched = int(sel[0])
        row = next((r for r in self._sched_rows if r[0] == self._sel_sched), None)
        if not row:
            return
        sched_id, sort_ord, stage, svid, evid, focus, q_id = row
        stage_lbl = _STAGE_LABEL.get(stage, stage or '—')
        passage   = self._passage_label(svid, evid)
        self.lbl_context.config(
            text=f'{sort_ord}. {stage_lbl}  ·  {passage}', fg='#1A5276')
        self._reload_question()

    # ── PERICOPE 모드: 페리코프 로드 ─────────────────────────────────────────

    def _load_pericopes(self):
        book_label = self.book_var.get()
        bcode = self._book_map.get(book_label)
        if bcode is None:
            return
        lang = self.lang_var.get()
        if self.sort_var.get() == '연대기 순서':
            order_expr   = 'COALESCE(p.chrono_order, 9999999)'
            order_clause = f'ORDER BY {order_expr}, p.start_vid'
        else:
            order_expr   = 'p.start_vid'
            order_clause = 'ORDER BY p.start_vid'

        try:
            with appdb.connect(self.db_path) as conn:
                rows = conn.execute(
                    f"""
                    SELECT p.pericope_id,
                           p.start_vid, p.end_vid,
                           {order_expr}                              AS ord_val,
                           COALESCE(pt.title, pt_en.title, '')       AS peri_title,
                           CASE WHEN pq.sys_text_id IS NOT NULL
                                THEN 1 ELSE 0 END                    AS has_q
                    FROM sys_pericope_asset p
                    JOIN bible_index bi_s ON bi_s.verse_id = p.start_vid
                    LEFT JOIN sys_text_asset pt
                           ON pt.clicked_id = p.pericope_id
                          AND pt.text_type  = 'PERI_TITLE'
                          AND pt.lang_code  = ?
                    LEFT JOIN sys_text_asset pt_en
                           ON pt_en.clicked_id = p.pericope_id
                          AND pt_en.text_type  = 'PERI_TITLE'
                          AND pt_en.lang_code  = 'EN'
                    LEFT JOIN sys_text_asset pq
                           ON pq.clicked_id    = p.pericope_id
                          AND pq.text_type     = 'PERI_QUESTION'
                          AND pq.lang_code     = ?
                          AND pq.record_status = 'LIVE'
                    WHERE p.peri_type = 'BODY'
                      AND bi_s.bcode  = ?
                    {order_clause}
                    """,
                    (lang, lang, bcode)
                ).fetchall()
                self._build_vid_cache(conn, lang,
                                      [(r[1], r[2]) for r in rows])
        except Exception as e:
            print(f'[PlanQuestionEditor] pericope load error: {e}')
            rows = []

        self._peri_rows = rows
        self._populate_peri_tree()
        self._clear_form()

    def _populate_peri_tree(self):
        for item in self.peri_tree.get_children():
            self.peri_tree.delete(item)
        for i, r in enumerate(self._peri_rows, 1):
            peri_id, svid, evid, ord_val, peri_title, has_q = r
            title_disp = (peri_title[:32] + '…') if len(peri_title) > 32 else peri_title
            self.peri_tree.insert(
                '', 'end', iid=str(peri_id),
                values=(i, self._passage_label(svid, evid), title_disp,
                        '✓' if has_q else '')
            )

    def _on_peri_select(self, event):
        sel = self.peri_tree.selection()
        if not sel:
            return
        self._sel_peri = int(sel[0])
        row = next((r for r in self._peri_rows if r[0] == self._sel_peri), None)
        if not row:
            return
        peri_id, svid, evid, ord_val, peri_title, has_q = row
        passage = self._passage_label(svid, evid)
        context = passage + (f'  ·  {peri_title}' if peri_title else '')
        self.lbl_context.config(text=context, fg='#1A5276')
        self._reload_question()

    # ── 공통: 질문 로드/저장/삭제 ────────────────────────────────────────────

    def _reload_question(self):
        lang       = self.lang_var.get()
        clicked_id, text_type = self._current_key()
        if clicked_id is None:
            return
        try:
            with appdb.connect(self.db_path) as conn:
                row = conn.execute(
                    "SELECT title, contents FROM sys_text_asset "
                    "WHERE clicked_id=? AND text_type=? "
                    "AND lang_code=? AND record_status='LIVE'",
                    (clicked_id, text_type, lang)
                ).fetchone()
        except Exception:
            row = None
        self.title_var.set(row[0] if row and row[0] else '')
        self.body_txt.delete('1.0', tk.END)
        if row and row[1]:
            self.body_txt.insert('1.0', row[1])
        self.lbl_status.config(text='')

    def _save(self):
        clicked_id, text_type = self._current_key()
        if clicked_id is None:
            messagebox.showwarning('선택 없음', '항목을 먼저 선택하세요.')
            return
        lang  = self.lang_var.get()
        title = self.title_var.get().strip()
        body  = self.body_txt.get('1.0', tk.END).strip()
        if not title and not body:
            messagebox.showwarning('내용 없음', '제목 또는 내용을 입력하세요.')
            return
        try:
            with appdb.connect(self.db_path) as conn:
                existing = conn.execute(
                    "SELECT sys_text_id FROM sys_text_asset "
                    "WHERE clicked_id=? AND text_type=? "
                    "AND lang_code=? AND record_status='LIVE'",
                    (clicked_id, text_type, lang)
                ).fetchone()
                if existing:
                    conn.execute(
                        "UPDATE sys_text_asset SET title=?, contents=? "
                        "WHERE sys_text_id=?",
                        (title or None, body or None, existing[0])
                    )
                    msg = '수정됨'
                else:
                    conn.execute(
                        "INSERT INTO sys_text_asset "
                        "(clicked_id, text_type, title, contents, lang_code, record_status) "
                        "VALUES (?, ?, ?, ?, ?, 'LIVE')",
                        (clicked_id, text_type, title or None, body or None, lang)
                    )
                    msg = '저장됨'
            self.lbl_status.config(text=f'✓ {msg}', fg='#27AE60')
            self._refresh_after_save()
        except Exception as e:
            messagebox.showerror('오류', str(e))

    def _delete(self):
        clicked_id, text_type = self._current_key()
        if clicked_id is None:
            return
        lang = self.lang_var.get()
        label = (f'schedule_id={clicked_id}' if self._mode == _MODE_LITURGICAL
                 else f'pericope_id={clicked_id}')
        if not messagebox.askyesno('삭제 확인',
                                   f'{label} / {lang} 질문을 삭제하겠습니까?'):
            return
        try:
            with appdb.connect(self.db_path) as conn:
                conn.execute(
                    "UPDATE sys_text_asset SET record_status='HIDE' "
                    "WHERE clicked_id=? AND text_type=? "
                    "AND lang_code=? AND record_status='LIVE'",
                    (clicked_id, text_type, lang)
                )
            self.lbl_status.config(text='삭제됨', fg='#E74C3C')
            self._refresh_after_save()
        except Exception as e:
            messagebox.showerror('오류', str(e))

    def _refresh_after_save(self):
        if self._mode == _MODE_LITURGICAL:
            prev = self._sel_sched
            self._load_day()
            if prev and str(prev) in self.sched_tree.get_children():
                self.sched_tree.selection_set(str(prev))
                self._reload_question()
        else:
            prev = self._sel_peri
            self._load_pericopes()
            if prev and str(prev) in self.peri_tree.get_children():
                self.peri_tree.selection_set(str(prev))
                self._reload_question()

    # ── 폼 초기화 ─────────────────────────────────────────────────────────────

    def _clear_form(self):
        self._sel_sched = None
        self._sel_peri  = None
        self.lbl_context.config(text='← 항목을 선택하세요', fg='#7F8C8D')
        self.title_var.set('')
        self.body_txt.delete('1.0', tk.END)
        self.lbl_status.config(text='')

    # ── 유틸리티 ─────────────────────────────────────────────────────────────

    def _current_key(self) -> tuple:
        """(clicked_id, text_type) 반환. 선택 없으면 (None, None)."""
        if self._mode == _MODE_LITURGICAL:
            return (self._sel_sched, 'PLAN_QUESTION') if self._sel_sched else (None, None)
        else:
            return (self._sel_peri, 'PERI_QUESTION') if self._sel_peri else (None, None)

    def _build_vid_cache(self, conn, lang, vid_pairs):
        for svid, evid in vid_pairs:
            for vid in (svid, evid):
                if vid and vid not in self._vid_cache:
                    row = conn.execute(
                        "SELECT bn.short_name, bi.chapter, bi.verse "
                        "FROM bible_index bi "
                        "JOIN book_names bn ON bi.bcode=bn.book_code "
                        "  AND bn.lang_code=? "
                        "WHERE bi.verse_id=?", (lang, vid)
                    ).fetchone()
                    self._vid_cache[vid] = (
                        (verse_ref.label(verse_ref.SCOPE_BOOK, row[0], row[1], row[2])
                         if row else str(vid))
                    )

    def _passage_label(self, svid, evid) -> str:
        if not svid:
            return '—'
        s = self._vid_cache.get(svid, str(svid))
        if evid and evid != svid:
            return f'{s} ~ {self._vid_cache.get(evid, str(evid))}'
        return s

    # ── LITURGICAL 주차 정보 편집 ─────────────────────────────────────────────

    def _open_week_editor(self):
        """현재 Day의 Week에 대한 WEEK_TITLE / WEEK_DESC 팝업 편집기."""
        if not self._plan_id:
            messagebox.showwarning('선택 없음', '플랜을 먼저 선택하세요.')
            return
        try:
            day = int(self.day_var.get())
        except (ValueError, tk.TclError):
            return
        week       = (day - 1) // 7 + 1
        lang       = self.lang_var.get()
        clicked_id = self._plan_id * 10000 + week

        # 기존 데이터 로드
        try:
            with appdb.connect(self.db_path) as conn:
                t_row = conn.execute(
                    "SELECT sys_text_id, title FROM sys_text_asset "
                    "WHERE clicked_id=? AND text_type='WEEK_TITLE' "
                    "AND lang_code=? AND record_status='LIVE' LIMIT 1",
                    (clicked_id, lang)
                ).fetchone()
                d_row = conn.execute(
                    "SELECT sys_text_id, contents FROM sys_text_asset "
                    "WHERE clicked_id=? AND text_type='WEEK_DESC' "
                    "AND lang_code=? AND record_status='LIVE' LIMIT 1",
                    (clicked_id, lang)
                ).fetchone()
        except Exception as e:
            messagebox.showerror('오류', str(e))
            return

        top = tk.Toplevel(self)
        top.title(f'Week {week} 정보 편집  ·  {lang}')
        top.geometry('500x360')
        top.configure(bg='#1C2833')
        top.grab_set()

        tk.Label(top, text=f'Week {week}  주차 정보  [{lang}]',
                 bg='#1C2833', fg='white',
                 font=('Malgun Gothic', 11, 'bold'),
                 pady=8).pack(fill='x')

        inner = tk.Frame(top, bg='#1C2833', padx=14)
        inner.pack(expand=True, fill='both')

        tk.Label(inner, text='주차 제목  (WEEK_TITLE)',
                 bg='#1C2833', fg='#F7DC6F',
                 font=('Malgun Gothic', 9, 'bold')).pack(anchor='w', pady=(4, 0))
        title_var = tk.StringVar(value=t_row[1] if t_row and t_row[1] else '')
        tk.Entry(inner, textvariable=title_var,
                 font=('Malgun Gothic', 10), width=55).pack(fill='x', pady=(2, 8))

        tk.Label(inner, text='주차 설명  (WEEK_DESC)',
                 bg='#1C2833', fg='#F7DC6F',
                 font=('Malgun Gothic', 9, 'bold')).pack(anchor='w')
        desc_txt = scrolledtext.ScrolledText(
            inner, font=('Malgun Gothic', 10), height=8, wrap='word',
            bg='#212F3D', fg='#D5D8DC', relief='flat', padx=8, pady=6)
        desc_txt.pack(expand=True, fill='both', pady=(2, 8))
        if d_row and d_row[1]:
            desc_txt.insert('1.0', d_row[1])

        status_lbl = tk.Label(top, text='', bg='#1C2833', fg='#27AE60',
                               font=('Malgun Gothic', 9))
        status_lbl.pack()

        def _save_week():
            t_val = title_var.get().strip()
            d_val = desc_txt.get('1.0', tk.END).strip()
            try:
                with appdb.connect(self.db_path) as conn:
                    for text_type, val, existing_row in [
                        ('WEEK_TITLE', t_val, t_row),
                        ('WEEK_DESC',  d_val, d_row),
                    ]:
                        if existing_row:
                            conn.execute(
                                "UPDATE sys_text_asset "
                                "SET title=?, contents=? "
                                "WHERE sys_text_id=?",
                                (val or None, val or None, existing_row[0])
                            )
                        elif val:
                            conn.execute(
                                "INSERT INTO sys_text_asset "
                                "(clicked_id, text_type, title, contents, "
                                " lang_code, record_status) "
                                "VALUES (?, ?, ?, ?, ?, 'LIVE')",
                                (clicked_id, text_type,
                                 val if text_type == 'WEEK_TITLE' else None,
                                 val if text_type == 'WEEK_DESC'  else None,
                                 lang)
                            )
                status_lbl.config(text='✓ 저장됨')
            except Exception as e:
                messagebox.showerror('오류', str(e))

        btn_row = tk.Frame(top, bg='#1C2833')
        btn_row.pack(pady=(0, 10))
        tk.Button(btn_row, text='저장', command=_save_week,
                  bg='#1A5276', fg='white',
                  font=('Malgun Gothic', 9, 'bold'),
                  bd=0, padx=16, pady=4).pack(side='left', padx=4)
        tk.Button(btn_row, text='닫기', command=top.destroy,
                  bg='#922B21', fg='white',
                  font=('Malgun Gothic', 9, 'bold'),
                  bd=0, padx=16, pady=4).pack(side='left', padx=4)
