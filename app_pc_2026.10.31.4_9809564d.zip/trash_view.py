# -*- coding: utf-8 -*-
"""통합 휴지통 — 숨긴 것(HIDE)을 한자리에서 보고 · 복원하고 · 완전 삭제한다.

★ 왜 (2026-08-26 덮개 2단계 확정) — 자기 것 HIDE 가 여러 표에 흩어져
  쌓이기만 했다(실측 23행: 연결 3 · 노트 1 · 즐겨찾기 6 · 연구자료 13 …).
  렌즈만 휴지통(My Lens)이 있었고 나머지는 지울 길 자체가 없었다.
★ **자동 삭제는 하지 않는다** — 사용자 데이터는 사용자가 지운다
  (errlog 90일 자동 정리와 다르다 — 사용자 확정).
★★ **두 가지 HIDE 를 갈라 보인다** (덮개 모델 — overlay.py):
  | 구분 | 뜻 | 할 수 있는 것 |
  |---|---|---|
  | 내 것 | 내가 만든 것을 뗀 것 (§10) | [복원] · [완전 삭제] |
  | **가림** | sys 자산을 덮개로 숨긴 것 | [가림 해제] — user 행을 지우면 sys 가 되살아난다 |
  가림 행을 「복원(LIVE)」하면 EDIT 대체가 되어 버리므로 그 단추는 잠근다.
⚠ 렌즈의 복원·완전 삭제는 **My Lens 의 cascade 로직을 그대로 부른다**
  (`user_lens_manager.LensView._restore_my_lens/_purge_my_lens` — self 는
  db_path 만 쓰므로 셔틀 객체로 unbound 호출. §links_panel count_for 선례).
  베끼면 갈라진다.
자리 = 설정(지원/설정) ▸ 휴지통 서브탭. `--selftest` 의무(데이터 함수).
"""
import sys
import tkinter as tk
from tkinter import ttk, messagebox
from types import SimpleNamespace

import appdb
import i18n


# ★ `MEDIA` 신설 (2026-08-30 사용자 신고 「My Edit 화면에 들어가서 **휴지통에서
#   복원해도 에러**」). 실측 — 숨긴 내 링크 3건이 **휴지통에 아예 없었다.**
KINDS = ('LINK', 'NOTE', 'FAV', 'REF', 'LENS', 'TAG', 'ENTITY', 'MEDIA')
_KIND_LBL = {
    'LINK':   ('TRASH_K_LINK', '연결'),
    'NOTE':   ('TRASH_K_NOTE', '노트·글'),
    'FAV':    ('TRASH_K_FAV', '즐겨찾기'),
    'REF':    ('TRASH_K_REF', '연구자료'),
    'LENS':   ('TRASH_K_LENS', '렌즈'),
    'TAG':    ('TRASH_K_TAG', '태그'),
    'ENTITY': ('TRASH_K_ENTITY', '주요용어'),
    'MEDIA':  ('TRASH_K_MEDIA', '내 링크'),
}


# ══════════════════════════════════════════════════════════════════
#  데이터 — 화면과 분리 (selftest 가 이 층을 잰다)
# ══════════════════════════════════════════════════════════════════
#: 글 유형 → 사람 말 (2026-08-27 — 휴지통에 `VERS_PRAYER` 같은 코드가
#  그대로 뜨면 무엇인지 알 수 없다)
_TT_KO = {
    'VERS_DESC': ('OE_S_DESC_LAY', '구절 설명'),
    'VERS_QUESTION': ('OE_S_Q_LAY', '묵상질문'),
    'VERS_PRAYER': ('OE_S_PRAYER', '묵상기도'),
    'VERS_NOTE': ('TAB_NOTE', '묵상노트'),
    'CHAP_DESC': ('OE_S_CHAP', '장 설명문'),
    'PERI_DESC': ('DESC_MODE_PERI', '단락설명'),
    'VERS_VERS_DESC': ('OC_LINKDESC', '연결설명문'),
    'ENTITY_DESC': ('EBM_T_DESC', '용어 설명문'),
    'ENTITY_VERSE_DESC': ('OC_LINKDESC', '연결설명문'),
    'CONT_DESC': ('OE_S_CDESC', '렌즈 설명'),
    'CONT_NAME': ('OE_S_CNAME', '렌즈 이름'),
    'NODE_NAME': ('OE_S_NNAME', '노드 이름'),
    'NODE_DESC': ('OE_S_NDESC', '노드 설명'),
    'NODE_QUESTION': ('OE_S_NQ', '노드 묵상질문'),
    'NODE_PRAYER': ('OE_S_NP', '노드 묵상기도'),
    'NODE_VERS_DESC': ('OC_LINKDESC', '연결설명문'),
}


def kind_label(kind):
    """갈래 열쇠 → 사람 말. `LINK:VERSE` → 「구절 연결」 (2026-08-27)."""
    if str(kind).startswith('LINK:'):
        sub = kind.split(':', 1)[1]
        try:
            import link_picker as _LP
            return '%s %s' % (_LP.kind_name(sub),
                              i18n.t('TRASH_K_LINK', '연결'))
        except Exception:
            return i18n.t('TRASH_K_LINK', '연결')
    k = _KIND_LBL.get(kind)
    return i18n.t(k[0], k[1]) if k else str(kind)


def kinds_of(rows):
    """목록에 **실제로 있는** 갈래만 (없는 단추를 만들지 않는다)."""
    seen = []
    for r in rows:
        if r['kind'] not in seen:
            seen.append(r['kind'])
    # 연결 갈래를 앞에, 그 안에서는 이름순
    lk = sorted([k for k in seen if str(k).startswith('LINK:')])
    return tuple(lk + [k for k in seen if k not in lk])


def _tt_label(tt):
    k = _TT_KO.get(tt)
    return i18n.t(k[0], k[1]) if k else (tt or '')


def _asset_label(conn, tt, cid, lang='KO'):
    """그 글이 붙은 **자산의 이름** — 구절 약명·용어 이름·렌즈/노드 이름.

    ⚠ 유형마다 `clicked_id` 가 가리키는 것이 다르다(절 vid · 장 열쇠 ·
      엔티티 번호 · 유닛 번호 · 링크 번호) — 유형이 곧 해석 규칙이다.
    """
    try:
        if tt in ('VERS_DESC', 'VERS_QUESTION', 'VERS_PRAYER', 'VERS_NOTE'):
            return _vlabel(conn, cid, lang)
        if tt == 'CHAP_DESC':
            b, ch = divmod(int(cid), 1000)
            r = conn.execute('SELECT short_name FROM book_names '
                             'WHERE book_code=? AND UPPER(lang_code)=?',
                             (b, (lang or 'KO').upper())).fetchone()
            return '%s %d장' % ((r[0] if r else '#%d' % b), ch)
        if tt in ('ENTITY_DESC', 'ENTITY_VERSE_DESC'):
            # ★ 이름은 **조회 정본**에게 묻는다 — 직접 SQL 은 검사기가 잡는다
            #   (2026-08-27 이 자리에서 실제로 +1 로 걸렸다).
            import overlay_read as _orr
            info = _orr.entity(conn, cid, lang)
            if info and info.get('name'):
                return info['name']
        if tt in ('CONT_DESC', 'CONT_NAME', 'NODE_NAME',
                  'NODE_DESC', 'NODE_QUESTION',
                  'NODE_PRAYER'):
            for tbl, pk in (('sys_unit_asset', 'sys_unit_id'),
                            ('userdb.user_unit_asset', 'user_unit_id')):
                try:
                    r = conn.execute('SELECT unit_name_sid FROM %s WHERE %s=?'
                                     % (tbl, pk), (cid,)).fetchone()
                    if r and r[0]:
                        return r[0]
                except Exception:
                    pass
        if tt in ('VERS_VERS_DESC', 'NODE_VERS_DESC'):
            for tbl, pk, a, b2 in (
                    ('sys_link_asset', 'sys_link_id', 'clicked_id',
                     'target_id'),
                    ('userdb.user_link_asset', 'user_link_id', 'clicked_id',
                     'target_id')):
                try:
                    r = conn.execute('SELECT %s, %s FROM %s WHERE %s=?'
                                     % (a, b2, tbl, pk), (cid,)).fetchone()
                    if r:
                        return '%s ↔ %s' % (_vlabel(conn, r[0], lang),
                                            _vlabel(conn, r[1], lang))
                except Exception:
                    pass
    except Exception:
        pass
    return '#%s' % cid


def _vlabel(conn, vid, lang='KO'):
    try:
        import verse_ref
        r = conn.execute(
            'SELECT bn.short_name, bi.chapter, bi.verse FROM bible_index bi '
            'JOIN book_names bn ON bn.book_code = bi.bcode '
            'AND UPPER(bn.lang_code)=? WHERE bi.verse_id=?',
            ((lang or 'KO').upper(), vid)).fetchone()
        if r:
            return verse_ref.label(lang, r[0], r[1], r[2])
    except Exception:
        pass
    return '#%s' % vid


def fetch_rows(conn, lang='KO'):
    """숨긴 것 전부 → [{kind, rid, label, shade}] — shade=True 는 sys 가림."""
    out = []

    # ① 연결 — VERS_VERS 만 sys 매칭(가림) 판정이 뜻을 갖는다
    for r in conn.execute(
            "SELECT user_link_id, link_type, clicked_id, target_id, "
            "COALESCE(rel_code,''), COALESCE(end_id, target_id) "
            "FROM user_link_asset WHERE record_status='HIDE'"):
        rid, lt, a, b, rel, end = r
        shade = False
        if lt == 'VERS_VERS':
            shade = conn.execute(
                'SELECT 1 FROM sys_link_asset WHERE link_type=? AND '
                "clicked_id=? AND target_id=? AND COALESCE(rel_code,'')=? "
                'AND COALESCE(end_id, target_id)=? '
                "AND COALESCE(record_status,'LIVE')='LIVE'",
                (lt, a, b, rel, end)).fetchone() is not None
            lbl = '%s ↔ %s' % (_vlabel(conn, a, lang), _vlabel(conn, b, lang))
        else:
            # ★ 연결도 **이름으로** (2026-08-27 사용자 — 「제목 구절약명 등이
            #   없어서 식별하기 힘들다」). `link_picker` 가 갈래 이름·이름표를
            #   이미 안다 — 그 단일 소스를 쓴다(코드·번호를 다시 해석하지
            #   않는다). 못 읽으면 옛 표기로 떨어진다.
            try:
                import link_picker as _LP
                # ⚠ `split_lt` 은 **넉 자 코드**를 준다 — 종류 이름으로
                #   되바꿔야 `label_of` 가 읽는다(TAG 는 세 자, §81 함정).
                _a4, _b4 = _LP.split_lt(lt)
                ak = _LP.KIND_OF.get(_a4, _a4)
                bk = _LP.KIND_OF.get(_b4, _b4)
                lbl = '%s %s → %s %s' % (
                    _LP.kind_name(ak), _LP.label_of(conn, ak, a, None, lang),
                    _LP.kind_name(bk), _LP.label_of(conn, bk, b, end, lang))
            except Exception:
                lbl = '%s #%s → #%s' % (lt, a, b)
        # ★ 갈래를 **연결 대상 종류로** 가른다 (2026-08-27 사용자 —
        #   「구절연결 선택검색 하려는데 구절연결이 '연결'이라는 단어로
        #   분류된다」). `LINK` 한 덩어리면 구절연결만 골라 볼 수 없다.
        #   갈래 열쇠 = `LINK:<종류>`(예 LINK:VERSE) — 화면이 종류 이름으로
        #   단추를 만든다.
        _sub = 'LINK'
        try:
            import link_picker as _LP2
            _a4b, _b4b = _LP2.split_lt(lt)
            _ak2 = _LP2.KIND_OF.get(_a4b, _a4b)
            _bk2 = _LP2.KIND_OF.get(_b4b, _b4b)
            # 이 자산(구절 축)에서 본 **상대 종류**가 갈래다
            # ⚠⚠ **그 규칙만으로는 구절이 사라진다** (2026-08-31 사용자 신고
            #   「구절 4개의 연결이 가림되었다고 표시했다. 그런데 휴지통에
            #   **구절 분류 버튼이 없다**」). 실측 — `BUNT_VERS`(도서 편↔구절)는
            #   A 가 구절이 아니라 **A(도서 편)** 로 분류돼 「구절」 단추가
            #   아예 안 생겼다. 휴지통은 **앵커가 없는 화면**이라 「상대」를
            #   한쪽만 보고 정할 수 없다.
            # ⇒ **어느 쪽이든 구절이면 구절**이다. 사람이 찾을 때 「구절 연결을
            #   숨겼다」로 기억하지 「도서 편 연결」로 기억하지 않는다.
            _sub = 'LINK:%s' % (
                _bk2 if _ak2 == 'VERSE'
                else 'VERSE' if _bk2 == 'VERSE'
                else _ak2)
        except Exception:
            pass
        out.append({'kind': _sub, 'rid': rid, 'label': lbl, 'shade': shade})

    # ② 노트·글 — origin_key 있는 행 = 덮개(가림·EDIT 흔적)
    for r in conn.execute(
            "SELECT user_text_id, text_type, clicked_id, "
            "COALESCE(title, substr(COALESCE(contents,''), 1, 24)), origin_key "
            "FROM user_text_asset WHERE record_status='HIDE'"):
        rid, tt, cid, head, okey = r
        # ★ **무엇인지 알아보게** (2026-08-27 사용자 — 「휴지통에서는 제목
        #   구절약명 등이 없어서 식별하기 힘들다」). 세 조각을 늘 채운다:
        #   ① 자산 이름(구절 약명·용어 이름·렌즈 이름) ② 유형을 사람 말로
        #   ③ 글 앞머리. 없으면 「(내용 없음)」이라고 **말해 준다** —
        #   빈 칸은 고장으로 읽힌다.
        who = _asset_label(conn, tt, cid, lang)
        head = (head or '').replace('\n', ' ').strip()[:30]
        lbl = ' · '.join(x for x in (who, _tt_label(tt),
                                     head or i18n.t('TRASH_EMPTY',
                                                    '(내용 없음)'))
                         if x)
        out.append({'kind': 'NOTE', 'rid': rid, 'label': lbl,
                    'shade': okey is not None})

    # ③ 즐겨찾기
    for r in conn.execute(
            "SELECT fav_id, fav_type, COALESCE(label,'') FROM user_favorite "
            "WHERE record_status='HIDE'"):
        out.append({'kind': 'FAV', 'rid': r[0],
                    'label': '%s · %s' % (r[1], r[2]), 'shade': False})

    # ④ 연구자료
    for r in conn.execute(
            "SELECT ref_id, COALESCE(title,'(제목 없음)') FROM user_ref_asset "
            "WHERE record_status='HIDE'"):
        out.append({'kind': 'REF', 'rid': r[0], 'label': r[1], 'shade': False})

    # ⑤ 렌즈 (컨테이너만 — 노드·글은 My Lens cascade 가 함께 다룬다)
    for r in conn.execute(
            "SELECT user_unit_id, unit_name_sid FROM user_unit_asset "
            "WHERE record_status='HIDE' AND unit_type='CONTAINER'"):
        out.append({'kind': 'LENS', 'rid': r[0], 'label': r[1], 'shade': False})

    # ⑥ 태그 — origin_key 있는 행 = sys 태그를 가리거나 고친 것
    for r in conn.execute(
            "SELECT user_tag_id, COALESCE(tag_name_sid,''), origin_key "
            "FROM user_tag_asset WHERE record_status='HIDE'"):
        rid, name, okey = r
        if okey and not name:
            name = okey
        out.append({'kind': 'TAG', 'rid': rid, 'label': name,
                    'shade': okey is not None})

    # ⑦ 주요용어(엔티티) 가림 — user_entity_asset HIDE = 전부 덮개 가림
    for r in conn.execute(
            "SELECT user_entity_id, entity_code FROM user_entity_asset "
            "WHERE record_status='HIDE'"):
        rid, code = r
        nm = conn.execute(
            "SELECT contents FROM sys_text_asset t JOIN sys_entity_master e "
            "ON e.entity_id = t.clicked_id AND t.text_type='ENTITY_NAME' "
            "WHERE e.entity_code=? AND t.record_status='LIVE' "
            "ORDER BY CASE UPPER(t.lang_code) WHEN ? THEN 0 WHEN 'EN' THEN 1 "
            "ELSE 2 END LIMIT 1", (code, (lang or 'KO').upper())).fetchone()
        out.append({'kind': 'ENTITY', 'rid': rid,
                    'label': (nm[0] if nm else code), 'shade': True})

    # ⑧ 내 링크 가림 — `user_media_asset` HIDE (2026-08-30)
    #   ⚠ 이것이 없어서 **숨긴 내 링크를 되살릴 길이 없었다.**
    try:
        for rid, title, url in conn.execute(
                "SELECT user_media_id, COALESCE(title,''), COALESCE(url,'') "
                "  FROM userdb.user_media_asset WHERE record_status='HIDE'"):
            out.append({'kind': 'MEDIA', 'rid': rid,
                        'label': (title or url)[:60], 'shade': False})
    except Exception:
        pass
    return out


def _base_kind(kind):
    """`LINK:VERSE` → `LINK`. 갈래를 세분한 뒤 남은 함정 (2026-08-31).

    ⚠⚠ 2026-08-27 에 연결 갈래를 `LINK:<종류>` 로 **세분했는데** 복원·비우기
      두 문은 여전히 `LINK` 만 알고 있었다. 그래서 **연결을 되살리려 하면
      `KeyError: 'LINK:VERSE'`** 로 죽었다 — §ENTITY 누락(119차)과 같은 자리다.
      그때 만든 래칫은 `KINDS` 대조라 **동적 하위 갈래를 못 봤다.**
    ⇒ 접두를 벗기는 문을 **하나** 두고 두 함수가 그것만 쓴다.
    """
    k = str(kind or '')
    return k.split(':', 1)[0] if ':' in k else k


def restore_row(conn, kind, rid, db_path=None):
    """내 것 HIDE → LIVE. 렌즈는 My Lens cascade 복원을 그대로 쓴다."""
    kind = _base_kind(kind)
    if kind == 'LENS':
        import user_lens_manager
        user_lens_manager.LensView._restore_my_lens(
            SimpleNamespace(db_path=db_path or 'bible_master.db'), rid)
        return
    tbl, pk = {
        'LINK': ('user_link_asset', 'user_link_id'),
        'NOTE': ('user_text_asset', 'user_text_id'),
        'FAV': ('user_favorite', 'fav_id'),
        'REF': ('user_ref_asset', 'ref_id'),
        'TAG': ('user_tag_asset', 'user_tag_id'),
        # ⚠⚠ **`ENTITY` 가 빠져 있었다** (2026-08-30 실측) — `KINDS` 에는 있고
        #   `purge_row` 에도 있는데 **여기만** 없어서 [복원]을 누르면
        #   `KeyError: 'ENTITY'` 로 죽었다. 사용자 신고 「휴지통에서 복원해도
        #   에러」의 정체다. 오류도 화면에 안 보이고 그냥 안 됐다.
        #   ⇒ **세 표(KINDS·restore·purge)가 어긋나지 않는지 selftest 가 잰다.**
        'ENTITY': ('user_entity_asset', 'user_entity_id'),
        'MEDIA': ('userdb.user_media_asset', 'user_media_id'),
    }[kind]
    conn.execute("UPDATE %s SET record_status='LIVE' WHERE %s=?" % (tbl, pk),
                 (rid,))
    conn.commit()


def purge_row(conn, kind, rid, db_path=None):
    """물리 삭제 — 내 것 완전 삭제와 가림 해제(sys 부활)가 같은 동작이다.

    ⚠ 연구자료는 딸린 것(언어별 본문·연결·작업대)까지 지운다 — 남기면
      고아 행이 되고, ref_id 가 재사용되면 남의 글에 붙는다.
    ⚠ 갈래는 `LINK:VERSE` 처럼 세분돼 올 수 있다 — `_base_kind` 로 벗긴다.
    """
    kind = _base_kind(kind)
    if kind == 'LENS':
        import user_lens_manager
        user_lens_manager.LensView._purge_my_lens(
            SimpleNamespace(db_path=db_path or 'bible_master.db'), rid)
        return
    if kind == 'REF':
        conn.execute('DELETE FROM user_ref_text WHERE ref_id=?', (rid,))
        conn.execute('DELETE FROM user_ref_asset_link WHERE ref_id=?', (rid,))
        conn.execute('DELETE FROM user_ref_compose WHERE ref_id=?', (rid,))
        conn.execute('DELETE FROM user_ref_asset WHERE ref_id=?', (rid,))
        conn.commit()
        return
    tbl, pk = {
        'LINK': ('user_link_asset', 'user_link_id'),
        'NOTE': ('user_text_asset', 'user_text_id'),
        'FAV': ('user_favorite', 'fav_id'),
        'TAG': ('user_tag_asset', 'user_tag_id'),
        'ENTITY': ('user_entity_asset', 'user_entity_id'),
        'MEDIA': ('userdb.user_media_asset', 'user_media_id'),
    }[kind]
    conn.execute('DELETE FROM %s WHERE %s=?' % (tbl, pk), (rid,))
    conn.commit()


# ══════════════════════════════════════════════════════════════════
#  화면 — 설정 ▸ 휴지통 서브탭
# ══════════════════════════════════════════════════════════════════
def build_tab(nb, db_path, lang_getter=None):
    """설정 노트북에 「휴지통」 탭을 붙인다. (단추는 상단 — §0)"""
    _t = i18n.t
    lang_getter = lang_getter or (lambda: 'KO')
    f = ttk.Frame(nb)
    nb.add(f, text=' ' + _t('TRASH_TAB', '휴지통') + ' ')
    view = _TrashBody(f, db_path, lang_getter)
    view.pack(fill='both', expand=True)
    return f


class _TrashBody(ttk.Frame):
    def __init__(self, master, db_path, lang_getter):
        super().__init__(master)
        self.db_path = db_path
        self.lang_getter = lang_getter
        self._rows = {}                     # iid → row dict
        self._kind = 'ALL'
        _t = i18n.t

        # ── 동작 단추 줄 (상단 — §0) ─────────────────────────────
        bar = ttk.Frame(self)
        bar.pack(fill='x', padx=8, pady=(8, 2))
        self._b_restore = tk.Button(bar, text=_t('TRASH_RESTORE', '복원'),
                                    command=self._do_restore)
        self._b_purge = tk.Button(bar, text=_t('TRASH_PURGE', '완전 삭제'),
                                  command=self._do_purge)
        self._b_unshade = tk.Button(bar, text=_t('TRASH_UNSHADE', '다시 보이기'),
                                    command=self._do_unshade)
        b_refresh = tk.Button(bar, text=_t('TRASH_REFRESH', '새로 읽기'),
                              command=self.refresh)
        for b in (self._b_restore, self._b_purge, self._b_unshade, b_refresh):
            b.pack(side='left', padx=(0, 6))
        self._cnt = tk.Label(bar, text='')
        self._cnt.pack(side='right')

        tk.Label(self, anchor='w', justify='left',
                 text='ⓘ ' + _t('TRASH_HINT',
                                '자동으로 지우지 않습니다 — 완전 삭제는 여기서 직접. '
                                '「가림」은 기본 자산을 덮개로 숨긴 것이라, 해제하면 '
                                '기본 자산이 다시 보입니다.')).pack(
            fill='x', padx=10, pady=(0, 4))

        # ── 종류 필터 ────────────────────────────────────────────
        kf = ttk.Frame(self)
        kf.pack(fill='x', padx=8, pady=(0, 4))
        # ★ 단추는 **실제로 있는 갈래만** 만든다 (2026-08-27 — 연결을 종류로
        #   갈랐으므로 고정 목록으로는 못 그린다. 빈 서랍도 안 만든다).
        #   `refresh()` 가 목록을 읽은 뒤 다시 짓는다.
        self._kf = kf
        self._kbtns = {}

        # ── 목록 ────────────────────────────────────────────────
        cols = ('kind', 'mark', 'label')
        self._tv = ttk.Treeview(self, columns=cols, show='headings',
                                selectmode='extended',
                                style='Trash.Treeview')
        try:
            import theme_font
            theme_font.list_style('Trash.Treeview', self.db_path)
        except Exception:
            pass
        self._tv.heading('kind', text=_t('TRASH_C_KIND', '종류'))
        self._tv.heading('mark', text=_t('TRASH_C_MARK', '구분'))
        self._tv.heading('label', text=_t('TRASH_C_LABEL', '이름'))
        self._tv.column('kind', width=90, stretch=False)
        self._tv.column('mark', width=70, stretch=False)
        self._tv.column('label', width=460)
        sb = ttk.Scrollbar(self, orient='vertical', command=self._tv.yview)
        self._tv.configure(yscrollcommand=sb.set)
        self._tv.pack(side='left', fill='both', expand=True,
                      padx=(8, 0), pady=(0, 8))
        sb.pack(side='left', fill='y', pady=(0, 8))
        self._tv.bind('<<TreeviewSelect>>', lambda _e: self._sync_btns())
        self.refresh()

    # ── 데이터 ──────────────────────────────────────────────────
    def _conn(self):
        conn = appdb.connect(self.db_path)
        return conn

    def refresh(self):
        _t = i18n.t
        lang = self.lang_getter() if callable(self.lang_getter) else 'KO'
        try:
            conn = self._conn()
            try:
                rows = fetch_rows(conn, lang)
            finally:
                conn.close()
        except Exception as e:
            print('[trash] fetch error:', e)
            rows = []
        self._all = rows
        self._rebuild_kind_btns()
        self._fill()

    def _rebuild_kind_btns(self):
        _t = i18n.t
        for w in self._kf.winfo_children():
            w.destroy()
        self._kbtns = {}
        codes = ('ALL',) + kinds_of(self._all)
        if self._kind not in codes:
            self._kind = 'ALL'
        for code in codes:
            n = (len(self._all) if code == 'ALL'
                 else sum(1 for r in self._all if r['kind'] == code))
            txt = (_t('COMMON_ALL', '전체') if code == 'ALL'
                   else kind_label(code))
            b = tk.Button(self._kf, text='%s(%d)' % (txt, n), bd=1, padx=8,
                          relief='sunken' if code == self._kind else 'raised',
                          command=lambda c=code: self._set_kind(c))
            b.pack(side='left', padx=(0, 4))
            self._kbtns[code] = b

    def _fill(self):
        _t = i18n.t
        # ⚠ 태그 색은 그릴 때마다 역할로 (§36-5b — paint 는 태그를 못 본다)
        try:
            from ui_theme import C as _C
            self._tv.tag_configure('shade', foreground=_C('fg_dim'))
            self._tv.tag_configure('empty', foreground=_C('fg_dim'))
        except Exception:
            pass
        self._tv.delete(*self._tv.get_children())
        self._rows = {}
        shown = 0
        for i, r in enumerate(self._all):
            if self._kind != 'ALL' and r['kind'] != self._kind:
                continue
            mark = (_t('TRASH_SHADE', '숨김') if r['shade']
                    else _t('TRASH_MINE', '내 것'))
            iid = 'r%d' % i
            self._tv.insert('', 'end', iid=iid,
                            values=(kind_label(r['kind']), mark, r['label']),
                            tags=('shade',) if r['shade'] else ())
            self._rows[iid] = r
            shown += 1
        if shown == 0:
            self._tv.insert('', 'end', iid='empty', tags=('empty',),
                            values=('', '', _t('TRASH_EMPTY',
                                               '숨긴 것이 없습니다.')))
        self._cnt.config(text='%d' % shown)
        self._sync_btns()

    def _set_kind(self, code):
        self._kind = code
        for c, b in self._kbtns.items():
            b.config(relief='sunken' if c == code else 'raised')
        self._fill()

    # ── 동작 ────────────────────────────────────────────────────
    def _sel(self):
        return [self._rows[i] for i in self._tv.selection() if i in self._rows]

    def _sync_btns(self):
        sel = self._sel()
        mine = [r for r in sel if not r['shade']]
        shade = [r for r in sel if r['shade']]
        self._b_restore.config(state='normal' if mine else 'disabled')
        self._b_purge.config(state='normal' if mine else 'disabled')
        self._b_unshade.config(state='normal' if shade else 'disabled')

    def _apply(self, rows, fn):
        try:
            conn = self._conn()
            try:
                for r in rows:
                    fn(conn, r['kind'], r['rid'], self.db_path)
            finally:
                conn.close()
        except Exception as e:
            print('[trash] apply error:', e)
            messagebox.showerror(i18n.t('TRASH_TAB', '휴지통'), str(e))
        self.refresh()

    def _do_restore(self):
        rows = [r for r in self._sel() if not r['shade']]
        if rows:
            self._apply(rows, lambda c, k, i, d: restore_row(c, k, i, d))

    def _do_purge(self):
        _t = i18n.t
        rows = [r for r in self._sel() if not r['shade']]
        if not rows:
            return
        if not messagebox.askyesno(
                _t('TRASH_PURGE', '완전 삭제'),
                _t('TRASH_PURGE_Q',
                   '{n}건을 완전히 삭제합니다. 되돌릴 수 없습니다. 계속할까요?'
                   ).format(n=len(rows))):
            return
        self._apply(rows, lambda c, k, i, d: purge_row(c, k, i, d))

    def _do_unshade(self):
        _t = i18n.t
        rows = [r for r in self._sel() if r['shade']]
        if not rows:
            return
        if not messagebox.askyesno(
                _t('TRASH_UNSHADE', '다시 보이기'),
                _t('TRASH_UNSHADE_Q',
                   '{n}건의 가림을 해제합니다. 숨겼던 기본 자산이 다시 '
                   '보입니다. 계속할까요?').format(n=len(rows))):
            return
        self._apply(rows, lambda c, k, i, d: purge_row(c, k, i, d))


# ══════════════════════════════════════════════════════════════════
#  자가 검증 — 데이터 층 (가짜 DB, PK 이름은 실제와 같게 — 코드가
#  이름으로 참조하는 실측 칼럼들이라 weird 로 바꾸면 검사가 무의미해진다)
# ══════════════════════════════════════════════════════════════════
def selftest():
    import sqlite3
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got))

    db = sqlite3.connect(':memory:')
    db.execute('ATTACH DATABASE ":memory:" AS userdb')
    db.executescript('''
      CREATE TABLE sys_link_asset (x INTEGER PRIMARY KEY, link_type TEXT,
        clicked_id INT, target_id INT, rel_code TEXT, end_id INT,
        record_status TEXT);
      CREATE TABLE sys_text_asset (x INTEGER PRIMARY KEY, clicked_id INT,
        text_type TEXT, contents TEXT, lang_code TEXT, record_status TEXT);
      CREATE TABLE sys_entity_master (entity_id INTEGER PRIMARY KEY,
        entity_code TEXT, record_status TEXT);
      CREATE TABLE bible_index (verse_id INTEGER PRIMARY KEY, bcode INT,
        chapter INT, verse INT);
      CREATE TABLE book_names (book_code INT, lang_code TEXT, short_name TEXT);
      CREATE TABLE userdb.user_link_asset (user_link_id INTEGER PRIMARY KEY,
        link_type TEXT, clicked_id INT, target_id INT, rel_code TEXT,
        end_id INT, record_status TEXT);
      CREATE TABLE userdb.user_text_asset (user_text_id INTEGER PRIMARY KEY,
        text_type TEXT, clicked_id INT, title TEXT, contents TEXT,
        origin_key TEXT, record_status TEXT);
      CREATE TABLE userdb.user_favorite (fav_id INTEGER PRIMARY KEY,
        fav_type TEXT, label TEXT, record_status TEXT);
      CREATE TABLE userdb.user_ref_asset (ref_id INTEGER PRIMARY KEY,
        title TEXT, record_status TEXT);
      CREATE TABLE userdb.user_ref_text (ref_id INT);
      CREATE TABLE userdb.user_ref_asset_link (ref_id INT);
      CREATE TABLE userdb.user_ref_compose (ref_id INT);
      CREATE TABLE userdb.user_unit_asset (user_unit_id INTEGER PRIMARY KEY,
        unit_type TEXT, unit_name_sid TEXT, record_status TEXT);
      CREATE TABLE userdb.user_tag_asset (user_tag_id INTEGER PRIMARY KEY,
        tag_name_sid TEXT, origin_key TEXT, record_status TEXT);
      CREATE TABLE userdb.user_entity_asset (user_entity_id INTEGER PRIMARY
        KEY, entity_code TEXT, record_status TEXT);
    ''')
    # sys 쪽 — 가림 판정 재료
    db.execute("INSERT INTO sys_link_asset VALUES (1,'VERS_VERS',1,100,'PRG',"
               "NULL,'LIVE')")
    # user 쪽 — 가림 1(VERS_VERS sys 매칭) + 내 것 1(비매칭)
    db.execute("INSERT INTO userdb.user_link_asset VALUES "
               "(11,'VERS_VERS',1,100,'PRG',NULL,'HIDE')")
    db.execute("INSERT INTO userdb.user_link_asset VALUES "
               "(12,'UREF_VERS',5,7,NULL,NULL,'HIDE')")
    db.execute("INSERT INTO userdb.user_text_asset VALUES "
               "(21,'VERS_NOTE',3,NULL,'내 노트',NULL,'HIDE')")
    db.execute("INSERT INTO userdb.user_text_asset VALUES "
               "(22,'VERS_DESC',71,NULL,'덮개','VERS_DESC|71|KO|LAY','HIDE')")
    db.execute("INSERT INTO userdb.user_favorite VALUES (31,'VERSE','창1:1','HIDE')")
    db.execute("INSERT INTO userdb.user_ref_asset VALUES (41,'시험 글','HIDE')")
    db.execute("INSERT INTO userdb.user_ref_text VALUES (41)")
    db.execute("INSERT INTO userdb.user_unit_asset VALUES "
               "(51,'CONTAINER','내 렌즈','HIDE')")
    db.execute("INSERT INTO userdb.user_tag_asset VALUES "
               "(61,'내 태그',NULL,'HIDE')")
    db.execute("INSERT INTO userdb.user_tag_asset VALUES "
               "(62,'복음(내 이름)','P|TAG_GOSPEL','HIDE')")
    db.execute("INSERT INTO userdb.user_entity_asset VALUES "
               "(71,'P_DAVID','HIDE')")
    db.commit()

    rows = fetch_rows(db)
    t('전 종류 수집', len(rows) == 10, len(rows))
    shade = {(r['kind'], r['rid']) for r in rows if r['shade']}
    # ⚠ 갈래 열쇠가 `LINK` → `LINK:<종류>` 로 세분됐다(2026-08-27 사용자 —
    #   「구절연결이 '연결'이라는 단어로 분류된다」). 검사도 새 규칙으로.
    t('★ 가림 판정 — VERS_VERS 매칭·덮개 글·덮개 태그·엔티티',
      shade == {('LINK:VERSE', 11), ('NOTE', 22), ('TAG', 62),
                ('ENTITY', 71)}, shade)
    t('   갈래가 종류로 갈린다(구절 연결)',
      kind_label('LINK:VERSE').startswith('구절'), kind_label('LINK:VERSE'))
    t('   실제로 있는 갈래만 단추가 된다',
      'LINK:VERSE' in kinds_of(rows) and 'LINK' not in kinds_of(rows),
      kinds_of(rows))

    # 복원 — 내 것만
    restore_row(db, 'NOTE', 21)
    t('복원 → LIVE', db.execute(
        "SELECT record_status FROM userdb.user_text_asset WHERE "
        "user_text_id=21").fetchone()[0] == 'LIVE')

    # 완전 삭제 — 연구자료는 딸린 것까지
    purge_row(db, 'REF', 41)
    t('★ 연구자료 완전 삭제 = 딸린 표까지',
      db.execute('SELECT COUNT(*) FROM userdb.user_ref_asset').fetchone()[0] == 0
      and db.execute('SELECT COUNT(*) FROM userdb.user_ref_text'
                     ).fetchone()[0] == 0)

    # 가림 해제 = user 행 물리 삭제
    purge_row(db, 'ENTITY', 71)
    t('★ 가림 해제 = user 행 삭제', db.execute(
        'SELECT COUNT(*) FROM userdb.user_entity_asset').fetchone()[0] == 0)
    purge_row(db, 'LINK', 11)
    t('   연결 가림 해제도', db.execute(
        "SELECT COUNT(*) FROM userdb.user_link_asset WHERE user_link_id=11"
        ).fetchone()[0] == 0)

    db.close()
    # ★★ **세 표가 어긋나지 않는가** (2026-08-30 신설) — `KINDS` 에 있는데
    #   `restore_row`/`purge_row` 에 없으면 [복원]·[완전 삭제]가 **KeyError 로
    #   죽는다.** 실제로 `ENTITY` 가 restore 에만 빠져 있었고, 오류가 화면에
    #   안 보여 「그냥 안 된다」로 나타났다.
    import inspect as _insp
    _rs, _ps = _insp.getsource(restore_row), _insp.getsource(purge_row)
    _miss_r = [k for k in KINDS if ("'%s':" % k) not in _rs and k != 'LENS']
    _miss_p = [k for k in KINDS if ("'%s':" % k) not in _ps
               and k not in ('LENS', 'REF')]
    t('★ 갈래마다 [복원] 이 있다', not _miss_r, _miss_r)
    t('★ 갈래마다 [완전 삭제] 가 있다', not _miss_p, _miss_p)
    t('★ 갈래마다 이름이 있다',
      all(k in _KIND_LBL for k in KINDS),
      [k for k in KINDS if k not in _KIND_LBL])
    # ★★ **화면이 실제로 넘기는 갈래로 잰다** (2026-08-31 신설) — 위 세 검사는
    #   `KINDS` 만 봐서 **`LINK:VERSE` 같은 하위 갈래를 못 봤다.** 그래서
    #   연결을 되살리면 `KeyError: 'LINK:VERSE'` 로 죽는데도 11/11 이었다.
    #   ⇒ 잣대가 **모양(상수)이 아니라 실제로 오는 값**을 재게 한다.
    _sub = ('LINK:VERSE', 'LINK:ENTITY', 'LINK:BOOK_UNIT', 'NOTE')
    _bad = []
    for k in _sub:
        try:
            _base_kind(k)
            if _base_kind(k) not in ('LENS',):
                _rs2 = _insp.getsource(restore_row)
                if ("'%s':" % _base_kind(k)) not in _rs2:
                    _bad.append(k)
        except Exception:
            _bad.append(k)
    t('★ 하위 갈래(LINK:종류)도 복원된다', not _bad, _bad)
    t('★ 접두 벗기기', _base_kind('LINK:VERSE') == 'LINK'
      and _base_kind('NOTE') == 'NOTE')

    print('trash_view selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    sys.exit(0 if selftest() else 1)
