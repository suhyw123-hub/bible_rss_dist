# -*- coding: utf-8 -*-
"""db_entity_compare.py — **가까운 낱말** (영구 도구, §0-5 KEEP)

★★★ 2026-09-24 — **「헷갈리는 낱말」에서 「가까운 낱말」로 넓혔다**
    (1.txt 15번 · 사용자 「헷갈리는 낱말만 표시하는 것은 부족하다. **비슷한
    말, 반대말, 관련어**도 표시하면 좋겠다」).
    짝마다 **관계**를 적는다 — `CONFUSED` 헷갈리는 낱말 · `SIMILAR` 비슷한
    말 · `OPPOSITE` 반대말 · `RELATED` 관련어(`entity_relation.COMPARE`).
    ⚠ **칸을 새로 만들지 않았다** — `sys_link_asset.rel_code` 가 이미
      「무슨 관계인가」를 말하는 자리다. 옛 20짝은 `rel_code` 가 비어 있고
      **그 뜻이 실제로 `CONFUSED`** 라 읽을 때 그렇게 본다(지어내지 않는다).

무엇을 담나
    `entity.md` §「같아 보이지만 다른 낱말을 다루는 세 자리」의 **①번**이다.
    같은 언어 안에서 **가까운 두 엔티티**를 짝지어 두고, 어떻게 다른지를 적는다.
    토브 ↔ 야샤르 · 헤세드 ↔ 헨 처럼 둘 다 엔티티로 있는 경우다.

    ② 원문 언어가 다른 낱말은 「낱말 구절」 탭의 낱말별 버튼이 이미 한다.
    ③ 번역어(토브 ↔ 영어 good)는 붙일 절이 없어 설명문 안에 한 번 적고 끝낸다.
    **이 표는 ①만 담는다. 자리를 섞지 않는다.**

★ 한 짝이 한 행이고, **양쪽에서 다 보인다.**
    토브를 봐도 야샤르를 봐도 같은 줄이 뜬다. 방향마다 행을 따로 두면
    한쪽만 고쳐져 두 설명이 어긋난다 — 실제로 흔한 사고다.
    그래서 설명문은 **어느 쪽에서 읽어도 말이 되게** 쓴다:
      「토브는 쓸모와 아름다움까지 아우르고, 야샤르는 굽지 않고 곧다는 뜻이다.」  (O)
      「이것과 달리 저것은 …」                                                      (X)

쓰는 법
    python db_entity_compare.py --init
    python db_entity_compare.py --check <draft.json>
    python db_entity_compare.py --apply <draft.json>
    python db_entity_compare.py --list [--entity T_TOV]
    python db_entity_compare.py --selftest      ← 탐지력 확인. 결과 보고 전 의무.

초안 형식
    {"pairs": [
       {"a": "T_TOV", "b": "T_YASHAR", "rel": "SIMILAR",
        "notes": {"KO": "…", "EN": "…"}}
    ]}
    ⚠ `rel` 을 안 적으면 `CONFUSED`(지금까지의 뜻)로 들어간다.

⚠ 사용자가 쓴 비교문을 여기 섞지 않는다. sys 를 다시 적재하면 지워진다
  (entity.md §sys 데이터와 사용자 데이터). 사용자 것은 나중에 `user_entity_compare` 로.
"""
from __future__ import annotations
import argparse, io, json, os, re, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb

#: ★★ 2026-08-24 — **통합 표로 옮겼다**(`db_link_migrate.py`).
#   짝은 `sys_link_asset(link_type='ENTI_ENTI')` 한 행이고 설명문의 닻은
#   `sys_link_id` 다. 옛 표 `sys_entity_compare` 는 **되돌릴 수 있게 남아
#   있지만 아무도 읽지 않는다** — 고칠 때 그쪽을 건드리지 말 것.
TABLE     = 'sys_link_asset'
LINK_TYPE = 'ENTI_ENTI'
A_COL, B_COL, ID_COL = 'clicked_id', 'target_id', 'sys_link_id'
OLD_TABLE = 'sys_entity_compare'        # 옛 표 — 백업으로만 남는다
TEXT_TYPE = 'ENTITY_COMPARE_DESC'
MIN_NOTE  = 20          # 이보다 짧으면 「왜 다른지」가 아니라 꼬리표다
NEED_LANG = ('KO', 'EN')

#: 관계 어휘 — **`entity_relation` 이 단일 소스다**(여기 베끼지 않는다).
try:
    import entity_relation as _ER
    REL_KINDS   = _ER.COMPARE
    REL_DEFAULT = _ER.COMPARE_DEFAULT
except Exception:                                         # noqa: BLE001
    REL_KINDS, REL_DEFAULT = ('CONFUSED',), 'CONFUSED'


def rel_cond(alias=''):
    """이 갈래만 선택하는 조건 `(절, 인자)` — **`rel_code` 로 좁힌다.**

    ⚠⚠⚠ 좁히지 않으면 같은 `ENTI_ENTI` 자리에 사는 **인물·우상·민족 관계**가
      섞여 든다(§275차 ⑬ — 다윗의 목록에 요나단·사울·이새가 떴다).
    ⚠ `rel_code IS NULL` 도 잡는다 — 관계를 안 적은 옛 짝이 곧 `CONFUSED` 다.
    """
    p = (alias + '.') if alias else ''
    ph = ','.join('?' * len(REL_KINDS))
    return ('(%srel_code IN (%s) OR %srel_code IS NULL)' % (p, ph, p),
            list(REL_KINDS))


def rel_of(code):
    """저장값 → 관계 코드. 비었으면 `CONFUSED`(옛 행)."""
    c = (code or '').strip().upper()
    return c if c in REL_KINDS else REL_DEFAULT


def rel_name(conn, code, lang='KO'):
    """관계 이름 — `rel_vocab` 한 곳에서 온다(화면이 이름을 또 적지 않는다)."""
    try:
        import rel_vocab
        return rel_vocab.name(conn, LINK_TYPE, rel_of(code), (lang or 'KO').upper())
    except Exception:                                     # noqa: BLE001
        return rel_of(code)

#: 옛 표를 만드는 글 — **되돌릴 때만** 쓴다. 새로 만들지 않는다.
DDL = [
    """CREATE TABLE IF NOT EXISTS sys_entity_compare (
           compare_id    INTEGER PRIMARY KEY AUTOINCREMENT,
           entity_id     INTEGER NOT NULL,
           other_id      INTEGER NOT NULL,
           sort_order    INTEGER DEFAULT 0,
           record_status TEXT DEFAULT 'LIVE'
       )""",
    # ⚠ 짝을 **작은 번호 먼저**로 저장하기 때문에 이 하나로 양방향 중복이 다 막힌다.
    "CREATE UNIQUE INDEX IF NOT EXISTS ix_ecmp_pair"
    " ON sys_entity_compare(entity_id, other_id)",
]


def init(conn):
    """통합 표는 `db_link_unify.py` 가 맡는다 — 여기서는 세기만 한다.

    ⚠ 옛 표를 새로 만들지 않는다(빈 표가 되살아나면 「어느 쪽이 진짜인가」가 흐려진다).
    """
    return conn.execute("SELECT COUNT(*) FROM %s WHERE link_type=?"
                        % TABLE, (LINK_TYPE,)).fetchone()[0]


def _eid(conn, code):
    r = conn.execute("SELECT entity_id FROM sys_entity_master WHERE entity_code=?"
                     " AND COALESCE(record_status,'LIVE')='LIVE'", (code,)).fetchone()
    return r[0] if r else None


def _tokens(name):
    """이름에서 쓸 만한 낱말만. ⚠ 이름이 `Righteousness (tsedeq / dikaiosyne)` 처럼
    괄호·빗금을 달고 있어서, 공백으로만 자르면 `(tsedeq` 가 되어 영영 안 맞는다."""
    return [w for w in re.split(r'[^0-9A-Za-z가-힣]+', name or '') if len(w) >= 2]


def _mentions(note, name):
    low = (note or '').lower()
    return any(w.lower() in low for w in _tokens(name))


def _name(conn, eid, lang='KO'):
    r = conn.execute("SELECT contents FROM sys_text_asset WHERE clicked_id=?"
                     " AND text_type='ENTITY_NAME' AND UPPER(lang_code)=? LIMIT 1",
                     (eid, lang)).fetchone()
    return r[0] if r else str(eid)


# ── 검사 ──────────────────────────────────────────────────────────────
def check(conn, draft, need_all=True):
    """반환 (오류, 경고, 해석된 짝). 오류가 있으면 적재하지 않는다.

    `need_all` — `True` 면 **KO·EN 둘 다** 있어야 한다(적재 도구의 규칙).
    ⚠ 화면은 `False` 로 부른다 (2026-09-22 · 1.txt 9-4 사용자 「**KO EN만
      입력하는 것은 아니다. 다국어 모드로 완전히 바꾸어라**」) — 그때는
      **적어도 한 언어**면 되고, 길이·두 이름 규칙은 **쓴 언어마다** 그대로
      건다. 규칙을 푸는 것이 아니라 **언어 수를 안 못 박는 것**이다.
    """
    err, warn, out = [], [], []
    pairs = draft.get('pairs') or []
    if not pairs:
        err.append('pairs 가 비었다')
    seen = set()
    for i, p in enumerate(pairs):
        tag = 'pairs[%d] %s↔%s' % (i, p.get('a'), p.get('b'))
        a, b = (p.get('a') or '').strip(), (p.get('b') or '').strip()
        if not a or not b:
            err.append('%s: a·b 둘 다 있어야 한다' % tag); continue
        if a == b:
            err.append('%s: 자기 자신과는 견줄 수 없다' % tag); continue
        ea, eb = _eid(conn, a), _eid(conn, b)
        for code, eid in ((a, ea), (b, eb)):
            if eid is None:
                err.append('%s: 그런 엔티티가 없다 — %s' % (tag, code))
        if ea is None or eb is None:
            continue
        lo, hi = (ea, eb) if ea < eb else (eb, ea)
        if (lo, hi) in seen:
            err.append('%s: 같은 짝이 이 초안 안에서 두 번 나온다' % tag)
        seen.add((lo, hi))

        # ★ **관계** — 안 적으면 `CONFUSED`(지금까지의 뜻).
        #   ⚠ 모르는 값을 조용히 기본값으로 바꾸지 않는다 — 오타를 그대로
        #     `CONFUSED` 로 넣으면 사람은 반대말을 넣은 줄 안다(§0-1).
        rel = (p.get('rel') or REL_DEFAULT).strip().upper()
        if rel not in REL_KINDS:
            err.append('%s: rel 은 %s 중 하나 — %s'
                       % (tag, '·'.join(REL_KINDS), p.get('rel')))
            continue

        raw = p.get('notes') or {}
        # ⚠ 대문자로 바꾼 **뒤에** 검사하면 소문자를 영영 못 잡는다(자가 검사가 잡음).
        for lang in raw:
            if lang != lang.upper():
                err.append('%s: lang_code 는 대문자로 — %s' % (tag, lang))
        notes = {k.upper(): (v or '').strip() for k, v in raw.items()}
        want = NEED_LANG if need_all else tuple(
            lg for lg, v in notes.items() if (v or '').strip())
        if not want:
            err.append('%s: 설명문을 적어도 한 언어는 적어야 한다' % tag)
        for lang in want:
            n = notes.get(lang, '')
            if not n:
                err.append('%s: %s 설명문이 없다' % (tag, lang))
            elif len(n) < MIN_NOTE:
                err.append('%s[%s]: %d자 — 왜 다른지를 적어야 한다(%d자 미만)'
                           % (tag, lang, len(n), MIN_NOTE))
        # ⚠ 「이것/저것」 식으로 쓰면 반대쪽에서 읽을 때 누가 누군지 알 수 없다.
        #   양쪽에서 다 보이는 한 줄이므로 **이름을 적어야** 한다.
        # ⚠⚠ **언어마다 한 줄씩 내면 같은 말이 두 번 뜬다**(2026-09-22
        #   사용자 「설명이 **두번 반복**해서 팝업 표시된다」). 언어를 모아
        #   **한 줄**로 내고, **무엇을 어떻게 고치면 되는지**까지 적는다
        #   (§0-1 — 막기만 하고 길을 안 알려 주면 사람이 갇힌다).
        bad = []
        for lang, n in notes.items():
            if not n:
                continue
            na, nb = _name(conn, ea, lang), _name(conn, eb, lang)
            if sum(1 for nm in (na, nb) if _mentions(n, nm)) < 2:
                bad.append(lang)
        if bad:
            warn.append(
                '%s: %s 설명문에 **두 이름이 다 안 나옵니다**.%s'
                '이 글은 「%s」 쪽에서도 「%s」 쪽에서도 **같은 한 줄로 보입니다**.%s'
                '그래서 「이것과 달리 저것은」처럼 쓰면 반대쪽에서 누구 이야기인지 '
                '알 수 없습니다.%s'
                '고치는 법 — 한 문장 안에 **두 이름을 다 적으세요**. '
                '예) 「%s 는 …, %s 는 …」'
                % (tag, '·'.join(bad), chr(10),
                   _name(conn, ea, 'KO'), _name(conn, eb, 'KO'), chr(10),
                   chr(10), _name(conn, ea, 'KO'), _name(conn, eb, 'KO')))
        out.append((lo, hi, notes, p.get('sort_order', 0), rel))
    return err, warn, out


def apply(conn, pairs):
    """통합 표에 넣는다.

    ⚠⚠ **`ON CONFLICT(칸…)` 을 쓰지 않는다.** 그 문법은 **정확히 일치하는
      UNIQUE 인덱스**를 요구하는데, 통합 표의 유일 열쇠는 `COALESCE` 를 쓰는
      **부분 인덱스**(살아 있는 것만)라 칸 목록으로 못 가리킨다. 인덱스 모양이
      바뀔 때마다 이 SQL 이 깨지는 것도 좋지 않다.
      ⇒ **먼저 고쳐 보고 없으면 넣는다** — 인덱스 모양에 안 묶인다.
    ⚠ 짝은 **작은 번호 먼저**로 넣으므로 이 하나로 양방향 중복이 다 막힌다.
    """
    n_p = n_t = 0
    rc, ra = rel_cond()
    for p in pairs:
        # ⚠ 옛 초안·옛 호출부는 칸이 넷이다 — 다섯째가 없으면 기본값
        lo, hi, notes, order = p[:4]
        rel = rel_of(p[4] if len(p) > 4 else REL_DEFAULT)
        # ⚠⚠ **이 갈래만 고쳐야 한다** — 좁히지 않으면 같은 두 엔티티의
        #   **가족 관계 행**(FATHER…)을 붙들어 그 줄을 비교 짝으로 바꾼다.
        cur = conn.execute(
            "UPDATE %s SET sort_order=?, rel_code=?, record_status='LIVE'"
            " WHERE link_type=? AND %s=? AND %s=? AND %s"
            % (TABLE, A_COL, B_COL, rc),
            [order, rel, LINK_TYPE, lo, hi] + ra)
        if not cur.rowcount:
            conn.execute(
                "INSERT INTO %s(link_type, %s, %s, rel_code, sort_order, record_status)"
                " VALUES(?,?,?,?,?,'LIVE')"
                % (TABLE, A_COL, B_COL), (LINK_TYPE, lo, hi, rel, order))
        cid = conn.execute(
            'SELECT %s FROM %s WHERE link_type=? AND %s=? AND %s=? AND %s'
            % (ID_COL, TABLE, A_COL, B_COL, rc),
            [LINK_TYPE, lo, hi] + ra).fetchone()[0]
        n_p += 1
        for lang, note in notes.items():
            if not note:
                continue
            conn.execute("DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type=?"
                         " AND UPPER(lang_code)=?", (cid, TEXT_TYPE, lang))
            conn.execute("INSERT INTO sys_text_asset(clicked_id, text_type, lang_code,"
                         " contents, record_status) VALUES(?,?,?,?,'LIVE')",
                         (cid, TEXT_TYPE, lang, note))
            n_t += 1
    conn.commit()
    return n_p, n_t


def remove(conn, a_eid, b_eid):
    """그 짝을 **지운다 — 설명문까지**. 돌려주는 것 `(짝 수, 글 수)`.

    ★★★ 2026-09-22 (1.txt 9-4 사용자 「삭제했다. 삭제버튼 누르는데
      **「숨길까요?」**라고 묻는다. **관리자화면인데 이상하다**. … 그러면서
      **설명문은 남는다**고 한다. **도대체 무슨 말인지 모르겠다**」).
    ⚠⚠ 옛 동작은 짝만 `HIDE` 하고 설명문을 남겼다. 그래서 ① 지운 것 같은데
      다시 저장하면 **옛 글이 되살아나고** ② 안내문이 그 사실을 설명하려다
      더 헷갈리게 했다. ⇒ **짝과 글을 함께 지운다.**
    ⚠ 이것은 **관리자가 손으로 만든 한 줄**이고 배포 콘텐츠의 원본이 아니다 —
      사용자 자료를 지우는 것과 다르다(§222차의 「지우지 않는다」는 수집물
      이야기다).
    """
    # ⚠ **어느 방향으로 저장돼 있어도 찾는다** — `apply` 는 작은 번호를 먼저
    #   넣지만, 옛 자료나 손으로 넣은 행이 거꾸로일 수 있다. 방향 하나만 보면
    #   **지운 것 같은데 안 지워진다**(1.txt 9-4 사용자 「숨기기 자체도
    #   작동하지 않는것 같다」).
    lo, hi = (a_eid, b_eid) if a_eid < b_eid else (b_eid, a_eid)
    rc, ra = rel_cond()
    # ⚠⚠⚠ **갈래로 좁힌다** — 안 좁히면 같은 두 사람의 **가족 관계 행까지**
    #   지운다(다윗↔요나단은 FRIEND 이기도 하다). 2026-09-24 에 함께 잡았다.
    ids = [r[0] for r in conn.execute(
        'SELECT %s FROM %s WHERE link_type=? AND ((%s=? AND %s=?)'
        ' OR (%s=? AND %s=?)) AND %s'
        % (ID_COL, TABLE, A_COL, B_COL, A_COL, B_COL, rc),
        [LINK_TYPE, lo, hi, hi, lo] + ra).fetchall()]
    n_t = 0
    for cid in ids:
        cur = conn.execute(
            'DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type=?',
            (cid, TEXT_TYPE))
        n_t += cur.rowcount or 0
    cur = conn.execute(
        'DELETE FROM %s WHERE link_type=? AND ((%s=? AND %s=?)'
        ' OR (%s=? AND %s=?)) AND %s'
        % (TABLE, A_COL, B_COL, A_COL, B_COL, rc),
        [LINK_TYPE, lo, hi, hi, lo] + ra)
    conn.commit()
    return (cur.rowcount or 0), n_t


def langs_of(conn, a_eid, b_eid):
    """그 짝에 **글이 있는 언어** 목록 — 화면이 라벨에 쓴다."""
    lo, hi = (a_eid, b_eid) if a_eid < b_eid else (b_eid, a_eid)
    rc, ra = rel_cond()
    r = conn.execute(
        'SELECT %s FROM %s WHERE link_type=? AND ((%s=? AND %s=?)'
        ' OR (%s=? AND %s=?))'
        " AND COALESCE(record_status,'LIVE')='LIVE' AND %s"
        % (ID_COL, TABLE, A_COL, B_COL, A_COL, B_COL, rc),
        [LINK_TYPE, lo, hi, hi, lo] + ra).fetchone()
    if not r:
        return []
    return [x[0].upper() for x in conn.execute(
        'SELECT DISTINCT lang_code FROM sys_text_asset WHERE clicked_id=?'
        " AND text_type=? AND COALESCE(record_status,'LIVE')='LIVE'"
        ' ORDER BY lang_code', (r[0], TEXT_TYPE)).fetchall()]


def set_rel(conn, a_eid, b_eid, rel):
    """있는 짝의 **관계만** 바꾼다 — 설명문은 안 건드린다.

    ★ 화면이 콤보를 바꾼 그 자리에서 부른다. 관계를 고치려고 설명문을 다시
      쓰게 하면 아무도 안 고친다.
    """
    r = rel_of(rel)
    lo, hi = (a_eid, b_eid) if a_eid < b_eid else (b_eid, a_eid)
    rc, ra = rel_cond()
    cur = conn.execute(
        'UPDATE %s SET rel_code=? WHERE link_type=? AND ((%s=? AND %s=?)'
        ' OR (%s=? AND %s=?)) AND %s'
        % (TABLE, A_COL, B_COL, A_COL, B_COL, rc),
        [r, LINK_TYPE, lo, hi, hi, lo] + ra)
    conn.commit()
    return cur.rowcount or 0


def rel_at(conn, a_eid, b_eid):
    """그 짝의 지금 관계 — 없으면 `None`."""
    lo, hi = (a_eid, b_eid) if a_eid < b_eid else (b_eid, a_eid)
    rc, ra = rel_cond()
    r = conn.execute(
        'SELECT rel_code FROM %s WHERE link_type=? AND ((%s=? AND %s=?)'
        ' OR (%s=? AND %s=?)) AND %s'
        % (TABLE, A_COL, B_COL, A_COL, B_COL, rc),
        [LINK_TYPE, lo, hi, hi, lo] + ra).fetchone()
    return rel_of(r[0]) if r else None


def pair_id(conn, a_eid, b_eid):
    """그 짝의 `sys_link_id` — 없으면 `None`. 설명문 어댑터의 닻이다."""
    lo, hi = (a_eid, b_eid) if a_eid < b_eid else (b_eid, a_eid)
    rc, ra = rel_cond()
    r = conn.execute(
        'SELECT %s FROM %s WHERE link_type=? AND ((%s=? AND %s=?)'
        ' OR (%s=? AND %s=?))'
        " AND COALESCE(record_status,'LIVE')='LIVE' AND %s"
        % (ID_COL, TABLE, A_COL, B_COL, A_COL, B_COL, rc),
        [LINK_TYPE, lo, hi, hi, lo] + ra).fetchone()
    return r[0] if r else None


# ── 화면용 ────────────────────────────────────────────────────────────
def fetch(conn, entity_id, lang='KO', with_rel=False):
    """[(상대 entity_id, 상대 이름, 설명문)] — **양쪽 어디서 봐도 나온다.**

    `with_rel=True` 면 **네 칸**으로 준다 — `(…, 관계 코드)`.
    ⚠ 기본을 세 칸으로 둔 까닭 = 옛 호출부가 `for o, n, d in rows` 로 푼다.
      칸을 늘리면 그 자리에서 터진다.
    """
    rc, ra = rel_cond('c')
    try:
        rows = conn.execute(
            "SELECT c.%s,"
            "       CASE WHEN c.%s=? THEN c.%s ELSE c.%s END,"
            "       c.rel_code"
            "  FROM %s c"
            " WHERE c.link_type=? AND (c.%s=? OR c.%s=?)"
            "   AND COALESCE(c.record_status,'LIVE')='LIVE' AND %s"
            " ORDER BY c.sort_order, c.%s"
            % (ID_COL, A_COL, B_COL, A_COL, TABLE, A_COL, B_COL, rc, ID_COL),
            [entity_id, LINK_TYPE, entity_id, entity_id] + ra).fetchall()
    except Exception:
        return []
    out = []
    for cid, other, rel in rows:
        t = conn.execute(
            "SELECT contents FROM sys_text_asset WHERE clicked_id=? AND text_type=?"
            "   AND COALESCE(record_status,'LIVE')='LIVE'"
            " ORDER BY CASE WHEN UPPER(lang_code)=? THEN 0"
            "               WHEN UPPER(lang_code)='EN' THEN 1"
            "               WHEN UPPER(lang_code)='KO' THEN 2 ELSE 3 END LIMIT 1",
            (cid, TEXT_TYPE, (lang or 'KO').upper())).fetchone()
        if not t or not (t[0] or '').strip():
            continue          # 설명문 없는 짝은 보이지 않는다 — 이름만 있으면 쓸모가 없다
        row = (other, _name(conn, other, (lang or 'KO').upper()), t[0])
        out.append(row + (rel_of(rel),) if with_rel else row)
    return out


# ── 옛 짝을 관계값으로 옮긴다 ────────────────────────────────────────
def migrate(conn, do_apply=False):
    """`rel_code` 가 빈 짝을 `CONFUSED` 로 채운다(멱등).

    ★ **뜻을 바꾸는 것이 아니라 적는 것이다** — 그 20짝은 「헷갈리는 이웃
      낱말」로 만들어졌으므로 `CONFUSED` 가 그때의 뜻 그대로다.
    ⚠ 읽는 쪽은 `NULL` 도 `CONFUSED` 로 보므로 **안 옮겨도 화면은 같다** —
      옮기는 값은 「관계를 골라 적었다」와 「아직 안 적었다」를 가르는 것이다.
    """
    n = conn.execute(
        "SELECT COUNT(*) FROM %s WHERE link_type=? AND rel_code IS NULL"
        % TABLE, (LINK_TYPE,)).fetchone()[0]
    if do_apply and n:
        conn.execute("UPDATE %s SET rel_code=? WHERE link_type=? AND rel_code IS NULL"
                     % TABLE, (REL_DEFAULT, LINK_TYPE))
        conn.commit()
    return n


# ── 후보 뽑기 ────────────────────────────────────────────────────────
def suggest(conn, min_share=5, limit=300):
    """**가까운 낱말 후보** — 사람이 선택할 목록. 자동 등록하지 않는다.

    ★★★ 잣대 = **lift**(같은 절에 실제로 함께 나온 수 ÷ 우연히 함께 나올 수).
      ⚠⚠ **횟수만 세면 안 된다** — 실측 1위가 「말씀 ↔ 듣다 266회」였는데
        둘 다 수천 절에 나오는 흔한 낱말이라 **가깝다는 뜻이 아니다.**
        lift 로 바꾸니 1위가 「무르다(가알) ↔ 속량하다(파다) lift 21.8」이다.
    ★ **탐지력의 증거** — 손으로 만든 옛 짝(헤세드↔에메트 · 체데크↔미슈파트 ·
      아온↔페샤 · 가알↔파다)이 **lift 상위에 그대로 올라온다**. 사람이 고른
      것을 기계가 되찾았다는 뜻이다(`--suggest --keep-have` 로 확인한다).
    ⚠ 함께 나온다는 것은 **가깝다는 신호일 뿐** 무슨 관계인지(비슷한가·
      반대인가)는 말해 주지 않는다. 관계와 설명문은 사람이 적는다.
    ⚠ **기계 낱말(`subtype: LEX`)은 뺀다** — 훑기 목록에도 안 나오는 낱말이라
      화면에 쓸 자리가 없고, 10,892개라 짝이 수십만이 된다.
    """
    have = {(min(a, b), max(a, b)) for a, b in conn.execute(
        "SELECT %s, %s FROM %s WHERE link_type=?" % (A_COL, B_COL, TABLE),
        (LINK_TYPE,))}
    NOLEX = "COALESCE(m%s.json_detail,'') NOT LIKE '%%\"subtype\": \"LEX\"%%'"
    tot = conn.execute(
        'SELECT COUNT(DISTINCT verse_id) FROM sys_entity_verse').fetchone()[0]
    if not tot:
        return []
    n_of = dict(conn.execute(
        "SELECT v.entity_id, COUNT(DISTINCT v.verse_id)"
        "  FROM sys_entity_verse v"
        "  JOIN sys_entity_master m1 ON m1.entity_id=v.entity_id"
        " WHERE m1.entity_type='TERM'"
        "   AND COALESCE(m1.record_status,'LIVE')='LIVE' AND " + (NOLEX % '1') +
        " GROUP BY 1"))
    rows = conn.execute(
        "SELECT v1.entity_id, v2.entity_id, COUNT(*) n"
        "  FROM sys_entity_verse v1"
        "  JOIN sys_entity_verse v2"
        "    ON v2.verse_id=v1.verse_id AND v2.entity_id>v1.entity_id"
        "  JOIN sys_entity_master m1 ON m1.entity_id=v1.entity_id"
        "  JOIN sys_entity_master m2 ON m2.entity_id=v2.entity_id"
        " WHERE m1.entity_type='TERM' AND m2.entity_type='TERM'"
        "   AND COALESCE(m1.record_status,'LIVE')='LIVE'"
        "   AND COALESCE(m2.record_status,'LIVE')='LIVE'"
        "   AND " + (NOLEX % '1') + " AND " + (NOLEX % '2') +
        " GROUP BY 1,2 HAVING n>=?", (min_share,)).fetchall()
    out = []
    for a, b, n in rows:
        exp = n_of.get(a, 0) * n_of.get(b, 0) / float(tot)
        if exp <= 0:
            continue
        out.append((n / exp, n, a, b, (a, b) in have))
    out.sort(reverse=True)
    res = []
    for lift, n, a, b, mine in out:
        res.append((a, _name(conn, a), b, _name(conn, b), n, lift, mine))
        if len(res) >= limit:
            break
    return res

# ── 자가 검사 ─────────────────────────────────────────────────────────
def selftest(conn):
    """★ 의무. 검사기가 조용히 전부 통과시키는 일이 실제로 있었다(§18-9)."""
    print('db_entity_compare 자가 검증')
    init(conn)
    good = '토브는 쓸모와 아름다움까지 아우르고, 야샤르는 굽지 않고 곧다는 뜻이다.'
    goodE = 'Tov covers usefulness and beauty, while yashar means straight, not bent.'
    P = lambda **kw: {'pairs': [dict({'a': 'T_TOV', 'b': 'T_HESED',
                                      'notes': {'KO': good, 'EN': goodE}}, **kw)]}
    cases = [
        ('정상',            P(), 0),
        ('없는 엔티티',      P(b='T_NOSUCH'), 1),
        ('자기 자신',        P(b='T_TOV'), 1),
        ('KO 설명문 없음',   P(notes={'EN': goodE}), 1),
        ('EN 설명문 없음',   P(notes={'KO': good}), 1),
        ('너무 짧은 설명문', P(notes={'KO': '다르다', 'EN': 'different'}), 1),
        ('소문자 lang',      P(notes={'ko': good, 'EN': goodE}), 1),
        ('짝 중복', {'pairs': [
            {'a': 'T_TOV', 'b': 'T_HESED', 'notes': {'KO': good, 'EN': goodE}},
            {'a': 'T_HESED', 'b': 'T_TOV', 'notes': {'KO': good, 'EN': goodE}}]}, 1),
        ('pairs 빈 것',      {'pairs': []}, 1),
        # ★ 관계 — 넷 중 하나라야 한다. **오타를 기본값으로 삼키지 않는다**
        ('관계 SIMILAR',     P(rel='SIMILAR'), 0),
        ('관계 소문자도 받음', P(rel='opposite'), 0),
        ('관계 오타',        P(rel='ANTONYM'), 1),
    ]
    ok = True
    for name, draft, want in cases:
        err, _w, _o = check(conn, draft)
        hit = 1 if err else 0
        mark = 'OK ' if hit == want else 'X  '
        if hit != want:
            ok = False
        print('  %s%-16s 오류 %d건 %s' % (mark, name, len(err),
                                          ('· ' + err[0]) if err else ''))

    # 이름이 안 들어간 설명문은 **경고**로 잡는다(양쪽에서 읽히므로)
    _e, warn, _o = check(conn, P(notes={'KO': '이것과 저것은 서로 다른 낱말이라 쓰임이 갈린다.',
                                        'EN': 'This one and that one differ in usage a lot.'}))
    # ⚠ 경고 글을 사람 말로 고쳤다(2026-09-22) — **재는 쪽을 함께 고친다**.
    #   그리고 이제 **언어를 모아 한 줄**로 내므로 경고가 하나다.
    if any('두 이름이 다 안 나온다' in w or '두 이름이 다 안 나옵니다' in w
           for w in warn):
        print('  OK 이름 없는 설명문     · 경고 %d줄 (언어를 모아 한 줄)'
              % len(warn))
    else:
        print('  X  이름 없는 설명문을 안 잡는다'); ok = False

    # ★ 관계를 안 적으면 CONFUSED 가 붙는다
    _e, _w, o5 = check(conn, P())
    if o5 and len(o5[0]) == 5 and o5[0][4] == REL_DEFAULT:
        print('  OK 관계 기본값         · %s' % REL_DEFAULT)
    else:
        print('  X  관계 기본값이 없다 %r' % (o5[:1],)); ok = False
    _e, _w, o6 = check(conn, P(rel='opposite'))
    if o6 and o6[0][4] == 'OPPOSITE':
        print('  OK 관계 대문자로 굳는다')
    else:
        print('  X  관계 대문자 변환 %r' % (o6[:1],)); ok = False

    # 양방향 조회 — 넣은 방향과 반대쪽에서도 보여야 한다
    RID = (-101, -102)
    # ⚠ 음수 번호를 쓴다 — 진짜 엔티티와 안 부딪히고 뒤에서 반드시 지운다
    conn.execute('DELETE FROM %s WHERE link_type=? AND %s IN (?,?)'
                 % (TABLE, A_COL), (LINK_TYPE,) + RID)
    conn.execute("INSERT INTO %s(link_type, %s, %s, record_status)"
                 " VALUES(?,?,?,'LIVE')" % (TABLE, A_COL, B_COL),
                 (LINK_TYPE,) + RID)
    cid = conn.execute('SELECT %s FROM %s WHERE link_type=? AND %s=?'
                       % (ID_COL, TABLE, A_COL), (LINK_TYPE, RID[0])).fetchone()[0]
    conn.execute("INSERT INTO sys_text_asset(clicked_id, text_type, lang_code, contents,"
                 " record_status) VALUES(?,?, 'KO', ?, 'LIVE')", (cid, TEXT_TYPE, good))
    fwd, rev = fetch(conn, RID[0]), fetch(conn, RID[1])
    if len(fwd) == 1 and len(rev) == 1 and fwd[0][0] == RID[1] and rev[0][0] == RID[0]:
        print('  OK 양방향 조회        · 넣은 쪽 %d건 · 반대쪽 %d건' % (len(fwd), len(rev)))
    else:
        print('  X  반대쪽에서 안 보인다 (%d/%d)' % (len(fwd), len(rev))); ok = False
    # 설명문이 없으면 안 보인다
    conn.execute('DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type=?',
                 (cid, TEXT_TYPE))
    if fetch(conn, RID[0]):
        print('  X  설명문 없는 짝이 보인다'); ok = False
    else:
        print('  OK 설명문 없으면 숨김')
    # ★ 한 언어만으로도 만들 수 있다(1.txt 9-4 「KO EN만 입력하는 것은
    #   아니다」) — `need_all=False`. 길이·두 이름 규칙은 그대로 산다.
    one = {'RU': '헤세드 와 토브 는 서로 다른 낱말이라 쓰임이 갈린다 러시아어로 적은 글'}
    e1, _w, _o = check(conn, P(notes=one), need_all=False)
    e2, _w, _o = check(conn, P(notes=one), need_all=True)
    if not e1 and e2:
        print('  OK 한 언어만도 된다     · need_all=False 통과 · True 는 막힘')
    else:
        print('  X  한 언어 규칙이 틀렸다 %r / %r' % (e1[:1], e2[:1])); ok = False
    e3, _w, _o = check(conn, P(notes={'RU': '너무 짧다'}), need_all=False)
    if e3:
        print('  OK 짧으면 한 언어라도 막힌다')
    else:
        print('  X  짧은 글이 통과했다'); ok = False

    # ★★★ **같은 두 낱말에 가족 관계 행이 함께 있어도 안 건드린다**
    #   (2026-09-24 · 다윗↔요나단은 FRIEND 이기도 하다). 갈래로 안 좁히면
    #   `pair_id` 가 그 행을 집어 **가족 관계에 비교 설명문을 붙이고**,
    #   [삭제]가 **가족 관계를 지운다**.
    conn.execute("INSERT INTO %s(link_type, %s, %s, rel_code, record_status)"
                 " VALUES(?,?,?,'FATHER','LIVE')" % (TABLE, A_COL, B_COL),
                 (LINK_TYPE,) + RID)
    fam_id = conn.execute(
        "SELECT %s FROM %s WHERE link_type=? AND %s=? AND rel_code='FATHER'"
        % (ID_COL, TABLE, A_COL), (LINK_TYPE, RID[0])).fetchone()[0]
    # ⚠ **재료가 실제로 애매한가를 먼저 잰다** — 좁히지 않은 조회가 두 행을
    #   집어야 이 검사가 뜻을 갖는다(허수 검사 금지 §238차).
    amb = conn.execute(
        'SELECT COUNT(*) FROM %s WHERE link_type=? AND %s=? AND %s=?'
        % (TABLE, A_COL, B_COL), (LINK_TYPE,) + RID).fetchone()[0]
    if amb == 2:
        print('  OK   (재료 확인) 좁히지 않으면 두 행이 걸린다')
    else:
        print('  X  재료가 애매하지 않다 %r' % amb); ok = False
    if pair_id(conn, RID[0], RID[1]) == cid:
        print('  OK ★ 가족 행을 안 집는다  · pair_id 가 비교 짝을 선택한다')
    else:
        print('  X  pair_id 가 가족 행을 집었다 %r' % pair_id(conn, *RID)); ok = False
    # ★★ **가족 행에 옛 설명문이 잘못 붙어 있어도 목록에 안 뜬다**
    #   (§275차 ⑬ 다윗의 목록에 요나단이 뜨던 바로 그 꼴을 만들어 잰다)
    #   ⚠ 앞 검사가 비교 짝의 글을 지웠다 — 되살려 놓아야 「한 줄」을 잰다
    conn.execute("INSERT INTO sys_text_asset(clicked_id, text_type, lang_code,"
                 " contents, record_status) VALUES(?,?,'KO',?,'LIVE')",
                 (cid, TEXT_TYPE, good))
    conn.execute("INSERT INTO sys_text_asset(clicked_id, text_type, lang_code,"
                 " contents, record_status) VALUES(?,?,'KO',?,'LIVE')",
                 (fam_id, TEXT_TYPE, good))
    if len(fetch(conn, RID[0])) == 1:
        print('  OK ★ 목록에 가족 행이 안 섞인다 · 설명문이 붙어 있어도')
    else:
        print('  X  목록에 가족 행이 섞였다 %d줄' % len(fetch(conn, RID[0]))); ok = False
    conn.execute('DELETE FROM sys_text_asset WHERE clicked_id=? AND text_type=?',
                 (fam_id, TEXT_TYPE))

    # ★ **진짜 삭제** — 짝과 설명문이 함께 사라진다(1.txt 9-4).
    #   ⚠ 글은 바로 위에서 이미 되살렸다(두 번 넣으면 삭제 수가 2가 된다).
    if pair_id(conn, RID[0], RID[1]) != cid:
        print('  X  pair_id 가 틀렸다'); ok = False
    else:
        print('  OK pair_id')
    if langs_of(conn, RID[1], RID[0]) == ['KO']:
        print('  OK langs_of           · 방향을 안 가린다')
    else:
        print('  X  langs_of %r' % langs_of(conn, RID[1], RID[0])); ok = False
    # ★ 관계만 바꾸는 문 — 설명문을 안 건드린다
    if set_rel(conn, RID[1], RID[0], 'similar') == 1             and rel_at(conn, *RID) == 'SIMILAR':
        print('  OK set_rel/rel_at      · 방향을 안 가린다')
    else:
        print('  X  set_rel %r' % rel_at(conn, *RID)); ok = False

    np_, nt_ = remove(conn, RID[1], RID[0])       # 거꾸로 줘도 지워야 한다
    left_t = conn.execute('SELECT COUNT(*) FROM sys_text_asset WHERE '
                          'clicked_id=? AND text_type=?',
                          (cid, TEXT_TYPE)).fetchone()[0]
    if np_ == 1 and nt_ == 1 and left_t == 0:
        print('  OK ★ 진짜 삭제         · 짝 %d · 글 %d · 남은 글 0' % (np_, nt_))
    else:
        print('  X  삭제가 반쪽이다 %r %r %r' % (np_, nt_, left_t)); ok = False
    if conn.execute('SELECT COUNT(*) FROM %s WHERE %s=?' % (TABLE, ID_COL),
                    (fam_id,)).fetchone()[0] == 1:
        print('  OK ★ 삭제가 가족 행을 안 지운다')
    else:
        print('  X  삭제가 가족 행까지 지웠다'); ok = False

    # ★ apply 가 관계를 실제로 적는가 (그리고 fetch 가 그것을 돌려주는가)
    conn.execute('DELETE FROM %s WHERE link_type=? AND %s IN (?,?)'
                 % (TABLE, A_COL), (LINK_TYPE,) + RID)
    apply(conn, [(RID[0], RID[1], {'KO': good}, 0, 'OPPOSITE')])
    got = conn.execute("SELECT rel_code FROM %s WHERE link_type=? AND %s=?"
                       % (TABLE, A_COL), (LINK_TYPE, RID[0])).fetchone()
    f4 = fetch(conn, RID[1], with_rel=True)
    if got and got[0] == 'OPPOSITE' and f4 and len(f4[0]) == 4             and f4[0][3] == 'OPPOSITE':
        print('  OK ★ 관계가 저장되고 반대쪽에서도 읽힌다 · OPPOSITE')
    else:
        print('  X  관계 왕복 실패 %r %r' % (got, f4[:1])); ok = False
    if fetch(conn, RID[1]) and len(fetch(conn, RID[1])[0]) == 3:
        print('  OK 옛 호출부는 세 칸 그대로')
    else:
        print('  X  세 칸 계약이 깨졌다'); ok = False
    # ⚠ 옛 네 칸 호출부도 견딘다(기본값 CONFUSED)
    apply(conn, [(RID[0], RID[1], {'KO': good}, 0)])
    got2 = conn.execute("SELECT rel_code FROM %s WHERE link_type=? AND %s=?"
                        % (TABLE, A_COL), (LINK_TYPE, RID[0])).fetchone()
    if got2 and got2[0] == REL_DEFAULT:
        print('  OK 네 칸 옛 호출부도 견딘다 · %s' % REL_DEFAULT)
    else:
        print('  X  네 칸 호출부 %r' % (got2,)); ok = False
    remove(conn, *RID)

    conn.execute('DELETE FROM %s WHERE link_type=? AND %s IN (?,?)'
                 % (TABLE, A_COL), (LINK_TYPE,) + RID)
    conn.commit()
    # ⚠ 시험 잔재가 진짜로 사라졌는지 센다(§test-residue — 두 번 겪었다)
    left = conn.execute('SELECT COUNT(*) FROM %s WHERE %s IN (?,?)'
                        % (TABLE, A_COL), RID).fetchone()[0]
    if left:
        print('  X  시험 잔재 %d행이 남았다' % left); ok = False
    else:
        print('  OK 시험 잔재 0')

    print('\n  자가 검사 PASS' if ok else '\n  자가 검사 FAIL')
    return ok


# ── CLI ───────────────────────────────────────────────────────────────
def main():
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    ap = argparse.ArgumentParser()
    ap.add_argument('--init', action='store_true')
    ap.add_argument('--check'); ap.add_argument('--apply')
    ap.add_argument('--list', action='store_true')
    ap.add_argument('--entity')
    ap.add_argument('--selftest', action='store_true')
    ap.add_argument('--migrate', action='store_true',
                    help='관계를 안 적은 옛 짝을 CONFUSED 로 채운다')
    ap.add_argument('--suggest', action='store_true',
                    help='같은 절에 자주 함께 걸리는 짝 — **사람이 선택한다**')
    ap.add_argument('--min', type=int, default=5)
    ap.add_argument('--keep-have', action='store_true',
                    help='이미 걸린 짝도 함께 — **탐지력을 눈으로 보는 자리**')
    ap.add_argument('--limit', type=int, default=300)
    a = ap.parse_args()
    conn = appdb.connect()

    if a.selftest:
        sys.exit(0 if selftest(conn) else 1)
    if a.init:
        print('%s 준비 · 현재 %d행' % (TABLE, init(conn))); return
    if a.migrate:
        n = migrate(conn, do_apply=True)
        print('관계를 안 적은 옛 짝 %d개를 %s 로 적었다' % (n, REL_DEFAULT))
        return
    if a.suggest:
        rows = suggest(conn, a.min, a.limit)
        if not a.keep_have:
            rows = [r for r in rows if not r[6]]
        print('같은 절에 %d회 이상 함께 걸린 짝 %d개 — **lift 순 · 자동 등록하지'
              ' 않는다**%s' % (a.min, len(rows),
                              '' if a.keep_have else '  (이미 걸린 짝은 뺐다)'))
        for ea, na, eb, nb, n, lift, mine in rows:
            print('  lift %5.1f  %4d회  %-24s ↔ %-24s   (%d,%d)%s'
                  % (lift, n, na, nb, ea, eb, '  ← 이미 걸림' if mine else ''))
        return
    if a.list:
        init(conn)
        if a.entity:
            eid = _eid(conn, a.entity)
            if eid is None:
                print('그런 엔티티가 없다 — %s' % a.entity); return
            for other, nm, note, rel in fetch(conn, eid, with_rel=True):
                print('  [%-9s] %-22s %s'
                      % (rel_name(conn, rel), nm, note[:60]))
            return
        # ⚠ **갈래로 좁힌다** — 안 좁히면 인물·우상 관계까지 늘어놓는다
        rc, ra = rel_cond()
        for cid, ea, eb, rel in conn.execute(
                'SELECT %s, %s, %s, rel_code FROM %s WHERE link_type=?'
                " AND COALESCE(record_status,'LIVE')='LIVE' AND %s ORDER BY %s"
                % (ID_COL, A_COL, B_COL, TABLE, rc, ID_COL), [LINK_TYPE] + ra):
            print('  %6d  [%-9s] %-20s ↔ %-20s'
                  % (cid, rel_name(conn, rel), _name(conn, ea), _name(conn, eb)))
        return

    path = a.check or a.apply
    if not path:
        ap.print_help(); return
    draft = json.load(io.open(path, encoding='utf-8'))
    err, warn, pairs = check(conn, draft)
    for w in warn:
        print('  ! ' + w)
    for e in err:
        print('  X ' + e)
    if err:
        print('\n검증 FAIL — 오류 %d건' % len(err)); sys.exit(1)
    print('검증 PASS — 짝 %d개' % len(pairs))
    for lo, hi, notes, _o in pairs:
        print('  %-20s ↔ %-20s  설명문[%s]'
              % (_name(conn, lo), _name(conn, hi), ','.join(sorted(notes))))
    if a.apply:
        n_p, n_t = apply(conn, pairs)
        print('\n적재 완료 — 짝 %d개 · 설명문 %d행' % (n_p, n_t))


if __name__ == '__main__':
    main()
