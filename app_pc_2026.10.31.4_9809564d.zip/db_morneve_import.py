# -*- coding: utf-8 -*-
"""
db_morneve_import.py — 스펄전 『아침과 저녁』 전문 적재 (2026-08-22 신설 · 영구)
==============================================================================
`python db_morneve_import.py --selftest`   — 의무
`python db_morneve_import.py --fetch`      — 원문 내려받기 (`_morneve_raw/`)
`python db_morneve_import.py --check`      — 파싱만 해 보고 세어 본다
`python db_morneve_import.py --preview 1 366 732`  — 그 순번의 편을 보여 준다
`python db_morneve_import.py --apply [seq…]`       — 적재 (멱등)

━━ 왜 만들었나 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
★ **7편만 들어 있었다.** 2026-05 에 7일 플랜(plan 47)을 만들면서 1월 1~7일
  아침만 넣고 전문을 안 채웠다. 실측 — 유닛 7 · 본문 6,335자.
  진본은 **732편**(366일 × 아침·저녁, 2월 29일 포함) · 1.8MB.

★★ **기존 7편의 `unit_id` 를 지키는 것이 이 도구의 핵심이다.**
  묵상플랜 `SPURGEON_ME_7D`(plan 47)의 스케줄이 `unit_key='BOOK_<unit_id>'`
  로 그 일곱을 가리킨다. 새로 넣으면서 번호가 바뀌면 **등록해 둔 플랜이
  통째로 깨진다.** ⇒ `(book_id, sequence)` 로 찾아 **덮어쓴다**(§0-5 SW/AOG
  규약과 같다). 옛 7편은 1~7 이 January 1~7 **아침**이었는데, 전문은
  아침·저녁이 번갈아 오므로 **순번 뜻이 달라진다** — 아래 ⚠ 참조.

⚠⚠ **순번 규칙이 바뀐다.** 옛 배치는 `seq 1~7 = 1월 1~7일 아침`이고
  새 배치는 `seq 1,2 = 1월 1일 아침·저녁`이다. 그대로 덮으면 plan 47 의
  이레가 「1월 1일 아침·저녁 · 2일 아침·저녁 …」 3.5일치가 된다.
  ⇒ `--apply` 가 **plan 47 의 스케줄을 새 번호로 다시 가리키게 고친다**
  (1월 1~7일 **아침** = 새 seq 1,3,5,7,9,11,13). 안 고치면 조용히 어긋난다.

⚠ 소스 = CCEL(§0-1b 1순위 · 교정 텍스트). 원문은 `_morneve_raw/`(gitignore).
⚠ CCEL txt 는 **본문이 세 칸 들여쓰기**돼 있고 문단은 빈 줄로 갈린다.
  줄을 문단으로 되붙인다(도서 적재 공통 — §0-5 db_sw_grace_import).
"""
import io
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import appdb

RAW_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                       '_morneve_raw')
RAW = os.path.join(RAW_DIR, 'morneve.txt')
URL = 'https://ccel.org/ccel/spurgeon/morneve/cache/morneve.txt'

BOOK_CODE = 'SPURGEON_ME'
ATTRIB = '— C. H. Spurgeon, Morning and Evening (1866)'

# 옛 7편(= 1월 1~7일 **아침**)이 새 배치에서 갖는 순번
OLD7_NEW_SEQ = [1, 3, 5, 7, 9, 11, 13]

_HEAD = re.compile(r'^(Morning|Evening), ([A-Z][a-z]+) (\d{1,2})\s*$', re.M)
_SEP = '_' * 30
# ⚠⚠ **대소문자 무관으로 찾는다.** 732편 중 두 편(6/2 저녁 · 11/3 저녁)만
#   `Go to`(소문자 t)여서, 대문자로만 찾았더니 그 줄이 본문에 남고 **구절이
#   한 칸씩 밀렸다**(실측). Treasury 의 `<h1>` 대소문자 혼재와 같은 계열이다 —
#   **머리글·앵커 탐색은 언제나 `re.I`**.
_LINKLINE = re.compile(r'^\s*\[\d+\]\s*Go\s+To\s+(Morning|Evening)\s+Reading\s*$',
                       re.M | re.I)
_FOOTNOTE = re.compile(r'^\s*\[\d+\]\s*$', re.M)
_MONTHS = ('January', 'February', 'March', 'April', 'May', 'June', 'July',
           'August', 'September', 'October', 'November', 'December')


def fetch():
    """원문을 받는다. ⚠ 이 망에서 파이썬 urllib 은 CCEL SSL 검증이 실패한다 —
    `curl` 로 받는다(§0-5 db_psalms_pd_import 에서 겪은 것과 같다)."""
    import subprocess
    if not os.path.isdir(RAW_DIR):
        os.makedirs(RAW_DIR)
    r = subprocess.run(['curl', '-sL', '--max-time', '120', '-o', RAW, URL])
    ok = os.path.exists(RAW) and os.path.getsize(RAW) > 1000000
    print('%s %s (%d bytes)' % ('받음' if ok else '실패', RAW,
                                os.path.getsize(RAW) if os.path.exists(RAW) else 0))
    return ok


def _paras(block):
    """CCEL 들여쓰기 본문 → 문단 목록.

    ⚠ 줄바꿈을 그대로 두면 하드랩이 본문에 남는다. 빈 줄이 문단 경계다."""
    out = []
    for chunk in re.split(r'\n\s*\n', block):
        t = ' '.join(x.strip() for x in chunk.split('\n')).strip()
        if t:
            out.append(t)
    return out


def parse(raw=None):
    """[{seq, session, month, day, label, verse, ref, body}] — 732편."""
    s = raw if raw is not None else io.open(RAW, encoding='utf-8',
                                            errors='replace').read()
    heads = list(_HEAD.finditer(s))
    if not heads:
        return []
    # 꼬리(각주 URL 목록)를 자른다 — 마지막 편 뒤의 `file:///` 덩이
    tail = s.find('\nReferences\n', heads[-1].end())
    end_all = tail if tail > 0 else len(s)

    out = []
    for i, m in enumerate(heads):
        b0 = m.end()
        b1 = heads[i + 1].start() if i + 1 < len(heads) else end_all
        block = s[b0:b1]
        # 편 끝 구분선 잘라내기
        k = block.find(_SEP)
        if k >= 0:
            block = block[:k]
        block = _LINKLINE.sub('', block)
        block = _FOOTNOTE.sub('', block)
        ps = _paras(block)
        verse = ref = ''
        # 첫 문단이 따옴표로 시작하면 그것이 본문 구절, 그다음이 성경 참조
        if ps and ps[0].lstrip().startswith('"'):
            verse = ps.pop(0).strip()
        if ps and len(ps[0]) < 40 and re.search(r'\d', ps[0]):
            ref = ps.pop(0).strip()
        sess, mon, day = m.group(1), m.group(2), int(m.group(3))
        out.append({
            'seq': i + 1,
            'session': sess.upper(),          # MORNING / EVENING
            'month': mon, 'day': day,
            'label': '%s %d — %s' % (mon, day, sess),
            'verse': verse, 'ref': ref,
            'body': '\n'.join(ps).strip(),
        })
    return out


def body_text(e):
    """저장할 본문 — 구절·참조를 머리에 두고 끝에 출처(§17-8)."""
    parts = []
    if e['verse']:
        parts.append(e['verse'])
    if e['ref']:
        parts.append(e['ref'])
    parts.append(e['body'])
    parts.append(ATTRIB)
    return '\n\n'.join(x for x in parts if x)


def check(items):
    """세어 보고 이상한 것을 알린다. 돌려주는 것은 문제 목록."""
    bad = []
    if len(items) != 732:
        bad.append('편 수가 732 가 아니다: %d' % len(items))
    n_m = sum(1 for e in items if e['session'] == 'MORNING')
    if n_m != 366 or len(items) - n_m != 366:
        bad.append('아침 %d · 저녁 %d' % (n_m, len(items) - n_m))
    # 아침·저녁이 번갈아 오는가
    for i, e in enumerate(items):
        want = 'MORNING' if i % 2 == 0 else 'EVENING'
        if e['session'] != want:
            bad.append('순서가 어긋난다 seq %d: %s' % (e['seq'], e['session']))
            break
    # 달이 순서대로인가
    seen, order = [], 0
    for e in items:
        if not seen or seen[-1] != e['month']:
            seen.append(e['month'])
    if seen != list(_MONTHS):
        bad.append('달 순서: %s' % seen)
    # 빈 본문 · 구절 없음 · 꼬리 잔재
    for e in items:
        if len(e['body']) < 400:
            bad.append('본문이 너무 짧다 %s (%d자)' % (e['label'], len(e['body'])))
        if not e['verse']:
            bad.append('구절이 없다 %s' % e['label'])
        if 'file:///' in e['body'] or '____' in e['body']:
            bad.append('꼬리 잔재 %s' % e['label'])
    return bad


def apply(conn, items, only=None, dry=False):
    """적재 — `(book_id, sequence)` 로 덮어쓴다. `unit_id` 가 안 바뀐다."""
    bid = conn.execute("SELECT book_id FROM sys_book_asset WHERE book_code=?",
                       (BOOK_CODE,)).fetchone()
    if not bid:
        raise SystemExit('도서 %s 가 없다' % BOOK_CODE)
    bid = bid[0]
    n_new = n_upd = 0
    for e in items:
        if only and e['seq'] not in only:
            continue
        row = conn.execute("SELECT unit_id FROM sys_book_unit "
                           " WHERE book_id=? AND sequence=?",
                           (bid, e['seq'])).fetchone()
        txt = body_text(e)
        if row:
            uid = row[0]
            n_upd += 1
            if not dry:
                conn.execute(
                    "UPDATE sys_book_unit SET session_type=?, unit_label=?, "
                    "  key_verse_ref=?, record_status='LIVE' WHERE unit_id=?",
                    (e['session'], e['label'], e['ref'] or None, uid))
        else:
            n_new += 1
            if dry:
                continue
            cur = conn.execute(
                "INSERT INTO sys_book_unit"
                "(book_id, sequence, session_type, unit_label, key_verse_ref,"
                " record_status) VALUES(?,?,?,?,?,'LIVE')",
                (bid, e['seq'], e['session'], e['label'], e['ref'] or None))
            uid = cur.lastrowid
        if dry:
            continue
        t = conn.execute("SELECT text_id FROM sys_book_unit_text "
                         " WHERE unit_id=? AND text_variant='ORIGINAL'",
                         (uid,)).fetchone()
        if t:
            conn.execute("UPDATE sys_book_unit_text SET body_text=?, "
                         "  lang_code='EN', record_status='LIVE' "
                         " WHERE text_id=?", (txt, t[0]))
        else:
            conn.execute(
                "INSERT INTO sys_book_unit_text"
                "(unit_id, text_variant, lang_code, body_text, record_status) "
                "VALUES(?,'ORIGINAL','EN',?,'LIVE')", (uid, txt))
    if not dry:
        conn.commit()
    return n_new, n_upd


def fix_plan(conn, dry=False):
    """★ **7일 플랜이 계속 1월 1~7일 아침을 가리키게** 고친다.

    ⚠ 안 고치면 조용히 어긋난다 — 새 순번에서 seq 1~7 은 「1일 아침·저녁 ·
      2일 아침·저녁 …」 사흘 반이 된다. 실측으로 확인할 것."""
    bid = conn.execute("SELECT book_id FROM sys_book_asset WHERE book_code=?",
                       (BOOK_CODE,)).fetchone()[0]
    pid = conn.execute("SELECT plan_id FROM sys_bible_plan "
                       " WHERE plan_code='SPURGEON_ME_7D'").fetchone()
    if not pid:
        print('  (plan SPURGEON_ME_7D 없음 — 건너뜀)')
        return 0
    pid = pid[0]
    n = 0
    for day, seq in enumerate(OLD7_NEW_SEQ, start=1):
        u = conn.execute("SELECT unit_id FROM sys_book_unit "
                         " WHERE book_id=? AND sequence=?", (bid, seq)).fetchone()
        if not u:
            continue
        key = 'BOOK_%d' % u[0]
        cur = conn.execute(
            "UPDATE sys_plan_schedule SET unit_key=? "
            " WHERE plan_id=? AND day=? AND stage_type='BOOK_TEXT'",
            (key, pid, day))
        n += cur.rowcount
    if not dry:
        conn.commit()
    return n


# ── 자가 검증 ────────────────────────────────────────────────────────────
def _selftest():
    ok = True

    def chk(name, cond, extra=''):
        nonlocal ok
        print(('  PASS ' if cond else '  FAIL ') + name +
              (' ' + str(extra) if extra else ''))
        if not cond:
            ok = False

    # ① 파서 — **원문 없이도 도는지** 작은 표본으로 (데이터 상태에 안 건다)
    sample = (
        'Morning, January 1\n\n   [33]Go To Evening Reading\n\n'
        '   "They did eat of the fruit."\n\n  Joshua 5:12\n\n'
        '   ' + ('첫 문단. ' * 60) + '\n\n   ' + ('둘째 문단. ' * 60) + '\n'
        '     ' + _SEP + '\n\n'
        'Evening, January 1\n\n   [34]Go To Morning Reading\n\n'
        '   "We will be glad."\n\n  Song of Solomon 1:4\n\n'
        '   ' + ('저녁 문단. ' * 60) + '\n'
        '     ' + _SEP + '\n')
    it = parse(sample)
    chk('두 편으로 갈린다', len(it) == 2, len(it))
    chk('아침·저녁', [e['session'] for e in it] == ['MORNING', 'EVENING'],
        [e['session'] for e in it])
    chk('구절을 떼어 낸다', it[0]['verse'].startswith('"They did eat'),
        it[0]['verse'][:24])
    chk('성경 참조', it[0]['ref'] == 'Joshua 5:12', it[0]['ref'])
    chk('머리글은 본문에 안 남는다', 'Go To Evening' not in it[0]['body'])
    # ⚠ 대소문자 함정 — 실제 원문에 `Go to`(소문자) 두 편이 있었다
    low = parse(sample.replace('Go To', 'Go to'))
    chk('소문자 `Go to` 도 걸러낸다',
        low and low[0]['verse'].startswith('"They did eat'),
        low[0]['verse'][:20] if low else None)
    chk('구분선도 안 남는다', '___' not in it[0]['body'])
    chk('문단이 되붙는다', it[0]['body'].count('\n') == 1,
        it[0]['body'].count('\n'))
    chk('라벨', it[0]['label'] == 'January 1 — Morning', it[0]['label'])
    chk('출처가 끝에', body_text(it[0]).rstrip().endswith('(1866)'))

    # ② check 가 진짜로 잡는가 — 일부러 깨서 확인(탐지력 검사)
    bad = check(it)
    chk('732 가 아니면 잡는다', any('732' in b for b in bad), bad[:1])
    broken = [dict(it[0], body='짧다'), dict(it[1])]
    chk('짧은 본문을 잡는다',
        any('너무 짧다' in b for b in check(broken)))
    noverse = [dict(it[0], verse=''), dict(it[1])]
    chk('구절 없음을 잡는다', any('구절이 없다' in b for b in check(noverse)))

    # ③ 순번 매핑 — 1월 1~7일 아침
    chk('옛 7편 → 새 순번', OLD7_NEW_SEQ == [1, 3, 5, 7, 9, 11, 13])
    chk('그 순번이 전부 아침', all(x % 2 == 1 for x in OLD7_NEW_SEQ))

    # ④ 원문이 있으면 전량도 본다 (없어도 통과 — 데이터 상태에 안 건다)
    if os.path.exists(RAW):
        items = parse()
        chk('원문 732편', len(items) == 732, len(items))
        probs = check(items)
        chk('원문 검사 통과', not probs, probs[:3])
    else:
        print('  --   원문 없음 — 전량 검사 건너뜀 (--fetch 로 받는다)')

    # ⑤ 적재는 **트랜잭션으로 돌려 본다** (실 DB 를 안 건드린다)
    conn = appdb.connect()
    before = conn.execute(
        "SELECT COUNT(*) FROM sys_book_unit u JOIN sys_book_asset b "
        "  ON b.book_id=u.book_id WHERE b.book_code=?", (BOOK_CODE,)).fetchone()[0]
    n, u = apply(conn, it[:1], dry=True)
    after = conn.execute(
        "SELECT COUNT(*) FROM sys_book_unit u JOIN sys_book_asset b "
        "  ON b.book_id=u.book_id WHERE b.book_code=?", (BOOK_CODE,)).fetchone()[0]
    chk('미리보기는 DB 를 안 건드린다', before == after, '%d → %d' % (before, after))
    conn.close()
    print('RESULT:', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1


def main():
    args = sys.argv[1:]
    if '--selftest' in args:
        raise SystemExit(_selftest())
    if '--fetch' in args:
        raise SystemExit(0 if fetch() else 1)
    if not os.path.exists(RAW):
        raise SystemExit('원문이 없다 — `--fetch` 먼저')
    items = parse()
    if '--check' in args:
        print('편 %d개' % len(items))
        probs = check(items)
        if probs:
            print('!! 문제 %d건' % len(probs))
            for p in probs[:20]:
                print('   ', p)
        else:
            print('검사 통과')
        tot = sum(len(body_text(e)) for e in items)
        print('본문 합계 %s자 · 편당 평균 %d자' % (format(tot, ','),
                                          tot // max(1, len(items))))
        return
    if '--preview' in args:
        i = args.index('--preview')
        for a in args[i + 1:]:
            if not a.isdigit():
                break
            e = next((x for x in items if x['seq'] == int(a)), None)
            if not e:
                print('없음', a)
                continue
            print('=' * 66)
            print('seq %d · %s · %s' % (e['seq'], e['label'], e['session']))
            print('=' * 66)
            t = body_text(e)
            print(t[:1400] + ('\n…(이하 %d자)' % (len(t) - 1400)
                              if len(t) > 1400 else ''))
            print()
        return
    if '--apply' in args:
        i = args.index('--apply')
        only = {int(a) for a in args[i + 1:] if a.isdigit()} or None
        probs = check(items)
        if probs and not only:
            print('!! 검사에서 %d건 — 그대로 적재하지 않는다' % len(probs))
            for p in probs[:10]:
                print('   ', p)
            return
        conn = appdb.connect()
        n, u = apply(conn, items, only=only)
        print('새로 %d · 덮어씀 %d' % (n, u))
        if not only:
            k = fix_plan(conn)
            print('7일 플랜 스케줄 %d행 재지정' % k)
        conn.close()
        return
    print(__doc__)


if __name__ == '__main__':
    main()
