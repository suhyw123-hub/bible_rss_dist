# -*- coding: utf-8 -*-
"""엔티티 유형 — **코드 · 차례 · 다국어 이름의 단일 소스** (2026-09-22 신설).

★★★ 1.txt 9-1 사용자 「유형 콤보 : **한글 이름을 표시**」.
  ⚠⚠ 실측 — 같은 표가 **여섯 곳**에 베껴져 있었고 베낀 다섯은 전부
    7~9유형이라 NATION·DOCTRINE·TERM·PHASE 가 빠져 있었다. 그리고 관리자
    「용어/분류/연결」의 유형 콤보는 **코드를 그대로**(`PERSON`·`IDOL`)
    보이고 있었다 — 사용자가 되풀이 지적한 「암호같은 표현」 그 자리.
  ⇒ 여기 한 곳만 고치면 사용자 화면·관리자 화면이 함께 따라온다.

⚠ 유형을 늘릴 때 **`CODES` 와 `LABEL` 을 함께** 채운다 — `selftest` 가
  「모든 언어에 모든 유형이 있는가」를 잰다(하나라도 빠지면 그 언어에서
  코드가 그대로 보인다).

    python entity_types.py --selftest
"""
import sys


# 상단 유형 버튼이 늘어서는 차례 (2026-08-13 사용자 지정).
# ⚠ **이 목록 하나가 버튼 차례를 정한다** — 버튼은 `_rebuild_type_buttons` 가
#   여기서 그대로 만든다. 순서를 바꾸려면 여기만 고친다.
# ★★★ **`PHASE`(심리·국면) 신설**(2026-09-18 사용자 「A로 하자 · 용어
#   분류값에 하나 추가하고 주요용어 관리화면에서 모두 관리」). 사용자가 손으로
#   다는 말(불안·외로움·무기력)의 자리 — 옛 태그 축 열여섯 가운데 정말로
#   비어 있던 것이 이 하나였다(나머지는 `entity_type` 복제거나 다른 자산).
#   ⚠ **맨 뒤에 둔다** — 성경 안에 실재하는 것(인물·장소…)이 먼저다.
# ★★★ **`WORLDVIEW`(세계관·사조) 신설**(2026-09-24 · 1.txt 15번 · 사용자
#   「성경에 등장하지 않으나 … 기독교를 대적하는 사상들 … 분별할 수 있는
#   성경구절을 연결하고 싶다」).
#   ⚠ **`DOCTRINE` 에 안 섞는다** — 교리는 「고백해 온 것」이고 사조는
#     「분별해 온 것」이다. 한 단추에 두면 삼위일체와 포스트모더니즘이
#     훑기 목록에 나란히 선다.
CODES = ['PERSON', 'NATION', 'IDOL', 'GROUP', 'FEAST',
               'SYSTEM', 'PLACE', 'OBJECT', 'DOCTRINE', 'TERM', 'PHASE',
               'WORLDVIEW']
LABEL = {
    'KO': {'PERSON': '인물', 'PLACE': '장소', 'FEAST': '절기',
            'OBJECT': '사물', 'SYSTEM': '제도', 'GROUP': '그룹', 'NATION': '민족', 'IDOL': '우상', 'DOCTRINE': '교리', 'TERM': '용어', 'PHASE': '심리·국면', 'WORLDVIEW': '세계관'},
    'EN': {'PERSON': 'Person', 'PLACE': 'Place', 'FEAST': 'Feast',
            'OBJECT': 'Object', 'SYSTEM': 'System', 'GROUP': 'Group', 'NATION': 'Nation', 'IDOL': 'Idol', 'DOCTRINE': 'Doctrine', 'TERM': 'Term', 'PHASE': 'Inner life', 'WORLDVIEW': 'Worldview'},
    'ZH': {'PERSON': '人物', 'PLACE': '地名', 'FEAST': '节期',
            'OBJECT': '器物', 'SYSTEM': '制度', 'GROUP': '群体', 'NATION': '民族', 'IDOL': '偶像', 'DOCTRINE': '教义', 'TERM': '词语', 'PHASE': '心境', 'WORLDVIEW': '世界观'},
    'JA': {'PERSON': '人物', 'PLACE': '場所', 'FEAST': '祝祭',
            'OBJECT': '器物', 'SYSTEM': '制度', 'GROUP': 'グループ', 'NATION': '民族', 'IDOL': '偶像', 'DOCTRINE': '教義', 'TERM': '用語', 'PHASE': '心の状態', 'WORLDVIEW': '世界観'},
    'DE': {'PERSON': 'Person', 'PLACE': 'Ort', 'FEAST': 'Fest',
            'OBJECT': 'Objekt', 'SYSTEM': 'System', 'GROUP': 'Gruppe', 'NATION': 'Volk', 'IDOL': 'Götze', 'DOCTRINE': 'Lehre', 'TERM': 'Begriff', 'PHASE': 'Inneres', 'WORLDVIEW': 'Weltanschauung'},
    'FR': {'PERSON': 'Personne', 'PLACE': 'Lieu', 'FEAST': 'Fête',
            'OBJECT': 'Objet', 'SYSTEM': 'Système', 'GROUP': 'Groupe', 'NATION': 'Nation', 'IDOL': 'Idole', 'DOCTRINE': 'Doctrine', 'TERM': 'Terme', 'PHASE': 'Intérieur', 'WORLDVIEW': 'Courant de pensée'},
    'ES': {'PERSON': 'Persona', 'PLACE': 'Lugar', 'FEAST': 'Fiesta',
            'OBJECT': 'Objeto', 'SYSTEM': 'Sistema', 'GROUP': 'Grupo', 'NATION': 'Nación', 'IDOL': 'Ídolo', 'DOCTRINE': 'Doctrina', 'TERM': 'Término', 'PHASE': 'Interior', 'WORLDVIEW': 'Cosmovisión'},
    'AR': {'PERSON': 'شخص', 'PLACE': 'مكان', 'FEAST': 'عيد',
            'OBJECT': 'شيء', 'SYSTEM': 'نظام', 'GROUP': 'مجموعة', 'NATION': 'أمة', 'IDOL': 'صنم', 'DOCTRINE': 'عقيدة', 'TERM': 'مصطلح', 'PHASE': 'الحالة', 'WORLDVIEW': 'تيار فكري'},
    'RU': {'PERSON': 'Личность', 'PLACE': 'Место', 'FEAST': 'Праздник',
            'OBJECT': 'Предмет', 'SYSTEM': 'Система', 'GROUP': 'Группа', 'NATION': 'Народ', 'IDOL': 'Идол', 'DOCTRINE': 'Доктрина', 'TERM': 'Термин', 'PHASE': 'Чувства', 'WORLDVIEW': 'Мировоззрение'},
    'PT': {'PERSON': 'Pessoa', 'PLACE': 'Lugar', 'FEAST': 'Festa',
            'OBJECT': 'Objeto', 'SYSTEM': 'Sistema', 'GROUP': 'Grupo', 'NATION': 'Nação', 'IDOL': 'Ídolo', 'DOCTRINE': 'Doutrina', 'TERM': 'Termo', 'PHASE': 'Interior', 'WORLDVIEW': 'Cosmovisão'},
    # ⚠ **`ZHT`(번체)가 빠져 있어 번체 사용자만 영어를 봤다**(2026-09-24 실측).
    'ZHT': {'PERSON': '人物', 'PLACE': '地名', 'FEAST': '節期',
            'OBJECT': '器物', 'SYSTEM': '制度', 'GROUP': '群體', 'NATION': '民族',
            'IDOL': '偶像', 'DOCTRINE': '教義', 'TERM': '詞語', 'PHASE': '心境',
            'WORLDVIEW': '世界觀思潮'},
}
ALL_LABEL = {'KO': '전체', 'EN': 'All', 'ZH': '全部', 'ZHT': '全部', 'JA': '全て',
               'DE': 'Alle', 'FR': 'Tous', 'ES': 'Todos',
               'AR': 'الكل', 'RU': 'Все', 'PT': 'Todos'}


def codes(with_all=False):
    """유형 코드 차례. `with_all` 이면 맨 앞에 `'ALL'`."""
    return (['ALL'] if with_all else []) + list(CODES)


def label(code, lang='KO'):
    """그 유형의 이름. 모르면 **코드를 그대로** 낸다(조용히 비우지 않는다)."""
    c = str(code or '').upper()
    if c in ('ALL', '', 'NONE'):
        return ALL_LABEL.get((lang or 'KO').upper(), ALL_LABEL['EN'])
    tbl = LABEL.get((lang or 'KO').upper()) or LABEL['EN']
    return tbl.get(c) or LABEL['EN'].get(c) or c


def labels(lang='KO', with_all=False):
    """콤보에 넣을 이름 목록 — `codes()` 와 **같은 차례**."""
    return [label(c, lang) for c in codes(with_all)]


def of_label(name, lang='KO', with_all=False):
    """이름 → 코드. 못 찾으면 넘겨받은 값을 그대로(코드를 직접 넣는 길)."""
    for c in codes(with_all):
        if label(c, lang) == name:
            return c
    return name


def selftest():
    ok = fail = 0

    def t(nm, cond, extra=''):
        nonlocal ok, fail
        if cond:
            ok += 1
            print('  PASS  %s' % nm)
        else:
            fail += 1
            print('  FAIL  %s  %s' % (nm, extra))

    # ⚠⚠ **개수를 못 박지 않는다**(§0-5) — 유형을 하나 늘리자 그 자리에서
    #   깨졌다(2026-09-24 `WORLDVIEW`). 묻는 것은 「몇 개인가」가 아니라
    #   **「목록이 쓸 만한가」**다.
    t('유형이 비지 않았다', len(CODES) >= 1 and all(CODES), len(CODES))
    # ★ 언어 표가 `ui_langs()` 를 다 덮는가 — 빠진 언어는 조용히 영어로
    #   떨어져 **오류 없이** 그 언어 사용자만 코드를 본다(ZHT 가 그랬다).
    try:
        import lang_config
        miss_lg = [x for x in lang_config.ui_langs() if x not in LABEL]
        t('★ 언어 표가 앱 언어를 다 덮는다', not miss_lg, miss_lg)
    except Exception as e:                                    # noqa: BLE001
        print('  --    언어 목록 검사 건너뜀: %s' % e)
    t('코드가 안 겹친다', len(set(CODES)) == len(CODES))
    for lg, tbl in LABEL.items():
        miss = [c for c in CODES if c not in tbl]
        t('%s 에 빠진 유형 0' % lg, not miss, miss)
    t('모르는 코드는 그대로 낸다', label('ZZZ') == 'ZZZ')
    t('ALL 은 「전체」', label('ALL', 'KO') == '전체', label('ALL', 'KO'))
    t('이름 → 코드 왕복',
      all(of_label(label(c, 'KO'), 'KO') == c for c in CODES))
    t('차례가 같다', len(labels('KO', True)) == len(codes(True)))
    t('모르는 언어는 영어로', label('PERSON', 'XX') == 'Person')
    print('\nentity_types %d PASS · %d FAIL' % (ok, fail))
    return 0 if fail == 0 else 1


if __name__ == '__main__':
    sys.exit(selftest() if '--selftest' in sys.argv else selftest())
