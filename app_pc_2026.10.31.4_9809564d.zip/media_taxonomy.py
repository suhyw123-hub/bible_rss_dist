"""
media_taxonomy.py
-----------------
수집 미디어(sys_media_asset) 분류 3축 — 단일 진실 소스.
관리자 검토 패널 + 사용자 표시 패널이 모두 여기서 import 한다.

3축:
- 내용유형 (media_type 컬럼):  SERMON / STUDY / WORSHIP / FILM
- 형태유형 (format_type 컬럼): VIDEO / AUDIO / TEXT / ANIMATION
- 대상     (audience 컬럼):    GENERAL(전체) / KIDS(어린이) / SIGN(수화 — 2026-09-08)

제약(내용유형별 허용 형태):
- SERMON·STUDY : 전부
- WORSHIP      : VIDEO 만
- FILM         : VIDEO, ANIMATION

주의: COMMENTARY·WIKI·참조사이트(INTERLINEAR/LEXICON/WEB 등)는 다른 분류축(외부 참조)
이며 이 3축과 무관하다. 본 모듈은 수집 미디어에만 적용한다.
"""

CONTENT_TYPES  = ['SERMON', 'STUDY', 'WORSHIP', 'FILM', 'READING', 'SERVICE', 'PRAYER', 'SITE']
#: ★ SITE = 성지·유적 답사(2026-10-23 · 사용자 「답사영상 유형 작업도 진행하라」) — 성지순례·답사·성서고고학 영상. 믿음의 발자취
#:   장소 카드가 이 유형을 먼저 보인다. 유튜브 서브메뉴는 따로 없다(「말씀」 갈래 안 · 전체) — 수집 분야로 수백 편이 된 뒤에.
#: ★ PRAYER = 기도(2026-10-12 사용자 docs/3.txt · 「기도 유투브 채널 수집 — 다른 것들과 동일한 방식」) —
#:   기도문을 소리 내어 드리는 영상(아침·밤 기도 · 중보 · 치유 · 시편 기도). **기도에 관한 설교는 설교다.**
#:   찬양 수집기의 셋째 분야(`db_worship_collect.DOMAINS`)로 모으고 연결 심사를 거쳐 승인한다.
#: ★ SERVICE = 예배 실황(2026-10-10 찬양 점검 ⑤ · 사용자 「예배실황은 일단 독자적으로 분류」) —
#:   설교·기도·찬양이 섞인 예배 전체 생중계. **처음에는 숨긴다**(is_active=0 — 사용자 화면은
#:   승인분만 읽는다). 관리자 콤보에서만 보인다 · 사용자 화면 갈래(KV_KIND)는 아직 없다.
FORMAT_TYPES   = ['VIDEO', 'AUDIO', 'TEXT', 'ANIMATION']
AUDIENCE_TYPES = ['GENERAL', 'KIDS', 'SIGN']

# ─────────────────────────────────────────────────────────────────────────────
# 판 갈래(rendition kind) — **찬양 넷째 축** (2026-09-09 신설)
# ─────────────────────────────────────────────────────────────────────────────
#: 사용자 확정(2026-09-09) — 「**재가공을 제거하려고 하지 마라. 잠들기 전에 2시간
#:   연속듣기를 선호하는 사람들이 매우 많다.** 현재 구분한 갈래를 잘 관리하라.
#:   **성악, 반주, 악보, 가사영상, 워십댄스 모두 의미있는 분류값**으로 쓸 수 있다」.
#:
#: ★★★ **축이 넷째다** — 내용(`media_type`)·형태(`format_type`)·대상(`audience`)
#:   어디에도 안 들어간다. 이것은 **「그 곡을 어떻게 담았나」**이고 찬양에만 있다.
#:
#: ★★★ **갈래는 하나가 아니다 — 목록이다**(실측). 한 영상에 여럿이 겹친다:
#:   `Living Hope | 1 Hour | Piano Instrumental` = 연속듣기 + 반주 ·
#:   `[반주/가사]` = 반주 + 가사 · `악보-주 예수 나의 산 소망(10회반복)` = 악보 + 연속듣기.
#:   ⇒ **하나를 고르게 하면 반드시 한쪽을 잃는다.**
#:
#: ⚠⚠ **갈래어로 검색하면 안 된다**(실측) — 「새 일이 일어나네 악보 코드」로 찾으니
#:   우영우·빵빵이·일베가 왔다. 유튜브가 곡명을 흘려버린다.
#:   ⇒ **곡명으로 모으고 제목에서 갈래를 읽는다.** 갈래는 이미 제목에 적혀 있다.
#:
#: ⚠ 아무것도 안 걸리면 **빈 목록**이다 — 그것이 보통의 찬양 영상이다(억지로
#:   하나를 붙이지 않는다).
REND_KINDS = ('OFFICIAL', 'LIVE', 'LYRICS', 'PLAYLIST', 'INSTRUMENTAL',
              'SHEET', 'COVER', 'CHOIR', 'DANCE', 'AI_GEN')
#: ★ AI_GEN = **AI 로 만든 음악**(Suno 등 · 2026-10-10 사용자 「AI 생성음악도 포함하라.
#:   AI 분류값이 필요하다」) — 받되 **표시한다**. 「어떻게 담았나」라서 이 축이다.
#:   ⚠ 근거가 적힌 것만 붙인다(제목·설명문의 Suno·AI찬양 따위) — 짐작으로 채널 통째로 안 붙인다.

#: 갈래 이름(한국어) — 화면은 i18n 을 쓰고 이것은 코드 폴백이다.
REND_NAME_KO = {
    'OFFICIAL': '공식 음원', 'LIVE': '라이브', 'LYRICS': '가사 영상',
    'PLAYLIST': '연속듣기', 'INSTRUMENTAL': '반주', 'SHEET': '악보',
    'COVER': '연주 커버', 'CHOIR': '성악·합창', 'DANCE': '워십댄스',
    'AI_GEN': 'AI 생성',
}

#: ★★★ **곡의 장르** — 「어느 전통·양식의 찬양인가」 (2026-09-12 사용자 0.txt
#:   「찬양 장르 분류 — Messianic Praise · CCM · 전통찬송가 · Black Gospel · **???**」
#:   → 「**???는 네가 아이디어가 있으면 추가하라는 뜻**이다」).
#: ★★ **판이 아니라 곡에 붙는다** — 같은 곡의 한국어판도 메시아닉이다.
#:   `REND_KINDS`(공식음원·라이브·반주…)는 **어떻게 담았나**라서 축이 다르다.
#: ✅ **더한 둘은 실측으로 골랐다**(찬양 1,694편 제목에서 셌다 · 지어내지 않았다):
#:     CCM **293** · 전통찬송가 **285** · **워십 171** · **복음성가 64** ·
#:     soaking 33 · 트로트찬양 6 · 블랙 가스펠 3 · 메시아닉 1.
#:   ⓐ **워십(예배찬양)** — 실측 3위이고 CCM 과 실제로 갈린다(집회 인도 ↔ 음반).
#:   ⓑ **복음성가** — 한국 고유이고 CCM 이전 세대다.
#: ⚠ **안 넣은 것과 까닭** — 「태교·수면」 32편은 **용도**이지 장르가 아니고
#:   (분위기 축의 몫), 「클래식·성악」 13편은 `REND_KINDS.CHOIR` 와 겹친다.
#: ⚠ **트로트찬양(6)·soaking(33)은 후보로 남긴다** — 실체는 있으나 표본이 얇다.
#:   §Z-1s 와 같은 잣대 — **재고 나서 늘린다.**
#: ⚠ 모르면 **비워 둔다**(NULL) — 억지로 넣지 않는다.
SONG_GENRES = ('CCM', 'HYMN', 'WORSHIP', 'GOSPEL_SONG', 'MESSIANIC',
               'BLACK_GOSPEL')

#: 장르 이름(한국어) — 화면은 i18n 을 쓰고 이것은 코드 폴백이다.
SONG_GENRE_KO = {
    'CCM': 'CCM', 'HYMN': '전통찬송가', 'WORSHIP': '워십(예배찬양)',
    'GOSPEL_SONG': '복음성가', 'MESSIANIC': '메시아닉 찬양',
    'BLACK_GOSPEL': '블랙 가스펠',
}


def genre_label(code, lang='KO'):
    """장르 이름 — 모르는 코드는 **코드를 그대로** 돌려준다(조용히 안 비운다)."""
    return SONG_GENRE_KO.get(str(code or '').upper(), str(code or ''))


#: ★ 갈래 낱말 — **실측한 제목에서 모았다**(짐작이 아니다).
#:   `'*'` = 언어무관(라틴·기호 표기는 어느 언어 제목에도 온다).
#: ⚠ 낱말은 **짧을수록 위험하다** — `mr` 은 Mr. 에, `ar` 은 아무 데나 걸린다.
#:   그런 것은 **부호와 함께**(`ver.mr` · `(ar` · `[mr`) 적는다.
REND_KW = {
    'OFFICIAL': {
        '*': ['official music video', 'official video', 'official mv',
              'official audio', 'official lyric', 'officia', 'vevo',
              '官方', '官方歌詞版'],
        'KO': ['공식 음원', '공식음원', '뮤직비디오', '정규앨범'],
    },
    'LIVE': {
        '*': ['live worship', 'live at', '(live', '[live', 'live)', 'live]',
              'live session', 'concert', 'conference', '敬拜MV'],
        'KO': ['라이브', '실황', '현장예배', '콘서트', '집회', '예배실황'],
        'PT': ['ao vivo'], 'ES': ['en vivo'], 'DE': ['livemitschnitt'],
    },
    'LYRICS': {
        '*': ['lyrics', 'lyric video', 'with lyrics', 'sub español',
              'subtitulado', '歌詞版', '歌词版', '中英字幕'],
        'KO': ['가사', '자막'],
        'PT': ['letra'], 'ES': ['letra'], 'AR': ['كلمات'],
    },
    # ★ 사용자가 「매우 많다」고 한 갈래 — 잠들기 전 연속듣기
    'PLAYLIST': {
        '*': ['playlist', 'palylist', '1 hour', '2 hour', '3 hour', '8 hour',
              'nonstop', 'non-stop', 'compilation', 'lofi', 'lo-fi',
              'sleep', 'soaking'],
        'KO': ['연속듣기', '연속 듣기', '모음', '반복', '시간 찬양', '시간 연속',
               '곡 연속', '메들리', '수면', '잠들기', '자장', '플레이리스트'],
        'ZH': ['詩歌合輯', '诗歌合辑', '連續播放'],
    },
    'INSTRUMENTAL': {
        '*': ['instrumental', 'accompaniment', 'karaoke', 'backing track',
              # ⚠ `mr`·`ar` 은 홑낱말로 못 쓴다 — 부호와 함께 적는다
              'ver.mr', 'ver.ar', 'ver mr', 'ver ar',
              '(mr', '[mr', 'mr)', 'mr]', 'mr |', 'mr｜',
              '(ar', '[ar', 'ar)', 'ar]', 'ar |', 'ar｜',
              'minus one', 'no vocal', 'female key', 'male key', 'key of '],
        'KO': ['반주', '노래방', '무반주', '엠알'],
        'PT': ['playback'], 'ES': ['pista'],
    },
    'SHEET': {
        # ⚠⚠ **`tab` 홑낱말 금지** — 실측 `Tabernacles`·`Tablets`·`WORSHIP
        #   TABLE` 다섯 편을 먹었다(§228차 홑낱말 함정 그대로). 부호와 함께 적는다.
        '*': ['sheet music', 'sheet+', 'chord', 'chords', 'tutorial',
              'guitar tab', 'tabs)', 'tab)', 'tab]', '(tab', '[tab',
              'transcription', '樂譜', '乐谱', '简谱', '簡譜'],
        'KO': ['악보', '코드', '계이름', '연주법', '레슨'],
    },
    'COVER': {
        '*': ['cover', 'drum cam', 'drum cover', 'guitar cover', 'bass cover',
              'piano cover', 'violin cover', 'cam)', 'cam]', 'play through',
              'playthrough'],
        'KO': ['커버', '드럼', '기타', '베이스', '건반', '피아노 연주', '연주영상'],
        'PT': ['versão'],
    },
    'CHOIR': {
        '*': ['choir', 'chorale', 'a cappella', 'acappella', 'quartet',
              'soprano', 'tenor', 'ensemble', '合唱'],
        'KO': ['합창', '성악', '중창', '아카펠라', '성가대', '찬양대'],
    },
    'DANCE': {
        '*': ['choreography', 'choreo', 'worship dance', 'dance team',
              'mirrored', 'dance cover'],
        'KO': ['워십댄스', '율동', '안무', '거울모드', '워십 댄스'],
    },
    # ⚠ `ai music`·`ai worship` 홑낱말은 안 쓴다 — Hawaii music · Shanghai worship 을 먹는다
    'AI_GEN': {
        '*': ['suno', 'ai-generated', 'ai generated', 'ai cover)', '(ai cover',
              '[ai cover', '| ai worship', '| ai music', '#ai찬양', '#aimusic',
              '#aiworship', 'ai生成', 'ai 生成'],
        'KO': ['ai찬양', 'ai 찬양', 'ai생성', 'ai 생성', 'ai 작곡', 'ai 작사',
               'ai로 만든', 'ai로 제작', 'ai 음악', 'ai음악'],
    },
}


def rend_kw_for(kind, lang):
    """그 갈래의 낱말 — 언어무관 ∪ 그 언어."""
    m = REND_KW.get(kind, {})
    out = list(m.get('*', []))
    for w in m.get((lang or '').upper(), []):
        if w not in out:
            out.append(w)
    return out


# ─────────────────────────────────────────────────────────────────────────────
# 분위기(mood) · 반주 악기(instrument) — **다섯째·여섯째 축** (2026-09-10 신설)
# ─────────────────────────────────────────────────────────────────────────────
#: ★★★ **왜 새 축인가** — 내용(`media_type`)·형태(`format_type`)·대상
#:   (`audience`)·판 갈래(`rend_kind`) 어디에도 안 들어간다. 이것은 **「어떤
#:   기분으로 듣나」**와 **「무엇으로 연주했나」**이고, 사용자가 골라 듣는 축이다.
#: ⚠ **여럿이 정상이다** — 「잔잔한 피아노 찬양」은 CALM + PIANO 다.
#: ⚠ 아무것도 안 걸리면 **빈 목록** — 억지로 붙이지 않는다.
MOOD_KINDS = ('CALM', 'UPBEAT', 'WARM', 'OLD', 'NEW',
              'BLOOD', 'THANKS', 'COMFORT', 'SLEEP')
MOOD_NAME_KO = {
    'CALM': '잔잔한', 'UPBEAT': '신나는', 'WARM': '따뜻한', 'OLD': '옛 찬송',
    'NEW': '최신', 'BLOOD': '보혈', 'THANKS': '감사', 'COMFORT': '위로',
    'SLEEP': '잠들 때',
}
MOOD_KW = {
    'CALM': {'KO': ['잔잔한', '잔잔하게', '조용한', '차분한', '편안한', '고요한',
                    '평안한', '묵상하는'],
             '*': ['peaceful', 'calming', 'calm ', 'quiet ', 'gentle',
                   'restful', 'serene', 'tranquil']},
    'UPBEAT': {'KO': ['신나는', '경쾌한', '힘찬', '힘이 나는', '밝은'],
               '*': ['uplifting', 'upbeat', 'joyful', 'energetic', 'lively']},
    'WARM': {'KO': ['따뜻한', '정겨운', '포근한'],
             '*': ['heartwarming', 'warm ']},
    # ⚠ `old` 홑낱말은 `gold`·`hold` 에 걸린다 — **짝을 지어** 적는다.
    'OLD': {'KO': ['추억의', '옛날', '옛 찬송', '오래된', '7080', '흘러간'],
            '*': ['old hymns', 'classic hymns', 'timeless', 'golden oldies',
                  'traditional hymns', 'vintage hymn']},
    'NEW': {'KO': ['최신', '신곡', '새 노래', '새노래'],
            '*': ['new release', 'latest worship', 'brand new worship']},
    'BLOOD': {'KO': ['보혈', '십자가의 피', '예수의 피'],
              '*': ['blood of jesus', 'precious blood']},
    'THANKS': {'KO': ['감사찬양', '감사 찬양', '감사예배', '추수감사'],
               '*': ['thanksgiving', 'grateful heart', 'give thanks']},
    'COMFORT': {'KO': ['위로', '지칠 때', '지치고', '힘들 때', '힘들고',
                       '상처', '치유', '쉼이 되는'],
                '*': ['comfort', 'comforting', 'healing', 'weary', 'broken']},
    'SLEEP': {'KO': ['잠잘', '잠들', '잠 잘', '숙면', '수면', '자기 전',
                     '잠자며', '잠 오는'],
              '*': ['for sleep', 'bedtime', 'sleep music', 'deep sleep']},
}

#: 반주 악기 — **무엇으로 연주했나**. `rend_kind.INSTRUMENTAL` 을 더 가른다.
INST_KINDS = ('PIANO', 'GUITAR', 'SAX', 'ORGAN', 'STRING', 'SOAKING', 'MR')
INST_NAME_KO = {
    'PIANO': '피아노', 'GUITAR': '기타', 'SAX': '색소폰', 'ORGAN': '오르간',
    'STRING': '현악', 'SOAKING': '소킹', 'MR': '반주(MR)',
}
INST_KW = {
    'PIANO': {'KO': ['피아노'], '*': ['piano']},
    # ⚠⚠ 한국어 `기타` 는 **「기타 등등」**이다 — 반드시 짝을 지어 적는다.
    'GUITAR': {'KO': ['기타 연주', '기타로', '기타연주', '통기타'],
               '*': ['guitar', 'fingerstyle']},
    # ⚠ 라틴 `sax` 는 짧아 위험 — 온말로만.
    'SAX': {'KO': ['색소폰'], '*': ['saxophone']},
    'ORGAN': {'KO': ['오르간', '올갠'], '*': ['organ ']},
    'STRING': {'KO': ['바이올린', '첼로', '하프', '현악'],
               '*': ['violin', 'cello', 'harp ', 'strings']},
    'SOAKING': {'KO': ['소킹'], '*': ['soaking']},
    # ⚠ `mr` 홑낱말은 Mr. 에 걸린다(§233차) — 부호와 함께.
    'MR': {'KO': ['반주', 'mr]', '[mr', 'mr)', '(mr', '무반주 아님'],
           '*': ['instrumental', 'backing track', 'karaoke']},
}


#: ★★★ **목록이 데이터다** (2026-09-10 사용자 「타이틀이 나중에 분석결과 바뀔
#:   수도 있다」). `sys_config` 에 있는 것이 정본이고 위의 코드값은 **처음 값**이다.
#:   담기는 꼴 = `[{"code": "CALM", "name": "잔잔한", "kw": {"KO": [...], "*": [...]}}]`
#: ⚠⚠ **코드는 안 바꾼다 · 이름은 마음대로 바꾼다** — 영상에 적히는 것은 코드다.
MOOD_CFG_KEY = 'MEDIA_MOOD_KINDS'
INST_CFG_KEY = 'MEDIA_INST_KINDS'


def _axis_default(kinds, names, kws):
    return [{'code': k, 'name': names.get(k, k), 'kw': kws.get(k, {})}
            for k in kinds]


def _axis_load(db_path, key, kinds, names, kws):
    """`sys_config` 의 목록 → [{code,name,kw}]. 없거나 깨졌으면 처음 값."""
    import json as _json
    try:
        import appdb as _appdb
        conn = _appdb.connect(db_path or DB)
        try:
            row = conn.execute("SELECT config_val FROM sys_config"
                               " WHERE config_key=?", (key,)).fetchone()
        finally:
            conn.close()
        if row and row[0]:
            v = _json.loads(row[0])
            out = [x for x in v
                   if isinstance(x, dict) and str(x.get('code') or '').strip()]
            if out:
                return [{'code': str(x['code']).upper(),
                         'name': x.get('name') or x['code'],
                         'kw': x.get('kw') or {}} for x in out]
    except Exception:
        pass
    return _axis_default(kinds, names, kws)


def mood_list(db_path=None):
    """분위기 목록 → [{code,name,kw}] — **읽는 문 하나**."""
    return _axis_load(db_path, MOOD_CFG_KEY, MOOD_KINDS, MOOD_NAME_KO, MOOD_KW)


def inst_list(db_path=None):
    """반주 악기 목록 → [{code,name,kw}] — **읽는 문 하나**."""
    return _axis_load(db_path, INST_CFG_KEY, INST_KINDS, INST_NAME_KO, INST_KW)


def axis_save(db_path, key, items):
    """목록을 갈아 끼운다(관리자 화면이 부른다) → 담은 수.

    ⚠ **코드가 없는 줄은 안 담는다** · 코드는 대문자로 맞춘다.
    """
    import json as _json
    import appdb as _appdb
    keep = []
    for x in items or []:
        code = str((x or {}).get('code') or '').strip().upper()
        if not code:
            continue
        keep.append({'code': code, 'name': (x.get('name') or code),
                     'kw': x.get('kw') or {}})
    conn = _appdb.connect(db_path or DB)
    try:
        conn.execute("INSERT INTO sys_config(config_key, config_val)"
                     " VALUES(?,?) ON CONFLICT(config_key)"
                     " DO UPDATE SET config_val=excluded.config_val",
                     (key, _json.dumps(keep, ensure_ascii=False)))
        conn.commit()
    finally:
        conn.close()
    return len(keep)


def axis_name(items, code):
    """코드 → 이름. **모르는 코드는 코드 그대로**(지워도 안 죽는다)."""
    for x in items or []:
        if str(x.get('code')).upper() == str(code).upper():
            return x.get('name') or code
    return str(code)


def _kw2(table, kind, lang):
    d = table.get(kind) or {}
    out = list(d.get('*', []))
    if lang:
        out += d.get(str(lang).upper(), [])
    return [w.lower() for w in out if w]


def _axis_read(title, lang, items):
    low = (title or '').lower()
    if not low.strip():
        return []
    out = []
    for it in items:
        kw = it.get('kw') or {}
        words = [w.lower() for w in
                 (list(kw.get('*', []))
                  + (list(kw.get(str(lang).upper(), [])) if lang else []))
                 if w]
        for w in words:
            if w in low:
                out.append(it['code'])
                break
    return out


def moods(title, lang=None, db_path=None, items=None):
    """제목에서 **분위기**를 읽는다 → ['CALM', 'SLEEP'] 꼴.

    ⚠ 설명문은 안 본다 — 채널 안내에 형용사가 흔해 오탐이 는다.
    ⚠ `items` 를 주면 그것으로 읽는다 — 여러 편을 훑을 때 **한 번만 읽는다**.
    """
    return _axis_read(title, lang,
                      items if items is not None else mood_list(db_path))


def instruments(title, lang=None, db_path=None, items=None):
    """제목에서 **반주 악기**를 읽는다 → ['PIANO'] 꼴."""
    return _axis_read(title, lang,
                      items if items is not None else inst_list(db_path))


def rend_kinds(title, lang=None, desc=None):
    """제목(+설명문)에서 판 갈래를 읽는다 → ['PLAYLIST', 'INSTRUMENTAL'] 꼴.

    ★ **여럿이 정상이다** — 한 영상이 「1시간 반주」일 수 있다.
    ⚠ 아무것도 안 걸리면 **빈 목록**을 낸다(억지로 하나를 붙이지 않는다).
    ⚠ 설명문은 **주지 않는 것이 기본**이다 — 채널 안내·해시태그에 낱말이 흔해
      오탐이 는다. 제목이 갈래를 말하지 않으면 그 영상은 보통 찬양이다.
    """
    low = ((title or '') + (' ' + desc if desc else '')).lower()
    if not low.strip():
        return []
    out = []
    for kind in REND_KINDS:
        for w in rend_kw_for(kind, lang):
            if w in low:
                out.append(kind)
                break
    return out


# ─────────────────────────────────────────────────────────────────────────────
# 제목의 언어를 문자체계로 짐작한다 (2026-09-09 신설)
# ─────────────────────────────────────────────────────────────────────────────
#: ⚠⚠ **없어서 각자 짐작하고 있었다** — `db_song_collect` 가 「한글이 아니면 EN」
#:   으로 정해 **중국어 讚美之泉 제목 60여 편이 통째로 EN 으로** 들어갔다.
#:   ⇒ 짐작하는 자리가 여럿이면 갈린다. **한 문으로 모은다.**
#:
#: ★ 잣대는 **문자체계**다 — 번역기가 아니라 글자를 센다. 그것이 이 앱이 실제로
#:   필요한 정밀도다(§bidi 가 같은 잣대를 쓴다).
#: ⚠ **한글이 한 글자라도 있으면 KO** — 「십자가 The Cross」처럼 섞인 제목은
#:   한국어 사용자를 위한 것이다(사용자 확정 「한글과 영어를 섞어서 부른 경우도
#:   KO 로 분류한다. EN 은 순수하게 EN 만」).
#: ⚠ **번체·간체를 글자로 가른다** — 겹치는 글자가 많아 완벽하지 않다. 번체
#:   전용 글자가 보이면 ZHT, 아니면 ZH(§203차 — 수집기 `lang_code` 는 짐작이라
#:   번체 제목이 ZH 로 들어오는 일이 있다. 그것은 필터가 감당한다).
import unicodedata as _ud

#: 번체에만 쓰는 글자(간체에서 달라진 것) — 실측 찬양 제목에서 모았다
_ZHT_ONLY = set('個們來時後點國學會與這樣讓愛麼萬導對將營歡歲總聽讚為說話語誰'
                '書寫還進遠邊過與應該權興觀覺親變體點齊龍鳥馬魚鳴蟲聲聞聖業')

_HANGUL = (0xAC00, 0xD7A3)
_KANA = ((0x3040, 0x309F), (0x30A0, 0x30FF))
_CJK = ((0x4E00, 0x9FFF), (0x3400, 0x4DBF))
_ARABIC = ((0x0600, 0x06FF), (0x0750, 0x077F))
_CYRILLIC = (0x0400, 0x04FF)
_HEBREW = (0x0590, 0x05FF)
_GREEK = (0x0370, 0x03FF)


def _in(cp, rng):
    return rng[0] <= cp <= rng[1]


def guess_lang(text, default='EN'):
    """제목·설명문의 언어를 **문자체계로** 짐작한다 → 'KO'|'JA'|'ZH'|'ZHT'|…

    ★ 부르는 곳이 하나여야 갈리지 않는다 — 수집기마다 짐작하지 말 것.
    ⚠ 못 정하면 `default` 를 낸다(**지어내지 않는다** — 라틴 글자만 있으면
      영어인지 포르투갈어인지 글자로는 못 가른다).
    """
    if not text:
        return default
    han = kana = cjk = arab = cyr = heb = grk = 0
    zht = False
    for ch in text:
        cp = ord(ch)
        if _in(cp, _HANGUL):
            han += 1
        elif any(_in(cp, r) for r in _KANA):
            kana += 1
        elif any(_in(cp, r) for r in _CJK):
            cjk += 1
            if ch in _ZHT_ONLY:
                zht = True
        elif any(_in(cp, r) for r in _ARABIC):
            arab += 1
        elif _in(cp, _CYRILLIC):
            cyr += 1
        elif _in(cp, _HEBREW):
            heb += 1
        elif _in(cp, _GREEK):
            grk += 1
    # ★ 한글이 하나라도 있으면 KO (사용자 확정 — 섞인 제목은 한국어 사용자의 것)
    if han:
        return 'KO'
    # ⚠ 가나가 있으면 일본어 — 한자만으로는 중국어와 못 가른다
    if kana:
        return 'JA'
    if cjk:
        return 'ZHT' if zht else 'ZH'
    if arab:
        return 'AR'
    if cyr:
        return 'RU'
    if heb:
        return 'HE'
    if grk:
        return 'EL'
    return default


def set_rend_kind(conn, media_ids, code, on=None):
    """선택한 영상의 **판 갈래 하나**를 켜고 끈다 → (켠 수, 끈 수).

    `on=None` 이면 **줄마다 뒤집는다**(토글) · `True`/`False` 면 못 박는다.
    ⚠ 목록에 없는 갈래는 **거부한다** — 조용히 담으면 화면이 코드를 보인다.
    """
    import json as _js
    code = (code or '').strip().upper()
    if code not in REND_KINDS:
        return (0, 0)
    ids = [int(x) for x in (media_ids if isinstance(media_ids,
                                                    (list, tuple, set))
                            else [media_ids])]
    n_on = n_off = 0
    for mid in ids:
        r = conn.execute("SELECT COALESCE(description,'')"
                         "  FROM sys_media_asset WHERE media_id=?",
                         (mid,)).fetchone()  # status-ok: 번호 하나로 제 줄의 갈래를 읽는다
        raw = r[0] if r else ''
        try:
            d = _js.loads(raw) if raw.startswith('{') else {}
        except Exception:                                # noqa: BLE001
            d = {}
        got = list(d.get('rend_kind') or [])
        want = (code not in got) if on is None else bool(on)
        if want:
            if code in got:
                continue
            got.append(code)
            n_on += 1
        else:
            if code not in got:
                continue
            got = [x for x in got if x != code]
            n_off += 1
        if got:
            d['rend_kind'] = sorted(set(got))
        else:
            d.pop('rend_kind', None)
        conn.execute("UPDATE sys_media_asset SET description=?"
                     " WHERE media_id=?",
                     (_js.dumps(d, ensure_ascii=False), mid))
    return (n_on, n_off)


def rend_label(kinds, lang='KO'):
    """화면에 쓸 한 줄 — 「연속듣기 · 반주」. 없으면 빈 글자."""
    if not kinds:
        return ''
    return ' · '.join(REND_NAME_KO.get(k, k) for k in kinds)

# 내용유형별 허용 형태유형 (제약)
FORMAT_BY_CONTENT = {
    'SERMON':  ['VIDEO', 'AUDIO', 'TEXT', 'ANIMATION'],
    'STUDY':   ['VIDEO', 'AUDIO', 'TEXT', 'ANIMATION'],
    'WORSHIP': ['VIDEO'],
    'FILM':    ['VIDEO', 'ANIMATION'],
    'SERVICE': ['VIDEO'],
    'PRAYER':  ['VIDEO', 'AUDIO'],
    'SITE':    ['VIDEO'],
}

# 표시 라벨 (KO) — ★★★ **`media_type` 다섯 값의 이름은 여기 하나**(2026-09-16 19-3).
#   사용자 화면은 `content_label(code, lang)` 로 `ui_strings KV_KIND_*` 를 읽고
#   이 표는 그 **KO 폴백이자 관리자 이름표**다. 값이 P2 영상 유형 콤보·어린이
#   화면 라디오·목록 「유형」 칸과 **글자까지 같아야** 한다(옛 값 설교/강해/영상은
#   그 셋과 어긋났고 READING 이 없어 관리자가 따로 적었다).
#: ★★★ **사용자 화면 갈래 — 이 표가 단일 소스다**(2026-09-17 사용자 「모든 것을
#:   P4 상단 라디오 버튼으로 통일하라」). P4 온라인 영상 상단 라디오와 P2 영상
#:   갈래의 유형 거르개가 **같은 목록·같은 이름**을 쓴다.
#:   (코드, i18n 열쇠, 한국어, 걸리는 media_type 들, audience)
#:
#: ★★★ **설교·강해·성경공부를 「말씀」 하나로 합쳤다 — 실측이 그렇게 말한다.**
#:   ⓐ 제목만 읽는 분류기로는 못 가른다 — `Philippians 1`(성경공부) ↔
#:     `1 Samuel 19:1-24`(설교)가 구별되지 않는다.
#:   ⓑ **같은 채널이 두 갈래로 갈린다** — 성경공부 채널 413곳 중 **231곳(56%)**
#:     이 설교에도 있고, 그 채널들의 영상이 성경공부 1,189 ↔ 설교 3,415 다.
#:   ⓒ 큐티·묵상 낱말이 든 2,605편 중 **97%가 설교**에 있다 — 「성경공부」를
#:     눌러서는 찾을 수 없었다.
#:   ⓓ 수가 **18:1**(36,282 : 1,996)이라 성경공부 라디오는 5%만 보여 준다.
#: ⚠⚠ **DB 의 `media_type` 은 그대로 둔다**(사용자 확정) — 교회 설교 자동승인
#:   (`db_media_autoapprove.church_sermon_ids`)과 예배 실황 보관함이 `SERMON`
#:   을 잣대로 쓴다. **합치는 것은 화면이지 데이터가 아니다.**
USER_KINDS = (
    ('ALL',  'KV_KIND_ALL',  '전체',      (),                  None),
    ('WORD', 'KV_KIND_WORD', '말씀',      ('SERMON', 'STUDY', 'SITE'), None),  # ★ SITE(답사)도 말씀 갈래에(서브메뉴 없음 · 2026-10-23)
    ('READ', 'KV_V_READ',    '성경듣기',   ('READING',),        None),
    ('WOR',  'KV_V_WOR',     '찬양듣기',   ('WORSHIP',),        None),
    ('PRAY', 'KV_V_PRAY',    '기도',       ('PRAYER',),         None),
    ('FILM', 'KV_KIND_FILM', '영화·애니',  ('FILM',),           None),
    ('KIDS', 'KV_AUD_KIDS',  '어린이',     (),                  'KIDS'),
    ('SIGN', 'KV_AUD_SIGN',  '수화',       (),                  'SIGN'),
)
#: 라디오 줄에서 **구분선을 넣는 자리**(그 갈래 **뒤**) — 화면 둘이 함께 쓴다.
KIND_SEP_AFTER = ('READ', 'PRAY', 'SIGN')


def kind_cond(code):
    """갈래 코드 → (media_type 튜플, audience|None). 모르는 코드는 전체."""
    for c, _i, _ko, tys, aud in USER_KINDS:
        if c == code:
            return tuple(tys), aud
    return (), None


def kind_label(code):
    """갈래 이름 — 사용자 언어. **화면이 한국어를 직접 적지 않는다.**"""
    for c, ik, ko, _t, _a in USER_KINDS:
        if c == code:
            try:
                import i18n
                return i18n.t(ik, ko)
            except Exception:
                return ko
    return code


CONTENT_LABEL  = {'SERMON': '설교·강해', 'STUDY': '성경공부', 'WORSHIP': '찬양',
                  'FILM': '영화·애니', 'READING': '성경듣기',
                  'SERVICE': '예배 실황', 'PRAYER': '기도', 'SITE': '성지·유적 답사'}
FORMAT_LABEL   = {'VIDEO': '영상', 'AUDIO': '음성', 'TEXT': '텍스트', 'ANIMATION': '애니'}
AUDIENCE_LABEL = {'GENERAL': '전체', 'KIDS': '어린이', 'SIGN': '수화'}

DEFAULT_CONTENT  = 'SERMON'
DEFAULT_FORMAT   = 'VIDEO'
DEFAULT_AUDIENCE = 'GENERAL'

# 어린이(KIDS) 자동판별 기본 키워드 (제목/채널명 부분일치, 대소문자 무관).
# sys_config.config_key='MEDIA_CLASSIFY_KIDS_KW' 로 관리자 편집 가능(없으면 이 기본값).
DEFAULT_KIDS_KW = [
    # KO
    '어린이', '키즈', '유아', '만화', '애니', '동화', '슈퍼북', '성경동화',
    '어린이성경', '주일학교', '유년부', '유치부', '아동', '꼬마',
    # EN
    'kids', 'children', "children's", 'child', 'animated', 'animation',
    'cartoon', 'superbook', 'for kids', 'for children', 'toddler',
    'preschool', 'sunday school',
]


def flatten_kw(val):
    """낱말표가 **버킷 dict**(`{bucket:[kw]}`)이든 평면 목록이든 낱말 목록으로.

    ⚠⚠ **실제로 당했다**(2026-09-08) — sys_config 의 어린이 낱말표가 버킷 dict
      인데 `match_kids` 가 그것을 그대로 받아 **열쇠**('KO'·'DE'·'ES'…)를
      낱말로 훑었다. 「1 Korinther」의 `ko`, 「Die Wahre」의 `de` 가 어린이로
      찍혀 **KIDS 563건 중 443건이 거짓**이었다. 오류도 안 났다.
    """
    if isinstance(val, dict):
        out = []
        for b in val.values():
            out += list(b or [])
        return out
    return list(val or [])


def match_kids(text, kids_kw=None):
    """제목/채널명 등에 어린이 키워드가 있으면 True (부분일치, 대소문자 무관).

    ⚠ 버킷 dict 를 줘도 안전하다(`flatten_kw`) — 열쇠를 낱말로 읽지 않는다.
    """
    return match_kw(text, kids_kw or DEFAULT_KIDS_KW)


def match_kw(text, kw):
    """낱말 목록(또는 버킷 dict) 부분일치 — 대상(KIDS·SIGN) 판별의 단일 문."""
    if not text:
        return False
    low = str(text).lower()
    return any(str(k).lower() in low for k in flatten_kw(kw) if str(k).strip())


def channel_audience(audience, is_kids=0):
    """채널 행의 대상 — `audience` 칸이 먼저, 없으면 옛 `is_kids` 로.

    ★ 옛 칸을 안 지운다 — 옛 DB·옛 독자가 그것을 본다. 두 칸이 어긋나면
      **`audience` 가 이긴다**(새 칸이 정본).
    """
    a = (audience or '').strip().upper()
    if a in AUDIENCE_TYPES:
        return a
    return 'KIDS' if is_kids else DEFAULT_AUDIENCE


def allowed_formats(content):
    """내용유형에 허용된 형태유형 목록 (제약). 모르는 값은 전체 허용."""
    return FORMAT_BY_CONTENT.get(content, FORMAT_TYPES)


# ─────────────────────────────────────────────────────────────────────────────
# 분류 키워드 — 언어별 + 공통(COMMON) 버킷 모델 (2026-06-09)
# ─────────────────────────────────────────────────────────────────────────────
# 저장: sys_config[키] = JSON {bucket: [kw...]}.  bucket = 'COMMON' 또는 언어코드.
#   COMMON = 언어 무관 외래어·브랜드·약어(ccm·worship·ASMR·documentary…) — 모든 언어 콘텐츠에 적용
#   언어코드 = 그 언어 고유 표기(찬양·통독·다큐…)
# 분류 시 매칭 대상 = COMMON ∪ (미디어 lang_code 버킷).  ← 한국어 제목 속 영어 단어도 잡힘
# (언어코드에 맹목적으로 따르지 않음 — 실제 콘텐츠 표기 혼용 고려)
COMMON_BUCKET = 'COMMON'

# 카테고리 → sys_config 키
CLASSIFY_KW_KEYS = {
    'WORSHIP':   'MEDIA_CLASSIFY_WORSHIP_KW',
    'SERMON':    'MEDIA_CLASSIFY_SERMON_KW',
    'STUDY':     'MEDIA_CLASSIFY_STUDY_KW',
    'FILM':      'MEDIA_CLASSIFY_FILM_KW',
    # ★ 성경듣기 — 낭독·오디오바이블 (2026-09-10)
    'READING':   'MEDIA_CLASSIFY_READING_KW',
    # ★ 기도 — 기도문·기도회·중보기도 (2026-10-12)
    'PRAYER':    'MEDIA_CLASSIFY_PRAYER_KW',
    # ★ 성지·유적 답사 (2026-10-23)
    'SITE':      'MEDIA_CLASSIFY_SITE_KW',
    'ANIMATION': 'MEDIA_CLASSIFY_ANIMATION_KW',
    'AUDIO':     'MEDIA_CLASSIFY_AUDIO_KW',
    'KIDS':      'MEDIA_CLASSIFY_KIDS_KW',
    'SIGN':      'MEDIA_CLASSIFY_SIGN_KW',
}
CONTENT_KW_CATS = ['SERMON', 'WORSHIP', 'STUDY', 'FILM', 'READING', 'PRAYER', 'SITE']   # media_type 결정
FORMAT_KW_CATS  = ['ANIMATION', 'AUDIO']                    # format_type 결정(나머지 VIDEO)
#: 대상(audience) 결정 — 차례가 우선순위(수화가 더 좁은 판정이라 먼저)
AUDIENCE_KW_CATS = ['SIGN', 'KIDS']

# 언어별 기본 키워드 {category: {bucket: [kw]}} — COMMON(외래어/브랜드) + 각 언어
#
# ★★ **11개 언어를 다 채웠다**(2026-09-06 사용자 지시 「키워드 규칙 : **다국어로
#   번역**하라」). 그전에는 COMMON + KO 둘뿐이라 **아홉 언어에서 분류가 한 번도
#   안 걸렸고**, 안 걸리면 `classify_content` 가 기본값 SERMON 을 준다 —
#   실측 SERMON 96%가 그래서 나온 숫자다(진짜 96%가 설교인 것이 아니다).
# ⚠ **EN 버킷을 따로 두지 않는다** — COMMON 이 이미 영어 낱말을 담고 있고
#   COMMON 은 모든 언어에 걸리므로 EN 을 만들면 두 벌이 된다.
# ⚠ **COMMON 이 이미 잡는 말은 안 적는다** — 매칭이 부분일치라
#   `film` 하나가 독일어 Film·프랑스어 film·포르투갈어 filme 를 함께 잡는다.
#   적을 것은 **그 언어에서만 쓰는 표기**다(Kurzfilm · película · وثائقي).
# ⚠ 분류는 **거르는 말과 잣대가 다르다** — 여기서 틀리면 이름표가 틀릴 뿐이라
#   `media_exclude` 만큼 인색하게 고를 이유가 없다. 다만 **카테고리끼리
#   겹치는 말**은 피한다(점수 싸움이 되어 둘 다 흐려진다).
#: ★★★ **성경듣기 낱말** — 「본문을 읽어 주는 것」만. 2026-09-10 실측 381편.
#:   ⚠⚠ **한 낱말로 넣지 않는다** — 「성경」·「말씀」은 설교에도 흔하다.
#:     `성경 낭독`·`읽어주는 성경` 처럼 **구(句)** 라야 설교를 안 먹는다.
#:   ⚠ 「통독」은 설교 시리즈 이름에도 쓰여 혼자서는 위험하다 — `성경 통독` 으로.
DEFAULT_READING_KW = {
    'COMMON': ['audio bible', 'bible reading', 'scripture reading',
               'read the bible', 'holy bible read'],
    'KO': ['성경 낭독', '성경낭독', '말씀 낭독', '말씀낭독', '읽어주는 성경',
           '성경 읽어주는', '성경듣기', '성경 듣기', '듣는 성경', '성경 통독',
           '오디오 성경', '잠자며 듣는', '잠잘때 듣는', '자면서 듣는'],
    'EN': ['audio bible', 'bible reading', 'read by', 'narrated bible',
           'spoken word bible', 'listen to the bible'],
    'JA': ['聖書朗読', '朗読聖書', 'オーディオバイブル', '聖書を読む'],
    'ZH': ['圣经朗读', '朗读圣经', '有声圣经', '圣经诵读'],
    'ZHT': ['聖經朗讀', '朗讀聖經', '有聲聖經', '聖經誦讀'],
    'DE': ['bibel hören', 'hörbibel', 'bibel gelesen', 'bibellesung'],
    'FR': ['bible lue', 'lecture de la bible', 'bible audio'],
    'ES': ['biblia hablada', 'biblia narrada', 'lectura de la biblia',
           'biblia en audio'],
    'PT': ['bíblia narrada', 'bíblia falada', 'leitura da bíblia',
           'bíblia em áudio'],
    'RU': ['аудио библия', 'аудиобиблия', 'чтение библии', 'библия читает'],
    'AR': ['الكتاب المقدس مسموع', 'قراءة الكتاب المقدس', 'الكتاب المقدس صوتي'],
}


#: ★★★ **기도 낱말**(2026-10-12 사용자 「채널 발굴 / 분류관리 등을 위한 씨앗을 정의」) — 그전에는 갈래가
#:   없어 일반 수집에 들어온 기도 영상이 **설교**(기본값)로 적혔다.
#:   ⚠ 「기도」 한 낱말은 안 넣는다 — 「기도의 능력」 설교·「기도하는 교회」 같은 제목에 흔하다.
#:     **구(句)** 로 넣는다(기도회·중보기도·기도문). 유럽어의 prayer·Gebet 은 홑낱말이지만
#:     그 언어 설교 제목에는 드물고, 설교면 sermon·Predigt 가 함께 걸려 점수로 가른다.
DEFAULT_PRAYER_KW = {
    'COMMON': ['prayer meeting', 'prayer time', 'pray with me', 'let us pray', 'intercessory prayer',
               'morning prayer', 'night prayer', 'evening prayer', 'healing prayer', 'powerful prayer',
               'guided prayer', 'daily prayer', 'prayer for protection', 'scripture prayer'],
    'KO': ['기도회', '합심기도', '중보기도', '통성기도', '기도문', '함께 기도', '기도합시다', '치유 기도',
           '치유기도', '축복기도', '아침 기도', '저녁 기도', '잠들기 전 기도', '선포 기도', '말씀 선포 기도', '말씀기도', '기도 시간'],
    'JA': ['祈り', 'お祈り', '祈祷会', 'とりなしの祈り', '朝の祈り', '夜の祈り'],
    'ZH': ['祷告', '祷告会', '代祷', '晨祷', '晚祷', '祷告文'],
    'ZHT': ['禱告', '禱告會', '代禱', '晨禱', '晚禱', '禱告文'],
    'DE': ['Gebet', 'Fürbitte', 'Gebetszeit', 'Morgengebet', 'Abendgebet', 'lasst uns beten'],
    'FR': ['prière', 'intercession', 'prions ensemble', 'prière du matin', 'prière du soir'],
    'ES': ['oración', 'oremos', 'intercesión', 'oración de la mañana', 'oración de la noche'],
    'PT': ['oração', 'oremos', 'intercessão', 'oração da manhã', 'oração da noite'],
    'RU': ['молитва', 'молитвы', 'помолимся', 'утренняя молитва', 'вечерняя молитва'],
    'AR': ['صلاة', 'صلوات', 'نصلي', 'صلاة الصباح', 'صلاة المساء'],
}


#: ★ 성지·유적 답사(2026-10-23) — 제목에 이 낱말이 있으면 설교·성경공부보다 답사다(찬양·영화는 안 이긴다). 실측 115편 · 채널 셋
#:   (C채널 「성지가 좋다」 · CBS 「성서 700 도시여행」 · 랜선순례).
DEFAULT_SITE_KW = {
    'COMMON': ['holy land', 'bible lands', 'biblical site', 'biblical archaeology', 'archaeolog', 'excavation', 'israel tour', 'pilgrimage', 'tel dan', 'megiddo'],
    'KO': ['성지순례', '성지 순례', '성지답사', '성지 답사', '성지가 좋다', '성서고고학', '성서 고고학', '성경고고학', '성경 고고학', '고고학', '성경지리', '성경 지리', '유적지', '유적', '랜선순례', '성서 700', '현장 답사', '답사'],
    'JA': ['聖地', '遺跡', '考古学', '聖書考古学'],
    'ZH': ['圣地', '遗址', '考古', '圣经考古'],
    'ZHT': ['聖地', '遺址', '考古', '聖經考古'],
    'DE': ['Heiliges Land', 'Archäologie', 'Ausgrabung', 'Pilgerreise'],
    'FR': ['Terre Sainte', 'archéologie', 'fouilles', 'pèlerinage'],
    'ES': ['Tierra Santa', 'arqueología', 'excavación', 'peregrinación'],
    'PT': ['Terra Santa', 'arqueologia', 'escavação', 'peregrinação'],
    'RU': ['Святая земля', 'археолог', 'раскопки', 'паломничество'],
    'AR': ['الأرض المقدسة', 'آثار', 'حفريات'],
}


DEFAULT_CLASSIFY_KW = {
    'READING':   DEFAULT_READING_KW,
    'PRAYER':    DEFAULT_PRAYER_KW,
    'SITE':      DEFAULT_SITE_KW,
    'WORSHIP': {
        'COMMON': ['ccm', 'worship', 'praise', 'hymn', 'anthem', 'hillsong', 'bethel',
                   'elevation worship', 'maverick city', 'passion', 'chris tomlin',
                   'kari jobe', 'lauren daigle', 'live worship'],
        'KO': ['찬양', '찬송', '워십', '경배와찬양', '경배'],
        'ZH': ['敬拜赞美', '敬拜mv', '赞美', '诗歌', '圣诗', '赞美之泉'],
        'ZHT': ['敬拜讚美', '敬拜mv', '讚美', '詩歌', '聖詩', '讚美之泉'],
        'JA': ['賛美', '讃美', '賛美歌', '讃美歌', '聖歌', 'ワーシップ', '礼拝賛美'],
        'DE': ['Lobpreis', 'Anbetung', 'Kirchenlied', 'Choral', 'Lobgesang'],
        'FR': ['louange', 'adoration', 'cantique', 'chant chrétien'],
        'ES': ['alabanza', 'adoración', 'cántico', 'canto cristiano', 'himno'],
        'PT': ['louvor', 'adoração', 'cântico', 'hino', 'canção gospel'],
        'RU': ['прославление', 'поклонение', 'хвала', 'песнопение', 'гимн'],
        'AR': ['تسبيح', 'ترنيم', 'ترانيم', 'عبادة', 'مديح'],
    },
    'SERMON': {
        'COMMON': ['sermon', 'preaching', 'homily', 'message', 'devotional',
                   'exposition', 'expository', 'exegesis'],
        # ⚠ **「강의」를 STUDY 로 옮겼다**(2026-09-06 사용자 2-2 「너무 포괄적인
        #   용어를 적용해도 문제 없는가」 — 실측이 답했다). 이 낱말이 유형을
        #   정한 3건이 **전부 공부 쪽**이었다: 「성막을 공부해야」·「성경 강의
        #   풀버전 통독」·「구약개론 강의」. 강의는 설교가 아니라 가르침이다.
        'KO': ['설교', '강해', '묵상', '말씀', '큐티'],
        'ZH': ['讲道', '证道', '释经', '灵修', '信息分享'],
        'ZHT': ['講道', '證道', '釋經', '靈修', '信息分享'],
        'JA': ['説教', 'メッセージ', 'デボーション', '講解', '御言葉'],
        'DE': ['Predigt', 'Andacht', 'Auslegung', 'Verkündigung', 'Wortverkündigung'],
        'FR': ['prédication', 'prêche', 'méditation', 'exhortation'],
        'ES': ['predicación', 'prédica', 'sermón', 'meditación', 'reflexión'],
        'PT': ['pregação', 'sermão', 'meditação', 'reflexão'],
        'RU': ['проповедь', 'проповеди', 'размышление', 'толкование'],
        'AR': ['عظة', 'وعظ', 'تأمل', 'تأملات', 'كلمة الله'],
    },
    'STUDY': {
        'COMMON': ['bible study', 'study', 'lesson', 'dictionary', 'geography',
                   'overview', 'introduction', 'course', 'word study'],
        # ⚠ **「강의」는 「평강의」와 겹친다**(실측 15건 중 오탐 1 —
        #   「평**강의** 길을 찾아서」는 평강+조사다). 앞뒤 한글로는 못 가른다
        #   — 성경강의·민수기강의·원어강의도 앞에 한글이 붙는 정당한 쓰임이다.
        #   ⇒ 그대로 둔다. 14/15 가 맞고, **이름표가 틀릴 뿐**이다.
        # ⚠⚠ **「해설」을 뺐다**(2026-09-06 실측) — 이 낱말이 유형을 정한
        #   **27건이 전부 「매일성경 본문해설」**이었다. 그것은 날마다 읽는
        #   본문 강해라 **설교 쪽**이고, STUDY 로 찍히면 갈래가 통째로 틀린다.
        #   ⇒ 빼니 27건이 SERMON 으로 가고 **다른 것은 하나도 안 바뀐다.**
        # ⚠ 「항공촬영·재연·인형극」은 실측 **0건**이지만 남긴다 — 넓어서가
        #   아니라 아직 그런 자료가 없을 뿐이고, 뜻이 좁아 오탐이 없다.
        'KO': ['통독', '통독하기', '성경공부', '성경지도', '답사', '성서지리', '지리',
               '개론', '사전', '강의', '성경시대'],
        'ZH': ['查经', '圣经学习', '圣经课程', '门徒训练', '圣经导论', '圣经地理'],
        'ZHT': ['查經', '聖經學習', '聖經課程', '門徒訓練', '聖經導論', '聖經地理'],
        'JA': ['聖書研究', '聖書講座', 'バイブルスタディ', '弟子訓練', '聖書入門'],
        'DE': ['Bibelstudium', 'Bibelkurs', 'Bibelarbeit', 'Jüngerschaft',
               'Bibelkunde', 'Einführung'],
        'FR': ['étude biblique', 'cours biblique', 'école biblique'],
        'ES': ['estudio bíblico', 'curso bíblico', 'escuela bíblica',
               'discipulado', 'introducción a la biblia'],
        'PT': ['estudo bíblico', 'curso bíblico', 'escola bíblica',
               'discipulado', 'introdução à bíblia'],
        'RU': ['изучение библии', 'библейский урок', 'разбор', 'ученичество',
               'введение в библию'],
        'AR': ['دراسة الكتاب', 'درس كتابي', 'تلمذة', 'مدخل إلى الكتاب'],
    },
    'FILM': {
        'COMMON': ['documentary', 'film', 'movie', 'drama', 'expedition', 'aerial',
                   'drone', 'trailer'],
        # ⚠ **「영화」는 「부귀영화·영화롭다」와 겹친다**(실측 18건 중 오탐 1 —
        #   「예수의 제자는 어떤 부귀영화를」). 그래도 그대로 둔다:
        #   ⓐ 분류는 **점수 싸움**이라 설교 낱말이 함께 있으면 진다(실측
        #     「부귀 영화」·「영화로우리라」·「인도 천영화」 셋 다 SERMON 으로 갔다)
        #   ⓑ **정당한 쓰임이 앞뒤 어디에나 붙는다**(성경영화·영화 오디세이)라
        #     「미사」처럼 낱말 끝 규칙으로 못 가른다.
        #   ⓒ **이름표가 틀릴 뿐**이고 거르는 말과 달리 값이 싸다.
        'KO': ['다큐', '다큐멘터리', '영화', '드라마', '드론', '위성사진', '항공촬영', '재연'],
        'ZH': ['电影', '影片', '纪录片', '短片', '微电影', '预告片'],
        'ZHT': ['電影', '影片', '紀錄片', '短片', '微電影', '預告片'],
        'JA': ['映画', 'ドラマ', 'ドキュメンタリー', '短編', '予告編'],
        'DE': ['Dokumentation', 'Doku', 'Reportage'],
        'FR': ['documentaire', 'court-métrage', 'long-métrage', 'bande-annonce'],
        'ES': ['película', 'documental', 'cortometraje', 'tráiler'],
        'PT': ['documentário', 'curta-metragem'],
        'RU': ['фильм', 'документальный', 'короткометражка', 'трейлер'],
        'AR': ['فيلم', 'وثائقي', 'مسلسل', 'فيلم قصير'],
    },
    'ANIMATION': {
        'COMMON': ['animation', 'animated', 'cartoon'],
        'KO': ['애니', '애니메이션', '만화', '인형극'],
        'ZH': ['动画', '卡通', '动漫'],
        'ZHT': ['動畫', '卡通', '動漫'],
        'JA': ['アニメ', 'アニメーション'],
        'DE': ['Zeichentrick', 'Trickfilm'],
        'FR': ['dessin animé', 'dessins animés'],
        'ES': ['dibujos animados', 'animación'],
        'PT': ['desenho animado', 'animação'],
        'RU': ['мультфильм', 'мультик', 'анимация'],
        'AR': ['رسوم متحركة', 'كرتون'],
    },
    'AUDIO': {
        'COMMON': ['audio', 'audiobook', 'narration', 'podcast', 'asmr'],
        'KO': ['성경듣기', '말씀듣기', '낭독', '오디오', '라디오성경'],
        'ZH': ['有声', '朗读', '播客', '音频', '有声圣经'],
        'ZHT': ['有聲', '朗讀', '播客', '音頻', '有聲聖經'],
        'JA': ['朗読', 'オーディオ', 'ポッドキャスト', '聴く聖書'],
        'DE': ['Hörbuch', 'Hörbibel', 'Vorlesung der Bibel'],
        'FR': ['lecture de la bible', 'écouter la bible'],
        'ES': ['lectura de la biblia', 'escuchar la biblia'],
        'PT': ['bíblia em áudio', 'leitura da bíblia'],
        'RU': ['аудиокнига', 'аудиобиблия', 'подкаст', 'чтение библии'],
        'AR': ['كتاب صوتي', 'الكتاب المسموع', 'بودكاست'],
    },
    'KIDS': {
        'COMMON': ['kids', 'children', "children's", 'child', 'animated', 'animation',
                   'cartoon', 'superbook', 'for kids', 'for children', 'toddler',
                   'preschool', 'sunday school'],
        'KO': ['어린이', '키즈', '유아', '만화', '애니', '동화', '슈퍼북', '성경동화',
               '어린이성경', '주일학교', '유년부', '유치부', '아동', '꼬마'],
        'ZH': ['儿童', '少儿', '孩子', '主日学', '儿童圣经', '幼儿'],
        'ZHT': ['兒童', '少兒', '孩子', '主日學', '兒童聖經', '幼兒'],
        'JA': ['子ども', 'こども', '子供', '児童', 'キッズ', '教会学校', '幼児'],
        'DE': ['Kinder', 'Kindergottesdienst', 'Kinderbibel', 'Sonntagsschule',
               'Kindergarten'],
        'FR': ['enfants', 'école du dimanche', 'bible pour enfants', 'jeunesse'],
        'ES': ['niños', 'escuela dominical', 'biblia para niños', 'infantil'],
        'PT': ['crianças', 'escola dominical', 'bíblia para crianças', 'infantil'],
        'RU': ['дети', 'детская', 'воскресная школа', 'детская библия'],
        'AR': ['أطفال', 'مدرسة الأحد', 'كتاب الأطفال'],
    },
    # ★★★ **수화(SIGN) — 대상 축의 셋째 값**(2026-09-08 사용자 지시 「주로 채널
    #   단위로 컨텐츠가 올라온다. 자동크롤러 **채널등록 단계부터** 검토해서
    #   방향을 설정하라」). 채널이 정한 대상이 먼저이고 낱말은 보조다.
    #   ⚠ **짧은 낱말을 안 적는다** — 실측 「수화」 한 낱말은 **이수화 목사**
    #     채널(3건)에 걸렸고 `asl` 은 Aslan·Basel 속에 든다. 구(句)로만 적는다.
    'SIGN': {
        'COMMON': ['sign language', 'in asl', 'asl bible', 'bsl bible', 'deaf bible',
                   'deaf church', 'for the deaf', 'signed bible', 'sign bible',
                   'auslan', 'ls:pr', 'libras'],
        'KO': ['수화 성경', '수화성경', '수화로 ', '수어 성경', '수어성경', '수어로 ',
               '농인', '농아인', '청각장애인', '수화통역', '수어통역', '수화예배',
               '수어예배', '농인교회'],
        'ZH': ['手语', '聋人', '手语圣经', '聋人教会'],
        'ZHT': ['手語', '聾人', '手語聖經', '聾人教會'],
        'JA': ['手話', 'ろう者', '手話聖書', '手話礼拝'],
        'DE': ['Gebärdensprache', 'Gehörlose', 'Gebärdenbibel'],
        'FR': ['langue des signes', 'sourds', 'bible en lsf'],
        'ES': ['lengua de señas', 'lengua de signos', 'sordos', 'biblia en señas'],
        'PT': ['língua de sinais', 'em libras', 'surdos', 'bíblia em libras'],
        'RU': ['жестовый язык', 'жестовом языке', 'для глухих', 'глухих'],
        'AR': ['لغة الإشارة', 'الصم', 'للصم'],
    },
}


# ⚠⚠ **중국어는 두 버킷이 서로의 말을 함께 갖는다**(2026-09-06 실측으로 잡았다).
#   수집기가 다는 `lang_code` 는 짐작이라 **번체 제목이 ZH 로 들어온다** —
#   실제로 「讚美之泉敬拜讚美」 MV 가 `lang_code='ZH'` 였고, ZH 버킷에 간체
#   「赞美之泉」만 있으면 한 건도 안 걸린다.
#   ⇒ 간체·번체는 **같은 언어의 두 표기**이므로 합집합으로 둔다. 다른 언어에는
#     이 규칙을 쓰지 않는다(그쪽은 lang_code 가 곧 표기다).
for _cat in DEFAULT_CLASSIFY_KW.values():
    _u, _seen = [], set()
    for _b in ('ZH', 'ZHT'):
        for _w in _cat.get(_b, []):
            if _w.lower() not in _seen:
                _seen.add(_w.lower()); _u.append(_w)
    if _u:
        _cat['ZH'] = list(_u); _cat['ZHT'] = list(_u)
del _cat, _u, _seen, _b, _w


def _norm_buckets(val, default):
    """config_val(JSON) → {bucket:[kw]}. 구버전 flat list 면 스크립트로 자동 분류."""
    if isinstance(val, dict):
        return {b: list(v) for b, v in val.items() if isinstance(v, list)}
    if isinstance(val, list):          # 구버전 flat → 버킷 분리(마이그레이션 안전망)
        return split_flat_by_script(val)
    return {b: list(v) for b, v in (default or {}).items()}


def split_flat_by_script(kw_list):
    """플랫 키워드 리스트 → 스크립트 기준 버킷 분리. 라틴/숫자/기호=COMMON,
    한글=KO, 가타카나/히라가나=JA, 한자(가나無)=ZH, 키릴=RU, 아랍=AR."""
    out = {}
    import unicodedata as _ud
    for kw in kw_list:
        s = str(kw)
        bucket = COMMON_BUCKET
        for ch in s:
            o = ord(ch)
            if 0xAC00 <= o <= 0xD7A3 or 0x1100 <= o <= 0x11FF:
                bucket = 'KO'; break
            if 0x3040 <= o <= 0x30FF:
                bucket = 'JA'; break
            if 0x4E00 <= o <= 0x9FFF:
                bucket = 'ZH'  # 한자 — 가나 있으면 위에서 JA 로 잡힘
            elif 0x0400 <= o <= 0x04FF:
                bucket = 'RU'; break
            elif 0x0600 <= o <= 0x06FF:
                bucket = 'AR'; break
        out.setdefault(bucket, []).append(s)
    return out


def load_classify_sets(conn):
    """모든 분류 카테고리의 {bucket:[kw]} 로드(없으면 DEFAULT). → {category:{bucket:[kw]}}"""
    import json as _json
    sets = {}
    for cat, key in CLASSIFY_KW_KEYS.items():
        row = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                           (key,)).fetchone()
        val = None
        if row and row[0]:
            try:
                val = _json.loads(row[0])
            except Exception:
                val = None
        sets[cat] = _norm_buckets(val, DEFAULT_CLASSIFY_KW.get(cat))
    return sets


def kw_for_lang(cat_buckets, lang):
    """카테고리 버킷에서 COMMON ∪ 해당 언어 키워드 합집합."""
    out = list(cat_buckets.get(COMMON_BUCKET, []))
    if lang:
        out += cat_buckets.get(lang, [])
    return out


#: ★★★ **교회 채널 낱말 — 「예배」가 찬양이 아닌 자리**
#:   (2026-09-07 사용자 확정 「**"교회" 채널에서 올린 "예배"라는 단어가 들어가
#:   있다면 비록 찬양이더라도 그것은 마커스 등의 찬양사역자들의 영상이 아니다.
#:   찬양 카테고리에서 제외하라. 아마 다른 언어권에서도 마찬가지일 것이다**」).
#:
#: ⚠⚠ **낱말로는 못 가른다** — 실측: 「예배」는 WORSHIP 낱말표에 **아예 없고**
#:   (KO = 찬양·찬송·워십·경배와찬양·경배), 걸리던 것은 채널 이름 안의
#:   **영어 `Worship`**(「예배하는교회 in Toronto (Worship House Church)」)이다.
#:   그 낱말을 빼면 `MARKERS WORSHIP` 이 죽는다. ⇒ **낱말이 아니라 「누가
#:   올렸나」로 가른다.**
#: ★ 실측 — WORSHIP 537건 중 **328건이 교회 채널**(예배인IN교회 39 ·
#:   대구은천교회예배실황 32 · 중부명성교회 중국어예배부 25 …)이고,
#:   **남는 209건은 찬양사역 채널**(MARKERS WORSHIP 40 · Just Jesus Worship 25 ·
#:   Estilo Adoração 7)이다. **깨끗하게 갈린다.**
#: ⚠ **제목이 아니라 채널 이름만 본다** — 찬양 영상 제목에 「교회여 일어나라」
#:   같은 말이 들어갈 수 있다.
#: ⚠ 미탐은 감수한다 — 「태장 더모어 청년부 젊은이 예배」는 교회 부서인데
#:   낱말이 없어 안 걸린다. **오탐(찬양사역 채널을 빼는 것)보다 싸다.**
CHURCH_WORDS = (
    '교회', '성당', 'church', 'chapel', 'parish', 'cathedral',
    'iglesia', 'igreja', 'église', 'eglise', 'kirche', 'gemeinde',
    'церковь', 'كنيسة', '教会', '教會', '敎會', 'chiesa', 'kerk',
)


def is_church_channel(channel):
    """그 채널이 **교회**인가 — 찬양사역 채널과 가르는 유일한 잣대.

    ⚠ 빈 채널명이면 거짓 — 모르면 지금까지처럼 둔다(§0-1).
    """
    low = (channel or '').lower()
    return any(w in low for w in CHURCH_WORDS)


def classify_content(text, lang, sets, channel=None):
    """내용유형(SERMON/WORSHIP/STUDY/FILM) — COMMON∪lang 키워드 점수 최고(0이면 SERMON).

    ⚠ `channel` 을 주면 **교회 채널의 WORSHIP 판정을 물린다**(위 표 참조).
      안 주면 지금까지와 똑같이 돈다 — 옛 호출부가 안 깨진다.
    """
    low = (text or '').lower()
    score = {}
    for cat in CONTENT_KW_CATS:
        kws = kw_for_lang(sets.get(cat, {}), lang)
        score[cat] = sum(1 for k in kws if k and k.lower() in low)
    # ★★★ **성경듣기가 설교를 이긴다**(2026-09-10) — 「성경 낭독」·「Audio
    #   Bible」은 그 자체로 결정적인데, 같은 제목에 「말씀」·「성경」이 함께 있어
    #   설교 점수가 더 높게 나온다. 실측 381편 중 283편이 그래서 설교였다.
    #   ⚠ **찬양·영화는 안 이긴다** — 「찬양 낭독 모음」이면 찬양이 맞다.
    if score.get('READING', 0) > 0 and score['READING'] >= score.get('WORSHIP', 0) \
            and score['READING'] >= score.get('FILM', 0):
        return 'READING'
    # ★★ **기도는 설교보다 점수가 높을 때만**(2026-10-12) — 동점이면 설교다(「Predigt über das Gebet」 =
    #   기도에 관한 설교). 「말씀 선포 기도」처럼 설교 낱말이 섞이는 꼴은 구(句) 하나를 더 넣어 이기게 한다.
    #   ⚠ 찬양은 안 이긴다(「기도 찬양」은 찬양).
    if score.get('PRAYER', 0) > 0 and score['PRAYER'] > score.get('SERMON', 0) \
            and score['PRAYER'] > score.get('WORSHIP', 0):
        return 'PRAYER'
    # ★ 답사는 설교·성경공부를 이긴다(2026-10-23) — 「성지순례 설교」도 답사 영상이다. 찬양·영화는 안 이긴다.
    if score.get('SITE', 0) > 0 and score['SITE'] >= score.get('WORSHIP', 0) and score['SITE'] >= score.get('FILM', 0):
        return 'SITE'
    best = max(CONTENT_KW_CATS, key=lambda c: score[c])
    if best == 'WORSHIP' and score[best] > 0 and is_church_channel(channel):
        # 교회가 올린 것은 찬양이 아니다 — **찬양을 뺀 채로 다시 고른다.**
        # ⚠ 그래도 STUDY·FILM 이 나올 수 있다(「성경공부」·「영화」가 제목에
        #   있으면 그쪽이 맞다). 찬양만 물리고 나머지 판정은 그대로 둔다.
        rest = [c for c in CONTENT_KW_CATS if c != 'WORSHIP']
        best = max(rest, key=lambda c: score[c])
        return best if score[best] > 0 else DEFAULT_CONTENT
    return best if score[best] > 0 else DEFAULT_CONTENT


def detect_format(text, lang, sets):
    """형태유형 — ANIMATION > AUDIO 우선, 없으면 VIDEO. (COMMON∪lang)"""
    low = (text or '').lower()
    for cat in ('ANIMATION', 'AUDIO'):
        kws = kw_for_lang(sets.get(cat, {}), lang)
        if any(k and k.lower() in low for k in kws):
            return cat
    return DEFAULT_FORMAT


# ─────────────────────────────────────────────────────────────────────────────
# 수화 언어 코드표 — `sys_sign_language` (2026-09-08 사용자 지시 「수화언어 전용
# 코드 만들어라」)
# ─────────────────────────────────────────────────────────────────────────────
# ★★★ **수화는 그 나라 말을 따라가지 않는다** — 파라과이 수화(PYS)·스페인 수화
#   (SSP)·멕시코 수화(MFS)는 서로 안 통하는 별개 언어이고, ASL 과 BSL 도 그렇다.
#   그래서 말 언어(`lang_code` — 자막·음성)와 **다른 층**에 코드를 둔다.
#   코드 = ISO 639-3 세 자(대문자). 실측 등록 채널 셋이 이미 언어코드 짝과
#   3/3 어긋났다(EN→인도수화 INS · ES→푸에르토리코 PSL · ES→파라과이 PYS).
# ⚠ 채널이 정본이다 — 채널 `sign_code` → 수집물 `description.sign_code`.
#   미디어 본체에 칸을 더하지 않는다(코어팩 적재기가 「모르는 칸」을 거부한다 —
#   구조화 속성은 JSON, §0-3 규칙 2).
# ⚠ 코드를 늘리는 법 = 이 표에 한 줄(관리자 화면에서도 `ensure_sign_table` 이
#   씨앗을 멱등으로 넣는다). 사람이 넣은 행은 덮지 않는다.
SIGN_TBL = 'sys_sign_language'
DEFAULT_SIGN_LANGUAGES = [
    # (코드, 영어 이름, 한국어 이름, 지역)
    ('INS', 'Indian Sign Language',            '인도 수화',        'IN'),
    ('PSL', 'Puerto Rican Sign Language',      '푸에르토리코 수화', 'PR'),
    ('PYS', 'Paraguayan Sign Language',        '파라과이 수화',    'PY'),
    ('ASE', 'American Sign Language (ASL)',    '미국 수화(ASL)',   'US'),
    ('BFI', 'British Sign Language (BSL)',     '영국 수화(BSL)',   'GB'),
    ('KVK', 'Korean Sign Language',            '한국수어',         'KR'),
    ('ILS', 'International Sign',              '국제수화',         ''),
    ('SSP', 'Spanish Sign Language (LSE)',     '스페인 수화(LSE)', 'ES'),
    ('MFS', 'Mexican Sign Language (LSM)',     '멕시코 수화(LSM)', 'MX'),
    ('AED', 'Argentine Sign Language (LSA)',   '아르헨티나 수화',  'AR'),
    ('BZS', 'Brazilian Sign Language (Libras)', '브라질 수화(Libras)', 'BR'),
    ('PSR', 'Portuguese Sign Language',        '포르투갈 수화',    'PT'),
    ('FSL', 'French Sign Language (LSF)',      '프랑스 수화(LSF)', 'FR'),
    ('GSG', 'German Sign Language (DGS)',      '독일 수화(DGS)',   'DE'),
    ('JSL', 'Japanese Sign Language',          '일본 수화',        'JP'),
    ('CSL', 'Chinese Sign Language',           '중국 수화',        'CN'),
    ('RSL', 'Russian Sign Language',           '러시아 수화',      'RU'),
    ('ASF', 'Auslan (Australian Sign Language)', '호주 수화(Auslan)', 'AU'),
    ('NZS', 'New Zealand Sign Language',       '뉴질랜드 수화',    'NZ'),
    ('TSS', 'Taiwan Sign Language',            '대만 수화',        'TW'),
    ('ESL', 'Egyptian Sign Language',          '이집트 수화',      'EG'),
]


#: 언어코드 → 그 언어권의 기본 수화(제목·설명문에 실마리가 없을 때의 마지막 유추).
#: 2026-09-08 사용자 「제목, 설명문에 수화코드를 기재하지 않은 경우 언어코드를
#: 통해서 유추하는 것이 최선」. ⚠ 유추한 값은 `sign_guess` 표식을 함께 남긴다.
SIGN_BY_LANG = {
    'KO': 'KVK', 'EN': 'ASE', 'ES': 'SSP', 'PT': 'BZS', 'FR': 'FSL', 'DE': 'GSG',
    'JA': 'JSL', 'ZH': 'CSL', 'ZHT': 'TSS', 'RU': 'RSL', 'AR': 'ESL',
}

#: 제목·설명문 실마리 → 코드 (부분일치 · 대소문자 무관 · 긴 것부터).
#: ⚠ 짧은 약어(asl·lsm·lse)는 낱말 경계로만 잡는다 — Aslan·Basel 속에 든다.
SIGN_TEXT_HINTS = [
    ('paraguay', 'PYS'), ('lengua de señas paraguaya', 'PYS'),
    ('indian sign language', 'INS'), ('isl bible', 'INS'),
    ('ls:pr', 'PSL'), ('puerto ric', 'PSL'),
    ('american sign language', 'ASE'), ('british sign language', 'BFI'),
    ('auslan', 'ASF'), ('new zealand sign', 'NZS'),
    ('libras', 'BZS'), ('lengua de señas mexicana', 'MFS'), ('lengua de señas argentina', 'AED'),
    ('langue des signes française', 'FSL'), ('gebärdensprache', 'GSG'),
    ('international sign', 'ILS'), ('한국수어', 'KVK'), ('한국 수화', 'KVK'),
    ('日本手話', 'JSL'), ('中国手语', 'CSL'), ('台灣手語', 'TSS'), ('русский жестовый', 'RSL'),
]
_SIGN_ABBR = {'asl': 'ASE', 'bsl': 'BFI', 'lsm': 'MFS', 'lsa': 'AED', 'lse': 'SSP',
              'lsf': 'FSL', 'dgs': 'GSG', 'jsl': 'JSL', 'nzsl': 'NZS', 'ksl': 'KVK'}


def infer_sign_code(text, lang=None):
    """→ (코드, 근거) — 근거 'TEXT'(실마리) | 'LANG'(언어 기본값) | None."""
    import re as _re
    low = (text or '').lower()
    for hint, code in SIGN_TEXT_HINTS:
        if hint in low:
            return code, 'TEXT'
    for ab, code in _SIGN_ABBR.items():
        if _re.search(r'(?<![a-z])' + ab + r'(?![a-z])', low):
            return code, 'TEXT'
    code = SIGN_BY_LANG.get((lang or '').upper())
    return (code, 'LANG') if code else (None, None)


def ensure_sign_table(conn):
    """코드표(멱등) + 씨앗. 사람이 고친 행은 덮지 않는다(INSERT OR IGNORE)."""
    conn.execute("""
        CREATE TABLE IF NOT EXISTS %s (
            sign_code     TEXT PRIMARY KEY,
            name_en       TEXT NOT NULL,
            name_ko       TEXT,
            region        TEXT,
            sort_order    INTEGER NOT NULL DEFAULT 100,
            record_status TEXT NOT NULL DEFAULT 'LIVE'
        )""" % SIGN_TBL)
    for i, (code, en, ko, rg) in enumerate(DEFAULT_SIGN_LANGUAGES):
        conn.execute("INSERT OR IGNORE INTO %s(sign_code, name_en, name_ko, region,"
                     " sort_order) VALUES(?,?,?,?,?)" % SIGN_TBL,
                     (code, en, ko, rg, (i + 1) * 10))
    conn.commit()
    return True


def sign_languages(conn):
    """→ [(code, name_en, name_ko, region)] LIVE 만, 차례대로."""
    ensure_sign_table(conn)
    return conn.execute(
        "SELECT sign_code, name_en, COALESCE(name_ko,''), COALESCE(region,'')"
        "  FROM %s WHERE record_status='LIVE' ORDER BY sort_order, sign_code"
        % SIGN_TBL).fetchall()


def sign_codes_in_use(conn):
    """승인된 수화 영상에 실제로 적힌 수화 코드 → 정렬 목록(화면 콤보 재료)."""
    try:
        return sorted({r[0] for r in conn.execute(
            "SELECT DISTINCT UPPER(json_extract(description,'$.sign_code'))"
            "  FROM sys_media_asset WHERE audience='SIGN' AND is_active=1"
            "   AND COALESCE(record_status,'LIVE')='LIVE'"
            "   AND COALESCE(json_extract(description,'$.sign_code'),'')<>''")
            if r[0]})
    except Exception:
        return []


def sign_name(conn, code, lang='KO'):
    """코드 → 그 언어 이름(KO 있으면 KO, 아니면 EN). 모르는 코드는 코드 그대로."""
    code = (code or '').strip().upper()
    if not code:
        return ''
    try:
        r = conn.execute("SELECT name_en, COALESCE(name_ko,'') FROM %s"
                         " WHERE sign_code=?" % SIGN_TBL,
                         (code,)).fetchone()  # status-ok: 코드 하나로 이름표를 읽는 코드표다
    except Exception:
        r = None
    if not r:
        return code
    return (r[1] if (lang or '').upper() == 'KO' and r[1] else r[0])


def media_sign_code(desc_json):
    """`sys_media_asset.description` JSON 에서 수화코드 → 대문자 코드 또는 ''."""
    try:
        import json as _json
        d = _json.loads(desc_json) if isinstance(desc_json, str) and desc_json else (desc_json or {})
        return str(d.get('sign_code') or '').strip().upper()
    except Exception:
        return ''


def content_label(code, lang=None):   # lang 은 자리만(i18n 이 현재 언어를 안다)
    """내용 유형(`media_type`) 이름표 — **단일 문**(2026-09-16 19-3).
    `ui_strings KV_KIND_<code>` 를 사용자 언어로 읽고 없으면 `CONTENT_LABEL`(KO).
    ⚠ 사용자 화면이 `CONTENT_LABEL` 을 직접 읽지 말 것 — 그 표는 KO 뿐이다."""
    c = (code or '').upper()
    ko = CONTENT_LABEL.get(c, c)
    try:
        import i18n
        return i18n.t('KV_KIND_' + c, ko) if c in CONTENT_LABEL else ko
    except Exception:
        return ko


def audience_label(audience, lang=None):
    """대상 축 이름표(어린이·수화) — `KV_AUD_*` · GENERAL 은 빈 문자열."""
    a = (audience or 'GENERAL').upper()
    if a == 'GENERAL':
        return ''
    ko = AUDIENCE_LABEL.get(a, a)
    try:
        import i18n
        return i18n.t('KV_AUD_' + a, ko)
    except Exception:
        return ko


def badge(content, ftype, audience='GENERAL', lang=None, with_format=False):
    """목록 「유형」 칸 이름표 — **`content_label` 그대로**(2026-09-16 19-3 통일).
    - 기본 = 내용 유형 이름(설교·강해 / 성경공부 / 찬양 / 영화·애니 / 성경듣기)
      + 대상이 어린이·수화면 접미. **형태(영상·음성·텍스트)는 안 붙인다** — 사용자
      화면의 P2 유형 콤보·어린이 라디오와 글자가 같아야 하고, 실측 형태가 99%
      VIDEO 라 가르는 값이 아니다(§235차).
    - `with_format=True`(관리자 화면) 면 옛대로 SERMON/STUDY 에 형태를 병기하고
      ANIMATION 을 따로 적는다.
    """
    cl = content_label(content, lang)
    if with_format:
        fl = FORMAT_LABEL.get(ftype, ftype or '')
        if content in ('SERMON', 'STUDY'):
            s = f'{cl}·{fl}' if fl else cl
        elif (ftype or '').upper() == 'ANIMATION':
            s = f'{cl}·{FORMAT_LABEL["ANIMATION"]}'
        else:
            s = cl
    else:
        s = cl
    al = audience_label(audience, lang)
    if al:
        s += '·' + al
    return s


def normalize_content(value):
    """구(舊) media_type 값을 새 내용유형으로 정규화 (혼합형 분해)."""
    v = (value or '').upper()
    if v in CONTENT_TYPES:
        return v
    if v in ('TEXT_SERMON', 'AUDIO_SERMON'):
        return 'SERMON'
    if v in ('TEXT_ARTICLE', 'PDF_DOC', 'INFOGRAPHIC', 'WIKI_SUMMARY'):
        return 'STUDY'
    return DEFAULT_CONTENT


def normalize_format(media_type, format_type):
    """구 media_type + format_type 으로 새 형태유형 추론."""
    ft = (format_type or '').upper()
    if ft in FORMAT_TYPES:
        return ft
    mt = (media_type or '').upper()
    if 'AUDIO' in mt:
        return 'AUDIO'
    if mt in ('TEXT_SERMON', 'TEXT_ARTICLE', 'PDF_DOC', 'WIKI_SUMMARY'):
        return 'TEXT'
    if ft == 'IMAGE':            # 정적 이미지(INFOGRAPHIC 폐지) → 텍스트로 취급
        return 'TEXT'
    return DEFAULT_FORMAT


# ══════════════════════════════════════════════════════════════════════════
#  어긋남(drift) — 「지금 규칙대로면 유형이 달라지는 것」을 센다
# ══════════════════════════════════════════════════════════════════════════
#
# ★★★ **왜 필요한가** (2026-09-07 사용자 물음 — 「이런 상황이 발생했는지 어떤
#   지표를 통해서 미리 알 수 없다. 지표를 통해서 관리자가 알 수 있는 장치를
#   만들 수 있는가? 아니면 **매일 재분류실행을 눌러야 하는가**」).
#   ⇒ **매일 누를 일이 아니다.** 새로 수집되는 것은 수집 문이 이미 이 규칙으로
#     분류하므로 어긋나지 않는다. 어긋나는 자리는 딱 둘이다:
#       ① **키워드 규칙을 고쳤을 때** — 옛 규칙으로 찍힌 것이 그대로 남는다
#       ② **수집 경로가 딴 문을 쓸 때** — 2026-09-07 에 실제로 났다(RSS 가
#          `classify_media_type` 을 불러 11언어 낱말을 한 번도 못 썼다)
#   그래서 **①은 규칙을 저장할 때 묻고, ②는 이 지표가 잡는다.**
#
# ⚠⚠ **재분류가 보는 것과 똑같은 행을 봐야 한다** — 지표가 「219건 어긋남」이라
#   말해 놓고 [재분류 실행]을 눌러도 안 없어지면 그 지표는 못 쓰게 된다.
#   그래서 대상 조회를 `reclass_rows` **한 문**으로 두고 화면과 지표가 함께 쓴다.

#: 재분류가 다루는 내용유형. ⚠ 여기 없는 유형은 한 번 찍히면 영영 안 바뀐다
#: (§203차 ㉕ — STUDY·FILM 이 그래서 546건 굳어 있었다).
RECLASS_TYPES = ('SERMON', 'STUDY', 'WORSHIP', 'FILM')


# ★ 재분류·현황이 함께 쓰는 「연결 갈래」 축 — 구절 축은 단락과 구간 둘이다(§203차 ⑦).
#   ⚠ `media_link.types()` 는 **목록**을 받는다. 글자('PERICOPE')를 그대로 주면
#     글자 하나하나를 갈래로 읽어 빈 목록이 되고 **대상이 0건**이 된다(2026-09-08
#     실측 — 「구절단락만」「주요용어만」이 아무것도 안 돌았다).
SCOPE_AXIS = {'PERICOPE': ['PERICOPE', 'VERSE'], 'ENTITY': ['ENTITY']}


def scope_types(scope=None):
    """scope(None·'PERICOPE'·'ENTITY') → link_type 목록. 단일 문."""
    import media_link
    return media_link.types(SCOPE_AXIS.get(scope) if scope else None)


def reclass_rows(conn, scope=None, linked_only=False):
    """재분류·지표가 함께 보는 대상 행 → [(media_id, title, desc_json, lang, type)].

    ⚠⚠ **`linked_only` 기본이 거짓이다**(2026-09-07 바꿨다) — 그전에는 화면이
      늘 「연결이 있는 것만」으로 좁혀 **연결 없는 영상 1,771건(10%)이 재분류
      대상에서 통째로 빠졌다.** 그런데 **최신 콘텐츠는 연결과 무관하게 나가고
      `media_type` 을 함께 싣는다**(§199차 ⑬) — 곧 **틀린 유형이 그대로
      사용자에게 간다.** 「연결이 없으니 무해하다」가 성립하지 않는다.
    ⚠ `format_type='VIDEO'` 조건은 그대로 둔다 — 오디오·글은 분류 축이 다르다.
    """
    tw = ', '.join("'%s'" % t for t in RECLASS_TYPES)
    sw = ''
    if linked_only:
        import media_link
        ty = ', '.join("'%s'" % t for t in scope_types(scope))
        sw = ("AND EXISTS (SELECT 1 FROM %s l WHERE l.clicked_id=a.media_id "
              "AND l.link_type IN (%s)"
              # ⚠ 걷은 연결은 「연결된 것」이 아니다 — 안 걸면 사람이 뗀 영상이
              #   재분류 대상으로 되살아난다(2026-09-17).
              "AND COALESCE(l.record_status,'LIVE')='LIVE')" % (media_link.TBL, ty))
    return conn.execute(
        "SELECT a.media_id, a.title, a.description, a.lang_code, a.media_type "
        "FROM sys_media_asset a WHERE a.format_type='VIDEO' "
        "AND a.record_status='LIVE' "
        "AND (a.media_type IN (%s, 'YOUTUBE') OR COALESCE(a.media_type,'')='') %s"
        % (tw, sw)).fetchall()


def _row_text(title, desc_json):
    """분류에 넣을 재료 — **제목 + 채널명**.

    ⚠⚠ **설명문을 넣지 않는다**(2026-09-07 실측으로 정했다). 넣으면 RSS
      수집분 어긋남이 **50 → 91로 늘고** 판정이 나빠진다: 「예수님의 재림,
      확실히 알라ㅣ주일2부예배」(설교)가 찬양으로, 「Robin Hood & the Golden
      Arrow」가 성경공부로 갔다. 설명문에는 찬양 순서·채널 안내가 섞여 잡음이
      많다. **재료를 늘리는 것이 늘 나은 것은 아니다.**
    ★ 그리고 **수집·재분류·지표 셋이 같은 재료를 써야** [재분류 실행]을 누를
      때마다 값이 뒤집히지 않는다.
    """
    return '%s %s' % (title or '', row_channel(desc_json))


def row_channel(desc_json):
    """그 행의 채널 이름 — **`is_church_channel` 에 넘길 값.**

    ⚠ 재료 문과 갈라 두지 않는다 — 두 곳에서 뽑으면 한쪽만 고쳐진다.
    """
    import json as _j
    try:
        return (_j.loads(desc_json or '{}') or {}).get('channel') or ''
    except Exception:
        return ''


def drift(conn, sets=None, protect_admin=True, linked_only=False, limit=0):
    """어긋난 것 → (수, [(media_id, 지금, 새것, 제목)]).

    ⚠ `protect_admin` — 사람이 손으로 고친 것은 재분류가 안 건드리므로
      **어긋남으로 세지 않는다.** 세면 영영 0 이 안 되어 지표가 죽는다.
    """
    if sets is None:
        sets = load_classify_sets(conn)
    prot = set()
    if protect_admin:
        try:
            prot = {r[0] for r in conn.execute(
                "SELECT DISTINCT media_id FROM sys_media_correction "
                "WHERE corrected_by='ADMIN'")}
        except Exception:
            prot = set()
    out, n = [], 0
    for mid, title, dj, lang, cur in reclass_rows(conn, linked_only=linked_only):
        if mid in prot:
            continue
        new = classify_content(_row_text(title, dj), lang, sets,
                               channel=row_channel(dj))
        if new != (cur or ''):
            n += 1
            if not limit or len(out) < limit:
                out.append((mid, cur, new, title or ''))
    return n, out


#: 규칙을 마지막으로 고친 때 / 재분류를 마지막으로 돌린 때.
#: ★ 둘을 견주면 **「고쳐 놓고 재분류를 안 했다」**를 화면이 말할 수 있다.
#: ⚠ 어긋남 수(`drift`)만으로는 부족하다 — 규칙을 고쳤는데 어긋남이 0 일 수도
#:   있고(무해한 낱말), 그때도 「언제 고쳤나」는 남아야 다음에 되짚는다.
KW_CHANGED_KEY  = 'MEDIA_KW_CHANGED_AT'
RECLASS_RUN_KEY = 'MEDIA_RECLASS_AT'


def _cfg_get(conn, key):
    try:
        r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?",
                         (key,)).fetchone()
        return r[0] if r else ''
    except Exception:
        return ''


def _cfg_set(conn, key, val):
    conn.execute("INSERT OR REPLACE INTO sys_config (config_key, config_val)"
                 " VALUES (?,?)", (key, val))


def mark_kw_changed(conn, when=None):
    """키워드 규칙을 저장했다 — 그 시각을 남긴다."""
    from datetime import datetime
    _cfg_set(conn, KW_CHANGED_KEY,
             when or datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    conn.commit()


def mark_reclass_run(conn, when=None):
    """재분류를 돌렸다 — 그 시각을 남긴다."""
    from datetime import datetime
    _cfg_set(conn, RECLASS_RUN_KEY,
             when or datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    conn.commit()


def reclass_pending(conn):
    """(밀렸나, 규칙 고친 때, 재분류 돌린 때).

    ⚠ **규칙을 고친 적이 없으면 밀린 것도 없다** — 처음부터 빨갛게 두면
      그 표식이 죽는다(§115차 「늘 뜨는 경고는 아무도 안 읽는다」).
    """
    kw = _cfg_get(conn, KW_CHANGED_KEY)
    rc = _cfg_get(conn, RECLASS_RUN_KEY)
    if not kw:
        return False, kw, rc
    return (not rc or rc < kw), kw, rc


def health(conn, sets=None):
    """분류 건강 지표 한 묶음 — **화면이 이 한 문만 부른다.**

    ⇒ {'total','drift','pending','kw_at','run_at','unlinked'}
    ⚠ 화면마다 세면 숫자가 갈린다(§0-1 — 배지와 목록이 어긋나면 안 된다).
    """
    n_drift, _ = drift(conn, sets=sets, limit=0)
    pending, kw, rc = reclass_pending(conn)
    rows = reclass_rows(conn)
    linked = reclass_rows(conn, linked_only=True)
    return {'total': len(rows), 'drift': n_drift, 'pending': pending,
            'kw_at': kw, 'run_at': rc,
            'unlinked': len(rows) - len(linked)}


def reclassify(conn, scope=None, linked_only=False, protect_admin=True,
               on_log=None, commit=True):
    """재분류 — **이 문 하나가 유형을 다시 매긴다.**

    ★ 화면([재분류 실행])과 명령줄이 **같은 문**을 쓴다. 두 벌로 두면
      「화면으로 돌린 것과 명령줄로 돌린 것이 다르다」가 난다(§199차).
    ⚠ 사람이 손으로 고친 것(`corrected_by='ADMIN'`)은 안 건드린다.
    ⚠ 바꾼 것은 `sys_media_correction` 에 남긴다 — **되돌릴 근거이자
      키워드 규칙의 오답 노트**다(§203차 ⑤).
    ⇒ (바뀐 수, 건너뛴 수, 유형별 분포)
    """
    from collections import Counter
    from datetime import date
    sets = load_classify_sets(conn)
    prot = set()
    if protect_admin:
        try:
            prot = {r[0] for r in conn.execute(
                "SELECT DISTINCT media_id FROM sys_media_correction "
                "WHERE corrected_by='ADMIN'")}
        except Exception:
            prot = set()
    if on_log:
        on_log('수동 수정 보호 대상: %d건' % len(prot))
    rows = reclass_rows(conn, scope=scope, linked_only=linked_only)
    if on_log:
        on_log('재분류 대상: %d건' % len(rows))
    today = date.today().isoformat()
    dist = Counter()
    changed = skipped = 0
    for mid, title, dj, lang, old in rows:
        if mid in prot:
            skipped += 1
            continue
        ch = row_channel(dj)
        new = classify_content(_row_text(title, dj), lang, sets, channel=ch)
        dist[new] += 1
        if new != old:
            conn.execute("UPDATE sys_media_asset SET media_type=? WHERE media_id=?",
                         (new, mid))
            conn.execute(
                "INSERT INTO sys_media_correction (media_id, original_type,"
                " corrected_type, corrected_by, title_snapshot, channel_snapshot,"
                " lang_code, corrected_at) VALUES (?,?,?,?,?,?,?,?)",
                (mid, old, new, 'AUTO_RECLASSIFY', title, ch, lang, today))
            changed += 1
    if commit:
        conn.commit()
        mark_reclass_run(conn)
    return changed, skipped, dist


# ── selftest ────────────────────────────────────────────────────────────────
# ⚠ 이 파일에 원래 자가검증이 없었다(2026-09-09 신설) — 분류의 집인데 잣대가
#   없으면 낱말을 늘릴 때마다 조용히 오탐이 는다.

def selftest():
    ok = [0, 0]

    def t(nm, cond, extra=''):
        ok[1] += 1
        ok[0] += 1 if cond else 0
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, extra if not cond else ''))

    # ── 언어 짐작 ──
    t('★ 한글이 하나라도 있으면 KO(섞인 제목은 한국어 사용자의 것)',
      guess_lang('십자가 The Cross | 제이어스 J-US') == 'KO')
    t('★★ 한글이 아니면 EN 이 아니다 — 중국어를 가른다',
      guess_lang('【十字架 The Cross】官方歌詞版MV - 讚美之泉') == 'ZHT')
    t('  간체는 ZH', guess_lang('我的救赎者活着 (赞美之泉)简体中英拼音') == 'ZH')
    t('  가나가 있으면 JA', guess_lang('主の祈り 賛美') == 'JA')
    t('  아랍·러시아도', guess_lang('ترنيمة افرحى') == 'AR'
      and guess_lang('Канал о православном') == 'RU')
    t('  라틴만이면 기본값(글자로는 못 가른다 — 지어내지 않는다)',
      guess_lang('Leeland - Way Maker') == 'EN'
      and guess_lang('GÓLGOTA - Eula Paula', default='PT') == 'PT')
    t('  빈 글자는 기본값', guess_lang('') == 'EN' and guess_lang(None) == 'EN')

    # ── 판 갈래 ──
    t('  갈래 코드에 이름이 다 있다',
      all(k in REND_NAME_KO for k in REND_KINDS))
    t('★★ 갈래는 여럿일 수 있다(하나를 선택하면 한쪽을 잃는다)',
      rend_kinds('Living Hope | 1 Hour | Piano Instrumental', 'EN')
      == ['PLAYLIST', 'INSTRUMENTAL'])
    t('  악보 + 연속듣기도',
      set(rend_kinds('악보-주 예수 나의 산 소망(10회반복)', 'KO'))
      == {'SHEET', 'PLAYLIST'})
    t('★ 사용자가 중요하다 한 연속듣기를 잡는다',
      all(rend_kinds(x, 'KO') == ['PLAYLIST'] for x in
          ('[우리 주 안에서 노래하며] BEST CCM | 1시간 연속듣기',
           '찬양 모음 2시간 반복', '수면 찬양 플레이리스트')))
    t('★ AI 생성 음악을 갈래로 읽는다(근거 낱말이 있을 때만)',
      'AI_GEN' in rend_kinds('주님 앞에 머무는 사람 #ai찬양 #ccm', 'KO')
      and 'AI_GEN' in rend_kinds('Holy Spirit Lullabies (Suno)', 'EN')
      and 'AI_GEN' not in rend_kinds('Hawaii music worship night', 'EN')
      and 'AI_GEN' not in rend_kinds('Defeat at Ai | Joshua 7', 'EN'))
    t('  오타 Palylist 도 잡는다',
      'PLAYLIST' in rend_kinds('[트롯찬양] 십자가의 노래 모음 Palylist', 'KO'))
    t('  한국 교회 말(찬양대·성가대)을 안다',
      all('CHOIR' in rend_kinds(x, 'KO') for x in
          ('3부_갈렙 찬양대 | 주 예수 나의 산 소망', '임마누엘 성가대 기억하네')))
    t('  반주 표기 넷(MR·AR·instrumental·반주)',
      all('INSTRUMENTAL' in rend_kinds(x, 'KO') for x in
          ('언제나 주만_제이어스 Ver.AR (가사포함)', '그는 졸지 않고 MR | INSTRUMENTAL',
           '[찬양MR] 우리 주 안에서 노래하며', '[원곡 그대로 피아노반주] 우리 주 안에서')))
    t('  중국어 갈래 표기(官方歌詞版MV)',
      set(rend_kinds('【十字架 The Cross】官方歌詞版MV - 讚美之泉', 'ZHT'))
      == {'OFFICIAL', 'LYRICS'})
    # ⚠⚠ 홑낱말 함정 — 실측으로 잡은 것
    for _t in ('All About The Feast of Tabernacles - Sukkot',
               'MOSES: The Tablets of Stone', 'WORSHIP TABLE 예배를 다시 배우는 자리'):
        t('  ★★ 「tab」 이 Tabernacle·Tablets 를 안 먹는다',
          'SHEET' not in rend_kinds(_t, 'EN'), (_t[:30], rend_kinds(_t, 'EN')))
    t('★ 보통 찬양은 빈 목록(억지로 하나를 안 붙인다)',
      rend_kinds('우리 주 안에서 노래하며 - 잔치공동체', 'KO') == [])
    t('  빈 제목도 빈 목록', rend_kinds('', 'KO') == [] and rend_kinds(None) == [])
    t('  화면 이름 한 줄',
      rend_label(['PLAYLIST', 'INSTRUMENTAL']) == '연속듣기 · 반주'
      and rend_label([]) == '')

    # ── 축이 서로 겹치지 않는다 ──
    t('★ 판 갈래가 내용·형태·대상 축과 안 겹친다',
      not (set(REND_KINDS) & (set(CONTENT_TYPES) | set(FORMAT_TYPES)
                              | set(AUDIENCE_TYPES))))
    # ── 분위기·반주 악기 (2026-09-10) ──────────────────────────────
    t('★★★ **분위기는 형용사로 읽는다**',
      moods('잔잔한 찬양 모음', 'KO') == ['CALM']
      and moods('신나는 찬양', 'KO') == ['UPBEAT'])
    t('★★ 여럿이 정상이다',
      set(moods('잠들며 듣는 잔잔한 찬양', 'KO')) == {'CALM', 'SLEEP'})
    t('★★ 라틴도 읽는다',
      moods('Peaceful Worship Instrumental', 'EN') == ['CALM'])
    t('★★★ **명사는 안 넣었다** — 「은혜 찬양」은 분위기가 없다',
      moods('은혜 찬양 모음', 'KO') == [])
    t('★★★ **`old` 홑낱말이 `gold`·`hold` 를 안 먹는다**',
      moods('Hold Me Fast', 'EN') == [] and moods('Golden Bells', 'EN') == []
      and moods('Old Hymns Classic', 'EN') == ['OLD'])
    t('★★★ **한국어 「기타」가 「기타 등등」을 안 먹는다**',
      instruments('찬양 기타 연주', 'KO') == ['GUITAR']
      and 'GUITAR' not in instruments('찬양 기타 등등 모음', 'KO'))
    t('★★ 악기를 읽는다',
      instruments('색소폰 찬송가 연주', 'KO') == ['SAX']
      and instruments('worship piano instrumental', 'EN') == ['PIANO', 'MR'])
    t('★ 아무것도 없으면 빈 목록',
      moods('주 예수 나의 산 소망', 'KO') == []
      and instruments('주 예수 나의 산 소망', 'KO') == [])
    t('★★ 두 축이 서로 겹치지 않는다',
      not (set(MOOD_KINDS) & set(INST_KINDS)))
    t('★★ 다른 축과도 안 겹친다(내용·형태·대상·판 갈래)',
      not ((set(MOOD_KINDS) | set(INST_KINDS)) &
           (set(CONTENT_TYPES) | set(FORMAT_TYPES) | set(AUDIENCE_TYPES))))
    t('★★★ **목록이 데이터다** — 코드로 읽고 이름은 따로 찾는다',
      [x['code'] for x in _axis_default(MOOD_KINDS, MOOD_NAME_KO, MOOD_KW)]
      == list(MOOD_KINDS))
    t('★★★ **이름을 바꿔도 이미 붙은 코드는 그대로**',
      _axis_read('조용한 찬양', 'KO',
                 [{'code': 'CALM', 'name': '완전히 다른 이름',
                   'kw': {'KO': ['조용한']}}]) == ['CALM'])
    t('★★ **모르는 코드는 코드 그대로 보인다**(지워도 안 죽는다)',
      axis_name([{'code': 'CALM', 'name': '잔잔한'}], 'GONE') == 'GONE'
      and axis_name([{'code': 'CALM', 'name': '잔잔한'}], 'CALM') == '잔잔한')
    t('★★ 목록을 늘리면 그대로 읽는다(코드 변경 없이)',
      _axis_read('경건한 찬양', 'KO',
                 [{'code': 'NEWONE', 'name': '경건한',
                   'kw': {'KO': ['경건한']}}]) == ['NEWONE'])
    t('★ 이름표가 빠짐없이 있다',
      all(k in MOOD_NAME_KO for k in MOOD_KINDS)
      and all(k in INST_NAME_KO for k in INST_KINDS))

    # ── 판 갈래 켜고 끄기(1.txt 17번 3) 재분류) ──────────────────────
    import sqlite3 as _sq
    import json as _js2
    _c = _sq.connect(':memory:')
    _c.execute("CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY,"
               " description TEXT)")
    _c.execute("INSERT INTO sys_media_asset VALUES(1, ?)",
               (_js2.dumps({'rend_kind': ['INSTRUMENTAL'], 'mood': ['CALM']}),))
    _c.execute("INSERT INTO sys_media_asset VALUES(2, '')")

    def _k(mid):
        r = _c.execute("SELECT COALESCE(description,'') FROM sys_media_asset"
                       " WHERE media_id=?", (mid,)).fetchone()[0]
        return (_js2.loads(r) if r.startswith('{') else {})

    t('★★ 갈래를 켠다', set_rend_kind(_c, [1], 'PLAYLIST') == (1, 0)
      and 'PLAYLIST' in _k(1).get('rend_kind', []), _k(1))
    t('★★★ **다른 갈래는 안 건드린다**',
      'INSTRUMENTAL' in _k(1).get('rend_kind', []) and _k(1).get('mood'), _k(1))
    t('★ 다시 부르면 끈다(토글)', set_rend_kind(_c, [1], 'PLAYLIST') == (0, 1)
      and 'PLAYLIST' not in _k(1).get('rend_kind', []), _k(1))
    t('★ on=True 로 못 박는다',
      set_rend_kind(_c, [1], 'PLAYLIST', on=True) == (1, 0)
      and set_rend_kind(_c, [1], 'PLAYLIST', on=True) == (0, 0), _k(1))
    t('★★ 마지막 갈래를 끄면 **칸을 지운다**(「없음」과 「안 재 봤음」을 가른다)',
      set_rend_kind(_c, [2], 'PLAYLIST', on=True) == (1, 0)
      and set_rend_kind(_c, [2], 'PLAYLIST', on=False) == (0, 1)
      and 'rend_kind' not in _k(2), _k(2))
    t('★★ 목록에 없는 갈래는 **거부한다**',
      set_rend_kind(_c, [1], 'NOPE') == (0, 0))
    _c.close()

    # ── 기도 갈래(2026-10-12) — 기본 낱말만으로 잰다(DB 설정에 기대지 않는다) ──
    _s = {c: DEFAULT_CLASSIFY_KW.get(c, {}) for c in CONTENT_KW_CATS}
    t('★ 기도 낱말 — 기도문·기도회는 기도', classify_content('치유 기도 | 잠들기 전 기도', 'KO', _s) == 'PRAYER'
      and classify_content('Powerful Morning Prayer', 'EN', _s) == 'PRAYER')
    t('★ 동점이면 설교 — 기도에 관한 설교는 설교', classify_content('Predigt über das Gebet', 'DE', _s) == 'SERMON'
      and classify_content('기도의 능력 - 주일 설교', 'KO', _s) == 'SERMON')
    t('  기도 + 찬양이면 찬양을 안 이긴다', classify_content('1 hour worship and prayer', 'EN', _s) == 'WORSHIP')
    t('  11언어 기도 낱말', all(DEFAULT_PRAYER_KW.get(l) for l in
                             ('KO', 'JA', 'ZH', 'ZHT', 'DE', 'FR', 'ES', 'PT', 'RU', 'AR')))

    print('media_taxonomy selftest %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    import sys as _sys
    try:
        _sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass
    if '--selftest' in _sys.argv:
        _sys.exit(0 if selftest() else 1)
    print('사용법: --selftest')
