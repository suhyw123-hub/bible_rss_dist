"""db_lens_plan.py — 렌즈를 묵상플랜으로 등록한다 (영구 도구).

2026-08-15 사용자 결정 — **렌즈묵상을 묵상플랜으로 한다(A안).**
그래야 등록·진행중 콤보·완료 이력이 다른 세 서브탭과 **같은 길**을 쓴다.

    렌즈 하나(`sys_unit_asset` CONTAINER, cat_id 100~108)
        → 플랜 하나(`sys_bible_plan`, plan_type='LENS', plan_code='LENS_<id>')

★ **스케줄 행을 만들지 않는다.** 이것이 이 설계의 핵심이다.
  · 진행중 콤보(`plan_active_bar.active_enrollments`)는 `sys_bible_plan` 과
    `sys_plan_category.scope` 만 읽는다 — **스케줄을 보지 않는다**(실측).
  · 완료 여부·완료 날짜도 `user_plan_enrollment`(enrollment_status·end_date)에 있다.
  · 렌즈는 **날짜 관리가 필요 없다**(사용자 지시). 일차를 만들 이유가 없다.
  ⚠ 그리고 `sys_plan_schedule.start_vid`·`end_vid` 는 **NOT NULL** 인데
    실측하니 렌즈 하나(cid=152)는 연결된 구절이 **0개**다. 스케줄을 만들려 했다면
    없는 구절을 지어내야 했다 — 오늘 판본 문제에서 배운 그 함정이다.

⚠ **렌즈는 계속 늘어난다.** 새 렌즈를 만들면 이 도구를 다시 돌린다(멱등).
   `temp_` 를 붙이지 않은 이유다(§0-4 — 반복 실행할 도구가 그 이름 때문에 사라진 전례).

사용:
    python db_lens_plan.py --selftest    (의무)
    python db_lens_plan.py --check
    python db_lens_plan.py --apply
"""
import sys
import appdb

# (옛 LENS_CAT_LO/HI 범위 상수는 폐기 — lens_cats() 가 scope='LENS' 를 읽는다)
PLAN_TYPE = 'LENS'
CODE = 'LENS_%d'


def lens_cats(conn):
    """LENS 카테고리 목록 — `sys_plan_category(scope='LENS')` 가 단일 소스.
    ⚠ 예전에는 `BETWEEN 100 AND 108` 하드코딩이라 **신설 cat 109(교회론)가
      빠져**, 그리로 옮긴 LIVE 렌즈(172)를 「없어진 렌즈」로 오판해 플랜을
      내렸다(2026-08-18 실측). 카테고리를 늘리면 여기가 저절로 따라온다."""
    return [r[0] for r in conn.execute(
        "SELECT cat_id FROM sys_plan_category WHERE scope='LENS' "
        "AND COALESCE(record_status,'LIVE')='LIVE'")]


def lenses(conn):
    """LIVE 인 렌즈 컨테이너. `(sys_unit_id, cat_id, 이름, 노드수)`"""
    out = []
    cats = lens_cats(conn)
    if not cats:
        return out
    marks = ','.join('?' * len(cats))
    for cid, cat, name in conn.execute(
            "SELECT sys_unit_id, cat_id, unit_name_sid FROM sys_unit_asset "
            "WHERE unit_type='CONTAINER' AND cat_id IN (%s) " % marks +
            "  AND COALESCE(record_status,'LIVE')='LIVE' "
            "ORDER BY cat_id, sort_order, sys_unit_id", cats):
        n = conn.execute(
            "SELECT COUNT(*) FROM sys_link_asset WHERE clicked_id=? "
            "AND link_type='CONT_NODE' AND COALESCE(record_status,'LIVE')='LIVE'",
            (cid,)).fetchone()[0]
        out.append((cid, cat, name or ('렌즈 %d' % cid), n))
    return out


def plan_of(conn, cid):
    r = conn.execute("SELECT plan_id, cat_id, record_status FROM sys_bible_plan "
                     "WHERE plan_code=?", (CODE % cid,)).fetchone()
    return r


def check(conn, quiet=False):
    rows = lenses(conn)
    _p = (lambda *a: None) if quiet else print
    _p('렌즈 %d개' % len(rows))
    _p('%-6s %-5s %-5s %-26s %s' % ('cid', 'cat', '노드', '이름', '플랜'))
    for cid, cat, name, n in rows:
        p = plan_of(conn, cid)
        st = ('plan_id=%s%s' % (p[0], '' if p[2] == 'LIVE' else ' (%s)' % p[2])
              if p else '없음 → 새로 만든다')
        _p('%-6s %-5s %-5s %-26s %s' % (cid, cat, n, (name or '')[:26], st))
    # 렌즈가 사라졌는데 플랜만 남은 것
    live = {cid for cid, *_ in rows}
    orphan = [(pid, code) for pid, code in conn.execute(
        "SELECT plan_id, plan_code FROM sys_bible_plan "
        "WHERE plan_type=? AND record_status='LIVE'", (PLAN_TYPE,))
        if int(code.split('_')[1]) not in live]
    if orphan:
        _p('')
        _p('⚠ 렌즈가 없어졌는데 남은 플랜 %d개 → HIDE 로 내린다:' % len(orphan))
        for pid, code in orphan:
            _p('   plan_id=%s %s' % (pid, code))
    return rows, orphan


def apply_(conn):
    """바깥에서 부르는 것 — 속을 돌리고 커밋한다."""
    n = _apply_core(conn)
    conn.commit()
    return n


def _apply_core(conn, quiet=False):
    """⚠ **여기서 커밋하지 않는다.** selftest 가 `BEGIN … ROLLBACK` 으로 감싸는데,
    속에서 커밋하면 되돌리기가 통째로 무력해진다 — 실제로 그렇게 당해서
    시험이 실제 DB 에 플랜 3행을 남겼다(2026-08-15)."""
    rows, orphan = check(conn, quiet=quiet)
    made = upd = 0
    for cid, cat, name, _n in rows:
        p = plan_of(conn, cid)
        if p is None:
            conn.execute(
                "INSERT INTO sys_bible_plan "
                "(plan_code, plan_type, plan_category, cat_id, duration_days, "
                " track_count, record_status) VALUES (?,?,?,?,1,1,'LIVE')",
                (CODE % cid, PLAN_TYPE, 'THEMATIC', cat))
            pid = conn.execute("SELECT plan_id FROM sys_bible_plan WHERE plan_code=?",
                               (CODE % cid,)).fetchone()[0]
            made += 1
        else:
            pid = p[0]
            # 렌즈가 다른 갈래로 옮겨갔거나 되살아났을 수 있다
            conn.execute("UPDATE sys_bible_plan SET cat_id=?, record_status='LIVE' "
                         "WHERE plan_id=?", (cat, pid))
            upd += 1
        # 제목 — 렌즈 이름을 그대로. ⚠ 지금은 KO 만이다(렌즈 이름이 한 칸뿐).
        #   다른 언어는 다른 플랜과 같이 `PLAN_TITLE` 행을 더하면 된다.
        cur = conn.execute(
            "SELECT sys_text_id FROM sys_text_asset WHERE text_type='PLAN_TITLE' "
            "AND clicked_id=? AND lang_code='KO'", (pid,)).fetchone()
        if cur:
            conn.execute("UPDATE sys_text_asset SET contents=?, record_status='LIVE' "
                         "WHERE sys_text_id=?", (name, cur[0]))
        else:
            conn.execute(
                "INSERT INTO sys_text_asset (clicked_id, text_type, contents, "
                " lang_code, record_status) VALUES (?,'PLAN_TITLE',?, 'KO','LIVE')",
                (pid, name))
    for pid, _code in orphan:
        # ⚠ 지우지 않는다 — 등록 기록이 이 plan_id 를 가리킨다. 내리기만 한다.
        conn.execute("UPDATE sys_bible_plan SET record_status='HIDE' WHERE plan_id=?",
                     (pid,))
    if not quiet:
        print()
        print('새로 %d개 · 갱신 %d개 · 내림 %d개' % (made, upd, len(orphan)))
    return made, upd, len(orphan)


def selftest():
    """만들고 → 확인하고 → 되돌린다."""
    conn = appdb.connect()
    ok = True
    before_plan = conn.execute(
        "SELECT COUNT(*) FROM sys_bible_plan WHERE plan_type=?", (PLAN_TYPE,)).fetchone()[0]
    before_txt = conn.execute(
        "SELECT COUNT(*) FROM sys_text_asset WHERE text_type='PLAN_TITLE'").fetchone()[0]
    rows = lenses(conn)
    if not rows:
        print('FAIL 렌즈가 하나도 없다 — 시험할 것이 없다'); conn.close(); return False
    try:
        conn.execute('BEGIN')
        _apply_core(conn, quiet=True)
        n = conn.execute("SELECT COUNT(*) FROM sys_bible_plan "
                         "WHERE plan_type=? AND record_status='LIVE'",
                         (PLAN_TYPE,)).fetchone()[0]
        if n != len(rows):
            print('FAIL 플랜 수 %d ≠ 렌즈 수 %d' % (n, len(rows))); ok = False

        # ★ 진행중 콤보가 실제로 집는지 — 등록을 하나 넣어 본다
        pid = conn.execute("SELECT plan_id FROM sys_bible_plan WHERE plan_code=?",
                           (CODE % rows[0][0],)).fetchone()[0]
        conn.execute(
            "INSERT INTO user_plan_enrollment (plan_id, start_date, current_day, "
            " enrollment_status, record_status) VALUES (?,?,1,'ACTIVE','LIVE')",
            (pid, '2026-01-01'))
        # ⚠ `active_enrollments` 는 **자기 연결을 새로 연다** — 우리 트랜잭션 밖이라
        #   아직 커밋 안 된 행을 못 본다. 그래서 여기서는 같은 연결로 직접 확인한다.
        #   (`db_path=None` 을 넘겼다가 「no such table」이 났다 — 경로 해석 실패였다.)
        got = conn.execute(
            "SELECT c.scope FROM user_plan_enrollment e "
            "JOIN sys_bible_plan p ON p.plan_id=e.plan_id "
            "LEFT JOIN sys_plan_category c ON c.cat_id=p.cat_id "
            "WHERE e.plan_id=? AND e.enrollment_status='ACTIVE'", (pid,)).fetchall()
        if not got:
            print('FAIL 진행중 콤보 조회가 렌즈를 못 집는다'); ok = False
        elif got[0][0] != 'LENS':
            print('FAIL 갈래가 LENS 가 아니다:', got[0][0]); ok = False

        # 두 번 돌려도 늘지 않는가 (멱등)
        _apply_core(conn, quiet=True)
        n2 = conn.execute("SELECT COUNT(*) FROM sys_bible_plan "
                          "WHERE plan_type=? AND record_status='LIVE'",
                          (PLAN_TYPE,)).fetchone()[0]
        if n2 != n:
            print('FAIL 다시 돌리니 %d → %d 로 늘었다' % (n, n2)); ok = False

        # 스케줄을 만들지 않았는가 (이 설계의 핵심)
        sc = conn.execute(
            "SELECT COUNT(*) FROM sys_plan_schedule WHERE plan_id IN "
            "(SELECT plan_id FROM sys_bible_plan WHERE plan_type=?)",
            (PLAN_TYPE,)).fetchone()[0]
        if sc:
            print('FAIL 스케줄 행을 만들었다:', sc); ok = False
    finally:
        conn.rollback()
    a1 = conn.execute("SELECT COUNT(*) FROM sys_bible_plan WHERE plan_type=?",
                      (PLAN_TYPE,)).fetchone()[0]
    a2 = conn.execute(
        "SELECT COUNT(*) FROM sys_text_asset WHERE text_type='PLAN_TITLE'").fetchone()[0]
    if (a1, a2) != (before_plan, before_txt):
        print('FAIL 되돌리기가 안 됐다: 플랜 %d→%d · 제목 %d→%d'
              % (before_plan, a1, before_txt, a2)); ok = False
    conn.close()
    print('selftest', 'OK' if ok else 'FAIL')
    return ok


if __name__ == '__main__':
    arg = sys.argv[1] if len(sys.argv) > 1 else '--check'
    if arg == '--selftest':
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect()
    (apply_ if arg == '--apply' else check)(conn)
    conn.close()
