# -*- coding: utf-8 -*-
"""gcloud_gate.py — **구글 클라우드에 닿는 기능의 일시 중단 스위치** (2026-09-16 신설·영구).

사용자: 「구글클라우드 무료 체험판이 종료되었다고 이메일이 왔다. 지금 구글클라우드에 연결된
기능을 일단 중단시켜야겠다. 전송/수집 등의 기능이 있다면 일시 중단하도록 … 앱 개발이 끝나고
나서 근본적인 대책을 만들어야겠다.」

★ 구글에 닿는 길은 셋이다(2026-09-16 전수 실측 — `googleapis`·`script.google` 검색):
  | 길 | 무엇 | 어디서 | 이 스위치가 하는 일 |
  |---|---|---|---|
  | **YouTube Data API v3** | 구절·용어 검색 수집 · 찬양/성경듣기 씨앗 검색 · 곡 이름 검색 · 링크 점검(`videos.list`) · 채널 주소 점검 · 구독자 · 채널 자동 발굴 · 관리자 화면의 [찾기]·[유효성 검사] | `db_media_crawler` · `db_worship_collect` · `db_song_collect` · `db_media_linkcheck` · `db_channel_mine` · `collect_channels` · 관리자 패널 여섯 | **API 키를 `YOUTUBE_API_KEYS_PAUSED` 로 옮기고 `YOUTUBE_API_KEYS` 를 비운다** — 키를 읽는 자리가 아홉 곳이라 문마다 고치지 않고 **키가 없으면 각자 이미 「키 없음」으로 멈추는 길**을 쓴다. 매일 작업의 API 걸음은 이름을 대고 건너뛴다 |
  | **Cloud Translation v2**(유료) | 최신 콘텐츠 발행 때 제목 번역 | `cloud_translate` ← `rss_publish` | `translate_batch` 가 첫 줄에서 거부한다 |
  | **Apps Script**(구글 계정의 스크립트 — 청구 계정과 무관하지만 사용자 지시 「전송 … 일시 중단」) | 사용자 문의 전송 · 답글 수신 | `user_feedback.submit`·`sync_replies` | 보내지 않고 까닭을 돌려준다 |
  ⚠ **안 건드리는 것** — RSS(`youtube_channel_rss`·`rss_reader` — 키 없이 공개 피드) ·
    사용량 집계(`usage_stats` → `api.hagahtorah.com` 은 **Cloudflare**) · `admin_translate` 의 비공식 gtx 통로
    (키 없는 웹 통로 — 구글 클라우드 청구와 무관). 자동 승인·사역자 잇기·갈래 규칙은 쿼터 0 이라 그대로 돈다.
  ⚠ 자동실행 작업 셋 중 **특수 성경듣기·찬양(WOR)·채널 발굴(DIS)은 API 뿐**이라 작업 스케줄러에서 **끈다**
    (`schtasks /change /disable`). 일반(GEN)은 RSS·자동 승인이 있어 그대로 두고 API 걸음만 건너뛴다.

쓰는 법 — `python gcloud_gate.py --pause` · `--resume` · `--status` · `--selftest`.
  관리자 ▸ YouTube API 키 관리 화면에도 같은 단추가 있다.
★ 스위치는 `sys_config['GCLOUD_PAUSED']`('1'/'0') 하나 — 배포 DB 표이지만 관리자 PC 의 값이다.
"""
import io
import os
import sys
import sqlite3

FLAG = 'GCLOUD_PAUSED'
KEYS = 'YOUTUBE_API_KEYS'
KEYS_BAK = 'YOUTUBE_API_KEYS_PAUSED'
MSG = '구글 클라우드 일시 중단 중 — 무료 체험 종료(2026-09-16). 재개는 관리자 ▸ YouTube API 키 관리 [재개] 또는 gcloud_gate --resume'
#: 이 스위치가 끄는 작업 스케줄러 작업(전부 API 뿐인 것)
TASKS_OFF = ('BibleMatrix_WorshipCollect', 'BibleMatrix_ChannelDiscover', 'BibleMatrix_PrayerCollect')


def _open(db_path=None):
    import appdb
    return appdb.connect(db_path) if db_path else appdb.connect()


def _get(conn, key):
    # ★ 2026-10-11 — 열쇠(KEYS·KEYS_BAK)는 배포 DB 밖(secret_store) · 중단 표식(FLAG)만 sys_config
    import secret_store as _SS
    if key in _SS.NAMES:
        return _SS.get(key) or ''
    r = conn.execute("SELECT config_val FROM sys_config WHERE config_key=?", (key,)).fetchone()
    return (r[0] or '') if r else ''


def _set(conn, key, val):
    import secret_store as _SS
    if key in _SS.NAMES:
        _SS.put(key, val)
        return
    conn.execute("INSERT INTO sys_config(config_key, config_val) VALUES(?,?)"
                 " ON CONFLICT(config_key) DO UPDATE SET config_val=excluded.config_val", (key, val))


def paused(conn=None, db_path=None):
    """지금 중단 중인가. 연결이 없으면 열어서 본다 · 못 열면 **중단 아님**(조용히 막지 않는다)."""
    own = conn is None
    try:
        if own:
            conn = _open(db_path)
        return _get(conn, FLAG).strip() == '1'
    except Exception:
        return False
    finally:
        if own and conn is not None:
            try:
                conn.close()
            except Exception:
                pass


def status(conn):
    return {'paused': _get(conn, FLAG).strip() == '1',
            'keys': len([k for k in _get(conn, KEYS).split(',') if k.strip()]),
            'keys_paused': len([k for k in _get(conn, KEYS_BAK).split(',') if k.strip()])}


def _tasks(on):
    out = {}
    try:
        import task_sched as TS
        for nm in TASKS_OFF:
            out[nm] = TS.set_enabled(nm, on)
    except Exception as e:
        out['error'] = str(e)[:80]
    return out


def pause(conn, tasks=True):
    """중단 — 표식 · 키 보관 · API 뿐인 작업 끄기. 멱등(이미 보관한 키를 덮지 않는다)."""
    keys = _get(conn, KEYS)
    if keys.strip():
        _set(conn, KEYS_BAK, keys)         # 있는 것만 옮긴다 — 빈 값으로 보관분을 덮지 않는다
        _set(conn, KEYS, '')
    _set(conn, FLAG, '1')
    conn.commit()
    r = status(conn)
    r['tasks'] = _tasks(False) if tasks else {}
    return r


def resume(conn, tasks=True):
    """재개 — 키를 되돌리고 표식을 내리고 작업을 켠다. 멱등."""
    bak = _get(conn, KEYS_BAK)
    if bak.strip() and not _get(conn, KEYS).strip():
        _set(conn, KEYS, bak)
        _set(conn, KEYS_BAK, '')
    _set(conn, FLAG, '0')
    conn.commit()
    r = status(conn)
    r['tasks'] = _tasks(True) if tasks else {}
    return r


def selftest():
    ok = [0, 0]

    def t(nm, cond, got=''):
        ok[0 if cond else 1] += 1
        print('  %s %s %s' % ('OK  ' if cond else 'FAIL', nm, got if not cond else ''))
    c = sqlite3.connect(':memory:')
    c.execute("CREATE TABLE sys_config(config_key TEXT PRIMARY KEY, config_val TEXT)")
    # 열쇠 집은 시험용 파일로(진짜 admin_secrets.db 에 닿지 않는다)
    import tempfile
    import secret_store as _SS
    _ss_old = _SS.FILE
    _SS.FILE = os.path.join(tempfile.mkdtemp(prefix='gg_st_'), 's.db')
    _SS.put(KEYS, 'AAA,BBB')
    t('처음은 중단 아님', not paused(c))
    r = pause(c, tasks=False)
    t('★★★ 중단하면 키가 비고 보관함으로 간다', r['paused'] and r['keys'] == 0 and r['keys_paused'] == 2, r)
    t('  paused() 가 참', paused(c))
    r2 = pause(c, tasks=False)
    t('  두 번 중단해도 보관한 키를 빈 값으로 덮지 않는다(멱등)', r2['keys_paused'] == 2, r2)
    r3 = resume(c, tasks=False)
    t('★★ 재개하면 키가 돌아오고 표식이 내려간다', (not r3['paused']) and r3['keys'] == 2 and r3['keys_paused'] == 0, r3)
    t('  두 번 재개해도 그대로', resume(c, tasks=False)['keys'] == 2)
    # 문마다 — 소스에 스위치가 걸려 있는가
    import inspect
    import collect_channels as CC
    import user_feedback as UF
    import cloud_translate as CT
    t('★★ 매일 작업의 API 걸음(링크 점검·찬양 한 바퀴·채널 발굴·API 수집)이 스위치를 본다',
      all('gcloud_gate' in inspect.getsource(f) for f in (CC.collect, CC._link_check, CC._worship_round, CC._discover_round)))
    t('★★ 문의 전송·답글 수신이 스위치를 본다',
      'gcloud_gate' in inspect.getsource(UF.submit) and 'gcloud_gate' in inspect.getsource(UF.sync_replies))
    t('★★ 유료 번역(Cloud Translation)이 스위치를 본다', 'gcloud_gate' in inspect.getsource(CT.translate_batch))
    t('  RSS 수집은 스위치를 안 본다(공개 피드 · 구글 클라우드 아님)',
      'gcloud_gate' not in inspect.getsource(CC._rss_phase))
    _SS.FILE = _ss_old                     # 열쇠 집을 진짜로 되돌린다
    print('gcloud_gate selftest %d/%d' % (ok[0], ok[0] + ok[1]))
    return ok[1] == 0


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    conn = _open()
    try:
        if '--pause' in a:
            print('중단:', pause(conn))
        elif '--resume' in a:
            print('재개:', resume(conn))
        else:
            print('상태:', status(conn))
    finally:
        conn.close()
