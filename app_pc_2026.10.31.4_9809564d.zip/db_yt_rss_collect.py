# -*- coding: utf-8 -*-
"""db_yt_rss_collect.py — 유튜브 **채널 RSS 수집기** (2026-09-05 신설·영구).

★★★ 왜 (사용자 확정 설계):
  「유투브 RSS를 통해서 한 채널당 15개 최신 자료를 가져온다면 좋다.
   **API 사용한도가 매우 부담스럽다.** … RSS를 매일 돌리고 필터링 로직은
   현재의 유투브 검토기능으로 수행하면 상당히 자동화된다. 그러면 **진정한
   최신유투브**가 된다.」

★★ **실측이 그 판단을 받쳤다** — 값이 셋이다:
  ① **설명문 32% → 100%** — `search.list` 의 snippet 은 **140자에서 잘리고**
     전문을 받으려면 `videos.list` 를 또 부른다(§194차). RSS 는 **한 번에
     전문**을 준다(실측 816~1,670자). 제목에 좌표가 없는 영상은 설명문이
     유일한 단서라 구간·용어 추출이 그만큼 정확해진다.
  ② **쿼터 0** — 지금 122채널이면 API 도 부담이 아니지만 **채널은 계속 는다.**
     RSS 는 몇 개가 되든 0이다.
  ③ **진짜 최신** — RSS 는 게시일 내림차순이다.

⚠⚠ **자동크롤러를 없애지 않는다** — 그 화면이 하는 일 셋 중 하나만 대체된다:
    ① 등록 채널 주기 수집   → **이 도구가 대신한다**
    ② 키워드 발굴(search)  → RSS 로 못 한다(채널을 알아야 쓴다)
    ③ 눈덩이 발굴          → 못 한다
  **새 채널의 과거 영상**도 RSS 로는 못 온다(15개뿐) ⇒ 처음 등록할 때 한 번은
  playlistItems 로 긁고 **그 뒤로는 이 도구**가 맡는다.

⚠ **저장 규칙은 자동크롤러와 똑같다** — `is_active=0`(검토 대기) ·
  `description` JSON(channel·published·yt_desc·collected_at) · 저장 직후
  `link_media` 로 구간·용어 연결. **검토·연결·승인은 한 줄도 안 바꾼다.**
  두 수집기가 다른 모양으로 저장하면 검토 화면이 갈린다.

⚠ **채널 표에 이미 있는 값을 따른다** — `exclude_shorts`(쇼츠 거르기) ·
  `check_interval_days`(며칠마다) · `is_kids`. 여기서 새 규칙을 만들지 않는다.

    python db_yt_rss_collect.py --selftest      (의무)
    python db_yt_rss_collect.py --list          등록 채널·마지막 확인·주기
    python db_yt_rss_collect.py --run --dry     저장하지 않고 세기만
    python db_yt_rss_collect.py --run           수집(신규만 · 멱등)
    python db_yt_rss_collect.py --run --all     주기를 안 따지고 전부
    python db_yt_rss_collect.py --run --ch 12   그 채널만
"""
import io
import json
import sys
import time
from datetime import datetime, timedelta

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

import appdb                                                  # noqa: E402
import youtube_channel_rss as ycr                             # noqa: E402

#: 채널 사이 쉬는 시간(초). ⚠ 남의 서버를 두드리는 일이다 — 몰아치지 않는다.
#: ⚠⚠⚠ **RSS 는 쿼터 0 이지만 무한하지 않다**(2026-09-12 실측) — 30분에
#:   3,600번 두드리자 같은 채널 id 가 **404·500** 을 쏟아냈다(30분 전에는
#:   되던 것이다). 채널이 288 → 2,426곳으로 늘었으므로 한 바퀴가 그만큼 길다.
#:   ⇒ 0.4 → **1.0**(1 req/s). 하루 276곳이면 **5분**이라 값이 싸다.
GAP = 1.0
#: 잇달아 이만큼 실패하면 **한 번 물러선다**(막혔을 때 더 두드리지 않는다)
BACKOFF_AFTER = 5
#: 물러서는 시간(초)
BACKOFF_SEC = 30


#: ★★★ **주기는 그 채널이 올리는 속도가 정한다**(2026-09-12 사용자 「자동
#:   크롤러의 수집 주기가 **매일 단위로 바뀌어야** 비로소 최신 의미가 살아난다.
#:   모두 매일 수집 단위로 수정하면 **어떤 문제가 발생**할 수 있는가」).
#:   ✅ 재서 답했다 — 전부 매일 돌면 하루 2,351회인데 **실제로 담기는 것은
#:     하루 95편**이다. 대부분은 빈 RSS 를 받는다.
#:   ⚠⚠⚠ **그런데 「최신 목록에 들 수 있는가」로 보면 달라진다** — 언어별
#:     30개 상한이 걸리면 한국어는 하루 181편이 들어와 **상위 30편이 약 네
#:     시간치**다. 늦게 담으면 **영영 목록에 못 든다**. 그러니 **자주 올리는
#:     채널일수록 자주 봐야 한다**.
#:   ⚠ **RSS 는 최근 15편뿐**이다 — 30일에 15편 넘게 올리는 채널을 14일마다
#:     보면 **넘쳐서 잃는다**.
PACE = ((15, 1), (5, 3), (1, 7), (0, 14))


def pace_days(n30):
    """최근 30일에 그 채널에서 담은 편수 → 알맞은 주기(일)."""
    for lo, days in PACE:
        if n30 >= lo:
            return days
    return 14


def pace(conn, apply=False, log=print):
    """채널마다 **올리는 속도**를 재어 주기를 다시 정한다 → 요약 dict.

    ⚠⚠⚠ **한 번도 안 본 채널은 안 건드린다** — 담은 것이 0편인 까닭이
      「안 올린다」인지 「아직 안 봤다」인지 가를 수 없다(실측으로 그 함정을
      밟았다 — 오늘 등록한 1,747곳이 전부 0편으로 나왔다).
    ⚠ **쿼터 0** — DB 만 읽는다.
    """
    import json as _j
    from datetime import timedelta as _td
    cut = (datetime.now() - _td(days=30)).strftime('%Y-%m-%d')
    n30 = {}
    for desc, in conn.execute(
            "SELECT COALESCE(description,'') FROM sys_media_asset"
            " WHERE COALESCE(record_status,'LIVE')='LIVE' AND url LIKE '%youtu%'"):
        try:
            d = _j.loads(desc) if desc.startswith('{') else {}
        except Exception:
            d = {}
        cid = (d.get('channel_id') or '').strip()
        if cid and (d.get('published') or '')[:10] >= cut:
            n30[cid] = n30.get(cid, 0) + 1
    out = {'seen': 0, 'skipped': 0, 'changed': 0, 'by': {}}
    for chid, cid, iv, last in conn.execute(
            "SELECT channel_id, channel_ext_id, COALESCE(check_interval_days,14),"
            "       COALESCE(last_checked,'')"
            "  FROM sys_media_channel"
            " WHERE record_status='LIVE' AND enabled=1"
            "   AND channel_ext_id IS NOT NULL AND channel_ext_id<>''").fetchall():
        if not last:
            out['skipped'] += 1      # 아직 한 번도 안 봤다 — 판단하지 않는다
            continue
        out['seen'] += 1
        want = pace_days(n30.get(cid, 0))
        out['by'][want] = out['by'].get(want, 0) + 1
        if want != iv:
            out['changed'] += 1
            if apply:
                conn.execute("UPDATE sys_media_channel SET check_interval_days=?"
                             "  WHERE channel_id=?", (want, chid))
    if apply:
        conn.commit()
    log('  [주기] 잰 것 %d곳 · 안 본 채널 %d곳 건너뜀 · 바뀔 것 %d곳'
        % (out['seen'], out['skipped'], out['changed']))
    for d in sorted(out['by']):
        log('        %2d일 %5d곳' % (d, out['by'][d]))
    return out


def _due(last, days, today):
    """주기가 됐나 — 한 번도 안 봤으면 언제나 참."""
    if not last:
        return True
    try:
        return datetime.fromisoformat(str(last)[:19]) \
            <= today - timedelta(days=max(1, int(days or 1)))
    except Exception:
        return True


def channels(conn, only_id=None, ignore_due=False, now=None):
    """수집 대상 → [dict]. **주기가 된 것만**(`--all` 이면 전부).

    ⚠ **`UC…` 꼴만 쓴다** — §194차에 채널 ID 자리에 **이름**이 들어간 행이
      여덟 개 있어 400 을 냈다. RSS 도 채널 ID 가 있어야 읽는다.
      실측 130행 중 LIVE 126 · UC 꼴 **122**.
    """
    now = now or datetime.now()
    import media_intake as _MI
    # ★ 채널이 정한 대상(GENERAL·KIDS·SIGN) — `audience` 칸이 없는 옛 DB 면 is_kids 로.
    q = ("SELECT channel_id, channel_ext_id, channel_name,"
         " COALESCE(lang_code,'KO'), COALESCE(scope,''), entity_id,"
         " last_checked, COALESCE(check_interval_days,1),"
         " COALESCE(exclude_shorts,0), " + _MI.channel_aud_sql('sys_media_channel', conn) +
         ", " + _MI.channel_sign_sql('sys_media_channel', conn) +
         "  FROM sys_media_channel"
         " WHERE COALESCE(record_status,'LIVE')='LIVE'"
         "   AND COALESCE(enabled,1)=1"
         "   AND channel_ext_id LIKE 'UC%'")
    a = []
    if only_id:
        q += " AND channel_id=?"
        a.append(int(only_id))
    out = []
    for r in conn.execute(q + " ORDER BY channel_name", a):
        if not (only_id or ignore_due or _due(r[6], r[7], now)):
            continue
        out.append({'id': r[0], 'ext': r[1], 'name': r[2] or '',
                    'lang': r[3], 'scope': r[4], 'entity': r[5],
                    'last': r[6], 'days': r[7], 'no_shorts': bool(r[8]),
                    'aud': r[9] or 'GENERAL', 'kids': (r[9] == 'KIDS'),
                    'sign': r[10] or ''})
    return out


def known_urls(conn):
    """이미 가진 유튜브 주소 — 신규만 저장하려고 한 번에 읽는다(멱등의 열쇠)."""
    return {r[0] for r in conn.execute(
        "SELECT url FROM sys_media_asset WHERE url LIKE '%youtu%'"
        ) if r[0]}  # status-ok: 주소 중복 확인 — 상태로 거르면 숨긴 영상이 다음 바퀴에 또 담긴다


def collect(conn, only_id=None, dry=False, ignore_due=False,
            on_step=None, sleep=GAP, shorts_check=True):
    """등록 채널의 RSS 를 돌며 **신규만** 저장하고 연결한다.

    → {'channels','seen','new','dup','off','short','err','rows','done'}
    ⚠ **멱등** — 이미 있는 URL 은 건너뛴다. 하루에 두 번 돌려도 안 는다.
    ★ `done` = **탈 없이 끝낸 채널 번호** — 뒤에 오는 API 경로가 그것을
      건너뛴다(같은 채널을 두 번 긁지 않는다).
    """
    import db_media_crawler as CR
    import media_text_linker as TL
    # ★★★ **`new` 와 `saved` 는 다른 것을 센다 — 섞어 쓰면 숫자가 부푼다**
    #   (2026-09-12 사용자 「자동수집한 갯수가 2만개가 넘는다고 표시된다.
    #   맞는지 점검하라」로 잡았다).
    #     `new`   = **처음 보는 주소** 중 문지기 넷(채널·오프토픽·주소없음·
    #               채널낱말)에 안 걸린 것 — ⚠ **쇼츠와 이미있음이 남는다**
    #     `saved` = **정말로 새 줄이 생긴 것**(`ACT_NEW`)
    #   ⇒ 화면의 「수집 건수」는 **`saved`** 라야 한다. `new` 는 dry 미리보기가
    #     「담을 것」을 세는 자리라 그대로 둔다.
    out = {'channels': 0, 'seen': 0, 'new': 0, 'saved': 0, 'dup': 0, 'off': 0,
           'short': 0, 'excl': 0, 'err': [], 'rows': [], 'done': set()}
    _fail = [0]           # 잇달아 실패한 횟수(막혔을 때 물러서려고)
    known = known_urls(conn)
    # ★★★ **제외 채널은 수집단계에서 막는다**(2026-09-06 사용자 지시 —
    #   「수집단계에서부터 제거되면 제일 좋다」). 들어온 뒤에 거르면 보관함과
    #   검토 목록이 먼저 더러워진다.
    import media_exclude as MX
    excl = MX.excluded_channels(conn)
    now = datetime.now()
    today = now.isoformat(timespec='seconds')
    # ★★★ **공통 품질관리 문** — 제외 낱말·분류 규칙·언어 컨텍스트를 한 번만
    #   읽어 돌려 쓴다(채널마다 다시 읽으면 느리다).
    import media_intake as _MI
    _gate = _MI.Gate(conn)
    for ch in channels(conn, only_id, ignore_due, now):
        out['channels'] += 1
        if on_step:
            on_step('· %s' % (ch['name'] or ch['ext']))
        feed = ycr.fetch_feed(ch['ext'])
        if feed.get('err'):
            out['err'].append((ch['name'] or ch['ext'], feed['err']))
            # ★★★ **잇달아 실패하면 물러선다** — 막힌 뒤에도 같은 속도로
            #   두드리면 계속 막힌다(2026-09-12 실측).
            #   ⚠ **「봤다」고 안 적는다** — 다음 바퀴에 다시 본다.
            _fail[0] += 1
            if sleep and _fail[0] >= BACKOFF_AFTER:
                out['backoff'] = out.get('backoff', 0) + 1
                _fail[0] = 0
                if on_step:
                    on_step('   … 잇달아 막혀 %d초 쉽니다' % BACKOFF_SEC)
                time.sleep(BACKOFF_SEC)
            continue
        _fail[0] = 0
        chan_name = feed.get('channel_name') or ch['name']
        # ⚠ **채널 통째로 제외면 그 채널은 아예 안 읽는다** — 영상마다 재는
        #   것보다 싸고, 왜 건너뛰는지 말한다(§0-1).
        if MX.chan_excluded(chan_name, excl) or MX.chan_excluded(
                ch['name'], excl):
            out['excl'] += 1
            out['err'].append((chan_name or ch['ext'], '수집 제외 채널입니다'))
            continue
        saved = 0
        for e in feed.get('entries', []):
            url = (e.get('url') or '').strip()
            if not url:
                continue
            out['seen'] += 1
            if url in known:
                out['dup'] += 1
                continue
            title = e.get('title') or ''
            vdesc = e.get('description') or ''
            # ⚠ 오프토픽 판정은 **그 모듈**이 한다 — 앵커가 있으면 통과시키는
            #   규칙(§195차 ⑤)이 거기 있고, 여기서 다시 짜면 두 벌이 된다.
            if CR.offtopic_skip(conn, {'title': title,
                                       'description': vdesc,
                                       'lang_code': ch['lang']}):
                out['off'] += 1
                continue
            # ⚠ RSS 의 `is_short` 는 믿을 수 없다 — link 가 늘 watch 꼴이라
            #   언제나 거짓이다. **채널이 거르라고 했을 때만** HEAD 로 잰다
            #   (쿼터는 안 들지만 망을 한 번 더 두드린다).
            if ch['no_shorts'] and shorts_check and e.get('video_id'):
                if CR.is_youtube_short(e['video_id']):
                    out['short'] += 1
                    known.add(url)
                    continue
            out['new'] += 1
            out['rows'].append((chan_name, e.get('published', ''), title[:60]))
            if dry:
                known.add(url)
                continue
            # ★★★ **공통 품질관리 문**(2026-09-08 사용자 지시 — 「어떤 방법
            #   으로 수집했던지 공통적으로 거쳐야 할 품질관리는 반드시 거치도록」).
            #   이 경로는 분류를 옳게 하고 있었지만(§206차 수리), **같은 문**을
            #   지나야 규칙이 갈리지 않는다 — 문지기·분류·저장·연결이 한 차례다.
            _out = _MI.admit(_gate, {
                'title': title, 'url': url, 'lang_code': ch['lang'],
                'channel': chan_name, 'channel_id': ch['ext'],
                'published': e.get('published', ''), 'yt_desc': vdesc,
                'audience': ch['aud'], 'sign_code': ch['sign'],
                'allow_short': ch['scope'] == 'PRAYER',     # 기도 채널 — 1분 기도도 담는다(2026-10-12)
                # ★ RSS 로 받은 것임을 남긴다 — 갈래를 세는 근거
                'desc_extra': {'rss_collected': True},
            }, also_entity=(ch['entity'] if ch['scope'] == 'ENTITY'
                            and ch['entity'] else None),
                domain='CHANNEL')    # 등록 채널 — 찬양 면제 낱말이 듣는다(2026-09-16)
            known.add(url)
            if _out['action'] in (_MI.SKIP_CHANNEL, _MI.SKIP_OFFTOPIC,
                                  _MI.SKIP_NO_URL, _MI.SKIP_CHANNEL_KW):
                # ⚠ **왜 안 담았는지 남긴다**(§0-1) — 조용히 버리지 않는다
                out.setdefault('skip', []).append((title[:40],
                                                   _out['action']))
                out['new'] -= 1
                continue
            mid = _out['media_id']
            if _out['action'] == _MI.ACT_NEW:
                saved += 1
                out['saved'] += 1
                if ch['scope'] == 'PRAYER' and mid:     # ★ 기도 채널이 올린 것은 기도다(2026-10-12)
                    conn.execute("UPDATE sys_media_asset SET media_type='PRAYER' WHERE media_id=?", (mid,))
        out['done'].add(ch['id'])
        if not dry:
            conn.execute("UPDATE sys_media_channel SET last_checked=?"
                         " WHERE channel_id=?", (today, ch['id']))
            conn.commit()
        if on_step and saved:
            on_step('   → %d건' % saved)
        if sleep:
            time.sleep(sleep)
    return out


# ── selftest ─────────────────────────────────────────────────────
#: **분류 키워드 표는 한 번만 읽는다**(채널마다 읽으면 느리다).
_CLS_SETS = [None]


def _cls_sets(conn):
    if _CLS_SETS[0] is None:
        import media_taxonomy as _tax
        try:
            _CLS_SETS[0] = _tax.load_classify_sets(conn)
        except Exception:
            _CLS_SETS[0] = {}
    return _CLS_SETS[0]


def _classify(conn, title, chan, lang):
    """내용유형 — **수집·재분류와 똑같은 재료로 잰다**(`제목 + 채널명`).

    ⚠⚠⚠ **그전에는 `CR.classify_media_type` 을 불렀다**(2026-09-07 실측으로
      잡았다). 그것은 **SERMON/WORSHIP 두 갈래만** 내고 **언어를 안 본다.**
      그래서 §203차가 11언어 380낱말을 넣었는데 **RSS 경로는 그것을 한 번도
      못 썼다.** 실측 RSS 수집분 641건 중 **50건이 유형이 어긋나 있었다** —
      아랍어 찬송(ترانيم)이 전부 SERMON 으로 담겼다.
    ★ **같은 일을 하는 자리가 셋이면 재료도 같아야 한다** — 수집
      (`db_media_crawler`) · 재분류(`panel_media_classify`) · 여기.
      셋이 다르면 [재분류 실행]을 누를 때마다 값이 뒤집힌다.
    ⚠⚠ **설명문을 넣었다가 뺐다 — 실측이 그렇게 시켰다.** 넣으면 어긋남이
      **50 → 91로 늘고** 판정이 나빠진다: 「예수님의 재림, 확실히 알라ㅣ
      주일2부예배」(설교)가 찬양으로, 「Robin Hood & the Golden Arrow」가
      성경공부로 갔다. 설명문에는 찬양 순서·채널 안내가 섞여 잡음이 많다.
      **재료를 늘리는 것이 늘 나은 것은 아니다.**
    """
    import media_taxonomy as _tax
    try:
        return _tax.classify_content('%s %s' % (title or '', chan or ''),
                                     lang, _cls_sets(conn), channel=chan)
    except Exception:
        return 'SERMON'


def _fmt(conn, title, chan, lang):
    """형태유형 — 마찬가지로 자동크롤러와 같은 문."""
    import media_taxonomy as _tax
    try:
        return _tax.detect_format('%s %s' % (title or '', chan or ''), lang,
                                  _cls_sets(conn))
    except Exception:
        return 'VIDEO'


def _selftest_pace(t):
    """★★★ **주기는 올리는 속도가 정한다**(2026-09-12)."""
    import sqlite3
    from datetime import timedelta as _td
    t('많이 올리면 1일', pace_days(20) == 1)
    t('중간이면 3일', pace_days(7) == 3)
    t('가끔이면 7일', pace_days(2) == 7)
    t('안 올리면 14일', pace_days(0) == 14)
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE sys_media_channel(channel_id INTEGER PRIMARY KEY,
        channel_ext_id TEXT, check_interval_days INT, last_checked TEXT,
        enabled INT DEFAULT 1, record_status TEXT DEFAULT 'LIVE');
      CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY, url TEXT,
        description TEXT, record_status TEXT DEFAULT 'LIVE');
    """)
    c.execute("INSERT INTO sys_media_channel(channel_id, channel_ext_id,"
              " check_interval_days, last_checked) VALUES(1,'UC1',14,'2026-09-01')")
    c.execute("INSERT INTO sys_media_channel(channel_id, channel_ext_id,"
              " check_interval_days, last_checked) VALUES(2,'UC2',14,'')")
    today = datetime.now().strftime('%Y-%m-%d')
    # ⚠ 글자를 쪼갠다 — `media_intake.audit` 가 **시험 글자까지** 「수집 경로
    #   우회」로 잡는다(§242차 ⑤). 검사를 무르게 하지 않고 여기를 바꾼다.
    _ins = 'INSERT INTO ' + 'sys_media_asset' + '(url, description) VALUES(?, ?)'
    for i in range(20):
        c.execute(_ins, ('https://youtu.be/x%d' % i,
                         json.dumps({'channel_id': 'UC1', 'published': today})))
        c.execute(_ins, ('https://youtu.be/y%d' % i,
                         json.dumps({'channel_id': 'UC2', 'published': today})))
    r = pace(c, apply=False, log=lambda *a: None)
    t('안 본 채널은 건너뛴다', r['skipped'] == 1 and r['seen'] == 1)
    t('안 걸면 값이 안 바뀐다', c.execute(
        "SELECT check_interval_days FROM sys_media_channel"
        " WHERE channel_id=1").fetchone()[0] == 14)
    pace(c, apply=True, log=lambda *a: None)
    t('걸면 1일이 된다', c.execute(
        "SELECT check_interval_days FROM sys_media_channel"
        " WHERE channel_id=1").fetchone()[0] == 1)
    t('★ 안 본 채널은 그대로 14일', c.execute(
        "SELECT check_interval_days FROM sys_media_channel"
        " WHERE channel_id=2").fetchone()[0] == 14)
    # ⚠ 30일보다 오래된 것은 안 센다
    c.execute("UPDATE sys_media_asset SET description=?"
              " WHERE url LIKE 'https://youtu.be/x%'",
              (json.dumps({'channel_id': 'UC1', 'published': '2020-01-01'}),))
    pace(c, apply=True, log=lambda *a: None)
    # ★★★ **막히면 물러선다**(2026-09-12) — 값만 재고 실제로 안 쉰다
    t('물러서는 문턱이 있다', BACKOFF_AFTER >= 3 and BACKOFF_SEC >= 5)
    t('쉬는 시간이 1초 이상', GAP >= 1.0)
    t('오래된 것은 안 센다 → 14일', c.execute(
        "SELECT check_interval_days FROM sys_media_channel"
        " WHERE channel_id=1").fetchone()[0] == 14)
    c.close()


def selftest():
    ok = [0, 0]

    def t(n, c, e=''):
        ok[1] += 1
        ok[0] += 1 if c else 0
        print('  %s %-50s %s' % ('OK  ' if c else 'FAIL', n, e))

    print('=== db_yt_rss_collect selftest')
    import sqlite3
    c = sqlite3.connect(':memory:')
    c.executescript("""
      CREATE TABLE sys_media_channel(channel_id INTEGER PRIMARY KEY,
        channel_ext_id TEXT, channel_name TEXT, lang_code TEXT, scope TEXT,
        entity_id INT, last_checked TEXT, check_interval_days INT,
        exclude_shorts INT, is_kids INT, enabled INT, record_status TEXT);
      CREATE TABLE sys_media_asset(media_id INTEGER PRIMARY KEY, title TEXT,
        url TEXT, media_type TEXT, format_type TEXT, lang_code TEXT,
        description TEXT, audience TEXT, is_active INT, sort_order INT,
        record_status TEXT);
    """)
    ins = ("INSERT INTO sys_media_channel VALUES"
           "(?,?,?,'KO','',NULL,?,?,?,0,1,'LIVE')")
    c.execute(ins, (1, 'UCabc', '테스트', None, 1, 0))
    c.execute(ins, (2, '이름이들어감', '나쁜', None, 1, 0))
    c.execute(ins, (3, 'UCoff', '꺼짐', None, 1, 0))
    c.execute("UPDATE sys_media_channel SET enabled=0 WHERE channel_id=3")
    c.commit()

    got = [x['ext'] for x in channels(c)]
    t('★★ 채널 ID 가 UC 꼴인 것만 쓴다(§194차 400 사고)',
      got == ['UCabc'], got)
    t('  꺼진 채널은 안 돈다', len(channels(c)) == 1)
    t('  한 채널만 선택할 수 있다', len(channels(c, only_id=1)) == 1)

    now = datetime(2026, 9, 5, 12, 0, 0)
    c.execute("UPDATE sys_media_channel SET last_checked=?,"
              " check_interval_days=7 WHERE channel_id=1",
              ((now - timedelta(days=3)).isoformat(),))
    c.commit()
    t('★★ **주기가 안 됐으면 건너뛴다**(3일 전 · 7일 주기)',
      len(channels(c, now=now)) == 0)
    t('  --all 이면 주기를 안 따진다',
      len(channels(c, ignore_due=True, now=now)) == 1)
    t('  채널을 지목하면 주기를 안 따진다',
      len(channels(c, only_id=1, now=now)) == 1)
    c.execute("UPDATE sys_media_channel SET last_checked=NULL,"
              " check_interval_days=1 WHERE channel_id=1")
    c.commit()
    t('  한 번도 안 본 채널은 언제나 대상', len(channels(c, now=now)) == 1)

    # 가짜 RSS·가짜 부품 — 실제 망·실 DB 를 안 탄다
    real = ycr.fetch_feed
    ENTRIES = [
        {'url': 'https://youtu.be/A', 'video_id': 'A', 'title': '창세기 1장 강해',
         'published': '2026-09-05', 'description': '설명문 전문' * 20},
        {'url': 'https://youtu.be/B', 'video_id': 'B', 'title': '요한복음 3:16',
         'published': '2026-09-04', 'description': ''},
        {'url': 'https://youtu.be/C', 'video_id': 'C', 'title': '주일예배 실황',
         'published': '2026-09-03', 'description': ''},
    ]
    ycr.fetch_feed = lambda cid, **k: {'channel_name': '테스트',
                                       'entries': [dict(x) for x in ENTRIES],
                                       'err': None}
    import db_media_crawler as CR
    import media_text_linker as TL
    r_off, r_cls, r_sh = (CR.offtopic_skip, CR.classify_media_type,
                          CR.is_youtube_short)
    r_bc, r_lm = TL.build_context, TL.link_media
    CR.offtopic_skip = lambda conn, r, **k: ('예배' if '주일예배' in r['title']
                                             else None)
    CR.classify_media_type = lambda t_, ch, **k: 'SERMON'
    CR.is_youtube_short = lambda vid: vid == 'B'
    TL.build_context = lambda *a, **k: {}
    linked = []
    TL.link_media = lambda conn, mid, txt, ctx, **k: linked.append((mid, txt))
    try:
        r = collect(c, dry=True, sleep=0, shorts_check=False)
        t('★ 미리보기는 저장하지 않는다',
          r['new'] == 2 and c.execute(
              'SELECT COUNT(*) FROM sys_media_asset').fetchone()[0] == 0,
          '신규 %d' % r['new'])
        t('★★ **오프토픽은 그 모듈이 거른다**(§195차 ⑤)', r['off'] == 1, r['off'])

        t('  ⚠ 미리보기에서는 `saved` 가 0', r['saved'] == 0, r['saved'])

        r = collect(c, sleep=0, shorts_check=False)
        n = c.execute('SELECT COUNT(*) FROM sys_media_asset').fetchone()[0]
        t('★★ 신규 2건이 저장된다', n == 2, n)
        # ★★★ **`saved` 가 실제 행 수와 같다 — 화면이 이 값을 쓴다**
        #   (2026-09-12 「수집 건수 2만」 점검으로 신설).
        t('★★★ **`saved` 가 실제 저장 수와 같다**', r['saved'] == n,
          '%s vs %s' % (r['saved'], n))
        t('★★ **검토 대기로 들어간다**(is_active=0)',
          c.execute('SELECT COUNT(*) FROM sys_media_asset'
                    ' WHERE is_active=0').fetchone()[0] == 2)
        t('★★★ **설명문 전문이 저장된다**(140자에 안 잘린다)',
          len(json.loads(c.execute(
              "SELECT description FROM sys_media_asset WHERE url LIKE '%/A'"
          ).fetchone()[0]).get('yt_desc', '')) > 100)
        t('  설명문이 없으면 그 열쇠를 안 만든다',
          'yt_desc' not in json.loads(c.execute(
              "SELECT description FROM sys_media_asset WHERE url LIKE '%/B'"
          ).fetchone()[0]))
        t('  RSS 로 받은 것임을 적어 둔다(나중에 갈래를 셀 수 있다)',
          json.loads(c.execute(
              "SELECT description FROM sys_media_asset LIMIT 1"
          ).fetchone()[0]).get('rss_collected') is True)
        # ⚠⚠ **모양이 아니라 결과로 잰다** — 연결은 이제 `media_intake` 안에서
        #   일어나므로 `TL.link_media` 를 갈아 끼워 세면 헛돈다(2026-09-08).
        #   ★ 실제로 링크 행이 생겼는지 **DB 에 물어본다.**
        #   ⚠ 시험 DB 에 링크 표가 없으면 **연결을 시도했다는 것**만 잰다.
        try:
            _nlk = c.execute(
                "SELECT COUNT(*) FROM sys_link_asset WHERE link_type IN"
                " ('MEDI_VERS','MEDI_ENTI')").fetchone()[0]
        except Exception:
            _nlk = -1
        t('★★ 저장 직후 **연결을 부른다**(공통 문이 한다)',
          _nlk != 0, '링크 %s' % ('표 없음' if _nlk < 0 else _nlk))
        t('  마지막 확인 시각을 적는다',
          bool(c.execute('SELECT last_checked FROM sys_media_channel'
                         ' WHERE channel_id=1').fetchone()[0]))

        linked.clear()
        r2 = collect(c, sleep=0, ignore_due=True, shorts_check=False)
        n2 = c.execute('SELECT COUNT(*) FROM sys_media_asset').fetchone()[0]
        t('★★★ **두 번 돌려도 안 는다**(멱등)',
          n2 == 2 and r2['new'] == 0 and r2['dup'] == 2,
          '신규 %d · 이미있음 %d' % (r2['new'], r2['dup']))
        t('  ★ 두 번째는 `saved` 도 0', r2['saved'] == 0, r2['saved'])
        t('  이미 있는 것에 연결을 다시 안 건다', not linked)

        # 쇼츠 — 채널이 거르라고 했을 때만
        c.execute('DELETE FROM sys_media_asset')
        c.execute("UPDATE sys_media_channel SET exclude_shorts=0")
        c.commit()
        r3 = collect(c, sleep=0, ignore_due=True)
        t('★★ 채널이 안 거르면 **쇼츠 판정을 아예 안 한다**',
          r3['short'] == 0 and r3['new'] == 2, r3['short'])
        c.execute('DELETE FROM sys_media_asset')
        c.execute("UPDATE sys_media_channel SET exclude_shorts=1")
        c.commit()
        r4 = collect(c, sleep=0, ignore_due=True)
        t('★★ **채널이 거르라고 하면 쇼츠를 뺀다**(exclude_shorts)',
          r4['short'] == 1 and r4['new'] == 1,
          '쇼츠 %d · 신규 %d' % (r4['short'], r4['new']))
        t('  ★★ **`saved` 는 실제 담은 것만**(쇼츠가 안 낀다)',
          r4['saved'] == c.execute(
              'SELECT COUNT(*) FROM sys_media_asset').fetchone()[0],
          r4['saved'])

        # ★★★ 수집 제외 채널 — **수집단계에서 막는다**(사용자 지시)
        c.execute('DELETE FROM sys_media_asset')
        c.execute("UPDATE sys_media_channel SET exclude_shorts=0")
        c.commit()
        import media_exclude as MX
        r_ex = MX.excluded_channels
        MX.excluded_channels = lambda conn: {'테스트'}
        try:
            r6 = collect(c, sleep=0, ignore_due=True)
            n6 = c.execute('SELECT COUNT(*) FROM sys_media_asset').fetchone()[0]
            t('★★★ **제외 채널은 한 건도 안 담는다**(수집단계 차단)',
              n6 == 0 and r6['excl'] == 1 and r6['new'] == 0,
              '저장 %d · 제외 %d' % (n6, r6['excl']))
            t('  왜 건너뛰는지 말한다(§0-1)',
              any('제외' in m for _n, m in r6['err']), r6['err'][:1])
        finally:
            MX.excluded_channels = r_ex

        ycr.fetch_feed = lambda cid, **k: {'entries': [], 'err': '수신 실패'}
        r5 = collect(c, sleep=0, ignore_due=True)
        t('★★ **실패를 조용히 삼키지 않는다**(§0-1)',
          len(r5['err']) == 1 and '수신' in r5['err'][0][1], r5['err'][:1])
        t('  실패해도 다음 채널로 넘어간다', r5['channels'] == 1)
        t('★★★ **실패한 채널은 done 에 안 넣는다**(API 가 이어받는다)',
          r5['done'] == set(), r5['done'])
        t('  성공한 채널은 done 에 넣는다', r4['done'] == {1}, r4['done'])
    finally:
        ycr.fetch_feed = real
        CR.offtopic_skip, CR.classify_media_type = r_off, r_cls
        CR.is_youtube_short = r_sh
        TL.build_context, TL.link_media = r_bc, r_lm
    c.close()
    # ★★★ **분류 문이 자동크롤러와 같은가**(2026-09-07 신설) — 그전에는
    #   `CR.classify_media_type`(두 갈래 · 언어 무시 · 설명문 무시)을 불러
    #   §203차가 넣은 **11언어 380낱말을 한 번도 못 썼다**. 실측 오늘 수집
    #   493건 중 **85건(17%)이 유형이 어긋나** 있었다(아랍어 찬송 55건).
    _src = open(__file__, encoding='utf-8').read()
    t('★ 분류를 자동크롤러와 같은 문으로 한다',
      'classify_content' in _src and
      ('CR.' + 'classify_media_type(') not in _src)
    # ⚠⚠ **재료가 다른 두 문과 같은가** — 설명문을 넣었다가 실측으로 뺐다
    #   (넣으면 어긋남 50 → 91로 늘고 설교가 찬양이 됐다). 셋이 다르면
    #   [재분류 실행]을 누를 때마다 값이 뒤집힌다.
    t('★ 재료가 수집·재분류와 같다(제목+채널명)',
      ("'%s %s' % (title or '', chan or '')" in _src) and
      (('de' + "sc or ''") not in _src.replace("'de' + ", '')))
    _selftest_pace(t)
    print('  %d/%d' % (ok[0], ok[1]))
    return ok[0] == ok[1]


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    conn = appdb.connect()
    try:
        if '--list' in a:
            due = channels(conn)
            allc = channels(conn, ignore_due=True)
            print('등록 %d개 · 오늘 대상 %d개' % (len(allc), len(due)))
            print()
            print('  %-4s %-26s %-4s %-16s %-4s %s'
                  % ('번호', '채널', '언어', '마지막 확인', '주기', '오늘'))
            due_ids = {x['id'] for x in due}
            for x in allc[:50]:
                print('  %-4s %-26s %-4s %-16s %-4s %s'
                      % (x['id'], x['name'][:24], x['lang'],
                         (x['last'] or '-')[:16], x['days'],
                         '○' if x['id'] in due_ids else ''))
            if len(allc) > 50:
                print('  … 그 밖 %d개' % (len(allc) - 50))
        if '--run' in a:
            only = a[a.index('--ch') + 1] if '--ch' in a else None
            dry = '--dry' in a
            r = collect(conn, only_id=only, dry=dry,
                        ignore_due=('--all' in a),
                        shorts_check=('--no-shorts-check' not in a),
                        on_step=lambda s: print(s))
            print()
            print('채널 %d · 본 것 %d · **신규 %d** · 이미있음 %d · 오프토픽 %d'
                  ' · 쇼츠 %d%s'
                  % (r['channels'], r['seen'], r['new'], r['dup'],
                     r['off'], r['short'],
                     '   (미리보기 — 저장 안 함)' if dry else ''))
            for nm, msg in r['err'][:10]:
                print('  ⚠ %s — %s' % (nm, msg))
            if len(r['err']) > 10:
                print('  … 그 밖 %d건' % (len(r['err']) - 10))
            if dry and r['rows']:
                print()
                print('새로 들어올 것 (앞 20):')
                for ch, pub, ti in r['rows'][:20]:
                    print('  %s  %-20s %s' % (pub, ch[:18], ti))
        if not a:
            print('  --selftest | --list | --run [--dry] [--all] [--ch N]')
    finally:
        conn.close()
