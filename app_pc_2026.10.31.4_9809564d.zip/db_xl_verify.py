# -*- coding: utf-8 -*-
"""번역 교차 검증 — **번역한 AI 와 다른 모델**에게 원문 + 옮긴 글을 함께 주고 **틀린 곳만** 목록으로 받는다.

★ 2026-10-27 신설(docs/1.txt 15 · 사용자 「다른 AI 가 번역한 것을 네가 검증한다면 오류 가능성을 줄일 수 있는가」).
  사라 오번역(「아브라함의 아들」 · 「도리어 도시」 · 「도는」)은 기계 게이트(문단 수·서식)가 못 본다 — 뜻을 봐야 잡힌다.
  ⇒ 고치지 않는다. **지적만** 받는다(고친 글을 받으면 그 글이 또 새 흠을 낳는다 — 317차-90 측정).
  사람이 그 지적을 보고 고치거나, 지적된 곳만 다시 번역한다.

⚠ 번역은 `gemini-3.5-flash-lite` 가 했다 — 검증은 그것과 **다른 모델**이라야 실수가 겹치지 않는다(기본 gemini-3.5-flash).
⚠ 답은 JSON 만 받는다 · 못 읽으면 실패로 적는다(조용히 「흠 없음」으로 치지 않는다 §0-1).

  python db_xl_verify.py --selftest
  python db_xl_verify.py --file _xlcheck/all.json --out _xlcheck/ai_review.json [--model gemini-3.5-flash] [--limit N]
"""
import json
import re
import sys
import time

KINDS = ('WRONG', 'GARBLE', 'OMIT', 'ADD', 'NAME')

PROMPT = """You check a translation against its source. Do NOT rewrite it.
List only real meaning errors, as JSON. Kinds:
WRONG  = meaning changed (kinship, gender, number, person, place, negation, verse reference)
GARBLE = broken or nonsense words in the translation
OMIT   = a sentence or clause of the source is missing
ADD    = content not in the source
NAME   = a proper name not in the standard spelling of that language's Bible
Ignore style, word choice, a title line, reference-abbreviation format, harmless paraphrase.
Answer ONLY this JSON: {"issues":[{"kind":"WRONG","src":"short source snippet","tr":"short translation snippet","note":"one line"}]}
If there are no errors: {"issues":[]}

[Source — %s]
%s

[Translation — %s]
%s
"""


def parse(text):
    """모델 답 → 지적 목록 · 못 읽으면 None(실패)."""
    if not text:
        return None
    m = re.search(r'\{.*\}', text, re.S)
    if not m:
        return None
    try:
        d = json.loads(m.group(0))
    except Exception:                                   # noqa: BLE001
        return None
    out = []
    for it in d.get('issues') or []:
        if not isinstance(it, dict):
            continue
        k = str(it.get('kind') or '').upper()
        if k not in KINDS:
            continue
        out.append({'kind': k, 'src': str(it.get('src') or '')[:200], 'tr': str(it.get('tr') or '')[:200],
                    'note': str(it.get('note') or '')[:300]})
    return out


def verify(src, tr, src_lang='EN', tr_lang='KO', model='gemini-3.5-flash', conn=None, _call=None):
    """→ (지적 목록 | None, 이유)."""
    if _call is None:
        import ai_client as AC
        _call = AC.call
    r = _call(PROMPT % (src_lang, src, tr_lang, tr), model=model, conn=conn, temperature=0)
    if not r.get('ok'):
        return None, r.get('why') or 'fail'
    got = parse(r.get('text') or '')
    return got, '' if got is not None else 'unparsed'


def run_file(path, out, model, limit=0):
    import appdb
    conn = appdb.connect()
    items = json.load(open(path, encoding='utf-8'))
    if limit:
        items = items[:limit]
    res = []
    for i, it in enumerate(items, 1):
        got, why = verify(it['en'], it['ko'], 'EN', 'KO', model, conn)
        res.append({'id': it['id'], 'label': it.get('label', ''), 'issues': got, 'why': why})
        print('%d/%d %s %s' % (i, len(items), it.get('label', ''), why or len(got)), flush=True)
        json.dump(res, open(out, 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
        time.sleep(0.5)
    return res


def selftest():
    n = 0
    bad = []

    def ck(c, m):
        nonlocal n
        n += 1
        if not c:
            bad.append(m)
    ck(parse('{"issues":[]}') == [], '빈 지적')
    ck(parse('```json\n{"issues":[{"kind":"wrong","src":"wife","tr":"아들","note":"x"}]}\n```')[0]['kind'] == 'WRONG',
       '코드 울타리·소문자 갈래')
    ck(parse('잘 모르겠다') is None, '못 읽으면 None')
    ck(parse('{"issues":[{"kind":"STYLE"}]}') == [], '모르는 갈래는 뺀다')

    def fake(prompt, **kw):
        assert 'wife' in prompt and '아들' in prompt
        return {'ok': True, 'text': '{"issues":[{"kind":"WRONG","src":"wife","tr":"아들","note":"아내"}]}'}
    got, why = verify('the wife of Abraham', '아브라함의 아들', _call=fake)
    ck(got and got[0]['kind'] == 'WRONG' and why == '', '가짜 호출 왕복')
    got, why = verify('a', 'b', _call=lambda p, **k: {'ok': False, 'why': 'HTTP 429'})
    ck(got is None and why == 'HTTP 429', '실패는 실패로')
    for m in bad:
        print('FAIL', m)
    print('%d/%d' % (n - len(bad), n))
    return not bad


if __name__ == '__main__':
    a = sys.argv[1:]
    if '--selftest' in a:
        sys.exit(0 if selftest() else 1)
    if '--file' in a:
        f = a[a.index('--file') + 1]
        o = a[a.index('--out') + 1] if '--out' in a else '_xlcheck/ai_review.json'
        m = a[a.index('--model') + 1] if '--model' in a else 'gemini-3.5-flash'
        lim = int(a[a.index('--limit') + 1]) if '--limit' in a else 0
        run_file(f, o, m, lim)
