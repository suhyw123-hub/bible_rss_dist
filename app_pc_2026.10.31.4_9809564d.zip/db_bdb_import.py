# -*- coding: utf-8 -*-
"""db_bdb_import.py — BDB(Brown-Driver-Briggs) 사전 층 적재 (영구).

2026-09-03 (188차) — **무삭제 전문(unabridged)으로 승격.**
  · 원자료 = github.com/eliranwong/unabridged-BDB-Hebrew-lexicon 의
    `unabridged-BDB-Hebrew-lexicon.csv`(탭 구분 · 33.7MB · 10,022항목).
    readme 가 「License: Public domain document」를 명기(규칙 ③ — 파일이
    스스로 밝힘). 정리(마크업) = Eliran Wong(marvel.bible) — 출처는
    license_info 에 적는다.
  · 실측 — 헤세드 H2617 전문 **37,502자**(옛 OSHB 개요는 332자 = 113배).
    화면 머리의 「OSHB 전사 개요」 단서가 필요 없어졌다.
  · 스트롱 다리가 2열에 내장(H2617 · 복수는 H1001_H1002 밑줄 결합 ·
    H0 = 자리표라 제외) — LexicalIndex.xml 이 더 이상 필요 없다.
  · 동음이의(같은 스트롱 여러 항목 — 640번호)는 전부 다리로 싣는다.
    화면([BDB] 갈래)이 항목마다 한 덩이로 그린다.

옛 정본(OSHB BrownDriverBriggs.xml — 진행 중 전사·뜻 개요 수준)은
`_lexicon_raw/bdb.xml` 에 남아 있지만 **읽지 않는다** — 원본 재유도의
정본이 CSV 로 바뀌었다(§174차 원칙 그대로 · 멱등 = 전체 재유도).

저장 (스키마 불변 — 화면·overlay_read 무수정):
  sys_bdb_entry(bdb_id PK · heb · body · status='')
  sys_bdb_map(strong · bdb_id)

사용:
  python db_bdb_import.py --selftest   (의무)
  python db_bdb_import.py --load      (멱등 — 전체 재유도)
  python db_bdb_import.py --status
"""
import csv
import html
import io
import os
import re
import sys

sys.stdout = io.TextIOWrapper(io.FileIO(1, 'w', closefd=False),
                              encoding='utf-8', errors='replace')

RAW = os.path.join(os.path.dirname(os.path.abspath(__file__)), '_lexicon_raw')
CSV = os.path.join(RAW, 'bdbfull.csv')

DDL_E = ("CREATE TABLE IF NOT EXISTS sys_bdb_entry("
         "bdb_id TEXT PRIMARY KEY, heb TEXT, body TEXT, status TEXT)")
DDL_M = ("CREATE TABLE IF NOT EXISTS sys_bdb_map("
         "strong TEXT, bdb_id TEXT, PRIMARY KEY(strong, bdb_id))")

_RX_H1 = re.compile(r'<h1>.*?</h1>', re.S)
_RX_NAV = re.compile(r'<div class="navigation">.*?</div>', re.S)
_RX_BLOCK = re.compile(r'</?(?:p|div[^>]*|hr[^>]*)>', re.I)
_RX_TAG = re.compile(r'<[^>]+>')
_RX_HEB = re.compile(r'<bdbheb>(.*?)</bdbheb>', re.S)


def _flat(content):
    """마크업 → 읽는 글. 구획(div.section·point·문단)은 줄바꿈으로 남긴다.

    ⚠ 태그를 그냥 지우면 문단이 한 벽이 된다 — 블록 태그를 먼저 줄바꿈으로
      바꾸고 나머지 태그를 걷는다(BDB <status> 함정과 같은 계열의 자리)."""
    s = _RX_H1.sub('', content, count=1)
    s = _RX_NAV.sub('', s, count=1)
    s = _RX_BLOCK.sub('\n', s)
    s = _RX_TAG.sub('', s)
    s = html.unescape(s)
    s = re.sub(r'[ \t]+', ' ', s)
    s = re.sub(r' ?\n ?', '\n', s)
    s = re.sub(r'\n{2,}', '\n', s)
    return s.strip()


def parse_csv(path=None):
    """→ [(bdb_id, heb, body, '')], [(strong, bdb_id)]."""
    csv.field_size_limit(10 ** 8)
    entries, maps = [], []
    with open(path or CSV, encoding='utf-8', newline='') as f:
        rd = csv.reader(f, delimiter='\t')
        hdr = next(rd, None)
        if not hdr or hdr[0] != 'BDBid':
            raise SystemExit('bdbfull.csv 머리가 다르다: %r' % (hdr,))
        for row in rd:
            if len(row) < 3:
                continue
            bid, strongs, content = row[0].strip(), row[1].strip(), row[2]
            if not bid:
                continue
            m = _RX_HEB.search(content)
            heb = _RX_TAG.sub('', m.group(1)).strip() if m else ''
            body = _flat(content)
            if len(body) < 10:
                continue
            entries.append((bid, heb, body, ''))
            for st in strongs.split('_'):
                st = st.strip()
                # H0 = 자리표(알파벳 머리 등) — 낱말이 아니다
                if re.fullmatch(r'H\d+[a-z]?', st) and st != 'H0':
                    maps.append((st, bid))
    return entries, maps


def load(conn, entries=None, maps=None):
    if entries is None:
        entries, maps = parse_csv()
    conn.execute(DDL_E)
    conn.execute(DDL_M)
    conn.execute('DELETE FROM sys_bdb_entry')
    conn.execute('DELETE FROM sys_bdb_map')
    conn.executemany('INSERT OR REPLACE INTO sys_bdb_entry VALUES(?,?,?,?)',
                     entries)
    conn.executemany('INSERT OR REPLACE INTO sys_bdb_map VALUES(?,?)',
                     sorted(set(maps or [])))
    conn.commit()
    print('BDB 항목 %d · 스트롱 다리 %d' % (len(entries), len(set(maps or []))))


def status(conn):
    try:
        n = conn.execute('SELECT COUNT(*) FROM sys_bdb_entry').fetchone()[0]
        m = conn.execute('SELECT COUNT(*) FROM sys_bdb_map').fetchone()[0]
        j = conn.execute(
            "SELECT COUNT(DISTINCT m.strong) FROM sys_bdb_map m"
            " JOIN sys_lemma_master lm ON lm.strong=m.strong").fetchone()[0]
        sz = conn.execute('SELECT SUM(LENGTH(body)) FROM sys_bdb_entry'
                          ).fetchone()[0] or 0
        print('항목 %d · 다리 %d · 마스터와 겹치는 스트롱 %d · 본문 %.1fMB'
              % (n, m, j, sz / 1e6))
    except Exception as e:
        print('미적재 (%s)' % e)


def selftest():
    import sqlite3
    ok = [0, 0]

    def t(name, cond, extra=''):
        ok[0] += 1
        ok[1] += 1 if cond else 0
        print('  %s %s %s' % ('OK ' if cond else 'FAIL', name, extra))

    entries, maps = parse_csv()
    t('항목 9,000~11,000', 9000 <= len(entries) <= 11000, len(entries))
    t('다리 9,000+', len(set(maps)) >= 9000, len(set(maps)))
    by = {e[0]: e for e in entries}
    m = {}
    for st, bid in maps:
        m.setdefault(st, bid)
    ch = by.get(m.get('H2617', ''), None)
    t('헤세드 실재·goodness 포함', bool(ch and 'goodness' in ch[2]),
      (ch[2][:40] if ch else ''))
    # 원문 37,502자는 마크업 포함 — 걷은 전문이 6,154자(개요 332자의 18배)
    t('헤세드 = 전문(4,000자+)', bool(ch and len(ch[2]) > 4000),
      (len(ch[2]) if ch else 0))
    t('태그 잔재 0', bool(ch and '<' not in ch[2] and 'onclick' not in ch[2]))
    t('머리 히브리 표제어', bool(ch and ch[1]))
    t('복수 스트롱 갈라 싣기 — H1001', 'H1001' in dict(maps))
    t('H0 자리표 제외', 'H0' not in dict(maps))
    # 메모리 적재 왕복 — 멱등
    conn = sqlite3.connect(':memory:')
    load(conn, entries[:50], maps[:50])
    c0 = conn.execute('SELECT COUNT(*) FROM sys_bdb_entry').fetchone()[0]
    load(conn, entries[:50], maps[:50])
    c1 = conn.execute('SELECT COUNT(*) FROM sys_bdb_entry').fetchone()[0]
    t('멱등', c0 == c1 == 50)
    conn.close()
    print('db_bdb_import selftest %d/%d' % (ok[1], ok[0]))
    return ok[1] == ok[0]


if __name__ == '__main__':
    if '--selftest' in sys.argv:
        sys.exit(0 if selftest() else 1)
    import appdb
    conn = appdb.connect('bible_master.db')
    try:
        if '--load' in sys.argv:
            load(conn)
        else:
            status(conn)
    finally:
        conn.close()
